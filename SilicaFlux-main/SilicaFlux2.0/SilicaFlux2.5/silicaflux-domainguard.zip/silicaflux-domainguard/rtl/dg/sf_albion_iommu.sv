// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | sf_albion_iommu            (PRIMARY MODULE, module 97)
//
// Multi-port DMA memory-isolation and IOVA->PA translation unit.
//
//   untrusted initiators --> [ us_* port 0..N-1 ] --> check --> [ ds_* port 0..N-1 ] --> fabric / memory
//   privileged admin     --> [ csr_* ]            (tables, domains, fault log)
//
// WHAT THIS IS / IS NOT
//   * A simple, flat, register-based translation unit: 4 KiB pages and naturally
//     aligned power-of-two regions, per-domain permissions, deny-by-default.
//   * It is NOT a RISC-V IOMMU (no in-memory device/process contexts, no page
//     walker, no command/fault queues in memory, no MSI translation, no ATS/PRI).
//     It must not be described as RISC-V IOMMU compliant.
//
// MODEL
//   domain   : isolation unit (tenant). Has enable, read-cap, write-cap.
//   context  : (port, stream-id) -> domain binding, set by the admin. The
//              stream id is requester-asserted; the PORT is the trust boundary.
//   entry    : {valid, domain, IOVA page, PA page, order, R, W}. Shared pool,
//              domain-tagged. Entries are immutable until invalidated.
//   request  : burst {tid, sid, we, iova, len}; must be beat-aligned and must
//              not cross a 4 KiB boundary (AXI rule), else it is denied.
//
// ADMIN OPERATIONS are atomic: staged in STG_* registers then committed by one
// CMD write. Every committed operation ends with a DRAIN: new checks are held
// off (STATUS.busy=1) until every burst that was already granted has finished,
// so when busy falls no authorisation from before the operation is still in
// use. Software must wait for busy=0 before reusing a physical page that an
// invalidation released.
//
// RESET: asynchronous assert, active-low. Reset state = globally disabled, no
// contexts, no entries, all domains disabled, empty fault log. Every request
// is denied with an error response until a privileged admin configures it.
// -----------------------------------------------------------------------------
`include "sf_albion_defs.svh"
module sf_albion_iommu #(
  parameter int NUM_PORTS   = 3,
  parameter int NUM_DOMAINS = 8,      // <= 256
  parameter int NUM_STREAMS = 4,      // per port, <= 16
  parameter int NUM_ENTRIES = 16,     // <= 256
  parameter int IOVA_W      = 32,     // byte address bits, 13..32
  parameter int PA_W        = 40,     // byte address bits, 13..44
  parameter int DATA_W      = 32,     // 8,16,32,64,...
  parameter int LEN_W       = 4,      // max burst = 2^LEN_W beats, 2^LEN_W*DATA_W/8 <= 4096
  parameter int TID_W       = 4,      // <= 8
  parameter int MAX_ORDER   = 8,      // largest region = 4 KiB << MAX_ORDER, <= 15
  parameter int FQ_DEPTH    = 8,      // fault-log depth
  parameter int CNT_W       = 16,     // statistics counter width
  // derived
  parameter int PORT_W = (NUM_PORTS   > 1) ? $clog2(NUM_PORTS)   : 1,
  parameter int DOM_W  = (NUM_DOMAINS > 1) ? $clog2(NUM_DOMAINS) : 1,
  parameter int SID_W  = (NUM_STREAMS > 1) ? $clog2(NUM_STREAMS) : 1,
  parameter int ENT_W  = (NUM_ENTRIES > 1) ? $clog2(NUM_ENTRIES) : 1,
  parameter int IPN_W  = IOVA_W - 12,
  parameter int PPN_W  = PA_W - 12,
  parameter int ORD_W  = (MAX_ORDER > 0) ? $clog2(MAX_ORDER + 1) : 1,
  parameter int STRB_W = DATA_W / 8
) (
  input  logic                         clk,
  input  logic                         rst_n,

  // ---------------- upstream (untrusted initiators), one slice per port ----------------
  input  logic [NUM_PORTS-1:0]            us_cmd_valid,
  output logic [NUM_PORTS-1:0]            us_cmd_ready,
  input  logic [NUM_PORTS*TID_W-1:0]      us_cmd_tid,
  input  logic [NUM_PORTS*SID_W-1:0]      us_cmd_sid,
  input  logic [NUM_PORTS-1:0]            us_cmd_we,
  input  logic [NUM_PORTS*IOVA_W-1:0]     us_cmd_addr,
  input  logic [NUM_PORTS*LEN_W-1:0]      us_cmd_len,
  input  logic [NUM_PORTS-1:0]            us_w_valid,
  output logic [NUM_PORTS-1:0]            us_w_ready,
  input  logic [NUM_PORTS*DATA_W-1:0]     us_w_data,
  input  logic [NUM_PORTS*STRB_W-1:0]     us_w_strb,
  output logic [NUM_PORTS-1:0]            us_r_valid,
  input  logic [NUM_PORTS-1:0]            us_r_ready,
  output logic [NUM_PORTS*TID_W-1:0]      us_r_tid,
  output logic [NUM_PORTS-1:0]            us_r_we,
  output logic [NUM_PORTS-1:0]            us_r_err,
  output logic [NUM_PORTS-1:0]            us_r_last,
  output logic [NUM_PORTS*DATA_W-1:0]     us_r_data,

  // ---------------- downstream (trusted fabric / memory) ----------------
  output logic [NUM_PORTS-1:0]            ds_cmd_valid,
  input  logic [NUM_PORTS-1:0]            ds_cmd_ready,
  output logic [NUM_PORTS*TID_W-1:0]      ds_cmd_tid,
  output logic [NUM_PORTS-1:0]            ds_cmd_we,
  output logic [NUM_PORTS*PA_W-1:0]       ds_cmd_addr,
  output logic [NUM_PORTS*LEN_W-1:0]      ds_cmd_len,
  output logic [NUM_PORTS-1:0]            ds_w_valid,
  input  logic [NUM_PORTS-1:0]            ds_w_ready,
  output logic [NUM_PORTS*DATA_W-1:0]     ds_w_data,
  output logic [NUM_PORTS*STRB_W-1:0]     ds_w_strb,
  output logic [NUM_PORTS-1:0]            ds_w_last,
  input  logic [NUM_PORTS-1:0]            ds_r_valid,
  output logic [NUM_PORTS-1:0]            ds_r_ready,
  input  logic [NUM_PORTS-1:0]            ds_r_err,
  input  logic [NUM_PORTS*DATA_W-1:0]     ds_r_data,

  // ---------------- privileged admin CSR bus (single-cycle) ----------------
  input  logic                         csr_valid,
  input  logic                         csr_we,
  input  logic [7:0]                   csr_addr,
  input  logic [31:0]                  csr_wdata,
  input  logic                         csr_priv,    // 1 = privileged (hypervisor / secure firmware)
  output logic                         csr_hit,     // 0 = bus error (unmapped, RO write, or not privileged)
  output logic [31:0]                  csr_rdata,

  output logic                         irq          // level: fault log non-empty & irq_en
);

  // ===========================================================================
  // Elaboration-time configuration checks
  // ===========================================================================
  if (IOVA_W < 13 || IOVA_W > 32)        begin : g_chk_iova $error("IOVA_W must be 13..32"); end
  if (PA_W   < 13 || PA_W   > 44)        begin : g_chk_pa   $error("PA_W must be 13..44");   end
  if (DATA_W < 8  || (DATA_W & (DATA_W-1)) != 0)
                                         begin : g_chk_dw   $error("DATA_W must be a power of two >= 8"); end
  if ((1 << LEN_W) * (DATA_W/8) > 4096)  begin : g_chk_len  $error("max burst exceeds 4 KiB"); end
  if (MAX_ORDER > 15 || MAX_ORDER > IPN_W || MAX_ORDER > PPN_W)
                                         begin : g_chk_ord  $error("MAX_ORDER too large"); end
  if (NUM_DOMAINS > 256 || NUM_ENTRIES > 256 || NUM_STREAMS > 16 || NUM_PORTS > 256 || TID_W > 8 || LEN_W > 8)
                                         begin : g_chk_cnt  $error("CSR field width exceeded"); end

  localparam int CIW      = $clog2(NUM_PORTS * NUM_STREAMS + 1);   // context-index width
  localparam int FQ_PW    = (FQ_DEPTH > 1) ? $clog2(FQ_DEPTH) : 1;
  localparam int FQ_CW    = $clog2(FQ_DEPTH + 1);
  localparam int R_CAUSE  = 0;
  localparam int R_WE     = 4;
  localparam int R_DOMV   = 5;
  localparam int R_DOM    = 6;
  localparam int R_PORT   = R_DOM  + DOM_W;
  localparam int R_SID    = R_PORT + PORT_W;
  localparam int R_TID    = R_SID  + SID_W;
  localparam int R_LEN    = R_TID  + TID_W;
  localparam int R_ADDR   = R_LEN  + LEN_W;
  localparam int FQ_REC_W = R_ADDR + IOVA_W;

  localparam logic [31:0] IPN_MASK32 = (IPN_W >= 32) ? 32'hFFFF_FFFF : ((32'd1 << IPN_W) - 32'd1);
  localparam logic [31:0] PPN_MASK32 = (PPN_W >= 32) ? 32'hFFFF_FFFF : ((32'd1 << PPN_W) - 32'd1);

  // CSR word offsets
  localparam logic [7:0] A_ID = 8'h00, A_CAP0 = 8'h01, A_CAP1 = 8'h02, A_CAP2 = 8'h03,
                         A_CTRL = 8'h04, A_STATUS = 8'h05,
                         A_STG_IPN = 8'h08, A_STG_PPN = 8'h09, A_STG_ATTR = 8'h0A,
                         A_STG_CTX = 8'h0B, A_STG_DOM = 8'h0C, A_CMD = 8'h0D,
                         A_FQ_STATUS = 8'h10, A_FQ_META = 8'h11, A_FQ_IOVA = 8'h12,
                         A_FQ_ID = 8'h13, A_FQ_POP = 8'h14,
                         A_SEL_DOM = 8'h18, A_DOM_CFG = 8'h19, A_DOM_FCNT = 8'h1A,
                         A_DOM_FMASK = 8'h1B, A_SEL_ENT = 8'h1C, A_ENT_RD0 = 8'h1D,
                         A_ENT_RD1 = 8'h1E, A_ENT_RD2 = 8'h1F, A_CTX_RD = 8'h20,
                         A_SEL_PORT = 8'h21, A_PORT_OK = 8'h22, A_PORT_DENY = 8'h23;
  localparam logic [31:0] ID_VALUE = 32'h4447_0100;   // "DG" v1.0

  // ===========================================================================
  // Architectural state
  // ===========================================================================
  logic                                   glob_en, irq_en;
  logic [NUM_DOMAINS-1:0]                 dom_en, dom_rd, dom_wr;
  logic [NUM_PORTS*NUM_STREAMS-1:0]       ctx_valid;
  logic [NUM_PORTS*NUM_STREAMS*DOM_W-1:0] ctx_dom;
  logic [NUM_ENTRIES-1:0]                 ent_valid, ent_r, ent_w;
  logic [NUM_ENTRIES*DOM_W-1:0]           ent_dom;
  logic [NUM_ENTRIES*IPN_W-1:0]           ent_ipn;
  logic [NUM_ENTRIES*PPN_W-1:0]           ent_ppn;
  logic [NUM_ENTRIES*ORD_W-1:0]           ent_ord;
  logic                                   blk;            // drain in progress: no new CHECKs

  logic [31:0] stg_ipn, stg_ppn, stg_attr, stg_ctx, stg_dom;
  logic [31:0] sel_dom, sel_ent, sel_port;
  logic        admin_viol, fq_ovf;
  logic [3:0]  last_err;

  logic [NUM_DOMAINS*CNT_W-1:0]  dom_fcnt;
  logic [NUM_DOMAINS*16-1:0]     dom_fmask;
  logic [NUM_PORTS*CNT_W-1:0]    port_ok, port_deny;

  // fault log
  logic [FQ_REC_W-1:0] fq_mem [FQ_DEPTH];
  logic [FQ_PW-1:0]    fq_wr, fq_rd;
  logic [FQ_CW-1:0]    fq_cnt;
  logic [CNT_W-1:0]    fq_drop;

  // ===========================================================================
  // Per-port filter + checker
  // ===========================================================================
  logic [NUM_PORTS-1:0]            p_act, p_auth, p_auth_we, p_flt_req, p_flt_gnt, p_ev_grant, p_ev_deny;
  logic [NUM_PORTS*DOM_W-1:0]      p_auth_dom;
  logic [NUM_PORTS*ENT_W-1:0]      p_auth_idx;
  logic [NUM_PORTS*SID_W-1:0]      p_auth_sid;
  logic [NUM_PORTS*4-1:0]          p_flt_cause;
  logic [NUM_PORTS-1:0]            p_flt_we, p_flt_domv;
  logic [NUM_PORTS*DOM_W-1:0]      p_flt_dom;
  logic [NUM_PORTS*SID_W-1:0]      p_flt_sid;
  logic [NUM_PORTS*TID_W-1:0]      p_flt_tid;
  logic [NUM_PORTS*LEN_W-1:0]      p_flt_len;
  logic [NUM_PORTS*IOVA_W-1:0]     p_flt_addr;

  logic [NUM_PORTS*SID_W-1:0]      p_chk_sid;
  logic [NUM_PORTS-1:0]            p_chk_we;
  logic [NUM_PORTS*IOVA_W-1:0]     p_chk_addr;
  logic [NUM_PORTS*LEN_W-1:0]      p_chk_len;
  logic [NUM_PORTS-1:0]            p_chk_grant, p_chk_domv;
  logic [NUM_PORTS*4-1:0]          p_chk_fault;
  logic [NUM_PORTS*PA_W-1:0]       p_chk_pa;
  logic [NUM_PORTS*DOM_W-1:0]      p_chk_dom;
  logic [NUM_PORTS*ENT_W-1:0]      p_chk_idx;

  genvar gp;
  generate
    for (gp = 0; gp < NUM_PORTS; gp++) begin : g_port
      sf_albion_xlate #(
        .NUM_DOMAINS(NUM_DOMAINS), .NUM_STREAMS(NUM_STREAMS), .NUM_ENTRIES(NUM_ENTRIES),
        .IOVA_W(IOVA_W), .PA_W(PA_W), .DATA_W(DATA_W), .LEN_W(LEN_W), .MAX_ORDER(MAX_ORDER)
      ) u_xlate (
        .glob_en(glob_en), .dom_en(dom_en), .dom_rd(dom_rd), .dom_wr(dom_wr),
        .ctx_valid(ctx_valid[gp*NUM_STREAMS +: NUM_STREAMS]),
        .ctx_dom(ctx_dom[gp*NUM_STREAMS*DOM_W +: NUM_STREAMS*DOM_W]),
        .ent_valid(ent_valid), .ent_dom(ent_dom), .ent_ipn(ent_ipn), .ent_ppn(ent_ppn),
        .ent_ord(ent_ord), .ent_r(ent_r), .ent_w(ent_w),
        .sid(p_chk_sid[gp*SID_W +: SID_W]), .we(p_chk_we[gp]),
        .iova(p_chk_addr[gp*IOVA_W +: IOVA_W]), .len(p_chk_len[gp*LEN_W +: LEN_W]),
        .grant(p_chk_grant[gp]), .fault(p_chk_fault[gp*4 +: 4]), .pa(p_chk_pa[gp*PA_W +: PA_W]),
        .dom(p_chk_dom[gp*DOM_W +: DOM_W]), .dom_v(p_chk_domv[gp]),
        .ent_idx(p_chk_idx[gp*ENT_W +: ENT_W]));

      sf_albion_port #(
        .IOVA_W(IOVA_W), .PA_W(PA_W), .DATA_W(DATA_W), .LEN_W(LEN_W), .TID_W(TID_W),
        .DOM_W(DOM_W), .SID_W(SID_W), .ENT_W(ENT_W)
      ) u_port (
        .clk(clk), .rst_n(rst_n),
        .us_cmd_valid(us_cmd_valid[gp]), .us_cmd_ready(us_cmd_ready[gp]),
        .us_cmd_tid(us_cmd_tid[gp*TID_W +: TID_W]), .us_cmd_sid(us_cmd_sid[gp*SID_W +: SID_W]),
        .us_cmd_we(us_cmd_we[gp]), .us_cmd_addr(us_cmd_addr[gp*IOVA_W +: IOVA_W]),
        .us_cmd_len(us_cmd_len[gp*LEN_W +: LEN_W]),
        .us_w_valid(us_w_valid[gp]), .us_w_ready(us_w_ready[gp]),
        .us_w_data(us_w_data[gp*DATA_W +: DATA_W]), .us_w_strb(us_w_strb[gp*STRB_W +: STRB_W]),
        .us_r_valid(us_r_valid[gp]), .us_r_ready(us_r_ready[gp]),
        .us_r_tid(us_r_tid[gp*TID_W +: TID_W]), .us_r_we(us_r_we[gp]), .us_r_err(us_r_err[gp]),
        .us_r_last(us_r_last[gp]), .us_r_data(us_r_data[gp*DATA_W +: DATA_W]),
        .ds_cmd_valid(ds_cmd_valid[gp]), .ds_cmd_ready(ds_cmd_ready[gp]),
        .ds_cmd_tid(ds_cmd_tid[gp*TID_W +: TID_W]), .ds_cmd_we(ds_cmd_we[gp]),
        .ds_cmd_addr(ds_cmd_addr[gp*PA_W +: PA_W]), .ds_cmd_len(ds_cmd_len[gp*LEN_W +: LEN_W]),
        .ds_w_valid(ds_w_valid[gp]), .ds_w_ready(ds_w_ready[gp]),
        .ds_w_data(ds_w_data[gp*DATA_W +: DATA_W]), .ds_w_strb(ds_w_strb[gp*STRB_W +: STRB_W]),
        .ds_w_last(ds_w_last[gp]),
        .ds_r_valid(ds_r_valid[gp]), .ds_r_ready(ds_r_ready[gp]), .ds_r_err(ds_r_err[gp]),
        .ds_r_data(ds_r_data[gp*DATA_W +: DATA_W]),
        .chk_sid(p_chk_sid[gp*SID_W +: SID_W]), .chk_we(p_chk_we[gp]),
        .chk_addr(p_chk_addr[gp*IOVA_W +: IOVA_W]), .chk_len(p_chk_len[gp*LEN_W +: LEN_W]),
        .chk_grant(p_chk_grant[gp]), .chk_fault(p_chk_fault[gp*4 +: 4]),
        .chk_pa(p_chk_pa[gp*PA_W +: PA_W]), .chk_dom(p_chk_dom[gp*DOM_W +: DOM_W]),
        .chk_domv(p_chk_domv[gp]), .chk_idx(p_chk_idx[gp*ENT_W +: ENT_W]), .chk_blk(blk),
        .act(p_act[gp]), .auth(p_auth[gp]), .auth_dom(p_auth_dom[gp*DOM_W +: DOM_W]),
        .auth_idx(p_auth_idx[gp*ENT_W +: ENT_W]), .auth_sid(p_auth_sid[gp*SID_W +: SID_W]),
        .auth_we(p_auth_we[gp]),
        .flt_req(p_flt_req[gp]), .flt_gnt(p_flt_gnt[gp]), .flt_cause(p_flt_cause[gp*4 +: 4]),
        .flt_we(p_flt_we[gp]), .flt_domv(p_flt_domv[gp]), .flt_dom(p_flt_dom[gp*DOM_W +: DOM_W]),
        .flt_sid(p_flt_sid[gp*SID_W +: SID_W]), .flt_tid(p_flt_tid[gp*TID_W +: TID_W]),
        .flt_len(p_flt_len[gp*LEN_W +: LEN_W]), .flt_addr(p_flt_addr[gp*IOVA_W +: IOVA_W]),
        .ev_grant(p_ev_grant[gp]), .ev_deny(p_ev_deny[gp]));
    end
  endgenerate

  // ===========================================================================
  // Fault-log arbitration (one record per cycle, lowest port first). A denied
  // burst answers its initiator only after its record has been taken, so the
  // log is lossless except for explicit overflow (counted, never blocking).
  // ===========================================================================
  logic                flt_push;
  logic [FQ_REC_W-1:0] flt_rec;
  logic                flt_rec_domv;
  logic [DOM_W-1:0]    flt_rec_dom;
  logic [3:0]          flt_rec_cause;

  always_comb begin
    p_flt_gnt     = '0;
    flt_push      = 1'b0;
    flt_rec       = '0;
    flt_rec_domv  = 1'b0;
    flt_rec_dom   = '0;
    flt_rec_cause = `SF_DG_F_NONE;
    for (int p = 0; p < NUM_PORTS; p++) begin
      if (!flt_push && p_flt_req[p]) begin
        p_flt_gnt[p]  = 1'b1;
        flt_push      = 1'b1;
        flt_rec_domv  = p_flt_domv[p];
        flt_rec_dom   = p_flt_dom[p*DOM_W +: DOM_W];
        flt_rec_cause = p_flt_cause[p*4 +: 4];
        flt_rec[R_CAUSE +: 4]      = p_flt_cause[p*4 +: 4];
        flt_rec[R_WE]              = p_flt_we[p];
        flt_rec[R_DOMV]            = p_flt_domv[p];
        flt_rec[R_DOM  +: DOM_W]   = p_flt_dom[p*DOM_W +: DOM_W];
        flt_rec[R_PORT +: PORT_W]  = PORT_W'(p);
        flt_rec[R_SID  +: SID_W]   = p_flt_sid[p*SID_W +: SID_W];
        flt_rec[R_TID  +: TID_W]   = p_flt_tid[p*TID_W +: TID_W];
        flt_rec[R_LEN  +: LEN_W]   = p_flt_len[p*LEN_W +: LEN_W];
        flt_rec[R_ADDR +: IOVA_W]  = p_flt_addr[p*IOVA_W +: IOVA_W];
      end
    end
  end

  // ===========================================================================
  // Admin CSR: decode
  // ===========================================================================
  logic act_any;
  assign act_any = |p_act;

  logic wr, rd_pub, wr_known, rd_known;
  always_comb begin
    wr = csr_valid && csr_we && csr_priv;
    rd_pub = (csr_addr == A_ID) || (csr_addr == A_CAP0) || (csr_addr == A_CAP1) || (csr_addr == A_CAP2);
    wr_known = 1'b0;
    rd_known = 1'b0;
    case (csr_addr)
      A_ID, A_CAP0, A_CAP1, A_CAP2:                                   rd_known = 1'b1;
      A_CTRL, A_STATUS, A_STG_IPN, A_STG_PPN, A_STG_ATTR, A_STG_CTX,
      A_STG_DOM, A_CMD, A_FQ_POP, A_SEL_DOM, A_DOM_FMASK, A_SEL_ENT,
      A_SEL_PORT:                                                     begin rd_known = 1'b1; wr_known = 1'b1; end
      A_FQ_STATUS, A_FQ_META, A_FQ_IOVA, A_FQ_ID, A_DOM_CFG, A_DOM_FCNT,
      A_ENT_RD0, A_ENT_RD1, A_ENT_RD2, A_CTX_RD, A_PORT_OK, A_PORT_DENY: rd_known = 1'b1;
      default: ;
    endcase
    if (csr_priv)      csr_hit = csr_we ? wr_known : rd_known;
    else               csr_hit = !csr_we && rd_pub;
  end

  // ===========================================================================
  // Admin CSR: command decode (combinational, evaluated against current state)
  // ===========================================================================
  logic        wr_cmd, op_go, op_do, ctrl_wr, ctrl_dis, ctrl_en;
  logic [3:0]  op, cmd_err;
  logic [7:0]  op_idx;
  logic [31:0] s_ipn, s_ppn;
  logic [3:0]  s_ord;
  logic [7:0]  s_dom, c_port, c_sid, c_dom, d_dom_i;
  logic        ent_overlap;
  logic [3:0]  k_ord;
  logic [31:0] k_mask;
  logic [31:0] e_ipn32;
  logic [ENT_W-1:0]  eidx;
  logic [CIW-1:0] cidx;

  always_comb begin
    wr_cmd  = wr && (csr_addr == A_CMD);
    op      = csr_wdata[3:0];
    op_idx  = csr_wdata[15:8];
    op_go   = wr_cmd && !blk;
    s_ipn   = stg_ipn;
    s_ppn   = stg_ppn;
    s_ord   = stg_attr[11:8];
    s_dom   = stg_attr[23:16];
    c_port  = stg_ctx[7:0];
    c_sid   = stg_ctx[15:8];
    c_dom   = stg_ctx[23:16];
    d_dom_i = stg_dom[7:0];
    eidx    = op_idx[ENT_W-1:0];
    cidx    = CIW'(32'(c_port) * NUM_STREAMS + 32'(c_sid));

    // overlap against every valid entry of the same domain: naturally aligned
    // blocks overlap iff one contains the other
    ent_overlap = 1'b0;
    k_ord       = '0;
    k_mask      = '0;
    e_ipn32     = '0;
    for (int e = 0; e < NUM_ENTRIES; e++) begin
      e_ipn32 = 32'(ent_ipn[e*IPN_W +: IPN_W]);
      k_ord   = (4'(ent_ord[e*ORD_W +: ORD_W]) > s_ord) ? 4'(ent_ord[e*ORD_W +: ORD_W]) : s_ord;
      k_mask  = ~(32'hFFFF_FFFF << k_ord);
      if (ent_valid[e] && (8'(ent_dom[e*DOM_W +: DOM_W]) == s_dom) &&
          (((e_ipn32 ^ s_ipn) & ~k_mask) == 32'd0))
        ent_overlap = 1'b1;
    end

    cmd_err = `SF_DG_E_OK;
    case (op)
      `SF_DG_OP_NOP:   ;
      `SF_DG_OP_FENCE: ;
      `SF_DG_OP_ENT_SET: begin
        if (32'(op_idx) >= NUM_ENTRIES)                         cmd_err = `SF_DG_E_IDX;
        else if (32'(s_dom) >= NUM_DOMAINS)                     cmd_err = `SF_DG_E_DOM;
        else if (32'(s_ord) > MAX_ORDER ||
                 (s_ipn & ~IPN_MASK32) != 32'd0 || (s_ppn & ~PPN_MASK32) != 32'd0 ||
                 (s_ipn & ~(32'hFFFF_FFFF << s_ord)) != 32'd0 ||
                 (s_ppn & ~(32'hFFFF_FFFF << s_ord)) != 32'd0)  cmd_err = `SF_DG_E_RANGE;
        else if (ent_valid[eidx])                               cmd_err = `SF_DG_E_BUSY;
        else if (ent_overlap)                                   cmd_err = `SF_DG_E_OVERLAP;
      end
      `SF_DG_OP_ENT_CLR:   if (32'(op_idx) >= NUM_ENTRIES)      cmd_err = `SF_DG_E_IDX;
      `SF_DG_OP_DOM_FLUSH: if (32'(op_idx) >= NUM_DOMAINS)      cmd_err = `SF_DG_E_DOM;
      `SF_DG_OP_CTX_SET: begin
        if (32'(c_port) >= NUM_PORTS || 32'(c_sid) >= NUM_STREAMS) cmd_err = `SF_DG_E_IDX;
        else if (32'(c_dom) >= NUM_DOMAINS)                     cmd_err = `SF_DG_E_DOM;
        else if (ctx_valid[cidx]) cmd_err = `SF_DG_E_BUSY;
      end
      `SF_DG_OP_CTX_CLR:
        if (32'(c_port) >= NUM_PORTS || 32'(c_sid) >= NUM_STREAMS) cmd_err = `SF_DG_E_IDX;
      `SF_DG_OP_DOM_SET:   if (32'(d_dom_i) >= NUM_DOMAINS)     cmd_err = `SF_DG_E_DOM;
      default:                                                 cmd_err = `SF_DG_E_OP;
    endcase

    op_do    = op_go && (cmd_err == `SF_DG_E_OK) && (op != `SF_DG_OP_NOP);
    ctrl_wr  = wr && (csr_addr == A_CTRL);
    ctrl_dis = ctrl_wr && glob_en && !csr_wdata[0];          // disabling is always allowed
    ctrl_en  = ctrl_wr && !glob_en && csr_wdata[0] && !blk;  // enabling only when no drain pending
  end

  // ===========================================================================
  // Sequential state
  // ===========================================================================
  logic fq_pop_ok, fq_push_ok;
  assign fq_pop_ok  = wr && (csr_addr == A_FQ_POP) && (fq_cnt != '0);
  assign fq_push_ok = flt_push && (fq_cnt != FQ_CW'(FQ_DEPTH));

  function automatic logic [CNT_W-1:0] sat_inc(input logic [CNT_W-1:0] v);
    sat_inc = (&v) ? v : (v + 1'b1);
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      glob_en    <= 1'b0;
      irq_en     <= 1'b0;
      dom_en     <= '0;
      dom_rd     <= '0;
      dom_wr     <= '0;
      ctx_valid  <= '0;
      ctx_dom    <= '0;
      ent_valid  <= '0;
      ent_r      <= '0;
      ent_w      <= '0;
      ent_dom    <= '0;
      ent_ipn    <= '0;
      ent_ppn    <= '0;
      ent_ord    <= '0;
      blk        <= 1'b0;
      stg_ipn    <= '0; stg_ppn <= '0; stg_attr <= '0; stg_ctx <= '0; stg_dom <= '0;
      sel_dom    <= '0; sel_ent <= '0; sel_port <= '0;
      admin_viol <= 1'b0;
      fq_ovf     <= 1'b0;
      last_err   <= `SF_DG_E_OK;
      dom_fcnt   <= '0;
      dom_fmask  <= '0;
      port_ok    <= '0;
      port_deny  <= '0;
      fq_wr      <= '0;
      fq_rd      <= '0;
      fq_cnt     <= '0;
      fq_drop    <= '0;
    end else begin
      // ------------------------------------------------------------ sticky clears (set below wins)
      if (wr && csr_addr == A_STATUS) begin
        if (csr_wdata[2]) fq_ovf     <= 1'b0;
        if (csr_wdata[3]) admin_viol <= 1'b0;
      end
      if (wr && csr_addr == A_DOM_FMASK && 32'(sel_dom) < NUM_DOMAINS)
        dom_fmask[sel_dom[DOM_W-1:0]*16 +: 16] <= dom_fmask[sel_dom[DOM_W-1:0]*16 +: 16] & ~csr_wdata[15:0];

      // ------------------------------------------------------------ non-privileged access attempt
      if (csr_valid && !csr_priv && !(!csr_we && rd_pub)) admin_viol <= 1'b1;

      // ------------------------------------------------------------ plain registers
      if (wr) begin
        case (csr_addr)
          A_STG_IPN:  stg_ipn  <= csr_wdata;
          A_STG_PPN:  stg_ppn  <= csr_wdata;
          A_STG_ATTR: stg_attr <= csr_wdata;
          A_STG_CTX:  stg_ctx  <= csr_wdata;
          A_STG_DOM:  stg_dom  <= csr_wdata;
          A_SEL_DOM:  sel_dom  <= csr_wdata;
          A_SEL_ENT:  sel_ent  <= csr_wdata;
          A_SEL_PORT: sel_port <= csr_wdata;
          default: ;
        endcase
      end

      // ------------------------------------------------------------ CTRL
      if (ctrl_wr) begin
        irq_en <= csr_wdata[1];
        if (ctrl_dis)      glob_en <= 1'b0;
        else if (ctrl_en)  glob_en <= 1'b1;
      end

      // ------------------------------------------------------------ CMD (atomic)
      if (wr_cmd) last_err <= blk ? `SF_DG_E_PENDING : cmd_err;
      if (ctrl_wr && csr_wdata[0] && !glob_en && blk) last_err <= `SF_DG_E_PENDING;

      if (op_do) begin
        case (op)
          `SF_DG_OP_ENT_SET: begin
            ent_valid[eidx]                  <= 1'b1;
            ent_dom[eidx*DOM_W +: DOM_W]     <= s_dom[DOM_W-1:0];
            ent_ipn[eidx*IPN_W +: IPN_W]     <= s_ipn[IPN_W-1:0];
            ent_ppn[eidx*PPN_W +: PPN_W]     <= s_ppn[PPN_W-1:0];
            ent_ord[eidx*ORD_W +: ORD_W]     <= s_ord[ORD_W-1:0];
            ent_r[eidx]                      <= stg_attr[0];
            ent_w[eidx]                      <= stg_attr[1];
          end
          `SF_DG_OP_ENT_CLR: ent_valid[eidx] <= 1'b0;
          `SF_DG_OP_DOM_FLUSH: begin
            for (int e = 0; e < NUM_ENTRIES; e++)
              if (8'(ent_dom[e*DOM_W +: DOM_W]) == op_idx) ent_valid[e] <= 1'b0;
          end
          `SF_DG_OP_CTX_SET: begin
            ctx_valid[cidx] <= 1'b1;
            ctx_dom[cidx*DOM_W +: DOM_W] <= c_dom[DOM_W-1:0];
          end
          `SF_DG_OP_CTX_CLR: ctx_valid[cidx] <= 1'b0;
          `SF_DG_OP_DOM_SET: begin
            dom_en[d_dom_i[DOM_W-1:0]] <= stg_dom[8];
            dom_rd[d_dom_i[DOM_W-1:0]] <= stg_dom[9];
            dom_wr[d_dom_i[DOM_W-1:0]] <= stg_dom[10];
          end
          default: ;
        endcase
      end

      // ------------------------------------------------------------ drain barrier
      if (op_do || ctrl_dis) blk <= 1'b1;
      else if (blk && !act_any) blk <= 1'b0;

      // ------------------------------------------------------------ fault log
      if (fq_push_ok) begin
        fq_mem[fq_wr] <= flt_rec;
        fq_wr         <= (fq_wr == FQ_PW'(FQ_DEPTH - 1)) ? '0 : fq_wr + 1'b1;
      end
      if (fq_pop_ok)
        fq_rd <= (fq_rd == FQ_PW'(FQ_DEPTH - 1)) ? '0 : fq_rd + 1'b1;
      fq_cnt <= fq_cnt + FQ_CW'(fq_push_ok) - FQ_CW'(fq_pop_ok);
      if (flt_push && !fq_push_ok) begin
        fq_ovf  <= 1'b1;
        fq_drop <= sat_inc(fq_drop);
      end

      // ------------------------------------------------------------ statistics
      if (flt_push && flt_rec_domv) begin
        for (int d = 0; d < NUM_DOMAINS; d++)
          if (flt_rec_dom == DOM_W'(d)) begin
            dom_fcnt[d*CNT_W +: CNT_W] <= sat_inc(dom_fcnt[d*CNT_W +: CNT_W]);
            dom_fmask[d*16 + 32'(flt_rec_cause[3:0])] <= 1'b1;
          end
      end
      for (int p = 0; p < NUM_PORTS; p++) begin
        if (p_ev_grant[p]) port_ok[p*CNT_W +: CNT_W]   <= sat_inc(port_ok[p*CNT_W +: CNT_W]);
        if (p_ev_deny[p])  port_deny[p*CNT_W +: CNT_W] <= sat_inc(port_deny[p*CNT_W +: CNT_W]);
      end
    end
  end

  assign irq = irq_en && (fq_cnt != '0);

  // ===========================================================================
  // Admin CSR: read mux (combinational; privileged except ID/CAP)
  // ===========================================================================
  logic [FQ_REC_W-1:0] fq_head;
  assign fq_head = (fq_cnt != '0) ? fq_mem[fq_rd] : '0;

  logic [31:0] ctx_rd;
  logic [31:0] ent_rd0, ent_rd1, ent_rd2;
  logic [31:0] dom_cfg, dom_fcnt_rd, dom_fmask_rd, port_ok_rd, port_deny_rd;
  logic [CIW-1:0] ctx_rd_idx;

  always_comb begin
    ctx_rd = 32'd0; ent_rd0 = 32'd0; ent_rd1 = 32'd0; ent_rd2 = 32'd0;
    dom_cfg = 32'd0; dom_fcnt_rd = 32'd0; dom_fmask_rd = 32'd0;
    port_ok_rd = 32'd0; port_deny_rd = 32'd0;
    ctx_rd_idx = CIW'(32'(stg_ctx[7:0]) * NUM_STREAMS + 32'(stg_ctx[15:8]));

    if (32'(stg_ctx[7:0]) < NUM_PORTS && 32'(stg_ctx[15:8]) < NUM_STREAMS) begin
      ctx_rd[0]     = ctx_valid[ctx_rd_idx];
      ctx_rd[23:16] = 8'(ctx_dom[ctx_rd_idx*DOM_W +: DOM_W]);
    end
    if (sel_ent < NUM_ENTRIES) begin
      ent_rd0[0]     = ent_valid[sel_ent[ENT_W-1:0]];
      ent_rd0[1]     = ent_r[sel_ent[ENT_W-1:0]];
      ent_rd0[2]     = ent_w[sel_ent[ENT_W-1:0]];
      ent_rd0[11:8]  = 4'(ent_ord[sel_ent[ENT_W-1:0]*ORD_W +: ORD_W]);
      ent_rd0[23:16] = 8'(ent_dom[sel_ent[ENT_W-1:0]*DOM_W +: DOM_W]);
      ent_rd1        = 32'(ent_ipn[sel_ent[ENT_W-1:0]*IPN_W +: IPN_W]);
      ent_rd2        = 32'(ent_ppn[sel_ent[ENT_W-1:0]*PPN_W +: PPN_W]);
    end
    if (sel_dom < NUM_DOMAINS) begin
      dom_cfg      = {29'd0, dom_wr[sel_dom[DOM_W-1:0]], dom_rd[sel_dom[DOM_W-1:0]], dom_en[sel_dom[DOM_W-1:0]]};
      dom_fcnt_rd  = 32'(dom_fcnt[sel_dom[DOM_W-1:0]*CNT_W +: CNT_W]);
      dom_fmask_rd = 32'(dom_fmask[sel_dom[DOM_W-1:0]*16 +: 16]);
    end
    if (sel_port < NUM_PORTS) begin
      port_ok_rd   = 32'(port_ok[sel_port[PORT_W-1:0]*CNT_W +: CNT_W]);
      port_deny_rd = 32'(port_deny[sel_port[PORT_W-1:0]*CNT_W +: CNT_W]);
    end
  end

  always_comb begin
    csr_rdata = 32'd0;
    if (csr_hit && !csr_we) begin
      case (csr_addr)
        A_ID:        csr_rdata = ID_VALUE;
        A_CAP0:      csr_rdata = {8'(NUM_STREAMS), 8'(NUM_ENTRIES), 8'(NUM_DOMAINS), 8'(NUM_PORTS)};
        A_CAP1:      csr_rdata = {8'(MAX_ORDER), 8'(DATA_W), 8'(PA_W), 8'(IOVA_W)};
        A_CAP2:      csr_rdata = {8'(CNT_W), 8'(TID_W), 8'(LEN_W), 8'(FQ_DEPTH)};
        A_CTRL:      csr_rdata = {30'd0, irq_en, glob_en};
        A_STATUS:    csr_rdata = {20'd0, last_err, 4'd0, admin_viol, fq_ovf, (fq_cnt != '0), blk};
        A_STG_IPN:   csr_rdata = stg_ipn;
        A_STG_PPN:   csr_rdata = stg_ppn;
        A_STG_ATTR:  csr_rdata = stg_attr;
        A_STG_CTX:   csr_rdata = stg_ctx;
        A_STG_DOM:   csr_rdata = stg_dom;
        A_CMD:       csr_rdata = 32'd0;
        A_FQ_STATUS: csr_rdata = {16'(fq_drop), 8'd0, 8'(fq_cnt)};
        A_FQ_META:   csr_rdata = {4'd0, 4'(fq_head[R_SID +: SID_W]), 8'(fq_head[R_PORT +: PORT_W]),
                                  8'(fq_head[R_DOM +: DOM_W]), 2'd0, fq_head[R_DOMV], fq_head[R_WE],
                                  fq_head[R_CAUSE +: 4]};
        A_FQ_IOVA:   csr_rdata = 32'(fq_head[R_ADDR +: IOVA_W]);
        A_FQ_ID:     csr_rdata = {16'd0, 8'(fq_head[R_LEN +: LEN_W]), 8'(fq_head[R_TID +: TID_W])};
        A_FQ_POP:    csr_rdata = 32'd0;
        A_SEL_DOM:   csr_rdata = sel_dom;
        A_DOM_CFG:   csr_rdata = dom_cfg;
        A_DOM_FCNT:  csr_rdata = dom_fcnt_rd;
        A_DOM_FMASK: csr_rdata = dom_fmask_rd;
        A_SEL_ENT:   csr_rdata = sel_ent;
        A_ENT_RD0:   csr_rdata = ent_rd0;
        A_ENT_RD1:   csr_rdata = ent_rd1;
        A_ENT_RD2:   csr_rdata = ent_rd2;
        A_CTX_RD:    csr_rdata = ctx_rd;
        A_SEL_PORT:  csr_rdata = sel_port;
        A_PORT_OK:   csr_rdata = port_ok_rd;
        A_PORT_DENY: csr_rdata = port_deny_rd;
        default:     csr_rdata = 32'd0;
      endcase
    end
  end

`ifdef SF_DG_FORMAL
  `include "sf_albion_formal.svh"
`endif
endmodule
