// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_pnr_wrap      (place-and-route measurement wrapper)
// NOT part of the operand buffer.  The buffer has ~1500 port bits - more than
// any FPGA package has pins - so for a real place & route (nextpnr) every
// input is driven from its own flip-flop of a shift register fed by an LFSR
// (distinct flops: synthesis cannot merge or constant-fold any input), and
// every output is registered and XOR-folded onto OBS_W pins.  All buffer logic
// therefore stays observable, and every buffer input/output path is timed
// register to register.  The XOR fold is a balanced tree with a register after
// every 4-input level, so no wrapper path is longer than one LUT and the
// wrapper never limits Fmax.  Wrapper cost: IW + OW flip-flops, a 32-bit LFSR,
// about OW/3 XOR LUTs and flip-flops in the fold.
// Classification: SYNTHESIZABLE (measurement harness only)
// =============================================================================
`include "tob_defs.svh"
`default_nettype none

module tob_pnr_wrap #(
  parameter int ARRAY_ROWS = 4, parameter int ARRAY_COLS = 4, parameter int WORD_BYTES = 4,
  parameter int A_SET_BYTES = 4096, parameter int B_SET_BYTES = 4096, parameter int A_BANKS = 4, parameter int B_BANKS = 2,
  parameter int A_REPL = 1, parameter int NUM_SETS = 2, parameter int SET_MAP = 0, parameter int PORT_MODE = 1,
  parameter int READ_LATENCY = 1, parameter int A_STAGE = 2, parameter int B_STAGE = 4, parameter int PERF_EN = 1,
  parameter int BACKEND = 1,
  localparam int OBS_W = 16
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             seed_in,
  output logic      [OBS_W-1:0] obs
);
  localparam int R = ARRAY_ROWS, C = ARRAY_COLS, WB = WORD_BYTES, DW = 8 * WB, AW = 32, IX = 16, KW = 17, TW = 8;
  localparam int SW = (NUM_SETS > 1) ? 1 : 1, RMW = $clog2(R + 1), CNW = $clog2(C + 1), NEV = `TOB_NUM_EV;
  localparam int GRP = (SET_MAP == 1 && NUM_SETS == 2) ? 2 : 1, NPA = GRP * A_REPL * A_BANKS;
  // input bits: dma req (valid, we, addr, data, strb, tag) + rsp_ready + 4 ctl valids + tile (valid, 4 addr, 4 idx, 3 k, tag)
  //             + tile_rsp_ready + s_ready + perf_clear
  localparam int IW = (2 + AW + DW + WB + TW) + 1 + 4 + (1 + 4 * AW + 4 * IX + 3 * KW + TW) + 3;
  localparam int O_DMA_REQ_READY = 0;
  localparam int O_DMA_RSP_VALID = O_DMA_REQ_READY + 1;
  localparam int O_DMA_RSP_RDATA = O_DMA_RSP_VALID + 1;
  localparam int O_DMA_RSP_ERR = O_DMA_RSP_RDATA + DW;
  localparam int O_DMA_RSP_ERR_CODE = O_DMA_RSP_ERR + 1;
  localparam int O_DMA_RSP_WE = O_DMA_RSP_ERR_CODE + 3;
  localparam int O_DMA_RSP_TAG = O_DMA_RSP_WE + 1;
  localparam int O_FILL_BEGIN_READY = O_DMA_RSP_TAG + TW;
  localparam int O_FILL_END_READY = O_FILL_BEGIN_READY + 1;
  localparam int O_CMP_BEGIN_READY = O_FILL_END_READY + 1;
  localparam int O_CMP_END_READY = O_CMP_BEGIN_READY + 1;
  localparam int O_FILL_SET = O_CMP_END_READY + 1;
  localparam int O_CMP_SET = O_FILL_SET + SW;
  localparam int O_SET_STATE = O_CMP_SET + SW;
  localparam int O_TILE_READY = O_SET_STATE + NUM_SETS*2;
  localparam int O_TILE_RSP_VALID = O_TILE_READY + 1;
  localparam int O_TILE_RSP_TAG = O_TILE_RSP_VALID + 1;
  localparam int O_TILE_RSP_ERR = O_TILE_RSP_TAG + TW;
  localparam int O_TILE_RSP_CODE = O_TILE_RSP_ERR + 1;
  localparam int O_TILE_RSP_M = O_TILE_RSP_CODE + 4;
  localparam int O_TILE_RSP_N = O_TILE_RSP_M + RMW;
  localparam int O_TILE_RSP_K = O_TILE_RSP_N + CNW;
  localparam int O_S_VALID = O_TILE_RSP_K + KW;
  localparam int O_S_A = O_S_VALID + 1;
  localparam int O_S_B = O_S_A + R*8;
  localparam int O_S_K = O_S_B + C*8;
  localparam int O_S_KG = O_S_K + KW;
  localparam int O_S_M0 = O_S_KG + KW;
  localparam int O_S_N0 = O_S_M0 + IX;
  localparam int O_S_ROW_MASK = O_S_N0 + IX;
  localparam int O_S_COL_MASK = O_S_ROW_MASK + R;
  localparam int O_S_FIRST = O_S_COL_MASK + C;
  localparam int O_S_LAST = O_S_FIRST + 1;
  localparam int O_S_TAG = O_S_LAST + 1;
  localparam int O_S_SET = O_S_TAG + TW;
  localparam int O_BUSY = O_S_SET + SW;
  localparam int O_ENGINE_IDLE = O_BUSY + 1;
  localparam int O_EV_INC = O_ENGINE_IDLE + 1;
  localparam int O_EV_BANK_CONFLICT_A = O_EV_INC + NEV*8;
  localparam int O_PERF_CNT = O_EV_BANK_CONFLICT_A + NPA;
  localparam int OW = O_PERF_CNT + NEV*32;

  logic [31:0]   lfsr;
  logic [IW-1:0] iv;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) lfsr <= 32'h1;
    else        lfsr <= {lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0] ^ seed_in};
  end
  always_ff @(posedge clk) iv <= {iv[IW-2:0], lfsr[31]};

  logic [OW-1:0] ov;
  tensor_operand_buffer #(
    .ARRAY_ROWS(R), .ARRAY_COLS(C), .WORD_BYTES(WB), .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES),
    .A_BANKS(A_BANKS), .B_BANKS(B_BANKS), .A_REPL(A_REPL), .NUM_SETS(NUM_SETS), .SET_MAP(SET_MAP), .PORT_MODE(PORT_MODE),
    .READ_LATENCY(READ_LATENCY), .A_STAGE(A_STAGE), .B_STAGE(B_STAGE), .ADDR_W(AW), .IDX_W(IX), .K_W(KW), .TAG_W(TW),
    .BACKEND(BACKEND), .PERF_EN(PERF_EN)
  ) u_tob (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(iv[0]), .dma_req_we(iv[1]), .dma_req_addr(iv[2 +: AW]), .dma_req_wdata(iv[2+AW +: DW]),
    .dma_req_wstrb(iv[2+AW+DW +: WB]), .dma_req_tag(iv[2+AW+DW+WB +: TW]),
    .dma_rsp_ready(iv[2+AW+DW+WB+TW]),
    .fill_begin_valid(iv[3+AW+DW+WB+TW]), .fill_end_valid(iv[4+AW+DW+WB+TW]),
    .cmp_begin_valid(iv[5+AW+DW+WB+TW]), .cmp_end_valid(iv[6+AW+DW+WB+TW]),
    .tile_valid(iv[7+AW+DW+WB+TW]),
    .tile_a_addr(iv[8+AW+DW+WB+TW +: AW]), .tile_lda(iv[8+2*AW+DW+WB+TW +: AW]),
    .tile_b_addr(iv[8+3*AW+DW+WB+TW +: AW]), .tile_ldb(iv[8+4*AW+DW+WB+TW +: AW]),
    .tile_m0(iv[8+5*AW+DW+WB+TW +: IX]), .tile_n0(iv[8+5*AW+DW+WB+TW+IX +: IX]),
    .tile_mat_m(iv[8+5*AW+DW+WB+TW+2*IX +: IX]), .tile_mat_n(iv[8+5*AW+DW+WB+TW+3*IX +: IX]),
    .tile_k0(iv[8+5*AW+DW+WB+TW+4*IX +: KW]), .tile_mat_k(iv[8+5*AW+DW+WB+TW+4*IX+KW +: KW]),
    .tile_k(iv[8+5*AW+DW+WB+TW+4*IX+2*KW +: KW]), .tile_tag(iv[8+5*AW+DW+WB+TW+4*IX+3*KW +: TW]),
    .tile_rsp_ready(iv[IW-3]), .s_ready(iv[IW-2]), .perf_clear(iv[IW-1]),
    .dma_req_ready(ov[O_DMA_REQ_READY +: 1]),
    .dma_rsp_valid(ov[O_DMA_RSP_VALID +: 1]),
    .dma_rsp_rdata(ov[O_DMA_RSP_RDATA +: DW]),
    .dma_rsp_err(ov[O_DMA_RSP_ERR +: 1]),
    .dma_rsp_err_code(ov[O_DMA_RSP_ERR_CODE +: 3]),
    .dma_rsp_we(ov[O_DMA_RSP_WE +: 1]),
    .dma_rsp_tag(ov[O_DMA_RSP_TAG +: TW]),
    .fill_begin_ready(ov[O_FILL_BEGIN_READY +: 1]),
    .fill_end_ready(ov[O_FILL_END_READY +: 1]),
    .cmp_begin_ready(ov[O_CMP_BEGIN_READY +: 1]),
    .cmp_end_ready(ov[O_CMP_END_READY +: 1]),
    .fill_set(ov[O_FILL_SET +: SW]),
    .cmp_set(ov[O_CMP_SET +: SW]),
    .set_state(ov[O_SET_STATE +: NUM_SETS*2]),
    .tile_ready(ov[O_TILE_READY +: 1]),
    .tile_rsp_valid(ov[O_TILE_RSP_VALID +: 1]),
    .tile_rsp_tag(ov[O_TILE_RSP_TAG +: TW]),
    .tile_rsp_err(ov[O_TILE_RSP_ERR +: 1]),
    .tile_rsp_code(ov[O_TILE_RSP_CODE +: 4]),
    .tile_rsp_m(ov[O_TILE_RSP_M +: RMW]),
    .tile_rsp_n(ov[O_TILE_RSP_N +: CNW]),
    .tile_rsp_k(ov[O_TILE_RSP_K +: KW]),
    .s_valid(ov[O_S_VALID +: 1]),
    .s_a(ov[O_S_A +: R*8]),
    .s_b(ov[O_S_B +: C*8]),
    .s_k(ov[O_S_K +: KW]),
    .s_kg(ov[O_S_KG +: KW]),
    .s_m0(ov[O_S_M0 +: IX]),
    .s_n0(ov[O_S_N0 +: IX]),
    .s_row_mask(ov[O_S_ROW_MASK +: R]),
    .s_col_mask(ov[O_S_COL_MASK +: C]),
    .s_first(ov[O_S_FIRST +: 1]),
    .s_last(ov[O_S_LAST +: 1]),
    .s_tag(ov[O_S_TAG +: TW]),
    .s_set(ov[O_S_SET +: SW]),
    .busy(ov[O_BUSY +: 1]),
    .engine_idle(ov[O_ENGINE_IDLE +: 1]),
    .ev_inc(ov[O_EV_INC +: NEV*8]),
    .ev_bank_conflict_a(ov[O_EV_BANK_CONFLICT_A +: NPA]),
    .perf_cnt(ov[O_PERF_CNT +: NEV*32])
  );

  // every output registered, then folded onto the observation pins by a registered 4:1 XOR tree
  localparam int L1 = (OW + 3) / 4, L2 = (L1 + 3) / 4, L3 = (L2 + 3) / 4, L4 = (L3 + 3) / 4;
  logic [OW-1:0]   oq;
  logic [4*L1-1:0] p0;
  logic [L1-1:0]   x1;
  logic [4*L2-1:0] p1;
  logic [L2-1:0]   x2;
  logic [4*L3-1:0] p2;
  logic [L3-1:0]   x3;
  logic [4*L4-1:0] p3;
  logic [L4-1:0]   x4;
  assign p0 = (4*L1)'(oq);
  assign p1 = (4*L2)'(x1);
  assign p2 = (4*L3)'(x2);
  assign p3 = (4*L4)'(x3);
  always_ff @(posedge clk) begin
    oq <= ov;
    for (int i = 0; i < L1; i++) x1[i] <= ^p0[4*i +: 4];
    for (int i = 0; i < L2; i++) x2[i] <= ^p1[4*i +: 4];
    for (int i = 0; i < L3; i++) x3[i] <= ^p2[4*i +: 4];
    for (int i = 0; i < L4; i++) x4[i] <= ^p3[4*i +: 4];
  end
  if (L4 > OBS_W) begin : g_err_obs
    `SRAM_CFG_FATAL("tob_pnr_wrap: too many outputs for the observation pins")
  end
  assign obs = OBS_W'(x4);

endmodule

`default_nettype wire
