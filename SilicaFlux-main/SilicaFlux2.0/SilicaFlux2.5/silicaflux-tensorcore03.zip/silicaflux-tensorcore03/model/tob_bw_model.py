#!/usr/bin/env python3
"""Analytical operand-bandwidth model of tensor_operand_buffer (docs/03_bandwidth_analysis.md).

Demand of an R x C output-stationary array at one k-slice per cycle:
    A: R INT8 operands per cycle (one per array row; A[m0+i][k0+k] for i < R)
    B: C INT8 operands per cycle (one per array column; B[k0+k][n0+j] for j < C)
Supply: every physical bank port delivers ONE word of WB bytes per cycle (1RW: one read OR one write; 1R1W: one
read AND one write).  Nothing else is assumed.

A path (row-major A, lane i streams the bytes A[m0+i][k0 ...] of ONE matrix row):
    * a word serves WB consecutive k-steps of its lane, so the average demand is R / WB words per cycle;
    * all lanes consume one byte per slice in lock-step, so lanes with the same byte phase (start address mod WB)
      need their next word by the same cycle.  L = the largest number of lanes with the same (replica, bank,
      phase) in one round: their L requests meet in one bank and are served one per cycle;
    * deadline (latency) coverage - the credit loop is registered, a word retired at edge P is re-requested in
      cycle P+1, granted after at most L-1 waits, written RL cycles later and needed WB*(A_STAGE-1) cycles later:
          (L - 1) + RL + 1 <= (A_STAGE - 1) * WB       (else bubbles at every round)
    * long-run limit - a lane's consecutive words rotate through all A_BANKS banks, so a bank shared by L lanes is
      visited once every A_BANKS rounds of WB cycles:   L <= WB * A_BANKS   (else rate <= WB * A_BANKS / L)
    * L depends on the word stride s = lda / WB and the banks: lanes i, j share a bank when (i - j) * s = 0 mod
      A_BANKS; replication divides the lanes per bank by A_REPL (lane i reads replica i mod A_REPL);
    * transients: at a tile start lanes are at different word indices; the arbiter serves URGENT requests (a lane
      holding at most its head word) first, which keeps the start-up within the same bound (doc 04).
B path (row k of the tile = C contiguous bytes at b + (k0+k)*ldb + n0):
    * nw = ceil((off + C) / WB) words (off = byte offset in the first word), in consecutive = distinct banks;
    * beats per row = ceil(nw / B_BANKS); rate <= 1 / beats;
    * latency loop: one row per cycle needs B_STAGE >= RL + 2 staged/in-flight rows.
DMA (one WB-byte write per cycle at most):
    * 1R1W banks: the write port is never used by reads -> fill at full rate concurrently with compute;
    * 1RW banks, SHARED sets: each write takes a port cycle from a bank the reads may need; a write waits at most
      WR_STARVE_LIMIT cycles, so it costs the reads at most 1 cycle per WR_STARVE_LIMIT + 1 on that bank;
    * 1RW banks, SPLIT sets: fill and compute use different physical banks -> no contention.
"""
from __future__ import annotations

import json
import math
import sys
from math import gcd


def lanes_per_bank(R: int, WB: int, NB: int, REPL: int, lda: int, a0: int = 0) -> int:
    """Largest number of A lanes that request the same physical bank in one round (steady state)."""
    worst = 0
    for q in range(4):                              # a few rounds (the pattern repeats with period NB)
        hits: dict = {}
        for i in range(R):
            s = a0 + i * lda
            key = (i % REPL, (s // WB + q) % NB, s % WB)   # same replica, same bank, same byte phase
            hits[key] = hits.get(key, 0) + 1
        worst = max(worst, max(hits.values()))
    return worst


def b_words(C: int, WB: int, off: int) -> int:
    return (off + C - 1) // WB + 1


def predict(cfg: dict, lda: int, ldb: int, a0: int = 0, b0: int = 0, K: int = 256) -> dict:
    R, C, WB = cfg.get("R", 4), cfg.get("C", 4), cfg.get("WB", 4)
    NBA, NBB, REPL = cfg.get("NBA", 4), cfg.get("NBB", 2), cfg.get("REPL", 1)
    RL, AST, BST = cfg.get("RL", 1), cfg.get("AST", 2), cfg.get("BST", 4)
    L = lanes_per_bank(R, WB, NBA, REPL, lda, a0)
    a_long = min(1.0, WB * NBA / L)
    a_cover = (L - 1) + RL + 1 <= (AST - 1) * WB
    # worst B row over the tile (offsets change with k when ldb is not a multiple of WB)
    nw_max = max(b_words(C, WB, (b0 + k * ldb) % WB) for k in range(min(K, 4 * WB)))
    beats = math.ceil(nw_max / NBB)
    b_rate = 1.0 / beats
    b_cover = BST >= RL + 2
    rate = min(a_long, b_rate)
    full = rate >= 1.0 and a_cover and b_cover
    return {"lanes_per_bank": L, "a_long_run": a_long, "a_latency_covered": a_cover, "b_words_max": nw_max,
            "b_beats": beats, "b_rate": b_rate, "b_latency_covered": b_cover, "predicted_rate_upper": rate,
            "predicted_full_rate": full,
            "a_words_per_cycle": R / WB, "b_words_per_cycle_aligned": math.ceil(C / WB),
            "a_bank_utilisation": (R / WB) / (NBA * REPL) if rate >= 1 else None}


def bram_estimate(cfg: dict) -> dict:
    """Ideal FPGA block-RAM count (inference with exact geometry; actual counts come from Yosys)."""
    WB, NS = cfg.get("WB", 4), cfg.get("NS", 2)
    ASB, BSB = cfg.get("ASB", 4096), cfg.get("BSB", 4096)
    NBA, NBB, REPL = cfg.get("NBA", 4), cfg.get("NBB", 2), cfg.get("REPL", 1)
    split = cfg.get("SMAP", 0) == 1 and NS == 2
    grp = 2 if split else 1
    out = {}
    for name, sb, nb, rep in [("A", ASB, NBA, REPL), ("B", BSB, NBB, 1)]:
        depth = (sb // WB // nb) * (1 if split else NS)
        banks = grp * nb * rep
        bits = banks * depth * WB * 8
        # Xilinx 7-series RAMB18E1 in simple-dual-port mode: 512 x 36 (32 data bits used)
        ramb18 = banks * math.ceil(depth / 512) * math.ceil(WB * 8 / 32) if WB * 8 >= 32 else banks * math.ceil(depth / (1024 if WB == 2 else 2048))
        out[name] = {"physical_banks": banks, "depth": depth, "stored_bits": bits, "ramb18_ideal": ramb18}
    out["total_bits"] = out["A"]["stored_bits"] + out["B"]["stored_bits"]
    return out


if __name__ == "__main__":
    cfg = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    lda = int(sys.argv[2]) if len(sys.argv) > 2 else 36
    ldb = int(sys.argv[3]) if len(sys.argv) > 3 else 4
    print(json.dumps({"predict": predict(cfg, lda, ldb), "bram": bram_estimate(cfg)}, indent=2))
