#!/usr/bin/env python3
"""Operand-bandwidth measurement sweep (RTL simulation, cycle accurate) versus the analytical model.

Each point: tb_tensor_operand_buffer +test=bw - one buffer configuration, one explicit matrix layout (lda, ldb,
A/B byte bases), `tiles` back-to-back full R x C tiles of K k-slices, s_ready = 1 (the array never stalls), optionally
a concurrent DMA fill of the other set (conc=1).  Measured (from the DUT event counters and the slice checker):
  in_tile_rate  = slices / (slices + bubbles inside tiles)     operand supply rate while a tile streams (1.0 = R + C
                                                                operands every cycle)
  overall_rate  = slices / cycles                               including per-tile setup / drain gaps
  starve, starve_a, starve_b, conflicts, rd_wr_block, wr_stall, overlap (cycles with a DMA write and a slice)
Prediction: model/tob_bw_model.py (bank-port limit and latency coverage).  Results: reports/perf.{json,md}.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from common import REPORTS, RTL_FILES, TB, cfg_label, full_cfg, parse_result, provenance, run, verilator_build, write_json  # noqa: E402
from tob_bw_model import predict  # noqa: E402

BASE = dict(R=4, C=4, WB=4, NBA=4, NBB=2, RL=1, AST=2, BST=4, NS=2, PMODE=1)
K = 256
# (group, cfg overrides, lda, ldb, abase, bbase, conc)
P = []
# A: layouts on the baseline (lda in bytes; word stride s = lda / 4; 4 banks)
for lda, note in [(260, "s=65 (odd, conflict-free)"), (268, "s=67 (=3 mod 4)"), (264, "s=66 (=2 mod 4)"), (256, "dense K=256: s=64 (=0 mod 4)"), (257, "unaligned rows")]:
    P.append(("A layout", {}, lda, 4, 0, 0, 0, note))
# B: alignment and B banks
for ldb, nbb, bb, note in [(4, 2, 0, "aligned rows, 2 banks"), (4, 2, 1, "every row straddles 2 words"), (5, 2, 0, "mixed offsets"),
                           (4, 1, 0, "aligned, 1 bank"), (4, 1, 1, "straddling, 1 bank (2 beats)"), (5, 1, 0, "mixed, 1 bank")]:
    P.append(("B layout", dict(NBB=nbb), 260, ldb, 0, bb, 0, note))
# staging depth and read latency against the worst A layout (all lanes in one bank)
for rl in (1, 2, 3, 4):
    for ast in (2, 4):
        P.append(("staging/latency", dict(RL=rl, AST=ast, BST=8), 256, 4, 0, 0, 0, f"all lanes one bank, RL={rl}, A_STAGE={ast}"))
for rl in (1, 2, 3, 4):
    P.append(("staging/latency", dict(RL=rl, AST=2, BST=4 if rl < 3 else 8), 260, 4, 0, 0, 0, f"conflict-free, RL={rl}"))
# replication and bank count on the worst layout
for repl in (1, 2, 4):
    P.append(("replication", dict(REPL=repl), 256, 4, 0, 0, 0, f"A_REPL={repl}, all lanes one bank"))
for nba in (1, 2, 4, 8):
    P.append(("A banks", dict(NBA=nba), 260, 4, 0, 0, 0, f"{nba} A banks, s=65"))
# larger arrays
P += [("array size", dict(R=8, C=8, NBA=8, NBB=4), 260, 8, 0, 0, 0, "8x8, 32-bit words, s=65"),
      ("array size", dict(R=8, C=8, NBA=8, NBB=4), 256, 8, 0, 0, 0, "8x8, 32-bit words, s=64"),
      ("array size", dict(R=8, C=8, NBA=8, NBB=4, AST=4), 256, 8, 0, 0, 0, "8x8, s=64, A_STAGE=4"),
      ("array size", dict(R=8, C=8, WB=8, NBA=4, NBB=2), 264, 8, 0, 0, 0, "8x8, 64-bit words, s=33"),
      ("array size", dict(R=16, C=16, NBA=16, NBB=8, ASB=16384, BSB=16384, AST=4, BST=4), 260, 16, 0, 0, 0, "16x16, 32-bit words, s=65"),
      ("array size", dict(R=16, C=16, WB=8, NBA=8, NBB=4, ASB=16384, BSB=16384), 264, 16, 0, 0, 0, "16x16, 64-bit words, s=33"),
      ("array size", dict(R=16, C=16, WB=16, NBA=4, NBB=2, ASB=16384, BSB=16384), 272, 16, 0, 0, 0, "16x16, 128-bit words, s=17")]
# held-out validation: added after the model correction, predicted before being simulated
P += [("held-out", dict(R=8, C=8, NBA=8, NBB=4), 264, 8, 0, 0, 0, "8x8, s=66: 2 lanes per bank"),
      ("held-out", dict(R=8, C=8, NBA=4, NBB=4), 260, 8, 0, 0, 0, "8x8, 4 A banks, s=65: 2 lanes per bank"),
      ("held-out", dict(R=16, C=16, NBA=16, NBB=8, ASB=16384, BSB=16384, AST=4, BST=4), 256, 16, 0, 0, 0, "16x16, s=64: 16 lanes one bank, A_STAGE=4"),
      ("held-out", dict(R=16, C=16, NBA=16, NBB=8, ASB=16384, BSB=16384, AST=8, BST=4), 256, 16, 0, 0, 0, "16x16, s=64: 16 lanes one bank, A_STAGE=8"),
      ("held-out", dict(NBA=2, RL=2, AST=2, BST=4), 256, 4, 0, 0, 0, "2 A banks, s=64, RL=2"),
      ("held-out", dict(WB=2, NBA=4, NBB=4), 260, 4, 0, 0, 0, "16-bit words, s=130, A_STAGE=2"),
      ("held-out", dict(WB=2, NBA=4, NBB=4, AST=4), 260, 4, 0, 0, 0, "16-bit words, s=130, A_STAGE=4")]
# DMA fill of the other set concurrently with compute
for pm, smap, wsl, note in [(1, 0, 8, "1R1W shared"), (0, 0, 8, "1RW shared, limit 8"), (0, 0, 2, "1RW shared, limit 2"),
                            (0, 0, 0, "1RW shared, write priority"), (0, 1, 8, "1RW split")]:
    P.append(("DMA overlap", dict(PMODE=pm, SMAP=smap, WSL=wsl), 260, 4, 0, 1, 1, note))


def job(pt) -> dict:
    grp, ov, lda, ldb, ab, bb, conc, note = pt
    cfg = dict(BASE, **ov)
    exe, blog = verilator_build("tb_tensor_operand_buffer", [*RTL_FILES, TB / "tb_tensor_operand_buffer.sv"], cfg, "main")
    if exe is None:
        return {"group": grp, "note": note, "result": "BUILD-FAIL", "log": blog[-800:]}
    args = [f"+test=bw", f"+K={K}", "+tiles=8", f"+lda={lda}", f"+ldb={ldb}", f"+abase={ab}", f"+bbase={bb}", f"+conc={conc}", "+seed=1"]
    rc, out, dt = run([exe, *args], cwd=exe.parent.parent, timeout=1800)
    m = re.search(r"^PERF cfg (.*)$", out, re.M)
    meas = dict(kv.split("=") for kv in m.group(1).split()) if m else {}
    meas = {k: int(v) for k, v in meas.items()}
    res = {"group": grp, "note": note, "label": cfg_label(cfg), "cfg": cfg, "lda": lda, "ldb": ldb, "abase": ab, "bbase": bb,
           "conc": conc, "result": parse_result(out), "measured": meas,
           "model": predict(full_cfg(cfg) | {"RL": cfg["RL"]}, lda, ldb, ab, bb, K)}
    if meas and meas.get("slices", 0) == 0:
        res["result"] = "FAIL (no slice delivered: " + "; ".join(l for l in out.splitlines() if l.startswith("ERROR"))[:300] + ")"
        meas = {}
        res["measured"] = {}
    if meas:
        s, bub, cyc = meas["slices"], meas["bubbles_in_tiles"], meas["cycles"]
        res["in_tile_rate"] = round(s / (s + bub), 4)
        res["overall_rate"] = round(s / cyc, 4)
        res["operands_per_cycle_in_tile"] = round(res["in_tile_rate"] * (cfg["R"] + cfg["C"]), 2)
    return res


LAT = [dict(), dict(RL=2, AST=4, BST=4), dict(RL=4, AST=4, BST=8), dict(PMODE=0), dict(R=8, C=8, NBA=8, NBB=4),
       dict(R=16, C=16, NBA=16, NBB=8, ASB=16384, BSB=16384, AST=4, BST=4)]


def lat_job(ov: dict) -> dict:
    cfg = dict(BASE, **ov)
    exe, blog = verilator_build("tb_tensor_operand_buffer", [*RTL_FILES, TB / "tb_tensor_operand_buffer.sv"], cfg, "main")
    if exe is None:
        return {"label": cfg_label(cfg), "result": "BUILD-FAIL"}
    rc, out, dt = run([exe, "+test=latency", "+seed=1"], cwd=exe.parent.parent, timeout=900)
    m = re.search(r"^LATENCY (.*)$", out, re.M)
    meas = {k: int(v) for k, v in (kv.split("=") for kv in m.group(1).split())} if m else {}
    return {"label": cfg_label(cfg), "cfg": cfg, "result": parse_result(out), "measured": meas}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(job, P))
        lat = list(ex.map(lat_job, LAT))
    write_json(REPORTS / "perf.json", {"provenance": provenance(), "K": K, "points": res, "latency": lat})
    L = ["# Operand bandwidth: RTL measurement vs model", "",
         f"`scripts/run_perf.py`; RTL simulation (Verilator), 8 back-to-back full tiles of K = {K} k-slices per point, the array",
         "never back-pressures (s_ready = 1).  in-tile rate = k-slices delivered per cycle while a tile streams (1.0 =",
         "R A-operands + C B-operands every cycle); overall = slices / all cycles (incl. per-tile setup/drain gaps).",
         "Model: `model/tob_bw_model.py` (L = lanes per physical A bank per round; full rate predicted when the bank-port",
         "limit and the latency-coverage conditions hold).  Every point is also a self-checking run (all slices compared).", "",
         "| group | configuration | layout | note | lanes/bank L | model: full rate? | in-tile rate | operands/cycle | overall | starve A/B | conflicts | wr stall | overlap | check |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in res:
        if not r.get("measured"):
            L.append(f"| {r['group']} | {r.get('label', '')} | | {r['note']} | | | | | | | | | | {r['result']} |")
            continue
        m, md = r["measured"], r["model"]
        L.append(f"| {r['group']} | {r['label']} | lda {r['lda']} ldb {r['ldb']} a+{r['abase']} b+{r['bbase']}{' +DMA' if r['conc'] else ''} | {r['note']} | "
                 f"{md['lanes_per_bank']} | {'yes' if md['predicted_full_rate'] else 'no (bound ' + format(md['predicted_rate_upper'], '.2f') + ')'} | "
                 f"{r['in_tile_rate']:.3f} | {r['operands_per_cycle_in_tile']} | {r['overall_rate']:.3f} | {m['starve_a']}/{m['starve_b']} | "
                 f"{m['conflicts']} | {m['wr_stall']} | {m['overlap']} | {r['result']} |")
    L += ["", "## Latency on an idle buffer (cycles, conflict-free layout, `+test=latency`)", "",
          "| configuration | DMA write accept -> response | tile accept -> tile response | tile accept -> first slice | gap between back-to-back tiles | check |",
          "|---|---|---|---|---|---|"]
    for r in lat:
        m = r.get("measured", {})
        L.append(f"| {r['label']} | {m.get('dma_accept_to_rsp', '')} | {m.get('tile_accept_to_rsp', '')} | "
                 f"{m.get('tile_accept_to_first_slice', '')} | {m.get('back_to_back_gap', '')} | {r['result']} |")
    pts = [r for r in res if r.get("measured") and not r["conc"]]
    agree = sum(1 for r in pts if r["model"]["predicted_full_rate"] == (r["in_tile_rate"] >= 0.9995))
    L += ["", f"Model check (compute-only points): full rate predicted <=> measured in-tile rate = 1.000 on {agree} / {len(pts)} points.",
          f"Self-checking runs passing: {sum(1 for r in res + lat if r['result'] == 'PASS')} / {len(res) + len(lat)}."]
    (REPORTS / "perf.md").write_text("\n".join(L) + "\n")
    print("\n".join(L[-40:]))
    return 0 if all(r["result"] == "PASS" for r in res + lat) else 1


if __name__ == "__main__":
    sys.exit(main())
