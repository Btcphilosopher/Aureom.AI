#!/usr/bin/env bash
# Package the module as a zip (no build products).  Usage: scripts/package.sh <output.zip>
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
out="$(realpath -m "${1:?output zip path}")"
cd "$here"
find . -type f ! -path './build/*' ! -path '*/__pycache__/*' ! -name SHA256SUMS ! -name '*.zip' -print0 \
  | sort -z | xargs -0 sha256sum > SHA256SUMS
cd ..
name="$(basename "$here")"
rm -f "$out"
zip -q -r -X "$out" "$name" -x "$name/build/*" "$name/*/__pycache__/*"
echo "wrote $out ($(du -h "$out" | cut -f1)); $(wc -l < "$here/SHA256SUMS") files hashed"
