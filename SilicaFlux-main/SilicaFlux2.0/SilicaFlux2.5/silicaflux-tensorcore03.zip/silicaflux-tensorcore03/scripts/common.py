"""Shared helpers for the TENSORCORE 03 scripts: file lists, builds, runs, provenance."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RTL = ROOT / "rtl"
TB = ROOT / "tb"
SRAMLIB = ROOT / "third_party/silicaflux-sramlib/rtl/mem"
TC02 = ROOT / "third_party/silicaflux-tensorcore02/rtl"
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"

SRAMLIB_FILES = [
    SRAMLIB / "sram_backend_1rw.sv",
    SRAMLIB / "sram_backend_1r1w.sv",
    SRAMLIB / "backends/generic/sram_generic_1rw.sv",
    SRAMLIB / "backends/generic/sram_generic_1r1w.sv",
    SRAMLIB / "backends/fpga/sram_fpga_1rw.sv",
    SRAMLIB / "backends/fpga/sram_fpga_1r1w.sv",
    SRAMLIB / "backends/asic/sram_asic_array.sv",
    SRAMLIB / "backends/asic/sram_leaf_sky130.sv",
    SRAMLIB / "backends/asic/sram_leaf_gf180.sv",
    SRAMLIB / "backends/asic/sram_leaf_ihp1p.sv",
    SRAMLIB / "backends/asic/sram_leaf_ihp2p.sv",
]
STUBS = SRAMLIB / "backends/asic/stubs/sram_macro_blackboxes.sv"
DMA_FIFO = ROOT / "third_party/silicaflux-datafabric/rtl/dma/dma_fifo.sv"
TOB_FILES = [RTL / f for f in ["tob_bank_arb.sv", "tob_bank.sv", "tob_dbuf_ctrl.sv", "tob_dma_port.sv",
                               "tob_tile_agu.sv", "tob_perf.sv", "tensor_operand_buffer.sv"]]
RTL_FILES = SRAMLIB_FILES + [STUBS, DMA_FIFO] + TOB_FILES
SYNTH_FILES = SRAMLIB_FILES + [DMA_FIFO] + TOB_FILES          # stubs added only for the ASIC flow
TC02_FILES = [TC02 / f for f in ["tensor_pe.sv", "tensor_skew.sv", "tensor_output_collect.sv", "tensor_systolic_array.sv"]]
INCDIRS = [RTL, SRAMLIB, SRAMLIB / "backends/asic"]
SIM_DEFINES = ["TOB_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"]
VLT = ROOT / "scripts/lint.vlt"

# testbench parameter defaults (tb/tb_tensor_operand_buffer.sv) and the DUT parameter each maps to
TB_DEFAULTS = dict(R=4, C=4, WB=4, ASB=4096, BSB=4096, NBA=4, NBB=2, REPL=1, NS=2, SMAP=0, PMODE=1, RL=1,
                   AST=2, BST=4, WSL=8, AW=32, BASE=0, BACKEND=0)
TB_TO_DUT = dict(R="ARRAY_ROWS", C="ARRAY_COLS", WB="WORD_BYTES", ASB="A_SET_BYTES", BSB="B_SET_BYTES",
                 NBA="A_BANKS", NBB="B_BANKS", REPL="A_REPL", NS="NUM_SETS", SMAP="SET_MAP", PMODE="PORT_MODE",
                 RL="READ_LATENCY", AST="A_STAGE", BST="B_STAGE", WSL="WR_STARVE_LIMIT", AW="ADDR_W",
                 BASE="DMA_BASE", BACKEND="BACKEND")
PMODE_NAMES = {0: "1RW", 1: "1R1W"}
SMAP_NAMES = {0: "SHARED", 1: "SPLIT"}
BACKEND_NAMES = {0: "GENERIC", 1: "FPGA", 2: "ASIC"}

VERILATOR_WAIVERS = ["-Wno-fatal", "-Wno-WIDTH", "-Wno-UNUSED", "-Wno-DECLFILENAME", "-Wno-INITIALDLY",
                     "-Wno-BLKSEQ", "-Wno-UNOPTFLAT", "-Wno-TIMESCALEMOD", "-Wno-CASEINCOMPLETE"]


def full_cfg(cfg: dict) -> dict:
    c = dict(TB_DEFAULTS)
    c.update(cfg)
    return c


def cfg_label(cfg: dict) -> str:
    c = full_cfg(cfg)
    s = (f"{c['R']}x{c['C']} WB{c['WB']} A{c['ASB'] // 1024 if c['ASB'] >= 1024 else c['ASB']}{'K' if c['ASB'] >= 1024 else 'B'}"
         f"/{c['NBA']}b B{c['BSB'] // 1024 if c['BSB'] >= 1024 else c['BSB']}{'K' if c['BSB'] >= 1024 else 'B'}/{c['NBB']}b "
         f"{'DB' if c['NS'] == 2 else 'SB'}{'-' + SMAP_NAMES[c['SMAP']] if c['NS'] == 2 else ''} {PMODE_NAMES[c['PMODE']]} RL{c['RL']}")
    if c["REPL"] != 1:
        s += f" REPL{c['REPL']}"
    if c["AST"] != 2 or c["BST"] != 4:
        s += f" stage{c['AST']}/{c['BST']}"
    if c["WSL"] != 8:
        s += f" WSL{c['WSL']}"
    if c["BASE"]:
        s += f" base{c['BASE']:#x}"
    if c["AW"] != 32:
        s += f" AW{c['AW']}"
    if c["BACKEND"]:
        s += " " + BACKEND_NAMES[c["BACKEND"]]
    return s


def cfg_key(cfg: dict) -> str:
    c = full_cfg(cfg)
    return hashlib.sha1(json.dumps(c, sort_keys=True).encode()).hexdigest()[:10]


def run(cmd, cwd=None, timeout=3600, env=None):
    t0 = time.time()
    try:
        p = subprocess.run([str(x) for x in cmd], cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        return p.returncode, p.stdout + p.stderr, time.time() - t0
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        return 124, out + "\nTIMEOUT", time.time() - t0


def gparams(cfg: dict, prefix: str) -> list[str]:
    c = full_cfg(cfg)
    return [f"{prefix}{k}={v}" for k, v in c.items()]


_LOCKS: dict = {}
_LOCKS_GUARD = threading.Lock()


def _lock(d: Path) -> threading.Lock:
    with _LOCKS_GUARD:
        return _LOCKS.setdefault(str(d), threading.Lock())


def verilator_build(top: str, files: list, cfg: dict, tag: str, extra_defines=(), gpre="-G", params=True) -> tuple[Path, str]:
    """Build (cached, one build per directory at a time) a Verilator --binary model; returns (binary, log)."""
    d = BUILD / f"v_{tag}_{cfg_key(cfg)}_{'_'.join(extra_defines) or 'std'}"
    with _lock(d):
        return _verilator_build(top, files, cfg, d, extra_defines, gpre, params)


def _verilator_build(top, files, cfg, d, extra_defines, gpre, params=True):
    exe = d / "obj_dir" / "tb"
    if exe.exists():
        return exe, "cached"
    d.mkdir(parents=True, exist_ok=True)
    cmd = (["verilator", "--binary", "--timing", "-j", "2", *VERILATOR_WAIVERS]
           + [f"-I{p}" for p in INCDIRS] + [f"-D{x}" for x in SIM_DEFINES + list(extra_defines)]
           + (gparams(cfg, gpre) if params else []) + ["--top-module", top, *files, "-o", "tb"])
    rc, out, _ = run(cmd, cwd=d, timeout=3600)
    (d / "build.log").write_text(" ".join(map(str, cmd)) + "\n" + out)
    strip_obj_dir(d / "obj_dir")
    return (exe if rc == 0 and exe.exists() else None), out


def strip_obj_dir(od: Path) -> None:
    """Keep only the simulation binary: Verilator's generated C++ and objects are ~150 MB per model."""
    if not od.is_dir():
        return
    for f in od.iterdir():
        if f.name != "tb":
            if f.is_dir():
                shutil.rmtree(f, ignore_errors=True)
            else:
                f.unlink(missing_ok=True)


def icarus_build(top: str, files: list, cfg: dict, tag: str, extra_defines=(), params=True) -> tuple[Path, str]:
    d = BUILD / f"i_{tag}_{cfg_key(cfg)}_{'_'.join(extra_defines) or 'std'}"
    with _lock(d):
        return _icarus_build(top, files, cfg, d, extra_defines, params)


def _icarus_build(top, files, cfg, d, extra_defines, params=True):
    vvp = d / "tb.vvp"
    if vvp.exists():
        return vvp, "cached"
    d.mkdir(parents=True, exist_ok=True)
    cmd = (["iverilog", "-g2012", "-o", vvp] + [f"-I{p}" for p in INCDIRS]
           + [f"-D{x}" for x in SIM_DEFINES + list(extra_defines)]
           + ([f"-P{top}.{k}={v}" for k, v in full_cfg(cfg).items()] if params else []) + ["-s", top, *files])
    rc, out, _ = run(cmd, cwd=d, timeout=1800)
    (d / "build.log").write_text(" ".join(map(str, cmd)) + "\n" + out)
    return (vvp if rc == 0 and vvp.exists() else None), out


def parse_result(out: str) -> str:
    m = re.findall(r"RESULT: (PASS|FAIL[^\n]*)", out)
    return m[-1] if m else "NO-RESULT"


def tool_versions() -> dict:
    v = {}
    for name, cmd in [("verilator", ["verilator", "--version"]), ("iverilog", ["iverilog", "-V"]),
                      ("yosys", ["yosys", "-V"]), ("nextpnr-ecp5", ["nextpnr-ecp5", "--version"])]:
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            v[name] = (p.stdout + p.stderr).strip().splitlines()[0]
        except Exception as e:  # noqa: BLE001
            v[name] = f"not available ({e})"
    v["python"] = platform.python_version()
    return v


def provenance() -> dict:
    return {"date_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "host": platform.node(),
            "tools": tool_versions()}


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=False) + "\n")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
