#!/usr/bin/env python3
"""Mutation testing: inject one design bug at a time into a copy of rtl/ and check that the testbenches fail.

Every mutant is a single exact textual substitution (it must match exactly once and still compile).  A mutant is
KILLED when at least one of the evaluation runs reports FAIL (or no result / timeout); SURVIVED otherwise.
Evaluation runs (Verilator, test=all, seed 1): four buffer configurations chosen so that every mechanism is active
somewhere (1RW contention, 1R1W double buffer, read latency 2, DMA window with base and hole), plus the arbiter unit
test for arbiter mutants.  Results: reports/mutation.{json,md}.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (BUILD, REPORTS, RTL, SIM_DEFINES, SRAMLIB, TB, VERILATOR_WAIVERS, full_cfg, gparams,  # noqa: E402
                    parse_result, provenance, run, write_json, RTL_FILES, strip_obj_dir)

EVAL_CFGS = [
    dict(PMODE=0),                                   # double buffer, shared banks, 1RW: contention and forced writes
    dict(),                                          # double buffer, 1R1W
    dict(RL=2, AST=4, BST=4, PMODE=0, SMAP=1),       # read latency 2, split sets
    dict(ASB=2048, BSB=8192, BASE=0x10000, NS=1, C=8, NBB=2),   # window with base and hole, multi-beat B rows
]

M = [  # (id, file, original, mutant, description)
    ("arb_rr_frozen", "tob_bank_arb.sv", "else if (rd_any) ptr_q <=", "else if (1'b0) ptr_q <=", "round-robin pointer never moves (fixed priority)"),
    ("arb_no_hazard", "tob_bank_arb.sv", "else                            hz[i] = rd_req[i] && (rd_row[i*RW +: RW] == wr_row);",
     "else                            hz[i] = 1'b0;", "1R1W same-row read/write hazard ignored"),
    ("arb_no_force", "tob_bank_arb.sv", "assign wr_ok     = !wr_req || (hz == '0) || wr_force;", "assign wr_ok     = !wr_req || (hz == '0);", "write starvation limit ignored"),
    ("arb_no_block", "tob_bank_arb.sv", "assign elig      = rd_req & ~rd_wr_blk;", "assign elig      = rd_req;", "reads not blocked by a granted write"),
    ("arb_two_grants", "tob_bank_arb.sv", "      if (!found && cand[idx]) begin", "      if (cand[idx]) begin", "several reads granted in one cycle"),
    ("arb_no_urgency", "tob_bank_arb.sv", "wire [NR-1:0] cand   = (elig_u != '0) ? elig_u : elig;", "wire [NR-1:0] cand   = elig;", "urgent requests not preferred"),
    ("dma_no_owner", "tob_dma_port.sv", "else if (st_x != `TOB_ST_FILL)   code = `TOB_DERR_OWNER;", "else if (1'b0)   code = `TOB_DERR_OWNER;", "ownership check removed"),
    ("dma_no_align", "tob_dma_port.sv", "else if (off[LWB-1:0] != '0)     code = `TOB_DERR_ALIGN;", "else if (1'b0)     code = `TOB_DERR_ALIGN;", "alignment check removed"),
    ("dma_hole", "tob_dma_port.sv", "in_b  = !below && (64'(off) >= REGION) && (64'(off) < REGION + B_TOT);",
     "in_b  = !below && (64'(off) >= A_TOT) && (64'(off) < REGION + B_TOT);", "hole between A and B decoded as B"),
    ("dma_retire_early", "tob_dma_port.sv", "wire retire  = h_v && (h_err || wr_go);", "wire retire  = h_v;", "write acknowledged without a bank grant"),
    ("dma_credit", "tob_dma_port.sv", "assign req_ready = alive_q && (occ < (RAW+2)'(RSP_DEPTH)) && (!h_v || retire);",
     "assign req_ready = alive_q && (occ <= (RAW+2)'(RSP_DEPTH)) && (!h_v || retire);", "response credit off by one"),
    ("dma_force_never", "tob_dma_port.sv", "assign wr_force = (w_q >= WCW'(WR_STARVE_LIMIT));", "assign wr_force = 1'b0;", "starvation counter never forces"),
    ("dbuf_fe_no_idle", "tob_dbuf_ctrl.sv", "assign fill_end_ready   = (st_f == `TOB_ST_FILL) && dma_idle;", "assign fill_end_ready   = (st_f == `TOB_ST_FILL);", "fill_end while a DMA request is held"),
    ("dbuf_ce_no_idle", "tob_dbuf_ctrl.sv", "assign cmp_end_ready    = (st_c == `TOB_ST_COMPUTE) && engine_idle;", "assign cmp_end_ready    = (st_c == `TOB_ST_COMPUTE);", "compute set released before its operands were delivered"),
    ("dbuf_no_pingpong", "tob_dbuf_ctrl.sv", "        fp_q              <= nxt(fp_q);", "        fp_q              <= fp_q;", "fill pointer does not advance"),
    ("agu_range_off1", "tob_tile_agu.sv", "else if (alast_q >= XW'(A_SET_BYTES))", "else if (alast_q > XW'(A_SET_BYTES))", "A range check off by one"),
    ("agu_no_ovf", "tob_tile_agu.sv", "if (alast_q[XW-1:ADDR_W] != '0)                rcode_c = `TOB_TERR_A_OVF;",
     "if (1'b0)                rcode_c = `TOB_TERR_A_OVF;", "A overflow not detected"),
    ("agu_no_kclamp", "tob_tile_agu.sv", "ek_c    = (tk_q <= krem_c) ? tk_q : krem_c;", "ek_c    = tk_q;", "tile_k not clamped at the matrix edge"),
    ("agu_lane_stride", "tob_tile_agu.sv", "acc_q                   <= acc_q + lda_q[ABW-1:0];", "acc_q                   <= acc_q + lda_q[ABW-1:0] + 1'b1;", "lane start address off by one per row"),
    ("agu_ld_check", "tob_tile_agu.sv", "ld_c    = (lda_q < ADDR_W'(mat_k_q)) || (ldb_q < ADDR_W'(mat_n_q));", "ld_c    = (ldb_q < ADDR_W'(mat_n_q));", "lda check removed"),
    ("top_pop_no_last", "tensor_operand_buffer.sv", "assign a_pop[i] = emit && live[i] && ((hoff == LWB'(WB - 1)) || c_last);",
     "assign a_pop[i] = emit && live[i] && (hoff == LWB'(WB - 1));", "lane word not retired at the end of a tile"),
    ("top_hoff_aligned", "tensor_operand_buffer.sv", "      hoff        = cctx[O_OFF + i*LWB +: LWB] + ck_q[LWB-1:0];", "      hoff        = ck_q[LWB-1:0];", "A byte offset ignores the start offset (slice data)"),
    ("top_b_no_off", "tensor_operand_buffer.sv", "b_row[j*8 +: 8] = line_n[(32'(o_off) + j)*8 +: 8];", "b_row[j*8 +: 8] = line_n[j*8 +: 8];", "B row extraction ignores the byte offset"),
    ("top_rl_stage", "tensor_operand_buffer.sv", "wire [PBW-1:0] spb = rpb[(READ_LATENCY-1)*PBW +: PBW];", "wire [PBW-1:0] spb = rpb[0 +: PBW];", "read data routed with the wrong pipeline stage"),
    ("top_bcredit", "tensor_operand_buffer.sv", "((bq_q != '0) || (bcnt_q < BCW'(B_STAGE)));", "((bq_q != '0) || (bcnt_q <= BCW'(B_STAGE)));", "B staging credit off by one"),
    ("top_acredit", "tensor_operand_buffer.sv", "(cnt_q < ACW'(A_STAGE));", "(cnt_q <= ACW'(A_STAGE));", "A staging credit off by one"),
    ("top_no_colmask", "tensor_operand_buffer.sv", "sb_c[j*8 +: 8] = cmask[j] ? b_head[j*8 +: 8] : 8'h00;", "sb_c[j*8 +: 8] = b_head[j*8 +: 8];", "dead B lanes not zeroed"),
    ("top_wrgo_no_b", "tensor_operand_buffer.sv", "assign wr_go = wr_valid && (a_wok == '1) && (b_wok == '1);", "assign wr_go = wr_valid && (a_wok == '1);", "B banks not consulted for writes"),
    ("top_set_row", "tensor_operand_buffer.sv", "wire [ARW-1:0]  wa_prow   = a_prow(wr_set, wa_rin);", "wire [ARW-1:0]  wa_prow   = a_prow('0, wa_rin);", "DMA writes ignore the set (shared banks)"),
    ("top_kg", "tensor_operand_buffer.sv", "skg_q    <= c_k0 + ck_q;", "skg_q    <= c_k0;", "global k coordinate wrong"),
    ("top_idle_outv", "tensor_operand_buffer.sv", "!f_run_q && !out_v && lanes_empty", "!f_run_q && lanes_empty", "engine idle while the last slice is still held"),
    ("top_fdone_no_b", "tensor_operand_buffer.sv", "wire             f_done = f_run_q && (fact == '0) && !bact_q;", "wire             f_done = f_run_q && (fact == '0);", "fetch context advanced before the B rows were issued"),
    ("top_ev_awords", "tensor_operand_buffer.sv", "n_ard  = n_ard  + EV_W'(a_rd_en[p]);", "n_ard  = n_ard  + EV_W'(a_rd_en[0]);", "A read-word event counts the wrong bank"),
    ("top_b_allornothing", "tensor_operand_buffer.sv", "assign b_go  = b_req && ((~b_rdreq | b_gnt) == '1);", "assign b_go  = b_req && (b_gnt != '0);", "B beat issued when only some banks granted"),
]

ARB_MUTANTS = {"arb_rr_frozen", "arb_no_hazard", "arb_no_force", "arb_no_block", "arb_two_grants", "arb_no_urgency"}


def eval_one(mid: str, rtl: Path, cfg: dict) -> dict:
    d = BUILD / "mut" / mid / ("cfg_" + "_".join(f"{k}{v}" for k, v in sorted(cfg.items())) or "base")
    d.mkdir(parents=True, exist_ok=True)
    files = [f if f.parent != RTL else rtl / f.name for f in RTL_FILES] + [TB / "tb_tensor_operand_buffer.sv"]
    inc = [rtl, SRAMLIB, SRAMLIB / "backends/asic"]
    cmd = (["verilator", "--binary", "--timing", "-j", "2", *VERILATOR_WAIVERS] + [f"-I{p}" for p in inc]
           + [f"-D{x}" for x in SIM_DEFINES] + gparams(cfg, "-G") + ["--top-module", "tb_tensor_operand_buffer", *files, "-o", "tb"])
    rc, out, _ = run(cmd, cwd=d, timeout=3600)
    strip_obj_dir(d / "obj_dir")
    if rc != 0:
        shutil.rmtree(d, ignore_errors=True)
        return {"cfg": cfg, "result": "BUILD-FAIL", "log": out[-800:]}
    rc, out, dt = run([d / "obj_dir/tb", "+test=all", "+seed=1"], cwd=d, timeout=900)
    shutil.rmtree(d, ignore_errors=True)                 # keep the disk allowance: mutant models are throw-away
    errs = [ln for ln in out.splitlines() if ln.startswith("ERROR")][:3]
    return {"cfg": cfg, "result": parse_result(out), "first_errors": errs, "seconds": round(dt, 1)}


def eval_arb(mid: str, rtl: Path) -> dict:
    d = BUILD / "mut" / mid / "arb"
    d.mkdir(parents=True, exist_ok=True)
    cmd = (["verilator", "--binary", "--timing", *VERILATOR_WAIVERS, f"-I{rtl}", f"-I{SRAMLIB}", "--top-module", "tb_tob_bank_arb",
            rtl / "tob_bank_arb.sv", TB / "tb_tob_bank_arb.sv", "-o", "tb"])
    rc, out, _ = run(cmd, cwd=d, timeout=1800)
    strip_obj_dir(d / "obj_dir")
    if rc != 0:
        return {"cfg": "arb-unit", "result": "BUILD-FAIL", "log": out[-800:]}
    rc, out, dt = run([d / "obj_dir/tb"], cwd=d, timeout=600)
    shutil.rmtree(d, ignore_errors=True)
    errs = [ln for ln in out.splitlines() if ln.startswith("ERROR")][:3]
    return {"cfg": "arb-unit", "result": parse_result(out), "first_errors": errs}


def mutant(m, ex) -> dict:
    mid, fname, orig, mut, desc = m
    rtl = BUILD / "mut" / mid / "rtl"
    if rtl.exists():
        shutil.rmtree(rtl)
    shutil.copytree(RTL, rtl)
    src = (rtl / fname).read_text()
    n = src.count(orig)
    if n != 1:
        return {"id": mid, "file": fname, "desc": desc, "status": f"INVALID (pattern found {n} times)"}
    (rtl / fname).write_text(src.replace(orig, mut))
    futs = [ex.submit(eval_one, mid, rtl, c) for c in EVAL_CFGS]
    if mid in ARB_MUTANTS:
        futs.append(ex.submit(eval_arb, mid, rtl))
    runs = [f.result() for f in futs]
    if any(r["result"] == "BUILD-FAIL" for r in runs):
        status = "INVALID (does not compile)"
    else:
        status = "KILLED" if any(r["result"] != "PASS" for r in runs) else "SURVIVED"
    return {"id": mid, "file": fname, "desc": desc, "original": orig, "mutant": mut, "status": status,
            "killed_by": [str(r["cfg"]) for r in runs if r["result"] != "PASS"], "runs": runs}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    sel = [m for m in M if not a.only or m[0] in a.only.split(",")]
    res = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as inner, cf.ThreadPoolExecutor(max_workers=2) as outer:
        for r in outer.map(lambda m: mutant(m, inner), sel):
            print(f"{r['id']:22s} {r['status']:10s} {r['desc']}  {r.get('killed_by', '')}")
            res.append(r)
    write_json(REPORTS / "mutation.json", {"provenance": provenance(), "eval_cfgs": EVAL_CFGS, "mutants": res})
    killed = sum(1 for r in res if r["status"] == "KILLED")
    L = ["# Mutation testing", "", f"**{killed} / {len(res)} mutants killed.**  Each mutant is one exact substitution in a copy",
         "of `rtl/`; evaluation = `tb_tensor_operand_buffer +test=all +seed=1` on the four configurations below (plus",
         "`tb_tob_bank_arb` for arbiter mutants).  Killed = at least one run fails.", "",
         "Evaluation configurations: " + "; ".join(str(full_cfg(c) if False else c) for c in EVAL_CFGS), "",
         "| mutant | file | injected bug | status | killed by | first error |", "|---|---|---|---|---|---|"]
    for r in res:
        fe = next((e for run_ in r.get("runs", []) for e in run_.get("first_errors", [])), "")
        L.append(f"| {r['id']} | {r['file']} | {r['desc']} | {r['status']} | {', '.join(r.get('killed_by', []))} | {fe[:110].replace('|', '/')} |")
    (REPORTS / "mutation.md").write_text("\n".join(L) + "\n")
    print(f"{killed}/{len(res)} killed")
    return 0 if killed == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
