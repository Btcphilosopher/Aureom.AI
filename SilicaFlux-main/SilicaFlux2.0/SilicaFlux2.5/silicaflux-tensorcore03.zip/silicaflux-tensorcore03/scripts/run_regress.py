#!/usr/bin/env python3
"""Staged regression of tensor_operand_buffer.

  lint     Verilator -Wall (zero warnings) over every regression configuration + Icarus elaboration,
           and negative elaboration tests: every illegal parameter combination must be rejected.
  stage1   single buffer (NUM_SETS = 1), ONE bank per operand: correctness baseline.
  stage2   single buffer, banked parallel access (banks, replication, array sizes, word widths, latencies).
  stage3   double buffering (NUM_SETS = 2): SHARED / SPLIT sets, 1RW / 1R1W, write-starvation limits, ...
  cross    the same seed in Icarus 12 (4-state) and Verilator: identical SUMMARY / measurement lines required.
  unit     tob_bank_arb unit test (both simulators).
  integ    DMA -> buffer -> TENSORCORE 02 array -> C vs reference matmul, overlapped and serial runs.

A stage only runs when every earlier stage passed (--force overrides).  Results: reports/regression.{json,md}.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from tob_bw_model import predict  # noqa: E402
from common import (BUILD, INCDIRS, REPORTS, RTL_FILES, TB, TB_TO_DUT, TC02_FILES, VLT, cfg_label, full_cfg,  # noqa: E402
                    icarus_build, parse_result, provenance, run, verilator_build, write_json)

TB_MAIN = TB / "tb_tensor_operand_buffer.sv"

SB1 = dict(NS=1, NBA=1, NBB=1)
STAGES = {
    "stage1": [
        dict(SB1),
        dict(SB1, PMODE=0),
        dict(SB1, RL=2, AST=4, BST=4),
        dict(SB1, PMODE=0, WSL=0),
        dict(SB1, R=2, C=2, ASB=1024, BSB=1024),
        dict(SB1, R=1, C=1, ASB=1024, BSB=1024),
        dict(SB1, WB=8),
    ],
    "stage2": [
        dict(NS=1),
        dict(NS=1, PMODE=0),
        dict(NS=1, NBA=2, NBB=2, RL=2),
        dict(NS=1, REPL=2),
        dict(NS=1, REPL=4, NBA=2),
        dict(NS=1, R=3, C=5, NBA=4, NBB=4),
        dict(NS=1, WB=2, NBA=4, NBB=4),
        dict(NS=1, WB=8, NBA=2, NBB=2),
        dict(NS=1, RL=3, AST=4, BST=8),
        dict(NS=1, C=8, NBB=2),
        dict(NS=1, R=8, C=8, NBA=8, NBB=4),
        dict(NS=1, R=16, C=16, NBA=8, NBB=8, ASB=8192, BSB=8192, AST=4, BST=4),
        dict(NS=1, BACKEND=1),
    ],
    "stage3": [
        dict(),
        dict(PMODE=0),
        dict(PMODE=0, SMAP=1),
        dict(SMAP=1),
        dict(PMODE=0, WSL=0),
        dict(PMODE=0, WSL=2),
        dict(PMODE=0, REPL=2),
        dict(RL=2, AST=4, BST=4),
        dict(ASB=2048, BSB=8192, BASE=0x10000),
        dict(R=8, C=8, NBA=8, NBB=4, SMAP=1),
        dict(PMODE=0, NBA=1, NBB=1),
        dict(BACKEND=1),
        dict(AW=40),
    ],
}
CROSS = [("stage1", 0), ("stage1", 1), ("stage2", 0), ("stage2", 3), ("stage2", 9), ("stage3", 0), ("stage3", 1),
         ("stage3", 2), ("stage3", 8)]
INTEG = [dict(PMODE=1, RL=1, SMAP=0, STALL=10), dict(PMODE=0, RL=1, SMAP=0, STALL=10), dict(PMODE=0, RL=1, SMAP=1, STALL=10),
         dict(PMODE=1, RL=2, SMAP=0, STALL=30), dict(PMODE=1, RL=1, SMAP=0, STALL=0), dict(R=8, C=8, PMODE=1, RL=1, SMAP=0, STALL=10),
         dict(R=2, C=3, PMODE=0, RL=3, SMAP=0, STALL=20)]

NEGATIVE = [  # (DUT parameter overrides, expected generate-block / message fragment)
    (dict(WORD_BYTES=3), "WORD_BYTES"), (dict(WORD_BYTES=1), "WORD_BYTES"), (dict(A_BANKS=3), "powers of two"),
    (dict(A_SET_BYTES=3000), "powers of two"), (dict(A_SET_BYTES=32, A_BANKS=8), "rows per set"),
    (dict(A_REPL=3), "A_REPL must be 1, 2 or 4"), (dict(A_REPL=4, ARRAY_ROWS=2), "must not exceed"),
    (dict(NUM_SETS=3), "NUM_SETS"), (dict(SET_MAP=2), "SET_MAP"), (dict(READ_LATENCY=0), "READ_LATENCY"),
    (dict(READ_LATENCY=9), "READ_LATENCY"), (dict(A_STAGE=3), "A_STAGE"), (dict(B_STAGE=1), "A_STAGE"),
    (dict(ADDR_W=8), "ADDR_W"), (dict(BACKEND=2), "MACRO_A"), (dict(PORT_MODE=2), "PORT_MODE"),
    (dict(DMA_RSP_DEPTH=3), "RSP_DEPTH"), (dict(DMA_BASE=2), "word aligned"), (dict(ARRAY_ROWS=0), "ARRAY_ROWS"),
    (dict(ADDR_W=16, A_SET_BYTES=32768, DMA_BASE=0x8000), "does not fit"),
]

SEEDS = [1, 2]


def dut_params(cfg: dict) -> dict:
    c = full_cfg(cfg)
    d = {TB_TO_DUT[k]: v for k, v in c.items()}
    d["DMA_BASE"] = f"64'h{c['BASE']:x}"
    return d


def lint_job(cfg: dict) -> dict:
    cmd = (["verilator", "--lint-only", "-Wall", VLT] + [f"-I{p}" for p in INCDIRS] + ["-DTOB_ASSERT"]
           + [f"-G{k}={v}" for k, v in dut_params(cfg).items()] + ["--top-module", "tensor_operand_buffer", *RTL_FILES])
    rc, out, dt = run(cmd, cwd=BUILD, timeout=600)
    warns = [ln for ln in out.splitlines() if ln.startswith("%Warning") or ln.startswith("%Error")]
    cmd_i = (["iverilog", "-g2012", "-o", "/dev/null"] + [f"-I{p}" for p in INCDIRS]
             + [f"-Ptensor_operand_buffer.{k}={v}" for k, v in dut_params(cfg).items()]
             + ["-s", "tensor_operand_buffer", *RTL_FILES])
    rc_i, out_i, _ = run(cmd_i, cwd=BUILD, timeout=600)
    ok = rc == 0 and not warns and rc_i == 0
    return {"suite": "lint", "label": cfg_label(cfg), "cfg": cfg, "verilator_rc": rc, "warnings": warns[:10],
            "icarus_rc": rc_i, "icarus_out": out_i[-500:] if rc_i else "", "result": "PASS" if ok else "FAIL",
            "seconds": round(dt, 1)}


def negative_job(params: dict, frag: str) -> dict:
    cmd = (["verilator", "--lint-only", VLT] + [f"-I{p}" for p in INCDIRS]
           + [f"-G{k}={v}" for k, v in params.items()] + ["--top-module", "tensor_operand_buffer", *RTL_FILES])
    rc, out, _ = run(cmd, cwd=BUILD, timeout=600)
    rejected = rc != 0 and frag in out
    return {"suite": "negative", "params": params, "expect": frag, "rc": rc,
            "result": "PASS" if rejected else "FAIL", "out": "" if rejected else out[-600:]}


def full_rate_predicted(cfg: dict) -> bool:
    """Model prediction for the t_concurrent layout (conflict-free word stride, A/B bases 0..WB-1 at random)."""
    c = full_cfg(cfg)
    l = c["WB"] * (c["NBA"] + 1)
    while l < 32:
        l += c["WB"] * c["NBA"]
    return all(predict(c, l, c["C"], a0, b0, 32)["predicted_full_rate"] for a0 in range(c["WB"]) for b0 in range(c["WB"]))


def sim_job(stage: str, idx: int, cfg: dict, seed: int, sim: str = "verilator", test: str = "all", extra=()) -> dict:
    files = [*RTL_FILES, TB_MAIN]
    if sim == "verilator":
        exe, blog = verilator_build("tb_tensor_operand_buffer", files, cfg, "main")
        if exe is None:
            return {"suite": stage, "idx": idx, "label": cfg_label(cfg), "cfg": cfg, "seed": seed, "sim": sim, "test": test,
                    "result": "BUILD-FAIL", "log": blog[-1500:]}
        rc, out, dt = run([exe, f"+test={test}", f"+seed={seed}", *extra], cwd=exe.parent.parent, timeout=3600)
    else:
        vvp, blog = icarus_build("tb_tensor_operand_buffer", files, cfg, "main")
        if vvp is None:
            return {"suite": stage, "idx": idx, "label": cfg_label(cfg), "cfg": cfg, "seed": seed, "sim": sim, "test": test,
                    "result": "BUILD-FAIL", "log": blog[-1500:]}
        rc, out, dt = run(["vvp", "-n", vvp, f"+test={test}", f"+seed={seed}"], cwd=vvp.parent, timeout=7200)
    res = parse_result(out)
    meas = [ln for ln in out.splitlines() if re.match(r"^(SUMMARY|CONTENTION|RDW|STARVE|PERF) ", ln)]
    errs = [ln for ln in out.splitlines() if ln.startswith("ERROR")][:8]
    return {"suite": stage, "idx": idx, "label": cfg_label(cfg), "cfg": cfg, "seed": seed, "sim": sim,
            "test": test + "".join(" " + x for x in extra), "result": res, "seconds": round(dt, 1), "measurements": meas, "errors": errs}


def unit_job(sim: str) -> dict:
    files = [INCDIRS[0] / "tob_bank_arb.sv", TB / "tb_tob_bank_arb.sv"]
    if sim == "verilator":
        exe, blog = verilator_build("tb_tob_bank_arb", files, {}, "arb", params=False)
        rc, out, dt = run([exe], cwd=BUILD, timeout=600) if exe else (1, blog, 0)
    else:
        vvp, blog = icarus_build("tb_tob_bank_arb", files, {}, "arb", params=False)
        rc, out, dt = run(["vvp", "-n", vvp], cwd=BUILD, timeout=600) if vvp else (1, blog, 0)
    meas = [ln for ln in out.splitlines() if ln.startswith("SUMMARY")]
    return {"suite": "unit", "sim": sim, "result": parse_result(out), "measurements": meas, "seconds": round(dt, 1)}


def integ_job(p: dict, sim: str = "verilator") -> dict:
    files = [*RTL_FILES, *TC02_FILES, TB / "tb_tob_array.sv"]
    tbp = {k: v for k, v in p.items()}
    if sim == "verilator":
        d = BUILD / ("integ_" + "_".join(f"{k}{v}" for k, v in sorted(tbp.items())))
        d.mkdir(parents=True, exist_ok=True)
        from common import SIM_DEFINES, VERILATOR_WAIVERS, strip_obj_dir
        cmd = (["verilator", "--binary", "--timing", "-j", "2", *VERILATOR_WAIVERS] + [f"-I{x}" for x in INCDIRS]
               + [f"-D{x}" for x in SIM_DEFINES] + [f"-G{k}={v}" for k, v in tbp.items()]
               + ["--top-module", "tb_tob_array", *files, "-o", "tb"])
        rc, out, _ = run(cmd, cwd=d, timeout=3600)
        strip_obj_dir(d / "obj_dir")
        if rc != 0:
            return {"suite": "integ", "params": p, "sim": sim, "result": "BUILD-FAIL", "log": out[-1500:]}
        rc, out, dt = run([d / "obj_dir/tb"], cwd=d, timeout=3600)
    else:
        d = BUILD / ("integ_i_" + "_".join(f"{k}{v}" for k, v in sorted(tbp.items())))
        d.mkdir(parents=True, exist_ok=True)
        from common import SIM_DEFINES
        cmd = (["iverilog", "-g2012", "-o", d / "tb.vvp"] + [f"-I{x}" for x in INCDIRS] + [f"-D{x}" for x in SIM_DEFINES]
               + [f"-Ptb_tob_array.{k}={v}" for k, v in tbp.items()] + ["-s", "tb_tob_array", *files])
        rc, out, _ = run(cmd, cwd=d, timeout=3600)
        if rc != 0:
            return {"suite": "integ", "params": p, "sim": sim, "result": "BUILD-FAIL", "log": out[-1500:]}
        rc, out, dt = run(["vvp", "-n", d / "tb.vvp"], cwd=d, timeout=7200)
    meas = [ln for ln in out.splitlines() if ln.startswith("INTEG")]
    errs = [ln for ln in out.splitlines() if ln.startswith("ERROR")][:8]
    return {"suite": "integ", "params": p, "sim": sim, "result": parse_result(out), "measurements": meas,
            "errors": errs, "seconds": round(dt, 1)}


def all_cfgs():
    seen, out = set(), []
    for st, lst in STAGES.items():
        for c in lst:
            k = cfg_label(c)
            if k not in seen:
                seen.add(k)
                out.append(c)
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", default="lint,stage1,stage2,stage3,cross,unit,integ")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--seeds", default=",".join(map(str, SEEDS)))
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--out", default="regression")
    a = ap.parse_args()
    seeds = [int(s) for s in a.seeds.split(",")]
    BUILD.mkdir(exist_ok=True)
    results, ok_so_far = [], True
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for st in a.stages.split(","):
            if not ok_so_far and not a.force:
                print(f"[skip] {st}: an earlier stage failed")
                results.append({"suite": st, "result": "SKIPPED"})
                continue
            if st == "lint":
                futs = [ex.submit(lint_job, c) for c in all_cfgs()] + [ex.submit(negative_job, p, f) for p, f in NEGATIVE]
            elif st in STAGES:
                # build once per configuration, then fan out the seeds
                futs = [ex.submit(sim_job, st, i, c, s) for i, c in enumerate(STAGES[st]) for s in seeds]
                # rate check: where the model predicts full rate, any bubble inside a tile is an error
                futs += [ex.submit(sim_job, st, i, c, 1, "verilator", "concurrent", ("+full_rate",))
                         for i, c in enumerate(STAGES[st]) if full_rate_predicted(c)]
            elif st == "cross":
                # Icarus and Verilator on the same configuration and seed (the Verilator reference is rerun here)
                futs = [ex.submit(sim_job, f"cross:{s}", i, STAGES[s][i], 1, "icarus") for s, i in CROSS]
                vref = {(s, i): ex.submit(sim_job, s, i, STAGES[s][i], 1, "verilator") for s, i in CROSS}
            elif st == "unit":
                futs = [ex.submit(unit_job, "verilator"), ex.submit(unit_job, "icarus")]
            elif st == "integ":
                futs = ([ex.submit(integ_job, p) for p in INTEG] + [ex.submit(integ_job, INTEG[0], "icarus")])
            else:
                print(f"unknown stage {st}")
                return 2
            stage_res = [f.result() for f in futs]
            if st == "cross":   # compare with the Verilator run of the same config and seed
                for r in stage_res:
                    stg = r["suite"].split(":")[1]
                    v = vref[(stg, r["idx"])].result()
                    same = v.get("result") == "PASS" and v.get("measurements") == r.get("measurements")
                    r["verilator_measurements"] = v.get("measurements")
                    r["identical_to_verilator"] = same
                    if r["result"] == "PASS" and not same:
                        r["result"] = "FAIL (differs from Verilator)"
            n_pass = sum(1 for r in stage_res if r["result"] == "PASS")
            print(f"[{st}] {n_pass}/{len(stage_res)} PASS")
            for r in stage_res:
                if r["result"] != "PASS":
                    print("   FAIL:", r.get("label", r.get("params")), r.get("seed", ""), r["result"], r.get("errors", r.get("warnings", r.get("out", "")))[:3] if isinstance(r.get("errors", r.get("warnings")), list) else r.get("out", "")[:300])
            ok_so_far = ok_so_far and n_pass == len(stage_res)
            results += stage_res
    write_json(REPORTS / f"{a.out}.json", {"provenance": provenance(), "results": results})
    write_md(results, REPORTS / f"{a.out}.md")
    return 0 if ok_so_far else 1


def write_md(results, path: Path) -> None:
    L = ["# Regression results", "", "Generated by `scripts/run_regress.py`; raw data in the `.json` next to this file.", ""]
    suites = []
    for r in results:
        if r["suite"] not in suites:
            suites.append(r["suite"])
    L += ["| suite | runs | pass |", "|---|---|---|"]
    for s in suites:
        rr = [r for r in results if r["suite"] == s]
        L.append(f"| {s} | {len(rr)} | {sum(1 for r in rr if r['result'] == 'PASS')} |")
    L.append("")
    for s in suites:
        rr = [r for r in results if r["suite"] == s and r["result"] != "SKIPPED"]
        L += [f"## {s}", ""]
        if not rr:
            L += ["(skipped: an earlier stage failed)", ""]
            continue
        if s == "lint":
            L += ["| configuration | Verilator -Wall | Icarus | result |", "|---|---|---|---|"]
            L += [f"| {r['label']} | {'clean' if not r['warnings'] and r['verilator_rc'] == 0 else r['warnings'][:1]} | rc {r['icarus_rc']} | {r['result']} |" for r in rr]
        elif s == "negative":
            L += ["| illegal parameters | expected rejection | result |", "|---|---|---|"]
            L += [f"| `{r['params']}` | {r['expect']} | {r['result']} |" for r in rr]
        elif s == "unit":
            L += ["| simulator | result | measurement |", "|---|---|---|"]
            L += [f"| {r['sim']} | {r['result']} | {' '.join(r['measurements'])} |" for r in rr]
        elif s == "integ":
            L += ["| parameters | sim | result | measurement |", "|---|---|---|---|"]
            L += [f"| {r['params']} | {r['sim']} | {r['result']} | {' '.join(r.get('measurements', []))} |" for r in rr]
        elif s.startswith("cross"):
            L += ["| configuration | seed | Icarus result | identical to Verilator |", "|---|---|---|---|"]
            L += [f"| {r['label']} | {r['seed']} | {r['result']} | {r.get('identical_to_verilator')} |" for r in rr]
        elif s.startswith("stage"):
            L += ["| # | configuration | test | seed | result | s | key measurements |", "|---|---|---|---|---|---|---|"]
            for r in rr:
                m = " ; ".join(x for x in r.get("measurements", []) if not x.startswith("SUMMARY") or "full_rate" in r["test"])
                L.append(f"| {r['idx']} | {r['label']} | {r['test']} | {r['seed']} | {r['result']} | {r.get('seconds', '')} | {m} |")
        else:
            L += [f"- {r}" for r in rr]
        L.append("")
    path.write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
