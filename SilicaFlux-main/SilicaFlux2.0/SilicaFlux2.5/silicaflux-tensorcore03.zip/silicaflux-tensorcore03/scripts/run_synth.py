#!/usr/bin/env python3
"""Synthesis and place-and-route resource report of tensor_operand_buffer (actual tool runs, no estimates).

  generic  Yosys technology-independent synthesis: elaboration, latch check (must be 0), and the inferred memories:
           exactly one $mem per PHYSICAL bank with the bank's depth (the other $mems are the small staging FIFOs).
  fpga     Yosys vendor flows with BACKEND = FPGA (block-RAM inference): synth_xilinx -family xc7, synth_ecp5,
           synth_ice40.  Every bank must map to RAM primitives (no $mem left = no flip-flop memory); RAM, LUT, FF,
           DSP/MULT counts from the post-synthesis netlist.  Synthesis only - no vendor tool, no timing for xc7.
  pnr      REAL place & route with nextpnr (ECP5 LFE5U-25F, iCE40 HX8K) of the buffer inside tob_pnr_wrap (I/O
           measurement wrapper): utilisation from nextpnr and the maximum frequency nextpnr's timing analysis
           reports for that device and speed grade.  FPGA numbers do NOT predict ASIC area or timing.
  asic     BACKEND = ASIC with pin-only black boxes of real open-PDK macros (SRAM Wrapper Library catalogue): the
           exact expected number of macro instances must survive, no $mem, no latch; the remaining cells are the
           buffer's control/datapath logic in Yosys generic gates (a cell count, NOT silicon area).
Results: reports/synth.{json,md}.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import math
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, INCDIRS, REPORTS, ROOT, STUBS, SYNTH_FILES, provenance, run, write_json  # noqa: E402

TOP = "tensor_operand_buffer"
WRAP = ROOT / "fpga/tob_pnr_wrap.sv"


def reads(stubs: bool = False, extra=()) -> str:
    files = [*SYNTH_FILES] + ([STUBS] if stubs else []) + list(extra)
    return "read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{p}" for p in INCDIRS) + " " + " ".join(str(f) for f in files)


def chparam(top: str, p: dict) -> str:
    return f"hierarchy -top {top} " + " ".join(f"-chparam {k} {v}" for k, v in p.items()) + "; "


def label(p: dict) -> str:
    g = lambda k, d: p.get(k, d)  # noqa: E731
    s = (f"{g('ARRAY_ROWS', 4)}x{g('ARRAY_COLS', 4)} WB{g('WORD_BYTES', 4)} A{g('A_SET_BYTES', 4096) // 1024}K/{g('A_BANKS', 4)}b "
         f"B{g('B_SET_BYTES', 4096) // 1024}K/{g('B_BANKS', 2)}b {'DB' if g('NUM_SETS', 2) == 2 else 'SB'}"
         f"{'-SPLIT' if g('SET_MAP', 0) == 1 and g('NUM_SETS', 2) == 2 else ''} {'1RW' if g('PORT_MODE', 1) == 0 else '1R1W'}")
    if g("A_REPL", 1) > 1:
        s += f" REPL{g('A_REPL', 1)}"
    if g("READ_LATENCY", 1) > 1:
        s += f" RL{g('READ_LATENCY', 1)}"
    if g("PERF_EN", 1) == 0:
        s += " noPerf"
    return s


def geometry(p: dict) -> dict:
    g = lambda k, d: p.get(k, d)  # noqa: E731
    wb, ns, split = g("WORD_BYTES", 4), g("NUM_SETS", 2), g("SET_MAP", 0) == 1 and g("NUM_SETS", 2) == 2
    grp = 2 if split else 1
    out = {}
    for x, sb, nb, rep in [("A", g("A_SET_BYTES", 4096), g("A_BANKS", 4), g("A_REPL", 1)), ("B", g("B_SET_BYTES", 4096), g("B_BANKS", 2), 1)]:
        out[x] = {"banks": grp * nb * rep, "depth": (sb // wb // nb) * (1 if split else ns), "width": wb * 8}
    out["stored_bits"] = sum(out[x]["banks"] * out[x]["depth"] * out[x]["width"] for x in "AB")
    out["operand_bytes"] = (g("A_SET_BYTES", 4096) * g("A_REPL", 1) + g("B_SET_BYTES", 4096)) * ns
    return out


def cell_counts(log: str) -> dict:
    blocks = log.split("Number of cells:")
    if len(blocks) < 2:
        return {}
    last = blocks[-1]
    out = {"_total": int(re.match(r"\s*(\d+)", last).group(1))}
    for m in re.finditer(r"^\s+(\S+)\s+(\d+)\s*$", last, re.M):
        out[m.group(1)] = int(m.group(2))
    return out


def jobdir(kind: str, p: dict, extra: str = "") -> Path:
    d = BUILD / "synth" / (kind + "_" + re.sub(r"\W+", "_", label(p) + extra))
    d.mkdir(parents=True, exist_ok=True)
    return d


BASE = dict()
GENERIC = [dict(), dict(NUM_SETS=1, A_BANKS=1, B_BANKS=1), dict(PORT_MODE=0), dict(SET_MAP=1), dict(A_REPL=2),
           dict(ARRAY_ROWS=8, ARRAY_COLS=8, A_BANKS=8, B_BANKS=4)]

XC7 = ("synth_xilinx -family xc7", r"RAMB(18|36)E1", {"RAMB36E1": 1, "RAMB18E1": 0.5})
ECP5 = ("synth_ecp5", r"DP16KD|PDPW16KD", {"DP16KD": 1, "PDPW16KD": 1})
ICE40 = ("synth_ice40", r"SB_RAM40_4K", {"SB_RAM40_4K": 1})
FPGA = [
    (XC7, dict(BACKEND=1)),                                                      # baseline: 4x4, 2 x (4 KiB A + 4 KiB B)
    (XC7, dict(BACKEND=1, NUM_SETS=1, A_BANKS=1, B_BANKS=1)),                    # stage-1 single buffer, single bank
    (XC7, dict(BACKEND=1, NUM_SETS=1)),                                          # stage-2 single buffer, banked
    (XC7, dict(BACKEND=1, PORT_MODE=0)),
    (XC7, dict(BACKEND=1, SET_MAP=1)),
    (XC7, dict(BACKEND=1, A_REPL=2)),
    (XC7, dict(BACKEND=1, PERF_EN=0)),
    (XC7, dict(BACKEND=1, A_SET_BYTES=16384, B_SET_BYTES=16384)),                # 64 KiB of operands
    (XC7, dict(BACKEND=1, ARRAY_ROWS=8, ARRAY_COLS=8, A_BANKS=8, B_BANKS=4, A_SET_BYTES=8192, B_SET_BYTES=8192)),
    (XC7, dict(BACKEND=1, ARRAY_ROWS=16, ARRAY_COLS=16, WORD_BYTES=8, A_BANKS=8, B_BANKS=4, A_SET_BYTES=16384, B_SET_BYTES=16384)),
    (ECP5, dict(BACKEND=1)),
    (ECP5, dict(BACKEND=1, PORT_MODE=0)),
    (ICE40, dict(BACKEND=1, A_SET_BYTES=2048, B_SET_BYTES=2048)),
]

# (params, macro module, words, width, macro id)
SKY_32x512 = ("sky130_sram_2kbyte_1rw1r_32x512_8", 512, 32, 2)
SKY_32x256 = ("sky130_sram_1kbyte_1rw1r_32x256_8", 256, 32, 1)
IHP1P_512x32 = ("RM_IHPSG13_1P_512x32_c2_bm_bist", 512, 32, 34)
IHP1P_256x32 = ("RM_IHPSG13_1P_256x32_c2_bm_bist", 256, 32, 27)
IHP2P_512x32 = ("RM_IHPSG13_2P_512x32_c2_bm_bist", 512, 32, 66)
GF180_8x512 = ("gf180mcu_fd_ip_sram__sram512x8m8wm1", 512, 8, 13)
ASIC = [
    (dict(PORT_MODE=1), SKY_32x512),                                # 1R1W on SKY130 OpenRAM 1RW1R
    (dict(PORT_MODE=1, SET_MAP=1), SKY_32x256),
    (dict(PORT_MODE=1), IHP2P_512x32),                              # 1R1W on IHP SG13G2 true dual port
    (dict(PORT_MODE=0), IHP1P_512x32),                              # 1RW on IHP SG13G2 single port
    (dict(PORT_MODE=0, SET_MAP=1), IHP1P_256x32),
    (dict(PORT_MODE=0), GF180_8x512),                               # 1RW on GF180MCU byte-wide macros
    (dict(PORT_MODE=1, PERF_EN=0), SKY_32x512),
]

PNR = [  # (family, params, device args, label)
    ("ecp5", dict(BACKEND=1), ["--25k", "--package", "CABGA256", "--speed", "6"], "LFE5U-25F-6 CABGA256"),
    ("ecp5", dict(BACKEND=1, PORT_MODE=0), ["--25k", "--package", "CABGA256", "--speed", "6"], "LFE5U-25F-6 CABGA256"),
    ("ecp5", dict(BACKEND=1, ARRAY_ROWS=8, ARRAY_COLS=8, A_BANKS=8, B_BANKS=4, A_SET_BYTES=8192, B_SET_BYTES=8192),
     ["--25k", "--package", "CABGA256", "--speed", "6"], "LFE5U-25F-6 CABGA256"),
    ("ice40", dict(BACKEND=1, A_SET_BYTES=2048, B_SET_BYTES=2048, PERF_EN=0), ["--hx8k", "--package", "ct256"], "iCE40-HX8K CT256"),
]


def job_generic(p: dict) -> dict:
    d = jobdir("generic", p)
    geo = geometry(p)
    nphys = geo["A"]["banks"] + geo["B"]["banks"]
    ys = (f"{reads()}; {chparam(TOP, p)}proc; flatten; opt_clean; select -assert-none t:$dlatch t:$adlatch; "
          f"memory -nomap; opt_clean; stat")
    rc, out, dt = run(["yosys", "-q", "-l", d / "yosys.log", "-p", ys], cwd=d, timeout=3600)
    log = (d / "yosys.log").read_text() if (d / "yosys.log").exists() else out
    cc = cell_counts(log)
    # inferred memories with their sizes (yosys 'memory -nomap' leaves one $mem_v2 per array)
    rc2, out2, _ = run(["yosys", "-q", "-p", f"{reads()}; {chparam(TOP, p)}proc; flatten; opt_clean; memory -nomap; opt_clean; "
                        f"select -list t:$mem_v2; tee -o {d / 'mems.txt'} dump t:$mem_v2"], cwd=d, timeout=3600)
    txt = (d / "mems.txt").read_text() if (d / "mems.txt").exists() else ""
    sizes, widths = re.findall(r"parameter \\SIZE (\d+)", txt), re.findall(r"parameter \\WIDTH (\d+)", txt)
    mems = [(int(s), int(w)) for s, w in zip(sizes, widths)]
    banks = [m for m in mems if m[0] in (geo["A"]["depth"], geo["B"]["depth"]) and m[1] == geo["A"]["width"]]
    ok = rc == 0 and rc2 == 0 and len(banks) == nphys
    return {"suite": "generic", "label": label(p), "params": p, "rc": rc, "latches": 0 if rc == 0 else None,
            "inferred_memories": mems, "bank_memories": len(banks), "expected_bank_memories": nphys,
            "cells": cc.get("_total"), "result": "PASS" if ok else "FAIL", "seconds": round(dt, 1)}


def job_fpga(flow, p: dict) -> dict:
    cmd, prim, eqw = flow
    d = jobdir("fpga_" + cmd.split()[0], p)
    ys = f"{reads()}; {chparam(TOP, p)}{cmd} -top {TOP}; select -assert-none t:$mem t:$mem_v2; stat"
    rc, out, dt = run(["yosys", "-q", "-l", d / "yosys.log", "-p", ys], cwd=d, timeout=7200)
    log = (d / "yosys.log").read_text() if (d / "yosys.log").exists() else out
    cc = cell_counts(log)
    prims = {k: v for k, v in cc.items() if re.fullmatch(prim, k)}
    luts = sum(v for k, v in cc.items() if re.match(r"(LUT\d|SB_LUT4|LUT4)$", k))
    ffs = sum(v for k, v in cc.items() if re.match(r"(FD[A-Z]*|SB_DFF\w*|TRELLIS_FF)$", k))
    dsp = sum(v for k, v in cc.items() if re.match(r"(DSP48E1|MULT18X18D|SB_MAC16)$", k))
    carry = sum(v for k, v in cc.items() if re.match(r"(CARRY4|CCU2C|SB_CARRY)$", k))
    lutram = sum(v for k, v in cc.items() if re.match(r"(RAM\d+[XM]\d*\w*|DPR16X4|TRELLIS_DPR16X4)$", k))
    geo = geometry(p)
    eq = sum(v * eqw.get(k, 1) for k, v in prims.items())
    return {"suite": "fpga", "flow": cmd, "label": label(p), "params": p, "rc": rc, "seconds": round(dt, 1),
            "ram_primitives": prims, "ram_equiv": eq, "luts": luts, "ffs": ffs, "dsp": dsp, "carry": carry,
            "lutram_cells": lutram, "stored_kbit": geo["stored_bits"] / 1024, "cells_total": cc.get("_total"),
            "result": "PASS" if rc == 0 and eq > 0 else "FAIL", "log_tail": "" if rc == 0 else log[-1200:]}


def job_asic(p: dict, macro) -> dict:
    name, words, width, mid = macro
    geo = geometry(p)
    expected = sum(geo[x]["banks"] * math.ceil(geo[x]["depth"] / words) * math.ceil(geo[x]["width"] / width) for x in "AB")
    q = dict(p, BACKEND=2, MACRO_A=mid, MACRO_B=mid)
    d = jobdir("asic", q, "_" + name)
    ys = (f"{reads(stubs=True)}; {chparam(TOP, q)}synth -top {TOP} -flatten; select -assert-count {expected} t:{name}; "
          f"select -assert-none t:$mem t:$mem_v2; select -assert-none t:$_DLATCH*; stat")
    rc, out, dt = run(["yosys", "-q", "-l", d / "yosys.log", "-p", ys], cwd=d, timeout=7200)
    log = (d / "yosys.log").read_text() if (d / "yosys.log").exists() else out
    cc = cell_counts(log)
    found = cc.get(name, 0)
    ffs = sum(v for k, v in cc.items() if "DFF" in k)
    return {"suite": "asic", "label": label(q), "params": q, "macro": name, "macro_geometry": f"{words}x{width}",
            "expected_instances": expected, "found_instances": found, "logic_cells": (cc.get("_total") or 0) - found,
            "logic_flip_flops": ffs, "rc": rc, "seconds": round(dt, 1),
            "result": "PASS" if rc == 0 and found == expected else "FAIL", "log_tail": "" if rc == 0 else log[-1200:]}


def job_pnr(fam: str, p: dict, dev: list, devlabel: str) -> dict:
    d = jobdir("pnr_" + fam, p)
    wp = {k: v for k, v in p.items()}
    json_out = d / "wrap.json"
    synth = "synth_ecp5" if fam == "ecp5" else "synth_ice40"
    ys = f"{reads(extra=[WRAP])}; {chparam('tob_pnr_wrap', wp)}{synth} -top tob_pnr_wrap -json {json_out}; stat"
    rc, out, dt = run(["yosys", "-q", "-l", d / "yosys.log", "-p", ys], cwd=d, timeout=7200)
    res = {"suite": "pnr", "family": fam, "device": devlabel, "label": label(p), "params": p, "synth_rc": rc}
    if rc != 0:
        res.update(result="FAIL", log_tail=((d / "yosys.log").read_text()[-1200:] if (d / "yosys.log").exists() else out[-1200:]))
        return res
    tool = "nextpnr-ecp5" if fam == "ecp5" else "nextpnr-ice40"
    cmd = [tool, *dev, "--json", json_out, "--report", d / "report.json", "--freq", "50", "--seed", "1", "--placer", "heap",
           "--timing-allow-fail"]
    if fam == "ecp5":
        cmd += ["--textcfg", d / "out.config", "--lpf-allow-unconstrained"]
    else:
        cmd += ["--asc", d / "out.asc", "--pcf-allow-unconstrained"]
    rc2, out2, dt2 = run(cmd, cwd=d, timeout=7200)
    (d / "nextpnr.log").write_text(out2)
    res["pnr_rc"] = rc2
    res["seconds"] = round(dt + dt2, 1)
    if rc2 != 0 or not (d / "report.json").exists():
        res.update(result="FAIL", log_tail=out2[-1500:])
        return res
    rep = json.loads((d / "report.json").read_text())
    res["utilisation"] = {k: v for k, v in rep.get("utilization", {}).items() if v.get("used", 0) > 0}
    res["fmax_mhz"] = {k: round(v.get("achieved", 0), 2) for k, v in rep.get("fmax", {}).items()}
    crit = re.findall(r"Max frequency for clock\s+'([^']+)':\s+([\d.]+) MHz", out2)
    res["fmax_log"] = crit[-1] if crit else None
    # where the critical path lives: the source files nextpnr names in its critical-path report
    cp = out2.split("Critical path report for clock")[-1].split("Max frequency")[0] if "Critical path report" in out2 else ""
    res["critical_path_sources"] = sorted({m.split("/")[-1] for m in re.findall(r"(\S+\.sv):\d+", cp)})
    res["result"] = "PASS"
    return res


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", default="generic,fpga,pnr,asic")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--merge", action="store_true", help="keep the other suites' results from reports/synth.json")
    a = ap.parse_args()
    suites = a.suite.split(",")
    futs = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        if "generic" in suites:
            futs += [ex.submit(job_generic, p) for p in GENERIC]
        if "fpga" in suites:
            futs += [ex.submit(job_fpga, f, p) for f, p in FPGA]
        if "pnr" in suites:
            futs += [ex.submit(job_pnr, *x) for x in PNR]
        if "asic" in suites:
            futs += [ex.submit(job_asic, p, m) for p, m in ASIC]
        res = [f.result() for f in futs]
    if a.merge and (REPORTS / "synth.json").exists():
        old = json.loads((REPORTS / "synth.json").read_text())["results"]
        res = [r for r in old if r["suite"] not in suites] + res
    write_json(REPORTS / "synth.json", {"provenance": provenance(), "results": res})
    write_md(res)
    bad = [r for r in res if r["result"] != "PASS"]
    for r in bad:
        print("FAIL", r["suite"], r["label"], r.get("log_tail", "")[-600:])
    print(f"{len(res) - len(bad)}/{len(res)} PASS")
    return 0 if not bad else 1


def write_md(res) -> None:
    L = ["# Synthesis and place-and-route resource report", "",
         "Every number below comes from an actual Yosys / nextpnr run (`scripts/run_synth.py`, logs under `build/synth/`).",
         "What is NOT claimed: no Vivado/Quartus/Radiant run, no timing for Xilinx (synthesis only), no ASIC timing, power or",
         "area (no Liberty/LEF flow: ASIC rows are macro-integrity checks plus generic-gate cell counts).  FPGA block-RAM",
         "counts and FPGA Fmax do not predict ASIC SRAM macro area or access time.", ""]
    g = [r for r in res if r["suite"] == "generic"]
    if g:
        L += ["## Generic synthesis: latch check and memory inference", "",
              "| configuration | physical banks (expected) | bank arrays inferred | all inferred memories (depth x width) | latches | cells | result |",
              "|---|---|---|---|---|---|---|"]
        for r in g:
            mm = ", ".join(f"{s}x{w}" for s, w in r["inferred_memories"])
            L.append(f"| {r['label']} | {r['expected_bank_memories']} | {r['bank_memories']} | {mm} | {r['latches']} | {r['cells']} | {r['result']} |")
        L.append("")
    f = [r for r in res if r["suite"] == "fpga"]
    if f:
        L += ["## FPGA synthesis (Yosys, BACKEND = FPGA block-RAM inference)", "",
              "| flow | configuration | stored Kbit | RAM primitives | LUTs | FFs | DSP/MULT | carry | LUT-RAM | $mem left | result |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
        for r in f:
            prims = ", ".join(f"{v}x {k}" for k, v in sorted(r["ram_primitives"].items()))
            L.append(f"| {r['flow'].split()[0]} | {r['label']} | {r['stored_kbit']:.0f} | {prims} | {r['luts']} | {r['ffs']} | {r['dsp']} | "
                     f"{r['carry']} | {r['lutram_cells']} | {'0' if r['rc'] == 0 else '?'} | {r['result']} |")
        L.append("")
    p = [r for r in res if r["suite"] == "pnr"]
    if p:
        L += ["## Place and route (nextpnr), buffer inside the I/O measurement wrapper", "",
              "| device | configuration | utilisation (used / available) | Fmax (nextpnr timing) | critical path through | result |", "|---|---|---|---|---|---|"]
        for r in p:
            u = "; ".join(f"{k} {v['used']}/{v['available']}" for k, v in sorted(r.get("utilisation", {}).items()))
            fm = ", ".join(f"{k}: {v} MHz" for k, v in r.get("fmax_mhz", {}).items())
            L.append(f"| {r['device']} | {r['label']} | {u} | {fm} | {', '.join(r.get('critical_path_sources', []))} | {r['result']} |")
        L.append("")
    s = [r for r in res if r["suite"] == "asic"]
    if s:
        L += ["## ASIC macro integration (Yosys, BACKEND = ASIC, black-box macros)", "",
              "| configuration | macro | expected | found | buffer logic cells (generic gates) | flip-flops | result |",
              "|---|---|---|---|---|---|---|"]
        for r in s:
            L.append(f"| {r['label']} | {r['macro']} ({r['macro_geometry']}) | {r['expected_instances']} | {r['found_instances']} | "
                     f"{r['logic_cells']} | {r['logic_flip_flops']} | {r['result']} |")
        L.append("")
    (REPORTS / "synth.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
