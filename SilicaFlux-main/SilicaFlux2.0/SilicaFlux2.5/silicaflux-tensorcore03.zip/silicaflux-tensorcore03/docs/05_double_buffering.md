# 05 — Single buffer, ping-pong double buffering and ownership

## 1. Ownership is explicit

Each set (an A region plus a B region) carries a 2-bit owner state (`set_state`), changed only by four
valid/ready commands:

```
          fill_begin            fill_end                cmp_begin              cmp_end
 EMPTY ───────────────► FILL ─────────────► READY ─────────────────► COMPUTE ────────────► EMPTY
        (next fill set)   DMA may write      valid, nobody owns it    tiles may read         (next compute set)
                          tiles refused      writes refused           writes refused (OWNER)
```

| Command | Accepted when (ready) | Effect |
|---|---|---|
| `fill_begin` | `state[fill_set] == EMPTY` | FILL: DMA writes to that set are performed |
| `fill_end` | `state[fill_set] == FILL` **and no DMA request is held in the port** | READY; `fill_set` advances (mod NUM_SETS). Every write issued before `fill_end` is in the array; a later write gets OWNER |
| `cmp_begin` | `state[cmp_set] == READY` | COMPUTE: tiles on this set are accepted |
| `cmp_end` | `state[cmp_set] == COMPUTE` **and the operand engine is drained** (no tile being validated, queued, fetched, staged or held in the output register) | EMPTY; `cmp_set` advances. Every operand of the set has been delivered |

A pending `cmp_end` (valid high) blocks new tiles (`tile_ready = 0`). A command whose precondition is false
simply waits; it is never dropped. The preconditions on one set are mutually exclusive, so at most one transition
happens per set per cycle.

**Preventing overwrite of operands in use:** a DMA write is performed only if its target set is in FILL. A set
being read is in COMPUTE, and only `cmp_end` can take it out of COMPUTE, which requires every slice to have been
delivered. A write into a set in use is therefore refused with OWNER and has no side effect. `t_owner` checks this,
and then checks that the set is byte-exact unchanged.

## 2. Operation

**Single buffer (`NUM_SETS = 1`)** — the stage-1 implementation. The same states serialise the work:
fill_begin → DMA writes → fill_end → cmp_begin → tiles → cmp_end → fill_begin … No overlap is possible or claimed.

**Ping-pong (`NUM_SETS = 2`)**, the intended operation:

```
 fill_begin(0)  DMA → set 0  fill_end(0)
 cmp_begin(0)   tiles on set 0 ...................... cmp_end(0)
                fill_begin(1)  DMA → set 1  fill_end(1)
                                                      cmp_begin(1)  tiles on set 1 .......... cmp_end(1)
                                                      fill_begin(0) DMA → set 0  fill_end(0)
```
Sets are used in strict alternation: `fill_set` and `cmp_set` are pointers that advance at `fill_end` and
`cmp_end`. `SET_MAP` decides whether the two sets share physical banks (SHARED: set = row MSB, fewest BRAMs; fill
and compute contend for ports under 1RW) or have their own (SPLIT: twice the banks at half the depth; no
contention even with single-port macros).

## 3. Overlap is measured, not assumed

The event `OVERLAP` counts the cycles in which a DMA write is performed *and* a slice is delivered. The testbench
(`t_contention`, `t_switch`, `t_rdw`) and the integration test require it to be non-zero in double-buffered runs.
The integration test also runs the same problem sequence twice, once overlapped and once serialised, and requires
both to be bit-exact against the reference matmul. Measured overlap cycles and speed-ups are in
`reports/regression.md` (integ rows) and `reports/perf.md` (DMA overlap group). Doc 03 §5 discusses them.
