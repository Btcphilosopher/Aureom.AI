# 10 — Status, limitations and next actions

## 1. Definition of done

> *The operand system supplies correctly aligned matrix data and accurately reports stalls under its real
> memory-port limitations.*

* **Correctly aligned matrix data.** Every slice of every test is compared field by field with a byte-accurate
  reference, under random back-pressure and poisoned SRAM outputs, in two simulators. End to end, the TENSORCORE 02
  array computes bit-exact C (196 tiles per problem set, partial tiles and K splits), and its own index and
  alignment checks never fire.
* **Real memory-port limitations.** Each physical bank is a SRAM Wrapper Library backend with a 1RW or 1R1W port
  model that is never exceeded (assertions plus testbench monitors). A bank delivers one word per cycle, and
  bandwidth comes only from banking, staging and replication.
* **Stalls accurately reported.** Operand starvation (split into A and B), bank conflicts, read stalls, write
  stalls, forced writes, reads blocked by writes, array back-pressure and DMA/compute overlap are all exported as
  `ev_inc` and counted. Every counter equals the sum of its event and independent counts, and the counters agree
  with the analytical model on 44 / 44 measured points.

## 2. Limitations (stated plainly)

* **Simulation and synthesis only.** No FPGA board run, no gate-level simulation, no formal proof of the new RTL.
  The measured Fmax is modest (ECP5-6: 40.3 MHz baseline, 28.2 MHz 8×8). The limiting paths are the event/counter
  logic and the DMA decode, not the operand path (doc 09).
  FPGA timing comes from nextpnr on ECP5 / iCE40 only (Xilinx: Yosys synthesis counts, no timing). There are no
  ASIC area, timing or power numbers. ASIC rows prove macro integration only.
* The DMA fill port is write-only. Read-back of operands goes through the slice path, not the DMA port.
* One tile context is fetched at a time: the next tile's fetch starts after the current tile's last request,
  leaving a measured 2-cycle gap between back-to-back tiles. This is hidden behind the array's DRAIN/READOUT time.
* With the default `A_STAGE = 2`, dense row-major A with K a multiple of WB·A_BANKS (for example K = 256) runs at
  0.892 of the full rate on the baseline. The cure (pad lda, or `A_STAGE = 4`) is measured, but nothing applies it
  automatically.
* `WR_STARVE_LIMIT = 0` (write priority) gives the reads no guarantee under 1RW. Use a non-zero limit or 1R1W /
  SPLIT when compute must keep its rate.
* Ping-pong order is fixed (strict alternation). Out-of-order use of sets is not supported.
* The Module 05 adapter (`hpc_dma_spm_port`) and the Module 07 counter bank are protocol-compatible by design
  (doc 00), but are not instantiated in a simulation here.

## 3. Prioritised next actions

1. Timing (doc 09 §2): add a register stage on `ev_inc` in front of `tob_perf` (counters then lag by one
   cycle), pre-decode the DMA address when the request is accepted, and split the AGU multiply over two cycles.
   These are the three critical paths nextpnr reports (40.3 MHz on ECP5-6 for the baseline). No gain is claimed
   until the flow has been rerun.
2. Connect Module 05 (`hpc_dma_adapter` + `hpc_dma_spm_port`) to the fill port and Module 07
   (`hpc_perf_counters.inc_i`) to `ev_inc` in a tile-level integration test.
3. Board bring-up on an ECP5 (LFE5U-25F) with the P&R wrapper replaced by the real tile I/O, and timing closure
   at the measured Fmax.
4. Optional software-side padding helper: choose lda so lda/WB is odd (doc 03 §5), or a parameterised automatic
   `A_STAGE` sizing rule.
5. Overlapped multi-context fetch (start tile t+1's A lanes per lane as soon as each finishes tile t) if
   back-to-back tiles without an array drain ever matter.
6. ASIC: generate exact-geometry macros for the chosen node and run an OpenROAD flow for area and timing; the
   FPGA numbers here must not be used for that.
