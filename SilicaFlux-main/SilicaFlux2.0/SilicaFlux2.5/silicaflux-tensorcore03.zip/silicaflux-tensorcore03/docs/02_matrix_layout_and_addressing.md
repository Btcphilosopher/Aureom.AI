# 02 — Matrix layout, address calculation and checks

Every address in this module is a **byte** address. Elements are INT8, so element index and byte offset coincide.

## 1. Matrix contract (row-major)

```
A (mat_m × mat_k):  A[r][c]  at  a_addr + r·lda + c        lda ≥ mat_k   (leading dimension / row stride, bytes)
B (mat_k × mat_n):  B[r][c]  at  b_addr + r·ldb + c        ldb ≥ mat_n
```
`a_addr` and `b_addr` are relative to the start of the compute set's A region and B region respectively.

A tile has an origin `(m0, n0)`, a reduction start `k0`, and a length `tile_k`:

```
eff_m = min(ARRAY_ROWS, mat_m − m0)     row mask    s_row_mask[i] = i < eff_m
eff_n = min(ARRAY_COLS, mat_n − n0)     column mask s_col_mask[j] = j < eff_n
eff_k = min(tile_k,     mat_k − k0)     number of k-slices
slice k (0 ≤ k < eff_k):
   s_a[i] = A[m0+i][k0+k]   = byte  a_addr + (m0+i)·lda + k0 + k      (i < eff_m, else 0)
   s_b[j] = B[k0+k][n0+j]   = byte  b_addr + (k0+k)·ldb + n0 + j      (j < eff_n, else 0)
   s_k = k,  s_kg = k0 + k,  s_m0 = m0,  s_n0 = n0,  s_first = (k == 0),  s_last = (k == eff_k − 1)
```
Partial tiles (matrix edges) and K splits (several tiles over one output block, partial sums accumulated outside)
are therefore plain descriptors. Both are exercised in `t_partial` and in the integration test (`K = 128` in chunks
of 32).

## 2. Validation (tob_tile_agu), first match wins

| Code | Name | Condition |
|---|---|---|
| 7 | OWNER | no set in COMPUTE state (tile refused before any arithmetic) |
| 1 | EMPTY | `tile_k = 0`, or `m0 ≥ mat_m`, `n0 ≥ mat_n`, `k0 ≥ mat_k` |
| 2 | LD | `lda < mat_k` or `ldb < mat_n` |
| 3 | A_OVF | Alast = a + (m0+eff_m−1)·lda + k0 + eff_k − 1 ≥ 2^ADDR_W |
| 4 | A_RANGE | Alast ≥ A_SET_BYTES |
| 5 | B_OVF | Blast = b + (k0+eff_k−1)·ldb + n0 + eff_n − 1 ≥ 2^ADDR_W |
| 6 | B_RANGE | Blast ≥ B_SET_BYTES |

The arithmetic is `ADDR_W + max(IDX_W, K_W) + 3` bits wide (52 bits by default), which no input can overflow. So
an overflow is *detected*, never silently wrapped. Since lda, ldb ≥ 0, the last byte of A and of B is the
largest address the tile touches, and checking it bounds every access. An error tile is answered on the tile
response channel in order, produces no slice, and performs no memory access. Every boundary case (last byte equal to
`SET_BYTES − 1` accepted, `SET_BYTES` refused, a single byte at 2^ADDR_W − 1, products ≥ 2^ADDR_W) is in `t_range`.

## 3. DMA window (tob_dma_port)

```
offset = byte address − DMA_BASE,   X_TOTAL = NUM_SETS · X_SET_BYTES,   REGION = max(A_TOTAL, B_TOTAL)
[0, A_TOTAL)                    A region:  set = offset / A_SET_BYTES, in-set byte = offset mod A_SET_BYTES
[A_TOTAL, REGION)               hole       → RANGE
[REGION, REGION + B_TOTAL)      B region:  set = (offset − REGION) / B_SET_BYTES
below DMA_BASE or above         → RANGE
```
Byte lane l of a word = `wdata[8l +: 8]`, enabled by `wstrb[l]` (little endian, the SFB2 / Module 04 convention).
Checks, first match wins: RANGE (1) > ALIGN (2, offset not word-aligned) > UNSUP (7, read request) > OWNER (6, the
target set is not in FILL). No error has a side effect. Codes 0..2 have the Module 04 meaning; 6 and 7 use Module
04's reserved codes.

## 4. Mapping to physical banks

```
word w   = in-set byte / WB            byte lane = in-set byte mod WB
bank     = w mod BANKS                 (word interleaving: consecutive words → consecutive banks)
row      = w / BANKS
physical row  = SHARED, NUM_SETS = 2 : {set, row}   (the set is the row MSB)
                otherwise            : row
physical bank = ((group · A_REPL) + replica) · A_BANKS + bank     group = set if SPLIT else 0
                (B: group · B_BANKS + bank)
```
A DMA write to A word w goes to *all* replicas of its bank in the same cycle. A lane reads replica `i mod A_REPL`.
Word interleaving puts the 1..⌈(C+WB−1)/WB⌉ words of a B row in distinct banks. Whether the R lanes of an A
tile hit distinct banks depends on the word stride lda/WB; this is the central bandwidth question of doc 03.
