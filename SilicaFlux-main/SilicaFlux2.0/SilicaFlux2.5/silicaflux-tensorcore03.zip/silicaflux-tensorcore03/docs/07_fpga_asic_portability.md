# 07 — FPGA and ASIC portability

Every physical bank is one SRAM Wrapper Library raw backend (`tob_bank` → `sram_backend_1rw` /
`sram_backend_1r1w`), selected by `BACKEND`:

| `BACKEND` | Implementation | Use |
|---|---|---|
| GENERIC | behavioural array (`SRAMLIB_POISON`: read data is X outside its valid cycle) | simulation, logic synthesis |
| FPGA | block-RAM inference templates (no vendor IP) | FPGA boards: `synth_xilinx`, `synth_ecp5`, `synth_ice40` map every bank to RAM primitives (`reports/synth.md`) |
| ASIC | real open-PDK macros tiled by `sram_asic_array`, selected by `MACRO_A` / `MACRO_B`; never a flip-flop fallback | SKY130 OpenRAM 1RW1R (→ 1R1W), IHP SG13G2 1P (→ 1RW) and 2P (→ 1R1W), GF180MCU 1RW byte-wide |

**ASIC integration point.** Set `BACKEND = ASIC`, choose a macro whose port topology matches `PORT_MODE` (the
library rejects 1R1W on a single-port macro), and set `READ_LATENCY` ≥ the macro's native latency (1 for every
catalogue macro; extra stages are flops). Use `SET_MAP = SPLIT` with single-port macros if DMA fill and compute
must not share ports. For a commercial node, add the compiler's macro through the library's manifest flow
(`third_party/silicaflux-sramlib/README.md`). The commercial placeholders deliberately fail elaboration.

**What the FPGA numbers do not say.** FPGA block-RAM counts, LUT counts and nextpnr Fmax describe that FPGA only.
An ASIC SRAM macro's area, access time, minimum cycle, read-during-write behaviour and power come from the
macro's datasheet and Liberty/LEF views, which are not used here. The ASIC rows of `reports/synth.md` check only that
the exact number of real macros survives synthesis and that no array became flip-flops. Their cell counts are Yosys
generic gates for the control/datapath logic, not silicon area. In particular:

* a BRAM is 18/36 Kbit with fixed aspect ratios; an ASIC macro can be generated at the exact depth and width;
* FPGA BRAMs here have one-cycle reads with an output register; macro access time limits the ASIC clock (not the
  logic depth measured on the FPGA);
* 1R1W is free on FPGA (simple-dual-port mode); on ASIC it needs a two-port macro (larger cell) or, with
  single-port macros, `SET_MAP = SPLIT` / the 1RW arbitration.
