# 03 — Operand bandwidth analysis

All measured numbers come from `reports/perf.md`: cycle-accurate RTL simulation, 8 back-to-back full tiles of
K = 256 per point, the array never back-pressuring, and every slice checked. **In-tile rate** = k-slices per cycle
while a tile streams; 1.000 means R A-operands + C B-operands every cycle.

## 1. Demand

An R×C output-stationary array consumes one k-slice per cycle: **R A operands** (`A[m0+i][k0+k]`, one per array
row) and **C B operands** (`B[k0+k][n0+j]`, one per column). That is R + C bytes per cycle for INT8: 8 B/cycle at
4×4, 16 at 8×8, 32 at 16×16.

## 2. Supply: what one SRAM really delivers

One physical bank port delivers **one word of WB bytes per cycle**. Under 1RW that single port is also the DMA's
write port. A single 32-bit single-port SRAM therefore supplies at most 4 B/cycle, shared by A, B and DMA, which is
half of even the 4×4 array's demand. Worse, with row-major A the R operands of one slice lie in R *different*
rows, so byte-by-byte access would need R reads per cycle for A alone. Bandwidth has to come from three
mechanisms, all of which this design implements and measures:

**(a) Per-lane staging turns R reads per cycle into R/WB.** Lane i reads whole words of its own row stream. A word
serves WB consecutive k-steps, so A needs R/WB words per cycle on average (1 word/cycle at 4×4 with 32-bit words).
The B row of a slice is contiguous: ⌈(off + C)/WB⌉ ≤ NWB = ⌊(C + 2·WB − 2)/WB⌋ words, which sit in consecutive,
hence distinct, banks.

**(b) Banking supplies the words in parallel**, provided the lanes that need a word in the same cycle sit in
different banks. Let L = the largest number of lanes sharing (replica, bank, byte phase) in one round:

```
deadline   (L − 1) + READ_LATENCY + 1 ≤ (A_STAGE − 1) · WB      the L requests of a round, served one per cycle,
                                                                 must return before the word is due
long run   L ≤ WB · A_BANKS                                      consecutive words rotate through the banks
B          beats = ⌈nw / B_BANKS⌉, rate ≤ 1 / beats; B_STAGE ≥ READ_LATENCY + 2 for one row per cycle
```
L is set by the word stride s = lda/WB. Lanes i and j share a bank when (i − j)·s ≡ 0 (mod A_BANKS).
* odd s and A_BANKS ≥ R → L = 1 (conflict-free);
* s ≡ 2 (mod 4) with 4 banks → L = 2;
* **s ≡ 0 (mod A_BANKS) → L = R: every lane in the same bank.** This is exactly the dense row-major case when K
  is a multiple of WB·A_BANKS, for example K = 256. It is the most common layout, and it is the worst one.

**(c) Replication and staging depth where justified.** `A_REPL` gives lane i its own copy (replica i mod A_REPL):
L divides by A_REPL, the cost is capacity × A_REPL, and DMA writes all copies in the same cycle (no extra write
bandwidth). Deeper staging (`A_STAGE`) widens the deadline window. Both are measured below against the cheaper
alternative: padding `lda` by WB bytes, which makes s odd.

## 3. Measurements versus the model

| Case (4×4, 32-bit words, 4 A banks, 2 B banks unless stated) | L | model | in-tile rate | operands / cycle |
|---|---|---|---|---|
| s = 65 (odd), s = 67 | 1 | full | **1.000** | 8.0 |
| s = 66 (≡ 2 mod 4) | 2 | full | **1.000** | 8.0 |
| **dense K = 256, s = 64** (A_STAGE = 2) | 4 | not full | **0.892** | 7.14 |
| same, A_STAGE = 4 | 4 | full | 1.000 | 8.0 |
| same, A_REPL = 2 / 4 | 2 / 1 | full | 1.000 / 1.000 | 8.0 |
| unaligned rows (lda = 257: all lanes one bank but different byte phases) | 1 | full | 1.000 | 8.0 |
| 1 A bank (s = 65) | 4 | not full | 0.892 | 7.14 |
| s = 64, A_STAGE = 2, READ_LATENCY 1 / 2 / 3 / 4 | 4 | not full | 0.892 / 0.805 / 0.734 / 0.674 | |
| s = 64, A_STAGE = 4, READ_LATENCY 1..4 | 4 | full | 1.000 (all) | |
| conflict-free, A_STAGE = 2, READ_LATENCY 1, 2, 3 / 4 | 1 | full / not | 1.000 / **0.892** | |
| B rows straddling two words, **1 B bank** (2 beats per row) | — | 0.50 | **0.501** | 4.01 |
| B rows with mixed offsets (ldb = 5), 1 B bank | — | not full | 0.571 | |
| any B alignment, 2 B banks | — | full | 1.000 | 8.0 |
| 8×8, 8 A banks, s = 65 | 1 | full | 1.000 | 16.0 |
| 8×8, s = 64, A_STAGE = 2 / 4 | 8 | not / full | 0.623 / 1.000 | 9.97 / 16.0 |
| 8×8, 64-bit words, s = 33 | 2 | full | 1.000 | 16.0 |
| 16×16, 32-bit words, 16 A banks, s = 65 | 1 | full | 1.000 | 32.0 |
| 16×16, 64-bit / 128-bit words | 2 / 4 | full | 1.000 / 1.000 | 32.0 |

The **model agrees with the RTL on 44 / 44 compute-only points.** For transparency: the first version of the model
disagreed on 3 of 37 points, all pessimistically. The causes were an off-by-one in the deadline inequality, a
long-run limit of WB instead of WB·A_BANKS, and ignored byte phase. The model was corrected from the derivation
(docstring of `model/tob_bw_model.py`), then validated on **7 held-out points whose predictions were recorded
before they were simulated** (4 full, 3 not full; all 7 correct). The regression additionally asserts zero
bubbles inside tiles (`+full_rate`) on every configuration where the model predicts full rate.

The full-rate assertion also found a real arbitration weakness. Plain round-robin left 1-cycle bubbles at tile
starts on a 16×16 array, because a prefetching lane could take the port from a lane that needed its next word.
Urgency-first arbitration (doc 04) removed them.

## 4. DMA fill concurrent with compute

DMA fills the other set at up to one word per cycle while tiles stream. The compute layout keeps both B banks read
every cycle (every B row straddles two words):

| Bank port model / sets | in-tile rate | DMA write stall cycles | overlap cycles (write + slice) |
|---|---|---|---|
| 1R1W, shared banks | **1.000** | 0 | 2021 |
| 1RW, shared, WR_STARVE_LIMIT 8 | 0.960 | 1044 | 1101 |
| 1RW, shared, WR_STARVE_LIMIT 2 | 0.854 | 1044 | 1013 |
| 1RW, shared, write priority (0) | 0.667 | 0 | 1004 |
| 1RW, **split** sets | **1.000** | 0 | 2021 |

With 1R1W (FPGA simple-dual-port BRAM, SKY130 1RW1R) the fill is free. With single-port macros, sharing the banks
costs compute bandwidth in proportion to how aggressively writes are prioritised, and the starvation limit is the
knob. SPLIT sets remove the contention at the price of twice the bank count at half the depth.

## 5. Sizing rules (from §2, validated in §3)

1. `B_BANKS ≥ ⌊(C + 2·WB − 2)/WB⌋` (2 at 4×4 with 32-bit words), `B_STAGE ≥ READ_LATENCY + 2`.
2. Pad `lda` so lda/WB is odd, and keep `A_BANKS·A_REPL ≥ R/WB`. That gives L = 1 and full rate with
   `A_STAGE = 2` for READ_LATENCY ≤ WB − 1.
3. If the layout cannot be padded (dense K multiple of WB·A_BANKS), raise `A_STAGE` so that
   (R − 1) + READ_LATENCY + 1 ≤ (A_STAGE − 1)·WB. This costs R·WB flip-flops per extra stage and keeps the
   capacity. Replication also works but multiplies the A capacity.
4. Prefer 1R1W banks (or SPLIT sets with 1RW macros) when DMA must overlap compute.
5. For the modest-FPGA baseline (4×4, 2 × 8 KiB) every rule holds except (3): dense K = 256 runs at 0.892 with
   the default `A_STAGE = 2`. Pad `lda` (or set `A_STAGE = 4`) for full rate.

## 6. Latency (idle buffer, conflict-free, measured)

| | 4×4 RL1 | 4×4 RL2 | 4×4 RL4 | 8×8 | 16×16 |
|---|---|---|---|---|---|
| DMA write accept → response | 2 | 2 | 2 | 2 | 2 |
| tile accept → tile response (= 8 + R) | 12 | 12 | 12 | 16 | 24 |
| tile accept → first slice (= R + RL + 11) | 16 | 17 | 19 | 20 | 28 |
| gap between back-to-back tiles | 2 | 2 | 2 | 2 | 2 |

The overall rate (slices / all cycles) of the baseline's 8 × 256-slice stream is 0.985. The difference from the
in-tile rate is the first tile's start-up and the 2-cycle gaps. In the integrated system both are hidden behind
the array's own DRAIN / READOUT time between tiles (doc 06).
