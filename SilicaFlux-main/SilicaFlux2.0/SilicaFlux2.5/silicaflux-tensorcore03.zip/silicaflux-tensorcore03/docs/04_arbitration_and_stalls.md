# 04 — Memory-port constraints, arbitration and stall signalling

## 1. What one physical bank can do (modelled, never exceeded)

| `PORT_MODE` | Per cycle | Backends / macros | Notes |
|---|---|---|---|
| 1RW | ONE access: a read OR a write | `sram_backend_1rw`: FPGA single-port BRAM, IHP SG13G2 1P, GF180MCU | DMA fill and compute reads share the port. |
| 1R1W | one read AND one write | `sram_backend_1r1w`: FPGA simple-dual-port BRAM, SKY130 OpenRAM 1RW1R, IHP 2P | A read and a write of the **same row** are never issued together (the cross-port behaviour of macros is undefined). |

The buffer never issues more than this. In the integrated design that is checked every cycle by assertions:
`tob_bank` (1RW: never read and write together), the top level (1R1W: never the same row), and the testbench, which
counts same-cycle read+write per bank (allowed only under 1R1W).

## 2. Requesters

* **A lanes** (R): each requests one word of its row stream. A request is **urgent** when the lane holds at most its
  head word (staged or in flight), i.e. its next word is needed within WB cycles. Otherwise it is a **prefetch**.
* **B fetcher** (1): one beat = up to `B_BANKS` consecutive words of a B row, in distinct banks. The beat is issued
  only if **every** involved bank grants (all-or-nothing), so all of a row's words return in the same cycle.
* **DMA write** (1 per cycle): one word, written to every replica of its bank in the same cycle (all-or-nothing
  across replicas).

## 3. Policy (deterministic)

```
per physical bank:
  hazard readers hz = all readers (1RW) | readers of the write's row (1R1W)
  wr_ok   = no write here | hz empty | wr_force                 (from requests only: no combinational loop)
  wr_go   = DMA write valid AND wr_ok at every target bank (all replicas)
  blocked = wr_go ? hz : none                                   (readers that yield to the write this cycle)
  cand    = urgent eligible readers if any, else all eligible readers     (eligible = readers − blocked)
  grant   = first of cand in round-robin order from the bank's pointer; pointer ← winner + 1
```
* **Compute first, bounded DMA wait.** A write waits while reads need its bank. The DMA port counts the cycles it
  has waited; at `WR_STARVE_LIMIT` it raises `wr_force`, and the write is granted in that cycle at every target
  bank, displacing the reads there. So a write waits at most `WR_STARVE_LIMIT` cycles (asserted in RTL and
  measured), and the reads of one bank lose at most 1 cycle in `WR_STARVE_LIMIT + 1` to writes.
  `WR_STARVE_LIMIT = 0` gives writes strict priority.
* **Urgent before prefetch.** Plain round-robin can give the port to a lane that is prefetching its third word while
  another lane on the same bank still lacks its next one. This happens at tile starts, when lanes are at different
  word indices. The model-gated full-rate assertion caught it on a 16×16 array as 1-cycle bubbles in 3 of 8 tiles.
  With the urgency class, that configuration runs bubble-free (`reports/regression.md`, `full_rate` rows).
* **Readers are starvation-free.** Within a class, round-robin from the bank's pointer (advanced past each winner)
  serves a continuously requesting urgent reader within (readers − 1) read grants of its bank. `tb_tob_bank_arb`
  measures this bound, and the buffer testbench bounds the urgent-request wait by 2R + 2 in every run. A prefetch
  request can wait longer, but becomes urgent as its staged words drain. Forced writes add at most one cycle per
  `WR_STARVE_LIMIT + 1`.
* Under 1R1W the write port is free whenever no same-row read is present. With the ownership rules, DMA and
  compute never touch the same set, so the hazard cannot occur in the integrated buffer; it is still guarded and
  is unit-tested in `tb_tob_bank_arb`. Under SPLIT the DMA set and the compute set use different physical banks
  even with 1RW macros.

## 4. Stall signalling

| Signal / event | Meaning |
|---|---|
| `dma_req_ready = 0` | Hold stage occupied by a write that has not been granted, or response credits exhausted |
| `ev WR_STALL` | A legal DMA write waited for a bank port this cycle |
| `ev WR_FORCED` | A DMA write was granted by the starvation limit and displaced a read |
| `ev A_RD_STALL` | Number of A lanes that requested and were not granted (conflict or write) |
| `ev B_RD_STALL` | The B beat requested and was not issued |
| `ev BANK_CONFLICT` | Physical banks with ≥ 2 eligible readers this cycle (one served, the rest wait) |
| `ev_bank_conflict_a[p]` | The same, per physical A bank |
| `ev RD_WR_BLOCK` | Readers blocked by a write (1RW, or a same-row hazard) |
| `ev STARVE` | **Operand starvation**: a tile is active and the output stage could take a slice, but staged operands are missing; split into `STARVE_A` (a live lane had no word) and `STARVE_B` (no B row) |
| `s_valid = 0` during a tile | The externally visible consequence of starvation (the array freezes; alignment is preserved) |
| `ev ARRAY_BP` | `s_valid && !s_ready`: the consumer back-pressures |
| `ev OVERLAP` | A DMA write was performed and a slice delivered in the same cycle (measured DMA/compute overlap) |

All events are multi-event increments in `ev_inc` (8 bits each), suitable for `hpc_perf_counters.inc_i` (Module
07). The local `tob_perf` bank counts them with saturation. The testbench checks every counter against the sum of
its `ev_inc` field, and checks slices, writes, errors, tiles, back-pressure cycles and A/B words read against
independently computed values.
