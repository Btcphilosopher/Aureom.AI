# 00 — Repository audit and reuse decisions

All prior SilicaFlux work lives in `btcphilosopher/Aureom.AI` as zip archives under
`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Each archive was extracted into an isolated
scratch directory and read before any line of this module was written. No repository file was modified, and this
module is delivered as a separate archive, not committed.

| Brief item | What exists (archive → path) | Status in the archive | Decision |
|---|---|---|---|
| SilicaFlux SRAM Wrapper Library | `SilicaFlux2.5/silicaflux-sramlib.zip` → `rtl/mem/` | Verified there: Verilator/Icarus/Yosys regression, formal, macro equivalence | **Reused unmodified** (`third_party/silicaflux-sramlib/`): raw `sram_backend_1rw` / `sram_backend_1r1w`, GENERIC / FPGA / ASIC backends, macro catalogue, black-box stubs. Every physical operand bank is one of these. |
| HPC scratchpad (Module 04) | `silicaflux-hpc-m04-scratchpad.zip` → `rtl/hpc_scratchpad.sv`, `hpc_spm_bank_arb.sv` | Verified there (staged regression, mutation, BRAM inference) | **Protocol and port-model rules reused; module not instantiated.** The DMA fill port speaks the `hpc_scratchpad` port protocol (codes 0–2 identical; 6 and 7 sit in Module 04's reserved range). Its per-bank rules (1RW / 1R1W, no same-row read+write in one cycle, round-robin past the first winner) are kept in `tob_bank_arb`. Why not use the scratchpad itself: it serves one word per port with tagged in-order responses. Feeding an R×C array would need R + ⌈C/WB⌉+1 ports, each with its own response FIFO. It also has no all-or-nothing multi-bank B read, no replica write, no compute-first write policy with a bound, and no set ownership. |
| Existing memory banks | Module 04 banks; `memory_controller.sf` (SilicaFlux 2.5) | — | Not suitable as operand storage, for the reasons above. Banks are built from the same sramlib backends Module 04 uses. |
| DMA / DataFabric interfaces | `silicaflux-hpc-m05-dma-adapter.zip` → `rtl/hpc_dma_adapter.sv`, `hpc_dma_spm_port.sv`; `silicaflux-datafabric.zip` | Verified there | The fill port is protocol-compatible with `hpc_dma_spm_port`: write acknowledged only after the array write, one response per request in order, `req_ready` independent of `rsp_ready`, tag and `we` echoed. The DataFabric `dma_fifo` is **reused unmodified** for every staging and response FIFO (SHA-256 identical to the DataFabric original). |
| FPGA BRAM wrappers | sramlib `backends/fpga/sram_fpga_{1rw,1r1w}.sv` | Yosys inference shown there | Reused (BACKEND = FPGA). |
| Real ASIC SRAM macro interfaces | sramlib `backends/asic/` + 34 manifests (SKY130 OpenRAM 1RW1R, GF180MCU 1RW, IHP SG13G2 1P/2P) | Pin-accurate black boxes, generated from vendor files | Reused (BACKEND = ASIC, `MACRO_A`/`MACRO_B`). No proprietary macro is used or assumed. |
| Consumer: systolic array | `silicaflux-tensorcore02.zip` → `rtl/tensor_systolic_array.sv` | Verified there | The contract this buffer must meet: one k-slice per handshake, `s_a = A[:,k]` (lane i = row i), `s_b = B[k,:]` (lane j = column j), unskewed (the array skews), `s_k` = next index, one global stall, `cfg_m/n/k`, one tile in flight. **Used unmodified in the integration test** (`third_party/silicaflux-tensorcore02/`). |
| Performance counters (Module 07) | `silicaflux-hpc-m07-perf-counters.zip` → `hpc_perf_counters.sv` | — | Events are exported as `ev_inc`: one multi-event increment field per event, matching `hpc_perf_counters.inc_i`. A local saturating counter bank (`tob_perf`) is also included. |
| TENSORCORE 01 PE | `silicaflux-tensorcore01-tensor_pe.zip` | — | Not needed (the array of TENSORCORE 02 is the consumer). |
| BandwidthLab, MemoryFlow, memory_cache_repo | various zips | Analysis models / caches | Not inspected in depth; not used. The bandwidth model here is self-contained (`model/tob_bw_model.py`) and checked against RTL measurements. |

## Facts about the consumer that shaped the design

* `pipe_en = ~stall_i & (RUN ? s_valid : DRAIN)`: the array advances only when a slice is accepted. A missing slice
  freezes it without corrupting alignment, so operand starvation costs time, never correctness.
* `s_ready = (state == RUN) & ~stall_i`: between tiles (CLEAR / DRAIN / READOUT) the array does not accept slices,
  so the buffer can prefetch the next tile into its staging registers.
* The array's built-in alignment checker (`align_err`) and its `s_k` output give an independent check of the
  buffer's k-index alignment in the integration test.

## Tools

The tools the prior modules used were missing from this container and were installed from the Ubuntu
archive: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, nextpnr-ecp5 / nextpnr-ice40 0.6 with the Trellis /
IceStorm device databases, and Python 3.13. Exact versions are recorded in every report's provenance.
