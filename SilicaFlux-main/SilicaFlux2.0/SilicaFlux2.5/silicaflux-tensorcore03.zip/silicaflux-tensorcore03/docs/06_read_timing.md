# 06 — Read timing and alignment

## 1. The SRAM contract this design relies on

The SRAM Wrapper Library raw backends guarantee that read data is valid **exactly `READ_LATENCY` cycles after the
read edge, for that one cycle only**. Nothing may rely on it being held, because real macros do not hold it. In
simulation the GENERIC backend is built with `SRAMLIB_POISON`, which makes `rdata` X in every cycle that is not a
valid read slot. A capture one cycle early or late therefore produces X bytes, and the slice checker compares with
4-state `!==`, so it fails.

## 2. Pipeline (edge n = the rising edge that ends cycle n)

```
edge X           a lane (or the B beat) is granted: the bank samples ce/addr  (grant = request + arbitration, same cycle)
edges X+1..X+RL  return pipeline register(s) carry {valid, physical bank} alongside the SRAM's own latency
edge X+RL        rdata of that bank is valid in the cycle before this edge and is written into the staging FIFO
                 (B: words merged into the row line, C bytes extracted, row pushed when its last beat returns)
edge X+RL+1      slice assembly sees the FIFO non-empty -> emit into the output register (if free or being drained)
cycle X+RL+2     s_valid = 1 with s_a/s_b/coordinates; transferred at edge X+RL+2 if s_ready
```
The return pipeline has exactly `READ_LATENCY` stages and is clocked with the SRAM, so the bank index arrives with
its data in the same cycle, for every `READ_LATENCY` from 1 to 8. The regression covers 1, 2 and 3; the bandwidth
sweep covers 1 to 4. Each lane and the B fetcher are granted at most one bank per cycle, and each bank grants at most
one reader per cycle, so a FIFO receives at most one word per cycle and the words of one stream return in request
order.

## 3. What is aligned with what

All slice fields are produced by one emit, from the same consumer context and the same `k`, and are registered
together in the output register. Data, valid, coordinates and reduction index therefore cannot drift relative to
each other:

| Field | Source at emit |
|---|---|
| `s_a[i]` | byte `(off0_i + k) mod WB` of lane i's head word (0 if `i ≥ eff_m`) |
| `s_b[j]` | byte j of the head B row (0 if `j ≥ eff_n`) |
| `s_k`, `s_kg` | `k`, `k0 + k` |
| `s_m0`, `s_n0`, `s_row_mask`, `s_col_mask`, `s_tag`, `s_set` | the consumer context of the tile |
| `s_first`, `s_last` | `k == 0`, `k == eff_k − 1` |

Off-by-one protection, layer by layer:

1. Fixed-latency return pipelines carrying the bank index; no "data valid" is inferred from timing.
2. Credits: a request is issued only if its FIFO slot is reserved, so data is never dropped or overwritten
   (asserted by the FIFO's own checker).
3. A lane retires its head word after the word's last byte **or** at the tile's last slice, so the next tile
   always starts on its own first word, whatever the alignment.
4. Every slice is compared with A[m0+i][k0+k] / B[k0+k][n0+j] from the byte-accurate reference memory. This holds
   under random back-pressure, with stable-while-stalled checked, and with poisoned SRAM outputs.
5. In the integration test the array's expected index (`s_k` of TENSORCORE 02) is compared with the buffer's at
   every handshake, the array's own alignment checker (`align_err`) must stay 0, and C must equal the reference
   matmul.

## 4. Latency figures (idle buffer, conflict-free layout)

From the pipeline: tile accept (edge e) → AGU 8 + R cycles → context pushed at edge e + 7 + R → fetch loads at
e + 8 + R → first grant at X = e + 9 + R → first slice transfer at **e + R + RL + 11**. The tile response is
transferred at e + 8 + R. A DMA write is acknowledged 2 cycles after acceptance (hold stage + response FIFO) when its
bank port is free. Measured (`reports/perf.md`, "Latency"; conflict-free layout):

| | 4×4 RL1 | 4×4 RL2 | 4×4 RL4 | 4×4 1RW | 8×8 | 16×16 |
|---|---|---|---|---|---|---|
| DMA write accept → response | 2 | 2 | 2 | 2 | 2 | 2 |
| tile accept → tile response (8 + R) | 12 | 12 | 12 | 12 | 16 | 24 |
| tile accept → first slice (R + RL + 11) | 16 | 17 | 19 | 16 | 20 | 28 |
| gap between back-to-back tiles | 2 | 2 | 2 | 2 | 2 | 2 |

Every measured value equals the expression. When the first words of several lanes share a bank, each extra lane
on that bank adds one cycle to the first slice (an earlier run with lda = 64 measured 19 cycles instead of 16 on the
4×4 baseline).

Steady state is one slice per cycle, as long as the bandwidth conditions of doc 03 hold. Between back-to-back
tiles the buffer leaves a 2-cycle gap (measured). The fetch of tile t+1 starts when every request of tile t has
been issued, and its context is already validated. In the integrated system this gap is hidden: after its last slice, the
TENSORCORE 02 array spends DRAIN (≈ M + N cycles) plus READOUT (M beats) plus CLEAR before it accepts the next
tile's first slice, and the buffer has the next tile staged by then.
