# 01 — Architecture and interface

## 1. Block diagram

```
 DMA master (Module 05 hpc_dma_spm_port, or any master speaking the Module 04 port protocol)
   │ dma_req_{valid,ready,we,addr,wdata,wstrb,tag}   dma_rsp_{valid,ready,rdata,err,err_code,we,tag}
   ▼
 tob_dma_port ── hold register ── decode: RANGE > ALIGN > UNSUP(read) > OWNER(set not FILL)
   │  wr_valid / wr_go (one write per cycle, every replica in the same cycle)   ▲ wr_force after
   │                                                                           │ WR_STARVE_LIMIT waits
   ▼                                                                           │
 ┌──────────────── A buffer ──────────────────┐    ┌──────────── B buffer ─────────────┐
 │ physical banks = A_BANKS × A_REPL (× 2 if   │    │ physical banks = B_BANKS (× 2 if  │
 │ SPLIT); one tob_bank_arb + tob_bank each    │    │ SPLIT); one tob_bank_arb + bank   │
 └──────▲─────────────────────────────────────┘    └──────▲────────────────────────────┘
        │ one word per lane request                      │ one B-row beat = up to B_BANKS words
 A lane fetchers (ARRAY_ROWS)                     B row fetcher (byte address += ldb per row)
        │ fixed READ_LATENCY return pipelines            │ return pipeline + row assembly (byte rotate)
        ▼                                                ▼
 A staging FIFOs (A_STAGE words / lane)           B staging FIFO (B_STAGE rows of ARRAY_COLS bytes)
        └──────────────── slice assembly ────────────────┘
          lane i byte = (off0_i + k) mod WB of its head word; dead lanes = 0
                              ▼
 output register: s_valid/s_ready, s_a, s_b, s_k, s_kg, s_m0, s_n0, s_row_mask, s_col_mask, s_first, s_last, s_tag, s_set
                              ▼
                     tensor_systolic_array (TENSORCORE 02)

 tile descriptors ─► tob_tile_agu (validate, overflow/range, lane start addresses; 1 shared multiplier)
                       ├─► tile_rsp FIFO (tag, err, code, eff_m/n/k = the array's cfg_m/n/k)
                       └─► context queue (2 entries: tile t is delivered while tile t+1 is fetched)
 ownership commands ─► tob_dbuf_ctrl (EMPTY → FILL → READY → COMPUTE → EMPTY, ping-pong pointers)
 events ─► ev_inc (multi-event increments, Module 07 compatible) ─► tob_perf (saturating counters)
```

| Module | File | Role |
|---|---|---|
| `tensor_operand_buffer` | `rtl/tensor_operand_buffer.sv` | Top level (primary source): fetchers, staging, slice assembly, bank instances, events |
| `tob_tile_agu` | `rtl/tob_tile_agu.sv` | Address generation: descriptor validation, overflow / range detection, per-lane start words |
| `tob_bank_arb` | `rtl/tob_bank_arb.sv` | Per physical bank: port model (1RW / 1R1W), round-robin readers, compute-first write policy with a bounded wait |
| `tob_bank` | `rtl/tob_bank.sv` | One physical bank = sramlib `sram_backend_1rw` / `sram_backend_1r1w` (GENERIC / FPGA / ASIC) |
| `tob_dma_port` | `rtl/tob_dma_port.sv` | Fill port: decode, ownership check, hold stage, response FIFO, write-starvation counter |
| `tob_dbuf_ctrl` | `rtl/tob_dbuf_ctrl.sv` | Set ownership / ping-pong controller |
| `tob_perf` | `rtl/tob_perf.sv` | Saturating counter bank over `ev_inc` |
| (reused) `sram_backend_*`, `sram_*` | `third_party/silicaflux-sramlib/` | Unmodified SRAM Wrapper Library |
| (reused) `dma_fifo` | `third_party/silicaflux-datafabric/` | Unmodified DataFabric FIFO (staging, responses, tile responses) |

## 2. Parameters

| Parameter | Default | Legal values | Meaning |
|---|---|---|---|
| `ARRAY_ROWS` (R), `ARRAY_COLS` (C) | 4, 4 | ≥ 1 | A lanes and B lanes = systolic array size |
| `WORD_BYTES` (WB) | 4 | 2, 4, 8, 16 | Bank word = DMA beat, in bytes |
| `A_SET_BYTES`, `B_SET_BYTES` | 4096, 4096 | powers of two, ≥ 2·WB·banks | Operand capacity per set (INT8 elements = bytes) |
| `A_BANKS`, `B_BANKS` | 4, 2 | powers of two | Logical banks (word-interleaved) |
| `A_REPL` | 1 | 1, 2, 4 (≤ R) | A replication: lane i reads replica i mod A_REPL; every DMA write goes to all replicas in the same cycle |
| `NUM_SETS` | 2 | 1, 2 | 1 = single buffer, 2 = ping-pong |
| `SET_MAP` | SHARED | SHARED, SPLIT | SHARED: the set is the row MSB of the same banks; SPLIT: each set has its own banks |
| `PORT_MODE` | 1R1W | 1RW, 1R1W | Physical bank port model (doc 04) |
| `READ_LATENCY` | 1 | 1..8 | SRAM read latency (sramlib raw contract) |
| `A_STAGE`, `B_STAGE` | 2, 4 | powers of two ≥ 2 | Staged + in-flight words per A lane / rows of B |
| `WR_STARVE_LIMIT` | 8 | ≥ 0 | Maximum cycles a DMA write yields to reads (0 = writes have priority) |
| `ADDR_W` | 32 | ≥ set width, ≤ 48 | Byte-address width of descriptors and of the DMA port |
| `DMA_BASE` | 0 | word aligned | Base of the DMA window |
| `IDX_W`, `K_W`, `TAG_W` | 16, 17, 8 | | Matrix index, K index (= TENSORCORE 02 `K_WIDTH`), tag widths |
| `DMA_RSP_DEPTH` | 4 | powers of two ≥ 2 | DMA response credits (≥ 3 for one write per cycle) |
| `BACKEND`, `MACRO_A`, `MACRO_B` | GENERIC, 0, 0 | sramlib | GENERIC / FPGA / ASIC (ASIC requires real macro ids) |
| `PERF_EN`, `CNT_W` | 1, 32 | | Local counter bank |

Every illegal combination is rejected at elaboration with a named generate block and a message. The regression
checks 20 such combinations (`reports/regression.md`, "negative").

**Modest-FPGA baseline:** a 4×4 array, 32-bit words, 2 sets × (4 KiB A + 4 KiB B) = 16 KiB, 4 A banks, 2 B banks,
1R1W (FPGA simple-dual-port BRAM), latency 1. Measured resources are in `reports/synth.md`.

## 3. Interfaces (all single clock, active-low asynchronous reset)

* **DMA fill port**: the Module 04 port protocol, write-only (doc 02 §3 for the window map). A write is
  acknowledged only after it has been written to every target bank and replica. Exactly one response per request,
  in order; never in the acceptance cycle; `dma_req_ready` never depends on `dma_rsp_ready`.
* **Ownership**: four valid/ready commands `fill_begin`, `fill_end`, `cmp_begin`, `cmp_end`. A command waits
  (ready low) while its precondition is false (doc 05). Outputs: `fill_set`, `cmp_set`, `set_state`.
* **Tile descriptor**: `tile_valid/ready` with `a_addr, lda, b_addr, ldb` (bytes), `m0, n0, k0` (tile origin and
  K index), `mat_m, mat_n, mat_k` (matrix size, for the boundary masks), `tile_k`, `tag`. A tile is accepted only while
  the compute set is in COMPUTE and no `cmp_end` is pending.
* **Tile response**: `tile_rsp_valid/ready`, `tag, err, code, m, n, k`. Responses come in descriptor order. For a
  good tile, `m/n/k` are the effective tile sizes, which the integration test feeds straight into
  `tensor_systolic_array.cfg_m/cfg_n/cfg_k`. Error tiles produce no slice and touch no memory.
* **Slice stream**: `s_valid/s_ready`, `s_a` (R bytes), `s_b` (C bytes), `s_k` (k inside the tile, equal to the
  array's `s_k`), `s_kg` (global k), `s_m0, s_n0` (matrix coordinates of lane 0), `s_row_mask, s_col_mask`,
  `s_first, s_last`, `s_tag, s_set`. The output is held stable while `s_ready` is low.
* **Status / performance**: `busy`, `engine_idle`, `ev_inc` (20 events × 8-bit increments, `tob_defs.svh`),
  `ev_bank_conflict_a` (per physical A bank), `perf_clear`, `perf_cnt`.

## 4. Data flow of one tile

1. **AGU** (8 + R cycles, hidden while the previous tile streams): `eff_m/n/k`. Then
   A0 = a + m0·lda + k0 and Alast = a + (m0+eff_m−1)·lda + k0 + eff_k − 1, and the same for B, all in 52-bit
   arithmetic. Range and overflow are checked on the last byte. Then lane i starts at A0 + i·lda, giving its first
   word and byte offset.
2. **Fetch.** Each live A lane requests the words from its first to its last, one per grant, while it has a free
   staging credit. The B fetcher requests row k at `b + (k0+k)·ldb + n0`: all words of the row in one beat,
   granted only if every involved bank grants (all-or-nothing), or in several beats when `B_BANKS` is smaller than
   the row's word span. Both run on the fetch context; the next tile's fetch starts when every request of this one
   has been issued.
3. **Return.** Read data comes back exactly `READ_LATENCY` cycles after the grant edge. A per-lane / per-B
   pipeline carries the bank index, so the right bank's data is written into the right staging FIFO in that exact
   cycle. B words are reassembled into a line and the C bytes of the row are extracted (byte rotate) before staging.
4. **Assembly.** A slice is ready when the B FIFO and every live lane FIFO are non-empty. Lane i supplies byte
   `(off0_i + k) mod WB` of its head word, and pops the word after its last byte or at the end of the tile. Dead
   lanes and columns are 0, with their mask bit clear.
5. **Output register.** The slice, coordinates, masks and tag are registered and held until `s_ready`.

Staging decouples the three timing domains: SRAM latency, bank conflicts, and the array's stalls and inter-tile
gaps. Credits make overflow impossible (asserted).
