# 08 — Verification

## 1. Method

* **Reference model, byte accurate.** `tb_tensor_operand_buffer` keeps `ref_a` / `ref_b`, NUM_SETS × SET_BYTES
  bytes each, initialised to X. A DMA write updates the strobed bytes only when its *acknowledgement* arrives. A test
  that reads a byte it never wrote is reported as a test bug, so every check compares against real data.
* **Independent expectations.** The expected DMA response code, tile response (code, eff_m/n/k), every slice field,
  the ownership state, and the A/B words read are computed in the testbench from the specification, in 64-bit
  arithmetic, without looking at DUT internals.
* **Every slice is checked**: `s_a`, `s_b` (4-state `!==`, poisoned SRAM outputs), `s_k`, `s_kg`, `s_m0`, `s_n0`,
  masks, `s_first`, `s_last`, `s_tag`, `s_set`, and stability while back-pressured.
* **White-box monitors** (bounds, not functional expectations): longest wait of an A lane request and of a DMA
  write; same-cycle read+write per physical bank (must be 0 under 1RW); `fill_end_ready` low while a DMA request is
  held. Embedded RTL assertions (`TOB_ASSERT`, `SRAMLIB_ASSERT`) run in every simulation.
* **Agents** for DMA, tiles, ownership commands, `s_ready`, `dma_rsp_ready` and `tile_rsp_ready` are independent
  processes, each with its own deterministic RNG. DMA fill and compute are therefore genuinely concurrent, and
  Icarus and Verilator replay identical stimulus. The `cross` stage requires identical measurement lines from both.
* **Staged** as the brief requires: stage 1 = single buffer with one bank per operand; stage 2 = single buffer,
  banked parallel access; stage 3 = double buffering. A stage runs only if the previous ones passed.
* **Rate check.** Where the analytical model predicts full rate for the concurrent-A/B layout, the regression also
  runs `concurrent +full_rate`, which turns any bubble inside a tile into an error.
* **Mutation testing**: 34 single-line design bugs, each of which must make at least one run fail
  (`reports/mutation.md`).
* **Integration with the real consumer**: `tb_tob_array` drives TENSORCORE 02 (unmodified) and checks C against a
  reference INT8 matmul.

## 2. Required tests → where

| Required | Test(s) | What is checked |
|---|---|---|
| All memory banks | `banks` | Every set is filled completely (random data, partial strobes). Tiles then read **every byte of every row of every bank, of every replica** (row offsets 0..A_REPL−1 put every row on every replica's lanes) and every B column group. Writes into a set in COMPUTE are refused and leave it unchanged. |
| Sequential reads | `seq` | Dense, aligned matrices; K walked in chunks (k0 = 0, 16, 32, …); multi-tile M and N |
| Strided reads | `stride`, `random` | Five layout classes: dense, dense + random pad, pathological (all lanes in one bank), conflict-free, large random; unaligned bases |
| Concurrent A/B reads | `concurrent` (+`full_rate` where predicted) | Long full tiles with both paths streaming; no bubble inside a tile where the model predicts full rate |
| Partial tiles | `partial`, `random` | Every edge tile of a (2R+1)×(2C+1)×37 problem; origins at the last row/column/k; tile_k clamped; zero padding and masks |
| Buffer switching | `switch` | Four ping-pong rounds with distinct data per set: every tile reads its own set; single-buffer configs run the serial version |
| DMA/compute contention | `contention`, `rdw`, integ | Full-rate DMA fill of one set while saturating reads stream from the other. Under 1RW + shared banks writes **must** be forced (coverage) and wait exactly `WR_STARVE_LIMIT`; under 1R1W no write may stall; OVERLAP must be > 0 |
| Reset | `reset` | Asynchronous reset in the middle of a DMA fill, a tile stream, and a tile validation; outputs idle in reset; state EMPTY; arrays keep their content (read back afterwards); normal operation resumes |
| Out-of-range addresses | `range`, `owner` | DMA: below base, beyond the window, in the A/B hole, unaligned, read (UNSUP), wrong owner. Tiles: EMPTY (4 forms), LD (2), A_RANGE / B_RANGE at exact boundaries (last byte = SET_BYTES−1 accepted, = SET_BYTES refused), A_OVF / B_OVF, a single byte at 2^ADDR_W−1. No slice, no side effect |
| Read-during-write collisions | `rdw`; `tb_tob_bank_arb` | Integrated: DMA writes the banks being read (other set); 1R1W performs both in the same cycle (counted, must be > 0 with shared banks), 1RW never does. Same row: unit test of both port models against a reference arbiter (forced and unforced hazards, co-issue of different rows) |
| Bank starvation | `starve`, `contention`; `tb_tob_bank_arb` | Pathological stride (all lanes in one bank) plus DMA pressure: conflicts > 0, lane wait bounded, DMA wait ≤ `WR_STARVE_LIMIT`; round-robin bound NR−1 measured in the unit test |
| Correct data alignment | every test; `align`; integ | Every slice field; 50 % `s_ready` back-pressure + random gaps on every other channel; poisoned SRAM outputs; array index and `align_err` in the integration test |
| Ownership / safe switching | `owner` | Writes to EMPTY / READY / COMPUTE sets refused; `fill_end` waits for a held request; `cmp_end` waits for the last slice under 85 % back-pressure; `tile_ready` low while a release is pending; tiles refused without a compute set |
| Performance counters | `perf` + final check of every run | Every counter = sum of its `ev_inc` field; SLICES, WR_WORDS, DMA_ERR, TILE_OK/ERR, ARRAY_BP, CYCLES, A/B words read = independent counts; starvation attribution consistent |

## 3. Results

See `reports/regression.md` (generated), `reports/mutation.md` and `reports/SUMMARY.md`. The figures in the README
are copied from those files.

## 4. Limits of this verification

* Simulation only: no formal proof of the new RTL, no gate-level simulation, no FPGA board run.
* The model-gated full-rate assertion covers the concurrent-A/B layout. Other layouts are measured
  (`reports/perf.md`) rather than asserted.
* The DMA port is tested with a protocol-level agent. Connecting the real Module 05 `hpc_dma_spm_port` is a
  documented next step (doc 10); the protocol compatibility is argued in doc 00 and doc 02, not simulated.
