# Synthesis and place-and-route resource report

Every number below comes from an actual Yosys / nextpnr run (`scripts/run_synth.py`, logs under `build/synth/`).
What is NOT claimed: no Vivado/Quartus/Radiant run, no timing for Xilinx (synthesis only), no ASIC timing, power or
area (no Liberty/LEF flow: ASIC rows are macro-integrity checks plus generic-gate cell counts).  FPGA block-RAM
counts and FPGA Fmax do not predict ASIC SRAM macro area or access time.

## Generic synthesis: latch check and memory inference

| configuration | physical banks (expected) | bank arrays inferred | all inferred memories (depth x width) | latches | cells | result |
|---|---|---|---|---|---|---|
| 4x4 WB4 A4K/4b B4K/2b DB 1R1W | 6 | 6 | 512x32, 512x32, 512x32, 512x32, 1024x32, 1024x32, 2x32, 2x32, 2x32, 2x32, 4x32, 4x12, 2x36 | 0 | 2780 | PASS |
| 4x4 WB4 A4K/1b B4K/1b SB 1R1W | 2 | 2 | 1024x32, 1024x32, 2x32, 2x32, 2x32, 2x32, 4x32, 4x12, 2x36 | 0 | 1474 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB 1RW | 6 | 6 | 512x32, 512x32, 512x32, 512x32, 1024x32, 1024x32, 2x32, 2x32, 2x32, 2x32, 4x32, 4x12, 2x36 | 0 | 2906 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB-SPLIT 1R1W | 12 | 12 | 256x32, 256x32, 256x32, 256x32, 256x32, 256x32, 256x32, 256x32, 512x32, 512x32, 512x32, 512x32, 2x32, 2x32, 2x32, 2x32, 4x32, 4x12, 2x36 | 0 | 4656 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB 1R1W REPL2 | 10 | 10 | 512x32, 512x32, 512x32, 512x32, 512x32, 512x32, 512x32, 512x32, 1024x32, 1024x32, 2x32, 2x32, 2x32, 2x32, 4x32, 4x12, 2x36 | 0 | 4128 | PASS |
| 8x8 WB4 A4K/8b B4K/4b DB 1R1W | 12 | 12 | 256x32, 256x32, 256x32, 256x32, 256x32, 256x32, 256x32, 256x32, 512x32, 512x32, 512x32, 512x32, 2x32, 2x32, 2x32, 2x32, 2x32, 2x32, 2x32, 2x32, 4x64, 4x12, 2x38 | 0 | 5721 | PASS |

## FPGA synthesis (Yosys, BACKEND = FPGA block-RAM inference)

| flow | configuration | stored Kbit | RAM primitives | LUTs | FFs | DSP/MULT | carry | LUT-RAM | $mem left | result |
|---|---|---|---|---|---|---|---|---|---|---|
| synth_xilinx | 4x4 WB4 A4K/4b B4K/2b DB 1R1W | 128 | 4x RAMB18E1, 2x RAMB36E1 | 3582 | 1866 | 4 | 577 | 38 | 0 | PASS |
| synth_xilinx | 4x4 WB4 A4K/1b B4K/1b SB 1R1W | 64 | 2x RAMB36E1 | 2845 | 1913 | 4 | 439 | 38 | 0 | PASS |
| synth_xilinx | 4x4 WB4 A4K/4b B4K/2b SB 1R1W | 64 | 6x RAMB18E1 | 3629 | 1862 | 4 | 559 | 38 | 0 | PASS |
| synth_xilinx | 4x4 WB4 A4K/4b B4K/2b DB 1RW | 128 | 4x RAMB18E1, 2x RAMB36E1 | 3594 | 1866 | 4 | 577 | 38 | 0 | PASS |
| synth_xilinx | 4x4 WB4 A4K/4b B4K/2b DB-SPLIT 1R1W | 128 | 12x RAMB18E1 | 4855 | 1875 | 4 | 736 | 38 | 0 | PASS |
| synth_xilinx | 4x4 WB4 A4K/4b B4K/2b DB 1R1W REPL2 | 192 | 8x RAMB18E1, 2x RAMB36E1 | 4308 | 1874 | 4 | 735 | 38 | 0 | PASS |
| synth_xilinx | 4x4 WB4 A4K/4b B4K/2b DB 1R1W noPerf | 128 | 4x RAMB18E1, 2x RAMB36E1 | 2794 | 1226 | 4 | 397 | 38 | 0 | PASS |
| synth_xilinx | 4x4 WB4 A16K/4b B16K/2b DB 1R1W | 512 | 16x RAMB36E1 | 3907 | 1922 | 4 | 582 | 38 | 0 | PASS |
| synth_xilinx | 8x8 WB4 A8K/8b B8K/4b DB 1R1W | 256 | 8x RAMB18E1, 4x RAMB36E1 | 8535 | 2281 | 4 | 1127 | 68 | 0 | PASS |
| synth_xilinx | 16x16 WB8 A16K/8b B16K/4b DB 1R1W | 512 | 16x RAMB36E1 | 19069 | 3109 | 4 | 1892 | 207 | 0 | PASS |
| synth_ecp5 | 4x4 WB4 A4K/4b B4K/2b DB 1R1W | 128 | 8x DP16KD | 5908 | 2065 | 3 | 1523 | 52 | 0 | PASS |
| synth_ecp5 | 4x4 WB4 A4K/4b B4K/2b DB 1RW | 128 | 8x DP16KD | 5179 | 1864 | 3 | 1523 | 52 | 0 | PASS |
| synth_ice40 | 4x4 WB4 A2K/4b B2K/2b DB 1R1W | 64 | 16x SB_RAM40_4K | 6902 | 2538 | 0 | 1954 | 0 | 0 | PASS |

## Place and route (nextpnr), buffer inside the I/O measurement wrapper

| device | configuration | utilisation (used / available) | Fmax (nextpnr timing) | critical path through | result |
|---|---|---|---|---|---|
| LFE5U-25F-6 CABGA256 | 4x4 WB4 A4K/4b B4K/2b DB 1R1W | DCCA 1/56; DP16KD 8/56; MULT18X18D 3/28; TRELLIS_COMB 8794/24288; TRELLIS_FF 3655/24288; TRELLIS_IO 19/197; TRELLIS_RAMW 52/3036 | $glbnet$clk$TRELLIS_IO_IN: 40.28 MHz | dma_fifo.sv, tensor_operand_buffer.sv, tob_dma_port.sv, tob_perf.sv, tob_pnr_wrap.sv | PASS |
| LFE5U-25F-6 CABGA256 | 4x4 WB4 A4K/4b B4K/2b DB 1RW | DCCA 1/56; DP16KD 8/56; MULT18X18D 3/28; TRELLIS_COMB 8012/24288; TRELLIS_FF 3454/24288; TRELLIS_IO 19/197; TRELLIS_RAMW 52/3036 | $glbnet$clk$TRELLIS_IO_IN: 40.43 MHz | dma_fifo.sv, tensor_operand_buffer.sv, tob_dma_port.sv, tob_perf.sv, tob_pnr_wrap.sv | PASS |
| LFE5U-25F-6 CABGA256 | 8x8 WB4 A8K/8b B8K/4b DB 1R1W | DCCA 1/56; DP16KD 16/56; MULT18X18D 3/28; TRELLIS_COMB 19888/24288; TRELLIS_FF 4349/24288; TRELLIS_IO 19/197; TRELLIS_RAMW 93/3036 | $glbnet$clk$TRELLIS_IO_IN: 28.24 MHz | dma_fifo.sv, tensor_operand_buffer.sv, tob_bank.sv, tob_perf.sv, tob_pnr_wrap.sv | PASS |
| iCE40-HX8K CT256 | 4x4 WB4 A2K/4b B2K/2b DB 1R1W noPerf | ICESTORM_LC 7292/7680; ICESTORM_RAM 16/32; SB_GB 7/8; SB_IO 19/256 | clk$SB_IO_IN_$glb_clk: 31.44 MHz | dma_fifo.sv, tensor_operand_buffer.sv, tob_pnr_wrap.sv, tob_tile_agu.sv | PASS |

## ASIC macro integration (Yosys, BACKEND = ASIC, black-box macros)

| configuration | macro | expected | found | buffer logic cells (generic gates) | flip-flops | result |
|---|---|---|---|---|---|---|
| 4x4 WB4 A4K/4b B4K/2b DB 1R1W | sky130_sram_2kbyte_1rw1r_32x512_8 (512x32) | 8 | 8 | 16419 | 2368 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB-SPLIT 1R1W | sky130_sram_1kbyte_1rw1r_32x256_8 (256x32) | 16 | 16 | 17900 | 2379 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB 1R1W | RM_IHPSG13_2P_512x32_c2_bm_bist (512x32) | 8 | 8 | 16416 | 2368 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB 1RW | RM_IHPSG13_1P_512x32_c2_bm_bist (512x32) | 8 | 8 | 16370 | 2368 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB-SPLIT 1RW | RM_IHPSG13_1P_256x32_c2_bm_bist (256x32) | 16 | 16 | 17926 | 2379 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB 1RW | gf180mcu_fd_ip_sram__sram512x8m8wm1 (512x8) | 32 | 32 | 16423 | 2368 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB 1R1W noPerf | sky130_sram_2kbyte_1rw1r_32x512_8 (512x32) | 8 | 8 | 12643 | 1728 | PASS |

