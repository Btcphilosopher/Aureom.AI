# Operand bandwidth: RTL measurement vs model

`scripts/run_perf.py`; RTL simulation (Verilator), 8 back-to-back full tiles of K = 256 k-slices per point, the array
never back-pressures (s_ready = 1).  in-tile rate = k-slices delivered per cycle while a tile streams (1.0 =
R A-operands + C B-operands every cycle); overall = slices / all cycles (incl. per-tile setup/drain gaps).
Model: `model/tob_bw_model.py` (L = lanes per physical A bank per round; full rate predicted when the bank-port
limit and the latency-coverage conditions hold).  Every point is also a self-checking run (all slices compared).

| group | configuration | layout | note | lanes/bank L | model: full rate? | in-tile rate | operands/cycle | overall | starve A/B | conflicts | wr stall | overlap | check |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | s=65 (odd, conflict-free) | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| A layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 268 ldb 4 a+0 b+0 | s=67 (=3 mod 4) | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| A layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 264 ldb 4 a+0 b+0 | s=66 (=2 mod 4) | 2 | yes | 1.000 | 8.0 | 0.985 | 18/10 | 1008 | 0 | 0 | PASS |
| A layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 256 ldb 4 a+0 b+0 | dense K=256: s=64 (=0 mod 4) | 4 | no (bound 1.00) | 0.892 | 7.14 | 0.874 | 282/10 | 1512 | 0 | 0 | PASS |
| A layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 257 ldb 4 a+0 b+0 | unaligned rows | 1 | yes | 1.000 | 8.0 | 0.977 | 34/10 | 24 | 0 | 0 | PASS |
| B layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | aligned rows, 2 banks | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| B layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+1 | every row straddles 2 words | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| B layout | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 5 a+0 b+0 | mixed offsets | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| B layout | 4x4 WB4 A4K/4b B4K/1b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | aligned, 1 bank | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| B layout | 4x4 WB4 A4K/4b B4K/1b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+1 | straddling, 1 bank (2 beats) | 1 | no (bound 0.50) | 0.501 | 4.01 | 0.496 | 17/2065 | 0 | 0 | 0 | PASS |
| B layout | 4x4 WB4 A4K/4b B4K/1b DB-SHARED 1R1W RL1 | lda 260 ldb 5 a+0 b+0 | mixed, 1 bank | 1 | no (bound 0.50) | 0.571 | 4.57 | 0.567 | 17/1553 | 0 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 stage2/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=1, A_STAGE=2 | 4 | no (bound 1.00) | 0.892 | 7.14 | 0.879 | 268/3 | 1533 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 stage4/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=1, A_STAGE=4 | 4 | yes | 1.000 | 8.0 | 0.984 | 20/3 | 1464 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL2 stage2/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=2, A_STAGE=2 | 4 | no (bound 1.00) | 0.805 | 6.44 | 0.794 | 517/4 | 1533 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL2 stage4/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=2, A_STAGE=4 | 4 | yes | 1.000 | 8.0 | 0.983 | 21/4 | 1485 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL3 stage2/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=3, A_STAGE=2 | 4 | no (bound 1.00) | 0.734 | 5.87 | 0.722 | 773/5 | 1533 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL3 stage4/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=3, A_STAGE=4 | 4 | yes | 1.000 | 8.0 | 0.983 | 22/5 | 1485 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL4 stage2/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=4, A_STAGE=2 | 4 | no (bound 1.00) | 0.674 | 5.39 | 0.663 | 1029/6 | 1533 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL4 stage4/8 | lda 256 ldb 4 a+0 b+0 | all lanes one bank, RL=4, A_STAGE=4 | 4 | yes | 1.000 | 8.0 | 0.979 | 30/6 | 1485 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | conflict-free, RL=1 | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL2 | lda 260 ldb 4 a+0 b+0 | conflict-free, RL=2 | 1 | yes | 1.000 | 8.0 | 0.985 | 18/18 | 0 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL3 stage2/8 | lda 260 ldb 4 a+0 b+0 | conflict-free, RL=3 | 1 | yes | 1.000 | 8.0 | 0.984 | 19/19 | 0 | 0 | 0 | PASS |
| staging/latency | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL4 stage2/8 | lda 260 ldb 4 a+0 b+0 | conflict-free, RL=4 | 1 | no (bound 1.00) | 0.892 | 7.14 | 0.882 | 261/6 | 0 | 0 | 0 | PASS |
| replication | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 256 ldb 4 a+0 b+0 | A_REPL=1, all lanes one bank | 4 | no (bound 1.00) | 0.892 | 7.14 | 0.874 | 282/10 | 1512 | 0 | 0 | PASS |
| replication | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 REPL2 | lda 256 ldb 4 a+0 b+0 | A_REPL=2, all lanes one bank | 2 | yes | 1.000 | 8.0 | 0.985 | 18/10 | 1008 | 0 | 0 | PASS |
| replication | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 REPL4 | lda 256 ldb 4 a+0 b+0 | A_REPL=4, all lanes one bank | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| A banks | 4x4 WB4 A4K/1b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | 1 A banks, s=65 | 4 | no (bound 1.00) | 0.892 | 7.14 | 0.874 | 282/10 | 1544 | 0 | 0 | PASS |
| A banks | 4x4 WB4 A4K/2b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | 2 A banks, s=65 | 2 | yes | 1.000 | 8.0 | 0.981 | 26/10 | 1032 | 0 | 0 | PASS |
| A banks | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | 4 A banks, s=65 | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| A banks | 4x4 WB4 A4K/8b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | 8 A banks, s=65 | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 0 | PASS |
| array size | 8x8 WB4 A4K/8b B4K/4b DB-SHARED 1R1W RL1 | lda 260 ldb 8 a+0 b+0 | 8x8, 32-bit words, s=65 | 1 | yes | 1.000 | 16.0 | 0.983 | 17/17 | 0 | 0 | 0 | PASS |
| array size | 8x8 WB4 A4K/8b B4K/4b DB-SHARED 1R1W RL1 | lda 256 ldb 8 a+0 b+0 | 8x8, 32-bit words, s=64 | 8 | no (bound 1.00) | 0.623 | 9.97 | 0.607 | 1306/10 | 3528 | 0 | 0 | PASS |
| array size | 8x8 WB4 A4K/8b B4K/4b DB-SHARED 1R1W RL1 stage4/4 | lda 256 ldb 8 a+0 b+0 | 8x8, s=64, A_STAGE=4 | 8 | yes | 1.000 | 16.0 | 0.961 | 66/10 | 3416 | 0 | 0 | PASS |
| array size | 8x8 WB8 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 264 ldb 8 a+0 b+0 | 8x8, 64-bit words, s=33 | 2 | yes | 1.000 | 16.0 | 0.979 | 26/10 | 1048 | 0 | 0 | PASS |
| array size | 16x16 WB4 A16K/16b B16K/8b DB-SHARED 1R1W RL1 stage4/4 | lda 260 ldb 16 a+0 b+0 | 16x16, 32-bit words, s=65 | 1 | yes | 1.000 | 32.0 | 0.979 | 17/17 | 0 | 0 | 0 | PASS |
| array size | 16x16 WB8 A16K/8b B16K/4b DB-SHARED 1R1W RL1 | lda 264 ldb 16 a+0 b+0 | 16x16, 64-bit words, s=33 | 2 | yes | 1.000 | 32.0 | 0.975 | 26/10 | 2104 | 0 | 0 | PASS |
| array size | 16x16 WB16 A16K/4b B16K/2b DB-SHARED 1R1W RL1 | lda 272 ldb 16 a+0 b+0 | 16x16, 128-bit words, s=17 | 4 | yes | 1.000 | 32.0 | 0.961 | 58/10 | 1560 | 0 | 0 | PASS |
| held-out | 8x8 WB4 A4K/8b B4K/4b DB-SHARED 1R1W RL1 | lda 264 ldb 8 a+0 b+0 | 8x8, s=66: 2 lanes per bank | 2 | yes | 1.000 | 16.0 | 0.983 | 18/10 | 2016 | 0 | 0 | PASS |
| held-out | 8x8 WB4 A4K/4b B4K/4b DB-SHARED 1R1W RL1 | lda 260 ldb 8 a+0 b+0 | 8x8, 4 A banks, s=65: 2 lanes per bank | 2 | yes | 1.000 | 16.0 | 0.979 | 26/10 | 2072 | 0 | 0 | PASS |
| held-out | 16x16 WB4 A16K/16b B16K/8b DB-SHARED 1R1W RL1 stage4/4 | lda 256 ldb 16 a+0 b+0 | 16x16, s=64: 16 lanes one bank, A_STAGE=4 | 16 | no (bound 1.00) | 0.773 | 24.75 | 0.730 | 730/10 | 7320 | 0 | 0 | PASS |
| held-out | 16x16 WB4 A16K/16b B16K/8b DB-SHARED 1R1W RL1 stage8/4 | lda 256 ldb 16 a+0 b+0 | 16x16, s=64: 16 lanes one bank, A_STAGE=8 | 16 | yes | 1.000 | 32.0 | 0.929 | 130/10 | 6840 | 0 | 0 | PASS |
| held-out | 4x4 WB4 A4K/2b B4K/2b DB-SHARED 1R1W RL2 | lda 256 ldb 4 a+0 b+0 | 2 A banks, s=64, RL=2 | 4 | no (bound 1.00) | 0.805 | 6.44 | 0.788 | 538/18 | 1512 | 0 | 0 | PASS |
| held-out | 4x4 WB2 A4K/4b B4K/4b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+0 | 16-bit words, s=130, A_STAGE=2 | 2 | no (bound 1.00) | 0.802 | 6.42 | 0.793 | 522/10 | 2032 | 0 | 0 | PASS |
| held-out | 4x4 WB2 A4K/4b B4K/4b DB-SHARED 1R1W RL1 stage4/4 | lda 260 ldb 4 a+0 b+0 | 16-bit words, s=130, A_STAGE=4 | 2 | yes | 1.000 | 8.0 | 0.985 | 18/10 | 2000 | 0 | 0 | PASS |
| DMA overlap | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | lda 260 ldb 4 a+0 b+1 +DMA | 1R1W shared | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 2021 | PASS |
| DMA overlap | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1RW RL1 | lda 260 ldb 4 a+0 b+1 +DMA | 1RW shared, limit 8 | 1 | yes | 0.960 | 7.68 | 0.946 | 17/103 | 0 | 1044 | 1101 | PASS |
| DMA overlap | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1RW RL1 WSL2 | lda 260 ldb 4 a+0 b+1 +DMA | 1RW shared, limit 2 | 1 | yes | 0.854 | 6.83 | 0.843 | 17/368 | 0 | 1044 | 1013 | PASS |
| DMA overlap | 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1RW RL1 WSL0 | lda 260 ldb 4 a+0 b+1 +DMA | 1RW shared, write priority | 1 | yes | 0.667 | 5.34 | 0.659 | 22/1037 | 4 | 0 | 1004 | PASS |
| DMA overlap | 4x4 WB4 A4K/4b B4K/2b DB-SPLIT 1RW RL1 | lda 260 ldb 4 a+0 b+1 +DMA | 1RW split | 1 | yes | 1.000 | 8.0 | 0.985 | 17/17 | 0 | 0 | 2021 | PASS |

## Latency on an idle buffer (cycles, conflict-free layout, `+test=latency`)

| configuration | DMA write accept -> response | tile accept -> tile response | tile accept -> first slice | gap between back-to-back tiles | check |
|---|---|---|---|---|---|
| 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL1 | 2 | 12 | 16 | 2 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL2 stage4/4 | 2 | 12 | 17 | 2 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1R1W RL4 stage4/8 | 2 | 12 | 19 | 2 | PASS |
| 4x4 WB4 A4K/4b B4K/2b DB-SHARED 1RW RL1 | 2 | 12 | 16 | 2 | PASS |
| 8x8 WB4 A4K/8b B4K/4b DB-SHARED 1R1W RL1 | 2 | 16 | 20 | 2 | PASS |
| 16x16 WB4 A16K/16b B16K/8b DB-SHARED 1R1W RL1 stage4/4 | 2 | 24 | 28 | 2 | PASS |

Model check (compute-only points): full rate predicted <=> measured in-tile rate = 1.000 on 44 / 44 points.
Self-checking runs passing: 55 / 55.
