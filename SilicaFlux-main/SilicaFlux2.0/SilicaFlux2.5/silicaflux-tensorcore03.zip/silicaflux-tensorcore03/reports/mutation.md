# Mutation testing

**34 / 34 mutants killed.**  Each mutant is one exact substitution in a copy
of `rtl/`; evaluation = `tb_tensor_operand_buffer +test=all +seed=1` on the four configurations below (plus
`tb_tob_bank_arb` for arbiter mutants).  Killed = at least one run fails.

Evaluation configurations: {'PMODE': 0}; {}; {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}; {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2}

| mutant | file | injected bug | status | killed by | first error |
|---|---|---|---|---|---|
| arb_rr_frozen | tob_bank_arb.sv | round-robin pointer never moves (fixed priority) | KILLED | arb-unit | ERROR cyc=9: mode 0 gnt 0001 exp 0010 (req 1111 ptr 1) |
| arb_no_hazard | tob_bank_arb.sv | 1R1W same-row read/write hazard ignored | KILLED | arb-unit | ERROR cyc=5: mode 1 wr_ok 1 exp 0 |
| arb_no_force | tob_bank_arb.sv | write starvation limit ignored | KILLED | {'PMODE': 0}, arb-unit | ERROR cyc=41386: coverage: 1RW shared banks under saturating reads but no write was forced |
| arb_no_block | tob_bank_arb.sv | reads not blocked by a granted write | KILLED | {'PMODE': 0}, arb-unit | ERROR cyc=38641: 1RW bank given a read and a write in one cycle |
| arb_two_grants | tob_bank_arb.sv | several reads granted in one cycle | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2}, arb-unit | ERROR cyc=2080: tile 0 k 0 s_a 86a4c808 exp 86a4d6bc |
| arb_no_urgency | tob_bank_arb.sv | urgent requests not preferred | KILLED | arb-unit | ERROR cyc=710: mode 0 gnt 0001 exp 1000 (req 1111 ptr 0) |
| dma_no_owner | tob_dma_port.sv | ownership check removed | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=4490: DMA rsp code 0 exp 6 (addr 1000 we 1) |
| dma_no_align | tob_dma_port.sv | alignment check removed | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=86392: DMA rsp code 0 exp 2 (addr 1 we 1) |
| dma_hole | tob_dma_port.sv | hole between A and B decoded as B | KILLED | {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=83096: DMA rsp code 0 exp 1 (addr 10800 we 1) |
| dma_retire_early | tob_dma_port.sv | write acknowledged without a bank grant | KILLED | {'PMODE': 0} | ERROR cyc=28873: tile 213 k 0 s_a 00007151 exp 00003451 |
| dma_credit | tob_dma_port.sv | response credit off by one | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} |  |
| dma_force_never | tob_dma_port.sv | starvation counter never forces | KILLED | {'PMODE': 0} | ERROR cyc=41386: coverage: 1RW shared banks under saturating reads but no write was forced |
| dbuf_fe_no_idle | tob_dbuf_ctrl.sv | fill_end while a DMA request is held | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=88830: fill_end_ready while a DMA request is held |
| dbuf_ce_no_idle | tob_dbuf_ctrl.sv | compute set released before its operands were delivered | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=89332: release accepted before every slice was delivered |
| dbuf_no_pingpong | tob_dbuf_ctrl.sv | fill pointer does not advance | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1} | ERROR cyc=2061: set pointers 0/0 model 1/0 |
| agu_range_off1 | tob_tile_agu.sv | A range check off by one | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=86462: tile 398 rsp code 0 exp 4 |
| agu_no_ovf | tob_tile_agu.sv | A overflow not detected | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=86474: tile 400 rsp code 4 exp 3 |
| agu_no_kclamp | tob_tile_agu.sv | tile_k not clamped at the matrix edge | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2076: tile 0 rsp dims 4 1 2 exp 4 1 1 |
| agu_lane_stride | tob_tile_agu.sv | lane start address off by one per row | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2083: tile 0 k 0 s_a 0a08b6bc exp 86a4d6bc |
| agu_ld_check | tob_tile_agu.sv | lda check removed | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=86424: tile 393 rsp code 0 exp 2 |
| top_pop_no_last | tensor_operand_buffer.sv | lane word not retired at the end of a tile | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2093: tile 1 k 0 s_a 08c8c01e exp 086a9e31 |
| top_hoff_aligned | tensor_operand_buffer.sv | A byte offset ignores the start offset (slice data) | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2082: tile 0 k 0 s_a 18a4350c exp 86a4d6bc |
| top_b_no_off | tensor_operand_buffer.sv | B row extraction ignores the byte offset | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2082: tile 0 k 0 s_b 000000c1 exp 000000e7 |
| top_rl_stage | tensor_operand_buffer.sv | read data routed with the wrong pipeline stage | KILLED | {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1} | ERROR cyc=2083: tile 0 k 0 s_a d9000000 exp 86a4d6bc |
| top_bcredit | tensor_operand_buffer.sv | B staging credit off by one | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} |  |
| top_acredit | tensor_operand_buffer.sv | A staging credit off by one | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} |  |
| top_no_colmask | tensor_operand_buffer.sv | dead B lanes not zeroed | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2082: tile 0 k 0 s_b 00c55be7 exp 000000e7 |
| top_wrgo_no_b | tensor_operand_buffer.sv | B banks not consulted for writes | KILLED | {'PMODE': 0} | ERROR cyc=41392: a saturated bank should make a write wait exactly WR_STARVE_LIMIT (8), saw 2 |
| top_set_row | tensor_operand_buffer.sv | DMA writes ignore the set (shared banks) | KILLED | {'PMODE': 0}, {} | ERROR cyc=5534: tile 20 k 0 s_a 00000000 exp 80008614 |
| top_kg | tensor_operand_buffer.sv | global k coordinate wrong | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2095: tile 1 k 1 s_k 1 s_kg 26 |
| top_idle_outv | tensor_operand_buffer.sv | engine idle while the last slice is still held | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=89449: release accepted before every slice was delivered |
| top_fdone_no_b | tensor_operand_buffer.sv | fetch context advanced before the B rows were issued | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=2166: tile 2 k 61 s_b 00208287 exp 68e6062c |
| top_ev_awords | tensor_operand_buffer.sv | A read-word event counts the wrong bank | KILLED | {'PMODE': 0}, {}, {'RL': 2, 'AST': 4, 'BST': 4, 'PMODE': 0, 'SMAP': 1}, {'ASB': 2048, 'BSB': 8192, 'BASE': 65536, 'NS': 1, 'C': 8, 'NBB': 2} | ERROR cyc=86760: A words read 428, model 387 |
| top_b_allornothing | tensor_operand_buffer.sv | B beat issued when only some banks granted | KILLED | {'PMODE': 0} | ERROR cyc=38641: 1RW bank given a read and a write in one cycle |
