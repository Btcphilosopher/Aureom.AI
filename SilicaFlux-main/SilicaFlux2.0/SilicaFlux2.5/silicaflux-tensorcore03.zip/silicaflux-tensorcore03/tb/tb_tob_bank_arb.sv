// =============================================================================
// SilicaFlux TENSORCORE 03 :: tb_tob_bank_arb
// Unit test of the per-bank arbiter, both port models side by side, against an
// independent reference model (round-robin pointer, hazard rules, force).
// Covers what the integrated buffer can never produce (ownership keeps the
// DMA set and the compute set disjoint): a read and a write of the SAME row in
// the same cycle.  Checks every cycle:
//   * grants == reference grants (one-hot, only eligible requesters, urgent
//     class first, round-robin inside a class);
//   * wr_ok == reference; under 1R1W a same-row read is never issued with the
//     write, under 1RW no read is issued with the write;
//   * forced writes always pass; a continuously requesting reader is granted
//     within NR-1 read grants (round-robin bound), measured.
// =============================================================================
`timescale 1ns/1ps
`include "tob_defs.svh"
`define ERR(args) begin errors = errors + 1; $write("ERROR cyc=%0d: ", cyc); $display args ; end

module tb_tob_bank_arb;
  localparam int NR = 4;
  localparam int RW = 3;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  int cyc = 0, errors = 0;
  always @(posedge clk) cyc <= cyc + 1;

  logic [NR-1:0]    rd_req, rd_urg;
  logic [NR*RW-1:0] rd_row;
  logic             wr_req, wr_force;
  logic [RW-1:0]    wr_row;
  logic [1:0]       wr_ok;
  logic [1:0]       wr_go;
  logic [NR-1:0]    gnt [0:1];
  logic [NR-1:0]    blk [0:1];
  logic [1:0]       any, conf;
  logic [RW-1:0]    rowg [0:1];

  for (genvar m = 0; m < 2; m++) begin : g_dut
    /* verilator lint_off PINCONNECTEMPTY */
    tob_bank_arb #(.NR(NR), .PORT_MODE(m), .RW(RW)) u (
      .clk(clk), .rst_n(rst_n), .rd_req(rd_req), .rd_urg(rd_urg), .rd_row(rd_row), .wr_req(wr_req), .wr_row(wr_row),
      .wr_force(wr_force), .wr_ok(wr_ok[m]), .wr_go(wr_go[m]), .rd_gnt(gnt[m]), .rd_any(any[m]), .rd_idx(),
      .rd_row_g(rowg[m]), .conflict(conf[m]), .rd_wr_blk(blk[m]));
    /* verilator lint_on PINCONNECTEMPTY */
    // single-bank system: the write goes when this bank allows it
    assign wr_go[m] = wr_req && wr_ok[m];
  end

  // reference model
  int ptr [0:1];
  int wait_cnt [0:1][0:NR-1];
  int max_wait [0:1];
  int n_hazard_cycles = 0, n_forced_hazard = 0, n_corw = 0;
  int unsigned rs = 32'h1234567;
  function automatic int unsigned rnd();
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5);
    return rs;
  endfunction

  always @(negedge clk) begin
    if (rst_n) begin
      for (int m = 0; m < 2; m++) begin
        logic [NR-1:0] hz, el, eg, cd;
        logic          eok;
        int            idx;
        for (int i = 0; i < NR; i++) hz[i] = (m == 0) ? rd_req[i] : (rd_req[i] && rd_row[i*RW +: RW] == wr_row);
        eok = !wr_req || hz == '0 || wr_force;
        el  = (wr_req && eok) ? (rd_req & ~hz) : rd_req;
        cd  = ((el & rd_urg) != '0) ? (el & rd_urg) : el;
        eg  = '0;
        for (int k = 0; k < NR; k++) begin
          idx = (ptr[m] + k) % NR;
          if (eg == '0 && cd[idx]) eg[idx] = 1'b1;
        end
        if (wr_ok[m] !== eok) `ERR(("mode %0d wr_ok %0d exp %0d", m, wr_ok[m], eok))
        if (gnt[m] !== eg)    `ERR(("mode %0d gnt %b exp %b (req %b ptr %0d)", m, gnt[m], eg, rd_req, ptr[m]))
        if (blk[m] !== ((wr_req && eok) ? hz : '0)) `ERR(("mode %0d rd_wr_blk", m))
        if (conf[m] !== ($countones(el) >= 2)) `ERR(("mode %0d conflict flag", m))
        // the physical rule itself
        if (wr_go[m] && any[m]) begin
          if (m == 0) `ERR(("1RW: read and write granted together"))
          else if (rowg[m] == wr_row) `ERR(("1R1W: same-row read and write granted together"))
          else n_corw = n_corw + 1;
        end
        if (m == 1 && wr_req && (hz != '0)) begin
          n_hazard_cycles = n_hazard_cycles + 1;
          if (wr_force) n_forced_hazard = n_forced_hazard + 1;
        end
      end
    end
  end
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int m = 0; m < 2; m++) begin
        ptr[m] = 0; max_wait[m] = 0;
        for (int i = 0; i < NR; i++) wait_cnt[m][i] = 0;
      end
    end else begin
      for (int m = 0; m < 2; m++) begin
        for (int i = 0; i < NR; i++) begin
          if (gnt[m][i]) ptr[m] = (i + 1) % NR;
        end
      end
    end
  end

  // fairness: with no writes, a requester that keeps requesting is served within NR-1 cycles
  int fair_wait [0:NR-1];
  int fair_max = 0;
  logic fair_phase = 0;
  always @(posedge clk) begin
    if (fair_phase) begin
      for (int i = 0; i < NR; i++) begin
        if (rd_req[i] && !gnt[1][i]) fair_wait[i] = fair_wait[i] + 1; else fair_wait[i] = 0;
        if (fair_wait[i] > fair_max) fair_max = fair_wait[i];
      end
    end else for (int i = 0; i < NR; i++) fair_wait[i] = 0;
  end

  logic [NR-1:0] urg_next = '1;
  task automatic drive(input logic [NR-1:0] rq, input logic [NR*RW-1:0] rr, input logic wq, input logic [RW-1:0] wrw, input logic f);
    @(negedge clk);
    #1;
    rd_req = rq; rd_row = rr; wr_req = wq; wr_row = wrw; wr_force = f; rd_urg = urg_next;
  endtask

  initial begin
    rd_req = '0; rd_row = '0; wr_req = 0; wr_row = '0; wr_force = 0; rd_urg = '1;
    repeat (3) @(negedge clk);
    rst_n = 1;
    // directed: same-row hazard, not forced -> write waits (1R1W) ; forced -> read blocked
    drive(4'b0001, {3'd0, 3'd0, 3'd0, 3'd5}, 1'b1, 3'd5, 1'b0);
    drive(4'b0001, {3'd0, 3'd0, 3'd0, 3'd5}, 1'b1, 3'd5, 1'b1);
    drive(4'b0011, {3'd0, 3'd0, 3'd2, 3'd5}, 1'b1, 3'd5, 1'b1);   // reader 1 (row 2) proceeds with the write
    drive(4'b0001, {3'd0, 3'd0, 3'd0, 3'd4}, 1'b1, 3'd5, 1'b0);   // different rows: both proceed under 1R1W
    // fairness phase: all four request continuously, no writes
    fair_phase = 1;
    for (int c = 0; c < 200; c++) begin
      logic [NR*RW-1:0] rr;
      rr = (NR*RW)'(rnd());
      drive(4'b1111, rr, 1'b0, 3'd0, 1'b0);
    end
    for (int c = 0; c < 500; c++) begin
      logic [NR-1:0] rq;
      rq = 4'(rnd()) | 4'b0001;
      drive(rq, '0, 1'b0, 3'd0, 1'b0);
    end
    fair_phase = 0;
    // urgency: one urgent requester beats every prefetch requester
    urg_next = 4'b1000;
    drive(4'b1111, '0, 1'b0, 3'd0, 1'b0);
    drive(4'b1111, '0, 1'b0, 3'd0, 1'b0);
    // random everything (random urgency)
    for (int c = 0; c < 20000; c++) begin
      logic [NR*RW-1:0] rr;
      logic [NR-1:0] rq;
      logic          wq, f;
      logic [RW-1:0] wrw;
      for (int i = 0; i < NR; i++) rr[i*RW +: RW] = 3'(rnd() % 3);   // few rows: frequent hazards
      rq  = 4'(rnd());
      wq  = (rnd() % 3) != 0;
      wrw = 3'(rnd() % 3);
      f   = (rnd() % 4) == 0;
      urg_next = 4'(rnd());
      drive(rq, rr, wq, wrw, f);
    end
    drive('0, '0, 1'b0, '0, 1'b0);
    repeat (2) @(negedge clk);
    $display("SUMMARY arb hazard_cycles=%0d forced_hazards=%0d co_issued_rw_1r1w=%0d rr_max_wait=%0d (bound %0d)",
             n_hazard_cycles, n_forced_hazard, n_corw, fair_max, NR - 1);
    if (fair_max > NR - 1) `ERR(("round-robin wait %0d exceeds NR-1", fair_max))
    if (n_hazard_cycles == 0 || n_forced_hazard == 0 || n_corw == 0) `ERR(("coverage: hazard scenarios not reached"))
    if (errors == 0) $display("RESULT: PASS"); else $display("RESULT: FAIL (%0d errors)", errors);
    $finish;
  end
endmodule
