// =============================================================================
// SilicaFlux TENSORCORE 03 :: tb_tob_array
// Integration test: DMA -> tensor_operand_buffer -> tensor_systolic_array
// (TENSORCORE 02, unmodified, third_party/) -> C, compared with a reference
// INT8 x INT8 -> INT32 matrix multiplication computed here.
//
//   * glue: tile_rsp (eff_m, eff_n, eff_k) launches the array (cfg_*); the
//     buffer's k-slices drive s_valid/s_a/s_b; the array's s_ready drives the
//     buffer's s_ready.  At every slice handshake the buffer's s_k must equal
//     the index the array expects (its s_k output), and the array's own
//     alignment checker (align_err) must stay 0;
//   * problems with partial tiles (M, N, K not multiples of the array size),
//     padded leading dimensions, unaligned bases, and K split across tiles
//     (partial results accumulated here);
//   * random stall_i and m_ready back-pressure on the array;
//   * the same problem sequence is run twice:
//       OVERLAP    fill of problem p+1 (other set) while problem p computes
//       SERIAL     fill p+1 only after problem p has finished
//     and both runs must be bit-exact; cycle counts and the counted overlap
//     (cycles with a DMA write and a slice handshake) are reported.
// =============================================================================
`timescale 1ns/1ps
`include "tob_defs.svh"
`define ERR(args) begin errors = errors + 1; $write("ERROR cyc=%0d: ", cyc); $display args ; if (errors > 30) $finish; end
`define HS_BEGIN(v, r) @(negedge clk); v <= 1'b1; #1; while (!(r)) begin @(negedge clk); #1; end
`define HS_END(v) @(negedge clk); v <= 1'b0;

module tb_tob_array;
  parameter int R     = 4;
  parameter int C     = 4;
  parameter int PMODE = 1;
  parameter int RL    = 1;
  parameter int SMAP  = 0;
  parameter int STALL = 10;       // % cycles with stall_i
  localparam int WB = 4, DW = 32, AW = 32, KW = 17, TAGW = 8, IDXW = 16, NS = 2;
  localparam int ASB = 4096, BSB = 4096;
  localparam int RMW = $clog2(R + 1), CNW = $clog2(C + 1), RIDW = (R > 1) ? $clog2(R) : 1;
  localparam longint REG = longint'(NS) * ASB;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;

  // ------------------------------------------------------------ buffer ports
  logic dma_req_valid = 0, dma_req_ready, dma_req_we = 1;
  logic [AW-1:0] dma_req_addr; logic [DW-1:0] dma_req_wdata; logic [WB-1:0] dma_req_wstrb; logic [TAGW-1:0] dma_req_tag;
  logic dma_rsp_valid, dma_rsp_ready = 1, dma_rsp_err, dma_rsp_we; logic [DW-1:0] dma_rsp_rdata; logic [2:0] dma_rsp_err_code; logic [TAGW-1:0] dma_rsp_tag;
  logic fill_begin_valid = 0, fill_begin_ready, fill_end_valid = 0, fill_end_ready, cmp_begin_valid = 0, cmp_begin_ready, cmp_end_valid = 0, cmp_end_ready;
  logic fill_set, cmp_set; logic [3:0] set_state;
  logic tile_valid = 0, tile_ready;
  logic [AW-1:0] tile_a_addr, tile_lda, tile_b_addr, tile_ldb;
  logic [IDXW-1:0] tile_m0, tile_n0, tile_mat_m, tile_mat_n; logic [KW-1:0] tile_k0, tile_mat_k, tile_k; logic [TAGW-1:0] tile_tag;
  logic tile_rsp_valid, tile_rsp_ready, tile_rsp_err; logic [TAGW-1:0] tile_rsp_tag; logic [3:0] tile_rsp_code;
  logic [RMW-1:0] tile_rsp_m; logic [CNW-1:0] tile_rsp_n; logic [KW-1:0] tile_rsp_k;
  logic s_valid, s_ready, s_first, s_last; logic [R*8-1:0] s_a; logic [C*8-1:0] s_b; logic [KW-1:0] s_k, s_kg;
  logic [IDXW-1:0] s_m0, s_n0; logic [R-1:0] s_row_mask; logic [C-1:0] s_col_mask; logic [TAGW-1:0] s_tag; logic s_set;
  logic busy, engine_idle; logic [`TOB_NUM_EV*8-1:0] ev_inc; logic [R-1:0] evc; logic [`TOB_NUM_EV*32-1:0] perf_cnt;

  tensor_operand_buffer #(
    .ARRAY_ROWS(R), .ARRAY_COLS(C), .WORD_BYTES(WB), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB), .A_BANKS(4), .B_BANKS(2),
    .NUM_SETS(NS), .SET_MAP(SMAP), .PORT_MODE(PMODE), .READ_LATENCY(RL), .A_STAGE(2), .B_STAGE(4),
    .ADDR_W(AW), .K_W(KW), .TAG_W(TAGW), .IDX_W(IDXW)
  ) u_buf (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr),
    .dma_req_wdata(dma_req_wdata), .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag),
    .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(dma_rsp_ready), .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_err(dma_rsp_err),
    .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid),
    .fill_end_ready(fill_end_ready), .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready),
    .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready), .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr),
    .tile_ldb(tile_ldb), .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n),
    .tile_mat_k(tile_mat_k), .tile_k(tile_k), .tile_tag(tile_tag),
    .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(tile_rsp_ready), .tile_rsp_tag(tile_rsp_tag), .tile_rsp_err(tile_rsp_err),
    .tile_rsp_code(tile_rsp_code), .tile_rsp_m(tile_rsp_m), .tile_rsp_n(tile_rsp_n), .tile_rsp_k(tile_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_row_mask), .s_col_mask(s_col_mask), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .busy(busy), .engine_idle(engine_idle), .ev_inc(ev_inc), .ev_bank_conflict_a(evc), .perf_clear(1'b0), .perf_cnt(perf_cnt)
  );

  // ------------------------------------------------------------ array (TENSORCORE 02, unmodified)
  logic cfg_valid, cfg_ready, cfg_reject, stall_i = 0, m_valid, m_ready = 1, m_last, a_busy, tile_done, align_err;
  logic [KW-1:0] arr_s_k;
  logic [RIDW-1:0] m_row; logic [C*32-1:0] m_data; logic [C-1:0] m_col_mask;
  logic [39:0] p_busy, p_issue, p_stall_up, p_stall_ext, p_mac, p_pad;

  assign cfg_valid      = tile_rsp_valid && !tile_rsp_err;
  assign tile_rsp_ready = tile_rsp_err ? 1'b1 : cfg_ready;

  tensor_systolic_array #(.ARRAY_ROWS(R), .ARRAY_COLS(C), .DATA_WIDTH(8), .ACC_WIDTH(32), .K_WIDTH(KW)) u_arr (
    .clk(clk), .rst_n(rst_n),
    .cfg_valid(cfg_valid), .cfg_ready(cfg_ready), .cfg_m(tile_rsp_m), .cfg_n(tile_rsp_n), .cfg_k(tile_rsp_k), .cfg_reject(cfg_reject),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(arr_s_k), .stall_i(stall_i),
    .m_valid(m_valid), .m_ready(m_ready), .m_row(m_row), .m_data(m_data), .m_col_mask(m_col_mask), .m_last(m_last),
    .busy(a_busy), .tile_done(tile_done), .align_err(align_err),
    .perf_busy(p_busy), .perf_issue(p_issue), .perf_stall_up(p_stall_up), .perf_stall_ext(p_stall_ext), .perf_mac(p_mac), .perf_pad(p_pad)
  );

  int unsigned rs [0:3];
  function automatic int unsigned rnd(input int k);
    int unsigned x; x = rs[k]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[k] = x; return x;
  endfunction
  always @(posedge clk) begin
    stall_i <= (int'(rnd(1) % 100) < STALL);
    m_ready <= (int'(rnd(2) % 100) >= 20);
  end

  // ------------------------------------------------------------ checks at the buffer/array boundary
  always @(posedge clk) if (rst_n) begin
    if (s_valid && s_ready && s_k !== arr_s_k) `ERR(("buffer s_k %0d != array expected k %0d", s_k, arr_s_k))
    if (align_err) `ERR(("array align_err"))
    if (cfg_reject) `ERR(("array rejected a configuration produced by the buffer"))
    if (tile_rsp_valid && tile_rsp_ready && tile_rsp_err) `ERR(("tile rejected: code %0d", tile_rsp_code))
  end

  // ------------------------------------------------------------ DMA agent (writes only, all must succeed)
  localparam int DQN = 8192;
  logic [AW-1:0] dq_addr [0:DQN-1]; logic [DW-1:0] dq_data [0:DQN-1]; logic [WB-1:0] dq_strb [0:DQN-1];
  int dq_tail = 0, dq_head = 0, dr = 0;
  always @(posedge clk) begin
    if (!rst_n) dma_req_valid <= 0;
    else begin
      if (dma_req_valid && dma_req_ready) dq_head = dq_head + 1;
      if (!dma_req_valid || dma_req_ready) begin
        if (dq_head != dq_tail) begin
          dma_req_valid <= 1; dma_req_addr <= dq_addr[dq_head % DQN]; dma_req_wdata <= dq_data[dq_head % DQN];
          dma_req_wstrb <= dq_strb[dq_head % DQN]; dma_req_tag <= TAGW'(dq_head);
        end else dma_req_valid <= 0;
      end
    end
  end
  always @(posedge clk) if (rst_n && dma_rsp_valid && dma_rsp_ready) begin
    if (dma_rsp_err) `ERR(("DMA write error code %0d", dma_rsp_err_code))
    dr = dr + 1;
  end

  // ------------------------------------------------------------ problems
  localparam int NP = 4;
  int pm [0:NP-1], pn [0:NP-1], pk [0:NP-1], plda [0:NP-1], pldb [0:NP-1], pa [0:NP-1], pb [0:NP-1], pkt [0:NP-1];
  logic signed [7:0] A [0:NP-1][0:63][0:255];
  logic signed [7:0] B [0:NP-1][0:255][0:63];
  logic signed [31:0] Cacc [0:63][0:63];

  task automatic gen_problem(input int p);
    pm[p] = (p % 2 == 0) ? 10 : 16;
    pn[p] = (p % 2 == 0) ? 7 : 16;
    pk[p] = (p % 2 == 0) ? 45 : 128;
    plda[p] = pk[p] + ((p % 2 == 0) ? 3 : 0);
    pldb[p] = pn[p] + ((p % 2 == 0) ? 1 : 0);
    pa[p] = (p % 2 == 0) ? 5 : 0;
    pb[p] = (p % 2 == 0) ? 2 : 0;
    pkt[p] = (p < 2) ? pk[p] : 32;              // problems 2, 3: K split into chunks of 32
    for (int i = 0; i < pm[p]; i++) for (int k = 0; k < pk[p]; k++) A[p][i][k] = 8'(rnd(0));
    for (int k = 0; k < pk[p]; k++) for (int j = 0; j < pn[p]; j++) B[p][k][j] = 8'(rnd(0));
  endtask

  // DMA image of problem p into set s (bytes outside the matrices are written as 0)
  task automatic dma_problem(input int p, input int s);
    logic [7:0] img [0:4095];
    for (int x = 0; x < ASB; x++) img[x] = 8'h00;
    for (int i = 0; i < pm[p]; i++) for (int k = 0; k < pk[p]; k++) img[pa[p] + i * plda[p] + k] = A[p][i][k];
    for (int w = 0; w < (pa[p] + pm[p] * plda[p] + WB - 1) / WB; w++) begin
      while (dq_tail - dr >= DQN - 1) @(negedge clk);
      dq_addr[dq_tail % DQN] = AW'(longint'(s) * ASB + w * WB);
      dq_data[dq_tail % DQN] = {img[w*4+3], img[w*4+2], img[w*4+1], img[w*4]};
      dq_strb[dq_tail % DQN] = '1;
      dq_tail = dq_tail + 1;
    end
    for (int x = 0; x < BSB; x++) img[x] = 8'h00;
    for (int k = 0; k < pk[p]; k++) for (int j = 0; j < pn[p]; j++) img[pb[p] + k * pldb[p] + j] = B[p][k][j];
    for (int w = 0; w < (pb[p] + pk[p] * pldb[p] + WB - 1) / WB; w++) begin
      while (dq_tail - dr >= DQN - 1) @(negedge clk);
      dq_addr[dq_tail % DQN] = AW'(REG + longint'(s) * BSB + w * WB);
      dq_data[dq_tail % DQN] = {img[w*4+3], img[w*4+2], img[w*4+1], img[w*4]};
      dq_strb[dq_tail % DQN] = '1;
      dq_tail = dq_tail + 1;
    end
  endtask
  task automatic dma_wait(); while (dr != dq_tail) @(negedge clk); endtask

  // tile issue (descriptor queue) and result collection
  localparam int TQN = 1024;
  int tq_m0 [0:TQN-1], tq_n0 [0:TQN-1], tq_k0 [0:TQN-1], tq_p [0:TQN-1];
  int tq_tail = 0, tq_head = 0, lq_head = 0, done_tiles = 0;
  always @(posedge clk) begin
    if (!rst_n) tile_valid <= 0;
    else begin
      if (tile_valid && tile_ready) tq_head = tq_head + 1;
      if (!tile_valid || tile_ready) begin
        if (tq_head != tq_tail) begin
          int t, p;
          t = tq_head % TQN; p = tq_p[t];
          tile_valid <= 1;
          tile_a_addr <= AW'(pa[p]); tile_lda <= AW'(plda[p]); tile_b_addr <= AW'(pb[p]); tile_ldb <= AW'(pldb[p]);
          tile_m0 <= IDXW'(tq_m0[t]); tile_n0 <= IDXW'(tq_n0[t]); tile_k0 <= KW'(tq_k0[t]);
          tile_mat_m <= IDXW'(pm[p]); tile_mat_n <= IDXW'(pn[p]); tile_mat_k <= KW'(pk[p]); tile_k <= KW'(pkt[p]);
          tile_tag <= TAGW'(tq_head);
        end else tile_valid <= 0;
      end
    end
  end
  // the array completes tiles in launch order: accumulate each readout row into C
  always @(posedge clk) if (rst_n && m_valid && m_ready) begin
    int t;
    t = lq_head % TQN;
    for (int j = 0; j < C; j++)
      if (m_col_mask[j]) Cacc[tq_m0[t] + m_row][tq_n0[t] + j] = Cacc[tq_m0[t] + m_row][tq_n0[t] + j] + $signed(m_data[j*32 +: 32]);
    if (m_last) begin lq_head = lq_head + 1; done_tiles = done_tiles + 1; end
  end

  task automatic issue_problem(input int p);
    for (int i = 0; i < 64; i++) for (int j = 0; j < 64; j++) Cacc[i][j] = 0;
    for (int m0 = 0; m0 < pm[p]; m0 = m0 + R)
      for (int n0 = 0; n0 < pn[p]; n0 = n0 + C)
        for (int k0 = 0; k0 < pk[p]; k0 = k0 + pkt[p]) begin
          tq_m0[tq_tail % TQN] = m0; tq_n0[tq_tail % TQN] = n0; tq_k0[tq_tail % TQN] = k0; tq_p[tq_tail % TQN] = p;
          tq_tail = tq_tail + 1;
        end
  endtask
  task automatic wait_problem();
    while (lq_head != tq_tail) @(negedge clk);
  endtask
  int checked = 0;
  task automatic check_problem(input int p);
    longint ref_c;
    for (int i = 0; i < pm[p]; i++) for (int j = 0; j < pn[p]; j++) begin
      ref_c = 0;
      for (int k = 0; k < pk[p]; k++) ref_c = ref_c + longint'(A[p][i][k]) * longint'(B[p][k][j]);
      if (Cacc[i][j] !== 32'(ref_c)) `ERR(("problem %0d C[%0d][%0d] = %0d, reference %0d", p, i, j, Cacc[i][j], ref_c))
      checked = checked + 1;
    end
  endtask

  task automatic fill_begin(); `HS_BEGIN(fill_begin_valid, fill_begin_ready) `HS_END(fill_begin_valid) endtask
  task automatic fill_end();   `HS_BEGIN(fill_end_valid, fill_end_ready)     `HS_END(fill_end_valid)   endtask
  task automatic cmp_begin();  `HS_BEGIN(cmp_begin_valid, cmp_begin_ready)   `HS_END(cmp_begin_valid)  endtask
  task automatic cmp_end();    `HS_BEGIN(cmp_end_valid, cmp_end_ready)       `HS_END(cmp_end_valid)    endtask

  longint overlap_ev = 0, slices_ev = 0;
  always @(posedge clk) if (rst_n) begin
    overlap_ev = overlap_ev + ev_inc[`TOB_EV_OVERLAP*8 +: 8];
    slices_ev  = slices_ev + ev_inc[`TOB_EV_SLICES*8 +: 8];
  end

  task automatic run(input bit overlap, output longint cycles, output longint ov);
    longint t0, o0;
    t0 = cyc; o0 = overlap_ev;
    fill_begin(); dma_problem(0, 0); dma_wait(); fill_end();
    for (int p = 0; p < NP; p++) begin
      cmp_begin();
      issue_problem(p);
      if (p + 1 < NP && overlap) begin fill_begin(); dma_problem(p + 1, (p + 1) % 2); end
      wait_problem();
      while (tq_head != tq_tail) @(negedge clk);
      cmp_end();
      check_problem(p);
      if (p + 1 < NP) begin
        if (!overlap) begin fill_begin(); dma_problem(p + 1, (p + 1) % 2); end
        dma_wait(); fill_end();
      end
    end
    cycles = cyc - t0;
    ov = overlap_ev - o0;
  endtask

  longint c_ov, c_ser, ov_ov, ov_ser;
  initial begin
    rs[0] = 32'h2545F491; rs[1] = 32'h9E3779B9; rs[2] = 32'h85EBCA6B; rs[3] = 32'hC2B2AE35;
    for (int p = 0; p < NP; p++) gen_problem(p);
    repeat (3) @(negedge clk);
    rst_n = 1;
    run(1'b1, c_ov, ov_ov);
    run(1'b0, c_ser, ov_ser);
    $display("INTEG R=%0d C=%0d PMODE=%0d RL=%0d SMAP=%0d STALL=%0d problems=%0d tiles=%0d C_elements_checked=%0d slices=%0d overlap_run_cycles=%0d overlap_cycles=%0d serial_run_cycles=%0d serial_overlap_cycles=%0d speedup=%0.3f",
             R, C, PMODE, RL, SMAP, STALL, 2 * NP, done_tiles, checked, slices_ev, c_ov, ov_ov, c_ser, ov_ser, real'(c_ser) / real'(c_ov));
    if (ov_ov == 0) `ERR(("overlapped run: no cycle had a DMA write and a slice handshake together"))
    if (ov_ser != 0) `ERR(("serial run: unexpected overlap"))
    if (errors == 0) $display("RESULT: PASS"); else $display("RESULT: FAIL (%0d errors)", errors);
    $finish;
  end
  initial begin #(64'd200000000); $display("RESULT: FAIL (timeout)"); $finish; end
endmodule
