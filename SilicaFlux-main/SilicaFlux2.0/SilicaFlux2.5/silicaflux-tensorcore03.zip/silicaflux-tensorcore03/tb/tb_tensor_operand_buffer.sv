// =============================================================================
// SilicaFlux TENSORCORE 03 :: tb_tensor_operand_buffer
// Self-checking testbench of tensor_operand_buffer (Verilator --timing and
// Icarus 12).  Every check compares the DUT with an independent model:
//
//   * byte-accurate reference memory  ref_a / ref_b  (NUM_SETS x SET_BYTES
//     bytes each, initialised to X: a test that reads a byte it never wrote
//     is itself reported as an error);
//   * DMA agent: request queue + driver (random gaps), in-order response
//     checker (tag, code, we, rdata = 0); the reference memory is updated
//     with the strobed bytes when a write is ACKNOWLEDGED;
//   * ownership model of every set (EMPTY/FILL/READY/COMPUTE, ping-pong
//     pointers) compared with set_state on every falling edge;
//   * tile agent: descriptor queue + driver; expected response (code,
//     eff_m/n/k) computed from the matrix contract with 64-bit arithmetic;
//   * slice checker: EVERY delivered slice is compared field by field
//     (s_a, s_b, s_k, s_kg, s_m0, s_n0, masks, first, last, tag, set) with
//     A[m0+i][k0+k] / B[k0+k][n0+j] read from the reference memory, using
//     4-state !== (an X from a mis-timed SRAM read - SRAMLIB_POISON - fails);
//     slices must be held stable under back-pressure;
//   * event/counter checker: every perf counter equals the sum of its ev_inc
//     field; slices, writes, errors, tiles, array back-pressure and the A / B
//     words read equal independently computed numbers;
//   * fairness monitors: max consecutive wait of an A lane request and of a
//     DMA write (bounded), same-cycle read+write per bank (counted).
//
// Plusargs: +test=<name> +seed=<n> +bp=<% s_ready low> +gap=<% DMA idle>
//           +rbp=<% response ready low> +tiles=<n> +full_rate (assert no
//           intra-tile bubble) +verbose
// Tests: smoke banks seq stride concurrent partial switch contention owner
//        range rdw starve align reset random perf bw all
// =============================================================================
`timescale 1ns/1ps
`include "tob_defs.svh"

`define ERR(args) begin errors = errors + 1; $write("ERROR cyc=%0d: ", cyc); $display args ; if (errors > 40) begin $display("too many errors"); $finish; end end

// Test-thread handshakes: inputs change only on the falling edge (+1 ns), ready is
// sampled there, the transfer happens at the next rising edge, valid drops at the
// following falling edge.  (Verilator --timing makes an NBA from a coroutine resumed
// at a rising edge visible to that same edge; falling-edge driving is portable.)
`define HS_BEGIN(v, r) @(negedge clk); v <= 1'b1; #1; while (!(r)) begin @(negedge clk); #1; end
`define HS_END(v) @(negedge clk); v <= 1'b0;

module tb_tensor_operand_buffer;
  // ------------------------------------------------------------ DUT configuration
  parameter int     R       = 4;
  parameter int     C       = 4;
  parameter int     WB      = 4;
  parameter int     ASB     = 4096;
  parameter int     BSB     = 4096;
  parameter int     NBA     = 4;
  parameter int     NBB     = 2;
  parameter int     REPL    = 1;
  parameter int     NS      = 2;
  parameter int     SMAP    = 0;
  parameter int     PMODE   = 1;
  parameter int     RL      = 1;
  parameter int     AST     = 2;
  parameter int     BST     = 4;
  parameter int     WSL     = 8;
  parameter int     AW      = 32;
  parameter longint BASE    = 0;
  parameter int     IDXW    = 16;
  parameter int     KW      = 17;
  parameter int     TAGW    = 8;
  parameter int     RSPD    = 4;
  parameter int     BACKEND = 0;
  parameter int     CNTW    = 32;

  localparam int     DW    = 8 * WB;
  localparam int     SW    = 1;
  localparam int     RMW   = $clog2(R + 1);
  localparam int     CNW   = $clog2(C + 1);
  localparam longint ATOT  = longint'(NS) * ASB;
  localparam longint BTOT  = longint'(NS) * BSB;
  localparam longint REG   = (ATOT > BTOT) ? ATOT : BTOT;
  localparam int     EVW   = 8;
  localparam int     NEV   = `TOB_NUM_EV;
  localparam int     GRP   = (SMAP == 1 && NS == 2) ? 2 : 1;
  localparam int     NPA   = GRP * REPL * NBA;
  localparam int     NPB   = GRP * NBB;
  localparam int     NWB   = (C + 2 * WB - 2) / WB;
  localparam longint AMAX  = longint'(1) << AW;

  // ------------------------------------------------------------ signals
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  logic              dma_req_valid = 0, dma_req_ready, dma_req_we = 0;
  logic [AW-1:0]     dma_req_addr = '0;
  logic [DW-1:0]     dma_req_wdata = '0;
  logic [WB-1:0]     dma_req_wstrb = '0;
  logic [TAGW-1:0]   dma_req_tag = '0;
  logic              dma_rsp_valid, dma_rsp_ready = 1, dma_rsp_err, dma_rsp_we;
  logic [DW-1:0]     dma_rsp_rdata;
  logic [2:0]        dma_rsp_err_code;
  logic [TAGW-1:0]   dma_rsp_tag;
  logic              fill_begin_valid = 0, fill_begin_ready, fill_end_valid = 0, fill_end_ready;
  logic              cmp_begin_valid = 0, cmp_begin_ready, cmp_end_valid = 0, cmp_end_ready;
  logic [SW-1:0]     fill_set, cmp_set;
  logic [NS*2-1:0]   set_state;
  logic              tile_valid = 0, tile_ready;
  logic [AW-1:0]     tile_a_addr = '0, tile_lda = '0, tile_b_addr = '0, tile_ldb = '0;
  logic [IDXW-1:0]   tile_m0 = '0, tile_n0 = '0, tile_mat_m = '0, tile_mat_n = '0;
  logic [KW-1:0]     tile_k0 = '0, tile_mat_k = '0, tile_k = '0;
  logic [TAGW-1:0]   tile_tag = '0;
  logic              tile_rsp_valid, tile_rsp_ready = 1, tile_rsp_err;
  logic [TAGW-1:0]   tile_rsp_tag;
  logic [3:0]        tile_rsp_code;
  logic [RMW-1:0]    tile_rsp_m;
  logic [CNW-1:0]    tile_rsp_n;
  logic [KW-1:0]     tile_rsp_k;
  logic              s_valid, s_ready = 1, s_first, s_last;
  logic [R*8-1:0]    s_a;
  logic [C*8-1:0]    s_b;
  logic [KW-1:0]     s_k, s_kg;
  logic [IDXW-1:0]   s_m0, s_n0;
  logic [R-1:0]      s_row_mask;
  logic [C-1:0]      s_col_mask;
  logic [TAGW-1:0]   s_tag;
  logic [SW-1:0]     s_set;
  logic              busy, engine_idle, perf_clear = 0;
  logic [NEV*EVW-1:0]  ev_inc;
  logic [NPA-1:0]      ev_bank_conflict_a;
  logic [NEV*CNTW-1:0] perf_cnt;

  tensor_operand_buffer #(
    .ARRAY_ROWS(R), .ARRAY_COLS(C), .WORD_BYTES(WB), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB),
    .A_BANKS(NBA), .B_BANKS(NBB), .A_REPL(REPL), .NUM_SETS(NS), .SET_MAP(SMAP), .PORT_MODE(PMODE),
    .READ_LATENCY(RL), .A_STAGE(AST), .B_STAGE(BST), .WR_STARVE_LIMIT(WSL), .ADDR_W(AW),
    .DMA_BASE(BASE), .IDX_W(IDXW), .K_W(KW), .TAG_W(TAGW), .DMA_RSP_DEPTH(RSPD), .BACKEND(BACKEND),
    .PERF_EN(1), .CNT_W(CNTW)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr),
    .dma_req_wdata(dma_req_wdata), .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag),
    .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(dma_rsp_ready), .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_err(dma_rsp_err),
    .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid),
    .fill_end_ready(fill_end_ready), .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready),
    .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready), .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr),
    .tile_ldb(tile_ldb), .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n),
    .tile_mat_k(tile_mat_k), .tile_k(tile_k), .tile_tag(tile_tag),
    .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(tile_rsp_ready), .tile_rsp_tag(tile_rsp_tag), .tile_rsp_err(tile_rsp_err),
    .tile_rsp_code(tile_rsp_code), .tile_rsp_m(tile_rsp_m), .tile_rsp_n(tile_rsp_n), .tile_rsp_k(tile_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_row_mask), .s_col_mask(s_col_mask), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .busy(busy), .engine_idle(engine_idle), .ev_inc(ev_inc), .ev_bank_conflict_a(ev_bank_conflict_a),
    .perf_clear(perf_clear), .perf_cnt(perf_cnt)
  );

  // ------------------------------------------------------------ deterministic per-process RNG (xorshift32)
  // 0 test thread, 1 DMA driver, 2 tile driver, 3 s_ready, 4 rsp ready, 5 tile-rsp ready
  int unsigned rs [0:7];
  function automatic int unsigned rnd(input int k);
    int unsigned x;
    x = rs[k];
    x = x ^ (x << 13);
    x = x ^ (x >> 17);
    x = x ^ (x << 5);
    rs[k] = x;
    return x;
  endfunction
  function automatic int urange(input int k, input int lo, input int hi);
    return lo + int'(rnd(k) % (hi - lo + 1));
  endfunction

  int errors = 0;
  int verbose = 0;
  int bp = 0, gap = 0, rbp = 0, tbp = 0;

  // ------------------------------------------------------------ reference memory and ownership model
  logic [7:0] ref_a [0:NS*ASB-1];
  logic [7:0] ref_b [0:NS*BSB-1];
  int tb_st [0:1];
  int tb_fp = 0, tb_cp = 0;

  // ============================================================ DMA agent
  localparam int DQN = 16384;
  logic          dq_we   [0:DQN-1];
  logic [AW-1:0] dq_addr [0:DQN-1];
  logic [DW-1:0] dq_data [0:DQN-1];
  logic [WB-1:0] dq_strb [0:DQN-1];
  logic [2:0]    dq_exp  [0:DQN-1];
  int dq_tail = 0, dq_head = 0, dr_head = 0;
  int n_wr_ok = 0, n_dma_err = 0;
  int dma_hold_on = 0;                        // when 1 the driver presents nothing

  always @(posedge clk) begin
    if (!rst_n) begin
      dma_req_valid <= 1'b0;
    end else begin
      int unsigned r;
      r = rnd(1);                               // drawn every cycle: identical streams in every simulator
      if (dma_req_valid && dma_req_ready) dq_head = dq_head + 1;
      if (!dma_req_valid || dma_req_ready) begin
        if (dq_head != dq_tail && !dma_hold_on && int'(r % 100) >= gap) begin
          dma_req_valid <= 1'b1;
          dma_req_we    <= dq_we  [dq_head % DQN];
          dma_req_addr  <= dq_addr[dq_head % DQN];
          dma_req_wdata <= dq_data[dq_head % DQN];
          dma_req_wstrb <= dq_strb[dq_head % DQN];
          dma_req_tag   <= TAGW'(dq_head);
        end else begin
          dma_req_valid <= 1'b0;
          dma_req_wdata <= 'x;
          dma_req_addr  <= 'x;
        end
      end
    end
  end

  always @(posedge clk) dma_rsp_ready <= (int'(rnd(4) % 100) >= rbp);

  function automatic logic [2:0] dma_expect(input logic we, input longint addr);
    longint off;
    int     set;
    bit     ina, inb;
    if (addr < BASE) return `TOB_DERR_RANGE;
    off = addr - BASE;
    ina = (off < ATOT);
    inb = (off >= REG) && (off < REG + BTOT);
    if (!ina && !inb) return `TOB_DERR_RANGE;
    if (off % WB != 0) return `TOB_DERR_ALIGN;
    if (!we) return `TOB_DERR_UNSUP;
    set = ina ? int'(off / ASB) : int'((off - REG) / BSB);
    if (tb_st[set] != 1) return `TOB_DERR_OWNER;
    return `TOB_DERR_OK;
  endfunction

  task automatic dma_push(input logic we, input longint addr, input logic [DW-1:0] data, input logic [WB-1:0] strb);
    while (dq_tail - dr_head >= DQN - 1) @(negedge clk);
    dq_we  [dq_tail % DQN] = we;
    dq_addr[dq_tail % DQN] = AW'(addr);
    dq_data[dq_tail % DQN] = data;
    dq_strb[dq_tail % DQN] = strb;
    dq_exp [dq_tail % DQN] = dma_expect(we, addr);
    dq_tail = dq_tail + 1;
  endtask

  // response checker; the reference memory follows acknowledged writes
  always @(posedge clk) begin
    if (rst_n && dma_rsp_valid && dma_rsp_ready) begin
      int     ix;
      longint off;
      ix = dr_head % DQN;
      if (dr_head >= dq_head) `ERR(("DMA response without an accepted request"))
      else begin
        if (dma_rsp_tag !== TAGW'(dr_head))   `ERR(("DMA rsp tag %0h exp %0h", dma_rsp_tag, TAGW'(dr_head)))
        if (dma_rsp_err_code !== dq_exp[ix])  `ERR(("DMA rsp code %0d exp %0d (addr %0h we %0d)", dma_rsp_err_code, dq_exp[ix], dq_addr[ix], dq_we[ix]))
        if (dma_rsp_err !== (dq_exp[ix] != 0)) `ERR(("DMA rsp err flag"))
        if (dma_rsp_we !== dq_we[ix])         `ERR(("DMA rsp we echo"))
        if (dma_rsp_rdata !== '0)             `ERR(("DMA rsp rdata not zero"))
        if (dq_exp[ix] == `TOB_DERR_OK) begin
          n_wr_ok = n_wr_ok + 1;
          off = longint'(dq_addr[ix]) - BASE;
          for (int b = 0; b < WB; b++) if (dq_strb[ix][b]) begin
            if (off < ATOT) ref_a[off + b]       = dq_data[ix][b*8 +: 8];
            else            ref_b[off - REG + b] = dq_data[ix][b*8 +: 8];
          end
        end else n_dma_err = n_dma_err + 1;
      end
      dr_head = dr_head + 1;
    end
  end

  task automatic dma_wait();
    longint t0;
    t0 = cyc;
    while (dr_head != dq_tail && cyc - t0 <= 400000) @(negedge clk);
    if (dr_head != dq_tail) `ERR(("timeout waiting for DMA responses (%0d of %0d)", dr_head, dq_tail))
  endtask

  function automatic longint a_base(input int set); return BASE + longint'(set) * ASB; endfunction
  function automatic longint b_base(input int set); return BASE + REG + longint'(set) * BSB; endfunction

  // write random bytes into [lo, hi) of a set region (partial strobes at the edges)
  task automatic fill_rand(input bit isb, input int set, input longint lo, input longint hi);
    longint base, w;
    logic [DW-1:0] d;
    logic [WB-1:0] st;
    base = isb ? b_base(set) : a_base(set);
    for (w = lo / WB; w * WB < hi; w++) begin
      for (int b = 0; b < WB; b++) begin
        d[b*8 +: 8] = 8'(rnd(0));
        st[b]       = (w * WB + b >= lo) && (w * WB + b < hi);
      end
      dma_push(1'b1, base + w * WB, d, st);
    end
  endtask
  // random strobes over an already written range (bytes not strobed must keep their value)
  task automatic fill_rand_strobes(input bit isb, input int set, input longint lo, input longint hi);
    longint base, w;
    logic [DW-1:0] d;
    logic [WB-1:0] st;
    base = isb ? b_base(set) : a_base(set);
    for (w = lo / WB; w * WB < hi; w++) begin
      for (int b = 0; b < WB; b++) d[b*8 +: 8] = 8'(rnd(0));
      st = WB'(rnd(0));
      dma_push(1'b1, base + w * WB, d, st);
    end
  endtask
  task automatic fill_set_full(input int set);
    fill_rand(1'b0, set, 0, ASB);
    fill_rand(1'b1, set, 0, BSB);
  endtask

  // ============================================================ ownership agent
  task automatic do_fill_begin(output int set);
    `HS_BEGIN(fill_begin_valid, fill_begin_ready)
    set = int'(fill_set);
    `HS_END(fill_begin_valid)
    if (set != tb_fp || tb_st[set] != 0) `ERR(("fill_begin: set %0d (model fp %0d st %0d)", set, tb_fp, tb_st[set]))
    tb_st[tb_fp] = 1;
    set = tb_fp;
  endtask
  task automatic do_fill_end();
    `HS_BEGIN(fill_end_valid, fill_end_ready)
    `HS_END(fill_end_valid)
    if (tb_st[tb_fp] != 1) `ERR(("fill_end in model state %0d", tb_st[tb_fp]))
    tb_st[tb_fp] = 2;
    tb_fp = (tb_fp + 1) % NS;
  endtask
  task automatic do_cmp_begin(output int set);
    `HS_BEGIN(cmp_begin_valid, cmp_begin_ready)
    set = int'(cmp_set);
    `HS_END(cmp_begin_valid)
    if (set != tb_cp || tb_st[set] != 2) `ERR(("cmp_begin: set %0d (model cp %0d st %0d)", set, tb_cp, tb_st[set]))
    tb_st[tb_cp] = 3;
    set = tb_cp;
  endtask

  // ============================================================ tile agent
  localparam int TQN = 4096;
  longint tq_a [0:TQN-1], tq_lda [0:TQN-1], tq_b [0:TQN-1], tq_ldb [0:TQN-1];
  int     tq_m0 [0:TQN-1], tq_n0 [0:TQN-1], tq_k0 [0:TQN-1];
  int     tq_mm [0:TQN-1], tq_mn [0:TQN-1], tq_mk [0:TQN-1], tq_k [0:TQN-1];
  int     tq_code [0:TQN-1], tq_em [0:TQN-1], tq_en [0:TQN-1], tq_ek [0:TQN-1], tq_set [0:TQN-1];
  int     tq_tail = 0, tq_head = 0, tr_head = 0;
  int     sq [0:TQN-1];
  int     sq_tail = 0, sq_head = 0, s_kk = 0;
  longint exp_a_words = 0, exp_b_words = 0;
  int     n_tile_ok = 0, n_tile_err = 0, n_slices = 0;

  always @(posedge clk) begin
    if (!rst_n) begin
      tile_valid <= 1'b0;
    end else begin
      int unsigned r;
      r = rnd(2);
      if (tile_valid && tile_ready) tq_head = tq_head + 1;
      if (!tile_valid || tile_ready) begin
        if (tq_head != tq_tail && int'(r % 100) >= gap) begin
          int t;
          t = tq_head % TQN;
          tile_valid  <= 1'b1;
          tile_a_addr <= AW'(tq_a[t]);   tile_lda <= AW'(tq_lda[t]);
          tile_b_addr <= AW'(tq_b[t]);   tile_ldb <= AW'(tq_ldb[t]);
          tile_m0     <= IDXW'(tq_m0[t]); tile_n0  <= IDXW'(tq_n0[t]); tile_k0 <= KW'(tq_k0[t]);
          tile_mat_m  <= IDXW'(tq_mm[t]); tile_mat_n <= IDXW'(tq_mn[t]); tile_mat_k <= KW'(tq_mk[t]);
          tile_k      <= KW'(tq_k[t]);   tile_tag <= TAGW'(tq_head);
        end else begin
          tile_valid <= 1'b0;
        end
      end
    end
  end
  always @(posedge clk) tile_rsp_ready <= (int'(rnd(5) % 100) >= tbp);

  // expected response of a descriptor, with the ownership model at push time
  task automatic tile_eval(input int t);
    longint alast, blast;
    int em, en, ek;
    tq_em[t] = 0; tq_en[t] = 0; tq_ek[t] = 0;
    if (tb_st[tb_cp] != 3)                                                         tq_code[t] = `TOB_TERR_OWNER;
    else if (tq_m0[t] >= tq_mm[t] || tq_n0[t] >= tq_mn[t] || tq_k0[t] >= tq_mk[t] || tq_k[t] == 0) tq_code[t] = `TOB_TERR_EMPTY;
    else if (tq_lda[t] < tq_mk[t] || tq_ldb[t] < tq_mn[t])                         tq_code[t] = `TOB_TERR_LD;
    else begin
      em = (tq_mm[t] - tq_m0[t] < R) ? tq_mm[t] - tq_m0[t] : R;
      en = (tq_mn[t] - tq_n0[t] < C) ? tq_mn[t] - tq_n0[t] : C;
      ek = (tq_mk[t] - tq_k0[t] < tq_k[t]) ? tq_mk[t] - tq_k0[t] : tq_k[t];
      alast = tq_a[t] + longint'(tq_m0[t] + em - 1) * tq_lda[t] + tq_k0[t] + ek - 1;
      blast = tq_b[t] + longint'(tq_k0[t] + ek - 1) * tq_ldb[t] + tq_n0[t] + en - 1;
      if (alast >= AMAX)      tq_code[t] = `TOB_TERR_A_OVF;
      else if (alast >= ASB)  tq_code[t] = `TOB_TERR_A_RANGE;
      else if (blast >= AMAX) tq_code[t] = `TOB_TERR_B_OVF;
      else if (blast >= BSB)  tq_code[t] = `TOB_TERR_B_RANGE;
      else begin
        tq_code[t] = `TOB_TERR_OK;
        tq_em[t] = em; tq_en[t] = en; tq_ek[t] = ek;
      end
    end
    tq_set[t] = tb_cp;
  endtask

  task automatic tile_push(input longint a, input longint lda, input longint b, input longint ldb,
                           input int m0, input int n0, input int k0, input int mm, input int mn, input int mk, input int tk);
    int t;
    longint s;
    while (tq_tail - tr_head >= TQN - 1 || sq_tail - sq_head >= TQN - 1) @(negedge clk);
    t = tq_tail % TQN;
    tq_a[t] = a; tq_lda[t] = lda; tq_b[t] = b; tq_ldb[t] = ldb;
    tq_m0[t] = m0; tq_n0[t] = n0; tq_k0[t] = k0; tq_mm[t] = mm; tq_mn[t] = mn; tq_mk[t] = mk; tq_k[t] = tk;
    tile_eval(t);
    if (tq_code[t] == `TOB_TERR_OK) begin
      sq[sq_tail % TQN] = tq_tail;
      sq_tail = sq_tail + 1;
      for (int i = 0; i < tq_em[t]; i++) begin
        s = a + longint'(m0 + i) * lda + k0;
        exp_a_words = exp_a_words + ((s % WB) + tq_ek[t] - 1) / WB + 1;
      end
      for (int k = 0; k < tq_ek[t]; k++) begin
        s = b + longint'(k0 + k) * ldb + n0;
        exp_b_words = exp_b_words + ((s % WB) + tq_en[t] - 1) / WB + 1;
      end
    end
    tq_tail = tq_tail + 1;
  endtask

  // tile response checker
  always @(posedge clk) begin
    if (rst_n && tile_rsp_valid && tile_rsp_ready) begin
      int t;
      t = tr_head % TQN;
      if (tr_head >= tq_head) `ERR(("tile response without an accepted tile"))
      else begin
        if (tile_rsp_tag  !== TAGW'(tr_head))        `ERR(("tile rsp tag"))
        if (tile_rsp_code !== 4'(tq_code[t]))        `ERR(("tile %0d rsp code %0d exp %0d", tr_head, tile_rsp_code, tq_code[t]))
        if (tile_rsp_err  !== (tq_code[t] != 0))     `ERR(("tile rsp err flag"))
        if (tile_rsp_m !== RMW'(tq_em[t]) || tile_rsp_n !== CNW'(tq_en[t]) || tile_rsp_k !== KW'(tq_ek[t]))
          `ERR(("tile %0d rsp dims %0d %0d %0d exp %0d %0d %0d", tr_head, tile_rsp_m, tile_rsp_n, tile_rsp_k, tq_em[t], tq_en[t], tq_ek[t]))
        if (tq_code[t] == 0) n_tile_ok = n_tile_ok + 1; else n_tile_err = n_tile_err + 1;
      end
      tr_head = tr_head + 1;
    end
  end

  // ------------------------------------------------------------ slice checker
  function automatic logic [R*8-1:0] exp_sa(input int t, input int k);
    logic [R*8-1:0] v;
    longint a;
    for (int i = 0; i < R; i++) begin
      if (i < tq_em[t]) begin
        a = tq_a[t] + longint'(tq_m0[t] + i) * tq_lda[t] + tq_k0[t] + k;
        v[i*8 +: 8] = ref_a[longint'(tq_set[t]) * ASB + a];
      end else v[i*8 +: 8] = 8'h00;
    end
    return v;
  endfunction
  function automatic logic [C*8-1:0] exp_sb(input int t, input int k);
    logic [C*8-1:0] v;
    longint a;
    for (int j = 0; j < C; j++) begin
      if (j < tq_en[t]) begin
        a = tq_b[t] + longint'(tq_k0[t] + k) * tq_ldb[t] + tq_n0[t] + j;
        v[j*8 +: 8] = ref_b[longint'(tq_set[t]) * BSB + a];
      end else v[j*8 +: 8] = 8'h00;
    end
    return v;
  endfunction

  longint t_first = 0, bubbles = 0, max_bubble_tile = 0;
  logic   prev_hold = 0;
  logic [R*8-1:0] prev_a;
  logic [C*8-1:0] prev_b;
  logic [KW-1:0]  prev_k;
  int full_rate = 0;

  always @(posedge clk) begin
    if (!rst_n) prev_hold <= 1'b0;
    else begin
      if (prev_hold && (!s_valid || s_a !== prev_a || s_b !== prev_b || s_k !== prev_k))
        `ERR(("slice changed or dropped while back-pressured"))
      prev_hold <= s_valid && !s_ready;
      prev_a <= s_a; prev_b <= s_b; prev_k <= s_k;
      if (s_valid && s_ready) begin
        n_slices = n_slices + 1;
        if (sq_head == sq_tail) `ERR(("slice delivered but none expected"))
        else begin
          int t;
          logic [R*8-1:0] ea;
          logic [C*8-1:0] eb;
          logic [R-1:0]   rm;
          logic [C-1:0]   cm;
          t  = sq[sq_head % TQN] % TQN;
          ea = exp_sa(t, s_kk);
          eb = exp_sb(t, s_kk);
          for (int i = 0; i < R; i++) rm[i] = (i < tq_em[t]);
          for (int j = 0; j < C; j++) cm[j] = (j < tq_en[t]);
          if ($isunknown(ea) || $isunknown(eb)) `ERR(("TEST BUG: tile %0d reads unwritten reference bytes", sq[sq_head % TQN]))
          if (s_a !== ea) `ERR(("tile %0d k %0d s_a %h exp %h", sq[sq_head % TQN], s_kk, s_a, ea))
          if (s_b !== eb) `ERR(("tile %0d k %0d s_b %h exp %h", sq[sq_head % TQN], s_kk, s_b, eb))
          if (s_k !== KW'(s_kk) || s_kg !== KW'(tq_k0[t] + s_kk)) `ERR(("tile %0d k %0d s_k %0d s_kg %0d", sq[sq_head % TQN], s_kk, s_k, s_kg))
          if (s_m0 !== IDXW'(tq_m0[t]) || s_n0 !== IDXW'(tq_n0[t])) `ERR(("tile %0d origin", sq[sq_head % TQN]))
          if (s_row_mask !== rm || s_col_mask !== cm) `ERR(("tile %0d masks %b %b", sq[sq_head % TQN], s_row_mask, s_col_mask))
          if (s_first !== (s_kk == 0) || s_last !== (s_kk == tq_ek[t] - 1)) `ERR(("tile %0d k %0d first/last", sq[sq_head % TQN], s_kk))
          if (s_tag !== TAGW'(sq[sq_head % TQN]) || s_set !== SW'(tq_set[t])) `ERR(("tile %0d tag/set", sq[sq_head % TQN]))
          if (s_kk == 0) t_first = cyc;
          if (s_kk == tq_ek[t] - 1) begin
            longint bub;
            bub = (cyc - t_first + 1) - tq_ek[t];
            bubbles = bubbles + bub;
            if (bub > max_bubble_tile) max_bubble_tile = bub;
            if (full_rate && bub != 0) `ERR(("full-rate config: %0d bubbles inside tile %0d (K=%0d)", bub, sq[sq_head % TQN], tq_ek[t]))
            s_kk = 0;
            sq_head = sq_head + 1;
          end else s_kk = s_kk + 1;
        end
      end
    end
  end

  always @(posedge clk) s_ready <= (int'(rnd(3) % 100) >= bp);

  task automatic tiles_wait();
    longint t0;
    t0 = cyc;
    while ((sq_head != sq_tail || tr_head != tq_tail) && cyc - t0 <= 2000000) @(negedge clk);
    if (sq_head != sq_tail || tr_head != tq_tail)
      `ERR(("timeout waiting for slices (%0d/%0d tiles, %0d/%0d rsps)", sq_head, sq_tail, tr_head, tq_tail))
  endtask

  task automatic do_cmp_end();
    while (tq_head != tq_tail) @(negedge clk);   // every queued tile was accepted against this set
    `HS_BEGIN(cmp_end_valid, cmp_end_ready)
    `HS_END(cmp_end_valid)
    if (sq_head != sq_tail) `ERR(("cmp_end accepted with %0d tiles still undelivered", sq_tail - sq_head))
    if (tb_st[tb_cp] != 3) `ERR(("cmp_end in model state %0d", tb_st[tb_cp]))
    tb_st[tb_cp] = 0;
    tb_cp = (tb_cp + 1) % NS;
  endtask

  // ============================================================ continuous monitors
  // ownership state compared on the rising edge (the model changes on falling edges only)
  always @(posedge clk) begin
    if (rst_n) begin
      for (int s = 0; s < NS; s++)
        if (set_state[s*2 +: 2] !== 2'(tb_st[s])) `ERR(("set %0d state %0d model %0d", s, set_state[s*2 +: 2], tb_st[s]))
      if (fill_set !== SW'(tb_fp) || cmp_set !== SW'(tb_cp)) `ERR(("set pointers %0d/%0d model %0d/%0d", fill_set, cmp_set, tb_fp, tb_cp))
    end
  end

  // fairness: longest wait of an URGENT A lane request (bounded), of any lane request (reported) and of a legal
  // DMA write (bounded by WR_STARVE_LIMIT)
  int lane_wait [0:R-1];
  int any_wait [0:R-1];
  int max_lane_wait = 0, max_any_wait = 0, wr_wait = 0, max_wr_wait = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int i = 0; i < R; i++) begin lane_wait[i] = 0; any_wait[i] = 0; end
      wr_wait = 0;
    end else begin
      for (int i = 0; i < R; i++) begin
        if (dut.lane_req[i] && dut.lane_urg[i] && !dut.lane_gnt[i]) lane_wait[i] = lane_wait[i] + 1;
        else lane_wait[i] = 0;
        if (dut.lane_req[i] && !dut.lane_gnt[i]) any_wait[i] = any_wait[i] + 1;
        else any_wait[i] = 0;
        if (lane_wait[i] > max_lane_wait) max_lane_wait = lane_wait[i];
        if (any_wait[i] > max_any_wait) max_any_wait = any_wait[i];
      end
      if (dut.wr_valid && !dut.wr_go) wr_wait = wr_wait + 1; else wr_wait = 0;
      if (wr_wait > max_wr_wait) max_wr_wait = wr_wait;
    end
  end

  // same-cycle read and write in one physical bank (allowed by 1R1W, never by 1RW)
  longint rw_same_bank = 0;
  logic [NPA-1:0] a_rw;
  logic [NPB-1:0] b_rw;
  for (genvar p = 0; p < NPA; p++) begin : g_mon_a
    assign a_rw[p] = dut.g_abank[p].u_bank.wr_en && dut.g_abank[p].u_bank.rd_en;
  end
  for (genvar q = 0; q < NPB; q++) begin : g_mon_b
    assign b_rw[q] = dut.g_bbank[q].u_bank.wr_en && dut.g_bbank[q].u_bank.rd_en;
  end
  always @(posedge clk) if (rst_n) begin
    for (int p = 0; p < NPA; p++) if (a_rw[p]) rw_same_bank = rw_same_bank + 1;
    for (int q = 0; q < NPB; q++) if (b_rw[q]) rw_same_bank = rw_same_bank + 1;
    if (PMODE == 0 && (a_rw != '0 || b_rw != '0)) `ERR(("1RW bank given a read and a write in one cycle"))
  end

  // event accumulation (since the last perf_clear) and external counts
  longint ev_acc [0:NEV-1];
  longint n_bp_cycles = 0, n_cycles_since_clear = 0;
  always @(posedge clk) begin
    if (!rst_n || perf_clear) begin
      for (int e = 0; e < NEV; e++) ev_acc[e] = 0;
      n_bp_cycles = 0;
      n_cycles_since_clear = 0;
    end else begin
      for (int e = 0; e < NEV; e++) ev_acc[e] = ev_acc[e] + ev_inc[e*EVW +: EVW];
      if (s_valid && !s_ready) n_bp_cycles = n_bp_cycles + 1;
      n_cycles_since_clear = n_cycles_since_clear + 1;
    end
  end
  function automatic longint cnt(input int e);
    return longint'(perf_cnt[e*CNTW +: CNTW]);
  endfunction

  // edge numbers of the last tile acceptance / tile response / first and last slice handshakes
  longint e_tacc = 0, e_trsp = 0, e_sfirst = 0, e_slast = 0, e_dacc = 0, e_drsp = 0;
  always @(posedge clk) if (rst_n) begin
    if (tile_valid && tile_ready)            e_tacc   = cyc;
    if (tile_rsp_valid && tile_rsp_ready)    e_trsp   = cyc;
    if (s_valid && s_ready && s_first)       e_sfirst = cyc;
    if (s_valid && s_ready && s_last)        e_slast  = cyc;
    if (dma_req_valid && dma_req_ready)      e_dacc   = cyc;
    if (dma_rsp_valid && dma_rsp_ready)      e_drsp   = cyc;
  end

  // ============================================================ helpers
  task automatic reset_dut(input int ncyc);
    @(negedge clk);
    rst_n <= 1'b0;
    fill_begin_valid <= 0; fill_end_valid <= 0; cmp_begin_valid <= 0; cmp_end_valid <= 0;
    repeat (ncyc) @(negedge clk);
    // flush every agent: requests in flight at reset are discarded by the DUT
    dq_head = dq_tail; dr_head = dq_tail;
    tq_head = tq_tail; tr_head = tq_tail; sq_head = sq_tail; s_kk = 0;
    tb_st[0] = 0; tb_st[1] = 0; tb_fp = 0; tb_cp = 0;
    n_slices = 0; n_wr_ok = 0; n_dma_err = 0; n_tile_ok = 0; n_tile_err = 0; exp_a_words = 0; exp_b_words = 0;
    rst_n <= 1'b1;
    @(negedge clk);
  endtask

  // bring every set back to EMPTY with fill and compute pointers aligned
  task automatic drain_sets();
    int s;
    for (int i = 0; i < 2 * NS; i++) begin
      if (tb_st[tb_fp] == 1) do_fill_end();
      if (tb_st[tb_cp] == 3) do_cmp_end();
      else if (tb_st[tb_cp] == 2) begin do_cmp_begin(s); do_cmp_end(); end
    end
  endtask

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
  endtask

  // matrix layout chooser: returns lda for mode
  //   0 dense (= K), 1 dense + random pad, 2 pathological (multiple of WB*banks),
  //   3 conflict-free (word stride = banks + 1), 4 random large
  function automatic longint pick_ld(input int mode, input int width, input int banks);
    longint l;
    case (mode)
      0: l = width;
      1: l = width + urange(0, 0, 2 * WB);
      2: begin l = longint'(WB) * banks; while (l < width) l = l + longint'(WB) * banks; end
      3: begin l = longint'(WB) * (banks + 1); while (l < width) l = l + longint'(WB) * banks; end
      default: l = width + urange(0, 0, 64);
    endcase
    return l;
  endfunction

  // random valid problem inside the compute set; issues ntiles tiles over it
  task automatic random_tiles(input int ntiles, input int ldmode);
    int mm, mn, mk, m0, n0, k0, tk, mode;
    longint lda, ldb, a, b, afoot, bfoot;
    for (int t = 0; t < ntiles; t++) begin
      mode = (ldmode < 0) ? urange(0, 0, 4) : ldmode;
      mk = urange(0, 1, 80);
      mm = urange(0, 1, 3 * R);
      mn = urange(0, 1, 3 * C);
      lda = pick_ld(mode, mk, NBA);
      ldb = pick_ld(mode, mn, NBB);
      afoot = longint'(mm - 1) * lda + mk;
      bfoot = longint'(mk - 1) * ldb + mn;
      while (afoot > ASB) begin mm = (mm + 1) / 2; if (mm == 1) begin lda = mk; mk = (mk > ASB) ? ASB : mk; end afoot = longint'(mm - 1) * lda + mk; end
      while (bfoot > BSB) begin mk = (mk + 1) / 2; if (lda < mk) lda = mk; bfoot = longint'(mk - 1) * ldb + mn; afoot = longint'(mm - 1) * lda + mk; end
      a = urange(0, 0, int'(ASB - afoot));
      b = urange(0, 0, int'(BSB - bfoot));
      m0 = urange(0, 0, mm - 1);
      n0 = urange(0, 0, mn - 1);
      k0 = urange(0, 0, mk - 1);
      tk = urange(0, 1, mk);
      tile_push(a, lda, b, ldb, m0, n0, k0, mm, mn, mk, tk);
    end
  endtask

  // fill a set completely and hand it to compute (single-buffer style round)
  task automatic round_fill_and_open(output int set);
    int fs;
    do_fill_begin(fs);
    fill_set_full(fs);
    dma_wait();
    do_fill_end();
    do_cmp_begin(set);
  endtask

  // ============================================================ tests
  task automatic t_smoke();
    int set;
    round_fill_and_open(set);
    random_tiles(20, -1);
    tiles_wait();
    do_cmp_end();
  endtask

  // every bank, every row, every replica, every set: full fill, then tiles that read every byte
  task automatic t_banks();
    int set, ld, rows, krows;
    for (int r = 0; r < NS; r++) begin
      round_fill_and_open(set);
      fill_rand_strobes(1'b0, set, 0, ASB);      // (set is in COMPUTE: all these must be refused)
      dma_wait();
      ld = (ASB >= 64 * 4) ? 64 : ASB / 4;
      rows = ASB / ld;
      // A sweep: every row, read by lanes of every replica (row offset rs)
      for (int rs = 0; rs < REPL; rs++)
        for (int m0 = rs; m0 < rows; m0 = m0 + R)
          tile_push(0, ld, 0, C, m0, 0, 0, rows, C, ld, ld);
      // B sweep: every row, every column group
      krows = BSB / ld;
      for (int n0 = 0; n0 < ld; n0 = n0 + C)
        tile_push(0, krows, 0, ld, 0, n0, 0, R, ld, krows, krows);
      tiles_wait();
      do_cmp_end();
    end
  endtask

  task automatic t_seq();
    int set, mk;
    round_fill_and_open(set);
    mk = (ASB / (2 * R) > 256) ? 256 : ASB / (2 * R);
    if (mk > BSB / (2 * C)) mk = BSB / (2 * C);
    // dense, aligned, K split into chunks of 16 (tiles walk along K)
    for (int k0 = 0; k0 < mk; k0 = k0 + 16)
      tile_push(0, mk, 0, C, 0, 0, k0, R, C, mk, 16);
    for (int m0 = 0; m0 < 2 * R; m0 = m0 + R)
      tile_push(0, mk, 0, 2 * C, m0, C, 0, 2 * R, 2 * C, mk, mk);
    tiles_wait();
    do_cmp_end();
  endtask

  task automatic t_stride();
    int set;
    round_fill_and_open(set);
    for (int mode = 0; mode < 5; mode++) random_tiles(12, mode);
    tiles_wait();
    do_cmp_end();
  endtask

  // concurrent A and B streaming at full rate on a conflict-free layout
  task automatic t_concurrent();
    int set, kk;
    longint lda;
    round_fill_and_open(set);
    lda = pick_ld(3, 32, NBA);
    kk  = 32;
    while (longint'(R - 1) * lda + kk > ASB || longint'(kk - 1) * C + C > BSB) kk = kk / 2;
    for (int t = 0; t < 8; t++) begin
      longint ba, bb;
      ba = urange(0, 0, 3);                 // one draw per statement: argument order is unspecified
      bb = urange(0, 0, 3);
      tile_push(ba, lda, bb, C, 0, 0, 0, R, C, kk, kk);
    end
    tiles_wait();
    do_cmp_end();
  endtask

  task automatic t_partial();
    int set, mm, mn, mk;
    round_fill_and_open(set);
    mm = 2 * R + 1; mn = 2 * C + 1; mk = 37;
    while (longint'(mm - 1) * mk + mk > ASB) mm = mm - 1;
    while (longint'(mk - 1) * mn + mn > BSB) mk = mk - 1;
    for (int m0 = 0; m0 < mm; m0 = m0 + R)
      for (int n0 = 0; n0 < mn; n0 = n0 + C)
        tile_push(0, mk, 0, mn, m0, n0, 0, mm, mn, mk, mk);
    // origins at the last row / column / k, and tile_k beyond the end (clamped)
    tile_push(0, mk, 0, mn, mm - 1, mn - 1, mk - 1, mm, mn, mk, 9);
    tile_push(0, mk, 0, mn, mm - 2, 0, mk - 5, mm, mn, mk, 100);
    random_tiles(20, -1);
    tiles_wait();
    do_cmp_end();
  endtask

  // ping-pong: fill the next set while the current one is computed; verify every tile reads its own set
  task automatic t_switch(input int rounds, input int ntiles);
    int fs, cs;
    do_fill_begin(fs);
    fill_set_full(fs);
    dma_wait();
    do_fill_end();
    for (int r = 0; r < rounds; r++) begin
      do_cmp_begin(cs);
      random_tiles(ntiles, -1);
      if (NS == 2) begin
        do_fill_begin(fs);                        // DMA owns the other set ...
        fill_set_full(fs);                        // ... and fills it while tiles stream
        dma_wait();
        do_fill_end();
      end
      tiles_wait();
      do_cmp_end();
      if (NS == 1 && r != rounds - 1) begin
        do_fill_begin(fs);
        fill_set_full(fs);
        dma_wait();
        do_fill_end();
      end
    end
    if (NS == 2) begin
      do_cmp_begin(cs);
      random_tiles(4, -1);
      tiles_wait();
      do_cmp_end();
    end
  endtask

  // DMA fill of one set at full rate while long tiles stream from the other.  The compute layout keeps the B
  // banks saturated: a conflict-free A stride (A never starves, so B never pauses) and every B row straddling two
  // words, so both B banks are read every cycle; under 1RW + shared banks the DMA writes into B must then be
  // forced by the starvation limit.
  task automatic t_contention();
    int fs, cs, kk;
    longint lda, ov0, st0, fo0, ww0;
    do_fill_begin(fs);
    fill_set_full(fs);
    dma_wait();
    do_fill_end();
    do_cmp_begin(cs);
    kk = (ASB / R > 512) ? 512 : ASB / R;
    if (kk > BSB / C - 1) kk = BSB / C - 1;
    lda = pick_ld(3, kk, NBA);
    while (longint'(R - 1) * lda + kk > ASB) begin kk = kk / 2; lda = pick_ld(3, kk, NBA); end
    ov0 = ev_acc[`TOB_EV_OVERLAP];
    st0 = ev_acc[`TOB_EV_WR_STALL];
    fo0 = ev_acc[`TOB_EV_WR_FORCED];
    ww0 = max_wr_wait;
    max_wr_wait = 0;
    for (int t = 0; t < 6; t++) tile_push(0, lda, 1, C, 0, 0, 0, R, C, kk, kk);
    if (NS == 2) begin
      do_fill_begin(fs);
      fill_set_full(fs);
      dma_wait();
      do_fill_end();
    end
    tiles_wait();
    do_cmp_end();
    $display("CONTENTION overlap_cycles=%0d wr_stall_cycles=%0d forced_writes=%0d max_wr_wait=%0d max_lane_wait=%0d rw_same_bank=%0d",
             ev_acc[`TOB_EV_OVERLAP] - ov0, ev_acc[`TOB_EV_WR_STALL] - st0, ev_acc[`TOB_EV_WR_FORCED] - fo0, max_wr_wait,
             max_lane_wait, rw_same_bank);
    if (NS == 2 && PMODE == 0 && SMAP == 0) begin
      if (ev_acc[`TOB_EV_WR_FORCED] - fo0 == 0) `ERR(("coverage: 1RW shared banks under saturating reads but no write was forced"))
      if (WSL > 0 && max_wr_wait != WSL) `ERR(("a saturated bank should make a write wait exactly WR_STARVE_LIMIT (%0d), saw %0d", WSL, max_wr_wait))
    end
    if (ww0 > max_wr_wait) max_wr_wait = ww0;
    if (NS == 2 && ev_acc[`TOB_EV_OVERLAP] - ov0 == 0) `ERR(("no DMA write overlapped slice delivery in a double-buffered run"))
    if (PMODE == 1 && ev_acc[`TOB_EV_WR_STALL] - st0 != 0) `ERR(("1R1W: DMA writes stalled although the write port is free"))
    if (max_wr_wait > WSL) `ERR(("DMA write waited %0d > WR_STARVE_LIMIT %0d", max_wr_wait, WSL))
    if (NS == 2) begin
      do_cmp_begin(cs);
      random_tiles(4, -1);
      tiles_wait();
      do_cmp_end();
    end
  endtask

  task automatic t_owner();
    int fs, cs;
    logic [DW-1:0] d;
    d = '1;
    // after reset every set is EMPTY: writes refused, tiles refused
    dma_push(1'b1, a_base(0), d, '1);
    dma_push(1'b1, b_base(NS - 1), d, '1);
    dma_wait();
    tile_push(0, 8, 0, 8, 0, 0, 0, 4, 4, 8, 8);           // OWNER
    tiles_wait();
    // command preconditions: only fill_begin may proceed
    @(negedge clk);
    if (fill_end_ready || cmp_begin_ready || cmp_end_ready || !fill_begin_ready) `ERR(("readies after reset"))
    do_fill_begin(fs);
    @(negedge clk);
    if (fill_begin_ready) `ERR(("second fill_begin would be accepted (next set not EMPTY)"))
    fill_set_full(fs);
    dma_push(1'b0, a_base(fs), '0, '0);                     // read: UNSUP
    if (NS == 2) dma_push(1'b1, a_base(1 - fs), d, '1);     // other set EMPTY: OWNER
    // fill_end must not be accepted while a DMA request is still in the hold stage
    dma_push(1'b1, a_base(fs) + 2 * WB, d, '1);
    while (dq_head != dq_tail) @(negedge clk);             // just accepted at the previous rising edge
    #1;
    if (!dut.dma_hold_v) `ERR(("coverage: the last DMA request is not held"))
    if (fill_end_ready)  `ERR(("fill_end_ready while a DMA request is held"))
    dma_wait();
    do_fill_end();
    dma_push(1'b1, a_base(fs) + WB, d, '1);                 // READY: OWNER
    dma_wait();
    do_cmp_begin(cs);
    fill_rand(1'b0, cs, 0, 64);                             // COMPUTE: OWNER ...
    fill_rand(1'b1, cs, 0, 64);
    dma_wait();
    random_tiles(10, -1);                                   // ... and the set is byte-exact unchanged
    tiles_wait();
    // release must wait for the delivery of every slice (heavy back-pressure)
    bp = 85;
    random_tiles(6, -1);
    while (tq_head != tq_tail) @(negedge clk);
    @(negedge clk); cmp_end_valid <= 1'b1; #1;
    while (!cmp_end_ready) begin
      if (tile_ready) `ERR(("tile_ready while a release is pending"))
      @(negedge clk); #1;
    end
    `HS_END(cmp_end_valid)
    if (sq_head != sq_tail) `ERR(("release accepted before every slice was delivered"))
    tb_st[tb_cp] = 0; tb_cp = (tb_cp + 1) % NS;
    bp = 0;
    tile_push(0, 8, 0, 8, 0, 0, 0, 4, 4, 8, 8);             // no compute set: OWNER
    tiles_wait();
  endtask

  task automatic t_range();
    int set;
    logic [DW-1:0] d;
    d = '1;
    do_fill_begin(set);
    fill_set_full(set);
    // DMA: below base, beyond the window, inside the hole, unaligned
    if (BASE >= WB) dma_push(1'b1, BASE - WB, d, '1);
    if (BASE + REG + BTOT + WB < AMAX) dma_push(1'b1, BASE + REG + BTOT, d, '1);
    if (BASE + REG + BTOT + 64 < AMAX) dma_push(1'b1, BASE + REG + BTOT + 64, d, '1);
    if (ATOT < REG) dma_push(1'b1, BASE + ATOT, d, '1);
    if (ATOT < REG) dma_push(1'b1, BASE + REG - WB, d, '1);
    dma_push(1'b1, a_base(set) + 1, d, '1);
    dma_push(1'b1, b_base(set) + WB - 1, d, '1);
    dma_push(1'b0, BASE + REG + BTOT, d, '1);              // read out of range: RANGE wins over UNSUP
    dma_wait();
    do_fill_end();
    do_cmp_begin(set);
    // tiles: every error class, interleaved with good tiles
    tile_push(0, 16, 0, 16, 0, 0, 0, 8, 8, 16, 0);                  // EMPTY: tile_k = 0
    tile_push(0, 16, 0, 16, 8, 0, 0, 8, 8, 16, 4);                  // EMPTY: m0 = mat_m
    tile_push(0, 16, 0, 16, 0, 8, 0, 8, 8, 16, 4);                  // EMPTY: n0 = mat_n
    tile_push(0, 16, 0, 16, 0, 0, 16, 8, 8, 16, 4);                 // EMPTY: k0 = mat_k
    tile_push(0, 15, 0, 16, 0, 0, 0, 8, 8, 16, 4);                  // LD (lda)
    tile_push(0, 16, 0, 7, 0, 0, 0, 8, 8, 16, 4);                   // LD (ldb)
    tile_push(0, 16, 0, 16, 0, 0, 0, 4, 4, 16, 16);                 // good
    tile_push(ASB - 15, 16, 0, 16, 0, 0, 0, 4, 4, 16, 16);          // A_RANGE: last byte at ASB+ ...
    tile_push(ASB - 16, 16, 0, 16, 0, 0, 0, 1, 4, 16, 16);          // good: last A byte = ASB - 1
    tile_push(ASB - 15, 16, 0, 16, 0, 0, 0, 1, 4, 16, 16);          // A_RANGE: last A byte exactly = ASB
    tile_push(0, ASB, 0, 16, 1, 0, 0, 4, 4, 16, 16);                // A_RANGE: row 1 beyond the set
    tile_push(0, AMAX - 1, 0, 16, 0, 0, 0, 4, 4, 16, 16);           // A_OVF: (R-1) * lda >= 2^ADDR_W
    tile_push(AMAX - 1, 16, 0, 16, 0, 0, 0, 1, 1, 1, 1);            // A_RANGE (single byte at 2^AW - 1)
    tile_push(0, 16, BSB - 3, 16, 0, 0, 0, 4, 4, 16, 1);            // B_RANGE
    tile_push(0, 16, 0, AMAX - 1, 0, 0, 0, 4, 4, 16, 16);           // B_OVF
    tile_push(0, 16, 0, BSB, 0, 0, 0, 4, 4, 16, 2);                 // B_RANGE (row 1)
    tile_push(0, 16, BSB - 4, 16, 0, 0, 0, 4, 4, 16, 1);            // good: last B byte = BSB - 1
    random_tiles(10, -1);
    tiles_wait();
    do_cmp_end();
  endtask

  // read-during-write: DMA writes the same physical banks the compute set is being read from
  task automatic t_rdw();
    int fs, cs, kk;
    longint rw0;
    do_fill_begin(fs);
    fill_set_full(fs);
    dma_wait();
    do_fill_end();
    do_cmp_begin(cs);
    rw0 = rw_same_bank;
    kk = (ASB / R > 256) ? 256 : ASB / R;
    if (kk > BSB / C) kk = BSB / C;
    for (int t = 0; t < 4; t++) tile_push(0, kk, 0, C, 0, 0, 0, R, C, kk, kk);
    if (NS == 2) begin
      do_fill_begin(fs);
      for (int rep = 0; rep < 2; rep++) begin fill_set_full(fs); fill_rand_strobes(1'b0, fs, 0, ASB); end
      dma_wait();
      do_fill_end();
    end
    tiles_wait();
    do_cmp_end();
    $display("RDW same_bank_read_write_cycles=%0d", rw_same_bank - rw0);
    if (NS == 2 && SMAP == 0 && PMODE == 1 && rw_same_bank - rw0 == 0)
      `ERR(("1R1W shared banks: no same-cycle read+write happened (test ineffective)"))
    if (NS == 2) begin
      do_cmp_begin(cs);                       // the set written during the reads: byte-exact
      random_tiles(12, -1);
      tiles_wait();
      do_cmp_end();
    end
  endtask

  // pathological strides: every lane in one bank; DMA pressure on the same banks
  task automatic t_starve();
    int fs, cs, kk;
    longint lda, c0, s0;
    do_fill_begin(fs);
    fill_set_full(fs);
    dma_wait();
    do_fill_end();
    do_cmp_begin(cs);
    lda = pick_ld(2, 64, NBA);
    kk = 64;
    while (longint'(R - 1) * lda + kk > ASB) begin kk = kk / 2; lda = pick_ld(2, kk, NBA); end
    if (kk > BSB / C) kk = BSB / C;
    c0 = ev_acc[`TOB_EV_BANK_CONFLICT];
    s0 = ev_acc[`TOB_EV_STARVE_A];
    for (int t = 0; t < 6; t++) tile_push(0, lda, 0, C, 0, 0, 0, R, C, kk, kk);
    if (NS == 2) begin
      do_fill_begin(fs);
      fill_set_full(fs);
      dma_wait();
      do_fill_end();
    end
    tiles_wait();
    do_cmp_end();
    $display("STARVE conflicts=%0d starve_a=%0d max_urgent_lane_wait=%0d max_any_lane_wait=%0d max_wr_wait=%0d",
             ev_acc[`TOB_EV_BANK_CONFLICT] - c0, ev_acc[`TOB_EV_STARVE_A] - s0, max_lane_wait, max_any_wait, max_wr_wait);
    if (R / REPL > 1 && ev_acc[`TOB_EV_BANK_CONFLICT] - c0 == 0) `ERR(("pathological stride produced no bank conflict"))
    if (max_lane_wait > 2 * R + 2) `ERR(("urgent lane request waited %0d cycles (unbounded starvation?)", max_lane_wait))
    if (max_wr_wait > WSL) `ERR(("DMA write waited %0d > WR_STARVE_LIMIT", max_wr_wait))
  endtask

  task automatic t_align();
    int set;
    bp = 50; rbp = 30; tbp = 30; gap = 20;
    round_fill_and_open(set);
    random_tiles(40, -1);
    tiles_wait();
    do_cmp_end();
    bp = 0; rbp = 0; tbp = 0; gap = 0;
  endtask

  task automatic t_reset();
    int set, fs;
    // (a) reset in the middle of a DMA fill
    do_fill_begin(fs);
    fill_set_full(fs);
    idle(urange(0, 20, 400));
    @(negedge clk); #2 rst_n = 1'b0;            // asynchronous assertion, off the clock edge
    @(negedge clk);
    if (s_valid || dma_rsp_valid || tile_rsp_valid || dma_req_ready || tile_ready) `ERR(("outputs active in reset"))
    reset_dut(3);
    if (set_state !== '0) `ERR(("set_state after reset"))
    // (b) full fill, then reset in the middle of a tile stream
    round_fill_and_open(set);
    bp = 30;
    random_tiles(10, -1);
    idle(urange(0, 10, 120));
    @(negedge clk); #3 rst_n = 1'b0;
    reset_dut(2);
    bp = 0;
    // arrays are not reset: reopen without writing and read the old content
    do_fill_begin(fs);
    do_fill_end();
    do_cmp_begin(set);
    random_tiles(10, -1);
    tiles_wait();
    // (c) reset while the AGU validates a tile
    tile_push(0, 16, 0, 16, 0, 0, 0, 4, 4, 16, 16);
    @(negedge clk);
    while (!(tile_valid && tile_ready)) @(negedge clk);
    @(negedge clk);
    idle(3);
    @(negedge clk); #1 rst_n = 1'b0;
    reset_dut(1);
    idle(1);
    if (busy) `ERR(("busy after reset"))
    t_smoke();
  endtask

  task automatic t_random(input int rounds);
    int fs, cs, pick;
    for (int r = 0; r < rounds; r++) begin
      bp  = urange(0, 0, 3) * 20;
      gap = urange(0, 0, 2) * 15;
      rbp = urange(0, 0, 2) * 20;
      tbp = urange(0, 0, 2) * 20;
      do_fill_begin(fs);
      pick = urange(0, 0, 3);                   // drawn unconditionally (no short-circuit dependence)
      if (r < NS || pick != 0) fill_set_full(fs);
      else begin
        fill_rand_strobes(1'b0, fs, 0, ASB);
        fill_rand_strobes(1'b1, fs, 0, BSB);
      end
      dma_wait();
      do_fill_end();
      if (!(NS == 2 && r == 0)) begin       // ping-pong: round 0 only fills
        do_cmp_begin(cs);
        random_tiles(urange(0, 4, 20), -1);
        tiles_wait();
        do_cmp_end();
      end
    end
    bp = 0; gap = 0; rbp = 0; tbp = 0;
  endtask

  // counters against ev_inc and against independent counts
  task automatic check_counters();
    longint aw, bw;
    @(negedge clk);
    @(negedge clk);
    for (int e = 0; e < NEV; e++)
      if (cnt(e) != ev_acc[e]) `ERR(("counter %0d = %0d, sum of ev_inc = %0d", e, cnt(e), ev_acc[e]))
    if (cnt(`TOB_EV_SLICES)   != n_slices)   `ERR(("SLICES %0d vs %0d", cnt(`TOB_EV_SLICES), n_slices))
    if (cnt(`TOB_EV_WR_WORDS) != n_wr_ok)    `ERR(("WR_WORDS %0d vs acknowledged %0d", cnt(`TOB_EV_WR_WORDS), n_wr_ok))
    if (cnt(`TOB_EV_DMA_ERR)  != n_dma_err)  `ERR(("DMA_ERR %0d vs %0d", cnt(`TOB_EV_DMA_ERR), n_dma_err))
    if (cnt(`TOB_EV_TILE_OK)  != n_tile_ok)  `ERR(("TILE_OK %0d vs %0d", cnt(`TOB_EV_TILE_OK), n_tile_ok))
    if (cnt(`TOB_EV_TILE_ERR) != n_tile_err) `ERR(("TILE_ERR %0d vs %0d", cnt(`TOB_EV_TILE_ERR), n_tile_err))
    if (cnt(`TOB_EV_ARRAY_BP) != n_bp_cycles) `ERR(("ARRAY_BP %0d vs %0d", cnt(`TOB_EV_ARRAY_BP), n_bp_cycles))
    if (cnt(`TOB_EV_CYCLES)   != n_cycles_since_clear) `ERR(("CYCLES %0d vs %0d", cnt(`TOB_EV_CYCLES), n_cycles_since_clear))
    aw = cnt(`TOB_EV_A_RD_WORDS); bw = cnt(`TOB_EV_B_RD_WORDS);
    if (aw != exp_a_words) `ERR(("A words read %0d, model %0d", aw, exp_a_words))
    if (bw != exp_b_words) `ERR(("B words read %0d, model %0d", bw, exp_b_words))
    if (cnt(`TOB_EV_STARVE) < cnt(`TOB_EV_STARVE_A) || cnt(`TOB_EV_STARVE) < cnt(`TOB_EV_STARVE_B) ||
        cnt(`TOB_EV_STARVE) > cnt(`TOB_EV_STARVE_A) + cnt(`TOB_EV_STARVE_B)) `ERR(("starvation counter attribution"))
    if (PMODE == 1 && cnt(`TOB_EV_RD_WR_BLOCK) != 0) `ERR(("1R1W: reads blocked by writes without a same-row hazard"))
    if (cnt(`TOB_EV_WR_FORCED) > cnt(`TOB_EV_WR_WORDS)) `ERR(("forced writes > writes"))
  endtask

  task automatic t_perf();
    @(negedge clk); perf_clear <= 1'b1; @(negedge clk); perf_clear <= 1'b0;
    n_slices = 0; n_wr_ok = 0; n_dma_err = 0; n_tile_ok = 0; n_tile_err = 0; exp_a_words = 0; exp_b_words = 0;
    t_switch(2, 10);
    t_range();
    check_counters();
  endtask

  // bandwidth measurement: one layout, back-to-back long tiles, s_ready = 1; optional concurrent fill
  task automatic t_bw();
    int set, fs, kk, ldm, ntl, conc, xa, xb, xlda, xldb;
    longint lda, ldb, c0 [0:NEV-1], t0;
    if (!$value$plusargs("ldmode=%d", ldm)) ldm = 3;
    if (!$value$plusargs("K=%d", kk)) kk = 256;
    if (!$value$plusargs("tiles=%d", ntl)) ntl = 8;
    if (!$value$plusargs("conc=%d", conc)) conc = 0;
    round_fill_and_open(set);
    lda = pick_ld(ldm, kk, NBA);
    while (longint'(R - 1) * lda + kk > ASB) begin kk = kk / 2; lda = pick_ld(ldm, kk, NBA); end
    ldb = (ldm == 2) ? pick_ld(2, C, NBB) : C;
    if ($value$plusargs("lda=%d", xlda)) lda = xlda;            // explicit layout (bandwidth sweep)
    if ($value$plusargs("ldb=%d", xldb)) ldb = xldb;
    if (!$value$plusargs("abase=%d", xa)) xa = -1;
    if (!$value$plusargs("bbase=%d", xb)) xb = -1;
    while (longint'(R - 1) * lda + kk + WB > ASB || longint'(kk - 1) * ldb + C + WB > BSB) kk = kk / 2;
    idle(4);
    for (int e = 0; e < NEV; e++) c0[e] = ev_acc[e];
    t0 = cyc;
    for (int t = 0; t < ntl; t++) begin
      longint ba, bb;
      ba = urange(0, 0, WB - 1);
      bb = urange(0, 0, WB - 1);
      if (xa >= 0) ba = xa;
      if (xb >= 0) bb = xb;
      tile_push(ba, lda, bb, ldb, 0, 0, 0, R, C, kk, kk);
    end
    if (conc && NS == 2) begin
      do_fill_begin(fs);
      fill_set_full(fs);
    end
    tiles_wait();
    $display("PERF cfg R=%0d C=%0d WB=%0d NBA=%0d NBB=%0d REPL=%0d NS=%0d SMAP=%0d PMODE=%0d RL=%0d AST=%0d BST=%0d ldmode=%0d lda=%0d ldb=%0d K=%0d tiles=%0d conc=%0d cycles=%0d slices=%0d starve=%0d starve_a=%0d starve_b=%0d conflicts=%0d a_words=%0d b_words=%0d a_stall=%0d b_stall=%0d rd_wr_block=%0d wr_words=%0d wr_stall=%0d overlap=%0d bubbles_in_tiles=%0d max_bubble_tile=%0d",
             R, C, WB, NBA, NBB, REPL, NS, SMAP, PMODE, RL, AST, BST, ldm, lda, ldb, kk, ntl, conc, cyc - t0,
             ev_acc[`TOB_EV_SLICES] - c0[`TOB_EV_SLICES], ev_acc[`TOB_EV_STARVE] - c0[`TOB_EV_STARVE],
             ev_acc[`TOB_EV_STARVE_A] - c0[`TOB_EV_STARVE_A], ev_acc[`TOB_EV_STARVE_B] - c0[`TOB_EV_STARVE_B],
             ev_acc[`TOB_EV_BANK_CONFLICT] - c0[`TOB_EV_BANK_CONFLICT], ev_acc[`TOB_EV_A_RD_WORDS] - c0[`TOB_EV_A_RD_WORDS],
             ev_acc[`TOB_EV_B_RD_WORDS] - c0[`TOB_EV_B_RD_WORDS], ev_acc[`TOB_EV_A_RD_STALL] - c0[`TOB_EV_A_RD_STALL],
             ev_acc[`TOB_EV_B_RD_STALL] - c0[`TOB_EV_B_RD_STALL], ev_acc[`TOB_EV_RD_WR_BLOCK] - c0[`TOB_EV_RD_WR_BLOCK],
             ev_acc[`TOB_EV_WR_WORDS] - c0[`TOB_EV_WR_WORDS], ev_acc[`TOB_EV_WR_STALL] - c0[`TOB_EV_WR_STALL],
             ev_acc[`TOB_EV_OVERLAP] - c0[`TOB_EV_OVERLAP], bubbles, max_bubble_tile);
    if (conc && NS == 2) begin
      dma_wait();
      do_fill_end();
    end
    do_cmp_end();
  endtask

  // latency of an idle buffer: DMA write -> response, tile accept -> response / first slice, tile-to-tile gap
  task automatic t_latency();
    int set, fs;
    longint a1, f1, l1, f2, d_acc, d_rsp, r1, ld;
    logic [DW-1:0] d;
    d = '1;
    ld = pick_ld(3, 64, NBA);                         // conflict-free: the R first words are in distinct banks
    do_fill_begin(fs);
    fill_set_full(fs);
    dma_wait();
    idle(5);
    dma_push(1'b1, a_base(fs), d, '1);
    dma_wait();
    d_acc = e_dacc; d_rsp = e_drsp;
    do_fill_end();
    do_cmp_begin(set);
    idle(5);
    tile_push(0, ld, 0, C, 0, 0, 0, R, C, 64, 64);
    tiles_wait();
    a1 = e_tacc; r1 = e_trsp; f1 = e_sfirst; l1 = e_slast;
    idle(5);
    tile_push(1, ld, 0, C, 0, 0, 0, R, C, 64, 64);           // two back-to-back tiles
    tile_push(2, ld, 0, C, 0, 0, 0, R, C, 64, 64);
    while (sq_head != sq_tail - 1) @(negedge clk);
    l1 = e_slast;
    tiles_wait();
    f2 = e_sfirst;
    $display("LATENCY dma_accept_to_rsp=%0d tile_accept_to_rsp=%0d tile_accept_to_first_slice=%0d back_to_back_gap=%0d",
             d_rsp - d_acc, r1 - a1, f1 - a1, f2 - l1 - 1);
    do_cmp_end();
  endtask

  // ============================================================ main
  string test;
  int seed;
  int unsigned dummy;
  initial begin
    if (!$value$plusargs("test=%s", test)) test = "all";
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("bp=%d", bp)) bp = 0;
    if (!$value$plusargs("gap=%d", gap)) gap = 0;
    if (!$value$plusargs("rbp=%d", rbp)) rbp = 0;
    if ($test$plusargs("full_rate")) full_rate = 1;
    if ($test$plusargs("verbose")) verbose = 1;
    for (int k = 0; k < 8; k++) rs[k] = 32'h9E3779B9 * (seed + 1) + 32'h7F4A7C15 * (k + 1);
    for (int k = 0; k < 8; k++) dummy = rnd(k);
    tb_st[0] = 0; tb_st[1] = 0;
    $display("TB config R=%0d C=%0d WB=%0d ASB=%0d BSB=%0d NBA=%0d NBB=%0d REPL=%0d NS=%0d SMAP=%0d PMODE=%0d RL=%0d AST=%0d BST=%0d WSL=%0d AW=%0d BASE=%0h BACKEND=%0d test=%s seed=%0d",
             R, C, WB, ASB, BSB, NBA, NBB, REPL, NS, SMAP, PMODE, RL, AST, BST, WSL, AW, BASE, BACKEND, test, seed);
    reset_dut(4);

    if (test == "smoke" || test == "all")      begin $display("-- smoke"); drain_sets();      t_smoke();           end
    if (test == "banks" || test == "all")      begin $display("-- banks"); drain_sets();      t_banks();           end
    if (test == "seq" || test == "all")        begin $display("-- seq"); drain_sets();        t_seq();             end
    if (test == "stride" || test == "all")     begin $display("-- stride"); drain_sets();     t_stride();          end
    if (test == "concurrent" || test == "all") begin $display("-- concurrent"); drain_sets(); t_concurrent();      end
    if (test == "partial" || test == "all")    begin $display("-- partial"); drain_sets();    t_partial();         end
    if (test == "switch" || test == "all")     begin $display("-- switch"); drain_sets();     t_switch(4, 8);      end
    if (test == "contention" || test == "all") begin $display("-- contention"); drain_sets(); t_contention();      end
    if (test == "rdw" || test == "all")        begin $display("-- rdw"); drain_sets();        t_rdw();             end
    if (test == "starve" || test == "all")     begin $display("-- starve"); drain_sets();     t_starve();          end
    if (test == "align" || test == "all")      begin $display("-- align"); drain_sets();      t_align();           end
    if (test == "random" || test == "all")     begin $display("-- random"); drain_sets();     t_random(6);         end
    if (test == "perf" || test == "all")       begin $display("-- perf"); drain_sets();       t_perf();            end
    // tests that start from reset state
    if (test == "owner" || test == "all")      begin $display("-- owner"); drain_sets();      reset_dut(2); t_owner(); end
    if (test == "range")                       begin $display("-- range"); drain_sets();      t_range();           end
    if (test == "reset" || test == "all")      begin $display("-- reset"); drain_sets();      t_reset();           end
    if (test == "latency")                     begin $display("-- latency"); drain_sets(); t_latency(); end
    if (test == "bw")                          begin $display("-- bw"); drain_sets();         t_bw();              end
    if (test != "bw") check_counters();

    idle(10);
    if (dq_tail != dr_head || sq_head != sq_tail || tr_head != tq_tail) `ERR(("agents not drained at the end"))
    $display("SUMMARY test=%s seed=%0d slices=%0d writes=%0d dma_err=%0d tiles_ok=%0d tiles_err=%0d bubbles=%0d max_lane_wait=%0d max_wr_wait=%0d rw_same_bank=%0d cycles=%0d",
             test, seed, n_slices, n_wr_ok, n_dma_err, n_tile_ok, n_tile_err, bubbles, max_lane_wait, max_wr_wait, rw_same_bank, cyc);
    if (errors == 0) $display("RESULT: PASS");
    else             $display("RESULT: FAIL (%0d errors)", errors);
    $finish;
  end

  initial begin
    #(64'd400000000);
    $display("RESULT: FAIL (global timeout)");
    $finish;
  end

endmodule
