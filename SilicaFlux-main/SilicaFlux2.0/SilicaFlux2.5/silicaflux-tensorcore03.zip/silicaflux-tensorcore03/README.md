# SilicaFlux TENSORCORE 03 — Banked Tensor Operand Buffers and Data Delivery

**Primary source:** `rtl/tensor_operand_buffer.sv` · Aureom.AI | SilicaFlux-HPC

This is the local memory subsystem that supplies the A and B INT8 operands to the TENSORCORE 02 output-stationary
systolic array, one k-slice per cycle: `s_a = A[m0..m0+R−1][k0+k]`, `s_b = B[k0+k][n0..n0+C−1]`. It has separate
banked A and B buffers built from the SilicaFlux SRAM Wrapper Library (GENERIC / FPGA BRAM / real ASIC macros),
per-lane staging that turns R reads per cycle into R/WB, explicit 1RW / 1R1W port models with deterministic
arbitration, optional A replication, and row-major byte addressing with overflow and range detection.
Ping-pong double buffering has explicit ownership. Every stall is reported as an event, and the event counts are
checked against an analytical bandwidth model.

Built in the order the brief asks: **stage 1** single buffer with one bank per operand, **stage 2** banked parallel
access, **stage 3** double buffering. Each stage was regressed before the next.

> Not committed to GitHub: this is a plain archive. Every number below comes from the generated reports in
> `reports/` (final run on frozen sources). Simulation, Yosys synthesis and nextpnr place & route only: there is no
> hardware run.

## Results

| Check | Result | Report |
|---|---|---|
| Lint: Verilator `-Wall` clean over 33 configurations + Icarus elaboration | **33 / 33** | `regression.md` |
| Illegal parameter combinations rejected at elaboration | **20 / 20** | `regression.md` |
| Stage 1: single buffer, one bank per operand (7 configurations × 2 seeds + rate check) | **15 / 15** | `regression.md` |
| Stage 2: single buffer, banked (13 configurations: 1×1 … 16×16, 16/32/64-bit words, latency 1–3, replication, FPGA backend) | **38 / 38** | `regression.md` |
| Stage 3: double buffering (13 configurations: shared/split sets, 1RW/1R1W, write-starvation limits 0/2/8, DMA window with base and hole, 40-bit addresses) | **38 / 38** | `regression.md` |
| Icarus 12 vs Verilator 5.020, same seed: identical measurement lines | **9 / 9** | `regression.md` |
| Per-bank arbiter unit test (both port models, same-row hazards, round-robin bound) | **2 / 2** | `regression.md` |
| Integration: DMA → buffer → TENSORCORE 02 array → C vs reference INT8 matmul (8 problems, partial tiles, K split) | **8 / 8**, 1304 C elements bit-exact per run | `regression.md` |
| Mutation testing: injected design bugs detected | **34 / 34** | `mutation.md` |
| Operand bandwidth sweep, self-checking | **55 / 55** | `perf.md` |
| Analytical model vs RTL (full rate predicted ⇔ measured), incl. 7 held-out predictions | **44 / 44** | `perf.md` |
| Synthesis / P&R runs (generic, xc7, ECP5, iCE40, ECP5 + iCE40 nextpnr, ASIC macros) | **30 / 30** | `synth.md` |

## Headline measurements

| | Value | Source |
|---|---|---|
| Baseline (4×4, 32-bit words, 2 × (4 KiB A + 4 KiB B), 4 A banks, 2 B banks, 1R1W) | **8 operands / cycle** (1.000 slice/cycle in tile) on conflict-free layouts | perf.md |
| Dense row-major A with K = 256 (all lanes in one bank), `A_STAGE = 2` → `A_STAGE = 4` or lda + 4 B padding | 0.892 → 1.000 | perf.md |
| 8×8 / 16×16 with sized banks | 16 / 32 operands per cycle (1.000) | perf.md |
| B rows straddling two words with 1 B bank → 2 B banks | 0.501 → 1.000 | perf.md |
| DMA fill of the other set during compute: 1R1W shared / 1RW split / 1RW shared (limit 8, 2, 0) | 1.000 / 1.000 / 0.960, 0.854, 0.667 | perf.md |
| DMA write wait under saturating reads, 1RW | exactly `WR_STARVE_LIMIT` (8, 2, 0) | regression.md |
| Latency: tile accept → first slice | R + READ_LATENCY + 11 cycles (16 at baseline) | perf.md |
| Latency: DMA write accept → acknowledgement | 2 cycles | perf.md |
| Integration, overlapped vs serial fill/compute | measured overlap 685 cycles, speed-up 1.13 (4×4) | regression.md |
| ECP5 LFE5U-25F-6 place & route (baseline, in I/O wrapper) | 40.3 MHz; 8 / 56 DP16KD; 36 % logic | synth.md |
| Xilinx 7-series synthesis (baseline) | 3582 LUT, 1866 FF, 4 RAMB18 + 2 RAMB36, 4 DSP | synth.md |
| ASIC: SKY130 / IHP SG13G2 / GF180MCU macros | exact macro counts; no flip-flop memory | synth.md |

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit: SRAM wrapper library, HPC scratchpad, banks, DMA/DataFabric, FPGA BRAM, ASIC macros; reuse | `docs/00_repository_audit.md`; `third_party/` (unmodified, SHA-256 identical: `third_party/PROVENANCE.md`) |
| 2 | Separate A/B buffers; capacity, banks, byte addressing, INT8, read latency, ready/valid; modest-FPGA start | `rtl/`, `docs/01_architecture.md` §2–3 |
| 3 | R A + C B operands per cycle: banking, replication, arbitration, staging, stall signalling; no unlimited single-port SRAM | `docs/03_bandwidth_analysis.md`, `docs/04_arbitration_and_stalls.md`, `reports/perf.md`, `model/tob_bw_model.py` |
| 4 | Row-major; base, leading dimension, element index, tile origin, K index, masks; bytes; overflow / range | `rtl/tob_tile_agu.sv`, `docs/02_matrix_layout_and_addressing.md` |
| 5 | Ping-pong, explicit ownership, no overwrite of operands in use, overlap only when verified | `rtl/tob_dbuf_ctrl.sv`, `docs/05_double_buffering.md`; OVERLAP event measured in tests and integration |
| 6 | Port constraints, deterministic arbitration, conflicts / read & write stalls / starvation events for counters | `rtl/tob_bank_arb.sv`, `ev_inc` (Module 07 `inc_i` compatible), `rtl/tob_perf.sv`, doc 04 |
| 7 | Synchronous latency; aligned data, valid, coordinates, reduction index | `docs/06_read_timing.md`; every slice checked; array `s_k` / `align_err` in integration |
| 8 | Inferred FPGA BRAM; separate ASIC integration point; no FPGA→ASIC inference | `docs/07_fpga_asic_portability.md`, `reports/synth.md` |
| 9 | All banks, sequential, strided, concurrent A/B, partial, switching, contention, reset, out-of-range, read-during-write, starvation, alignment; byte-accurate reference | `docs/08_verification.md` §2, `tb/` |
| 10 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `tensor_operand_buffer.sv` | `rtl/tensor_operand_buffer.sv` (+ `rtl/tob_defs.svh`) |
| Address-generation logic | `rtl/tob_tile_agu.sv` (descriptor validation, overflow / range, lane start words), fetch address logic in the top level |
| Bank arbitration | `rtl/tob_bank_arb.sv`, `rtl/tob_bank.sv` |
| Double-buffer controller | `rtl/tob_dbuf_ctrl.sv` (+ ownership check in `rtl/tob_dma_port.sv`) |
| Tests | `tb/tb_tensor_operand_buffer.sv` (16 tests + bandwidth and latency measurement modes), `tb/tb_tob_bank_arb.sv`, `tb/tb_tob_array.sv` (integration with TENSORCORE 02); `scripts/run_regress.py`, `scripts/run_mutants.py` |
| Memory bandwidth analysis | `docs/03_bandwidth_analysis.md`, `model/tob_bw_model.py`, `reports/perf.md` |
| Actual synthesis resource report | `reports/synth.md` (+ `.json`), `docs/09_synthesis_report.md`, `fpga/tob_pnr_wrap.sv` (P&R I/O wrapper) |

## Interface at a glance

```
tensor_operand_buffer #(ARRAY_ROWS=4, ARRAY_COLS=4, WORD_BYTES=4, A_SET_BYTES=4096, B_SET_BYTES=4096, A_BANKS=4, B_BANKS=2,
                        A_REPL=1, NUM_SETS=2, SET_MAP=SHARED|SPLIT, PORT_MODE=1RW|1R1W, READ_LATENCY=1, A_STAGE=2, B_STAGE=4,
                        WR_STARVE_LIMIT=8, ADDR_W=32, DMA_BASE=0, IDX_W=16, K_W=17, TAG_W=8, DMA_RSP_DEPTH=4,
                        BACKEND=GENERIC|FPGA|ASIC, MACRO_A, MACRO_B, PERF_EN=1, CNT_W=32)
  DMA fill   dma_req_{valid,ready,we,addr,wdata,wstrb,tag}  dma_rsp_{valid,ready,rdata,err,err_code,we,tag}   (Module 04 port protocol)
  ownership  fill_begin / fill_end / cmp_begin / cmp_end (valid/ready)   fill_set cmp_set set_state
  tiles      tile_{valid,ready,a_addr,lda,b_addr,ldb,m0,n0,k0,mat_m,mat_n,mat_k,k,tag}   tile_rsp_{valid,ready,tag,err,code,m,n,k}
  slices     s_{valid,ready,a,b,k,kg,m0,n0,row_mask,col_mask,first,last,tag,set}     (to tensor_systolic_array s_*)
  status     busy engine_idle ev_inc[20 x 8] ev_bank_conflict_a perf_clear perf_cnt[20 x CNT_W]
```

## Quick start

```bash
make quick        # lint + 20 illegal-parameter checks + stage 1
```

```bash
make test         # lint -> stage1 -> stage2 -> stage3 -> Icarus cross-check -> arbiter unit -> integration
```

```bash
make mutants perf synth report
```

```bash
make sim TEST=contention SEED=3 CFG='PMODE=0 NS=2'
```

Tools: Verilator 5.020, Icarus Verilog 12, Yosys 0.33, nextpnr-ecp5 / nextpnr-ice40 0.6 (Trellis / IceStorm
databases), Python ≥ 3.10. The directory is self-contained: `third_party/` holds every reused source.

## Files

```
rtl/          tensor_operand_buffer.sv tob_tile_agu.sv tob_bank_arb.sv tob_bank.sv tob_dbuf_ctrl.sv tob_dma_port.sv tob_perf.sv tob_defs.svh
tb/           tb_tensor_operand_buffer.sv tb_tob_bank_arb.sv tb_tob_array.sv
model/        tob_bw_model.py                         analytical operand-bandwidth model
fpga/         tob_pnr_wrap.sv                         I/O wrapper for place & route (measurement only)
scripts/      run_regress.py run_mutants.py run_perf.py run_synth.py make_report.py common.py lint.vlt
docs/         00 audit · 01 architecture · 02 layout & addressing · 03 bandwidth · 04 arbitration & stalls · 05 double buffering
              06 read timing · 07 FPGA/ASIC · 08 verification · 09 synthesis · 10 status & next actions
reports/      SUMMARY regression mutation perf synth (.md + .json, generated)
third_party/  silicaflux-sramlib (RTL subset) · silicaflux-datafabric dma_fifo · silicaflux-tensorcore02 (integration only)
              PROVENANCE.md SHA256SUMS
Makefile  SHA256SUMS
```

## What is not claimed

No hardware run, no gate-level simulation, and no formal proof of the new RTL. There is no Xilinx timing (Yosys
synthesis only) and no ASIC area, timing or power (ASIC rows are macro-integrity checks with generic-gate cell
counts). FPGA results do not predict ASIC SRAM macros. The Module 05 DMA adapter and the Module 07 counter bank are
protocol-compatible by design but not simulated together with this module. Fmax is modest (40.3 MHz on ECP5-6),
limited by the event/counter and DMA-decode paths (doc 09, doc 10).
