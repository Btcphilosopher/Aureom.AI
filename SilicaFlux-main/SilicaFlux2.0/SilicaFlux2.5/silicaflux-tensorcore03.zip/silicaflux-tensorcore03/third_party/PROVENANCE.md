# Provenance of third_party/ (unmodified copies)

Each file is byte-identical to the file of the same relative path inside the named archive of
`btcphilosopher/Aureom.AI` (SHA-256 of the copy = SHA-256 of the original, both computed here).

| file | source archive | SHA-256 | identical |
|---|---|---|---|
| `silicaflux-datafabric/rtl/dma/dma_fifo.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip` → `silicaflux-datafabric/rtl/dma/dma_fifo.sv` | `ada85a9465e410db…` | yes |
| `silicaflux-sramlib/README.md` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/README.md` | `f90ed16a8dd3375c…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/sram_asic_array.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/sram_asic_array.sv` | `d01a75f168734747…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_gf180.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_gf180.sv` | `69501f0f60e89c27…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp1p.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp1p.sv` | `99f36e6870333ae7…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp2p.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp2p.sv` | `119040eb5514f0ff…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_sky130.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_sky130.sv` | `4d35bc6c9949dae0…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/sram_macro_funcs.svh` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/sram_macro_funcs.svh` | `a8249d5f8bbc4b10…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/sram_macro_ids.svh` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/sram_macro_ids.svh` | `3a1cda1ca095c0e1…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv` | `ebbddd6d4ddf9d1e…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1r1w.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1r1w.sv` | `ca465a2120a5aa84…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1rw.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1rw.sv` | `44adfd6dfafcf866…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1r1w.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1r1w.sv` | `8eb1cae360ab03df…` | yes |
| `silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv` | `634eb25398c89edf…` | yes |
| `silicaflux-sramlib/rtl/mem/sram_backend_1r1w.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/sram_backend_1r1w.sv` | `2c84f533980a5be7…` | yes |
| `silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv` | `355fd65ae67bada4…` | yes |
| `silicaflux-sramlib/rtl/mem/sram_defs.svh` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/sram_defs.svh` | `856b67598ee09275…` | yes |
| `silicaflux-tensorcore02/rtl/tensor_output_collect.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore02.zip` → `silicaflux-tensorcore02/rtl/tensor_output_collect.sv` | `ae2bf95f200152b8…` | yes |
| `silicaflux-tensorcore02/rtl/tensor_pe.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore02.zip` → `silicaflux-tensorcore02/rtl/tensor_pe.sv` | `f931027f5c65b87b…` | yes |
| `silicaflux-tensorcore02/rtl/tensor_skew.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore02.zip` → `silicaflux-tensorcore02/rtl/tensor_skew.sv` | `a69f279fa282f22e…` | yes |
| `silicaflux-tensorcore02/rtl/tensor_systolic_array.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore02.zip` → `silicaflux-tensorcore02/rtl/tensor_systolic_array.sv` | `07be2f4be73cb018…` | yes |
