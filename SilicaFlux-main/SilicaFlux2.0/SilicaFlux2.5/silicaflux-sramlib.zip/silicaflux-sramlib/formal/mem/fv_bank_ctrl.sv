// =============================================================================
// Formal harness: sram_bank_controller (2 masters x 2 banks, GENERIC backend)
//   * embedded assertions: one grant per bank, grants only to requesters,
//     read data owner == master response stage (no misrouted / dropped /
//     duplicated read), no functional access in test mode;
//   * per master (symbolic m): the n-th response answers the n-th
//     response-producing request (ID, err, we), and a tracked read of the
//     symbolic word returns the word written by earlier accepted writes of
//     ANY master (global serialisation by acceptance cycle);
//   * round-robin fairness: with all rsp_ready high, a master holding a valid
//     request waits at most NUM_MASTERS cycles.
// =============================================================================
`include "sram_defs.svh"
`include "fv_defs.svh"
`default_nettype none

module fv_bank_ctrl #(
  parameter int NM  = 2,
  parameter int NB  = 2,
  parameter int BD  = 2,
  parameter int DW  = 2,
  parameter int LAT = 1,
  parameter int FIFO = 2,
  localparam int TOTAL = NM * 0 + NB * BD,
  localparam int AWD = $clog2(TOTAL) + 1,       // one spare bit: out-of-range requests
  localparam int IDW = 2
) (
  input wire logic              clk,
  input wire logic              rst_n,
  input wire logic [NM-1:0]     req_valid,
  input wire logic [NM-1:0]     req_we,
  input wire logic [NM*AWD-1:0] req_addr,
  input wire logic [NM*DW-1:0]  req_wdata,
  input wire logic [NM*IDW-1:0] req_id,
  input wire logic [NM-1:0]     rsp_ready
);
  logic [NM-1:0] req_ready, rsp_valid, rsp_err, rsp_we, stall;
  logic [NM*DW-1:0] rsp_rdata;
  logic [NM*IDW-1:0] rsp_id;
  logic [NB*DW-1:0] tst_rdata;
  logic busy;

  sram_bank_controller #(.NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .MASK_WIDTH(1), .BANK_DEPTH(BD),
                         .READ_LATENCY(LAT), .ID_WIDTH(IDW), .RSP_FIFO_DEPTH(FIFO), .ADDR_WIDTH(AWD)) dut (
    .clk, .rst_n, .m_req_valid(req_valid), .m_req_ready(req_ready), .m_req_we(req_we), .m_req_addr(req_addr),
    .m_req_wdata(req_wdata), .m_req_wmask({NM{1'b1}}), .m_req_id(req_id), .m_rsp_valid(rsp_valid),
    .m_rsp_ready(rsp_ready), .m_rsp_rdata(rsp_rdata), .m_rsp_err(rsp_err), .m_rsp_we(rsp_we), .m_rsp_id(rsp_id),
    .m_stall_conflict(stall), .tst_active(1'b0), .tst_sel('0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0),
    .tst_wdata('0), .tst_rdata, .busy);

  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n); else assume (rst_n);
  // master rules
  reg [NM-1:0] pend = 0;
  reg [NM-1:0] pwe; reg [NM*AWD-1:0] pad; reg [NM*DW-1:0] pwd; reg [NM*IDW-1:0] pid;
  always @(posedge clk) begin
    pend <= {NM{rst_n}} & req_valid & ~req_ready;
    pwe <= req_we; pad <= req_addr; pwd <= req_wdata; pid <= req_id;
  end
  genvar g;
  for (g = 0; g < NM; g = g + 1) begin : g_m
    always @(*) if (pend[g]) assume (req_valid[g] && req_we[g] == pwe[g] && req_addr[g*AWD +: AWD] == pad[g*AWD +: AWD] &&
                                     req_wdata[g*DW +: DW] == pwd[g*DW +: DW] && req_id[g*IDW +: IDW] == pid[g*IDW +: IDW]);
  end

  // global shadow of the symbolic word
  (* anyconst *) reg [AWD-1:0] tw;
  always @(*) assume (tw < TOTAL);
  reg [DW-1:0] shadow = '0;
  reg known = 1'b0;
  integer i;
  always @(posedge clk) if (rst_n) begin
    for (i = 0; i < NM; i = i + 1)
      if (req_valid[i] && req_ready[i] && req_we[i] && req_addr[i*AWD +: AWD] == tw) begin
        shadow <= req_wdata[i*DW +: DW]; known <= 1'b1;
      end
  end
  // two masters can never write the same word in one cycle (same bank)
  always @(posedge clk) if (rst_n && !init)
    `PROP(!(req_valid[0] && req_ready[0] && req_valid[1] && req_ready[1] && req_addr[0 +: AWD] == req_addr[AWD +: AWD] &&
              req_addr[0 +: AWD] < TOTAL));

  // tracked transaction of master tm
  (* anyconst *) reg [0:0] tm;
  (* anyseq *) reg pick;
  wire          acc   = req_valid[tm] && req_ready[tm];
  wire [AWD-1:0] ad   = req_addr[tm*AWD +: AWD];
  wire          okad  = ad < TOTAL;
  wire          deliv = rsp_valid[tm] && rsp_ready[tm];
  reg [7:0] seq_in = 0, seq_out = 0, t_seq;
  reg tracking = 0, t_rd, t_err, t_we, t_known;
  reg [IDW-1:0] t_id; reg [DW-1:0] t_data;
  always @(posedge clk) if (rst_n) begin
    if (acc) seq_in <= seq_in + 1'b1;          // WRITE_ACK = 1: every request answers
    if (deliv) seq_out <= seq_out + 1'b1;
    if (acc && pick && !tracking) begin
      tracking <= 1; t_seq <= seq_in; t_rd <= !req_we[tm] && ad == tw; t_err <= !okad; t_we <= req_we[tm];
      t_id <= req_id[tm*IDW +: IDW]; t_data <= shadow; t_known <= known;
    end
    if (deliv && tracking && seq_out == t_seq) tracking <= 0;
  end
  always @(posedge clk) if (rst_n && !init) begin
    `PROP(seq_out != seq_in || !rsp_valid[tm]);
    if (deliv && tracking && seq_out == t_seq) begin
      `PROP(rsp_id[tm*IDW +: IDW] == t_id && rsp_err[tm] == t_err && rsp_we[tm] == t_we);
      if (t_rd && t_known) `PROP(rsp_rdata[tm*DW +: DW] == t_data);
    end
  end

  // round-robin fairness under no backpressure
  reg [3:0] wt0 = 0, wt1 = 0;
  reg bp_seen = 0;
  always @(posedge clk) begin
    wt0 <= (rst_n && req_valid[0] && !req_ready[0]) ? wt0 + 1'b1 : 4'd0;
    wt1 <= (rst_n && req_valid[1] && !req_ready[1]) ? wt1 + 1'b1 : 4'd0;
    if (rst_n && rsp_ready != {NM{1'b1}}) bp_seen <= 1;
  end
  always @(posedge clk) if (rst_n && !init && !bp_seen && rsp_ready == {NM{1'b1}}) begin
    `PROP(wt0 <= NM);
    `PROP(wt1 <= NM);
  end
  always @(posedge clk) if (rst_n) `COVER_T(deliv && tracking && seq_out == t_seq && t_rd && t_known);
endmodule

`default_nettype wire
