// =============================================================================
// Formal harness: sram_tdp (GENERIC backend, COLLISION = STALL)
//   * embedded assertion: no same-address pair involving a write is issued;
//   * port A tracked read of the symbolic address returns the word written by
//     writes (either port) accepted in earlier cycles;
//   * starvation bound: with both rsp_ready high and no test mode, a pending
//     request on either port waits at most 2 cycles.
// =============================================================================
`include "sram_defs.svh"
`include "fv_defs.svh"
`default_nettype none

module fv_sram_tdp #(
  parameter int DW    = 4,
  parameter int DEPTH = 4,
  parameter int MW    = 2,
  parameter int LAT   = 1,
  parameter int FIFO  = 2,
  localparam int AW   = $clog2(DEPTH),
  localparam int LW   = DW / MW
) (
  input wire logic          clk,
  input wire logic          rst_n,
  input wire logic          a_valid, a_we, b_valid, b_we,
  input wire logic [AW-1:0] a_addr, b_addr,
  input wire logic [DW-1:0] a_wdata, b_wdata,
  input wire logic [MW-1:0] a_wmask, b_wmask,
  input wire logic          a_id, b_id,
  input wire logic          a_rr, b_rr
);
  logic a_ready, b_ready, a_rv, b_rv, a_err, b_err, a_rwe, b_rwe, a_rid, b_rid, busy;
  logic [DW-1:0] a_rd, b_rd, tst_rdata;

  sram_tdp #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .RSP_FIFO_DEPTH(FIFO)) dut (
    .clk, .rst_n,
    .a_req_valid(a_valid), .a_req_ready(a_ready), .a_req_we(a_we), .a_req_addr(a_addr), .a_req_wdata(a_wdata),
    .a_req_wmask(a_wmask), .a_req_id(a_id), .a_rsp_valid(a_rv), .a_rsp_ready(a_rr), .a_rsp_rdata(a_rd),
    .a_rsp_err(a_err), .a_rsp_we(a_rwe), .a_rsp_id(a_rid),
    .b_req_valid(b_valid), .b_req_ready(b_ready), .b_req_we(b_we), .b_req_addr(b_addr), .b_req_wdata(b_wdata),
    .b_req_wmask(b_wmask), .b_req_id(b_id), .b_rsp_valid(b_rv), .b_rsp_ready(b_rr), .b_rsp_rdata(b_rd),
    .b_rsp_err(b_err), .b_rsp_we(b_rwe), .b_rsp_id(b_rid),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata, .busy);

  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n); else assume (rst_n);
  reg pa = 0, pb = 0;
  reg pawe, pbwe, paid, pbid; reg [AW-1:0] paa, pba; reg [DW-1:0] pad, pbd; reg [MW-1:0] pam, pbm;
  always @(posedge clk) begin
    pa <= rst_n && a_valid && !a_ready; pb <= rst_n && b_valid && !b_ready;
    pawe <= a_we; paa <= a_addr; pad <= a_wdata; pam <= a_wmask; paid <= a_id;
    pbwe <= b_we; pba <= b_addr; pbd <= b_wdata; pbm <= b_wmask; pbid <= b_id;
  end
  always @(*) begin
    if (pa) assume (a_valid && a_we == pawe && a_addr == paa && a_wdata == pad && a_wmask == pam && a_id == paid);
    if (pb) assume (b_valid && b_we == pbwe && b_addr == pba && b_wdata == pbd && b_wmask == pbm && b_id == pbid);
  end

  (* anyconst *) reg [AW-1:0] ta;
  function automatic [DW-1:0] lanes(input [MW-1:0] m);
    integer i;
    for (i = 0; i < DW; i = i + 1) lanes[i] = m[i / LW];
  endfunction
  reg [DW-1:0] shadow = '0; reg [MW-1:0] known = '0;
  wire aacc = a_valid && a_ready, bacc = b_valid && b_ready;
  always @(posedge clk) if (rst_n) begin
    // STALL guarantees A and B never both write ta in one cycle
    if (aacc && a_we && a_addr == ta) begin
      shadow <= (shadow & ~lanes(a_wmask)) | (a_wdata & lanes(a_wmask)); known <= known | a_wmask;
    end else if (bacc && b_we && b_addr == ta) begin
      shadow <= (shadow & ~lanes(b_wmask)) | (b_wdata & lanes(b_wmask)); known <= known | b_wmask;
    end
  end
  always @(posedge clk) if (rst_n && !init) `PROP(!(aacc && bacc && a_we && b_we && a_addr == b_addr));

  (* anyseq *) reg pick;
  reg [7:0] seq_in = 0, seq_out = 0, t_seq;
  reg tracking = 0, t_rd, t_we, t_id;
  reg [DW-1:0] t_data; reg [MW-1:0] t_known;
  wire deliver = a_rv && a_rr;
  always @(posedge clk) if (rst_n) begin
    if (aacc) seq_in <= seq_in + 1'b1;
    if (deliver) seq_out <= seq_out + 1'b1;
    if (aacc && pick && !tracking) begin
      tracking <= 1; t_seq <= seq_in; t_rd <= !a_we && a_addr == ta; t_we <= a_we; t_id <= a_id;
      t_data <= shadow; t_known <= known;
    end
    if (deliver && tracking && seq_out == t_seq) tracking <= 0;
  end
  always @(posedge clk) if (rst_n && !init && deliver && tracking && seq_out == t_seq) begin
    `PROP(a_rid == t_id && a_rwe == t_we && !a_err);
    if (t_rd) `PROP(((a_rd ^ t_data) & lanes(t_known)) == '0);
  end

  reg [3:0] wa = 0, wb = 0;
  reg bp_seen = 0;
  always @(posedge clk) begin
    wa <= (rst_n && a_valid && !a_ready) ? wa + 1'b1 : 4'd0;
    wb <= (rst_n && b_valid && !b_ready) ? wb + 1'b1 : 4'd0;
    if (rst_n && !(a_rr && b_rr)) bp_seen <= 1;
  end
  always @(posedge clk) if (rst_n && !init && !bp_seen && a_rr && b_rr) begin
    `PROP(wa <= 2);
    `PROP(wb <= 2);
  end
  always @(posedge clk) if (rst_n) `COVER_T(aacc && bacc && a_addr == b_addr && !a_we && !b_we);
endmodule

`default_nettype wire
