// =============================================================================
// Formal harness macros.
//   default : PROP(x) is a proof obligation, COVER_T(x) a cover target.
//   FV_COVER: PROP(x) vanishes and every cover target becomes assert(!x), so
//             a BMC counterexample == the target is reachable (non-vacuity
//             check with engines that only understand safety properties).
// =============================================================================
`ifndef FV_DEFS_SVH
`define FV_DEFS_SVH
`ifdef FV_COVER
  `define PROP(x) ;
  `define COVER_T(x) assert (!(x));
`else
  `define PROP(x) assert (x);
  `define COVER_T(x) cover (x);
`endif
`endif
