// =============================================================================
// Formal harness: sram_sp (GENERIC backend, small bounded configuration)
// Proven obligations (BMC, see scripts/mem/run_formal.py for depth/engine):
//   * every embedded protocol assertion of sram_sp / sram_rsp_path
//     (credit bound, no FIFO overflow, no unsolicited response, response
//     stability under backpressure, no array access >= DEPTH, test-mode
//     exclusion);
//   * end-to-end: for ANY accepted response-producing request (chosen by the
//     solver) the delivered response has the right ID, err and we flags, and
//     for a read of the symbolic address ta the data equals the reference
//     shadow on every lane that has been written (byte-masked writes and
//     MBIST test writes included);
//   * a response-producing request is never answered out of order: the n-th
//     response belongs to the n-th such request.
// Environment assumptions: one reset at the start; the master keeps a pending
// request stable until accepted; tst_ce only while tst_active.
// =============================================================================
`include "sram_defs.svh"
`include "fv_defs.svh"
`default_nettype none

module fv_sram_sp #(
  parameter int DW    = 4,
  parameter int DEPTH = 5,
  parameter int MW    = 2,
  parameter int LAT   = 2,
  parameter int FIFO  = 3,
  parameter int WACK  = 1,
  parameter int IDW   = 2,
  localparam int AW   = $clog2(DEPTH),
  localparam int LW   = DW / MW
) (
  input wire logic           clk,
  input wire logic           rst_n,
  input wire logic           req_valid,
  input wire logic           req_we,
  input wire logic [AW-1:0]  req_addr,
  input wire logic [DW-1:0]  req_wdata,
  input wire logic [MW-1:0]  req_wmask,
  input wire logic [IDW-1:0] req_id,
  input wire logic           rsp_ready,
  input wire logic           tst_active,
  input wire logic           tst_ce,
  input wire logic           tst_we,
  input wire logic [AW-1:0]  tst_addr,
  input wire logic [DW-1:0]  tst_wdata
);
  logic           req_ready, rsp_valid, rsp_err, rsp_we, busy;
  logic [DW-1:0]  rsp_rdata, tst_rdata;
  logic [IDW-1:0] rsp_id;

  sram_sp #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .RSP_FIFO_DEPTH(FIFO),
            .WRITE_ACK(WACK), .ID_WIDTH(IDW)) dut (
    .clk, .rst_n, .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wmask, .req_id,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_we, .rsp_id,
    .tst_active, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy);

  // ------------------------------------------------------------ environment
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) begin
    if (init) assume (!rst_n);
    else      assume (rst_n);
    if (!tst_active) assume (!tst_ce);
    if (FIFO == 0) assume (rsp_ready);
  end
  reg             p_pend = 1'b0;
  reg             p_we;
  reg [AW-1:0]    p_addr;
  reg [DW-1:0]    p_wdata;
  reg [MW-1:0]    p_wmask;
  reg [IDW-1:0]   p_id;
  always @(posedge clk) begin
    p_pend <= rst_n && req_valid && !req_ready;
    p_we <= req_we; p_addr <= req_addr; p_wdata <= req_wdata; p_wmask <= req_wmask; p_id <= req_id;
  end
  always @(*) if (p_pend) assume (req_valid && req_we == p_we && req_addr == p_addr && req_wdata == p_wdata &&
                                  req_wmask == p_wmask && req_id == p_id);

  // ------------------------------------------------------------ reference shadow of the symbolic address
  (* anyconst *) reg [AW-1:0] ta;
  always @(*) assume (ta < DEPTH);
  function automatic [DW-1:0] lanes(input [MW-1:0] m);
    integer i;
    for (i = 0; i < DW; i = i + 1) lanes[i] = m[i / LW];
  endfunction
  reg [DW-1:0] shadow = '0;
  reg [MW-1:0] known  = '0;
  wire acc    = req_valid && req_ready;
  wire a_ok   = (req_addr < DEPTH);
  wire needs  = !req_we || (WACK != 0) || !a_ok;
  always @(posedge clk) begin
    if (rst_n && acc && req_we && a_ok && req_addr == ta) begin
      shadow <= (shadow & ~lanes(req_wmask)) | (req_wdata & lanes(req_wmask));
      known  <= known | req_wmask;
    end
    if (rst_n && tst_active && tst_ce && tst_we && tst_addr == ta) begin
      shadow <= tst_wdata;
      known  <= '1;
    end
  end

  // ------------------------------------------------------------ tracked transaction
  (* anyseq *) reg pick;
  reg [7:0]     seq_in = '0, seq_out = '0, t_seq;
  reg           tracking = 1'b0, t_rd, t_err, t_we;
  reg [IDW-1:0] t_id;
  reg [DW-1:0]  t_data;
  reg [MW-1:0]  t_known;
  wire deliver = rsp_valid && rsp_ready;
  always @(posedge clk) begin
    if (rst_n) begin
      if (acc && needs) seq_in <= seq_in + 1'b1;
      if (deliver)      seq_out <= seq_out + 1'b1;
      if (acc && needs && pick && !tracking) begin
        tracking <= 1'b1;
        t_seq    <= seq_in;
        t_rd     <= !req_we && a_ok && (req_addr == ta);
        t_err    <= !a_ok;
        t_we     <= req_we;
        t_id     <= req_id;
        t_data   <= shadow;
        t_known  <= known;
      end
      if (deliver && tracking && seq_out == t_seq) tracking <= 1'b0;
    end
  end
  always @(posedge clk) begin
    if (rst_n && !init) begin
      // the n-th response answers the n-th response-producing request
      `PROP(seq_out != seq_in || !rsp_valid);
      if (deliver && tracking && seq_out == t_seq) begin
        `PROP(rsp_id == t_id);
        `PROP(rsp_err == t_err);
        `PROP(rsp_we == t_we);
        if (t_rd) `PROP(((rsp_rdata ^ t_data) & lanes(t_known)) == '0);
        if (t_err || t_we) `PROP(rsp_rdata == '0);
      end
    end
  end
  // reachability: a tracked read of the symbolic address can complete
  always @(posedge clk) if (rst_n) `COVER_T(deliver && tracking && seq_out == t_seq && t_rd && known == '1);
endmodule

`default_nettype wire
