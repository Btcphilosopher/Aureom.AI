// =============================================================================
// Formal harness: sram_1r1w (GENERIC backend)
//   * embedded assertions (STALL never issues a same-address read+write pair;
//     FORBID collision check; response-path invariants);
//   * data: a tracked read of the symbolic address returns the word written
//     by writes accepted in EARLIER cycles (same-cycle write excluded) - the
//     ordering rule shared by STALL and READ_OLD;
//   * STALL starvation bound: with rsp_ready held high and no test mode, a
//     pending write or read waits at most 2 cycles (alternating priority).
// =============================================================================
`include "sram_defs.svh"
`include "fv_defs.svh"
`default_nettype none

module fv_sram_1r1w #(
  parameter int DW        = 4,
  parameter int DEPTH     = 4,
  parameter int MW        = 2,
  parameter int LAT       = 1,
  parameter int COLLISION = 0,
  parameter int FIFO      = 2,
  localparam int AW       = $clog2(DEPTH),
  localparam int LW       = DW / MW
) (
  input wire logic          clk,
  input wire logic          rst_n,
  input wire logic          wr_valid,
  input wire logic [AW-1:0] wr_addr,
  input wire logic [DW-1:0] wr_data,
  input wire logic [MW-1:0] wr_mask,
  input wire logic          rd_valid,
  input wire logic [AW-1:0] rd_addr,
  input wire logic          rd_id,
  input wire logic          rsp_ready,
  input wire logic          tst_active
);
  logic wr_ready, wr_err, rd_ready, rsp_valid, rsp_err, busy;
  logic [DW-1:0] rsp_rdata, tst_rdata;
  logic rsp_id;

  sram_1r1w #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .COLLISION(COLLISION),
              .RSP_FIFO_DEPTH(FIFO)) dut (
    .clk, .rst_n, .wr_valid, .wr_ready, .wr_addr, .wr_data, .wr_mask, .wr_err,
    .rd_valid, .rd_ready, .rd_addr, .rd_id, .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_id,
    .tst_active, .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata, .busy);

  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) begin
    if (init) assume (!rst_n); else assume (rst_n);
    if (COLLISION == 2) assume (!(wr_valid && rd_valid && wr_addr == rd_addr));
  end
  // master rules: pending requests are held stable
  reg pw = 0, pr = 0;
  reg [AW-1:0] pwa, pra; reg [DW-1:0] pwd; reg [MW-1:0] pwm; reg pri;
  always @(posedge clk) begin
    pw <= rst_n && wr_valid && !wr_ready; pr <= rst_n && rd_valid && !rd_ready;
    pwa <= wr_addr; pwd <= wr_data; pwm <= wr_mask; pra <= rd_addr; pri <= rd_id;
  end
  always @(*) begin
    if (pw) assume (wr_valid && wr_addr == pwa && wr_data == pwd && wr_mask == pwm);
    if (pr) assume (rd_valid && rd_addr == pra && rd_id == pri);
  end

  (* anyconst *) reg [AW-1:0] ta;
  function automatic [DW-1:0] lanes(input [MW-1:0] m);
    integer i;
    for (i = 0; i < DW; i = i + 1) lanes[i] = m[i / LW];
  endfunction
  reg [DW-1:0] shadow = '0;
  reg [MW-1:0] known = '0;
  wire wacc = wr_valid && wr_ready;
  wire racc = rd_valid && rd_ready;
  always @(posedge clk) if (rst_n && wacc && wr_addr == ta) begin
    shadow <= (shadow & ~lanes(wr_mask)) | (wr_data & lanes(wr_mask));
    known  <= known | wr_mask;
  end

  (* anyseq *) reg pick;
  reg [7:0] seq_in = 0, seq_out = 0, t_seq;
  reg tracking = 0, t_rd, t_id;
  reg [DW-1:0] t_data; reg [MW-1:0] t_known;
  wire deliver = rsp_valid && rsp_ready;
  always @(posedge clk) if (rst_n) begin
    if (racc) seq_in <= seq_in + 1'b1;
    if (deliver) seq_out <= seq_out + 1'b1;
    if (racc && pick && !tracking) begin
      tracking <= 1; t_seq <= seq_in; t_rd <= (rd_addr == ta); t_id <= rd_id;
      t_data <= shadow; t_known <= known;           // shadow before this cycle's write
    end
    if (deliver && tracking && seq_out == t_seq) tracking <= 0;
  end
  always @(posedge clk) if (rst_n && !init) begin
    `PROP(seq_out != seq_in || !rsp_valid);
    if (deliver && tracking && seq_out == t_seq) begin
      `PROP(rsp_id == t_id && !rsp_err);
      if (t_rd) `PROP(((rsp_rdata ^ t_data) & lanes(t_known)) == '0);
    end
  end

  // starvation bound (STALL, no backpressure, no test mode)
  reg [3:0] ww = 0, rw = 0;
  always @(posedge clk) begin
    ww <= (rst_n && wr_valid && !wr_ready && !tst_active) ? ww + 1'b1 : 4'd0;
    rw <= (rst_n && rd_valid && !rd_ready && !tst_active) ? rw + 1'b1 : 4'd0;
  end
  reg bp_seen = 0;
  always @(posedge clk) if (rst_n && (!rsp_ready || tst_active)) bp_seen <= 1;
  always @(posedge clk) if (rst_n && !init && COLLISION == 0 && !bp_seen && rsp_ready && !tst_active) begin
    `PROP(ww <= 2);
    `PROP(rw <= 2);
  end
  always @(posedge clk) if (rst_n) `COVER_T(deliver && tracking && seq_out == t_seq && t_rd && known == '1);
endmodule

`default_nettype wire
