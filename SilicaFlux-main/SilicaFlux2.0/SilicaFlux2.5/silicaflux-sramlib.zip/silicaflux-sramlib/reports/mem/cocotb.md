# cocotb results (Icarus Verilog)

| top | params | seed | result |
|---|---|---|---|
| sram_sp | `{'DATA_WIDTH': 32, 'DEPTH': 100, 'MASK_WIDTH': 4, 'READ_LATENCY': 2, 'ID_WIDTH': 3}` | 20261105 | PASS  |
| sram_sp | `{'DATA_WIDTH': 64, 'DEPTH': 1024, 'MASK_WIDTH': 8, 'READ_LATENCY': 1, 'ID_WIDTH': 2, 'BACKEND': 1}` | 20261106 | PASS  |
| sram_bank_controller | `{'NUM_MASTERS': 3, 'NUM_BANKS': 4, 'BANK_DEPTH': 64, 'DATA_WIDTH': 16, 'ID_WIDTH': 4, 'ADDR_WIDTH': 9}` | 20261107 | PASS  |
| sram_bank_controller | `{'NUM_MASTERS': 4, 'NUM_BANKS': 8, 'BANK_DEPTH': 32, 'DATA_WIDTH': 32, 'ID_WIDTH': 3, 'ADDR_WIDTH': 9, 'READ_LATENCY': 2}` | 20261108 | PASS  |
