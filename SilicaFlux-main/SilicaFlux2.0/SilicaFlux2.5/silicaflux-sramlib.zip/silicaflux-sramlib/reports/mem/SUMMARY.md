# SilicaFlux SRAM Wrapper Library - verification summary

Generated 2026-11-05T20:23:07Z.  Design sha256 `ee0f5e09652986b76e92007e7bc172d284a2af3bf2e38b3795aa10c9879a7ffd`; library tree sha256 `83f7e855c23064174f26ca9bb28d87e42b2252bd351e672bf965b8acf3c4e74b`.  Enclosing git: `not a git checkout` (library files committed: False).  SilicaFlux reference checkout: `e936758d5001a34dede816a6dceb2d2138f64753` (clean: True).

| check | source report | result |
|---|---|---|
| lint | regression.md | 47 pass / 0 fail |
| sim | regression.md | 53 pass / 0 fail |
| xsim | regression.md | 5 pass / 0 fail |
| equiv | regression.md | 11 pass / 0 fail |
| mutants | regression.md | 10 pass / 0 fail |
| scoreboard checks in the sim suite | regression.json | 2,731,959 |
| cocotb (Icarus) | cocotb.md | 4 pass / 0 fail |
| formal (BMC + cover) | formal.md | 9 pass / 0 fail |
| synthesis (generic / FPGA / ASIC) | synth.md | 29 pass / 0 fail |
| SilicaFlux 2.5 integration | integration.md | 3 pass / 0 fail |
| workload benchmarks (self-checking) | analysis.md | 48 of 48 runs PASS |

## Tools

| tool | version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| yosys-smtbmc | present |
| z3 | Z3 version 4.8.12 - 64 bit |
| boolector | 1.5.118 |
| sby | NOT INSTALLED |
| openroad | NOT INSTALLED |
| vivado | NOT INSTALLED |
| quartus_sh | NOT INSTALLED |
| python | 3.13.18 |
| cocotb | 2.1.0 |

Blocked / not available in the environment that produced these reports: sby, openroad, vivado, quartus_sh.

Every number above comes from the JSON reports in this directory; each JSON embeds the commands, exit codes,
seeds and tool versions of the run that produced it.
