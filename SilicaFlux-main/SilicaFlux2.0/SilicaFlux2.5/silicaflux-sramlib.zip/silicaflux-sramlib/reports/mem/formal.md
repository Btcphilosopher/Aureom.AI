# Formal verification report

Engine: Yosys `read_verilog -formal` -> AIGER -> ABC (`bmc3`, `pdr`).  BMC proves every assertion
(embedded RTL checkers + harness end-to-end properties) for ALL input sequences up to the given depth
from reset under the harness assumptions; the cover run shows the tracked scenario is reachable, so the
proof is not vacuous; PDR attempts an unbounded proof within a time limit.  Results hold for the listed
small parameterisations only; larger configurations are covered by simulation.

| job | params | depth | BMC | cover (non-vacuity) | PDR | claim | BMC secs |
|---|---|---|---|---|---|---|---|
| sram_sp lat2 fifo3 depth5 (non-pow2) | `{'LAT': 2, 'FIFO': 3}` | 20 | PASSED (20 frames) | REACHED at frame 5 | UNDECIDED (time limit) | bounded proof, depth 20 | 38.4 |
| sram_sp lat1 fifo1 posted writes | `{'LAT': 1, 'FIFO': 1, 'WACK': 0}` | 20 | PASSED (20 frames) | REACHED at frame 4 | UNDECIDED (time limit) | bounded proof, depth 20 | 2.92 |
| sram_sp lat1 no-backpressure mode | `{'LAT': 1, 'FIFO': 0}` | 20 | PASSED (20 frames) | REACHED at frame 4 | UNDECIDED (time limit) | bounded proof, depth 20 | 2.22 |
| sram_1r1w STALL | `{'COLLISION': 0}` | 20 | PASSED (20 frames) | REACHED at frame 5 | UNDECIDED (time limit) | bounded proof, depth 20 | 3.83 |
| sram_1r1w READ_OLD | `{'COLLISION': 1}` | 20 | PASSED (20 frames) | REACHED at frame 4 | UNDECIDED (time limit) | bounded proof, depth 20 | 3.06 |
| sram_1r1w FORBID | `{'COLLISION': 2}` | 20 | PASSED (20 frames) | REACHED at frame 5 | UNDECIDED (time limit) | bounded proof, depth 20 | 3.4 |
| sram_tdp STALL | `{}` | 20 | PASSED (20 frames) | REACHED at frame 3 | UNDECIDED (time limit) | bounded proof, depth 20 | 20.19 |
| sram_bank_controller 2x2 lat1 | `{}` | 16 | PASSED (16 frames) | REACHED at frame 5 | UNDECIDED (time limit) | bounded proof, depth 16 | 2.15 |
| sram_bank_controller 2x2 lat2 | `{'LAT': 2, 'FIFO': 3}` | 16 | PASSED (16 frames) | REACHED at frame 6 | UNDECIDED (time limit) | bounded proof, depth 16 | 6.9 |

Tools: yosys `Yosys 0.33 (git sha1 2584903a060)` (with its bundled yosys-abc).
