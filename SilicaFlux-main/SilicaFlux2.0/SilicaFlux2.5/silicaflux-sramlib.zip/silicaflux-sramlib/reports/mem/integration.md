# SilicaFlux 2.5 integration: memory_controller.sf on library SRAM banks

Testbench: MemoryFlow `tb_sf25_memctrl.sv` (from the repository's `SilicaFlux2.0/SilicaFlux2.5/silicaflux-memoryflow-v2.0.0.zip`), the existing
characterisation bench for the unmodified 2.5 scratchpad controller (8 banks x 512 x 128 b, parity,
scalar + vector + burst ports, random backpressure, burst kill, parity-error injection).

| run | MF result | checks | equal to baseline | metric differences | result |
|---|---|---|---|---|---|
| baseline: repository memory_controller.sf | PASS | 150843 | baseline | - | PASS |
| library banks, GENERIC backend | PASS | 150843 | True | 0 | PASS |
| library banks, FPGA backend | PASS | 150843 | True | 0 | PASS |

Baseline metrics (identical in every passing run):

* `sf25_burst_load_beats_per_cycle_L1` = 0.200000
* `sf25_burst_load_beats_per_cycle_L128` = 0.969697
* `sf25_burst_load_beats_per_cycle_L16` = 0.800000
* `sf25_burst_load_beats_per_cycle_L2` = 0.333333
* `sf25_burst_load_beats_per_cycle_L256` = 0.984615
* `sf25_burst_load_beats_per_cycle_L32` = 0.888889
* `sf25_burst_load_beats_per_cycle_L4` = 0.500000
* `sf25_burst_load_beats_per_cycle_L64` = 0.941176
* `sf25_burst_load_beats_per_cycle_L8` = 0.666667
* `sf25_burst_store_beats_per_cycle_L1` = 0.250000
* `sf25_burst_store_beats_per_cycle_L128` = 0.977099
* `sf25_burst_store_beats_per_cycle_L16` = 0.842105
* `sf25_burst_store_beats_per_cycle_L2` = 0.400000
* `sf25_burst_store_beats_per_cycle_L256` = 0.988417
* `sf25_burst_store_beats_per_cycle_L32` = 0.914286
* `sf25_burst_store_beats_per_cycle_L4` = 0.571429
* `sf25_burst_store_beats_per_cycle_L64` = 0.955224
* `sf25_burst_store_beats_per_cycle_L8` = 0.727273
* `sf25_init_cycles` = 512.000000
* `sf25_kill_accepted_beats` = 14.000000
* `sf25_kill_committed_beats` = 13.000000
* `sf25_scalar_load_latency_cycles` = 3.000000
* `sf25_scalar_load_stream_words_per_cycle` = 0.999512
* `sf25_scalar_store_stream_words_per_cycle` = 0.999512
* `sf25_sv_disjoint_bank_requests_per_cycle` = 1.992218
* `sf25_sv_same_bank_conflict_cycles` = 1023.000000
* `sf25_sv_same_bank_requests_per_cycle` = 0.998051
* `sf25_three_port_stream_bytes_per_cycle` = 29.873582
* `sf25_three_port_stream_requests_per_cycle` = 2.489465
* `sf25_total_burst_beats` = 21633.000000
* `sf25_total_scalar_responses` = 13253.000000
* `sf25_total_vector_responses` = 9285.000000
* `sf25_vector_load_latency_cycles` = 3.000000
* `sf25_vector_load_stream_bytes_per_cycle` = 15.984390
* `sf25_vector_load_stream_lines_per_cycle` = 0.999024
* `sf25_vector_store_stream_lines_per_cycle` = 0.999024
