# SRAM library regression report

Generated 2026-11-05T20:07:13Z on `Linux-6.18.44-fc-v236-x86_64-with-glibc2.39`.  Library tree sha256 `315b79cd2a76576a…`; git: `not a git checkout` (library files committed: False).

## Tools

| tool | version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| yosys-smtbmc | present |
| z3 | Z3 version 4.8.12 - 64 bit |
| boolector | 1.5.118 |
| sby | NOT INSTALLED |
| openroad | NOT INSTALLED |
| vivado | NOT INSTALLED |
| quartus_sh | NOT INSTALLED |
| python | 3.13.18 |
| cocotb | 2.1.0 |

Base seed: 20261105.  Command: `scripts/mem/run_regress.py --suite all --jobs 3 --out reports/mem/regression.json`

## Summary

| suite | PASS | FAIL | SKIP |
|---|---|---|---|
| lint | 47 | 0 | 0 |
| sim | 53 | 0 | 0 |
| xsim | 5 | 0 | 0 |
| equiv | 11 | 0 | 0 |
| mutants | 10 | 0 | 0 |

## lint

| kind | top | params | result | detail |
|---|---|---|---|---|
| positive | sram_sp | `{}` | PASS | 0 warnings |
| positive | sram_sp | `{"DATA_WIDTH": 128, "DEPTH": 100, "READ_LATENCY": 3, "RSP_FIFO_DEPTH": 0}` | PASS | 0 warnings |
| positive | sram_sp | `{"BACKEND": 1, "DEPTH": 4096}` | PASS | 0 warnings |
| positive | sram_sp | `{"BACKEND": 2, "MACRO": 1, "DEPTH": 1000, "DATA_WIDTH": 64}` | PASS | 0 warnings |
| positive | sram_1r1w | `{}` | PASS | 0 warnings |
| positive | sram_1r1w | `{"BACKEND": 2, "MACRO": 1}` | PASS | 0 warnings |
| positive | sram_1r1w | `{"BACKEND": 2, "MACRO": 66}` | PASS | 0 warnings |
| positive | sram_tdp | `{}` | PASS | 0 warnings |
| positive | sram_tdp | `{"BACKEND": 1}` | PASS | 0 warnings |
| positive | sram_tdp | `{"BACKEND": 2, "MACRO": 61}` | PASS | 0 warnings |
| positive | sram_bank_controller | `{}` | PASS | 0 warnings |
| positive | sram_bank_controller | `{"NUM_BANKS": 8, "NUM_MASTERS": 3, "ADDR_MODE": 1, "ADDR_WIDTH": 32}` | PASS | 0 warnings |
| positive | sram_bank_controller | `{"NUM_BANKS": 4, "BACKEND": 2, "MACRO": 21, "DATA_WIDTH": 64, "BANK_DEPTH": 2048}` | PASS | 0 warnings |
| positive | sram_mbist_march | `{"NUM_TARGETS": 4}` | PASS | 0 warnings |
| positive | sram_mbist_adapter | `{}` | PASS | 0 warnings |
| positive | sram_backend_1rw | `{"BACKEND": 2, "MACRO": 13, "DATA_WIDTH": 32, "MASK_WIDTH": 32, "DEPTH": 1500}` | PASS | 0 warnings |
| positive | sram_backend_2rw | `{"BACKEND": 2, "MACRO": 61, "READ_LATENCY": 2}` | PASS | 0 warnings |
| positive | sram_fpga_selftest_top | `{}` | PASS | 0 warnings |
| positive | sfv_memory_subsystem_example | `{}` | PASS | 0 warnings |
| positive | sfv_memory_subsystem_example | `{"BACKEND": 2, "MACRO_CTRL": 21, "MACRO_CPU": 24, "MACRO_SPM": 35}` | PASS | 0 warnings |
| negative | sram_1r1w | `{"BACKEND": 2, "MACRO": 13}` | PASS | expects 'single-port': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_1r1w | `{"BACKEND": 2, "MACRO": 1, "COLLISION": 1}` | PASS | expects 'READ_OLD is not guaranteed': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_tdp | `{"BACKEND": 2, "MACRO": 1}` | PASS | expects 'no 2RW': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_tdp | `{"BACKEND": 2, "MACRO": 13}` | PASS | expects 'single-port': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_tdp | `{"COLLISION": 1}` | PASS | expects 'STALL or FORBID': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 2, "MACRO": 91}` | PASS | expects 'commercial placeholder': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 2, "MACRO": 90}` | PASS | expects 'commercial placeholder': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 2, "MACRO": 92}` | PASS | expects 'commercial placeholder': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 2}` | PASS | expects 'requires an explicit MACRO': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 2, "MACRO": 55}` | PASS | expects 'not a catalogue entry': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 2, "MACRO": 1, "DATA_WIDTH": 36, "MASK_WIDTH": 4}` | PASS | expects 'mask granularity': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 2, "MACRO": 21, "READ_LATENCY": 0}` | PASS | expects 'READ_LATENCY': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 0, "INIT_FILE": "\"x.hex\""}` | PASS | expects 'only supported by the FPGA backend': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"BACKEND": 7}` | PASS | expects 'unknown BACKEND': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"DEPTH": 1}` | PASS | expects 'DEPTH must be >= 2': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"DATA_WIDTH": 32, "MASK_WIDTH": 3}` | PASS | expects 'MASK_WIDTH must divide': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_sp | `{"WRITE_ACK": 2}` | PASS | expects 'WRITE_ACK': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_bank_controller | `{"NUM_BANKS": 3}` | PASS | expects 'power of two': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_bank_controller | `{"INTERLEAVE": 1, "BANK_DEPTH": 100}` | PASS | expects 'power-of-two BANK_DEPTH': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_bank_controller | `{"ADDR_MODE": 1, "DATA_WIDTH": 24, "MASK_WIDTH": 3}` | PASS | expects 'power of two': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_bank_controller | `{"ADDR_WIDTH": 8}` | PASS | expects 'ADDR_WIDTH': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| negative | sram_mbist_march | `{"ALGO": 5}` | PASS | expects 'unknown ALGO': %Warning-USERFATAL: /tmp/claude-0/-home-user-Aureom-AI/23a55824-eb05-58e0-8ae8-ab181016d74d/scratchpad/silicaf |
| icarus-elab | sram_sp | `{}` | PASS |  |
| icarus-elab | sram_1r1w | `{}` | PASS |  |
| icarus-elab | sram_tdp | `{}` | PASS |  |
| icarus-elab | sram_bank_controller | `{}` | PASS |  |
| icarus-elab | sram_mbist_march | `{}` | PASS |  |

## sim

| tb | params | seed | checks | errors | result | secs |
|---|---|---|---|---|---|---|
| tb_sram_sp | `{"DW": 8, "DEPTH": 64, "MW": 1, "LAT": 1, "FIFO": 2}` | 20261105 | 17801 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 8, "DEPTH": 256, "MW": 1, "LAT": 2, "FIFO": 3}` | 20261106 | 20289 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 8, "DEPTH": 1024, "MW": 1, "LAT": 3, "FIFO": 4}` | 20261107 | 31873 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 8, "DEPTH": 4096, "MW": 1, "LAT": 1, "FIFO": 2}` | 20261108 | 77835 | 0 | PASS | 0.03 |
| tb_sram_sp | `{"DW": 16, "DEPTH": 64, "MW": 2, "LAT": 2, "FIFO": 3}` | 20261109 | 18115 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 16, "DEPTH": 256, "MW": 2, "LAT": 3, "FIFO": 4}` | 20261110 | 21242 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 16, "DEPTH": 1024, "MW": 2, "LAT": 1, "FIFO": 2}` | 20261111 | 32637 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 16, "DEPTH": 4096, "MW": 2, "LAT": 2, "FIFO": 3}` | 20261112 | 78873 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 32, "DEPTH": 64, "MW": 4, "LAT": 3, "FIFO": 4}` | 20261113 | 20186 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 32, "DEPTH": 256, "MW": 4, "LAT": 1, "FIFO": 2}` | 20261114 | 23102 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 32, "DEPTH": 1024, "MW": 4, "LAT": 2, "FIFO": 3}` | 20261115 | 34858 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 32, "DEPTH": 4096, "MW": 4, "LAT": 3, "FIFO": 4}` | 20261116 | 80893 | 0 | PASS | 0.03 |
| tb_sram_sp | `{"DW": 64, "DEPTH": 64, "MW": 8, "LAT": 1, "FIFO": 2}` | 20261117 | 33957 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 64, "DEPTH": 256, "MW": 8, "LAT": 2, "FIFO": 3}` | 20261118 | 36932 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 64, "DEPTH": 1024, "MW": 8, "LAT": 3, "FIFO": 4}` | 20261119 | 48572 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 64, "DEPTH": 4096, "MW": 8, "LAT": 1, "FIFO": 2}` | 20261120 | 94456 | 0 | PASS | 0.05 |
| tb_sram_sp | `{"DW": 128, "DEPTH": 64, "MW": 16, "LAT": 2, "FIFO": 3}` | 20261121 | 30820 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 128, "DEPTH": 256, "MW": 16, "LAT": 3, "FIFO": 4}` | 20261122 | 33629 | 0 | PASS | 0.03 |
| tb_sram_sp | `{"DW": 128, "DEPTH": 1024, "MW": 16, "LAT": 1, "FIFO": 2}` | 20261123 | 44959 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 128, "DEPTH": 4096, "MW": 16, "LAT": 2, "FIFO": 3}` | 20261124 | 91205 | 0 | PASS | 0.04 |
| tb_sram_sp | `{"DW": 32, "DEPTH": 1024, "MW": 4, "LAT": 1, "BACKEND": 1}` | 20261125 | 34564 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 128, "DEPTH": 256, "MW": 16, "LAT": 2, "FIFO": 3, "BACKEND": 1}` | 20261126 | 33818 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 16, "DEPTH": 4096, "MW": 2, "LAT": 1, "BACKEND": 1}` | 20261127 | 78722 | 0 | PASS | 0.03 |
| tb_sram_sp | `{"DW": 16, "DEPTH": 300, "MW": 16, "LAT": 1}` | 20261128 | 24687 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 36, "DEPTH": 1000, "MW": 4, "LAT": 2}` | 20261129 | 34780 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 32, "DEPTH": 100, "MW": 4, "LAT": 1, "FIFO": 0}` | 20261130 | 18354 | 0 | PASS | 0.01 |
| tb_sram_sp | `{"DW": 64, "DEPTH": 257, "MW": 8, "LAT": 3, "FIFO": 1}` | 20261131 | 37460 | 0 | PASS | 0.04 |
| tb_sram_sp | `{"DW": 32, "DEPTH": 3000, "MW": 4, "LAT": 2, "WACK": 0}` | 20261132 | 35491 | 0 | PASS | 0.02 |
| tb_sram_sp | `{"DW": 8, "DEPTH": 1000, "MW": 1, "LAT": 1, "WACK": 0, "FIFO": 5}` | 20261133 | 18162 | 0 | PASS | 0.01 |
| tb_sram_1r1w | `{"COLLISION": 0}` | 20261134 | 41737 | 0 | PASS | 0.02 |
| tb_sram_1r1w | `{"COLLISION": 1}` | 20261135 | 42349 | 0 | PASS | 0.02 |
| tb_sram_1r1w | `{"COLLISION": 2}` | 20261136 | 41861 | 0 | PASS | 0.02 |
| tb_sram_1r1w | `{"COLLISION": 0, "BACKEND": 1, "DW": 64, "MW": 8, "LAT": 2}` | 20261137 | 41919 | 0 | PASS | 0.02 |
| tb_sram_1r1w | `{"COLLISION": 1, "BACKEND": 1, "DW": 16, "MW": 2, "DEPTH": 4096}` | 20261138 | 45653 | 0 | PASS | 0.02 |
| tb_sram_1r1w | `{"COLLISION": 0, "DW": 8, "MW": 1, "DEPTH": 100, "LAT": 2}` | 20261139 | 41499 | 0 | PASS | 0.02 |
| tb_sram_1r1w | `{"COLLISION": 0, "DW": 128, "MW": 16, "DEPTH": 64, "LAT": 3, "FIFO": 1}` | 20261140 | 23096 | 0 | PASS | 0.03 |
| tb_sram_tdp | `{"COLLISION": 0}` | 20261141 | 30772 | 0 | PASS | 0.02 |
| tb_sram_tdp | `{"COLLISION": 2}` | 20261142 | 30819 | 0 | PASS | 0.02 |
| tb_sram_tdp | `{"COLLISION": 0, "BACKEND": 1, "DW": 64, "MW": 8, "LAT": 2, "WACK": 0}` | 20261143 | 17160 | 0 | PASS | 0.02 |
| tb_sram_tdp | `{"COLLISION": 0, "DW": 8, "MW": 8, "DEPTH": 100, "FIFO": 0}` | 20261144 | 37653 | 0 | PASS | 0.02 |
| tb_sram_banking | `{"NM": 2, "NB": 1, "BD": 256}` | 20261145 | 54562 | 0 | PASS | 0.03 |
| tb_sram_banking | `{"NM": 2, "NB": 2, "BD": 128, "DW": 8, "MW": 1}` | 20261146 | 79213 | 0 | PASS | 0.04 |
| tb_sram_banking | `{"NM": 4, "NB": 2, "BD": 100, "ILV": 0}` | 20261147 | 98851 | 0 | PASS | 0.05 |
| tb_sram_banking | `{"NM": 4, "NB": 4, "BD": 256}` | 20261148 | 151087 | 0 | PASS | 0.07 |
| tb_sram_banking | `{"NM": 4, "NB": 4, "BD": 256, "ARB": 1, "ILV": 1}` | 20261149 | 155461 | 0 | PASS | 0.06 |
| tb_sram_banking | `{"NM": 3, "NB": 8, "BD": 100, "LAT": 2, "AMODE": 1}` | 20261150 | 120580 | 0 | PASS | 0.07 |
| tb_sram_banking | `{"NM": 8, "NB": 8, "BD": 64, "DW": 64, "MW": 8, "LAT": 3, "FIFO": 2}` | 20261151 | 185899 | 0 | PASS | 0.13 |
| tb_sram_banking | `{"NM": 4, "NB": 8, "BD": 128, "DW": 128, "MW": 16, "AMODE": 1, "WACK": 0}` | 20261152 | 106756 | 0 | PASS | 0.11 |
| tb_sram_banking | `{"NM": 4, "NB": 4, "BD": 512, "BACKEND": 1, "LAT": 2}` | 20261153 | 151366 | 0 | PASS | 0.07 |
| tb_sram_banking | `{"NM": 1, "NB": 4, "BD": 64, "DW": 16, "MW": 2, "FIFO": 0}` | 20261154 | 45235 | 0 | PASS | 0.03 |
| tb_sram_mbist | `{"LAT": 1, "PIPE": 0}` | 20261155 | 57 | 0 | PASS | 0.03 |
| tb_sram_mbist | `{"LAT": 2, "PIPE": 1}` | 20261156 | 57 | 0 | PASS | 0.03 |
| tb_sram_fpga_selftest | `{}` | 20261157 | 45 | 0 | PASS | 0.01 |

## xsim

| tb | params | checks (VL / IV) | trace lines | identical | result |
|---|---|---|---|---|---|
| tb_sram_sp | `{"DW": 32, "DEPTH": 1024, "MW": 4, "LAT": 1}` | 34991 / 34991 | 8758 | True | PASS |
| tb_sram_sp | `{"DW": 8, "DEPTH": 100, "MW": 1, "LAT": 2}` | 18674 / 18674 | 4392 | True | PASS |
| tb_sram_1r1w | `{"COLLISION": 0}` | 25374 / 25374 | 4144 | True | PASS |
| tb_sram_tdp | `{"COLLISION": 0}` | 18737 / 18737 | 9255 | True | PASS |
| tb_sram_banking | `{"NM": 4, "NB": 4, "BD": 64}` | 45316 / 45316 | 15049 | True | PASS |

## equiv

| configuration | tiling (from elaboration) | generic | vendor model | checks | traces | result |
|---|---|---|---|---|---|---|
| sky130 1RW 32x256 native | ASIC macro id 1 family 1: 1 col x 1 row = 1 instance(s) of 256x32 for 256x32, latency 1+0 | PASS | PASS | 23471 / 23471 | identical | PASS |
| sky130 1RW 64x1000 tiled 2x4 | ASIC macro id 1 family 1: 2 col x 4 row = 8 instance(s) of 256x32 for 1000x64, latency 1+1 | PASS | PASS | 48740 / 48740 | identical | PASS |
| sky130 1RW 8x1024 + posted writes | ASIC macro id 3 family 1: 1 col x 1 row = 1 instance(s) of 1024x8 for 1024x8, latency 1+0 | PASS | PASS | 17833 / 17833 | identical | PASS |
| sky130 1R1W 32x512 STALL | ASIC macro id 2 family 1: 1 col x 1 row = 1 instance(s) of 512x32 for 512x32, latency 1+0 | PASS | PASS | 25374 / 25374 | identical | PASS |
| gf180 1RW 32x512 bit-mask (4 cols) | ASIC macro id 13 family 2: 4 col x 1 row = 4 instance(s) of 512x8 for 512x32, latency 1+0 | PASS | PASS | 29904 / 29904 | identical | PASS |
| gf180 1RW 16x150 tiled 2x3 | ASIC macro id 10 family 2: 2 col x 3 row = 6 instance(s) of 64x8 for 150x16, latency 1+1 | PASS | PASS | 20223 / 20223 | identical | PASS |
| ihp 1P 32x2048 tiled 1x2 lat2 | ASIC macro id 21 family 3: 1 col x 2 row = 2 instance(s) of 1024x32 for 2048x32, latency 1+1 | PASS | PASS | 50343 / 50343 | identical | PASS |
| ihp 1P 128x256 tiled 2x1 | ASIC macro id 29 family 3: 2 col x 1 row = 2 instance(s) of 256x64 for 256x128, latency 1+0 | PASS | PASS | 33918 / 33918 | identical | PASS |
| ihp 2P 2RW 32x1024 STALL | ASIC macro id 61 family 4: 1 col x 1 row = 1 instance(s) of 1024x32 for 1024x32, latency 1+0 | PASS | PASS | 20230 / 20230 | identical | PASS |
| ihp 2P 1R1W 32x500 STALL | ASIC macro id 66 family 4: 1 col x 1 row = 1 instance(s) of 512x32 for 500x32, latency 1+0 | PASS | PASS | 25450 / 25450 | identical | PASS |
| sky130 4-bank controller | ASIC macro id 1 family 1: 1 col x 1 row = 1 instance(s) of 256x32 for 256x32, latency 1+0 | PASS | PASS | 60571 / 60571 | identical | PASS |

## mutants

| injected bug | testbench | verdict | first detection |
|---|---|---|---|
| rsp FIFO bypass ignores queued responses (reordering) | tb_sram_sp | killed | SRAM_ERROR t=15515000 rsp_id=1 exp 3 |
| credit check off by one (FIFO overflow) | tb_sram_sp | killed | [15375000] %Error: sram_rsp_path.sv:186: Assertion failed in TOP.tb_sram_sp.dut.u_rsp.g_fifo: TOP.tb |
| write mask ignored | tb_sram_sp | killed | SRAM_ERROR t=1605000 rsp_rdata=a2a9639f exp a2a9e49f (known ffffffff) |
| invalid-address check removed | tb_sram_sp | killed | [8595000] %Error: sram_generic_1rw.sv:122: Assertion failed in TOP.tb_sram_sp.dut.u_array.g_generic. |
| 1R1W STALL does not stall the write | tb_sram_1r1w | killed | [7305000] %Error: sram_1r1w.sv:188: Assertion failed in TOP.tb_sram_1r1w.dut: TOP.tb_sram_1r1w.dut:  |
| 2RW conflict not prevented | tb_sram_tdp | killed | [6985000] %Error: sram_generic_2rw.sv:93: Assertion failed in TOP.tb_sram_tdp.dut.u_array.g_generic. |
| bank owner pipeline misroutes read data | tb_sram_banking | killed | [135000] %Error: sram_bank_controller.sv:310: Assertion failed in TOP.tb_sram_banking.dut.unnamedblk |
| bank decode aliases banks | tb_sram_banking | killed | SRAM_ERROR t=755000 master 1: rdata 59ce5db1 exp 1dce5db1 |
| MBIST March element 2 reads the wrong value | tb_sram_mbist | killed | SRAM_ERROR t=29550000 fault-free March C- (solid) must pass |
| test mode does not block functional requests | tb_sram_sp | killed | [42055000] %Error: sram_sp.sv:155: Assertion failed in TOP.tb_sram_sp.dut: TOP.tb_sram_sp.dut: funct |
