# SRAM capacity, area and bandwidth analysis

All area figures are MACRO-ONLY sums of published macro dimensions (manifest `physical.source`: LEF SIZE for
SKY130, spec CSV for GF180MCU, datasheet for IHP SG13G2).  They exclude placement halos, power rings, routing
channels, the standard-cell glue and any ECC/redundancy.  No silicon, FPGA board or sign-off data exists.

## Capacity vs open-PDK macros (single-port, best macro per family, byte lanes)

| capacity | word | banks | family | best macro | instances | utilisation | macro area mm2 | macro-limited clock | peak B/cycle |
|---|---|---|---|---|---|---|---|---|---|
| 32 KiB | 32 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 64 | 1.00 | 13.40 | 108 MHz (GF180 spec, 3.3 V typ) | 4 |
| 32 KiB | 32 | 1 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 4 | 1.00 | 1.03 | not characterised in manifest | 4 |
| 32 KiB | 32 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 8 | 1.00 | 2.11 | not characterised in manifest | 4 |
| 32 KiB | 32 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 16 | 1.00 | 4.55 | not characterised in manifest | 4 |
| 32 KiB | 32 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 64 | 1.00 | 13.40 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 32 KiB | 32 | 4 | IHP_1P | `RM_IHPSG13_1P_2048x32_c2_bm_bist` | 4 | 1.00 | 1.04 | not characterised in manifest | 16 |
| 32 KiB | 32 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 8 | 1.00 | 2.11 | not characterised in manifest | 16 |
| 32 KiB | 32 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 16 | 1.00 | 4.55 | not characterised in manifest | 16 |
| 32 KiB | 128 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 64 | 1.00 | 13.40 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 32 KiB | 128 | 1 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 2 | 1.00 | 0.98 | not characterised in manifest | 16 |
| 32 KiB | 128 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 8 | 1.00 | 2.11 | not characterised in manifest | 16 |
| 32 KiB | 128 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 16 | 1.00 | 4.55 | not characterised in manifest | 16 |
| 32 KiB | 128 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 64 | 1.00 | 13.40 | 108 MHz (GF180 spec, 3.3 V typ) | 64 |
| 32 KiB | 128 | 4 | IHP_1P | `RM_IHPSG13_1P_512x64_c2_bm_bist` | 8 | 1.00 | 1.20 | not characterised in manifest | 64 |
| 32 KiB | 128 | 4 | IHP_2P | `RM_IHPSG13_2P_512x32_c2_bm_bist` | 16 | 1.00 | 2.41 | not characterised in manifest | 64 |
| 32 KiB | 128 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 16 | 1.00 | 4.55 | not characterised in manifest | 64 |
| 64 KiB | 32 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 128 | 1.00 | 26.80 | 108 MHz (GF180 spec, 3.3 V typ) | 4 |
| 64 KiB | 32 | 1 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 8 | 1.00 | 2.06 | not characterised in manifest | 4 |
| 64 KiB | 32 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 16 | 1.00 | 4.23 | not characterised in manifest | 4 |
| 64 KiB | 32 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 32 | 1.00 | 9.11 | not characterised in manifest | 4 |
| 64 KiB | 32 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 128 | 1.00 | 26.80 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 64 KiB | 32 | 4 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 8 | 1.00 | 2.06 | not characterised in manifest | 16 |
| 64 KiB | 32 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 16 | 1.00 | 4.23 | not characterised in manifest | 16 |
| 64 KiB | 32 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 32 | 1.00 | 9.11 | not characterised in manifest | 16 |
| 64 KiB | 128 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 128 | 1.00 | 26.80 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 64 KiB | 128 | 1 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 4 | 1.00 | 1.97 | not characterised in manifest | 16 |
| 64 KiB | 128 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 16 | 1.00 | 4.23 | not characterised in manifest | 16 |
| 64 KiB | 128 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 32 | 1.00 | 9.11 | not characterised in manifest | 16 |
| 64 KiB | 128 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 128 | 1.00 | 26.80 | 108 MHz (GF180 spec, 3.3 V typ) | 64 |
| 64 KiB | 128 | 4 | IHP_1P | `RM_IHPSG13_1P_1024x64_c2_bm_bist` | 8 | 1.00 | 2.11 | not characterised in manifest | 64 |
| 64 KiB | 128 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 16 | 1.00 | 4.23 | not characterised in manifest | 64 |
| 64 KiB | 128 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 32 | 1.00 | 9.11 | not characterised in manifest | 64 |
| 128 KiB | 32 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 256 | 1.00 | 53.61 | 108 MHz (GF180 spec, 3.3 V typ) | 4 |
| 128 KiB | 32 | 1 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 16 | 1.00 | 4.12 | not characterised in manifest | 4 |
| 128 KiB | 32 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 32 | 1.00 | 8.45 | not characterised in manifest | 4 |
| 128 KiB | 32 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 64 | 1.00 | 18.21 | not characterised in manifest | 4 |
| 128 KiB | 32 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 256 | 1.00 | 53.61 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 128 KiB | 32 | 4 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 16 | 1.00 | 4.12 | not characterised in manifest | 16 |
| 128 KiB | 32 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 32 | 1.00 | 8.45 | not characterised in manifest | 16 |
| 128 KiB | 32 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 64 | 1.00 | 18.21 | not characterised in manifest | 16 |
| 128 KiB | 128 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 256 | 1.00 | 53.61 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 128 KiB | 128 | 1 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 8 | 1.00 | 3.93 | not characterised in manifest | 16 |
| 128 KiB | 128 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 32 | 1.00 | 8.45 | not characterised in manifest | 16 |
| 128 KiB | 128 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 64 | 1.00 | 18.21 | not characterised in manifest | 16 |
| 128 KiB | 128 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 256 | 1.00 | 53.61 | 108 MHz (GF180 spec, 3.3 V typ) | 64 |
| 128 KiB | 128 | 4 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 8 | 1.00 | 3.93 | not characterised in manifest | 64 |
| 128 KiB | 128 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 32 | 1.00 | 8.45 | not characterised in manifest | 64 |
| 128 KiB | 128 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 64 | 1.00 | 18.21 | not characterised in manifest | 64 |
| 256 KiB | 32 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 512 | 1.00 | 107.21 | 108 MHz (GF180 spec, 3.3 V typ) | 4 |
| 256 KiB | 32 | 1 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 32 | 1.00 | 8.24 | not characterised in manifest | 4 |
| 256 KiB | 32 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 64 | 1.00 | 16.91 | not characterised in manifest | 4 |
| 256 KiB | 32 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 128 | 1.00 | 36.42 | not characterised in manifest | 4 |
| 256 KiB | 32 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 512 | 1.00 | 107.21 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 256 KiB | 32 | 4 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 32 | 1.00 | 8.24 | not characterised in manifest | 16 |
| 256 KiB | 32 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 64 | 1.00 | 16.91 | not characterised in manifest | 16 |
| 256 KiB | 32 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 128 | 1.00 | 36.42 | not characterised in manifest | 16 |
| 256 KiB | 128 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 512 | 1.00 | 107.21 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 256 KiB | 128 | 1 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 16 | 1.00 | 7.87 | not characterised in manifest | 16 |
| 256 KiB | 128 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 64 | 1.00 | 16.91 | not characterised in manifest | 16 |
| 256 KiB | 128 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 128 | 1.00 | 36.42 | not characterised in manifest | 16 |
| 256 KiB | 128 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 512 | 1.00 | 107.21 | 108 MHz (GF180 spec, 3.3 V typ) | 64 |
| 256 KiB | 128 | 4 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 16 | 1.00 | 7.87 | not characterised in manifest | 64 |
| 256 KiB | 128 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 64 | 1.00 | 16.91 | not characterised in manifest | 64 |
| 256 KiB | 128 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 128 | 1.00 | 36.42 | not characterised in manifest | 64 |
| 512 KiB | 32 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 1024 | 1.00 | 214.43 | 108 MHz (GF180 spec, 3.3 V typ) | 4 |
| 512 KiB | 32 | 1 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 64 | 1.00 | 16.49 | not characterised in manifest | 4 |
| 512 KiB | 32 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 128 | 1.00 | 33.81 | not characterised in manifest | 4 |
| 512 KiB | 32 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 256 | 1.00 | 72.84 | not characterised in manifest | 4 |
| 512 KiB | 32 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 1024 | 1.00 | 214.43 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 512 KiB | 32 | 4 | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 64 | 1.00 | 16.49 | not characterised in manifest | 16 |
| 512 KiB | 32 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 128 | 1.00 | 33.81 | not characterised in manifest | 16 |
| 512 KiB | 32 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 256 | 1.00 | 72.84 | not characterised in manifest | 16 |
| 512 KiB | 128 | 1 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 1024 | 1.00 | 214.43 | 108 MHz (GF180 spec, 3.3 V typ) | 16 |
| 512 KiB | 128 | 1 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 32 | 1.00 | 15.73 | not characterised in manifest | 16 |
| 512 KiB | 128 | 1 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 128 | 1.00 | 33.81 | not characterised in manifest | 16 |
| 512 KiB | 128 | 1 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 256 | 1.00 | 72.84 | not characterised in manifest | 16 |
| 512 KiB | 128 | 4 | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 1024 | 1.00 | 214.43 | 108 MHz (GF180 spec, 3.3 V typ) | 64 |
| 512 KiB | 128 | 4 | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 32 | 1.00 | 15.73 | not characterised in manifest | 64 |
| 512 KiB | 128 | 4 | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 128 | 1.00 | 33.81 | not characterised in manifest | 64 |
| 512 KiB | 128 | 4 | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 256 | 1.00 | 72.84 | not characterised in manifest | 64 |

Full table (all widths and 1/2/4/8 banks): `reports/mem/analysis.json`.

## SilicaFlux-V illustrative presets on open-PDK macros (best macro per family)

| preset | organisation | family | macro | tiling (cols x rows) | instances | macro area mm2 |
|---|---|---|---|---|---|---|
| small control SRAM | 32 b x 1024 (4 KiB) | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 4 x 2 | 8 | 1.675 |
| small control SRAM | 32 b x 1024 (4 KiB) | IHP_1P | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | 1 x 1 | 1 | 0.140 |
| small control SRAM | 32 b x 1024 (4 KiB) | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 1 x 1 | 1 | 0.264 |
| small control SRAM | 32 b x 1024 (4 KiB) | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 1 x 2 | 2 | 0.569 |
| CPU SRAM bank | 32 b x 4096 (16 KiB) | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 4 x 8 | 32 | 6.701 |
| CPU SRAM bank | 32 b x 4096 (16 KiB) | IHP_1P | `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 2 x 1 | 2 | 0.515 |
| CPU SRAM bank | 32 b x 4096 (16 KiB) | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 1 x 4 | 4 | 1.057 |
| CPU SRAM bank | 32 b x 4096 (16 KiB) | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 1 x 8 | 8 | 2.276 |
| vector scratchpad | 64 b x 4096 (32 KiB) | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 8 x 8 | 64 | 13.402 |
| vector scratchpad | 64 b x 4096 (32 KiB) | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 1 x 2 | 2 | 0.983 |
| vector scratchpad | 64 b x 4096 (32 KiB) | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 2 x 4 | 8 | 2.113 |
| vector scratchpad | 64 b x 4096 (32 KiB) | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 2 x 8 | 16 | 4.553 |
| tensor scratchpad | 128 b x 2048 (32 KiB) | GF180_1RW | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 16 x 4 | 64 | 13.402 |
| tensor scratchpad | 128 b x 2048 (32 KiB) | IHP_1P | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 2 x 1 | 2 | 0.983 |
| tensor scratchpad | 128 b x 2048 (32 KiB) | IHP_2P | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 4 x 2 | 8 | 2.113 |
| tensor scratchpad | 128 b x 2048 (32 KiB) | SKY130_1RW1R | `sky130_sram_2kbyte_1rw1r_32x512_8` | 4 x 4 | 16 | 4.553 |

Commercial 130 / 65 / 28 nm: `SRAM_MACRO_COMMERCIAL_130NM` PENDING_NO_MACRO; `SRAM_MACRO_COMMERCIAL_28NM` PENDING_NO_MACRO; `SRAM_MACRO_COMMERCIAL_65NM` PENDING_NO_MACRO - no area or timing can be stated until a licensed memory compiler's outputs are obtained.

## Simulated workloads on sram_bank_controller (4 masters, self-checking testbench)

| word | banks | workload | words/cycle | bytes/cycle | conflict rate | avg latency | max latency | toggles/access | TB |
|---|---|---|---|---|---|---|---|---|---|
| 32 | 1 | cpu | 1.000 | 4.002 | 0.701 | 1.00 | 1 | 19.8 | PASS |
| 32 | 1 | vector | 1.001 | 4.003 | 0.750 | 1.00 | 1 | 18.0 | PASS |
| 32 | 1 | tensor | 1.001 | 4.003 | 0.750 | 1.00 | 1 | 18.0 | PASS |
| 32 | 1 | dma | 1.001 | 4.003 | 0.750 | 1.00 | 1 | 22.2 | PASS |
| 32 | 1 | mixed | 1.001 | 4.003 | 0.739 | 1.00 | 1 | 21.4 | PASS |
| 32 | 1 | stride_nb | 1.001 | 4.003 | 0.750 | 1.00 | 1 | 16.5 | PASS |
| 32 | 2 | cpu | 1.780 | 7.119 | 0.371 | 1.00 | 1 | 20.2 | PASS |
| 32 | 2 | vector | 2.000 | 8.001 | 0.500 | 1.00 | 1 | 18.0 | PASS |
| 32 | 2 | tensor | 2.000 | 8.001 | 0.500 | 1.00 | 1 | 18.0 | PASS |
| 32 | 2 | dma | 1.997 | 7.988 | 0.501 | 1.00 | 1 | 21.5 | PASS |
| 32 | 2 | mixed | 1.995 | 7.979 | 0.464 | 1.00 | 1 | 21.4 | PASS |
| 32 | 2 | stride_nb | 1.001 | 4.003 | 0.750 | 1.00 | 1 | 16.5 | PASS |
| 32 | 4 | cpu | 2.147 | 8.588 | 0.165 | 1.00 | 1 | 20.0 | PASS |
| 32 | 4 | vector | 3.998 | 15.994 | 0.000 | 1.00 | 1 | 18.0 | PASS |
| 32 | 4 | tensor | 3.998 | 15.994 | 0.000 | 1.00 | 1 | 18.0 | PASS |
| 32 | 4 | dma | 3.923 | 15.693 | 0.019 | 1.00 | 1 | 20.9 | PASS |
| 32 | 4 | mixed | 3.129 | 12.516 | 0.144 | 1.00 | 1 | 20.9 | PASS |
| 32 | 4 | stride_nb | 1.001 | 4.003 | 0.750 | 1.00 | 1 | 16.5 | PASS |
| 32 | 8 | cpu | 2.271 | 9.083 | 0.088 | 1.00 | 1 | 19.4 | PASS |
| 32 | 8 | vector | 3.998 | 15.994 | 0.000 | 1.00 | 1 | 18.0 | PASS |
| 32 | 8 | tensor | 3.998 | 15.994 | 0.000 | 1.00 | 1 | 18.0 | PASS |
| 32 | 8 | dma | 3.970 | 15.878 | 0.008 | 1.00 | 1 | 20.5 | PASS |
| 32 | 8 | mixed | 3.372 | 13.488 | 0.068 | 1.00 | 1 | 20.4 | PASS |
| 32 | 8 | stride_nb | 1.001 | 4.003 | 0.750 | 1.00 | 1 | 16.5 | PASS |
| 128 | 1 | cpu | 1.000 | 16.008 | 0.701 | 2.00 | 2 | 67.8 | PASS |
| 128 | 1 | vector | 1.001 | 16.013 | 0.750 | 2.00 | 2 | 65.9 | PASS |
| 128 | 1 | tensor | 1.001 | 16.013 | 0.750 | 2.00 | 2 | 65.9 | PASS |
| 128 | 1 | dma | 1.001 | 16.013 | 0.750 | 2.00 | 2 | 69.2 | PASS |
| 128 | 1 | mixed | 1.001 | 16.013 | 0.739 | 2.00 | 2 | 68.5 | PASS |
| 128 | 1 | stride_nb | 1.001 | 16.013 | 0.750 | 2.00 | 2 | 64.6 | PASS |
| 128 | 2 | cpu | 1.780 | 28.475 | 0.371 | 2.00 | 2 | 68.2 | PASS |
| 128 | 2 | vector | 2.000 | 32.003 | 0.500 | 2.00 | 2 | 66.0 | PASS |
| 128 | 2 | tensor | 2.000 | 32.003 | 0.500 | 2.00 | 2 | 66.0 | PASS |
| 128 | 2 | dma | 1.997 | 31.952 | 0.501 | 2.00 | 2 | 68.5 | PASS |
| 128 | 2 | mixed | 1.995 | 31.917 | 0.464 | 2.00 | 2 | 68.3 | PASS |
| 128 | 2 | stride_nb | 1.001 | 16.013 | 0.750 | 2.00 | 2 | 64.6 | PASS |
| 128 | 4 | cpu | 2.147 | 34.352 | 0.165 | 2.00 | 2 | 67.9 | PASS |
| 128 | 4 | vector | 3.998 | 63.976 | 0.000 | 2.00 | 2 | 66.0 | PASS |
| 128 | 4 | tensor | 3.998 | 63.976 | 0.000 | 2.00 | 2 | 65.9 | PASS |
| 128 | 4 | dma | 3.923 | 62.771 | 0.019 | 2.00 | 2 | 68.0 | PASS |
| 128 | 4 | mixed | 3.129 | 50.064 | 0.144 | 2.00 | 2 | 67.9 | PASS |
| 128 | 4 | stride_nb | 1.001 | 16.013 | 0.750 | 2.00 | 2 | 64.6 | PASS |
| 128 | 8 | cpu | 2.271 | 36.333 | 0.088 | 2.00 | 2 | 67.5 | PASS |
| 128 | 8 | vector | 3.998 | 63.976 | 0.000 | 2.00 | 2 | 66.0 | PASS |
| 128 | 8 | tensor | 3.998 | 63.976 | 0.000 | 2.00 | 2 | 65.9 | PASS |
| 128 | 8 | dma | 3.970 | 63.512 | 0.008 | 2.00 | 2 | 67.5 | PASS |
| 128 | 8 | mixed | 3.372 | 53.952 | 0.068 | 2.00 | 2 | 67.5 | PASS |
| 128 | 8 | stride_nb | 1.001 | 16.013 | 0.750 | 2.00 | 2 | 64.6 | PASS |

Peak per-cycle bandwidth = min(masters, banks) x word.  Latency in cycles from acceptance; the
configured READ_LATENCY is the floor (1 for 32-bit rows, 2 for 128-bit rows).  toggles/access is the
Hamming distance between consecutive bank input words (row + write data): an activity proxy, not power.
Seed and cycle counts are in analysis.json; cycles per run: 4000.
