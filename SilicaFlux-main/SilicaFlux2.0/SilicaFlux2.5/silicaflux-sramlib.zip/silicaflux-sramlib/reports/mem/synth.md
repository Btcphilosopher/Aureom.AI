# Synthesis report (Yosys)

generic  `synth` (technology-independent gates) of every public module:
           elaboration, inferred memories (width x depth, read/write ports,
           from `memory -nomap` before mapping), flip-flop / cell counts,
           latch check (must be zero), warning count.
  fpga     block-RAM inference with Yosys' vendor flows (synth_xilinx xc7,
           synth_ice40, synth_ecp5): RAM primitive counts must be > 0 and no
           memory may fall back to flip-flops (checked via $mem cells absent
           and RAM primitives present).  This is inference evidence only: no
           vendor tool (Vivado/Quartus/Radiant) and no board was available.
  asic     BACKEND=ASIC with the pin-only macro black boxes: the exact
           expected number of real macro instances must survive synthesis,
           and no $mem cell (i.e. no flip-flop array) may exist.  A passing
           generic synthesis is NOT evidence of macro integration; this check
           is the macro-integrity gate.  Physical views (LEF/GDS) are not used.
Results: reports/mem/synth.{json,md}.

Yosys: `Yosys 0.33 (git sha1 2584903a060)`.  Vivado: NOT INSTALLED; Quartus: NOT INSTALLED; OpenROAD: NOT INSTALLED.

## Generic synthesis

| module | params | memories inferred (W x D, rd/wr ports) | cells | flip-flops | latches | warnings | result |
|---|---|---|---|---|---|---|---|
| sram_sp | `{"DATA_WIDTH": 32, "DEPTH": 1024}` | 32x1024 (1R/1W); 32x2 (1R/1W); 1x2 (1R/1W) | 71079 | 32883 | 0 | 1 | PASS |
| sram_sp | `{"DATA_WIDTH": 128, "DEPTH": 100, "READ_LATENCY": 3, "RSP_FIFO_DEPTH": 0}` | 128x100 (1R/1W) | 28092 | 13200 | 0 | 2 | PASS |
| sram_1r1w | `{"DATA_WIDTH": 32, "DEPTH": 512}` | 32x512 (1R/1W); 32x2 (1R/1W); 1x2 (1R/1W) | 35769 | 16496 | 0 | 1 | PASS |
| sram_tdp | `{"DATA_WIDTH": 32, "DEPTH": 256}` | 32x256 (2R/2W); 32x2 (1R/1W); 1x2 (1R/1W); 32x2 (1R/1W); 1x2 (1R/1W) | 37073 | 8422 | 0 | 1 | PASS |
| sram_bank_controller | `{"NUM_MASTERS": 4, "NUM_BANKS": 4, "BANK_DEPTH": 256}` | 32x256 (1R/1W); 32x256 (1R/1W); 32x256 (1R/1W); 32x256 (1R/1W); 32x2 (1R/1W); 4x2 (1R/1W); 32x2 (1R/1W); 4x2 (1R/1W); 32x2 (1R/1W); 4x2 (1R/1W); 32x2 (1R/1W); 4x2 (1R/1W) | 74555 | 33281 | 0 | 9 | PASS |
| sram_bank_controller | `{"NUM_MASTERS": 8, "NUM_BANKS": 8, "DATA_WIDTH": 64, "BANK_DEPTH": 64, "ADDR_MODE": 1}` | 64x64 (1R/1W); 64x64 (1R/1W); 64x64 (1R/1W); 64x64 (1R/1W); 64x64 (1R/1W); 64x64 (1R/1W); 64x64 (1R/1W); 64x64 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W); 64x2 (1R/1W); 4x2 (1R/1W) | 93113 | 34585 | 0 | 9 | PASS |
| sram_rsp_path | `{"DATA_WIDTH": 128, "LATENCY": 2, "FIFO_DEPTH": 3}` | 128x3 (1R/1W); 1x3 (1R/1W) | 1025 | 414 | 0 | 1 | PASS |
| sram_mbist_march | `{"NUM_TARGETS": 6, "DW": 32, "AW": 12}` | none | 919 | 132 | 0 | 4 | PASS |
| sram_mbist_adapter | `{}` | none | 2 | 0 | 0 | 0 | PASS |

## FPGA block-RAM inference

| configuration | flow | RAM primitives | other cells | result |
|---|---|---|---|---|
| xc7 sram_sp 32x1024 (4 KiB) | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | {'CARRY4': 10, 'FDCE': 10, 'FDRE': 10, 'LUT2': 51, 'LUT3': 56, 'LUT4': 36, 'LUT5': 6, 'LUT6': 12} | PASS |
| xc7 sram_sp 32x1024 lat2 (output reg) | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | {'CARRY4': 10, 'FDCE': 13, 'FDRE': 49, 'LUT2': 52, 'LUT3': 58, 'LUT4': 39, 'LUT5': 5, 'LUT6': 16} | PASS |
| xc7 sram_sp 64x4096 (32 KiB) | `synth_xilinx -family xc7` | {'RAMB36E1': 8} | {'CARRY4': 10, 'FDCE': 10, 'FDRE': 10, 'LUT2': 96, 'LUT3': 87, 'LUT4': 68, 'LUT5': 7, 'LUT6': 12} | PASS |
| xc7 sram_sp 128x2048 (32 KiB) | `synth_xilinx -family xc7` | {'RAMB36E1': 8} | {'CARRY4': 10, 'FDCE': 10, 'FDRE': 10, 'LUT2': 176, 'LUT3': 149, 'LUT4': 133, 'LUT5': 9, 'LUT6': 12} | PASS |
| xc7 sram_1r1w 32x512 | `synth_xilinx -family xc7` | {'RAMB18E1': 1} | {'CARRY4': 10, 'FDCE': 12, 'FDRE': 10, 'LUT2': 57, 'LUT3': 58, 'LUT4': 36, 'LUT5': 9, 'LUT6': 21} | PASS |
| xc7 sram_tdp 32x1024 | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | {'CARRY4': 20, 'FDCE': 21, 'FDRE': 86, 'LUT2': 106, 'LUT3': 131, 'LUT4': 72, 'LUT5': 16, 'LUT6': 42} | PASS |
| xc7 bank_controller 4x4 banks 32x2048 (32 KiB) | `synth_xilinx -family xc7` | {'RAMB36E1': 8} | {'CARRY4': 196, 'FDCE': 52, 'FDRE': 52, 'LUT1': 50, 'LUT2': 324, 'LUT3': 222, 'LUT4': 154, 'LUT5': 82, 'LUT6': 836} | PASS |
| xc7 sram_sp 32x131072 (512 KiB) | `synth_xilinx -family xc7` | {'RAMB36E1': 128} | {'CARRY4': 10, 'FDCE': 10, 'FDRE': 11, 'LUT2': 52, 'LUT3': 91, 'LUT4': 44, 'LUT5': 6, 'LUT6': 12} | PASS |
| xc7 selftest top (Arty A7-100T design) | `synth_xilinx -family xc7` | {'RAMB36E1': 4} | {'CARRY4': 54, 'FDCE': 123, 'FDPE': 10, 'FDRE': 49, 'LUT1': 41, 'LUT2': 168, 'LUT3': 132, 'LUT4': 79, 'LUT5': 109, 'LUT6': 244} | PASS |
| ice40 sram_sp 16x256 | `synth_ice40` | {'SB_RAM40_4K': 1} | {'SB_DFF': 3, 'SB_DFFE': 38, 'SB_DFFER': 2, 'SB_DFFR': 8, 'SB_LUT4': 115} | PASS |
| ice40 sram_1r1w 16x512 | `synth_ice40` | {'SB_RAM40_4K': 2} | {'SB_DFF': 1, 'SB_DFFE': 36, 'SB_DFFER': 3, 'SB_DFFR': 8, 'SB_LUT4': 131} | PASS |
| ecp5 sram_sp 32x1024 | `synth_ecp5` | {'DP16KD': 2} | {'LUT4': 198, 'TRELLIS_FF': 19} | PASS |
| ecp5 sram_tdp 18x1024 | `synth_ecp5` | {'DP16KD': 1} | {'LUT4': 306, 'TRELLIS_FF': 38} | PASS |

## ASIC macro integrity (black-box macros)

| configuration | macro | expected | found | glue cells | glue flip-flops | $mem cells | result |
|---|---|---|---|---|---|---|---|
| SKY130 sram_sp 32x4096 (16 KiB) | `sky130_sram_1kbyte_1rw1r_32x256_8` | 16 | 16 | 1361 | 87 | 0 (asserted) | PASS |
| SKY130 sram_1r1w 32x1024 | `sky130_sram_2kbyte_1rw1r_32x512_8` | 2 | 2 | 361 | 81 | 0 (asserted) | PASS |
| GF180 sram_sp 32x2048 (8 KiB) | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 16 | 16 | 401 | 85 | 0 (asserted) | PASS |
| IHP 1P sram_sp 128x2048 (32 KiB) | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | 8 | 8 | 1014 | 276 | 0 (asserted) | PASS |
| IHP 2P sram_tdp 32x1024 | `RM_IHPSG13_2P_1024x32_c2_bm_bist` | 1 | 1 | 569 | 166 | 0 (asserted) | PASS |
| SKY130 bank_controller 4 banks x 32x1024 | `sky130_sram_1kbyte_1rw1r_32x256_8` | 16 | 16 | 3846 | 393 | 0 (asserted) | PASS |
| SilicaFlux-V example subsystem on IHP 1P macros | `RM_IHPSG13_1P_1024x32_c2_bm_bist, RM_IHPSG13_1P_2048x32_c2_bm_bist, RM_IHPSG13_1P_512x64_c2_bm_bist` | 11 | 11 | 12375 | 1199 | 0 (asserted) | PASS |
