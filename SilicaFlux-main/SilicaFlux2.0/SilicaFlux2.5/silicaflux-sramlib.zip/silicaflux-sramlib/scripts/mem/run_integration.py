#!/usr/bin/env python3
"""SilicaFlux 2.5 integration check: memory_controller.sf with library banks.

Runs MemoryFlow's characterisation testbench for the EXISTING SilicaFlux 2.5
scratchpad controller (tb/silicaflux/tb_sf25_memctrl.sv inside the repository's
silicaflux-memoryflow-v2.0.0.zip) on
  1. the unmodified repository memory_controller.sf            (baseline)
  2. integration/silicaflux25/memory_controller_sramlib.sf, GENERIC backend
  3. the same, FPGA backend (block-RAM inference template)
with SRAMLIB_POISON on (library backends drive X / random data whenever the
array output is not a valid read slot), so a controller that relied on the
SRAM holding its output would fail.  The only testbench change is the one
hierarchical path used by its parity-corruption phase (recorded in the report).
The check passes when every run passes and the patched runs reproduce the
baseline's functional metrics (check count, response counts, throughput).

Usage: run_integration.py --silicaflux <path to SilicaFlux-main>
Results: reports/mem/integration.{json,md}
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, RTL, RTL_FILES, STUBS, provenance, run, write_json  # noqa: E402

MF_ZIP = "SilicaFlux2.0/SilicaFlux2.5/silicaflux-memoryflow-v2.0.0.zip"
OLD_PATH = "dut.g_bank[5].mem_q[128][37]"
NEW_PATH = "dut.g_bank[5].u_sram.g_generic.u_mem.mem[128][37]"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    # default: the library unpacked at SilicaFlux-main/silicaflux-sramlib/
    dflt = ROOT.parent if (ROOT.parent / "memory_controller.sf").exists() else ROOT.parent / "SilicaFlux-main"
    ap.add_argument("--silicaflux", type=Path, default=dflt)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    sf = a.silicaflux
    pkg = sf / "silicaflux_pkg (1).sf"
    orig = sf / "memory_controller.sf"
    zipf = sf / MF_ZIP
    for f in (pkg, orig, zipf):
        if not f.exists():
            print(f"missing repository file: {f}")
            return 2
    work = BUILD / "integration"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    with zipfile.ZipFile(zipf) as z:          # data only: extracted, never executed
        z.extractall(work / "mf")
    mf = work / "mf/silicaflux-memoryflow"
    tb = mf / "tb/silicaflux/tb_sf25_memctrl.sv"
    shutil.copy(pkg, work / "silicaflux_pkg.sv")
    shutil.copy(orig, work / "memory_controller_orig.sv")
    shutil.copy(ROOT / "integration/silicaflux25/memory_controller_sramlib.sf", work / "memory_controller_sramlib.sv")
    tbtxt = tb.read_text()
    if tbtxt.count(OLD_PATH) != 2:          # read and write of the same bit on one line
        print("testbench hierarchical path not found as expected")
        return 2
    (work / "tb_patched.sv").write_text(tbtxt.replace(OLD_PATH, NEW_PATH))

    base = ["verilator", "--binary", "--timing", "--assert", "-j", "1", "-Wno-fatal", "-Wno-lint", "-Wno-style",
            f"+incdir+{mf / 'tb/common'}", f"+incdir+{RTL}", f"+incdir+{RTL / 'backends/asic'}",
            "--top-module", "tb_sf25_memctrl", "-o", "Vtb"]
    # FPGA variant: same patched source, default SRAM_BACKEND changed to 1 (the TB instantiates with defaults)
    ptxt = (work / "memory_controller_sramlib.sv").read_text()
    anchor = "parameter int          SRAM_BACKEND      = 0,"
    if ptxt.count(anchor) != 1:
        print("SRAM_BACKEND parameter anchor not found")
        return 2
    (work / "memory_controller_sramlib_fpga.sv").write_text(ptxt.replace(anchor, anchor.replace("= 0,", "= 1,")))
    (work / "tb_fpga.sv").write_text(tbtxt.replace(OLD_PATH, NEW_PATH.replace("g_generic", "g_fpga")))
    lib = ["-DSRAMLIB_POISON", "--x-assign", "unique", "--x-initial", "unique"]
    runs = [
        ("baseline: repository memory_controller.sf", [work / "silicaflux_pkg.sv", work / "memory_controller_orig.sv", tb], []),
        ("library banks, GENERIC backend", [work / "silicaflux_pkg.sv", *RTL_FILES, *STUBS, work / "memory_controller_sramlib.sv",
                                            work / "tb_patched.sv"], lib),
        ("library banks, FPGA backend", [work / "silicaflux_pkg.sv", *RTL_FILES, *STUBS, work / "memory_controller_sramlib_fpga.sv",
                                         work / "tb_fpga.sv"], lib),
    ]
    recs = []
    for name, files, extra in runs:
        mdir = work / re.sub(r"\W+", "_", name)
        mdir.mkdir()
        cmd = base + ["--Mdir", str(mdir)] + extra + [str(f) for f in files]
        b = run(cmd, cwd=mdir, timeout=3600)
        rec = {"name": name, "build_cmd": b["cmd"], "build_rc": b["rc"]}
        if b["rc"] != 0:
            rec.update({"result": "FAIL", "log": b["out"][-2500:]})
            recs.append(rec)
            continue
        r = run([str(mdir / "Vtb"), f"+verilator+seed+{a.seed}", f"+seed={a.seed}"], cwd=mdir, timeout=3600)
        m = re.search(r"MF_RESULT (PASS|FAIL) errors=(\d+) checks=(\d+)", r["out"])
        metrics = dict(re.findall(r"MF_METRIC (\S+)=(\S+)", r["out"]))
        rec.update({"run_cmd": r["cmd"], "run_rc": r["rc"], "mf_result": m.group(1) if m else "NO RESULT",
                    "errors": int(m.group(2)) if m else None, "checks": int(m.group(3)) if m else 0, "metrics": metrics,
                    "result": "PASS" if m and m.group(1) == "PASS" and r["rc"] == 0 else "FAIL"})
        if rec["result"] != "PASS":
            rec["log"] = r["out"][-2500:]
        recs.append(rec)
        print(f"[integration] {rec['result']} {name}: checks={rec['checks']}", flush=True)
    # metric equivalence against the baseline
    base_m = recs[0].get("metrics", {})
    for rec in recs[1:]:
        diff = {k: (v, rec.get("metrics", {}).get(k)) for k, v in base_m.items() if rec.get("metrics", {}).get(k) != v}
        rec["metric_differences_vs_baseline"] = diff
        rec["checks_equal_baseline"] = rec.get("checks") == recs[0].get("checks")
        if diff or not rec["checks_equal_baseline"]:
            rec["result"] = "FAIL"
    res = {"provenance": provenance({"silicaflux_source": str(sf), "testbench": f"{MF_ZIP}::silicaflux-memoryflow/tb/silicaflux/tb_sf25_memctrl.sv",
                                     "testbench_change": f"'{OLD_PATH}' -> '{NEW_PATH}' (GENERIC run) / g_fpga (FPGA run)"}),
           "records": recs}
    write_json(REPORTS / "integration.json", res)
    L = ["# SilicaFlux 2.5 integration: memory_controller.sf on library SRAM banks", "",
         "Testbench: MemoryFlow `tb_sf25_memctrl.sv` (from the repository's `" + MF_ZIP + "`), the existing",
         "characterisation bench for the unmodified 2.5 scratchpad controller (8 banks x 512 x 128 b, parity,",
         "scalar + vector + burst ports, random backpressure, burst kill, parity-error injection).", "",
         "| run | MF result | checks | equal to baseline | metric differences | result |", "|---|---|---|---|---|---|"]
    for r in recs:
        L.append(f"| {r['name']} | {r.get('mf_result', '-')} | {r.get('checks', '-')} | {r.get('checks_equal_baseline', 'baseline')} | "
                 f"{len(r.get('metric_differences_vs_baseline', {})) if 'metric_differences_vs_baseline' in r else '-'} | {r['result']} |")
    if base_m:
        L += ["", "Baseline metrics (identical in every passing run):", ""] + [f"* `{k}` = {v}" for k, v in sorted(base_m.items())]
    (REPORTS / "integration.md").write_text("\n".join(L) + "\n")
    return 0 if all(r["result"] == "PASS" for r in recs) else 1


if __name__ == "__main__":
    sys.exit(main())
