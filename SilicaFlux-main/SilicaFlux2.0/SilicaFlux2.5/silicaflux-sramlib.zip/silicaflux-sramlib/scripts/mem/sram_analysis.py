#!/usr/bin/env python3
"""SRAM configuration, capacity and benchmark analysis for the SilicaFlux SRAM library.

  plan      tiling plan for one configuration on one macro (same arithmetic as
            rtl/mem/backends/asic/sram_asic_array.sv), or the reason it is rejected:
              sram_analysis.py plan --width 32 --depth 4096 --macro SKY130_1RW1R_32X256 --ports 1RW
  capacity  aggregate capacities (32..512 KiB) x word widths x bank counts x open
            macro families: macro count and MACRO-ONLY area from the manifests
            (published LEF / datasheet dimensions), bit utilisation, and the
            macro-limited clock where the manifest has a characterised minimum
            cycle time.  Commercial nodes: no data (pending manifests).
  bench     runs the self-checking banking testbench (Verilator) for the CPU,
            vector, tensor, DMA and mixed workloads over 1/2/4/8 banks and
            collects sustained words/cycle, conflict rate, latency and a
            switching-activity proxy (bank-input Hamming distance per access).
  all       capacity + bench, written to reports/mem/analysis.{json,md}

Every number carries its source.  Nothing here is a silicon, FPGA-board or
signed-off physical result: macro area excludes halos, power rings, routing
channels and the standard-cell glue; workloads are synthetic traffic models.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, provenance, run, write_json  # noqa: E402

TOPO_OK = {"1RW": {"1RW", "1RW1R", "2RW"}, "1R1W": {"1RW1R", "2RW"}, "2RW": {"2RW"}}


def manifests() -> list[dict]:
    return [json.loads(p.read_text()) for p in sorted((ROOT / "manifests").glob("*.json"))]


def find_macro(name: str) -> dict:
    for m in manifests():
        if name in (m["define"], m["define"].replace("SRAM_MACRO_", ""), m["macro_name"], str(m["id"])):
            return m
    raise SystemExit(f"unknown macro {name}")


def plan(width: int, depth: int, mask_width: int, m: dict, ports: str) -> dict:
    if m["status"] != "OPEN_SOURCE_AVAILABLE":
        return {"ok": False, "reason": f"{m['define']}: {m['status']} (no macro data)"}
    if m["port_topology"] not in TOPO_OK[ports]:
        return {"ok": False, "reason": f"{m['macro_name']} is {m['port_topology']}, cannot provide {ports}"}
    lw = width // mask_width
    g = m["write_mask"]["granularity_bits"]
    if width % mask_width:
        return {"ok": False, "reason": "MASK_WIDTH must divide DATA_WIDTH"}
    if g > 1 and mask_width != 1 and lw % g:
        return {"ok": False, "reason": f"lane width {lw} is not a multiple of the macro mask granularity {g}"}
    nc = math.ceil(width / m["data_width"])
    nr = math.ceil(depth / m["words"])
    n = nc * nr
    area = n * m["physical"]["area_um2"]
    return {"ok": True, "macro": m["macro_name"], "columns": nc, "rows": nr, "instances": n,
            "bit_utilisation": round(width * depth / (n * m["data_width"] * m["words"]), 4),
            "macro_area_mm2": round(area / 1e6, 4), "area_source": m["physical"]["source"],
            "native_latency": m["read_latency_cycles"]}


def min_cycle_ns(m: dict) -> float | None:
    t = m.get("timing", {})
    return t.get("min_clock_period_ns")


def capacity() -> dict:
    ms = [m for m in manifests() if m["status"] == "OPEN_SOURCE_AVAILABLE"]
    fams = sorted({m["family"] for m in ms})
    rows = []
    for kib in (32, 64, 128, 256, 512):
        for width in (32, 64, 128):
            for banks in (1, 2, 4, 8):
                words = kib * 1024 * 8 // width
                if words % banks:
                    continue
                bank_depth = words // banks
                for fam in fams:
                    best = None
                    for m in (x for x in ms if x["family"] == fam):
                        p = plan(width, bank_depth, max(1, width // 8), m, "1RW")
                        if p["ok"]:
                            p["macro_area_mm2"] = round(p["macro_area_mm2"] * banks, 4)
                            p["instances"] *= banks
                            if best is None or p["macro_area_mm2"] < best["macro_area_mm2"]:
                                best = p | {"min_cycle_ns": min_cycle_ns(m)}
                    if best:
                        rows.append({"capacity_kib": kib, "word_bits": width, "banks": banks, "family": fam,
                                     "bank_depth": bank_depth, **best,
                                     "peak_bytes_per_cycle": banks * width // 8})
    pend = [m for m in manifests() if m["status"] != "OPEN_SOURCE_AVAILABLE"]
    return {"rows": rows, "presets": presets(), "pending": [{"define": m["define"], "process": m["process"], "status": m["status"]} for m in pend]}


PRESETS = [  # rtl/mem/sram_presets.svh - illustrative, not confirmed SilicaFlux specifications
    ("small control SRAM", 32, 1024), ("CPU SRAM bank", 32, 4096),
    ("vector scratchpad", 64, 4096), ("tensor scratchpad", 128, 2048),
]


def presets() -> list[dict]:
    ms = [m for m in manifests() if m["status"] == "OPEN_SOURCE_AVAILABLE"]
    out = []
    for name, w, d in PRESETS:
        for fam in sorted({m["family"] for m in ms}):
            best = None
            for m in (x for x in ms if x["family"] == fam):
                p = plan(w, d, w // 8, m, "1RW")
                if p["ok"] and (best is None or p["macro_area_mm2"] < best["macro_area_mm2"]):
                    best = p
            if best:
                out.append({"preset": name, "word_bits": w, "words": d, "kib": w * d // 8192, "family": fam, **best})
    return out


BENCH_CFGS = [
    {"NM": 4, "NB": nb, "DW": 32, "MW": 4, "BD": 4096 // nb, "LAT": 1} for nb in (1, 2, 4, 8)
] + [
    {"NM": 4, "NB": nb, "DW": 128, "MW": 16, "BD": 1024 // nb, "LAT": 2} for nb in (1, 2, 4, 8)
]
WORKLOADS = {1: "cpu", 2: "vector", 3: "tensor", 4: "dma", 5: "mixed", 6: "stride_nb"}


def bench(seed: int, ncyc: int) -> list[dict]:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from run_regress import vl_build  # noqa: E402
    out = []
    for cfg in BENCH_CFGS:
        exe, b = vl_build("tb_sram_banking", cfg)
        if b["rc"] != 0:
            out.append({"config": cfg, "error": b["out"][-800:]})
            continue
        for wl, name in WORKLOADS.items():
            r = run([str(exe), f"+seed={seed}", f"+wl={wl}", f"+ncyc={ncyc}"], cwd=exe.parent, timeout=3600)
            m = re.search(r"SRAM_METRIC wl=\S+ .*", r["out"])
            res = re.search(r"SRAM_RESULT (PASS|FAIL).*checks=(\d+)", r["out"])
            kv = dict(re.findall(r"(\w+)=([\d.]+)", m.group(0))) if m else {}
            out.append({"config": cfg, "workload": name, "seed": seed, "cycles": ncyc, "cmd": r["cmd"],
                        "tb_result": res.group(1) if res else "NO RESULT", "checks": int(res.group(2)) if res else 0,
                        "words_per_cycle": float(kv.get("words_per_cycle", 0)),
                        "bytes_per_cycle": round(float(kv.get("words_per_cycle", 0)) * cfg["DW"] / 8, 3),
                        "peak_bytes_per_cycle": cfg["NB"] * cfg["DW"] / 8 if cfg["NB"] <= cfg["NM"] else cfg["NM"] * cfg["DW"] / 8,
                        "conflict_rate": float(kv.get("conflict_rate", 0)), "avg_latency": float(kv.get("avg_latency", 0)),
                        "max_latency": int(float(kv.get("max_latency", 0))),
                        "toggles_per_access": float(kv.get("toggles_per_access", 0))})
            print(f"[bench] NB={cfg['NB']} DW={cfg['DW']} {name:9} {out[-1]['words_per_cycle']:.3f} w/c "
                  f"conflicts {out[-1]['conflict_rate']:.3f} {out[-1]['tb_result']}", flush=True)
    return out


def write_report(cap: dict | None, bn: list[dict] | None) -> None:
    res = {"provenance": provenance(), "capacity": cap, "bench": bn}
    write_json(REPORTS / "analysis.json", res)
    L = ["# SRAM capacity, area and bandwidth analysis", "",
         "All area figures are MACRO-ONLY sums of published macro dimensions (manifest `physical.source`: LEF SIZE for",
         "SKY130, spec CSV for GF180MCU, datasheet for IHP SG13G2).  They exclude placement halos, power rings, routing",
         "channels, the standard-cell glue and any ECC/redundancy.  No silicon, FPGA board or sign-off data exists.", ""]
    if cap:
        L += ["## Capacity vs open-PDK macros (single-port, best macro per family, byte lanes)", "",
              "| capacity | word | banks | family | best macro | instances | utilisation | macro area mm2 | macro-limited clock | peak B/cycle |",
              "|---|---|---|---|---|---|---|---|---|---|"]
        for r in cap["rows"]:
            if r["banks"] not in (1, 4) or r["word_bits"] == 64:
                continue
            clk = f"{1000 / r['min_cycle_ns']:.0f} MHz (GF180 spec, 3.3 V typ)" if r.get("min_cycle_ns") else "not characterised in manifest"
            L.append(f"| {r['capacity_kib']} KiB | {r['word_bits']} | {r['banks']} | {r['family']} | `{r['macro']}` | {r['instances']} | "
                     f"{r['bit_utilisation']:.2f} | {r['macro_area_mm2']:.2f} | {clk} | {r['peak_bytes_per_cycle']} |")
        L += ["", "Full table (all widths and 1/2/4/8 banks): `reports/mem/analysis.json`.", "",
              "## SilicaFlux-V illustrative presets on open-PDK macros (best macro per family)", "",
              "| preset | organisation | family | macro | tiling (cols x rows) | instances | macro area mm2 |",
              "|---|---|---|---|---|---|---|"]
        for r in cap.get("presets", []):
            L.append(f"| {r['preset']} | {r['word_bits']} b x {r['words']} ({r['kib']} KiB) | {r['family']} | `{r['macro']}` | "
                     f"{r['columns']} x {r['rows']} | {r['instances']} | {r['macro_area_mm2']:.3f} |")
        L += ["",
              "Commercial 130 / 65 / 28 nm: " + "; ".join(f"`{p['define']}` {p['status']}" for p in cap["pending"]) +
              " - no area or timing can be stated until a licensed memory compiler's outputs are obtained.", ""]
    if bn:
        L += ["## Simulated workloads on sram_bank_controller (4 masters, self-checking testbench)", "",
              "| word | banks | workload | words/cycle | bytes/cycle | conflict rate | avg latency | max latency | toggles/access | TB |",
              "|---|---|---|---|---|---|---|---|---|---|"]
        for r in bn:
            if "error" in r:
                continue
            c = r["config"]
            L.append(f"| {c['DW']} | {c['NB']} | {r['workload']} | {r['words_per_cycle']:.3f} | {r['bytes_per_cycle']} | "
                     f"{r['conflict_rate']:.3f} | {r['avg_latency']:.2f} | {r['max_latency']} | {r['toggles_per_access']:.1f} | {r['tb_result']} |")
        L += ["", "Peak per-cycle bandwidth = min(masters, banks) x word.  Latency in cycles from acceptance; the",
              "configured READ_LATENCY is the floor (1 for 32-bit rows, 2 for 128-bit rows).  toggles/access is the",
              "Hamming distance between consecutive bank input words (row + write data): an activity proxy, not power.",
              f"Seed and cycle counts are in analysis.json; cycles per run: {bn[0]['cycles'] if bn else '-'}."]
    (REPORTS / "analysis.md").write_text("\n".join(L) + "\n")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan")
    p.add_argument("--width", type=int, required=True)
    p.add_argument("--depth", type=int, required=True)
    p.add_argument("--mask-width", type=int, default=0)
    p.add_argument("--macro", required=True)
    p.add_argument("--ports", default="1RW", choices=list(TOPO_OK))
    sub.add_parser("capacity")
    b = sub.add_parser("bench")
    b.add_argument("--seed", type=int, default=20261105)
    b.add_argument("--ncyc", type=int, default=4000)
    al = sub.add_parser("all")
    al.add_argument("--seed", type=int, default=20261105)
    al.add_argument("--ncyc", type=int, default=4000)
    a = ap.parse_args()
    if a.cmd == "plan":
        mw = a.mask_width or (a.width // 8 if a.width % 8 == 0 else 1)
        r = plan(a.width, a.depth, mw, find_macro(a.macro), a.ports)
        print(json.dumps(r, indent=2))
        return 0 if r["ok"] else 1
    if a.cmd == "capacity":
        write_report(capacity(), None)
    elif a.cmd == "bench":
        write_report(None, bench(a.seed, a.ncyc))
    else:
        write_report(capacity(), bench(a.seed, a.ncyc))
    print((REPORTS / "analysis.md").read_text()[:3000])
    return 0


if __name__ == "__main__":
    sys.exit(main())
