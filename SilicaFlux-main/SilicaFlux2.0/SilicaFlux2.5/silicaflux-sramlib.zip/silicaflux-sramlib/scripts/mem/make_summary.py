#!/usr/bin/env python3
"""Aggregate reports/mem/*.json into reports/mem/SUMMARY.md (status per check, provenance)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, provenance  # noqa: E402


def load(name: str) -> dict | None:
    p = REPORTS / name
    return json.loads(p.read_text()) if p.exists() else None


def count(recs: list[dict], key: str = "result") -> str:
    c = {"PASS": 0, "FAIL": 0, "SKIP": 0}
    for r in recs:
        c[r.get(key, "FAIL")] = c.get(r.get(key, "FAIL"), 0) + 1
    return f"{c['PASS']} pass / {c['FAIL']} fail" + (f" / {c['SKIP']} skip" if c["SKIP"] else "")


def main() -> int:
    prov = provenance()
    L = ["# SilicaFlux SRAM Wrapper Library - verification summary", "",
         f"Generated {prov['generated_utc']}.  Design sha256 `{prov['design_sha256']}`; library tree sha256 `{prov['library_tree_sha256']}`.  "
         f"Enclosing git: `{prov['git'].get('commit')}` (library files committed: {prov['git'].get('library_files_committed')})."
         + (f"  SilicaFlux reference checkout: `{prov['git']['reference_repo']['commit']}` (clean: {prov['git']['reference_repo']['clean']})."
            if prov['git'].get('reference_repo') else ""), "",
         "| check | source report | result |", "|---|---|---|"]
    ok = True
    stale = []
    for f in sorted(REPORTS.glob("*.json")):
        d = json.loads(f.read_text()).get("provenance", {})
        if d.get("design_sha256") and d["design_sha256"] != prov["design_sha256"]:
            stale.append(f.name)
    if stale:
        L.insert(3, f"**Stale reports (produced from a different design tree): {', '.join(stale)}**\n")
        ok = False
    reg = load("regression.json")
    if not reg:   # individual make targets write lint.json / test.json / equiv.json instead
        parts = [load(n) for n in ("lint.json", "test.json", "equiv.json")]
        if any(parts):
            reg = {"records": [r for p in parts if p for r in p["records"]]}
    if reg:
        for suite in ("lint", "sim", "xsim", "equiv", "mutants"):
            rs = [r for r in reg["records"] if r["suite"] == suite]
            if rs:
                L.append(f"| {suite} | regression.md | {count(rs)} |")
                ok &= all(r["result"] != "FAIL" for r in rs)
        checks = sum(r.get("checks", 0) or 0 for r in reg["records"] if r["suite"] == "sim")
        L.append(f"| scoreboard checks in the sim suite | regression.json | {checks:,} |")
    for name, label, key in (("cocotb.json", "cocotb (Icarus)", "records"), ("formal.json", "formal (BMC + cover)", "jobs"),
                             ("synth.json", "synthesis (generic / FPGA / ASIC)", "records"),
                             ("integration.json", "SilicaFlux 2.5 integration", "records")):
        d = load(name)
        if d:
            rs = d[key]
            L.append(f"| {label} | {name.replace('.json', '.md')} | {count(rs)} |")
            ok &= all(r.get("result") != "FAIL" for r in rs)
        else:
            L.append(f"| {label} | - | not run |")
    an = load("analysis.json")
    if an:
        b = an.get("bench") or []
        L.append(f"| workload benchmarks (self-checking) | analysis.md | {sum(1 for r in b if r.get('tb_result') == 'PASS')} of {len(b)} runs PASS |")
    L += ["", "## Tools", "", "| tool | version |", "|---|---|"] + [f"| {k} | {v} |" for k, v in prov["tools"].items()]
    L += ["", "Blocked / not available in the environment that produced these reports: "
          + ", ".join(k for k, v in prov["tools"].items() if v == "NOT INSTALLED") + ".",
          "", "Every number above comes from the JSON reports in this directory; each JSON embeds the commands, exit codes,",
          "seeds and tool versions of the run that produced it."]
    (REPORTS / "SUMMARY.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
