#!/usr/bin/env python3
"""Yosys synthesis checks for the SRAM library.

  generic  `synth` (technology-independent gates) of every public module:
           elaboration, inferred memories (width x depth, read/write ports,
           from `memory -nomap` before mapping), flip-flop / cell counts,
           latch check (must be zero), warning count.
  fpga     block-RAM inference with Yosys' vendor flows (synth_xilinx xc7,
           synth_ice40, synth_ecp5): RAM primitive counts must be > 0 and no
           memory may fall back to flip-flops (checked via $mem cells absent
           and RAM primitives present).  This is inference evidence only: no
           vendor tool (Vivado/Quartus/Radiant) and no board was available.
  asic     BACKEND=ASIC with the pin-only macro black boxes: the exact
           expected number of real macro instances must survive synthesis,
           and no $mem cell (i.e. no flip-flop array) may exist.  A passing
           generic synthesis is NOT evidence of macro integration; this check
           is the macro-integrity gate.  Physical views (LEF/GDS) are not used.
Results: reports/mem/synth.{json,md}.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, RTL, RTL_FILES, STUBS, provenance, run, write_json  # noqa: E402

FPGA_TOP = [ROOT / "rtl/mem/fpga/sram_fpga_selftest_top.sv", ROOT / "rtl/mem/fpga/sram_uart_tx.sv",
            ROOT / "rtl/mem/examples/sfv_memory_subsystem_example.sv"]

GENERIC = [
    ("sram_sp 32x1024 lat1", "sram_sp", {"DATA_WIDTH": 32, "DEPTH": 1024}),
    ("sram_sp 128x100 lat3 fifo0", "sram_sp", {"DATA_WIDTH": 128, "DEPTH": 100, "READ_LATENCY": 3, "RSP_FIFO_DEPTH": 0}),
    ("sram_1r1w 32x512 STALL", "sram_1r1w", {"DATA_WIDTH": 32, "DEPTH": 512}),
    ("sram_tdp 32x256 STALL", "sram_tdp", {"DATA_WIDTH": 32, "DEPTH": 256}),
    ("sram_bank_controller 4m x 4b x 32x256", "sram_bank_controller", {"NUM_MASTERS": 4, "NUM_BANKS": 4, "BANK_DEPTH": 256}),
    ("sram_bank_controller 8m x 8b x 64x64 byte-addr", "sram_bank_controller",
     {"NUM_MASTERS": 8, "NUM_BANKS": 8, "DATA_WIDTH": 64, "BANK_DEPTH": 64, "ADDR_MODE": 1}),
    ("sram_rsp_path 128b lat2 fifo3", "sram_rsp_path", {"DATA_WIDTH": 128, "LATENCY": 2, "FIFO_DEPTH": 3}),
    ("sram_mbist_march 6 targets", "sram_mbist_march", {"NUM_TARGETS": 6, "DW": 32, "AW": 12}),
    ("sram_mbist_adapter", "sram_mbist_adapter", {}),
]

FPGA = [
    # name, top, params, flow, primitive regex
    ("xc7 sram_sp 32x1024 (4 KiB)", "sram_sp", {"BACKEND": 1, "DATA_WIDTH": 32, "DEPTH": 1024}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 sram_sp 32x1024 lat2 (output reg)", "sram_sp", {"BACKEND": 1, "DATA_WIDTH": 32, "DEPTH": 1024, "READ_LATENCY": 2}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 sram_sp 64x4096 (32 KiB)", "sram_sp", {"BACKEND": 1, "DATA_WIDTH": 64, "DEPTH": 4096}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 sram_sp 128x2048 (32 KiB)", "sram_sp", {"BACKEND": 1, "DATA_WIDTH": 128, "DEPTH": 2048}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 sram_1r1w 32x512", "sram_1r1w", {"BACKEND": 1, "DATA_WIDTH": 32, "DEPTH": 512}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 sram_tdp 32x1024", "sram_tdp", {"BACKEND": 1, "DATA_WIDTH": 32, "DEPTH": 1024}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 bank_controller 4x4 banks 32x2048 (32 KiB)", "sram_bank_controller",
     {"BACKEND": 1, "NUM_MASTERS": 4, "NUM_BANKS": 4, "BANK_DEPTH": 2048}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 sram_sp 32x131072 (512 KiB)", "sram_sp", {"BACKEND": 1, "DATA_WIDTH": 32, "DEPTH": 131072}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("xc7 selftest top (Arty A7-100T design)", "sram_fpga_selftest_top", {}, "synth_xilinx -family xc7", r"RAMB(18|36)E1"),
    ("ice40 sram_sp 16x256", "sram_sp", {"BACKEND": 1, "DATA_WIDTH": 16, "DEPTH": 256}, "synth_ice40", r"SB_RAM40_4K"),
    ("ice40 sram_1r1w 16x512", "sram_1r1w", {"BACKEND": 1, "DATA_WIDTH": 16, "DEPTH": 512}, "synth_ice40", r"SB_RAM40_4K"),
    ("ecp5 sram_sp 32x1024", "sram_sp", {"BACKEND": 1, "DATA_WIDTH": 32, "DEPTH": 1024}, "synth_ecp5", r"DP16KD|PDPW16KD"),
    ("ecp5 sram_tdp 18x1024", "sram_tdp", {"BACKEND": 1, "DATA_WIDTH": 16, "DEPTH": 1024, "MASK_WIDTH": 2}, "synth_ecp5", r"DP16KD"),
]

ASIC = [
    # name, top, params, macro module, expected instances
    ("SKY130 sram_sp 32x4096 (16 KiB)", "sram_sp", {"BACKEND": 2, "MACRO": 1, "DATA_WIDTH": 32, "DEPTH": 4096},
     "sky130_sram_1kbyte_1rw1r_32x256_8", 16),
    ("SKY130 sram_1r1w 32x1024", "sram_1r1w", {"BACKEND": 2, "MACRO": 2, "DATA_WIDTH": 32, "DEPTH": 1024},
     "sky130_sram_2kbyte_1rw1r_32x512_8", 2),
    ("GF180 sram_sp 32x2048 (8 KiB)", "sram_sp", {"BACKEND": 2, "MACRO": 13, "DATA_WIDTH": 32, "DEPTH": 2048},
     "gf180mcu_fd_ip_sram__sram512x8m8wm1", 16),
    ("IHP 1P sram_sp 128x2048 (32 KiB)", "sram_sp", {"BACKEND": 2, "MACRO": 21, "DATA_WIDTH": 128, "DEPTH": 2048, "MASK_WIDTH": 16},
     "RM_IHPSG13_1P_1024x32_c2_bm_bist", 8),
    ("IHP 2P sram_tdp 32x1024", "sram_tdp", {"BACKEND": 2, "MACRO": 61, "DATA_WIDTH": 32, "DEPTH": 1024},
     "RM_IHPSG13_2P_1024x32_c2_bm_bist", 1),
    ("SKY130 bank_controller 4 banks x 32x1024", "sram_bank_controller",
     {"BACKEND": 2, "MACRO": 1, "NUM_MASTERS": 4, "NUM_BANKS": 4, "BANK_DEPTH": 1024}, "sky130_sram_1kbyte_1rw1r_32x256_8", 16),
    ("SilicaFlux-V example subsystem on IHP 1P macros", "sfv_memory_subsystem_example",
     {"BACKEND": 2, "MACRO_CTRL": 21, "MACRO_CPU": 24, "MACRO_SPM": 35},
     {"RM_IHPSG13_1P_1024x32_c2_bm_bist": 1, "RM_IHPSG13_1P_2048x32_c2_bm_bist": 2, "RM_IHPSG13_1P_512x64_c2_bm_bist": 8}, None),
]


def reads(extra: list[Path] | None = None) -> str:
    files = RTL_FILES + FPGA_TOP + (extra or [])
    # -defer: elaborate only the requested parameterisation (several modules, e.g. sram_asic_array,
    # deliberately $fatal with their default parameters)
    return f"read_verilog -defer -sv -DSYNTHESIS -I{RTL} -I{RTL / 'backends/asic'} " + " ".join(str(f) for f in files)


def chparam(top: str, p: dict) -> str:
    return f"hierarchy -top {top} " + " ".join(f"-chparam {k} {v}" for k, v in p.items()) + "; "


def cell_counts(log: str) -> dict[str, int]:
    """Cell-type counts from the LAST `stat` block in a Yosys log."""
    blocks = log.split("Number of cells:")
    if len(blocks) < 2:
        return {}
    last = blocks[-1]
    out = {"_total": int(re.match(r"\s*(\d+)", last).group(1))}
    for m in re.finditer(r"^\s+(\S+)\s+(\d+)\s*$", last, re.M):
        out[m.group(1)] = int(m.group(2))
    return out


def mem_inventory(json_path: Path) -> list[dict]:
    d = json.loads(json_path.read_text())
    mems = []
    for mname, m in d.get("modules", {}).items():
        for cname, c in m.get("cells", {}).items():
            if c["type"] in ("$mem", "$mem_v2"):
                p = c["parameters"]
                val = lambda k: int(p[k], 2) if isinstance(p.get(k), str) else int(p.get(k, 0))
                mems.append({"module": mname, "cell": cname.split("$")[-1] if cname.startswith("$") else cname,
                             "width": val("WIDTH"), "depth": val("SIZE"), "rd_ports": val("RD_PORTS"),
                             "wr_ports": val("WR_PORTS")})
    return mems


def job_generic(name: str, top: str, p: dict) -> dict:
    d = BUILD / "synth" / re.sub(r"\W+", "_", name)
    d.mkdir(parents=True, exist_ok=True)
    ys = (f"{reads()}; {chparam(top, p)}proc; flatten; opt_clean; "
          f"select -assert-none t:$dlatch t:$adlatch; memory -nomap; opt_clean; write_json {d}/mem.json; stat; "
          f"synth -top {top} -flatten; select -assert-none t:$_DLATCH*; stat")
    r = run(["yosys", "-p", ys], cwd=d, timeout=5400)
    ok = r["rc"] == 0
    cc = cell_counts(r["out"])
    flops = sum(v for k, v in cc.items() if k.startswith("$_DFF") or k.startswith("$_SDFF") or k.startswith("$_DFFE"))
    return {"suite": "generic", "name": name, "top": top, "params": p, "cmd": "yosys -p '" + ys + "'", "rc": r["rc"],
            "memories": mem_inventory(d / "mem.json") if (d / "mem.json").exists() else [],
            "cells_total": cc.get("_total"), "flip_flops": flops, "latches": 0 if ok else None,
            "warnings": len(re.findall(r"^Warning:", r["out"], re.M)),
            "result": "PASS" if ok else "FAIL", "log_tail": "" if ok else r["out"][-2500:]}


def job_fpga(name: str, top: str, p: dict, flow: str, prim: str) -> dict:
    d = BUILD / "synth" / re.sub(r"\W+", "_", name)
    d.mkdir(parents=True, exist_ok=True)
    ys = f"{reads()}; {chparam(top, p)}{flow} -top {top}; select -assert-none t:$mem t:$mem_v2; stat"
    r = run(["yosys", "-p", ys], cwd=d, timeout=5400)
    cc = cell_counts(r["out"])
    prims = {k: v for k, v in cc.items() if re.fullmatch(prim, k)}
    lut_ff = {k: v for k, v in cc.items() if re.match(r"(LUT\d|SB_LUT4|LUT4|TRELLIS_FF|FD|SB_DFF|CARRY)", k)}
    ok = r["rc"] == 0 and sum(prims.values()) > 0
    return {"suite": "fpga", "name": name, "top": top, "params": p, "flow": flow, "cmd": "yosys -p '" + ys + "'", "rc": r["rc"],
            "ram_primitives": prims, "other_cells": lut_ff, "cells_total": cc.get("_total"),
            "warnings": len(re.findall(r"^Warning:", r["out"], re.M)),
            "result": "PASS" if ok else "FAIL", "log_tail": "" if ok else r["out"][-2500:]}


def job_asic(name: str, top: str, p: dict, macro, n) -> dict:
    """macro/n: one macro name and its expected count, or a {macro: count} dict (n unused)."""
    exp = macro if isinstance(macro, dict) else {macro: n}
    d = BUILD / "synth" / re.sub(r"\W+", "_", name)
    d.mkdir(parents=True, exist_ok=True)
    checks = "".join(f"select -assert-count {c} t:{m}; " for m, c in exp.items())
    ys = (f"{reads(STUBS)}; {chparam(top, p)}synth -top {top} -flatten; {checks}"
          f"select -assert-none t:$mem t:$mem_v2; select -assert-none t:$_DLATCH*; stat")
    r = run(["yosys", "-p", ys], cwd=d, timeout=5400)
    cc = cell_counts(r["out"])
    flops = sum(v for k, v in cc.items() if "DFF" in k)
    found = {m: cc.get(m) for m in exp}
    nmac = sum(v or 0 for v in found.values())
    return {"suite": "asic", "name": name, "top": top, "params": p, "macro": ", ".join(exp),
            "expected_instances": sum(exp.values()), "found_instances": nmac, "per_macro": found,
            "glue_cells_total": (cc.get("_total") or 0) - nmac, "glue_flip_flops": flops,
            "cmd": "yosys -p '" + ys + "'", "rc": r["rc"],
            "result": "PASS" if r["rc"] == 0 and found == exp else "FAIL",
            "log_tail": "" if r["rc"] == 0 else r["out"][-2500:]}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--suite", default="all")
    a = ap.parse_args()
    suites = ["generic", "fpga", "asic"] if a.suite == "all" else a.suite.split(",")
    recs = []
    if "generic" in suites:
        for j in GENERIC:
            recs.append(job_generic(*j)); print(f"[synth] {recs[-1]['result']} {j[0]}", flush=True)
    if "fpga" in suites:
        for j in FPGA:
            recs.append(job_fpga(*j)); print(f"[synth] {recs[-1]['result']} {j[0]} {recs[-1]['ram_primitives']}", flush=True)
    if "asic" in suites:
        for j in ASIC:
            recs.append(job_asic(*j)); print(f"[synth] {recs[-1]['result']} {j[0]} macros={recs[-1]['found_instances']}", flush=True)
    res = {"provenance": provenance(), "records": recs}
    write_json(REPORTS / "synth.json", res)
    L = ["# Synthesis report (Yosys)", "", __doc__.split("\n\n", 1)[1].strip(), "",
         f"Yosys: `{res['provenance']['tools']['yosys']}`.  Vivado: {res['provenance']['tools']['vivado']}; "
         f"Quartus: {res['provenance']['tools']['quartus_sh']}; OpenROAD: {res['provenance']['tools']['openroad']}.", ""]
    g = [r for r in recs if r["suite"] == "generic"]
    if g:
        L += ["## Generic synthesis", "", "| module | params | memories inferred (W x D, rd/wr ports) | cells | flip-flops | latches | warnings | result |",
              "|---|---|---|---|---|---|---|---|"]
        for r in g:
            mems = "; ".join(f"{m['width']}x{m['depth']} ({m['rd_ports']}R/{m['wr_ports']}W)" for m in r["memories"]) or "none"
            L.append(f"| {r['top']} | `{json.dumps(r['params'])}` | {mems} | {r['cells_total']} | {r['flip_flops']} | "
                     f"{r['latches']} | {r['warnings']} | {r['result']} |")
    f = [r for r in recs if r["suite"] == "fpga"]
    if f:
        L += ["", "## FPGA block-RAM inference", "", "| configuration | flow | RAM primitives | other cells | result |", "|---|---|---|---|---|"]
        for r in f:
            L.append(f"| {r['name']} | `{r['flow']}` | {r['ram_primitives']} | {r['other_cells']} | {r['result']} |")
    s = [r for r in recs if r["suite"] == "asic"]
    if s:
        L += ["", "## ASIC macro integrity (black-box macros)", "",
              "| configuration | macro | expected | found | glue cells | glue flip-flops | $mem cells | result |",
              "|---|---|---|---|---|---|---|---|"]
        for r in s:
            L.append(f"| {r['name']} | `{r['macro']}` | {r['expected_instances']} | {r['found_instances']} | "
                     f"{r['glue_cells_total']} | {r['glue_flip_flops']} | 0 (asserted) | {r['result']} |")
    (REPORTS / "synth.md").write_text("\n".join(L) + "\n")
    return 0 if all(r["result"] == "PASS" for r in recs) else 1


if __name__ == "__main__":
    sys.exit(main())
