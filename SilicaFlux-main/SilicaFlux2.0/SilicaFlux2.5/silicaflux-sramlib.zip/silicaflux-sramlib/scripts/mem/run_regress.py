#!/usr/bin/env python3
"""SilicaFlux SRAM library regression.

Suites
  lint     Verilator -Wall lint of every public module (several parameter sets),
           Icarus elaboration, and NEGATIVE tests: unsupported configurations
           must fail elaboration with the expected message.
  sim      Verilator self-checking testbenches over the parameter sweep
           (DATA_WIDTH 8..128, DEPTH 64..4096 incl. non-power-of-two, banks 1..8,
           latencies 1..3, all collision policies, GENERIC and FPGA backends).
  xsim     same seed in Verilator and Icarus -> request/response traces must be
           byte-identical (stimulus and DUT timing are simulator independent).
  equiv    Icarus: GENERIC backend vs ASIC backend on the REAL vendor macro
           models (SKY130 OpenRAM, GF180MCU, IHP SG13G2): both must pass and
           their traces must be identical.  Needs the pinned macro sources
           (scripts/mem/fetch_open_macros.sh); SKIPPED with a reason otherwise.
  mutants  testbench sanity: known bugs are injected into a copy of the RTL;
           every mutant must make its testbench FAIL ("killed").
Results: reports/mem/regression.json and regression.md (provenance, tool
versions, seeds, commands, exit codes, check counts, metrics).
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (BUILD, EXT_DEFAULT, INC_DIRS, REPORTS, ROOT, RTL, RTL_FILES, STUBS, TB, provenance, run,  # noqa: E402
                    tree_hash, write_json)

VL_FLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "--assert", "-DSRAMLIB_ASSERT", "-DSRAMLIB_POISON",
            "--x-assign", "unique", "--x-initial", "unique", "-Wno-fatal", "-Wno-DECLFILENAME", "-Wno-MULTITOP",
            "-Wno-UNUSEDSIGNAL", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-j", "1"]
TB_FILES = {"tb_sram_sp": "tb_sram_sp.sv", "tb_sram_1r1w": "tb_sram_1r1w.sv", "tb_sram_tdp": "tb_sram_tdp.sv",
            "tb_sram_banking": "tb_sram_banking.sv", "tb_sram_mbist": "tb_sram_mbist.sv",
            "tb_sram_fpga_selftest": "tb_sram_fpga_selftest.sv"}
FPGA_TOP = [ROOT / "rtl/mem/fpga/sram_fpga_selftest_top.sv", ROOT / "rtl/mem/fpga/sram_uart_tx.sv"]
EXAMPLES = [ROOT / "rtl/mem/examples/sfv_memory_subsystem_example.sv"]


SRC_HASH = tree_hash([ROOT / "rtl", ROOT / "tb"])


def inc_args(prefix: str) -> list[str]:
    return [f"{prefix}{d}" for d in INC_DIRS]


def parse_result(out: str) -> dict:
    m = re.search(r"SRAM_RESULT (PASS|FAIL) tb=(\S+) seed=(\d+) checks=(\d+) errors=(\d+)", out)
    res = {"result": "FAIL", "checks": 0, "errors": None}
    if m:
        res = {"result": m.group(1), "checks": int(m.group(4)), "errors": int(m.group(5))}
    if re.search(r"%Error|ASSERT|Assertion failed|SRAM_ERROR", out) and res["result"] == "PASS":
        # an embedded RTL assertion fired even though the scoreboard passed
        if re.search(r"%Error|Assertion failed", out):
            res["result"] = "FAIL"
    res["metrics"] = [l.strip() for l in out.splitlines() if l.startswith("SRAM_METRIC")]
    res["first_errors"] = [l.strip() for l in out.splitlines() if "SRAM_ERROR" in l or "%Error" in l][:5]
    return res


# ----------------------------------------------------------------------------- builders
def vl_build(top: str, params: dict, rtl_files: list[Path] | None = None, tag: str = "") -> tuple[Path, dict]:
    # the cache key covers the CONTENT of every source (a stale binary must never be reused)
    key = hashlib.sha1(json.dumps([top, params, tag, [str(p) for p in (rtl_files or [])], SRC_HASH],
                                  sort_keys=True).encode()).hexdigest()[:12]
    mdir = BUILD / "vl" / f"{top}_{key}"
    exe = mdir / "Vtb"
    files = (rtl_files or (RTL_FILES + STUBS))
    extra = FPGA_TOP if top == "tb_sram_fpga_selftest" else []
    cmd = (["verilator", *VL_FLAGS, *inc_args("+incdir+"), *[str(f) for f in files], *[str(f) for f in extra],
            str(TB / TB_FILES[top]), "--top-module", top, "--Mdir", str(mdir), "-o", "Vtb"]
           + [f"-G{k}={v}" for k, v in params.items()])
    if exe.exists() and not tag:
        return exe, {"cmd": " ".join(cmd), "rc": 0, "out": "cached", "secs": 0}
    if mdir.exists():
        shutil.rmtree(mdir)
    mdir.mkdir(parents=True, exist_ok=True)     # verilator does not create parent directories
    r = run(cmd, timeout=1800)
    return exe, r


def iv_build(top: str, params: dict, extra_files: list[Path], out: Path, defines: list[str]) -> dict:
    cmd = (["iverilog", "-g2012", *[f"-D{d}" for d in defines], *inc_args("-I"),
            *[f"-P{top}.{k}={v}" for k, v in params.items()], "-o", str(out), "-s", top,
            str(TB / TB_FILES[top]), *[str(f) for f in RTL_FILES], *[str(f) for f in extra_files]])
    return run(cmd, timeout=1800)


# ----------------------------------------------------------------------------- suites
def sim_matrix(quick: bool) -> list[dict]:
    t: list[dict] = []
    i = 0
    # sram_sp: full DATA_WIDTH x DEPTH sweep on the GENERIC backend
    for dw in (8, 16, 32, 64, 128):
        for depth in (64, 256, 1024, 4096):
            if quick and (dw, depth) not in ((8, 64), (32, 1024), (128, 256)):
                continue
            lat = 1 + (i % 3)
            t.append({"tb": "tb_sram_sp", "p": {"DW": dw, "DEPTH": depth, "MW": dw // 8, "LAT": lat, "FIFO": lat + 1},
                      "args": ["+nrand=1500"]})
            i += 1
    extra_sp = [
        {"DW": 32, "DEPTH": 1024, "MW": 4, "LAT": 1, "BACKEND": 1},
        {"DW": 128, "DEPTH": 256, "MW": 16, "LAT": 2, "FIFO": 3, "BACKEND": 1},
        {"DW": 16, "DEPTH": 4096, "MW": 2, "LAT": 1, "BACKEND": 1},
        {"DW": 16, "DEPTH": 300, "MW": 16, "LAT": 1},                 # bit-level mask
        {"DW": 36, "DEPTH": 1000, "MW": 4, "LAT": 2},                 # 9-bit lanes (data+parity)
        {"DW": 32, "DEPTH": 100, "MW": 4, "LAT": 1, "FIFO": 0},       # no backpressure mode
        {"DW": 64, "DEPTH": 257, "MW": 8, "LAT": 3, "FIFO": 1},       # credit-limited
        {"DW": 32, "DEPTH": 3000, "MW": 4, "LAT": 2, "WACK": 0},      # posted writes
        {"DW": 8, "DEPTH": 1000, "MW": 1, "LAT": 1, "WACK": 0, "FIFO": 5},
    ]
    for p in (extra_sp[:3] if quick else extra_sp):
        t.append({"tb": "tb_sram_sp", "p": p, "args": ["+nrand=1500"]})
    # sram_1r1w
    r1 = [
        {"COLLISION": 0}, {"COLLISION": 1}, {"COLLISION": 2},
        {"COLLISION": 0, "BACKEND": 1, "DW": 64, "MW": 8, "LAT": 2},
        {"COLLISION": 1, "BACKEND": 1, "DW": 16, "MW": 2, "DEPTH": 4096},
        {"COLLISION": 0, "DW": 8, "MW": 1, "DEPTH": 100, "LAT": 2},
        {"COLLISION": 0, "DW": 128, "MW": 16, "DEPTH": 64, "LAT": 3, "FIFO": 1},
    ]
    for p in (r1[:3] if quick else r1):
        t.append({"tb": "tb_sram_1r1w", "p": p, "args": ["+ncyc=2500"]})
    # sram_tdp
    td = [
        {"COLLISION": 0}, {"COLLISION": 2},
        {"COLLISION": 0, "BACKEND": 1, "DW": 64, "MW": 8, "LAT": 2, "WACK": 0},
        {"COLLISION": 0, "DW": 8, "MW": 8, "DEPTH": 100, "FIFO": 0},
    ]
    for p in (td[:2] if quick else td):
        t.append({"tb": "tb_sram_tdp", "p": p, "args": ["+ncyc=2500"]})
    # banking: 1, 2, 4, 8 banks
    bk = [
        {"NM": 2, "NB": 1, "BD": 256},
        {"NM": 2, "NB": 2, "BD": 128, "DW": 8, "MW": 1},
        {"NM": 4, "NB": 2, "BD": 100, "ILV": 1 - 1},
        {"NM": 4, "NB": 4, "BD": 256},
        {"NM": 4, "NB": 4, "BD": 256, "ARB": 1, "ILV": 1},
        {"NM": 3, "NB": 8, "BD": 100, "LAT": 2, "AMODE": 1},
        {"NM": 8, "NB": 8, "BD": 64, "DW": 64, "MW": 8, "LAT": 3, "FIFO": 2},
        {"NM": 4, "NB": 8, "BD": 128, "DW": 128, "MW": 16, "AMODE": 1, "WACK": 0},
        {"NM": 4, "NB": 4, "BD": 512, "BACKEND": 1, "LAT": 2},
        {"NM": 1, "NB": 4, "BD": 64, "DW": 16, "MW": 2, "FIFO": 0},
    ]
    for p in (bk[2:5] if quick else bk):
        t.append({"tb": "tb_sram_banking", "p": p, "args": ["+ncyc=2000"]})
    for p in ({"LAT": 1, "PIPE": 0}, {"LAT": 2, "PIPE": 1}):
        t.append({"tb": "tb_sram_mbist", "p": p, "args": []})
    if (TB / TB_FILES["tb_sram_fpga_selftest"]).exists():
        t.append({"tb": "tb_sram_fpga_selftest", "p": {}, "args": []})
    return t


def run_sim(test: dict, seed: int) -> dict:
    exe, b = vl_build(test["tb"], test["p"])
    rec = {"suite": "sim", "simulator": "verilator", "tb": test["tb"], "params": test["p"], "seed": seed,
           "build_cmd": b["cmd"], "build_rc": b["rc"], "build_secs": b["secs"]}
    if b["rc"] != 0 or not exe.exists():
        rec.update({"result": "FAIL", "reason": "build failed", "log_tail": b["out"][-3000:]})
        return rec
    args = [str(exe), f"+seed={seed}", f"+verilator+seed+{seed}", "+verilator+rand+reset+2", *test["args"]]
    r = run(args, cwd=exe.parent, timeout=3600)
    rec.update({"run_cmd": r["cmd"], "run_rc": r["rc"], "run_secs": r["secs"], **parse_result(r["out"])})
    if r["rc"] != 0 and rec["result"] == "PASS":
        rec["result"] = "FAIL"
    if rec["result"] != "PASS":
        rec["log_tail"] = r["out"][-3000:]
    return rec


LINT_POS = [
    ("sram_sp", {}), ("sram_sp", {"DATA_WIDTH": 128, "DEPTH": 100, "READ_LATENCY": 3, "RSP_FIFO_DEPTH": 0}),
    ("sram_sp", {"BACKEND": 1, "DEPTH": 4096}), ("sram_sp", {"BACKEND": 2, "MACRO": 1, "DEPTH": 1000, "DATA_WIDTH": 64}),
    ("sram_1r1w", {}), ("sram_1r1w", {"BACKEND": 2, "MACRO": 1}), ("sram_1r1w", {"BACKEND": 2, "MACRO": 66}),
    ("sram_tdp", {}), ("sram_tdp", {"BACKEND": 1}), ("sram_tdp", {"BACKEND": 2, "MACRO": 61}),
    ("sram_bank_controller", {}), ("sram_bank_controller", {"NUM_BANKS": 8, "NUM_MASTERS": 3, "ADDR_MODE": 1, "ADDR_WIDTH": 32}),
    ("sram_bank_controller", {"NUM_BANKS": 4, "BACKEND": 2, "MACRO": 21, "DATA_WIDTH": 64, "BANK_DEPTH": 2048}),
    ("sram_mbist_march", {"NUM_TARGETS": 4}), ("sram_mbist_adapter", {}),
    ("sram_backend_1rw", {"BACKEND": 2, "MACRO": 13, "DATA_WIDTH": 32, "MASK_WIDTH": 32, "DEPTH": 1500}),
    ("sram_backend_2rw", {"BACKEND": 2, "MACRO": 61, "READ_LATENCY": 2}),
    ("sram_fpga_selftest_top", {}),
    ("sfv_memory_subsystem_example", {}),
    ("sfv_memory_subsystem_example", {"BACKEND": 2, "MACRO_CTRL": 21, "MACRO_CPU": 24, "MACRO_SPM": 35}),
]
# (top, params, expected message fragment)
LINT_NEG = [
    ("sram_1r1w", {"BACKEND": 2, "MACRO": 13}, "single-port"),
    ("sram_1r1w", {"BACKEND": 2, "MACRO": 1, "COLLISION": 1}, "READ_OLD is not guaranteed"),
    ("sram_tdp", {"BACKEND": 2, "MACRO": 1}, "no 2RW"),
    ("sram_tdp", {"BACKEND": 2, "MACRO": 13}, "single-port"),
    ("sram_tdp", {"COLLISION": 1}, "STALL or FORBID"),
    ("sram_sp", {"BACKEND": 2, "MACRO": 91}, "commercial placeholder"),
    ("sram_sp", {"BACKEND": 2, "MACRO": 90}, "commercial placeholder"),
    ("sram_sp", {"BACKEND": 2, "MACRO": 92}, "commercial placeholder"),
    ("sram_sp", {"BACKEND": 2}, "requires an explicit MACRO"),
    ("sram_sp", {"BACKEND": 2, "MACRO": 55}, "not a catalogue entry"),
    ("sram_sp", {"BACKEND": 2, "MACRO": 1, "DATA_WIDTH": 36, "MASK_WIDTH": 4}, "mask granularity"),
    ("sram_sp", {"BACKEND": 2, "MACRO": 21, "READ_LATENCY": 0}, "READ_LATENCY"),
    ("sram_sp", {"BACKEND": 0, "INIT_FILE": '"x.hex"'}, "only supported by the FPGA backend"),
    ("sram_sp", {"BACKEND": 7}, "unknown BACKEND"),
    ("sram_sp", {"DEPTH": 1}, "DEPTH must be >= 2"),
    ("sram_sp", {"DATA_WIDTH": 32, "MASK_WIDTH": 3}, "MASK_WIDTH must divide"),
    ("sram_sp", {"WRITE_ACK": 2}, "WRITE_ACK"),
    ("sram_bank_controller", {"NUM_BANKS": 3}, "power of two"),
    ("sram_bank_controller", {"INTERLEAVE": 1, "BANK_DEPTH": 100}, "power-of-two BANK_DEPTH"),
    ("sram_bank_controller", {"ADDR_MODE": 1, "DATA_WIDTH": 24, "MASK_WIDTH": 3}, "power of two"),
    ("sram_bank_controller", {"ADDR_WIDTH": 8}, "ADDR_WIDTH"),
    ("sram_mbist_march", {"ALGO": 5}, "unknown ALGO"),
]


def lint_cmd(top: str, params: dict, wall: bool) -> list[str]:
    files = RTL_FILES + STUBS + FPGA_TOP + EXAMPLES
    return (["verilator", "--lint-only", *(["-Wall"] if wall else []), "-Wno-DECLFILENAME", "-Wno-MULTITOP",
             *inc_args("+incdir+"), *[str(f) for f in files], "--top-module", top]
            + [f"-G{k}={v}" for k, v in params.items()])


def run_lint() -> list[dict]:
    recs = []
    for top, p in LINT_POS:
        r = run(lint_cmd(top, p, True), timeout=600)
        warns = [l for l in r["out"].splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
        recs.append({"suite": "lint", "kind": "positive", "top": top, "params": p, "cmd": r["cmd"], "rc": r["rc"],
                     "warnings": len(warns), "result": "PASS" if r["rc"] == 0 and not warns else "FAIL",
                     "messages": warns[:10]})
    for top, p, frag in LINT_NEG:
        r = run(lint_cmd(top, p, False), timeout=600)
        ok = r["rc"] != 0 and frag in r["out"]
        msg = next((l for l in r["out"].splitlines() if "USERFATAL" in l or "%Error" in l), "")
        recs.append({"suite": "lint", "kind": "negative", "top": top, "params": p, "expect": frag, "cmd": r["cmd"],
                     "rc": r["rc"], "result": "PASS" if ok else "FAIL", "message": msg.strip()})
    # Icarus elaboration of the public wrappers (portability)
    for top, p in (("sram_sp", {}), ("sram_1r1w", {}), ("sram_tdp", {}), ("sram_bank_controller", {}), ("sram_mbist_march", {})):
        out = BUILD / "iv" / f"lint_{top}.vvp"
        out.parent.mkdir(parents=True, exist_ok=True)
        cmd = ["iverilog", "-g2012", *inc_args("-I"), "-o", str(out), "-s", top, *[str(f) for f in RTL_FILES]]
        r = run(cmd, timeout=600)
        errs = [l for l in r["out"].splitlines() if "error" in l.lower() and "cannot be synthesized" not in l]
        recs.append({"suite": "lint", "kind": "icarus-elab", "top": top, "params": p, "cmd": r["cmd"], "rc": r["rc"],
                     "result": "PASS" if r["rc"] == 0 and not errs else "FAIL", "messages": errs[:5]})
    return recs


def run_xsim(seed: int) -> list[dict]:
    recs = []
    cfgs = [("tb_sram_sp", {"DW": 32, "DEPTH": 1024, "MW": 4, "LAT": 1}, ["+nrand=1500"]),
            ("tb_sram_sp", {"DW": 8, "DEPTH": 100, "MW": 1, "LAT": 2}, ["+nrand=1500"]),
            ("tb_sram_1r1w", {"COLLISION": 0}, ["+ncyc=1500"]),
            ("tb_sram_tdp", {"COLLISION": 0}, ["+ncyc=1500"]),
            ("tb_sram_banking", {"NM": 4, "NB": 4, "BD": 64}, ["+ncyc=600"])]
    for tb, p, args in cfgs:
        d = BUILD / "xsim" / hashlib.sha1(json.dumps([tb, p]).encode()).hexdigest()[:10]
        d.mkdir(parents=True, exist_ok=True)
        exe, b = vl_build(tb, p)
        rv = run([str(exe), f"+seed={seed}", f"+trace={d}/vl.txt", *args], cwd=d, timeout=3600)
        bi = iv_build(tb, p, [], d / "iv.vvp", ["SRAMLIB_POISON"])
        ri = run(["vvp", "-n", str(d / "iv.vvp"), f"+seed={seed}", f"+trace={d}/iv.txt", *args], cwd=d, timeout=3600)
        pv, pi = parse_result(rv["out"]), parse_result(ri["out"])
        same = (d / "vl.txt").exists() and (d / "iv.txt").exists() and (d / "vl.txt").read_bytes() == (d / "iv.txt").read_bytes()
        n = len((d / "vl.txt").read_text().splitlines()) if (d / "vl.txt").exists() else 0
        recs.append({"suite": "xsim", "tb": tb, "params": p, "seed": seed, "verilator": pv["result"], "icarus": pi["result"],
                     "checks_verilator": pv["checks"], "checks_icarus": pi["checks"], "trace_lines": n,
                     "traces_identical": same, "cmds": [rv["cmd"], bi["cmd"], ri["cmd"]],
                     "result": "PASS" if pv["result"] == pi["result"] == "PASS" and same else "FAIL"})
    return recs


def macro_models(ext: Path) -> dict[str, list[Path]]:
    s = ext / "sky130_sram_macros"
    g = ext / "gf180_sram/cells"
    i = ext / "ihp/ihp-sg13g2/libs.ref/sg13g2_sram/verilog"
    return {
        "sky130": [s / n / f"{n}.v" for n in ("sky130_sram_1kbyte_1rw1r_32x256_8", "sky130_sram_2kbyte_1rw1r_32x512_8",
                                               "sky130_sram_1kbyte_1rw1r_8x1024_8")],
        "gf180": [g / n / f"{n}.v" for n in ("gf180mcu_fd_ip_sram__sram512x8m8wm1", "gf180mcu_fd_ip_sram__sram64x8m8wm1")],
        "ihp1p": [i / "RM_IHPSG13_1P_core_behavioral_bm_bist.v", i / "RM_IHPSG13_1P_1024x32_c2_bm_bist.v",
                  i / "RM_IHPSG13_1P_256x64_c2_bm_bist.v"],
        "ihp2p": [i / "RM_IHPSG13_2P_core_behavioral_bm_bist_ideal.v", i / "RM_IHPSG13_2P_1024x32_c2_bm_bist.v",
                  i / "RM_IHPSG13_2P_512x32_c2_bm_bist.v"],
    }


EQUIV = [
    # name, tb, params (BACKEND/MACRO added for the ASIC run), model set, plusargs
    ("sky130 1RW 32x256 native", "tb_sram_sp", {"DW": 32, "DEPTH": 256, "MW": 4, "LAT": 1, "MACRO": 1}, "sky130", ["+nrand=1500"]),
    ("sky130 1RW 64x1000 tiled 2x4", "tb_sram_sp", {"DW": 64, "DEPTH": 1000, "MW": 8, "LAT": 2, "MACRO": 1}, "sky130", ["+nrand=1500"]),
    ("sky130 1RW 8x1024 + posted writes", "tb_sram_sp", {"DW": 8, "DEPTH": 1024, "MW": 1, "LAT": 1, "WACK": 0, "MACRO": 3}, "sky130", ["+nrand=1500"]),
    ("sky130 1R1W 32x512 STALL", "tb_sram_1r1w", {"DW": 32, "DEPTH": 512, "MW": 4, "LAT": 1, "COLLISION": 0, "MACRO": 2}, "sky130", ["+ncyc=1500"]),
    ("gf180 1RW 32x512 bit-mask (4 cols)", "tb_sram_sp", {"DW": 32, "DEPTH": 512, "MW": 32, "LAT": 1, "MACRO": 13}, "gf180", ["+nrand=1500"]),
    ("gf180 1RW 16x150 tiled 2x3", "tb_sram_sp", {"DW": 16, "DEPTH": 150, "MW": 2, "LAT": 2, "MACRO": 10}, "gf180", ["+nrand=1500"]),
    ("ihp 1P 32x2048 tiled 1x2 lat2", "tb_sram_sp", {"DW": 32, "DEPTH": 2048, "MW": 4, "LAT": 2, "MACRO": 21}, "ihp1p", ["+nrand=1500"]),
    ("ihp 1P 128x256 tiled 2x1", "tb_sram_sp", {"DW": 128, "DEPTH": 256, "MW": 16, "LAT": 1, "MACRO": 29}, "ihp1p", ["+nrand=1500"]),
    ("ihp 2P 2RW 32x1024 STALL", "tb_sram_tdp", {"DW": 32, "DEPTH": 1024, "MW": 4, "LAT": 1, "COLLISION": 0, "MACRO": 61}, "ihp2p", ["+ncyc=1500"]),
    ("ihp 2P 1R1W 32x500 STALL", "tb_sram_1r1w", {"DW": 32, "DEPTH": 500, "MW": 4, "LAT": 1, "COLLISION": 0, "MACRO": 66}, "ihp2p", ["+ncyc=1500"]),
    ("sky130 4-bank controller", "tb_sram_banking", {"NM": 4, "NB": 4, "BD": 256, "DW": 32, "MW": 4, "MACRO": 1}, "sky130", ["+ncyc=800"]),
]


def run_equiv(seed: int, ext: Path) -> list[dict]:
    recs = []
    models = macro_models(ext)
    for name, tb, p, mset, args in EQUIV:
        files = models[mset]
        missing = [str(f) for f in files if not f.exists()]
        if missing:
            recs.append({"suite": "equiv", "name": name, "result": "SKIP",
                         "reason": f"vendor model not present: {missing[0]} (run scripts/mem/fetch_open_macros.sh)"})
            continue
        d = BUILD / "equiv" / re.sub(r"\W+", "_", name)
        d.mkdir(parents=True, exist_ok=True)
        pg = {k: v for k, v in p.items() if k != "MACRO"} | {"BACKEND": 0}
        pa = p | {"BACKEND": 2}
        defs = ["SRAMLIB_POISON"] + (["FUNCTIONAL"] if mset.startswith("ihp") else [])
        defs_asic = defs + ["SRAMLIB_VERBOSE", "SRAMLIB_VENDOR_MODELS"]
        bg = iv_build(tb, pg, [], d / "g.vvp", defs)
        ba = iv_build(tb, pa, files, d / "a.vvp", defs_asic)
        rg = run(["vvp", "-n", str(d / "g.vvp"), f"+seed={seed}", f"+trace={d}/g.txt", *args], cwd=d, timeout=3600)
        ra = run(["vvp", "-n", str(d / "a.vvp"), f"+seed={seed}", f"+trace={d}/a.txt", *args], cwd=d, timeout=3600)
        out_a = "\n".join(l for l in ra["out"].splitlines() if not re.search(r"\b(Reading|Writing) ", l))
        pg_, pa_ = parse_result(rg["out"]), parse_result(out_a)
        tile = next((l for l in out_a.splitlines() if "[sramlib]" in l), "")
        has_trace = (d / "g.txt").exists() and (d / "a.txt").exists() and (d / "g.txt").stat().st_size > 0
        same = has_trace and (d / "g.txt").read_bytes() == (d / "a.txt").read_bytes()
        rec = {"suite": "equiv", "name": name, "tb": tb, "params": pa, "seed": seed, "models": [str(f.relative_to(ext)) for f in files],
               "generic": pg_["result"], "asic_vendor_model": pa_["result"], "checks_generic": pg_["checks"],
               "checks_asic": pa_["checks"], "tiling": tile.split(": ", 1)[-1] if tile else "",
               "trace_compare": ("identical" if same else "DIFFERENT") if has_trace else "check counts only (no trace in this TB)",
               "cmds": [bg["cmd"], ba["cmd"], rg["cmd"], ra["cmd"]]}
        ok = pg_["result"] == pa_["result"] == "PASS" and (same if has_trace else pg_["checks"] == pa_["checks"])
        rec["result"] = "PASS" if ok else "FAIL"
        if not ok:
            rec["log_tail_asic"] = out_a[-2000:]
            rec["build_asic"] = ba["out"][-1500:]
        recs.append(rec)
    return recs


MUTANTS = [
    ("rsp FIFO bypass ignores queued responses (reordering)", "sram_rsp_path.sv",
     "wire bypass    = !from_fifo && stg_valid && rsp_ready;", "wire bypass    = stg_valid && rsp_ready;",
     "tb_sram_sp", {"DW": 32, "DEPTH": 256, "MW": 4, "LAT": 2}),
    ("credit check off by one (FIFO overflow)", "sram_rsp_path.sv",
     "assign can_issue = live_q && (oc_q < CW'(FIFO_DEPTH));", "assign can_issue = live_q && (oc_q <= CW'(FIFO_DEPTH));",
     "tb_sram_sp", {"DW": 32, "DEPTH": 256, "MW": 4, "LAT": 1}),
    ("write mask ignored", "backends/generic/sram_generic_1rw.sv",
     "if (wmask[l]) new_w[l*LW +: LW] = wdata[l*LW +: LW];", "new_w[l*LW +: LW] = wdata[l*LW +: LW];",
     "tb_sram_sp", {"DW": 32, "DEPTH": 256, "MW": 4, "LAT": 1}),
    ("invalid-address check removed", "sram_sp.sv",
     "assign addr_ok   = POW2 ? 1'b1 : ({1'b0, req_addr} < DEPTH_W);", "assign addr_ok   = 1'b1;",
     "tb_sram_sp", {"DW": 32, "DEPTH": 100, "MW": 4, "LAT": 1}),
    ("1R1W STALL does not stall the write", "sram_1r1w.sv",
     "assign wr_ready = base_w && !(coll && rd_wins);", "assign wr_ready = base_w;",
     "tb_sram_1r1w", {"COLLISION": 0}),
    ("2RW conflict not prevented", "sram_tdp.sv",
     "assign b_req_ready = b_base && !(conflict && !b_wins && a_base);", "assign b_req_ready = b_base;",
     "tb_sram_tdp", {"COLLISION": 0}),
    ("bank owner pipeline misroutes read data", "sram_bank_controller.sv",
     "own_idx[b*READ_LATENCY] <= b_gidx[b];", "own_idx[b*READ_LATENCY] <= '0;",
     "tb_sram_banking", {"NM": 4, "NB": 4, "BD": 64}),
    ("bank decode aliases banks", "sram_bank_controller.sv",
     "m_bank[m] = BW'(w);", "m_bank[m] = BW'(w >> 1);",
     "tb_sram_banking", {"NM": 4, "NB": 4, "BD": 64}),
    ("MBIST March element 2 reads the wrong value", "sram_mbist_march.sv",
     "3'd2: elem_info = 4'b0111;   // U(r1,w0)", "3'd2: elem_info = 4'b0110;   // U(r1,w0)",
     "tb_sram_mbist", {"LAT": 1, "PIPE": 0}),
    ("test mode does not block functional requests", "sram_sp.sv",
     "assign req_ready = !t_on && (can_issue || (!needs_rsp && rst_n_live));",
     "assign req_ready = (can_issue || (!needs_rsp && rst_n_live));",
     "tb_sram_sp", {"DW": 32, "DEPTH": 256, "MW": 4, "LAT": 1}),
]


def run_mutants(seed: int) -> list[dict]:
    recs = []
    for name, rel, old, new, tb, p in MUTANTS:
        tmp = Path(tempfile.mkdtemp(prefix="mut_", dir=BUILD))
        shutil.copytree(RTL, tmp / "rtl_mem")
        f = tmp / "rtl_mem" / rel
        src = f.read_text()
        if src.count(old) != 1:
            recs.append({"suite": "mutants", "name": name, "result": "FAIL", "reason": f"mutation anchor not unique in {rel}"})
            continue
        f.write_text(src.replace(old, new))
        mfiles = [tmp / "rtl_mem" / pth.relative_to(RTL) for pth in RTL_FILES] + STUBS
        exe, b = vl_build(tb, p, rtl_files=mfiles, tag=name)
        if b["rc"] != 0:
            recs.append({"suite": "mutants", "name": name, "result": "FAIL", "reason": "mutant did not build", "log": b["out"][-1500:]})
            continue
        r = run([str(exe), f"+seed={seed}", "+nrand=1500", "+ncyc=1500"], cwd=exe.parent, timeout=3600)
        pr = parse_result(r["out"])
        killed = pr["result"] != "PASS"
        recs.append({"suite": "mutants", "name": name, "file": rel, "tb": tb, "params": p, "seed": seed,
                     "tb_result": pr["result"], "first_errors": pr["first_errors"][:2],
                     "result": "PASS" if killed else "FAIL", "verdict": "killed" if killed else "SURVIVED"})
        shutil.rmtree(tmp, ignore_errors=True)
        shutil.rmtree(exe.parent, ignore_errors=True)
    return recs


# ----------------------------------------------------------------------------- report
def write_md(res: dict, path: Path) -> None:
    L = ["# SRAM library regression report", "",
         f"Generated {res['provenance']['generated_utc']} on `{res['provenance']['host']}`.  "
         f"Library tree sha256 `{res['provenance']['library_tree_sha256'][:16]}…`; "
         f"git: `{res['provenance']['git'].get('commit')}` "
         f"(library files committed: {res['provenance']['git'].get('library_files_committed')}).", "",
         "## Tools", "", "| tool | version |", "|---|---|"]
    L += [f"| {k} | {v} |" for k, v in res["provenance"]["tools"].items()]
    L += ["", f"Base seed: {res['base_seed']}.  Command: `{res['command']}`", "", "## Summary", "",
          "| suite | PASS | FAIL | SKIP |", "|---|---|---|---|"]
    for s, c in res["summary"].items():
        L.append(f"| {s} | {c['PASS']} | {c['FAIL']} | {c['SKIP']} |")
    for suite in ("lint", "sim", "xsim", "equiv", "mutants"):
        rows = [r for r in res["records"] if r["suite"] == suite]
        if not rows:
            continue
        L += ["", f"## {suite}", ""]
        if suite == "lint":
            L += ["| kind | top | params | result | detail |", "|---|---|---|---|---|"]
            for r in rows:
                det = r.get("expect", "") and f"expects '{r['expect']}': {r.get('message', '')[:110]}" or (f"{r.get('warnings', 0)} warnings" if r["kind"] == "positive" else "")
                L.append(f"| {r['kind']} | {r['top']} | `{json.dumps(r['params'])}` | {r['result']} | {det} |")
        elif suite == "sim":
            L += ["| tb | params | seed | checks | errors | result | secs |", "|---|---|---|---|---|---|---|"]
            for r in rows:
                L.append(f"| {r['tb']} | `{json.dumps(r['params'])}` | {r['seed']} | {r.get('checks', 0)} | {r.get('errors')} | "
                         f"{r['result']} | {r.get('run_secs', '')} |")
        elif suite == "xsim":
            L += ["| tb | params | checks (VL / IV) | trace lines | identical | result |", "|---|---|---|---|---|---|"]
            for r in rows:
                L.append(f"| {r['tb']} | `{json.dumps(r['params'])}` | {r['checks_verilator']} / {r['checks_icarus']} | "
                         f"{r['trace_lines']} | {r['traces_identical']} | {r['result']} |")
        elif suite == "equiv":
            L += ["| configuration | tiling (from elaboration) | generic | vendor model | checks | traces | result |",
                  "|---|---|---|---|---|---|---|"]
            for r in rows:
                if r["result"] == "SKIP":
                    L.append(f"| {r['name']} | | | | | | SKIP: {r['reason']} |")
                else:
                    L.append(f"| {r['name']} | {r['tiling']} | {r['generic']} | {r['asic_vendor_model']} | "
                             f"{r['checks_generic']} / {r['checks_asic']} | {r['trace_compare']} | {r['result']} |")
        elif suite == "mutants":
            L += ["| injected bug | testbench | verdict | first detection |", "|---|---|---|---|"]
            for r in rows:
                L.append(f"| {r['name']} | {r.get('tb', '')} | {r.get('verdict', r.get('reason'))} | "
                         f"{(r.get('first_errors') or [''])[0][:100]} |")
    path.write_text("\n".join(L) + "\n")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--suite", default="all", help="lint,sim,xsim,equiv,mutants or all")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--seed", type=int, default=20261105)
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2)))
    ap.add_argument("--ext", type=Path, default=EXT_DEFAULT)
    ap.add_argument("--out", type=Path, default=REPORTS / "regression.json")
    a = ap.parse_args()
    suites = ["lint", "sim", "xsim", "equiv", "mutants"] if a.suite == "all" else a.suite.split(",")
    BUILD.mkdir(parents=True, exist_ok=True)
    records: list[dict] = []
    if "lint" in suites:
        print("[regress] lint ...", flush=True)
        records += run_lint()
    if "sim" in suites:
        tests = sim_matrix(a.quick)
        print(f"[regress] sim: {len(tests)} configurations, {a.jobs} jobs ...", flush=True)
        with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
            futs = [ex.submit(run_sim, t, a.seed + i) for i, t in enumerate(tests)]
            for f in futs:
                r = f.result()
                print(f"  {r['result']:4} {r['tb']} {json.dumps(r['params'])} checks={r.get('checks')}", flush=True)
                records.append(r)
    if "xsim" in suites:
        print("[regress] xsim ...", flush=True)
        records += run_xsim(a.seed)
    if "equiv" in suites:
        print(f"[regress] equiv (vendor models from {a.ext}) ...", flush=True)
        records += run_equiv(a.seed, a.ext)
    if "mutants" in suites:
        print("[regress] mutants ...", flush=True)
        records += run_mutants(a.seed)
    summary: dict[str, dict] = {}
    for r in records:
        s = summary.setdefault(r["suite"], {"PASS": 0, "FAIL": 0, "SKIP": 0})
        s[r["result"]] += 1
    res = {"provenance": provenance(), "base_seed": a.seed, "command": " ".join(sys.argv), "summary": summary,
           "records": records}
    write_json(a.out, res)
    write_md(res, a.out.with_suffix(".md"))
    for s, c in summary.items():
        print(f"[regress] {s:8} PASS {c['PASS']:3}  FAIL {c['FAIL']:3}  SKIP {c['SKIP']:3}")
    return 1 if any(c["FAIL"] for c in summary.values()) else 0


if __name__ == "__main__":
    sys.exit(main())
