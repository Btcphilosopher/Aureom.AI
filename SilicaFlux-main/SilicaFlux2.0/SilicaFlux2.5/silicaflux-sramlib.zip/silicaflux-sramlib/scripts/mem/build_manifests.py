#!/usr/bin/env python3
"""Build SRAM macro configuration manifests from the *real* public macro sources.

Every value written into manifests/<macro>.json is either
  * extracted from a vendor/PDK file (Verilog model, LEF, datasheet, spec CSV),
    with the file's path and sha256 recorded under "provenance", or
  * a behavioural observation from reading that file, stated in "notes" and
    attributed to the file it came from.
Nothing here is typed in from memory.  Commercial-node manifests are not built
by this script (they are hand-written PENDING placeholders with null fields).

Usage:
  scripts/mem/fetch_open_macros.sh <ext_dir>         # pinned sparse clones
  python3 scripts/mem/build_manifests.py --ext <ext_dir> --out manifests
The ext directory is treated as data: files are only read and parsed.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
from pathlib import Path

SKY130_REPO = "https://github.com/efabless/sky130_sram_macros"
GF180_REPO = "https://github.com/google/globalfoundries-pdk-ip-gf180mcu_fd_ip_sram"
IHP_REPO = "https://github.com/IHP-GmbH/IHP-Open-PDK"

# Library macro IDs.  Never renumber (they are compiled into RTL via the
# generated catalogue).  Ranges: 1-9 SKY130, 10-19 GF180, 20-59 IHP 1P,
# 60-79 IHP 2P, 90-99 commercial placeholders.
SKY130_IDS = {
    "sky130_sram_1kbyte_1rw1r_32x256_8": (1, "SKY130_1RW1R_32X256"),
    "sky130_sram_2kbyte_1rw1r_32x512_8": (2, "SKY130_1RW1R_32X512"),
    "sky130_sram_1kbyte_1rw1r_8x1024_8": (3, "SKY130_1RW1R_8X1024"),
}
GF180_IDS = {
    "gf180mcu_fd_ip_sram__sram64x8m8wm1": (10, "GF180_1RW_8X64"),
    "gf180mcu_fd_ip_sram__sram128x8m8wm1": (11, "GF180_1RW_8X128"),
    "gf180mcu_fd_ip_sram__sram256x8m8wm1": (12, "GF180_1RW_8X256"),
    "gf180mcu_fd_ip_sram__sram512x8m8wm1": (13, "GF180_1RW_8X512"),
}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def git_head(repo: Path) -> str:
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True,
                          text=True, check=True).stdout.strip()


def git_files(repo: Path, prefix: str) -> list[str]:
    args = ["git", "-C", str(repo), "ls-tree", "-r", "--name-only", "HEAD"] + ([prefix] if prefix else [])
    out = subprocess.run(args,
                         capture_output=True, text=True, check=True).stdout
    return [l for l in out.splitlines() if l]


def lef_size(p: Path) -> tuple[float, float]:
    m = re.search(r"^\s*SIZE\s+([0-9.]+)\s+BY\s+([0-9.]+)\s*;", p.read_text(errors="replace"), re.M)
    if not m:
        raise ValueError(f"no SIZE in {p}")
    return float(m.group(1)), float(m.group(2))


def verilog_ports(p: Path, module: str) -> dict[str, tuple[str, int]]:
    """Port name -> (direction, width), from non-ANSI 'input [a:b] name;' declarations."""
    txt = re.sub(r"//.*", "", p.read_text(errors="replace"))
    m = re.search(r"\bmodule\s+" + re.escape(module) + r"\b(.*?)\bendmodule", txt, re.S)
    if not m:
        raise ValueError(f"module {module} not in {p}")
    body = m.group(1)
    ports: dict[str, tuple[str, int]] = {}
    for d in re.finditer(r"^\s*(input|output|inout)\s+(?:wire\s+|reg\s+)?(\[[^\]]+\])?\s*([\w\s,]+);",
                         body, re.M):
        width = 1
        if d.group(2):
            a, b = re.match(r"\[\s*(\d+)\s*:\s*(\d+)\s*\]", d.group(2)).groups()  # numeric ranges only
            width = abs(int(a) - int(b)) + 1
        for name in [n.strip() for n in d.group(3).split(",") if n.strip()]:
            ports[name] = (d.group(1), width)
    return ports


def rel(p: Path, root: Path) -> str:
    return str(p.relative_to(root))


# --------------------------------------------------------------------- SKY130
def build_sky130(root: Path) -> list[dict]:
    head = git_head(root)
    allf = git_files(root, "")
    lic = root / "LICENSE"
    out = []
    for name, (mid, define) in SKY130_IDS.items():
        d = root / name
        v = d / f"{name}.v"
        lef = d / f"{name}.lef"
        txt = v.read_text()
        par = {k: int(x) for k, x in re.findall(r"parameter\s+(\w+)\s*=\s*(\d+)\s*;", txt)}
        w, h = lef_size(lef)
        views = [f for f in allf if f.startswith(name + "/")]
        aw, dw, nm = par["ADDR_WIDTH"], par["DATA_WIDTH"], par["NUM_WMASKS"]
        plist = [("input", "clk0", 1), ("input", "csb0", 1), ("input", "web0", 1), ("input", "wmask0", nm),
                 ("input", "addr0", aw), ("input", "din0", dw), ("output", "dout0", dw), ("input", "clk1", 1),
                 ("input", "csb1", 1), ("input", "addr1", aw), ("output", "dout1", dw)]
        for pd, pn, pw in plist:   # cross-check against the model text
            assert re.search(r"\b" + pd + r"\b[^;]*\b" + pn + r"\s*;", txt), (name, pn)
        out.append({
            "id": mid, "define": "SRAM_MACRO_" + define, "macro_name": name, "family": "SKY130_1RW1R",
            "status": "OPEN_SOURCE_AVAILABLE",
            "foundry": "SkyWater Technology (open PDK)", "process": "SKY130 (130 nm)",
            "generator": "OpenRAM (per Verilog model header '// OpenRAM SRAM model')",
            "data_width": par["DATA_WIDTH"], "words": 1 << par["ADDR_WIDTH"],
            "address_width": par["ADDR_WIDTH"],
            "port_topology": "1RW1R",
            "port_list": [{"dir": d, "name": n, "width": w} for d, n, w in plist],
            "ports": {"port0": "read/write (clk0,csb0,web0,wmask0,addr0,din0,dout0)",
                      "port1": "read only (clk1,csb1,addr1,dout1)"},
            "read_latency_cycles": 1,
            "write_mask": {"granularity_bits": par["DATA_WIDTH"] // par["NUM_WMASKS"],
                           "mask_bits": par["NUM_WMASKS"], "polarity": "active_high", "pin": "wmask0"},
            "clock": {"pins": ["clk0", "clk1"], "polarity": "rising edge registers all inputs"},
            "chip_enable": {"pins": ["csb0", "csb1"], "polarity": "active_low"},
            "write_enable": {"pin": "web0", "polarity": "active_low"},
            "sleep_retention": {"supported": False, "notes": "no sleep/retention pins in the Verilog model"},
            "output_hold": "NOT_HELD: dout is driven X T_HOLD after every rising clk edge and updated after the "
                           "falling edge of a read cycle; sample it exactly one cycle after the read",
            "collision": {
                "port0_read_during_write": "not applicable (web0 selects read or write)",
                "cross_port_same_address": "UNDEFINED: model prints 'WARNING: Writing and reading addr0 and "
                                           "addr1 simultaneously' and both ports act on the falling edge",
            },
            "supply_pins": ["vccd1", "vssd1"],
            "supply_pin_condition": "only when USE_POWER_PINS is defined",
            "test_pins": [],
            "tie_offs": {},
            "views": {
                "verilog_model": rel(v, root),
                "liberty": [f for f in views if f.endswith(".lib")],
                "lef": rel(lef, root),
                "gds": [f for f in views if f.endswith(".gds")],
                "spice": [f for f in views if f.endswith(".sp")],
            },
            "physical": {"width_um": w, "height_um": h, "area_um2": round(w * h, 2), "source": rel(lef, root)},
            "timing": {"source": [f for f in views if f.endswith(".lib")],
                       "notes": "not extracted; read the Liberty file for the selected corner"},
            "license": "Apache-2.0", "license_file": "LICENSE",
            "access": "public download, no NDA",
            "silicon_status": "not established by this library (no silicon or FPGA measurement performed)",
            "constraints": [
                "same-address write (port0) and read (port1) in one cycle must not be issued",
                "dout0/dout1 are valid only in the cycle after the read: capture, never rely on hold",
            ],
            "pin_map": {"clk": "clk0, clk1", "ce (1RW)": "csb0 = ~ce", "we": "web0 = ~we",
                        "wmask[lane]": "wmask0[byte] (lane width must be a multiple of 8)",
                        "addr": "addr0 (1RW) / addr0=write, addr1=read (1R1W)",
                        "wdata": "din0", "rdata": "dout0 (1RW) / dout1 (1R1W)",
                        "unused": "csb1 = 1 in 1RW use"},
            "provenance": {"repo": SKY130_REPO, "commit": head,
                           "files": {rel(p, root): sha256(p) for p in (v, lef, lic)}},
        })
    return out


# --------------------------------------------------------------------- GF180
def build_gf180(root: Path) -> list[dict]:
    head = git_head(root)
    allf = git_files(root, "cells")
    lic = root / "LICENSE"
    out = []
    for name, (mid, define) in GF180_IDS.items():
        d = root / "cells" / name
        v = d / f"{name}.v"
        lef = d / f"{name}.lef"
        ports = verilog_ports(v, name)
        dims = d / "specs" / "6_Physical_Dimensions.csv"
        ac = d / "specs" / "5_AC_Characteristics2.csv"
        rows = list(csv.reader(dims.read_text().splitlines()))
        w, h, area = (float(x) for x in rows[1][:3])
        acrows = {r[0]: r for r in csv.reader(ac.read_text().splitlines()) if r}
        lw, lh = lef_size(lef)
        views = [f for f in allf if f.startswith(f"cells/{name}/")]
        out.append({
            "id": mid, "define": "SRAM_MACRO_" + define, "macro_name": name, "family": "GF180_1RW",
            "status": "OPEN_SOURCE_AVAILABLE",
            "foundry": "GlobalFoundries (open PDK)", "process": "GF180MCU (180 nm)",
            "data_width": ports["D"][1], "words": 1 << ports["A"][1], "address_width": ports["A"][1],
            "port_topology": "1RW",
            "port_list": [{"dir": d, "name": n, "width": w} for n, (d, w) in ports.items()],
            "read_latency_cycles": 1,
            "write_mask": {"granularity_bits": 1, "mask_bits": ports["WEN"][1], "polarity": "active_low",
                           "pin": "WEN"},
            "clock": {"pins": ["CLK"], "polarity": "rising edge latches all inputs (specs/1_pins_desc.csv)"},
            "chip_enable": {"pin": "CEN", "polarity": "active_low"},
            "write_enable": {"pin": "GWEN", "polarity": "active_low"},
            "sleep_retention": {"supported": False,
                                "notes": "CEN high = standby with data retained (specs/1_pins_desc.csv); "
                                         "no separate sleep/retention pin"},
            "output_hold": "HOLDS previous data in write, standby and mask cycles (specs/2_truth_table.csv)",
            "collision": {"port0_read_during_write": "write cycle returns 'Hold previous data' on Q",
                          "cross_port_same_address": "not applicable (single port)"},
            "supply_pins": ["VDD", "VSS"],
            "test_pins": [],
            "tie_offs": {},
            "views": {
                "verilog_model": rel(v, root),
                "liberty": [f for f in views if f.endswith(".lib")],
                "lef": rel(lef, root),
                "gds": [f for f in views if f.endswith(".gds")],
                "cdl": [f for f in views if f.endswith(".cdl")],
            },
            "physical": {"width_um": w, "height_um": h, "area_um2": area, "source": rel(dims, root),
                         "lef_size_um": [lw, lh]},
            "timing": {"source": rel(ac, root), "corner": "Typical process, 3.3 V, 25 C",
                       "min_clock_period_ns": float(acrows["Tcyc"][4]),
                       "clock_to_q_rise_ns": float(acrows["Tah"][4])},
            "license": "Apache-2.0", "license_file": "LICENSE",
            "access": "public download, no NDA",
            "silicon_status": "not established by this library (no silicon or FPGA measurement performed)",
            "constraints": [
                "CEN must be high before the first running cycle (specs/1_pins_desc.csv); the model "
                "ignores accesses until it has seen a CEN 1->0 transition",
                "simulation model initialises the array to 0; silicon content after power-up is undefined",
            ],
            "pin_map": {"clk": "CLK", "ce": "CEN = ~ce", "we": "GWEN = ~we",
                        "wmask[lane]": "WEN[bit] = ~(lane mask expanded to bits)",
                        "addr": "A", "wdata": "D", "rdata": "Q"},
            "provenance": {"repo": GF180_REPO, "commit": head,
                           "files": {rel(p, root): sha256(p) for p in (v, lef, dims, ac, lic)}},
        })
    return out


# --------------------------------------------------------------------- IHP
def build_ihp(root: Path) -> list[dict]:
    head = git_head(root)
    base = "ihp-sg13g2/libs.ref/sg13g2_sram"
    allf = git_files(root, base)
    lic = root / "LICENSE"
    out = []
    names = sorted({Path(f).stem for f in allf if f.startswith(base + "/verilog/RM_IHPSG13_")
                    and f.endswith("_bm_bist.v")})
    n1, n2 = 20, 60
    for name in names:
        m = re.match(r"RM_IHPSG13_(\dP)_(\d+)x(\d+)_c(\d)_bm_bist$", name)
        if not m:
            continue
        kind, words, width, cmux = m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4))
        if kind == "1P":
            mid, n1 = n1, n1 + 1
        else:
            mid, n2 = n2, n2 + 1
        v = root / base / "verilog" / f"{name}.v"
        lef = root / base / "lef" / f"{name}.lef"
        doc = root / base / "doc" / f"{name}.txt"
        ports = verilog_ports(v, name)
        dtxt = doc.read_text(errors="replace")
        area = float(re.search(r"^Area.*=\s*([0-9.]+)\s*square microns", dtxt, re.M).group(1))
        t = re.search(r"\|\s*Clock to Data Out\s*\|\s*Delay\s*\|\s*Rising\s*\|\s*([0-9.e+-]+)\s*\|\s*([0-9.e+-]+)"
                      r"\s*\|\s*([0-9.e+-]+)", dtxt)
        lw, lh = lef_size(lef)
        assert ports["A_ADDR"][1] == (words - 1).bit_length() and ports["A_DIN"][1] == width, name
        views = [f for f in allf if Path(f).name.startswith(name)]
        two = kind == "2P"
        pfx = ["A", "B"] if two else ["A"]
        out.append({
            "id": mid, "define": f"SRAM_MACRO_IHP_{kind}_{words}X{width}", "macro_name": name,
            "family": "IHP_2P" if two else "IHP_1P",
            "status": "OPEN_SOURCE_AVAILABLE",
            "foundry": "IHP (open PDK)", "process": "SG13G2 (130 nm SiGe BiCMOS)",
            "column_mux": cmux,
            "data_width": width, "words": words, "address_width": ports["A_ADDR"][1],
            "port_topology": "2RW" if two else "1RW",
            "port_list": [{"dir": d, "name": n, "width": w} for n, (d, w) in ports.items()],
            "read_latency_cycles": 1,
            "write_mask": {"granularity_bits": 1, "mask_bits": ports["A_BM"][1], "polarity": "active_high",
                           "pin": "/".join(p + "_BM" for p in pfx)},
            "clock": {"pins": [p + "_CLK" for p in pfx], "polarity": "rising"},
            "chip_enable": {"pin": "/".join(p + "_MEN" for p in pfx), "polarity": "active_high"},
            "write_enable": {"pin": "/".join(p + "_WEN" for p in pfx), "polarity": "active_high"},
            "read_enable": {"pin": "/".join(p + "_REN" for p in pfx), "polarity": "active_high"},
            "sleep_retention": {"supported": False, "notes": "MEN low deactivates the memory; no retention pin"},
            "output_hold": "HOLDS: DOUT is a register updated only by read or write-through (core model)",
            "collision": {"port0_read_during_write": "WEN=1 and REN=1 is a defined write-through",
                          "cross_port_same_address": ("UNDEFINED: datasheet 'Both ports operate independently from "
                                                      "each other, there is no conflict handling included'")
                          if two else "not applicable (single port)"},
            "supply_pins": ["VDD", "VSS", "VDDARRAY"],
            "test_pins": [f"{p}_BIST_{s}" for p in pfx for s in ("CLK", "EN", "MEN", "WEN", "REN", "ADDR", "DIN", "BM")],
            "tie_offs": {f"{p}_DLY": 1 for p in pfx},
            "views": {
                "verilog_model": rel(v, root),
                "liberty": [f for f in views if f.endswith(".lib")],
                "lef": rel(lef, root),
                "gds": [f for f in views if f.endswith(".gds")],
                "cdl": [f for f in views if f.endswith(".cdl")],
                "datasheet": rel(doc, root),
            },
            "physical": {"width_um": lw, "height_um": lh, "area_um2": area, "source": rel(doc, root)},
            "timing": {"source": rel(doc, root),
                       "clock_to_dout_rise_ns": {"wc_1d08V_125C": float(t.group(1)), "bc_1d32V_m55C": float(t.group(2)),
                                                 "tc_1d20V_25C": float(t.group(3))}},
            "license": "Apache-2.0", "license_file": "LICENSE",
            "access": "public download, no NDA",
            "silicon_status": "not established by this library (no silicon or FPGA measurement performed)",
            "constraints": [
                "*_DLY must be tied to 1 (datasheet: MANDATORY)",
                "one cycle before and after *_BIST_EN changes no access may be issued (datasheet); the library "
                "ties *_BIST_EN to 0 and tests through its own test mux",
            ] + (["same-address accesses from A and B in one cycle must not be issued when either writes"] if two else []),
            "pin_map": {"clk": " ,".join(p + "_CLK" for p in pfx), "ce": "*_MEN", "we": "*_WEN",
                        "re": "*_REN = ce & ~we (write-through never used)",
                        "wmask[lane]": "*_BM[bit] = lane mask expanded to bits", "addr": "*_ADDR",
                        "wdata": "*_DIN", "rdata": "*_DOUT",
                        "tied": "*_DLY=1, *_BIST_EN=0, other *_BIST_* = 0"},
            "provenance": {"repo": IHP_REPO, "commit": head,
                           "files": {rel(p, root): sha256(p) for p in (v, lef, doc, lic)}},
        })
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ext", required=True, type=Path, help="directory with the pinned sparse clones")
    ap.add_argument("--out", default=Path(__file__).resolve().parents[2] / "manifests", type=Path)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    mans = build_sky130(a.ext / "sky130_sram_macros") + build_gf180(a.ext / "gf180_sram") + build_ihp(a.ext / "ihp")
    for m in mans:
        m = {"schema": "silicaflux-sramlib/macro-manifest/1", **m}
        (a.out / f"{m['macro_name']}.json").write_text(json.dumps(m, indent=2) + "\n")
    print(f"wrote {len(mans)} manifests to {a.out}")


if __name__ == "__main__":
    main()
