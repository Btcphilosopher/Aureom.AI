#!/usr/bin/env python3
"""Run the cocotb tests (tb/mem/cocotb) on Icarus Verilog via cocotb_tools.runner.

Each configuration is built and tested with a recorded seed; results (cocotb
results XML parsed) go to reports/mem/cocotb.{json,md}.  Skipped with a reason
when cocotb or Icarus is not installed.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, INC_DIRS, REPORTS, ROOT, RTL_FILES, provenance, write_json  # noqa: E402

CONFIGS = [
    ("sram_sp", "test_sram_sp_random", {"DATA_WIDTH": 32, "DEPTH": 100, "MASK_WIDTH": 4, "READ_LATENCY": 2, "ID_WIDTH": 3}),
    ("sram_sp", "test_sram_sp_random", {"DATA_WIDTH": 64, "DEPTH": 1024, "MASK_WIDTH": 8, "READ_LATENCY": 1, "ID_WIDTH": 2,
                                        "BACKEND": 1}),
    ("sram_bank_controller", "test_bank_controller_random",
     {"NUM_MASTERS": 3, "NUM_BANKS": 4, "BANK_DEPTH": 64, "DATA_WIDTH": 16, "ID_WIDTH": 4, "ADDR_WIDTH": 9}),
    ("sram_bank_controller", "test_bank_controller_random",
     {"NUM_MASTERS": 4, "NUM_BANKS": 8, "BANK_DEPTH": 32, "DATA_WIDTH": 32, "ID_WIDTH": 3, "ADDR_WIDTH": 9, "READ_LATENCY": 2}),
]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seed", type=int, default=20261105)
    a = ap.parse_args()
    recs = []
    try:
        from cocotb_tools.runner import get_runner
    except Exception as e:  # pragma: no cover
        recs.append({"result": "SKIP", "reason": f"cocotb not available: {e}"})
        get_runner = None
    if get_runner and not shutil.which("iverilog"):
        recs.append({"result": "SKIP", "reason": "iverilog not installed"})
        get_runner = None
    if get_runner:
        for i, (top, test, params) in enumerate(CONFIGS):
            bdir = BUILD / "cocotb" / f"{top}_{i}"
            if bdir.exists():
                shutil.rmtree(bdir)
            runner = get_runner("icarus")
            seed = a.seed + i
            rec = {"top": top, "test": test, "params": params, "seed": seed, "simulator": "icarus"}
            try:
                runner.build(sources=[str(f) for f in RTL_FILES], hdl_toplevel=top, includes=[str(d) for d in INC_DIRS],
                             parameters=params, defines={"SRAMLIB_POISON": 1}, build_dir=str(bdir),
                             timescale=("1ns", "1ps"), always=True)
                xml = runner.test(hdl_toplevel=top, test_module="test_sram_random", testcase=test,
                                  test_dir=str(ROOT / "tb/mem/cocotb"), build_dir=str(bdir), seed=seed,
                                  results_xml=str(bdir / "results.xml"))   # keep tb/ free of run outputs
                root = ET.parse(xml).getroot()
                cases = root.findall(".//testcase")
                fails = [c for c in cases if c.find("failure") is not None or c.find("error") is not None]
                log = (bdir / "results.xml").read_text() if (bdir / "results.xml").exists() else ""
                rec.update({"testcases": len(cases), "failures": len(fails),
                            "result": "PASS" if cases and not fails else "FAIL"})
                if fails:
                    rec["failure"] = ET.tostring(fails[0], encoding="unicode")[:1500]
            except Exception as e:
                rec.update({"result": "FAIL", "failure": repr(e)[:1500]})
            recs.append(rec)
            print(f"[cocotb] {rec['result']} {top} {params} seed={seed}", flush=True)
    res = {"provenance": provenance(), "records": recs}
    write_json(REPORTS / "cocotb.json", res)
    L = ["# cocotb results (Icarus Verilog)", "", "| top | params | seed | result |", "|---|---|---|---|"]
    for r in recs:
        L.append(f"| {r.get('top', '-')} | `{r.get('params', '')}` | {r.get('seed', '')} | {r['result']} {r.get('reason', '')} |")
    (REPORTS / "cocotb.md").write_text("\n".join(L) + "\n")
    return 0 if all(r["result"] in ("PASS", "SKIP") for r in recs) else 1


if __name__ == "__main__":
    sys.exit(main())
