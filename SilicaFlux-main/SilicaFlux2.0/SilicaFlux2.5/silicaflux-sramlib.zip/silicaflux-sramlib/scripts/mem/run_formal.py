#!/usr/bin/env python3
"""Formal checks of the SRAM library protocol invariants (Yosys + ABC).

Flow per job (SymbiYosys is not installed; this is the same AIGER route as
its `abc` engines):
  yosys : read_verilog -formal (-DSRAMLIB_ASSERT: embedded RTL checkers on);
          prep; flatten; memory_map; async2sync; setundef -anyseq; dffunmap;
          techmap; abc -g AND; write_aiger -zinit (uninitialised state elements
          get free initial values through extra inputs)
  abc   : bmc3 -F N  -> bounded proof of every assertion to depth N
          pdr        -> attempt at an unbounded proof (time-limited)
  cover : the same harness with -DFV_COVER turns every cover target into
          assert(!target); bmc3 must FIND it (proves the properties are not
          vacuous: the interesting scenario is reachable under the assumptions)
The SMT route (yosys-smtbmc) was evaluated and rejected in this environment:
Ubuntu's boolector 1.5 build aborts in smtbmc's incremental mode and z3 4.8.12
did not finish depth 4 within 5 minutes.  Results apply to the small listed
parameterisations; reports/mem/formal.{json,md}.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, RTL, provenance, run, write_json  # noqa: E402

FORMAL = ROOT / "formal/mem"
SRC = ([RTL / "backends/generic/sram_generic_1rw.sv", RTL / "backends/generic/sram_generic_1r1w.sv",
        RTL / "backends/generic/sram_generic_2rw.sv", RTL / "sram_backend_1rw.sv", RTL / "sram_backend_1r1w.sv",
        RTL / "sram_backend_2rw.sv", RTL / "sram_rsp_path.sv", RTL / "sram_sp.sv", RTL / "sram_1r1w.sv",
        RTL / "sram_tdp.sv", RTL / "sram_bank_controller.sv"])

JOBS = [
    # name, top, harness, params, depth
    ("sram_sp lat2 fifo3 depth5 (non-pow2)", "fv_sram_sp", "fv_sram_sp.sv", {"LAT": 2, "FIFO": 3}, 20),
    ("sram_sp lat1 fifo1 posted writes", "fv_sram_sp", "fv_sram_sp.sv", {"LAT": 1, "FIFO": 1, "WACK": 0}, 20),
    ("sram_sp lat1 no-backpressure mode", "fv_sram_sp", "fv_sram_sp.sv", {"LAT": 1, "FIFO": 0}, 20),
    ("sram_1r1w STALL", "fv_sram_1r1w", "fv_sram_1r1w.sv", {"COLLISION": 0}, 20),
    ("sram_1r1w READ_OLD", "fv_sram_1r1w", "fv_sram_1r1w.sv", {"COLLISION": 1}, 20),
    ("sram_1r1w FORBID", "fv_sram_1r1w", "fv_sram_1r1w.sv", {"COLLISION": 2}, 20),
    ("sram_tdp STALL", "fv_sram_tdp", "fv_sram_tdp.sv", {}, 20),
    ("sram_bank_controller 2x2 lat1", "fv_bank_ctrl", "fv_bank_ctrl.sv", {}, 16),
    ("sram_bank_controller 2x2 lat2", "fv_bank_ctrl", "fv_bank_ctrl.sv", {"LAT": 2, "FIFO": 3}, 16),
]


FLOW = ("prep -top {top}; flatten; memory_map; opt -fast; async2sync; chformal -remove -cover; "
        "setundef -anyseq; opt -keepdc -fast -noff; delete -output; dffunmap; techmap; opt -fast -noff; "
        "abc -g AND; opt_clean; write_aiger -I -B -zinit -map {aim} {aig}")


def export_aig(top: str, harness: str, params: dict, aig: Path, cover: bool) -> tuple[Path, dict]:
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    defs = "-DSYNTHESIS " + ("-DFV_COVER" if cover else "-DSRAMLIB_ASSERT")
    reads = " ".join(str(f) for f in SRC + [FORMAL / harness])
    ys = (f"read_verilog -formal -sv {defs} -I{RTL} -I{RTL / 'backends/asic'} -I{FORMAL} {reads}; "
          + (f"chparam {chp} {top}; " if chp else "")
          + FLOW.format(top=top, aim=aig.with_suffix(".aim"), aig=aig))
    return aig, run(["yosys", "-q", "-p", ys], cwd=aig.parent, timeout=1800)


def abc(aig: Path, cmd: str, timeout: int) -> dict:
    return run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; {cmd}"], cwd=aig.parent, timeout=timeout)


def abc_status(out: str, depth: int) -> str:
    m = re.search(r"was asserted in frame (\d+)", out)
    if m:
        return f"FAILED at frame {m.group(1)}"
    if re.search(r"No output asserted in (\d+) frames", out):
        return f"PASSED ({depth} frames)"
    return "UNKNOWN"


def pdr_status(out: str) -> str:
    if "Property proved" in out:
        return "PROVED"
    if "was asserted in frame" in out:
        return "FAILED"
    return "UNDECIDED (time limit)"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pdr-secs", type=int, default=300)
    ap.add_argument("--quick", action="store_true", help="halve the BMC depths")
    ap.add_argument("--no-induction", action="store_true", help="skip the PDR (unbounded) attempt")
    a = ap.parse_args()
    recs = []
    for name, top, harness, params, depth in JOBS:
        if a.quick:
            depth = max(8, depth // 2)
        d = BUILD / "formal" / re.sub(r"\W+", "_", name)
        d.mkdir(parents=True, exist_ok=True)
        rec = {"name": name, "top": top, "harness": f"formal/mem/{harness}", "params": params, "depth": depth,
               "engine": "abc bmc3 / pdr"}
        aig_p, yp = export_aig(top, harness, params, d / "prop.aig", cover=False)
        aig_c, yc = export_aig(top, harness, params, d / "cover.aig", cover=True)
        rec["yosys_cmd"] = yp["cmd"]
        if yp["rc"] != 0 or yc["rc"] != 0:
            rec.update({"bmc": "ELAB_ERROR", "result": "FAIL", "log": (yp["out"] + yc["out"])[-2000:]})
            recs.append(rec)
            print(f"[formal] {name}: elaboration failed\n{rec['log'][-800:]}")
            continue
        b = abc(aig_p, f"bmc3 -F {depth}", 3600)
        rec.update({"bmc": abc_status(b["out"], depth), "bmc_secs": b["secs"], "bmc_cmd": b["cmd"]})
        c = abc(aig_c, f"bmc3 -F {depth}", 3600)
        cs = abc_status(c["out"], depth)
        rec.update({"cover": "REACHED" + cs.split("FAILED")[-1] if cs.startswith("FAILED") else "NOT REACHED",
                    "cover_secs": c["secs"]})
        if not a.no_induction:
            p = abc(aig_p, f"pdr -T {a.pdr_secs}", a.pdr_secs + 120)
            rec.update({"pdr": pdr_status(p["out"]), "pdr_secs": p["secs"]})
        rec["claim"] = ("unbounded proof (PDR)" if rec.get("pdr") == "PROVED" and rec["bmc"].startswith("PASSED")
                        else f"bounded proof, depth {depth}" if rec["bmc"].startswith("PASSED") else "property violated")
        rec["result"] = "PASS" if rec["bmc"].startswith("PASSED") and rec["cover"].startswith("REACHED") else "FAIL"
        if rec["result"] != "PASS":
            rec["bmc_log"] = b["out"][-2000:]
        print(f"[formal] {name}: bmc={rec['bmc']} cover={rec['cover']} pdr={rec.get('pdr', '-')} "
              f"({rec['bmc_secs']}s)", flush=True)
        recs.append(rec)
    res = {"provenance": provenance(), "jobs": recs}
    write_json(REPORTS / "formal.json", res)
    L = ["# Formal verification report", "",
         "Engine: Yosys `read_verilog -formal` -> AIGER -> ABC (`bmc3`, `pdr`).  BMC proves every assertion",
         "(embedded RTL checkers + harness end-to-end properties) for ALL input sequences up to the given depth",
         "from reset under the harness assumptions; the cover run shows the tracked scenario is reachable, so the",
         "proof is not vacuous; PDR attempts an unbounded proof within a time limit.  Results hold for the listed",
         "small parameterisations only; larger configurations are covered by simulation.", "",
         "| job | params | depth | BMC | cover (non-vacuity) | PDR | claim | BMC secs |", "|---|---|---|---|---|---|---|---|"]
    for r in recs:
        L.append(f"| {r['name']} | `{r['params']}` | {r['depth']} | {r.get('bmc')} | {r.get('cover')} | "
                 f"{r.get('pdr', '-')} | {r.get('claim', '')} | {r.get('bmc_secs', '')} |")
    L += ["", f"Tools: yosys `{res['provenance']['tools']['yosys']}` (with its bundled yosys-abc)."]
    (REPORTS / "formal.md").write_text("\n".join(L) + "\n")
    return 0 if all(r["result"] == "PASS" for r in recs) else 1


if __name__ == "__main__":
    sys.exit(main())
