"""Shared helpers for the SilicaFlux SRAM library scripts: paths, file lists,
tool versions and provenance records (git commit, tree hash, commands, exit
codes).  Every report written by the scripts embeds `provenance()`."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RTL = ROOT / "rtl/mem"
TB = ROOT / "tb/mem"
BUILD = ROOT / "build"
REPORTS = ROOT / "reports/mem"

INC_DIRS = [RTL, RTL / "backends/asic", TB]

RTL_FILES = (sorted((RTL / "backends/generic").glob("*.sv")) + sorted((RTL / "backends/fpga").glob("*.sv"))
             + [RTL / "backends/asic/sram_asic_array.sv"] + sorted((RTL / "backends/asic").glob("sram_leaf_*.sv"))
             + sorted(RTL.glob("sram_*.sv")))
STUBS = [RTL / "backends/asic/stubs/sram_macro_blackboxes.sv"]

# where scripts/mem/fetch_open_macros.sh puts the pinned public macro sources
EXT_DEFAULT = Path(os.environ.get("SRAMLIB_EXT", ROOT / "build/ext"))


def run(cmd: list[str] | str, cwd: Path | None = None, timeout: int = 3600, env: dict | None = None) -> dict:
    """Run a command, return {cmd, rc, out, secs}; never raises on non-zero exit."""
    t0 = _dt.datetime.now()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout,
                           shell=isinstance(cmd, str), env=env)
        rc, out = p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        rc, out = -9, f"TIMEOUT after {timeout}s\n{e.stdout or ''}"
    return {"cmd": cmd if isinstance(cmd, str) else " ".join(str(c) for c in cmd), "rc": rc, "out": out,
            "secs": round((_dt.datetime.now() - t0).total_seconds(), 2)}


def tool_version(cmd: list[str]) -> str:
    if not shutil.which(cmd[0]):
        return "NOT INSTALLED"
    r = run(cmd, timeout=60)
    line = (r["out"].strip().splitlines() or ["?"])[0]
    return line.strip()


def tool_versions() -> dict:
    v = {
        "verilator": tool_version(["verilator", "--version"]),
        "iverilog": tool_version(["iverilog", "-V"]),
        "yosys": tool_version(["yosys", "-V"]),
        "yosys-smtbmc": "present" if shutil.which("yosys-smtbmc") else "NOT INSTALLED",
        "z3": tool_version(["z3", "--version"]),
        "boolector": tool_version(["boolector", "--version"]),
        "sby": tool_version(["sby", "--help"]) if shutil.which("sby") else "NOT INSTALLED",
        "openroad": tool_version(["openroad", "-version"]) if shutil.which("openroad") else "NOT INSTALLED",
        "vivado": "NOT INSTALLED" if not shutil.which("vivado") else tool_version(["vivado", "-version"]),
        "quartus_sh": "NOT INSTALLED" if not shutil.which("quartus_sh") else tool_version(["quartus_sh", "--version"]),
        "python": platform.python_version(),
    }
    try:
        import cocotb  # noqa: F401
        v["cocotb"] = cocotb.__version__
    except Exception:
        v["cocotb"] = "NOT INSTALLED"
    return v


def tree_hash(paths: list[Path] | None = None) -> str:
    """sha256 over the library sources (rtl, tb, formal, scripts, manifests, Makefile)."""
    h = hashlib.sha256()
    roots = paths or [ROOT / d for d in ("rtl", "tb", "formal", "scripts", "manifests", "synth", "integration")] + [ROOT / "Makefile"]
    files: list[Path] = []
    for r in roots:
        if r.is_file():
            files.append(r)
        elif r.is_dir():
            files += [p for p in r.rglob("*") if p.is_file() and not ({"__pycache__", "sim_build"} & set(p.parts))
                      and p.name != "results.xml" and p.suffix != ".pyc"]   # run outputs are not sources
    for p in sorted(files):
        h.update(str(p.relative_to(ROOT)).encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def git_commit() -> dict:
    """Commit of the enclosing SilicaFlux/Aureom repository, if the library sits inside one."""
    out = {}
    for key, args in (("commit", ["rev-parse", "HEAD"]), ("branch", ["rev-parse", "--abbrev-ref", "HEAD"])):
        r = run(["git", "-C", str(ROOT), *args], timeout=30)
        out[key] = r["out"].strip() if r["rc"] == 0 else "not a git checkout"
    r = run(["git", "-C", str(ROOT), "status", "--porcelain", "--", "."], timeout=30)
    out["library_files_committed"] = (r["rc"] == 0 and r["out"].strip() == "")
    # the SilicaFlux checkout the library was developed / integrated against (when it lives outside it)
    ref = os.environ.get("SRAMLIB_REF_REPO")
    if ref:
        r1 = run(["git", "-C", ref, "rev-parse", "HEAD"], timeout=30)
        r2 = run(["git", "-C", ref, "status", "--porcelain"], timeout=30)
        out["reference_repo"] = {"path": ref, "commit": r1["out"].strip() if r1["rc"] == 0 else None,
                                 "clean": r2["rc"] == 0 and r2["out"].strip() == ""}
    return out


def provenance(extra: dict | None = None) -> dict:
    p = {
        "generated_utc": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "host": platform.platform(),
        "library_tree_sha256": tree_hash(),
        # design under test only (independent of docs/scripts edits)
        "design_sha256": tree_hash([ROOT / d for d in ("rtl", "tb", "formal", "manifests", "integration")]),
        "git": git_commit(),
        "tools": tool_versions(),
    }
    if extra:
        p.update(extra)
    return p


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=str) + "\n")
