# 00 — Repository evidence report (Phase 1)

Scope: `btcphilosopher/aureom.ai` at commit `e936758d5001a34dede816a6dceb2d2138f64753` (2026-11-05), branch
`claude/happy-edison-p5ge1q`.  Every statement below was checked in this session by reading the file or by
running a tool on it; tool results are quoted with the command that produced them.  Nothing was modified in the
repository.

## 1. What the repository is

The repository is a mixed archive (798 files) of many unrelated Aureom projects (zips, PDFs, images).  The
SilicaFlux material is:

| Location | Content |
|---|---|
| `SilicaFlux-main/` | README, 13 loose `.sf` HDL files, 16 design PDFs, nested zips (below) |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` | the "2.5" generation: 19 `.sf` HDL files, tools, more zips |
| `SilicaFlux-main/silicaflux.zip` | Gen-1 RTL as `.sv` (`silicaflux/rtl`, `tb`, `sim`, `synth`) |
| `SilicaFlux-main/**/silicaflux-memoryflow*.zip` | MemoryFlow v1 / v2 memory-subsystem toolkit (RTL + Python) |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-testcore.zip` | TestCore DFT/MBIST/JTAG infrastructure |
| other nested archives | `memory_cache_repo`, `RISC-V CPU`, `cpu_core`, `pipelined_cpu`, `soc_integration.tar.gz`, `formal verification`, `digital_lib`, `UVM_Inspired_Architecture`, `comm_protocols`, `dsp_arithmetic`, `Finite State Machines Library`, `silicaflux-powerlink`, `-twinlab`, `-transistorlab`, `-timinglab`, `silicafluxai`, `silicafluxbitcoinasic`, `SilicaFluxML` |

All archives were extracted to a scratch directory (630 HDL files: `.sv`, `.v`, `.sf`, `.svh`) and inventoried by
script.

## 2. What `.sf` means

`.sf` files are **plain SystemVerilog-2017 source with a renamed extension**.  Their headers say
`Language: Silica Flux-2017`; there is no SilicaFlux compiler, preprocessor or translator anywhere in the
repository.  Evidence: Verilator 5.020 parses them directly with `+1800-2017ext+sf`:

| File | Package needed | Result (`verilator --lint-only +1800-2017ext+sf`) |
|---|---|---|
| `SilicaFlux-main/memory_controller.sf` | `silicaflux_pkg (1).sf` (136 lines) | elaborates; 1 lint warning with `-Wall` |
| `SilicaFlux-main/tensor_unit.sf`, `alu.sf` | `silicaflux_pkg.sf` | elaborate |
| `SilicaFlux-main/fetch_unit.sf` | `sf_frontend_pkg.sf` | needs that package (not auto-found) |
| `SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf` | — | **fails**: line 93 uses `sf_axi_req_t`, defined in no package |

Note the two incompatible packages: `silicaflux_pkg.sf` (2,081 lines) and `silicaflux_pkg (1).sf` (136 lines);
`memory_controller.sf` only elaborates with the latter.

## 3. Top-level processor modules

| Generation | Module / file | Status (verified) |
|---|---|---|
| Gen-1 | `silicaflux_top` — `silicaflux.zip::silicaflux/rtl/silicaflux_top.sv` | **elaborates** (`verilator --lint-only -I<rtl> --top-module silicaflux_top`, exit 0) |
| Gen-2.5 | `silicaflux_top` — `SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf` | **does not elaborate**; of the 27 module types it instantiates, 25 are defined nowhere in the repository (`sf_core`, `sf_l2_cache`, `sf_llc_bank`, `sf_coh_xbar`, `sf_coh_mgr`, `sf_mem_fabric`, `sf_axi_edge`, `sf_dma_bridge`, `sf_tensor_engine`, `sf_vector_unit`, `sf_tlb_subsys`, `sf_dispatch_fabric`, …); `sf_clk_ctrl` exists only as a timing-constraint stub (`silicaflux-timinglab/reports/constraints/silicaflux_top/stub.v`), `sf_rst_sync` only in `silicaflux-powerlink/rtl/sf_sync.sv` |
| SilicaFlux-V | — | **documented only** (`SilicaFlux-V_ Reduced-ASIC Prototype Design.pdf`, `Process Node Comparison for SilicaFlux‑V.pdf`, `Physical Layout Strategy ….pdf`); no RTL top |

## 4. Memories in the SilicaFlux HDL

Search: every unpacked array whose name suggests storage, every `$readmem*`, and every known macro/primitive name
(`sky130_sram_*`, `gf180mcu_fd_ip_sram*`, `RM_IHPSG13*`, `DFFRAM*`, `RAMB*`, `altsyncram`, `xpm_memory*`,
`SB_RAM40_4K`, `SB_SPRAM256KA`).

| Memory | Source (file:line) | Organisation and access | Classification |
|---|---|---|---|
| Gen-1 tile scratchpad | `silicaflux.zip::rtl/memory_controller.sv:52` `logic [XLEN-1:0] sram [0:SRAM_DEPTH-1]` (256 × 32 b per tile, 4 tiles) | written from two processes (write-back port :87, FSM :129, vector bursts :213-216) and read up to four words per cycle (:192-195) — a multi-port flip-flop array | synthesizable RTL; **not mappable to a 1RW/1R1W macro without a controller redesign** |
| Gen-1 instruction memory | `silicaflux.zip::rtl/fetch_unit.sv:45` `imem [0:IMEM_DEPTH-1]` (1024 × 32 b) | write port `imem_wr_en` (:79-80), synchronous read `instr_reg <= imem[pc_reg]` (:92) | synthesizable; 1R1W-shaped (→ `sram_1r1w`) |
| Gen-1 register file | `silicaflux.zip::rtl/register_bank.sv:52` `vregs` (16 × 128 b) + 32 × 32 b | multi-read register file | flip-flops (not an SRAM candidate) |
| Gen-2.5 banked scratchpad | `SilicaFlux-main/memory_controller.sf:980` `sf_vword_t mem_q [BANK_DEPTH]` per bank (default 8 × 512 × 128 b = 64 KiB) + per-byte parity array `par_mem_q` (:1021) | single port per bank, per-byte enables, `SRAM_LATENCY` read pipeline, storage cleared through the port by an `INIT_ON_RESET` sweep (:544-553) | synthesizable; **macro-compatible** → integrated (see §7) |
| Gen-2.5 queues/buffers | `fetch_unit.sf` `fq_mem_q`, `tile_interface.sf` `txf_mem_q`/`rxf_mem_q`, `noc_interconnect.sf` router `mem [BUF_DEPTH]`, `scheduler.sf` IQ arrays | small FIFOs / CAM-like structures | flip-flops |
| Gen-2.5 bank decoder | `SilicaFlux2.0/SilicaFlux2.5/sram-decoder.sf` `sf_sram_bank_decode` | bank/row/offset decode helper | instantiated by nothing |
| MemoryFlow SRAM layer | `silicaflux-memoryflow-v2.0.0.zip::rtl/sram/sf_sram_1rw.sv`, `sf_sram_{1rw,1r1w,2rw}_inferred.sv`, `sf_sram_bank.sv` | inferred arrays + optional tiling onto `sf_macro_1rw_leaf` | the "macro" is a **generic behavioural stand-in** (`rtl/macro_stubs/sf_macro_1rw_leaf.sv`), not a foundry macro |
| TestCore MBIST | `silicaflux-testcore.zip::rtl/tc_mbist.sv`, `rtl/tc_mbist_collar.sv`; TB model `tb/models/tc_sram_model.sv` | March controller with memory registry; collar test bus `bist_active/sel/ce/we/addr/wdata → rdata` | synthesizable controller + collar; this library adopts the **same test-bus contract** |
| SilicaFlux-AI | `silicafluxai.zip::rtl/memory/sfx_sram_interface.sv` | 1RW, byte strobes, 1-cycle read, rvalid | standalone wrapper (not used by the SilicaFlux tops) |
| Other archives | `memory_cache_repo` (`sp_ram`, `dp_ram`, caches), `RISC-V CPU` / `cpu_core` / `pipelined_cpu` (`instr_mem`, `data_mem`), `soc_integration` (`soc_sram`, `boot_rom`) | several use **asynchronous reads** (`assign … = mem[…]`), `$readmemh` and zeroing `initial` loops | behavioural / FPGA-style; **not** SRAM-macro compatible |

**Instantiated memory macros: none.**  No foundry/compiler SRAM macro, FPGA RAM primitive or vendor RAM IP
is instantiated anywhere in the SilicaFlux HDL.

## 5. Interfaces and timing semantics found

* Gen-2.5 `memory_controller.sf`: valid/ready request and response channels per port (scalar, vector, burst),
  credit-reserved responses, fixed `SRAM_LATENCY`, in-order per port, flush/kill, parity exception.  Bank storage
  command `{en, we, row, be[16], wdata[128]}` (`mc_bank_cmd_t`, :320-327); read data consumed only at the
  metadata tail `SRAM_LATENCY` cycles after issue (:1123, :1143, :1169).
* Gen-1 `memory_controller.sv`: request/response FSM, one access at a time.
* TestCore collar: test bus as above; registry latency = macro latency + collar pipeline stages.

## 6. Existing verification and synthesis flows

| Flow | Location | Notes |
|---|---|---|
| Icarus simulation | `silicaflux.zip::sim/run_sim.sh` | Gen-1 testbenches |
| Vivado | `silicaflux.zip::synth/vivado/synth.tcl`, `silicaflux_arty.xdc` | Digilent Arty A7-100T, `xc7a100tcsg324-1`; the XDC comments E3 as "12 MHz" but constrains 10 ns |
| Quartus | `silicaflux.zip::synth/quartus/synth.tcl` | Cyclone V |
| MemoryFlow | `silicaflux-memoryflow-v2.0.0.zip` | pytest + Verilator + Yosys; `tb/silicaflux/tb_sf25_memctrl.sv` targets the real `memory_controller.sf` |
| TestCore | `silicaflux-testcore.zip` | Makefile, `scripts/regress.py`, SV TBs |
| Repo's own 2.5 TB | `SilicaFlux2.0/SilicaFlux2.5/tb_memory_controller.sf` | **interface drift**: written for a different DUT (word addressing, `mem_stall_i`, `trc_valid_o`); does not match `memory_controller.sf` |

Re-run here: MemoryFlow's `tb_sf25_memctrl.sv` on the unmodified `memory_controller.sf` + `silicaflux_pkg (1).sf`
passes, `MF_RESULT PASS errors=0 checks=150843` (Verilator 5.020).

## 7. Classification summary

| Class | Items |
|---|---|
| Existing synthesizable hardware | Gen-1 cluster (`silicaflux_top.sv` and units); Gen-2.5 `memory_controller.sf`, `tensor_unit.sf`, `alu.sf`, `register_bank.sf`, `vector_engine.sf`; MemoryFlow RTL; TestCore RTL |
| Behavioural / simulation-only memories | TestCore `tc_sram_model`, MemoryFlow `sf_macro_1rw_leaf` (behavioural) and `sf_extmem_model`; `$readmemh`/async-read memories in the auxiliary CPU/SoC archives |
| Missing implementations | 25 of 27 Gen-2.5 top-level submodules incl. L2/LLC, coherent fabric, DMA bridge, AXI edge; any DRAM controller/PHY; SilicaFlux-V RTL |
| Newly proposed modules (this library) | `rtl/mem/*` — see README "Files" |
| Foundry-dependent IP | SRAM macros: none present in the repository.  Open-PDK macros (SKY130, GF180MCU, IHP SG13G2) were fetched from their public repositories for this work (pinned commits in `manifests/`); commercial 130/65/28 nm compilers: **not available** |

## 8. Branch

The brief asks for a branch `feature/silicaflux-sram-library`.  Per the requester's explicit instruction for this
task ("make as a zip, do not commit to github") no branch was created and nothing was committed or pushed; the
library is delivered as `silicaflux-sramlib.zip`, intended to be unpacked at `SilicaFlux-main/silicaflux-sramlib/`
next to the other SilicaFlux sub-projects.
