# 09 — Status, outstanding dependencies and next actions

Numbers below are from the final regression run recorded in `reports/mem/SUMMARY.md` (design sha256 and tool
versions are in every JSON report).  Where this page and a report disagree, the report is authoritative.

## 1. Acceptance criteria

| Criterion (brief §17) | Status | Evidence |
|---|---|---|
| All selected source modules elaborate | **met** | `lint` suite: 20 Verilator `-Wall` elaborations (every module, GENERIC / FPGA / each open-PDK family, the example top), 22 negative elaboration tests, 5 Icarus elaborations — 47/47 PASS |
| Generic single-port and 1R1W implementations are synthesizable | **met** | `synth.md` "Generic synthesis": Yosys `synth` of `sram_sp`, `sram_1r1w`, `sram_tdp`, `sram_bank_controller`, MBIST blocks |
| No unintended latches | **met** | `synth.md`: `$dlatch` count 0 for every generic job (checked, not just reported) |
| Read latency and write semantics documented | **met** | `01_interface_spec.md` §4-§8 (latency, ordering, write-ack/posted writes, collisions, init) |
| All supported configurations pass self-checking functional tests | **met for the simulated set** | `sim` suite 53/53 configurations (2,731,959 scoreboard checks); `xsim` 5/5 configurations with byte-identical Verilator/Icarus traces; cocotb 4/4; mutation suite 10/10 bugs detected.  Not every Cartesian parameter combination is simulated (doc 05) |
| Byte-write masking works | **met** | `tb_sram_sp` P6 (all 2^MW masks for MW ≤ 8), bit masks and 9-bit lanes in the sweep, masks in every random TB; mutant "ignored write mask" killed |
| Simultaneous-access conditions verified | **met** | `tb_sram_1r1w` (all three policies), `tb_sram_tdp` (write/write and read/write), formal STALL proofs incl. starvation bound |
| Banking does not lose or misroute transactions | **met (bounded)** | banking TB scoreboard (per-master ID/order/data), embedded misroute/duplicate assertions, formal 2×2 BMC depth 16, mutants "misrouted bank data" and "aliased bank decode" killed |
| FPGA inference demonstrated if tools available | **met with Yosys; vendor tools not available** | `synth.md` "FPGA block-RAM inference" (xc7 RAMB36E1/RAMB18E1, iCE40 SB_RAM40_4K, ECP5 DP16KD); no Vivado/Quartus, no board run |
| Macro adapters validated against actual models or marked pending | **met** | `equiv` suite: 11/11 configurations trace-identical against the SKY130, GF180MCU and IHP SG13G2 vendor Verilog models; commercial 130/65/28 nm manifests `PENDING_NO_MACRO` (selecting them is an elaboration error) |
| MBIST access has a documented and tested integration contract | **met** | `04_mbist.md`; `tb_sram_mbist` (7 fault models, exact first-failure address/element), test-port hand-over in every wrapper TB, MBIST in the example subsystem |
| Every unsupported mode fails safely | **met** | negative elaboration tests in the `lint` suite (each must fail with its message): ASIC without macro, commercial placeholder, READ_OLD on ASIC, 2RW on non-2P macro, 1R1W on 1RW macro, latency below macro latency, unrepresentable lane width, INIT_FILE outside FPGA, illegal depth/width |
| No unlicensed proprietary macro source | **met** | only port-list stubs and manifests; open-PDK vendor files fetched on demand (Apache-2.0) and not redistributed |
| CI can reproduce the results | **prepared, not exercised** | `make mem-all` reproduces every report locally; `ci/github-actions-sramlib.yml` is a template — not installed or run (delivery as a zip, no commits) |

## 2. Outstanding macro and PDK dependencies

| Item | What exists | What is missing / blocking |
|---|---|---|
| SKY130 (OpenRAM) | 3 macros, 1RW1R only, ≤ 2 KiB, byte mask, output not held (handled) | larger or single-port macros (would have to be generated with OpenRAM — not done); per-corner timing used in a flow; bit-mask variants (parity lanes cannot be stored, see doc 07) |
| GF180MCU | 4 macros, 8 bit × 64…512, bit mask, `Tcyc` per corner | wide/deep macros — tiling to SilicaFlux-V sizes needs hundreds of instances (doc 08) |
| IHP SG13G2 | 18 × 1P + 9 × 2P adapted, bit mask, BIST pins present | Liberty-based STA, LEF placement with halos, power-pin connection, use of the macro BIST mux (functional pins used today), the three non-BIST variants not adapted |
| Commercial 130 / 65 / 28 nm | ID slots 90-92, integration procedure (doc 02 §6) | the compiler outputs themselves (licence/NDA), then manifest + leaf family |
| FPGA | Yosys inference evidence, Arty A7 self-test top + XDC | vendor synthesis/timing (Vivado), a board run with captured UART output |
| Tools | Verilator 5.020, Icarus 12, Yosys 0.33 + ABC, cocotb 2.1 | SymbiYosys and a working SMT solver (unbounded proofs), OpenROAD (floorplan/STA), Vivado/Quartus |
| SilicaFlux sources | 2.5 `memory_controller.sf` (integrated as a patched copy) | SilicaFlux-V RTL (not in the repository); 2.5 `compute_tile.sf` does not elaborate as checked in (doc 00) |

## 3. Known limitations (not defects, but not claimed)

* Formal results are **bounded** (BMC depth 16-20) on small parameterisations; PDR attempts ended UNDECIDED within
  the time limit.  Larger configurations rely on simulation.
* No timing, power or silicon-area claims beyond macro-outline areas from the vendors' files (doc 08).
* MBIST demonstration controller: no production fault coverage, retention test, repair or ATPG interaction.
* Single clock domain only; no ECC; no sleep/retention control (none of the open macros has the pins).
* The SilicaFlux-V presets are illustrative, not confirmed architecture.
* Verilator 5.020 needed testbench workarounds (doc 05 "Issues found"); newer Verilator versions are untested.

## 4. Prioritised next engineering actions

| # | Priority | Action | Why / exit criterion |
|---|---|---|---|
| 1 | P0 | Review and apply `integration/silicaflux25/memory_controller.sf.patch` in the repository (with the one-line TB path change) | first real consumer of the library; exit: `make mem-integration` green in CI |
| 2 | P0 | Install `ci/github-actions-sramlib.yml`, pin the tool container | makes the regression reproducible on every change |
| 3 | P0 | Run the FPGA self-test on an Arty A7-100T with Vivado; archive timing/utilisation and the UART log | turns "inference demonstrated" into "board validated" |
| 4 | P0 | Decide the first-silicon PDK for SilicaFlux-V; if open, IHP SG13G2 (densest open macros, 1P + 2P): OpenROAD floorplan of `sfv_memory_subsystem_example` with the IHP LEF/Liberty, power pins and halos, STA at the target clock | first physical evidence (area incl. halos, timing, routability) |
| 5 | P1 | Parse Liberty (SKY130, IHP) into the manifests: min cycle time, setup/hold, clock-to-out per corner | enables frequency-aware `sram_analysis.py plan` |
| 6 | P1 | Optional SECDED layer (`sram_ecc` wrapper over any backend), scrub hook, error counters | reliability for large SRAM; also solves SKY130 parity-lane storage |
| 7 | P1 | Connect `sram_mbist_adapter` ports to TestCore `tc_mbist`; IHP leaves: drive the macro BIST mux (`*_BIST_EN` with the one-idle-cycle rule) | production-style test access |
| 8 | P1 | Gen-1 `fetch_unit` IMEM → `sram_1r1w`; Gen-1 tile memory → `sram_bank_controller` (doc 07 §3) | consistent memories across the family |
| 9 | P1 | SymbiYosys + a working SMT solver: k-induction / unbounded proofs of the wrappers and bank controller, wider parameter sets | removes the "bounded" qualifier |
| 10 | P2 | Commercial compiler engagement (130/65/28 nm): obtain outputs under licence, fill the PENDING manifests, add the leaf family, run `mem-equiv` / `mem-synth` | only path to those nodes |
| 11 | P2 | Bank-controller extensions: XOR/hashed interleave (stride-by-B traffic serialises today), weighted/QoS arbitration, per-bank clock gating | measured conflict behaviour in `analysis.md` |
| 12 | P2 | Dual-clock 1R1W (CDC-safe) for DMA/IO buffers; sleep/retention control where a chosen macro provides it | features absent from the open macros |
