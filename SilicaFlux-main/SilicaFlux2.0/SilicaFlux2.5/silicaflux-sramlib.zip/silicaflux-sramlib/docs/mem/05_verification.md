# 05 — Verification

## Environment

Verilator 5.020 (primary simulator, `--timing --assert`, `--x-assign/--x-initial unique`), Icarus Verilog 12
(4-state; cross-simulator checks, vendor macro models, cocotb), cocotb 2.1, Yosys 0.33 + bundled ABC (formal,
synthesis).  Not available: SymbiYosys (could not be installed), a working SMT back end for `yosys-smtbmc`
(Ubuntu boolector 1.5 aborts in incremental mode; z3 4.8.12 did not finish depth 4 in 5 minutes), OpenROAD,
Vivado, Quartus.  Tool versions are embedded in every report.

## Independent reference models

* SystemVerilog testbenches (`tb/mem/*.sv`): procedural reference array with a per-bit *known* mask (never-written
  bits are not compared), expected-response queues per port/master, explicit same-cycle ordering rules.
* cocotb (`tb/mem/cocotb/test_sram_random.py`): a separate Python scoreboard (dict model), X-aware.
* Stimulus uses a built-in xorshift PRNG seeded by `+seed`, so a seed reproduces exactly and Verilator and Icarus
  produce **byte-identical request/response traces** (checked by the `xsim` suite).  All seeds are recorded.

## Coverage of the required tests

| # | Required test | Where |
|---|---|---|
| 1 | reset and initialisation semantics | `tb_sram_sp` P0 (ready/valid low in reset and the cycle after); all TBs check reset; init policy §9 of the spec |
| 2 | single word write/read | `tb_sram_sp` P1 |
| 3 | consecutive writes | `tb_sram_sp` P2 (back-to-back throughput asserted) |
| 4 | consecutive reads | `tb_sram_sp` P3 (exact latency asserted) |
| 5 | alternating reads/writes | `tb_sram_sp` P4 |
| 6 | random addresses | `tb_sram_sp` P8, all other TBs, cocotb |
| 7 | walking one / walking zero | `tb_sram_sp` P5; FPGA self-test passes 3-4 |
| 8 | all-zero / all-one | `tb_sram_sp` P5; FPGA self-test passes 0-1 |
| 9 | byte-enable combinations | `tb_sram_sp` P6 (all 2^MW masks for MW ≤ 8, walking lane + random otherwise); bit masks (MW = DW) and 9-bit lanes in the sweep |
| 10 | address boundaries | `tb_sram_sp` P7 (0, 1, DEPTH-2, DEPTH-1) |
| 11 | invalid addresses | `tb_sram_sp` P7/P8 (non-power-of-two depths), 1R1W/2RW/banking random invalid traffic, misaligned byte addresses |
| 12 | multiple-bank access | `tb_sram_banking` (1, 2, 4, 8 banks; 1-8 masters) |
| 13 | simultaneous read/write | `tb_sram_1r1w` (dual-issue cycles counted and required), `tb_sram_tdp` |
| 14 | collision scenarios | `tb_sram_1r1w` all three policies (hot-address stress), `tb_sram_tdp` write/write and read/write conflicts; formal STALL proofs |
| 15 | backpressure | all handshake TBs at 0/30/70 % `rsp_ready` low, payload stability checked every stalled cycle |
| 16 | data retention | `tb_sram_sp` P10 (fill, 300 idle cycles, read back) |
| 17 | MBIST access + injected faults | `tb_sram_mbist` (7 fault models, exact first-failure address/element), test-port hand-over in every wrapper TB |
| 18 | parameter changes | sweep below |
| 19 | FPGA backend equivalence | FPGA backend in the sweep (`sram_sp`, `sram_1r1w`, `sram_tdp`, banking, cocotb) with the same checks; Yosys BRAM inference |
| 20 | generic vs macro-model equivalence | `equiv` suite: identical traces GENERIC vs vendor SKY130 / GF180 / IHP models |

## Assertions

Embedded in the RTL under `SRAMLIB_ASSERT` (simulation and formal), plus harness properties:

| Property | Where |
|---|---|
| no accepted transaction silently dropped | response-path credit/occupancy invariants; TB drain checks; formal n-th-response tracking |
| no unsolicited read response | `sram_rsp_path` (`rsp_valid` with nothing outstanding) |
| stable response under backpressure | `sram_rsp_path` |
| correct response ordering / ID | formal harnesses (tracked transaction), TB scoreboards |
| no conflicting accesses to a single-port / 2RW / 1R1W array | `sram_1r1w` (STALL never issues same-address pair), `sram_tdp`, bank grant one-hot |
| valid address bounds | every wrapper (`array access beyond DEPTH`) |
| legal control combinations | test mode excludes functional accepts; `tst_ce` only with `tst_active`; `RSP_FIFO_DEPTH=0` requires `rsp_ready` |
| misrouting / duplication (banking) | owner pipeline == master response stage; at most one bank per master per cycle |
| master-side rules | `sram_if` (valid/payload held until ready); assumed in formal |

## Formal (`reports/mem/formal.md`)

Nine jobs (`sram_sp` ×3, `sram_1r1w` ×3 policies, `sram_tdp`, `sram_bank_controller` ×2) are proven by BMC to
depth 16-20 from reset for **all** input sequences under the master-rule assumptions, including every embedded
assertion and the end-to-end data/ID/order properties with a symbolic address, the STALL starvation bound and the
round-robin fairness bound.  Covers show the tracked scenarios are reachable (non-vacuous).  PDR (unbounded) is
attempted with a time limit and reported as such.  The proofs are for small widths/depths; the logic is fully
parameterised, and larger configurations are covered by simulation.

## Parameter sweep (`reports/mem/regression.md`, sim suite)

`sram_sp`: the full DATA_WIDTH {8,16,32,64,128} × DEPTH {64,256,1024,4096} grid (20 builds, latency cycling 1-3)
plus extra points (FPGA backend, bit masks, 9-bit lanes, non-power-of-two depths 100/257/300/1000/3000,
`RSP_FIFO_DEPTH` 0/1/5, posted writes).  `sram_1r1w`: 7 points (all policies, GENERIC/FPGA, widths 8-128,
latency 1-3).  `sram_tdp`: 4 points.  `sram_bank_controller`: 10 points covering 1, 2, 4 and 8 banks, 1-8 masters,
widths 8-128, word and byte addressing, both interleaves, both arbiters, FPGA backend, no-backpressure mode.
MBIST: 2 points.  FPGA self-test: 1.  Not every Cartesian combination is simulated; every module parameter
dimension is exercised at its extremes and at non-power-of-two values, and the formal proofs cover the protocol
logic independently of width and depth.

## Testbench sanity (mutation suite)

Ten deliberate RTL bugs (response reordering, credit off-by-one, ignored write mask, removed address check,
missing 1R1W stall, missing 2RW conflict stall, misrouted bank data, aliased bank decode, wrong March element, test
mode not blocking requests) are injected into copies of the RTL; each must make its testbench fail.  Results in
`reports/mem/regression.md` (mutants section).

## Issues found during verification

| Found by | Issue | Resolution |
|---|---|---|
| formal (`fv_sram_sp`) | an MBIST test address ≥ DEPTH (non-power-of-two) reached the array | test accesses are now gated by the same range check in `sram_sp`, `sram_1r1w`, `sram_tdp`, `sram_bank_controller` |
| cross-simulator traces | several testbench races (driving stimulus at a clock edge, polling the scoreboard at the monitor's edge, two RNG calls in one argument list, a short-circuited RNG call folded by one simulator) | testbench discipline: drive on the falling edge, poll on the falling edge, one RNG call per statement |
| cross-simulator traces | Verilator 5.020 evaluates a side-effecting function call on the right of `&&` / `?:` even when the left operand already decides the result (Icarus short-circuits), so the PRNG streams diverged | RNG calls never appear inside `&&`, `\|\|` or `?:`; they are hoisted into their own statements |
| embedded RTL assertion (`sram_generic_2rw`: same-address write on both ports) | with the stimulus driver written as an `initial forever` process, Verilator 5.020 `--timing` did not re-evaluate the TDP wrapper's combinational conflict detector after the process wrote the request signals (probe: `ad = 70/70`, write on B, `conflict = 0` one ns after the falling edge); Icarus with the same seed was correct.  The banking TB hit the analogous `rsp_valid dropped while rsp_ready was low` check | all TB drivers are clocked `always @(negedge clk)` blocks; the five cross-simulator configurations are trace-identical again.  The RTL was not changed — the raw-backend checker caught a simulator scheduling problem, not a design bug |
| vendor-model equivalence | GF180MCU model samples write inputs 100 ps after the clock; zero-delay adapter → hold race, corrupted writes | `SRAMLIB_VENDOR_MODELS` adds a 1 ns input delay in the leaves (simulation only, doc 02 §5); all 11 equivalence configurations trace-identical |
| regression runner | a cached Verilator binary was reused after a testbench edit (cache keyed on parameters only) | cache key includes a SHA-256 of `rtl/` and `tb/` |
| Yosys 0.33 | `int'()` casts unsupported; package references in parameter lists unsupported; internal assert when unpacked-array elements connect to instance ports; default-parameter elaboration of deliberately-fatal modules | RTL uses sized casts, a `define header, flat vectors on ports; synthesis reads with `-defer` |
| review | bank-controller range check compared against a truncated constant when `ADDR_WIDTH = log2(TOTAL)` | compare with an (ADDR_WIDTH+1)-bit constant |
