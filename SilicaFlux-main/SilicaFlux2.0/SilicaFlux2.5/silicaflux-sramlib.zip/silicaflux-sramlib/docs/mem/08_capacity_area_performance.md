# 08 — Capacity, area and performance (evidence-only)

Generated numbers live in `reports/mem/analysis.md` / `.json` (`make mem-bench`), `reports/mem/synth.md`
(`make mem-synth`) and `reports/mem/regression.md`.  This page explains what they do and do not show.

## 1. Sources and rules

| Quantity | Source | Not used |
|---|---|---|
| macro area | manifest `physical` (SKY130: LEF `SIZE`; GF180MCU: `specs/6_Physical_Dimensions.csv`; IHP: datasheet `Area`) | estimates, scaling rules, memoryflow's area model |
| macro clock | only GF180MCU publishes a minimum cycle time per corner in a form extracted to the manifests (`Tcyc`, 3.3 V typical: 9.24 ns for 512×8) | SKY130 / IHP clock rates (Liberty not parsed; IHP datasheet gives clock-to-out only) |
| bandwidth | words/cycle measured by the self-checking banking testbench; peak = min(masters, banks) × word | any MHz figure for logic |
| switching activity | bank-input Hamming distance per access (testbench) | power numbers |
| FPGA capacity | Yosys `synth_xilinx` RAMB36E1/RAMB18E1 counts | vendor timing/utilisation reports (no Vivado) |
| commercial nodes | nothing — manifests are PENDING | any 65/28 nm figure |

Macro-only area excludes placement halos, power rings/straps, routing channels, the library's glue logic (reported
separately by `make mem-synth` as generic gate counts), ECC check bits and redundancy.  It is a **lower bound** on
the silicon area of the SRAM, not a die-area estimate.

## 2. Aggregate capacity 32-512 KiB

`analysis.md` tabulates, for 32/64/128/256/512 KiB × word width 32/64/128 × 1/2/4/8 banks, the best open macro per
family (instances, bit utilisation, macro area) and the peak bytes/cycle.  Readings (from that table):

* **IHP SG13G2** has the densest open macros of the three families: 32 KiB = 2 × `RM_IHPSG13_1P_2048x64`
  (128-bit words, 0.98 mm² macro area) or 4 × `RM_IHPSG13_1P_4096x16` (32-bit words, 1.03 mm²); 512 KiB = 32
  instances / 15.7 mm² (128-bit) or 64 instances / 16.5 mm² (32-bit).
* **SKY130 OpenRAM**: the largest published macro is 2 KiB; 32 KiB = 16 instances / 4.55 mm², 512 KiB = 256
  instances / 72.8 mm².  Only 1RW1R macros are published, so 1RW use wastes the second port.
* **GF180MCU**: only 8-bit-wide macros up to 512 words (512 B); 32 KiB = 64 instances / 13.4 mm², 512 KiB = 1,024
  instances / 214 mm² — GF180 suits small control memories only.
* **FPGA (xc7)**: Yosys maps 512 KiB of `sram_sp` to 128 RAMB36E1.  Whether a given device has that many is a
  device-datasheet question; not verified here.
* **Commercial 130/65/28 nm**: unknown until compiler data exists.  No statement about economic feasibility is
  made for any capacity.

## 3. SilicaFlux-V presets

The illustrative presets (`rtl/mem/sram_presets.svh`) are tiled per family in `analysis.md` ("SilicaFlux-V
illustrative presets").  All four presets total 84 KiB: IHP 1P 7 instances / 2.62 mm² of macro area; SKY130 42
instances / 11.95 mm²; GF180 168 instances / 35.2 mm².

## 4. Banking performance

`analysis.md` lists, for 32-bit (latency 1) and 128-bit (latency 2) words over 1/2/4/8 banks and 4 masters, the
sustained words/cycle, conflict rate, average/maximum latency and activity proxy for CPU, vector, tensor-tile, DMA,
mixed and stride-by-B traffic.  Patterns to expect (and observed): with low-order interleave, unit-stride vector
and DMA streams approach the min(masters, banks) peak; random CPU-like traffic loses a large fraction to conflicts
until banks ≥ masters; stride-by-B traffic serialises on one bank regardless of bank count; latency rises above
`READ_LATENCY` only through bank conflicts' indirect effect on credits and through response backpressure.

## 5. Library glue cost

`synth.md` reports generic-gate counts for the wrappers, the bank controller and the ASIC tiling glue (e.g. the
16-macro SKY130 32×4096 array: ~1.4 k generic cells including the 16-way registered read mux).  These are
technology-independent Yosys cells, not a standard-cell area.
