// =============================================================================
// SilicaFlux SRAM Wrapper Library :: tb_sram_banking   (self-checking + benchmark)
// NUM_MASTERS masters on sram_bank_controller.  Every response is checked
// against one global reference memory (data on known bits, error flag,
// write-ack flag) and against the master's expected-ID queue (order and
// identity: a response routed to the wrong master or out of order fails).
//
// Workloads (+wl=<n>, default runs the regression sequence 0..6):
//   0 random     uniform addresses, 40 % writes, random masks
//   1 cpu        per-master sequential word stream, 30 % writes, short gaps
//   2 vector     per-master unit-stride streaming, back-to-back
//   3 tensor     tile loads: TILE x TILE words from a ROWLEN-wide matrix
//   4 dma        64-word bursts, alternating read and write bursts
//   5 mixed      master 0 cpu, 1 vector, 2 tensor, 3+ dma
//   6 stride     every master strides by NUM_BANKS (worst case: one bank)
// Per workload: SRAM_METRIC line with accepted words/cycle, bank-conflict
// rate, average and max response latency and a switching-activity proxy
// (Hamming distance of consecutive bank input words per issued access).
// Plusargs: +seed=<n> +ncyc=<n> +wl=<n> +bp=<pct> +errpct=<pct>
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sram_banking;
  parameter int NM      = 4;
  parameter int NB      = 4;
  parameter int DW      = 32;
  parameter int MW      = 4;
  parameter int BD      = 256;
  parameter int LAT     = 1;
  parameter int BACKEND = 0;
  parameter int MACRO   = 0;
  parameter int ARB     = 0;
  parameter int ILV     = 0;
  parameter int AMODE   = 0;
  parameter int FIFO    = LAT + 1;
  parameter int WACK    = 1;
  parameter int IDW     = 6;
  localparam int TOTAL  = NB * BD;
  localparam int BOFF   = (AMODE == 1 && DW >= 16) ? $clog2(DW / 8) : 0;
  localparam int AWD    = $clog2(TOTAL) + BOFF + 1;     // one spare bit: out-of-range addresses
  localparam int LW     = DW / MW;
  localparam int QD     = 4096;
  localparam int RAW    = (BD > 1) ? $clog2(BD) : 1;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;

  logic [NM-1:0]     req_valid = '0, req_we = '0, rsp_ready = '1;
  logic [NM*AWD-1:0] req_addr = '0;
  logic [NM*DW-1:0]  req_wdata = '0;
  logic [NM*MW-1:0]  req_wmask = '0;
  logic [NM*IDW-1:0] req_id = '0;
  logic [NM-1:0]     req_ready, rsp_valid, rsp_err, rsp_we, stall_conflict;
  logic [NM*DW-1:0]  rsp_rdata;
  logic [NM*IDW-1:0] rsp_id;
  logic              busy;
  logic              tst_active = 0, tst_ce = 0, tst_we = 0;
  logic [NB-1:0]     tst_sel = '0;
  logic [RAW-1:0]    tst_addr = '0;
  logic [DW-1:0]     tst_wdata = '0;
  logic [NB*DW-1:0]  tst_rdata;

  sram_bank_controller #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .MASK_WIDTH(MW), .BANK_DEPTH(BD), .READ_LATENCY(LAT),
    .BACKEND(BACKEND), .MACRO(MACRO), .ARB(ARB), .INTERLEAVE(ILV), .ADDR_MODE(AMODE), .ID_WIDTH(IDW),
    .RSP_FIFO_DEPTH(FIFO), .WRITE_ACK(WACK), .TEST_EN(1), .ADDR_WIDTH(AWD)
  ) dut (
    .clk, .rst_n,
    .m_req_valid(req_valid), .m_req_ready(req_ready), .m_req_we(req_we), .m_req_addr(req_addr),
    .m_req_wdata(req_wdata), .m_req_wmask(req_wmask), .m_req_id(req_id),
    .m_rsp_valid(rsp_valid), .m_rsp_ready(rsp_ready), .m_rsp_rdata(rsp_rdata), .m_rsp_err(rsp_err),
    .m_rsp_we(rsp_we), .m_rsp_id(rsp_id), .m_stall_conflict(stall_conflict),
    .tst_active, .tst_sel, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy
  );

  // ------------------------------------------------------------ reference memory
  logic [DW-1:0] model [TOTAL];
  logic [DW-1:0] known [TOTAL];
  initial for (int i = 0; i < TOTAL; i++) begin model[i] = '0; known[i] = '0; end
  function automatic logic [DW-1:0] lane_bits(input logic [MW-1:0] m);
    logic [DW-1:0] b;
    for (int i = 0; i < DW; i++) b[i] = m[i / LW];
    lane_bits = b;
  endfunction
  // word index of the bank/row pair (for the test-port model)
  function automatic int word_of(input int b, input int r);
    word_of = (ILV == 0) ? r * NB + b : b * BD + r;
  endfunction

  // per-master expected queues: index m*QD + slot
  logic [DW-1:0]  e_data [NM*QD];
  logic [DW-1:0]  e_known[NM*QD];
  logic           e_err  [NM*QD];
  logic           e_we   [NM*QD];
  logic [IDW-1:0] e_id   [NM*QD];
  longint         e_cyc  [NM*QD];
  int qh [NM], qt [NM], qn [NM];
  initial for (int m = 0; m < NM; m++) begin qh[m] = 0; qt[m] = 0; qn[m] = 0; end

  // metrics
  longint cyc = 0, m_acc = 0, m_conf = 0, m_rsp = 0, lat_sum = 0, lat_max = 0, m_cyc0 = 0, m_err = 0;
  longint togg = 0, bank_acc = 0;
  bit     acc_q [NM];
  initial for (int m = 0; m < NM; m++) acc_q[m] = 0;
  int     bp_pct = 0;
  int     trace_fd = 0;
  string  trace_file;

  always @(posedge clk) begin
    cyc = cyc + 1;
    if (rst_n) begin
      for (int m = 0; m < NM; m++) begin
        if (rsp_valid[m] && rsp_ready[m]) begin
          if (qn[m] == 0) tb_check(0, $sformatf("master %0d: unsolicited response", m));
          else begin
            int x;
            x = m*QD + qh[m];
            tb_check(rsp_id[m*IDW +: IDW] === e_id[x], $sformatf("master %0d: response ID %0h exp %0h (order/routing)", m, rsp_id[m*IDW +: IDW], e_id[x]));
            tb_check(rsp_err[m] === e_err[x] && rsp_we[m] === e_we[x], $sformatf("master %0d: err/we mismatch", m));
            tb_check(((rsp_rdata[m*DW +: DW] ^ e_data[x]) & e_known[x]) === '0,
                     $sformatf("master %0d: rdata %h exp %h", m, rsp_rdata[m*DW +: DW], e_data[x]));
            if (trace_fd != 0)
              $fdisplay(trace_fd, "%0d %0d %h %b %b %h", cyc, m, rsp_rdata[m*DW +: DW] & e_known[x], rsp_err[m], rsp_we[m], rsp_id[m*IDW +: IDW]);
            lat_sum += cyc - e_cyc[x];
            if (cyc - e_cyc[x] > lat_max) lat_max = cyc - e_cyc[x];
            m_rsp++;
            qh[m] = (qh[m] + 1) % QD; qn[m]--;
          end
        end
      end
      // acceptance: reads evaluated before writes of the same cycle (a bank grants one master,
      // so same-word read/write in one cycle cannot happen; ordering is irrelevant but explicit)
      for (int m = 0; m < NM; m++) begin
        if (req_valid[m] && req_ready[m] && !req_we[m]) push_rsp(m);
        if (stall_conflict[m]) m_conf++;
      end
      for (int m = 0; m < NM; m++) begin
        if (req_valid[m] && req_ready[m] && req_we[m]) push_rsp(m);
        acc_q[m] = req_valid[m] && req_ready[m];
        if (acc_q[m]) m_acc++;
      end
      if (tst_active && tst_ce && tst_we)
        for (int b = 0; b < NB; b++)
          if (tst_sel[b]) begin model[word_of(b, int'(tst_addr))] = tst_wdata; known[word_of(b, int'(tst_addr))] = '1; end
    end
  end

  task automatic push_rsp(input int m);
    logic [AWD-1:0] a;
    int  w, x;
    bit  ok;
    a  = req_addr[m*AWD +: AWD];
    ok = 1;
    if (BOFF > 0 && (a & AWD'((1 << BOFF) - 1)) != 0) ok = 0;
    w  = int'(a >> BOFF);
    if (w >= TOTAL) ok = 0;
    x  = m*QD + qt[m];
    if (!ok) begin
      m_err++;
      e_data[x] = '0; e_known[x] = '1; e_err[x] = 1; e_we[x] = req_we[m];
    end else if (req_we[m]) begin
      model[w] = (model[w] & ~lane_bits(req_wmask[m*MW +: MW])) | (req_wdata[m*DW +: DW] & lane_bits(req_wmask[m*MW +: MW]));
      known[w] = known[w] | lane_bits(req_wmask[m*MW +: MW]);
      if (WACK == 0) return;
      e_data[x] = '0; e_known[x] = '1; e_err[x] = 0; e_we[x] = 1;
    end else begin
      e_data[x] = model[w]; e_known[x] = known[w]; e_err[x] = 0; e_we[x] = 0;
    end
    e_id[x] = req_id[m*IDW +: IDW]; e_cyc[x] = cyc;
    qt[m] = (qt[m] + 1) % QD; qn[m]++;
  endtask

  // switching-activity proxy on every bank's input port
  for (genvar b = 0; b < NB; b++) begin : g_act
    logic [RAW-1:0] p_row = '0;
    logic [DW-1:0]  p_wd = '0;
    always @(posedge clk) begin
      if (rst_n && dut.g_bank[b].ce) begin
        togg += $countones(dut.g_bank[b].row ^ p_row) + $countones(dut.g_bank[b].wdata ^ p_wd);
        bank_acc++;
        p_row = dut.g_bank[b].row;
        p_wd  = dut.g_bank[b].wdata;
      end
    end
  end

  // ------------------------------------------------------------ traffic generation
  int wl = 0, err_pct = 0;
  bit drive_en = 0;
  int ptr [NM], burst_left [NM], tile_r [NM], tile_c [NM];
  bit burst_wr [NM];
  localparam int TILE = 8, ROWLEN = 64;
  initial for (int m = 0; m < NM; m++) begin ptr[m] = 0; burst_left[m] = 0; tile_r[m] = 0; tile_c[m] = 0; burst_wr[m] = 0; end

  function automatic int kind_of(input int m);
    if (wl == 5) kind_of = (m == 0) ? 1 : (m == 1) ? 2 : (m == 2) ? 3 : 4;
    else kind_of = wl;
  endfunction

  // returns {issue, we, word}
  task automatic gen(input int m, output bit go, output bit we, output int w);
    int base;
    base = (m * TOTAL) / NM;
    go = 1; we = 0; w = 0;
    case (kind_of(m))
      0: begin go = rnd_pct(70); we = rnd_pct(40); w = rnd_below(TOTAL); end
      1: begin go = rnd_pct(60); we = rnd_pct(30); w = (base + ptr[m]) % TOTAL; if (go) ptr[m]++; end
      2: begin go = 1; we = (ptr[m] / 256) % 2 == 1; w = (base + ptr[m]) % TOTAL; ptr[m]++; end
      3: begin
           go = 1; we = 0;
           w  = (base + tile_r[m] * ROWLEN + tile_c[m]) % TOTAL;
           tile_c[m]++;
           if (tile_c[m] == TILE) begin tile_c[m] = 0; tile_r[m]++; if (tile_r[m] == TILE) begin tile_r[m] = 0; base = 0; end end
         end
      4: begin
           if (burst_left[m] == 0) begin burst_left[m] = 64; burst_wr[m] = !burst_wr[m]; ptr[m] = rnd_below(TOTAL); end
           go = 1; we = burst_wr[m]; w = ptr[m] % TOTAL; ptr[m]++; burst_left[m]--;
         end
      6: begin go = 1; we = rnd_pct(20); w = (ptr[m] * NB + (m % NB) * 0) % TOTAL; ptr[m]++; end
      default: begin go = rnd_pct(50); we = rnd_pct(50); w = rnd_below(TOTAL); end
    endcase
  endtask

  bit e_inj, e_mis, full_m;
  // RNG calls never appear inside && / || / ?: : Verilator 5.020 does not short-circuit side-effecting
  // calls there, which would make the stimulus simulator-dependent.
  // An always block, not an 'initial forever' process: with Verilator 5.020 --timing, DUT combinational
  // logic was observed NOT to be re-evaluated after writes from a resumed process (stale collision
  // detection in the TDP wrapper), so stimulus is driven from a clocked always block.
  always @(negedge clk) begin : p_driver
    for (int m = 0; m < NM; m++) begin
      if (FIFO == 0) rsp_ready[m] <= 1'b1;
      else           rsp_ready[m] <= !rnd2_pct(bp_pct);
    end
    if (drive_en) begin
      for (int m = 0; m < NM; m++) begin
        if (req_valid[m] && acc_q[m]) req_valid[m] = 1'b0;
        if (!req_valid[m]) begin
          bit go, we; int w; logic [AWD-1:0] a;
          gen(m, go, we, w);
          if (go) begin
            a = AWD'(w) << BOFF;
            e_inj = 1'b0;
            if (err_pct > 0) e_inj = rnd_pct(err_pct);
            if (e_inj) begin
              e_mis = 1'b0;
              if (BOFF > 0) e_mis = rnd_pct(50);
              if (e_mis) a = a | AWD'(1);                                 // misaligned
              else       a = AWD'(TOTAL + rnd_below(TOTAL)) << BOFF;      // out of range
            end
            req_valid[m] = 1'b1; req_we[m] = we;
            req_addr[m*AWD +: AWD] = a;
            req_wdata[m*DW +: DW]  = DW'(rnd_vec());
            full_m = rnd_pct(60);
            if (full_m) req_wmask[m*MW +: MW] = '1;
            else        req_wmask[m*MW +: MW] = MW'(rnd_vec());
            req_id[m*IDW +: IDW]   = IDW'(rnd32());
          end
        end
      end
    end
  end

  task automatic drain();
    int guard, pend;
    @(posedge clk); #1;
    drive_en = 0;
    @(negedge clk);
    pend = 1;
    while (pend) begin
      pend = 0;
      for (int m = 0; m < NM; m++) begin
        if (req_valid[m] && acc_q[m]) req_valid[m] = 1'b0;
        if (req_valid[m]) pend = 1;
      end
      if (pend) @(negedge clk);
    end
    guard = 0;
    pend  = 1;
    while (pend && guard < 200000) begin
      pend = busy;
      for (int m = 0; m < NM; m++) if (qn[m] != 0) pend = 1;
      if (pend) begin @(negedge clk); guard++; end   // poll away from the monitor's edge
    end
    for (int m = 0; m < NM; m++) tb_check(qn[m] == 0, $sformatf("master %0d: missing responses (dropped)", m));
    repeat (LAT + 3) @(posedge clk);
    tb_check(rsp_valid == '0, "extra response after drain");
  endtask

  function automatic string wl_name(input int k);
    case (k)
      0: wl_name = "random"; 1: wl_name = "cpu"; 2: wl_name = "vector"; 3: wl_name = "tensor";
      4: wl_name = "dma"; 5: wl_name = "mixed"; 6: wl_name = "stride_nb"; default: wl_name = "?";
    endcase
  endfunction

  task automatic run(input int k, input int n, input int bp, input int ep);
    drain();
    wl = k; bp_pct = bp; err_pct = ep;
    m_acc = 0; m_conf = 0; m_rsp = 0; lat_sum = 0; lat_max = 0; togg = 0; bank_acc = 0;
    for (int m = 0; m < NM; m++) begin ptr[m] = 0; burst_left[m] = 0; tile_r[m] = 0; tile_c[m] = 0; end
    m_cyc0 = cyc;
    @(posedge clk); #1;
    drive_en = 1;
    repeat (n) @(negedge clk);
    drain();
    $display("SRAM_METRIC wl=%s nm=%0d nb=%0d dw=%0d lat=%0d arb=%0d ilv=%0d bp=%0d cycles=%0d accepted=%0d words_per_cycle=%0.4f conflict_stalls=%0d conflict_rate=%0.4f avg_latency=%0.3f max_latency=%0d toggles_per_access=%0.2f",
             wl_name(k), NM, NB, DW, LAT, ARB, ILV, bp, n, m_acc, real'(m_acc) / real'(n), m_conf,
             (m_acc + m_conf) > 0 ? real'(m_conf) / real'(m_acc + m_conf) : 0.0,
             m_rsp > 0 ? real'(lat_sum) / real'(m_rsp) : 0.0, lat_max,
             bank_acc > 0 ? real'(togg) / real'(bank_acc) : 0.0);
  endtask

  int ncyc = 3000, only_wl = -1, bp_arg = -1;
  initial begin
    tb_seed_init();
    if (!$value$plusargs("ncyc=%d", ncyc)) ncyc = 3000;
    if (!$value$plusargs("wl=%d", only_wl)) only_wl = -1;
    if (!$value$plusargs("bp=%d", bp_arg)) bp_arg = -1;
    if ($value$plusargs("trace=%s", trace_file)) trace_fd = $fopen(trace_file, "w");
    $display("SRAM_INFO tb_sram_banking NM=%0d NB=%0d DW=%0d MW=%0d BD=%0d LAT=%0d BACKEND=%0d ARB=%0d ILV=%0d AMODE=%0d FIFO=%0d WACK=%0d",
             NM, NB, DW, MW, BD, LAT, BACKEND, ARB, ILV, AMODE, FIFO, WACK);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (2) @(negedge clk);

    if (only_wl >= 0) begin
      run(only_wl, ncyc, (bp_arg < 0) ? 0 : bp_arg, 0);
    end else begin
      for (int k = 0; k <= 6; k++) run(k, ncyc, 0, 0);
      run(0, ncyc, 30, 5);          // backpressure + misaligned / out-of-range addresses
      run(5, ncyc, 60, 3);

      // MBIST: write every bank in parallel through the test port, then read back functionally
      drain();
      @(negedge clk);
      tst_active = 1; tst_sel = '1;
      for (int r = 0; r < BD && r < 64; r++) begin
        @(negedge clk);
        tst_ce = 1; tst_we = 1; tst_addr = RAW'(r); tst_wdata = DW'(rnd_vec());
        @(posedge clk);
        tb_check(req_ready == '0, "functional ready must be 0 in test mode");
      end
      @(negedge clk); tst_ce = 0;
      repeat (LAT + 2) @(negedge clk);
      tst_active = 0; tst_sel = '0;
      run(0, ncyc / 2, 10, 0);
    end
    $display("SRAM_METRIC total_checks=%0d", tb_checks);
    if (trace_fd != 0) $fclose(trace_fd);
    tb_finish("tb_sram_banking");
  end

  initial begin
    #(64'd2_000_000_000);
    tb_check(0, "global timeout");
    tb_finish("tb_sram_banking");
  end

endmodule

`default_nettype wire
