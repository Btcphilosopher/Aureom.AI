"""cocotb random tests for the SilicaFlux SRAM library (independent Python scoreboard).

Runs on Icarus Verilog (cocotb 2.x needs Verilator >= 5.036; the environment has 5.020).
The reference model is a plain Python dict of words with a per-bit "known" mask;
every response is checked for data (known bits), err, we, id and order.  Random
seeds come from cocotb (RANDOM_SEED, recorded in the results XML and the log).

  test_sram_sp_random           sram_sp: random reads / masked writes / invalid
                                addresses, random valid gaps and rsp backpressure
  test_bank_controller_random   sram_bank_controller: several masters, per-master
                                in-order ID check, global memory model
"""
from __future__ import annotations

import random
from collections import deque

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, RisingEdge


def ival(sig) -> int:
    """Strict: control signals must never be X/Z after reset."""
    return int(sig.value)


def dval(sig) -> tuple[int, int]:
    """Data with 4-state values: (value with X/Z read as 0, mask of X/Z bits)."""
    s = str(sig.value).lower()
    v = int(s.replace("x", "0").replace("z", "0"), 2)
    xm = int("".join("1" if c in "xz" else "0" for c in s), 2)
    return v, xm


async def reset(dut):
    dut.rst_n.value = 1
    await FallingEdge(dut.clk)
    dut.rst_n.value = 0
    for _ in range(3):
        await FallingEdge(dut.clk)
    dut.rst_n.value = 1
    for _ in range(2):
        await FallingEdge(dut.clk)


def lanes_to_bits(mask: int, mw: int, lw: int) -> int:
    b = 0
    for l in range(mw):
        if (mask >> l) & 1:
            b |= ((1 << lw) - 1) << (l * lw)
    return b


@cocotb.test()
async def test_sram_sp_random(dut):
    dw, depth = int(dut.DATA_WIDTH.value), int(dut.DEPTH.value)
    mw, lat = int(dut.MASK_WIDTH.value), int(dut.READ_LATENCY.value)
    aw = max(1, (depth - 1).bit_length())
    lw = dw // mw
    rng = random.Random(cocotb.RANDOM_SEED)
    dut._log.info(f"sram_sp DW={dw} DEPTH={depth} MW={mw} LAT={lat} seed={cocotb.RANDOM_SEED}")
    for s in ("req_valid", "req_we", "req_addr", "req_wdata", "req_wmask", "req_id", "tst_active", "tst_ce",
              "tst_we", "tst_addr", "tst_wdata"):
        getattr(dut, s).value = 0
    dut.rsp_ready.value = 1
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset(dut)

    model: dict[int, tuple[int, int]] = {}
    exp: deque = deque()
    stats = {"checks": 0, "rsp": 0, "acc": 0}
    bp = 30
    n_req = 2500

    async def monitor():
        while True:
            await RisingEdge(dut.clk)
            if ival(dut.rsp_valid) and ival(dut.rsp_ready):
                assert exp, "unsolicited response"
                d, k, err, we, rid = exp.popleft()
                got, xm = dval(dut.rsp_rdata)
                assert xm & k == 0, f"X on known data bits {xm & k:x}"
                assert ival(dut.rsp_err) == err and ival(dut.rsp_we) == we and ival(dut.rsp_id) == rid, \
                    f"tag mismatch err={ival(dut.rsp_err)}/{err} we={ival(dut.rsp_we)}/{we} id={ival(dut.rsp_id)}/{rid}"
                assert (got ^ d) & k == 0, f"data {got:x} expected {d:x} known {k:x}"
                stats["checks"] += 1
                stats["rsp"] += 1
            if ival(dut.req_valid) and ival(dut.req_ready):
                stats["acc"] += 1
                a, we = ival(dut.req_addr), ival(dut.req_we)
                rid = ival(dut.req_id)
                if a >= depth:
                    exp.append((0, (1 << dw) - 1, 1, we, rid))
                elif we:
                    bits = lanes_to_bits(ival(dut.req_wmask), mw, lw)
                    v, k = model.get(a, (0, 0))
                    model[a] = ((v & ~bits) | (dval(dut.req_wdata)[0] & bits), k | bits)
                    exp.append((0, (1 << dw) - 1, 0, 1, rid))   # WRITE_ACK = 1
                else:
                    v, k = model.get(a, (0, 0))
                    exp.append((v, k, 0, 0, rid))

    async def backpressure():
        while True:
            await FallingEdge(dut.clk)
            dut.rsp_ready.value = 0 if rng.randrange(100) < bp else 1

    cocotb.start_soon(monitor())
    cocotb.start_soon(backpressure())
    for i in range(n_req):
        await FallingEdge(dut.clk)
        for _ in range(rng.choice((0, 0, 0, 1, 2))):
            await FallingEdge(dut.clk)
        a = rng.randrange(1 << aw)                     # includes invalid addresses for non-power-of-two DEPTH
        dut.req_valid.value = 1
        dut.req_we.value = rng.randrange(100) < 45
        dut.req_addr.value = a
        dut.req_wdata.value = rng.getrandbits(dw)
        dut.req_wmask.value = rng.getrandbits(mw)
        dut.req_id.value = rng.getrandbits(int(dut.ID_WIDTH.value))
        await RisingEdge(dut.clk)
        while not ival(dut.req_ready):
            await RisingEdge(dut.clk)
        await FallingEdge(dut.clk)
        dut.req_valid.value = 0
    bp = 0
    for _ in range(200):
        await FallingEdge(dut.clk)
        if not exp and not ival(dut.busy):
            break
    assert not exp, f"{len(exp)} responses missing (dropped)"
    dut._log.info(f"SRAM_COCOTB sram_sp accepted={stats['acc']} responses={stats['rsp']} checks={stats['checks']}")


@cocotb.test()
async def test_bank_controller_random(dut):
    if not hasattr(dut, "NUM_BANKS"):
        return
    nm, nb = int(dut.NUM_MASTERS.value), int(dut.NUM_BANKS.value)
    dw, bd = int(dut.DATA_WIDTH.value), int(dut.BANK_DEPTH.value)
    aw, idw = int(dut.ADDR_WIDTH.value), int(dut.ID_WIDTH.value)
    total = nb * bd
    rng = random.Random(cocotb.RANDOM_SEED)
    dut._log.info(f"bank_controller NM={nm} NB={nb} DW={dw} BD={bd} seed={cocotb.RANDOM_SEED}")
    for s in ("m_req_valid", "m_req_we", "m_req_addr", "m_req_wdata", "m_req_id", "tst_active", "tst_sel", "tst_ce",
              "tst_we", "tst_addr", "tst_wdata"):
        getattr(dut, s).value = 0
    dut.m_req_wmask.value = (1 << (nm * int(dut.MASK_WIDTH.value))) - 1
    dut.m_rsp_ready.value = (1 << nm) - 1
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset(dut)

    def field(v: int, i: int, w: int) -> int:
        return (v >> (i * w)) & ((1 << w) - 1)

    model: dict[int, int] = {}
    exp = [deque() for _ in range(nm)]
    pend = [None] * nm
    stats = {"checks": 0}

    async def monitor():
        while True:
            await RisingEdge(dut.clk)
            rv, rr = ival(dut.m_rsp_valid), ival(dut.m_rsp_ready)
            (rdat, rx), rid, rerr = dval(dut.m_rsp_rdata), ival(dut.m_rsp_id), ival(dut.m_rsp_err)
            for m in range(nm):
                if (rv >> m) & 1 and (rr >> m) & 1:
                    assert exp[m], f"master {m}: unsolicited response"
                    d, known, err, i = exp[m].popleft()
                    assert field(rid, m, idw) == i, f"master {m}: id {field(rid, m, idw)} expected {i} (order/routing)"
                    assert ((rerr >> m) & 1) == err, f"master {m}: err mismatch"
                    if known:
                        assert field(rx, m, dw) == 0, f"master {m}: X on known data"
                        assert field(rdat, m, dw) == d, f"master {m}: data {field(rdat, m, dw):x} expected {d:x}"
                    stats["checks"] += 1
            v, rdy, we = ival(dut.m_req_valid), ival(dut.m_req_ready), ival(dut.m_req_we)
            ad, wd, qi = ival(dut.m_req_addr), dval(dut.m_req_wdata)[0], ival(dut.m_req_id)
            for m in range(nm):                      # reads before writes of the same cycle
                if (v >> m) & 1 and (rdy >> m) & 1 and not (we >> m) & 1:
                    a = field(ad, m, aw)
                    ok = a < total
                    exp[m].append((model.get(a, 0), ok and a in model, 0 if ok else 1, field(qi, m, idw)))
            for m in range(nm):
                if (v >> m) & 1 and (rdy >> m) & 1:
                    pend[m] = "accepted"
                    if (we >> m) & 1:
                        a = field(ad, m, aw)
                        if a < total:
                            model[a] = field(wd, m, dw)
                        exp[m].append((0, True, 0 if a < total else 1, field(qi, m, idw)))

    cocotb.start_soon(monitor())
    for cyc in range(4000):
        await FallingEdge(dut.clk)
        v, we = ival(dut.m_req_valid), ival(dut.m_req_we)
        ad, wd, qi = ival(dut.m_req_addr), dval(dut.m_req_wdata)[0], ival(dut.m_req_id)
        for m in range(nm):
            if pend[m] == "accepted":
                v &= ~(1 << m)
                pend[m] = None
            if not (v >> m) & 1 and rng.randrange(100) < 70:
                a = rng.randrange(total + total // 8)
                if rng.randrange(100) < 30:
                    a = (m * 7 + cyc) % total          # streaming component
                v |= 1 << m
                we = (we & ~(1 << m)) | ((rng.randrange(100) < 40) << m)
                ad = (ad & ~(((1 << aw) - 1) << (m * aw))) | (a << (m * aw))
                wd = (wd & ~(((1 << dw) - 1) << (m * dw))) | (rng.getrandbits(dw) << (m * dw))
                qi = (qi & ~(((1 << idw) - 1) << (m * idw))) | (rng.getrandbits(idw) << (m * idw))
        dut.m_req_valid.value = v
        dut.m_req_we.value = we
        dut.m_req_addr.value = ad
        dut.m_req_wdata.value = wd
        dut.m_req_id.value = qi
        dut.m_rsp_ready.value = rng.getrandbits(nm) | rng.getrandbits(nm)   # ~25 % backpressure per master
    # drain
    dut.m_req_valid.value = 0
    dut.m_rsp_ready.value = (1 << nm) - 1
    for _ in range(100):
        await FallingEdge(dut.clk)
    assert all(not e for e in exp), "responses missing (dropped)"
    dut._log.info(f"SRAM_COCOTB bank_controller checks={stats['checks']}")
