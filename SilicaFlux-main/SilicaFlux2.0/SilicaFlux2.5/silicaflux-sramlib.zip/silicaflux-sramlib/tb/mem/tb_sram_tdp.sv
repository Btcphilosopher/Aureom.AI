// =============================================================================
// SilicaFlux SRAM Wrapper Library :: tb_sram_tdp   (self-checking)
// Two independent read/write ports on sram_tdp: simultaneous traffic,
// write/write, write/read and read/read same-address conflicts, alternating
// priority (starvation bound), backpressure per port, invalid addresses and
// the test port.  Reference model: per cycle, both ports' reads are evaluated
// before both ports' writes are applied; STALL guarantees no same-address
// pair involving a write is accepted in one cycle (checked).
// Plusargs: +seed=<n> +ncyc=<n> +trace=<file>
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sram_tdp;
  parameter int DW        = 32;
  parameter int DEPTH     = 256;
  parameter int MW        = 4;
  parameter int LAT       = 1;
  parameter int BACKEND   = 0;
  parameter int MACRO     = 0;
  parameter int COLLISION = 0;
  parameter int FIFO      = LAT + 1;
  parameter int WACK      = 1;
  parameter int IDW       = 4;
  localparam int AW       = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int LW       = DW / MW;
  localparam int NSPACE   = 1 << AW;
  localparam int QD       = 8192;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;

  logic           v [2];
  logic           we [2];
  logic [AW-1:0]  ad [2];
  logic [DW-1:0]  wd [2];
  logic [MW-1:0]  wm [2];
  logic [IDW-1:0] id [2];
  logic           rdy [2];
  logic           rv [2];
  logic           rr [2];
  logic [DW-1:0]  rdat [2];
  logic           rerr [2];
  logic           rwe [2];
  logic [IDW-1:0] rid [2];
  logic           busy;
  logic           tst_active = 0, tst_ce = 0, tst_we = 0;
  logic [AW-1:0]  tst_addr = '0;
  logic [DW-1:0]  tst_wdata = '0, tst_rdata;
  initial for (int p = 0; p < 2; p++) begin v[p] = 0; we[p] = 0; ad[p] = '0; wd[p] = '0; wm[p] = '0; id[p] = '0; rr[p] = 1; end

  sram_tdp #(
    .DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .BACKEND(BACKEND), .MACRO(MACRO),
    .COLLISION(COLLISION), .RSP_FIFO_DEPTH(FIFO), .WRITE_ACK(WACK), .ID_WIDTH(IDW), .TEST_EN(1)
  ) dut (
    .clk, .rst_n,
    .a_req_valid(v[0]), .a_req_ready(rdy[0]), .a_req_we(we[0]), .a_req_addr(ad[0]), .a_req_wdata(wd[0]),
    .a_req_wmask(wm[0]), .a_req_id(id[0]), .a_rsp_valid(rv[0]), .a_rsp_ready(rr[0]), .a_rsp_rdata(rdat[0]),
    .a_rsp_err(rerr[0]), .a_rsp_we(rwe[0]), .a_rsp_id(rid[0]),
    .b_req_valid(v[1]), .b_req_ready(rdy[1]), .b_req_we(we[1]), .b_req_addr(ad[1]), .b_req_wdata(wd[1]),
    .b_req_wmask(wm[1]), .b_req_id(id[1]), .b_rsp_valid(rv[1]), .b_rsp_ready(rr[1]), .b_rsp_rdata(rdat[1]),
    .b_rsp_err(rerr[1]), .b_rsp_we(rwe[1]), .b_rsp_id(rid[1]),
    .tst_active, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy
  );

  logic [DW-1:0] model [DEPTH];
  logic [DW-1:0] known [DEPTH];
  initial for (int i = 0; i < DEPTH; i++) begin model[i] = '0; known[i] = '0; end
  function automatic logic [DW-1:0] lane_bits(input logic [MW-1:0] m);
    logic [DW-1:0] b;
    for (int i = 0; i < DW; i++) b[i] = m[i / LW];
    lane_bits = b;
  endfunction

  // expected responses: index = port*QD + slot
  logic [DW-1:0]  e_data [2*QD];
  logic [DW-1:0]  e_known[2*QD];
  logic           e_err  [2*QD];
  logic           e_we   [2*QD];
  logic [IDW-1:0] e_id   [2*QD];
  int qh [2], qt [2], qn [2];
  initial for (int p = 0; p < 2; p++) begin qh[p] = 0; qt[p] = 0; qn[p] = 0; end

  longint cyc = 0, n_conf = 0, n_dual = 0, n_ww = 0;
  int     wt [2], max_wt [2];
  initial for (int p = 0; p < 2; p++) begin wt[p] = 0; max_wt[p] = 0; end
  bit     acc_q [2];
  initial begin acc_q[0] = 0; acc_q[1] = 0; end
  int     bp_pct = 0, hot_pct = 0, inval_pct = 0, wr_pct = 50, go_pct = 70;
  int     trace_fd = 0;
  string  trace_file;

  task automatic push(input int p, input logic [DW-1:0] d, input logic [DW-1:0] k, input logic e, input logic w,
                      input logic [IDW-1:0] i);
    e_data[p*QD + qt[p]] = d; e_known[p*QD + qt[p]] = k; e_err[p*QD + qt[p]] = e; e_we[p*QD + qt[p]] = w;
    e_id[p*QD + qt[p]] = i; qt[p] = (qt[p] + 1) % QD; qn[p]++;
  endtask

  always @(posedge clk) begin
    cyc = cyc + 1;
    if (rst_n) begin
      for (int p = 0; p < 2; p++) begin
        if (rv[p] && rr[p]) begin
          if (qn[p] == 0) tb_check(0, $sformatf("port %0d unsolicited response", p));
          else begin
            int x;
            x = p*QD + qh[p];
            tb_check(rerr[p] === e_err[x] && rwe[p] === e_we[x] && rid[p] === e_id[x],
                     $sformatf("port %0d response tag mismatch", p));
            tb_check(((rdat[p] ^ e_data[x]) & e_known[x]) === '0,
                     $sformatf("port %0d rdata=%h exp %h", p, rdat[p], e_data[x]));
            if (trace_fd != 0) $fdisplay(trace_fd, "%0d %0d %h %b %b %h", cyc, p, rdat[p] & e_known[x], rerr[p], rwe[p], rid[p]);
            qh[p] = (qh[p] + 1) % QD; qn[p]--;
          end
        end
      end
      // conflict bookkeeping
      if (!tst_active && v[0] && v[1] && ad[0] == ad[1] && int'(ad[0]) < DEPTH && (we[0] || we[1])) begin
        n_conf++;
        if (we[0] && we[1]) n_ww++;
        tb_check(!(rdy[0] && rdy[1]), "conflicting pair accepted in the same cycle");
        if (COLLISION == 2) tb_check(0, "FORBID: driver produced a conflict");
      end
      if (v[0] && rdy[0] && v[1] && rdy[1]) n_dual++;
      for (int p = 0; p < 2; p++) begin
        wt[p] = (v[p] && !rdy[p] && !tst_active) ? wt[p] + 1 : 0;
        if (bp_pct == 0 && wt[p] > max_wt[p]) max_wt[p] = wt[p];
      end
      // reads of both ports first ...
      for (int p = 0; p < 2; p++) begin
        if (v[p] && rdy[p]) begin
          if (int'(ad[p]) >= DEPTH) push(p, '0, '1, 1'b1, we[p], id[p]);
          else if (!we[p]) push(p, model[ad[p]], known[ad[p]], 1'b0, 1'b0, id[p]);
          else if (WACK != 0) push(p, '0, '1, 1'b0, 1'b1, id[p]);
        end
      end
      // ... then both ports' writes
      for (int p = 0; p < 2; p++) begin
        if (v[p] && rdy[p] && we[p] && int'(ad[p]) < DEPTH) begin
          model[ad[p]] = (model[ad[p]] & ~lane_bits(wm[p])) | (wd[p] & lane_bits(wm[p]));
          known[ad[p]] = known[ad[p]] | lane_bits(wm[p]);
        end
      end
      if (tst_active && tst_ce && tst_we) begin model[tst_addr] = tst_wdata; known[tst_addr] = '1; end
      for (int p = 0; p < 2; p++) acc_q[p] = v[p] && rdy[p];
    end
  end

  bit drive_en = 0;
  function automatic logic [AW-1:0] pick_addr();
    bit inv, hot;
    inv = 1'b0;
    if (inval_pct > 0 && NSPACE > DEPTH) inv = rnd_pct(inval_pct);
    if (inv) pick_addr = AW'(DEPTH + rnd_below(NSPACE - DEPTH));
    else begin
      hot = rnd_pct(hot_pct);
      if (hot) pick_addr = AW'(rnd_below(3));
      else     pick_addr = AW'(rnd_below(DEPTH));
    end
  endfunction

  bit held [2];
  bit go, full_m;
  initial begin held[0] = 0; held[1] = 0; end
  // RNG calls never appear inside && / || / ?: : Verilator 5.020 does not short-circuit side-effecting
  // calls there, which would make the stimulus simulator-dependent.
  // An always block, not an 'initial forever' process: with Verilator 5.020 --timing, DUT combinational
  // logic was observed NOT to be re-evaluated after writes from a resumed process (stale collision
  // detection in the TDP wrapper), so stimulus is driven from a clocked always block.
  always @(negedge clk) begin : p_driver
    for (int p = 0; p < 2; p++) begin
      if (FIFO == 0) rr[p] <= 1'b1;
      else           rr[p] <= !rnd2_pct(bp_pct);
    end
    if (drive_en) begin
      for (int p = 0; p < 2; p++) begin
        held[p] = v[p] && !acc_q[p];
        if (v[p] && acc_q[p]) v[p] = 0;
        go = 1'b0;
        if (!v[p]) go = rnd_pct(go_pct);
        if (go) begin
          v[p] = 1; we[p] = rnd_pct(wr_pct); ad[p] = pick_addr(); wd[p] = DW'(rnd_vec());
          full_m = rnd_pct(40);
          if (full_m) wm[p] = '1;
          else        wm[p] = MW'(rnd_vec());
          id[p] = IDW'(rnd32());
        end
      end
      if (COLLISION == 2 && v[0] && v[1] && ad[0] == ad[1] && int'(ad[0]) < DEPTH && (we[0] || we[1])) begin
        if (!held[1]) ad[1] = AW'((int'(ad[0]) + 1) % DEPTH);
        else          ad[0] = AW'((int'(ad[1]) + 1) % DEPTH);
      end
    end
  end

  task automatic drain();
    int guard;
    @(posedge clk); #1;
    drive_en = 0;
    @(negedge clk);
    while (v[0] || v[1]) begin
      for (int p = 0; p < 2; p++) if (v[p] && acc_q[p]) v[p] = 0;
      if (v[0] || v[1]) @(negedge clk);
    end
    guard = 0;
    while ((qn[0] != 0 || qn[1] != 0 || busy) && guard < 100000) begin @(negedge clk); guard++; end   // poll away from the monitor's edge
    tb_check(qn[0] == 0 && qn[1] == 0, "drain: missing responses");
    repeat (LAT + 3) @(posedge clk);
    tb_check(!rv[0] && !rv[1], "drain: extra response");
  endtask

  task automatic run(input int n, input int bp, input int hp, input int ip, input int wp, input int gp);
    drain();
    bp_pct = bp; hot_pct = hp; inval_pct = ip; wr_pct = wp; go_pct = gp;
    @(posedge clk); #1;
    drive_en = 1;
    repeat (n) @(negedge clk);
    drain();
  endtask

  int ncyc = 4000;
  initial begin
    tb_seed_init();
    if (!$value$plusargs("ncyc=%d", ncyc)) ncyc = 4000;
    if ($value$plusargs("trace=%s", trace_file)) trace_fd = $fopen(trace_file, "w");
    $display("SRAM_INFO tb_sram_tdp DW=%0d DEPTH=%0d MW=%0d LAT=%0d BACKEND=%0d MACRO=%0d COLLISION=%0d FIFO=%0d WACK=%0d",
             DW, DEPTH, MW, LAT, BACKEND, MACRO, COLLISION, FIFO, WACK);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (2) @(negedge clk);
    // initialise every word through port A
    for (int i = 0; i < DEPTH; i++) begin
      v[0] = 1; we[0] = 1; ad[0] = AW'(i); wd[0] = DW'(rnd_vec()); wm[0] = '1;
      @(posedge clk); while (!rdy[0]) @(posedge clk);
      @(negedge clk);
    end
    v[0] = 0;
    run(ncyc,  0,  0, 0, 50, 100);   // both ports streaming
    run(ncyc,  0, 60, 0, 50,  80);   // conflict stress
    run(ncyc, 30, 40, 5, 60,  70);   // backpressure + invalid addresses
    run(ncyc, 70, 30, 5, 40,  90);

    drain();
    @(negedge clk);
    tst_active = 1;
    for (int i = 0; i < 32; i++) begin
      @(negedge clk);
      tst_ce = 1; tst_we = 1; tst_addr = AW'(i % DEPTH); tst_wdata = DW'(rnd_vec());
      @(posedge clk);
      tb_check(!rdy[0] && !rdy[1], "functional ready must be 0 in test mode");
    end
    @(negedge clk); tst_ce = 0;
    repeat (LAT + 2) @(negedge clk);
    tst_active = 0;
    run(ncyc / 2, 10, 20, 0, 30, 70);

    tb_check(n_dual > 0, "ports never accepted together");
    if (COLLISION == 0) begin
      tb_check(n_conf > 0 && n_ww > 0, "conflict stress produced no write/write conflict");
      tb_check(max_wt[0] <= 2 && max_wt[1] <= 2, $sformatf("starvation: max waits A=%0d B=%0d", max_wt[0], max_wt[1]));
    end
    $display("SRAM_METRIC dual_issue_cycles=%0d conflicts=%0d write_write=%0d max_wait_a=%0d max_wait_b=%0d",
             n_dual, n_conf, n_ww, max_wt[0], max_wt[1]);
    if (trace_fd != 0) $fclose(trace_fd);
    tb_finish("tb_sram_tdp");
  end

  initial begin
    #(64'd400_000_000);
    tb_check(0, "global timeout");
    tb_finish("tb_sram_tdp");
  end

endmodule

`default_nettype wire
