// =============================================================================
// SilicaFlux SRAM Wrapper Library :: tb_sram_1r1w   (self-checking)
// Simultaneous read/write, collision policies, backpressure, invalid
// addresses, starvation bound and the MBIST test port of sram_1r1w.
//
// Reference semantics (independent model): in every cycle the accepted read
// is evaluated against the model BEFORE the accepted write of the same cycle
// is applied ("a read sees writes accepted in earlier cycles only").
//   STALL    : the TB additionally checks that a same-address pair is never
//              accepted in one cycle and that waits stay bounded.
//   READ_OLD : the TB checks that a same-address pair IS accepted together
//              (no stall) and that the read returns the old word.
//   FORBID   : the driver never creates a collision.
// A single cycle-based driver produces both channels (deterministic across
// simulators).  Plusargs: +seed=<n> +ncyc=<n> +trace=<file>
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sram_1r1w;
  parameter int DW        = 32;
  parameter int DEPTH     = 512;
  parameter int MW        = 4;
  parameter int LAT       = 1;
  parameter int BACKEND   = 0;
  parameter int MACRO     = 0;
  parameter int COLLISION = 0;
  parameter int FIFO      = LAT + 1;
  parameter int IDW       = 4;
  localparam int AW       = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int LW       = DW / MW;
  localparam int NSPACE   = 1 << AW;
  localparam int QD       = 8192;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;

  logic           wr_valid = 0, rd_valid = 0;
  logic [AW-1:0]  wr_addr = '0, rd_addr = '0;
  logic [DW-1:0]  wr_data = '0;
  logic [MW-1:0]  wr_mask = '0;
  logic [IDW-1:0] rd_id = '0;
  logic           wr_ready, rd_ready, wr_err, rsp_valid, rsp_err, busy;
  logic           rsp_ready = 1'b1;
  logic [DW-1:0]  rsp_rdata;
  logic [IDW-1:0] rsp_id;
  logic           tst_active = 0, tst_ce = 0, tst_we = 0;
  logic [AW-1:0]  tst_addr = '0;
  logic [DW-1:0]  tst_wdata = '0, tst_rdata;

  sram_1r1w #(
    .DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .BACKEND(BACKEND), .MACRO(MACRO),
    .COLLISION(COLLISION), .RSP_FIFO_DEPTH(FIFO), .ID_WIDTH(IDW), .TEST_EN(1)
  ) dut (
    .clk, .rst_n,
    .wr_valid, .wr_ready, .wr_addr, .wr_data, .wr_mask, .wr_err,
    .rd_valid, .rd_ready, .rd_addr, .rd_id,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_id,
    .tst_active, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy
  );

  // ------------------------------------------------------------ reference model
  logic [DW-1:0] model [DEPTH];
  logic [DW-1:0] known [DEPTH];
  initial for (int i = 0; i < DEPTH; i++) begin model[i] = '0; known[i] = '0; end

  function automatic logic [DW-1:0] lane_bits(input logic [MW-1:0] m);
    logic [DW-1:0] b;
    for (int i = 0; i < DW; i++) b[i] = m[i / LW];
    lane_bits = b;
  endfunction

  logic [DW-1:0]  e_data [QD];
  logic [DW-1:0]  e_known[QD];
  logic           e_err  [QD];
  logic [IDW-1:0] e_id   [QD];
  longint         e_cyc  [QD];
  int qh = 0, qt = 0, qn = 0;
  logic [DW-1:0]  t_data [QD];
  logic [DW-1:0]  t_known[QD];
  longint         t_due  [QD];
  int th = 0, tt = 0, tn = 0;

  longint cyc = 0, n_coll = 0, n_coll_both = 0, n_dual = 0, n_wr = 0, n_rd = 0;
  int     w_wait = 0, r_wait = 0, max_w_wait = 0, max_r_wait = 0;
  bit     p_stall = 0;
  logic [DW-1:0] p_data; logic p_err; logic [IDW-1:0] p_id;
  int     trace_fd = 0;
  string  trace_file;
  bit     lat_exact = 0;

  always @(posedge clk) begin
    cyc = cyc + 1;
    if (!rst_n) begin
      tb_check(!wr_ready && !rd_ready && !rsp_valid, "ready/valid must be low in reset");
    end else begin
      if (p_stall) begin
        tb_check(rsp_valid === 1'b1, "rsp_valid dropped under backpressure");
        tb_check(rsp_rdata === p_data && rsp_err === p_err && rsp_id === p_id, "response changed under backpressure");
      end
      p_stall = rsp_valid && !rsp_ready;
      p_data = rsp_rdata; p_err = rsp_err; p_id = rsp_id;

      if (rsp_valid && rsp_ready) begin
        if (qn == 0) tb_check(0, "unsolicited response");
        else begin
          tb_check(rsp_err === e_err[qh], "rsp_err mismatch");
          tb_check(rsp_id === e_id[qh], "rsp_id mismatch");
          tb_check(((rsp_rdata ^ e_data[qh]) & e_known[qh]) === '0,
                   $sformatf("rsp_rdata=%h exp %h known %h", rsp_rdata, e_data[qh], e_known[qh]));
          if (lat_exact) tb_check(cyc - e_cyc[qh] == longint'(LAT), "read latency != READ_LATENCY");
          if (trace_fd != 0) $fdisplay(trace_fd, "%0d %h %b %h", cyc, rsp_rdata & e_known[qh], rsp_err, rsp_id);
          qh = (qh + 1) % QD; qn--;
        end
      end
      if (tn > 0 && t_due[th] == cyc) begin
        tb_check(((tst_rdata ^ t_data[th]) & t_known[th]) === '0, "tst_rdata mismatch");
        th = (th + 1) % QD; tn--;
      end

      // collision bookkeeping
      if (!tst_active && wr_valid && rd_valid && wr_addr == rd_addr && int'(wr_addr) < DEPTH) begin
        n_coll++;
        if (wr_ready && rd_ready) n_coll_both++;
        if (COLLISION == 0) tb_check(!(wr_ready && rd_ready), "STALL: same-address read and write accepted together");
        if (COLLISION == 1) begin
          tb_check(wr_ready, "READ_OLD: a collision must not stall the write");
          // reads may still wait for a response credit; with no backpressure and a full-rate FIFO they never do
          if (bp_pct == 0 && FIFO >= LAT + 1) tb_check(rd_ready, "READ_OLD: a collision must not stall the read");
        end
        if (COLLISION == 2) tb_check(0, "FORBID: driver produced a collision");
      end
      if (wr_valid && wr_ready && rd_valid && rd_ready) n_dual++;
      // wait bounds
      w_wait = (wr_valid && !wr_ready && !tst_active) ? w_wait + 1 : 0;
      r_wait = (rd_valid && !rd_ready && !tst_active && rsp_ready) ? r_wait + 1 : 0;
      if (bp_pct == 0 && w_wait > max_w_wait) max_w_wait = w_wait;   // bound only without backpressure
      if (bp_pct == 0 && r_wait > max_r_wait) max_r_wait = r_wait;

      // read first (sees only earlier writes) ...
      if (rd_valid && rd_ready) begin
        n_rd++;
        if (int'(rd_addr) >= DEPTH) begin
          e_data[qt] = '0; e_known[qt] = '1; e_err[qt] = 1;
        end else begin
          e_data[qt] = model[rd_addr]; e_known[qt] = known[rd_addr]; e_err[qt] = 0;
        end
        e_id[qt] = rd_id; e_cyc[qt] = cyc; qt = (qt + 1) % QD; qn++;
      end
      // ... then the write of this cycle
      tb_check(wr_err === (wr_valid && wr_ready && int'(wr_addr) >= DEPTH), "wr_err mismatch");
      if (wr_valid && wr_ready) begin
        n_wr++;
        if (int'(wr_addr) < DEPTH) begin
          model[wr_addr] = (model[wr_addr] & ~lane_bits(wr_mask)) | (wr_data & lane_bits(wr_mask));
          known[wr_addr] = known[wr_addr] | lane_bits(wr_mask);
        end
      end
      // test port: read first, then write (same rule)
      if (tst_active && tst_ce && !tst_we) begin
        t_data[tt] = model[tst_addr]; t_known[tt] = known[tst_addr]; t_due[tt] = cyc + longint'(LAT);
        tt = (tt + 1) % QD; tn++;
      end
      if (tst_active && tst_ce && tst_we) begin
        model[tst_addr] = tst_wdata; known[tst_addr] = '1;
      end
    end
  end

  // ------------------------------------------------------------ cycle driver
  int  bp_pct = 0, w_pct = 50, r_pct = 50, hot_pct = 0, inval_pct = 0;
  bit  w_hold = 0, r_hold = 0;

  function automatic logic [AW-1:0] pick_addr();
    bit inv, hot;
    inv = 1'b0;
    if (inval_pct > 0 && NSPACE > DEPTH) inv = rnd_pct(inval_pct);
    if (inv) pick_addr = AW'(DEPTH + rnd_below(NSPACE - DEPTH));
    else begin
      hot = rnd_pct(hot_pct);
      if (hot) pick_addr = AW'(rnd_below(4));
      else     pick_addr = AW'(rnd_below(DEPTH));
    end
  endfunction

  bit drive_en = 0;
  bit w_acc_q = 0, r_acc_q = 0, w_acc_hold = 0;   // sampled at the posedge
  bit go_w, go_r, full_m;
  // RNG calls never appear inside && / || / ?: : Verilator 5.020 does not short-circuit side-effecting
  // calls there, which would make the stimulus simulator-dependent.
  // An always block, not an 'initial forever' process: with Verilator 5.020 --timing, DUT combinational
  // logic was observed NOT to be re-evaluated after writes from a resumed process (stale collision
  // detection in the TDP wrapper), so stimulus is driven from a clocked always block.
  always @(negedge clk) begin : p_driver
    if (FIFO == 0) rsp_ready <= 1'b1;
    else           rsp_ready <= !rnd2_pct(bp_pct);
    if (drive_en) begin
      // retire accepted requests (acceptance was sampled at the last posedge)
      if (wr_valid && w_acc_q) wr_valid = 1'b0;
      if (rd_valid && r_acc_q) rd_valid = 1'b0;
      go_w = 1'b0;
      if (!wr_valid) go_w = rnd_pct(w_pct);
      if (go_w) begin
        wr_valid = 1'b1; wr_addr = pick_addr(); wr_data = DW'(rnd_vec()); wr_mask = MW'(rnd_vec());
        full_m = rnd_pct(30);
        if (full_m) wr_mask = '1;
      end
      go_r = 1'b0;
      if (!rd_valid) go_r = rnd_pct(r_pct);
      if (go_r) begin
        rd_valid = 1'b1; rd_addr = pick_addr(); rd_id = IDW'(rnd32());
      end
      if (COLLISION == 2 && wr_valid && rd_valid && wr_addr == rd_addr && int'(wr_addr) < DEPTH) begin
        // FORBID: move whichever request is new this cycle
        if (!w_acc_hold) wr_addr = AW'((int'(rd_addr) + 1) % DEPTH);
        else             rd_addr = AW'((int'(wr_addr) + 1) % DEPTH);
      end
    end
  end
  always @(posedge clk) begin
    w_acc_q = wr_valid && wr_ready;
    r_acc_q = rd_valid && rd_ready;
    w_acc_hold = wr_valid && !wr_ready;     // write request is being held (cannot change)
  end

  task automatic drain();
    int guard;
    @(posedge clk); #1;
    drive_en = 0;                               // takes effect at the next negedge
    @(negedge clk);
    while (wr_valid || rd_valid) begin
      if (wr_valid && w_acc_q) wr_valid = 0;
      if (rd_valid && r_acc_q) rd_valid = 0;
      if (wr_valid || rd_valid) @(negedge clk);
    end
    guard = 0;
    while ((qn != 0 || busy) && guard < 100000) begin @(negedge clk); guard++; end   // poll away from the monitor's edge
    tb_check(qn == 0, "drain: missing responses");
    repeat (LAT + 3) @(posedge clk);
    tb_check(qn == 0 && !rsp_valid, "drain: extra response");
  endtask

  task automatic run(input int ncyc, input int bp, input int wp, input int rp, input int hp, input int ip);
    drain();
    bp_pct = bp; w_pct = wp; r_pct = rp; hot_pct = hp; inval_pct = ip;
    lat_exact = (bp == 0);
    @(posedge clk); #1;
    drive_en = 1;
    repeat (ncyc) @(negedge clk);
    drain();
  endtask

  int ncyc = 4000;
  initial begin
    tb_seed_init();
    if (!$value$plusargs("ncyc=%d", ncyc)) ncyc = 4000;
    if ($value$plusargs("trace=%s", trace_file)) trace_fd = $fopen(trace_file, "w");
    $display("SRAM_INFO tb_sram_1r1w DW=%0d DEPTH=%0d MW=%0d LAT=%0d BACKEND=%0d MACRO=%0d COLLISION=%0d FIFO=%0d",
             DW, DEPTH, MW, LAT, BACKEND, MACRO, COLLISION, FIFO);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (2) @(negedge clk);

    // fill the array so reads have defined data (all lanes)
    drive_en = 0;
    for (int i = 0; i < DEPTH; i++) begin
      wr_valid = 1; wr_addr = AW'(i); wr_data = DW'(rnd_vec()); wr_mask = '1;
      @(posedge clk); while (!wr_ready) @(posedge clk);
      @(negedge clk);
    end
    wr_valid = 0;

    run(ncyc,     0, 100, 100,  0, 0);  // simultaneous streams, full throughput
    run(ncyc,     0,  70,  70, 60, 0);  // collision stress (4 hot addresses)
    run(ncyc,    30,  60,  60, 30, 5);  // backpressure + invalid addresses
    run(ncyc,    70,  50,  80, 30, 5);  // heavy backpressure

    // MBIST test port
    drive_en = 0;
    @(negedge clk);
    tst_active = 1;
    for (int i = 0; i < 64; i++) begin
      @(negedge clk);
      tst_ce = 1; tst_we = (i % 2 == 0); tst_addr = AW'((i / 2) % DEPTH); tst_wdata = DW'(rnd_vec());
      @(posedge clk);
      tb_check(!wr_ready && !rd_ready, "functional ready must be 0 in test mode");
    end
    @(negedge clk); tst_ce = 0;
    repeat (LAT + 2) @(negedge clk);
    tst_active = 0;
    run(ncyc / 2, 10, 50, 50, 10, 0);   // functional traffic sees MBIST-written data

    tb_check(n_dual > 0, "no cycle accepted a read and a write together");
    if (COLLISION != 2) tb_check(n_coll > 0, "collision stress produced no collision");
    // starvation bound without backpressure: 1 cycle per collision (alternating priority), plus the
    // credit wait of a response FIFO shallower than LATENCY+1
    if (COLLISION == 0)
      tb_check(max_w_wait <= 2 && max_r_wait <= ((FIFO >= LAT + 1) ? 2 : LAT + 2),
               $sformatf("starvation: max waits w=%0d r=%0d", max_w_wait, max_r_wait));
    $display("SRAM_METRIC writes=%0d reads=%0d dual_issue_cycles=%0d collisions=%0d coll_both_accepted=%0d max_wait_w=%0d max_wait_r=%0d",
             n_wr, n_rd, n_dual, n_coll, n_coll_both, max_w_wait, max_r_wait);
    if (trace_fd != 0) $fclose(trace_fd);
    tb_finish("tb_sram_1r1w");
  end

  initial begin
    #(64'd400_000_000);
    tb_check(0, "global timeout");
    tb_finish("tb_sram_1r1w");
  end

endmodule

`default_nettype wire
