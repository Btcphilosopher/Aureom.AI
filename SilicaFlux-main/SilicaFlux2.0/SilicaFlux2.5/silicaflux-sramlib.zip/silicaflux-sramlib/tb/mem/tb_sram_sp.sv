// =============================================================================
// SilicaFlux SRAM Wrapper Library :: tb_sram_sp   (self-checking)
// Verifies sram_sp against an independent reference model (procedural array
// with per-bit "known" mask + expected-response queue).  Runs unchanged in
// the Verilator (GENERIC/FPGA backends) and Icarus (also ASIC backend with the
// vendor macro models), so the same seed gives the same stimulus everywhere.
//
// Phases
//   P0 reset semantics          P6 byte-enable combinations
//   P1 single write/read        P7 address boundaries + invalid addresses
//   P2 consecutive writes       P8 random traffic, random gaps, backpressure
//   P3 consecutive reads        P9 MBIST test port (mid-traffic hand-over)
//   P4 alternating r/w          P10 data retention (fill, idle, read back)
//   P5 walking 1/0, all-0/all-1
// Every response is checked for data (known bits), err, we, id and order;
// latency is checked exactly (= READ_LATENCY) when no backpressure is
// applied, and payload stability is checked whenever rsp_valid && !rsp_ready.
// Plusargs: +seed=<n>  +nrand=<n>  +trace=<file> (response trace for
//           cross-backend equivalence; unknown bits masked to 0).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sram_sp;
  parameter int DW      = 32;
  parameter int DEPTH   = 1024;
  parameter int MW      = 4;
  parameter int LAT     = 1;
  parameter int BACKEND = 0;
  parameter int MACRO   = 0;
  parameter int FIFO    = LAT + 1;
  parameter int WACK    = 1;
  parameter int IDW     = 4;
  localparam int AW     = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int LW     = DW / MW;
  localparam int NSPACE = 1 << AW;
  localparam int QD     = 8192;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;            // a real falling edge for the asynchronous reset

  logic           req_valid = 0, req_we = 0;
  logic [AW-1:0]  req_addr = '0;
  logic [DW-1:0]  req_wdata = '0;
  logic [MW-1:0]  req_wmask = '0;
  logic [IDW-1:0] req_id = '0;
  logic           req_ready, rsp_valid, rsp_err, rsp_we, busy;
  logic           rsp_ready = 1'b1;
  logic [DW-1:0]  rsp_rdata;
  logic [IDW-1:0] rsp_id;
  logic           tst_active = 0, tst_ce = 0, tst_we = 0;
  logic [AW-1:0]  tst_addr = '0;
  logic [DW-1:0]  tst_wdata = '0, tst_rdata;

  sram_sp #(
    .DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .BACKEND(BACKEND), .MACRO(MACRO),
    .RSP_FIFO_DEPTH(FIFO), .WRITE_ACK(WACK), .ID_WIDTH(IDW), .TEST_EN(1)
  ) dut (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wmask, .req_id,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_we, .rsp_id,
    .tst_active, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy
  );

  // ------------------------------------------------------------ reference model
  logic [DW-1:0] model [DEPTH];
  logic [DW-1:0] known [DEPTH];
  initial for (int i = 0; i < DEPTH; i++) begin model[i] = '0; known[i] = '0; end

  function automatic logic [DW-1:0] lane_bits(input logic [MW-1:0] m);
    logic [DW-1:0] b;
    for (int i = 0; i < DW; i++) b[i] = m[i / LW];
    lane_bits = b;
  endfunction

  // expected response queue (circular)
  logic [DW-1:0]  e_data [QD];
  logic [DW-1:0]  e_known[QD];
  logic           e_err  [QD];
  logic           e_we   [QD];
  logic [IDW-1:0] e_id   [QD];
  longint         e_cyc  [QD];
  int qh = 0, qt = 0, qn = 0;

  // expected test-port reads
  logic [DW-1:0]  t_data [QD];
  logic [DW-1:0]  t_known[QD];
  longint         t_due  [QD];
  int th = 0, tt = 0, tn = 0;

  longint cyc = 0;
  bit     lat_exact = 0;
  longint n_rsp = 0, n_acc = 0, n_bp_stall = 0;
  int     trace_fd = 0;
  string  trace_file;

  // payload of the previous cycle (stability check)
  bit             p_stall = 0;
  logic [DW-1:0]  p_data;
  logic           p_err, p_we;
  logic [IDW-1:0] p_id;

  // ------------------------------------------------------------ monitor / scoreboard
  always @(posedge clk) begin
    cyc = cyc + 1;
    if (!rst_n) begin
      tb_check(req_ready === 1'b0, "req_ready must be 0 in reset");
      tb_check(rsp_valid === 1'b0, "rsp_valid must be 0 in reset");
    end else begin
      // stability under backpressure
      if (p_stall) begin
        tb_check(rsp_valid === 1'b1, "rsp_valid dropped under backpressure");
        tb_check(rsp_rdata === p_data && rsp_err === p_err && rsp_we === p_we && rsp_id === p_id,
                 "response payload changed under backpressure");
      end
      p_stall = rsp_valid && !rsp_ready;
      p_data = rsp_rdata; p_err = rsp_err; p_we = rsp_we; p_id = rsp_id;
      if (p_stall) n_bp_stall++;

      // response check (before this edge's accept: responses belong to earlier requests)
      if (rsp_valid && rsp_ready) begin
        n_rsp++;
        if (qn == 0) begin
          tb_check(0, "unsolicited response");
        end else begin
          tb_check(rsp_err === e_err[qh], $sformatf("rsp_err=%b exp %b", rsp_err, e_err[qh]));
          tb_check(rsp_we === e_we[qh], $sformatf("rsp_we=%b exp %b", rsp_we, e_we[qh]));
          tb_check(rsp_id === e_id[qh], $sformatf("rsp_id=%0h exp %0h", rsp_id, e_id[qh]));
          tb_check(((rsp_rdata ^ e_data[qh]) & e_known[qh]) === '0,
                   $sformatf("rsp_rdata=%h exp %h (known %h)", rsp_rdata, e_data[qh], e_known[qh]));
          if (e_we[qh] || e_err[qh]) tb_check(rsp_rdata === '0, "write-ack/error response data must be 0");
          tb_check(cyc - e_cyc[qh] >= longint'(LAT), "response earlier than READ_LATENCY");
          if (lat_exact) tb_check(cyc - e_cyc[qh] == longint'(LAT),
                                  $sformatf("latency %0d != %0d without backpressure", cyc - e_cyc[qh], LAT));
          if (trace_fd != 0)
            $fdisplay(trace_fd, "%0d %h %b %b %h", cyc, rsp_rdata & e_known[qh], rsp_err, rsp_we, rsp_id);
          qh = (qh + 1) % QD; qn--;
        end
      end

      // test-port read check (exact latency)
      if (tn > 0 && t_due[th] == cyc) begin
        tb_check(((tst_rdata ^ t_data[th]) & t_known[th]) === '0,
                 $sformatf("tst_rdata=%h exp %h", tst_rdata, t_data[th]));
        th = (th + 1) % QD; tn--;
      end

      // request acceptance
      if (req_valid && req_ready) begin
        n_acc++;
        if (trace_fd != 0) $fdisplay(trace_fd, "REQ %0d we=%b a=%h m=%h", cyc, req_we, req_addr, req_wmask);
        tb_check(!tst_active, "request accepted while tst_active");
        if (int'(req_addr) >= DEPTH) begin
          if (!req_we || WACK != 0 || 1) begin   // invalid address always answers with err
            e_data[qt] = '0; e_known[qt] = '1; e_err[qt] = 1; e_we[qt] = req_we; e_id[qt] = req_id;
            e_cyc[qt] = cyc; qt = (qt + 1) % QD; qn++;
          end
        end else if (req_we) begin
          model[req_addr] = (model[req_addr] & ~lane_bits(req_wmask)) | (req_wdata & lane_bits(req_wmask));
          known[req_addr] = known[req_addr] | lane_bits(req_wmask);
          if (WACK != 0) begin
            e_data[qt] = '0; e_known[qt] = '1; e_err[qt] = 0; e_we[qt] = 1; e_id[qt] = req_id;
            e_cyc[qt] = cyc; qt = (qt + 1) % QD; qn++;
          end
        end else begin
          e_data[qt] = model[req_addr]; e_known[qt] = known[req_addr]; e_err[qt] = 0; e_we[qt] = 0;
          e_id[qt] = req_id; e_cyc[qt] = cyc; qt = (qt + 1) % QD; qn++;
        end
      end

      // test-port operations
      if (tst_active && tst_ce) begin
        if (tst_we) begin
          model[tst_addr] = tst_wdata;
          known[tst_addr] = '1;
        end else begin
          t_data[tt] = model[tst_addr]; t_known[tt] = known[tst_addr]; t_due[tt] = cyc + longint'(LAT);
          tt = (tt + 1) % QD; tn++;
        end
      end
    end
  end

  // ------------------------------------------------------------ drivers
  int bp_pct = 0;   // probability (%) that rsp_ready is low in a cycle
  // An always block, not an 'initial forever' process: with Verilator 5.020 --timing, DUT combinational
  // logic was observed NOT to be re-evaluated after writes from a resumed process (stale collision
  // detection in the TDP wrapper), so stimulus is driven from a clocked always block.
  always @(negedge clk) begin : p_bp
    if (FIFO == 0) rsp_ready <= 1'b1;
    else           rsp_ready <= !rnd2_pct(bp_pct);
  end

  task automatic send(input logic we, input logic [AW-1:0] a, input logic [DW-1:0] d,
                      input logic [MW-1:0] m, input int gap);
    for (int g = 0; g < gap; g++) @(negedge clk);
    req_valid = 1'b1; req_we = we; req_addr = a; req_wdata = d; req_wmask = m;
    req_id = IDW'(rnd32());
    @(posedge clk);
    while (!req_ready) @(posedge clk);
    @(negedge clk);
    req_valid = 1'b0;
    req_wdata = DW'(rnd_vec());          // payload changes after acceptance only
  endtask

  task automatic wr(input int a, input logic [DW-1:0] d, input logic [MW-1:0] m);   // no default args (Icarus)
    send(1'b1, AW'(a), d, m, 0);
  endtask
  task automatic rd(input int a);
    send(1'b0, AW'(a), '0, '0, 0);
  endtask

  task automatic drain();
    int guard;
    guard = 0;
    while ((qn != 0 || busy) && guard < 100000) begin @(negedge clk); guard++; end   // poll away from the monitor's edge
    tb_check(qn == 0, "drain: responses missing (dropped transaction)");
    repeat (LAT + 3) @(posedge clk);
    tb_check(qn == 0 && !rsp_valid, "drain: extra response after drain");
    @(negedge clk);                       // stimulus is only ever driven on the falling edge
  endtask

  task automatic set_bp(input int pct);
    drain();
    @(posedge clk); #1;                   // change shared knobs away from both clock edges
    bp_pct = pct;
    lat_exact = (pct == 0);
    @(negedge clk);
  endtask

  // ------------------------------------------------------------ test sequence
  int nrand = 3000;
  int t0;
  logic [DW-1:0] v;
  logic [MW-1:0] m4;
  logic          r_we;
  bit            inv, gap_on;
  int            r_gap;
  int a;

  initial begin
    tb_seed_init();
    if (!$value$plusargs("nrand=%d", nrand)) nrand = 3000;
    if ($value$plusargs("trace=%s", trace_file)) trace_fd = $fopen(trace_file, "w");
    $display("SRAM_INFO tb_sram_sp DW=%0d DEPTH=%0d MW=%0d LAT=%0d BACKEND=%0d MACRO=%0d FIFO=%0d WACK=%0d",
             DW, DEPTH, MW, LAT, BACKEND, MACRO, FIFO, WACK);

    // P0 reset
    repeat (5) @(negedge clk);
    rst_n = 1'b1;
    @(posedge clk);
    tb_check(req_ready === 1'b0, "req_ready must stay 0 in the first cycle after reset");
    @(posedge clk);
    tb_check(req_ready === 1'b1, "req_ready must be 1 after reset release");
    set_bp(0);

    // P1 single write/read
    wr(0, DW'(64'hA5A5_5A5A_DEAD_BEEF), {MW{1'b1}});
    rd(0);
    drain();

    // P2 consecutive writes (full throughput)
    t0 = int'(cyc);
    for (int i = 0; i < 64 && i < DEPTH; i++) wr(i, DW'(rnd_vec()), {MW{1'b1}});
    if (FIFO >= LAT + 1 || FIFO == 0 || WACK == 0)
      tb_check(int'(cyc) - t0 <= ((DEPTH < 64) ? DEPTH : 64) + 2, "consecutive writes not back-to-back");
    // P3 consecutive reads
    t0 = int'(cyc);
    for (int i = 0; i < 64 && i < DEPTH; i++) rd(i);
    if (FIFO >= LAT + 1 || FIFO == 0)
      tb_check(int'(cyc) - t0 <= ((DEPTH < 64) ? DEPTH : 64) + 2, "consecutive reads not back-to-back");
    drain();

    // P4 alternating read/write
    for (int i = 0; i < 64; i++) begin
      a = rnd_below(DEPTH);
      v = DW'(rnd_vec()); m4 = MW'(rnd32());   // one RNG call per statement: portable order
      wr(a, v, m4);
      rd(a);
      rd(rnd_below(DEPTH));
    end
    drain();

    // P5 walking ones / zeros, all-0 / all-1
    for (int k = 0; k < 3; k++) begin
      a = (k == 0) ? 0 : (k == 1) ? DEPTH - 1 : DEPTH / 2;
      for (int b = 0; b < DW; b++) begin
        v = '0; v[b] = 1'b1;
        wr(a, v, {MW{1'b1}}); rd(a);
        wr(a, ~v, {MW{1'b1}}); rd(a);
      end
      wr(a, '0, {MW{1'b1}}); rd(a);
      wr(a, {DW{1'b1}}, {MW{1'b1}}); rd(a);
    end
    drain();

    // P6 byte-enable combinations
    a = rnd_below(DEPTH);
    if (MW <= 8) begin
      for (int m = 0; m < (1 << MW); m++) begin
        wr(a, {DW{1'b1}}, {MW{1'b1}});
        wr(a, DW'(rnd_vec()), MW'(m));
        rd(a);
        wr(a, '0, {MW{1'b1}});
        wr(a, DW'(rnd_vec()), MW'(m));
        rd(a);
      end
    end else begin
      for (int l = 0; l < MW; l++) begin            // walking single lane
        wr(a, '0, {MW{1'b1}}); wr(a, {DW{1'b1}}, MW'(1) << l); rd(a);
        wr(a, {DW{1'b1}}, {MW{1'b1}}); wr(a, '0, ~(MW'(1) << l)); rd(a);
      end
      for (int i = 0; i < 128; i++) begin v = DW'(rnd_vec()); m4 = MW'(rnd_vec()); wr(a, v, m4); rd(a); end
    end
    drain();

    // P7 boundaries and invalid addresses
    wr(0, DW'(rnd_vec()), {MW{1'b1}}); wr(1, DW'(rnd_vec()), {MW{1'b1}}); wr(DEPTH - 2, DW'(rnd_vec()), {MW{1'b1}}); wr(DEPTH - 1, DW'(rnd_vec()), {MW{1'b1}});
    rd(0); rd(1); rd(DEPTH - 2); rd(DEPTH - 1);
    if (NSPACE > DEPTH) begin
      for (int i = DEPTH; i < NSPACE && i < DEPTH + 16; i++) begin
        send(1'b1, AW'(i), DW'(rnd_vec()), '1, 0);
        send(1'b0, AW'(i), '0, '0, 0);
      end
      send(1'b0, AW'(NSPACE - 1), '0, '0, 0);
      // invalid writes must not have modified anything: re-read the top and bottom
      rd(0); rd(1); rd(DEPTH - 2); rd(DEPTH - 1);
    end
    drain();

    // P8 random traffic with gaps and backpressure
    for (int ph = 0; ph < 3; ph++) begin
      set_bp((ph == 0) ? 0 : (ph == 1) ? 30 : 70);
      for (int i = 0; i < nrand / 3; i++) begin
        // RNG calls never inside && / ?: (Verilator 5.020 does not short-circuit side-effecting calls)
        inv = 1'b0;
        if (NSPACE > DEPTH) inv = rnd_pct(5);
        if (inv) a = DEPTH + rnd_below(NSPACE - DEPTH);
        else     a = rnd_below(DEPTH);
        r_we = rnd_pct(45); v = DW'(rnd_vec()); m4 = MW'(rnd_vec());
        gap_on = rnd_pct(30);
        r_gap = 0;
        if (gap_on) r_gap = rnd_below(3);
        send(r_we, AW'(a), v, m4, r_gap);
      end
    end
    set_bp(0);

    // P9 MBIST test port: hand-over while functional reads are in flight
    for (int i = 0; i < 8; i++) rd(rnd_below(DEPTH));
    @(negedge clk);
    tst_active = 1'b1;
    req_valid = 1'b1; req_we = 1'b0; req_addr = '0;      // pending request must be held off
    for (int i = 0; i < 64; i++) begin
      @(negedge clk);
      tst_ce = 1'b1; tst_we = (i % 2 == 0); tst_addr = AW'(rnd_below(DEPTH)); tst_wdata = DW'(rnd_vec());
      if (i % 2 == 1) tst_addr = AW'(a);
      if (i % 2 == 0) a = int'(tst_addr);
      @(posedge clk);
      tb_check(!req_ready, "req_ready must be 0 in test mode");
    end
    @(negedge clk);
    tst_ce = 1'b0;
    repeat (LAT + 2) @(negedge clk);
    tst_active = 1'b0;
    @(posedge clk);
    while (!req_ready) @(posedge clk);                    // the held request is accepted now
    @(negedge clk);
    req_valid = 1'b0;
    drain();

    // P10 retention: fill, idle, read back
    for (int i = 0; i < DEPTH && i < 4096; i++) wr(i, DW'(rnd_vec()) ^ DW'(i), {MW{1'b1}});
    drain();
    repeat (300) @(negedge clk);
    for (int i = 0; i < DEPTH && i < 4096; i++) rd(i);
    drain();

    tb_check(n_rsp > 0 && n_acc > 0, "no traffic");
    $display("SRAM_METRIC accepted=%0d responses=%0d bp_stall_cycles=%0d cycles=%0d", n_acc, n_rsp, n_bp_stall, cyc);
    if (trace_fd != 0) $fclose(trace_fd);
    tb_finish("tb_sram_sp");
  end

  initial begin
    #(64'd200_000_000);
    tb_check(0, "global timeout");
    tb_finish("tb_sram_sp");
  end

endmodule

`default_nettype wire
