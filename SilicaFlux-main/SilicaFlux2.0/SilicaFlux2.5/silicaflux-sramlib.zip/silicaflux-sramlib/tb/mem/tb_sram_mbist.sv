// =============================================================================
// SilicaFlux SRAM Wrapper Library :: tb_sram_mbist   (self-checking)
// sram_mbist_march driving three kinds of library memories over the
// TestCore-format bus:
//   target 0   sram_sp   32 b x 100 (non-power-of-two)  via sram_mbist_adapter
//   target 1   sram_1r1w 16 b x 64                     via sram_mbist_adapter
//   target 2-5 sram_bank_controller, 4 banks x 32 x 32 b (bank b = target 2+b)
// Fault models are injected into the GENERIC backend (simulation-only hooks)
// one at a time; for each, the TB checks detection, the failing target, the
// FIRST failing address and March element predicted by hand from the March C-
// sequence, and that the other targets are not flagged.  Also: fault-free
// pass (solid and checkerboard), MATS+, stop-on-fail, empty selection =
// FAIL, adapter pipelining (+PIPE), and functional access after MBIST.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sram_mbist;
  parameter int LAT  = 1;
  parameter int PIPE = 0;            // test-path pipeline stages in each adapter (in and out)
  localparam int NT  = 6;
  localparam int BDW = 32, BAW = 7;
  localparam int TLAT = LAT + 2 * PIPE;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;

  // ------------------------------------------------------------ MBIST controller(s)
  logic           start = 0, bg_checker = 0, stop_on_fail = 0, use_mats = 0;
  logic [NT-1:0]  target_mask = '1;
  logic           busy_c, done_c, pass_c, fail_c, busy_m, done_m, pass_m, fail_m;
  logic [NT-1:0]  fmask_c, fmask_m;
  logic [2:0]     ft_c, ft_m;
  logic [BAW-1:0] fa_c, fa_m;
  logic [2:0]     fe_c, fe_m;
  logic [BDW-1:0] fs_c, fs_m;
  logic [15:0]    fc_c, fc_m;
  logic           act_c, ce_c, we_c, act_m, ce_m, we_m;
  logic [NT-1:0]  sel_c, sel_m;
  logic [BAW-1:0] ad_c, ad_m;
  logic [BDW-1:0] wd_c, wd_m;
  logic [NT*BDW-1:0] bus_rdata;

  localparam logic [NT*32-1:0] MAXA = {32'd31, 32'd31, 32'd31, 32'd31, 32'd63, 32'd99};
  localparam logic [NT*16-1:0] TDW  = {16'd32, 16'd32, 16'd32, 16'd32, 16'd16, 16'd32};

  sram_mbist_march #(.NUM_TARGETS(NT), .DW(BDW), .AW(BAW), .READ_LATENCY(TLAT), .TARGET_MAXADDR(MAXA),
                     .TARGET_DW(TDW), .ALGO(`SRAM_MBIST_MARCH_CM)) u_mbist_cm (
    .clk, .rst_n, .start(start && !use_mats), .target_mask, .bg_checker, .stop_on_fail,
    .busy(busy_c), .done(done_c), .pass(pass_c), .fail(fail_c), .fail_mask(fmask_c), .fail_target(ft_c),
    .fail_addr(fa_c), .fail_elem(fe_c), .fail_syndrome(fs_c), .fail_count(fc_c),
    .tst_active(act_c), .tst_sel(sel_c), .tst_ce(ce_c), .tst_we(we_c), .tst_addr(ad_c), .tst_wdata(wd_c),
    .tst_rdata(bus_rdata));
  sram_mbist_march #(.NUM_TARGETS(NT), .DW(BDW), .AW(BAW), .READ_LATENCY(TLAT), .TARGET_MAXADDR(MAXA),
                     .TARGET_DW(TDW), .ALGO(`SRAM_MBIST_MATS_P)) u_mbist_mats (
    .clk, .rst_n, .start(start && use_mats), .target_mask, .bg_checker, .stop_on_fail,
    .busy(busy_m), .done(done_m), .pass(pass_m), .fail(fail_m), .fail_mask(fmask_m), .fail_target(ft_m),
    .fail_addr(fa_m), .fail_elem(fe_m), .fail_syndrome(fs_m), .fail_count(fc_m),
    .tst_active(act_m), .tst_sel(sel_m), .tst_ce(ce_m), .tst_we(we_m), .tst_addr(ad_m), .tst_wdata(wd_m),
    .tst_rdata(bus_rdata));

  // bus mux (one controller active at a time)
  wire            b_act = use_mats ? act_m : act_c;
  wire [NT-1:0]   b_sel = use_mats ? sel_m : sel_c;
  wire            b_ce  = use_mats ? ce_m  : ce_c;
  wire            b_we  = use_mats ? we_m  : we_c;
  wire [BAW-1:0]  b_ad  = use_mats ? ad_m  : ad_c;
  wire [BDW-1:0]  b_wd  = use_mats ? wd_m  : wd_c;

  // ------------------------------------------------------------ target 0: sram_sp 32 x 100
  logic t0_req_valid = 0, t0_req_we = 0, t0_req_ready, t0_rsp_valid, t0_rsp_err, t0_rsp_we, t0_busy;
  logic [6:0]  t0_req_addr = '0;
  logic [31:0] t0_req_wdata = '0, t0_rsp_rdata;
  logic [0:0]  t0_rsp_id;
  logic        t0_ta, t0_tce, t0_twe;
  logic [6:0]  t0_tad;
  logic [31:0] t0_twd, t0_trd;
  sram_sp #(.DATA_WIDTH(32), .DEPTH(100), .MASK_WIDTH(4), .READ_LATENCY(LAT)) u_t0 (
    .clk, .rst_n, .req_valid(t0_req_valid), .req_ready(t0_req_ready), .req_we(t0_req_we), .req_addr(t0_req_addr),
    .req_wdata(t0_req_wdata), .req_wmask(4'hF), .req_id(1'b0), .rsp_valid(t0_rsp_valid), .rsp_ready(1'b1),
    .rsp_rdata(t0_rsp_rdata), .rsp_err(t0_rsp_err), .rsp_we(t0_rsp_we), .rsp_id(t0_rsp_id),
    .tst_active(t0_ta), .tst_ce(t0_tce), .tst_we(t0_twe), .tst_addr(t0_tad), .tst_wdata(t0_twd), .tst_rdata(t0_trd),
    .busy(t0_busy));
  sram_mbist_adapter #(.BUS_AW(BAW), .BUS_DW(BDW), .MEM_AW(7), .MEM_DW(32), .IN_PIPE(PIPE), .OUT_PIPE(PIPE)) u_ad0 (
    .clk, .bist_active(b_act), .bist_sel(b_sel[0]), .bist_ce(b_ce), .bist_we(b_we), .bist_addr(b_ad),
    .bist_wdata(b_wd), .bist_rdata(bus_rdata[0*BDW +: BDW]),
    .tst_active(t0_ta), .tst_ce(t0_tce), .tst_we(t0_twe), .tst_addr(t0_tad), .tst_wdata(t0_twd), .tst_rdata(t0_trd));

  // ------------------------------------------------------------ target 1: sram_1r1w 16 x 64
  logic        t1_ta, t1_tce, t1_twe, t1_wr_ready, t1_wr_err, t1_rd_ready, t1_rsp_valid, t1_rsp_err, t1_busy;
  logic [5:0]  t1_tad;
  logic [15:0] t1_twd, t1_trd, t1_rsp_rdata;
  logic [0:0]  t1_rsp_id;
  sram_1r1w #(.DATA_WIDTH(16), .DEPTH(64), .MASK_WIDTH(2), .READ_LATENCY(LAT)) u_t1 (
    .clk, .rst_n, .wr_valid(1'b0), .wr_ready(t1_wr_ready), .wr_addr('0), .wr_data('0), .wr_mask('0), .wr_err(t1_wr_err),
    .rd_valid(1'b0), .rd_ready(t1_rd_ready), .rd_addr('0), .rd_id(1'b0), .rsp_valid(t1_rsp_valid), .rsp_ready(1'b1),
    .rsp_rdata(t1_rsp_rdata), .rsp_err(t1_rsp_err), .rsp_id(t1_rsp_id),
    .tst_active(t1_ta), .tst_ce(t1_tce), .tst_we(t1_twe), .tst_addr(t1_tad), .tst_wdata(t1_twd), .tst_rdata(t1_trd),
    .busy(t1_busy));
  sram_mbist_adapter #(.BUS_AW(BAW), .BUS_DW(BDW), .MEM_AW(6), .MEM_DW(16), .IN_PIPE(PIPE), .OUT_PIPE(PIPE)) u_ad1 (
    .clk, .bist_active(b_act), .bist_sel(b_sel[1]), .bist_ce(b_ce), .bist_we(b_we), .bist_addr(b_ad),
    .bist_wdata(b_wd), .bist_rdata(bus_rdata[1*BDW +: BDW]),
    .tst_active(t1_ta), .tst_ce(t1_tce), .tst_we(t1_twe), .tst_addr(t1_tad), .tst_wdata(t1_twd), .tst_rdata(t1_trd));

  // ------------------------------------------------------------ targets 2..5: 4-bank controller
  logic [1:0]   bk_req_ready, bk_rsp_valid, bk_rsp_err, bk_rsp_we, bk_stall;
  logic [63:0]  bk_rsp_rdata;
  logic [7:0]   bk_rsp_id;
  logic         bk_busy;
  logic [127:0] bk_trd;
  logic         bk_ta [4];
  logic         bk_tce [4];
  logic         bk_twe [4];
  logic [4:0]   bk_tad [4];
  logic [31:0]  bk_twd [4];
  for (genvar b = 0; b < 4; b++) begin : g_bad
    sram_mbist_adapter #(.BUS_AW(BAW), .BUS_DW(BDW), .MEM_AW(5), .MEM_DW(32), .IN_PIPE(PIPE), .OUT_PIPE(PIPE)) u_ad (
      .clk, .bist_active(b_act), .bist_sel(b_sel[2+b]), .bist_ce(b_ce), .bist_we(b_we), .bist_addr(b_ad),
      .bist_wdata(b_wd), .bist_rdata(bus_rdata[(2+b)*BDW +: BDW]),
      .tst_active(bk_ta[b]), .tst_ce(bk_tce[b]), .tst_we(bk_twe[b]), .tst_addr(bk_tad[b]), .tst_wdata(bk_twd[b]),
      .tst_rdata(bk_trd[b*32 +: 32]));
  end
  // the bank controller has ONE shared test port with per-bank select
  wire [3:0] bk_sel = {bk_tce[3], bk_tce[2], bk_tce[1], bk_tce[0]};
  sram_bank_controller #(.NUM_MASTERS(2), .NUM_BANKS(4), .DATA_WIDTH(32), .BANK_DEPTH(32), .READ_LATENCY(LAT)) u_t2 (
    .clk, .rst_n, .m_req_valid('0), .m_req_ready(bk_req_ready), .m_req_we('0), .m_req_addr('0), .m_req_wdata('0),
    .m_req_wmask('0), .m_req_id('0), .m_rsp_valid(bk_rsp_valid), .m_rsp_ready('1), .m_rsp_rdata(bk_rsp_rdata),
    .m_rsp_err(bk_rsp_err), .m_rsp_we(bk_rsp_we), .m_rsp_id(bk_rsp_id), .m_stall_conflict(bk_stall),
    .tst_active(bk_ta[0]), .tst_sel(bk_sel), .tst_ce(|bk_sel),
    .tst_we(bk_sel[0] ? bk_twe[0] : bk_sel[1] ? bk_twe[1] : bk_sel[2] ? bk_twe[2] : bk_twe[3]),
    .tst_addr(bk_sel[0] ? bk_tad[0] : bk_sel[1] ? bk_tad[1] : bk_sel[2] ? bk_tad[2] : bk_tad[3]),
    .tst_wdata(bk_sel[0] ? bk_twd[0] : bk_sel[1] ? bk_twd[1] : bk_sel[2] ? bk_twd[2] : bk_twd[3]),
    .tst_rdata(bk_trd), .busy(bk_busy));

  // ------------------------------------------------------------ fault injection helpers
  task automatic set_fault(input int t, input int kind, input int a, input int b, input int a2, input int b2);
    case (t)
      0: begin u_t0.u_array.g_generic.u_mem.flt_kind = kind; u_t0.u_array.g_generic.u_mem.flt_addr = a;
               u_t0.u_array.g_generic.u_mem.flt_bit = b; u_t0.u_array.g_generic.u_mem.flt_addr2 = a2;
               u_t0.u_array.g_generic.u_mem.flt_bit2 = b2; end
      1: begin u_t1.u_array.g_generic.u_mem.flt_kind = kind; u_t1.u_array.g_generic.u_mem.flt_addr = a;
               u_t1.u_array.g_generic.u_mem.flt_bit = b; u_t1.u_array.g_generic.u_mem.flt_addr2 = a2;
               u_t1.u_array.g_generic.u_mem.flt_bit2 = b2; end
      2: begin u_t2.g_bank[0].u_bank.g_generic.u_mem.flt_kind = kind; u_t2.g_bank[0].u_bank.g_generic.u_mem.flt_addr = a;
               u_t2.g_bank[0].u_bank.g_generic.u_mem.flt_bit = b; u_t2.g_bank[0].u_bank.g_generic.u_mem.flt_addr2 = a2;
               u_t2.g_bank[0].u_bank.g_generic.u_mem.flt_bit2 = b2; end
      3: begin u_t2.g_bank[1].u_bank.g_generic.u_mem.flt_kind = kind; u_t2.g_bank[1].u_bank.g_generic.u_mem.flt_addr = a;
               u_t2.g_bank[1].u_bank.g_generic.u_mem.flt_bit = b; u_t2.g_bank[1].u_bank.g_generic.u_mem.flt_addr2 = a2;
               u_t2.g_bank[1].u_bank.g_generic.u_mem.flt_bit2 = b2; end
      4: begin u_t2.g_bank[2].u_bank.g_generic.u_mem.flt_kind = kind; u_t2.g_bank[2].u_bank.g_generic.u_mem.flt_addr = a;
               u_t2.g_bank[2].u_bank.g_generic.u_mem.flt_bit = b; u_t2.g_bank[2].u_bank.g_generic.u_mem.flt_addr2 = a2;
               u_t2.g_bank[2].u_bank.g_generic.u_mem.flt_bit2 = b2; end
      default: begin u_t2.g_bank[3].u_bank.g_generic.u_mem.flt_kind = kind; u_t2.g_bank[3].u_bank.g_generic.u_mem.flt_addr = a;
               u_t2.g_bank[3].u_bank.g_generic.u_mem.flt_bit = b; u_t2.g_bank[3].u_bank.g_generic.u_mem.flt_addr2 = a2;
               u_t2.g_bank[3].u_bank.g_generic.u_mem.flt_bit2 = b2; end
    endcase
  endtask

  // ------------------------------------------------------------ run helper
  longint run_cycles;
  task automatic run_mbist(input bit mats, input logic [NT-1:0] mask, input bit chk, input bit sof);
    longint c0;
    int guard;
    @(negedge clk);
    use_mats = mats; target_mask = mask; bg_checker = chk; stop_on_fail = sof;
    @(negedge clk);
    start = 1;
    @(negedge clk);
    start = 0;
    c0 = 0; guard = 0;
    while (!(mats ? done_m : done_c) && guard < 200000) begin @(negedge clk); guard++; end   // poll away from the monitor's edge
    run_cycles = guard;
    tb_check(guard < 200000, "MBIST run did not finish");
  endtask

  function automatic bit r_fail();         r_fail = use_mats ? fail_m : fail_c;        endfunction
  function automatic bit r_pass();         r_pass = use_mats ? pass_m : pass_c;        endfunction
  function automatic logic [NT-1:0] r_mask(); r_mask = use_mats ? fmask_m : fmask_c;  endfunction
  function automatic int r_tgt();          r_tgt  = int'(use_mats ? ft_m : ft_c);      endfunction
  function automatic int r_addr();         r_addr = int'(use_mats ? fa_m : fa_c);      endfunction
  function automatic int r_elem();         r_elem = int'(use_mats ? fe_m : fe_c);      endfunction

  task automatic expect_fault(input string nm, input int t, input int kind, input int a, input int b,
                              input int a2, input int b2, input int exp_addr, input int exp_elem);
    set_fault(t, kind, a, b, a2, b2);
    run_mbist(0, '1, 0, 0);
    tb_check(r_fail() && !r_pass(), $sformatf("%s: fault not detected", nm));
    tb_check(r_mask() == NT'(1) << t, $sformatf("%s: fail mask %b, expected only target %0d", nm, r_mask(), t));
    tb_check(r_tgt() == t, $sformatf("%s: first failing target %0d exp %0d", nm, r_tgt(), t));
    tb_check(r_addr() == exp_addr, $sformatf("%s: first failing address %0d exp %0d", nm, r_addr(), exp_addr));
    if (exp_elem >= 0) tb_check(r_elem() == exp_elem, $sformatf("%s: failing element %0d exp %0d", nm, r_elem(), exp_elem));
    $display("SRAM_INFO %-28s target=%0d addr=%0d elem=%0d syndrome=%h count=%0d cycles=%0d", nm, r_tgt(), r_addr(), r_elem(),
             fs_c, fc_c, run_cycles);
    set_fault(t, 0, 0, 0, 0, 0);
  endtask

  initial begin
    tb_seed_init();
    $display("SRAM_INFO tb_sram_mbist LAT=%0d PIPE=%0d (controller latency %0d)", LAT, PIPE, TLAT);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (3) @(negedge clk);

    // fault-free, March C-, solid and checkerboard
    run_mbist(0, '1, 0, 0);
    tb_check(pass_c && !fail_c && fc_c == 0, "fault-free March C- (solid) must pass");
    // expected cycles: per target 10N ops + NEXT + DRAIN(L+2) ; N = 100, 64, 32 x 4
    $display("SRAM_METRIC march_cm_cycles=%0d ops=%0d", run_cycles, 10 * (100 + 64 + 4 * 32));
    tb_check(run_cycles >= 10 * (100 + 64 + 4 * 32), "March C- finished in fewer cycles than 10N operations");
    run_mbist(0, '1, 1, 0);
    tb_check(pass_c && !fail_c, "fault-free March C- (checkerboard) must pass");

    // single-fault detection with hand-predicted first failure (solid background)
    expect_fault("SA0 t0 a37 b5",          0, 1, 37, 5,  0, 0, 37, 2);
    expect_fault("SA1 t0 a99 b31",         0, 2, 99, 31, 0, 0, 99, 1);
    expect_fault("TF-up t1 a10 b15",       1, 3, 10, 15, 0, 0, 10, 2);
    expect_fault("TF-down t1 a0 b0",       1, 4,  0,  0, 0, 0,  0, 3);
    expect_fault("CFid t2 a3b1->a20b7",    2, 5,  3,  1, 20, 7, 20, 1);
    expect_fault("AF t4 a5->a9",           4, 6,  5,  0, 9, 0,  9, 1);
    expect_fault("SA0 t5 a31 b0",          5, 1, 31,  0, 0, 0, 31, 2);

    // MATS+ detects a stuck-at-1
    set_fault(3, 2, 7, 9, 0, 0);
    run_mbist(1, '1, 0, 0);
    tb_check(fail_m && fmask_m == 6'b001000 && fa_m == 7, "MATS+ must detect SA1 at target 3 address 7");
    set_fault(3, 0, 0, 0, 0, 0);
    run_mbist(1, '1, 0, 0);
    tb_check(pass_m, "fault-free MATS+ must pass");

    // stop on first fail
    set_fault(0, 2, 1, 0, 0, 0);
    run_mbist(0, '1, 0, 1);
    tb_check(fail_c && fc_c >= 1 && fc_c <= TLAT && run_cycles < 200, "stop_on_fail must end the run at the first miscompare");
    set_fault(0, 0, 0, 0, 0, 0);

    // empty selection is a FAIL, never a false PASS
    run_mbist(0, '0, 0, 0);
    tb_check(done_c && fail_c && !pass_c, "empty target selection must report FAIL");

    // functional access works after MBIST (March C- leaves every word = background 0)
    @(negedge clk);
    t0_req_valid = 1; t0_req_we = 0; t0_req_addr = 7'd50;
    @(posedge clk); while (!t0_req_ready) @(posedge clk);
    @(negedge clk); t0_req_valid = 0;
    repeat (LAT) @(posedge clk);
    tb_check(t0_rsp_valid && t0_rsp_rdata == 32'h0 && !t0_rsp_err, "functional read after MBIST must return the MBIST background");
    @(negedge clk);
    t0_req_valid = 1; t0_req_we = 1; t0_req_addr = 7'd51; t0_req_wdata = 32'hCAFE_F00D;
    @(posedge clk); while (!t0_req_ready) @(posedge clk);
    @(negedge clk); t0_req_we = 0;
    @(posedge clk); while (!t0_req_ready) @(posedge clk);
    @(negedge clk); t0_req_valid = 0;
    repeat (LAT) @(posedge clk);
    tb_check(t0_rsp_valid && t0_rsp_rdata == 32'hCAFE_F00D, "functional write/read after MBIST");

    tb_finish("tb_sram_mbist");
  end

  initial begin
    #(64'd100_000_000);
    tb_check(0, "global timeout");
    tb_finish("tb_sram_mbist");
  end

endmodule

`default_nettype wire
