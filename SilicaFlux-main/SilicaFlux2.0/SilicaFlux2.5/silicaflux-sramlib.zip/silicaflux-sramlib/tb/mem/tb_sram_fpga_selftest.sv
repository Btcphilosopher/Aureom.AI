// =============================================================================
// SilicaFlux SRAM Wrapper Library :: tb_sram_fpga_selftest   (self-checking)
// Runs sram_fpga_selftest_top (GENERIC backend so a fault can be injected),
// decodes its UART output with an independent 8N1 receiver model and checks
// the LEDs:
//   run 1  fault-free             -> "SFX SRAM PASS\r\n", led = 0111
//   run 2  SA0 at addr 77 bit 3   -> "SFX SRAM FAIL P1 A004D\r\n", led = 1011
//          (pass 0 writes zeros and passes; pass 1 writes ones and must fail
//           at word 77 = 0x4D)
// =============================================================================
`timescale 1ns/1ps
`include "sram_defs.svh"
`default_nettype none

module tb_sram_fpga_selftest;
  localparam int CLK_HZ = 1_000_000, BAUD = 100_000, CPB = CLK_HZ / BAUD;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;            // power-on reset before the first clock edge
  logic [3:0] led;
  logic       tx;

  sram_fpga_selftest_top #(.CLK_HZ(CLK_HZ), .BAUD(BAUD), .DATA_WIDTH(32), .DEPTH(256), .READ_LATENCY(2),
                           .BACKEND(`SRAM_BACKEND_GENERIC)) u_top (
    .clk, .rst_n_btn(rst_n), .led, .uart_tx(tx));

  // independent UART receiver (samples mid-bit)
  string      rx_line = "";
  int         n_lines = 0;
  logic [7:0] rx_b;
  initial begin : p_rx
    forever begin
      @(negedge tx);
      repeat (CPB / 2) @(posedge clk);
      if (tx === 1'b0) begin                       // a real start bit
        for (int i = 0; i < 8; i++) begin
          repeat (CPB) @(posedge clk);
          rx_b[i] = tx;
        end
        repeat (CPB) @(posedge clk);
        tb_check(tx === 1'b1, "UART stop bit missing");
        rx_line = {rx_line, string'(rx_b)};
        if (rx_b == 8'h0A) n_lines = n_lines + 1;
      end
    end
  end

  task automatic run_and_expect(input string exp, input logic [3:0] exp_led);
    int guard, n0;
    rx_line = "";
    n0 = n_lines;
    @(negedge clk); rst_n = 1'b0;
    repeat (3) @(negedge clk); rst_n = 1'b1;
    guard = 0;
    while (n_lines == n0 && guard < 2_000_000) begin @(negedge clk); guard++; end
    repeat (CPB * 2) @(posedge clk);
    tb_check(n_lines == n0 + 1, "no UART report received");
    tb_check(rx_line == exp, $sformatf("UART report '%s' expected '%s'", rx_line, exp));
    tb_check(led === exp_led, $sformatf("LEDs %b expected %b", led, exp_led));
    $display("SRAM_INFO selftest report: %s", rx_line.substr(0, rx_line.len() - 3));
  endtask

  initial begin
    tb_seed_init();
    run_and_expect("SFX SRAM PASS\015\012", 4'b0111);   // octal CR LF (portable escapes)
    u_top.u_sram.u_array.g_generic.u_mem.flt_kind = 1;      // stuck-at-0
    u_top.u_sram.u_array.g_generic.u_mem.flt_addr = 77;
    u_top.u_sram.u_array.g_generic.u_mem.flt_bit  = 3;
    run_and_expect("SFX SRAM FAIL P1 A004D\015\012", 4'b1011);
    tb_finish("tb_sram_fpga_selftest");
  end

  initial begin
    #(64'd500_000_000);
    tb_check(0, "global timeout");
    tb_finish("tb_sram_fpga_selftest");
  end
endmodule

`default_nettype wire
