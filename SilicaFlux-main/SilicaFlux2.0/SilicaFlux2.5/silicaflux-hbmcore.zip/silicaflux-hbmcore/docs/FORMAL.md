# HBMCore formal verification

Formal harnesses, mutants and the runner live in `verification/formal/`; the machine-readable result of the last
run is `reports/formal.json`. Nothing in `rtl/` was changed or weakened: **no property failed on the real RTL**
(see [Findings](#findings); two design observations are listed there).

**Read this first: what "proved" means here.** Every result below is a statement about a *model*: the RTL module
instantiated with small parameters (DEPTH = 4, CPL_DEPTH = 4, N = 3, 2 bank groups, ...) inside a harness whose
environment is constrained by the `assume` statements listed per module. Results are labelled

* **UNBOUNDED** - `mode prove`: k-induction (z3) or property-directed reachability (ABC PDR / IC3) succeeded. The
  property holds for *all* reachable cycles of that model under those assumptions. It is not a statement about other
  parameter values (e.g. DEPTH = 16) and it is only as good as the assumptions.
* **BOUNDED** - `mode bmc` / `mode cover`: no counter-example (resp. the cover is reached) within `depth` clock
  cycles from reset. A bounded result is **not a proof**; it is reported as bounded in `reports/formal.json`
  (`"bounded": true`).

## 1. Files, tools, how to run

```
verification/formal/fv_<module>.sv    harness (DUT + environment assumptions + shadow model + assert/cover)
verification/formal/fv_<module>.sby   SymbiYosys tasks: prove | bmc | cover | mut_*
verification/formal/mutants/          gen_mutants.py + the generated buggy RTL copies (one injected bug each)
verification/formal/run_formal.sh     runs every task, writes reports/formal.json   (python driver: run_formal.py)
```

```
verification/formal/run_formal.sh                # everything (59 tasks), 2 solver processes at a time
verification/formal/run_formal.sh -m req_queue   # one module        (-t REGEX = task filter, --no-mutants, --mutants-only)
```

Toolchain (all pre-installed, nothing was installed): SymbiYosys + Yosys 0.71 with the built-in **yosys-slang**
frontend (YoWASP wheel in `/tmp/venv_yw`), solvers `z3` 4.8.12 and the ABC binary of the system Yosys (`yosys-abc`).
Practical notes that matter if you re-create this elsewhere:

* SystemVerilog with packages / packed structs is read with `read_slang`. In the WASM build threads are
  unavailable, so `read_slang -j 1` is mandatory. `-D SYNTHESIS` excludes the simulation-only `$error` blocks.
  The geometry macros of `rtl/sf_hbm_geom.svh` are overridden with `-D` (smaller row/col/id/src widths).
* **z3 must be run as `smtbmc --unroll z3`.** Without `--unroll` z3 does not terminate on these models (a one-step
  query of the 4-slot queue ran for > 1 minute; with `--unroll` it takes milliseconds).
* The system `boolector` is 1.5.118, which does not understand SMT-LIB `set-option`; it cannot be used with smtbmc.
* ABC `bmc3` (BMC) and `pdr` (IC3) are used where z3 is too slow. The yowasp-sby passes `pdr -v -l`, which the older
  system ABC rejects; `run_formal.py` interposes a 3-line wrapper that drops `-l`, and provides `yosys-witness`
  shims pointing at the YoWASP binaries. Counter-examples of ABC runs cannot be replayed (no yices installed), so
  every task whose *purpose* is to produce a counter-example (all mutants) uses z3.
* Assumptions are `assume` statements in clocked blocks; the DUT is held in reset (`init`) in cycle 0 only. Mid-operation
  reset is not covered. A "constant" free input (timing profile, tracked index) is a plain input plus
  `assume(init || x == x_prev)` because the slang frontend does not turn `(* anyconst *)` into a `$anyconst` cell
  (first attempt silently left the profile unconstrained; found because a counter showed an impossible value).

## 2. Results

| Module | Task | Properties | Mode | Depth | Engine | Result | Strength | s |
|---|---|---|---|---|---|---|---|---|
| `sf_hbm_bank_fsm` | `bmc` | B-1..B-5 (cross-check) | bmc | 16 | z3 | PASS | BOUNDED | 111 |
| `sf_hbm_bank_fsm` | `cover` | cover (legal env.) | cover | 24 | z3 | PASS | bounded (reachability) | 5 |
| `sf_hbm_bank_fsm` | `ill_bmc` | B-6 violation_o exact | bmc | 16 | z3 | PASS | BOUNDED | 6 |
| `sf_hbm_bank_fsm` | `ill_cover` | cover (illegal strobes) | cover | 16 | z3 | PASS | bounded (reachability) | 4 |
| `sf_hbm_bank_fsm` | `prove` | B-1..B-5 | prove | k=4 | z3 | PASS | **UNBOUNDED** | 8 |
| `sf_hbm_cdc_fifo` | `mc_bmc` | C-1..C-5 multiclock (cross-check) | bmc | 30 | ABC bmc3 | PASS | BOUNDED | 12 |
| `sf_hbm_cdc_fifo` | `mc_cover` | cover (multiclock) | cover | 28 | z3 | PASS | bounded (reachability) | 4 |
| `sf_hbm_cdc_fifo` | `mc_prove` | C-1..C-5 multiclock | prove | - | ABC PDR | PASS | **UNBOUNDED** | 12 |
| `sf_hbm_cdc_fifo` | `sc_cover` | cover (single clock) | cover | 16 | z3 | PASS | bounded (reachability) | 4 |
| `sf_hbm_cdc_fifo` | `sc_prove` | C-1..C-5, single-clock abstraction | prove | - | ABC PDR | PASS | **UNBOUNDED** | 4 |
| `sf_hbm_read_return` | `bmc` | R-1..R-6 (control) | bmc | 10 | ABC bmc3 | PASS | BOUNDED | 20 |
| `sf_hbm_read_return` | `bmc_data` | R-1..R-6 + 256-bit data | bmc | 10 | ABC bmc3 | PASS | BOUNDED | 170 |
| `sf_hbm_read_return` | `cover` | cover | cover | 16 | z3 | PASS | bounded (reachability) | 15 |
| `sf_hbm_refresh` | `blk_cover` | O1 observation (block_i free) | cover | 30 | z3 | PASS | bounded (reachability) | 2 |
| `sf_hbm_refresh` | `bmc` | F-1..F-4 (cross-check) | bmc | 120 | ABC bmc3 | PASS | BOUNDED | 12 |
| `sf_hbm_refresh` | `cover` | cover | cover | 40 | z3 | PASS | bounded (reachability) | 2 |
| `sf_hbm_refresh` | `prove` | F-1..F-4 | prove | - | ABC PDR | PASS | **UNBOUNDED** | 7 |
| `sf_hbm_req_queue` | `bmc` | Q-a..Q-f (cross-check) | bmc | 8 | z3 | PASS | BOUNDED | 124 |
| `sf_hbm_req_queue` | `cover` | cover | cover | 26 | z3 | PASS | bounded (reachability) | 28 |
| `sf_hbm_req_queue` | `prove` | Q-a..Q-f | prove | k=4 | z3 | PASS | **UNBOUNDED** | 16 |
| `sf_hbm_rsp_arb` | `cover` | cover | cover | 22 | z3 | PASS | bounded (reachability) | 78 |
| `sf_hbm_rsp_arb` | `fair` | A-5, A-6 (with E2) | prove | k=5 | z3 | PASS | **UNBOUNDED** | 8 |
| `sf_hbm_rsp_arb` | `prove` | A-1..A-4 | prove | k=6 | z3 | PASS | **UNBOUNDED** | 18 |
| `sf_hbm_timing` | `bmc` | T-1..T-4 (cross-check) | bmc | 20 | ABC bmc3 | PASS | BOUNDED | 7 |
| `sf_hbm_timing` | `cover` | cover | cover | 24 | z3 | PASS | bounded (reachability) | 7 |
| `sf_hbm_timing` | `prove` | T-1..T-4 | prove | - | ABC PDR | PASS | **UNBOUNDED** | 82 |

Totals: 59 tasks, 59 ok, 0 findings, 0 unexpected; 33/33 mutants killed. (`Depth`: BMC/cover depth, or `k` = induction depth; PDR has no depth.)
Generated from `reports/formal.json` (2026-11-15T09:16:10Z); RTL digests of that run are recorded in the same file.


## 3. Non-vacuity (cover statements and mutants)

Every module has a `cover` task: all `cover` statements must be reached within the depth, otherwise the task fails.
The covers include the "interesting states" (queue full / full-by-hold, every arbiter input granted, stall then
grant, read completion via return and via timeout, refresh forced / pulled-in, REF after PREA, tFAW as the only
blocker, FIFO full / wrap-around, ...). They are listed next to the assertions in each `fv_*.sv` file.

Mutants are generated from the real RTL by `mutants/gen_mutants.py`, which refuses to write a mutant unless the text
to replace occurs exactly once (`--check` is run by `run_formal.sh`, so a drifting RTL file is noticed). Each mutant
is one deliberate bug; the corresponding harness must FAIL on it with a counter-example.

| Module | Mutant | Injected bug | Outcome | Killed by (first failing assertion) |
|---|---|---|---|---|
| `sf_hbm_bank_fsm` | `bf_ras_ignored` | PRE legal before tRAS has elapsed | **killed** | `fv_bank_fsm.sv:165` `assert(act_seen && 16'(age_act) >= max1(tp.tras));` (cycle 3) |
| `sf_hbm_bank_fsm` | `bf_rcd_ignored` | RD legal immediately after ACT (tRCDRD not enforced) | **killed** | `fv_bank_fsm.sv:162` `if (can_rd)  assert(act_seen && 16'(age_act) >= max1(tp.trcdrd));` (cycle 3) |
| `sf_hbm_bank_fsm` | `bf_row_lost` | ACT does not latch the row address | **killed** | `fv_bank_fsm.sv:135` `if (pv_act) begin assert(row_open); assert(open_row == pv_row); end` (cycle 3) |
| `sf_hbm_bank_fsm` | `bf_trp_ignored` | bank reported idle (ACT legal) before tRP has elapsed | **killed** | `fv_bank_fsm.sv:127` `assert(idle     == (state == 2'd0));` (cycle 4) |
| `sf_hbm_bank_fsm` | `bf_viol_blind` | violation_o never reports an illegal ACT | **killed** | `fv_bank_fsm.sv:141` `assert(violation == pv_illegal);` (cycle 4) |
| `sf_hbm_bank_fsm` | `bf_wr_short` | WR->PRE recovery omits WL+burst (only tWR) | **killed** | `fv_bank_fsm.sv:158` `assert(dut.c_wr    == (wr_seen  ? remcnt(tp.wl + tp.burst + tp.twr, age_wr) : 16'd0));` (cycle 4) |
| `sf_hbm_cdc_fifo` | `cf_bin_ptr` | pointers cross the domains in BINARY instead of Gray code (multi-bit change per step) | **killed** | `fv_cdc_fifo.sv:84` `assert($countones(dut.wgray_next ^ dut.wgray_q) <= 1);` (cycle 3) |
| `sf_hbm_cdc_fifo` | `cf_empty_never` | empty_o is never raised (underflow: unwritten data is read) | **killed** | `fv_cdc_fifo.sv:94` `if (!empty) assert(occ >= 3'd1);` (cycle 3) |
| `sf_hbm_cdc_fifo` | `cf_full_never` | full_o is never raised (overflow: unread data is overwritten) | **killed** | `fv_cdc_fifo.sv:93` `if (!full)  assert(occ <= 3'(DEPTH - 1));` (cycle 9) |
| `sf_hbm_cdc_fifo` | `cf_mem_addr` | write address is off by one (data lands in the wrong slot) | **killed** | `fv_cdc_fifo.sv:98` `assert(dut.mem[trk[AW-1:0]] == trk_data);` (cycle 3) |
| `sf_hbm_read_return` | `rr_credit_early` | credit_o drops one entry early (credit low when not full) | **killed** | `fv_read_return.sv:203` `assert(credit == g_credit);` (cycle 5) |
| `sf_hbm_read_return` | `rr_data_corrupt` | returned read data is stored inverted | **killed** | `fv_read_return.sv:240` `assert(rsp.data == (trk_ctx.write ? '0 : trk_data_exp));` (cycle 4) |
| `sf_hbm_read_return` | `rr_done_sticky` | done flag of a released entry is not cleared (stale completion: duplicate response) | **killed** | `fv_read_return.sv:230` `if (dut.done_q[i]) assert(in_win);` (cycle 4) |
| `sf_hbm_read_return` | `rr_early_done` | a READ is marked done at allocation (completion released before the data/return event) | **killed** | `fv_read_return.sv:207` `assert(rsp_valid == (g_cnt != 3'd0 && eff_done[g_head]));` (cycle 3) |
| `sf_hbm_read_return` | `rr_early_timeout` | read-return timeout fires one cycle after the due time instead of after RD_TIMEOUT | **killed** | `fv_read_return.sv:246` `assert((cyc - 16'd1) - g_due[g_rd_q[g_rd_head_to]] >= 16'(RDT));` (cycle 5) |
| `sf_hbm_read_return` | `rr_pop_noready` | head is popped whenever it is done, even if the consumer is not ready (response lost under stall) | **killed** | `fv_read_return.sv:204` `assert(occ == g_cnt);` (cycle 4) |
| `sf_hbm_refresh` | `rf_hold_early` | ACT hold is dropped while the REF command is still pending (state R_REF) | **killed** | `fv_refresh.sv:122` `if (pv_hold_act && !hold_act) assert(pv_ref_granted);` (cycle 4) |
| `sf_hbm_refresh` | `rf_no_repay` | a granted REF does not repay the debt | **killed** | `fv_refresh.sv:117` `assert(!deadline_miss);` (cycle 27) |
| `sf_hbm_refresh` | `rf_ref_open` | sequencer skips the PREA when rows are open and goes straight to REF_AB | **killed** | `fv_refresh.sv:124` `if (mnt_valid && mnt_cmd.cmd == HCMD_REF_AB) assert(bk_row_open_i == '0);` (cycle 4) |
| `sf_hbm_refresh` | `rf_urgent_late` | urgent threshold off by one (debt > max_postpone instead of >=) | **killed** | `fv_refresh.sv:117` `assert(!deadline_miss);` (cycle 27) |
| `sf_hbm_req_queue` | `rq_dep_all` | new entry depends on EVERY older entry instead of only on conflicting ones (over-blocking) | **killed** | `fv_req_queue.sv:181` `assert(ent_blocked[i] == exp_blk);` (cycle 4) |
| `sf_hbm_req_queue` | `rq_dep_stale` | dependency column of a removed entry is not cleared (stale dep bit) | **killed** | `fv_req_queue.sv:181` `assert(ent_blocked[i] == exp_blk);` (cycle 5) |
| `sf_hbm_req_queue` | `rq_drop_hold` | allocation ignores hold_i (a slot whose write data is still owed can be re-allocated) | **killed** | `fv_req_queue.sv:117` `assert(push_ready == exp_ready);` (cycle 2) |
| `sf_hbm_req_queue` | `rq_full_nohold` | full_o ignores hold_i (full != 'no allocatable slot') | **killed** | `fv_req_queue.sv:134` `assert(full == !(\|(~ent_valid & ~hold_i)));` (cycle 2) |
| `sf_hbm_req_queue` | `rq_older_norem` | new entry's age row does not mask the entry removed in the same cycle (older bit set for an invalid slot) | **killed** | `fv_req_queue.sv:148` `assert(ent_older[i][j] == sold[i][j]);` (cycle 4) |
| `sf_hbm_req_queue` | `rq_overwrite` | payload of a push is always stored in slot 0 (overwrites a valid entry) | **killed** | `fv_req_queue.sv:129` `for (int i = 0; i < DEPTH; i++) if (ent_valid[i]) assert(ent_txn[i] == stxn[i]);` (cycle 3) |
| `sf_hbm_rsp_arb` | `ra_fixed_prio` | round-robin pointer always restarts at input 0 (fixed priority: starvation) | **killed** | `fv_rsp_arb.sv:142` `assert(int'(others[i]) + int'(rrdist(dut.ptr_q, i)) <= int'(N-1));` (cycle 3) |
| `sf_hbm_rsp_arb` | `ra_lost` | in_ready_o raised without out_ready_i (input consumed although the output was not accepted: lost response) | **killed** | `fv_rsp_arb.sv:83` `assert((in_ready != '0) == out_hs);` (cycle 2) |
| `sf_hbm_rsp_arb` | `ra_multi_grant` | in_ready_o raised for every input on a handshake (not exclusive; duplicates responses) | **killed** | `fv_rsp_arb.sv:82` `assert($onehot0(in_ready));` (cycle 2) |
| `sf_hbm_rsp_arb` | `ra_reselect` | no grant locking: the arbiter re-selects every cycle, even while the output is stalled | **killed** | `fv_rsp_arb.sv:110` `assert(sel == pv_sel);` (cycle 3) |
| `sf_hbm_timing` | `tm_ccd_l` | same-bank-group column-to-column spacing uses tCCD_S instead of tCCD_L | **killed** | `fv_timing.sv:110` `if (s_col[h]) assert(16'(a_col[h]) >= max1(h == g ? tp.tccd_l : tp.tccd_s));` (cycle 3) |
| `sf_hbm_timing` | `tm_faw_off` | tFAW window is never enforced | **killed** | `fv_timing.sv:106` `if (n_act == 3'd4) assert(16'(f3) >= max1(tp.tfaw));` (cycle 6) |
| `sf_hbm_timing` | `tm_wtr_l_short` | WR->RD same-bank-group turnaround uses tWTR_S | **killed** | `fv_timing.sv:111` `if (s_wr[h])  assert(16'(a_wr[h])  >= max1(tp.wl + tp.burst + (h == g ? tp.twtr_l : tp.twtr_s))` (cycle 3) |

Kill rate: 33 / 33.


## 4. Per-module assumptions and properties

Assumption tables: *assumption* | *why it is reasonable* | *what would break if it were false*.

Common to all harnesses: **R0** the DUT is held in reset in cycle 0 only and every property is guarded by `!init`
(*why*: the RTL reset is asynchronous and the harness cycle 0 is the reset cycle; *breaks*: reset asserted during
operation is not covered). **G** geometry macros shrink widths of fields the module only stores / compares
(*why*: no structure changes; *breaks*: nothing structural, but results are for the shrunk widths).

### 4.1 `sf_hbm_req_queue` (DEPTH = 4, AGE_W = 4)  -  `fv_req_queue.sv`

Geometry: ROW 2, COL 2, ID 2, SRC 1, BG 1, BA 1 bits. An independent shadow model (`sv`, `stxn`, `sold`, `sage`) is
rebuilt from the interface (allocation = lowest slot that is neither allocated nor held; payload at push; arrival-order
matrix; age); the DUT is compared with it, and `dut.dep_q / valid_q / older_q` are read by hierarchical name.

| ID | Property | Mode |
|----|----------|------|
| Q-a | push accepted only into a slot that is neither valid nor held; `push_ready_o`/`push_idx_o` equal the independent allocator | prove |
| Q-b | `ent_valid_o == shadow valid`; payload of every valid entry == the payload that was pushed (never overwritten, stable until removal) | prove |
| Q-c | removal of an invalid slot never happens: the environment removes only slots its own bookkeeping holds (E1) and the DUT's valid bit agrees (`rem_valid_i => ent_valid_o[rem_idx_i]`) | prove |
| Q-d | `occ_o == popcount(valid)` (no overflow of the counter), `occ_wr/occ_rd` split, `empty_o`, `full_o == !(|(~valid & ~hold))` (full <=> no allocatable slot) | prove |
| Q-e | `ent_older_o` equals arrival order; irreflexive, antisymmetric, total, transitive over valid entries; exactly one oldest entry iff any entry valid; `older[i][j] => valid[j]`; `age[j] >= age[i]` for older j; ages equal the shadow age; `dep[i][j] => valid[j] && older[i][j]` (all i, j) | prove |
| Q-f | never blocked by a younger entry (`dep[i][j]` is 0 if j is younger); `dep[i][j] == valid[j] && older[i][j] && hbm_conflict(i, j)`; `ent_blocked_o[i]` equals "exists older valid conflicting entry"; the oldest entry is never blocked | prove |

| Assumption | Why reasonable | What breaks if false |
|---|---|---|
| E1 `rem_valid_i => shadow_allocated[rem_idx_i]` | the scheduler removes only an entry it issued from this queue (the RTL `$error` flags the opposite) | property Q-c is only a statement under E1; behaviour of a removal of an invalid slot is not claimed (the column-clearing of dep/older could then hit a slot allocated in the same cycle) |
| `hold_i`, `push_valid_i`, `push_txn_i` completely free | most general stimulus: includes push while full, hold toggling every cycle, same-cycle push and remove | none (no assumption) |
| AGE_W = 4 instead of 16 | age saturation (reached by the cover at 15 cycles) has the same logic at any width | width-specific overflow of a 16-bit age is not exercised |

### 4.2 `sf_hbm_bank_fsm`  -  `fv_bank_fsm.sv`

Symbolic profile (all used fields 0..4; WL <= 3, burst <= 2, tWR <= 3), ROW = 4 bits. Two environments chosen by a macro:
the **legal** one proves state/timing properties; the **illegal** one (only E0, E1) proves `violation_o` exactness.
The timing proof ties the DUT's down-counters to ghost "cycles since event" counters by exact inductive invariants
(`dut.c_rcdrd == remcnt(tRCDRD, age_act)` etc.), which is what makes the result UNBOUNDED.

| ID | Property | Mode |
|----|----------|------|
| B-1 | `row_open_o == (state_o==ACTIVE)`, `idle_o == (state_o==IDLE)`, PRECHARGING/REFRESHING imply closed and not idle | prove |
| B-2 | `can_act => !row_open && idle`; `can_rd/can_wr/can_pre => row_open`; `can_act` excludes the others | prove |
| B-3 | after ACT: bank open and `open_row_o` == ACT row; only ACT changes the row; opens only through ACT; PRE closes; open stays open until PRE | prove |
| B-4 | ACT->RD >= tRCDRD, ACT->WR >= tRCDWR, ACT->PRE >= tRAS, RD->PRE >= tRTP, WR->PRE >= WL+BL+tWR, ACT->ACT >= tRC, PRE->ACT >= tRP, REF->ACT >= tRFC(PB) (a rule of 0 or 1 means "next cycle") | prove (+ bmc 16) |
| B-5 | legal environment: `violation_o` never asserted | prove |
| B-6 | free environment: `violation_o == "an illegal strobe was applied last cycle"` (exact), and it IS asserted for an illegal strobe (covers: `violation_o` asserted, after an illegal ACT, while the bank is open, in/after refresh) | bmc 16 + cover |

| Assumption | Why reasonable | What breaks if false |
|---|---|---|
| E0 profile constant and small | the profile is selected once from `sf_hbm_profile_pkg`; small values keep the 16-bit counters tractable (symbolic over every value in range) | values > 4 not covered (same logic); a profile that changes while a bank is mid-timing is not covered |
| E1 at most one command per cycle (so never ACT with PRE) | one command bus per pseudo-channel (RTL header, and the `$error` in the RTL) | ACT+PRE in one cycle makes the counters ambiguous |
| E2 ACT only when `can_act`; RD/WR only when `can_rd`/`can_wr` | contract: "a correct scheduler never causes a violation" | violation_o fires (that is B-6) |
| E3 RD/WR address the open row | scheduler addresses the open row after ACT | a row miss raises `violation_o` |
| E4 PRE of an open bank only when `can_pre` (PRE to a closed bank is a legal no-op) | tRAS/tRTP/tWR are the scheduler's responsibility | early PRE: violation_o, B-4 not claimed |
| E5 REF only on an idle, tRC-clean bank | sequencing in `sf_hbm_refresh` | REF on an open bank: violation_o |

### 4.3 `sf_hbm_rsp_arb` (N = 3)  -  `fv_rsp_arb.sv`

Geometry SRC 1, ID 2 bits (data stays 256 bits). The fairness task drops all payload comparisons (irrelevant to
fairness, keeps the model small).

| ID | Property | Mode |
|----|----------|------|
| A-1 | exclusivity: `$onehot0(in_ready_o)`; `in_ready_o != 0 <=> out_valid_o && out_ready_i`; ready only for a valid input | prove |
| A-2 | `out_valid_o => in_valid_i[sel_o]`, `sel_o < N`, `out_rsp_o == in_rsp_i[sel_o]` | prove |
| A-3 | no duplicate / lost / invented response: output handshake <=> exactly one input handshake with identical payload | prove |
| A-4 | `out_valid_o && !out_ready_i` => next cycle `out_valid_o`, same `sel_o`, same `out_rsp_o` | prove |
| A-5 | round-robin: while input i waits (valid, not granted), at most N-1 = 2 grants go to other inputs (no timing assumption) | prove (`fair`) |
| A-6 | bounded wait: with E2, input i waits <= 11 cycles (3 handshakes, the first within 3 cycles, then <= 4 each) | prove (`fair`) |

The fairness proof uses three strengthening invariants (`others[i] + rrdist(ptr, i) <= N-1`, `waitc <= 4*others +
ready-low-run`, and an ordering invariant for a locked winner); they are asserted in the harness and proved.

| Assumption | Why reasonable | What breaks if false |
|---|---|---|
| E1 an input that is valid and not granted stays valid with unchanged payload | AXI-style source protocol; the RTL `$error` ("locked input withdrew its valid") flags the opposite | a withdrawing input makes `out_valid_o` drop while stalled (A-4 false) and a changing payload breaks stability |
| E2 (`fair` task only) `out_ready_i` is high at least once in every 4 cycles | the response consumer is not stalled forever; K = 4 is a modelling constant | without it nothing can be said about waiting time (A-5, which needs no timing assumption, still holds) |

### 4.4 `sf_hbm_read_return` (CPL_DEPTH = 4, RD_TIMEOUT = 3, RD_EXTRA_LAT = 0)  -  `fv_read_return.sv`  -  **BOUNDED**

A ghost model built from the interface only: sequence numbers carried in `ctx.id`, ghost occupancy / slot pointers,
per-slot "completion event" flags (error at allocation, write at `wr_done`, read at `rd_valid_i` matched to the
oldest outstanding read, or the timeout pulse), independent due times. The DUT's `rsp_valid_o` must equal "head entry
has had its completion event" *exactly*. A tracked symbolic sequence number checks payload integrity.

| ID | Property | Mode |
|----|----------|------|
| R-1 | `credit_o == (occupancy != CPL_DEPTH)` (low exactly when full), `occ_o`, `push_idx_o` equal the ghost | bmc 10 |
| R-2 | responses leave in allocation order: `rsp.id == pop sequence`; `rsp_valid_o == (occupancy != 0 && head completed)`; no response for an entry that was never allocated | bmc 10 |
| R-3 | a READ entry is valid for output only after `rd_valid_i` or the timeout path (never because it was allocated); WRITE only after `wr_done`; no duplicate completion (a freed slot cannot present a stale done; `done_q[i]` only inside the allocated window) | bmc 10 |
| R-4 | `rsp_valid_o` and `rsp_o` (src/id/write/err/corrected, and data in `bmc_data`) stable while `!rsp_ready_i` | bmc 10 |
| R-5 | tracked entry: src/id/write/err/corrected (and 256-bit data, task `bmc_data`) equal what was pushed / returned; timeout => `HERR_FLUSHED`, data 0 | bmc 10 |
| R-6 | timeout only when `cyc - due >= RD_TIMEOUT` (never early); `rd_unexpected_o` never; `rd_timing_err_o` exactly when data arrives at a cycle other than the due cycle | bmc 10 |

| Assumption | Why reasonable | What breaks if false |
|---|---|---|
| E0/E2 `tp` constant, RL <= 2; `cyc_i` is a free-running 16-bit counter from 0 | profile static; the parent supplies a global counter | other RL values / counter wrap not covered |
| E1 `push_kind != 3`; `ctx.write == (kind==1)`; `ctx.id` = allocation sequence number (a label) | kind 3 is undefined; id is never decoded by the DUT | kind 3 would be a write that never completes |
| E3 `rd_valid_i` only while the environment model says a read is outstanding (reads allocated - returns - timeouts already reported) | PHY contract: one return per read command; see O2 | an unmatched return pulses `rd_unexpected_o`; a late return after a timeout is attributed to the next read |
| E4 `wr_done` only for an allocated, not yet completed write allocated in an earlier cycle | write-data engine completes after the column command | duplicate/early done would complete the wrong entry (same-cycle allocate+done is conservatively excluded) |

### 4.5 `sf_hbm_refresh` (all-bank mode, 4 banks, symbolic profile)  -  `fv_refresh.sv`

Profile: 24 <= tREFI <= 30, 1 <= max_postpone <= 3, 0 <= max_pullin <= 3 (`HBM_BG_BITS=1`, `HBM_BA_BITS=1`).
`block_i` (new RTL input), `pause_i`, `clear_i` are tied to 0 and `enable_i` to 1.

| ID | Property | Mode |
|----|----------|------|
| F-1 | `-max_pullin <= debt_o <= max_postpone` (hence also `<= max_postpone+1`) and `deadline_miss_o` never fires | prove (PDR) + bmc 120 |
| F-2 | `hold_act_o` is released only in the cycle after a REF_AB grant | prove + bmc |
| F-3 | REF_AB is never presented (nor granted) while any bank row is open | prove + bmc |
| F-4 | only PREA / REF_AB are presented in all-bank mode; `active_o => hold_act_o`; `ev_ref_o == REF granted last cycle` | prove + bmc |

| Assumption | Why reasonable | What breaks if false |
|---|---|---|
| E0 profile constant; 24 <= tREFI <= 30; mp 1..3; mu 0..3 | HYPOTHETICAL_SIM profiles have mp 2..4, tREFI >= 240 | **tREFI must exceed the sequence latency (~13 cycles with K = 3)**: with a shorter tREFI a new debt unit arrives before the refresh finishes and `deadline_miss_o` is *expected* to fire |
| E1 `enable_i=1`, `pause_i=0`, `block_i=0`, `clear_i=0`, mode = REFMODE_AB, `eager`/`pullin_en`/`queue_idle_i` free | these paths are separate features; see O1 | with pause/block asserted the hold is released without a REF (by design), F-2 is then false |
| E2 a presented command is granted within KG = 3 cycles; grant only for a presented command | the scheduler arbitrates maintenance commands with priority (`mnt_prio_o`) and "only grants them when every timing rule allows" | without a grant bound refresh can be starved and the debt grows without bound |
| E3 `bk_idle_i[b] => !bk_row_open_i[b]` | a precharged bank has no open row | the two inputs would contradict each other |
| E4 a row can only open in a cycle after `hold_act_o` was low | the scheduler honours the ACT hold | an ACT slipping in after the hold lets a row open under REF (F-3 false) |
| E5 the cycle after a granted PREA all rows are closed | PREA semantics | PREWAIT would see open rows again |
| E6 a bank that is neither open nor idle (precharging / refreshing) becomes idle within KI = 3 cycles | tRP / tRFC are finite; real values are larger but tREFI is larger still (3900 vs 260 in `sim_ref`) | no bound on the sequence latency |
| E7 an idle bank stays idle unless a row is opened or a REF was granted last cycle | banks do not spontaneously leave idle | without it the banks need never be simultaneously idle (this exact counter-example appeared during development) |

### 4.6 `sf_hbm_cdc_fifo` (WIDTH = 2, DEPTH = 4)  -  `fv_cdc_fifo.sv`

`multiclock on`: `wclk`/`rclk` are free inputs, so every interleaving of write and read edges (any ratio / phase,
simultaneous edges) is explored. A ghost model counts ACCEPTED pushes / pops (mod 8) and tracks one symbolic word.

| ID | Property | Mode |
|----|----------|------|
| C-1 | pointer algebra: next Gray pointer differs in <= 1 bit; `gray == bin2gray(bin)`; DUT binary pointers == ghost counts | mc prove (PDR) |
| C-2 | no overflow: accepted pushes - accepted pops <= DEPTH (full never allows overwriting unread data) | mc prove |
| C-3 | no underflow: accepted pops <= accepted pushes (empty never allows reading unwritten data) | mc prove |
| C-4 | `!full_o => occupancy <= DEPTH-1`; `!empty_o => occupancy >= 1` (never optimistic) | mc prove |
| C-5 | order/integrity: when tracked word n is at the head (`!empty_o`, pops == n) it was pushed and `rdata_o` equals the pushed value | mc prove |

Tasks: `mc_prove` (multiclock, ABC PDR, UNBOUNDED), `mc_bmc` (multiclock BMC depth 30, BOUNDED, cross-check),
`sc_prove` (single-clock abstraction `wclk == rclk`, UNBOUNDED for that abstraction), covers.

| Assumption | Why reasonable | What breaks if false |
|---|---|---|
| push/pop/wdata free (push while full and pop while empty are legal stimulus, ignored by contract) | the module contract says they are ignored | none |
| each domain's reset is released by its own first clock edge (both start in reset) | the documented reset-domain-crossing rule (`sf_hbm_rst_sync`) | releasing a domain asynchronously is not covered |
| synchroniser flops sample the pointer atomically (no metastability, no per-bit skew) | skew is not representable without editing the RTL; **C-1 makes it safe**: each pointer update changes at most one bit, so a bit-skewed sample equals either the old or the new pointer, both of which the atomic model already contains | a non-Gray pointer would NOT be safe: mutant `cf_bin_ptr` is killed by C-1 |
| tracked index `trk` constant | symbolic word number | - |

### 4.7 `sf_hbm_timing` (2 bank groups, symbolic small profile; stretch)  -  `fv_timing.sv`

| ID | Property | Mode |
|----|----------|------|
| T-1 | `ok_act_o[g]` high => tRRD_S/L vs every earlier ACT and, with four ACTs seen, the 4th most recent ACT is >= tFAW old | prove (PDR) + bmc 20 |
| T-2 | `ok_rd_o`/`ok_wr_o` high => tCCD_S/L vs every earlier column command; WR->RD >= WL+BL+tWTR_S/L; RD->WR >= RL+BL+2-WL (>= 1) | prove + bmc |
| T-3 | `ok_act_o`/`ok_ref_o` high => REF_AB->ACT/REF >= tRFC; every `ok_*` low until tMRD / tXP / tXS after MRS / PDX / SRX | prove + bmc |
| T-4 | legal environment => `violation_o` never fires | prove + bmc |

| Assumption | Why reasonable | What breaks if false |
|---|---|---|
| E0 constant profile; tRRD/tCCD/tRFC/tMRD/tXP/tXS <= 4, tFAW <= 6, tWTR <= 3, WL <= 3, RL <= 4, burst <= 2 | small constants keep the 16-bit counters tractable | larger values not covered |
| E1 one command per cycle (ACT, RD, WR, REF_AB, MRS, PDX, SRX) | single command bus | two commands in a cycle make the counter updates ambiguous (RTL `$error`) |
| E2 a command is issued only while its `ok_*` is high | contract: "`ok_*` is the legality of issuing this cycle" | `violation_o` fires |


## 5. Findings

**No property failed on the unmodified RTL.** The only counter-examples seen during development were harness
modelling errors (shadow reset in cycle 0; a ghost array indexed by queue position instead of slot; the stray
anyconst; a bank-idle environment that let the four banks toggle idle independently so that "all banks idle" never
held) and were fixed in the harness, never by weakening a property or touching `rtl/`.

Observations (not property failures; each is outside what the module promises, but integration should know):

* **O1 - `block_i` only gates the START of a refresh sequence and aborts `R_HOLD`; it does not stop a sequence that is
  already past `R_HOLD`.** `block_i` (new input) gates `start` and aborts `R_HOLD` back to `R_IDLE` (which drops
  `hold_act_o` *without* a REF), exactly like `pause_i`. In `R_PREA`, `R_PREWAIT` and `R_REF` it is ignored: PREA / REF_AB
  are still presented while `block_i` is high. The header comment of `sf_hbm_refresh.sv` describes exactly this
  ("stops a sequence from starting - and aborts one still in its HOLD phase"), but the port comment still says "never
  START or continue a sequence". Formal evidence: `fv_refresh.sby:blk_cover` reaches `block_i && mnt_valid && cmd ==
  REF_AB`, `block_i && mnt_valid && cmd == PREA`, and an ACT-hold release with no REF granted. Properties F-1..F-4 are
  therefore stated under `block_i = pause_i = 0` (E1); with either asserted, "hold released => REF granted" is false by
  design. If the power module can raise `block_i` while a sequence is running, something downstream has to absorb the
  PREA/REF.
* **O2 - a late read return after a timeout is indistinguishable from the next read's return.** `sf_hbm_read_return`
  matches PHY data to the *oldest outstanding* read; after a timeout (`HERR_FLUSHED`) the entry is retired, so if the
  PHY later delivers the data of that read it is attributed to the next outstanding read (or flagged
  `rd_unexpected_o` if none). This is the documented contract (data arrives at exactly t+1+RL; the timeout is only a
  safety net for a lost return), and it is assumption E3 of the read-return harness; the formal result says nothing
  about a PHY that returns data later than `RD_TIMEOUT`.
* **O3 - `sf_hbm_req_queue`'s simulation check `push_valid_i && !any_free && push_fire` is unreachable**
  (`push_fire = push_valid_i && any_free`), so that `$error` can never fire. Harmless: a push while full is simply
  ignored, which the harness leaves legal (push_valid_i is unconstrained).

## 6. What is not covered

* Parameters other than those in the harnesses (the properties are structural, but nothing was run at DEPTH = 16 etc.).
* `sf_hbm_read_return`: BOUNDED only (depth 10). k-induction fails for want of an invariant over the 16-bit cycle
  counter / due-time FIFO, and ABC PDR did not converge in 200 s (frame 9, still growing). A longer BMC or
  hand-written invariants would be the next step.
* `sf_hbm_refresh` per-bank (REF_PB) mode, pause/block/clear paths and `enable_i` toggling are not verified (tied off).
* CDC: metastability and bit-skew of the 2-flop synchronisers are not modelled (see the cdc section for the argument
  that the Gray-adjacency property makes this safe); reset-domain crossing is only modelled as "each domain released by
  its own first clock edge".
* Liveness is only checked as bounded waiting (arbiter, refresh debt); there is no fairness proof for the scheduler,
  and the remaining RTL modules (scheduler, pseudochannel, write_data, ecc_ras, power_state, ...) have no formal harness.
