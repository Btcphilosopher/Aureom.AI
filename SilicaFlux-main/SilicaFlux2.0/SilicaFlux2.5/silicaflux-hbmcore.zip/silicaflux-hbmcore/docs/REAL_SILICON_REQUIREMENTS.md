# What real HBM4 silicon integration still needs

Passing every test in this repository does **not** make the controller silicon-ready. This is the (non-exhaustive) list of what is missing.
`MISSING_SPEC.md` is the machine-generated register; this page groups it by who has to supply it.

## From the standards and the DRAM vendor
1. **JESD270-4 (or the current HBM4 revision)**: the real command set and pin-level encodings, command-bus partitioning (row/column), timing constraint
   table with the values of the chosen speed grade, burst length / access granularity, bank-group architecture, refresh modes (all-bank / same-bank / per-bank) and
   their postpone/pull-in limits, DRFM/RFM definition, power states and exit latencies, mode-register map and mandatory initialisation sequence, ECC / CRC / parity features,
   temperature-related refresh requirements.
2. **Vendor datasheet**: density-specific geometry (rows, columns, banks), supported speed grades, VDD/VDDQ, thermal limits, RAS features and device-side ECC behaviour.
3. A validated **HBM4 DRAM model** (vendor or independent) to replace `hbm4_dram_model.sv`. Without one, timing correctness against the real device is unverified.
   (DRAMsim3 / Ramulator 2.0 were *not* integrated: no HBM4-capable configuration could be validated here; an HBM3 configuration with more channels must not be called HBM4.)

## From the PHY / IP side
4. **Licensed HBM4 PHY and its interface specification** (DFI 5.1-compatible or vendor-specific), clock ratio / data-width conversion, training, calibration, impedance, power-up
   sequence, PHY status/alert/CRC signals, supported dynamic frequency/voltage switching. HBMCore treats training as an external service and provides only an unimplemented backend stub.
5. TSV/base-die and microbump interface, **I/O electrical** characterisation, interposer / package design, SI/PI signoff, thermal solution.
6. Controller-to-PHY clocking, reset sequencing and CDC signoff with the actual PHY clock/reset structure.

## From the implementation flow
7. Target **process node + PDK**; synthesis with real libraries, STA at the PHY/NoC clock targets, floorplan/placement/routing (OpenROAD/commercial), DFT, power analysis,
   LVS/DRC, signoff. (This environment had no PDK, no OpenROAD and no OpenSTA: only technology-independent proxy statistics exist in `reports/synth/`.)
8. Physical clustering confirmation (`PHYSICAL_DESIGN.md` guidance is untested in P&R).
9. Pipelining of the scheduler selection stage (single-stage ~114 gate levels in the generic netlist) and balanced SECDED XOR trees, before any frequency target is claimed.

## From verification
10. Coverage closure (no functional/line coverage metric has been collected), constrained-random UVM-style environment, gate-level/back-annotated simulation, emulation with the real PHY.
11. Unbounded formal where only bounded proofs exist (see `FORMAL.md` when present), RowHammer threat model + device behaviour before any mitigation claim.
12. Compliance testing against the standard's test suite - HBMCore claims **no** compliance.

## From the SoC
13. A memory map able to address a multi-GiB stack (the NoC address is 32-bit), a request fabric with one ingress per channel/cluster (the single-port top is limited to 32 B/cycle),
    integration of the compute-tile / tile-interface path that does not compile from the current tree, and real TensorCore operand buffers.
