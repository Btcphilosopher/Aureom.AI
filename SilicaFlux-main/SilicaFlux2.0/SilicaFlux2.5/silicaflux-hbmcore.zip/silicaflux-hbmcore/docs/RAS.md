# RAS: data protection, error reporting, fault injection

> **Status.** The controller-level SECDED and the 10-bit-per-granule sideband are an `ENGINEERING_ASSUMPTION` (`docs/STANDARDS_MATRIX.md` RAS-01); whether an HBM4 PHY/DRAM interface offers such a sideband is `UNVERIFIED`.
> On-die ECC (RAS-02), PHY/interface parity or CRC (RAS-03) and read-modify-write for partial writes (RAS-04) are `UNIMPLEMENTED`. RowHammer mitigation (REF-04) is `UNIMPLEMENTED`: **no RowHammer protection is claimed**.

Code: `rtl/sf_hbm_ecc_ras.sv` (one instance per pseudo-channel, `u_ecc`). Normative code definition: `docs/RAS_CODE.md` (not restated beyond what the RTL needs).

## 1. Four separate mechanisms (module header)

| # | mechanism | what HBMCore does | status |
|---|---|---|---|
| 1 | **On-die DRAM ECC** | inside the DRAM; invisible to HBMCore except through an optional status/alert input `ondie_event_i`, which is **counted** (`ondie_cnt_o`), never "corrected" | RAS-02 `UNIMPLEMENTED` (event counter only); the behavioural DRAM model does not model it ("OMITTED: on-die ECC") |
| 2 | **Controller SECDED** | `sf_hbm_ecc_ras`: (265,256) Hamming + overall parity over one 32 B granule = 9 + 1 = `HBM_ECC_W = 10` sideband bits | RAS-01 `ENGINEERING_ASSUMPTION` (sideband availability `UNVERIFIED`) |
| 3 | **PHY/interface check** | parity/CRC/alert seen by the PHY arrive as `phy_event_i` and as the per-return flag `rerr_o`; both only increment `phy_cnt_o` | RAS-03 `UNIMPLEMENTED` (event counter only) |
| 4 | **System end-to-end** | not implemented; "Do not assume (1) provides (4)" | none |

The mechanisms are independent: enabling (2) does not change what (1), (3) or (4) do, and none of them substitutes for another.

## 2. Controller SECDED behaviour

Enable: `ecc_en_i` (`cfg.ecc_en`, CSR `ECCCFG[0]`).

| path | `ecc_en = 0` | `ecc_en = 1` |
|---|---|---|
| write | `wecc_o = 0`; data unchanged (apart from injection) | `wecc_o = enc(wdata_i)`, 10 check bits computed **before** any injected flip; combinational |
| read | `rdata_o = r_in` (read data after optional injection), `rerr_o = NONE`, no counters | decode `dec(r_in, recc_i)`: clean -> unchanged; correctable -> corrected data and `rcorr_o = 1`; uncorrectable -> `rerr_o = HERR_ECC`, `rcorr_o = 0` |
| counters | none | `ce` / `ue` events only when `rd_fire_i` (a real return) |

Decode outcomes (`syn[8:0]` = recomputed check XOR stored check, `op` = overall parity over data and all 10 stored bits) are tabulated in `docs/RAS_CODE.md`: clean; single-bit error (check bit or data bit, corrected; `syn` that is a power of two = a check bit flipped; `syn == pos(d)` = data bit `d` flipped);
`syn == 0, op = 1` = overall-parity bit flipped (corrected); `syn != 0, op = 0` = double error (uncorrectable); a single-error syndrome that points past the code (`syn` not a power of two and not any data-bit position) is uncorrectable.
All-zero data has all-zero check bits, so never-written zero memory is a valid codeword (the DRAM model returns zero with an all-zero ECC word for never-written granules).

**Poisoned responses.** An uncorrectable error produces a response with `rsp.err = HERR_ECC` (code 6, numerically identical to `silicaflux_pkg::SF_MEM_EXC_ECC`) and `rsp.corrected = 0`. The `data` field carries the **uncorrected** granule
(`sf_hbm_read_return.sv` stores `rd_data_i` regardless of `err`); a consumer must treat the data as invalid. A corrected error returns good data with `rsp.corrected = 1`, `err = NONE`.
The `sf_hbm_datafabric` adapter maps `HERR_ECC` to the NoC status `ECC` with `be = 0` and no data (`DATAFABRIC.md`). A poisoned read still counts as a completion in the performance counters (`cmp_rd`).

## 3. Counters, log, alert

| item | behaviour (RTL) |
|---|---|
| `ce_cnt_o`, `ue_cnt_o` | 32 bit, **saturate** at `0xFFFF_FFFF`; count correctable / uncorrectable events (reads with `ecc_en = 1`) |
| `phy_cnt_o` | counts `phy_event_i || (pa_rvalid && pa_rerr)`; saturating; counted whether or not `ecc_en` is set |
| `ondie_cnt_o` | counts `ondie_event_i`; saturating |
| `clear_i` (CSR `ECCCLR`, any write) | zeroes the four counters, `log_valid_o` and `alert_o`. Events in the cycle of a clear are dropped (the clear branch has priority). `log_ue_o` / `log_syndrome_o` keep their old value but are qualified by `log_valid_o` |
| error log | holds the **first** corrected-or-uncorrectable error since the last clear: `log_valid_o`, `log_ue_o` (1 = uncorrectable), `log_syndrome_o[8:0]`. No address, bank, row or timestamp is logged; the pseudo-channel number of the first error (`ECCLOG[31:16]`) is an integrator-supplied CSR input (`ecc_log_pc_i`), no RTL produces it |
| `alert_o` | sticky "maintenance alert": set by any uncorrectable event, cleared by `clear_i` |
| `ev_ce_o`, `ev_ue_o` | one-cycle event pulses exported as `evt.ecc_ce`, `evt.ecc_ue` and counted by `sf_hbm_perf` (`PERF_COUNTERS.md`) |

**What is visible above the pseudo-channel.** `sf_hbm_channel.sv` connects only `ecc_log_valid/ue/syn`, `ecc_alert` and the event pulses into `hbm_pc_stat_t`; the 32-bit `ecc_ce_o`, `ecc_ue_o`, `phy_err_o` and `ondie_err_o` ports of the pseudo-channel are left **unconnected**.
Through `sf_hbm4_controller` the CE/UE totals are therefore available only through the performance counters (per-PC 19/20, aggregate 17/18), and the PHY and on-die counters are not observable at all; they are readable only when a pseudo-channel is instantiated directly (as `tb_pc_single.sv` does).
CSR `ERRSTAT[3]` (sticky uncorrectable) is driven by an integrator-supplied `ev_ue_i`; CSR `STATUS[12]` by `ecc_alert_any_i` (`PERF_COUNTERS.md` section 6).

## 4. Fault injection

One shot per arm, per pseudo-channel, for tests and RAS research. Control: `inj_arm_i`, `inj_mode_i[1:0]`, `inj_bit_i[8:0]` (+ at the controller top `inj_pc_i[15:0]`, the **global** pseudo-channel index, decoded to the one pseudo-channel that sees `inj_arm_i`).
Register access: CSR `ECCINJ` (`[1:0]` mode, `[10:2]` bit, `[31:16]` pseudo-channel; writing bit 12 = 1 arms, self-clearing).

| mode | effect | consumed when |
|---|---|---|
| 0 | none (arming with mode 0 leaves the block armed with no effect until re-armed) | never |
| 1 | flip bit `inj_bit[7:0]` of the **next write data after encoding** (the stored word is corrupted, the check bits are those of the clean data) | the write data leaves (`wr_fire_i`) |
| 2 | flip the two adjacent bits `inj_bit[7:0]` and `inj_bit[7:0]+1` of the next write data after encoding. If `inj_bit[7:0] == 0xFF` nothing is flipped, but the shot is still consumed | `wr_fire_i` |
| 3 | flip bit `inj_bit[7:0]` of the **next read data before decoding** | a real read return (`rd_fire_i`) |

`inj_bit[8] = 1` disables the flip in all modes (the shot is still consumed). With `ecc_en = 0` a mode-3 injection corrupts the returned data **silently** (no detection, no counter). The DRAM model offers a second, independent injection path into the stored array
(`flip_bits`, `poke`, used by `tb_pc_single.sv`) that emulates a DRAM-side bit error.

## 5. Partial writes with ECC enabled

A granule-wide code needs read-modify-write for a masked write; RMW is **not implemented** (RAS-04 `UNIMPLEMENTED`). Policy instead:
`sf_hbm4_controller.sv` rejects a write with `wmask != '1` when `cfg.ecc_en = 1`, as an **error entry** with `HERR_POLICY` (code 3): it issues no DRAM command, changes no memory and returns an ordinary error response that obeys the same ordering rules as everything else.
With `ecc_en = 0` partial writes are accepted and the byte enable travels to the PHY as `wmask`; whether a real PHY/DRAM supports write masking is `UNVERIFIED` (IF-08).
The check is made at the controller ingress; a pseudo-channel instantiated directly (channel-sliced testbench mode, `ARCHITECTURE.md` section 4) has no such check.

## 6. Interaction caveats (derived from the RTL)

* Toggling `ecc_en` while data is in the array: data written with `ecc_en = 0` carries all-zero check bits; reading it back with `ecc_en = 1` is only clean for all-zero data and otherwise produces spurious corrected or uncorrectable events. No scrubber exists.
* The error log keeps the first event only; subsequent events are only counted.
* `HERR_FLUSHED` (read-return timeout) is a protocol error counter (`rd_timeout`), not an ECC event.
* The first-error pseudo-channel number and the aggregation of `ecc_alert`/`ev_ue` over pseudo-channels are the integrator's job; `sf_hbm_top` performs the OR-reduction (`ECCLOG` shows the lowest-numbered pseudo-channel that holds a log entry; the per-PC logs are the exact source).

## 7. RowHammer / refresh management: not implemented

`HCMD_RFM` ("refresh-management maintenance (abstract; DRFM research hook)") exists in `hbm_cmd_e`; the scheduler's maintenance legality accepts it (`all_idle && tm_ok_misc`) and the DRAM model accepts it. **No RTL block ever issues it**:
`rtl/sf_hbm_refresh.sv` states "refresh-management / DRFM commands are not issued here (sf_hbm_rfm hook, see docs)"; there is no `sf_hbm_rfm` module in `rtl/`. There is no activation counting, aggressor tracking or victim refresh in the controller.
The DRAM model keeps per-row-hash activation counters for reporting only and models no disturbance. Hammer-style traffic can be generated for research, but nothing here may be described as RowHammer protection.
Also absent: temperature-compensated refresh (REF-05), scrubbing, address logging, page retirement, retry.

## 8. Verification that exists

| what | where |
|---|---|
| SECDED encode/decode, injection modes 1-3, DRAM-side single and double flips, all 10 check-bit flips, counters/log/alert/clear | `verification/tests/tb_pc_single.sv` test `ecc` (`ecc_secded_and_fault_injection`): clean data CE=UE=0; write-path single flip -> CE=1, log valid and not UE, response `corrected`; write-path double flip -> `HERR_ECC`, UE=1, alert; read-path flip -> CE; 7 DRAM-side single flips -> CE=7; 5 double flips -> UE=5; 10 check-bit flips -> CE=10 with intact data; clear zeroes counters/log/alert |
| partial write + ECC -> `HERR_POLICY`, memory unchanged | `verification/tests/tb_ctrl_multi.sv` test `ecc_policy` (`partial_write_with_ecc_rejected`) |
| independent code implementation (built from `docs/RAS_CODE.md` only, never from the RTL) | `python/hbm4/reference_memory.py`, `python/tests/test_reference_memory.py` (`test_hamming_positions`, `test_encode_single_data_bit_hand_computed`, `test_every_single_bit_flip_is_corrected`, `test_random_double_bit_flips_are_uncorrectable`, `test_syndrome_past_the_code_is_uncorrectable`, `test_all_zero_is_valid_codeword`) |
| scoreboard handling of `HERR_ECC` / `HERR_POLICY` | `python/tests/test_scoreboard.py` (`test_ecc_policy_error_for_partial_write`, `test_expected_errors_map_and_predicate_for_ecc_poison`) |

Gaps: `rerr_o` (the PHY read-error input) is tied to 0 in every testbench; `phy_event_i` / `ondie_event_i` are driven by `tb_pc_single` test `phy_events` (counted separately, ECC counters and data unaffected, cleared by ECC clear). The CSR ECC registers are exercised by `tb_top_csr` `ecc_via_csr` (single/double flip through `ECCINJ`, `ECCLOG`, `STATUS` alert, `ERRSTAT` W1C, `ECCCLR`);
no script compares RTL check bits with the Python encoder directly (both are checked against the same hand-derivable definition in `docs/RAS_CODE.md`).
Observed error rates in benchmarks: none are measured (`tb_bench.sv` keeps `ecc_on = 0`; it has no plusarg to enable ECC and injects no faults).
