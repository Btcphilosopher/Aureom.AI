# Scheduler (`rtl/sf_hbm_scheduler.sv`) and request queue (`rtl/sf_hbm_req_queue.sv`)

> All timing values referenced here are fields of a `HYPOTHETICAL_SIM` profile (`configs/timing/profiles.json`). The scheduler issues
> commands of the abstract set `hbm_cmd_e`; nothing here is a JEDEC / HBM4 / DFI behaviour description.

One scheduler exists per pseudo-channel. It picks **at most one command per cycle** (`issue_valid_o`) from three sources, in this order:

```
 1. maintenance   init MRS > power sequencer > refresh engine   (granted if legal AND (mnt_prio_i OR no legal demand entry))
 2. demand        the selected queue entry's NEXT command (PRE | ACT | RD/WR) or an error-entry completion (no PHY command)
 3. proactive PRE close-page / timeout page policy, only if (1) and (2) did not issue
```

`PRIORITY NEVER BYPASSES A TIMING RULE` (module header): ranking is applied only among entries whose next command is already legal; legality is
computed first (section 3). A simulation-time assertion re-checks that an issued ACT/RD/WR is permitted by the bank and cross-bank views.

## 1. Inputs the scheduler sees

| group | signals | produced by |
|---|---|---|
| queue view | `ent_valid_i`, `ent_txn_i`, `ent_blocked_i`, `ent_older_i[i][j]`, `ent_age_i` | `sf_hbm_req_queue` |
| bank view | `bk_row_open_i`, `bk_open_row_i`, `bk_can_act/rd/wr/pre_i`, `bk_idle_i` (x16 banks) | `sf_hbm_bank_fsm` |
| cross-bank view | `tm_ok_act/rd/wr_i[bank group]`, `tm_ok_ref_i`, `tm_ok_misc_i` | `sf_hbm_timing` |
| credits | `cpl_credit_i` (completion entry), `wr_credit_i` (write pending FIFO), `phy_ready_i` | `sf_hbm_read_return`, `sf_hbm_write_data`, `sf_hbm_phy_adapter` |
| maintenance | `mnt_valid_i`, `mnt_cmd_i`, `mnt_prio_i`, `hold_act_i`, `hold_col_i`, `hold_bank_valid_i/hold_bank_i/hold_bank_col_i` | pseudo-channel mux of init / power / refresh |
| configuration | `cfg_i` (`hbm_sched_cfg_t`) | CSR or testbench |

## 2. Command generation for one entry: row hit, row empty, row conflict

The scheduler does not generate a command *sequence* per request; every cycle it re-derives the **next** command of every queue entry from the live bank state
(`need_col / need_pre / need_act`), and the entry stays in the queue until its column command issues:

| bank state seen by the entry | `is_open` | `is_hit` | next command | derived flag |
|---|---|---|---|---|
| open on the entry's row | 1 | 1 | `RD` / `WR` (column) | `need_col` |
| open on another row | 1 | 0 | `PRE` (that bank) | `need_pre` |
| precharged | 0 | 0 | `ACT` (the entry's row) | `need_act` |
| entry carries `err != HERR_NONE` | -- | -- | none: completes as an *error entry* (`issue_err_o`) | `is_err` |

Resulting sequences (`t0` = issue cycle of the first command; `N` after a command means "earliest `t0+N`", the counters of `sf_hbm_bank_fsm`/`sf_hbm_timing`
are loaded with `N-1` on the issue edge and `== 0` means legal, `hbm_ld` in `sf_hbm_pkg.sv`):

```
row hit       :  RD|WR at t0                                    (legal when bank can_rd/can_wr, cross-bank ok_rd/ok_wr, credits, no hold)
row empty     :  ACT at t0  --(tRCDRD | tRCDWR)-->  RD|WR
row conflict  :  PRE at t0  --(tRP)-->  ACT  --(tRCDRD | tRCDWR)-->  RD|WR
```

Additional earliest-time conditions that apply on top (all enforced by the counters, not by this module): `PRE` needs `tRAS` since ACT, `tRTP` since the last RD, `WL+burst+tWR` since the last WR
of that bank; `ACT` needs `tRP` since PRE, `tRC` since the previous ACT of the bank, `tRRD_S/L` since other ACTs, the `tFAW` window, no refresh in progress; column commands need
`tCCD_S/L`, write-to-read (`WL+burst+tWTR_S/L`) and read-to-write (`RL+burst+2-WL`, min 1) turnarounds, and no `tMRD/tXP/tXS` window. Authoritative list: `docs/TIMING_RULES.md`.

Legality of the next command (`rtl/sf_hbm_scheduler.sv`, "legality of each entry's NEXT command"):

| next command | legal when |
|---|---|
| column, write | `bk_can_wr[b] && tm_ok_wr[g] && wr_credit && cpl_credit && phy_ready && !hold_col && !(held_bank && hold_bank_col)` |
| column, read | `bk_can_rd[b] && tm_ok_rd[g] && cpl_credit && phy_ready && !hold_col && !(held_bank && hold_bank_col)` |
| ACT | `bk_can_act[b] && tm_ok_act[g] && phy_ready && !hold_act && !held_bank` |
| PRE | `bk_can_pre[b] && phy_ready && !held_bank && (policy == FCFS \|\| !hit_pending[b])`  (PRE protection, section 5) |
| error completion | `cpl_credit` only (no `phy_ready`, no bank state) |

`b = {bg,ba}`, `g = bg`, `held_bank = hold_bank_valid && hold_bank == b`. A legal entry additionally has to be a candidate: `cand = valid && !blocked && (policy != FCFS || oldest_valid)`.

## 3. Policies (`hbm_sched_policy_e`, `cfg_i.policy`)

| policy | code | candidate set | tier bits used | PRE protection |
|---|---|---|---|---|
| `SCHED_FCFS` | 0 | only the oldest valid entry (`ent_older_i[i] & ent_valid_i == 0`). Strict in-order command issue; if the oldest entry's next command is not legal nothing else issues (except maintenance and proactive close) | `colhit` and `bgdiff` are forced 0; urgent/deadline/qos/batch still computed but select among a single candidate | none (PRE is never withheld) |
| `SCHED_FRFCFS` | 1 | every unblocked valid entry | `colhit` set for column commands and error completions | yes |
| `SCHED_BGAWARE` | 2 | as FRFCFS | `colhit` + `bgdiff` (column command to a bank group different from `last_bg_q`, the bank group of the previous *demand* column command) | yes |
| reserved | 3 | treated as non-FCFS, `bgdiff = 0` (`policy == SCHED_BGAWARE` is false), i.e. behaves like FRFCFS | | yes |

## 4. Priority tiers

`tier[i] = {urgent, dl, qos[1:0], batch, colhit, bgdiff}` (7 bits, MSB strongest). The selection narrows the legal set one bit at a time from bit 6 to bit 0
(`for k = 6..0: if any narrowed entry has tier[k]=1, keep only those`), so it is a strict lexicographic order; the winner is then the **oldest** entry of the final set
(exact order from the age matrix, not from the 16-bit age counter).

| bit | name | condition (exactly as in RTL) |
|---|---|---|
| 6 | `urgent` | `cfg.starve_limit != 0 && age >= cfg.starve_limit` (anti-starvation; 0 = off) |
| 5 | `deadline` | `cfg.deadline_en && qos == QOS_RT (2'd3) && age >= cfg.deadline_thr` |
| 4:3 | `qos` | `cfg.prio_en ? qos : 2'b00` (`QOS_BE 0 < QOS_LOW 1 < QOS_HIGH 2 < QOS_RT 3`) |
| 2 | `batch` | `cfg.batch_en && (entry.write == cur_dir_q)` (read/write batching direction) |
| 1 | `colhit` | `policy != FCFS && (need_col \|\| is_err)` |
| 0 | `bgdiff` | `policy == BGAWARE && need_col && entry.bg != last_bg_q` |

`age` is the saturating `AGE_W` (default 16) cycles-since-push counter of the queue, compared as 16 bits.

**Batching state** (registered, `cfg.batch_en` only): `cur_dir_q` (0 reads, 1 writes), `batch_cnt_q` (8 bits, saturates at 255). Each cycle, with `dir_work[d]` = some candidate non-error entry of direction `d`:
(a) if the current direction has no work and the other has, flip and clear the count; (b) else if `batch_cnt_q >= cfg.batch_len` and the other direction has work, flip and clear;
(c) else if a demand column command of the current direction issues, `batch_cnt_q++`. Edge case derived from (b): `batch_len == 0` flips the direction every cycle in which the other direction has work.

`last_bg_q` is updated at every demand column command (`demand_col`).

## 5. Page policies, PRE protection, proactive close

| item | behaviour (RTL) |
|---|---|
| `PAGE_OPEN` (0) | no proactive PRE: rows stay open until a conflict, a refresh `PREA`/`PRE`, or a power-state `PREA` |
| `PAGE_CLOSE` (1) | proactive `PRE` for a bank whose row is open, whose `bk_can_pre` holds, that is not held by a per-bank refresh, with `phy_ready`, and for which **no valid queue entry** (blocked or not, any policy) hits the open row (`any_pending[b] == 0`) |
| `PAGE_TIMEOUT` (2) | as `PAGE_CLOSE`, but only after the bank has been open-and-unwanted for `idle_cnt_q[b] >= cfg.close_timeout` cycles (`idle_cnt_q` counts cycles with row open and `any_pending == 0`, saturates at `0xFFFF`, cleared otherwise). `close_timeout == 0` therefore behaves like `PAGE_CLOSE` |
| proactive close arbitration | issues only if no maintenance grant and **no legal demand entry** in the same cycle; among banks wanting to close, the **lowest** `{bg,ba}` index wins |
| PRE protection (`FRFCFS`/`BGAWARE`) | a `PRE` for bank `b` is not legal while `hit_pending[b]`, i.e. while some *candidate* (valid, unblocked, non-error) entry hits the open row of `b`. Hit entries are therefore served before a conflicting entry may close the row. `FCFS` does not protect |

Override (`boost`): the protection is **lifted for a starving entry** (`starve_limit != 0 && age >= starve_limit`) and for a QoS-deadline-urgent entry (`deadline_en`, `qos == RT`, `age >= deadline_thr`); such an entry may `PRE` an open row even while younger hits to it are pending. In addition a **drain** rule blocks every *new* non-boosted column command to a bank while a boosted entry needs to precharge it: a hit stream re-arms tRTP/tWR on every column command, and with `tRTP > tCCD_L` (the `sim_strict` profile) the PRE would otherwise never become legal - the first version of the override, without the drain, left the starving request waiting behind the whole flood on that profile (541 cycles with `starve_limit = 60`; 129 with the drain). Without this override a continuous stream of row hits could postpone a conflicting request for ever and `starve_limit` would be useless (this was found by review of the first version, which had the property documented as a known limitation, and then fixed).
`tb_pc_single.sv` test `starvation`: 8 hits already pending, a conflicting request B, then a flood of 112 more hits to the open row. Observed (`sim_fast` / `sim_ref` / `sim_strict`, B latency in cycles without -> with `starve_limit = 60`): 249 -> 77, 385 -> 111, 541 -> 129 (B waits for all 121 responses without the limit, for 18-35 with it); FCFS serves strictly oldest first. The test also passes with close-page, with PHY stalls and response back-pressure, and with PHY command/read latency stages. The mutants `starve_boost_off` (protection never lifted), `starve_never` (age comparison disabled) and `starve_drain_off` (no drain; killed on `sim_strict`) are killed by this test; `policy` still checks hit-before-PRE ordering (13 hits, 1 ACT for FR-FCFS).

## 6. Maintenance arbitration

Maintenance sources are multiplexed inside `sf_hbm_pseudochannel.sv` with fixed priority `init MRS > power sequencer > refresh`; the scheduler sees one `(mnt_valid, mnt_cmd, mnt_prio)`.

| command | legality (`mnt_leg`) |
|---|---|
| `PREA` | every open bank has `bk_can_pre`, and `tm_ok_misc` |
| `PRE` | target bank closed or `bk_can_pre`, and `tm_ok_misc` |
| `REF_AB` | all banks idle and `tm_ok_ref` |
| `REF_PB` | target bank idle and `tm_ok_ref` |
| `MRS` | all banks idle and `tm_ok_ref` |
| `PDE`, `SRE`, `RFM` | all banks idle and `tm_ok_misc` |
| `PDX`, `SRX` | always (even with `phy_ready = 0`) |
| all except `PDX/SRX` | additionally `phy_ready` |

`mnt_grant = mnt_leg && (mnt_prio || !have_demand)` where `have_demand = |legal` (error entries count). A granted maintenance command **suppresses** demand and proactive close in that cycle.
`mnt_prio`: init MRS and power commands always 1; refresh = `urgent` (debt >= `max_postpone`) while preparing (`PREA`/`PRE`), and always 1 for the `REF_AB`/`REF_PB` command itself (`sf_hbm_refresh.sv`).
A non-urgent refresh therefore only issues in cycles in which no demand entry is legal.

Hold signals (from refresh / power / enable) restrict demand: `hold_act` blocks every ACT; `hold_col` blocks every column command; `hold_bank_*` blocks ACT and PRE (and, with `hold_bank_col`, column commands) to one bank.
All-bank refresh holds ACT from the start of the sequence and column commands only when urgent; per-bank refresh holds only the target bank. `HCMD_RFM` is accepted by the legality table but no RTL source generates it (`RAS.md`).

## 7. Request queue: age matrix and dependency matrix

`sf_hbm_req_queue` (`DEPTH` default 16, `AGE_W` default 16):

| structure | meaning | update |
|---|---|---|
| `valid_q[i]`, `txn_q[i]` | slot occupancy and `hbm_txn_t` | push at the **lowest free** index that is not held (`hold_i`); no bypass: an accepted entry is visible to the scheduler the next cycle |
| `older_q[i][j]` | entry `j` is older than entry `i` (total order = acceptance order, wrap-free) | at push of `i`: `older_q[i] <= valid_q & ~rem_oh`; column `j` cleared when `j` is removed |
| `dep_q[i][j]` | entry `i` **must not issue before** entry `j` | at push: `dep_q[i][j] = valid_q[j] && !rem_oh[j] && hbm_conflict(new, txn_q[j])`; cleared when `j` is removed |
| `ent_blocked_o[i]` | `|dep_q[i]` | combinational; a blocked entry is never a candidate |
| `age_q[i]` | cycles since push, saturating at all-ones | `+1` per cycle while valid, cleared at push |
| removal | `rem_valid_i/rem_idx_i` = column-command issue or error-entry completion (`issue_col || issue_err`) | the slot becomes allocatable again **unless** `hold_i[i]` (write data still owed) |

`hbm_conflict(new, old)` (`sf_hbm_pkg.sv`, restated from `ORDERING.md`) is true if any of:

| term | condition |
|---|---|
| hazard | same granule `{bg,ba,row,col}` and at least one of the two is a write (RAW/WAR/WAW) |
| same ID | same `{src,id}` |
| ordering attribute | `new.order == ORD_STRICT` or `old.order == ORD_STRICT`, or (`new.order == ORD_SRC` and `new.src == old.src`) |

The dependency is released when the **older entry's column command issues**, not when its response is delivered. Responses of one pseudo-channel are then returned in command-issue order by the completion sequencer.
`ORD_STRICT` and `ORD_SRC` order only inside one pseudo-channel queue; the cross-pseudo-channel same-ID rule is enforced by the top-level tracker (`ARCHITECTURE.md` section 7).
Area: `DEPTH*DEPTH` bits for each matrix, one comparator set per valid entry at every push (`sf_hbm_req_queue.sv` KNOWN LIMITATIONS).
Formal harness: `verification/formal/fv_req_queue.sv` (see `docs/FORMAL.md`).

## 8. Row-hit accounting definitions

| term | definition (RTL: `touched_q`, `conflict_q`, per queue slot) |
|---|---|
| row hit | the entry's column command issues and **no ACT or PRE was ever issued on its behalf** (`demand_act`/`demand_pre` with `sel_idx == entry`) |
| row empty | column command issues and the **first** command issued on its behalf was an ACT |
| row conflict | column command issues and the first command issued on its behalf was a PRE |
| scope | demand column commands only (`demand_col = demand_go && !is_err && need_col`); error entries and maintenance are not counted; each accepted non-error request is counted exactly once |

`touched_q`/`conflict_q` of a slot are cleared when its column command (or error completion) issues. Consequences of the definition: a row closed by a refresh `PREA` or a proactive `PRE` (neither is "on behalf of" an entry)
makes the next access a *row empty*; an entry whose row was opened by another entry's ACT is a *hit*. `row_hit_rate = hit / (hit + empty + conflict)` (`docs/TIMING_RULES.md`).
`tb_ctrl_multi.sv` test `perf` checks `hit + empty + conflict == number of column commands`.

## 9. Statistics events

All are one-cycle pulses of `sf_hbm_scheduler` (`ev_*`) or of `sf_hbm_pseudochannel` (`evt_o`, type `hbm_pc_evt_t`); `sf_hbm_perf` counts the latter (`PERF_COUNTERS.md`).

| event | exact definition | source |
|---|---|---|
| `row_hit`, `row_empty`, `row_conflict` | section 8, at the demand column-command issue cycle | scheduler `ev_row_*` |
| `bypass` | `demand_go && oldest_legal_idx != sel_idx`: the winner is not the oldest *legal* entry | scheduler `ev_bypass_o` |
| `qos_stall` | `bypass && cfg.prio_en && qos(oldest legal) < qos(winner)` | scheduler `ev_qos_stall_o` |
| `phy_stall` | `any_cand && !phy_ready && nothing_issued` | scheduler `ev_phy_stall_o` |
| `ref_stall` | `any_cand && nothing_issued && phy_ready && (hold_act \|\| hold_col \|\| hold_bank_valid)` | scheduler `ev_ref_stall_o` |
| `timing_stall` | `any_cand && nothing_issued && phy_ready && no hold`. **Catch-all:** includes cycles lost to the completion credit, the write pending FIFO, PRE protection and bank/cross-bank timing, not only DRAM timing | scheduler `ev_timing_stall_o` |
| `act` | cycle in which an `ACT` command issues (any source) | computed in `sf_hbm_pseudochannel.sv` from `issue_cmd` |
| `pre` | cycle in which `PRE` or `PREA` issues (one count per command, so one `PREA` counts once, not per bank) | same |
| `refresh` | `REF_AB` or `REF_PB` issues | same |
| `ref_forced`, `ref_pullin` | at refresh completion: `urgent` / `debt <= 0` before repayment | `sf_hbm_refresh.sv` |
| `busy` | `!q_empty || completion buffer non-empty || write pending FIFO non-empty` | pseudo-channel |

The scheduler also exports `ev_act_o`, `ev_pre_o`, `ev_demand_pending_o`; they are wired in `sf_hbm_pseudochannel.sv` (`s_act`, `s_pre`, `s_pend`) but **not consumed** there.
`nothing_issued = !issue_valid && !issue_err`; `any_cand = |cand` (error entries included).

## 10. Known limitations

| # | limitation | evidence |
|---|---|---|
| 1 | One command per pseudo-channel per cycle; no separate row/column command bus (`ENGINEERING_ASSUMPTION`, STANDARDS_MATRIX ARCH-08) | scheduler header |
| 2 | The whole selection (legality of `DEPTH` entries, 7-level tier narrowing, oldest-select) is one combinational stage; a pipelining plan is referenced in the RTL header (`docs/PHYSICAL_DESIGN.md`) but that file is not present in `docs/` | scheduler header |
| 3 | No auto-precharge (`RDA`/`WRA`); explicit `PRE` only | `sf_hbm_pseudochannel.sv`, `sf_hbm_bank_fsm.sv` |
| 4 | `FCFS` is head-of-line blocking by design | `cand` definition |
| 5 | PRE protection is overridden only for a starving / deadline-urgent entry (`boost`, section 5); a hit flood therefore delays a conflicting request by about `starve_limit` + one PRE/ACT/RD sequence | `leg_pre` |
| 6 | `batch_len = 0` toggles the direction every cycle when both directions have work | section 4 |
| 7 | `timing_stall` is a catch-all; do not read it as pure DRAM-timing loss | section 9 |
| 8 | Reserved policy value 3 silently behaves like `FRFCFS` | section 3 |
| 9 | Row-hit accounting is per request, not per bank; refresh/power PRE shift hits into "row empty" | section 8 |
| 10 | The Python scheduler (`python/hbm4/scheduler.py`) is "not cycle-matched to any RTL" and models only FCFS/FR-FCFS, open/close page and all-bank refresh; the tiers, BGAWARE, batching and QoS have no Python counterpart | `python/README.md` |

## 11. Verification that exists

* `verification/tests/tb_pc_single.sv`: `random`, `random_hot` (row locality), `policy` (FCFS vs FR-FCFS command counts), `backpressure`, `saturation`, `hazards`; run per profile 0..2 and policy 0..2 by `scripts/regress.py` (`pc_single_profile*_policy*`); also `+PAGE`, `+BATCH`, `+PRIO` plusargs.
* `verification/tests/tb_ctrl_multi.sv`: scoreboard of data, ownership, same-ID order, mapping; `perf` test for the accounting identity.
* `scripts/mutation_check.sh`: mutants `pre_protect_off`, `raw_dependency_off`, `slot_hold_off` target this section; results in `reports/mutation_report.json` (generated).
* Priority tiers `urgent`, `deadline`, `bgdiff` and `batch` have no dedicated directed test in the files named above (the plusargs `+PRIO`, `+BATCH` and `tb_bench.sv` benchmark J exercise `qos`, `batch` and `deadline` stochastically); their effect on results: <!-- RESULTS: filled in by scripts/make_report.py -->.
