# Register of missing specification details (generated)

Everything here is information that real HBM4 silicon integration needs and that this repository does NOT have.
Each item is exposed as a configurable requirement or a clearly labelled stub. **None has been guessed.**

| id | missing detail | currently |
|---|---|---|
| ARCH-01 | check against JESD270-4 channel organisation | PUBLIC_REFERENCE: parameter NUM_CHANNELS (1,2,4,8,32 simulated); rtl/sf_hbm4_controller.sv |
| ARCH-02 | check against JESD270-4 | PUBLIC_REFERENCE: sf_hbm_channel (PCS=2), HBM_DQ_PER_PC=32 |
| ARCH-03 | check against JESD270-4 | PUBLIC_REFERENCE: reference configuration NCH=32; never modelled as one monolithic port |
| ARCH-04 | JESD270-4 burst length / access granularity | ENGINEERING_ASSUMPTION: HBM_BEATS=8, HBM_GRAN_BYTES=32 (sf_hbm_pkg) |
| ARCH-05 | JESD270-4 / vendor datasheet density-specific geometry | ENGINEERING_ASSUMPTION: rtl/sf_hbm_geom.svh (override with -D) |
| ARCH-06 | vendor datasheet capacity options | ENGINEERING_ASSUMPTION: derived: 2^(OFF+COL+BA+BG+ROW+PC+CH+NS) bytes |
| ARCH-07 | does the real channel share a command bus between pseudo-channels? (PHY/standard) | ENGINEERING_ASSUMPTION: sf_hbm_pseudochannel has its own scheduler; no shared command bus modelled |
| ARCH-08 | JESD270-4 command bus partitioning | ENGINEERING_ASSUMPTION: scheduler issues one command/cycle |
| IF-01 | real HBM4 command table | ENGINEERING_ASSUMPTION: hbm_cmd_e in sf_hbm_pkg; NOT a JEDEC command table |
| IF-02 | JESD270-4 command truth tables + licensed PHY interface | UNIMPLEMENTED: sf_hbm_command_encoder: ENCODING!=0 is a build error by design |
| IF-03 | DFI 5.1 specification + PHY vendor integration guide | UNIMPLEMENTED: sf_hbm_phy_adapter BACKEND=1 is an explicit stub (backend_unimplemented_o) |
| IF-04 | n/a (simulation only) | ENGINEERING_ASSUMPTION: sf_hbm_phy_adapter BACKEND=0 -> hbm4_dram_model |
| IF-05 | PHY clock-ratio contract | UNIMPLEMENTED: 1:1 only; async FIFO provided for host-side CDC (sf_hbm_cdc_fifo) |
| IF-06 | PHY read-data return contract | ENGINEERING_ASSUMPTION: sf_hbm_read_return checks it (rd_timing_err / timeout) |
| IF-07 | PHY write-data timing contract | ENGINEERING_ASSUMPTION: sf_hbm_write_data |
| IF-08 | JESD270-4 write data masking / DM / DBI behaviour | UNVERIFIED: wmask passed through; partial writes rejected when controller ECC is on |
| TIM-01 | values for the selected speed grade from JESD270-4 / datasheet | UNVERIFIED: configs/timing/profiles.json: ALL profiles HYPOTHETICAL_SIM |
| TIM-02 | diff against the JESD270-4 constraint table; add missing classes (e.g. tRREFD, tPPD, tRDPDE) | ENGINEERING_ASSUMPTION: docs/TIMING_RULES.md (normative for this project) |
| TIM-03 | JESD270-4 definitions (the +2 bus-turnaround term in particular) | ENGINEERING_ASSUMPTION: sf_hbm_timing, sf_hbm_bank_fsm |
| TIM-04 | JESD270-4 bank-group architecture of HBM4 | ENGINEERING_ASSUMPTION: per-bank-group counters in sf_hbm_timing |
| REF-01 | supported refresh modes and postpone/pull-in limits for HBM4 | UNVERIFIED: sf_hbm_refresh |
| REF-02 | whether / how HBM4 defines per-bank refresh | UNVERIFIED: sf_hbm_refresh REFMODE_PB |
| REF-03 | JESD270-4 power states and exit latencies | UNVERIFIED: sf_hbm_power_state (abstract PDE/PDX/SRE/SRX) |
| REF-04 | JESD270-4 DRFM definition + threat model + device behaviour | UNIMPLEMENTED: HCMD_RFM reserved; python/benchmarks hammer traffic exists but no mitigation logic claims protection |
| REF-05 | device temperature interface | UNIMPLEMENTED: none |
| RAS-01 | does the HBM4 PHY/DRAM interface provide a sideband for 10 bits per granule? | ENGINEERING_ASSUMPTION: sf_hbm_ecc_ras; docs/RAS_CODE.md |
| RAS-02 | device behaviour description | UNIMPLEMENTED: only an event-counting input (ondie_event_i) |
| RAS-03 | PHY CRC/parity definition | UNIMPLEMENTED: only an event-counting input (phy_event_i) |
| RAS-04 | implement RMW in the pseudo-channel | UNIMPLEMENTED: partial write with ECC -> HERR_POLICY |
| INIT-01 | JESD270-4 initialisation sequence + PHY bring-up document | ENGINEERING_ASSUMPTION: sf_hbm_init |
| INIT-02 | JESD270-4 mode registers | UNIMPLEMENTED: 4 abstract MRS steps with placeholder operands |
| INIT-03 | licensed PHY with training firmware/RTL | UNIMPLEMENTED: treated as an EXTERNAL PHY service (phy_init_start/done, train_start/done) |
| SYS-01 | keep in sync with SF_NOC_PKT_VERSION | ENGINEERING_ASSUMPTION: integration/datafabric/sf_hbm_datafabric.sv vendors the contract from silicaflux-datafabric-noc-v2 |
| SYS-02 | SoC memory-map decision | ENGINEERING_ASSUMPTION: address-extension register (high bits) in the DataFabric adapter; integration blocker documented |
| SYS-03 | SoC bus decision (APB wrapper if required) | ENGINEERING_ASSUMPTION: sf_hbm_csr |
| PHY-01 | licensed PHY + package + signoff | UNIMPLEMENTED: out of scope for RTL; docs/REAL_SILICON_REQUIREMENTS.md |
| PHY-02 | PDK + STA flow | UNIMPLEMENTED: only technology-independent Yosys statistics; no PDK, no OpenROAD/OpenSTA in the environment |
