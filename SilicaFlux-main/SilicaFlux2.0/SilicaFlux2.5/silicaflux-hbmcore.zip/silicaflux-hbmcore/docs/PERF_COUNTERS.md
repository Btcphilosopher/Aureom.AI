# Performance counters (`rtl/sf_hbm_perf.sv`) and the CSR window (`rtl/sf_hbm_csr.sv`)

> Counters report *what the simulated controller did against a hypothetical timing profile*. No value read from them is an HBM4 or silicon measurement. Measured values are not in this document:
> <!-- RESULTS: filled in by scripts/make_report.py -->

## 1. Where the numbers come from

Every pseudo-channel produces a bundle `hbm_pc_stat_t` (`sf_hbm_pkg.sv`) = one-cycle event pulses `hbm_pc_evt_t evt` + sampled status. `sf_hbm4_controller` exports one bundle per pseudo-channel as `stat_o[]` (flat index
`((stack*NUM_CHANNELS)+ch)*2+pc`) and three top-level stall pulses (`ev_stall_id_o`, `ev_stall_q_o`, `ev_stall_fence_o`). `sf_hbm_perf` consumes `stat_o` plus the three stall pulses.
**`sf_hbm_perf` and `sf_hbm_csr` are not instantiated by `sf_hbm4_controller`**: `sf_hbm_top` wires them around it (`tb_ctrl_multi.sv` instantiates `sf_hbm_perf` directly to cross-check it against its own tallies).

| `stat` field | meaning |
|---|---|
| `evt.acc_rd/acc_wr` | request accepted by the pseudo-channel queue (`req_valid && q_push_ready && ctrl_enable`); error entries are accepted requests too |
| `evt.cmp_rd/cmp_wr` | response accepted by the consumer (`rsp_valid && rsp_ready`), error-free or not |
| `evt.row_hit/row_empty/row_conflict/act/pre/refresh/ref_forced/ref_pullin/ref_stall/timing_stall/qos_stall/bypass/phy_stall` | `SCHEDULER.md` section 9 |
| `evt.ecc_ce/ecc_ue` | `RAS.md` section 3 |
| `evt.rd_timing_err/rd_timeout/rd_unexpected` | read-return protocol events (`PHY_CONTRACT.md` C4, C5, C7) |
| `evt.violation` | a bank-local or cross-bank timing/state violation detected by the controller's own checkers (must stay 0; also an `$error` in simulation) |
| `evt.deadline_miss` | refresh debt exceeded `max_postpone` (must stay 0) |
| `evt.busy` | queue, completion buffer or write-pending FIFO non-empty |
| `evt.in_pd/in_sr` | cycle spent in power-down / self-refresh (`pwr_state == 3 / 4`) |
| `lat` | latency of the response accepted this cycle (valid with `evt.cmp_*`): request-queue age at issue + completion-sequencer residency, i.e. cycles from queue acceptance to response acceptance **inside the pseudo-channel** (includes time waiting for a back-pressured consumer; excludes top-level ID-tracker stalls and the top arbiter). 16 bit |
| `bytes` | payload bytes of that response: 32 for a read, `popcount(wmask)` for a write (6 bit). Also set for *error* completions (an erroneous write contributes its mask popcount although nothing is written) |
| `occ` | request-queue occupancy (6 bit in the bundle; see caveat 6) |
| `pwr_state`, `debt`, `quiet`, `unimpl`, `ecc_alert/ecc_lv/ecc_lue/ecc_lsyn`, `bank_state[16][2]` | sampled status, not counted by `sf_hbm_perf` |

## 2. Counter lists

Counter widths are `CNT_W` bits (parameter, default 48). `CNT_W` may be 2..64 (read data is 64 bit, so `CNT_W <= 64` is lossless). `CNT_W < 32` exists only so that saturation can be exercised in a short simulation (`tb_top_csr -GPERF_W=6`); with `CNT_W < 16` the two *maximum* counters (`lat_max`, `occ_max`) truncate their 16-bit / 6-bit source value instead of saturating.

### 2.1 Per-pseudo-channel (`PER_PC_EN = 1`; index = counter id, 44 counters per PC)

| id | name | increment per cycle | | id | name | increment per cycle |
|---|---|---|---|---|---|---|
| 0 | acc_rd | `evt.acc_rd` | | 22 | lat_sum | `lat` if `cmp_rd \|\| cmp_wr` |
| 1 | acc_wr | `evt.acc_wr` | | 23 | lat_cnt | 1 if `cmp_rd \|\| cmp_wr` |
| 2 | cmp_rd | `evt.cmp_rd` | | 24 | lat_max | **maximum** of `lat` over completions (not an adder) |
| 3 | cmp_wr | `evt.cmp_wr` | | 25 | occ_sum | `occ` every cycle |
| 4 | bytes_rd | `bytes` if `cmp_rd` | | 26 | occ_max | **maximum** of `occ` (not an adder) |
| 5 | bytes_wr | `bytes` if `cmp_wr` | | 27 | protocol_err | 1 if `rd_timing_err \|\| rd_timeout \|\| rd_unexpected` |
| 6 | row_hit | `evt.row_hit` | | 28 | violations | `evt.violation` |
| 7 | row_empty | `evt.row_empty` | | 29 | deadline_miss | `evt.deadline_miss` |
| 8 | row_conflict | `evt.row_conflict` | | 30 | pd_cycles | `evt.in_pd` |
| 9 | act | `evt.act` | | 31 | sr_cycles | `evt.in_sr` |
| 10 | pre | `evt.pre` | | 32..43 | latency histogram bins 0..11 | 1 in the bin of `lat` if `cmp_rd \|\| cmp_wr` |
| 11 | refresh | `evt.refresh` | | | | |
| 12 | ref_forced | `evt.ref_forced` | | | | |
| 13 | ref_pullin | `evt.ref_pullin` | | | | |
| 14 | ref_stall | `evt.ref_stall` | | | | |
| 15 | timing_stall | `evt.timing_stall` | | | | |
| 16 | qos_stall | `evt.qos_stall` | | | | |
| 17 | bypass (reordered) | `evt.bypass` | | | | |
| 18 | phy_stall | `evt.phy_stall` | | | | |
| 19 | ecc_ce | `evt.ecc_ce` | | | | |
| 20 | ecc_ue | `evt.ecc_ue` | | | | |
| 21 | busy_cycles | `evt.busy` | | | | |

Latency histogram: bin `b = clog2(lat+1)` clipped to 11, which in the code is `0` for `lat = 0`, `k` for `2^(k-1) <= lat < 2^k` (k = 1..10) and `11` for `lat >= 1024`. Percentiles are computed offline from the exact histogram that `tb_bench.sv` collects (`python/hbm4/performance.py`), not from these 12 bins.
Counters 24 and 26 do not take part in overflow detection.

### 2.2 Aggregate (sum over all pseudo-channels; 33 counters; with a snapshot shadow)

| id | name | | id | name | | id | name |
|---|---|---|---|---|---|---|---|
| 0 | cycles (+1 every cycle) | | 11 | pre | | 22 | occ_sum (sum of `occ` over PCs) |
| 1 | acc_rd | | 12 | refresh | | 23 | stall_id (`ev_stall_id_i`) |
| 2 | acc_wr | | 13 | ref_stall | | 24 | stall_q (`ev_stall_q_i`) |
| 3 | cmp_rd | | 14 | timing_stall | | 25 | stall_fence (`ev_stall_fence_i`) |
| 4 | cmp_wr | | 15 | qos_stall | | 26 | ref_forced |
| 5 | bytes_rd | | 16 | phy_stall | | 27 | ref_pullin |
| 6 | bytes_wr | | 17 | ecc_ce | | 28 | violations |
| 7 | row_hit | | 18 | ecc_ue | | 29 | protocol_err |
| 8 | row_empty | | 19 | busy_pc_cycles (PC-cycles busy) | | 30 | deadline_miss |
| 9 | row_conflict | | 20 | lat_sum | | 31 | pd_cycles |
| 10 | act | | 21 | lat_cnt | | 32 | sr_cycles |

An aggregate counter can advance by up to `N` per cycle (one per pseudo-channel). There is no aggregate for `bypass`, `lat_max`, `occ_max` or the histogram.

## 3. Rollover, saturation, overflow

| item | behaviour |
|---|---|
| width | every counter `CNT_W` bits |
| rollover | **saturating, never wraps** (`sat_add`: a sum that carries out of `CNT_W` bits is replaced by all-ones) |
| overflow flag `ovf_o` | sticky; set (while not frozen) the first cycle any aggregate or per-PC (except ids 24, 26) counter would exceed its range; cleared only by `clear_i` (and reset). Exported as CSR `STATUS[10]` |
| derived headroom | not quoted as a number of years/cycles here; it follows from `2^CNT_W` and the per-cycle increment |
| `lat_max`, `occ_max` | monotone maxima, cleared by `clear_i` |
| reset | asynchronous; everything (counters, shadows, `ovf`) to zero |

## 4. Snapshot, clear, freeze

| control | semantics (RTL) |
|---|---|
| `clear_i` (1-cycle pulse) | all per-PC counters, all aggregates, all shadows and `ovf` -> 0. Highest priority: works while frozen; events in the clear cycle are not counted |
| `snap_i` (1-cycle pulse) | copies **all aggregate** counters into the shadow bank in one cycle; the copy is of the register values *before* this cycle's increment (events of the snap cycle are not in the snapshot). Works while frozen |
| `freeze_i` (level) | all counters (per-PC, aggregate, `ovf`) hold; **events during a freeze are not counted** (lost, not queued) |
| read | `sel_agg_i = 1`: aggregate **shadow** bank `shad_q[sel_cnt_i]` (valid for `sel_cnt_i < 33`, else 0). `sel_agg_i = 0`: live per-PC counter `pc_q[sel_pc_i][sel_cnt_i]` (valid for `sel_pc_i < N` and `sel_cnt_i < 44`, else 0; `PER_PC_EN = 0` returns 0). Combinational, 64 bit, zero-extended. Reads never clear anything |
| consistency | the aggregate shadow gives a mutually consistent multi-register read after one `snap_i`. **Per-PC counters have no shadow** ("area"): read them under `freeze_i` for a consistent view |

Area: `PER_PC_EN = 1` holds `N * 44 * CNT_W` flops of per-PC counters (arithmetic: 64 pseudo-channels at `CNT_W = 48` is 135,168 flops, the "~135k flops" of the module header). It is "a verification / bring-up instrument, not an ASIC default";
`PER_PC_EN = 0` keeps only the aggregates. Synthesis numbers: see `reports/synth/` (generated).

## 5. Caveats (from the RTL)

1. `evt.act`/`evt.pre` count issued commands: a `PREA` counts as **one** `pre`, regardless of how many banks it closes.
2. `timing_stall` is a catch-all (credits, PRE protection and timing, `SCHEDULER.md` section 9).
3. `lat` stops at the pseudo-channel boundary; the time a request waits at the top level (`ev_stall_id`, `ev_stall_q`, `ev_stall_fence`) is not in `lat_sum` and is counted separately (aggregate 23..25, one count per stalled cycle of the single host port).
4. The aggregate `bytes_*` count completed transactions' payload bytes including error completions (section 1).
5. Reads/writes that were accepted but not yet completed are in `acc_*` but not in `cmp_*`.
6. (Fixed) `sf_hbm_channel.sv` used to declare the occupancy wire as 5 bits while `sf_hbm_pseudochannel` produces `$clog2(DEPTH)+1` bits, truncating an occupancy of 32 to 0 for `DEPTH = 32`; both the wire and `tb_bench.sv`'s copy are now full width.
7. The RAS counters (`ecc_ce_o` etc.) and `res_*` residency counters of the pseudo-channel are not part of `stat_o`; only the event/`in_pd`/`in_sr` pulses are (`RAS.md`, `POWER.md`).

## 6. CSR window (`rtl/sf_hbm_csr.sv`)

Bus: `rb_sel_i`, `rb_we_i`, `rb_addr_i[11:0]` (word address), `rb_wdata_i[31:0]` -> `rb_rdata_o[31:0]`, `rb_err_o`. One access per cycle, zero wait states, **combinational read mux** (read data valid in the same cycle), writes on the clock edge.
The module header states that the shape matches the existing control-plane bus `sf_crt_regs.sv` of the SilicaFlux clock-tree project (not re-verified here). An APB wrapper is not part of this block.
Unmapped read: data 0 and `rb_err = 1`; unmapped **write**: `rb_err = 1`; writes to read-only registers: `rb_err = 1` and no effect; a read of the write-only `ECCCLR`: `rb_err = 1`.

Register map (copied from the header and checked against the read and write `case` statements; where the two differ the difference is stated):

| addr | name | access | fields (write layout) | notes |
|---|---|---|---|---|
| 0x000 | ID | RO | `{16'h4842 'HB', 8'h01 version, 8'(HBM_TXN_VERSION) txn contract}` | reads `0x4842_0101` while `HBM_TXN_VERSION = 1` |
| 0x001 | GEOMETRY | RO | `{num_stacks[7:0], num_channels[7:0], cluster_ch[7:0], depth[7:0]}` | module parameters `NUM_STACKS, NUM_CH, CL_CH, QDEPTH`: the integrator must keep them equal to the controller instance; they are not derived from it |
| 0x002 | CONTROL | RW | `[0]` enable (`cfg.enable`, starts the init sequence / allows traffic) | reset 0 |
| 0x003 | STATUS | RO | `[0]` ready, `[1]` init_error, `[4:2]` init_cause, `[7:5]` init_state, `[9:8]` profile_status (0 = HYPOTHETICAL_SIM), `[10]` perf_overflow, `[11]` any_unimplemented_phy, `[12]` ecc_alert_any, `[13]` per-bank refresh selected on a profile where it is infeasible | all fed by integrator-supplied inputs |
| 0x004 | PROFILE | RW | `[3:0]` timing-profile select | reset 1 (`sim_ref`); "change only while idle" |
| 0x005 | MAPCFG | RW | `[1:0]` map mode, `[4:2]` interleave bits, `[8]` hash | |
| 0x006 | SCHED0 | RW | `[2:0]` policy, `[4]` prio_en, `[5]` batch_en, `[6]` deadline_en, `[9:8]` page policy | read-back layout = write layout (an earlier read concatenation placed the page policy at `[10:9]`; found by review, fixed, and now covered by `tb_top_csr` `rw_readback`) |
| 0x007 | SCHED1 | RW | `[7:0]` batch_len, `[23:8]` starve_limit | reset batch_len = 8, starve_limit = 0 (off) |
| 0x008 | SCHED2 | RW | `[15:0]` deadline_thr, `[31:16]` close_timeout | reset deadline_thr = 0, close_timeout = 32 |
| 0x009 | REFCFG | RW | `[1:0]` mode (0 AB, 1 PB, 2 off), `[2]` eager, `[3]` pull-in enable | reset: AB, eager = 1, pull-in off |
| 0x00A | POWER0 | RW | `[1:0]` request (0 active, 1 power-down, 2 self-refresh) | |
| 0x00B | POWER1 | RW | `[15:0]` auto power-down idle cycles, `[31:16]` auto self-refresh idle cycles (0 = off) | |
| 0x00C | INITTO | RW | init per-state timeout cycles (0 = none) | reset 100000 |
| 0x00D | ECCCFG | RW | `[0]` controller ECC enable | |
| 0x00E | ECCINJ | RW | `[1:0]` mode, `[10:2]` bit, `[31:16]` target pseudo-channel; writing bit 12 = 1 arms the injector | `inj_arm_o` is a registered 1-cycle pulse (self-clearing; bit 12 reads 0); mode/bit/pc are registered with the same write |
| 0x00F | ECCCLR | WO | any write clears the ECC/RAS counters and log | registered 1-cycle pulse `ecc_clear_o` |
| 0x010 | ECCLOG | RO | `[8:0]` syndrome, `[9]` valid, `[10]` uncorrectable, `[31:16]` pseudo-channel | `sf_hbm_top` shows the lowest-numbered pseudo-channel that holds a log entry |
| 0x011 | MAXBURST | RW | `[7:0]` host burst limit - 1 (16 B NoC beats) | reset 31. The controller does not use `cfg.max_burst_m1`; `sf_hbm_top` exports it (`max_burst_m1_o`) to `sf_hbm_datafabric.max_burst_m1_i` and `sf_hbm_dma_adapter.node_max_burst_m1_i` |
| 0x012 | ADDRHI | RW | `[7:0]` HBM byte-address bits `[39:32]` | reset 0; exported as `addr_hi_o` to the DataFabric node (its NoC address is only 32 bit) and to the DMA adapter |
| 0x020 | PERFCTL | RW | `[0]` freeze; writing `[4]` = 1 pulses clear, `[5]` = 1 pulses snapshot (self-clearing) | read returns `[0]` only |
| 0x021 | PERFSEL | RW | `[15:0]` pseudo-channel, `[21:16]` counter id, `[24]` 1 = read aggregate (snapshot bank) | |
| 0x022 | PERFLO | RO | selected counter `[31:0]` | |
| 0x023 | PERFHI | RO | selected counter `[63:32]` | |
| 0x030 | ERRSTAT | RO/W1C | sticky: `[0]` DRAM-model/bank violation, `[1]` read-return protocol error, `[2]` refresh deadline miss, `[3]` ECC uncorrectable | writing 1 to a bit clears it; an event in the same cycle as a clear wins (the bit stays set) |
| 0x040 | PROFINFO | RO | `[15:0]` clock MHz of the selected profile (informational) | `hbm_profile_mhz()` of the generated `sf_hbm_profile_pkg` (field `clock_mhz` of `configs/timing/profiles.json`), not used by any timing rule |

Reset defaults (`sf_hbm_csr.sv`): `enable = 0`; FR-FCFS; open page; AB refresh eager; profile 1 (`sim_ref`); all other `hbm_cfg_t` fields 0.
Outputs: `cfg_o` (`hbm_cfg_t`) and the pulses go to `sf_hbm4_controller`/`sf_hbm_perf`; the status inputs are produced from `stat_o`, `ready_o`, `init_*_o`, `ref_cfg_infeasible_o` by the glue in `sf_hbm_top`.

## 7. Verification that exists

| what | where |
|---|---|
| aggregate counters equal the testbench's own tallies (acc/cmp counts, bytes incl. byte-enable popcount, row hit/empty/conflict, act, pre, `lat_cnt`); `hit + empty + conflict` equals the number of column commands; per-PC `acc_*` sum to the aggregate; the snapshot bank does not change without a new snapshot; freeze: events during freeze are not counted; clear zeroes per-PC, aggregate, `ovf` | `verification/tests/tb_ctrl_multi.sv` test `perf` (`perf_counters_exact`), built for 1/2/4/8 channels by `scripts/regress.py` |
| lint | `scripts/regress.py` group `lint`: `lint_sf_hbm_perf`, `lint_sf_hbm_csr` |

`tb_top_csr` (built twice: `PERF_W = 48` for exact tallies, `PERF_W = 6` for saturation) covers the whole CSR block, PERFSEL/PERFLO/PERFHI 64-bit reads, snapshot / freeze / clear, counter saturation and the `ovf` flag. Still not covered by any simulation: the latency histogram, `lat_max`/`occ_max`, `pd_cycles`/`sr_cycles`, the `stall_*` aggregates and `PER_PC_EN = 0` (the last is only synthesized).
