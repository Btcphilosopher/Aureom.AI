# Power-state sequencing (`rtl/sf_hbm_power_state.sv`)

> **Status.** The commands `PDE / PDX / SRE / SRX` are **abstract** (`hbm_cmd_e`), not JEDEC encodings. Whether HBM4 offers each state, its entry/exit rules and its exit latencies is `UNVERIFIED`
> (`docs/STANDARDS_MATRIX.md` REF-03). The exit latencies `txp`/`txs` come from the timing profile, which is `HYPOTHETICAL_SIM` in every shipped profile. There is no standard value in this document.

One sequencer per pseudo-channel (`u_pwr` in `sf_hbm_pseudochannel.sv`). It requests maintenance commands through the scheduler's maintenance port (`SCHEDULER.md` section 6), holds demand traffic while the DRAM is (becoming) low-power,
and cooperates with the refresh engine (`rtl/sf_hbm_refresh.sv`).

## 1. States

`state_o[2:0]` (also `stat_o[].pwr_state`):

| code | state | `hold_o` (blocks demand ACT + column) | `pause_ref_o` | maintenance command requested |
|---|---|---|---|---|
| 0 | `PW_ACTIVE` | 0 | 0 | -- |
| 1 | `PW_PREP` | 0 ("PREP keeps serving until it must close rows") | 0 | `PREA` while `!all_idle_i` |
| 2 | `PW_ENTER` | 1 | 1 only if the target is self-refresh | `PDE` or `SRE` |
| 3 | `PW_PD` (power-down) | 1 | 0 | -- |
| 4 | `PW_SR` (self-refresh) | 1 | 1 | -- |
| 5 | `PW_EXIT` | 1 | 0 (`pause_ref_o = (st == SR) \|\| (st == ENTER && tgt_sr)`) | `PDX` or `SRX` |
| 6 | `PW_WAKE` | 1 | 0 | -- |

All maintenance commands requested by this block have `mnt_prio = 1` (they beat demand when legal). `PDX`/`SRX` are legal regardless of `phy_ready`; every other command requires it.

```
                      want_low                    all_idle && quiet                 grant of PDE/SRE
   +---------+  (enable && quiet &&    +------+  ---------------------->  +-------+  ------------->  +----------+
   | ACTIVE  |   !work_pending &&      | PREP |                           | ENTER |                   | PD | SR  |
   |   (0)   |   (want_sr || want_pd)) | (1)  |  <-- work_pending || !enable  (2)   |  <-- work_pending &&  | (3)|(4) |
   +---------+ ----------------------> +------+      (abort to ACTIVE)     +-------+      !grant (abort)  +----------+
       ^                                                                                                      |
       |  wake_cnt == 0                    grant of PDX/SRX                                                    | exit condition (section 3)
   +--------+  <------------------------  +------+  <-----------------------------------------------------------+
   | WAKE   |                             | EXIT |
   |  (6)   |  <--- txp-1 | txs-1 ---     | (5)  |
   +--------+                             +------+
```

## 2. Entry

Signals and their sources (`sf_hbm_pseudochannel.sv`):

| input | source |
|---|---|
| `enable_i` | `ctrl_enable_i` (controller ready) |
| `req_i[1:0]` | `pwr_req_i` = `cfg.pwr_req`, CSR `POWER0`: 0 active, 1 power-down, 2 self-refresh (3 reserved) |
| `pd_idle_i`, `sr_idle_i` | `cfg.pd_idle`, `cfg.sr_idle`, CSR `POWER1`: cycles of continuous idle that arm automatic entry, `0` = disabled |
| `quiet_i` | `q_empty && completion buffer empty && write-pending FIFO empty && !rf_active` (no refresh sequence in progress) |
| `work_pending_i` | `req_valid_i || !q_empty` of that pseudo-channel (a request being offered counts even before acceptance) |
| `all_idle_i` | every bank precharged with its bank-local timers elapsed (`&bk_idle`) |
| `ref_urgent_i` | refresh debt `>= max_postpone` |

```
want_sr  = (req_i == 2) || (sr_idle_i != 0 && idle_cnt_q >= sr_idle_i)
want_pd  = (req_i == 1) || (pd_idle_i != 0 && idle_cnt_q >= pd_idle_i)
want_low = enable_i && quiet_i && !work_pending_i && (want_sr || want_pd)
ACTIVE --want_low--> PREP,  target = SR if want_sr else PD
```

`idle_cnt_q` (16 bit, saturating) increments in every `ACTIVE` cycle with `quiet_i && !work_pending_i`, is cleared in `ACTIVE` otherwise and in `PD`/`SR`; it is not changed in `PREP`/`ENTER`/`EXIT`/`WAKE`.
Derived consequences: self-refresh has priority when both are wanted; there is **no `PD -> SR` promotion** (the counter is cleared in `PD`), so an automatic self-refresh entry can only happen if `sr_idle <= pd_idle` or `pd_idle = 0`.

**Safe entry** (module header): low power is entered only when nothing is queued, in flight, or waiting for write data / read return; no refresh sequence is running; every bank is precharged (`PREA` is issued during `PREP` if any row is open).

| state | rule |
|---|---|
| `PREP` | `work_pending_i || !enable_i` -> `ACTIVE` (abort). Else `all_idle_i && quiet_i` -> `ENTER`. Otherwise stay (demand is still served, a refresh may still start: `block_i` excludes `PREP`) |
| `ENTER` | `work_pending_i && !mnt_grant_i` -> `ACTIVE` (**abort before the command left**: requests are never stranded behind a low-power command). `mnt_grant_i` -> `PD` or `SR` (a request arriving in the same cycle as the grant does not abort) |

`PDE`/`SRE` are legal in the scheduler only when all banks are idle, `tm_ok_misc` holds (no `tMRD/tXP/tXS` window) and the PHY is ready (`SCHEDULER.md` section 6).
`!enable_i` is not an abort condition in `ENTER`.

## 3. Wake and exit

| state | exit rule |
|---|---|
| `PD` | -> `EXIT` if `((req_i == 0) && work_pending_i) || ref_urgent_i`, or if `!enable_i` |
| `SR` | -> `EXIT` if `(req_i == 0) && work_pending_i`, or if `!enable_i`. **Refresh urgency does not wake self-refresh** (the DRAM refreshes itself) |
| `EXIT` | `PDX`/`SRX` is requested; on grant -> `WAKE`, `wake_cnt_q <= hbm_ld(txs or txp)`, and for a self-refresh exit a one-cycle registered pulse `ref_clear_o` is raised |
| `WAKE` | counts `wake_cnt_q` down to 0, then -> `ACTIVE` (the state lasts `max(1, N)` cycles for `N = txp` or `txs`). Demand stays held (`hold_o = 1`) |

**Wake rules in words**

* New work wakes `PD`/`SR` **only once the power request is withdrawn** (`req_i == 0`). While `pwr_req` stays at 1 or 2, requests are still *accepted* into the queue (the queue and `req_ready_o` do not look at the power state)
  but are not served. (`pwr_req = 3`, reserved, also never wakes on work, because the test is `req_i == 2'd0`.)
* **An urgent refresh wakes power-down even if power-down is still requested** ("refresh cannot be issued into a powered-down DRAM and must not be starved by a held request"). After the wake the channel is `ACTIVE`, serves the queued
  work and the refresh, and re-enters power-down when it is quiet again (`want_low` is still true while `req_i == 1`).
* In addition to the sequencer's own `WAKE` count, `sf_hbm_timing` blocks every command except `PDX/SRX` for `txp`/`txs` cycles after the exit command (`c_x`, loaded on the `pdx_i`/`srx_i` strobes).

## 4. Interaction with the refresh engine

| signal | value | effect in `sf_hbm_refresh` |
|---|---|---|
| `block_i` | `pwr_state != ACTIVE && pwr_state != PREP`, i.e. `ENTER`, `PD`, `SR`, `EXIT`, `WAKE` (wiring in `sf_hbm_pseudochannel.sv`) | no refresh sequence **starts**; a sequence still in its `HOLD` state falls back to `IDLE`. **The debt keeps accruing.** (The refresh header also says "never START or continue a sequence", but the code only tests `block_i` at the start and in `HOLD`; sequences already in `PREA/PREWAIT/REF` are not aborted. This cannot happen at `PREP -> ENTER` because that transition requires `quiet_i`, which includes `!rf_active`.) |
| `pause_i` | `SR`, or `ENTER` with an SR target | interval timer frozen (`ivl_cnt_q` holds), no debt accrual, no start |
| `clear_i` | `ref_clear_o` (self-refresh exit) | debt set to 0 and the interval timer reloaded: "the DRAM refreshed itself" |
| `ref_urgent_i` (to the power block) | debt `>= max_postpone` | wakes `PD` (not `SR`) |

Powered-down refresh behaviour: while in `PD` the controller issues no refresh; debt accrues; when it becomes urgent the channel is woken, `block_i` drops when the state returns to `ACTIVE` (after `EXIT` and `WAKE`), and the refresh engine
starts a (forced) sequence. `deadline_miss` (debt `> max_postpone`) is the monitor for this path; it pulses `evt.deadline_miss` and is an `$error` in simulation (`sf_hbm_pseudochannel.sv`).
The refresh header attributes the discovery of the `block_i` rule to the `tb_pc_single` power test.

## 5. Residency counters

| counter | counts cycles in | width / overflow | observability |
|---|---|---|---|
| `res_active_o` | every state except `PD` and `SR` (so including `PREP`, `ENTER`, `EXIT`, `WAKE`) | 32 bit, **wraps** (no saturation); cleared only by reset | pseudo-channel port only: `sf_hbm_channel.sv` leaves it unconnected |
| `res_pd_o` | `PW_PD` | 32 bit, wraps | pseudo-channel port only |
| `res_sr_o` | `PW_SR` | 32 bit, wraps | pseudo-channel port only |
| `pd_cycles`, `sr_cycles` (per-PC counters 30, 31; aggregate 31, 32 of `sf_hbm_perf`) | `evt.in_pd` (`pwr_state == 3`), `evt.in_sr` (`pwr_state == 4`) | `CNT_W` (48) saturating, with clear/snapshot/freeze | available at the controller level through `stat_o` (`PERF_COUNTERS.md`) |

Residency values from the benchmarks: <!-- RESULTS: filled in by scripts/make_report.py -->.

## 6. Dynamic frequency / voltage switching: not implemented

Nothing in `rtl/` changes a clock frequency, a voltage or a PHY speed grade, and no state of this sequencer represents such a transition. The module header states why: it "needs a documented PHY and system-level contract".
Supporting facts from the repository:

* HBMCore generates no clocks and owns no clock gating (`CDC_AND_CLOCKS.md`); a frequency change would be a PHY/clock-tree service that is outside this block.
* The PHY clock ratio is 1:1 only and PHY training is an external service (`PHY_CONTRACT.md`); a frequency change normally implies re-training, which has no interface here.
* Timing profiles are quasi-static hypothetical tables. `profile_sel` (CSR `PROFILE`, "change only while idle") swaps the cycle counts used by the timing machinery; it does not change a clock and has no quiesce/drain/retime sequencing.
* No temperature or thermal input exists (`STANDARDS_MATRIX.md` REF-05, UNIMPLEMENTED).

## 7. Verification that exists

| test | file | what it checks |
|---|---|---|
| `power` (`power_states_pd_sr_auto`) | `verification/tests/tb_pc_single.sv` | power-down on request (waits for state 3, checks the DRAM model's `in_pd`, no wake while requested, wake after withdrawal and traffic served, `res_pd != 0`); self-refresh held for `6*trefi` then traffic (`res_sr != 0`, DRAM model's `in_sr`); automatic entry with `pd_idle = 40` and automatic wake; 12 rounds of randomised `pwr_req` interleaved with traffic ("nothing may be lost and no timing rule may break") |
| `refresh`, `refmodes` | same | refresh under traffic, per-bank, lazy/forced refresh (`ref_forced` must become non-zero under a saturating stream) |
| `perf` | `tb_ctrl_multi.sv` | counter semantics (not the power counters) |

Not covered by a *directed* test in the repository: the "urgent refresh wakes power-down while still requested" rule in isolation, `pwr_req = 3`, automatic self-refresh entry, aborts in `PREP`/`ENTER`, and `PW_WAKE` durations against a profile.
The randomised part of `power` can reach some of them incidentally; the repository does not record which.
