// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_refresh.sv
//  Refresh manager of one pseudo-channel.
//
//  MODEL (abstract; refresh MODE availability for HBM4 is UNVERIFIED - docs/STANDARDS_MATRIX.md)
//    A free-running interval counter adds one unit of refresh DEBT every tREFI cycles
//    (all-bank mode) or every tREFI/NUM_BANKS cycles (per-bank mode). Each completed refresh
//    command repays one unit.
//        debt >  0            refresh owed
//        debt >= max_postpone refresh URGENT: new ACT and (all-bank) column commands are held,
//                             the sequence gets scheduler priority -> refresh cannot be starved
//        debt <= -max_pullin  no more pull-in
//    Postponement is therefore bounded by max_postpone intervals and pull-in by max_pullin
//    intervals - both profile fields, never implicit.
//    deadline_miss_o pulses if debt ever exceeds max_postpone (must never happen; asserted in tests).
//
//  START CONDITIONS
//      urgent
//      || (cfg.eager && debt > 0)
//      || (queue idle && (debt > 0 || (cfg.pullin_en && debt > -max_pullin)))
//
//  SEQUENCE (all-bank):  HOLD (no new ACT) -> PREA until every bank idle -> REF_AB -> back to IDLE.
//           (per-bank):  HOLD target bank -> PRE if open -> wait idle -> REF_PB(bank) -> next bank.
//  The sequence is expressed as maintenance commands; sf_hbm_scheduler arbitrates them against
//  demand traffic and only grants them when every timing rule allows.
//
//  pause_i (self-refresh) freezes the engine; block_i (power state ENTER, PD, SR, EXIT or WAKE, i.e. neither ACTIVE nor PREP) stops a sequence from starting - and aborts one still in its HOLD phase - while the debt keeps accruing,
//  so a refresh that becomes urgent during power-down is serviced after the power module wakes the channel (found by tb_pc_single power test); clear_i (self-refresh exit) zeroes debt,
//  because the DRAM refreshed itself.
//  RESET: async assert; debt 0, IDLE.
//  KNOWN LIMITATIONS: refresh-management / DRFM commands are not issued here (sf_hbm_rfm hook, see docs).
// =============================================================================
module sf_hbm_refresh
  import sf_hbm_pkg::*;
(
  input  logic                         clk_i,
  input  logic                         rst_ni,
  input  hbm_timing_t                  tp_i,
  input  hbm_ref_cfg_t                 cfg_i,
  input  logic                         enable_i,        // controller ready
  input  logic                         pause_i,         // self-refresh: timer frozen, sequencer idle
  input  logic                         block_i,         // channel not ACTIVE/PREP: never START a sequence and abort one still in HOLD; PREA/PREWAIT/REF run to completion (power-down entry waits for quiet_o, which includes this engine being idle); debt keeps accruing
  input  logic                         clear_i,
  input  logic                         queue_idle_i,

  input  logic [HBM_NUM_BANKS-1:0]     bk_idle_i,
  input  logic [HBM_NUM_BANKS-1:0]     bk_row_open_i,

  output logic                         mnt_valid_o,
  output hbm_cmd_t                     mnt_cmd_o,
  output logic                         mnt_prio_o,
  input  logic                         mnt_grant_i,

  output logic                         hold_act_o,
  output logic                         hold_col_o,
  output logic                         hold_bank_valid_o,
  output logic [HBM_BANK_W-1:0]        hold_bank_o,
  output logic                         hold_bank_col_o,

  output logic signed [7:0]            debt_o,
  output logic                         urgent_o,
  output logic                         active_o,        // a refresh sequence is in progress
  output logic                         ev_ref_o,
  output logic                         ev_forced_o,
  output logic                         ev_pullin_o,
  output logic                         deadline_miss_o
);
  localparam int unsigned NB = HBM_NUM_BANKS;

  typedef enum logic [2:0] {R_IDLE, R_HOLD, R_PREA, R_PREWAIT, R_REF} rstate_e;
  rstate_e st_q;

  logic [15:0]        ivl_cnt_q;
  logic signed [7:0]  debt_q;
  logic [HBM_BANK_W-1:0] ptr_q;

  wire pb_mode  = (cfg_i.mode == REFMODE_PB);
  wire off_mode = (cfg_i.mode == REFMODE_OFF);

  logic [15:0] interval;
  always_comb begin
    interval = pb_mode ? (tp_i.trefi >> HBM_BANK_W) : tp_i.trefi;
    if (interval == 16'd0) interval = 16'd1;
  end

  wire signed [8:0] mp = $signed({1'b0, tp_i.max_postpone[7:0]});
  wire signed [8:0] mu = $signed({1'b0, tp_i.max_pullin[7:0]});
  wire signed [8:0] debt_ext = {debt_q[7], debt_q};

  wire urgent   = !off_mode && (debt_ext >= mp);
  wire pending  = (debt_ext > 9'sd0);
  wire can_pull = cfg_i.pullin_en && (debt_ext > -mu);
  wire start    = !off_mode && enable_i && !pause_i && !block_i &&
                  (urgent || (cfg_i.eager && pending) || (queue_idle_i && (pending || can_pull)));

  assign debt_o   = debt_q;
  assign urgent_o = urgent;
  assign active_o = (st_q != R_IDLE);

  logic all_idle;
  assign all_idle = &bk_idle_i;

  // ---- maintenance command / holds (combinational from state) ----------------
  always_comb begin
    mnt_valid_o       = 1'b0;
    mnt_cmd_o         = '0;
    mnt_prio_o        = urgent;
    hold_act_o        = 1'b0;
    hold_col_o        = 1'b0;
    hold_bank_valid_o = 1'b0;
    hold_bank_o       = ptr_q;
    hold_bank_col_o   = 1'b0;
    case (st_q)
      R_HOLD, R_PREA, R_PREWAIT, R_REF: begin
        if (!pb_mode) begin
          hold_act_o = 1'b1;
          hold_col_o = urgent;
        end else begin
          hold_bank_valid_o = 1'b1;
          hold_bank_col_o   = urgent;
        end
        if (st_q == R_PREA) begin
          mnt_valid_o = 1'b1;
          if (pb_mode) begin
            mnt_cmd_o.cmd = HCMD_PRE;
            mnt_cmd_o.bg  = hbm_bg_t'(ptr_q[HBM_BANK_W-1 -: HBM_BG_W]);
            mnt_cmd_o.ba  = hbm_ba_t'(ptr_q[HBM_BA_W-1:0]);
          end else begin
            mnt_cmd_o.cmd = HCMD_PREA;
          end
        end else if (st_q == R_REF) begin
          mnt_valid_o = 1'b1;
          mnt_prio_o  = 1'b1;
          if (pb_mode) begin
            mnt_cmd_o.cmd = HCMD_REF_PB;
            mnt_cmd_o.bg  = hbm_bg_t'(ptr_q[HBM_BANK_W-1 -: HBM_BG_W]);
            mnt_cmd_o.ba  = hbm_ba_t'(ptr_q[HBM_BA_W-1:0]);
          end else begin
            mnt_cmd_o.cmd = HCMD_REF_AB;
          end
        end
      end
      default: ;
    endcase
  end

  wire target_idle = pb_mode ? bk_idle_i[ptr_q] : all_idle;
  wire target_open = pb_mode ? bk_row_open_i[ptr_q] : (|bk_row_open_i);

  logic tick;
  assign tick = (ivl_cnt_q == 16'd0);

  // next debt value (combinational): accrual on the interval tick, repayment on a granted REF
  logic signed [8:0] nd_c;
  always_comb begin
    nd_c = debt_ext;
    if (off_mode || clear_i || !enable_i) begin
      if (clear_i) nd_c = 9'sd0;
    end else if (!pause_i) begin
      if (tick) nd_c = nd_c + 9'sd1;
    end
    if (st_q == R_REF && mnt_grant_i) nd_c = nd_c - 9'sd1;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= R_IDLE; ivl_cnt_q <= 16'd0; debt_q <= '0; ptr_q <= '0;
      ev_ref_o <= 1'b0; ev_forced_o <= 1'b0; ev_pullin_o <= 1'b0; deadline_miss_o <= 1'b0;
    end else begin
      ev_ref_o <= 1'b0; ev_forced_o <= 1'b0; ev_pullin_o <= 1'b0; deadline_miss_o <= 1'b0;

      // interval timer
      if (off_mode || clear_i || !enable_i) begin
        ivl_cnt_q <= interval - 16'd1;
      end else if (!pause_i) begin
        if (tick) ivl_cnt_q <= interval - 16'd1;
        else      ivl_cnt_q <= ivl_cnt_q - 16'd1;
      end

      // sequencer
      case (st_q)
        R_IDLE: if (start) st_q <= R_HOLD;
        R_HOLD: begin
          if (pause_i || off_mode || block_i) st_q <= R_IDLE;
          else if (target_open)    st_q <= R_PREA;
          else if (target_idle)    st_q <= R_REF;
          else                     st_q <= R_PREWAIT;   // closing / refreshing already in flight
        end
        R_PREA: if (mnt_grant_i) st_q <= R_PREWAIT;
        R_PREWAIT: begin
          if (target_idle) st_q <= R_REF;
          else if (target_open) st_q <= R_PREA;        // something re-opened the target (should not happen under hold)
        end
        R_REF: if (mnt_grant_i) begin
          st_q <= R_IDLE;
          ev_ref_o    <= 1'b1;
          ev_forced_o <= urgent;
          ev_pullin_o <= !pending;
          if (pb_mode) ptr_q <= ptr_q + HBM_BANK_W'(1);
        end
        default: st_q <= R_IDLE;
      endcase

      // saturate debt into the 8-bit register; flag a missed deadline
      if (nd_c > mp) deadline_miss_o <= 1'b1;
      if (nd_c > 9'sd100)       debt_q <= 8'sd100;
      else if (nd_c < -9'sd100) debt_q <= -8'sd100;
      else                      debt_q <= nd_c[7:0];
    end
  end
endmodule : sf_hbm_refresh
