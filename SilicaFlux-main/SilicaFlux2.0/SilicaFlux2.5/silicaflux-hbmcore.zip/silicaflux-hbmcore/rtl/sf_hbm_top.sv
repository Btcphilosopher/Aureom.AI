// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_top.sv
//  Complete controller instance: sf_hbm4_controller + sf_hbm_perf + sf_hbm_csr.
//
//  This is the block a SoC integrates (docs/ARCHITECTURE.md).  It only adds glue to the three verified blocks:
//    * CSR register bus (rb_*, same shape as sf_crt_regs) drives the runtime configuration cfg_i of the controller, the RAS
//      injection controls and the performance-counter controls;
//    * the OR-reductions of the per-pseudo-channel status bundles (unimplemented-PHY, ECC alert, violation, protocol error,
//      refresh-deadline miss, uncorrectable error) feed the CSR status / sticky error registers;
//    * ECCLOG shows the LOWEST-NUMBERED pseudo-channel whose ECC log holds an entry (a stateless selection, not the
//      chronologically first error across pseudo-channels; per-PC logs are the exact source and are cleared by ECCCLR);
//    * addr_hi_o / max_burst_m1_o export the DataFabric-node settings (CSR ADDRHI / MAXBURST).
//  The PHY side is the controller's simulation bundle unchanged: the controller / PHY separation is NOT altered here.
//  PERF_CNT_W < 48 is for tests only (saturation is observable on a short run).
//  RESET: async assert.
// =============================================================================
module sf_hbm_top
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;
#(
  parameter int unsigned NUM_STACKS     = 1,
  parameter int unsigned NUM_CHANNELS   = 32,
  parameter int unsigned CH_PER_CLUSTER = 8,
  parameter int unsigned DEPTH          = 16,
  parameter int unsigned CPL_DEPTH      = 8,
  parameter int unsigned TRK_SRC_W      = 2,
  parameter int unsigned TRK_ID_W       = 4,
  parameter int unsigned PHY_BACKEND    = 0,
  parameter int unsigned PHY_CMD_LAT    = 0,
  parameter int unsigned PHY_RD_LAT     = 0,
  parameter bit          WR_ACK_AT_DATA = 1'b1,
  parameter int unsigned NUM_MRS        = 4,
  parameter int unsigned PERF_CNT_W     = 48,
  parameter bit          PERF_PER_PC    = 1'b1
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  // register bus
  input  logic                         rb_sel_i,
  input  logic                         rb_we_i,
  input  logic [11:0]                  rb_addr_i,
  input  logic [31:0]                  rb_wdata_i,
  output logic [31:0]                  rb_rdata_o,
  output logic                         rb_err_o,

  // exported configuration (DataFabric node)
  output logic [7:0]                   addr_hi_o,
  output logic [7:0]                   max_burst_m1_o,
  output hbm_cfg_t                     cfg_o,

  // bring-up handshakes with the external PHY / power / clock infrastructure
  input  logic                         power_good_i,
  input  logic                         clk_stable_i,
  input  logic                         phy_init_done_i,
  input  logic                         train_done_i,
  output logic                         phy_init_start_o,
  output logic                         train_start_o,
  output logic                         ready_o,

  // host request / response
  input  logic                         req_valid_i,
  output logic                         req_ready_o,
  input  hbm_addr_t                    req_addr_i,
  input  logic                         req_write_i,
  input  logic                         req_fence_i,
  input  hbm_id_t                      req_id_i,
  input  hbm_src_t                     req_src_i,
  input  hbm_qos_t                     req_qos_i,
  input  hbm_order_e                   req_order_i,
  input  hbm_data_t                    req_wdata_i,
  input  hbm_mask_t                    req_wmask_i,
  output logic                         rsp_valid_o,
  input  logic                         rsp_ready_i,
  output hbm_rsp_t                     rsp_o,

  // simulation-PHY side (unchanged controller interface)
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 phy_ready_ext_i,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 phy_event_i,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 ondie_event_i,
  output logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_cmd_valid_o,
  output hbm_cmd_t [NUM_STACKS*NUM_CHANNELS*2-1:0]             sim_cmd_o,
  output logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_wvalid_o,
  output hbm_data_t [NUM_STACKS*NUM_CHANNELS*2-1:0]            sim_wdata_o,
  output hbm_mask_t [NUM_STACKS*NUM_CHANNELS*2-1:0]            sim_wmask_o,
  output hbm_ecc_t [NUM_STACKS*NUM_CHANNELS*2-1:0]             sim_wecc_o,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_rvalid_i,
  input  hbm_data_t [NUM_STACKS*NUM_CHANNELS*2-1:0]            sim_rdata_i,
  input  hbm_ecc_t [NUM_STACKS*NUM_CHANNELS*2-1:0]             sim_recc_i,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_rerr_i,

  output logic [15:0]                  outstanding_o
);
  localparam int unsigned NPC = NUM_STACKS * NUM_CHANNELS * 2;

  hbm_cfg_t cfg;
  logic     ecc_clear, inj_arm, perf_clear, perf_snap, perf_freeze, perf_agg;
  logic [15:0] inj_pc, perf_pc;  logic [1:0] inj_mode;  logic [8:0] inj_bit;  logic [5:0] perf_cnt;
  logic     init_error;  logic [2:0] init_cause, init_state;
  hbm_pc_stat_t [NPC-1:0] stat;
  logic ev_sid, ev_sq, ev_sf, ref_infeasible;
  logic [63:0] perf_rd;  logic perf_ovf;

  sf_hbm4_controller #(
    .NUM_STACKS(NUM_STACKS), .NUM_CHANNELS(NUM_CHANNELS), .CH_PER_CLUSTER(CH_PER_CLUSTER), .DEPTH(DEPTH),
    .CPL_DEPTH(CPL_DEPTH), .TRK_SRC_W(TRK_SRC_W), .TRK_ID_W(TRK_ID_W), .PHY_BACKEND(PHY_BACKEND),
    .PHY_CMD_LAT(PHY_CMD_LAT), .PHY_RD_LAT(PHY_RD_LAT), .WR_ACK_AT_DATA(WR_ACK_AT_DATA), .NUM_MRS(NUM_MRS)
  ) ctrl (
    .clk_i, .rst_ni, .cfg_i(cfg),
    .power_good_i, .clk_stable_i, .phy_init_done_i, .train_done_i,
    .phy_init_start_o, .train_start_o, .ready_o, .init_error_o(init_error), .init_cause_o(init_cause), .init_state_o(init_state),
    .req_valid_i, .req_ready_o, .req_addr_i, .req_write_i, .req_fence_i, .req_id_i, .req_src_i, .req_qos_i, .req_order_i,
    .req_wdata_i, .req_wmask_i, .rsp_valid_o, .rsp_ready_i, .rsp_o,
    .ecc_clear_i(ecc_clear), .inj_arm_i(inj_arm), .inj_pc_i(inj_pc), .inj_mode_i(inj_mode), .inj_bit_i(inj_bit),
    .phy_ready_ext_i, .phy_event_i, .ondie_event_i,
    .sim_cmd_valid_o, .sim_cmd_o, .sim_wvalid_o, .sim_wdata_o, .sim_wmask_o, .sim_wecc_o,
    .sim_rvalid_i, .sim_rdata_i, .sim_recc_i, .sim_rerr_i,
    .stat_o(stat),
    .ev_accept_o(), .ev_accept_rd_o(), .ev_accept_wr_o(), .ev_err_req_o(),
    .ev_stall_id_o(ev_sid), .ev_stall_q_o(ev_sq), .ev_stall_fence_o(ev_sf),
    .outstanding_o, .ref_cfg_infeasible_o(ref_infeasible)
  );

  sf_hbm_perf #(.N(NPC), .CNT_W(PERF_CNT_W), .PER_PC_EN(PERF_PER_PC)) perf (
    .clk_i, .rst_ni, .stat_i(stat), .ev_stall_id_i(ev_sid), .ev_stall_q_i(ev_sq), .ev_stall_fence_i(ev_sf),
    .clear_i(perf_clear), .snap_i(perf_snap), .freeze_i(perf_freeze),
    .sel_pc_i(perf_pc), .sel_cnt_i(perf_cnt), .sel_agg_i(perf_agg), .rdata_o(perf_rd), .ovf_o(perf_ovf)
  );

  // ---- status reductions for the CSR ---------------------------------------------------------------------
  logic unimpl_any, alert_any, ev_viol, ev_prot, ev_dl, ev_ue;
  logic log_valid, log_ue;  logic [8:0] log_syn;  logic [15:0] log_pc;
  always_comb begin
    unimpl_any = 1'b0; alert_any = 1'b0; ev_viol = 1'b0; ev_prot = 1'b0; ev_dl = 1'b0; ev_ue = 1'b0;
    log_valid = 1'b0; log_ue = 1'b0; log_syn = '0; log_pc = '0;
    for (int i = NPC - 1; i >= 0; i--) begin            // descending loop: the LOWEST index wins the log registers
      unimpl_any |= stat[i].unimpl;
      alert_any  |= stat[i].ecc_alert;
      ev_viol    |= stat[i].evt.violation;
      ev_prot    |= stat[i].evt.rd_timing_err | stat[i].evt.rd_timeout | stat[i].evt.rd_unexpected;
      ev_dl      |= stat[i].evt.deadline_miss;
      ev_ue      |= stat[i].evt.ecc_ue;
      if (stat[i].ecc_lv) begin log_valid = 1'b1; log_ue = stat[i].ecc_lue; log_syn = stat[i].ecc_lsyn; log_pc = 16'(i); end
    end
  end

  sf_hbm_csr #(.NUM_STACKS(NUM_STACKS), .NUM_CH(NUM_CHANNELS), .CL_CH(CH_PER_CLUSTER), .QDEPTH(DEPTH)) csr (
    .clk_i, .rst_ni,
    .rb_sel_i, .rb_we_i, .rb_addr_i, .rb_wdata_i, .rb_rdata_o, .rb_err_o,
    .cfg_o(cfg), .addr_hi_o, .max_burst_m1_o,
    .ecc_clear_o(ecc_clear), .inj_arm_o(inj_arm), .inj_pc_o(inj_pc), .inj_mode_o(inj_mode), .inj_bit_o(inj_bit),
    .perf_clear_o(perf_clear), .perf_snap_o(perf_snap), .perf_freeze_o(perf_freeze),
    .perf_pc_o(perf_pc), .perf_cnt_o(perf_cnt), .perf_agg_o(perf_agg), .perf_rdata_i(perf_rd),
    .ready_i(ready_o), .init_error_i(init_error), .init_cause_i(init_cause), .init_state_i(init_state),
    .profile_status_i(hbm_profile_status(cfg.profile_sel)), .profile_mhz_i(hbm_profile_mhz(cfg.profile_sel)),
    .perf_ovf_i(perf_ovf), .unimpl_any_i(unimpl_any), .ecc_alert_any_i(alert_any), .ref_infeasible_i(ref_infeasible),
    .ecc_log_valid_i(log_valid), .ecc_log_ue_i(log_ue), .ecc_log_syn_i(log_syn), .ecc_log_pc_i(log_pc),
    .ev_violation_i(ev_viol), .ev_protocol_i(ev_prot), .ev_deadline_i(ev_dl), .ev_ue_i(ev_ue)
  );
  assign cfg_o = cfg;
endmodule : sf_hbm_top
