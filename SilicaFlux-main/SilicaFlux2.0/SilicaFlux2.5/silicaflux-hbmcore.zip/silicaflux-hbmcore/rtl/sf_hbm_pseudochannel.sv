// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_pseudochannel.sv
//  One independently scheduled pseudo-channel controller (32 DQ, 16 banks by default).
//
//      request --> req_queue --> scheduler --> bank FSMs + timing --> command encoder --> PHY adapter
//                      |                \--> completion sequencer (read_return) <-- PHY read data
//                 write_data  ---------------------------------------------------> PHY write data
//      refresh / power / init  -----> maintenance port of the scheduler
//
//  Independent scheduling per pseudo-channel is an ENGINEERING_ASSUMPTION; whether the real HBM4
//  channel shares a command bus between its two pseudo-channels is a PHY/standard question
//  (docs/MISSING_SPEC.md). Nothing here couples two pseudo-channels.
//
//  RESOURCE RELATIONSHIPS
//      request-queue slot  == write-data slot (same index)
//      queue slot is freed at column-command (or error) issue
//      completion entry is reserved at issue (credit) and freed when the response is accepted
//
//  TIMEBASE: cyc_q is a free-running 16-bit counter; all due times are modulo 2^16.
//  RESET: async assert, everything idle. enable (ctrl_enable_i) must be high for traffic; while low
//  only the init MRS maintenance port is serviced.
//  SYNTHESIS STATUS: see reports/synth/. KNOWN LIMITATIONS: one command per cycle; no auto-precharge.
// =============================================================================
module sf_hbm_pseudochannel
  import sf_hbm_pkg::*;
#(
  parameter int unsigned DEPTH          = 16,
  parameter int unsigned CPL_DEPTH      = 8,
  parameter int unsigned AGE_W          = 16,
  parameter int unsigned PEND_DEPTH     = 16,
  parameter int unsigned PHY_BACKEND    = 0,
  parameter int unsigned PHY_CMD_LAT    = 0,
  parameter int unsigned PHY_RD_LAT     = 0,
  parameter bit          WR_ACK_AT_DATA = 1'b1
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  // ---- quasi-static configuration ------------------------------------------
  input  hbm_timing_t                  tp_i,
  input  hbm_sched_cfg_t               sched_cfg_i,
  input  hbm_ref_cfg_t                 ref_cfg_i,
  input  logic                         ecc_en_i,
  input  logic                         ctrl_enable_i,
  input  logic [1:0]                   pwr_req_i,
  input  logic [15:0]                  pd_idle_i,
  input  logic [15:0]                  sr_idle_i,

  // ---- init broadcast --------------------------------------------------------
  input  logic                         init_mrs_valid_i,
  input  logic [7:0]                   init_mrs_code_i,
  output logic                         init_mrs_ack_o,

  // ---- RAS control ------------------------------------------------------------
  input  logic                         ecc_clear_i,
  input  logic                         inj_arm_i,
  input  logic [1:0]                   inj_mode_i,
  input  logic [8:0]                   inj_bit_i,

  // ---- request (granule transaction) ----------------------------------------
  input  logic                         req_valid_i,
  output logic                         req_ready_o,
  input  hbm_txn_t                     req_txn_i,
  input  hbm_data_t                    req_wdata_i,
  input  hbm_mask_t                    req_wmask_i,

  // ---- response -----------------------------------------------------------------
  output logic                         rsp_valid_o,
  input  logic                         rsp_ready_i,
  output hbm_rsp_t                     rsp_o,

  // ---- simulation-PHY side -----------------------------------------------------
  input  logic                         phy_ready_ext_i,
  input  logic                         phy_event_i,
  input  logic                         ondie_event_i,
  output logic                         sim_cmd_valid_o,
  output hbm_cmd_t                     sim_cmd_o,
  output logic                         sim_wvalid_o,
  output hbm_data_t                    sim_wdata_o,
  output hbm_mask_t                    sim_wmask_o,
  output hbm_ecc_t                     sim_wecc_o,
  input  logic                         sim_rvalid_i,
  input  hbm_data_t                    sim_rdata_i,
  input  hbm_ecc_t                     sim_recc_i,
  input  logic                         sim_rerr_i,

  // ---- status / observability ---------------------------------------------------
  output hbm_pc_evt_t                  evt_o,
  output logic [15:0]                  lat_o,          // latency of the response accepted this cycle (valid with evt_o.cmp_*)
  output logic [5:0]                   rsp_bytes_o,
  output logic [$clog2(DEPTH):0]       occ_o,
  output logic [2:0]                   pwr_state_o,
  output logic [31:0]                  res_active_o,
  output logic [31:0]                  res_pd_o,
  output logic [31:0]                  res_sr_o,
  output logic signed [7:0]            ref_debt_o,
  output logic                         quiet_o,
  output logic                         backend_unimplemented_o,
  output logic [31:0]                  ecc_ce_o,
  output logic [31:0]                  ecc_ue_o,
  output logic [31:0]                  phy_err_o,
  output logic [31:0]                  ondie_err_o,
  output logic                         ecc_log_valid_o,
  output logic                         ecc_log_ue_o,
  output logic [8:0]                   ecc_log_syn_o,
  output logic                         ecc_alert_o,
  output logic [HBM_NUM_BANKS-1:0][1:0] bank_state_o,
  output logic                         dbg_cmd_valid_o,   // command issued this cycle (pre-register)
  output hbm_cmd_t                     dbg_cmd_o
);
  localparam int unsigned NB    = HBM_NUM_BANKS;
  localparam int unsigned IW    = $clog2(DEPTH);
  localparam int unsigned CIW   = $clog2(CPL_DEPTH);
  localparam int unsigned RD_EXTRA = PHY_CMD_LAT + PHY_RD_LAT;

  // --------------------------------------------------------------------------
  // time base
  // --------------------------------------------------------------------------
  hbm_cyc_t cyc_q;
  always_ff @(posedge clk_i or negedge rst_ni)
    if (!rst_ni) cyc_q <= '0; else cyc_q <= cyc_q + hbm_cyc_t'(1);

  // --------------------------------------------------------------------------
  // request queue
  // --------------------------------------------------------------------------
  logic [IW-1:0]               push_idx;
  logic                        q_push_ready;
  logic [DEPTH-1:0]            ent_valid, ent_blocked;
  hbm_txn_t [DEPTH-1:0]        ent_txn;
  logic [DEPTH-1:0][DEPTH-1:0] ent_older;
  logic [DEPTH-1:0][AGE_W-1:0] ent_age;
  logic [IW:0]                 q_occ, q_occ_rd, q_occ_wr;
  logic                        q_full, q_empty;

  logic                        rem_valid;
  logic [IW-1:0]               rem_idx;
  logic [DEPTH-1:0]            wd_slot_busy;

  wire accept = req_valid_i && q_push_ready && ctrl_enable_i;
  assign req_ready_o = q_push_ready && ctrl_enable_i;

  sf_hbm_req_queue #(.DEPTH(DEPTH), .AGE_W(AGE_W)) u_queue (
    .clk_i, .rst_ni,
    .push_valid_i(accept), .push_ready_o(q_push_ready), .push_txn_i(req_txn_i), .push_idx_o(push_idx),
    .rem_valid_i(rem_valid), .rem_idx_i(rem_idx), .hold_i(wd_slot_busy),
    .ent_valid_o(ent_valid), .ent_txn_o(ent_txn), .ent_blocked_o(ent_blocked),
    .ent_older_o(ent_older), .ent_age_o(ent_age),
    .occ_o(q_occ), .occ_rd_o(q_occ_rd), .occ_wr_o(q_occ_wr), .full_o(q_full), .empty_o(q_empty)
  );
  assign occ_o = q_occ;

  // bytes moved by each queued write (popcount of the byte mask)
  logic [5:0] bytes_q [DEPTH];
  logic [5:0] wmask_pop;
  always_comb begin
    wmask_pop = '0;
    for (int i = 0; i < HBM_MASK_W; i++) wmask_pop = wmask_pop + 6'(req_wmask_i[i]);
  end
  always_ff @(posedge clk_i) if (accept) bytes_q[push_idx] <= req_txn_i.write ? wmask_pop : 6'(HBM_GRAN_BYTES);

  // --------------------------------------------------------------------------
  // bank FSM array
  // --------------------------------------------------------------------------
  logic [NB-1:0]            bk_row_open, bk_can_act, bk_can_rd, bk_can_wr, bk_can_pre, bk_idle, bk_viol;
  hbm_row_t [NB-1:0]        bk_open_row;
  logic [NB-1:0][1:0]       bk_state;
  logic [NB-1:0]            st_act, st_rd, st_wr, st_pre, st_refpb;
  logic                     st_refab;
  hbm_row_t                 st_row;

  logic                     issue_valid;
  hbm_cmd_t                 issue_cmd;
  logic                     issue_col, issue_err;
  logic [IW-1:0]            issue_idx;

  wire [HBM_BANK_W-1:0] ibank = {issue_cmd.bg, issue_cmd.ba};
  always_comb begin
    st_row   = issue_cmd.row;
    st_refab = issue_valid && (issue_cmd.cmd == HCMD_REF_AB);
    for (int b = 0; b < NB; b++) begin
      logic m;
      m = (ibank == HBM_BANK_W'(b));
      st_act[b]    = issue_valid && (issue_cmd.cmd == HCMD_ACT) && m;
      st_rd[b]     = issue_valid && (issue_cmd.cmd == HCMD_RD)  && m;
      st_wr[b]     = issue_valid && (issue_cmd.cmd == HCMD_WR)  && m;
      st_pre[b]    = issue_valid && (((issue_cmd.cmd == HCMD_PRE) && m) || (issue_cmd.cmd == HCMD_PREA));
      st_refpb[b]  = issue_valid && (issue_cmd.cmd == HCMD_REF_PB) && m;
    end
  end

  for (genvar b = 0; b < NB; b++) begin : g_bank
    sf_hbm_bank_fsm u_bank (
      .clk_i, .rst_ni, .tp_i,
      .act_i(st_act[b]), .rd_i(st_rd[b]), .wr_i(st_wr[b]), .cmd_row_i(st_row),
      .pre_i(st_pre[b]), .refab_i(st_refab), .refpb_i(st_refpb[b]),
      .row_open_o(bk_row_open[b]), .open_row_o(bk_open_row[b]),
      .can_act_o(bk_can_act[b]), .can_rd_o(bk_can_rd[b]), .can_wr_o(bk_can_wr[b]), .can_pre_o(bk_can_pre[b]),
      .idle_o(bk_idle[b]), .state_o(bk_state[b]), .violation_o(bk_viol[b])
    );
  end
  assign bank_state_o = bk_state;

  // --------------------------------------------------------------------------
  // cross-bank timing
  // --------------------------------------------------------------------------
  logic [HBM_NUM_BG-1:0] tm_ok_act, tm_ok_rd, tm_ok_wr;
  logic tm_ok_ref, tm_ok_misc, tm_busy, tm_viol;
  sf_hbm_timing u_timing (
    .clk_i, .rst_ni, .tp_i,
    .act_i(issue_valid && issue_cmd.cmd == HCMD_ACT),
    .rd_i (issue_valid && issue_cmd.cmd == HCMD_RD),
    .wr_i (issue_valid && issue_cmd.cmd == HCMD_WR),
    .bg_i (issue_cmd.bg),
    .refab_i(st_refab),
    .mrs_i(issue_valid && issue_cmd.cmd == HCMD_MRS),
    .pdx_i(issue_valid && issue_cmd.cmd == HCMD_PDX),
    .srx_i(issue_valid && issue_cmd.cmd == HCMD_SRX),
    .ok_act_o(tm_ok_act), .ok_rd_o(tm_ok_rd), .ok_wr_o(tm_ok_wr),
    .ok_ref_o(tm_ok_ref), .ok_misc_o(tm_ok_misc), .busy_o(tm_busy), .violation_o(tm_viol)
  );

  // --------------------------------------------------------------------------
  // completion sequencer / read return
  // --------------------------------------------------------------------------
  logic                cpl_credit;
  logic [CIW-1:0]      cpl_push_idx;
  logic [CIW:0]        cpl_occ;
  logic                wd_done_valid;
  logic [CIW-1:0]      wd_done_idx;
  logic                rr_rd_valid;
  hbm_data_t           rr_rd_data;
  hbm_err_e            rr_rd_err;
  logic                rr_rd_corr;
  logic                rr_timing_err, rr_timeout, rr_unexpected;
  logic [15:0]         rr_lat;

  hbm_ctx_t            push_ctx;
  always_comb begin
    push_ctx       = '0;
    push_ctx.src   = ent_txn[issue_idx].src;
    push_ctx.id    = ent_txn[issue_idx].id;
    push_ctx.write = ent_txn[issue_idx].write;
    push_ctx.err   = ent_txn[issue_idx].err;
    push_ctx.qos   = ent_txn[issue_idx].qos;
    push_ctx.bytes = bytes_q[issue_idx];
    push_ctx.lat0  = 16'(ent_age[issue_idx]);
  end
  wire        cpl_push = issue_col || issue_err;
  wire [1:0]  cpl_kind = issue_err ? 2'd2 : (ent_txn[issue_idx].write ? 2'd1 : 2'd0);

  sf_hbm_read_return #(.CPL_DEPTH(CPL_DEPTH), .RD_EXTRA_LAT(RD_EXTRA)) u_rr (
    .clk_i, .rst_ni, .tp_i, .cyc_i(cyc_q),
    .push_valid_i(cpl_push), .push_ctx_i(push_ctx), .push_kind_i(cpl_kind),
    .push_idx_o(cpl_push_idx), .credit_o(cpl_credit),
    .wr_done_valid_i(wd_done_valid), .wr_done_idx_i(wd_done_idx),
    .rd_valid_i(rr_rd_valid), .rd_data_i(rr_rd_data), .rd_err_i(rr_rd_err), .rd_corr_i(rr_rd_corr),
    .rsp_valid_o, .rsp_ready_i, .rsp_o, .rsp_bytes_o, .rsp_lat_o(rr_lat),
    .occ_o(cpl_occ),
    .rd_timing_err_o(rr_timing_err), .rd_timeout_o(rr_timeout), .rd_unexpected_o(rr_unexpected)
  );
  assign lat_o = rr_lat;

  // --------------------------------------------------------------------------
  // write data
  // --------------------------------------------------------------------------
  logic        wd_can_issue, wd_pend_empty;
  logic        wd_valid;
  hbm_data_t   wd_data;
  hbm_mask_t   wd_mask;
  wire         wr_issue = issue_col && (issue_cmd.cmd == HCMD_WR);

  sf_hbm_write_data #(.DEPTH(DEPTH), .PEND_DEPTH(PEND_DEPTH), .CPL_IDX_W(CIW), .WR_ACK_AT_DATA(WR_ACK_AT_DATA)) u_wd (
    .clk_i, .rst_ni, .tp_i, .cyc_i(cyc_q),
    .st_valid_i(accept && req_txn_i.write && (req_txn_i.err == HERR_NONE)),
    .st_idx_i(push_idx), .st_data_i(req_wdata_i), .st_mask_i(req_wmask_i),
    .wr_issue_i(wr_issue), .wr_idx_i(issue_idx), .wr_cpl_idx_i(cpl_push_idx), .can_issue_o(wd_can_issue),
    .wdata_valid_o(wd_valid), .wdata_o(wd_data), .wmask_o(wd_mask),
    .wr_done_valid_o(wd_done_valid), .wr_done_idx_o(wd_done_idx),
    .pend_empty_o(wd_pend_empty), .slot_busy_o(wd_slot_busy)
  );

  // --------------------------------------------------------------------------
  // refresh / power / init -> maintenance port
  // --------------------------------------------------------------------------
  logic rf_mnt_valid, rf_mnt_prio, rf_hold_act, rf_hold_col, rf_hold_bank_valid, rf_hold_bank_col;
  hbm_cmd_t rf_mnt_cmd;
  logic [HBM_BANK_W-1:0] rf_hold_bank;
  logic rf_urgent, rf_active, rf_ev, rf_forced, rf_pullin, rf_miss;
  logic pw_mnt_valid, pw_hold, pw_pause_ref, pw_ref_clear;
  hbm_cmd_t pw_mnt_cmd;
  logic mnt_grant, rf_grant, pw_grant, init_grant;

  wire all_idle = &bk_idle;
  wire quiet = q_empty && (cpl_occ == '0) && wd_pend_empty && !rf_active;
  assign quiet_o = quiet;

  sf_hbm_refresh u_ref (
    .clk_i, .rst_ni, .tp_i, .cfg_i(ref_cfg_i),
    .enable_i(ctrl_enable_i), .pause_i(pw_pause_ref), .block_i((pwr_state_o != 3'd0) && (pwr_state_o != 3'd1)), .clear_i(pw_ref_clear), .queue_idle_i(q_empty),
    .bk_idle_i(bk_idle), .bk_row_open_i(bk_row_open),
    .mnt_valid_o(rf_mnt_valid), .mnt_cmd_o(rf_mnt_cmd), .mnt_prio_o(rf_mnt_prio), .mnt_grant_i(rf_grant),
    .hold_act_o(rf_hold_act), .hold_col_o(rf_hold_col),
    .hold_bank_valid_o(rf_hold_bank_valid), .hold_bank_o(rf_hold_bank), .hold_bank_col_o(rf_hold_bank_col),
    .debt_o(ref_debt_o), .urgent_o(rf_urgent), .active_o(rf_active),
    .ev_ref_o(rf_ev), .ev_forced_o(rf_forced), .ev_pullin_o(rf_pullin), .deadline_miss_o(rf_miss)
  );

  sf_hbm_power_state u_pwr (
    .clk_i, .rst_ni, .tp_i, .enable_i(ctrl_enable_i),
    .req_i(pwr_req_i), .pd_idle_i, .sr_idle_i,
    .quiet_i(quiet), .work_pending_i(req_valid_i || !q_empty), .all_idle_i(all_idle), .ref_urgent_i(rf_urgent),
    .mnt_valid_o(pw_mnt_valid), .mnt_cmd_o(pw_mnt_cmd), .mnt_grant_i(pw_grant),
    .hold_o(pw_hold), .pause_ref_o(pw_pause_ref), .ref_clear_o(pw_ref_clear),
    .state_o(pwr_state_o), .res_active_o, .res_pd_o, .res_sr_o
  );

  // init MRS: taken once per (valid, code); ack drops as soon as the code changes
  logic        init_ack_q;
  logic [7:0]  init_ack_code_q;
  assign init_mrs_ack_o = init_ack_q && (init_ack_code_q == init_mrs_code_i) && init_mrs_valid_i;
  wire   init_sel   = init_mrs_valid_i && !init_mrs_ack_o;
  hbm_cmd_t init_cmd;
  always_comb begin init_cmd = '0; init_cmd.cmd = HCMD_MRS; init_cmd.mrs = init_mrs_code_i; end

  wire mnt_valid = init_sel || pw_mnt_valid || rf_mnt_valid;
  hbm_cmd_t mnt_cmd;
  logic     mnt_prio;
  always_comb begin
    if (init_sel)           begin mnt_cmd = init_cmd;   mnt_prio = 1'b1; end
    else if (pw_mnt_valid)  begin mnt_cmd = pw_mnt_cmd; mnt_prio = 1'b1; end
    else                    begin mnt_cmd = rf_mnt_cmd; mnt_prio = rf_mnt_prio; end
  end
  assign init_grant = mnt_grant && init_sel;
  assign pw_grant   = mnt_grant && !init_sel && pw_mnt_valid;
  assign rf_grant   = mnt_grant && !init_sel && !pw_mnt_valid && rf_mnt_valid;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin init_ack_q <= 1'b0; init_ack_code_q <= '0; end
    else begin
      if (init_grant) begin init_ack_q <= 1'b1; init_ack_code_q <= init_mrs_code_i; end
      if (!init_mrs_valid_i) init_ack_q <= 1'b0;
    end
  end

  // --------------------------------------------------------------------------
  // scheduler
  // --------------------------------------------------------------------------
  logic phy_cmd_ready;
  logic s_hit, s_empty, s_conf, s_act, s_pre, s_tstall, s_rstall, s_byp, s_qstall, s_pstall, s_pend;

  wire hold_act = rf_hold_act || pw_hold || !ctrl_enable_i;
  wire hold_col = rf_hold_col || pw_hold || !ctrl_enable_i;

  sf_hbm_scheduler #(.DEPTH(DEPTH), .AGE_W(AGE_W)) u_sched (
    .clk_i, .rst_ni, .cfg_i(sched_cfg_i),
    .ent_valid_i(ent_valid), .ent_txn_i(ent_txn), .ent_blocked_i(ent_blocked),
    .ent_older_i(ent_older), .ent_age_i(ent_age),
    .bk_row_open_i(bk_row_open), .bk_can_act_i(bk_can_act), .bk_can_rd_i(bk_can_rd), .bk_can_wr_i(bk_can_wr),
    .bk_can_pre_i(bk_can_pre), .bk_idle_i(bk_idle), .bk_open_row_i(bk_open_row),
    .tm_ok_act_i(tm_ok_act), .tm_ok_rd_i(tm_ok_rd), .tm_ok_wr_i(tm_ok_wr),
    .tm_ok_ref_i(tm_ok_ref), .tm_ok_misc_i(tm_ok_misc),
    .cpl_credit_i(cpl_credit), .wr_credit_i(wd_can_issue), .phy_ready_i(phy_cmd_ready),
    .mnt_valid_i(mnt_valid), .mnt_cmd_i(mnt_cmd), .mnt_prio_i(mnt_prio), .mnt_grant_o(mnt_grant),
    .hold_act_i(hold_act), .hold_col_i(hold_col),
    .hold_bank_valid_i(rf_hold_bank_valid), .hold_bank_i(rf_hold_bank), .hold_bank_col_i(rf_hold_bank_col),
    .issue_valid_o(issue_valid), .issue_cmd_o(issue_cmd), .issue_col_o(issue_col),
    .issue_err_o(issue_err), .issue_idx_o(issue_idx),
    .ev_row_hit_o(s_hit), .ev_row_empty_o(s_empty), .ev_row_conflict_o(s_conf),
    .ev_act_o(s_act), .ev_pre_o(s_pre), .ev_timing_stall_o(s_tstall), .ev_ref_stall_o(s_rstall),
    .ev_bypass_o(s_byp), .ev_qos_stall_o(s_qstall), .ev_phy_stall_o(s_pstall), .ev_demand_pending_o(s_pend)
  );
  assign rem_valid = issue_col || issue_err;
  assign rem_idx   = issue_idx;
  assign dbg_cmd_valid_o = issue_valid;
  assign dbg_cmd_o       = issue_cmd;

  // --------------------------------------------------------------------------
  // command encoder -> PHY adapter
  // --------------------------------------------------------------------------
  logic     enc_valid;
  hbm_cmd_t enc_cmd;
  sf_hbm_command_encoder #(.ENCODING(0)) u_enc (
    .clk_i, .rst_ni, .cmd_valid_i(issue_valid), .cmd_i(issue_cmd), .phy_cmd_valid_o(enc_valid), .phy_cmd_o(enc_cmd)
  );

  hbm_data_t ecc_wdata;
  hbm_ecc_t  ecc_wecc;
  logic      pa_rvalid, pa_rerr;
  hbm_data_t pa_rdata;
  hbm_ecc_t  pa_recc;

  sf_hbm_phy_adapter #(.BACKEND(PHY_BACKEND), .CMD_LAT(PHY_CMD_LAT), .RD_LAT(PHY_RD_LAT)) u_phy (
    .clk_i, .rst_ni,
    .cmd_valid_i(enc_valid), .cmd_i(enc_cmd),
    .wdata_valid_i(wd_valid), .wdata_i(ecc_wdata), .wmask_i(wd_mask), .wecc_i(ecc_wecc),
    .rdata_valid_o(pa_rvalid), .rdata_o(pa_rdata), .recc_o(pa_recc), .rerr_o(pa_rerr),
    .cmd_ready_o(phy_cmd_ready), .backend_unimplemented_o, .phy_ready_ext_i,
    .sim_cmd_valid_o, .sim_cmd_o, .sim_wvalid_o, .sim_wdata_o, .sim_wmask_o, .sim_wecc_o,
    .sim_rvalid_i, .sim_rdata_i, .sim_recc_i, .sim_rerr_i
  );

  // --------------------------------------------------------------------------
  // ECC / RAS (controller SECDED on the PHY data path)
  // --------------------------------------------------------------------------
  logic ecc_ev_ce, ecc_ev_ue;
  hbm_data_t ecc_rdata;
  hbm_err_e  ecc_rerr;
  logic      ecc_rcorr;
  sf_hbm_ecc_ras u_ecc (
    .clk_i, .rst_ni, .ecc_en_i, .clear_i(ecc_clear_i),
    .inj_arm_i, .inj_mode_i, .inj_bit_i,
    .wr_fire_i(wd_valid), .wdata_i(wd_data), .wdata_o(ecc_wdata), .wecc_o(ecc_wecc),
    .rd_fire_i(pa_rvalid), .rdata_i(pa_rdata), .recc_i(pa_recc),
    .rdata_o(ecc_rdata), .rerr_o(ecc_rerr), .rcorr_o(ecc_rcorr),
    .phy_event_i(phy_event_i || (pa_rvalid && pa_rerr)), .ondie_event_i,
    .ce_cnt_o(ecc_ce_o), .ue_cnt_o(ecc_ue_o), .phy_cnt_o(phy_err_o), .ondie_cnt_o(ondie_err_o),
    .log_valid_o(ecc_log_valid_o), .log_ue_o(ecc_log_ue_o), .log_syndrome_o(ecc_log_syn_o),
    .alert_o(ecc_alert_o), .ev_ce_o(ecc_ev_ce), .ev_ue_o(ecc_ev_ue)
  );
  assign rr_rd_valid = pa_rvalid;
  assign rr_rd_data  = ecc_rdata;
  assign rr_rd_err   = ecc_rerr;
  assign rr_rd_corr  = ecc_rcorr;

  // --------------------------------------------------------------------------
  // event pulses
  // --------------------------------------------------------------------------
  wire rsp_fire = rsp_valid_o && rsp_ready_i;
  always_comb begin
    evt_o = '0;
    evt_o.acc_rd        = accept && !req_txn_i.write;
    evt_o.acc_wr        = accept &&  req_txn_i.write;
    evt_o.cmp_rd        = rsp_fire && !rsp_o.write;
    evt_o.cmp_wr        = rsp_fire &&  rsp_o.write;
    evt_o.row_hit       = s_hit;
    evt_o.row_empty     = s_empty;
    evt_o.row_conflict  = s_conf;
    evt_o.act           = issue_valid && (issue_cmd.cmd == HCMD_ACT);
    evt_o.pre           = issue_valid && ((issue_cmd.cmd == HCMD_PRE) || (issue_cmd.cmd == HCMD_PREA));
    evt_o.refresh       = issue_valid && ((issue_cmd.cmd == HCMD_REF_AB) || (issue_cmd.cmd == HCMD_REF_PB));
    evt_o.ref_forced    = rf_ev && rf_forced;
    evt_o.ref_pullin    = rf_ev && rf_pullin;
    evt_o.ref_stall     = s_rstall;
    evt_o.timing_stall  = s_tstall;
    evt_o.qos_stall     = s_qstall;
    evt_o.bypass        = s_byp;
    evt_o.phy_stall     = s_pstall;
    evt_o.ecc_ce        = ecc_ev_ce;
    evt_o.ecc_ue        = ecc_ev_ue;
    evt_o.rd_timing_err = rr_timing_err;
    evt_o.rd_timeout    = rr_timeout;
    evt_o.rd_unexpected = rr_unexpected;
    evt_o.violation     = (|bk_viol) || tm_viol;
    evt_o.deadline_miss = rf_miss;
    evt_o.busy          = !q_empty || (cpl_occ != '0) || !wd_pend_empty;
    evt_o.in_pd         = (pwr_state_o == 3'd3);
    evt_o.in_sr         = (pwr_state_o == 3'd4);
  end

`ifndef SYNTHESIS
  // protocol-level assertions that must hold in every simulation
  always_ff @(posedge clk_i) if (rst_ni) begin
    if (evt_o.violation)      $error("[%m] DRAM timing/bank-state violation detected by the controller's own checkers");
    if (rr_unexpected)        $error("[%m] unexpected read data (no outstanding read)");
    if (rr_timeout)           $error("[%m] read data never returned (timeout)");
    if (rr_timing_err)        $error("[%m] read data returned at the wrong cycle");
    if (rf_miss)              $error("[%m] refresh deadline missed (debt above max_postpone)");
    if (issue_valid && issue_err)  $error("[%m] error completion and PHY command issued together");
  end
`endif
endmodule : sf_hbm_pseudochannel
