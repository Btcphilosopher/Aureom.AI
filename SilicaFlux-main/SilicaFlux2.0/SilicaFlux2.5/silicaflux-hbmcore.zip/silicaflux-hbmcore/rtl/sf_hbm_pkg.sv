// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_pkg.sv
//  Shared types, abstract command interface, error codes and pure functions.
//
//  STANDARDS STATUS (see docs/STANDARDS_MATRIX.md)
//    * 32 DQ per pseudo-channel, 2 pseudo-channels per channel,
//      32 channels / 2048 DQ per stack ........................ PUBLIC_REFERENCE
//    * burst of 8 beats => 32 B access granule ................. ENGINEERING_ASSUMPTION
//    * bank-group / bank / row / column counts ................. ENGINEERING_ASSUMPTION
//    * hbm_cmd_e is an ABSTRACT controller command set. It is NOT the JESD270-4
//      command table and carries NO pin-level encoding. Physical command encoding
//      is "pending specification integration" (see sf_hbm_command_encoder.sv).
//    * timing values come only from generated profile packages; every shipped
//      profile is HYPOTHETICAL_SIM (configs/timing/profiles.json).
//
//  Synthesizable: yes (types, enums and pure functions only).
// =============================================================================
`include "sf_hbm_geom.svh"

package sf_hbm_pkg;

  // ---------------------------------------------------------------------------
  // Contract version (bump on any width / meaning change of a type below)
  // ---------------------------------------------------------------------------
  localparam int unsigned HBM_TXN_VERSION = 1;

  // ---------------------------------------------------------------------------
  // Geometry (reference simulation geometry; override via sf_hbm_geom.svh)
  // ---------------------------------------------------------------------------
  localparam int unsigned HBM_DQ_PER_PC   = 32;                       // PUBLIC_REFERENCE
  localparam int unsigned HBM_BEATS       = 8;                        // ENGINEERING_ASSUMPTION
  localparam int unsigned HBM_GRAN_BITS   = HBM_DQ_PER_PC * HBM_BEATS; // 256
  localparam int unsigned HBM_GRAN_BYTES  = HBM_GRAN_BITS / 8;        // 32
  localparam int unsigned HBM_OFF_W       = 5;                        // log2(32)

  localparam int unsigned HBM_BG_W        = `HBM_BG_BITS;
  localparam int unsigned HBM_BA_W        = `HBM_BA_BITS;
  localparam int unsigned HBM_ROW_W       = `HBM_ROW_BITS;
  localparam int unsigned HBM_COL_W       = `HBM_COL_BITS;
  localparam int unsigned HBM_NUM_BG      = 1 << HBM_BG_W;
  localparam int unsigned HBM_NUM_BANKS   = 1 << (HBM_BG_W + HBM_BA_W);
  localparam int unsigned HBM_BANK_W      = HBM_BG_W + HBM_BA_W;

  localparam int unsigned HBM_ID_W        = `HBM_ID_BITS;
  localparam int unsigned HBM_SRC_W       = `HBM_SRC_BITS;
  localparam int unsigned HBM_QOS_W       = 2;
  localparam int unsigned HBM_ADDR_W      = `HBM_ADDR_BITS;
  localparam int unsigned HBM_MASK_W      = HBM_GRAN_BYTES;           // byte enables per granule

  // controller-level SECDED over one granule: (256 data + 9 Hamming + 1 overall)
  localparam int unsigned HBM_ECC_W       = 10;

  localparam int unsigned HBM_CYC_W       = 16;   // wrapping cycle counter width used for due-time checks

  // ---------------------------------------------------------------------------
  // Basic typedefs
  // ---------------------------------------------------------------------------
  typedef logic [HBM_GRAN_BITS-1:0] hbm_data_t;
  typedef logic [HBM_MASK_W-1:0]    hbm_mask_t;
  typedef logic [HBM_ID_W-1:0]      hbm_id_t;
  typedef logic [HBM_SRC_W-1:0]     hbm_src_t;
  typedef logic [HBM_QOS_W-1:0]     hbm_qos_t;
  typedef logic [HBM_ADDR_W-1:0]    hbm_addr_t;
  typedef logic [HBM_ECC_W-1:0]     hbm_ecc_t;
  typedef logic [HBM_ROW_W-1:0]     hbm_row_t;
  typedef logic [HBM_COL_W-1:0]     hbm_col_t;
  typedef logic [HBM_BG_W-1:0]      hbm_bg_t;
  typedef logic [HBM_BA_W-1:0]      hbm_ba_t;
  typedef logic [HBM_CYC_W-1:0]     hbm_cyc_t;

  // ---------------------------------------------------------------------------
  // Error / status codes. Numerically identical to silicaflux_pkg::sf_mem_exc_e
  // so a response status can be copied to a NoC packet unchanged.
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    HERR_NONE      = 3'd0,   // completed normally
    HERR_MISALIGN  = 3'd1,   // address not aligned to the 32 B access granule
    HERR_RANGE     = 3'd2,   // address outside the configured capacity
    HERR_POLICY    = 3'd3,   // request violates a configured policy (e.g. partial write with ECC on)
    HERR_BURST_BND = 3'd4,   // multi-granule request crosses the capacity aperture
    HERR_BURST_LEN = 3'd5,   // multi-granule request longer than the configured maximum
    HERR_ECC       = 3'd6,   // uncorrectable data error (poisoned data)
    HERR_FLUSHED   = 3'd7    // aborted (reset / flush / read-return timeout)
  } hbm_err_e;

  // ---------------------------------------------------------------------------
  // Ordering attribute carried by every transaction (docs/ORDERING.md)
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    ORD_RELAXED = 2'd0,   // ordered only by hazards (same granule, a write involved) and same {src,id}
    ORD_SRC     = 2'd1,   // additionally ordered against every older request of the same source
    ORD_STRICT  = 2'd2,   // barrier within its pseudo-channel queue (older issue first, younger issue after)
    ORD_RSVD    = 2'd3
  } hbm_order_e;

  // ---------------------------------------------------------------------------
  // ABSTRACT controller command set (NOT a JEDEC command table)
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    HCMD_NOP    = 4'd0,
    HCMD_ACT    = 4'd1,    // open a row
    HCMD_RD     = 4'd2,    // column read
    HCMD_WR     = 4'd3,    // column write
    HCMD_PRE    = 4'd4,    // close one bank
    HCMD_PREA   = 4'd5,    // close all banks of the pseudo-channel
    HCMD_REF_AB = 4'd6,    // all-bank refresh   (mode availability: UNVERIFIED for HBM4)
    HCMD_REF_PB = 4'd7,    // per-bank refresh   (mode availability: UNVERIFIED for HBM4)
    HCMD_MRS    = 4'd8,    // mode-register / maintenance write (abstract)
    HCMD_PDE    = 4'd9,    // power-down entry   (abstract)
    HCMD_PDX    = 4'd10,   // power-down exit
    HCMD_SRE    = 4'd11,   // self-refresh entry
    HCMD_SRX    = 4'd12,   // self-refresh exit
    HCMD_RFM    = 4'd13,   // refresh-management maintenance (abstract; DRFM research hook)
    HCMD_RSVD14 = 4'd14,
    HCMD_RSVD15 = 4'd15
  } hbm_cmd_e;

  typedef struct packed {
    hbm_cmd_e   cmd;
    hbm_bg_t    bg;
    hbm_ba_t    ba;
    hbm_row_t   row;
    hbm_col_t   col;
    logic [7:0] mrs;      // abstract mode-register operand
  } hbm_cmd_t;

  localparam int unsigned HBM_CMD_W = $bits(hbm_cmd_t);

  // ---------------------------------------------------------------------------
  // Per-pseudo-channel transaction (one 32 B granule, after address mapping)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    hbm_src_t   src;
    hbm_id_t    id;
    hbm_qos_t   qos;
    hbm_order_e order;
    logic       write;
    hbm_err_e   err;      // != NONE: "error entry" - completes with this status, issues no DRAM command
    hbm_bg_t    bg;
    hbm_ba_t    ba;
    hbm_row_t   row;
    hbm_col_t   col;
  } hbm_txn_t;

  localparam int unsigned HBM_TXN_W = $bits(hbm_txn_t);

  // response context travelling through the completion sequencer
  typedef struct packed {
    hbm_src_t   src;
    hbm_id_t    id;
    logic       write;
    hbm_err_e   err;
    hbm_qos_t   qos;
    logic [5:0] bytes;      // payload bytes this transaction moves (32 for a read, popcount(mask) for a write)
    logic [15:0] lat0;      // cycles spent in the request queue before the command issued
  } hbm_ctx_t;

  // per-pseudo-channel event pulses consumed by sf_hbm_perf (one cycle wide)
  typedef struct packed {
    logic acc_rd, acc_wr;            // request accepted
    logic cmp_rd, cmp_wr;            // response accepted by the consumer (error-free or not)
    logic row_hit, row_empty, row_conflict;
    logic act, pre, refresh;
    logic ref_forced, ref_pullin;
    logic ref_stall, timing_stall, qos_stall, bypass, phy_stall;
    logic ecc_ce, ecc_ue;
    logic rd_timing_err, rd_timeout, rd_unexpected;
    logic violation;                 // a timing/bank-state violation was detected (must stay 0)
    logic deadline_miss;             // refresh debt exceeded the profile's postpone limit (must stay 0)
    logic busy;                      // pseudo-channel has outstanding work this cycle
    logic in_pd, in_sr;              // cycle spent in power-down / self-refresh (residency)
  } hbm_pc_evt_t;

  // observability bundle of one pseudo-channel (events + sampled status)
  typedef struct packed {
    hbm_pc_evt_t evt;
    logic [15:0] lat;                // latency of the response accepted this cycle (valid with evt.cmp_*)
    logic [5:0]  bytes;              // payload bytes of that response
    logic [5:0]  occ;                // request-queue occupancy
    logic [2:0]  pwr_state;
    logic signed [7:0] debt;         // refresh debt (intervals owed)
    logic        quiet;
    logic        unimpl;             // PHY backend unimplemented
    logic        ecc_alert, ecc_lv, ecc_lue;
    logic [8:0]  ecc_lsyn;
    logic [HBM_NUM_BANKS-1:0][1:0] bank_state;
  } hbm_pc_stat_t;

  // response as seen by the requester
  typedef struct packed {
    hbm_src_t   src;
    hbm_id_t    id;
    logic       write;
    hbm_err_e   err;
    logic       corrected;  // ECC corrected a single-bit error in this granule (data is good)
    hbm_data_t  data;
  } hbm_rsp_t;

  // ---------------------------------------------------------------------------
  // Scheduler configuration (runtime, from CSR)
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    SCHED_FCFS      = 3'd0,   // strict oldest-first
    SCHED_FRFCFS    = 3'd1,   // first-ready (column hits first), then oldest
    SCHED_BGAWARE   = 3'd2,   // FR-FCFS + prefer a different bank group than the previous column command
    SCHED_RSVD3     = 3'd3
  } hbm_sched_policy_e;

  typedef enum logic [1:0] {
    PAGE_OPEN    = 2'd0,      // leave rows open until a conflict or refresh
    PAGE_CLOSE   = 2'd1,      // precharge as soon as no pending request wants the open row
    PAGE_TIMEOUT = 2'd2       // precharge after `close_timeout` idle cycles
  } hbm_page_policy_e;

  typedef struct packed {
    hbm_sched_policy_e policy;
    logic              prio_en;        // QoS class priority
    logic              batch_en;       // read/write batching
    logic [7:0]        batch_len;      // max consecutive column commands in one direction when the other waits
    logic [15:0]       starve_limit;   // 0 = off; entries older than this get top priority (anti-starvation)
    logic              deadline_en;    // deadline-aware QoS for class QOS_RT
    logic [15:0]       deadline_thr;   // age at which a QOS_RT entry becomes urgent
    hbm_page_policy_e  page;
    logic [15:0]       close_timeout;
  } hbm_sched_cfg_t;

  localparam hbm_qos_t QOS_BE = 2'd0, QOS_LOW = 2'd1, QOS_HIGH = 2'd2, QOS_RT = 2'd3;

  // ---------------------------------------------------------------------------
  // Refresh configuration
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    REFMODE_AB   = 2'd0,      // all-bank refresh
    REFMODE_PB   = 2'd1,      // per-bank refresh (one bank at a time)
    REFMODE_OFF  = 2'd2       // refresh disabled (only legal while the DRAM model is told to ignore it)
  } hbm_ref_mode_e;

  typedef struct packed {
    hbm_ref_mode_e mode;
    logic          eager;      // 1: start as soon as debt > 0 ; 0: postpone while the queue is busy
    logic          pullin_en;  // pull refreshes in while the queue is idle
  } hbm_ref_cfg_t;

  // ---------------------------------------------------------------------------
  // Timing profile (all fields in controller clock cycles; see profiles.json)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [15:0] trcdrd, trcdwr, trp, tras, trc;
    logic [15:0] tccd_s, tccd_l, trrd_s, trrd_l, tfaw;
    logic [15:0] twr, twtr_s, twtr_l, trtp;
    logic [15:0] trfc, trfcpb, trefi;
    logic [15:0] rl, wl, burst;
    logic [15:0] tmrd, txp, txs;
    logic [15:0] max_postpone, max_pullin;
  } hbm_timing_t;

  // ---------------------------------------------------------------------------
  // Address-map controls
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    MAP_LINEAR     = 2'd0,    // page-contiguous per pseudo-channel; channel bits at the top
    MAP_CH_IL      = 2'd1,    // pseudo-channel / channel interleave at 2^il granules
    MAP_BANK_AWARE = 2'd2,    // channel interleave, then bank-group/bank rotate before the column MSBs
    MAP_RSVD       = 2'd3
  } hbm_map_e;

  typedef struct packed {
    logic [2:0]  stk;
    logic [5:0]  ch;
    logic [1:0]  pc;
    hbm_bg_t     bg;
    hbm_ba_t     ba;
    hbm_row_t    row;
    hbm_col_t    col;
  } hbm_loc_t;

  // ---------------------------------------------------------------------------
  // Controller-wide runtime configuration (driven by sf_hbm_csr, consumed by sf_hbm4_controller)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic             enable;          // start the init sequence / allow traffic
    hbm_map_e         map_mode;
    logic [2:0]       il_bits;
    logic             map_hash;
    logic [3:0]       profile_sel;
    hbm_sched_cfg_t   sched;
    hbm_ref_cfg_t     ref_cfg;
    logic             ecc_en;
    logic [1:0]       pwr_req;
    logic [15:0]      pd_idle;
    logic [15:0]      sr_idle;
    logic [31:0]      init_timeout;
    logic [HBM_ID_W-1:0] max_burst_m1; // host-side burst limit (granules - 1), used by the transaction splitter
  } hbm_cfg_t;

  // ---------------------------------------------------------------------------
  // Pure helper functions
  // ---------------------------------------------------------------------------
  // Counter load value: a rule "next command allowed N cycles after this one" loads N-1,
  // because the counter is visible one cycle after the issuing edge and `== 0` means "allowed".
  function automatic logic [15:0] hbm_ld(input logic [15:0] n);
    return (n == 16'd0) ? 16'd0 : (n - 16'd1);
  endfunction

  function automatic logic [15:0] hbm_max16(input logic [15:0] a, input logic [15:0] b);
    return (a > b) ? a : b;
  endfunction

  function automatic logic [15:0] hbm_dec16(input logic [15:0] a);
    return (a == 16'd0) ? 16'd0 : (a - 16'd1);
  endfunction

  // Do two transactions of one pseudo-channel queue have to stay in order?
  // (new = younger, old = older.) Used when a request is inserted (docs/ORDERING.md).
  function automatic logic hbm_conflict(input hbm_txn_t nw, input hbm_txn_t od);
    logic same_gran, hazard, same_id, ordr;
    same_gran = (nw.bg == od.bg) && (nw.ba == od.ba) && (nw.row == od.row) && (nw.col == od.col);
    hazard    = same_gran && (nw.write || od.write);                       // RAW / WAR / WAW
    same_id   = (nw.src == od.src) && (nw.id == od.id);                    // same-ID responses stay in order
    ordr      = (nw.order == ORD_STRICT) || (od.order == ORD_STRICT) ||
                ((nw.order == ORD_SRC) && (nw.src == od.src));
    return hazard || same_id || ordr;
  endfunction

  function automatic logic [HBM_ADDR_W-1:0] hbm_bits(input logic [HBM_ADDR_W-1:0] v,
                                                      input int unsigned lo, input int unsigned w);
    logic [HBM_ADDR_W-1:0] m;
    m = (w >= HBM_ADDR_W) ? '1 : ((HBM_ADDR_W'(1) << w) - HBM_ADDR_W'(1));
    return (v >> lo) & m;
  endfunction

  // total byte-address bits that name a location for the given channel/stack counts
  function automatic int unsigned hbm_cap_bits(input int unsigned ns_bits, input int unsigned ch_bits,
                                               input int unsigned pc_bits);
    return HBM_OFF_W + HBM_COL_W + HBM_BA_W + HBM_BG_W + HBM_ROW_W + pc_bits + ch_bits + ns_bits;
  endfunction

  // ---- forward map: byte address -> location --------------------------------
  function automatic hbm_loc_t hbm_map_addr(input logic [HBM_ADDR_W-1:0] addr,
                                            input hbm_map_e mode, input logic [2:0] il_bits,
                                            input logic hash,
                                            input int unsigned ns_bits, input int unsigned ch_bits,
                                            input int unsigned pc_bits);
    hbm_loc_t l;
    logic [HBM_ADDR_W-1:0] g;
    int unsigned p, il, c_lo, c_hi;
    hbm_col_t col_lo, col_hi;
    hbm_row_t rowv;
    l = '0;
    g = addr >> HBM_OFF_W;
    il = (32'(il_bits) > HBM_COL_W) ? HBM_COL_W : 32'(il_bits);
    c_lo = il;  c_hi = HBM_COL_W - il;
    p = 0;
    col_lo = '0; col_hi = '0;
    case (mode)
      MAP_LINEAR: begin
        l.col = hbm_col_t'(hbm_bits(g, p, HBM_COL_W));  p += HBM_COL_W;
        l.ba  = hbm_ba_t'(hbm_bits(g, p, HBM_BA_W));    p += HBM_BA_W;
        l.bg  = hbm_bg_t'(hbm_bits(g, p, HBM_BG_W));    p += HBM_BG_W;
        l.row = hbm_row_t'(hbm_bits(g, p, HBM_ROW_W));  p += HBM_ROW_W;
        l.pc  = 2'(hbm_bits(g, p, pc_bits));            p += pc_bits;
        l.ch  = 6'(hbm_bits(g, p, ch_bits));            p += ch_bits;
        l.stk = 3'(hbm_bits(g, p, ns_bits));          p += ns_bits;
      end
      MAP_CH_IL: begin
        col_lo = hbm_col_t'(hbm_bits(g, p, c_lo));      p += c_lo;
        l.pc  = 2'(hbm_bits(g, p, pc_bits));            p += pc_bits;
        l.ch  = 6'(hbm_bits(g, p, ch_bits));            p += ch_bits;
        l.stk = 3'(hbm_bits(g, p, ns_bits));          p += ns_bits;
        col_hi = hbm_col_t'(hbm_bits(g, p, c_hi));      p += c_hi;
        l.ba  = hbm_ba_t'(hbm_bits(g, p, HBM_BA_W));    p += HBM_BA_W;
        l.bg  = hbm_bg_t'(hbm_bits(g, p, HBM_BG_W));    p += HBM_BG_W;
        l.row = hbm_row_t'(hbm_bits(g, p, HBM_ROW_W));  p += HBM_ROW_W;
        l.col = col_lo | (col_hi << c_lo);
      end
      default: begin // MAP_BANK_AWARE
        col_lo = hbm_col_t'(hbm_bits(g, p, c_lo));      p += c_lo;
        l.pc  = 2'(hbm_bits(g, p, pc_bits));            p += pc_bits;
        l.ch  = 6'(hbm_bits(g, p, ch_bits));            p += ch_bits;
        l.stk = 3'(hbm_bits(g, p, ns_bits));          p += ns_bits;
        l.bg  = hbm_bg_t'(hbm_bits(g, p, HBM_BG_W));    p += HBM_BG_W;
        l.ba  = hbm_ba_t'(hbm_bits(g, p, HBM_BA_W));    p += HBM_BA_W;
        col_hi = hbm_col_t'(hbm_bits(g, p, c_hi));      p += c_hi;
        l.row = hbm_row_t'(hbm_bits(g, p, HBM_ROW_W));  p += HBM_ROW_W;
        l.col = col_lo | (col_hi << c_lo);
      end
    endcase
    if (hash) begin   // permutation hash: a bijection because `row` is never altered
      rowv = l.row;
      l.bg = l.bg ^ rowv[HBM_BG_W-1:0];
      l.ba = l.ba ^ rowv[HBM_BG_W +: HBM_BA_W];
      if (ch_bits > 0)
        l.ch = l.ch ^ 6'(hbm_bits(HBM_ADDR_W'(rowv), HBM_BANK_W, ch_bits));
    end
    return l;
  endfunction

  // ---- inverse map: location -> byte address (offset = 0) -------------------
  function automatic logic [HBM_ADDR_W-1:0] hbm_unmap_loc(input hbm_loc_t loc,
                                            input hbm_map_e mode, input logic [2:0] il_bits,
                                            input logic hash,
                                            input int unsigned ns_bits, input int unsigned ch_bits,
                                            input int unsigned pc_bits);
    hbm_loc_t l;
    logic [HBM_ADDR_W-1:0] g;
    int unsigned p, il, c_lo, c_hi;
    hbm_row_t rowv;
    hbm_col_t colv, col_lo_m, col_hi_v;
    l = loc;
    il = (32'(il_bits) > HBM_COL_W) ? HBM_COL_W : 32'(il_bits);
    c_lo = il;  c_hi = HBM_COL_W - il;
    if (hash) begin
      rowv = l.row;
      l.bg = l.bg ^ rowv[HBM_BG_W-1:0];
      l.ba = l.ba ^ rowv[HBM_BG_W +: HBM_BA_W];
      if (ch_bits > 0)
        l.ch = l.ch ^ 6'(hbm_bits(HBM_ADDR_W'(rowv), HBM_BANK_W, ch_bits));
    end
    g = '0;  p = 0;
    colv = l.col;
    col_lo_m = hbm_col_t'(hbm_bits(HBM_ADDR_W'(colv), 0, c_lo));
    col_hi_v = hbm_col_t'(HBM_ADDR_W'(colv) >> c_lo);
    case (mode)
      MAP_LINEAR: begin
        g |= HBM_ADDR_W'(l.col)   << p;  p += HBM_COL_W;
        g |= HBM_ADDR_W'(l.ba)    << p;  p += HBM_BA_W;
        g |= HBM_ADDR_W'(l.bg)    << p;  p += HBM_BG_W;
        g |= HBM_ADDR_W'(l.row)   << p;  p += HBM_ROW_W;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.pc), 0, pc_bits))    << p;  p += pc_bits;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.ch), 0, ch_bits))    << p;  p += ch_bits;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.stk), 0, ns_bits)) << p;  p += ns_bits;
      end
      MAP_CH_IL: begin
        g |= HBM_ADDR_W'(col_lo_m) << p;  p += c_lo;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.pc), 0, pc_bits))    << p;  p += pc_bits;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.ch), 0, ch_bits))    << p;  p += ch_bits;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.stk), 0, ns_bits)) << p;  p += ns_bits;
        g |= HBM_ADDR_W'(col_hi_v) << p;  p += c_hi;
        g |= HBM_ADDR_W'(l.ba)     << p;  p += HBM_BA_W;
        g |= HBM_ADDR_W'(l.bg)     << p;  p += HBM_BG_W;
        g |= HBM_ADDR_W'(l.row)    << p;  p += HBM_ROW_W;
      end
      default: begin
        g |= HBM_ADDR_W'(col_lo_m) << p;  p += c_lo;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.pc), 0, pc_bits))    << p;  p += pc_bits;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.ch), 0, ch_bits))    << p;  p += ch_bits;
        g |= HBM_ADDR_W'(hbm_bits(HBM_ADDR_W'(l.stk), 0, ns_bits)) << p;  p += ns_bits;
        g |= HBM_ADDR_W'(l.bg)     << p;  p += HBM_BG_W;
        g |= HBM_ADDR_W'(l.ba)     << p;  p += HBM_BA_W;
        g |= HBM_ADDR_W'(col_hi_v) << p;  p += c_hi;
        g |= HBM_ADDR_W'(l.row)    << p;  p += HBM_ROW_W;
      end
    endcase
    return g << HBM_OFF_W;
  endfunction

endpackage : sf_hbm_pkg
