// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_bank_fsm.sv
//  One DRAM bank as seen by the controller: row state + bank-local timing.
//
//  INTERFACE CONTRACT
//    * The parent decodes each issued command into per-bank strobes. At most one
//      command per pseudo-channel per cycle; a strobe is only raised for the bank
//      the command addresses (PRE/ACT/RD/WR), or for every bank (PREA, REF_AB).
//    * can_*_o are purely bank-local legality. Cross-bank rules (tRRD, tFAW, tCCD,
//      tWTR, turnaround, tRFC, tMRD ...) live in sf_hbm_timing.
//    * violation_o pulses for one cycle when a strobe is applied while the
//      bank-local rule forbids it. A correct scheduler never causes one; the pulse
//      exists so tests (and the DRAM-model cross-check) can prove that.
//
//  STATE (derived, no hidden state): row_open register + down-counters.
//      IDLE        : !row_open, tRP and tRFC elapsed          (precharged)
//      ACTIVE      :  row_open                                (open_row valid)
//      PRECHARGING : !row_open, tRP not yet elapsed
//      REFRESHING  : !row_open, tRFC(pb) not yet elapsed
//
//  RULES ENFORCED (names are profile fields):
//      ACT->RD tRCDRD  ACT->WR tRCDWR  ACT->PRE tRAS  ACT->ACT tRC  PRE->ACT tRP
//      RD->PRE tRTP    WR->PRE (WL+burst+tWR)    REF->ACT tRFC / tRFCpb
//
//  RESET: asynchronous assert, synchronous release semantics are the integrator's
//  responsibility; all counters clear and the bank is IDLE.
//  SYNTHESIS STATUS: see reports/synth/ (generic gate-level via Yosys).
//  KNOWN LIMITATIONS: auto-precharge (RDA/WRA) is not modelled; the scheduler uses
//  explicit PRE commands.
// =============================================================================
module sf_hbm_bank_fsm
  import sf_hbm_pkg::*;
(
  input  logic        clk_i,
  input  logic        rst_ni,
  input  hbm_timing_t tp_i,

  input  logic        act_i,
  input  logic        rd_i,
  input  logic        wr_i,
  input  hbm_row_t    cmd_row_i,      // row of ACT, or row targeted by RD/WR
  input  logic        pre_i,          // PRE for this bank, or PREA
  input  logic        refab_i,        // all-bank refresh starts
  input  logic        refpb_i,        // per-bank refresh of this bank starts

  output logic        row_open_o,
  output hbm_row_t    open_row_o,
  output logic        can_act_o,
  output logic        can_rd_o,
  output logic        can_wr_o,
  output logic        can_pre_o,
  output logic        idle_o,         // precharged and every bank-local timer elapsed
  output logic [1:0]  state_o,        // 0 IDLE, 1 ACTIVE, 2 PRECHARGING, 3 REFRESHING
  output logic        violation_o
);

  logic     row_open_q;
  hbm_row_t open_row_q;
  logic [15:0] c_rcdrd, c_rcdwr, c_ras, c_rc, c_rp, c_rtp, c_wr, c_rfc;

  // ---- legality (combinational on registered state) -------------------------
  assign idle_o     = !row_open_q && (c_rp == 16'd0) && (c_rfc == 16'd0);
  assign can_act_o  = idle_o && (c_rc == 16'd0);
  assign can_rd_o   = row_open_q && (c_rcdrd == 16'd0);
  assign can_wr_o   = row_open_q && (c_rcdwr == 16'd0);
  assign can_pre_o  = row_open_q && (c_ras == 16'd0) && (c_rtp == 16'd0) && (c_wr == 16'd0);

  assign row_open_o = row_open_q;
  assign open_row_o = open_row_q;

  always_comb begin
    if (row_open_q)                 state_o = 2'd1;
    else if (c_rfc != 16'd0)        state_o = 2'd3;
    else if (c_rp != 16'd0)         state_o = 2'd2;
    else                            state_o = 2'd0;
  end

  // ---- violation detection ---------------------------------------------------
  logic viol_c;
  always_comb begin
    viol_c = 1'b0;
    if (act_i && !can_act_o)                                   viol_c = 1'b1;
    if (rd_i  && !(can_rd_o && (cmd_row_i == open_row_q)))     viol_c = 1'b1;
    if (wr_i  && !(can_wr_o && (cmd_row_i == open_row_q)))     viol_c = 1'b1;
    // PRE to a bank that is open must satisfy tRAS/tRTP/tWR; PRE to a closed bank is a legal no-op.
    if (pre_i && row_open_q && !can_pre_o)                     viol_c = 1'b1;
    if ((refab_i || refpb_i) && !can_act_o)                    viol_c = 1'b1;
  end

  // ---- state / counters ------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      row_open_q <= 1'b0;
      open_row_q <= '0;
      c_rcdrd <= '0; c_rcdwr <= '0; c_ras <= '0; c_rc <= '0;
      c_rp <= '0; c_rtp <= '0; c_wr <= '0; c_rfc <= '0;
      violation_o <= 1'b0;
    end else begin
      violation_o <= viol_c;

      c_rcdrd <= hbm_dec16(c_rcdrd);
      c_rcdwr <= hbm_dec16(c_rcdwr);
      c_ras   <= hbm_dec16(c_ras);
      c_rc    <= hbm_dec16(c_rc);
      c_rp    <= hbm_dec16(c_rp);
      c_rtp   <= hbm_dec16(c_rtp);
      c_wr    <= hbm_dec16(c_wr);
      c_rfc   <= hbm_dec16(c_rfc);

      if (act_i) begin
        row_open_q <= 1'b1;
        open_row_q <= cmd_row_i;
        c_rcdrd    <= hbm_ld(tp_i.trcdrd);
        c_rcdwr    <= hbm_ld(tp_i.trcdwr);
        c_ras      <= hbm_ld(tp_i.tras);
        c_rc       <= hbm_ld(tp_i.trc);
        c_rtp      <= 16'd0;
        c_wr       <= 16'd0;
      end
      if (rd_i)
        c_rtp <= hbm_max16(hbm_dec16(c_rtp), hbm_ld(tp_i.trtp));
      if (wr_i)
        c_wr  <= hbm_max16(hbm_dec16(c_wr), hbm_ld(tp_i.wl + tp_i.burst + tp_i.twr));
      if (pre_i && row_open_q) begin
        row_open_q <= 1'b0;
        c_rp       <= hbm_ld(tp_i.trp);
      end
      if (refab_i) c_rfc <= hbm_ld(tp_i.trfc);
      if (refpb_i) c_rfc <= hbm_ld(tp_i.trfcpb);
    end
  end

`ifndef SYNTHESIS
  // simulation-only invariant checks
  always_ff @(posedge clk_i) if (rst_ni) begin
    if (row_open_q && (c_rp != 16'd0))
      $error("[%m] bank both open and precharging");
    if (act_i && pre_i)
      $error("[%m] ACT and PRE strobes in the same cycle");
  end
`endif
endmodule : sf_hbm_bank_fsm
