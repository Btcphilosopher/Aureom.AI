// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_perf.sv
//  Performance counters: per-pseudo-channel and aggregate.
//
//  PER-PC COUNTERS (index = counter id; N pseudo-channels)         [PER_PC_EN = 1]
//    0 acc_rd   1 acc_wr   2 cmp_rd   3 cmp_wr   4 bytes_rd   5 bytes_wr
//    6 row_hit  7 row_empty  8 row_conflict  9 act  10 pre  11 refresh  12 ref_forced  13 ref_pullin
//    14 ref_stall  15 timing_stall  16 qos_stall  17 bypass(reordered)  18 phy_stall
//    19 ecc_ce  20 ecc_ue  21 busy_cycles  22 lat_sum  23 lat_cnt  24 lat_max  25 occ_sum  26 occ_max
//    27 protocol_err (read-return timing/timeout/unexpected)  28 violations  29 deadline_miss
//    30 pd_cycles  31 sr_cycles  32..43 latency histogram, bin b = clog2(lat+1) clipped to 11
//  AGGREGATE COUNTERS (sums over every pseudo-channel, with a snapshot shadow)
//    0 cycles 1 acc_rd 2 acc_wr 3 cmp_rd 4 cmp_wr 5 bytes_rd 6 bytes_wr 7 row_hit 8 row_empty 9 row_conflict
//    10 act 11 pre 12 refresh 13 ref_stall 14 timing_stall 15 qos_stall 16 phy_stall 17 ecc_ce 18 ecc_ue
//    19 busy_pc_cycles 20 lat_sum 21 lat_cnt 22 occ_sum 23 stall_id 24 stall_q 25 stall_fence 26 ref_forced
//    27 ref_pullin 28 violations 29 protocol_err 30 deadline_miss 31 pd_cycles 32 sr_cycles
//
//  ROLLOVER / SNAPSHOT / RESET (defined, docs/PERF_COUNTERS.md)
//    * Every counter is CNT_W bits and SATURATES (never wraps); the first saturation of any counter sets
//      the sticky overflow flag ovf_o (cleared by clear_i).
//    * clear_i  (1-cycle pulse): all counters and the overflow flag go to zero.
//    * snap_i   (1-cycle pulse): all AGGREGATE counters are copied into a shadow bank in one cycle; the
//      shadow is what read_agg reads, so a software read of several aggregates is mutually consistent.
//    * freeze_i (level): all counters hold (events during a freeze are NOT counted). Per-PC counters have no
//      shadow bank (area); read them under freeze_i for a consistent view.
//    * Counting never stops otherwise; counters are NOT cleared by reads.
//  Sample points: events are the one-cycle pulses of hbm_pc_stat_t.evt.
//  RESET: async assert clears everything.
//  AREA NOTE: PER_PC_EN = 1 with 64 pseudo-channels is ~135k flops - a verification / bring-up instrument, not
//  an ASIC default (reports/synth). PER_PC_EN = 0 keeps only the aggregates.
// =============================================================================
module sf_hbm_perf
  import sf_hbm_pkg::*;
#(
  parameter int unsigned N         = 2,
  parameter int unsigned CNT_W     = 48,
  parameter bit          PER_PC_EN = 1'b1
) (
  input  logic                          clk_i,
  input  logic                          rst_ni,
  input  hbm_pc_stat_t [N-1:0]          stat_i,
  input  logic                          ev_stall_id_i,
  input  logic                          ev_stall_q_i,
  input  logic                          ev_stall_fence_i,
  input  logic                          clear_i,
  input  logic                          snap_i,
  input  logic                          freeze_i,
  input  logic [15:0]                   sel_pc_i,
  input  logic [5:0]                    sel_cnt_i,
  input  logic                          sel_agg_i,
  output logic [63:0]                   rdata_o,
  output logic                          ovf_o
);
  localparam int unsigned NPCC = 44;
  localparam int unsigned NAGG = 33;
  localparam int unsigned CW   = CNT_W;

  // Sum in a vector wide enough for BOTH operands (CW may be below 32 in saturation tests); any bit at or above CW = carry-out.
  localparam int unsigned SW = ((CW > 32) ? CW : 32) + 1;
  function automatic logic [CW-1:0] sat_add(input logic [CW-1:0] a, input logic [31:0] b);
    logic [SW-1:0] s;
    s = SW'(a) + SW'(b);
    return (|(s >> CW)) ? {CW{1'b1}} : s[CW-1:0];
  endfunction
  function automatic logic sat_hit(input logic [CW-1:0] a, input logic [31:0] b);
    logic [SW-1:0] s;
    s = SW'(a) + SW'(b);
    return |(s >> CW);
  endfunction

  // ---- aggregate event sums for this cycle -------------------------------------
  logic [31:0] agg_inc [NAGG];
  always_comb begin
    for (int k = 0; k < NAGG; k++) agg_inc[k] = 32'd0;
    agg_inc[0] = 32'd1;
    for (int i = 0; i < N; i++) begin
      automatic hbm_pc_evt_t e = stat_i[i].evt;
      agg_inc[1]  += 32'(e.acc_rd);
      agg_inc[2]  += 32'(e.acc_wr);
      agg_inc[3]  += 32'(e.cmp_rd);
      agg_inc[4]  += 32'(e.cmp_wr);
      agg_inc[5]  += (e.cmp_rd ? 32'(stat_i[i].bytes) : 32'd0);
      agg_inc[6]  += (e.cmp_wr ? 32'(stat_i[i].bytes) : 32'd0);
      agg_inc[7]  += 32'(e.row_hit);
      agg_inc[8]  += 32'(e.row_empty);
      agg_inc[9]  += 32'(e.row_conflict);
      agg_inc[10] += 32'(e.act);
      agg_inc[11] += 32'(e.pre);
      agg_inc[12] += 32'(e.refresh);
      agg_inc[13] += 32'(e.ref_stall);
      agg_inc[14] += 32'(e.timing_stall);
      agg_inc[15] += 32'(e.qos_stall);
      agg_inc[16] += 32'(e.phy_stall);
      agg_inc[17] += 32'(e.ecc_ce);
      agg_inc[18] += 32'(e.ecc_ue);
      agg_inc[19] += 32'(e.busy);
      agg_inc[20] += ((e.cmp_rd || e.cmp_wr) ? 32'(stat_i[i].lat) : 32'd0);
      agg_inc[21] += 32'(e.cmp_rd || e.cmp_wr);
      agg_inc[22] += 32'(stat_i[i].occ);
      agg_inc[26] += 32'(e.ref_forced);
      agg_inc[27] += 32'(e.ref_pullin);
      agg_inc[28] += 32'(e.violation);
      agg_inc[29] += 32'(e.rd_timing_err || e.rd_timeout || e.rd_unexpected);
      agg_inc[30] += 32'(e.deadline_miss);
      agg_inc[31] += 32'(e.in_pd);
      agg_inc[32] += 32'(e.in_sr);
    end
    agg_inc[23] = 32'(ev_stall_id_i);
    agg_inc[24] = 32'(ev_stall_q_i);
    agg_inc[25] = 32'(ev_stall_fence_i);
  end

  logic [CW-1:0] agg_q  [NAGG];
  logic [CW-1:0] shad_q [NAGG];
  logic          ovf_q;
  assign ovf_o = ovf_q;

  logic ovf_new;
  always_comb begin
    ovf_new = 1'b0;
    for (int k = 0; k < NAGG; k++) ovf_new = ovf_new || sat_hit(agg_q[k], agg_inc[k]);
  end

  // ---- per-pseudo-channel counters ----------------------------------------------
  logic [CW-1:0] pc_q [N][NPCC];
  logic          pc_ovf;
  if (PER_PC_EN) begin : g_pc
    logic [N-1:0] ovf_v;
    for (genvar i = 0; i < N; i++) begin : g_i
      logic [31:0] inc [NPCC];
      logic [3:0]  hb;
      always_comb begin
        automatic hbm_pc_evt_t e = stat_i[i].evt;
        automatic logic done = e.cmp_rd || e.cmp_wr;
        for (int k = 0; k < NPCC; k++) inc[k] = 32'd0;
        inc[0]  = 32'(e.acc_rd);          inc[1]  = 32'(e.acc_wr);
        inc[2]  = 32'(e.cmp_rd);          inc[3]  = 32'(e.cmp_wr);
        inc[4]  = e.cmp_rd ? 32'(stat_i[i].bytes) : 32'd0;
        inc[5]  = e.cmp_wr ? 32'(stat_i[i].bytes) : 32'd0;
        inc[6]  = 32'(e.row_hit);         inc[7]  = 32'(e.row_empty);   inc[8]  = 32'(e.row_conflict);
        inc[9]  = 32'(e.act);             inc[10] = 32'(e.pre);         inc[11] = 32'(e.refresh);
        inc[12] = 32'(e.ref_forced);      inc[13] = 32'(e.ref_pullin);  inc[14] = 32'(e.ref_stall);
        inc[15] = 32'(e.timing_stall);    inc[16] = 32'(e.qos_stall);   inc[17] = 32'(e.bypass);
        inc[18] = 32'(e.phy_stall);       inc[19] = 32'(e.ecc_ce);      inc[20] = 32'(e.ecc_ue);
        inc[21] = 32'(e.busy);
        inc[22] = done ? 32'(stat_i[i].lat) : 32'd0;
        inc[23] = 32'(done);
        inc[25] = 32'(stat_i[i].occ);
        inc[27] = 32'(e.rd_timing_err || e.rd_timeout || e.rd_unexpected);
        inc[28] = 32'(e.violation);       inc[29] = 32'(e.deadline_miss);
        inc[30] = 32'(e.in_pd);           inc[31] = 32'(e.in_sr);
        // latency histogram bin
        hb = 4'd0;
        for (int b = 0; b < 12; b++) if (stat_i[i].lat >= 16'((32'd1 << b) )) hb = 4'(b + 1);
        if (hb > 4'd11) hb = 4'd11;
        for (int b = 0; b < 12; b++) inc[32 + b] = (done && (hb == 4'(b))) ? 32'd1 : 32'd0;
      end
      logic ovf_i;
      always_comb begin
        ovf_i = 1'b0;
        for (int k = 0; k < NPCC; k++) if (k != 24 && k != 26) ovf_i = ovf_i || sat_hit(pc_q[i][k], inc[k]);
      end
      assign ovf_v[i] = ovf_i;

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          for (int k = 0; k < NPCC; k++) pc_q[i][k] <= '0;
        end else if (clear_i) begin
          for (int k = 0; k < NPCC; k++) pc_q[i][k] <= '0;
        end else if (!freeze_i) begin
          for (int k = 0; k < NPCC; k++) begin
            if (k == 24)      begin if (inc[23] != 0 && CW'(stat_i[i].lat) > pc_q[i][24]) pc_q[i][24] <= CW'(stat_i[i].lat); end
            else if (k == 26) begin if (CW'(stat_i[i].occ) > pc_q[i][26]) pc_q[i][26] <= CW'(stat_i[i].occ); end
            else              pc_q[i][k] <= sat_add(pc_q[i][k], inc[k]);
          end
        end
      end
    end
    assign pc_ovf = |ovf_v;
  end else begin : g_nopc
    assign pc_ovf = 1'b0;
    always_comb for (int i = 0; i < N; i++) for (int k = 0; k < NPCC; k++) pc_q[i][k] = '0;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int k = 0; k < NAGG; k++) begin agg_q[k] <= '0; shad_q[k] <= '0; end
      ovf_q <= 1'b0;
    end else if (clear_i) begin
      for (int k = 0; k < NAGG; k++) begin agg_q[k] <= '0; shad_q[k] <= '0; end
      ovf_q <= 1'b0;
    end else begin
      if (!freeze_i) begin
        for (int k = 0; k < NAGG; k++) agg_q[k] <= sat_add(agg_q[k], agg_inc[k]);
        if (ovf_new || pc_ovf) ovf_q <= 1'b1;
      end
      if (snap_i) for (int k = 0; k < NAGG; k++) shad_q[k] <= agg_q[k];
    end
  end

  always_comb begin
    rdata_o = '0;
    if (sel_agg_i) begin
      if (sel_cnt_i < 6'(NAGG)) rdata_o = 64'(shad_q[sel_cnt_i]);
    end else if (PER_PC_EN) begin
      if (sel_pc_i < 16'(N) && sel_cnt_i < 6'(NPCC)) rdata_o = 64'(pc_q[sel_pc_i[$clog2(N > 1 ? N : 2)-1:0]][sel_cnt_i]);
    end
  end
endmodule : sf_hbm_perf
