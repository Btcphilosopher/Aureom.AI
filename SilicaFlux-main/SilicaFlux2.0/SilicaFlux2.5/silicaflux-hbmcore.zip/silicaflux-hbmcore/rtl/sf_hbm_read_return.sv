// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_read_return.sv
//  Completion sequencer + read-data return engine of one pseudo-channel.
//
//  WHAT IT OWNS
//    * A circular buffer of CPL_DEPTH completion entries allocated IN COLUMN-COMMAND ISSUE
//      ORDER. An entry carries the response context {src,id,write,err,qos}, the read data
//      and a `done` flag. Responses leave strictly in allocation order, so one
//      pseudo-channel never reorders its own responses; reordering across pseudo-channels
//      is the job of the top level (docs/ORDERING.md).
//    * Credit: an entry is reserved at issue (credit_o low when full). Because space is
//      reserved before the command leaves, PHY read data never needs back-pressure and a
//      stalled response consumer can never lose data.
//
//  COMPLETION RULES
//    READ   : `done` is set ONLY by the PHY return-data event (rd_valid_i). Issuing the
//             command does not complete a read. Data returns in command order; the engine
//             matches it with the oldest outstanding read.
//    WRITE  : `done` is set by the write-data engine's wr_done pulse (see WR completion policy
//             in sf_hbm_write_data).
//    ERROR  : error entries (address/policy errors travelling through the queue) complete
//             immediately with their err code and issue no DRAM command.
//
//  RETURN-TIMING CHECK (docs/PHY_CONTRACT.md)
//    A read pushed at cycle t must return data at exactly t + 1 + RL + RD_EXTRA_LAT.
//      rd_timing_err_o   pulse: data arrived at any other cycle
//      rd_timeout_o      pulse: nothing arrived RD_TIMEOUT cycles after the due time; the
//                        entry completes with HERR_FLUSHED so a lost return cannot hang the system
//      rd_unexpected_o   pulse: data arrived with no outstanding read
//
//  STABILITY: rsp_o is driven from the head entry registers; it does not change while
//  rsp_valid_o && !rsp_ready_i.
//  RESET: async assert; empty.
// =============================================================================
module sf_hbm_read_return
  import sf_hbm_pkg::*;
#(
  parameter int unsigned CPL_DEPTH    = 8,
  parameter int unsigned RD_EXTRA_LAT = 0,
  parameter int unsigned RD_TIMEOUT   = 64
) (
  input  logic                          clk_i,
  input  logic                          rst_ni,
  input  hbm_timing_t                   tp_i,
  input  hbm_cyc_t                      cyc_i,

  // allocate at column-command (or error) issue
  input  logic                          push_valid_i,
  input  hbm_ctx_t                      push_ctx_i,
  input  logic [1:0]                    push_kind_i,      // 0 read, 1 write, 2 error
  output logic [$clog2(CPL_DEPTH)-1:0]  push_idx_o,
  output logic                          credit_o,

  input  logic                          wr_done_valid_i,
  input  logic [$clog2(CPL_DEPTH)-1:0]  wr_done_idx_i,

  // PHY read-data return (already ECC-processed)
  input  logic                          rd_valid_i,
  input  hbm_data_t                     rd_data_i,
  input  hbm_err_e                      rd_err_i,
  input  logic                          rd_corr_i,

  // response channel
  output logic                          rsp_valid_o,
  input  logic                          rsp_ready_i,
  output hbm_rsp_t                      rsp_o,
  output logic [5:0]                    rsp_bytes_o,
  output logic [15:0]                   rsp_lat_o,        // request-queue age + completion-sequencer residency

  output logic [$clog2(CPL_DEPTH):0]    occ_o,
  output logic                          rd_timing_err_o,
  output logic                          rd_timeout_o,
  output logic                          rd_unexpected_o
);
  localparam int unsigned IW = $clog2(CPL_DEPTH);

  hbm_ctx_t  [CPL_DEPTH-1:0] ctx_q;
  logic      [CPL_DEPTH-1:0] done_q, corr_q;
  hbm_err_e  [CPL_DEPTH-1:0] err_q;
  hbm_data_t [CPL_DEPTH-1:0] data_q;
  hbm_cyc_t  [CPL_DEPTH-1:0] tpush_q;

  logic [IW-1:0] head_q, tail_q;
  logic [IW:0]   cnt_q;

  // outstanding-read FIFO (index into the completion buffer + due cycle)
  logic [IW-1:0]            rq_idx [CPL_DEPTH];
  hbm_cyc_t                 rq_due [CPL_DEPTH];
  logic [IW-1:0]            rq_rp, rq_wp;
  logic [IW:0]              rq_cnt;

  assign push_idx_o = tail_q;
  assign credit_o   = (cnt_q != (IW+1)'(CPL_DEPTH));
  assign occ_o      = cnt_q;

  wire push_fire = push_valid_i && credit_o;
  wire head_done = (cnt_q != '0) && done_q[head_q];
  assign rsp_valid_o = head_done;
  wire pop_fire = head_done && rsp_ready_i;

  always_comb begin
    rsp_o           = '0;
    rsp_o.src       = ctx_q[head_q].src;
    rsp_o.id        = ctx_q[head_q].id;
    rsp_o.write     = ctx_q[head_q].write;
    rsp_o.err       = err_q[head_q];
    rsp_o.corrected = corr_q[head_q];
    rsp_o.data      = ctx_q[head_q].write ? '0 : data_q[head_q];
    rsp_bytes_o     = ctx_q[head_q].bytes;
    rsp_lat_o       = ctx_q[head_q].lat0 + 16'(cyc_i - tpush_q[head_q]);
  end

  // read-return matching
  wire        rq_have   = (rq_cnt != '0);
  hbm_cyc_t   head_due;
  assign head_due = rq_due[rq_rp];
  wire        late_to   = rq_have && !rd_valid_i && (cyc_i != head_due) &&
                          ((cyc_i - head_due) < 16'h8000) &&
                          ((cyc_i - head_due) >= hbm_cyc_t'(RD_TIMEOUT));

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      head_q <= '0; tail_q <= '0; cnt_q <= '0;
      done_q <= '0; corr_q <= '0; err_q <= '0; ctx_q <= '0; data_q <= '0; tpush_q <= '0;
      rq_rp <= '0; rq_wp <= '0; rq_cnt <= '0;
      rd_timing_err_o <= 1'b0; rd_timeout_o <= 1'b0; rd_unexpected_o <= 1'b0;
    end else begin
      rd_timing_err_o <= 1'b0; rd_timeout_o <= 1'b0; rd_unexpected_o <= 1'b0;

      // ---- allocate ----------------------------------------------------------
      if (push_fire) begin
        ctx_q[tail_q]  <= push_ctx_i;
        tpush_q[tail_q] <= cyc_i;
        corr_q[tail_q] <= 1'b0;
        data_q[tail_q] <= '0;
        err_q[tail_q]  <= push_ctx_i.err;
        done_q[tail_q] <= (push_kind_i == 2'd2);
        tail_q <= (tail_q == IW'(CPL_DEPTH-1)) ? '0 : (tail_q + 1'b1);
        if (push_kind_i == 2'd0) begin
          rq_idx[rq_wp] <= tail_q;
          rq_due[rq_wp] <= cyc_i + hbm_cyc_t'(1) + tp_i.rl[HBM_CYC_W-1:0] + hbm_cyc_t'(RD_EXTRA_LAT);
          rq_wp <= (rq_wp == IW'(CPL_DEPTH-1)) ? '0 : (rq_wp + 1'b1);
        end
      end

      // ---- write completion --------------------------------------------------
      if (wr_done_valid_i)
        done_q[wr_done_idx_i] <= 1'b1;

      // ---- read data return --------------------------------------------------
      if (rd_valid_i) begin
        if (rq_have) begin
          data_q[rq_idx[rq_rp]] <= rd_data_i;
          corr_q[rq_idx[rq_rp]] <= rd_corr_i;
          err_q [rq_idx[rq_rp]] <= (rd_err_i != HERR_NONE) ? rd_err_i : ctx_q[rq_idx[rq_rp]].err;
          done_q[rq_idx[rq_rp]] <= 1'b1;
          if (cyc_i != head_due) rd_timing_err_o <= 1'b1;
          rq_rp  <= (rq_rp == IW'(CPL_DEPTH-1)) ? '0 : (rq_rp + 1'b1);
        end else begin
          rd_unexpected_o <= 1'b1;
        end
      end else if (late_to) begin
        err_q [rq_idx[rq_rp]] <= HERR_FLUSHED;
        done_q[rq_idx[rq_rp]] <= 1'b1;
        rd_timeout_o <= 1'b1;
        rq_rp  <= (rq_rp == IW'(CPL_DEPTH-1)) ? '0 : (rq_rp + 1'b1);
      end
      // outstanding-read count
      case ({push_fire && (push_kind_i == 2'd0), (rd_valid_i && rq_have) || (!rd_valid_i && late_to)})
        2'b10:   rq_cnt <= rq_cnt + 1'b1;
        2'b01:   rq_cnt <= rq_cnt - 1'b1;
        default: rq_cnt <= rq_cnt;
      endcase

      // ---- release -----------------------------------------------------------
      if (pop_fire) begin
        done_q[head_q] <= 1'b0;
        head_q <= (head_q == IW'(CPL_DEPTH-1)) ? '0 : (head_q + 1'b1);
      end
      case ({push_fire, pop_fire})
        2'b10:   cnt_q <= cnt_q + 1'b1;
        2'b01:   cnt_q <= cnt_q - 1'b1;
        default: cnt_q <= cnt_q;
      endcase
    end
  end

`ifndef SYNTHESIS
  // a pop and a same-cycle done-set for the same index would be a design error
  always_ff @(posedge clk_i) if (rst_ni) begin
    if (rsp_valid_o && !rsp_ready_i) begin
      // payload stability is asserted by the formal harness; here: head must not move
    end
    if (wr_done_valid_i && !((cnt_q != '0) || push_fire))
      $error("[%m] write completion for an unallocated entry");
  end
`endif
endmodule : sf_hbm_read_return
