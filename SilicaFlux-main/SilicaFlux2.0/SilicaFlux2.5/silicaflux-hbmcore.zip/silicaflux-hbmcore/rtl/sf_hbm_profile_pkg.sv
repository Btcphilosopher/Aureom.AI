// =============================================================================
//  GENERATED FILE - DO NOT EDIT.  Source: configs/timing/profiles.json
//  Generator: scripts/gen_profiles.py (validates every profile before emitting)
//
//  ALL SHIPPED PROFILES ARE HYPOTHETICAL_SIM. They are not JEDEC / vendor values.
// =============================================================================
package sf_hbm_profile_pkg;
  import sf_hbm_pkg::*;
  localparam int unsigned HBM_NUM_PROFILES = 3;
  // status code: 0 HYPOTHETICAL_SIM, 1 VERIFIED_STANDARD, 2 VERIFIED_PHY_SPEC
  function automatic logic [1:0] hbm_profile_status(input logic [3:0] sel);
    case (sel)
      4'd0: return 2'd0;   // sim_fast
      4'd1: return 2'd0;   // sim_ref
      4'd2: return 2'd0;   // sim_strict
      default: return 2'd0;
    endcase
  endfunction

  // per-bank refresh feasible for this profile? (rule in scripts/gen_profiles.py: trefi/16 >= max(tras, WR2PRE) + trp + 8)
  function automatic logic hbm_profile_pb_ok(input logic [3:0] sel);
    case (sel)
      4'd0: return 1'b0;   // sim_fast
      4'd1: return 1'b1;   // sim_ref
      4'd2: return 1'b1;   // sim_strict
      default: return 1'b0;
    endcase
  endfunction

  // informational clock of the profile in MHz (1 cycle = 1000/clock_mhz ns); not used by any timing rule
  function automatic logic [15:0] hbm_profile_mhz(input logic [3:0] sel);
    case (sel)
      4'd0: return 16'd1000;   // sim_fast
      4'd1: return 16'd1000;   // sim_ref
      4'd2: return 16'd1000;   // sim_strict
      default: return 16'd0;
    endcase
  endfunction

  function automatic hbm_timing_t hbm_profile(input logic [3:0] sel);
    hbm_timing_t t;
    t = '0;
    case (sel)
      4'd0: begin   // sim_fast  [HYPOTHETICAL_SIM]
        t.trcdrd = 16'd4;
        t.trcdwr = 16'd3;
        t.trp = 16'd4;
        t.tras = 16'd9;
        t.trc = 16'd13;
        t.tccd_s = 16'd1;
        t.tccd_l = 16'd2;
        t.trrd_s = 16'd2;
        t.trrd_l = 16'd3;
        t.tfaw = 16'd10;
        t.twr = 16'd5;
        t.twtr_s = 16'd2;
        t.twtr_l = 16'd4;
        t.trtp = 16'd2;
        t.trfc = 16'd24;
        t.trfcpb = 16'd12;
        t.trefi = 16'd240;
        t.rl = 16'd6;
        t.wl = 16'd3;
        t.burst = 16'd1;
        t.tmrd = 16'd4;
        t.txp = 16'd4;
        t.txs = 16'd30;
        t.max_postpone = 16'd3;
        t.max_pullin = 16'd2;
      end
      4'd1: begin   // sim_ref  [HYPOTHETICAL_SIM]
        t.trcdrd = 16'd14;
        t.trcdwr = 16'd10;
        t.trp = 16'd14;
        t.tras = 16'd34;
        t.trc = 16'd48;
        t.tccd_s = 16'd1;
        t.tccd_l = 16'd2;
        t.trrd_s = 16'd2;
        t.trrd_l = 16'd4;
        t.tfaw = 16'd16;
        t.twr = 16'd16;
        t.twtr_s = 16'd4;
        t.twtr_l = 16'd8;
        t.trtp = 16'd6;
        t.trfc = 16'd260;
        t.trfcpb = 16'd130;
        t.trefi = 16'd3900;
        t.rl = 16'd20;
        t.wl = 16'd8;
        t.burst = 16'd1;
        t.tmrd = 16'd8;
        t.txp = 16'd8;
        t.txs = 16'd270;
        t.max_postpone = 16'd4;
        t.max_pullin = 16'd4;
      end
      4'd2: begin   // sim_strict  [HYPOTHETICAL_SIM]
        t.trcdrd = 16'd20;
        t.trcdwr = 16'd16;
        t.trp = 16'd18;
        t.tras = 16'd44;
        t.trc = 16'd62;
        t.tccd_s = 16'd2;
        t.tccd_l = 16'd4;
        t.trrd_s = 16'd4;
        t.trrd_l = 16'd6;
        t.tfaw = 16'd28;
        t.twr = 16'd20;
        t.twtr_s = 16'd6;
        t.twtr_l = 16'd12;
        t.trtp = 16'd8;
        t.trfc = 16'd350;
        t.trfcpb = 16'd180;
        t.trefi = 16'd1950;
        t.rl = 16'd24;
        t.wl = 16'd10;
        t.burst = 16'd2;
        t.tmrd = 16'd10;
        t.txp = 16'd10;
        t.txs = 16'd360;
        t.max_postpone = 16'd2;
        t.max_pullin = 16'd2;
      end
      default: begin   // fall back to profile 0
        t.trcdrd = 16'd4;
        t.trcdwr = 16'd3;
        t.trp = 16'd4;
        t.tras = 16'd9;
        t.trc = 16'd13;
        t.tccd_s = 16'd1;
        t.tccd_l = 16'd2;
        t.trrd_s = 16'd2;
        t.trrd_l = 16'd3;
        t.tfaw = 16'd10;
        t.twr = 16'd5;
        t.twtr_s = 16'd2;
        t.twtr_l = 16'd4;
        t.trtp = 16'd2;
        t.trfc = 16'd24;
        t.trfcpb = 16'd12;
        t.trefi = 16'd240;
        t.rl = 16'd6;
        t.wl = 16'd3;
        t.burst = 16'd1;
        t.tmrd = 16'd4;
        t.txp = 16'd4;
        t.txs = 16'd30;
        t.max_postpone = 16'd3;
        t.max_pullin = 16'd2;
      end
    endcase
    return t;
  endfunction
endpackage : sf_hbm_profile_pkg
