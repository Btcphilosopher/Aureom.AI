#!/usr/bin/env python3
"""SILICAFLUX HBMCORE engineering dashboard generator.

Reads REAL simulation / synthesis / verification outputs under the project root and writes ONE self-contained
HTML file, dashboard/index.html (inline CSS/JS/SVG, no network access, no external assets).

    python3 dashboard/build_dashboard.py            # normal run (also: make hbm-dashboard)
    python3 dashboard/build_dashboard.py --quiet    # only the final summary line

Rules this script enforces (see dashboard/README.md):
  * NO FABRICATED DATA. Every number embedded below is read from a file; a missing input produces an explicit
    'no data' panel in the page, never a placeholder. Only two kinds of derived values exist and both are labelled
    in the page: nearest-rank latency percentiles from the exact latency histogram, and trace-derived command
    sequences / REF lists. Nothing is smoothed, extrapolated or synthesised.
  * Deterministic: same inputs -> byte-identical index.html (no wall-clock time is embedded; a content
    fingerprint is printed instead). Large traces are down-sampled with a fixed stride and the page says so.
  * Plain python3 standard library only. Exits 0 even when inputs are missing.

Inputs (all optional): reports/summary.json, reports/bench/*.json, reports/bench/timeline/*.timeline.json and *.cmds,
reports/traces/pc_single_p*_pol*.trace, configs/timing/profiles.json, reports/regression.json, reports/formal.json,
reports/mutation_report.json, reports/cocotb.json, reports/synth/*.json, reports/synth/SYNTH.md,
reports/datafabric_summary.json, integration/datafabric/third_party/noc_v2/PACKET_SPEC.md (packet field table).
"""
import argparse
import hashlib
import json
import math
import os
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
REPORTS = ROOT / "reports"
OUT = HERE / "index.html"
TEMPLATE = HERE / "template.html"

# canonical order of the benchmark matrix (scripts/run_benchmarks.sh / scripts/make_report.py)
MAIN_ORDER = ["A_seq_read", "B_seq_write", "C_balanced", "D_random", "E_hotspot_1ch", "F_all_channels", "G_high_locality",
              "H_low_locality", "I_refresh_on", "I_refresh_off", "J_compete_noqos", "J_compete_qos", "K_tensor_gemm_4096",
              "K_tensor_gemm_32768", "K_tensor_gemm_262144", "L_fp64_stream", "A_seq_read_single_port", "F_all_ch_single_port"]
EXPECTED_SCALE = [f"scale_{w}_{c}ch" for c in (1, 2, 4, 8, 32) for w in ("A", "F")]

MAX_TIMELINE_SAMPLES = 4000       # deterministic stride down-sampling above this
MAX_CMDLOG_ROWS = 60000
MAX_REFS = 4000
FORBIDDEN = re.compile(r"(?i)\b(hbm4|jedec)[\s\-]*compliant")

QUIET = False
INPUTS = []      # {path, label, found, detail, make}
NOTES = []       # human-readable notes shown in the page footer / inputs panel


def say(msg):
    if not QUIET:
        print(msg)


def rel(p):
    try:
        return str(pathlib.Path(p).resolve().relative_to(ROOT))
    except ValueError:
        return str(p)


def log_input(path, found, make, detail="", label=None):
    INPUTS.append(dict(path=path, label=label or path, found=bool(found), make=make, detail=detail))
    say(f"  [{'found  ' if found else 'MISSING'}] {path}" + (f"  ({detail})" if detail else "") + ("" if found else f"   -> run {make}"))


def read_json(path, make, label=None, quiet_missing=False):
    """Return parsed JSON or None. Logs the outcome."""
    p = ROOT / path
    if not p.exists():
        if not quiet_missing:
            log_input(path, False, make, label=label)
        return None
    try:
        data = json.loads(p.read_text())
    except Exception as e:  # noqa: BLE001 - report, never crash
        log_input(path, False, make, detail=f"unreadable: {e}", label=label)
        return None
    log_input(path, True, make, label=label)
    return data


# ------------------------------------------------------------------------------------------------ helpers
def decimate(seq, limit):
    """Deterministic stride down-sampling that always keeps the last element. Returns (list, stride)."""
    n = len(seq)
    if n <= limit:
        return seq, 1
    stride = int(math.ceil(n / limit))
    out = seq[::stride]
    if out[-1] is not seq[-1]:
        out.append(seq[-1])
    return out, stride


def pctile_hist(hist, p):
    """Nearest-rank percentile (python/hbm4/performance.percentile semantics) over {value: count}."""
    items = sorted((int(k), int(v)) for k, v in hist.items())
    n = sum(v for _, v in items)
    if n == 0:
        return None
    rank = max(1, min(n, int(math.ceil(p / 100.0 * n))))
    c = 0
    for k, v in items:
        c += v
        if c >= rank:
            return k
    return items[-1][0]


def scrub(obj):
    """Remove any claim phrase the dashboard must never print (from embedded text)."""
    if isinstance(obj, str):
        return FORBIDDEN.sub("[claim removed]", obj)
    if isinstance(obj, list):
        return [scrub(x) for x in obj]
    if isinstance(obj, dict):
        return {k: scrub(v) for k, v in obj.items()}
    return obj


# ------------------------------------------------------------------------------------------------ benchmarks
def bench_from_summary_row(name, r):
    """Fallback when reports/bench/*.json are absent: rebuild what summary.json carries (no histogram, no per-PC arrays)."""
    return dict(
        name=name, benchmark=r.get("bench"), status="MODELLED_HYPOTHETICAL_PROFILE_NOT_HARDWARE", partial_from_summary=True,
        config=r.get("cfg", {}), requested_bytes=r.get("requested_bytes"), completed_bytes=r.get("completed_bytes"),
        read_bytes=None, write_bytes=None, cycles=r.get("cycles"), time_us=r.get("time_us"), bandwidth_gb_s=r.get("bw"),
        peak_modelled_gb_s=r.get("peak"), efficiency=r.get("eff"),
        latency=dict(mean=r.get("lat_mean"), max=r.get("lat_max"), hist=None), p=dict(p50=r.get("p50"), p95=r.get("p95"), p99=r.get("p99")),
        row=dict(hit_rate=r.get("hit"), act=r.get("act"), pre=r.get("pre")),
        stalls=dict(queue_full_cycles=r.get("q_stall"), timing_stall_pc_cycles=r.get("t_stall"), refresh_stall_pc_cycles=r.get("r_stall")),
        refresh=dict(commands=r.get("refreshes"), overhead_fraction=r.get("refresh_ovh")),
        dram_violations=r.get("viol"), pc_utilisation=None, pc_bytes=None, sources=r.get("sources") or [], gemm=r.get("gemm"))


def load_bench(summary):
    bench = {}
    bdir = REPORTS / "bench"
    files = sorted(bdir.glob("*.json")) if bdir.is_dir() else []
    for f in files:
        try:
            d = json.loads(f.read_text())
        except Exception as e:  # noqa: BLE001
            say(f"  [unreadable] {rel(f)}: {e}")
            NOTES.append(f"{rel(f)} unreadable ({e}); skipped")
            continue
        if f.stem.startswith("_"):        # leading underscore = scratch / probe output, not a benchmark result
            say(f"  [skipped] {rel(f)} (scratch file: leading underscore)")
            continue
        d["name"] = f.stem
        lat = d.get("latency") or {}
        hist = lat.get("hist")
        if hist:
            d["p"] = dict(p50=pctile_hist(hist, 50), p95=pctile_hist(hist, 95), p99=pctile_hist(hist, 99))
        else:
            d["p"] = dict(p50=None, p95=None, p99=None)
        bench[f.stem] = d
    if not files and summary and summary.get("benchmarks"):
        for k, r in sorted(summary["benchmarks"].items()):
            bench[k] = bench_from_summary_row(k, r)
        NOTES.append("reports/bench/*.json not found: benchmark views use reports/summary.json (no histograms / per-PC arrays).")
        say("  [fallback] reports/bench/*.json absent -> using reports/summary.json rows")
    # cross-check percentiles against summary.json when both exist (independent arithmetic, same definition)
    if summary and summary.get("benchmarks") and files:
        bad = 0
        for k, r in summary["benchmarks"].items():
            b = bench.get(k)
            if b and b["p"]["p50"] is not None and (b["p"]["p50"], b["p"]["p95"], b["p"]["p99"]) != (r.get("p50"), r.get("p95"), r.get("p99")):
                bad += 1
                NOTES.append(f"percentile mismatch for {k} between dashboard and summary.json")
        say(f"  percentile cross-check vs summary.json: {'OK' if not bad else str(bad) + ' MISMATCH(ES)'}")
    names = list(bench)
    order = [n for n in MAIN_ORDER if n in bench]
    order += sorted(n for n in names if n not in MAIN_ORDER and n.startswith("scale_"))
    order += sorted(n for n in names if n not in MAIN_ORDER and n.startswith("dse_"))
    order += sorted(n for n in names if n not in order)
    if bdir.is_dir():
        for n in MAIN_ORDER[:-2]:
            log_input(f"reports/bench/{n}.json", n in bench, "make hbm-benchmark", label=n)
        have = [n for n in names if n.startswith("scale_")]
        log_input("reports/bench/scale_*.json", bool(have), "make hbm-benchmark", detail=f"{len(have)} of {len(EXPECTED_SCALE)} expected" if have else "",
                  label="scaling runs")
        have = [n for n in names if n.startswith("dse_")]
        log_input("reports/bench/dse_*.json", bool(have), "make hbm-benchmark", detail=f"{len(have)} files" if have else "", label="design-space runs")
    else:
        log_input("reports/bench/", False, "make hbm-benchmark", label="benchmark directory")
    return bench, order


# ------------------------------------------------------------------------------------------------ timeline / command log
def parse_timeline(path):
    txt = path.read_text()
    partial = False
    try:
        arr = json.loads(txt)
    except Exception:  # partial file while the benchmark is still running: keep complete rows only
        partial = True
        rows = []
        for ln in txt.splitlines():
            ln = ln.strip().rstrip(",")
            if ln.startswith("{") and ln.endswith("}"):
                try:
                    rows.append(json.loads(ln))
                except Exception:  # noqa: BLE001
                    pass
        arr = rows
    samples = [x for x in arr if isinstance(x, dict) and "t" in x]
    return samples, partial


def load_timelines():
    tl, cl = {}, {}
    d = REPORTS / "bench" / "timeline"
    if d.is_dir():
        for f in sorted(d.glob("*.timeline.json")):
            key = f.name[:-len(".timeline.json")]
            try:
                samples, partial = parse_timeline(f)
            except Exception as e:  # noqa: BLE001
                say(f"  [unreadable] {rel(f)}: {e}")
                continue
            total = len(samples)
            samples, stride = decimate(samples, MAX_TIMELINE_SAMPLES)
            tl[key] = dict(samples=[dict(t=s["t"], busy=s.get("busy"), occ=s.get("occ"), done=s.get("done"), bank0=s.get("bank0")) for s in samples],
                           total=total, stride=stride, partial=partial)
            log_input(rel(f), True, "make hbm-benchmark", detail=f"{total} samples" + (", PARTIAL file" if partial else "") + (f", stride {stride}" if stride > 1 else ""))
        for f in sorted(d.glob("*.cmds")):
            key = f.name[:-len(".cmds")]
            rows, bad = [], 0
            for ln in f.read_text().splitlines():
                p = ln.split()
                if len(p) == 7:
                    try:
                        rows.append([int(x) for x in p])
                        continue
                    except ValueError:
                        pass
                bad += 1 if ln.strip() else 0
            total = len(rows)
            rows, stride = decimate(rows, MAX_CMDLOG_ROWS)
            cl[key] = dict(rows=rows, total=total, stride=stride, ignored_lines=bad)
            log_input(rel(f), True, "make hbm-benchmark", detail=f"{total} commands" + (f", stride {stride}" if stride > 1 else ""))
    if not tl:
        log_input("reports/bench/timeline/A.timeline.json", False, "make hbm-benchmark", label="timeline A")
    if not cl:
        log_input("reports/bench/timeline/A.cmds", False, "make hbm-benchmark", label="command log A")
    return tl, cl


# ------------------------------------------------------------------------------------------------ traces
def analyse_trace(path, prof):
    cmds, wset = [], set()
    for ln in path.read_text().splitlines():
        p = ln.split()
        if not p:
            continue
        try:
            if p[0] == "W":
                wset.add((int(p[1]), int(p[2])))
            elif len(p) == 7:
                cmds.append(tuple(int(x) for x in p))
        except ValueError:
            continue
    counts = {}
    for c in cmds:
        counts[c[2]] = counts.get(c[2], 0) + 1
    last = max((c[0] for c in cmds), default=0)
    refs = [[c[0], c[2], c[3], c[4]] for c in cmds if c[2] in (6, 7)]
    preas = [c[0] for c in cmds if c[2] == 5]
    rec = dict(file=path.name, n_cmds=len(cmds), n_wdata=len(wset), last_cycle=last, counts={str(k): v for k, v in sorted(counts.items())},
               refs=refs[:MAX_REFS], n_refs=len(refs), preas=preas[:MAX_REFS], seqs=[])
    if not prof:
        return rec
    # ---- bank sequences ACT -> (RD|WR)+ -> PRE|PREA -> ACT, per (pc, bank), from the trace itself
    banks = {}
    prea = {}
    for c in cmds:
        cyc, pc, cmd, bg, ba, row, col = c
        if cmd in (1, 2, 3, 4, 7):
            banks.setdefault((pc, bg, ba), []).append((cyc, cmd, row, col))
        elif cmd == 5:
            prea.setdefault(pc, []).append((cyc, 5, 0, 0))
    wl = prof["wl"]
    seqs = []
    for (pc, bg, ba), evs in banks.items():
        merged = sorted(evs + prea.get(pc, []), key=lambda e: e[0])
        cur = None
        for cyc, cmd, row, col in merged:
            if cmd == 1:
                if cur and cur["pre"] is not None and cur["cols"]:
                    cur["act1"] = [cyc, row]
                    seqs.append(cur)
                cur = dict(pc=pc, bg=bg, ba=ba, act0=[cyc, row], cols=[], pre=None, act1=None)
            elif cmd in (2, 3):
                if cur and cur["pre"] is None:
                    cur["cols"].append([cyc, cmd, col])
            elif cmd in (4, 5):
                if cur and cur["pre"] is None:
                    cur["pre"] = [cyc, cmd]
    seqs.sort(key=lambda s: (s["act0"][0], s["pc"], s["bg"], s["ba"]))

    def slack(s):
        a0, a1, pre = s["act0"][0], s["act1"][0], s["pre"][0]
        c0 = s["cols"][0]
        out = [c0[0] - a0 - (prof["trcdrd"] if c0[1] == 2 else prof["trcdwr"]), pre - a0 - prof["tras"], a1 - pre - prof["trp"], a1 - a0 - prof["trc"]]
        for c in s["cols"]:
            if c[1] == 2:
                out.append(pre - c[0] - prof["trtp"])
            else:
                out.append(pre - c[0] - (prof["wl"] + prof["burst"] + prof["twr"]))
        return out

    viol = [s for s in seqs if min(slack(s)) < 0]
    rec["n_seq_total"] = len(seqs)
    rec["n_seq_violating_profile_min"] = len(viol)
    chosen = []
    # Candidates for the diagram: row visits whose ACT-to-ACT span is at most 8 x tRC, so that the spacing is legible
    # (open-page visits that stay open for thousands of cycles are still counted in n_seq_* above).
    pool = [s for s in seqs if s["act1"][0] - s["act0"][0] <= 8 * prof["trc"]] or seqs
    rec["n_seq_compact"] = len(pool)

    def pick(pred, kind):
        for s in pool:
            if pred(s) and not any(s is c[0] for c in chosen):
                chosen.append((s, kind))
                return

    if pool:
        pick(lambda s: True, "first row visit")
        pick(lambda s: all(c[1] == 2 for c in s["cols"]), "first read-only row visit")
        pick(lambda s: all(c[1] == 3 for c in s["cols"]), "first write-only row visit")
        pick(lambda s: {c[1] for c in s["cols"]} == {2, 3}, "first mixed read+write row visit")
        pick(lambda s: len(s["cols"]) >= 4, "first row visit with >= 4 column commands")
        tight = min(pool, key=lambda s: (min(slack(s)), s["act0"][0]))
        if not any(tight is c[0] for c in chosen):
            chosen.append((tight, "tightest slack against the profile minimum"))
    out = []
    for s, kind in sorted(chosen, key=lambda t: t[0]["act0"][0]):
        s = dict(s)
        s["kind"] = kind
        s["wd"] = [c[0] + wl for c in s["cols"] if c[1] == 3 and (c[0] + wl, s["pc"]) in wset]
        s["min_slack"] = min(slack(s))
        out.append(s)
    rec["seqs"] = out
    return rec


def load_traces(profiles):
    out = []
    d = REPORTS / "traces"
    files = sorted(d.glob("pc_single_p*_pol*.trace")) if d.is_dir() else []
    pmap = {p["id"]: p for p in profiles}
    for f in files:
        m = re.match(r"pc_single_p(\d+)_pol(\d+)\.trace$", f.name)
        if not m:
            continue
        pid, pol = int(m.group(1)), int(m.group(2))
        rec = analyse_trace(f, pmap.get(pid))
        rec.update(profile=pid, policy=pol)
        out.append(rec)
        warn = f", {rec.get('n_seq_violating_profile_min', 0)} sequences below a profile minimum!" if rec.get("n_seq_violating_profile_min") else ""
        log_input(rel(f), True, "make hbm-channel-test",
                  detail=f"{rec['n_cmds']} cmds, {rec['n_refs']} REF, {len(rec['seqs'])} candidate sequences" + warn)
    if not files:
        log_input("reports/traces/pc_single_p1_pol1.trace", False, "make hbm-channel-test", label="RTL command trace")
    return out


# ------------------------------------------------------------------------------------------------ synthesis / docs
def load_synth():
    synth = {}
    d = REPORTS / "synth"
    if d.is_dir():
        for f in sorted(d.glob("*.json")):
            try:
                synth[f.stem] = json.loads(f.read_text())
            except Exception as e:  # noqa: BLE001
                say(f"  [unreadable] {rel(f)}: {e}")
        log_input("reports/synth/*.json", bool(synth), "make hbm-synthesis", detail=f"{len(synth)} modules" if synth else "", label="synthesis proxy")
    else:
        log_input("reports/synth/*.json", False, "make hbm-synthesis", label="synthesis proxy")
    md = None
    p = d / "SYNTH.md"
    if p.exists():
        md = p.read_text()
        log_input("reports/synth/SYNTH.md", True, "make hbm-synthesis")
    else:
        log_input("reports/synth/SYNTH.md", False, "make hbm-synthesis")
    return synth, md


def load_packet_fields():
    rp = "integration/datafabric/third_party/noc_v2/PACKET_SPEC.md"
    p = ROOT / rp
    if not p.exists():
        log_input(rp, False, "(vendored NoC contract)", label="packet field table")
        return None
    fields = []
    in_tbl = False
    for ln in p.read_text().splitlines():
        if ln.startswith("| bits "):
            in_tbl = True
            continue
        if in_tbl:
            if not ln.startswith("|"):
                if fields:
                    break
                continue
            cells = [c.strip().replace("**", "").replace("`", "") for c in ln.strip().strip("|").split("|")]
            if len(cells) >= 6 and re.match(r"^\d+(:\d+)?$", cells[0]):
                fields.append(dict(bits=cells[0], name=cells[1].strip("`"), width=cells[2], type=cells[3].strip("`"), meaning=cells[4], inspected=cells[5]))
    log_input(rp, bool(fields), "(vendored NoC contract)", detail=f"{len(fields)} fields" if fields else "table not found", label="packet field table")
    return fields or None


# ------------------------------------------------------------------------------------------------ main
def main():
    global QUIET
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--out", default=str(OUT))
    args = ap.parse_args()
    QUIET = args.quiet
    say(f"SILICAFLUX HBMCORE dashboard build   root={ROOT}")
    say("inputs:")

    summary = read_json("reports/summary.json", "make hbm-report", label="summary (make_report.py)")
    profiles_raw = read_json("configs/timing/profiles.json", "make hbm-gen", label="timing profiles")
    profiles = []
    if profiles_raw:
        for p in profiles_raw.get("profiles", []):
            profiles.append(p)
    bench, order = load_bench(summary)
    timelines, cmdlogs = load_timelines()
    for key, t in list(timelines.items()) + list(cmdlogs.items()):
        t["bench"] = next((n for n in order if bench[n].get("benchmark") == key and bench[n].get("config", {}).get("npc") == 64
                           and bench[n].get("config", {}).get("ports", 1) == 1), next((n for n in order if bench[n].get("benchmark") == key), None))
    traces = load_traces(profiles)

    regression = read_json("reports/regression.json", "make hbm-regression", label="regression")
    if regression is None and summary and summary.get("regression"):
        regression = dict(summary=summary["regression"], results=None, from_summary=True)
        say("  [fallback] regression counts taken from reports/summary.json")
    formal = read_json("reports/formal.json", "make hbm-formal", label="formal")
    if formal is None and summary and summary.get("formal"):
        formal = summary["formal"]
        say("  [fallback] formal results taken from reports/summary.json")
    mutation = read_json("reports/mutation_report.json", "make hbm-mutation", label="mutation")
    cocotb = read_json("reports/cocotb.json", "python3 verification/cocotb/run_cocotb.py", label="cocotb")
    synth, synth_md = load_synth()
    if not synth and summary and summary.get("synthesis"):
        synth = summary["synthesis"]
        say("  [fallback] synthesis rows taken from reports/summary.json")
    datafabric = read_json("reports/datafabric_summary.json", "make hbm-transaction-test", label="datafabric summary")
    packet_fields = load_packet_fields()

    data = dict(
        meta=dict(title="SILICAFLUX HBMCORE engineering dashboard", generator="dashboard/build_dashboard.py", notes=NOTES,
                  caps=dict(timeline=MAX_TIMELINE_SAMPLES, cmdlog=MAX_CMDLOG_ROWS, refs=MAX_REFS)),
        inputs=INPUTS, profiles=profiles, main_order=MAIN_ORDER, bench_order=order, bench=bench,
        summary=dict(present=bool(summary), refused=(summary or {}).get("refused"), n_rows=len((summary or {}).get("benchmarks", {}))),
        timelines=timelines, cmdlogs=cmdlogs, traces=traces,
        regression=regression, formal=formal, mutation=mutation, cocotb=cocotb,
        synth=synth, synth_md=synth_md, datafabric=datafabric, packet_fields=packet_fields)
    data = scrub(data)
    n_found = sum(1 for i in INPUTS if i["found"])
    n_miss = len(INPUTS) - n_found
    data["meta"]["n_found"], data["meta"]["n_missing"] = n_found, n_miss
    blob = json.dumps(data, separators=(",", ":"), ensure_ascii=True)
    fp = hashlib.sha256(blob.encode()).hexdigest()[:12]
    data["meta"]["fingerprint"] = fp
    blob = json.dumps(data, separators=(",", ":"), ensure_ascii=True).replace("<", "\\u003c")

    if not TEMPLATE.exists():
        print(f"ERROR: template missing: {TEMPLATE}", file=sys.stderr)
        return 1
    tpl = TEMPLATE.read_text()
    if "__DASHBOARD_DATA_JSON__" not in tpl:
        print("ERROR: template has no __DASHBOARD_DATA_JSON__ placeholder", file=sys.stderr)
        return 1
    html = tpl.replace("__DASHBOARD_DATA_JSON__", blob)
    bad = FORBIDDEN.search(html)
    if bad:
        print(f"ERROR: forbidden claim wording in output: {bad.group(0)!r}", file=sys.stderr)
        return 1
    out = pathlib.Path(args.out)
    tmp = out.with_suffix(".html.tmp")
    tmp.write_text(html, encoding="utf-8")
    os.replace(tmp, out)
    size = out.stat().st_size
    nb = len(bench)
    print(f"wrote {rel(out)}  {size/1024:.0f} KiB  fingerprint {fp}  inputs: {n_found} found / {n_miss} missing  benchmarks: {nb}"
          f"  traces: {len(traces)}  synth modules: {len(synth)}")
    if size > 8 * 1024 * 1024:
        print("WARNING: output exceeds 8 MiB; lower the MAX_* caps in build_dashboard.py", file=sys.stderr)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 - never leave a half-written page behind a traceback exit code for missing inputs
        print(f"ERROR: dashboard build failed: {exc!r}", file=sys.stderr)
        sys.exit(1)
