# SILICAFLUX HBMCORE

A parameterised **HBM4-*style*** memory-controller subsystem for the SilicaFlux-HPC chip: SystemVerilog RTL (plus a generated Silica Flux `.sf` export), a behavioural DRAM model with an
independent timing checker, an independent Python reference model, cocotb / formal / mutation verification, DataFabric and DMA integration, benchmarks, a design-space sweep, synthesis
statistics, a dashboard and documentation.

> ## Status - read this first
> * **Simulation-grade engineering model. Not silicon-ready.** Passing every test in this repository does not make the controller usable with a real HBM4 stack.
> * **No JEDEC / HBM4 compliance is claimed.** No JEDEC specification, vendor datasheet or PHY interface document was available. Every timing profile is `HYPOTHETICAL_SIM`
>   (`configs/timing/profiles.json`, units: controller cycles, 1 cycle = 1 ns in the shipped profiles). The command set is an **abstract controller command set**, not a JEDEC command table.
>   No opcode, pin-level encoding or timing value was invented *and presented as standard*: `docs/STANDARDS_MATRIX.md` lists every assumption and its status (0 rows are `VERIFIED_*`),
>   `docs/MISSING_SPEC.md` lists what is missing.
> * **No DFI compliance either.** The PHY side is a clean adapter boundary (`docs/PHY_CONTRACT.md`) with a functional simulation backend (A) and an **unimplemented** vendor-PHY stub (B) that
>   says so (`backend_unimplemented_o`). Training / calibration are an external PHY service.
> * **All performance numbers are modelled, never measured**: RTL simulation against a hypothetical profile. `sim_ref` is calibrated so that 64 pseudo-channels x 32 B/cycle = 2048 GB/s by construction.
> * No PDK, OpenROAD or OpenSTA was available: synthesis results are technology-independent *proxies* (gate counts, logic levels), never ns / um^2 / mW.
> * Nothing was committed or pushed to GitHub; this tree is delivered as a zip.

## What is in here

| path | content |
|---|---|
| `rtl/` | 24 SystemVerilog files (~4.6 k lines): `sf_hbm_pkg`, `sf_hbm4_controller`, `sf_hbm_top` (controller + perf + CSR), `sf_hbm_stack_cluster`, `sf_hbm_channel`, `sf_hbm_pseudochannel`, `sf_hbm_req_queue`, `sf_hbm_addr_map`, `sf_hbm_bank_fsm`, `sf_hbm_scheduler`, `sf_hbm_timing`, `sf_hbm_command_encoder`, `sf_hbm_write_data`, `sf_hbm_read_return`, `sf_hbm_refresh`, `sf_hbm_power_state`, `sf_hbm_init`, `sf_hbm_phy_adapter`, `sf_hbm_ecc_ras`, `sf_hbm_perf`, `sf_hbm_csr`, `sf_hbm_rsp_arb`, `sf_hbm_cdc_fifo` (+ `sf_hbm_rst_sync`), generated `sf_hbm_profile_pkg` |
| `integration/` | DataFabric memory-node adapter (`sf_hbm_datafabric`), DMA adapter (`sf_hbm_dma_adapter`) against the real scratchpad controller, vendored NoC v2 contract (SHA-256 checked), TensorCore / VectorCore trace tools, generated `silicaflux_sf/*.sf` |
| `verification/` | `tests/` Verilator self-checking benches, `hbm4/hbm4_dram_model.sv` (independent timing checker), `bfm/`, `cocotb/`, `formal/` (SymbiYosys harnesses + mutants) |
| `python/` | independent reference model (address map, bank state, timing checker, scheduler, scoreboard, ECC, performance, trace checkers), 197 pytest tests, bandwidth calculator |
| `configs/` | timing profiles (JSON -> generated package) |
| `scripts/` | simulation / lint / regression / mutation / benchmark / synthesis / report / packaging scripts |
| `reports/` | machine-readable and human results (regression, benchmarks, synthesis, formal, cocotb, mutation, vector replay) |
| `dashboard/` | `index.html`: 16-view engineering dashboard built from the reports (no invented data: missing inputs show "no data") |
| `docs/` | architecture, scheduler, timing rules, address map, ordering, RAS, power, PHY contract, perf counters, CDC, DataFabric, standards matrix, audit, integration blockers, physical-design guidance, formal, module reference, real-silicon requirements |

## Quick start

Tools used for the shipped results: Verilator 5.048 (`/opt/vl548`; >= 5.020 works for the non-cocotb flows), Python 3, pytest, cocotb 2.x (needs Verilator >= 5.036), YoWASP Yosys / SymbiYosys + native Yosys (synthesis, formal), z3.
`make hbm-deps` reports what is present; a missing tool is reported as a dependency failure, never as a pass.

```bash
make hbm-deps               # which tools exist
make hbm-gen                # regenerate timing-profile package + standards matrix
make hbm-lint               # Verilator lint of the controller and the top
make hbm-channel-test       # single pseudo-channel: ACT/RD/WR/PRE/REF against the timing-aware DRAM model (all profiles x policies)
make hbm-timing-test        # legal / illegal command pairs for every timing rule
make hbm-refresh-test hbm-ecc-test
make hbm-csr-test           # sf_hbm_top: register file + perf counters through the register bus
make hbm-transaction-test   # 1/2/4/8-channel controller, DataFabric, DMA
make hbm-python-test        # independent Python model
make hbm-cocotb             # cocotb tests (address map, ECC, traffic + replay through the Python checker)
make hbm-formal             # SymbiYosys proofs + mutants   (15-25 minutes)
make hbm-mutation           # RTL mutants must be killed
make hbm-regression         # everything except the 32-channel build, writes reports/regression.{json,xml,md}
make hbm-regression-full    # + 32 channels / 64 pseudo-channels
make hbm-benchmark          # benchmarks A-L, scaling, design-space sweep (long)
make hbm-synthesis          # proxy synthesis statistics (long); make hbm-synthesis-report rebuilds SYNTH.md
make hbm-report hbm-dashboard
make hbm-zip                # dist/silicaflux-hbmcore.zip
```

First executable deliverable (the single-channel controller against the timing-aware model): `make hbm-channel-test`, or directly

```bash
./scripts/vsim.sh tb_pc_single && ./build/tb_pc_single/obj/Vtb_pc_single +TEST=all +PROFILE=1 +POLICY=1
```

## Architecture in one paragraph

One **pseudo-channel** is the replicated unit (`sf_hbm_pseudochannel`): request queue with dependency / age matrices -> scheduler (FCFS / FR-FCFS / bank-group-aware, QoS, deadline, batching, starvation override with
bank drain, page policies, maintenance arbitration) -> 16 counter-based bank FSMs + a cross-bank timing engine -> command encoder -> PHY adapter -> DRAM model; write-data staging, a read-return completion
sequencer (in-order responses, credits), a refresh debt engine with bounded postpone / pull-in, power states, a controller-side SECDED (256 + 10 bits) with fault injection. A channel has two pseudo-channels; a
cluster up to eight channels; `sf_hbm4_controller` adds the address map (linear / channel-interleave / bank-aware, optional bijective hash), same-ID order tracking, fence, error entries, response arbiters and the
init sequencer. `sf_hbm_top` wraps it with the performance counters and the CSR file. See `docs/ARCHITECTURE.md`, `docs/MODULES.md`.

## Key results (all MODELLED; hypothetical profile; details and all rows in `reports/BENCHMARKS.md`)

32 channels / 64 pseudo-channels, profile `sim_ref` (calibrated to a 2048 GB/s pin-rate figure by construction), channel-sliced ingress, zero DRAM-model violations in every result:

| workload | modelled bandwidth | note |
|---|---|---|
| sequential read / write (A, B) | 1812 / 1832 GB/s (88.5 % / 89.5 % of 2048) | row-hit 98 %, refresh included |
| alternating read/write (C) | 504 GB/s (24.6 %) | bus turnaround dominates |
| random granules (D, F) / random rows (H) | 301 / 310 / 301 GB/s (~15 %) | row-hit < 1 %; limited by row cycle, tRRD/tFAW; mean latency ~110 cycles, P99 ~430 |
| high-locality mixed (G) | 1137 GB/s (55.5 %) | 20 % writes |
| refresh cost (I) | 7.1 % measured vs 6.7 % analytic (tRFC/tREFI) | refresh-off run is a baseline only |
| single host port of `sf_hbm4_controller` | 31.7 GB/s (ceiling 32 at 1 GHz) | cannot feed 32 channels -> channel-sliced ingress is required |
| QoS under contention (2 channels, 8 sources) | RT mean latency 97.9 -> 68.3 cycles; best-effort streaming 72.8 -> 95.9 | the trade-off is visible; in the 64-PC run only PC0 is congested and QoS changes little |
| TensorCore GEMM tile loading (traffic model) | sustains 4,096 MAC/cycle at 86.6 % utilisation; at 32,768 MAC/cycle memory delivers 454 of the 2,048 GB/s needed (19.7 % utilisation) | not the TensorCore RTL |
| channel scaling 1 -> 32 | 47.8 GB/s per channel for short sequential runs (74.7 % of per-channel peak), linear | 32 channels 75.3 % |

Also in `reports/BENCHMARKS.md`: STREAM triad (L: ~390 GB/s, an array-placement bank-collision artefact, not a controller limit), the 55-point queue-depth / completion-depth / policy / mapping / page-policy / QoS / window / profile design-space sweep, and the
RTL replay of 8 VectorCore workloads (hash off and on) with an RTL-vs-Python scheduler comparison (`reports/vector_replay.md`).

Synthesis (proxy, no PDK): one pseudo-channel = 12.9 k flip-flops, ~177 k gate-equivalents, longest path 165 gate levels; 64 of them ~11.3 M GE / 827 k flops (`docs/PHYSICAL_DESIGN.md`). Scheduler select (114 levels) and SECDED (161 levels) are the two depth hotspots.

## Verification status of the last run (generated data: `reports/regression.md`, `reports/formal.json`, `reports/mutation_report.json`, `reports/cocotb.json`)

| what | result |
|---|---|
| regression (`scripts/regress.py --full`) | **74 entries: 74 PASS, 0 FAIL, 0 dependency failures** (lint / elaboration 13, channel 19, CSR 4, transaction 8, timing 4, refresh 3, ECC 1, DataFabric 4, DMA 4, CDC 6, Python 3, cocotb 1, formal 1, mutation 1, 32-channel 2) |
| honesty note on that run | two entries were first reported FAIL because of bugs in the *runner*, not in the design (a `mkdir` step without a success marker; the mutation entry matching its own "Assertion failed" kill messages). They were fixed and **re-run**; `regression.md` lists both re-runs under "merged re-runs". The same applies to a `policy` test expectation that did not account for close-page / timeout-page (fixed before the final run) |
| RTL mutation check | 15 injected bugs, **15 killed, 0 survivors** (`reports/mutation_report.json`) |
| formal (SymbiYosys, reduced-parameter models) | 59 tasks OK, 33/33 formal mutants killed; unbounded for `req_queue`, `bank_fsm`, `rsp_arb`, `refresh`, `cdc_fifo`, `timing`; `read_return` bounded only (`docs/FORMAL.md`) |
| independent Python model | 197 pytest tests pass; RTL command traces and transaction logs are re-checked by it (`python_trace_check_of_rtl_traces`, `python_scoreboard_on_rtl_transaction_log`) |
| cocotb | address map, ECC, per-pseudo-channel traffic + replay through the Python timing checker: all pass |
| DRAM-model timing checker | zero violations in every simulation of the regression and in all 101 benchmark results (results with violations are refused by the report generator) |
| not collected | functional / line coverage |

## What was found and fixed along the way (selection; the reasons why the tests exist)

* The independent DRAM model caught a write-data slot being reused before its data was delivered -> slot hold.
* A refresh issued into a powered-down DRAM -> refresh blocking / urgent wake; per-bank refresh infeasible on one profile -> explicit flag.
* Review of the first scheduler found that a stream of row hits could postpone a conflicting request for ever (`starve_limit` was useless); the first fix still failed on the strict profile because the hit stream
  re-arms tRTP; the final design adds a bank drain (`tb_pc_single` `starvation`, 3 mutants).
* Review found a CSR read-back mismatch (page policy), a lost sticky-error event, a 5-bit occupancy truncation, a DMA that ignored the 4 GiB window and counted failed chunks -> all fixed, covered by `tb_top_csr` / `tb_dma_spm`.
* A mid-run-reset check of the CDC FIFO found a stale-request race in the testbench (not in the FIFO); saturation of the performance counters needed narrow widths (generalised helper).

## Not done / limits (full list: `docs/REAL_SILICON_REQUIREMENTS.md`, `docs/INTEGRATION_BLOCKERS.md`, `docs/MISSING_SPEC.md`)

* No JEDEC HBM4 specification, vendor datasheet or licensed PHY interface was available: no compliance, no real timing values, no pin-level encodings, no PHY training.
* PHY backend B (vendor PHY) is an unimplemented stub. RowHammer / DRFM mitigation, partial-write read-modify-write with controller ECC, and DRAMsim3 / Ramulator cross-checks are **not** implemented / integrated.
* No functional or line coverage metric was collected. Formal proofs are on reduced-parameter models under stated assumptions; `read_return` is bounded only (`docs/FORMAL.md`).
* No PDK / STA / P&R: synthesis numbers are proxies; two combinational depth hotspots (scheduler select, SECDED chains) are identified but not yet pipelined (`docs/PHYSICAL_DESIGN.md`).
* Integration: the NoC address is 32 bit (a stack needs 36+ bits -> `ADDRHI` window register); the controller has one host port (<= 32 B/cycle): a 32-channel product needs a channel-sliced ingress; the compute-tile
  path does not compile from the existing tree and TensorCore has no operand-buffer RTL, so TensorCore / VectorCore appear as traffic models / replayed traces.

Layout, test inventory and the regression result of the last run: `reports/regression.md`.
