#!/usr/bin/env python3
"""Generate rtl/sf_hbm_profile_pkg.sv from configs/timing/profiles.json.

Also VALIDATES every profile. A profile that fails validation is rejected (non-zero exit) so that an
internally inconsistent timing set can never reach the RTL, the DRAM model or the Python model.

Validation rules (internal-consistency only; they do NOT make a profile standard-compliant):
  * every field present, integer, 1 <= value <= 65535 (burst >= 1, wl >= 1)
  * trc  >= tras + trp                                (row cycle covers active + precharge)
  * tras >= max(trcdrd, trcdwr)                       (a column command must fit inside the active window)
  * tccd_l >= tccd_s >= burst                         (back-to-back bursts cannot overlap on the data bus)
  * trrd_l >= trrd_s ;  tfaw >= 4*trrd_s - (trrd_s)   (four activates need at least 3 x tRRD_S; FAW not looser than RRD)
  * twtr_l >= twtr_s
  * trfc >= trfcpb ; trefi > trfc ; trefi >= 4*trfc/ (loose sanity: refresh must leave useful time)
  * rl >= 1, wl >= 1
"""
import json, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "configs" / "timing" / "profiles.json"
DST = ROOT / "rtl" / "sf_hbm_profile_pkg.sv"

FIELDS = ["trcdrd", "trcdwr", "trp", "tras", "trc", "tccd_s", "tccd_l", "trrd_s", "trrd_l", "tfaw",
          "twr", "twtr_s", "twtr_l", "trtp", "trfc", "trfcpb", "trefi", "rl", "wl", "burst",
          "tmrd", "txp", "txs", "max_postpone", "max_pullin"]

STATUS_CODE = {"HYPOTHETICAL_SIM": 0, "VERIFIED_STANDARD": 1, "VERIFIED_PHY_SPEC": 2}


NUM_BANKS = 16   # default geometry (rtl/sf_hbm_geom.svh): 4 bank groups x 4 banks


def pb_capable(p):
    """Per-bank refresh feasibility (ENGINEERING RULE, not a JEDEC rule).

    In per-bank mode one refresh is owed every trefi/NUM_BANKS cycles and each is a serial sequence
    HOLD -> (wait tRAS / write recovery) -> PRE -> tRP -> REF_PB. The worst-case sequence time must fit the interval
    or the refresh debt grows without bound:   trefi/NUM_BANKS >= max(tras, wl+burst+twr) + trp + 8.
    """
    interval = p["trefi"] // NUM_BANKS
    worst = max(p["tras"], p["wl"] + p["burst"] + p["twr"]) + p["trp"] + 8
    return interval >= worst


def validate(p):
    errs = []
    for f in FIELDS:
        if f not in p:
            errs.append(f"missing field {f}")
        elif not isinstance(p[f], int) or p[f] < 0 or p[f] > 65535:
            errs.append(f"field {f} must be an integer in [0,65535], got {p[f]!r}")
    if errs:
        return errs
    for f in ("burst", "wl", "rl", "tccd_s", "trrd_s", "trp", "tras"):
        if p[f] < 1:
            errs.append(f"{f} must be >= 1")
    if p["trc"] < p["tras"] + p["trp"]:
        errs.append("trc < tras + trp")
    if p["tras"] < max(p["trcdrd"], p["trcdwr"]):
        errs.append("tras < max(trcdrd, trcdwr)")
    if not (p["tccd_l"] >= p["tccd_s"] >= p["burst"]):
        errs.append("require tccd_l >= tccd_s >= burst")
    if p["trrd_l"] < p["trrd_s"]:
        errs.append("trrd_l < trrd_s")
    if p["tfaw"] < 3 * p["trrd_s"]:
        errs.append("tfaw < 3*trrd_s (four activates cannot fit)")
    if p["twtr_l"] < p["twtr_s"]:
        errs.append("twtr_l < twtr_s")
    if p["trfc"] < p["trfcpb"]:
        errs.append("trfc < trfcpb")
    if p["trefi"] <= p["trfc"]:
        errs.append("trefi <= trfc")
    if p["status"] not in STATUS_CODE:
        errs.append(f"unknown status {p['status']}")
    return errs


def main():
    data = json.loads(SRC.read_text())
    profs = data["profiles"]
    bad = False
    ids = set()
    for p in profs:
        e = validate(p)
        if p["id"] in ids:
            e.append("duplicate id")
        ids.add(p["id"])
        if e:
            bad = True
            print(f"PROFILE {p.get('name')} INVALID:", *e, sep="\n  - ", file=sys.stderr)
    if bad:
        sys.exit(1)

    n = max(p["id"] for p in profs) + 1
    out = []
    out.append("// =============================================================================")
    out.append("//  GENERATED FILE - DO NOT EDIT.  Source: configs/timing/profiles.json")
    out.append("//  Generator: scripts/gen_profiles.py (validates every profile before emitting)")
    out.append("//")
    out.append("//  ALL SHIPPED PROFILES ARE HYPOTHETICAL_SIM. They are not JEDEC / vendor values.")
    out.append("// =============================================================================")
    out.append("package sf_hbm_profile_pkg;")
    out.append("  import sf_hbm_pkg::*;")
    out.append(f"  localparam int unsigned HBM_NUM_PROFILES = {n};")
    out.append("  // status code: 0 HYPOTHETICAL_SIM, 1 VERIFIED_STANDARD, 2 VERIFIED_PHY_SPEC")
    out.append("  function automatic logic [1:0] hbm_profile_status(input logic [3:0] sel);")
    out.append("    case (sel)")
    for p in profs:
        out.append(f"      4'd{p['id']}: return 2'd{STATUS_CODE[p['status']]};   // {p['name']}")
    out.append("      default: return 2'd0;")
    out.append("    endcase")
    out.append("  endfunction")
    out.append("")
    out.append("  // per-bank refresh feasible for this profile? (rule in scripts/gen_profiles.py: trefi/16 >= max(tras, WR2PRE) + trp + 8)")
    out.append("  function automatic logic hbm_profile_pb_ok(input logic [3:0] sel);")
    out.append("    case (sel)")
    for p in profs:
        out.append(f"      4'd{p['id']}: return 1'b{1 if pb_capable(p) else 0};   // {p['name']}")
    out.append("      default: return 1'b0;")
    out.append("    endcase")
    out.append("  endfunction")
    out.append("")
    out.append("  // informational clock of the profile in MHz (1 cycle = 1000/clock_mhz ns); not used by any timing rule")
    out.append("  function automatic logic [15:0] hbm_profile_mhz(input logic [3:0] sel);")
    out.append("    case (sel)")
    for p in profs:
        out.append(f"      4'd{p['id']}: return 16'd{p['clock_mhz']};   // {p['name']}")
    out.append("      default: return 16'd0;")
    out.append("    endcase")
    out.append("  endfunction")
    out.append("")
    out.append("  function automatic hbm_timing_t hbm_profile(input logic [3:0] sel);")
    out.append("    hbm_timing_t t;")
    out.append("    t = '0;")
    out.append("    case (sel)")
    for p in profs:
        out.append(f"      4'd{p['id']}: begin   // {p['name']}  [{p['status']}]")
        for f in FIELDS:
            out.append(f"        t.{f} = 16'd{p[f]};")
        out.append("      end")
    out.append("      default: begin   // fall back to profile 0")
    p = profs[0]
    for f in FIELDS:
        out.append(f"        t.{f} = 16'd{p[f]};")
    out.append("      end")
    out.append("    endcase")
    out.append("    return t;")
    out.append("  endfunction")
    out.append("endpackage : sf_hbm_profile_pkg")
    DST.write_text("\n".join(out) + "\n")
    print(f"generated {DST.relative_to(ROOT)} ({len(profs)} profiles, all validated; per-bank refresh feasible: " + ", ".join(f"{p['name']}={pb_capable(p)}" for p in profs) + ")")


if __name__ == "__main__":
    main()
