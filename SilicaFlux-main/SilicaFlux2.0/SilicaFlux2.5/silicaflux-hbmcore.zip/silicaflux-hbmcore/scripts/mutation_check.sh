#!/usr/bin/env bash
# Mutation sanity check: each mutant injects ONE bug into a scratch copy of the RTL; the testbench MUST fail.
# A mutant that survives means the verification environment has a hole. Output: reports/mutation_report.json
set -uo pipefail
cd "$(dirname "$0")/.."
export VERILATOR_ROOT=${VERILATOR_ROOT:-/opt/vl548/usr/share/verilator}
V=${VERILATOR:-/opt/vl548/usr/bin/verilator}
W=build/mutants; rm -rf "$W"; mkdir -p "$W"
declare -a RES
run_mutant () {  # name file sed-expr tb extra-plusargs
  local name=$1 file=$2 expr=$3 tb=${4:-tb_pc_single} args=${5:-"+TEST=all +SEED=3 +PROFILE=0"}
  local d="$W/$name"; mkdir -p "$d/rtl"; cp rtl/*.sv rtl/*.svh "$d/rtl/"
  sed -i -E "$expr" "$d/rtl/$file"
  if cmp -s "rtl/$file" "$d/rtl/$file"; then echo "$name: MUTATION DID NOT APPLY"; RES+=("{\"mutant\":\"$name\",\"status\":\"not_applied\"}"); return; fi
  local RTL="$d/rtl/sf_hbm_pkg.sv $d/rtl/sf_hbm_profile_pkg.sv $(ls $d/rtl/sf_hbm*.sv | grep -v -e sf_hbm_pkg -e profile_pkg | tr '\n' ' ')"
  $V --binary --timing --assert -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-UNOPTFLAT -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC \
     -I"$d/rtl" --top-module $tb -Mdir "$d/obj" -o Vm -j 4 $RTL verification/hbm4/hbm4_dram_model.sv verification/tests/$tb.sv > "$d/build.log" 2>&1 \
     || { echo "$name: build failed"; RES+=("{\"mutant\":\"$name\",\"status\":\"build_failed\"}"); return; }
  local out; out=$(timeout 600 "$d/obj/Vm" $args 2>&1)
  if echo "$out" | grep -q "RESULT: PASS"; then echo "$name: SURVIVED  <-- verification hole"; RES+=("{\"mutant\":\"$name\",\"status\":\"SURVIVED\"}")
  else echo "$name: killed   ($(echo "$out" | grep -m1 -oE 'violated by|DATA MISMATCH|DRAIN TIMEOUT|write_data[a-z_]*|Assertion failed|FAIL' | head -1))"; RES+=("{\"mutant\":\"$name\",\"status\":\"killed\"}"); fi
}
run_mutant tRCDRD_short      sf_hbm_bank_fsm.sv   's/hbm_ld\(tp_i\.trcdrd\)/hbm_ld(tp_i.trcdrd - 16'"'"'d1)/'
run_mutant tRAS_short        sf_hbm_bank_fsm.sv   's/c_ras      <= hbm_ld\(tp_i\.tras\)/c_ras      <= hbm_ld(tp_i.tras - 16'"'"'d2)/'
run_mutant tRP_short         sf_hbm_bank_fsm.sv   's/c_rp       <= hbm_ld\(tp_i\.trp\)/c_rp       <= hbm_ld(tp_i.trp - 16'"'"'d1)/'
run_mutant tFAW_ignored      sf_hbm_timing.sv     's/faw_ok     = .*/faw_ok     = 1'"'"'b1;/'
run_mutant tCCD_L_as_S       sf_hbm_timing.sv     's/\? tp_i\.tccd_l : tp_i\.tccd_s/? tp_i.tccd_s : tp_i.tccd_s/'
run_mutant tWTR_L_ignored    sf_hbm_timing.sv     's/\(g == int'"'"'\(bg_i\)\) \? k_wtr_l : k_wtr_s/k_wtr_s/'
run_mutant raw_dependency_off sf_hbm_req_queue.sv 's/dep_q\[free_idx\]   <= conflict_vec;/dep_q[free_idx]   <= (push_txn_i.write ? conflict_vec : conflict_vec) \& {DEPTH{1'"'"'b0}};/'
run_mutant wdata_one_late    sf_hbm_write_data.sv 's/cyc_i \+ tp_i\.wl\[HBM_CYC_W-1:0\]/cyc_i + tp_i.wl[HBM_CYC_W-1:0] + hbm_cyc_t'"'"'(1)/'
run_mutant slot_hold_off     sf_hbm_req_queue.sv  's/!valid_q\[i\] && !hold_i\[i\]/!valid_q[i]/'
run_mutant read_data_swap    sf_hbm_read_return.sv 's/data_q\[rq_idx\[rq_rp\]\] <= rd_data_i;/data_q[rq_idx[rq_rp]] <= {rd_data_i[127:0], rd_data_i[255:128]};/'
run_mutant refresh_disabled  sf_hbm_refresh.sv    's/wire start    = !off_mode/wire start    = 1'"'"'b0 \&\& !off_mode/' tb_pc_single "+TEST=refresh +SEED=3 +PROFILE=0"
run_mutant pre_protect_off   sf_hbm_scheduler.sv  's/\(\(cfg_i\.policy == SCHED_FCFS\) \|\| !hit_pending\[b\] \|\| boost\[i\]\)/1'"'"'b1/' tb_pc_single "+TEST=policy +SEED=3 +PROFILE=0 +POLICY=1"
run_mutant starve_boost_off  sf_hbm_scheduler.sv  's/!hit_pending\[b\] \|\| boost\[i\]\)/!hit_pending[b])/' tb_pc_single "+TEST=starvation +SEED=3 +PROFILE=1 +POLICY=1"
run_mutant starve_never      sf_hbm_scheduler.sv  's/starve\[i\] = \(cfg_i\.starve_limit != 16.d0\) \&\& /starve[i] = 1'"'"'b0 \&\& /' tb_pc_single "+TEST=starvation +SEED=3 +PROFILE=1 +POLICY=1"
run_mutant starve_drain_off  sf_hbm_scheduler.sv  's/ \&\& !\(drain_bank\[b\] \&\& !boost\[i\]\)//' tb_pc_single "+TEST=starvation +SEED=3 +PROFILE=2 +POLICY=1"
printf '{"mutants":[%s]}\n' "$(IFS=,; echo "${RES[*]}")" > reports/mutation_report.json
echo "survivors: $(grep -o SURVIVED reports/mutation_report.json | wc -l)"
