#!/usr/bin/env python3
"""Generate docs/standards_matrix.json, docs/STANDARDS_MATRIX.md and docs/MISSING_SPEC.md.

SINGLE SOURCE: the FEATURES table below. Every row has a classification from the closed set
  VERIFIED_STANDARD  checked against the applicable official JEDEC text (JESD270-4 or later)
  VERIFIED_PHY_SPEC  checked against a licensed PHY / DFI interface document
  PUBLIC_REFERENCE   taken from public vendor / press material, NOT checked against the standard
  ENGINEERING_ASSUMPTION  a design decision of this project
  UNIMPLEMENTED      not implemented in this repository
  UNVERIFIED         implemented, but nothing available here confirms it matches the standard

NO ROW IS CLASSIFIED VERIFIED_STANDARD OR VERIFIED_PHY_SPEC: neither JESD270-4 nor a licensed PHY
specification was available while building this project. The generator REFUSES to emit if a row
claims either without a `source` document and revision (so a future claim must be documented).
"""
import json, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
CLASSES = ["VERIFIED_STANDARD", "VERIFIED_PHY_SPEC", "PUBLIC_REFERENCE", "ENGINEERING_ASSUMPTION",
           "UNIMPLEMENTED", "UNVERIFIED"]

# (id, area, requirement, class, implementation status / where, what is needed to close it, source)
F = []
def row(i, area, req, cls, impl, close, source=None):
    F.append(dict(id=i, area=area, requirement=req, classification=cls, implementation=impl,
                  needed_to_close=close, source=source))

# ------------------------------------------------------------------ architecture / geometry
row("ARCH-01", "geometry", "32 independent channels per HBM4 stack", "PUBLIC_REFERENCE",
    "parameter NUM_CHANNELS (1,2,4,8,32 simulated); rtl/sf_hbm4_controller.sv", "check against JESD270-4 channel organisation")
row("ARCH-02", "geometry", "2 pseudo-channels per channel, 32 DQ each (64 DQ per channel)", "PUBLIC_REFERENCE",
    "sf_hbm_channel (PCS=2), HBM_DQ_PER_PC=32", "check against JESD270-4")
row("ARCH-03", "geometry", "2048 aggregate DQ per stack (32 ch x 64 DQ)", "PUBLIC_REFERENCE",
    "reference configuration NCH=32; never modelled as one monolithic port", "check against JESD270-4")
row("ARCH-04", "geometry", "burst of 8 beats => 32 B access granule per pseudo-channel", "ENGINEERING_ASSUMPTION",
    "HBM_BEATS=8, HBM_GRAN_BYTES=32 (sf_hbm_pkg)", "JESD270-4 burst length / access granularity")
row("ARCH-05", "geometry", "4 bank groups x 4 banks, 32768 rows, 64 granule columns per bank", "ENGINEERING_ASSUMPTION",
    "rtl/sf_hbm_geom.svh (override with -D)", "JESD270-4 / vendor datasheet density-specific geometry")
row("ARCH-06", "geometry", "capacity of a stack (64 GiB at the default geometry)", "ENGINEERING_ASSUMPTION",
    "derived: 2^(OFF+COL+BA+BG+ROW+PC+CH+NS) bytes", "vendor datasheet capacity options")
row("ARCH-07", "geometry", "independent command scheduling per pseudo-channel", "ENGINEERING_ASSUMPTION",
    "sf_hbm_pseudochannel has its own scheduler; no shared command bus modelled", "does the real channel share a command bus between pseudo-channels? (PHY/standard)")
row("ARCH-08", "geometry", "single command per pseudo-channel per cycle (no separate row / column command bus)", "ENGINEERING_ASSUMPTION",
    "scheduler issues one command/cycle", "JESD270-4 command bus partitioning")
# ------------------------------------------------------------------ interface
row("IF-01", "interface", "abstract typed command interface (NOP/ACT/RD/WR/PRE/PREA/REF/MRS/PD/SR/RFM)", "ENGINEERING_ASSUMPTION",
    "hbm_cmd_e in sf_hbm_pkg; NOT a JEDEC command table", "real HBM4 command table")
row("IF-02", "interface", "pin-level HBM4 command / address encoding", "UNIMPLEMENTED",
    "sf_hbm_command_encoder: ENCODING!=0 is a build error by design", "JESD270-4 command truth tables + licensed PHY interface")
row("IF-03", "interface", "DFI 5.1-compatible controller/PHY interface", "UNIMPLEMENTED",
    "sf_hbm_phy_adapter BACKEND=1 is an explicit stub (backend_unimplemented_o)", "DFI 5.1 specification + PHY vendor integration guide")
row("IF-04", "interface", "simulation PHY (functional, fixed latencies, 1:1 clock)", "ENGINEERING_ASSUMPTION",
    "sf_hbm_phy_adapter BACKEND=0 -> hbm4_dram_model", "n/a (simulation only)")
row("IF-05", "interface", "PHY/controller clock-ratio and data-width conversion", "UNIMPLEMENTED",
    "1:1 only; async FIFO provided for host-side CDC (sf_hbm_cdc_fifo)", "PHY clock-ratio contract")
row("IF-06", "interface", "read data returns exactly RL cycles after the command, in command order, no tags", "ENGINEERING_ASSUMPTION",
    "sf_hbm_read_return checks it (rd_timing_err / timeout)", "PHY read-data return contract")
row("IF-07", "interface", "write data exactly WL cycles after the command", "ENGINEERING_ASSUMPTION",
    "sf_hbm_write_data", "PHY write-data timing contract")
row("IF-08", "interface", "write data mask (partial writes) supported by PHY/DRAM", "UNVERIFIED",
    "wmask passed through; partial writes rejected when controller ECC is on", "JESD270-4 write data masking / DM / DBI behaviour")
# ------------------------------------------------------------------ timing
row("TIM-01", "timing", "numeric values of tRCD, tRP, tRAS, tRC, tCCD, tRRD, tFAW, tWR, tWTR, tRTP, tRFC, tREFI, RL, WL, tMRD, tXP, tXS", "UNVERIFIED",
    "configs/timing/profiles.json: ALL profiles HYPOTHETICAL_SIM", "values for the selected speed grade from JESD270-4 / datasheet")
row("TIM-02", "timing", "set of timing CONSTRAINT CLASSES (S/L bank-group variants, tFAW, turnarounds, refresh, MRS, power exit)", "ENGINEERING_ASSUMPTION",
    "docs/TIMING_RULES.md (normative for this project)", "diff against the JESD270-4 constraint table; add missing classes (e.g. tRREFD, tPPD, tRDPDE)")
row("TIM-03", "timing", "derived turnaround formulas: RTW = RL+BL+2-WL, WTR = WL+BL+tWTR, WR2PRE = WL+BL+tWR", "ENGINEERING_ASSUMPTION",
    "sf_hbm_timing, sf_hbm_bank_fsm", "JESD270-4 definitions (the +2 bus-turnaround term in particular)")
row("TIM-04", "timing", "tCCD / tRRD short-vs-long bank-group distinction", "ENGINEERING_ASSUMPTION",
    "per-bank-group counters in sf_hbm_timing", "JESD270-4 bank-group architecture of HBM4")
# ------------------------------------------------------------------ refresh / reliability
row("REF-01", "refresh", "all-bank refresh with postponement (max_postpone) and pull-in (max_pullin)", "UNVERIFIED",
    "sf_hbm_refresh", "supported refresh modes and postpone/pull-in limits for HBM4")
row("REF-02", "refresh", "per-bank (same-bank) refresh", "UNVERIFIED",
    "sf_hbm_refresh REFMODE_PB", "whether / how HBM4 defines per-bank refresh")
row("REF-03", "refresh", "self-refresh and power-down states, entry/exit rules", "UNVERIFIED",
    "sf_hbm_power_state (abstract PDE/PDX/SRE/SRX)", "JESD270-4 power states and exit latencies")
row("REF-04", "refresh", "Directed Refresh Management / RFM (RowHammer mitigation)", "UNIMPLEMENTED",
    "HCMD_RFM reserved; python/benchmarks hammer traffic exists but no mitigation logic claims protection", "JESD270-4 DRFM definition + threat model + device behaviour")
row("REF-05", "refresh", "temperature-compensated refresh rate", "UNIMPLEMENTED", "none", "device temperature interface")
row("RAS-01", "ras", "controller-level SECDED over a 256-bit granule with 10 sideband check bits", "ENGINEERING_ASSUMPTION",
    "sf_hbm_ecc_ras; docs/RAS_CODE.md", "does the HBM4 PHY/DRAM interface provide a sideband for 10 bits per granule?")
row("RAS-02", "ras", "on-die DRAM ECC", "UNIMPLEMENTED", "only an event-counting input (ondie_event_i)", "device behaviour description")
row("RAS-03", "ras", "PHY / interface parity or CRC", "UNIMPLEMENTED", "only an event-counting input (phy_event_i)", "PHY CRC/parity definition")
row("RAS-04", "ras", "read-modify-write for partial writes with ECC", "UNIMPLEMENTED",
    "partial write with ECC -> HERR_POLICY", "implement RMW in the pseudo-channel")
# ------------------------------------------------------------------ init / training
row("INIT-01", "init", "controller-side bring-up sequencing (power-good, clock, PHY init, MRS, training, ready)", "ENGINEERING_ASSUMPTION",
    "sf_hbm_init", "JESD270-4 initialisation sequence + PHY bring-up document")
row("INIT-02", "init", "HBM4 mode-register map and mandatory MRS sequence", "UNIMPLEMENTED",
    "4 abstract MRS steps with placeholder operands", "JESD270-4 mode registers")
row("INIT-03", "init", "PHY training / calibration (eye search, VREF, delay tuning, impedance)", "UNIMPLEMENTED",
    "treated as an EXTERNAL PHY service (phy_init_start/done, train_start/done)", "licensed PHY with training firmware/RTL")
# ------------------------------------------------------------------ integration
row("SYS-01", "integration", "SilicaFlux DataFabric NoC v2 packet contract (noc_packet_t, v1)", "ENGINEERING_ASSUMPTION",
    "integration/datafabric/sf_hbm_datafabric.sv vendors the contract from silicaflux-datafabric-noc-v2", "keep in sync with SF_NOC_PKT_VERSION")
row("SYS-02", "integration", "32-bit SilicaFlux physical address addresses a 64 GiB stack", "ENGINEERING_ASSUMPTION",
    "address-extension register (high bits) in the DataFabric adapter; integration blocker documented", "SoC memory-map decision")
row("SYS-03", "integration", "CSR bus = existing rb_sel/rb_we/rb_addr/rb_wdata/rb_rdata/rb_err style", "ENGINEERING_ASSUMPTION",
    "sf_hbm_csr", "SoC bus decision (APB wrapper if required)")
# ------------------------------------------------------------------ physical
row("PHY-01", "physical", "TSV / microbump / base-die PHY, I/O electrical behaviour", "UNIMPLEMENTED",
    "out of scope for RTL; docs/REAL_SILICON_REQUIREMENTS.md", "licensed PHY + package + signoff")
row("PHY-02", "physical", "synthesis / timing numbers at a target node", "UNIMPLEMENTED",
    "only technology-independent Yosys statistics; no PDK, no OpenROAD/OpenSTA in the environment", "PDK + STA flow")


def validate():
    errs = []
    ids = set()
    for r in F:
        if r["classification"] not in CLASSES:
            errs.append(f"{r['id']}: bad class {r['classification']}")
        if r["id"] in ids:
            errs.append(f"{r['id']}: duplicate id")
        ids.add(r["id"])
        if r["classification"] in ("VERIFIED_STANDARD", "VERIFIED_PHY_SPEC") and not r["source"]:
            errs.append(f"{r['id']}: {r['classification']} requires a source document and revision")
    return errs


def main():
    errs = validate()
    if errs:
        print("\n".join(errs), file=sys.stderr)
        sys.exit(1)
    counts = {c: sum(1 for r in F if r["classification"] == c) for c in CLASSES}
    (ROOT / "docs" / "standards_matrix.json").write_text(json.dumps(
        {"project": "SILICAFLUX HBMCORE", "compliance_claim": "NONE - no row is VERIFIED_STANDARD or VERIFIED_PHY_SPEC",
         "classes": CLASSES, "counts": counts, "features": F}, indent=2) + "\n")

    md = ["# Standards conformance matrix (generated by scripts/gen_standards_matrix.py)", "",
          "**Compliance claim: none.** Neither JESD270-4 (or a later HBM4 revision), nor a licensed HBM4 PHY specification, nor a DFI specification",
          "was available to this project. Therefore **no requirement below is classified `VERIFIED_STANDARD` or `VERIFIED_PHY_SPEC`**, and nothing in",
          "this repository may be described as JEDEC-compliant, HBM4-compliant or DFI-compliant.", "",
          "| class | count |", "|---|---|"]
    for c in CLASSES:
        md.append(f"| {c} | {counts[c]} |")
    md += ["", "Classification meaning: `PUBLIC_REFERENCE` = public vendor/press figure, not checked against the standard; "
           "`ENGINEERING_ASSUMPTION` = this project's own design decision; `UNVERIFIED` = implemented but unconfirmed against the standard; "
           "`UNIMPLEMENTED` = not built.", ""]
    area = None
    for r in F:
        if r["area"] != area:
            area = r["area"]
            md += ["", f"## {area}", "", "| id | requirement | class | implementation | needed to close |", "|---|---|---|---|---|"]
        md.append(f"| {r['id']} | {r['requirement']} | `{r['classification']}` | {r['implementation']} | {r['needed_to_close']} |")
    (ROOT / "docs" / "STANDARDS_MATRIX.md").write_text("\n".join(md) + "\n")

    mm = ["# Register of missing specification details (generated)", "",
          "Everything here is information that real HBM4 silicon integration needs and that this repository does NOT have.",
          "Each item is exposed as a configurable requirement or a clearly labelled stub. **None has been guessed.**", "",
          "| id | missing detail | currently |", "|---|---|---|"]
    for r in F:
        if r["classification"] in ("UNIMPLEMENTED", "UNVERIFIED", "ENGINEERING_ASSUMPTION", "PUBLIC_REFERENCE"):
            mm.append(f"| {r['id']} | {r['needed_to_close']} | {r['classification']}: {r['implementation']} |")
    (ROOT / "docs" / "MISSING_SPEC.md").write_text("\n".join(mm) + "\n")
    print("generated docs/standards_matrix.json, STANDARDS_MATRIX.md, MISSING_SPEC.md:", counts)


if __name__ == "__main__":
    main()
