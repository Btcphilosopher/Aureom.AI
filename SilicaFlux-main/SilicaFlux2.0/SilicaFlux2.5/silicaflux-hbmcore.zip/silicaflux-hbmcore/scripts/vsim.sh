#!/usr/bin/env bash
# Build one Verilator testbench.   usage: scripts/vsim.sh <tb_top> [extra verilator args...]
# Artifacts: build/<tb_top>/obj/V<tb_top>  (run it with +PLUSARGS)
# Simulator: Verilator >= 5.020 (5.048 used for the shipped results; $VERILATOR overrides).
set -euo pipefail
cd "$(dirname "$0")/.."
export VERILATOR_ROOT=${VERILATOR_ROOT:-/opt/vl548/usr/share/verilator}
V=${VERILATOR:-/opt/vl548/usr/bin/verilator}
TB=$1; shift
OUT=build/$TB${TAG:+_$TAG}
RTL="rtl/sf_hbm_pkg.sv rtl/sf_hbm_profile_pkg.sv $(ls rtl/sf_hbm*.sv | grep -v -e sf_hbm_pkg -e profile_pkg | tr '\n' ' ')"
MODEL="verification/hbm4/hbm4_dram_model.sv"
EXTRA=""
if [ -n "${WITH_DF:-}" ]; then EXTRA="integration/datafabric/third_party/noc_v2/silicaflux_pkg.sv integration/datafabric/sf_hbm_datafabric.sv verification/bfm/hbm_mock_backend.sv -Iintegration/datafabric/third_party/noc_v2"; fi
if [ -n "${WITH_DMA:-}" ]; then EXTRA="$EXTRA integration/dma/sf_hbm_dma_adapter.sv integration/datafabric/third_party/noc_v2/scratchpad_memory_controller.sv"; fi
TBF=$(ls verification/tests/$TB.sv)
mkdir -p "$OUT"
$V --binary --timing --assert --x-assign unique --x-initial unique -Wno-fatal -Wno-lint -Wno-style \
   -Wno-TIMESCALEMOD -Wno-UNOPTFLAT -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -Wno-CASEINCOMPLETE \
   ${VOPT:-} -Irtl --top-module "$TB" -Mdir "$OUT/obj" -o "V$TB" -j ${JOBS:-4} "$@" \
   $RTL $EXTRA $MODEL $TBF > "$OUT/build.log" 2>&1 || { tail -40 "$OUT/build.log"; exit 1; }
echo "built $OUT/obj/V$TB"
