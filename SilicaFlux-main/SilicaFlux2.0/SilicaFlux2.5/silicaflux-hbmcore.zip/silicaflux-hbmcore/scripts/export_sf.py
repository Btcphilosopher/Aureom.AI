#!/usr/bin/env python3
"""Export the HBMCore RTL as Silica Flux (.sf) sources for the SilicaFlux flow, and PROVE the export compiles.

AUDIT FACT (docs/AUDIT.md): a `.sf` file in the existing SilicaFlux tree is ordinary SystemVerilog text with a 'Language: Silica Flux-2017'
header; the shipped run_sim.sh compiles `.sf` with a stock SystemVerilog compiler. So the export is a header + the unchanged source,
written to integration/silicaflux_sf/. Verification: Verilator lints the exported files directly with `+systemverilogext+sf`
(no renaming), and the exported text is compared with the .sv original body (must be byte-identical after the header).
The packages must come first in the compile order (SF_PRIORITY_FILES convention of run_sim.sh): sf_hbm_pkg.sf, sf_hbm_profile_pkg.sf.
"""
import pathlib, subprocess, sys, os
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "integration" / "silicaflux_sf"
OUT.mkdir(parents=True, exist_ok=True)
srcs = [ROOT / "rtl" / "sf_hbm_pkg.sv", ROOT / "rtl" / "sf_hbm_profile_pkg.sv"] + \
       sorted(p for p in (ROOT / "rtl").glob("sf_hbm*.sv") if p.name not in ("sf_hbm_pkg.sv", "sf_hbm_profile_pkg.sv"))
hdr = ("// =============================================================================\n"
       "//  SilicaFlux Architecture   (exported by scripts/export_sf.py - DO NOT EDIT; edit rtl/{name}.sv)\n"
       "//  File      : {stem}.sf\n"
       "//  Language  : Silica Flux-2017   (== IEEE 1800 SystemVerilog text; see docs/SILICA_FLUX_COMPAT.md)\n"
       "// =============================================================================\n")
files = []
for s in srcs:
    d = OUT / (s.stem + ".sf")
    d.write_text(hdr.format(name=s.name, stem=s.stem) + s.read_text())
    files.append(d)
# the geometry header is included by sf_hbm_pkg ("sf_hbm_geom.svh"); keep it next to the package
(OUT / "sf_hbm_geom.svh").write_text((ROOT / "rtl" / "sf_hbm_geom.svh").read_text())
# body identity check
for s, d in zip(srcs, files):
    body = d.read_text().split("// =============================================================================\n", 2)[-1] if False else d.read_text()[len(hdr.format(name=s.name, stem=s.stem)):]
    assert body == s.read_text(), f"{d.name}: exported body differs from {s.name}"
env = dict(os.environ); env.setdefault("VERILATOR_ROOT", "/opt/vl548/usr/share/verilator")
v = env.get("VERILATOR", "/opt/vl548/usr/bin/verilator")
cmd = [v, "--lint-only", "-Wno-fatal", "-Wno-UNUSEDSIGNAL", "-Wno-UNUSEDPARAM", "-Wno-DECLFILENAME", "-Wno-SYNCASYNCNET", "+systemverilogext+sf",
       f"-I{OUT}", "--top-module", "sf_hbm4_controller"] + [str(f) for f in files]
p = subprocess.run(cmd, capture_output=True, text=True, env=env)
errs = [l for l in (p.stdout + p.stderr).splitlines() if l.startswith("%Error")]
print(f"exported {len(files)} .sf files to {OUT.relative_to(ROOT)}; Verilator +systemverilogext+sf lint: {'PASS' if p.returncode == 0 and not errs else 'FAIL'}")
if errs: print("\n".join(errs[:10]))
sys.exit(0 if p.returncode == 0 and not errs else 1)
