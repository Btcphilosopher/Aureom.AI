#!/usr/bin/env python3
"""Technology-INDEPENDENT synthesis statistics for the HBMCore RTL.

FLOW   YoWASP yosys + yosys-slang (parses the SystemVerilog packages/structs)  ->  plain Verilog  ->  native Yosys + ABC,
       generic gate set {AND NAND OR NOR XOR XNOR MUX NOT + DFF}. Flattened per module.
OUTPUT reports/synth/<module>.json and reports/synth/SYNTH.md

WHAT THE NUMBERS ARE
  * cells / flip-flops / memory bits : exact counts of this generic netlist.
  * gate_equivalents                 : a ROUGH proxy (NAND/NOR 1, AND/OR 1.5, XOR/XNOR 2.5, MUX 2.5, NOT 0.5, DFF 4.5). Not um^2.
  * logic_levels                     : longest combinational path in gates (yosys `ltp -noff`) on the ABC-mapped generic netlist.
                                       NOT nanoseconds: no liberty library, no wire model, no STA.
WHAT THEY ARE NOT: no PDK, no OpenROAD/OpenSTA in this environment => no ns, MHz, um^2, power. These are PROXY results and say
nothing about an advanced-node target. The commercial HBM4 PHY is not part of this flow at all.
"""
import json, pathlib, re, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "reports" / "synth"
BUILD = ROOT / "build" / "synth"
OUT.mkdir(parents=True, exist_ok=True)
BUILD.mkdir(parents=True, exist_ok=True)
YW = "/tmp/venv_yw/bin/yowasp-yosys"
PKG = ["rtl/sf_hbm_pkg.sv", "rtl/sf_hbm_profile_pkg.sv"]

GE = {"$_NAND_": 1.0, "$_NOR_": 1.0, "$_AND_": 1.5, "$_OR_": 1.5, "$_XOR_": 2.5, "$_XNOR_": 2.5, "$_MUX_": 2.5, "$_NOT_": 0.5,
      "$_ANDNOT_": 1.5, "$_ORNOT_": 1.5, "$_AOI3_": 2.0, "$_OAI3_": 2.0}
DFF_GE = 4.5

# (label, top, extra sources, parameter overrides)
M = [
    ("bank_fsm", "sf_hbm_bank_fsm", [], {}),
    ("timing", "sf_hbm_timing", [], {}),
    ("req_queue_d16", "sf_hbm_req_queue", [], {"DEPTH": 16}),
    ("req_queue_d8", "sf_hbm_req_queue", [], {"DEPTH": 8}),
    ("req_queue_d32", "sf_hbm_req_queue", [], {"DEPTH": 32}),
    ("scheduler_d16", "sf_hbm_scheduler", [], {"DEPTH": 16}),
    ("scheduler_d8", "sf_hbm_scheduler", [], {"DEPTH": 8}),
    ("write_data", "sf_hbm_write_data", [], {"DEPTH": 16, "PEND_DEPTH": 16, "CPL_IDX_W": 3}),
    ("read_return", "sf_hbm_read_return", [], {"CPL_DEPTH": 8}),
    ("refresh", "sf_hbm_refresh", [], {}),
    ("power_state", "sf_hbm_power_state", [], {}),
    ("init", "sf_hbm_init", [], {}),
    ("ecc_ras", "sf_hbm_ecc_ras", [], {}),
    ("command_encoder", "sf_hbm_command_encoder", [], {}),
    ("phy_adapter", "sf_hbm_phy_adapter", [], {}),
    ("rsp_arb_n8", "sf_hbm_rsp_arb", [], {"N": 8}),
    ("addr_map_32ch", "sf_hbm_addr_map", [], {"NUM_STACKS": 1, "NUM_CHANNELS": 32, "PCS": 2}),
    ("csr", "sf_hbm_csr", [], {}),
    ("perf_n2", "sf_hbm_perf", [], {"N": 2, "CNT_W": 48, "PER_PC_EN": 1}),
    ("perf_n2_aggregate_only", "sf_hbm_perf", [], {"N": 2, "CNT_W": 48, "PER_PC_EN": 0}),
    ("cdc_fifo_w288_d8", "sf_hbm_cdc_fifo", [], {"WIDTH": 288, "DEPTH": 8}),
    ("pseudochannel", "sf_hbm_pseudochannel", [], {}),
    ("datafabric_adapter", "sf_hbm_datafabric", ["integration/datafabric/third_party/noc_v2/silicaflux_pkg.sv", "integration/datafabric/sf_hbm_datafabric.sv"], {"ROB_N": 16, "NTAG": 16}),
]


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def synth(label, top, extra, params):
    src = PKG + [f"rtl/{top}.sv"] if not extra else PKG + extra
    # modules with sub-instances need every rtl file; give them the whole directory
    allrtl = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "rtl").glob("sf_hbm*.sv") if "pkg" not in p.name)
    files = PKG + (extra if extra else []) + [f for f in allrtl if f not in src]
    if not extra:
        files = PKG + allrtl
    g = " ".join(f"-G {k}={v}" for k, v in params.items())
    inc = "-Irtl -Iintegration/datafabric/third_party/noc_v2"
    v = BUILD / f"{label}.v"
    t0 = time.time()
    p = run([YW, "-q", "-p", f"read_slang -j 1 --top {top} {g} {inc} {' '.join(files)}; hierarchy -check -top {top}; proc; flatten; opt_expr; opt_clean; memory_map; techmap; opt -fast; opt_clean; write_verilog -noattr {v}"], cwd=ROOT)
    if p.returncode != 0 or not v.exists():
        return dict(label=label, top=top, status="FRONTEND_FAILED", detail=(p.stdout + p.stderr)[-800:])
    stat = BUILD / f"{label}.stat"
    p2 = run(["yosys", "-q", "-p",
              f"read_verilog {v}; synth -top {top}; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX; opt_clean; tee -o {stat} stat; tee -o {stat}.ltp ltp -noff"], cwd=ROOT)
    if p2.returncode != 0 or not stat.exists():
        return dict(label=label, top=top, status="BACKEND_FAILED", detail=(p2.stdout + p2.stderr)[-800:])
    txt = stat.read_text()
    cells = {}
    for m in re.finditer(r"^\s+(\$_\w+_)\s+(\d+)\s*$", txt, re.M):
        cells[m.group(1)] = int(m.group(2))
    tot = re.search(r"Number of cells:\s+(\d+)", txt)
    mem_bits = re.search(r"Number of memory bits:\s+(\d+)", txt)
    ff = sum(c for k, c in cells.items() if "DFF" in k or "DLATCH" in k)
    logic = sum(c for k, c in cells.items() if not ("DFF" in k or "DLATCH" in k))
    ge = sum(GE.get(k, 1.5) * c for k, c in cells.items() if not ("DFF" in k or "DLATCH" in k)) + DFF_GE * ff
    lv = None
    lt = pathlib.Path(str(stat) + ".ltp")
    if lt.exists():
        m = re.search(r"length=(\d+)", lt.read_text())
        lv = int(m.group(1)) if m else None
    return dict(label=label, top=top, params=params, status="OK", cells_total=int(tot.group(1)) if tot else None, flip_flops=ff, logic_cells=logic,
                memory_bits=int(mem_bits.group(1)) if mem_bits else 0, gate_equivalents=round(ge), logic_levels=lv, cell_breakdown=cells,
                seconds=round(time.time() - t0, 1), flow="yowasp-yosys(slang)->verilog->yosys(abc generic)",
                note="technology-independent proxy; no PDK, no STA, no ns/um2")


# Flattened synthesis cost grows with the number of pseudo-channels (one pseudo-channel alone takes ~13 minutes in this environment),
# so the multi-channel instances are OPT-IN (--big) and docs/PHYSICAL_DESIGN.md composes their size from the measured pieces instead.
BIG = [
    ("channel_2pc", "sf_hbm_channel", [], {}),
    ("stack_cluster_4ch", "sf_hbm_stack_cluster", [], {"NCH": 4}),
    ("controller_4ch", "sf_hbm4_controller", [], {"NUM_CHANNELS": 4, "CH_PER_CLUSTER": 2}),
]


def write_report():
    res = []
    for label, top, extra, params in M + BIG:
        f = OUT / f"{label}.json"
        if f.exists():
            res.append(json.loads(f.read_text()))
    md = ["# Synthesis statistics (generated by scripts/synth.py --report)", "",
          "**Technology-independent proxy results. NOT area (um^2), NOT timing (ns/MHz), NOT power.** No PDK, no OpenROAD, no OpenSTA are available in the build environment.",
          "Flow: YoWASP Yosys + yosys-slang (front end) -> Verilog -> native Yosys + ABC with a generic gate set. `logic_levels` = longest combinational path in gates.",
          "`gate_equivalents` weights: NAND/NOR 1, AND/OR 1.5, XOR/XNOR 2.5, MUX 2.5, NOT 0.5, DFF 4.5 (rough). A target-node result would differ.",
          "Each module is flattened and synthesized alone with the parameters shown; a module is NOT the sum of its children in this table "
          "(optimisation across the hierarchy changes the numbers slightly). Modules with no entry were not run (see the notes below the table).", "",
          "| module | params | flip-flops | logic cells | ~gate-equiv | logic levels | status |", "|---|---|---|---|---|---|---|"]
    for r in res:
        if r["status"] == "OK":
            note = " (pass-through at CMD_LAT = RD_LAT = 0: wires only)" if r["label"] == "phy_adapter" else ""
            md.append(f"| {r['label']}{note} | {r['params'] or ''} | {r['flip_flops']:,} | {r['logic_cells']:,} | {r['gate_equivalents']:,} | {r['logic_levels']} | OK |")
        else:
            md.append(f"| {r['label']} | | | | | | {r['status']}: {r.get('detail', '')[:200]} |")
    ran = {r["label"] for r in res}
    missing = [l for l, *_ in M + BIG if l not in ran]
    if missing:
        md += ["", "Not run: " + ", ".join(missing) + ".  (Multi-channel instances need hours of flattened synthesis in this environment; their size is composed in docs/PHYSICAL_DESIGN.md from the measured pseudo-channel.)"]
    (OUT / "SYNTH.md").write_text("\n".join(md) + "\n")
    return 0


def main():
    if "--report" in sys.argv:
        return write_report()
    big = "--big" in sys.argv
    only = {a for a in sys.argv[1:] if not a.startswith("--")}
    res = []
    for label, top, extra, params in (M + BIG if (big or only) else M):
        if only and label not in only:
            continue
        r = synth(label, top, extra, params)
        (OUT / f"{label}.json").write_text(json.dumps(r, indent=1))
        res.append(r)
        if r["status"] == "OK":
            print(f"{label:26s} FF={r['flip_flops']:>7,} logic={r['logic_cells']:>8,} GE~{r['gate_equivalents']:>9,} levels={r['logic_levels']} mem_bits={r['memory_bits']} ({r['seconds']}s)", flush=True)
        else:
            print(f"{label:26s} {r['status']}: {r.get('detail','')[-200:]}", flush=True)
    if not only:
        write_report()
    return 0 if all(r["status"] == "OK" for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
