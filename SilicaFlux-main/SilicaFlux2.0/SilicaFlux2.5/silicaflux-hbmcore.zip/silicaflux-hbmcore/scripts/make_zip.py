#!/usr/bin/env python3
"""Package hbmcore/ into dist/silicaflux-hbmcore.zip (+ MANIFEST.sha256 inside the archive).
Nothing is committed or pushed; the archive is an ordinary file. Build products (build/, dist/, caches) are excluded; sources,
reports, docs, traces, dashboard and scripts are included so that `make hbm-regression` can be re-run from the unpacked tree."""
import hashlib, os, pathlib, sys, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "dist" / "silicaflux-hbmcore.zip"
TOP = "silicaflux-hbmcore"
SKIP_DIRS = {"build", "dist", "__pycache__", ".pytest_cache", ".git", ".mypy_cache", "sim_build", "obj_dir"}
SKIP_EXT = {".pyc", ".pyo", ".o", ".a", ".so", ".zip", ".vcd", ".fst", ".log"}
MAX_BYTES = 40 * 1024 * 1024


def main():
    OUT.parent.mkdir(exist_ok=True)
    files = []
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = sorted(d for d in dns if d not in SKIP_DIRS)
        for fn in sorted(fns):
            p = pathlib.Path(dp) / fn
            if p.suffix in SKIP_EXT or fn.endswith("~"):
                continue
            if p.stat().st_size > MAX_BYTES:
                print(f"skip (> {MAX_BYTES >> 20} MiB): {p.relative_to(ROOT)}")
                continue
            files.append(p)
    manifest = []
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files:
            rel = p.relative_to(ROOT).as_posix()
            data = p.read_bytes()
            manifest.append(f"{hashlib.sha256(data).hexdigest()}  {rel}")
            zi = zipfile.ZipInfo(f"{TOP}/{rel}", date_time=(2026, 1, 1, 0, 0, 0))
            zi.external_attr = (0o755 if os.access(p, os.X_OK) else 0o644) << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, data)
        mf = "\n".join(manifest) + "\n"
        z.writestr(f"{TOP}/MANIFEST.sha256", mf)
    with zipfile.ZipFile(OUT) as z:
        bad = z.testzip()
    print(f"wrote {OUT.relative_to(ROOT)}: {len(files)} files + MANIFEST.sha256, {OUT.stat().st_size / 1e6:.1f} MB, integrity {'OK' if bad is None else 'BAD: ' + bad}")
    return 0 if bad is None else 1


if __name__ == "__main__":
    sys.exit(main())
