#!/usr/bin/env bash
# Technology-independent synthesis statistics -> reports/synth/ . Needs yowasp-yosys (slang front end) and native yosys+abc.
cd "$(dirname "$0")/.."
for t in /tmp/venv_yw/bin/yowasp-yosys yosys; do command -v $t >/dev/null 2>&1 || [ -x $t ] || { echo "DEPENDENCY MISSING: $t"; exit 2; }; done
python3 scripts/synth.py "$@"
