"""Timing-rule tests: hand-computed legal / illegal command traces.

All expected values are derived by hand from docs/TIMING_RULES.md and the numbers
of configs/timing/profiles.json (HYPOTHETICAL_SIM profiles).

Profile 0 (sim_fast):
  trcdrd 4, trcdwr 3, trp 4, tras 9, trc 13, tccd_s 1, tccd_l 2, trrd_s 2, trrd_l 3,
  tfaw 10, twr 5, twtr_s 2, twtr_l 4, trtp 2, trfc 24, trfcpb 12, trefi 240,
  rl 6, wl 3, burst 1, tmrd 4, txp 4, txs 30, max_postpone 3
  RTW = max(1, 6+1+2-3) = 6   WTR_S = 3+1+2 = 6   WTR_L = 3+1+4 = 8   WR2PRE = 3+1+5 = 9
  refresh bound = (3+1)*240 + 24 + 4*13 = 960 + 24 + 52 = 1036
Profile 2 (sim_strict):
  trcdrd 20, trcdwr 16, trp 18, tras 44, trc 62, tccd_s 2, tccd_l 4, trrd_s 4, trrd_l 6,
  tfaw 28, twr 20, twtr_s 6, twtr_l 12, trtp 8, trfc 350, trfcpb 180, trefi 1950,
  rl 24, wl 10, burst 2, tmrd 10, txp 10, txs 360, max_postpone 2
  RTW = 24+2+2-10 = 18   WTR_S = 10+2+6 = 18   WTR_L = 10+2+12 = 24   WR2PRE = 10+2+20 = 32
  refresh bound = 3*1950 + 350 + 4*62 = 5850 + 350 + 248 = 6448
"""

from __future__ import annotations

import json
from typing import Any

import pytest

from hbm4.commands import (
    ACT, MRS, PDE, PDX, PRE, PREA, RD, REF_AB, REF_PB, RFM, SRE, SRX, WR,
)
from hbm4.timing import Profile, ProfileError, TimingChecker, default_profiles_path, load_profiles

PROFILES = load_profiles()
P0 = PROFILES[0]
P1 = PROFILES[1]
P2 = PROFILES[2]

Ev = tuple


def act(c: int, bg: int = 0, ba: int = 0, row: int = 5, pc: int = 0) -> Ev:
    return (c, pc, ACT, bg, ba, row, 0)


def rd(c: int, bg: int = 0, ba: int = 0, row: int = 5, col: int = 0, pc: int = 0) -> Ev:
    return (c, pc, RD, bg, ba, row, col)


def wr(c: int, bg: int = 0, ba: int = 0, row: int = 5, col: int = 0, pc: int = 0) -> Ev:
    return (c, pc, WR, bg, ba, row, col)


def pre(c: int, bg: int = 0, ba: int = 0, pc: int = 0) -> Ev:
    return (c, pc, PRE, bg, ba, 0, 0)


def cmd(c: int, code: int, bg: int = 0, ba: int = 0, pc: int = 0) -> Ev:
    return (c, pc, code, bg, ba, 0, 0)


def W(c: int, pc: int = 0) -> Ev:
    return ("W", c, pc)


def run(profile: Profile, events: list[Ev], end: int | None = None, **kw: Any) -> TimingChecker:
    chk = TimingChecker(profile, **kw)
    for ev in events:
        if ev[0] == "W":
            chk.feed_wdata(ev[1], ev[2])
        else:
            chk.feed(*ev)
    chk.finish(end)
    return chk


def rules(profile: Profile, events: list[Ev], end: int | None = None, **kw: Any) -> set[str]:
    return run(profile, events, end, **kw).rules()


# ---------------------------------------------------------------------------
# Profiles
# ---------------------------------------------------------------------------

def test_profiles_load_and_status() -> None:
    assert sorted(PROFILES) == [0, 1, 2]
    assert [p.name for p in PROFILES.values()] == ["sim_fast", "sim_ref", "sim_strict"]
    for p in PROFILES.values():
        assert p.status == "HYPOTHETICAL_SIM"
        assert p.clock_mhz == 1000


@pytest.mark.parametrize(
    "prof, rtw, wtr_s, wtr_l, wr2pre, deadline",
    [
        # P0: RTW 6+1+2-3 = 6 ; WTR_S 3+1+2 = 6 ; WTR_L 3+1+4 = 8 ; WR2PRE 3+1+5 = 9 ; 4*240+24+52
        (P0, 6, 6, 8, 9, 1036),
        # P1: RTW 20+1+2-8 = 15 ; WTR_S 8+1+4 = 13 ; WTR_L 8+1+8 = 17 ; WR2PRE 8+1+16 = 25
        #     deadline 5*3900 + 260 + 4*48 = 19500 + 260 + 192 = 19952
        (P1, 15, 13, 17, 25, 19952),
        # P2: RTW 24+2+2-10 = 18 ; WTR_S 10+2+6 = 18 ; WTR_L 10+2+12 = 24 ; WR2PRE 10+2+20 = 32
        #     deadline 3*1950 + 350 + 4*62 = 5850 + 350 + 248 = 6448
        (P2, 18, 18, 24, 32, 6448),
    ],
)
def test_derived_values(prof: Profile, rtw: int, wtr_s: int, wtr_l: int, wr2pre: int, deadline: int) -> None:
    assert (prof.RTW, prof.WTR_S, prof.WTR_L, prof.WR2PRE) == (rtw, wtr_s, wtr_l, wr2pre)
    assert prof.refresh_deadline == deadline


def test_rtw_clamps_at_one() -> None:
    p = Profile(**{**P0.__dict__, "rl": 1, "wl": 20})  # 1 + 1 + 2 - 20 < 1
    assert p.RTW == 1


def test_profile_loader_rejects_missing_field(tmp_path) -> None:
    with open(default_profiles_path(), encoding="utf-8") as fh:
        doc = json.load(fh)
    del doc["profiles"][0]["trfc"]
    f = tmp_path / "bad.json"
    f.write_text(json.dumps(doc))
    with pytest.raises(ProfileError):
        load_profiles(f)


def test_checker_carries_status() -> None:
    chk = TimingChecker(P0)
    assert chk.status == "HYPOTHETICAL_SIM"
    assert "HYPOTHETICAL_SIM" in chk.header() and "NOT" in chk.header()


# ---------------------------------------------------------------------------
# A fully legal trace touching every command class (P0) -- must be clean
# ---------------------------------------------------------------------------

def test_legal_trace_all_commands_clean() -> None:
    ev: list[Ev] = [
        act(0, 0, 0, 5),                      # ACT g0
        act(2, 1, 0, 6),                      # ACT g1: 2-0 >= trrd_s 2
        rd(4, 0, 0, 5, 1),                    # 4-0 >= trcdrd 4
        rd(6, 1, 0, 6, 1),                    # 6-2 = 4 >= trcdrd; 6-4 >= tccd_s 1
        wr(12, 0, 0, 5, 2), W(15),            # 12-6 = 6 >= RTW 6 ; data at 12+wl 3 = 15
        rd(18, 1, 0, 6, 2),                   # 18-12 = 6 >= WTR_S 6 ; 18-6 >= tccd_s
        rd(20, 0, 0, 5, 3),                   # 20-12 = 8 >= WTR_L 8
        pre(22, 0, 0),                        # tras ok; 22-20 = 2 >= trtp 2 ; 22-12 = 10 >= WR2PRE 9
        pre(23, 1, 0),                        # 23-18 = 5 >= trtp ; tras 23-2
        cmd(27, REF_AB),                      # banks closed; 27-22 = 5, 27-23 = 4 >= trp 4
        act(51, 0, 0, 7),                     # 51 >= ref_busy_until = 27 + 24
        pre(60, 0, 0),                        # 60-51 = 9 >= tras 9
        cmd(64, MRS),                         # 64-60 = 4 >= trp
        cmd(68, PDE),                         # 68-64 = 4 >= tmrd 4
        cmd(70, PDX),
        cmd(74, SRE),                         # 74-70 = 4 >= txp 4
        cmd(100, SRX),
        act(130, 0, 0, 8),                    # 130-100 = 30 >= txs 30
        cmd(131, RFM),                        # no RFM rule
        cmd(140, REF_PB, 2, 0),               # bank (2,0) never opened
    ]
    chk = run(P0, ev)
    assert chk.violations == []
    assert chk.clean


# ---------------------------------------------------------------------------
# One illegal trace per timing rule (and the legal boundary just after it)
# ---------------------------------------------------------------------------

def test_tRCDRD() -> None:
    # ACT@10, RD@13: 13-10 = 3 < trcdrd 4 ; RD@14 legal (4 >= 4)
    assert rules(P0, [act(10), rd(13)]) == {"tRCDRD"}
    assert rules(P0, [act(10), rd(14)]) == set()


def test_tRCDWR() -> None:
    # ACT@10, WR@12: 2 < trcdwr 3 ; WR@13 legal ; data at 13 + wl 3 = 16 / 12 + 3 = 15
    assert rules(P0, [act(10), wr(12), W(15)]) == {"tRCDWR"}
    assert rules(P0, [act(10), wr(13), W(16)]) == set()


def test_tRP() -> None:
    # ACT@0, PRE@20, ACT@22: 22-20 = 2 < trp 4 (tRC 22 >= 13 fine)
    assert rules(P0, [act(0), pre(20), act(22)]) == {"tRP"}
    assert rules(P0, [act(0), pre(20), act(24)]) == set()


def test_tRC() -> None:
    # ACT@0, PRE@9 (tras 9 ok), ACT@12: 12-0 = 12 < trc 13.  Note trc == tras + trp in every
    # profile, so a tRC violation always comes with a tRP (or tRAS) violation.
    assert rules(P0, [act(0), pre(9), act(12)]) == {"tRC", "tRP"}
    assert rules(P0, [act(0), pre(9), act(13)]) == set()  # 13-0 = 13 >= trc, 13-9 = 4 >= trp


def test_tRAS() -> None:
    # ACT@0, PRE@8: 8 < tras 9 ; PRE@9 legal
    assert rules(P0, [act(0), pre(8)]) == {"tRAS"}
    assert rules(P0, [act(0), pre(9)]) == set()


def test_tRRD_S() -> None:
    # ACT g0@0, ACT g1@1: 1 < trrd_s 2 ; @2 legal
    assert rules(P0, [act(0, 0, 0), act(1, 1, 0)]) == {"tRRD_S"}
    assert rules(P0, [act(0, 0, 0), act(2, 1, 0)]) == set()


def test_tRRD_L() -> None:
    # ACT (g0,b0)@0, ACT (g0,b1)@2: 2 < trrd_l 3 ; @3 legal
    assert rules(P0, [act(0, 0, 0), act(2, 0, 1)]) == {"tRRD_L"}
    assert rules(P0, [act(0, 0, 0), act(3, 0, 1)]) == set()


def test_tFAW() -> None:
    # four ACTs in distinct groups at 0,2,4,6 (gaps 2 = trrd_s); 5th ACT (g0,b1):
    #   vs same group g0@0: 9 >= trrd_l 3 ; vs g3@6: 3 >= 2 ; 4th most recent ACT = @0 -> 9 < tfaw 10
    four = [act(0, 0, 0), act(2, 1, 0), act(4, 2, 0), act(6, 3, 0)]
    assert rules(P0, four + [act(9, 0, 1)]) == {"tFAW"}
    assert rules(P0, four + [act(10, 0, 1)]) == set()


def test_tCCD_S() -> None:
    # P2 (tccd_s 2): ACT(g0)@0, ACT(g1)@4 (trrd_s 4); RD g0@24 (24 >= trcdrd 20),
    #   RD g1@25: 25-4 = 21 >= 20, but 25-24 = 1 < tccd_s 2 ; @26 legal
    base = [act(0, 0, 0), act(4, 1, 0), rd(24, 0, 0)]
    assert rules(P2, base + [rd(25, 1, 0)]) == {"tCCD_S"}
    assert rules(P2, base + [rd(26, 1, 0)]) == set()


def test_tCCD_L() -> None:
    # P2 (tccd_l 4): ACT(g0,b0)@0, ACT(g0,b1)@6 (trrd_l 6); RD b0@26,
    #   RD b1@28: 28-6 = 22 >= 20, 28-26 = 2 < tccd_l 4 ; @30 legal
    base = [act(0, 0, 0), act(6, 0, 1), rd(26, 0, 0)]
    assert rules(P2, base + [rd(28, 0, 1)]) == {"tCCD_L"}
    assert rules(P2, base + [rd(30, 0, 1)]) == set()


def test_tCCD_applies_to_wr_wr_too() -> None:
    # P2: WR g0@20 (20 >= trcdwr 16), WR g1@21 (21-4 = 17 >= 16): 21-20 = 1 < tccd_s 2
    ev = [act(0, 0, 0), act(4, 1, 0), wr(20, 0, 0), W(30), wr(21, 1, 0), W(31)]
    assert rules(P2, ev) == {"tCCD_S"}


def test_tWTR_S() -> None:
    # P2: WTR_S = 10+2+6 = 18. WR g0@20 (data @30); RD g1@37: 37-20 = 17 < 18 ; @38 legal
    #   (RD g1: 37-4 = 33 >= trcdrd 20 ; 37-20 >= tccd_s 2)
    base = [act(0, 0, 0), act(4, 1, 0), wr(20, 0, 0), W(30)]
    assert rules(P2, base + [rd(37, 1, 0)]) == {"tWTR_S"}
    assert rules(P2, base + [rd(38, 1, 0)]) == set()


def test_tWTR_L() -> None:
    # P2: WTR_L = 10+2+12 = 24. WR (g0,b0)@20; RD (g0,b1)@43: 23 < 24 ; @44 legal
    #   (act b1 @6 -> 43-6 = 37 >= 20 ; tccd_l 23 >= 4)
    base = [act(0, 0, 0), act(6, 0, 1), wr(20, 0, 0), W(30)]
    assert rules(P2, base + [rd(43, 0, 1)]) == {"tWTR_L"}
    assert rules(P2, base + [rd(44, 0, 1)]) == set()


def test_tRTW() -> None:
    # P2: RTW = 24+2+2-10 = 18. RD@20 ; WR@37: 17 < 18 ; WR@38 legal (data at 38+10 = 48)
    base = [act(0, 0, 0), rd(20, 0, 0)]
    assert rules(P2, base + [wr(37, 0, 0), W(47)]) == {"tRTW"}
    assert rules(P2, base + [wr(38, 0, 0), W(48)]) == set()


def test_tRTW_is_any_group() -> None:
    # RD in g1, WR in g0 17 cycles later: "last_RD(any group)"
    base = [act(0, 0, 0), act(4, 1, 0), rd(24, 1, 0)]
    assert rules(P2, base + [wr(41, 0, 0), W(51)]) == {"tRTW"}  # 41-24 = 17 < 18
    assert rules(P2, base + [wr(42, 0, 0), W(52)]) == set()


def test_tRTP() -> None:
    # P2: trtp 8. ACT@0, RD@40, PRE@44: tras 44 >= 44 ok ; 44-40 = 4 < 8 ; PRE@48 legal
    base = [act(0, 0, 0), rd(40, 0, 0)]
    assert rules(P2, base + [pre(44)]) == {"tRTP"}
    assert rules(P2, base + [pre(48)]) == set()


def test_tWR_write_recovery() -> None:
    # P2: WR2PRE = 32. ACT@0, WR@20, PRE@50: tras ok ; 50-20 = 30 < 32 ; PRE@52 legal
    base = [act(0, 0, 0), wr(20, 0, 0), W(30)]
    assert rules(P2, base + [pre(50)]) == {"tWR"}
    assert rules(P2, base + [pre(52)]) == set()


def test_tRFC_all_bank() -> None:
    # REF_AB@100 -> ref_busy_until = 124. ACT@123 violates ; ACT@124 legal
    assert rules(P0, [cmd(100, REF_AB), act(123)]) == {"tRFC"}
    assert rules(P0, [cmd(100, REF_AB), act(124)]) == set()
    # a second REF_AB, an MRS, PDE and SRE inside the window also violate rule 2 / preconditions
    for c in (REF_AB, MRS, PDE, SRE):
        assert rules(P0, [cmd(100, REF_AB), cmd(110, c)]) == {"tRFC"}, c


def test_tRFC_pb() -> None:
    # REF_PB(0,0)@100 -> bank_ref_until(0,0) = 112
    assert rules(P0, [cmd(100, REF_PB), act(111)]) == {"tRFCpb"}
    assert rules(P0, [cmd(100, REF_PB), act(112)]) == set()
    assert rules(P0, [cmd(100, REF_PB), act(101, 1, 0)]) == set()  # other bank is not blocked
    assert rules(P0, [cmd(100, REF_PB), cmd(105, REF_PB)]) == {"tRFCpb"}  # same bank again


def test_tMRD() -> None:
    # MRS@100: no command for tmrd 4 cycles
    assert rules(P0, [cmd(100, MRS), act(103)]) == {"tMRD"}
    assert rules(P0, [cmd(100, MRS), act(104)]) == set()
    assert rules(P0, [cmd(100, MRS), cmd(102, MRS)]) == {"tMRD"}


def test_tXP() -> None:
    # PDE@100, PDX@101, then no command for txp 4: ACT@104 (3) violates ; ACT@105 legal
    assert rules(P0, [cmd(100, PDE), cmd(101, PDX), act(104)]) == {"tXP_tXS"}
    assert rules(P0, [cmd(100, PDE), cmd(101, PDX), act(105)]) == set()


def test_tXS() -> None:
    # SRE@100, SRX@200, txs 30: ACT@229 (29) violates ; ACT@230 legal
    assert rules(P0, [cmd(100, SRE), cmd(200, SRX), act(229)]) == {"tXP_tXS"}
    assert rules(P0, [cmd(100, SRE), cmd(200, SRX), act(230)]) == set()


def test_col_to_closed_bank() -> None:
    assert rules(P0, [rd(10)]) == {"col_to_closed_bank"}
    assert rules(P0, [wr(10), W(13)]) == {"col_to_closed_bank"}
    # after a legal PRE the bank is closed again
    assert rules(P0, [act(0), pre(9), rd(20)]) == {"col_to_closed_bank"}


def test_col_to_wrong_row() -> None:
    assert rules(P0, [act(0, row=5), rd(4, row=6)]) == {"col_to_wrong_row"}
    assert rules(P0, [act(0, row=5), rd(4, row=5)]) == set()


def test_ACT_to_open_bank() -> None:
    # ACT row5@0, ACT row6@20 same bank without PRE (tRC 20 >= 13 ok)
    assert rules(P0, [act(0, row=5), act(20, row=6)]) == {"ACT_to_open_bank"}


def test_REF_with_open_bank() -> None:
    assert rules(P0, [act(0), cmd(20, REF_AB)]) == {"REF_with_open_bank"}
    assert rules(P0, [act(0), cmd(20, REF_PB, 0, 0)]) == {"REF_with_open_bank"}
    assert rules(P0, [act(0), cmd(20, REF_PB, 1, 0)]) == set()  # a different, closed bank


def test_MRS_and_low_power_entry_with_open_bank() -> None:
    assert rules(P0, [act(0), cmd(20, MRS)]) == {"MRS_with_open_bank"}
    assert rules(P0, [act(0), cmd(20, PDE)]) == {"LP_entry_with_open_bank"}
    assert rules(P0, [act(0), cmd(20, SRE)]) == {"LP_entry_with_open_bank"}


def test_trp_before_refresh_mrs_and_low_power_entry() -> None:
    # ACT@0, PRE@9 ; the next command at 12 is 3 < trp 4 after the PRE, at 13 it is legal
    pre_seq = [act(0), pre(9)]
    assert rules(P0, pre_seq + [cmd(12, REF_AB)]) == {"tRP_REF"}
    assert rules(P0, pre_seq + [cmd(13, REF_AB)]) == set()
    assert rules(P0, pre_seq + [cmd(12, REF_PB)]) == {"tRP_REF"}
    assert rules(P0, pre_seq + [cmd(13, REF_PB)]) == set()
    assert rules(P0, pre_seq + [cmd(12, MRS)]) == {"tRP_MRS"}
    assert rules(P0, pre_seq + [cmd(13, MRS)]) == set()
    assert rules(P0, pre_seq + [cmd(12, PDE)]) == {"tRP_LP"}
    assert rules(P0, pre_seq + [cmd(12, SRE)]) == {"tRP_LP"}
    assert rules(P0, pre_seq + [cmd(13, PDE)]) == set()


def test_command_while_low_power() -> None:
    assert rules(P0, [cmd(10, PDE), act(12)]) == {"command_while_low_power"}
    assert rules(P0, [cmd(10, PDE), rd(12)]) == {"command_while_low_power"}
    assert rules(P0, [cmd(10, PDE), cmd(12, REF_AB)]) == {"command_while_low_power"}
    assert rules(P0, [cmd(10, SRE), act(12)]) == {"command_while_low_power"}
    assert rules(P0, [cmd(10, SRE), cmd(12, PDX)]) == {"command_while_low_power"}  # wrong exit
    assert rules(P0, [cmd(10, PDE), cmd(12, SRX)]) == {"command_while_low_power"}
    assert rules(P0, [cmd(10, PDE), cmd(12, RFM)]) == {"command_while_low_power"}
    # the legal exits are accepted immediately (no minimum residency in TIMING_RULES.md)
    assert rules(P0, [cmd(10, PDE), cmd(11, PDX)]) == set()
    assert rules(P0, [cmd(10, SRE), cmd(11, SRX)]) == set()


def test_low_power_command_is_ignored_for_state() -> None:
    # ACT during power-down must not open the bank: RD after the exit is col_to_closed_bank
    chk = run(P0, [cmd(10, PDE), act(12), cmd(20, PDX), rd(30)])
    assert chk.rules() == {"command_while_low_power", "col_to_closed_bank"}


def test_exit_without_entry() -> None:
    assert rules(P0, [cmd(10, PDX)]) == {"exit_wrong_state"}
    assert rules(P0, [cmd(10, SRX)]) == {"exit_wrong_state"}
    assert rules(P0, [cmd(10, PDE), cmd(12, PDX), cmd(20, PDX)]) == {"exit_wrong_state"}


def test_rfm_has_no_rule_of_its_own() -> None:
    assert rules(P0, [cmd(10, RFM)]) == set()
    assert rules(P0, [cmd(100, MRS), cmd(102, RFM)]) == {"tMRD"}  # only the global gate applies
    assert rules(P0, [act(0), cmd(1, RFM)]) == set()  # no precharge precondition is stated


# ---------------------------------------------------------------------------
# PRE / PREA semantics
# ---------------------------------------------------------------------------

def test_pre_to_closed_bank_is_legal_noop() -> None:
    assert rules(P0, [pre(5)]) == set()
    assert rules(P0, [act(0), pre(9), pre(10)]) == set()


def test_pre_noop_does_not_restart_trp_by_default() -> None:
    # ACT@0, PRE@9 (real), PRE@10 (no-op), ACT@13: 13-9 = 4 >= trp (literal "closed banks are unaffected")
    ev = [act(0), pre(9), pre(10), act(13)]
    assert rules(P0, ev) == set()
    # knob: if the no-op PRE did record last_PRE, ACT@13 would be 3 < 4 after it
    assert rules(P0, ev, pre_noop_updates_last_pre=True) == {"tRP"}


def test_prea() -> None:
    # ACT b0@0, ACT b1(g1)@2, PREA@10: bank b1: 10-2 = 8 < tras 9 -> tRAS ; PREA@11 legal
    base = [act(0, 0, 0), act(2, 1, 0)]
    assert rules(P0, base + [cmd(10, PREA)]) == {"tRAS"}
    assert rules(P0, base + [cmd(11, PREA)]) == set()
    # PREA closes everything and records last_PRE: ACT (g0,b0) at 14: 14-11 = 3 < trp
    assert rules(P0, base + [cmd(11, PREA), act(14, 0, 0)]) == {"tRP"}
    assert rules(P0, base + [cmd(11, PREA), act(15, 0, 0)]) == set()
    # RD@4 then PREA@5: tRAS (5 < 9) and tRTP (5-4 = 1 < 2)
    assert rules(P0, [act(0), rd(4), cmd(5, PREA)]) == {"tRAS", "tRTP"}


def test_violating_command_still_updates_state() -> None:
    # ACT g1@1 violates tRRD_S but still opens the bank: RD@5 (5-1 = 4 >= trcdrd) is then clean
    assert rules(P0, [act(0, 0, 0), act(1, 1, 0), rd(5, 1, 0)]) == {"tRRD_S"}


# ---------------------------------------------------------------------------
# Write data (TIMING_RULES.md, "Data timing")
# ---------------------------------------------------------------------------

def test_write_data_exact_time_is_clean() -> None:
    assert rules(P0, [act(0), wr(10), W(13)]) == set()  # 10 + wl 3


def test_write_data_off_time() -> None:
    assert rules(P0, [act(0), wr(10), W(12)]) == {"write_data_off_time"}  # early
    assert rules(P0, [act(0), wr(10), W(14)]) == {"write_data_off_time"}  # late


def test_write_data_missing() -> None:
    ev = [act(0), wr(10)]
    assert rules(P0, ev, end=20) == {"write_data_missing"}
    assert rules(P0, ev, end=13) == {"write_data_missing"}  # due at 13 = end
    assert rules(P0, ev, end=12) == set()  # not yet due
    # P1 (wl 8): WR@40 -> data due at 48
    assert rules(P1, [act(0), wr(40)], end=47) == set()
    assert rules(P1, [act(0), wr(40)], end=48) == {"write_data_missing"}


def test_write_data_unexpected() -> None:
    assert rules(P0, [W(5)]) == {"write_data_unexpected"}
    assert rules(P0, [act(0), wr(10), W(13), W(13)]) == {"write_data_unexpected"}


def test_write_data_per_pc() -> None:
    # the beat must be on the same pseudo-channel as the WR
    ev = [act(0, pc=0), wr(10, pc=0), W(13, pc=1)]
    assert rules(P0, ev, end=20) == {"write_data_unexpected", "write_data_missing"}


def test_burst_two_still_one_beat_per_wr() -> None:
    # P2 burst = 2: the literal reading is one beat at t + wl = 20 + 10 = 30
    assert rules(P2, [act(0), wr(20), W(30)]) == set()


# ---------------------------------------------------------------------------
# Refresh deadline
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("prof, bound", [(P0, 1036), (P1, 19952), (P2, 6448)])
def test_refresh_deadline_boundary(prof: Profile, bound: int) -> None:
    ok = run(prof, [], end=bound, pcs=[0])
    assert ok.violations == []  # now - last_refresh = bound <= bound
    bad = run(prof, [], end=bound + 1, pcs=[0])
    assert bad.rules() == {"refresh_deadline"}
    assert len(bad.violations) == 1  # one violation per pc listing the lapsed banks
    assert bad.violations[0].cycle == bound + 1


def test_refresh_deadline_reset_by_ref_ab() -> None:
    # REF_AB@1000 resets every bank; next lapse is 1000 + 1036 + 1 = 2037
    ev = [cmd(1000, REF_AB)]
    assert rules(P0, ev, end=2036) == set()
    assert rules(P0, ev, end=2037) == {"refresh_deadline"}


def test_refresh_deadline_late_ref_is_itself_a_violation() -> None:
    # strict reading: REF_AB at 1036 is in time, at 1037 the gap 1037 > 1036 was already exceeded
    assert rules(P0, [cmd(1036, REF_AB)]) == set()
    assert rules(P0, [cmd(1037, REF_AB)]) == {"refresh_deadline"}


def test_refresh_deadline_per_bank_with_ref_pb() -> None:
    # REF_PB refreshes only its bank: after REF_PB(0,0)@1000 the other 15 banks lapse at 1037
    chk = run(P0, [cmd(1000, REF_PB, 0, 0)], end=1037)
    assert chk.rules() == {"refresh_deadline"}
    assert "15 banks" in chk.violations[0].detail


def test_refresh_deadline_self_refresh_exempt_and_srx_resets() -> None:
    assert rules(P0, [cmd(100, SRE)], end=100_000) == set()  # still in self-refresh
    ev = [cmd(100, SRE), cmd(100_000, SRX)]
    assert rules(P0, ev, end=100_000 + 1036) == set()  # SRX reset last_refresh to 100000
    assert rules(P0, ev, end=100_000 + 1037) == {"refresh_deadline"}


def test_refresh_deadline_power_down_is_not_exempt() -> None:
    assert rules(P0, [cmd(100, PDE)], end=1037) == {"refresh_deadline"}


def test_refresh_deadline_time_zero_option() -> None:
    # a trace starting at cycle 5000 with time_zero = 5000
    assert rules(P0, [act(5000)], end=5000 + 1036, time_zero=5000) == set()
    assert rules(P0, [act(5000)], end=5000 + 1037, time_zero=5000) == {"refresh_deadline"}


# ---------------------------------------------------------------------------
# Bus hygiene, pseudo-channel independence, robustness
# ---------------------------------------------------------------------------

def test_one_command_per_pc_per_cycle() -> None:
    assert "cmd_bus_conflict" in rules(P0, [act(0, 0, 0), act(0, 1, 0)])
    # different pseudo-channels may use the same cycle
    assert rules(P0, [act(0, 0, 0, pc=0), act(0, 0, 0, pc=1)]) == set()


def test_pseudo_channels_are_independent() -> None:
    # same bank, same cycle, different pcs: no tRRD / tFAW coupling
    ev = [act(0, 0, 0, pc=0), act(1, 1, 0, pc=1), act(2, 2, 0, pc=2), act(3, 3, 0, pc=3),
          act(4, 0, 1, pc=4)]
    assert rules(P0, ev) == set()
    # the same ACT pair on ONE pc violates tRRD_S
    assert rules(P0, [act(0, 0, 0, pc=0), act(1, 1, 0, pc=0)]) == {"tRRD_S"}
    # a bank open on pc0 is not open on pc1
    assert rules(P0, [act(0, pc=0), rd(4, pc=1)]) == {"col_to_closed_bank"}
    # power state is per pc
    assert rules(P0, [cmd(10, PDE, pc=0), act(12, pc=1)]) == set()
    # ref busy is per pc
    assert rules(P0, [cmd(100, REF_AB, pc=0), act(101, pc=1)]) == set()


def test_unknown_command_and_bad_bank() -> None:
    assert rules(P0, [(5, 0, 99, 0, 0, 0, 0)]) == {"unknown_command"}
    assert rules(P0, [act(5, 7, 0)]) == {"bank_out_of_range"}
    assert rules(P0, [act(5, 0, 4)]) == {"bank_out_of_range"}


def test_non_monotonic_time() -> None:
    # second ACT at cycle 5 after one at 10 on the same pc: reported, and the negative gap
    # (5 - 10) also fails tRRD_S
    assert rules(P0, [act(10, 0, 0), act(5, 1, 0)]) == {"trace_not_chronological", "tRRD_S"}


def test_violation_records() -> None:
    chk = run(P0, [act(10), rd(13)])
    v = chk.violations[0]
    assert (v.rule, v.cycle, v.pc, v.cmd) == ("tRCDRD", 13, 0, RD)
    assert v.cmd_name == "RD" and "gap=3" in v.detail
    assert chk.summary() == {"tRCDRD": 1}
