"""cocotb: RTL sf_hbm_ecc_ras SECDED vs python/hbm4/reference_memory.py (independent implementation of docs/RAS_CODE.md)."""
import random
import cocotb
from cocotb.triggers import Timer
from hbm4.reference_memory import secded_encode, secded_decode

async def settle(): await Timer(1, "ns")

@cocotb.test()
async def encode_and_decode_match_python(dut):
    rng = random.Random(7)
    dut.ecc_en_i.value = 1; dut.clear_i.value = 0; dut.inj_arm_i.value = 0; dut.inj_mode_i.value = 0; dut.inj_bit_i.value = 0
    dut.wr_fire_i.value = 0; dut.rd_fire_i.value = 0; dut.phy_event_i.value = 0; dut.ondie_event_i.value = 0
    dut.clk_i.value = 0; dut.rst_ni.value = 1
    cases = 0
    for _ in range(300):
        d = rng.getrandbits(256)
        dut.wdata_i.value = d
        await settle()
        e = secded_encode(d)
        assert int(dut.wecc_o.value) == e, f"encode mismatch data={d:#x}: rtl={int(dut.wecc_o.value):#x} python={e:#x}"
        # clean, single-bit (data and check bits), double-bit
        flips = [[]] + [[rng.randrange(266)] for _ in range(3)] + [rng.sample(range(266), 2) for _ in range(3)]
        for fl in flips:
            dd, ee = d, e
            for b in fl:
                if b < 256: dd ^= 1 << b
                else: ee ^= 1 << (b - 256)
            dut.rdata_i.value = dd; dut.recc_i.value = ee
            await settle()
            pd, pce, pue, _syn = secded_decode(dd, ee)
            rtl_err = int(dut.rerr_o.value)           # 0 none, 6 ECC (uncorrectable)
            assert (rtl_err == 6) == bool(pue), f"UE disagrees flips={fl}: rtl_err={rtl_err} python_ue={pue}"
            if not pue:
                assert int(dut.rdata_o.value) == pd, f"corrected data differs flips={fl}"
                assert int(dut.rcorr_o.value) == int(bool(pce)), f"corrected flag differs flips={fl}"
            cases += 1
    dut._log.info(f"{cases} encode/decode cases agree with the Python SECDED")

@cocotb.test()
async def exhaustive_single_bit_positions(dut):
    d = 0x0123456789ABCDEF_FEDCBA9876543210_0F1E2D3C4B5A6978_8796A5B4C3D2E1F0
    dut.wdata_i.value = d; await settle(); e = int(dut.wecc_o.value)
    for b in range(266):
        dd, ee = d, e
        if b < 256: dd ^= 1 << b
        else: ee ^= 1 << (b - 256)
        dut.rdata_i.value = dd; dut.recc_i.value = ee; await settle()
        assert int(dut.rerr_o.value) == 0 and int(dut.rdata_o.value) == d and int(dut.rcorr_o.value) == 1, f"single-bit error at position {b} not corrected by the RTL"
