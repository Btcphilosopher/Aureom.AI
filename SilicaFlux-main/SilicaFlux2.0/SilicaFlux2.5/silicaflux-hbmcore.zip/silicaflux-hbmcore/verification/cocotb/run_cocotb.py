#!/usr/bin/env python3
"""Build and run the cocotb regression with Verilator (>= 5.036 required by cocotb 2.x; 5.048 used here).
Writes reports/cocotb.json. After the traffic test, the DRAM command trace is replayed through the independent Python TimingChecker."""
import json, os, pathlib, sys, time
HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(ROOT / "python")); sys.path.insert(0, str(HERE))
os.environ["PATH"] = "/opt/vl548/usr/bin:" + os.environ["PATH"]
os.environ.setdefault("VERILATOR_ROOT", "/opt/vl548/usr/share/verilator")
from cocotb_tools.runner import get_runner

RTL = [str(ROOT / "rtl" / f) for f in ("sf_hbm_pkg.sv", "sf_hbm_profile_pkg.sv")] + \
      sorted(str(p) for p in (ROOT / "rtl").glob("sf_hbm*.sv") if "pkg" not in p.name)
MODEL = str(ROOT / "verification" / "hbm4" / "hbm4_dram_model.sv")
ARGS = ["--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-UNOPTFLAT", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-Wno-CASEINCOMPLETE"]
results = []

def run(name, top, srcs, test_module, params=None, extra_env=None, plusargs=None):
    t0 = time.time()
    bdir = ROOT / "build" / "cocotb" / name
    r = get_runner("verilator")
    r.build(sources=srcs, hdl_toplevel=top, build_dir=bdir, includes=[str(ROOT / "rtl")], build_args=ARGS, parameters=params or {}, timescale=("1ns", "1ps"), always=True)
    env = dict(os.environ); env.update(extra_env or {}); env["PYTHONPATH"] = f"{ROOT/'python'}:{HERE}:" + env.get("PYTHONPATH", "")
    os.environ.update(extra_env or {})
    xml = r.test(hdl_toplevel=top, test_module=test_module, build_dir=bdir, plusargs=plusargs or [], results_xml=str(bdir / "results.xml"), timescale=("1ns", "1ps"))
    import xml.etree.ElementTree as ET
    tree = ET.parse(xml); tests = list(tree.iter("testcase")); fails = [t for t in tests if t.find("failure") is not None or t.find("error") is not None]
    results.append(dict(name=name, top=top, test_module=test_module, tests=len(tests), failed=len(fails), seconds=round(time.time() - t0, 1),
                        status="PASS" if not fails else "FAIL"))
    print(f"[{results[-1]['status']}] {name}: {len(tests)} cocotb tests, {len(fails)} failed")
    return not fails

ok = True
for nch in (4, 32):
    ok &= run(f"addr_map_{nch}ch", "cocotb_addr_map", RTL + [str(HERE / "hdl" / "cocotb_addr_map.sv")], "test_addr_map", params={"NUM_CHANNELS": nch}, extra_env={"NCH": str(nch)})
ok &= run("ecc", "sf_hbm_ecc_ras", RTL, "test_ecc")
for prof in (0, 1, 2):
    tr = ROOT / "reports" / "traces" / f"cocotb_pc_p{prof}.trace"; tr.parent.mkdir(parents=True, exist_ok=True)
    ok &= run(f"pc_traffic_profile{prof}", "cocotb_pc_top", RTL + [MODEL, str(HERE / "hdl" / "cocotb_pc_top.sv")], "test_pc_traffic",
              extra_env={"PROFILE": str(prof), "POLICY": "1", "NREQ": "1500"}, plusargs=[f"+HBM_TRACE={tr}"])
    # independent timing check of the RTL-driven command trace
    from hbm4.trace_check import check_trace_file
    from hbm4.timing import load_profiles
    chk = check_trace_file(str(tr), load_profiles()[prof], pcs=[0]) if tr.exists() else None
    clean = chk is not None and not chk.violations
    results.append(dict(name=f"python_timing_checker_on_cocotb_trace_profile{prof}", status="PASS" if clean else "FAIL", violations=0 if chk is None else len(chk.violations)))
    print(f"[{'PASS' if clean else 'FAIL'}] python TimingChecker on cocotb trace, profile {prof}: {0 if chk is None else len(chk.violations)} violations")
    ok &= clean
(ROOT / "reports").mkdir(exist_ok=True)
(ROOT / "reports" / "cocotb.json").write_text(json.dumps(dict(simulator="verilator 5.048", cocotb="2.1.0", results=results, all_passed=bool(ok)), indent=1))
sys.exit(0 if ok else 1)
