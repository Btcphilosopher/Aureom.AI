// =============================================================================
//  tb_dma_spm.sv -- DMA integration: external HBM <-> on-chip scratchpad SRAM
//
//   host tile (TB) ---\                                              /--- vector port (TB reads/writes lines)
//                      >-- NoC request mux --> sf_hbm_datafabric --> HBM backend (mock | real controller + DRAM model)
//   sf_hbm_dma_adapter /                                             \
//        |  burst port ---------------------------------------------> REAL silicaflux memory_controller (scratchpad)
//
//  The scratchpad is the UNMODIFIED memory_controller from DataFabric NoC v2 (third_party/noc_v2). The DMA must respect
//  its burst rules (single domain, single 4 KiB page, aperture) - violations would come back as burst errors.
//  Tests: HBM->SRAM and SRAM->HBM copies, programmable burst sizes 1/3/8/32, 16 B- but not 32 B-aligned HBM addresses,
//  page-boundary splitting, byte-exact comparison, error paths (out-of-aperture SRAM, out-of-capacity HBM, misaligned),
//  back-to-back transfers, measured throughput.
// =============================================================================
`timescale 1ns/1ps
module tb_dma_spm;
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;
  import silicaflux_pkg::*;

  parameter int unsigned BACKEND = 0;     // 0 mock (fast), 1 real controller + DRAM model
  localparam sf_paddr_t SPM_BASE = 32'h1000_0000;
  localparam int unsigned CAPB = 24;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  longint unsigned cyc; always @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  localparam sf_noc_id_t DMA_ID = 4'b0000, HOST_ID = 4'b0001, MEM_ID = 4'b0011;

  // ---------------- NoC wiring
  logic a_req_v, a_req_r; noc_packet_t a_req_p; logic a_rsp_v, a_rsp_r; noc_packet_t a_rsp_p;
  logic h_req_v; noc_packet_t h_req_p; logic h_rsp_r;
  logic d_req_v, d_req_r; noc_packet_t d_req_p; logic d_rsp_v, d_rsp_r; noc_packet_t d_rsp_p;
  logic dma_busy;
  assign a_req_v = dma_busy ? d_req_v : h_req_v;
  assign a_req_p = dma_busy ? d_req_p : h_req_p;
  assign d_req_r = dma_busy ? a_req_r : 1'b0;
  logic h_req_r; assign h_req_r = dma_busy ? 1'b0 : a_req_r;
  // response routing by dst_id
  wire rsp_to_dma = (a_rsp_p.dst_id == DMA_ID);
  assign d_rsp_v = a_rsp_v && rsp_to_dma;
  assign d_rsp_p = a_rsp_p;
  logic h_rsp_v; assign h_rsp_v = a_rsp_v && !rsp_to_dma;
  assign a_rsp_r = rsp_to_dma ? d_rsp_r : h_rsp_r;
  noc_packet_t h_rsp_p; assign h_rsp_p = a_rsp_p;

  // ---------------- HBM side
  logic h_v, h_r; hbm_addr_t h_a; logic h_w; hbm_id_t h_id; hbm_src_t h_src; hbm_qos_t h_q; hbm_data_t h_wd; hbm_mask_t h_wm;
  logic hr_v, hr_r; hbm_rsp_t hr;
  logic [7:0] addr_hi = 8'h00;
  logic [7:0] max_burst_m1 = 8'd31;
  logic ev_d, ev_e;
  sf_hbm_datafabric #(.REQ_DEPTH(4), .ROB_N(64), .NTAG(64), .HBM_SRC(1)) node (
    .clk_i(clk), .rst_ni(rst_n), .req_valid_i(a_req_v), .req_ready_o(a_req_r), .req_pkt_i(a_req_p),
    .rsp_valid_o(a_rsp_v), .rsp_ready_i(a_rsp_r), .rsp_pkt_o(a_rsp_p), .addr_hi_i(addr_hi), .max_burst_m1_i(max_burst_m1),
    .h_req_valid_o(h_v), .h_req_ready_i(h_r), .h_req_addr_o(h_a), .h_req_write_o(h_w), .h_req_id_o(h_id),
    .h_req_src_o(h_src), .h_req_qos_o(h_q), .h_req_wdata_o(h_wd), .h_req_wmask_o(h_wm),
    .h_rsp_valid_i(hr_v), .h_rsp_ready_o(hr_r), .h_rsp_i(hr), .ev_drop_o(ev_d), .ev_err_rsp_o(ev_e));

  int unsigned viol_cnt = 0; logic bringup_done = 1;
  if (BACKEND == 0) begin : g_mock
    hbm_mock_backend #(.CAP_BITS(CAPB)) mock (.clk_i(clk), .rst_ni(rst_n), .req_valid_i(h_v), .req_ready_o(h_r),
      .req_addr_i(h_a), .req_write_i(h_w), .req_id_i(h_id), .req_src_i(h_src), .req_wdata_i(h_wd), .req_wmask_i(h_wm),
      .rsp_valid_o(hr_v), .rsp_ready_i(hr_r), .rsp_o(hr));
  end else begin : g_real
    localparam int unsigned NCH = 2, NPC = 4;
    hbm_cfg_t cfg; logic pg = 0, cs = 0, pid = 0, tdn = 0, rdy, pis, ts, ierr; logic [2:0] ic, ist;
    logic [NPC-1:0] pready, scv, swv, srv, srerr; hbm_cmd_t [NPC-1:0] sc; hbm_data_t [NPC-1:0] swd, srd; hbm_mask_t [NPC-1:0] swm;
    hbm_ecc_t [NPC-1:0] swe, sre; hbm_pc_stat_t [NPC-1:0] stat; logic e1, e2, e3, e4, e5, e6, e7, infeas; logic [15:0] outst;
    sf_hbm4_controller #(.NUM_STACKS(1), .NUM_CHANNELS(NCH), .CH_PER_CLUSTER(NCH), .DEPTH(16), .TRK_SRC_W(2), .TRK_ID_W(6)) ctl (
      .clk_i(clk), .rst_ni(rst_n), .cfg_i(cfg), .power_good_i(pg), .clk_stable_i(cs), .phy_init_done_i(pid), .train_done_i(tdn),
      .phy_init_start_o(pis), .train_start_o(ts), .ready_o(rdy), .init_error_o(ierr), .init_cause_o(ic), .init_state_o(ist),
      .req_valid_i(h_v), .req_ready_o(h_r), .req_addr_i(h_a), .req_write_i(h_w), .req_fence_i(1'b0), .req_id_i(h_id),
      .req_src_i(h_src), .req_qos_i(h_q), .req_order_i(ORD_RELAXED), .req_wdata_i(h_wd), .req_wmask_i(h_wm),
      .rsp_valid_o(hr_v), .rsp_ready_i(hr_r), .rsp_o(hr), .ecc_clear_i(1'b0), .inj_arm_i(1'b0), .inj_pc_i('0), .inj_mode_i('0), .inj_bit_i('0),
      .phy_ready_ext_i(pready), .phy_event_i('0), .ondie_event_i('0),
      .sim_cmd_valid_o(scv), .sim_cmd_o(sc), .sim_wvalid_o(swv), .sim_wdata_o(swd), .sim_wmask_o(swm), .sim_wecc_o(swe),
      .sim_rvalid_i(srv), .sim_rdata_i(srd), .sim_recc_i(sre), .sim_rerr_i(srerr), .stat_o(stat),
      .ev_accept_o(e1), .ev_accept_rd_o(e2), .ev_accept_wr_o(e3), .ev_err_req_o(e4), .ev_stall_id_o(e5), .ev_stall_q_o(e6),
      .ev_stall_fence_o(e7), .outstanding_o(outst), .ref_cfg_infeasible_o(infeas));
    hbm_timing_t tp; assign tp = hbm_profile(4'd1);
    int unsigned cmdc;
    hbm4_dram_model #(.NUM_PC(NPC)) dram (.clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(1'b0), .stall_pct_i(8'd0),
      .cmd_valid_i(scv), .cmd_i(sc), .wvalid_i(swv), .wdata_i(swd), .wmask_i(swm), .wecc_i(swe),
      .ready_o(pready), .rvalid_o(srv), .rdata_o(srd), .recc_o(sre), .rerr_o(srerr), .viol_cnt_o(viol_cnt), .cmd_cnt_o(cmdc));
    initial begin
      bringup_done = 0; cfg = '0; cfg.enable = 1; cfg.map_mode = MAP_BANK_AWARE; cfg.profile_sel = 4'd1;
      cfg.sched.policy = SCHED_FRFCFS; cfg.ref_cfg.mode = REFMODE_AB; cfg.ref_cfg.eager = 1; cfg.init_timeout = 32'd20000;
      @(posedge rst_n); repeat (5) @(posedge clk); pg = 1; repeat (3) @(posedge clk); cs = 1; repeat (3) @(posedge clk);
      wait (pis); repeat (4) @(posedge clk); pid = 1; wait (ts); repeat (6) @(posedge clk); tdn = 1; wait (rdy);
      bringup_done = 1;
    end
  end

  // ---------------- scratchpad (REAL memory_controller) + DMA
  logic spm_rq_v, spm_rq_r, spm_wd_v, spm_wd_r, spm_rd_v, spm_rd_r, spm_dn_v, spm_dn_r;
  sf_burst_desc_t spm_rq; sf_burst_wbeat_t spm_wd; sf_burst_rbeat_t spm_rd; sf_burst_done_t spm_dn;
  logic vq_v, vq_r, vr_v, vr_r; sf_vector_mem_req_t vq; sf_vector_mem_rsp_t vr;
  logic sq_v = 0, sr_r = 1; sf_scalar_mem_req_t sq = '0;
  logic init_done;
  memory_controller #(.SPM_BASE(SPM_BASE), .NUM_BANKS(8), .BANK_DEPTH(512), .SCALAR_LINES(64), .BURST_MAX_BEATS(256),
                      .BURST_PAGE_BYTES(4096)) spm (
    .clk_i(clk), .rst_ni(rst_n), .flush_i(1'b0), .burst_kill_i(1'b0),
    .scalar_req_valid_i(sq_v), .scalar_req_ready_o(), .scalar_req_i(sq), .scalar_rsp_valid_o(), .scalar_rsp_ready_i(sr_r), .scalar_rsp_o(),
    .vector_req_valid_i(vq_v), .vector_req_ready_o(vq_r), .vector_req_i(vq), .vector_rsp_valid_o(vr_v), .vector_rsp_ready_i(vr_r), .vector_rsp_o(vr),
    .burst_req_valid_i(spm_rq_v), .burst_req_ready_o(spm_rq_r), .burst_req_i(spm_rq),
    .burst_wdata_valid_i(spm_wd_v), .burst_wdata_ready_o(spm_wd_r), .burst_wdata_i(spm_wd),
    .burst_rdata_valid_o(spm_rd_v), .burst_rdata_ready_i(spm_rd_r), .burst_rdata_o(spm_rd),
    .burst_done_valid_o(spm_dn_v), .burst_done_ready_i(spm_dn_r), .burst_done_o(spm_dn),
    .coh_wr_valid_o(), .coh_wr_addr_o(), .init_done_o(init_done), .busy_o(), .bank_conflict_o());

  logic dma_start = 0, dma_dir = 0, dma_done; logic [39:0] dma_hbm = 0; sf_paddr_t dma_spm = 0; logic [23:0] dma_bytes = 0; logic [5:0] dma_burst = 8;
  sf_mem_exc_e dma_err; logic [31:0] dma_moved; logic [15:0] dma_chunks;
  sf_hbm_dma_adapter #(.MY_ID(DMA_ID), .MEM_ID(MEM_ID), .SPM_PAGE_BYTES(4096), .SPM_MAX_BEATS(256)) dma (
    .clk_i(clk), .rst_ni(rst_n), .start_i(dma_start), .dir_i(dma_dir), .hbm_addr_i(dma_hbm), .spm_addr_i(dma_spm),
    .bytes_i(dma_bytes), .burst_beats_i(dma_burst), .node_addr_hi_i(addr_hi), .node_max_burst_m1_i(max_burst_m1), .busy_o(dma_busy), .done_o(dma_done), .err_o(dma_err),
    .bytes_moved_o(dma_moved), .chunks_o(dma_chunks),
    .noc_req_valid_o(d_req_v), .noc_req_ready_i(d_req_r), .noc_req_o(d_req_p),
    .noc_rsp_valid_i(d_rsp_v), .noc_rsp_ready_o(d_rsp_r), .noc_rsp_i(d_rsp_p),
    .spm_req_valid_o(spm_rq_v), .spm_req_ready_i(spm_rq_r), .spm_req_o(spm_rq),
    .spm_wdata_valid_o(spm_wd_v), .spm_wdata_ready_i(spm_wd_r), .spm_wdata_o(spm_wd),
    .spm_rdata_valid_i(spm_rd_v), .spm_rdata_ready_o(spm_rd_r), .spm_rdata_i(spm_rd),
    .spm_done_valid_i(spm_dn_v), .spm_done_ready_o(spm_dn_r), .spm_done_i(spm_dn));

  // ---------------- host helpers
  int errors = 0;
  logic [7:0] href [longint];        // reference image of the HBM
  logic [7:0] sref [longint];        // reference image of the scratchpad (by SRAM byte address)
  int tid = 0;

  function automatic noc_packet_t mk(sf_noc_class_e c, int txn, sf_paddr_t a, sf_noc_be_t be, sf_noc_data_t d, bit sop, bit eop);
    noc_packet_t p; p = '0; p.valid = 1; p.sop = sop; p.eop = eop; p.pclass = c; p.dst_id = MEM_ID; p.src_id = HOST_ID;
    p.txn_id = sf_mem_tag_t'(txn); p.xfer = SF_NOC_X_BURST; p.addr = a; p.be = be; p.data = d; return p;
  endfunction

  noc_packet_t hq [$];
  always @(posedge clk) begin
    if (!rst_n) h_req_v <= 0;
    else begin
      if (h_req_v && h_req_r) h_req_v <= 0;
      if ((!h_req_v || h_req_r) && hq.size() != 0 && !dma_busy) begin h_req_p <= hq.pop_front(); h_req_v <= 1; end
    end
  end
  noc_packet_t hrs [$];
  assign h_rsp_r = 1'b1;
  always @(posedge clk) if (rst_n && h_rsp_v && h_rsp_r) hrs.push_back(h_rsp_p);

  // host: write `len` bytes (16 B aligned) to HBM at `a` with random data, updating href
  task automatic host_fill(input sf_paddr_t a, input int bytes);
    int beats, off; beats = bytes / 16; off = 0;
    while (off < beats) begin
      int n; noc_packet_t p; n = (beats - off > 32) ? 32 : (beats - off);
      p = mk(SF_NOC_WR_REQ, tid++ % 256, a + 16 * off, '0, sf_noc_data_t'(n - 1), 1, 0); hq.push_back(p);
      for (int b = 0; b < n; b++) begin
        sf_noc_data_t d; d = {$urandom, $urandom, $urandom, $urandom};
        hq.push_back(mk(SF_NOC_WR_REQ, tid % 256, a + 16 * (off + b), 16'hFFFF, d, 0, (b == n - 1)));
        for (int i = 0; i < 16; i++) href[longint'(a) + 16 * (off + b) + i] = d[i*8 +: 8];
      end
      off += n;
    end
  endtask
  // host: read back from HBM and compare with href
  task automatic host_check(input sf_paddr_t a, input int bytes, input string what);
    int beats, got, off; beats = bytes / 16; off = 0; hrs.delete();
    while (off < beats) begin
      int n; n = (beats - off > 32) ? 32 : (beats - off);
      hq.push_back(mk(SF_NOC_RD_REQ, tid++ % 256, a + 16 * off, '0, sf_noc_data_t'(n - 1), 1, 1));
      off += n;
    end
    begin int w; w = 0; while (hrs.size() < beats && w < 200000) begin @(posedge clk); w++; end end
    if (hrs.size() != beats) begin errors++; $display("[TB][FAIL] %s: host read returned %0d of %0d flits", what, hrs.size(), beats); return; end
    for (int b = 0; b < beats; b++) begin
      if (hrs[b].status != SF_MEM_EXC_NONE) begin errors++; $display("[TB][FAIL] %s: host read error status %0d", what, hrs[b].status); return; end
      for (int i = 0; i < 16; i++) begin
        logic [7:0] e; e = href.exists(longint'(a) + 16 * b + i) ? href[longint'(a) + 16 * b + i] : 8'h00;
        if (hrs[b].data[i*8 +: 8] !== e) begin errors++; $display("[TB][FAIL] %s: HBM byte %0d of beat %0d exp=%02h got=%02h", what, i, b, e, hrs[b].data[i*8 +: 8]); return; end
      end
    end
  endtask

  // scratchpad access through the real vector port
  assign vr_r = 1'b1;
  task automatic spm_line_rd(input sf_paddr_t a, output sf_vword_t d, output sf_mem_exc_e ex);
    vq = '0; vq.op = SF_MEM_LOAD; vq.addr = a; vq.lane_mask = '1; vq.tag = 8'h5A;
    @(posedge clk); vq_v <= 1; @(posedge clk); while (!vq_r) @(posedge clk); vq_v <= 0;
    while (!vr_v) @(posedge clk); d = vr.rdata; ex = vr.exc; @(posedge clk);
  endtask
  task automatic spm_line_wr(input sf_paddr_t a, input sf_vword_t d);
    sf_vword_t dummy; sf_mem_exc_e ex;
    vq = '0; vq.op = SF_MEM_STORE; vq.addr = a; vq.wdata = d; vq.lane_mask = '1; vq.tag = 8'h5B;
    @(posedge clk); vq_v <= 1; @(posedge clk); while (!vq_r) @(posedge clk); vq_v <= 0;
    while (!vr_v) @(posedge clk); @(posedge clk);
  endtask
  task automatic spm_check(input sf_paddr_t a, input int bytes, input string what);
    for (int b = 0; b < bytes / 16; b++) begin
      sf_vword_t d; sf_mem_exc_e ex;
      spm_line_rd(a + 16 * b, d, ex);
      if (ex != SF_MEM_EXC_NONE) begin errors++; $display("[TB][FAIL] %s: scratchpad read exc %0d at line %0d", what, ex, b); return; end
      for (int i = 0; i < 16; i++) begin
        logic [7:0] e; e = sref.exists(longint'(a) + 16 * b + i) ? sref[longint'(a) + 16 * b + i] : 8'h00;
        if (d[i*8 +: 8] !== e) begin errors++; $display("[TB][FAIL] %s: scratchpad byte %0d of line %0d exp=%02h got=%02h", what, i, b, e, d[i*8 +: 8]); return; end
      end
    end
  endtask
  task automatic spm_fill(input sf_paddr_t a, input int bytes);
    for (int b = 0; b < bytes / 16; b++) begin
      sf_vword_t d; d = {$urandom, $urandom, $urandom, $urandom};
      spm_line_wr(a + 16 * b, d);
      for (int i = 0; i < 16; i++) sref[longint'(a) + 16 * b + i] = d[i*8 +: 8];
    end
  endtask

  // run a DMA transfer and wait for completion
  longint last_cycles; sf_mem_exc_e last_err;
  task automatic run_dma(input bit dir, input longint hbm_a, input sf_paddr_t spm_a, input int bytes, input int burst);
    longint t0; int w;
    @(negedge clk); dma_dir = dir; dma_hbm = 40'(hbm_a); dma_spm = spm_a; dma_bytes = 24'(bytes); dma_burst = 6'(burst); dma_start = 1;
    @(negedge clk); dma_start = 0; t0 = cyc; w = 0;
    while (!dma_done && w < 400000) begin @(posedge clk); w++; end
    if (!dma_done) begin errors++; $display("[TB][FAIL] DMA timeout (dir=%0d bytes=%0d burst=%0d)", dir, bytes, burst); end
    last_cycles = cyc - t0; last_err = dma_err;
    repeat (4) @(posedge clk);
  endtask

  int test_base;
  task automatic bt(string n); test_base = errors; $display("[TB] ---- %s", n); endtask
  task automatic et(string n);
    if (BACKEND == 1 && viol_cnt != 0) begin errors++; $display("[TB][FAIL] DRAM violations %0d", viol_cnt); end
    $display("[TB] TEST %-44s %s", n, (errors == test_base) ? "PASS" : "FAIL");
  endtask

  longint stat_bytes, stat_cycles;
  task automatic t_h2s(input string name, input longint hbm_a, input sf_paddr_t spm_a, input int bytes, input int burst);
    bt(name);
    host_fill(sf_paddr_t'(hbm_a), bytes);
    while (hq.size() != 0 || h_req_v) @(posedge clk); repeat (30) @(posedge clk);
    // image of the scratchpad destination region is whatever the DMA writes: copy expectations from href
    for (int i = 0; i < bytes; i++) sref[longint'(spm_a) + i] = href[hbm_a + i];
    run_dma(0, hbm_a, spm_a, bytes, burst);
    if (last_err != SF_MEM_EXC_NONE) begin errors++; $display("[TB][FAIL] DMA error %0d", last_err); end
    if (dma_moved != bytes) begin errors++; $display("[TB][FAIL] bytes_moved %0d != %0d", dma_moved, bytes); end
    spm_check(spm_a, bytes, name);
    $display("[TB]   %0d bytes in %0d cycles, %0d chunks of <=%0d beats -> %0.2f B/cycle", bytes, last_cycles, dma_chunks, burst, real'(bytes) / real'(last_cycles));
    stat_bytes += bytes; stat_cycles += last_cycles;
    et(name);
  endtask

  task automatic t_s2h(input string name, input longint hbm_a, input sf_paddr_t spm_a, input int bytes, input int burst);
    bt(name);
    spm_fill(spm_a, bytes);
    for (int i = 0; i < bytes; i++) href[hbm_a + i] = sref[longint'(spm_a) + i];
    run_dma(1, hbm_a, spm_a, bytes, burst);
    if (last_err != SF_MEM_EXC_NONE) begin errors++; $display("[TB][FAIL] DMA error %0d", last_err); end
    if (dma_moved != bytes) begin errors++; $display("[TB][FAIL] bytes_moved %0d != %0d", dma_moved, bytes); end
    host_check(sf_paddr_t'(hbm_a), bytes, name);
    $display("[TB]   %0d bytes in %0d cycles, %0d chunks of <=%0d beats -> %0.2f B/cycle", bytes, last_cycles, dma_chunks, burst, real'(bytes) / real'(last_cycles));
    stat_bytes += bytes; stat_cycles += last_cycles;
    et(name);
  endtask

  initial begin
    int unsigned seed; if (!$value$plusargs("SEED=%d", seed)) seed = 1; $urandom(seed);
    vq_v = 0; stat_bytes = 0; stat_cycles = 0;
    $display("[TB] tb_dma_spm BACKEND=%0d (%s) seed=%0d", BACKEND, BACKEND ? "real controller + DRAM model" : "mock HBM", seed);
    rst_n = 0; repeat (5) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);
    wait (bringup_done); wait (init_done); repeat (4) @(posedge clk);
    // ---- HBM -> scratchpad, several burst sizes, 32 B-aligned and 16 B-only-aligned HBM sources
    t_h2s("hbm_to_spm_1KiB_burst8",        32'h0001_0000, SPM_BASE + 32'h0400, 1024, 8);
    t_h2s("hbm_to_spm_burst1_beat_by_beat", 32'h0001_1000, SPM_BASE + 32'h0800, 256, 1);
    t_h2s("hbm_to_spm_burst3_odd",         32'h0001_2000, SPM_BASE + 32'h0C00, 480, 3);
    t_h2s("hbm_to_spm_burst32_max",        32'h0001_3000, SPM_BASE + 32'h1000, 2048, 32);
    t_h2s("hbm_to_spm_hbm_16B_not_32B_aligned", 32'h0001_4010, SPM_BASE + 32'h1800, 800, 8);
    // ---- scratchpad page boundary (4 KiB): the DMA must split the chunk at the page edge
    t_h2s("hbm_to_spm_crossing_4KiB_page", 32'h0001_5000, SPM_BASE + 32'h1F00, 1024, 32);
    // ---- scratchpad -> HBM
    t_s2h("spm_to_hbm_1KiB_burst8",        32'h0002_0000, SPM_BASE + 32'h0400, 1024, 8);
    t_s2h("spm_to_hbm_burst5_hbm_16B_aligned", 32'h0002_1010, SPM_BASE + 32'h0800, 640, 5);
    t_s2h("spm_to_hbm_crossing_4KiB_page", 32'h0002_2000, SPM_BASE + 32'h1F80, 512, 32);
    // ---- round trip: HBM A -> SPM -> HBM B, compare B with A
    bt("round_trip_hbm_spm_hbm_4KiB");
    host_fill(32'h0003_0000, 4096);
    while (hq.size() != 0 || h_req_v) @(posedge clk); repeat (30) @(posedge clk);
    run_dma(0, 32'h0003_0000, SPM_BASE + 32'h2000, 4096, 16);
    run_dma(1, 32'h0004_0000, SPM_BASE + 32'h2000, 4096, 16);
    for (int i = 0; i < 4096; i++) href[32'h0004_0000 + i] = href[32'h0003_0000 + i];
    host_check(32'h0004_0000, 4096, "round trip");
    et("round_trip_hbm_spm_hbm_4KiB");
    // ---- errors
    bt("error_paths");
    run_dma(0, 32'h0005_0003, SPM_BASE + 32'h0400, 64, 4);                       // misaligned HBM address
    if (last_err != SF_MEM_EXC_MISALIGN) begin errors++; $display("[TB][FAIL] misaligned: err=%0d", last_err); end
    run_dma(0, 32'h0005_0000, 32'h2000_0000, 64, 4);                              // SRAM address outside the aperture
    if (last_err == SF_MEM_EXC_NONE) begin errors++; $display("[TB][FAIL] out-of-aperture SRAM transfer reported no error"); end
    addr_hi = 8'hF0;
    run_dma(0, 40'hF0_0000_0000 + 40'h1000, SPM_BASE + 32'h0400, 256, 4);        // HBM address beyond capacity
    if (last_err != SF_MEM_EXC_RANGE) begin errors++; $display("[TB][FAIL] HBM out of capacity: err=%0d (expected RANGE)", last_err); end
    // wrong 4 GiB window (node addr_hi = 0, request says window 1): rejected by the DMA itself, no NoC traffic
    addr_hi = 8'h00;
    begin
      run_dma(0, 40'h01_0000_1000, SPM_BASE + 32'h0400, 256, 4);
      if (last_err != SF_MEM_EXC_RANGE || dma_moved != 0 || dma_chunks != 0) begin errors++; $display("[TB][FAIL] wrong addr_hi window: err=%0d moved=%0d chunks=%0d", last_err, dma_moved, dma_chunks); end
    end
    // a transfer that would wrap the 32-bit NoC address (last 128 B of the window, 256 B long)
    run_dma(0, 40'h0_FFFF_FF80, SPM_BASE + 32'h0400, 256, 4);
    if (last_err != SF_MEM_EXC_RANGE || dma_moved != 0) begin errors++; $display("[TB][FAIL] 4GiB wrap: err=%0d moved=%0d", last_err, dma_moved); end
    // bytes_moved counts only error-free chunks: first chunk of a transfer that runs into the SRAM aperture end is ok, then fails
    addr_hi = 8'hF0;
    run_dma(0, 40'hF0_0000_0000 + 40'h2000, SPM_BASE + 32'h0400, 256, 4);          // HBM beyond capacity -> every chunk errors
    if (dma_moved != 0) begin errors++; $display("[TB][FAIL] failed transfer reports bytes_moved=%0d (expected 0)", dma_moved); end
    addr_hi = 8'h00;
    // the node's burst limit (3 -> 4 beats) is respected by the DMA (burst 32 requested): no BURST_LEN, data still exact
    bt("hbm_to_spm_node_burst_limit_4beats");
    host_fill(32'h0001_7000, 1024);                                              // (the host model itself needs the full burst limit)
    while (hq.size() != 0 || h_req_v) @(posedge clk); repeat (30) @(posedge clk);
    for (int i = 0; i < 1024; i++) sref[longint'(SPM_BASE + 32'h0400) + i] = href[40'h1_7000 + i];
    max_burst_m1 = 8'd3;
    run_dma(0, 40'h0_0001_7000, SPM_BASE + 32'h0400, 1024, 32);
    max_burst_m1 = 8'd31;
    if (last_err != SF_MEM_EXC_NONE || dma_moved != 1024) begin errors++; $display("[TB][FAIL] node burst limit: err=%0d moved=%0d", last_err, dma_moved); end
    if (dma_chunks != 16) begin errors++; $display("[TB][FAIL] node burst clamp: %0d chunks (expected 16 of 4 beats)", dma_chunks); end
    spm_check(SPM_BASE + 32'h0400, 1024, "node burst limit data");
    et("hbm_to_spm_node_burst_limit_4beats");
    // the DMA must still work after every error (no stuck flits / state)
    t_h2s("hbm_to_spm_after_errors",       32'h0001_6000, SPM_BASE + 32'h0400, 512, 8);
    et("error_paths");
    if (stat_cycles != 0) $display("[TB] DMA aggregate: %0d bytes in %0d cycles = %0.2f B/cycle (SRAM port limit 16 B/cycle)", stat_bytes, stat_cycles, real'(stat_bytes)/real'(stat_cycles));
    if (errors == 0) $display("RESULT: PASS  (tb_dma_spm BACKEND=%0d)", BACKEND); else $display("RESULT: FAIL  (tb_dma_spm BACKEND=%0d, %0d errors)", BACKEND, errors);
    $finish;
  end
  initial begin #200_000_000; $display("RESULT: FAIL  (tb_dma_spm watchdog)"); $finish; end
endmodule
