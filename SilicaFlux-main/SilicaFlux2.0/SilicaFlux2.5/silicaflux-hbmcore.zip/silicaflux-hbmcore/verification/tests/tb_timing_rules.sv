// =============================================================================
//  tb_timing_rules.sv  --  DRAM timing verification: legal AND deliberately illegal command schedules
//
//  For every timing relationship a pair of directed schedules is run against THREE independent judges:
//     (1) sf_hbm_bank_fsm   x16   (RTL, bank-local rules)         violation_o
//     (2) sf_hbm_timing           (RTL, cross-bank rules)         violation_o
//     (3) hbm4_dram_model         (behavioural, timestamp-based)  viol_cnt_o
//  A schedule at the MINIMUM legal spacing must be accepted by all judges (zero flags). The same schedule with the
//  spacing reduced by one cycle must be REJECTED by the model, and by the RTL judges for the rules they own.
//  All spacings are computed from the ACTIVE profile (hbm_timing_t), never hard-coded numbers:
//      +PROFILE=<0..2>
//  Rules whose spacing is 1 cycle cannot be violated by a different-cycle command and are reported N/A.
// =============================================================================
`timescale 1ns/1ps
module tb_timing_rules;
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;

  localparam int unsigned NB = HBM_NUM_BANKS;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  int unsigned profile_sel = 0;
  hbm_timing_t tp;

  // ---- strobes shared by the RTL judges and the model ------------------------------------------
  logic [NB-1:0] act_s, rd_s, wr_s, pre_s, refpb_s;
  logic          refab_s, mrs_s, pdx_s, srx_s;
  hbm_row_t      row_s;
  hbm_bg_t       bg_s;
  logic          cmd_v;
  hbm_cmd_t      cmd_s;
  logic          wv; hbm_data_t wd; hbm_mask_t wm;

  logic [NB-1:0] bk_viol, bk_can_act, bk_can_rd, bk_can_wr, bk_can_pre, bk_idle, bk_open;
  hbm_row_t [NB-1:0] bk_row;
  logic [NB-1:0][1:0] bk_st;
  for (genvar b = 0; b < NB; b++) begin : g_bk
    sf_hbm_bank_fsm u (.clk_i(clk), .rst_ni(rst_n), .tp_i(tp),
      .act_i(act_s[b]), .rd_i(rd_s[b]), .wr_i(wr_s[b]), .cmd_row_i(row_s), .pre_i(pre_s[b]),
      .refab_i(refab_s), .refpb_i(refpb_s[b]),
      .row_open_o(bk_open[b]), .open_row_o(bk_row[b]), .can_act_o(bk_can_act[b]), .can_rd_o(bk_can_rd[b]),
      .can_wr_o(bk_can_wr[b]), .can_pre_o(bk_can_pre[b]), .idle_o(bk_idle[b]), .state_o(bk_st[b]), .violation_o(bk_viol[b]));
  end
  logic [HBM_NUM_BG-1:0] ok_act, ok_rd, ok_wr; logic ok_ref, ok_misc, tm_busy, tm_viol;
  sf_hbm_timing u_tm (.clk_i(clk), .rst_ni(rst_n), .tp_i(tp),
    .act_i(|act_s), .rd_i(|rd_s), .wr_i(|wr_s), .bg_i(bg_s), .refab_i(refab_s), .mrs_i(mrs_s), .pdx_i(pdx_s), .srx_i(srx_s),
    .ok_act_o(ok_act), .ok_rd_o(ok_rd), .ok_wr_o(ok_wr), .ok_ref_o(ok_ref), .ok_misc_o(ok_misc), .busy_o(tm_busy), .violation_o(tm_viol));

  int unsigned mviol, mcmds;
  hbm4_dram_model #(.NUM_PC(1)) dram (.clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(1'b1), .stall_pct_i(8'd0),
    .cmd_valid_i(cmd_v), .cmd_i(cmd_s), .wvalid_i(wv), .wdata_i(wd), .wmask_i(wm), .wecc_i('0),
    .ready_o(), .rvalid_o(), .rdata_o(), .recc_o(), .rerr_o(), .viol_cnt_o(mviol), .cmd_cnt_o(mcmds));

  // ---- schedule machinery ------------------------------------------------------------------------
  typedef struct { int cyc; hbm_cmd_e cmd; int bg, ba, row, col; int wd_off; } ev_t;   // wd_off: write-data offset from WR (default WL)
  ev_t sched [$];
  int  hc;                               // harness cycle
  int  bank_flags, tm_flags;             // sticky counters of RTL-judge violation pulses
  int  total_fail;

  always @(posedge clk) if (rst_n) begin
    for (int b = 0; b < NB; b++) bank_flags += int'(bk_viol[b]);
    tm_flags += int'(tm_viol);
  end

  task automatic add(input int c, input hbm_cmd_e cm, input int bg, input int ba, input int row, input int col, input int wd_off = -1);
    ev_t e;
    e.cyc = c; e.cmd = cm; e.bg = bg; e.ba = ba; e.row = row; e.col = col; e.wd_off = wd_off;
    sched.push_back(e);
  endtask

  task automatic clear_strobes();
    act_s = '0; rd_s = '0; wr_s = '0; pre_s = '0; refpb_s = '0; refab_s = 0; mrs_s = 0; pdx_s = 0; srx_s = 0;
    cmd_v = 0; cmd_s = '0; row_s = '0; bg_s = '0; wv = 0; wd = '0; wm = '0;
  endtask

  // run `sched` from a clean reset; return judge counters
  task automatic run(input int extra, output int m_v, output int b_v, output int t_v);
    int last, wr_due [$];
    last = 0;
    foreach (sched[i]) if (sched[i].cyc + 40 > last) last = sched[i].cyc + 40;
    last += extra;
    // reset all judges
    rst_n = 0; clear_strobes(); repeat (3) @(posedge clk); #1 rst_n = 1;
    bank_flags = 0; tm_flags = 0;
    @(negedge clk);
    wr_due.delete();
    for (hc = 0; hc <= last; hc++) begin
      clear_strobes();
      foreach (sched[i]) if (sched[i].cyc == hc) begin
        int b; b = sched[i].bg * 4 + sched[i].ba;
        cmd_v = 1; cmd_s.cmd = sched[i].cmd; cmd_s.bg = hbm_bg_t'(sched[i].bg); cmd_s.ba = hbm_ba_t'(sched[i].ba);
        cmd_s.row = hbm_row_t'(sched[i].row); cmd_s.col = hbm_col_t'(sched[i].col);
        row_s = hbm_row_t'(sched[i].row); bg_s = hbm_bg_t'(sched[i].bg);
        case (sched[i].cmd)
          HCMD_ACT:    act_s[b] = 1;
          HCMD_RD:     rd_s[b]  = 1;
          HCMD_WR:     begin wr_s[b] = 1; wr_due.push_back(hc + ((sched[i].wd_off >= 0) ? sched[i].wd_off : int'(tp.wl))); end
          HCMD_PRE:    pre_s[b] = 1;
          HCMD_PREA:   pre_s = '1;
          HCMD_REF_AB: refab_s = 1;
          HCMD_REF_PB: refpb_s[b] = 1;
          HCMD_MRS:    mrs_s = 1;
          HCMD_PDX:    pdx_s = 1;
          HCMD_SRX:    srx_s = 1;
          default: ;
        endcase
      end
      // write data beat for any WR whose data is due now
      for (int k = 0; k < wr_due.size(); k++) if (wr_due[k] == hc) begin wv = 1; wd = {8{32'hA5A5_0000 + hc}}; wm = '1; end
      @(negedge clk);
    end
    m_v = int'(mviol); b_v = bank_flags; t_v = tm_flags;
    sched.delete();
  endtask

  // legal (gap = g) vs illegal (gap = g-1) pair. `build` fills `sched` with the final command at cycle base+gap.
  // dut: 1 if the RTL judges are expected to flag it (0 for rules only the model owns).
  typedef enum int { S_RCDRD, S_RCDWR, S_RAS, S_RP, S_RRD_S, S_RRD_L, S_FAW, S_CCD_S, S_CCD_L, S_WTR_S, S_WTR_L,
                     S_RTW, S_RTP, S_WR, S_REF_ENTRY, S_RFC, S_MRD, S_REFPB_RFC } scen_e;

  function automatic int gap_of(scen_e s);
    case (s)
      S_RCDRD: return int'(tp.trcdrd);   S_RCDWR: return int'(tp.trcdwr);  S_RAS: return int'(tp.tras);
      S_RP: return int'(tp.trp);         S_RRD_S: return int'(tp.trrd_s);   S_RRD_L: return int'(tp.trrd_l);
      S_FAW: return int'(tp.tfaw);       S_CCD_S: return int'(tp.tccd_s);   S_CCD_L: return int'(tp.tccd_l);
      S_WTR_S: return int'(tp.wl + tp.burst + tp.twtr_s);  S_WTR_L: return int'(tp.wl + tp.burst + tp.twtr_l);
      S_RTW: begin int v; v = int'(tp.rl + tp.burst) + 2 - int'(tp.wl); return (v < 1) ? 1 : v; end
      S_RTP: return int'(tp.trtp);       S_WR: return int'(tp.wl + tp.burst + tp.twr);
      S_REF_ENTRY: return int'(tp.trp);  S_RFC: return int'(tp.trfc);       S_MRD: return int'(tp.tmrd);
      S_REFPB_RFC: return int'(tp.trfcpb);
      default: return 1;
    endcase
  endfunction

  task automatic build(input scen_e s, input int gap);
    int T0;
    T0 = 20;                                  // quiet start so nothing from reset interferes
    sched.delete();
    case (s)
      S_RCDRD: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + gap, HCMD_RD, 0, 0, 5, 1); end
      S_RCDWR: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + gap, HCMD_WR, 0, 0, 5, 1); end
      S_RAS:   begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + gap, HCMD_PRE, 0, 0, 5, 0); end
      S_RP:    begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.tras), HCMD_PRE, 0, 0, 5, 0);
                     add(T0 + int'(tp.tras) + gap, HCMD_ACT, 0, 0, 6, 0); end
      S_RRD_S: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + gap, HCMD_ACT, 1, 0, 5, 0); end
      S_RRD_L: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + gap, HCMD_ACT, 0, 1, 5, 0); end
      S_FAW:   begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.trrd_s), HCMD_ACT, 1, 0, 5, 0);
                     add(T0 + 2*int'(tp.trrd_s), HCMD_ACT, 2, 0, 5, 0); add(T0 + 3*int'(tp.trrd_s), HCMD_ACT, 3, 0, 5, 0);
                     add(T0 + gap, HCMD_ACT, 0, 1, 5, 0); end       // 5th ACT: >= tFAW after the 1st
      S_CCD_S: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.trrd_s), HCMD_ACT, 1, 0, 5, 0);
                     add(T0 + 60, HCMD_RD, 0, 0, 5, 1);  add(T0 + 60 + gap, HCMD_RD, 1, 0, 5, 1); end
      S_CCD_L: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.trrd_l), HCMD_ACT, 0, 1, 5, 0);
                     add(T0 + 60, HCMD_RD, 0, 0, 5, 1);  add(T0 + 60 + gap, HCMD_RD, 0, 1, 5, 1); end
      S_WTR_S: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.trrd_s), HCMD_ACT, 1, 0, 5, 0);
                     add(T0 + 60, HCMD_WR, 0, 0, 5, 1);  add(T0 + 60 + gap, HCMD_RD, 1, 0, 5, 1); end
      S_WTR_L: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.trrd_l), HCMD_ACT, 0, 1, 5, 0);
                     add(T0 + 60, HCMD_WR, 0, 0, 5, 1);  add(T0 + 60 + gap, HCMD_RD, 0, 1, 5, 1); end
      S_RTW:   begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.trrd_s), HCMD_ACT, 1, 0, 5, 0);
                     add(T0 + 60, HCMD_RD, 0, 0, 5, 1);  add(T0 + 60 + gap, HCMD_WR, 1, 0, 5, 1); end
      S_RTP:   begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.tras), HCMD_RD, 0, 0, 5, 1);
                     add(T0 + int'(tp.tras) + gap, HCMD_PRE, 0, 0, 5, 0); end
      S_WR:    begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.tras), HCMD_WR, 0, 0, 5, 1);
                     add(T0 + int'(tp.tras) + gap, HCMD_PRE, 0, 0, 5, 0); end
      S_REF_ENTRY: begin add(T0, HCMD_ACT, 0, 0, 5, 0);  add(T0 + int'(tp.tras), HCMD_PRE, 0, 0, 5, 0);
                     add(T0 + int'(tp.tras) + gap, HCMD_REF_AB, 0, 0, 0, 0); end
      S_RFC:   begin add(T0, HCMD_REF_AB, 0, 0, 0, 0);  add(T0 + gap, HCMD_ACT, 0, 0, 5, 0); end
      S_MRD:   begin add(T0, HCMD_MRS, 0, 0, 0, 0);     add(T0 + gap, HCMD_ACT, 0, 0, 5, 0); end
      S_REFPB_RFC: begin add(T0, HCMD_REF_PB, 0, 0, 0, 0);  add(T0 + gap, HCMD_ACT, 0, 0, 5, 0); end
      default: ;
    endcase
  endtask

  task automatic check_pair(input string name, input scen_e s, input bit dut_owns_it);
    int g, mv, bv, tv, mv2, bv2, tv2;
    g = gap_of(s);
    if (g <= 1) begin $display("[TB] RULE %-14s N/A (spacing %0d cycle: cannot be violated by a distinct-cycle command)", name, g); return; end
    build(s, g);     run(0, mv, bv, tv);
    build(s, g - 1); run(0, mv2, bv2, tv2);
    if (mv != 0 || bv != 0 || tv != 0) begin
      $display("[TB][FAIL] RULE %-14s LEGAL schedule (gap=%0d) was rejected: model=%0d bank=%0d timing=%0d", name, g, mv, bv, tv); total_fail++;
    end else if (mv2 == 0) begin
      $display("[TB][FAIL] RULE %-14s ILLEGAL schedule (gap=%0d) NOT detected by the DRAM model", name, g - 1); total_fail++;
    end else if (dut_owns_it && (bv2 + tv2) == 0) begin
      $display("[TB][FAIL] RULE %-14s ILLEGAL schedule (gap=%0d) NOT detected by the RTL timing engines (model saw %0d)", name, g - 1, mv2); total_fail++;
    end else
      $display("[TB] RULE %-14s legal gap=%-3d accepted by all judges | gap=%-3d rejected: model=%0d bank_fsm=%0d timing=%0d  PASS", name, g, g - 1, mv2, bv2, tv2);
  endtask

  // ---- stand-alone illegal traces (always illegal) -----------------------------------------------------
  task automatic check_illegal(input string name, input bit dut_owns_it);
    int mv, bv, tv;
    run(0, mv, bv, tv);
    if (mv == 0) begin $display("[TB][FAIL] TRACE %-26s illegal trace NOT detected by the model", name); total_fail++; end
    else if (dut_owns_it && (bv + tv) == 0) begin $display("[TB][FAIL] TRACE %-26s NOT detected by the RTL engines (model=%0d)", name, mv); total_fail++; end
    else $display("[TB] TRACE %-26s rejected: model=%0d bank_fsm=%0d timing=%0d  PASS", name, mv, bv, tv);
  endtask

  initial begin
    int mv, bv, tv;
    void'($value$plusargs("PROFILE=%d", profile_sel));
    tp = hbm_profile(4'(profile_sel));
    total_fail = 0; bank_flags = 0; tm_flags = 0; hc = 0;
    clear_strobes();
    $display("[TB] tb_timing_rules profile=%0d (%s)", profile_sel, (hbm_profile_status(4'(profile_sel)) == 2'd0) ? "HYPOTHETICAL_SIM" : "VERIFIED");
    // ------------------------------------------------------------------ min-spacing rules
    check_pair("ACT->RD tRCDRD",  S_RCDRD, 1);
    check_pair("ACT->WR tRCDWR",  S_RCDWR, 1);
    check_pair("ACT->PRE tRAS",   S_RAS, 1);
    check_pair("PRE->ACT tRP",    S_RP, 1);
    check_pair("ACT->ACT tRRD_S", S_RRD_S, 1);
    check_pair("ACT->ACT tRRD_L", S_RRD_L, 1);
    check_pair("4-ACT tFAW",      S_FAW, 1);
    check_pair("RD->RD tCCD_S",   S_CCD_S, 1);
    check_pair("RD->RD tCCD_L",   S_CCD_L, 1);
    check_pair("WR->RD tWTR_S",   S_WTR_S, 1);
    check_pair("WR->RD tWTR_L",   S_WTR_L, 1);
    check_pair("RD->WR tRTW",     S_RTW, 1);
    check_pair("RD->PRE tRTP",    S_RTP, 1);
    check_pair("WR->PRE tWR",     S_WR, 1);
    check_pair("PRE->REF tRP",    S_REF_ENTRY, 0);       // bank-local idleness: judged by model (and bank_fsm via refab)
    check_pair("REF->ACT tRFC",   S_RFC, 1);
    check_pair("REFPB->ACT tRFCpb", S_REFPB_RFC, 1);
    check_pair("MRS->cmd tMRD",   S_MRD, 0);             // tMRD is a DRAM-model rule; the RTL gates it via ok_ref/misc flags
    // ------------------------------------------------------------------ always-illegal traces
    sched.delete(); add(20, HCMD_RD, 0, 0, 5, 1);                                                   check_illegal("RD to precharged bank", 1);
    sched.delete(); add(20, HCMD_ACT, 0, 0, 5, 0); add(20 + int'(tp.trcdrd) + 2, HCMD_RD, 0, 0, 6, 1);  check_illegal("RD to the wrong row", 1);
    sched.delete(); add(20, HCMD_ACT, 0, 0, 5, 0); add(20 + int'(tp.trc) + 5, HCMD_ACT, 0, 0, 6, 0);   check_illegal("ACT to an open bank", 1);
    sched.delete(); add(20, HCMD_ACT, 0, 0, 5, 0); add(20 + 50, HCMD_REF_AB, 0, 0, 0, 0);              check_illegal("REF_AB with a bank open", 1);
    sched.delete(); add(20, HCMD_PDE, 0, 0, 0, 0); add(30, HCMD_ACT, 0, 0, 5, 0);                       check_illegal("ACT while in power-down", 0);
    sched.delete(); add(20, HCMD_PDE, 0, 0, 0, 0); add(30, HCMD_PDX, 0, 0, 0, 0); add(30 + int'(tp.txp) - 1, HCMD_ACT, 0, 0, 5, 0);
                                                                                                        check_illegal("ACT inside tXP", 0);
    sched.delete(); add(20, HCMD_SRE, 0, 0, 0, 0); add(30, HCMD_SRX, 0, 0, 0, 0); add(30 + int'(tp.txs) - 1, HCMD_ACT, 0, 0, 5, 0);
                                                                                                        check_illegal("ACT inside tXS", 0);
    sched.delete(); add(20, HCMD_PDX, 0, 0, 0, 0);                                                      check_illegal("PDX while not in power-down", 0);
    sched.delete(); add(20, HCMD_ACT, 0, 0, 5, 0); add(20 + int'(tp.trcdwr), HCMD_WR, 0, 0, 5, 1, int'(tp.wl) + 1);
                                                                                                        check_illegal("write data one cycle late", 0);
    sched.delete(); add(20, HCMD_ACT, 0, 0, 5, 0); add(20 + int'(tp.trcdwr), HCMD_WR, 0, 0, 5, 1, int'(tp.wl) - 1);
                                                                                                        check_illegal("write data one cycle early", 0);
    // refresh deadline: nothing refreshes for longer than (max_postpone+1)*tREFI + tRFC + 4*tRC
    sched.delete(); add(20 + (int'(tp.max_postpone) + 2) * int'(tp.trefi) + int'(tp.trfc) + 4 * int'(tp.trc), HCMD_NOP, 0, 0, 0, 0);
                                                                                                        check_illegal("refresh deadline overrun", 0);
    // ------------------------------------------------------------------ a fully legal mixed schedule must be clean
    begin
      int T; T = 20;
      sched.delete();
      add(T, HCMD_ACT, 0, 0, 5, 0);
      add(T + int'(tp.trrd_s), HCMD_ACT, 1, 1, 9, 0);
      add(T + 60, HCMD_WR, 0, 0, 5, 3);
      add(T + 60 + int'(tp.wl + tp.burst + tp.twtr_s), HCMD_RD, 1, 1, 9, 2);
      add(T + 160, HCMD_PREA, 0, 0, 0, 0);
      add(T + 160 + int'(tp.trp), HCMD_REF_AB, 0, 0, 0, 0);
      add(T + 160 + int'(tp.trp) + int'(tp.trfc), HCMD_ACT, 2, 2, 7, 0);
      run(0, mv, bv, tv);
      if (mv != 0 || bv != 0 || tv != 0) begin $display("[TB][FAIL] legal mixed schedule flagged: model=%0d bank=%0d timing=%0d", mv, bv, tv); total_fail++; end
      else $display("[TB] TRACE %-26s accepted by all judges  PASS", "legal mixed schedule (ACT/WR/RD/PREA/REF)");
    end
    if (total_fail == 0) $display("RESULT: PASS  (tb_timing_rules profile %0d)", profile_sel);
    else                 $display("RESULT: FAIL  (tb_timing_rules profile %0d, %0d failing checks)", profile_sel, total_fail);
    $finish;
  end
  initial begin #50_000_000; $display("RESULT: FAIL (tb_timing_rules watchdog)"); $finish; end
endmodule
