// =============================================================================
//  tb_bench.sv -- reproducible memory-controller benchmarks (A..L of the project brief)
//
//  *** ALL NUMBERS FROM THIS BENCH ARE MODELLED (RTL simulation against the behavioural DRAM model with a
//  HYPOTHETICAL timing profile). They are NOT measurements of hardware and not HBM4 performance. ***
//
//  INGRESS MODES
//    PORTS=1  channel-sliced ingress: every pseudo-channel has its own request port (how a channel-sliced fabric
//             would feed 32 channels). Sources enqueue into per-pseudo-channel software FIFOs; each pseudo-channel
//             presents one request per cycle with valid held until accepted.
//    PORTS=0  the single host port of sf_hbm4_controller (<= 1 granule / cycle = 32 B/cycle): shows the ingress limit.
//  SOURCES: NSRC independent request generators (accelerators), each limited to WINDOW outstanding requests and
//  ISSUE_W new requests per cycle (workload parallelism). Only the generators differ between benchmarks.
//
//  BENCHMARKS (+BENCH=<letter>)
//    A seq stream reads   B seq stream writes   C balanced rd/wr streams   D uniform random
//    E single-channel hotspot   F all-channel spread (random over the full capacity)   G high row locality
//    H low row locality   I refresh under sustained streaming   J competing accelerators (QoS)
//    K TensorCore GEMM tile loading (double buffered)   L FP64 STREAM triad
//
//  OUTPUT (+JSON=<file>): requested/completed bytes, simulated cycles/time, achieved GB/s, latency mean/min/max + exact
//  histogram (percentiles are computed by python/hbm4/performance.py from it), row-hit rate, queue/timing/refresh stalls,
//  per-pseudo-channel utilisation, refresh overhead, per-source stats, DRAM-model violations (must be 0).
//  +TIMELINE=<file> additionally dumps a down-sampled activity trace for the dashboard.
// =============================================================================
`timescale 1ns/1ps
module tb_bench;
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;

  parameter int unsigned NCH   = 4;
  parameter int unsigned CHCL  = 4;
  parameter int unsigned QD    = 16;
  parameter int unsigned CPLD  = 8;           // completion-sequencer depth per pseudo-channel (in-flight column commands)
  parameter int unsigned PORTS = 1;           // 1 = per-pseudo-channel ingress, 0 = single host port of sf_hbm4_controller
  localparam int unsigned NPC  = NCH * 2;
  localparam int unsigned CH_BITS = (NCH > 1) ? $clog2(NCH) : 0;
  localparam int unsigned CAPBITS = hbm_cap_bits(0, CH_BITS, 1);
  localparam int unsigned MAXSRC = 16;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  longint unsigned cyc; always @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  // ---------------------------------------------------------------- configuration
  int unsigned profile_sel = 1, policy = 1, map_mode = 1, il = 0, hash = 0, page_pol = 0, ref_mode = 0, batch_on = 0, prio_on = 0;
  int unsigned nsrc = 8, window = 64, issue_w = 4, nreq = 4000, ecc_on = 0, deadline_on = 0;
  string bench;
  hbm_cfg_t cfg;
  hbm_timing_t tp;

  // ---------------------------------------------------------------- DRAM model
  logic [NPC-1:0] pready, scv, swv, srv, srerr;
  hbm_cmd_t [NPC-1:0] sc; hbm_data_t [NPC-1:0] swd, srd; hbm_mask_t [NPC-1:0] swm; hbm_ecc_t [NPC-1:0] swe, sre;
  int unsigned viol_cnt, cmd_cnt;
  hbm4_dram_model #(.NUM_PC(NPC)) dram (.clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(1'b0), .stall_pct_i(8'd0),
    .cmd_valid_i(scv), .cmd_i(sc), .wvalid_i(swv), .wdata_i(swd), .wmask_i(swm), .wecc_i(swe),
    .ready_o(pready), .rvalid_o(srv), .rdata_o(srd), .recc_o(sre), .rerr_o(srerr), .viol_cnt_o(viol_cnt), .cmd_cnt_o(cmd_cnt));

  // ---------------------------------------------------------------- controller
  hbm_pc_stat_t [NPC-1:0] stat;
  logic ready;
  // per-PC request/response ports (PORTS=1) or the host port (PORTS=0)
  logic [NPC-1:0] p_req_v, p_req_r, p_rsp_v; hbm_txn_t [NPC-1:0] p_txn; hbm_data_t [NPC-1:0] p_wd; hbm_mask_t [NPC-1:0] p_wm;
  hbm_rsp_t [NPC-1:0] p_rsp;
  // host port
  logic hp_v, hp_r; hbm_addr_t hp_a; logic hp_w; hbm_id_t hp_id; hbm_src_t hp_src; hbm_qos_t hp_q; hbm_data_t hp_wd; hbm_mask_t hp_wm;
  logic hr_v; hbm_rsp_t hr_rsp; logic e_acc, e_accr, e_accw, e_err, e_sid, e_sq, e_sf; logic [15:0] outst; logic infeas;

  if (PORTS == 1) begin : g_ports
    for (genvar p = 0; p < NPC; p++) begin : g_pc
      logic sv; hbm_cmd_t scmd; logic wv; hbm_data_t wd; hbm_mask_t wm; hbm_ecc_t we; logic ok; hbm_pc_stat_t st;
      logic [15:0] lat; logic [5:0] bytes; logic [5:0] occ; logic [2:0] pws; logic [31:0] r0, r1, r2; logic signed [7:0] debt; logic quiet, unimpl;
      logic [31:0] c0, c1, c2, c3; logic lv, lue, alert; logic [8:0] lsyn; hbm_pc_evt_t evt; logic [HBM_NUM_BANKS-1:0][1:0] bst;
      sf_hbm_pseudochannel #(.DEPTH(QD), .CPL_DEPTH(CPLD), .PEND_DEPTH(QD)) pc (
        .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .sched_cfg_i(cfg.sched), .ref_cfg_i(cfg.ref_cfg), .ecc_en_i(cfg.ecc_en),
        .ctrl_enable_i(ready), .pwr_req_i(2'd0), .pd_idle_i(16'd0), .sr_idle_i(16'd0),
        .init_mrs_valid_i(1'b0), .init_mrs_code_i(8'd0), .init_mrs_ack_o(), .ecc_clear_i(1'b0), .inj_arm_i(1'b0), .inj_mode_i(2'd0), .inj_bit_i(9'd0),
        .req_valid_i(p_req_v[p]), .req_ready_o(p_req_r[p]), .req_txn_i(p_txn[p]), .req_wdata_i(p_wd[p]), .req_wmask_i(p_wm[p]),
        .rsp_valid_o(p_rsp_v[p]), .rsp_ready_i(1'b1), .rsp_o(p_rsp[p]),
        .phy_ready_ext_i(pready[p]), .phy_event_i(1'b0), .ondie_event_i(1'b0),
        .sim_cmd_valid_o(scv[p]), .sim_cmd_o(sc[p]), .sim_wvalid_o(swv[p]), .sim_wdata_o(swd[p]), .sim_wmask_o(swm[p]), .sim_wecc_o(swe[p]),
        .sim_rvalid_i(srv[p]), .sim_rdata_i(srd[p]), .sim_recc_i(sre[p]), .sim_rerr_i(srerr[p]),
        .evt_o(evt), .lat_o(lat), .rsp_bytes_o(bytes), .occ_o(occ), .pwr_state_o(pws), .res_active_o(r0), .res_pd_o(r1), .res_sr_o(r2),
        .ref_debt_o(debt), .quiet_o(quiet), .backend_unimplemented_o(unimpl), .ecc_ce_o(c0), .ecc_ue_o(c1), .phy_err_o(c2), .ondie_err_o(c3),
        .ecc_log_valid_o(lv), .ecc_log_ue_o(lue), .ecc_log_syn_o(lsyn), .ecc_alert_o(alert), .bank_state_o(bst), .dbg_cmd_valid_o(), .dbg_cmd_o());
      assign stat[p] = '{evt: evt, lat: lat, bytes: bytes, occ: 6'(occ), pwr_state: pws, debt: debt, quiet: quiet, unimpl: unimpl,
                         ecc_alert: alert, ecc_lv: lv, ecc_lue: lue, ecc_lsyn: lsyn, bank_state: bst};
    end
    assign ready = 1'b1;
  end else begin : g_top
    logic pg = 0, cs = 0, pid = 0, tdn = 0, rdy, pis, ts, ierr; logic [2:0] ic, ist;
    sf_hbm4_controller #(.NUM_STACKS(1), .NUM_CHANNELS(NCH), .CH_PER_CLUSTER(CHCL), .DEPTH(QD), .CPL_DEPTH(CPLD), .TRK_SRC_W(4), .TRK_ID_W(6)) ctl (
      .clk_i(clk), .rst_ni(rst_n), .cfg_i(cfg), .power_good_i(pg), .clk_stable_i(cs), .phy_init_done_i(pid), .train_done_i(tdn),
      .phy_init_start_o(pis), .train_start_o(ts), .ready_o(rdy), .init_error_o(ierr), .init_cause_o(ic), .init_state_o(ist),
      .req_valid_i(hp_v), .req_ready_o(hp_r), .req_addr_i(hp_a), .req_write_i(hp_w), .req_fence_i(1'b0), .req_id_i(hp_id),
      .req_src_i(hp_src), .req_qos_i(hp_q), .req_order_i(ORD_RELAXED), .req_wdata_i(hp_wd), .req_wmask_i(hp_wm),
      .rsp_valid_o(hr_v), .rsp_ready_i(1'b1), .rsp_o(hr_rsp), .ecc_clear_i(1'b0), .inj_arm_i(1'b0), .inj_pc_i('0), .inj_mode_i('0), .inj_bit_i('0),
      .phy_ready_ext_i(pready), .phy_event_i('0), .ondie_event_i('0),
      .sim_cmd_valid_o(scv), .sim_cmd_o(sc), .sim_wvalid_o(swv), .sim_wdata_o(swd), .sim_wmask_o(swm), .sim_wecc_o(swe),
      .sim_rvalid_i(srv), .sim_rdata_i(srd), .sim_recc_i(sre), .sim_rerr_i(srerr), .stat_o(stat),
      .ev_accept_o(e_acc), .ev_accept_rd_o(e_accr), .ev_accept_wr_o(e_accw), .ev_err_req_o(e_err), .ev_stall_id_o(e_sid),
      .ev_stall_q_o(e_sq), .ev_stall_fence_o(e_sf), .outstanding_o(outst), .ref_cfg_infeasible_o(infeas));
    assign ready = rdy;
    initial begin
      @(posedge rst_n); repeat (3) @(posedge clk); pg = 1; repeat (2) @(posedge clk); cs = 1; wait (pis); repeat (2) @(posedge clk);
      pid = 1; wait (ts); repeat (2) @(posedge clk); tdn = 1;
    end
  end

  // ---------------------------------------------------------------- traffic
  typedef struct { longint addr; bit wr; int src; int qos; longint t_gen; } item_t;
  item_t   pq [int][$];                 // per-pseudo-channel software FIFO (assoc array of queues: pop works on assoc elements)
  item_t   hq [$];                      // host-port FIFO (PORTS=0)
  int      src_out [MAXSRC];            // outstanding per source
  longint  src_gen [MAXSRC];            // generated per source
  longint  src_done [MAXSRC];
  longint  src_bytes [MAXSRC];
  longint  src_lat_sum [MAXSRC];
  longint  src_lat_max [MAXSRC];
  int      src_qos [MAXSRC];
  longint  src_target [MAXSRC];
  longint  t_acc [MAXSRC][256];
  longint  t_gen_tab [MAXSRC][256];
  int      id_ctr [MAXSRC];
  longint  total_gen, total_done, total_acc, bytes_req, bytes_done_rd, bytes_done_wr;
  longint  lat_hist [int];              // controller latency (accept -> response), exact histogram
  longint  e2e_sum, lat_sum, lat_n, lat_max, lat_min;
  longint  pc_busy [NPC], pc_bytes [NPC], pc_cmp [NPC];
  longint  q_stall_cyc, id_stall_cyc;
  longint  s_hit, s_empty, s_conf, s_act, s_pre, s_ref, s_tst, s_rst, s_qos, s_byp;
  longint  t_start, t_end;
  longint  expected_total;
  longint  occ_sum;
  longint  pc_cmds_rd [NPC];
  int      timeline_fd;
  longint  tl_next;
  string   json_path, tl_path, trace_path;
  longint  tr_cyc [$]; longint tr_addr [$]; bit tr_wr [$]; int tr_src [$];   // bench R: replayed access trace (arrival cycle, address, write, source)
  int      tr_pos;

  // ---- address helpers --------------------------------------------------------------------------------------
  function automatic longint addr_of(int stk, int ch, int pcn, int bg, int ba, int row, int col);
    hbm_loc_t l; l = '0; l.stk = 3'(stk); l.ch = 6'(ch); l.pc = 2'(pcn); l.bg = hbm_bg_t'(bg); l.ba = hbm_ba_t'(ba); l.row = hbm_row_t'(row); l.col = hbm_col_t'(col);
    return longint'(hbm_unmap_loc(l, hbm_map_e'(map_mode[1:0]), il[2:0], hash[0], 0, CH_BITS, 1));
  endfunction
  function automatic int pc_of(longint a);
    hbm_loc_t l; l = hbm_map_addr(hbm_addr_t'(a), hbm_map_e'(map_mode[1:0]), il[2:0], hash[0], 0, CH_BITS, 1);
    return int'(l.ch) * 2 + int'(l.pc);
  endfunction
  function automatic hbm_txn_t txn_of(longint a, bit wr, int src, int id, int qos);
    hbm_loc_t l; hbm_txn_t t;
    l = hbm_map_addr(hbm_addr_t'(a), hbm_map_e'(map_mode[1:0]), il[2:0], hash[0], 0, CH_BITS, 1);
    t = '0; t.src = hbm_src_t'(src); t.id = hbm_id_t'(id); t.qos = hbm_qos_t'(qos); t.write = wr; t.err = HERR_NONE;
    t.bg = l.bg; t.ba = l.ba; t.row = l.row; t.col = l.col; return t;
  endfunction

  // ---- generators -------------------------------------------------------------------------------------------
  longint seq_ptr [MAXSRC];
  longint gseq;
  int     gem_stage [MAXSRC];
  longint region_gran;
  function automatic longint rnd_gran(); return longint'($urandom) % region_gran; endfunction

  // GEMM (K) schedule state (source 0 only)
  int unsigned tile = 128, elem = 4, tc_macs = 4096, gem_m = 512;
  longint gm_i, gm_j, gm_k;
  longint tile_base_a = 64'h0000_0000, tile_base_b = 64'h0400_0000, tile_base_c = 64'h0800_0000;

  // produce next item of source s; returns 0 when the source has nothing left to generate
  function automatic bit next_item(int s, output item_t it);
    longint g;
    it.src = s; it.qos = src_qos[s]; it.t_gen = cyc; it.wr = 0; it.addr = 0;
    if (src_gen[s] >= src_target[s]) return 0;
    case (bench)
      // ONE logically sequential buffer shared by the parallel engines (engine s takes whichever granule is next):
      // the combined request stream is perfectly sequential, which is what a streaming DMA/accelerator presents
      "A", "I": begin g = gseq++; it.addr = (g % region_gran) * 32; it.wr = 0; end
      "B":      begin g = gseq++; it.addr = (g % region_gran) * 32; it.wr = 1; end
      "C":      begin g = gseq++; it.wr = g[0]; it.addr = ((g >> 1) % (region_gran / 2) + (it.wr ? region_gran / 2 : 0)) * 32; end   // read stream + write stream
      "D":      begin it.addr = rnd_gran() * 32; it.wr = ($urandom % 100) < 30; end
      "F":      begin // PERFECTLY BALANCED across every pseudo-channel (deterministic round-robin), random bank/row/column inside it
                  longint k; int pcc; k = gseq++; pcc = int'(k % NPC);
                  it.addr = addr_of(0, pcc / 2, pcc % 2, $urandom % 4, $urandom % 4, $urandom % 1024, $urandom % 64); it.wr = ($urandom % 100) < 30; end
      "E":      begin it.addr = addr_of(0, 0, 0, $urandom % 4, $urandom % 4, $urandom % 64, $urandom % 64); it.wr = ($urandom % 100) < 30; end
      "G":      begin // each source owns one bank per pseudo-channel and walks the 64 columns of a row on a pseudo-channel before the next
                  longint k; int pcc; int colv; int rowv;
                  k = seq_ptr[s]++; pcc = int'(k % NPC); colv = int'((k / NPC) % 64); rowv = int'((k / (NPC * 64)) % 32);
                  it.addr = addr_of(0, pcc / 2, pcc % 2, (s / 4) % 4, s % 4, rowv + 100 * s, colv); it.wr = ($urandom % 100) < 20; end
      "H":      begin // every access to a random row of the source's bank: nearly every access is a row miss/conflict
                  it.addr = addr_of(0, $urandom % NCH, $urandom % 2, (s / 4) % 4, s % 4, $urandom % 4096, $urandom % 64); it.wr = ($urandom % 100) < 20; end
      "J":      begin
                  case (s % 4)
                    0: begin g = gseq++; it.addr = (g % region_gran) * 32; it.wr = 0; end                                              // streaming
                    1: begin it.addr = rnd_gran() * 32; it.wr = ($urandom % 100) < 50; end                                               // random mixed
                    2: begin it.addr = addr_of(0, 0, 0, $urandom % 4, $urandom % 4, $urandom % 64, $urandom % 64); it.wr = 0; end         // hotspot on PC0
                    default: begin it.addr = rnd_gran() * 32; it.wr = 0; end                                                             // latency-critical (RT)
                  endcase end
      "L":      begin // STREAM triad a[i] = b[i] + s*c[i]: 8-byte elements, 4 per granule; per element-group: read b, read c, write a
                  longint grp; grp = gseq++;
                  it.addr = (((grp / 3) % (region_gran / 3)) + (grp % 3) * (region_gran / 3)) * 32;
                  it.wr = (grp % 3 == 2); end
      default:  begin g = seq_ptr[s]++; it.addr = (g % region_gran) * 32; end
    endcase
    it.addr = it.addr & ((longint'(1) << CAPBITS) - 1) & ~longint'(31);
    src_gen[s]++; return 1;
  endfunction

  // ---- GEMM tile loader state machine (bench K): produces a request burst per tile load, paced by double buffering ----
  longint gem_compute_busy, gem_total_steps, gem_steps_done, gem_loads_issued, gem_loaded_bytes, gem_stall_wait;
  longint gem_load_pending;          // granule requests of the current tile load still outstanding
  longint gem_compute_left;          // compute cycles left for the current step
  bit     gem_have_ready, gem_computing, gem_loading;
  longint gem_step_load_start, gem_load_lat_sum, gem_load_lat_n;
  longint gem_c_pending;
  task automatic gem_enqueue_load(input longint a_base, input longint b_base);
    // one k-step loads an A tile (tile rows x tile*elem bytes, row stride gem_m*elem) and a B tile of the same shape
    longint rowbytes; int rg; item_t it;
    rowbytes = longint'(tile) * elem; rg = int'(rowbytes / 32);
    for (int t2 = 0; t2 < 2; t2++) begin
      longint base; base = (t2 == 0) ? a_base : b_base;
      for (int r = 0; r < int'(tile); r++) for (int g = 0; g < rg; g++) begin
        it.src = 0; it.qos = 0; it.t_gen = cyc; it.wr = 0;
        it.addr = (base + longint'(r) * longint'(gem_m) * elem + longint'(g) * 32) & ((longint'(1) << CAPBITS) - 1) & ~longint'(31);
        pq[pc_of(it.addr)].push_back(it); src_gen[0]++; src_out[0]++; gem_load_pending++; total_gen++;
      end
    end
    bytes_req += 2 * rowbytes * tile;
  endtask
  task automatic gem_enqueue_store(input longint c_base);
    longint rowbytes; int rg; item_t it;
    rowbytes = longint'(tile) * elem; rg = int'(rowbytes / 32);
    for (int r = 0; r < int'(tile); r++) for (int g = 0; g < rg; g++) begin
      it.src = 0; it.qos = 0; it.t_gen = cyc; it.wr = 1;
      it.addr = (c_base + longint'(r) * longint'(gem_m) * elem + longint'(g) * 32) & ((longint'(1) << CAPBITS) - 1) & ~longint'(31);
      pq[pc_of(it.addr)].push_back(it); src_gen[0]++; src_out[0]++; gem_c_pending++; total_gen++;
    end
    bytes_req += rowbytes * tile;
  endtask

  // ---------------------------------------------------------------- per-cycle engine
  int      pc_hold_valid [NPC];
  item_t   pc_hold [NPC];
  hbm_txn_t pc_hold_txn [NPC];
  longint  pc_hold_seq [NPC];
  longint  req_seq;
  logic    running, finished;
  longint  tcount;

  function automatic int alloc_id(int s); int i; i = id_ctr[s]; id_ctr[s] = (id_ctr[s] + 1) % 256; return i; endfunction

  always @(posedge clk) if (rst_n && running) begin
    item_t it;
    // ---- 1. completions (response ports) -------------------------------------------------------------------
    for (int p = 0; p < NPC; p++) begin
      logic rv; hbm_rsp_t rr;
      rv = (PORTS == 1) ? p_rsp_v[p] : 1'b0; rr = p_rsp[p];
      if (PORTS == 1 && rv) begin
        int s, id; longint l;
        s = int'(rr.src); id = int'(rr.id); l = int'(cyc) - t_acc[s][id];
        src_out[s]--; src_done[s]++; src_bytes[s] += 32; total_done++;
        lat_sum += l; lat_n++; if (l > lat_max) lat_max = l; if (l < lat_min) lat_min = l;
        if (lat_hist.exists(int'(l))) lat_hist[int'(l)]++; else lat_hist[int'(l)] = 1;
        src_lat_sum[s] += l; if (l > src_lat_max[s]) src_lat_max[s] = l;
        e2e_sum += int'(cyc) - t_gen_tab[s][id];
        if (rr.write) bytes_done_wr += 32; else bytes_done_rd += 32;
        t_end = cyc;
      end
    end
    if (PORTS == 0 && hr_v) begin
      int s, id; longint l;
      s = int'(hr_rsp.src); id = int'(hr_rsp.id); l = int'(cyc) - t_acc[s][id];
      src_out[s]--; src_done[s]++; src_bytes[s] += 32; total_done++;
      lat_sum += l; lat_n++; if (l > lat_max) lat_max = l; if (l < lat_min) lat_min = l;
      if (lat_hist.exists(int'(l))) lat_hist[int'(l)]++; else lat_hist[int'(l)] = 1;
      src_lat_sum[s] += l; if (l > src_lat_max[s]) src_lat_max[s] = l;
      e2e_sum += int'(cyc) - t_gen_tab[s][id];
      if (hr_rsp.write) bytes_done_wr += 32; else bytes_done_rd += 32;
      t_end = cyc;
    end

    // ---- 2. GEMM state machine (bench K) ---------------------------------------------------------------------------
    if (bench == "K") begin
      // gem_load_pending counts granule loads not yet answered; recount from responses
      // (done via src_out[0] and the pending counters below)
    end

    // ---- 3. generation: sources -> per-PC software FIFOs --------------------------------------------------------------
    if (bench == "R") begin
      // replay: an access is released at its arrival cycle (relative to the run start) if its source has window space (in-order per trace)
      while (tr_pos < tr_cyc.size() && tr_cyc[tr_pos] <= (int'(cyc) - int'(t_start)) && src_out[tr_src[tr_pos] % MAXSRC] < int'(window)) begin
        item_t r;
        r.src = tr_src[tr_pos] % MAXSRC; r.qos = 0; r.t_gen = cyc; r.wr = tr_wr[tr_pos];
        r.addr = tr_addr[tr_pos] & ((longint'(1) << CAPBITS) - 1) & ~longint'(31);
        pq[(PORTS == 1) ? pc_of(r.addr) : 0].push_back(r);
        src_out[r.src]++; src_gen[r.src]++; total_gen++; bytes_req += 32; tr_pos++;
      end
    end
    if (bench != "K" && bench != "R") begin
      for (int s = 0; s < int'(nsrc); s++) begin
        for (int w = 0; w < int'(issue_w); w++) begin
          if (src_out[s] >= int'(window)) break;
          // RT source of bench J issues at a low rate (1 request / 32 cycles)
          if (bench == "J" && (s % 4) == 3 && (cyc % 32) != 0) break;
          if (!next_item(s, it)) break;
          pq[(PORTS == 1) ? pc_of(it.addr) : 0].push_back(it);
          src_out[s]++; total_gen++; bytes_req += 32;
        end
      end
    end

    // ---- 4. ingress: per-PC drivers (PORTS=1) or host port (PORTS=0) ------------------------------------------------------------
    if (PORTS == 1) begin
      for (int p = 0; p < NPC; p++) begin
        // accepted this cycle?
        if (p_req_v[p] && p_req_r[p]) begin
          t_acc[pc_hold[p].src][int'(pc_hold_txn[p].id)] = cyc; total_acc++;
          pc_hold_valid[p] = 0; p_req_v[p] <= 1'b0;
        end else if (p_req_v[p] && !p_req_r[p]) q_stall_cyc++;
        if (!pc_hold_valid[p] && pq.exists(p) && pq[p].size() != 0) begin
          int id;
          pc_hold[p] = pq[p].pop_front(); id = alloc_id(pc_hold[p].src);
          t_gen_tab[pc_hold[p].src][id] = pc_hold[p].t_gen;
          pc_hold_txn[p] = txn_of(pc_hold[p].addr, pc_hold[p].wr, pc_hold[p].src, id, pc_hold[p].qos);
          pc_hold_valid[p] = 1;
          p_txn[p] <= pc_hold_txn[p]; p_wd[p] <= {8{32'(cyc)}}; p_wm[p] <= '1; p_req_v[p] <= 1'b1;
        end
      end
    end else begin
      if (hp_v && hp_r) begin t_acc[hp_src][int'(hp_id)] = cyc; total_acc++; hp_v <= 1'b0; end
      else if (hp_v && !hp_r) q_stall_cyc++;
      if ((!hp_v || hp_r) && pq.exists(0) && pq[0].size() != 0) begin
        int id; item_t h;
        h = pq[0].pop_front(); id = alloc_id(h.src); t_gen_tab[h.src][id] = h.t_gen;
        hp_a <= hbm_addr_t'(h.addr); hp_w <= h.wr; hp_id <= hbm_id_t'(id); hp_src <= hbm_src_t'(h.src); hp_q <= hbm_qos_t'(h.qos);
        hp_wd <= {8{32'(cyc)}}; hp_wm <= '1; hp_v <= 1'b1;
      end
    end

    // ---- 5. statistics ------------------------------------------------------------------------------------------------------
    for (int p = 0; p < NPC; p++) begin
      s_hit += stat[p].evt.row_hit; s_empty += stat[p].evt.row_empty; s_conf += stat[p].evt.row_conflict;
      s_act += stat[p].evt.act; s_pre += stat[p].evt.pre; s_ref += stat[p].evt.refresh;
      s_tst += stat[p].evt.timing_stall; s_rst += stat[p].evt.ref_stall; s_qos += stat[p].evt.qos_stall; s_byp += stat[p].evt.bypass;
      pc_busy[p] += stat[p].evt.busy; occ_sum += stat[p].occ;
      if (stat[p].evt.cmp_rd || stat[p].evt.cmp_wr) begin pc_bytes[p] += stat[p].bytes; pc_cmp[p]++; end
    end
    if (PORTS == 0) id_stall_cyc += e_sid;
    // timeline sample
    if (timeline_fd != 0 && cyc >= tl_next) begin
      int busy_n, occ_n;
      busy_n = 0; occ_n = 0; for (int p = 0; p < NPC; p++) begin busy_n += stat[p].evt.busy; occ_n += stat[p].occ; end
      $fdisplay(timeline_fd, "{\"t\":%0d,\"busy\":%0d,\"occ\":%0d,\"done\":%0d,\"bank0\":\"%0h\"},", cyc, busy_n, occ_n, total_done, stat[0].bank_state);
      tl_next = cyc + 32;
    end
    if (total_done == total_gen && total_gen >= expected_total && bench != "K") finished = 1;
  end

  // ---- command timeline of PC0 for the dashboard (first N commands) -------------------------------------------------------------
  int cmd_log_fd; int cmd_log_n;
  always @(posedge clk) if (rst_n && running && cmd_log_fd != 0 && cmd_log_n < 6000) begin
    for (int p = 0; p < NPC; p++) if (p < 4 && scv[p]) begin
      $fdisplay(cmd_log_fd, "%0d %0d %0d %0d %0d %0d %0d", cyc, p, int'(sc[p].cmd), sc[p].bg, sc[p].ba, sc[p].row, sc[p].col);
      cmd_log_n++;
    end
  end

  // ---------------------------------------------------------------- GEMM bench driver (bench K) -----------------------------------------
  // A single in-order "TensorCore tile sequencer": for each output tile (i,j): for k in 0..K/tile: load A(i,k), B(k,j) (double buffered);
  // compute takes tile^3/tc_macs cycles per k-step; after the last k, store C(i,j).
  task automatic run_gemm();
    longint steps, comp_cycles, n_tiles_i, n_tiles_j, n_k, t_begin, t_stop;
    longint buf_ready_at;           // cycle the NEXT tile pair finished loading (prefetch)
    longint compute_end;            // cycle the current compute finishes
    longint load_target;            // responses needed for the prefetch to complete
    longint done_at_issue;
    int unsigned cflag;
    n_tiles_i = gem_m / tile; n_tiles_j = gem_m / tile; n_k = gem_m / tile;
    comp_cycles = (longint'(tile) * tile * tile + tc_macs - 1) / tc_macs;
    steps = (nreq == 0) ? n_k * 2 : longint'(nreq);          // steps = k-steps executed (nreq reused as step budget for K)
    gem_total_steps = steps; gem_steps_done = 0; gem_compute_busy = 0;
    gm_i = 0; gm_j = 0; gm_k = 0;
    t_begin = cyc; t_start = cyc;
    // prime: load the first pair
    done_at_issue = bytes_done_rd;
    gem_enqueue_load(tile_base_a + (gm_i * tile * gem_m + gm_k * tile) * elem, tile_base_b + (gm_k * tile * gem_m + gm_j * tile) * elem);
    load_target = total_done + 0;
    begin
      longint need; need = 2 * longint'(tile) * tile * elem;      // bytes
      while (bytes_done_rd - done_at_issue < need) @(posedge clk);
      gem_load_lat_sum += cyc - t_begin; gem_load_lat_n++;
    end
    for (longint st = 0; st < steps; st++) begin
      longint need, t_c0, t_l0, d0; bit last_k;
      last_k = (gm_k == n_k - 1);
      // start compute of the CURRENT pair and, in parallel, prefetch the NEXT pair (double buffering)
      t_c0 = cyc; compute_end = cyc + comp_cycles; gem_compute_busy += comp_cycles;
      if (st + 1 < steps) begin
        longint ni, nj, nk;
        nk = gm_k + 1; nj = gm_j; ni = gm_i;
        if (nk == n_k) begin nk = 0; nj = gm_j + 1; if (nj == n_tiles_j) begin nj = 0; ni = gm_i + 1; if (ni == n_tiles_i) ni = 0; end end
        d0 = bytes_done_rd; t_l0 = cyc;
        gem_enqueue_load(tile_base_a + (ni * tile * gem_m + nk * tile) * elem, tile_base_b + (nk * tile * gem_m + nj * tile) * elem);
        need = 2 * longint'(tile) * tile * elem;                    // bytes
        // wait until BOTH the compute and the prefetch are finished
        while (cyc < compute_end || (bytes_done_rd - d0) < need) @(posedge clk);
        gem_load_lat_sum += cyc - t_l0; gem_load_lat_n++;
        if (cyc > compute_end) gem_stall_wait += cyc - compute_end;           // compute waited for memory
        gm_k = nk; gm_j = nj; gm_i = ni;
      end else begin
        while (cyc < compute_end) @(posedge clk);
      end
      gem_steps_done++;
      if (last_k) begin gem_enqueue_store(tile_base_c + (gm_i * tile * gem_m + gm_j * tile) * elem); end
    end
    while (total_done < total_gen) @(posedge clk);
    t_stop = cyc; t_end = cyc; finished = 1;
  endtask

  // ---------------------------------------------------------------- main
  initial begin
    int unsigned seed;
    if (!$value$plusargs("BENCH=%s", bench)) bench = "A";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    void'($value$plusargs("PROFILE=%d", profile_sel)); void'($value$plusargs("POLICY=%d", policy)); void'($value$plusargs("MAP=%d", map_mode));
    void'($value$plusargs("IL=%d", il)); void'($value$plusargs("HASH=%d", hash)); void'($value$plusargs("PAGE=%d", page_pol));
    void'($value$plusargs("REFMODE=%d", ref_mode)); void'($value$plusargs("BATCH=%d", batch_on)); void'($value$plusargs("PRIO=%d", prio_on));
    void'($value$plusargs("NSRC=%d", nsrc)); void'($value$plusargs("WINDOW=%d", window)); void'($value$plusargs("ISSUEW=%d", issue_w));
    void'($value$plusargs("NREQ=%d", nreq)); void'($value$plusargs("DEADLINE=%d", deadline_on));
    void'($value$plusargs("TILE=%d", tile)); void'($value$plusargs("MACS=%d", tc_macs)); void'($value$plusargs("GEMM=%d", gem_m));
    if (nsrc > MAXSRC) nsrc = MAXSRC;
    gseq = 0;
    $urandom(seed);
    tp = hbm_profile(4'(profile_sel));
    cfg = '0; cfg.enable = 1; cfg.map_mode = hbm_map_e'(map_mode[1:0]); cfg.il_bits = il[2:0]; cfg.map_hash = hash[0];
    cfg.profile_sel = 4'(profile_sel); cfg.sched.policy = hbm_sched_policy_e'(policy[2:0]); cfg.sched.prio_en = prio_on[0];
    cfg.sched.batch_en = batch_on[0]; cfg.sched.batch_len = 8'd16; cfg.sched.page = hbm_page_policy_e'(page_pol[1:0]); cfg.sched.close_timeout = 16'd32;
    cfg.sched.deadline_en = deadline_on[0]; cfg.sched.deadline_thr = 16'd64; cfg.sched.starve_limit = 16'd0;
    cfg.ref_cfg.mode = hbm_ref_mode_e'(ref_mode[1:0]); cfg.ref_cfg.eager = 1; cfg.ref_cfg.pullin_en = 0;
    cfg.init_timeout = 32'd20000; cfg.ecc_en = ecc_on[0];
    region_gran = longint'(1) << (CAPBITS - 5 - 6);                      // use a 1/64 slice of the capacity so reads/writes are spread but bounded
    if (region_gran > 64'h0100_0000) region_gran = 64'h0100_0000;
    for (int s = 0; s < MAXSRC; s++) begin
      src_out[s] = 0; src_gen[s] = 0; src_done[s] = 0; src_bytes[s] = 0; src_lat_sum[s] = 0; src_lat_max[s] = 0; seq_ptr[s] = 0; id_ctr[s] = 0;
      src_qos[s] = 0; src_target[s] = nreq;
    end
    if (bench == "J") begin src_qos[0] = 0; src_qos[1] = 1; src_qos[2] = 2; src_qos[3] = 3; for (int s = 4; s < MAXSRC; s++) src_qos[s] = s % 4; src_target[3] = nreq / 8; end
    if (bench == "J" && nsrc < 4) nsrc = 4;
    if (bench == "L") region_gran = 64'h0100_0000;
    expected_total = 0; for (int s2 = 0; s2 < int'(nsrc); s2++) expected_total += src_target[s2];
    tr_pos = 0;
    if (bench == "R") begin
      int tf; longint c; string rw; longint a; int sr; int cnt;
      if (!$value$plusargs("TRACE=%s", trace_path)) begin $display("[TB] bench R needs +TRACE=<file>"); $finish; end
      tf = $fopen(trace_path, "r");
      if (tf == 0) begin $display("[TB] cannot open trace %s", trace_path); $finish; end
      cnt = 0;
      while (!$feof(tf)) begin
        if ($fscanf(tf, "%d %s %h %d\n", c, rw, a, sr) == 4) begin tr_cyc.push_back(c); tr_wr.push_back(rw == "W"); tr_addr.push_back(a); tr_src.push_back(sr); cnt++; end
        else void'($fgetc(tf));
      end
      $fclose(tf);
      expected_total = cnt;
      $display("[TB] replaying %0d accesses from %s", cnt, trace_path);
    end
    for (int p = 0; p < NPC; p++) begin pc_hold_valid[p] = 0; pc_busy[p] = 0; pc_bytes[p] = 0; pc_cmp[p] = 0; p_req_v[p] = 0; end
    total_gen = 0; total_done = 0; total_acc = 0; bytes_req = 0; bytes_done_rd = 0; bytes_done_wr = 0; lat_sum = 0; lat_n = 0; lat_max = 0; lat_min = 64'h7fff_ffff;
    e2e_sum = 0; q_stall_cyc = 0; id_stall_cyc = 0; s_hit = 0; s_empty = 0; s_conf = 0; s_act = 0; s_pre = 0; s_ref = 0; s_tst = 0; s_rst = 0; s_qos = 0; s_byp = 0;
    t_start = 0; t_end = 0; occ_sum = 0; finished = 0; running = 0; hp_v = 0; cmd_log_n = 0; timeline_fd = 0; cmd_log_fd = 0; tl_next = 0;
    gem_stall_wait = 0; gem_load_lat_sum = 0; gem_load_lat_n = 0; gem_c_pending = 0; gem_load_pending = 0; gem_compute_busy = 0;
    if ($value$plusargs("TIMELINE=%s", tl_path)) begin timeline_fd = $fopen(tl_path, "w"); $fdisplay(timeline_fd, "["); end
    if ($value$plusargs("CMDLOG=%s", tl_path)) cmd_log_fd = $fopen(tl_path, "w");
    $display("[TB] tb_bench BENCH=%s NCH=%0d NPC=%0d PORTS=%0d profile=%0d(%s) policy=%0d map=%0d il=%0d hash=%0d page=%0d refmode=%0d nsrc=%0d window=%0d issue_w=%0d nreq=%0d",
             bench, NCH, NPC, PORTS, profile_sel, (hbm_profile_status(4'(profile_sel)) == 2'd0) ? "HYPOTHETICAL_SIM" : "VERIFIED", policy, map_mode, il, hash, page_pol, ref_mode, nsrc, window, issue_w, nreq);
    rst_n = 0; repeat (4) @(posedge clk); rst_n = 1; repeat (4) @(posedge clk);
    if (PORTS == 0) wait (ready);
    repeat (2) @(posedge clk);
    t_start = cyc; running = 1;
    if (bench == "K") run_gemm();
    else begin
      int w; w = 0;
      while (!finished && w < 4000000) begin @(posedge clk); w++; end
      // let the last responses settle
      repeat (4) @(posedge clk);
    end
    running = 0;
    report();
    $finish;
  end

  // ---------------------------------------------------------------- report
  task automatic report();
    longint dur, bytes_done;
    real gbs, theo_gbs, avg_lat, hit_rate, util_sum;
    int f; int first;
    dur = t_end - t_start; if (dur < 1) dur = 1;
    bytes_done = bytes_done_rd + bytes_done_wr;
    gbs = real'(bytes_done) / real'(dur);                                   // 1 cycle = 1 ns in every shipped profile: bytes/cycle == GB/s
    theo_gbs = real'(NPC) * 32.0 / real'(tp.burst);                          // granule per `burst` cycles per PC, 1 GHz
    avg_lat = (lat_n != 0) ? real'(lat_sum) / real'(lat_n) : 0.0;
    hit_rate = ((s_hit + s_empty + s_conf) != 0) ? real'(s_hit) / real'(s_hit + s_empty + s_conf) : 0.0;
    util_sum = 0.0; for (int p = 0; p < NPC; p++) util_sum += real'(pc_busy[p]) / real'(dur);
    $display("[TB] RESULT bench=%s requested=%0d B completed=%0d B cycles=%0d  bandwidth=%0.2f GB/s (modelled, peak %0.1f)  avg_lat=%0.1f  max_lat=%0d  row_hit=%0.3f  violations=%0d",
             bench, bytes_req, bytes_done, dur, gbs, theo_gbs, avg_lat, lat_max, hit_rate, viol_cnt);
    if (timeline_fd != 0) begin $fdisplay(timeline_fd, "{}]"); $fclose(timeline_fd); end
    if (cmd_log_fd != 0) $fclose(cmd_log_fd);
    if ($value$plusargs("JSON=%s", json_path)) begin
      f = $fopen(json_path, "w");
      $fdisplay(f, "{");
      $fdisplay(f, "  \"benchmark\": \"%s\", \"status\": \"MODELLED_HYPOTHETICAL_PROFILE_NOT_HARDWARE\",", bench);
      $fdisplay(f, "  \"config\": {\"nch\": %0d, \"npc\": %0d, \"ports\": %0d, \"profile\": %0d, \"profile_status\": \"%s\", \"policy\": %0d, \"map\": %0d, \"il\": %0d, \"hash\": %0d, \"page\": %0d, \"refmode\": %0d, \"batch\": %0d, \"prio\": %0d, \"queue_depth\": %0d, \"cpl_depth\": %0d, \"nsrc\": %0d, \"window\": %0d, \"issue_w\": %0d, \"nreq\": %0d, \"clock_mhz\": 1000, \"tburst\": %0d, \"trefi\": %0d, \"trfc\": %0d},",
              NCH, NPC, PORTS, profile_sel, (hbm_profile_status(4'(profile_sel)) == 2'd0) ? "HYPOTHETICAL_SIM" : "VERIFIED", policy, map_mode, il, hash, page_pol, ref_mode, batch_on, prio_on, QD, CPLD, nsrc, window, issue_w, nreq, tp.burst, tp.trefi, tp.trfc);
      $fdisplay(f, "  \"requested_bytes\": %0d, \"completed_bytes\": %0d, \"read_bytes\": %0d, \"write_bytes\": %0d,", bytes_req, bytes_done, bytes_done_rd, bytes_done_wr);
      $fdisplay(f, "  \"cycles\": %0d, \"time_us\": %0.3f, \"bandwidth_gb_s\": %0.4f, \"peak_modelled_gb_s\": %0.3f, \"efficiency\": %0.4f,", dur, real'(dur) / 1000.0, gbs, theo_gbs, gbs / theo_gbs);
      $fdisplay(f, "  \"latency\": {\"mean\": %0.3f, \"min\": %0d, \"max\": %0d, \"count\": %0d, \"e2e_mean\": %0.3f, \"hist\": {", avg_lat, lat_min, lat_max, lat_n, (lat_n != 0) ? real'(e2e_sum) / real'(lat_n) : 0.0);
      first = 1; foreach (lat_hist[k]) begin $fwrite(f, "%s\"%0d\": %0d", first ? "" : ", ", k, lat_hist[k]); first = 0; end
      $fdisplay(f, "}},");
      $fdisplay(f, "  \"row\": {\"hit\": %0d, \"empty\": %0d, \"conflict\": %0d, \"hit_rate\": %0.4f, \"act\": %0d, \"pre\": %0d},", s_hit, s_empty, s_conf, hit_rate, s_act, s_pre);
      $fdisplay(f, "  \"stalls\": {\"queue_full_cycles\": %0d, \"timing_stall_pc_cycles\": %0d, \"refresh_stall_pc_cycles\": %0d, \"qos_bypass_events\": %0d, \"reorder_events\": %0d, \"id_order_stall_cycles\": %0d},", q_stall_cyc, s_tst, s_rst, s_qos, s_byp, id_stall_cyc);
      $fdisplay(f, "  \"refresh\": {\"commands\": %0d, \"overhead_fraction\": %0.5f},", s_ref, real'(s_ref) * real'(tp.trfc) / (real'(dur) * real'(NPC)));
      $fdisplay(f, "  \"avg_queue_occupancy_per_pc\": %0.3f, \"mean_pc_busy_fraction\": %0.4f, \"dram_violations\": %0d, \"dram_commands\": %0d,", real'(occ_sum) / real'(dur) / real'(NPC), util_sum / real'(NPC), viol_cnt, cmd_cnt);
      $fwrite(f, "  \"pc_utilisation\": [");
      for (int p = 0; p < NPC; p++) $fwrite(f, "%s%0.4f", (p == 0) ? "" : ", ", real'(pc_busy[p]) / real'(dur));
      $fdisplay(f, "],");
      $fwrite(f, "  \"pc_bytes\": [");
      for (int p = 0; p < NPC; p++) $fwrite(f, "%s%0d", (p == 0) ? "" : ", ", pc_bytes[p]);
      $fdisplay(f, "],");
      $fwrite(f, "  \"sources\": [");
      for (int s = 0; s < int'(nsrc); s++)
        $fwrite(f, "%s{\"src\": %0d, \"qos\": %0d, \"completed\": %0d, \"bytes\": %0d, \"bw_gb_s\": %0.4f, \"lat_mean\": %0.3f, \"lat_max\": %0d}",
                (s == 0) ? "" : ", ", s, src_qos[s], src_done[s], src_bytes[s], real'(src_bytes[s]) / real'(dur),
                (src_done[s] != 0) ? real'(src_lat_sum[s]) / real'(src_done[s]) : 0.0, src_lat_max[s]);
      $fdisplay(f, "]%s", (bench == "K") ? "," : "");
      if (bench == "K")
        $fdisplay(f, "  \"gemm\": {\"tile\": %0d, \"elem_bytes\": %0d, \"matrix\": %0d, \"macs_per_cycle\": %0d, \"steps\": %0d, \"compute_cycles_per_step\": %0d, \"compute_busy_cycles\": %0d, \"compute_utilisation\": %0.4f, \"compute_wait_for_memory_cycles\": %0d, \"tile_load_latency_mean\": %0.2f, \"bytes_per_step\": %0d, \"required_gb_s_at_full_rate\": %0.3f}",
                tile, elem, gem_m, tc_macs, gem_steps_done, (longint'(tile) * tile * tile + tc_macs - 1) / tc_macs, gem_compute_busy,
                real'(gem_compute_busy) / real'(dur), gem_stall_wait, (gem_load_lat_n != 0) ? real'(gem_load_lat_sum) / real'(gem_load_lat_n) : 0.0,
                2 * tile * tile * elem, real'(2 * tile * tile * elem) / real'((longint'(tile) * tile * tile + tc_macs - 1) / tc_macs));
      $fdisplay(f, "}");
      $fclose(f);
    end
  endtask
  initial begin #2_000_000_000; $display("[TB] watchdog"); report(); $finish; end
endmodule
