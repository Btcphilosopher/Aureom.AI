# PDN optimisation evidence

`pdn_sweep/variants/<experiment id>/` holds, per candidate: `result.json` (parameters, OpenROAD
records, checks, IR metrics), `regen.log`, `regen/check_*.rpt`, `export/` (the regenerated PDN
geometry + per-instance power, bulky CSVs gzip-compressed) and, for the global-route set,
`grt.log` / `grt/grt_congestion.rpt(.gz)`.

The regenerated OpenDB databases (`pdn.odb`, ≈67 MB each) are **not shipped**; they are
reproduced bit-for-bit in geometry by `make powergrid-optimise` (regeneration of the baseline was
verified identical to the original PDN, see reports/tests/reproducibility.json).
