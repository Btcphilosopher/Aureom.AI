# PDN connectivity check with OpenROAD PDNSim check_power_grid, per net.
# Env: PG_NETS (default "VDD VSS"), PG_OUT.
source [file join [expr {[info exists ::env(PG_TCL_DIR)] ? $::env(PG_TCL_DIR) : [file dirname [file normalize [info script]]]}] common.tcl]
set block [pg_load_design]
set out [pg_require PG_OUT]
file mkdir $out
foreach net [pg_env PG_NETS "VDD VSS"] {
  set n [$block findNet $net]
  if {$n eq "NULL"} { puts "PG-CHECK {\"net\":[pg_json_str $net],\"status\":\"MISSING\"}"; continue }
  set err $out/check_${net}.rpt
  set rc [catch {check_power_grid -net $net -error_file $err} res]
  set lines 0
  if {[file exists $err]} { set fh [open $err]; set lines [llength [split [string trim [read $fh]] "\n"]]; close $fh; if {[file size $err] == 0} {set lines 0} }
  puts "PG-CHECK {\"net\":[pg_json_str $net],\"type\":\"[$n getSigType]\",\"tcl_rc\":$rc,\"result\":[pg_json_str $res],\"error_file\":[pg_json_str $err],\"error_lines\":$lines}"
}
