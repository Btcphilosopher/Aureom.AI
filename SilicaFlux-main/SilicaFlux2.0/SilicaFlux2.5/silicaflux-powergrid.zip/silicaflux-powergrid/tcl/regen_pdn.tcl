# Regenerate the PDN of a placed database with modified parameters (optimisation loop).
# Rips up the existing PDN (pdngen -ripup), re-runs the design PDN script with the
# FLP_PDN_* environment overrides, checks connectivity, writes a new ODB.
# Env: PG_PDN_TCL (PDN script), FLP_PDN_* overrides, PG_OUT, PG_ODB_OUT.
source [file join [expr {[info exists ::env(PG_TCL_DIR)] ? $::env(PG_TCL_DIR) : [file dirname [file normalize [info script]]]}] common.tcl]
set block [pg_load_design]
set out [pg_require PG_OUT]
file mkdir $out
set rc [catch {pdngen -ripup} res]
puts "PG-RIPUP {\"tcl_rc\":$rc,\"result\":[pg_json_str $res]}"
set rc [catch {source [pg_require PG_PDN_TCL]} res]
puts "PG-PDN-DEFINE {\"tcl_rc\":$rc,\"result\":[pg_json_str $res]}"
if {$rc} { exit 4 }
set rc [catch {pdngen -failed_via_report $out/failed_vias.rpt} res]
puts "PG-PDNGEN {\"tcl_rc\":$rc,\"result\":[pg_json_str $res]}"
if {$rc} { exit 5 }
foreach net [pg_env PG_NETS "VDD VSS"] {
  set rc [catch {check_power_grid -net $net -error_file $out/check_${net}.rpt} res]
  puts "PG-CHECK {\"net\":[pg_json_str $net],\"tcl_rc\":$rc,\"result\":[pg_json_str $res]}"
}
set rc [catch {check_placement -verbose} res]
puts "PG-PLACEMENT {\"tcl_rc\":$rc,\"result\":[pg_json_str $res]}"
write_db [pg_require PG_ODB_OUT]
puts "PG-REGEN-DONE"
