# Preliminary global route (FastRoute) on a placed database to MEASURE routing congestion
# caused by a PDN variant.  Same settings as FloorplanLab route_estimate.tcl / ORFS
# ihp-sg13g2 fastroute.tcl: layer adjustment 0.05, signal layers Metal2-Metal5.
# Env: PG_GRT_MIN_LAYER (Metal2) PG_GRT_MAX_LAYER (Metal5) PG_GRT_ADJ (0.05) PG_GRT_ITERS (30)
source [file join [expr {[info exists ::env(PG_TCL_DIR)] ? $::env(PG_TCL_DIR) : [file dirname [file normalize [info script]]]}] common.tcl]
set block [pg_load_design]
set out [pg_require PG_OUT]
file mkdir $out
set lo [pg_env PG_GRT_MIN_LAYER Metal2]; set hi [pg_env PG_GRT_MAX_LAYER Metal5]
set_global_routing_layer_adjustment $lo-$hi [pg_env PG_GRT_ADJ 0.05]
set_routing_layers -signal $lo-$hi
set t0 [clock seconds]
set rc [catch {global_route -congestion_iterations [pg_env PG_GRT_ITERS 30] -congestion_report_file $out/grt_congestion.rpt -allow_congestion -verbose} msg]
puts "PG-GRT {\"tcl_rc\":$rc,\"seconds\":[expr {[clock seconds] - $t0}],\"result\":[pg_json_str $msg]}"
