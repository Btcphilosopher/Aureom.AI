# Load a placed design and print a machine-readable summary (PG-SUMMARY line).
source [file join [expr {[info exists ::env(PG_TCL_DIR)] ? $::env(PG_TCL_DIR) : [file dirname [file normalize [info script]]]}] common.tcl]
set block [pg_load_design]
set dbu [$block getDbUnitsPerMicron]
set die [$block getDieArea]; set core [$block getCoreArea]
set n_inst 0; set n_placed 0; set n_block 0
foreach i [$block getInsts] { incr n_inst; if {[$i isPlaced]} {incr n_placed}; if {[$i isBlock]} {incr n_block} }
set pg {}
foreach n [$block getNets] { set t [$n getSigType]; if {$t eq "POWER" || $t eq "GROUND"} { lappend pg "[pg_json_str [$n getName]]:{\"type\":\"$t\",\"swires\":[llength [$n getSWires]],\"special\":[$n isSpecial]}" } }
puts "PG-SUMMARY {\"design\":[pg_json_str [$block getName]],\"dbu\":$dbu,\"die\":\[[join [list [$die xMin] [$die yMin] [$die xMax] [$die yMax]] ,]\],\"core\":\[[join [list [$core xMin] [$core yMin] [$core xMax] [$core yMax]] ,]\],\"instances\":$n_inst,\"placed\":$n_placed,\"blocks\":$n_block,\"pg_nets\":{[join $pg ,]},\"openroad\":[pg_json_str [ord::openroad_version]]}"
