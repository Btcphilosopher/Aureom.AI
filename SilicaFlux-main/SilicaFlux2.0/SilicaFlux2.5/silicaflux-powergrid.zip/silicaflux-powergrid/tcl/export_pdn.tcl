# Export the physical PDN, instances and (optionally) per-instance power from OpenDB/OpenSTA.
# Output (PG_OUT): meta.json wires.csv vias.csv via_defs.csv insts.csv power.csv bterms.csv
# Env: PG_NETS, PG_POWER (1 = per-instance power), PG_ACTIVITY (vectorless input activity),
#      PG_VCD + PG_VCD_SCOPE (read_power_activities), PG_CORNER.
source [file join [expr {[info exists ::env(PG_TCL_DIR)] ? $::env(PG_TCL_DIR) : [file dirname [file normalize [info script]]]}] common.tcl]
set block [pg_load_design]
set out [pg_require PG_OUT]
file mkdir $out
set dbu [$block getDbUnitsPerMicron]
pg_dump_tech $out/tech_layers.csv
set nets [pg_env PG_NETS "VDD VSS"]

set fw [open $out/wires.csv w]; puts $fw "net,layer,x0,y0,x1,y1,shape,dir"
set fv [open $out/vias.csv w];  puts $fv "net,x,y,via"
array set vdefs {}
foreach net $nets {
  set n [$block findNet $net]
  if {$n eq "NULL"} { puts "PG-ERROR: net $net not found"; exit 3 }
  foreach sw [$n getSWires] {
    foreach sb [$sw getWires] {
      if {[$sb isVia]} {
        set xy [$sb getViaXY]
        set tv [$sb getTechVia]; set bv [$sb getBlockVia]
        if {$bv ne "NULL"} { set v $bv; set nm "B:[$bv getName]" } else { set v $tv; set nm "T:[$tv getName]" }
        if {![info exists vdefs($nm)]} { set vdefs($nm) $v }
        puts $fv "$net,[lindex $xy 0],[lindex $xy 1],$nm"
      } else {
        puts $fw "$net,[[$sb getTechLayer] getName],[$sb xMin],[$sb yMin],[$sb xMax],[$sb yMax],[$sb getWireShapeType],[$sb getDir]"
      }
    }
  }
}
close $fw; close $fv
set fd [open $out/via_defs.csv w]; puts $fd "via,bottom,cut,top,cuts,rows,cols,bot_x0,bot_y0,bot_x1,bot_y1,top_x0,top_y0,top_x1,top_y1"
foreach nm [array names vdefs] {
  set v $vdefs($nm)
  set bot [[$v getBottomLayer] getName]; set top [[$v getTopLayer] getName]
  set cuts 0; set cut ""; set bb {0 0 0 0}; set tb {0 0 0 0}
  foreach b [$v getBoxes] {
    set l [$b getTechLayer]
    if {[$l getType] eq "CUT"} { incr cuts; set cut [$l getName] } elseif {[$l getName] eq $bot} { set bb [list [$b xMin] [$b yMin] [$b xMax] [$b yMax]] } elseif {[$l getName] eq $top} { set tb [list [$b xMin] [$b yMin] [$b xMax] [$b yMax]] }
  }
  set rows ""; set cols ""
  if {[string match B:* $nm] && [$v hasParams]} { set p [$v getViaParams]; set rows [$p getNumCutRows]; set cols [$p getNumCutCols] }
  puts $fd "$nm,$bot,$cut,$top,$cuts,$rows,$cols,[join $bb ,],[join $tb ,]"
}
close $fd

# block terminals on PG nets (pads / pins), if any
set fb [open $out/bterms.csv w]; puts $fb "net,bterm,layer,x0,y0,x1,y1"
foreach net $nets {
  set n [$block findNet $net]
  foreach bt [$n getBTerms] { foreach bp [$bt getBPins] { foreach box [$bp getBoxes] { puts $fb "$net,[$bt getName],[[$box getTechLayer] getName],[$box xMin],[$box yMin],[$box xMax],[$box yMax]" } } }
}
close $fb

# instances: geometry + PG pin location (centre of the ITerm bbox) per PG net
set fi [open $out/insts.csv w]; puts $fi "inst,master,type,placed,orient,x0,y0,x1,y1,pg_net,pin,sig,px0,py0,px1,py1"
foreach inst [$block getInsts] {
  set bb [$inst getBBox]
  set m [$inst getMaster]
  set typ [expr {[$inst isBlock] ? "BLOCK" : [$m getType]}]
  set any 0
  foreach it [$inst getITerms] {
    set st [[$it getMTerm] getSigType]
    if {$st ne "POWER" && $st ne "GROUND"} continue
    set nt [$it getNet]; set nn [expr {$nt eq "NULL" ? "" : [$nt getName]}]
    set r [$it getBBox]
    puts $fi "[$inst getName],[$m getName],$typ,[$inst isPlaced],[$inst getOrient],[$bb xMin],[$bb yMin],[$bb xMax],[$bb yMax],$nn,[[$it getMTerm] getName],$st,[$r xMin],[$r yMin],[$r xMax],[$r yMax]"
    set any 1
  }
  if {!$any} { puts $fi "[$inst getName],[$m getName],$typ,[$inst isPlaced],[$inst getOrient],[$bb xMin],[$bb yMin],[$bb xMax],[$bb yMax],,,,,,," }
}
close $fi

set power_label "NOT RUN"
if {[pg_env PG_POWER 0]} {
  set vcd [pg_env PG_VCD]
  if {$vcd ne ""} {
    read_power_activities -scope [pg_require PG_VCD_SCOPE] -vcd $vcd
    set power_label "SIMULATED: activities from VCD $vcd"
  } else {
    set act [pg_env PG_ACTIVITY 0.1]
    set_power_activity -input -activity $act
    set power_label "MODELLED (vectorless): OpenSTA input activity $act propagated; no simulation trace"
  }
  set corner [sta::cmd_corner]
  set fp [open $out/power.csv w]; puts $fp "inst,internal_w,switching_w,leakage_w,total_w"
  set tot 0.0
  foreach c [get_cells -hierarchical *] {
    if {[catch {sta::instance_power $c $corner} pw]} continue
    puts $fp "[get_full_name $c],[join $pw ,]"
    set tot [expr {$tot + [lindex $pw 3]}]
  }
  close $fp
  report_power > $out/report_power.rpt
  puts "PG-INFO: total instance power $tot W"
}
set die [$block getDieArea]; set core [$block getCoreArea]
set fm [open $out/meta.json w]
puts $fm "{\"design\":[pg_json_str [$block getName]],\"dbu\":$dbu,\"die\":\[[$die xMin],[$die yMin],[$die xMax],[$die yMax]\],\"core\":\[[$core xMin],[$core yMin],[$core xMax],[$core yMax]\],\"nets\":[pg_json_str $nets],\"odb\":[pg_json_str [pg_env PG_ODB]],\"openroad\":[pg_json_str [ord::openroad_version]],\"power_label\":[pg_json_str $power_label],\"setrc\":[pg_json_str [pg_env PG_SETRC]]}"
close $fm
puts "PG-EXPORT-DONE $out"
