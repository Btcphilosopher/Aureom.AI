# Write PDNSim's own resistor network as SPICE (write_pg_spice), per net.
source [file join [expr {[info exists ::env(PG_TCL_DIR)] ? $::env(PG_TCL_DIR) : [file dirname [file normalize [info script]]]}] common.tcl]
set block [pg_load_design]
set out [pg_require PG_OUT]
file mkdir $out
set_power_activity -input -activity [pg_env PG_ACTIVITY 0.1]
foreach net [pg_env PG_NETS "VDD VSS"] {
  set_pdnsim_net_voltage -net $net -voltage [pg_require PG_VOLTAGE_$net]
  set args [list -net $net -outfile $out/${net}_pdnsim.sp]
  set vsrc [pg_env PG_VSRC_$net]
  if {$vsrc ne ""} { lappend args -vsrc $vsrc }
  set rc [catch {write_pg_spice {*}$args} res]
  puts "PG-SPICE {\"net\":[pg_json_str $net],\"tcl_rc\":$rc,\"result\":[pg_json_str $res]}"
}
