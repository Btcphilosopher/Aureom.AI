# Static IR analysis with OpenROAD PDNSim (psm), OpenROAD 2.0-12331-g6011bbe77 syntax:
#   set_pdnsim_net_voltage -net N -voltage V
#   check_power_grid -net N [-error_file F]
#   analyze_power_grid -net N [-vsrc F] [-outfile F] [-error_file F] [-enable_em] [-em_outfile F] [-dx -dy] [-node_density|-node_density_factor]
# Env: PG_NETS, PG_VOLTAGE_<net>, PG_VSRC_<net> (vsrc CSV: x_um,y_um,size_um,voltage),
#      PG_ACTIVITY / PG_VCD, PG_NODE_DENSITY_FACTOR, PG_OUT.
# Instance power is computed by OpenSTA inside analyze_power_grid (sta->power per instance).
source [file join [expr {[info exists ::env(PG_TCL_DIR)] ? $::env(PG_TCL_DIR) : [file dirname [file normalize [info script]]]}] common.tcl]
set block [pg_load_design]
set out [pg_require PG_OUT]
file mkdir $out
pg_dump_tech $out/tech_layers_used.csv
set vcd [pg_env PG_VCD]
if {$vcd ne ""} { read_power_activities -scope [pg_require PG_VCD_SCOPE] -vcd $vcd } else { set_power_activity -input -activity [pg_env PG_ACTIVITY 0.1] }
foreach net [pg_env PG_NETS "VDD VSS"] {
  set v [pg_require PG_VOLTAGE_$net]
  set_pdnsim_net_voltage -net $net -voltage $v
  set vsrc [pg_env PG_VSRC_$net]
  set args [list -net $net -outfile $out/${net}_voltage.csv -error_file $out/${net}_errors.rpt -enable_em -em_outfile $out/${net}_em.csv]
  if {$vsrc ne ""} { if {![file exists $vsrc]} { puts "PG-ERROR: vsrc file missing $vsrc"; exit 2 }; lappend args -vsrc $vsrc }
  set ndf [pg_env PG_NODE_DENSITY_FACTOR]
  if {$ndf ne ""} { lappend args -node_density_factor $ndf }
  set t0 [clock milliseconds]
  set rc [catch {analyze_power_grid {*}$args} res]
  set ms [expr {[clock milliseconds] - $t0}]
  puts "PG-PDNSIM {\"net\":[pg_json_str $net],\"voltage\":$v,\"vsrc\":[pg_json_str $vsrc],\"tcl_rc\":$rc,\"result\":[pg_json_str $res],\"ms\":$ms}"
  if {[pg_env PG_WRITE_SPICE 0]} {
    set sargs [list -net $net -outfile $out/${net}_pdnsim.sp]
    if {$vsrc ne ""} { lappend sargs -vsrc $vsrc }
    set src [catch {write_pg_spice {*}$sargs} sres]
    puts "PG-SPICE {\"net\":[pg_json_str $net],\"tcl_rc\":$src,\"result\":[pg_json_str $sres]}"
  }
}
