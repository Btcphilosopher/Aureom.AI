# =============================================================================
# SilicaFlux PowerGrid -- common OpenROAD helpers.
# All inputs come from environment variables written by powergrid/openroad_adapter.py:
#   PG_TECH_LEF  PG_LEFS  PG_LIBS  PG_ODB  PG_SDC  PG_OUT  [PG_SETRC]
# Commands are the ones present in OpenROAD 2.0-12331-g6011bbe77 (checked with `help`).
# =============================================================================
proc pg_env {name {default ""}} {
  if {[info exists ::env($name)] && $::env($name) ne ""} { return $::env($name) }
  return $default
}
proc pg_require {name} {
  set v [pg_env $name]
  if {$v eq ""} { puts "PG-ERROR: required environment variable $name is not set"; exit 2 }
  return $v
}
proc pg_load_design {} {
  set tech [pg_require PG_TECH_LEF]
  if {![file exists $tech]} { puts "PG-ERROR: tech LEF missing: $tech"; exit 2 }
  read_lef $tech
  foreach l [pg_env PG_LEFS] { if {![file exists $l]} { puts "PG-ERROR: LEF missing: $l"; exit 2 }; read_lef $l }
  foreach l [pg_env PG_LIBS] { if {![file exists $l]} { puts "PG-ERROR: Liberty missing: $l"; exit 2 }; read_liberty $l }
  set odb [pg_require PG_ODB]
  if {![file exists $odb]} { puts "PG-ERROR: OpenDB database missing: $odb"; exit 2 }
  read_db $odb
  set sdc [pg_env PG_SDC]
  if {$sdc ne ""} { read_sdc $sdc }
  set rc [pg_env PG_SETRC]
  if {$rc ne ""} { puts "PG-INFO: sourcing layer RC from $rc"; source $rc }
  set block [ord::get_db_block]
  if {$block eq "NULL"} { puts "PG-ERROR: no block in $odb"; exit 2 }
  pg_apply_resistance_override
  return $block
}
proc pg_json_str {s} { return "\"[string map {\\ \\\\ \" \\\"} $s]\"" }

# The OpenDB technology carries its own layer resistances; an ORFS flow that sourced the
# platform setRC.tcl (set_layer_rc) has OVERWRITTEN the tech-LEF values in the database.
# PG_RES_OVERRIDE=<csv layer,ohm> restores a chosen data set (e.g. the tech LEF) explicitly.
proc pg_apply_resistance_override {} {
  set f [pg_env PG_RES_OVERRIDE]
  set tech [ord::get_db_tech]
  if {$f ne ""} {
    set fh [open $f]; set lines [split [read $fh] "\n"]; close $fh
    foreach ln $lines {
      set ln [string trim $ln]; if {$ln eq "" || [string match "layer,*" $ln]} continue
      lassign [split $ln ,] lname res
      set l [$tech findLayer $lname]
      if {$l eq "NULL"} { puts "PG-ERROR: resistance override: no layer $lname"; exit 2 }
      set old [$l getResistance]; $l setResistance $res
      puts "PG-RES {\"layer\":[pg_json_str $lname],\"db_before\":$old,\"applied\":$res}"
    }
  }
}
proc pg_dump_tech {path} {
  set fh [open $path w]; puts $fh "layer,type,resistance,width_dbu"
  foreach l [[ord::get_db_tech] getLayers] { set t [$l getType]; if {$t eq "ROUTING" || $t eq "CUT"} { puts $fh "[$l getName],$t,[$l getResistance],[$l getWidth]" } }
  close $fh
}
