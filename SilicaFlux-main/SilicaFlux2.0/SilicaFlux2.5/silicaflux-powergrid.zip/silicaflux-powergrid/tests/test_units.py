import pytest

from powergrid.units import UnitError, format_quantity, parse_quantity


@pytest.mark.parametrize("text,dim,si", [
    ("1 ohm", "resistance", 1.0), ("25 mohm", "resistance", 0.025), ("2 kohm", "resistance", 2000.0),
    ("1.2 V", "voltage", 1.2), ("50 mV", "voltage", 0.05), ("3 A", "current", 3.0), ("12 mA", "current", 0.012),
    ("0.44 um", "length", 0.44e-6), ("130 nm", "length", 130e-9), ("2.5 mm", "length", 2.5e-3),
    ("10 mW", "power", 0.01), ("1 W/mm2", "power_density", 1e6), ("0.1 ohm/sq", "sheet_resistance", 0.1),
    ("1 mA/um", "linear_current_density", 1e3), ({"value": 3, "unit": "mA"}, "current", 0.003),
])
def test_parse(text, dim, si):
    assert parse_quantity(text, dim) == pytest.approx(si, rel=1e-12)


@pytest.mark.parametrize("bad,dim", [
    (1.2, "voltage"), ("1.2", "voltage"), ("5 mA", "voltage"), ("3 M", "resistance"), ("2 MEG", "resistance"),
    ("1 mil", "length"), ("1 MOhm", "resistance"), ("1 MV", "voltage"), ("nan V", "voltage"), ("1 furlong", "length"),
    (True, "current"), ({"value": "x", "unit": "V"}, "voltage"),
])
def test_reject(bad, dim):
    with pytest.raises(UnitError):
        parse_quantity(bad, dim)


def test_format():
    assert format_quantity(0.0123, "voltage", "mV") == "12.3 mV"
