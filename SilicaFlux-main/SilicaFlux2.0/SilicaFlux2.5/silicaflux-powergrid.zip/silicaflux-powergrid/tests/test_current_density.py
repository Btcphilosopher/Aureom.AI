import math

import numpy as np
import pytest

from conftest import chain
from powergrid.current_density import em_screen, layer_summary, resolve_via_array, segment_table, black_mttf_ratio
from powergrid.graph import Load, Network, NetType, VoltageSource
from powergrid.solver import solve


def _net(limit):
    n = Network(); n.add_net("VDD", NetType.POWER, 1.0)
    n.add_node("a", "VDD"); n.add_node("b", "VDD"); n.add_node("c", "VDD")
    n.add_metal_segment("a", "b", layer="M", length_m=10e-6, width_m=2e-6, sheet_resistance_ohm_sq=0.1,
                        thickness_m=0.5e-6, current_limit_a=limit)
    n.add_segment("b", "c", 1.0)                       # no limit -> UNKNOWN
    n.add_source(VoltageSource("V", "a", 1.0)); n.add_load(Load("L", "c", None, current_a=0.01))
    return n


def test_density_values():
    sol = solve(_net(0.02))
    t = segment_table(sol)
    assert t["j_linear_a_per_m"][0] == pytest.approx(0.01 / 2e-6)
    assert t["j_volumetric_a_per_m2"][0] == pytest.approx(0.01 / (2e-6 * 0.5e-6))


def test_em_statuses_never_claim_safety_without_limit():
    ok = em_screen(solve(_net(0.02)))
    assert ok["counts"]["PASS"] == 1 and ok["counts"]["UNKNOWN"] == 1 and ok["overall"] == "UNKNOWN"
    bad = em_screen(solve(_net(0.005)))
    assert bad["counts"]["FAIL"] == 1 and bad["overall"] == "FAIL"


def test_via_array_single_cut_equals_lumped_and_crowding_for_rows():
    one = resolve_via_array(1, 1, 0.84e-6, 4.0, 0.103, 0.021, 2e-6, 2e-6)
    assert one["max_over_mean"] == pytest.approx(1.0)
    row = resolve_via_array(1, 8, 0.84e-6, 0.5, 0.103, 0.021, 2e-6, 2e-6, feed="opposite")
    assert row["max_over_mean"] > 1.05 and row["kcl_ok"]          # end cuts carry more than average


def test_black_ratio_research_only():
    assert black_mttf_ratio(2e10, 1e10, 378.15, 378.15, 2.0, 0.9) == pytest.approx(0.25)
