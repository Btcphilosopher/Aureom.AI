"""TEST I -- ground return: separate VDD and VSS networks, effective supply."""
import math

import pytest

from powergrid.graph import Load, Network, NetType, NetworkError, VoltageSource
from powergrid.solver import solve


def make(rp=0.2, rn=0.3, i=0.5, v=1.2):
    n = Network("gr")
    n.add_net("VDD", NetType.POWER, v)
    n.add_net("VSS", NetType.GROUND, 0.0)
    n.add_domain("CORE", "VDD", "VSS")
    n.add_node("vdd_pad", "VDD"); n.add_node("vdd_load", "VDD")
    n.add_node("vss_pad", "VSS"); n.add_node("vss_load", "VSS")
    n.add_segment("vdd_pad", "vdd_load", rp)
    n.add_segment("vss_load", "vss_pad", rn)
    n.add_source(VoltageSource("VDD_src", "vdd_pad", v))
    n.add_source(VoltageSource("VSS_src", "vss_pad", 0.0))
    n.add_load(Load("cell", "vdd_load", "vss_load", current_a=i, domain="CORE"))
    return n


def test_effective_supply_includes_ground_bounce():
    rp, rn, i, v = 0.2, 0.3, 0.5, 1.2
    sol = solve(make(rp, rn, i, v))
    row = sol.load_table()[0]
    assert math.isclose(row["v_vdd"], v - i * rp, abs_tol=1e-12)        # VDD droop
    assert math.isclose(row["v_vss"], i * rn, abs_tol=1e-12)            # ground bounce
    assert math.isclose(row["v_eff"], v - i * (rp + rn), abs_tol=1e-12)
    assert math.isclose(row["vdd_droop_v"], i * rp, abs_tol=1e-12)
    assert math.isclose(row["ground_bounce_v"], i * rn, abs_tol=1e-12)
    assert math.isclose(row["total_loss_v"], i * (rp + rn), abs_tol=1e-12)
    assert math.isclose(sol.source_current["VDD_src"], i, abs_tol=1e-12)
    assert math.isclose(sol.source_current["VSS_src"], -i, abs_tol=1e-12)
    assert sol.metrics["ideal_return_loads"] == 0
    assert abs(sol.metrics["global_current_balance_A"]) < 1e-12
    assert sol.metrics["power_ok"]


def test_ignoring_ground_overstates_supply():
    with_gnd = solve(make()).load_v_eff[0]
    n = Network("nognd"); n.add_net("VDD", NetType.POWER, 1.2)
    n.add_node("p", "VDD"); n.add_node("l", "VDD"); n.add_segment("p", "l", 0.2)
    n.add_source(VoltageSource("V", "p", 1.2)); n.add_load(Load("c", "l", None, current_a=0.5))
    no_gnd = solve(n).load_v_eff[0]
    assert no_gnd - with_gnd == pytest.approx(0.5 * 0.3, abs=1e-12)


def test_power_and_ground_never_joined_implicitly():
    n = make()
    with pytest.raises(NetworkError, match="nets are never connected"):
        n.add_segment("vdd_load", "vss_load", 1.0)


def test_load_domain_must_match_nets():
    n = make()
    n.add_net("VDD2", NetType.POWER, 0.9); n.add_net("VSS2", NetType.GROUND, 0.0)
    n.add_domain("AON", "VDD2", "VSS2")
    n.add_node("x", "VDD2")
    with pytest.raises(NetworkError, match="do not match domain"):
        n.add_load(Load("bad", "x", "vss_load", current_a=0.1, domain="AON"))
    with pytest.raises(NetworkError, match="names domain"):
        n.add_load(Load("bad2", "vdd_load", "vss_load", current_a=0.1, domain=None))


def test_load_terminals_must_be_power_and_ground():
    n = make()
    with pytest.raises(NetworkError, match="non-power net"):
        n.add_load(Load("bad", "vss_load", "vss_pad", current_a=0.1, domain="CORE"))
