"""PDN import on the public ORFS gcd reference (IHP SG13G2) and PDNSim comparison."""
from pathlib import Path

import numpy as np
import pytest

from powergrid.compare import compare_instance_voltages, solve_pdnsim_spice
from powergrid.openroad_adapter import parse_pdnsim_spice, parse_pdnsim_voltage
from powergrid.pdn_import import ImportOptions, SourceSpec, build_network, canonical_name, read_export
from powergrid.solver import solve
from powergrid.technology import parse_lef, tech_from_db_dump

D = Path(__file__).parent / "data" / "gcd_ihp"
LEF = Path("/opt/eda/orfs/flow/platforms/ihp-sg13g2/lef/sg13g2_tech.lef")
pytestmark = pytest.mark.skipif(not LEF.exists(), reason="IHP SG13G2 tech LEF not installed")
SRC = [SourceSpec("VDD_p0", "VDD", -12.56, -10.22), SourceSpec("VSS_p0", "VSS", 162.04, 161.98)]


@pytest.fixture(scope="module")
def exp():
    return read_export(D / "export")


@pytest.fixture(scope="module")
def techs():
    lef = parse_lef(LEF)
    return {"tech_lef": lef, "odb_tech": tech_from_db_dump(D / "export" / "tech_layers.csv", lef)}


def test_extraction_completeness(exp, techs):
    net, rep = build_network(exp, techs["tech_lef"], SRC, ImportOptions())
    assert rep.wires == 57 and rep.wires_floating == 0 and rep.vias_dangling == 0
    assert rep.std_cells_attached == len(exp.insts)                 # every instance attached
    assert rep.total_power_w == pytest.approx(sum(exp.power_w.values()))   # no power silently dropped
    assert len(rep.pg_iterms_unconnected_in_db) > 0                  # recorded, not hidden
    sol = solve(net)
    assert sol.metrics["kcl_ok"] and sol.metrics["power_ok"] and sol.metrics["floating_components"] == 0
    # current entering the VDD source equals the total load current (I = P/Vnom)
    assert sol.source_current["VDD_p0"] == pytest.approx(rep.total_current_a, rel=1e-9)


@pytest.mark.parametrize("source,pdir", [("odb_tech", "pdnsim_odb"), ("tech_lef", "pdnsim_lef")])
def test_agrees_with_pdnsim_under_equivalent_assumptions(exp, techs, source, pdir):
    net, rep = build_network(exp, techs[source], SRC, ImportOptions(current_conversion="pdnsim_watts"))
    sol = solve(net)
    for k, (n, vnom) in enumerate((("VDD", 1.2), ("VSS", 0.0))):
        pv = {canonical_name(i): v for i, (x, y, v) in parse_pdnsim_voltage(D / pdir / f"{n}_voltage.csv").items()}
        mine = {i: sol.voltage(nodes[k]) for i, nodes in rep.inst_attach.items()}
        c = compare_instance_voltages(mine, pv, vnom, worst_rel_tol=0.15)
        assert c["matched"] == len(exp.insts)
        assert c["status"] == "AGREE", c
        assert c["correlation"] > 0.75


def test_physical_current_differs_from_pdnsim_convention(exp, techs):
    a = solve(build_network(exp, techs["odb_tech"], SRC, ImportOptions(current_conversion="nominal"))[0])
    b = solve(build_network(exp, techs["odb_tech"], SRC, ImportOptions(current_conversion="pdnsim_watts"))[0])
    ratio = (1.2 - a.load_v_vdd.min()) / (1.2 - b.load_v_vdd.min())
    assert ratio == pytest.approx(1 / 1.2, rel=1e-9)               # linear network: I = P/V vs I = P


def test_pdnsim_spice_network_resolved_to_quantisation():
    for n, vnom in (("VDD", 1.2), ("VSS", 0.0)):
        sp = parse_pdnsim_spice(D / "pdnsim_odb" / f"{n}_pdnsim.sp")
        assert sp["isource_nodes_duplicated"] > 0                   # write_pg_spice duplicate-current defect
        _, sol, info = solve_pdnsim_spice(sp, n, vnom)
        assert info["total_current_dedup_a"] < info["total_current_written_a"]
        pv = parse_pdnsim_voltage(D / "pdnsim_odb" / f"{n}_voltage.csv")
        diffs = [sol.voltage(f"{n}_{int(round(x*1000))}_{int(round(y*1000))}_1") - v for (x, y, v) in pv.values()]
        assert np.max(np.abs(diffs)) <= 5.1e-6                     # PDNSim prints 6 significant digits


def test_ground_sign_of_write_pg_spice(exp):
    sp = parse_pdnsim_spice(D / "pdnsim_odb" / "VSS_pdnsim.sp")
    _, wrong, _ = solve_pdnsim_spice(sp, "VSS", 0.0, ground_sign_fix=False)
    assert wrong.node_voltage.min() < 0                             # as written, VSS would sink below 0 V


def test_floating_wire_is_reported(exp, techs):
    import copy
    from powergrid.pdn_import import Wire
    e2 = copy.copy(exp)
    e2.wires = list(exp.wires) + [Wire("VDD", "Metal5", 500000, 500000, 502000, 600000, "STRIPE")]
    net, rep = build_network(e2, techs["tech_lef"], SRC, ImportOptions())
    assert rep.wires_floating == 1
