"""Constant-power loads: nonlinear iteration vs closed form; voltage collapse."""
import math

import pytest

from powergrid.graph import Load, LoadModel, Network, NetType, VoltageSource
from powergrid.solver import SolverOptions, VoltageCollapseError, solve


def one(p, r=1.0, v=1.0, conv="local"):
    n = Network(); n.add_net("VDD", NetType.POWER, v)
    n.add_node("s", "VDD"); n.add_node("l", "VDD"); n.add_segment("s", "l", r)
    n.add_source(VoltageSource("V", "s", v))
    n.add_load(Load("P", "l", None, model=LoadModel.FIXED_POWER, power_w=p, conversion_voltage=conv))
    return n


@pytest.mark.parametrize("p", [0.01, 0.1, 0.2, 0.24])
def test_constant_power_matches_closed_form(p):
    sol = solve(one(p), SolverOptions(fp_vtol=1e-13, fp_max_iter=2000))
    vl = (1.0 + math.sqrt(1.0 - 4 * p * 1.0)) / 2.0           # high-voltage (stable) branch
    assert sol.voltage("l") == pytest.approx(vl, abs=1e-9)
    assert sol.load_current[0] * sol.voltage("l") == pytest.approx(p, rel=1e-8)
    assert sol.metrics["fixed_point_iterations"] >= 1


def test_nominal_conversion_is_single_linear_solve():
    sol = solve(one(0.2, conv="nominal"))
    assert sol.load_current[0] == pytest.approx(0.2)            # P / V_nominal
    assert sol.metrics["fixed_point_iterations"] == 0
    assert sol.voltage("l") == pytest.approx(0.8)


def test_voltage_collapse_beyond_max_power_transfer():
    with pytest.raises(VoltageCollapseError):
        solve(one(0.30))                                        # > V^2/(4R) = 0.25 W
