from pathlib import Path

import pytest

from powergrid.optimise import experiment_id, marginal_gains, pareto_front, rule_check, synthetic_sweep
from powergrid.technology import parse_lef

LEF = Path("/opt/eda/orfs/flow/platforms/ihp-sg13g2/lef/sg13g2_tech.lef")
BASE = {"FLP_PDN_STRAP1_LAYER": "Metal5", "FLP_PDN_STRAP1_WIDTH": "2.2", "FLP_PDN_STRAP1_PITCH": "75.6",
        "FLP_PDN_STRAP2_LAYER": "TopMetal1", "FLP_PDN_STRAP2_WIDTH": "1.8", "FLP_PDN_STRAP2_PITCH": "30.24"}


def test_experiment_id_deterministic_and_order_free():
    a = experiment_id({"x": 1, "y": "2"}); b = experiment_id({"y": "2", "x": 1})
    assert a == b and a.startswith("X") and a != experiment_id({"x": 2, "y": "2"})


@pytest.mark.skipif(not LEF.exists(), reason="IHP LEF not installed")
def test_rule_check():
    t = parse_lef(LEF)
    assert rule_check(BASE, t, macro_bound_um=38.83) == []
    assert any("minimum width" in e for e in rule_check({**BASE, "FLP_PDN_STRAP1_WIDTH": "0.1"}, t))
    assert any("38.83" in e for e in rule_check({**BASE, "FLP_PDN_STRAP2_PITCH": "60.48"}, t, macro_bound_um=38.83))
    assert any("interleaved" in e for e in rule_check({**BASE, "FLP_PDN_STRAP1_PITCH": "4.0"}, t))
    assert any("does not exist" in e for e in rule_check({**BASE, "FLP_PDN_STRAP1_LAYER": "Metal8"}, t))


def test_pareto_and_gains():
    pts = [{"id": "a", "status": "VALID", "l": 10, "m": 1}, {"id": "b", "status": "VALID", "l": 5, "m": 2},
           {"id": "c", "status": "VALID", "l": 11, "m": 3}, {"id": "d", "status": "REJECTED", "l": 0, "m": 0}]
    assert set(pareto_front(pts, ("l", "m"))) == {"a", "b"}
    base = {"id": "a", "worst_loss_mv": 10, "mean_loss_mv": 5, "resistive_loss_uw": 1, "pdn_metal_area_um2": 100,
            "metal5_blockage": 0.01, "via_cuts_total": 10}
    o = {**base, "id": "b", "label": "b", "status": "VALID", "worst_loss_mv": 8, "pdn_metal_area_um2": 300, "metal5_blockage": 0.02}
    g = marginal_gains(base, [o])[0]
    assert g["d_worst_loss_mv"] == -2 and g["mv_saved_per_mm2_metal"] == pytest.approx(2 / 200e-6)


@pytest.mark.skipif(not LEF.exists(), reason="IHP LEF not installed")
def test_synthetic_sweep_wider_straps_reduce_loss():
    t = parse_lef(LEF)
    base = {"rail_pitch": 30.24, "m5_width": 2.2, "m5_pitch": 75.6, "tm1_width": 1.8, "tm1_pitch": 60.48,
            "stack_cuts": 5, "tm_cuts": 2, "pads_per_side": 1}
    rows = synthetic_sweep(t, 600, 600, base, {"tm1_width": [1.8, 7.2]}, 0.05, 1.2)
    assert rows[1]["worst_loss_mv"] < rows[0]["worst_loss_mv"] and all(r["kcl_ok"] for r in rows)
