"""Optional OpenROAD integration on the PUBLIC gcd reference (skipped without the toolchain).

Passing this proves the adapter works on a public design; it says nothing about SilicaFlux.
"""
import os
from pathlib import Path

import pytest

from powergrid.openroad_adapter import OpenROAD

D = Path(__file__).parent / "data" / "gcd_ihp"
P = Path("/opt/eda/orfs/flow/platforms/ihp-sg13g2")
ora = OpenROAD()
pytestmark = [pytest.mark.slow, pytest.mark.skipif(not (ora.available() and P.exists()), reason="OpenROAD/IHP platform not installed")]


def _env(out):
    return {"PG_TECH_LEF": str(P / "lef/sg13g2_tech.lef"), "PG_LEFS": str(P / "lef/sg13g2_stdcell.lef"),
            "PG_LIBS": str(P / "lib/sg13g2_stdcell_typ_1p20V_25C.lib"), "PG_ODB": str(D / "3_place.odb"),
            "PG_SDC": str(D / "3_place.sdc"), "PG_OUT": str(out), "PG_NETS": "VDD VSS"}


def test_check_power_grid(tmp_path):
    r = ora.run("check_pdn.tcl", _env(tmp_path), tmp_path / "log", "check")
    recs = [x for x in r.records if x["_tag"] == "PG-CHECK"]
    assert r.ok and len(recs) == 2 and all(x["result"] == "true" for x in recs)


def test_pdnsim_runs_with_vsrc(tmp_path):
    e = {**_env(tmp_path), "PG_VOLTAGE_VDD": "1.2", "PG_VOLTAGE_VSS": "0.0",
         "PG_VSRC_VDD": str(D / "pdnsim_odb/vsrc_VDD.loc"), "PG_VSRC_VSS": str(D / "pdnsim_odb/vsrc_VSS.loc")}
    r = ora.run("run_pdnsim.tcl", e, tmp_path / "log", "pdnsim")
    assert r.ok and (tmp_path / "VDD_voltage.csv").exists() and (tmp_path / "VSS_voltage.csv").exists()
    # identical inputs reproduce the stored PDNSim result bit-for-bit
    assert (tmp_path / "VDD_voltage.csv").read_text() == (D / "pdnsim_odb/VDD_voltage.csv").read_text()


def test_missing_odb_fails_clearly(tmp_path):
    e = {**_env(tmp_path), "PG_ODB": str(tmp_path / "nope.odb")}
    r = ora.run("check_pdn.tcl", e, tmp_path / "log", "check")
    assert not r.ok and any("missing" in x for x in r.errors)
