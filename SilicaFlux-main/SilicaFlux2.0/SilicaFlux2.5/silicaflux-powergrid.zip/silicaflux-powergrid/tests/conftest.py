import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest

from powergrid.graph import Load, Network, NetType, VoltageSource


@pytest.fixture
def single_net():
    def make(v=1.0):
        n = Network("t")
        n.add_net("VDD", NetType.POWER, v)
        return n
    return make


def chain(rs, v=1.0, loads=None):
    """Source -> R0 -> n1 -> R1 -> n2 ... (helper for hand-checkable tests)."""
    n = Network("chain")
    n.add_net("VDD", NetType.POWER, v)
    n.add_node("n0", "VDD")
    for k, r in enumerate(rs):
        n.add_node(f"n{k+1}", "VDD")
        n.add_segment(f"n{k}", f"n{k+1}", r)
    n.add_source(VoltageSource("V", "n0", v))
    for node, i in (loads or {}).items():
        n.add_load(Load(f"L_{node}", node, None, current_a=i))
    return n
