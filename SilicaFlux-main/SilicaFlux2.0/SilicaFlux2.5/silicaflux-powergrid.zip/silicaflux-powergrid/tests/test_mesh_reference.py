"""TEST D -- 2-D resistor mesh vs independently constructed references.
TEST J -- mesh refinement convergence for a fixed physical problem.

References that share no code with powergrid.conductance / powergrid.solver:
  (1) a dense nodal matrix built by an explicit 5-point stencil and solved
      with numpy.linalg.solve;
  (2) the exact discrete solution from the eigen-decomposition of the
      Dirichlet grid Laplacian (discrete sine transform), evaluated in
      closed form;
  (3) for TEST J, the continuous Poisson solution on a square, centre value
      u(1/2,1/2) = 0.0736713532814... for lap(u) = -1 on the unit square
      (series solution, evaluated here independently).
"""
import math

import numpy as np
import pytest

from powergrid.graph import Load, Network, NetType, VoltageSource
from powergrid.mesh import sheet_square
from powergrid.solver import SolverOptions, solve


def build_mesh(nx, ny, r_h, r_v, src_nodes, loads, v=1.0):
    n = Network("mesh")
    n.add_net("VDD", NetType.POWER, v)
    for i in range(nx):
        for j in range(ny):
            n.add_node(f"{i},{j}", "VDD", "M", float(i), float(j))
    for i in range(nx):
        for j in range(ny):
            if i + 1 < nx:
                n.add_segment(f"{i},{j}", f"{i+1},{j}", r_h)
            if j + 1 < ny:
                n.add_segment(f"{i},{j}", f"{i},{j+1}", r_v)
    for k, s in enumerate(src_nodes):
        n.add_source(VoltageSource(f"V{k}", f"{s[0]},{s[1]}", v))
    for (i, j), cur in loads.items():
        n.add_load(Load(f"L{i}_{j}", f"{i},{j}", None, current_a=cur))
    return n


def dense_reference(nx, ny, r_h, r_v, src_nodes, loads, v=1.0):
    N = nx * ny
    idx = lambda i, j: i * ny + j
    G = np.zeros((N, N)); b = np.zeros(N)
    for i in range(nx):
        for j in range(ny):
            for di, dj, r in ((1, 0, r_h), (0, 1, r_v)):
                ii, jj = i + di, j + dj
                if ii < nx and jj < ny:
                    p, q, g = idx(i, j), idx(ii, jj), 1.0 / r
                    G[p, p] += g; G[q, q] += g; G[p, q] -= g; G[q, p] -= g
    for (i, j), cur in loads.items():
        b[idx(i, j)] -= cur
    fixed = [idx(*s) for s in src_nodes]
    for f in fixed:                       # replace row by identity (row-replacement method)
        G[f, :] = 0.0; G[f, f] = 1.0; b[f] = v
    return np.linalg.solve(G, b).reshape(nx, ny)


@pytest.mark.parametrize("nx,ny,rh,rv", [(5, 5, 1.0, 1.0), (7, 4, 0.3, 2.0), (12, 9, 0.05, 0.11)])
def test_mesh_matches_dense_reference(nx, ny, rh, rv):
    rng = np.random.default_rng(nx * 100 + ny)
    loads = {(i, j): float(rng.uniform(0.001, 0.02)) for i in range(nx) for j in range(ny) if rng.random() < 0.4}
    srcs = [(0, 0), (nx - 1, ny - 1)]
    loads.pop((0, 0), None); loads.pop((nx - 1, ny - 1), None)
    sol = solve(build_mesh(nx, ny, rh, rv, srcs, loads))
    ref = dense_reference(nx, ny, rh, rv, srcs, loads)
    got = np.array([[sol.voltage(f"{i},{j}") for j in range(ny)] for i in range(nx)])
    assert np.max(np.abs(got - ref)) < 1e-12
    cg = solve(build_mesh(nx, ny, rh, rv, srcs, loads), SolverOptions(method="cg", iterative_rtol=1e-14))
    assert np.max(np.abs(cg.node_voltage - sol.node_voltage)) < 1e-10


def dst_reference(m, g, cur):
    """Exact drop at every interior node of an (m+2)x(m+2) grid whose boundary is
    held at the supply, each interior node drawing ``cur``, conductance g."""
    k = np.arange(1, m + 1)
    S = np.sin(np.outer(k, k) * np.pi / (m + 1)) * math.sqrt(2.0 / (m + 1))   # orthonormal DST-I
    lam = 2.0 - 2.0 * np.cos(k * np.pi / (m + 1))
    F = np.full((m, m), cur)
    Fh = S @ F @ S
    Dh = Fh / (g * (lam[:, None] + lam[None, :]))
    return S @ Dh @ S


def test_mesh_matches_spectral_closed_form():
    n, rs, v, j = 12, 0.08, 1.2, 2.0e4
    side = 1e-3
    net = sheet_square(n, side, rs, v, j)
    sol = solve(net)
    h = side / n
    ref = dst_reference(n - 1, 1.0 / rs, j * h * h)
    got = np.array([[v - sol.voltage(f"n{i}_{jj}") for jj in range(1, n)] for i in range(1, n)])
    assert np.max(np.abs(got - ref)) < 1e-13


def poisson_centre_unit_square(terms=60):
    """u(1/2,1/2) for -lap u = 1 on [0,1]^2, u = 0 on the boundary.

    u(x,y) = x(1-x)/2 - (4/pi^3) sum_{n odd} sin(n pi x) cosh(n pi (y-1/2)) / (n^3 cosh(n pi/2))
    (separation of variables; converges exponentially).
    """
    s = 0.125
    for n in range(1, 2 * terms, 2):
        s -= 4.0 / math.pi ** 3 * math.sin(n * math.pi / 2) / (n ** 3 * math.cosh(n * math.pi / 2))
    return s


def test_mesh_refinement_converges_second_order():
    """TEST J: same physical sheet, finer discretisation -> error falls as h^2."""
    rs, v, j, side = 0.05, 1.0, 5.0e4, 2e-3
    u0 = poisson_centre_unit_square()
    assert abs(u0 - 0.0736713532814) < 1e-12
    exact = rs * j * side ** 2 * u0
    errs = []
    for n in (4, 8, 16, 32):
        sol = solve(sheet_square(n, side, rs, v, j))
        drop = v - sol.voltage(f"n{n//2}_{n//2}")
        errs.append(abs(drop - exact))
    orders = [math.log2(errs[k] / errs[k + 1]) for k in range(len(errs) - 1)]
    assert errs[-1] / exact < 2e-3
    assert all(1.8 < o < 2.2 for o in orders), orders
