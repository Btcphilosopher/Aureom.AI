import os
from pathlib import Path

import pytest

from powergrid.technology import (TechnologyError, load_profile, parse_lef, parse_setrc, tech_from_db_dump,
                                  write_resistance_override)

ROOT = Path(__file__).resolve().parents[1]
IHP = Path("/opt/eda/orfs/flow/platforms/ihp-sg13g2/lef/sg13g2_tech.lef")

MINI = """
LAYER M1
  TYPE ROUTING ;
  DIRECTION HORIZONTAL ;
  WIDTH 0.2 ;
  THICKNESS 0.3 ;
  RESISTANCE RPERSQ 0.08 ;
  DCCURRENTDENSITY AVERAGE 1.5 ;
END M1
LAYER V1
  TYPE CUT ;
  # RESISTANCE 99 ;   commented out: must be ignored
END V1
LAYER M2
  TYPE ROUTING ;
  DIRECTION VERTICAL ;
  WIDTH 0.4 ;
  RESISTANCE RPERSQ 0.04 ;
END M2
"""


def test_parse_minimal_lef(tmp_path):
    f = tmp_path / "t.lef"; f.write_text(MINI)
    t = parse_lef(f)
    assert t.layer_order() == ["M1", "M2"]
    assert t.sheet_resistance("M1") == 0.08 and t.routing["M1"].thickness_um == 0.3
    assert t.cuts["V1"].below == "M1" and t.cuts["V1"].above == "M2"
    with pytest.raises(TechnologyError, match="refusing to invent"):
        t.via_resistance_per_cut("V1")            # commented value ignored -> missing, not invented
    with pytest.raises(TechnologyError):
        t.sheet_resistance("M8")                  # layers that do not exist are not assumed


@pytest.mark.skipif(not IHP.exists(), reason="IHP SG13G2 platform not installed")
def test_ihp_lef_values_and_setrc_conversion():
    p = load_profile(ROOT / "configs/technology/ihp_sg13g2.yaml")
    assert p.nominal_supply_v == pytest.approx(1.2)
    t = p.tech("tech_lef")
    assert t.layer_order() == ["Metal1", "Metal2", "Metal3", "Metal4", "Metal5", "TopMetal1", "TopMetal2"]
    assert t.sheet_resistance("Metal1") == 0.135 and t.via_resistance_per_cut("TopVia1") == 4.0
    s = p.tech("orfs_setrc")
    # set_layer_rc Metal1 0.135e-3 kohm/um at default width 0.16 um -> 0.0216 ohm/sq equivalent
    assert s.sheet_resistance("Metal1") == pytest.approx(0.0216)
    assert s.via_resistance_per_cut("Via1") == pytest.approx(2.0)


def test_db_dump_and_override_roundtrip(tmp_path):
    f = tmp_path / "t.lef"; f.write_text(MINI.replace("# RESISTANCE 99", "RESISTANCE 3"))
    base = parse_lef(f)
    dump = tmp_path / "db.csv"
    dump.write_text("layer,type,resistance,width_dbu\nM1,ROUTING,0.02,200\nV1,CUT,0.5,0\nM2,ROUTING,0.04,400\n")
    db = tech_from_db_dump(dump, base)
    assert db.sheet_resistance("M1") == 0.02 and db.via_resistance_per_cut("V1") == 0.5
    assert "DIFFERENT" in db.notes[0]
    write_resistance_override(base, tmp_path / "o.csv")
    assert "M1,0.08" in (tmp_path / "o.csv").read_text()


def test_commercial_profiles_blocked():
    for n in ("commercial_130nm", "commercial_65nm", "commercial_28nm"):
        p = load_profile(ROOT / f"configs/technology/{n}.yaml")
        assert p.status == "blocked"
        with pytest.raises(TechnologyError, match="blocked"):
            p.tech()
