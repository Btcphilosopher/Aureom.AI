"""TEST B (series voltage division) and TEST C (parallel resistors)."""
import math

import pytest

from conftest import chain
from powergrid.graph import Load, Network, NetType, VoltageSource
from powergrid.solver import solve


def test_series_voltage_divider_open_load():
    # 1.2 V -> 2 ohm -> a -> 4 ohm -> b -> 6 ohm -> ground source (0 V)
    n = Network("div")
    n.add_net("VDD", NetType.POWER, 1.2)
    for x in "sabg":
        n.add_node(x, "VDD")
    n.add_segment("s", "a", 2.0); n.add_segment("a", "b", 4.0); n.add_segment("b", "g", 6.0)
    n.add_source(VoltageSource("Vs", "s", 1.2))
    # a 0 V source on the same net closes the divider (generic circuit: domain guard disabled)
    n.add_source(VoltageSource("Vg", "g", 0.0, check_nominal=False))
    sol = solve(n)
    i = 1.2 / 12.0
    assert math.isclose(sol.source_current["Vs"], i, rel_tol=1e-12)
    assert math.isclose(sol.source_current["Vg"], -i, rel_tol=1e-12)
    assert math.isclose(sol.voltage("a"), 1.2 * 10 / 12, rel_tol=1e-12)
    assert math.isclose(sol.voltage("b"), 1.2 * 6 / 12, rel_tol=1e-12)


def test_series_chain_with_distributed_loads():
    # 1 V, R = [0.5, 0.25, 0.25], loads 0.1 A at n1,n2,n3
    sol = solve(chain([0.5, 0.25, 0.25], v=1.0, loads={"n1": 0.1, "n2": 0.1, "n3": 0.1}))
    v1 = 1.0 - 0.3 * 0.5
    v2 = v1 - 0.2 * 0.25
    v3 = v2 - 0.1 * 0.25
    assert math.isclose(sol.voltage("n1"), v1, abs_tol=1e-12)
    assert math.isclose(sol.voltage("n2"), v2, abs_tol=1e-12)
    assert math.isclose(sol.voltage("n3"), v3, abs_tol=1e-12)
    assert math.isclose(sol.source_current["V"], 0.3, abs_tol=1e-12)


@pytest.mark.parametrize("rs", [(1.0, 1.0), (2.0, 3.0), (0.1, 10.0, 5.0)])
def test_parallel_equivalent_and_branch_currents(rs):
    n = Network("par")
    n.add_net("VDD", NetType.POWER, 1.0)
    n.add_node("s", "VDD"); n.add_node("l", "VDD")
    for r in rs:
        n.add_segment("s", "l", r)
    n.add_source(VoltageSource("V", "s", 1.0))
    I = 0.2
    n.add_load(Load("L", "l", None, current_a=I))
    sol = solve(n)
    req = 1.0 / sum(1.0 / r for r in rs)
    assert math.isclose(1.0 - sol.voltage("l"), I * req, rel_tol=1e-12)
    for k, r in enumerate(rs):
        assert math.isclose(sol.current(k), I * req / r, rel_tol=1e-12)   # current divider
    assert math.isclose(sum(sol.segment_current), I, rel_tol=1e-12)
