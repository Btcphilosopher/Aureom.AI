"""TEST H -- energy balance: P_source + P_injections = P_dissipated + P_load."""
import math

import numpy as np
from hypothesis import given, settings

from conftest import chain
from test_kcl import random_network
from powergrid.solver import solve


def test_power_balance_hand_example():
    sol = solve(chain([0.5, 0.25], v=1.0, loads={"n1": 0.2, "n2": 0.1}))
    m = sol.metrics
    v1 = 1.0 - 0.3 * 0.5; v2 = v1 - 0.1 * 0.25
    assert math.isclose(m["power_source_W"], 0.3, rel_tol=1e-12)
    assert math.isclose(m["power_dissipated_W"], 0.3**2 * 0.5 + 0.1**2 * 0.25, rel_tol=1e-12)
    assert math.isclose(m["power_load_W"], 0.2 * v1 + 0.1 * v2, rel_tol=1e-12)
    assert m["power_ok"]


@settings(max_examples=150, deadline=None)
@given(random_network())
def test_power_balance_random(net):
    sol = solve(net)
    m = sol.metrics
    lhs = m["power_source_W"] + m["power_injections_W"]
    rhs = m["power_dissipated_W"] + m["power_load_W"]
    assert abs(lhs - rhs) <= 1e-9 * abs(lhs) + m["power_noise_floor_W"]
    assert m["power_ok"]
    assert m["power_dissipated_W"] >= 0.0
    # segment-level dissipation equals the reported total (excluding source series R)
    seg = float(np.nansum(sol.segment_power()))
    src_series = sum(s.series_resistance_ohm * sol.source_current[s.name] ** 2 for s in net.sources)
    assert math.isclose(seg + src_series, m["power_dissipated_W"], rel_tol=1e-9, abs_tol=1e-18)
