"""Sparse assembly, determinism, iterative vs direct, residual reporting."""
import numpy as np
import pytest
import scipy.sparse as sp

from powergrid.conductance import assemble_conductance, merge_zero_resistance
from powergrid.graph import Load, Network, NetType, VoltageSource
from powergrid.mesh import sheet_square
from powergrid.solver import SolverOptions, solve


def test_stamp_pattern():
    G = assemble_conductance(3, np.array([0, 1]), np.array([1, 2]), np.array([2.0, 5.0]))
    assert sp.isspmatrix_csr(G)
    assert np.allclose(G.toarray(), [[2, -2, 0], [-2, 7, -5], [0, -5, 5]])
    assert np.allclose(G.toarray(), G.toarray().T)
    assert np.allclose(G.sum(axis=1), 0)          # rows of a floating Laplacian sum to zero


def test_duplicate_edges_sum():
    G = assemble_conductance(2, np.array([0, 0]), np.array([1, 1]), np.array([1.0, 3.0]))
    assert np.allclose(G.toarray(), [[4, -4], [-4, 4]])


def test_zero_r_merge_labels():
    lab = merge_zero_resistance(5, np.array([0, 1, 3]), np.array([1, 2, 4]), np.array([0.0, 1.0, 0.0]))
    assert lab[0] == lab[1] and lab[3] == lab[4] and lab[1] != lab[2]


def _shuffled(n_order):
    net = Network("p"); net.add_net("VDD", NetType.POWER, 1.0)
    names = ["a", "b", "c", "d"]
    for k in n_order:
        net.add_node(names[k], "VDD")
    net.add_segment("a", "b", 1.0); net.add_segment("b", "c", 2.0); net.add_segment("c", "d", 0.5)
    net.add_segment("a", "c", 3.0)
    net.add_source(VoltageSource("V", "a", 1.0))
    net.add_load(Load("L", "d", None, current_a=0.1)); net.add_load(Load("M", "b", None, current_a=0.05))
    return net


def test_deterministic_regardless_of_insertion_order():
    s1 = solve(_shuffled([0, 1, 2, 3])); s2 = solve(_shuffled([3, 1, 0, 2]))
    for n in "abcd":
        assert s1.voltage(n) == s2.voltage(n)      # bit-identical


def test_repeat_runs_bit_identical():
    a = solve(sheet_square(10, 1e-3, 0.1, 1.0, 1e4)).node_voltage
    b = solve(sheet_square(10, 1e-3, 0.1, 1.0, 1e4)).node_voltage
    assert np.array_equal(a, b)


@pytest.mark.parametrize("pc", ["jacobi", "ilu", "none"])
def test_cg_matches_direct(pc):
    net = sheet_square(24, 1e-3, 0.1, 1.0, 1e4)
    d = solve(net)
    c = solve(net, SolverOptions(method="cg", preconditioner=pc, iterative_rtol=1e-13))
    assert np.max(np.abs(d.node_voltage - c.node_voltage)) < 1e-11
    assert c.metrics["cg_iterations"] and c.metrics["cg_iterations"][0] > 0
    assert c.metrics["kcl_ok"]


def test_metrics_report_matrix_and_residual():
    m = solve(sheet_square(8, 1e-3, 0.1, 1.0, 1e4)).metrics
    assert m["unknowns"] == 7 * 7 and m["matrix_nnz"] > 0
    assert m["residual_backward_error"] < 1e-14 and m["method"] == "direct"
    assert m["components"] >= 1 and m["floating_components"] == 0
