"""TEST G -- Kirchhoff's current law at every non-source node (property-based)."""
import numpy as np
from hypothesis import given, settings, strategies as st

from powergrid.graph import CurrentInjection, Load, Network, NetType, VoltageSource
from powergrid.solver import solve


@st.composite
def random_network(draw):
    n = draw(st.integers(3, 25))
    seed = draw(st.integers(0, 2**31 - 1))
    rng = np.random.default_rng(seed)
    net = Network("rand")
    net.add_net("VDD", NetType.POWER, 1.0)
    net.add_net("VSS", NetType.GROUND, 0.0)
    net.add_domain("D", "VDD", "VSS")
    for netname in ("VDD", "VSS"):
        for k in range(n):
            net.add_node(f"{netname}{k}", netname)
        for k in range(1, n):                      # random spanning tree
            j = int(rng.integers(0, k))
            net.add_segment(f"{netname}{j}", f"{netname}{k}", float(rng.uniform(1e-3, 10)))
        for _ in range(int(rng.integers(0, 2 * n))):   # extra edges (loops), some zero-R
            a, b = rng.integers(0, n, 2)
            if a != b:
                r = 0.0 if rng.random() < 0.05 else float(10 ** rng.uniform(-3, 1))
                net.add_segment(f"{netname}{a}", f"{netname}{b}", r)
    net.add_source(VoltageSource("Vdd", "VDD0", 1.0, series_resistance_ohm=float(rng.uniform(0, 0.5))))
    net.add_source(VoltageSource("Vss", "VSS0", 0.0))
    for k in range(1, n):
        if rng.random() < 0.6:
            net.add_load(Load(f"L{k}", f"VDD{k}", f"VSS{int(rng.integers(0, n))}",
                              current_a=float(rng.uniform(0, 0.01)), domain="D"))
    if rng.random() < 0.5:
        net.add_injection(CurrentInjection("I0", f"VDD{int(rng.integers(1, n))}", float(rng.uniform(-0.005, 0.005))))
    return net


@settings(max_examples=150, deadline=None)
@given(random_network())
def test_kcl_every_node(net):
    sol = solve(net)
    total = sum(abs(c) for c in sol.source_current.values())
    floor = sol.metrics["kcl_noise_floor_A"]
    assert np.max(np.abs(sol.kcl_residual)) <= 1e-9 * total + floor
    assert sol.metrics["kcl_ok"]
    # every load's return current reaches the VSS source
    assert abs(sol.metrics["global_current_balance_A"]) <= 1e-9 * total + net.n_nodes * floor


@settings(max_examples=60, deadline=None)
@given(random_network())
def test_kcl_independent_recomputation(net):
    """Recompute KCL from raw branch currents without using solver internals."""
    sol = solve(net)
    inflow = np.zeros(net.n_nodes)
    for s in range(net.n_segments):
        i = sol.segment_current[s]
        inflow[net.seg_a[s]] -= i
        inflow[net.seg_b[s]] += i
    for k, ld in enumerate(net.loads):
        inflow[net.node_index(ld.vdd_node)] -= sol.load_current[k]
        inflow[net.node_index(ld.vss_node)] += sol.load_current[k]
    for inj in net.injections:
        inflow[net.node_index(inj.node)] += inj.current_a
    src_nodes = {net.node_index(s.node) for s in net.sources}
    # sources with series R inject at their node through the series branch (not a network segment)
    for s in net.sources:
        if s.series_resistance_ohm > 0:
            inflow[net.node_index(s.node)] += sol.source_current[s.name]
            src_nodes.discard(net.node_index(s.node))
    mask = np.ones(net.n_nodes, dtype=bool)
    mask[list(src_nodes)] = False
    # nodes shorted to an ideal source node take part of the source current
    vsrc = {sol.node_voltage[net.node_index(s.node)] for s in net.sources if s.series_resistance_ohm == 0}
    total = sum(abs(c) for c in sol.source_current.values())
    floor = sol.metrics["kcl_noise_floor_A"]
    bad = [i for i in np.nonzero(mask)[0] if abs(inflow[i]) > 1e-9 * total + floor and not any(
        sol.node_voltage[i] == v and net.node_net[i] == "VSS" for v in vsrc)]
    assert not bad
