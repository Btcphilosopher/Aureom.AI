import math
import shutil

import numpy as np
import pytest

from powergrid.thermal import ThermalParams, solve_die_temperature
from powergrid.transient import RLCParams, load_step, ngspice_crosscheck, simulate, step_metrics


def test_final_value_and_lc_first_droop():
    p = RLCParams(1.0, 0.0, 1e-9, 1e-9, 1e-9, 0.0, 0.0)
    di = 0.1
    s = simulate(p, load_step(0.0, di, 1e-9, 1e-15), 300e-9, 5e-12)
    # lossless LC tank driven by a current step: v_min = V - dI * sqrt(L/C)
    assert 1.0 - s["v_load"].min() == pytest.approx(di * math.sqrt(1e-9 / 1e-9), rel=5e-3)
    p2 = RLCParams(1.2, 0.01, 0.05, 1e-9, 2e-9, 0.02, 0.5)
    s2 = simulate(p2, load_step(0.0, 0.02, 2e-9, 1e-9), 600e-9, 10e-12)
    assert s2["v_load"][-1] == pytest.approx(1.2 - 0.02 * (0.06 + 0.5), abs=2e-5)   # DC: I*(R_vrm+R_pkg+R_die)
    m = step_metrics(s2, 1.2, 0.005, 2e-9)
    assert m["v_min"] <= s2["v_load"][-1] and m["recovery_time_s"] > 0


@pytest.mark.skipif(shutil.which("ngspice") is None, reason="ngspice not installed")
def test_ngspice_crosscheck(tmp_path):
    p = RLCParams(1.2, 0.01, 0.05, 1e-9, 2e-9, 0.02, 1.0)
    r = ngspice_crosscheck(p, 0.007, 0.04, 20e-9, 1e-9, 150e-9, 10e-12, tmp_path)
    assert r["status"] == "RUN" and r["max_abs_diff_v"] < 1e-5


def test_uniform_heating_matches_theta():
    prm = ThermalParams(148.0, 300e-6, 40.0, 25.0, 8, 8)
    pm = np.full((8, 8), 0.5 / 64)
    T, info = solve_die_temperature(pm, 2e-3, 2e-3, prm)
    assert np.allclose(T, 25.0 + 0.5 * 40.0, atol=1e-9)        # no lateral gradient
    assert info["kcl_ok"]
