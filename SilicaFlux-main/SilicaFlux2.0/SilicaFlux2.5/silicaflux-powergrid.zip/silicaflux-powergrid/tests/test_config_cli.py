import subprocess
import sys
from pathlib import Path

import pytest
from pydantic import ValidationError

from powergrid.config import DesignConfig, MeshConfig
from powergrid.loads import load_block_powers, vcd_scope_check

ROOT = Path(__file__).resolve().parents[1]


def run(*args):
    return subprocess.run([sys.executable, "-m", "powergrid", *args], cwd=ROOT, capture_output=True, text=True, timeout=300)


def test_mesh_config_rejects_unitless_and_unknown_keys():
    with pytest.raises(ValidationError):
        MeshConfig(name="x", kind="sheet", n=8, side=2, sheet_resistance="0.1 ohm/sq", supply="1 V", current_density="1 A/m2")
    with pytest.raises(ValidationError):
        MeshConfig(name="x", kind="sheet", n=8, side="2 mm", sheet_resistance="0.1 ohm/sq", supply="1 V",
                   current_density="1 A/m2", typo=1)


def test_load_sources_mandatory():
    ls = load_block_powers({"blocks": {"cpu": {"power": "10 mW", "source": "ASSUMED"}, "tensor": {"power": "missing"}}})
    assert ls.total_w() == pytest.approx(0.01) and ls.missing() == ["tensor"]
    with pytest.raises(ValueError, match="source"):
        load_block_powers({"blocks": {"cpu": {"power": "10 mW"}}})


def test_vcd_scope_check(tmp_path):
    v = tmp_path / "t.vcd"
    v.write_text("$scope module tb $end\n$scope module u_cpu $end\n$upscope $end\n$upscope $end\n$enddefinitions $end\n")
    r = vcd_scope_check(v, ["u_cpu/_1_", "u_tile/_2_"])
    assert r["matched_prefixes"] == 1 and r["match_fraction"] == 0.5


def test_cli_solve_reference_mesh(tmp_path):
    r = run("solve", "--config", "configs/reference_mesh.yaml", "--out", str(tmp_path / "ref"))
    assert r.returncode == 0, r.stderr
    assert (tmp_path / "ref" / "run.json").exists() and (tmp_path / "ref" / "maps" / "ir_drop.png").exists()


def test_cli_invalid_config_exit_code(tmp_path):
    bad = tmp_path / "bad.yaml"
    bad.write_text("name: b\nkind: sheet\nn: 8\nside: 2\nsheet_resistance: '0.1 ohm/sq'\nsupply: '1 V'\ncurrent_density: '1 A/m2'\n")
    r = run("solve", "--config", str(bad), "--out", str(tmp_path / "o"))
    assert r.returncode == 3


def test_cli_missing_design_is_blocked():
    r = run("analyse", "--design", "mcu_i")
    assert r.returncode == 2 and "BLOCKED" in r.stderr
