"""TEST E -- adding a valid supply tap: hand-computed change under fixed load."""
import math

from powergrid.graph import Load, Network, NetType, VoltageSource
from powergrid.solver import solve


def line(n_nodes, r, i_load, taps):
    net = Network("line")
    net.add_net("VDD", NetType.POWER, 1.0)
    for k in range(n_nodes + 1):
        net.add_node(f"n{k}", "VDD", "M", float(k), 0.0)
    for k in range(n_nodes):
        net.add_segment(f"n{k}", f"n{k+1}", r)
    for t in taps:
        net.add_source(VoltageSource(f"tap{t}", f"n{t}", 1.0))
    for k in range(1, n_nodes + 1):
        if k not in taps:
            net.add_load(Load(f"L{k}", f"n{k}", None, current_a=i_load))
    return net


def test_one_tap_vs_two_taps():
    # 4 resistors R, loads I at n1..n4, tap at n0: drop(n4) = I R (4+3+2+1) = 10 I R
    R, I = 0.5, 0.01
    one = solve(line(4, R, I, taps=[0]))
    assert math.isclose(1.0 - one.voltage("n4"), 10 * I * R, rel_tol=1e-12)
    # add a tap at n4: loads n1..n3; symmetric about n2 -> currents: each tap supplies 1.5 I
    two = solve(line(4, R, I, taps=[0, 4]))
    # n1: drop = 1.5 I R ; n2: drop = 1.5 I R + 0.5 I R = 2 I R
    assert math.isclose(1.0 - two.voltage("n1"), 1.5 * I * R, rel_tol=1e-12)
    assert math.isclose(1.0 - two.voltage("n2"), 2.0 * I * R, rel_tol=1e-12)
    assert math.isclose(two.source_current["tap0"], 1.5 * I, rel_tol=1e-12)
    assert math.isclose(two.source_current["tap4"], 1.5 * I, rel_tol=1e-12)
    # worst drop falls from 10 IR to 2 IR (load at n4 removed: the tap replaces it)
    worst_one = max(1.0 - v for v in one.node_voltage)
    worst_two = max(1.0 - v for v in two.node_voltage)
    assert worst_two < worst_one


def test_tap_with_source_resistance_shares_unequally():
    # Two taps, different series resistance: current splits inversely to path resistance
    net = Network("share"); net.add_net("VDD", NetType.POWER, 1.0)
    net.add_node("a", "VDD"); net.add_node("b", "VDD"); net.add_node("l", "VDD")
    net.add_segment("a", "l", 0.1); net.add_segment("b", "l", 0.1)
    net.add_source(VoltageSource("pa", "a", 1.0, series_resistance_ohm=0.1))
    net.add_source(VoltageSource("pb", "b", 1.0, series_resistance_ohm=0.3))
    net.add_load(Load("L", "l", None, current_a=1.0))
    sol = solve(net)
    # paths: 0.2 ohm and 0.4 ohm -> 2/3 and 1/3 of the current
    assert math.isclose(sol.source_current["pa"], 2 / 3, rel_tol=1e-12)
    assert math.isclose(sol.source_current["pb"], 1 / 3, rel_tol=1e-12)
    assert math.isclose(sol.voltage("l"), 1.0 - (0.2 * 0.4 / 0.6), rel_tol=1e-12)
