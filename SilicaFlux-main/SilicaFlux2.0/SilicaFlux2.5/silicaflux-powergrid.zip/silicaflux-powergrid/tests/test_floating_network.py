"""TEST F -- floating / disconnected components and other invalid networks."""
import math

import numpy as np
import pytest

from conftest import chain
from powergrid.graph import Load, Network, NetType, NetworkError, VoltageSource
from powergrid.solver import (FloatingNetworkError, SolverOptions, VoltageSourceConflictError, solve)


def test_no_source_at_all_is_rejected():
    n = Network(); n.add_net("VDD", NetType.POWER, 1.0)
    n.add_node("a", "VDD"); n.add_node("b", "VDD"); n.add_segment("a", "b", 1.0)
    n.add_load(Load("L", "b", None, current_a=0.1))
    with pytest.raises(FloatingNetworkError, match="no voltage source"):
        solve(n)


def test_loaded_island_without_reference_is_rejected():
    n = chain([1.0], loads={"n1": 0.1})
    n.add_node("x", "VDD"); n.add_node("y", "VDD"); n.add_segment("x", "y", 1.0)
    n.add_load(Load("Lx", "y", None, current_a=0.05))
    with pytest.raises(FloatingNetworkError) as exc:
        solve(n)
    assert "underconstrained" in exc.value.reason
    comps = exc.value.details["components"]
    assert comps[0]["loaded"] is True and comps[0]["n_nodes"] == 2


def test_unloaded_island_rejected_by_default_and_reported_when_allowed():
    n = chain([1.0], loads={"n1": 0.1})
    n.add_node("x", "VDD"); n.add_node("y", "VDD"); n.add_segment("x", "y", 1.0)
    with pytest.raises(FloatingNetworkError):
        solve(n)
    sol = solve(n, SolverOptions(allow_unloaded_floating=True))
    assert math.isnan(sol.voltage("x")) and math.isnan(sol.voltage("y"))   # undefined, not 0 V
    assert sol.voltage("n1") == pytest.approx(0.9)
    assert len(sol.floating) == 1 and sol.metrics["floating_components"] == 1
    assert sol.segment_current[1] == 0.0


def test_no_conductance_to_ground_is_added():
    # the solution of the referenced part must be unaffected by the presence of the island
    a = solve(chain([1.0, 2.0], loads={"n2": 0.1}))
    n = chain([1.0, 2.0], loads={"n2": 0.1})
    n.add_node("iso", "VDD")
    b = solve(n, SolverOptions(allow_unloaded_floating=True))
    assert np.allclose(a.node_voltage, b.node_voltage[:3], atol=0, rtol=0)


def test_negative_nan_inf_resistance_rejected():
    n = Network(); n.add_net("VDD", NetType.POWER, 1.0); n.add_node("a", "VDD"); n.add_node("b", "VDD")
    for bad in (-1.0, float("nan"), float("inf")):
        with pytest.raises(NetworkError):
            n.add_segment("a", "b", bad)


def test_zero_resistance_is_an_exact_short():
    n = chain([1.0, 0.0, 1.0], loads={"n3": 0.1, "n1": 0.05})
    sol = solve(n)
    assert sol.voltage("n1") == sol.voltage("n2")
    assert sol.metrics["zero_resistance_merges"] == 1
    # current through the short reconstructed by KCL: 0.1 A flows n1 -> n2
    assert sol.current(1) == pytest.approx(0.1, abs=1e-15)
    assert sol.metrics["kcl_ok"] and sol.metrics["power_ok"]


def test_source_conflict_through_short_detected():
    n = Network(); n.add_net("VDD", NetType.POWER, 1.0)
    n.add_node("a", "VDD"); n.add_node("b", "VDD"); n.add_segment("a", "b", 0.0)
    n.add_source(VoltageSource("V1", "a", 1.0)); n.add_source(VoltageSource("V2", "b", 1.1))
    with pytest.raises(VoltageSourceConflictError):
        solve(n)


def test_equal_parallel_ideal_sources_allowed_but_split_flagged():
    n = Network(); n.add_net("VDD", NetType.POWER, 1.0)
    n.add_node("a", "VDD"); n.add_node("l", "VDD"); n.add_segment("a", "l", 1.0)
    n.add_source(VoltageSource("V1", "a", 1.0)); n.add_source(VoltageSource("V2", "a", 1.0))
    n.add_load(Load("L", "l", None, current_a=0.2))
    sol = solve(n)
    assert sol.source_current["V1"] + sol.source_current["V2"] == pytest.approx(0.2)
    assert any("not unique" in w for w in sol.warnings)


def test_cross_net_segment_and_wrong_net_source_rejected():
    n = Network(); n.add_net("VDD", NetType.POWER, 1.2); n.add_net("VSS", NetType.GROUND, 0.0)
    n.add_node("p", "VDD"); n.add_node("g", "VSS")
    with pytest.raises(NetworkError):
        n.add_segment("p", "g", 1.0)
    with pytest.raises(NetworkError, match="another domain"):
        n.add_source(VoltageSource("Vbad", "g", 1.2))
