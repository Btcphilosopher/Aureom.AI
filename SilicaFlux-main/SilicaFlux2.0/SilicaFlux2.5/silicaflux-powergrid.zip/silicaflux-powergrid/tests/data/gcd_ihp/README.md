# Test fixture: ORFS public reference design `gcd` on IHP SG13G2

Produced in this repository by running ORFS ab2aaf0f (OpenROAD 2.0-12331-g6011bbe77,
Yosys 0.38+92) `make DESIGN_CONFIG=designs/ihp-sg13g2/gcd/config.mk place`, then:

* `export/`      tcl/export_pdn.tcl (PG_POWER=1, vectorless input activity 0.1)
* `pdnsim_odb/`  tcl/run_pdnsim.tcl with the database (setRC-overwritten) resistances,
                 vsrc VDD at (-12.56, -10.22) um, VSS at (162.04, 161.98) um, write_pg_spice
* `pdnsim_lef/`  same with PG_RES_OVERRIDE = IHP tech-LEF resistances
* `3_place.odb`  placed database used by the optional OpenROAD integration test

This is a PUBLIC reference design; results here say nothing about SilicaFlux.
