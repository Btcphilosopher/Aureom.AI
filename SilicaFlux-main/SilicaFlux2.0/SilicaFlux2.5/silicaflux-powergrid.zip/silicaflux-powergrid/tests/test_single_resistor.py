"""TEST A -- single resistor: 1 V source, 1 ohm, 0.1 A load."""
import math

from conftest import chain
from powergrid.solver import solve


def test_single_resistor_hand_values():
    sol = solve(chain([1.0], v=1.0, loads={"n1": 0.1}))
    assert math.isclose(sol.voltage("n1"), 0.9, abs_tol=1e-12)          # load voltage
    assert math.isclose(sol.voltage("n0") - sol.voltage("n1"), 0.1, abs_tol=1e-12)  # resistor drop
    assert math.isclose(sol.current(0), 0.1, abs_tol=1e-12)
    assert math.isclose(sol.source_current["V"], 0.1, abs_tol=1e-12)
    m = sol.metrics
    assert math.isclose(m["power_source_W"], 0.1, abs_tol=1e-12)
    assert math.isclose(m["power_dissipated_W"], 0.01, abs_tol=1e-12)
    assert math.isclose(m["power_load_W"], 0.09, abs_tol=1e-12)
    assert m["kcl_ok"] and m["power_ok"]
    assert any("ideal 0 V reference" in w for w in sol.warnings)
