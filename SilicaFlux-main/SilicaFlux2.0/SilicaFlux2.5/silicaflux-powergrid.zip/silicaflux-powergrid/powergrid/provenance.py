"""Provenance and result-status vocabulary used throughout PowerGrid.

Two orthogonal vocabularies exist:

* :class:`DataSource` -- where an *input* number came from (load currents,
  activity, resistances, package values).
* :class:`ResultStatus` -- what kind of *result* a chart / table / gate is.
  The dashboard and reports must display one of these for every artefact.

A green PASS is only ever shown for a check that executed with real inputs;
see :func:`gate_colour`.
"""
from __future__ import annotations

from enum import Enum


class DataSource(str, Enum):
    MEASURED = "MEASURED"          # silicon / bench measurement
    SIMULATED = "SIMULATED"        # derived from a simulation trace (VCD/SAIF) or tool run
    MODELLED = "MODELLED"          # computed by a model from real library/design data
    ASSUMED = "ASSUMED"            # explicit user/demonstration assumption
    PDK = "PDK"                    # read from technology files (LEF/Liberty) of a named PDK
    TOOL_EXTRACTED = "TOOL_EXTRACTED"  # read from an EDA database (OpenDB/DEF)
    ANALYTICAL = "ANALYTICAL"      # closed-form reference value


class ResultStatus(str, Enum):
    ACTUAL_EDA_RESULT = "ACTUAL EDA RESULT"
    NUMERICAL_MODEL = "NUMERICAL MODEL"
    ASSUMPTION = "ASSUMPTION"
    DEMONSTRATION = "DEMONSTRATION"
    NOT_RUN = "NOT RUN"
    BLOCKED = "BLOCKED"


class CheckStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"
    NOT_ANALYSED = "NOT ANALYSED"
    NOT_RUN = "NOT RUN"
    BLOCKED = "BLOCKED"


def gate_colour(status: CheckStatus | str, executed: bool) -> str:
    """Colour for a gate badge.  Green only for an executed PASS."""
    s = CheckStatus(status) if not isinstance(status, CheckStatus) else status
    if s is CheckStatus.PASS and executed:
        return "pass"
    if s is CheckStatus.FAIL:
        return "fail"
    if s in (CheckStatus.BLOCKED,):
        return "blocked"
    return "neutral"
