"""Toolchain / environment audit (machine-readable)."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Any

from .flows import provenance_header

ROOT = Path(__file__).resolve().parents[1]


def toolchain_audit() -> dict[str, Any]:
    h = provenance_header()
    tools = {}
    for t, args in (("openroad", ["-version"]), ("yosys", ["-V"]), ("ngspice", ["-v"]), ("klayout", ["-v"]),
                    ("iverilog", ["-V"]), ("verilator", ["--version"])):
        exe = shutil.which(t) or (f"/opt/eda/env/bin/{t}" if Path(f"/opt/eda/env/bin/{t}").exists() else None)
        if exe is None:
            tools[t] = "NOT INSTALLED"
            continue
        try:
            out = subprocess.run([exe, *args], capture_output=True, text=True, timeout=30)
            line = next((l for l in (out.stdout + out.stderr).splitlines() if l.strip() and not set(l.strip()) <= {"*"}), "?")
            tools[t] = f"{exe}: {line.strip()[:100]}"
        except Exception as exc:  # noqa
            tools[t] = f"{exe}: ERROR {exc}"
    pdks = {}
    for name, p in (("ihp_sg13g2", "/opt/eda/orfs/flow/platforms/ihp-sg13g2/lef/sg13g2_tech.lef"),
                    ("sky130hd", "/opt/eda/orfs/flow/platforms/sky130hd/lef/sky130_fd_sc_hd.tlef"),
                    ("gf180mcu", "/opt/eda/orfs/flow/platforms/gf180/lef/gf180mcu_5LM_1TM_9K_9t_tech.lef"),
                    ("ihp_sram_collateral", "/opt/eda/collateral/ihp-sg13g2-sram-d0e5b3c/lef"),
                    ("commercial_130/65/28", None)):
        pdks[name] = "present" if p and Path(p).exists() else ("BLOCKED (no licensed kit)" if p is None else "MISSING")
    return {"header": h, "tools": tools, "pdks": pdks,
            "floorplanlab": str((ROOT.parent / "silicaflux-floorplanlab").resolve()) if (ROOT.parent / "silicaflux-floorplanlab").exists() else "MISSING"}
