"""Engineering quality gates (brief section 30), evaluated from evidence files.

A gate is PASS only if the check executed and its evidence file exists.
PARTIAL means some, but not all, required checks executed (never shown green).
"""
from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parents[1]

GATES = {
    1: "Circuit model mathematically valid",
    2: "Sparse solver passes reference tests",
    3: "Current conservation verified",
    4: "Power balance verified",
    5: "Floating network detection verified",
    6: "Real PDN geometry loaded",
    7: "Layer and via resistance data validated",
    8: "Power/ground connectivity checked",
    9: "Supply source locations verified",
    10: "Load current provenance established",
    11: "Static IR-drop simulation completed",
    12: "Independent comparison against PDNSim performed",
    13: "Critical voltage-drop regions identified",
    14: "Current-density screening completed",
    15: "PDN optimisation validated against physical design rules",
    16: "Timing and thermal implications documented",
    17: "Results reproducible",
}


def _junit(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    root = ET.parse(path).getroot()
    cases: dict[str, str] = {}
    for tc in root.iter("testcase"):
        name = f"{tc.get('classname')}::{tc.get('name')}"
        st = "passed"
        for child in tc:
            if child.tag in ("failure", "error"):
                st = "failed"
            elif child.tag == "skipped":
                st = "skipped"
        cases[name] = st
    return cases


def _all(cases: dict[str, str], modules: list[str]) -> Optional[bool]:
    sel = {k: v for k, v in cases.items() if any(m in k for m in modules)}
    if not sel:
        return None
    return all(v == "passed" for v in sel.values())


def evaluate(reports: Path) -> list[dict[str, Any]]:
    cases = _junit(reports / "tests" / "junit.xml")
    ana = reports / "silicaflux_v" / "analysis" / "run.json"
    run = json.loads(ana.read_text()) if ana.exists() else None
    opt = reports / "optimisation" / "pdn_sweep" / "summary.json"
    optj = json.loads(opt.read_text()) if opt.exists() else None
    det = reports / "tests" / "reproducibility.json"
    detj = json.loads(det.read_text()) if det.exists() else None
    out: list[dict[str, Any]] = []

    def add(n: int, status: str, evidence: str, note: str = "") -> None:
        out.append({"gate": n, "title": GATES[n], "status": status, "evidence": evidence, "note": note})

    for n, mods in ((1, ["test_single_resistor", "test_series_parallel", "test_ground_network", "test_units"]),
                    (2, ["test_sparse_solver", "test_mesh_reference", "test_supply_taps", "test_constant_power"]),
                    (3, ["test_kcl"]), (4, ["test_power_balance"]), (5, ["test_floating_network"])):
        ok = _all(cases, mods)
        add(n, "NOT RUN" if ok is None else ("PASS" if ok else "FAIL"), "reports/tests/junit.xml", ", ".join(mods))
    if run is None:
        for n in range(6, 15):
            add(n, "NOT RUN", "reports/silicaflux_v/analysis/run.json missing")
    else:
        imp = run.get("import", {})
        add(6, "PASS" if imp.get("wires", 0) > 0 and imp.get("vias", 0) > 0 else "FAIL", "analysis run.json: import",
            f"{imp.get('wires')} wires, {imp.get('vias')} vias, {imp.get('std_cells_attached')} cells, "
            f"{imp.get('macros_attached')} macros from OpenDB")
        add(7, "UNKNOWN", "tables/resistance_sources.csv",
            "values come from the IHP tech LEF, but the OpenDB/ORFS setRC data differ 1.6-10x and no foundry process "
            "specification was available to arbitrate -> not validated")
        add(8, run["connectivity"]["status"], "evidence/check/check_*.rpt", "OpenROAD check_power_grid on VDD and VSS")
        add(9, "BLOCKED", "configs/designs/silicaflux_v.yaml supply_models",
            "no pad ring / package exists for SilicaFlux-V; supply taps are ASSUMED candidates")
        add(10, "PASS", "evidence/export/power.csv.gz", "provenance MODELLED (OpenSTA vectorless); not workload-representative")
        sm = run.get("supply_models", {})
        add(11, "PASS" if sm and all(v.get("kcl_ok") and v.get("power_ok") for v in sm.values()) else "FAIL",
            "tables/supply_models.csv", "custom solver on the extracted PDN; KCL and power balance verified")
        pd = run.get("pdnsim", {}).get("runs", {})
        ok12 = bool(pd) and all(r["status"] == "ACTUAL EDA RESULT" for r in pd.values())
        agree = []
        for r in pd.values():
            for n_, v in r.get("nets", {}).items():
                c = v.get("comparison", {}).get("pdnsim_watts/pin")
                if c:
                    agree.append(c["status"] == "AGREE")
        add(12, "PASS" if ok12 and agree and all(agree) else ("FAIL" if pd else "NOT RUN"), "evidence/pdnsim_*",
            "equivalent assumptions: worst drop within tolerance; physical I=P/V differs by the 1/V convention (finding)")
        add(13, "PASS" if run.get("groups") else "NOT RUN", "tables/groups_*.csv")
        em = run.get("current_density", {}).get("em", {})
        add(14, "PASS" if em.get("counts") else "NOT RUN", "tables/top_segments_*.csv",
            "screening vs LEF DC limits only (no EM signoff)")
    if optj is None:
        add(15, "NOT RUN", "reports/optimisation/pdn_sweep/summary.json missing")
    else:
        rej = [v for v in optj["variants"] if v.get("status") == "REJECTED"]
        val = [v for v in optj["variants"] if v.get("status") == "VALID"]
        add(15, "PARTIAL" if val else "FAIL", "reports/optimisation/pdn_sweep",
            f"{len(val)} variants regenerated + check_power_grid + check_placement passed, {len(rej)} rejected; "
            "full DRC (KLayout deck) NOT RUN")
    add(16, "PASS" if run and run.get("timing") else "NOT RUN", "tables/timing_risk_*.csv, experiments J",
        "voltage-aware STA BLOCKED (no low-voltage Liberty); thermal ASSUMED parameters")
    if detj:
        add(17, "PASS" if detj.get("bit_identical") and detj.get("pdn_regen_identical", True) else "FAIL",
            "reports/tests/reproducibility.json", json.dumps(detj)[:200])
    else:
        add(17, "NOT RUN", "reports/tests/reproducibility.json missing")
    out.sort(key=lambda g: g["gate"])
    return out
