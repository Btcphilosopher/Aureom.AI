"""Stand-alone PDN connectivity check (OpenROAD check_power_grid)."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import DesignConfig
from .flows import _jsonable, provenance_header
from .openroad_adapter import DesignInputs, OpenROAD, ToolchainError


def check_pdn(cfg_path: Path, out: Path) -> dict[str, Any]:
    cfg = DesignConfig.load(cfg_path)
    ora = OpenROAD()
    if not ora.available():
        raise ToolchainError("OpenROAD not installed (env/install_toolchain.sh)")
    di = DesignInputs(cfg.name, cfg.odb, cfg.tech_lef, cfg.lefs, cfg.libs, cfg.sdc)
    missing = di.validate()
    if missing:
        raise FileNotFoundError(f"physical design inputs missing: {missing}")
    out.mkdir(parents=True, exist_ok=True)
    r = ora.run("check_pdn.tcl", {**di.env(), "PG_OUT": str(out)}, out / "check_pdn.log", "check_power_grid")
    checks = [x for x in r.records if x["_tag"] == "PG-CHECK"]
    ok = r.ok and len(checks) == 2 and all(c.get("result") == "true" and c.get("error_lines", 1) == 0 for c in checks)
    res = {"status": "PASS" if ok else "FAIL", "checks": checks, "step": r.as_dict(), "header": provenance_header(),
           "inputs_sha256": di.hashes()}
    (out / "run.json").write_text(json.dumps(_jsonable(res), indent=1))
    return res
