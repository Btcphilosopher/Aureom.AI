"""Import a physical PDN exported from OpenDB (tcl/export_pdn.tcl) into a Network.

Extraction model (documented in docs/PDN_EXTRACTION.md)
-------------------------------------------------------
* Every special-wire rectangle (rail, strap, ring) of a PG net becomes a 1-D
  conductor along its long axis, width = short side, R = Rs * L / W with Rs
  from the selected technology source (tech LEF by default).
* Breakpoints (nodes) are placed on a wire at: every via landing inside the
  wire, every same-layer overlap/abutment with another wire of the same net,
  every load attachment and every supply source.  Wire stubs beyond the
  outermost breakpoint carry no current and are not modelled.
* A via instance joins its bottom-layer and top-layer landing points with
  R = R_cut / n_cuts (cut-layer resistance from the technology; lumped array).
  Stacked vias share their intermediate landing nodes (same x, y, layer).
* Same-layer overlaps of two wires of the same net are ideal joins (R = 0,
  merged by the solver): physically one piece of metal.
* Standard cells: the cell's PG pin is attached at the pin's x-centre on the
  bottom-layer rail of its net that overlaps the pin ("pin" mode), or -- to
  reproduce PDNSim 6011bbe77 -- at the node nearest to the instance origin on a
  node-density grid ("pdnsim" mode).
* Macros (BLOCK): current spread equally over the via landing nodes of the
  net inside the macro outline on the lowest PDN layer present there (PDNSim
  methodology).  Macro-internal PG resistance is not modelled (the LEF
  abstract carries none).
* Unsupported / suspicious structures are recorded, never silently dropped:
  wires without any breakpoint (floating), vias whose landing point touches
  no wire and no other via (dangling), vias whose layers have no resistance.
"""
from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np

from .graph import Load, LoadModel, Network, NetType, NetworkError, SegmentKind, VoltageSource
from .provenance import DataSource
from .technology import TechData, TechnologyError

__all__ = ["PDNExport", "read_export", "SourceSpec", "ImportOptions", "ImportReport", "build_network"]


@dataclass
class Wire:
    net: str
    layer: str
    x0: int
    y0: int
    x1: int
    y1: int
    shape: str

    @property
    def horizontal(self) -> bool:
        return (self.x1 - self.x0) >= (self.y1 - self.y0)

    @property
    def width(self) -> int:
        return (self.y1 - self.y0) if self.horizontal else (self.x1 - self.x0)

    @property
    def centre(self) -> int:
        return (self.y0 + self.y1) // 2 if self.horizontal else (self.x0 + self.x1) // 2


@dataclass
class ViaDef:
    name: str
    bottom: str
    cut: str
    top: str
    cuts: int


@dataclass
class PDNExport:
    root: Path
    meta: dict[str, Any]
    wires: list[Wire]
    vias: list[tuple[str, int, int, str]]          # net, x, y, via def name
    via_defs: dict[str, ViaDef]
    insts: dict[str, dict[str, Any]]
    power_w: dict[str, float]
    bterms: list[dict[str, Any]]

    @property
    def dbu(self) -> int:
        return int(self.meta["dbu"])


def canonical_name(name: str) -> str:
    """Instance-name key shared by OpenDB (escaped: g_sram\\[0\\]) and OpenSTA (g_sram[0])."""
    return name.replace("\\", "")


def _open(root: Path, name: str):
    """Open name or name.gz inside root (evidence directories store bulky CSVs compressed)."""
    import gzip
    p = root / name
    if p.exists():
        return open(p)
    if (root / (name + ".gz")).exists():
        return gzip.open(root / (name + ".gz"), "rt")
    raise FileNotFoundError(f"{p} (or .gz) not found")


def read_export(path: str | Path) -> PDNExport:
    root = Path(path)
    meta = json.loads((root / "meta.json").read_text())
    wires: list[Wire] = []
    with _open(root, "wires.csv") as fh:
        for row in csv.DictReader(fh):
            wires.append(Wire(row["net"], row["layer"], int(row["x0"]), int(row["y0"]), int(row["x1"]), int(row["y1"]), row["shape"]))
    vias: list[tuple[str, int, int, str]] = []
    with _open(root, "vias.csv") as fh:
        for row in csv.DictReader(fh):
            vias.append((row["net"], int(row["x"]), int(row["y"]), row["via"]))
    via_defs: dict[str, ViaDef] = {}
    with _open(root, "via_defs.csv") as fh:
        for row in csv.DictReader(fh):
            via_defs[row["via"]] = ViaDef(row["via"], row["bottom"], row["cut"], row["top"], int(row["cuts"]))
    insts: dict[str, dict[str, Any]] = {}
    with _open(root, "insts.csv") as fh:
        for row in csv.DictReader(fh):
            d = insts.setdefault(canonical_name(row["inst"]), {
                "master": row["master"], "type": row["type"], "placed": row["placed"] == "1",
                "orient": row["orient"], "bbox": tuple(int(row[k]) for k in ("x0", "y0", "x1", "y1")), "pins": {},
            })
            if row.get("pin"):
                box = tuple(int(row[k]) for k in ("px0", "py0", "px1", "py1"))
                if row["pg_net"]:
                    d["pins"].setdefault(row["pg_net"], []).append((row["pin"], box))
                else:
                    # PG ITerm without a net in the database (e.g. buffers inserted after global_connect)
                    d.setdefault("unconnected_pg", []).append((row.get("sig", ""), row["pin"], box))
    power: dict[str, float] = {}
    if (root / "power.csv").exists() or (root / "power.csv.gz").exists():
        with _open(root, "power.csv") as fh:
            for row in csv.DictReader(fh):
                power[canonical_name(row["inst"])] = float(row["total_w"])
    bterms: list[dict[str, Any]] = []
    if (root / "bterms.csv").exists():
        with open(root / "bterms.csv") as fh:
            bterms = list(csv.DictReader(fh))
    return PDNExport(root, meta, wires, vias, via_defs, insts, power, bterms)


# ----------------------------------------------------------------------------- options
@dataclass
class SourceSpec:
    name: str
    net: str
    x_um: float
    y_um: float
    layer: Optional[str] = None          # default: top PDN layer of the net
    series_resistance_ohm: float = 0.0
    voltage_v: Optional[float] = None    # default: net nominal
    kind: str = "explicit"
    provenance: str = DataSource.ASSUMED.value


@dataclass
class ImportOptions:
    power_net: str = "VDD"
    ground_net: str = "VSS"
    vdd_v: float = 1.2
    attach: str = "pin"                   # pin | pdnsim
    node_density_um: Optional[float] = None   # pdnsim attach mode: rail node spacing
    current_conversion: str = "nominal"   # nominal (I=P/Vnom) | local (constant power, iterative) | pdnsim_watts (I=P numerically)
    load_provenance: str = DataSource.MODELLED.value
    include_ground: bool = True
    current_scale: float = 1.0
    extra_block_current_a: dict[str, float] = field(default_factory=dict)   # macro inst -> A (ASSUMED loads)
    merge_loads_per_node: bool = True


@dataclass
class ImportReport:
    wires: int = 0
    wires_floating: int = 0
    vias: int = 0
    vias_dangling: int = 0
    via_levels: dict[str, int] = field(default_factory=dict)
    junctions: int = 0
    instances: int = 0
    std_cells_attached: int = 0
    macros_attached: int = 0
    instances_unpowered: list[str] = field(default_factory=list)
    instances_unplaced: list[str] = field(default_factory=list)
    macros_without_landing: list[str] = field(default_factory=list)
    power_missing: list[str] = field(default_factory=list)
    total_power_w: float = 0.0
    total_current_a: float = 0.0
    unsupported: list[str] = field(default_factory=list)
    resistance_source: str = ""
    sources: list[dict[str, Any]] = field(default_factory=list)
    macro_pin_landings: int = 0
    pg_iterms_unconnected_in_db: list[str] = field(default_factory=list)
    inst_attach: dict[str, tuple[str, Optional[str]]] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        d = dict(self.__dict__)
        d.pop("inst_attach", None)
        for k in ("instances_unpowered", "instances_unplaced", "macros_without_landing", "power_missing",
                  "pg_iterms_unconnected_in_db"):
            v = d[k]
            d[k] = {"count": len(v), "examples": v[:10]}
        return d


# ----------------------------------------------------------------------------- builder
class _NetBuilder:
    """Per-net breakpoint collection on wires."""

    CELL = 20000  # spatial hash cell (dbu)

    def __init__(self, net: str, wires: list[Wire]) -> None:
        self.net = net
        self.wires = wires
        self.breaks: list[set[int]] = [set() for _ in wires]
        self.by_layer: dict[str, dict[tuple[int, int], list[int]]] = defaultdict(lambda: defaultdict(list))
        for i, w in enumerate(wires):
            g = self.by_layer[w.layer]
            for cx in range(w.x0 // self.CELL, w.x1 // self.CELL + 1):
                for cy in range(w.y0 // self.CELL, w.y1 // self.CELL + 1):
                    g[(cx, cy)].append(i)

    def wires_at(self, layer: str, x: int, y: int) -> list[int]:
        g = self.by_layer.get(layer)
        if not g:
            return []
        out = []
        for i in g.get((x // self.CELL, y // self.CELL), []):
            w = self.wires[i]
            if w.x0 <= x <= w.x1 and w.y0 <= y <= w.y1:
                out.append(i)
        return out

    def add_break(self, wi: int, x: int, y: int) -> tuple[int, int]:
        w = self.wires[wi]
        if w.horizontal:
            self.breaks[wi].add(x)
            return (x, w.centre)
        self.breaks[wi].add(y)
        return (w.centre, y)


def _nid(net: str, layer: str, x: int, y: int) -> str:
    return f"{net}|{layer}|{x}|{y}"


def build_network(
    exp: PDNExport,
    tech: TechData,
    sources: list[SourceSpec],
    opts: ImportOptions,
) -> tuple[Network, ImportReport]:
    rep = ImportReport(resistance_source=f"{tech.source}: {', '.join(tech.files)}")
    dbu = exp.dbu
    um = 1e-6 / 1.0
    to_m = 1e-6 / dbu
    net = Network(f"{exp.meta.get('design', 'design')}_pdn")
    nets = [opts.power_net] + ([opts.ground_net] if opts.include_ground else [])
    net.add_net(opts.power_net, NetType.POWER, opts.vdd_v)
    if opts.include_ground:
        net.add_net(opts.ground_net, NetType.GROUND, 0.0)
        net.add_domain("CORE", opts.power_net, opts.ground_net)
    layer_order = tech.layer_order()
    lindex = {n: i for i, n in enumerate(layer_order)}
    rail_layer = layer_order[0]
    for w in exp.wires:
        if w.layer not in lindex:
            rep.unsupported.append(f"wire on non-routing layer {w.layer}")

    builders: dict[str, _NetBuilder] = {}
    node_xy: dict[str, tuple[int, int, str]] = {}
    for n in nets:
        ws = [w for w in exp.wires if w.net == n and w.layer in lindex]
        builders[n] = _NetBuilder(n, ws)
        rep.wires += len(ws)

    # ---------------------------------------------------------------- vias -> landing points
    via_links: dict[str, list[tuple[str, str, float, int, str]]] = defaultdict(list)
    landing_count: dict[str, int] = defaultdict(int)
    pending: list[tuple[str, int, int, ViaDef]] = []
    free_landings: set[str] = set()
    for vnet, x, y, vname in exp.vias:
        if vnet not in builders:
            continue
        vd = exp.via_defs.get(vname)
        if vd is None:
            rep.unsupported.append(f"via {vname}: definition missing")
            continue
        pending.append((vnet, x, y, vd))
    for vnet, x, y, vd in pending:
        b = builders[vnet]
        ends = []
        for layer in (vd.bottom, vd.top):
            hits = b.wires_at(layer, x, y)
            if hits:
                pts = [b.add_break(wi, x, y) for wi in hits]
                # all wires hit at this point are joined to the first landing node
                ids = [_nid(vnet, layer, px, py) for px, py in pts]
                for (px, py), nid_ in zip(pts, ids):
                    node_xy[nid_] = (px, py, layer)
                for other in ids[1:]:
                    if other != ids[0]:
                        via_links[vnet].append((ids[0], other, 0.0, 0, "junction"))
                ends.append(ids[0])
            else:
                nid_ = _nid(vnet, layer, x, y)
                node_xy[nid_] = (x, y, layer)
                free_landings.add(nid_)
                ends.append(nid_)
            landing_count[ends[-1]] += 1
        try:
            rcut = tech.via_resistance_per_cut(vd.cut)
        except TechnologyError as exc:
            raise TechnologyError(f"PDN via {vd.name} on {vnet}: {exc}") from exc
        via_links[vnet].append((ends[0], ends[1], rcut / vd.cuts, vd.cuts, vd.cut))
        rep.vias += 1
        rep.via_levels[vd.cut] = rep.via_levels.get(vd.cut, 0) + 1

    # ---------------------------------------------------------------- same-layer junctions
    for n, b in builders.items():
        per_layer: dict[str, list[int]] = defaultdict(list)
        for i, w in enumerate(b.wires):
            per_layer[w.layer].append(i)
        for layer, idxs in per_layer.items():
            if len(idxs) < 2:
                continue
            W = np.array([[b.wires[i].x0, b.wires[i].y0, b.wires[i].x1, b.wires[i].y1] for i in idxs], dtype=np.int64)
            order = np.argsort(W[:, 0], kind="stable")
            Ws = W[order]
            for p in range(len(order)):
                x1p = Ws[p, 2]
                q = p + 1
                while q < len(order) and Ws[q, 0] <= x1p:
                    if Ws[q, 1] <= Ws[p, 3] and Ws[p, 1] <= Ws[q, 3]:
                        i, j = idxs[order[p]], idxs[order[q]]
                        cx = (max(Ws[p, 0], Ws[q, 0]) + min(Ws[p, 2], Ws[q, 2])) // 2
                        cy = (max(Ws[p, 1], Ws[q, 1]) + min(Ws[p, 3], Ws[q, 3])) // 2
                        pi_ = b.add_break(i, int(cx), int(cy)); pj = b.add_break(j, int(cx), int(cy))
                        a_id, b_id = _nid(n, layer, *pi_), _nid(n, layer, *pj)
                        node_xy[a_id] = (pi_[0], pi_[1], layer); node_xy[b_id] = (pj[0], pj[1], layer)
                        if a_id != b_id:
                            via_links[n].append((a_id, b_id, 0.0, 0, "junction"))
                        rep.junctions += 1
                    q += 1

    # ---------------------------------------------------------------- loads: attachment points
    load_pts: dict[str, list[tuple[str, str, float]]] = {}   # inst -> [(net, node_id, weight)]
    vnom = opts.vdd_v
    rail_nodes_cache: dict[str, Any] = {}
    nd = None
    if opts.attach == "pdnsim":
        nd = int(round((opts.node_density_um or 18.9) * dbu))

    def rail_attach(n: str, pin_box: tuple[int, int, int, int], origin: tuple[int, int]) -> Optional[str]:
        b = builders[n]
        x0, y0, x1, y1 = pin_box
        xc = (x0 + x1) // 2
        cands = []
        g = b.by_layer.get(rail_layer, {})
        seen: set[int] = set()
        for cx in range(x0 // b.CELL, x1 // b.CELL + 1):
            for cy in range(y0 // b.CELL, y1 // b.CELL + 1):
                for i in g.get((cx, cy), []):
                    if i in seen:
                        continue
                    seen.add(i)
                    w = b.wires[i]
                    if w.horizontal and w.x0 <= xc <= w.x1 and not (w.y1 < y0 or w.y0 > y1):
                        cands.append(i)
        if not cands:
            return None
        wi = min(cands, key=lambda i: abs(b.wires[i].centre - (y0 + y1) // 2))
        w = b.wires[wi]
        if opts.attach == "pdnsim" and nd:
            # PDNSim 6011bbe77: current at the instance ORIGIN, snapped to the rail node grid
            ox = origin[0]
            gx = w.x0 + int(round((ox - w.x0) / nd)) * nd
            gx = min(max(gx, w.x0), w.x1)
            px, py = b.add_break(wi, gx, w.centre)
        else:
            px, py = b.add_break(wi, xc, w.centre)
        nid_ = _nid(n, rail_layer, px, py)
        node_xy[nid_] = (px, py, rail_layer)
        return nid_

    for name, d in exp.insts.items():
        rep.instances += 1
        if not d["placed"]:
            rep.instances_unplaced.append(name)
            continue
        p_inst = exp.power_w.get(name)
        extra = opts.extra_block_current_a.get(name)
        if p_inst is None and extra is None:
            if d["type"] in ("CORE", "BLOCK") and d["pins"]:
                rep.power_missing.append(name)
            continue
        if d["type"] == "BLOCK":
            apts: list[tuple[str, str, float]] = []
            bx0, by0, bx1, by1 = d["bbox"]
            for n in nets:
                cand = [nid_ for nid_ in free_landings
                        if nid_.startswith(n + "|") and bx0 <= node_xy[nid_][0] <= bx1 and by0 <= node_xy[nid_][1] <= by1]
                if not cand:
                    continue
                low = min(lindex.get(node_xy[c][2], 99) for c in cand)
                cand = [c for c in cand if lindex.get(node_xy[c][2], 99) == low]
                apts.extend((n, c, 1.0 / len(cand)) for c in sorted(cand))
            if not apts or opts.power_net not in {q[0] for q in apts}:
                rep.macros_without_landing.append(name)
                continue
            load_pts[name] = apts
            rep.macros_attached += 1
        else:
            apts = []
            if d.get("unconnected_pg"):
                rep.pg_iterms_unconnected_in_db.append(name)
                for sig, pin, box in d["unconnected_pg"]:
                    target = opts.power_net if sig == "POWER" else opts.ground_net if sig == "GROUND" else None
                    if target is not None and target in nets and target not in d["pins"]:
                        d["pins"].setdefault(target, []).append((pin, box))
            for n in nets:
                pins = d["pins"].get(n)
                if not pins:
                    continue
                # union bbox of the cell's PG pin shapes for this net
                bx = (min(pb[0] for _, pb in pins), min(pb[1] for _, pb in pins),
                      max(pb[2] for _, pb in pins), max(pb[3] for _, pb in pins))
                att = rail_attach(n, bx, (d["bbox"][0], d["bbox"][1]))
                if att is not None:
                    apts.append((n, att, 1.0))
            if opts.power_net not in {q[0] for q in apts} or (opts.include_ground and opts.ground_net not in {q[0] for q in apts}):
                rep.instances_unpowered.append(name)
                continue
            load_pts[name] = apts
            rep.inst_attach[name] = (apts[0][1], apts[1][1] if len(apts) > 1 else None)
            rep.std_cells_attached += 1

    # ---------------------------------------------------------------- sources (snap)
    src_nodes: list[tuple[SourceSpec, str]] = []
    for s in sources:
        if s.net not in builders:
            raise NetworkError(f"source {s.name}: net {s.net} not in the imported nets {nets}")
        b = builders[s.net]
        layer = s.layer or max({w.layer for w in b.wires}, key=lambda l: lindex[l])
        sx, sy = int(round(s.x_um * dbu)), int(round(s.y_um * dbu))
        # nearest existing breakpoint (via/junction) on the layer; else a new break on the nearest wire
        best = None
        for nid_, (x, y, layer_) in node_xy.items():
            if layer_ == layer and nid_.startswith(s.net + "|"):
                dd = (x - sx) ** 2 + (y - sy) ** 2
                if best is None or dd < best[0]:
                    best = (dd, nid_)
        if best is None:
            raise NetworkError(f"source {s.name}: no {s.net} node on layer {layer}")
        src_nodes.append((s, best[1]))
        x, y, _ = node_xy[best[1]]
        rep.sources.append({"name": s.name, "net": s.net, "requested_um": [s.x_um, s.y_um],
                            "snapped_um": [x / dbu, y / dbu], "layer": layer,
                            "distance_um": math.sqrt(best[0]) / dbu, "series_ohm": s.series_resistance_ohm,
                            "kind": s.kind, "provenance": s.provenance})

    # ---------------------------------------------------------------- materialise wires
    for n, b in builders.items():
        for wi, w in enumerate(b.wires):
            bpts = sorted(b.breaks[wi])
            if not bpts:
                rep.wires_floating += 1
                continue
            if len(bpts) == 1:
                continue
            rs = tech.sheet_resistance(w.layer)
            thick = tech.routing[w.layer].thickness_um
            ids = [(_nid(n, w.layer, t, w.centre) if w.horizontal else _nid(n, w.layer, w.centre, t)) for t in bpts]
            xs = np.array([(t if w.horizontal else w.centre) for t in bpts], float) * to_m
            ys = np.array([(w.centre if w.horizontal else t) for t in bpts], float) * to_m
            idx = net.add_nodes_bulk(ids, n, w.layer, xs, ys)
            L = np.diff(np.array(bpts, float)) * to_m
            width = w.width * to_m
            keep = L > 0
            limit = None
            jmax = tech.routing[w.layer].dc_current_ma_per_um
            if jmax is not None:
                limit = np.full(int(keep.sum()), jmax * 1e-3 * (w.width / dbu))   # mA/um * um -> A
            net.add_segments_bulk(idx[:-1][keep], idx[1:][keep], rs * L[keep] / width, kind=SegmentKind.METAL,
                                  layer=w.layer, length_m=L[keep], width_m=np.full(int(keep.sum()), width),
                                  thickness_m=None if thick is None else thick * 1e-6, current_limit_a=limit,
                                  provenance=f"{DataSource.TOOL_EXTRACTED.value}+{tech.source}")
    # remaining standalone landing nodes (stack intermediates, macro pins)
    for nid_, (x, y, layer) in node_xy.items():
        if not net.has_node(nid_):
            n = nid_.split("|", 1)[0]
            net.add_node(nid_, n, layer, x * to_m, y * to_m)
    for n, links in via_links.items():
        by_kind: dict[str, list[tuple[str, str, float, int, str]]] = defaultdict(list)
        for l in links:
            by_kind[l[4]].append(l)
        for cut, ls in by_kind.items():
            a = np.array([net.node_index(l[0]) for l in ls]); bb = np.array([net.node_index(l[1]) for l in ls])
            r = np.array([l[2] for l in ls]); cuts = np.array([l[3] for l in ls])
            ok = a != bb
            if cut == "junction":
                net.add_segments_bulk(a[ok], bb[ok], r[ok], kind=SegmentKind.CONTACT, layer="same-layer-junction",
                                      provenance=DataSource.TOOL_EXTRACTED.value)
            else:
                lim = tech.cuts[cut].dc_current_ma_per_cut
                net.add_segments_bulk(a[ok], bb[ok], r[ok], kind=SegmentKind.VIA, layer=cut, via_cuts=cuts[ok],
                                      current_limit_a=None if lim is None else cuts[ok] * lim * 1e-3,
                                      provenance=f"{DataSource.TOOL_EXTRACTED.value}+{tech.source}")
    # dangling via landings: a node touched by exactly one via and by no wire
    wire_nodes = set()
    for n, b in builders.items():
        for wi, w in enumerate(b.wires):
            for t in b.breaks[wi]:
                wire_nodes.add(_nid(n, w.layer, t, w.centre) if w.horizontal else _nid(n, w.layer, w.centre, t))
    macro_boxes = [d["bbox"] for d in exp.insts.values() if d["type"] == "BLOCK"]

    def in_macro(x: int, y: int) -> bool:
        return any(b0 <= x <= b2 and b1 <= y <= b3 for b0, b1, b2, b3 in macro_boxes)

    dangling = [nid_ for nid_, c in landing_count.items()
                if c == 1 and nid_ in free_landings and nid_ not in wire_nodes]
    rep.macro_pin_landings = sum(1 for nid_ in dangling if in_macro(*node_xy[nid_][:2]))
    rep.vias_dangling = len(dangling) - rep.macro_pin_landings

    # ---------------------------------------------------------------- sources
    for s, nid_ in src_nodes:
        v = s.voltage_v if s.voltage_v is not None else (opts.vdd_v if s.net == opts.power_net else 0.0)
        x, y, _ = node_xy[nid_]
        net.add_source(VoltageSource(s.name, nid_, v, s.series_resistance_ohm, kind=s.kind, provenance=s.provenance,
                                     x_m=x * to_m, y_m=y * to_m))

    # ---------------------------------------------------------------- loads
    per_node: dict[tuple[str, Optional[str]], float] = defaultdict(float)
    per_node_block: dict[tuple[str, Optional[str]], str] = {}
    total_p = 0.0
    for name, lpts in load_pts.items():
        p_w = exp.power_w.get(name, 0.0) * opts.current_scale
        total_p += p_w
        if opts.current_conversion == "pdnsim_watts":
            i_tot = p_w                       # PDNSim 6011bbe77: power value injected as current
        else:
            i_tot = p_w / vnom
        i_tot += opts.extra_block_current_a.get(name, 0.0)
        vdd_pts = [q for q in lpts if q[0] == opts.power_net]
        vss_pts = [q for q in lpts if q[0] == opts.ground_net] if opts.include_ground else []
        if exp.insts[name]["type"] == "BLOCK":
            # pair macro VDD landings with the nearest VSS landing
            vss_arr = np.array([node_xy[q[1]][:2] for q in vss_pts], float) if vss_pts else None
            for (_, nv, wgt) in vdd_pts:
                vs: Optional[str] = None
                if vss_arr is not None:
                    xy = np.array(node_xy[nv][:2], float)
                    vs = vss_pts[int(np.argmin(np.hypot(*(vss_arr - xy).T)))][1]
                key = (nv, vs)
                per_node[key] += i_tot * wgt
                per_node_block[key] = name
        else:
            key = (vdd_pts[0][1], vss_pts[0][1] if vss_pts else None)
            per_node[key] += i_tot
            per_node_block.setdefault(key, name)
    rep.total_power_w = total_p
    k = 0
    for (nv, ns), cur in sorted(per_node.items()):
        if cur == 0.0:
            continue
        net.add_load(Load(f"L{k}", nv, ns, current_a=cur, domain="CORE" if opts.include_ground else None,
                          block=per_node_block[(nv, ns)], provenance=opts.load_provenance))
        k += 1
    rep.total_current_a = float(sum(per_node.values()))
    net.metadata.update({"dbu": dbu, "die": exp.meta.get("die"), "core": exp.meta.get("core"),
                         "design": exp.meta.get("design"), "power_label": exp.meta.get("power_label"),
                         "layer_order": layer_order, "import": rep.as_dict(),
                         "load_instances": {f"L{i}": None for i in range(0)}})
    return net, rep


def load_instance_map(net: Network) -> dict[str, list[str]]:
    """Load name -> instance(s): stored in load.block for std cells (first instance at the node)."""
    out: dict[str, list[str]] = defaultdict(list)
    for ld in net.loads:
        out[ld.block or ""].append(ld.name)
    return out
