"""Validated run configurations (Pydantic v2).

Every dimensional value is a string with an explicit unit (``"1.2 V"``),
parsed by :mod:`powergrid.units`; bare numbers for dimensional fields are
rejected.  Unknown keys are rejected (``extra='forbid'``) so typos cannot
silently fall back to defaults.
"""
from __future__ import annotations

import glob
import os
from pathlib import Path
from typing import Any, Literal, Optional

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .units import parse_quantity

ROOT = Path(__file__).resolve().parents[1]

__all__ = ["load_yaml", "MeshConfig", "DesignConfig", "SupplyModel", "TapSpec", "resolve_path"]


def resolve_path(p: str, base: Path) -> str:
    env = dict(os.environ)
    env.setdefault("ORFS_FLOW", "/opt/eda/orfs/flow")
    env.setdefault("IHP_SRAM", "/opt/eda/collateral/ihp-sg13g2-sram-d0e5b3c")
    env.setdefault("FLP_ROOT", str((ROOT.parent / "silicaflux-floorplanlab").resolve()))
    import re
    p = re.sub(r"\$\{(\w+)\}", lambda m: env.get(m.group(1), m.group(0)), p)
    q = Path(p)
    return str(q if q.is_absolute() else (base / q).resolve())


def load_yaml(path: str | Path) -> dict[str, Any]:
    d = yaml.safe_load(Path(path).read_text())
    if not isinstance(d, dict):
        raise ValueError(f"{path}: top level must be a mapping")
    return d


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


# ----------------------------------------------------------------------------- reference mesh
class MeshConfig(_Strict):
    name: str
    kind: Literal["sheet", "grid"]
    fidelity: str = "NUMERICAL MODEL"
    # sheet
    n: Optional[int] = None
    side: Optional[str] = None
    sheet_resistance: Optional[str] = None
    supply: str
    current_density: Optional[str] = None
    # strap grid
    grid: Optional[dict[str, Any]] = None
    solver: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check(self) -> "MeshConfig":
        parse_quantity(self.supply, "voltage", field="supply")
        if self.kind == "sheet":
            for f in ("n", "side", "sheet_resistance", "current_density"):
                if getattr(self, f) is None:
                    raise ValueError(f"sheet mesh needs '{f}'")
            parse_quantity(self.side, "length", field="side")
            parse_quantity(self.sheet_resistance, "sheet_resistance", field="sheet_resistance")
            parse_quantity(self.current_density, "current_density", field="current_density")
        elif self.grid is None:
            raise ValueError("grid mesh needs a 'grid' section")
        return self


# ----------------------------------------------------------------------------- physical design
class TapSpec(_Strict):
    side: Literal["bottom", "top", "left", "right", "xy"]
    position: Optional[float] = None       # fraction along the side (0..1)
    x: Optional[str] = None
    y: Optional[str] = None


class SupplyModel(_Strict):
    name: str
    kind: Literal["wirebond_ring_taps", "area_array_hypothetical", "explicit"]
    description: str
    provenance: str = "ASSUMED"
    taps_per_side: Optional[int] = None
    sides: list[str] = Field(default_factory=lambda: ["bottom", "top", "left", "right"])
    pitch: Optional[str] = None             # area array pitch
    series_resistance: str = "0 ohm"
    taps: list[TapSpec] = Field(default_factory=list)

    @field_validator("series_resistance")
    @classmethod
    def _r(cls, v: str) -> str:
        parse_quantity(v, "resistance", field="series_resistance")
        return v


class DesignConfig(_Strict):
    name: str
    description: str
    technology: str
    odb: str
    sdc: Optional[str] = None
    tech_lef: str
    lefs: list[str]
    libs: list[str]
    pdn_tcl: Optional[str] = None
    pdn_params: dict[str, Any] = Field(default_factory=dict)
    power_net: str = "VDD"
    ground_net: str = "VSS"
    activity: dict[str, Any] = Field(default_factory=dict)
    groups: list[dict[str, Any]] = Field(default_factory=list)
    supply_models: list[SupplyModel]
    default_supply_model: str
    resistance_sources: list[str] = Field(default_factory=lambda: ["tech_lef", "odb_tech"])
    primary_resistance_source: Literal["tech_lef", "odb_tech", "orfs_setrc"] = "tech_lef"
    timing_reports: dict[str, str] = Field(default_factory=dict)
    provenance: dict[str, Any] = Field(default_factory=dict)
    voltage_margin: Optional[dict[str, Any]] = None

    @classmethod
    def load(cls, path: str | Path) -> "DesignConfig":
        p = Path(path).resolve()
        d = load_yaml(p)
        base = p.parent
        for k in ("odb", "sdc", "tech_lef", "pdn_tcl", "technology"):
            if d.get(k):
                d[k] = resolve_path(d[k], base)
        d["lefs"] = [resolve_path(x, base) for x in d.get("lefs", [])]
        libs: list[str] = []
        for x in d.get("libs", []):
            r = resolve_path(x, base)
            hits = sorted(glob.glob(r))
            libs.extend(hits if hits else [r])
        d["libs"] = libs
        d["timing_reports"] = {k: resolve_path(v, base) for k, v in d.get("timing_reports", {}).items()}
        cfg = cls(**d)
        if cfg.default_supply_model not in {s.name for s in cfg.supply_models}:
            raise ValueError(f"default_supply_model {cfg.default_supply_model} is not defined")
        return cfg

    def supply(self, name: Optional[str] = None) -> SupplyModel:
        n = name or self.default_supply_model
        for s in self.supply_models:
            if s.name == n:
                return s
        raise KeyError(f"supply model {n!r} not defined (have {[s.name for s in self.supply_models]})")
