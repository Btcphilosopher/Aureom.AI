"""Generators for structured PDN networks.

* :func:`sheet_square` -- a uniform resistive sheet discretised on an N x N
  grid (used for the mesh-refinement convergence study, TEST J).
* :func:`build_strap_grid` -- a multi-layer, two-net (VDD + VSS) strap grid
  with rails, straps, optional core ring, via arrays at every same-net
  crossing, supply pads with series resistance and block loads.  Used for
  the SilicaFlux-V *demonstration* experiments (all inputs labelled).

Geometry convention: coordinates in metres, origin at the lower-left core
corner, layer direction 'H' (wires along x) or 'V' (wires along y).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np

from .graph import Load, LoadModel, Network, NetType, SegmentKind, VoltageSource
from .provenance import DataSource

__all__ = ["sheet_square", "LayerDef", "ViaDef", "PadDef", "BlockLoad", "GridSpec", "build_strap_grid"]


def sheet_square(
    n: int,
    side_m: float,
    sheet_res_ohm_sq: float,
    v_supply: float,
    current_density_a_m2: float,
) -> Network:
    """Uniform sheet (side x side) held at ``v_supply`` on its whole boundary,
    loaded by a uniform areal current density.  Node-centred grid with spacing
    h = side/n; interior nodes carry a load of j*h^2; neighbouring nodes are
    joined by a square of sheet (R = Rs).  Continuous reference: the Poisson
    problem  Rs^-1 * lap(v) = j  with Dirichlet boundary.
    """
    if n < 2:
        raise ValueError("n >= 2")
    net = Network(f"sheet_{n}")
    net.add_net("VDD", NetType.POWER, v_supply)
    h = side_m / n
    ids = [[f"n{i}_{j}" for j in range(n + 1)] for i in range(n + 1)]
    for i in range(n + 1):
        for j in range(n + 1):
            net.add_node(ids[i][j], "VDD", "sheet", i * h, j * h)
    for i in range(n + 1):
        for j in range(n + 1):
            if i < n and not (j in (0, n)):
                net.add_segment(ids[i][j], ids[i + 1][j], sheet_res_ohm_sq, kind=SegmentKind.METAL,
                                layer="sheet", length_m=h, width_m=h, provenance=DataSource.ANALYTICAL.value)
            if j < n and not (i in (0, n)):
                net.add_segment(ids[i][j], ids[i][j + 1], sheet_res_ohm_sq, kind=SegmentKind.METAL,
                                layer="sheet", length_m=h, width_m=h, provenance=DataSource.ANALYTICAL.value)
    k = 0
    for i in range(n + 1):
        for j in range(n + 1):
            boundary = i in (0, n) or j in (0, n)
            if boundary:
                net.add_source(VoltageSource(f"b{k}", ids[i][j], v_supply, provenance=DataSource.ANALYTICAL.value))
                k += 1
            else:
                net.add_load(Load(f"L{i}_{j}", ids[i][j], None, current_a=current_density_a_m2 * h * h,
                                  provenance=DataSource.ANALYTICAL.value))
    net.metadata["center_node"] = ids[n // 2][n // 2] if n % 2 == 0 else None
    return net


# ----------------------------------------------------------------------------- strap grid
@dataclass
class LayerDef:
    name: str
    direction: str                 # 'H' or 'V'
    width_m: float
    pitch_m: float                 # same-net pitch; VDD and VSS interleave at pitch/2
    offset_m: float
    sheet_res_ohm_sq: float
    thickness_m: Optional[float] = None
    provenance: str = DataSource.ASSUMED.value


@dataclass
class ViaDef:
    lower: str
    upper: str
    resistance_per_cut_ohm: float
    cuts: int
    provenance: str = DataSource.ASSUMED.value


@dataclass
class PadDef:
    name: str
    net: str
    x_m: float
    y_m: float
    layer: str                     # layer the pad attaches to (nearest node of that layer/net)
    voltage_v: float
    series_resistance_ohm: float
    kind: str = "wirebond_pad"
    provenance: str = DataSource.ASSUMED.value


@dataclass
class BlockLoad:
    name: str
    x0_m: float
    y0_m: float
    x1_m: float
    y1_m: float
    current_a: Optional[float] = None
    power_w: Optional[float] = None
    model: LoadModel = LoadModel.FIXED_CURRENT
    provenance: str = DataSource.ASSUMED.value
    layer: Optional[str] = None    # attach layer (default: lowest layer)


@dataclass
class GridSpec:
    width_m: float
    height_m: float
    layers: list[LayerDef]
    vias: list[ViaDef]
    pads: list[PadDef]
    loads: list[BlockLoad] = field(default_factory=list)
    vdd_net: str = "VDD"
    vss_net: str = "VSS"
    vdd_v: float = 1.2
    ring_layers: Optional[tuple[str, str]] = None   # (H layer, V layer) ring around the core
    ring_width_m: float = 0.0
    model_ground: bool = True
    name: str = "strap_grid"


def _positions(extent: float, pitch: float, offset: float) -> np.ndarray:
    if pitch <= 0:
        raise ValueError("pitch must be > 0")
    xs = np.arange(offset, extent + 1e-15, pitch)
    return xs[(xs >= 0) & (xs <= extent)]


def build_strap_grid(spec: GridSpec) -> Network:
    """Multi-layer VDD/VSS strap grid with vias at every same-net crossing.

    VDD wires of a layer sit at ``offset + k*pitch``; VSS wires at
    ``offset + pitch/2 + k*pitch``.  A wire is split into segments at every
    via crossing (and ring junction), so each segment is R = Rs*L/W.
    """
    net = Network(spec.name)
    net.add_net(spec.vdd_net, NetType.POWER, spec.vdd_v)
    nets = [(spec.vdd_net, 0.0)]
    if spec.model_ground:
        net.add_net(spec.vss_net, NetType.GROUND, 0.0)
        net.add_domain("CORE", spec.vdd_net, spec.vss_net)
        nets.append((spec.vss_net, 0.5))
    W, H = spec.width_m, spec.height_m
    layer_by = {l.name: l for l in spec.layers}
    # wire coordinates per (net, layer)
    wires: dict[tuple[str, str], np.ndarray] = {}
    for netname, shift in nets:
        for l in spec.layers:
            extent = H if l.direction == "H" else W
            wires[(netname, l.name)] = _positions(extent, l.pitch_m, l.offset_m + shift * l.pitch_m)
    # breakpoints along each wire = coordinates of crossing wires of adjacent layers (same net)
    adj: dict[str, list[str]] = {l.name: [] for l in spec.layers}
    for v in spec.vias:
        adj[v.lower].append(v.upper)
        adj[v.upper].append(v.lower)

    def node_id(netname: str, layer: str, x: float, y: float) -> str:
        return f"{netname}:{layer}:{x*1e6:.4f}:{y*1e6:.4f}"

    for netname, _ in nets:
        for l in spec.layers:
            coords = wires[(netname, l.name)]
            cross: list[float] = [0.0, W if l.direction == "H" else H]
            for other in adj[l.name]:
                cross.extend(wires[(netname, other)].tolist())
            along = np.unique(np.round(np.array(cross), 12))
            for c in coords:
                prev = None
                for t in along:
                    x, y = (t, c) if l.direction == "H" else (c, t)
                    nid = node_id(netname, l.name, x, y)
                    net.add_node(nid, netname, l.name, x, y)
                    if prev is not None:
                        length = t - prev[1]
                        if length > 0:
                            net.add_metal_segment(prev[0], nid, layer=l.name, length_m=length, width_m=l.width_m,
                                                  sheet_resistance_ohm_sq=l.sheet_res_ohm_sq,
                                                  thickness_m=l.thickness_m, provenance=l.provenance)
                    prev = (nid, t)
        for v in spec.vias:
            lo, up = layer_by[v.lower], layer_by[v.upper]
            if lo.direction == up.direction:
                raise ValueError(f"via {v.lower}-{v.upper}: parallel layers do not cross")
            hl, vl = (lo, up) if lo.direction == "H" else (up, lo)
            for y in wires[(netname, hl.name)]:
                for x in wires[(netname, vl.name)]:
                    net.add_via(node_id(netname, v.lower, x, y), node_id(netname, v.upper, x, y), layer=f"{v.lower}-{v.upper}",
                                resistance_per_cut_ohm=v.resistance_per_cut_ohm, cuts=v.cuts, provenance=v.provenance)
        # ring: connect the ends of every wire of the ring layers along the core boundary
        if spec.ring_layers is not None:
            for lname in spec.ring_layers:
                l = layer_by[lname]
                ends = []
                for c in wires[(netname, lname)]:
                    if l.direction == "H":
                        ends.append(("W", node_id(netname, lname, 0.0, c), c))
                        ends.append(("E", node_id(netname, lname, W, c), c))
                    else:
                        ends.append(("S", node_id(netname, lname, c, 0.0), c))
                        ends.append(("N", node_id(netname, lname, c, H), c))
                for side in ("W", "E", "S", "N"):
                    pts = sorted([(c, nid) for s, nid, c in ends if s == side])
                    for (c0, n0), (c1, n1) in zip(pts, pts[1:]):
                        net.add_metal_segment(n0, n1, layer=f"{lname}_ring", length_m=c1 - c0,
                                              width_m=spec.ring_width_m or l.width_m,
                                              sheet_resistance_ohm_sq=l.sheet_res_ohm_sq, provenance=l.provenance)
    # pads: nearest node of the pad's net on the pad's layer
    xs = np.asarray(net.node_x)
    ys = np.asarray(net.node_y)
    nets_a = np.asarray(net.node_net, dtype=object)
    lays_a = np.asarray([l or "" for l in net.node_layer], dtype=object)
    for p in spec.pads:
        cand_a = np.nonzero((nets_a == p.net) & (lays_a == p.layer))[0]
        if cand_a.size == 0:
            raise ValueError(f"pad {p.name}: no {p.net} node on layer {p.layer}")
        d = np.hypot(xs[cand_a] - p.x_m, ys[cand_a] - p.y_m)
        nid = net.node_ids[int(cand_a[int(np.argmin(d))])]
        net.add_source(VoltageSource(p.name, nid, p.voltage_v, p.series_resistance_ohm, kind=p.kind,
                                     provenance=p.provenance, x_m=p.x_m, y_m=p.y_m))
    # loads: block current spread uniformly over the attach-layer nodes inside the block;
    # each VDD attach node is paired with the nearest VSS node of the same layer (KD-tree)
    from scipy.spatial import cKDTree
    low = spec.layers[0].name
    xs = np.asarray(net.node_x); ys = np.asarray(net.node_y)
    nets_arr = np.asarray(net.node_net, dtype=object)
    lay_arr = np.asarray([l or "" for l in net.node_layer], dtype=object)
    for b in spec.loads:
        lyr = b.layer or low
        inside = (xs >= b.x0_m) & (xs <= b.x1_m) & (ys >= b.y0_m) & (ys <= b.y1_m) & (lay_arr == lyr)
        vdd_nodes = np.nonzero(inside & (nets_arr == spec.vdd_net))[0]
        if vdd_nodes.size == 0:
            raise ValueError(f"load {b.name}: no {spec.vdd_net} node on {lyr} inside the block")
        pair: Optional[np.ndarray] = None
        if spec.model_ground:
            vss_nodes = np.nonzero(inside & (nets_arr == spec.vss_net))[0]
            if vss_nodes.size == 0:
                raise ValueError(f"load {b.name}: no {spec.vss_net} node on {lyr} inside the block")
            tree = cKDTree(np.c_[xs[vss_nodes], ys[vss_nodes]])
            _, k = tree.query(np.c_[xs[vdd_nodes], ys[vdd_nodes]])
            pair = vss_nodes[k]
        n = vdd_nodes.size
        for k, iv in enumerate(vdd_nodes):
            vss_node = net.node_ids[int(pair[k])] if pair is not None else None
            if b.model is LoadModel.FIXED_CURRENT:
                net.add_load(Load(f"{b.name}#{k}", net.node_ids[iv], vss_node, current_a=(b.current_a or 0.0) / n,
                                  block=b.name, provenance=b.provenance,
                                  domain="CORE" if spec.model_ground else None))
            else:
                net.add_load(Load(f"{b.name}#{k}", net.node_ids[iv], vss_node, model=LoadModel.FIXED_POWER,
                                  power_w=(b.power_w or 0.0) / n, block=b.name, provenance=b.provenance,
                                  domain="CORE" if spec.model_ground else None))
    net.metadata.update({"width_m": W, "height_m": H, "generator": "build_strap_grid"})
    return net
