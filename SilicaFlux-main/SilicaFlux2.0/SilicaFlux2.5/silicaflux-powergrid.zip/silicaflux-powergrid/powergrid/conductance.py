"""Sparse conductance-matrix assembly and network topology analysis.

Nodal analysis: for every resistive edge (a, b) with conductance g = 1/R

    G[a, a] += g     G[b, b] += g
    G[a, b] -= g     G[b, a] -= g

Zero-resistance edges are NOT turned into huge conductances; their end nodes
are merged into one *supernode* (union-find) so the matrix stays well
conditioned and the short is exact.  Prescribed-voltage (Dirichlet) supernodes
are eliminated from the unknown vector:

    G_UU v_U = i_U - G_UF v_F

No conductance to ground is ever added to make a matrix invertible.  A
component without a voltage reference is reported (``FloatingComponent``)
instead.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

import numpy as np
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components

__all__ = [
    "merge_zero_resistance",
    "assemble_conductance",
    "Topology",
    "build_topology",
]


def merge_zero_resistance(n: int, a: np.ndarray, b: np.ndarray, r: np.ndarray) -> np.ndarray:
    """Return a cluster label for every node after merging R == 0 edges.

    Nodes joined by a chain of zero-resistance edges share a label; every
    other node has a label of its own.  (Vectorised: connected components of
    the zero-resistance subgraph.)
    """
    zero = np.nonzero(np.asarray(r) == 0.0)[0]
    if zero.size == 0:
        return np.arange(n, dtype=np.int64)
    adj = sp.coo_matrix((np.ones(zero.size), (np.asarray(a)[zero], np.asarray(b)[zero])), shape=(n, n))
    _, labels = connected_components(adj, directed=False)
    return labels.astype(np.int64)


def assemble_conductance(n: int, a: np.ndarray, b: np.ndarray, g: np.ndarray) -> sp.csr_matrix:
    """Assemble the symmetric n x n nodal conductance matrix (CSR)."""
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    g = np.asarray(g, dtype=float)
    rows = np.concatenate([a, b, a, b])
    cols = np.concatenate([a, b, b, a])
    vals = np.concatenate([g, g, -g, -g])
    G = sp.coo_matrix((vals, (rows, cols)), shape=(n, n)).tocsr()
    G.sum_duplicates()
    return G


@dataclass
class Topology:
    """Supernode mapping, partitions and connectivity of an extended network."""

    n_ext: int                          # extended nodes (network nodes + internal source nodes)
    super_of: np.ndarray                # extended node -> supernode index
    n_super: int
    edge_sa: np.ndarray                 # positive-R edges in supernode space
    edge_sb: np.ndarray
    edge_g: np.ndarray
    edge_ext: np.ndarray                # index of the edge in the extended edge list
    component: np.ndarray               # supernode -> connected-component id
    n_components: int
    internal_loop_edges: list[int] = field(default_factory=list)  # positive-R edges inside one supernode


def build_topology(
    n_ext: int,
    a: np.ndarray,
    b: np.ndarray,
    r: np.ndarray,
    canonical_rank: np.ndarray,
) -> Topology:
    """Merge zero-R edges, number supernodes deterministically, find components.

    ``canonical_rank[i]`` defines the deterministic ordering of extended node
    ``i`` (e.g. its position in the sorted list of node names).  Supernodes
    are numbered by the smallest rank among their members.
    """
    roots = merge_zero_resistance(n_ext, a, b, r)
    # rank of each root = min rank of members
    uniq_roots, inv = np.unique(roots, return_inverse=True)
    min_rank = np.full(len(uniq_roots), np.iinfo(np.int64).max, dtype=np.int64)
    np.minimum.at(min_rank, inv, canonical_rank.astype(np.int64))
    order = np.argsort(min_rank, kind="stable")
    new_id = np.empty_like(order)
    new_id[order] = np.arange(len(order))
    super_of = new_id[inv]
    n_super = len(uniq_roots)

    pos = np.nonzero(r > 0.0)[0]
    sa = super_of[a[pos]]
    sb = super_of[b[pos]]
    internal = pos[sa == sb]
    keep = sa != sb
    sa, sb, ext = sa[keep], sb[keep], pos[keep]
    g = 1.0 / r[ext]
    adj = sp.coo_matrix((np.ones(len(sa)), (sa, sb)), shape=(n_super, n_super))
    ncomp, comp = connected_components(adj, directed=False)
    return Topology(
        n_ext=n_ext,
        super_of=super_of,
        n_super=n_super,
        edge_sa=sa,
        edge_sb=sb,
        edge_g=g,
        edge_ext=ext,
        component=comp,
        n_components=int(ncomp),
        internal_loop_edges=[int(i) for i in internal],
    )


def conductance_ratio(g: Sequence[float]) -> float:
    arr = np.asarray(g, dtype=float)
    if arr.size == 0:
        return 1.0
    return float(arr.max() / arr.min())
