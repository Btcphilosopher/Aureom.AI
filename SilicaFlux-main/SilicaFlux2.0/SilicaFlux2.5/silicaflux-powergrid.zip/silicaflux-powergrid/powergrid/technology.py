"""Technology data: per-layer sheet resistance, via resistance, current limits.

Numbers are never typed into PowerGrid.  They are read from the PDK files a
technology profile points to:

* ``tech_lef``   -- LEF ``RESISTANCE RPERSQ`` (routing layers), cut-layer
  ``RESISTANCE`` (ohm per cut) or VIA-definition ``RESISTANCE``,
  ``THICKNESS``, ``WIDTH``, ``DIRECTION``, ``DCCURRENTDENSITY AVERAGE``
  (mA/um for routing layers, mA per cut for cut layers).
* ``orfs_setrc`` -- the ORFS platform ``setRC.tcl`` (``set_layer_rc``):
  per-unit-length resistance used by OpenROAD's parasitic estimation.  It is a
  *correlation* file, not foundry data; it is offered only as an explicitly
  selected alternative and every result records which source was used.

If a layer or via resistance a network needs is missing from the selected
source, :class:`TechnologyError` is raised -- nothing is substituted.
"""
from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

__all__ = [
    "TechnologyError",
    "RoutingLayer",
    "CutLayer",
    "TechData",
    "parse_lef",
    "parse_setrc",
    "TechnologyProfile",
    "load_profile",
]


class TechnologyError(RuntimeError):
    pass


@dataclass
class RoutingLayer:
    name: str
    index: int                       # order in the LEF stack (0 = lowest)
    direction: Optional[str]         # HORIZONTAL / VERTICAL
    width_um: Optional[float]        # default (minimum) width
    pitch_um: Optional[float]
    thickness_um: Optional[float]
    rpersq_ohm: Optional[float]      # sheet resistance, ohm/sq
    dc_current_ma_per_um: Optional[float]  # DCCURRENTDENSITY AVERAGE (LEF: mA/um)
    min_spacing_um: Optional[float] = None
    max_width_um: Optional[float] = None


@dataclass
class CutLayer:
    name: str
    index: int
    below: Optional[str]
    above: Optional[str]
    resistance_per_cut_ohm: Optional[float]
    dc_current_ma_per_cut: Optional[float]
    cut_width_um: Optional[float]


@dataclass
class TechData:
    source: str                      # tech_lef | orfs_setrc
    files: list[str]
    sha256: dict[str, str]
    routing: dict[str, RoutingLayer] = field(default_factory=dict)
    cuts: dict[str, CutLayer] = field(default_factory=dict)
    via_def_resistance: dict[str, float] = field(default_factory=dict)  # VIA name -> ohm (whole via)
    notes: list[str] = field(default_factory=list)

    def layer_order(self) -> list[str]:
        return [l.name for l in sorted(self.routing.values(), key=lambda l: l.index)]

    def sheet_resistance(self, layer: str) -> float:
        lyr = self.routing.get(layer)
        if lyr is None:
            raise TechnologyError(f"layer {layer!r} is not a routing layer of this technology "
                                  f"(available: {self.layer_order()})")
        if lyr.rpersq_ohm is None or not lyr.rpersq_ohm > 0:
            raise TechnologyError(f"no sheet resistance for layer {layer} in {self.source} ({self.files})")
        return lyr.rpersq_ohm

    def cut_between(self, lower: str, upper: str) -> CutLayer:
        for c in self.cuts.values():
            if c.below == lower and c.above == upper:
                return c
        raise TechnologyError(f"no cut layer between {lower} and {upper}")

    def via_resistance_per_cut(self, cut_layer: str) -> float:
        c = self.cuts.get(cut_layer)
        if c is None:
            raise TechnologyError(f"unknown cut layer {cut_layer!r}")
        if c.resistance_per_cut_ohm is None or not c.resistance_per_cut_ohm > 0:
            raise TechnologyError(
                f"no per-cut resistance for {cut_layer} in {self.source} ({self.files}); refusing to "
                "invent a via resistance"
            )
        return c.resistance_per_cut_ohm

    def summary(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "files": self.files,
            "sha256": self.sha256,
            "routing": {n: l.__dict__ for n, l in sorted(self.routing.items(), key=lambda kv: kv[1].index)},
            "cuts": {n: c.__dict__ for n, c in sorted(self.cuts.items(), key=lambda kv: kv[1].index)},
            "notes": self.notes,
        }


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


_NUM = r"([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)"


def parse_lef(path: str | Path) -> TechData:
    """Parse the technology part of a LEF file (layers, cut resistances, VIA resistances)."""
    p = Path(path)
    if not p.is_file():
        raise TechnologyError(f"technology LEF not found: {p}")
    text = p.read_text(errors="replace")
    # strip comments
    lines = [ln.split("#", 1)[0] for ln in text.splitlines()]
    td = TechData(source="tech_lef", files=[str(p)], sha256={str(p): _sha(p)})
    order: list[tuple[str, str]] = []           # (name, type) in file order for ROUTING/CUT
    i = 0
    n = len(lines)
    while i < n:
        ln = lines[i].strip()
        m = re.match(r"^LAYER\s+(\S+)\s*$", ln)
        mv = re.match(r"^VIA\s+(\S+)(\s+DEFAULT)?\s*$", ln)
        if m:
            name = m.group(1)
            body: list[str] = []
            i += 1
            while i < n and not re.match(rf"^\s*END\s+{re.escape(name)}\s*$", lines[i]):
                body.append(lines[i].strip())
                i += 1
            blob = " ".join(body)
            tm = re.search(r"\bTYPE\s+(\w+)", blob)
            ltype = tm.group(1) if tm else ""
            if ltype == "ROUTING":
                def f(pattern: str) -> Optional[float]:
                    mm = re.search(pattern, blob)
                    return float(mm.group(1)) if mm else None
                direction = re.search(r"\bDIRECTION\s+(\w+)", blob)
                td.routing[name] = RoutingLayer(
                    name=name, index=len(order),
                    direction=direction.group(1) if direction else None,
                    width_um=f(rf"(?<![A-Z])WIDTH\s+{_NUM}\s*;"),
                    pitch_um=f(rf"\bPITCH\s+{_NUM}"),
                    thickness_um=f(rf"\bTHICKNESS\s+{_NUM}"),
                    rpersq_ohm=f(rf"\bRESISTANCE\s+RPERSQ\s+{_NUM}"),
                    dc_current_ma_per_um=f(rf"\bDCCURRENTDENSITY\s+AVERAGE\s+{_NUM}"),
                    min_spacing_um=f(rf"\bSPACING\s+{_NUM}\s*;"),
                    max_width_um=f(rf"\bMAXWIDTH\s+{_NUM}"),
                )
                order.append((name, "ROUTING"))
            elif ltype == "CUT":
                rm = re.search(rf"\bRESISTANCE\s+{_NUM}", blob)
                dm = re.search(rf"\bDCCURRENTDENSITY\s+AVERAGE\s+{_NUM}", blob)
                wm = re.search(rf"(?<![A-Z])WIDTH\s+{_NUM}", blob)
                td.cuts[name] = CutLayer(
                    name=name, index=len(order), below=None, above=None,
                    resistance_per_cut_ohm=float(rm.group(1)) if rm else None,
                    dc_current_ma_per_cut=float(dm.group(1)) if dm else None,
                    cut_width_um=float(wm.group(1)) if wm else None,
                )
                order.append((name, "CUT"))
        elif mv:
            name = mv.group(1)
            body = []
            i += 1
            while i < n and not re.match(rf"^\s*END\s+{re.escape(name)}\s*$", lines[i]):
                body.append(lines[i].strip())
                i += 1
            blob = " ".join(body)
            rm = re.search(rf"\bRESISTANCE\s+{_NUM}", blob)
            if rm:
                td.via_def_resistance[name] = float(rm.group(1))
        i += 1
    # link cut layers to their neighbours in the stack
    for k, (name, typ) in enumerate(order):
        if typ != "CUT":
            continue
        below = next((order[j][0] for j in range(k - 1, -1, -1) if order[j][1] == "ROUTING"), None)
        above = next((order[j][0] for j in range(k + 1, len(order)) if order[j][1] == "ROUTING"), None)
        td.cuts[name].below, td.cuts[name].above = below, above
    # drop the contact layer below the first routing layer (not part of the PDN stack)
    for name in [c.name for c in td.cuts.values() if c.below is None]:
        td.notes.append(f"cut layer {name} below the first routing layer ignored (contact)")
        del td.cuts[name]
    if not td.routing:
        raise TechnologyError(f"no ROUTING layers found in {p}")
    return td


def parse_setrc(path: str | Path, base: TechData, liberty_resistance_unit_ohm: float = 1e3) -> TechData:
    """Build a TechData whose resistances come from ORFS ``set_layer_rc``.

    ``set_layer_rc -layer L -resistance r``: r is resistance per micron in the
    liberty resistance unit (kOhm for the ORFS platforms used here), i.e. for
    a wire of the layer's default width.  Converted to an *equivalent* sheet
    resistance r * W_default so that R = Rs * L / W reproduces OpenROAD's own
    computation (psm ir_solver getResistance).  ``-via V -resistance r`` is per
    cut in the liberty unit.  Geometry/limits are taken from ``base``.
    """
    p = Path(path)
    if not p.is_file():
        raise TechnologyError(f"setRC file not found: {p}")
    td = TechData(source="orfs_setrc", files=base.files + [str(p)], sha256={**base.sha256, str(p): _sha(p)})
    td.routing = {k: RoutingLayer(**{**v.__dict__}) for k, v in base.routing.items()}
    td.cuts = {k: CutLayer(**{**v.__dict__}) for k, v in base.cuts.items()}
    for l in td.routing.values():
        l.rpersq_ohm = None
    for c in td.cuts.values():
        c.resistance_per_cut_ohm = None
    for ln in p.read_text().splitlines():
        ln = ln.split("#", 1)[0]
        m = re.search(rf"set_layer_rc\s+-layer\s+(\S+).*-resistance\s+{_NUM}", ln)
        if m and m.group(1) in td.routing:
            lyr = td.routing[m.group(1)]
            r_per_um = float(m.group(2)) * liberty_resistance_unit_ohm
            if lyr.width_um:
                lyr.rpersq_ohm = r_per_um * lyr.width_um
        m = re.search(rf"set_layer_rc\s+-via\s+(\S+).*-resistance\s+{_NUM}", ln)
        if m and m.group(1) in td.cuts:
            td.cuts[m.group(1)].resistance_per_cut_ohm = float(m.group(2)) * liberty_resistance_unit_ohm
    td.notes.append("resistances from ORFS setRC.tcl (correlation data for signal parasitics, not PDK data)")
    return td


def tech_from_db_dump(path: str | Path, base: TechData) -> TechData:
    """Resistances as stored in an OpenDB technology (tcl pg_dump_tech output).

    OpenDB keeps routing-layer resistance in ohm/sq and cut-layer resistance in
    ohm per cut (PDNSim reads exactly these when no set_layer_rc is active).
    """
    p = Path(path)
    if not p.is_file():
        raise TechnologyError(f"OpenDB tech dump not found: {p}")
    td = TechData(source="odb_tech", files=base.files + [str(p)], sha256={**base.sha256, str(p): _sha(p)})
    td.routing = {k: RoutingLayer(**{**v.__dict__}) for k, v in base.routing.items()}
    td.cuts = {k: CutLayer(**{**v.__dict__}) for k, v in base.cuts.items()}
    import csv as _csv
    with open(p) as fh:
        for row in _csv.DictReader(fh):
            r = float(row["resistance"])
            if row["layer"] in td.routing:
                td.routing[row["layer"]].rpersq_ohm = r if r > 0 else None
            elif row["layer"] in td.cuts:
                td.cuts[row["layer"]].resistance_per_cut_ohm = r if r > 0 else None
    changed = [n for n in td.routing if td.routing[n].rpersq_ohm != base.routing[n].rpersq_ohm] + \
              [n for n in td.cuts if td.cuts[n].resistance_per_cut_ohm != base.cuts[n].resistance_per_cut_ohm]
    td.notes.append("resistances read from the OpenDB technology of the analysed database"
                    + (f"; DIFFERENT from the tech LEF on {changed}" if changed else "; identical to the tech LEF"))
    return td


def write_resistance_override(td: TechData, path: str | Path) -> None:
    """CSV 'layer,ohm' for tcl PG_RES_OVERRIDE (routing: ohm/sq, cut: ohm per cut)."""
    with open(path, "w") as fh:
        fh.write("layer,resistance\n")
        for l in sorted(td.routing.values(), key=lambda l: l.index):
            if l.rpersq_ohm:
                fh.write(f"{l.name},{l.rpersq_ohm!r}\n")
        for c in sorted(td.cuts.values(), key=lambda c: c.index):
            if c.resistance_per_cut_ohm:
                fh.write(f"{c.name},{c.resistance_per_cut_ohm!r}\n")


# ----------------------------------------------------------------------------- profiles
@dataclass
class TechnologyProfile:
    name: str
    status: str                       # enabled | blocked | template
    description: str
    tech_lef: Optional[str]
    setrc: Optional[str]
    supply_nets: dict[str, Any]
    nominal_supply_v: Optional[float]
    nominal_supply_source: Optional[str]
    liberty_resistance_unit_ohm: float
    blocked_reason: Optional[str]
    raw: dict[str, Any]

    def require_vdd(self) -> float:
        if self.nominal_supply_v is None:
            raise TechnologyError(f"profile {self.name}: nominal supply unavailable ({self.nominal_supply_source})")
        return self.nominal_supply_v

    def tech(self, source: str = "tech_lef") -> TechData:
        if self.status != "enabled":
            raise TechnologyError(f"technology profile {self.name} is {self.status}: {self.blocked_reason}")
        if not self.tech_lef:
            raise TechnologyError(f"profile {self.name}: no tech LEF configured")
        base = parse_lef(_expand(self.tech_lef))
        if source == "tech_lef":
            return base
        if source == "orfs_setrc":
            if not self.setrc:
                raise TechnologyError(f"profile {self.name}: no setRC file configured")
            return parse_setrc(_expand(self.setrc), base, self.liberty_resistance_unit_ohm)
        raise TechnologyError(f"unknown resistance source {source!r}")


def _expand(path: str) -> str:
    import os
    env = dict(os.environ)
    env.setdefault("ORFS_FLOW", "/opt/eda/orfs/flow")
    env.setdefault("IHP_SRAM", "/opt/eda/collateral/ihp-sg13g2-sram-d0e5b3c")
    return re.sub(r"\$\{(\w+)\}", lambda m: env.get(m.group(1), m.group(0)), path)


def liberty_nominal_voltage(path: str | Path) -> float:
    """Read ``nom_voltage`` from a Liberty file (plain or .gz)."""
    import gzip
    p = Path(path)
    if not p.is_file():
        raise TechnologyError(f"liberty file not found: {p}")
    opener = gzip.open if p.suffix == ".gz" else open
    with opener(p, "rt", errors="replace") as fh:  # type: ignore[operator]
        for k, line in enumerate(fh):
            m = re.search(rf"nom_voltage\s*:\s*{_NUM}", line)
            if m:
                return float(m.group(1))
            if k > 2000:
                break
    raise TechnologyError(f"no nom_voltage in {p}")


def load_profile(path: str | Path) -> TechnologyProfile:
    d = yaml.safe_load(Path(path).read_text())
    from .units import parse_quantity
    vnom: Optional[float] = None
    vsrc: Optional[str] = None
    ns = d.get("nominal_supply") or {}
    if d.get("status") == "enabled" and ns.get("liberty"):
        lib = _expand(ns["liberty"])
        try:
            vnom = liberty_nominal_voltage(lib)
            vsrc = f"liberty nom_voltage of {lib}"
        except TechnologyError as exc:
            vsrc = f"UNAVAILABLE: {exc}"
    return TechnologyProfile(
        name=d["name"],
        status=d.get("status", "blocked"),
        description=d.get("description", ""),
        tech_lef=d.get("tech_lef"),
        setrc=d.get("setrc"),
        supply_nets=d.get("supply_nets", {}),
        nominal_supply_v=vnom,
        nominal_supply_source=vsrc,
        liberty_resistance_unit_ohm=parse_quantity(d.get("liberty_resistance_unit", "1 kohm"), "resistance"),
        blocked_reason=d.get("blocked_reason"),
        raw=d,
    )
