"""Branch currents, current density and preliminary electromigration screening.

For every resistive branch  I = (V_a - V_b) / R  (from the solver).

Metal:  linear density  J_w = |I| / W   (A/m; foundry DC rules are usually
        stated per width, e.g. LEF DCCURRENTDENSITY AVERAGE in mA/um) and, when
        the thickness is known, volumetric J = |I| / (W * t)  (A/m^2).
Via:    current per cut |I| / n_cuts for a lumped array.  The lumped array
        assumes equal sharing; :func:`resolve_via_array` quantifies the real,
        unequal distribution (current crowding) for a given geometry.

EM screening statuses
---------------------
PASS          |I| <= limit, limit taken from technology data
FAIL          |I| >  limit
UNKNOWN       no applicable limit available -> never reported as safe
NOT ANALYSED  segment excluded (zero-resistance join, floating, no current)

The LEF limit is a single DC average number with no temperature, lifetime,
duty-cycle, direction or Blech-length qualification; a PASS here is a
screening result, not electromigration signoff.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np

from .graph import Load, Network, NetType, SegmentKind, VoltageSource
from .provenance import CheckStatus
from .solver import DCSolution, solve

__all__ = ["segment_table", "em_screen", "layer_summary", "resolve_via_array", "black_mttf_ratio"]


def segment_table(sol: DCSolution) -> dict[str, np.ndarray]:
    net = sol.network
    arr = net.arrays()
    I = sol.segment_current
    absI = np.abs(I)
    width = arr["width"]
    thick = arr["thickness"]
    cuts = arr["cuts"].astype(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        j_lin = np.where(np.isfinite(width), absI / width, np.nan)
        j_vol = np.where(np.isfinite(width) & np.isfinite(thick), absI / (width * thick), np.nan)
        per_cut = np.where(cuts > 0, absI / cuts, np.nan)
    p = I ** 2 * arr["r"]
    return {"current_a": I, "abs_current_a": absI, "j_linear_a_per_m": j_lin, "j_volumetric_a_per_m2": j_vol,
            "current_per_cut_a": per_cut, "power_w": p, "limit_a": arr["ilimit"]}


def em_screen(sol: DCSolution, margin: float = 1.0) -> dict[str, Any]:
    """Compare branch currents with technology limits (LEF DC average limits).

    ``margin`` < 1 applies a derating (e.g. 0.8); the result records it.
    """
    t = segment_table(sol)
    net = sol.network
    kinds = np.array([k.value for k in net.seg_kind])
    limit = t["limit_a"] * margin
    absI = t["abs_current_a"]
    status = np.full(net.n_segments, CheckStatus.UNKNOWN.value, dtype=object)
    excluded = (np.asarray(net.seg_r) == 0.0) | ~np.isfinite(absI)
    has = np.isfinite(limit) & (limit > 0)
    status[has & (absI <= limit)] = CheckStatus.PASS.value
    status[has & (absI > limit)] = CheckStatus.FAIL.value
    status[excluded] = CheckStatus.NOT_ANALYSED.value
    with np.errstate(invalid="ignore", divide="ignore"):
        util = np.where(has, absI / limit, np.nan)
    counts = {s.value: int(np.sum(status == s.value)) for s in
              (CheckStatus.PASS, CheckStatus.FAIL, CheckStatus.UNKNOWN, CheckStatus.NOT_ANALYSED)}
    worst = int(np.nanargmax(util)) if np.any(np.isfinite(util)) else None
    overall = (CheckStatus.FAIL if counts["FAIL"] else
               CheckStatus.UNKNOWN if counts["UNKNOWN"] else
               CheckStatus.PASS if counts["PASS"] else CheckStatus.NOT_ANALYSED)
    return {
        "status_per_segment": status,
        "utilisation": util,
        "counts": counts,
        "overall": overall.value,
        "margin": margin,
        "worst_segment": None if worst is None else {
            "index": worst, "layer": net.seg_layer[worst], "kind": kinds[worst],
            "abs_current_a": float(absI[worst]), "limit_a": float(limit[worst]), "utilisation": float(util[worst]),
            "a": net.node_ids[net.seg_a[worst]], "b": net.node_ids[net.seg_b[worst]]},
        "basis": "LEF DCCURRENTDENSITY AVERAGE (mA/um for metal, mA/cut for vias); no temperature / lifetime / "
                 "duty-cycle qualification -> screening only, not EM signoff",
    }


def layer_summary(sol: DCSolution) -> list[dict[str, Any]]:
    t = segment_table(sol)
    net = sol.network
    layers = np.array([l or "" for l in net.seg_layer], dtype=object)
    out = []
    for lyr in sorted(set(layers.tolist())):
        m = layers == lyr
        absI = t["abs_current_a"][m]
        if absI.size == 0:
            continue
        k = int(np.nanargmax(absI)) if np.any(np.isfinite(absI)) else 0
        out.append({
            "layer": lyr, "segments": int(m.sum()),
            "max_current_a": float(np.nanmax(absI)) if absI.size else 0.0,
            "mean_current_a": float(np.nanmean(absI)) if absI.size else 0.0,
            "max_j_linear_a_per_m": float(np.nanmax(t["j_linear_a_per_m"][m])) if np.any(np.isfinite(t["j_linear_a_per_m"][m])) else None,
            "max_j_vol_a_per_m2": float(np.nanmax(t["j_volumetric_a_per_m2"][m])) if np.any(np.isfinite(t["j_volumetric_a_per_m2"][m])) else None,
            "max_current_per_cut_a": float(np.nanmax(t["current_per_cut_a"][m])) if np.any(np.isfinite(t["current_per_cut_a"][m])) else None,
            "power_w": float(np.nansum(t["power_w"][m])),
            "worst_index": int(np.nonzero(m)[0][k]),
        })
    return out


def resolve_via_array(
    n_rows: int,
    n_cols: int,
    pitch_m: float,
    r_cut_ohm: float,
    rs_lower_ohm_sq: float,
    rs_upper_ohm_sq: float,
    width_lower_m: float,
    width_upper_m: float,
    feed: str = "opposite",
    total_current_a: float = 1.0,
    v: float = 1.0,
) -> dict[str, Any]:
    """Resolve current sharing in an n_rows x n_cols via array between two wires.

    The lower wire runs along x (current enters from its left end), the upper
    wire along x as well; ``feed='opposite'`` takes current out at the right
    end of the upper wire, ``'same'`` at its left end.  Each wire is a 2-D
    resistive sheet discretised at the cut pitch (row conductance across the
    wire width included); each cut is R_cut.  Solved with the PowerGrid DC
    solver.  Returns the per-cut currents, max/mean ratio (crowding factor)
    and the lumped equivalent resistance.
    """
    net = Network("via_array")
    net.add_net("N", NetType.POWER, v)
    nx, ny = n_cols, n_rows
    dy_l = width_lower_m / ny
    dy_u = width_upper_m / ny
    for lvl, rs, dy in (("lo", rs_lower_ohm_sq, dy_l), ("up", rs_upper_ohm_sq, dy_u)):
        for i in range(-1, nx + 1):
            for j in range(ny):
                net.add_node(f"{lvl}{i},{j}", "N", lvl, i * pitch_m, j * dy)
        for i in range(-1, nx + 1):
            for j in range(ny):
                if i + 1 <= nx:
                    net.add_segment(f"{lvl}{i},{j}", f"{lvl}{i+1},{j}", rs * pitch_m / dy, kind=SegmentKind.METAL, layer=lvl)
                if j + 1 < ny:
                    net.add_segment(f"{lvl}{i},{j}", f"{lvl}{i},{j+1}", rs * dy / pitch_m, kind=SegmentKind.METAL, layer=lvl)
    cut_idx = []
    for i in range(nx):
        for j in range(ny):
            cut_idx.append(net.add_segment(f"lo{i},{j}", f"up{i},{j}", r_cut_ohm, kind=SegmentKind.VIA, layer="cut", via_cuts=1))
    # feed: ideal source on the lower wire's left edge (all rows tied by a short)
    net.add_node("src", "N")
    for j in range(ny):
        net.add_segment("src", f"lo-1,{j}", 0.0)
    net.add_source(VoltageSource("V", "src", v))
    net.add_node("sink", "N")
    col = nx if feed == "opposite" else -1
    for j in range(ny):
        net.add_segment(f"up{col},{j}", "sink", 0.0)
    net.add_load(Load("L", "sink", None, current_a=total_current_a))
    sol = solve(net)
    I = np.abs(sol.segment_current[cut_idx]).reshape(nx, ny)
    mean = float(I.mean())
    return {
        "per_cut_current_a": I.tolist(),
        "max_over_mean": float(I.max() / mean) if mean > 0 else math.nan,
        "min_over_mean": float(I.min() / mean) if mean > 0 else math.nan,
        "lumped_equal_share_a": total_current_a / (nx * ny),
        "max_cut_current_a": float(I.max()),
        "drop_v": float(v - sol.voltage("sink")),
        "kcl_ok": bool(sol.metrics["kcl_ok"]),
    }


def black_mttf_ratio(j_a_per_m2: float, j_ref_a_per_m2: float, t_k: float, t_ref_k: float,
                     n: float, ea_ev: float) -> float:
    """Black's-equation MTTF ratio MTTF(J,T)/MTTF(Jref,Tref) -- RESEARCH ONLY.

    Requires process-qualified n and Ea; with generic textbook values this is
    a qualitative sensitivity indicator, never a lifetime prediction.
    """
    k = 8.617333262e-5
    if j_a_per_m2 <= 0 or j_ref_a_per_m2 <= 0:
        raise ValueError("current densities must be > 0")
    return (j_ref_a_per_m2 / j_a_per_m2) ** n * math.exp(ea_ev / k * (1.0 / t_k - 1.0 / t_ref_k))
