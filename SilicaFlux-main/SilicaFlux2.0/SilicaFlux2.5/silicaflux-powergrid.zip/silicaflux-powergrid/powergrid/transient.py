"""Dynamic droop research module (second release, isolated from static IR).

Lumped model (one supply loop, VDD and return lumped together):

    V_reg --R_vrm-- --R_pkg--L_pkg-- node_d --R_die-- node_l
                                        |                 |
                                    C_pkg_decap        C_die (ESR R_c)   i_load(t)

State variables: package inductor current i_L, decap voltages.  Integrated
with the trapezoidal rule (A-stable, second order) on a fixed step; verified
against the closed-form second-order step response (tests) and optionally
against ngspice on the identical netlist (:func:`ngspice_crosscheck`).

Nothing here is a SilicaFlux package model: every R/L/C is an input that
must carry a source.  Without physically credible package parasitics and
regulator behaviour the output is a sensitivity study, not a prediction.
Static PDNSim output is never presented as dynamic droop.
"""
from __future__ import annotations

import math
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

import numpy as np

__all__ = ["RLCParams", "simulate", "step_metrics", "ngspice_crosscheck", "load_step"]


@dataclass
class RLCParams:
    v_reg: float
    r_vrm: float
    r_pkg: float
    l_pkg: float
    c_die: float
    r_c: float          # decap ESR (series with C_die)
    r_die: float        # on-die grid resistance between decap node and load node
    source: str = "ASSUMED"
    notes: list[str] = field(default_factory=list)


def load_step(i0: float, i1: float, t_on: float, t_rise: float) -> Callable[[float], float]:
    def f(t: float) -> float:
        if t <= t_on:
            return i0
        if t >= t_on + t_rise:
            return i1
        return i0 + (i1 - i0) * (t - t_on) / t_rise
    return f


def simulate(p: RLCParams, i_load: Callable[[float], float], t_end: float, dt: float) -> dict[str, np.ndarray]:
    """Trapezoidal integration of the lumped loop.

    Unknown vector x = [i_L, v_C]; node_l voltage from KCL at node_d / node_l:
      node_d: i_L = i_C + i_die ;  i_C = (v_d - v_C)/R_c ;  i_die = i_load (series path)
    so v_d = v_C + R_c (i_L - i_load),  v_l = v_d - R_die * i_load.
      L di_L/dt = V_reg - (R_vrm + R_pkg) i_L - v_d
      C dv_C/dt = i_L - i_load
    """
    n = int(round(t_end / dt)) + 1
    t = np.linspace(0.0, (n - 1) * dt, n)
    R = p.r_vrm + p.r_pkg
    il = np.array([i_load(tt) for tt in t])
    # DC initial condition with the initial load current
    iL = il[0]
    vC = p.v_reg - R * il[0]
    A = np.array([[-(R + p.r_c) / p.l_pkg, -1.0 / p.l_pkg], [1.0 / p.c_die, 0.0]])
    def b(i: float) -> np.ndarray:
        return np.array([(p.v_reg + p.r_c * i) / p.l_pkg, -i / p.c_die])
    I2 = np.eye(2)
    M1 = np.linalg.inv(I2 - 0.5 * dt * A)
    M2 = I2 + 0.5 * dt * A
    xs = np.zeros((n, 2))
    xs[0] = [iL, vC]
    for k in range(1, n):
        xs[k] = M1 @ (M2 @ xs[k - 1] + 0.5 * dt * (b(il[k - 1]) + b(il[k])))
    vd = xs[:, 1] + p.r_c * (xs[:, 0] - il)
    vl = vd - p.r_die * il
    return {"t": t, "i_L": xs[:, 0], "v_c": xs[:, 1], "v_d": vd, "v_load": vl, "i_load": il}


def step_metrics(res: dict[str, np.ndarray], v_nom: float, band: float, t_event: float) -> dict[str, Any]:
    t, v = res["t"], res["v_load"]
    k_min = int(np.argmin(v))
    v_final = float(v[-1])
    after = t >= t_event
    below = after & (v < v_nom - band)
    droop_duration = float(np.sum(below) * (t[1] - t[0])) if np.any(below) else 0.0
    # recovery: last time |v - v_final| > 1% of the excursion
    exc = abs(v_final - float(v[k_min]))
    outside = np.nonzero(after & (np.abs(v - v_final) > 0.01 * exc))[0] if exc > 0 else np.array([], int)
    recovery = float(t[outside[-1]] - t_event) if outside.size else 0.0
    # ringing frequency from zero crossings of (v - v_final) after the minimum
    sig = v[k_min:] - v_final
    zc = np.nonzero(np.diff(np.sign(sig)) != 0)[0]
    f_ring = float(1.0 / (2.0 * np.mean(np.diff(t[k_min:][zc])))) if zc.size > 2 else None
    return {"v_min": float(v[k_min]), "t_min_after_event": float(t[k_min] - t_event), "v_final": v_final,
            "first_droop_v": float(v_nom - v[k_min]), "droop_duration_s": droop_duration,
            "recovery_time_s": recovery, "ringing_hz": f_ring}


def ngspice_crosscheck(p: RLCParams, i0: float, i1: float, t_on: float, t_rise: float, t_end: float,
                       dt: float, workdir: Optional[Path] = None) -> dict[str, Any]:
    """Run the identical circuit in ngspice (if installed) and compare v_load."""
    exe = shutil.which("ngspice")
    if exe is None:
        return {"status": "NOT RUN", "reason": "ngspice not installed"}
    wd = Path(workdir or tempfile.mkdtemp(prefix="pg_ngspice_"))
    wd.mkdir(parents=True, exist_ok=True)
    deck = wd / "rlc.cir"
    out = wd / "rlc.out"
    deck.write_text(f"""* PowerGrid lumped droop cross-check
Vreg n0 0 DC {p.v_reg}
Rvrm n0 n1 {p.r_vrm}
Rpkg n1 n2 {p.r_pkg}
Lpkg n2 nd {p.l_pkg} IC={i0}
Rc nd nc {p.r_c}
Cdie nc 0 {p.c_die} IC={p.v_reg - (p.r_vrm + p.r_pkg) * i0}
Rdie nd nl {p.r_die}
Iload nl 0 PWL(0 {i0} {t_on} {i0} {t_on + t_rise} {i1} {t_end} {i1})
.options method=trap reltol=1e-6 abstol=1e-12 vntol=1e-9
.tran {dt} {t_end} 0 {dt} UIC
.control
run
wrdata {out} v(nl)
quit
.endc
.end
""")
    proc = subprocess.run([exe, "-b", str(deck)], capture_output=True, text=True, timeout=300)
    if proc.returncode != 0 or not out.exists():
        return {"status": "FAILED", "returncode": proc.returncode, "stderr": proc.stderr[-2000:]}
    data = np.loadtxt(out)
    ts, vs = data[:, 0], data[:, 1]
    mine = simulate(p, load_step(i0, i1, t_on, t_rise), t_end, dt)
    v_interp = np.interp(mine["t"], ts, vs)
    err = np.abs(v_interp - mine["v_load"])
    return {"status": "RUN", "deck": str(deck), "points": int(ts.size), "max_abs_diff_v": float(err.max()),
            "v_min_ngspice": float(vs.min()), "v_min_powergrid": float(mine["v_load"].min()),
            "ngspice_version": next((l.strip("* ").strip() for l in subprocess.run([exe, "-v"], capture_output=True, text=True).stdout.splitlines() if "ngspice-" in l), "?")}
