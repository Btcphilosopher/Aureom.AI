"""SilicaFlux PowerGrid command-line interface.

  python -m powergrid solve      --config configs/reference_mesh.yaml
  python -m powergrid check-pdn  --design silicaflux_v
  python -m powergrid pdnsim     --design silicaflux_v
  python -m powergrid analyse    --design silicaflux_v
  python -m powergrid compare    --run-dir reports/silicaflux_v/A_baseline
  python -m powergrid optimise   --config configs/experiments/pdn_sweep.yaml
  python -m powergrid experiments --config configs/experiments/silicaflux_v_demo.yaml
  python -m powergrid transient  --config configs/experiments/droop_study.yaml
  python -m powergrid report     --run-dir reports/run_001
  python -m powergrid dashboard  [--out reports/dashboard.html]
  python -m powergrid audit      [--json]

Exit status: 0 success, 2 blocked (toolchain / PDK / inputs missing), 3 invalid
input or electrically invalid network, 4 tool step failed.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parents[1]


def _design_path(name: str) -> Path:
    p = Path(name)
    if p.suffix in (".yaml", ".yml") and p.exists():
        return p
    q = ROOT / "configs" / "designs" / f"{name}.yaml"
    if not q.exists():
        raise FileNotFoundError(f"design config {name!r} not found ({q})")
    return q


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="powergrid", description="SilicaFlux PowerGrid static IR / PDN analysis")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("solve"); s.add_argument("--config", required=True); s.add_argument("--out")
    for name in ("check-pdn", "pdnsim", "analyse"):
        s = sub.add_parser(name); s.add_argument("--design", required=True); s.add_argument("--out")
        s.add_argument("--models", nargs="*")
    s = sub.add_parser("compare"); s.add_argument("--run-dir", required=True)
    s = sub.add_parser("optimise"); s.add_argument("--config", required=True); s.add_argument("--out")
    s = sub.add_parser("experiments"); s.add_argument("--config", required=True); s.add_argument("--out")
    s = sub.add_parser("transient"); s.add_argument("--config", required=True); s.add_argument("--out")
    s = sub.add_parser("report"); s.add_argument("--run-dir", required=True)
    s = sub.add_parser("dashboard"); s.add_argument("--out", default=str(ROOT / "reports" / "dashboard.html"))
    s.add_argument("--reports", default=str(ROOT / "reports"))
    s = sub.add_parser("audit"); s.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)

    from .graph import NetworkError
    from .openroad_adapter import ToolchainError
    from .solver import SolverError
    from .technology import TechnologyError
    from .units import UnitError
    try:
        if a.cmd == "solve":
            from .reference import solve_reference
            out = Path(a.out or ROOT / "reports" / "reference" / Path(a.config).stem)
            run = solve_reference(Path(a.config), out)
            print(json.dumps({k: run[k] for k in ("status", "summary")}, indent=1, default=str))
        elif a.cmd in ("analyse", "pdnsim"):
            from .flows import analyse_design
            dp = _design_path(a.design)
            out = Path(a.out or ROOT / "reports" / dp.stem / ("pdnsim" if a.cmd == "pdnsim" else "analysis"))
            from .config import DesignConfig
            cfg = DesignConfig.load(dp)
            models = a.models or ([cfg.default_supply_model] if a.cmd == "pdnsim" else None)
            run = analyse_design(dp, out, run_pdnsim=True, models=models)
            print(json.dumps({"status": run["status"], "run_dir": str(out),
                              "supply_models": {k: v["worst_total_loss_mv"] for k, v in run["supply_models"].items()}},
                             indent=1))
        elif a.cmd == "check-pdn":
            from .check import check_pdn
            dp = _design_path(a.design)
            out = Path(a.out or ROOT / "reports" / dp.stem / "check")
            res = check_pdn(dp, out)
            print(json.dumps(res, indent=1, default=str))
            return 0 if res["status"] == "PASS" else 4
        elif a.cmd == "compare":
            from .report import comparison_table
            print(comparison_table(Path(a.run_dir)))
        elif a.cmd == "optimise":
            from .optimise import optimise_from_config
            out = Path(a.out or ROOT / "reports" / "optimisation" / Path(a.config).stem)
            res = optimise_from_config(a.config, out)
            for v in res["variants"]:
                print(f"{v['id']}  {v.get('status'):9s}  {str(v.get('worst_loss_mv'))[:7]:>7s} mV  {v['label']}"
                      + (f"   [{v.get('reason')}]" if v.get("status") != "VALID" else ""))
        elif a.cmd == "experiments":
            from .experiments import run_experiments
            out = Path(a.out or ROOT / "reports" / "experiments" / Path(a.config).stem)
            res = run_experiments(Path(a.config), out)
            print(json.dumps({k: v.get("headline") for k, v in res["experiments"].items()}, indent=1, default=str))
        elif a.cmd == "transient":
            from .experiments import run_transient
            out = Path(a.out or ROOT / "reports" / "transient" / Path(a.config).stem)
            res = run_transient(Path(a.config), out)
            print(json.dumps(res["summary"], indent=1, default=str))
        elif a.cmd == "report":
            from .report import write_report
            print(write_report(Path(a.run_dir)))
        elif a.cmd == "dashboard":
            from .dashboard import build_dashboard
            print(build_dashboard(Path(a.reports), Path(a.out)))
        elif a.cmd == "audit":
            from .audit import toolchain_audit
            res = toolchain_audit()
            print(json.dumps(res, indent=1) if a.json else "\n".join(f"{k}: {v}" for k, v in res.items()))
    except (ToolchainError, FileNotFoundError, TechnologyError) as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2
    except (UnitError, NetworkError, SolverError, ValueError) as exc:
        print(f"INVALID: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 3
    except RuntimeError as exc:
        print(f"FAILED: {exc}", file=sys.stderr)
        return 4
    return 0


if __name__ == "__main__":
    sys.exit(main())
