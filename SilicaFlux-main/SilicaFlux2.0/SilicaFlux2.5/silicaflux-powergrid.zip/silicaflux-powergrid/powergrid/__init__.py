"""SilicaFlux PowerGrid -- static IR-drop analysis for the SilicaFlux family."""
__version__ = "1.0.0"
