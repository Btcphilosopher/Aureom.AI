"""Constrained PDN optimisation with physical re-verification.

Physical loop (per candidate, deterministic experiment ID = hash of parameters):
  1. rule pre-check against the technology (LEF min/max width, spacing, the
     FloorplanLab macro-PG coverage bound for the TopMetal1 strap)
  2. regenerate the PDN on the placed OpenDB (tcl/regen_pdn.tcl: pdngen -ripup,
     re-run the design PDN script with overrides, pdngen)
  3. check_power_grid on VDD and VSS, check_placement
  4. export the new PDN, re-extract, re-solve (PowerGrid) -> IR, losses, currents
  5. optional: PDNSim on the regenerated database, optional global route (congestion)
  6. reject invalid designs (any failed step), compare with the baseline
Nothing is accepted on the basis of the solver alone: a candidate must pass
the OpenROAD steps.

Resource metrics: PDN conductor area per layer, via cuts per level, and the
fraction of *signal routing* layer area blocked by PDN straps (+ spacing) on
layers at or below the design's max routing layer.  Measured congestion
(global-route overflow) is recorded only when a global route was run.
"""
from __future__ import annotations

import hashlib
import json
import math
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np

from .config import DesignConfig
from .current_density import em_screen
from .mesh import BlockLoad, GridSpec, LayerDef, PadDef, ViaDef, build_strap_grid
from .openroad_adapter import DesignInputs, OpenROAD
from .pdn_import import ImportOptions, read_export
from .solver import solve
from .technology import TechData, load_profile

__all__ = ["experiment_id", "rule_check", "resource_metrics", "pareto_front", "marginal_gains",
           "run_physical_variants", "synthetic_sweep"]


def experiment_id(params: dict[str, Any]) -> str:
    blob = json.dumps({k: str(v) for k, v in sorted(params.items())}, sort_keys=True)
    return "X" + hashlib.sha1(blob.encode()).hexdigest()[:10]


def rule_check(params: dict[str, str], tech: TechData, macro_bound_um: Optional[float] = None,
               max_routing_layer: str = "Metal5") -> list[str]:
    """Pre-check strap parameters against technology rules (tool checks follow)."""
    errs = []
    for key in ("STRAP1", "STRAP2", "RAIL"):
        lyr = params.get(f"FLP_PDN_{key}_LAYER")
        if not lyr:
            continue
        L = tech.routing.get(lyr)
        if L is None:
            errs.append(f"{key}: layer {lyr} does not exist in this technology"); continue
        w = float(params[f"FLP_PDN_{key}_WIDTH"]); p = float(params[f"FLP_PDN_{key}_PITCH"])
        if L.width_um and w < L.width_um - 1e-9:
            errs.append(f"{key}: width {w} um < {lyr} minimum width {L.width_um} um")
        if L.max_width_um and w > L.max_width_um + 1e-9:
            errs.append(f"{key}: width {w} um > {lyr} MAXWIDTH {L.max_width_um} um")
        sp = L.min_spacing_um or 0.0
        if key != "RAIL" and p / 2.0 < w + sp:
            errs.append(f"{key}: pitch {p} um cannot hold interleaved VDD/VSS straps of width {w} um "
                        f"with spacing {sp} um (need pitch >= {2 * (w + sp):.3f})")
        if L.pitch_um and key != "RAIL":
            # strap pitch/width on the manufacturing grid
            if abs(round(w * 1000) - w * 1000) > 1e-6 or abs(round(p * 1000) - p * 1000) > 1e-6:
                errs.append(f"{key}: width/pitch not on the 1 nm grid")
    if macro_bound_um is not None and params.get("FLP_PDN_STRAP2_LAYER") == "TopMetal1":
        w = float(params["FLP_PDN_STRAP2_WIDTH"]); p = float(params["FLP_PDN_STRAP2_PITCH"])
        if p + w > macro_bound_um + 1e-9:
            errs.append(f"STRAP2: pitch+width {p + w:.2f} um > {macro_bound_um} um: a VDD strap would miss some of "
                        "the 38.83 um SRAM VDD! periphery stripes (FloorplanLab PDN_MACRO_PIN_COVERAGE rule)")
    return errs


def resource_metrics(exp: Any, tech: TechData, max_routing_layer: str = "Metal5") -> dict[str, Any]:
    dbu = exp.dbu
    core = [c / dbu for c in exp.meta["core"]]
    core_area = (core[2] - core[0]) * (core[3] - core[1])
    order = tech.layer_order()
    max_idx = order.index(max_routing_layer) if max_routing_layer in order else len(order) - 1
    area: dict[str, float] = defaultdict(float); blocked: dict[str, float] = defaultdict(float)
    for w in exp.wires:
        a = (w.x1 - w.x0) * (w.y1 - w.y0) / dbu / dbu
        area[w.layer] += a
        L = tech.routing.get(w.layer)
        if L is not None and order.index(w.layer) <= max_idx and order.index(w.layer) > 0:
            sp = L.min_spacing_um or 0.0
            length = max(w.x1 - w.x0, w.y1 - w.y0) / dbu
            width = min(w.x1 - w.x0, w.y1 - w.y0) / dbu
            blocked[w.layer] += (width + 2 * sp) * length
    cuts: dict[str, int] = defaultdict(int)
    for _, _, _, vname in exp.vias:
        vd = exp.via_defs[vname]
        cuts[vd.cut] += vd.cuts
    return {"conductor_area_um2": dict(area), "signal_layer_blockage_fraction": {k: v / core_area for k, v in blocked.items()},
            "via_cuts": dict(cuts), "via_instances": len(exp.vias), "total_pdn_metal_area_um2": sum(area.values()),
            "core_area_um2": core_area}


def pareto_front(points: list[dict[str, Any]], keys: tuple[str, str]) -> list[str]:
    """Non-dominated set (minimise both keys)."""
    ids = []
    for p in points:
        if p.get("status") != "VALID":
            continue
        dominated = False
        for q in points:
            if q is p or q.get("status") != "VALID":
                continue
            if all(q[k] <= p[k] for k in keys) and any(q[k] < p[k] for k in keys):
                dominated = True
                break
        if not dominated:
            ids.append(p["id"])
    return ids


def marginal_gains(base: dict[str, Any], others: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for o in others:
        if o.get("status") != "VALID" or o["id"] == base["id"]:
            continue
        d_loss = o["worst_loss_mv"] - base["worst_loss_mv"]
        d_mean = o["mean_loss_mv"] - base["mean_loss_mv"]
        d_area = o["pdn_metal_area_um2"] - base["pdn_metal_area_um2"]
        d_block = o["metal5_blockage"] - base["metal5_blockage"]
        rows.append({"id": o["id"], "label": o["label"],
                     "d_worst_loss_mv": d_loss, "d_mean_loss_mv": d_mean,
                     "d_resistive_loss_uw": o["resistive_loss_uw"] - base["resistive_loss_uw"],
                     "d_pdn_metal_area_um2": d_area, "d_via_cuts": o["via_cuts_total"] - base["via_cuts_total"],
                     "d_metal5_signal_blockage_pct": d_block * 100,
                     "mv_saved_per_mm2_metal": (-d_loss / (d_area * 1e-6)) if d_area > 0 else None,
                     "mv_saved_per_pct_metal5": (-d_loss / (d_block * 100)) if d_block > 1e-9 else None,
                     "d_global_route_overflow": (o["grt_overflow"] - base["grt_overflow"])
                     if o.get("grt_overflow") is not None and base.get("grt_overflow") is not None else None})
    return rows


def run_physical_variants(cfg_path: str | Path, variants: list[dict[str, Any]], out: Path, supply_models: list[str],
                          resistance_source: str = "tech_lef", loads_power: Optional[dict[str, float]] = None) -> list[dict[str, Any]]:
    from .flows import _summary, tap_specs  # local import to avoid a cycle
    from .pdn_import import build_network
    from .technology import tech_from_db_dump
    cfg = DesignConfig.load(cfg_path)
    prof = load_profile(cfg.technology)
    vdd = prof.require_vdd()
    lef = prof.tech("tech_lef")
    di = DesignInputs(cfg.name, cfg.odb, cfg.tech_lef, cfg.lefs, cfg.libs, cfg.sdc, None, cfg.pdn_tcl)
    ora = OpenROAD()
    rows = []
    for v in variants:
        params = {**cfg.pdn_params, **{k: str(x) for k, x in v.get("params", {}).items()}}
        vid = experiment_id(params)
        d = out / vid
        d.mkdir(parents=True, exist_ok=True)
        row: dict[str, Any] = {"id": vid, "label": v["label"], "params": {k: params[k] for k in sorted(params)},
                               "changed": v.get("params", {}), "steps": {}}
        errs = rule_check(params, lef, macro_bound_um=v.get("macro_bound_um", 38.83))
        if errs:
            row.update(status="REJECTED", reason="rule pre-check: " + "; ".join(errs))
            rows.append(row); (d / "result.json").write_text(json.dumps(row, indent=1)); continue
        env = {**di.env(), **params, "PG_PDN_TCL": cfg.pdn_tcl, "PG_OUT": str(d / "regen"), "PG_ODB_OUT": str(d / "pdn.odb")}
        r = ora.run("regen_pdn.tcl", env, d / "regen.log", "regen_pdn")
        row["steps"]["regen"] = {"ok": r.ok, "records": r.records, "errors": r.errors[:10], "seconds": r.seconds}
        checks = [x for x in r.records if x["_tag"] == "PG-CHECK"]
        place = [x for x in r.records if x["_tag"] == "PG-PLACEMENT"]
        conn = len(checks) == 2 and all(c["result"] == "true" and c["tcl_rc"] == 0 for c in checks)
        if not r.ok or not conn or not place or place[0]["tcl_rc"] != 0:
            row.update(status="REJECTED", reason=f"OpenROAD: regen ok={r.ok}, connectivity={conn}, placement={place}")
            rows.append(row); (d / "result.json").write_text(json.dumps(row, indent=1, default=str)); continue
        e2 = {**di.env(), "PG_ODB": str(d / "pdn.odb"), "PG_OUT": str(d / "export"), "PG_POWER": "1",
              "PG_ACTIVITY": str(cfg.activity.get("input_activity", 0.1))}
        r2 = ora.run("export_pdn.tcl", e2, d / "export.log", "export")
        if not r2.ok:
            row.update(status="REJECTED", reason="export failed"); rows.append(row); continue
        exp = read_export(d / "export")
        if loads_power is not None:
            exp.power_w = dict(loads_power)
        tech = lef if resistance_source == "tech_lef" else tech_from_db_dump(d / "export" / "tech_layers.csv", lef)
        # macro PG coverage after regeneration: every macro must keep VDD and VSS landings
        res = resource_metrics(exp, lef)
        row.update(resources=res, pdn_metal_area_um2=res["total_pdn_metal_area_um2"],
                   metal5_blockage=res["signal_layer_blockage_fraction"].get("Metal5", 0.0),
                   via_cuts_total=sum(res["via_cuts"].values()))
        per_model = {}
        for m in supply_models:
            srcs = tap_specs(cfg, m, exp, vdd)
            net, rep = build_network(exp, tech, srcs, ImportOptions(vdd_v=vdd))
            if rep.macros_without_landing:
                row.update(status="REJECTED", reason=f"macros without PDN landing: {rep.macros_without_landing}")
                break
            sol = solve(net)
            s = _summary(sol, vdd)
            em = em_screen(sol)
            s["em_overall"] = em["overall"]; s["em_worst_utilisation"] = em["worst_segment"]["utilisation"] if em["worst_segment"] else None
            per_model[m] = {k: s[k] for k in ("worst_total_loss_mv", "mean_total_loss_mv", "worst_vdd_droop_mv",
                                              "worst_vss_bounce_mv", "resistive_loss_uw", "kcl_ok", "power_ok",
                                              "em_overall", "em_worst_utilisation", "total_load_current_ma")}
        else:
            row["status"] = "VALID"
        row["models"] = per_model
        if row["status"] == "VALID":
            m0 = per_model[supply_models[0]]
            row.update(worst_loss_mv=m0["worst_total_loss_mv"], mean_loss_mv=m0["mean_total_loss_mv"],
                       resistive_loss_uw=m0["resistive_loss_uw"])
        (d / "result.json").write_text(json.dumps(row, indent=1, default=str))
        rows.append(row)
    return rows


# ----------------------------------------------------------------------------- synthetic sweeps
def synthetic_sweep(tech: TechData, width_um: float, height_um: float, base: dict[str, Any], sweeps: dict[str, list[Any]],
                    total_current_a: float, vdd: float, pads_per_side: int = 1) -> list[dict[str, Any]]:
    """Fast trend study on a generated two-net strap grid built from technology data.

    base: {m5_width, m5_pitch, tm1_width, tm1_pitch, rail_pitch, stack_cuts, tm_cuts}
    """
    rows = []
    keys = list(sweeps)
    for k in keys:
        for val in sweeps[k]:
            p = {**base, k: val}
            W, H = width_um * 1e-6, height_um * 1e-6
            r_stack = sum(tech.via_resistance_per_cut(c) for c in ("Via1", "Via2", "Via3", "Via4"))
            layers = [
                LayerDef("Metal1", "H", 0.44e-6, p["rail_pitch"] * 1e-6, 0.0, tech.sheet_resistance("Metal1"),
                         provenance="PDK(LEF)"),
                LayerDef("Metal5", "V", p["m5_width"] * 1e-6, p["m5_pitch"] * 1e-6, p["m5_pitch"] * 0.18e-6,
                         tech.sheet_resistance("Metal5"), provenance="PDK(LEF)"),
                LayerDef("TopMetal1", "H", p["tm1_width"] * 1e-6, p["tm1_pitch"] * 1e-6, p["tm1_pitch"] * 0.45e-6,
                         tech.sheet_resistance("TopMetal1"), provenance="PDK(LEF)"),
            ]
            vias = [ViaDef("Metal1", "Metal5", r_stack, p["stack_cuts"], provenance="PDK(LEF) stack Via1-4"),
                    ViaDef("Metal5", "TopMetal1", tech.via_resistance_per_cut("TopVia1"), p["tm_cuts"],
                           provenance="PDK(LEF) TopVia1")]
            pads = []
            n = p.get("pads_per_side", pads_per_side)
            for pnet in ("VDD", "VSS"):
                for i in range(n):
                    f = (i + 0.5) / n
                    for side, (x, y) in {"b": (f * W, 0.0), "t": (f * W, H)}.items():
                        pads.append(PadDef(f"{pnet}_{side}{i}", pnet, x, y, "TopMetal1", vdd if pnet == "VDD" else 0.0,
                                           p.get("pad_r", 0.0)))
            spec = GridSpec(W, H, layers, vias, pads,
                            [BlockLoad("core", 0.0, 0.0, W, H, current_a=total_current_a)], vdd_v=vdd)
            net = build_strap_grid(spec)
            sol = solve(net)
            veff = sol.load_v_eff
            m5_area = (p["m5_width"]) * 2 * (width_um / p["m5_pitch"]) * height_um
            tm1_area = (p["tm1_width"]) * 2 * (height_um / p["tm1_pitch"]) * width_um
            rows.append({"sweep": k, "value": val, "worst_loss_mv": float((vdd - veff.min()) * 1e3),
                         "mean_loss_mv": float((vdd - veff.mean()) * 1e3),
                         "resistive_loss_uw": sol.metrics["power_dissipated_W"] * 1e6,
                         "metal5_area_fraction": m5_area / (width_um * height_um),
                         "tm1_area_fraction": tm1_area / (width_um * height_um),
                         "nodes": net.n_nodes, "kcl_ok": bool(sol.metrics["kcl_ok"])})
    return rows


def optimise_from_config(path: str | Path, out: Path) -> dict[str, Any]:
    from .config import load_yaml, resolve_path
    from .flows import _jsonable, provenance_header, write_csv
    p = Path(path).resolve()
    d = load_yaml(p)
    design = resolve_path(d["design"], p.parent)
    out.mkdir(parents=True, exist_ok=True)
    rows = run_physical_variants(design, d["variants"], out / "variants", d.get("supply_models", ["WB4"]),
                                 d.get("resistance_source", "tech_lef"))
    valid = [r for r in rows if r.get("status") == "VALID"]
    base = next((r for r in valid if not r["changed"]), None)
    front = pareto_front(valid, ("worst_loss_mv", "metal5_blockage")) if valid else []
    front_area = pareto_front(valid, ("worst_loss_mv", "pdn_metal_area_um2")) if valid else []
    gains = marginal_gains(base, valid) if base else []
    for r in rows:
        r["pareto_loss_vs_metal5"] = r["id"] in front
        r["pareto_loss_vs_area"] = r["id"] in front_area
    summary = {"run_type": "pdn_optimisation", "header": provenance_header(), "config": str(p), "design": design,
               "fidelity": "ACTUAL EDA RESULT (regenerated PDN, OpenROAD checks) + NUMERICAL MODEL (IR); loads MODELLED (vectorless)",
               "variants": rows, "baseline_id": base["id"] if base else None, "pareto_loss_vs_metal5": front,
               "pareto_loss_vs_area": front_area, "marginal_gains": gains}
    flat = [{"id": r["id"], "label": r["label"], "status": r.get("status"), "reason": r.get("reason"),
             "worst_loss_mv": r.get("worst_loss_mv"), "mean_loss_mv": r.get("mean_loss_mv"),
             "resistive_loss_uw": r.get("resistive_loss_uw"), "pdn_metal_area_um2": r.get("pdn_metal_area_um2"),
             "metal5_signal_blockage_pct": (r["metal5_blockage"] * 100) if r.get("metal5_blockage") is not None else None,
             "via_cuts_total": r.get("via_cuts_total"),
             **{f"{m}_worst_loss_mv": v["worst_total_loss_mv"] for m, v in (r.get("models") or {}).items()},
             "pareto_loss_vs_metal5": r["pareto_loss_vs_metal5"]} for r in rows]
    write_csv(out / "variants.csv", flat)
    write_csv(out / "marginal_gains.csv", gains)
    _plot_pareto(valid, front, out / "pareto.png")
    (out / "summary.json").write_text(json.dumps(_jsonable(summary), indent=1, default=str))
    return summary


def _plot_pareto(valid: list[dict[str, Any]], front: list[str], path: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from .visualise import PALETTE
    if not valid:
        return
    fig, ax = plt.subplots(figsize=(7.2, 5), dpi=110)
    fig.patch.set_facecolor(PALETTE["navy"]); ax.set_facecolor("#101d3d")
    for r in valid:
        on = r["id"] in front
        ax.plot(r["metal5_blockage"] * 100, r["worst_loss_mv"], "o", color=PALETTE["gold"] if on else PALETTE["cyan"],
                ms=8 if on else 6, mec="k")
        ax.annotate(r["label"].split(" [")[0][:28], (r["metal5_blockage"] * 100, r["worst_loss_mv"]), fontsize=6,
                    color=PALETTE["ink"], xytext=(4, 3), textcoords="offset points")
    ax.set_xlabel("Metal5 signal-routing area blocked by PDN straps (+spacing) [%]", color=PALETTE["ink"])
    ax.set_ylabel("worst total supply loss, WB4 taps [mV]", color=PALETTE["ink"])
    ax.set_title("PDN variants (regenerated + checked in OpenROAD); gold = Pareto front", color=PALETTE["ink"], fontsize=9)
    ax.tick_params(colors=PALETTE["ink"]); ax.grid(alpha=0.2)
    fig.text(0.01, 0.01, "ACTUAL EDA geometry + NUMERICAL MODEL IR | loads MODELLED (vectorless) | taps ASSUMED",
             color=PALETTE["muted"], fontsize=6)
    fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(path, facecolor=fig.get_facecolor()); fig.savefig(path.with_suffix(".svg"), facecolor=fig.get_facecolor())
    plt.close(fig)
