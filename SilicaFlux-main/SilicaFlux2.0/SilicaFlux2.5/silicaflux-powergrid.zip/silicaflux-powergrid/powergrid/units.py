"""Unit-safe parsing and conversion for SilicaFlux PowerGrid.

Every dimensional quantity entering the tool from a configuration file must
carry an explicit unit.  Quantities are converted to SI base units
(ohm, volt, ampere, metre, watt, kelvin offsets in degC) and stored as plain
floats internally.

Ground rules (implemented, tested in tests/test_units.py):

* A bare number for a dimensional field is rejected (``"1.2"`` is ambiguous:
  volts? millivolts?).
* Only an explicit whitelist of unit spellings is accepted, case-sensitive.
  ``"M"`` / ``"MEG"`` (SPICE mega vs milli confusion), ``"mil"`` (thousandth
  of an inch vs milli), ``"mohm"`` written as ``"MOhm"`` and similar
  ambiguous spellings are rejected with a message.
* A unit belonging to another dimension is rejected (``"5 mA"`` given where
  a voltage is expected).
* Non-finite values (nan/inf) are rejected.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any, Mapping

__all__ = [
    "UnitError",
    "DIMENSIONS",
    "parse_quantity",
    "q",
    "format_quantity",
    "to_unit",
]


class UnitError(ValueError):
    """Raised for missing, unknown, ambiguous or mismatched units."""


# dimension -> {unit spelling -> multiplier to SI}
DIMENSIONS: dict[str, dict[str, float]] = {
    "resistance": {
        "ohm": 1.0, "Ohm": 1.0, "Ω": 1.0,
        "mohm": 1e-3, "mΩ": 1e-3, "milliohm": 1e-3,
        "uohm": 1e-6, "µohm": 1e-6, "µΩ": 1e-6,
        "kohm": 1e3, "kΩ": 1e3,
    },
    "voltage": {"V": 1.0, "mV": 1e-3, "uV": 1e-6, "µV": 1e-6},
    "current": {"A": 1.0, "mA": 1e-3, "uA": 1e-6, "µA": 1e-6, "nA": 1e-9},
    "length": {"m": 1.0, "mm": 1e-3, "um": 1e-6, "µm": 1e-6, "nm": 1e-9},
    "area": {"m2": 1.0, "mm2": 1e-6, "um2": 1e-12, "µm2": 1e-12},
    "power": {"W": 1.0, "mW": 1e-3, "uW": 1e-6, "µW": 1e-6, "nW": 1e-9},
    "power_density": {           # SI: W/m^2
        "W/m2": 1.0, "W/mm2": 1e6, "mW/mm2": 1e3, "W/cm2": 1e4, "uW/um2": 1e6,
    },
    "sheet_resistance": {        # SI: ohm per square
        "ohm/sq": 1.0, "mohm/sq": 1e-3,
    },
    "resistivity": {             # SI: ohm*m
        "ohm*m": 1.0, "ohm*cm": 1e-2, "uohm*cm": 1e-8, "µohm*cm": 1e-8, "ohm*um": 1e-6,
    },
    "linear_current_density": {  # SI: A/m (current per conductor width)
        "A/m": 1.0, "mA/um": 1e3, "A/um": 1e6, "uA/um": 1.0,
    },
    "current_density": {         # SI: A/m^2
        "A/m2": 1.0, "A/cm2": 1e4, "MA/cm2": 1e10, "mA/um2": 1e9, "A/um2": 1e12,
    },
    "temperature": {"C": 0.0, "degC": 0.0},   # offset-free: values kept in degC
    "temperature_coefficient": {"1/K": 1.0, "ppm/K": 1e-6},
    "frequency": {"Hz": 1.0, "kHz": 1e3, "MHz": 1e6, "GHz": 1e9},
    "time": {"s": 1.0, "ms": 1e-3, "us": 1e-6, "µs": 1e-6, "ns": 1e-9, "ps": 1e-12},
    "capacitance": {"F": 1.0, "uF": 1e-6, "µF": 1e-6, "nF": 1e-9, "pF": 1e-12, "fF": 1e-15},
    "inductance": {"H": 1.0, "nH": 1e-9, "pH": 1e-12, "uH": 1e-6, "µH": 1e-6},
    "thermal_resistance": {"K/W": 1.0, "C/W": 1.0},
    "conductivity_thermal": {"W/(m*K)": 1.0},
    "heat_transfer_coefficient": {"W/(m2*K)": 1.0},
}

# Spellings that are refused even though they look plausible, with the reason.
AMBIGUOUS: dict[str, str] = {
    "M": "SPICE 'M' means milli, SI 'M' means mega",
    "MEG": "SPICE mega suffix; write the SI unit explicitly",
    "meg": "SPICE mega suffix; write the SI unit explicitly",
    "mil": "thousandth of an inch or milli-? use um/mm",
    "MOhm": "mega-ohm or milli-ohm? write 'kohm' or 'mohm'",
    "Mohm": "mega-ohm or milli-ohm? write 'kohm' or 'mohm'",
    "MV": "megavolt is not a valid on-chip quantity; did you mean mV?",
    "MA": "megaampere is not a valid on-chip quantity; did you mean mA?",
    "MW": "megawatt is not a valid on-chip quantity; did you mean mW?",
    "u": "bare prefix without a unit",
    "m_": "bare prefix without a unit",
    "R": "'R' is not a unit",
    "sq": "use 'ohm/sq'",
    "deg": "use 'C' (degrees Celsius)",
    "K": "absolute temperature in kelvin is not accepted; use C",
}

_NUM_UNIT = re.compile(
    r"^\s*([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)\s*([^\s].*?)?\s*$"
)


def _check_finite(value: float, text: str) -> float:
    if not math.isfinite(value):
        raise UnitError(f"non-finite quantity {text!r}")
    return value


def parse_quantity(value: Any, dimension: str, *, field: str = "") -> float:
    """Parse ``value`` (``"1.2 V"`` / ``{"value": 1.2, "unit": "V"}``) to SI.

    ``dimension`` must be a key of :data:`DIMENSIONS`.  Raises
    :class:`UnitError` for bare numbers, unknown / ambiguous units and
    dimension mismatches.  Temperatures are returned in degrees Celsius.
    """
    where = f" for field '{field}'" if field else ""
    if dimension not in DIMENSIONS:
        raise UnitError(f"unknown dimension {dimension!r}{where}")
    table = DIMENSIONS[dimension]
    if isinstance(value, bool):
        raise UnitError(f"boolean is not a {dimension}{where}")
    if isinstance(value, (int, float)):
        raise UnitError(
            f"bare number {value!r}{where} is ambiguous: a {dimension} needs an explicit "
            f"unit, e.g. one of {sorted(table)}"
        )
    if isinstance(value, Mapping):
        if set(value) - {"value", "unit", "source", "note"} or "value" not in value or "unit" not in value:
            raise UnitError(f"quantity mapping{where} needs exactly 'value' and 'unit' (+source/note)")
        num = value["value"]
        unit = value["unit"]
        if isinstance(num, bool) or not isinstance(num, (int, float)):
            raise UnitError(f"quantity value{where} must be numeric, got {num!r}")
        text = f"{num} {unit}"
    elif isinstance(value, str):
        m = _NUM_UNIT.match(value)
        if not m:
            raise UnitError(f"cannot parse quantity {value!r}{where}")
        num = float(m.group(1))
        unit = m.group(2)
        text = value
        if unit is None:
            raise UnitError(
                f"quantity {value!r}{where} has no unit; a {dimension} needs one of {sorted(table)}"
            )
    else:
        raise UnitError(f"unsupported quantity type {type(value).__name__}{where}")
    unit = str(unit).strip()
    if unit in AMBIGUOUS:
        raise UnitError(f"ambiguous unit {unit!r}{where}: {AMBIGUOUS[unit]}")
    if unit not in table:
        for dim, tab in DIMENSIONS.items():
            if unit in tab:
                raise UnitError(
                    f"unit {unit!r}{where} is a {dim}, but a {dimension} is required"
                )
        raise UnitError(f"unknown unit {unit!r}{where}; accepted for {dimension}: {sorted(table)}")
    mult = table[unit]
    if dimension == "temperature":
        return _check_finite(float(num), text)
    return _check_finite(float(num) * mult, text)


def q(text: Any, dimension: str) -> float:
    """Short alias of :func:`parse_quantity` for code and tests."""
    return parse_quantity(text, dimension)


def to_unit(si_value: float, dimension: str, unit: str) -> float:
    """Convert an SI value to ``unit`` of ``dimension`` (for reporting)."""
    table = DIMENSIONS[dimension]
    if unit not in table:
        raise UnitError(f"unit {unit!r} not valid for {dimension}")
    if dimension == "temperature":
        return si_value
    return si_value / table[unit]


def format_quantity(si_value: float, dimension: str, unit: str, digits: int = 4) -> str:
    return f"{to_unit(si_value, dimension, unit):.{digits}g} {unit}"


@dataclass(frozen=True)
class Quantity:
    """A parsed quantity that remembers how it was written (for provenance)."""

    si: float
    dimension: str
    text: str

    @classmethod
    def parse(cls, value: Any, dimension: str, field: str = "") -> "Quantity":
        si = parse_quantity(value, dimension, field=field)
        return cls(si=si, dimension=dimension, text=str(value))
