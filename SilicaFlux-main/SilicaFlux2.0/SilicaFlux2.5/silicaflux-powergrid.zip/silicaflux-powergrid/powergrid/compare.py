"""Comparison of the PowerGrid solver with OpenROAD PDNSim.

Error metrics (per net, over instances present in both results):
  * worst drop (|V - V_nominal|) of each tool and their relative difference
  * per-instance |dV| max, RMS, and RMS relative to PDNSim's worst drop
  * Pearson correlation of per-instance drops
  * quantisation floor of the PDNSim voltage file (6 significant digits)

Acceptance tolerances are only meaningful under EQUIVALENT assumptions:
same resistance data (the OpenDB tech values PDNSim reads), same source
nodes, same instance powers and PDNSim's power-to-current convention.  The
tolerance used for the "same model" check (solving PDNSim's own SPICE network)
is the output quantisation; for the independent extraction it is a stated
engineering tolerance on the worst drop (default 15 %) -- disagreements are
reported as findings, never tuned away.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np

from .graph import CurrentInjection, Network, NetType, VoltageSource
from .solver import DCSolution, solve

__all__ = ["compare_instance_voltages", "solve_pdnsim_spice", "quantisation_floor"]


def quantisation_floor(v_nominal: float, digits: int = 6) -> float:
    """Half an ULP of a value printed with ``digits`` significant digits."""
    if v_nominal == 0:
        return 0.0
    e = math.floor(math.log10(abs(v_nominal)))
    return 0.5 * 10 ** (e - digits + 1)


def compare_instance_voltages(
    mine: dict[str, float],
    pdnsim: dict[str, float],
    v_nominal: float,
    worst_rel_tol: float = 0.15,
) -> dict[str, Any]:
    names = sorted(set(mine) & set(pdnsim))
    if not names:
        return {"matched": 0, "status": "NOT RUN", "reason": "no common instances"}
    a = np.array([mine[n] for n in names])
    b = np.array([pdnsim[n] for n in names])
    da, db = np.abs(a - v_nominal), np.abs(b - v_nominal)
    diff = a - b
    worst_a, worst_b = float(da.max()), float(db.max())
    rel = (worst_a - worst_b) / worst_b if worst_b > 0 else math.nan
    corr = float(np.corrcoef(da, db)[0, 1]) if da.std() > 0 and db.std() > 0 else math.nan
    k_a, k_b = int(np.argmax(da)), int(np.argmax(db))
    return {
        "matched": len(names),
        "only_mine": len(set(mine) - set(pdnsim)),
        "only_pdnsim": len(set(pdnsim) - set(mine)),
        "worst_drop_mine_v": worst_a,
        "worst_drop_pdnsim_v": worst_b,
        "worst_drop_rel_diff": rel,
        "worst_instance_mine": names[k_a],
        "worst_instance_pdnsim": names[k_b],
        "max_abs_diff_v": float(np.max(np.abs(diff))),
        "rms_diff_v": float(np.sqrt(np.mean(diff ** 2))),
        "rms_diff_rel_to_worst": float(np.sqrt(np.mean(diff ** 2)) / worst_b) if worst_b > 0 else math.nan,
        "mean_diff_v": float(np.mean(diff)),
        "correlation": corr,
        "pdnsim_quantisation_v": quantisation_floor(v_nominal if v_nominal else 1e-4),
        "tolerance_worst_rel": worst_rel_tol,
        "status": "AGREE" if (math.isfinite(rel) and abs(rel) <= worst_rel_tol) else "DISAGREE",
    }


def solve_pdnsim_spice(spice: dict[str, Any], net_name: str, v_nominal: float,
                       ground_sign_fix: bool = True, dedupe: bool = True) -> tuple[Network, DCSolution, dict[str, Any]]:
    """Solve PDNSim's own exported resistor network with the PowerGrid solver.

    ``dedupe``: write_pg_spice (6011bbe77) repeats a node's current source once
    per resistor that starts at the node; keep one per node.
    ``ground_sign_fix``: write_pg_spice writes ground-net currents as sinks,
    while PDNSim's own solve injects them (J = +I for GROUND nets).
    """
    n = Network(f"pdnsim_spice_{net_name}")
    ground = v_nominal == 0.0
    n.add_net(net_name, NetType.GROUND if ground else NetType.POWER, v_nominal)
    for a, b, r in spice["resistors"]:
        n.add_node(a, net_name)
        n.add_node(b, net_name)
        n.add_segment(a, b, r)
    for k, (node, v) in enumerate(spice["vsources"]):
        n.add_node(node, net_name)
        n.add_source(VoltageSource(f"V{k}", node, v))
    cur: dict[str, float] = {}
    total_written = 0.0
    for node, i in spice["isources"]:
        total_written += i
        if dedupe:
            cur[node] = i
        else:
            cur[node] = cur.get(node, 0.0) + i
    sign = +1.0 if (ground and ground_sign_fix) else -1.0
    for k, (node, i) in enumerate(sorted(cur.items())):
        n.add_node(node, net_name)
        n.add_injection(CurrentInjection(f"I{k}", node, sign * i))
    sol = solve(n)
    info = {"resistors": len(spice["resistors"]), "vsources": len(spice["vsources"]),
            "isource_lines": len(spice["isources"]), "isource_nodes": len(cur),
            "duplicated_nodes": spice["isource_nodes_duplicated"],
            "total_current_written_a": total_written, "total_current_dedup_a": sum(cur.values()),
            "min_resistance_ohm": min((r for _, _, r in spice["resistors"]), default=math.nan),
            "zero_resistances": sum(1 for _, _, r in spice["resistors"] if r == 0.0)}
    return n, sol, info
