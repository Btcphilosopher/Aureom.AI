"""Maps and plots drawn ONLY from solver results.

Binning (no interpolation): every map pixel is a statistic (worst / sum) of
the solver nodes, loads or branch mid-points that fall inside the bin; bins
containing nothing are left blank (white/transparent), never filled.  The
method is written into every figure caption and into the run metadata.
Comparison plots share colour scales via explicit ``vmin``/``vmax``.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Optional, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle

from .solver import DCSolution

__all__ = ["bin_stat", "load_points", "heatmap", "save_maps", "PALETTE", "BINNING_METHOD"]

PALETTE = {"navy": "#0b1630", "gold": "#c9a227", "cyan": "#22d3ee", "violet": "#8b5cf6", "amber": "#f59e0b",
           "ink": "#e6ecf5", "muted": "#8a97b0"}
# categorical series slots validated (dataviz validate_palette.js, dark mode, surface #111f42):
# lightness band, chroma, adjacent CVD dE >= 19 / normal-vision dE >= 22, contrast >= 3:1 -> ALL PASS
SERIES = ["#0ea5c6", "#b08f1f", "#8b5cf6", "#d55181"]
BINNING_METHOD = ("binned statistic of solver values on a regular grid over the core; empty bins blank; "
                  "no interpolation or smoothing")


def bin_stat(x: np.ndarray, y: np.ndarray, v: np.ndarray, extent: tuple[float, float, float, float],
             nx: int, ny: int, stat: str = "max") -> np.ndarray:
    x0, y0, x1, y1 = extent
    ok = np.isfinite(x) & np.isfinite(y) & np.isfinite(v)
    x, y, v = x[ok], y[ok], v[ok]
    ix = np.clip(((x - x0) / (x1 - x0) * nx).astype(int), 0, nx - 1)
    iy = np.clip(((y - y0) / (y1 - y0) * ny).astype(int), 0, ny - 1)
    out = np.full((ny, nx), np.nan)
    flat = iy * nx + ix
    if stat == "max":
        acc = np.full(nx * ny, -np.inf); np.maximum.at(acc, flat, v); acc[np.isinf(acc)] = np.nan
    elif stat == "min":
        acc = np.full(nx * ny, np.inf); np.minimum.at(acc, flat, v); acc[np.isinf(acc)] = np.nan
    elif stat == "sum":
        acc = np.full(nx * ny, np.nan); cnt = np.bincount(flat, minlength=nx * ny)
        s = np.bincount(flat, weights=v, minlength=nx * ny); acc[cnt > 0] = s[cnt > 0]
    elif stat == "mean":
        acc = np.full(nx * ny, np.nan); cnt = np.bincount(flat, minlength=nx * ny)
        s = np.bincount(flat, weights=v, minlength=nx * ny); acc[cnt > 0] = s[cnt > 0] / cnt[cnt > 0]
    else:
        raise ValueError(stat)
    return acc.reshape(ny, nx)


def load_points(sol: DCSolution) -> dict[str, np.ndarray]:
    net = sol.network
    xs = np.asarray(net.node_x); ys = np.asarray(net.node_y)
    vi = np.array([net.node_index(l.vdd_node) for l in net.loads], dtype=np.int64)
    return {"x": xs[vi], "y": ys[vi], "v_vdd": sol.load_v_vdd, "v_vss": sol.load_v_vss,
            "v_eff": sol.load_v_eff, "i": sol.load_current, "p": sol.load_current * sol.load_v_eff}


def heatmap(grid: np.ndarray, extent: tuple[float, float, float, float], title: str, cbar: str, path: Path,
            cmap: str = "Oranges", vmin: Optional[float] = None, vmax: Optional[float] = None,
            overlays: Optional[Sequence[dict[str, Any]]] = None, points: Optional[Sequence[dict[str, Any]]] = None,
            provenance: str = "", scale: float = 1e6, unit: str = "um") -> str:
    x0, y0, x1, y1 = extent
    fig, ax = plt.subplots(figsize=(7.2, 6.4), dpi=110)
    fig.patch.set_facecolor(PALETTE["navy"]); ax.set_facecolor("#ffffff")
    im = ax.imshow(grid, origin="lower", extent=(x0 * scale, x1 * scale, y0 * scale, y1 * scale), cmap=cmap,
                   vmin=vmin, vmax=vmax, interpolation="nearest", aspect="equal")
    for ov in overlays or []:
        bx = ov["bbox"]
        ax.add_patch(Rectangle((bx[0] * scale, bx[1] * scale), (bx[2] - bx[0]) * scale, (bx[3] - bx[1]) * scale,
                               fill=False, ec=ov.get("color", PALETTE["cyan"]), lw=ov.get("lw", 0.8), ls=ov.get("ls", "-")))
        if ov.get("label"):
            ax.text(bx[0] * scale + 4, bx[3] * scale - 4, ov["label"], color=ov.get("color", PALETTE["cyan"]),
                    fontsize=6, va="top", ha="left")
    for pt in points or []:
        ax.plot(pt["x"] * scale, pt["y"] * scale, pt.get("marker", "^"), color=pt.get("color", PALETTE["gold"]),
                ms=pt.get("ms", 7), mec="k", mew=0.6)
        if pt.get("label"):
            ax.text(pt["x"] * scale, pt["y"] * scale, " " + pt["label"], color="k", fontsize=6)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cb.set_label(cbar, color=PALETTE["ink"]); cb.ax.tick_params(colors=PALETTE["ink"])
    ax.set_title(title, color=PALETTE["ink"], fontsize=10)
    ax.set_xlabel(f"x [{unit}]", color=PALETTE["ink"]); ax.set_ylabel(f"y [{unit}]", color=PALETTE["ink"])
    ax.tick_params(colors=PALETTE["ink"])
    fig.text(0.01, 0.005, (provenance + " | " if provenance else "") + BINNING_METHOD, color=PALETTE["muted"],
             fontsize=5.5, ha="left", va="bottom", wrap=True)
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, facecolor=fig.get_facecolor())
    if path.suffix == ".png":
        fig.savefig(path.with_suffix(".svg"), facecolor=fig.get_facecolor())
    plt.close(fig)
    return str(path)


def _vr(sh: dict[str, tuple[Optional[float], Optional[float]]], key: str,
        default: tuple[Optional[float], Optional[float]]) -> tuple[Optional[float], Optional[float]]:
    return sh.get(key, default)


def save_maps(sol: DCSolution, out: Path, extent: tuple[float, float, float, float], nbin: int = 64,
              overlays: Optional[Sequence[dict[str, Any]]] = None, provenance: str = "",
              vdd_nom: float = 1.2, shared: Optional[dict[str, tuple[Optional[float], Optional[float]]]] = None,
              warnings_pts: Optional[Sequence[dict[str, Any]]] = None) -> dict[str, str]:
    """Write the standard map set; returns {name: path}."""
    out.mkdir(parents=True, exist_ok=True)
    lp = load_points(sol)
    net = sol.network
    srcs = [{"x": s.x_m if s.x_m is not None else net.node_x[net.node_index(s.node)],
             "y": s.y_m if s.y_m is not None else net.node_y[net.node_index(s.node)],
             "color": PALETTE["gold"] if net.node_net[net.node_index(s.node)] != "VSS" else PALETTE["violet"],
             "marker": "^" if net.node_net[net.node_index(s.node)] != "VSS" else "v"} for s in net.sources]
    sh = shared or {}
    maps: dict[str, str] = {}
    drop_mv = (vdd_nom - lp["v_vdd"]) * 1e3
    bounce_mv = lp["v_vss"] * 1e3
    loss_mv = (vdd_nom - lp["v_eff"]) * 1e3
    g = bin_stat(lp["x"], lp["y"], drop_mv, extent, nbin, nbin, "max")
    maps["vdd_droop"] = heatmap(g, extent, "VDD droop at load points, worst per bin  (\u25b2 VDD, \u25bc VSS tap)", "VDD droop [mV]",
                                out / "vdd_droop.png", "Oranges", *_vr(sh, "vdd_droop", (0, None)), overlays=overlays,
                                points=srcs, provenance=provenance)
    g = bin_stat(lp["x"], lp["y"], bounce_mv, extent, nbin, nbin, "max")
    maps["vss_bounce"] = heatmap(g, extent, "VSS ground bounce at load points, worst per bin", "ground bounce [mV]",
                                 out / "vss_bounce.png", "Purples", *_vr(sh, "vss_bounce", (0, None)), overlays=overlays,
                                 points=srcs, provenance=provenance)
    g = bin_stat(lp["x"], lp["y"], loss_mv, extent, nbin, nbin, "max")
    maps["ir_drop"] = heatmap(g, extent, "Total supply loss = VDD droop + VSS bounce  (\u25b2 VDD tap, \u25bc VSS tap)", "loss [mV]",
                              out / "ir_drop.png", "Oranges", *_vr(sh, "ir_drop", (0, None)), overlays=overlays,
                              points=srcs, provenance=provenance)
    g = bin_stat(lp["x"], lp["y"], lp["v_eff"], extent, nbin, nbin, "min")
    maps["v_eff"] = heatmap(g, extent, "Effective supply V_eff = V_VDD - V_VSS (worst per bin)", "V_eff [V]",
                            out / "v_eff.png", "Blues_r", *_vr(sh, "v_eff", (None, None)), overlays=overlays,
                            points=srcs, provenance=provenance)
    g = bin_stat(lp["x"], lp["y"], lp["v_vdd"], extent, nbin, nbin, "min")
    maps["vdd_voltage"] = heatmap(g, extent, "VDD node voltage at loads (min per bin)", "V_VDD [V]",
                                  out / "vdd_voltage.png", "Blues_r", overlays=overlays, points=srcs, provenance=provenance)
    g = bin_stat(lp["x"], lp["y"], lp["v_vss"], extent, nbin, nbin, "max")
    maps["vss_voltage"] = heatmap(g, extent, "VSS node voltage at loads (max per bin)", "V_VSS [V]",
                                  out / "vss_voltage.png", "Purples", overlays=overlays, points=srcs, provenance=provenance)
    area_mm2 = ((extent[2] - extent[0]) / nbin) * ((extent[3] - extent[1]) / nbin) * 1e6
    g = bin_stat(lp["x"], lp["y"], lp["p"], extent, nbin, nbin, "sum") / area_mm2
    maps["power_density"] = heatmap(g, extent, "Load power density (sum per bin / bin area)", "W/mm^2",
                                    out / "power_density.png", "Oranges", overlays=overlays, provenance=provenance)
    xs = np.asarray(net.node_x); ys = np.asarray(net.node_y)
    a = np.asarray(net.seg_a); b = np.asarray(net.seg_b)
    mx, my = 0.5 * (xs[a] + xs[b]), 0.5 * (ys[a] + ys[b])
    g = bin_stat(mx, my, np.abs(sol.segment_current) * 1e3, extent, nbin, nbin, "max")
    maps["current"] = heatmap(g, extent, "Branch current magnitude (max per bin, all layers)", "|I| [mA]",
                              out / "current.png", "Blues", overlays=overlays, points=srcs, provenance=provenance)
    # critical loads + supply sources
    k = np.argsort(lp["v_eff"])[: min(25, len(lp["v_eff"]))]
    crit = [{"x": lp["x"][i], "y": lp["y"][i], "marker": "o", "color": PALETTE["amber"], "ms": 4} for i in k]
    g = bin_stat(lp["x"], lp["y"], loss_mv, extent, nbin, nbin, "max")
    maps["critical_loads"] = heatmap(g, extent, "25 worst-V_eff load points (amber) and supply sources",
                                     "loss [mV]", out / "critical_loads.png", "Greys", overlays=overlays,
                                     points=srcs + crit, provenance=provenance)
    if shared and "ir_drop_common" in shared:
        lo, hi = shared["ir_drop_common"]
        g = bin_stat(lp["x"], lp["y"], loss_mv, extent, nbin, nbin, "max")
        maps["ir_drop_common_scale"] = heatmap(g, extent, "Total supply loss on the COMMON comparison scale", "loss [mV]",
                                               out / "ir_drop_common_scale.png", "Oranges", lo, hi, overlays=overlays,
                                               points=srcs, provenance=provenance)
    if warnings_pts is not None:
        maps["connectivity_warnings"] = heatmap(np.full((nbin, nbin), np.nan), extent,
                                                f"PDN connectivity warnings ({len(warnings_pts)} marked)", "-",
                                                out / "connectivity_warnings.png", "Greys", overlays=overlays,
                                                points=list(warnings_pts) + srcs, provenance=provenance)
    return maps


def layer_maps(sol: DCSolution, out: Path, extent: tuple[float, float, float, float], nbin: int = 64,
               provenance: str = "") -> dict[str, str]:
    """Per-metal-layer branch-current maps (layer inspection)."""
    net = sol.network
    xs = np.asarray(net.node_x); ys = np.asarray(net.node_y)
    a = np.asarray(net.seg_a); b = np.asarray(net.seg_b)
    mx, my = 0.5 * (xs[a] + xs[b]), 0.5 * (ys[a] + ys[b])
    layers = np.array([l or "" for l in net.seg_layer], dtype=object)
    I = np.abs(sol.segment_current) * 1e3
    vmax = float(np.nanmax(I)) if I.size else None
    out_maps = {}
    for lyr in sorted(set(layers.tolist())):
        if not lyr or lyr == "same-layer-junction":
            continue
        m = layers == lyr
        g = bin_stat(mx[m], my[m], I[m], extent, nbin, nbin, "max")
        out_maps[lyr] = heatmap(g, extent, f"{lyr}: branch |I| (max per bin; common scale)", "|I| [mA]",
                                out / f"layer_{lyr}.png", "Blues", 0, vmax, provenance=provenance)
    return out_maps
