"""HTML engineering reports from run directories (raw outputs kept alongside)."""
from __future__ import annotations

import html
import json
import os
from pathlib import Path
from typing import Any

CSS = """
:root{--navy:#0b1630;--panel:#111f42;--panel2:#16285a;--gold:#c9a227;--cyan:#22d3ee;--violet:#8b5cf6;--amber:#f59e0b;
--ink:#e6ecf5;--muted:#8a97b0;--pass:#1f9d55;--fail:#d64545;--neutral:#5b6b8c;--blocked:#8b5cf6}
*{box-sizing:border-box}body{margin:0;background:var(--navy);color:var(--ink);font:14px/1.5 "IBM Plex Sans","Inter",system-ui,sans-serif}
header{padding:28px 32px;border-bottom:1px solid #22325f;background:linear-gradient(120deg,#0b1630,#14224d)}
h1{margin:0;color:var(--gold);font-weight:600;letter-spacing:.5px}h2{color:var(--gold);border-bottom:1px solid #22325f;padding-bottom:6px;margin-top:36px}
h3{color:var(--cyan);margin-bottom:6px}main{padding:0 32px 48px;max-width:1500px}
table{border-collapse:collapse;margin:8px 0 16px;font-size:12.5px;width:100%}th,td{border:1px solid #22325f;padding:4px 8px;text-align:left;vertical-align:top}
th{background:var(--panel2);color:var(--gold);font-weight:600}tr:nth-child(even) td{background:#0f1c3d}
code,.mono{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:12px}
.badge{display:inline-block;padding:1px 8px;border-radius:10px;font-size:11px;font-weight:600;border:1px solid}
.b-actual{color:var(--cyan);border-color:var(--cyan)}.b-model{color:var(--gold);border-color:var(--gold)}
.b-assume{color:var(--amber);border-color:var(--amber)}.b-demo{color:var(--violet);border-color:var(--violet)}
.b-notrun{color:var(--muted);border-color:var(--muted)}.b-blocked{color:#fff;background:var(--blocked);border-color:var(--blocked)}
.s-PASS{background:var(--pass);color:#fff}.s-FAIL{background:var(--fail);color:#fff}.s-UNKNOWN,.s-PARTIAL,.s-NOT{background:var(--neutral);color:#fff}
.s-BLOCKED{background:var(--blocked);color:#fff}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(420px,1fr));gap:14px}
figure{margin:0;background:var(--panel);padding:8px;border-radius:6px}figure img{width:100%;border-radius:4px}figcaption{color:var(--muted);font-size:11.5px}
.kpi{display:inline-block;background:var(--panel);border:1px solid #22325f;border-radius:6px;padding:10px 14px;margin:4px 8px 4px 0;min-width:190px}
.kpi b{display:block;font-size:20px;color:var(--gold)}.kpi span{color:var(--muted);font-size:11.5px}
.note{color:var(--muted);font-size:12px}.warn{color:var(--amber)}
"""

BADGE = {"ACTUAL EDA RESULT": "b-actual", "NUMERICAL MODEL": "b-model", "ASSUMPTION": "b-assume", "DEMONSTRATION": "b-demo",
         "NOT RUN": "b-notrun", "BLOCKED": "b-blocked"}


def badge(status: str) -> str:
    return f'<span class="badge {BADGE.get(status, "b-notrun")}">{html.escape(status)}</span>'


def gate_badge(status: str) -> str:
    cls = "s-" + status.split()[0]
    return f'<span class="badge {cls}">{html.escape(status)}</span>'


def fmt(v: Any, nd: int = 4) -> str:
    if v is None:
        return "—"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, float):
        return f"{v:.{nd}g}"
    if isinstance(v, (list, dict)):
        return html.escape(json.dumps(v)[:300])
    return html.escape(str(v))


def table(rows: list[dict[str, Any]], cols: list[str] | None = None, nd: int = 4) -> str:
    if not rows:
        return '<p class="note">no rows</p>'
    cols = cols or list(rows[0].keys())
    h = "".join(f"<th>{html.escape(c)}</th>" for c in cols)
    body = "".join("<tr>" + "".join(f"<td>{fmt(r.get(c), nd)}</td>" for c in cols) + "</tr>" for r in rows)
    return f"<table><tr>{h}</tr>{body}</table>"


def fig(path: str, caption: str, base: Path) -> str:
    rel = os.path.relpath(path, base)
    return f'<figure><img src="{html.escape(rel)}" loading="lazy"><figcaption>{html.escape(caption)}</figcaption></figure>'


def comparison_table(run_dir: Path) -> str:
    run = json.loads((run_dir / "run.json").read_text())
    lines = ["resistance  net  case                    mine_mV   pdnsim_mV  rel_diff  rms_uV  corr    status"]
    for lab, r in run.get("pdnsim", {}).get("runs", {}).items():
        for net, v in r.get("nets", {}).items():
            for case, c in v.get("comparison", {}).items():
                lines.append(f"{lab:10s}  {net:4s} {case:22s} {c['worst_drop_mine_v']*1e3:8.4f}  {c['worst_drop_pdnsim_v']*1e3:9.4f}"
                             f"  {c['worst_drop_rel_diff']*100:7.2f}%  {c['rms_diff_v']*1e6:6.2f}  {c['correlation']:.5f} {c['status']}")
    return "\n".join(lines)


def write_report(run_dir: Path) -> str:
    src = run_dir / "run.json" if (run_dir / "run.json").exists() else run_dir / "summary.json"
    if not src.exists():
        raise FileNotFoundError(f"no run.json or summary.json in {run_dir}")
    run = json.loads(src.read_text())
    kind = run.get("run_type")
    if kind != "physical_analysis":
        return _generic(run_dir, run)
    h = run["header"]
    dm = next(iter(run["maps"]))
    sm = run["supply_models"]
    base = run_dir
    parts = [f"<html><head><meta charset='utf-8'><title>PowerGrid analysis report</title><style>{CSS}</style></head><body>",
             f"<header><h1>SilicaFlux PowerGrid — static IR analysis: {html.escape(run['design'])}</h1>"
             f"<div class='note'>{badge('ACTUAL EDA RESULT')} geometry &amp; PDNSim · {badge('NUMERICAL MODEL')} custom solver · "
             f"{badge('ASSUMPTION')} supply taps · loads: {html.escape(run['load_source']['provenance'])} (vectorless)</div></header><main>"]
    d = sm[dm] if dm in sm else next(iter(sm.values()))
    parts.append("<h2>Headline (default supply model)</h2>")
    parts.append("".join(f"<div class='kpi'><b>{v}</b><span>{k}</span></div>" for k, v in (
        ("worst V_eff", f"{d['worst_v_eff_v']:.5f} V"), ("worst total loss", f"{d['worst_total_loss_mv']:.3f} mV"),
        ("worst VDD droop", f"{d['worst_vdd_droop_mv']:.3f} mV"), ("worst ground bounce", f"{d['worst_vss_bounce_mv']:.3f} mV"),
        ("resistive loss", f"{d['resistive_loss_uw']:.2f} µW"), ("load current", f"{d['total_load_current_ma']:.3f} mA"))))
    parts.append(f"<p class='note'>Supply model {html.escape(dm)} — {html.escape(d['description'])}. Nominal supply "
                 f"{run['supply']['vdd_nominal_v']} V ({html.escape(run['supply']['source'])}).</p>")
    parts.append("<h2>Provenance</h2>" + table([
        {"item": "PowerGrid / solver", "value": f"{h['powergrid_version']} / {h['solver_version']}"},
        {"item": "PowerGrid git", "value": h["powergrid_git"]}, {"item": "repository git", "value": h["repository_git"]},
        {"item": "OpenROAD", "value": h["openroad"]}, {"item": "ngspice", "value": h["ngspice"]},
        {"item": "Python / packages", "value": f"{h['python']} {h['packages']}"},
        {"item": "PDK", "value": "IHP SG13G2 (ORFS ab2aaf0f platform), typical corner 1.20 V 25 C"},
        {"item": "load source", "value": run["load_source"]["label"]},
        {"item": "resistance source (primary)", "value": run["resistance_data"]["primary"]},
        {"item": "numerical method", "value": "nodal analysis, zero-R supernodes, Dirichlet elimination, SuperLU (COLAMD)"},
        {"item": "map method", "value": run["map_method"]},
        {"item": "timestamp", "value": h["timestamp_utc"]}], ["item", "value"]))
    parts.append("<h3>Input files (sha256)</h3>" + table([{"file": k, "sha256": v} for k, v in run["inputs"]["files_sha256"].items()]))
    parts.append("<h2>PDN connectivity (OpenROAD check_power_grid)</h2>" + table(run["connectivity"]["checks"],
                 ["net", "type", "result", "error_lines", "error_file"]))
    imp = run["import"]
    parts.append("<h3>Extraction</h3>" + table([{k: imp[k] for k in ("wires", "wires_floating", "vias", "vias_dangling",
                 "macro_pin_landings", "junctions", "instances", "std_cells_attached", "macros_attached",
                 "total_power_w", "total_current_a")}]))
    parts.append("<p class='note'>" + html.escape("; ".join(run["findings"])) + "</p>")
    parts.append("<h2>Supply models (ASSUMED taps)</h2>" + table(
        [{"model": k, **{kk: v[kk] for kk in ("sources", "worst_total_loss_mv", "worst_vdd_droop_mv", "worst_vss_bounce_mv",
          "mean_total_loss_mv", "max_source_current_ma", "min_source_current_ma", "resistive_loss_uw", "kcl_ok", "power_ok")}}
         for k, v in sm.items()]))
    parts.append("<h2>Maps</h2><div class='grid'>" + "".join(fig(p, f"{k} — {dm}", base) for k, p in run["maps"][dm].items()) + "</div>")
    others = [(m, v["ir_drop_common_scale"]) for m, v in run["maps"].items() if m != "layers" and isinstance(v, dict) and "ir_drop_common_scale" in v]
    if others:
        parts.append("<h3>IR-drop maps per supply model (common colour scale)</h3><div class='grid'>" +
                     "".join(fig(p, m, base) for m, p in others) + "</div>")
    parts.append("<h3>Per-layer branch current</h3><div class='grid'>" +
                 "".join(fig(p, k, base) for k, p in run["maps"].get("layers", {}).items()) + "</div>")
    parts.append("<h2>Logical groups (instance-name prefixes; annotations, not block outlines)</h2>" + table(run["groups"]))
    cd = run["current_density"]
    parts.append("<h2>Current density &amp; EM screening</h2>" + table(cd["layers"]) +
                 f"<p>EM screening: <b>{html.escape(cd['em']['overall'])}</b> {fmt(cd['em']['counts'])} — "
                 f"{html.escape(cd['em']['basis'])}</p>" + table([cd["em"]["worst_segment"] or {}]))
    parts.append("<h2>Resistance data sources</h2>" + table(run["resistance_data"]["table"]) +
                 f"<p class='warn'>{html.escape(run['resistance_data']['finding'])}</p>")
    parts.append("<h2>Sensitivities</h2>" + table([{"case": k, **{kk: v[kk] for kk in ("worst_total_loss_mv", "worst_vdd_droop_mv",
                 "worst_vss_bounce_mv", "resistive_loss_uw", "fixed_point_iterations")}} for k, v in run["sensitivity"].items()]))
    pd = run.get("pdnsim")
    if pd:
        rows = []
        for lab, r in pd["runs"].items():
            for net, v in r["nets"].items():
                for case, c in v["comparison"].items():
                    rows.append({"resistance": lab, "net": net, "case": case, "mine_mV": c["worst_drop_mine_v"] * 1e3,
                                 "pdnsim_mV": c["worst_drop_pdnsim_v"] * 1e3, "rel_diff_%": c["worst_drop_rel_diff"] * 100,
                                 "rms_uV": c["rms_diff_v"] * 1e6, "corr": c["correlation"], "matched": c["matched"], "status": c["status"]})
        parts.append(f"<h2>Custom solver vs OpenROAD PDNSim {badge('ACTUAL EDA RESULT')}</h2>" + table(rows) +
                     "<ul>" + "".join(f"<li>{html.escape(x)}</li>" for x in pd["limitations"]) + "</ul>")
        sr = pd["runs"].get("odb_tech", {}).get("spice_resolve")
        if sr:
            parts.append("<h3>PDNSim's own network (write_pg_spice) re-solved by PowerGrid</h3>" +
                         table([{"net": k, **v} for k, v in sr.items()]))
    tm = run.get("timing", {})
    parts.append("<h2>Timing coupling</h2>" + f"<p>{html.escape(str(tm.get('label', '')))} · voltage-aware STA: "
                 f"{gate_badge(tm.get('voltage_aware_sta', {}).get('status', 'NOT RUN'))} "
                 f"{html.escape(str(tm.get('voltage_aware_sta', {}).get('reason')))}</p>" +
                 table(tm.get("rows", [])[:15], ["startpoint", "endpoint", "slack_ns", "group", "v_eff_start", "v_eff_end",
                                                  "supply_loss_mv", "flags", "timing_effect"]))
    parts.append("<h2>Remaining signoff requirements</h2><ul>" + "".join(f"<li>{x}</li>" for x in (
        "foundry-qualified per-layer and via resistance (reconcile tech LEF vs setRC.tcl) and EM rules with temperature/lifetime",
        "real pad ring / package / bond-wire model and supply pad assignment",
        "activity from simulation of real workloads mapped to the gate netlist (VCD/SAIF), SRAM access energy",
        "post-route extracted PDN (incl. signal-route coupling), CTS clock-tree power, decap insertion",
        "dynamic (vectored) IR / package-level transient with credible RLC and regulator models",
        "voltage-aware STA with characterised low-voltage Liberty corners",
        "commercial EM/IR signoff tool correlation and human engineering approval")) + "</ul>")
    parts.append("</main></body></html>")
    out = run_dir / "report.html"
    out.write_text("\n".join(parts))
    return str(out)


def _generic(run_dir: Path, run: dict[str, Any]) -> str:
    parts = [f"<html><head><meta charset='utf-8'><title>PowerGrid report</title><style>{CSS}</style></head><body>",
             f"<header><h1>SilicaFlux PowerGrid — {html.escape(str(run.get('run_type')))}</h1>"
             f"<div class='note'>{html.escape(str(run.get('fidelity', run.get('summary', {}).get('label', ''))))}</div></header><main>"]
    kind = run.get("run_type")
    if kind == "pdn_optimisation":
        flat = [{"id": v["id"], "label": v["label"], "status": v.get("status"), "reason": v.get("reason"),
                 "worst_loss_mv_WB4": v.get("worst_loss_mv"),
                 "metal5_signal_blockage_pct": (v["metal5_blockage"] * 100) if v.get("metal5_blockage") is not None else None,
                 "pdn_metal_area_um2": v.get("pdn_metal_area_um2"), "via_cuts": v.get("via_cuts_total"),
                 "pareto": v.get("pareto_loss_vs_metal5")} for v in run["variants"]]
        parts.append("<h2>Variants (regenerated + checked in OpenROAD)</h2>" + table(flat))
        parts.append("<h2>Marginal gains vs baseline</h2>" + table(run["marginal_gains"]))
        grt = run_dir / "global_route.json"
        if grt.exists():
            g = json.loads(grt.read_text())
            parts.append("<h2>Measured global-route overflow (FastRoute)</h2>" +
                         table([{"label": v["label"], "total_overflow": v["total_overflow"], "seconds": v["seconds"]} for v in g.values()]))
        run = {k: v for k, v in run.items() if k not in ("variants", "marginal_gains")}
    for k, v in run.items():
        if k in ("header",):
            continue
        if isinstance(v, list) and v and isinstance(v[0], dict):
            parts.append(f"<h2>{html.escape(k)}</h2>" + table(v))
        elif isinstance(v, dict) and k == "experiments":
            for ek, ev in v.items():
                parts.append(f"<h2>{html.escape(ek)}</h2><p>{html.escape(str(ev.get('headline', '')))}</p>")
                for kk in ("rows", "via_current_crowding"):
                    if isinstance(ev.get(kk), list):
                        parts.append(table(ev[kk]))
                if isinstance(ev.get("row"), dict):
                    parts.append(table([ev["row"]]))
        else:
            parts.append(f"<h3>{html.escape(k)}</h3><pre class='mono'>{html.escape(json.dumps(v, indent=1, default=str)[:4000])}</pre>")
    imgs = sorted(run_dir.rglob("*.png"))
    if imgs:
        parts.append("<h2>Figures</h2><div class='grid'>" + "".join(fig(str(p), p.relative_to(run_dir).as_posix(), run_dir) for p in imgs[:60]) + "</div>")
    parts.append("</main></body></html>")
    out = run_dir / "report.html"
    out.write_text("\n".join(parts))
    return str(out)
