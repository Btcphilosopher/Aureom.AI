"""Load-model interface: where current demand comes from, with provenance.

Supported load sources
----------------------
A. user-supplied per-block power           (ASSUMED unless the user states otherwise)
B. user-supplied per-instance current      (as labelled by the user)
C. library-based analysis (OpenSTA)        (MODELLED: vectorless, or SIMULATED with a VCD)
D. time-windowed current profiles          (SIMULATED; each window solved as a DC point)

Power-to-current conversion
---------------------------
``I = P / V``.  Every conversion records which V was used:
* ``nominal`` -- the domain's nominal supply (single linear solve);
* ``local``   -- the solved local effective supply: constant-power loads,
  solved by fixed-point iteration in :mod:`powergrid.solver` with convergence
  and voltage-collapse checks.

Activity profiles
-----------------
Workload profiles (idle, cpu, vector, tensor, sram, dma, concurrent) are only
*scalings of a stated baseline* unless backed by a simulation trace.  Their
provenance is carried into every report.  No wattage is assigned to a block
merely because it exists: a block without data is listed as MISSING.

VCD / SAIF
----------
OpenROAD 2.0-12331 offers ``read_power_activities -scope S -vcd F`` (VCD only);
there is no ``read_saif`` / ``read_vcd`` command in this build.  SAIF import is
therefore BLOCKED here.  The VCD hierarchy must match the netlist instance
hierarchy under ``-scope``; an RTL-simulation VCD of SilicaFlux-V does not map
onto the synthesised, flattened/renamed netlist automatically (see
:func:`vcd_scope_check`).
"""
from __future__ import annotations

import gzip
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .provenance import DataSource
from .units import parse_quantity

__all__ = ["BlockPower", "LoadSet", "ActivityProfile", "load_block_powers", "vcd_scope_check", "BLOCKS",
           "power_report_by_group"]

BLOCKS = ["cpu", "vector", "tensor", "sram", "fabric", "dma", "clock", "periph", "testcore"]


@dataclass
class BlockPower:
    block: str
    power_w: Optional[float]
    source: DataSource
    note: str = ""
    region: Optional[tuple[float, float, float, float]] = None   # x0,y0,x1,y1 (m)

    @property
    def missing(self) -> bool:
        return self.power_w is None


@dataclass
class ActivityProfile:
    name: str
    source: DataSource
    scale: dict[str, float]           # block -> multiplier of the baseline block power
    note: str = ""


@dataclass
class LoadSet:
    name: str
    blocks: list[BlockPower]
    conversion: str = "nominal"       # nominal | local
    fidelity: str = "DEMONSTRATION"
    notes: list[str] = field(default_factory=list)

    def total_w(self) -> float:
        return sum(b.power_w or 0.0 for b in self.blocks)

    def missing(self) -> list[str]:
        return [b.block for b in self.blocks if b.missing]

    def apply(self, profile: ActivityProfile) -> "LoadSet":
        new = []
        for b in self.blocks:
            s = profile.scale.get(b.block, 1.0)
            new.append(BlockPower(b.block, None if b.power_w is None else b.power_w * s,
                                  DataSource.ASSUMED if profile.source is DataSource.ASSUMED else b.source,
                                  f"{b.note}; profile {profile.name} x{s}", b.region))
        return LoadSet(f"{self.name}:{profile.name}", new, self.conversion, self.fidelity,
                       self.notes + [f"activity profile {profile.name} ({profile.source.value}): {profile.note}"])


def load_block_powers(spec: dict[str, Any]) -> LoadSet:
    """Parse a ``loads:`` YAML mapping. Every power must carry a unit and a source."""
    blocks = []
    for name, d in spec.get("blocks", {}).items():
        if d is None or d.get("power") in (None, "missing"):
            blocks.append(BlockPower(name, None, DataSource.ASSUMED, "no data"))
            continue
        src = d.get("source")
        if src is None:
            raise ValueError(f"load block {name}: 'source' (MEASURED/SIMULATED/MODELLED/ASSUMED) is mandatory")
        region = None
        if "region_um" in d:
            x0, y0, x1, y1 = (float(v) * 1e-6 for v in d["region_um"])
            region = (x0, y0, x1, y1)
        blocks.append(BlockPower(name, parse_quantity(d["power"], "power", field=f"loads.{name}.power"),
                                 DataSource(src), d.get("note", ""), region))
    return LoadSet(spec.get("name", "loads"), blocks, spec.get("conversion", "nominal"),
                   spec.get("fidelity", "DEMONSTRATION"), list(spec.get("notes", [])))


def vcd_scope_check(vcd: str | Path, netlist_instances: list[str], max_scopes: int = 20000) -> dict[str, Any]:
    """Check whether VCD scopes can be mapped onto netlist instance names.

    Returns the fraction of netlist hierarchy prefixes found in the VCD; a low
    value means the RTL-simulation hierarchy does not match the gate netlist and
    activity annotation would silently fall back to defaults.
    """
    p = Path(vcd)
    opener = gzip.open if p.suffix == ".gz" else open
    scopes: list[str] = []
    stack: list[str] = []
    with opener(p, "rt", errors="replace") as fh:  # type: ignore[operator]
        for line in fh:
            m = re.match(r"\s*\$scope\s+\w+\s+(\S+)\s+\$end", line)
            if m:
                stack.append(m.group(1))
                scopes.append("/".join(stack))
                if len(scopes) > max_scopes:
                    break
            elif re.match(r"\s*\$upscope", line):
                if stack:
                    stack.pop()
            elif line.startswith("$enddefinitions"):
                break
    prefixes = sorted({i.split("/")[0] for i in netlist_instances if "/" in i})
    vcd_leaf = {s.split("/")[-1] for s in scopes}
    hit = [p_ for p_ in prefixes if p_ in vcd_leaf]
    return {"vcd": str(p), "scopes": len(scopes), "netlist_top_prefixes": len(prefixes),
            "matched_prefixes": len(hit), "match_fraction": (len(hit) / len(prefixes)) if prefixes else 0.0,
            "examples_unmatched": [p_ for p_ in prefixes if p_ not in vcd_leaf][:10]}


def power_report_by_group(power_w: dict[str, float], groups: dict[str, list[str]]) -> dict[str, float]:
    """Sum per-instance power by FloorplanLab-style instance-name prefix groups."""
    out = {g: 0.0 for g in groups}
    out["other"] = 0.0
    for inst, p in power_w.items():
        for g, prefixes in groups.items():
            if any(inst.startswith(pre) for pre in prefixes):
                out[g] += p
                break
        else:
            out["other"] += p
    return out
