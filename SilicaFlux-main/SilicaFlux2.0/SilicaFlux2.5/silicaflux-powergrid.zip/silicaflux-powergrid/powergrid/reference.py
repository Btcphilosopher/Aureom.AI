"""`powergrid solve`: solve a configured reference network (sheet or strap grid)."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .config import MeshConfig, load_yaml
from .current_density import em_screen, layer_summary
from .flows import _jsonable, _summary, provenance_header, write_csv
from .graph import LoadModel
from .mesh import BlockLoad, GridSpec, LayerDef, PadDef, ViaDef, build_strap_grid, sheet_square
from .solver import SolverOptions, solve
from .units import parse_quantity
from .visualise import save_maps


def _grid_from_cfg(g: dict[str, Any], vdd: float) -> GridSpec:
    q = parse_quantity
    layers = [LayerDef(l["name"], l["direction"], q(l["width"], "length"), q(l["pitch"], "length"),
                       q(l.get("offset", "0 um"), "length"), q(l["sheet_resistance"], "sheet_resistance"),
                       provenance=l.get("source", "ASSUMED")) for l in g["layers"]]
    vias = [ViaDef(v["lower"], v["upper"], q(v["resistance_per_cut"], "resistance"), int(v["cuts"]),
                   provenance=v.get("source", "ASSUMED")) for v in g["vias"]]
    pads = [PadDef(p["name"], p["net"], q(p["x"], "length"), q(p["y"], "length"), p["layer"],
                   vdd if p["net"] == g.get("vdd_net", "VDD") else 0.0, q(p.get("series_resistance", "0 ohm"), "resistance"),
                   provenance=p.get("source", "ASSUMED")) for p in g["pads"]]
    loads = []
    for b in g.get("loads", []):
        x0, y0, x1, y1 = (q(v, "length") for v in b["region"])
        if "current" in b:
            loads.append(BlockLoad(b["name"], x0, y0, x1, y1, current_a=q(b["current"], "current"), provenance=b.get("source", "ASSUMED"), layer=b.get("layer")))
        else:
            loads.append(BlockLoad(b["name"], x0, y0, x1, y1, power_w=q(b["power"], "power"), model=LoadModel.FIXED_POWER,
                                   provenance=b.get("source", "ASSUMED"), layer=b.get("layer")))
    return GridSpec(q(g["width"], "length"), q(g["height"], "length"), layers, vias, pads, loads, vdd_v=vdd,
                    model_ground=g.get("model_ground", True), name=g.get("name", "grid"))


def solve_reference(cfg_path: Path, out: Path) -> dict[str, Any]:
    d = load_yaml(cfg_path)
    cfg = MeshConfig(**d)
    vdd = parse_quantity(cfg.supply, "voltage")
    if cfg.kind == "sheet":
        net = sheet_square(int(cfg.n or 0), parse_quantity(cfg.side, "length"), parse_quantity(cfg.sheet_resistance, "sheet_resistance"),
                           vdd, parse_quantity(cfg.current_density, "current_density"))
        extent = (0.0, 0.0, parse_quantity(cfg.side, "length"), parse_quantity(cfg.side, "length"))
    else:
        spec = _grid_from_cfg(cfg.grid or {}, vdd)
        net = build_strap_grid(spec)
        extent = (0.0, 0.0, spec.width_m, spec.height_m)
    sopts = SolverOptions(**cfg.solver)
    sol = solve(net, sopts)
    out.mkdir(parents=True, exist_ok=True)
    summ = _summary(sol, vdd)
    maps = save_maps(sol, out / "maps", extent, 48, provenance=f"{cfg.fidelity} | {cfg.name}", vdd_nom=vdd)
    ls = layer_summary(sol)
    em = em_screen(sol)
    write_csv(out / "loads.csv", sol.load_table())
    write_csv(out / "layers.csv", ls)
    run = {"run_type": "reference_solve", "status": "COMPLETED", "config": str(cfg_path.resolve()),
           "config_content": d, "header": provenance_header(), "fidelity": cfg.fidelity, "network": net.summary(),
           "summary": summ, "metrics": sol.metrics, "warnings": sol.warnings, "maps": maps,
           "em": {k: v for k, v in em.items() if k not in ("status_per_segment", "utilisation")}}
    (out / "run.json").write_text(json.dumps(_jsonable(run), indent=1, default=str))
    return run
