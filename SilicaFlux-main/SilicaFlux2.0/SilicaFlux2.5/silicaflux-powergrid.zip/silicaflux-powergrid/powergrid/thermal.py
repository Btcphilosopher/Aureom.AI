"""Standalone die thermal model and electrothermal coupling (research grade).

Thermal model
-------------
Steady-state 2-D conduction in a silicon slab (thickness t_si, conductivity
k_si) discretised on an nx x ny grid; every cell loses heat to an ambient
reference through a package path whose total resistance theta_ja (K/W) is
shared over the die area (h_eff = 1 / (theta_ja * A_die)).  The thermal
network is solved with the *same* verified PowerGrid DC solver by analogy
(temperature <-> voltage, heat flow <-> current, ambient <-> source with a
series resistance).  Every parameter is an input with a source label; none is
built in.  This is NOT a package-qualified thermal model (no heat spreader,
mould, board or convection detail) -- use TwinLab or a specialist tool for
that and import the map with :func:`import_temperature_map`.

Electrothermal loop
-------------------
1 solve PDN -> 2 power map (loads + I^2R) -> 3 temperature -> 4 R(T) = R0 (1 +
alpha (T - T0)) with a technology-supplied alpha -> 5 re-solve -> 6 converge
(|dT|_inf < tol) with under-relaxation.  If the technology profile provides
no temperature coefficient the loop is BLOCKED for real designs.
"""
from __future__ import annotations

import csv
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np

from .graph import CurrentInjection, Network, NetType, VoltageSource
from .solver import DCSolution, SolverOptions, solve

__all__ = ["ThermalParams", "solve_die_temperature", "electrothermal", "import_temperature_map", "power_map"]


@dataclass
class ThermalParams:
    k_si_w_mk: float
    t_si_m: float
    theta_ja_k_w: float
    t_ambient_c: float
    nx: int = 32
    ny: int = 32
    source: str = "ASSUMED"
    notes: list[str] = field(default_factory=list)


def power_map(x: np.ndarray, y: np.ndarray, p: np.ndarray, extent: tuple[float, float, float, float],
              nx: int, ny: int) -> np.ndarray:
    """Bin point powers (W) into an nx x ny grid over extent (x0,y0,x1,y1)."""
    x0, y0, x1, y1 = extent
    ix = np.clip(((x - x0) / (x1 - x0) * nx).astype(int), 0, nx - 1)
    iy = np.clip(((y - y0) / (y1 - y0) * ny).astype(int), 0, ny - 1)
    out = np.zeros((nx, ny))
    np.add.at(out, (ix, iy), p)
    return out


def solve_die_temperature(pmap: np.ndarray, width_m: float, height_m: float, prm: ThermalParams) -> tuple[np.ndarray, dict[str, Any]]:
    nx, ny = pmap.shape
    dx, dy = width_m / nx, height_m / ny
    area = width_m * height_m
    h_eff = 1.0 / (prm.theta_ja_k_w * area)          # W/(m^2 K)
    net = Network("thermal")
    net.add_net("T", NetType.POWER, prm.t_ambient_c if prm.t_ambient_c != 0 else 1e-9)
    for i in range(nx):
        for j in range(ny):
            net.add_node(f"t{i},{j}", "T", "si", (i + 0.5) * dx, (j + 0.5) * dy)
    gx = prm.k_si_w_mk * prm.t_si_m * dy / dx       # lateral conductance between x-neighbours
    gy = prm.k_si_w_mk * prm.t_si_m * dx / dy
    for i in range(nx):
        for j in range(ny):
            if i + 1 < nx:
                net.add_segment(f"t{i},{j}", f"t{i+1},{j}", 1.0 / gx)
            if j + 1 < ny:
                net.add_segment(f"t{i},{j}", f"t{i},{j+1}", 1.0 / gy)
            r_amb = 1.0 / (h_eff * dx * dy)
            net.add_source(VoltageSource(f"amb{i},{j}", f"t{i},{j}", prm.t_ambient_c, series_resistance_ohm=r_amb,
                                         check_nominal=False))
            if pmap[i, j] != 0:
                net.add_injection(CurrentInjection(f"q{i},{j}", f"t{i},{j}", float(pmap[i, j])))
    sol = solve(net)
    T = sol.node_voltage.reshape(nx, ny)
    total = float(pmap.sum())
    return T, {"t_max_c": float(T.max()), "t_mean_c": float(T.mean()), "total_power_w": total,
               "theta_check_k_w": (float(T.mean()) - prm.t_ambient_c) / total if total > 0 else math.nan,
               "kcl_ok": bool(sol.metrics["kcl_ok"]), "source": prm.source}


def electrothermal(net: Network, tcr_per_k: float, t_ref_c: float, prm: ThermalParams,
                   extent: tuple[float, float, float, float], max_iter: int = 30, tol_c: float = 1e-3,
                   relax: float = 0.7, opts: Optional[SolverOptions] = None) -> dict[str, Any]:
    """Iterate PDN <-> die temperature with temperature-dependent metal resistance."""
    r0 = np.asarray(net.seg_r, dtype=float).copy()
    arr = net.arrays()
    xs, ys = arr["x"], arr["y"]
    mid_x = 0.5 * (xs[arr["a"]] + xs[arr["b"]])
    mid_y = 0.5 * (ys[arr["a"]] + ys[arr["b"]])
    x0, y0, x1, y1 = extent
    T_seg = np.full(r0.size, t_ref_c)
    history = []
    sol: Optional[DCSolution] = None
    T = np.full((prm.nx, prm.ny), prm.t_ambient_c)
    converged = False
    for it in range(1, max_iter + 1):
        net.set_resistances(r0 * (1.0 + tcr_per_k * (T_seg - t_ref_c)))
        sol = solve(net, opts)
        # heat sources: load power at the VDD attach point + I^2R of every segment at its midpoint
        lp = sol.load_current * sol.load_v_eff
        lx = np.array([xs[net.node_index(l.vdd_node)] for l in net.loads])
        ly = np.array([ys[net.node_index(l.vdd_node)] for l in net.loads])
        sp = sol.segment_power()
        ok = np.isfinite(mid_x) & np.isfinite(sp)
        pm = power_map(np.concatenate([lx, mid_x[ok]]), np.concatenate([ly, mid_y[ok]]),
                       np.concatenate([lp, sp[ok]]), extent, prm.nx, prm.ny)
        T_new, info = solve_die_temperature(pm, x1 - x0, y1 - y0, prm)
        dT = float(np.max(np.abs(T_new - T)))
        T = T + relax * (T_new - T) if it > 1 else T_new
        ix = np.clip(((mid_x - x0) / (x1 - x0) * prm.nx).astype(int), 0, prm.nx - 1)
        iy = np.clip(((mid_y - y0) / (y1 - y0) * prm.ny).astype(int), 0, prm.ny - 1)
        T_seg = np.where(np.isfinite(mid_x), T[ix, iy], t_ref_c)
        worst = float(np.min(sol.load_v_eff)) if net.loads else math.nan
        history.append({"iteration": it, "max_dT_c": dT, "t_max_c": float(T.max()), "worst_v_eff": worst})
        if it > 1 and dT < tol_c:
            converged = True
            break
    net.set_resistances(r0)
    return {"converged": converged, "iterations": len(history), "history": history, "temperature_map_c": T,
            "final_solution": sol, "tcr_per_k": tcr_per_k, "t_ref_c": t_ref_c}


def import_temperature_map(path: str | Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """CSV with x_um,y_um,t_c (e.g. exported by TwinLab or a thermal tool)."""
    xs, ys, ts = [], [], []
    with open(path) as fh:
        for row in csv.DictReader(fh):
            xs.append(float(row["x_um"]) * 1e-6); ys.append(float(row["y_um"]) * 1e-6); ts.append(float(row["t_c"]))
    return np.array(xs), np.array(ys), np.array(ts)
