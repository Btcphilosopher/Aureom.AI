"""TimingFlow / TimingLab coupling: overlap of IR drop with critical timing paths.

Inputs are real OpenSTA path reports (``report_checks``) produced by the
FloorplanLab / TimingLab flows.  For each reported path the start- and
end-point instances are mapped to their solved local effective supply.

No millivolt-to-picosecond conversion is performed: there is no
voltage-aware timing library for the analysed corner in the toolchain (the
ORFS ab2aaf0f IHP platform ships only the typ 1.20 V std-cell Liberty), so
droop is reported as an *electrical risk*, never as a delay penalty.
A voltage-aware STA becomes possible once multi-voltage Liberty corners are
installed (see :func:`voltage_aware_sta_status`).
"""
from __future__ import annotations

import glob
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

__all__ = ["parse_report_checks", "group_of", "risk_table", "voltage_aware_sta_status"]


@dataclass
class TimingPath:
    startpoint: str
    endpoint: str
    slack_ns: float
    status: str
    group: Optional[str]
    clock_period_ns: Optional[float] = None


def _inst(pin: str) -> str:
    # 'u_cpu/_123_/Q' -> 'u_cpu/_123_' ; ports stay as they are
    pin = pin.split(" ")[0]
    return pin.rsplit("/", 1)[0] if "/" in pin else pin


def parse_report_checks(path: str | Path) -> list[TimingPath]:
    text = Path(path).read_text(errors="replace")
    paths = []
    for block in re.split(r"\n(?=Startpoint:)", text):
        ms = re.search(r"Startpoint:\s*(\S+)", block)
        me = re.search(r"Endpoint:\s*(\S+)", block)
        sl = re.search(r"([-+]?\d+\.\d+)\s+slack\s+\((\w+)\)", block)
        if not (ms and me and sl):
            continue
        pg = re.search(r"Path Group:\s*(\S+)", block)
        paths.append(TimingPath(ms.group(1).replace("\\", ""), me.group(1).replace("\\", ""), float(sl.group(1)),
                                sl.group(2), pg.group(1) if pg else None))
    return paths


def group_of(inst: str, groups: list[dict[str, Any]]) -> str:
    name = inst.replace("\\", "")
    for g in groups:
        if any(name.startswith(m) for m in g["match"]):
            return g["name"]
    return "top"


def risk_table(paths: list[TimingPath], inst_veff: dict[str, float], groups: list[dict[str, Any]],
               v_nom: float, group_stats: dict[str, dict[str, Any]], slack_margin_ns: float = 1.0,
               loss_flag_mv: float = 10.0) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    def lookup(tok: str) -> tuple[str, Optional[float]]:
        tok = tok.replace("\\", "")
        if tok in inst_veff:                 # register start/end points are reported as instances
            return tok, inst_veff[tok]
        inst = _inst(tok)                    # otherwise strip the pin name
        return inst, inst_veff.get(inst)

    for p in paths:
        si, vs = lookup(p.startpoint)
        ei, ve = lookup(p.endpoint)
        vmin = min([v for v in (vs, ve) if v is not None], default=None)
        loss = None if vmin is None else (v_nom - vmin) * 1e3
        g = group_of(ei, groups)
        gs = group_stats.get(g, {})
        flags = []
        if p.slack_ns < slack_margin_ns:
            flags.append("critical_timing")
        if loss is not None and loss >= loss_flag_mv:
            flags.append("large_ir_drop")
        if gs.get("power_density_rank") is not None and gs["power_density_rank"] <= 3:
            flags.append("high_activity_group")
        rows.append({"startpoint": p.startpoint, "endpoint": p.endpoint, "slack_ns": p.slack_ns, "status": p.status,
                     "group": g, "v_eff_start": vs, "v_eff_end": ve, "supply_loss_mv": loss, "flags": flags,
                     "risk_score": len(flags), "timing_effect": "NOT CONVERTED (no voltage-aware Liberty)"})
    rows.sort(key=lambda r: (-r["risk_score"], r["slack_ns"]))
    return rows


def voltage_aware_sta_status(platform_lib_dir: str) -> dict[str, Any]:
    libs = sorted(glob.glob(str(Path(platform_lib_dir) / "*.lib")))
    corners = [Path(l).name for l in libs]
    multi = [c for c in corners if re.search(r"(slow|ss)_", c)]
    return {"std_cell_libs": corners, "low_voltage_corners": multi,
            "status": "AVAILABLE" if multi else "BLOCKED",
            "reason": None if multi else "only the typical-voltage std-cell Liberty is installed; a voltage-aware "
                                          "STA (or delay derating) needs characterised low-voltage corners"}
