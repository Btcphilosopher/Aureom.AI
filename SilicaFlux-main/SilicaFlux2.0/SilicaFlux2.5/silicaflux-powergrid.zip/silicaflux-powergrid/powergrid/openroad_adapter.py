"""OpenROAD power-integrity adapter.

Runs the PowerGrid Tcl scripts (tcl/*.tcl) with the pinned OpenROAD build,
captures stdout/stderr, exit status, timing and tool version, parses the
machine-readable ``PG-*`` lines and PDNSim result files, and stores everything
as evidence in a run directory with SHA-256 hashes of every input.

A step is only ever reported as successful when OpenROAD exited with status 0,
the Tcl command returned without error and the expected output files exist.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parents[1]
TCL = ROOT / "tcl"

DEFAULT_OPENROAD = os.environ.get("OPENROAD_EXE", "/opt/eda/env/bin/openroad")

__all__ = ["ToolchainError", "DesignInputs", "StepResult", "OpenROAD", "parse_pdnsim_voltage", "parse_pdnsim_em",
           "parse_pdnsim_spice", "write_vsrc"]


class ToolchainError(RuntimeError):
    pass


@dataclass
class DesignInputs:
    """Physical design inputs; every path must exist (checked by validate())."""

    name: str
    odb: str
    tech_lef: str
    lefs: list[str]
    libs: list[str]
    sdc: Optional[str] = None
    setrc: Optional[str] = None
    pdn_tcl: Optional[str] = None
    power_net: str = "VDD"
    ground_net: str = "VSS"
    provenance: str = ""

    def validate(self) -> list[str]:
        missing = []
        for p in [self.odb, self.tech_lef, *self.lefs, *self.libs] + ([self.sdc] if self.sdc else []) + \
                 ([self.setrc] if self.setrc else []):
            if not Path(p).is_file():
                missing.append(p)
        return missing

    def env(self) -> dict[str, str]:
        return {
            "PG_ODB": self.odb, "PG_TECH_LEF": self.tech_lef, "PG_LEFS": " ".join(self.lefs),
            "PG_LIBS": " ".join(self.libs), "PG_SDC": self.sdc or "", "PG_SETRC": self.setrc or "",
            "PG_NETS": f"{self.power_net} {self.ground_net}",
        }

    def hashes(self) -> dict[str, str]:
        out = {}
        for p in [self.odb, self.tech_lef, *self.lefs, *self.libs] + ([self.sdc] if self.sdc else []):
            out[p] = sha256(p)
        return out


def sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class StepResult:
    step: str
    command: list[str]
    returncode: int
    seconds: float
    log: str
    records: list[dict[str, Any]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.errors

    def as_dict(self) -> dict[str, Any]:
        return {"step": self.step, "command": self.command, "returncode": self.returncode, "ok": self.ok,
                "seconds": round(self.seconds, 3), "log": self.log, "records": self.records,
                "errors": self.errors[:50], "warnings_count": len(self.warnings), "warnings_head": self.warnings[:20]}


class OpenROAD:
    def __init__(self, exe: str = DEFAULT_OPENROAD) -> None:
        self.exe = exe

    def available(self) -> bool:
        return Path(self.exe).is_file() and os.access(self.exe, os.X_OK)

    def version(self) -> str:
        if not self.available():
            raise ToolchainError(f"OpenROAD not found at {self.exe} (run env/install_toolchain.sh)")
        out = subprocess.run([self.exe, "-version"], capture_output=True, text=True, timeout=60)
        return out.stdout.strip().splitlines()[0] if out.stdout.strip() else "unknown"

    def run(self, script: str, env: dict[str, str], log_path: Path, step: str, timeout: int = 6 * 3600) -> StepResult:
        if not self.available():
            raise ToolchainError(f"OpenROAD not found at {self.exe} (run env/install_toolchain.sh)")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        cmd = [self.exe, "-no_init", "-exit", str(TCL / script)]
        e = dict(os.environ)
        e.update(env)
        e["PG_TCL_DIR"] = str(TCL)
        t0 = time.perf_counter()
        proc = subprocess.run(cmd, capture_output=True, text=True, env=e, timeout=timeout)
        dt = time.perf_counter() - t0
        text = proc.stdout + ("\n--- stderr ---\n" + proc.stderr if proc.stderr else "")
        log_path.write_text(text)
        res = StepResult(step=step, command=cmd, returncode=proc.returncode, seconds=dt, log=str(log_path))
        for line in text.splitlines():
            m = re.match(r"^(PG-[A-Z-]+)\s+(\{.*\})\s*$", line)
            if m:
                try:
                    rec = json.loads(m.group(2))
                except json.JSONDecodeError:
                    rec = {"raw": m.group(2)}
                rec["_tag"] = m.group(1)
                res.records.append(rec)
            if line.startswith("PG-ERROR") or re.match(r"^\[ERROR", line) or line.startswith("Error:"):
                res.errors.append(line)
            if re.match(r"^\[WARNING", line):
                res.warnings.append(line)
        for rec in res.records:
            if rec.get("tcl_rc") not in (None, 0):
                res.errors.append(f"{rec['_tag']} returned Tcl error: {rec.get('result')}")
        return res


# ----------------------------------------------------------------------------- PDNSim files
def write_vsrc(path: Path, sources: list[tuple[float, float, float, float]]) -> None:
    """PDNSim 6011bbe77 vsrc format: one line per source 'x_um, y_um, size_um, voltage'."""
    with open(path, "w") as fh:
        for x, y, size, v in sources:
            fh.write(f"{x:.4f}, {y:.4f}, {size:.4f}, {v:.6f}\n")


def parse_pdnsim_voltage(path: str | Path) -> dict[str, tuple[float, float, float]]:
    """'Instance name, X location, Y location, Voltage' -> {inst: (x_um, y_um, V)}."""
    out: dict[str, tuple[float, float, float]] = {}
    with open(path) as fh:
        header = fh.readline()
        if "Instance" not in header:
            raise ValueError(f"unexpected PDNSim voltage file header: {header!r}")
        for line in fh:
            line = line.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.rsplit(",", 3)]
            out[parts[0]] = (float(parts[1]), float(parts[2]), float(parts[3]))
    return out


def parse_pdnsim_em(path: str | Path) -> list[dict[str, Any]]:
    rows = []
    with open(path) as fh:
        reader = csv.reader(fh)
        header = next(reader, None)
        for r in reader:
            if r:
                rows.append({"raw": [c.strip() for c in r]})
    return rows


def parse_pdnsim_spice(path: str | Path) -> dict[str, Any]:
    """Parse write_pg_spice output: resistors, voltage sources, current sources (as written)."""
    R: list[tuple[str, str, float]] = []
    V: list[tuple[str, float]] = []
    I: list[tuple[str, float]] = []
    names_I: dict[str, int] = {}
    with open(path) as fh:
        for line in fh:
            t = line.split()
            if not t or t[0].startswith("."):
                continue
            if t[0].startswith("R"):
                R.append((t[1], t[2], float(t[3])))
            elif t[0].startswith("V"):
                V.append((t[1], float(t[3])))
            elif t[0].startswith("I"):
                I.append((t[1], float(t[3])))
                names_I[t[1]] = names_I.get(t[1], 0) + 1
    dup = {k: c for k, c in names_I.items() if c > 1}
    return {"resistors": R, "vsources": V, "isources": I, "isource_nodes_duplicated": len(dup),
            "isource_duplicate_examples": list(dup.items())[:5]}


def copy_evidence(files: list[Path], dest: Path) -> list[str]:
    dest.mkdir(parents=True, exist_ok=True)
    out = []
    for f in files:
        if f.exists():
            shutil.copy2(f, dest / f.name)
            out.append(str(dest / f.name))
    return out


def parse_grt_overflow(log_text: str) -> dict[str, Any]:
    """Total resource / demand / overflow from the FastRoute final congestion table."""
    import re as _re
    rows = {}
    final = log_text.split("Final congestion report")[-1] if "Final congestion report" in log_text else log_text
    for line in final.splitlines():
        m = _re.match(r"^(Metal\w*|TopMetal\w*|Total)\s+(\d+)\s+(\d+)\s+([\d.]+)%\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)", line.strip())
        if m:
            rows[m.group(1)] = {"resource": int(m.group(2)), "demand": int(m.group(3)), "usage_pct": float(m.group(4)),
                                "overflow_h": int(m.group(5)), "overflow_v": int(m.group(6)), "overflow_total": int(m.group(7))}
    return rows
