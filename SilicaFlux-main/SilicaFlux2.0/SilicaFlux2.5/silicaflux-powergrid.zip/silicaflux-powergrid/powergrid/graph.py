"""Electrical network model: nodes, resistive segments, sources, loads.

The model is a purely resistive DC network.  Storage is columnar (parallel
Python lists converted to NumPy arrays on demand) so that extracted physical
PDNs with ~10^6 segments remain tractable.

Sign conventions
----------------
* Node voltages are absolute, in volts, referenced to the global 0 V of the
  ideal supply sources.
* A :class:`CurrentInjection` of ``+I`` pushes ``I`` amperes INTO its node.
* A load draws its current OUT of its VDD node and returns it INTO its VSS
  node (``vss_node is None`` means the return is an ideal 0 V reference; this
  is flagged in every result that uses it).
* A segment current is positive when it flows from endpoint ``a`` to ``b``.
* A source current is positive when it flows OUT of the source INTO the
  network (a VDD source delivering current is positive, a VSS source sinking
  the return current is negative).

Physical rules enforced on construction / validation
----------------------------------------------------
* resistance must be finite and >= 0; negative or NaN is rejected;
  exactly 0 marks an ideal short (handled by node merging in the solver).
* a segment may only join two nodes of the same net -- nets are never
  connected implicitly; separate domains stay separate.
* a load's VDD node must belong to a POWER net and its VSS node to a GROUND
  net, and both must belong to the load's declared voltage domain.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable, Iterator, Optional

import numpy as np

from .provenance import DataSource

__all__ = [
    "NetworkError",
    "NetType",
    "SegmentKind",
    "Net",
    "Domain",
    "VoltageSource",
    "Load",
    "LoadModel",
    "CurrentInjection",
    "SegmentView",
    "Network",
]


class NetworkError(ValueError):
    """Invalid network construction (bad resistance, cross-net segment, ...)."""


class NetType(str, Enum):
    POWER = "POWER"
    GROUND = "GROUND"


class SegmentKind(str, Enum):
    METAL = "metal"            # wire segment on a routing layer
    VIA = "via"                # one via (array) between adjacent layers
    CONTACT = "contact"        # contact / macro-pin / cell-pin attachment
    SOURCE = "source"          # supply source series resistance (package, bond wire, bump)
    RESISTOR = "resistor"      # generic lumped resistor (analytical tests)


class LoadModel(str, Enum):
    FIXED_CURRENT = "fixed_current"
    FIXED_POWER = "fixed_power"


@dataclass(frozen=True)
class Net:
    name: str
    type: NetType
    nominal_voltage_v: float


@dataclass(frozen=True)
class Domain:
    """A voltage domain = one power net + one ground net, explicitly paired."""

    name: str
    power_net: str
    ground_net: str


@dataclass
class VoltageSource:
    """Ideal voltage ``voltage_v`` behind ``series_resistance_ohm`` at ``node``.

    ``series_resistance_ohm == 0`` fixes the node voltage directly (Dirichlet
    boundary condition).  A positive value models package / bond-wire / bump
    resistance: an internal ideal node is created and joined to ``node``.
    """

    name: str
    node: str
    voltage_v: float
    series_resistance_ohm: float = 0.0
    kind: str = "ideal"        # ideal | wirebond_pad | bump | package_contact | explicit
    provenance: str = DataSource.ASSUMED.value
    x_m: Optional[float] = None
    y_m: Optional[float] = None
    # guard against attaching a source of another domain; disable only for
    # generic circuits (e.g. a divider closed by a 0 V source on the same net)
    check_nominal: bool = True


@dataclass
class Load:
    name: str
    vdd_node: str
    vss_node: Optional[str]
    model: LoadModel = LoadModel.FIXED_CURRENT
    current_a: Optional[float] = None
    power_w: Optional[float] = None
    domain: Optional[str] = None
    block: Optional[str] = None
    provenance: str = DataSource.ASSUMED.value
    # for fixed-power loads converted at a stated voltage: which one
    conversion_voltage: str = "local"       # 'local' (iterative) or 'nominal'

    def __post_init__(self) -> None:
        if self.model is LoadModel.FIXED_CURRENT:
            if self.current_a is None or not math.isfinite(self.current_a):
                raise NetworkError(f"load {self.name}: fixed-current load needs a finite current")
            if self.current_a < 0:
                raise NetworkError(
                    f"load {self.name}: negative load current {self.current_a} A; use a "
                    "CurrentInjection for a current source"
                )
        else:
            if self.power_w is None or not math.isfinite(self.power_w) or self.power_w < 0:
                raise NetworkError(f"load {self.name}: fixed-power load needs a finite power >= 0")


@dataclass
class CurrentInjection:
    """Independent current source: ``current_a`` (A) into ``node`` (may be < 0)."""

    name: str
    node: str
    current_a: float
    provenance: str = DataSource.ASSUMED.value


@dataclass
class SegmentView:
    index: int
    a: str
    b: str
    resistance_ohm: float
    kind: SegmentKind
    layer: Optional[str]
    length_m: Optional[float]
    width_m: Optional[float]
    thickness_m: Optional[float]
    via_cuts: Optional[int]
    current_limit_a: Optional[float]
    provenance: str


class Network:
    """Columnar resistive network with explicit nets and domains."""

    def __init__(self, name: str = "network") -> None:
        self.name = name
        self.nets: dict[str, Net] = {}
        self.domains: dict[str, Domain] = {}
        # nodes
        self._node_index: dict[str, int] = {}
        self.node_ids: list[str] = []
        self.node_net: list[str] = []
        self.node_layer: list[Optional[str]] = []
        self.node_x: list[float] = []
        self.node_y: list[float] = []
        # segments (columnar)
        self.seg_a: list[int] = []
        self.seg_b: list[int] = []
        self.seg_r: list[float] = []
        self.seg_kind: list[SegmentKind] = []
        self.seg_layer: list[Optional[str]] = []
        self.seg_length: list[float] = []
        self.seg_width: list[float] = []
        self.seg_thickness: list[float] = []
        self.seg_cuts: list[int] = []
        self.seg_ilimit: list[float] = []
        self.seg_prov: list[str] = []
        # elements
        self.sources: list[VoltageSource] = []
        self.loads: list[Load] = []
        self.injections: list[CurrentInjection] = []
        self.metadata: dict[str, object] = {}
        self._load_names: set[str] = set()
        self._source_names: set[str] = set()

    # ------------------------------------------------------------------ nets
    def add_net(self, name: str, type: NetType | str, nominal_voltage_v: float) -> Net:
        t = NetType(type)
        if name in self.nets:
            raise NetworkError(f"net {name!r} defined twice")
        if not math.isfinite(nominal_voltage_v):
            raise NetworkError(f"net {name!r}: non-finite nominal voltage")
        net = Net(name, t, float(nominal_voltage_v))
        self.nets[name] = net
        return net

    def add_domain(self, name: str, power_net: str, ground_net: str) -> Domain:
        if power_net not in self.nets or self.nets[power_net].type is not NetType.POWER:
            raise NetworkError(f"domain {name}: {power_net!r} is not a defined POWER net")
        if ground_net not in self.nets or self.nets[ground_net].type is not NetType.GROUND:
            raise NetworkError(f"domain {name}: {ground_net!r} is not a defined GROUND net")
        for d in self.domains.values():
            if d.power_net == power_net and d.name != name:
                raise NetworkError(
                    f"power net {power_net!r} already belongs to domain {d.name!r}; "
                    "a net may belong to one domain only"
                )
        dom = Domain(name, power_net, ground_net)
        self.domains[name] = dom
        return dom

    # ------------------------------------------------------------------ nodes
    def add_node(
        self,
        node_id: str,
        net: str,
        layer: Optional[str] = None,
        x_m: float = math.nan,
        y_m: float = math.nan,
    ) -> int:
        if net not in self.nets:
            raise NetworkError(f"node {node_id!r}: net {net!r} is not defined")
        idx = self._node_index.get(node_id)
        if idx is not None:
            if self.node_net[idx] != net:
                raise NetworkError(
                    f"node {node_id!r} redefined on net {net!r} (was {self.node_net[idx]!r})"
                )
            return idx
        idx = len(self.node_ids)
        self._node_index[node_id] = idx
        self.node_ids.append(node_id)
        self.node_net.append(net)
        self.node_layer.append(layer)
        self.node_x.append(float(x_m))
        self.node_y.append(float(y_m))
        return idx

    def has_node(self, node_id: str) -> bool:
        return node_id in self._node_index

    def node_index(self, node_id: str) -> int:
        try:
            return self._node_index[node_id]
        except KeyError:
            raise NetworkError(f"unknown node {node_id!r}") from None

    @property
    def n_nodes(self) -> int:
        return len(self.node_ids)

    @property
    def n_segments(self) -> int:
        return len(self.seg_a)

    # ------------------------------------------------------------------ segments
    def add_segment(
        self,
        a: str,
        b: str,
        resistance_ohm: float,
        *,
        kind: SegmentKind | str = SegmentKind.RESISTOR,
        layer: Optional[str] = None,
        length_m: Optional[float] = None,
        width_m: Optional[float] = None,
        thickness_m: Optional[float] = None,
        via_cuts: Optional[int] = None,
        current_limit_a: Optional[float] = None,
        provenance: str = DataSource.ASSUMED.value,
    ) -> int:
        r = float(resistance_ohm)
        if math.isnan(r) or math.isinf(r):
            raise NetworkError(f"segment {a}-{b}: resistance {resistance_ohm!r} is not finite")
        if r < 0:
            raise NetworkError(f"segment {a}-{b}: negative resistance {r} ohm rejected")
        ia, ib = self.node_index(a), self.node_index(b)
        if ia == ib:
            raise NetworkError(f"segment {a}-{b}: both ends are the same node")
        if self.node_net[ia] != self.node_net[ib]:
            raise NetworkError(
                f"segment {a}-{b} joins net {self.node_net[ia]!r} to net {self.node_net[ib]!r}; "
                "nets are never connected implicitly"
            )
        for name, val in (("length", length_m), ("width", width_m), ("thickness", thickness_m)):
            if val is not None and (not math.isfinite(val) or val <= 0):
                raise NetworkError(f"segment {a}-{b}: invalid {name} {val!r}")
        if via_cuts is not None and via_cuts < 1:
            raise NetworkError(f"segment {a}-{b}: via cut count must be >= 1")
        self.seg_a.append(ia)
        self.seg_b.append(ib)
        self.seg_r.append(r)
        self.seg_kind.append(SegmentKind(kind))
        self.seg_layer.append(layer)
        self.seg_length.append(math.nan if length_m is None else float(length_m))
        self.seg_width.append(math.nan if width_m is None else float(width_m))
        self.seg_thickness.append(math.nan if thickness_m is None else float(thickness_m))
        self.seg_cuts.append(0 if via_cuts is None else int(via_cuts))
        self.seg_ilimit.append(math.nan if current_limit_a is None else float(current_limit_a))
        self.seg_prov.append(provenance)
        return len(self.seg_a) - 1

    def add_metal_segment(
        self,
        a: str,
        b: str,
        *,
        layer: str,
        length_m: float,
        width_m: float,
        sheet_resistance_ohm_sq: float,
        thickness_m: Optional[float] = None,
        provenance: str = DataSource.PDK.value,
        current_limit_a: Optional[float] = None,
    ) -> int:
        """Metal wire: R = Rs * L / W (Rs from the technology; never bulk rho)."""
        if sheet_resistance_ohm_sq <= 0 or not math.isfinite(sheet_resistance_ohm_sq):
            raise NetworkError(f"layer {layer}: invalid sheet resistance {sheet_resistance_ohm_sq}")
        if length_m <= 0 or width_m <= 0:
            raise NetworkError(f"metal segment {a}-{b}: length and width must be > 0")
        r = sheet_resistance_ohm_sq * length_m / width_m
        return self.add_segment(
            a, b, r, kind=SegmentKind.METAL, layer=layer, length_m=length_m, width_m=width_m,
            thickness_m=thickness_m, provenance=provenance, current_limit_a=current_limit_a,
        )

    def add_via(
        self,
        a: str,
        b: str,
        *,
        layer: str,
        resistance_per_cut_ohm: float,
        cuts: int,
        provenance: str = DataSource.PDK.value,
        current_limit_a: Optional[float] = None,
    ) -> int:
        """Via array: ``cuts`` parallel cuts, R = R_cut / cuts (lumped).

        The lumped model cannot represent unequal sharing between cuts; use
        :func:`powergrid.current_density.resolve_via_array` to quantify it.
        """
        if cuts < 1:
            raise NetworkError(f"via {a}-{b}: cuts must be >= 1")
        if resistance_per_cut_ohm < 0 or not math.isfinite(resistance_per_cut_ohm):
            raise NetworkError(f"via {a}-{b}: invalid cut resistance {resistance_per_cut_ohm}")
        return self.add_segment(
            a, b, resistance_per_cut_ohm / cuts, kind=SegmentKind.VIA, layer=layer, via_cuts=cuts,
            provenance=provenance, current_limit_a=current_limit_a,
        )

    def add_nodes_bulk(self, ids: list[str], net: str, layer: Optional[str], x_m: np.ndarray, y_m: np.ndarray) -> np.ndarray:
        """Add many nodes of one net/layer; returns their indices (existing ids are reused)."""
        if net not in self.nets:
            raise NetworkError(f"net {net!r} is not defined")
        out = np.empty(len(ids), dtype=np.int64)
        for k, nid in enumerate(ids):
            idx = self._node_index.get(nid)
            if idx is None:
                idx = len(self.node_ids)
                self._node_index[nid] = idx
                self.node_ids.append(nid)
                self.node_net.append(net)
                self.node_layer.append(layer)
                self.node_x.append(float(x_m[k]))
                self.node_y.append(float(y_m[k]))
            elif self.node_net[idx] != net:
                raise NetworkError(f"node {nid!r} redefined on net {net!r}")
            out[k] = idx
        return out

    def add_segments_bulk(
        self,
        a: np.ndarray,
        b: np.ndarray,
        r: np.ndarray,
        *,
        kind: SegmentKind,
        layer: Optional[str],
        length_m: Optional[np.ndarray] = None,
        width_m: Optional[np.ndarray] = None,
        thickness_m: Optional[float] = None,
        via_cuts: Optional[np.ndarray] = None,
        current_limit_a: Optional[np.ndarray] = None,
        provenance: str = DataSource.TOOL_EXTRACTED.value,
    ) -> None:
        """Vectorised segment insertion with the same validation as add_segment."""
        a = np.asarray(a, dtype=np.int64); b = np.asarray(b, dtype=np.int64); r = np.asarray(r, dtype=float)
        n = a.size
        if b.size != n or r.size != n:
            raise NetworkError("bulk segment arrays differ in length")
        if n == 0:
            return
        if not np.all(np.isfinite(r)) or np.any(r < 0):
            raise NetworkError(f"bulk segments on {layer}: negative or non-finite resistance")
        if np.any(a == b):
            raise NetworkError(f"bulk segments on {layer}: self-loop")
        nn = self.node_net
        if any(nn[x] != nn[y] for x, y in zip(a.tolist(), b.tolist())):
            raise NetworkError(f"bulk segments on {layer}: segment joins two nets")
        nan = np.full(n, math.nan)
        self.seg_a.extend(a.tolist()); self.seg_b.extend(b.tolist()); self.seg_r.extend(r.tolist())
        self.seg_kind.extend([SegmentKind(kind)] * n)
        self.seg_layer.extend([layer] * n)
        self.seg_length.extend((nan if length_m is None else np.asarray(length_m, float)).tolist())
        self.seg_width.extend((nan if width_m is None else np.asarray(width_m, float)).tolist())
        self.seg_thickness.extend([math.nan if thickness_m is None else float(thickness_m)] * n)
        self.seg_cuts.extend((np.zeros(n, np.int64) if via_cuts is None else np.asarray(via_cuts, np.int64)).tolist())
        self.seg_ilimit.extend((nan if current_limit_a is None else np.asarray(current_limit_a, float)).tolist())
        self.seg_prov.extend([provenance] * n)

    def segment(self, i: int) -> SegmentView:
        return SegmentView(
            index=i,
            a=self.node_ids[self.seg_a[i]],
            b=self.node_ids[self.seg_b[i]],
            resistance_ohm=self.seg_r[i],
            kind=self.seg_kind[i],
            layer=self.seg_layer[i],
            length_m=None if math.isnan(self.seg_length[i]) else self.seg_length[i],
            width_m=None if math.isnan(self.seg_width[i]) else self.seg_width[i],
            thickness_m=None if math.isnan(self.seg_thickness[i]) else self.seg_thickness[i],
            via_cuts=self.seg_cuts[i] or None,
            current_limit_a=None if math.isnan(self.seg_ilimit[i]) else self.seg_ilimit[i],
            provenance=self.seg_prov[i],
        )

    def segments(self) -> Iterator[SegmentView]:
        for i in range(self.n_segments):
            yield self.segment(i)

    def set_resistances(self, r: np.ndarray) -> None:
        """Replace all segment resistances (e.g. temperature update)."""
        r = np.asarray(r, dtype=float)
        if r.shape != (self.n_segments,):
            raise NetworkError("resistance vector has the wrong length")
        if not np.all(np.isfinite(r)) or np.any(r < 0):
            raise NetworkError("resistance update contains negative or non-finite values")
        self.seg_r = [float(v) for v in r]

    # ------------------------------------------------------------------ elements
    def add_source(self, src: VoltageSource) -> VoltageSource:
        idx = self.node_index(src.node)
        net = self.nets[self.node_net[idx]]
        if not math.isfinite(src.voltage_v):
            raise NetworkError(f"source {src.name}: non-finite voltage")
        if src.series_resistance_ohm < 0 or not math.isfinite(src.series_resistance_ohm):
            raise NetworkError(f"source {src.name}: invalid series resistance")
        if src.name in self._source_names:
            raise NetworkError(f"source name {src.name!r} used twice")
        if src.check_nominal and abs(src.voltage_v - net.nominal_voltage_v) > 0.5 * max(abs(net.nominal_voltage_v), 0.1) + 1e-12:
            raise NetworkError(
                f"source {src.name}: {src.voltage_v} V on net {net.name} (nominal "
                f"{net.nominal_voltage_v} V) -- a source of another domain attached to this net?"
            )
        self.sources.append(src)
        self._source_names.add(src.name)
        return src

    def add_load(self, load: Load) -> Load:
        ip = self.node_index(load.vdd_node)
        pnet = self.nets[self.node_net[ip]]
        if pnet.type is not NetType.POWER:
            raise NetworkError(f"load {load.name}: VDD node {load.vdd_node} is on non-power net {pnet.name}")
        if load.vss_node is not None:
            ig = self.node_index(load.vss_node)
            gnet = self.nets[self.node_net[ig]]
            if gnet.type is not NetType.GROUND:
                raise NetworkError(f"load {load.name}: VSS node {load.vss_node} is on non-ground net {gnet.name}")
            if self.domains:
                dom = self.domains.get(load.domain or "")
                if dom is None:
                    raise NetworkError(
                        f"load {load.name}: network defines domains {sorted(self.domains)} but the "
                        f"load names domain {load.domain!r}"
                    )
                if dom.power_net != pnet.name or dom.ground_net != gnet.name:
                    raise NetworkError(
                        f"load {load.name}: nodes on {pnet.name}/{gnet.name} do not match domain "
                        f"{dom.name} ({dom.power_net}/{dom.ground_net})"
                    )
        if load.name in self._load_names:
            raise NetworkError(f"load name {load.name!r} used twice")
        self.loads.append(load)
        self._load_names.add(load.name)
        return load

    def add_injection(self, inj: CurrentInjection) -> CurrentInjection:
        self.node_index(inj.node)
        if not math.isfinite(inj.current_a):
            raise NetworkError(f"injection {inj.name}: non-finite current")
        self.injections.append(inj)
        return inj

    # ------------------------------------------------------------------ arrays
    def arrays(self) -> dict[str, np.ndarray]:
        return {
            "a": np.asarray(self.seg_a, dtype=np.int64),
            "b": np.asarray(self.seg_b, dtype=np.int64),
            "r": np.asarray(self.seg_r, dtype=float),
            "length": np.asarray(self.seg_length, dtype=float),
            "width": np.asarray(self.seg_width, dtype=float),
            "thickness": np.asarray(self.seg_thickness, dtype=float),
            "cuts": np.asarray(self.seg_cuts, dtype=np.int64),
            "ilimit": np.asarray(self.seg_ilimit, dtype=float),
            "x": np.asarray(self.node_x, dtype=float),
            "y": np.asarray(self.node_y, dtype=float),
        }

    def nodes_of_net(self, net: str) -> np.ndarray:
        return np.array([i for i, n in enumerate(self.node_net) if n == net], dtype=np.int64)

    def summary(self) -> dict[str, object]:
        kinds: dict[str, int] = {}
        for k in self.seg_kind:
            kinds[k.value] = kinds.get(k.value, 0) + 1
        layers: dict[str, int] = {}
        for lyr in self.seg_layer:
            if lyr is not None:
                layers[lyr] = layers.get(lyr, 0) + 1
        return {
            "name": self.name,
            "nets": {n: {"type": v.type.value, "nominal_v": v.nominal_voltage_v} for n, v in self.nets.items()},
            "domains": {d: {"power": v.power_net, "ground": v.ground_net} for d, v in self.domains.items()},
            "nodes": self.n_nodes,
            "segments": self.n_segments,
            "segments_by_kind": kinds,
            "segments_by_layer": layers,
            "sources": len(self.sources),
            "loads": len(self.loads),
            "injections": len(self.injections),
        }


def total_load_current(loads: Iterable[Load]) -> float:
    return sum(l.current_a or 0.0 for l in loads if l.model is LoadModel.FIXED_CURRENT)
