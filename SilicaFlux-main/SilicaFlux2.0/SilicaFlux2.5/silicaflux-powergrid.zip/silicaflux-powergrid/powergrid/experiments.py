"""SilicaFlux-V demonstration experiments (brief section 23, A-J), TestCore power
modes and the transient droop study.

Fidelity labels
---------------
* Geometry, PDN, resistances, placement: ACTUAL EDA RESULT (FloorplanLab
  A_baseline database exported in the analysis run; IHP tech-LEF data).
* Loads: the OpenSTA vectorless per-instance power (MODELLED) and workload
  scenarios derived from it with explicit ASSUMED multipliers -> every
  workload result is DEMONSTRATION fidelity, never measured SilicaFlux power.
* Supply taps, source resistance, thermal parameters, temperature
  coefficient, RLC parasitics: ASSUMED (no package or PDK data exists).
"""
from __future__ import annotations

import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional

import numpy as np

from .config import DesignConfig, load_yaml, resolve_path
from .current_density import resolve_via_array
from .flows import _jsonable, _summary, provenance_header, tap_specs, write_csv
from .optimise import synthetic_sweep
from .pdn_import import ImportOptions, SourceSpec, build_network, read_export
from .solver import solve
from .technology import load_profile
from .thermal import ThermalParams, electrothermal
from .timing import group_of
from .transient import RLCParams, load_step, ngspice_crosscheck, simulate, step_metrics
from .units import parse_quantity
from .visualise import save_maps

__all__ = ["workload_power", "run_experiments", "run_transient", "testcore_modes"]


def workload_power(exp: Any, groups: list[dict[str, Any]], spec: dict[str, Any], ref_group: str) -> tuple[dict[str, float], dict[str, Any]]:
    """Per-instance power for a workload: vectorless baseline with ASSUMED rules per group.

    rules: {group: {scale_vectorless: k}}  -> P_inst = k * P_vectorless(inst)
           {group: {ref_multiple: k}}      -> P_inst = k * mean vectorless power per instance of ref_group
    'sram_macros' addresses the BLOCK instances.
    """
    gi: dict[str, list[str]] = defaultdict(list)
    for name, d in exp.insts.items():
        gi["sram_macros" if d["type"] == "BLOCK" else group_of(name, groups)].append(name)
    ref = gi.get(ref_group, [])
    p_ref = (sum(exp.power_w.get(n, 0.0) for n in ref) / len(ref)) if ref else 0.0
    out = dict(exp.power_w)
    applied = {}
    for g, rule in (spec or {}).items():
        members = gi.get(g, [])
        if "scale_vectorless" in rule:
            k = float(rule["scale_vectorless"])
            for n in members:
                out[n] = exp.power_w.get(n, 0.0) * k
        elif "ref_multiple" in rule:
            k = float(rule["ref_multiple"])
            for n in members:
                out[n] = p_ref * k
        applied[g] = {"rule": rule, "instances": len(members), "power_mw": sum(out.get(n, 0.0) for n in members) * 1e3}
    per_group = {g: sum(out.get(n, 0.0) for n in ms) * 1e3 for g, ms in gi.items()}
    return out, {"reference_group": ref_group, "p_ref_uw_per_instance": p_ref * 1e6, "applied": applied,
                 "group_power_mw": per_group, "total_mw": sum(out.values()) * 1e3}


def _solve_power(exp: Any, tech: Any, srcs: list[SourceSpec], power: dict[str, float], vdd: float, **kw: Any):
    saved = exp.power_w
    exp.power_w = power
    try:
        net, rep = build_network(exp, tech, srcs, ImportOptions(vdd_v=vdd, **kw))
    finally:
        exp.power_w = saved
    return net, rep, solve(net)


def _group_worst(net: Any, sol: Any, rep: Any, groups: list[dict[str, Any]], exp: Any, vdd: float) -> dict[str, float]:
    worst: dict[str, float] = defaultdict(float)
    for inst, (nv, ns) in rep.inst_attach.items():
        loss = (vdd - (sol.voltage(nv) - (sol.voltage(ns) if ns else 0.0))) * 1e3
        g = group_of(inst, groups)
        worst[g] = max(worst[g], loss)
    # macros: worst over their VDD landing loads
    for k, ld in enumerate(net.loads):
        if ld.block and exp.insts.get(ld.block, {}).get("type") == "BLOCK":
            worst["sram_macros"] = max(worst["sram_macros"], (vdd - sol.load_v_eff[k]) * 1e3)
    return dict(worst)


def run_experiments(cfg_path: Path, out: Path) -> dict[str, Any]:
    c = load_yaml(cfg_path)
    base = cfg_path.resolve().parent
    cfg = DesignConfig.load(resolve_path(c["design"], base))
    export_dir = Path(resolve_path(c["export"], base))
    prof = load_profile(cfg.technology)
    vdd = prof.require_vdd()
    lef = prof.tech("tech_lef")
    exp = read_export(export_dir)
    dbu = exp.dbu
    core = tuple(v / dbu * 1e-6 for v in exp.meta["core"])
    out.mkdir(parents=True, exist_ok=True)
    res: dict[str, Any] = {"run_type": "demonstration_experiments", "header": provenance_header(),
                           "config": str(cfg_path.resolve()), "config_content": c, "export": str(export_dir),
                           "fidelity": "DEMONSTRATION: ACTUAL EDA geometry + MODELLED/ASSUMED loads + ASSUMED supply taps",
                           "experiments": {}}
    E = res["experiments"]
    wl = c["workloads"]
    ref_group = c.get("reference_group", "cpu")
    dm = c.get("supply_model", cfg.default_supply_model)
    srcs = tap_specs(cfg, dm, exp, vdd)

    # ---------------- A / B: supply taps
    rows = []
    for m in ("WB1", "WB4", "WB8", "WB16"):
        net, rep, sol = _solve_power(exp, lef, tap_specs(cfg, m, exp, vdd), exp.power_w, vdd)
        s = _summary(sol, vdd)
        cur = np.array([abs(v) for k, v in sol.source_current.items() if k.startswith(cfg.power_net)])
        rows.append({"model": m, "vdd_taps": int(cur.size), "worst_loss_mv": s["worst_total_loss_mv"],
                     "mean_loss_mv": s["mean_total_loss_mv"], "max_tap_ma": float(cur.max() * 1e3),
                     "min_tap_ma": float(cur.min() * 1e3), "tap_imbalance_max_over_mean": float(cur.max() / cur.mean())})
    write_csv(out / "B_supply_taps.csv", rows)
    E["A_single_source"] = {"headline": f"WB1 (1 VDD + 1 VSS ring tap): worst loss {rows[0]['worst_loss_mv']:.2f} mV",
                            "rows": rows[:1], "fidelity": "loads MODELLED (vectorless); tap ASSUMED"}
    E["B_multiple_taps"] = {"headline": " | ".join(f"{r['model']}: {r['worst_loss_mv']:.2f} mV (tap I max/mean {r['tap_imbalance_max_over_mean']:.2f})" for r in rows),
                            "rows": rows}
    # simple 2-D grid single source (synthetic, from tech data)
    syn_base = c["synthetic"]["base"]
    W_um = (core[2] - core[0]) * 1e6; H_um = (core[3] - core[1]) * 1e6
    tot_i = sum(exp.power_w.values()) / vdd
    sw = synthetic_sweep(lef, W_um, H_um, syn_base, {"pads_per_side": [1, 2, 4]}, tot_i, vdd)
    E["A_single_source"]["synthetic_grid"] = sw

    # ---------------- C / D / E: strap pitch, width, vias (synthetic trends; physical in optimisation run)
    sweeps = c["synthetic"]["sweeps"]
    rows_c = synthetic_sweep(lef, W_um, H_um, syn_base, {k: sweeps[k] for k in ("m5_pitch", "tm1_pitch")}, tot_i * c["synthetic"].get("current_scale", 1.0), vdd)
    rows_d = synthetic_sweep(lef, W_um, H_um, syn_base, {k: sweeps[k] for k in ("m5_width", "tm1_width")}, tot_i * c["synthetic"].get("current_scale", 1.0), vdd)
    rows_e = synthetic_sweep(lef, W_um, H_um, syn_base, {k: sweeps[k] for k in ("stack_cuts", "tm_cuts")}, tot_i * c["synthetic"].get("current_scale", 1.0), vdd)
    for name, rr in (("C_strap_pitch", rows_c), ("D_strap_width", rows_d), ("E_via_density", rows_e)):
        write_csv(out / f"{name}.csv", rr)
        E[name] = {"rows": rr, "fidelity": "NUMERICAL MODEL on a generated grid with IHP LEF data; loads uniform (total = vectorless current x scale)",
                   "headline": "; ".join(f"{r['sweep']}={r['value']}: {r['worst_loss_mv']:.3f} mV" for r in rr),
                   "physical_verification": "see reports/optimisation/pdn_sweep (regenerated in OpenROAD)"}
    va = c.get("via_array", {})
    crowd = []
    for n in va.get("sizes", [[1, 5], [5, 5], [2, 12]]):
        cut = va.get("cut_layer", "TopVia1")
        lo, up = va.get("lower", "Metal5"), va.get("upper", "TopMetal1")
        r = resolve_via_array(n[0], n[1], parse_quantity(va.get("pitch", "0.84 um"), "length"),
                              lef.via_resistance_per_cut(cut), lef.sheet_resistance(lo), lef.sheet_resistance(up),
                              parse_quantity(va.get("lower_width", "5 um"), "length"),
                              parse_quantity(va.get("upper_width", "5 um"), "length"), feed=va.get("feed", "opposite"))
        crowd.append({"array": f"{n[0]}x{n[1]}", "cut_layer": cut, "max_over_mean": r["max_over_mean"],
                      "min_over_mean": r["min_over_mean"], "kcl_ok": r["kcl_ok"]})
    write_csv(out / "E_via_crowding.csv", crowd)
    E["E_via_density"]["via_current_crowding"] = crowd

    # ---------------- F / G / H: workloads on the real PDN
    wrows = []
    maps = {}
    shared = None
    sols = {}
    for name in ("idle", "tensor_mac", "sram_heavy", "concurrent", "cpu_intensive", "vector_arith", "dma_transfer"):
        if name not in wl:
            continue
        power, info = workload_power(exp, cfg.groups, wl[name]["rules"], ref_group)
        net, rep, sol = _solve_power(exp, lef, srcs, power, vdd)
        s = _summary(sol, vdd)
        gw = _group_worst(net, sol, rep, cfg.groups, exp, vdd)
        top = sorted(gw.items(), key=lambda kv: -kv[1])[:4]
        wrows.append({"workload": name, "source": wl[name].get("source", "ASSUMED"), "total_power_mw": info["total_mw"],
                      "model_valid": s["model_valid"], "loads_below_90pct": s["loads_below_90pct_nominal"],
                      "worst_loss_mv": s["worst_total_loss_mv"], "worst_vdd_droop_mv": s["worst_vdd_droop_mv"],
                      "worst_vss_bounce_mv": s["worst_vss_bounce_mv"], "mean_loss_mv": s["mean_total_loss_mv"],
                      "worst_groups": "; ".join(f"{g} {v:.2f}" for g, v in top), "kcl_ok": s["kcl_ok"], "power_ok": s["power_ok"],
                      "group_power_mw": info["group_power_mw"]})
        sols[name] = (net, sol, info)
    write_csv(out / "FGH_workloads.csv", wrows)
    vmax = max(r["worst_loss_mv"] for r in wrows)
    for name, (net, sol, info) in sols.items():
        maps[name] = save_maps(sol, out / "maps" / name, core, 64,
                               provenance=f"DEMONSTRATION | workload {name} ({wl[name].get('source', 'ASSUMED')}) | taps {dm} ASSUMED",
                               vdd_nom=vdd, shared={"ir_drop": (0, vmax)})["ir_drop"]
    for key, name in (("F_tensor_heavy", "tensor_mac"), ("G_sram_heavy", "sram_heavy"), ("H_combined", "concurrent")):
        row = next((r for r in wrows if r["workload"] == name), None)
        if row:
            E[key] = {"headline": f"{name}: {row['total_power_mw']:.1f} mW (ASSUMED) -> worst loss {row['worst_loss_mv']:.2f} mV; worst groups {row['worst_groups']}",
                      "row": row, "map": maps.get(name)}
    E["workloads_all"] = {"rows": wrows, "maps": maps}

    # ---------------- I: ground-return sensitivity
    conc, _ = workload_power(exp, cfg.groups, wl.get("concurrent", {}).get("rules", {}), ref_group)
    irows = []
    for label, kw, ss in (("VSS modelled, ideal taps", {}, srcs),
                          ("VSS NOT modelled (ideal return)", {"include_ground": False}, [s for s in srcs if s.net == cfg.power_net])):
        net, rep, sol = _solve_power(exp, lef, ss, conc, vdd, **kw)
        s = _summary(sol, vdd)
        irows.append({"case": label, "worst_loss_mv": s["worst_total_loss_mv"], "worst_bounce_mv": s["worst_vss_bounce_mv"]})
    for r_m in c.get("ground_series_mohm", [50, 200, 500]):
        ss = [SourceSpec(**{**s.__dict__, "series_resistance_ohm": (r_m * 1e-3 if s.net == cfg.ground_net else 0.0)}) for s in srcs]
        net, rep, sol = _solve_power(exp, lef, ss, conc, vdd)
        s = _summary(sol, vdd)
        irows.append({"case": f"VSS tap series R {r_m} mohm (ASSUMED)", "worst_loss_mv": s["worst_total_loss_mv"],
                      "worst_bounce_mv": s["worst_vss_bounce_mv"]})
    write_csv(out / "I_ground_return.csv", irows)
    E["I_ground_return"] = {"rows": irows, "headline": " | ".join(f"{r['case']}: {r['worst_loss_mv']:.2f} mV" for r in irows),
                            "workload": "concurrent (ASSUMED)"}

    # ---------------- J: temperature-dependent resistance (electrothermal, ASSUMED parameters)
    th = c["thermal"]
    prm = ThermalParams(parse_quantity(th["k_si"], "conductivity_thermal"), parse_quantity(th["t_si"], "length"),
                        parse_quantity(th["theta_ja"], "thermal_resistance"), parse_quantity(th["t_ambient"], "temperature"),
                        th.get("nx", 24), th.get("ny", 24), "ASSUMED")
    tcr = parse_quantity(th["tcr"], "temperature_coefficient")
    jrows = []
    for scale in th.get("power_scales", [1.0, 5.0]):
        pw = {k: v * scale for k, v in conc.items()}
        saved = exp.power_w; exp.power_w = pw
        try:
            net, rep = build_network(exp, lef, srcs, ImportOptions(vdd_v=vdd))
        finally:
            exp.power_w = saved
        s0 = solve(net)
        et = electrothermal(net, tcr, parse_quantity(th["t_ref"], "temperature"), prm, core, max_iter=20, tol_c=1e-3)
        s1 = et["final_solution"]
        jrows.append({"power_scale": scale, "total_power_mw": sum(pw.values()) * 1e3,
                      "worst_loss_25c_ref_mv": (vdd - s0.load_v_eff.min()) * 1e3,
                      "worst_loss_electrothermal_mv": (vdd - s1.load_v_eff.min()) * 1e3,
                      "t_max_c": et["history"][-1]["t_max_c"], "iterations": et["iterations"], "converged": et["converged"],
                      "within_10pct_supply_window": bool(s1.metrics.get("loads_below_90pct_nominal", 0) == 0),
                      "model_valid": bool(s1.metrics.get("model_valid", True))})
    write_csv(out / "J_temperature.csv", jrows)
    E["J_temperature"] = {"rows": jrows, "status": "DEMONSTRATION (BLOCKED for signoff: IHP temperature coefficient "
                                                   "and package thermal data not available)",
                          "assumptions": th, "headline": " | ".join(f"x{r['power_scale']:g}: {r['worst_loss_25c_ref_mv']:.2f} -> {r['worst_loss_electrothermal_mv']:.2f} mV at Tmax {r['t_max_c']:.1f} C" for r in jrows)}

    # ---------------- TestCore modes
    res["testcore"] = testcore_modes(exp, lef, srcs, cfg, vdd, c.get("testcore", {}), out)
    (out / "run.json").write_text(json.dumps(_jsonable(res), indent=1, default=str))
    return res


def testcore_modes(exp: Any, tech: Any, srcs: list[SourceSpec], cfg: DesignConfig, vdd: float, tc: dict[str, Any], out: Path) -> dict[str, Any]:
    """Test-mode supply analysis using what TestCore actually defines.

    TestCore facts (silicaflux-testcore docs): MBIST tests memories ONE AT A TIME
    (04_mbist.md) with the CPU held in reset; scan chains are NOT inserted (readiness
    screen only, 06_scan_architecture.md); shift frequency not yet chosen.  Test
    currents are therefore not available: per-macro SRAM access current and scan
    activity below are ASSUMED what-ifs.
    """
    macros = [n for n, d in exp.insts.items() if d["type"] == "BLOCK"]
    i_mac = parse_quantity(tc.get("assumed_sram_access_power", "2 mW"), "power")
    rows = []
    for label, active in (("MBIST sequential (TestCore default: 1 macro)", 1),
                          ("MBIST 4 macros in parallel (what-if)", 4),
                          (f"MBIST all {len(macros)} macros in parallel (what-if)", len(macros))):
        pw = {k: (v if not exp.insts.get(k, {}).get("type") == "BLOCK" else 0.0) for k, v in exp.power_w.items()}
        # CPU held in reset during MBIST: keep vectorless background (conservative), add macro access power
        # worst placement of the active set: macros furthest from the taps first (by index order of distance)
        dist = []
        for m in macros:
            b = exp.insts[m]["bbox"]
            cx, cy = (b[0] + b[2]) / 2 / exp.dbu, (b[1] + b[3]) / 2 / exp.dbu
            dist.append((min(math.hypot(cx - s.x_um, cy - s.y_um) for s in srcs), m))
        for _, m in sorted(dist, reverse=True)[:active]:
            pw[m] = i_mac
        net, rep, sol = _solve_power(exp, tech, srcs, pw, vdd)
        s = _summary(sol, vdd)
        rows.append({"mode": label, "active_macros": active, "assumed_access_power_per_macro_mw": i_mac * 1e3,
                     "worst_loss_mv": s["worst_total_loss_mv"], "total_power_mw": sum(pw.values()) * 1e3})
    sc = float(tc.get("assumed_scan_shift_flop_activity_scale", 5.0))
    pw = dict(exp.power_w)
    net, rep, sol = _solve_power(exp, tech, srcs, {k: v * sc for k, v in pw.items()}, vdd)
    s = _summary(sol, vdd)
    rows.append({"mode": f"scan shift what-if (all logic x{sc:g} vectorless, ASSUMED)", "active_macros": 0,
                 "assumed_access_power_per_macro_mw": None, "worst_loss_mv": s["worst_total_loss_mv"],
                 "total_power_mw": sum(pw.values()) * sc * 1e3})
    write_csv(out / "testcore_modes.csv", rows)
    return {"rows": rows, "facts": {"mbist_concurrency": "one memory at a time (TestCore docs/04_mbist.md)",
                                    "scan": "not inserted; readiness screen only (docs/06_scan_architecture.md); shift frequency TBD",
                                    "jtag": "TCK domain 378 flops; low activity (not separately modelled)"},
            "status": "DEMONSTRATION: test currents ASSUMED; production test current must come from scan-inserted "
                      "netlist simulation (pattern VCD) and vendor MBIST characterisation"}


def run_transient(cfg_path: Path, out: Path) -> dict[str, Any]:
    c = load_yaml(cfg_path)
    q = parse_quantity
    p0 = c["rlc"]
    base = RLCParams(q(p0["v_reg"], "voltage"), q(p0["r_vrm"], "resistance"), q(p0["r_pkg"], "resistance"),
                     q(p0["l_pkg"], "inductance"), q(p0["c_die"], "capacitance"), q(p0["r_c"], "resistance"),
                     q(p0["r_die"], "resistance"), p0.get("source", "ASSUMED"))
    out.mkdir(parents=True, exist_ok=True)
    dt = q(c.get("dt", "10 ps"), "time"); t_end = q(c.get("t_end", "200 ns"), "time"); t_on = q(c.get("t_on", "20 ns"), "time")
    band = q(c.get("droop_band", "10 mV"), "voltage")
    rows = []
    traces = {}
    for ev in c["events"]:
        i0, i1, tr = q(ev["i0"], "current"), q(ev["i1"], "current"), q(ev["t_rise"], "time")
        for cs in c.get("decap_scales", [1.0]):
            p = RLCParams(**{**base.__dict__, "c_die": base.c_die * cs})
            sim = simulate(p, load_step(i0, i1, t_on, tr), t_end, dt)
            m = step_metrics(sim, base.v_reg - (base.r_vrm + base.r_pkg) * i0, band, t_on)
            rows.append({"event": ev["name"], "decap_scale": cs, "i0_ma": i0 * 1e3, "i1_ma": i1 * 1e3, "t_rise_ns": tr * 1e9, **m})
            if cs == 1.0:
                traces[ev["name"]] = sim
    write_csv(out / "droop.csv", rows)
    ev0 = c["events"][0]
    xc = ngspice_crosscheck(base, q(ev0["i0"], "current"), q(ev0["i1"], "current"), t_on, q(ev0["t_rise"], "time"),
                            t_end, dt, out / "ngspice")
    _plot_transient(traces, out / "droop.png")
    summary = {"events": len(c["events"]), "worst_v_min": min(r["v_min"] for r in rows),
               "ngspice_crosscheck": xc, "label": "RESEARCH: lumped RLC with ASSUMED parasitics; not a package-accurate prediction"}
    res = {"run_type": "transient_droop", "header": provenance_header(), "config_content": c, "rows": rows, "summary": summary}
    (out / "run.json").write_text(json.dumps(_jsonable(res), indent=1, default=str))
    return res


def _plot_transient(traces: dict[str, dict[str, np.ndarray]], path: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from .visualise import PALETTE
    fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=110)
    fig.patch.set_facecolor(PALETTE["navy"]); ax.set_facecolor("#101d3d")
    cols = [PALETTE["gold"], PALETTE["cyan"], PALETTE["violet"], PALETTE["amber"], "#e6ecf5"]
    for k, (name, s) in enumerate(traces.items()):
        ax.plot(s["t"] * 1e9, s["v_load"], color=cols[k % len(cols)], lw=1.2, label=name)
    ax.set_xlabel("t [ns]", color=PALETTE["ink"]); ax.set_ylabel("V at load [V]", color=PALETTE["ink"])
    ax.tick_params(colors=PALETTE["ink"]); ax.grid(alpha=0.2); ax.legend(fontsize=7)
    ax.set_title("Lumped RLC droop (RESEARCH, ASSUMED parasitics)", color=PALETTE["ink"], fontsize=9)
    fig.tight_layout(); fig.savefig(path, facecolor=fig.get_facecolor()); plt.close(fig)
