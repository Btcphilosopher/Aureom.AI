"""End-to-end flows: physical design analysis, PDNSim comparison, provenance.

Every flow writes a self-describing run directory:
  run.json         metadata, inputs (sha256), tool versions, results, gates, findings
  evidence/        OpenROAD logs, check reports, PDNSim outputs, exported PDN (compressed)
  tables/          CSV results
  maps/            PNG + SVG heatmaps
"""
from __future__ import annotations

import csv
import datetime as _dt
import gzip
import json
import math
import platform
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional

import numpy as np

from . import __version__
from .compare import compare_instance_voltages, solve_pdnsim_spice
from .config import DesignConfig
from .current_density import em_screen, layer_summary, segment_table
from .graph import LoadModel
from .openroad_adapter import (DesignInputs, OpenROAD, ToolchainError, parse_pdnsim_spice, parse_pdnsim_voltage,
                               write_vsrc)
from .pdn_import import ImportOptions, SourceSpec, build_network, canonical_name, read_export
from .provenance import CheckStatus, DataSource, ResultStatus
from .solver import SOLVER_VERSION, SolverOptions, solve
from .technology import TechData, load_profile, tech_from_db_dump, write_resistance_override, parse_setrc
from .timing import group_of, parse_report_checks, risk_table, voltage_aware_sta_status
from .units import parse_quantity
from .visualise import BINNING_METHOD, layer_maps, save_maps

ROOT = Path(__file__).resolve().parents[1]

__all__ = ["provenance_header", "analyse_design", "tap_specs", "write_csv"]


def _git(args: list[str], cwd: Path) -> str:
    try:
        return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, timeout=20).stdout.strip()
    except Exception:
        return ""


def provenance_header(extra: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    import importlib
    pkgs = {}
    for m in ("numpy", "scipy", "networkx", "pandas", "pydantic", "yaml", "matplotlib", "plotly", "pytest", "hypothesis"):
        try:
            pkgs[m] = getattr(importlib.import_module(m), "__version__", "?")
        except Exception:
            pkgs[m] = "MISSING"
    ora = OpenROAD()
    h = {
        "tool": "SilicaFlux PowerGrid", "powergrid_version": __version__, "solver_version": SOLVER_VERSION,
        "timestamp_utc": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"),
        "powergrid_git": {"revision": _git(["rev-parse", "HEAD"], ROOT) or "not a git checkout",
                          "dirty": bool(_git(["status", "--porcelain"], ROOT))},
        "repository_git": {"revision": _git(["rev-parse", "HEAD"], ROOT.parent.parent) or "unknown",
                           "branch": _git(["rev-parse", "--abbrev-ref", "HEAD"], ROOT.parent.parent)},
        "python": sys.version.split()[0], "platform": platform.platform(), "packages": pkgs,
        "openroad": ora.version() if ora.available() else "NOT INSTALLED",
        "ngspice": next((l.strip("* ").strip() for l in subprocess.run(["ngspice", "-v"], capture_output=True, text=True).stdout.splitlines() if "ngspice-" in l), "?")
        if shutil.which("ngspice") else "NOT INSTALLED",
    }
    if extra:
        h.update(extra)
    return h


def write_csv(path: Path, rows: list[dict[str, Any]]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return str(path)
    keys: list[str] = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: (json.dumps(v) if isinstance(v, (list, dict)) else v) for k, v in r.items()})
    return str(path)


def _jsonable(o: Any) -> Any:
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, float) and not math.isfinite(o):
        return None
    if isinstance(o, np.ndarray):
        return _jsonable(o.tolist())
    return o


# ----------------------------------------------------------------------------- supply taps
def _rings(exp: Any, net: str) -> dict[str, Any]:
    rings = [w for w in exp.wires if w.net == net and w.shape == "RING"]
    return {"wires": rings}


def tap_specs(cfg: DesignConfig, model_name: str, exp: Any, vdd: float) -> list[SourceSpec]:
    model = cfg.supply(model_name)
    rser = parse_quantity(model.series_resistance, "resistance")
    dbu = exp.dbu
    core = [c / dbu for c in exp.meta["core"]]
    cx0, cy0, cx1, cy1 = core
    out: list[SourceSpec] = []
    nets = (cfg.power_net, cfg.ground_net)
    if model.kind == "wirebond_ring_taps":
        n = model.taps_per_side or 1
        for net in nets:
            ring = [w for w in exp.wires if w.net == net and w.shape == "RING"]
            if not ring:
                raise ValueError(f"supply model {model.name}: no core ring on {net}; ring-tap model not applicable")
            rx0 = min(w.x0 for w in ring) / dbu; ry0 = min(w.y0 for w in ring) / dbu
            rx1 = max(w.x1 for w in ring) / dbu; ry1 = max(w.y1 for w in ring) / dbu
            k = 0
            for side in model.sides:
                for i in range(n):
                    f = (i + 0.5) / n
                    if side == "bottom":
                        x, y = rx0 + f * (rx1 - rx0), ry0
                    elif side == "top":
                        x, y = rx0 + f * (rx1 - rx0), ry1
                    elif side == "left":
                        x, y = rx0, ry0 + f * (ry1 - ry0)
                    else:
                        x, y = rx1, ry0 + f * (ry1 - ry0)
                    out.append(SourceSpec(f"{net}_{model.name}_{side}{i}", net, x, y, series_resistance_ohm=rser,
                                          voltage_v=vdd if net == cfg.power_net else 0.0, kind="wirebond_pad",
                                          provenance=model.provenance))
                    k += 1
    elif model.kind == "area_array_hypothetical":
        pitch = parse_quantity(model.pitch, "length") * 1e6
        xs = np.arange(cx0 + pitch / 2, cx1, pitch)
        ys = np.arange(cy0 + pitch / 2, cy1, pitch)
        for j, y in enumerate(ys):
            for i, x in enumerate(xs):
                net = nets[(i + j) % 2]
                out.append(SourceSpec(f"{net}_{model.name}_{i}_{j}", net, float(x), float(y), series_resistance_ohm=rser,
                                      voltage_v=vdd if net == cfg.power_net else 0.0, kind="bump",
                                      provenance="ASSUMED (HYPOTHETICAL package)"))
    else:
        for k, t in enumerate(model.taps):
            if t.side != "xy" or t.x is None or t.y is None:
                raise ValueError(f"supply model {model.name}: explicit taps need side 'xy' with x and y")
            for net in nets:
                out.append(SourceSpec(f"{net}_{model.name}_{k}", net, parse_quantity(t.x, "length") * 1e6,
                                      parse_quantity(t.y, "length") * 1e6, series_resistance_ohm=rser,
                                      voltage_v=vdd if net == cfg.power_net else 0.0, provenance=model.provenance))
    return out


# ----------------------------------------------------------------------------- analyse
def _group_stats(net: Any, sol: Any, rep: Any, groups: list[dict[str, Any]], exp: Any, vdd: float) -> tuple[list[dict[str, Any]], dict[str, float]]:
    veff_node: dict[tuple[str, Optional[str]], float] = {}
    for k, ld in enumerate(net.loads):
        veff_node[(ld.vdd_node, ld.vss_node)] = float(sol.load_v_eff[k])
    vdd_v = {}
    vss_v = {}
    inst_veff: dict[str, float] = {}
    for inst, (nv, ns) in rep.inst_attach.items():
        v1 = sol.voltage(nv)
        v0 = sol.voltage(ns) if ns else 0.0
        inst_veff[inst] = v1 - v0
        vdd_v[inst] = v1
        vss_v[inst] = v0
    acc: dict[str, dict[str, Any]] = defaultdict(lambda: {"instances": 0, "power_w": 0.0, "worst_v_eff": math.inf,
                                                          "sum_loss": 0.0, "worst_inst": None, "worst_droop_mv": 0.0,
                                                          "worst_bounce_mv": 0.0, "x": [], "y": []})
    for inst, v in inst_veff.items():
        g = group_of(inst, groups)
        a = acc[g]
        a["instances"] += 1
        a["power_w"] += exp.power_w.get(inst, 0.0)
        a["sum_loss"] += vdd - v
        a["worst_droop_mv"] = max(a["worst_droop_mv"], (vdd - vdd_v[inst]) * 1e3)
        a["worst_bounce_mv"] = max(a["worst_bounce_mv"], vss_v[inst] * 1e3)
        if v < a["worst_v_eff"]:
            a["worst_v_eff"] = v
            a["worst_inst"] = inst
    # macros (BLOCK) by name
    for name, d in exp.insts.items():
        if d["type"] == "BLOCK":
            g = "sram_macros"
            a = acc[g]
            a["instances"] += 1
            a["power_w"] += exp.power_w.get(name, 0.0)
    rows = []
    for g, a in acc.items():
        rows.append({"group": g, "instances": a["instances"], "power_mw": a["power_w"] * 1e3,
                     "worst_v_eff_v": None if not math.isfinite(a["worst_v_eff"]) else a["worst_v_eff"],
                     "worst_loss_mv": None if not math.isfinite(a["worst_v_eff"]) else (vdd - a["worst_v_eff"]) * 1e3,
                     "mean_loss_mv": a["sum_loss"] / a["instances"] * 1e3 if a["instances"] and a["sum_loss"] else None,
                     "worst_vdd_droop_mv": a["worst_droop_mv"], "worst_vss_bounce_mv": a["worst_bounce_mv"],
                     "worst_instance": a["worst_inst"]})
    rows.sort(key=lambda r: -(r["worst_loss_mv"] or 0))
    return rows, inst_veff


def _solve_case(exp: Any, tech: TechData, srcs: list[SourceSpec], opts: ImportOptions, sopts: Optional[SolverOptions] = None):
    net, rep = build_network(exp, tech, srcs, opts)
    sol = solve(net, sopts)
    return net, rep, sol


def _summary(sol: Any, vdd: float) -> dict[str, Any]:
    lt_veff = sol.load_v_eff
    k = int(np.argmin(lt_veff))
    net = sol.network
    m = sol.metrics
    return {
        "worst_v_eff_v": float(lt_veff[k]), "worst_total_loss_mv": float((vdd - lt_veff[k]) * 1e3),
        "worst_vdd_droop_mv": float((vdd - sol.load_v_vdd.min()) * 1e3),
        "worst_vss_bounce_mv": float(sol.load_v_vss.max() * 1e3),
        "mean_total_loss_mv": float((vdd - lt_veff.mean()) * 1e3),
        "worst_load_block": net.loads[k].block,
        "total_load_current_ma": float(sol.load_current.sum() * 1e3),
        "resistive_loss_uw": m["power_dissipated_W"] * 1e6, "load_power_mw": m["power_load_W"] * 1e3,
        "source_power_mw": m["power_source_W"] * 1e3,
        "kcl_ok": bool(m["kcl_ok"]), "power_ok": bool(m["power_ok"]), "kcl_max_abs_a": m["kcl_max_abs_A"],
        "power_balance_rel": m["power_balance_rel"], "residual_backward_error": m["residual_backward_error"],
        "unknowns": m["unknowns"], "matrix_nnz": m["matrix_nnz"], "method": m["method"],
        "time_factor_s": m["time_factor_s"], "time_solve_s": m["time_solve_s"],
        "fixed_point_iterations": m["fixed_point_iterations"],
        "source_currents_ma": {k_: v * 1e3 for k_, v in sol.source_current.items()},
        "model_valid": bool(m.get("model_valid", True)),
        "loads_below_90pct_nominal": int(m.get("loads_below_90pct_nominal", 0)),
    }


def analyse_design(cfg_path: str | Path, out: Path, run_pdnsim: bool = True, models: Optional[list[str]] = None,
                   nbin: int = 64) -> dict[str, Any]:
    cfg = DesignConfig.load(cfg_path)
    out.mkdir(parents=True, exist_ok=True)
    ev = out / "evidence"; tab = out / "tables"; mp = out / "maps"
    for d in (ev, tab, mp):
        d.mkdir(exist_ok=True)
    run: dict[str, Any] = {"run_type": "physical_analysis", "design": cfg.name, "config": str(Path(cfg_path).resolve()),
                           "header": provenance_header(), "steps": [], "findings": [], "status": "RUNNING"}
    ora = OpenROAD()
    if not ora.available():
        run["status"] = "BLOCKED"
        run["blocked_reason"] = "OpenROAD toolchain unavailable (env/install_toolchain.sh)"
        (out / "run.json").write_text(json.dumps(_jsonable(run), indent=1))
        raise ToolchainError(run["blocked_reason"])
    di = DesignInputs(cfg.name, cfg.odb, cfg.tech_lef, cfg.lefs, cfg.libs, cfg.sdc, None, cfg.pdn_tcl, cfg.power_net, cfg.ground_net)
    missing = di.validate()
    if missing:
        run["status"] = "BLOCKED"; run["blocked_reason"] = f"physical design inputs missing: {missing}"
        (out / "run.json").write_text(json.dumps(_jsonable(run), indent=1))
        raise FileNotFoundError(run["blocked_reason"])
    run["inputs"] = {"files_sha256": di.hashes(), "design_inputs": di.__dict__}
    prof = load_profile(cfg.technology)
    vdd = prof.require_vdd()
    run["supply"] = {"vdd_nominal_v": vdd, "source": prof.nominal_supply_source}
    env = di.env()

    # ---- 1. connectivity
    r = ora.run("check_pdn.tcl", {**env, "PG_OUT": str(ev / "check")}, ev / "check_pdn.log", "check_power_grid")
    run["steps"].append(r.as_dict())
    checks = [x for x in r.records if x["_tag"] == "PG-CHECK"]
    conn_ok = r.ok and len(checks) == 2 and all(c.get("result") == "true" and c.get("error_lines", 1) == 0 for c in checks)
    run["connectivity"] = {"status": "PASS" if conn_ok else "FAIL", "checks": checks}

    # ---- 2. export
    r = ora.run("export_pdn.tcl", {**env, "PG_OUT": str(ev / "export"), "PG_POWER": "1",
                                   "PG_ACTIVITY": str(cfg.activity.get("input_activity", 0.1))},
                ev / "export_pdn.log", "export_pdn_and_power")
    run["steps"].append(r.as_dict())
    if not r.ok:
        run["status"] = "FAILED"; run["failure_reason"] = "PDN export failed"
        (out / "run.json").write_text(json.dumps(_jsonable(run), indent=1))
        raise RuntimeError(run["failure_reason"])
    exp = read_export(ev / "export")
    lef = prof.tech("tech_lef")
    odbt = tech_from_db_dump(ev / "export" / "tech_layers.csv", lef)
    techs: dict[str, TechData] = {"tech_lef": lef, "odb_tech": odbt}
    if prof.setrc:
        try:
            techs["orfs_setrc"] = prof.tech("orfs_setrc")
        except Exception as exc:  # noqa
            run["findings"].append(f"setRC source unavailable: {exc}")
    res_table = []
    for lname, l in lef.routing.items():
        res_table.append({"layer": lname, "type": "ROUTING", "tech_lef_ohm_sq": l.rpersq_ohm,
                          "odb_ohm_sq": odbt.routing[lname].rpersq_ohm,
                          "setrc_equiv_ohm_sq": techs["orfs_setrc"].routing[lname].rpersq_ohm if "orfs_setrc" in techs else None,
                          "thickness_um": l.thickness_um, "dc_limit_ma_per_um": l.dc_current_ma_per_um})
    for cname, c in lef.cuts.items():
        res_table.append({"layer": cname, "type": "CUT", "tech_lef_ohm_per_cut": c.resistance_per_cut_ohm,
                          "odb_ohm_per_cut": odbt.cuts[cname].resistance_per_cut_ohm,
                          "setrc_ohm_per_cut": techs["orfs_setrc"].cuts[cname].resistance_per_cut_ohm if "orfs_setrc" in techs else None,
                          "dc_limit_ma_per_cut": c.dc_current_ma_per_cut})
    write_csv(tab / "resistance_sources.csv", res_table)
    run["resistance_data"] = {"primary": cfg.primary_resistance_source, "table": res_table, "notes": odbt.notes,
                              "finding": "The OpenDB written by the ORFS flow carries layer resistances overwritten by "
                                         "the platform setRC.tcl (set_layer_rc); they differ from the IHP tech LEF "
                                         "by 1.6-6x (metal) and 10x (vias). Analyses are run with both."}
    with open(ev / "export" / "power.csv") as fh:
        pass
    total_p = sum(exp.power_w.values())
    run["load_source"] = {"label": exp.meta.get("power_label"), "total_power_mw": total_p * 1e3,
                          "provenance": DataSource.MODELLED.value,
                          "macro_power_mw": sum(exp.power_w.get(n, 0.0) for n, d in exp.insts.items() if d["type"] == "BLOCK") * 1e3,
                          "note": cfg.activity.get("label")}

    # ---- 3. supply models (primary resistance source)
    tech = techs[cfg.primary_resistance_source]
    models = models or [m.name for m in cfg.supply_models]
    results: dict[str, Any] = {}
    sols: dict[str, Any] = {}
    for mname in models:
        srcs = tap_specs(cfg, mname, exp, vdd)
        net, rep, sol = _solve_case(exp, tech, srcs, ImportOptions(power_net=cfg.power_net, ground_net=cfg.ground_net,
                                                                     vdd_v=vdd, current_conversion="nominal"))
        s = _summary(sol, vdd)
        s["sources"] = len(srcs)
        s["kind"] = cfg.supply(mname).kind
        s["description"] = cfg.supply(mname).description
        s["max_source_current_ma"] = max(abs(v) for v in s["source_currents_ma"].values())
        s["min_source_current_ma"] = min(abs(v) for v in s["source_currents_ma"].values())
        results[mname] = s
        sols[mname] = (net, rep, sol, srcs)
    run["supply_models"] = results
    write_csv(tab / "supply_models.csv", [{"model": k, **{kk: vv for kk, vv in v.items() if kk != "source_currents_ma"}}
                                          for k, v in results.items()])
    dm = cfg.default_supply_model
    net, rep, sol, srcs = sols[dm]
    run["import"] = rep.as_dict()
    if rep.pg_iterms_unconnected_in_db:
        run["findings"].append(f"{len(rep.pg_iterms_unconnected_in_db)} instances have PG pins without a net in the "
                               "OpenDB (inserted after global_connect); attached by pin type to the abutting rail.")
    src_rows = [{"source": k, "net": next(s.net for s in srcs if s.name == k), "current_ma": v * 1e3,
                 **next(d for d in rep.sources if d["name"] == k)} for k, v in sol.source_current.items()]
    write_csv(tab / f"source_currents_{dm}.csv", src_rows)
    for mname, (n_, r_, s_, sr_) in sols.items():
        write_csv(tab / f"source_currents_{mname}.csv",
                  [{"source": k, "current_ma": v * 1e3} for k, v in s_.source_current.items()])

    # ---- 4. maps (default model) + consistent scale across models
    dbu = exp.dbu
    core = tuple(c / dbu * 1e-6 for c in exp.meta["core"])
    overlays: list[dict[str, Any]] = []
    for name, di_ in exp.insts.items():
        if di_["type"] == "BLOCK":
            b = di_["bbox"]
            overlays.append({"bbox": tuple(v / dbu * 1e-6 for v in b), "color": "#22d3ee", "label": "SRAM"})
    group_rows, inst_veff = _group_stats(net, sol, rep, cfg.groups, exp, vdd)
    # logical group regions = bounding box of member attachment points (annotation, not a block outline)
    gxy: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for inst, (nv, _) in rep.inst_attach.items():
        g = group_of(inst, cfg.groups)
        i = net.node_index(nv)
        gxy[g].append((net.node_x[i], net.node_y[i]))
    for g in ("cpu", "vector", "tensor", "dma", "fabric", "periph"):
        if gxy.get(g):
            arr = np.array(gxy[g])
            lo = np.percentile(arr, 5, axis=0); hi = np.percentile(arr, 95, axis=0)
            overlays.append({"bbox": (lo[0], lo[1], hi[0], hi[1]), "color": "#f59e0b", "label": g, "ls": "--"})
    worst_loss = max(results[m]["worst_total_loss_mv"] for m in results)
    prov = (f"{ResultStatus.NUMERICAL_MODEL.value} on ACTUAL EDA geometry | loads MODELLED (OpenSTA vectorless) | "
            f"supply {dm} ASSUMED | R: {tech.source}")
    common: dict[str, tuple[Optional[float], Optional[float]]] = {"ir_drop_common": (0.0, worst_loss), "vdd_droop": (0.0, None), "vss_bounce": (0.0, None), "ir_drop": (0.0, None)}
    run["maps"] = {dm: save_maps(sol, mp / dm, core, nbin, overlays, prov, vdd, shared=common, warnings_pts=[])}
    for mname in models:
        if mname == dm:
            continue
        n_, r_, s_, sr_ = sols[mname]
        mm = save_maps(s_, mp / mname, core, nbin, overlays, prov.replace(dm, mname), vdd, shared=common)
        run["maps"][mname] = {"ir_drop": mm["ir_drop"], "ir_drop_common_scale": mm["ir_drop_common_scale"]}
    run["maps"]["layers"] = layer_maps(sol, mp / dm / "layers", core, nbin, prov)
    run["map_method"] = BINNING_METHOD
    write_csv(tab / f"groups_{dm}.csv", group_rows)
    run["groups"] = group_rows

    # per-instance results (compressed)
    with gzip.open(tab / f"instances_{dm}.csv.gz", "wt") as fh:
        fh.write("instance,group,v_vdd,v_vss,v_eff,power_w\n")
        for inst, (nv, ns) in sorted(rep.inst_attach.items()):
            v1 = sol.voltage(nv); v0 = sol.voltage(ns) if ns else 0.0
            fh.write(f"{inst},{group_of(inst, cfg.groups)},{v1:.9f},{v0:.9f},{v1 - v0:.9f},{exp.power_w.get(inst, 0.0):.6e}\n")

    # ---- 5. current density / EM
    em = em_screen(sol)
    ls = layer_summary(sol)
    write_csv(tab / f"layers_{dm}.csv", ls)
    st = segment_table(sol)
    order = np.argsort(-st["abs_current_a"])[:200]
    top = []
    for i in order:
        top.append({"segment": int(i), "layer": net.seg_layer[i], "kind": net.seg_kind[i].value,
                    "a": net.node_ids[net.seg_a[i]], "b": net.node_ids[net.seg_b[i]],
                    "current_ma": float(sol.segment_current[i] * 1e3), "resistance_ohm": net.seg_r[i],
                    "j_linear_ma_per_um": float(st["j_linear_a_per_m"][i] * 1e-3) if np.isfinite(st["j_linear_a_per_m"][i]) else None,
                    "current_per_cut_ma": float(st["current_per_cut_a"][i] * 1e3) if np.isfinite(st["current_per_cut_a"][i]) else None,
                    "limit_ma": float(st["limit_a"][i] * 1e3) if np.isfinite(st["limit_a"][i]) else None,
                    "em_status": em["status_per_segment"][i],
                    "utilisation": float(em["utilisation"][i]) if np.isfinite(em["utilisation"][i]) else None})
    write_csv(tab / f"top_segments_{dm}.csv", top)
    run["current_density"] = {"layers": ls, "em": {k: v for k, v in em.items() if k not in ("status_per_segment", "utilisation")},
                              "top_segments_csv": str(tab / f"top_segments_{dm}.csv")}

    # ---- 6. sensitivities on the default model
    sens: dict[str, Any] = {}
    for src_name, t in techs.items():
        if src_name == cfg.primary_resistance_source:
            continue
        _, _, s2 = _solve_case(exp, t, srcs, ImportOptions(vdd_v=vdd))
        sens[f"resistance_source={src_name}"] = _summary(s2, vdd)
    for r_mohm in (25, 50, 100, 200):
        srcs_r = [SourceSpec(**{**s.__dict__, "series_resistance_ohm": r_mohm * 1e-3}) for s in srcs]
        _, _, s2 = _solve_case(exp, tech, srcs_r, ImportOptions(vdd_v=vdd))
        sens[f"source_series_R={r_mohm}mohm"] = _summary(s2, vdd)
    _, _, s2 = _solve_case(exp, tech, [s for s in srcs if s.net == cfg.power_net],
                           ImportOptions(vdd_v=vdd, include_ground=False))
    sens["ground_network_ideal (VSS not modelled)"] = _summary(s2, vdd)
    for scale in (5.0, 10.0):
        _, _, s2 = _solve_case(exp, tech, srcs, ImportOptions(vdd_v=vdd, current_scale=scale))
        sens[f"load_scale_x{scale:g} (ASSUMED activity)"] = _summary(s2, vdd)
    # constant-power (local voltage) conversion
    net_cp, rep_cp = build_network(exp, tech, srcs, ImportOptions(vdd_v=vdd))
    for ld in net_cp.loads:
        ld.model = LoadModel.FIXED_POWER
        ld.power_w = (ld.current_a or 0.0) * vdd
        ld.conversion_voltage = "local"
    s_cp = solve(net_cp)
    sens["constant_power_local_voltage"] = _summary(s_cp, vdd)
    run["sensitivity"] = sens
    write_csv(tab / f"sensitivity_{dm}.csv", [{"case": k, **{kk: vv for kk, vv in v.items() if kk != "source_currents_ma"}}
                                             for k, v in sens.items()])

    # ---- 7. timing coupling
    tc: dict[str, Any] = {"voltage_aware_sta": voltage_aware_sta_status(str(Path(cfg.libs[0]).parent))}
    rpt = cfg.timing_reports.get("reg2reg") or cfg.timing_reports.get("setup")
    if rpt and Path(rpt).exists():
        paths = parse_report_checks(rpt)
        gstat: dict[str, dict[str, Any]] = {r_["group"]: {} for r_ in group_rows}
        dens = sorted([r_ for r_ in group_rows if r_["instances"]], key=lambda r_: -(r_["power_mw"] / r_["instances"]))
        for k, r_ in enumerate(dens):
            gstat[r_["group"]] = {"power_density_rank": k + 1}
        rt = risk_table(paths, inst_veff, cfg.groups, vdd, gstat)
        write_csv(tab / f"timing_risk_{dm}.csv", rt)
        tc.update({"report": rpt, "paths": len(paths), "rows": rt[:20],
                   "label": "PRE-ROUTE timing (FloorplanLab placement STA, ideal clocks); droop NOT converted to delay"})
    else:
        tc["status"] = "NOT RUN (no timing report)"
    run["timing"] = tc

    # ---- 8. PDNSim + comparison
    if run_pdnsim:
        run["pdnsim"] = _pdnsim_compare(cfg, ora, env, exp, techs, srcs, rep, out, vdd, dm)

    run["status"] = "COMPLETED"
    run["finished_utc"] = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
    # compress the bulky export evidence
    for f in ("insts.csv", "vias.csv", "power.csv"):
        p = ev / "export" / f
        if p.exists():
            with open(p, "rb") as src_fh, gzip.open(str(p) + ".gz", "wb") as dst:
                shutil.copyfileobj(src_fh, dst)
            p.unlink()
    (out / "run.json").write_text(json.dumps(_jsonable(run), indent=1))
    return run


def _pdnsim_compare(cfg: DesignConfig, ora: OpenROAD, env: dict[str, str], exp: Any, techs: dict[str, TechData],
                    srcs: list[SourceSpec], rep: Any, out: Path, vdd: float, model: str) -> dict[str, Any]:
    ev = out / "evidence"
    res: dict[str, Any] = {"supply_model": model,
                           "limitations": ["PDNSim 6011bbe77 places sources on the top PDN layer only and has no source "
                                           "series resistance: compared with ideal taps at identical nodes",
                                           "PDNSim injects instance POWER (W) as CURRENT (A) (ir_solver.cpp createJ); "
                                           "the custom solver is run with the same convention for equivalence"]}
    # identical source nodes: use the custom importer's snapped coordinates
    for net_name in (cfg.power_net, cfg.ground_net):
        pts = [(d["snapped_um"][0], d["snapped_um"][1], 10.0, vdd if net_name == cfg.power_net else 0.0)
               for d in rep.sources if d["net"] == net_name]
        write_vsrc(ev / f"vsrc_{net_name}.loc", pts)
    runs = {}
    for label, tname in (("odb_tech", "odb_tech"), ("tech_lef", "tech_lef")):
        d = ev / f"pdnsim_{label}"
        e = {**env, "PG_OUT": str(d), f"PG_VOLTAGE_{cfg.power_net}": str(vdd), f"PG_VOLTAGE_{cfg.ground_net}": "0.0",
             f"PG_VSRC_{cfg.power_net}": str(ev / f"vsrc_{cfg.power_net}.loc"),
             f"PG_VSRC_{cfg.ground_net}": str(ev / f"vsrc_{cfg.ground_net}.loc"),
             "PG_ACTIVITY": str(cfg.activity.get("input_activity", 0.1)), "PG_WRITE_SPICE": "1" if label == "odb_tech" else "0"}
        if label == "tech_lef":
            write_resistance_override(techs["tech_lef"], ev / "lef_override.csv")
            e["PG_RES_OVERRIDE"] = str(ev / "lef_override.csv")
        r = ora.run("run_pdnsim.tcl", e, ev / f"pdnsim_{label}.log", f"pdnsim_{label}")
        recs = [x for x in r.records if x["_tag"] == "PG-PDNSIM"]
        ok = r.ok and len(recs) == 2 and all(x["tcl_rc"] == 0 for x in recs) and \
            all((d / f"{n}_voltage.csv").exists() for n in (cfg.power_net, cfg.ground_net))
        entry: dict[str, Any] = {"step": r.as_dict(), "status": "ACTUAL EDA RESULT" if ok else "FAILED", "nets": {}}
        if ok:
            pvs = {}
            for net_name, vnom in ((cfg.power_net, vdd), (cfg.ground_net, 0.0)):
                pv = {canonical_name(i): v for i, (x, y, v) in parse_pdnsim_voltage(d / f"{net_name}_voltage.csv").items()}
                pvs[net_name] = pv
                worst = max(abs(v - vnom) for v in pv.values())
                entry["nets"][net_name] = {"instances": len(pv), "worst_drop_mv": worst * 1e3,
                                           "ms": next(x["ms"] for x in recs if x["net"] == net_name), "comparison": {}}
            for conv in ("pdnsim_watts", "nominal"):
                for attach in ("pin", "pdnsim"):
                    n2, r2, s2 = _solve_case(exp, techs[tname], srcs,
                                             ImportOptions(vdd_v=vdd, current_conversion=conv, attach=attach))
                    for k, (net_name, vnom) in enumerate(((cfg.power_net, vdd), (cfg.ground_net, 0.0))):
                        mine = {i: s2.voltage(nodes[k]) for i, nodes in r2.inst_attach.items() if nodes[k]}
                        entry["nets"][net_name]["comparison"][f"{conv}/{attach}"] = \
                            compare_instance_voltages(mine, pvs[net_name], vnom)
            if label == "odb_tech":
                spice_chk = {}
                for net_name, vnom in ((cfg.power_net, vdd), (cfg.ground_net, 0.0)):
                    sp_path = d / f"{net_name}_pdnsim.sp"
                    if not sp_path.exists():
                        continue
                    sp = parse_pdnsim_spice(sp_path)
                    _, ssol, info = solve_pdnsim_spice(sp, net_name, vnom)
                    pvl = parse_pdnsim_voltage(d / f"{net_name}_voltage.csv")
                    dif = []
                    for inst, (x, y, v) in pvl.items():
                        node = f"{net_name}_{int(round(x * 1000))}_{int(round(y * 1000))}_1"
                        if ssol.network.has_node(node):
                            dif.append(ssol.voltage(node) - v)
                    info["matched_instances"] = len(dif)
                    info["max_abs_diff_v"] = float(np.max(np.abs(dif))) if dif else None
                    info["quantisation_v"] = 0.5e-5 if vnom else None
                    spice_chk[net_name] = info
                    with open(sp_path, "rb") as fh_in, gzip.open(str(sp_path) + ".gz", "wb") as fh_out:
                        shutil.copyfileobj(fh_in, fh_out)
                    sp_path.unlink()
                entry["spice_resolve"] = spice_chk
            for f in d.glob("*_em.csv"):
                with open(f, "rb") as fh_in, gzip.open(str(f) + ".gz", "wb") as fh_out:
                    shutil.copyfileobj(fh_in, fh_out)
                f.unlink()
        runs[label] = entry
    res["runs"] = runs
    return res
