"""PowerGrid engineering dashboard: one self-contained HTML file built from run outputs.

Every panel carries a provenance badge (ACTUAL EDA RESULT / NUMERICAL MODEL /
ASSUMPTION / DEMONSTRATION / NOT RUN / BLOCKED).  A panel whose run directory is
missing shows NOT RUN -- nothing is synthesised to fill it.  Charts use the
validated categorical slots in visualise.SERIES, one y-axis per chart, hover
tooltips, and a data table next to each chart.
"""
from __future__ import annotations

import base64
import html
import json
from pathlib import Path
from typing import Any, Optional

from .gates import evaluate
from .report import CSS, badge, fmt, gate_badge, table
from .visualise import SERIES

SECTIONS = ["Project overview", "Power domains", "PDN connectivity", "Supply sources", "Static IR-drop map",
            "Ground bounce", "Current density", "Layer-by-layer inspection", "CPU / vector / tensor power",
            "SRAM macro power", "Power source sensitivity", "Strap and via optimisation", "Electrothermal studies",
            "Timing risk", "Physical-design validation", "Engineering reports"]


def _load(p: Path) -> Optional[dict[str, Any]]:
    return json.loads(p.read_text()) if p.exists() else None


def _img(path: Optional[str], caption: str) -> str:
    if not path or not Path(path).exists():
        return f"<figure><figcaption>{badge('NOT RUN')} {html.escape(caption)} (file missing)</figcaption></figure>"
    data = base64.b64encode(Path(path).read_bytes()).decode()
    return (f'<figure><img alt="{html.escape(caption)}" src="data:image/png;base64,{data}">'
            f"<figcaption>{html.escape(caption)}</figcaption></figure>")


def _bar(div: str, x: list[str], series: list[tuple[str, list[float]]], ytitle: str, title: str) -> str:
    traces = []
    for k, (name, ys) in enumerate(series):
        traces.append({"type": "bar", "name": name, "x": x, "y": ys, "marker": {"color": SERIES[k % len(SERIES)]},
                       "hovertemplate": f"%{{x}}<br>{html.escape(name)}: %{{y:.4g}} {html.escape(ytitle)}<extra></extra>"})
    layout = {"title": {"text": title, "font": {"size": 13, "color": "#e6ecf5"}}, "barmode": "group", "bargap": 0.25,
              "paper_bgcolor": "#111f42", "plot_bgcolor": "#111f42", "font": {"color": "#c9d3e6", "size": 11},
              "yaxis": {"title": {"text": ytitle}, "gridcolor": "#22325f", "zerolinecolor": "#2c3d6e"},
              "xaxis": {"tickangle": -25}, "showlegend": len(series) > 1, "legend": {"orientation": "h", "y": 1.12},
              "margin": {"l": 60, "r": 20, "t": 50, "b": 90}, "height": 360}
    return f'<div id="{div}" class="plot"></div><script>Plotly.newPlot("{div}",{json.dumps(traces)},{json.dumps(layout)},{{displaylogo:false,responsive:true}});</script>'


def _scatter(div: str, pts: list[dict[str, Any]], xk: str, yk: str, xt: str, yt: str, title: str, front: set[str]) -> str:
    on = [p for p in pts if p["id"] in front]
    off = [p for p in pts if p["id"] not in front]
    traces = []
    for k, (name, ps) in enumerate((("dominated", off), ("Pareto front", on))):
        traces.append({"type": "scatter", "mode": "markers+text", "name": name, "x": [p[xk] for p in ps], "y": [p[yk] for p in ps],
                       "text": [p["label"].split(" [")[0] for p in ps],
                       "texttemplate": [(p["label"].split(" [")[0][:26] if (name == "Pareto front" or p["label"].startswith("baseline")) else "") for p in ps],
                       "textposition": "top center",
                       "textfont": {"size": 9, "color": "#c9d3e6"},
                       "marker": {"size": 11, "color": SERIES[k], "line": {"width": 2, "color": "#111f42"}},
                       "hovertemplate": "%{text}<br>" + f"{xt}: %{{x:.3g}}<br>{yt}: %{{y:.4g}}<extra></extra>"})
    layout = {"title": {"text": title, "font": {"size": 13, "color": "#e6ecf5"}}, "paper_bgcolor": "#111f42",
              "plot_bgcolor": "#111f42", "font": {"color": "#c9d3e6", "size": 11},
              "xaxis": {"title": {"text": xt}, "gridcolor": "#22325f"}, "yaxis": {"title": {"text": yt}, "gridcolor": "#22325f"},
              "legend": {"orientation": "h", "y": 1.12}, "margin": {"l": 60, "r": 20, "t": 50, "b": 50}, "height": 420}
    return f'<div id="{div}" class="plot"></div><script>Plotly.newPlot("{div}",{json.dumps(traces)},{json.dumps(layout)},{{displaylogo:false,responsive:true}});</script>'


def build_dashboard(reports: Path, out: Path) -> str:
    import plotly.offline
    ana_dir = reports / "silicaflux_v" / "analysis"
    ana = _load(ana_dir / "run.json")
    opt = _load(reports / "optimisation" / "pdn_sweep" / "summary.json")
    expd = reports / "experiments" / "silicaflux_v_demo"
    exp = _load(expd / "run.json")
    tr = _load(reports / "transient" / "droop_study" / "run.json")
    gates = evaluate(reports)
    nav = "".join(f'<a href="#s{k+1}">{k+1}. {html.escape(s)}</a>' for k, s in enumerate(SECTIONS))
    P: list[str] = []

    def sec(k: int, status: str, body: str) -> None:
        P.append(f'<section id="s{k}"><h2>{k}. {html.escape(SECTIONS[k-1])} {badge(status)}</h2>{body}</section>')

    # 1 overview
    if ana:
        sm = ana["supply_models"]; dm = next(iter(ana["maps"]))
        d = sm[dm]
        kpis = "".join(f"<div class='kpi'><b>{v}</b><span>{k}</span></div>" for k, v in (
            ("design", ana["design"]), ("worst V_eff (" + dm + ")", f"{d['worst_v_eff_v']:.4f} V"),
            ("worst total loss", f"{d['worst_total_loss_mv']:.2f} mV"), ("load (vectorless)", f"{ana['load_source']['total_power_mw']:.2f} mW"),
            ("PDN wires · vias (extracted)", f"{ana['import']['wires']} · {ana['import']['vias']:,}"),
            ("solver unknowns", f"{d['unknowns']:,}")))
        body = kpis + ("<p class='note'>Static IR analysis of the real SilicaFlux-V placed database (FloorplanLab A_baseline, "
                       "IHP SG13G2). Loads are OpenSTA vectorless estimates; supply taps are assumptions (no pad ring exists). "
                       "Passing these gates demonstrates an analysis capability, not production signoff.</p>")
    else:
        body = "<p>analysis run missing</p>"
    body += "<h3>Engineering quality gates</h3>" + "<table><tr><th>#</th><th>gate</th><th>status</th><th>evidence</th><th>note</th></tr>" + "".join(
        f"<tr><td>{g['gate']}</td><td>{html.escape(g['title'])}</td><td>{gate_badge(g['status'])}</td><td class='mono'>{html.escape(g['evidence'])}</td><td>{html.escape(g['note'])}</td></tr>"
        for g in gates) + "</table>"
    sec(1, "ACTUAL EDA RESULT" if ana else "NOT RUN", body)
    # 2 domains
    sec(2, "ACTUAL EDA RESULT" if ana else "NOT RUN", table([
        {"domain": "CORE", "power net": "VDD", "ground net": "VSS", "nominal": f"{ana['supply']['vdd_nominal_v']} V" if ana else "—",
         "source": ana["supply"]["source"] if ana else "—",
         "members": "all std cells + 12 RM_IHPSG13 SRAM macros (VDD!, VDDARRAY! -> VDD; VSS! -> VSS)"}]) +
        "<p class='note'>Single domain. VDDARRAY! is tied to VDD by the FloorplanLab PDN (assumption recorded there); no "
        "switched, retention or isolated domains exist in sfv_soc_df. PowerLink's UPF variants describe other chips.</p>")
    # 3 connectivity
    if ana:
        body = table(ana["connectivity"]["checks"], ["net", "type", "result", "error_lines"]) + table([{k: ana["import"][k] for k in (
            "wires", "wires_floating", "vias", "vias_dangling", "macro_pin_landings", "std_cells_attached", "macros_attached")}])
        body += "<p class='note'>" + html.escape(" ".join(ana["findings"])) + "</p>"
        body += _img(ana["maps"][dm].get("connectivity_warnings"), "connectivity warnings")
        sec(3, "ACTUAL EDA RESULT", body)
    else:
        sec(3, "NOT RUN", "")
    # 4 supply sources
    if ana:
        x = list(sm.keys())
        body = _bar("p_models", x, [("worst total loss", [sm[m]["worst_total_loss_mv"] for m in x])], "mV",
                    "Worst total supply loss by supply model (ASSUMED taps)")
        body += _bar("p_taps", x, [("max tap current", [sm[m]["max_source_current_ma"] for m in x]),
                                   ("min tap current", [sm[m]["min_source_current_ma"] for m in x])], "mA",
                     "Current sharing between taps")
        body += table([{"model": m, "taps": sm[m]["sources"], "description": sm[m]["description"],
                        "worst_loss_mv": sm[m]["worst_total_loss_mv"]} for m in x])
        sec(4, "ASSUMPTION", body)
    # 5 IR map
    if ana:
        body = "<div class='grid'>" + "".join(_img(ana["maps"][dm].get(k), f"{k} ({dm})") for k in ("ir_drop", "v_eff", "critical_loads", "power_density")) + "</div>"
        others = [(m, v["ir_drop_common_scale"]) for m, v in ana["maps"].items() if m != "layers" and isinstance(v, dict) and "ir_drop_common_scale" in v]
        body += "<h3>All supply models — common colour scale</h3><div class='grid'>" + "".join(_img(p, m) for m, p in others) + "</div>"
        sec(5, "NUMERICAL MODEL", body)
        sec(6, "NUMERICAL MODEL", "<div class='grid'>" + _img(ana["maps"][dm].get("vdd_droop"), "VDD droop") +
            _img(ana["maps"][dm].get("vss_bounce"), "VSS bounce") + "</div>" +
            _bar("p_db", x, [("VDD droop", [sm[m]["worst_vdd_droop_mv"] for m in x]), ("VSS bounce", [sm[m]["worst_vss_bounce_mv"] for m in x])],
                 "mV", "Worst VDD droop and ground bounce per supply model"))
        ls = ana["current_density"]["layers"]
        sec(7, "NUMERICAL MODEL", _bar("p_layers", [l["layer"] for l in ls], [("max branch current", [l["max_current_a"] * 1e3 for l in ls])],
                                        "mA", "Maximum branch current per layer") + table(ls, ["layer", "segments", "max_current_a", "max_j_linear_a_per_m",
                                        "max_current_per_cut_a", "power_w"]) +
            f"<p>EM screening vs LEF DC limits: <b>{html.escape(ana['current_density']['em']['overall'])}</b> "
            f"{fmt(ana['current_density']['em']['counts'])}. {html.escape(ana['current_density']['em']['basis'])}</p>")
        sec(8, "NUMERICAL MODEL", "<div class='grid'>" + "".join(_img(p, k) for k, p in ana["maps"].get("layers", {}).items()) + "</div>")
        g = [r for r in ana["groups"] if r["group"] != "sram_macros"]
        sec(9, "NUMERICAL MODEL", _bar("p_gp", [r["group"] for r in g], [("power (vectorless)", [r["power_mw"] for r in g])], "mW",
                                        "Group power — MODELLED vectorless (vector/tensor near-idle under vectorless propagation)") +
            _bar("p_gl", [r["group"] for r in g], [("worst loss", [r["worst_loss_mv"] or 0 for r in g])], "mV", "Worst total loss per group") + table(ana["groups"]))
    else:
        for k in (5, 6, 7, 8, 9):
            sec(k, "NOT RUN", "")
    # 10 SRAM
    body = ""
    if ana:
        mac = next((r for r in ana["groups"] if r["group"] == "sram_macros"), None)
        body += table([mac] if mac else [])
        body += "<p class='note'>The RM_IHPSG13 Liberty has no access energy on A_CLK: vectorless macro power is pin internal power + leakage only.</p>"
    if exp and "G_sram_heavy" in exp["experiments"]:
        body += f"<p>{html.escape(exp['experiments']['G_sram_heavy']['headline'])}</p>" + _img(exp["experiments"]["G_sram_heavy"].get("map"), "SRAM-heavy (ASSUMED)")
    if exp:
        tc = exp.get("testcore", {})
        body += "<h3>TestCore MBIST / scan modes (DEMONSTRATION)</h3>" + table(tc.get("rows", [])) + f"<p class='note'>{html.escape(tc.get('status', ''))}</p>"
    sec(10, "DEMONSTRATION" if exp else ("NUMERICAL MODEL" if ana else "NOT RUN"), body)
    # 11 sensitivity
    if ana:
        sv = ana["sensitivity"]
        ks = list(sv.keys())
        sec(11, "ASSUMPTION", _bar("p_sens", ks, [("worst total loss", [sv[k]["worst_total_loss_mv"] for k in ks])], "mV",
                                    f"Sensitivity of worst loss ({dm})") + table([{"case": k, **{kk: sv[k][kk] for kk in (
                                        "worst_total_loss_mv", "worst_vdd_droop_mv", "worst_vss_bounce_mv")}} for k in ks]))
    else:
        sec(11, "NOT RUN", "")
    # 12 optimisation
    if opt:
        val = [v for v in opt["variants"] if v.get("status") == "VALID"]
        pts = [{"id": v["id"], "label": v["label"], "x": v["metal5_blockage"] * 100, "y": v["worst_loss_mv"]} for v in val]
        body = _scatter("p_par", pts, "x", "y", "Metal5 signal area blocked [%]", "worst loss WB4 [mV]",
                        "PDN variants regenerated in OpenROAD — Pareto front", set(opt["pareto_loss_vs_metal5"]))
        body += table([{"id": v["id"], "label": v["label"], "status": v.get("status"), "reason": v.get("reason"),
                        "worst_loss_mv": v.get("worst_loss_mv"),
                        "metal5_blockage_%": (v["metal5_blockage"] * 100) if v.get("metal5_blockage") is not None else None,
                        "pdn_metal_um2": v.get("pdn_metal_area_um2"), "via_cuts": v.get("via_cuts_total")} for v in opt["variants"]])
        body += "<h3>Marginal gains vs baseline</h3>" + table(opt["marginal_gains"])
        sec(12, "ACTUAL EDA RESULT", body)
    else:
        sec(12, "NOT RUN", "")
    if exp:
        for key in ("C_strap_pitch", "D_strap_width", "E_via_density"):
            e = exp["experiments"].get(key)
            if e:
                P[-1] = P[-1].replace("</section>", f"<h3>{key} (synthetic trend, IHP LEF data)</h3>" + table(e["rows"], ["sweep", "value", "worst_loss_mv", "mean_loss_mv", "metal5_area_fraction", "tm1_area_fraction"]) + "</section>")
        crowd = exp["experiments"].get("E_via_density", {}).get("via_current_crowding")
        if crowd:
            P[-1] = P[-1].replace("</section>", "<h3>Via-array current crowding (resolved model)</h3>" + table(crowd) + "</section>")
    # 13 electrothermal
    if exp:
        j = exp["experiments"].get("J_temperature", {})
        body = f"<p>{html.escape(j.get('status', ''))}</p>" + table(j.get("rows", []))
        if tr:
            body += "<h3>Dynamic droop research (lumped RLC, ASSUMED)</h3>" + table(tr["rows"], ["event", "decap_scale", "i0_ma", "i1_ma", "v_min", "first_droop_v", "droop_duration_s", "recovery_time_s", "ringing_hz"])
            body += f"<p class='note'>ngspice cross-check: {fmt(tr['summary']['ngspice_crosscheck'])}</p>"
            body += _img(str(reports / "transient" / "droop_study" / "droop.png"), "droop traces")
        sec(13, "DEMONSTRATION", body)
    else:
        sec(13, "NOT RUN", "")
    # 14 timing
    if ana:
        tm = ana["timing"]
        sec(14, "NUMERICAL MODEL", f"<p>{html.escape(str(tm.get('label')))}. Voltage-aware STA: {gate_badge(tm['voltage_aware_sta']['status'])} "
            f"{html.escape(str(tm['voltage_aware_sta']['reason']))}</p>" + table(tm.get("rows", []), ["startpoint", "endpoint", "slack_ns", "group",
            "v_eff_start", "v_eff_end", "supply_loss_mv", "flags", "timing_effect"]))
    else:
        sec(14, "NOT RUN", "")
    # 15 validation
    if ana and ana.get("pdnsim"):
        rows = []
        for lab, r in ana["pdnsim"]["runs"].items():
            for net, v in r["nets"].items():
                for case, c in v["comparison"].items():
                    rows.append({"resistance": lab, "net": net, "case": case, "mine_mV": c["worst_drop_mine_v"] * 1e3,
                                 "pdnsim_mV": c["worst_drop_pdnsim_v"] * 1e3, "rel_diff_%": c["worst_drop_rel_diff"] * 100,
                                 "rms_uV": c["rms_diff_v"] * 1e6, "corr": c["correlation"], "status": c["status"]})
        sr = ana["pdnsim"]["runs"].get("odb_tech", {}).get("spice_resolve", {})
        sec(15, "ACTUAL EDA RESULT", table(rows) + "<ul>" + "".join(f"<li>{html.escape(x)}</li>" for x in ana["pdnsim"]["limitations"]) + "</ul>" +
            "<h3>write_pg_spice network re-solved</h3>" + table([{"net": k, **v} for k, v in sr.items()]))
    else:
        sec(15, "NOT RUN", "")
    # 16 reports
    links = []
    for p in sorted(reports.rglob("report.html")):
        links.append(f"<li><a href='{html.escape(p.relative_to(out.parent).as_posix() if out.parent in p.parents else str(p))}'>{html.escape(str(p.relative_to(reports)))}</a></li>")
    sec(16, "ACTUAL EDA RESULT" if links else "NOT RUN", "<ul>" + "".join(links) + "</ul><p class='note'>Raw outputs (CSV, JSON, logs, PDNSim files) live next to each report.</p>")

    page = (f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>PowerGrid Dashboard</title><style>{CSS}nav{{display:flex;flex-wrap:wrap;gap:6px 14px;padding:10px 32px;background:#0e1a39;"
            f"position:sticky;top:0;z-index:5;border-bottom:1px solid #22325f}}nav a{{color:#9fb3d9;text-decoration:none;font-size:12px}}"
            f"nav a:hover{{color:#c9a227}}section{{scroll-margin-top:60px}}.plot{{width:100%;max-width:980px}}</style>"
            f"<script>{plotly.offline.get_plotlyjs()}</script></head><body>"
            f"<header><h1>SilicaFlux PowerGrid</h1><div class='note'>Aureom.AI · SilicaFlux Semiconductor Engineering · "
            f"Project 08 — power distribution, static IR drop, current density. Status vocabulary: "
            + " ".join(badge(s) for s in ("ACTUAL EDA RESULT", "NUMERICAL MODEL", "ASSUMPTION", "DEMONSTRATION", "NOT RUN", "BLOCKED")) +
            f"</div></header><nav>{nav}</nav><main>" + "\n".join(P) + "</main></body></html>")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(page)
    return str(out)
