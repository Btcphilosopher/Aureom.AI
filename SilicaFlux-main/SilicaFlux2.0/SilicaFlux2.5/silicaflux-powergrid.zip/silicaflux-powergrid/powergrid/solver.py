"""Sparse DC nodal-analysis solver for resistive power-distribution networks.

Method
------
1. Extend the network with one internal ideal node per supply source that has
   a series resistance (package / bond wire / bump); sources without series
   resistance fix their node directly (Dirichlet boundary condition).
2. Merge zero-resistance edges into supernodes (exact shorts, no huge
   conductances).
3. Detect voltage-source conflicts (two different prescribed voltages on one
   supernode), floating components (no voltage reference) and disconnected
   sub-networks.  A loaded floating component is an error; an unloaded one is
   reported and left at an UNDEFINED (NaN) voltage only if explicitly allowed.
4. Eliminate the prescribed supernodes and solve G_UU v_U = i_U - G_UF v_F with
   SciPy SuperLU (direct) or preconditioned conjugate gradients (iterative).
5. Reconstruct every branch current (I = (V_a - V_b)/R; zero-resistance
   branches by a minimum-norm KCL solve), every source current, and verify
   Kirchhoff's current law at every node and the global power balance.

Constant-power loads are solved by damped fixed-point iteration on the local
effective voltage, reusing one LU factorisation; non-convergence and voltage
collapse are reported, never hidden.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .conductance import assemble_conductance, build_topology, conductance_ratio
from .graph import Load, LoadModel, Network, NetType

__all__ = [
    "SolverError",
    "FloatingNetworkError",
    "VoltageSourceConflictError",
    "SingularNetworkError",
    "NonConvergenceError",
    "VoltageCollapseError",
    "SolverOptions",
    "DCSolution",
    "solve",
]

SOLVER_VERSION = "powergrid-dc 1.0.0"


class SolverError(RuntimeError):
    """Base class: the network could not be solved; ``reason`` says why."""

    def __init__(self, reason: str, details: Optional[dict[str, Any]] = None) -> None:
        super().__init__(reason)
        self.reason = reason
        self.details = details or {}


class FloatingNetworkError(SolverError):
    pass


class VoltageSourceConflictError(SolverError):
    pass


class SingularNetworkError(SolverError):
    pass


class NonConvergenceError(SolverError):
    pass


class VoltageCollapseError(SolverError):
    pass


@dataclass
class SolverOptions:
    method: str = "direct"              # direct | cg | auto
    iterative_rtol: float = 1e-12
    iterative_maxiter: int = 20000
    preconditioner: str = "jacobi"      # jacobi | ilu | none
    kcl_rtol: float = 1e-9              # KCL residual relative to total supplied current
    power_rtol: float = 1e-9            # power-balance error relative to source power
    allow_unloaded_floating: bool = False
    source_conflict_tol_v: float = 1e-12
    # constant-power iteration
    fp_max_iter: int = 200
    fp_vtol: float = 1e-9               # V
    fp_damping: float = 1.0
    collapse_fraction: float = 0.5      # V_eff below this fraction of nominal => collapse
    auto_direct_limit: int = 2_000_000  # unknowns above which 'auto' uses CG


@dataclass
class FloatingComponent:
    net: str
    n_nodes: int
    sample_nodes: list[str]
    loaded: bool


@dataclass
class DCSolution:
    network: Network
    node_voltage: np.ndarray            # per network node; NaN = undefined (floating, unloaded)
    segment_current: np.ndarray         # per segment, a -> b positive
    segment_current_unique: np.ndarray  # False for zero-R branches inside loops (min-norm split)
    source_current: dict[str, float]    # out of the source into the network
    source_series_current: dict[str, float]
    load_current: np.ndarray            # per load (A), as finally applied
    load_v_vdd: np.ndarray
    load_v_vss: np.ndarray              # 0 for ideal-return loads
    load_ideal_return: np.ndarray
    metrics: dict[str, Any]
    floating: list[FloatingComponent] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    kcl_residual: np.ndarray = field(default_factory=lambda: np.zeros(0))

    # ---------------------------------------------------------------- views
    @property
    def load_v_eff(self) -> np.ndarray:
        return self.load_v_vdd - self.load_v_vss

    def voltage(self, node_id: str) -> float:
        return float(self.node_voltage[self.network.node_index(node_id)])

    def current(self, seg_index: int) -> float:
        return float(self.segment_current[seg_index])

    def load_table(self) -> list[dict[str, Any]]:
        rows = []
        for k, ld in enumerate(self.network.loads):
            vdd_nom = self.network.nets[self.network.node_net[self.network.node_index(ld.vdd_node)]].nominal_voltage_v
            if ld.vss_node is not None:
                vss_nom = self.network.nets[self.network.node_net[self.network.node_index(ld.vss_node)]].nominal_voltage_v
            else:
                vss_nom = 0.0
            v_eff = self.load_v_vdd[k] - self.load_v_vss[k]
            rows.append({
                "load": ld.name,
                "block": ld.block,
                "model": ld.model.value,
                "provenance": ld.provenance,
                "current_a": float(self.load_current[k]),
                "v_vdd": float(self.load_v_vdd[k]),
                "v_vss": float(self.load_v_vss[k]),
                "v_eff": float(v_eff),
                "vdd_droop_v": float(vdd_nom - self.load_v_vdd[k]),
                "ground_bounce_v": float(self.load_v_vss[k] - vss_nom),
                "total_loss_v": float((vdd_nom - vss_nom) - v_eff),
                "power_w": float(self.load_current[k] * v_eff),
                "ideal_return": bool(self.load_ideal_return[k]),
            })
        return rows

    def segment_power(self) -> np.ndarray:
        r = np.asarray(self.network.seg_r)
        return self.segment_current ** 2 * r


# ----------------------------------------------------------------------------------
def _canonical_rank(ids: list[str]) -> np.ndarray:
    arr = np.asarray(ids, dtype=object)
    order = np.argsort(arr.astype(str), kind="stable")
    rank = np.empty(len(ids), dtype=np.int64)
    rank[order] = np.arange(len(ids))
    return rank


@dataclass
class _Prepared:
    n0: int
    n_ext: int
    a: np.ndarray
    b: np.ndarray
    r: np.ndarray
    seg_count: int
    src_edge: dict[int, int]            # source index -> extended edge index (series-R sources)
    fixed_ext: list[tuple[int, float, int]]  # (extended node, voltage, source index)
    topo: Any
    fixed_super: dict[int, float]
    unknown: np.ndarray                 # supernode ids that are unknowns (defined)
    fixed: np.ndarray
    floating_super: np.ndarray
    floating: list[FloatingComponent]
    G: sp.csr_matrix
    G_UU: sp.csc_matrix
    G_UF: sp.csr_matrix
    v_fixed: np.ndarray
    pos_in_unknown: np.ndarray          # supernode -> position in unknown vector (-1)
    warnings: list[str]


def _prepare(net: Network, opts: SolverOptions) -> _Prepared:
    warnings: list[str] = []
    n0 = net.n_nodes
    if n0 == 0:
        raise SolverError("empty network: no nodes")
    if not net.sources:
        raise FloatingNetworkError(
            "network has no voltage source: every node is floating (no voltage reference)",
            {"nodes": n0},
        )
    arr = net.arrays()
    a_list = [arr["a"]]
    b_list = [arr["b"]]
    r_list = [arr["r"]]
    src_edge: dict[int, int] = {}
    fixed_ext: list[tuple[int, float, int]] = []
    n_ext = n0
    e = net.n_segments
    for k, s in enumerate(net.sources):
        node = net.node_index(s.node)
        if s.series_resistance_ohm > 0:
            internal = n_ext
            n_ext += 1
            a_list.append(np.array([internal]))
            b_list.append(np.array([node]))
            r_list.append(np.array([s.series_resistance_ohm]))
            src_edge[k] = e
            e += 1
            fixed_ext.append((internal, s.voltage_v, k))
        else:
            fixed_ext.append((node, s.voltage_v, k))
    a = np.concatenate(a_list).astype(np.int64)
    b = np.concatenate(b_list).astype(np.int64)
    r = np.concatenate(r_list).astype(float)

    rank = np.empty(n_ext, dtype=np.int64)
    rank[:n0] = _canonical_rank(net.node_ids)
    # internal source nodes rank after all network nodes, in source order
    rank[n0:] = n0 + np.arange(n_ext - n0)
    topo = build_topology(n_ext, a, b, r, rank)
    if topo.internal_loop_edges:
        warnings.append(
            f"{len(topo.internal_loop_edges)} positive-resistance branch(es) lie inside a "
            "zero-resistance cluster; they carry no current"
        )

    # ---- prescribed voltages and conflicts
    fixed_super: dict[int, float] = {}
    fixed_by: dict[int, list[str]] = {}
    for ext_node, v, k in fixed_ext:
        sid = int(topo.super_of[ext_node])
        fixed_by.setdefault(sid, []).append(net.sources[k].name)
        if sid in fixed_super and abs(fixed_super[sid] - v) > opts.source_conflict_tol_v:
            raise VoltageSourceConflictError(
                f"voltage-source conflict: sources {fixed_by[sid]} prescribe different voltages "
                f"({fixed_super[sid]} V vs {v} V) on the same electrical node",
                {"sources": fixed_by[sid]},
            )
        fixed_super[sid] = v

    # ---- floating components
    comp = topo.component
    comp_has_fixed = np.zeros(topo.n_components, dtype=bool)
    for sid in fixed_super:
        comp_has_fixed[comp[sid]] = True
    loaded_super = np.zeros(topo.n_super, dtype=bool)
    for ld in net.loads:
        loaded_super[topo.super_of[net.node_index(ld.vdd_node)]] = True
        if ld.vss_node is not None:
            loaded_super[topo.super_of[net.node_index(ld.vss_node)]] = True
    for inj in net.injections:
        if inj.current_a != 0.0:
            loaded_super[topo.super_of[net.node_index(inj.node)]] = True
    floating: list[FloatingComponent] = []
    floating_comp_ids = np.nonzero(~comp_has_fixed)[0]
    floating_super_mask = np.isin(comp, floating_comp_ids)
    if floating_comp_ids.size:
        super_net_node = np.full(topo.n_super, -1, dtype=np.int64)
        # one representative network node per supernode (first occurrence)
        ext_ids = np.arange(n0)
        sup0 = topo.super_of[:n0]
        first = np.full(topo.n_super, -1, dtype=np.int64)
        order = np.argsort(sup0, kind="stable")
        sorted_sup = sup0[order]
        uniq, idx = np.unique(sorted_sup, return_index=True)
        first[uniq] = ext_ids[order][idx]
        super_net_node = first
        for cid in floating_comp_ids:
            members = np.nonzero(comp == cid)[0]
            nodes = [int(super_net_node[m]) for m in members if super_net_node[m] >= 0]
            sample = [net.node_ids[i] for i in nodes[:5]]
            nets = sorted({net.node_net[i] for i in nodes})
            n_members = int(np.isin(topo.super_of[:n0], members).sum())
            floating.append(FloatingComponent(
                net=",".join(nets), n_nodes=n_members, sample_nodes=sample,
                loaded=bool(loaded_super[members].any()),
            ))
        loaded = [f for f in floating if f.loaded]
        if loaded or not opts.allow_unloaded_floating:
            fl = loaded or floating
            raise FloatingNetworkError(
                f"{len(floating)} floating component(s) without a voltage reference "
                f"({sum(1 for f in floating if f.loaded)} carry load current); e.g. net "
                f"{fl[0].net}, {fl[0].n_nodes} node(s) such as {fl[0].sample_nodes}. The network is "
                "electrically underconstrained; no conductance to ground is added.",
                {"components": [f.__dict__ for f in floating]},
            )
        warnings.append(
            f"{len(floating)} unloaded floating component(s) ({sum(f.n_nodes for f in floating)} nodes) "
            "excluded; their voltages are UNDEFINED (NaN)"
        )

    fixed = np.array(sorted(fixed_super), dtype=np.int64)
    is_fixed = np.zeros(topo.n_super, dtype=bool)
    is_fixed[fixed] = True
    unknown = np.nonzero(~is_fixed & ~floating_super_mask)[0]
    G = assemble_conductance(topo.n_super, topo.edge_sa, topo.edge_sb, topo.edge_g)
    G_UU = G[unknown][:, unknown].tocsc()
    G_UF = G[unknown][:, fixed].tocsr()
    v_fixed = np.array([fixed_super[int(s)] for s in fixed], dtype=float)
    pos = np.full(topo.n_super, -1, dtype=np.int64)
    pos[unknown] = np.arange(unknown.size)
    return _Prepared(
        n0=n0, n_ext=n_ext, a=a, b=b, r=r, seg_count=net.n_segments, src_edge=src_edge,
        fixed_ext=fixed_ext, topo=topo, fixed_super=fixed_super, unknown=unknown, fixed=fixed,
        floating_super=np.nonzero(floating_super_mask)[0], floating=floating, G=G, G_UU=G_UU,
        G_UF=G_UF, v_fixed=v_fixed, pos_in_unknown=pos, warnings=warnings,
    )


class _LinearSolver:
    """Factorise once, solve many right-hand sides."""

    def __init__(self, A: sp.csc_matrix, opts: SolverOptions) -> None:
        self.A = A
        self.opts = opts
        n = A.shape[0]
        method = opts.method
        if method == "auto":
            method = "direct" if n <= opts.auto_direct_limit else "cg"
        self.method = method
        self.iterations: list[int] = []
        t0 = time.perf_counter()
        self.lu = None
        self.M = None
        if n == 0:
            self.factor_time = 0.0
            return
        diag = A.diagonal()
        if np.any(diag <= 0):
            raise SingularNetworkError("conductance matrix has a non-positive diagonal entry")
        if method == "direct":
            try:
                self.lu = spla.splu(A, permc_spec="COLAMD")
            except RuntimeError as exc:
                raise SingularNetworkError(f"sparse LU factorisation failed: {exc}") from exc
        elif method == "cg":
            if opts.preconditioner == "jacobi":
                inv = 1.0 / diag
                self.M = spla.LinearOperator(A.shape, matvec=lambda x: inv * x)
            elif opts.preconditioner == "ilu":
                ilu = spla.spilu(A, drop_tol=1e-5, fill_factor=10)
                self.M = spla.LinearOperator(A.shape, matvec=ilu.solve)
        else:
            raise SolverError(f"unknown solver method {method!r}")
        self.factor_time = time.perf_counter() - t0

    def solve(self, rhs: np.ndarray) -> np.ndarray:
        if rhs.size == 0:
            return rhs.copy()
        if self.lu is not None:
            x = self.lu.solve(rhs)
        else:
            count = [0]

            def cb(_xk: np.ndarray) -> None:
                count[0] += 1

            x, info = spla.cg(self.A, rhs, rtol=self.opts.iterative_rtol, atol=0.0,
                              maxiter=self.opts.iterative_maxiter, M=self.M, callback=cb)
            self.iterations.append(count[0])
            if info != 0:
                raise NonConvergenceError(
                    f"conjugate-gradient solver did not converge in {count[0]} iterations "
                    f"(info={info}, rtol={self.opts.iterative_rtol})",
                    {"iterations": count[0]},
                )
        if not np.all(np.isfinite(x)):
            raise SingularNetworkError("solution contains non-finite values (numerically singular matrix)")
        return np.asarray(x)


def _injection_vector(net: Network, prep: _Prepared, load_currents: np.ndarray) -> np.ndarray:
    """Current injected into every supernode (A, positive into the node)."""
    inj = np.zeros(prep.topo.n_super)
    sup = prep.topo.super_of
    for k, ld in enumerate(net.loads):
        i = load_currents[k]
        inj[sup[net.node_index(ld.vdd_node)]] -= i
        if ld.vss_node is not None:
            inj[sup[net.node_index(ld.vss_node)]] += i
    for injn in net.injections:
        inj[sup[net.node_index(injn.node)]] += injn.current_a
    return inj


def _solve_linear(net: Network, prep: _Prepared, lin: _LinearSolver, load_currents: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    inj = _injection_vector(net, prep, load_currents)
    rhs = inj[prep.unknown] - prep.G_UF @ prep.v_fixed
    v_u = lin.solve(rhs)
    v_super = np.full(prep.topo.n_super, np.nan)
    v_super[prep.fixed] = prep.v_fixed
    v_super[prep.unknown] = v_u
    res = prep.G_UU @ v_u - rhs if v_u.size else np.zeros(0)
    res_inf = float(np.max(np.abs(res))) if res.size else 0.0
    return v_super, inj, res_inf


def _load_voltages(net: Network, prep: _Prepared, v_super: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    sup = prep.topo.super_of
    vdd = np.array([v_super[sup[net.node_index(l.vdd_node)]] for l in net.loads], dtype=float)
    vss = np.array([0.0 if l.vss_node is None else v_super[sup[net.node_index(l.vss_node)]] for l in net.loads], dtype=float)
    return vdd, vss


def _initial_currents(net: Network) -> np.ndarray:
    cur = np.zeros(len(net.loads))
    for k, ld in enumerate(net.loads):
        if ld.model is LoadModel.FIXED_CURRENT:
            cur[k] = ld.current_a or 0.0
        else:
            vnom = _nominal_veff(net, ld)
            cur[k] = (ld.power_w or 0.0) / vnom
    return cur


def _nominal_veff(net: Network, ld: Load) -> float:
    vdd = net.nets[net.node_net[net.node_index(ld.vdd_node)]].nominal_voltage_v
    vss = 0.0 if ld.vss_node is None else net.nets[net.node_net[net.node_index(ld.vss_node)]].nominal_voltage_v
    v = vdd - vss
    if v <= 0:
        raise SolverError(f"load {ld.name}: non-positive nominal supply {v} V")
    return v


def _reconstruct_currents(net: Network, prep: _Prepared, v_super: np.ndarray, inj_super: np.ndarray,
                          load_currents: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict[str, float], np.ndarray]:
    """Branch currents for all extended edges + ideal-source currents + per-node KCL residual."""
    a, b, r = prep.a, prep.b, prep.r
    sup = prep.topo.super_of
    v_ext = v_super[sup]
    I = np.full(a.size, np.nan)
    unique = np.ones(a.size, dtype=bool)
    pos = r > 0
    I[pos] = (v_ext[a[pos]] - v_ext[b[pos]]) / r[pos]
    # branches in floating components carry zero current by construction (no load); mark exact
    floating_nodes = np.isin(sup, prep.floating_super)
    fl_edges = pos & floating_nodes[a]
    I[fl_edges] = 0.0
    # positive-R branches inside one supernode carry no current
    for e in prep.topo.internal_loop_edges:
        I[e] = 0.0

    # external injection at every extended node (loads/injections act on network nodes)
    n_ext = prep.n_ext
    inj_ext = np.zeros(n_ext)
    for k, ld in enumerate(net.loads):
        inj_ext[net.node_index(ld.vdd_node)] -= load_currents[k]
        if ld.vss_node is not None:
            inj_ext[net.node_index(ld.vss_node)] += load_currents[k]
    for injn in net.injections:
        inj_ext[net.node_index(injn.node)] += injn.current_a

    # ideal sources: extended node fixed directly by a source (R==0 sources or internal nodes)
    src_at: dict[int, list[int]] = {}
    for ext_node, _v, k in prep.fixed_ext:
        src_at.setdefault(ext_node, []).append(k)

    # outflow through known branches at each extended node
    out = np.zeros(n_ext)
    known = ~np.isnan(I)
    np.add.at(out, a[known], I[known])
    np.add.at(out, b[known], -I[known])

    source_current: dict[str, float] = {}
    zero = np.nonzero(r == 0.0)[0]
    # clusters needing reconstruction: supernodes with zero-R edges, or with >1 ideal source
    cluster_nodes: dict[int, list[int]] = {}
    for e in zero:
        cluster_nodes.setdefault(int(sup[a[e]]), [])
    for ext_node, ks in src_at.items():
        cluster_nodes.setdefault(int(sup[ext_node]), [])
    if cluster_nodes:
        members_all = np.nonzero(np.isin(sup, list(cluster_nodes)))[0]
        for mm in members_all:
            cluster_nodes[int(sup[mm])].append(int(mm))
    zero_by_cluster: dict[int, list[int]] = {}
    for e in zero:
        zero_by_cluster.setdefault(int(sup[a[e]]), []).append(int(e))

    for sid, members in cluster_nodes.items():
        zedges = zero_by_cluster.get(sid, [])
        srcs = [(m, k) for m in members for k in src_at.get(m, [])]
        if not zedges and len(srcs) <= 1:
            if srcs:
                m, k = srcs[0]
                # source current = outflow through branches - external injection at the node
                source_current[net.sources[k].name] = float(out[m] - inj_ext[m])
            continue
        if sid in set(int(s) for s in prep.floating_super):
            for ze in zedges:
                I[ze] = 0.0
            continue
        # unknowns: zero-R branch currents (a->b) and ideal source currents (into node)
        idx = {m: i for i, m in enumerate(members)}
        ncol = len(zedges) + len(srcs)
        A = np.zeros((len(members), ncol))
        for j, ze in enumerate(zedges):
            A[idx[int(a[ze])], j] += 1.0     # leaves a
            A[idx[int(b[ze])], j] -= 1.0     # enters b
        for j, (m, _k) in enumerate(srcs):
            A[idx[m], len(zedges) + j] -= 1.0  # source current enters m
        # KCL: (outflow known) + (outflow zero-R) - (source in) - injection = 0
        rhs = np.array([inj_ext[m] - out[m] for m in members])
        sol, *_ = np.linalg.lstsq(A, rhs, rcond=None)
        rank = np.linalg.matrix_rank(A) if A.size else 0
        nonunique = rank < ncol
        for j, ze in enumerate(zedges):
            I[ze] = sol[j]
            unique[ze] = not nonunique
        for j, (m, k) in enumerate(srcs):
            source_current[net.sources[k].name] = float(sol[len(zedges) + j])
        if nonunique:
            prep.warnings.append(
                f"zero-resistance cluster with {len(members)} nodes contains loops or parallel ideal "
                "sources: branch/source current split is not unique (minimum-norm split reported)"
            )

    # series-R sources: current out of the source = current in the series edge (internal -> node)
    for k, e in prep.src_edge.items():
        source_current[net.sources[k].name] = float(I[e])

    # per-network-node KCL residual: outflow - injection - source inflow = 0
    out_all = np.zeros(n_ext)
    ok = ~np.isnan(I)
    np.add.at(out_all, a[ok], I[ok])
    np.add.at(out_all, b[ok], -I[ok])
    src_in = np.zeros(n_ext)
    for ext_node, _v, k in prep.fixed_ext:
        if k in prep.src_edge:
            continue  # internal node: current leaves through the series edge
        src_in[ext_node] += source_current.get(net.sources[k].name, 0.0)
    kcl = out_all - inj_ext - src_in
    # internal source nodes: outflow equals the source current by definition
    for k, e in prep.src_edge.items():
        kcl[prep.a[e]] = 0.0
    kcl[floating_nodes] = 0.0
    return I, unique, source_current, kcl[: prep.n0]


def solve(net: Network, opts: Optional[SolverOptions] = None) -> DCSolution:
    """Solve the DC operating point of ``net``.  Raises :class:`SolverError` subclasses."""
    opts = opts or SolverOptions()
    t_start = time.perf_counter()
    prep = _prepare(net, opts)
    t_prep = time.perf_counter() - t_start
    lin = _LinearSolver(prep.G_UU, opts)

    currents = _initial_currents(net)
    fixed_power = [k for k, ld in enumerate(net.loads)
                   if ld.model is LoadModel.FIXED_POWER and ld.conversion_voltage == "local"]
    iterations = 0
    fp_history: list[float] = []
    t0 = time.perf_counter()
    v_super, inj, res_inf = _solve_linear(net, prep, lin, currents)
    if fixed_power:
        fp_idx = np.array(fixed_power)
        power = np.array([net.loads[k].power_w or 0.0 for k in fixed_power])
        vnom = np.array([_nominal_veff(net, net.loads[k]) for k in fixed_power])
        converged = False
        prev_veff: Optional[np.ndarray] = None
        for it in range(1, opts.fp_max_iter + 1):
            iterations = it
            vdd, vss = _load_voltages(net, prep, v_super)
            veff = (vdd - vss)[fp_idx]
            if np.any(~np.isfinite(veff)) or np.any(veff <= opts.collapse_fraction * vnom):
                worst = int(np.nanargmin(veff / vnom))
                raise VoltageCollapseError(
                    f"voltage collapse: constant-power load {net.loads[fixed_power[worst]].name} sees "
                    f"{veff[worst]:.6g} V (< {opts.collapse_fraction:.0%} of nominal {vnom[worst]} V) "
                    f"at iteration {it}; the requested power cannot be delivered through this network",
                    {"iteration": it, "v_eff": float(veff[worst])},
                )
            if prev_veff is not None:
                dv = float(np.max(np.abs(veff - prev_veff)))
                fp_history.append(dv)
                if dv < opts.fp_vtol:
                    converged = True
                    break
                if len(fp_history) > 20 and fp_history[-1] > fp_history[-2] > fp_history[-3] > 0:
                    raise VoltageCollapseError(
                        "constant-power iteration diverging (voltage updates growing): operating "
                        "point beyond the maximum transferable power", {"history": fp_history[-10:]},
                    )
            prev_veff = veff
            new_i = power / veff
            currents[fp_idx] = (1 - opts.fp_damping) * currents[fp_idx] + opts.fp_damping * new_i
            v_super, inj, res_inf = _solve_linear(net, prep, lin, currents)
        if not converged:
            raise NonConvergenceError(
                f"constant-power iteration did not converge in {opts.fp_max_iter} iterations "
                f"(last update {fp_history[-1] if fp_history else float('nan'):.3e} V)",
                {"history": fp_history},
            )
    t_solve = time.perf_counter() - t0

    I_ext, unique_ext, source_current, kcl = _reconstruct_currents(net, prep, v_super, inj, currents)
    v_nodes = v_super[prep.topo.super_of[: prep.n0]]
    seg_I = I_ext[: prep.seg_count]
    seg_unique = unique_ext[: prep.seg_count]
    vdd, vss = _load_voltages(net, prep, v_super)
    ideal_ret = np.array([l.vss_node is None for l in net.loads], dtype=bool)

    # ---------------------------------------------------------------- conservation checks
    p_src = sum(s.voltage_v * source_current[s.name] for s in net.sources)
    p_diss = float(np.nansum(I_ext[prep.r > 0] ** 2 * prep.r[prep.r > 0]))
    p_load = float(np.sum(currents * (vdd - vss))) if net.loads else 0.0
    p_inj = 0.0
    for injn in net.injections:
        p_inj += injn.current_a * float(v_super[prep.topo.super_of[net.node_index(injn.node)]])
    supplied = sum(abs(c) for c in source_current.values()) + sum(abs(j.current_a) for j in net.injections)
    supplied = max(supplied, 1e-300)
    kcl_max = float(np.max(np.abs(kcl))) if kcl.size else 0.0
    # Floating-point noise floor of a branch current I = (Va - Vb) * g: each term carries
    # an absolute error ~ eps * |V| * g, summed over the node degree.
    eps = np.finfo(float).eps
    g_max = float(prep.topo.edge_g.max()) if prep.topo.edge_g.size else 0.0
    v_max = float(np.max(np.abs(prep.v_fixed))) if prep.v_fixed.size else 0.0
    deg = np.bincount(np.concatenate([prep.topo.edge_sa, prep.topo.edge_sb]), minlength=prep.topo.n_super)
    deg_max = int(deg.max()) if deg.size else 0
    i_floor = 8.0 * max(deg_max, 1) * eps * g_max * max(v_max, 1e-3)
    n_terms = len(net.sources) + len(net.loads) + len(net.injections)
    p_floor = i_floor * max(v_max, 1e-3) * max(n_terms, 1)
    p_ref = max(abs(p_src) + abs(p_inj), 1e-300)
    p_err = (p_src + p_inj) - (p_diss + p_load)
    # normwise backward error of the linear solve
    gnorm = float(abs(prep.G_UU).sum(axis=1).max()) if prep.G_UU.nnz else 0.0
    v_u = v_super[prep.unknown]
    rhs_norm = float(np.max(np.abs(prep.G_UU @ v_u))) if v_u.size else 0.0
    backward = res_inf / max(gnorm * (float(np.max(np.abs(v_u))) if v_u.size else 0.0) + rhs_norm, 1e-300)
    net_source_current = sum(source_current.values()) + sum(j.current_a for j in net.injections)
    ideal_return_current = float(np.sum(currents[ideal_ret])) if net.loads else 0.0

    metrics: dict[str, Any] = {
        "solver_version": SOLVER_VERSION,
        "method": lin.method,
        "preconditioner": opts.preconditioner if lin.method == "cg" else None,
        "network_nodes": prep.n0,
        "extended_nodes": prep.n_ext,
        "supernodes": int(prep.topo.n_super),
        "unknowns": int(prep.unknown.size),
        "fixed_supernodes": int(prep.fixed.size),
        "matrix_nnz": int(prep.G_UU.nnz),
        "components": int(prep.topo.n_components),
        "floating_components": len(prep.floating),
        "zero_resistance_merges": int(prep.n_ext - prep.topo.n_super),
        "conductance_ratio": conductance_ratio(prep.topo.edge_g),
        "residual_inf_A": res_inf,
        "residual_backward_error": backward,
        "kcl_max_abs_A": kcl_max,
        "kcl_rel": kcl_max / supplied,
        "kcl_noise_floor_A": i_floor,
        "kcl_ok": kcl_max <= opts.kcl_rtol * supplied + i_floor,
        "global_current_balance_A": float(net_source_current - ideal_return_current),
        "power_source_W": float(p_src),
        "power_injections_W": float(p_inj),
        "power_dissipated_W": p_diss,
        "power_load_W": p_load,
        "power_balance_error_W": float(p_err),
        "power_balance_rel": float(abs(p_err) / p_ref),
        "power_noise_floor_W": p_floor,
        "power_ok": abs(p_err) <= opts.power_rtol * p_ref + p_floor,
        "fixed_power_loads": len(fixed_power),
        "fixed_point_iterations": iterations,
        "fixed_point_history_V": fp_history,
        "cg_iterations": lin.iterations,
        "time_prepare_s": t_prep,
        "time_factor_s": lin.factor_time,
        "time_solve_s": t_solve,
        "ideal_return_loads": int(ideal_ret.sum()),
    }
    warnings = list(prep.warnings)
    if ideal_ret.any():
        warnings.append(
            f"{int(ideal_ret.sum())} load(s) return current to an ideal 0 V reference (ground network not modelled)"
        )
    if not metrics["kcl_ok"]:
        warnings.append(f"KCL residual {kcl_max:.3e} A exceeds tolerance")
    if not metrics["power_ok"]:
        warnings.append(f"power balance error {p_err:.3e} W exceeds tolerance")
    if net.loads:
        vnoms = np.array([_nominal_veff(net, l) for l in net.loads])
        veff_all = vdd - vss
        n_bad = int(np.sum(veff_all <= 0.0))
        n_low = int(np.sum(veff_all < 0.9 * vnoms))
        metrics["loads_nonpositive_veff"] = n_bad
        metrics["loads_below_90pct_nominal"] = n_low
        metrics["model_valid"] = n_bad == 0 and not np.any(veff_all < opts.collapse_fraction * vnoms)
        if n_bad:
            warnings.append(f"{n_bad} load(s) have V_eff <= 0: fixed-current loads beyond any physical operating point "
                            "(the network cannot deliver this current) -- result INVALID")
        elif not metrics["model_valid"]:
            warnings.append("some loads below the collapse fraction of nominal: linear fixed-current result outside "
                            "its validity; use constant-power loads to detect collapse")
        if n_low:
            warnings.append(f"{n_low} load(s) below 90 % of nominal supply")
    if metrics["conductance_ratio"] > 1e12:
        warnings.append(f"conductance ratio {metrics['conductance_ratio']:.2e}: poorly conditioned network")
    return DCSolution(
        network=net,
        node_voltage=v_nodes,
        segment_current=seg_I,
        segment_current_unique=seg_unique,
        source_current={s.name: source_current[s.name] for s in net.sources},
        source_series_current={net.sources[k].name: float(I_ext[e]) for k, e in prep.src_edge.items()},
        load_current=currents,
        load_v_vdd=vdd,
        load_v_vss=vss,
        load_ideal_return=ideal_ret,
        metrics=metrics,
        floating=prep.floating,
        warnings=warnings,
        kcl_residual=kcl,
    )


def worst_effective(sol: DCSolution) -> dict[str, Any]:
    if not sol.network.loads:
        return {}
    veff = sol.load_v_eff
    k = int(np.argmin(veff))
    return {"load": sol.network.loads[k].name, "v_eff": float(veff[k]), "block": sol.network.loads[k].block}
