# OpenROAD PDNSim integration and independent comparison

## Flow (tcl/, driven by `powergrid/openroad_adapter.py`)

`load_design.tcl` → `check_pdn.tcl` (`check_power_grid -net VDD|VSS -error_file`) →
`export_pdn.tcl` → `run_pdnsim.tcl` (`set_pdnsim_net_voltage`, `analyze_power_grid -vsrc -outfile
-error_file -enable_em -em_outfile`, optional `write_pg_spice`) → `regen_pdn.tcl` (optimisation) →
`global_route.tcl` (congestion). Every step's command, exit status, duration, `PG-*` records,
warnings and errors are stored in the run's `run.json` and `evidence/*.log`; a step counts as
successful only with exit status 0, Tcl return code 0 and its output files present.

Voltage sources are given **explicitly** (`-vsrc`, one line `x_um, y_um, size_um, V` per source).
Without a vsrc file this PDNSim build silently places a 140 µm checkerboard of sources on the top
layer (warnings PSM-0016/17/18/65) — never used here. The vsrc coordinates are the exact nodes the
custom importer snapped each tap to, so both solvers feed the grid at the same physical points.

## What PDNSim 6011bbe77 actually computes (read from `src/psm/src/ir_solver.cpp` at that revision)

1. **Resistance data**: `resizer->layerRC()` (set by `set_layer_rc`) and, if zero, the layer
   resistance stored in the **OpenDB technology**. The ORFS flow sources the platform `setRC.tcl`,
   whose `set_layer_rc` calls **overwrite the tech-LEF values inside the database**. Measured on the
   SilicaFlux-V and gcd databases: Metal1 0.135 → 0.0216 Ω/sq, Metal2–5 0.103 → 0.0206 Ω/sq,
   TopMetal1 0.021 → 0.0344 Ω/sq, TopMetal2 0.0145 → 0.029 Ω/sq, Via1–4 20 → 2 Ω/cut,
   TopVia1 4 → 0.4 Ω/cut, TopVia2 2.2 → 0.22 Ω/cut. So "PDNSim on an ORFS database" does not use
   the PDK tech LEF. `PG_RES_OVERRIDE` restores a chosen data set explicitly.
2. **Load current**: `createJ()` adds each instance's OpenSTA **power in watts as a current in
   amperes** (no division by the supply voltage). At 1.2 V this over-states current and IR drop by
   1.2× (shown below and in `tests/test_pdn_import.py`).
3. Standard-cell current is attached at the instance **origin**, snapped to rail nodes spaced
   5 × row height (18.9 µm); macro current is spread over the macro's pin-layer nodes.
4. Sources only on the top PDN layer; no source series resistance.
5. The per-instance voltage file is written with 6 significant digits (≈5 µV quantisation at 1.2 V).

## `write_pg_spice` defects (6011bbe77), demonstrated on gcd and SilicaFlux-V

| defect | evidence |
|---|---|
| a node's current source is written once **per resistor** whose first terminal is that node | SilicaFlux-V VDD: 32 253 `I` lines for 28 290 nodes; 3 963 duplicated nodes; written total 10.29 mA vs 8.33 mA real (+23 %); gcd +38 % |
| ground-net currents are written with the **sink** orientation, opposite to PDNSim's own solve (`J = +I` for GROUND nets) | solving the VSS file as written drives VSS below 0 V; with the sign corrected PowerGrid reproduces PDNSim to 1e-8 V |
| resistances printed with `std::to_string` (6 fixed decimals) | smallest SilicaFlux-V value 0.002060 Ω carries ~3 significant digits |

After de-duplication and sign correction, PowerGrid re-solving PDNSim's own exported network
reproduces PDNSim's per-instance voltages to **5.0 µV (VDD) / 1.3e-8 V (VSS)** — the output
quantisation. The two linear solvers agree; remaining differences are extraction choices.

## Independent comparison on SilicaFlux-V (WB4 taps, vectorless loads, 90 994 instances)

| resistance data | case | net | PowerGrid worst | PDNSim worst | diff | RMS diff | corr |
|---|---|---|---|---|---|---|---|
| OpenDB (setRC) | PDNSim convention (I = P), pin attach | VDD | 2.51 mV | 2.52 mV | −0.3 % | 10 µV | 0.9999 |
| OpenDB (setRC) | PDNSim convention, pin attach | VSS | 2.58 mV | 2.58 mV | −0.2 % | 10 µV | 0.9999 |
| tech LEF | PDNSim convention, pin attach | VDD | 6.69 mV | 6.74 mV | −0.7 % | 20 µV | 0.9998 |
| tech LEF | PDNSim convention, pin attach | VSS | 6.73 mV | 6.75 mV | −0.3 % | 20 µV | 0.9998 |
| tech LEF | **physical I = P/V**, pin attach | VDD | 5.58 mV | 6.74 mV | −17.2 % | 0.84 mV | 0.9998 |

Interpretation: under equivalent assumptions the independent extraction agrees with PDNSim to
< 1 % on the worst drop and ~0.3 % RMS of it per instance. The −17 % with the physically correct
`I = P/V` is exactly PDNSim's 1/V convention (1/1.2 = 0.833), not an extraction error — it is
reported as a finding, not tuned away. Computation time: PDNSim ≈ 10.6 s (VDD) / 5.5 s (VSS);
PowerGrid ≈ 7 s extraction + 2.5 s solve for both nets together.

Public reference (gcd, IHP SG13G2, 437 instances; `tests/test_pdn_import.py`): same conclusions;
drops are ≈ 0.1 mV so the 10 µV PDNSim quantisation and node-density snapping dominate the
residual (worst drop within 8–10 %, correlation 0.78–0.89).

Re-run: `make powergrid-pdnsim` / `make powergrid-compare`.
