# Technology profiles (`configs/technology/*.yaml`)

Profiles contain **no electrical numbers**: they point to PDK files, and `powergrid/technology.py`
parses resistances, widths, thickness, direction and DC current limits from them at run time
(nominal supply from the Liberty `nom_voltage`). Only layers present in the LEF exist — no M1…M8
stack is assumed anywhere.

| profile | status | stack (from LEF) | resistance data available | notes |
|---|---|---|---|---|
| `ihp_sg13g2` | enabled (primary) | Metal1–5, TopMetal1–2 | RPERSQ all layers; per-cut R all cuts; DC limits all layers/cuts | 1.20 V typ; only typ std-cell Liberty at ORFS ab2aaf0f; ORFS `setRC.tcl` disagrees 1.6–10× |
| `sky130hd` | enabled | li1, met1–5 | RPERSQ yes; **per-cut via R missing** in the tlef | via resistance BLOCKED from LEF; setRC values usable only if explicitly selected (correlation data) |
| `gf180mcu` | enabled (generic studies) | Metal1–5 (5LM 9K option) | RPERSQ; via R only in VIA definitions (4.5 Ω) | no SilicaFlux-V SRAM path on GF180 (FloorplanLab audit) |
| `commercial_130nm/65nm/28nm` | **blocked** | — | — | no licensed kit; analysis refuses to run |

Resistance sources selectable per run: `tech_lef` (PDK LEF), `odb_tech` (values stored in the
analysed OpenDB — what PDNSim reads), `orfs_setrc` (ORFS correlation file converted to an
equivalent sheet resistance `r_per_um × W_default`). Every result records which one was used.

Parsed IHP SG13G2 values (tech LEF): Metal1 0.135 Ω/sq (0.40 µm, 1 mA/µm), Metal2–5 0.103 Ω/sq
(0.45 µm, 2 mA/µm), TopMetal1 0.021 Ω/sq (2.0 µm, 15 mA/µm), TopMetal2 0.0145 Ω/sq (3.0 µm,
16 mA/µm); Via1–4 20 Ω/cut (0.4 mA/cut), TopVia1 4 Ω/cut (1.4 mA/cut), TopVia2 2.2 Ω/cut (10 mA/cut).
