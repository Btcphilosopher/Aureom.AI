# Recorded test commands and results

| command | result |
|---|---|
| `make powergrid-test` (`python -m pytest -q --junitxml=reports/tests/junit.xml`) | 105 tests, 0 failures, 0 errors, 0 skipped, 10.9 s |
| `make powergrid-typecheck` (`mypy powergrid`) | Success: no issues found in 29 source files |
| `make powergrid-reproducibility` | `{"design": "silicaflux_v", "bit_identical": true, "solution_sha256": "f1e7db235a4310edd88cb791b222066d7f9dafee1e6b320837348d91df72dfc3", "pdn_regen_identical": true}` |

## Per module

| module | tests | failed | skipped |
|---|---|---|---|
| test_config_cli | 6 | 0 | 0 |
| test_constant_power | 6 | 0 | 0 |
| test_current_density | 4 | 0 | 0 |
| test_floating_network | 9 | 0 | 0 |
| test_ground_network | 5 | 0 | 0 |
| test_kcl | 2 | 0 | 0 |
| test_mesh_reference | 5 | 0 | 0 |
| test_openroad_integration | 3 | 0 | 0 |
| test_optimisation | 4 | 0 | 0 |
| test_pdn_import | 7 | 0 | 0 |
| test_power_balance | 2 | 0 | 0 |
| test_series_parallel | 5 | 0 | 0 |
| test_single_resistor | 1 | 0 | 0 |
| test_sparse_solver | 9 | 0 | 0 |
| test_supply_taps | 2 | 0 | 0 |
| test_technology | 4 | 0 | 0 |
| test_transient_thermal | 3 | 0 | 0 |
| test_units | 28 | 0 | 0 |

The OpenROAD integration tests (`test_openroad_integration.py`, marker `slow`) ran against the installed OpenROAD 2.0-12331-g6011bbe77 on the PUBLIC ORFS gcd design; they are skipped automatically where the toolchain is absent. Raw logs: `reports/tests/pytest.log`, `reports/tests/junit.xml`, `reports/tests/mypy.log`.
