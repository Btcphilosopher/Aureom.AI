# Phase 1 — Repository and EDA environment audit (evidence-backed)

Scope: the accessible repository `btcphilosopher/aureom.ai` (branch checked out in this session,
HEAD `36e36d8`). The SilicaFlux material lives in `SilicaFlux-main/` as loose `.sf` files, PDFs,
images and **40 archives** (`.zip`, one `.tar.gz`), which were unpacked into an isolated scratch
area for inspection (nothing in the repository was modified). Paths below are archive-relative.

## 1. What exists

| Item asked for | Found? | Evidence (path) | Notes |
|---|---|---|---|
| `.sf` sources | **yes** | 33 `.sf` files in `SilicaFlux-main/` and `SilicaFlux2.0/SilicaFlux2.5/` | `.sf` = SystemVerilog-2017 text ("Silica Flux-2017", per TimingLab 2.0 README); e.g. `tensor_unit.sf`, `vector_engine (1).sf`, `silicaflux_top.sf` |
| `.sv` / `.v` sources | **yes** | 828 `.sv`, 3 `.v` across the archives | SilicaFlux-V release 1, DataFabric, MCU-I, SRAM lib, TestCore, TimingLab, PowerLink RTL, generic IP libraries |
| `.sf` translation / compile tools | **no compiler** | `SilicaFlux2.5/sfx_asm.py` is an *assembler* for `.sfx` programs, not an HDL translator | `.sf` files are consumed as SystemVerilog directly (TimingLab uses Yosys-slang) |
| Top-level processors | **yes** | `silicaflux-v-release1.zip: silicaflux-v/rtl/top/sfv_soc.sv`; `silicaflux-datafabric: rtl/soc/sfv_soc_df.sv`; `SilicaFlux2.5/silicaflux_top.sf` | `sfv_soc_df` (SilicaFlux-V + DataFabric DMA) is the only top with a physical flow |
| CPU logic | **yes** | `silicaflux-v/rtl/cpu/sfv_cpu.sv` (RV32I_Zicsr, 2-stage) | |
| Vector / tensor datapaths | **yes** | `silicaflux-v/rtl/accel/sfv_vec_engine.sv`, `sfv_tensor_engine.sv`, `sfv_tile.sv`; 2.x `vector_engine.sf`, `tensor_unit.sf` | |
| SRAM Wrapper Library | **yes** | `SilicaFlux2.5/silicaflux-sramlib.zip` | technology-independent wrappers; IHP macro wrapper used by FloorplanLab is `silicaflux-v/asic/tech/ihp_sg13g2/sfv_sram_macro_bank.sv` |
| DataFabric and DMA | **yes** | `silicaflux-datafabric.zip` (`rtl/interconnect/*`, `rtl/dma/*`) | |
| MCU-I RTL | **yes (RTL only)** | `SilicaFlux2.5/silicaflux-mcu-i.zip`: 21 `.sv` in `rtl/`, ASIC configs `asic/configs/{ihp_sg13g2,sky130hd,gf180mcu}.cfg`, `asic/orfs/` **empty** | FloorplanLab's `configs/mcu_i` still says "not available" — that audit predates the MCU-I archive. **No MCU-I placement/PDN exists**, so MCU-I PDN analysis is BLOCKED |
| FloorplanLab | **yes** | `SilicaFlux2.5/silicaflux-floorplanlab.zip` | ORFS ab2aaf0f flow for `sfv_soc_df` on IHP SG13G2; 17 recorded runs; `results/` (ODB/DEF) git-ignored → regenerated in this session |
| TimingFlow | **as "TimingLab"** at the audited commit (see note) | `silicaflux-timinglab.zip` (v1.0) and `silicaflux-timinglab (1).zip` (2.0) | no project called TimingFlow exists; PowerGrid couples to TimingLab/FloorplanLab OpenSTA reports |
| ORFS configurations | **yes** | FloorplanLab `reports/runs/*/inputs/config.mk`, `platforms/*/profile.yaml`; release-1 `asic/configs/*.cfg` | |
| Existing power-grid Tcl | **yes** | FloorplanLab `platforms/ihp_sg13g2/pdn.tcl`, `platforms/sky130hd/pdn.tcl`, `scripts/orfs_hooks/post_pdn.tcl`; PowerLink `openroad/pdn_silicaflux_v_{generic,sky130,gf180mcu}.tcl` | PowerLink's scripts target a generic 65 nm stack (no PDK selected) |
| Technology LEF | **not committed**; installed | `/opt/eda/orfs/flow/platforms/ihp-sg13g2/lef/sg13g2_tech.lef` (ORFS ab2aaf0f), sky130hd `.tlef`, gf180 tech LEFs | installed by `env/install_toolchain.sh` (pinned) |
| Cell LEF / Liberty | **installed** | `sg13g2_stdcell.lef`, `sg13g2_stdcell_typ_1p20V_25C.lib` | **only the typical std-cell corner** exists at ORFS ab2aaf0f |
| SRAM macro abstracts | **installed** | `/opt/eda/collateral/ihp-sg13g2-sram-d0e5b3c/{lef,lib,gds,verilog}` RM_IHPSG13_1P_{256..2048}x64 | Liberty has **no access energy on A_CLK** (pin energies ≤ 0.03 pJ, leakage 1.58 µW) |
| OpenDB databases / DEF | **not committed** | FloorplanLab `results/` is git-ignored | regenerated: `results/A_baseline/orfs/results/ihp-sg13g2/silicaflux_v/base/3_place.odb` (this session, 16 min) |
| Power & ground net naming | **yes** | FloorplanLab `profile.yaml`: `VDD`/`VSS`; SRAM `VDD!`, `VDDARRAY!` → VDD, `VSS!` → VSS (single 1.2 V domain, assumption recorded by FloorplanLab) | |
| Power analysis reports | **yes (vectorless)** | FloorplanLab `reports/runs/*/place_power.rpt`: 8.34 mW, labelled "VECTORLESS ESTIMATE … not measured" | macros 0 W in that report; PowerLink `results/silicaflux_v/power_by_block.csv` = planning assumptions for a *different* 4-tile architecture at generic 65 nm |
| Switching-activity traces | **none for SilicaFlux-V workloads** | `soc_integration/sim/dump.vcd` (another design), PowerLink `results/rtl/tb_sf_pwr_seq.{vcd,saif}` (power-sequencer testbench) | no workload VCD/SAIF of `sfv_soc_df` exists |
| Existing IR-drop analysis | **none on real geometry** | FloorplanLab RESULTS.md: "Not done: static/dynamic IR drop (no supply-source model…)"; PowerLink: homogenised grid on generic 65 nm assumptions (~5 mV) | PowerGrid is the first IR analysis on the real SilicaFlux-V PDN |
| Package / pad ring | **none** | FloorplanLab places core pins only; `sg13g2_io` not in ORFS ab2aaf0f | supply sources are therefore assumptions (taps on the core ring) |
| TestCore | **yes** | `silicaflux-testcore.zip` docs 01–13 | MBIST tests memories one at a time; scan chains *not inserted*; shift frequency undecided |
| TwinLab | **yes (UI)** | `silicaflux-twinlab.zip` (Angular/TypeScript), `services/semiconductor-physics.ts` 2-D FD thermal solver | no exported temperature map for SilicaFlux-V; PowerGrid accepts a CSV import |

## 2. Toolchain (this session, reproduced from FloorplanLab's pinned recipe)

| Tool | Version | Source |
|---|---|---|
| OpenROAD (+ OpenSTA 2.4.0, PDNSim/psm) | 2.0-12331-g6011bbe77 | conda litex-hub, pinned to ORFS ab2aaf0f |
| Yosys (flow) | 0.38+92 (84116c9a3) | conda litex-hub |
| ORFS | ab2aaf0fb8513f6f6fa8898ba65ae9599a26e621 | git sparse checkout |
| IHP SRAM collateral | ORFS d0e5b3c13e4b… | git show |
| ngspice | 42 | Ubuntu apt (added for PowerGrid cross-checks) |
| GNU time | apt | needed by the ORFS Makefile (was missing; synthesis failed until installed) |
| Python | 3.13.18 (+ 3.12 available) | numpy 2.5.3, scipy 1.18.1, networkx 3.7, pandas 3.0.5, pydantic 2.13.5, PyYAML 6.0.3, matplotlib 3.11.2, plotly 7.1.0, pytest 9.2.0, hypothesis 6.170.15, mypy 2.4.1 |

### Commands verified against the installed OpenROAD (`help <cmd>`)

| Brief's command | Installed syntax | Consequence |
|---|---|---|
| `set_pdnsim_net_voltage` | `[-net] [-voltage]` | used |
| `set_pdnsim_inst_power` | **does not exist** | per-instance power comes from OpenSTA inside `analyze_power_grid` |
| `check_power_grid` | `[-error_file] [-net]` | used |
| `analyze_power_grid` | `[-vsrc] [-outfile] [-error_file] [-enable_em] [-em_outfile] [-net] [-dx] [-dy] [-node_density] [-node_density_factor] [-corner]` | **no `-voltage_file`** (the brief's illustration): `-outfile` writes per-instance voltages; no `-source_type` option in this build |
| `write_pg_spice` | `[-vsrc] [-outfile] [-net] [-dx] [-dy] [-corner]` | used; three defects found (see PDNSIM_COMPARISON.md) |
| `read_vcd` / `read_saif` | **do not exist** | VCD via `read_power_activities -scope -vcd`; **SAIF import BLOCKED** in this build |
| `set_power_activity`, `report_power` | present | used (vectorless input activity 0.1, as FloorplanLab) |

## 3. Missing dependencies (and what they block)

1. **Supply pad / package data** for SilicaFlux-V → GATE 9 BLOCKED; all source models are assumptions.
2. **Workload switching activity** (VCD of `sfv_soc_df` mapped to the gate netlist) → loads are vectorless (MODELLED).
3. **SRAM access energy** (Liberty has none on A_CLK) → SRAM loads under-estimated; SRAM-heavy studies use ASSUMED values.
4. **Foundry-qualified resistance and EM rules** → GATE 7 UNKNOWN: the IHP tech LEF and the ORFS `setRC.tcl` correlation data differ 1.6–10×, and the OpenDB written by ORFS silently carries the setRC values.
5. **Low-voltage std-cell Liberty** (slow 1.08 V) → voltage-aware STA BLOCKED.
6. **Temperature coefficient of IHP metals, package thermal data** → electrothermal analysis is DEMONSTRATION only.
7. **Package RLC / regulator / decap data** → transient droop is a research model with ASSUMED parasitics.
8. **MCU-I physical implementation**, **full SilicaFlux (2.5) SRAM mapping**, **commercial PDKs** → those targets are BLOCKED.

## 4. Branch / repository handling

The brief asked for an isolated branch `feature/silicaflux-powergrid`; the work was first delivered
as a zip with nothing committed, then (on request) published as
`SilicaFlux2.0/SilicaFlux2.5/silicaflux-powergrid.zip` on the session branch. The
project is self-contained in `silicaflux-powergrid/`; FloorplanLab was unpacked unchanged next to it
(`SilicaFlux-main/silicaflux-floorplanlab/`, untracked) because its configs reference that path.
Existing RTL and physical-design configurations were not modified.

## 5. **Post-analysis note (repository commit `ba77e7c`, uploaded after this analysis):** `SilicaFlux2.5/silicaflux-timingflow.zip` (TimingFlow, Project 06) now exists. Its IHP SG13G2 platform (a newer pinned ORFS revision) provides `sg13g2_stdcell_slow_1p08V_125C.lib`, slow/fast SRAM corners and the `sg13g2_io` pad library. That removes the *data* blocker for voltage-aware timing and a pad-ring model; it is **not integrated in this PowerGrid release** (all results here use ORFS ab2aaf0f). Integrating it is the recommended next step.
