# Remaining foundry / package dependencies and the path to EM/IR signoff

## Missing PDK / foundry data
* Process-qualified sheet resistance per layer and per-cut via resistance (min/typ/max, temperature
  coefficient) — to arbitrate tech LEF vs setRC (docs/OPEN_ISSUES.md #1).
* EM rule deck: DC/AC/peak current limits vs temperature, duty cycle, Blech length, wide-metal and
  via-array rules, target lifetime.
* Multi-corner Liberty (slow 1.08 V / fast 1.32 V std cells — the SRAM slow/fast libs exist) for
  voltage-aware timing.
* SRAM compiler data: access energy per operation, peak current waveform, internal PG resistance.
* Metal temperature coefficients and a package thermal model (θjc / θja for the chosen package).
* KLayout DRC/LVS decks are present in the platform but were not run on PowerGrid variants.

## Missing package / board data
* Pad ring and supply pad assignment; bond-wire lengths/diameters; lead-frame or substrate R/L.
* Regulator output impedance and load-step response; board decoupling.
* On-die decoupling capacitance (inserted decap cells) and intrinsic capacitance per region.

## Commercial nodes
Commercial 130 / 65 / 28 nm profiles are `blocked` (no licensed kit). No node scaling is done.

## Before commercial EM/IR signoff
1. Final post-route, post-CTS database with fill and decap; extracted PDN including signal-route
   coupling where relevant.
2. Foundry-qualified technology data (above) loaded and reconciled; this tool's LEF/setRC conflict
   resolved.
3. Vectored activity from representative workloads (gate-level VCD/FSDB) and vectorless coverage,
   including test modes (scan shift/capture, MBIST) from the scan-inserted netlist.
4. Real package/pad model with source resistance and inductance; static and dynamic (vectored)
   IR in a signoff tool (e.g. Voltus / RedHawk-SC) with the foundry EM deck at the signoff
   temperature and lifetime.
5. Correlation of this tool's static results with the signoff tool on the same inputs (the
   PDNSim comparison harness here is the template).
6. Voltage-aware STA with the IR map annotated (or derated corners agreed with the foundry).
7. Human engineering review and approval.
