# Physical PDN extraction (OpenDB → PowerGrid network)

`tcl/export_pdn.tcl` (OpenROAD) writes, for the PG nets of a placed database:

| file | content |
|---|---|
| `wires.csv` | every special-wire rectangle: net, layer, bbox (dbu), shape type (RING / STRIPE / FOLLOWPIN), direction |
| `vias.csv`, `via_defs.csv` | every via instance (net, x, y, definition); definitions with bottom/cut/top layer, cut count (rows × cols) and enclosures |
| `insts.csv` | every instance: master, type (CORE / BLOCK / …), placement, orientation, bbox, every PG ITerm with its net (or none) and pin bbox |
| `power.csv` | per-instance internal / switching / leakage / total power from OpenSTA (`sta::instance_power`) |
| `tech_layers.csv` | the layer resistances **stored in the analysed OpenDB** (see the setRC finding) |
| `bterms.csv`, `meta.json` | PG block terminals (none in SilicaFlux-V), die / core, tool version, power label |

`powergrid/pdn_import.py` builds the network:

1. **Wires** become 1-D conductors along their long axis; width = short side; `R = Rs·L/W` with
   `Rs` from the selected technology source. Breakpoints: every via landing inside the wire, every
   same-layer overlap with another wire of the net (ideal join), every load attachment and supply
   source. Stubs beyond the outermost breakpoint carry no current and are not modelled.
2. **Vias** join the bottom and top landing points with `R_cut/n_cuts` of their cut layer;
   stacked vias (Via1–Via4 between Metal1 rails and Metal5 straps) share intermediate landing
   nodes. A landing that touches no wire and no other via is reported as **dangling**, except
   landings on SRAM macro PG pins (Metal4), which are reported as macro-pin landings.
3. **Standard cells** attach at the x-centre of their PG pin on the bottom-layer rail of that net
   (`attach: pin`). `attach: pdnsim` reproduces PDNSim 6011bbe77 (instance origin snapped to a
   node-density grid of 5 × row height). PG ITerms with **no net in the database** (14 167 instances
   in SilicaFlux-V, buffers/cells inserted after `global_connect`) are attached by pin type to the abutting rail
   and reported.
4. **Macros** spread their current equally over their landing nodes on the lowest PDN layer inside
   the macro outline (PDNSim's methodology); macro-internal PG resistance is not modelled (the LEF
   abstract carries none).
5. **Sources** snap to the nearest node of their net on the requested layer (default: top PDN
   layer, as PDNSim); requested and snapped coordinates and distances are reported.
6. **Unsupported / suspicious structures** are counted, never dropped silently: floating wires,
   dangling vias, wires on non-routing layers, vias without definitions, macros without landing,
   unplaced instances, instances without power, PG pins without net.

Extraction of SilicaFlux-V A_baseline (this session): 2 783 wires, 104 735 vias (Via1–3: 12 573
each, Via4: 38 153, TopVia1: 28 863), 0 floating wires, 0 dangling vias, 25 580 SRAM pin
landings, 90 994 standard cells + 12 macros attached, 323 627 nodes, 336 700 segments; build ≈7 s,
solve ≈2.5 s.
