# Electrical model, solver and validation

## 1. Network model (`powergrid/graph.py`)

* **Nodes** carry a net, an optional layer and coordinates. **Nets** are POWER or GROUND with a
  nominal voltage; a **domain** pairs exactly one power net with one ground net.
* **Segments** carry: end nodes, resistance, kind (metal / via / contact / source / resistor),
  layer, length, width, thickness, via cut count, current limit (from technology data) and a
  provenance string. Metal: `R = Rs·L/W` with the *technology* sheet resistance (tech LEF
  `RESISTANCE RPERSQ`), never bulk copper resistivity — narrow on-chip conductors are not bulk.
  Via arrays: `R = R_cut / n_cuts` (lumped; see §5 for current crowding).
* Rejected on construction: negative / NaN / infinite resistance, a segment joining two nets
  (nets are never connected implicitly), a load whose VDD/VSS nodes are not on the power/ground
  net of its declared domain, a source whose voltage does not belong to the net's domain.
* `R = 0` is legal and means an ideal short (handled by node merging, §2).

### Sign conventions
| quantity | positive means |
|---|---|
| node voltage | absolute, w.r.t. the 0 V of the ideal sources |
| `CurrentInjection` | current INTO the node |
| load current | drawn OUT of its VDD node, returned INTO its VSS node (`vss_node=None` → ideal 0 V return, flagged) |
| segment current | flowing from endpoint `a` to `b` |
| source current | flowing OUT of the source INTO the network (VSS sources are negative) |

Per-load results: `V_eff = V_VDD,local − V_VSS,local`, VDD droop `= V_nom − V_VDD,local`, ground
bounce `= V_VSS,local − 0`, total loss `= V_nom − V_eff`.

## 2. Sparse DC solver (`powergrid/solver.py`, `powergrid/conductance.py`)

1. Sources with series resistance get an internal ideal node + a resistor (package / bond wire).
2. Zero-resistance edges are merged into supernodes (connected components of the zero-R subgraph);
   no artificial large conductance is introduced.
3. Deterministic numbering: supernodes ordered by the smallest canonical rank (sorted node name)
   of their members — the result is bit-identical for any insertion order (tested).
4. Checks before solving: voltage-source conflicts (different prescribed voltages on one
   supernode, e.g. through a short), connected components (SciPy `csgraph`), floating components
   (no voltage reference). A loaded floating component is an error; an unloaded one is an error by
   default and, if explicitly allowed, is excluded with **undefined (NaN)** voltages. **No
   conductance to ground is ever added to make the matrix invertible.**
5. Assembly: COO → CSR, `G[a,a]+=g, G[b,b]+=g, G[a,b]-=g, G[b,a]-=g`; Dirichlet supernodes
   eliminated: `G_UU v_U = i_U − G_UF v_F`.
6. Solve: SuperLU (COLAMD ordering) by default; conjugate gradients with Jacobi or ILU
   preconditioning on request (`method: cg`), with iteration counts and non-convergence errors.
7. Post-processing: branch currents `(V_a−V_b)/R`; zero-R branch and parallel-ideal-source
   currents by a minimum-norm KCL solve (flagged as non-unique when loops exist); source currents;
   per-node KCL residual; global current balance; power balance
   `P_source + P_injections = Σ I²R + Σ I_load·V_eff`.
8. Reported numerics: unknowns, nnz, conductance ratio, residual ∞-norm, normwise backward error,
   KCL max residual vs a stated floating-point noise floor (`8·deg·ε·g_max·V_max`), power-balance
   error vs its floor, factor/solve times, CG iterations, fixed-point history.

**Constant-power loads** (`I = P/V_local`): damped fixed-point iteration re-using one LU
factorisation; convergence on `max|ΔV_eff|`; **voltage collapse** is reported when V_eff falls
below a fraction (default 50 %) of nominal or the iteration diverges — e.g. a 1 V source, 1 Ω,
0.3 W load (> V²/4R) raises `VoltageCollapseError`. `conversion_voltage: nominal` gives the single
linear solve `I = P/V_nom` and is labelled as such.

**Iterative solvers** (investigated, `tests/test_sparse_solver.py`): CG with Jacobi, ILU and no
preconditioning reproduces SuperLU to < 1e-11 V on test meshes. On the 323 k-unknown SilicaFlux-V
network SuperLU factorises in ≈1.1 s and solves in ≈0.2 s, so the direct method is the default;
`method: auto` switches to CG above 2 M unknowns.

## 3. Analytical validation (all pass; `make powergrid-test`)

| Test | File | What is checked |
|---|---|---|
| A single resistor | `test_single_resistor.py` | 1 V, 1 Ω, 0.1 A → 0.9 V load, 0.1 V drop, P: 0.1 = 0.01 + 0.09 W |
| B series | `test_series_parallel.py` | voltage division, chain with distributed loads, source currents |
| C parallel | `test_series_parallel.py` | equivalent resistance and branch currents (current divider) |
| D 2-D mesh | `test_mesh_reference.py` | vs (1) dense stencil matrix + `numpy.linalg.solve` (< 1e-12 V), (2) exact discrete-sine-transform eigen solution (< 1e-13 V), CG vs direct |
| E supply taps | `test_supply_taps.py` | one vs two taps on a loaded line (hand values 10 IR → 2 IR), unequal sharing through source resistance |
| F floating | `test_floating_network.py` | no source, loaded island, unloaded island (NaN, not 0 V), no added conductance, conflicts, cross-net, invalid R |
| G KCL | `test_kcl.py` | Hypothesis: random VDD/VSS graphs with loops, zero-R shorts, source resistance, injections; KCL at every non-source node, independent recomputation |
| H power balance | `test_power_balance.py` | hand example + Hypothesis; segment-level dissipation sum |
| I ground return | `test_ground_network.py` | droop `I·Rp`, bounce `I·Rn`, `V_eff = V − I(Rp+Rn)`; ignoring ground over-states the supply by `I·Rn` |
| J refinement | `test_mesh_reference.py` | square sheet vs continuous Poisson solution (u(½,½)=0.0736713532814…); observed order 1.8–2.2 (second order) |
| constant power | `test_constant_power.py` | closed form `V=(V0+√(V0²−4PR))/2`, nominal conversion, collapse |
| units | `test_units.py` | SI conversion, rejection of bare numbers, `M`/`MEG`/`mil`/`MOhm`, dimension mismatch, NaN |

## 4. Loads (`powergrid/loads.py`)

Sources: user per-block power, user per-instance current, OpenSTA (vectorless or VCD), time
windows (each a DC point). Every value carries MEASURED / SIMULATED / MODELLED / ASSUMED. Blocks
without data are listed as MISSING — never filled. `read_power_activities -vcd` is the only
activity import of this OpenROAD build (SAIF BLOCKED); `vcd_scope_check()` measures how much of the
gate-netlist hierarchy a VCD covers before it is trusted.

## 5. Current density and EM screening (`powergrid/current_density.py`)

Linear density `|I|/W` (LEF limits are mA/µm), volumetric `|I|/(W·t)`, per-cut via current.
`resolve_via_array()` resolves an n×m via array between two finite-resistance plates with the same
solver: for a 1×8 TopVia1 row fed from opposite ends the end cuts carry measurably more than the
average (crowding factor > 1), so the lumped equal-share assumption is not used for limits without
that factor. Statuses PASS / FAIL / UNKNOWN / NOT ANALYSED — **UNKNOWN whenever no limit exists**.
Black's equation is provided only as a research ratio requiring process-qualified n and Ea.

## 6. Thermal and transient (research modules)

`thermal.py`: steady 2-D die conduction solved with the same verified solver (analogy), every
parameter an input with a source; electrothermal loop with under-relaxation and a technology
temperature coefficient (none exists for IHP in the PDK files → DEMONSTRATION). `transient.py`:
lumped RLC with trapezoidal integration, checked against the lossless-LC closed form and against
ngspice on the identical deck (max difference 0.14 µV in the shipped study).
