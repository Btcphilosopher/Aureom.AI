"""Write docs/CHANGES.md: full source change list (every file added by PowerGrid, with size and sha256)."""
import hashlib
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
rows = []
for p in sorted(ROOT.rglob("*")):
    rel = p.relative_to(ROOT).as_posix()
    if p.is_dir() or rel.startswith(("reports/", "work/", ".git/")) or "__pycache__" in rel or rel.endswith(".pyc") \
            or rel.startswith(".pytest_cache") or rel.startswith(".mypy_cache") or rel.startswith(".hypothesis"):
        continue
    data = p.read_bytes()
    lines = data.count(b"\n") if not rel.endswith((".odb", ".png")) else "-"
    rows.append(f"| `{rel}` | {len(data)} | {lines} | `{hashlib.sha256(data).hexdigest()[:16]}` |")
txt = ["# Source change list", "",
       "All files below are NEW (the PowerGrid project did not exist). No existing repository file was modified:",
       "the SilicaFlux RTL, FloorplanLab configuration and other projects are untouched (FloorplanLab was unpacked",
       "unchanged next to this project and run as an input tool). Generated evidence lives in `reports/`.", "",
       "| file | bytes | lines | sha256 (16) |", "|---|---|---|---|"] + rows
(ROOT / "docs" / "CHANGES.md").write_text("\n".join(txt) + "\n")
print(len(rows), "files")
