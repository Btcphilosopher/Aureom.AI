"""Run the physical PDN sweep (configs/experiments/pdn_sweep.yaml) -> reports/optimisation/."""
import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from powergrid.cli import main
sys.exit(main(["optimise", "--config", sys.argv[1] if len(sys.argv) > 1 else "configs/experiments/pdn_sweep.yaml"]))
