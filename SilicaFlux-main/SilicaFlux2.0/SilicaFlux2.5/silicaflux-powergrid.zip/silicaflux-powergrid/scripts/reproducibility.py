"""GATE 17 evidence: repeated solves are bit-identical; regenerating the baseline PDN
reproduces the original geometry exactly; repeated PDNSim runs are identical (integration test)."""
import gzip, hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
from powergrid.config import DesignConfig
from powergrid.flows import tap_specs
from powergrid.pdn_import import ImportOptions, build_network, read_export
from powergrid.solver import solve
from powergrid.technology import load_profile

cfg = DesignConfig.load(ROOT / "configs/designs/silicaflux_v.yaml")
exp_dir = ROOT / "reports/silicaflux_v/analysis/evidence/export"
out = {"design": cfg.name}
if exp_dir.exists():
    exp = read_export(exp_dir)
    tech = load_profile(cfg.technology).tech("tech_lef")
    srcs = tap_specs(cfg, cfg.default_supply_model, exp, 1.2)
    v = []
    for _ in range(2):
        net, _ = build_network(exp, tech, srcs, ImportOptions())
        v.append(solve(net).node_voltage)
    out["bit_identical"] = bool(np.array_equal(v[0], v[1]))
    out["solution_sha256"] = hashlib.sha256(v[0].tobytes()).hexdigest()

def digest(d: Path, name: str) -> str:
    p = d / name
    data = p.read_bytes() if p.exists() else gzip.open(str(p) + ".gz").read()
    return hashlib.sha256(b"".join(sorted(data.splitlines()))).hexdigest()

opt = ROOT / "reports/optimisation/pdn_sweep/summary.json"
if opt.exists() and exp_dir.exists():
    s = json.loads(opt.read_text())
    base = ROOT / "reports/optimisation/pdn_sweep/variants" / s["baseline_id"] / "export"
    out["pdn_regen_identical"] = all(digest(base, f) == digest(exp_dir, f) for f in ("wires.csv", "vias.csv"))
(ROOT / "reports/tests").mkdir(parents=True, exist_ok=True)
(ROOT / "reports/tests/reproducibility.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
