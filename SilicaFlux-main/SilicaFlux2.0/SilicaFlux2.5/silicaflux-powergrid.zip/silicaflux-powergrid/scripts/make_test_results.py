"""Write docs/TEST_RESULTS.md from reports/tests/{junit.xml,pytest.log,mypy.log,reproducibility.json}."""
import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
T = ROOT / "reports" / "tests"
root = ET.parse(T / "junit.xml").getroot()
suite = root if root.tag == "testsuite" else root.find("testsuite")
mods: Counter = Counter()
fails: Counter = Counter()
skipped: Counter = Counter()
for tc in root.iter("testcase"):
    m = tc.get("classname", "").split(".")[-1] if "." in tc.get("classname", "") else tc.get("classname", "")
    mods[m] += 1
    for ch in tc:
        if ch.tag in ("failure", "error"):
            fails[m] += 1
        if ch.tag == "skipped":
            skipped[m] += 1
lines = ["# Recorded test commands and results", "",
         "| command | result |", "|---|---|",
         f"| `make powergrid-test` (`python -m pytest -q --junitxml=reports/tests/junit.xml`) | "
         f"{suite.get('tests')} tests, {suite.get('failures')} failures, {suite.get('errors')} errors, "
         f"{suite.get('skipped')} skipped, {float(suite.get('time')):.1f} s |"]
mypy = (T / "mypy.log").read_text().strip().splitlines()[-1] if (T / "mypy.log").exists() else "not run"
lines.append(f"| `make powergrid-typecheck` (`mypy powergrid`) | {mypy} |")
if (T / "reproducibility.json").exists():
    lines.append(f"| `make powergrid-reproducibility` | `{json.dumps(json.loads((T / 'reproducibility.json').read_text()))}` |")
lines += ["", "## Per module", "", "| module | tests | failed | skipped |", "|---|---|---|---|"]
for m in sorted(mods):
    lines.append(f"| {m} | {mods[m]} | {fails[m]} | {skipped[m]} |")
lines += ["", "The OpenROAD integration tests (`test_openroad_integration.py`, marker `slow`) ran against the "
          "installed OpenROAD 2.0-12331-g6011bbe77 on the PUBLIC ORFS gcd design; they are skipped automatically "
          "where the toolchain is absent. Raw logs: `reports/tests/pytest.log`, `reports/tests/junit.xml`, "
          "`reports/tests/mypy.log`."]
(ROOT / "docs" / "TEST_RESULTS.md").write_text("\n".join(lines) + "\n")
print("\n".join(lines[:8]))
