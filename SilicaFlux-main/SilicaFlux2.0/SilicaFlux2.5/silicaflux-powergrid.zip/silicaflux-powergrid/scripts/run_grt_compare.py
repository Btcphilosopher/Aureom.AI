"""Measure global-route congestion for the baseline and selected PDN variants (OpenROAD FastRoute)."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from powergrid.config import DesignConfig
from powergrid.openroad_adapter import DesignInputs, OpenROAD, parse_grt_overflow

cfg = DesignConfig.load(ROOT / "configs/designs/silicaflux_v.yaml")
summ = json.loads((ROOT / "reports/optimisation/pdn_sweep/summary.json").read_text())
labels = sys.argv[1:] or ["baseline (A_baseline)", "Metal5 4.4 um + TopMetal1 3.6 um", "TopMetal1 width x3 (5.4 um)"]
res = {}
for v in summ["variants"]:
    if v["label"] not in labels or v.get("status") != "VALID":
        continue
    d = ROOT / "reports/optimisation/pdn_sweep/variants" / v["id"]
    di = DesignInputs(cfg.name, str(d / "pdn.odb"), cfg.tech_lef, cfg.lefs, cfg.libs, cfg.sdc)
    r = OpenROAD().run("global_route.tcl", {**di.env(), "PG_OUT": str(d / "grt")}, d / "grt.log", "global_route", timeout=7200)
    ov = parse_grt_overflow(Path(r.log).read_text())
    res[v["id"]] = {"label": v["label"], "ok": r.ok, "seconds": r.seconds, "congestion": ov,
                    "total_overflow": ov.get("Total", {}).get("overflow_total")}
    print(v["label"], res[v["id"]]["total_overflow"], round(r.seconds), flush=True)
(ROOT / "reports/optimisation/pdn_sweep/global_route.json").write_text(json.dumps(res, indent=1))
