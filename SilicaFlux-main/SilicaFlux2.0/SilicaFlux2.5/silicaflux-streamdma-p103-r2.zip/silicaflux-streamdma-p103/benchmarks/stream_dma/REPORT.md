# Benchmark report -- StreamDMA

**All measured numbers below are SIMULATION cycles** from the DUT's own performance counters against a behavioural AXI slave model (fixed latency, ideal or randomly back-pressured handshakes). **There are no FPGA or silicon measurements in this project.** Every benchmark run is also checked byte-for-byte against the reference model (`ok` column of results.csv is 1 for all rows). Throughput is quoted in bytes per clock cycle; no clock frequency is claimed anywhere.

## 1. Theoretical throughput (from the configuration only; not measured)

* **Datapath peak** = `W` bytes/cycle = `DATA_WIDTH/8`: one full beat per cycle on R and one on W. A copy moves each byte once through each, so the ceiling is `W` B/cycle (128-bit: 16 B/cycle; 256-bit: 32 B/cycle). Short bursts or backpressure only lower it.
* **Latency-bound limit** with `N` outstanding bursts of `BL` beats and memory latency `L` cycles: a burst occupies a slot for `BL + L + c` cycles, so `BW(N) = min( W , N * BL * W / (BL + L + c) )`, with `c` = fixed internal pipeline cycles per burst.
* `c` is not derived from the RTL; it is **fitted once from the single-outstanding measurements** (Phase 1, `b_n1`): the measured period at L = 2, 10, 30, 80 is `BL + L + 2` each time, so `c = 2`. The Phase-2 results below are then *predictions* of this formula, not refits.
* **Bytes in flight needed to reach the peak** = `W * (BL + L + c)`: the data buffer must hold at least that much (`FIFO_DEPTH >= N * BL`) and `N >= ceil((BL + L + c) / BL)`.

## 2. Measured, Phase 1 -> Phase 2 (128 KiB aligned copy, simulation)

| config | N rd/wr | BL | FIFO | PLAN | lat2 B/cyc (pred) | lat10 B/cyc (pred) | lat30 B/cyc (pred) | lat80 B/cyc (pred) | lat10 + 70% backpressure |
|---|---|---|---|---|---|---|---|---|---|
| b_n1 | 1/1 | 16 | 64 | 1 | 12.76 (12.80) | 9.12 (9.14) | 5.32 (5.33) | 2.61 (2.61) | 7.20 |
| b_n1p2 | 1/1 | 16 | 64 | 2 | 12.76 (12.80) | 9.12 (9.14) | 5.32 (5.33) | 2.61 (2.61) | 7.20 |
| b_n2 | 2/2 | 16 | 64 | 2 | 15.93 (16.00) | 15.90 (16.00) | 10.60 (10.67) | 5.20 (5.22) | 11.06 |
| b_n4 | 4/4 | 16 | 64 | 2 | 15.93 (16.00) | 15.90 (16.00) | 15.82 (16.00) | 10.22 (10.45) | 11.06 |
| b_n8 | 8/8 | 16 | 128 | 2 | 15.93 (16.00) | 15.90 (16.00) | 15.82 (16.00) | 15.63 (16.00) | 11.09 |
| b_n4_bl8 | 4/4 | 8 | 64 | 2 | 15.94 (16.00) | 15.91 (16.00) | 12.70 (12.80) | 5.66 (5.69) | 11.08 |
| b_n4_bl32 | 4/4 | 32 | 128 | 2 | 15.90 (16.00) | 15.87 (16.00) | 15.79 (16.00) | 15.60 (16.00) | 11.10 |
| b_n4_f32 | 4/4 | 16 | 32 | 2 | 15.93 (16.00) | 15.90 (16.00) | 10.39 (16.00) | 5.15 (10.45) | 11.00 |
| b_n4_p1 | 4/4 | 16 | 64 | 1 | 15.00 (16.00) | 14.97 (16.00) | 14.90 (16.00) | 10.21 (10.45) | 11.06 |
| b_n4_dw256 | 4/4 | 16 | 64 | 2 | 31.71 (32.00) | 31.59 (32.00) | 31.29 (32.00) | 20.18 (20.90) | 21.95 |

Peak is 16 B/cycle (32 for `b_n4_dw256`). 'pred' is the formula of section 1 with `c = 2`.

## 3. What the stall counters say (128 KiB aligned copy, lat10) -- the measurements that drove Phase 2

| config | active cycles | rd stall: no free slot | rd stall: buffer full | rd stall: guard | wr stall: waiting for read data | wr stall: W/AW not accepted | buf occupancy (avg beats) |
|---|---|---|---|---|---|---|---|
| b_n1 | 14377 | 11753 | 0 | 3 | 5639 | 0 | 0.57 |
| b_n1p2 | 14377 | 13794 | 0 | 3 | 6150 | 0 | 0.57 |
| b_n2 | 8245 | 7655 | 0 | 3 | 18 | 0 | 0.99 |
| b_n4 | 8245 | 7110 | 508 | 3 | 18 | 0 | 0.99 |
| b_n8 | 8245 | 7036 | 503 | 3 | 18 | 0 | 0.99 |
| b_n4_bl8 | 8237 | 7137 | 0 | 3 | 18 | 0 | 0.99 |
| b_n4_bl32 | 8261 | 7558 | 252 | 3 | 18 | 0 | 0.99 |
| b_n4_f32 | 8245 | 0 | 7656 | 3 | 18 | 0 | 0.99 |
| b_n4_p1 | 8756 | 73 | 6019 | 3 | 18 | 0 | 35.71 |
| b_n4_dw256 | 4149 | 3526 | 252 | 3 | 18 | 0 | 0.98 |

Reading the table:

* **Phase 1 (`b_n1`, one outstanding)**: 82% of active cycles the next read burst is ready but the only slot is busy (*no free slot*), and the assembler waits for source
  data for 39% of the cycles (*waiting for read data*). The buffer is almost empty (0.57 beats on average). Diagnosis: **latency-bound, not bandwidth-bound**.
* **Phase 2 (`b_n2` ... `b_n8`)**: with enough slots the 'no free slot' stall just means the read side is *ahead* of the single W channel (the datapath is the limit);
  the waiting-for-data stall disappears (18 cycles = pipeline fill) and the copy runs at 99% of the datapath peak. `b_n2` suffices at L = 10; L = 30 needs N = 4; L = 80 needs N = 8
  (or `BL = 32` with N = 4: `b_n4_bl32`), exactly as the bytes-in-flight rule predicts.
* **`b_n4_f32` (FIFO_DEPTH 32)**: 7656 *buffer full* stalls and a collapse at higher latency -- the buffer, not the slot count, was the limit (needs `FIFO_DEPTH >= N * BL`).
* **`b_n4_p1` (PLAN_DEPTH 1)**: guard look-ahead disabled costs ~6% at low latency (15.00 vs 15.93 B/cycle): the guard round trip per burst is then not hidden.
* **Unaligned** copies (source +3, destination +5) run at the same rate as aligned ones (results.csv): the byte realigner costs no throughput.
* **Burst utilisation** (`rd_beats / (rd_bursts x BL)`) is 100% for these large transfers (all bursts are full); see results.csv for the small-transfer workloads.

## 4. What is still slow: many small transactions

`txn_x64_64B` (64 transactions of 64 bytes) runs at **1.42 B/cycle for every N and every buffer size** (mean transaction latency 41.0 cycles at L = 10): the limit is the **one-transaction-in-flight contract**, not memory parallelism, so more outstanding requests cannot help. Cycle breakdown of one 64-byte transaction at L = 2 (trace, `tb_b_n4 1 trace_small`), 29 cycles per transaction: AR -> last R beat 5, last R beat -> AW 5 (response ingest, realign, W-FIFO fill, AW issue), AW -> B 5, B -> completion record 3, **completion accepted -> next transaction's first AR 11** (completion handshake, `txn_done`, validator, segment FIFOs, hazard check, planner, guard round trip, AR issue). The measured next optimisation is therefore **overlapping the start of transaction n+1 with the completion tail of transaction n**, which needs per-transaction contexts and error attribution; it was deliberately **not** attempted here (docs/08). Large-transfer throughput is unaffected.

## 5. Other workloads (B/cycle, lat10)

| config | 128 KiB unaligned | 32 x 2 KiB scatter-gather | 64 x 256 B scatter-gather | 32 x 4 KiB transactions | 64 x 64 B transactions |
|---|---|---|---|---|---|
| b_n1 | 9.11 | 9.09 | 8.94 | 8.38 | 1.42 |
| b_n1p2 | 9.11 | 9.09 | 8.94 | 8.38 | 1.42 |
| b_n2 | 15.89 | 15.80 | 15.21 | 13.26 | 1.42 |
| b_n4 | 15.89 | 15.80 | 15.21 | 13.26 | 1.42 |
| b_n8 | 15.89 | 15.80 | 15.21 | 13.26 | 1.42 |
| b_n4_bl8 | 15.91 | 15.83 | 15.33 | 13.61 | 1.42 |
| b_n4_bl32 | 15.86 | 15.73 | 15.21 | 12.60 | 1.42 |
| b_n4_f32 | 15.89 | 15.80 | 15.21 | 13.26 | 1.42 |
| b_n4_p1 | 14.97 | 14.88 | 14.37 | 12.64 | 1.42 |
| b_n4_dw256 | 31.58 | 31.19 | 29.41 | 22.63 | 1.56 |

## 6. Hardware measurements

**None.** No FPGA bitstream or silicon exists for this block; no frequency, power or area-in-um^2 figure is claimed. Resource counts are in reports/synth.md and are Yosys generic-cell / Xilinx-7 mapping estimates only.
