#!/usr/bin/env python3
"""Benchmark driver.  Builds the Verilator bench for each benchmark configuration (tests/stream_dma/configs.sh), runs
`tb_<cfg> 1 bench` (workloads x latency/backpressure conditions, every run checked byte-for-byte), collects the performance-counter
CSV rows, and writes benchmarks/stream_dma/results.csv, plus a theoretical-throughput table computed from the configuration alone.
ALL measured values are SIMULATION cycles against a behavioural slave: not FPGA or silicon measurements.
usage: run_bench.py [--configs a,b,c] [--no-build]"""
import argparse, csv, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
def cfgs():
    out = subprocess.run(["bash", "-c", "source tests/stream_dma/configs.sh; echo $BENCH_CONFIGS"], cwd=ROOT, capture_output=True, text=True).stdout.split()
    return out
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--configs"); ap.add_argument("--no-build", action="store_true"); a = ap.parse_args()
    cs = a.configs.split(",") if a.configs else cfgs()
    rows = []; header = None
    for c in cs:
        if not a.no_build:
            r = subprocess.run(["bash", "scripts/build_tb.sh", c], cwd=ROOT, capture_output=True, text=True)
            if r.returncode: print("build failed", c, r.stdout[-300:], r.stderr[-300:]); sys.exit(1)
        r = subprocess.run([f"build/tb_{c}/tb_{c}", "1", "bench"], cwd=ROOT, capture_output=True, text=True, env=dict(os.environ, TB_CFGNAME=c), timeout=3000)
        for line in r.stdout.splitlines():
            if line.startswith("BENCH_HEADER,"): header = line.split(",")[1:]
            elif line.startswith("BENCH,"): rows.append(line.split(",")[1:])
        print(c, "rows so far:", len(rows), flush=True)
    path = os.path.join(ROOT, "benchmarks/stream_dma/results.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)
    bad = [r for r in rows if r[3] != "1"]
    print(f"wrote {path}: {len(rows)} rows, {len(bad)} with ok=0")
    sys.exit(1 if bad else 0)
if __name__ == "__main__": main()
