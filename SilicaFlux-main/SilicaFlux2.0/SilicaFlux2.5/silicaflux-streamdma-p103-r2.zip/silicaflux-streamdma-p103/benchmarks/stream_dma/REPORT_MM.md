# Benchmark report -- StreamDMA against the real MemoryMatrix (P101)

**All numbers are SIMULATION cycles** of the integrated RTL (StreamDMA -> bridge -> `sf_memory_matrix`; 128-bit datapath, matrix read latency 1, no ECC, matrix queue depth 8 unless stated), measured with the DMA's own performance counters and the matrix's own counters. There is no FPGA or silicon measurement. Every copy is verified byte-for-byte (`ok` column: all 1). Throughput is bytes per clock cycle; **no clock frequency is claimed**.

Workload: 6 copies of 16 KiB (SRAM arena -> compute arena and back). *Noise* = another matrix master issuing random 1..16-byte reads/writes to a disjoint region at the stated probability per cycle (100% = a request every cycle). *Skew* = destination placement relative to the source: 0 bytes, or one beat (16 B); a wider skew sweep is in section 4. Raw rows: `mm_results.csv` (columns defined in the header line).

## 1. Theoretical bounds (from the configuration only; not measured)

* **DMA datapath peak** = 16 B/cycle (one 128-bit beat per cycle on R and on W).
* **Matrix bank bound.** A copied byte is read once and written once = two bank-bytes. A bank accepts one 64-bit word (8 B) per cycle, so `NUM_BANKS` banks sustain at most `NUM_BANKS x 8 / 2 = 4 x NUM_BANKS` B/cycle of copy bandwidth: **16 / 32 / 64 B/cycle for 4 / 8 / 16 banks**. With 4 banks this equals the datapath peak, so any bank conflict must show as lost throughput; with 8 and 16 banks the DMA is datapath-limited and leaves headroom for other masters.
* **Per-master bound.** Each of the DMA's two matrix masters issues at most one 16 B request per cycle.
* **Per-copy fill/drain.** With one transaction in flight a copy has an unavoidable start-up (guard, AR, read latency, burst assembly) and tail (last write, B, completion record). Ideal copy time = 16384 B / 16 B/cycle = 1024 cycles.

## 2. Measured throughput (B/cycle; peak 16)

### Destination skew 0 B

| banks | outstanding | noise 0% | noise 25% | noise 50% | noise 100% |
|---|---|---|---|---|---|
| 4 | 1 | 10.73 | 9.51 | 8.73 | 8.60 |
| 4 | 2 | 14.52 | 12.38 | 10.89 | 10.74 |
| 4 | 4 | 14.52 | 12.38 | 10.89 | 10.74 |
| 8 | 1 | 10.79 | 10.55 | 10.48 | 10.39 |
| 8 | 2 | 14.93 | 14.31 | 13.92 | 13.72 |
| 8 | 4 | 14.93 | 14.31 | 13.92 | 13.72 |
| 16 | 1 | 10.82 | 10.72 | 10.69 | 10.70 |
| 16 | 2 | 14.93 | 14.62 | 14.52 | 14.20 |
| 16 | 4 | 14.93 | 14.62 | 14.52 | 14.20 |

### Destination skew 16 B

| banks | outstanding | noise 0% | noise 25% | noise 50% | noise 100% |
|---|---|---|---|---|---|
| 4 | 1 | 10.63 | 9.50 | 8.73 | 8.56 |
| 4 | 2 | 15.37 | 12.41 | 10.83 | 10.80 |
| 4 | 4 | 15.37 | 12.41 | 10.83 | 10.80 |
| 8 | 1 | 10.69 | 10.53 | 10.48 | 10.36 |
| 8 | 2 | 15.37 | 14.37 | 13.93 | 13.64 |
| 8 | 4 | 15.37 | 14.37 | 13.93 | 13.64 |
| 16 | 1 | 10.79 | 10.71 | 10.64 | 10.69 |
| 16 | 2 | 15.37 | 14.80 | 14.43 | 14.07 |
| 16 | 4 | 15.37 | 14.80 | 14.43 | 14.07 |

'outstanding' = `MAX_OUTSTANDING_READS = MAX_OUTSTANDING_WRITES`; 1 is the brief's initial configuration.

## 3. Where the cycles go (4 outstanding, skew 0 vs 16; matrix counters summed over the run)

| banks | skew | noise | B/cycle | matrix conflict cycles | matrix read-master arbitration stalls | avg matrix read latency | avg matrix write latency | DMA: write waits for read data |
|---|---|---|---|---|---|---|---|---|
| 4 | 0 B | 0% | 14.52 | 750 | 375 | 7.15 | 2.00 | 441 |
| 4 | 0 B | 100% | 10.74 | 24088 | 2730 | 10.43 | 7.60 | 2796 |
| 4 | 16 B | 0% | 15.37 | 0 | 0 | 2.00 | 2.00 | 66 |
| 4 | 16 B | 100% | 10.80 | 23921 | 2681 | 10.37 | 6.84 | 2747 |
| 8 | 0 B | 0% | 14.93 | 378 | 189 | 4.59 | 2.00 | 255 |
| 8 | 0 B | 100% | 13.72 | 12230 | 743 | 7.81 | 3.89 | 809 |
| 8 | 16 B | 0% | 15.37 | 0 | 0 | 2.00 | 2.00 | 66 |
| 8 | 16 B | 100% | 13.64 | 12197 | 796 | 7.88 | 3.11 | 862 |
| 16 | 0 B | 0% | 14.93 | 378 | 189 | 4.59 | 2.00 | 255 |
| 16 | 0 B | 100% | 14.20 | 6354 | 516 | 7.47 | 2.90 | 582 |
| 16 | 16 B | 0% | 15.37 | 0 | 0 | 2.00 | 2.00 | 66 |
| 16 | 16 B | 100% | 14.07 | 6026 | 587 | 7.55 | 2.01 | 653 |

'matrix conflict cycles' = cycles in which two or more masters requested the same bank (summed over banks).

## 4. What the measured stalls say, and what was done about it

1. **The initial configuration (1 outstanding) is latency-bound.** 10.7-10.8 B/cycle at 4/8/16 banks (67-68% of peak), independent of the bank count; the read side waits for its only slot (`dma_rd_stall_out` = 6096 cycles at 8 banks) and the matrix adds ~2 cycles read latency, so a burst occupies its slot for BL + latency + fixed overhead cycles (same law as docs/06).
2. **One more outstanding burst removes it.** 2 outstanding gives 14.52 / 14.93 / 14.93 B/cycle at 4/8/16 banks (+38% at 8 banks) and 4 outstanding gives 14.52 / 14.93 / 14.93 - **no further gain**, because the matrix latency is short. Recommended integrated configuration: `MAX_OUTSTANDING_READS = MAX_OUTSTANDING_WRITES = 2` (the 4-outstanding data-buffer and slot cost buys nothing here).
3. **4 banks: the loss was bank conflicts between the DMA's own streams, not matrix queue depth.** At skew 0 the 4-bank run reaches 14.52 B/cycle with 750 conflict cycles. Doubling the matrix request queue (`NSLOT` 8 -> 16, config `mb_b4_n4_s16`) changes nothing (14.52); skewing the destination by one beat drives the conflicts to 0 and the copy to **15.37 B/cycle** (+5.9%); at 8 banks 14.93 -> 15.37, at 16 banks 14.93 -> 15.37. This is a **placement rule, not an RTL change**. Skew sweep at 4 banks, no noise (bytes: B/cycle, conflict cycles): 0 B: 14.52, 750; 8 B: 14.51, 744; 16 B: 15.37, 0; 24 B: 15.36, 0; 32 B: 14.53, 744; 48 B: 15.37, 0. At 8 banks: 0 B: 14.93, 378; 8 B: 14.91, 375; 16 B: 15.37, 0; 24 B: 15.36, 0; 32 B: 14.94, 372; 48 B: 15.37, 0. Not every skew removes the conflicts, and what works depends on the fixed lag the DMA pipeline puts between its read and write streams, so this is measured for this workload and **not claimed in general**; P101's `mm_layout.py` is the tool for choosing placements.
4. **Longer bursts (BL 32)**: 4 banks 14.72 vs 14.52 B/cycle with no noise (+1.4%), 10.65 vs 10.74 with a noise master at 100% (-0.8%): a small effect either way, not worth a larger buffer here.
5. **Contention from another master.** A noise master at 100% costs 4 banks 26%, 8 banks 8%, 16 banks 5% of the DMA's throughput (skew 0): more banks leave room for the other master, as the bound in section 1 predicts.
6. **What is left is per-copy fill/drain, i.e. the one-transaction-in-flight contract.** The best configuration needs 1066 cycles per 16 KiB copy against 1024 ideal (42 cycles of start-up and tail, 4% below the datapath peak). Measured on the integrated system (8 banks, 2 outstanding, skew 16, no noise): one 16 KiB copy 15.37 B/cycle, **8 transactions of 4 KiB 13.79 B/cycle, 32 transactions of 64 bytes 1.94 B/cycle**. The per-transaction cost is fixed, so short transactions pay it in full. The remaining optimisation is transaction overlap (docs/08, docs/10 section 7); it was **not attempted**.

## 5. Hardware measurements

**None.** No FPGA bitstream or silicon exists for this block. Matrix and DMA latencies above are RTL-simulation cycle counts.
