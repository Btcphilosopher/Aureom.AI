#!/usr/bin/env python3
"""StreamDMA against the REAL MemoryMatrix (P101) RTL: throughput, matrix bank conflicts, latency.  All numbers are Verilator simulation cycles.
Builds every config of MM_BENCH_CONFIGS, runs `tb_<cfg> 1 bench`, writes benchmarks/stream_dma/mm_results.csv and benchmarks/stream_dma/REPORT_MM.md.
Every benchmark copy is also checked byte-for-byte by the bench (column ok).  The analysis text is generated from the data: re-running regenerates every quoted number."""
import csv, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
def sh(cmd, **kw): return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, **kw)
cfgs = sh(["bash", "-c", "source tests/stream_dma/mm/mm_configs.sh; echo $MM_BENCH_CONFIGS"]).stdout.split()
rows, hdr = [], None
for c in cfgs:
    r = sh(["bash", "scripts/build_mm_tb.sh", c])
    if r.returncode: print("BUILD FAILED", c, r.stdout[-300:]); sys.exit(2)
    runs = [{}]
    if c in ("mb_b4_n4", "mb_b8_n4"): runs.append({"TB_SKEWS": "8,24,32,48", "TB_NOISES": "0"})      # skew sweep (copy16k only)
    for extra in runs:
        t = sh([f"build/tb_{c}/tb_{c}", "1", "bench"], env=dict(os.environ, TB_CFGNAME=c, **extra), timeout=1800)
        for l in t.stdout.splitlines():
            if l.startswith("bench,config"): hdr = l.split(",")[1:]
            elif l.startswith("bench,"): rows.append(l.split(",")[1:])
    print("done", c, flush=True)
with open(os.path.join(ROOT, "benchmarks", "stream_dma", "mm_results.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(hdr); w.writerows(rows)
D = [dict(zip(hdr, r)) for r in rows]
bad = sum(1 for r in D if r["ok"] != "1")
def get(cfg, skew, noise, wl="copy16k"):
    for r in D:
        if r["config"] == cfg and r["workload"] == wl and int(r["skew_B"]) == skew and int(r["noise_pct"]) == noise: return r
bw = lambda cfg, sk, n: float(get(cfg, sk, n)["B_per_cycle"])
cf = lambda cfg, sk, n: int(get(cfg, sk, n)["mm_conflict_cycles"])
cyc_per_copy = lambda cfg, sk, n: int(get(cfg, sk, n)["cycles"]) / 6.0
O = []
O += ["# Benchmark report -- StreamDMA against the real MemoryMatrix (P101)", "",
      "**All numbers are SIMULATION cycles** of the integrated RTL (StreamDMA -> bridge -> `sf_memory_matrix`; 128-bit datapath, matrix read latency 1, no ECC, matrix queue depth 8 unless stated), measured with the DMA's own "
      "performance counters and the matrix's own counters. There is no FPGA or silicon measurement. Every copy is verified byte-for-byte (`ok` column: %s). Throughput is bytes per clock cycle; **no clock frequency is claimed**." %
      ("all 1" if bad == 0 else "**%d FAILED**" % bad), "",
      "Workload: 6 copies of 16 KiB (SRAM arena -> compute arena and back). *Noise* = another matrix master issuing random 1..16-byte reads/writes to a disjoint region at the stated probability per cycle (100% = a request every cycle). "
      "*Skew* = destination placement relative to the source: 0 bytes, or one beat (16 B); a wider skew sweep is in section 4. Raw rows: `mm_results.csv` (columns defined in the header line).", "",
      "## 1. Theoretical bounds (from the configuration only; not measured)", "",
      "* **DMA datapath peak** = 16 B/cycle (one 128-bit beat per cycle on R and on W).",
      "* **Matrix bank bound.** A copied byte is read once and written once = two bank-bytes. A bank accepts one 64-bit word (8 B) per cycle, so `NUM_BANKS` banks sustain at most `NUM_BANKS x 8 / 2 = 4 x NUM_BANKS` B/cycle of copy bandwidth: "
      "**16 / 32 / 64 B/cycle for 4 / 8 / 16 banks**. With 4 banks this equals the datapath peak, so any bank conflict must show as lost throughput; with 8 and 16 banks the DMA is datapath-limited and leaves headroom for other masters.",
      "* **Per-master bound.** Each of the DMA's two matrix masters issues at most one 16 B request per cycle.",
      "* **Per-copy fill/drain.** With one transaction in flight a copy has an unavoidable start-up (guard, AR, read latency, burst assembly) and tail (last write, B, completion record). Ideal copy time = 16384 B / 16 B/cycle = 1024 cycles.", ""]
O += ["## 2. Measured throughput (B/cycle; peak 16)", ""]
for skew in (0, 16):
    O += [f"### Destination skew {skew} B", "", "| banks | outstanding | noise 0% | noise 25% | noise 50% | noise 100% |", "|---|---|---|---|---|---|"]
    for b in (4, 8, 16):
        for n in (1, 2, 4):
            if get(f"mb_b{b}_n{n}", skew, 0): O.append(f"| {b} | {n} | " + " | ".join(f"{bw(f'mb_b{b}_n{n}', skew, x):.2f}" for x in (0, 25, 50, 100)) + " |")
    O.append("")
O += ["'outstanding' = `MAX_OUTSTANDING_READS = MAX_OUTSTANDING_WRITES`; 1 is the brief's initial configuration.", "",
      "## 3. Where the cycles go (4 outstanding, skew 0 vs 16; matrix counters summed over the run)", "",
      "| banks | skew | noise | B/cycle | matrix conflict cycles | matrix read-master arbitration stalls | avg matrix read latency | avg matrix write latency | DMA: write waits for read data |", "|---|---|---|---|---|---|---|---|---|"]
for b in (4, 8, 16):
    for sk in (0, 16):
        for n in (0, 100):
            r = get(f"mb_b{b}_n4", sk, n)
            O.append(f"| {b} | {sk} B | {n}% | {float(r['B_per_cycle']):.2f} | {r['mm_conflict_cycles']} | {r['mm_rd_arbstall']} | {r['mm_rd_lat_avg']} | {r['mm_wr_lat_avg']} | {r['dma_wr_stall_data']} |")
O += ["", "'matrix conflict cycles' = cycles in which two or more masters requested the same bank (summed over banks).", "",
      "## 4. What the measured stalls say, and what was done about it", ""]
b1 = [bw(f"mb_b{b}_n1", 0, 0) for b in (4, 8, 16)]
O += [f"1. **The initial configuration (1 outstanding) is latency-bound.** {min(b1):.1f}-{max(b1):.1f} B/cycle at 4/8/16 banks ({100*min(b1)/16:.0f}-{100*max(b1)/16:.0f}% of peak), independent of the bank count; "
      f"the read side waits for its only slot (`dma_rd_stall_out` = {get('mb_b8_n1', 0, 0)['dma_rd_stall_out']} cycles at 8 banks) and the matrix adds ~2 cycles read latency, so a burst occupies its slot for BL + latency + fixed overhead cycles (same law as docs/06).",
      f"2. **One more outstanding burst removes it.** 2 outstanding gives {bw('mb_b4_n2',0,0):.2f} / {bw('mb_b8_n2',0,0):.2f} / {bw('mb_b16_n2',0,0):.2f} B/cycle at 4/8/16 banks "
      f"(+{100*(bw('mb_b8_n2',0,0)/bw('mb_b8_n1',0,0)-1):.0f}% at 8 banks) and 4 outstanding gives {bw('mb_b4_n4',0,0):.2f} / {bw('mb_b8_n4',0,0):.2f} / {bw('mb_b16_n4',0,0):.2f} - **no further gain**, because the matrix latency is short. "
      "Recommended integrated configuration: `MAX_OUTSTANDING_READS = MAX_OUTSTANDING_WRITES = 2` (the 4-outstanding data-buffer and slot cost buys nothing here).",
      f"3. **4 banks: the loss was bank conflicts between the DMA's own streams, not matrix queue depth.** At skew 0 the 4-bank run reaches {bw('mb_b4_n4',0,0):.2f} B/cycle with {cf('mb_b4_n4',0,0)} conflict cycles. "
      f"Doubling the matrix request queue (`NSLOT` 8 -> 16, config `mb_b4_n4_s16`) changes nothing ({bw('mb_b4_n4_s16',0,0):.2f}); skewing the destination by one beat drives the conflicts to {cf('mb_b4_n4',16,0)} and the copy to **{bw('mb_b4_n4',16,0):.2f} B/cycle** "
      f"(+{100*(bw('mb_b4_n4',16,0)/bw('mb_b4_n4',0,0)-1):.1f}%); at 8 banks {bw('mb_b8_n4',0,0):.2f} -> {bw('mb_b8_n4',16,0):.2f}, at 16 banks {bw('mb_b16_n4',0,0):.2f} -> {bw('mb_b16_n4',16,0):.2f}. "
      f"This is a **placement rule, not an RTL change**. Skew sweep at 4 banks, no noise (bytes: B/cycle, conflict cycles): " + "; ".join(f"{k} B: {bw('mb_b4_n4',k,0):.2f}, {cf('mb_b4_n4',k,0)}" for k in (0, 8, 16, 24, 32, 48)) + ". At 8 banks: " + "; ".join(f"{k} B: {bw('mb_b8_n4',k,0):.2f}, {cf('mb_b8_n4',k,0)}" for k in (0, 8, 16, 24, 32, 48)) + ". "
      "Not every skew removes the conflicts, and what works depends on the fixed lag the DMA pipeline puts between its read and write streams, so this is measured for this workload and **not claimed in general**; P101's `mm_layout.py` is the tool for choosing placements.",
      f"4. **Longer bursts (BL 32)**: 4 banks {bw('mb_b4_n4_bl32',0,0):.2f} vs {bw('mb_b4_n4',0,0):.2f} B/cycle with no noise ({100*(bw('mb_b4_n4_bl32',0,0)/bw('mb_b4_n4',0,0)-1):+.1f}%), {bw('mb_b4_n4_bl32',0,100):.2f} vs {bw('mb_b4_n4',0,100):.2f} with a noise master at 100% ({100*(bw('mb_b4_n4_bl32',0,100)/bw('mb_b4_n4',0,100)-1):+.1f}%): a small effect either way, not worth a larger buffer here.",
      f"5. **Contention from another master.** A noise master at 100% costs 4 banks {100*(1-bw('mb_b4_n4',0,100)/bw('mb_b4_n4',0,0)):.0f}%, 8 banks {100*(1-bw('mb_b8_n4',0,100)/bw('mb_b8_n4',0,0)):.0f}%, 16 banks {100*(1-bw('mb_b16_n4',0,100)/bw('mb_b16_n4',0,0)):.0f}% of the DMA's throughput (skew 0): more banks leave room for the other master, as the bound in section 1 predicts.",
      f"6. **What is left is per-copy fill/drain, i.e. the one-transaction-in-flight contract.** The best configuration needs {cyc_per_copy('mb_b8_n2',16,0):.0f} cycles per 16 KiB copy against 1024 ideal ({cyc_per_copy('mb_b8_n2',16,0)-1024:.0f} cycles of start-up and tail, "
      f"{100*(1-bw('mb_b8_n2',16,0)/16):.0f}% below the datapath peak). Measured on the integrated system (8 banks, 2 outstanding, skew 16, no noise): one 16 KiB copy {bw('mb_b8_n2',16,0):.2f} B/cycle, **8 transactions of 4 KiB {float(get('mb_b8_n2',16,0,'txn4k')['B_per_cycle']):.2f} B/cycle, 32 transactions of 64 bytes {float(get('mb_b8_n2',16,0,'txn64')['B_per_cycle']):.2f} B/cycle**. "
      "The per-transaction cost is fixed, so short transactions pay it in full. The remaining optimisation is transaction overlap (docs/08, docs/10 section 7); it was **not attempted**.", "",
      "## 5. Hardware measurements", "", "**None.** No FPGA bitstream or silicon exists for this block. Matrix and DMA latencies above are RTL-simulation cycle counts."]
open(os.path.join(ROOT, "benchmarks", "stream_dma", "REPORT_MM.md"), "w").write("\n".join(O) + "\n")
print("wrote mm_results.csv (%d rows, %d with ok!=1) and REPORT_MM.md" % (len(D), bad)); sys.exit(1 if bad else 0)
