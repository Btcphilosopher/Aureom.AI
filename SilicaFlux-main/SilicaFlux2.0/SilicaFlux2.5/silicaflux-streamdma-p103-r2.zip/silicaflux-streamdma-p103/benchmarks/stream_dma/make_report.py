#!/usr/bin/env python3
"""Generate benchmarks/stream_dma/REPORT.md from results.csv.  Keeps THEORETICAL throughput (computed from the configuration only)
strictly separate from MEASURED throughput (simulation counters).  There is no hardware measurement in this project."""
import csv, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
rows = list(csv.DictReader(open(os.path.join(ROOT, "benchmarks/stream_dma/results.csv"))))
def cfg_params(name):
    src = open(os.path.join(ROOT, "tests/stream_dma/configs.sh")).read()
    m = re.search(r"CFG_%s=\(([^)]*)\)" % name, src); d = {}
    for kv in m.group(1).split(): k, v = kv.split("="); d[k] = int(v)
    return d
cfgs = []; [cfgs.append(r["config"]) for r in rows if r["config"] not in cfgs]
def get(c, wl, cond): return [r for r in rows if r["config"] == c and r["workload"] == wl and r["condition"] == cond][0]
LAT = {"lat2": 2, "lat10": 10, "lat30": 30, "lat80": 80}
C0 = 2   # fitted per-burst pipeline constant, see below
out = []
w = out.append
w("# Benchmark report -- StreamDMA\n")
w("**All measured numbers below are SIMULATION cycles** from the DUT's own performance counters against a behavioural AXI slave model (fixed latency, ideal or randomly "
  "back-pressured handshakes). **There are no FPGA or silicon measurements in this project.** Every benchmark run is also checked byte-for-byte against the reference model "
  "(`ok` column of results.csv is 1 for all rows). Throughput is quoted in bytes per clock cycle; no clock frequency is claimed anywhere.\n")
w("## 1. Theoretical throughput (from the configuration only; not measured)\n")
w("* **Datapath peak** = `W` bytes/cycle = `DATA_WIDTH/8`: one full beat per cycle on R and one on W. A copy moves each byte once through each, so the ceiling is `W` B/cycle "
  "(128-bit: 16 B/cycle; 256-bit: 32 B/cycle). Short bursts or backpressure only lower it.")
w("* **Latency-bound limit** with `N` outstanding bursts of `BL` beats and memory latency `L` cycles: a burst occupies a slot for `BL + L + c` cycles, so "
  "`BW(N) = min( W , N * BL * W / (BL + L + c) )`, with `c` = fixed internal pipeline cycles per burst.")
w(f"* `c` is not derived from the RTL; it is **fitted once from the single-outstanding measurements** (Phase 1, `b_n1`): the measured period at L = 2, 10, 30, 80 is "
  f"`BL + L + 2` each time, so `c = {C0}`. The Phase-2 results below are then *predictions* of this formula, not refits.")
w("* **Bytes in flight needed to reach the peak** = `W * (BL + L + c)`: the data buffer must hold at least that much (`FIFO_DEPTH >= N * BL`) and `N >= ceil((BL + L + c) / BL)`.\n")
w("## 2. Measured, Phase 1 -> Phase 2 (128 KiB aligned copy, simulation)\n")
w("| config | N rd/wr | BL | FIFO | PLAN | " + " | ".join(f"{c} B/cyc (pred)" for c in ("lat2", "lat10", "lat30", "lat80")) + " | lat10 + 70% backpressure |")
w("|---|---|---|---|---|---|---|---|---|---|")
for c in cfgs:
    p = cfg_params(c); W = p["DATA_WIDTH"] // 8; BL = p["BURST_LENGTH"]; N = p["MAX_OUTSTANDING_READS"]
    cells = []
    for cond in ("lat2", "lat10", "lat30", "lat80"):
        m = float(get(c, "stream_128KiB_aligned", cond)["bw_B_per_cycle"]); L = LAT[cond]
        pred = min(W, N * BL * W / (BL + L + C0))
        cells.append(f"{m:.2f} ({pred:.2f})")
    bp = float(get(c, "stream_128KiB_aligned", "lat10_bp70")["bw_B_per_cycle"])
    w(f"| {c} | {N}/{p['MAX_OUTSTANDING_WRITES']} | {BL} | {p['FIFO_DEPTH']} | {p['PLAN_DEPTH']} | " + " | ".join(cells) + f" | {bp:.2f} |")
w("\nPeak is 16 B/cycle (32 for `b_n4_dw256`). 'pred' is the formula of section 1 with `c = 2`.\n")
w("## 3. What the stall counters say (128 KiB aligned copy, lat10) -- the measurements that drove Phase 2\n")
w("| config | active cycles | rd stall: no free slot | rd stall: buffer full | rd stall: guard | wr stall: waiting for read data | wr stall: W/AW not accepted | buf occupancy (avg beats) |")
w("|---|---|---|---|---|---|---|---|")
for c in cfgs:
    r = get(c, "stream_128KiB_aligned", "lat10")
    w(f"| {c} | {r['active_cycles']} | {r['rd_stall_out']} | {r['rd_stall_buf']} | {r['rd_stall_guard']} | {r['wr_stall_data']} | {int(r['wr_stall_w'])+int(r['wr_stall_aw'])} | {r['buf_occ_avg']} |")
w("""
Reading the table:

* **Phase 1 (`b_n1`, one outstanding)**: 82% of active cycles the next read burst is ready but the only slot is busy (*no free slot*), and the assembler waits for source
  data for 39% of the cycles (*waiting for read data*). The buffer is almost empty (0.57 beats on average). Diagnosis: **latency-bound, not bandwidth-bound**.
* **Phase 2 (`b_n2` ... `b_n8`)**: with enough slots the 'no free slot' stall just means the read side is *ahead* of the single W channel (the datapath is the limit);
  the waiting-for-data stall disappears (18 cycles = pipeline fill) and the copy runs at 99% of the datapath peak. `b_n2` suffices at L = 10; L = 30 needs N = 4; L = 80 needs N = 8
  (or `BL = 32` with N = 4: `b_n4_bl32`), exactly as the bytes-in-flight rule predicts.
* **`b_n4_f32` (FIFO_DEPTH 32)**: 7656 *buffer full* stalls and a collapse at higher latency -- the buffer, not the slot count, was the limit (needs `FIFO_DEPTH >= N * BL`).
* **`b_n4_p1` (PLAN_DEPTH 1)**: guard look-ahead disabled costs ~6% at low latency (15.00 vs 15.93 B/cycle): the guard round trip per burst is then not hidden.
* **Unaligned** copies (source +3, destination +5) run at the same rate as aligned ones (results.csv): the byte realigner costs no throughput.
* **Burst utilisation** (`rd_beats / (rd_bursts x BL)`) is 100% for these large transfers (all bursts are full); see results.csv for the small-transfer workloads.
""")
w("## 4. What is still slow: many small transactions\n")
rs = {c: get(c, "txn_x64_64B", "lat10") for c in cfgs}
w(f"`txn_x64_64B` (64 transactions of 64 bytes) runs at **{float(rs['b_n4']['bw_B_per_cycle']):.2f} B/cycle for every N and every buffer size** (mean transaction latency "
  f"{rs['b_n4']['lat_avg']} cycles at L = 10): the limit is the **one-transaction-in-flight contract**, not memory parallelism, so more outstanding requests cannot help. "
  "Cycle breakdown of one 64-byte transaction at L = 2 (trace, `tb_b_n4 1 trace_small`), 29 cycles per transaction: AR -> last R beat 5, last R beat -> AW 5 "
  "(response ingest, realign, W-FIFO fill, AW issue), AW -> B 5, B -> completion record 3, **completion accepted -> next transaction's first AR 11** "
  "(completion handshake, `txn_done`, validator, segment FIFOs, hazard check, planner, guard round trip, AR issue). The measured next optimisation is therefore "
  "**overlapping the start of transaction n+1 with the completion tail of transaction n**, which needs per-transaction contexts and error attribution; it was "
  "deliberately **not** attempted here (docs/08). Large-transfer throughput is unaffected.\n")
w("## 5. Other workloads (B/cycle, lat10)\n")
w("| config | 128 KiB unaligned | 32 x 2 KiB scatter-gather | 64 x 256 B scatter-gather | 32 x 4 KiB transactions | 64 x 64 B transactions |")
w("|---|---|---|---|---|---|")
for c in cfgs:
    w(f"| {c} | " + " | ".join(f"{float(get(c, wl, 'lat10')['bw_B_per_cycle']):.2f}" for wl in ("stream_128KiB_unaligned", "sg_32x2KiB", "sg_64x256B", "txn_x32_4KiB", "txn_x64_64B")) + " |")
w("\n## 6. Hardware measurements\n\n**None.** No FPGA bitstream or silicon exists for this block; no frequency, power or area-in-um^2 figure is claimed. "
  "Resource counts are in reports/synth.md and are Yosys generic-cell / Xilinx-7 mapping estimates only.\n")
open(os.path.join(ROOT, "benchmarks/stream_dma/REPORT.md"), "w").write("\n".join(out))
print("wrote REPORT.md")
