// Bounded proof for the byte realigner: the output byte stream equals the input byte stream (order preserved, nothing lost or
// duplicated), strobes mark exactly the popped lanes, unused lanes are zero, and the fill level stays within the accumulator.
// Stream bytes are tagged with their 8-bit sequence number so any reorder/loss/duplication shows up as a mismatch.
module fv_align #(parameter DW = 64) (
  input wire clk,
  input wire in_valid, input wire [7:0] in_nb_raw,
  input wire pop_req, input wire [7:0] pop_lo_raw, input wire [7:0] pop_n_raw
);
  localparam W = DW / 8, LW = $clog2(W), CW = $clog2(2 * W + 1);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire in_ready, pop_ok; wire [DW-1:0] out_data; wire [W-1:0] out_strb; wire [CW-1:0] cnt;
  // environment contract, built into the stimulus (no assume needed): runs are 1..W bytes packed in the low lanes with the upper lanes zero;
  // pops are 1..W bytes placed so that they fit between lane pop_lo and the top of the beat.
  wire [LW:0] in_nbytes = {1'b0, in_nb_raw[LW-1:0]} + 1;
  wire [LW:0] pop_n     = {1'b0, pop_n_raw[LW-1:0]} + 1;
  wire [LW:0] room      = W - pop_n;
  wire [LW-1:0] pop_lo  = ({1'b0, pop_lo_raw[LW-1:0]} > room) ? room[LW-1:0] : pop_lo_raw[LW-1:0];
  reg [15:0] in_seq = 0, out_seq = 0;
  reg [DW-1:0] in_data;
  integer i;
  always @* begin
    in_data = 0;
    for (i = 0; i < W; i = i + 1) if (i < in_nbytes) in_data[8*i +: 8] = (in_seq + i);
  end
  sf_stream_dma_align #(.DW(DW)) dut (.clk(clk), .rst_n(rst_n), .flush(1'b0), .in_valid(in_valid), .in_ready(in_ready), .in_data(in_data), .in_nbytes(in_nbytes),
    .pop_req(pop_req), .pop_lo(pop_lo), .pop_n(pop_n), .pop_ok(pop_ok), .out_data(out_data), .out_strb(out_strb), .cnt(cnt));
  wire do_push = in_valid && in_ready, do_pop = pop_req && pop_ok;
  always @(posedge clk) begin
    if (rst_n) begin
      if (do_push) in_seq <= in_seq + in_nbytes;
      if (do_pop)  out_seq <= out_seq + pop_n;
    end
  end
  always @* begin
    if (rst_n) begin
      assert(cnt <= 2 * W);                                  // accumulator never overflows
      assert(cnt == in_seq - out_seq);                       // byte conservation: nothing lost, nothing duplicated
      assert(pop_ok == (pop_n <= cnt));                      // a pop succeeds exactly when the bytes are there
      assert(in_ready == ((cnt - (do_pop ? pop_n : 0)) <= W));
      if (do_pop) begin
        for (i = 0; i < W; i = i + 1) begin
          if (i >= pop_lo && i < pop_lo + pop_n) begin
            assert(out_strb[i] == 1'b1);
            assert(out_data[8*i +: 8] == (out_seq + (i - pop_lo)));   // order preserved: the k-th popped byte is the k-th stream byte
          end else begin
            assert(out_strb[i] == 1'b0);
            assert(out_data[8*i +: 8] == 8'h00);                      // no stale data on unused lanes
          end
        end
      end
    end
  end
endmodule
