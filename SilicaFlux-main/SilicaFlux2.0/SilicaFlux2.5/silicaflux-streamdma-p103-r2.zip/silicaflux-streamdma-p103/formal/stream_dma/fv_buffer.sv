// Bounded proof for the reservation ring: equivalence with a shadow model (valid bits, data, counters), plus the reorder
// property: entries become visible at the head strictly in reservation order, whatever order they were filled in.
module fv_buffer #(parameter DW = 32, parameter DEPTH = 4) (
  input wire clk, input wire rsv_valid, input wire [7:0] rsv_n_raw, input wire fill_valid_raw, input wire [7:0] fill_idx_raw,
  input wire [DW-1:0] fill_data, input wire [7:0] fill_nb_raw, input wire head_pop
);
  localparam IW = $clog2(DEPTH), CW = $clog2(DEPTH + 1), LW = $clog2(DW/8);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire rsv_ok; wire [IW-1:0] rsv_base; wire head_valid; wire [DW-1:0] head_data; wire [LW:0] head_nbytes; wire [CW-1:0] occ, rsv; wire empty;
  // environment contract by construction: a reservation is 1..DEPTH beats; a fill targets an entry that is reserved and not yet filled
  wire [8:0] rsv_n = {1'b0, 1'b0, rsv_n_raw[IW-1:0]} + 9'd1;
  wire [IW-1:0] fill_idx = fill_idx_raw[IW-1:0];
  reg [DEPTH-1:0] s_rsvd = 0, s_vld = 0; reg [DW-1:0] s_d [0:DEPTH-1]; reg [LW:0] s_n [0:DEPTH-1];
  reg [IW-1:0] s_rp = 0, s_wp = 0; reg [CW-1:0] s_cnt = 0, s_occ = 0;
  wire fill_valid = fill_valid_raw && s_rsvd[fill_idx] && !s_vld[fill_idx];
  wire [LW:0] fill_nbytes = {1'b0, fill_nb_raw[LW-1:0]} + 1;
  sf_stream_dma_buffer #(.DW(DW), .DEPTH(DEPTH)) dut (.clk(clk), .rst_n(rst_n), .flush(1'b0), .rsv_valid(rsv_valid), .rsv_n(rsv_n), .rsv_ok(rsv_ok), .rsv_base(rsv_base),
    .fill_valid(fill_valid), .fill_idx(fill_idx), .fill_data(fill_data), .fill_nbytes(fill_nbytes), .head_valid(head_valid), .head_data(head_data),
    .head_nbytes(head_nbytes), .head_pop(head_pop), .occ(occ), .rsv(rsv), .empty(empty));
  integer k;
  wire do_rsv = rsv_valid && rsv_ok;
  wire pop = head_valid && head_pop;
  always @(posedge clk) if (rst_n) begin
    if (do_rsv) begin for (k = 0; k < DEPTH; k = k + 1) if (((k - s_wp) % DEPTH + DEPTH) % DEPTH < rsv_n) s_rsvd[k] <= 1'b1; s_wp <= s_wp + rsv_n[IW-1:0]; end
    if (fill_valid) begin s_vld[fill_idx] <= 1'b1; s_d[fill_idx] <= fill_data; s_n[fill_idx] <= fill_nbytes; end
    if (pop) begin s_vld[s_rp] <= 1'b0; s_rsvd[s_rp] <= 1'b0; s_rp <= s_rp + 1'b1; end
    s_cnt <= s_cnt + (do_rsv ? rsv_n[CW-1:0] : 0) - (pop ? 1 : 0);
    s_occ <= s_occ + (fill_valid ? 1 : 0) - (pop ? 1 : 0);
  end
  always @* if (rst_n) begin
    assert(rsv == s_cnt); assert(occ == s_occ); assert(empty == (s_cnt == 0));
    assert(rsv <= DEPTH); assert(occ <= rsv);
    assert(rsv_ok == ((rsv + rsv_n) <= DEPTH));
    assert(rsv_base == s_wp);
    assert(head_valid == s_vld[s_rp]);                    // the head is visible only once ITS entry arrived, regardless of later entries
    if (head_valid) begin assert(head_data == s_d[s_rp]); assert(head_nbytes == s_n[s_rp]); end
  end
endmodule
