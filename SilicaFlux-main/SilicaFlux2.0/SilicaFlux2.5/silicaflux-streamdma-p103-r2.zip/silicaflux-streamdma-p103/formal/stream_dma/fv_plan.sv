// Exhaustive proof (all inputs) for the burst planner.  The reference below restates the specification in plain integer
// arithmetic, independently of the RTL's structure.
module fv_plan #(parameter DW = 128, parameter BL = 16, parameter REM_W = 25) (
  input wire [11:0] addr_lo,
  input wire [REM_W-1:0] rem
);
  localparam W = DW / 8;
  localparam LW = $clog2(W);
  wire [12:0] nbytes; wire [8:0] nbeats; wire [LW-1:0] off, endl;
  sf_stream_dma_plan #(.DW(DW), .BL(BL), .REM_W(REM_W)) dut (.addr_lo(addr_lo), .rem(rem), .nbytes(nbytes), .nbeats(nbeats), .off(off), .endl(endl));

  reg [31:0] a, o, m, nb, env_start, payload;
  always @* begin
    assume(rem != 0);
    a = addr_lo; o = a % W;
    m = rem;
    if (BL * W - o < m) m = BL * W - o;
    if (4096 - a < m)   m = 4096 - a;
    nb = (o + m + W - 1) / W;
    // exact spec
    assert(nbytes == m);
    assert(off == o);
    assert(nbeats == nb);
    // derived safety properties
    assert(nbytes >= 1);                         // progress
    assert(nbytes <= rem);                       // never moves more than is left
    assert(nbytes <= 4096);
    assert(nbeats >= 1 && nbeats <= BL);         // burst length
    env_start = a - o;
    assert(env_start + nbeats * W <= 4096);      // the beat envelope never leaves the 4 KiB page
    assert(a + nbytes <= env_start + nbeats * W);// the payload is inside the envelope
    assert(endl < W);
    payload = (nbeats - 1) * W + endl - off + 1; // lane accounting: payload bytes over all beats == nbytes
    assert(payload == nbytes);
  end
endmodule
