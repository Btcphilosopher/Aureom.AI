// Exhaustive proof for the descriptor checker: err == 0  <=>  the descriptor satisfies every acceptance rule, stated here
// with 128-bit arithmetic.  err == 0 therefore implies: no address / length overflow, in range, no overlap, domain bound.
module fv_dcheck #(parameter AW = 40, parameter DOM_W = 4, parameter SEGL = 24, parameter TXNL = 30) (
  input wire [255:0] desc, input wire [DOM_W-1:0] trusted, input wire [15:0] type_en,
  input wire in_txn, input wire [15:0] cur_id, input wire [DOM_W-1:0] cur_dom, input wire [TXNL:0] cur_total
);
  wire [7:0] err;
  sf_stream_dma_dcheck #(.AW(AW), .DOM_W(DOM_W), .MAX_SEG_LOG2(SEGL), .MAX_TXN_LOG2(TXNL)) dut (
    .desc(desc), .trusted_domain(trusted), .type_en(type_en), .in_txn(in_txn), .cur_txn_id(cur_id), .cur_domain(cur_dom), .cur_total(cur_total), .err(err));
  wire [127:0] src = desc[191:128], dst = desc[255:192], len = desc[127:96];
  wire [127:0] LIM = 128'd1 << AW;
  wire first = desc[16], f_cpl = desc[19], f_irq = desc[20];
  wire [3:0] st = desc[67:64], dt = desc[71:68];
  wire good =
       desc[7:0] == 8'd1 && desc[15:8] == 8'd0
    && desc[63:48] == trusted
    && desc[31:21] == 11'd0 && (first || (!f_cpl && !f_irq))
    && desc[95:72] == 24'd0
    && (in_txn ? !first : first)
    && (!in_txn || (desc[47:32] == cur_id && trusted == cur_dom))
    && st < 5 && dt < 5 && type_en[st] && type_en[dt]
    && len >= 1 && len <= (128'd1 << SEGL)
    && (in_txn ? cur_total : 0) + len <= (128'd1 << TXNL)     // cur_total is already ctx_total in the RTL; see below
    && src < LIM && dst < LIM && src + len <= LIM && dst + len <= LIM
    && !(st == dt && src < dst + len && dst < src + len);
  // the RTL receives ctx_total (0 outside a transaction) from the validator, so feed the same value to the reference
  always @* begin
    assume(in_txn || cur_total == 0);
    assert((err == 8'd0) == good);
    if (err == 8'd0) begin
      assert(src + len <= LIM);
      assert(dst + len <= LIM);
      assert(len >= 1);
      assert(!(st == dt && src < dst + len && dst < src + len));
      assert(desc[63:48] == trusted);
    end
  end
endmodule
