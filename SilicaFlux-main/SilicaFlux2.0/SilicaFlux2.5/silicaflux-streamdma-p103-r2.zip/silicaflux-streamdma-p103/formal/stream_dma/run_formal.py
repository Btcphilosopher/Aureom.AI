#!/usr/bin/env python3
"""Formal runner (Yosys + yosys-smtbmc + z3; the same pipeline SymbiYosys wraps).
Each job: read RTL + harness with -formal, chparam, prep, async2sync, write_smt2, then BMC (-t depth) and optionally k-induction (-i).
usage: run_formal.py [--only NAME] [--report reports/formal.md]"""
import argparse, os, subprocess, sys, time, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RTL = ["third_party/p61-clouddpu/rtl/sfd_fifo.sv"] + ["rtl/stream_dma/sf_stream_dma_%s.sv" % n for n in
       ("plan", "dcheck", "align", "buffer", "cpl")]
# name, harness file, top, params, depth, engine, what is proved.  engine "smt" = yosys-smtbmc + z3, "sat" = yosys built-in SAT (minisat) unrolling
JOBS = [
 ("plan_dw128_bl16", "fv_plan.sv", "fv_plan", "DW=128 BL=16 REM_W=25", 1, "smt", "burst planner, exhaustive"),
 ("plan_dw32_bl64",  "fv_plan.sv", "fv_plan", "DW=32 BL=64 REM_W=19", 1, "smt", "burst planner, exhaustive"),
 ("plan_dw512_bl8",  "fv_plan.sv", "fv_plan", "DW=512 BL=8 REM_W=25", 1, "smt", "burst planner, exhaustive"),
 ("plan_dw64_bl3",   "fv_plan.sv", "fv_plan", "DW=64 BL=3 REM_W=16", 1, "smt", "burst planner, exhaustive (non power-of-two BURST_LENGTH)"),
 ("dcheck_aw40",     "fv_dcheck.sv", "fv_dcheck", "AW=40 DOM_W=4 SEGL=24 TXNL=30", 1, "smt", "descriptor checker == acceptance rules, exhaustive"),
 ("dcheck_aw64",     "fv_dcheck.sv", "fv_dcheck", "AW=64 DOM_W=4 SEGL=24 TXNL=30", 1, "smt", "descriptor checker, 64-bit addresses (no wrap), exhaustive"),
 ("dcheck_aw16",     "fv_dcheck.sv", "fv_dcheck", "AW=16 DOM_W=2 SEGL=8 TXNL=10", 1, "smt", "descriptor checker, small limits, exhaustive"),
 ("align_dw16",      "fv_align.sv", "fv_align", "DW=16", 12, "sat", "byte realigner: order / loss / duplication / strobes / zero lanes (BMC)"),
 ("align_dw32",      "fv_align.sv", "fv_align", "DW=32", 8, "sat", "byte realigner: order / loss / duplication / strobes / zero lanes (BMC)"),
 ("buffer_d4",       "fv_buffer.sv", "fv_buffer", "DW=32 DEPTH=4", 12, "sat", "reservation ring == shadow model; in-order visibility (BMC)"),
 ("buffer_d8",       "fv_buffer.sv", "fv_buffer", "DW=16 DEPTH=8", 9, "sat", "reservation ring == shadow model; in-order visibility (BMC)"),
 ("cpl",             "fv_cpl.sv", "fv_cpl", "AW=16 DOM_W=2 TXNL=8", 12, "sat", "completion engine contract (BMC)"),
]
def prep_script(job, files_root=""):
    name, h, top, params, depth, eng, what = job
    ys = ["read_verilog -formal -sv -I rtl/stream_dma " + " ".join(RTL) + " formal/stream_dma/" + h]
    for kv in params.split():
        k, v = kv.split("="); ys.append(f"chparam -set {k} {v} {top}")
    ys += [f"prep -top {top}", "flatten", "memory_map", "async2sync", "dffunmap"]
    return ys

def run(job, out, cwd=None, tmo=1500):
    name, h, top, params, depth, eng, what = job
    cwd = cwd or ROOT
    d = os.path.join(out, name); os.makedirs(d, exist_ok=True)
    ys = prep_script(job)
    t0 = time.time()
    if eng == "sat":
        ys.append(f"sat -verify -seq {depth} -prove-asserts -timeout {tmo}")
        try:
            r = subprocess.run(["yosys", "-q", "-l", f"{d}/log.txt", "-p", "; ".join(ys)], cwd=cwd, capture_output=True, text=True, timeout=tmo + 60)
        except subprocess.TimeoutExpired:
            return name, "TIMEOUT", time.time() - t0, "no result in %d s at depth %d" % (tmo, depth), what
        log = open(f"{d}/log.txt").read() if os.path.exists(f"{d}/log.txt") else ""
        if "no model found: SUCCESS" in log: st = "PASS"
        elif "model found: FAIL" in log: st = "FAIL"
        else: st = "ERROR"
        return name, st, time.time() - t0, ("" if st == "PASS" else (r.stdout + r.stderr)[-300:]), what
    ys += [f"write_smt2 -wires {d}/m.smt2"]
    r = subprocess.run(["yosys", "-q", "-p", "; ".join(ys)], cwd=cwd, capture_output=True, text=True)
    if r.returncode: return name, "ERROR", 0, r.stdout[-400:] + r.stderr[-400:], what
    cmd = ["yosys-smtbmc", "-s", "z3", "-t", str(depth), "--presat", f"{d}/m.smt2"]
    try:
        b = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=tmo)
    except subprocess.TimeoutExpired:
        return name, "TIMEOUT", time.time() - t0, "solver did not finish in %d s at depth %d" % (tmo, depth), what
    st = "PASS" if "Status: PASSED" in b.stdout else ("FAIL" if "Status: FAILED" in b.stdout else "ERROR")
    return name, st, time.time() - t0, "" if st == "PASS" else b.stdout[-300:], what

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--only"); ap.add_argument("--report", default="reports/formal.md"); a = ap.parse_args()
    out = os.path.join(ROOT, "build", "formal"); shutil.rmtree(out, ignore_errors=True)
    rows = []
    for j in JOBS:
        if a.only and a.only not in j[0]: continue
        r = run(j, out); rows.append((r, j)); print(f"{r[1]:5s} {r[0]:18s} {r[2]:6.1f}s  {r[4]}  {r[3]}", flush=True)
    ok = all(r[0][1] == "PASS" for r in rows)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, a.report), "w") as f:
        f.write("# Formal verification results\n\nTools: Yosys 0.33 (built-in SAT for the sequential jobs, `yosys-smtbmc` + Z3 4.8.12 for the combinational ones). SymbiYosys is not packaged for this environment.\n"
                "'exhaustive' = bit-vector SAT over ALL input values (a proof). 'BMC' = bounded model check from reset to the stated depth (a bounded proof, NOT an unbounded one).\n\n"
                "| job | result | depth | time | engine | what |\n|---|---|---|---|---|---|\n")
        for (r, j) in rows: f.write(f"| {r[0]} | {r[1]} | {j[4]} | {r[2]:.1f}s | {j[5]} | {r[4]} |\n")
        f.write("\nNot formally verified (simulation only): read/write engines, top-level integration, MemoryGuard path (vendored, verified in CloudDMA P64).\n")
    sys.exit(0 if ok else 1)
