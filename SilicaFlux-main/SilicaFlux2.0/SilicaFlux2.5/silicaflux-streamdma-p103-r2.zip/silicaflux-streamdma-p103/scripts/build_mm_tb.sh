#!/bin/bash
# build_mm_tb.sh <cfg> [extra RTL dir for mutants]: build the StreamDMA <-> MemoryMatrix Verilator bench (configs: tests/stream_dma/mm/mm_configs.sh)
set -e
cd "$(dirname "$0")/.."
CFG=${1:-mm_initial}; RTLDIR=${2:-rtl/stream_dma}; OUT=${MM_BUILD_DIR:-build}/tb_$CFG
source tests/stream_dma/mm/mm_configs.sh
declare -n C=CFG_$CFG
mkdir -p $OUT
G=""; D=""; NB=4; BD=4096; DW=128
for kv in "${C[@]}"; do
  k=${kv%%=*}; v=${kv#*=}
  G="$G -G$k=$v"
  case $k in
    DATA_WIDTH) D="$D -DTB_DW=$v"; DW=$v;; BURST_LENGTH) D="$D -DTB_BL=$v";;
    MAX_OUTSTANDING_READS) D="$D -DTB_NR=$v";; MAX_OUTSTANDING_WRITES) D="$D -DTB_NW=$v";;
    NUM_BANKS) NB=$v;; BANK_DEPTH) BD=$v;; ENABLE_ECC) D="$D -DTB_ECC=$v";;
  esac
done
D="$D -DTB_MMBYTES=$((NB*BD*8))"
# mutants replace single RTL files: RTLDIR holds a patched copy of rtl/stream_dma
FL=$(mktemp); sed "s#rtl/stream_dma/#$RTLDIR/#" rtl/filelist.f > $FL.a; sed "s#rtl/stream_dma/#$RTLDIR/#" rtl/filelist_mm.f > $FL.b
verilator --cc --exe --build -j 4 -O1 --x-initial unique --x-assign unique -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-DECLFILENAME \
  --assert -DSF_ASSERT --Mdir $OUT -I$RTLDIR rtl/lint.vlt -f $FL.a -f $FL.b tests/stream_dma/mm/tb_mm_top.sv --top-module tb_mm_top $G \
  -CFLAGS "-O1 -std=c++17 $D" $PWD/tests/stream_dma/mm/tb_mm_main.cpp -o tb_$CFG >$OUT/build.log 2>&1 || { tail -50 $OUT/build.log; rm -f $FL $FL.a $FL.b; exit 1; }
rm -f $FL $FL.a $FL.b
echo "built $OUT/tb_$CFG"
