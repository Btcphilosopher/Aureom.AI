#!/usr/bin/env python3
"""Mutation test: inject one RTL bug at a time, rebuild the Verilator bench in a scratch copy of the project, and require the
suite to FAIL (nonzero exit, timeout, or build-visible divergence).  A surviving mutant means a hole in the bench.
usage: mutate.py [--only NAME] [--jobs N] [--report reports/mutation.md]"""
import argparse, os, re, shutil, subprocess, sys, tempfile, time, concurrent.futures as cf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = "rtl/stream_dma/"
# (name, file, old, new, config, why it matters)
M = [
 ("cpl-partial-registered", R+"sf_stream_dma_cpl.sv", "assign cpl_partial = (cpl_bytes_done != '0) && (cpl_status != `SFSD_ST_OK);", "always_ff @(posedge clk) cpl_partial <= (cpl_bytes_done != '0) && (cpl_status != `SFSD_ST_OK);", "initial", "partial flag one cycle behind the record (stale in the first cycle)"),
 ("align-strobe-no-lane-shift", R+"sf_stream_dma_align.sv", "assign out_strb = nmask << pop_lo;", "assign out_strb = nmask;", "initial", "write strobes ignore the destination lane offset"),
 ("align-data-no-lane-shift", R+"sf_stream_dma_align.sv", "assign out_data = lowbytes << (8 * 32'(pop_lo));", "assign out_data = lowbytes;", "initial", "write data ignores the destination lane offset"),
 ("align-insert-before-pop", R+"sf_stream_dma_align.sv", "<< (8 * 32'(cnt_p));", "<< (8 * 32'(cnt));", "initial", "bytes inserted at the pre-pop fill level (lost/duplicated bytes)"),
 ("align-room-check", R+"sf_stream_dma_align.sv", "assign in_ready = (cnt_p <= CW'(W));", "assign in_ready = (cnt_p <= CW'(2*W));", "initial", "accumulator overflow"),
 ("read-first-beat-shift", R+"sf_stream_dma_read.sv", "wire [LW-1:0] b_lo    = (k_cnt == 9'd0) ? k_off : '0;", "wire [LW-1:0] b_lo    = '0;", "initial", "source byte offset of the first beat ignored"),
 ("read-mask-off-by-one", R+"sf_stream_dma_read.sv", "(i < 32'(b_nb)) ? 8'hFF : 8'h00", "(i <= 32'(b_nb)) ? 8'hFF : 8'h00", "initial", "garbage lane leaks into the byte stream"),
 ("read-last-beat-count", R+"sf_stream_dma_read.sv", "wire [LW-1:0] b_hi    = k_lastexp ? k_endl : LW'(W - 1);", "wire [LW-1:0] b_hi    = LW'(W - 1);", "initial", "partial final beat treated as full"),
 ("read-fill-index", R+"sf_stream_dma_read.sv", "assign fill_idx    = k_base + k_cnt[IW-1:0];", "assign fill_idx    = k_base;", "initial", "all beats of a burst land in one ring entry"),
 ("read-rlast-fault-missing", R+"sf_stream_dma_read.sv", "assign f_proto = rq_v && (!k_known || (rq_last != k_lastexp));", "assign f_proto = rq_v && !k_known;", "initial", "bad RLAST not reported as a protocol error"),
 ("read-bus-error-ignored", R+"sf_stream_dma_read.sv", "assign f_bus   = k_known && (rq_resp != 2'b00);", "assign f_bus   = 1'b0;", "initial", "read error response swallowed"),
 ("read-address-bypasses-guard", R+"sf_stream_dma_read.sv", "ar_addr <= q_pa;", "ar_addr <= q_iova;", "initial", "AR address formed from the descriptor, not the guard's grant"),
 ("write-address-bypasses-guard", R+"sf_stream_dma_write.sv", "aw_addr <= wq_pa;", "aw_addr <= wq_iova;", "initial", "AW address formed from the descriptor, not the guard's grant"),
 ("write-bytes-ack-off-by-one", R+"sf_stream_dma_write.sv", "acked_bytes <= acked_bytes + TOT_W'(b_bytes);", "acked_bytes <= acked_bytes + TOT_W'(b_bytes) - 1;", "initial", "completion accounting"),
 ("write-bus-error-ignored", R+"sf_stream_dma_write.sv", "assign f_bus   = b_known && (bq_resp != 2'b00);", "assign f_bus   = 1'b0;", "initial", "write error response swallowed (and counted as acknowledged)"),
 ("write-b-ok-counts-error", R+"sf_stream_dma_write.sv", "wire b_ok = b_known && (bq_resp == 2'b00);", "wire b_ok = b_known;", "initial", "errored write counted as acknowledged"),
 ("write-spurious-b-ignored", R+"sf_stream_dma_write.sv", "assign f_proto = bq_v && !b_known;", "assign f_proto = 1'b0;", "initial", "unmatched B response ignored"),
 ("write-slot-never-freed", R+"sf_stream_dma_write.sv", "if (b_known) for (int i = 0; i < NSLOT; i++) if (32'(bq_id) == i) s_v[i] <= 1'b0;", "", "initial", "B response does not free its slot"),
 ("write-last-burst-never-ends", R+"sf_stream_dma_write.sv", "wire txn_last_item   = plan_last_burst && cur_last;", "wire txn_last_item   = 1'b0;", "initial", "transaction end never signalled"),
 ("write-beat-last-wrong", R+"sf_stream_dma_write.sv", "wire               a_lastb = (a_j == (a_nb - 9'd1));", "wire               a_lastb = (a_j == a_nb);", "initial", "WLAST / burst length"),
 ("plan-crosses-4k", R+"sf_stream_dma_plan.sv", "lim_pg   = 14'd4096 - 14'(addr_lo);", "lim_pg   = 14'd4097 - 14'(addr_lo);", "initial", "burst crosses a 4 KiB page"),
 ("plan-extra-beat", R+"sf_stream_dma_plan.sv", "nbeats   = 9'((sum + 14'(W - 1)) >> LW);", "nbeats   = 9'((sum + 14'(W)) >> LW);", "initial", "burst one beat too long"),
 ("plan-ignores-burst-limit", R+"sf_stream_dma_plan.sv", "lim_beat = BEAT_MAX - 14'(off);", "lim_beat = 14'd4096;", "initial", "BURST_LENGTH ignored"),
 ("buffer-no-reservation-check", R+"sf_stream_dma_buffer.sv", "assign rsv_ok   = ((16'(rsv) + 16'(rsv_n)) <= 16'(DEPTH));", "assign rsv_ok   = 1'b1;", "initial", "ring overrun"),
 ("buffer-valid-not-cleared", R+"sf_stream_dma_buffer.sv", "if (pop)        vld[rp] <= 1'b0;", "", "initial", "stale valid bit re-delivers data"),
 ("desc-domain-unchecked", R+"sf_stream_dma_dcheck.sv", "wire dom_bad   = (dom_cl != 16'(trusted_domain));", "wire dom_bad   = 1'b0;", "initial", "descriptor may claim any domain"),
 ("desc-overlap-unchecked", R+"sf_stream_dma_dcheck.sv", "wire         ovl_bad  = (s_type == d_type) && ({64'd0, src} < d_end) && ({64'd0, dst} < s_end);", "wire         ovl_bad  = 1'b0;", "initial", "overlapping copy accepted"),
 ("desc-overflow-boundary", R+"sf_stream_dma_dcheck.sv", "wire         ovf_bad  = (s_end > lim_a) || (d_end > lim_a);", "wire         ovf_bad  = (s_end >= lim_a) || (d_end >= lim_a);", "initial", "off-by-one at the top of the address space"),
 ("desc-range-unchecked", R+"sf_stream_dma_dcheck.sv", "wire         rng_bad  = ({64'd0, src} >= lim_a) || ({64'd0, dst} >= lim_a);", "wire         rng_bad  = 1'b0;", "initial", "address >= 2^AW accepted"),
 ("desc-version-unchecked", R+"sf_stream_dma_dcheck.sv", "if      (version != `SFSD_DESC_VERSION) err = `SFSD_ERR_VERSION;", "if      (1'b0) err = `SFSD_ERR_VERSION;", "initial", "wrong descriptor version accepted"),
 ("desc-reserved-unchecked", R+"sf_stream_dma_dcheck.sv", "wire rsvd_bad  = (|rsvd0);", "wire rsvd_bad  = 1'b0;", "initial", "reserved bits accepted"),
 ("desc-chain-txn-unchecked", R+"sf_stream_dma_dcheck.sv", "wire txn_bad   = in_txn && (txn_id != cur_txn_id);", "wire txn_bad   = 1'b0;", "initial", "TXN_ID may change mid-transaction"),
 ("desc-skip-never-ends", R+"sf_stream_dma_descriptor.sv", "if (h_last) skip <= 1'b0;", "", "initial", "skip mode never resynchronises on LAST"),
 ("desc-total-wrong", R+"sf_stream_dma_descriptor.sv", "seg_total  <= ctx_total + h_len;", "seg_total  <= ctx_total;", "initial", "bytes_total accounting"),
 ("cpl-completes-before-writes-ack", R+"sf_stream_dma_cpl.sv", "wire ok_ready = (st == ST_RUN) && end_seen && wr_quiet && rd_quiet;", "wire ok_ready = (st == ST_RUN) && end_seen;", "initial", "completion signalled before the destination acknowledged the writes"),
 ("cpl-drain-ignores-outstanding", R+"sf_stream_dma_cpl.sv", "end else if (rd_quiet && wr_drained) begin\n            st <= ST_CPL; flush <= 1'b1; rec_en <= 1'b1;", "end else begin\n            st <= ST_CPL; flush <= 1'b1; rec_en <= 1'b1;", "initial", "error path flushes while requests are still on the bus"),
 ("cpl-watchdog-dead", R+"sf_stream_dma_cpl.sv", "wire wd_hit  = watch && (cfg_timeout != 32'd0) && (wd >= cfg_timeout);", "wire wd_hit  = 1'b0;", "initial", "timeout never fires"),
 ("cpl-kill-not-held-in-flush", R+"sf_stream_dma_cpl.sv", "assign kill       = (st == ST_DRAIN) || fenced_q || flush;", "assign kill       = (st == ST_DRAIN) || fenced_q;", "initial", "work can start in the flush cycle (perf counters over-count)"),
 ("read-hazard-disabled", R+"sf_stream_dma_read.sv", "wire hz_go    = !hz_conflict || quiesced;", "wire hz_go    = 1'b1;", "par4", "RAW/WAW interlock removed"),
 ("read-hazard-quiesce-early", R+"sf_stream_dma_read.sv", "wire quiesced = (wr_acked_bytes == hz_start);", "wire quiesced = (wr_acked_bytes + TOT_W'(16) >= hz_start);", "par4", "interlock releases before earlier writes are acknowledged"),
 ("read-id-not-matched", R+"sf_stream_dma_read.sv", "for (int i = 0; i < NSLOT; i++) if (32'(rq_id) == i) begin\n      k_known = s_v[i];", "for (int i = 0; i < NSLOT; i++) if (i == 0) begin\n      k_known = s_v[i];", "par4", "R responses matched to slot 0 regardless of RID (assumes in-order)"),
 ("top-soft-reset-not-deferred", R+"sf_stream_dma.sv", "if (soft_pend && g_infl == 8'd0 && !guard_req_valid) begin", "if (soft_pend) begin", "initial", "soft reset while a guard response is in flight"),
]

def build_and_run(m, tmp_root):
    name, f, old, new, cfg, why = m
    d = os.path.join(tmp_root, name)
    shutil.copytree(ROOT, d, ignore=shutil.ignore_patterns("build", "reports", "*.zip", ".git", "benchmarks"))
    p = os.path.join(d, f)
    src = open(p).read()
    if old not in src:
        return name, "BAD-MUTANT", "pattern not found", why
    open(p, "w").write(src.replace(old, new, 1))
    r = subprocess.run(["bash", "scripts/build_tb.sh", cfg], cwd=d, capture_output=True, text=True)
    if r.returncode != 0:
        return name, "BUILD-FAIL", r.stdout[-300:] + r.stderr[-300:], why
    try:
        t = subprocess.run([f"build/tb_{cfg}/tb_{cfg}", "1", "all", "60"], cwd=d, capture_output=True, text=True, timeout=300, env=dict(os.environ, TB_FAILFAST="1"))
        out = t.stdout
        res = "KILLED" if (t.returncode != 0 or "RESULT: PASS" not in out) else "SURVIVED"
        first = next((l.strip() for l in out.splitlines() if "FAIL" in l), "")
    except subprocess.TimeoutExpired:
        res, first = "KILLED", "hang (timeout)"
    shutil.rmtree(d, ignore_errors=True)
    return name, res, first[:110], why

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--only"); ap.add_argument("--jobs", type=int, default=3); ap.add_argument("--report", default="reports/mutation.md")
    a = ap.parse_args()
    ms = [m for m in M if (not a.only or a.only in m[0])]
    tmp = tempfile.mkdtemp(prefix="sfsd_mut_")
    t0 = time.time(); results = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for r in ex.map(lambda m: build_and_run(m, tmp), ms):
            results.append(r); print(f"{r[1]:10s} {r[0]:36s} {r[2]}", flush=True)
    shutil.rmtree(tmp, ignore_errors=True)
    killed = sum(1 for r in results if r[1] == "KILLED"); surv = [r for r in results if r[1] == "SURVIVED"]; bad = [r for r in results if r[1] in ("BAD-MUTANT", "BUILD-FAIL")]
    os.makedirs(os.path.join(ROOT, os.path.dirname(a.report)), exist_ok=True)
    with open(os.path.join(ROOT, a.report), "w") as f:
        f.write(f"# Mutation testing\n\n{len(results)} injected RTL bugs; **{killed} killed**, {len(surv)} survived, {len(bad)} invalid/unbuildable.\n"
                f"Each mutant is built into a scratch copy and run against `tb_<config> 1 all 60`; KILLED = the suite reported a failure (or hung).\n\n"
                "| mutant | result | first symptom | what it models |\n|---|---|---|---|\n")
        for r in results: f.write(f"| {r[0]} | {r[1]} | {r[2].replace('|','/')} | {r[3]} |\n")
        f.write(f"\nElapsed {time.time()-t0:.0f} s.\n")
    print(f"\n{killed}/{len(results)} killed, {len(surv)} survived, {len(bad)} bad")
    sys.exit(1 if surv or bad else 0)
