#!/usr/bin/env python3
"""StreamDMA <-> MemoryMatrix integration regression: build every configuration of tests/stream_dma/mm/mm_configs.sh, run N seeds each
(directed tests + constrained-random regression), write reports/integration_mm.md.
usage: run_mm.py [--seeds 1,2,3,4,5] [--rand 200] [--configs a,b] [--jobs 2]"""
import argparse, collections, concurrent.futures as cf, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def sh(cmd, **kw): return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, **kw)
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", default="1,2,3,4,5"); ap.add_argument("--rand", type=int, default=200); ap.add_argument("--configs"); ap.add_argument("--jobs", type=int, default=2)
    a = ap.parse_args()
    allc = sh(["bash", "-c", "source tests/stream_dma/mm/mm_configs.sh; echo $MM_CONFIGS"]).stdout.split()
    cfgs = a.configs.split(",") if a.configs else allc; seeds = a.seeds.split(","); t0 = time.time()
    def build(c):
        r = sh(["bash", "scripts/build_mm_tb.sh", c]); return c, r.returncode, (r.stdout + r.stderr)[-300:]
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for c, rc, msg in ex.map(build, cfgs):
            if rc: print("BUILD FAILED", c, msg); sys.exit(2)
    def run(args):
        c, s = args
        r = sh([f"build/tb_{c}/tb_{c}", s, "all", str(a.rand)], timeout=3000); out = r.stdout
        m = re.search(r"TOTAL runs=(\d+) failed_runs=(\d+) errors=(\d+) cycles=(\d+)", out)
        per = {mm.group(1): (int(mm.group(2)), int(mm.group(3))) for mm in re.finditer(r"^([a-z_]+)\s+(\d+)\s+(\d+)\s*$", out, re.M) if mm.group(1) != "test"}
        return c, s, ("RESULT: PASS" in out and r.returncode == 0), (tuple(map(int, m.groups())) if m else (0, 0, 0, 0)), per, [l.strip() for l in out.splitlines() if "FAIL" in l][:3]
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for r in ex.map(run, [(c, s) for c in cfgs for s in seeds]):
            res.append(r); print(("PASS" if r[2] else "FAIL"), r[0], "seed", r[1], "runs=%d failed=%d errors=%d cycles=%d" % r[3], r[5] if not r[2] else "", flush=True)
    allok = all(r[2] for r in res); tot_runs = sum(r[3][0] for r in res); tot_cyc = sum(r[3][3] for r in res)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "integration_mm.md"), "w") as f:
        f.write(f"# StreamDMA <-> MemoryMatrix (P101) integration regression\n\n{len(cfgs)} configurations x {len(seeds)} seeds = {len(res)} bench runs, **{'ALL PASS' if allok else 'FAILURES'}**; "
                f"{tot_runs} descriptor streams / directed cases, {tot_cyc/1e6:.1f} M simulated cycles, random-regression length {a.rand}. Verilator 5.020, `--x-initial unique`, MemoryMatrix internal assertions on (`-DSF_ASSERT`). "
                f"Elapsed {time.time()-t0:.0f} s.\n\nThe memory is the vendored MemoryMatrix RTL; it is loaded and dumped through its own request port. Details: docs/10_MEMORYMATRIX_INTEGRATION.md.\n\n"
                "| config | seed | result | runs | failed | errors | cycles |\n|---|---|---|---|---|---|---|\n")
        for r in res: f.write(f"| {r[0]} | {r[1]} | {'PASS' if r[2] else 'FAIL'} | {r[3][0]} | {r[3][1]} | {r[3][2]} | {r[3][3]} |\n")
        cov = collections.defaultdict(lambda: [0, 0])
        for r in res:
            for k, (n, fl) in r[4].items(): cov[k][0] += n; cov[k][1] += fl
        f.write("\n## Test classes (summed over all configurations and seeds)\n\n| test class | runs | failed |\n|---|---|---|\n")
        for k in sorted(cov): f.write(f"| {k} | {cov[k][0]} | {cov[k][1]} |\n")
    sys.exit(0 if allok else 1)
