#!/bin/bash
# run_bridge_unit.sh [rtl dir]: build and run the adversarial-master unit test of the MemoryMatrix bridge (Verilator --binary --timing).
set -e
cd "$(dirname "$0")/.."
RTLDIR=${1:-rtl/stream_dma}; OUT=${UNIT_BUILD_DIR:-build/unit_bridge}
mkdir -p $OUT
FL=$(mktemp); sed "s#rtl/stream_dma/#$RTLDIR/#" rtl/filelist_mm.f | grep -v '^//' > $FL.b
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-DECLFILENAME --assert -DSF_ASSERT -O1 --x-initial unique \
  --Mdir $OUT -I$RTLDIR -f $FL.b third_party/p61-clouddpu/rtl/sfd_fifo.sv tests/stream_dma/mm/tb_bridge_unit.sv --top-module tb_bridge_unit -o unit.bin \
  -CFLAGS -O1 -CFLAGS -std=c++20 >$OUT/build.log 2>&1 || { tail -30 $OUT/build.log; rm -f $FL $FL.b; exit 1; }
rm -f $FL $FL.b
$OUT/unit.bin +verilator+rand+reset+2 | tee $OUT/run.log
grep -q 'RESULT: PASS' $OUT/run.log
