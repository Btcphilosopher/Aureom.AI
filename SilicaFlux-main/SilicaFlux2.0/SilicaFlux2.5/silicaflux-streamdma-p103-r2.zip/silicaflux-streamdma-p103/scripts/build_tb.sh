#!/bin/bash
# build_tb.sh <cfg> : build the Verilator bench for one configuration (see tests/stream_dma/configs.sh)
set -e
cd "$(dirname "$0")/.."
CFG=${1:-initial}
source tests/stream_dma/configs.sh
declare -n C=CFG_$CFG
OUT=build/tb_$CFG
mkdir -p $OUT
G=""; D=""
for kv in "${C[@]}"; do
  k=${kv%%=*}; v=${kv#*=}
  case $k in
    DATA_WIDTH) G="$G -GDATA_WIDTH=$v"; D="$D -DTB_DW=$v";;
    BURST_LENGTH) G="$G -GBURST_LENGTH=$v"; D="$D -DTB_BL=$v";;
    FIFO_DEPTH) G="$G -GFIFO_DEPTH=$v"; D="$D -DTB_FIFO=$v";;
    MAX_OUTSTANDING_READS) G="$G -GMAX_OUTSTANDING_READS=$v"; D="$D -DTB_NR=$v";;
    MAX_OUTSTANDING_WRITES) G="$G -GMAX_OUTSTANDING_WRITES=$v"; D="$D -DTB_NW=$v";;
    MAX_SEG_LOG2) G="$G -GMAX_SEG_LOG2=$v"; D="$D -DTB_MAXSEG=$v";;
    MAX_TXN_LOG2) G="$G -GMAX_TXN_LOG2=$v"; D="$D -DTB_MAXTXN=$v";;
    *) G="$G -G$k=$v";;
  esac
done
verilator --cc --exe --build -j 4 -O1 --x-initial unique --x-assign unique -Wno-fatal -Wno-lint -Wno-style \
  --Mdir $OUT -Irtl/stream_dma rtl/lint.vlt -f rtl/filelist.f tests/stream_dma/tb_top.sv --top-module tb_top $G \
  -CFLAGS "-O1 -std=c++17 -I$PWD/tests/stream_dma $D" $PWD/tests/stream_dma/tb_main.cpp -o tb_$CFG >$OUT/build.log 2>&1 || { tail -40 $OUT/build.log; exit 1; }
echo "built $OUT/tb_$CFG"
