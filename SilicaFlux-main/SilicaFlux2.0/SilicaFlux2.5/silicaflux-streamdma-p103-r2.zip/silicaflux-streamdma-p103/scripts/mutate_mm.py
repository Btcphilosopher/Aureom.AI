#!/usr/bin/env python3
"""Mutation test of the StreamDMA <-> MemoryMatrix bridge: each mutant injects ONE bug into sf_stream_dma_mm_bridge.sv, rebuilds the
integration bench and runs it fail-fast; the bench MUST fail.  Mutants it does not kill are offered to the adversarial-master unit test
(tests/stream_dma/mm/tb_bridge_unit.sv).  A survivor of BOTH is a hole (or an equivalent mutant, to be argued).  The unmutated design must pass both first.
usage: mutate_mm.py [--cfg mm_par4] [--seeds 1,2] [--rand 80] [--jobs 2] [--only name,...]     writes reports/mutation_mm.md"""
import argparse, concurrent.futures as cf, os, re, shutil, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BR = "sf_stream_dma_mm_bridge.sv"

# (name, bug class, [(old, new), ...])   every `old` must occur exactly once in the bridge
M = [
 ("rd-last-dropped",      "RLAST never produced (last flag lost in the request id)",           [("MM_IDW'({rd_lastb, rd_id})", "MM_IDW'({1'b0, rd_id})")]),
 ("rd-last-always",       "RLAST on every beat",                                               [("MM_IDW'({rd_lastb, rd_id})", "MM_IDW'({1'b1, rd_id})")]),
 ("rd-last-off-by-one",   "burst one beat too long (last-beat detection)",                      [("wire                 rd_lastb = (rd_cnt == 8'd0);", "wire                 rd_lastb = (rd_cnt == 8'd1);")]),
 ("rd-addr-step",         "read address advances by half a beat",                              [("rd_addr <= rd_addr + MM_AW'(W);", "rd_addr <= rd_addr + MM_AW'(W/2);")]),
 ("wr-addr-step",         "write address advances by half a beat",                             [("wb_addr <= wb_addr + MM_AW'(W);", "wb_addr <= wb_addr + MM_AW'(W/2);")]),
 ("wr-strobes-ignored",   "byte strobes dropped: every lane written",                          [("assign wr_req_be     = w_strb;", "assign wr_req_be     = {W{1'b1}};")]),
 ("wr-data-lane-swap",    "write data byte lanes 0/1 swapped",                                 [("assign wr_req_wdata  = w_data;", "assign wr_req_wdata  = {w_data[DATA_WIDTH-1:16], w_data[7:0], w_data[15:8]};")]),
 ("w-ready-ignores-matrix","W accepted although the matrix did not accept the beat",           [("assign w_ready       = wb_act && wr_req_ready;", "assign w_ready       = wb_act;")]),
 ("ar-ready-always",      "AR accepted while a burst is being expanded (burst overwritten)",   [("assign ar_ready     = !rd_act || (rd_acc && rd_lastb);", "assign ar_ready     = 1'b1;")]),
 ("awq-pop-early",        "next AW loaded while the current burst still has beats to send",    [("assign awq_pop       = awq_v && (!wb_act || (wb_acc && wb_lastb));", "assign awq_pop       = awq_v;")]),
 ("b-before-ack",         "B emitted when the last beat is ACCEPTED by the matrix, not when it is performed",
                          [("if (b_v_q && b_ready) b_v_q <= 1'b0;", "if (b_v_q && b_ready) b_v_q <= 1'b0;\n      if (wb_acc && wb_lastb) begin b_v_q <= 1'b1; b_id_q <= wb_id; b_resp_q <= 2'b00; end"),
                           ("b_v_q <= 1'b1; b_id_q <= wr_rsp_id[WIDW-1:0]; b_resp_q <= worst; b_acc <= 2'b00;", "b_acc <= 2'b00;")]),
 ("b-resp-last-only",     "B response taken from the last beat only (earlier errors forgotten)", [("b_resp_q <= worst;", "b_resp_q <= rsp_r;")]),
 ("rd-resp-ignored",      "read errors reported as OKAY",                                      [("assign r_resp       = st2resp(rd_rsp_status);", "assign r_resp       = 2'b00;")]),
 ("wr-resp-ignored",      "write errors reported as OKAY",                                     [("wire  [1:0]        rsp_r  = st2resp(wr_rsp_status);", "wire  [1:0]        rsp_r  = 2'b00;")]),
 ("type-check-off",       "memory type not checked (fail-closed path removed)",                [("|| !TYPE_MASK[mt];", "|| 1'b0;")]),
 ("aperture-bits-off",    "address bits above MM_AW ignored (aliasing into the matrix)",       [("hi_nz = (a[ADDR_WIDTH-1:MM_AW] != '0);", "hi_nz = 1'b0;")]),
 ("wrap-check-off",       "burst running past the top of the aperture not detected (wraps to 0)", [("ovf   = endp[MM_AW + 1] || (endp[MM_AW] && (endp[MM_AW-1:0] != '0));", "ovf   = 1'b0;")]),
 ("rd-bad-not-forced",    "refused read burst still issued at its own address",                [("assign rd_req_addr  = rd_bad ? OOR_ADDR : rd_addr;", "assign rd_req_addr  = rd_addr;")]),
 ("wr-bad-not-forced",    "refused write burst still issued at its own address",               [("assign wr_req_addr   = wb_bad ? OOR_ADDR : wb_addr;", "assign wr_req_addr   = wb_addr;")]),
 ("secure-rd-never",      "domain never reaches the matrix on reads (secure bit stuck 0)",     [("rd_sec  <= SECURE_MASK[DOM_X'(ar_domain)];", "rd_sec  <= 1'b0;")]),
 ("secure-wr-never",      "domain never reaches the matrix on writes (secure bit stuck 0)",    [("SECURE_MASK[DOM_X'(aw_domain)]})", "1'b0})")]),
 ("secure-rd-always",     "every read claims to be secure (secure bit stuck 1)",               [("rd_sec  <= SECURE_MASK[DOM_X'(ar_domain)];", "rd_sec  <= 1'b1;")]),
 ("secure-wr-always",     "every write claims to be secure (secure bit stuck 1)",              [("SECURE_MASK[DOM_X'(aw_domain)]})", "1'b1})")]),
 ("size-check-off",       "beat size other than the full width not refused (only a non-DMA master can send it)", [("|| (sz != 3'(LW))", "|| 1'b0")]),
 ("burst-type-off",       "burst type other than INCR not refused (only a non-DMA master can send it)",          [("|| (bt != 2'b01)", "|| 1'b0")]),
 ("proto-check-off",      "WLAST disagreeing with the AW length not flagged",                  [("if (w_last != wb_lastb) proto_err <= 1'b1;", "")]),
 ("rid-wrong-bit",        "RID taken from the wrong id bits",                                  [("assign r_id         = rd_rsp_id[RIDW-1:0];", "assign r_id         = rd_rsp_id[RIDW:1];")]),
 ("bid-lost",             "BID not carried through the matrix (always 0)",                     [("b_id_q <= wr_rsp_id[WIDW-1:0];", "b_id_q <= '0;")]),
]

def sh(cmd, **kw): return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, **kw)

def one(args):
    name, cls, patches, cfg, seeds, rand = args
    base = os.path.join(ROOT, "build", "mut_mm", name)
    shutil.rmtree(base, ignore_errors=True); os.makedirs(base)
    rtl = os.path.join(base, "rtl"); shutil.copytree(os.path.join(ROOT, "rtl", "stream_dma"), rtl)
    src = open(os.path.join(rtl, BR)).read()
    for old, new in patches:
        if src.count(old) != 1: return name, cls, "PATCH-ERROR", f"pattern occurs {src.count(old)}x: {old[:60]}"
        src = src.replace(old, new)
    open(os.path.join(rtl, BR), "w").write(src)
    env = dict(os.environ, MM_BUILD_DIR=os.path.relpath(base, ROOT))
    r = sh(["bash", "scripts/build_mm_tb.sh", cfg, os.path.relpath(rtl, ROOT)], env=env)
    if r.returncode: return name, cls, "BUILD-ERROR", (r.stdout + r.stderr)[-300:]
    exe = os.path.join(base, f"tb_{cfg}", f"tb_{cfg}")
    for sd in seeds:
        try:
            t = subprocess.run([exe, str(sd), "all", str(rand)], cwd=ROOT, capture_output=True, text=True, timeout=300, env=dict(os.environ, TB_FAILFAST="1"))
        except subprocess.TimeoutExpired:
            return name, cls, "KILLED", f"seed {sd}: hang / timeout"
        out = t.stdout
        if t.returncode != 0 or "RESULT: PASS" not in out:
            m = re.search(r"\[FAIL[^\]]*\] (.*)", out)
            shutil.rmtree(base, ignore_errors=True)
            return name, cls, "KILLED", f"seed {sd}: " + (m.group(1)[:110] if m else "nonzero exit")
    # not killed by the StreamDMA system bench: the adversarial-master unit test gets its turn
    env2 = dict(os.environ, UNIT_BUILD_DIR=os.path.relpath(os.path.join(base, "unit"), ROOT))
    u = sh(["bash", "scripts/run_bridge_unit.sh", os.path.relpath(rtl, ROOT)], env=env2)
    shutil.rmtree(base, ignore_errors=True)
    if u.returncode != 0:
        m = re.search(r"\[FAIL[^\]]*\] (.*)", u.stdout)
        return name, cls, "KILLED", "unit test: " + (m.group(1)[:110] if m else "build/run failure: " + (u.stdout + u.stderr)[-120:])
    return name, cls, "SURVIVED", ""

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--cfg", default="mm_par4"); ap.add_argument("--seeds", default="1,2"); ap.add_argument("--rand", type=int, default=80)
    ap.add_argument("--jobs", type=int, default=2); ap.add_argument("--only")
    a = ap.parse_args()
    sel = [m for m in M if not a.only or m[0] in a.only.split(",")]
    seeds = [int(x) for x in a.seeds.split(",")]
    # sanity: the unmutated design must PASS the very runs the mutants are judged by (a failing baseline would 'kill' every mutant)
    base = os.path.join(ROOT, "build", "mut_mm_base"); shutil.rmtree(base, ignore_errors=True)
    r = sh(["bash", "scripts/build_mm_tb.sh", a.cfg], env=dict(os.environ, MM_BUILD_DIR=os.path.relpath(base, ROOT)))
    if r.returncode: print("baseline build failed"); sys.exit(2)
    for sd in seeds:
        t = subprocess.run([os.path.join(base, f"tb_{a.cfg}", f"tb_{a.cfg}"), str(sd), "all", str(a.rand)], cwd=ROOT, capture_output=True, text=True, timeout=600)
        if "RESULT: PASS" not in t.stdout or t.returncode: print(f"BASELINE (unmutated) FAILS on seed {sd}: mutation results would be meaningless\n" + t.stdout[-600:]); sys.exit(2)
    u = sh(["bash", "scripts/run_bridge_unit.sh"], env=dict(os.environ, UNIT_BUILD_DIR=os.path.relpath(os.path.join(base, "unit"), ROOT)))
    if u.returncode: print("BASELINE (unmutated) FAILS the bridge unit test\n" + u.stdout[-600:]); sys.exit(2)
    print(f"baseline (unmutated, {a.cfg}, seeds {seeds}, plus the bridge unit test): PASS", flush=True); shutil.rmtree(base, ignore_errors=True)
    t0 = time.time(); res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for r in ex.map(one, [(n, c, p, a.cfg, seeds, a.rand) for n, c, p in sel]):
            res.append(r); print(f"{r[2]:12s} {r[0]:24s} {r[3]}", flush=True)
    killed = sum(1 for r in res if r[2] == "KILLED"); bad = [r for r in res if r[2] != "KILLED"]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "mutation_mm.md"), "w") as f:
        by_unit = sum(1 for r in res if r[2] == "KILLED" and r[3].startswith("unit test"))
        f.write(f"# Mutation test: StreamDMA <-> MemoryMatrix bridge\n\n**{killed} / {len(res)} injected bugs detected** ({killed-by_unit} by the StreamDMA system bench, {by_unit} only by the adversarial-master unit test; config `{a.cfg}`, seeds {a.seeds}, random-regression length {a.rand}, fail-fast, {time.time()-t0:.0f} s). "
                "The unmutated design passes both benches first (a failing baseline would 'kill' everything).\n\n"
                "Each mutant changes ONE expression in `sf_stream_dma_mm_bridge.sv`; the integration bench must fail. The first column is what happened.\n\n| result | mutant | injected bug | first failure |\n|---|---|---|---|\n")
        for r in res: f.write(f"| {r[2]} | `{r[0]}` | {r[1]} | {r[3]} |\n")
        if bad: f.write("\n**Not killed:** " + ", ".join(r[0] for r in bad) + "\n")
    print(f"{killed}/{len(res)} killed"); sys.exit(0 if not bad else 1)
