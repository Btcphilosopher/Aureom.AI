#!/usr/bin/env python3
"""Verify that every vendored file in third_party/ is byte-identical to the SHA-256 recorded in third_party/MANIFEST.tsv, and (optionally) to the
member of the repository archive it was copied from -- the manifest alone proves nothing about provenance.
  check_vendor.py                     manifest hashes only
  check_vendor.py --repo <root>       also compare every file with its member in the archive named in the manifest (archives looked up under <root>)
  check_vendor.py --archive <zip> ... also compare with the given archive(s) (any number); a row whose member is in none of them is reported as not checked"""
import hashlib, os, sys, zipfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rows = []
for line in open(os.path.join(root, "third_party", "MANIFEST.tsv")):
    if line.startswith("#") or not line.strip(): continue
    path, member, src, sha = line.rstrip("\n").split("\t")
    rows.append((path, member, src.split(" (")[0], sha))
bad = 0
for path, member, src, sha in rows:
    h = hashlib.sha256(open(os.path.join(root, "third_party", path), "rb").read()).hexdigest(); ok = (h == sha); bad += (not ok)
    if not ok or "-v" in sys.argv: print(("OK  " if ok else "BAD ") + path)
print(f"manifest: {len(rows)} files, {'all match' if not bad else str(bad) + ' MISMATCH'}")
zips = {}
def zopen(p):
    if p not in zips: zips[p] = zipfile.ZipFile(p)
    return zips[p]
if "--archive" in sys.argv:
    for i, a in enumerate(sys.argv):
        if a == "--archive": zopen(sys.argv[i + 1])
repo = sys.argv[sys.argv.index("--repo") + 1] if "--repo" in sys.argv else None
checked = unchecked = 0; arch_bad = 0
for path, member, src, sha in rows:
    z = None
    if repo and os.path.exists(os.path.join(repo, src)): z = zopen(os.path.join(repo, src))
    cands = [z] if z else list(zips.values())
    hit = False
    for zz in cands:
        if member in zz.namelist():
            h = hashlib.sha256(zz.read(member)).hexdigest(); hit = True; checked += 1
            if h != sha: arch_bad += 1; print("BAD archive:" + member)
            break
    if not hit: unchecked += 1
if repo or zips:
    print(f"archive provenance: {checked} files compared with their archive member, {arch_bad} mismatch, {unchecked} not checked (archive not available)")
sys.exit(1 if (bad or arch_bad) else 0)
