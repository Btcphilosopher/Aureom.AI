#!/usr/bin/env python3
"""Full regression: build the bench for every configuration, run N seeds each (random register init via +verilator+rand+reset+2),
and write reports/regression.md.  usage: regress.py [--seeds 1,2,3,4,5] [--rand 300] [--configs a,b]"""
import argparse, collections, concurrent.futures as cf, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def sh(cmd, **kw): return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, **kw)
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", default="1,2,3,4,5"); ap.add_argument("--rand", type=int, default=300); ap.add_argument("--configs"); ap.add_argument("--jobs", type=int, default=2)
    a = ap.parse_args()
    allc = sh(["bash", "-c", "source tests/stream_dma/configs.sh; echo $ALL_CONFIGS"]).stdout.split()
    cfgs = a.configs.split(",") if a.configs else allc
    seeds = a.seeds.split(",")
    t0 = time.time()
    def build(c):
        r = sh(["bash", "scripts/build_tb.sh", c]); return c, r.returncode, r.stdout[-200:] + r.stderr[-200:]
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for c, rc, msg in ex.map(build, cfgs):
            if rc: print("BUILD FAILED", c, msg); sys.exit(2)
    def run(args):
        c, s = args
        r = sh([f"build/tb_{c}/tb_{c}", s, "all", str(a.rand), "+verilator+rand+reset+2", f"+verilator+seed+{s}"], timeout=3000)
        out = r.stdout
        m = re.search(r"TOTAL runs=(\d+) failed_runs=(\d+) bus_errors=(\d+) cycles=(\d+)", out)
        per = {mm.group(1): (int(mm.group(2)), int(mm.group(3))) for mm in re.finditer(r"^(\S+)\s+(\d+)\s+(\d+)$", out, re.M) if mm.group(1) not in ("TOTAL",)}
        per = {k: v for k, v in per.items() if k != "test"}
        per2 = {}
        for mm in re.finditer(r"^([a-z_]+)\s+(\d+)\s+(\d+)\s*$", out, re.M): per2[mm.group(1)] = (int(mm.group(2)), int(mm.group(3)))
        ok = ("RESULT: PASS" in out) and r.returncode == 0
        return c, s, ok, (tuple(map(int, m.groups())) if m else (0, 0, 0, 0)), per2, [l for l in out.splitlines() if "FAIL" in l][:3]
    jobs = [(c, s) for c in cfgs for s in seeds]
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for r in ex.map(run, jobs):
            res.append(r); print(("PASS" if r[2] else "FAIL"), r[0], "seed", r[1], "runs=%d failed=%d bus_errors=%d cycles=%d" % r[3], r[5] if not r[2] else "", flush=True)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    tot_runs = sum(r[3][0] for r in res); tot_cyc = sum(r[3][3] for r in res); allok = all(r[2] for r in res)
    with open(os.path.join(ROOT, "reports", "regression.md"), "w") as f:
        f.write(f"# Regression report\n\n{len(cfgs)} configurations x {len(seeds)} seeds = {len(res)} bench runs, **{'ALL PASS' if allok else 'FAILURES'}**; "
                f"{tot_runs} directed + constrained-random descriptor streams, {tot_cyc/1e6:.1f} M simulated cycles. Verilator 5.020, `--x-initial unique`, random register init per seed, "
                f"random-regression length {a.rand}. Elapsed {time.time()-t0:.0f} s.\n\n| config | seed | result | runs | failed | bus-monitor errors | cycles |\n|---|---|---|---|---|---|---|\n")
        for r in res: f.write(f"| {r[0]} | {r[1]} | {'PASS' if r[2] else 'FAIL'} | {r[3][0]} | {r[3][1]} | {r[3][2]} | {r[3][3]} |\n")
        cov = collections.defaultdict(lambda: [0, 0])
        for r in res:
            for k, (n, fl) in r[4].items(): cov[k][0] += n; cov[k][1] += fl
        f.write("\n## Test classes (summed over all configurations and seeds)\n\n| test class | runs | failed |\n|---|---|---|\n")
        for k in sorted(cov): f.write(f"| {k} | {cov[k][0]} | {cov[k][1]} |\n")
        f.write("\nEach 'run' is one descriptor stream executed on the DUT and compared with the independent reference model: every destination byte, every byte's "
                "write count (lost / duplicated / stray bytes), every completion-record field, the bus-level completion contract and the performance counters; plus the per-cycle bus protocol, "
                "protection and domain monitors.\n")
    sys.exit(0 if allok else 1)
