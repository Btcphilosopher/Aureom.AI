#!/bin/bash
for t in verilator yosys iverilog z3 python3 make zip g++; do printf "%-10s " $t; if [ $t = iverilog ]; then iverilog -V 2>&1 | head -1; else ($t --version 2>&1 || $t -V 2>&1) | head -1; fi; done
