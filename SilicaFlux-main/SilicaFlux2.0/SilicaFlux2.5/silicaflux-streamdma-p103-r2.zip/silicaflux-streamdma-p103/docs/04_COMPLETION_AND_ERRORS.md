# 04 — Completion contract, errors, abort, timeout, reset

## 1. The documented completion contract

> A transaction completes with `status OK` **only when** (1) the end of the transaction was reached, (2) **every write burst that was
> issued for it was answered `OKAY` by the destination**, (3) the read side is quiet, and (4) `bytes_done == bytes_total`.

`bytes_done` = destination payload bytes of write bursts that received an `OKAY` response — nothing else. The bench checks this against the
bus itself: the sum of reported `bytes_done` must equal the payload bytes of the bursts its slave model answered `OKAY`
(`COMPLETION CONTRACT` check; the mutants `write-b-ok-counts-error`, `write-bytes-ack-off-by-one` and `cpl-completes-before-writes-ack` target it).
*Acknowledgement means the destination's `B` response.* If the interconnect acknowledges writes early ("posted"), the guarantee is only
as strong as that acknowledgement — a platform property.

## 2. Completion record (`cpl_*` port, ready/valid, held until accepted)

`txn_id, domain, status, err, detail, bytes_done, bytes_total, err_addr, latency, partial` plus the `irq` pulse.
`status`: 0 OK · 1 ERROR · 2 ABORTED · 3 TIMEOUT. `partial` = `bytes_done != 0 && status != OK` — a combinational function of the record, so it is correct **in the first cycle** the record is presented (revision 1 registered it one cycle behind the record: an immediately accepted record carried a stale flag; found by the MemoryMatrix integration bench, fixed, now checked on every accepted record by both benches, by `fv_cpl.sv`, and by the mutants `cpl-partial-registered`). `detail` = the guard's fault code for
`ERR_GUARD_*`, the bus response code for `ERR_BUS_*`, the previous error for a timeout during a drain. `bytes_total` = bytes validated so far
(the whole transaction on success). `latency` = cycles from the start of the transaction (first descriptor admitted) to the cycle the
record was generated. A record is pushed on error always, on success only with `CPL_EN`. The record is stable until accepted
(proved: `fv_cpl.sv`). The next transaction starts only after the record was accepted.

## 3. Error codes

`0x01–0x0E` validation (see 02) · `0x20 ERR_GUARD_RD`, `0x21 ERR_GUARD_WR` the guard refused a burst (nothing of that burst moved) ·
`0x30 ERR_BUS_RD`, `0x31 ERR_BUS_WR` response `SLVERR/DECERR` · `0x32 ERR_PROTO` unexpected id, bad `RLAST`, spurious response ·
`0x33 ERR_TIMEOUT` · `0x34 ERR_ABORT` · `0x35 ERR_INTERNAL` (the completion self-check failed; must never happen).

## 4. Error / partial completion

First fault wins. The engine **stops starting work, drains the bus** (requests already issued are answered; write bursts whose `AW` was
issued still send all their `W` beats — an `AW` is never left without its data), then flushes the data path and reports. **No rollback**:
bytes already written stay written; `bytes_done` says how many were acknowledged. Bytes written but not acknowledged before the fault
may exist inside destination envelopes (never outside them; never twice). Remaining descriptors of the transaction are dropped.

## 5. Abort, timeout, reset

| Event | Behaviour |
|---|---|
| `ctl_abort` (pulse) | the active transaction is cancelled like an error: drain, flush, record with `status ABORTED / ERR_ABORT`; queued transactions behind it still run. If it arrives while idle it is ignored |
| watchdog (`cfg_timeout` > 0) | counts cycles with **no progress while the memory side owes work** (outstanding requests, committed `W` beats, a guard request in flight). Waiting for software to push the next descriptor does **not** count. On expiry: record `TIMEOUT / ERR_TIMEOUT`, the channel is **fenced** (`fenced=1`): nothing new starts, nothing is flushed, late responses are not trusted. Only `ctl_soft_reset` or `rst_n` clears it |
| `ctl_soft_reset` (pulse) | resets the core (not the perf counters), clears a fence, flushes the queue. It is **deferred until the MemoryGuard has nothing in flight** for this DMA (`soft_reset_pending`), and no new work starts meanwhile — otherwise a guard response that outlived the reset could be matched to a later request and hand it somebody else's physical address. `soft_reset_active` marks the reset cycle: **the platform must reset the memory fabric in that cycle** (stale `R`/`B` beats of the old transaction would otherwise be matched to new slots). If the guard never answers an accepted request, only `rst_n` clears the condition |
| `rst_n` (hardware reset) | cancels everything silently: no completion record, no bus activity afterwards from the cancelled transaction (tested), queue emptied. Bytes already written before the reset are correct, inside the destination, written once (tested). The platform must reset the fabric and the guard together |

## 6. Protocol rules the engine follows (checked by the bench monitors on every cycle)

`valid` is never withdrawn before `ready` and the payload is stable while stalled; `AW` and `W` are independent (`W` never waits for
`AWREADY`; a slave that waits for `WVALID` before `AWREADY` works — tested); a write burst is issued only when all its beats are
buffered, so a started burst always completes; every burst is full-width, INCR, beat-aligned, ≤ `BURST_LENGTH` beats, never crosses
4 KiB; IDs are unique among outstanding requests; `WLAST` exactly on the last beat; no `W` strobe of zero and no data on a lane
whose strobe is zero.
