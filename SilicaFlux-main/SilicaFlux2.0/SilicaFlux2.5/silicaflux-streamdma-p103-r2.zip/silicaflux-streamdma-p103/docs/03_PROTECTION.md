# 03 — Memory protection: the MemoryGuard path and the trusted domain

## 1. What "MemoryGuard" is here

The repository contains **no module named MemoryGuard** (see 00_AUDIT). The nearest verified artefact is CloudDMA's permission path
(`sfdma_perm_checker` + `sfdma_perm_table`, Project 64, formal/unit/mutation evidence there). StreamDMA therefore defines the
**MemoryGuard interface = the IOMMU request/response contract of that checker** and instantiates the checker (vendored byte-for-byte,
SHA-256 in `third_party/MANIFEST.tsv`):

```
guard_req_valid/ready  guard_req_domain  guard_req_asid(=memory type)  guard_req_write  guard_req_addr  guard_req_bytes  guard_req_id
guard_rsp_valid/ready  guard_rsp_id      guard_rsp_ok  guard_rsp_fault[3:0]  guard_rsp_pa
```
Request: `(domain, type, write, beat-aligned envelope start, envelope bytes 1..4096, never crossing 4 KiB)`.
Response, in request order: `ok` means the WHOLE envelope lies in ONE mapping of this `(domain, type)` that grants the access, with
the physical address of the envelope start. Fault codes: 1 no mapping, 2 permission, 3 mapped for another domain (simulation table only;
a real guard reports 1), 4 starts inside a mapping and leaves it, 5 translation failure, 6 type disabled, 7 request violates the
contract (internal consistency). A real MemoryGuard implements the same ports; the vendored table is the verified stand-in
(the bench uses it, programmed through its `tw_*` port).

## 2. What is enforced, and where

| Requirement | Enforcement |
|---|---|
| Permission validation **before** every protected transaction | every read burst and every write burst is submitted to the guard first; the AR/AW address is **the guard's `pa` for that very burst**. There is no datapath from a descriptor field to a bus address (mutants `read-address-bypasses-guard` / `write-address-bypasses-guard` are killed by the bench's independent PA monitor) |
| Trusted domain context captured | `desc_domain` is a **hardware sideband** accompanying each push; it is stored in the queue *with* the descriptor (captured at push, cannot change afterwards), latched when the transaction starts, forwarded to the guard with every request and driven on `ar_domain`/`aw_domain` as a second, independent check point |
| Untrusted descriptor fields cannot grant themselves permissions | the descriptor's `DOMAIN` is only a **claim**, compared against the sideband for every descriptor (`ERR_DOMAIN`); a change of the trusted binding in the middle of a transaction is also `ERR_DOMAIN`. No descriptor field selects a permission, a bypass or a physical address; memory types are validated and `cfg_type_en` can disable them; flags/reserved bits are checked |
| Address / length overflow | validator (≥ 128-bit arithmetic) + the checker's local checks (`bytes ≤ 4096`, no 4 KiB crossing, `addr+bytes ≤ 2**AW`) + a re-check of the guard's answer (beat-aligned PA, in-page offset kept, `pa+bytes ≤ 2**AW`) |
| Second, independent check point (SRAM) | when the memory is MemoryMatrix, the bridge turns the trusted domain on `ar_domain`/`aw_domain` into the matrix's `prot.secure` bit (`SECURE_MASK`), so the matrix's own region table can refuse a domain the guard let through; refusals come back as `SLVERR` and complete the transaction with `ERR_BUS_RD/WR` (docs/10 §4, tested incl. mutants `secure-*`) |
| No stray access | proved in simulation by an independent monitor: every AR/AW must (a) be granted for some trusted domain of the run by the bench's own translation table and (b) lie inside the beat-aligned envelope of a source/destination segment of the stream |

## 3. What the check does and does not cover

* **Per burst, ahead of use.** A burst is ≤ one 4 KiB page; mappings are 4 KiB multiples, so one lookup validates the whole burst
  exactly. The guard is asked for the next burst while earlier bursts are in flight (`PLAN_DEPTH`). A grant is for that burst; if the
  platform revokes a mapping while a burst is authorised-but-in-flight, that burst may still complete → **quiesce before unmapping**.
* **Envelope, not payload**, for reads (whole beats are fetched); writes use strobes but the envelope is what is validated.
* **Not claimed:** side-channel isolation, DoS fairness, protection from a compromised management plane (the guard programming port and
  the CSR window must never be reachable by a tenant), confidentiality of buffers (no scrubbing: stale bytes stay in the data buffer until
  overwritten; they are never readable through this block by another domain, but a platform that cares must partition or scrub).
* **A simulation table is not an isolation mechanism.** Real isolation requires the platform conditions in 09_INTEGRATION.
