# 06 — Performance: theoretical vs. achieved (stand-alone slave model; for the real MemoryMatrix see `benchmarks/stream_dma/REPORT_MM.md` and docs/10 §7)

The full analysis, with tables generated from the raw counter data, is **`benchmarks/stream_dma/REPORT.md`** (raw rows: `benchmarks/stream_dma/results.csv`; reproduce with `make bench`).
This page states the method and the conclusions. **All achieved numbers are simulation cycles. There are no hardware measurements.**

## Method

* **Theoretical** throughput is computed from the configuration alone: datapath peak `W = DATA_WIDTH/8` bytes/cycle, and the latency-bound limit
  `min(W, N·BL·W / (BL + L + c))` for `N` outstanding bursts, `BL` beats per burst, memory latency `L`. The constant `c` (internal cycles per burst) is *fitted once* from the
  single-outstanding (Phase 1) measurements (`c = 2`); every Phase-2 number is then a prediction.
* **Achieved** throughput comes from the DUT's own performance counters (`sf_stream_dma_perf`): `BYTES_WR / ACTIVE` etc., with the stall counters (read: no free slot / buffer full / guard; write:
  waiting for read data / W or AW not accepted / buffer full), buffer occupancy, burst utilisation, memory-conflict (hazard) events and transaction latency. Workloads: 128 KiB aligned and unaligned
  copies, 32 × 2 KiB and 64 × 256 B scatter-gather, 32 × 4 KiB and 64 × 64 B transactions; memory latency 2 / 10 / 30 / 80 cycles; ideal handshakes and 70% / 40% backpressure. Every benchmark run is checked byte-for-byte.

## Conclusions

1. **Phase 1 (one outstanding read, one outstanding write)** is latency-bound: 12.8 / 9.1 / 5.3 / 2.6 B/cycle at L = 2 / 10 / 30 / 80 (peak 16). The stall counters show the read side blocked on "no free slot" for 82% of the
   cycles and the assembler starved for source data 39% of the cycles; the data buffer is nearly empty. Throughput matches `BL·W/(BL + L + 2)` to within 0.5%.
2. **Phase 2 (parallel outstanding requests)** removes exactly that stall: with `N ≥ ceil((BL + L + 2)/BL)` slots and `FIFO_DEPTH ≥ N·BL` the copy runs at **99% of the datapath peak** (15.9 of 16 B/cycle at L = 10 with N = 2;
   N = 4 at L = 30; N = 8 or BL = 32 at L = 80). The formula predicts the measured values within ~2% wherever the buffer is large enough.
3. The stall counters also identified the sizing rules that the formula alone does not give: **`FIFO_DEPTH` must cover `N·BL`** (a 32-beat buffer with N = 4 shows 7656 "buffer full" stalls and collapses at higher latency) and
   **burst look-ahead** (`PLAN_DEPTH` 2 instead of 1 recovers ~6% at low latency by hiding the guard round trip).
4. Alignment costs nothing (unaligned copies run at the aligned rate); under 70% random backpressure on every channel the engine delivers 98.7% of what the slave offers (≈ 11.1 of 11.2 B/cycle).
5. **Remaining limit: small transactions** (64-byte transactions ≈ 1.4 B/cycle at L = 10) — bounded by per-transaction latency under the one-transaction-in-flight contract, independent of outstanding depth. A 29-cycle breakdown
   (11 of which are the dead time between a completion and the next transaction's first AR) is in REPORT.md §4. The next optimisation is transaction overlap; it was **not** attempted (docs/08).

## What is *not* claimed

No frequency, no GB/s figure, no power, no FPGA/silicon measurement. "Bytes per cycle" scales to GB/s only with a clock that no one has measured for this RTL.

## Revision 2 addendum: measured against the real MemoryMatrix

`benchmarks/stream_dma/REPORT_MM.md` repeats the method on the integrated system (DMA → bridge → `sf_memory_matrix`) with the theoretical bounds stated separately (datapath peak 16 B/cycle; matrix bank bound `4 × NUM_BANKS` B/cycle for a copy) and the matrix's own conflict / stall / latency counters. Differences from the stand-alone results that matter:
the memory latency is short (≈ 2 cycles), so **2 outstanding bursts already saturate** where the stand-alone slave at latency 30–80 needed 4–8; with 4 banks the bank bound equals the datapath peak, so **bank conflicts between the DMA's own read and write streams show up as lost throughput** and are removed by a destination placement rule, not by RTL; and the per-transaction fill/drain cost (≈ 42 cycles per 16 KiB copy) makes 64-byte transactions ≈ 1.9 B/cycle.
