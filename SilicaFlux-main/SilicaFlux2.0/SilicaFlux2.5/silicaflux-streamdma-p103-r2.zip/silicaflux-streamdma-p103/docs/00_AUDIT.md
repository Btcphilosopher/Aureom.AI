# 00 — Repository audit (Project 103, SilicaFlux StreamDMA) — revision 2

Audited: the working tree of the session checkout of `Btcphilosopher/Aureom.AI`. As in the earlier SilicaFlux projects the hardware lives
almost entirely **inside zip archives** (`SilicaFlux-main/`, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`); the archives named in the
brief were located by member name **and by content** (every archive, nested archives included, searched for the names below) and the ones that matter were extracted read-only to a scratch directory.

## 0. What changed since revision 1 (corrections to this audit)

| Revision 1 said | Revision 2 found |
|---|---|
| "**MemoryMatrix**: no module of that name exists" | **Wrong.** `silicaflux-memorymatrix-p101.zip` (Project 101) is in the repository: `sf_memory_matrix` (+ arbiter, decoder, perf), 84 files, its own regression, mutation, formal and benchmark evidence. It is the multi-bank SRAM subsystem the DMA is meant to feed. It is now **reused and integrated** (docs/10). |
| "no AXI4→SFB2 adapter; local SRAM needs one … **Gap**" | The matrix does not use SFB2 at all; its master port is a different request/response interface. The missing piece was an **AXI4-style → MemoryMatrix bridge**, which now exists (`sf_stream_dma_mm_bridge.sv`) and is verified against the real matrix RTL. |
| "SRAMController: not instantiated; local SRAM is reached through the memory port" | Still not instantiated: the matrix instantiates `sf_sram_bank` directly and its master port is a strict superset of the `sf_sram_controller` master port (P101 header), so the matrix *replaces* the controller's role for multi-master access. |
| (implied) the earlier verification covered the completion record | It did **not** cover `cpl_partial`: the flag was registered one cycle behind the record (stale in the first cycle, wrong for an immediately accepted record) and no bench check or formal property looked at it. Found by the integration bench, **fixed**, now checked by bench, formal and mutation (docs/05 §6). |
| `third_party/MANIFEST.sha256` | The file is `third_party/MANIFEST.tsv`. Provenance is now verified against the repository archives themselves (`scripts/check_vendor.py --repo <root>`: 35 files, 0 mismatches), not only against the manifest. |

Still true and re-confirmed: **no module named MemoryGuard exists anywhere in the repository** (content search of every archive; the only hits are this project and an unrelated "memory guard" sentence about a thermal solver's RAM limit).

**What was and was not read.** Read line by line in this project (rev 1 + rev 2): the CloudDMA P64 permission checker, permission table and package, P61 `sfd_fifo` / `sfd_rr_arb`,
the CloudDMA audit / descriptor / protection / limitation documents, the Meridian arbitration document; **rev 2 additionally** read the StreamDMA top level, descriptor validator, read engine, write engine and completion engine
(independent review, docs/05 §6), the MemoryMatrix header / port list / permission decoder / counter definitions / README, and the original bench's reference model. **Not re-read line by line:**
`sf_stream_dma_{buffer, align, plan, dcheck, queue, perf}` (covered by formal proofs / BMC, docs/05 §5), and the HPC / Storage / HostLink / DataFabric DMA engines (their properties below are quoted from CloudDMA P64's own audit,
`silicaflux-clouddma-p64/docs/00_AUDIT.md`). Nothing from older projects was re-simulated except: the CloudDMA permission path is exercised by every bench run, and **MemoryMatrix cases `base_4b_64w_256d`, `nb8`, `data128`, `regions3` were re-run on this toolchain (4/4 pass, 3.3 M self-checks)** before it was used.

## 1. Inventory against the brief

| Brief item | What exists (archive :: member) | Decision |
|---|---|---|
| **CloudDMA** | `silicaflux-clouddma-p64` (`silicaflux_cloud_dma`, `sfdma_channel`, `sfdma_desc_walker`, `sfdma_burst_ctrl`, `sfdma_perm_checker`, `sfdma_perm_table`, `sfdma_bytebuf`, …); `silicaflux-clouddpu-p61 :: sfd_clouddma` | **Reused** (vendored byte-for-byte): `sfdma_perm_checker`, `sfdma_perm_table`, `silicaflux_dma_pkg`, and P61's `sfd_fifo`. **Not reused**: the CloudDMA channel itself — a different, larger design (descriptor-in-memory chain walker, CRC, completion record written to memory, IOMMU ASIDs, multi-channel) with no `memmove`; StreamDMA is a new single-channel engine whose differences are listed in docs/01 |
| **HPC DMA** | `silicaflux-hpc-m05-dma-adapter :: hpc_dma_adapter` (+ M07 perf counters) | Not reused. A word-oriented adapter; no byte strobes / unaligned bursts (per P64's audit) |
| **Storage DMA** | `silicaflux-storagecore-p51 :: sfs_dma` | Not reused (one outstanding, aligned). Storage is memory type 2 behind the memory port |
| **DataFabric** | `silicaflux-datafabric :: silicaflux_dma, dma_transfer_engine, dma_burst_engine, dma_validate, sfb_*` | **Contract noted, not reused.** SFB2 has no native bursts and no IDs (per its PROTOCOL.md), so it cannot carry reordered, multi-outstanding bursts. An AXI4→SFB2 adapter does not exist; none was written (DRAM / network / storage endpoints are still behind the bench's AXI slave model) |
| **MeridianQoS** | `silicaflux-meridian-p83 :: sf_meridian_arbiter, sf_meridian_mport, sf_meridian_fabric` (QoS classes, aging) | Not integrated. QoS arbitration between masters belongs in the fabric in front of the memory port; mapping a StreamDMA port onto a Meridian master port was not evaluated |
| **SRAMController** | `silicaflux-sramcontroller-p73 :: sf_sram_controller`; `silicaflux-memorycore-sram :: sf_sram_controller` | Not instantiated; **superseded by MemoryMatrix for this purpose** (see §0) |
| **MemoryMatrix** | **`silicaflux-memorymatrix-p101 :: sf_memory_matrix`** (+ `_arbiter`, `_decoder`, `_perf`, defs/map headers; reuses `sf_sram_bank`, `sf_sram_core`, `sf_sram_macro_wrapper`, SECDED) | **Reused and integrated.** 30 files vendored byte-for-byte under `third_party/memorymatrix-p101/` (SHA-256 manifest; compared with the archive members). Bridge + system bench + mutation + benchmark: docs/10 |
| **TensorCore / Vector Engine** | `silicaflux.zip :: vector_engine.sv, tensor_unit.sv`; `silicaflux-tensorcore0x`; `silicaflux-tensorcore07 :: tensor_dma_adapter`; `silicaflux-hpc-m02-vector-lane`; P101 also carries `sf_tensor_scratchpad` / `sf_vector_scratchpad` adapters | Memory type 4 ("compute scratchpad") is served by the matrix in the integration test, i.e. the memory those engines use. The **compute RTL itself is not instantiated**; the tensor DMA adapter is a different, narrower interface |
| **MemoryGuard** | **no module of that name exists.** Nearest verified artefacts: `sfdma_perm_checker/table` (P64), `sf_albion_iommu` in `silicaflux-domainguard`, `sfd_sram_guard`/`sfd_host_guard` in P61 | StreamDMA **defines** the MemoryGuard interface as the IOMMU contract of the P64 checker and reuses that checker (docs/03). DomainGuard was listed but not integrated. The matrix's own region/permission table (`prot.secure`) is used as a **second, independent check point** behind the guard (docs/10 §4) |
| HBM | `silicaflux-hbmcore :: sf_hbm_dma_adapter` | Not integrated. HBM is memory type 0 |

## 2. Reuse actually made

Vendored **unchanged** (`third_party/`, SHA-256 in `third_party/MANIFEST.tsv`; 35 files, each compared with its member of the repository archive):

* P61 `sfd_fifo.sv` (all queues, and the bridge's AW queue), `sfd_rr_arb.sv` (vendored for completeness, not instantiated);
* P64 `sfdma_perm_checker.sv` (the MemoryGuard front end), `sfdma_perm_table.sv` (the bench's MemoryGuard model — a *model of an IOMMU contract*, not an isolation mechanism), `silicaflux_dma_pkg.sv`;
* **P101 MemoryMatrix** (30 files: the matrix, its arbiter/decoder/perf, and the reused SilicaFlux SRAM bank/core/ECC modules it carries) — the memory the integration bench runs against.

## 3. Modules that do not exist and what stands in for them

| Needed | Stand-in |
|---|---|
| MemoryGuard / IOMMU | vendored P64 checker + simulation table (verified there against an independent 64-bit reference) |
| AXI4 → MemoryMatrix adapter | **new:** `sf_stream_dma_mm_bridge` (this project) |
| AXI4 → SFB2 adapter | none (DataFabric endpoints are not reachable); the bench's AXI slave model stands in for DRAM / storage / network |
| A control plane that supplies the trusted domain with each descriptor | the `desc_domain` sideband; the bench drives it |
| DRAM / storage / network | the bench's byte-array slave model, with reordering, interleaving, latency, backpressure and faults. **SRAM / compute scratchpad are now the real MemoryMatrix RTL** |

## 4. Tooling used

Verilator 5.020, Yosys 0.33, Icarus Verilog 12 (installed, **not used**), Z3 4.8.12 with `yosys-smtbmc`, Python 3, g++ 13. SymbiYosys is
not packaged for this environment; `formal/stream_dma/run_formal.py` performs the same Yosys → SMT2 → `smtbmc` steps. The repository coding rules for
Yosys 0.33 were followed (flat ports, no packages in the new RTL, no `int'()` casts). Versions: `reports/tools.txt`.

## 5. Gaps found in the repository that this project does not close

No MemoryGuard; no AXI4→SFB2 adapter (so DataFabric endpoints are unreachable); no memory fabric with several outstanding transactions in front of DRAM / storage; **no per-master reset for MemoryMatrix** (only a global `flush_i`, docs/10 §5); no FPGA or silicon
result anywhere in the repository that this design could be compared with.
