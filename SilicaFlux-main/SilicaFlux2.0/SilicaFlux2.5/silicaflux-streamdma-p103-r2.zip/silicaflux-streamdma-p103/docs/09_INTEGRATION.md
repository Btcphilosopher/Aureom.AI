# 09 — Integration and platform requirements

## Ports (see the header of `sf_stream_dma.sv`)

control (`ctl_abort`, `ctl_soft_reset`, `cfg_timeout`, `cfg_type_en`) · descriptor push (`desc_valid/ready/data/domain`) · completion
(`cpl_*`, `irq`) · MemoryGuard (`guard_req_*`, `guard_rsp_*`) · memory port (`ar_*`, `r_*`, `aw_*`, `w_*`, `b_*`; `*_mtype` and `*_domain` sidebands) ·
status (`busy`, `fenced`, `guard_proto_err`, `soft_reset_pending`, `soft_reset_active`) · performance (`perf_clear`, `perf_sel`, `perf_data[63:0]`).
No CSR block: the control plane maps these onto registers (descriptor words, `cfg_*`, counters through `perf_sel`).

## Requirements on the platform for the guarantees in docs 03 and 04 to hold

1. The memory port is the **only** path from this DMA's domain to memory (no bypass around the guard).
2. `desc_domain` comes from the hardware path that authenticates the submitter (queue binding, function id) — never from software-controlled data.
3. The MemoryGuard implements the contract in 03 §1 (responses in request order, one per request, whole-envelope check, injective mappings).
   The guard-programming interface is privileged.
4. **Quiesce before unmapping** a buffer a transaction may still use.
5. **Soft reset / fence recovery:** pulse `ctl_soft_reset`, and reset the memory fabric in the cycle `soft_reset_active` is high. If a guard request
   was accepted but never answered, use `rst_n`.
6. `rst_n` resets the core, the fabric and the guard together.
7. Writes are acknowledged by the destination (`B` after the write was performed); an interconnect that acknowledges early weakens the completion contract.
8. The data buffer is register-file style storage (`FIFO_DEPTH × (DATA_WIDTH + log2(bytes) + 1)` bits, asynchronous read). For ASIC use an SRAM macro with
   a registered read; for FPGA it maps to distributed RAM (docs/07).
9. The data buffer is not scrubbed between transactions (03 §3).

## When the memory is MemoryMatrix (P101): additional requirements (docs/10)

10. **Disjoint physical windows per memory type.** Types that share the matrix (the integration serves types 1 and 4) must be mapped by the guard onto **disjoint, injective** physical windows. The hazard interlock tracks destinations per memory type, so
    two types aliasing the same physical bytes would defeat it (the same IOVA-aliasing caveat as docs/08 "Protection", extended across types).
11. **Soft reset needs a matrix flush, and the flush is global.** `soft_reset_active` must reset the bridge and pulse the matrix's `flush_i` (done in `tb_mm_top.sv`). `flush_i` discards the responses of *every* master of the matrix, so keep the other masters quiescent around a DMA soft reset, or use `rst_n`.
12. **ECC builds are zeroed by reset.** With `ENABLE_ECC = 1` the matrix runs its bank-init engine on `rst_n` and the whole array reads zero afterwards; non-ECC builds keep their contents across reset (P101 M8). A hard reset therefore cancels a transfer *and*, for ECC builds, erases all SRAM.
13. **The matrix capacity must be smaller than `2**MM_AW`** (elaboration error otherwise): the bridge refuses a burst by sending it to an address the matrix rejects.
14. A matrix permission-region table (secure-only, read-only, deny) is **static configuration**; reprogram it only while the DMA is quiescent (the bench changes it between runs).
