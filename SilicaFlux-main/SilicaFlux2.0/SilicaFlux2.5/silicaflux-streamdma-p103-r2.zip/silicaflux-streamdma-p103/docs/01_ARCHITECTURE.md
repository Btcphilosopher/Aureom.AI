# 01 — Architecture

```
 desc push ─► Descriptor Queue ─► Descriptor Validator ─► segment FIFOs ─┬─► Read Request Engine ─► Data Buffer ─► Write Request Engine ─► AW/W/B
 (+trusted    sf_stream_dma_queue   sf_stream_dma_descriptor  (rseg,wseg) │   plan→guard→AR queue      (reservation    plan→assemble→W FIFO
  domain)                            + _dcheck                           │   →AR issue, R ingest       ring + align)   →guard→AW queue→AW issue, B ingest
                                                                         │          ▲ MemoryGuard (read)                         ▲ MemoryGuard (write)
                                                                         └────► Completion Engine (sf_stream_dma_cpl): events, drain, flush, watchdog, record
 perf counters (sf_stream_dma_perf) observe every stage
```

| File | Role |
|---|---|
| `sf_stream_dma.sv` | top: parameters + static checks, soft reset, wiring, performance-event plumbing |
| `sf_stream_dma_queue.sv` | **Descriptor Queue** (`DESCRIPTOR_DEPTH`), stores descriptor + trusted domain |
| `sf_stream_dma_dcheck.sv`, `sf_stream_dma_descriptor.sv` | **Descriptor Validator**: rules, transaction tracking, error markers, skip mode |
| `sf_stream_dma_plan.sv` | burst planner (pure combinational, proved) |
| `sf_stream_dma_read.sv` | **Read Request Engine**: hazard interlock, planner, guard client, AR queue/issue, slot table, R ingest |
| `sf_stream_dma_buffer.sv` | **Data Buffer**: reservation ring (`FIFO_DEPTH` beats) |
| `sf_stream_dma_align.sv` | byte realigner (accumulator), the only place bytes change lane |
| `sf_stream_dma_write.sv` | **Write Request Engine**: planner, assembler, W FIFO, guard client, AW queue/issue, slot table, B ingest |
| `sf_stream_dma_cpl.sv` | **Completion Engine**: the contract, drain/flush, abort, watchdog, record |
| `sf_stream_dma_perf.sv` | performance counter bank |
| vendored `sfdma_perm_checker` | the MemoryGuard front end (2 clients: read, write) |

## Parameters

`DATA_WIDTH` (power of two 32..512, initial 128) · `ADDR_WIDTH` (16..64) · `NUM_CHANNELS` (**must be 1** — elaboration error otherwise) ·
`BURST_LENGTH` (1..256, `BURST_LENGTH × bytes/beat ≤ 4096`) · `FIFO_DEPTH` (data buffer beats, power of two ≥ `BURST_LENGTH`) ·
`MAX_OUTSTANDING_READS` / `MAX_OUTSTANDING_WRITES` (≥ 1) · `DESCRIPTOR_DEPTH` · further: `DOM_W`, `SEG_DEPTH`, `PLAN_DEPTH` (burst look-ahead),
`WR_FIFO_DEPTH` (≥ `BURST_LENGTH`), `GUARD_OUT`, `MAX_SEG_LOG2`, `MAX_TXN_LOG2`, `CNT_W`. Invalid combinations are rejected at elaboration
(an unresolved module is instantiated whose name states the violated rule).
**Initial configuration (as briefed):** 128-bit datapath, one channel, `MAX_OUTSTANDING_READS = MAX_OUTSTANDING_WRITES = 1`, explicit byte strobes,
one transaction in flight.

## Datapath and byte order

1. **Read side.** The planner cuts a segment into bursts: ≤ `BURST_LENGTH` beats, never crossing 4 KiB, beat-aligned envelope, first-beat byte
   offset `off`, last-beat last lane `endl`. Each burst is checked by the guard, then issued. Its `ARID` is its **slot** number.
2. **Response buffering.** At AR issue the buffer **reserves** `nbeats` consecutive ring entries in issue order. A response beat is matched by `RID`
   to its slot, shifted right by the first-beat offset so its payload sits in lane 0.., masked, and written at `slot.base + beat`, marking the
   entry valid. Beats of different IDs may arrive in any order or interleaved; the consumer sees entries **in reservation order only**. Reserved
   space guarantees a response always has room, so `R` is never back-pressured.
3. **Realign.** The head entry (1..W payload bytes in lanes 0..) is pushed into a 2W-byte accumulator; a write beat pops exactly the bytes its
   destination lanes need and places them at lane offset `lo` with strobe = those lanes. Source and destination offsets are therefore independent.
   Byte order = stream order (proved: `fv_align.sv`).
4. **Burst construction.** The write planner mirrors the read planner on the destination. The assembler builds a burst's beats into the W FIFO;
   `AW` is issued only when **all** beats of its burst are in the FIFO (store-and-forward at burst granularity: a started burst always completes,
   which also makes error handling clean). `W` beats follow in order; `W` never waits for `AWREADY`.
5. **Write responses.** `BID` = slot; any order across IDs is accepted; `OKAY` adds the burst's payload bytes to `acked_bytes`.

## Concurrency ("parallel outstanding requests")

`MAX_OUTSTANDING_READS` slots (ID = slot) and `MAX_OUTSTANDING_WRITES` slots; `PLAN_DEPTH` look-ahead hides the guard round trip. All request IDs
are tracked in the slot tables; no response ordering is assumed (reorder/interleave tests, `par4`/`dw64` (3 read slots — not a power of two) etc.).
Reads of the next segment overlap writes of the current one, subject to the hazard interlock (02 §5).

## Differences from CloudDMA (P64), deliberately

Smaller: one channel, descriptors arrive through a ready/valid queue (not fetched from memory), no CRC, completion record on a port rather than
written to memory, **one transaction in flight**, hazard interlock instead of `ORDERED`, the byte realigner is an accumulator (not a W² rotation
network), a reservation ring for reordering, and the guard is reached through the vendored checker's contract.
