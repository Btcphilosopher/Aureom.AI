# 02 — Descriptor ABI, transactions and scatter-gather (version 1)

Single source of truth: `rtl/stream_dma/sf_stream_dma_defs.svh` (constants) and `rtl/stream_dma/sf_stream_dma_dcheck.sv` (rules).
The verification bench's reference model (`tests/stream_dma/tb_ref.h`) was written from THIS document, not from the RTL.

## 1. Conventions

| Item | Rule |
|---|---|
| Size / order | 256 bits = 8 × 32-bit words, little endian: word *n* = bits `[32n+31:32n]`; a 64-bit field is two words, low word first |
| Address width | descriptor addresses are 64-bit; the engine's `ADDR_WIDTH` (16..64) bounds what is reachable; every address and every `addr+len` is checked against `2**ADDR_WIDTH` in ≥ 128-bit arithmetic (no wrap-around can alias a low address) |
| Alignment | **none required**: source and destination may start at any byte; length may be any byte count |
| Memory types | `SRC_TYPE`/`DST_TYPE`: 0 DRAM/HBM, 1 SRAM, 2 storage window, 3 network buffers, 4 compute scratchpad; 5..15 reserved (rejected). `cfg_type_en` can disable types. Types are separate address spaces: overlap is only checked between equal types |
| Limits | `LENGTH` ≤ `2**MAX_SEG_LOG2` (default 16 MiB); transaction total ≤ `2**MAX_TXN_LOG2` (default 1 GiB) |

## 2. Layout

```
word  bits        field      meaning
 0    [7:0]       VERSION    1
      [15:8]      OPCODE     0 = COPY; 1..255 reserved (rejected)
      [31:16]     FLAGS      see section 3
 1    [15:0]      TXN_ID     transaction id chosen by software, echoed in the completion record
      [31:16]     DOMAIN     the tenant the submitter CLAIMS to be. Must equal the trusted sideband captured at push
 2    [3:0]       SRC_TYPE
      [7:4]       DST_TYPE
      [31:8]      reserved   must be 0
 3    [31:0]      LENGTH     bytes of this segment (1 .. 2**MAX_SEG_LOG2). 0 is rejected
 4,5  [63:0]      SRC_ADDR   source address (an IOVA: translated by the MemoryGuard)
 6,7  [63:0]      DST_ADDR   destination address (an IOVA)
```

## 3. Flags (`W0[31:16]`) — transaction structure and completion flags

| Bit | Name | Meaning |
|---|---|---|
| 0 | `FIRST` | first (or only) segment of a transaction |
| 1 | `LAST` | last (or only) segment; the transaction completes after the writes of every segment were acknowledged |
| 2 | `FENCE` | do not start reading this segment until every earlier write is acknowledged (explicit barrier; hazards are also interlocked automatically, §5) |
| 3 | `CPL_EN` | **FIRST only**: push a completion record on success (an error ALWAYS pushes one) |
| 4 | `IRQ_EN` | **FIRST only**: pulse `irq` at completion (an error always pulses it) |
| 5..15 | — | reserved, must be 0 |

`CPL_EN`/`IRQ_EN` on a non-FIRST descriptor are rejected (`ERR_FLAGS`).

## 4. Transactions and scatter-gather

* A **transaction** is a run of descriptors `FIRST … LAST` that share one `TXN_ID` and one trusted domain. A single descriptor is `FIRST|LAST`.
* **Scatter-gather = a chain of segments.** Segment *i* copies `LEN_i` bytes from `SRC_i` to `DST_i`; any mix of contiguous and
  noncontiguous sources and destinations is expressed by the addresses (gather: many sources → one contiguous destination;
  scatter: one source → many destinations; or both noncontiguous). The chain is *indexed segments*: it is pushed through the descriptor queue;
  the byte stream is continuous across segment boundaries on the read side, and each segment's destination is written with byte strobes,
  so a partial first or final beat never touches a byte outside `[DST, DST+LEN)`.
* **Chain semantics are sequential**: the result is as if segments executed one after another, in order. The hardware reorders
  nothing that is observable (§5).
* **One transaction is in flight at a time** (this release). A descriptor that would *start* a transaction waits in the queue until
  the previous transaction's completion has been delivered. Descriptors *inside* the open transaction are validated and pipelined ahead.

## 5. Overlap and ordering — "no silent corruption"

* **Within a segment**, source and destination of the same memory type must not overlap (`ERR_OVERLAP`). The engine has **no memmove
  semantics**: overlapping copies are rejected, never executed. (A memmove would need the read/write order of every burst fixed
  against the memory's own reordering; rejecting is the documented, tested choice.)
* **Between segments** of a transaction the interlock gives the sequential semantics for free: a segment whose source overlaps a
  destination written earlier in the transaction (read-after-write), or whose destination overlaps one (write-after-write), or that
  carries `FENCE`, does not start reading until every earlier write is acknowledged. Write-after-read is safe by construction (a write
  is issued only after all earlier stream bytes were read and their responses consumed). The interlock tracks one `[lo,hi)` hull of the
  un-retired destinations per memory type — conservative (a false positive costs cycles, never correctness).
* **Not covered** (platform requirement, see 09_INTEGRATION): two *different IOVAs* of one domain mapped to the *same physical bytes*
  (aliasing) cannot be detected by an IOVA-based check; mappings must be injective.

## 6. Validation rules (first failing rule wins; no byte of a failing descriptor moves)

| # | Rule | Error |
|---|---|---|
| 1 | `VERSION == 1` | `0x01 ERR_VERSION` |
| 2 | `OPCODE == 0` | `0x02 ERR_OPCODE` |
| 3 | `DOMAIN == trusted sideband` (all 16 bits) | `0x03 ERR_DOMAIN` — an **isolation violation** |
| 4 | no reserved flag; `CPL_EN`/`IRQ_EN` only on `FIRST` | `0x04 ERR_FLAGS` |
| 5 | reserved word-2 bits zero | `0x05 ERR_RSVD` |
| 6 | outside a transaction the descriptor must be `FIRST`; inside it must not be | `0x06 ERR_CHAIN_FIRST` |
| 7 | inside a transaction `TXN_ID` unchanged | `0x07 ERR_CHAIN_TXN` |
| 8 | inside a transaction the trusted domain is unchanged | `0x03 ERR_DOMAIN` |
| 9 | `SRC_TYPE`, `DST_TYPE` ≤ 4 and enabled | `0x08 ERR_MEMTYPE` |
| 10 | `LENGTH ≥ 1` | `0x09 ERR_LEN_ZERO` |
| 11 | `LENGTH ≤ 2**MAX_SEG_LOG2` | `0x0A ERR_LEN_BIG` |
| 12 | running total + `LENGTH` ≤ `2**MAX_TXN_LOG2` | `0x0B ERR_TOTAL_BIG` |
| 13 | `SRC_ADDR`, `DST_ADDR` < `2**ADDR_WIDTH` | `0x0C ERR_ADDR_RANGE` |
| 14 | `SRC+LENGTH`, `DST+LENGTH` ≤ `2**ADDR_WIDTH` | `0x0D ERR_ADDR_OVFL` |
| 15 | same type ⇒ `[SRC,SRC+LEN)` ∩ `[DST,DST+LEN) = ∅` | `0x0E ERR_OVERLAP` |

Proved exhaustively: `err == 0 ⇔` all of the above hold (`formal/stream_dma/fv_dcheck.sv`).

**Rejected descriptor in a chain (partial completion).** Segments already accepted still execute completely; an error *marker* follows
them in order; the transaction completes with `status ERROR`, the error code, and `bytes_done` = the bytes of the executed prefix.
The remaining descriptors of that transaction are **dropped** (skip mode) up to and including the next `LAST`, or until a `FIRST`
descriptor appears (a broken transaction with no `LAST` cannot swallow the next one). A stray non-`FIRST` descriptor outside a
transaction produces one `ERR_CHAIN_FIRST` completion and the same skip behaviour. Nothing is rolled back.
