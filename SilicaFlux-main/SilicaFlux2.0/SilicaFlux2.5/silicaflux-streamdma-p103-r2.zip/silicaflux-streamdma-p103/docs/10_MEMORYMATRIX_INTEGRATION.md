# 10 — StreamDMA ↔ MemoryMatrix (Project 101) integration

**Evidence level: RTL simulation (Verilator 5.020) of StreamDMA + a new bridge + the real, unmodified `sf_memory_matrix` RTL.** No FPGA, no silicon, no timing closure, no frequency. Every number below was copied by a script from the generated reports
(`reports/integration_mm.md`, `reports/mutation_mm.md`, `reports/unit_bridge.txt`, `reports/synth.md`, `benchmarks/stream_dma/REPORT_MM.md`), not typed by hand.

## 1. Why and what

The brief asks for an engine that "connects SilicaFlux compute, networking, storage and SRAM subsystems" and to "reuse existing verified modules". The repository's SRAM subsystem is **MemoryMatrix** (P101: multi-bank single-port SRAM, per-bank round-robin arbitration,
interleave map, bank-spanning / misaligned accesses, byte enables, optional SECDED ECC, permission regions, performance counters). Revision 1 of this project missed it (docs/00 §0). Revision 2 reuses it as the real memory behind memory types 1 (SRAM) and 4 (compute scratchpad):

```
 descriptors ─► sf_stream_dma ──(AXI4-style: AR/R/AW/W/B, IDs, INCR bursts, byte strobes)──► sf_stream_dma_mm_bridge ──► sf_memory_matrix  (masters 0 = DMA read, 1 = DMA write)
                    │  ▲                                                                                                    ▲ ▲
                    ▼  │ MemoryGuard contract                                                                       master 2 = host (bench)   master 3 = noise (bench)
            sfdma_perm_checker + table (P64)
```

## 2. The bridge (`rtl/stream_dma/sf_stream_dma_mm_bridge.sv`)

| DMA side | matrix side |
|---|---|
| `AR` burst of `len+1` beats | `len+1` read requests on **master 0**: `addr += W`, `size = log2(W)`, `id = {last, ARID}` |
| `AW` burst (queued, `AW_DEPTH`, the vendored `sfd_fifo`) + `W` beats | one write request per `W` beat on **master 1**: `be = WSTRB`, `id = {last, AWID}`; `w_ready` = (a burst is active) AND the matrix accepts the beat |
| `R` beat | the matrix read response (responses of one master return **in acceptance order**, so `R` is in order); `RLAST` = the `last` bit carried in the id |
| `B` | **after the matrix write response of the burst's last beat** (every beat of the burst has been performed by its bank: "acknowledged write"); the worst beat response wins |

Zero-bubble hand-over between bursts in both directions; `W` that arrives before its `AW` waits (`w_ready = 0`), which cannot deadlock because `AW` acceptance does not depend on `W` (the DMA never makes `AW` wait for `W`).
Status mapping: `SF_ST_OK → OKAY`, `SF_ST_RANGE → DECERR`, every other status (permission, alignment, ECC-uncorrectable, bad op) `→ SLVERR`. The DMA then completes the transaction with `ERR_BUS_RD` / `ERR_BUS_WR` (docs/04).

## 3. Fail closed

A burst that is not exactly what the matrix serves is **not forwarded as written**. It is issued at the address `{MM_AW{1}}`, which the matrix rejects with `SF_ST_RANGE` (no array access, no side effect), and comes back as `DECERR`. The conditions:

| condition | reachable from StreamDMA? | verified by |
|---|---|---|
| memory type not in `TYPE_MASK` (here: only 1 and 4) | yes (a type-2 transfer that the guard permits) | system bench `type-rd/wr`; mutant `type-check-off` |
| physical address with bits above `MM_AW` | yes (guard maps an IOVA window to PA 1 MiB) | system bench `aperture-rd/wr`; mutant `aperture-bits-off` |
| address beyond the matrix but inside the aperture | yes | system bench `range-rd/wr` (the matrix itself answers `RANGE`) |
| burst that would **wrap** around the top of the aperture | **no**: a burst never crosses 4 KiB and `2**MM_AW` is a 4 KiB multiple | **adversarial unit test T3**; mutant `wrap-check-off` — see the proof below |
| beat size ≠ full width, burst type ≠ INCR | **no** | unit tests T4, T5; mutants `size-check-off`, `burst-type-off` |
| `WLAST` ≠ AW length | **no** | unit test T8 (sticky `proto_err`); mutant `proto-check-off` |

With `wrap-check-off` the unit test **shows real corruption**: *"PA 0 untouched by the wrapping write: byte mismatch"* — the second beat of a burst starting at `0xFFFF0` wraps to address 0 and overwrites it. These four checks are invisible through StreamDMA (so the system bench alone would let their mutants survive for the wrong reason); that is why the adversarial unit test exists.
The bridge refuses `ADDR_WIDTH <= MM_AW` at elaboration; the integration top refuses a matrix whose capacity equals `2**MM_AW` (nothing would then be out of range) — **a platform top that instantiates the bridge must apply the same check** (docs/09 item 13).

## 4. Protection through the matrix (a second check point)

* The **guard** (P64 checker + table) still decides every burst's physical address; the bridge never forms an address from a descriptor field.
* The trusted domain on `ar_domain` / `aw_domain` becomes the matrix's `prot.secure` bit (`SECURE_MASK`; the bench marks domain 2 secure). The matrix's region table can then refuse a domain the guard let through: **secure-only window** (domain 1 refused, domain 2 allowed, both byte-exact), **write-protected window**, **deny-all window**, and a window that **write-protects only the first 128 bytes of a burst** (the burst is half denied: the `B` response must carry the *worst* beat; mutant `b-resp-last-only`).
* Refusals are `SLVERR`; the DMA reports `ERROR / ERR_BUS_*`, `bytes_done` equals the payload of bursts answered `OKAY` (checked against the bus), and the bytes of a refused burst stay unchanged (checked by dumping the matrix).

## 5. Completion, reset, abort

* **Completion contract through a real memory.** The DMA reports OK only after every write burst was answered `OKAY`; here that means every beat was performed by its bank. The bench checks it **at the bus, in the cycle the record is accepted**: no OK record while any write beat or burst is unacknowledged, and `Σ bytes_done` = payload of bursts whose `B` was `OKAY` (mutants `b-before-ack`, `w-ready-ignores-matrix`, `wr-strobes-ignored`, `wr-resp-ignored`). Doing this check *later* (while the next transaction already writes) produced a false failure during development — it must be at acceptance (docs/05 §6).
* **Abort** (12 random aborts per run): aborted record + the queued transaction completes OK; every destination byte is old or new, none outside the destination, none written twice.
* **Hard reset** (`rst_n` at random cycles, 16 per run): no record, no activity on the matrix afterwards, written bytes correct and in place; non-ECC matrix contents persist, **ECC builds are zeroed** by the matrix's bank-init engine (the bench checks "all zero" for ECC configs).
* **Soft reset** (`ctl_soft_reset`, 10 per run): the bridge is reset and the matrix **flushed** in the `soft_reset_active` cycle (docs/09 item 11). MemoryMatrix has **no per-master reset**: `flush_i` discards the responses of *all* masters, so the bench keeps host and noise idle around it. This is a limitation of the matrix interface, listed in docs/00 §5.

## 6. Verification (all in `reports/`)

| item | result |
|---|---|
| Bridge lint | Verilator `-Wall` clean in 4 parameterisations; 5 illegal bridge parameter sets and 1 illegal integration parameter set rejected **by their intended check** (`reports/lint.md`) |
| Adversarial unit test (`tb_bridge_unit.sv`) | **PASS**, 175 checks (`reports/unit_bridge.txt`) — drives the bridge directly against the real matrix: legal round trips, byte strobes, aperture wrap, wrong size, wrong burst type, unserved types, out-of-aperture, wrong WLAST, secure window, long burst after refusals |
| System bench (`tb_mm_main.cpp`) | 6 matrix configurations × 5 seeds = 30 bench runs, **all pass**; 21,000 descriptor streams / directed cases, 22.2 M simulated cycles (`reports/integration_mm.md`). Memory is loaded and dumped **through the matrix's own port** (never peeked). Independent byte-accurate reference model, write-count monitor (no lost / duplicated / stray byte), stray-read monitor, bus-level completion contract, DMA counters vs what the matrix saw, a noise master that checks its own reads |
| Test classes | single byte, full width, large (to 20 000 B), scatter-gather, unaligned, cross-segment RAW / WAW hazards (incl. `FENCE`), multiple transactions, random backpressure (descriptor, completion, matrix noise), full-rate contention, matrix faults (range, aperture, type, secure, write-protect, deny, wrap, half-denied burst), abort, hard reset, soft reset, constrained-random |
| Matrix configurations | 4 / 8 / 16 banks; read latency 1 / 2 / 3; ECC on; 64 / 128 / 256-bit datapath; issue window 2; 1 to 4 outstanding DMA bursts |
| Mutation (`mutate_mm.py`) | **28 / 28** injected bridge bugs detected (24 by the StreamDMA system bench, 4 only by the adversarial unit test), baseline-gated (`reports/mutation_mm.md`) |
| Matrix re-verification | 4 cases of P101's own regression re-run on this toolchain: pass (docs/00 §0) |

**Honest history of the bench.** The first integration runs failed — every time because of a **bench** error, found by reproducing the failure in isolation before changing anything: a refresh margin that spilled into the noise region; a random generator that gave one transaction two domains (the DMA was right to refuse it);
a contract check performed *after* the next transaction had started; a mapping added after the guard table was programmed; a reference image not resynchronised after a legitimately partial write; a "bytes_done = 0" expectation that only holds with one outstanding write; an ECC expectation that ignored zero-on-reset; a clock advanced by `raw_tick()` without the driver/sampler (eight in all). And **one real RTL defect** in the previously "verified" DMA: `cpl_partial` (docs/05 §6).
A mutation run with a failing baseline "killed" a mutant for the wrong reason, so the harness now refuses to run unless the unmutated design passes both benches first.

## 7. Performance against the real matrix (simulation; `benchmarks/stream_dma/REPORT_MM.md`)

Theoretical bounds are separate from measurements there. Headlines (16 KiB copies, 128-bit datapath, peak 16 B/cycle):
* 1 outstanding burst (the initial configuration): **10.7 / 10.8 / 10.8 B/cycle** at 4 / 8 / 16 banks — latency-bound, independent of the bank count;
* **2 outstanding: 14.52 / 14.93 / 14.93**; 4 outstanding gives the same numbers (the matrix latency is short);
* 4 banks at skew 0 lose to bank conflicts between the DMA's own streams; a one-beat destination skew gives **15.37** (placement rule, no RTL change); a deeper matrix queue (`NSLOT` 16) changes nothing (14.52);
* a noise master at 100 % costs 4 banks 26 %, 8 banks 8 %, 16 banks 5 %;
* per-transaction cost: 8 × 4 KiB transactions 13.79 B/cycle, 32 × 64 B transactions 1.94 B/cycle.

## 8. Synthesis of the bridge (Yosys, no PDK; `reports/synth.md`)

| parameters | ASIC-generic cells | flops | gate levels (ltp) | FPGA LUTs | FPGA FFs | RAM cells | LUT6 levels |
|---|---|---|---|---|---|---|---|
| default (128-bit, 1 outstanding id bit) | 628 | 133 | 22 | 153 | 74 | 6 | 5 |
| RIDW=2, WIDW=2, AW_DEPTH=4 | 777 | 203 | 22 | 158 | 80 | 6 | 5 |

The bridge is small next to the DMA core (the data buffer dominates, docs/07) and its logic depth is far below the validator's (≈ 120 gate levels). Its outputs toward the matrix are combinational from the DMA's registered `valid`/payload and the matrix's registered-state `ready`; `ar_ready` depends combinationally on `rd_req_ready` (a registered-state function in the matrix contract), so there is no combinational loop. **These are logic-depth and resource indicators only: no cell library, no wire model, no timing constraint, no frequency.**

## 9. What is not done

No FPGA / ASIC run of the integration; no formal harness for the bridge; transaction overlap (docs/08); AXI4→SFB2 adapter; per-master matrix reset; MBIST / scrubber attachment (P101's own limitation); DRAM / storage / network endpoints are still the bench's model.
