// StreamDMA <-> MemoryMatrix (P101) integration: the bridge plus the vendored MemoryMatrix RTL (paths relative to the project root).
// Use TOGETHER with rtl/filelist.f (which supplies sfd_fifo):  verilator ... -f rtl/filelist.f -f rtl/filelist_mm.f
+incdir+third_party/memorymatrix-p101/rtl/memory
+incdir+third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl
+incdir+third_party/memorymatrix-p101/rtl/memory/third_party/ras_secded
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/sf_sram_core.sv
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/sf_sram_macro_wrapper.sv
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/sf_ecc_enc.sv
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/sf_ecc_dec.sv
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/sf_ecc_counters.sv
third_party/memorymatrix-p101/rtl/memory/third_party/memorycore/rtl/sf_sram_bank.sv
third_party/memorymatrix-p101/rtl/memory/third_party/ras_secded/sfras_secded_enc.sv
third_party/memorymatrix-p101/rtl/memory/third_party/ras_secded/sfras_secded_dec.sv
third_party/memorymatrix-p101/rtl/memory/sf_memory_matrix_decoder.sv
third_party/memorymatrix-p101/rtl/memory/sf_memory_matrix_arbiter.sv
third_party/memorymatrix-p101/rtl/memory/sf_memory_matrix_perf.sv
third_party/memorymatrix-p101/rtl/memory/sf_memory_matrix.sv
rtl/stream_dma/sf_stream_dma_mm_bridge.sv
