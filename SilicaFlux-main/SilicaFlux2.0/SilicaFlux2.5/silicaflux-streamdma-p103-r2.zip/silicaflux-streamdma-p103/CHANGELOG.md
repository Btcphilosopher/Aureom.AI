# Changelog

## Revision 2 (this package) — relative to the earlier `silicaflux-streamdma-p103` archive

**Baseline reproduced first.** On a fresh toolchain (Verilator 5.020, Yosys 0.33, Z3 4.8.12, Icarus 12 installed but unused) every revision-1 result was re-run before anything was changed: lint clean (9 + 13 negative),
35 bench runs / 55 265 descriptor streams all pass with cycle counts identical to the shipped report, 12/12 formal jobs pass and 12/12 formal sensitivity checks catch their bug, 41/41 mutants killed, the benchmark CSV (360 rows) is
byte-identical, synthesis identical except the `initial` row (69 565 → 69 554 cells: the width-only `plan` edit that revision 1 had disclosed as post-dating its synthesis run).

**RTL**

* `sf_stream_dma_cpl.sv`: **bug fix** — `cpl_partial` was registered one cycle behind the completion record, so a record accepted in its first cycle carried a stale flag (every aborted or faulted transfer that had already moved bytes reported `partial = 0`).
  It is now a combinational function of the record, as documented (`partial = bytes_done != 0 && status != OK`). No other RTL of the DMA core changed; all benchmark cycle counts are identical (the 360-row benchmark CSV is byte-identical to revision 1). Synthesis totals moved by ≈ 0.2 % and the 256-bit gate-depth indicator by ±8 levels; an experiment shows this is mapper noise, not the change (docs/07).
* new `sf_stream_dma_mm_bridge.sv`: AXI4-style memory port → MemoryMatrix (P101) master ports; fail-closed; `prot.secure` from the trusted domain.

**Verification**

* The completion-record flag was previously checked by nothing (the C++ bench never read `cpl_partial`, the formal harness had no property for it). Now: checked on **every accepted record** by both benches, by a new property in `fv_cpl.sv` (proved; the old implementation is caught as a counterexample), and by two new mutants (`cpl-partial-registered` in the simulation list, a matching formal-sensitivity entry).
* new MemoryMatrix integration: system bench (`tests/stream_dma/mm/`), adversarial bridge unit test, 28-mutant bridge mutation run (baseline-gated), vendored matrix with provenance, lint of the bridge and negative tests, synthesis of the bridge.
* `scripts/check_vendor.py` can now compare every vendored file with the repository archive member it was copied from (`--repo`).

**Documentation / audit**

* docs/00: **MemoryMatrix does exist** (revision 1 said it did not) and is now integrated; SRAMController's role is superseded by the matrix; the `MANIFEST.sha256` name was wrong (`MANIFEST.tsv`).
* new docs/10 (integration), `benchmarks/stream_dma/REPORT_MM.md` (measured stalls against the real matrix: 1 → 2 outstanding bursts +38 %, destination placement removes all bank conflicts, matrix queue depth does not matter), updates to docs/03, 04, 05, 06, 07, 08, 09.

**Deliberately not done**: transaction overlap (largest remaining throughput lever; risks and prerequisites in docs/08), formal verification of the bridge, AXI4→SFB2 adapter, any FPGA/ASIC run.
