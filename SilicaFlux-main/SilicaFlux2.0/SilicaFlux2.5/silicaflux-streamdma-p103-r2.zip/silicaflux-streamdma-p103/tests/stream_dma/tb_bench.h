// =============================================================================
// StreamDMA benchmark mode:  tb_<cfg> <seed> bench
// Runs standard workloads against the slave model, swept over memory latency and backpressure, and prints one CSV row per
// (workload, condition) from the DUT's own performance counters.  Every run is also checked byte-for-byte against the reference
// model, so a throughput number is never reported for a transfer that was wrong.  All numbers are SIMULATION cycles.
// =============================================================================
#pragma once
#include "tb_ref.h"

static std::vector<Desc> bw_stream(u64 bytes, u64 so, u64 dof) {
  Desc d; d.st = 0; d.dt = 1; d.src = IB(0) + so; d.dst = IB(1) + (256u << 10) + dof; d.len = bytes; d.flags = F_FIRST | F_LAST | F_CPL; d.txn = 1; d.dom = d.trusted = 1; return {d};
}
static std::vector<Desc> bw_sg(int nseg, u64 seglen, u16 id) {
  std::vector<Desc> v;
  for (int i = 0; i < nseg; i++) {
    Desc d; d.st = 0; d.dt = 1; d.src = IB(0) + (u64)i * (seglen + 4096) % (250u << 10); d.dst = IB(1) + (256u << 10) + (u64)i * seglen % (250u << 10); d.len = seglen;
    d.flags = (i == 0 ? F_FIRST | F_CPL : 0) | (i == nseg - 1 ? F_LAST : 0); d.txn = id; d.dom = d.trusted = 1; v.push_back(d);
  }
  return v;
}
static std::vector<Desc> bw_small(int ntxn, u64 len) {
  std::vector<Desc> v;
  for (int i = 0; i < ntxn; i++) {
    Desc d; d.st = 0; d.dt = 1; d.src = IB(0) + (u64)i * 4096 % (250u << 10); d.dst = IB(1) + (256u << 10) + (u64)i * 4096 % (250u << 10); d.len = len;
    d.flags = F_FIRST | F_LAST | F_CPL; d.txn = (u16)(i + 1); d.dom = d.trusted = 1; v.push_back(d);
  }
  return v;
}

static void run_bench(Sim& s, Ref& ref, const char* cfgname) {
  struct W { const char* name; std::function<std::vector<Desc>()> mk; };
  std::vector<W> wl = {
    {"stream_128KiB_aligned",   [] { return bw_stream(128 << 10, 0, 0); }},
    {"stream_128KiB_unaligned", [] { return bw_stream(128 << 10, 3, 5); }},
    {"sg_32x2KiB",              [] { return bw_sg(32, 2048, 1); }},
    {"sg_64x256B",              [] { return bw_sg(64, 256, 1); }},
    {"txn_x32_4KiB",            [] { return bw_small(32, 4096); }},
    {"txn_x64_64B",             [] { return bw_small(64, 64); }},
  };
  struct C { const char* name; int lat; int pr; int pw; };
  std::vector<C> cond = {
    {"lat2",  2, 100, 100}, {"lat10", 10, 100, 100}, {"lat30", 30, 100, 100}, {"lat80", 80, 100, 100},
    {"lat10_bp70", 10, 70, 70}, {"lat10_bp40", 10, 40, 40},
  };
  printf("BENCH_HEADER,config,workload,condition,ok,bytes,active_cycles,bw_B_per_cycle,rd_bursts,wr_bursts,rd_beats,wr_beats,burst_util_pct,"
         "rd_stall_ar,rd_stall_buf,rd_stall_out,rd_stall_guard,wr_stall_aw,wr_stall_w,wr_stall_data,wr_stall_wbuf,wr_stall_out,wr_stall_guard,"
         "buf_occ_avg,buf_occ_max,wbuf_occ_avg,wbuf_occ_max,haz_events,txn_done,lat_avg,lat_max\n");
  for (const W& w : wl) for (const C& c : cond) {
    s.cfg = SlaveCfg(); s.cfg.lat_r = c.lat; s.cfg.lat_b = c.lat;
    s.cfg.p_ar_ready = s.cfg.p_aw_ready = s.cfg.p_w_ready = c.pr; s.cfg.p_r_valid = c.pr; s.cfg.p_b_valid = c.pw;
    s.perf_clear_now();
    std::vector<Desc> v = w.mk(); u64 cyc0 = s.cyc; (void)cyc0;
    bool ok = run_stream(s, ref, v);
    u64 act = s.perf(PC_ACTIVE), bw = s.perf(PC_BYTES_WR), cy = s.perf(PC_CYCLES);
    u64 rb = s.perf(PC_RD_BURSTS), wb = s.perf(PC_WR_BURSTS), rbt = s.perf(PC_RD_BEATS), wbt = s.perf(PC_WR_BEATS), td = s.perf(PC_TXN_DONE);
    double util = rb ? 100.0 * (double)rbt / ((double)rb * TB_BL) : 0;
    printf("BENCH,%s,%s,%s,%d,%llu,%llu,%.3f,%llu,%llu,%llu,%llu,%.1f,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%.2f,%llu,%.2f,%llu,%llu,%llu,%.1f,%llu\n",
      cfgname, w.name, c.name, ok ? 1 : 0, (unsigned long long)bw, (unsigned long long)act, act ? (double)bw / (double)act : 0.0,
      (unsigned long long)rb, (unsigned long long)wb, (unsigned long long)rbt, (unsigned long long)wbt, util,
      (unsigned long long)s.perf(PC_RD_STALL_AR), (unsigned long long)s.perf(PC_RD_STALL_BUF), (unsigned long long)s.perf(PC_RD_STALL_OUT), (unsigned long long)s.perf(PC_RD_STALL_GRD),
      (unsigned long long)s.perf(PC_WR_STALL_AW), (unsigned long long)s.perf(PC_WR_STALL_W), (unsigned long long)s.perf(PC_WR_STALL_DATA), (unsigned long long)s.perf(PC_WR_STALL_WBUF),
      (unsigned long long)s.perf(PC_WR_STALL_OUT), (unsigned long long)s.perf(PC_WR_STALL_GRD),
      cy ? (double)s.perf(PC_OCC_SUM) / (double)cy : 0.0, (unsigned long long)s.perf(PC_OCC_MAX), cy ? (double)s.perf(PC_WOCC_SUM) / (double)cy : 0.0, (unsigned long long)s.perf(PC_WOCC_MAX),
      (unsigned long long)s.perf(PC_HAZ_EVENTS), (unsigned long long)td, td ? (double)s.perf(PC_LAT_SUM) / (double)td : 0.0, (unsigned long long)s.perf(PC_LAT_MAX));
    fflush(stdout);
  }
}
