// =============================================================================
// StreamDMA bench -- independent reference model + run/check machinery
// =============================================================================
#pragma once
#include "tb_core.h"

typedef unsigned __int128 u128;

struct Chunk { u64 pa, n; };
struct ExecSeg { int st, dt, dom; std::vector<Chunk> src, dst; u64 len; };
struct RefPlan {
  std::vector<ExpCpl> cpls; std::vector<ExecSeg> segs; bool relaxed = false;
  u64 n_ok = 0, n_rej = 0, n_drop = 0, total_ok_bytes = 0; u32 irq_expected = 0; u32 dom_mask = 0;
};

struct Ref {
  Sim& s; Mem mem[NMT];
  explicit Ref(Sim& sim) : s(sim) {}

  // ---- descriptor validation (spec order, written from docs/02_DESCRIPTOR_ABI.md)
  int check(const Desc& d, bool in_txn, u16 cur_id, u8 cur_dom, u64 ctx_total) const {
    const u128 lim = (u128)1 << TB_AW;
    bool first = d.flags & F_FIRST, cpl = d.flags & F_CPL, irq = d.flags & F_IRQ;
    if (d.ver != 1) return E_VERSION;
    if (d.op != 0) return E_OPCODE;
    if (d.dom != d.trusted) return E_DOMAIN;
    if ((d.flags >> 5) != 0 || (!first && (cpl || irq))) return E_FLAGS;
    if (d.rsvd0 != 0) return E_RSVD;
    if (in_txn ? first : !first) return E_CHAIN_FIRST;
    if (in_txn && d.txn != cur_id) return E_CHAIN_TXN;
    if (in_txn && d.trusted != cur_dom) return E_DOMAIN;
    for (int t : {d.st, d.dt}) if (t >= NMT || !((s.type_en >> t) & 1)) return E_MEMTYPE;
    u64 len = d.len & 0xFFFFFFFFULL;
    if (len == 0) return E_LEN_ZERO;
    if (len > (1ULL << TB_MAXSEG)) return E_LEN_BIG;
    if (ctx_total + len > (1ULL << TB_MAXTXN)) return E_TOTAL_BIG;
    if ((u128)d.src >= lim || (u128)d.dst >= lim) return E_ADDR_RANGE;
    if ((u128)d.src + len > lim || (u128)d.dst + len > lim) return E_ADDR_OVFL;
    if (d.st == d.dt && (u128)d.src < (u128)d.dst + len && (u128)d.dst < (u128)d.src + len) return E_OVERLAP;
    return E_NONE;
  }

  // translate a range page by page (guard contract is per burst, bursts never cross 4 KiB, mappings are 4 KiB multiples)
  bool translate(int dom, int t, u64 a, u64 n, bool wr, std::vector<Chunk>& out, int* fault) const {
    u64 pos = a, left = n;
    while (left) {
      u64 pg_end = (pos | 4095) + 1, c = std::min(left, pg_end - pos);
      u64 pa;
      if (!s.xlate(dom, t, pos, c, wr, &pa)) { s.in_map(dom, t, pos, c, wr, fault); return false; }
      out.push_back({pa, c}); pos += c; left -= c;
    }
    return true;
  }

  RefPlan plan(const std::vector<Desc>& stream) {
    RefPlan p; bool in_txn = false, skip = false; u16 id = 0; u8 dom = 0; u64 total = 0, done = 0; bool cpl_en = false, irq_en = false;
    for (const Desc& d : stream) {
      bool first = d.flags & F_FIRST, last = d.flags & F_LAST;
      p.dom_mask |= 1u << d.trusted;
      if (skip && !first) { p.n_drop++; if (last) skip = false; continue; }
      skip = false;
      int err = check(d, in_txn, id, dom, in_txn ? total : 0);
      if (err) {
        ExpCpl c{}; c.status = ST_ERROR; c.err = err; c.rec = true; c.irq = true;
        if (in_txn) { c.txn = id; c.dom = dom; c.total = total; } else { c.txn = d.txn; c.dom = d.trusted; c.total = 0; done = 0; }
        c.done = in_txn ? done : 0; p.cpls.push_back(c); p.n_rej++;
        in_txn = false; skip = !last; total = 0; done = 0; continue;
      }
      p.n_ok++;
      u64 len = d.len & 0xFFFFFFFFULL;
      if (first) { in_txn = true; id = d.txn; dom = d.trusted; total = 0; done = 0; cpl_en = d.flags & F_CPL; irq_en = d.flags & F_IRQ; }
      total += len;
      ExecSeg e; e.st = d.st; e.dt = d.dt; e.dom = d.trusted; e.len = len;
      int f1 = 0, f2 = 0; bool rd_ok = translate(d.trusted, d.st, d.src, len, false, e.src, &f1), wr_ok = translate(d.trusted, d.dt, d.dst, len, true, e.dst, &f2);
      if (!rd_ok || !wr_ok) {
        ExpCpl c{}; c.txn = id; c.dom = dom; c.status = ST_ERROR; c.rec = true; c.irq = true; c.done = done; c.total = total;
        c.err = !rd_ok ? E_GUARD_RD : E_GUARD_WR; c.detail = !rd_ok ? f1 : f2;
        if (!rd_ok && !wr_ok) c.err_mask_alt = 1ULL << E_GUARD_WR;
        p.cpls.push_back(c); p.relaxed = true; p.n_rej++;           // execution fault: partial effects allowed
        // the failing segment's other side may still be read/written by the DUT: allow its envelopes too
        p.segs.push_back(e);
        in_txn = false; skip = !last; total = 0; done = 0; continue;
      }
      p.segs.push_back(e); done += len;
      p.total_ok_bytes += len;
      if (last) {
        ExpCpl c{}; c.txn = id; c.dom = dom; c.status = ST_OK; c.err = 0; c.done = done; c.total = total; c.rec = cpl_en; c.irq = irq_en;
        p.cpls.push_back(c); in_txn = false; total = 0; done = 0;
      }
    }
    for (const ExpCpl& c : p.cpls) if (c.irq) p.irq_expected++;
    return p;
  }

  // strictly sequential, byte-by-byte execution on the reference memory
  void exec(const RefPlan& p, bool last_partial_exec) {
    for (size_t k = 0; k < p.segs.size(); k++) {
      const ExecSeg& e = p.segs[k];
      if (last_partial_exec && k + 1 == p.segs.size() && p.relaxed) {
        // the failing segment of a faulted plan is not executed in the reference (its effects are only bounded, see check())
        break;
      }
      std::vector<u8> tmp; tmp.reserve(e.len);
      for (const Chunk& c : e.src) for (u64 i = 0; i < c.n; i++) tmp.push_back(mem[e.st].d[c.pa + i]);
      size_t idx = 0;
      for (const Chunk& c : e.dst) for (u64 i = 0; i < c.n; i++) { mem[e.dt].d[c.pa + i] = tmp[idx++]; mem[e.dt].wc[c.pa + i]++; }
    }
  }
};

struct RunOpt { bool no_writes = false; bool relaxed = false; long max_cycles = 0; bool expect_hang = false; bool allow_extra_cpl = false; int dom_check = 1; };

static inline u64 rnd_fill(Sim& s, int t, u64 lo, u64 n) {
  u64 a = lo > 64 ? lo - 64 : 0, b = std::min<u64>(lo + n + 64, PHYS);
  for (u64 i = a; i < b; i++) s.mem[t].d[i] = (u8)s.rng();
  return b - a;
}

struct Baseline { u64 ok0; u64 n_ar, n_aw, n_arb, n_awb; int err; u64 bw, br, rb, wb, rbt, wbt, td, dok, drj, ddr; long c0; };

// Bring both memories into a known random state around every touched range, execute the reference, arm the monitors.
static RefPlan prep_stream(Sim& s, Ref& ref, const std::vector<Desc>& stream, const RunOpt& o, Baseline* b) {
  RefPlan pl = ref.plan(stream);
  for (const ExecSeg& e : pl.segs) {
    for (const Chunk& c : e.src) rnd_fill(s, e.st, c.pa, c.n);
    for (const Chunk& c : e.dst) rnd_fill(s, e.dt, c.pa, c.n);
  }
  for (const ExecSeg& e : pl.segs) {
    for (const Chunk& c : e.src) { u64 a = c.pa > 64 ? c.pa - 64 : 0, bb = std::min<u64>(c.pa + c.n + 64, PHYS); memcpy(&ref.mem[e.st].d[a], &s.mem[e.st].d[a], bb - a); }
    for (const Chunk& c : e.dst) { u64 a = c.pa > 64 ? c.pa - 64 : 0, bb = std::min<u64>(c.pa + c.n + 64, PHYS); memcpy(&ref.mem[e.dt].d[a], &s.mem[e.dt].d[a], bb - a); }
  }
  ref.exec(pl, pl.relaxed);
  for (int t = 0; t < NMT; t++) { s.allow_rd[t].clear(); s.allow_wr[t].clear(); }
  for (const ExecSeg& e : pl.segs) {
    for (const Chunk& c : e.src) s.allow_rd[e.st].push_back({c.pa & ~(u64)(W - 1), (c.pa + c.n + W - 1) & ~(u64)(W - 1)});
    for (const Chunk& c : e.dst) s.allow_wr[e.dt].push_back({c.pa & ~(u64)(W - 1), (c.pa + c.n + W - 1) & ~(u64)(W - 1)});
  }
  s.check_allow = true; s.dom_mask = pl.dom_mask; s.check_dom = o.dom_check;
  s.got.clear(); s.irq_count = 0; s.touched.clear();
  b->ok0 = s.ok_bytes; b->n_ar = s.n_ar; b->n_aw = s.n_aw; b->n_arb = s.n_arb; b->n_awb = s.n_awb; b->err = s.errors; b->c0 = (long)s.cyc;
  b->bw = s.perf(PC_BYTES_WR); b->br = s.perf(PC_BYTES_RD); b->rb = s.perf(PC_RD_BURSTS); b->wb = s.perf(PC_WR_BURSTS);
  b->rbt = s.perf(PC_RD_BEATS); b->wbt = s.perf(PC_WR_BEATS); b->td = s.perf(PC_TXN_DONE); b->dok = s.perf(PC_DESC_OK);
  b->drj = s.perf(PC_DESC_REJ); b->ddr = s.perf(PC_DESC_DROP);
  return pl;
}
static void clear_counts(Sim& s, Ref& ref, const RefPlan& pl) {
  for (auto& tt : s.touched) s.mem[tt.first].wc[tt.second] = 0;
  for (const ExecSeg& e : pl.segs) for (const Chunk& c : e.dst) for (u64 i = 0; i < c.n; i++) ref.mem[e.dt].wc[c.pa + i] = 0;
}
// compare memory + counters + completions.  Returns number of new failures.
static int check_stream(Sim& s, Ref& ref, const RefPlan& pl, const RunOpt& o, const Baseline& b) {
  bool relaxed = o.relaxed || pl.relaxed;
  u64 expect_cpl = 0; for (const ExpCpl& c : pl.cpls) if (c.rec) expect_cpl++;
  if (s.got.size() != expect_cpl) s.fail("completion records: got %zu expected %llu", s.got.size(), (unsigned long long)expect_cpl);
  size_t gi = 0;
  for (size_t i = 0; i < pl.cpls.size(); i++) {
    const ExpCpl& e = pl.cpls[i]; if (!e.rec) continue; if (gi >= s.got.size()) break;
    const ExpCpl& g = s.got[gi++];
    bool err_ok = (g.err == e.err) || (g.err < 64 && ((e.err_mask_alt >> g.err) & 1));
    if (g.txn != e.txn) s.fail("cpl[%zu] txn %u != %u", i, g.txn, e.txn);
    if (g.dom != e.dom) s.fail("cpl[%zu] domain %u != %u", i, g.dom, e.dom);
    if (g.status != e.status) s.fail("cpl[%zu] status %d != %d (err %#x vs %#x)", i, g.status, e.status, g.err, e.err);
    if (!err_ok) s.fail("cpl[%zu] err %#x != %#x", i, g.err, e.err);
    if (e.detail >= 0 && g.detail != e.detail && !e.err_mask_alt) s.fail("cpl[%zu] detail %d != %d", i, g.detail, e.detail);
    if (e.status == ST_OK || !relaxed) {
      if (g.done != e.done) s.fail("cpl[%zu] bytes_done %llu != %llu", i, (unsigned long long)g.done, (unsigned long long)e.done);
      if (g.total != e.total) s.fail("cpl[%zu] bytes_total %llu != %llu", i, (unsigned long long)g.total, (unsigned long long)e.total);
    } else if (g.done > g.total) s.fail("cpl[%zu] bytes_done %llu > bytes_total %llu", i, (unsigned long long)g.done, (unsigned long long)g.total);
  }
  // memory: every expected byte right, nothing written that was not expected, nothing written twice
  for (const ExecSeg& e : pl.segs) for (const Chunk& c : e.dst) for (u64 i = 0; i < c.n; i++) {
    u64 a = c.pa + i;
    if (!relaxed) {
      if (s.mem[e.dt].d[a] != ref.mem[e.dt].d[a]) { s.fail("DATA MISMATCH type %d pa %llx: got %02x expected %02x", e.dt, (unsigned long long)a, s.mem[e.dt].d[a], ref.mem[e.dt].d[a]); break; }
      if (s.mem[e.dt].wc[a] != ref.mem[e.dt].wc[a]) { s.fail("WRITE COUNT type %d pa %llx: wrote %u times, expected %u (lost/duplicated byte)", e.dt, (unsigned long long)a, s.mem[e.dt].wc[a], ref.mem[e.dt].wc[a]); break; }
    }
  }
  for (auto& tt : s.touched) {
    u8 t = tt.first; u32 a = tt.second;
    if (!relaxed) { if (s.mem[t].wc[a] > ref.mem[t].wc[a]) { s.fail("STRAY/DUPLICATE WRITE type %d pa %x: %u writes, expected %u", t, a, s.mem[t].wc[a], ref.mem[t].wc[a]); break; } }
    else {
      bool in = false; for (const ExecSeg& e : pl.segs) if (e.dt == t) for (const Chunk& c : e.dst) if (a >= c.pa && a < c.pa + c.n) in = true;
      if (!in) { s.fail("STRAY WRITE (faulted run) type %d pa %x", t, a); break; }
      if (s.mem[t].wc[a] > 1) { /* faulted runs use non-overlapping segments */ s.fail("DUPLICATE WRITE (faulted run) type %d pa %x", t, a); break; }
    }
  }
  if (relaxed) for (const ExecSeg& e : pl.segs) for (const Chunk& c : e.dst) for (u64 i = 0; i < c.n; i++) {
    u64 a = c.pa + i;      // a byte that was written holds the value the reference computed (written bytes are never garbage)
    if (s.mem[e.dt].wc[a] > 0 && ref.mem[e.dt].wc[a] > 0 && s.mem[e.dt].d[a] != ref.mem[e.dt].d[a]) { s.fail("DATA MISMATCH (faulted run) type %d pa %llx", e.dt, (unsigned long long)a); break; }
  }
  if (o.no_writes && !s.touched.empty()) s.fail("a refused/faulted transaction wrote %zu bytes", s.touched.size());
  // COMPLETION CONTRACT, checked against the bus itself: the bytes the DUT reports as done are exactly the payload bytes of the
  // write bursts the memory answered OKAY (checked when every transaction of the run produced a record; timeouts excepted: their response may never come)
  { u64 sum = 0; bool any_to = false; for (const ExpCpl& g : s.got) { sum += g.done; if (g.status == ST_TIMEOUT) any_to = true; }
    if (!any_to && s.got.size() == pl.cpls.size() && sum != s.ok_bytes - b.ok0) s.fail("COMPLETION CONTRACT: reported bytes_done %llu != %llu bytes acknowledged OKAY on the bus", (unsigned long long)sum, (unsigned long long)(s.ok_bytes - b.ok0)); }
  // performance counters vs the independent bus monitor and the plan
  if (s.perf(PC_RD_BURSTS) - b.rb != s.n_ar - b.n_ar) s.fail("perf RD_BURSTS %llu != bus %llu", (unsigned long long)(s.perf(PC_RD_BURSTS) - b.rb), (unsigned long long)(s.n_ar - b.n_ar));
  if (s.perf(PC_WR_BURSTS) - b.wb != s.n_aw - b.n_aw) s.fail("perf WR_BURSTS %llu != bus %llu", (unsigned long long)(s.perf(PC_WR_BURSTS) - b.wb), (unsigned long long)(s.n_aw - b.n_aw));
  if (s.perf(PC_RD_BEATS) - b.rbt != s.n_arb - b.n_arb) s.fail("perf RD_BEATS mismatch");
  if (s.perf(PC_WR_BEATS) - b.wbt != s.n_awb - b.n_awb) s.fail("perf WR_BEATS mismatch");
  if (!relaxed) {
    u64 dw = s.perf(PC_BYTES_WR) - b.bw;
    if (dw != pl.total_ok_bytes) s.fail("perf BYTES_WR %llu != %llu", (unsigned long long)dw, (unsigned long long)pl.total_ok_bytes);
    if (s.perf(PC_BYTES_RD) - b.br != pl.total_ok_bytes) s.fail("perf BYTES_RD %llu != %llu", (unsigned long long)(s.perf(PC_BYTES_RD) - b.br), (unsigned long long)pl.total_ok_bytes);
    if (s.perf(PC_TXN_DONE) - b.td != pl.cpls.size()) s.fail("perf TXN_DONE %llu != %zu", (unsigned long long)(s.perf(PC_TXN_DONE) - b.td), pl.cpls.size());
    if (s.perf(PC_DESC_OK) - b.dok != pl.n_ok) s.fail("perf DESC_OK %llu != %llu", (unsigned long long)(s.perf(PC_DESC_OK) - b.dok), (unsigned long long)pl.n_ok);
    if (s.perf(PC_DESC_DROP) - b.ddr != pl.n_drop) s.fail("perf DESC_DROP %llu != %llu", (unsigned long long)(s.perf(PC_DESC_DROP) - b.ddr), (unsigned long long)pl.n_drop);
    if ((u32)s.irq_count != pl.irq_expected) s.fail("irq pulses %d != %u", s.irq_count, pl.irq_expected);
  }
  return s.errors - b.err;
}

// RunOpt::patch lets a test turn the reference expectation into the fault it injected on the bus
typedef std::function<void(RefPlan&)> Patch;

static bool run_stream(Sim& s, Ref& ref, const std::vector<Desc>& stream, RunOpt o = RunOpt(), Patch patch = nullptr, RefPlan* out_plan = nullptr) {
  Baseline b; RefPlan pl = prep_stream(s, ref, stream, o, &b);
  if (patch) patch(pl);
  u64 expect_cpl = 0; for (const ExpCpl& c : pl.cpls) if (c.rec) expect_cpl++;
  for (const Desc& d : stream) s.push_q.push_back(d);
  u64 tot = 0; for (const Desc& d : stream) tot += d.len & 0xFFFFFFFFULL;
  long maxc = o.max_cycles ? o.max_cycles : 6000 + (long)tot * 14 + (long)stream.size() * 800;
  while (((long)s.cyc - b.c0) < maxc) {
    s.cycle();
    if (s.quiescent() && s.got.size() >= expect_cpl && (s.perf(PC_TXN_DONE) - b.td) >= pl.cpls.size()) break;
  }
  s.cycles(24);                                    // settle: nothing may happen after completion
  if (!s.quiescent()) s.fail("run did not reach quiescence in %ld cycles (got %zu/%llu completions, busy=%d)", maxc, s.got.size(), (unsigned long long)expect_cpl, (int)s.d->busy);
  int nf = check_stream(s, ref, pl, o, b);
  clear_counts(s, ref, pl);
  s.check_allow = false;
  if (out_plan) *out_plan = pl;
  return nf == 0;
}
