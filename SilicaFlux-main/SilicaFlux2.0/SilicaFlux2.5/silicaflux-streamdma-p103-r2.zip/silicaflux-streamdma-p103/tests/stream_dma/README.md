# tests/stream_dma — Verilator system bench

```
bash scripts/build_tb.sh <config>            # configs: tests/stream_dma/configs.sh  (initial par4 small dw64 dw256 dw32 dw512 + benchmark configs)
build/tb_<config>/tb_<config> [seed] [test|all|bench] [random-runs] [+verilator+rand+reset+2 +verilator+seed+N]
TB_TRACE=1 ...   print every AR / AW / R / B / completion handshake
TB_FAILFAST=1 .. exit at the first failing run (used by the mutation harness)
```
Files: `tb_top.sv` (DUT + vendored permission table as MemoryGuard model), `tb_core.h` (AXI slave model, monitors), `tb_ref.h` (independent reference model, run/check),
`tb_main.cpp` (tests), `tb_bench.h` (benchmark mode). See docs/05_VERIFICATION.md.

## MemoryMatrix integration (tests/stream_dma/mm/)

```
bash scripts/run_bridge_unit.sh                 # adversarial-master unit test of the bridge against the real matrix (Verilator --binary --timing)
bash scripts/build_mm_tb.sh <cfg> && build/tb_<cfg>/tb_<cfg> [seed] [all|test[,test..]|bench] [random-runs]     # configs: tests/stream_dma/mm/mm_configs.sh
python3 scripts/run_mm.py                       # all configs x 5 seeds -> reports/integration_mm.md
python3 scripts/mutate_mm.py                    # bridge mutation test  -> reports/mutation_mm.md
TB_FAILFAST=1 stops at the first failure; TB_DEBUG=1 prints every completion record with the bus counters.
```
Files: `tb_mm_top.sv` (DMA + MemoryGuard model + bridge + MemoryMatrix; host and noise masters), `tb_mm_main.cpp` (self-contained bench and reference model), `tb_bridge_unit.sv` (adversarial AXI master), `mm_configs.sh`. See docs/10.
