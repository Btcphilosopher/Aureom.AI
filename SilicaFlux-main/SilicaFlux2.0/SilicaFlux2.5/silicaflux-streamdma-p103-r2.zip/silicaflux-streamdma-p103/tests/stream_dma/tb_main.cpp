// =============================================================================
// StreamDMA verification bench -- tests and driver.   usage: tb_<cfg> [seed] [test-filter] [rand-runs]
// =============================================================================
#include "tb_ref.h"
#include "tb_bench.h"
#include <map>

struct T {
  Sim& s; Ref& ref; int runs = 0, failed = 0; std::string cur; std::map<std::string, std::pair<int,int>> per;
  T(Sim& a, Ref& b) : s(a), ref(b) {}
  bool run(const std::vector<Desc>& st, RunOpt o = RunOpt(), Patch p = nullptr) {
    bool ok = run_stream(s, ref, st, o, p); runs++; per[cur].first++;
    if (!ok) { failed++; per[cur].second++; if (failed <= 5) printf("  ^ in test '%s' run #%d\n", cur.c_str(), runs); if (getenv("TB_FAILFAST")) { printf("RESULT: FAIL (fail-fast)\n"); exit(1); } }
    return ok;
  }
};

// ----------------------------------------------------------------------------- descriptor builders
static Desc mk(int st, u64 soff, int dt, u64 doff, u64 len, u16 flags, u16 txn, u8 dom = 1) {
  Desc d; d.st = st; d.dt = dt; d.src = IB(st) + soff; d.dst = IB(dt) + doff; d.len = len; d.flags = flags; d.txn = txn; d.dom = dom; d.trusted = dom; return d;
}
static const u64 SRC0 = 0, DST0 = 256u << 10;                // source zone [0,256K), destination zone [256K,512K) of each window
static std::vector<Desc> one(int st, u64 so, int dt, u64 dof, u64 len, u16 txn = 1, u16 extra = F_CPL, u8 dom = 1) {
  return { mk(st, SRC0 + so, dt, DST0 + dof, len, F_FIRST | F_LAST | extra, txn, dom) };
}
static u16 TXN = 1; static u16 nt() { return TXN++; }

// ============================================================================= tests
static void t_single_byte(T& t) {
  t.cur = "single_byte";
  for (int so = 0; so < W; so++) for (int dof = 0; dof < W; dof += (W > 16 ? 5 : 1)) t.run(one(0, so, 1, dof, 1, nt()));
  for (int a = 0; a < NMT; a++) for (int b = 0; b < NMT; b++) t.run(one(a, 3, b, 7, 1, nt()));
  t.run(one(0, W - 1, 0, W - 1, 1, nt()));                      // last lane -> last lane, same type
  t.run(one(0, 4095, 0, 4095, 1, nt()));                        // last byte of a 4 KiB page
}
static void t_full_width(T& t) {
  t.cur = "full_width";
  for (int n : {1, 2, TB_BL - 1, TB_BL, TB_BL + 1, 2 * TB_BL, 3 * TB_BL + 5}) {
    t.run(one(0, 0, 1, 0, (u64)n * W, nt()));
    t.run(one(1, 0, 4, 0, (u64)n * W, nt()));
  }
  t.run(one(0, W, 0, 2 * W, W, nt()));
}
static void t_large(T& t) {
  t.cur = "large";
  for (u64 n : {4096ull, 4097ull, 8192ull, 65536ull + 13, 100000ull, 250000ull}) {
    t.run(one(0, 0, 1, 0, n, nt()));
    t.run(one(1, 5, 2, 11, n, nt()));
  }
  t.run(one(0, 4000, 4, 4090, 20000, nt()));                    // starts just below a 4 KiB boundary on both sides
  t.run(one(0, 4096 - W, 0, 4096 - 1, 3 * 4096 + 7, nt()));
}
static void t_unaligned(T& t, int budget) {
  t.cur = "unaligned";
  std::vector<u64> lens = {1, 2, 3, (u64)W - 1, (u64)W, (u64)W + 1, 2 * (u64)W - 1, 2 * (u64)W + 3, (u64)TB_BL * W - 1, (u64)TB_BL * W, (u64)TB_BL * W + 1, (u64)TB_BL * W + (u64)W - 1};
  int n = 0;
  std::vector<std::tuple<int,int,u64>> all;
  for (int so = 0; so < W; so++) for (int dof = 0; dof < W; dof++) for (u64 l : lens) all.push_back({so, dof, l});
  std::shuffle(all.begin(), all.end(), t.s.rng);
  for (auto& x : all) { if (n++ >= budget) break; t.run(one(0, std::get<0>(x), 1, std::get<1>(x), std::get<2>(x), nt())); }
}
static void t_sg(T& t) {
  t.cur = "scatter_gather";
  auto& r = t.s.rng;
  for (int k = 0; k < 12; k++) {
    int n = 2 + r() % 7; std::vector<Desc> v; u64 so = 0, dof = 0; u16 id = nt();
    int mode = k % 3;                                              // 0 gather (many src -> contiguous dst), 1 scatter, 2 both noncontiguous
    for (int i = 0; i < n; i++) {
      u64 len = 1 + r() % (3 * TB_BL * W); u16 fl = (i == 0 ? F_FIRST | F_CPL : 0) | (i == n - 1 ? F_LAST : 0);
      u64 s_off = (mode == 1) ? so : (u64)(i * 20000 + r() % 4000), d_off = (mode == 0) ? dof : (u64)(i * 20000 + 3000 + r() % 4000);
      if (mode == 0) dof += len; if (mode == 1) so += len;
      v.push_back(mk(0, SRC0 + s_off, 1, DST0 + d_off, len, fl, id));
    }
    t.run(v);
  }
  // 64 one-byte segments gathered into a contiguous buffer
  std::vector<Desc> v; u16 id = nt();
  for (int i = 0; i < 64; i++) v.push_back(mk(0, SRC0 + i * 37 + 5, 1, DST0 + i, 1, (i == 0 ? F_FIRST | F_CPL : 0) | (i == 63 ? F_LAST : 0), id));
  t.run(v);
  // segment boundaries land mid-beat and exactly on beat / burst boundaries
  v.clear(); id = nt();
  u64 lens[] = {(u64)W, (u64)W - 3, 5, (u64)TB_BL * W, 1, (u64)TB_BL * W + 1, (u64)W};
  u64 so = 0, dof = 0; int n = 7;
  for (int i = 0; i < n; i++) { v.push_back(mk(0, SRC0 + so, 2, DST0 + dof, lens[i], (i == 0 ? F_FIRST | F_CPL : 0) | (i == n - 1 ? F_LAST : 0), id)); so += lens[i] + 11; dof += lens[i]; }
  t.run(v);
}
static void t_multi(T& t) {
  t.cur = "multi_txn";
  std::vector<Desc> v;
  for (int i = 0; i < 24; i++) { auto o = one(i % NMT, (u64)i * 301, (i + 1) % NMT, (u64)i * 97, 1 + (u64)(t.s.rng() % 700), nt(), (i & 1) ? F_CPL : (F_CPL | F_IRQ)); v.insert(v.end(), o.begin(), o.end()); }
  t.run(v);
  v.clear();
  for (int i = 0; i < 6; i++) {            // multi-descriptor transactions back to back
    u16 id = nt(); int n = 1 + i % 4;
    for (int j = 0; j < n; j++) v.push_back(mk(0, SRC0 + (u64)j * 5000 + i * 9, 1, DST0 + (u64)j * 5000 + i * 3, 100 + t.s.rng() % 900, (j == 0 ? F_FIRST | F_CPL : 0) | (j == n - 1 ? F_LAST : 0), id));
  }
  t.run(v);
}


// ----------------------------------------------------------------------------- random stream generator
static std::vector<Desc> rand_stream(Sim& s, int ntxn, bool hazards = true, bool allow_cpl_off = true, int maxlen_class = 3) {
  auto& r = s.rng; std::vector<Desc> v;
  for (int k = 0; k < ntxn; k++) {
    u16 id = nt(); int n = 1 + r() % 5; u8 dom = 1 + r() % 2; u16 f0 = F_FIRST | ((allow_cpl_off && r() % 4 == 0) ? 0 : F_CPL) | ((r() % 4 == 0) ? F_IRQ : 0);
    int pst = -1; u64 pdst = 0, plen = 0;
    for (int i = 0; i < n; i++) {
      int st = r() % NMT, dt = r() % NMT; u64 len; int c = r() % 10;
      if (c < 3) len = 1 + r() % (W + 3); else if (c < 6) len = 1 + r() % (2 * TB_BL * W); else if (c < 9 || maxlen_class < 3) len = 1 + r() % 6000; else len = 1 + r() % 40000;
      u64 so = r() % ((256u << 10) - len), dof = r() % ((256u << 10) - len);
      u16 fl = (i == 0 ? f0 : 0) | (i == n - 1 ? F_LAST : 0) | ((r() % 12 == 0) ? F_FENCE : 0);
      if (hazards && i > 0) {
        int h = r() % 10;
        if (h == 0) { st = pst; so = pdst + (r() % plen); if (so + len > (512u << 10)) so = (512u << 10) - len; so += 0; }          // RAW: read what the previous segment wrote
        else if (h == 1) { dt = pst == -1 ? dt : dt; dof = pdst + (r() % plen) - (256u << 10); if (dof + len > (256u << 10)) dof = (256u << 10) - len; }   // WAW overlap
      }
      Desc d = mk(st, so, dt, DST0 + dof, len, fl, id, dom);
      v.push_back(d); pst = dt; pdst = DST0 + dof; plen = len;
    }
  }
  return v;
}
static std::vector<Desc> disjoint_stream(Sim& s, int ntxn) {            // destinations never overlap each other: exact byte checks are valid
  auto& r = s.rng; std::vector<Desc> v; u64 dpos = 0, spos = 0;
  for (int k = 0; k < ntxn; k++) {
    u16 id = nt(); int n = 1 + r() % 3;
    for (int i = 0; i < n; i++) {
      u64 len = 1 + r() % 9000; int st = r() % NMT, dt = r() % NMT;
      if (dpos + len + 64 > (250u << 10)) dpos = 0; if (spos + len + 64 > (250u << 10)) spos = 0;
      v.push_back(mk(st, spos + (r() % 7), dt, DST0 + dpos + (r() % 5), len, (i == 0 ? F_FIRST | F_CPL : 0) | (i == n - 1 ? F_LAST : 0), id));
      dpos += len + 64; spos += len + 64;
    }
  }
  return v;
}
static void rand_slave(Sim& s) {
  auto& r = s.rng; SlaveCfg& c = s.cfg;
  c.p_ar_ready = 20 + r() % 81; c.p_aw_ready = 20 + r() % 81; c.p_w_ready = 20 + r() % 81; c.p_r_valid = 20 + r() % 81; c.p_b_valid = 20 + r() % 81;
  c.lat_r = r() % 30; c.jit_r = r() % 20; c.lat_b = r() % 30; c.jit_b = r() % 20;
  c.rd_order = r() % 3; c.wr_order = r() % 2; c.aw_waits_w = (r() % 4 == 0); c.p_desc = 30 + r() % 71; c.p_cpl = 30 + r() % 71;
}
static void ideal_slave(Sim& s) { s.cfg = SlaveCfg(); }

static void t_backpressure(T& t) {
  t.cur = "backpressure";
  struct P { int ar, aw, w, r, b, lr, lb, dsc, cpl; } prof[] = {
    {50,50,50,50,50, 3, 3, 100, 100}, {20,20,20,30,30, 12, 20, 50, 40}, {100,100,10,100,100, 2, 2, 100, 100}, {10,100,100,100,10, 30, 30, 100, 100},
    {100,100,100,15,100, 5, 5, 20, 100}, {70,70,70,70,70, 0, 0, 100, 10}};
  for (auto& p : prof) {
    ideal_slave(t.s); SlaveCfg& c = t.s.cfg;
    c.p_ar_ready = p.ar; c.p_aw_ready = p.aw; c.p_w_ready = p.w; c.p_r_valid = p.r; c.p_b_valid = p.b; c.lat_r = p.lr; c.lat_b = p.lb; c.p_desc = p.dsc; c.p_cpl = p.cpl; c.jit_r = 7; c.jit_b = 7;
    t.run(one(0, 3, 1, 5, 5000, nt())); t.run(one(0, 0, 1, 0, 1, nt())); t.run(rand_stream(t.s, 4));
  }
  ideal_slave(t.s);
}
static void t_aw_waits_w(T& t) {
  t.cur = "aw_waits_for_w";
  ideal_slave(t.s); t.s.cfg.aw_waits_w = true;
  t.run(one(0, 1, 1, 2, 3000, nt())); t.run(rand_stream(t.s, 4));
  t.s.cfg.p_w_ready = 30; t.run(rand_stream(t.s, 4)); ideal_slave(t.s);
}
static void t_reorder(T& t) {
  t.cur = "reorder_interleave";
  for (int ro = 0; ro < 3; ro++) for (int wo = 0; wo < 2; wo++) {
    ideal_slave(t.s); SlaveCfg& c = t.s.cfg; c.rd_order = ro; c.wr_order = wo; c.lat_r = 8; c.jit_r = 25; c.lat_b = 6; c.jit_b = 30;
    t.run(one(0, 3, 1, 5, 20000, nt())); t.run(rand_stream(t.s, 4));
    c.p_r_valid = 40; c.p_b_valid = 40; t.run(rand_stream(t.s, 3));
  }
  ideal_slave(t.s);
}

static Patch bus_fault(int err) {
  return [err](RefPlan& p) { p.relaxed = true; if (!p.cpls.empty()) { p.cpls[0].status = ST_ERROR; p.cpls[0].err = err; p.cpls[0].irq = true; p.cpls[0].rec = true; p.cpls[0].detail = -1; } p.irq_expected = 1; };
}
static void t_faults(T& t) {
  t.cur = "memory_faults";
  ideal_slave(t.s);
  struct Pos { const char* n; u64 pa; };
  u64 L = 3 * (u64)TB_BL * W + 17;
  for (int resp : {2, 3}) for (int beat : {-1, 0}) for (u64 pa : {(u64)0, (u64)TB_BL * W + 5, 2 * (u64)TB_BL * W + 9, L - 1}) {
    // read fault: type 0 PA window [pa, pa+1) inside the source of domain 1
    t.s.faults.clear(); t.s.faults.push_back({0, pa, pa + 1, false, resp, beat});
    t.run(one(0, 0, 1, 0, L, nt()), RunOpt(), bus_fault(E_BUS_RD));
    // write fault in the destination (type 1, domain 1, dst zone starts at PA 256K)
    t.s.faults.clear(); t.s.faults.push_back({1, DST0 + pa, DST0 + pa + 1, true, resp, beat});
    t.run(one(0, 0, 1, 0, L, nt()), RunOpt(), bus_fault(E_BUS_WR));
    t.s.faults.clear();
    t.run(one(0, 7, 1, 9, 2000, nt()));                              // the engine recovered: the next transaction is clean
  }
  // a fault in the third segment of a chain, then a clean transaction
  {
    std::vector<Desc> v; u16 id = nt();
    for (int i = 0; i < 4; i++) v.push_back(mk(0, i * 9000, 1, DST0 + i * 9000, 4000, (i == 0 ? F_FIRST | F_CPL : 0) | (i == 3 ? F_LAST : 0), id));
    t.s.faults.push_back({0, 2 * 9000 + 100, 2 * 9000 + 101, false, 2, -1});
    t.run(v, RunOpt(), bus_fault(E_BUS_RD)); t.s.faults.clear(); t.run(rand_stream(t.s, 2, false));
  }
  // slave decode error: access beyond the physical memory (type 4 window is mapped to PA 0..512K, so shrink via fault range instead)
  t.s.faults.clear();
}

static void expect_err(T& t, const std::vector<Desc>& v, int code, const char* what) {
  RefPlan p = t.ref.plan(v);
  if (p.cpls.empty() || p.cpls[0].err != code) { t.s.fail("reference model disagrees with the hand-written expectation for '%s' (ref err %d, hand %d)", what, p.cpls.empty() ? -1 : p.cpls[0].err, code); t.failed++; }
}
static void t_invalid(T& t) {
  t.cur = "invalid_descriptors";
  ideal_slave(t.s);
  struct C { const char* n; std::function<void(Desc&)> f; int code; };
  Desc base = one(0, 0, 1, 0, 100, 0)[0];
  std::vector<C> cs = {
    {"version 0", [](Desc& d) { d.ver = 0; }, E_VERSION}, {"version 2", [](Desc& d) { d.ver = 2; }, E_VERSION},
    {"opcode 1", [](Desc& d) { d.op = 1; }, E_OPCODE}, {"opcode 255", [](Desc& d) { d.op = 255; }, E_OPCODE},
    {"domain claim != trusted", [](Desc& d) { d.dom = 2; }, E_DOMAIN}, {"domain claim 0", [](Desc& d) { d.dom = 0; }, E_DOMAIN},
    {"domain claim high bits", [](Desc& d) { d.dom = 0x1001; }, E_DOMAIN},
    {"reserved flag bit 5", [](Desc& d) { d.flags |= 1 << 5; }, E_FLAGS}, {"reserved flag bit 15", [](Desc& d) { d.flags |= 1 << 15; }, E_FLAGS},
    {"reserved word2 bits", [](Desc& d) { d.rsvd0 = 1; }, E_RSVD}, {"reserved word2 bit 23", [](Desc& d) { d.rsvd0 = 1u << 23; }, E_RSVD},
    {"no FIRST outside txn", [](Desc& d) { d.flags &= ~(F_FIRST | F_CPL); }, E_CHAIN_FIRST},
    {"CPL_EN without FIRST", [](Desc& d) { d.flags &= ~F_FIRST; }, E_FLAGS},
    {"src type 5", [](Desc& d) { d.st = 5; }, E_MEMTYPE}, {"dst type 15", [](Desc& d) { d.dt = 15; }, E_MEMTYPE},
    {"length 0", [](Desc& d) { d.len = 0; }, E_LEN_ZERO}, {"length 2^seg + 1", [](Desc& d) { d.len = (1ull << TB_MAXSEG) + 1; }, E_LEN_BIG},
    {"length 0xFFFFFFFF", [](Desc& d) { d.len = 0xFFFFFFFFull; }, E_LEN_BIG},
    {"src >= 2^AW", [](Desc& d) { d.src = 1ull << TB_AW; }, E_ADDR_RANGE}, {"dst >= 2^AW", [](Desc& d) { d.dst = 1ull << TB_AW; }, E_ADDR_RANGE},
    {"src wraps 64 bit", [](Desc& d) { d.src = ~0ull - 7; d.len = 64; }, E_ADDR_RANGE},
    {"src + len overflows 2^AW", [](Desc& d) { d.src = (1ull << TB_AW) - 8; d.len = 16; }, E_ADDR_OVFL},
    {"dst + len overflows 2^AW", [](Desc& d) { d.dst = (1ull << TB_AW) - 1; d.len = 2; }, E_ADDR_OVFL},
    {"overlap dst = src + 1", [](Desc& d) { d.st = d.dt = 0; d.src = IB(0) + 1000; d.dst = IB(0) + 1001; d.len = 100; }, E_OVERLAP},
    {"overlap dst = src - 1", [](Desc& d) { d.st = d.dt = 0; d.src = IB(0) + 1001; d.dst = IB(0) + 1000; d.len = 100; }, E_OVERLAP},
    {"overlap identical", [](Desc& d) { d.st = d.dt = 2; d.src = d.dst = IB(2) + 4096; d.len = 64; }, E_OVERLAP},
    {"overlap by one byte", [](Desc& d) { d.st = d.dt = 0; d.src = IB(0) + 1000; d.dst = IB(0) + 1099; d.len = 100; }, E_OVERLAP},
  };
  for (auto& c : cs) {
    Desc d = base; d.txn = nt(); c.f(d);
    std::vector<Desc> v = {d}; expect_err(t, v, c.code, c.n); t.run(v);
  }
  // legal boundary cases that must be ACCEPTED
  t.cur = "descriptor_boundaries";
  { Desc d = base; d.txn = nt(); d.st = d.dt = 0; d.src = IB(0) + 1000; d.dst = IB(0) + 1100; d.len = 100; t.run({d}); }              // adjacent, no overlap
  { Desc d = base; d.txn = nt(); d.st = d.dt = 0; d.src = IB(0) + 1100; d.dst = IB(0) + 1000; d.len = 100; t.run({d}); }
  { Desc d = base; d.txn = nt(); d.st = 0; d.dt = 1; d.src = IB(0) + 1000; d.dst = IB(1) + 1000; d.len = 100; t.run({d}); }          // same offsets, different memory types
  if (TB_MAXSEG <= 17) { Desc d = base; d.txn = nt(); d.len = 1ull << TB_MAXSEG; t.run({d}); }                                         // exactly the maximum
  { Desc d = base; d.txn = nt(); d.flags |= F_IRQ; t.run({d}); }
  // exact top of the address space: end == 2^AW is legal (then refused by the guard: unmapped), end == 2^AW + 1 is an overflow
  { Desc d = base; d.txn = nt(); d.src = (1ull << TB_AW) - 64; d.len = 64; expect_err(t, {d}, E_GUARD_RD, "src ends exactly at 2^AW"); t.run({d}); }
  { Desc d = base; d.txn = nt(); d.dst = (1ull << TB_AW) - 64; d.len = 64; expect_err(t, {d}, E_GUARD_WR, "dst ends exactly at 2^AW"); t.run({d}); }
  { Desc d = base; d.txn = nt(); d.src = (1ull << TB_AW) - 1; d.len = 1; expect_err(t, {d}, E_GUARD_RD, "last byte of the address space"); t.run({d}); }
  { Desc d = base; d.txn = nt(); d.src = (1ull << TB_AW) - 63; d.len = 64; expect_err(t, {d}, E_ADDR_OVFL, "src overruns 2^AW by one byte"); t.run({d}); }
  { Desc d = base; d.txn = nt(); d.dst = (1ull << TB_AW) - 1; d.len = 1; d.flags = F_FIRST | F_LAST; expect_err(t, {d}, E_GUARD_WR, "dst is the last byte, no completion record"); t.run({d}); }
  // structural errors inside a transaction
  t.cur = "invalid_chains";
  auto chain = [&](int n, u16 id) { std::vector<Desc> v; for (int i = 0; i < n; i++) v.push_back(mk(0, i * 3000, 1, DST0 + i * 3000, 500 + i * 7, (i == 0 ? F_FIRST | F_CPL : 0) | (i == n - 1 ? F_LAST : 0), id)); return v; };
  for (int bad = 0; bad < 4; bad++) {                                  // an invalid descriptor at every position of a 4-segment chain
    std::vector<Desc> v = chain(4, nt()); v[bad].ver = 9;
    expect_err(t, v, E_VERSION, "bad version in chain"); v.push_back(chain(1, nt())[0]); t.run(v);   // prefix executes, rest is skipped, next transaction runs
  }
  { std::vector<Desc> v = chain(3, nt()); v[1].txn += 1; expect_err(t, v, E_CHAIN_TXN, "txn id changes"); t.run(v); t.run(chain(2, nt())); }
  { std::vector<Desc> v = chain(3, nt()); v[1].flags |= F_FIRST; expect_err(t, v, E_CHAIN_FIRST, "FIRST in the middle"); t.run(v); }
  { std::vector<Desc> v = chain(3, nt()); v[1].trusted = 2; v[1].dom = 2; expect_err(t, v, E_DOMAIN, "trusted binding changes mid-transaction"); t.run(v); }
  { std::vector<Desc> v = chain(3, nt()); v[2].flags |= F_CPL; expect_err(t, v, E_FLAGS, "CPL_EN on a non-first"); t.run(v); }
  { std::vector<Desc> v = chain(3, nt()); v[1].len = 0; v[2].len = 0; t.run(v); t.run(chain(2, nt())); }               // zero length mid-chain, last also zero (skipped)
  { std::vector<Desc> v = chain(2, nt()); v.push_back(chain(1, nt())[0]); v.push_back(chain(3, nt())[1]); v.push_back(chain(3, nt())[2]); t.run(v); }   // stray non-first descriptors between transactions
  { std::vector<Desc> v = chain(3, nt()); v[1].ver = 9; auto st = chain(3, nt()); v.push_back(st[1]); auto w = chain(2, nt()); v.insert(v.end(), w.begin(), w.end());
    t.run(v); }                 // broken txn, its LAST is dropped, then a STRAY non-FIRST (must be reported, skip mode must have ended at LAST), then a good txn
  { std::vector<Desc> v = chain(3, nt()); v[1].ver = 7; v[2].flags &= ~F_LAST; auto w = chain(2, nt()); v.insert(v.end(), w.begin(), w.end()); t.run(v); }  // broken txn without LAST, resync at the next FIRST
  { std::vector<Desc> v = chain(2, nt()); v[0].flags = F_FIRST | F_LAST | F_CPL; v[0].len = 0; t.run(v); }                    // bad FIRST|LAST then stray second
  if (TB_MAXTXN <= 16) {                                               // total-bytes limit (small configuration)
    std::vector<Desc> v; u16 id = nt(); u64 seg = 1ull << (TB_MAXTXN - 2);
    for (int i = 0; i < 6; i++) v.push_back(mk(0, i * 0, 1, DST0 + 0, seg, (i == 0 ? F_FIRST | F_CPL : 0) | (i == 5 ? F_LAST : 0), id));
    for (int i = 0; i < 6; i++) v[i].src = IB(0) + (u64)i * 40000 % 200000, v[i].dst = IB(1) + DST0 + (u64)i * 40000 % 200000;
    expect_err(t, v, E_TOTAL_BIG, "total bytes of a transaction exceed the limit"); t.run(v);
  }
  // disabled memory type (configuration)
  t.cur = "type_disable";
  t.s.type_en = 0x0F; { Desc d = base; d.txn = nt(); d.dt = 4; expect_err(t, {d}, E_MEMTYPE, "disabled memory type"); t.run({d}); } t.run(one(0, 0, 1, 0, 64, nt()));
  t.s.type_en = 0x1F; t.run(one(0, 0, 4, 0, 64, nt()));
}

static void t_protection(T& t) {
  t.cur = "protection";
  ideal_slave(t.s);
  RunOpt nw; nw.no_writes = true;
  u64 UNM = 0xA0000;                                                    // IOVA offset beyond every domain-1 window of type 0 (unmapped)
  // unmapped source / destination
  { Desc d = mk(0, UNM, 1, DST0, 256, F_FIRST | F_LAST | F_CPL, nt()); RefPlan p = t.ref.plan({d}); if (p.cpls[0].err != E_GUARD_RD || p.cpls[0].detail != FAULT_NO_MAP) t.s.fail("ref expectation (unmapped src)"); t.run({d}, nw); }
  { Desc d = mk(0, 0, 0, UNM, 256, F_FIRST | F_LAST | F_CPL, nt()); t.run({d}, nw); }
  { Desc d = mk(0, 0, 0, HALF + 3 * 65536, 256, F_FIRST | F_LAST | F_CPL, nt()); t.run({d}, nw); }
  // permission: read-only and write-only windows (domain 1, type 0)
  { Desc d = mk(0, 0, 0, HALF, 256, F_FIRST | F_LAST | F_CPL, nt()); RefPlan p = t.ref.plan({d}); if (p.cpls[0].err != E_GUARD_WR || p.cpls[0].detail != FAULT_PERM) t.s.fail("ref expectation (write to RO)"); t.run({d}, nw); }
  { Desc d = mk(0, HALF + 65536, 0, DST0, 256, F_FIRST | F_LAST | F_CPL, nt()); RefPlan p = t.ref.plan({d}); if (p.cpls[0].err != E_GUARD_RD || p.cpls[0].detail != FAULT_PERM) t.s.fail("ref expectation (read from WO)"); t.run({d}, nw); }
  t.run({mk(0, HALF + 100, 1, DST0 + 7, 1000, F_FIRST | F_LAST | F_CPL, nt())});                  // reading the RO window is legal
  t.run({mk(1, 5, 0, HALF + 65536 + 33, 1000, F_FIRST | F_LAST | F_CPL, nt())});                   // writing the WO window is legal
  // access that starts in a window and leaves it: partial effects allowed
  t.run({mk(0, 0, 0, HALF - 100, 300, F_FIRST | F_LAST | F_CPL, nt())});                            // write straddles main(RW) -> RO window : fails at the page that is RO
  t.run({mk(0, HALF - 100, 1, DST0, 300, F_FIRST | F_LAST | F_CPL, nt())});                         // read straddles RW -> RO window: legal (both readable)
  // other domains
  t.run({mk(0, 0, 1, DST0, 4096, F_FIRST | F_LAST | F_CPL, nt(), 3)});                              // domain 3 owns a single 4 KiB page of type 0 only
  { Desc d = mk(0, 0, 0, 50, 100, F_FIRST | F_LAST | F_CPL, nt(), 3); t.run({d}, nw); }          // dst overlaps src in the same type -> rejected by validation
  { Desc d = mk(0, 0, 0, 4096, 100, F_FIRST | F_LAST | F_CPL, nt(), 3); t.run({d}, nw); }           // dst page not mapped for domain 3
  { Desc d = mk(0, HALF + 100, 1, DST0, 64, F_FIRST | F_LAST | F_CPL, nt(), 2); RefPlan p = t.ref.plan({d}); if (p.cpls[0].detail != FAULT_DOMAIN) t.s.fail("ref expectation (another domain's window)"); t.run({d}, nw); }
  { Desc d = mk(2, 0, 1, DST0, 64, F_FIRST | F_LAST | F_CPL, nt(), 3); t.run({d}, nw); }            // domain 3 has no mapping at all for type 2
  // the descriptor cannot talk its way into another domain
  { Desc d = mk(0, 0, 1, DST0, 64, F_FIRST | F_LAST | F_CPL, nt(), 1); d.trusted = 2; t.run({d}, nw); }       // claims 1, hardware says 2
  { Desc d = mk(0, 0, 1, DST0, 64, F_FIRST | F_LAST | F_CPL, nt(), 2); d.trusted = 1; t.run({d}, nw); }
  // same IOVA, two domains, two physical windows: each domain only ever touches its own
  t.run({mk(0, 0, 1, DST0, 5000, F_FIRST | F_LAST | F_CPL, nt(), 1)}); t.run({mk(0, 0, 1, DST0, 5000, F_FIRST | F_LAST | F_CPL, nt(), 2)});
  // fault mid-chain after a good prefix
  { std::vector<Desc> v; u16 id = nt(); v.push_back(mk(0, 0, 1, DST0, 700, F_FIRST | F_CPL, id)); v.push_back(mk(0, 5000, 1, DST0 + 5000, 700, 0, id));
    v.push_back(mk(0, UNM, 1, DST0 + 9000, 700, F_LAST, id)); t.run(v); t.run(one(0, 1, 1, 1, 77, nt())); }
}

static void t_hazard(T& t) {
  t.cur = "hazards";
  for (int mode = 0; mode < 2; mode++) {
    if (mode == 1) { rand_slave(t.s); t.s.cfg.rd_order = 2; t.s.cfg.wr_order = 1; }
    for (u64 n : {(u64)1, (u64)W + 3, (u64)TB_BL * W * 2 + 5, (u64)3000}) {
      // RAW chain A -> B -> C -> D inside one transaction
      std::vector<Desc> v; u16 id = nt();
      v.push_back(mk(0, 0, 0, DST0, n, F_FIRST | F_CPL, id)); v.push_back(mk(0, DST0, 0, DST0 + 10000 + 3, n, 0, id));
      v.push_back(mk(0, DST0 + 10000 + 3, 1, DST0, n, 0, id)); v.push_back(mk(1, DST0, 0, DST0 + 30000 + 1, n, F_LAST, id));
      t.run(v);
      // WAW: the last writer wins
      v.clear(); id = nt();
      v.push_back(mk(0, 0, 1, DST0, n, F_FIRST | F_CPL, id)); v.push_back(mk(0, 20000, 1, DST0 + (n > 4 ? 2 : 0), n, 0, id)); v.push_back(mk(0, 40000, 1, DST0 + 1, n, F_LAST, id));
      t.run(v);
      // WAR: segment 1 overwrites what segment 0 read
      v.clear(); id = nt();
      v.push_back(mk(0, 100, 1, DST0, n, F_FIRST | F_CPL, id)); v.push_back(mk(2, 0, 0, 100 + (n > 2 ? 1 : 0), n, F_LAST, id));
      t.run(v);
      // FENCE
      v.clear(); id = nt();
      v.push_back(mk(0, 0, 1, DST0, n, F_FIRST | F_CPL, id)); v.push_back(mk(3, 0, 2, DST0, n, F_FENCE, id)); v.push_back(mk(0, 5, 1, DST0 + n, n, F_LAST, id));
      t.run(v);
    }
  }
  ideal_slave(t.s);
  // the interlock must actually have fired for the dependent copies
  u64 h = t.s.perf(PC_HAZ_EVENTS); if (h == 0) { t.s.fail("hazard interlock never fired (HAZ_EVENTS == 0)"); t.failed++; }
}

// ----------------------------------------------------------------------------- reset / abort / timeout
static void expect_clean_after_reset(T& t, Sim& s, const RefPlan& pl, u64 ar0, u64 aw0, u64 w0) {
  s.cycles(200);
  if (s.d->busy) s.fail("busy after reset");
  if (s.d->cpl_valid) s.fail("completion presented after reset");
  if (s.n_ar != ar0 || s.n_aw != aw0 || s.n_w != w0) s.fail("bus activity after reset (ar %llu->%llu aw %llu->%llu w %llu->%llu)", (unsigned long long)ar0, (unsigned long long)s.n_ar, (unsigned long long)aw0, (unsigned long long)s.n_aw, (unsigned long long)w0, (unsigned long long)s.n_w);
  // whatever was written before the reset is correct data inside the destination, written at most once
  for (auto& tt : s.touched) {
    u8 ty = tt.first; u32 a = tt.second; bool in = false;
    for (const ExecSeg& e : pl.segs) if (e.dt == ty) for (const Chunk& c : e.dst) if (a >= c.pa && a < c.pa + c.n) in = true;
    if (!in) { s.fail("stray write before reset type %d pa %x", ty, a); break; }
    if (s.mem[ty].wc[a] != 1) { s.fail("byte written %u times type %d pa %x", s.mem[ty].wc[a], ty, a); break; }
    if (s.mem[ty].d[a] != t.ref.mem[ty].d[a]) { s.fail("wrong data written before reset type %d pa %x", ty, a); break; }
  }
}
static void t_reset(T& t) {
  t.cur = "reset_cancel";
  Sim& s = t.s; ideal_slave(s);
  for (int k = 0; k < 60; k++) {
    bool soft = (k % 3 == 2);
    if (k % 4 == 1) rand_slave(s); else ideal_slave(s);
    std::vector<Desc> v;
    if (k % 2) v = one(0, 3, 1, 5, 4000 + s.rng() % 20000, nt()); else v = disjoint_stream(s, 2);
    RunOpt o; Baseline b; RefPlan pl = prep_stream(s, t.ref, v, o, &b);
    for (const Desc& d : v) s.push_q.push_back(d);
    s.cycles(1 + (int)(s.rng() % 400));
    u64 ar0, aw0, w0;
    if (soft) { s.req_soft = true; long cc = (long)s.cyc; while ((long)s.cyc - cc < 3000 && (s.d->soft_reset_pending || s.cyc == (u64)cc || s.d->busy)) s.cycle(); s.clear_slave(); s.cycles(3); }
    else { s.hard_reset(1 + s.rng() % 3); s.program_maps(); }
    s.push_q.clear(); s.push_hold = false;
    ar0 = s.n_ar; aw0 = s.n_aw; w0 = s.n_w;
    expect_clean_after_reset(t, s, pl, ar0, aw0, w0);
    clear_counts(s, t.ref, pl); s.check_allow = false; s.got.clear();
    t.runs++; t.per[t.cur].first++; if (s.errors) { t.failed++; t.per[t.cur].second++; s.errors = 0; }
    ideal_slave(s);
    t.run(one(0, 11, 1, 13, 1 + s.rng() % 3000, nt()));                  // after reset the engine works and nothing stale leaks into it
  }
}
static void t_abort(T& t) {
  t.cur = "abort";
  Sim& s = t.s;
  for (int k = 0; k < 30; k++) {
    if (k % 2) rand_slave(s); else ideal_slave(s);
    std::vector<Desc> v; u16 id = nt();
    u64 lim = std::min<u64>(15000, (1ull << TB_MAXTXN) / 3 - 1100); for (int i = 0; i < 3; i++) v.push_back(mk(0, i * 20000, 1, DST0 + i * 20000, 1000 + s.rng() % lim, (i == 0 ? F_FIRST | F_CPL : 0) | (i == 2 ? F_LAST : 0), id));
    auto nxt = one(2, 0, 3, 0, 500, nt()); v.insert(v.end(), nxt.begin(), nxt.end());                // a second transaction queued behind
    RunOpt o; Baseline b; RefPlan pl = prep_stream(s, t.ref, v, o, &b);
    for (const Desc& d : v) s.push_q.push_back(d);
    s.cycles(10 + (int)(s.rng() % 600)); s.req_abort = true;
    long c0 = (long)s.cyc;
    while (((long)s.cyc - c0) < 400000) { s.cycle(); if (s.quiescent() && s.got.size() >= 2) break; }
    s.cycles(30);
    if (!s.quiescent()) s.fail("abort: did not quiesce");
    if (s.got.size() != 2) s.fail("abort: expected 2 completions (aborted txn + the queued one), got %zu", s.got.size());
    else {
      if (!(s.got[0].status == ST_ABORTED && s.got[0].err == E_ABORT) && !(s.got[0].status == ST_OK)) s.fail("abort: first completion status %d err %#x", s.got[0].status, s.got[0].err);
      if (s.got[0].status == ST_ABORTED && s.got[0].done > s.got[0].total) s.fail("abort: done > total");
      // the abort lands in exactly one transaction: if it hit the first, the queued one must run clean; if the first had already
      // finished, the abort may legitimately hit the (short) queued transaction instead
      if (s.got[0].status == ST_ABORTED && s.got[1].status != ST_OK) s.fail("abort: the queued transaction after the abort did not complete OK (status %d err %#x)", s.got[1].status, s.got[1].err);
      if (s.got[0].status == ST_OK && !(s.got[1].status == ST_OK || (s.got[1].status == ST_ABORTED && s.got[1].err == E_ABORT))) s.fail("abort: second completion status %d err %#x", s.got[1].status, s.got[1].err);
    }
    // written bytes are right and inside the destinations (the queued transaction wrote its destination fully)
    for (auto& tt : s.touched) {
      u8 ty = tt.first; u32 a = tt.second; bool in = false;
      for (const ExecSeg& e : pl.segs) if (e.dt == ty) for (const Chunk& c : e.dst) if (a >= c.pa && a < c.pa + c.n) in = true;
      if (!in) { s.fail("abort: stray write type %d pa %x", ty, a); break; }
      if (s.mem[ty].wc[a] != 1 || s.mem[ty].d[a] != t.ref.mem[ty].d[a]) { s.fail("abort: bad byte type %d pa %x (writes %u)", ty, a, s.mem[ty].wc[a]); break; }
    }
    clear_counts(s, t.ref, pl); s.check_allow = false; s.got.clear();
    t.runs++; t.per[t.cur].first++; if (s.errors) { t.failed++; t.per[t.cur].second++; s.errors = 0; }
    ideal_slave(s); t.run(rand_stream(s, 2, false));
  }
}
static void t_timeout(T& t) {
  t.cur = "timeout_fence";
  Sim& s = t.s; ideal_slave(s);
  s.timeout_cfg = 300;
  enum { HR, HB, HAR, HAW, HW, HG };
  for (int mode = 0; mode < 6; mode++) {
    std::vector<Desc> v = one(0, 3, 1, 5, 6000, nt()); auto nxt = one(0, 9, 1, 9, 64, nt()); v.insert(v.end(), nxt.begin(), nxt.end());
    RunOpt o; Baseline b; RefPlan pl = prep_stream(s, t.ref, v, o, &b);
    for (const Desc& d : v) s.push_q.push_back(d);
    s.cycles(40 + (int)(s.rng() % 40));
    if (mode == HR) s.hang_r = true; if (mode == HB) s.hang_b = true; if (mode == HAR) s.hang_ar = true; if (mode == HAW) s.hang_aw = true;
    if (mode == HW) s.hang_w = true; if (mode == HG) s.guard_stall_f = true;
    long c0 = (long)s.cyc; while (((long)s.cyc - c0) < 4000 && s.got.empty()) s.cycle();
    if (s.got.empty()) { s.fail("timeout mode %d: no completion within 4000 cycles", mode); }
    else {
      if (s.got[0].status != ST_TIMEOUT || s.got[0].err != E_TIMEOUT) s.fail("timeout mode %d: status %d err %#x", mode, s.got[0].status, s.got[0].err);
      if (!s.d->fenced) s.fail("timeout mode %d: channel not fenced", mode);
    }
    u64 ar0 = s.n_ar, aw0 = s.n_aw; s.cycles(1500);
    if (s.d->fenced == 0) s.fail("timeout mode %d: fence dropped by itself", mode);
    if (s.got.size() != 1) s.fail("timeout mode %d: extra completions while fenced (%zu)", mode, s.got.size());
    if (s.n_ar != ar0 && mode != HAR) s.fail("timeout mode %d: new AR issued while fenced", mode);
    if (s.n_aw != aw0) s.fail("timeout mode %d: new AW issued while fenced", mode);
    // recovery: bus reset + core soft reset restore the channel
    s.guard_stall_f = false; s.req_soft = true; s.cycles(12);
    if (s.d->fenced) s.fail("timeout mode %d: still fenced after ctl_soft_reset", mode);
    s.got.clear(); clear_counts(s, t.ref, pl); s.check_allow = false;
    t.runs++; t.per[t.cur].first++; if (s.errors) { t.failed++; t.per[t.cur].second++; s.errors = 0; }
    t.run(one(0, 1, 1, 1, 3000, nt()));
  }
  // starvation by software (descriptors that have not arrived yet) must NOT time out
  {
    std::vector<Desc> v; u16 id = nt();
    v.push_back(mk(0, 0, 1, DST0, 500, F_FIRST | F_CPL, id)); v.push_back(mk(0, 1000, 1, DST0 + 1000, 500, F_LAST, id));
    RunOpt o; Baseline b; RefPlan pl = prep_stream(s, t.ref, v, o, &b);
    s.push_q.push_back(v[0]); s.cycles(2000);                                   // 2000 > 300 idle cycles in the middle of a transaction
    if (s.d->fenced || !s.got.empty()) s.fail("watchdog fired on a transaction that was merely waiting for its next descriptor");
    s.push_q.push_back(v[1]);
    long c0 = (long)s.cyc; while (((long)s.cyc - c0) < 20000 && !(s.quiescent() && s.got.size() == 1)) s.cycle();
    int nf = check_stream(s, t.ref, pl, o, b); clear_counts(s, t.ref, pl); s.check_allow = false;
    t.runs++; t.per[t.cur].first++; if (nf) { t.failed++; t.per[t.cur].second++; }
  }
  s.timeout_cfg = 0;
}
static void t_protocol(T& t) {
  t.cur = "bus_protocol_faults";
  Sim& s = t.s; ideal_slave(s);
  for (int mode = 0; mode < 2; mode++) {
    std::vector<Desc> v = one(0, 3, 1, 5, 3000, nt());
    RunOpt o; o.relaxed = true; Baseline b; RefPlan pl = prep_stream(s, t.ref, v, o, &b);
    pl.relaxed = true; pl.cpls[0].status = ST_ERROR; pl.cpls[0].err = E_PROTO; pl.cpls[0].irq = true; pl.irq_expected = 1;
    for (const Desc& d : v) s.push_q.push_back(d);
    if (mode == 0) s.inject_bad_last = true;
    else { s.cycles(3); s.inject_spurious_b = true; s.cycle(); s.inject_spurious_b = false; }
    long c0 = (long)s.cyc; while (((long)s.cyc - c0) < 100000 && !(s.quiescent() && s.got.size() == 1)) s.cycle();
    s.inject_bad_last = false; s.cycles(24);
    int nf = check_stream(s, t.ref, pl, o, b); clear_counts(s, t.ref, pl); s.check_allow = false;
    t.runs++; t.per[t.cur].first++; if (nf) { t.failed++; t.per[t.cur].second++; }
    t.run(one(0, 1, 1, 1, 777, nt()));
  }
}
static void t_cpl_bp(T& t) {
  t.cur = "completion_backpressure";
  ideal_slave(t.s); t.s.cfg.p_cpl = 8; t.s.cfg.p_desc = 60;
  std::vector<Desc> v; for (int i = 0; i < 20; i++) { auto o = one(i % NMT, i * 53, (i + 2) % NMT, i * 11, 1 + t.s.rng() % 300, nt(), F_CPL | ((i % 3 == 0) ? F_IRQ : 0)); v.insert(v.end(), o.begin(), o.end()); }
  t.run(v); ideal_slave(t.s);
}
static void t_random(T& t, int n) {
  t.cur = "random_regression";
  for (int i = 0; i < n; i++) {
    rand_slave(t.s);
    std::vector<Desc> v = rand_stream(t.s, 1 + t.s.rng() % 4);
    if (i % 7 == 3 && !v.empty()) { Desc& d = v[t.s.rng() % v.size()]; int c = t.s.rng() % 6; if (c == 0) d.ver = 3; else if (c == 1) d.len = 0; else if (c == 2) d.rsvd0 = 5; else if (c == 3) d.dom = 9; else if (c == 4) d.src = 1ull << 40; else d.flags |= 0x400; }
    t.run(v);
  }
  ideal_slave(t.s);
}

// ============================================================================= driver
int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  u64 seed = 1; std::string filter; int rand_runs = 300;
  std::vector<std::string> args; for (int i = 1; i < argc; i++) { std::string a = argv[i]; if (a[0] != '+') args.push_back(a); }
  if (args.size() > 0) seed = strtoull(args[0].c_str(), nullptr, 0);
  if (args.size() > 1 && args[1] != "all") filter = args[1];
  if (args.size() > 2) rand_runs = atoi(args[2].c_str());
  Vtb_top* dut = new Vtb_top;
  Sim s(dut, seed); Ref ref(s); T t(s, ref);
  s.default_maps(); s.hard_reset(); s.program_maps();
  printf("StreamDMA bench: DW=%d NR=%d NW=%d BL=%d FIFO=%d seed=%llu\n", TB_DW, TB_NR, TB_NW, TB_BL, TB_FIFO, (unsigned long long)seed);
  if (filter == "trace_small") { s.cfg.lat_r = s.cfg.lat_b = 2; auto v = bw_small(4, 64); s.trace = true; run_stream(s, ref, v); delete dut; return 0; }
  if (filter == "bench") { run_bench(s, ref, getenv("TB_CFGNAME") ? getenv("TB_CFGNAME") : "cfg"); delete dut; return 0; }
  auto want = [&](const char* n) { return filter.empty() || filter == n; };
  if (want("single_byte"))    t_single_byte(t);
  if (want("full_width"))     t_full_width(t);
  if (want("large"))          t_large(t);
  if (want("unaligned"))      t_unaligned(t, 600);
  if (want("scatter_gather")) t_sg(t);
  if (want("multi_txn"))      t_multi(t);
  if (want("backpressure"))   t_backpressure(t);
  if (want("aw_waits_for_w")) t_aw_waits_w(t);
  if (want("reorder_interleave")) t_reorder(t);
  if (want("memory_faults"))  t_faults(t);
  if (want("invalid_descriptors")) t_invalid(t);
  if (want("protection"))     t_protection(t);
  if (want("hazards"))        t_hazard(t);
  if (want("reset_cancel"))   t_reset(t);
  if (want("abort"))          t_abort(t);
  if (want("timeout_fence"))  t_timeout(t);
  if (want("bus_protocol_faults")) t_protocol(t);
  if (want("completion_backpressure")) t_cpl_bp(t);
  if (want("random_regression")) t_random(t, rand_runs);
  printf("\n%-22s %8s %8s\n", "test", "runs", "failed");
  for (auto& kv : t.per) printf("%-22s %8d %8d\n", kv.first.c_str(), kv.second.first, kv.second.second);
  printf("TOTAL runs=%d failed_runs=%d bus_errors=%d cycles=%llu\n", t.runs, t.failed, s.errors, (unsigned long long)s.cyc);
  bool pass = (t.failed == 0 && s.errors == 0);
  printf("%s\n", pass ? "RESULT: PASS" : "RESULT: FAIL");
  delete dut;
  return pass ? 0 : 1;
}
