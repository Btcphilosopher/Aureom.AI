// =============================================================================
// StreamDMA :: tb_mm_top -- system integration top for the Verilator bench tb_mm_main.cpp
//
//   sf_stream_dma  --AXI4-style-->  sf_stream_dma_mm_bridge  --2 masters-->  sf_memory_matrix (MemoryMatrix P101, vendored RTL)
//        ^ MemoryGuard model (vendored CloudDMA permission table)               ^ master 2: HOST  (bench: backdoor load / dump through the REAL port)
//        |                                                                      ^ master 3: NOISE (bench: random traffic -> bank conflicts)
//   masters of the matrix:  0 = DMA read, 1 = DMA write, 2 = host, 3 = noise
//   Nothing here peeks into the SRAM arrays: memory is loaded and checked through MemoryMatrix's own request/response port.
//   Wide buses are exposed at a FIXED 512 bit so one C++ bench serves every DATA_WIDTH.
// =============================================================================
`default_nettype none
module tb_mm_top #(
  parameter int DATA_WIDTH             = 128,
  parameter int ADDR_WIDTH             = 40,
  parameter int BURST_LENGTH           = 16,
  parameter int FIFO_DEPTH             = 64,
  parameter int MAX_OUTSTANDING_READS  = 1,
  parameter int MAX_OUTSTANDING_WRITES = 1,
  parameter int DESCRIPTOR_DEPTH       = 4,
  parameter int SEG_DEPTH              = 2,
  parameter int PLAN_DEPTH             = 1,
  parameter int WR_FIFO_DEPTH          = 2 * BURST_LENGTH,
  parameter int MAX_SEG_LOG2           = 24,
  parameter int MAX_TXN_LOG2           = 30,
  parameter int GUARD_LAT              = 2,
  parameter int DOM_W                  = 4,
  // ---- MemoryMatrix
  parameter int MM_AW                  = 20,
  parameter int NUM_BANKS              = 4,
  parameter int BANK_DEPTH             = 4096,      // words (64 bit) per bank: 4 x 4096 x 8 B = 128 KiB
  parameter int READ_LATENCY           = 1,
  parameter int ENABLE_ECC             = 0,
  parameter int ISSUE_WINDOW           = 1,
  parameter int MM_NSLOT               = 8,
  parameter int ILV_MODE               = 0,
  parameter int ILV_GRAN_LOG2          = 0,
  parameter int AW_DEPTH               = 2,
  parameter logic [15:0] TYPE_MASK     = 16'h0012,  // matrix serves memory types 1 (SRAM) and 4 (compute scratchpad)
  parameter logic [15:0] SECURE_MASK   = 16'h0004,  // domain 2 accesses are tagged secure
  localparam int W    = DATA_WIDTH / 8,
  localparam int RIDW = (MAX_OUTSTANDING_READS  > 1) ? $clog2(MAX_OUTSTANDING_READS)  : 1,
  localparam int WIDW = (MAX_OUTSTANDING_WRITES > 1) ? $clog2(MAX_OUTSTANDING_WRITES) : 1,
  localparam int TOT_W = MAX_TXN_LOG2 + 1,
  localparam int LW   = $clog2(DATA_WIDTH / 8),
  localparam int SZW  = (LW > 0) ? $clog2(LW + 1) : 1,
  localparam int NM   = 4,
  localparam int NRG  = 2,
  localparam int MM_IDW = 8
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            ctl_abort,
  input  wire logic            ctl_soft_reset,
  input  wire logic [31:0]     cfg_timeout,
  input  wire logic [15:0]     cfg_type_en,
  // descriptor push / completion
  input  wire logic            desc_valid,
  output logic                 desc_ready,
  input  wire logic [255:0]    desc_data,
  input  wire logic [DOM_W-1:0] desc_domain,
  output logic                 cpl_valid,
  input  wire logic            cpl_ready,
  output logic [15:0]          cpl_txn_id,
  output logic [DOM_W-1:0]     cpl_domain,
  output logic [3:0]           cpl_status,
  output logic [7:0]           cpl_err,
  output logic [3:0]           cpl_detail,
  output logic [TOT_W-1:0]     cpl_bytes_done,
  output logic [TOT_W-1:0]     cpl_bytes_total,
  output logic [ADDR_WIDTH-1:0] cpl_err_addr,
  output logic [31:0]          cpl_latency,
  output logic                 cpl_partial,
  output logic                 irq,
  // permission table programming (MemoryGuard model)
  input  wire logic            tw_en,
  input  wire logic [3:0]      tw_idx,
  input  wire logic            tw_valid,
  input  wire logic [DOM_W-1:0] tw_domain,
  input  wire logic [3:0]      tw_asid,
  input  wire logic [ADDR_WIDTH-1:0] tw_base,
  input  wire logic [ADDR_WIDTH:0]   tw_size,
  input  wire logic [ADDR_WIDTH-1:0] tw_pa,
  input  wire logic [1:0]      tw_perm,
  output logic                 tw_rej,
  // MemoryMatrix permission regions (static configuration)
  input  wire logic [NRG*MM_AW-1:0] rg_base,
  input  wire logic [NRG*MM_AW-1:0] rg_last,
  input  wire logic [NRG*5-1:0]     rg_perm,
  input  wire logic [NRG*NM-1:0]    rg_mmask,
  // MemoryMatrix master 2 (host) and master 3 (noise): driven by the bench
  input  wire logic            host_req_valid,
  output logic                 host_req_ready,
  input  wire logic            host_we,
  input  wire logic [MM_AW-1:0] host_addr,
  input  wire logic [SZW-1:0]  host_size,
  input  wire logic [511:0]    host_wdata,
  input  wire logic [63:0]     host_be,
  input  wire logic [MM_IDW-1:0] host_id,
  output logic                 host_rsp_valid,
  output logic [511:0]         host_rsp_rdata,
  output logic [2:0]           host_rsp_status,
  output logic [MM_IDW-1:0]    host_rsp_id,
  input  wire logic            noise_req_valid,
  output logic                 noise_req_ready,
  input  wire logic            noise_we,
  input  wire logic [MM_AW-1:0] noise_addr,
  input  wire logic [SZW-1:0]  noise_size,
  input  wire logic [511:0]    noise_wdata,
  input  wire logic [63:0]     noise_be,
  input  wire logic [MM_IDW-1:0] noise_id,
  output logic                 noise_rsp_valid,
  output logic [511:0]         noise_rsp_rdata,
  output logic [2:0]           noise_rsp_status,
  // monitor taps: what the DMA's two matrix masters do, and what the matrix answers
  output logic                 mon_rd_v, mon_rd_rdy, mon_rd_rsp,
  output logic [MM_AW-1:0]     mon_rd_addr,
  output logic [2:0]           mon_rd_status,
  output logic                 mon_wr_v, mon_wr_rdy, mon_wr_rsp,
  output logic [MM_AW-1:0]     mon_wr_addr,
  output logic [63:0]          mon_wr_be,
  output logic [2:0]           mon_wr_status,
  output logic                 mon_wr_req_last,                       // the matrix request carries the burst's last-beat flag
  output logic                 mon_b_hs,                              // B channel handshake (DMA side of the bridge)
  output logic [1:0]           mon_b_resp,
  output logic                 bridge_proto_err,
  // matrix performance (summed over banks) and status
  input  wire logic            mm_perf_clr,
  output logic [31:0]          mm_cycles, mm_acc_rd, mm_acc_wr, mm_conflicts, mm_lost, mm_busy,
  output logic [31:0]          mm_rd_mstall, mm_wr_mstall, mm_rd_arbstall, mm_wr_arbstall, mm_rej,
  output logic [31:0]          mm_rd_bytes, mm_wr_bytes,
  output logic [39:0]          mm_rd_lat_sum, mm_wr_lat_sum,
  output logic [31:0]          mm_rd_lat_cnt, mm_wr_lat_cnt,
  output logic                 mm_idle,
  // DMA status / perf
  output logic                 busy,
  output logic                 fenced,
  output logic                 guard_proto_err,
  output logic                 soft_reset_pending,
  output logic                 soft_reset_active,
  input  wire logic            perf_clear,
  input  wire logic [5:0]      perf_sel,
  output logic [63:0]          perf_data
);
  localparam longint MM_BYTES = 64'(NUM_BANKS) * 64'(BANK_DEPTH) * 8;
  generate
    if (MM_BYTES >= (64'd1 << MM_AW)) begin : g_chk_cap
      matrix_capacity_must_be_below_2_pow_MM_AW_so_the_bridge_can_force_out_of_aperture u_err ();
    end
  endgenerate

  // ------------------------------------------------------------------ MemoryGuard model
  logic                 gq_valid, gq_ready, gq_write, gq_id, gr_valid, gr_ready, gr_id, gr_ok, gt_ready;
  logic [DOM_W-1:0]     gq_dom;
  logic [3:0]           gq_asid, gr_fault;
  logic [ADDR_WIDTH-1:0] gq_addr, gr_pa;
  logic [15:0]          gq_bytes;
  logic [31:0]          rej_count;
  sfdma_perm_table #(.AW(ADDR_WIDTH), .DOM_W(DOM_W), .IDW(1), .NENT(16), .LAT(GUARD_LAT)) u_table (
    .clk(clk), .rst_n(rst_n),
    .tw_en(tw_en), .tw_idx(tw_idx), .tw_valid(tw_valid), .tw_domain(tw_domain), .tw_asid(tw_asid),
    .tw_base(tw_base), .tw_size(tw_size), .tw_pa(tw_pa), .tw_perm(tw_perm), .tw_rej(tw_rej), .rej_count(rej_count),
    .req_valid(gq_valid), .req_ready(gt_ready), .req_domain(gq_dom), .req_asid(gq_asid), .req_write(gq_write),
    .req_addr(gq_addr), .req_bytes(gq_bytes), .req_id(gq_id),
    .rsp_valid(gr_valid), .rsp_ready(gr_ready), .rsp_id(gr_id), .rsp_ok(gr_ok), .rsp_fault(gr_fault), .rsp_pa(gr_pa));
  assign gq_ready = gt_ready;

  // ------------------------------------------------------------------ DUT
  logic                 ar_valid, ar_ready, r_valid, r_ready, r_last, aw_valid, aw_ready, w_valid, w_ready, w_last, b_valid, b_ready;
  logic [RIDW-1:0]      ar_id, r_id;
  logic [WIDW-1:0]      aw_id, b_id;
  logic [ADDR_WIDTH-1:0] ar_addr, aw_addr;
  logic [7:0]           ar_len, aw_len;
  logic [2:0]           ar_size, aw_size;
  logic [1:0]           ar_burst, aw_burst, r_resp, b_resp;
  logic [3:0]           ar_mtype, aw_mtype;
  logic [DOM_W-1:0]     ar_domain, aw_domain;
  logic [DATA_WIDTH-1:0] r_data, w_data;
  logic [W-1:0]         w_strb;

  sf_stream_dma #(
    .DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(ADDR_WIDTH), .NUM_CHANNELS(1), .BURST_LENGTH(BURST_LENGTH), .FIFO_DEPTH(FIFO_DEPTH),
    .MAX_OUTSTANDING_READS(MAX_OUTSTANDING_READS), .MAX_OUTSTANDING_WRITES(MAX_OUTSTANDING_WRITES),
    .DESCRIPTOR_DEPTH(DESCRIPTOR_DEPTH), .DOM_W(DOM_W), .SEG_DEPTH(SEG_DEPTH), .PLAN_DEPTH(PLAN_DEPTH),
    .WR_FIFO_DEPTH(WR_FIFO_DEPTH), .MAX_SEG_LOG2(MAX_SEG_LOG2), .MAX_TXN_LOG2(MAX_TXN_LOG2)
  ) u_dut (
    .clk(clk), .rst_n(rst_n), .ctl_abort(ctl_abort), .ctl_soft_reset(ctl_soft_reset), .cfg_timeout(cfg_timeout), .cfg_type_en(cfg_type_en),
    .desc_valid(desc_valid), .desc_ready(desc_ready), .desc_data(desc_data), .desc_domain(desc_domain),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_txn_id(cpl_txn_id), .cpl_domain(cpl_domain), .cpl_status(cpl_status),
    .cpl_err(cpl_err), .cpl_detail(cpl_detail), .cpl_bytes_done(cpl_bytes_done), .cpl_bytes_total(cpl_bytes_total),
    .cpl_err_addr(cpl_err_addr), .cpl_latency(cpl_latency), .cpl_partial(cpl_partial), .irq(irq),
    .guard_req_valid(gq_valid), .guard_req_ready(gq_ready), .guard_req_domain(gq_dom), .guard_req_asid(gq_asid),
    .guard_req_write(gq_write), .guard_req_addr(gq_addr), .guard_req_bytes(gq_bytes), .guard_req_id(gq_id),
    .guard_rsp_valid(gr_valid), .guard_rsp_ready(gr_ready), .guard_rsp_id(gr_id), .guard_rsp_ok(gr_ok),
    .guard_rsp_fault(gr_fault), .guard_rsp_pa(gr_pa),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_size(ar_size),
    .ar_burst(ar_burst), .ar_mtype(ar_mtype), .ar_domain(ar_domain),
    .r_valid(r_valid), .r_ready(r_ready), .r_id(r_id), .r_data(r_data), .r_resp(r_resp), .r_last(r_last),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_size(aw_size),
    .aw_burst(aw_burst), .aw_mtype(aw_mtype), .aw_domain(aw_domain),
    .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data), .w_strb(w_strb), .w_last(w_last),
    .b_valid(b_valid), .b_ready(b_ready), .b_id(b_id), .b_resp(b_resp),
    .busy(busy), .fenced(fenced), .guard_proto_err(guard_proto_err), .soft_reset_pending(soft_reset_pending), .soft_reset_active(soft_reset_active),
    .perf_clear(perf_clear), .perf_sel(perf_sel), .perf_data(perf_data));

  // ------------------------------------------------------------------ bridge
  // docs/04: on ctl_soft_reset the platform must reset the memory fabric in the cycle soft_reset_active is high.  Here: the bridge is reset and
  // MemoryMatrix is flushed (its only reset-like input; it is global, so the bench keeps the other matrix masters idle around a soft reset).
  wire bridge_rst_n = rst_n & ~soft_reset_active;
  logic                 rd_req_valid, rd_req_ready, rd_rsp_valid, rd_rsp_ready;
  logic [MM_AW-1:0]     rd_req_addr;
  logic [SZW-1:0]       rd_req_size;
  logic [MM_IDW-1:0]    rd_req_id, rd_rsp_id;
  logic [1:0]           rd_req_prot;
  logic [DATA_WIDTH-1:0] rd_rsp_rdata;
  logic [2:0]           rd_rsp_status;
  logic                 wr_req_valid, wr_req_ready, wr_rsp_valid, wr_rsp_ready;
  logic [MM_AW-1:0]     wr_req_addr;
  logic [SZW-1:0]       wr_req_size;
  logic [DATA_WIDTH-1:0] wr_req_wdata;
  logic [W-1:0]         wr_req_be;
  logic [MM_IDW-1:0]    wr_req_id, wr_rsp_id;
  logic [1:0]           wr_req_prot;
  logic [2:0]           wr_rsp_status;

  sf_stream_dma_mm_bridge #(
    .DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(ADDR_WIDTH), .MM_AW(MM_AW), .RIDW(RIDW), .WIDW(WIDW), .MM_IDW(MM_IDW),
    .AW_DEPTH(AW_DEPTH), .DOM_W(DOM_W), .TYPE_MASK(TYPE_MASK), .SECURE_MASK(SECURE_MASK)
  ) u_bridge (
    .clk(clk), .rst_n(bridge_rst_n),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_size(ar_size),
    .ar_burst(ar_burst), .ar_mtype(ar_mtype), .ar_domain(ar_domain),
    .r_valid(r_valid), .r_ready(r_ready), .r_id(r_id), .r_data(r_data), .r_resp(r_resp), .r_last(r_last),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_size(aw_size),
    .aw_burst(aw_burst), .aw_mtype(aw_mtype), .aw_domain(aw_domain),
    .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data), .w_strb(w_strb), .w_last(w_last),
    .b_valid(b_valid), .b_ready(b_ready), .b_id(b_id), .b_resp(b_resp),
    .rd_req_valid(rd_req_valid), .rd_req_ready(rd_req_ready), .rd_req_addr(rd_req_addr), .rd_req_size(rd_req_size),
    .rd_req_id(rd_req_id), .rd_req_prot(rd_req_prot),
    .rd_rsp_valid(rd_rsp_valid), .rd_rsp_ready(rd_rsp_ready), .rd_rsp_rdata(rd_rsp_rdata), .rd_rsp_id(rd_rsp_id), .rd_rsp_status(rd_rsp_status),
    .wr_req_valid(wr_req_valid), .wr_req_ready(wr_req_ready), .wr_req_addr(wr_req_addr), .wr_req_size(wr_req_size),
    .wr_req_wdata(wr_req_wdata), .wr_req_be(wr_req_be), .wr_req_id(wr_req_id), .wr_req_prot(wr_req_prot),
    .wr_rsp_valid(wr_rsp_valid), .wr_rsp_ready(wr_rsp_ready), .wr_rsp_id(wr_rsp_id), .wr_rsp_status(wr_rsp_status),
    .proto_err(bridge_proto_err));

  // ------------------------------------------------------------------ MemoryMatrix
  logic [NM-1:0]               m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_ready, m_rsp_we, m_rsp_ce;
  logic [NM*MM_AW-1:0]         m_req_addr;
  logic [NM*SZW-1:0]           m_req_size;
  logic [NM*DATA_WIDTH-1:0]    m_req_wdata, m_rsp_rdata;
  logic [NM*W-1:0]             m_req_be;
  logic [NM*MM_IDW-1:0]        m_req_id, m_rsp_id;
  logic [NM*2-1:0]             m_req_prot;
  logic [NM*3-1:0]             m_rsp_status;

  assign m_req_valid = {noise_req_valid, host_req_valid, wr_req_valid, rd_req_valid};
  assign m_req_we    = {noise_we, host_we, 1'b1, 1'b0};
  assign m_req_addr  = {noise_addr, host_addr, wr_req_addr, rd_req_addr};
  assign m_req_size  = {noise_size, host_size, wr_req_size, rd_req_size};
  assign m_req_wdata = {noise_wdata[DATA_WIDTH-1:0], host_wdata[DATA_WIDTH-1:0], wr_req_wdata, {DATA_WIDTH{1'b0}}};
  assign m_req_be    = {noise_be[W-1:0], host_be[W-1:0], wr_req_be, {W{1'b0}}};
  assign m_req_id    = {noise_id, host_id, wr_req_id, rd_req_id};
  assign m_req_prot  = {2'b11, 2'b11, wr_req_prot, rd_req_prot};          // host / noise: privileged + secure (never denied by secure regions)
  assign rd_req_ready   = m_req_ready[0];
  assign wr_req_ready   = m_req_ready[1];
  assign host_req_ready = m_req_ready[2];
  assign noise_req_ready = m_req_ready[3];
  assign m_rsp_ready = {1'b1, 1'b1, wr_rsp_ready, rd_rsp_ready};
  assign rd_rsp_valid = m_rsp_valid[0];
  assign wr_rsp_valid = m_rsp_valid[1];
  assign rd_rsp_rdata = m_rsp_rdata[0*DATA_WIDTH +: DATA_WIDTH];
  assign rd_rsp_id    = m_rsp_id[0*MM_IDW +: MM_IDW];
  assign wr_rsp_id    = m_rsp_id[1*MM_IDW +: MM_IDW];
  assign rd_rsp_status = m_rsp_status[0*3 +: 3];
  assign wr_rsp_status = m_rsp_status[1*3 +: 3];
  assign host_rsp_valid  = m_rsp_valid[2];
  assign host_rsp_rdata  = 512'(m_rsp_rdata[2*DATA_WIDTH +: DATA_WIDTH]);
  assign host_rsp_status = m_rsp_status[2*3 +: 3];
  assign host_rsp_id     = m_rsp_id[2*MM_IDW +: MM_IDW];
  assign noise_rsp_valid = m_rsp_valid[3];
  assign noise_rsp_rdata  = 512'(m_rsp_rdata[3*DATA_WIDTH +: DATA_WIDTH]);
  assign noise_rsp_status = m_rsp_status[3*3 +: 3];

  logic [31:0]              pc_cycles;
  logic [NUM_BANKS*32-1:0]  pc_acc_rd, pc_acc_wr, pc_conf, pc_lost, pc_busy;
  logic [NM*32-1:0]         pc_mstall, pc_arbstall, pc_busystall, pc_selfconf, pc_starve, pc_reqs, pc_bytes_rd, pc_bytes_wr, pc_lat_cnt;
  logic [4*32-1:0]          pc_starve_cls;
  logic [NM*40-1:0]         pc_lat_sum;
  logic [NM*20-1:0]         pc_lat_max;
  logic [31:0]              pc_rej;
  logic [NUM_BANKS-1:0]     ev_ce, ev_ue, trc_acc, trc_we;
  logic [NUM_BANKS*MM_AW-1:0] ev_addr;
  logic [NUM_BANKS*16-1:0]  ce_cnt, ue_cnt;
  logic                     flush_busy, init_busy;
  localparam int MW_ = $clog2(NM);
  localparam int SW_ = $clog2(MM_NSLOT);
  localparam int K_  = (DATA_WIDTH / 8 + 2 * 8 - 2) / 8;
  localparam int KW_ = (K_ > 1) ? $clog2(K_) : 1;
  localparam int ROW_W_ = $clog2(BANK_DEPTH);
  localparam int STORE_W_ = (ENABLE_ECC != 0) ? 64 + $clog2(64 + $clog2(64 + 1) + 1) + 1 : 64;
  localparam int FBW_ = (STORE_W_ > 1) ? $clog2(STORE_W_) : 1;
  localparam int BW_ = $clog2(NUM_BANKS);
  logic [NUM_BANKS*MW_-1:0]  trc_m;
  logic [NUM_BANKS*SW_-1:0]  trc_slot;
  logic [NUM_BANKS*KW_-1:0]  trc_k;
  logic [NUM_BANKS*ROW_W_-1:0] trc_row;
  logic [NUM_BANKS*STORE_W_-1:0] tst_rdata;

  sf_memory_matrix #(
    .NUM_BANKS(NUM_BANKS), .BANK_DEPTH(BANK_DEPTH), .WORD_WIDTH(64), .DATA_WIDTH(DATA_WIDTH), .READ_LATENCY(READ_LATENCY),
    .NUM_MASTERS(NM), .ENABLE_ECC(ENABLE_ECC), .AW(MM_AW), .IDW(MM_IDW), .NSLOT(MM_NSLOT), .ISSUE_WINDOW(ISSUE_WINDOW),
    .INTERLEAVE_MODE(ILV_MODE), .ILV_GRAN_LOG2(ILV_GRAN_LOG2), .NUM_REGIONS(NRG), .DEFAULT_ALLOW(1),
    .MCLASS(32'hFFFFFF4F)                       // m0, m1 = DMA class; m2 = CTRL; m3 = TENSOR (noise)
  ) u_mm (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_size(m_req_size),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id), .m_req_prot(m_req_prot),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we),
    .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .rg_base_i(rg_base), .rg_last_i(rg_last), .rg_perm_i(rg_perm), .rg_mmask_i(rg_mmask),
    .flush_i(soft_reset_active), .flush_busy_o(flush_busy), .quiesce_i(1'b0), .idle_o(mm_idle),
    .init_start_i(1'b0), .init_busy_o(init_busy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue), .ev_addr_o(ev_addr), .ce_cnt_o(ce_cnt), .ue_cnt_o(ue_cnt),
    .perf_clr_i(mm_perf_clr), .perf_cycles_o(pc_cycles), .perf_acc_rd_o(pc_acc_rd), .perf_acc_wr_o(pc_acc_wr), .perf_conf_o(pc_conf),
    .perf_lost_o(pc_lost), .perf_busy_o(pc_busy), .perf_mstall_o(pc_mstall), .perf_arbstall_o(pc_arbstall),
    .perf_busystall_o(pc_busystall), .perf_selfconf_o(pc_selfconf), .perf_starve_o(pc_starve), .perf_starve_cls_o(pc_starve_cls),
    .perf_reqs_o(pc_reqs), .perf_bytes_rd_o(pc_bytes_rd), .perf_bytes_wr_o(pc_bytes_wr), .perf_lat_sum_o(pc_lat_sum),
    .perf_lat_cnt_o(pc_lat_cnt), .perf_lat_max_o(pc_lat_max), .perf_rej_o(pc_rej),
    .trc_acc_o(trc_acc), .trc_we_o(trc_we), .trc_m_o(trc_m), .trc_slot_o(trc_slot), .trc_k_o(trc_k), .trc_row_o(trc_row),
    .tst_active_i(1'b0), .tst_sel_i({NUM_BANKS{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W_{1'b0}}),
    .tst_wdata_i({STORE_W_{1'b0}}), .tst_rdata_o(tst_rdata),
    .fi_bank({BW_{1'b0}}), .fi_type(4'd0), .fi_row({ROW_W_{1'b0}}), .fi_row2({ROW_W_{1'b0}}), .fi_bit({FBW_{1'b0}}), .fi_bit2({FBW_{1'b0}}),
    .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({ROW_W_{1'b0}}), .seu_mask({STORE_W_{1'b0}}));

  // ------------------------------------------------------------------ summed matrix counters + monitor taps
  function automatic logic [31:0] sum_nb(input logic [NUM_BANKS*32-1:0] v);
    logic [31:0] s;
    s = 32'd0;
    for (int i = 0; i < NUM_BANKS; i++) s = s + v[i*32 +: 32];
    sum_nb = s;
  endfunction
  assign mm_cycles = pc_cycles;
  assign mm_acc_rd = sum_nb(pc_acc_rd);
  assign mm_acc_wr = sum_nb(pc_acc_wr);
  assign mm_conflicts = sum_nb(pc_conf);
  assign mm_lost = sum_nb(pc_lost);
  assign mm_busy = sum_nb(pc_busy);
  assign mm_rd_mstall = pc_mstall[0*32 +: 32];   assign mm_wr_mstall = pc_mstall[1*32 +: 32];
  assign mm_rd_arbstall = pc_arbstall[0*32 +: 32]; assign mm_wr_arbstall = pc_arbstall[1*32 +: 32];
  assign mm_rej = pc_rej;
  assign mm_rd_bytes = pc_bytes_rd[0*32 +: 32];  assign mm_wr_bytes = pc_bytes_wr[1*32 +: 32];
  assign mm_rd_lat_sum = pc_lat_sum[0*40 +: 40]; assign mm_wr_lat_sum = pc_lat_sum[1*40 +: 40];
  assign mm_rd_lat_cnt = pc_lat_cnt[0*32 +: 32]; assign mm_wr_lat_cnt = pc_lat_cnt[1*32 +: 32];

  assign mon_rd_v = rd_req_valid;  assign mon_rd_rdy = rd_req_ready;  assign mon_rd_addr = rd_req_addr;
  assign mon_rd_rsp = rd_rsp_valid && rd_rsp_ready;                    assign mon_rd_status = rd_rsp_status;
  assign mon_wr_v = wr_req_valid;  assign mon_wr_rdy = wr_req_ready;  assign mon_wr_addr = wr_req_addr;
  assign mon_wr_be = 64'(wr_req_be);
  assign mon_wr_rsp = wr_rsp_valid && wr_rsp_ready;                    assign mon_wr_status = wr_rsp_status;
  assign mon_wr_req_last = wr_req_id[WIDW];
  assign mon_b_hs = b_valid && b_ready;
  assign mon_b_resp = b_resp;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, rej_count, host_wdata[511:DATA_WIDTH], noise_wdata[511:DATA_WIDTH], host_be[63:W], noise_be[63:W], m_rsp_we, m_rsp_ce,
                     pc_busystall, pc_selfconf, pc_starve, pc_starve_cls, pc_reqs, pc_lat_max, ev_ce, ev_ue, ev_addr, ce_cnt, ue_cnt,
                     trc_acc, trc_we, trc_m, trc_slot, trc_k, trc_row, tst_rdata, flush_busy, init_busy, 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
