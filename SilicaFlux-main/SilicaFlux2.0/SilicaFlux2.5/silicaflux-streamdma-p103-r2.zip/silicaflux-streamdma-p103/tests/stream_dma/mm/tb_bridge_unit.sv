// =============================================================================
// StreamDMA <-> MemoryMatrix :: bridge unit test with an ADVERSARIAL AXI master.
//
// The system bench (tb_mm_main.cpp) drives the bridge through StreamDMA, which is a polite master: it never emits a burst that wraps around
// the top of the aperture, never uses another beat size, another burst type, or a wrong WLAST.  The bridge's defensive checks for exactly those
// cases are therefore unreachable from the system bench, and mutating them would survive for the wrong reason.  This bench drives the bridge
// directly, against the REAL sf_memory_matrix, and requires every illegal burst to fail closed (DECERR, no array access, no side effect).
//
//   build/run:  scripts/run_bridge_unit.sh            (Verilator --binary --timing)
//   prints:     RESULT: PASS | FAIL    (errors=N checks=M)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_bridge_unit;
  localparam int DW = 128, W = 16, AWD = 40, MM_AW = 20, IDW = 8, RIDW = 2, WIDW = 2;
  localparam int NB = 4, BD = 4096, NM = 2, NRG = 2;
  localparam int SZW = 3;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  int errors = 0, checks = 0;
  task automatic chk(input bit cond, input string msg);
    checks++;
    if (!cond) begin errors++; if (errors <= 20) $display("  [FAIL @%0t] %s", $time, msg); end
  endtask

  // ---------------------------------------------------------------- AXI side (driven by this bench)
  logic              ar_valid = 0; wire ar_ready; logic [RIDW-1:0] ar_id = 0; logic [AWD-1:0] ar_addr = 0; logic [7:0] ar_len = 0;
  logic [2:0]        ar_size = 3'd4; logic [1:0] ar_burst = 2'b01; logic [3:0] ar_mtype = 4'd1, ar_domain = 4'd1;
  wire               r_valid; wire [RIDW-1:0] r_id; wire [DW-1:0] r_data; wire [1:0] r_resp; wire r_last;
  logic              aw_valid = 0; wire aw_ready; logic [WIDW-1:0] aw_id = 0; logic [AWD-1:0] aw_addr = 0; logic [7:0] aw_len = 0;
  logic [2:0]        aw_size = 3'd4; logic [1:0] aw_burst = 2'b01; logic [3:0] aw_mtype = 4'd1, aw_domain = 4'd1;
  logic              w_valid = 0; wire w_ready; logic [DW-1:0] w_data = 0; logic [W-1:0] w_strb = '1; logic w_last = 0;
  wire               b_valid; wire [WIDW-1:0] b_id; wire [1:0] b_resp; wire proto_err;

  // ---------------------------------------------------------------- bridge <-> matrix wiring (2 matrix masters: 0 read, 1 write)
  wire               rd_req_valid, rd_req_ready, rd_rsp_valid, rd_rsp_ready, wr_req_valid, wr_req_ready, wr_rsp_valid, wr_rsp_ready;
  wire [MM_AW-1:0]   rd_req_addr, wr_req_addr; wire [SZW-1:0] rd_req_size, wr_req_size; wire [IDW-1:0] rd_req_id, wr_req_id, rd_rsp_id, wr_rsp_id;
  wire [1:0]         rd_req_prot, wr_req_prot; wire [DW-1:0] rd_rsp_rdata, wr_req_wdata; wire [W-1:0] wr_req_be; wire [2:0] rd_rsp_status, wr_rsp_status;

  sf_stream_dma_mm_bridge #(.DATA_WIDTH(DW), .ADDR_WIDTH(AWD), .MM_AW(MM_AW), .RIDW(RIDW), .WIDW(WIDW), .MM_IDW(IDW), .AW_DEPTH(2), .DOM_W(4),
                            .TYPE_MASK(16'h0012), .SECURE_MASK(16'h0004)) u_br (
    .clk(clk), .rst_n(rst_n),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_size(ar_size), .ar_burst(ar_burst), .ar_mtype(ar_mtype), .ar_domain(ar_domain),
    .r_valid(r_valid), .r_ready(1'b1), .r_id(r_id), .r_data(r_data), .r_resp(r_resp), .r_last(r_last),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_size(aw_size), .aw_burst(aw_burst), .aw_mtype(aw_mtype), .aw_domain(aw_domain),
    .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data), .w_strb(w_strb), .w_last(w_last),
    .b_valid(b_valid), .b_ready(1'b1), .b_id(b_id), .b_resp(b_resp),
    .rd_req_valid(rd_req_valid), .rd_req_ready(rd_req_ready), .rd_req_addr(rd_req_addr), .rd_req_size(rd_req_size), .rd_req_id(rd_req_id), .rd_req_prot(rd_req_prot),
    .rd_rsp_valid(rd_rsp_valid), .rd_rsp_ready(rd_rsp_ready), .rd_rsp_rdata(rd_rsp_rdata), .rd_rsp_id(rd_rsp_id), .rd_rsp_status(rd_rsp_status),
    .wr_req_valid(wr_req_valid), .wr_req_ready(wr_req_ready), .wr_req_addr(wr_req_addr), .wr_req_size(wr_req_size), .wr_req_wdata(wr_req_wdata), .wr_req_be(wr_req_be),
    .wr_req_id(wr_req_id), .wr_req_prot(wr_req_prot), .wr_rsp_valid(wr_rsp_valid), .wr_rsp_ready(wr_rsp_ready), .wr_rsp_id(wr_rsp_id), .wr_rsp_status(wr_rsp_status),
    .proto_err(proto_err));

  logic [NM-1:0] mrv, mrr, mwe, mpv, mpr; wire [NM-1:0] m_rsp_we, m_rsp_ce;
  wire [NM-1:0] m_req_ready, m_rsp_valid;
  wire [NM*DW-1:0] m_rsp_rdata; wire [NM*IDW-1:0] m_rsp_id; wire [NM*3-1:0] m_rsp_status;
  logic [NRG*MM_AW-1:0] rg_base = '0, rg_last = '0; logic [NRG*5-1:0] rg_perm = '0; logic [NRG*NM-1:0] rg_mmask = '0;
  assign rd_req_ready = m_req_ready[0]; assign wr_req_ready = m_req_ready[1];
  assign rd_rsp_valid = m_rsp_valid[0]; assign wr_rsp_valid = m_rsp_valid[1];
  assign rd_rsp_rdata = m_rsp_rdata[0*DW +: DW]; assign rd_rsp_id = m_rsp_id[0*IDW +: IDW]; assign wr_rsp_id = m_rsp_id[1*IDW +: IDW];
  assign rd_rsp_status = m_rsp_status[2:0]; assign wr_rsp_status = m_rsp_status[5:3];

  localparam int ROW_W = $clog2(BD), STORE_W = 64, BW_ = $clog2(NB), FBW_ = $clog2(STORE_W);
  /* verilator lint_off PINMISSING */
  sf_memory_matrix #(.NUM_BANKS(NB), .BANK_DEPTH(BD), .WORD_WIDTH(64), .DATA_WIDTH(DW), .READ_LATENCY(1), .NUM_MASTERS(NM), .ENABLE_ECC(0), .AW(MM_AW), .IDW(IDW), .NSLOT(8),
                     .NUM_REGIONS(NRG), .DEFAULT_ALLOW(1)) u_mm (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid({wr_req_valid, rd_req_valid}), .m_req_ready(m_req_ready), .m_req_we(2'b10), .m_req_addr({wr_req_addr, rd_req_addr}), .m_req_size({wr_req_size, rd_req_size}),
    .m_req_wdata({wr_req_wdata, {DW{1'b0}}}), .m_req_be({wr_req_be, {W{1'b0}}}), .m_req_id({wr_req_id, rd_req_id}), .m_req_prot({wr_req_prot, rd_req_prot}),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready({wr_rsp_ready, rd_rsp_ready}), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .rg_base_i(rg_base), .rg_last_i(rg_last), .rg_perm_i(rg_perm), .rg_mmask_i(rg_mmask),
    .flush_i(1'b0), .quiesce_i(1'b0), .init_start_i(1'b0), .scrub_en_i(1'b0), .ecc_clr_i(1'b0), .perf_clr_i(1'b0),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W{1'b0}}), .tst_wdata_i({STORE_W{1'b0}}),
    .fi_bank({BW_{1'b0}}), .fi_type(4'd0), .fi_row({ROW_W{1'b0}}), .fi_row2({ROW_W{1'b0}}), .fi_bit({FBW_{1'b0}}), .fi_bit2({FBW_{1'b0}}), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row({ROW_W{1'b0}}), .seu_mask({STORE_W{1'b0}}));
  /* verilator lint_on PINMISSING */

  // ---------------------------------------------------------------- response monitors
  logic [1:0]    rd_resp [0:15]; logic [DW-1:0] rd_dat [0:15]; logic rd_lst [0:15]; logic [RIDW-1:0] rd_rid [0:15]; int rd_n = 0;
  logic [1:0]    b_resp_q; logic [WIDW-1:0] b_id_q; int b_n = 0;
  always @(posedge clk) begin
    if (r_valid) begin if (rd_n < 16) begin rd_resp[rd_n] <= r_resp; rd_dat[rd_n] <= r_data; rd_lst[rd_n] <= r_last; rd_rid[rd_n] <= r_id; end rd_n <= rd_n + 1; end
    if (b_valid) begin b_resp_q <= b_resp; b_id_q <= b_id; b_n <= b_n + 1; end
  end

  // ---------------------------------------------------------------- bus tasks
  task automatic tick(input int n = 1); repeat (n) @(posedge clk); endtask
  task automatic rd(input [AWD-1:0] a, input [7:0] len, input [2:0] sz, input [1:0] bt, input [3:0] mt, input [3:0] dom, input [RIDW-1:0] id);
    int t;
    rd_n = 0; @(negedge clk);
    ar_valid = 1; ar_addr = a; ar_len = len; ar_size = sz; ar_burst = bt; ar_mtype = mt; ar_domain = dom; ar_id = id;
    t = 0; do begin @(posedge clk); t++; end while (!ar_ready && t < 200);
    @(negedge clk); ar_valid = 0;
    t = 0; while (rd_n < len + 1 && t < 400) begin @(posedge clk); t++; end
    chk(rd_n == len + 1, $sformatf("read %0d beats expected, got %0d", len + 1, rd_n));
    tick(4);
  endtask
  // write with data pattern seed; wlast_bad: assert WLAST on the first beat instead of the last (protocol violation); strb applies to every beat
  task automatic wr(input [AWD-1:0] a, input [7:0] len, input [2:0] sz, input [1:0] bt, input [3:0] mt, input [3:0] dom, input [WIDW-1:0] id,
                    input [7:0] seed, input [W-1:0] strb, input bit wlast_bad);
    int t, k, bn0;
    bn0 = b_n; @(negedge clk);
    aw_valid = 1; aw_addr = a; aw_len = len; aw_size = sz; aw_burst = bt; aw_mtype = mt; aw_domain = dom; aw_id = id;
    t = 0; do begin @(posedge clk); t++; end while (!aw_ready && t < 200);
    @(negedge clk); aw_valid = 0;
    for (k = 0; k <= len; k++) begin
      w_valid = 1; w_strb = strb; w_data = {W{seed + 8'(k)}}; w_last = wlast_bad ? (k == 0) : (k == len);
      t = 0; do begin @(posedge clk); t++; end while (!w_ready && t < 400);
      @(negedge clk);
    end
    w_valid = 0; w_last = 0;
    t = 0; while (b_n == bn0 && t < 600) begin @(posedge clk); t++; end
    chk(b_n == bn0 + 1, "write: no B response");
    tick(4);
  endtask
  task automatic expect_read(input [AWD-1:0] a, input [7:0] len, input [7:0] seed, input [W-1:0] strb_mask_bytes, input string what);
    rd(a, len, 3'd4, 2'b01, 4'd1, 4'd1, 0);
    for (int k = 0; k <= len; k++) begin
      chk(rd_resp[k] == 2'b00, {what, ": read beat not OKAY"});
      for (int j = 0; j < W; j++) if (strb_mask_bytes[j]) chk(rd_dat[k][8*j +: 8] == 8'(seed + k), $sformatf("%s: byte mismatch beat %0d lane %0d", what, k, j));
    end
  endtask
  task automatic expect_all_decerr(input string what, input int n);
    for (int k = 0; k < n; k++) chk(rd_resp[k] == 2'b11, $sformatf("%s: beat %0d response %0b, expected DECERR(11)", what, k, rd_resp[k]));
  endtask

  initial begin
    $display("StreamDMA MemoryMatrix bridge unit test (adversarial AXI master, real sf_memory_matrix)");
    repeat (6) @(posedge clk); rst_n = 1; repeat (6) @(posedge clk);

    // ---- T1: a legal write/read round trip, bursts of 1 and 4 beats, ids carried through
    wr(40'h1000, 8'd3, 3'd4, 2'b01, 4'd1, 4'd1, 2'd2, 8'h10, '1, 0);
    chk(b_resp_q == 2'b00 && b_id_q == 2'd2, "T1: B must be OKAY with the AW id");
    rd(40'h1000, 8'd3, 3'd4, 2'b01, 4'd1, 4'd1, 2'd1);
    for (int k = 0; k < 4; k++) begin
      chk(rd_resp[k] == 2'b00 && rd_rid[k] == 2'd1, "T1: read beat OKAY with ARID");
      chk(rd_lst[k] == (k == 3), "T1: RLAST only on the last beat");
      for (int j = 0; j < W; j++) chk(rd_dat[k][8*j +: 8] == 8'(8'h10 + k), "T1: data");
    end
    // ---- T2: byte strobes: only the enabled lanes change
    wr(40'h2000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'hAA, '1, 0);
    wr(40'h2000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h55, 16'h00F0, 0);
    rd(40'h2000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0);
    for (int j = 0; j < W; j++) chk(rd_dat[0][8*j +: 8] == ((j >= 4 && j < 8) ? 8'h55 : 8'hAA), $sformatf("T2: lane %0d", j));

    // ---- T3: a burst that would WRAP around the top of the 2^MM_AW aperture: both beats must fail, beat 1 must not alias address 0
    wr(40'h0, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h77, '1, 0);                                 // known content at PA 0
    wr(40'hFFFF0, 8'd1, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h99, '1, 0);                           // would write PA 0xFFFF0 then wrap to PA 0
    chk(b_resp_q == 2'b11, "T3: wrapping write burst must complete with DECERR");
    expect_read(40'h0, 8'd0, 8'h77, '1, "T3: PA 0 untouched by the wrapping write");
    rd(40'hFFFF0, 8'd1, 3'd4, 2'b01, 4'd1, 4'd1, 0); expect_all_decerr("T3 wrapping read", 2);

    // ---- T4: beat size other than the full width (here 8 bytes on a 16-byte bus), read and write
    rd(40'h1000, 8'd1, 3'd3, 2'b01, 4'd1, 4'd1, 0); expect_all_decerr("T4 size read", 2);
    wr(40'h3000, 8'd0, 3'd3, 2'b01, 4'd1, 4'd1, 0, 8'h33, '1, 0); chk(b_resp_q == 2'b11, "T4: wrong-size write must be DECERR");
    // ---- T5: burst types other than INCR (FIXED, WRAP)
    rd(40'h1000, 8'd1, 3'd4, 2'b00, 4'd1, 4'd1, 0); expect_all_decerr("T5 FIXED read", 2);
    rd(40'h1000, 8'd1, 3'd4, 2'b10, 4'd1, 4'd1, 0); expect_all_decerr("T5 WRAP read", 2);
    wr(40'h3000, 8'd0, 3'd4, 2'b10, 4'd1, 4'd1, 0, 8'h33, '1, 0); chk(b_resp_q == 2'b11, "T5: WRAP write must be DECERR");
    // ---- T6: a memory type the matrix does not serve (0 DRAM, 2 storage, 3 network): nothing may be read or written
    rd(40'h1000, 8'd0, 3'd4, 2'b01, 4'd2, 4'd1, 0); expect_all_decerr("T6 type 2 read", 1);
    wr(40'h3000, 8'd0, 3'd4, 2'b01, 4'd0, 4'd1, 0, 8'h33, '1, 0); chk(b_resp_q == 2'b11, "T6: type 0 write must be DECERR");
    // ---- T7: address bits above the matrix aperture
    rd(40'h10_0000 + 40'h40, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0); expect_all_decerr("T7 aperture read", 1);
    wr(40'h10_0000 + 40'h3000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h33, '1, 0); chk(b_resp_q == 2'b11, "T7: out-of-aperture write must be DECERR");
    wr(40'h1_0000_0000 + 40'h3000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h44, '1, 0); chk(b_resp_q == 2'b11, "T7: bit 32 set must be DECERR");
    // none of the refused writes may have touched PA 0x3000 (T4-T7 all aimed at it)
    rd(40'h3000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0);
    chk(rd_dat[0][7:0] !== 8'h33 && rd_dat[0][7:0] !== 8'h44, "T4-T7: a refused write reached the array");
    // ---- T8: WLAST on the wrong beat is a protocol violation: flagged (sticky), and the burst still completes (no hang)
    chk(proto_err == 1'b0, "T8: proto_err must be clear before the violation");
    wr(40'h4000, 8'd1, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h21, '1, 1);
    chk(proto_err == 1'b1, "T8: WLAST on the first beat of a 2-beat burst must raise proto_err");
    // ---- T9: the domain reaches the matrix as prot.secure: a secure-only window refuses domain 1 and accepts domain 2 (SECURE_MASK bit 2)
    rg_base = {20'h0, 20'h5000}; rg_last = {20'h0, 20'h5FFF}; rg_perm = {5'h0, 5'h1B}; rg_mmask = {2'b00, 2'b11};    // region 0: [0x5000,0x5FFF] R|W|secure|enabled, masters 0 and 1
    wr(40'h5000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd2, 0, 8'h61, '1, 0); chk(b_resp_q == 2'b00, "T9: secure domain 2 may write the secure window");
    wr(40'h5010, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h62, '1, 0); chk(b_resp_q == 2'b10, "T9: non-secure domain 1 write must be SLVERR (PERM)");
    rd(40'h5000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd2, 0); chk(rd_resp[0] == 2'b00 && rd_dat[0][7:0] == 8'h61, "T9: secure domain 2 read");
    rd(40'h5000, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0); chk(rd_resp[0] == 2'b10, "T9: non-secure domain 1 read must be SLVERR (PERM)");
    rg_perm = '0;
    rd(40'h5010, 8'd0, 3'd4, 2'b01, 4'd1, 4'd1, 0); chk(rd_dat[0][7:0] !== 8'h62, "T9: the refused write must not have reached the array");
    // ---- T10: a long legal burst (16 beats) after all the refusals: the bridge recovered
    wr(40'h6000, 8'd15, 3'd4, 2'b01, 4'd1, 4'd1, 0, 8'h80, '1, 0); chk(b_resp_q == 2'b00, "T10: legal 16-beat write after refusals");
    rd(40'h6000, 8'd15, 3'd4, 2'b01, 4'd1, 4'd1, 0);
    for (int k = 0; k < 16; k++) chk(rd_resp[k] == 2'b00 && rd_dat[k][7:0] == 8'(8'h80 + k) && rd_lst[k] == (k == 15), "T10: 16-beat read back");

    $display("RESULT: %s (errors=%0d checks=%0d)", errors == 0 ? "PASS" : "FAIL", errors, checks);
    $finish;
  end
  initial begin #50_000_000; $display("RESULT: FAIL (timeout)"); $finish; end
endmodule
`default_nettype wire
