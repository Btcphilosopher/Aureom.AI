// =============================================================================
// StreamDMA <-> MemoryMatrix (P101) system bench.
//
//   DUT chain : sf_stream_dma -> sf_stream_dma_mm_bridge -> sf_memory_matrix (the vendored P101 RTL, unmodified)
//   Memory is NEVER peeked: the bench loads and dumps it through MemoryMatrix's own request/response port (master 2),
//   while master 3 injects random traffic into a disjoint region (bank conflicts) and checks its own reads.
//
//   Independent reference model: a flat byte image of the matrix, a translation table written from docs/02, and a
//   strictly sequential, byte-by-byte execution of the descriptor stream.  It shares no code with the RTL and none with
//   tests/stream_dma/tb_ref.h (this bench is deliberately self-contained).
//
//   Per run: refresh random data around every touched range (regions off) -> push descriptors -> wait for the completion
//   records -> dump the ranges through the matrix -> compare byte for byte; plus the write-count monitor (no lost /
//   duplicated / stray byte), the stray-read monitor, the bus-level completion contract and the cross-check of the DMA's
//   own performance counters against what the matrix really saw.
//
//   usage: tb_mm_<cfg> [seed] [all|<test>|bench] [random-runs]     (env TB_FAILFAST=1: stop at the first failure)
// =============================================================================
#include "Vtb_mm_top.h"
#include "verilated.h"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <deque>
#include <set>
#include <random>
#include <algorithm>
#include <string>
#include <map>
#include <cstdarg>

#ifndef TB_DW
#define TB_DW 128
#endif
#ifndef TB_MMBYTES
#define TB_MMBYTES (128 * 1024)
#endif
#ifndef TB_MMAW
#define TB_MMAW 20
#endif
#ifndef TB_BL
#define TB_BL 16
#endif
#ifndef TB_NR
#define TB_NR 1
#endif
#ifndef TB_NW
#define TB_NW 1
#endif
#ifndef TB_ECC
#define TB_ECC 0
#endif

typedef uint64_t u64; typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8;
static const int W = TB_DW / 8;
static const int LW = __builtin_ctz(W);
static const u32 MMB = TB_MMBYTES;
// physical map of the matrix: type-1 (SRAM) arena, type-4 (compute scratchpad) arena, noise region.  Disjoint by construction.
static const u32 A1 = 0, A1N = 48 << 10, A4 = 64 << 10, A4N = 48 << 10, NZ = 112 << 10, NZN = 16 << 10;
static const u32 S_LO = A1 + (16 << 10), S_N = 8 << 10;          // secure-only window (inside the type-1 arena): offsets 16K..24K
static const u32 P_LO = A4 + (32 << 10), P_N = 4 << 10;          // protected window (inside the type-4 arena): offsets 32K..36K
static inline u64 IB(int t) { return 0x40000000ULL + (u64)t * 0x10000000ULL; }
static inline u32 PA0(int t) { return t == 1 ? A1 : A4; }
static inline u32 PAN(int t) { return t == 1 ? A1N : A4N; }
static inline u64 iova(int t, u32 off) { return IB(t) + off; }          // IOVA of byte `off` of the type-t arena

enum { E_NONE = 0, E_BUS_RD = 0x30, E_BUS_WR = 0x31, E_ABORT = 0x34 };
enum { ST_OK = 0, ST_ERROR = 1, ST_ABORTED = 2, ST_TIMEOUT = 3 };
enum { F_FIRST = 1, F_LAST = 2, F_FENCE = 4, F_CPL = 8, F_IRQ = 16 };
enum { PC_BYTES_WR = 2, PC_BYTES_RD = 3, PC_RD_BEATS = 6, PC_WR_BEATS = 7, PC_RD_STALL_OUT = 10, PC_RD_STALL_BUF = 9, PC_WR_STALL_DATA = 14, PC_TXN_DONE = 24 };
enum { RC_NONE = 0, RC_SECURE = 1, RC_WPROT = 2, RC_DENY = 3, RC_WLOW = 4 };

struct Desc { u8 ver = 1, op = 0; u16 flags = 0, txn = 0, dom = 1; u8 st = 1, dt = 1; u64 len = 0, src = 0, dst = 0; u8 trusted = 1; };
static void pack(const Desc& d, u32 w[8]) {
  w[0] = d.ver | ((u32)d.op << 8) | ((u32)d.flags << 16); w[1] = d.txn | ((u32)d.dom << 16); w[2] = (d.st & 15) | ((u32)(d.dt & 15) << 4);
  w[3] = (u32)d.len; w[4] = (u32)d.src; w[5] = (u32)(d.src >> 32); w[6] = (u32)d.dst; w[7] = (u32)(d.dst >> 32);
}
struct Map { u8 dom, type; u64 iova, size, pa; u8 perm; };
struct Cpl { u16 txn; u8 dom; int status, err; u64 done, total; bool partial; };
struct Exp { u16 txn; u8 dom; int status, err; u64 done, total; bool rec; };
struct Range { u32 lo, hi; };
struct Seg { int st, dt; u16 txn; u32 spa, dpa; u64 len; };
struct Plan { std::vector<Exp> cpls; std::vector<Seg> segs; std::vector<Range> ext; };
struct RunOpt { bool relaxed = false; long max_cycles = 0; int regions = RC_NONE; };

struct Sim {
  const char* cur = "-";                                          // name of the running test class (printed with every failure)
  Vtb_mm_top* d; u64 cyc = 0; std::mt19937_64 rng; int errors = 0, printed = 0;
  std::vector<u8> ref = std::vector<u8>(MMB);                       // reference image of the whole matrix
  std::vector<u16> wc = std::vector<u16>(MMB), wcref = std::vector<u16>(MMB);
  std::vector<Map> maps;
  int p_desc = 100, p_cpl = 100, p_noise = 0;                       // bench-side behaviour (percent per cycle)
  std::deque<Desc> push_q; bool push_hold = false; Desc push_cur;
  std::vector<Cpl> got; int irq_count = 0;
  // matrix-side monitors of the two DMA masters
  u64 n_rreq = 0, n_rrsp = 0, n_wreq = 0, n_wrsp = 0, ack_bytes = 0, n_oor_wr = 0, n_oor_rd = 0, burst_acc = 0, n_bursts = 0, n_b = 0, contract_done = 0; std::deque<u64> burst_q; std::deque<int> wbytes_q;
  std::vector<Range> allow_rd, allow_wr; bool check_allow = false;
  std::vector<u32> wr_touched;
  // host master (blocking helper) and noise master
  struct HReq { bool we; u32 addr; int size; u8 data[64]; u64 be; int id; };
  std::deque<HReq> hq; bool h_hold = false; HReq h_cur; std::deque<std::vector<u8>> hresp; std::deque<int> hstat;
  struct NReq { bool we; u32 addr; int size; u8 data[64]; u64 be; } n_cur; bool n_hold = false;
  struct NExp { bool we; std::vector<u8> data; };
  std::deque<NExp> nexp; u64 noise_reqs = 0;
  u64 run_cycles = 0, run_bytes = 0, total_cycles_runs = 0;

  explicit Sim(Vtb_mm_top* dut, u64 seed) : d(dut), rng(seed) {}
  void fail(const char* fmt, ...) __attribute__((format(printf, 2, 3))) {
    errors++;
    if (printed < 14) { char b[700]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof b, fmt, a); va_end(a); printf("  [FAIL %s @%llu] %s\n", cur, (unsigned long long)cyc, b); printed++; }
    if (getenv("TB_FAILFAST")) { printf("RESULT: FAIL (failfast)\n"); fflush(stdout); exit(1); }
  }
  bool pct(int p) { return p >= 100 || (p > 0 && (int)(rng() % 100) < p); }
  u64 rnd(u64 n) { return n ? rng() % n : 0; }

  template <typename T> void set_wide(T& w, const u8* b, int n) { for (size_t i = 0; i < 16; i++) w[i] = 0; for (int i = 0; i < n; i++) w[i / 4] |= (u32)b[i] << (8 * (i % 4)); }
  template <typename T> void get_wide(const T& w, u8* b, int n) { for (int i = 0; i < n; i++) b[i] = (w[i / 4] >> (8 * (i % 4))) & 0xFF; }

  // ---------------------------------------------------------------- independent translation (MemoryGuard contract)
  bool xl(int dom, int t, u64 a, u64 n, bool wr, u64* pa) const {
    for (const Map& m : maps) {
      if (m.type != t || m.dom != dom) continue;
      if (a >= m.iova && a + n <= m.iova + m.size && (wr ? (m.perm & 2) : (m.perm & 1))) { *pa = m.pa + (a - m.iova); return true; }
    }
    return false;
  }
  void default_maps() { maps.clear(); for (int dom = 1; dom <= 2; dom++) for (int t : {1, 4}) maps.push_back({(u8)dom, (u8)t, IB(t), PAN(t), PA0(t), 3}); }
  void raw_tick() { d->clk = 0; d->eval(); d->clk = 1; d->eval(); d->clk = 0; d->eval(); cyc++; }
  void program_maps() {
    settle_noise();                                                  // raw_tick() runs the clock WITHOUT the driver/sampler: no request may be in flight
    for (int i = 0; i < 16; i++) { d->tw_en = 1; d->tw_idx = i; d->tw_valid = 0; d->tw_domain = 0; d->tw_asid = 0; d->tw_base = 0; d->tw_size = 4096; d->tw_pa = 0; d->tw_perm = 0; raw_tick(); }
    int i = 0;
    for (const Map& m : maps) {
      d->tw_en = 1; d->tw_idx = i++; d->tw_valid = 1; d->tw_domain = m.dom; d->tw_asid = m.type; d->tw_base = m.iova; d->tw_size = m.size; d->tw_pa = m.pa; d->tw_perm = m.perm; raw_tick();
    }
    d->tw_en = 0; raw_tick();
  }
  u64 perf(int idx) { d->perf_sel = idx; d->eval(); return d->perf_data; }

  // MemoryMatrix permission regions (static configuration).  Region 0: secure-only window S.  Region 1: window P, DMA-protected by cfg.
  void apply_regions(int rc) {
    u32 p_last = (rc == RC_WLOW) ? P_LO + 127 : P_LO + P_N - 1;
    u64 base = (u64)S_LO | ((u64)P_LO << TB_MMAW), last = (u64)(S_LO + S_N - 1) | ((u64)p_last << TB_MMAW);
    u64 p0 = (rc == RC_SECURE) ? 0x1B : 0;                              // R | W | secure-only | enabled
    u64 p1 = (rc == RC_WPROT || rc == RC_WLOW) ? 0x11 : (rc == RC_DENY) ? 0x10 : 0;   // R + enabled (write denied) / enabled with no right at all
    d->rg_base = base; d->rg_last = last; d->rg_perm = p0 | (p1 << 5); d->rg_mmask = 0xF | (0xF << 4);
  }

  // ---------------------------------------------------------------- one clock cycle
  void drive() {
    d->cpl_ready = pct(p_cpl);
    if (!push_hold && !push_q.empty() && pct(p_desc)) { push_cur = push_q.front(); push_hold = true; }
    d->desc_valid = push_hold;
    if (push_hold) { u32 w[8]; pack(push_cur, w); for (int i = 0; i < 8; i++) d->desc_data[i] = w[i]; d->desc_domain = push_cur.trusted; }
    if (!h_hold && !hq.empty()) { h_cur = hq.front(); h_hold = true; }
    d->host_req_valid = h_hold;
    if (h_hold) { d->host_we = h_cur.we; d->host_addr = h_cur.addr; d->host_size = h_cur.size; set_wide(d->host_wdata, h_cur.data, W); d->host_be = h_cur.be; d->host_id = h_cur.id; }
    if (!n_hold && p_noise > 0 && pct(p_noise)) {
      n_cur.size = (int)rnd(LW + 1); u32 span = 1u << n_cur.size; bool al = rnd(2);
      u32 a = NZ + (u32)rnd(NZN - 2 * W); if (al) a &= ~(span - 1);
      n_cur.addr = a; n_cur.we = rnd(2); n_cur.be = 0;
      for (int i = 0; i < W; i++) n_cur.data[i] = (u8)rng();
      for (u32 i = 0; i < span; i++) if (rnd(4) != 0) n_cur.be |= 1ULL << i;
      n_hold = true;
    }
    d->noise_req_valid = n_hold;
    if (n_hold) { d->noise_we = n_cur.we; d->noise_addr = n_cur.addr; d->noise_size = n_cur.size; set_wide(d->noise_wdata, n_cur.data, W); d->noise_be = n_cur.be; d->noise_id = (u8)noise_reqs; }
  }
  static bool in_ranges(const std::vector<Range>& v, u32 a, int n) { for (const Range& r : v) if (a >= r.lo && a + n <= r.hi) return true; return false; }
  void sample() {
    if (d->desc_valid && d->desc_ready) { push_q.pop_front(); push_hold = false; }
    if (d->cpl_valid && d->cpl_ready) {
      Cpl c{(u16)d->cpl_txn_id, (u8)d->cpl_domain, (int)d->cpl_status, (int)d->cpl_err, (u64)d->cpl_bytes_done, (u64)d->cpl_bytes_total, (bool)d->cpl_partial};
      // docs/04 section 2: partial = (bytes_done != 0 && status != OK).  Checked on EVERY accepted record, in the cycle it is accepted.
      if (c.partial != (c.done != 0 && c.status != ST_OK)) fail("cpl_partial=%d inconsistent with record {status %d done %llu}", (int)c.partial, c.status, (unsigned long long)c.done);
      got.push_back(c); contract_done += c.done;
      // COMPLETION CONTRACT, checked against the bus in the cycle the record is accepted (never later: the next transaction may already be writing):
      //   an OK record only after every write beat / burst was answered by the matrix, and bytes_done == payload of the bursts answered OKAY.
      if (getenv("TB_DEBUG")) printf("   [rec @%llu] txn %u status %d err %#x done %llu total %llu | bus: wreq %llu wrsp %llu bursts %llu B %llu ack_bytes %llu\n", (unsigned long long)cyc, c.txn, c.status, c.err,
                                     (unsigned long long)c.done, (unsigned long long)c.total, (unsigned long long)n_wreq, (unsigned long long)n_wrsp, (unsigned long long)n_bursts, (unsigned long long)n_b, (unsigned long long)ack_bytes);
      if (c.status == ST_OK && (n_wreq != n_wrsp || n_bursts != n_b || burst_acc != 0)) fail("COMPLETION CONTRACT: OK record while %llu write beats / %llu bursts are unacknowledged", (unsigned long long)(n_wreq - n_wrsp), (unsigned long long)(n_bursts - n_b));
      if (c.status != ST_TIMEOUT && contract_done != ack_bytes) fail("COMPLETION CONTRACT: reported %llu bytes, the bus answered %llu payload bytes OKAY", (unsigned long long)contract_done, (unsigned long long)ack_bytes);
    }
    if (d->irq) irq_count++;
    // host master: responses come back in acceptance order (matrix contract M2)
    if (h_hold && d->host_req_ready) { h_hold = false; hq.pop_front(); }
    if (d->host_rsp_valid) { std::vector<u8> v(W); get_wide(d->host_rsp_rdata, v.data(), W); hresp.push_back(v); hstat.push_back(d->host_rsp_status); }
    // noise master: by contract M1 the effect of an accepted request is visible to every later accepted request of the same master
    if (n_hold && d->noise_req_ready) {
      u32 span = 1u << n_cur.size; NExp e; e.we = n_cur.we;
      if (n_cur.we) { for (u32 i = 0; i < span; i++) if ((n_cur.be >> i) & 1) ref[n_cur.addr + i] = n_cur.data[i]; }
      else e.data.assign(ref.begin() + n_cur.addr, ref.begin() + n_cur.addr + span);
      nexp.push_back(e); n_hold = false; noise_reqs++;
    }
    if (d->noise_rsp_valid) {
      if (nexp.empty()) fail("noise master: unexpected response");
      else {
        NExp e = nexp.front(); nexp.pop_front();
        if (d->noise_rsp_status != 0) fail("noise master: status %d", (int)d->noise_rsp_status);
        else if (!e.we) { std::vector<u8> g(W); get_wide(d->noise_rsp_rdata, g.data(), W);
          for (size_t i = 0; i < e.data.size(); i++) if (g[i] != e.data[i]) { fail("noise read mismatch lane %zu: got %02x expected %02x", i, g[i], e.data[i]); break; } }
      }
    }
    // the DMA's two masters of the matrix
    if (d->mon_rd_v && d->mon_rd_rdy) {
      n_rreq++; u32 a = (u32)d->mon_rd_addr;
      if (a >= MMB) n_oor_rd++; else if (check_allow && !in_ranges(allow_rd, a, W)) fail("STRAY READ at %#x (outside every source envelope)", a);
    }
    if (d->mon_rd_rsp) n_rrsp++;
    if (d->mon_wr_v && d->mon_wr_rdy) {
      n_wreq++; u32 a = (u32)d->mon_wr_addr; u64 be = d->mon_wr_be; wbytes_q.push_back(__builtin_popcountll(be));
      burst_acc += __builtin_popcountll(be); if (d->mon_wr_req_last) { burst_q.push_back(burst_acc); burst_acc = 0; n_bursts++; }
      if (a >= MMB) n_oor_wr++;                                      // the matrix rejects it (SF_ST_RANGE): no array access
      else {
        for (int j = 0; j < W; j++) if (((be >> j) & 1) && a + j < MMB) { if (wc[a + j] == 0) wr_touched.push_back(a + j); wc[a + j]++; }
        if (check_allow && be && !in_ranges(allow_wr, a, W)) fail("STRAY WRITE at %#x (outside every destination envelope)", a);
      }
    }
    if (d->mon_wr_rsp) { n_wrsp++; if (!wbytes_q.empty()) wbytes_q.pop_front(); }
    // BURST-level acknowledgement: the DMA's bytes_done is defined as the payload of write bursts answered OKAY (docs/04 section 1).  The bridge answers
    // bursts in the order of their beats, so the oldest unanswered burst is the one a B belongs to.
    if (d->mon_b_hs) { n_b++; if (!burst_q.empty()) { if (d->mon_b_resp == 0) ack_bytes += burst_q.front(); burst_q.pop_front(); } else fail("B response without an outstanding write burst"); }
    if (d->bridge_proto_err) fail("bridge protocol error (WLAST disagrees with the AW length)");
    if (d->guard_proto_err) fail("guard protocol error");
  }
  void step() { drive(); d->clk = 0; d->eval(); sample(); d->clk = 1; d->eval(); cyc++; }
  void steps(int n) { while (n-- > 0) step(); }

  // ---------------------------------------------------------------- host access through the REAL matrix port
  void host_xfer(bool we, u32 addr, u8* p, u32 n) {
    u32 lo = addr & ~(u32)(W - 1), hi = (u32)(((u64)addr + n + W - 1) & ~(u64)(W - 1)); size_t nreq = 0;
    hresp.clear(); hstat.clear();
    for (u32 a = lo; a < hi; a += W) {
      HReq r{}; r.we = we; r.addr = a; r.size = LW; r.id = (int)(nreq++ & 0xFF);
      if (we) for (int j = 0; j < W; j++) { u32 x = a + j; bool in = x >= addr && x < addr + n; r.be |= (u64)in << j; r.data[j] = in ? p[x - addr] : 0; }
      hq.push_back(r);
    }
    long guard = 0;
    while (!(hq.empty() && !h_hold && hstat.size() >= nreq)) { step(); if (++guard > 400000) { fail("host access timed out"); return; } }
    for (int st : hstat) if (st != 0) { fail("host access returned status %d", st); break; }
    if (!we) { size_t k = 0; for (u32 a = lo; a < hi; a += W, k++) for (int j = 0; j < W; j++) { u32 x = a + j; if (x >= addr && x < addr + n) p[x - addr] = hresp[k][j]; } }
  }
  void host_write(u32 addr, const u8* p, u32 n) { host_xfer(true, addr, const_cast<u8*>(p), n); }
  void host_read(u32 addr, u8* p, u32 n) { host_xfer(false, addr, p, n); }

  // ---------------------------------------------------------------- reference model
  Plan plan(const std::vector<Desc>& s) {
    Plan p; u16 id = 0; u8 dom = 0; u64 total = 0; bool cpl_en = false;
    for (const Desc& d : s) {
      bool first = d.flags & F_FIRST, last = d.flags & F_LAST;
      if (first) { id = d.txn; dom = d.trusted; total = 0; cpl_en = d.flags & F_CPL; }
      u64 sp = 0, dp = 0;
      if (!(xl(d.trusted, d.st, d.src, d.len, false, &sp) && xl(d.trusted, d.dt, d.dst, d.len, true, &dp))) { fprintf(stderr, "bench bug: unmapped descriptor in a data test\n"); exit(2); }
      p.segs.push_back({d.st, d.dt, id, (u32)sp, (u32)dp, d.len}); total += d.len;
      if (last) p.cpls.push_back({id, dom, ST_OK, 0, total, total, cpl_en});
    }
    return p;
  }
  void touch(Plan& p, u32 lo, u64 n) {
    // the +-64 byte guard bands must never reach the noise region [NZ, ..): a live second master owns it
    u32 a = lo > 64 ? ((lo - 64) & ~(u32)(W - 1)) : 0; u32 b = (u32)std::min<u64>(NZ, ((u64)lo + n + 64 + W - 1) & ~(u64)(W - 1)); p.ext.push_back({a, b});
  }
  void merge(Plan& p) {
    std::sort(p.ext.begin(), p.ext.end(), [](const Range& x, const Range& y) { return x.lo < y.lo; });
    std::vector<Range> o; for (const Range& r : p.ext) { if (!o.empty() && r.lo <= o.back().hi) o.back().hi = std::max(o.back().hi, r.hi); else o.push_back(r); }
    p.ext = o;
  }
  void refresh(const Plan& p) {                                      // random-refresh every touched range THROUGH the matrix; ref follows
    for (const Range& r : p.ext) { std::vector<u8> v(r.hi - r.lo); for (auto& b : v) b = (u8)rng(); host_write(r.lo, v.data(), (u32)v.size()); memcpy(&ref[r.lo], v.data(), v.size()); }
  }
  void exec_ref(const Plan& p) {                                     // strictly sequential, byte by byte
    for (const Seg& s : p.segs) {
      std::vector<u8> t(ref.begin() + s.spa, ref.begin() + s.spa + s.len);
      for (u64 i = 0; i < s.len; i++) { ref[s.dpa + i] = t[i]; wcref[s.dpa + i]++; }
    }
  }
  void arm(const Plan& p) {
    allow_rd.clear(); allow_wr.clear();
    for (const Seg& s : p.segs) {
      allow_rd.push_back({s.spa & ~(u32)(W - 1), (u32)((s.spa + s.len + W - 1) & ~(u64)(W - 1))});
      allow_wr.push_back({s.dpa & ~(u32)(W - 1), (u32)((s.dpa + s.len + W - 1) & ~(u64)(W - 1))});
    }
    check_allow = true;
  }
  void clear_counters() { n_rreq = n_rrsp = n_wreq = n_wrsp = ack_bytes = n_oor_wr = n_oor_rd = burst_acc = n_bursts = n_b = contract_done = 0; burst_q.clear(); wbytes_q.clear(); wr_touched.clear(); std::fill(wc.begin(), wc.end(), 0); }
  bool dma_quiet() { return !d->busy && n_rreq == n_rrsp && n_wreq == n_wrsp && n_bursts == n_b && !d->cpl_valid && push_q.empty() && !push_hold; }

  // wait for the DMA to complete `expect_cpl` records (or until cycle budget); enforces the bus-level completion contract on the way
  void wait_done(u64 expect_cpl, long maxc, u64 td_target, u64 td0) {
    u64 c0 = cyc;
    while ((long)(cyc - c0) < maxc) {
      step();
      if (dma_quiet() && got.size() >= expect_cpl && perf(PC_TXN_DONE) - td0 >= td_target) break;
    }
    run_cycles = cyc - c0; steps(40);
  }

  bool run(std::vector<Desc> s, RunOpt o = RunOpt()) {
    Plan p = plan(s);
    for (const Seg& sg : p.segs) { touch(p, sg.spa, sg.len); touch(p, sg.dpa, sg.len); }
    merge(p); apply_regions(RC_NONE); refresh(p);
    std::vector<std::vector<u8>> old; for (const Range& r : p.ext) old.emplace_back(ref.begin() + r.lo, ref.begin() + r.hi);
    exec_ref(p); arm(p);
    int e0 = errors; got.clear(); irq_count = 0; clear_counters();
    u64 bw0 = perf(PC_BYTES_WR), br0 = perf(PC_BYTES_RD), rb0 = perf(PC_RD_BEATS), wb0 = perf(PC_WR_BEATS), td0 = perf(PC_TXN_DONE);
    u64 expect_cpl = 0; for (const Exp& e : p.cpls) if (e.rec) expect_cpl++;
    u64 tot = 0; for (const Desc& x : s) tot += x.len;
    for (const Desc& x : s) push_q.push_back(x);
    apply_regions(o.regions);
    wait_done(expect_cpl, o.max_cycles ? o.max_cycles : 8000 + (long)tot * 12 + (long)s.size() * 1500, p.cpls.size(), td0);
    run_bytes = tot; total_cycles_runs += run_cycles;
    apply_regions(RC_NONE);
    if (!dma_quiet()) fail("run did not reach quiescence (completions %zu/%llu busy=%d)", got.size(), (unsigned long long)expect_cpl, (int)d->busy);
    check_allow = false;
    // ---- completion records
    if (got.size() != expect_cpl) fail("completion records: got %zu expected %llu", got.size(), (unsigned long long)expect_cpl);
    std::set<u16> ok_txn;
    for (size_t i = 0, gi = 0; i < p.cpls.size() && gi < got.size(); i++) {
      const Exp& e = p.cpls[i]; if (!e.rec) continue; const Cpl& g = got[gi++];
      if (g.status == ST_OK) ok_txn.insert(g.txn);
      if (!o.relaxed && (g.txn != e.txn || g.dom != e.dom || g.status != e.status || g.err != e.err || g.done != e.done || g.total != e.total))
        fail("cpl[%zu] got {txn %u dom %u st %d err %#x done %llu total %llu} expected {txn %u dom %u st %d err %#x done %llu total %llu}", i, g.txn, g.dom, g.status, g.err,
             (unsigned long long)g.done, (unsigned long long)g.total, e.txn, e.dom, e.status, e.err, (unsigned long long)e.done, (unsigned long long)e.total);
    }
    // ---- memory: dump every touched range through the matrix and compare with the reference
    std::set<u32> exact;                                             // relaxed runs: bytes of transactions that reported OK must still be exact
    if (o.relaxed) for (const Seg& sg : p.segs) if (ok_txn.count(sg.txn)) for (u64 i = 0; i < sg.len; i++) exact.insert(sg.dpa + (u32)i);
    for (size_t k = 0; k < p.ext.size(); k++) {
      const Range& r = p.ext[k]; std::vector<u8> g(r.hi - r.lo); host_read(r.lo, g.data(), (u32)g.size());
      for (u32 a = r.lo; a < r.hi; a++) {
        u8 got8 = g[a - r.lo], exp8 = ref[a], old8 = old[k][a - r.lo];
        if (!o.relaxed || exact.count(a)) { if (got8 != exp8) { fail("DATA MISMATCH pa %#x: got %02x expected %02x", a, got8, exp8); break; } }
        else if (got8 != exp8 && got8 != old8) { fail("GARBAGE BYTE pa %#x: got %02x, neither old %02x nor new %02x", a, got8, old8, exp8); break; }
      }
      if (o.relaxed) memcpy(&ref[r.lo], g.data(), g.size());         // resynchronise the reference with what really happened
    }
    // ---- write counts: no lost / duplicated / stray byte at the matrix input
    if (!o.relaxed) {
      for (const Seg& sg : p.segs) for (u64 i = 0; i < sg.len; i++) { u32 a = sg.dpa + (u32)i; if (wc[a] != wcref[a]) { fail("WRITE COUNT pa %#x: wrote %u times, expected %u (lost / duplicated byte)", a, wc[a], wcref[a]); goto wc_done; } }
      for (u32 a : wr_touched) if (wc[a] > wcref[a]) { fail("STRAY/DUPLICATE WRITE pa %#x: %u writes, expected %u", a, wc[a], wcref[a]); break; }
    } else {
      for (u32 a : wr_touched) { bool in = false; for (const Seg& sg : p.segs) if (a >= sg.dpa && a < sg.dpa + sg.len) in = true; if (!in) { fail("STRAY WRITE (faulted run) pa %#x", a); break; } if (wc[a] > 1) { fail("DUPLICATE WRITE (faulted run) pa %#x", a); break; } }
    }
  wc_done:
    for (const Seg& sg : p.segs) for (u64 i = 0; i < sg.len; i++) wcref[sg.dpa + i] = 0;
    // ---- the DMA's own performance counters against what the matrix really saw
    if (!o.relaxed) {
      if (perf(PC_RD_BEATS) - rb0 != n_rreq) fail("perf RD_BEATS %llu != matrix read requests %llu", (unsigned long long)(perf(PC_RD_BEATS) - rb0), (unsigned long long)n_rreq);
      if (perf(PC_WR_BEATS) - wb0 != n_wreq) fail("perf WR_BEATS %llu != matrix write requests %llu", (unsigned long long)(perf(PC_WR_BEATS) - wb0), (unsigned long long)n_wreq);
      if (perf(PC_BYTES_WR) - bw0 != tot) fail("perf BYTES_WR %llu != %llu", (unsigned long long)(perf(PC_BYTES_WR) - bw0), (unsigned long long)tot);
      if (perf(PC_BYTES_RD) - br0 != tot) fail("perf BYTES_RD %llu != %llu", (unsigned long long)(perf(PC_BYTES_RD) - br0), (unsigned long long)tot);
      if (perf(PC_TXN_DONE) - td0 != p.cpls.size()) fail("perf TXN_DONE mismatch");
      if (n_oor_rd || n_oor_wr) fail("a clean run produced out-of-aperture accesses (%llu rd, %llu wr)", (unsigned long long)n_oor_rd, (unsigned long long)n_oor_wr);
    }
    return errors == e0;
  }

  // ---------------------------------------------------------------- reset and whole-memory sync
  void settle_noise() { int pn = p_noise; p_noise = 0; long g = 0; while ((n_hold || !nexp.empty()) && ++g < 100000) step(); steps(20); p_noise = pn; }
  void hard_reset() {
    d->rst_n = 0; d->ctl_abort = 0; d->ctl_soft_reset = 0; push_q.clear(); push_hold = false; hq.clear(); h_hold = false; n_hold = false; nexp.clear();
    d->desc_valid = 0; d->host_req_valid = 0; d->noise_req_valid = 0;
    for (int i = 0; i < 4; i++) raw_tick();
    d->rst_n = 1; raw_tick(); hresp.clear(); hstat.clear(); program_maps(); clear_counters(); got.clear();
#if TB_ECC
    std::fill(ref.begin(), ref.end(), 0);                            // ECC builds run the bank init engine on reset: the whole array is zero afterwards (P101 INIT_ON_RESET)
#endif
  }
  void fill_all() { int pn = p_noise; p_noise = 0; std::vector<u8> v(MMB); for (auto& b : v) b = (u8)rng(); host_write(0, v.data(), MMB); ref = v; p_noise = pn; }
  void dump_check_all(const char* what) {
    settle_noise(); std::vector<u8> g(MMB); host_read(0, g.data(), MMB);
    for (u32 a = 0; a < MMB; a++) if (g[a] != ref[a]) { fail("%s: whole-memory mismatch at pa %#x: got %02x expected %02x", what, a, g[a], ref[a]); break; }
  }
};

// ======================================================================== descriptor construction helpers
static Desc mk(u16 txn, u16 flags, int st, int dt, u64 len, u32 so, u32 dof, u8 dom = 1) {
  Desc d; d.txn = txn; d.flags = flags; d.st = st; d.dt = dt; d.len = len; d.src = iova(st, so); d.dst = iova(dt, dof); d.dom = dom; d.trusted = dom; return d;
}
static bool overlap(u64 a, u64 an, u64 b, u64 bn) { return a < b + bn && b < a + an; }
static void pick(Sim& s, int st, int dt, u64 len, u32* so, u32* dof) {             // random non-overlapping (src,dst) offsets, kept out of the special windows
  for (;;) {
    *so = (u32)s.rnd(PAN(st) - len + 1); *dof = (u32)s.rnd(PAN(dt) - len + 1);
    bool bad = (st == dt) && overlap(*so, len, *dof, len);
    for (int k = 0; k < 2; k++) {
      u32 off = k ? *dof : *so; int t = k ? dt : st;
      if (t == 1 && overlap(off, len, S_LO - A1, S_N)) bad = true;
      if (t == 4 && overlap(off, len, P_LO - A4, P_N)) bad = true;
    }
    if (!bad) return;
  }
}
static int pick_t(Sim& s) { return s.rnd(2) ? 1 : 4; }

struct Tally { int runs = 0, fails = 0; };
static std::map<std::string, Tally> tally;
static void note(const char* name, bool ok) { tally[name].runs++; if (!ok) tally[name].fails++; }

// ======================================================================== data tests
static void t_single_byte(Sim& s) {
  for (int so = 0; so < W; so++) for (int dof = 0; dof < W; dof += (W > 16 ? 3 : 1)) {
    int st = pick_t(s), dt = pick_t(s); u32 sb = (st == dt) ? 256 : 4096, db = (st == dt) ? 1024 : 8192;
    note("single_byte", s.run({mk(1, 3 | 8, st, dt, 1, sb + so, db + dof)}));
  }
  note("single_byte", s.run({mk(2, 3 | 8, 1, 4, 1, A1N - 1, A4N - 1)}));            // last byte of both arenas
}
static void t_full_width(Sim& s) {
  for (u64 beats : {1, 2, TB_BL - 1, TB_BL, TB_BL + 1, 2 * TB_BL, 3 * TB_BL + 5}) {
    u64 len = beats * W; int st = pick_t(s), dt = pick_t(s); u32 so, dof; pick(s, st, dt, len, &so, &dof); so &= ~(u32)(W - 1); dof &= ~(u32)(W - 1);
    if (st == dt && overlap(so, len, dof, len)) dof = (so + len + W) & ~(u32)(W - 1);
    note("full_width", s.run({mk(3, 3 | 8, st, dt, len, so, dof)}));
  }
}
static void t_large(Sim& s) {
  for (u64 len : {4096, 4097, 8000, 16384, 20000}) for (int al = 0; al < 2; al++) {
    u32 so = al ? 3 : 0, dof = al ? 5 : 0;
    note("large", s.run({mk(4, 3 | 8 | 16, 1, 4, len, so, dof)}));
    note("large", s.run({mk(5, 3 | 8, 4, 4, len > 12000 ? 12000 : len, so + 1, 24000 + dof)}));
  }
}
static void t_scatter_gather(Sim& s) {
  for (int rep = 0; rep < 12; rep++) {
    int nseg = 2 + (int)s.rnd(7); std::vector<Desc> v;
    for (int i = 0; i < nseg; i++) {
      int st = pick_t(s), dt = pick_t(s); u64 len = 1 + s.rnd(i % 3 == 0 ? 40 : 900); u32 so, dof; pick(s, st, dt, len, &so, &dof);
      v.push_back(mk(6, (i == 0 ? F_FIRST | F_CPL : 0) | (i == nseg - 1 ? F_LAST : 0), st, dt, len, so, dof));
    }
    bool bad = false;                                                // pure scatter-gather: no destination overlaps another destination or any source
    for (size_t i = 0; i < v.size() && !bad; i++) for (size_t j = 0; j < v.size() && !bad; j++) if (i != j) {
      u64 di = v[i].dst - IB(v[i].dt), dj = v[j].dst - IB(v[j].dt), sj = v[j].src - IB(v[j].st);
      if (v[i].dt == v[j].dt && overlap(di, v[i].len, dj, v[j].len)) bad = true;
      if (v[i].dt == v[j].st && overlap(di, v[i].len, sj, v[j].len)) bad = true;
    }
    if (bad) { rep--; continue; }
    note("scatter_gather", s.run(v));
  }
}
static void t_unaligned(Sim& s) {
  for (int rep = 0; rep < 60; rep++) {
    int st = pick_t(s), dt = pick_t(s); u64 len = 1 + s.rnd(rep % 4 == 0 ? 2000 : 150); u32 so, dof; pick(s, st, dt, len, &so, &dof);
    note("unaligned", s.run({mk(7, 3 | 8, st, dt, len, so, dof)}));
  }
}
static void t_hazards(Sim& s) {          // cross-segment RAW / WAW inside one transaction: sequential semantics must hold through the matrix
  for (int rep = 0; rep < 14; rep++) {
    int t = pick_t(s); u64 len = 64 + s.rnd(700); u32 a = (u32)s.rnd(2000), b = 4096 + (u32)s.rnd(2000), c = 8192 + (u32)s.rnd(2000), e = 12288 + (u32)s.rnd(2000);
    std::vector<Desc> v;
    v.push_back(mk(8, F_FIRST | F_CPL, t, t, len, a, b));                                // A -> B
    v.push_back(mk(8, 0, t, t, len, b + (u32)s.rnd(len / 2), c));                         // B(part) -> C   (RAW on B)
    v.push_back(mk(8, 0, t, t, len, c, e));                                               // C -> E          (RAW on C)
    v.push_back(mk(8, F_LAST, t, t, len / 2 + 1, a + 5, b + len / 4));                    // A -> B again, overlapping the first write (WAW, last writer wins)
    if (rep % 2) v[2].flags |= F_FENCE;
    note("hazards", s.run(v));
  }
}
static void t_multi_txn(Sim& s) {
  for (int rep = 0; rep < 6; rep++) {
    std::vector<Desc> v; int n = 3 + (int)s.rnd(6);
    for (int i = 0; i < n; i++) {
      int st = pick_t(s), dt = pick_t(s); u64 len = 1 + s.rnd(1500); u32 so, dof; pick(s, st, dt, len, &so, &dof);
      v.push_back(mk((u16)(100 + i), F_FIRST | F_LAST | F_CPL | (i % 3 == 0 ? F_IRQ : 0), st, dt, len, so, dof));
    }
    note("multi_txn", s.run(v));
  }
}
static void t_backpressure(Sim& s) {      // random backpressure on the descriptor and completion ports, with noise traffic in the matrix
  int pd[] = {100, 30, 5}, pc[] = {100, 20, 3}, pn[] = {0, 40, 100};
  for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
    s.p_desc = pd[i]; s.p_cpl = pc[j]; s.p_noise = pn[(i + j) % 3];
    for (int rep = 0; rep < 4; rep++) {
      std::vector<Desc> v; int n = 1 + (int)s.rnd(3);
      for (int k = 0; k < n; k++) { int st = pick_t(s), dt = pick_t(s); u64 len = 1 + s.rnd(3000); u32 so, dof; pick(s, st, dt, len, &so, &dof); v.push_back(mk((u16)(10 + k), 3 | 8 | 16, st, dt, len, so, dof)); }
      note("backpressure", s.run(v));
    }
  }
  s.p_desc = s.p_cpl = 100; s.p_noise = 0;
}
static void t_contention(Sim& s) {        // the noise master requests a bank every cycle
  s.p_noise = 100;
  for (int rep = 0; rep < 10; rep++) { int st = pick_t(s), dt = pick_t(s); u64 len = 256 + s.rnd(6000); u32 so, dof; pick(s, st, dt, len, &so, &dof); note("contention", s.run({mk(20, 3 | 8, st, dt, len, so, dof)})); }
  s.p_noise = 0;
}

// ======================================================================== memory faults raised by the REAL matrix / the bridge's fail-closed checks
// One segment whose source or destination is refused by the memory side.  Expected: exactly one ERROR record with the stated code, bytes_done == 0,
// the destination bytes in the matrix unchanged, nothing written anywhere else, and the matrix's own reject counter incremented (or, for the
// bridge's fail-closed path, the access never reached an array).  Then a clean transfer must work again.
// partial_lo/partial_n: bytes [dpa+partial_lo, +partial_n) of the destination MAY have been written (a burst that is only half denied is performed beat by beat:
// MemoryMatrix contract M4; the DMA has no rollback, docs/04 section 4) -- they must then hold the SOURCE byte, never anything else.
// victim: when the destination IOVA is deliberately mapped OUTSIDE the matrix, dpa is the range that would be hit by address aliasing; it must stay untouched
// and the stray monitors must not accept any write there (allow_dst = false).
static bool fault_case(Sim& s, const char* name, Desc d, int rc, int expect_err, bool src_in, u32 spa, bool dst_in, u32 dpa, u64 len, bool expect_mm_reject = true,
                       bool allow_dst = true, u32 partial_lo = 0, u32 partial_n = 0, u64 max_done = 0) {
  Plan p;
  if (src_in) s.touch(p, spa, len);
  if (dst_in) s.touch(p, dpa, len);
  s.merge(p); s.apply_regions(RC_NONE); s.refresh(p);
  std::vector<std::vector<u8>> old; for (const Range& r : p.ext) old.emplace_back(s.ref.begin() + r.lo, s.ref.begin() + r.hi);
  int e0 = s.errors; s.got.clear(); s.clear_counters(); s.allow_rd.clear(); s.allow_wr.clear();
  if (src_in) s.allow_rd.push_back({spa & ~(u32)(W - 1), (u32)((spa + len + W - 1) & ~(u64)(W - 1))});
  if (dst_in && allow_dst) s.allow_wr.push_back({dpa & ~(u32)(W - 1), (u32)((dpa + len + W - 1) & ~(u64)(W - 1))});
  s.check_allow = true;
  u64 rej0 = s.d->mm_rej, td0 = s.perf(PC_TXN_DONE);
  d.flags = 3 | 8; s.push_q.push_back(d); s.apply_regions(rc);
  s.wait_done(1, 20000, 1, td0);
  s.apply_regions(RC_NONE); s.check_allow = false;
  if (!s.dma_quiet()) s.fail("%s: no quiescence", name);
  if (s.got.size() != 1) s.fail("%s: expected exactly one completion record, got %zu", name, s.got.size());
  else {
    const Cpl& c = s.got[0];
    if (c.status != ST_ERROR || c.err != expect_err) s.fail("%s: record status %d err %#x, expected ERROR/%#x", name, c.status, c.err, expect_err);
    if (c.done > max_done) s.fail("%s: bytes_done %llu > %llu (a refused burst must never be counted; exactness is checked against the bus by the completion contract)", name, (unsigned long long)c.done, (unsigned long long)max_done);
    if (c.total != len) s.fail("%s: bytes_total %llu != %llu", name, (unsigned long long)c.total, (unsigned long long)len);
  }
  if (expect_mm_reject && s.d->mm_rej == rej0) s.fail("%s: the matrix did not reject anything (mm_rej unchanged)", name);
  for (size_t k = 0; k < p.ext.size(); k++) {                        // refused transfer: every byte of every touched range is still the old byte
    const Range& r = p.ext[k]; std::vector<u8> g(r.hi - r.lo); s.host_read(r.lo, g.data(), (u32)g.size());
    for (u32 a = r.lo; a < r.hi; a++) {
      u8 gv = g[a - r.lo], ov = old[k][a - r.lo];
      bool may = partial_n && a >= dpa + partial_lo && a < dpa + partial_lo + partial_n;
      u8 nv = ov; if (may) { u32 i = a - dpa; u32 sa = spa + i; for (size_t kk = 0; kk < p.ext.size(); kk++) if (sa >= p.ext[kk].lo && sa < p.ext[kk].hi) nv = old[kk][sa - p.ext[kk].lo]; }
      if (gv != ov && !(may && gv == nv)) { s.fail("%s: byte at pa %#x changed (%02x -> %02x) although the transfer was refused", name, a, ov, gv); break; }
    }
    memcpy(&s.ref[r.lo], g.data(), g.size());                        // every byte was verified as old or as a permitted new byte: follow the hardware
  }
  return s.errors == e0;
}
static void t_mm_faults(Sim& s) {
  // extra guard mappings that lead the DMA to places the matrix (or the bridge) must refuse
  s.default_maps();
  s.maps.push_back({1, 1, IB(1) + 0x100000, 8192, 0x80000, 3});     // PA 512 KiB: inside the 1 MiB aperture bits but beyond the 128 KiB matrix -> matrix SF_ST_RANGE
  s.maps.push_back({1, 1, IB(1) + 0x200000, 8192, 0x100000, 3});    // PA 1 MiB: bit MM_AW set -> the bridge's fail-closed address check
  s.maps.push_back({1, 2, IB(2), 8192, 0, 3});                      // memory type 2 (storage): enabled and mapped, but NOT served by this matrix
  s.maps.push_back({1, 1, IB(1) + 0x300000, 8192, 0xFF000, 3});     // PA 0xFF000..0x101000: lets a burst start just below the top of the aperture
  s.program_maps();
  const u64 L = 700;
  // (a) beyond the matrix: read side, write side
  note("mm_faults", fault_case(s, "range-rd", mk(40, 0, 1, 4, L, 0x100000 + 64, 100), RC_NONE, E_BUS_RD, false, 0, true, A4 + 100, L));
  note("mm_faults", fault_case(s, "range-wr", mk(41, 0, 4, 1, L, 100, 0x100000 + 64), RC_NONE, E_BUS_WR, true, A4 + 100, false, 0, L));
  // (b) PA with bits above MM_AW (bridge fail-closed; the forced address is then refused by the matrix as RANGE)
  note("mm_faults", fault_case(s, "aperture-rd", mk(42, 0, 1, 4, L, 0x200000 + 64, 100), RC_NONE, E_BUS_RD, false, 0, true, A4 + 100, L));
  note("mm_faults", fault_case(s, "aperture-wr", mk(43, 0, 4, 1, L, 100, 0x200000 + 64), RC_NONE, E_BUS_WR, true, A4 + 100, false, 0, L));
  // (b2) a burst that would WRAP around the top of the aperture: beat 0 is beyond the matrix, beat 1 would alias PA 0 if the bridge did not check
  note("mm_faults", fault_case(s, "wrap-wr", mk(56, 0, 4, 1, 32, 100, 0x300000 + 0xFF0), RC_NONE, E_BUS_WR, true, A4 + 100, true, 0, 32, true, false));
  note("mm_faults", fault_case(s, "wrap-rd", mk(57, 0, 1, 4, 32, 0x300000 + 0xFF0, 100), RC_NONE, E_BUS_RD, false, 0, true, A4 + 100, 32, true));
  // (c) memory type the matrix does not serve
  { Desc d = mk(44, 0, 2, 4, L, 64, 100); note("mm_faults", fault_case(s, "type-rd", d, RC_NONE, E_BUS_RD, false, 0, true, A4 + 100, L)); }
  { Desc d = mk(45, 0, 4, 2, L, 100, 64); note("mm_faults", fault_case(s, "type-wr", d, RC_NONE, E_BUS_WR, true, A4 + 100, false, 0, L)); }
  s.default_maps(); s.program_maps();
  // (d) MemoryMatrix's own permission regions: secure-only window (domain 1 is not secure, domain 2 is: the trusted domain reaches the matrix as prot.secure)
  note("mm_faults", fault_case(s, "secure-rd", mk(46, 0, 1, 4, L, S_LO - A1 + 64, 100), RC_SECURE, E_BUS_RD, true, S_LO + 64, true, A4 + 100, L));
  note("mm_faults", fault_case(s, "secure-wr", mk(47, 0, 4, 1, L, 100, S_LO - A1 + 64), RC_SECURE, E_BUS_WR, true, A4 + 100, true, S_LO + 64, L));
  { RunOpt o; o.regions = RC_SECURE;                                                // same window, secure domain 2: must work, byte-exact
    note("mm_faults", s.run({mk(48, 3 | 8, 1, 4, L, S_LO - A1 + 64, 100, 2)}, o));
    note("mm_faults", s.run({mk(49, 3 | 8, 4, 1, L, 100, S_LO - A1 + 64, 2)}, o)); }
  // (e) write-protected and deny-all windows: reads of a write-protected window work, writes and everything else are refused
  { RunOpt o; o.regions = RC_WPROT; note("mm_faults", s.run({mk(50, 3 | 8, 4, 1, L, P_LO - A4 + 64, 100)}, o)); }
  note("mm_faults", fault_case(s, "wprot-wr", mk(51, 0, 1, 4, L, 100, P_LO - A4 + 64), RC_WPROT, E_BUS_WR, true, A1 + 100, true, P_LO + 64, L));
  note("mm_faults", fault_case(s, "deny-rd", mk(52, 0, 4, 1, L, P_LO - A4 + 64, 100), RC_DENY, E_BUS_RD, true, P_LO + 64, true, A1 + 100, L));
  note("mm_faults", fault_case(s, "deny-wr", mk(53, 0, 1, 4, L, 100, P_LO - A4 + 64), RC_DENY, E_BUS_WR, true, A1 + 100, true, P_LO + 64, L));
  // (f) a burst that is half denied: the first 8 beats of the first burst hit a write-protected 128 bytes, the last 8 do not.  The B response must carry the WORST beat.
  { u32 sa = 100; note("mm_faults", fault_case(s, "half-denied-burst", mk(58, 0, 1, 4, 512, sa, P_LO - A4), RC_WLOW, E_BUS_WR, true, A1 + sa, true, P_LO, 512, true, true, 128, 384, 256)); }
  // recovery after every kind of fault: a clean transfer must work
  note("mm_faults", s.run({mk(54, 3 | 8, 1, 4, 3000, 7, 11)}));
  s.dump_check_all("mm_faults");                                    // nothing outside the touched ranges changed either
}

// ======================================================================== abort, hard reset, soft reset during transfers
static void t_abort(Sim& s) {
  for (int rep = 0; rep < 12; rep++) {
    std::vector<Desc> v{mk(60, 3 | 8, 1, 4, 12000, 3, 5), mk(61, 3 | 8, 4, 1, 700, 20000, 30000)};
    Plan p = s.plan(v); for (const Seg& sg : p.segs) { s.touch(p, sg.spa, sg.len); s.touch(p, sg.dpa, sg.len); } s.merge(p); s.apply_regions(RC_NONE); s.refresh(p);
    std::vector<std::vector<u8>> old; for (const Range& r : p.ext) old.emplace_back(s.ref.begin() + r.lo, s.ref.begin() + r.hi);
    s.exec_ref(p); s.arm(p); int e0 = s.errors; s.got.clear(); s.clear_counters(); u64 td0 = s.perf(PC_TXN_DONE);
    for (const Desc& x : v) s.push_q.push_back(x);
    s.steps(10 + (int)s.rnd(500)); s.d->ctl_abort = 1; s.step(); s.d->ctl_abort = 0;
    s.wait_done(2, 60000, 2, td0); s.check_allow = false;
    if (!s.dma_quiet()) s.fail("abort: did not quiesce");
    if (s.got.size() != 2) s.fail("abort: expected 2 records (aborted + queued), got %zu", s.got.size());
    else {
      const Cpl &a = s.got[0], &b = s.got[1];
      if (!(a.status == ST_ABORTED && a.err == E_ABORT) && a.status != ST_OK) s.fail("abort: first record status %d err %#x", a.status, a.err);
      if (a.status == ST_ABORTED && a.done > a.total) s.fail("abort: bytes_done > bytes_total");
      if (a.status == ST_ABORTED && b.status != ST_OK) s.fail("abort: the queued transaction after the abort did not complete OK (status %d err %#x)", b.status, b.err);
      if (a.status == ST_OK && !(b.status == ST_OK || (b.status == ST_ABORTED && b.err == E_ABORT))) s.fail("abort: second record status %d err %#x", b.status, b.err);
    }
    std::set<u32> exact; for (const Seg& sg : p.segs) { bool ok = false; for (const Cpl& c : s.got) if (c.txn == sg.txn && c.status == ST_OK) ok = true; if (ok) for (u64 i = 0; i < sg.len; i++) exact.insert(sg.dpa + (u32)i); }
    for (size_t k = 0; k < p.ext.size(); k++) {
      const Range& r = p.ext[k]; std::vector<u8> g(r.hi - r.lo); s.host_read(r.lo, g.data(), (u32)g.size());
      for (u32 a = r.lo; a < r.hi; a++) {
        u8 gv = g[a - r.lo], ev = s.ref[a], ov = old[k][a - r.lo];
        if (exact.count(a) ? gv != ev : (gv != ev && gv != ov)) { s.fail("abort: bad byte at pa %#x: got %02x new %02x old %02x", a, gv, ev, ov); break; }
      }
      memcpy(&s.ref[r.lo], g.data(), g.size());
    }
    for (u32 a : s.wr_touched) { bool in = false; for (const Seg& sg : p.segs) if (a >= sg.dpa && a < sg.dpa + sg.len) in = true; if (!in || s.wc[a] > 1) { s.fail("abort: stray/duplicate write at pa %#x", a); break; } }
    for (const Seg& sg : p.segs) for (u64 i = 0; i < sg.len; i++) s.wcref[sg.dpa + i] = 0;
    note("abort", s.errors == e0);
    note("abort", s.run({mk(62, 3 | 8, 1, 4, 2000, 9, 13)}));      // recovery
  }
}
static void t_reset(Sim& s, bool soft) {
  const char* nm = soft ? "soft_reset" : "hard_reset";
  for (int rep = 0; rep < (soft ? 10 : 16); rep++) {
    s.p_noise = 0; s.settle_noise();
    std::vector<Desc> v{mk(70, 3 | 8, 1, 4, 14000, 3, 5)};
    Plan p = s.plan(v); for (const Seg& sg : p.segs) { s.touch(p, sg.spa, sg.len); s.touch(p, sg.dpa, sg.len); } s.merge(p); s.apply_regions(RC_NONE); s.refresh(p);
    std::vector<std::vector<u8>> old; for (const Range& r : p.ext) old.emplace_back(s.ref.begin() + r.lo, s.ref.begin() + r.hi);
    s.exec_ref(p); s.arm(p); int e0 = s.errors; s.got.clear(); s.clear_counters();
    for (const Desc& x : v) s.push_q.push_back(x);
    s.steps(5 + (int)s.rnd(900));
    s.check_allow = false;
    if (soft) {
      s.d->ctl_soft_reset = 1; s.step(); s.d->ctl_soft_reset = 0; s.push_q.clear(); s.push_hold = false;
      long g = 0; while ((s.d->soft_reset_pending || s.d->soft_reset_active) && ++g < 5000) s.step();
      s.steps(200); s.got.clear();
    } else {
      s.hard_reset(); s.steps(200);
    }
    // after the reset: no completion record, no activity on either DMA master, engine idle
    u64 r0 = s.n_rreq, w0 = s.n_wreq; s.steps(200);
    if (!s.got.empty()) s.fail("%s: a completion record appeared after the reset", nm);
    if (s.n_rreq != r0 || s.n_wreq != w0) s.fail("%s: DMA activity on the matrix after the reset", nm);
    if (s.d->busy) s.fail("%s: engine still busy after the reset", nm);
    for (size_t k = 0; k < p.ext.size(); k++) {
      const Range& r = p.ext[k]; std::vector<u8> g(r.hi - r.lo); s.host_read(r.lo, g.data(), (u32)g.size());
      if (TB_ECC && !soft) { for (u32 a = r.lo; a < r.hi; a++) if (g[a - r.lo] != 0) { s.fail("%s: ECC build must be zero after reset, pa %#x holds %02x", nm, a, g[a - r.lo]); break; } }
      else for (u32 a = r.lo; a < r.hi; a++) { u8 gv = g[a - r.lo], ev = s.ref[a], ov = old[k][a - r.lo]; if (gv != ev && gv != ov) { s.fail("%s: garbage byte at pa %#x: got %02x new %02x old %02x", nm, a, gv, ev, ov); break; } }
      memcpy(&s.ref[r.lo], g.data(), g.size());
    }
    for (u32 a : s.wr_touched) { bool in = false; for (const Seg& sg : p.segs) if (a >= sg.dpa && a < sg.dpa + sg.len) in = true; if (!in || s.wc[a] > 1) { s.fail("%s: stray/duplicate write at pa %#x", nm, a); break; } }
    for (const Seg& sg : p.segs) for (u64 i = 0; i < sg.len; i++) s.wcref[sg.dpa + i] = 0;
    note(nm, s.errors == e0);
    note(nm, s.run({mk(71, 3 | 8, 1, 4, 3000, 9, 13)}));          // clean transfer afterwards
  }
}

// ======================================================================== constrained-random regression
static void t_random(Sim& s, int n) {
  for (int i = 0; i < n; i++) {
    int pd[] = {100, 100, 50, 10}, pc[] = {100, 100, 40, 5}, pn[] = {0, 0, 30, 100};
    s.p_desc = pd[s.rnd(4)]; s.p_cpl = pc[s.rnd(4)]; s.p_noise = pn[s.rnd(4)];
    std::vector<Desc> v; int ntx = 1 + (int)s.rnd(3);
    for (int t = 0; t < ntx; t++) {
      int nseg = 1 + (int)s.rnd(4); u8 tdom = s.rnd(4) == 0 ? 2 : 1;       // the trusted domain is fixed for a whole transaction
      for (int k = 0; k < nseg; k++) {
        int st = pick_t(s), dt = pick_t(s); u64 len = 1 + s.rnd(s.rnd(8) == 0 ? 6000 : 400); u32 so, dof; pick(s, st, dt, len, &so, &dof);
        u16 fl = (k == 0 ? F_FIRST | F_CPL : 0) | (k == nseg - 1 ? F_LAST : 0) | (k && s.rnd(4) == 0 ? F_FENCE : 0) | (k == 0 && s.rnd(3) == 0 ? F_IRQ : 0);
        v.push_back(mk((u16)(200 + t), fl, st, dt, len, so, dof, tdom));
      }
    }
    // occasionally chain a RAW dependency: next segment reads what the previous one wrote
    if (s.rnd(3) == 0 && v.size() >= 2) { Desc& a = v[v.size() - 2]; Desc& b = v[v.size() - 1];
      if (a.txn == b.txn && a.dt == b.st && a.dom == b.dom && b.len <= a.len) { u64 off = (a.dst - IB(a.dt)) + s.rnd(a.len - b.len + 1); b.src = iova(b.st, (u32)off);
        if (b.st == b.dt && overlap(off, b.len, b.dst - IB(b.dt), b.len)) b.dst = iova(b.dt, (u32)((off + b.len + 64) % (PAN(b.dt) - b.len))); } }
    bool legal = true;                                               // an intra-segment overlap (src/dst of one descriptor) is not a legal copy
    for (const Desc& x : v) if (x.st == x.dt && overlap(x.src - IB(x.st), x.len, x.dst - IB(x.dt), x.len)) legal = false;
    for (const Desc& x : v) { u32 so2 = (u32)(x.src - IB(x.st)), do2 = (u32)(x.dst - IB(x.dt));
      if ((x.st == 1 && overlap(so2, x.len, S_LO - A1, S_N)) || (x.dt == 1 && overlap(do2, x.len, S_LO - A1, S_N)) || (x.st == 4 && overlap(so2, x.len, P_LO - A4, P_N)) || (x.dt == 4 && overlap(do2, x.len, P_LO - A4, P_N))) legal = false; }
    if (!legal) { i--; continue; }
    note("random_regression", s.run(v));
  }
  s.p_desc = s.p_cpl = 100; s.p_noise = 0;
}

// ======================================================================== benchmark mode (simulation cycles against the REAL matrix)
// Workloads (every copy is verified byte for byte):
//   copy16k  6 copies of 16 KiB (SRAM arena -> compute arena and back), for destination skews and noise levels (TB_SKEWS / TB_NOISES override the defaults 0,16 / 0,25,50,100)
//   txn4k    8 transactions of 4 KiB      txn64   32 transactions of 64 bytes   (one transaction in flight: per-transaction fill/drain is exposed); skew 16, no noise
// Skew = destination placement relative to the source in bytes.  With 64-bit matrix words one beat (16 B at 128 bit) moves the write stream to the other bank pair of the read stream.
// Noise = another matrix master issuing random 1..16-byte accesses to a disjoint region.
static std::vector<int> env_list(const char* name, std::vector<int> def) {
  const char* e = getenv(name); if (!e) return def;
  std::vector<int> v; for (const char* p = e; *p;) { v.push_back(atoi(p)); while (*p && *p != ',') p++; if (*p == ',') p++; } return v;
}
static void bench_row(Sim& s, const char* cfgname, const char* wl, u32 skew, int noise, u64 bytes, u64 cycles, int ok) {
  printf("bench,%s,%s,%u,%d,%llu,%llu,%.3f,%d,%u,%u,%u,%u,%u,%.2f,%.2f,%llu,%llu,%llu,%d\n", cfgname, wl, skew, noise, (unsigned long long)bytes, (unsigned long long)cycles, (double)bytes / cycles, W,
         (unsigned)s.d->mm_conflicts, (unsigned)s.d->mm_rd_arbstall, (unsigned)s.d->mm_wr_arbstall, (unsigned)s.d->mm_rd_mstall, (unsigned)s.d->mm_wr_mstall,
         s.d->mm_rd_lat_cnt ? (double)s.d->mm_rd_lat_sum / s.d->mm_rd_lat_cnt : 0.0, s.d->mm_wr_lat_cnt ? (double)s.d->mm_wr_lat_sum / s.d->mm_wr_lat_cnt : 0.0,
         (unsigned long long)s.perf(PC_WR_STALL_DATA), (unsigned long long)s.perf(PC_RD_STALL_OUT), (unsigned long long)s.perf(PC_RD_STALL_BUF), ok);
}
static void bench_clear(Sim& s, int noise) { s.p_noise = noise; s.steps(50); s.d->mm_perf_clr = 1; s.d->perf_clear = 1; s.step(); s.d->mm_perf_clr = 0; s.d->perf_clear = 0; }
static void bench(Sim& s, const char* cfgname) {
  printf("bench,config,workload,skew_B,noise_pct,bytes,cycles,B_per_cycle,peak_B_per_cycle,mm_conflict_cycles,mm_rd_arbstall,mm_wr_arbstall,mm_rd_mstall,mm_wr_mstall,mm_rd_lat_avg,mm_wr_lat_avg,dma_wr_stall_data,dma_rd_stall_out,dma_rd_stall_buf,ok\n");
  for (int skew : env_list("TB_SKEWS", {0, W})) for (int noise : env_list("TB_NOISES", {0, 25, 50, 100})) {
    bench_clear(s, noise); u64 bytes = 0, cycles = 0; int ok = 1;
    for (int rep = 0; rep < 6; rep++) {
      u64 len = 16384; std::vector<Desc> v{mk(1, 3 | 8, 1, 4, len, 0, (u32)skew)};
      if (rep & 1) v = {mk(1, 3 | 8, 4, 1, len, 16384, 20000 + (u32)skew)};
      ok &= s.run(v) ? 1 : 0; bytes += s.run_bytes; cycles += s.run_cycles;
    }
    bench_row(s, cfgname, "copy16k", skew, noise, bytes, cycles, ok);
  }
  if (!getenv("TB_SKEWS")) for (auto wl : {std::make_pair("txn4k", 4096u), std::make_pair("txn64", 64u)}) {
    bench_clear(s, 0); std::vector<Desc> v; int n = wl.second == 4096 ? 8 : 32;
    for (int i = 0; i < n; i++) v.push_back(mk((u16)(i + 1), F_FIRST | F_LAST | F_CPL, 1, 4, wl.second, (u32)(i * wl.second), (u32)(i * wl.second) + W));
    int ok = s.run(v) ? 1 : 0; bench_row(s, cfgname, wl.first, W, 0, s.run_bytes, s.run_cycles, ok);
  }
  s.p_noise = 0;
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  u64 seed = argc > 1 ? strtoull(argv[1], 0, 0) : 1; std::string which = argc > 2 ? argv[2] : "all"; int nrand = argc > 3 ? atoi(argv[3]) : 100;
  Vtb_mm_top* top = new Vtb_mm_top; Sim s(top, seed);
  printf("StreamDMA<->MemoryMatrix bench: DW=%d NR=%d NW=%d BL=%d matrix=%u KiB seed=%llu\n", TB_DW, TB_NR, TB_NW, TB_BL, MMB >> 10, (unsigned long long)seed);
  top->cfg_timeout = 0; top->cfg_type_en = 0x1F; top->ctl_abort = 0; top->ctl_soft_reset = 0; top->perf_clear = 0; top->perf_sel = 0; top->mm_perf_clr = 0; top->tw_en = 0;
  top->cpl_ready = 1; top->desc_valid = 0; top->host_req_valid = 0; top->noise_req_valid = 0; top->rst_n = 0;
  s.default_maps(); s.apply_regions(RC_NONE); s.hard_reset(); s.fill_all();
  auto want = [&](const char* n) { return which == "all" || ("," + which + ",").find(std::string(",") + n + ",") != std::string::npos; };
  if (which == "bench") { const char* cn = getenv("TB_CFGNAME"); bench(s, cn ? cn : "cfg"); return s.errors ? 1 : 0; }
  if (want("single_byte"))    { s.cur = "single_byte"; t_single_byte(s); }
  if (want("full_width"))     { s.cur = "full_width"; t_full_width(s); }
  if (want("large"))          { s.cur = "large"; t_large(s); }
  if (want("scatter_gather")) { s.cur = "scatter_gather"; t_scatter_gather(s); }
  if (want("unaligned"))      { s.cur = "unaligned"; t_unaligned(s); }
  if (want("hazards"))        { s.cur = "hazards"; t_hazards(s); }
  if (want("multi_txn"))      { s.cur = "multi_txn"; t_multi_txn(s); }
  if (want("backpressure"))   { s.cur = "backpressure"; t_backpressure(s); }
  if (want("contention"))     { s.cur = "contention"; t_contention(s); }
  if (want("mm_faults"))      { s.cur = "mm_faults"; t_mm_faults(s); }
  if (want("abort"))          { s.cur = "abort"; t_abort(s); }
  if (want("hard_reset"))     { s.cur = "hard_reset"; t_reset(s, false); }
  if (want("soft_reset"))     { s.cur = "soft_reset"; t_reset(s, true); }
  if (want("random"))         { s.cur = "random"; t_random(s, nrand); }
  s.dump_check_all("end of test");
  printf("\n%-22s %6s %7s\n", "test", "runs", "failed");
  int runs = 0, fl = 0; for (auto& kv : tally) { printf("%-22s %6d %7d\n", kv.first.c_str(), kv.second.runs, kv.second.fails); runs += kv.second.runs; fl += kv.second.fails; }
  printf("TOTAL runs=%d failed_runs=%d errors=%d cycles=%llu dma_busy_cycles=%llu\n", runs, fl, s.errors, (unsigned long long)s.cyc, (unsigned long long)s.total_cycles_runs);
  printf("RESULT: %s\n", (s.errors == 0 && fl == 0) ? "PASS" : "FAIL");
  delete top;
  return (s.errors == 0 && fl == 0) ? 0 : 1;
}
