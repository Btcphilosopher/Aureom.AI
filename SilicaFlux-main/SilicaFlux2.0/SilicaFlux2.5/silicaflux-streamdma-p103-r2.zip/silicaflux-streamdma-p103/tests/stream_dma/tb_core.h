// =============================================================================
// StreamDMA verification bench -- core: AXI slave model, protocol/protection monitors, independent reference model.
// The reference model (class Ref) is written in C++ from docs/02_DESCRIPTOR_ABI.md, NOT derived from the RTL: it keeps its
// own byte arrays, its own translation table and executes the descriptor stream strictly sequentially, byte by byte.
// =============================================================================
#pragma once
#include "Vtb_top.h"
#include "verilated.h"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <deque>
#include <random>
#include <algorithm>
#include <string>
#include <functional>
#include <cstdarg>
#include <map>
#include <set>

#ifndef TB_DW
#define TB_DW 128
#endif
#ifndef TB_NR
#define TB_NR 1
#endif
#ifndef TB_NW
#define TB_NW 1
#endif
#ifndef TB_BL
#define TB_BL 16
#endif
#ifndef TB_FIFO
#define TB_FIFO 64
#endif
#ifndef TB_AW
#define TB_AW 40
#endif
#ifndef TB_MAXSEG
#define TB_MAXSEG 24
#endif
#ifndef TB_MAXTXN
#define TB_MAXTXN 30
#endif
#ifndef TB_DOMW
#define TB_DOMW 4
#endif

typedef uint64_t u64; typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8;
static const int W = TB_DW / 8;
static const int NMT = 5;
static const u64 PHYS = 2u << 20;                       // 2 MiB physical per memory type
static const u64 HALF = 512u << 10;                     // per-domain window
static inline u64 IB(int t) { return 0x40000000ULL + (u64)t * 0x10000000ULL; }

// error codes / status (mirrors the ABI document, written out independently)
enum { E_NONE=0, E_VERSION=1, E_OPCODE=2, E_DOMAIN=3, E_FLAGS=4, E_RSVD=5, E_CHAIN_FIRST=6, E_CHAIN_TXN=7, E_MEMTYPE=8,
       E_LEN_ZERO=9, E_LEN_BIG=10, E_TOTAL_BIG=11, E_ADDR_RANGE=12, E_ADDR_OVFL=13, E_OVERLAP=14,
       E_GUARD_RD=0x20, E_GUARD_WR=0x21, E_BUS_RD=0x30, E_BUS_WR=0x31, E_PROTO=0x32, E_TIMEOUT=0x33, E_ABORT=0x34, E_INTERNAL=0x35 };
enum { ST_OK=0, ST_ERROR=1, ST_ABORTED=2, ST_TIMEOUT=3 };
enum { F_FIRST=1, F_LAST=2, F_FENCE=4, F_CPL=8, F_IRQ=16 };
enum { FAULT_NONE=0, FAULT_NO_MAP=1, FAULT_PERM=2, FAULT_DOMAIN=3, FAULT_RANGE=4, FAULT_XLAT=5, FAULT_ASID=6, FAULT_LEN=7 };
// perf indices
enum { PC_CYCLES=0, PC_ACTIVE, PC_BYTES_WR, PC_BYTES_RD, PC_RD_BURSTS, PC_WR_BURSTS, PC_RD_BEATS, PC_WR_BEATS, PC_RD_STALL_AR,
       PC_RD_STALL_BUF, PC_RD_STALL_OUT, PC_RD_STALL_GRD, PC_WR_STALL_AW, PC_WR_STALL_W, PC_WR_STALL_DATA, PC_WR_STALL_WBUF,
       PC_WR_STALL_OUT, PC_WR_STALL_GRD, PC_HAZ_CYCLES, PC_HAZ_EVENTS, PC_OCC_SUM, PC_OCC_MAX, PC_WOCC_SUM, PC_WOCC_MAX,
       PC_TXN_DONE, PC_TXN_ERR, PC_LAT_SUM, PC_LAT_MAX, PC_LAT_LAST, PC_DESC_OK, PC_DESC_REJ, PC_DESC_DROP, PC_GUARD_VIOL,
       PC_BUS_ERR, PC_PROTO_ERR, PC_TIMEOUTS, PC_N };

struct Desc {                                           // one descriptor, every field explicit so tests can corrupt any of them
  u8 ver = 1, op = 0; u16 flags = 0, txn = 0, dom = 0; u8 st = 0, dt = 0; u32 rsvd0 = 0; u64 len = 0, src = 0, dst = 0;
  u8 trusted = 1;                                       // trusted-domain sideband accompanying the push
};
static void pack(const Desc& d, u32 w[8]) {
  w[0] = d.ver | ((u32)d.op << 8) | ((u32)d.flags << 16);
  w[1] = d.txn | ((u32)d.dom << 16);
  w[2] = (d.st & 15) | ((u32)(d.dt & 15) << 4) | (d.rsvd0 << 8);
  w[3] = (u32)d.len;
  w[4] = (u32)d.src; w[5] = (u32)(d.src >> 32);
  w[6] = (u32)d.dst; w[7] = (u32)(d.dst >> 32);
}

struct Map { u8 dom; u8 type; u64 iova, size, pa; u8 perm; };       // perm bit0 = read, bit1 = write

struct Mem { std::vector<u8> d; std::vector<u16> wc; Mem() : d(PHYS), wc(PHYS) {} };

struct ExpCpl { u16 txn; u8 dom; int status; int err; u64 done, total; bool rec; bool irq; int detail = -1; u64 err_mask_alt = 0; };

struct SlaveCfg {
  int p_ar_ready = 100, p_aw_ready = 100, p_w_ready = 100;
  int p_r_valid = 100, p_b_valid = 100;
  int lat_r = 3, jit_r = 0, lat_b = 3, jit_b = 0;
  int rd_order = 0;                // 0 in order, 1 bursts return in random order, 2 beats interleave across IDs (random order)
  int wr_order = 0;                // 0 in order, 1 B responses in random order
  bool aw_waits_w = false;         // AWREADY only once WVALID is seen (legal slave behaviour)
  int p_desc = 100, p_cpl = 100;   // bench-side pushing / completion readiness
};
struct Fault { int type; u64 lo, hi; bool wr; int resp; int beat; };   // PA range, error response, beat index (-1 = all)
struct RdReq { int id; u64 addr; int len; int mt; u64 rdy; int beat; bool bad; int resp; int badbeat; };
struct AwReq { int id; u64 addr; int len; int mt; int dom; int beat; bool bad; int resp; u64 payload = 0; };
struct WBeat { u8 data[64]; u64 strb; bool last; };
struct BRsp  { int id; u64 rdy; int resp; u64 payload = 0; };

struct Range { u64 lo, hi; };

struct Sim {
  Vtb_top* d; u64 cyc = 0; std::mt19937_64 rng; SlaveCfg cfg; Mem mem[NMT];
  // slave state
  std::deque<RdReq> rq; std::deque<AwReq> awq; std::deque<WBeat> wbuf; std::vector<BRsp> bq;
  int cur_rd = -1; std::vector<Fault> faults;
  bool hang_r = false, hang_b = false, hang_ar = false, hang_aw = false, hang_w = false;
  bool inject_spurious_r = false, inject_spurious_b = false, inject_bad_last = false;
  // monitors
  int errors = 0; int printed = 0; u64 n_ar = 0, n_aw = 0, n_arb = 0, n_awb = 0, n_w = 0, n_r = 0, n_b = 0;
  bool pv_ar = false, pv_aw = false, pv_w = false; u64 p_ar_a = 0, p_aw_a = 0; u8 p_ar_len = 0, p_aw_len = 0; u8 p_w_last = 0; u64 p_w_strb = 0; u8 p_w_data[64];
  std::vector<bool> rd_busy_id, wr_busy_id;
  std::vector<Range> allow_rd[NMT], allow_wr[NMT]; bool check_allow = false;
  u32 dom_mask = 0x2; bool check_dom = true;
  bool wr_seen_after_reset = false; bool req_abort = false, req_soft = false, guard_stall_f = false, bus_reset_req = false;
  // bench side
  std::deque<Desc> push_q; bool push_hold = false; Desc push_cur;
  std::vector<ExpCpl> got; u64 got_cpl_ready_pending = 0; int irq_count = 0;
  std::vector<Map> maps; u16 type_en = 0x1F; u32 timeout_cfg = 0;
  std::vector<std::string> msgs; std::vector<std::pair<u8,u32>> touched; u64 ok_bytes = 0;   // payload bytes of write bursts the slave answered OKAY

  Sim(Vtb_top* dut, u64 seed) : d(dut), rng(seed) { rd_busy_id.assign(TB_NR, false); wr_busy_id.assign(TB_NW, false); }

  void fail(const char* fmt, ...) __attribute__((format(printf, 2, 3))) {
    errors++;
    if (printed < 12) { char b[512]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof b, fmt, a); va_end(a);
      printf("  [FAIL @%llu] %s\n", (unsigned long long)cyc, b); printed++; }
  }
  bool pct(int p) { return p >= 100 || (int)(rng() % 100) < p; }

  // ----------------------------------------------------------------- independent translation (guard contract)
  bool in_map(int dom, int t, u64 a, u64 n, bool wr, int* fault = nullptr) const {
    bool any_perm = false, any_range = false, any_dom = false;
    for (const Map& m : maps) {
      bool starts = (a >= m.iova) && (a < m.iova + m.size), inr = starts && (a + n <= m.iova + m.size);
      bool pok = wr ? (m.perm & 2) : (m.perm & 1);
      if (m.type != t) continue;
      if (m.dom == dom) { if (inr && pok) return true; if (inr && !pok) any_perm = true; if (starts && !inr) any_range = true; }
      else if (starts) any_dom = true;
    }
    if (fault) *fault = any_perm ? FAULT_PERM : any_range ? FAULT_RANGE : any_dom ? FAULT_DOMAIN : FAULT_NO_MAP;
    return false;
  }
  bool xlate(int dom, int t, u64 a, u64 n, bool wr, u64* pa) const {
    for (const Map& m : maps) {
      if (m.type != t || m.dom != dom) continue;
      bool inr = (a >= m.iova) && (a + n <= m.iova + m.size);
      if (inr && ((wr ? m.perm & 2 : m.perm & 1))) { *pa = m.pa + (a - m.iova); return true; }
    }
    return false;
  }
  // is [pa, pa+n) of memory type t a physical range that SOME mapping of this domain grants for the access?
  bool pa_granted(int dom, int t, u64 pa, u64 n, bool wr) const {
    for (const Map& m : maps) {
      if (m.type != t || m.dom != dom) continue;
      if (pa >= m.pa && pa + n <= m.pa + m.size && (wr ? m.perm & 2 : m.perm & 1)) return true;
    }
    return false;
  }

  bool pa_granted_any(int t, u64 pa, u64 n, bool wr) const {
    for (int dm = 0; dm < 16; dm++) if (((dom_mask >> dm) & 1) && pa_granted(dm, t, pa, n, wr)) return true;
    return false;
  }
  // ----------------------------------------------------------------- hardware access helpers
  void set_wide(VlWide<16>& w, const u8* b, int n) { for (int i = 0; i < 16; i++) w[i] = 0; for (int i = 0; i < n; i++) w[i / 4] |= (u32)b[i] << (8 * (i % 4)); }
  void get_wide(const VlWide<16>& w, u8* b, int n) { for (int i = 0; i < n; i++) b[i] = (w[i / 4] >> (8 * (i % 4))) & 0xFF; }
  u64 perf(int idx) { d->perf_sel = idx; d->eval(); return d->perf_data; }

  void program_maps() {
    int i = 0;
    for (const Map& m : maps) {
      d->tw_en = 1; d->tw_idx = i++; d->tw_valid = 1; d->tw_domain = m.dom; d->tw_asid = m.type; d->tw_base = m.iova; d->tw_size = m.size;
      d->tw_pa = m.pa; d->tw_perm = m.perm; tick_raw();
    }
    d->tw_en = 0; tick_raw();
  }
  void tick_raw() { d->clk = 0; d->eval(); d->clk = 1; d->eval(); d->clk = 0; d->eval(); cyc++; }

  void default_maps() {
    maps.clear();
    for (int dom = 1; dom <= 2; dom++) for (int t = 0; t < NMT; t++) maps.push_back({(u8)dom, (u8)t, IB(t), HALF, (u64)(dom - 1) * HALF, 3});
    maps.push_back({1, 0, IB(0) + HALF, 64u << 10, 1u << 20, 1});                    // domain 1 read-only window
    maps.push_back({1, 0, IB(0) + HALF + (64u << 10), 64u << 10, (1u << 20) + (64u << 10), 2});   // domain 1 write-only window
    maps.push_back({3, 0, IB(0), 4096, (1u << 20) + (128u << 10), 3});               // domain 3: a single 4 KiB page
    maps.push_back({1, 1, IB(1) + HALF, 8192, (1u << 20) + (256u << 10), 3});        // domain 1 SRAM: 8 KiB window right after the main one
  }

  // ----------------------------------------------------------------- reset
  void clear_slave() {
    rq.clear(); awq.clear(); wbuf.clear(); bq.clear(); cur_rd = -1; pv_ar = pv_aw = pv_w = false;
    std::fill(rd_busy_id.begin(), rd_busy_id.end(), false); std::fill(wr_busy_id.begin(), wr_busy_id.end(), false);
    hang_r = hang_b = hang_ar = hang_aw = hang_w = false; push_hold = false; push_q.clear();
  }
  void idle_inputs() {
    d->desc_valid = 0; d->cpl_ready = 1; d->ar_ready = 0; d->aw_ready = 0; d->w_ready = 0; d->r_valid = 0; d->b_valid = 0;
    d->ctl_abort = 0; d->ctl_soft_reset = 0; d->perf_clear = 0; d->tw_en = 0; d->guard_stall = 0; d->perf_sel = 0;
    d->cfg_timeout = timeout_cfg; d->cfg_type_en = type_en;
  }
  void hard_reset(int cycles = 4) {
    clear_slave(); idle_inputs(); d->rst_n = 0; for (int i = 0; i < cycles; i++) tick_raw(); d->rst_n = 1; tick_raw();
    wr_seen_after_reset = false;
  }

  // ----------------------------------------------------------------- one clock cycle
  void drive() {
    // bench-side pushes
    if (!push_hold && !push_q.empty() && pct(cfg.p_desc)) { push_cur = push_q.front(); push_hold = true; }
    if (push_hold) {
      u32 w[8]; pack(push_cur, w); d->desc_valid = 1; for (int i = 0; i < 8; i++) d->desc_data[i] = w[i]; d->desc_domain = push_cur.trusted;
    } else d->desc_valid = 0;
    d->cpl_ready = pct(cfg.p_cpl);
    d->cfg_timeout = timeout_cfg; d->cfg_type_en = type_en; d->ctl_abort = req_abort; d->ctl_soft_reset = req_soft; req_abort = req_soft = false; d->guard_stall = guard_stall_f;
    // slave readies
    d->ar_ready = !hang_ar && pct(cfg.p_ar_ready) && (int)rq.size() < 64;
    bool wv = d->w_valid;
    d->aw_ready = !hang_aw && pct(cfg.p_aw_ready) && (!cfg.aw_waits_w || wv || !wbuf.empty()) && (int)awq.size() < 64;
    d->w_ready = !hang_w && pct(cfg.p_w_ready) && wbuf.size() < 64;
    // R channel
    d->r_valid = 0; d->b_valid = 0;
    if (!hang_r) drive_r();
    if (!hang_b) drive_b();
    if (inject_spurious_r) { cur_rd = -1; d->r_valid = 1; d->r_id = 0; d->r_last = 1; d->r_resp = 0; VlWide<16> z; for (int i = 0; i < 16; i++) z[i] = 0x5A5A5A5A; d->r_data = z; }
    if (inject_spurious_b) { d->b_valid = 1; d->b_id = 0; d->b_resp = 0; }
  }
  void drive_r() {
    if (rq.empty() || !pct(cfg.p_r_valid)) return;
    int pick = -1;
    if (cfg.rd_order == 0) { if (rq.front().rdy <= cyc) pick = 0; }
    else if (cfg.rd_order == 1) {
      if (cur_rd >= 0 && cur_rd < (int)rq.size() && rq[cur_rd].beat > 0 && rq[cur_rd].beat < rq[cur_rd].len + 1) pick = cur_rd;
      else { std::vector<int> c; for (int i = 0; i < (int)rq.size(); i++) if (rq[i].rdy <= cyc) c.push_back(i); if (!c.empty()) pick = c[rng() % c.size()]; }
    } else { std::vector<int> c; for (int i = 0; i < (int)rq.size(); i++) if (rq[i].rdy <= cyc) c.push_back(i); if (!c.empty()) pick = c[rng() % c.size()]; }
    if (pick < 0) return;
    cur_rd = pick; RdReq& r = rq[pick];
    u64 a = r.addr + (u64)r.beat * W; u8 buf[64] = {0};
    int resp = 0; if (r.bad && (r.badbeat < 0 || r.badbeat == r.beat)) resp = r.resp;
    if (a + W <= PHYS) memcpy(buf, &mem[r.mt].d[a], W); else resp = 3;
    VlWide<16> w; set_wide(w, buf, W); d->r_data = w; d->r_id = r.id; d->r_resp = resp;
    bool last = (r.beat == r.len); if (inject_bad_last) last = !last; d->r_last = last; d->r_valid = 1;
  }
  void drive_b() {
    if (bq.empty() || !pct(cfg.p_b_valid)) return;
    int pick = -1;
    if (cfg.wr_order == 0) { if (bq.front().rdy <= cyc) pick = 0; }
    else { std::vector<int> c; for (int i = 0; i < (int)bq.size(); i++) if (bq[i].rdy <= cyc) c.push_back(i); if (!c.empty()) pick = c[rng() % c.size()]; }
    if (pick < 0) return;
    d->b_valid = 1; d->b_id = bq[pick].id; d->b_resp = bq[pick].resp;
  }

  void observe() {
    // ---------------- handshakes this cycle
    bool ar_hs = d->ar_valid && d->ar_ready, aw_hs = d->aw_valid && d->aw_ready, w_hs = d->w_valid && d->w_ready;
    bool r_hs = d->r_valid && d->r_ready, b_hs = d->b_valid && d->b_ready;
    // valid/payload stability (a reset legitimately drops an un-accepted valid)
    if (d->soft_reset_active) pv_ar = pv_aw = pv_w = false;
    if (pv_ar && !d->ar_valid) fail("AR valid dropped before ready");
    if (pv_aw && !d->aw_valid) fail("AW valid dropped before ready");
    if (pv_w && !d->w_valid) fail("W valid dropped before ready");
    if (pv_ar && d->ar_valid && (d->ar_addr != p_ar_a || d->ar_len != p_ar_len)) fail("AR payload changed while stalled");
    if (pv_aw && d->aw_valid && (d->aw_addr != p_aw_a || d->aw_len != p_aw_len)) fail("AW payload changed while stalled");
    if (pv_w && d->w_valid) { u8 b[64]; get_wide(d->w_data, b, W); if (memcmp(b, p_w_data, W) || d->w_strb != p_w_strb || d->w_last != p_w_last) fail("W payload changed while stalled"); }
    pv_ar = d->ar_valid && !d->ar_ready; pv_aw = d->aw_valid && !d->aw_ready; pv_w = d->w_valid && !d->w_ready;
    if (pv_ar) { p_ar_a = d->ar_addr; p_ar_len = d->ar_len; }
    if (pv_aw) { p_aw_a = d->aw_addr; p_aw_len = d->aw_len; }
    if (pv_w) { get_wide(d->w_data, p_w_data, W); p_w_strb = d->w_strb; p_w_last = d->w_last; }

    // ---------------- AR accepted
    if (ar_hs) {
      n_ar++; int len = d->ar_len, id = d->ar_id; u64 a = d->ar_addr; int mt = d->ar_mtype; n_arb += len + 1;
      if (d->ar_size != (u32)__builtin_ctz(W)) fail("AR size %u != log2(W)", d->ar_size);
      if (d->ar_burst != 1) fail("AR burst type not INCR");
      if (a % W) fail("AR addr %llx not beat aligned", (unsigned long long)a);
      if (len + 1 > TB_BL) fail("AR burst %d beats > BURST_LENGTH", len + 1);
      if ((a & 4095) + (u64)(len + 1) * W > 4096) fail("AR burst crosses 4 KiB (addr %llx len %d)", (unsigned long long)a, len + 1);
      if (id >= TB_NR) fail("AR id %d out of range", id); else { if (rd_busy_id[id]) fail("AR id %d reused while outstanding", id); rd_busy_id[id] = true; }
      if (mt >= NMT) fail("AR mtype %d", mt);
      if (check_dom && !((dom_mask >> d->ar_domain) & 1)) fail("AR domain sideband %u not a trusted domain of this run", (unsigned)d->ar_domain);
      if (mt < NMT) {
        if (!pa_granted_any(mt, a, (u64)(len + 1) * W, false)) fail("PROTECTION: AR [%llx,+%d beats) type %d not granted to any trusted domain of this run", (unsigned long long)a, len + 1, mt);
        if (check_allow) { bool ok = false; for (auto& r : allow_rd[mt]) if (a >= r.lo && a + (u64)(len + 1) * W <= r.hi) ok = true; if (!ok) fail("STRAY READ [%llx,+%d beats) type %d outside every source envelope", (unsigned long long)a, len + 1, mt); }
      }
      RdReq r{id, a, len, mt, cyc + cfg.lat_r + (cfg.jit_r ? rng() % (cfg.jit_r + 1) : 0), 0, false, 0, -1};
      for (const Fault& f : faults) if (!f.wr && f.type == mt && a < f.hi && a + (u64)(len + 1) * W > f.lo) { r.bad = true; r.resp = f.resp; r.badbeat = f.beat; }
      rq.push_back(r);
    }
    // ---------------- R delivered
    if (r_hs) {
      n_r++; int id = d->r_id; bool found = false;
      for (size_t i = 0; i < rq.size(); i++) if (rq[i].id == id && (int)i == cur_rd) { found = true; break; }
      (void)found;
      if (cur_rd >= 0 && cur_rd < (int)rq.size()) {
        RdReq& r = rq[cur_rd];
        if (r.id == id) { r.beat++; if (r.beat == r.len + 1) { rd_busy_id[id] = false; rq.erase(rq.begin() + cur_rd); cur_rd = -1; } }
      }
    }
    // ---------------- AW accepted
    if (aw_hs) {
      n_aw++; int len = d->aw_len, id = d->aw_id; u64 a = d->aw_addr; int mt = d->aw_mtype; n_awb += len + 1; wr_seen_after_reset = true;
      if (d->aw_size != (u32)__builtin_ctz(W)) fail("AW size");
      if (d->aw_burst != 1) fail("AW burst type");
      if (a % W) fail("AW addr %llx not beat aligned", (unsigned long long)a);
      if (len + 1 > TB_BL) fail("AW burst %d beats > BURST_LENGTH", len + 1);
      if ((a & 4095) + (u64)(len + 1) * W > 4096) fail("AW burst crosses 4 KiB");
      if (id >= TB_NW) fail("AW id %d out of range", id); else { if (wr_busy_id[id]) fail("AW id %d reused while outstanding", id); wr_busy_id[id] = true; }
      if (mt >= NMT) fail("AW mtype %d", mt);
      if (check_dom && !((dom_mask >> d->aw_domain) & 1)) fail("AW domain sideband %u not a trusted domain of this run", (unsigned)d->aw_domain);
      if (mt < NMT) {
        if (!pa_granted_any(mt, a, (u64)(len + 1) * W, true)) fail("PROTECTION: AW [%llx,+%d beats) type %d not granted to any trusted domain of this run", (unsigned long long)a, len + 1, mt);
        if (check_allow) { bool ok = false; for (auto& r : allow_wr[mt]) if (a >= r.lo && a + (u64)(len + 1) * W <= r.hi) ok = true; if (!ok) fail("STRAY WRITE [%llx,+%d beats) type %d outside every destination envelope", (unsigned long long)a, len + 1, mt); }
      }
      AwReq r{id, a, len, mt, 0, 0, false, 0};
      for (const Fault& f : faults) if (f.wr && f.type == mt && a < f.hi && a + (u64)(len + 1) * W > f.lo) { r.bad = true; r.resp = f.resp; }
      awq.push_back(r);
    }
    // ---------------- W accepted
    if (w_hs) {
      n_w++; WBeat b; get_wide(d->w_data, b.data, W); b.strb = d->w_strb; b.last = d->w_last;
      if (b.strb >> W) fail("W strobe has bits above lane %d", W);
      for (int i = 0; i < W; i++) if (!((b.strb >> i) & 1) && b.data[i] != 0) { fail("W data lane %d nonzero with strobe 0 (stale data leak)", i); break; }
      if (b.strb == 0) fail("W beat with an all-zero strobe");
      wbuf.push_back(b);
    }
    // ---------------- apply W beats against accepted AWs
    while (!awq.empty() && !wbuf.empty()) {
      AwReq& a = awq.front(); WBeat b = wbuf.front(); wbuf.pop_front();
      bool last = (a.beat == a.len);
      if (b.last != last) fail("WLAST %d at beat %d of %d", b.last, a.beat, a.len + 1);
      u64 base = a.addr + (u64)a.beat * W;
      if (!a.bad) {
        for (int i = 0; i < W; i++) if ((b.strb >> i) & 1) {
          if (base + i < PHYS) { mem[a.mt].d[base + i] = b.data[i]; if (mem[a.mt].wc[base + i]++ == 0) touched.push_back({(u8)a.mt, (u32)(base + i)}); }
          else a.resp = 3;
        }
      }
      a.beat++; a.payload += __builtin_popcountll(b.strb);
      if (a.beat == a.len + 1) {
        int resp = a.bad ? a.resp : a.resp;
        bq.push_back({a.id, cyc + cfg.lat_b + (cfg.jit_b ? rng() % (cfg.jit_b + 1) : 0), resp, a.payload});
        awq.pop_front();
      }
    }
    // ---------------- B delivered
    if (b_hs) {
      n_b++; int id = d->b_id;
      for (size_t i = 0; i < bq.size(); i++) if (bq[i].id == id) { if (bq[i].resp == 0) ok_bytes += bq[i].payload; bq.erase(bq.begin() + i); break; }
      if (id < TB_NW) wr_busy_id[id] = false;
    }
    // ---------------- completion port
    if (d->cpl_valid && d->cpl_ready) {
      ExpCpl c{}; c.txn = d->cpl_txn_id; c.dom = d->cpl_domain; c.status = d->cpl_status; c.err = d->cpl_err; c.done = d->cpl_bytes_done;
      c.total = d->cpl_bytes_total; c.rec = true; c.detail = d->cpl_detail; got.push_back(c);
      // docs/04 section 2: partial == (bytes_done != 0 && status != OK), checked in the cycle the record is accepted (added after an integration run found it stale)
      if ((bool)d->cpl_partial != (c.done != 0 && c.status != ST_OK)) fail("cpl_partial=%d inconsistent with record {status %d done %llu}", (int)d->cpl_partial, c.status, (unsigned long long)c.done);
    }
    if (d->irq) irq_count++;
    if (d->soft_reset_active) bus_reset_req = true;
    if (d->guard_proto_err) fail("guard protocol error event (stale guard response)");
    // ---------------- push handshake
    if (push_hold && d->desc_valid && d->desc_ready) { push_hold = false; push_q.pop_front(); }
  }

  bool trace = getenv("TB_TRACE") != nullptr;
  void cycle() {
    drive(); d->clk = 0; d->eval();
    if (trace) {
      if (d->ar_valid && d->ar_ready) printf("  @%llu AR id=%d addr=%llx len=%d\n", (unsigned long long)cyc, (int)d->ar_id, (unsigned long long)d->ar_addr, (int)d->ar_len + 1);
      if (d->aw_valid && d->aw_ready) printf("  @%llu AW id=%d addr=%llx len=%d\n", (unsigned long long)cyc, (int)d->aw_id, (unsigned long long)d->aw_addr, (int)d->aw_len + 1);
      if (d->r_valid) printf("  @%llu R id=%d resp=%d last=%d\n", (unsigned long long)cyc, (int)d->r_id, (int)d->r_resp, (int)d->r_last);
      if (d->b_valid) printf("  @%llu B id=%d resp=%d\n", (unsigned long long)cyc, (int)d->b_id, (int)d->b_resp);
      if (d->cpl_valid && d->cpl_ready) printf("  @%llu CPL txn=%d status=%d err=%x done=%llu total=%llu\n", (unsigned long long)cyc, (int)d->cpl_txn_id, (int)d->cpl_status, (int)d->cpl_err, (unsigned long long)d->cpl_bytes_done, (unsigned long long)d->cpl_bytes_total);
    }
    observe();
    d->clk = 1; d->eval(); d->clk = 0; d->eval(); cyc++;
    if (bus_reset_req) { bus_reset_req = false; clear_slave(); }   // the platform resets the memory fabric together with the core
  }
  void cycles(int n) { while (n-- > 0) cycle(); }
  void perf_clear_now() { d->perf_clear = 1; tick_raw(); d->perf_clear = 0; }

  // spurious injections for the cycle (one-shot helper)
  bool quiescent() const { return !d->busy && push_q.empty() && !push_hold && !d->cpl_valid && rq.empty() && awq.empty() && wbuf.empty() && bq.empty(); }
};
