// =============================================================================
// StreamDMA :: tb_top -- Verilator test wrapper
//   DUT (sf_stream_dma) + the vendored CloudDMA permission table acting as the MemoryGuard.
//   Wide buses are exposed at a FIXED width (512-bit data, 64-bit strobe) so the C++ bench is independent of DATA_WIDTH.
//   guard_stall forces the guard to refuse to accept requests (guard-hang / timeout tests).
// =============================================================================
`default_nettype none
module tb_top #(
  parameter int DATA_WIDTH = 128,
  parameter int ADDR_WIDTH = 40,
  parameter int BURST_LENGTH = 16,
  parameter int FIFO_DEPTH = 64,
  parameter int MAX_OUTSTANDING_READS = 1,
  parameter int MAX_OUTSTANDING_WRITES = 1,
  parameter int DESCRIPTOR_DEPTH = 4,
  parameter int SEG_DEPTH = 2,
  parameter int PLAN_DEPTH = 1,
  parameter int WR_FIFO_DEPTH = 2 * BURST_LENGTH,
  parameter int MAX_SEG_LOG2 = 24,
  parameter int MAX_TXN_LOG2 = 30,
  parameter int GUARD_LAT = 2,
  parameter int DOM_W = 4,
  localparam int W = DATA_WIDTH / 8,
  localparam int RIDW = (MAX_OUTSTANDING_READS  > 1) ? $clog2(MAX_OUTSTANDING_READS)  : 1,
  localparam int WIDW = (MAX_OUTSTANDING_WRITES > 1) ? $clog2(MAX_OUTSTANDING_WRITES) : 1,
  localparam int TOT_W = MAX_TXN_LOG2 + 1
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            ctl_abort,
  input  wire logic            ctl_soft_reset,
  input  wire logic [31:0]     cfg_timeout,
  input  wire logic [15:0]     cfg_type_en,
  input  wire logic            guard_stall,
  // descriptor push
  input  wire logic            desc_valid,
  output logic                 desc_ready,
  input  wire logic [255:0]    desc_data,
  input  wire logic [DOM_W-1:0] desc_domain,
  // completion
  output logic                 cpl_valid,
  input  wire logic            cpl_ready,
  output logic [15:0]          cpl_txn_id,
  output logic [DOM_W-1:0]     cpl_domain,
  output logic [3:0]           cpl_status,
  output logic [7:0]           cpl_err,
  output logic [3:0]           cpl_detail,
  output logic [TOT_W-1:0]     cpl_bytes_done,
  output logic [TOT_W-1:0]     cpl_bytes_total,
  output logic [ADDR_WIDTH-1:0] cpl_err_addr,
  output logic [31:0]          cpl_latency,
  output logic                 cpl_partial,
  output logic                 irq,
  // permission table programming
  input  wire logic            tw_en,
  input  wire logic [3:0]      tw_idx,
  input  wire logic            tw_valid,
  input  wire logic [DOM_W-1:0] tw_domain,
  input  wire logic [3:0]      tw_asid,
  input  wire logic [ADDR_WIDTH-1:0] tw_base,
  input  wire logic [ADDR_WIDTH:0]   tw_size,
  input  wire logic [ADDR_WIDTH-1:0] tw_pa,
  input  wire logic [1:0]      tw_perm,
  output logic                 tw_rej,
  // AXI-style master
  output logic                 ar_valid,
  input  wire logic            ar_ready,
  output logic [RIDW-1:0]      ar_id,
  output logic [ADDR_WIDTH-1:0] ar_addr,
  output logic [7:0]           ar_len,
  output logic [2:0]           ar_size,
  output logic [1:0]           ar_burst,
  output logic [3:0]           ar_mtype,
  output logic [DOM_W-1:0]     ar_domain,
  input  wire logic            r_valid,
  output logic                 r_ready,
  input  wire logic [RIDW-1:0] r_id,
  input  wire logic [511:0]    r_data,
  input  wire logic [1:0]      r_resp,
  input  wire logic            r_last,
  output logic                 aw_valid,
  input  wire logic            aw_ready,
  output logic [WIDW-1:0]      aw_id,
  output logic [ADDR_WIDTH-1:0] aw_addr,
  output logic [7:0]           aw_len,
  output logic [2:0]           aw_size,
  output logic [1:0]           aw_burst,
  output logic [3:0]           aw_mtype,
  output logic [DOM_W-1:0]     aw_domain,
  output logic                 w_valid,
  input  wire logic            w_ready,
  output logic [511:0]         w_data,
  output logic [63:0]          w_strb,
  output logic                 w_last,
  input  wire logic            b_valid,
  output logic                 b_ready,
  input  wire logic [WIDW-1:0] b_id,
  input  wire logic [1:0]      b_resp,
  // status / perf
  output logic                 busy,
  output logic                 fenced,
  output logic                 guard_proto_err,
  output logic                 soft_reset_pending,
  output logic                 soft_reset_active,
  input  wire logic            perf_clear,
  input  wire logic [5:0]      perf_sel,
  output logic [63:0]          perf_data
);
  // guard wiring
  logic                 gq_valid, gq_ready, gq_write, gq_id, gr_valid, gr_ready, gr_id, gr_ok, gt_ready;
  logic [DOM_W-1:0]     gq_dom;
  logic [3:0]           gq_asid, gr_fault;
  logic [ADDR_WIDTH-1:0] gq_addr, gr_pa;
  logic [15:0]          gq_bytes;
  logic [31:0]          rej_count;

  sfdma_perm_table #(.AW(ADDR_WIDTH), .DOM_W(DOM_W), .IDW(1), .NENT(16), .LAT(GUARD_LAT)) u_table (
    .clk(clk), .rst_n(rst_n),
    .tw_en(tw_en), .tw_idx(tw_idx), .tw_valid(tw_valid), .tw_domain(tw_domain), .tw_asid(tw_asid),
    .tw_base(tw_base), .tw_size(tw_size), .tw_pa(tw_pa), .tw_perm(tw_perm), .tw_rej(tw_rej), .rej_count(rej_count),
    .req_valid(gq_valid && !guard_stall), .req_ready(gt_ready), .req_domain(gq_dom), .req_asid(gq_asid), .req_write(gq_write),
    .req_addr(gq_addr), .req_bytes(gq_bytes), .req_id(gq_id),
    .rsp_valid(gr_valid), .rsp_ready(gr_ready), .rsp_id(gr_id), .rsp_ok(gr_ok), .rsp_fault(gr_fault), .rsp_pa(gr_pa));
  assign gq_ready = gt_ready && !guard_stall;

  logic [DATA_WIDTH-1:0] r_data_d, w_data_d;
  logic [W-1:0]          w_strb_d;
  assign r_data_d = r_data[DATA_WIDTH-1:0];
  assign w_data   = 512'(w_data_d);
  assign w_strb   = 64'(w_strb_d);

  sf_stream_dma #(
    .DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(ADDR_WIDTH), .NUM_CHANNELS(1), .BURST_LENGTH(BURST_LENGTH), .FIFO_DEPTH(FIFO_DEPTH),
    .MAX_OUTSTANDING_READS(MAX_OUTSTANDING_READS), .MAX_OUTSTANDING_WRITES(MAX_OUTSTANDING_WRITES),
    .DESCRIPTOR_DEPTH(DESCRIPTOR_DEPTH), .DOM_W(DOM_W), .SEG_DEPTH(SEG_DEPTH), .PLAN_DEPTH(PLAN_DEPTH),
    .WR_FIFO_DEPTH(WR_FIFO_DEPTH), .MAX_SEG_LOG2(MAX_SEG_LOG2), .MAX_TXN_LOG2(MAX_TXN_LOG2)
  ) u_dut (
    .clk(clk), .rst_n(rst_n), .ctl_abort(ctl_abort), .ctl_soft_reset(ctl_soft_reset), .cfg_timeout(cfg_timeout), .cfg_type_en(cfg_type_en),
    .desc_valid(desc_valid), .desc_ready(desc_ready), .desc_data(desc_data), .desc_domain(desc_domain),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_txn_id(cpl_txn_id), .cpl_domain(cpl_domain), .cpl_status(cpl_status),
    .cpl_err(cpl_err), .cpl_detail(cpl_detail), .cpl_bytes_done(cpl_bytes_done), .cpl_bytes_total(cpl_bytes_total),
    .cpl_err_addr(cpl_err_addr), .cpl_latency(cpl_latency), .cpl_partial(cpl_partial), .irq(irq),
    .guard_req_valid(gq_valid), .guard_req_ready(gq_ready), .guard_req_domain(gq_dom), .guard_req_asid(gq_asid),
    .guard_req_write(gq_write), .guard_req_addr(gq_addr), .guard_req_bytes(gq_bytes), .guard_req_id(gq_id),
    .guard_rsp_valid(gr_valid), .guard_rsp_ready(gr_ready), .guard_rsp_id(gr_id), .guard_rsp_ok(gr_ok),
    .guard_rsp_fault(gr_fault), .guard_rsp_pa(gr_pa),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_size(ar_size),
    .ar_burst(ar_burst), .ar_mtype(ar_mtype), .ar_domain(ar_domain),
    .r_valid(r_valid), .r_ready(r_ready), .r_id(r_id), .r_data(r_data_d), .r_resp(r_resp), .r_last(r_last),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_size(aw_size),
    .aw_burst(aw_burst), .aw_mtype(aw_mtype), .aw_domain(aw_domain),
    .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data_d), .w_strb(w_strb_d), .w_last(w_last),
    .b_valid(b_valid), .b_ready(b_ready), .b_id(b_id), .b_resp(b_resp),
    .busy(busy), .fenced(fenced), .guard_proto_err(guard_proto_err), .soft_reset_pending(soft_reset_pending), .soft_reset_active(soft_reset_active),
    .perf_clear(perf_clear), .perf_sel(perf_sel), .perf_data(perf_data));
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = &{1'b0, r_data[511:DATA_WIDTH], rej_count, r_data_d[0]};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
