# StreamDMA <-> MemoryMatrix (P101) integration regression

6 configurations x 5 seeds = 30 bench runs, **ALL PASS**; 21000 descriptor streams / directed cases, 22.2 M simulated cycles, random-regression length 200. Verilator 5.020, `--x-initial unique`, MemoryMatrix internal assertions on (`-DSF_ASSERT`). Elapsed 114 s.

The memory is the vendored MemoryMatrix RTL; it is loaded and dumped through its own request port. Details: docs/10_MEMORYMATRIX_INTEGRATION.md.

| config | seed | result | runs | failed | errors | cycles |
|---|---|---|---|---|---|---|
| mm_initial | 1 | PASS | 716 | 0 | 0 | 696114 |
| mm_initial | 2 | PASS | 716 | 0 | 0 | 708107 |
| mm_initial | 3 | PASS | 716 | 0 | 0 | 744265 |
| mm_initial | 4 | PASS | 716 | 0 | 0 | 713667 |
| mm_initial | 5 | PASS | 716 | 0 | 0 | 704235 |
| mm_par4 | 1 | PASS | 716 | 0 | 0 | 643928 |
| mm_par4 | 2 | PASS | 716 | 0 | 0 | 632167 |
| mm_par4 | 3 | PASS | 716 | 0 | 0 | 644784 |
| mm_par4 | 4 | PASS | 716 | 0 | 0 | 696053 |
| mm_par4 | 5 | PASS | 716 | 0 | 0 | 666147 |
| mm_b16_l3 | 1 | PASS | 716 | 0 | 0 | 663305 |
| mm_b16_l3 | 2 | PASS | 716 | 0 | 0 | 648732 |
| mm_b16_l3 | 3 | PASS | 716 | 0 | 0 | 668065 |
| mm_b16_l3 | 4 | PASS | 716 | 0 | 0 | 686606 |
| mm_b16_l3 | 5 | PASS | 716 | 0 | 0 | 664675 |
| mm_ecc | 1 | PASS | 716 | 0 | 0 | 863910 |
| mm_ecc | 2 | PASS | 716 | 0 | 0 | 800738 |
| mm_ecc | 3 | PASS | 716 | 0 | 0 | 813577 |
| mm_ecc | 4 | PASS | 716 | 0 | 0 | 836318 |
| mm_ecc | 5 | PASS | 716 | 0 | 0 | 862642 |
| mm_dw256 | 1 | PASS | 812 | 0 | 0 | 409970 |
| mm_dw256 | 2 | PASS | 812 | 0 | 0 | 407159 |
| mm_dw256 | 3 | PASS | 812 | 0 | 0 | 403606 |
| mm_dw256 | 4 | PASS | 812 | 0 | 0 | 405364 |
| mm_dw256 | 5 | PASS | 812 | 0 | 0 | 389960 |
| mm_dw64_win2 | 1 | PASS | 524 | 0 | 0 | 1150039 |
| mm_dw64_win2 | 2 | PASS | 524 | 0 | 0 | 1153575 |
| mm_dw64_win2 | 3 | PASS | 524 | 0 | 0 | 1138721 |
| mm_dw64_win2 | 4 | PASS | 524 | 0 | 0 | 1148340 |
| mm_dw64_win2 | 5 | PASS | 524 | 0 | 0 | 1185597 |

## Test classes (summed over all configurations and seeds)

| test class | runs | failed |
|---|---|---|
| abort | 720 | 0 |
| backpressure | 1080 | 0 |
| contention | 300 | 0 |
| full_width | 210 | 0 |
| hard_reset | 960 | 0 |
| hazards | 420 | 0 |
| large | 600 | 0 |
| mm_faults | 540 | 0 |
| multi_txn | 180 | 0 |
| random_regression | 6000 | 0 |
| scatter_gather | 360 | 0 |
| single_byte | 7230 | 0 |
| soft_reset | 600 | 0 |
| unaligned | 1800 | 0 |
