# Lint report (Verilator 5.020, -Wall, third_party waived by rtl/lint.vlt only)

| configuration | warnings |
|---|---|
| default (128-bit, N=1/1) | 0 |
| DATA_WIDTH=32 BURST_LENGTH=64 FIFO_DEPTH=128 | 0 |
| DATA_WIDTH=64 N=3/2 (non power-of-two slots) | 0 |
| DATA_WIDTH=256 N=4/4 PLAN_DEPTH=2 | 0 |
| DATA_WIDTH=512 BURST_LENGTH=8 | 0 |
| ADDR_WIDTH=64 | 0 |
| ADDR_WIDTH=16 small limits | 0 |
| BURST_LENGTH=5 (non power of two) FIFO_DEPTH=8 | 0 |
| N=8/8 FIFO=256 | 0 |

## Negative elaboration tests (each must be rejected)

| illegal parameters | rejected |
|---|---|
| NUM_CHANNELS=2 | yes |
| DATA_WIDTH=48 | yes |
| DATA_WIDTH=16 | yes |
| DATA_WIDTH=1024 | yes |
| BURST_LENGTH=0 | yes |
| BURST_LENGTH=512 | yes |
| BURST_LENGTH*bytes > 4096 (DW=512 BL=128) | yes |
| FIFO_DEPTH=48 (not a power of two) | yes |
| FIFO_DEPTH < BURST_LENGTH | yes |
| WR_FIFO_DEPTH < BURST_LENGTH | yes |
| ADDR_WIDTH=8 | yes |
| MAX_OUTSTANDING_READS=0 | yes |
| DOM_W=0 | yes |

## MemoryMatrix bridge (sf_stream_dma_mm_bridge), -Wall

| configuration | warnings |
|---|---|
| default (128-bit, 40-bit DMA address, 20-bit matrix address) | 0 |
| DATA_WIDTH=256 RIDW=2 WIDW=2 AW_DEPTH=4 | 0 |
| DATA_WIDTH=64 MM_AW=16 ADDR_WIDTH=32 MM_IDW=4 | 0 |
| DATA_WIDTH=512 MM_AW=24 | 0 |

| illegal bridge parameters | rejected |
|---|---|
| ADDR_WIDTH <= MM_AW (no way to detect out-of-aperture addresses) | yes |
| MM_IDW too small for {last, id} | yes |
| DATA_WIDTH=48 | yes |
| AW_DEPTH=0 | yes |
| MM_AW=40 | yes |

| illegal integration parameters | rejected |
|---|---|
| matrix capacity == 2**MM_AW | yes |
| (control) default integration top elaborates | yes |

**All clean / all rejected as required.**
