# Formal verification results

Tools: Yosys 0.33 (built-in SAT for the sequential jobs, `yosys-smtbmc` + Z3 4.8.12 for the combinational ones). SymbiYosys is not packaged for this environment.
'exhaustive' = bit-vector SAT over ALL input values (a proof). 'BMC' = bounded model check from reset to the stated depth (a bounded proof, NOT an unbounded one).

| job | result | depth | time | engine | what |
|---|---|---|---|---|---|
| plan_dw128_bl16 | PASS | 1 | 0.3s | smt | burst planner, exhaustive |
| plan_dw32_bl64 | PASS | 1 | 0.6s | smt | burst planner, exhaustive |
| plan_dw512_bl8 | PASS | 1 | 0.6s | smt | burst planner, exhaustive |
| plan_dw64_bl3 | PASS | 1 | 0.2s | smt | burst planner, exhaustive (non power-of-two BURST_LENGTH) |
| dcheck_aw40 | PASS | 1 | 14.4s | smt | descriptor checker == acceptance rules, exhaustive |
| dcheck_aw64 | PASS | 1 | 15.1s | smt | descriptor checker, 64-bit addresses (no wrap), exhaustive |
| dcheck_aw16 | PASS | 1 | 15.2s | smt | descriptor checker, small limits, exhaustive |
| align_dw16 | PASS | 12 | 6.7s | sat | byte realigner: order / loss / duplication / strobes / zero lanes (BMC) |
| align_dw32 | PASS | 8 | 18.8s | sat | byte realigner: order / loss / duplication / strobes / zero lanes (BMC) |
| buffer_d4 | PASS | 12 | 52.5s | sat | reservation ring == shadow model; in-order visibility (BMC) |
| buffer_d8 | PASS | 9 | 27.1s | sat | reservation ring == shadow model; in-order visibility (BMC) |
| cpl | PASS | 12 | 1.9s | sat | completion engine contract (BMC) |

Not formally verified (simulation only): read/write engines, top-level integration, MemoryGuard path (vendored, verified in CloudDMA P64).
