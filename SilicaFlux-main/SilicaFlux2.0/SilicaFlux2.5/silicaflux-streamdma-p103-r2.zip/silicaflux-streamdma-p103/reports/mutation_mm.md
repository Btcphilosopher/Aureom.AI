# Mutation test: StreamDMA <-> MemoryMatrix bridge

**28 / 28 injected bugs detected** (24 by the StreamDMA system bench, 4 only by the adversarial-master unit test; config `mm_par4`, seeds 1,2, random-regression length 80, fail-fast, 249 s). The unmutated design passes both benches first (a failing baseline would 'kill' everything).

Each mutant changes ONE expression in `sf_stream_dma_mm_bridge.sv`; the integration bench must fail. The first column is what happened.

| result | mutant | injected bug | first failure |
|---|---|---|---|
| KILLED | `rd-last-dropped` | RLAST never produced (last flag lost in the request id) | seed 1: cpl[0] got {txn 1 dom 1 st 1 err 0x32 done 0 total 1} expected {txn 1 dom 1 st 0 err 0 done 1 total 1} |
| KILLED | `rd-last-always` | RLAST on every beat | seed 1: cpl[0] got {txn 3 dom 1 st 1 err 0x32 done 0 total 32} expected {txn 3 dom 1 st 0 err 0 done 32 total 32} |
| KILLED | `rd-last-off-by-one` | burst one beat too long (last-beat detection) | seed 1: STRAY READ at 0x1010 (outside every source envelope) |
| KILLED | `rd-addr-step` | read address advances by half a beat | seed 1: DATA MISMATCH pa 0xf80: got 67 expected 51 |
| KILLED | `wr-addr-step` | write address advances by half a beat | seed 1: DATA MISMATCH pa 0xf78: got 51 expected 67 |
| KILLED | `wr-strobes-ignored` | byte strobes dropped: every lane written | seed 1: COMPLETION CONTRACT: reported 1 bytes, the bus answered 16 payload bytes OKAY |
| KILLED | `wr-data-lane-swap` | write data byte lanes 0/1 swapped | seed 1: DATA MISMATCH pa 0x12000: got 00 expected 2d |
| KILLED | `w-ready-ignores-matrix` | W accepted although the matrix did not accept the beat | seed 1: COMPLETION CONTRACT: reported 3508 bytes, the bus answered 3492 payload bytes OKAY |
| KILLED | `ar-ready-always` | AR accepted while a burst is being expanded (burst overwritten) | seed 1: run did not reach quiescence (completions 0/1 busy=1) |
| KILLED | `awq-pop-early` | next AW loaded while the current burst still has beats to send | seed 1: bridge protocol error (WLAST disagrees with the AW length) |
| KILLED | `b-before-ack` | B emitted when the last beat is ACCEPTED by the matrix, not when it is performed | seed 1: COMPLETION CONTRACT: OK record while 2 write beats / 0 bursts are unacknowledged |
| KILLED | `b-resp-last-only` | B response taken from the last beat only (earlier errors forgotten) | seed 1: half-denied-burst: record status 0 err 0, expected ERROR/0x31 |
| KILLED | `rd-resp-ignored` | read errors reported as OKAY | seed 1: range-rd: record status 0 err 0, expected ERROR/0x30 |
| KILLED | `wr-resp-ignored` | write errors reported as OKAY | seed 1: range-wr: record status 0 err 0, expected ERROR/0x31 |
| KILLED | `type-check-off` | memory type not checked (fail-closed path removed) | seed 1: STRAY READ at 0x40 (outside every source envelope) |
| KILLED | `aperture-bits-off` | address bits above MM_AW ignored (aliasing into the matrix) | seed 1: STRAY READ at 0x40 (outside every source envelope) |
| KILLED | `wrap-check-off` | burst running past the top of the aperture not detected (wraps to 0) | unit test: T3: PA 0 untouched by the wrapping write: byte mismatch beat 0 lane 0 |
| KILLED | `rd-bad-not-forced` | refused read burst still issued at its own address | seed 1: STRAY READ at 0x40 (outside every source envelope) |
| KILLED | `wr-bad-not-forced` | refused write burst still issued at its own address | seed 1: STRAY WRITE at 0x40 (outside every destination envelope) |
| KILLED | `secure-rd-never` | domain never reaches the matrix on reads (secure bit stuck 0) | seed 1: cpl[0] got {txn 48 dom 2 st 1 err 0x30 done 0 total 700} expected {txn 48 dom 2 st 0 err 0 done 700 total 700} |
| KILLED | `secure-wr-never` | domain never reaches the matrix on writes (secure bit stuck 0) | seed 1: cpl[0] got {txn 49 dom 2 st 1 err 0x31 done 0 total 700} expected {txn 49 dom 2 st 0 err 0 done 700 total 700} |
| KILLED | `secure-rd-always` | every read claims to be secure (secure bit stuck 1) | seed 1: secure-rd: record status 0 err 0, expected ERROR/0x30 |
| KILLED | `secure-wr-always` | every write claims to be secure (secure bit stuck 1) | seed 1: secure-wr: record status 0 err 0, expected ERROR/0x31 |
| KILLED | `size-check-off` | beat size other than the full width not refused (only a non-DMA master can send it) | unit test: T4 size read: beat 0 response 0, expected DECERR(11) |
| KILLED | `burst-type-off` | burst type other than INCR not refused (only a non-DMA master can send it) | unit test: T5 FIXED read: beat 0 response 0, expected DECERR(11) |
| KILLED | `proto-check-off` | WLAST disagreeing with the AW length not flagged | unit test: T8: WLAST on the first beat of a 2-beat burst must raise proto_err |
| KILLED | `rid-wrong-bit` | RID taken from the wrong id bits | seed 1: run did not reach quiescence (completions 0/1 busy=1) |
| KILLED | `bid-lost` | BID not carried through the matrix (always 0) | seed 1: run did not reach quiescence (completions 0/1 busy=1) |
