from pathlib import Path

from conftest import FIX, ROOT
from timingflow import sdc_lint as L


def _lint(tmp_path, text, **kw):
    p = tmp_path / "t.sdc"
    p.write_text(text)
    return L.lint(p, **kw)


def test_generated_reference_sdc_is_clean_of_fails():
    r = L.lint(FIX / "gcd_func_pre_cts.sdc", registry_ids=set())
    assert r.status() in ("PASS", "WARNING")
    assert not [f for f in r.findings if f.severity == "FAIL"]


def test_legacy_v1_sdc_findings():
    r = L.lint(ROOT / "third_party" / "silicaflux-v1" / "synth" / "silicaflux.sdc", registry_ids=set())
    rules = {f.rule for f in r.findings}
    assert "L13-unregistered-exception" in rules and "L08-hier-filter" in rules


def test_duplicate_clock(tmp_path):
    r = _lint(tmp_path, "create_clock -name c -period 5 [get_ports a]\ncreate_clock -name c -period 5 [get_ports b]\n")
    assert any(f.rule == "L01-duplicate-clock" for f in r.findings)


def test_unknown_clock_and_zero_delay(tmp_path):
    r = _lint(tmp_path, "create_clock -name c -period 5 [get_ports a]\nset_input_delay 0 -clock d [get_ports x]\n")
    rules = {f.rule for f in r.findings}
    assert "L02-unknown-clock" in rules and "L03-zero-io-delay" in rules


def test_unbounded_and_broad_exception(tmp_path):
    r = _lint(tmp_path, "set_false_path -setup\nset_false_path -to [all_registers]\n")
    rules = {f.rule for f in r.findings}
    assert "L06-unbounded-exception" in rules and "L07-broad-exception" in rules
    assert r.status() == "FAIL"


def test_multicycle_needs_hold(tmp_path):
    r = _lint(tmp_path, "create_clock -name c -period 5 [get_ports a]\nset_multicycle_path -setup 2 -from [get_pins x/Q] -to [get_pins y/D]\n")
    assert any(f.rule == "L11-mcp-no-hold" for f in r.findings)
    r2 = _lint(tmp_path, "create_clock -name c -period 5 [get_ports a]\nset_multicycle_path -setup 2 -from [get_pins x/Q] -to [get_pins y/D]\n"
                         "set_multicycle_path -hold 1 -from [get_pins x/Q] -to [get_pins y/D]\n")
    assert not any(f.rule == "L11-mcp-no-hold" for f in r2.findings)


def test_ignored_command_flagged(tmp_path):
    r = _lint(tmp_path, "set_ideal_network [get_pins u/GCLK]\n")
    assert any(f.rule == "L09-ignored-command" for f in r.findings)


def test_tokenizer_continuations_and_comments():
    cmds = L.parse("# c\ncreate_clock -name a \\\n  -period 2 [get_ports {x y}] ;# tail\nset_load 0.1 [all_outputs]\n")
    assert [c.name for c in cmds] == ["create_clock", "set_load"]
    assert cmds[0].opt("-period") == "2"
