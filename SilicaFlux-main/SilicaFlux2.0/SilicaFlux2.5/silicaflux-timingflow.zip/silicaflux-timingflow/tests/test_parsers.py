import json

from conftest import FIX
from timingflow import parse_reports as P


def test_ends_parse_real_gcd():
    rows = P.parse_ends(FIX / "gcd_sta" / "ends_setup_func_tt.rpt")
    assert rows and rows[0]["group"] == "core_clock" and rows[0]["check"] == "setup"
    assert rows[0]["slack_ns"] == -1.2297 and rows[0]["violated"]
    assert any(r["ref"] == "output" for r in rows)
    g = P.group_stats(rows)
    assert g["setup:core_clock"]["wns_ns"] == -1.2297
    assert g["setup:core_clock"]["violators"] == sum(r["violated"] for r in rows)


def test_ends_parse_inf_unconstrained():
    rows = P.parse_ends(FIX / "sfv_sta" / "rdc_unconstrained_head.rpt")
    assert rows, "INF rows must parse"
    assert any(r["slack_ns"] == float("inf") for r in rows)


def test_check_setup():
    cs = P.parse_check_setup(FIX / "sfv_sta" / "check_setup_func.rpt")
    assert cs["input_no_delay"]["items"] == ["rst_ni"]
    assert cs["unconstrained_endpoints"]["count"] == 1


def test_drv_and_pulse():
    d = P.parse_drv(FIX / "sfv_sta" / "drv_func_slow.rpt")
    assert d["max_slew"]["violators"] > 0 and d["max_slew"]["worst_slack"] < 0
    assert "max_capacitance" in d
    p = P.parse_pulse(FIX / "sfv_sta" / "pulse_func_slow.rpt")
    assert p["violators"] > 0 and p["items"][0]["phase"] in ("high", "low")


def test_skew_latency_power():
    s = P.parse_skew(FIX / "sfv_sta" / "skew_setup_func_slow.rpt")
    assert "clk" in s and "setup_skew" in s["clk"]
    assert s["spi_sck"]["found"] is False
    lat = P.parse_latency(FIX / "sfv_sta" / "latency_func_typ.rpt")
    assert lat["clk"]["max_ns"] >= lat["clk"]["min_ns"]
    pw = P.parse_power(FIX / "sfv_sta" / "power_func_typ.rpt")
    assert pw["groups"]["Total"]["total_w"] > 0


def test_paths_json_and_text_merge():
    jp = P.parse_paths_json(FIX / "gcd_sta" / "paths_setup_func_tt.json")
    tp = P.parse_paths_text(FIX / "gcd_sta" / "paths_setup_func_tt.rpt")
    assert jp and tp
    p = jp[0]
    assert p["check"] == "setup" and p["points"][0]["arc"] == "start"
    assert abs(p["cell_delay_ns"] + p["net_delay_ns"] - (p["points"][-1]["arrival_ns"] - p["points"][0]["arrival_ns"])) < 1e-6
    P.merge_fanout(jp, tp)
    assert any(pt.get("fanout") for pt in jp[0]["points"])
    assert all(t.get("endpoint") for t in tp)


def test_text_paths_columns():
    tp = P.parse_paths_text(FIX / "sfv_sta" / "paths_hold_func_typ_head.rpt")
    assert tp[0]["path_type"] == "min"
    assert any(pt["fanout"] for pt in tp[0]["points"])
