import pytest

from conftest import needs_orfs
from timingflow import config as C, sdc_gen as G


def test_all_configs_load():
    for d in C.list_designs():
        C.load_design(d)
    assert C.load_design("mcu_i").status == "NOT_FOUND"
    for p in C.list_platforms():
        C.load_platform(p)


def test_registry_ids_unique_and_evidence():
    ex = C.load_exceptions(C.load_design("silicaflux_v"))
    assert len({e.id for e in ex.exceptions}) == len(ex.exceptions)
    assert all(e.rtl_evidence for e in ex.exceptions)


def test_sdc_match():
    assert G.sdc_match("gpio_i[3]", "gpio_i[*]") and not G.sdc_match("gpio_i", "gpio_i[*]")


@needs_orfs
@pytest.mark.parametrize("stage,cls", [("synthesis", "pre_cts"), ("cts", "post_cts")])
def test_generate_func(stage, cls):
    d = C.load_design("silicaflux_v")
    p = C.load_platform("ihp_sg13g2")
    m = [x for x in d.modes if x.name == "func"][0]
    ports = {"clk": "input", "tck": "input", "rst_ni": "input", "test_mode": "input", "uart_rx": "input",
             "spi_miso": "input", "tms": "input", "tdi": "input", "uart_tx": "output", "spi_sck": "output",
             "spi_mosi": "output", "spi_cs0_n": "output", "tdo": "output", "tdo_oe": "output",
             "cpu_sleep": "output", "test_pass": "output", "test_fail": "output", "gpio_i[0]": "input",
             "gpio_o[0]": "output", "gpio_oe[0]": "output", "test_status[0]": "output"}
    r = G.generate(d, p, m, stage, C.load_io(d), C.load_exceptions(d), ["typ", "slow", "fast"], ports)
    assert r.stage_class == cls
    assert "create_clock -name clk -period 20" in r.text
    assert "create_generated_clock -name spi_sck" in r.text
    if cls == "post_cts":
        assert "set_propagated_clock [all_clocks]" in r.text and "set_clock_transition" not in r.text
        assert "set_clock_uncertainty -setup 0.1 [get_clocks {clk}]" in r.text
    else:
        assert "set_clock_uncertainty -setup 0.25 [get_clocks {clk}]" in r.text
    assert 'set_false_path -comment "EXC-SFV-002"' in r.text
    assert "set_case_analysis 0 [get_ports {test_mode}]" in r.text
    assert "set_multicycle_path -hold -start 1" in r.text
    assert r.uncovered_ports == []
    assert "EXC-SFV-006" not in r.applied_exceptions  # test-mode only


@needs_orfs
def test_generate_test_mode_case():
    d = C.load_design("silicaflux_v")
    p = C.load_platform("ihp_sg13g2")
    m = [x for x in d.modes if x.name == "test"][0]
    r = G.generate(d, p, m, "synthesis", C.load_io(d), C.load_exceptions(d), ["typ"])
    assert "set_case_analysis 1 [get_ports {test_mode}]" in r.text
    assert "EXC-SFV-002" not in r.applied_exceptions
