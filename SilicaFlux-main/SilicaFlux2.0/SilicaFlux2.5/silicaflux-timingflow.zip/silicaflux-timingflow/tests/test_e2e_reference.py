"""End-to-end on the PUBLIC reference design (ORFS gcd, sky130hd).
A passing reference run is not a SilicaFlux timing result."""
import json

from conftest import needs_tools, slow
from timingflow import flow


@needs_tools
@slow
def test_reference_gcd_stage_a():
    for s in ("synth", "synthesis", "check_sdc"):
        r = flow.run_stage("ref_gcd", "sky130hd", s, "ci_reference")
        assert r["status"] == "PASS", r
    rd = flow.run_dir_for("ref_gcd", "sky130hd", "ci_reference")
    sm = json.loads((rd / "sta_synthesis" / "summary.json").read_text())
    assert sm["label"] == "POST-SYNTHESIS" and "func_tt" in sm["scenes"]
    assert sm["provenance"]["tools"]["opensta"]
