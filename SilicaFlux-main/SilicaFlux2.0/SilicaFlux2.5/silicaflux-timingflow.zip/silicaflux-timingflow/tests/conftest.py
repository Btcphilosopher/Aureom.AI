import os
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
FIX = ROOT / "tests" / "fixtures"


def have_orfs() -> bool:
    from timingflow.paths import env
    return Path(env("ORFS_PLATFORMS"), "ihp-sg13g2", "lib").exists()


def have_tools() -> bool:
    from timingflow.paths import env
    return bool(shutil.which(env("YOSYS"))) and Path(env("STA")).exists()


needs_orfs = pytest.mark.skipif(not have_orfs(), reason="ORFS platform collateral not available (set ORFS_PLATFORMS)")
needs_tools = pytest.mark.skipif(not (have_orfs() and have_tools()), reason="yosys/OpenSTA/ORFS not available")
slow = pytest.mark.skipif(os.environ.get("RUN_SLOW") != "1", reason="slow end-to-end test: set RUN_SLOW=1")
