import json

from conftest import needs_orfs
from timingflow import config as C, gates, physical


@needs_orfs
def test_gates_not_run_without_evidence(tmp_path):
    d, p = C.load_design("silicaflux_v"), C.load_platform("ihp_sg13g2")
    r = gates.evaluate(d, p, tmp_path)
    assert all(g["status"] in ("NOT RUN", "FAIL") for g in r["gates"])
    assert r["signoff"] == "NOT ACHIEVED"


@needs_orfs
def test_signoff_gates_need_postroute(tmp_path):
    d, p = C.load_design("silicaflux_v"), C.load_platform("ihp_sg13g2")
    sd = tmp_path / "sta_synthesis"
    sd.mkdir()
    sd.joinpath("summary.json").write_text(json.dumps({"status": "PASS", "label": "POST-SYNTHESIS", "scenes": {
        "func_typ": {"setup_all": {"wns_ns": 5.0, "violators": 0}, "hold_all": {"wns_ns": 1.0, "violators": 0}}},
        "provenance": {"tools": {"x": 1}}}))
    r = gates.evaluate(d, p, tmp_path)
    g = {x["gate"]: x for x in r["gates"]}
    assert g[7]["status"] == "PASS"
    assert g[13]["status"] == "NOT RUN" and g[14]["status"] == "NOT RUN"   # positive pre-route slack cannot pass signoff


@needs_orfs
def test_physical_prereqs(tmp_path, monkeypatch):
    d, p = C.load_design("silicaflux_v"), C.load_platform("ihp_sg13g2")
    monkeypatch.setattr(physical, "openroad_available", lambda: (True, "openroad"))
    r = physical.run_stage(d, p, tmp_path, "postroute")
    assert r["status"] == "NOT RUN" and "4_grt.odb" in r["reason"]
    r = physical.run_stage(d, p, tmp_path, "placement")
    assert r["status"] == "NOT RUN" and "netlist" in r["reason"]
