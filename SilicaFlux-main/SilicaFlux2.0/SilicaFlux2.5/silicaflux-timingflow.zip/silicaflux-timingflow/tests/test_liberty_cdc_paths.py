from conftest import FIX, needs_orfs
from timingflow import cdc, critical_paths as CP, liberty
from timingflow.config import BlockMapEntry

LIB = """library (t) {
  time_unit : "1ns" ;
  capacitive_load_unit (1,pf) ;
  nom_voltage : 1.2 ;
  cell (dff_r) { area : 2 ; ff (IQ,IQN) { next_state : "D" ; clocked_on : "CLK" ; clear : "!RESET_B" ; }
     pin (D) { direction : input ; capacitance : 0.002 ; } pin (Q) { direction : output ; } }
  cell (icg) { clock_gating_integrated_cell : "latch_posedge" ; area : 3 ; }
  cell (lat) { latch (IQ,IQN) { enable : "G" ; data_in : "D" ; } }
  cell (nand2) { area : 1 ; pin (A) { direction : input ; capacitance : 0.0013 ; } }
}
"""


def test_liberty_utils(tmp_path):
    p = tmp_path / "t.lib"
    p.write_text(LIB)
    info = liberty.read_info(p)
    assert info.name == "t" and info.nom_voltage == 1.2 and info.cells == ["dff_r", "icg", "lat", "nand2"]
    assert liberty.cell_classes(p) == {"dff_r": "ff", "icg": "icg", "lat": "latch", "nand2": "comb"}
    assert liberty.async_pins(p) == {"dff_r": {"RESET_B"}}
    assert liberty.pin_capacitance(p, "nand2", "A") == 0.0013
    marked = liberty.mark_dont_use(p, tmp_path / "s.lib", ["icg", "lat"])
    assert marked == ["icg", "lat"] and (tmp_path / "s.lib").read_text().count("dont_use : true") == 2


def _path(cells, ep="u_dbg/s0_reg/D", cap="tck"):
    pts = [{"pin": "u_cpu/a_reg/CLK", "instance": "u_cpu/a_reg", "cell": "dff", "arc": "start", "incr_ns": 0}]
    pts.append({"pin": "u_cpu/a_reg/Q", "instance": "u_cpu/a_reg", "cell": "dff", "arc": "cell", "incr_ns": 0.2})
    for i, c in enumerate(cells):
        pts.append({"pin": f"g{i}/A", "instance": f"g{i}", "cell": c, "arc": "net", "incr_ns": 0})
        pts.append({"pin": f"g{i}/Y", "instance": f"g{i}", "cell": c, "arc": "cell", "incr_ns": 0.1})
    pts.append({"pin": ep, "instance": ep.rsplit("/", 1)[0], "cell": "dff", "arc": "net", "incr_ns": 0})
    return {"startpoint": "u_cpu/a_reg/Q", "endpoint": ep, "launch_clock": "clk", "capture_clock": cap, "points": pts}


def test_cdc_classification():
    second = {"u_dbg/s0_reg": [{"pin": "u_dbg/s1_reg/D", "is_register": True, "clocks": ["tck"]}]}
    assert cdc.classify_crossing(_path(["buf_2"]), second)["class"] == "SYNC_2FF"
    assert cdc.classify_crossing(_path(["nand2_1"]), second)["class"] == "LOGIC_BEFORE_SYNC"
    many = {"u_dbg/s0_reg": [{"pin": "x/A", "is_register": False, "clocks": []}, {"pin": "y/A", "is_register": False, "clocks": []}]}
    assert cdc.classify_crossing(_path(["nand2_1"]), many)["class"] == "QUASI_STATIC_DATA"


def test_block_mapper():
    m = CP.BlockMapper([BlockMapEntry(prefix="u_tile/u_ve/", block="VECTOR"), BlockMapEntry(prefix="u_tile/", block="SRAM"),
                        BlockMapEntry(prefix="g_sram", block="SRAM", sub="bank")], {"clk", "rst_ni", "gpio_o[0]"})
    assert m.classify("u_tile/u_ve/x_reg/D")[0] == "VECTOR"
    assert m.classify("u_tile/arb_reg/Q")[0] == "SRAM"
    assert m.classify("g_sram[2].u_bank/rd_q_reg/Q") == ("SRAM", "bank")
    assert m.classify("gpio_o[0]")[0] == "IO"
    assert m.classify("u_unknown/x/Y")[0] == "UNKNOWN"


def test_classify_real_path():
    from timingflow.parse_reports import parse_paths_json
    paths = parse_paths_json(FIX / "sfv_sta" / "paths_setup_func_slow_head.json")
    m = CP.BlockMapper([BlockMapEntry(prefix="u_tile/u_te/", block="TENSOR"), BlockMapEntry(prefix="u_cpu/", block="CPU")])
    r = CP.rank_paths(paths, m, fanout_limit=8)
    assert r and r[0]["rank"] == 1 and r[0]["dominance"].startswith("cell")


def test_block_bottlenecks_exclude_recovery():
    """A design-wide reset problem must not mask a block's clocked data slack."""
    m = CP.BlockMapper([BlockMapEntry(prefix="u_xbar/", block="DATAFABRIC"), BlockMapEntry(prefix="u_cpu/", block="CPU")], set())
    rows = [{"check": "setup", "group": "asynchronous", "endpoint": "u_xbar/pend_q_reg/RESET_B", "slack_ns": -51.09, "violated": True},
            {"check": "setup", "group": "clk", "endpoint": "u_xbar/rdata_reg/D", "slack_ns": 9.07, "violated": False},
            {"check": "setup", "group": "clk", "endpoint": "u_cpu/rf_reg/D", "slack_ns": 5.88, "violated": False},
            {"check": "hold", "group": "clk", "endpoint": "u_cpu/rf_reg/D", "slack_ns": -0.1, "violated": True}]
    allg = {b["block"]: b for b in CP.block_bottlenecks(rows, m, "setup")}
    assert allg["DATAFABRIC"]["wns_ns"] == -51.09 and allg["DATAFABRIC"]["violators"] == 1
    clk = CP.block_bottlenecks(rows, m, "setup", {"asynchronous"})
    assert [b["block"] for b in clk] == ["CPU", "DATAFABRIC"]
    assert {b["block"]: b["wns_ns"] for b in clk} == {"CPU": 5.88, "DATAFABRIC": 9.07}
    assert all(b["violators"] == 0 for b in clk)
