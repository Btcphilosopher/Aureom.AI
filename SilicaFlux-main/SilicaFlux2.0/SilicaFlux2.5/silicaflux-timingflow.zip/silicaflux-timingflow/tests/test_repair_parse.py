"""repair_result.tcl parsing on a real OpenROAD repair_timing run (blk_cpu, IHP SG13G2, POST-GLOBAL-ROUTE)."""
from pathlib import Path

from timingflow.physical import parse_repair_result

FIX = Path(__file__).parent / "fixtures" / "cpu_repair_setup"


def test_parse_real_repair_result():
    r = parse_repair_result(FIX)
    assert r["accepted"] and r["legal"]
    b, a = r["before"]["scenes"], r["after"]["scenes"]
    assert set(b) == {"func_typ", "func_slow", "func_fast"}
    assert b["func_slow"][0] == -2.043577 and a["func_slow"][0] == -0.285319
    # hold (index 2) untouched by the setup repair in every scene
    assert all(b[s][2] == a[s][2] for s in b)
    assert r["after"]["cells"] - r["before"]["cells"] == 7


def test_missing_result_is_none(tmp_path):
    assert parse_repair_result(tmp_path) is None
