import yaml

from timingflow import compare, optimise


def test_pareto():
    c = [{"label": "a", "status": "PASS", "reg2reg_setup_wns_ns": 5.0, "area_um2": 100},
         {"label": "b", "status": "PASS", "reg2reg_setup_wns_ns": 6.0, "area_um2": 120},
         {"label": "c", "status": "PASS", "reg2reg_setup_wns_ns": 4.0, "area_um2": 130},   # dominated by a
         {"label": "d", "status": "REJECTED", "reg2reg_setup_wns_ns": 9.0, "area_um2": 50}]
    optimise.pareto(c, {"reg2reg_setup_wns_ns": "max", "area_um2": "min"})
    assert [x["label"] for x in c if x["pareto"]] == ["a", "b"]


def test_rejections_without_running(tmp_path, monkeypatch):
    monkeypatch.setattr(optimise, "REPORTS_DIR", tmp_path)
    e = {"name": "t", "design": "blk_vec", "stage": "synthesis",
         "constraints": [{"param": "MUL_W", "allowed": [32], "reason": "ISA-visible"}],
         "candidates": [{"label": "bad_period", "period": 10.0},
                        {"label": "bad_param", "params": {"MUL_W": 16}},
                        {"label": "ok", "params": {"MUL_W": 32}}]}
    p = tmp_path / "e.yaml"
    p.write_text(yaml.safe_dump(e))
    r = optimise.run_experiment(p, dry_run=True)
    st = {c["label"]: (c["status"], c.get("reject_reason", "")) for c in r["candidates"]}
    assert st["bad_period"][0] == "REJECTED" and "clock constraint" in st["bad_period"][1]
    assert st["bad_param"][0] == "REJECTED" and "ISA-visible" in st["bad_param"][1]
    assert st["ok"][0] == "NOT RUN"


def test_compare_refuses_different_constraints():
    a = {"platform": "x", "scenes": {"s": {}}, "parasitics": "p",
         "provenance": {"liberty_sha256_16": {"t": 1}, "tools": {"opensta": "3.1.0"}, "config_digest": {"io": "1", "exceptions": "2"}}}
    b = {**a, "provenance": {**a["provenance"], "config_digest": {"io": "9", "exceptions": "2"}}}
    assert compare.comparable(a, a) == []
    assert "IO assumptions or exception registry differ" in compare.comparable(a, b)


def test_pareto_tolerance_treats_noise_as_equal():
    # exp E numbers: ARB0 is 0.573 ns and 8,796 um2 "better" -- both inside the measured noise floor
    c = [{"label": "ARB1", "status": "PASS", "reg2reg_setup_wns_ns": 3.878, "area_um2": 5767105.0},
         {"label": "ARB0", "status": "PASS", "reg2reg_setup_wns_ns": 4.452, "area_um2": 5758309.0}]
    obj = {"reg2reg_setup_wns_ns": "max", "area_um2": "min"}
    optimise.pareto(c, obj)
    assert [x["pareto"] for x in c] == [False, True]
    optimise.pareto(c, obj, {"reg2reg_setup_wns_ns": 0.6, "area_um2": 28836})
    assert [x["pareto"] for x in c] == [True, True]
    # a gain larger than the tolerance still dominates
    c[1]["reg2reg_setup_wns_ns"] = 5.0
    optimise.pareto(c, obj, {"reg2reg_setup_wns_ns": 0.6, "area_um2": 28836})
    assert [x["pareto"] for x in c] == [False, True]
