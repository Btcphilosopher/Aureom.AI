# TimingFlow: controlled timing repair on a stage database.
#   tf(repair_kind) setup|hold ; tf(repair_stage) placement|cts|global_route
#   tf(max_iter) iteration cap ; tf(max_buffer_pct) buffer budget (% of instances)
#   tf(setup_margin) ns of extra setup target (0 = repair violations only) ; tf(repair_tag) output-name suffix
#   tf(drv_first) 1 = run repair_design (max slew/cap/fanout, wire length) on the stage parasitics before
#                 repair_timing, as ORFS does after global routing
# Rollback: if any scene's opposite check (hold for setup repair, setup for hold
# repair) gets worse by more than tf(rollback_margin) ns, the repaired database
# is NOT written and the run reports ROLLED_BACK.
set tf_dir [file dirname [file normalize [info script]]]
source $tf_dir/tf_util.tcl
source $::env(TF_RUN_VARS)
source $tf_dir/load_design.tcl
source $tf_dir/load_corners.tcl
source $tf_dir/report_paths.tcl
if {[info exists ::tf_repair_kind_override]} { set tf(repair_kind) $::tf_repair_kind_override }
set db [dict get {placement 2_place.odb cts 3_cts.odb global_route 4_grt.odb} $tf(repair_stage)]
if {$tf(repair_kind) eq "hold" && $tf(repair_stage) eq "placement"} {
  error "TF-PREREQ: hold repair needs propagated clocks (run CTS first); refusing ideal-clock hold repair"
}
set tf(odb) $tf(pnr_dir)/$db
tf::load_physical
tf::load_modes_and_scenes
source $tf(setrc)
if {$tf(repair_stage) eq "global_route"} { estimate_parasitics -global_routing } else { estimate_parasitics -placement }
proc tf::snap {tag} {
  global tf
  set rows {}
  foreach s $tf(scenes) {
    set sc [sta::find_scene $s]
    lappend rows $s [list [tf::ns [sta::worst_slack_scene $sc max]] [tf::ns [sta::total_negative_slack_scene_cmd $sc max]] \
                          [tf::ns [sta::worst_slack_scene $sc min]] [tf::ns [sta::total_negative_slack_scene_cmd $sc min]]]
  }
  set n 0; set nb 0; set area 0
  foreach inst [get_cells -hierarchical *] {
    incr n
    if {[get_property $inst is_buffer] || [get_property $inst is_inverter]} { incr nb }
    catch {set area [expr {$area + [get_property [get_lib_cells -of_objects $inst] area]}]}
  }
  return [list scenes $rows cells $n buffers $nb area $area]
}
set before [tf::snap before]
set t0 [clock seconds]
if {[info exists tf(drv_first)] && $tf(drv_first)} {
  tf::log "repair_design before repair_timing (stage parasitics)"
  repair_design -max_wire_length $tf(max_wire_um)
}
if {$tf(repair_kind) eq "setup"} {
  set sm [expr {[info exists tf(setup_margin)] ? $tf(setup_margin) : 0}]
  repair_timing -setup -max_passes $tf(max_iter) -max_buffer_percent $tf(max_buffer_pct) -setup_margin $sm
} else {
  repair_timing -hold -max_passes $tf(max_iter) -max_buffer_percent $tf(max_buffer_pct) -hold_margin $tf(hold_margin)
}
detailed_placement
set legal [expr {![catch {check_placement}]}]
if {$tf(repair_stage) eq "global_route"} { estimate_parasitics -global_routing } else { estimate_parasitics -placement }
set after [tf::snap after]
set rolled 0
foreach {s b} [dict get $before scenes] {
  set a [dict get [dict get $after scenes] $s]
  set idx [expr {$tf(repair_kind) eq "setup" ? 2 : 0}]
  set bv [lindex $b $idx]; set av [lindex $a $idx]
  if {$bv ne "" && $av ne "" && $av < $bv - $tf(rollback_margin) && $av < 0} { set rolled 1; tf::log "rollback trigger: $s opposite check $bv -> $av" }
}
if {!$legal} { set rolled 1; tf::log "rollback trigger: placement not legal" }
set f [open $tf(outdir)/repair_result.tcl w]
puts $f [list set r(before) $before]; puts $f [list set r(after) $after]
puts $f [list set r(legal) $legal]; puts $f [list set r(rolled_back) $rolled]; puts $f [list set r(seconds) [expr {[clock seconds]-$t0}]]
close $f
if {!$rolled} {
  set tag [expr {[info exists tf(repair_tag)] ? $tf(repair_tag) : ""}]
  write_db $tf(pnr_dir)/[file rootname $db]_repair_$tf(repair_kind)$tag.odb
  foreach s $tf(scenes) { tf::report_scene $s $tf(outdir) }
}
tf::tool_info $tf(outdir)/tool_info.json
tf::log "DONE"
