# TimingFlow: analysis-only STA of an existing OpenROAD stage database.
# The parasitic source is fixed by the stage (never chosen freely):
#   placement     estimate_parasitics -placement   (ideal clocks)
#   cts           estimate_parasitics -placement   (propagated clocks)
#   global_route  estimate_parasitics -global_routing (needs global routes in the DB)
#   postroute     extracted SPEF from extract_parasitics (needs 5_route_<corner>.spef)
set tf_dir [file dirname [file normalize [info script]]]
source $tf_dir/tf_util.tcl
source $::env(TF_RUN_VARS)
source $tf_dir/load_design.tcl
source $tf_dir/load_corners.tcl
source $tf_dir/validate_constraints.tcl
source $tf_dir/report_paths.tcl
if {[info exists ::tf_stage_override]} { set tf(stage) $::tf_stage_override }
set db [dict get {placement 2_place.odb cts 3_cts.odb global_route 4_grt.odb postroute 5_route.odb} $tf(stage)]
set tf(odb) $tf(pnr_dir)/$db
tf::load_physical
if {$tf(stage) eq "postroute"} {
  foreach c $tf(corners) {
    if {![file exists $tf(spef,$c)]} { error "TF-PREREQ: no extracted SPEF for corner $c — POST-ROUTE analysis refused" }
  }
}
tf::load_modes_and_scenes
source $tf(setrc)
switch -- $tf(stage) {
  placement    { estimate_parasitics -placement }
  cts          { estimate_parasitics -placement }
  global_route { estimate_parasitics -global_routing }
  postroute    { }
}
tf::validate $tf(outdir)
foreach s $tf(scenes) { tf::report_scene $s $tf(outdir) }
tf::report_design $tf(outdir)
tf::tool_info $tf(outdir)/tool_info.json
tf::log "DONE"
