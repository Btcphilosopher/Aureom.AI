# TimingFlow Tcl utilities — shared by OpenSTA (stage A) and OpenROAD (B-E).
# Every command a script depends on is probed with tf::require before use, so
# an unsupported tool revision fails with a clear message instead of a
# half-written report.

namespace eval tf {
  variable unsupported {}
}

proc tf::log {msg} { puts "TF: $msg"; flush stdout }

proc tf::has {cmd} {
  return [expr {[llength [info commands $cmd]] > 0 || [llength [info commands ::$cmd]] > 0}]
}

proc tf::require {cmd} {
  if {![tf::has $cmd]} {
    error "TF-UNSUPPORTED: command '$cmd' is not available in this tool revision"
  }
}

# Run a command only if supported; record the gap otherwise.
proc tf::try_cmd {cmd args} {
  variable unsupported
  if {![tf::has $cmd]} {
    lappend unsupported $cmd
    tf::log "NOT SUPPORTED in this revision: $cmd (skipped)"
    return 0
  }
  uplevel 1 [list $cmd {*}$args]
  return 1
}

proc tf::jstr {s} {
  set s [string map {\\ \\\\ \" \\\" \n \\n \r \\r \t \\t} $s]
  return "\"$s\""
}

proc tf::jnum {v} {
  if {$v eq "" || [string match -nocase *inf* $v] || [string match -nocase *nan* $v]} { return null }
  if {[string is double -strict $v]} { return $v }
  return null
}

proc tf::jarr_str {lst} {
  set parts {}
  foreach x $lst { lappend parts [tf::jstr $x] }
  return "\[[join $parts ,]\]"
}

# kv: list of {key type value}; type in s n b a o (o = raw JSON)
proc tf::jobj {kv} {
  set parts {}
  foreach {k t v} $kv {
    switch -- $t {
      s { set j [tf::jstr $v] }
      n { set j [tf::jnum $v] }
      b { set j [expr {$v ? "true" : "false"}] }
      a { set j [tf::jarr_str $v] }
      o { set j $v }
      default { error "bad json type $t" }
    }
    lappend parts "[tf::jstr $k]: $j"
  }
  return "\{[join $parts {, }]\}"
}

proc tf::write_file {path text} {
  set f [open $path w]; puts $f $text; close $f
}

# seconds (OpenSTA API, SI) -> ns
proc tf::ns {v} {
  if {$v eq "" || [string match -nocase *inf* $v]} { return "" }
  return [format %.6f [expr {$v * 1e9}]]
}

# Capture all output of a script into a file (works for commands without >).
proc tf::capture {path script} {
  sta::redirect_file_begin $path
  set rc [catch {uplevel 1 $script} err]
  sta::redirect_file_end
  if {$rc} { tf::log "capture($path) error: $err" }
  return $rc
}

proc tf::tool_info {path} {
  variable unsupported
  set ver ""; set sha ""
  catch {set ver [sta::version]}
  catch {set sha [sta::git_sha1]}
  set orv ""
  catch {set orv [ord::openroad_version]}
  set probe {}
  foreach c {define_scene define_corners read_spef estimate_parasitics repair_design repair_timing
             clock_tree_synthesis global_route detailed_route extract_parasitics report_clock_skew
             report_check_types check_setup report_power set_propagated_clock write_sdc} {
    lappend probe $c [tf::has $c]
  }
  set pj {}
  foreach {c v} $probe { lappend pj $c b $v }
  tf::write_file $path [tf::jobj [list sta_version s $ver sta_git s $sha openroad_version s $orv \
    commands o [tf::jobj $pj] unsupported_used a $unsupported]]
}
