# TimingFlow: exception-impact and structural CDC/RDC data collection (OpenSTA).
#
# Runs on the post-synthesis netlist with a *bare* SDC per mode = the generated
# SDC minus every registry exception (clocks, IO delays and case analysis kept).
# Nothing here changes timing results; it measures what each exception hides
# and exposes every clock-domain and reset-domain crossing for review.
#
# Outputs (tf(outdir)):
#   impact_<id>_<scene>_{setup,hold}.rpt   endpoints the exception's path spec covers
#   impact_objects.json                    object counts per exception reference
#   cdc_<from>__<to>.json                  crossing paths (one per endpoint), JSON
#   cdc_async_in_<port>.json               async input port -> first register paths
#   cdc_endpoint_loads.json                fanout of each crossing endpoint register
#   rdc_async.rpt / rdc_async.json         recovery/removal paths without exceptions
#
# Usage: TF_RUN_VARS=<vars> sta -no_splash -exit tcl/constraint_analysis.tcl

set tf_dir [file dirname [file normalize [info script]]]
source $tf_dir/tf_util.tcl
source $::env(TF_RUN_VARS)
source $tf_dir/load_design.tcl
source $tf_dir/load_corners.tcl

tf::load_libs
tf::load_netlist
# bare modes / scenes
set tf(modes) $tf(impact_modes)
foreach m $tf(modes) { set tf(sdc,$m) $tf(bare_sdc,$m) }
set tf(scenes) {}
foreach m $tf(modes) {
  foreach c $tf(impact_corners) {
    lappend tf(scenes) bare_${m}_$c
    set tf(scene,bare_${m}_$c) [list $m $c]
  }
}
tf::load_modes_and_scenes
set out $tf(outdir)

# ------------------------------------------------------------ exception impact
set objs {}
foreach spec $tf(exc_specs) {
  lassign $spec id type modes from through to
  set counts {}
  foreach {k expr} [list from $from through $through to $to] {
    if {$expr eq ""} { continue }
    set n -1
    catch {set n [llength [subst $expr]]}
    lappend counts $k n $n
  }
  lappend objs [tf::jobj [list id s $id type s $type counts o [tf::jobj $counts]]]
  if {$type eq "case_analysis"} { continue }
  foreach m $modes {
    if {[lsearch -exact $tf(modes) $m] < 0} { continue }
    foreach c $tf(impact_corners) {
      set s bare_${m}_$c
      if {$type eq "clock_groups_async"} {
        # every ordered pair of groups
        set groups $from
        foreach ga $groups {
          foreach gb $groups {
            if {$ga eq $gb} { continue }
            set fa {}; set fb {}
            foreach x $ga { catch {lappend fa {*}[get_clocks $x]} }
            foreach x $gb { catch {lappend fb {*}[get_clocks $x]} }
            if {![llength $fa] || ![llength $fb]} { continue }
            set tag [join $ga _]__[join $gb _]
            report_checks -scenes $s -path_delay max -from $fa -to $fb -format end \
              -group_path_count 100000 -endpoint_path_count 1 > $out/impact_${id}_${s}_${tag}_setup.rpt
          }
        }
        continue
      }
      set args {}
      if {$from ne ""} { lappend args -from [subst $from] }
      if {$through ne ""} { lappend args -through [subst $through] }
      if {$to ne ""} { lappend args -to [subst $to] }
      catch {report_checks -scenes $s -path_delay max {*}$args -format end -unconstrained \
        -group_path_count 100000 -endpoint_path_count 1 > $out/impact_${id}_${s}_setup.rpt}
      catch {report_checks -scenes $s -path_delay min {*}$args -format end -unconstrained \
        -group_path_count 100000 -endpoint_path_count 1 > $out/impact_${id}_${s}_hold.rpt}
    }
  }
}
tf::write_file $out/impact_objects.json "\[[join $objs ,\n]\]"

# ------------------------------------------------------------ CDC
set cdc_mode [lindex $tf(modes) 0]
set cdc_scene bare_${cdc_mode}_[lindex $tf(impact_corners) 0]
set_scene $cdc_scene
foreach rc [all_registers -cells] { set ::tf_reg([get_full_name $rc]) 1 }
set clks [all_clocks]
set endpoints {}
foreach a $clks {
  foreach b $clks {
    if {$a eq $b} { continue }
    set an [get_name $a]; set bn [get_name $b]
    report_checks -scenes $cdc_scene -path_delay max -from $a -to $b -format json -digits 6 \
      -group_path_count 100000 -endpoint_path_count 1 -unique_paths_to_endpoint > $out/cdc_${an}__${bn}.json
    report_checks -scenes $cdc_scene -path_delay max -from $a -to $b -format end \
      -group_path_count 100000 -endpoint_path_count 1 > $out/cdc_${an}__${bn}.rpt
  }
}
# fanout of every register that captures a crossing (second synchroniser stage check)
proc tf::net_loads {pin depth} {
  # input pins driven by $pin, following buffer/inverter chains up to $depth levels
  set res {}
  set net [get_nets -of_objects $pin]
  if {$net eq ""} { return $res }
  foreach lp [get_pins -of_objects $net -filter "direction == input"] {
    set lc [get_cells -of_objects $lp]
    if {$depth > 0 && ([get_property $lc is_buffer] || [get_property $lc is_inverter])} {
      foreach op [get_pins -of_objects $lc -filter "direction == output"] {
        lappend res {*}[tf::net_loads $op [expr {$depth - 1}]]
      }
    } else {
      lappend res $lp
    }
  }
  return $res
}
proc tf::reg_loads {inst} {
  set res {}
  foreach qp [get_pins -of_objects [get_cells $inst] -filter "direction == output"] {
    foreach lp [tf::net_loads $qp 3] {
      set lc [get_cells -of_objects $lp]
      set lcn [get_full_name $lc]
      set isreg [info exists ::tf_reg($lcn)]
      set clk {}
      if {$isreg} {
        foreach cp [get_pins -of_objects $lc -filter "direction == input"] {
          catch {foreach k [get_property $cp clocks] { lappend clk [get_name $k] }}
        }
      }
      lappend res [tf::jobj [list pin s [get_full_name $lp] cell s [get_property $lc ref_name] \
        is_register b $isreg is_buffer b [get_property $lc is_buffer] is_inverter b [get_property $lc is_inverter] \
        clocks a [lsort -unique $clk]]]
    }
  }
  return "\[[join $res ,]\]"
}
set ej {}
foreach f [glob -nocomplain $out/cdc_*__*.rpt] {
  set fh [open $f]; set txt [read $fh]; close $fh
  foreach line [split $txt "\n"] {
    if {[regexp {^(\S+)/(D|SCD|SCE) \(} $line -> inst pin]} {
      if {![info exists seen($inst)]} {
        set seen($inst) 1
        lappend ej "[tf::jstr $inst]: [tf::reg_loads $inst]"
      }
    }
  }
}
# asynchronous input ports -> first registers (unconstrained in the bare mode)
foreach p $tf(async_inputs) {
  set ports {}
  catch {set ports [get_ports $p]}
  foreach port $ports {
    set pn [get_full_name $port]
    set safe [string map {[ _ ] _ / _} $pn]
    report_checks -scenes $cdc_scene -path_delay max -from $port -unconstrained -format json -digits 6 \
      -group_path_count 1000 -endpoint_path_count 1 -unique_paths_to_endpoint > $out/cdc_async_in_$safe.json
    report_checks -scenes $cdc_scene -path_delay max -from $port -unconstrained -format end \
      -group_path_count 1000 -endpoint_path_count 1 > $out/cdc_async_in_$safe.rpt
    set fh [open $out/cdc_async_in_$safe.rpt]; set txt [read $fh]; close $fh
    foreach line [split $txt "\n"] {
      if {[regexp {^(\S+)/(D) \(} $line -> inst pin]} {
        if {![info exists seen($inst)]} { set seen($inst) 1; lappend ej "[tf::jstr $inst]: [tf::reg_loads $inst]" }
      }
    }
  }
}
tf::write_file $out/cdc_endpoint_loads.json "\{[join $ej ,\n]\}"

# ------------------------------------------------------------ RDC (recovery/removal without exceptions)
report_checks -scenes $cdc_scene -path_delay max -path_group asynchronous -format json -digits 6 \
  -group_path_count 100000 -endpoint_path_count 1 -unique_paths_to_endpoint > $out/rdc_async.json
report_checks -scenes $cdc_scene -path_delay max -path_group asynchronous -format end \
  -group_path_count 100000 -endpoint_path_count 1 > $out/rdc_async.rpt
report_checks -scenes $cdc_scene -path_delay max -path_group asynchronous -unconstrained -format end \
  -group_path_count 100000 -endpoint_path_count 1 > $out/rdc_async_unconstrained.rpt

tf::tool_info $out/tool_info.json
tf::log "DONE"
