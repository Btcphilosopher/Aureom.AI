# TimingFlow: dump clock-tree geometry from the OpenDB database (OpenROAD only).
# Writes tf(outdir)/clock_tree.json: for every clock net, its driver and sink
# instances with placement coordinates (um) and master cell — real data from the
# CTS database, used by the report/dashboard clock-tree view.
proc tf::dump_clock_tree {path} {
  set block [ord::get_db_block]
  set dbu [[$block getTech] getDbUnitsPerMicron]
  set nets {}
  foreach net [$block getNets] {
    if {[$net getSigType] ne "CLOCK"} { continue }
    set drv {}; set sinks {}
    foreach it [$net getITerms] {
      set inst [$it getInst]
      set xy [$inst getLocation]
      set rec [tf::jobj [list inst s [$inst getName] master s [[$inst getMaster] getName] \
        pin s [[$it getMTerm] getName] x_um n [expr {[lindex $xy 0] / double($dbu)}] y_um n [expr {[lindex $xy 1] / double($dbu)}]]]
      if {[$it isOutputSignal]} { lappend drv $rec } else { lappend sinks $rec }
    }
    lappend nets [tf::jobj [list net s [$net getName] drivers o "\[[join $drv ,]\]" sinks o "\[[join $sinks ,]\]" n_sinks n [llength $sinks]]]
  }
  set die [$block getDieArea]
  tf::write_file $path [tf::jobj [list die_um o [tf::jobj [list x1 n [expr {[$die xMin]/double($dbu)}] y1 n [expr {[$die yMin]/double($dbu)}] \
    x2 n [expr {[$die xMax]/double($dbu)}] y2 n [expr {[$die yMax]/double($dbu)}]]] clock_nets o "\[[join $nets ,\n]\]"]]
  tf::log "clock tree: [llength $nets] clock nets dumped"
}
