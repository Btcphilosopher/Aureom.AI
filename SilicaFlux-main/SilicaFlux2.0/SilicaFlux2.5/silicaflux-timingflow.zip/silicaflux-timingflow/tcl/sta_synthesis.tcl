# TimingFlow STAGE A — POST-SYNTHESIS static timing analysis (OpenSTA).
#
# Inputs : mapped netlist, Liberty per corner, generated SDC per mode.
# Interconnect: none (pin capacitance only) unless tf(parasitics) selects the
#               library wire-load model as a labelled sensitivity run.
# Clocks : ideal (no clock tree exists yet).
# Results are POST-SYNTHESIS estimates and do not represent routed wire delay.
#
# Usage: TF_RUN_VARS=<run_vars.tcl> sta -no_splash -exit tcl/sta_synthesis.tcl

set tf_dir [file dirname [file normalize [info script]]]
source $tf_dir/tf_util.tcl
source $::env(TF_RUN_VARS)
source $tf_dir/load_design.tcl
source $tf_dir/load_corners.tcl
source $tf_dir/validate_constraints.tcl
source $tf_dir/report_paths.tcl

if {$tf(stage) ne "synthesis"} { error "TF-STAGE: sta_synthesis.tcl run with stage $tf(stage)" }
tf::log "STAGE POST-SYNTHESIS design=$tf(design) top=$tf(top) parasitics=$tf(parasitics)"

tf::load_libs
tf::load_netlist
tf::load_modes_and_scenes
tf::validate $tf(outdir)
foreach s $tf(scenes) { tf::report_scene $s $tf(outdir) }
tf::report_design $tf(outdir)
if {[info exists tf(extra_scripts)]} {
  foreach x $tf(extra_scripts) { tf::log "extra: $x"; source $x }
}
tf::tool_info $tf(outdir)/tool_info.json
tf::log "DONE"
