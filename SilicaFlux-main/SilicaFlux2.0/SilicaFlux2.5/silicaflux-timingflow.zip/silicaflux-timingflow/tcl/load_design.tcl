# TimingFlow: library + design loading (OpenSTA and OpenROAD).
# Requires the run variables array ::tf (written by timingflow/sta.py into
# run_vars.tcl):
#   tf(corners)        analysed corners, e.g. {typ slow fast}
#   tf(lib,<corner>)   every Liberty file of the corner (stdcell + io + macro)
#   tf(netlist) tf(top)            gate-level netlist (stage A)
#   tf(odb) tf(lef_files)          OpenROAD database + LEFs (stages B-E)

proc tf::scene_capable {} { return [tf::has define_scene] }

proc tf::load_libs {} {
  global tf
  if {[tf::scene_capable]} {
    set seen {}
    foreach c $tf(corners) {
      foreach lib $tf(lib,$c) {
        if {[lsearch -exact $seen $lib] >= 0} { continue }
        if {![file exists $lib]} { error "TF-MISSING-LIB: $lib" }
        read_liberty $lib
        lappend seen $lib
      }
    }
    tf::log "read [llength $seen] Liberty files for corners {$tf(corners)} (scene MCMM)"
  } else {
    tf::require define_corners
    define_corners {*}$tf(corners)
    foreach c $tf(corners) {
      foreach lib $tf(lib,$c) {
        if {![file exists $lib]} { error "TF-MISSING-LIB: $lib" }
        read_liberty -corner $c $lib
      }
    }
    tf::log "read Liberty per corner with legacy define_corners {$tf(corners)}"
  }
}

proc tf::load_netlist {} {
  global tf
  if {![file exists $tf(netlist)]} { error "TF-MISSING-NETLIST: $tf(netlist)" }
  read_verilog $tf(netlist)
  link_design $tf(top)
  tf::log "linked $tf(top) from $tf(netlist)"
}

# OpenROAD: LEFs, Liberty and a stage database.
proc tf::load_physical {} {
  global tf
  tf::require read_db
  foreach lef $tf(lef_files) {
    if {![file exists $lef]} { error "TF-MISSING-LEF: $lef" }
    read_lef $lef
  }
  tf::load_libs
  if {![file exists $tf(odb)]} { error "TF-MISSING-ODB: $tf(odb) (run the preceding physical stage first)" }
  read_db $tf(odb)
  tf::log "loaded database $tf(odb)"
}
