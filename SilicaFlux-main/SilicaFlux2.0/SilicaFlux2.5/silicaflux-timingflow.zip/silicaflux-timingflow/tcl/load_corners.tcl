# TimingFlow: SDC modes and analysis scenes (mode x corner).
#   tf(modes)              e.g. {func test}
#   tf(sdc,<mode>)         generated SDC per mode
#   tf(scenes)             scene names
#   tf(scene,<name>)       {mode corner}
#   tf(parasitics)         none | wire_load:<model> | placement | global_route | spef
#   tf(spef,<corner>)      SPEF per corner when parasitics == spef
#   tf(sdc_log)            file collecting SDC warnings/errors for the audit

proc tf::load_modes_and_scenes {} {
  global tf sta_continue_on_error
  # Keep reading after an SDC error so the audit sees *every* bad reference;
  # the audit then FAILS the run if any were reported.
  set sta_continue_on_error 1
  if {[tf::scene_capable]} {
    foreach m $tf(modes) {
      tf::log "read_sdc -mode $m $tf(sdc,$m)"
      read_sdc -mode $m $tf(sdc,$m)
    }
    if {$tf(parasitics) eq "spef"} {
      foreach c $tf(corners) {
        read_spef -name spef_$c $tf(spef,$c)
      }
    }
    foreach s $tf(scenes) {
      lassign $tf(scene,$s) m c
      set args [list $s -mode $m -liberty $tf(lib,$c)]
      if {$tf(parasitics) eq "spef"} { lappend args -spef spef_$c }
      define_scene {*}$args
      tf::log "scene $s = mode $m x corner $c"
    }
  } else {
    if {[llength $tf(modes)] > 1} {
      error "TF-UNSUPPORTED: multi-mode analysis needs define_scene (this revision only has define_corners)"
    }
    read_sdc $tf(sdc,[lindex $tf(modes) 0])
    if {$tf(parasitics) eq "spef"} {
      foreach c $tf(corners) { read_spef -corner $c $tf(spef,$c) }
    }
  }
  set sta_continue_on_error 0
  if {[string match wire_load:* $tf(parasitics)]} {
    set wl [string range $tf(parasitics) 10 end]
    set_wire_load_model -name $wl
    tf::log "wire-load model $wl applied (sensitivity analysis)"
  }
}

# Scenes belonging to one mode
proc tf::mode_scenes {mode} {
  global tf
  set out {}
  foreach s $tf(scenes) {
    if {[lindex $tf(scene,$s) 0] eq $mode} { lappend out $s }
  }
  return $out
}
