# TimingFlow: POST-PLACEMENT analysis of an existing database (see sta_stage.tcl).
set ::tf_stage_override placement
source [file join [file dirname [file normalize [info script]]] sta_stage.tcl]
