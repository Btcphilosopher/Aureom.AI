# TimingFlow: per-scene timing reports (OpenSTA / OpenROAD).
# For every scene s (mode x corner) this writes:
#   paths_setup_<s>.json / paths_hold_<s>.json  top paths (one per endpoint), JSON
#   paths_setup_<s>.rpt  / paths_hold_<s>.rpt   worst paths, full text with fanout/cap/slew
#   ends_setup_<s>.rpt   / ends_hold_<s>.rpt    one line per endpoint (violator counts, histograms)
#   slack_summary_<s>.rpt                        worst slack per check type
#   drv_<s>.rpt                                  max slew / cap / fanout violators
#   pulse_<s>.rpt                                min pulse width / min period violators
#   async_<s>.rpt                                recovery / removal violators
#   gating_<s>.rpt                               clock-gating setup/hold checks
#   skew_setup_<s>.rpt skew_hold_<s>.rpt latency_<s>.rpt
#   metrics_<s>.json                             WNS/TNS/WHS/THS (ns)
# Units: ns, pF (Liberty units).

proc tf::report_scene {s outdir} {
  global tf
  set n $tf(path_count)
  set fields {capacitance slew fanout input_pins net}
  report_checks -scenes $s -path_delay max -group_path_count $n -endpoint_path_count 1 \
    -unique_paths_to_endpoint -format json -digits 6 > $outdir/paths_setup_$s.json
  report_checks -scenes $s -path_delay min -group_path_count $n -endpoint_path_count 1 \
    -unique_paths_to_endpoint -format json -digits 6 > $outdir/paths_hold_$s.json
  report_checks -scenes $s -path_delay max -group_path_count $tf(text_path_count) \
    -fields $fields -digits 4 > $outdir/paths_setup_$s.rpt
  report_checks -scenes $s -path_delay min -group_path_count $tf(text_path_count) \
    -fields $fields -digits 4 > $outdir/paths_hold_$s.rpt
  # register-to-register only (classification by timing graph, not by name)
  set rclk [all_registers -clock_pins]
  set rdat [all_registers -data_pins]
  report_checks -scenes $s -path_delay max -from $rclk -to $rdat -group_path_count $n \
    -endpoint_path_count 1 -unique_paths_to_endpoint -format json -digits 6 > $outdir/paths_r2r_setup_$s.json
  report_checks -scenes $s -path_delay min -from $rclk -to $rdat -group_path_count $n \
    -endpoint_path_count 1 -unique_paths_to_endpoint -format json -digits 6 > $outdir/paths_r2r_hold_$s.json
  report_checks -scenes $s -path_delay max -from $rclk -to $rdat -group_path_count $tf(text_path_count) \
    -fields $fields -digits 4 > $outdir/paths_r2r_setup_$s.rpt
  # SRAM macro interfaces (macros are not Liberty registers): read paths start at
  # the macro (A_CLK -> A_DOUT arc); write/address/enable paths end at macro pins.
  if {[info exists tf(macros)] && [llength $tf(macros)]} {
    set mcells {}
    foreach m $tf(macros) {
      foreach c [get_cells -hierarchical -filter "ref_name == $m"] { lappend mcells $c }
    }
    if {[llength $mcells]} {
      report_checks -scenes $s -path_delay max -from $mcells -group_path_count $n -endpoint_path_count 1 \
        -unique_paths_to_endpoint -format json -digits 6 > $outdir/paths_sram_rd_setup_$s.json
      report_checks -scenes $s -path_delay max -to $mcells -group_path_count $n -endpoint_path_count 1 \
        -unique_paths_to_endpoint -format json -digits 6 > $outdir/paths_sram_wr_setup_$s.json
      report_checks -scenes $s -path_delay min -to $mcells -group_path_count $n -endpoint_path_count 1 \
        -unique_paths_to_endpoint -format json -digits 6 > $outdir/paths_sram_wr_hold_$s.json
      report_checks -scenes $s -path_delay max -from $mcells -group_path_count 3 \
        -fields $fields -digits 4 > $outdir/paths_sram_rd_setup_$s.rpt
      report_checks -scenes $s -path_delay max -to $mcells -group_path_count 3 \
        -fields $fields -digits 4 > $outdir/paths_sram_wr_setup_$s.rpt
    }
  }
  # worst setup path through each top-level block instance (block-focused evidence)
  if {[info exists tf(through_insts)]} {
    foreach inst $tf(through_insts) {
      set c [get_cells -quiet $inst]
      if {[llength $c]} {
        report_checks -scenes $s -path_delay max -through $c -group_path_count 3 -endpoint_path_count 1 \
          -format json -digits 6 > $outdir/through_${inst}_$s.json
      } else {
        tf::log "through-block query NOT RUN for $inst in $s: no hierarchical instance (flat database)"
      }
    }
  }
  report_checks -scenes $s -path_delay max -format end -group_path_count $tf(end_count) \
    -endpoint_path_count 1 -digits 4 > $outdir/ends_setup_$s.rpt
  report_checks -scenes $s -path_delay min -format end -group_path_count $tf(end_count) \
    -endpoint_path_count 1 -digits 4 > $outdir/ends_hold_$s.rpt
  report_check_types -scenes $s -max_delay -min_delay -recovery -removal -clock_gating_setup \
    -clock_gating_hold -min_pulse_width -min_period -max_slew -max_capacitance -max_fanout \
    -format slack_only -digits 4 > $outdir/slack_summary_$s.rpt
  report_check_types -scenes $s -violators -max_slew -max_capacitance -max_fanout \
    -digits 4 > $outdir/drv_$s.rpt
  report_check_types -scenes $s -violators -min_pulse_width -min_period -digits 4 > $outdir/pulse_$s.rpt
  report_check_types -scenes $s -violators -recovery -removal -digits 4 > $outdir/async_$s.rpt
  report_check_types -scenes $s -clock_gating_setup -clock_gating_hold -digits 4 > $outdir/gating_$s.rpt
  if {[tf::has report_clock_skew]} {
    tf::capture $outdir/skew_setup_$s.rpt { report_clock_skew -setup -scenes $s -digits 4 }
    tf::capture $outdir/skew_hold_$s.rpt { report_clock_skew -hold -scenes $s -digits 4 }
  }
  if {[tf::has report_clock_latency]} {
    tf::capture $outdir/latency_$s.rpt { report_clock_latency -scenes $s -digits 4 }
  }
  set sc [sta::find_scene $s]
  set wns [tf::ns [sta::worst_slack_scene $sc max]]
  set tns [tf::ns [sta::total_negative_slack_scene_cmd $sc max]]
  set whs [tf::ns [sta::worst_slack_scene $sc min]]
  set ths [tf::ns [sta::total_negative_slack_scene_cmd $sc min]]
  lassign $tf(scene,$s) m c
  tf::write_file $outdir/metrics_$s.json [tf::jobj [list scene s $s mode s $m corner s $c \
    wns_ns n $wns tns_ns n $tns whs_ns n $whs ths_ns n $ths]]
  tf::log "scene $s: WNS=$wns TNS=$tns WHS=$whs THS=$ths (ns)"
}

proc tf::report_design {outdir} {
  global tf
  foreach m $tf(modes) {
    if {[tf::has write_sdc]} {
      catch {write_sdc -mode $m -no_timestamp $outdir/applied_$m.sdc}
    }
  }
  # Power: vectorless estimate in the power scene only (labelled as such).
  if {$tf(power_scene) ne "" && [tf::has report_power]} {
    set_power_activity -input -activity $tf(power_input_activity) -duty 0.5
    report_power -scene $tf(power_scene) -digits 6 > $outdir/power_$tf(power_scene).rpt
  }
}
