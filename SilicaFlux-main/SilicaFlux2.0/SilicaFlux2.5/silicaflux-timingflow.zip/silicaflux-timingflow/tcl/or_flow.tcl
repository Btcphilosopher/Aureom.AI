# TimingFlow OpenROAD physical stages.  One entry script, stage selected by
# tf(stage).  Each stage reads the previous stage's database and refuses to run
# without it, so post-route analysis can never be applied to a placement DB.
#
#   placement    netlist -> floorplan, IO pins, tapcells, PDN, macro + global
#                placement, repair_design, detailed placement -> 2_place.odb
#   cts          2_place.odb -> clock_tree_synthesis, repair_timing -hold -> 3_cts.odb
#   global_route 3_cts.odb -> global_route -> 4_grt.odb
#   postroute    4_grt.odb -> detailed_route, extract_parasitics (RCX) -> 5_route.odb + SPEF
#
# Platform collateral (setRC, make_tracks, pdn, tapcell, RCX rules) comes from
# the ORFS platform directory named in configs/platforms/<pdk>.yaml.

set tf_dir [file dirname [file normalize [info script]]]
source $tf_dir/tf_util.tcl
source $::env(TF_RUN_VARS)
source $tf_dir/load_design.tcl
source $tf_dir/load_corners.tcl
source $tf_dir/validate_constraints.tcl
source $tf_dir/report_paths.tcl
source $tf_dir/clock_tree_dump.tcl

set pnr $tf(pnr_dir)
file mkdir $pnr
proc tf::stage_db {s} {
  global pnr
  return [dict get {placement 2_place.odb cts 3_cts.odb global_route 4_grt.odb postroute 5_route.odb} $s]
}
proc tf::metric {name value} {
  global tf
  set f [open $tf(outdir)/phys_metrics.tcl a]; puts $f [list set m($name) $value]; close $f
}
file delete -force $tf(outdir)/phys_metrics.tcl

proc tf::design_metrics {tag} {
  set area 0; set n 0; set nbuf 0; set nseq 0
  foreach inst [get_cells -hierarchical *] {
    incr n
    set lc [get_lib_cells -of_objects $inst]
    if {$lc eq ""} { continue }
    catch {set area [expr {$area + [get_property $lc area]}]}
    if {[get_property $inst is_buffer] || [get_property $inst is_inverter]} { incr nbuf }
  }
  tf::metric ${tag}_cells $n
  tf::metric ${tag}_area_um2 [format %.3f $area]
  tf::metric ${tag}_buffers_inverters $nbuf
  catch {tf::metric ${tag}_util [format %.4f [rsz::utilization]]}
  if {[tf::has report_design_area]} { tf::capture $::tf(outdir)/design_area_$tag.rpt { report_design_area } }
}

tf::log "OPENROAD STAGE $tf(stage) design=$tf(design)"
tf::require read_lef

# ------------------------------------------------------------------ load
if {$tf(stage) eq "placement"} {
  foreach lef $tf(lef_files) { read_lef $lef }
  tf::load_libs
  tf::load_netlist
} else {
  set prev [dict get {cts placement global_route cts postroute global_route} $tf(stage)]
  set tf(odb) $pnr/[tf::stage_db $prev]
  tf::load_physical
}
tf::load_modes_and_scenes
source $tf(setrc)

# ------------------------------------------------------------------ stages
switch -- $tf(stage) {
  placement {
    tf::require initialize_floorplan
    initialize_floorplan -utilization $tf(core_util) -aspect_ratio 1.0 -core_space $tf(core_margin) -site $tf(site)
    source $tf(make_tracks)
    if {[llength $tf(macros)]} {
      if {[tf::has rtl_macro_placer]} {
        rtl_macro_placer -halo_width $tf(macro_halo) -halo_height $tf(macro_halo)
      } elseif {[tf::has macro_placement]} {
        global_placement -density $tf(place_density)
        macro_placement -halo [list $tf(macro_halo) $tf(macro_halo)]
      } else { error "TF-UNSUPPORTED: no macro placer in this OpenROAD revision" }
    }
    place_pins -hor_layers $tf(io_hor) -ver_layers $tf(io_ver)
    if {[file exists $tf(tapcell)]} { source $tf(tapcell) }
    if {[file exists $tf(pdn)]} { catch {source $tf(pdn); pdngen} pdn_err; tf::log "pdn: $pdn_err" }
    tf::design_metrics pre_place
    global_placement -density $tf(place_density) -pad_left 1 -pad_right 1
    estimate_parasitics -placement
    tf::design_metrics pre_repair
    repair_design -max_wire_length $tf(max_wire_um)
    repair_tie_fanout -separation 0 [lindex $tf(tiehi) 0]/[lindex $tf(tiehi) 1]
    repair_tie_fanout -separation 0 [lindex $tf(tielo) 0]/[lindex $tf(tielo) 1]
    detailed_placement
    check_placement -verbose
    estimate_parasitics -placement
    tf::design_metrics post_place
  }
  cts {
    tf::require clock_tree_synthesis
    clock_tree_synthesis -buf_list $tf(cts_bufs) -root_buf [lindex $tf(cts_bufs) 0] -sink_clustering_enable
    set_propagated_clock [all_clocks]
    estimate_parasitics -placement
    tf::design_metrics pre_hold
    tf::capture $tf(outdir)/pre_hold_repair.rpt { report_worst_slack -min; report_tns -min }
    if {$tf(repair_hold)} {
      repair_timing -hold -hold_margin $tf(hold_margin) -max_buffer_percent $tf(max_buffer_pct)
    }
    detailed_placement
    check_placement -verbose
    estimate_parasitics -placement
    tf::design_metrics post_cts
    catch {tf::dump_clock_tree $tf(outdir)/clock_tree.json} cte; tf::log "clock tree dump: $cte"
  }
  global_route {
    tf::require global_route
    # equivalent of the ORFS platform fastroute.tcl (which reads ORFS env vars)
    set_global_routing_layer_adjustment $tf(min_layer)-$tf(max_layer) 0.05
    set_routing_layers -signal $tf(min_layer)-$tf(max_layer)
    global_route -congestion_iterations 30 -allow_congestion -congestion_report_file $tf(outdir)/congestion.rpt
    estimate_parasitics -global_routing
    tf::design_metrics post_grt
  }
  postroute {
    tf::require detailed_route
    tf::require extract_parasitics
    set_routing_layers -signal $tf(min_layer)-$tf(max_layer)
    detailed_route -output_drc $tf(outdir)/drc.rpt -verbose 1
    if {[file exists $tf(fill_script)]} { catch {source $tf(fill_script)} }
    define_process_corner -ext_model_index 0 X
    extract_parasitics -ext_model_file $tf(rcx_rules)
    foreach c $tf(corners) { write_spef $pnr/5_route_$c.spef }
    tf::design_metrics post_route
  }
}
write_db $pnr/[tf::stage_db $tf(stage)]
write_verilog $pnr/[file rootname [tf::stage_db $tf(stage)]].v

# ------------------------------------------------------------------ timing
if {$tf(stage) eq "postroute"} {
  # re-annotate the extracted parasitics for STA
  foreach c $tf(corners) { catch {read_spef $pnr/5_route_$c.spef} }
}
tf::validate $tf(outdir)
foreach s $tf(scenes) { tf::report_scene $s $tf(outdir) }
tf::report_design $tf(outdir)
tf::tool_info $tf(outdir)/tool_info.json
tf::log "DONE"
