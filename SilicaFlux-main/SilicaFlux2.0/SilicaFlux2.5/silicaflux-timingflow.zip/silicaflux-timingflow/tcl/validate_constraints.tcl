# TimingFlow: tool-side constraint validation (per mode).
# Produces, per mode m:
#   check_setup_<m>.rpt   OpenSTA check_setup -verbose (missing clocks, IO
#                         delays, unconstrained endpoints, loops, generated clocks,
#                         multiply-clocked registers)
#   clocks_<m>.json       every clock: period, waveform, sources, generated/virtual/propagated
#   clock_props_<m>.rpt   report_clock_properties
#   coverage_<m>.json     endpoint / register / port counts
# The Python audit (timingflow/constraints.py) merges these with the static
# SDC lint and the read_sdc warnings in the log.

proc tf::clock_json {c} {
  set srcs {}
  foreach s [get_property $c sources] { lappend srcs [get_full_name $s] }
  set wf ""
  catch {set wf [get_property $c waveform]}
  return [tf::jobj [list name s [get_property $c name] period_ns n [get_property $c period] \
    waveform s $wf sources a $srcs is_generated b [get_property $c is_generated] \
    is_virtual b [get_property $c is_virtual] is_propagated b [get_property $c is_propagated]]]
}

proc tf::validate {outdir} {
  global tf
  tf::require check_setup
  foreach m $tf(modes) {
    set scenes [tf::mode_scenes $m]
    if {[tf::scene_capable] && [llength $scenes]} { set_scene [lindex $scenes 0] }
    check_setup -verbose > $outdir/check_setup_$m.rpt
    set cj {}
    foreach c [all_clocks] { lappend cj [tf::clock_json $c] }
    tf::write_file $outdir/clocks_$m.json "\[[join $cj ,\n]\]"
    if {[tf::has report_clock_properties]} {
      report_clock_properties > $outdir/clock_props_$m.rpt
    }
    set n_regs [llength [all_registers]]
    set n_ff [llength [all_registers -edge_triggered]]
    set n_lat [llength [all_registers -level_sensitive]]
    set n_in [llength [all_inputs]]
    set n_out [llength [all_outputs]]
    set n_end ""
    catch {set n_end [sta::endpoint_count]}
    tf::write_file $outdir/coverage_$m.json [tf::jobj [list mode s $m scene s [lindex $scenes 0] \
      registers n $n_regs flops n $n_ff latches n $n_lat inputs n $n_in outputs n $n_out \
      endpoints n $n_end clocks n [llength [all_clocks]]]]
    tf::log "validated mode $m: $n_ff flops, $n_lat latches, [llength [all_clocks]] clocks, $n_end endpoints"
  }
}
