"""Constraint validation: static lint + registry rules + OpenSTA tool checks.

Status vocabulary: PASS | WARNING | FAIL | NOT APPLICABLE | NOT RUN.
A timing run is never accepted as closure while any FAIL remains here, and a
run with unconstrained endpoints fails Gate 5 regardless of slack.
"""
from __future__ import annotations

import fnmatch
import hashlib
import json
import re
from pathlib import Path

from . import cdc as cdcmod
from . import liberty, sdc_gen, sdc_lint
from .config import (CONFIG_DIR, DesignConfig, ExceptionRegistry, Platform, load_exceptions,
                     load_io)
from .parse_reports import parse_check_setup, parse_ends, read_json
from .paths import TCL_DIR
from .sta import corner_libs, run_tool, write_run_vars

STATUSES = ("PASS", "WARNING", "FAIL", "NOT APPLICABLE", "NOT RUN")
CDC_TYPES = {"clock_groups_async", "false_path"}


def chk(cid: str, title: str, status: str, evidence: str = "", details=None) -> dict:
    assert status in STATUSES, status
    return {"id": cid, "title": title, "status": status, "evidence": evidence, "details": details or []}


# --------------------------------------------------------------------------- registry
def registry_checks(design: DesignConfig, exc: ExceptionRegistry | None, ports: dict[str, str]) -> list[dict]:
    if exc is None:
        return [chk("X01", "Exception registry present", "WARNING", "no exceptions_file configured")]
    clocks = {c.name for c in design.clocks} | {g.name for g in design.generated_clocks}
    modes = {m.name for m in design.modes}
    out = []
    probs, warn, pend = [], [], []
    for e in exc.exceptions:
        refs = list(e.from_) + list(e.to) + list(e.through)
        for r in refs:
            kind, _, name = r.partition(":")
            if kind not in ("port", "pin", "cell", "inst", "clock", "net"):
                probs.append(f"{e.id}: malformed reference '{r}'")
            if kind == "clock" and name not in clocks:
                probs.append(f"{e.id}: unknown clock '{name}'")
            if kind == "port" and ports and not any(sdc_gen.sdc_match(p, name) or p.split("[")[0] == name for p in ports):
                probs.append(f"{e.id}: port '{name}' matches no top-level port")
            if "*" in name:
                warn.append(f"{e.id}: wildcard '{r}' — scope proven only by the impact report")
        for g in e.groups:
            for cname in g:
                if cname not in clocks:
                    probs.append(f"{e.id}: clock group references unknown clock '{cname}'")
        if not e.rtl_evidence:
            probs.append(f"{e.id}: no RTL evidence")
        if e.type in CDC_TYPES and not e.verification_evidence:
            probs.append(f"{e.id}: CDC/RDC exception without verification evidence")
        if e.type == "multicycle_path" and (e.setup_multiplier is None or e.hold_multiplier is None):
            probs.append(f"{e.id}: multicycle without both setup and hold multipliers")
        if e.type == "false_path" and not (e.from_ or e.to or e.through):
            probs.append(f"{e.id}: unbounded false path")
        for m in e.modes:
            if m not in modes:
                probs.append(f"{e.id}: unknown mode '{m}'")
        if e.approval != "APPROVED":
            pend.append(f"{e.id}: {e.approval} (owner: {e.owner})")
    out.append(chk("X01", "Exception entries complete and well-formed", "FAIL" if probs else "PASS",
                   f"{len(exc.exceptions)} entries, registry {exc.revision}", probs))
    out.append(chk("X02", "Exception wildcards scoped", "WARNING" if warn else "PASS",
                   "see exception_impact.json", warn))
    out.append(chk("X03", "Exceptions reviewed and approved", "WARNING" if pend else "PASS",
                   "Gate 6 requires APPROVED for every applied exception", pend))
    reg = CONFIG_DIR / design.exceptions_file
    digest = hashlib.sha256(reg.read_bytes()).hexdigest()
    stamp = reg.with_suffix(".reviewed")
    if stamp.exists() and stamp.read_text().split()[0] == digest:
        out.append(chk("X04", "Registry unchanged since last sign-off", "PASS", f"sha256 {digest[:16]}"))
    else:
        out.append(chk("X04", "Registry unchanged since last sign-off", "WARNING",
                       f"sha256 {digest[:16]} has no matching review stamp ({stamp.name}); changes require review"))
    return out


# --------------------------------------------------------------------------- analysis run
def bare_sdc(text: str) -> str:
    """Generated SDC minus every registry exception (lines carrying -comment "EXC-")."""
    out = []
    for line in text.splitlines():
        if '-comment "' in line and re.search(r'-comment "EXC-', line):
            out.append("# [bare] removed: " + line[:120])
        else:
            out.append(line)
    return "\n".join(out) + "\n"


def _tcl(s: str) -> str:
    return "{" + s + "}"


def exc_specs(exc: ExceptionRegistry | None, modes: list[str]) -> list[str]:
    specs = []
    if exc is None:
        return specs
    for e in exc.exceptions:
        ms = [m for m in e.modes if m in modes]
        if not ms:
            continue
        if e.type == "clock_groups_async":
            groups = " ".join("{" + " ".join(g) + "}" for g in e.groups)
            specs.append("{" + f"{e.id} {e.type} {{{' '.join(ms)}}} {{{groups}}} {{}} {{}}" + "}")
            continue
        fr = sdc_gen.objs(e.from_) if e.from_ else ""
        th = sdc_gen.objs(e.through) if e.through else ""
        to = sdc_gen.objs(e.to) if e.to else ""
        specs.append("{" + f"{e.id} {e.type} {{{' '.join(ms)}}} {_tcl(fr)} {_tcl(th)} {_tcl(to)}" + "}")
    return specs


def run_analysis(design: DesignConfig, platform: Platform, run_dir: Path, corners: list[str] | None = None,
                 threads: int = 4) -> dict:
    meta = read_json(run_dir / "sdc" / "sdc_meta.json")
    netlist = run_dir / "synth" / "netlist.v"
    if not meta or not netlist.exists():
        return {"status": "NOT RUN", "reason": "run synthesis and stage A first (needs netlist + generated SDC)"}
    out = run_dir / "constraint_analysis"
    out.mkdir(parents=True, exist_ok=True)
    modes = list(meta["modes"])
    for m in modes:
        (out / f"bare_{m}.sdc").write_text(bare_sdc(Path(meta["modes"][m]["sdc"]).read_text()))
    exc = load_exceptions(design)
    io = load_io(design)
    async_in = []
    if io:
        for g in io.groups:
            if g.kind == "async" and g.direction == "input":
                async_in += g.ports
    corners = corners or [platform.synthesis_corner, next((c for c in platform.corners if c != platform.synthesis_corner), platform.synthesis_corner)]
    corners = list(dict.fromkeys(corners))
    rv = out / "run_vars.tcl"
    extra = {"impact_modes": "{" + " ".join(modes) + "}",
             "impact_corners": "{" + " ".join(corners) + "}",
             "exc_specs": "{" + " ".join(exc_specs(exc, modes)) + "}",
             "async_inputs": "{" + " ".join("{" + p + "}" for p in async_in) + "}"}
    for m in modes:
        extra[f"bare_sdc,{m}"] = "{" + str(out / f"bare_{m}.sdc") + "}"
    write_run_vars(rv, design=design, platform=platform, stage="synthesis", corners=corners, sdc_meta=meta,
                   outdir=out, netlist=netlist, extra=extra)
    res = run_tool("sta", TCL_DIR / "constraint_analysis.tcl", rv, out / "sta.log", threads)
    if res["status"] != "PASS":
        (out / "run_result.json").write_text(json.dumps(res, indent=1))
        return res
    # clock relationships for the CDC graph
    rel: dict[tuple[str, str], str] = {}
    names = [c.name for c in design.clocks] + [g.name for g in design.generated_clocks]
    for g in design.generated_clocks:
        rel[(g.master, g.name)] = rel[(g.name, g.master)] = f"synchronous related (generated from {g.master})"
    if exc:
        for e in exc.exceptions:
            if e.type == "clock_groups_async":
                for ga in e.groups:
                    for gb in e.groups:
                        if ga is gb:
                            continue
                        for a in ga:
                            for b in gb:
                                rel[(a, b)] = f"asynchronous ({e.id})"
    res["cdc"] = cdcmod.analyze(out, rel)
    res["clock_graph"] = {"clocks": names, "edges": [{"from": a, "to": b, "relationship": r} for (a, b), r in rel.items()]}
    res["impact"] = exception_impact(out, exc, corners, platform, design.macros.get(platform.name, []))
    (out / "run_result.json").write_text(json.dumps({k: v for k, v in res.items() if k not in ("cdc",)}, indent=1))
    (out / "exception_impact.json").write_text(json.dumps(res["impact"], indent=1))
    return res


def _pin_classes(platform: Platform | None) -> tuple[dict, dict]:
    classes: dict[str, str] = {}
    apins: dict[str, set[str]] = {}
    if platform is None:
        return classes, apins
    for lib in platform.liberty_set(platform.synthesis_corner, [])["stdcell"]:
        if lib.exists():
            classes.update(liberty.cell_classes(lib))
            apins.update(liberty.async_pins(lib))
    return classes, apins


def endpoint_kind(row: dict, classes: dict, apins: dict, macros: list[str]) -> str:
    ref, ep = row.get("ref", ""), row["endpoint"]
    pin = ep.rsplit("/", 1)[-1] if "/" in ep else ""
    if ref in ("output", "input", "inout") or "/" not in ep:
        return "port"
    if ref in macros:
        return "macro_pin"
    k = classes.get(ref)
    if k in ("ff", "latch"):
        return "async_set_reset" if pin in apins.get(ref, set()) else "register_data"
    if k == "icg":
        return "clock_gate_enable"
    if k == "comb":
        return "terminated_comb_input (case analysis/constant)"
    return "unknown"


def exception_impact(out: Path, exc: ExceptionRegistry | None, corners: list[str],
                     platform: Platform | None = None, macros: list[str] | None = None) -> list[dict]:
    if exc is None:
        return []
    classes, apins = _pin_classes(platform)
    objs = {o["id"]: o for o in (read_json(out / "impact_objects.json", []) or [])}
    rows = []
    for e in exc.exceptions:
        files = sorted(out.glob(f"impact_{e.id}_*_setup.rpt"))
        ends = []
        for f in files:
            ends += [dict(r, scene=f.stem) for r in parse_ends(f)]
        eps = {r["endpoint"] for r in ends}
        groups = sorted({r["group"] for r in ends})
        kinds: dict[str, int] = {}
        seen = set()
        for r in ends:
            if r["endpoint"] in seen:
                continue
            seen.add(r["endpoint"])
            k = endpoint_kind(r, classes, apins, macros or [])
            kinds[k] = kinds.get(k, 0) + 1
        bad_kinds = {k for k in kinds if k in ("register_data", "port", "macro_pin", "clock_gate_enable", "unknown")}
        async_only = bool(ends) and not bad_kinds
        viol = sorted({r["endpoint"] for r in ends if r["violated"]})
        verdict = "NOT APPLICABLE" if e.type == "case_analysis" else "INFO"
        notes = []
        if e.type == "false_path" and ends:
            if async_only:
                verdict = "PASS"
                notes.append(f"covered endpoint pins are only async set/reset or case-blocked inputs: {kinds}")
            else:
                verdict = "FAIL"
                notes.append(f"false path covers functional endpoints {sorted(bad_kinds)}: {kinds}")
        if e.type == "clock_groups_async":
            verdict = "REVIEW REQUIRED" if ends else "NOT APPLICABLE"
            notes.append(f"{len(eps)} crossing endpoints hidden from STA; structure in cdc.json")
        if e.type in ("max_delay", "min_delay"):
            verdict = "PASS" if ends else "WARNING"
            notes.append(f"{len(eps)} endpoints bounded" if ends else "matches no path")
        if e.type == "multicycle_path":
            verdict = "PASS" if ends else "WARNING"
            notes.append(f"{len(eps)} endpoints relaxed; setup x{e.setup_multiplier} -{e.setup_reference}, "
                         f"hold x{e.hold_multiplier} -{e.hold_reference}")
        rows.append({"id": e.id, "type": e.type, "approval": e.approval, "objects": objs.get(e.id, {}).get("counts"),
                     "endpoint_kinds": kinds,
                     "endpoints_covered": len(eps), "path_groups": groups,
                     "endpoints_violating_without_exception": len(viol), "verdict": verdict, "notes": notes,
                     "examples": sorted(eps)[:15]})
    return rows


# --------------------------------------------------------------------------- audit
SDC_WARN_RE = re.compile(r"^(Warning|Error) (\d+): (.*\.sdc) line (\d+), (.*)$", re.M)


def audit(design: DesignConfig, platform: Platform, run_dir: Path, stage_dir: str = "sta_synthesis",
          analysis: dict | None = None) -> dict:
    sd = run_dir / stage_dir
    meta = read_json(run_dir / "sdc" / "sdc_meta.json") or {}
    netlist = run_dir / "synth" / "netlist.v"
    ports = sdc_gen.netlist_top_ports(netlist, design.top) if netlist.exists() else {}
    exc = load_exceptions(design)
    io = load_io(design)
    checks: list[dict] = []
    corners = list(platform.corners)
    # C01/C02 libraries and SRAM models
    missing, macro_missing = [], []
    for c in corners:
        for lib in corner_libs(platform, design, c):
            if not lib.exists():
                missing.append(f"{c}: {lib}")
    for m in design.macros.get(platform.name, []):
        for c in corners:
            p = platform.macro_liberty(c, m)
            if not p.exists():
                macro_missing.append(f"{m} @ {c}: {p}")
    checks.append(chk("C01", "Timing libraries present for every analysed corner", "FAIL" if missing else "PASS",
                      f"{len(corners)} corners: {', '.join(corners)}", missing))
    log = (sd / "sta.log").read_text(errors="replace") if (sd / "sta.log").exists() else ""
    unlinked = re.findall(r"(?:module|cell) '?(\S+?)'? not found", log)
    checks.append(chk("C02", "SRAM macro timing models present (no behavioural array inferred)",
                      "FAIL" if macro_missing or unlinked else ("PASS" if design.macros.get(platform.name) else "NOT APPLICABLE"),
                      f"macros: {design.macros.get(platform.name, [])}", macro_missing + [f"unlinked: {u}" for u in unlinked]))
    # C03 corner consistency
    incons = []
    for c, cd in platform.corners.items():
        if cd.macro_temperature_c is not None and cd.macro_temperature_c != cd.temperature_c and design.macros.get(platform.name):
            incons.append(f"{c}: stdcell {cd.temperature_c} C vs SRAM macro {cd.macro_temperature_c} C")
    checks.append(chk("C03", "PVT consistency of Liberty sets within each corner", "WARNING" if incons else "PASS",
                      "nominal PVT of stdcell/IO/macro libraries", incons))
    if not log:
        checks.append(chk("C04", "OpenSTA constraint checks", "NOT RUN", f"no {stage_dir}/sta.log"))
        return _finish(design, platform, run_dir, checks, analysis)
    # C04 clocks on real sources / no-clock registers
    cs = {m: parse_check_setup(sd / f"check_setup_{m}.rpt") for m in meta.get("modes", {}) if (sd / f"check_setup_{m}.rpt").exists()}
    clocks = {m: read_json(sd / f"clocks_{m}.json", []) for m in meta.get("modes", {})}
    noclk = [f"{m}: {d['no_clock']['count']} register clock pins without clock" for m, d in cs.items() if "no_clock" in d]
    nosrc = [f"{m}: clock {c['name']} has no source" for m, cl in clocks.items() for c in cl if not c["sources"] and not c["is_virtual"]]
    checks.append(chk("C04", "Every register clocked; clocks defined on real sources", "FAIL" if noclk or nosrc else "PASS",
                      "check_setup -no_clock; clocks_<mode>.json", noclk + nosrc))
    # C05 periods
    badp = []
    for m, cl in clocks.items():
        for c in cl:
            try:
                want = design.clock(c["name"]).period_ns
            except KeyError:
                g = next((g for g in design.generated_clocks if g.name == c["name"]), None)
                want = design.clock(g.master).period_ns * g.divide_by if g else None
            if want is not None and abs(float(c["period_ns"]) - want) > 1e-6:
                badp.append(f"{m}: {c['name']} period {c['period_ns']} != configured {want}")
    checks.append(chk("C05", "Clock periods equal the configured targets", "FAIL" if badp else "PASS", "", badp))
    # C06-C08 static lint and SDC read warnings
    lint_rows, lint_fail, lint_warn = [], [], []
    rid = {e.id for e in exc.exceptions} if exc else None
    for m, mm in meta.get("modes", {}).items():
        lr = sdc_lint.lint(mm["sdc"], registry_ids=rid)
        lint_rows.append(lr.as_dict())
        lint_fail += [f"{m} L{f.line}: {f.rule} {f.message}" for f in lr.findings if f.severity == "FAIL"]
        lint_warn += [f"{m} L{f.line}: {f.rule} {f.message}" for f in lr.findings if f.severity == "WARNING"]
    dup = [x for x in lint_fail if "duplicate" in x]
    checks.append(chk("C06", "No duplicate clock declarations", "FAIL" if dup else "PASS", "static lint L01", dup))
    gen_issues = [f"{m}: {d['generated_clocks']['count']} generated-clock problems" for m, d in cs.items() if "generated_clocks" in d]
    gen_issues += [x for x in lint_fail if "genclk" in x]
    checks.append(chk("C07", "Generated clocks valid (master, source, RTL divider evidence)",
                      "FAIL" if gen_issues else ("PASS" if design.generated_clocks else "NOT APPLICABLE"),
                      "; ".join(f"{g.name}: {g.rtl_evidence[:80]}" for g in design.generated_clocks), gen_issues))
    sdcw = [f"{w[2].split('/')[-1]}:{w[3]} {w[0]} {w[1]}: {w[4]}" for w in SDC_WARN_RE.findall(log)]
    checks.append(chk("C08", "All SDC object/clock references resolve (no empty collections, unknown clocks or bad paths)",
                      "FAIL" if sdcw else "PASS", "read_sdc warnings/errors in sta.log", sdcw[:100]))
    # C09-C11 unconstrained endpoints / IO
    io_kind: list[tuple] = []
    if io:
        for g in io.groups:
            for p in g.ports:
                io_kind.append((p, g.kind, g.exception_id, g.modes))

    def justified(port: str, mode: str) -> str | None:
        for pat, kind, eid, modes in io_kind:
            if (modes is None or mode in modes) and (sdc_gen.sdc_match(port, pat) or port.split("[")[0] == pat):
                if kind in ("clock", "async", "reset", "static"):
                    return f"{kind}{' via ' + eid if eid else ''}"
        return None

    for cid, key, title in (("C09", "unconstrained_endpoints", "No unconstrained timing endpoints"),
                            ("C10", "input_no_delay", "Every input constrained (delay, exception or case analysis)"),
                            ("C11", "output_no_delay", "Every output constrained (delay or exception)")):
        unj, jus = [], []
        for m, d in cs.items():
            for it in d.get(key, {}).get("items", []):
                j = justified(it.split("/")[0], m)
                (jus if j else unj).append(f"{m}: {it}" + (f" [{j}]" if j else ""))
        n_total = sum(d.get(key, {}).get("count", 0) for d in cs.values())
        st = "FAIL" if unj else ("WARNING" if jus else "PASS")
        checks.append(chk(cid, title, st, f"check_setup -{key}: {n_total} reported across modes "
                          f"({len(jus)} justified by IO config, {len(unj)} unjustified)", unj + jus))
    # C12 IO coverage
    unc = [f"{m}: {p}" for m, mm in meta.get("modes", {}).items() for p in mm.get("uncovered_ports", [])]
    checks.append(chk("C12", "Every top-level port has a documented IO timing assumption", "FAIL" if unc else "PASS",
                      f"{meta.get('n_top_ports', 0)} port bits", unc[:100]))
    # C13 IO review status
    if io:
        checks.append(chk("C13", "IO timing assumptions reviewed against board/datasheet data",
                          "PASS" if io.status in ("REVIEWED", "MEASURED") else "WARNING",
                          f"status {io.status}, owner {io.owner}, level {io.level}", io.assumptions))
        bad = []
        for g in io.groups:
            if g.kind == "sync" and g.max_ns is not None and g.min_ns is not None:
                if g.min_ns > g.max_ns:
                    bad.append(f"{g.name}: min {g.min_ns} > max {g.max_ns}")
                try:
                    per = design.clock(g.clock).period_ns
                except KeyError:
                    gc = next((x for x in design.generated_clocks if x.name == g.clock), None)
                    per = design.clock(gc.master).period_ns * gc.divide_by if gc else None
                if per and g.max_ns >= per:
                    bad.append(f"{g.name}: max {g.max_ns} >= period {per} of {g.clock}")
            if g.kind == "sync" and (g.max_ns is None or g.min_ns is None):
                bad.append(f"{g.name}: insufficiently constrained (missing max/min)")
        checks.append(chk("C14", "IO delays internally consistent (min<=max<period, both present)",
                          "FAIL" if bad else "PASS", "", bad))
    else:
        checks.append(chk("C13", "IO timing assumptions reviewed", "FAIL", "no io_file: IO paths insufficiently constrained"))
    # C15 conflicting constraints, C17 ignored commands, C18 MCP pairs
    conf = [x for x in lint_warn if "L14" in x]
    checks.append(chk("C15", "No conflicting exceptions on the same path specification", "WARNING" if conf else "PASS", "lint L14", conf))
    ign = [x for x in lint_warn if "L09" in x] + [x for x in lint_fail if "L10" in x]
    checks.append(chk("C17", "No commands unsupported or ignored by the installed STA", "FAIL" if any("L10" in x for x in ign) else ("WARNING" if ign else "PASS"),
                      "OpenSTA 3.1.0 ignores set_ideal_network/latency/transition", ign))
    mcp = [x for x in lint_fail if "L11" in x]
    checks.append(chk("C18", "Every multicycle path has explicit setup AND hold multipliers", "FAIL" if mcp else "PASS", "lint L11", mcp))
    other_lint = [x for x in lint_fail if not any(k in x for k in ("L01", "L06-genclk", "L10", "L11"))]
    checks.append(chk("C16", "No unbounded or design-wide exceptions", "FAIL" if other_lint else "PASS", "lint L06/L07", other_lint))
    loops = [f"{m}: {d['loops']['count']} combinational loops" for m, d in cs.items() if "loops" in d]
    checks.append(chk("C19", "No combinational loops", "FAIL" if loops else "PASS", "check_setup -loops", loops))
    mult = [f"{m}: {d['multiple_clock']['count']} pins with multiple clocks" for m, d in cs.items() if "multiple_clock" in d]
    checks.append(chk("C20", "Register clock pins see one clock per mode", "WARNING" if mult else "PASS", "check_setup -multiple_clock", mult))
    checks += registry_checks(design, exc, ports)
    return _finish(design, platform, run_dir, checks, analysis, lint_rows)


def _finish(design, platform, run_dir: Path, checks: list[dict], analysis: dict | None, lint_rows=None) -> dict:
    if analysis is None:
        analysis = read_json(run_dir / "constraint_analysis" / "run_result.json")
        cdcj = read_json(run_dir / "constraint_analysis" / "cdc.json")
        if analysis is not None:
            analysis["cdc"] = cdcj
            analysis["impact"] = read_json(run_dir / "constraint_analysis" / "exception_impact.json", [])
    if analysis and analysis.get("status") == "PASS":
        imp = analysis.get("impact", [])
        bad = [f"{r['id']}: {'; '.join(r['notes'])}" for r in imp if r["verdict"] == "FAIL"]
        info = [f"{r['id']} [{r['verdict']}]: {r['endpoints_covered']} endpoints; {'; '.join(r['notes'])}" for r in imp]
        checks.append(chk("C21", "Exceptions do not hide functional paths (impact report)",
                          "FAIL" if bad else "PASS", "constraint_analysis/exception_impact.json", bad + info))
        cdcj = analysis.get("cdc") or {}
        st = cdcj.get("status", "NOT RUN")
        cst = "FAIL" if st == "FAIL" else "WARNING" if st.startswith("REVIEW") else "PASS" if st.startswith("PASS") else "NOT RUN"
        det = [f"{p['from']}->{p['to']} [{p['relationship']}]: {p['crossings']} crossings {p['by_class']} => {p['status']}"
               for p in cdcj.get("clock_pairs", []) if p["crossings"]]
        det += [f"async input {a['port_report']}: {a['by_class']} => {a['status']}" for a in cdcj.get("async_inputs", [])]
        checks.append(chk("C22", "Asynchronous clock groups backed by structural CDC evidence", cst,
                          "constraint_analysis/cdc.json (structural only; protocol review still required)", det))
        rdc = [f"{r['reset_source']} ({r['launch_clock']} -> {r['capture_clocks']}): {r['endpoints']} endpoints, {r['release']}"
               for r in cdcj.get("rdc", [])]
        checks.append(chk("C23", "Reset release synchronous to every reset domain (RDC)",
                          "WARNING" if any("review" in x for x in rdc) else ("PASS" if rdc else "NOT RUN"),
                          "recovery/removal paths without exceptions", rdc[:40]))
    else:
        checks.append(chk("C21", "Exceptions do not hide functional paths (impact report)", "NOT RUN",
                          "run `timingflow check-sdc` (constraint analysis)"))
        checks.append(chk("C22", "Asynchronous clock groups backed by structural CDC evidence", "NOT RUN", ""))
        checks.append(chk("C23", "Reset release synchronous to every reset domain (RDC)", "NOT RUN", ""))
    order = {"FAIL": 0, "WARNING": 1, "NOT RUN": 2, "PASS": 3, "NOT APPLICABLE": 4}
    overall = min((c["status"] for c in checks), key=lambda s: order[s]) if checks else "NOT RUN"
    if overall == "NOT APPLICABLE":
        overall = "PASS"
    res = {"design": design.name, "platform": platform.name, "overall": overall,
           "counts": {s: sum(1 for c in checks if c["status"] == s) for s in STATUSES},
           "checks": sorted(checks, key=lambda c: c["id"]), "lint": lint_rows or []}
    (run_dir / "constraint_audit.json").write_text(json.dumps(res, indent=1))
    return res
