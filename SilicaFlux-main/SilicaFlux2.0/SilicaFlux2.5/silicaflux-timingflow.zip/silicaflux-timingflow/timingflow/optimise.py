"""Multi-objective experiment runner with Pareto selection.

An experiment file (configs/experiments/*.yaml) lists candidates that differ
ONLY in RTL parameters / design variant / physical knobs.  Timing constraints
(period, uncertainty, IO, exceptions) are fixed requirements: a candidate that
changes them is rejected unless the experiment is explicitly labelled
``sensitivity: true``.

Each candidate is run through the real flow (Yosys + OpenSTA [+ OpenROAD]);
candidates whose run fails, whose functional check fails or is not provided, or
that violate a declared constraint are REJECTED with the reason and excluded
from the Pareto front.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import yaml

from . import flow
from .compare import compare
from .config import load_design
from .parse_reports import read_json
from .paths import REPORTS_DIR, ROOT


def _metrics(rd: Path, stage: str) -> dict:
    sm = read_json(rd / f"sta_{stage}" / "summary.json")
    syn = read_json(rd / "synth" / "synth_summary.json", {}) or {}
    if not sm or sm.get("status") != "PASS":
        return {"status": "FAIL" if sm else "NOT RUN"}
    sc = sm["scenes"]
    r2r = [v["reg2reg"]["setup_wns_ns"] for v in sc.values() if v["reg2reg"]["setup_wns_ns"] is not None]
    r2r_h = [v["reg2reg"]["hold_wns_ns"] for v in sc.values() if v["reg2reg"]["hold_wns_ns"] is not None]
    worst = min(sc.items(), key=lambda kv: kv[1]["reg2reg"]["setup_wns_ns"] if kv[1]["reg2reg"]["setup_wns_ns"] is not None else 1e9)
    top = worst[1]["top_reg2reg_paths"][:1]
    return {"status": "PASS", "reg2reg_setup_wns_ns": min(r2r) if r2r else None,
            "reg2reg_hold_wns_ns": min(r2r_h) if r2r_h else None,
            "wns_ns": min(v["wns_ns"] for v in sc.values()), "tns_ns": min(v["tns_ns"] for v in sc.values()),
            "worst_scene": worst[0], "worst_path": top[0] if top else None,
            "area_um2": syn.get("total_area_um2"), "cells": syn.get("n_cells"),
            "flops": (syn.get("cell_classes") or {}).get("flops"),
            "fmax_derived_mhz": worst[1]["reg2reg"].get("fmax_derived_mhz"), **_phys_area(rd, stage)}


PHYS_PREFIX = {"placement": "post_place", "cts": "post_cts", "global_route": "post_grt", "postroute": "post_route"}


def _phys_area(rd: Path, stage: str) -> dict:
    """Placed cell area and core area (cell area / utilisation) from the OpenROAD stage metrics."""
    if stage not in PHYS_PREFIX:
        return {}
    pm = (read_json(rd / f"sta_{stage}" / "run_result.json", {}) or {}).get("phys_metrics") or {}
    pre = PHYS_PREFIX[stage]
    try:
        a, u = float(pm[f"{pre}_area_um2"]), float(pm[f"{pre}_util"])
    except (KeyError, ValueError):
        return {}
    return {"placed_cell_area_um2": a, "core_utilisation": u, "core_area_um2": round(a / u, 1) if u else None,
            "buffers_inverters": int(float(pm.get(f"{pre}_buffers_inverters", 0)))}


def pareto(cands: list[dict], objectives: dict[str, str], tolerances: dict[str, float] | None = None) -> None:
    """Mark non-dominated valid candidates.

    ``tolerances`` gives, per objective, the difference below which two values
    count as equal (e.g. the measured synthesis noise floor).  A candidate only
    dominates another if it is better by more than the tolerance in at least
    one objective and not worse by more than the tolerance in any.
    """
    tol = tolerances or {}
    valid = [c for c in cands if c["status"] == "PASS" and all(c.get(k) is not None for k in objectives)]

    def gain(a, b, k, d):  # how much better a is than b on objective k
        return (a[k] - b[k]) if d == "max" else (b[k] - a[k])

    def better(a, b):  # a dominates b
        ge = all(gain(a, b, k, d) >= -tol.get(k, 0.0) for k, d in objectives.items())
        gt = any(gain(a, b, k, d) > tol.get(k, 0.0) for k, d in objectives.items())
        return ge and gt
    for c in cands:
        c["pareto"] = c in valid and not any(better(o, c) for o in valid if o is not c)


def run_experiment(path: Path, dry_run: bool = False) -> dict:
    ex = yaml.safe_load(Path(path).read_text())
    name, stage = ex["name"], ex.get("stage", "synthesis")
    sens = bool(ex.get("sensitivity", False))
    out = REPORTS_DIR / "experiments" / name
    out.mkdir(parents=True, exist_ok=True)
    cands = []
    base_rd = None
    for c in ex["candidates"]:
        label = c["label"]
        design = c.get("design", ex["design"])
        plat = c.get("platform", ex.get("platform", "ihp_sg13g2"))
        run = f"{name}_{label}" if name.startswith("exp_") else f"exp_{name}_{label}"
        rec = {"label": label, "design": design, "platform": plat, "run": run, "params": c.get("params", {}),
               "latency_cycles": c.get("latency_cycles"), "latency_evidence": c.get("latency_evidence", ""),
               "note": c.get("note", "")}
        if c.get("period") and not sens:
            rec.update(status="REJECTED", reject_reason="changes the clock constraint in a non-sensitivity experiment")
            cands.append(rec)
            continue
        for rule in ex.get("constraints", []):
            if rule.get("param") in rec["params"] and str(rec["params"][rule["param"]]) not in [str(v) for v in rule["allowed"]]:
                rec.update(status="REJECTED", reject_reason=f"{rule['param']}={rec['params'][rule['param']]} violates: {rule['reason']}")
        if rec.get("status") == "REJECTED":
            cands.append(rec)
            continue
        if dry_run:
            rec["status"] = "NOT RUN"
            cands.append(rec)
            continue
        rd = flow.run_dir_for(design, plat, run)
        stages = ["synth", "synthesis"] + ([s for s in ("placement", "cts", "global_route", "postroute")
                                           if flow.STAGES.index(s) <= flow.STAGES.index(stage)] if stage != "synthesis" else [])
        ok = True
        for s in stages:
            r = flow.run_stage(design, plat, s, run, c.get("period"), c.get("params"), None, "none", 4, c.get("physical"))
            if r.get("status") != "PASS":
                rec.update(status="FAIL", reject_reason=f"{s}: {r.get('reason') or r.get('tail', '')[-300:]}")
                ok = False
                break
        if ok:
            rec.update(_metrics(rd, stage))
            fc = c.get("functional_check") or ex.get("functional_check")
            if fc:
                cmd = fc.format(**{k: v for k, v in rec["params"].items()}, root=str(ROOT))
                p = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=ROOT, timeout=3600)
                rec["functional"] = "PASS" if p.returncode == 0 else "FAIL"
                rec["functional_log"] = (p.stdout + p.stderr)[-1500:]
                if p.returncode != 0:
                    rec.update(status="REJECTED", reject_reason="functional check failed")
            else:
                rec["functional"] = "NOT RUN"
            if ex.get("area_budget_um2") and rec.get("area_um2") and rec["area_um2"] > ex["area_budget_um2"]:
                rec.update(status="REJECTED", reject_reason=f"area {rec['area_um2']:.0f} > budget {ex['area_budget_um2']}")
            if base_rd is None:
                base_rd = rd
        cands.append(rec)
    objectives = ex.get("objectives", {"reg2reg_setup_wns_ns": "max", "area_um2": "min"})
    tolerances = ex.get("tolerances", {})
    pareto(cands, objectives, tolerances)
    if sens:  # the constraint was varied on purpose: candidates are not alternatives, so no front
        for c in cands:
            c["pareto"] = False
    res = {"name": name, "description": ex.get("description", ""), "stage": stage, "sensitivity": sens,
           "objectives": objectives, "tolerances": tolerances, "status": "DONE" if not dry_run else "DRY RUN",
           "candidates": cands, "experiment_file": str(path)}
    passed = [c for c in cands if c["status"] == "PASS"]
    if len(passed) >= 2:
        a = flow.run_dir_for(passed[0]["design"], passed[0]["platform"], passed[0]["run"])
        b = flow.run_dir_for(passed[1]["design"], passed[1]["platform"], passed[1]["run"])
        res["comparison"] = compare(a, b, stage)
    (out / "result.json").write_text(json.dumps(res, indent=1, default=str))
    return res


def rescore(path: Path) -> dict:
    """Recompute metrics (from the candidates' existing summaries) and the Pareto
    front of an executed experiment with the current objectives/tolerances.
    No tool is run; candidates that were REJECTED keep their status."""
    ex = yaml.safe_load(Path(path).read_text())
    out = REPORTS_DIR / "experiments" / ex["name"] / "result.json"
    res = json.loads(out.read_text())
    stage = res.get("stage", "synthesis")
    for c in res["candidates"]:
        if c["status"] == "PASS":
            m = _metrics(flow.run_dir_for(c["design"], c["platform"], c["run"]), stage)
            if m.get("status") == "PASS":
                c.update(m)
    res["objectives"] = ex.get("objectives", res.get("objectives"))
    res["tolerances"] = ex.get("tolerances", {})
    pareto(res["candidates"], res["objectives"], res["tolerances"])
    if res.get("sensitivity"):
        for c in res["candidates"]:
            c["pareto"] = False
    out.write_text(json.dumps(res, indent=1, default=str))
    return res
