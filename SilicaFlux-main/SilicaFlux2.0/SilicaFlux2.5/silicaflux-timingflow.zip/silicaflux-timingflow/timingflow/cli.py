"""TimingFlow command-line interface.

  python -m timingflow tools
  python -m timingflow run --design silicaflux_v --platform ihp_sg13g2 --stage synthesis
  python -m timingflow flow --design silicaflux_v --platform ihp_sg13g2 --to check_sdc
  python -m timingflow lint-sdc FILE.sdc [...]
  python -m timingflow exceptions --design silicaflux_v
  python -m timingflow report --design silicaflux_v --platform ihp_sg13g2
  python -m timingflow gates --design silicaflux_v --platform ihp_sg13g2
  python -m timingflow compare --baseline RUN_DIR_A --candidate RUN_DIR_B [--stage synthesis]
  python -m timingflow optimise --experiment configs/experiments/<x>.yaml
  python -m timingflow repro --design silicaflux_v --platform ihp_sg13g2
  python -m timingflow dashboard [--out reports/dashboard.html]
  python -m timingflow summarize --design silicaflux_v --platform ihp_sg13g2 [--stage cts]   (re-parse raw reports, no tool run)
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import config, flow


def _params(kv: list[str] | None) -> dict:
    out = {}
    for s in kv or []:
        k, _, v = s.partition("=")
        out[k] = v
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="timingflow", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("tools", help="tool versions and command support")
    sub.add_parser("list", help="designs and platforms")

    def common(p, stage=False):
        p.add_argument("--design", required=True)
        p.add_argument("--platform", default="ihp_sg13g2")
        p.add_argument("--run", default="baseline")
        if stage:
            p.add_argument("--period", type=float, help="override primary clock period (ns) — labelled as a sensitivity run")
            p.add_argument("--corners", nargs="*")
            p.add_argument("--param", nargs="*", help="RTL parameter overrides K=V")
            p.add_argument("--wire-load", help="library wire-load model for a labelled stage-A sensitivity run")
            p.add_argument("--threads", type=int, default=4)
            p.add_argument("--core-util", type=float)

    p = sub.add_parser("run", help="run one stage")
    common(p, True)
    p.add_argument("--stage", required=True, choices=flow.STAGES)
    p = sub.add_parser("flow", help="run stages in order up to --to")
    common(p, True)
    p.add_argument("--to", default="check_sdc", choices=flow.STAGES)
    p.add_argument("--from", dest="frm", default="synth", choices=flow.STAGES)
    p = sub.add_parser("lint-sdc", help="static lint of SDC files")
    p.add_argument("files", nargs="+")
    p = sub.add_parser("exceptions", help="validate the exception registry")
    p.add_argument("--design", required=True)
    for name in ("report", "gates", "repro"):
        p = sub.add_parser(name)
        common(p)
    p = sub.add_parser("repair", help="controlled OpenROAD timing repair on a stage database")
    common(p)
    p.add_argument("--kind", choices=["setup", "hold"], required=True)
    p.add_argument("--stage", choices=["placement", "cts", "global_route"], required=True)
    p.add_argument("--max-iter", type=int, default=5)
    p.add_argument("--max-buffer-pct", type=float, default=20)
    p.add_argument("--setup-margin", type=float, default=0.0, help="setup repair target margin in ns (0 = fix violations only)")
    p.add_argument("--drv-first", action="store_true", help="run repair_design (slew/cap/fanout) on the stage parasitics first")
    p = sub.add_parser("compare")
    p.add_argument("--baseline", required=True)
    p.add_argument("--candidate", required=True)
    p.add_argument("--stage", default="synthesis")
    p = sub.add_parser("optimise")
    p.add_argument("--experiment", required=True)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--rescore", action="store_true", help="recompute metrics/Pareto of an executed experiment (no tool run)")
    p = sub.add_parser("summarize", help="re-parse the raw OpenSTA/OpenROAD reports of an existing run (no tool is executed)")
    common(p)
    p.add_argument("--stage", nargs="*", choices=flow.STAGES[1:2] + ["placement", "cts", "global_route", "postroute"])
    p = sub.add_parser("dashboard")
    p.add_argument("--out", default=None)
    a = ap.parse_args(argv)

    if a.cmd == "tools":
        from .provenance import tool_versions
        print(json.dumps({k: v for k, v in tool_versions().items() if k != "pinned"}, indent=1))
        return 0
    if a.cmd == "list":
        for d in config.list_designs():
            dc = config.load_design(d)
            print(f"{d:24s} {dc.status:12s} {dc.title}")
        print("platforms:", ", ".join(config.list_platforms()), "(commercial: NOT AVAILABLE)")
        return 0
    if a.cmd in ("run", "flow"):
        stages = [a.stage] if a.cmd == "run" else flow.STAGES[flow.STAGES.index(a.frm): flow.STAGES.index(a.to) + 1]
        rc = 0
        phys = {"core_util": a.core_util} if getattr(a, "core_util", None) else {}
        for s in stages:
            r = flow.run_stage(a.design, a.platform, s, a.run, a.period, _params(a.param), a.corners,
                               f"wire_load:{a.wire_load}" if a.wire_load else "none", a.threads, phys)
            print(f"[{s}] {r.get('status')} {r.get('reason', '') or ''} {r.get('runtime_s', '')}")
            if r.get("status") not in ("PASS",):
                rc = 1 if r.get("status") == "FAIL" else rc
                if a.cmd == "flow":
                    break
        return rc
    if a.cmd == "lint-sdc":
        from .sdc_lint import lint
        rc = 0
        for f in a.files:
            r = lint(f)
            print(f"{f}: {r.status()}")
            for x in r.findings:
                print(f"  {x.severity:8s} {x.rule} line {x.line}: {x.message}")
            rc |= r.status() == "FAIL"
        return rc
    if a.cmd == "exceptions":
        from .constraints import registry_checks
        d = config.load_design(a.design)
        for c in registry_checks(d, config.load_exceptions(d), {}):
            print(f"{c['id']} {c['status']:8s} {c['title']} — {c['evidence']}")
            for x in c["details"]:
                print("    ", x)
        return 0
    if a.cmd in ("report", "gates", "repro"):
        rd = flow.run_dir_for(a.design, a.platform, a.run)
        d, p = config.load_design(a.design), config.load_platform(a.platform)
        if a.cmd == "gates":
            from .gates import evaluate
            r = evaluate(d, p, rd)
            print(f"signoff: {r['signoff']}")
            for gg in r["gates"]:
                print(f"  G{gg['gate']:<2d} {gg['status']:9s} {gg['title']} — {gg['evidence']}")
            return 0
        if a.cmd == "repro":
            from .repro import check
            r = check(a.design, a.platform, a.run)
            print(json.dumps(r, indent=1))
            return 0 if r.get("identical") else 1
        from .gates import evaluate
        from .report import write
        evaluate(d, p, rd)
        r = write(rd)
        print(json.dumps(r, indent=1))
        return 0
    if a.cmd == "repair":
        from .physical import run_repair
        rd = flow.run_dir_for(a.design, a.platform, a.run)
        r = run_repair(config.load_design(a.design), config.load_platform(a.platform), rd, a.kind, a.stage,
                       opts={"max_iter": a.max_iter, "max_buffer_pct": a.max_buffer_pct,
                             "setup_margin": a.setup_margin, "drv_first": a.drv_first})
        print(json.dumps({k: v for k, v in r.items() if k != "repair_result_tcl"}, indent=1))
        return 0 if r.get("status") == "PASS" else 1
    if a.cmd == "compare":
        from .compare import compare
        r = compare(Path(a.baseline), Path(a.candidate), a.stage)
        print(json.dumps(r, indent=1))
        return 0
    if a.cmd == "optimise":
        from .optimise import rescore, run_experiment
        r = rescore(Path(a.experiment)) if a.rescore else run_experiment(Path(a.experiment), dry_run=a.dry_run)
        print(json.dumps({k: v for k, v in r.items() if k != "candidates"}, indent=1))
        return 0
    if a.cmd == "summarize":
        from . import summary
        rd = flow.run_dir_for(a.design, a.platform, a.run)
        d, p = config.load_design(a.design), config.load_platform(a.platform)
        for st in a.stage or ["synthesis", "placement", "cts", "global_route", "postroute"]:
            rr = rd / f"sta_{st}" / "run_result.json"
            if not rr.exists() or json.loads(rr.read_text()).get("status") != "PASS":
                print(f"[{st}] NOT RUN (no passing run_result.json)")
                continue
            s = summary.summarize_stage(d, p, rd, st, f"sta_{st}")
            print(f"[{st}] {s['status']} {s['label']} scenes={len(s['scenes'])}")
        return 0
    if a.cmd == "dashboard":
        from .dashboard import build
        print(build(Path(a.out) if a.out else None))
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
