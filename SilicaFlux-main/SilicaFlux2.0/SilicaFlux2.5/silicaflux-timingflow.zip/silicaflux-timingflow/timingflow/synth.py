"""Yosys synthesis driver (TimingFlow Stage A input).

Produces a mapped gate-level netlist for one design on one platform:

* synthesis Liberty = synthesis-corner stdcell Liberty with the platform's
  dont_use cells marked (Yosys 0.33 has no ``-dont_use`` switch);
* SRAM macros and RTL-instantiated library cells are read ``-lib`` (black
  boxes with Liberty pins); nothing is inferred for a hard macro;
* hierarchy is kept at the block boundaries listed in the design config so
  every timing-path pin carries its real instance path (used by the
  critical-path classifier — no string guessing on flattened names);
* flip-flops are renamed after the RTL register they implement
  (``rename -wire -suffix _reg``) so start/end points are traceable;
* latches are listed; ``check`` warnings are counted and kept.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import time
from pathlib import Path

from . import liberty
from .config import DesignConfig, Platform
from .paths import env


def _q(p: Path | str) -> str:
    s = str(p)
    return '"' + s + '"' if " " in s else s


def synth_libs(platform: Platform, design: DesignConfig, out: Path) -> dict:
    """Write the dont_use-marked synthesis Liberty; return lib paths."""
    corner = platform.synthesis_corner
    libs = platform.liberty_set(corner, design.macros.get(platform.name, []))
    out.mkdir(parents=True, exist_ok=True)
    std = []
    marked_all = []
    for src in libs["stdcell"]:
        if not src.exists():
            raise FileNotFoundError(f"missing stdcell Liberty {src} (set ORFS_PLATFORMS)")
        dst = out / f"synth_{src.name}"
        marked_all += liberty.mark_dont_use(src, dst, platform.cells.dont_use)
        std.append(dst)
    missing = [str(m) for m in libs["macro"] if not m.exists()]
    if missing:
        raise FileNotFoundError("missing SRAM macro Liberty (no timing model => no STA): " + ", ".join(missing))
    return {"corner": corner, "stdcell": std, "stdcell_src": libs["stdcell"],
            "macro": libs["macro"], "dont_use_marked": marked_all}


def yosys_script(design: DesignConfig, platform: Platform, libs: dict, out: Path,
                 period_ns: float, params: dict | None = None) -> str:
    files = design.rtl_files(platform.name)
    missing = [str(f) for f in files if not f.exists()]
    if missing:
        raise FileNotFoundError("missing RTL: " + ", ".join(missing))
    defs = " ".join(f"-D{d}" for d in design.defines)
    incs = " ".join(f"-I{_q(design.src_root() / i)}" for i in design.include_dirs)
    std = libs["stdcell"][0]
    chparams = {**design.parameters, **(params or {})}
    chp = " ".join(f"-chparam {k} {v}" for k, v in chparams.items())
    lines = [f"# TimingFlow synthesis script: {design.name} on {platform.name} "
             f"(corner {libs['corner']}, abc target {period_ns} ns)"]
    for lib in libs["stdcell"]:
        lines.append(f"read_liberty -lib {_q(lib)}")
    for lib in libs["macro"]:
        lines.append(f"read_liberty -lib {_q(lib)}")
    defer = "-defer " if design.synth.defer else ""
    lines.append(f"read_verilog {defer}-sv {defs} {incs} " + " ".join(_q(f) for f in files))
    lines.append(f"hierarchy -check -top {design.top} {chp}".rstrip())
    for m in design.synth.keep_hierarchy:
        # plain module, '$paramod$<hash>\\name' and '$paramod\\name\\P=V...' forms
        lines.append(f"setattr -mod -set keep_hierarchy 1 {m} $paramod*\\{m} $paramod*\\{m}\\*")
    lines.append(f"synth -top {design.top}" + (" -flatten" if design.synth.flatten else ""))
    lines.append(f"tee -o {_q(out / 'latches.txt')} select -list t:$dlatch* t:$_DLATCH* t:$sr t:$_SR_*")
    lines.append("opt -purge")
    lines.append(f"dfflibmap -liberty {_q(std)}")
    lines.append("rename -wire -suffix _reg t:* t:$* %d")
    load_pf = platform.cells.abc_load_ff / 1000.0
    constr = out / "abc.constr"
    constr.write_text(f"set_driving_cell {platform.cells.abc_driver}\nset_load {load_pf}\n")
    abc_script = ""
    if design.synth.abc_script == "speed":
        sp = Path(env("ORFS_SCRIPTS")) / "abc_speed.script"
        if not sp.exists():
            raise FileNotFoundError(f"ORFS abc_speed.script not found at {sp} (set ORFS_SCRIPTS)")
        abc_script = f"-script {_q(sp)} "
    lines.append(f"abc {abc_script}-liberty {_q(std)} -D {int(round(period_ns * 1000))} -constr {_q(constr)}")
    lines.append("opt_clean")
    th, tl = platform.cells.tiehi, platform.cells.tielo
    lines.append(f"hilomap -singleton -hicell {th[0]} {th[1]} -locell {tl[0]} {tl[1]}")
    lines.append("setundef -zero")
    b = platform.cells.min_buffer
    lines.append(f"insbuf -buf {b[0]} {b[1]} {b[2]}")
    lines.append("opt_clean -purge")
    lines.append(f"tee -o {_q(out / 'check.txt')} check")
    stat_libs = " ".join(f"-liberty {_q(l)}" for l in [std] + list(libs["macro"]))
    lines.append(f"tee -o {_q(out / 'stat.txt')} stat -top {design.top} {stat_libs}")
    lines.append(f"write_verilog -noattr -noexpr -nohex -nodec {_q(out / 'netlist.v')}")
    return "\n".join(lines) + "\n"


_AREA_RE = re.compile(r"Chip area for (?:top )?module '\\?([^']+)':\s*([0-9.]+)")


def parse_stat(text: str, top: str) -> dict:
    """Parse ``stat -top`` output: per-module areas and the hierarchy total."""
    areas = {m.group(1): float(m.group(2)) for m in _AREA_RE.finditer(text)}
    res = {"module_area_um2": areas}
    m = re.search(r"design hierarchy ===.*?Chip area for top module '\\?[^']+':\s*([0-9.]+)", text, re.S)
    if m:
        res["total_area_um2"] = float(m.group(1))
    elif areas:
        res["total_area_um2"] = areas.get(top) or max(areas.values())
    # top-level (hierarchy) cell type counts: last "Number of cells" block
    blocks = text.split("=== design hierarchy ===")
    tail = blocks[-1] if len(blocks) > 1 else text
    cells = {}
    for mm in re.finditer(r"^\s{5}(\S+)\s+(\d+)\s*$", tail, re.M):
        cells[mm.group(1)] = int(mm.group(2))
    res["cell_counts"] = cells
    n = re.findall(r"Number of cells:\s+(\d+)", tail)
    if n:
        res["n_cells"] = int(n[-1])
    return res


def classify_cells(cells: dict, std_libs: list[Path], macros: list[str]) -> dict:
    """Count flops / latches / ICGs / macros / combinational cells using the
    Liberty groups of the synthesis library (no name heuristics)."""
    classes: dict[str, str] = {}
    for lib in std_libs:
        classes.update(liberty.cell_classes(lib))
    out = {"flops": 0, "latches": 0, "macros": 0, "icg": 0, "comb": 0, "other": 0}
    for name, n in cells.items():
        if name in macros:
            out["macros"] += n
        else:
            k = {"ff": "flops", "latch": "latches", "icg": "icg", "comb": "comb"}.get(classes.get(name, ""), "other")
            out[k] += n
    return out


def sanitize_module_names(netlist: Path) -> dict[str, str]:
    """Rename Yosys '$paramod...' module *types* to readable identifiers.

    Only module type names change (definitions + instantiation types); instance
    names, nets and logic are untouched.  Returns {old: new}.
    """
    import hashlib
    text = netlist.read_text()
    olds = re.findall(r"^module \\(\$paramod\S+)", text, re.M)
    mapping = {}
    for old in olds:
        base = old.split("\\")[1] if "\\" in old else old
        h = hashlib.sha1(old.encode()).hexdigest()[:6]
        mapping[old] = f"{base}__p{h}"
    for old, new in mapping.items():
        text = text.replace("\\" + old + " ", new + " ")
    netlist.write_text(text)
    return mapping


def run(design: DesignConfig, platform: Platform, out: Path, period_ns: float,
        params: dict | None = None) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    yosys = env("YOSYS")
    if not shutil.which(yosys):
        return {"status": "NOT RUN", "reason": f"yosys not found ({yosys})"}
    libs = synth_libs(platform, design, out / "lib")
    script = yosys_script(design, platform, libs, out, period_ns, params)
    (out / "synth.ys").write_text(script)
    t0 = time.time()
    proc = subprocess.run([yosys, "-q", "-l", str(out / "yosys.log"), "-s", str(out / "synth.ys")],
                          capture_output=True, text=True, timeout=design.synth.timeout_s)
    dt = time.time() - t0
    log = (out / "yosys.log").read_text(errors="replace") if (out / "yosys.log").exists() else ""
    warnings = re.findall(r"^Warning: (.*)$", log, re.M)
    errors = re.findall(r"^ERROR: (.*)$", log, re.M)
    res = {"status": "PASS" if proc.returncode == 0 and (out / "netlist.v").exists() else "FAIL",
           "returncode": proc.returncode, "runtime_s": round(dt, 1),
           "period_target_ns": period_ns, "synthesis_corner": libs["corner"],
           "synthesis_liberty": [str(p) for p in libs["stdcell_src"]],
           "macro_liberty": [str(p) for p in libs["macro"]],
           "dont_use_marked": libs["dont_use_marked"],
           "n_warnings": len(warnings), "warnings_unique": sorted(set(warnings))[:200],
           "errors": errors, "parameters": {**design.parameters, **(params or {})},
           "netlist": str(out / "netlist.v")}
    if res["status"] == "PASS":
        res["module_renames"] = sanitize_module_names(out / "netlist.v")
        stat = parse_stat((out / "stat.txt").read_text(), design.top)
        res.update(stat)
        res["cell_classes"] = classify_cells(stat.get("cell_counts", {}), libs["stdcell"],
                                             design.macros.get(platform.name, []))
        lat = (out / "latches.txt").read_text() if (out / "latches.txt").exists() else ""
        res["inferred_latches"] = [l.strip() for l in lat.splitlines() if l.strip() and not l.startswith(("\n", "--"))]
        chk = (out / "check.txt").read_text() if (out / "check.txt").exists() else ""
        res["check_warnings"] = len(re.findall(r"^Warning:", chk, re.M))
        res["check_problems"] = [l for l in chk.splitlines() if "problem" in l.lower()][:5]
    else:
        res["stderr_tail"] = (proc.stderr or "")[-2000:]
        res["log_tail"] = log[-3000:]
    (out / "synth_summary.json").write_text(json.dumps(res, indent=1))
    return res
