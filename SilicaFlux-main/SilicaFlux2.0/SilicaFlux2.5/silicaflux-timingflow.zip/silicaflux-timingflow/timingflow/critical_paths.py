"""Critical-path explorer: classification and ranking of real STA paths.

Block attribution uses the netlist instance hierarchy (kept at block
boundaries during synthesis) mapped through the design's ``block_map``
(longest matching instance-path prefix).  Top-level ports are ``IO``.
Pins that match no prefix are ``UNKNOWN`` — they are never guessed.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from .config import BlockMapEntry


def _norm(s: str) -> str:
    return s.replace(".", "/")


@dataclass
class BlockMapper:
    entries: list[BlockMapEntry]
    ports: set[str] | None = None

    def __post_init__(self):
        self._sorted = sorted(((_norm(e.prefix), e) for e in self.entries), key=lambda x: -len(x[0]))

    def classify(self, name: str | None) -> tuple[str, str]:
        if not name:
            return "UNKNOWN", ""
        base = name.split(" ")[0]
        if "/" not in base and "." not in base:
            if self.ports is None or base in self.ports or base.split("[")[0] in {p.split("[")[0] for p in self.ports}:
                return "IO", base
        n = _norm(base)
        for pref, e in self._sorted:
            if n.startswith(pref):
                return e.block, e.sub
        if base.count("/") <= 1 and not any(base.startswith(p.rstrip("/")) for p, _ in self._sorted):
            return "UNKNOWN", "top-level glue (no block hierarchy)"
        return "UNKNOWN", ""


def classify_path(path: dict, mapper: BlockMapper, fanout_limit: int | None = None,
                  interconnect_modelled: bool = False) -> dict:
    sb, ss = mapper.classify(path.get("startpoint"))
    eb, es = mapper.classify(path.get("endpoint"))
    contrib: dict[str, float] = defaultdict(float)
    seq: list[str] = []
    max_fo, max_slew, hfn = 0, 0.0, []
    pts = path.get("points", [])
    launch = 0.0
    if pts and pts[0].get("arc") == "start" and (pts[0].get("arrival_ns") or 0) > 0 and \
            not pts[0]["pin"].endswith(("/CLK", "/CK", "/A_CLK", "/clk0")):
        # path starts at a macro/port output: the arrival already contains the
        # launch delay (e.g. SRAM clock-to-DOUT, input delay + pad driver)
        launch = pts[0]["arrival_ns"] - (path.get("launch_clock_arrival_ns") or 0.0)
        contrib[sb] += launch
    for pt in pts:
        b, _ = mapper.classify(pt.get("instance") or pt.get("pin"))
        if pt.get("arc") in ("cell", "net"):
            contrib[b] += pt.get("incr_ns") or 0.0
        if not seq or seq[-1] != b:
            seq.append(b)
        fo = pt.get("fanout")
        if fo:
            max_fo = max(max_fo, fo)
            if fanout_limit and fo > fanout_limit:
                hfn.append({"pin": pt["pin"], "fanout": fo})
        if pt.get("slew_ns"):
            max_slew = max(max_slew, pt["slew_ns"])
    owner = max(contrib.items(), key=lambda kv: kv[1])[0] if contrib else eb
    cell, net = path.get("cell_delay_ns", 0.0), path.get("net_delay_ns", 0.0)
    if not interconnect_modelled:
        dominance = "cell (interconnect not modelled at this stage)"
    else:
        dominance = "cell-delay dominated" if cell >= net else "interconnect dominated"
    return {
        "start_block": sb, "start_sub": ss, "end_block": eb, "end_sub": es,
        "owner_block": owner, "block_sequence": seq,
        "delay_by_block_ns": {k: round(v, 4) for k, v in sorted(contrib.items(), key=lambda kv: -kv[1])},
        "cell_delay_ns": cell, "net_delay_ns": net, "launch_delay_ns": round(launch, 4), "dominance": dominance,
        "max_fanout": max_fo or None, "max_slew_ns": round(max_slew, 4) if max_slew else None,
        "high_fanout_nets": hfn[:10], "crosses_blocks": len(set(seq) - {"IO"}) > 1,
    }


def summarize_path(path: dict, cls: dict) -> dict:
    return {k: path.get(k) for k in ("check", "group", "startpoint", "endpoint", "launch_clock", "capture_clock",
                                    "arrival_ns", "required_ns", "slack_ns", "logic_depth",
                                    "launch_clock_arrival_ns", "capture_clock_arrival_ns", "crpr_ns",
                                    "margin_ns")} | cls


def rank_paths(paths: list[dict], mapper: BlockMapper, fanout_limit: int | None = None,
               interconnect_modelled: bool = False, top: int = 50) -> list[dict]:
    out = []
    for p in sorted(paths, key=lambda p: p.get("slack_ns", 0.0)):
        out.append(summarize_path(p, classify_path(p, mapper, fanout_limit, interconnect_modelled)))
        if len(out) >= top:
            break
    for i, r in enumerate(out):
        r["rank"] = i + 1
    return out


def block_bottlenecks(end_rows: list[dict], mapper: BlockMapper, check: str = "setup",
                      exclude_groups: set[str] | frozenset[str] = frozenset()) -> list[dict]:
    """Per block: endpoints, violators, worst slack and TNS (endpoint attribution).

    ``exclude_groups`` drops path groups (e.g. recovery/removal) so a block's
    clocked data endpoints are not masked by a design-wide reset problem.
    """
    agg: dict[str, dict] = {}
    for r in end_rows:
        if r["check"] != check or r["group"] in exclude_groups:
            continue
        b, _ = mapper.classify(r["endpoint"])
        a = agg.setdefault(b, {"block": b, "endpoints": 0, "violators": 0, "wns_ns": None, "tns_ns": 0.0,
                               "worst_endpoint": None, "groups": Counter()})
        a["endpoints"] += 1
        a["groups"][r["group"]] += 1
        if r["violated"]:
            a["violators"] += 1
            a["tns_ns"] += r["slack_ns"]
        if a["wns_ns"] is None or r["slack_ns"] < a["wns_ns"]:
            a["wns_ns"], a["worst_endpoint"] = r["slack_ns"], r["endpoint"]
    rows = []
    for a in agg.values():
        a["tns_ns"] = round(a["tns_ns"], 4)
        a["groups"] = dict(a["groups"])
        rows.append(a)
    return sorted(rows, key=lambda a: (a["wns_ns"] if a["wns_ns"] is not None else 1e9))
