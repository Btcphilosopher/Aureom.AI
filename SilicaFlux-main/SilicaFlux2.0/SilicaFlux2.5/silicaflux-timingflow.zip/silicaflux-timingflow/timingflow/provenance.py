"""Provenance: everything needed to reproduce or qualify a result.

A report without provenance is not qualified evidence; every summary embeds
the block produced here (tool revisions, Liberty hashes, design and constraint
revisions, parasitic method, stage, analysis mode).
"""
from __future__ import annotations

import hashlib
import json
import platform as pyplat
import shutil
import subprocess
from functools import lru_cache
from pathlib import Path

from . import liberty
from .config import DesignConfig, Platform, config_digest
from .paths import ROOT, env


@lru_cache(maxsize=None)
def tool_versions() -> dict:
    out = {}

    def run(cmd):
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout.strip().splitlines()[0]
        except Exception as e:
            return f"unavailable ({e.__class__.__name__})"

    out["yosys"] = run([env("YOSYS"), "-V"]) if shutil.which(env("YOSYS")) else "not found"
    sta = env("STA")
    out["opensta"] = run([sta, "-version"]) if Path(sta).exists() else "not found"
    orx = env("OPENROAD")
    out["openroad"] = run([orx, "-version"]) if Path(orx).exists() else "not found"
    out["verilator"] = run([env("VERILATOR"), "--version"]) if shutil.which(env("VERILATOR")) else "not found"
    out["iverilog"] = run([env("IVERILOG"), "-V"]) if shutil.which(env("IVERILOG")) else "not found"
    out["python"] = pyplat.python_version()
    pins = ROOT / "configs" / "tools.yaml"
    if pins.exists():
        out["pinned"] = pins.read_text()
    return out


def _sha(p: Path) -> str:
    try:
        return liberty.sha256_file(p)[:16]
    except Exception:
        return "missing"


def collect(design: DesignConfig, platform: Platform, run_dir: Path, stage_dir: Path) -> dict:
    tinfo = {}
    try:
        tinfo = json.loads((stage_dir / "tool_info.json").read_text())
    except Exception:
        pass
    libs = {}
    for c in platform.corners:
        s = platform.liberty_set(c, design.macros.get(platform.name, []))
        libs[c] = {str(p.name): _sha(p) for p in s["stdcell"] + s["io"] + s["macro"]}
    tp = ROOT / "third_party" / "PROVENANCE.json"
    intake = {}
    if tp.exists():
        d = json.loads(tp.read_text())
        intake = {s["vendored"]: s.get("archive_sha256", "")[:16] for s in d.get("sources", [])}
    sdcs = {}
    for f in sorted((run_dir / "sdc").glob("*.sdc")):
        sdcs[f.name] = hashlib.sha256(f.read_bytes()).hexdigest()[:16]
    net = run_dir / "synth" / "netlist.v"
    return {"tool_info": tinfo, "tools": tool_versions(),
            "liberty_sha256_16": libs, "platform_root": platform.root,
            "design_revision": intake, "config_digest": config_digest(design),
            "constraint_revision": sdcs,
            "netlist_sha256_16": _sha(net) if net.exists() else None,
            "host": pyplat.platform()}
