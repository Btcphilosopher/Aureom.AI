"""Minimal Liberty utilities.

Only what TimingFlow needs and can verify: library header facts (name, units,
nominal PVT), cell presence, pin capacitance, and writing a synthesis-only
copy with ``dont_use : true`` on selected cells (Yosys 0.33's dfflibmap/abc
have no ``-dont_use`` option; both honour the Liberty attribute).
"""
from __future__ import annotations

import fnmatch
import gzip
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

_CELL_RE = re.compile(r'^(\s*)cell\s*\(\s*"?([A-Za-z0-9_$.\[\]]+)"?\s*\)\s*\{', re.M)


def _read(path: Path) -> str:
    data = Path(path).read_bytes()
    if data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)
    return data.decode("utf-8", errors="replace")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class LibertyInfo:
    path: str
    name: str
    sha256: str
    time_unit: str | None = None
    cap_unit: str | None = None
    nom_voltage: float | None = None
    nom_temperature: float | None = None
    nom_process: float | None = None
    default_max_transition: float | None = None
    cells: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        d = dict(self.__dict__)
        d["n_cells"] = len(self.cells)
        d.pop("cells")
        return d


def _attr(text: str, name: str) -> str | None:
    m = re.search(rf'^\s*{name}\s*:\s*"?([^";]+)"?\s*;', text, re.M)
    return m.group(1).strip() if m else None


def _float(v: str | None) -> float | None:
    try:
        return float(v) if v is not None else None
    except ValueError:
        return None


def read_info(path: str | Path) -> LibertyInfo:
    text = _read(Path(path))
    m = re.search(r'^\s*library\s*\(\s*"?([A-Za-z0-9_.\-]+)"?\s*\)', text, re.M)
    if not m:
        raise ValueError(f"{path}: no library() header")
    first_cell = _CELL_RE.search(text)
    head = text[: first_cell.start() if first_cell else len(text)]
    cap = re.search(r'capacitive_load_unit\s*\(\s*([0-9.]+)\s*,\s*"?([a-zA-Z]+)"?\s*\)', head)
    return LibertyInfo(
        path=str(path), name=m.group(1), sha256=sha256_file(Path(path)),
        time_unit=_attr(head, "time_unit"),
        cap_unit=f"{cap.group(1)}{cap.group(2)}" if cap else None,
        nom_voltage=_float(_attr(head, "nom_voltage")),
        nom_temperature=_float(_attr(head, "nom_temperature")),
        nom_process=_float(_attr(head, "nom_process")),
        default_max_transition=_float(_attr(head, "default_max_transition")),
        cells=[c.group(2) for c in _CELL_RE.finditer(text)],
    )


def _cell_block(text: str, cell: str) -> str | None:
    """Return the text of ``cell (name) { ... }`` using brace matching."""
    m = re.search(rf'^\s*cell\s*\(\s*"?{re.escape(cell)}"?\s*\)\s*\{{', text, re.M)
    if not m:
        return None
    depth, i = 0, m.end() - 1
    while i < len(text):
        c = text[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return text[m.start(): i + 1]
        i += 1
    return None


def _pin_block(cell_text: str, pin: str) -> str | None:
    m = re.search(rf'(?:^|[\s;{{]){"pin"}\s*\(\s*"?{re.escape(pin)}"?\s*\)\s*\{{', cell_text)
    if not m:
        return None
    depth, i = 0, m.end() - 1
    while i < len(cell_text):
        c = cell_text[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return cell_text[m.start(): i + 1]
        i += 1
    return None


def pin_capacitance(path: str | Path, cell: str, pin: str) -> float | None:
    """Pin capacitance (library cap units) read from the Liberty file."""
    text = _read(Path(path))
    cb = _cell_block(text, cell)
    if cb is None:
        return None
    pb = _pin_block(cb, pin)
    if pb is None:
        return None
    vals = [float(v) for v in re.findall(r'(?:^|[\s;{])(?:rise_|fall_)?capacitance\s*:\s*([0-9.eE+-]+)\s*;', pb)]
    return max(vals) if vals else None


def has_cell(path: str | Path, cell: str) -> bool:
    return _cell_block(_read(Path(path)), cell) is not None


def mark_dont_use(src: str | Path, dst: str | Path, patterns: list[str]) -> list[str]:
    """Write ``dst`` = ``src`` with ``dont_use : true;`` in cells matching patterns.

    Returns the list of cells marked.  Cells that already carry dont_use are
    left as they are.
    """
    text = _read(Path(src))
    marked: list[str] = []
    out: list[str] = []
    pos = 0
    for m in _CELL_RE.finditer(text):
        name = m.group(2)
        if any(fnmatch.fnmatchcase(name, p) for p in patterns):
            out.append(text[pos: m.end()])
            out.append(f"\n{m.group(1)}  dont_use : true ; /* timingflow: platform dont_use */")
            pos = m.end()
            marked.append(name)
    out.append(text[pos:])
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    Path(dst).write_text("".join(out))
    return marked


def cell_classes(path: str | Path) -> dict[str, str]:
    """Classify every cell from its Liberty groups: ff | latch | icg | comb."""
    text = _read(Path(path))
    out: dict[str, str] = {}
    for m in _CELL_RE.finditer(text):
        name = m.group(2)
        block = _cell_block(text, name) or ""
        if "clock_gating_integrated_cell" in block:
            out[name] = "icg"
        elif re.search(r"(?:^|[\s;{])(ff|ff_bank)\s*\(", block):
            out[name] = "ff"
        elif re.search(r"(?:^|[\s;{])(latch|latch_bank)\s*\(", block):
            out[name] = "latch"
        else:
            out[name] = "comb"
    return out


def async_pins(path: str | Path) -> dict[str, set[str]]:
    """Asynchronous set/reset pins per sequential cell, from ff/latch clear/preset."""
    text = _read(Path(path))
    out: dict[str, set[str]] = {}
    for m in _CELL_RE.finditer(text):
        name = m.group(2)
        block = _cell_block(text, name) or ""
        pins: set[str] = set()
        for expr in re.findall(r'(?:^|[\s;{])(?:clear|preset)\s*:\s*"([^"]+)"', block):
            pins |= set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", expr))
        if pins:
            out[name] = pins
    return out
