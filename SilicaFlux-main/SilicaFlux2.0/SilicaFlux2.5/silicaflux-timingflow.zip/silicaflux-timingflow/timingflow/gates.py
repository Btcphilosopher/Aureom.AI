"""Staged timing signoff gates (1-18).

A gate is PASS only on evidence produced by an executed run.  Gates that need a
stage which has not run are NOT RUN, never PASS.  Setup/hold/DRV/corner gates
(13-16) are evaluated only on POST-ROUTE (extracted) results: positive slack at
an earlier stage, or in a single typical corner, is reported but cannot pass a
signoff gate.  OpenSTA/OpenROAD results are not equivalent to a foundry-approved
commercial signoff flow; thresholds below are this project's, not a foundry's.
"""
from __future__ import annotations

import json
from pathlib import Path

from .config import DesignConfig, Platform, load_exceptions
from .parse_reports import read_json

THRESHOLDS = {
    "setup_slack_min_ns": 0.0,
    "hold_slack_min_ns": 0.0,
    "drv_violations_max": 0,
    "pulse_width_violations_max": 0,
    "unconstrained_endpoints_max_unjustified": 0,
    "basis": "project thresholds (no foundry signoff margins / OCV derates available)",
}
STAGES = ["synthesis", "placement", "cts", "global_route", "postroute"]


def g(n: int, title: str, status: str, evidence: str) -> dict:
    return {"gate": n, "title": title, "status": status, "evidence": evidence}


def evaluate(design: DesignConfig, platform: Platform, run_dir: Path) -> dict:
    synth = read_json(run_dir / "synth" / "synth_summary.json")
    audit = read_json(run_dir / "constraint_audit.json")
    sums = {s: read_json(run_dir / f"sta_{s}" / "summary.json") for s in STAGES}
    ac = {c["id"]: c for c in (audit or {}).get("checks", [])}

    def st(cid):
        return ac.get(cid, {}).get("status", "NOT RUN")

    out = []
    if synth is None:
        out.append(g(1, "RTL elaboration successful", "NOT RUN", "no synthesis run"))
        out.append(g(2, "Synthesis successful", "NOT RUN", "no synthesis run"))
    else:
        out.append(g(1, "RTL elaboration successful", "PASS" if synth["status"] == "PASS" else "FAIL",
                     f"yosys hierarchy -check + synth ({synth.get('runtime_s')} s)"))
        lat = synth.get("inferred_latches") or []
        out.append(g(2, "Synthesis successful", "PASS" if synth["status"] == "PASS" and not lat and not synth.get("check_warnings")
                     else "FAIL", f"{synth.get('n_cells')} cells, {len(lat)} latches, check warnings {synth.get('check_warnings')}"))
    if audit is None:
        for n, t in ((3, "All required timing libraries loaded"), (4, "Primary and generated clocks validated"),
                     (5, "All required endpoints constrained"), (6, "Timing exceptions reviewed")):
            out.append(g(n, t, "NOT RUN", "run check-sdc"))
    else:
        s3 = "PASS" if st("C01") == "PASS" and st("C02") in ("PASS", "NOT APPLICABLE") else "FAIL"
        out.append(g(3, "All required timing libraries loaded", s3, f"C01={st('C01')} C02={st('C02')} C03={st('C03')}"))
        ids = ("C04", "C05", "C06", "C07", "C08")
        s4 = "FAIL" if any(st(i) == "FAIL" for i in ids) else "PASS"
        out.append(g(4, "Primary and generated clocks validated", s4, " ".join(f"{i}={st(i)}" for i in ids)))
        ids = ("C09", "C10", "C11", "C12")
        s5 = "FAIL" if any(st(i) == "FAIL" for i in ids) else "PASS"
        out.append(g(5, "All required endpoints constrained", s5,
                     " ".join(f"{i}={st(i)}" for i in ids) + " (WARNING = justified by documented IO kind)"))
        exc = load_exceptions(design)
        pend = [e.id for e in exc.exceptions if e.approval != "APPROVED"] if exc else []
        s6 = "FAIL" if st("X01") == "FAIL" or st("C21") == "FAIL" else ("FAIL" if pend else "PASS")
        out.append(g(6, "Timing exceptions reviewed", s6,
                     f"X01={st('X01')} C21={st('C21')}; not approved: {', '.join(pend) if pend else 'none'}"))
    labels = {"synthesis": (7, "Pre-placement (post-synthesis) analysis completed"),
              "placement": (8, "Post-placement analysis completed"),
              "cts": (10, "Post-CTS timing analysed"),
              "global_route": (11, "Global-route timing analysed"),
              "postroute": (12, "Detailed routing and extraction completed")}
    for s, (n, t) in labels.items():
        sm = sums[s]
        out.append(g(n, t, "PASS" if sm and sm.get("status") == "PASS" else ("FAIL" if sm else "NOT RUN"),
                     sm.get("label", "") if sm else "stage not run"))
    cts = read_json(run_dir / "sta_cts" / "run_result.json")
    out.append(g(9, "Clock-tree synthesis completed", "PASS" if cts and cts.get("status") == "PASS" else ("FAIL" if cts else "NOT RUN"),
                 "OpenROAD clock_tree_synthesis" if cts else "stage not run"))
    pr = sums["postroute"]
    latest = next((s for s in reversed(STAGES) if sums[s] and sums[s].get("status") == "PASS"), None)
    info = ""
    if latest:
        sm = sums[latest]
        ws = min((v["setup_all"]["wns_ns"] for v in sm["scenes"].values() if v["setup_all"]["wns_ns"] is not None), default=None)
        wh = min((v["hold_all"]["wns_ns"] for v in sm["scenes"].values() if v["hold_all"]["wns_ns"] is not None), default=None)
        info = f"latest completed stage {sm['label']}: worst setup {ws} ns, worst hold {wh} ns (informative only)"
    if not pr or pr.get("status") != "PASS":
        for n, t in ((13, "Required setup checks pass"), (14, "Required hold checks pass"),
                     (15, "Max-transition/capacitance/pulse-width and library checks pass"),
                     (16, "Required process corners and operating modes pass")):
            out.append(g(n, t, "NOT RUN", "requires POST-ROUTE extracted timing; " + info))
    else:
        sc = pr["scenes"]
        ws = min(v["setup_all"]["wns_ns"] for v in sc.values())
        wh = min(v["hold_all"]["wns_ns"] for v in sc.values())
        out.append(g(13, "Required setup checks pass", "PASS" if ws >= THRESHOLDS["setup_slack_min_ns"] else "FAIL", f"worst setup {ws} ns"))
        out.append(g(14, "Required hold checks pass", "PASS" if wh >= THRESHOLDS["hold_slack_min_ns"] else "FAIL", f"worst hold {wh} ns"))
        drv = sum(d.get("violators", 0) for v in sc.values() for d in v["drv"].values())
        pw = sum((v["min_pulse_width"]["violators"] or 0) for v in sc.values())
        kinds = sorted({f"{k}" for v in sc.values() for k, d in v["drv"].items() if d.get("violators")})
        worst = {k: min((v["drv"][k].get("worst_slack") for v in sc.values()
                         if k in v["drv"] and v["drv"][k].get("worst_slack") is not None), default=None) for k in kinds}
        out.append(g(15, "Max-transition/capacitance/pulse-width and library checks pass",
                     "PASS" if drv <= THRESHOLDS["drv_violations_max"] and pw <= THRESHOLDS["pulse_width_violations_max"] else "FAIL",
                     f"DRV violators {drv} (summed over {len(sc)} scenes; kinds {kinds or 'none'}; worst {worst or '-'}), "
                     f"pulse-width violators {pw}"))
        missing = [u.name for u in platform.unavailable_corners]
        ok = all(v["setup_all"]["violators"] == 0 and v["hold_all"]["violators"] == 0 for v in sc.values())
        out.append(g(16, "Required process corners and operating modes pass",
                     "FAIL" if missing or not ok else "PASS",
                     f"scenes {list(sc)} {'all pass setup+hold' if ok else 'have violations'}; unavailable PDK corners: {missing}; "
                     "no foundry signoff corner list is available to define the required set (docs/UNRESOLVED.md #10-11)"))
    s17 = "NOT RUN"
    if audit:
        c22, c23 = st("C22"), st("C23")
        s17 = "FAIL" if "FAIL" in (c22, c23) else ("FAIL" if "WARNING" in (c22, c23) else ("PASS" if c22 == c23 == "PASS" else "NOT RUN"))
        ev = f"C22={c22} C23={c23} (structural only; protocol/formal CDC evidence must be linked in the registry)"
    else:
        ev = "run check-sdc"
    out.append(g(17, "Required CDC/RDC evidence linked", s17, ev))
    prov_ok = bool(sums["synthesis"] and sums["synthesis"].get("provenance", {}).get("tools"))
    rep = read_json(run_dir / "repro_check.json")
    s18 = "PASS" if prov_ok and rep and rep.get("identical") else ("FAIL" if rep and not rep.get("identical") else "NOT RUN")
    out.append(g(18, "Timing report package reproducible", s18,
                 f"provenance {'complete' if prov_ok else 'missing'}; repro check {'identical' if rep and rep.get('identical') else 'not run' if not rep else 'differs'}"))
    out = sorted(out, key=lambda x: x["gate"])
    res = {"design": design.name, "platform": platform.name, "run_dir": str(run_dir), "thresholds": THRESHOLDS,
           "gates": out, "signoff": "NOT ACHIEVED" if any(x["status"] != "PASS" for x in out) else "PROJECT GATES PASSED",
           "note": "OpenSTA/OpenROAD results are not a foundry-approved signoff; see docs/SIGNOFF_GATES.md"}
    (run_dir / "gates.json").write_text(json.dumps(res, indent=1))
    return res
