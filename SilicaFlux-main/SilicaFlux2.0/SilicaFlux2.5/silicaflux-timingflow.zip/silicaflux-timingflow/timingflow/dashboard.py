"""TimingFlow dashboard: a single self-contained HTML file built from the real
run summaries under runs/ (and experiment results under reports/experiments).

No synthetic data is embedded.  Any stage, corner or check without executed
evidence is rendered NOT RUN.  Plotly.js is inlined so the file works offline.
"""
from __future__ import annotations

import json
from pathlib import Path

from .config import list_designs, list_platforms, load_design, load_exceptions, load_platform
from .parse_reports import read_json
from .physical import parse_repair_result
from .paths import REPORTS_DIR, RUNS_DIR

STAGES = ["synthesis", "placement", "cts", "global_route", "postroute"]


def _slim_scene(v: dict) -> dict:
    keep = ("mode", "corner", "wns_ns", "tns_ns", "whs_ns", "ths_ns", "setup_all", "hold_all", "setup_clock_groups",
            "hold_clock_groups", "reg2reg", "recovery_removal", "clock_gating", "min_pulse_width")
    d = {k: v.get(k) for k in keep}
    d["groups"] = v.get("groups", {})
    d["drv"] = {k: {"violators": x["violators"], "worst_slack": x["worst_slack"]} for k, x in v.get("drv", {}).items()}
    d["sram"] = {k: v["sram"].get(k) for k in ("read_setup_wns_ns", "write_setup_wns_ns", "write_hold_wns_ns")}
    d["top_setup"] = v.get("top_setup_paths", [])[:25]
    d["top_hold"] = v.get("top_hold_paths", [])[:15]
    d["top_r2r"] = v.get("top_reg2reg_paths", [])[:25]
    d["bottlenecks_setup"] = v.get("bottlenecks_setup", [])
    d["bottlenecks_hold"] = v.get("bottlenecks_hold", [])
    d["bottlenecks_setup_clocked"] = v.get("bottlenecks_setup_clocked", [])
    d["through"] = {k: x["clocked"] for k, x in (v.get("worst_through_block") or {}).items() if x.get("clocked")}
    d["skew"] = v.get("clock_skew", {})
    d["latency"] = v.get("clock_latency", {})
    return d


def collect() -> dict:
    data = {"runs": [], "designs": [], "platforms": [], "experiments": []}
    for dn in list_designs():
        d = load_design(dn)
        exc = load_exceptions(d) if d.status != "NOT_FOUND" else None
        data["designs"].append({"name": dn, "title": d.title, "status": d.status, "family": d.family,
                                "evidence": d.status_evidence, "kind": d.kind, "top": d.top,
                                "clocks": [c.model_dump() for c in d.clocks],
                                "generated_clocks": [g.model_dump() for g in d.generated_clocks],
                                "modes": [m.model_dump() for m in d.modes],
                                "exceptions": [e.model_dump(by_alias=True) for e in exc.exceptions] if exc else []})
    for pn in list_platforms():
        p = load_platform(pn)
        data["platforms"].append({"name": pn, "node": p.node, "status": p.status,
                                  "corners": {k: c.model_dump() for k, c in p.corners.items()},
                                  "unavailable": [u.model_dump() for u in p.unavailable_corners]})
    commercial = read_json(Path(__file__).resolve().parents[1] / "configs" / "platforms" / "commercial.yaml")
    for rd in sorted(RUNS_DIR.glob("*/*/*")):
        if not rd.is_dir() or rd.name.endswith("__repro"):
            continue
        run = {"design": rd.parts[-3], "platform": rd.parts[-2], "run": rd.name, "stages": {}}
        for s in STAGES:
            sm = read_json(rd / f"sta_{s}" / "summary.json")
            if not sm:
                run["stages"][s] = {"status": "NOT RUN"}
                continue
            if sm.get("status") != "PASS":
                run["stages"][s] = {"status": sm.get("status"), "label": sm.get("label"), "reason": sm.get("reason", "")[:400]}
                continue
            prov = sm.get("provenance", {})
            run["stages"][s] = {"status": "PASS", "label": sm["label"], "parasitics": sm["parasitics"],
                                "clocks_mode": sm["clocks_mode"], "corners": sm["corners"], "modes": sm["modes"],
                                "scenes": {k: _slim_scene(v) for k, v in sm["scenes"].items()},
                                "clocks": sm.get("clocks", {}), "power": sm.get("power"),
                                "synthesis": sm.get("synthesis"),
                                "provenance": {k: prov.get(k) for k in ("design_revision", "config_digest", "constraint_revision",
                                                                        "netlist_sha256_16", "liberty_sha256_16", "platform_root")}
                                | {"tools": {k: v for k, v in (prov.get("tools") or {}).items() if k != "pinned"},
                                   "tool_info": prov.get("tool_info")}}
        run["repairs"] = [r for r in (parse_repair_result(d) for d in sorted(rd.glob("repair_*"))) if r]
        run["synth"] = read_json(rd / "synth" / "synth_summary.json")
        if run["synth"]:
            run["synth"] = {k: run["synth"].get(k) for k in ("status", "total_area_um2", "n_cells", "cell_classes", "runtime_s",
                                                             "parameters", "period_target_ns", "errors")}
        au = read_json(rd / "constraint_audit.json")
        run["audit"] = {"overall": au["overall"], "counts": au["counts"],
                        "checks": [dict(c, details=c["details"][:12]) for c in au["checks"]]} if au else None
        run["gates"] = read_json(rd / "gates.json")
        cdc = read_json(rd / "constraint_analysis" / "cdc.json")
        if cdc:
            run["cdc"] = {"status": cdc["status"], "disclaimer": cdc["disclaimer"],
                          "pairs": [{k: p[k] for k in ("from", "to", "relationship", "crossings", "by_class", "status")}
                                    | {"multibit_groups": p["multibit_groups"][:8],
                                       "examples": [e for e in p["examples"] if e["class"] != "QUASI_STATIC_DATA"][:6]}
                                    for p in cdc["clock_pairs"]],
                          "async_inputs": [{k: a[k] for k in ("port_report", "by_class", "status")} for a in cdc["async_inputs"]],
                          "rdc": cdc["rdc"][:12]}
        run["impact"] = read_json(rd / "constraint_analysis" / "exception_impact.json", [])
        phys = {}
        for s in ("placement", "cts", "global_route", "postroute"):
            rr = read_json(rd / f"sta_{s}" / "run_result.json")
            if rr:
                phys[s] = {k: rr.get(k) for k in ("status", "runtime_s", "phys_metrics", "reason", "warnings")}
        run["physical"] = phys
        data["runs"].append(run)
    for f in sorted((REPORTS_DIR / "experiments").glob("*/result.json")):
        data["experiments"].append(read_json(f))
    return data


CSS = """
:root{--navy:#0b1430;--panel:#111d42;--panel2:#16234f;--ink:#e8ecf6;--ink2:#a9b3cf;--muted:#7a839c;--grid:#24315c;
--gold:#d4b25a;--gold2:#b8891a;--cyan:#0aa2c0;--violet:#8466ee;--magenta:#d6528f;
--pass:#2fa36b;--warn:#c98a00;--fail:#d9534f;--notrun:#7a839c}
*{box-sizing:border-box}body{margin:0;background:var(--navy);color:var(--ink);font:14px/1.45 "IBM Plex Sans",system-ui,-apple-system,"Segoe UI",sans-serif}
header{padding:18px 24px 10px;border-bottom:1px solid var(--grid);background:linear-gradient(180deg,#0e1a3d,#0b1430)}
h1{margin:0;font-size:20px;letter-spacing:.04em;color:var(--gold)}h1 small{color:var(--ink2);font-weight:400;font-size:13px;margin-left:8px}
.sub{color:var(--ink2);font-size:12px;margin-top:4px}
.controls{display:flex;flex-wrap:wrap;gap:10px;padding:10px 24px;border-bottom:1px solid var(--grid);position:sticky;top:0;background:var(--navy);z-index:5}
.controls label{font-size:11px;color:var(--ink2);display:flex;flex-direction:column;gap:2px}
select{background:var(--panel);color:var(--ink);border:1px solid var(--grid);border-radius:6px;padding:4px 8px;font:inherit;min-width:150px}
nav{display:flex;flex-wrap:wrap;gap:4px;padding:8px 24px;border-bottom:1px solid var(--grid)}
nav a{color:var(--ink2);text-decoration:none;font-size:12px;padding:3px 8px;border-radius:5px;border:1px solid transparent}
nav a:hover{border-color:var(--grid);color:var(--ink)}
main{padding:12px 24px 40px;max-width:1500px}
section{scroll-margin-top:72px;background:var(--panel);border:1px solid var(--grid);border-radius:10px;padding:14px 16px;margin:14px 0}
h2{margin:0 0 8px;font-size:15px;color:var(--cyan);letter-spacing:.03em}h3{font-size:13px;color:var(--gold);margin:12px 0 6px}
table{border-collapse:collapse;width:100%;font:12px "IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace}
th,td{border-bottom:1px solid var(--grid);padding:4px 6px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{color:var(--ink2);font-weight:500;background:var(--panel2);position:sticky;top:0}
td.num{text-align:right}.wrap{overflow:auto;max-height:420px}
.st{font-weight:600;white-space:nowrap}.PASS{color:var(--pass)}.WARNING,.REVIEW{color:var(--warn)}.FAIL{color:var(--fail)}.NOTRUN,.NA{color:var(--notrun)}
.neg{color:var(--fail)}.pos{color:var(--pass)}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
.tile{background:var(--panel2);border:1px solid var(--grid);border-radius:8px;padding:10px}
.tile .k{font-size:11px;color:var(--ink2)}.tile .v{font:600 20px "IBM Plex Mono",monospace;margin-top:2px}.tile .n{font-size:11px;color:var(--muted)}
.note{color:var(--ink2);font-size:12px}.badge{display:inline-block;padding:1px 6px;border-radius:4px;border:1px solid var(--grid);font-size:11px;color:var(--ink2)}
.plot{width:100%;min-height:300px}code{color:var(--gold)}
@media(max-width:700px){header,main,.controls,nav{padding-left:16px;padding-right:16px}}
"""

JS = r"""
const D = JSON.parse(document.getElementById('tf-data').textContent);
const STAGES=['synthesis','placement','cts','global_route','postroute'];
const ICON={PASS:'✔',WARNING:'▲',FAIL:'✖','NOT RUN':'○','NOT APPLICABLE':'–'};
const SER=['#0aa2c0','#b8891a','#8466ee','#d6528f'];
const $=s=>document.querySelector(s);
function stc(s){const k=(s||'NOT RUN').startsWith('REVIEW')?'REVIEW':(s||'').replace(/ .*/,'').replace('NOT','NOTRUN');return `<span class="st ${k}">${ICON[s]||(s&&s.startsWith('REVIEW')?'▲':s&&s.startsWith('FAIL')?'✖':s&&s.startsWith('PASS')?'✔':'')} ${s||'NOT RUN'}</span>`}
function f(v,d=3){if(v===null||v===undefined)return '—';if(typeof v==='number'){if(!isFinite(v))return v>0?'INF':'-INF';return v.toFixed(d)}return String(v)}
function dst(s){const k={IMPLEMENTED:'PASS',PARTIAL:'WARNING',NOT_FOUND:'NOTRUN'}[s]||'NOTRUN';const i={IMPLEMENTED:'✔',PARTIAL:'▲',NOT_FOUND:'○'}[s]||'';return `<span class="st ${k}">${i} ${s}</span>`}
function sl(v){if(v===null||v===undefined)return '—';return `<span class="${v<0?'neg':'pos'}">${f(v)}</span>`}
function tbl(rows,cols,hdr){return `<div class="wrap"><table><thead><tr>${(hdr||cols).map(c=>`<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${cols.map(c=>`<td>${typeof c==='function'?c(r):(r[c]??'—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`}
const layout=(t)=>({title:{text:t,font:{color:'#e8ecf6',size:13},x:0},paper_bgcolor:'#111d42',plot_bgcolor:'#111d42',font:{color:'#a9b3cf',family:'IBM Plex Sans, system-ui'},margin:{l:60,r:20,t:40,b:50},xaxis:{gridcolor:'#24315c',zerolinecolor:'#a9b3cf'},yaxis:{gridcolor:'#24315c',zerolinecolor:'#a9b3cf'},legend:{orientation:'h',y:-0.2},hoverlabel:{bgcolor:'#16234f',font:{color:'#e8ecf6'}}});
const cfg={displaylogo:false,responsive:true};
function runs(){return D.runs}
function sel(){const r=runs()[+$('#run').value];return r}
function populate(){
  $('#run').innerHTML=runs().map((r,i)=>`<option value="${i}">${r.design} · ${r.platform} · ${r.run}</option>`).join('');
  $('#run').onchange=()=>{fillStage();render()};fillStage();
}
function fillStage(){const r=sel();if(!r)return;$('#stage').innerHTML=STAGES.map(s=>`<option ${r.stages[s].status==='PASS'?'':'disabled'} value="${s}">${s} — ${r.stages[s].status}</option>`).join('');
  const last=STAGES.filter(s=>r.stages[s].status==='PASS').pop();if(last)$('#stage').value=last;$('#stage').onchange=()=>{fillScene();render()};fillScene()}
function fillScene(){const r=sel();const st=r&&r.stages[$('#stage').value];if(!st||!st.scenes){$('#scene').innerHTML='<option>—</option>';return}
  const ks=Object.keys(st.scenes);$('#scene').innerHTML=ks.map(k=>`<option>${k}</option>`).join('');const w=ks.reduce((a,k)=>st.scenes[k].wns_ns<st.scenes[a].wns_ns?k:a,ks[0]);$('#scene').value=w;$('#scene').onchange=render}
function render(){const r=sel();if(!r){$('#main').innerHTML='<section><h2>No runs</h2><p>No executed runs found under runs/. Nothing is shown rather than placeholder numbers.</p></section>';return}
 const st=r.stages[$('#stage').value]||{status:'NOT RUN'};const sc=st.scenes?st.scenes[$('#scene').value]:null;
 const dz=D.designs.find(d=>d.name===r.design)||{};const pf=D.platforms.find(p=>p.name===r.platform)||{};
 let h='';
 // 1 overview
 h+=`<section id="s1"><h2>1 · Design overview</h2><div class="tiles">
 <div class="tile"><div class="k">design</div><div class="v" style="font-size:15px">${dz.title||r.design}</div><div class="n">${dz.status} · top <code>${dz.top}</code></div></div>
 <div class="tile"><div class="k">platform</div><div class="v" style="font-size:15px">${pf.node||r.platform}</div><div class="n">${Object.keys(pf.corners||{}).length} corners available</div></div>
 <div class="tile"><div class="k">synthesized cells</div><div class="v">${r.synth?r.synth.n_cells:'—'}</div><div class="n">flops ${r.synth&&r.synth.cell_classes?r.synth.cell_classes.flops:'—'} · macros ${r.synth&&r.synth.cell_classes?r.synth.cell_classes.macros:'—'}</div></div>
 <div class="tile"><div class="k">cell area (synthesis, µm²)</div><div class="v">${r.synth?f(r.synth.total_area_um2,0):'—'}</div><div class="n">Yosys stat -liberty (incl. macros)</div></div>
 <div class="tile"><div class="k">clock target</div><div class="v">${dz.clocks&&dz.clocks[0]?f(dz.clocks[0].period_ns,2)+' ns':'—'}</div><div class="n">requirement, not a result</div></div></div>
 <h3>All SilicaFlux targets</h3>${tbl(D.designs,['name','family',d=>dst(d.status),'kind','evidence'],['design','family','repository status','kind','evidence'])}</section>`;
 // 2 status
 h+=`<section id="s2"><h2>2 · Timing status by stage</h2>${tbl(STAGES.map(s=>({s,...r.stages[s]})),[x=>x.label||x.s.toUpperCase(),x=>stc(x.status),x=>x.parasitics||'—',x=>x.clocks_mode||'—',
 x=>x.scenes?sl(Math.min(...Object.values(x.scenes).map(v=>v.wns_ns))):'—',x=>x.scenes?sl(Math.min(...Object.values(x.scenes).map(v=>v.reg2reg.setup_wns_ns??Infinity))):'—',
 x=>x.scenes?sl(Math.min(...Object.values(x.scenes).map(v=>v.whs_ns))):'—',x=>x.reason?`<span class="note">${x.reason.slice(0,160)}</span>`:''],
 ['stage','status','parasitics','clocks','worst WNS (ns)','worst reg2reg (ns)','worst WHS (ns)','note'])}
 <p class="note">WNS includes every path group (recovery/removal, IO, max-delay). reg2reg is measured by an explicit register-clock-pin → register-data-pin query.</p></section>`;
 // 3 clocks
 const clk=st.clocks?Object.entries(st.clocks).flatMap(([m,cs])=>cs.map(c=>({m,...c}))):[];
 h+=`<section id="s3"><h2>3 · Clock definitions</h2>${clk.length?tbl(clk,['m','name',c=>f(c.period_ns,3),c=>c.sources.join(' '),c=>c.is_generated?'generated':'primary',c=>c.is_propagated?'propagated':'ideal'],['mode','clock','period (ns)','source','kind','network']):'<p>'+stc('NOT RUN')+'</p>'}
 <h3>Configured</h3>${tbl((dz.clocks||[]).map(c=>({...c,u:`${c.uncertainty.pre_cts_setup}/${c.uncertainty.pre_cts_hold} pre-CTS · ${c.uncertainty.post_cts_setup}/${c.uncertainty.post_cts_hold} post-CTS`})),['name','port',c=>f(c.period_ns,2),'u','period_source'],['clock','port','period (ns)','uncertainty setup/hold (ns)','source of target'])}
 ${(dz.generated_clocks||[]).length?'<h3>Generated clocks (RTL evidence)</h3>'+tbl(dz.generated_clocks,['name','master','divide_by','target','rtl_evidence']):''}</section>`;
 // 4 corners
 h+=`<section id="s4"><h2>4 · Process corners</h2>${tbl(Object.entries(pf.corners||{}).map(([k,c])=>({k,...c})),['k','process',c=>f(c.voltage_v,2),c=>f(c.temperature_c,0),c=>c.macro_temperature_c===null?'—':f(c.macro_temperature_c,0),c=>c.stdcell_liberty.join(', ')],['corner','process','V','T stdcell (°C)','T SRAM (°C)','stdcell Liberty'])}
 ${(pf.unavailable||[]).length?'<h3>Not available</h3>'+tbl(pf.unavailable,['name','reason']):''}
 ${st.scenes?'<h3>Per-scene results ('+st.label+')</h3>'+tbl(Object.entries(st.scenes).map(([k,v])=>({k,...v})),['k','mode','corner',v=>sl(v.wns_ns),v=>f(v.tns_ns,2),v=>sl(v.whs_ns),v=>f(v.ths_ns,2),v=>sl(v.reg2reg.setup_wns_ns),v=>v.reg2reg.fmax_derived_mhz?f(v.reg2reg.fmax_derived_mhz,1):'—',v=>sl(v.sram.read_setup_wns_ns),v=>v.setup_all.violators,v=>v.hold_all.violators],['scene','mode','corner','WNS','TNS','WHS','THS','reg2reg WNS','Fmax* (MHz)','SRAM read WNS','setup viol.','hold viol.'])+'<p class="note">Fmax* = DERIVED 1/(T − worst reg2reg slack) at this stage/corner; not a measured frequency.</p><div id="pc" class="plot"></div>':''}</section>`;
 // 5 explorer
 h+=`<section id="s5"><h2>5 · Critical path explorer ${sc?'<span class="badge">'+$('#scene').value+'</span>':''}</h2>${sc?tbl(sc.top_r2r.concat(sc.top_setup).filter((p,i,a)=>a.findIndex(q=>q.endpoint===p.endpoint&&q.startpoint===p.startpoint)===i).slice(0,40),[p=>p.rank,p=>sl(p.slack_ns),'group','startpoint','endpoint',p=>p.owner_block+(p.start_block!==p.end_block?` (${p.start_block}→${p.end_block})`:''),p=>p.logic_depth,p=>f(p.cell_delay_ns,2)+' / '+f(p.net_delay_ns,2),p=>p.max_fanout??'—',p=>f(p.max_slew_ns,2),'dominance'],['#','slack (ns)','group','startpoint','endpoint','block (by hierarchy)','depth','cell/net (ns)','max fo','max slew (ns)','dominance']):stc('NOT RUN')}
 <p class="note">Block attribution = netlist instance hierarchy mapped through the design's block_map; unmatched pins are UNKNOWN, never guessed.</p></section>`;
 // 6/7 setup & hold
 h+=`<section id="s6"><h2>6 · Setup violations</h2>${sc?tbl(Object.values(sc.groups).filter(g=>g.check==='setup'),['group',g=>g.endpoints,g=>g.violators,g=>sl(g.wns_ns),g=>f(g.tns_ns,2),'worst_endpoint'],['path group','endpoints','violators','WNS','TNS','worst endpoint'])+'<h3>By block (all groups)</h3>'+tbl(sc.bottlenecks_setup,['block','endpoints','violators',b=>sl(b.wns_ns),b=>f(b.tns_ns,2),'worst_endpoint'],['block','endpoints','violators','WNS (ns)','TNS (ns)','worst endpoint'])+((sc.bottlenecks_setup_clocked||[]).length?'<h3>By block — clocked data endpoints only (recovery/removal, path-delay, unconstrained excluded)</h3>'+tbl(sc.bottlenecks_setup_clocked,['block','endpoints','violators',b=>sl(b.wns_ns),b=>f(b.tns_ns,2),'worst_endpoint'],['block','endpoints','violators','WNS (ns)','TNS (ns)','worst endpoint']):'')+(Object.keys(sc.through||{}).length?'<h3>Worst clocked path crossing each block boundary</h3>'+tbl(Object.entries(sc.through).map(([k,x])=>({k,...x})).sort((a,b)=>a.slack_ns-b.slack_ns),['k',x=>sl(x.slack_ns),x=>f(x.delay_inside_block_ns,2),x=>f(x.arrival_ns,2),'startpoint','endpoint','logic_depth'],['instance','slack (ns)','delay inside (ns)','arrival (ns)','startpoint','endpoint','depth']):''):stc('NOT RUN')}<div id="pb" class="plot"></div></section>`;
 h+=`<section id="s7"><h2>7 · Hold violations</h2>${sc?tbl(Object.values(sc.groups).filter(g=>g.check==='hold'),['group',g=>g.endpoints,g=>g.violators,g=>sl(g.wns_ns),g=>f(g.tns_ns,2),'worst_endpoint'],['path group','endpoints','violators','WHS','THS','worst endpoint'])+tbl(sc.top_hold.slice(0,12),[p=>sl(p.slack_ns),'startpoint','endpoint','owner_block'],['slack (ns)','startpoint','endpoint','block']):stc('NOT RUN')}
 <p class="note">${st.clocks_mode==='ideal'?'Clocks are ideal at this stage: hold results are indicative; hold signoff requires propagated clocks (post-CTS) and extracted parasitics.':''}</p></section>`;
 // 8 clock tree
 const ph=r.physical&&r.physical.cts;
 h+=`<section id="s8"><h2>8 · Clock-tree explorer</h2>${st.clocks_mode==='propagated'&&sc?tbl(Object.entries(sc.skew.setup||{}).map(([k,v])=>({k,...v})),['k',v=>f(v.source_latency,3),v=>f(v.target_latency,3),v=>f(v.setup_skew,3),'source_latency_pin','target_latency_pin'],['clock','source latency (ns)','target latency (ns)','setup skew (ns)','source pin','target pin'])+'<h3>Insertion delay (propagated)</h3>'+tbl(Object.entries((sc.latency||{}).clocks||{}).map(([k,v])=>({k,...v})),['k',v=>f(v.min_ns,3),v=>f(v.max_ns,3),v=>f(v.skew_ns,3)],['clock','min (ns)','max (ns)','spread (ns)']):'<p>'+stc('NOT RUN')+' — no clock tree exists at this stage (ideal clocks). Pre-CTS latency/skew printed by OpenSTA include the unbuffered ICG delay and are not used by ideal-clock checks.</p>'}
 ${ph?'<h3>CTS run</h3>'+tbl(Object.entries(ph.phys_metrics||{}).map(([k,v])=>({k,v})),['k','v'],['metric','value']):''}</section>`;
 // 9 breakdown
 h+=`<section id="s9"><h2>9 · Path delay breakdown</h2>${sc&&sc.top_r2r.length?'<div id="pd" class="plot"></div>':stc('NOT RUN')}</section>`;
 // 10/11 optimisation + compare
 const ex=D.experiments.filter(e=>e&&e.design_family&&true);
 h+=`<section id="s10"><h2>10 · Timing optimisation</h2>${D.experiments.length?D.experiments.map(e=>`<h3>${e.name} <span class="badge">${e.status}</span></h3><p class="note">${e.description||''}</p>${tbl(e.candidates||[],[c=>c.label,c=>stc(c.status),c=>sl(c.reg2reg_setup_wns_ns),c=>f(c.tns_ns,2),c=>f(c.area_um2,0),c=>c.flops??'—',c=>c.latency_cycles??'—',c=>e.sensitivity?'n/a':(c.pareto?'★':''),c=>c.reject_reason||''],['candidate','status','reg2reg WNS (ns)','TNS (ns)','area (µm²)','flops','latency (cycles)','Pareto','reject reason'])}<div id="po_${e.name}" class="plot"></div>`).join(''):stc('NOT RUN')}</section>`;
 h+=`<section id="s11"><h2>11 · Before / after comparison</h2>${(r.repairs||[]).map(x=>`<h3>Repair ${x.name} <span class="st ${x.accepted?'PASS':'WARNING'}">${x.accepted?'✔ ACCEPTED':'▲ ROLLED BACK'}</span></h3>${tbl(Object.keys(x.before.scenes).map(k=>({k,b:x.before.scenes[k],a:(x.after.scenes[k]||[])})),['k',y=>sl(y.b[0])+' → '+sl(y.a[0]),y=>f(y.b[1],3)+' → '+f(y.a[1],3),y=>sl(y.b[2])+' → '+sl(y.a[2])],['scene','setup WNS before → after (ns)','setup TNS (ns)','hold WNS before → after (ns)'])}<p class="note">cells ${x.before.cells} → ${x.after.cells}; area ${f(x.before.area,0)} → ${f(x.after.area,0)} µm²; placement legal: ${x.legal?'yes':'NO'}</p>`).join('')}${D.experiments.filter(e=>e.comparison).length?D.experiments.filter(e=>e.comparison).map(e=>`<h3>${e.name}: ${e.comparison.status}</h3>${e.comparison.reasons&&e.comparison.reasons.length?'<p class="note">'+e.comparison.reasons.join('; ')+'</p>':''}${tbl(e.comparison.scenes||[],['scene',s=>sl(s.reg2reg_setup_wns_ns_base),s=>sl(s.reg2reg_setup_wns_ns_cand),s=>f(s.reg2reg_setup_wns_ns_delta),s=>sl(s.wns_ns_base),s=>sl(s.wns_ns_cand)],['scene','reg2reg base','reg2reg cand','Δ (ns)','WNS base','WNS cand'])}`).join(''):stc('NOT RUN')}</section>`;
 // 12 exceptions
 h+=`<section id="s12"><h2>12 · Timing exception registry</h2>${tbl(dz.exceptions||[],['id','type',e=>e.modes.join(','),e=>`<span class="st ${e.approval==='APPROVED'?'PASS':'WARNING'}">${e.approval==='APPROVED'?'✔':'▲'} ${e.approval}</span>`,'owner','reason',e=>e.rtl_evidence.join('<br>')],['id','type','modes','approval','owner','reason','RTL evidence'])}
 ${r.impact&&r.impact.length?'<h3>Impact (what each exception hides)</h3>'+tbl(r.impact,['id',i=>stc(i.verdict),'endpoints_covered',i=>JSON.stringify(i.endpoint_kinds||{}),i=>i.notes.join('; ')],['id','verdict','endpoints','endpoint pin kinds','notes']):''}
 ${r.cdc?'<h3>Clock-domain crossings — '+stc(r.cdc.status)+'</h3><p class="note">'+r.cdc.disclaimer+'</p>'+tbl(r.cdc.pairs.filter(p=>p.crossings),['from','to','relationship','crossings',p=>JSON.stringify(p.by_class),p=>stc(p.status)])+tbl(r.cdc.async_inputs,['port_report',a=>JSON.stringify(a.by_class),a=>stc(a.status)],['async input','classes','status'])+'<h3>Reset domains</h3>'+tbl(r.cdc.rdc,['reset_source','launch_clock',x=>x.capture_clocks.join(','),'endpoints','release']):''}</section>`;
 // 13 provenance
 h+=`<section id="s13"><h2>13 · Analysis provenance</h2>${st.provenance?'<pre style="white-space:pre-wrap;font:11px IBM Plex Mono,monospace;color:#a9b3cf">'+JSON.stringify(st.provenance,null,1)+'</pre>':stc('NOT RUN')}</section>`;
 // 14 readiness
 h+=`<section id="s14"><h2>14 · Readiness checklist (signoff gates)</h2>${r.gates?'<p><b>'+r.gates.signoff+'</b> — '+r.gates.note+'</p>'+tbl(r.gates.gates,[g=>'G'+g.gate,g=>stc(g.status),'title','evidence'],['gate','status','criterion','evidence']):stc('NOT RUN')}
 ${r.audit?'<h3>Constraint audit — '+stc(r.audit.overall)+'</h3>'+tbl(r.audit.checks,['id',c=>stc(c.status),'title','evidence',c=>c.details.slice(0,4).join('<br>')]):''}</section>`;
 $('#main').innerHTML=h;
 // plots
 if(st.scenes){const ks=Object.keys(st.scenes);const corners=[...new Set(ks.map(k=>st.scenes[k].corner))];
  Plotly.newPlot('pc',[{type:'bar',name:'reg2reg setup WNS',x:ks,y:ks.map(k=>st.scenes[k].reg2reg.setup_wns_ns),marker:{color:SER[0]},hovertemplate:'%{x}<br>reg2reg WNS %{y:.3f} ns<extra></extra>'},
   {type:'bar',name:'all-groups WNS',x:ks,y:ks.map(k=>st.scenes[k].wns_ns),marker:{color:SER[1]},hovertemplate:'%{x}<br>WNS %{y:.3f} ns<extra></extra>'},
   {type:'bar',name:'WHS',x:ks,y:ks.map(k=>st.scenes[k].whs_ns),marker:{color:SER[2]},hovertemplate:'%{x}<br>WHS %{y:.3f} ns<extra></extra>'}],
   {...layout('Worst slack per scene (ns)'),barmode:'group',bargap:0.25},cfg)}
 if(sc){const b=((sc.bottlenecks_setup_clocked||[]).length?sc.bottlenecks_setup_clocked:sc.bottlenecks_setup).filter(x=>x.block!=='IO');Plotly.newPlot('pb',[{type:'bar',orientation:'h',y:b.map(x=>x.block),x:b.map(x=>x.wns_ns),marker:{color:SER[2]},hovertemplate:'%{y}<br>WNS %{x:.3f} ns<extra></extra>'}],{...layout('Worst setup slack by block (ns, clocked data endpoints; recovery/removal excluded)'),height:300,margin:{l:110,r:20,t:40,b:50}},cfg)}
 if(sc&&sc.top_r2r.length){const p=sc.top_r2r.slice(0,15).reverse();const lab=p.map(x=>`#${x.rank} ${x.owner_block} …${x.endpoint.slice(-30)}`);
  Plotly.newPlot('pd',[{type:'bar',orientation:'h',name:'cell delay',y:lab,x:p.map(x=>x.cell_delay_ns),marker:{color:SER[0],line:{color:'#111d42',width:2}},hovertemplate:'%{y}<br>cell %{x:.3f} ns<extra></extra>'},
   {type:'bar',orientation:'h',name:'net (interconnect) delay',y:lab,x:p.map(x=>x.net_delay_ns),marker:{color:SER[1],line:{color:'#111d42',width:2}},hovertemplate:'%{y}<br>net %{x:.3f} ns<extra></extra>'}],
   {...layout('Top reg-to-reg paths: cell vs interconnect delay (ns)'),barmode:'stack',height:420,margin:{l:300,r:20,t:40,b:50}},cfg)}
 D.experiments.forEach(e=>{if(!document.getElementById('po_'+e.name))return;
  const obj=e.objectives||{reg2reg_setup_wns_ns:'max',area_um2:'min'};const ks=Object.keys(obj);
  const yk=ks.find(k=>obj[k]==='max')||'reg2reg_setup_wns_ns';const xk=ks.find(k=>k!==yk)||'area_um2';
  const c=(e.candidates||[]).filter(x=>x.status==='PASS'&&x[yk]!=null);if(!c.length)return;
  if(e.sensitivity){ // constraint varied on purpose: show slack per candidate, no Pareto front
    Plotly.newPlot('po_'+e.name,[{type:'bar',x:c.map(x=>x.label),y:c.map(x=>x[yk]),marker:{color:SER[0]},hovertemplate:'%{x}<br>'+yk+' %{y:.3f}<extra></extra>'}],
    {...layout(e.name+': '+yk+' per candidate (SENSITIVITY — constraint varied on purpose; no Pareto front)'),yaxis:{...layout('').yaxis,title:yk}},cfg);return}
  const cc=c.filter(x=>x[xk]!=null);if(!cc.length)return;
  Plotly.newPlot('po_'+e.name,[{type:'scatter',mode:'markers+text',x:cc.map(x=>x[xk]),y:cc.map(x=>x[yk]),text:cc.map(x=>x.label),textposition:'top center',cliponaxis:false,marker:{size:11,color:cc.map(x=>x.pareto?SER[1]:SER[0]),line:{color:'#111d42',width:2}},hovertemplate:'%{text}<br>'+xk+' %{x:.1f}<br>'+yk+' %{y:.3f}<extra></extra>'}],
  {...layout(e.name+': '+yk+' vs '+xk+' (gold = Pareto'+(e.tolerances&&Object.keys(e.tolerances).length?', with tolerances':'')+')'),xaxis:{...layout('').xaxis,title:xk},yaxis:{...layout('').yaxis,title:yk}},cfg)});
}
populate();render();
"""


def build(out: Path | None = None) -> str:
    import plotly.offline
    data = collect()
    out = out or (REPORTS_DIR / "dashboard.html")
    out.parent.mkdir(parents=True, exist_ok=True)
    html = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TimingFlow Dashboard</title><style>{CSS}</style>
<script>{plotly.offline.get_plotlyjs()}</script></head><body>
<header><h1>SilicaFlux TimingFlow<small>static timing analysis · multi-corner · timing closure</small></h1>
<div class="sub">Built from executed OpenSTA/OpenROAD runs only — no synthetic data. Stages without evidence show NOT RUN. Results before POST-ROUTE are estimates, not signoff.</div></header>
<div class="controls"><label>run<select id="run"></select></label><label>stage<select id="stage"></select></label><label>scene (mode × corner)<select id="scene"></select></label></div>
<nav>{''.join(f'<a href="#s{i}">{i} {t}</a>' for i, t in enumerate(['Overview','Status','Clocks','Corners','Paths','Setup','Hold','Clock tree','Breakdown','Optimisation','Before/after','Exceptions','Provenance','Readiness'], 1))}</nav>
<main id="main"></main>
<script type="application/json" id="tf-data">{json.dumps(data, default=str).replace('</', '<\\/')}</script>
<script>{JS}</script></body></html>"""
    out.write_text(html)
    return str(out)
