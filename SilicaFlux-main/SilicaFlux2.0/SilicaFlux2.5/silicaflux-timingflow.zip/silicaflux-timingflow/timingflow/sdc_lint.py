"""Static SDC lint — works on any SDC file (generated or hand-written).

Tokenises SDC as Tcl (braces, brackets, quotes, continuations, comments) and
applies rule checks that do not need a netlist.  Netlist-dependent checks
(object resolution, unconstrained endpoints) are done by OpenSTA and merged
by ``constraints.py``.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# OpenSTA 3.1.0 documents these as "parsed but ignored" (doc/Commands.md).
IGNORED_BY_OPENSTA = {"set_ideal_network", "set_ideal_latency", "set_ideal_transition"}
SDC_COMMANDS = {
    "create_clock", "create_generated_clock", "set_clock_uncertainty", "set_clock_latency",
    "set_clock_transition", "set_propagated_clock", "set_clock_groups", "set_clock_gating_check",
    "set_input_delay", "set_output_delay", "set_load", "set_driving_cell", "set_input_transition",
    "set_max_transition", "set_max_capacitance", "set_max_fanout", "set_min_capacitance",
    "set_false_path", "set_multicycle_path", "set_max_delay", "set_min_delay", "set_case_analysis",
    "set_disable_timing", "set_timing_derate", "set_operating_conditions", "set_wire_load_model",
    "set_wire_load_mode", "set_units", "set_fanout_load", "set_port_fanout_number", "set_sense",
    "set_data_check", "group_path", "set_ideal_network", "set_ideal_latency", "set_ideal_transition",
    "set_max_time_borrow", "set_resistance", "set_logic_zero", "set_logic_one", "set_logic_dc",
    "current_design", "set", "puts", "expr", "foreach", "if", "proc", "source", "set_hierarchy_separator",
}
EXCEPTION_CMDS = {"set_false_path", "set_multicycle_path", "set_max_delay", "set_min_delay"}


@dataclass
class Cmd:
    name: str
    args: list[str]
    line: int
    text: str

    def opt(self, name: str) -> str | None:
        for i, a in enumerate(self.args):
            if a == name and i + 1 < len(self.args):
                return self.args[i + 1]
        return None

    def has(self, name: str) -> bool:
        return name in self.args


@dataclass
class Finding:
    rule: str
    severity: str           # FAIL | WARNING | INFO
    line: int
    message: str
    text: str = ""


@dataclass
class LintResult:
    path: str
    commands: list[Cmd] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)

    def status(self) -> str:
        sev = {f.severity for f in self.findings}
        return "FAIL" if "FAIL" in sev else "WARNING" if "WARNING" in sev else "PASS"

    def as_dict(self) -> dict:
        return {"path": self.path, "status": self.status(), "n_commands": len(self.commands),
                "findings": [f.__dict__ for f in self.findings]}


def split_commands(text: str) -> list[tuple[int, str]]:
    """Split Tcl/SDC text into (line, command) respecting {} [] "" and continuations."""
    out: list[tuple[int, str]] = []
    buf, depth_b, depth_k, inq, start, line = [], 0, 0, False, 1, 1
    i = 0
    at_cmd_start = True
    while i < len(text):
        c = text[i]
        if c == "\\" and i + 1 < len(text) and text[i + 1] == "\n":
            buf.append(" ")
            i += 2
            line += 1
            continue
        if at_cmd_start and c == "#" and depth_b == 0 and depth_k == 0:
            while i < len(text) and text[i] != "\n":
                i += 1
            continue
        if c == '"' and depth_b == 0:
            inq = not inq
        elif not inq:
            if c == "{":
                depth_b += 1
            elif c == "}":
                depth_b -= 1
            elif c == "[":
                depth_k += 1
            elif c == "]":
                depth_k -= 1
        if (c in "\n;") and depth_b == 0 and depth_k == 0 and not inq:
            s = "".join(buf).strip()
            if s:
                out.append((start, s))
            buf = []
            if c == "\n":
                line += 1
            start = line
            at_cmd_start = True
            i += 1
            continue
        if c == "\n":
            line += 1
        if not c.isspace():
            if at_cmd_start and c != "#":
                start = line
            at_cmd_start = False
        buf.append(c)
        i += 1
    s = "".join(buf).strip()
    if s:
        out.append((start, s))
    return out


def tokenize(cmd: str) -> list[str]:
    toks, buf, db, dk, inq = [], [], 0, 0, False
    for c in cmd:
        if c == '"' and db == 0:
            inq = not inq
        elif not inq:
            if c == "{":
                db += 1
            elif c == "}":
                db -= 1
            elif c == "[":
                dk += 1
            elif c == "]":
                dk -= 1
        if c.isspace() and db == 0 and dk == 0 and not inq:
            if buf:
                toks.append("".join(buf))
                buf = []
            continue
        buf.append(c)
    if buf:
        toks.append("".join(buf))
    return toks


def parse(text: str) -> list[Cmd]:
    cmds = []
    for line, s in split_commands(text):
        if s.startswith(";#"):
            continue
        s = re.sub(r";\s*#.*$", "", s)
        t = tokenize(s)
        if t:
            cmds.append(Cmd(t[0], t[1:], line, s))
    return cmds


def _objs(arg: str | None) -> list[str]:
    """Names inside [get_xxx {a b}] / [get_xxx a] (best effort)."""
    if not arg:
        return []
    m = re.findall(r"\[\s*get_\w+\s+(?:-\w+\s+)*\{?([^\]\}]*)\}?\s*\]", arg)
    names = []
    for grp in m:
        names += grp.split()
    return names


def lint(path: str | Path, registry_ids: set[str] | None = None, known_commands: set[str] | None = None) -> LintResult:
    text = Path(path).read_text()
    res = LintResult(path=str(path), commands=parse(text))
    F = res.findings.append
    clocks: dict[str, Cmd] = {}
    clock_sources: dict[str, str] = {}
    mcp: dict[tuple, set[str]] = {}
    exc_targets: dict[tuple, list[str]] = {}
    for c in res.commands:
        known = known_commands or SDC_COMMANDS
        if c.name not in known and c.name not in SDC_COMMANDS:
            F(Finding("L10-unknown-command", "FAIL", c.line, f"unknown/unsupported command '{c.name}'", c.text[:160]))
        if c.name in IGNORED_BY_OPENSTA:
            F(Finding("L09-ignored-command", "WARNING", c.line,
                      f"'{c.name}' is parsed but ignored by OpenSTA 3.1.0 — it has no effect on timing", c.text[:160]))
        if c.name == "create_clock":
            name = c.opt("-name") or (c.args[-1] if c.args else "?")
            src = c.args[-1] if c.args and not c.args[-1].startswith("-") else ""
            if name in clocks and not c.has("-add"):
                F(Finding("L01-duplicate-clock", "FAIL", c.line, f"clock '{name}' defined twice (first at line {clocks[name].line})", c.text[:160]))
            if src and src in clock_sources and not c.has("-add"):
                F(Finding("L01-duplicate-clock-source", "FAIL", c.line,
                          f"source {src} already has clock '{clock_sources[src]}' (use -add for multiple clocks)", c.text[:160]))
            per = c.opt("-period")
            try:
                if per is not None and float(per) <= 0:
                    F(Finding("L05-bad-period", "FAIL", c.line, f"non-positive period {per}", c.text[:160]))
            except ValueError:
                F(Finding("L05-symbolic-period", "INFO", c.line, f"period '{per}' is an expression/variable; resolved only at read time", c.text[:160]))
            clocks[name] = c
            if src:
                clock_sources[src] = name
        if c.name == "create_generated_clock":
            name = c.opt("-name")
            if not c.opt("-source"):
                F(Finding("L06-genclk-no-source", "FAIL", c.line, "generated clock without -source", c.text[:160]))
            if not any(c.has(o) for o in ("-divide_by", "-multiply_by", "-edges", "-combinational")):
                F(Finding("L06-genclk-no-relation", "FAIL", c.line, "generated clock without -divide_by/-multiply_by/-edges", c.text[:160]))
            if name:
                clocks[name] = c
        # clock references
        for o in ("-clock",):
            v = c.opt(o)
            if v and c.name in ("set_input_delay", "set_output_delay") and v not in clocks:
                F(Finding("L02-unknown-clock", "FAIL", c.line, f"reference to undefined clock '{v}'", c.text[:160]))
        for ref in re.findall(r"get_clocks\s+\{?([\w\s*]+)\}?", c.text):
            for n in ref.split():
                if "*" not in n and n not in clocks:
                    F(Finding("L02-unknown-clock", "FAIL", c.line, f"get_clocks '{n}' before/without definition", c.text[:160]))
        if c.name in ("set_input_delay", "set_output_delay"):
            vals = [a for a in c.args if re.fullmatch(r"-?\d+(\.\d+)?", a)]
            if vals and all(float(v) == 0.0 for v in vals) and not c.has("-min"):
                F(Finding("L03-zero-io-delay", "WARNING", c.line, "zero IO delay: external timing not represented", c.text[:160]))
            if "all_inputs" in c.text or "all_outputs" in c.text:
                F(Finding("L04-blanket-io-delay", "WARNING", c.line, "same IO delay applied to every port (no per-interface derivation)", c.text[:160]))
        if c.name in EXCEPTION_CMDS or c.name == "set_clock_groups":
            cm = c.opt("-comment")
            cid = cm.strip('"{}') if cm else None
            if registry_ids is not None and (not cid or cid not in registry_ids):
                F(Finding("L13-unregistered-exception", "WARNING", c.line,
                          "timing exception not linked to an exception-registry entry (-comment <id>)", c.text[:160]))
        if c.name in EXCEPTION_CMDS:
            if not any(c.has(o) for o in ("-from", "-to", "-through", "-rise_from", "-fall_from", "-rise_to", "-fall_to")):
                F(Finding("L06-unbounded-exception", "FAIL", c.line, f"{c.name} without -from/-through/-to applies to the whole design", c.text[:160]))
            if re.search(r"all_(inputs|outputs|registers)|get_cells\s+\*|get_pins\s+\*|\{\*\}", c.text):
                F(Finding("L07-broad-exception", "FAIL", c.line, "exception targets a design-wide collection", c.text[:160]))
            if "*" in c.text:
                F(Finding("L08-wildcard-exception", "WARNING", c.line,
                          "wildcard in exception: scope must be proven with the exception-impact report", c.text[:160]))
            if "-filter" in c.text and "-hierarchical" in c.text:
                F(Finding("L08-hier-filter", "WARNING", c.line,
                          "hierarchical -filter match is tool/netlist-name dependent (breaks after flattening/renaming)", c.text[:160]))
            key = (c.opt("-from"), c.opt("-through"), c.opt("-to"))
            exc_targets.setdefault(key, []).append(c.name)
            if c.name == "set_multicycle_path":
                kind = "hold" if c.has("-hold") else "setup"
                mcp.setdefault(key, set()).add(kind)
            if c.name == "set_false_path" and re.search(r"get_clocks", c.opt("-from") or "") and re.search(r"get_clocks", c.opt("-to") or ""):
                F(Finding("L12-clock-false-path", "WARNING", c.line,
                          "clock-to-clock false path: use set_clock_groups with CDC evidence instead", c.text[:160]))
    for key, kinds in mcp.items():
        if "setup" in kinds and "hold" not in kinds:
            F(Finding("L11-mcp-no-hold", "FAIL", 0, f"multicycle -setup without matching -hold for {key}"))
    for key, cmds in exc_targets.items():
        uniq = set(cmds) - {"set_multicycle_path"} if cmds.count("set_multicycle_path") <= 2 else set(cmds)
        if len(set(cmds)) > 1 and "set_false_path" in cmds:
            F(Finding("L14-conflicting-exceptions", "WARNING", 0, f"false path and other exception on same path spec {key}: {sorted(set(cmds))}"))
    return res
