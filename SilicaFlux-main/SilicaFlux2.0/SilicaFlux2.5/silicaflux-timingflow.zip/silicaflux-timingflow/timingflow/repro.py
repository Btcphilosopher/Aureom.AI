"""Reproducibility check: re-run synthesis + stage A into a scratch run and
compare netlist hash and per-scene metrics bit-for-bit with the original run."""
from __future__ import annotations

import json
import shutil

from . import flow
from .parse_reports import read_json


def check(design: str, platform: str, run: str = "baseline") -> dict:
    rd = flow.run_dir_for(design, platform, run)
    rr = flow.run_dir_for(design, platform, run + "__repro")
    if rr.exists():
        shutil.rmtree(rr)
    a = read_json(rd / "sta_synthesis" / "summary.json")
    if not a:
        return {"identical": False, "reason": "original run has no stage-A summary"}
    per = read_json(rd / "synth" / "synth_summary.json", {}).get("period_target_ns")
    params = read_json(rd / "synth" / "synth_summary.json", {}).get("parameters") or {}
    flow.run_stage(design, platform, "synth", run + "__repro", per, params)
    flow.run_stage(design, platform, "synthesis", run + "__repro", per, params)
    b = read_json(rr / "sta_synthesis" / "summary.json")
    diffs = []
    if a["provenance"]["netlist_sha256_16"] != b["provenance"]["netlist_sha256_16"]:
        diffs.append("netlist hash differs")
    for sc, v in a["scenes"].items():
        w = b["scenes"].get(sc, {})
        for k in ("wns_ns", "tns_ns", "whs_ns", "ths_ns"):
            if v.get(k) != w.get(k):
                diffs.append(f"{sc} {k}: {v.get(k)} vs {w.get(k)}")
    res = {"identical": not diffs, "differences": diffs, "original": str(rd), "rerun": str(rr),
           "netlist_sha256_16": a["provenance"]["netlist_sha256_16"]}
    (rd / "repro_check.json").write_text(json.dumps(res, indent=1))
    return res
