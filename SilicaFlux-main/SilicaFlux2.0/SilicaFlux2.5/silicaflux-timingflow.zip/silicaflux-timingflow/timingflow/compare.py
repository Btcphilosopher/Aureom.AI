"""Compare two runs (baseline vs candidate) on identical terms.

Refuses to compare as equivalent when the platform, corner set, SDC digest or
tool revisions differ (reported as 'not comparable' with the reasons), so an
improvement cannot come from a constraint or library change.
"""
from __future__ import annotations

import json
from pathlib import Path

from .parse_reports import read_json

KEYS = ["wns_ns", "tns_ns", "whs_ns", "ths_ns"]


def _sum(run: Path, stage: str):
    return read_json(run / f"sta_{stage}" / "summary.json")


def comparable(a: dict, b: dict) -> list[str]:
    why = []
    if a["platform"] != b["platform"]:
        why.append(f"platform {a['platform']} vs {b['platform']}")
    if set(a["scenes"]) != set(b["scenes"]):
        why.append("different scene (mode x corner) sets")
    pa, pb = a.get("provenance", {}), b.get("provenance", {})
    if pa.get("liberty_sha256_16") != pb.get("liberty_sha256_16"):
        why.append("Liberty files differ")
    ta = {k: v for k, v in pa.get("tools", {}).items() if k in ("yosys", "opensta", "openroad")}
    tb = {k: v for k, v in pb.get("tools", {}).items() if k in ("yosys", "opensta", "openroad")}
    if ta != tb:
        why.append(f"tool revisions differ {ta} vs {tb}")
    ca = {k: v for k, v in pa.get("config_digest", {}).items() if k in ("io", "exceptions")}
    cb = {k: v for k, v in pb.get("config_digest", {}).items() if k in ("io", "exceptions")}
    if ca != cb:
        why.append("IO assumptions or exception registry differ")
    if a.get("parasitics") != b.get("parasitics"):
        why.append("parasitic models differ")
    return why


def compare(baseline: Path, candidate: Path, stage: str = "synthesis") -> dict:
    a, b = _sum(baseline, stage), _sum(candidate, stage)
    if not a or not b or a.get("status") != "PASS" or b.get("status") != "PASS":
        return {"status": "NOT RUN", "reason": f"stage {stage} missing or failed in one of the runs"}
    why = comparable(a, b)
    rows = []
    for sc in sorted(set(a["scenes"]) & set(b["scenes"])):
        va, vb = a["scenes"][sc], b["scenes"][sc]
        r = {"scene": sc}
        for k in KEYS:
            r[f"{k}_base"], r[f"{k}_cand"] = va[k], vb[k]
            r[f"{k}_delta"] = None if va[k] is None or vb[k] is None else round(vb[k] - va[k], 4)
        for k in ("setup_wns_ns", "hold_wns_ns"):
            x, y = va["reg2reg"].get(k), vb["reg2reg"].get(k)
            r[f"reg2reg_{k}_base"], r[f"reg2reg_{k}_cand"] = x, y
            r[f"reg2reg_{k}_delta"] = None if x is None or y is None else round(y - x, 4)
        rows.append(r)
    sa, sb = a.get("synthesis", {}), b.get("synthesis", {})
    area = {"area_um2_base": sa.get("total_area_um2"), "area_um2_cand": sb.get("total_area_um2"),
            "cells_base": sa.get("n_cells"), "cells_cand": sb.get("n_cells"),
            "flops_base": (sa.get("cell_classes") or {}).get("flops"), "flops_cand": (sb.get("cell_classes") or {}).get("flops")}
    if area["area_um2_base"] and area["area_um2_cand"]:
        area["area_delta_pct"] = round(100.0 * (area["area_um2_cand"] / area["area_um2_base"] - 1), 3)
    res = {"status": "COMPARABLE" if not why else "NOT COMPARABLE", "reasons": why, "stage": stage,
           "baseline": str(baseline), "candidate": str(candidate), "scenes": rows, "area": area}
    return res
