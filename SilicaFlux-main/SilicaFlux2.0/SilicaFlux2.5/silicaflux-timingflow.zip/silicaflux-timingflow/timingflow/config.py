"""Configuration models (pydantic v2) and loaders.

All timing intent lives in YAML under ``configs/``:

* ``platforms/<pdk>.yaml``  — corners, Liberty, physical collateral
* ``designs/<design>.yaml`` — sources, top, clocks, modes, IO file, exceptions file
* ``io/<design>.yaml``      — board/block-level IO timing assumptions
* ``exceptions/<design>.yaml`` — the controlled timing-exception registry

``${VAR}`` in strings is expanded from the environment (with defaults from
``paths.DEFAULT_ENV``).  Models forbid unknown keys so typos fail loudly.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .paths import CONFIG_DIR, ROOT, env

_VAR = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def expand(s: str) -> str:
    return _VAR.sub(lambda m: env(m.group(1)), s)


def _expand_tree(x: Any) -> Any:
    if isinstance(x, str):
        return expand(x)
    if isinstance(x, list):
        return [_expand_tree(i) for i in x]
    if isinstance(x, dict):
        return {k: _expand_tree(v) for k, v in x.items()}
    return x


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


# --------------------------------------------------------------------------- platform
class Corner(Strict):
    process: str
    voltage_v: float
    temperature_c: float
    stdcell_liberty: list[str]
    io_liberty: list[str] = []
    macro_liberty: str = ""
    macro_temperature_c: float | None = None
    checks: list[Literal["setup", "hold"]] = ["setup", "hold"]


class UnavailableCorner(Strict):
    name: str
    reason: str


class Cells(Strict):
    tiehi: list[str]
    tielo: list[str]
    buffer: list[str]
    min_buffer: list[str]
    abc_driver: str
    abc_load_ff: float
    dont_use: list[str] = []
    icg: str | None = None
    clock_buffers: list[str] = []


class PlatformIO(Strict):
    input_driver_cell: str
    input_driver_pin: str
    output_load_cell: str
    output_load_pin: str


class Physical(Strict):
    tech_lef: str
    stdcell_lef: list[str]
    macro_lef: str
    site: str
    setrc: str
    make_tracks: str
    pdn: str
    tapcell: str
    rcx_rules: str
    min_routing_layer: str
    max_routing_layer: str
    io_layers: dict[str, str]
    place_density: float
    core_margin_um: float
    fill_cells: list[str] = []


class Platform(Strict):
    name: str
    node: str
    status: Literal["AVAILABLE", "NOT_AVAILABLE"]
    root: str
    macro_root: str | None = None
    licence: str = ""
    corners: dict[str, Corner]
    unavailable_corners: list[UnavailableCorner] = []
    synthesis_corner: str
    cells: Cells
    io: PlatformIO
    physical: Physical
    drv_limits_source: str = ""

    def path(self, rel: str) -> Path:
        rel = rel.replace("{macro_root}", self.macro_root or "")
        p = Path(rel)
        return p if p.is_absolute() else Path(self.root) / p

    def macro_liberty(self, corner: str, macro: str) -> Path:
        pat = self.corners[corner].macro_liberty
        return self.path(pat.replace("{macro}", macro))

    def macro_lef(self, macro: str) -> Path:
        return self.path(self.physical.macro_lef.replace("{macro}", macro))

    def liberty_set(self, corner: str, macros: list[str]) -> dict[str, list[Path]]:
        c = self.corners[corner]
        return {
            "stdcell": [self.path(x) for x in c.stdcell_liberty],
            "io": [self.path(x) for x in c.io_liberty],
            "macro": [self.macro_liberty(corner, m) for m in macros],
        }


# --------------------------------------------------------------------------- design
class Uncertainty(Strict):
    pre_cts_setup: float
    pre_cts_hold: float
    post_cts_setup: float
    post_cts_hold: float
    basis: str


class ClockDef(Strict):
    name: str
    port: str
    period_ns: float
    period_source: str
    duty: float = 0.5
    uncertainty: Uncertainty
    ideal_transition_ns: float = 0.15
    source_latency_ns: float = 0.0
    source_latency_basis: str = "no board/PLL insertion data: 0 ns (stated, not measured)"


class GeneratedClockDef(Strict):
    name: str
    source_port: str
    target: str                        # 'port:<name>' or 'pin:<hier pin>'
    master: str
    divide_by: int
    invert: bool = False
    rtl_evidence: str
    note: str = ""


class ModeDef(Strict):
    name: str
    description: str
    case_analysis: dict[str, Literal[0, 1]] = {}
    clocks: list[str] | None = None          # None = all clocks
    status: Literal["DEFINED", "NOT_APPLICABLE"] = "DEFINED"
    reason: str = ""


class BlockMapEntry(Strict):
    prefix: str                       # hierarchical instance prefix (netlist path)
    block: Literal["CPU", "VECTOR", "TENSOR", "SRAM", "DATAFABRIC", "DMA",
                   "PERIPHERAL", "CLOCK/RESET", "DEBUG", "UNKNOWN"]
    sub: str = ""


class SynthOpts(Strict):
    flatten: bool = True
    keep_hierarchy: list[str] = []     # module base names kept as hierarchy
    abc_script: Literal["default", "speed"] = "default"
    defer: bool = False                # read_verilog -defer: elaborate only the requested parameterisation
    timeout_s: int = 7200


class DrvLimits(Strict):
    max_fanout: int | None = None
    max_transition_ns: float | None = None
    max_capacitance_pf: float | None = None
    basis: str


class DesignConfig(Strict):
    name: str
    title: str
    family: str
    status: Literal["IMPLEMENTED", "PARTIAL", "NOT_FOUND"]
    status_evidence: str = ""
    kind: Literal["soc", "block"] = "soc"
    source_root: str = ""
    top: str = ""
    filelist: str | None = None
    sources: list[str] = []
    exclude: list[str] = []
    tech_sources: dict[str, list[str]] = {}
    extra_sources: list[str] = []
    include_dirs: list[str] = []
    defines: list[str] = []
    parameters: dict[str, Any] = {}
    macros: dict[str, list[str]] = {}
    platforms: list[str] = []
    synth: SynthOpts = SynthOpts()
    clocks: list[ClockDef] = []
    generated_clocks: list[GeneratedClockDef] = []
    modes: list[ModeDef] = []
    io_file: str | None = None
    exceptions_file: str | None = None
    block_map: list[BlockMapEntry] = []
    reset_ports: list[str] = []
    drv: DrvLimits | None = None
    notes: list[str] = []

    @model_validator(mode="after")
    def _check(self):
        if self.status != "NOT_FOUND":
            if not self.top:
                raise ValueError(f"{self.name}: top required")
            if not (self.filelist or self.sources):
                raise ValueError(f"{self.name}: filelist or sources required")
            names = [c.name for c in self.clocks]
            if len(names) != len(set(names)):
                raise ValueError(f"{self.name}: duplicate clock names {names}")
        return self

    def src_root(self) -> Path:
        return (ROOT / self.source_root).resolve()

    def rtl_files(self, platform: str) -> list[Path]:
        root = self.src_root()
        files: list[str] = []
        if self.filelist:
            for line in (root / self.filelist).read_text().splitlines():
                line = line.strip()
                if line and not line.startswith(("#", "//")):
                    files.append(line)
        files += self.sources
        files = [f for f in files if f not in self.exclude]
        files += self.tech_sources.get(platform, [])
        files += self.extra_sources
        out = []
        for f in files:
            p = Path(f)
            out.append(p if p.is_absolute() else (root / p))
        return out

    def clock(self, name: str) -> ClockDef:
        for c in self.clocks:
            if c.name == name:
                return c
        raise KeyError(name)


# --------------------------------------------------------------------------- IO
class IOGroup(Strict):
    name: str
    ports: list[str]
    direction: Literal["input", "output"]
    kind: Literal["sync", "async", "static", "clock", "reset"]
    clock: str | None = None
    clock_edge: Literal["rise", "fall"] = "rise"
    max_ns: float | None = None
    min_ns: float | None = None
    max_delay_bound_ns: float | None = None    # for async: set_max_delay bound
    exception_id: str | None = None
    derivation: str
    modes: list[str] | None = None


class IOConfig(Strict):
    design: str
    level: Literal["board", "block-budget"]
    status: Literal["ASSUMED_UNREVIEWED", "REVIEWED", "MEASURED"]
    owner: str
    revision: str
    assumptions: list[str]
    input_transition_ns: float | None = None
    groups: list[IOGroup]


# --------------------------------------------------------------------------- exceptions
class ExceptionEntry(Strict):
    id: str
    type: Literal["false_path", "multicycle_path", "clock_groups_async", "max_delay",
                  "min_delay", "case_analysis", "disable_timing"]
    modes: list[str] = ["func"]
    from_: list[str] = Field(default=[], alias="from")
    to: list[str] = []
    through: list[str] = []
    groups: list[list[str]] = []
    value: float | None = None
    setup_multiplier: int | None = None
    hold_multiplier: int | None = None
    setup_reference: Literal["start", "end"] = "end"
    hold_reference: Literal["start", "end"] = "end"
    case_value: int | None = None
    datapath_only: bool = False
    reason: str
    rtl_evidence: list[str]
    verification_evidence: list[str] = []
    owner: str
    approval: Literal["PROPOSED", "PENDING_REVIEW", "APPROVED", "REJECTED"]
    date: str
    design_revision: str
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class ExceptionRegistry(Strict):
    design: str
    revision: str
    exceptions: list[ExceptionEntry]

    @field_validator("exceptions")
    @classmethod
    def _unique(cls, v):
        ids = [e.id for e in v]
        dup = {i for i in ids if ids.count(i) > 1}
        if dup:
            raise ValueError(f"duplicate exception ids: {sorted(dup)}")
        return v


# --------------------------------------------------------------------------- loaders
def _load_yaml(path: Path) -> dict:
    with open(path) as f:
        return _expand_tree(yaml.safe_load(f))


def load_platform(name: str) -> Platform:
    return Platform.model_validate(_load_yaml(CONFIG_DIR / "platforms" / f"{name}.yaml"))


def load_design(name: str) -> DesignConfig:
    return DesignConfig.model_validate(_load_yaml(CONFIG_DIR / "designs" / f"{name}.yaml"))


def load_io(design: DesignConfig) -> IOConfig | None:
    if not design.io_file:
        return None
    return IOConfig.model_validate(_load_yaml(CONFIG_DIR / design.io_file))


def load_exceptions(design: DesignConfig) -> ExceptionRegistry | None:
    if not design.exceptions_file:
        return None
    return ExceptionRegistry.model_validate(_load_yaml(CONFIG_DIR / design.exceptions_file))


def list_designs() -> list[str]:
    return sorted(p.stem for p in (CONFIG_DIR / "designs").glob("*.yaml"))


def list_platforms() -> list[str]:
    return sorted(p.stem for p in (CONFIG_DIR / "platforms").glob("*.yaml") if p.stem != "commercial")


def file_digest(paths: list[Path]) -> str:
    h = hashlib.sha256()
    for p in paths:
        h.update(str(p.name).encode())
        h.update(Path(p).read_bytes())
    return h.hexdigest()[:16]


def config_digest(design: DesignConfig) -> dict[str, str]:
    """Digest of every config file that defines this design's timing intent."""
    files = {"design": CONFIG_DIR / "designs" / f"{design.name}.yaml"}
    if design.io_file:
        files["io"] = CONFIG_DIR / design.io_file
    if design.exceptions_file:
        files["exceptions"] = CONFIG_DIR / design.exceptions_file
    return {k: hashlib.sha256(v.read_bytes()).hexdigest()[:16] for k, v in files.items()}


def dump(model: BaseModel) -> str:
    return json.dumps(model.model_dump(by_alias=True), indent=1)
