"""Stage summaries: turn the raw OpenSTA/OpenROAD reports of one stage into a
single provenance-stamped summary.json (units: ns, pF, W, um^2)."""
from __future__ import annotations

import json
import re
from pathlib import Path

from . import provenance
from .config import DesignConfig, Platform
from .critical_paths import BlockMapper, block_bottlenecks, rank_paths
from .parse_reports import (group_stats, merge_fanout, parse_check_setup, parse_drv, parse_ends,
                            parse_latency, parse_paths_json, parse_paths_text, parse_power, parse_pulse,
                            parse_skew, read_json)
from .sdc_gen import netlist_top_ports
from .sta import STAGE_LABEL

PRE_CTS = {"synthesis", "placement"}
CLOCK_GROUP_EXCLUDE = {"asynchronous", "path delay", "unconstrained", "gated clock"}


def _fanout_limit(platform: Platform) -> int | None:
    from . import liberty
    for lib in platform.liberty_set(platform.synthesis_corner, [])["stdcell"]:
        if lib.exists():
            m = re.search(r"default_max_fanout\s*:\s*([0-9.]+)", lib.read_text(errors="replace")[:200000])
            if m:
                return int(float(m.group(1)))
    return None


def summarize_stage(design: DesignConfig, platform: Platform, run_dir: Path, stage: str,
                    stage_dir: str | None = None, top_paths: int = 40) -> dict:
    sd = run_dir / (stage_dir or f"sta_{stage}")
    rr = read_json(sd / "run_result.json", {}) or {}
    res: dict = {"design": design.name, "title": design.title, "platform": platform.name,
                 "node": platform.node, "stage": stage, "label": STAGE_LABEL[stage],
                 "status": rr.get("status", "NOT RUN"), "run_dir": str(run_dir), "stage_dir": str(sd),
                 "parasitics": rr.get("parasitics_description", rr.get("parasitics", "")),
                 "clocks_mode": "ideal" if stage in PRE_CTS else "propagated",
                 "corners": rr.get("corners", []), "modes": rr.get("modes", [])}
    if res["status"] != "PASS":
        res["reason"] = rr.get("reason") or rr.get("tail", "")[-1500:]
        (sd).mkdir(parents=True, exist_ok=True)
        (sd / "summary.json").write_text(json.dumps(res, indent=1))
        return res
    netlist = run_dir / "synth" / "netlist.v"
    ports = set(netlist_top_ports(netlist, design.top)) if netlist.exists() else None
    mapper = BlockMapper(design.block_map, ports)
    fo_lim = _fanout_limit(platform)
    interconnect = stage not in ("synthesis",) or "wire-load" in res["parasitics"]
    scenes = {}
    worst = {"setup": None, "hold": None, "r2r_setup": None}
    for mf in sorted(sd.glob("metrics_*.json")):
        m = read_json(mf)
        s = m["scene"]
        ends = parse_ends(sd / f"ends_setup_{s}.rpt") + parse_ends(sd / f"ends_hold_{s}.rpt")
        gs = group_stats(ends)
        jp_setup = parse_paths_json(sd / f"paths_setup_{s}.json")
        jp_hold = parse_paths_json(sd / f"paths_hold_{s}.json")
        merge_fanout(jp_setup, parse_paths_text(sd / f"paths_setup_{s}.rpt"))
        merge_fanout(jp_hold, parse_paths_text(sd / f"paths_hold_{s}.rpt"))
        # reg2reg = clocked data checks only (recovery/removal and max_delay groups excluded)
        r2r = [p for p in (parse_paths_json(sd / f"paths_r2r_setup_{s}.json") if (sd / f"paths_r2r_setup_{s}.json").exists() else [])
               if p.get("group") not in CLOCK_GROUP_EXCLUDE]
        r2r_h = [p for p in (parse_paths_json(sd / f"paths_r2r_hold_{s}.json") if (sd / f"paths_r2r_hold_{s}.json").exists() else [])
                 if p.get("group") not in CLOCK_GROUP_EXCLUDE]
        if (sd / f"paths_r2r_setup_{s}.rpt").exists():
            merge_fanout(r2r, parse_paths_text(sd / f"paths_r2r_setup_{s}.rpt"))
        sram_rd = parse_paths_json(sd / f"paths_sram_rd_setup_{s}.json") if (sd / f"paths_sram_rd_setup_{s}.json").exists() else []
        sram_wr = parse_paths_json(sd / f"paths_sram_wr_setup_{s}.json") if (sd / f"paths_sram_wr_setup_{s}.json").exists() else []
        sram_wh = parse_paths_json(sd / f"paths_sram_wr_hold_{s}.json") if (sd / f"paths_sram_wr_hold_{s}.json").exists() else []
        drv = parse_drv(sd / f"drv_{s}.rpt") if (sd / f"drv_{s}.rpt").exists() else {}
        pulse = parse_pulse(sd / f"pulse_{s}.rpt") if (sd / f"pulse_{s}.rpt").exists() else {}
        asy = parse_ends(sd / f"async_{s}.rpt") if (sd / f"async_{s}.rpt").exists() else []
        gating = parse_ends(sd / f"gating_{s}.rpt") if (sd / f"gating_{s}.rpt").exists() else []
        skew_s = parse_skew(sd / f"skew_setup_{s}.rpt") if (sd / f"skew_setup_{s}.rpt").exists() else {}
        skew_h = parse_skew(sd / f"skew_hold_{s}.rpt") if (sd / f"skew_hold_{s}.rpt").exists() else {}
        lat = parse_latency(sd / f"latency_{s}.rpt") if (sd / f"latency_{s}.rpt").exists() else {}
        icg = platform.cells.icg
        icg_rows = [r for r in ends if icg and r.get("ref") == icg]
        setup_rows = [r for r in ends if r["check"] == "setup"]
        hold_rows = [r for r in ends if r["check"] == "hold"]
        clk_setup = [r for r in setup_rows if r["group"] not in CLOCK_GROUP_EXCLUDE]
        clk_hold = [r for r in hold_rows if r["group"] not in CLOCK_GROUP_EXCLUDE]

        def agg(rows):
            v = [r for r in rows if r["violated"]]
            fin = [r["slack_ns"] for r in rows if abs(r["slack_ns"]) != float("inf")]
            return {"endpoints": len(rows), "violators": len(v), "wns_ns": min(fin) if fin else None,
                    "tns_ns": round(sum(r["slack_ns"] for r in v), 4)}

        rk = rank_paths(jp_setup, mapper, fo_lim, interconnect, top_paths)
        rk_h = rank_paths(jp_hold, mapper, fo_lim, interconnect, min(top_paths, 20))
        rk_r2r = rank_paths(r2r, mapper, fo_lim, interconnect, top_paths)
        r2r_wns = min((p["slack_ns"] for p in r2r), default=None)
        r2r_hold_wns = min((p["slack_ns"] for p in r2r_h), default=None)
        sc = {"mode": m["mode"], "corner": m["corner"],
              "wns_ns": m["wns_ns"], "tns_ns": m["tns_ns"], "whs_ns": m["whs_ns"], "ths_ns": m["ths_ns"],
              "setup_all": agg(setup_rows), "hold_all": agg(hold_rows),
              "setup_clock_groups": agg(clk_setup), "hold_clock_groups": agg(clk_hold),
              "groups": gs,
              "reg2reg": {"setup_wns_ns": r2r_wns, "hold_wns_ns": r2r_hold_wns, "paths_reported": len(r2r)},
              "sram": {"read_setup_wns_ns": min((p["slack_ns"] for p in sram_rd), default=None),
                       "write_setup_wns_ns": min((p["slack_ns"] for p in sram_wr), default=None),
                       "write_hold_wns_ns": min((p["slack_ns"] for p in sram_wh), default=None),
                       "read_top": rank_paths(sram_rd, mapper, fo_lim, interconnect, 5),
                       "write_top": rank_paths(sram_wr, mapper, fo_lim, interconnect, 5),
                       "write_hold_top": rank_paths(sram_wh, mapper, fo_lim, interconnect, 5)},
              "drv": {k: {"violators": v["violators"], "worst_slack": v["worst_slack"], "top": v["items"][:10]}
                      for k, v in drv.items()},
              "min_pulse_width": {"violators": pulse.get("violators"), "worst_slack_ns": pulse.get("worst_slack_ns"),
                                  "indicative_only": stage in PRE_CTS},
              "recovery_removal": {"violators": sum(1 for r in asy if r["violated"]),
                                   "worst_slack_ns": min((r["slack_ns"] for r in asy), default=None)},
              "clock_gating": {"checks": len(gating), "violators": sum(1 for r in gating if r["violated"]),
                               "worst_slack_ns": min((r["slack_ns"] for r in gating), default=None),
                               "icg_enable_setup_worst_ns": min((r["slack_ns"] for r in icg_rows if r["check"] == "setup"), default=None),
                               "icg_enable_hold_worst_ns": min((r["slack_ns"] for r in icg_rows if r["check"] == "hold"), default=None),
                               "icg_enable_endpoints": sorted({r["endpoint"] for r in icg_rows}),
                               "note": "integrated clock gates are timed by their Liberty GATE setup/hold arcs (regular clock path group); "
                                       "OpenSTA-inferred gating checks apply only to discrete gating logic"},
              "clock_skew": {"setup": skew_s, "hold": skew_h, "indicative_only": stage in PRE_CTS},
              "clock_latency": {"clocks": lat, "indicative_only": stage in PRE_CTS},
              "top_setup_paths": rk, "top_hold_paths": rk_h, "top_reg2reg_paths": rk_r2r,
              "bottlenecks_setup": block_bottlenecks(ends, mapper, "setup"),
              "bottlenecks_hold": block_bottlenecks(ends, mapper, "hold"),
              "bottlenecks_setup_clocked": block_bottlenecks(ends, mapper, "setup", CLOCK_GROUP_EXCLUDE)}
        if r2r_wns is not None:
            clk = design.clocks[0]
            sc["reg2reg"]["fmax_derived_mhz"] = round(1000.0 / (clk.period_ns - r2r_wns), 2) if clk.period_ns - r2r_wns > 0 else None
            sc["reg2reg"]["fmax_note"] = (f"DERIVED: 1/(T - worst reg2reg slack) for {clk.name}; {res['label']}, "
                                          f"{res['clocks_mode']} clocks, corner {m['corner']}; not a measured frequency")
        thr = {}
        for tf_ in sorted(sd.glob(f"through_*_{s}.json")):
            inst = tf_.stem[len("through_"): -len(f"_{s}")]
            tp = [p for p in parse_paths_json(tf_)]
            if tp:
                w = min(tp, key=lambda p: p["slack_ns"])
                thr[inst] = {"slack_ns": w["slack_ns"], "group": w["group"], "startpoint": w["startpoint"],
                             "endpoint": w["endpoint"], "logic_depth": w["logic_depth"]}
                # worst *clocked data* path through the block (recovery/removal, path-delay and
                # unconstrained groups excluded) with the delay spent inside the block itself
                clk_p = [p for p in tp if p["group"] not in CLOCK_GROUP_EXCLUDE]
                if clk_p:
                    c = min(clk_p, key=lambda p: p["slack_ns"])
                    pre = inst.rstrip("/") + "/"
                    inside = sum(pt["incr_ns"] or 0.0 for pt in c["points"] if pt["pin"].startswith(pre))
                    thr[inst]["clocked"] = {"slack_ns": c["slack_ns"], "group": c["group"], "startpoint": c["startpoint"],
                                            "endpoint": c["endpoint"], "logic_depth": c["logic_depth"],
                                            "delay_inside_block_ns": round(inside, 4),
                                            "arrival_ns": c["arrival_ns"]}
        sc["worst_through_block"] = thr
        if not thr:
            sc["worst_through_block_note"] = ("NOT RUN: no block-boundary (-through) query results in this stage directory "
                                              "(OpenROAD physical stages link the netlist flat, so no hierarchical instance exists; "
                                              "stage-A runs made before the query was added have none); block attribution uses "
                                              "endpoints and path delay-by-block instead")
        scenes[s] = sc
        for key, val, path in (("setup", m["wns_ns"], rk[0] if rk else None),
                               ("hold", m["whs_ns"], rk_h[0] if rk_h else None),
                               ("r2r_setup", r2r_wns, rk_r2r[0] if rk_r2r else None)):
            if val is not None and (worst[key] is None or val < worst[key]["slack_ns"]):
                worst[key] = {"scene": s, "slack_ns": val, "path": path}
    res["scenes"] = scenes
    res["worst"] = worst
    modes = res["modes"] or sorted({v["mode"] for v in scenes.values()})
    res["check_setup"] = {mm: parse_check_setup(sd / f"check_setup_{mm}.rpt") for mm in modes
                          if (sd / f"check_setup_{mm}.rpt").exists()}
    res["clocks"] = {mm: read_json(sd / f"clocks_{mm}.json", []) for mm in modes}
    res["coverage"] = {mm: read_json(sd / f"coverage_{mm}.json", {}) for mm in modes}
    pw = list(sd.glob("power_*.rpt"))
    if pw:
        res["power"] = parse_power(pw[0])
        res["power"]["scene"] = pw[0].stem[6:]
        res["power"]["basis"] = ("VECTORLESS ESTIMATE: input activity 0.1, duty 0.5 propagated by OpenSTA; "
                                 "Liberty power models; no simulation activity (VCD/SAIF) — not a power signoff number")
    synth = read_json(run_dir / "synth" / "synth_summary.json", {}) or {}
    res["synthesis"] = {k: synth.get(k) for k in ("total_area_um2", "n_cells", "cell_classes", "runtime_s",
                                                  "period_target_ns", "synthesis_corner", "inferred_latches",
                                                  "check_warnings", "n_warnings")}
    res["provenance"] = provenance.collect(design, platform, run_dir, sd)
    (sd / "summary.json").write_text(json.dumps(res, indent=1, default=str))
    return res
