"""Repository paths and environment defaults."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs"
TCL_DIR = ROOT / "tcl"
RUNS_DIR = Path(os.environ.get("TIMINGFLOW_RUNS", ROOT / "runs"))
REPORTS_DIR = ROOT / "reports"

# Defaults reflect the reference environment documented in docs/TOOLS.md.
DEFAULT_ENV = {
    "ORFS_PLATFORMS": "/opt/eda/orfs/flow/platforms",
    "ORFS_SCRIPTS": "/opt/eda/orfs/flow/scripts",
    "YOSYS": "yosys",
    "STA": "/opt/eda/opensta/bin/sta",
    "OPENROAD": "/opt/eda/openroad/bin/openroad",
    "VERILATOR": "verilator",
    "IVERILOG": "iverilog",
}


def env(name: str) -> str:
    return os.environ.get(name, DEFAULT_ENV.get(name, ""))
