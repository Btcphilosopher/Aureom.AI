"""Timing report package: TXT, CSV, JSON, HTML, PNG for one run.

Everything is read from the run's summaries/audit/gates (actual tool output).
Units are explicit in every column name.  A report is written only with its
provenance block; stages that did not run appear as NOT RUN.
"""
from __future__ import annotations

import base64
import csv
import io
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from .parse_reports import parse_ends, read_json  # noqa: E402
from .paths import REPORTS_DIR  # noqa: E402

STAGES = ["synthesis", "placement", "cts", "global_route", "postroute"]
# validated (dataviz validate_palette.js, dark mode, surface #0b1430)
NAVY, PANEL, INK, INK2, GRID = "#0b1430", "#111d42", "#e8ecf6", "#a9b3cf", "#24315c"
SERIES = ["#0aa2c0", "#b8891a", "#8466ee", "#d6528f"]
STATUS = {"PASS": "#2fa36b", "WARNING": "#c98a00", "FAIL": "#d9534f", "NOT RUN": "#7a839c",
          "NOT APPLICABLE": "#56607a", "REVIEW REQUIRED": "#c98a00"}
ICON = {"PASS": "✔", "WARNING": "▲", "FAIL": "✖", "NOT RUN": "○", "NOT APPLICABLE": "–"}


def _style(ax, title):
    ax.set_facecolor(PANEL)
    ax.figure.set_facecolor(NAVY)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.grid(axis="x", color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)
    ax.set_title(title, color=INK, fontsize=10, loc="left", fontweight="bold")
    ax.xaxis.label.set_color(INK2)
    ax.yaxis.label.set_color(INK2)


def _png(fig, path: Path) -> str:
    fig.tight_layout()
    fig.savefig(path, dpi=144, facecolor=NAVY)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, facecolor=NAVY)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def load_run(run_dir: Path) -> dict:
    return {"manifest": read_json(run_dir / "manifest.json", {}),
            "synth": read_json(run_dir / "synth" / "synth_summary.json"),
            "audit": read_json(run_dir / "constraint_audit.json"),
            "gates": read_json(run_dir / "gates.json"),
            "cdc": read_json(run_dir / "constraint_analysis" / "cdc.json"),
            "impact": read_json(run_dir / "constraint_analysis" / "exception_impact.json", []),
            "stages": {s: read_json(run_dir / f"sta_{s}" / "summary.json") for s in STAGES}}


def scene_rows(stages: dict) -> list[dict]:
    rows = []
    for st, sm in stages.items():
        if not sm or sm.get("status") != "PASS":
            rows.append({"stage": st, "label": (sm or {}).get("label", st.upper()), "status": (sm or {}).get("status", "NOT RUN")})
            continue
        for sc, v in sm["scenes"].items():
            rows.append({"stage": st, "label": sm["label"], "status": "PASS", "scene": sc, "mode": v["mode"],
                         "corner": v["corner"], "parasitics": sm["parasitics"], "clocks": sm["clocks_mode"],
                         "wns_ns": v["wns_ns"], "tns_ns": v["tns_ns"], "whs_ns": v["whs_ns"], "ths_ns": v["ths_ns"],
                         "setup_violators": v["setup_all"]["violators"], "hold_violators": v["hold_all"]["violators"],
                         "clock_group_setup_wns_ns": v["setup_clock_groups"]["wns_ns"],
                         "clock_group_hold_wns_ns": v["hold_clock_groups"]["wns_ns"],
                         "reg2reg_setup_wns_ns": v["reg2reg"]["setup_wns_ns"],
                         "reg2reg_hold_wns_ns": v["reg2reg"]["hold_wns_ns"],
                         "reg2reg_fmax_derived_mhz": v["reg2reg"].get("fmax_derived_mhz"),
                         "recovery_wns_ns": v["recovery_removal"]["worst_slack_ns"],
                         "recovery_violators": v["recovery_removal"]["violators"],
                         "sram_read_setup_wns_ns": v["sram"]["read_setup_wns_ns"],
                         "sram_write_setup_wns_ns": v["sram"]["write_setup_wns_ns"],
                         "sram_write_hold_wns_ns": v["sram"]["write_hold_wns_ns"],
                         "max_slew_violators": v["drv"].get("max_slew", {}).get("violators"),
                         "max_cap_violators": v["drv"].get("max_capacitance", {}).get("violators"),
                         "max_fanout_violators": v["drv"].get("max_fanout", {}).get("violators"),
                         "pulse_width_violators": v["min_pulse_width"]["violators"],
                         "clock_gating_worst_ns": v["clock_gating"]["worst_slack_ns"]})
    return rows


def charts(run: dict, out: Path) -> dict:
    imgs = {}
    stages = {k: v for k, v in run["stages"].items() if v and v.get("status") == "PASS"}
    if not stages:
        return imgs
    latest_name = [s for s in STAGES if s in stages][-1]
    sm = stages[latest_name]
    sd = Path(sm["stage_dir"])
    # 1. worst setup slack per path group, corners as series (func mode)
    func = {k: v for k, v in sm["scenes"].items() if v["mode"] == "func"} or sm["scenes"]
    groups = sorted({g["group"] for v in func.values() for g in v["groups"].values() if g["check"] == "setup"})
    fig, ax = plt.subplots(figsize=(8, 0.5 + 0.55 * len(groups) * max(1, len(func)) / 2))
    _style(ax, f"Worst setup slack by path group — {sm['label']} (ns)")
    h = 0.8 / max(1, len(func))
    for i, (sc, v) in enumerate(sorted(func.items())):
        vals = []
        for gname in groups:
            gg = v["groups"].get(f"setup:{gname}")
            vals.append(gg["wns_ns"] if gg and gg["wns_ns"] is not None and abs(gg["wns_ns"]) < 1e9 else 0)
        ys = [j + i * h for j in range(len(groups))]
        ax.barh(ys, vals, height=h * 0.9, color=SERIES[i % 4], label=v["corner"], edgecolor=PANEL, linewidth=2)
    ax.set_yticks([j + h * (len(func) - 1) / 2 for j in range(len(groups))])
    ax.set_yticklabels(groups, color=INK2)
    ax.axvline(0, color=INK2, linewidth=0.8)
    ax.set_xlabel("slack (ns)  — negative = violation")
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=INK, fontsize=8, title="corner", title_fontsize=8,
              loc="upper left", bbox_to_anchor=(1.01, 1.0))
    imgs["slack_by_group"] = _png(fig, out / "slack_by_group.png")
    # 2. endpoint slack histogram, clock groups only, per corner (small multiples)
    fig, axs = plt.subplots(1, len(func), figsize=(3.2 * len(func), 2.8), squeeze=False)
    for i, (sc, v) in enumerate(sorted(func.items())):
        ax = axs[0][i]
        rows = [r for r in parse_ends(sd / f"ends_setup_{sc}.rpt")
                if r["group"] not in ("asynchronous", "path delay", "unconstrained") and abs(r["slack_ns"]) < 1e9]
        _style(ax, f"{v['corner']}: reg/IO setup endpoints")
        ax.hist([r["slack_ns"] for r in rows], bins=40, color=SERIES[i % 4], edgecolor=PANEL, linewidth=0.5)
        ax.axvline(0, color=INK2, linewidth=0.8)
        ax.set_xlabel("slack (ns)")
        ax.grid(axis="y", color=GRID, linewidth=0.6)
    imgs["endpoint_hist"] = _png(fig, out / "endpoint_slack_histogram.png")
    # 3. cell vs net delay for top reg2reg paths (worst scene)
    worst_sc = min(func.items(), key=lambda kv: kv[1]["reg2reg"]["setup_wns_ns"] if kv[1]["reg2reg"]["setup_wns_ns"] is not None else 1e9)[0]
    tp = func[worst_sc]["top_reg2reg_paths"][:12]
    if tp:
        fig, ax = plt.subplots(figsize=(8.5, 1.4 + 0.35 * len(tp)))
        _style(ax, f"Top reg-to-reg paths, delay composition — {worst_sc} (ns)")
        y = list(range(len(tp)))[::-1]
        launch = [p.get("launch_delay_ns") or 0.0 for p in tp]
        cell = [p["cell_delay_ns"] for p in tp]
        net = [p["net_delay_ns"] for p in tp]
        ax.barh(y, launch, color=SERIES[2], label="launch (clock arrival + clock→Q / macro clock→DOUT / input delay)", edgecolor=PANEL, linewidth=2)
        ax.barh(y, cell, left=launch, color=SERIES[0], label="cell delay", edgecolor=PANEL, linewidth=2)
        ax.barh(y, net, left=[a + b for a, b in zip(launch, cell)], color=SERIES[1], label="net (interconnect) delay",
                edgecolor=PANEL, linewidth=2)
        if not any(net):
            ax.text(0.99, 1.01, "interconnect not modelled at this stage (net delay = 0)", transform=ax.transAxes,
                    ha="right", va="bottom", color=INK2, fontsize=7)
        ax.set_yticks(y)
        ax.set_yticklabels([f"#{p['rank']} {p['owner_block']}: …{p['endpoint'][-38:]}  ({p['slack_ns']:+.2f})" for p in tp],
                           color=INK2, fontsize=7)
        ax.set_xlabel("delay (ns); label: owner block, endpoint, (slack ns)")
        ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=INK, fontsize=8, loc="upper center",
                  bbox_to_anchor=(0.5, -0.16), ncol=3)
        imgs["path_breakdown"] = _png(fig, out / "path_delay_breakdown.png")
    # 4. per-block violating endpoints (setup), worst func scene
    bn = [b for b in func[worst_sc]["bottlenecks_setup"] if b["block"] != "IO"]
    if bn:
        fig, ax = plt.subplots(figsize=(8, 0.6 + 0.35 * len(bn)))
        _style(ax, f"Setup violators by block — {worst_sc}")
        y = list(range(len(bn)))[::-1]
        ax.barh(y, [b["violators"] for b in bn], color=SERIES[2], edgecolor=PANEL, linewidth=2)
        ax.set_yticks(y)
        ax.set_yticklabels([f"{b['block']} (WNS {b['wns_ns']:+.2f} ns)" for b in bn], color=INK2, fontsize=8)
        for yy, b in zip(y, bn):
            ax.text(b["violators"], yy, f" {b['violators']}/{b['endpoints']}", va="center", color=INK, fontsize=7)
        ax.set_xlabel("violating endpoints (all setup path groups incl. recovery)")
        imgs["block_violators"] = _png(fig, out / "block_violators.png")
    # 5. clock-tree geometry from the CTS database (real OpenDB coordinates)
    ct = None
    for st in ("postroute", "global_route", "cts"):
        cand = Path(run["stages"][st]["stage_dir"]) / "clock_tree.json" if run["stages"].get(st) and run["stages"][st].get("stage_dir") else None
        if cand and cand.exists():
            ct = json.loads(cand.read_text())
            break
    if ct is None and run["stages"].get("cts") and run["stages"]["cts"].get("stage_dir"):
        cand = Path(run["stages"]["cts"]["stage_dir"]) / "clock_tree.json"
        ct = json.loads(cand.read_text()) if cand.exists() else None
    if ct:
        fig, ax = plt.subplots(figsize=(6.4, 6.4))
        _style(ax, "Clock tree from the CTS database (µm)")
        ax.grid(axis="y", color=GRID, linewidth=0.6)
        d = ct["die_um"]
        ax.plot([d["x1"], d["x2"], d["x2"], d["x1"], d["x1"]], [d["y1"], d["y1"], d["y2"], d["y2"], d["y1"]], color=INK2, linewidth=0.8)
        nsink = nbuf = 0
        for n in ct["clock_nets"]:
            for dr in n["drivers"]:
                for sk in n["sinks"]:
                    ax.plot([dr["x_um"], sk["x_um"]], [dr["y_um"], sk["y_um"]], color=SERIES[2], linewidth=0.25, alpha=0.5)
        xs = [sk["x_um"] for n in ct["clock_nets"] for sk in n["sinks"] if not sk["master"].startswith(("sg13g2_buf", "sky130_fd_sc_hd__clkbuf", "sky130_fd_sc_hd__buf"))]
        ys = [sk["y_um"] for n in ct["clock_nets"] for sk in n["sinks"] if not sk["master"].startswith(("sg13g2_buf", "sky130_fd_sc_hd__clkbuf", "sky130_fd_sc_hd__buf"))]
        bx = [dr["x_um"] for n in ct["clock_nets"] for dr in n["drivers"]]
        by = [dr["y_um"] for n in ct["clock_nets"] for dr in n["drivers"]]
        ax.scatter(xs, ys, s=3, color=SERIES[0], label=f"sinks ({len(xs)})", linewidths=0)
        ax.scatter(bx, by, s=14, color=SERIES[1], label=f"clock drivers / buffers ({len(bx)})", edgecolors=PANEL, linewidths=0.6)
        ax.set_aspect("equal")
        ax.set_xlabel("x (µm)")
        ax.set_ylabel("y (µm)")
        ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=INK, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.1), ncol=2)
        imgs["clock_tree"] = _png(fig, out / "clock_tree.png")
    return imgs


def _table_html(rows: list[dict], cols: list[str]) -> str:
    h = "<table><thead><tr>" + "".join(f"<th>{c}</th>" for c in cols) + "</tr></thead><tbody>"
    for r in rows:
        tds = []
        for c in cols:
            v = r.get(c, "")
            if isinstance(v, float):
                v = f"{v:.3f}"
            if c == "status" and v in STATUS:
                v = f'<span class="st" style="color:{STATUS[v]}">{ICON.get(v, "")} {v}</span>'
            tds.append(f"<td>{v if v is not None else '—'}</td>")
        h += "<tr>" + "".join(tds) + "</tr>"
    return h + "</tbody></table>"


def write(run_dir: Path, out: Path | None = None) -> dict:
    run = load_run(run_dir)
    parts = run_dir.parts
    out = out or (REPORTS_DIR / parts[-3] / parts[-2] / parts[-1])
    out.mkdir(parents=True, exist_ok=True)
    rows = scene_rows(run["stages"])
    # JSON (complete)
    (out / "timing_report.json").write_text(json.dumps(run, indent=1, default=str))
    # CSV per scene
    cols = sorted({k for r in rows for k in r}, key=lambda k: (k not in ("stage", "label", "status", "scene", "mode", "corner"), k))
    with open(out / "timing_scenes.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    # CSV top paths
    with open(out / "critical_paths.csv", "w", newline="") as f:
        fields = ["stage", "scene", "kind", "rank", "slack_ns", "arrival_ns", "required_ns", "group", "startpoint", "endpoint",
                  "launch_clock", "capture_clock", "owner_block", "start_block", "end_block", "cell_delay_ns",
                  "net_delay_ns", "logic_depth", "max_fanout", "max_slew_ns", "dominance"]
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for st, sm in run["stages"].items():
            if not sm or sm.get("status") != "PASS":
                continue
            for sc, v in sm["scenes"].items():
                for kind in ("top_setup_paths", "top_hold_paths", "top_reg2reg_paths"):
                    for p in v[kind]:
                        w.writerow(dict(p, stage=st, scene=sc, kind=kind))
    # audit CSV
    if run["audit"]:
        with open(out / "constraint_audit.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["id", "status", "title", "evidence", "details"])
            for c in run["audit"]["checks"]:
                w.writerow([c["id"], c["status"], c["title"], c["evidence"], " | ".join(c["details"][:20])])
    imgs = charts(run, out)
    # TXT
    L = [f"SilicaFlux TimingFlow report — {parts[-3]} / {parts[-2]} / run '{parts[-1]}'", "=" * 78]
    for st, sm in run["stages"].items():
        if not sm:
            L.append(f"{st.upper():14s} NOT RUN")
            continue
        L.append(f"{sm['label']:20s} status {sm['status']}  parasitics: {sm.get('parasitics', '')}  clocks: {sm.get('clocks_mode', '')}")
        if sm.get("status") != "PASS":
            L.append(f"    reason: {sm.get('reason', '')[:300]}")
            continue
        for sc, v in sm["scenes"].items():
            L.append(f"   {sc:12s} WNS {v['wns_ns']:>10.3f}  TNS {v['tns_ns']:>12.3f}  WHS {v['whs_ns']:>8.3f}  THS {v['ths_ns']:>9.3f} ns | "
                     f"reg2reg WNS {v['reg2reg']['setup_wns_ns']} ns | viol setup {v['setup_all']['violators']} hold {v['hold_all']['violators']} | "
                     f"slew {v['drv'].get('max_slew', {}).get('violators')} cap {v['drv'].get('max_capacitance', {}).get('violators')}")
        w = sm["worst"]
        for k in ("setup", "r2r_setup", "hold"):
            if w.get(k) and w[k].get("path"):
                p = w[k]["path"]
                L.append(f"   worst {k:9s}: {p['slack_ns']:+.3f} ns [{w[k]['scene']}] {p['startpoint']} -> {p['endpoint']} "
                         f"(group {p['group']}, owner {p['owner_block']}, {p['dominance']})")
    if run["audit"]:
        L.append("")
        L.append(f"Constraint audit: {run['audit']['overall']}  {run['audit']['counts']}")
        for c in run["audit"]["checks"]:
            L.append(f"  {c['id']} {c['status']:14s} {c['title']}")
    if run["gates"]:
        L.append("")
        L.append(f"Signoff gates: {run['gates']['signoff']}")
        for gg in run["gates"]["gates"]:
            L.append(f"  G{gg['gate']:<2d} {gg['status']:9s} {gg['title']} — {gg['evidence'][:110]}")
    prov = next((sm.get("provenance") for sm in run["stages"].values() if sm and sm.get("provenance")), None)
    if prov:
        L.append("")
        L.append("Provenance: " + json.dumps({k: prov[k] for k in ("design_revision", "config_digest", "constraint_revision",
                                                                    "netlist_sha256_16")}, default=str))
        L.append("Tools: " + json.dumps({k: v for k, v in prov["tools"].items() if k != "pinned"}))
    (out / "timing_report.txt").write_text("\n".join(L) + "\n")
    # HTML
    css = f"""body{{background:{NAVY};color:{INK};font:14px/1.45 'IBM Plex Sans',system-ui,sans-serif;margin:24px}}
h1,h2{{font-family:'IBM Plex Sans',system-ui;letter-spacing:.02em}}h1{{color:#d4b25a}}h2{{color:{SERIES[0]};border-bottom:1px solid {GRID};padding-bottom:4px}}
table{{border-collapse:collapse;font:12px 'IBM Plex Mono',ui-monospace,monospace;margin:8px 0}}td,th{{border:1px solid {GRID};padding:3px 6px;text-align:left}}
th{{background:{PANEL};color:{INK2}}}.st{{font-weight:600}}img{{max-width:100%;border:1px solid {GRID};margin:6px 0}}
.note{{color:{INK2};font-size:12px}}"""
    H = [f"<!doctype html><html><head><meta charset='utf-8'><title>TimingFlow report</title><style>{css}</style></head><body>",
         f"<h1>SilicaFlux TimingFlow — {parts[-3]} / {parts[-2]} / {parts[-1]}</h1>",
         "<p class='note'>Every value is read from OpenSTA/OpenROAD output of this run. Units: ns, pF, µm², W. "
         "Stages that did not execute are NOT RUN. Post-synthesis and post-placement results are estimates, not signoff.</p>"]
    H.append("<h2>Per-stage, per-scene timing</h2>")
    H.append(_table_html(rows, ["label", "status", "scene", "parasitics", "clocks", "wns_ns", "tns_ns", "whs_ns", "ths_ns",
                                "reg2reg_setup_wns_ns", "reg2reg_fmax_derived_mhz", "recovery_wns_ns", "setup_violators",
                                "hold_violators", "max_slew_violators", "max_cap_violators", "pulse_width_violators"]))
    for k, title in (("slack_by_group", "Worst slack by path group"), ("endpoint_hist", "Endpoint slack distribution"),
                     ("path_breakdown", "Critical path delay composition"), ("block_violators", "Bottlenecks by block"),
                     ("clock_tree", "Clock tree (CTS database geometry)")):
        if k in imgs:
            H.append(f"<h2>{title}</h2><img alt='{title}' src='data:image/png;base64,{imgs[k]}'>")
    if run["audit"]:
        H.append(f"<h2>Constraint audit — {run['audit']['overall']}</h2>")
        H.append(_table_html([dict(c, details="; ".join(c["details"][:6])) for c in run["audit"]["checks"]],
                             ["id", "status", "title", "evidence", "details"]))
    if run["impact"]:
        H.append("<h2>Exception impact</h2>")
        H.append(_table_html([dict(r, notes="; ".join(r["notes"]), endpoint_kinds=json.dumps(r.get("endpoint_kinds")))
                              for r in run["impact"]], ["id", "type", "approval", "verdict", "endpoints_covered",
                                                        "endpoint_kinds", "notes"]))
    if run["gates"]:
        H.append(f"<h2>Signoff gates — {run['gates']['signoff']}</h2>")
        H.append(_table_html(run["gates"]["gates"], ["gate", "status", "title", "evidence"]))
    if prov:
        H.append("<h2>Provenance</h2><pre>" + json.dumps({k: v for k, v in prov.items() if k != "tools"}, indent=1, default=str)
                 + "\n" + json.dumps({k: v for k, v in prov["tools"].items() if k != "pinned"}, indent=1) + "</pre>")
    H.append("</body></html>")
    (out / "timing_report.html").write_text("\n".join(H))
    return {"out": str(out), "files": sorted(p.name for p in out.iterdir())}
