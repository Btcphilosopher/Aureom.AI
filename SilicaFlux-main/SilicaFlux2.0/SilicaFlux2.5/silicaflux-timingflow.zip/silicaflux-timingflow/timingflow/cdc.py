"""Clock-domain / reset-domain analysis from real netlist + STA data.

Static timing does not prove CDC correctness.  This module only *exposes*
crossings and checks their structure; every result that cannot be proven
structurally is marked REVIEW REQUIRED, never PASS.

Structural rules for a crossing endpoint register R (captures data from
another clock domain):
  * SYNC_2FF          — the launch register drives R with no logic between
                        them (buffers/inverters allowed) AND R's output drives
                        exactly one register in the same clock domain (second
                        stage) and nothing else.
  * LOGIC_BEFORE_SYNC — combinational logic between domains (glitch hazard): FAIL
  * QUASI_STATIC_DATA — R is not a synchroniser stage; data from another domain is
                        consumed directly.  Acceptable only for quasi-static data
                        protected by a handshake: REVIEW REQUIRED with evidence.
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path

from .parse_reports import parse_ends, parse_paths_json, read_json


def _bus(name: str) -> str:
    return re.sub(r"\[\d+\]", "[*]", name)


def _inst(pin: str) -> str:
    return pin.rsplit("/", 1)[0]


def classify_crossing(path: dict, loads: dict) -> dict:
    pts = path.get("points", [])
    # cells between the launch register output and the capture pin
    mids = []
    for p in pts[1:-1]:
        if p.get("arc") == "cell":
            mids.append(p.get("cell", ""))
    # first cell arc is the launch register clk->Q; remaining are logic
    logic = mids[1:] if mids else []
    lib_bufinv = [c for c in logic if re.search(r"(buf|inv|clkbuf|dlygate)", c)]
    has_logic = len(logic) > len(lib_bufinv)
    end_inst = _inst(path["endpoint"])
    ld = loads.get(end_inst, [])
    regs = [l for l in ld if l.get("is_register")]
    second_stage = (len(ld) == 1 and len(regs) == 1 and regs[0]["pin"].endswith("/D")
                    and path.get("capture_clock") in regs[0].get("clocks", []))
    if path["endpoint"].count("/") == 0 or path.get("endpoint_is_port"):
        cls = "IO_PORT"
    elif second_stage and has_logic:
        cls = "LOGIC_BEFORE_SYNC"          # glitch can reach a synchroniser first stage
    elif second_stage:
        cls = "SYNC_2FF"
    else:
        cls = "QUASI_STATIC_DATA"          # consumed directly: needs handshake / stability evidence
    return {"endpoint": path["endpoint"], "startpoint": path["startpoint"],
            "launch_clock": path.get("launch_clock"), "capture_clock": path.get("capture_clock"),
            "logic_cells": logic, "class": cls, "second_stage_loads": len(ld),
            "start_bus": _bus(path["startpoint"]), "end_bus": _bus(end_inst)}


def analyze(outdir: Path, clock_relations: dict[tuple[str, str], str]) -> dict:
    loads = read_json(outdir / "cdc_endpoint_loads.json", {}) or {}
    pairs = []
    all_rows = []
    for f in sorted(outdir.glob("cdc_*__*.json")):
        a, b = f.stem[4:].split("__")
        paths = parse_paths_json(f)
        rows = [classify_crossing(p, loads) for p in paths]
        all_rows += rows
        counts = defaultdict(int)
        for r in rows:
            counts[r["class"]] += 1
        multibit = defaultdict(set)
        for r in rows:
            if r["class"] in ("QUASI_STATIC_DATA", "LOGIC_BEFORE_SYNC"):
                multibit[(r["start_bus"], r["end_bus"])].add(r["endpoint"])
        rel = clock_relations.get((a, b), "unknown (timed as synchronous)")
        if "synchronous related" in rel:
            status = "SYNCHRONOUS (timed by STA, not a CDC)" if rows else "NOT APPLICABLE"
        else:
            status = ("NOT APPLICABLE" if not rows else
                      "FAIL" if counts.get("LOGIC_BEFORE_SYNC") else
                      "REVIEW REQUIRED" if counts.get("QUASI_STATIC_DATA") else "PASS (structural)")
            if rows and not rel.startswith("asynchronous"):
                status = "FAIL (crossing between clocks with no declared relationship)"
        pairs.append({"from": a, "to": b, "relationship": rel, "crossings": len(rows),
                      "by_class": dict(counts), "status": status,
                      "multibit_groups": [{"from": k[0], "to": k[1], "endpoints": len(v)}
                                          for k, v in sorted(multibit.items(), key=lambda kv: -len(kv[1]))][:40],
                      "examples": rows[:25]})
    async_in = []
    for f in sorted(outdir.glob("cdc_async_in_*.json")):
        paths = parse_paths_json(f)
        rows = []
        for p in paths:
            p.setdefault("capture_clock", None)
            r = classify_crossing(p, loads)
            # for async ports the second stage must be clocked by the first stage's clock
            end_inst = _inst(p["endpoint"])
            ld = loads.get(end_inst, [])
            regs = [l for l in ld if l.get("is_register")]
            if not r["logic_cells"] and len(ld) == 1 and len(regs) == 1 and regs[0]["pin"].endswith("/D"):
                r["class"] = "SYNC_2FF"
            rows.append(r)
        cls = defaultdict(int)
        for r in rows:
            cls[r["class"]] += 1
        async_in.append({"port_report": f.stem[13:], "first_registers": len(rows), "by_class": dict(cls),
                         "status": ("NOT APPLICABLE" if not rows else "FAIL" if cls.get("LOGIC_BEFORE_SYNC")
                                    else "REVIEW REQUIRED" if cls.get("QUASI_STATIC_DATA") else "PASS (structural)"),
                         "examples": rows[:10]})
    # RDC
    rdc_paths = parse_paths_json(outdir / "rdc_async.json") if (outdir / "rdc_async.json").exists() else []
    rdc = defaultdict(lambda: {"endpoints": 0, "worst_slack_ns": None, "launch_clock": None, "capture_clocks": set()})
    for p in rdc_paths:
        key = p["startpoint"]
        d = rdc[key]
        d["endpoints"] += 1
        d["launch_clock"] = p.get("launch_clock")
        d["capture_clocks"].add(p.get("capture_clock"))
        if d["worst_slack_ns"] is None or p["slack_ns"] < d["worst_slack_ns"]:
            d["worst_slack_ns"] = p["slack_ns"]
    rdc_rows = []
    for k, v in rdc.items():
        caps = sorted(c for c in v["capture_clocks"] if c)
        same = v["launch_clock"] in caps and len(caps) == 1
        rdc_rows.append({"reset_source": k, "launch_clock": v["launch_clock"], "capture_clocks": caps,
                         "endpoints": v["endpoints"], "worst_recovery_slack_ns": v["worst_slack_ns"],
                         "release": "synchronous to capture clock" if same else "CROSSES DOMAINS / async source: review"})
    unc = parse_ends(outdir / "rdc_async_unconstrained.rpt") if (outdir / "rdc_async_unconstrained.rpt").exists() else []
    overall = "FAIL" if any(p["status"].startswith("FAIL") for p in pairs + async_in) else \
              "REVIEW REQUIRED" if any(p["status"] == "REVIEW REQUIRED" for p in pairs + async_in) or \
              any("review" in r["release"] for r in rdc_rows) else "PASS (structural)"
    res = {"status": overall,
           "disclaimer": "Structural checks on the synthesized netlist. STA does not establish CDC/RDC correctness; "
                         "REVIEW REQUIRED items need protocol/formal/simulation evidence before any exception is approved.",
           "clock_pairs": pairs, "async_inputs": async_in,
           "rdc": sorted(rdc_rows, key=lambda r: -r["endpoints"]),
           "rdc_unconstrained_endpoints": len([r for r in unc])}
    (outdir / "cdc.json").write_text(json.dumps(res, indent=1, default=list))
    return res
