"""Flow orchestration with explicit stage prerequisites.

Stage order and prerequisites (a stage refuses to run on the wrong database):
  synth         RTL                              -> synth/netlist.v
  synthesis     synth/netlist.v                  -> sta_synthesis/   (STAGE A, OpenSTA)
  check_sdc     netlist + generated SDC          -> constraint_analysis/, constraint_audit.json
  placement     synth/netlist.v + OpenROAD       -> pnr/2_place.odb, sta_placement/
  cts           pnr/2_place.odb                  -> pnr/3_cts.odb, sta_cts/
  global_route  pnr/3_cts.odb                    -> pnr/4_grt.odb, sta_global_route/
  postroute     pnr/4_grt.odb + detailed route + extraction -> pnr/5_route.odb + SPEF, sta_postroute/
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from . import constraints, physical, sta, summary, synth
from .config import load_design, load_platform
from .paths import RUNS_DIR

STAGES = ["synth", "synthesis", "check_sdc", "placement", "cts", "global_route", "postroute"]


def run_dir_for(design: str, platform: str, run: str = "baseline") -> Path:
    return (RUNS_DIR / design / platform / run).resolve()


def manifest_update(run_dir: Path, stage: str, result: dict) -> dict:
    mf = run_dir / "manifest.json"
    m = json.loads(mf.read_text()) if mf.exists() else {"stages": {}}
    m["stages"][stage] = {k: v for k, v in result.items() if k in
                          ("status", "reason", "runtime_s", "label", "returncode", "outdir", "corners", "modes")}
    m["stages"][stage]["finished"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    run_dir.mkdir(parents=True, exist_ok=True)
    mf.write_text(json.dumps(m, indent=1))
    return m


def run_stage(design_name: str, platform_name: str, stage: str, run: str = "baseline",
              period_ns: float | None = None, params: dict | None = None, corners: list[str] | None = None,
              parasitics: str = "none", threads: int = 4, phys_opts: dict | None = None) -> dict:
    design = load_design(design_name)
    platform = load_platform(platform_name)
    if design.status == "NOT_FOUND":
        return {"status": "NOT RUN", "reason": f"{design_name}: {design.status_evidence}"}
    if platform.status != "AVAILABLE":
        return {"status": "NOT RUN", "reason": f"platform {platform_name} not available"}
    rd = run_dir_for(design_name, platform_name, run)
    rd.mkdir(parents=True, exist_ok=True)
    if period_ns is not None:
        design.clocks[0].period_ns = period_ns
        design.clocks[0].period_source = f"CLI override for run '{run}' (sensitivity / experiment)"
    per = design.clocks[0].period_ns
    if stage == "synth":
        res = synth.run(design, platform, rd / "synth", per, params)
    elif stage == "synthesis":
        res = sta.run_stage_a(design, platform, rd, corners, None, parasitics, threads)
        if res.get("status") == "PASS":
            tag = "sta_synthesis" if parasitics == "none" else f"sta_synthesis_{parasitics.replace(':', '_')}"
            summary.summarize_stage(design, platform, rd, "synthesis", tag)
    elif stage == "check_sdc":
        a = constraints.run_analysis(design, platform, rd, threads=threads)
        au = constraints.audit(design, platform, rd, analysis=a if a.get("status") == "PASS" else None)
        res = {"status": "PASS" if a.get("status") == "PASS" else a.get("status", "FAIL"),
               "audit_overall": au["overall"], "counts": au["counts"], "runtime_s": a.get("runtime_s")}
    elif stage in ("placement", "cts", "global_route", "postroute"):
        res = physical.run_stage(design, platform, rd, stage, corners=corners, threads=threads, opts=phys_opts or {})
        if res.get("status") == "PASS":
            summary.summarize_stage(design, platform, rd, stage, f"sta_{stage}")
    else:
        raise ValueError(f"unknown stage {stage}; choose from {STAGES}")
    manifest_update(rd, stage, res)
    return res
