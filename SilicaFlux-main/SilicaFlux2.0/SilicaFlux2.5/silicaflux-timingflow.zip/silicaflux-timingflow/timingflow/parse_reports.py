"""Parsers for OpenSTA / OpenROAD timing reports.

Every parser takes the text (or path) of a report actually produced by the
tools and returns plain Python data.  Units: ns and pF (the Liberty units of
the analysed libraries); OpenSTA's JSON format uses SI seconds/farads, which
are converted here.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

NUM = r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?"


def _txt(x: str | Path) -> str:
    if isinstance(x, Path) or (isinstance(x, str) and "\n" not in x and len(x) < 4096 and Path(x).exists()):
        return Path(x).read_text(errors="replace")
    return x


# --------------------------------------------------------------------------- check_setup
_CS_KINDS = [
    ("input_no_delay", r"input ports? missing set_input_delay"),
    ("output_no_delay", r"output ports? missing set_output_delay"),
    ("unconstrained_endpoints", r"unconstrained endpoints?"),
    ("no_clock", r"(register/latch pins?|pins?) with no clock"),
    ("multiple_clock", r"multiple clocks"),
    ("loops", r"combinational loops?"),
    ("generated_clocks", r"generated clocks?"),
]


def parse_check_setup(text: str | Path) -> dict:
    text = _txt(text)
    out: dict[str, dict] = {}
    cur = None
    for line in text.splitlines():
        m = re.match(r"^Warning: There (?:is|are) (\d+) (.*?)\.?$", line)
        if m:
            n, what = int(m.group(1)), m.group(2)
            kind = next((k for k, pat in _CS_KINDS if re.search(pat, what)), "other:" + what)
            out[kind] = {"count": n, "message": line.strip(), "items": []}
            cur = kind
            continue
        if line.startswith("Warning:"):
            kind = "other:" + line[9:].strip()
            out[kind] = {"count": 1, "message": line.strip(), "items": []}
            cur = kind
            continue
        if cur and line.startswith(" ") and line.strip():
            out[cur]["items"].append(line.strip())
    return out


# --------------------------------------------------------------------------- endpoint lists
_END_HDR = re.compile(r"^(max_delay/setup|min_delay/hold) group (.+?)\s*$")
_END_ROW = re.compile(rf"^(\S+)(?: \(([^)]*)\))?\s+({NUM}|INF|-INF)\s+({NUM}|INF|-INF)\s+({NUM}|INF|-INF) \((MET|VIOLATED)\)\s*$")


def _f(v: str) -> float:
    return float("inf") if v == "INF" else float("-inf") if v == "-INF" else float(v)


def parse_ends(text: str | Path) -> list[dict]:
    """report_checks -format end -> one row per endpoint and path group."""
    text = _txt(text)
    rows: list[dict] = []
    check = group = None
    for line in text.splitlines():
        h = _END_HDR.match(line)
        if h:
            check = "setup" if h.group(1).startswith("max") else "hold"
            group = h.group(2)
            continue
        m = _END_ROW.match(line)
        if m and group is not None:
            rows.append({"check": check, "group": group, "endpoint": m.group(1), "ref": m.group(2) or "",
                         "required_ns": _f(m.group(3)), "arrival_ns": _f(m.group(4)),
                         "slack_ns": _f(m.group(5)), "violated": m.group(6) == "VIOLATED"})
    return rows


def group_stats(rows: list[dict]) -> dict:
    """Per (check, path group): worst slack, TNS, violator count, endpoints."""
    out: dict[str, dict] = {}
    for r in rows:
        key = f"{r['check']}:{r['group']}"
        g = out.setdefault(key, {"check": r["check"], "group": r["group"], "endpoints": 0,
                                 "violators": 0, "wns_ns": None, "tns_ns": 0.0, "worst_endpoint": None})
        g["endpoints"] += 1
        if r["violated"]:
            g["violators"] += 1
            g["tns_ns"] += r["slack_ns"]
        if g["wns_ns"] is None or r["slack_ns"] < g["wns_ns"]:
            g["wns_ns"] = r["slack_ns"]
            g["worst_endpoint"] = r["endpoint"]
    for g in out.values():
        g["tns_ns"] = round(g["tns_ns"], 4)
    return out


# --------------------------------------------------------------------------- DRV / pulse / async
_DRV_SECTION = re.compile(r"^(max slew|max capacitance|max fanout|min slew|min capacitance|min fanout)\s*$")
_DRV_ROW = re.compile(rf"^(\S+)\s+({NUM})\s+({NUM})\s+({NUM}) \((VIOLATED|MET)\)\s*$")


def parse_drv(text: str | Path, top: int = 50) -> dict:
    text = _txt(text)
    out: dict[str, dict] = {}
    sec = None
    for line in text.splitlines():
        s = _DRV_SECTION.match(line.strip())
        if s:
            sec = s.group(1).replace(" ", "_")
            out.setdefault(sec, {"violators": 0, "worst_slack": None, "items": []})
            continue
        m = _DRV_ROW.match(line)
        if m and sec:
            d = out[sec]
            slack = float(m.group(4))
            if m.group(5) == "VIOLATED":
                d["violators"] += 1
            if d["worst_slack"] is None or slack < d["worst_slack"]:
                d["worst_slack"] = slack
            if len(d["items"]) < top:
                d["items"].append({"pin": m.group(1), "limit": float(m.group(2)),
                                   "actual": float(m.group(3)), "slack": slack})
    return out


_PW_ROW = re.compile(rf"^(\S+) \((high|low)\)\s+({NUM})\s+({NUM})\s+({NUM}) \((VIOLATED|MET)\)\s*$")


def parse_pulse(text: str | Path, top: int = 50) -> dict:
    text = _txt(text)
    items, viol, worst = [], 0, None
    for line in text.splitlines():
        m = _PW_ROW.match(line)
        if m:
            slack = float(m.group(5))
            viol += m.group(6) == "VIOLATED"
            worst = slack if worst is None or slack < worst else worst
            if len(items) < top:
                items.append({"pin": m.group(1), "phase": m.group(2), "required_ns": float(m.group(3)),
                              "actual_ns": float(m.group(4)), "slack_ns": slack})
    return {"violators": viol, "worst_slack_ns": worst, "items": items}


def parse_slack_only(text: str | Path) -> list[dict]:
    text = _txt(text)
    rows = []
    for line in text.splitlines():
        m = re.match(rf"^(\S(?:.*\S)?)\s+({NUM})\s*$", line)
        if m and not line.startswith(("Group", "---")):
            rows.append({"group": m.group(1), "slack_ns": float(m.group(2))})
    return rows


# --------------------------------------------------------------------------- clock skew / latency
def parse_skew(text: str | Path) -> dict:
    text = _txt(text)
    out: dict[str, dict] = {}
    for blk in re.split(r"^Clock ", text, flags=re.M)[1:]:
        lines = blk.splitlines()
        clk = lines[0].strip()
        d = {"found": "No launch/capture paths found" not in blk}
        for l in lines[1:]:
            m = re.match(rf"^\s*({NUM}) (source latency|target latency|clock uncertainty|CRPR|setup skew|hold skew)(.*)$", l)
            if m:
                d[m.group(2).replace(" ", "_")] = float(m.group(1))
                if "latency" in m.group(2):
                    d[m.group(2).replace(" ", "_") + "_pin"] = m.group(3).strip()
        out[clk] = d
    return out


def parse_latency(text: str | Path) -> dict:
    text = _txt(text)
    out: dict[str, dict] = {}
    for blk in re.split(r"^Clock ", text, flags=re.M)[1:]:
        lines = blk.splitlines()
        clk = lines[0].strip()
        d = {}
        for l in lines:
            m = re.match(rf"^\s*({NUM})\s+({NUM}) latency\s*$", l)
            if m and "min_ns" not in d:
                d["min_ns"], d["max_ns"] = float(m.group(1)), float(m.group(2))
            m = re.match(rf"^\s*({NUM}) skew\s*$", l)
            if m and "skew_ns" not in d:
                d["skew_ns"] = float(m.group(1))
        out[clk] = d
    return out


def parse_power(text: str | Path) -> dict:
    text = _txt(text)
    out = {"groups": {}, "warnings": re.findall(r"^Warning.*$", text, re.M)}
    for line in text.splitlines():
        m = re.match(rf"^(Sequential|Combinational|Clock|Macro|Pad|Total)\s+({NUM})\s+({NUM})\s+({NUM})\s+({NUM})", line)
        if m:
            out["groups"][m.group(1)] = {"internal_w": float(m.group(2)), "switching_w": float(m.group(3)),
                                         "leakage_w": float(m.group(4)), "total_w": float(m.group(5))}
    return out


# --------------------------------------------------------------------------- paths
def _pt(p: dict) -> dict:
    d = {"pin": p.get("pin", ""), "instance": p.get("instance", ""), "cell": p.get("cell", ""),
         "net": p.get("net"), "arrival_ns": p["arrival"] * 1e9 if p.get("arrival") is not None else None,
         "slew_ns": p["slew"] * 1e9 if p.get("slew") is not None else None,
         "cap_pf": p["capacitance"] * 1e12 if p.get("capacitance") is not None else None,
         "src": p.get("verilog_src", "")}
    return d


def annotate_increments(points: list[dict]) -> list[dict]:
    """Mark each step as a cell arc (same instance) or a net arc (instance change)."""
    prev = None
    for p in points:
        if prev is None or p["arrival_ns"] is None or prev["arrival_ns"] is None:
            p["incr_ns"], p["arc"] = 0.0, "start"
        else:
            p["incr_ns"] = p["arrival_ns"] - prev["arrival_ns"]
            same = p["instance"] and p["instance"] == prev["instance"]
            p["arc"] = "cell" if same else "net"
        prev = p
    return points


def parse_paths_json(path: str | Path) -> list[dict]:
    text = Path(path).read_text(errors="replace")
    if not text.strip():
        return []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # OpenSTA writes '{"checks": [' even when no paths exist
        return []
    out = []
    for c in data.get("checks", []):
        src = annotate_increments([_pt(p) for p in c.get("source_path", [])])
        tgt = [_pt(p) for p in c.get("target_clock_path", []) or []]
        cell = sum(p["incr_ns"] for p in src if p["arc"] == "cell")
        net = sum(p["incr_ns"] for p in src if p["arc"] == "net")
        # launch clock latency = arrival at the startpoint clock pin (first point if register)
        launch_lat = src[0]["arrival_ns"] if src and src[0]["pin"].endswith(("/CLK", "/CK", "/A_CLK")) else None
        capture_lat = tgt[-1]["arrival_ns"] if tgt else None
        e = {
            "type": c.get("type"), "group": c.get("path_group"), "path_type": c.get("path_type"),
            "check": "setup" if c.get("path_type") == "max" else "hold",
            "startpoint": c.get("startpoint"), "endpoint": c.get("endpoint"),
            "launch_clock": c.get("source_clock"), "launch_edge": c.get("source_clock_edge"),
            "capture_clock": c.get("target_clock"), "capture_edge": c.get("target_clock_edge"),
            "arrival_ns": (c.get("data_arrival_time") or 0) * 1e9,
            "required_ns": (c.get("required_time") or 0) * 1e9,
            "slack_ns": (c.get("slack") or 0) * 1e9,
            "crpr_ns": (c.get("crpr") or 0) * 1e9,
            "margin_ns": (c.get("margin") or 0) * 1e9,
            "launch_clock_arrival_ns": launch_lat, "capture_clock_arrival_ns": capture_lat,
            "cell_delay_ns": round(cell, 6), "net_delay_ns": round(net, 6),
            "logic_depth": sum(1 for p in src if p["arc"] == "cell"),
            "points": src,
        }
        out.append(e)
    return out


def parse_paths_text(text: str | Path) -> list[dict]:
    """Full-format report_checks text with -fields (Fanout Cap Slew Delay Time)."""
    text = _txt(text)
    paths = []
    for blk in re.split(r"^Startpoint: ", text, flags=re.M)[1:]:
        lines = blk.splitlines()
        p = {"startpoint": lines[0].split(" (")[0].strip(), "points": []}
        for l in lines:
            for key, pat in (("endpoint", r"^Endpoint: (\S+)"), ("group", r"^Path Group: (.+)"),
                             ("path_type", r"^Path Type: (\S+)"), ("mode", r"^Mode: (\S+)"),
                             ("corner", r"^Corner: (\S+)")):
                m = re.match(pat, l)
                if m:
                    p[key] = m.group(1).strip()
        hdr_i = next((i for i, l in enumerate(lines) if l.lstrip().startswith("Fanout") or
                      re.match(r"^\s*(Cap|Slew|Delay)\s", l)), None)
        if hdr_i is None:
            continue
        hdr = lines[hdr_i]
        cols = [(m.group(0), m.end()) for m in re.finditer(r"\S+", hdr)]
        names = [c[0] for c in cols]
        ends = [c[1] for c in cols]
        desc_start = hdr.find("Description")
        for l in lines[hdr_i + 2:]:
            if l.startswith("---") or "data arrival time" in l:
                break
            m = re.search(r" ([\^v]) (\S+) \(([^)]+)\)\s*$", l)
            if not m:
                continue
            vals = {}
            start = 0
            for name, end in zip(names, ends):
                if name == "Description":
                    break
                seg = l[start:end].strip()
                start = end
                if seg:
                    try:
                        vals[name.lower()] = float(seg)
                    except ValueError:
                        pass
            p["points"].append({"pin": m.group(2), "cell": m.group(3), "edge": "rise" if m.group(1) == "^" else "fall",
                                "fanout": int(vals["fanout"]) if "fanout" in vals else None,
                                "cap_pf": vals.get("cap"), "slew_ns": vals.get("slew"),
                                "incr_ns": vals.get("delay"), "arrival_ns": vals.get("time")})
        sm = re.search(rf"^\s*({NUM})\s+slack \((MET|VIOLATED)\)", blk, re.M)
        if sm:
            p["slack_ns"] = float(sm.group(1))
        paths.append(p)
    return paths


def merge_fanout(json_paths: list[dict], text_paths: list[dict]) -> None:
    """Copy fanout from the text report onto JSON path points.  Fanout is a
    property of the driver pin, so the index is the pin name alone."""
    idx = {}
    for tp in text_paths:
        for pt in tp["points"]:
            if pt.get("fanout") is not None:
                idx[pt["pin"]] = pt["fanout"]
    for jp in json_paths:
        for pt in jp["points"]:
            f = idx.get(pt["pin"])
            if f is not None:
                pt["fanout"] = f


def read_json(path: Path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except Exception:
        return default
