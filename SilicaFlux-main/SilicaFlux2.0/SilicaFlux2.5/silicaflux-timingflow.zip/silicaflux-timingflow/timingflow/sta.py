"""OpenSTA / OpenROAD drivers: SDC generation, run_vars.tcl, tool invocation."""
from __future__ import annotations

import json
import shutil
import subprocess
import time
from pathlib import Path

from . import sdc_gen
from .config import DesignConfig, Platform, load_exceptions, load_io
from .paths import TCL_DIR, env

STAGE_LABEL = {
    "synthesis": "POST-SYNTHESIS",
    "placement": "POST-PLACEMENT",
    "cts": "POST-CTS",
    "global_route": "POST-GLOBAL-ROUTE",
    "postroute": "POST-ROUTE",
}


def _tcl_list(items) -> str:
    return "{" + " ".join("{" + str(i) + "}" for i in items) + "}"


def active_modes(design: DesignConfig, modes: list[str] | None = None):
    out = [m for m in design.modes if m.status == "DEFINED"]
    if modes:
        out = [m for m in out if m.name in modes]
    return out


def write_sdcs(design: DesignConfig, platform: Platform, stage: str, corners: list[str],
               netlist: Path, outdir: Path, modes: list[str] | None = None) -> dict:
    io = load_io(design)
    exc = load_exceptions(design)
    ports = sdc_gen.netlist_top_ports(netlist, design.top) if netlist and netlist.exists() else {}
    outdir.mkdir(parents=True, exist_ok=True)
    meta = {"stage": stage, "stage_class": sdc_gen.stage_class(stage), "modes": {},
            "n_top_ports": len(ports)}
    for m in active_modes(design, modes):
        r = sdc_gen.generate(design, platform, m, stage, io, exc, corners, ports)
        p = outdir / f"{m.name}_{r.stage_class}.sdc"
        p.write_text(r.text)
        meta["modes"][m.name] = {"sdc": str(p), "clocks": r.clocks, "applied_exceptions": r.applied_exceptions,
                                 "skipped_exceptions": r.skipped_exceptions, "io_groups": r.io_groups,
                                 "uncovered_ports": r.uncovered_ports, "load_pf": r.load_pf,
                                 "notes": r.notes}
    (outdir / "sdc_meta.json").write_text(json.dumps(meta, indent=1))
    return meta


def corner_libs(platform: Platform, design: DesignConfig, corner: str) -> list[Path]:
    s = platform.liberty_set(corner, design.macros.get(platform.name, []))
    return s["stdcell"] + s["io"] + s["macro"]


def write_run_vars(path: Path, *, design: DesignConfig, platform: Platform, stage: str,
                   corners: list[str], sdc_meta: dict, outdir: Path, netlist: Path | None = None,
                   odb: Path | None = None, lef_files: list[Path] | None = None,
                   parasitics: str = "none", spef: dict | None = None,
                   path_count: int = 200, text_path_count: int = 10, end_count: int = 100000,
                   power_scene: str | None = None, power_activity: float = 0.1,
                   extra: dict | None = None, extra_scripts: list[Path] | None = None) -> None:
    modes = list(sdc_meta["modes"].keys())
    scenes = [f"{m}_{c}" for m in modes for c in corners]
    L = [f"# TimingFlow run variables — {design.name} / {platform.name} / {stage}",
         f"set tf(design) {design.name}", f"set tf(top) {design.top}",
         f"set tf(stage) {stage}", f"set tf(stage_label) {STAGE_LABEL[stage]}",
         f"set tf(platform) {platform.name}",
         f"set tf(outdir) {{{outdir}}}", f"set tf(corners) {_tcl_list(corners)}",
         f"set tf(modes) {_tcl_list(modes)}", f"set tf(scenes) {_tcl_list(scenes)}",
         f"set tf(parasitics) {parasitics}", f"set tf(path_count) {path_count}",
         f"set tf(text_path_count) {text_path_count}", f"set tf(end_count) {end_count}",
         f"set tf(power_scene) {{{power_scene or ''}}}",
         f"set tf(power_input_activity) {power_activity}"]
    for c in corners:
        L.append(f"set tf(lib,{c}) {_tcl_list(corner_libs(platform, design, c))}")
    L.append(f"set tf(macros) {_tcl_list(design.macros.get(platform.name, []))}")
    insts = sorted({e.prefix.rstrip("/") for e in design.block_map
                    if e.prefix.endswith("/") and e.prefix.count("/") == 1 and e.prefix.rstrip("/")})
    L.append(f"set tf(through_insts) {_tcl_list(insts)}")
    for m in modes:
        L.append(f"set tf(sdc,{m}) {{{sdc_meta['modes'][m]['sdc']}}}")
    for m in modes:
        for c in corners:
            L.append(f"set tf(scene,{m}_{c}) {{{m} {c}}}")
    if netlist:
        L.append(f"set tf(netlist) {{{netlist}}}")
    if odb:
        L.append(f"set tf(odb) {{{odb}}}")
    if lef_files is not None:
        L.append(f"set tf(lef_files) {_tcl_list(lef_files)}")
    for c, f in (spef or {}).items():
        L.append(f"set tf(spef,{c}) {{{f}}}")
    for k, v in (extra or {}).items():
        L.append(f"set tf({k}) {v}")
    if extra_scripts:
        L.append(f"set tf(extra_scripts) {_tcl_list(extra_scripts)}")
    path.write_text("\n".join(L) + "\n")


def run_tool(tool: str, script: Path, run_vars: Path, log: Path, threads: int = 4,
             timeout_s: int = 14400) -> dict:
    exe = env("STA") if tool == "sta" else env("OPENROAD")
    if not exe or not (Path(exe).exists() or shutil.which(exe)):
        return {"status": "NOT RUN", "reason": f"{tool} executable not found ({exe})"}
    if tool == "sta":
        cmd = [exe, "-no_splash", "-threads", str(threads), "-exit", str(script)]
    else:
        cmd = [exe, "-no_splash", "-threads", str(threads), "-exit", str(script)]
    t0 = time.time()
    with open(log, "w") as f:
        proc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, timeout=timeout_s,
                              env={**__import__("os").environ, "TF_RUN_VARS": str(run_vars)})
    text = log.read_text(errors="replace")
    done = "TF: DONE" in text
    return {"status": "PASS" if proc.returncode == 0 and done else "FAIL",
            "returncode": proc.returncode, "runtime_s": round(time.time() - t0, 1),
            "command": " ".join(cmd), "log": str(log),
            "tail": "" if done else text[-3000:]}


def run_stage_a(design: DesignConfig, platform: Platform, run_dir: Path, corners: list[str] | None = None,
                modes: list[str] | None = None, parasitics: str = "none", threads: int = 4,
                path_count: int = 200) -> dict:
    """STAGE A: POST-SYNTHESIS STA on run_dir/synth/netlist.v."""
    corners = corners or list(platform.corners)
    netlist = run_dir / "synth" / "netlist.v"
    if not netlist.exists():
        return {"status": "NOT RUN", "reason": f"no mapped netlist at {netlist} (run synthesis first)"}
    tag = "sta_synthesis" if parasitics == "none" else f"sta_synthesis_{parasitics.replace(':', '_')}"
    out = run_dir / tag
    out.mkdir(parents=True, exist_ok=True)
    meta = write_sdcs(design, platform, "synthesis", corners, netlist, run_dir / "sdc")
    pscene = None
    first_mode = next(iter(meta["modes"]), None)
    pc = platform.synthesis_corner if platform.synthesis_corner in corners else corners[0]
    if first_mode:
        pscene = f"{first_mode}_{pc}"
    rv = out / "run_vars.tcl"
    write_run_vars(rv, design=design, platform=platform, stage="synthesis", corners=corners,
                   sdc_meta=meta, outdir=out, netlist=netlist, parasitics=parasitics,
                   power_scene=pscene, path_count=path_count)
    res = run_tool("sta", TCL_DIR / "sta_synthesis.tcl", rv, out / "sta.log", threads)
    res.update({"stage": "synthesis", "label": STAGE_LABEL["synthesis"], "corners": corners,
                "modes": list(meta["modes"]), "parasitics": parasitics,
                "parasitics_description": ("none: pin capacitance only, no wire load"
                                           if parasitics == "none" else
                                           f"library wire-load model {parasitics.split(':', 1)[-1]} (sensitivity)"),
                "clocks": "ideal", "outdir": str(out)})
    (out / "run_result.json").write_text(json.dumps(res, indent=1))
    return res
