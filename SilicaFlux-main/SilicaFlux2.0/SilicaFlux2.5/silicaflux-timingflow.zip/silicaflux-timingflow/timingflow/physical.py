"""OpenROAD physical stages B-E with hard prerequisites.

Every stage reads the previous stage's database; a missing prerequisite yields
NOT RUN with the reason, never an analysis of the wrong database.
"""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

from .config import DesignConfig, Platform
from .parse_reports import read_json
from .paths import TCL_DIR, env
from .sta import STAGE_LABEL, run_tool, write_run_vars, write_sdcs

STAGE_DB = {"placement": "2_place.odb", "cts": "3_cts.odb", "global_route": "4_grt.odb", "postroute": "5_route.odb"}
PREV = {"cts": "placement", "global_route": "cts", "postroute": "global_route"}
PARASITICS = {"placement": "estimate_parasitics -placement (ideal clocks)",
              "cts": "estimate_parasitics -placement (propagated clocks after CTS)",
              "global_route": "estimate_parasitics -global_routing",
              "postroute": "extract_parasitics (OpenRCX) -> SPEF"}

DEFAULTS = {"core_util": 35, "macro_halo": 15, "max_wire_um": 1000, "hold_margin": 0.0,
            "max_buffer_pct": 20, "repair_hold": 1, "max_iter": 5, "rollback_margin": 0.05, "setup_margin": 0.0, "drv_first": 0}


def openroad_available() -> tuple[bool, str]:
    exe = env("OPENROAD")
    if exe and (Path(exe).exists() or shutil.which(exe)):
        return True, exe
    return False, exe


def lef_files(platform: Platform, design: DesignConfig) -> list[Path]:
    ph = platform.physical
    files = [platform.path(ph.tech_lef)] + [platform.path(x) for x in ph.stdcell_lef]
    files += [platform.macro_lef(m) for m in design.macros.get(platform.name, [])]
    return files


def run_stage(design: DesignConfig, platform: Platform, run_dir: Path, stage: str,
              corners: list[str] | None = None, threads: int = 4, opts: dict | None = None,
              analysis_only: bool = False) -> dict:
    ok, exe = openroad_available()
    if not ok:
        return {"status": "NOT RUN", "stage": stage, "label": STAGE_LABEL[stage],
                "reason": f"OpenROAD executable not found ({exe}); set OPENROAD"}
    netlist = run_dir / "synth" / "netlist.v"
    pnr = run_dir / "pnr"
    if stage == "placement" and not netlist.exists():
        return {"status": "NOT RUN", "stage": stage, "reason": "no synthesized netlist (run synth first)"}
    if stage in PREV and not (pnr / STAGE_DB[PREV[stage]]).exists():
        return {"status": "NOT RUN", "stage": stage,
                "reason": f"prerequisite database {STAGE_DB[PREV[stage]]} missing (run {PREV[stage]} first)"}
    o = dict(DEFAULTS, **(opts or {}))
    corners = corners or list(platform.corners)
    out = run_dir / f"sta_{stage}"
    out.mkdir(parents=True, exist_ok=True)
    meta = write_sdcs(design, platform, stage, corners, netlist, run_dir / "sdc")
    lefs = lef_files(platform, design)
    missing = [str(p) for p in lefs if not p.exists()]
    if missing:
        return {"status": "NOT RUN", "stage": stage, "reason": "missing LEF: " + ", ".join(missing)}
    ph, cells = platform.physical, platform.cells
    extra = {
        "pnr_dir": "{" + str(pnr) + "}",
        "site": ph.site, "core_util": o["core_util"], "core_margin": ph.core_margin_um,
        "place_density": ph.place_density, "macro_halo": o["macro_halo"],
        "io_hor": ph.io_layers["horizontal"], "io_ver": ph.io_layers["vertical"],
        "min_layer": ph.min_routing_layer, "max_layer": ph.max_routing_layer,
        "setrc": "{" + str(platform.path(ph.setrc)) + "}",
        "make_tracks": "{" + str(platform.path(ph.make_tracks)) + "}",
        "pdn": "{" + str(platform.path(ph.pdn)) + "}",
        "tapcell": "{" + str(platform.path(ph.tapcell)) + "}",
        "rcx_rules": "{" + str(platform.path(ph.rcx_rules)) + "}",
        "fill_script": "{}",
        "tiehi": "{" + " ".join(cells.tiehi) + "}", "tielo": "{" + " ".join(cells.tielo) + "}",
        "cts_bufs": "{" + " ".join(cells.clock_buffers) + "}",
        "max_wire_um": o["max_wire_um"], "hold_margin": o["hold_margin"],
        "max_buffer_pct": o["max_buffer_pct"], "repair_hold": o["repair_hold"],
        "max_iter": o["max_iter"], "rollback_margin": o["rollback_margin"],
    }
    spef = {c: pnr / f"5_route_{c}.spef" for c in corners} if stage == "postroute" and analysis_only else None
    rv = out / "run_vars.tcl"
    write_run_vars(rv, design=design, platform=platform, stage=stage, corners=corners, sdc_meta=meta,
                   outdir=out, netlist=netlist, lef_files=lefs, parasitics="spef" if spef else "none",
                   spef=spef, power_scene=f"{next(iter(meta['modes']))}_{platform.synthesis_corner}", extra=extra)
    script = TCL_DIR / (f"sta_{stage}.tcl" if analysis_only else "or_flow.tcl")
    res = run_tool("openroad", script, rv, out / "openroad.log", threads, timeout_s=6 * 3600)
    res.update({"stage": stage, "label": STAGE_LABEL[stage], "corners": corners, "modes": list(meta["modes"]),
                "parasitics": "spef" if stage == "postroute" else "estimated",
                "parasitics_description": PARASITICS[stage], "outdir": str(out),
                "database": str(pnr / STAGE_DB[stage])})
    pm = out / "phys_metrics.tcl"
    if pm.exists():
        res["phys_metrics"] = {m.group(1): m.group(2) for m in re.finditer(r"set m\((\S+)\) (\S+)", pm.read_text())}
    log = (out / "openroad.log").read_text(errors="replace") if (out / "openroad.log").exists() else ""
    res["warnings"] = sorted(set(re.findall(r"^\[WARNING ([A-Z]+-\d+)\]", log, re.M)))[:100]
    res["errors"] = re.findall(r"^\[ERROR ([A-Z]+-\d+)\].*$", log, re.M)[:20]
    (out / "run_result.json").write_text(json.dumps(res, indent=1))
    return res


def run_repair(design: DesignConfig, platform: Platform, run_dir: Path, kind: str, stage: str,
               corners: list[str] | None = None, threads: int = 4, opts: dict | None = None) -> dict:
    """Controlled setup/hold repair on a stage database (tcl/repair_common.tcl).

    Hold repair is refused before CTS (ideal clocks).  Iterations and buffer
    budget are capped; the repaired DB is written only if no scene's opposite
    check degrades beyond the rollback margin and placement stays legal.
    """
    ok, exe = openroad_available()
    if not ok:
        return {"status": "NOT RUN", "reason": f"OpenROAD not found ({exe})"}
    if kind == "hold" and stage == "placement":
        return {"status": "NOT RUN", "reason": "hold repair requires propagated clocks (run after CTS)"}
    db = run_dir / "pnr" / STAGE_DB[stage]
    if not db.exists():
        return {"status": "NOT RUN", "reason": f"missing {db.name} (run {stage} first)"}
    o = dict(DEFAULTS, **(opts or {}))
    corners = corners or list(platform.corners)
    tag = (f"_m{o['setup_margin']:g}" if kind == "setup" and o["setup_margin"] else "") + ("_drv" if o["drv_first"] else "")
    out = run_dir / f"repair_{kind}_{stage}{tag}"
    out.mkdir(parents=True, exist_ok=True)
    meta = write_sdcs(design, platform, stage, corners, run_dir / "synth" / "netlist.v", run_dir / "sdc")
    extra = {"pnr_dir": "{" + str(run_dir / "pnr") + "}", "repair_kind": kind, "repair_stage": stage,
             "max_iter": o["max_iter"], "max_buffer_pct": o["max_buffer_pct"], "hold_margin": o["hold_margin"],
             "rollback_margin": o["rollback_margin"], "setup_margin": o["setup_margin"], "repair_tag": tag or "{}",
             "drv_first": int(bool(o["drv_first"])), "max_wire_um": o["max_wire_um"],
             "setrc": "{" + str(platform.path(platform.physical.setrc)) + "}"}
    rv = out / "run_vars.tcl"
    write_run_vars(rv, design=design, platform=platform, stage=stage, corners=corners, sdc_meta=meta, outdir=out,
                   lef_files=lef_files(platform, design), extra=extra)
    res = run_tool("openroad", TCL_DIR / f"repair_{kind}.tcl", rv, out / "openroad.log", threads)
    rr = out / "repair_result.tcl"
    if rr.exists():
        res["repair_result_tcl"] = rr.read_text()[:4000]
        res["rolled_back"] = "r(rolled_back) 1" in rr.read_text()
    (out / "run_result.json").write_text(json.dumps(res, indent=1))
    return res


def parse_repair_result(repair_dir: Path) -> dict | None:
    """Read repair_result.tcl (written by tcl/repair_common.tcl) into a dict.

    Returns {"name", "accepted", "legal", "seconds", "before", "after"} where
    before/after hold per-scene [setup WNS, setup TNS, hold WNS, hold TNS] (ns)
    and cell/buffer/area totals; None when the repair did not produce a result.
    """
    rr = Path(repair_dir) / "repair_result.tcl"
    if not rr.exists():
        return None
    r = {m.group(1): m.group(2).strip() for m in re.finditer(r"^set r\((\w+)\) (.*)$", rr.read_text(), re.M)}

    def snap(v: str) -> dict:
        sc = {m.group(1): [float(x) for x in m.group(2).split()]
              for m in re.finditer(r"(\w+_\w+) \{([-\d.\s]+)\}", v)}
        tot = {k: float(m.group(1)) for k in ("cells", "buffers", "area") if (m := re.search(rf"\b{k} ([-\d.]+)", v))}
        return {"scenes": sc, **tot}
    return {"name": Path(repair_dir).name, "accepted": r.get("rolled_back") == "0", "legal": r.get("legal") == "1",
            "seconds": float(r.get("seconds", "nan")), "before": snap(r.get("before", "")), "after": snap(r.get("after", ""))}
