"""SRAM macro timing from the macro's own Liberty (never from a behavioural array).

For each macro and corner: clock-to-output (A_CLK -> A_DOUT), setup/hold of
address, data, write enable, chip enable and bit mask, minimum clock pulse width
and minimum period.  Table values are summarised as min/max over the
characterised slew/load grid; the in-context values come from STA paths.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .liberty import _read


def parse_groups(text: str) -> dict:
    """Tiny Liberty group parser -> nested dict {type, name, attrs, groups}."""
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = text.replace("\\\n", " ")
    pos = 0
    root = {"type": "root", "name": "", "attrs": {}, "groups": []}
    stack = [root]
    # simple attributes may omit the ';' at end of line (accepted by Liberty readers)
    tok = re.compile(r'\s*(?:(\w+)\s*\(([^)]*)\)\s*\{|(\w+)\s*:\s*("[^"]*"|[^;\n]*)[ \t]*;?|(\w+)\s*\(([^)]*)\)\s*;?|(\}))', re.S)
    while pos < len(text):
        m = tok.match(text, pos)
        if not m:
            nxt = text.find("\n", pos)
            pos = len(text) if nxt < 0 else nxt + 1
            continue
        pos = m.end()
        if m.group(1):
            g = {"type": m.group(1), "name": m.group(2).strip().strip('"'), "attrs": {}, "groups": []}
            stack[-1]["groups"].append(g)
            stack.append(g)
        elif m.group(3):
            stack[-1]["attrs"][m.group(3)] = m.group(4).strip().strip('"')
        elif m.group(5):
            stack[-1]["attrs"].setdefault(m.group(5), []).append(m.group(6).strip())
        elif m.group(7) and len(stack) > 1:
            stack.pop()
    return root


def _values(g: dict) -> list[float]:
    vals = []
    for v in g["attrs"].get("values", []):
        vals += [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", v)]
    return vals


def macro_timing(lib: Path) -> dict:
    root = parse_groups(_read(lib))
    cell = next(g for g in root["groups"][0]["groups"] if g["type"] == "cell")
    out = {"cell": cell["name"], "area_um2": float(cell["attrs"].get("area", "nan")), "pins": {}}

    def visit(g, pin_ctx):
        if g["type"] in ("pin", "bus"):
            pin_ctx = re.sub(r"\[.*", "", g["name"])
        if g["type"] == "timing":
            tt = g["attrs"].get("timing_type", "combinational")
            rp = g["attrs"].get("related_pin", "")
            d = out["pins"].setdefault(pin_ctx, {})
            for tbl in g["groups"]:
                if tbl["type"] in ("cell_rise", "cell_fall", "rise_constraint", "fall_constraint"):
                    v = _values(tbl)
                    if v:
                        key = f"{tt}:{rp}"
                        e = d.setdefault(key, {"min_ns": min(v), "max_ns": max(v)})
                        e["min_ns"], e["max_ns"] = min(e["min_ns"], min(v)), max(e["max_ns"], max(v))
            if tt in ("min_pulse_width",):
                for tbl in g["groups"]:
                    v = _values(tbl)
                    if v:
                        d.setdefault(f"min_pulse_width:{tbl['type']}", {"min_ns": min(v), "max_ns": max(v)})
        for a in ("min_period", "min_pulse_width_high", "min_pulse_width_low"):
            if a in g["attrs"] and g["type"] in ("pin",):
                out["pins"].setdefault(pin_ctx, {})[a] = float(g["attrs"][a])
        for c in g["groups"]:
            visit(c, pin_ctx)

    visit(cell, None)
    return out


def summarize(platform, macros: list[str]) -> list[dict]:
    """Per macro x corner: output clock-to-data arcs (with launching edge) and the
    worst setup/hold of every input pin, independent of the vendor's pin naming."""
    rows = []
    for m in macros:
        for c in platform.corners:
            lib = platform.macro_liberty(c, m)
            if not lib.exists():
                rows.append({"macro": m, "corner": c, "status": "MISSING LIBERTY"})
                continue
            t = macro_timing(lib)
            outs, setups, holds, pw = {}, {}, {}, {}
            for pin, arcs in t["pins"].items():
                for k, v in arcs.items():
                    if not isinstance(v, dict):
                        pw[f"{pin}:{k}"] = v
                        continue
                    tt, _, rp = k.partition(":")
                    if tt in ("rising_edge", "falling_edge"):
                        outs[pin] = {"edge": tt.split("_")[0], "clock": rp, **v}
                    elif tt.startswith("setup"):
                        setups[pin] = v["max_ns"]
                    elif tt.startswith("hold"):
                        holds[pin] = v["max_ns"]
                    elif tt.startswith("min_pulse_width"):
                        pw[f"{pin}:{k}"] = v["max_ns"]
            rows.append({"macro": m, "corner": c, "status": "OK", "liberty": lib.name, "area_um2": t["area_um2"],
                         "clock_to_output": outs, "setup_max_ns": setups, "hold_max_ns": holds,
                         "clock_pulse_period": pw,
                         "clk_to_q_max_ns": max((o["max_ns"] for o in outs.values()), default=None),
                         "clk_to_q_min_ns": min((o["min_ns"] for o in outs.values()), default=None),
                         "output_launch_edge": sorted({o["edge"] for o in outs.values()}),
                         "worst_setup_ns": max(setups.values(), default=None),
                         "worst_hold_ns": max(holds.values(), default=None)})
    return rows


def write_report(platform, macros: list[str], out: Path) -> list[dict]:
    rows = summarize(platform, macros)
    out.mkdir(parents=True, exist_ok=True)
    (out / f"sram_macro_timing_{platform.name}.json").write_text(json.dumps(rows, indent=1))
    return rows
