"""Configuration-driven SDC generation.

One SDC per (design, mode, stage-class).  Stage classes:

* ``pre_cts``  (synthesis, placement): ideal clocks, set_clock_transition,
  uncertainty = jitter + skew allowance;
* ``post_cts`` (cts, global_route, postroute): set_propagated_clock, uncertainty
  = jitter only.  Clock insertion delay is never typed in — it is computed
  from the clock tree.

The SDC is deterministic (no timestamps) and its header records the digests of
the configuration files it was generated from.  Every exception carries its
registry id in ``-comment`` so it survives ``write_sdc``.
"""
from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from pathlib import Path

from . import liberty
from .config import (DesignConfig, ExceptionEntry, ExceptionRegistry, IOConfig, ModeDef,
                     Platform, config_digest)

PRE_CTS_STAGES = {"synthesis", "placement"}
POST_CTS_STAGES = {"cts", "global_route", "postroute"}
GENERATOR_VERSION = "timingflow-sdc-1"


def stage_class(stage: str) -> str:
    if stage in PRE_CTS_STAGES:
        return "pre_cts"
    if stage in POST_CTS_STAGES:
        return "post_cts"
    raise ValueError(f"unknown stage {stage}")


def sdc_match(name: str, pattern: str) -> bool:
    """SDC-style name match: '*' is a wildcard, brackets are literal bus indices."""
    import re as _re
    rx = "^" + _re.escape(pattern).replace("\\*", ".*").replace("\\?", ".") + "$"
    return _re.match(rx, name) is not None


def _braced(names: list[str]) -> str:
    return "{" + " ".join(names) + "}"


def obj(ref: str) -> str:
    """'port:a' -> [get_ports {a}] ; 'pin:x/y' -> [get_pins {x/y}] ..."""
    kind, _, name = ref.partition(":")
    fn = {"port": "get_ports", "pin": "get_pins", "cell": "get_cells", "inst": "get_cells",
          "clock": "get_clocks", "net": "get_nets"}.get(kind)
    if fn is None:
        raise ValueError(f"bad object reference '{ref}' (use port:/pin:/cell:/clock:/net:)")
    return f"[{fn} {_braced([name])}]"


def objs(refs: list[str]) -> str:
    by_kind: dict[str, list[str]] = {}
    for r in refs:
        k, _, n = r.partition(":")
        by_kind.setdefault(k, []).append(n)
    parts = []
    for k, names in by_kind.items():
        parts.append(obj(f"{k}:{names[0]}") if len(names) == 1 else
                     f"[{ {'port':'get_ports','pin':'get_pins','cell':'get_cells','inst':'get_cells','clock':'get_clocks','net':'get_nets'}[k]} {_braced(names)}]")
    return parts[0] if len(parts) == 1 else "[concat " + " ".join(parts) + "]"


@dataclass
class SdcResult:
    text: str
    mode: str
    stage_class: str
    clocks: list[str]
    applied_exceptions: list[str]
    skipped_exceptions: list[dict] = field(default_factory=list)
    io_groups: list[str] = field(default_factory=list)
    uncovered_ports: list[str] = field(default_factory=list)
    load_pf: float | None = None
    notes: list[str] = field(default_factory=list)


def pad_load_pf(platform: Platform, corners: list[str]) -> tuple[float | None, dict]:
    """Max over analysed corners of the platform output-load pin capacitance."""
    per = {}
    for c in corners:
        libs = platform.liberty_set(c, [])
        cands = libs["io"] + libs["stdcell"]
        for lib in cands:
            if lib.exists() and liberty.has_cell(lib, platform.io.output_load_cell):
                cap = liberty.pin_capacitance(lib, platform.io.output_load_cell, platform.io.output_load_pin)
                if cap is not None:
                    per[c] = cap
                    break
    return (max(per.values()) if per else None), per


def _mode_active(entry_modes: list[str] | None, mode: str) -> bool:
    return entry_modes is None or mode in entry_modes


def emit_exception(e: ExceptionEntry, mode_clocks: list[str]) -> tuple[list[str], str | None]:
    """Return (sdc lines, skip_reason)."""
    c = f'-comment "{e.id}"'
    fr = f" -from {objs(e.from_)}" if e.from_ else ""
    th = "".join(f" -through {objs([t])}" for t in e.through)
    to = f" -to {objs(e.to)}" if e.to else ""
    if e.type == "clock_groups_async":
        groups = [[g for g in grp if g in mode_clocks] for grp in e.groups]
        groups = [g for g in groups if g]
        if len(groups) < 2:
            return [], "fewer than two clock groups exist in this mode"
        gs = " ".join(f"-group {_braced(g)}" for g in groups)
        return [f"set_clock_groups -asynchronous -name {e.id.replace('-', '_')} {c} {gs}"], None
    if e.type == "false_path":
        if not (fr or th or to):
            return [], "false path without -from/-through/-to is rejected"
        return [f"set_false_path {c}{fr}{th}{to}"], None
    if e.type == "multicycle_path":
        if e.setup_multiplier is None or e.hold_multiplier is None:
            return [], "multicycle path must state both setup and hold multipliers"
        return [f"set_multicycle_path -setup -{e.setup_reference} {e.setup_multiplier} {c}{fr}{th}{to}",
                f"set_multicycle_path -hold -{e.hold_reference} {e.hold_multiplier} {c}{fr}{th}{to}"], None
    if e.type in ("max_delay", "min_delay"):
        if e.value is None:
            return [], "delay value missing"
        cmd = "set_max_delay" if e.type == "max_delay" else "set_min_delay"
        il = " -ignore_clock_latency" if e.datapath_only else ""
        return [f"{cmd}{il} {c}{fr}{th}{to} {e.value}"], None
    if e.type == "case_analysis":
        if e.case_value is None or not e.to:
            return [], "case analysis needs case_value and target ('to')"
        return [f"set_case_analysis {e.case_value} {objs(e.to)}"], None
    if e.type == "disable_timing":
        return [f"set_disable_timing {objs(e.to)}"], None
    return [], f"unsupported type {e.type}"


def generate(design: DesignConfig, platform: Platform, mode: ModeDef, stage: str,
             io: IOConfig | None, exc: ExceptionRegistry | None, corners: list[str],
             top_ports: dict[str, str] | None = None) -> SdcResult:
    """top_ports: {port_name: 'input'|'output'} from the netlist (for coverage)."""
    sc = stage_class(stage)
    mode_clocks = [c.name for c in design.clocks if mode.clocks is None or c.name in mode.clocks]
    gen_clocks = [g for g in design.generated_clocks if g.master in mode_clocks]
    all_clock_names = mode_clocks + [g.name for g in gen_clocks]
    dig = config_digest(design)
    L: list[str] = []
    L.append(f"# SDC generated by TimingFlow ({GENERATOR_VERSION}) — do not edit; edit configs/ instead")
    L.append(f"# design={design.name} top={design.top} platform={platform.name} mode={mode.name} "
             f"stage_class={sc} corners={','.join(corners)}")
    L.append("# config digests: " + " ".join(f"{k}={v}" for k, v in dig.items()))
    L.append("# units: time ns, capacitance pF (from the Liberty libraries)")
    L.append("")
    L.append("# ---------------------------------------------------------------- clocks")
    for cname in mode_clocks:
        ck = design.clock(cname)
        hi = ck.period_ns * ck.duty
        L.append(f"# {ck.name}: {ck.period_source}")
        L.append(f"create_clock -name {ck.name} -period {ck.period_ns:g} -waveform {{0 {hi:g}}} [get_ports {{{ck.port}}}]")
    for g in gen_clocks:
        kind, _, tname = g.target.partition(":")
        tgt = f"[get_ports {{{tname}}}]" if kind == "port" else f"[get_pins {{{tname}}}]"
        inv = " -invert" if g.invert else ""
        L.append(f"# {g.name}: {g.rtl_evidence}")
        L.append(f"create_generated_clock -name {g.name} -source [get_ports {{{g.source_port}}}] "
                 f"-master_clock {g.master} -divide_by {g.divide_by}{inv} {tgt}")
    L.append("")
    L.append(f"# ---------------------------------------------------------------- clock modelling ({sc})")
    for cname in mode_clocks:
        ck = design.clock(cname)
        u = ck.uncertainty
        su, ho = (u.pre_cts_setup, u.pre_cts_hold) if sc == "pre_cts" else (u.post_cts_setup, u.post_cts_hold)
        L.append(f"# uncertainty basis: {u.basis}")
        L.append(f"set_clock_uncertainty -setup {su:g} [get_clocks {{{cname}}}]")
        L.append(f"set_clock_uncertainty -hold {ho:g} [get_clocks {{{cname}}}]")
        if ck.source_latency_ns:
            L.append(f"set_clock_latency -source {ck.source_latency_ns:g} [get_clocks {{{cname}}}]  ;# {ck.source_latency_basis}")
        if sc == "pre_cts":
            L.append(f"set_clock_transition {ck.ideal_transition_ns:g} [get_clocks {{{cname}}}]")
    for g in gen_clocks:
        m = design.clock(g.master)
        su, ho = ((m.uncertainty.pre_cts_setup, m.uncertainty.pre_cts_hold) if sc == "pre_cts"
                  else (m.uncertainty.post_cts_setup, m.uncertainty.post_cts_hold))
        L.append(f"set_clock_uncertainty -setup {su:g} [get_clocks {{{g.name}}}]")
        L.append(f"set_clock_uncertainty -hold {ho:g} [get_clocks {{{g.name}}}]")
    if sc == "post_cts":
        L.append("set_propagated_clock [all_clocks]")
    else:
        L.append("# pre-CTS: clocks are ideal; no insertion delay is assumed or invented")
    L.append("")

    res = SdcResult(text="", mode=mode.name, stage_class=sc, clocks=all_clock_names, applied_exceptions=[])
    # ---------------------------------------------------------------- IO
    L.append("# ---------------------------------------------------------------- IO environment")
    clock_ports = {design.clock(c).port for c in mode_clocks}
    load, per = pad_load_pf(platform, corners)
    res.load_pf = load
    L.append(f"set_driving_cell -lib_cell {platform.io.input_driver_cell} -pin {platform.io.input_driver_pin} "
             f"[delete_from_list [all_inputs] [get_ports {_braced(sorted(clock_ports))}]]")
    if load is not None:
        L.append(f"# output load = max over corners of {platform.io.output_load_cell}/{platform.io.output_load_pin} "
                 f"capacitance: " + ", ".join(f"{k}={v:g}" for k, v in per.items()) + " pF")
        L.append(f"set_load -pin_load {load:g} [all_outputs]")
    else:
        res.notes.append("output load cell not found in Liberty: no set_load emitted (WARNING)")
        L.append("# WARNING: output load cell not found in Liberty; no set_load")
    covered: set[str] = set()
    if io is not None:
        L.append(f"# IO assumptions: level={io.level} status={io.status} revision={io.revision} owner={io.owner}")
        for g in io.groups:
            if not _mode_active(g.modes, mode.name):
                continue
            res.io_groups.append(g.name)
            excl = sorted(clock_ports | set(design.reset_ports))
            if top_ports:
                for p in g.ports:
                    if p == "@data_inputs":
                        covered |= {n for n, d in top_ports.items() if d == "input" and n not in excl}
                    elif p == "@outputs":
                        covered |= {n for n, d in top_ports.items() if d == "output"}
                    else:
                        covered |= {n for n in top_ports if sdc_match(n, p) or (p == n.split("[")[0])}
            L.append(f"# [{g.name}] kind={g.kind}: {g.derivation}")
            if g.kind == "sync":
                if g.clock not in all_clock_names:
                    L.append(f"# SKIPPED: reference clock {g.clock} not defined in mode {mode.name}")
                    res.notes.append(f"io group {g.name}: clock {g.clock} absent in mode {mode.name}")
                    continue
                cmd = "set_input_delay" if g.direction == "input" else "set_output_delay"
                fall = " -clock_fall" if g.clock_edge == "fall" else ""
                if g.ports == ["@data_inputs"]:
                    ports = f"[delete_from_list [all_inputs] [get_ports {_braced(excl)}]]"
                elif g.ports == ["@outputs"]:
                    ports = "[all_outputs]"
                else:
                    ports = f"[get_ports {_braced(g.ports)}]"
                if g.max_ns is None or g.min_ns is None:
                    res.notes.append(f"io group {g.name}: max/min delay missing -> insufficiently constrained")
                    L.append(f"# INSUFFICIENTLY CONSTRAINED: missing max/min for {g.name}")
                    continue
                L.append(f"{cmd} -clock {g.clock}{fall} -max {g.max_ns:g} {ports}")
                L.append(f"{cmd} -clock {g.clock}{fall} -min {g.min_ns:g} {ports}")
            elif g.kind in ("async", "reset", "static", "clock"):
                L.append(f"#   constrained by {g.exception_id or 'clock/case definition'}")
    if top_ports:
        res.uncovered_ports = sorted(p for p in top_ports if p not in covered)
        if res.uncovered_ports:
            L.append("# UNCOVERED PORTS (no IO assumption in this mode): " + " ".join(res.uncovered_ports))
    L.append("")
    # ---------------------------------------------------------------- DRV
    if design.drv:
        L.append(f"# ---------------------------------------------------------------- design rules ({design.drv.basis})")
        if design.drv.max_fanout:
            L.append(f"set_max_fanout {design.drv.max_fanout} [current_design]")
        if design.drv.max_transition_ns:
            L.append(f"set_max_transition {design.drv.max_transition_ns:g} [current_design]")
        if design.drv.max_capacitance_pf:
            L.append(f"set_max_capacitance {design.drv.max_capacitance_pf:g} [current_design]")
        L.append("")
    # ---------------------------------------------------------------- exceptions
    L.append("# ---------------------------------------------------------------- timing exceptions (registry)")
    if exc is not None:
        L.append(f"# registry revision {exc.revision}")
        for e in exc.exceptions:
            if mode.name not in e.modes:
                continue
            if e.approval == "REJECTED":
                res.skipped_exceptions.append({"id": e.id, "reason": "REJECTED in registry"})
                continue
            lines, skip = emit_exception(e, all_clock_names)
            if skip:
                res.skipped_exceptions.append({"id": e.id, "reason": skip})
                L.append(f"# {e.id} SKIPPED: {skip}")
                continue
            L.append(f"# {e.id} [{e.approval}] {e.reason}")
            L.extend(lines)
            res.applied_exceptions.append(e.id)
    L.append("")
    res.text = "\n".join(L) + "\n"
    return res


def netlist_top_ports(netlist: Path, top: str) -> dict[str, str]:
    """Port directions of the top module from a Yosys-written netlist (bit-blasted names)."""
    import re
    text = Path(netlist).read_text(errors="replace")
    m = re.search(rf"^module\s+\\?{re.escape(top)}\s*\(", text, re.M)
    if not m:
        return {}
    end = text.find("endmodule", m.end())
    body = text[m.end(): end]
    ports: dict[str, str] = {}
    for mm in re.finditer(r"^\s*(input|output|inout)\s+(?:wire\s+)?(?:\[(\d+):(\d+)\]\s+)?\\?([A-Za-z0-9_$.\[\]]+)\s*;", body, re.M):
        d, hi, lo, name = mm.groups()
        if hi is not None:
            for i in range(min(int(hi), int(lo)), max(int(hi), int(lo)) + 1):
                ports[f"{name}[{i}]"] = d
        else:
            ports[name] = d
    return ports
