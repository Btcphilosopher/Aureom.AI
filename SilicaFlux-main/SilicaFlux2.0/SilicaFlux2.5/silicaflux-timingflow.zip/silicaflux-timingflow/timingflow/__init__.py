"""SilicaFlux TimingFlow — static timing analysis and timing-closure framework."""
__version__ = "0.1.0"
