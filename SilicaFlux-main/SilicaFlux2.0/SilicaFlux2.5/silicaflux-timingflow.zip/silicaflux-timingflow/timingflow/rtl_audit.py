"""Source-backed timing-readiness audit.

Lexical scan of the vendored SystemVerilog (module headers, ports,
``always_ff`` sensitivity lists, instances) merged with the authoritative
tool results (Yosys elaboration/synthesis, Verilator lint) for each block.
The scan never decides synthesis status — only an executed tool run does.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path

from .paths import ROOT, env

MOD_RE = re.compile(r"^\s*module\s+(\w+)", re.M)
FF_RE = re.compile(r"always_ff\s*@\s*\(([^)]*)\)")
EDGE_RE = re.compile(r"(posedge|negedge)\s+([\w.\[\]]+)")
PORT_RE = re.compile(r"^\s*(input|output|inout)\b([^;,)]*?)(\w+)\s*(?:,|\)|$)", re.M)
INST_RE = re.compile(r"^\s*(\w+)\s*(?:#\s*\((?:[^()]|\([^()]*\))*\))?\s+(u_\w+|g_\w+|\w+_i)\s*\(", re.M)


def strip_comments(t: str) -> str:
    t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    return re.sub(r"//.*", "", t)


def scan_file(path: Path) -> list[dict]:
    text = strip_comments(path.read_text(errors="replace"))
    mods = []
    starts = [(m.start(), m.group(1)) for m in MOD_RE.finditer(text)]
    for i, (s, name) in enumerate(starts):
        e = text.find("endmodule", s)
        body = text[s: e if e > 0 else len(text)]
        header_end = body.find(");")
        ports = [(m.group(1), m.group(3)) for m in PORT_RE.finditer(body[: header_end + 2 if header_end > 0 else len(body)])]
        edges = {}
        n_ff = 0
        for ff in FF_RE.finditer(body):
            n_ff += 1
            for ed, sig in EDGE_RE.findall(ff.group(1)):
                edges.setdefault(sig, set()).add(ed)
        clocks = sorted(s for s, ed in edges.items() if "posedge" in ed and not re.search(r"rst|reset", s, re.I)
                        or re.search(r"clk|tck|clock", s, re.I))
        resets = sorted(s for s in edges if re.search(r"rst|reset|trst", s, re.I))
        insts = [(m.group(1), m.group(2)) for m in INST_RE.finditer(body)
                 if m.group(1) not in ("if", "for", "case", "assign", "module", "else", "begin", "return")]
        mods.append({"module": name, "file": str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
                     "inputs": [p for d, p in ports if d == "input"], "outputs": [p for d, p in ports if d == "output"],
                     "clock_signals": clocks, "reset_signals": resets,
                     "edges": {k: sorted(v) for k, v in edges.items()}, "always_ff_blocks": n_ff,
                     "instances": insts[:60], "multi_edge": any(len(v) > 1 for k, v in edges.items() if "clk" in k or "tck" in k)})
    return mods


def scan_tree(root: Path, exts=(".sv", ".v")) -> list[dict]:
    out = []
    for p in sorted(root.rglob("*")):
        if p.suffix in exts and p.is_file():
            out += scan_file(p)
    return out


def verilator_lint(files: list[Path], top: str, incs: list[Path] | None = None, defines: list[str] | None = None,
                   params: dict | None = None) -> dict:
    v = env("VERILATOR")
    if not shutil.which(v):
        return {"status": "NOT RUN", "reason": "verilator not found"}
    cmd = [v, "--lint-only", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-sv", "--top-module", top]
    cmd += [f"-I{i}" for i in (incs or [])] + [f"-D{d}" for d in (defines or [])]
    cmd += [f"-G{k}={v}" for k, v in (params or {}).items()] + [str(f) for f in files]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    errs = [l for l in (p.stdout + p.stderr).splitlines() if l.startswith("%Error")]
    return {"status": "PASS" if not errs else "FAIL", "errors": errs[:10], "command": " ".join(cmd[:8]) + " ..."}


def yosys_elab(files: list[Path], top: str, incs: list[Path] | None = None, defines: list[str] | None = None,
               libs: list[Path] | None = None, params: dict | None = None, defer: bool = False) -> dict:
    y = env("YOSYS")
    if not shutil.which(y):
        return {"status": "NOT RUN", "reason": "yosys not found"}
    script = "".join(f"read_liberty -lib {l}; " for l in (libs or []))
    script += f"read_verilog {'-defer ' if defer else ''}-sv " + " ".join(f"-D{d}" for d in (defines or [])) + " " + \
              " ".join(f"-I{i}" for i in (incs or [])) + " " + " ".join(str(f) for f in files)
    script += f"; hierarchy -check -top {top} " + " ".join(f"-chparam {k} {v}" for k, v in (params or {}).items())
    p = subprocess.run([y, "-q", "-p", script], capture_output=True, text=True, timeout=900)
    errs = [l for l in (p.stdout + p.stderr).splitlines() if "ERROR" in l]
    return {"status": "PASS" if p.returncode == 0 else "FAIL", "errors": errs[:5],
            "tool": "yosys " + subprocess.run([y, "-V"], capture_output=True, text=True).stdout.strip()}
