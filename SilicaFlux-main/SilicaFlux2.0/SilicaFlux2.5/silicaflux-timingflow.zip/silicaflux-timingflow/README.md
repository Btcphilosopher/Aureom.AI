# SilicaFlux TimingFlow — Project 06

Static timing analysis, multi-corner timing verification and timing-closure
framework for the SilicaFlux processor family (Aureom.AI · SilicaFlux
Semiconductor Engineering).

TimingFlow runs **real tools** — Yosys 0.33, OpenSTA 3.1.0, OpenROAD 40ab0df2 (built from source) — on the
**real SilicaFlux RTL** vendored byte-identically from the repository, against
**real Liberty** (IHP SG13G2 typ/slow/fast incl. SRAM macros; SKY130HD TT), with
generated, mode-specific SDC whose every exception is registered and audited.
It never prints a frequency, slack or improvement that a tool did not report;
stages that did not execute are shown as **NOT RUN**.

> Final answers to the brief's questions, with evidence: **[FINAL_ANSWERS.md](FINAL_ANSWERS.md)**.
> All numbers: **[docs/RESULTS.md](docs/RESULTS.md)** (generated from `runs/`).
> Interactive view: **`reports/dashboard.html`** (self-contained, offline).
> What was left out of this zip and how to regenerate it: **`PACKAGE_MANIFEST.md`**.

## Status at a glance (from executed runs; details in FINAL_ANSWERS.md)

| design / platform | furthest stage | slow-corner setup WNS | hold | signoff gates |
|---|---|---|---|---|
| SilicaFlux-V SoC / IHP SG13G2 (6 scenes) | POST-GLOBAL-ROUTE | −7.388 ns (CPU→bridge→CSR bus paths) | −0.970 ns fast (SRAM macro inputs) | NOT ACHIEVED — G6, G17 FAIL; G12–G16 NOT RUN |
| CPU block `sfv_cpu` / IHP (3 scenes) | **POST-ROUTE** (0 DRC, SPEF) | −2.303 ns → **+0.196 ns** after controlled repair | ≥ +0.049 ns | G13/G14 PASS on the repaired run; G15 (CTS root fanout), G16 (no foundry corner list) FAIL |
| SilicaFlux-V + DataFabric SoC / IHP | POST-SYNTHESIS | reg2reg +3.878 ns (recovery −51.1 ns pre-buffering) | −0.369 ns | — |
| SilicaFlux-V SoC / SKY130HD (TT only) | POST-SYNTHESIS | reg2reg +1.327 ns TT (OpenRAM falling-edge launch) | +0.041 ns | multi-corner impossible (TT only) |
| Full SilicaFlux v1.0 | BLOCKED (Yosys parser) | — | — | — |
| MCU-I | NOT FOUND in the repository | — | — | — |
| Commercial 130/65/28 nm | NOT AVAILABLE | — | — | — |

## What is in the box

| Path | Contents |
|---|---|
| `timingflow/` | Python package: config models (pydantic), Liberty utilities, Yosys driver, SDC generator, SDC lint, constraint audit, CDC/RDC structure analysis, exception-impact analysis, OpenSTA/OpenROAD drivers with stage prerequisites, report parsers, critical-path explorer, summaries, signoff gates, comparison, multi-objective optimiser, report exporter, dashboard, CLI |
| `tcl/` | OpenSTA/OpenROAD scripts: `load_design`, `load_corners` (scene MCMM), `validate_constraints`, `report_paths`, `sta_synthesis` (stage A), `or_flow` (stages B–E), `sta_{placement,cts,global_route,postroute}` (analysis-only), `repair_{setup,hold}`, `constraint_analysis` (impact + CDC/RDC) |
| `configs/` | `platforms/` (IHP SG13G2, SKY130HD, commercial = NOT AVAILABLE), `designs/` (SilicaFlux-V, DataFabric SoC, blocks, SRAM library, Full SilicaFlux = PARTIAL, MCU-I = NOT FOUND, reference gcd), `io/` (board/block IO assumptions), `exceptions/` (registry), `experiments/`, `tools.yaml` (pinned revisions) |
| `third_party/` | SilicaFlux RTL vendored unmodified from `SilicaFlux-main` archives + `SHA256SUMS` + `PROVENANCE.json` (`scripts/intake.py --verify`) |
| `runs/` | executed runs: netlists, generated SDC, raw OpenSTA reports, summaries, audits, gates |
| `reports/` | per-run TXT/CSV/JSON/HTML/PNG report packages, experiment results, `dashboard.html`, audit tables |
| `docs/` | AUDIT, FLOW, CONSTRAINTS, EXCEPTIONS_CDC_RDC, SIGNOFF_GATES, TOOLS, EXPERIMENTS, RESULTS (generated), TECHNOLOGY_COMPARISON, FLOORPLANLAB_INTERFACE, UNRESOLVED |
| `tests/` | pytest suite on real tool-output fixtures + rule unit tests; opt-in end-to-end on the public reference design |
| `scripts/` | intake, audit, results generator, toolchain setup (`setup_tools.sh`), ORFS fetch |
| `.github/workflows/timingflow.yml` | CI: lint, intake integrity, unit tests, reference e2e, SilicaFlux-V stage A artefacts (public collateral only) |

## Quick start
```bash
pip install -r requirements.txt
```
```bash
bash scripts/setup_tools.sh --opensta-only        # Yosys 0.33 (apt) + OpenSTA 3.1.0 (pinned source); full OpenROAD chain without the flag
```
```bash
bash scripts/fetch_orfs.sh /opt/eda/orfs          # pinned ORFS platform collateral
```
```bash
python -m timingflow flow   --design silicaflux_v --platform ihp_sg13g2 --to check_sdc
```
```bash
python -m timingflow report --design silicaflux_v --platform ihp_sg13g2
```
```bash
python -m timingflow dashboard
```
```bash
python -m timingflow repair --design blk_cpu --platform ihp_sg13g2 --kind setup --stage global_route
```
Make targets: `make timing-lint timing-check-sdc timing-synth timing-placement
timing-cts timing-global-route timing-postroute timing-corners timing-report
timing-optimise timing-compare timing-dashboard timing-gates test`.

## Honesty rules implemented in code
* Stage labels (POST-SYNTHESIS … POST-ROUTE) come from the stage that ran; a
  stage refuses to run without its prerequisite database.
* Pre-CTS clocks are ideal: no insertion delay is invented; pre-CTS skew/latency
  and pulse-width are flagged *indicative only*.
* No port gets a silent zero IO delay; uncovered ports FAIL the audit.
* Every exception carries a registry id and is impact-checked; a false path that
  covers functional endpoints FAILs.
* CDC is checked structurally on the netlist, never by module name; anything not
  structurally provable is REVIEW REQUIRED.
* Derived Fmax is always labelled DERIVED with its stage/corner.
* Power is reported only as a labelled vectorless estimate.
* Commercial nodes are NOT AVAILABLE; nothing is rescaled between nodes.
* Signoff gates 13–16 can pass only on POST-ROUTE extracted timing in every
  scene; OpenSTA/OpenROAD are not a foundry signoff flow.
