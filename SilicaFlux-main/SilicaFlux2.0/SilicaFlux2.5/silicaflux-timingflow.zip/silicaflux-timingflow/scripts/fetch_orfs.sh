#!/usr/bin/env bash
# Pinned sparse fetch of OpenROAD-flow-scripts platform collateral used by TimingFlow.
#   scripts/fetch_orfs.sh <dest>    then: export ORFS_PLATFORMS=<dest>/flow/platforms ORFS_SCRIPTS=<dest>/flow/scripts
set -euo pipefail
DEST=${1:-/opt/eda/orfs}
REV=3f8ab4ebeb3a886a88fc0774b176c77a18905718
git clone --filter=blob:none --sparse https://github.com/The-OpenROAD-Project/OpenROAD-flow-scripts "$DEST"
git -C "$DEST" sparse-checkout set flow/platforms/sky130hd flow/platforms/sky130ram flow/platforms/ihp-sg13g2 \
    flow/scripts flow/util flow/designs/sky130hd/gcd flow/designs/src/gcd
git -C "$DEST" checkout -q "$REV"
echo "ORFS $(git -C "$DEST" rev-parse HEAD)"
