#!/usr/bin/env bash
# Reproduce the TimingFlow reference toolchain (Ubuntu 24.04).  Revisions: configs/tools.yaml
#   scripts/setup_tools.sh [--opensta-only] [--prefix /opt/eda]
set -euo pipefail
PREFIX=/opt/eda; ONLY_STA=0
for a in "$@"; do case $a in --opensta-only) ONLY_STA=1;; --prefix=*) PREFIX=${a#*=};; esac; done
J=${J:-$(nproc)}
SUDO=$([ "$(id -u)" = 0 ] && echo "" || echo sudo)
$SUDO apt-get update
$SUDO apt-get install -y --no-install-recommends yosys iverilog verilator tcl tcl-dev tcllib swig libeigen3-dev cmake \
  bison flex libfl-dev build-essential zlib1g-dev libfmt-dev libgtest-dev libgmock-dev automake autoconf libtool \
  tcl-tclreadline git
mkdir -p "$PREFIX/src"; cd "$PREFIX/src"
# CUDD 3.0.0
[ -d cudd ] || git clone https://github.com/ivmai/cudd.git
git -C cudd checkout -q f54f533303640afd5dbe47a05ebeabb3066f2a25
(cd cudd && autoreconf -fi && ./configure --prefix="$PREFIX/cudd" && make -j"$J" && make install)
# OpenSTA 3.1.0
[ -d OpenSTA ] || git clone https://github.com/The-OpenROAD-Project/OpenSTA.git
git -C OpenSTA checkout -q 444cfc701ce34e0cf3dc73bbad3a9c2b56ad8c08
cmake -S OpenSTA -B OpenSTA/build -DCUDD_DIR="$PREFIX/cudd" -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$PREFIX/opensta"
cmake --build OpenSTA/build --target sta -j"$J" && cmake --install OpenSTA/build
echo "export STA=$PREFIX/opensta/bin/sta"
[ "$ONLY_STA" = 1 ] && exit 0
# ---- OpenROAD (last CMake revision) and its from-source dependencies
$SUDO apt-get install -y --no-install-recommends libboost-all-dev libyaml-cpp-dev libdeflate-dev python3-dev \
  libreadline-dev libomp-dev libpcre2-dev pkg-config libgl-dev libglx-dev libglu1-mesa-dev
$SUDO apt-get remove -y libspdlog-dev liblemon-dev || true      # incompatible with OpenROAD (fmt 12 / C++20)
[ -d or-tools ] || git clone --depth 1 -b v9.14 https://github.com/google/or-tools.git
cmake -S or-tools -B or-tools/build -DCMAKE_BUILD_TYPE=Release -DBUILD_DEPS=ON -DBUILD_CXX=ON -DBUILD_PYTHON=OFF \
  -DBUILD_SAMPLES=OFF -DBUILD_EXAMPLES=OFF -DBUILD_TESTING=OFF -DUSE_SCIP=OFF -DUSE_COINOR=OFF -DUSE_HIGHS=OFF \
  -DUSE_GLPK=OFF -DUSE_PDLP=OFF -DBUILD_SHARED_LIBS=ON -DCMAKE_INSTALL_PREFIX="$PREFIX/ortools"
cmake --build or-tools/build -j"$J" && cmake --install or-tools/build
[ -d swig ] || git clone --depth 1 -b v4.3.0 https://github.com/swig/swig.git
(cd swig && ./autogen.sh && ./configure --prefix="$PREFIX/swig" --without-pcre && make -j"$J" && make install)
[ -d spdlog ] || git clone --depth 1 -b v1.15.0 https://github.com/gabime/spdlog.git
cmake -S spdlog -B spdlog/build -DCMAKE_INSTALL_PREFIX="$PREFIX/spdlog" -DCMAKE_POSITION_INDEPENDENT_CODE=ON -DSPDLOG_BUILD_EXAMPLE=OFF
cmake --build spdlog/build -j"$J" --target install
[ -d lemon-graph ] || git clone --depth 1 -b 1.3.1 https://github.com/The-OpenROAD-Project/lemon-graph.git
cmake -S lemon-graph -B lemon-graph/build -DCMAKE_INSTALL_PREFIX="$PREFIX/lemon" && cmake --build lemon-graph/build -j"$J" --target install
[ -d OpenROAD ] || git clone --filter=blob:none https://github.com/The-OpenROAD-Project/OpenROAD.git
git -C OpenROAD checkout -q 40ab0df2bc52e1fca4b47352c9cf432df23c0972
git -C OpenROAD submodule update --init --recursive src/sta third-party/abc third-party/sv-elab
O=$PREFIX/ortools
cmake -S OpenROAD -B OpenROAD/build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$PREFIX/openroad" \
  -DBUILD_GUI=OFF -DBUILD_PYTHON=OFF -DENABLE_TESTS=ON -DBUILD_TCLX=OFF \
  -DSWIG_EXECUTABLE="$PREFIX/swig/bin/swig" -DSWIG_DIR="$PREFIX/swig/share/swig/4.3.0" \
  -Dortools_ROOT="$O" -Dabsl_ROOT="$O" -Dspdlog_ROOT="$PREFIX/spdlog" -DLEMON_DIR="$PREFIX/lemon/share/lemon/cmake" \
  -DCMAKE_PREFIX_PATH="$PREFIX/lemon;$PREFIX/spdlog;$O;$PREFIX/cudd" -DCUDD_DIR="$PREFIX/cudd"
cmake --build OpenROAD/build --target openroad -j"$J" && cmake --install OpenROAD/build
echo "export OPENROAD=$PREFIX/openroad/bin/openroad"
