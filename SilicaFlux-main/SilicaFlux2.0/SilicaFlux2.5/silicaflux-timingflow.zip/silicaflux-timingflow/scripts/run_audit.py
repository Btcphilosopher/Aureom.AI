#!/usr/bin/env python3
"""Generate the source-backed timing-readiness audit.

  python scripts/run_audit.py --repo <path>/SilicaFlux-main

Writes reports/audit/audit.json and reports/audit/AUDIT_TABLES.md (included by
docs/AUDIT.md).  Repository inventory is taken from the real archives; block
facts come from a lexical RTL scan; elaboration/lint status from running Yosys
and Verilator; synthesis status from TimingFlow runs (if present).
"""
from __future__ import annotations

import argparse
import io
import json
import re
import sys
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from timingflow import rtl_audit  # noqa: E402
from timingflow.config import list_designs, load_design, load_platform  # noqa: E402
from timingflow.paths import RUNS_DIR  # noqa: E402

HDL = (".sv", ".v", ".svh", ".vh", ".sf")
KEYS = {"cpu": r"cpu|core|fetch|decod|alu|regfile|register_bank|forwarding", "vector": r"vec",
        "tensor": r"tensor|mac|matmul|systolic", "dma": r"dma", "fabric": r"xbar|crossbar|noc|fabric|bus|arbit",
        "sram": r"sram|mem|cache|rom", "clock": r"clk|clock|pll|div", "reset": r"rst|reset", "sdc": r"\.sdc$",
        "openroad": r"openroad|or_|pnr|floorplan|place|cts|route"}


def inventory(repo: Path) -> list[dict]:
    rows = []
    for a in sorted(list(repo.rglob("*.zip")) + list(repo.rglob("*.tar.gz"))):
        try:
            if a.suffix == ".zip":
                with zipfile.ZipFile(a) as z:
                    names = [i.filename for i in z.infolist() if not i.is_dir()]
            else:
                with tarfile.open(a) as t:
                    names = [m.name for m in t.getmembers() if m.isfile()]
        except Exception as e:
            rows.append({"archive": str(a.relative_to(repo)), "error": str(e)})
            continue
        names = [n for n in names if "node_modules" not in n]
        hdl = [n for n in names if n.endswith(HDL)]
        rows.append({"archive": str(a.relative_to(repo)), "files": len(names), "hdl": len(hdl),
                     "sdc": sum(n.endswith(".sdc") for n in names), "tcl": sum(n.endswith(".tcl") for n in names),
                     "python": sum(n.endswith(".py") for n in names),
                     "liberty_lef_odb_spef": sum(n.endswith((".lib", ".lef", ".odb", ".spef", ".def")) for n in names),
                     "topics": sorted(k for k, pat in KEYS.items() if any(re.search(pat, n, re.I) for n in hdl + [x for x in names if x.endswith(('.sdc', '.tcl'))]))})
    loose = sorted(p for p in repo.rglob("*") if p.suffix in (".sf", ".sv", ".v", ".sdc", ".tcl") and p.is_file())
    for p in loose:
        rows.append({"archive": "(loose) " + str(p.relative_to(repo)), "files": 1, "hdl": int(p.suffix in HDL),
                     "sdc": int(p.suffix == ".sdc"), "tcl": int(p.suffix == ".tcl"), "python": 0,
                     "liberty_lef_odb_spef": 0, "topics": []})
    return rows


def design_block_table(dname: str) -> dict:
    d = load_design(dname)
    if d.status == "NOT_FOUND":
        return {"design": dname, "status": d.status, "evidence": d.status_evidence}
    plat = load_platform(d.platforms[0]) if d.platforms else None
    files = d.rtl_files(plat.name if plat else "")
    incs = [d.src_root() / i for i in d.include_dirs]
    libs = []
    if plat:
        s = plat.liberty_set(plat.synthesis_corner, d.macros.get(plat.name, []))
        libs = s["stdcell"] + s["macro"]
    mods = []
    for f in files:
        if f.exists():
            mods += rtl_audit.scan_file(f)
    yo = rtl_audit.yosys_elab(files, d.top, incs, d.defines, libs, d.parameters, d.synth.defer)
    # Verilator lint of the technology-independent RTL: PDK wrappers out, generic
    # (excluded-for-ASIC) files back in, behavioural SRAM (no SFV_SRAM_MACRO).
    generic = [d.src_root() / x for x in d.exclude]
    generic += [Path(re.sub(r"/asic/tech/[^/]+/", "/rtl/common/", str(f)))
                for f in files if f.name == "sfv_clkgate.sv" and "/asic/tech/" in str(f)]
    stubs = [f.parent / "stubs" / "sram_macro_blackboxes.sv" for f in files if f.name == "sram_asic_array.sv"]
    ve = rtl_audit.verilator_lint([f for f in files if "/asic/tech/" not in str(f)] + generic + stubs, d.top, incs,
                                  [x for x in d.defines if x != "SFV_SRAM_MACRO"], d.parameters)
    runs = {}
    for rd in sorted((RUNS_DIR / dname).glob("*/*")):
        s = rd / "synth" / "synth_summary.json"
        if s.exists():
            j = json.loads(s.read_text())
            runs[f"{rd.parts[-2]}/{rd.name}"] = {k: j.get(k) for k in ("status", "n_cells", "total_area_um2", "cell_classes")}
    return {"design": dname, "title": d.title, "status": d.status, "top": d.top, "n_files": len(files),
            "yosys_elaboration": yo, "verilator_lint": ve, "synthesis_runs": runs, "modules": mods,
            "clocks_configured": [c.name for c in d.clocks], "generated_clocks": [g.name for g in d.generated_clocks],
            "macros": d.macros}


def md(audit: dict) -> str:
    L = ["<!-- generated by scripts/run_audit.py — do not edit -->", "", "## A. Repository inventory (archives under SilicaFlux-main)", "",
         "| archive | files | HDL | SDC | Tcl | Liberty/LEF/ODB/SPEF | topics (by file names) |", "|---|---|---|---|---|---|---|"]
    for r in audit["inventory"]:
        if r.get("hdl") or r.get("sdc") or r.get("tcl"):
            L.append(f"| {r['archive']} | {r.get('files', '')} | {r.get('hdl', '')} | {r.get('sdc', '')} | {r.get('tcl', '')} | "
                     f"{r.get('liberty_lef_odb_spef', '')} | {', '.join(r.get('topics', []))} |")
    L += ["", "No Liberty, LEF, ODB, DEF or SPEF file exists anywhere in the repository archives (column above); "
          "all technology collateral comes from ORFS platforms (configs/platforms).", ""]
    for d in audit["designs"]:
        L.append(f"## B. {d['design']} — {d.get('title', '')}")
        if d["status"] == "NOT_FOUND":
            L += ["", f"**NOT FOUND.** {d['evidence']}", ""]
            continue
        L += ["", f"* top `{d['top']}`, {d['n_files']} source files; Yosys elaboration **{d['yosys_elaboration']['status']}** "
              f"({d['yosys_elaboration'].get('tool', '')}); Verilator lint **{d['verilator_lint']['status']}**",
              f"* configured clocks: {', '.join(d['clocks_configured'])}; generated: {', '.join(d['generated_clocks']) or 'none'}; macros: {d['macros']}"]
        for k, v in d["synthesis_runs"].items():
            L.append(f"* synthesis run `{k}`: {v['status']}, {v['n_cells']} cells, {v['total_area_um2']} µm², {v['cell_classes']}")
        if d["yosys_elaboration"].get("errors"):
            L.append(f"* Yosys errors: `{d['yosys_elaboration']['errors'][0][:160]}`")
        L += ["", "| module | file | clocks (edge) | resets | always_ff | inputs | outputs | instances |", "|---|---|---|---|---|---|---|---|"]
        seen = set()
        for m in d["modules"]:
            if m["module"] in seen:
                continue
            seen.add(m["module"])
            ce = "; ".join(f"{k}:{'/'.join(v)}" for k, v in m["edges"].items() if k in m["clock_signals"]) or "—"
            L.append(f"| `{m['module']}` | {m['file'].split('third_party/')[-1]} | {ce} | {', '.join(m['reset_signals']) or '—'} | "
                     f"{m['always_ff_blocks']} | {len(m['inputs'])} | {len(m['outputs'])} | "
                     f"{', '.join(i[1] + ':' + i[0] for i in m['instances'][:8])}{' …' if len(m['instances']) > 8 else ''} |")
        L.append("")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", type=Path, required=True)
    a = ap.parse_args()
    audit = {"inventory": inventory(a.repo), "designs": [design_block_table(d) for d in list_designs()]}
    out = ROOT / "reports" / "audit"
    out.mkdir(parents=True, exist_ok=True)
    (out / "audit.json").write_text(json.dumps(audit, indent=1, default=str))
    (out / "AUDIT_TABLES.md").write_text(md(audit))
    print(f"wrote {out}/audit.json and AUDIT_TABLES.md ({len(audit['inventory'])} archives/files, {len(audit['designs'])} designs)")
