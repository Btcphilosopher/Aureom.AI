#!/usr/bin/env python3
"""Generate docs/RESULTS.md from executed runs (no hand-typed numbers).

Every table cites the run directory it came from.  Missing runs/stages are
printed as NOT RUN.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from timingflow import sram  # noqa: E402
from timingflow.config import load_platform  # noqa: E402
from timingflow.parse_reports import read_json  # noqa: E402
from timingflow.physical import parse_repair_result  # noqa: E402

RUNS = ROOT / "runs"
STAGES = ["synthesis", "placement", "cts", "global_route", "postroute"]


def f(v, d=3):
    if v is None:
        return "—"
    if isinstance(v, float):
        if v != v or abs(v) == float("inf"):
            return "INF"
        return f"{v:.{d}f}"
    return str(v)


def summ(design, plat, run="baseline", stage="synthesis"):
    return read_json(RUNS / design / plat / run / f"sta_{stage}" / "summary.json")


def scene_table(sm) -> list[str]:
    L = ["| scene | WNS (ns) | TNS (ns) | WHS (ns) | THS (ns) | reg2reg setup WNS (ns) | reg2reg hold WNS (ns) | Fmax* (MHz) | recovery WNS (ns) | SRAM read / write / write-hold WNS (ns) | setup viol. | hold viol. | max-slew / max-cap / max-fanout viol. |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for k, v in sm["scenes"].items():
        d = v["drv"]
        rr = v["recovery_removal"]["worst_slack_ns"]
        rec = min((g["wns_ns"] for g in v["groups"].values() if g["group"] == "asynchronous" and g["check"] == "setup"), default=None)
        L.append(f"| {k} | {f(v['wns_ns'])} | {f(v['tns_ns'], 1)} | {f(v['whs_ns'])} | {f(v['ths_ns'], 2)} | "
                 f"{f(v['reg2reg']['setup_wns_ns'])} | {f(v['reg2reg']['hold_wns_ns'])} | {f(v['reg2reg'].get('fmax_derived_mhz'), 1)} | "
                 f"{f(rec)} | {f(v['sram']['read_setup_wns_ns'])} / {f(v['sram']['write_setup_wns_ns'])} / {f(v['sram']['write_hold_wns_ns'])} | "
                 f"{v['setup_all']['violators']} | {v['hold_all']['violators']} | "
                 f"{d.get('max_slew', {}).get('violators', 0)} / {d.get('max_capacitance', {}).get('violators', 0)} / {d.get('max_fanout', {}).get('violators', 0)} |")
    return L


def path_line(label, w) -> str:
    if not w or not w.get("path"):
        return f"| {label} | — | — | — | — | — | — |"
    p = w["path"]
    comp = ", ".join(f"{k} {f(v, 2)}" for k, v in p["delay_by_block_ns"].items())
    return (f"| {label} | {f(p['slack_ns'])} ({w['scene']}) | `{p['startpoint']}` | `{p['endpoint']}` | {p['group']} | "
            f"{p['owner_block']} ({p['start_block']}→{p['end_block']}); {comp} | depth {p['logic_depth']}, max fanout {p['max_fanout']}, "
            f"max slew {f(p['max_slew_ns'], 2)} ns; {p['dominance']} |")


def progression(design, plat, run="baseline") -> list[str]:
    rows = []
    for st in STAGES:
        sm = summ(design, plat, run, st)
        rr = read_json(RUNS / design / plat / run / f"sta_{st}" / "run_result.json") or {}
        if not sm or sm.get("status") != "PASS":
            rows.append(f"| {st} | {(sm or {}).get('status', 'NOT RUN')} | | | | | | | |")
            continue
        for k, v in sm["scenes"].items():
            t = v["top_reg2reg_paths"][0] if v["top_reg2reg_paths"] else {}
            pm = rr.get("phys_metrics") or {}
            area = next((pm[x] for x in ("post_route_area_um2", "post_grt_area_um2", "post_cts_area_um2", "post_place_area_um2") if x in pm), "—")
            rows.append(f"| {sm['label']} | PASS | {k} | {f(v['wns_ns'])} | {f(v['whs_ns'])} | {f(v['reg2reg']['setup_wns_ns'])} | "
                        f"{f(v['reg2reg']['hold_wns_ns'])} | {f(t.get('cell_delay_ns'), 2)} / {f(t.get('net_delay_ns'), 2)} | {area} |")
    if not any("PASS" in r for r in rows[1:]):
        return []
    return ["Stage progression (same netlist and constraints; parasitics per stage):", "",
            "| stage | status | scene | WNS (ns) | WHS (ns) | reg2reg setup (ns) | reg2reg hold (ns) | worst reg2reg cell / net delay (ns) | cell area after stage (µm²) |",
            "|---|---|---|---|---|---|---|---|---|"] + rows + [""]


def repair_section(design, plat, run="baseline") -> list[str]:
    rd = RUNS / design / plat / run
    L = []
    for d in sorted(rd.glob("repair_*")):
        res = read_json(d / "run_result.json") or {}
        r = parse_repair_result(d)
        if not r:
            L.append(f"* `{d.name}`: {res.get('status', 'NOT RUN')} — no repair_result.tcl ({res.get('reason', '')})")
            continue
        b, a = r["before"], r["after"]
        L += [f"### Controlled repair `{d.name}` — {'ACCEPTED' if r['accepted'] else 'ROLLED BACK'} "
              f"(placement legal: {'yes' if r['legal'] else 'NO'}, {r['seconds']:.0f} s)", "",
              "| scene | setup WNS before → after (ns) | setup TNS before → after (ns) | hold WNS before → after (ns) |",
              "|---|---|---|---|"]
        for s_, bv in b["scenes"].items():
            av = a["scenes"].get(s_, [None] * 4)
            L.append(f"| {s_} | {f(bv[0])} → {f(av[0])} | {f(bv[1], 3)} → {f(av[1], 3)} | {f(bv[2])} → {f(av[2])} |")
        if b.get("cells") and a.get("cells"):
            L.append("")
            L.append(f"Cells {int(b['cells'])} → {int(a['cells'])}, buffers/inverters {int(b['buffers'])} → {int(a['buffers'])}, "
                     f"area {f(b['area'], 1)} → {f(a['area'], 1)} µm² ({(a['area'] - b['area']) / b['area'] * 100:+.3f} %). "
                     "Rollback rule: the opposite check may not degrade by more than the rollback margin into a violation in any scene, "
                     "and placement must stay legal; the repaired database is written as a separate `*_repair_<kind>.odb`.")
        L.append("")
    return (["Timing repair runs (OpenROAD `repair_timing`, tcl/repair_common.tcl):", ""] + L) if L else []


def _die(d) -> str:
    if isinstance(d, dict) and {"x1", "x2", "y1", "y2"} <= set(d):
        return f"{d['x2'] - d['x1']:.1f} × {d['y2'] - d['y1']:.1f} µm"
    return str(d)


def clock_tree_section(design, plat, run="baseline") -> list[str]:
    sm = summ(design, plat, run, "cts")
    if not sm or sm.get("status") != "PASS":
        return []
    L = ["Clock tree after CTS (propagated clocks; OpenSTA `report_clock_latency` / `report_clock_skew` on the CTS database):", "",
         "| scene | clock | insertion delay min … max (ns) | latency spread (ns) | setup skew (ns) | hold skew (ns) | min-pulse-width violators |",
         "|---|---|---|---|---|---|---|"]
    for k, v in sm["scenes"].items():
        for c, lat in (v.get("clock_latency") or {}).get("clocks", {}).items():
            su = (v.get("clock_skew") or {}).get("setup", {}).get(c, {})
            ho = (v.get("clock_skew") or {}).get("hold", {}).get(c, {})
            L.append(f"| {k} | {c} | {f(lat.get('min_ns'))} … {f(lat.get('max_ns'))} | {f(lat.get('skew_ns'))} | "
                     f"{f(su.get('setup_skew'))} | {f(ho.get('hold_skew'))} | {(v.get('min_pulse_width') or {}).get('violators')} |")
    ct = read_json(RUNS / design / plat / run / "sta_cts" / "clock_tree.json")
    if ct:
        nets = ct.get("clock_nets") or []
        sinks = sum(len(n.get("sinks", [])) for n in nets) if isinstance(nets, list) else None
        L += ["", f"Clock-net dump (`sta_cts/clock_tree.json`, plotted as `clock_tree.png`): die {_die(ct.get('die_um'))}, "
                  f"{len(nets)} clock nets{f', {sinks} sink pins' if sinks else ''}."]
    L.append("")
    return L


def design_section(name, design, plat, run="baseline") -> list[str]:
    L = [f"## {name} — `{design}` on `{plat}` (run `{run}`)", ""]
    L += progression(design, plat, run)
    L += clock_tree_section(design, plat, run)
    L += repair_section(design, plat, run)
    rd = RUNS / design / plat / run
    syn = read_json(rd / "synth" / "synth_summary.json")
    if syn:
        L.append(f"Synthesis (Yosys 0.33 + ORFS abc_speed, {syn.get('synthesis_corner')} corner Liberty): {syn.get('status')}, "
                 f"{syn.get('n_cells')} cells, area {f(syn.get('total_area_um2'), 0)} µm² (incl. macros), classes {syn.get('cell_classes')}, "
                 f"latches {len(syn.get('inferred_latches') or [])}, runtime {syn.get('runtime_s')} s.")
        L.append("")
    for st in STAGES:
        sm = summ(design, plat, run, st)
        if not sm:
            L.append(f"**{st.upper()}: NOT RUN**")
            L.append("")
            continue
        L.append(f"### {sm['label']} — {sm['status']} · parasitics: {sm.get('parasitics')} · clocks: {sm.get('clocks_mode')}")
        L.append("")
        if sm["status"] != "PASS":
            L.append(f"reason: `{(sm.get('reason') or '')[:400]}`")
            L.append("")
            continue
        L += scene_table(sm)
        L.append("")
        L.append("Fmax* = DERIVED 1/(T − worst reg2reg slack) at this stage and corner (ideal clocks before CTS); not a measured frequency.")
        L.append("")
        L += ["| worst | slack (ns) | startpoint | endpoint | group | block attribution and delay by block (ns) | path facts |",
              "|---|---|---|---|---|---|---|"]
        w = sm["worst"]
        L.append(path_line("setup (all groups)", w.get("setup")))
        L.append(path_line("reg-to-reg setup", w.get("r2r_setup")))
        L.append(path_line("hold", w.get("hold")))
        L.append("")
        func = {k: v for k, v in sm["scenes"].items() if v["mode"] == sm["scenes"][k]["mode"]}
        worst_sc = min(sm["scenes"], key=lambda k: sm["scenes"][k]["reg2reg"]["setup_wns_ns"] if sm["scenes"][k]["reg2reg"]["setup_wns_ns"] is not None else 1e9)
        v = sm["scenes"][worst_sc]
        L.append(f"Top reg-to-reg paths ({worst_sc}):")
        L.append("")
        L += ["| # | slack (ns) | owner | start→end | startpoint | endpoint | depth | launch / cell / net (ns) |", "|---|---|---|---|---|---|---|---|"]
        for p in v["top_reg2reg_paths"][:8]:
            L.append(f"| {p['rank']} | {f(p['slack_ns'])} | {p['owner_block']} | {p['start_block']}→{p['end_block']} | `{p['startpoint']}` | "
                     f"`{p['endpoint']}` | {p['logic_depth']} | {f(p.get('launch_delay_ns'), 2)} / {f(p['cell_delay_ns'], 2)} / {f(p['net_delay_ns'], 2)} |")
        L.append("")
        cg = v["clock_gating"]
        L.append(f"ICG enables (Liberty GATE arcs): worst setup {f(cg.get('icg_enable_setup_worst_ns'))} ns, worst hold "
                 f"{f(cg.get('icg_enable_hold_worst_ns'))} ns at {cg.get('icg_enable_endpoints')}.")
        if sm.get("power"):
            t = sm["power"]["groups"].get("Total", {})
            L.append(f"Power ({sm['power']['scene']}): total {f(t.get('total_w', 0) * 1e3, 2)} mW (internal {f(t.get('internal_w', 0) * 1e3, 2)}, "
                     f"switching {f(t.get('switching_w', 0) * 1e3, 2)}, leakage {f(t.get('leakage_w', 0) * 1e3, 3)} mW) — {sm['power']['basis']}.")
        L.append("")
        L.append("Per-block setup bottlenecks (endpoint attribution, " + worst_sc + "):")
        L.append("")
        L += ["| block | endpoints | violators | WNS (ns) | TNS (ns) | worst endpoint |", "|---|---|---|---|---|---|"]
        for b in v["bottlenecks_setup"]:
            L.append(f"| {b['block']} | {b['endpoints']} | {b['violators']} | {f(b['wns_ns'])} | {f(b['tns_ns'], 1)} | `{b['worst_endpoint']}` |")
        L.append("")
        if v.get("bottlenecks_setup_clocked"):
            L.append(f"Per-block setup bottlenecks, clocked data endpoints only (recovery/removal, path-delay and unconstrained groups excluded, {worst_sc}):")
            L.append("")
            L += ["| block | endpoints | violators | WNS (ns) | TNS (ns) | worst endpoint |", "|---|---|---|---|---|---|"]
            for b in v["bottlenecks_setup_clocked"]:
                L.append(f"| {b['block']} | {b['endpoints']} | {b['violators']} | {f(b['wns_ns'])} | {f(b['tns_ns'], 1)} | `{b['worst_endpoint']}` |")
            L.append("")
        thr = {k: x["clocked"] for k, x in (v.get("worst_through_block") or {}).items() if x.get("clocked")}
        if thr:
            L.append(f"Worst clocked data path crossing each top-level block boundary (`report_checks -through <instance>`, {worst_sc}); "
                     "paths entirely inside a block are covered by the endpoint table above:")
            L.append("")
            L += ["| instance | slack (ns) | delay inside the instance (ns) | arrival (ns) | startpoint | endpoint | depth |", "|---|---|---|---|---|---|---|"]
            for k, x in sorted(thr.items(), key=lambda kv: kv[1]["slack_ns"]):
                L.append(f"| `{k}` | {f(x['slack_ns'])} | {f(x['delay_inside_block_ns'], 2)} | {f(x['arrival_ns'], 2)} | `{x['startpoint']}` | `{x['endpoint']}` | {x['logic_depth']} |")
            L.append("")
    au = read_json(rd / "constraint_audit.json")
    if au:
        L.append(f"### Constraint audit — {au['overall']} {au['counts']}")
        L.append("")
        L += ["| id | status | check | evidence |", "|---|---|---|---|"]
        for c in au["checks"]:
            L.append(f"| {c['id']} | {c['status']} | {c['title']} | {c['evidence'][:140]} |")
        L.append("")
    imp = read_json(rd / "constraint_analysis" / "exception_impact.json")
    if imp:
        L += ["Exception impact:", "", "| id | type | verdict | endpoints | endpoint pin kinds |", "|---|---|---|---|---|"]
        for r in imp:
            L.append(f"| {r['id']} | {r['type']} | {r['verdict']} | {r['endpoints_covered']} | {r.get('endpoint_kinds')} |")
        L.append("")
    cdc = read_json(rd / "constraint_analysis" / "cdc.json")
    if cdc:
        L.append(f"CDC/RDC (structural): **{cdc['status']}**")
        L.append("")
        L += ["| from → to | relationship | crossings | classes | status |", "|---|---|---|---|---|"]
        for p in cdc["clock_pairs"]:
            if p["crossings"]:
                L.append(f"| {p['from']} → {p['to']} | {p['relationship']} | {p['crossings']} | {p['by_class']} | {p['status']} |")
        for a in cdc["async_inputs"]:
            L.append(f"| port {a['port_report']} | async input | {a['first_registers']} | {a['by_class']} | {a['status']} |")
        L.append("")
        L += ["| reset source | launch clock | capture clocks | endpoints | release |", "|---|---|---|---|---|"]
        for r in cdc["rdc"]:
            L.append(f"| `{r['reset_source']}` | {r['launch_clock']} | {r['capture_clocks']} | {r['endpoints']} | {r['release']} |")
        L.append("")
    gt = read_json(rd / "gates.json")
    if gt:
        L.append(f"### Signoff gates — {gt['signoff']}")
        L.append("")
        L += ["| gate | status | evidence |", "|---|---|---|"]
        for x in gt["gates"]:
            L.append(f"| G{x['gate']} {x['title']} | {x['status']} | {x['evidence'][:160]} |")
        L.append("")
    return L


def sram_section() -> list[str]:
    L = ["## SRAM macro timing from the vendor Liberty (experiment D, part 1)", "",
         "| macro | corner | clock→DOUT min…max (ns) | launch edge | worst setup (ns) | worst hold (ns) | A_ADDR / A_DIN / A_WEN / A_MEN / A_BM setup (ns) | hold (ns) |",
         "|---|---|---|---|---|---|---|---|"]
    for pn, macros in (("ihp_sg13g2", ["RM_IHPSG13_1P_2048x64_c2_bm_bist", "RM_IHPSG13_1P_512x64_c2_bm_bist", "RM_IHPSG13_1P_256x64_c2_bm_bist"]),
                       ("sky130hd", ["sky130_sram_1rw1r_128x256_8"])):
        p = load_platform(pn)
        for r in sram.summarize(p, macros):
            if r["status"] != "OK":
                L.append(f"| {r['macro']} | {r['corner']} | {r['status']} | | | | | |")
                continue
            su, ho = r["setup_max_ns"], r["hold_max_ns"]
            keys = [k for k in ("A_ADDR", "A_DIN", "A_WEN", "A_MEN", "A_BM")] if "A_ADDR" in su else ["addr0", "din0", "web0", "csb0", "wmask0"]
            L.append(f"| {r['macro']} | {r['corner']} | {f(r['clk_to_q_min_ns'])} … {f(r['clk_to_q_max_ns'])} | {','.join(r['output_launch_edge'])} | "
                     f"{f(r['worst_setup_ns'])} | {f(r['worst_hold_ns'])} | {' / '.join(f(su.get(k)) for k in keys)} | {' / '.join(f(ho.get(k)) for k in keys)} |")
    L += ["", "Values are min/max over the characterised slew × load tables of each arc. The SKY130 OpenRAM Liberty "
          "reports a sub-nanosecond clock→dout launched on the falling edge; this is an unverified characterisation and is "
          "not used to support any frequency claim.", ""]
    return L


def tech_section() -> list[str]:
    L = ["## Technology comparison — SilicaFlux-V, identical RTL and constraints", "",
         "| platform | corners available | corners unavailable | cells | area (µm², incl. macros) | macros | reg2reg WNS typ / slow / fast (ns) | Fmax* typ (MHz) | SRAM read WNS (worst, ns) | worst hold (ns) | DRV slew/cap viol. (worst scene) |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    for pn in ("ihp_sg13g2", "sky130hd"):
        p = load_platform(pn)
        sm = summ("silicaflux_v", pn)
        syn = read_json(RUNS / "silicaflux_v" / pn / "baseline" / "synth" / "synth_summary.json") or {}
        if not sm or sm.get("status") != "PASS":
            L.append(f"| {pn} | {', '.join(p.corners)} | {'; '.join(u.name for u in p.unavailable_corners)} | — | — | — | NOT RUN | | | | |")
            continue
        func = {v["corner"]: v for k, v in sm["scenes"].items() if v["mode"] == "func"}
        r2r = " / ".join(f(func[c]["reg2reg"]["setup_wns_ns"]) if c in func else "n/a" for c in ("typ", "slow", "fast")) \
            if "typ" in func else " / ".join(f"{c}: {f(v['reg2reg']['setup_wns_ns'])}" for c, v in func.items())
        fm = next((v["reg2reg"].get("fmax_derived_mhz") for c, v in func.items() if c in ("typ", "tt")), None)
        sr = min((v["sram"]["read_setup_wns_ns"] for v in func.values() if v["sram"]["read_setup_wns_ns"] is not None), default=None)
        wh = min(v["whs_ns"] for v in func.values())
        dr = max(func.values(), key=lambda v: v["drv"].get("max_slew", {}).get("violators", 0))["drv"]
        L.append(f"| {pn} | {', '.join(p.corners)} | {'; '.join(u.name for u in p.unavailable_corners) or '—'} | {syn.get('n_cells')} | "
                 f"{f(syn.get('total_area_um2'), 0)} | {(syn.get('cell_classes') or {}).get('macros')} | {r2r} | {f(fm, 1)} | {f(sr)} | {f(wh)} | "
                 f"{dr.get('max_slew', {}).get('violators', 0)}/{dr.get('max_capacitance', {}).get('violators', 0)} |")
    L += ["| commercial 130 nm | NOT AVAILABLE | | | | | | | | | |", "| commercial 65 nm | NOT AVAILABLE | | | | | | | | | |",
          "| commercial 28 nm | NOT AVAILABLE | | | | | | | | | |", "",
          "Both open platforms are 130 nm-class; differences come from the cell libraries and SRAM macros (IHP compiled 64-bit "
          "macros vs SKY130 OpenRAM 32-bit 1RW1R macros), not from a node shrink.  SKY130 has only a TT corner here, so its "
          "result cannot support a multi-corner claim.  No result is scaled to another node.", ""]
    return L


def experiments_section() -> list[str]:
    L = ["## Experiments (real flow runs per candidate)", ""]
    for f_ in sorted((ROOT / "reports" / "experiments").glob("*/result.json")):
        e = json.loads(f_.read_text())
        L.append(f"### {e['name']} — {e['status']}{' (SENSITIVITY: constraint varied on purpose)' if e.get('sensitivity') else ''}")
        L.append("")
        L.append(e.get("description", ""))
        L.append("")
        L.append(f"Pareto objectives: {e.get('objectives')}; tolerances (differences treated as equal): {e.get('tolerances') or 'none'}.")
        L.append("")
        L += ["| candidate | status | reg2reg WNS (ns) | worst scene | WNS all groups (ns) | area (µm²) | cells | flops | Fmax* (MHz) | latency | Pareto | note / reject reason |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for c in e["candidates"]:
            L.append(f"| {c['label']} | {c['status']} | {f(c.get('reg2reg_setup_wns_ns'))} | {c.get('worst_scene', '—')} | {f(c.get('wns_ns'))} | "
                     f"{f(c.get('area_um2'), 0)} | {c.get('cells', '—')} | {c.get('flops', '—')} | {f(c.get('fmax_derived_mhz'), 1)} | "
                     f"{c.get('latency_cycles') or '—'} | {'★' if c.get('pareto') else ''} | {c.get('reject_reason') or c.get('note') or ''} |")
        if any(c.get("core_area_um2") for c in e["candidates"]):
            L += ["", "Physical area per candidate (OpenROAD stage metrics):", "",
                  "| candidate | placed cell area (µm²) | core utilisation | core area (µm²) | buffers+inverters |", "|---|---|---|---|---|"]
            for c in e["candidates"]:
                L.append(f"| {c['label']} | {f(c.get('placed_cell_area_um2'), 0)} | {f(c.get('core_utilisation'), 3)} | "
                         f"{f(c.get('core_area_um2'), 0)} | {c.get('buffers_inverters', '—')} |")
        wp = [c for c in e["candidates"] if c.get("worst_path")]
        if wp:
            L.append("")
            L.append("Limiting reg-to-reg path per candidate:")
            L.append("")
            for c in wp:
                p = c["worst_path"]
                L.append(f"* {c['label']}: `{p['startpoint']}` → `{p['endpoint']}` ({f(p['slack_ns'])} ns, depth {p['logic_depth']}, {p['owner_block']})")
        exf = Path(e.get("experiment_file", ""))
        focus = None
        if exf.exists():
            import yaml
            focus = (yaml.safe_load(exf.read_text()) or {}).get("focus_instance")
        if focus:
            L += ["", f"Worst clocked data path crossing `{focus}` per candidate (all scenes):", "",
                  "| candidate | scene | slack (ns) | delay inside `" + focus + "` (ns) | startpoint | endpoint | depth |",
                  "|---|---|---|---|---|---|---|"]
            for c in e["candidates"]:
                sm = summ(c["design"], c["platform"], c["run"], e.get("stage", "synthesis")) if c.get("run") else None
                rows = [(k, v["worst_through_block"][focus]["clocked"]) for k, v in (sm or {}).get("scenes", {}).items()
                        if (v.get("worst_through_block") or {}).get(focus, {}).get("clocked")]
                if not rows:
                    L.append(f"| {c['label']} | — | {'NOT RUN' if c['status'] != 'PASS' else 'no through-block data'} | | | | |")
                    continue
                k, x = min(rows, key=lambda r: r[1]["slack_ns"])
                L.append(f"| {c['label']} | {k} | {f(x['slack_ns'])} | {f(x['delay_inside_block_ns'], 2)} | `{x['startpoint']}` | `{x['endpoint']}` | {x['logic_depth']} |")
        if e.get("comparison"):
            cmp = e["comparison"]
            L.append("")
            L.append(f"Comparison {cmp.get('status')}: {cmp.get('reasons') or ''} area {cmp.get('area')}")
        L.append("")
    return L


if __name__ == "__main__":
    L = ["# Results (generated by scripts/make_results.py from runs/ — do not edit)", "",
         "All numbers below are read from OpenSTA/OpenROAD reports of executed runs.  Units: ns, µm², mW. "
         "POST-SYNTHESIS results use ideal clocks and no interconnect (pin capacitance only); they are not signoff.", ""]
    for name, d, p, *rest in (("SilicaFlux-V SoC", "silicaflux_v", "ihp_sg13g2"),
                       ("SilicaFlux-V + DataFabric SoC", "silicaflux_v_df", "ihp_sg13g2"),
                       ("SilicaFlux-V SoC (technology comparison)", "silicaflux_v", "sky130hd"),
                       ("CPU block", "blk_cpu", "ihp_sg13g2"),
                       ("CPU block — derived run: post-route of the margin-3 setup-repaired database", "blk_cpu", "ihp_sg13g2", "repaired_m3"),
                       ("Vector engine block", "blk_vec", "ihp_sg13g2"),
                       ("Tensor engine block", "blk_tensor", "ihp_sg13g2"), ("DMA block", "blk_dma", "ihp_sg13g2"),
                       ("SRAM Wrapper Library (sram_sp, IHP 256x64)", "blk_sramlib_ihp", "ihp_sg13g2"),
                       ("Reference design (NOT SilicaFlux)", "ref_gcd", "sky130hd")):
        run = rest[0] if rest else "baseline"
        if (RUNS / d / p / run).exists():
            L += design_section(name, d, p, run)
            df = RUNS / d / p / run / "DERIVED_FROM.md"
            if df.exists():
                L += ["Provenance of this derived run:", ""] + [x for x in df.read_text().splitlines() if not x.startswith("#")] + [""]
        else:
            L += [f"## {name} — `{d}` on `{p}` (run `{run}`): NOT RUN", ""]
    L += sram_section()
    L += tech_section()
    L += experiments_section()
    (ROOT / "docs" / "RESULTS.md").write_text("\n".join(L) + "\n")
    print("wrote docs/RESULTS.md", len(L), "lines")
