#!/usr/bin/env python3
"""Vendor the SilicaFlux RTL that TimingFlow analyses, unmodified, from the
repository archives (btcphilosopher/Aureom.AI, SilicaFlux-main/).

Every vendored file is byte-identical to its archive member.  The script
records the archive SHA-256, the member path and the file SHA-256 in
third_party/PROVENANCE.json and third_party/SHA256SUMS, so the intake can be
re-verified with ``sha256sum -c`` or ``python scripts/intake.py --verify``.

Usage:
    python scripts/intake.py --repo <path>/SilicaFlux-main [--verify]
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import sys
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TP = ROOT / "third_party"

# (vendored dir, archive relative to SilicaFlux-main, member prefix, include globs)
SOURCES = [
    ("silicaflux-v", "silicaflux-v-release1.zip", "silicaflux-v/",
     ["rtl/*", "asic/tech/*", "asic/constraints/*", "asic/configs/*",
      "reports/firmware/sfv_bootrom_image.sv", "docs/CLOCK_RESET.md",
      "docs/TOOL_VERSIONS.md", "docs/ISSUE_REGISTER.md", "docs/ACCELERATORS.md",
      "docs/ARCHITECTURE.md", "docs/BUS.md", "README.md"]),
    ("silicaflux-datafabric", "silicaflux-datafabric.zip", "silicaflux-datafabric/",
     ["rtl/*", "generated/sfb_memmap_pkg.sv", "README.md",
      "docs/datafabric/ARCHITECTURE.md", "docs/datafabric/PROTOCOL.md",
      "docs/datafabric/DMA.md", "docs/datafabric/ISSUES.md"]),
    ("silicaflux-sramlib", "SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip", "silicaflux-sramlib/",
     ["rtl/mem/*", "manifests/*", "README.md", "docs/mem/01_interface_spec.md",
      "docs/mem/02_backends_and_macros.md"]),
    ("silicaflux-v1", "silicaflux.zip", "silicaflux/",
     ["rtl/*", "synth/silicaflux.sdc", "README.md", "docs/ISA_REFERENCE.md"]),
]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def members(archive: Path):
    if archive.suffix == ".zip":
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                if not info.is_dir():
                    yield info.filename, z.read(info)
    else:
        with tarfile.open(archive) as t:
            for m in t.getmembers():
                if m.isfile():
                    yield m.name, t.extractfile(m).read()


def intake(repo: Path) -> dict:
    prov = {"repository": "btcphilosopher/Aureom.AI", "subdir": "SilicaFlux-main", "sources": []}
    sums = []
    for vdir, arch, prefix, globs in SOURCES:
        archive = repo / arch
        if not archive.exists():
            print(f"[intake] MISSING archive {archive}", file=sys.stderr)
            prov["sources"].append({"vendored": vdir, "archive": arch, "status": "MISSING"})
            continue
        adata = archive.read_bytes()
        entry = {"vendored": vdir, "archive": arch, "archive_sha256": sha256(adata),
                 "member_prefix": prefix, "files": []}
        for name, data in members(archive):
            # tolerate archives wrapped in an extra top directory
            idx = name.find(prefix)
            if idx < 0:
                continue
            rel = name[idx + len(prefix):]
            if not any(fnmatch.fnmatch(rel, g) for g in globs):
                continue
            dst = TP / vdir / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(data)
            h = sha256(data)
            entry["files"].append({"path": rel, "member": name, "sha256": h})
            sums.append(f"{h}  {vdir}/{rel}")
        entry["status"] = "OK"
        print(f"[intake] {vdir}: {len(entry['files'])} files from {arch}")
        prov["sources"].append(entry)
    (TP / "PROVENANCE.json").write_text(json.dumps(prov, indent=1) + "\n")
    (TP / "SHA256SUMS").write_text("\n".join(sorted(sums, key=lambda s: s[66:])) + "\n")
    return prov


def verify() -> int:
    bad = 0
    for line in (TP / "SHA256SUMS").read_text().splitlines():
        h, rel = line.split(None, 1)
        p = TP / rel.strip()
        if not p.exists() or sha256(p.read_bytes()) != h:
            print(f"[intake] MISMATCH {rel}")
            bad += 1
    print(f"[intake] verify: {'OK' if not bad else f'{bad} mismatches'}")
    return 1 if bad else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", type=Path, help="path to SilicaFlux-main")
    ap.add_argument("--verify", action="store_true")
    a = ap.parse_args()
    if a.verify:
        sys.exit(verify())
    if not a.repo:
        ap.error("--repo is required for intake")
    intake(a.repo.resolve())
    sys.exit(verify())
