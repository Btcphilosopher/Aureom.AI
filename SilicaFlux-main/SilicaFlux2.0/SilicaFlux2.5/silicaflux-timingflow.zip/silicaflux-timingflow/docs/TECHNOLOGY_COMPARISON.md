# Technology node comparison

| Platform | Status | Corners usable here | SRAM macros (Liberty) |
|---|---|---|---|
| IHP SG13G2 (130 nm SiGe BiCMOS, open) | AVAILABLE | typ 1.20 V 25 °C · slow 1.08 V 125 °C · fast 1.32 V −40 °C (SRAM fast −55 °C) | compiled RM_IHPSG13_1P_* in all three corners |
| SKY130 HD (130 nm, open) | AVAILABLE — TT only | tt 1.80 V 25 °C (SS/FF not in the ORFS collateral) | OpenRAM sky130_sram_1rw1r_* TT only |
| Commercial 130 nm | NOT AVAILABLE | — | — |
| Commercial 65 nm | NOT AVAILABLE | — | — |
| Commercial 28 nm | NOT AVAILABLE | — | — |

The measured comparison (same RTL, same constraints, same tools) is generated
in `docs/RESULTS.md` § *Technology comparison* from the runs
`runs/silicaflux_v/{ihp_sg13g2,sky130hd}/baseline`.  Rules applied:

* both open platforms are 130 nm-class — differences reflect libraries and SRAM
  macros, not a node shrink;
* a TT-only platform cannot support a multi-corner or signoff claim;
* no result is scaled numerically to another node; commercial rows stay NOT
  AVAILABLE until licensed collateral (Liberty per signoff corner, LEF, SRAM
  compiler outputs, extraction rules, foundry margins) is configured in
  `configs/platforms/` (requirements listed in `configs/platforms/commercial.yaml`).
