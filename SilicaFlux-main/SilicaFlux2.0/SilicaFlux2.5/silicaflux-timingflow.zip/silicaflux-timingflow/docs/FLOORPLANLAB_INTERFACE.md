# FloorplanLab (Project 05) / TwinLab integration

## What exists
`FloorplanLab` exists only as an Angular UI component inside TwinLab
(`silicaflux-twinlab/src/app/components/floorplan-lab/floorplan-lab.{ts,html}`).
It has no OpenROAD database, Tcl, DEF, LEF or placement output, so there is
nothing physical to reuse.  **Integration is therefore defined as an import
interface and is not claimed as complete.**

## Import interface (what TimingFlow accepts from a FloorplanLab run)
A FloorplanLab implementation run is consumed by placing its products in a
TimingFlow run directory; the stage scripts then analyse them instead of
re-implementing:

| File (in `runs/<design>/<platform>/<run>/`) | Producer | Consumed by |
|---|---|---|
| `synth/netlist.v` | the same Yosys recipe (or FloorplanLab's, with `synth_summary.json`) | every stage |
| `pnr/2_place.odb` | FloorplanLab placement | `tcl/sta_placement.tcl` (analysis-only) and `cts` |
| `pnr/3_cts.odb` | FloorplanLab CTS | `tcl/sta_cts.tcl`, `global_route` |
| `pnr/4_grt.odb` | FloorplanLab global route | `tcl/sta_global_route.tcl`, `postroute` |
| `pnr/5_route.odb` + `pnr/5_route_<corner>.spef` | FloorplanLab detailed route + extraction | `tcl/sta_postroute.tcl` |
| `floorplan.json` | `{"core_util": .., "aspect": .., "macro_placement": {inst: [x_um, y_um, orient]}, "platform": .., "process_profile_sha256": ..}` | recorded in provenance; G7 placement experiments |

Rules: one authoritative process profile per run (`configs/platforms/<pdk>.yaml`
— FloorplanLab must reference the same ORFS platform commit, checked through the
Liberty/LEF hashes in provenance); the analysis-only scripts refuse a stage
whose prerequisite database is missing; `timingflow run --stage placement|cts|...`
performs the same steps itself when FloorplanLab is absent.

## Reference test
`tests/test_gates_and_prereqs.py::test_physical_prereqs` checks the prerequisite
contract (a post-route request without `4_grt.odb` is NOT RUN).  The in-flow
OpenROAD stages are the standalone reference implementation of the interface.

## TwinLab / MemoryLab
TwinLab is an Angular visualisation app; MemoryLab is a Python
bandwidth/latency simulator.  TimingFlow exports `reports/<…>/timing_report.json`
(per-scene slack, derived reg2reg Fmax with its label, SRAM access timing) for
them to consume; no closed-loop performance evaluation was run.
