# Toolchain: revisions, how it was built, and revision-specific findings

Pinned revisions: `configs/tools.yaml`.  Reproduce: `scripts/setup_tools.sh`
(and `scripts/fetch_orfs.sh` for platform collateral).  Every run records the
versions it actually used in `summary.json → provenance.tools`.

| Tool | Revision | Source in the reference environment |
|---|---|---|
| Yosys | 0.33 (git 2584903a060) | Ubuntu 24.04 apt — same version used by every earlier SilicaFlux project, so results are comparable with their netlists |
| OpenSTA | 3.1.0, git 444cfc70 (2026-11-05) | built from source with CUDD 3.0.0 (ivmai/cudd f54f5333) |
| OpenROAD | 26Q4-1485-g40ab0df2bc (2026-11-01, last revision with a CMake build) | built from source (`/opt/eda/build_openroad_chain.sh`): OR-Tools v9.14 (BUILD_DEPS), SWIG 4.3.0, spdlog 1.15.0, LEMON (OpenROAD fork 1.3.1). **Build succeeded**; binary `/opt/eda/openroad/bin/openroad`, used for stages B–E and repair |
| OpenROAD-flow-scripts | 3f8ab4eb (2026-11-06) | sparse git checkout: IHP SG13G2, SKY130HD, SKY130 OpenRAM platforms, flow scripts, gcd reference |
| Verilator | 5.020 | apt |
| Icarus Verilog | 12.0 | apt |
| Python | 3.13 (≥3.12 required) | pydantic, numpy, pandas, matplotlib, plotly, PyYAML, pytest |

## Revision-specific behaviour found and handled
| Finding | Evidence | How TimingFlow handles it |
|---|---|---|
| OpenSTA 3.1.0 replaced corners by **scenes** (`define_scene -mode -liberty`); `define_corners` is deprecated | `help define_scene` | scene MCMM with fallback to `define_corners` (`tcl/load_corners.tcl`) |
| `set_ideal_network`, `set_ideal_latency`, `set_ideal_transition` are **parsed but ignored** | OpenSTA `doc/Commands.md` | lint rule L09 → audit C17 WARNING; never relied upon |
| Ideal clocks: timing checks use ideal latency at register clock pins, but `report_clock_latency`/`report_clock_skew` and min-pulse-width use the real (unbuffered) ICG output network | `search/Search.cc::clkPathArrival`; measured 7.59 ns "latency" at u_te flops pre-CTS while required times show 0 | pre-CTS skew/latency/pulse-width are labelled *indicative only*; they become gate criteria only post-CTS |
| `report_pulse_width_checks`, `report_unconstrained` do not exist | command probe | `report_check_types -min_pulse_width`, `check_setup -unconstrained_endpoints` |
| `sta::endpoint_violation_count` **segfaults** after `set_scene` | reproduced (exit 139) | violators counted from `report_checks -format end` per scene |
| `report_checks -format json` defaults to 3 significant digits; honours `-digits` | measured | all JSON reports use `-digits 6` |
| OpenSTA does **not** apply Liberty `default_wire_load` implicitly | WNS identical with/without; changes only with `set_wire_load_model` | stage A states "pin capacitance only"; `--wire-load` sensitivity option |
| Yosys 0.33 `dfflibmap`/`abc` have no `-dont_use` | yosys help | synthesis-only Liberty copy with `dont_use : true` (`liberty.mark_dont_use`) — the method older ORFS used |
| Yosys 0.33 **and 0.70** cannot parse SilicaFlux v1.0 `silicaflux_pkg.sv:218`: `return {{15{imm[16]}}, imm};`. Minimal repro: `function automatic logic [31:0] f(input logic [16:0] imm); return {{15{imm[16]}}, imm}; endfunction` fails, `f = {{15{imm[16]}}, imm};` parses | Yosys error (0.33 apt, 0.70 yowasp); Verilator 5.020 lints cleanly | Full SilicaFlux v1.0: synthesis BLOCKED under the pinned Yosys (no RTL edits) |
| `keep_hierarchy` patterns must match `$paramod\name\P=V` and `$paramod$hash\name` | yosys selection | both forms matched; module types renamed `name__p<hash>` after synthesis |
| IHP SRAM Liberty omits `;` after some simple attributes | `RM_IHPSG13_*` lines `when : "..."` | TimingFlow Liberty parser tolerates it |
| OpenROAD HEAD (pinned by ORFS HEAD) is **Bazel-only** since 2026-11-01 | OpenROAD `CMakeLists.txt` | last CMake revision 40ab0df2 built instead |
| OpenROAD build needs spdlog ≥1.15 and a C++20-clean LEMON; Ubuntu's spdlog 1.12 / LEMON 1.3.1 fail (fmt 12 collision; removed `allocator::construct`) | compiler errors in `or_build.log` | from-source spdlog 1.15.0 and OpenROAD's lemon-graph fork |
| ORFS marks `sg13g2_slgcp_1` (the ICG SilicaFlux-V instantiates) as DONT_USE | `ihp-sg13g2/config.mk` | explicit instantiation is legal; the cell is a real `latch_posedge_precontrol` ICG; recorded for review (resizer will not size it) |
| OpenROAD 40ab0df2 provides `rtl_macro_placer`; the older `macro_placement` command is absent | `tf::has` probe | `or_flow.tcl` uses whichever exists (probe order recorded in the log) |
| `cmake --install` of this revision fails on a missing generated file; the built binary is complete | `or_build.log` | `build/bin/openroad` copied to `/opt/eda/openroad/bin` |
| `repair_design` builds high-fanout trees from `sg13g2_buf_16` interleaved with `sg13g2_buf_1` "fanoutNNN" buffers; at the slow corner each buf_1 stage costs 0.46–0.66 ns (slew 0.53–0.82 ns) | `runs/blk_cpu/.../sta_placement/paths_r2r_setup_func_slow.rpt` | explains most of the CPU reg2reg loss at POST-PLACEMENT (slow): buffer-tree delay, not wire delay — recorded in RESULTS/FINAL_ANSWERS |
| Yosys 0.33 + ABC results for a kept module depend on the **rest of the design** (global object ordering): `sfv_vec_engine__p5336c1` (identical RTL and parameters) mapped to 62,311 vs 62,819 statements in the two experiment E candidates, which differ only in the crossbar's `ARB_MODE` | module-body hashes of `synth/netlist.v` in `runs/silicaflux_v_df/ihp_sg13g2/exp_e_*`; the same input reproduces bit-identically (G18) | measured stage-A noise floor ≈0.6 ns reg2reg (slow): experiments declare `tolerances` and the Pareto selection treats smaller differences as equal (`optimise.pareto`) |
