# TimingFlow stages, prerequisites and parasitic models

| Stage | Label in every report | Tool | Inputs (prerequisite) | Interconnect model | Clocks |
|---|---|---|---|---|---|
| `synth` | — | Yosys 0.33 | vendored RTL (`third_party/`, hash-verified) + synthesis-corner Liberty (dont_use applied) + macro Liberty as black boxes | — | — |
| A `synthesis` | **POST-SYNTHESIS** | OpenSTA 3.1.0 | `synth/netlist.v`, Liberty of every corner, generated SDC per mode | none: pin capacitance only (OpenSTA does not apply Liberty `default_wire_load` implicitly — verified). `--wire-load <model>` gives a labelled sensitivity run | ideal |
| `check_sdc` | — | OpenSTA + Python | netlist + generated SDC | — | — |
| B `placement` | **POST-PLACEMENT** | OpenROAD | `synth/netlist.v`, LEF/tech LEF, ORFS platform scripts | `estimate_parasitics -placement` | ideal (no insertion delay is invented) |
| C `cts` | **POST-CTS** | OpenROAD | `pnr/2_place.odb` | `estimate_parasitics -placement` | propagated (`set_propagated_clock`) |
| D `global_route` | **POST-GLOBAL-ROUTE** | OpenROAD | `pnr/3_cts.odb` | `estimate_parasitics -global_routing` | propagated |
| E `postroute` | **POST-ROUTE** | OpenROAD + OpenRCX | `pnr/4_grt.odb` → `detailed_route` → `extract_parasitics` → SPEF per corner | extracted SPEF | propagated |

A stage that lacks its prerequisite returns **NOT RUN** with the reason
(`timingflow/physical.py`, `tcl/sta_stage.tcl`, `tcl/repair_common.tcl`); a
post-route analysis can therefore never be run on a placement database, and
hold repair is refused before CTS.

## Command support is probed, not assumed
Every Tcl script sources `tcl/tf_util.tcl`; commands are checked with
`tf::require` / `tf::try_cmd` and the probe result is stored in each stage's
`tool_info.json`.  Findings for the pinned revisions are in `docs/TOOLS.md`
(e.g. `set_ideal_network` is parsed-but-ignored by OpenSTA 3.1.0, and
`sta::endpoint_violation_count` crashes after `set_scene`).

## Multi-corner / multi-mode
OpenSTA 3.1.0 replaces `define_corners` with **scenes** (`define_scene
<name> -mode <sdc mode> -liberty <files>`).  TimingFlow reads one SDC per mode
(`read_sdc -mode`) and defines one scene per mode × corner, so every report
(`report_checks -scenes`, per-scene WNS/TNS via `sta::worst_slack_scene`) is
attributed to its corner and mode.  Older revisions fall back to
`define_corners` + `read_liberty -corner` (single mode) automatically.

Setup and hold are analysed in **every** scene — TimingFlow does not assume
setup is only critical at the slow corner or hold only at the fast corner.

## Synthesis recipe (stage A input)
`timingflow/synth.py`: `read_liberty -lib` (std + macros) → `read_verilog -sv`
→ `hierarchy -check` → `setattr keep_hierarchy` on block modules → `synth
-flatten` (kept blocks stay hierarchical) → latch listing → `dfflibmap` →
`rename -wire -suffix _reg` (registers carry their RTL names) → `abc -script
ORFS abc_speed.script -D <period>` → tie cells, `insbuf`, `check`, `stat`,
`write_verilog`.  Module *types* of parameterised blocks are renamed
`<module>__p<hash>`; the mapping is in `synth_summary.json`.

The ORFS ABC script performs buffering and sizing (`buffer -c; upsize; dnsize`)
inside combinational logic only.  Nets that leave a kept hierarchy and drive
sequential pins directly (e.g. the system reset tree) remain unbuffered until
OpenROAD `repair_design` (stage B).  Stage A therefore reports those paths and
flags the high-fanout nets; it does not pretend they are buffered.

`-D <period>` is passed, but the ORFS `abc_speed.script` used here does not
read the delay target (its commands carry no `-D`): experiment A produced
byte-identical CPU netlists (same SHA-256, `2ab142c5f87b5fef…`) at
20/15/12/10 ns, and experiment C identical tensor cell counts and areas.  The netlist
is therefore period-independent, and a period sweep at stage A is an exact
slack sensitivity (Fmax* identical across the sweep), not a re-synthesis.

## Run directory
```
runs/<design>/<platform>/<run>/
  manifest.json                 stage status + timestamps
  synth/  synth.ys yosys.log netlist.v stat.txt synth_summary.json lib/ (dont_use-marked Liberty)
  sdc/    <mode>_<pre|post>_cts.sdc  sdc_meta.json
  sta_synthesis/  run_vars.tcl sta.log tool_info.json check_setup_* clocks_* coverage_*
                  paths_{setup,hold,r2r_setup,r2r_hold,sram_rd_setup,sram_wr_setup,sram_wr_hold}_<scene>.{json,rpt}
                  ends_{setup,hold}_<scene>.rpt drv_* pulse_* async_* gating_* skew_* latency_* power_* metrics_*
                  applied_<mode>.sdc  summary.json
  constraint_analysis/  bare_<mode>.sdc impact_* cdc_* rdc_* exception_impact.json cdc.json
  constraint_audit.json  gates.json
  pnr/ (2_place.odb 3_cts.odb 4_grt.odb 5_route.odb 5_route_<corner>.spef)   sta_<stage>/ ...
```

## Repair is separate from the stages (by design)

Stages B–E report the database exactly as the stage left it: placement runs
`repair_design` (DRV, high fanout, reset tree), CTS runs hold repair, but
global route does **not** re-run `repair_design`/`repair_timing` as ORFS does.
Timing repair is a separate, controlled step (`timingflow repair`,
`tcl/repair_common.tcl`): iteration and buffer caps, optional
`--setup-margin`, optional `--drv-first` (re-run `repair_design` on the stage
parasitics first), a before/after snapshot of every scene, and rollback if the
opposite check degrades into a violation or placement becomes illegal.  The
repaired database is written next to the original (`*_repair_<kind>[tag].odb`);
to judge it on extracted parasitics it is routed as a *derived run* (see
`runs/blk_cpu/ihp_sg13g2/repaired_m3/DERIVED_FROM.md`).
