# Unresolved signoff dependencies

Nothing in this repository constitutes timing signoff.  What remains, in the
order it blocks production signoff of SilicaFlux-V / DataFabric:

## Implementation
1. **Physical implementation of the SoCs through detailed routing and
   extraction** (stages B–E) on the chosen PDK, with the reset tree buffered
   (`repair_design`), a clock tree built, hold repaired and post-route
   parasitics extracted per corner.  Post-route timing must then be re-run in
   every scene.  Status per stage: `docs/RESULTS.md` (NOT RUN entries are real).
   The CPU block (`sfv_cpu`) has been taken through all five stages on IHP
   SG13G2 (detailed route with 0 DRC violations, OpenRCX SPEF per corner);
   it is the only design with POST-ROUTE results.
1a. **CPU block post-route closure** (`runs/blk_cpu/ihp_sg13g2/baseline`):
   setup fails only on block outputs `rt_rd_wdata[*]` against an *assumed*
   block budget (−2.30 ns slow), and one max-fanout violation remains on the
   CTS root buffer `clkbuf_0_clk` (fanout 16 vs the IHP Liberty
   `default_max_fanout : 8`; OpenROAD CTS does not honour it).  The critical
   path at every stage is a linear buffer chain distributing one register bit
   (ABC `buffer -c` buf_16 cells interleaved with `repair_design` buf_1 fanout
   buffers, 7.8 ns of a 17.1 ns path at slow); a controlled
   `repair_timing -setup_margin 3` closes it (see RESULTS, derived run
   `repaired_m3`).  The block budget must be replaced by the SoC-level
   context before G13 can be judged.
1b. **SilicaFlux-V SoC physical status** (`runs/silicaflux_v/ihp_sg13g2/baseline`):
   placement, CTS and global route PASS as stages; detailed route + RCX NOT RUN
   (a 102k-cell, 12-macro detailed route did not fit this session's runtime).
   At POST-GLOBAL-ROUTE the SoC does **not** close at slow: setup −7.388 ns
   (1,699 endpoints) on CPU-launched bus accesses (register-file read address →
   `u_xbar` → `u_pbr` → accelerator/peripheral CSR); SRAM macro input setup
   −6.90 ns caused by 6–12 ns slews on long `u_tile`→macro nets (max-slew 297,
   max-cap 115 violators at slow); hold −0.97 ns at fast (76 endpoints, mbist /
   arbitration → macro `A_ADDR`) because the macro `A_CLK` pins are the latest
   clock branch (clock spread 1.95 ns at slow under global-route parasitics).
   Needed: post-GRT `repair_design` + `repair_timing` (a controlled
   `--drv-first` repair was attempted and stopped after 45 CPU-minutes inside
   `repair_design` with global-route parasitics — NOT COMPLETED, no database
   written; run it with placement parasitics + incremental GRT as ORFS does, or
   on a larger machine), CTS balancing of macro clock pins, macro placement that
   shortens TSPM→macro nets, and a decision on registering the peripheral
   bridge read path.
2. **Reset distribution**: `sys_rst_n` (func) and RST_N (test mode) drive
   >2,000 asynchronous reset pins from one cell; recovery fails by 40–47 ns
   before buffering.  **Resolved by buffering in the physical flow**: after
   `repair_design` recovery is positive in every scene (+12.5 / +5.6 ns at
   POST-GLOBAL-ROUTE slow, func/test).  Removal/recovery must be re-checked on
   extracted post-route parasitics.
3. **SRAM macro hold**: macro input hold requirements (≤1.38 ns slow) exceed
   direct register→macro path delays.  Post-CTS hold repair closed it with
   placement parasitics (+0.004 ns fast, 52 buffers), but it re-opens under
   global-route parasitics (−0.97 ns fast) because of the macro clock-pin
   latency; needs hold repair on routed parasitics after CTS balancing.
4. **Macro placement / floorplan** for 8 × 2048×64 + 4 × 512×64 IHP macros; the
   SRAM→vector read path (worst reg2reg) is placement-sensitive.

## Constraints and evidence
5. **IO timing**: every board-level assumption is ASSUMED_UNREVIEWED (no board,
   flash part or JTAG probe selected).  Replace with datasheet/board values.
6. **Exception approvals**: EXC-SFV-001…007 are PENDING_REVIEW with unassigned
   owners; Gate 6 fails until each is approved by a named engineer.
7. **CDC**: fix R1 (`cpu_sleep` combinational into a TCK synchroniser), review
   R2 (UART RX loopback mux before the synchroniser), and link protocol/formal
   evidence for the SBA toggle handshake (1,700+ quasi-static crossing
   endpoints) before EXC-SFV-001 can be approved.  STA cannot prove CDC.
8. **Synchroniser cells**: `sfv_sync` should become the library's
   characterised synchroniser cell with dont_touch (release ISS-008).
9. **Async outputs** (`cpu_sleep`, GPIO, UART TX, status): glitch-freedom review;
   `cpu_sleep` has 4.6–7.5 ns of logic after its register.

## Libraries, corners, tools
10. **Corners**: IHP SG13G2 provides typ/slow/fast for stdcells, IO and SRAM, but
    the SRAM fast corner is characterised at −55 °C vs −40 °C for stdcells/IO
    (C03).  SKY130 is TT-only in the available collateral (SS/FF NOT AVAILABLE),
    so no SKY130 result can pass Gate 16.
11. **Foundry signoff methodology**: OCV/AOCV/POCV derates, clock uncertainty
    budgets, SI/crosstalk, EM/IR-aware timing and the foundry's required
    corner list are not available.  OpenSTA/OpenROAD are not a
    foundry-approved signoff flow.
12. **Commercial 130/65/28 nm**: NOT AVAILABLE (no licensed collateral); no
    result is rescaled from another node.
13. **Full SilicaFlux v1.0**: synthesis blocked by the Yosys `return {…}`
    limitation (docs/TOOLS.md) — needs an approved equivalent RTL rewrite or a
    Yosys fix.
14. **MCU-I**: does not exist in the repository.
15. **Power**: only vectorless estimates (input activity 0.1); signoff power
    needs simulation activity (VCD/SAIF) from the firmware regressions.
