# Constraints: generation, IO assumptions, modes, validation

## Generated SDC (`timingflow/sdc_gen.py`)
One SDC per **(design, mode, stage class)**, deterministic, no timestamps,
header carries the digests of the configuration files it came from.  Edit the
YAML, never the SDC.

| Source | SDC produced |
|---|---|
| `configs/designs/<d>.yaml: clocks` | `create_clock` on the real port, period from config (**a requirement, not a result**), duty |
| `generated_clocks` (only with RTL evidence of divider logic) | `create_generated_clock -source -master_clock -divide_by` |
| `uncertainty` | pre-CTS: jitter + skew allowance; post-CTS: jitter only and `set_propagated_clock [all_clocks]` |
| `ideal_transition_ns` | `set_clock_transition` (pre-CTS only) |
| platform `io:` | `set_driving_cell` = pad receiver cell, `set_load -pin_load` = max over analysed corners of the pad driver input capacitance, read from the IO Liberty |
| `configs/io/<d>.yaml` | `set_input_delay` / `set_output_delay` per interface (max and min, edge-specific); async / reset / static ports are covered by registry exceptions or case analysis |
| `configs/exceptions/<d>.yaml` | exceptions with `-comment "<ID>"`, filtered by mode; REJECTED entries skipped |

No port receives a silent zero delay: every top-level port bit must match an
IO group in every mode, otherwise the SDC lists it as **UNCOVERED** and audit
check C12 FAILs.  Missing max/min on a synchronous interface is reported as
*insufficiently constrained*.

### SilicaFlux-V clocking facts used (all from RTL)
* `clk` — single system clock pin, no PLL (`docs/CLOCK_RESET.md` of the release).
* `tck` — JTAG; TDO launched on the falling edge (`rtl/debug/sfv_jtag.sv`).
* `gclk_ve`, `gclk_te` — outputs of library ICG cells (`sg13g2_slgcp_1` /
  `sky130_fd_sc_hd__sdlclkp_1`): **gated clocks, not generated clocks**.  The
  cells carry `clock_gating_integrated_cell` and GATE setup/hold arcs, so the
  gating checks come from the library.
* `spi_sck` — divided functional clock driven off-chip:
  `sck <= ~sck` every DIV+1 cycles (`rtl/periph/sfv_spi.sv`), modelled as
  `create_generated_clock -divide_by 2` (DIV=0 worst case) at the port so SPI
  IO delays reference the clock the flash actually sees.
* UART baud divider, timer prescalers — **clock enables**, no generated clock.

### Modes
| mode | status | definition |
|---|---|---|
| `func` | DEFINED | `test_mode`=0 (EXC-SFV-005), clocks clk, tck, spi_sck |
| `test` | DEFINED | `test_mode`=1 (EXC-SFV-006): ICGs forced open, reset synchronisers bypassed to RST_N (RST_N then timed as a synchronous tester input) |
| `debug` | NOT APPLICABLE | JTAG access is concurrent with `func`; no separate clocking/muxing in RTL |
| `low_power` | NOT APPLICABLE | no DVFS / power domains; ICG + WFI are functional behaviour |

## IO assumptions (`configs/io/silicaflux_v.yaml`)
Status **ASSUMED_UNREVIEWED**: no board, flash part or debug probe is selected
in the repository.  Each interface states its derivation (flash tV/tHO,
setup/hold, probe skew, board trace delay).  Audit check C13 stays WARNING and
signoff gate 6/16 cannot pass until an owner replaces them with datasheet
values.  Block experiments use `configs/io/block_budget.yaml` (30 % of the
cycle on each side), explicitly labelled *block-budget*.

## Constraint audit (`timingflow/constraints.py`)
Statuses: PASS · WARNING · FAIL · NOT APPLICABLE · NOT RUN.

| id | check | evidence |
|---|---|---|
| C01 | every corner's Liberty present | file existence per corner |
| C02 | SRAM macro timing models present; nothing unlinked | macro Liberty per corner + `link_design` log |
| C03 | PVT consistency inside a corner | nominal T/V of stdcell vs IO vs macro Liberty |
| C04 | every register clocked; clocks on real sources | `check_setup -no_clock`, `clocks_<mode>.json` |
| C05 | clock periods equal configured targets | tool-reported period vs config |
| C06 | no duplicate clocks | static lint L01 |
| C07 | generated clocks valid | `check_setup -generated_clocks`, lint L06, RTL evidence |
| C08 | all object/clock references resolve (no empty collections) | `read_sdc` warnings in `sta.log` (read with `sta_continue_on_error 1` so every bad reference is seen) |
| C09–C11 | no unconstrained endpoints / inputs / outputs | `check_setup`, each item cross-checked with the IO kind (clock/async/reset/static → WARNING *justified*; otherwise FAIL) |
| C12 | every port bit has an IO assumption in every mode | SDC generator coverage vs netlist ports |
| C13 | IO assumptions reviewed | IO file status |
| C14 | IO delays consistent (min ≤ max < period, both present) | IO file |
| C15 | no conflicting exceptions | lint L14 |
| C16 | no unbounded / design-wide exceptions | lint L06/L07 |
| C17 | no unsupported / parsed-but-ignored commands | lint L09/L10 |
| C18 | every multicycle has setup **and** hold | lint L11 |
| C19 | no combinational loops | `check_setup -loops` |
| C20 | one clock per register clock pin per mode | `check_setup -multiple_clock` |
| C21 | exceptions do not hide functional paths | exception-impact analysis (endpoint pin classes from Liberty) |
| C22 | asynchronous clock groups backed by structural CDC evidence | `cdc.json` |
| C23 | reset release synchronous in every reset domain | recovery/removal paths without exceptions |
| X01–X04 | registry completeness, wildcard scope, approval, change-since-review | `configs/exceptions/*.yaml` |

`timingflow lint-sdc <files>` applies the static rules to any SDC, including
the repository's legacy ones (findings in `docs/AUDIT.md` §3).
