# Timing signoff gates

`python -m timingflow gates --design <d> --platform <p>` (`timingflow/gates.py`)
evaluates the 18 gates from executed evidence only.  A gate whose evidence was
not produced is **NOT RUN**, never PASS.

| Gate | Criterion | Evidence used | Pass rule |
|---|---|---|---|
| 1 | RTL elaboration successful | Yosys `hierarchy -check` inside synthesis | synthesis status PASS |
| 2 | Synthesis successful | `synth_summary.json` | PASS, 0 inferred latches, 0 `check` warnings |
| 3 | Required timing libraries loaded | audit C01, C02 | both PASS (C03 PVT mismatch is reported, not gating) |
| 4 | Primary and generated clocks validated | C04–C08 | no FAIL |
| 5 | All required endpoints constrained | C09–C12 | no FAIL; WARNING only when every reported item is justified by a documented IO kind |
| 6 | Timing exceptions reviewed | X01, C21, registry approvals | no FAIL **and every applied exception APPROVED** |
| 7 | Pre-placement analysis completed | `sta_synthesis/summary.json` | stage PASS |
| 8 | Post-placement analysis completed | `sta_placement/summary.json` | stage PASS |
| 9 | Clock-tree synthesis completed | `sta_cts/run_result.json` | PASS |
| 10 | Post-CTS timing analysed | `sta_cts/summary.json` | PASS |
| 11 | Global-route timing analysed | `sta_global_route/summary.json` | PASS |
| 12 | Detailed routing and extraction completed | `sta_postroute/summary.json` (needs SPEF) | PASS |
| 13 | Required setup checks pass | **POST-ROUTE** scenes only | worst setup slack ≥ 0 ns in every scene |
| 14 | Required hold checks pass | POST-ROUTE scenes only | worst hold slack ≥ 0 ns in every scene |
| 15 | Library checks pass | POST-ROUTE DRV + min pulse width | 0 violators |
| 16 | Required corners and modes pass | POST-ROUTE scenes + platform corner availability | all scenes clean **and** no required corner unavailable |
| 17 | CDC/RDC evidence linked | C22, C23 | both PASS (structural) — protocol evidence must also be linked in the registry before approval |
| 18 | Report package reproducible | provenance completeness + `timingflow repro` (bit-identical netlist hash and metrics on re-run) | both |

Thresholds (`gates.THRESHOLDS`): setup ≥ 0 ns, hold ≥ 0 ns, 0 DRV and
pulse-width violators — **project thresholds**.  No foundry signoff margins,
OCV/AOCV/POCV derates, SI/crosstalk analysis, or EM/IR-aware timing are
available to this project; OpenSTA/OpenROAD results are not equivalent to a
foundry-approved signoff flow.  Positive slack in one typical corner, or at
any stage before POST-ROUTE, can never pass gates 13–16.
