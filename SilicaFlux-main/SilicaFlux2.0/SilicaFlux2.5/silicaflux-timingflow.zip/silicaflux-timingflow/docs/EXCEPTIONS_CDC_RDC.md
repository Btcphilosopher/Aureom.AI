# Timing exceptions, CDC and RDC

## Registry rules (`configs/exceptions/<design>.yaml`)
Every entry has: unique id, type, modes, from/through/to (typed references
`port:` `pin:` `cell:` `clock:` `net:`), reason, RTL evidence, verification
evidence, owner, approval (`PROPOSED | PENDING_REVIEW | APPROVED | REJECTED`),
date, design revision.  Enforced by `constraints.registry_checks` and the lint:

* malformed or unresolvable references, unknown clocks/modes → FAIL (X01)
* CDC/RDC types (`clock_groups_async`, `false_path`) without verification evidence → FAIL
* multicycle without **both** setup and hold multipliers (and `-start/-end` references) → FAIL
* unbounded or design-wide (`all_registers`, `*`) exceptions → FAIL (C16)
* wildcards → WARNING until the impact report proves their scope (X02)
* anything not APPROVED → signoff gate 6 FAILS (X03)
* registry file changed since the last review stamp (`<design>.reviewed` holding its sha256) → WARNING (X04); CI shows the diff

### Exception impact (`tcl/constraint_analysis.tcl`)
The netlist is re-analysed with a **bare** SDC (all registry exceptions removed,
clocks/IO/case analysis kept).  For each exception, the paths its specification
covers are reported and every endpoint pin is classified from the Liberty
(`ff` group `clear`/`preset` pins = async set/reset; other register pins = data;
macro pins; ports; ICG enables; case-blocked combinational inputs).

| verdict rule | |
|---|---|
| `false_path` | PASS only if every covered endpoint is an async set/reset pin or a case-blocked input; any data/port/macro endpoint → **FAIL: hides functional paths** |
| `clock_groups_async` | REVIEW REQUIRED, with the number of hidden crossing endpoints; structure checked in `cdc.json` |
| `max_delay` / `multicycle` | PASS when it covers real paths (count reported), WARNING when it matches nothing |

## CDC (`timingflow/cdc.py`)
STA does not establish CDC correctness.  TimingFlow builds the clock-relationship
graph (same / generated-synchronous / asynchronous / unknown) and, for every
ordered clock pair, reports every crossing endpoint from the bare analysis.
Each crossing is classified **structurally on the netlist**, never by module
name:

| class | rule | status |
|---|---|---|
| `SYNC_2FF` | launch register → capture register with only buffers/inverters between, and the capture register's output drives exactly one register of the same clock (buffer chains followed) | PASS (structural) |
| `LOGIC_BEFORE_SYNC` | as above but combinational logic between the domains feeds a synchroniser first stage | **FAIL** (glitch can be captured) |
| `QUASI_STATIC_DATA` | crossing data consumed directly (not a synchroniser stage) | **REVIEW REQUIRED** — acceptable only with handshake/stability evidence (protocol, formal or simulation) linked in the registry |
| `IO_PORT` | endpoint is a port (IO timing, not CDC) | — |
| crossing between clocks with no declared relationship | | **FAIL** |

Asynchronous input ports (registry IO kind `async`) get the same first-stage
check.  Multi-bit groups (same source bus → same destination bus) are listed
so gray-code / handshake requirements are visible.

## RDC
Recovery/removal paths are analysed **without** the reset false path: each
reset source register/port, its launch clock and the clocks of the registers it
resets are tabulated.  A source whose release is not synchronous to every
capture clock is REVIEW REQUIRED (C23).  Asynchronous reset *assertion* from
the RST_N pin is covered by EXC-SFV-002, whose impact report must show only
async set/reset pins (it does — see RESULTS.md).
