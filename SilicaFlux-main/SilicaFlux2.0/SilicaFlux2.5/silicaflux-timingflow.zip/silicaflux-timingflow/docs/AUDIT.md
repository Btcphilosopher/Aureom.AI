# Source-backed timing-readiness audit

Repository: `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (166 files:
PDF reports, images, 30+ zip/tar archives, 33 loose `.sf` files).  Everything
below was established by opening the archives and running tools; nothing is
assumed from earlier prompts or reports.  Machine-generated per-module tables
(clocks, resets, `always_ff` counts, instances, elaboration and lint status)
are in `reports/audit/AUDIT_TABLES.md` and `reports/audit/audit.json`
(`make audit REPO=…/SilicaFlux-main`).

## 1. Requested targets — what actually exists

| Target | Status | Evidence |
|---|---|---|
| **SilicaFlux MCU-I** | **NOT FOUND** | no RTL, doc or config matching `MCU-I`/`mcu_i`/`mcu-i` in any archive (SV/V/MD/PY/YAML/JSON searched). `configs/designs/mcu_i.yaml` records this; nothing is invented. |
| **SilicaFlux-V** | IMPLEMENTED | `silicaflux-v-release1.zip` → `sfv_soc` (RV32I_Zicsr 2-stage CPU, 4-lane vector, 4×4 INT8 tensor, 128 KiB SRAM in 4 banks, 16 KiB TSPM, 3×7 SFB crossbar, UART/SPI/GPIO/timer/intc, JTAG, MBIST, ICGs). Yosys elaboration PASS, Verilator lint PASS, synthesis PASS (IHP SG13G2 and SKY130HD collateral). |
| **Full SilicaFlux** (v1.0 cluster) | PARTIAL — synthesis BLOCKED | `silicaflux.zip` → `silicaflux_top` (control core, scheduler, 4 tiles, 2×2 NoC, chiplet interface). Verilator lint PASS; **Yosys 0.33 and 0.70 reject `silicaflux_pkg.sv:218`** (`return {…}` concatenation; minimal repro in docs/TOOLS.md). No RTL is edited by TimingFlow. |
| **SilicaFlux DataFabric** | IMPLEMENTED | `silicaflux-datafabric.zip` → `sfv_soc_df` (SFB2 crossbar + DMA on SilicaFlux-V). Its README states no PDK synthesis/STA existed; TimingFlow provides the first. |
| **SRAM Wrapper Library** | IMPLEMENTED (ASIC backend partially characterisable) | `silicaflux-sramlib.zip` → `sram_sp/sram_1r1w/sram_tdp/bank controller` with GENERIC/FPGA/ASIC backends. Of the library's IHP macro catalogue only `RM_IHPSG13_1P_256x64` (and 1024x64/2048x64/…x64 geometries) have Liberty in the ORFS platform; the 32-bit-wide IHP macros used by its examples (`1024x32`, `2048x32`, `256x32`, 2P) have **no timing model available** → C02 would FAIL for those configurations. |
| Future vector/tensor accelerator configurations | NOT FOUND (beyond parameters) | only the SilicaFlux-V engines (parameters `LANES`, `MUL_W`) and v1.0 engines exist. |
| `.sf` files | SystemVerilog source, no compiler needed | all 33 `.sf` files contain `module`/`package`; `sfx_asm.py` assembles `.sfx` programs (ISA assembler), it is not an RTL translator. The loose `.sf` files are the SilicaFlux 2.5 RTL generation (separate from SilicaFlux-V). |
| FloorplanLab (Project 05) | NOT an OpenROAD flow | exists only as an Angular UI component (`silicaflux-twinlab/src/app/components/floorplan-lab/`). No OpenROAD database, script or placement result. See docs/FLOORPLANLAB_INTERFACE.md. |
| Technology collateral | none in repository | no `.lib/.lef/.odb/.def/.spef` in any archive. All collateral comes from pinned ORFS platforms. |

## 2. Earlier timing work found in the repository (and its status here)

| Artefact | What it contains | How TimingFlow treats it |
|---|---|---|
| `silicaflux-v-release1/reports/synth/{sky130hd,ihp_sg13g2,…}` | Yosys + OpenSTA/OpenROAD placement-estimate reports (litex-hub OpenROAD 2.0-12381, OpenSTA 2.5.0, typical corner only) | prior evidence, not reused as results; its `timing_max.rpt` shows the same unbuffered reset-recovery problem TimingFlow measures |
| `silicaflux-timinglab*.zip` | Python/Tcl flow for SilicaFlux v1.0 blocks with a headline Fmax table | the archive ships test fixtures but **no run reports backing the headline table**; treated as unverified claims |
| `asic/constraints/sfv_soc.sdc` (release) | clk/tck, async groups, 30 % IO budget on every port, false paths on `rst_ni`/`test_mode` | linted (§3); replaced by the generated, mode-specific SDC |
| `synth/silicaflux.sdc` (v1.0) | 100 MHz FPGA SDC | linted (§3) |
| `silicaflux-powerlink/openroad/pdn_*.tcl` | PDN scripts | not needed for timing; ORFS platform `pdn.tcl` is used |

## 3. Findings on the repository's existing SDC (`timingflow lint-sdc`)
* **v1.0 `silicaflux.sdc`**: five exceptions with no registry linkage; four use
  `get_cells -hierarchical -filter {NAME =~ *u_tif*…}` (tool/netlist-name
  dependent — they silently become empty collections after flattening/renaming);
  the IMEM multicycle has matching setup/hold but no functional justification;
  identical 2 ns / 0 ns IO budgets on unrelated interfaces.
* **SilicaFlux-V `sfv_soc.sdc`**: `set_false_path -from [get_ports test_mode]`
  instead of mode-specific case analysis; one 30 % budget for every port
  (UART/GPIO are asynchronous, SPI is source-synchronous to its own SCK);
  exceptions unregistered; `tck` async group without structural CDC evidence.

## 4. SilicaFlux-V clock, reset and register structure (from RTL)
| Item | Fact | Source |
|---|---|---|
| Primary clocks | `clk` (no PLL), `tck` (JTAG; TDO on falling edge) | `rtl/top/sfv_soc.sv`, `rtl/debug/sfv_jtag.sv` |
| Gated clocks | `gclk_ve`, `gclk_te` from library ICGs (`sg13g2_slgcp_1` / `sky130_fd_sc_hd__sdlclkp_1`); RTL fallback is a latch+AND model only for FPGA/simulation | `asic/tech/*/sfv_clkgate.sv`, `rtl/common/sfv_clkgate.sv` |
| Generated clock | `spi_sck` = clk/(2·(DIV+1)) driven off-chip | `rtl/periph/sfv_spi.sv` |
| Clock enables (not clocks) | UART baud divider, timer | `sfv_uart.sv`, `sfv_periph_misc.sv` |
| Resets | `por_rst_n`, `sys_rst_n`, `cpu_rst_n` via `sfv_rst_sync` (async assert, 2-stage sync release, test-mode bypass); TAP `trst_n` = RST_N | `rtl/common/sfv_common.sv`, `sfv_soc.sv` |
| Synchronisers | `sfv_sync` (2-flop) on GPIO, UART RX, straps, JTAG status/control | RTL; verified structurally by TimingFlow, not by name |
| Pipelines | CPU: 2 stages (release README); vector: issue → read-response → `rreg_q` with `CYCLES = 3 + B·P`; tensor: rank-1 update per 2 cycles, `CYCLES = 3 + 2K` | `docs/ACCELERATORS.md`, RTL |
| SRAM | 4 banks × 2 × `RM_IHPSG13_1P_2048x64` (IHP) / 36 × `sky130_sram_1rw1r_128x256_8` (SKY130); TSPM 4 × `RM_IHPSG13_1P_512x64`; read data muxed (lane/macro select) after the macro | `asic/tech/*/sfv_sram_macro_bank.sv` |

Per-module tables with every port count, edge and instance:
`reports/audit/AUDIT_TABLES.md` §B.

## 5. Timing-relevant RTL issues found by running the tools
| # | Issue | Evidence | Status |
|---|---|---|---|
| R1 | `cpu_sleep` is **combinational** (~20 logic levels in `sfv_cpu`) and is sampled by the TCK-domain synchroniser `u_dbg/u_s_slp` → glitches can be captured | CDC class LOGIC_BEFORE_SYNC, `cdc.json`; RTL `sfv_jtag.sv:166`, `sfv_soc.sv:124` | open — register `sleeping` in the clk domain first |
| R2 | UART RX loopback mux (`loop_q ? txd : rxd`) sits in front of the synchroniser first stage | `sfv_uart.sv:85`; CDC class LOGIC_BEFORE_SYNC | review (select is quasi-static; strict rule fails) |
| R3 | JTAG SBA command/result registers cross clk↔tck as multi-bit quasi-static data (1,702 + 33 endpoints) protected by a toggle handshake | `cdc.json` (QUASI_STATIC_DATA) | needs protocol/formal evidence before EXC-SFV-001 can be approved |
| R4 | `sys_rst_n` / test-mode RST_N drive >2,000 async reset pins from one cell — recovery fails by ~40–47 ns before buffering | stage A `asynchronous` group | **resolved in the physical flow**: after `repair_design` recovery is positive in every scene (+12.5 / +5.6 ns func/test at POST-GLOBAL-ROUTE slow); re-check on extracted parasitics |
| R5 | SRAM macro input hold (up to 1.38 ns at the slow corner) exceeds the direct register→macro path delay | SoC and SRAM-library stage A hold reports | closed by CTS hold repair (52 buffers, +0.004 ns fast) but **re-opens under global-route parasitics** (−0.97 ns fast) because the macro `A_CLK` pins are the latest clock branch (R11) |
| R6 | `cpu_sleep` output (async, bounded by EXC-SFV-004) has 4.6–7.5 ns of logic after its launching register — not glitch-free | path-delay group | review for an async output |
| R7 | v1.0 package uses `return {…}` that Yosys cannot parse | docs/TOOLS.md | blocks Full SilicaFlux synthesis |
| R8 | ORFS lists the instantiated ICG `sg13g2_slgcp_1` as DONT_USE | ORFS `ihp-sg13g2/config.mk` | legal for explicit instantiation; review with the platform owner |
| R9 | The CPU register file (`rf`, 32×32 flops, asynchronous read `rf[rs1]`, `rf[rs2]`, `sfv_cpu.sv:237-238`) is read through Yosys-merged address registers (`memory_dff`: "merged address FF to cell"); each 5-bit read address fans out to a 1,024-input mux tree | `_00003_`/`_00004_` registers launch the worst path of the CPU block (all stages) and of the SoC (POST-PLACEMENT onward) | buffer chains of weak buf_1 cells cost 6.6–7.8 ns at slow; a controlled `repair_timing -setup_margin 3` recovers 3.5 ns on the CPU block (verified post-route). RTL alternative (duplicated read-address registers) not needed so far |
| R10 | CPU loads/stores to accelerator and peripheral CSRs are single-cycle combinational round trips: CPU → `u_xbar` → peripheral bridge `u_pbr` → CSR read mux (`u_te`, `u_uart`, …) → `u_pbr/rdata_reg` | SoC worst path POST-PLACEMENT/CTS/GRT (−7.1 to −7.4 ns slow, 57–60 levels) | open — candidate fixes: post-GRT repair, or a registered bridge read (adds a wait state; ISA-invisible but changes bus latency, needs functional verification) |
| R11 | CTS leaves the SRAM macro clock pins as the latest branch: insertion delay spread 1.43 ns (POST-CTS) → 1.95 ns (POST-GLOBAL-ROUTE) at slow | `report_clock_skew` (macro `A_CLK` = source/target latency pins) | delays SRAM launches (setup) and breaks macro-input hold; needs macro clock-pin balancing in CTS |
| R12 | Long TSPM→macro nets in `u_tile` reach 6–12 ns slew under global-route parasitics (max-slew 297, max-cap 115 violators at slow) | POST-GLOBAL-ROUTE DRV report | needs post-GRT `repair_design` (controlled repair with `--drv-first`) and macro placement closer to the tile |
