# Engineering experiments A–G: method

All experiments run through `timingflow optimise --experiment configs/experiments/<x>.yaml`
(`timingflow/optimise.py`).  Each candidate gets its own run directory
(`runs/<design>/<platform>/exp_<name>_<label>/`) and is synthesised and timed by
the real tools with identical PDK, corners, constraints, exceptions and tool
revisions.  Candidates are REJECTED (with the reason) when they change a
constraint outside a labelled sensitivity experiment, violate a declared
architectural rule, fail a run, fail a functional check, or exceed an area
budget; the Pareto front is computed only over valid candidates.  Numeric
results are generated into `docs/RESULTS.md` § Experiments and
`reports/experiments/<name>/result.json`.

| Exp | Question | Design / knob | Kind | Why this form |
|---|---|---|---|---|
| A | What limits the CPU, and where? | `sfv_cpu`, period 20/15/12/10 ns | SENSITIVITY (constraint varied on purpose, labelled) | the CPU meets 20 ns with margin at stage A; tightening locates the limiting path class instead of "fixing" anything |
| B | Vector arithmetic timing; are cheaper datapaths valid? | `sfv_vec_engine` LANES=4/8, MUL_W=32/16 | architectural variants at fixed 20 ns | MUL_W<32 changes architected MUL/DOT results → REJECTED without a spec change; LANES=8 is legal for the engine but not integrable in SilicaFlux-V (tensor requires LANES=4) |
| C | Does the tensor MAC need more pipeline stages? | `sfv_tensor_engine`, period 20/15/12/10 ns | SENSITIVITY | the RTL has no pipeline-depth parameter; a pipelined MAC would change `CYCLES = 3 + 2K` and firmware-visible latency, so it is only justified if the sweep shows the MAC limiting the SoC target |
| D | Does SRAM access timing limit the clock? | IHP 2048×64 / 512×64 / 256×64, SKY130 OpenRAM | Liberty extraction (`timingflow/sram.py`) + in-context SRAM read/write path queries in every SoC/block STA | macro arcs come only from vendor Liberty; in-context slack comes from STA paths that start/end at macro pins |
| E | Does DataFabric arbitration create a critical path? | `sfv_soc_df` ARB_MODE=1 (round robin) vs 0 (fixed priority) | shipped, verified configurations at fixed constraints | both modes are verified by the DataFabric project; only timing/area are compared |
| F | Clock-tree skew / insertion delay | OpenROAD CTS (stage C) | measured from `report_clock_skew` / `report_clock_latency` on propagated clocks | requires OpenROAD CTS; pre-CTS numbers are not used |
| G | Timing sensitivity to placement alternatives | `sfv_cpu` core utilisation 30/45/60 % | physical knob, constraints fixed (stage B) | FloorplanLab has no physical flow; TimingFlow's own placement provides the alternatives |

Functional verification for RTL changes (lint → unit tests → integration
simulation → formal equivalence) is mandatory per the brief.  No experiment
here modifies RTL: A and C vary only the constraint (sensitivity), B/E vary
parameters of verified, shipped configurations (and B's ISA-visible variant is
rejected), G varies only placement.  Any future RTL variant (e.g. registering
the TSPM read data in the vector engine, or a pipelined MAC) must add a
`functional_check` command to its experiment file; without it the candidate
reports `functional: NOT RUN`.

## Pareto tolerances (synthesis noise floor)

Experiment E measured that Yosys/ABC maps an *unchanged* kept module
(`sfv_vec_engine`) differently when an unrelated module changes (global object
ordering), moving its reg2reg slack by 0.573 ns at slow.  Experiments may
therefore declare `tolerances:` per objective; `optimise.pareto` treats
differences below the tolerance as equal, so noise cannot create a Pareto
"winner".  `timingflow optimise --experiment X --rescore` recomputes metrics
and the front from existing runs without re-running any tool.

## Outcomes (numbers: docs/RESULTS.md § Experiments; summary here)

| Exp | Outcome |
|---|---|
| A | CPU netlist is identical at every period (abc_speed ignores `-D`), so the sweep is an exact sensitivity: POST-SYNTHESIS reg2reg Fmax* 146.0 MHz at slow; the limiting path is internal to the CPU (register file / decode). At POST-ROUTE (stage E, extracted) the same CPU block reaches reg2reg +2.263 ns at slow (Fmax* 56.4 MHz): the 10.9 ns lost between stages A and E at slow is almost entirely cell delay in high-fanout buffer chains (net delay on the post-route critical path 0.21 ns); a controlled `repair_timing -setup_margin 3` recovers 3.5 ns of it at POST-GLOBAL-ROUTE (derived run `repaired_m3`). |
| B | LANES=4 (shipped) +9.36 ns slow; LANES=8 −2.81 ns and +128.6 % area (fails 50 MHz at slow even before placement); MUL_W=16 REJECTED (changes architected MUL/DOT results). |
| C | Tensor netlist period-independent; POST-SYNTHESIS Fmax* 116.9 MHz at slow (MAC accumulate path). No pipeline stage justified at stage A; see the SoC physical results for the post-placement picture. |
| D | IHP macro clock→DOUT (slow) 8.88–9.29 ns (2048×64), 6.31–6.73 ns (512×64); SRAM-fed vector/tensor paths are the worst clocked paths at POST-SYNTHESIS (+4.52 / +5.08 ns slow). SKY130 OpenRAM launches `dout` on the falling edge (half-cycle SRAM paths, +1.33 ns TT at stage A). |
| E | Arbitration is not critical: worst clocked path crossing `u_xbar` +5.884 ns (RR) vs +5.918 ns (fixed), 1.09–1.12 ns spent inside the crossbar; DataFabric's own endpoints +9.07 / +8.73 ns. The 0.57 ns SoC-level reg2reg difference is synthesis noise in `sfv_vec_engine` (identical RTL), so both candidates are on the Pareto front; round robin (fairness) stays the recommendation. |
| F | CPU block CTS (stage C): insertion delay 0.38–0.62 ns fast, 0.50–0.76 typ, 0.72–0.99 slow; latency spread 0.24–0.27 ns; setup skew 0.34–0.36 ns; hold −0.80 ns (205 endpoints) repaired to +0.001 ns with 125 hold buffers. One max-fanout violation on the CTS root buffer remains (fanout 16 vs Liberty default 8). |
| G | CPU block POST-PLACEMENT at slow, identical netlist: core utilisation 30 / 45 / 60 % gives reg2reg +2.609 / +2.777 / +3.316 ns with core area 632,792 / 423,162 / 315,520 µm² and the same buffer count (2,678–2,682). The baseline at 40 % gave +2.927 ns, so placement variation is about ±0.3 ns. Over 30–60 % density changes slack by < 0.8 ns, and net delay on the worst path stays 0.16–0.36 ns: the CPU is buffer/cell-limited, not wire-limited. 60 % is the only Pareto point (best slack and smallest core). Floorplan density is not the lever; repair/sizing is (experiment A's margin repair: +3.5 ns). |
