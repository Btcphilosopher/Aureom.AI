# SilicaFlux DataFabric DMA (`silicaflux_dma`)

Single-channel memory-to-memory DMA. One SFB2 master port (crossbar master 3 in
`sfv_soc_df`), registers on peripheral page 6 (`0x4000_6000`), interrupt = INTC
source 8. The complete register table (offsets, fields, access, reset values) is
generated from the YAML into [MEMORY_MAP.md](MEMORY_MAP.md); this page defines the
behaviour.

| Configuration | `ENGINE` | Use |
|---|---|---|
| Simple (`dma_transfer_engine`) | 0 | **SilicaFlux-V production candidate.** One transaction in flight, one data register, 4 cycles/word with 1-cycle SRAM. |
| Buffered (`dma_burst_engine`) | 1 | Optional. FIFO_DEPTH 2..16, BURST, MAX_OUT 2, single or dual SFB2 port. |

## 1. Programming sequence

1. write `SRC_ADDR`, `DST_ADDR`, `LENGTH` (bytes);
2. optionally `INT_ENABLE` (bit 0 completion, bit 1 error);
3. write `CONTROL = START` (bit 0);
4. the DMA validates the descriptor, then reads source words and writes destination
   words autonomously — the CPU executes no load/store per copied word;
5. completion: `STATUS.BUSY` falls on the same edge on which `STATUS.DONE` or
   `STATUS.ERROR` rises (software never observes "not busy and no outcome");
   `INT_STATUS` bit set; level IRQ while `INT_STATUS & INT_ENABLE`.

## 2. Rules and validation (before any bus access)

| Check (first failing rule wins) | `ERROR_CODE` |
|---|---|
| `LENGTH == 0` | 1 ZERO_LENGTH |
| `LENGTH > 2^MAX_LEN_LOG2` (`INFO[23:16]`, 2^24 in SilicaFlux-V) | 2 LENGTH |
| `SRC_ADDR` not DW-aligned | 3 SRC_ALIGN |
| `DST_ADDR` not DW-aligned | 4 DST_ALIGN |
| `SRC_ADDR + LENGTH > 2^32` (range would wrap) | 5 SRC_OVERFLOW |
| `DST_ADDR + LENGTH > 2^32` | 6 DST_OVERFLOW |
| `[SRC, SRC+LEN)` and `[DST, DST+LEN)` intersect (incl. SRC == DST) | 7 OVERLAP |

* **Lengths are byte-accurate.** Source and destination must be DW-aligned (no
  byte-shifting datapath in version 1); the final, partial destination word is
  written with a strobe covering only bytes `< LENGTH`, so bytes after the end are
  never modified (checked by tests at every length 1..3·DW/8+1).
* The source's last word is read in full (it is inside the same aligned word, so
  inside the same region); only memory-like targets are therefore allowed.
* **Overlap is rejected** (version 1 does not implement memmove ordering).
* **Region legality is not known to the DMA.** An unmapped or protected address
  produces a bus error on first access: `ERROR_CODE` 8 READ_BUS / 9 WRITE_BUS,
  `ERROR_ADDR` = failing address. In `sfv_soc_df` the access matrix denies the DMA
  the whole peripheral window: MMIO side effects and access sizes of the
  peripherals have **not** been reviewed, so DMA to/from peripherals is not
  claimed. Reachable: SRAM (all banks), tile scratchpad (TSPM), boot ROM as source.

## 3. Busy-state protection

While `BUSY`: writes to `SRC_ADDR`, `DST_ADDR`, `LENGTH` and `CONTROL.START` are
**refused** — the register bus returns an error (CPU store access fault) and nothing
changes; the active transfer is never modified. A refused write has no effect at
all (a `START|ABORT` write while busy does not abort). Writes to read-only
registers and unmapped offsets also return an error. Reads have no side effects.

## 4. State machine (simple engine)

```
IDLE --START--> VALIDATE --ok--> ISSUE_READ --accept--> WAIT_READ --rsp ok--> ISSUE_WRITE
  ^                 | invalid          ^                     | rsp error           | accept
  |                 v                  |                     v                     v
  +-- ERROR <-------+------------------+---- (abort) ------ ERROR            WAIT_WRITE
  +-- COMPLETE <-- last beat written OK --------------------------------------- | rsp ok
                                       next beat: ISSUE_READ <------------------+
```

* exactly one bus transaction outstanding; request outputs are registered and held
  until accepted (SFB2 R2); `rsp_ready` = 1 in the WAIT states (the only states in
  which a response can arrive);
* a write is issued only with data from an error-free read of the same beat;
* **read error** → ERROR, no further write; **write error** → ERROR, no further
  request; `BYTES_DONE` is always the contiguous prefix whose writes completed;
* **abort** (`CONTROL.ABORT`, implemented): takes effect at the next beat boundary,
  after the outstanding transaction's response — the engine never withdraws a
  request. Status ERROR + ABORTED, code 10; `BYTES_DONE` tells how much was copied.
  If the abort races the final beat and every write completed, the transfer reports
  DONE;
* no timeout watchdog: a slave that never responds keeps the DMA busy, visible in
  `STATUS.STATE`, `ACTIVE_CYCLES` and `STALL_CYCLES`. A watchdog was deliberately not
  added — a slow slave is not faulty by assumption, and SilicaFlux-V slaves have
  bounded latency;
* reset (system reset domain) returns the engine to IDLE and clears all registers;
  no request is issued during or after reset until the next START (verified).

## 5. Buffered engine differences

* read issuer → FIFO → write issuer; a read is issued only when a FIFO slot is
  reserved for its data, so the response path never stalls (`rsp_ready` = 1);
* single port: READ and WRITE phases of up to `BURST` back-to-back single-beat
  transactions; the phase changes only when the port is idle. Dual port: reads on
  port 0 and writes on port 1 run concurrently;
* after a read error the beats before it are still written (same final memory as
  the simple engine); after a write error up to `MAX_OUT − 1` later beats may also
  have been written — `BYTES_DONE` still reports only the contiguous OK prefix;
* `STATUS.STATE` shows ISSUE_READ / ISSUE_WRITE for the phase.

## 6. Interrupts

`INT_STATUS[0]` completion, `[1]` error; set by the event (set wins over a
same-cycle write-one-to-clear), cleared by writing 1. `irq = |(INT_STATUS &
INT_ENABLE)`, level sensitive, INTC source 8 (claim value 9). Example ISR:
`firmware/drivers/silicaflux_dma.c: dma_isr()`.

## 7. Performance registers (`PERF = 1`)

`ACTIVE_CYCLES` (busy cycles of the current/last transfer), `STALL_CYCLES` (cycles a
request waited for acceptance — bus contention/back-pressure), `TRANSFERS`
(completed transfers since reset). 32-bit, wrap. Removing them (`PERF = 0`) saves
96 flops; the registers then answer with a bus error.

## 8. Measured performance (RTL, Verilator; `reports/datafabric/benchmark.md`)

See [PPA.md](PPA.md) for the sweep. In the SilicaFlux-V SoC (firmware D8): a 4 KiB
copy took 4,334 cycles including driver setup and polling, versus 9,219 cycles for
the CPU's word copy loop — with the CPU free during the DMA transfer.
