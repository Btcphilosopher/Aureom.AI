# Open issues and blockers (prioritised)

Severity: **H** blocks tape-out / product use, **M** should be closed before
integration sign-off, **L** improvement. DataFabric is **not tape-out ready**:
integrated-system verification is far from complete and no physical-design signoff
exists.

| ID | Sev | Area | Issue | Proposed action |
|---|---|---|---|---|
| DF-01 | H | physical design | No PDK / Liberty / OpenROAD in this environment: no placement, routing congestion, STA, IR-drop or power numbers for DataFabric. Area/depth figures are technology-independent proxies. | Run the SilicaFlux-V ASIC flow (`synth/asic/*.template`) with sky130/IHP SG13G2 first, then the licensed 130/65/28 nm PDKs. |
| DF-02 | H | timing | Longest generic-gate path is the DMA start-time validator (33-bit add/compare chain, ~81 levels) and, in the crossbar, decode → arbitration → ready (17–45 levels, growing with masters). Unknown against a real clock target. | Close timing in the real flow; if needed register `dma_validate` (one extra cycle per transfer) and/or add `sfb_reg_slice` on slave ports. |
| DF-03 | H | DFT | No scan insertion, no ATPG; DataFabric flops follow the SilicaFlux-V DFT rules (async reset bypass in test mode via `sfv_rst_sync`) but scan readiness was not checked by a DFT tool. | Include in the SilicaFlux-V scan/ATPG flow (release ISS list). |
| DF-04 | M | integration | SoC verification is firmware-level only: no random system-level stress with JTAG + CPU + DMA concurrently, no soft-reset-during-DMA scenario at SoC level (covered at unit level). | Add SoC random test: DMA loops while CPU runs acceptance app; soft reset / JTAG reset mid-transfer. |
| DF-05 | M | formal | DMA proofs are **bounded only**: no counterexample in 23 cycles (simple engine) / 22 cycles (buffered) with ABC bmc3. ABC PDR did not converge within 1,200 s for either engine (`reports/datafabric/formal.md`). This covers only the first ~4–5 beats of a transfer. No liveness proof: a never-responding slave keeps the DMA busy by design, with no watchdog. | Add abstraction (counter/datapath reduction) for unbounded DMA proofs; decide on an optional, explicitly specified watchdog. |
| DF-06 | M | MMIO DMA | DMA denied the peripheral window: peripheral side effects, sub-word restrictions and FIFO-style registers were not reviewed. | Review per peripheral, add fixed-address (non-incrementing) mode only with a reviewed use case (e.g. UART RX). |
| DF-07 | M | performance | Single outstanding transaction per port (SFB2 rev 2.0): pipelined slaves (READ_LATENCY ≥ 2) run at 1/latency of their bandwidth. | Implement the ID / multi-outstanding extension (PROTOCOL.md §8) only if a measured workload needs it. |
| DF-08 | M | area | The optional perf-counter page costs ~7.0 k NAND2-eq (≈ the crossbar itself). | Ship SilicaFlux-V with `PERF = 0`; keep the page for FPGA/bring-up builds. |
| DF-09 | M | security | Any bus master that can reach SRAM/TSPM can DMA to it; the access matrix is static. No privilege levels on the bus. | Out of scope for first silicon; revisit with secure boot (silicaflux-v ISS-016). |
| DF-10 | L | DMA features | Unaligned source/destination rejected (no byte-shifter); overlap rejected (no memmove); single channel; no 2-D/strided transfers; no descriptor chaining. | Add only with a workload that needs them (memoryflow `sf_dma` is the reference for 2-D/multi-channel). |
| DF-11 | L | accelerators | Vector/tensor engines are reached through the TSPM; the engines cannot initiate transfers (no stream interface). | Add an engine-done → DMA-start trigger if firmware overhead becomes measurable. |
| DF-12 | L | 1R1W SRAM | `sfb_sram_1r1w_slave` serialises reads and writes through one crossbar port; true 1R1W concurrency needs two ports. | Two crossbar ports (read-only + write-only alias) when a dual-port DMA uses such a macro. |
| DF-13 | L | MBIST | With `SRAM_IMPL = 1`, MBIST through `sfv_mbist` requires `SRAM_LATENCY = 1` (sfv_mbist's assumption). | Use the SRAM library's own MBIST adapter for other latencies. |
| DF-14 | L | tools | Yosys 0.33 front-end limits (no `int'()`, unsized `'1` parameter overrides become 1 bit) are documented and checked by GLS; SymbiYosys was not available. | Keep GLS in CI; move to a newer Yosys/sby when the ASIC flow is upgraded. |

## Resolved during this work (defects found by verification)

| ID | Found by | Defect | Fix |
|---|---|---|---|
| DF-R1 | SoC firmware regression (D3) | Driver `DMA_POLL_BUSY = 1` collided with `DMA_ERR_ZERO_LENGTH = 1`: `dma_wait()` spun forever on a finished transfer | `DMA_POLL_BUSY = 0x100` |
| DF-R2 | tb_dma STATUS checks | `done`/`fail` were registered pulses: one cycle with `BUSY = 0` and neither DONE nor ERROR | decoded from the terminal FSM state |
| DF-R3 | synthesis review | Unsized `'1` parameter overrides: Yosys enabled only master 0 → slave 0 (simulators correct) | sized literals everywhere; GLS added to the flow |
| DF-R4 | Yosys elaboration | `int'()` cast in the buffered engine rejected by Yosys 0.33 | width-explicit comparison |
| DF-R5 | mutation campaign | 3 testbench blind spots (slave over-subscription masked by the slave model; an unused error-slave output; skid second entry never exercised) | pipelined slave model, router uses the error flag, dedicated slice testbench — 12/12 mutants killed |
| DF-R6 | buffered-engine review | abort stopped `bytes_done` accounting for writes accepted before the abort; an abort racing the last beat reported ABORTED although all data was written | separate write-error flag; abort decided at the finish point |
| DF-R7 | SoC regression (JTAG boot of the grown demo image) | the release-1 testbench's JTAG loader copies a fixed 2,400 words (9.6 KiB); a larger image was silently truncated and crashed | `+jtag_words=` plusarg in `tb_soc_df` (default 2,400 keeps release-1 behaviour) |
