// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_sp
// Single-port (1RW) synchronous SRAM with a valid/ready request channel, an
// in-order valid/ready response channel and a raw MBIST test port.
//
// Interface contract (full text: docs/mem/01_interface_spec.md)
//   Addressing   word addresses, 0 .. DEPTH-1; AW = clog2(DEPTH).  Lane l of
//                wdata/rdata/wmask is bits [l*LW +: LW], LW = DATA_WIDTH /
//                MASK_WIDTH (little-endian lane order).
//   Request      transfer when req_valid && req_ready.  The master must keep
//                req_valid and the payload stable until accepted.
//   Read         response READ_LATENCY cycles after acceptance (no
//                backpressure), rsp_we = 0, rsp_rdata = word.
//   Write        lanes with wmask = 1 written at the acceptance edge; a read
//                accepted in a later cycle observes it.  WRITE_ACK = 1: one
//                response (rsp_we = 1, rsp_rdata = 0) per write; WRITE_ACK = 0:
//                posted (no response) unless the address is invalid.
//   Invalid addr req_addr >= DEPTH (only possible for non-power-of-two DEPTH):
//                accepted, no array access, response with rsp_err = 1.
//   Ordering     exactly one response per response-producing request, in
//                acceptance order, never dropped, duplicated or unsolicited.
//   Backpressure rsp_* stable while rsp_valid && !rsp_ready.  RSP_FIFO_DEPTH
//                bounds outstanding responses (credit); READ_LATENCY + 1
//                sustains one access per cycle; 0 = no backpressure allowed.
//   Reset        rst_n (async assert, sync release by the user) resets only
//                control state; req_ready = 0 in reset and the cycle after.
//                The array is not reset and has no defined content.
//   Test port    tst_active = 1 hands the array to the MBIST bus for as long
//                as it is high (req_ready forced 0; already accepted reads
//                still complete).  tst_ce/tst_we/tst_addr/tst_wdata are raw
//                array controls (all lanes written); tst_rdata is the raw
//                array output, valid exactly READ_LATENCY cycles after a test
//                read, never held.  Compatible with the TestCore collar bus.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_sp #(
  parameter int DATA_WIDTH     = 32,
  parameter int DEPTH          = 1024,
  parameter int MASK_WIDTH     = (DATA_WIDTH % 8 == 0) ? DATA_WIDTH / 8 : 1,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int WRITE_ACK      = 1,
  parameter int ID_WIDTH       = 1,
  parameter int TEST_EN        = 1,
  parameter     INIT_FILE      = "",
  localparam int AW            = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // request
  input  wire logic                  req_valid,
  output logic                       req_ready,
  input  wire logic                  req_we,
  input  wire logic [AW-1:0]         req_addr,
  input  wire logic [DATA_WIDTH-1:0] req_wdata,
  input  wire logic [MASK_WIDTH-1:0] req_wmask,
  input  wire logic [ID_WIDTH-1:0]   req_id,
  // response
  output logic                       rsp_valid,
  input  wire logic                  rsp_ready,
  output logic [DATA_WIDTH-1:0]      rsp_rdata,
  output logic                       rsp_err,
  output logic                       rsp_we,
  output logic [ID_WIDTH-1:0]        rsp_id,
  // MBIST test port
  input  wire logic                  tst_active,
  input  wire logic                  tst_ce,
  input  wire logic                  tst_we,
  input  wire logic [AW-1:0]         tst_addr,
  input  wire logic [DATA_WIDTH-1:0] tst_wdata,
  output logic [DATA_WIDTH-1:0]      tst_rdata,
  // status
  output logic                       busy
);

  if (WRITE_ACK != 0 && WRITE_ACK != 1) begin : g_err_write_ack_not_0_or_1
    `SRAM_CFG_FATAL("sram_sp: WRITE_ACK must be 0 or 1")
  end

  localparam bit POW2 = (DEPTH == (1 << AW));
  localparam logic [AW:0] DEPTH_W = (AW+1)'(DEPTH);    // DEPTH as an (AW+1)-bit value for address range checks

  // ------------------------------------------------------------ request decode
  logic addr_ok, needs_rsp, can_issue, accept, t_on, rst_n_live;

  // posted writes need no credit but must still respect reset release
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rst_n_live <= 1'b0;
    else        rst_n_live <= 1'b1;
  end

  assign t_on      = (TEST_EN != 0) && tst_active;
  assign addr_ok   = POW2 ? 1'b1 : ({1'b0, req_addr} < DEPTH_W);
  wire   tst_ok    = POW2 ? 1'b1 : ({1'b0, tst_addr} < DEPTH_W);
  assign needs_rsp = !req_we || (WRITE_ACK != 0) || !addr_ok;
  assign req_ready = !t_on && (can_issue || (!needs_rsp && rst_n_live));
  assign accept    = req_valid && req_ready;

  // ------------------------------------------------------------ array port mux
  logic                  a_ce, a_we;
  logic [MASK_WIDTH-1:0] a_wmask;
  logic [AW-1:0]         a_addr;
  logic [DATA_WIDTH-1:0] a_wdata, a_rdata;

  always_comb begin
    if (t_on) begin
      a_ce    = tst_ce && tst_ok;          // out-of-range test addresses never reach the array
      a_we    = tst_we;
      a_wmask = '1;
      a_addr  = tst_addr;
      a_wdata = tst_wdata;
    end else begin
      a_ce    = accept && addr_ok;
      a_we    = req_we;
      a_wmask = req_wmask;
      a_addr  = req_addr;
      a_wdata = req_wdata;
    end
  end

  sram_backend_1rw #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY),
    .BACKEND(BACKEND), .MACRO(MACRO), .INIT_FILE(INIT_FILE)
  ) u_array (
    .clk, .ce(a_ce), .we(a_we), .wmask(a_wmask), .addr(a_addr), .wdata(a_wdata), .rdata(a_rdata)
  );

  assign tst_rdata = (TEST_EN != 0) ? a_rdata : '0;

  // ------------------------------------------------------------ response path
  /* verilator lint_off UNUSEDSIGNAL */
  logic stg_valid, stg_rd;            // observed by assertions / debug only
  /* verilator lint_on UNUSEDSIGNAL */
  sram_rsp_path #(
    .DATA_WIDTH(DATA_WIDTH), .LATENCY(READ_LATENCY), .FIFO_DEPTH(RSP_FIFO_DEPTH), .ID_WIDTH(ID_WIDTH)
  ) u_rsp (
    .clk, .rst_n,
    .can_issue,
    .iss_valid(accept && needs_rsp), .iss_rd(!req_we && addr_ok), .iss_err(!addr_ok), .iss_we(req_we),
    .iss_id(req_id),
    .arr_rdata(a_rdata), .stg_valid, .stg_rd,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_we, .rsp_id,
    .busy
  );

`ifdef SRAMLIB_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      `SRAM_CHK(!(a_ce && {1'b0, a_addr} >= DEPTH_W), "array access beyond DEPTH")
      `SRAM_CHK(!(t_on && accept), "functional request accepted in test mode")
      if (TEST_EN != 0) begin
        `SRAM_CHK(!(tst_ce && !tst_active), "tst_ce asserted while tst_active is low")
      end
    end
  end
`endif

endmodule

`default_nettype wire
