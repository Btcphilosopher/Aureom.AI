## =============================================================================
## SilicaFlux SRAM Wrapper Library :: sram_fpga_selftest_top on Digilent Arty A7-100T
## Part: xc7a100tcsg324-1 (the target of the repository's existing
##       silicaflux/synth/vivado/synth.tcl and silicaflux_arty.xdc).
##
## Pin provenance
##   E3, C2, H5, J5 : as used by the repository's silicaflux_arty.xdc.
##   T9, T10, D10   : Digilent Arty A7 master XDC (LD6, LD7, uart_rxd_out).
## VERIFY every pin against the master XDC for your board revision before
## programming.  NOTE: the repository's silicaflux_arty.xdc comments E3 as a
## "12 MHz onboard crystal" but constrains it at 10 ns; the Arty A7 E3 input is
## documented by Digilent as the 100 MHz oscillator, which this file assumes.
## This flow has NOT been run in Vivado or on a board (no Vivado in the
## environment that produced it).
## =============================================================================

set_property -dict { PACKAGE_PIN E3  IOSTANDARD LVCMOS33 } [get_ports { clk }]
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports { clk }]

## red CK_RST push-button: active low
set_property -dict { PACKAGE_PIN C2  IOSTANDARD LVCMOS33 } [get_ports { rst_n_btn }]

## LD4..LD7
set_property -dict { PACKAGE_PIN H5  IOSTANDARD LVCMOS33 } [get_ports { led[0] }]
set_property -dict { PACKAGE_PIN J5  IOSTANDARD LVCMOS33 } [get_ports { led[1] }]
set_property -dict { PACKAGE_PIN T9  IOSTANDARD LVCMOS33 } [get_ports { led[2] }]
set_property -dict { PACKAGE_PIN T10 IOSTANDARD LVCMOS33 } [get_ports { led[3] }]

## USB-UART bridge: FPGA transmit -> host receive
set_property -dict { PACKAGE_PIN D10 IOSTANDARD LVCMOS33 } [get_ports { uart_tx }]

## asynchronous reset input and LED / UART outputs are not timed
set_false_path -from [get_ports { rst_n_btn }]
set_false_path -to   [get_ports { led[*] uart_tx }]
