// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_bank_controller
// NUM_MASTERS requesters x NUM_BANKS single-port (1RW) banks.
//
// Address map
//   ADDR_MODE = WORD: m_req_addr is a word address.  BYTE: a byte address;
//   the low log2(DATA_WIDTH/8) bits must be zero (else error response
//   "misaligned"); word = addr >> log2(DATA_WIDTH/8).
//   word >= NUM_BANKS * BANK_DEPTH -> error response "out of range".
//   INTERLEAVE = LOW  (default): bank = word % NUM_BANKS, row = word / NUM_BANKS
//              (sequential words rotate through the banks; NUM_BANKS power of 2)
//   INTERLEAVE = HIGH: bank = word / BANK_DEPTH, row = word % BANK_DEPTH
//              (contiguous regions per bank; BANK_DEPTH power of 2)
//
// Arbitration: each bank grants at most one master per cycle.
//   ARB = RR (default): rotating priority per bank, updated on every grant:
//     a master that keeps its request valid is granted within NUM_MASTERS
//     grants of that bank (starvation-free).  ARB = FIXED: master 0 highest
//     (documented: lower masters can starve under sustained contention).
//   A request is accepted (m_req_ready) in the cycle its bank grants it, so
//   acceptance == issue to the array.  Masters targeting different banks
//   proceed in parallel (up to min(NUM_MASTERS, NUM_BANKS) accesses/cycle).
//   Error requests need no bank and are accepted when the master has a
//   response credit.
//
// Responses: per master, in that master's acceptance order, each carrying the
// request's ID (m_rsp_id), READ_LATENCY cycles after acceptance when not
// back-pressured.  In-order delivery is by construction: every access
// (including error responses) takes exactly READ_LATENCY cycles and a master
// issues at most one request per cycle.  A per-bank owner pipeline routes the
// bank's read data to the master that issued it; assertions check that no
// response is dropped, duplicated or misrouted.
// No coherence protocol (none is required by the SilicaFlux RTL: the 2.5
// memory_controller only exports a write-notify hook).
//
// MBIST: tst_active blocks all functional traffic; banks with tst_sel[b] = 1
// execute tst_ce/tst_we/tst_addr (row)/tst_wdata (parallel test of identical
// banks is allowed); tst_rdata[b*DW +: DW] is bank b's raw output.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_bank_controller #(
  parameter int NUM_MASTERS    = 4,
  parameter int NUM_BANKS      = 4,
  parameter int DATA_WIDTH     = 32,
  parameter int MASK_WIDTH     = (DATA_WIDTH % 8 == 0) ? DATA_WIDTH / 8 : 1,
  parameter int BANK_DEPTH     = 1024,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int ARB            = `SRAM_ARB_RR,
  parameter int INTERLEAVE     = `SRAM_ILV_LOW,
  parameter int ADDR_MODE      = `SRAM_ADDR_WORD,
  parameter int ID_WIDTH       = 4,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int WRITE_ACK      = 1,
  parameter int TEST_EN        = 1,
  localparam int TOTAL         = NUM_BANKS * BANK_DEPTH,
  localparam int BOFF          = (ADDR_MODE == `SRAM_ADDR_BYTE && DATA_WIDTH >= 16) ? $clog2(DATA_WIDTH / 8) : 0,
  localparam int MIN_AW        = $clog2(TOTAL) + BOFF,
  parameter int ADDR_WIDTH     = MIN_AW,
  localparam int BW            = (NUM_BANKS > 1) ? $clog2(NUM_BANKS) : 1,
  localparam int RAW           = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int MW_           = (NUM_MASTERS > 1) ? $clog2(NUM_MASTERS) : 1
) (
  input  wire logic                              clk,
  input  wire logic                              rst_n,
  // masters (flattened: master m uses slice m)
  input  wire logic [NUM_MASTERS-1:0]            m_req_valid,
  output logic      [NUM_MASTERS-1:0]            m_req_ready,
  input  wire logic [NUM_MASTERS-1:0]            m_req_we,
  input  wire logic [NUM_MASTERS*ADDR_WIDTH-1:0] m_req_addr,
  input  wire logic [NUM_MASTERS*DATA_WIDTH-1:0] m_req_wdata,
  input  wire logic [NUM_MASTERS*MASK_WIDTH-1:0] m_req_wmask,
  input  wire logic [NUM_MASTERS*ID_WIDTH-1:0]   m_req_id,
  output logic      [NUM_MASTERS-1:0]            m_rsp_valid,
  input  wire logic [NUM_MASTERS-1:0]            m_rsp_ready,
  output logic      [NUM_MASTERS*DATA_WIDTH-1:0] m_rsp_rdata,
  output logic      [NUM_MASTERS-1:0]            m_rsp_err,
  output logic      [NUM_MASTERS-1:0]            m_rsp_we,
  output logic      [NUM_MASTERS*ID_WIDTH-1:0]   m_rsp_id,
  output logic      [NUM_MASTERS-1:0]            m_stall_conflict,   // lost bank arbitration (perf)
  // MBIST test port
  input  wire logic                              tst_active,
  input  wire logic [NUM_BANKS-1:0]              tst_sel,
  input  wire logic                              tst_ce,
  input  wire logic                              tst_we,
  input  wire logic [RAW-1:0]                    tst_addr,
  input  wire logic [DATA_WIDTH-1:0]             tst_wdata,
  output logic      [NUM_BANKS*DATA_WIDTH-1:0]   tst_rdata,
  output logic                                   busy
);

  // ------------------------------------------------------------ configuration checks
  if (NUM_MASTERS < 1 || NUM_MASTERS > 16) begin : g_err_num_masters_1_to_16
    `SRAM_CFG_FATAL("sram_bank_controller: NUM_MASTERS must be 1..16")
  end
  if (NUM_BANKS < 1 || (NUM_BANKS & (NUM_BANKS - 1)) != 0) begin : g_err_num_banks_not_power_of_2
    `SRAM_CFG_FATAL("sram_bank_controller: NUM_BANKS must be a power of two (1, 2, 4, 8, ...)")
  end
  if (INTERLEAVE == `SRAM_ILV_HIGH && (BANK_DEPTH & (BANK_DEPTH - 1)) != 0) begin : g_err_high_interleave_needs_pow2_bank_depth
    `SRAM_CFG_FATAL("sram_bank_controller: INTERLEAVE=HIGH requires a power-of-two BANK_DEPTH")
  end
  if (INTERLEAVE != `SRAM_ILV_LOW && INTERLEAVE != `SRAM_ILV_HIGH) begin : g_err_unknown_interleave
    `SRAM_CFG_FATAL("sram_bank_controller: unknown INTERLEAVE")
  end
  if (ADDR_MODE == `SRAM_ADDR_BYTE && (DATA_WIDTH % 8 != 0 || ((DATA_WIDTH / 8) & (DATA_WIDTH / 8 - 1)) != 0)) begin : g_err_byte_mode_needs_pow2_bytes
    `SRAM_CFG_FATAL("sram_bank_controller: ADDR_MODE=BYTE requires DATA_WIDTH/8 to be a power of two")
  end
  if (ADDR_WIDTH < MIN_AW) begin : g_err_addr_width_too_small
    `SRAM_CFG_FATAL("sram_bank_controller: ADDR_WIDTH cannot address NUM_BANKS*BANK_DEPTH words")
  end
  if (ARB != `SRAM_ARB_RR && ARB != `SRAM_ARB_FIXED) begin : g_err_unknown_arb
    `SRAM_CFG_FATAL("sram_bank_controller: unknown ARB policy")
  end

  logic t_on, live_q;
  assign t_on = (TEST_EN != 0) && tst_active;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_q <= 1'b0;
    else        live_q <= 1'b1;
  end

  // ------------------------------------------------------------ per-master decode
  localparam logic [ADDR_WIDTH:0] TOTAL_W = (ADDR_WIDTH+1)'(TOTAL);   // one extra bit: TOTAL may be 2**ADDR_WIDTH
  localparam logic [MW_-1:0] LAST_M = MW_'(NUM_MASTERS - 1);
  localparam logic [RAW:0]   BD_W   = (RAW+1)'(BANK_DEPTH);
  wire tst_row_ok = ({1'b0, tst_addr} < BD_W);
  logic [NUM_MASTERS-1:0] m_ok, m_need, m_credit, m_can;
  logic [BW-1:0]          m_bank [NUM_MASTERS];
  logic [RAW-1:0]         m_row  [NUM_MASTERS];

  always_comb begin
    for (int m = 0; m < NUM_MASTERS; m++) begin
      logic [ADDR_WIDTH-1:0] a, w;
      logic                  mis;
      a   = m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH];
      mis = 1'b0;
      if (BOFF > 0) mis = |(a & ADDR_WIDTH'((1 << BOFF) - 1));
      w   = a >> BOFF;
      m_ok[m] = !mis && ({1'b0, w} < TOTAL_W);
      if (NUM_BANKS == 1) begin
        m_bank[m] = '0;
        m_row[m]  = RAW'(w);
      end else if (INTERLEAVE == `SRAM_ILV_LOW) begin
        m_bank[m] = BW'(w);
        m_row[m]  = RAW'(w >> BW);
      end else begin
        m_bank[m] = BW'(w >> RAW);
        m_row[m]  = RAW'(w);
      end
      m_need[m]   = !m_req_we[m] || (WRITE_ACK != 0) || !m_ok[m];
      m_credit[m] = m_can[m] || (!m_need[m] && live_q);
    end
  end

  // ------------------------------------------------------------ per-bank arbitration
  logic [NUM_MASTERS-1:0] b_req [NUM_BANKS];
  logic [NUM_MASTERS-1:0] b_gnt [NUM_BANKS];
  logic [MW_-1:0]         b_ptr [NUM_BANKS];
  logic [MW_-1:0]         b_gidx [NUM_BANKS];
  logic [NUM_BANKS-1:0]   b_any;

  always_comb begin
    for (int b = 0; b < NUM_BANKS; b++) begin
      logic found;
      int   idx;
      for (int m = 0; m < NUM_MASTERS; m++)
        b_req[b][m] = m_req_valid[m] && m_ok[m] && m_credit[m] && !t_on && (m_bank[m] == BW'(b));
      b_gnt[b]  = '0;
      b_gidx[b] = '0;
      found     = 1'b0;
      for (int k = 0; k < NUM_MASTERS; k++) begin
        idx = (ARB == `SRAM_ARB_RR) ? (32'(b_ptr[b]) + k) : k;
        if (idx >= NUM_MASTERS) idx = idx - NUM_MASTERS;
        if (!found && b_req[b][idx]) begin
          found        = 1'b1;
          b_gnt[b][idx] = 1'b1;
          b_gidx[b]    = MW_'(idx);
        end
      end
      b_any[b] = found;
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int b = 0; b < NUM_BANKS; b++) b_ptr[b] <= '0;
    end else begin
      for (int b = 0; b < NUM_BANKS; b++)
        if (b_any[b]) b_ptr[b] <= (b_gidx[b] == LAST_M) ? '0 : b_gidx[b] + 1'b1;
    end
  end

  logic [NUM_MASTERS-1:0] m_gnt;
  always_comb begin
    m_gnt = '0;
    for (int b = 0; b < NUM_BANKS; b++) m_gnt = m_gnt | b_gnt[b];
    for (int m = 0; m < NUM_MASTERS; m++) begin
      m_req_ready[m]      = (m_gnt[m] || (!m_ok[m] && m_can[m])) && !t_on;
      m_stall_conflict[m] = m_req_valid[m] && m_ok[m] && m_credit[m] && !t_on && !m_gnt[m];
    end
  end

  // ------------------------------------------------------------ banks
  // flat vectors (not unpacked arrays) on instance ports: Yosys 0.33 re-elaborates a parent whose
  // port connections are unpacked-array elements and then fails on the duplicate module
  logic [NUM_BANKS*DATA_WIDTH-1:0] bk_rdata;
  logic [NUM_BANKS-1:0]  bk_rd;                       // functional read issued
  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_bank
    logic                  ce, we;
    logic [MASK_WIDTH-1:0] wmask;
    logic [RAW-1:0]        row;
    logic [DATA_WIDTH-1:0] wdata;
    always_comb begin
      if (t_on) begin
        // out-of-range rows never reach a bank
        ce = tst_ce && tst_sel[b] && tst_row_ok; we = tst_we; wmask = '1; row = tst_addr; wdata = tst_wdata;
      end else begin
        ce = b_any[b]; we = 1'b0; wmask = '0; row = '0; wdata = '0;
        for (int m = 0; m < NUM_MASTERS; m++) begin
          if (b_gnt[b][m]) begin
            we    = m_req_we[m];
            wmask = m_req_wmask[m*MASK_WIDTH +: MASK_WIDTH];
            row   = m_row[m];
            wdata = m_req_wdata[m*DATA_WIDTH +: DATA_WIDTH];
          end
        end
      end
    end
    assign bk_rd[b] = !t_on && b_any[b] && !we;

    sram_backend_1rw #(
      .DATA_WIDTH(DATA_WIDTH), .DEPTH(BANK_DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY),
      .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_bank (   // explicit connections: Yosys 0.33 mis-handles .name shorthand to generate-scope nets
      .clk(clk), .ce(ce), .we(we), .wmask(wmask), .addr(row), .wdata(wdata), .rdata(bk_rdata[b*DATA_WIDTH +: DATA_WIDTH])
    );
    assign tst_rdata[b*DATA_WIDTH +: DATA_WIDTH] = (TEST_EN != 0) ? bk_rdata[b*DATA_WIDTH +: DATA_WIDTH] : '0;
  end

  // ------------------------------------------------------------ owner pipelines (response routing)
  logic [READ_LATENCY-1:0] own_v   [NUM_BANKS];
  logic [MW_-1:0]          own_idx [NUM_BANKS*READ_LATENCY];   // [b*READ_LATENCY + stage]
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int b = 0; b < NUM_BANKS; b++) own_v[b] <= '0;
    end else begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        own_v[b][0] <= bk_rd[b];
        for (int k = 1; k < READ_LATENCY; k++) own_v[b][k] <= own_v[b][k-1];
      end
    end
  end
  always_ff @(posedge clk) begin
    for (int b = 0; b < NUM_BANKS; b++) begin
      own_idx[b*READ_LATENCY] <= b_gidx[b];
      for (int k = 1; k < READ_LATENCY; k++) own_idx[b*READ_LATENCY + k] <= own_idx[b*READ_LATENCY + k - 1];
    end
  end

  logic [NUM_MASTERS*DATA_WIDTH-1:0] m_arr;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_MASTERS-1:0] m_owned;    // routing check (assertions)
  /* verilator lint_on UNUSEDSIGNAL */
  always_comb begin
    for (int m = 0; m < NUM_MASTERS; m++) begin
      m_arr[m*DATA_WIDTH +: DATA_WIDTH] = '0;
      m_owned[m] = 1'b0;
      for (int b = 0; b < NUM_BANKS; b++) begin
        if (own_v[b][READ_LATENCY-1] && own_idx[b*READ_LATENCY + READ_LATENCY-1] == MW_'(m)) begin
          m_arr[m*DATA_WIDTH +: DATA_WIDTH] = m_arr[m*DATA_WIDTH +: DATA_WIDTH] | bk_rdata[b*DATA_WIDTH +: DATA_WIDTH];
          m_owned[m] = 1'b1;
        end
      end
    end
  end

  // ------------------------------------------------------------ per-master response paths
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_MASTERS-1:0] m_stg_v, m_stg_rd;   // routing check (assertions)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NUM_MASTERS-1:0] m_busy;
  for (genvar m = 0; m < NUM_MASTERS; m++) begin : g_master
    wire acc = m_req_valid[m] && m_req_ready[m];
    sram_rsp_path #(
      .DATA_WIDTH(DATA_WIDTH), .LATENCY(READ_LATENCY), .FIFO_DEPTH(RSP_FIFO_DEPTH), .ID_WIDTH(ID_WIDTH)
    ) u_rsp (
      .clk(clk), .rst_n(rst_n), .can_issue(m_can[m]),
      .iss_valid(acc && m_need[m]), .iss_rd(!m_req_we[m] && m_ok[m]), .iss_err(!m_ok[m]), .iss_we(m_req_we[m]),
      .iss_id(m_req_id[m*ID_WIDTH +: ID_WIDTH]),
      .arr_rdata(m_arr[m*DATA_WIDTH +: DATA_WIDTH]), .stg_valid(m_stg_v[m]), .stg_rd(m_stg_rd[m]),
      .rsp_valid(m_rsp_valid[m]), .rsp_ready(m_rsp_ready[m]), .rsp_rdata(m_rsp_rdata[m*DATA_WIDTH +: DATA_WIDTH]),
      .rsp_err(m_rsp_err[m]), .rsp_we(m_rsp_we[m]), .rsp_id(m_rsp_id[m*ID_WIDTH +: ID_WIDTH]), .busy(m_busy[m])
    );
  end
  assign busy = |m_busy;

`ifdef SRAMLIB_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        `SRAM_CHK(($countones(b_gnt[b]) <= 1), "bank granted more than one master")
        `SRAM_CHK(((b_gnt[b] & ~b_req[b]) == '0), "grant without request")
      end
      for (int m = 0; m < NUM_MASTERS; m++) begin
        // misrouting / dropping / duplication of read data
        `SRAM_CHK(m_owned[m] == (m_stg_v[m] && m_stg_rd[m]), "read data owner and master response stage disagree (misrouted or dropped read)")
        `SRAM_CHK(!(m_req_valid[m] && m_req_ready[m] && t_on), "functional request accepted in test mode")
      end
    end
  end
  // no master owns two banks' data in the same cycle
  always_ff @(posedge clk) begin
    if (rst_n) begin
      for (int m = 0; m < NUM_MASTERS; m++) begin
        int n;
        n = 0;
        for (int b = 0; b < NUM_BANKS; b++)
          if (own_v[b][READ_LATENCY-1] && own_idx[b*READ_LATENCY + READ_LATENCY-1] == MW_'(m)) n++;
        `SRAM_CHK(n <= 1, "two banks returned data for the same master in one cycle (duplicated)")
      end
    end
  end
`endif

endmodule

`default_nettype wire
