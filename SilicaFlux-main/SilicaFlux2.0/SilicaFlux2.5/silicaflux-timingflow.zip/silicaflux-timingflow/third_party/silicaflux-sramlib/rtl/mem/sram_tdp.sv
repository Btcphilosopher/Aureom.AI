// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_tdp
// True dual-port (2RW) SRAM: two independent read/write ports A and B, each
// with the sram_sp request/response channels, common clock.
//
// Availability (enforced at elaboration):
//   GENERIC  yes (simulation / logic synthesis)
//   FPGA     yes (true dual-port block RAM inference; verified with Yosys)
//   ASIC     only on a native 2RW macro (IHP SG13G2 RM_IHPSG13_2P_*).  The
//            SKY130 OpenRAM 1RW1R and GF180MCU 1RW macros cannot provide it
//            and are rejected; the library never emulates 2RW with flops or
//            time multiplexing.  Use sram_1r1w or banking instead.
//
// Conflict = both ports request the same valid address in one cycle and at
// least one of them writes (read/read is never a conflict).
//   COLLISION = `SRAM_COLL_STALL (default): the pair is never issued; the
//     port without priority is back-pressured, priority alternates after
//     every conflict (starvation-free).  Result = the two accesses executed
//     sequentially in acceptance order (write/write: the later write wins).
//   COLLISION = `SRAM_COLL_FORBID: master guarantee, assertion, no logic.
//   READ_OLD is not offered: no supported 2RW target defines the outcome.
// Test port: drives port A only (port B idle while tst_active).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_tdp #(
  parameter int DATA_WIDTH     = 32,
  parameter int DEPTH          = 1024,
  parameter int MASK_WIDTH     = (DATA_WIDTH % 8 == 0) ? DATA_WIDTH / 8 : 1,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int COLLISION      = `SRAM_COLL_STALL,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int WRITE_ACK      = 1,
  parameter int ID_WIDTH       = 1,
  parameter int TEST_EN        = 1,
  parameter     INIT_FILE      = "",
  localparam int AW            = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // port A
  input  wire logic                  a_req_valid,
  output logic                       a_req_ready,
  input  wire logic                  a_req_we,
  input  wire logic [AW-1:0]         a_req_addr,
  input  wire logic [DATA_WIDTH-1:0] a_req_wdata,
  input  wire logic [MASK_WIDTH-1:0] a_req_wmask,
  input  wire logic [ID_WIDTH-1:0]   a_req_id,
  output logic                       a_rsp_valid,
  input  wire logic                  a_rsp_ready,
  output logic [DATA_WIDTH-1:0]      a_rsp_rdata,
  output logic                       a_rsp_err,
  output logic                       a_rsp_we,
  output logic [ID_WIDTH-1:0]        a_rsp_id,
  // port B
  input  wire logic                  b_req_valid,
  output logic                       b_req_ready,
  input  wire logic                  b_req_we,
  input  wire logic [AW-1:0]         b_req_addr,
  input  wire logic [DATA_WIDTH-1:0] b_req_wdata,
  input  wire logic [MASK_WIDTH-1:0] b_req_wmask,
  input  wire logic [ID_WIDTH-1:0]   b_req_id,
  output logic                       b_rsp_valid,
  input  wire logic                  b_rsp_ready,
  output logic [DATA_WIDTH-1:0]      b_rsp_rdata,
  output logic                       b_rsp_err,
  output logic                       b_rsp_we,
  output logic [ID_WIDTH-1:0]        b_rsp_id,
  // MBIST test port (through port A)
  input  wire logic                  tst_active,
  input  wire logic                  tst_ce,
  input  wire logic                  tst_we,
  input  wire logic [AW-1:0]         tst_addr,
  input  wire logic [DATA_WIDTH-1:0] tst_wdata,
  output logic [DATA_WIDTH-1:0]      tst_rdata,
  output logic                       busy
);

  if (COLLISION != `SRAM_COLL_STALL && COLLISION != `SRAM_COLL_FORBID) begin : g_err_tdp_supports_stall_or_forbid_only
    `SRAM_CFG_FATAL("sram_tdp: COLLISION must be STALL or FORBID (no 2RW target defines a collision outcome)")
  end
  if (WRITE_ACK != 0 && WRITE_ACK != 1) begin : g_err_write_ack_not_0_or_1
    `SRAM_CFG_FATAL("sram_tdp: WRITE_ACK must be 0 or 1")
  end

  localparam bit POW2 = (DEPTH == (1 << AW));
  localparam logic [AW:0] DEPTH_W = (AW+1)'(DEPTH);

  logic t_on, live_q;
  assign t_on = (TEST_EN != 0) && tst_active;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_q <= 1'b0;
    else        live_q <= 1'b1;
  end

  // ------------------------------------------------------------ per-port decode
  logic a_ok, b_ok, a_need, b_need, a_can, b_can, a_base, b_base;
  assign a_ok   = POW2 ? 1'b1 : ({1'b0, a_req_addr} < DEPTH_W);
  assign b_ok   = POW2 ? 1'b1 : ({1'b0, b_req_addr} < DEPTH_W);
  wire   tst_ok = POW2 ? 1'b1 : ({1'b0, tst_addr} < DEPTH_W);
  assign a_need = !a_req_we || (WRITE_ACK != 0) || !a_ok;
  assign b_need = !b_req_we || (WRITE_ACK != 0) || !b_ok;
  assign a_base = !t_on && (a_can || (!a_need && live_q));
  assign b_base = !t_on && (b_can || (!b_need && live_q));

  logic conflict, b_wins, prio_b_q;
  assign conflict = a_req_valid && b_req_valid && a_ok && b_ok && (a_req_addr == b_req_addr) && (a_req_we || b_req_we);

  if (COLLISION == `SRAM_COLL_STALL) begin : g_stall
    assign b_wins      = prio_b_q && b_base;
    assign a_req_ready = a_base && !(conflict && b_wins);
    assign b_req_ready = b_base && !(conflict && !b_wins && a_base);
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) prio_b_q <= 1'b0;
      else if (conflict && a_req_valid && a_req_ready && !(b_req_valid && b_req_ready)) prio_b_q <= 1'b1;
      else if (conflict && b_req_valid && b_req_ready && !(a_req_valid && a_req_ready)) prio_b_q <= 1'b0;
    end
  end else begin : g_forbid
    assign b_wins      = 1'b0;
    assign prio_b_q    = 1'b0;
    assign a_req_ready = a_base;
    assign b_req_ready = b_base;
  end

  wire a_acc = a_req_valid && a_req_ready;
  wire b_acc = b_req_valid && b_req_ready;

  // ------------------------------------------------------------ array
  logic                  pa_ce, pa_we, pb_ce, pb_we;
  logic [MASK_WIDTH-1:0] pa_wmask, pb_wmask;
  logic [AW-1:0]         pa_addr, pb_addr;
  logic [DATA_WIDTH-1:0] pa_wdata, pb_wdata, pa_rdata, pb_rdata;
  always_comb begin
    if (t_on) begin
      pa_ce = tst_ce && tst_ok; pa_we = tst_we;     // out-of-range test addresses never reach the array
      pa_wmask = '1; pa_addr = tst_addr; pa_wdata = tst_wdata;
      pb_ce = 1'b0;
    end else begin
      pa_ce = a_acc && a_ok; pa_we = a_req_we; pa_wmask = a_req_wmask; pa_addr = a_req_addr; pa_wdata = a_req_wdata;
      pb_ce = b_acc && b_ok;
    end
    pb_we = b_req_we; pb_wmask = b_req_wmask; pb_addr = b_req_addr; pb_wdata = b_req_wdata;
  end

  sram_backend_2rw #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY),
    .BACKEND(BACKEND), .MACRO(MACRO), .INIT_FILE(INIT_FILE)
  ) u_array (
    .clk,
    .a_ce(pa_ce), .a_we(pa_we), .a_wmask(pa_wmask), .a_addr(pa_addr), .a_wdata(pa_wdata), .a_rdata(pa_rdata),
    .b_ce(pb_ce), .b_we(pb_we), .b_wmask(pb_wmask), .b_addr(pb_addr), .b_wdata(pb_wdata), .b_rdata(pb_rdata)
  );
  assign tst_rdata = (TEST_EN != 0) ? pa_rdata : '0;

  // ------------------------------------------------------------ response paths
  /* verilator lint_off UNUSEDSIGNAL */
  logic a_stg_v, a_stg_rd, b_stg_v, b_stg_rd;   // observed by assertions / debug only
  /* verilator lint_on UNUSEDSIGNAL */
  logic a_busy, b_busy;
  sram_rsp_path #(.DATA_WIDTH(DATA_WIDTH), .LATENCY(READ_LATENCY), .FIFO_DEPTH(RSP_FIFO_DEPTH), .ID_WIDTH(ID_WIDTH)) u_rsp_a (
    .clk, .rst_n, .can_issue(a_can),
    .iss_valid(a_acc && a_need), .iss_rd(!a_req_we && a_ok), .iss_err(!a_ok), .iss_we(a_req_we), .iss_id(a_req_id),
    .arr_rdata(pa_rdata), .stg_valid(a_stg_v), .stg_rd(a_stg_rd),
    .rsp_valid(a_rsp_valid), .rsp_ready(a_rsp_ready), .rsp_rdata(a_rsp_rdata), .rsp_err(a_rsp_err), .rsp_we(a_rsp_we),
    .rsp_id(a_rsp_id), .busy(a_busy));
  sram_rsp_path #(.DATA_WIDTH(DATA_WIDTH), .LATENCY(READ_LATENCY), .FIFO_DEPTH(RSP_FIFO_DEPTH), .ID_WIDTH(ID_WIDTH)) u_rsp_b (
    .clk, .rst_n, .can_issue(b_can),
    .iss_valid(b_acc && b_need), .iss_rd(!b_req_we && b_ok), .iss_err(!b_ok), .iss_we(b_req_we), .iss_id(b_req_id),
    .arr_rdata(pb_rdata), .stg_valid(b_stg_v), .stg_rd(b_stg_rd),
    .rsp_valid(b_rsp_valid), .rsp_ready(b_rsp_ready), .rsp_rdata(b_rsp_rdata), .rsp_err(b_rsp_err), .rsp_we(b_rsp_we),
    .rsp_id(b_rsp_id), .busy(b_busy));
  assign busy = a_busy | b_busy;

`ifdef SRAMLIB_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      `SRAM_CHK(!(pa_ce && pb_ce && pa_addr == pb_addr && (pa_we || pb_we)), "conflicting same-address accesses issued to the 2RW array")
      `SRAM_CHK(!(pa_ce && {1'b0, pa_addr} >= DEPTH_W), "port A access beyond DEPTH")
      `SRAM_CHK(!(pb_ce && {1'b0, pb_addr} >= DEPTH_W), "port B access beyond DEPTH")
      `SRAM_CHK(!(t_on && (a_acc || b_acc)), "functional access accepted in test mode")
    end
  end
`endif

endmodule

`default_nettype wire
