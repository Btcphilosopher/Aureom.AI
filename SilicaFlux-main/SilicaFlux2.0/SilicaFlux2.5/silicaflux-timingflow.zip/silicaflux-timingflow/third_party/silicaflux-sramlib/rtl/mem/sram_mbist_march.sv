// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_mbist_march
// Demonstration March MBIST controller for the library's test ports.
//
// Bus: the TestCore collar bus (silicaflux-testcore tc_mbist / tc_mbist_collar):
//   tst_active (whole run), tst_sel[t] (one target at a time), tst_ce, tst_we,
//   tst_addr, tst_wdata, tst_rdata[t*DW +: DW].
// so this controller and TestCore's tc_mbist are interchangeable masters of
// the same memory-side contract (sram_mbist_adapter maps widths/pipelining).
//
// Algorithms (ALGO)
//   March C- : {B(w0); U(r0,w1); U(r1,w0); D(r0,w1); D(r1,w0); B(r0)}   10N
//   MATS+    : {B(w0); U(r0,w1); D(r1,w0)}                              5N
// "0" = data background bg(addr), "1" = ~bg(addr); bg is all-zero or a
// checkerboard (0101.. inverted on odd addresses) selected by bg_checker.
// One operation per cycle; every read is compared exactly READ_LATENCY cycles
// after issue (never relying on the array holding its output); a read and a
// write are never issued in the same cycle (1R1W safe).
// Targets with tst sel bit in target_mask are tested one after another
// (bounds peak test power); each target's depth and width come from
// TARGET_MAXADDR / TARGET_DW.
//
// Results: pass/fail, per-target fail mask, saturating fail count, FIRST
// failure (target, element, address, syndrome = expected ^ actual on the
// target's bits).  stop_on_fail ends the run after the first miscompare.
//
// Scope: a functional demonstration.  It detects the classic static fault
// models March C- covers (stuck-at, transition, idempotent coupling, address
// decoder faults); it is NOT a production MBIST (no retention/pause elements,
// no macro-specific algorithms, no repair, no coverage sign-off).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_mbist_march #(
  parameter int NUM_TARGETS                     = 1,
  parameter int DW                              = 32,
  parameter int AW                              = 10,
  parameter int READ_LATENCY                    = 1,
  parameter logic [NUM_TARGETS*32-1:0] TARGET_MAXADDR = {NUM_TARGETS{32'd1023}},
  parameter logic [NUM_TARGETS*16-1:0] TARGET_DW      = {NUM_TARGETS{16'd32}},
  parameter int ALGO                            = `SRAM_MBIST_MARCH_CM,
  localparam int TW                             = (NUM_TARGETS > 1) ? $clog2(NUM_TARGETS) : 1
) (
  input  wire logic                        clk,
  input  wire logic                        rst_n,
  // control / status handshake
  input  wire logic                        start,          // pulse; ignored while busy
  input  wire logic [NUM_TARGETS-1:0]      target_mask,
  input  wire logic                        bg_checker,
  input  wire logic                        stop_on_fail,
  output logic                             busy,
  output logic                             done,           // high from completion until next start
  output logic                             pass,           // valid with done
  output logic                             fail,
  output logic [NUM_TARGETS-1:0]           fail_mask,
  output logic [TW-1:0]                    fail_target,
  output logic [AW-1:0]                    fail_addr,
  output logic [2:0]                       fail_elem,
  output logic [DW-1:0]                    fail_syndrome,
  output logic [15:0]                      fail_count,
  // test bus
  output logic                             tst_active,
  output logic [NUM_TARGETS-1:0]           tst_sel,
  output logic                             tst_ce,
  output logic                             tst_we,
  output logic [AW-1:0]                    tst_addr,
  output logic [DW-1:0]                    tst_wdata,
  input  wire logic [NUM_TARGETS*DW-1:0]   tst_rdata
);

  if (ALGO != `SRAM_MBIST_MARCH_CM && ALGO != `SRAM_MBIST_MATS_P) begin : g_err_unknown_algorithm
    `SRAM_CFG_FATAL("sram_mbist_march: unknown ALGO")
  end
  if (READ_LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_mbist_march: READ_LATENCY must be >= 1")
  end

  localparam int NELEM = (ALGO == `SRAM_MBIST_MATS_P) ? 3 : 6;

  // ------------------------------------------------------------ element table
  function automatic logic [3:0] elem_info(input logic [2:0] e);
    // {down, nops==2, op0_is_read, op0_val}; op1 (if present) is a write of ~op0_val
    if (ALGO == `SRAM_MBIST_MATS_P) begin
      case (e)
        3'd0: elem_info = 4'b0000;   // B(w0)
        3'd1: elem_info = 4'b0110;   // U(r0,w1)
        default: elem_info = 4'b1111; // D(r1,w0)
      endcase
    end else begin
      case (e)
        3'd0: elem_info = 4'b0000;   // B(w0)
        3'd1: elem_info = 4'b0110;   // U(r0,w1)
        3'd2: elem_info = 4'b0111;   // U(r1,w0)
        3'd3: elem_info = 4'b1110;   // D(r0,w1)
        3'd4: elem_info = 4'b1111;   // D(r1,w0)
        default: elem_info = 4'b0010; // B(r0)
      endcase
    end
  endfunction

  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic [DW-1:0] bg_of(input logic [AW-1:0] a, input logic chk);   // only a[0] matters
    logic [DW-1:0] p;
    for (int i = 0; i < DW; i++) p[i] = chk & (i % 2 == 1);
    bg_of = chk ? (p ^ {DW{a[0]}}) : '0;
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */

  function automatic logic [AW-1:0] maxaddr_of(input logic [TW-1:0] t);
    maxaddr_of = AW'(TARGET_MAXADDR[t*32 +: 32]);
  endfunction

  function automatic logic [DW-1:0] dwmask_of(input logic [TW-1:0] t);
    int w;
    w = 32'(TARGET_DW[t*16 +: 16]);
    for (int i = 0; i < DW; i++) dwmask_of[i] = (i < w);
  endfunction

  // ------------------------------------------------------------ sequencer
  localparam logic [2:0] S_IDLE = 3'd0, S_NEXT = 3'd1, S_RUN = 3'd2, S_DRAIN = 3'd3, S_DONE = 3'd4;
  logic [2:0]             st_q;
  logic [TW-1:0]          tgt_q;
  logic [NUM_TARGETS-1:0] todo_q;
  logic [2:0]             elem_q;
  logic                   op_q;          // 0: first op of the element, 1: second
  logic [AW-1:0]          addr_q;
  logic                   chk_q, stop_q;
  logic [7:0]             drain_q;

  logic [3:0]  ei;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [3:0]  ei_next;              // only the direction bit is used
  /* verilator lint_on UNUSEDSIGNAL */
  logic        e_down, e_two, e_rd0, e_v0;
  assign ei      = elem_info(elem_q);
  assign ei_next = elem_info(elem_q + 3'd1);
  assign e_down = ei[3];
  assign e_two  = ei[2];
  assign e_rd0  = ei[1];
  assign e_v0   = ei[0];

  logic        cur_rd, cur_val, last_op, last_addr, last_elem, issue;
  assign cur_rd    = (op_q == 1'b0) ? e_rd0 : 1'b0;
  assign cur_val   = (op_q == 1'b0) ? e_v0  : ~e_v0;
  assign last_op   = !e_two || op_q;
  assign last_addr = e_down ? (addr_q == '0) : (addr_q == maxaddr_of(tgt_q));
  assign last_elem = (elem_q == 3'(NELEM - 1));
  assign issue     = (st_q == S_RUN);

  logic fail_now;   // from the compare stage

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; tgt_q <= '0; todo_q <= '0; elem_q <= '0; op_q <= 1'b0; addr_q <= '0;
      chk_q <= 1'b0; stop_q <= 1'b0; drain_q <= '0;
    end else begin
      case (st_q)
        S_IDLE, S_DONE: begin
          if (start) begin
            todo_q <= target_mask;
            chk_q  <= bg_checker;
            stop_q <= stop_on_fail;
            st_q   <= S_NEXT;
          end
        end
        S_NEXT: begin
          if (todo_q == '0) begin
            st_q <= S_DONE;
          end else begin
            for (int t = NUM_TARGETS - 1; t >= 0; t--) if (todo_q[t]) tgt_q <= TW'(t);
            elem_q <= '0; op_q <= 1'b0; addr_q <= '0;
            st_q   <= S_RUN;
          end
        end
        S_RUN: begin
          if (stop_q && fail_now) begin
            todo_q  <= '0;
            drain_q <= 8'(READ_LATENCY + 1);
            st_q    <= S_DRAIN;
          end else if (!last_op) begin
            op_q <= 1'b1;
          end else begin
            op_q <= 1'b0;
            if (!last_addr) begin
              addr_q <= e_down ? addr_q - 1'b1 : addr_q + 1'b1;
            end else if (!last_elem) begin
              elem_q <= elem_q + 1'b1;
              addr_q <= ei_next[3] ? maxaddr_of(tgt_q) : '0;
            end else begin
              todo_q[tgt_q] <= 1'b0;
              drain_q <= 8'(READ_LATENCY + 1);
              st_q    <= S_DRAIN;
            end
          end
        end
        S_DRAIN: begin
          if (drain_q == '0) st_q <= (stop_q && fail) ? S_DONE : S_NEXT;
          else drain_q <= drain_q - 1'b1;
        end
        default: st_q <= S_IDLE;
      endcase
    end
  end

  assign busy       = (st_q == S_NEXT) || (st_q == S_RUN) || (st_q == S_DRAIN);
  assign done       = (st_q == S_DONE);
  assign tst_active = busy;
  always_comb begin
    tst_sel = '0;
    if (busy) tst_sel[tgt_q] = 1'b1;
  end
  assign tst_ce    = issue;
  assign tst_we    = issue && !cur_rd;
  assign tst_addr  = addr_q;
  assign tst_wdata = (cur_val ? ~bg_of(addr_q, chk_q) : bg_of(addr_q, chk_q)) & dwmask_of(tgt_q);

  // ------------------------------------------------------------ compare pipeline
  logic [READ_LATENCY-1:0] cv_q;
  logic [DW-1:0]           cexp_q  [READ_LATENCY];
  logic [AW-1:0]           caddr_q [READ_LATENCY];
  logic [2:0]              celem_q [READ_LATENCY];
  logic [TW-1:0]           ctgt_q  [READ_LATENCY];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cv_q <= '0;
    else begin
      cv_q[0] <= issue && cur_rd;
      for (int k = 1; k < READ_LATENCY; k++) cv_q[k] <= cv_q[k-1];
    end
  end
  always_ff @(posedge clk) begin
    cexp_q[0]  <= (cur_val ? ~bg_of(addr_q, chk_q) : bg_of(addr_q, chk_q)) & dwmask_of(tgt_q);
    caddr_q[0] <= addr_q;
    celem_q[0] <= elem_q;
    ctgt_q[0]  <= tgt_q;
    for (int k = 1; k < READ_LATENCY; k++) begin
      cexp_q[k] <= cexp_q[k-1]; caddr_q[k] <= caddr_q[k-1]; celem_q[k] <= celem_q[k-1]; ctgt_q[k] <= ctgt_q[k-1];
    end
  end

  logic [TW-1:0] ct;
  logic [DW-1:0] act, syn;
  assign ct       = ctgt_q[READ_LATENCY-1];
  assign act      = tst_rdata[ct*DW +: DW] & dwmask_of(ct);
  assign syn      = act ^ cexp_q[READ_LATENCY-1];
  assign fail_now = cv_q[READ_LATENCY-1] && (syn != '0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fail <= 1'b0; fail_mask <= '0; fail_target <= '0; fail_addr <= '0; fail_elem <= '0;
      fail_syndrome <= '0; fail_count <= '0;
    end else if ((st_q == S_IDLE || st_q == S_DONE) && start) begin
      // an empty selection is reported as FAIL (never a false PASS)
      fail <= (target_mask == '0); fail_mask <= '0; fail_target <= '0; fail_addr <= '0; fail_elem <= '0;
      fail_syndrome <= '0; fail_count <= '0;
    end else if (fail_now) begin
      if (!fail) begin
        fail_target   <= ct;
        fail_addr     <= caddr_q[READ_LATENCY-1];
        fail_elem     <= celem_q[READ_LATENCY-1];
        fail_syndrome <= syn;
      end
      fail           <= 1'b1;
      fail_mask[ct]  <= 1'b1;
      if (fail_count != 16'hFFFF) fail_count <= fail_count + 1'b1;
    end
  end
  assign pass = done && !fail;

endmodule

`default_nettype wire
