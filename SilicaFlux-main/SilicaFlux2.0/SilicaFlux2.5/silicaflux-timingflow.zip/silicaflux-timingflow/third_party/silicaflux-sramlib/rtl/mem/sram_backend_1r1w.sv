// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_backend_1r1w
// Raw one-read one-write (1R1W) backend selector: the macro-shaped port that tightly coupled
// pipelines (e.g. the SilicaFlux 2.5 memory_controller bank arrays) use
// directly, and that the handshake wrappers build on.
//
//   BACKEND = `SRAM_BACKEND_GENERIC : sram_generic_1r1w  (simulation / logic synthesis)
//   BACKEND = `SRAM_BACKEND_FPGA    : sram_fpga_1r1w     (block-RAM inference)
//   BACKEND = `SRAM_BACKEND_ASIC    : sram_asic_array MODE 1 over MACRO (hard macros)
//
// Raw contract (identical for every backend):
//   * one access per port per cycle; we/waddr on the write port, re/raddr on the read port, both in the same cycle allowed;
//     same-address read and write in one cycle is backend-specific (see COLLISION in sram_1r1w)
//   * write: lanes with wmask=1 are written at the rising edge;
//   * read data valid EXACTLY READ_LATENCY cycles after the read edge, for one
//     cycle only (never rely on it being held);
//   * addresses must be < DEPTH; no reset of the array; no initial content
//     except INIT_FILE on the FPGA backend.
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_backend_1r1w #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  parameter int BACKEND      = `SRAM_BACKEND_GENERIC,
  parameter int MACRO        = 0,
  parameter     INIT_FILE    = "",
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  we,
  input  wire logic [MASK_WIDTH-1:0] wmask,
  input  wire logic [AW-1:0]         waddr,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  input  wire logic                  re,
  input  wire logic [AW-1:0]         raddr,
  output logic      [DATA_WIDTH-1:0] rdata
);

  if (BACKEND != `SRAM_BACKEND_GENERIC && BACKEND != `SRAM_BACKEND_FPGA && BACKEND != `SRAM_BACKEND_ASIC) begin : g_err_unknown_backend
    `SRAM_CFG_FATAL("sram_backend_1r1w: unknown BACKEND")
  end
  if (BACKEND == `SRAM_BACKEND_ASIC && MACRO == 0) begin : g_err_asic_backend_without_macro
    `SRAM_CFG_FATAL("sram_backend_1r1w: BACKEND=ASIC requires an explicit MACRO (no flip-flop fallback)")
  end
  if (BACKEND != `SRAM_BACKEND_FPGA && INIT_FILE != "") begin : g_err_init_file_only_on_fpga
    `SRAM_CFG_FATAL("sram_backend_1r1w: INIT_FILE is only supported by the FPGA backend (ASIC SRAM has no defined content)")
  end
  if (DEPTH < 2) begin : g_err_depth_lt_2
    `SRAM_CFG_FATAL("sram_backend_1r1w: DEPTH must be >= 2")
  end
  if (DATA_WIDTH < 1) begin : g_err_data_width_lt_1
    `SRAM_CFG_FATAL("sram_backend_1r1w: DATA_WIDTH must be >= 1")
  end

  if (BACKEND == `SRAM_BACKEND_GENERIC) begin : g_generic
    sram_generic_1r1w #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY)) u_mem (.clk, .we, .wmask, .waddr, .wdata, .re, .raddr, .rdata);
  end else if (BACKEND == `SRAM_BACKEND_FPGA) begin : g_fpga
    sram_fpga_1r1w #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY), .INIT_FILE(INIT_FILE)) u_mem (.clk, .we, .wmask, .waddr, .wdata, .re, .raddr, .rdata);
  end else if (BACKEND == `SRAM_BACKEND_ASIC) begin : g_asic
    /* verilator lint_off PINCONNECTEMPTY */
    sram_asic_array #(.MODE(1), .DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY), .MACRO(MACRO)) u_mem (
      .clk, .a_ce(we), .a_we(1'b1), .a_wmask(wmask), .a_addr(waddr), .a_wdata(wdata), .a_rdata(),
      .b_ce(re), .b_we(1'b0), .b_wmask('0), .b_addr(raddr), .b_wdata('0), .b_rdata(rdata));
    /* verilator lint_on PINCONNECTEMPTY */
  end

endmodule

`default_nettype wire
