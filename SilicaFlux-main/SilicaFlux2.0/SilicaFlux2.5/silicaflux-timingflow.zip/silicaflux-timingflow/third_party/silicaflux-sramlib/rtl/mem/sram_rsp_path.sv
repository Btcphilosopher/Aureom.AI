// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_rsp_path
// Per-port response path shared by sram_sp, sram_1r1w, sram_tdp and
// sram_bank_controller.
//
//   * Tag pipeline, LATENCY deep: {valid, rd, err, we, id} of every accepted
//     response-producing request travels alongside the array read pipeline,
//     so the tag at the last stage belongs to the array data present now.
//   * FIFO_DEPTH > 0: response FIFO with credit accounting.  can_issue is
//     derived only from registered state (no combinational path from
//     rsp_ready to can_issue/req_ready).  Outstanding responses (in flight +
//     stored) never exceed FIFO_DEPTH, so the FIFO cannot overflow and a
//     response is never dropped.  When the FIFO is empty and rsp_ready=1 the
//     stage data bypasses it (latency = LATENCY cycles); otherwise it is
//     captured, so rsp_* are register outputs and stable while
//     rsp_valid && !rsp_ready.  FIFO_DEPTH = LATENCY + 1 sustains one
//     response per cycle.
//   * FIFO_DEPTH = 0: no backpressure.  The master must hold rsp_ready = 1
//     (checked by assertion); responses appear exactly LATENCY cycles after
//     acceptance; zero storage overhead.
//   * Responses leave strictly in acceptance order.  Read data of write
//     acknowledgements and error responses is all-zero.
//   * can_issue is 0 during reset and the first cycle after it.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_rsp_path #(
  parameter int DATA_WIDTH = 32,
  parameter int LATENCY    = 1,
  parameter int FIFO_DEPTH = 2,
  parameter int ID_WIDTH   = 1,
  localparam int CW        = $clog2(FIFO_DEPTH + 1) + 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // issue side (cycle in which the request is accepted)
  output logic                       can_issue,
  input  wire logic                  iss_valid,
  input  wire logic                  iss_rd,
  input  wire logic                  iss_err,
  input  wire logic                  iss_we,
  input  wire logic [ID_WIDTH-1:0]   iss_id,
  // array read data, valid when stg_valid && stg_rd
  input  wire logic [DATA_WIDTH-1:0] arr_rdata,
  output logic                       stg_valid,
  output logic                       stg_rd,
  // response channel
  output logic                       rsp_valid,
  input  wire logic                  rsp_ready,
  output logic [DATA_WIDTH-1:0]      rsp_rdata,
  output logic                       rsp_err,
  output logic                       rsp_we,
  output logic [ID_WIDTH-1:0]        rsp_id,
  output logic                       busy
);

  if (LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_rsp_path: LATENCY must be >= 1")
  end
  if (FIFO_DEPTH < 0) begin : g_err_negative_fifo_depth
    `SRAM_CFG_FATAL("sram_rsp_path: FIFO_DEPTH must be >= 0")
  end

  // ------------------------------------------------------------ reset release
  logic live_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_q <= 1'b0;
    else        live_q <= 1'b1;
  end

  // ------------------------------------------------------------ tag pipeline
  logic [LATENCY-1:0] t_v, t_rd, t_err, t_we;
  logic [ID_WIDTH-1:0] t_id [LATENCY];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      t_v <= '0;
    end else begin
      t_v[0] <= iss_valid;
      for (int k = 1; k < LATENCY; k++) t_v[k] <= t_v[k-1];
    end
  end
  always_ff @(posedge clk) begin
    t_rd[0]  <= iss_rd;
    t_err[0] <= iss_err;
    t_we[0]  <= iss_we;
    t_id[0]  <= iss_id;
    for (int k = 1; k < LATENCY; k++) begin
      t_rd[k]  <= t_rd[k-1];
      t_err[k] <= t_err[k-1];
      t_we[k]  <= t_we[k-1];
      t_id[k]  <= t_id[k-1];
    end
  end

  assign stg_valid = t_v[LATENCY-1];
  assign stg_rd    = t_rd[LATENCY-1] & ~t_err[LATENCY-1];

  logic [DATA_WIDTH-1:0] p_data;
  assign p_data = (stg_valid && stg_rd) ? arr_rdata : '0;

  // ------------------------------------------------------------ response queue
  if (FIFO_DEPTH == 0) begin : g_nofifo
    assign rsp_valid = stg_valid;
    assign rsp_rdata = p_data;
    assign rsp_err   = t_err[LATENCY-1];
    assign rsp_we    = t_we[LATENCY-1];
    assign rsp_id    = t_id[LATENCY-1];
    assign can_issue = live_q;
    assign busy      = |t_v;
    wire unused_rsp_ready = rsp_ready;   // no backpressure in this mode (checked by assertion)
`ifdef SRAMLIB_ASSERT
    always_ff @(posedge clk) begin
      if (rst_n && stg_valid) begin
        `SRAM_CHK(rsp_ready, "FIFO_DEPTH=0 requires rsp_ready=1 whenever rsp_valid=1 (response would be lost)")
      end
    end
`endif
  end else begin : g_fifo
    localparam int PTRW = (FIFO_DEPTH > 1) ? $clog2(FIFO_DEPTH) : 1;
    localparam logic [PTRW-1:0] LASTP = PTRW'(FIFO_DEPTH - 1);
    logic [DATA_WIDTH-1:0] f_data [FIFO_DEPTH];
    logic [FIFO_DEPTH-1:0] f_err, f_we;
    logic [ID_WIDTH-1:0]   f_id [FIFO_DEPTH];
    logic [PTRW-1:0]       rp_q, wp_q;
    logic [CW-1:0]         fc_q;      // FIFO occupancy
    logic [CW-1:0]         oc_q;      // outstanding = in flight + stored

    wire from_fifo = (fc_q != '0);
    wire deq       = from_fifo && rsp_ready;
    wire bypass    = !from_fifo && stg_valid && rsp_ready;
    wire enq       = stg_valid && !bypass;
    wire hs        = rsp_valid && rsp_ready;

    function automatic logic [PTRW-1:0] inc(input logic [PTRW-1:0] p);
      inc = (p == LASTP) ? '0 : p + 1'b1;
    endfunction

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        rp_q <= '0;
        wp_q <= '0;
        fc_q <= '0;
        oc_q <= '0;
      end else begin
        if (enq) wp_q <= inc(wp_q);
        if (deq) rp_q <= inc(rp_q);
        fc_q <= fc_q + CW'(enq) - CW'(deq);
        oc_q <= oc_q + CW'(iss_valid) - CW'(hs);
      end
    end
    always_ff @(posedge clk) begin
      if (enq) begin
        f_data[wp_q] <= p_data;
        f_err[wp_q]  <= t_err[LATENCY-1];
        f_we[wp_q]   <= t_we[LATENCY-1];
        f_id[wp_q]   <= t_id[LATENCY-1];
      end
    end

    assign rsp_valid = from_fifo | stg_valid;
    assign rsp_rdata = from_fifo ? f_data[rp_q] : p_data;
    assign rsp_err   = from_fifo ? f_err[rp_q]  : t_err[LATENCY-1];
    assign rsp_we    = from_fifo ? f_we[rp_q]   : t_we[LATENCY-1];
    assign rsp_id    = from_fifo ? f_id[rp_q]   : t_id[LATENCY-1];
    assign can_issue = live_q && (oc_q < CW'(FIFO_DEPTH));
    assign busy      = (oc_q != '0);

`ifdef SRAMLIB_ASSERT
    // ---------------------------------------------------- protocol checkers
    logic                  pv_q;
    logic [DATA_WIDTH-1:0] pd_q;
    logic                  pe_q, pw_q;
    logic [ID_WIDTH-1:0]   pi_q;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) pv_q <= 1'b0;
      else        pv_q <= rsp_valid && !rsp_ready;
    end
    always_ff @(posedge clk) begin
      pd_q <= rsp_rdata; pe_q <= rsp_err; pw_q <= rsp_we; pi_q <= rsp_id;
    end
    always_ff @(posedge clk) begin
      if (rst_n) begin
        `SRAM_CHK(oc_q <= CW'(FIFO_DEPTH), "outstanding responses exceed FIFO_DEPTH")
        `SRAM_CHK(fc_q <= oc_q, "FIFO occupancy exceeds outstanding count")
        `SRAM_CHK(!(enq && fc_q == CW'(FIFO_DEPTH) && !deq), "response FIFO overflow (response dropped)")
        `SRAM_CHK(!(iss_valid && !can_issue), "request accepted without a response credit")
        `SRAM_CHK(!(rsp_valid && oc_q == '0), "unsolicited response (nothing outstanding)")
        if (pv_q) begin
          `SRAM_CHK(rsp_valid, "rsp_valid dropped while rsp_ready was low")
          `SRAM_CHK(rsp_rdata == pd_q && rsp_err == pe_q && rsp_we == pw_q && rsp_id == pi_q,
                    "response payload changed while rsp_valid && !rsp_ready")
        end
      end
    end
`endif
  end

endmodule

`default_nettype wire
