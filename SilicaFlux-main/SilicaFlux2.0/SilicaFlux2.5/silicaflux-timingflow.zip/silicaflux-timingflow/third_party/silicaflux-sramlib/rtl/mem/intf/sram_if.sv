// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_if   (optional convenience bundle)
// SystemVerilog interface carrying the sram_sp request/response channels, with
// master / slave / monitor modports and simulation-time protocol checks on the
// MASTER side of the contract (valid and payload held until ready).
// The library cores use flat ports (portable to Yosys 0.33, whose interface
// support is limited); sram_sp_if adapts this bundle to sram_sp.
// Classification: SYNTHESIZABLE interface + simulation-only checks
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

interface sram_if #(
  parameter int DATA_WIDTH = 32,
  parameter int ADDR_WIDTH = 10,
  parameter int MASK_WIDTH = DATA_WIDTH / 8,
  parameter int ID_WIDTH   = 1
) (
  input wire logic clk,
  input wire logic rst_n
);
  logic                  req_valid, req_ready, req_we;
  logic [ADDR_WIDTH-1:0] req_addr;
  logic [DATA_WIDTH-1:0] req_wdata;
  logic [MASK_WIDTH-1:0] req_wmask;
  logic [ID_WIDTH-1:0]   req_id;
  logic                  rsp_valid, rsp_ready, rsp_err, rsp_we;
  logic [DATA_WIDTH-1:0] rsp_rdata;
  logic [ID_WIDTH-1:0]   rsp_id;

  modport master  (input clk, rst_n, req_ready, rsp_valid, rsp_rdata, rsp_err, rsp_we, rsp_id,
                   output req_valid, req_we, req_addr, req_wdata, req_wmask, req_id, rsp_ready);
  modport slave   (input clk, rst_n, req_valid, req_we, req_addr, req_wdata, req_wmask, req_id, rsp_ready,
                   output req_ready, rsp_valid, rsp_rdata, rsp_err, rsp_we, rsp_id);
  modport monitor (input clk, rst_n, req_valid, req_ready, req_we, req_addr, req_wdata, req_wmask, req_id,
                   rsp_valid, rsp_ready, rsp_rdata, rsp_err, rsp_we, rsp_id);

`ifdef SRAMLIB_ASSERT
  // master-side rule: a pending request is held stable until accepted
  logic                  p_pend;
  logic                  p_we;
  logic [ADDR_WIDTH-1:0] p_addr;
  logic [DATA_WIDTH-1:0] p_wdata;
  logic [MASK_WIDTH-1:0] p_wmask;
  logic [ID_WIDTH-1:0]   p_id;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) p_pend <= 1'b0;
    else        p_pend <= req_valid && !req_ready;
  end
  always_ff @(posedge clk) begin
    p_we <= req_we; p_addr <= req_addr; p_wdata <= req_wdata; p_wmask <= req_wmask; p_id <= req_id;
    if (rst_n && p_pend) begin
      `SRAM_CHK(req_valid, "master dropped req_valid before acceptance")
      `SRAM_CHK(req_we == p_we && req_addr == p_addr && req_wdata == p_wdata && req_wmask == p_wmask && req_id == p_id,
                "master changed the request payload before acceptance")
    end
  end
`endif
endinterface

// sram_if slave port -> sram_sp (all sram_sp parameters forwarded)
module sram_sp_if #(
  parameter int DATA_WIDTH     = 32,
  parameter int DEPTH          = 1024,
  parameter int MASK_WIDTH     = DATA_WIDTH / 8,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int WRITE_ACK      = 1,
  parameter int ID_WIDTH       = 1,
  localparam int AW            = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  sram_if.slave            bus,
  input  wire logic        tst_active,
  input  wire logic        tst_ce,
  input  wire logic        tst_we,
  input  wire logic [AW-1:0] tst_addr,
  input  wire logic [DATA_WIDTH-1:0] tst_wdata,
  output logic [DATA_WIDTH-1:0] tst_rdata,
  output logic             busy
);
  sram_sp #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY),
            .BACKEND(BACKEND), .MACRO(MACRO), .RSP_FIFO_DEPTH(RSP_FIFO_DEPTH), .WRITE_ACK(WRITE_ACK),
            .ID_WIDTH(ID_WIDTH)) u_sram (
    .clk(bus.clk), .rst_n(bus.rst_n),
    .req_valid(bus.req_valid), .req_ready(bus.req_ready), .req_we(bus.req_we), .req_addr(bus.req_addr),
    .req_wdata(bus.req_wdata), .req_wmask(bus.req_wmask), .req_id(bus.req_id),
    .rsp_valid(bus.rsp_valid), .rsp_ready(bus.rsp_ready), .rsp_rdata(bus.rsp_rdata), .rsp_err(bus.rsp_err),
    .rsp_we(bus.rsp_we), .rsp_id(bus.rsp_id),
    .tst_active, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy);
endmodule

`default_nettype wire
