// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_fpga_1rw
// FPGA backend, single port block RAM by inference (no vendor IP core).
//
// Coding template: single clock, synchronous read, per-lane write enables in
// a for loop, read only when not writing ("no-change" mode: the output
// register keeps its value during a write).  Recognised by Yosys
// (synth_xilinx / synth_ice40 / synth_ecp5 BRAM mapping) and written to match
// the single-port byte-write templates in the Xilinx/Intel synthesis guides.
//
// READ_LATENCY: 1 = BRAM output latch; 2 = plus the BRAM's optional output
// register (DOA_REG / output register, no reset so it can be absorbed);
// >= 3 adds fabric pipeline registers.
//
// INIT_FILE: optional $readmemh image.  This is the ONLY backend that
// accepts initial content (FPGA bitstream initialisation).  ASIC SRAM has no
// defined power-up content and an ASIC boot ROM is a different macro class.
// Read-during-write (same port): not applicable, a write cycle returns no
// read data by contract.
// Classification: SYNTHESIZABLE (block-RAM inference)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_fpga_1rw #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  parameter     INIT_FILE    = "",
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int LW          = DATA_WIDTH / MASK_WIDTH
) (
  input  wire logic                  clk,
  input  wire logic                  ce,
  input  wire logic                  we,
  input  wire logic [MASK_WIDTH-1:0] wmask,
  input  wire logic [AW-1:0]         addr,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  output logic      [DATA_WIDTH-1:0] rdata
);

  if (READ_LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_fpga_1rw: READ_LATENCY must be >= 1")
  end
  if (MASK_WIDTH < 1 || (DATA_WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_not_divisor
    `SRAM_CFG_FATAL("sram_fpga_1rw: MASK_WIDTH must divide DATA_WIDTH")
  end

  (* ram_style = "block" *)
  logic [DATA_WIDTH-1:0] mem [DEPTH];
  logic [DATA_WIDTH-1:0] q0;

  initial begin
    if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
  end

  always_ff @(posedge clk) begin
    if (ce) begin
      if (we) begin
        for (int l = 0; l < MASK_WIDTH; l++) begin
          if (wmask[l]) mem[addr][l*LW +: LW] <= wdata[l*LW +: LW];
        end
      end else begin
        q0 <= mem[addr];
      end
    end
  end

  if (READ_LATENCY == 1) begin : g_lat1
    assign rdata = q0;
  end else begin : g_latn
    logic [DATA_WIDTH-1:0] pipe [READ_LATENCY-1];
    always_ff @(posedge clk) begin
      pipe[0] <= q0;
      for (int k = 1; k < READ_LATENCY - 1; k++) pipe[k] <= pipe[k-1];
    end
    assign rdata = pipe[READ_LATENCY-2];
  end

endmodule

`default_nettype wire
