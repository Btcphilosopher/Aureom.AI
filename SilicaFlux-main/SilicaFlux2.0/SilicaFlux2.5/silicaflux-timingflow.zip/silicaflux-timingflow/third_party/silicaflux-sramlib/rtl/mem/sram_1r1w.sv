// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_1r1w
// One read port + one write port, common clock, independent addresses.
//
// Write channel  wr_valid/wr_ready, wr_addr, wr_data, wr_mask.  Posted (no
//                response).  An accepted write to an invalid address
//                (>= DEPTH) does not touch the array and pulses wr_err.
// Read channel   rd_valid/rd_ready, rd_addr, rd_id -> in-order response
//                channel rsp_valid/rsp_ready, rsp_rdata, rsp_err, rsp_id,
//                READ_LATENCY cycles after acceptance (no backpressure).
//
// Ordering rule (all collision policies): a read returns the data written by
// every write accepted in an EARLIER cycle, and never the data of a write
// accepted in the same cycle.
//
// COLLISION (same-cycle read and write of the same valid address)
//   `SRAM_COLL_STALL    (default, every backend) the pair is never issued:
//                       one side is back-pressured; priority alternates on
//                       successive collisions, so neither side starves.
//                       Costs one address comparator; ready depends
//                       combinationally on the other channel's valid/addr.
//   `SRAM_COLL_READ_OLD both issue; the read returns the old word.  Only
//                       GENERIC and FPGA (inference preserves RTL read-first
//                       semantics).  Rejected for ASIC: the supported macros
//                       define the cross-port collision as undefined.
//   `SRAM_COLL_FORBID   master guarantees no collision; checked by assertion;
//                       in simulation the colliding read returns X.
//
// Test port: tst_ce & tst_we -> write port, tst_ce & ~tst_we -> read port
// (TestCore collar TYPE 1 semantics, never a read and a write in one cycle).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_1r1w #(
  parameter int DATA_WIDTH     = 32,
  parameter int DEPTH          = 1024,
  parameter int MASK_WIDTH     = (DATA_WIDTH % 8 == 0) ? DATA_WIDTH / 8 : 1,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int COLLISION      = `SRAM_COLL_STALL,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int ID_WIDTH       = 1,
  parameter int TEST_EN        = 1,
  parameter     INIT_FILE      = "",
  localparam int AW            = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // write channel
  input  wire logic                  wr_valid,
  output logic                       wr_ready,
  input  wire logic [AW-1:0]         wr_addr,
  input  wire logic [DATA_WIDTH-1:0] wr_data,
  input  wire logic [MASK_WIDTH-1:0] wr_mask,
  output logic                       wr_err,
  // read channel
  input  wire logic                  rd_valid,
  output logic                       rd_ready,
  input  wire logic [AW-1:0]         rd_addr,
  input  wire logic [ID_WIDTH-1:0]   rd_id,
  output logic                       rsp_valid,
  input  wire logic                  rsp_ready,
  output logic [DATA_WIDTH-1:0]      rsp_rdata,
  output logic                       rsp_err,
  output logic [ID_WIDTH-1:0]        rsp_id,
  // MBIST test port
  input  wire logic                  tst_active,
  input  wire logic                  tst_ce,
  input  wire logic                  tst_we,
  input  wire logic [AW-1:0]         tst_addr,
  input  wire logic [DATA_WIDTH-1:0] tst_wdata,
  output logic [DATA_WIDTH-1:0]      tst_rdata,
  output logic                       busy
);

  if (COLLISION != `SRAM_COLL_STALL && COLLISION != `SRAM_COLL_READ_OLD && COLLISION != `SRAM_COLL_FORBID) begin : g_err_unknown_collision_policy
    `SRAM_CFG_FATAL("sram_1r1w: unknown COLLISION policy")
  end
  if (COLLISION == `SRAM_COLL_READ_OLD && BACKEND == `SRAM_BACKEND_ASIC) begin : g_err_read_old_not_guaranteed_by_asic_macros
    `SRAM_CFG_FATAL("sram_1r1w: COLLISION=READ_OLD is not guaranteed by any supported ASIC macro (cross-port collision undefined)")
  end

  localparam bit POW2 = (DEPTH == (1 << AW));
  localparam logic [AW:0] DEPTH_W = (AW+1)'(DEPTH);

  logic t_on, live_q, can_issue;
  assign t_on = (TEST_EN != 0) && tst_active;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_q <= 1'b0;
    else        live_q <= 1'b1;
  end

  logic w_ok, r_ok, coll, base_w, base_r, rd_wins, prio_q;
  assign w_ok   = POW2 ? 1'b1 : ({1'b0, wr_addr} < DEPTH_W);
  assign r_ok   = POW2 ? 1'b1 : ({1'b0, rd_addr} < DEPTH_W);
  wire   tst_ok = POW2 ? 1'b1 : ({1'b0, tst_addr} < DEPTH_W);
  assign coll   = wr_valid && rd_valid && w_ok && r_ok && (wr_addr == rd_addr);
  assign base_w = live_q && !t_on;
  assign base_r = can_issue && !t_on;

  if (COLLISION == `SRAM_COLL_STALL) begin : g_stall
    // read wins a collision only if it has priority AND can actually be accepted
    assign rd_wins  = prio_q && base_r;
    assign wr_ready = base_w && !(coll && rd_wins);
    assign rd_ready = base_r && !(coll && !rd_wins && base_w);
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) prio_q <= 1'b0;
      else if (coll && wr_valid && wr_ready && !(rd_valid && rd_ready)) prio_q <= 1'b1;   // write went first
      else if (coll && rd_valid && rd_ready && !(wr_valid && wr_ready)) prio_q <= 1'b0;   // read went first
    end
  end else begin : g_nostall
    assign rd_wins  = 1'b0;
    assign prio_q   = 1'b0;
    assign wr_ready = base_w;
    assign rd_ready = base_r;
  end

  wire w_acc = wr_valid && wr_ready;
  wire r_acc = rd_valid && rd_ready;
  assign wr_err = w_acc && !w_ok;

  // ------------------------------------------------------------ array
  logic                  a_we, a_re;
  logic [MASK_WIDTH-1:0] a_wmask;
  logic [AW-1:0]         a_waddr, a_raddr;
  logic [DATA_WIDTH-1:0] a_wdata, a_rdata, a_rdata_eff;
  always_comb begin
    if (t_on) begin
      a_we    = tst_ce && tst_ok && tst_we;      // out-of-range test addresses never reach the array
      a_re    = tst_ce && tst_ok && !tst_we;
      a_wmask = '1;
      a_waddr = tst_addr;
      a_raddr = tst_addr;
      a_wdata = tst_wdata;
    end else begin
      a_we    = w_acc && w_ok;
      a_re    = r_acc && r_ok;
      a_wmask = wr_mask;
      a_waddr = wr_addr;
      a_raddr = rd_addr;
      a_wdata = wr_data;
    end
  end

  sram_backend_1r1w #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY),
    .BACKEND(BACKEND), .MACRO(MACRO), .INIT_FILE(INIT_FILE)
  ) u_array (
    .clk, .we(a_we), .wmask(a_wmask), .waddr(a_waddr), .wdata(a_wdata), .re(a_re), .raddr(a_raddr), .rdata(a_rdata)
  );
  assign tst_rdata = (TEST_EN != 0) ? a_rdata : '0;

`ifndef SYNTHESIS
  // FORBID: a colliding read is undefined -> X in simulation
  logic [READ_LATENCY-1:0] cx_q = '0;
  always_ff @(posedge clk) begin
    cx_q[0] <= (COLLISION == `SRAM_COLL_FORBID) && a_we && a_re && (a_waddr == a_raddr);
    for (int k = 1; k < READ_LATENCY; k++) cx_q[k] <= cx_q[k-1];
  end
  assign a_rdata_eff = cx_q[READ_LATENCY-1] ? {DATA_WIDTH{1'bx}} : a_rdata;
`else
  assign a_rdata_eff = a_rdata;
`endif

  // ------------------------------------------------------------ read response path
  /* verilator lint_off UNUSEDSIGNAL */
  logic stg_valid, stg_rd, unused_we; // observed by assertions / debug only
  /* verilator lint_on UNUSEDSIGNAL */
  sram_rsp_path #(
    .DATA_WIDTH(DATA_WIDTH), .LATENCY(READ_LATENCY), .FIFO_DEPTH(RSP_FIFO_DEPTH), .ID_WIDTH(ID_WIDTH)
  ) u_rsp (
    .clk, .rst_n, .can_issue,
    .iss_valid(r_acc), .iss_rd(r_ok), .iss_err(!r_ok), .iss_we(1'b0), .iss_id(rd_id),
    .arr_rdata(a_rdata_eff), .stg_valid, .stg_rd,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_we(unused_we), .rsp_id, .busy
  );

`ifdef SRAMLIB_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      `SRAM_CHK(!(a_we && {1'b0, a_waddr} >= DEPTH_W), "write beyond DEPTH reached the array")
      `SRAM_CHK(!(a_re && {1'b0, a_raddr} >= DEPTH_W), "read beyond DEPTH reached the array")
      `SRAM_CHK(!(t_on && (w_acc || r_acc)), "functional access accepted in test mode")
      if (COLLISION == `SRAM_COLL_STALL) begin
        `SRAM_CHK(!(a_we && a_re && a_waddr == a_raddr), "STALL policy issued a same-address read and write")
      end
      if (COLLISION == `SRAM_COLL_FORBID && !t_on) begin
        `SRAM_CHK(!coll, "FORBID policy: master issued a same-cycle same-address read and write")
      end
    end
  end
`endif

endmodule

`default_nettype wire
