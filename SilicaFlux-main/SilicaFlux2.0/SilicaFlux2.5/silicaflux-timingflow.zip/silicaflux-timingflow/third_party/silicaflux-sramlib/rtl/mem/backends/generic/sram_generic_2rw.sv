// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_generic_2rw
// GENERIC backend, true dual port (two read/write ports), common clock.
//
// Raw contract as sram_generic_1rw, per port.  Same-address accesses from
// both ports in one cycle where either writes are OUTSIDE the raw contract
// (real 2RW macros do not define them); the sram_tdp wrapper never issues
// them (COLLISION=STALL) or asserts they do not occur (FORBID).  In
// simulation such a cycle is reported and the affected outputs are X.
// Classification: SYNTHESIZABLE (flip-flop/inferred array)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_generic_2rw #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int LW          = DATA_WIDTH / MASK_WIDTH
) (
  input  wire logic                  clk,
  input  wire logic                  a_ce,
  input  wire logic                  a_we,
  input  wire logic [MASK_WIDTH-1:0] a_wmask,
  input  wire logic [AW-1:0]         a_addr,
  input  wire logic [DATA_WIDTH-1:0] a_wdata,
  output logic      [DATA_WIDTH-1:0] a_rdata,
  input  wire logic                  b_ce,
  input  wire logic                  b_we,
  input  wire logic [MASK_WIDTH-1:0] b_wmask,
  input  wire logic [AW-1:0]         b_addr,
  input  wire logic [DATA_WIDTH-1:0] b_wdata,
  output logic      [DATA_WIDTH-1:0] b_rdata
);

  if (READ_LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_generic_2rw: READ_LATENCY must be >= 1")
  end
  if (MASK_WIDTH < 1 || (DATA_WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_not_divisor
    `SRAM_CFG_FATAL("sram_generic_2rw: MASK_WIDTH must divide DATA_WIDTH")
  end

  logic [DATA_WIDTH-1:0] mem [DEPTH];
  logic [DATA_WIDTH-1:0] qa0, qb0;

  // One process, both ports (portable inference of a 2-write-port memory).
  always_ff @(posedge clk) begin
    if (a_ce && !a_we) qa0 <= mem[a_addr];
    if (b_ce && !b_we) qb0 <= mem[b_addr];
    if (a_ce && a_we) begin
      for (int l = 0; l < MASK_WIDTH; l++)
        if (a_wmask[l]) mem[a_addr][l*LW +: LW] <= a_wdata[l*LW +: LW];
    end
    if (b_ce && b_we) begin
      for (int l = 0; l < MASK_WIDTH; l++)
        if (b_wmask[l]) mem[b_addr][l*LW +: LW] <= b_wdata[l*LW +: LW];
    end
  end

  logic [DATA_WIDTH-1:0] qa_out, qb_out;
  if (READ_LATENCY == 1) begin : g_lat1
    assign qa_out = qa0;
    assign qb_out = qb0;
  end else begin : g_latn
    logic [DATA_WIDTH-1:0] pa [READ_LATENCY-1];
    logic [DATA_WIDTH-1:0] pb [READ_LATENCY-1];
    always_ff @(posedge clk) begin
      pa[0] <= qa0;
      pb[0] <= qb0;
      for (int k = 1; k < READ_LATENCY - 1; k++) begin
        pa[k] <= pa[k-1];
        pb[k] <= pb[k-1];
      end
    end
    assign qa_out = pa[READ_LATENCY-2];
    assign qb_out = pb[READ_LATENCY-2];
  end

`ifndef SYNTHESIS
  logic [READ_LATENCY-1:0] rva_q = '0, rvb_q = '0, cola_q = '0, colb_q = '0;
  wire coll = a_ce && b_ce && (a_addr == b_addr) && (a_we || b_we);
  always_ff @(posedge clk) begin
    rva_q[0]  <= a_ce & ~a_we;
    rvb_q[0]  <= b_ce & ~b_we;
    cola_q[0] <= coll & ~a_we;
    colb_q[0] <= coll & ~b_we;
    for (int k = 1; k < READ_LATENCY; k++) begin
      rva_q[k] <= rva_q[k-1];  rvb_q[k] <= rvb_q[k-1];
      cola_q[k] <= cola_q[k-1]; colb_q[k] <= colb_q[k-1];
    end
    if (coll) $error("%m: same-address access with a write on both ports (outside the raw 2RW contract)");
  end
`ifdef SRAMLIB_POISON
  assign a_rdata = (rva_q[READ_LATENCY-1] && !cola_q[READ_LATENCY-1]) ? qa_out : {DATA_WIDTH{1'bx}};
  assign b_rdata = (rvb_q[READ_LATENCY-1] && !colb_q[READ_LATENCY-1]) ? qb_out : {DATA_WIDTH{1'bx}};
`else
  assign a_rdata = qa_out;
  assign b_rdata = qb_out;
`endif
`else
  assign a_rdata = qa_out;
  assign b_rdata = qb_out;
`endif

endmodule

`default_nettype wire
