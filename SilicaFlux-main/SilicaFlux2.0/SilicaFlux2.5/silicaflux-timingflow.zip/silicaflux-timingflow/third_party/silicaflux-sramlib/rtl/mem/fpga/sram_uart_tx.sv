// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_uart_tx
// Minimal 8N1 UART transmitter for the FPGA memory self-test report.
// valid/ready byte interface; tx idles high.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sram_uart_tx #(
  parameter int CLKS_PER_BIT = 868          // 100 MHz / 115200
) (
  input  wire logic       clk,
  input  wire logic       rst_n,
  input  wire logic       valid,
  input  wire logic [7:0] data,
  output logic            ready,
  output logic            tx
);
  localparam int CW = $clog2(CLKS_PER_BIT + 1);
  localparam logic [CW-1:0] LASTC = CW'(CLKS_PER_BIT - 1);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [9:0]    sh_q;       // {stop, data[7:0], start}; bit 0 is consumed as tx directly
  /* verilator lint_on UNUSEDSIGNAL */
  logic [3:0]    nbit_q;
  logic [CW-1:0] cnt_q;

  assign ready = (nbit_q == 4'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sh_q <= '1; nbit_q <= '0; cnt_q <= '0; tx <= 1'b1;
    end else if (nbit_q == 4'd0) begin
      tx <= 1'b1;
      if (valid) begin
        sh_q   <= {1'b1, data, 1'b0};
        nbit_q <= 4'd10;
        cnt_q  <= '0;
        tx     <= 1'b0;                       // start bit
      end
    end else if (cnt_q == LASTC) begin
      cnt_q  <= '0;
      nbit_q <= nbit_q - 1'b1;
      sh_q   <= {1'b1, sh_q[9:1]};
      tx     <= (nbit_q == 4'd1) ? 1'b1 : sh_q[1];
    end else begin
      cnt_q <= cnt_q + 1'b1;
    end
  end
endmodule

`default_nettype wire
