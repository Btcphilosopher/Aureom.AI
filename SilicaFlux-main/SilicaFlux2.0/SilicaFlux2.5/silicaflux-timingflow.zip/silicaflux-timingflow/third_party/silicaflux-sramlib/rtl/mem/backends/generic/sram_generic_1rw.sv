// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_generic_1rw
// GENERIC backend, single port (1RW), synchronous read.
//
// Raw backend contract (shared by every backend, see docs/mem/01_interface_spec.md):
//   * One access per cycle: ce=1 selects the port, we=1 write / we=0 read.
//   * Write: lanes with wmask[l]=1 take wdata at the rising edge; other lanes
//     keep their content.  A write cycle produces no read data.
//   * Read : rdata is valid EXACTLY READ_LATENCY cycles after the read edge,
//     for that one cycle.  It is NOT guaranteed to be held afterwards (some
//     real macros drive X one hold time after the next edge).
//   * addr must be < DEPTH (the handshake wrappers guarantee it).
//   * The array is never reset and has no defined power-up content.
//
// Classification: SYNTHESIZABLE (flip-flop/inferred array).  An ASIC flow
// turns this array into flip-flops: it is for simulation, logic synthesis
// and equivalence reference only.  Silicon storage uses BACKEND=ASIC.
//
// Simulation-only extras (excluded when SYNTHESIS is defined):
//   * SRAMLIB_POISON: rdata is X in every cycle that is not a valid read slot,
//     so a consumer that relies on rdata being held fails in simulation.
//   * Fault injection for MBIST verification.  Set from a testbench by
//     hierarchical assignment (u.flt_kind etc.); 0 = no fault (default).
//       1 SA0   cell (flt_addr,flt_bit) stuck at 0
//       2 SA1   cell (flt_addr,flt_bit) stuck at 1
//       3 TFU   cell cannot make a 0->1 transition
//       4 TFD   cell cannot make a 1->0 transition
//       5 CFID  0->1 write transition of aggressor (flt_addr,flt_bit) sets
//               victim (flt_addr2,flt_bit2) to 1
//       6 AF    address decoder fault: flt_addr accesses flt_addr2
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_generic_1rw #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int LW          = DATA_WIDTH / MASK_WIDTH
) (
  input  wire logic                  clk,
  input  wire logic                  ce,
  input  wire logic                  we,
  input  wire logic [MASK_WIDTH-1:0] wmask,
  input  wire logic [AW-1:0]         addr,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  output logic      [DATA_WIDTH-1:0] rdata
);

  if (READ_LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_generic_1rw: READ_LATENCY must be >= 1")
  end
  if (MASK_WIDTH < 1 || (DATA_WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_not_divisor
    `SRAM_CFG_FATAL("sram_generic_1rw: MASK_WIDTH must divide DATA_WIDTH")
  end

  logic [DATA_WIDTH-1:0] mem [DEPTH];
  logic [DATA_WIDTH-1:0] q0;

`ifdef SYNTHESIS
  always_ff @(posedge clk) begin
    if (ce) begin
      if (we) begin
        for (int l = 0; l < MASK_WIDTH; l++) begin
          if (wmask[l]) mem[addr][l*LW +: LW] <= wdata[l*LW +: LW];
        end
      end else begin
        q0 <= mem[addr];
      end
    end
  end
`else
  /* verilator lint_off BLKSEQ */
  /* verilator lint_off UNUSEDSIGNAL */
  // ------------------------------------------------ simulation model + faults
  int unsigned flt_kind  = 0;
  int unsigned flt_addr  = 0;
  int unsigned flt_bit   = 0;
  int unsigned flt_addr2 = 0;
  int unsigned flt_bit2  = 0;

  function automatic int unsigned eff_addr(input int unsigned a);
    eff_addr = (flt_kind == 6 && a == flt_addr) ? flt_addr2 : a;
  endfunction

  logic [DATA_WIDTH-1:0] old_w, new_w, rd_w;
  int unsigned           ea;
  always @(posedge clk) begin
    if (ce) begin
      ea = eff_addr(int'(addr));
      if (we) begin
        old_w = mem[ea];
        new_w = old_w;
        for (int l = 0; l < MASK_WIDTH; l++) begin
          if (wmask[l]) new_w[l*LW +: LW] = wdata[l*LW +: LW];
        end
        if (ea == flt_addr) begin
          case (flt_kind)
            1: new_w[flt_bit] = 1'b0;
            2: new_w[flt_bit] = 1'b1;
            3: if (old_w[flt_bit] === 1'b0 && new_w[flt_bit] === 1'b1) new_w[flt_bit] = 1'b0;
            4: if (old_w[flt_bit] === 1'b1 && new_w[flt_bit] === 1'b0) new_w[flt_bit] = 1'b1;
            default: ;
          endcase
          if (flt_kind == 5 && old_w[flt_bit] !== 1'b1 && new_w[flt_bit] === 1'b1 && flt_addr2 != ea)
            mem[flt_addr2][flt_bit2] <= 1'b1;
        end
        mem[ea] <= new_w;
      end else begin
        rd_w = mem[ea];
        if (ea == flt_addr && flt_kind == 1) rd_w[flt_bit] = 1'b0;
        if (ea == flt_addr && flt_kind == 2) rd_w[flt_bit] = 1'b1;
        q0 <= rd_w;
      end
    end
  end
  // contract check: addresses beyond DEPTH never reach the array
  always_ff @(posedge clk) begin
    if (ce && int'(addr) >= DEPTH)
      $error("%m: access to address %0d >= DEPTH %0d (raw backend contract violation)", addr, DEPTH);
  end
  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_on BLKSEQ */
`endif

  // ------------------------------------------------ output pipeline
  logic [DATA_WIDTH-1:0] q_out;
  if (READ_LATENCY == 1) begin : g_lat1
    assign q_out = q0;
  end else begin : g_latn
    logic [DATA_WIDTH-1:0] pipe [READ_LATENCY-1];
    always_ff @(posedge clk) begin
      pipe[0] <= q0;
      for (int k = 1; k < READ_LATENCY - 1; k++) pipe[k] <= pipe[k-1];
    end
    assign q_out = pipe[READ_LATENCY-2];
  end

`ifndef SYNTHESIS
`ifdef SRAMLIB_POISON
  logic [READ_LATENCY-1:0] rv_q = '0;
  always_ff @(posedge clk) begin
    rv_q[0] <= ce & ~we;
    for (int k = 1; k < READ_LATENCY; k++) rv_q[k] <= rv_q[k-1];
  end
  assign rdata = rv_q[READ_LATENCY-1] ? q_out : {DATA_WIDTH{1'bx}};
`else
  assign rdata = q_out;
`endif
`else
  assign rdata = q_out;
`endif

endmodule

`default_nettype wire
