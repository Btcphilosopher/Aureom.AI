// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_presets.svh
// ILLUSTRATIVE SilicaFlux-V configurations (from the library brief).  They are
// examples for integration and evaluation, NOT confirmed SilicaFlux design
// specifications.  Use as:  sram_sp #(.DATA_WIDTH(`SFV_CPU_BANK_DW), .DEPTH(`SFV_CPU_BANK_DEPTH), ...)
// The per-family macro tiling of each preset is tabulated by
// scripts/mem/sram_analysis.py (reports/mem/analysis.md).
// =============================================================================
`ifndef SRAM_PRESETS_SVH
`define SRAM_PRESETS_SVH
`define SFV_CTRL_SRAM_DW        32     // control and diagnostic data      4 KiB
`define SFV_CTRL_SRAM_DEPTH     1024
`define SFV_CPU_BANK_DW         32     // CPU-accessible storage          16 KiB
`define SFV_CPU_BANK_DEPTH      4096
`define SFV_VEC_SPM_DW          64     // vector scratchpad (SIMD)        32 KiB
`define SFV_VEC_SPM_DEPTH       4096
`define SFV_TENSOR_SPM_DW       128    // tensor operands / buffers       32 KiB
`define SFV_TENSOR_SPM_DEPTH    2048
`endif
