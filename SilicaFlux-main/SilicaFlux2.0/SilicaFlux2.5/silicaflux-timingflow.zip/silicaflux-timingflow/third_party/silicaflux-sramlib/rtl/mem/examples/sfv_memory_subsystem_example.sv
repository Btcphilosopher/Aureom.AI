// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sfv_memory_subsystem_example
// Integration EXAMPLE for SilicaFlux-V (illustrative sizes from sram_presets.svh;
// not a confirmed SilicaFlux-V architecture):
//
//   control SRAM   sram_sp               32 b x 1024  (4 KiB)   CPU control/diagnostic data
//   CPU SRAM       sram_sp               32 b x 4096  (16 KiB)  CPU-private storage
//   scratchpad     sram_bank_controller  4 masters (CPU, vector, tensor, DMA) x 4 banks
//                                        x 128 b x 512 (32 KiB), byte addressed, RR arbitration
//   MBIST          sram_mbist_march      6 targets: control, CPU, 4 scratchpad banks
//
// One BACKEND for everything; on ASIC each memory class gets its own macro
// (parameters below).  MBIST owns the test ports while mbist_busy is high.
// Classification: SYNTHESIZABLE example top
// =============================================================================
`include "sram_defs.svh"
`include "sram_presets.svh"
`default_nettype none

module sfv_memory_subsystem_example #(
  parameter int BACKEND    = `SRAM_BACKEND_GENERIC,
  parameter int MACRO_CTRL = 0,     // e.g. `SRAM_MACRO_IHP_1P_1024X32
  parameter int MACRO_CPU  = 0,     // e.g. `SRAM_MACRO_IHP_1P_2048X32  (2 rows)
  parameter int MACRO_SPM  = 0,     // e.g. `SRAM_MACRO_IHP_1P_512X64   (2 columns per bank)
  localparam int SPM_DW    = 128,
  localparam int SPM_BANKS = 4,
  localparam int SPM_BD    = 512,
  localparam int SPM_AW    = 16,    // byte address: 32 KiB
  localparam int NM        = 4      // 0 CPU, 1 vector, 2 tensor, 3 DMA
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // control SRAM (CPU port)
  input  wire logic                    ctl_req_valid,
  output logic                         ctl_req_ready,
  input  wire logic                    ctl_req_we,
  input  wire logic [9:0]              ctl_req_addr,
  input  wire logic [31:0]             ctl_req_wdata,
  input  wire logic [3:0]              ctl_req_wmask,
  output logic                         ctl_rsp_valid,
  output logic [31:0]                  ctl_rsp_rdata,
  output logic                         ctl_rsp_err,
  // CPU SRAM
  input  wire logic                    cpu_req_valid,
  output logic                         cpu_req_ready,
  input  wire logic                    cpu_req_we,
  input  wire logic [11:0]             cpu_req_addr,
  input  wire logic [31:0]             cpu_req_wdata,
  input  wire logic [3:0]              cpu_req_wmask,
  output logic                         cpu_rsp_valid,
  output logic [31:0]                  cpu_rsp_rdata,
  output logic                         cpu_rsp_err,
  // scratchpad masters (flattened, master m = slice m)
  input  wire logic [NM-1:0]           spm_req_valid,
  output logic      [NM-1:0]           spm_req_ready,
  input  wire logic [NM-1:0]           spm_req_we,
  input  wire logic [NM*SPM_AW-1:0]    spm_req_addr,
  input  wire logic [NM*SPM_DW-1:0]    spm_req_wdata,
  input  wire logic [NM*16-1:0]        spm_req_wmask,
  input  wire logic [NM*4-1:0]         spm_req_id,
  output logic      [NM-1:0]           spm_rsp_valid,
  input  wire logic [NM-1:0]           spm_rsp_ready,
  output logic      [NM*SPM_DW-1:0]    spm_rsp_rdata,
  output logic      [NM-1:0]           spm_rsp_err,
  output logic      [NM*4-1:0]         spm_rsp_id,
  // MBIST control / status
  input  wire logic                    mbist_start,
  output logic                         mbist_busy,
  output logic                         mbist_done,
  output logic                         mbist_pass,
  output logic [5:0]                   mbist_fail_mask
);
  // ------------------------------------------------------------ MBIST bus
  localparam int BDW = SPM_DW, BAW = 12;
  logic           t_act, t_ce, t_we;
  logic [5:0]     t_sel;
  logic [BAW-1:0] t_addr;
  logic [BDW-1:0] t_wdata;
  logic [6*BDW-1:0] t_rdata;
  logic [2:0]     unused_ft, unused_fe;
  logic [BAW-1:0] unused_fa;
  logic [BDW-1:0] unused_fs;
  logic [15:0]    unused_fc;
  logic           unused_fail;

  sram_mbist_march #(
    .NUM_TARGETS(6), .DW(BDW), .AW(BAW), .READ_LATENCY(1),
    .TARGET_MAXADDR({32'(SPM_BD-1), 32'(SPM_BD-1), 32'(SPM_BD-1), 32'(SPM_BD-1), 32'd4095, 32'd1023}),
    .TARGET_DW({16'd128, 16'd128, 16'd128, 16'd128, 16'd32, 16'd32})
  ) u_mbist (
    .clk(clk), .rst_n(rst_n), .start(mbist_start), .target_mask(6'h3F), .bg_checker(1'b0), .stop_on_fail(1'b0),
    .busy(mbist_busy), .done(mbist_done), .pass(mbist_pass), .fail(unused_fail), .fail_mask(mbist_fail_mask),
    .fail_target(unused_ft), .fail_addr(unused_fa), .fail_elem(unused_fe), .fail_syndrome(unused_fs),
    .fail_count(unused_fc), .tst_active(t_act), .tst_sel(t_sel), .tst_ce(t_ce), .tst_we(t_we), .tst_addr(t_addr),
    .tst_wdata(t_wdata), .tst_rdata(t_rdata));

  // ------------------------------------------------------------ control SRAM
  logic        c_ta, c_tce, c_twe, unused_c_busy, unused_c_rwe;
  logic [9:0]  c_tad;
  logic [31:0] c_twd, c_trd;
  logic [0:0]  unused_c_rid;
  sram_mbist_adapter #(.BUS_AW(BAW), .BUS_DW(BDW), .MEM_AW(10), .MEM_DW(32)) u_ad_ctl (
    .clk(clk), .bist_active(t_act), .bist_sel(t_sel[0]), .bist_ce(t_ce), .bist_we(t_we), .bist_addr(t_addr),
    .bist_wdata(t_wdata), .bist_rdata(t_rdata[0*BDW +: BDW]), .tst_active(c_ta), .tst_ce(c_tce), .tst_we(c_twe),
    .tst_addr(c_tad), .tst_wdata(c_twd), .tst_rdata(c_trd));
  sram_sp #(.DATA_WIDTH(`SFV_CTRL_SRAM_DW), .DEPTH(`SFV_CTRL_SRAM_DEPTH), .READ_LATENCY(1), .BACKEND(BACKEND),
            .MACRO(MACRO_CTRL), .RSP_FIFO_DEPTH(0)) u_ctrl (
    .clk(clk), .rst_n(rst_n), .req_valid(ctl_req_valid), .req_ready(ctl_req_ready), .req_we(ctl_req_we),
    .req_addr(ctl_req_addr), .req_wdata(ctl_req_wdata), .req_wmask(ctl_req_wmask), .req_id(1'b0),
    .rsp_valid(ctl_rsp_valid), .rsp_ready(1'b1), .rsp_rdata(ctl_rsp_rdata), .rsp_err(ctl_rsp_err), .rsp_we(unused_c_rwe),
    .rsp_id(unused_c_rid), .tst_active(c_ta), .tst_ce(c_tce), .tst_we(c_twe), .tst_addr(c_tad), .tst_wdata(c_twd),
    .tst_rdata(c_trd), .busy(unused_c_busy));

  // ------------------------------------------------------------ CPU SRAM
  logic        p_ta, p_tce, p_twe, unused_p_busy, unused_p_rwe;
  logic [11:0] p_tad;
  logic [31:0] p_twd, p_trd;
  logic [0:0]  unused_p_rid;
  sram_mbist_adapter #(.BUS_AW(BAW), .BUS_DW(BDW), .MEM_AW(12), .MEM_DW(32)) u_ad_cpu (
    .clk(clk), .bist_active(t_act), .bist_sel(t_sel[1]), .bist_ce(t_ce), .bist_we(t_we), .bist_addr(t_addr),
    .bist_wdata(t_wdata), .bist_rdata(t_rdata[1*BDW +: BDW]), .tst_active(p_ta), .tst_ce(p_tce), .tst_we(p_twe),
    .tst_addr(p_tad), .tst_wdata(p_twd), .tst_rdata(p_trd));
  sram_sp #(.DATA_WIDTH(`SFV_CPU_BANK_DW), .DEPTH(`SFV_CPU_BANK_DEPTH), .READ_LATENCY(1), .BACKEND(BACKEND),
            .MACRO(MACRO_CPU), .RSP_FIFO_DEPTH(0)) u_cpu (
    .clk(clk), .rst_n(rst_n), .req_valid(cpu_req_valid), .req_ready(cpu_req_ready), .req_we(cpu_req_we),
    .req_addr(cpu_req_addr), .req_wdata(cpu_req_wdata), .req_wmask(cpu_req_wmask), .req_id(1'b0),
    .rsp_valid(cpu_rsp_valid), .rsp_ready(1'b1), .rsp_rdata(cpu_rsp_rdata), .rsp_err(cpu_rsp_err), .rsp_we(unused_p_rwe),
    .rsp_id(unused_p_rid), .tst_active(p_ta), .tst_ce(p_tce), .tst_we(p_twe), .tst_addr(p_tad), .tst_wdata(p_twd),
    .tst_rdata(p_trd), .busy(unused_p_busy));

  // ------------------------------------------------------------ shared banked scratchpad
  logic [NM-1:0]  unused_s_stall, unused_s_rwe;   // perf counters / write acks not used in this example
  logic           unused_s_busy;
  logic [8:0]     s_tad;
  assign s_tad = t_addr[8:0];
  sram_bank_controller #(
    .NUM_MASTERS(NM), .NUM_BANKS(SPM_BANKS), .DATA_WIDTH(SPM_DW), .MASK_WIDTH(16), .BANK_DEPTH(SPM_BD),
    .READ_LATENCY(1), .BACKEND(BACKEND), .MACRO(MACRO_SPM), .ADDR_MODE(`SRAM_ADDR_BYTE), .ADDR_WIDTH(SPM_AW),
    .ID_WIDTH(4)
  ) u_spm (
    .clk(clk), .rst_n(rst_n), .m_req_valid(spm_req_valid), .m_req_ready(spm_req_ready), .m_req_we(spm_req_we),
    .m_req_addr(spm_req_addr), .m_req_wdata(spm_req_wdata), .m_req_wmask(spm_req_wmask), .m_req_id(spm_req_id),
    .m_rsp_valid(spm_rsp_valid), .m_rsp_ready(spm_rsp_ready), .m_rsp_rdata(spm_rsp_rdata), .m_rsp_err(spm_rsp_err),
    .m_rsp_we(unused_s_rwe), .m_rsp_id(spm_rsp_id), .m_stall_conflict(unused_s_stall),
    .tst_active(t_act), .tst_sel(t_sel[5:2]), .tst_ce(t_ce), .tst_we(t_we), .tst_addr(s_tad), .tst_wdata(t_wdata),
    .tst_rdata(t_rdata[2*BDW +: 4*BDW]), .busy(unused_s_busy));

endmodule

`default_nettype wire
