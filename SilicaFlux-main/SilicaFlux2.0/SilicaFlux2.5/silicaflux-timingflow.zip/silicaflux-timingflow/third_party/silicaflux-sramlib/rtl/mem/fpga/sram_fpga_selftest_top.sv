// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_fpga_selftest_top
// Standalone FPGA memory test: one sram_sp (FPGA block-RAM backend by
// default) is written and read back with eight pattern passes, and the result
// is reported on LEDs and a UART.
//
//   pass 0 all zeros          pass 4 walking zero (bit = addr % DW)
//   pass 1 all ones           pass 5 address-in-data (addr replicated ^ A5..)
//   pass 2 checkerboard       pass 6 address hash (pseudo-random, regenerable)
//   pass 3 walking one        pass 7 byte-mask: write ones, then clear lane
//                                    (addr % MASK_WIDTH) with a masked write
// Each pass writes every word (posted writes), then reads every word and
// compares in order.  The first miscompare stops the test.
//
//   led[0] heartbeat while running, on when finished    led[2] PASS
//   led[1] finished                                      led[3] FAIL
//   uart_tx 8N1 at BAUD: "SFX SRAM PASS\r\n" or "SFX SRAM FAIL P<p> A<aaaa>\r\n"
// Press the reset button to run again.
//
// NOT validated on hardware: this design has been simulated and synthesised
// (Yosys, xc7) only.  See docs/mem/06_fpga.md before claiming board results.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_fpga_selftest_top #(
  parameter int CLK_HZ       = 100_000_000,
  parameter int BAUD         = 115_200,
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 4096,           // 16 KiB at 32 bits
  parameter int READ_LATENCY = 2,              // BRAM + output register
  parameter int BACKEND      = `SRAM_BACKEND_FPGA,
  localparam int MW          = DATA_WIDTH / 8,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic       clk,
  input  wire logic       rst_n_btn,           // asynchronous, active low
  output logic [3:0]      led,
  output logic            uart_tx
);

  if (DATA_WIDTH % 8 != 0 || (DATA_WIDTH & (DATA_WIDTH - 1)) != 0) begin : g_err_data_width_pow2_bytes
    `SRAM_CFG_FATAL("sram_fpga_selftest_top: DATA_WIDTH must be a power of two >= 8")
  end

  // ------------------------------------------------------------ reset synchroniser
  logic [1:0] rs_q;
  always_ff @(posedge clk or negedge rst_n_btn) begin
    if (!rst_n_btn) rs_q <= 2'b00;
    else            rs_q <= {rs_q[0], 1'b1};
  end
  wire rst_n = rs_q[1];

  // ------------------------------------------------------------ memory under test
  logic                  req_valid, req_ready, req_we, rsp_valid, rsp_err;
  logic [AW-1:0]         req_addr;
  logic [DATA_WIDTH-1:0] req_wdata, rsp_rdata;
  logic [MW-1:0]         req_wmask;
  /* verilator lint_off UNUSEDSIGNAL */
  logic                  unused_rsp_we, unused_busy;
  logic [0:0]            unused_rsp_id;
  logic [DATA_WIDTH-1:0] unused_tst_rdata;
  /* verilator lint_on UNUSEDSIGNAL */

  sram_sp #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(READ_LATENCY), .BACKEND(BACKEND),
    .WRITE_ACK(0), .TEST_EN(0)
  ) u_sram (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wmask, .req_id(1'b0),
    .rsp_valid, .rsp_ready(1'b1), .rsp_rdata, .rsp_err, .rsp_we(unused_rsp_we), .rsp_id(unused_rsp_id),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(unused_tst_rdata),
    .busy(unused_busy)
  );

  // ------------------------------------------------------------ patterns
  localparam logic [AW-1:0] DWM = AW'(DATA_WIDTH - 1);  // walking-bit position = addr mod DATA_WIDTH (power of 2)
  localparam logic [AW-1:0] MWM = AW'(MW - 1);         // lane index = addr mod MW (power of 2)
  function automatic logic [DATA_WIDTH-1:0] pattern(input logic [2:0] ph, input logic [AW-1:0] a);
    logic [DATA_WIDTH-1:0] p, one;
    logic [31:0]           h;
    one = {{(DATA_WIDTH-1){1'b0}}, 1'b1};
    h   = 32'(a) * 32'h9E37_79B1;
    h   = h ^ (h >> 15);
    case (ph)
      3'd0: p = '0;
      3'd1: p = '1;
      3'd2: p = a[0] ? {(DATA_WIDTH/2){2'b10}} : {(DATA_WIDTH/2){2'b01}};
      3'd3: p = one << (a & DWM);
      3'd4: p = ~(one << (a & DWM));
      3'd5: begin p = '0; for (int i = 0; i < DATA_WIDTH; i += 16) p[i +: 16] = 16'(a) ^ 16'hA5A5; end
      3'd6: begin p = '0; for (int i = 0; i < DATA_WIDTH; i += 32) p[i +: 32] = h ^ 32'(i); end
      default: begin                        // pass 7 expectation: ones with lane (a % MW) cleared
        p = '1;
        p[(a & MWM) * 8 +: 8] = 8'h00;
      end
    endcase
    pattern = p;
  endfunction

  // ------------------------------------------------------------ sequencer
  localparam logic [2:0] S_W = 3'd0, S_R = 3'd1, S_MSG = 3'd2, S_END = 3'd3;
  logic [2:0]    st_q, ph_q;
  logic [AW:0]   wa_q, ra_q, rc_q;            // write / read-issue / read-check counters
  logic          step_q;                      // pass 7: 0 = write ones, 1 = masked clear
  logic          fail_q;
  logic [2:0]    fph_q;
  logic [AW-1:0] fad_q;

  always_comb begin
    req_valid = 1'b0; req_we = 1'b0; req_addr = '0; req_wdata = '0; req_wmask = '1;
    if (st_q == S_W) begin
      req_valid = 1'b1; req_we = 1'b1; req_addr = AW'(wa_q);
      if (ph_q == 3'd7) begin
        req_wdata = step_q ? '0 : '1;
        req_wmask = step_q ? (MW'(1) << (AW'(wa_q) & MWM)) : '1;
      end else begin
        req_wdata = pattern(ph_q, AW'(wa_q));
      end
    end else if (st_q == S_R && ra_q < (AW+1)'(DEPTH)) begin
      req_valid = 1'b1; req_we = 1'b0; req_addr = AW'(ra_q);
    end
  end

  logic msg_start, msg_done;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_W; ph_q <= '0; wa_q <= '0; ra_q <= '0; rc_q <= '0; step_q <= 1'b0;
      fail_q <= 1'b0; fph_q <= '0; fad_q <= '0;
    end else begin
      case (st_q)
        S_W: if (req_ready) begin
          if (ph_q == 3'd7 && !step_q) step_q <= 1'b1;
          else begin
            step_q <= 1'b0;
            if (wa_q == (AW+1)'(DEPTH - 1)) begin wa_q <= '0; st_q <= S_R; end
            else wa_q <= wa_q + 1'b1;
          end
        end
        S_R: begin
          if (req_valid && req_ready) ra_q <= ra_q + 1'b1;
          if (rsp_valid) begin
            if (rsp_rdata != pattern(ph_q, AW'(rc_q)) || rsp_err) begin
              fail_q <= 1'b1; fph_q <= ph_q; fad_q <= AW'(rc_q);
              st_q   <= S_MSG;
            end else if (rc_q == (AW+1)'(DEPTH - 1)) begin
              rc_q <= '0; ra_q <= '0;
              if (ph_q == 3'd7) st_q <= S_MSG;
              else begin ph_q <= ph_q + 1'b1; st_q <= S_W; end
            end else begin
              rc_q <= rc_q + 1'b1;
            end
          end
        end
        S_MSG: if (msg_done) st_q <= S_END;
        default: ;
      endcase
    end
  end
  assign msg_start = (st_q == S_MSG);

  // ------------------------------------------------------------ UART report
  function automatic logic [7:0] hexc(input logic [3:0] n);
    hexc = (n < 4'd10) ? 8'h30 + 8'(n) : 8'h37 + 8'(n);
  endfunction
  // "SFX SRAM PASS\r\n" (15) / "SFX SRAM FAIL P0 A0000\r\n" (24)
  function automatic logic [7:0] msg_char(input logic [4:0] i, input logic f, input logic [2:0] p, input logic [15:0] a);
    logic [7:0] c;
    case (i)
      5'd0: c = "S"; 5'd1: c = "F"; 5'd2: c = "X"; 5'd3: c = " ";
      5'd4: c = "S"; 5'd5: c = "R"; 5'd6: c = "A"; 5'd7: c = "M"; 5'd8: c = " ";
      default: c = 8'h00;
    endcase
    if (!f) begin
      case (i)
        5'd9: c = "P"; 5'd10: c = "A"; 5'd11: c = "S"; 5'd12: c = "S"; 5'd13: c = 8'h0D; 5'd14: c = 8'h0A;
        default: ;
      endcase
    end else begin
      case (i)
        5'd9: c = "F"; 5'd10: c = "A"; 5'd11: c = "I"; 5'd12: c = "L"; 5'd13: c = " "; 5'd14: c = "P";
        5'd15: c = hexc({1'b0, p}); 5'd16: c = " "; 5'd17: c = "A";
        5'd18: c = hexc(a[15:12]); 5'd19: c = hexc(a[11:8]); 5'd20: c = hexc(a[7:4]); 5'd21: c = hexc(a[3:0]);
        5'd22: c = 8'h0D; 5'd23: c = 8'h0A;
        default: ;
      endcase
    end
    msg_char = c;
  endfunction

  logic [4:0] mi_q;
  logic       tx_ready;
  wire  [4:0] mlen    = fail_q ? 5'd24 : 5'd15;
  wire        tx_valid = msg_start && (mi_q < mlen);
  assign msg_done = msg_start && (mi_q == mlen) && tx_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) mi_q <= '0;
    else if (tx_valid && tx_ready) mi_q <= mi_q + 1'b1;
  end
  sram_uart_tx #(.CLKS_PER_BIT(CLK_HZ / BAUD)) u_uart (
    .clk, .rst_n, .valid(tx_valid), .data(msg_char(mi_q, fail_q, fph_q, 16'(fad_q))), .ready(tx_ready), .tx(uart_tx)
  );

  // ------------------------------------------------------------ LEDs
  logic [25:0] hb_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) hb_q <= '0;
    else        hb_q <= hb_q + 1'b1;
  end
  wire finished = (st_q == S_MSG) || (st_q == S_END);
  assign led[0] = finished ? 1'b1 : hb_q[25];
  assign led[1] = finished;
  assign led[2] = finished && !fail_q;
  assign led[3] = finished && fail_q;

endmodule

`default_nettype wire
