// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_defs.svh
//
// Library-wide constants.  Deliberately a `define header rather than a
// SystemVerilog package: Yosys 0.33 (the open synthesis/formal front end used
// by this library's regression) cannot resolve package references in module
// parameter lists, and every synthesizable module here must elaborate in the
// three open tools used here (Verilator 5.020, Icarus 12, Yosys 0.33) unaided.
//
// Values are part of the public contract: never renumber, only append.
// =============================================================================
`ifndef SRAM_DEFS_SVH
`define SRAM_DEFS_SVH

// ---------------------------------------------------------------- backends
// GENERIC : behavioural/synthesizable array for simulation and early logic
//           synthesis.  An ASIC flow turns it into flip-flops: never use it
//           for silicon storage.
// FPGA    : block-RAM inference template (no vendor IP cores).
// ASIC    : explicit foundry/compiler macro instances selected by MACRO.
//           Never falls back to flip-flops.
`define SRAM_BACKEND_GENERIC 0
`define SRAM_BACKEND_FPGA    1
`define SRAM_BACKEND_ASIC    2

// ---------------------------------------------------- collision policies
// Applies to same-cycle accesses to the same word where at least one is a
// write (1R1W: read vs write; 2RW: port A vs port B).
// STALL    : the wrapper never issues such a pair; it back-pressures one
//            side (alternating priority, starvation-free).  Valid for every
//            backend.  DEFAULT.
// READ_OLD : 1R1W only.  Both are issued; the read returns the pre-write
//            word.  Only accepted where the backend guarantees it (GENERIC,
//            FPGA inference).  Rejected at elaboration for ASIC macros.
// FORBID   : the master guarantees no collision.  Checked by assertion; in
//            simulation a collision returns X.  No arbitration logic.
`define SRAM_COLL_STALL    0
`define SRAM_COLL_READ_OLD 1
`define SRAM_COLL_FORBID   2

// ---------------------------------------------------- bank controller
`define SRAM_ARB_RR    0   // per-bank round robin (starvation-free)
`define SRAM_ARB_FIXED 1   // per-bank fixed priority, master 0 highest

`define SRAM_ILV_LOW  0    // word-interleaved: bank = word_addr % NUM_BANKS
`define SRAM_ILV_HIGH 1    // contiguous: bank = word_addr / BANK_DEPTH

`define SRAM_ADDR_WORD 0   // master addresses are word addresses
`define SRAM_ADDR_BYTE 1   // master addresses are byte addresses (aligned)

// ---------------------------------------------------- MBIST algorithms
`define SRAM_MBIST_MARCH_CM 0   // March C-  (10N)
`define SRAM_MBIST_MATS_P   1   // MATS+     (5N)

// ---------------------------------------------------- configuration errors
// Elaboration-time failure for unsupported configurations.  Icarus 12 does
// not evaluate elaboration-time $fatal, so it gets a time-0 $fatal instead.
// Yosys 0.33 aborts on the $fatal but does not print the message: the
// message is therefore also written in the generate-block name.
`ifdef __ICARUS__
  `define SRAM_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SRAM_CFG_FATAL(msg) $fatal(1, msg);
`endif

// ---------------------------------------------------- assertions
// SRAMLIB_ASSERT enables the embedded protocol checkers (Verilator and the
// formal harnesses define it; synthesis never does).
`ifdef FORMAL
  `define SRAM_CHK(cond, msg) assert (cond);
`else
  `define SRAM_CHK(cond, msg) assert (cond) else $error("%m: %s", msg);
`endif

`endif // SRAM_DEFS_SVH
