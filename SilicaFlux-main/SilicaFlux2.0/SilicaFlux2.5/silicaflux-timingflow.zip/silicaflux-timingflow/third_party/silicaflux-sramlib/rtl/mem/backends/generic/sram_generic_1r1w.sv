// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_generic_1r1w
// GENERIC backend, one read port + one write port, common clock.
//
// Raw contract as sram_generic_1rw, per port.  Same-cycle read and write of
// the same address: this model returns the OLD word (read-first).  That is a
// property of this backend only; wrappers expose it (COLLISION=READ_OLD)
// solely for backends that guarantee it.
// Fault injection (simulation only) as in sram_generic_1rw.
// Classification: SYNTHESIZABLE (flip-flop/inferred array)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_generic_1r1w #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int LW          = DATA_WIDTH / MASK_WIDTH
) (
  input  wire logic                  clk,
  // write port
  input  wire logic                  we,
  input  wire logic [MASK_WIDTH-1:0] wmask,
  input  wire logic [AW-1:0]         waddr,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  // read port
  input  wire logic                  re,
  input  wire logic [AW-1:0]         raddr,
  output logic      [DATA_WIDTH-1:0] rdata
);

  if (READ_LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_generic_1r1w: READ_LATENCY must be >= 1")
  end
  if (MASK_WIDTH < 1 || (DATA_WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_not_divisor
    `SRAM_CFG_FATAL("sram_generic_1r1w: MASK_WIDTH must divide DATA_WIDTH")
  end

  logic [DATA_WIDTH-1:0] mem [DEPTH];
  logic [DATA_WIDTH-1:0] q0;

`ifdef SYNTHESIS
  always_ff @(posedge clk) begin
    if (we) begin
      for (int l = 0; l < MASK_WIDTH; l++) begin
        if (wmask[l]) mem[waddr][l*LW +: LW] <= wdata[l*LW +: LW];
      end
    end
  end
  always_ff @(posedge clk) begin
    if (re) q0 <= mem[raddr];
  end
`else
  /* verilator lint_off BLKSEQ */
  /* verilator lint_off UNUSEDSIGNAL */
  int unsigned flt_kind  = 0;
  int unsigned flt_addr  = 0;
  int unsigned flt_bit   = 0;
  int unsigned flt_addr2 = 0;
  int unsigned flt_bit2  = 0;

  function automatic int unsigned eff_addr(input int unsigned a);
    eff_addr = (flt_kind == 6 && a == flt_addr) ? flt_addr2 : a;
  endfunction

  logic [DATA_WIDTH-1:0] old_w, new_w, rd_w;
  int unsigned           wa, ra;
  always @(posedge clk) begin
    // read first: sees the array before this edge's write
    if (re) begin
      ra   = eff_addr(int'(raddr));
      rd_w = mem[ra];
      if (ra == flt_addr && flt_kind == 1) rd_w[flt_bit] = 1'b0;
      if (ra == flt_addr && flt_kind == 2) rd_w[flt_bit] = 1'b1;
      q0 <= rd_w;
    end
    if (we) begin
      wa    = eff_addr(int'(waddr));
      old_w = mem[wa];
      new_w = old_w;
      for (int l = 0; l < MASK_WIDTH; l++) begin
        if (wmask[l]) new_w[l*LW +: LW] = wdata[l*LW +: LW];
      end
      if (wa == flt_addr) begin
        case (flt_kind)
          1: new_w[flt_bit] = 1'b0;
          2: new_w[flt_bit] = 1'b1;
          3: if (old_w[flt_bit] === 1'b0 && new_w[flt_bit] === 1'b1) new_w[flt_bit] = 1'b0;
          4: if (old_w[flt_bit] === 1'b1 && new_w[flt_bit] === 1'b0) new_w[flt_bit] = 1'b1;
          default: ;
        endcase
        if (flt_kind == 5 && old_w[flt_bit] !== 1'b1 && new_w[flt_bit] === 1'b1 && flt_addr2 != wa)
          mem[flt_addr2][flt_bit2] <= 1'b1;
      end
      mem[wa] <= new_w;
    end
  end
  always @(posedge clk) begin
    if (we && int'(waddr) >= DEPTH) $error("%m: write address %0d >= DEPTH %0d", waddr, DEPTH);
    if (re && int'(raddr) >= DEPTH) $error("%m: read address %0d >= DEPTH %0d", raddr, DEPTH);
  end
  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_on BLKSEQ */
`endif

  logic [DATA_WIDTH-1:0] q_out;
  if (READ_LATENCY == 1) begin : g_lat1
    assign q_out = q0;
  end else begin : g_latn
    logic [DATA_WIDTH-1:0] pipe [READ_LATENCY-1];
    always_ff @(posedge clk) begin
      pipe[0] <= q0;
      for (int k = 1; k < READ_LATENCY - 1; k++) pipe[k] <= pipe[k-1];
    end
    assign q_out = pipe[READ_LATENCY-2];
  end

`ifndef SYNTHESIS
`ifdef SRAMLIB_POISON
  logic [READ_LATENCY-1:0] rv_q = '0;
  always_ff @(posedge clk) begin
    rv_q[0] <= re;
    for (int k = 1; k < READ_LATENCY; k++) rv_q[k] <= rv_q[k-1];
  end
  assign rdata = rv_q[READ_LATENCY-1] ? q_out : {DATA_WIDTH{1'bx}};
`else
  assign rdata = q_out;
`endif
`else
  assign rdata = q_out;
`endif

endmodule

`default_nettype wire
