// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_mbist_adapter
// Connects ONE library memory's test port to a shared MBIST bus in the
// TestCore collar format (silicaflux-testcore: tc_mbist -> tc_mbist_collar):
//
//   bus side   bist_active, bist_sel (this memory's select bit), bist_ce,
//              bist_we, bist_addr[BUS_AW], bist_wdata[BUS_DW] -> bist_rdata
//   memory     tst_active, tst_ce, tst_we, tst_addr[MEM_AW], tst_wdata[MEM_DW]
//              <- tst_rdata (sram_sp / sram_1r1w / sram_tdp / one bank of
//              sram_bank_controller via its tst_sel)
//
//   * bist_active hands the memory to the bus for the whole MBIST mode
//     (functional requests are back-pressured by the wrapper), exactly as
//     tc_mbist_collar does with f_ready = !bist_active.
//   * Only a selected memory sees bist_ce.  Writes cover all lanes.
//   * IN_PIPE / OUT_PIPE add register stages on the TEST path only (bus
//     timing closure across the die).  The MBIST registry latency for this
//     memory must be READ_LATENCY + IN_PIPE + OUT_PIPE.
//   * Address/data are truncated to the memory; read data is zero-extended.
// Hard macros with their own test pins (e.g. IHP *_BIST_* pins) are driven
// through the functional pins by this scheme; switching to a macro's internal
// BIST mux is a per-family adapter change (see docs/mem/04_mbist.md).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

/* verilator lint_off UNUSEDSIGNAL */   // clk unused without pipes; upper bus bits unused for narrow memories
module sram_mbist_adapter #(
  parameter int BUS_AW   = 16,
  parameter int BUS_DW   = 72,
  parameter int MEM_AW   = 10,
  parameter int MEM_DW   = 32,
  parameter int IN_PIPE  = 0,
  parameter int OUT_PIPE = 0
) (
  input  wire logic              clk,
  input  wire logic              bist_active,
  input  wire logic              bist_sel,
  input  wire logic              bist_ce,
  input  wire logic              bist_we,
  input  wire logic [BUS_AW-1:0] bist_addr,
  input  wire logic [BUS_DW-1:0] bist_wdata,
  output logic      [BUS_DW-1:0] bist_rdata,
  output logic                   tst_active,
  output logic                   tst_ce,
  output logic                   tst_we,
  output logic      [MEM_AW-1:0] tst_addr,
  output logic      [MEM_DW-1:0] tst_wdata,
  input  wire logic [MEM_DW-1:0] tst_rdata
);

  if (MEM_AW > BUS_AW || MEM_DW > BUS_DW) begin : g_err_memory_wider_than_bus
    `SRAM_CFG_FATAL("sram_mbist_adapter: memory address/data wider than the MBIST bus")
  end

  assign tst_active = bist_active;

  if (IN_PIPE != 0) begin : g_in
    always_ff @(posedge clk) begin
      tst_ce    <= bist_active && bist_sel && bist_ce;
      tst_we    <= bist_we;
      tst_addr  <= bist_addr[MEM_AW-1:0];
      tst_wdata <= bist_wdata[MEM_DW-1:0];
    end
  end else begin : g_noin
    assign tst_ce    = bist_active && bist_sel && bist_ce;
    assign tst_we    = bist_we;
    assign tst_addr  = bist_addr[MEM_AW-1:0];
    assign tst_wdata = bist_wdata[MEM_DW-1:0];
  end

  if (OUT_PIPE != 0) begin : g_out
    always_ff @(posedge clk) bist_rdata <= BUS_DW'(tst_rdata);
  end else begin : g_noout
    assign bist_rdata = BUS_DW'(tst_rdata);
  end

endmodule
/* verilator lint_on UNUSEDSIGNAL */

`default_nettype wire
