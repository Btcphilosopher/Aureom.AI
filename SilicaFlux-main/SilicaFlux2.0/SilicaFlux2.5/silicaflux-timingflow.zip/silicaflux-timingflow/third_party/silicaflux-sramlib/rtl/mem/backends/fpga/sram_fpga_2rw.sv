// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_fpga_2rw
// FPGA backend, true dual-port block RAM (two read/write ports, one clock)
// by inference.  Xilinx 7-series RAMB18E1/RAMB36E1, Lattice ECP5 DP16KD and
// iCE40 SB_RAM40_4K (the latter only 1R1W: Yosys emulates/rejects 2RW there)
// differ in what they support: the regression checks the mapping with Yosys
// for xc7 and ecp5.
//
// Same-address accesses with a write on both ports in one cycle are outside
// the raw contract (the BRAM primitives define them as a collision); the
// sram_tdp wrapper prevents or forbids them.
// Classification: SYNTHESIZABLE (block-RAM inference)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_fpga_2rw #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  parameter     INIT_FILE    = "",
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int LW          = DATA_WIDTH / MASK_WIDTH
) (
  input  wire logic                  clk,
  input  wire logic                  a_ce,
  input  wire logic                  a_we,
  input  wire logic [MASK_WIDTH-1:0] a_wmask,
  input  wire logic [AW-1:0]         a_addr,
  input  wire logic [DATA_WIDTH-1:0] a_wdata,
  output logic      [DATA_WIDTH-1:0] a_rdata,
  input  wire logic                  b_ce,
  input  wire logic                  b_we,
  input  wire logic [MASK_WIDTH-1:0] b_wmask,
  input  wire logic [AW-1:0]         b_addr,
  input  wire logic [DATA_WIDTH-1:0] b_wdata,
  output logic      [DATA_WIDTH-1:0] b_rdata
);

  if (READ_LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_fpga_2rw: READ_LATENCY must be >= 1")
  end
  if (MASK_WIDTH < 1 || (DATA_WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_not_divisor
    `SRAM_CFG_FATAL("sram_fpga_2rw: MASK_WIDTH must divide DATA_WIDTH")
  end

  (* ram_style = "block" *)
  logic [DATA_WIDTH-1:0] mem [DEPTH];
  logic [DATA_WIDTH-1:0] qa0, qb0;

  initial begin
    if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
  end

  always_ff @(posedge clk) begin
    if (a_ce) begin
      if (a_we) begin
        for (int l = 0; l < MASK_WIDTH; l++)
          if (a_wmask[l]) mem[a_addr][l*LW +: LW] <= a_wdata[l*LW +: LW];
      end else begin
        qa0 <= mem[a_addr];
      end
    end
    if (b_ce) begin
      if (b_we) begin
        for (int l = 0; l < MASK_WIDTH; l++)
          if (b_wmask[l]) mem[b_addr][l*LW +: LW] <= b_wdata[l*LW +: LW];
      end else begin
        qb0 <= mem[b_addr];
      end
    end
  end

  if (READ_LATENCY == 1) begin : g_lat1
    assign a_rdata = qa0;
    assign b_rdata = qb0;
  end else begin : g_latn
    logic [DATA_WIDTH-1:0] pa [READ_LATENCY-1];
    logic [DATA_WIDTH-1:0] pb [READ_LATENCY-1];
    always_ff @(posedge clk) begin
      pa[0] <= qa0;
      pb[0] <= qb0;
      for (int k = 1; k < READ_LATENCY - 1; k++) begin
        pa[k] <= pa[k-1];
        pb[k] <= pb[k-1];
      end
    end
    assign a_rdata = pa[READ_LATENCY-2];
    assign b_rdata = pb[READ_LATENCY-2];
  end

endmodule

`default_nettype wire
