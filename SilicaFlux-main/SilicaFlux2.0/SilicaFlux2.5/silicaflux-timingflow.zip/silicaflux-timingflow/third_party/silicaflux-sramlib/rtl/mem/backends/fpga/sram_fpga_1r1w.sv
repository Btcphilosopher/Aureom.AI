// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_fpga_1r1w
// FPGA backend, simple dual-port block RAM (1 write + 1 read port, one
// clock) by inference.
//
// Read-during-write at the same address: the RTL reads the array in a
// separate process from the write, i.e. the read returns the OLD word.  An
// inferring tool must preserve that RTL behaviour (Yosys adds bypass logic
// when the target primitive cannot provide it), so the guarantee comes from
// HDL semantics rather than from a vendor primitive mode.  The FPGA backend
// therefore accepts COLLISION=READ_OLD.
// Classification: SYNTHESIZABLE (block-RAM inference)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sram_fpga_1r1w #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  parameter     INIT_FILE    = "",
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int LW          = DATA_WIDTH / MASK_WIDTH
) (
  input  wire logic                  clk,
  input  wire logic                  we,
  input  wire logic [MASK_WIDTH-1:0] wmask,
  input  wire logic [AW-1:0]         waddr,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  input  wire logic                  re,
  input  wire logic [AW-1:0]         raddr,
  output logic      [DATA_WIDTH-1:0] rdata
);

  if (READ_LATENCY < 1) begin : g_err_latency_lt_1
    `SRAM_CFG_FATAL("sram_fpga_1r1w: READ_LATENCY must be >= 1")
  end
  if (MASK_WIDTH < 1 || (DATA_WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_not_divisor
    `SRAM_CFG_FATAL("sram_fpga_1r1w: MASK_WIDTH must divide DATA_WIDTH")
  end

  (* ram_style = "block" *)
  logic [DATA_WIDTH-1:0] mem [DEPTH];
  logic [DATA_WIDTH-1:0] q0;

  initial begin
    if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
  end

  always_ff @(posedge clk) begin
    if (we) begin
      for (int l = 0; l < MASK_WIDTH; l++) begin
        if (wmask[l]) mem[waddr][l*LW +: LW] <= wdata[l*LW +: LW];
      end
    end
  end

  always_ff @(posedge clk) begin
    if (re) q0 <= mem[raddr];
  end

  if (READ_LATENCY == 1) begin : g_lat1
    assign rdata = q0;
  end else begin : g_latn
    logic [DATA_WIDTH-1:0] pipe [READ_LATENCY-1];
    always_ff @(posedge clk) begin
      pipe[0] <= q0;
      for (int k = 1; k < READ_LATENCY - 1; k++) pipe[k] <= pipe[k-1];
    end
    assign rdata = pipe[READ_LATENCY-2];
  end

endmodule

`default_nettype wire
