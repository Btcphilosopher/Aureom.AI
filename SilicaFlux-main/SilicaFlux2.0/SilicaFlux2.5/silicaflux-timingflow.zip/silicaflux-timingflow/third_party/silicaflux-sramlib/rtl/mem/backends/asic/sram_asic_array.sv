// =============================================================================
// SilicaFlux SRAM Wrapper Library :: sram_asic_array
// ASIC backend: builds a logical DATA_WIDTH x DEPTH array from a grid of
// real foundry/compiler macro instances selected by MACRO (catalogue IDs in
// sram_macro_ids.svh, generated from manifests/*.json).
//
//   columns NC = ceil(DATA_WIDTH / macro width)  (width tiling, data padded)
//   rows    NR = ceil(DEPTH / macro words)       (depth tiling, registered
//                                                 row-select output mux)
//
// Hard rules (elaboration fails, nothing is substituted):
//   * MACRO must be a catalogue entry with a real macro (PENDING commercial
//     placeholders fail: no licensed compiler output exists).
//   * The port topology must be native to the macro: 1RW on any; 1R1W on
//     1RW1R (SKY130) or 2RW (IHP 2P); 2RW only on IHP 2P.
//   * READ_LATENCY >= the macro's native latency (extra stages = flops).
//   * Lane write masks must be representable: on byte-mask macros (SKY130)
//     the lane width must be a multiple of 8 (or MASK_WIDTH = 1).
// The only standard-cell logic added is the mask/data padding, the row
// decoder/one-hot chip enables and the registered read mux.
//
// Raw contract: as sram_generic_1rw.  Port A = the single port (MODE 0), the
// write port (MODE 1) or port A (MODE 2); port B = read port (MODE 1) or
// port B (MODE 2).
// Classification: SYNTHESIZABLE (instantiates hard-macro black boxes)
// =============================================================================
`include "sram_defs.svh"
`include "sram_macro_ids.svh"
`default_nettype none

module sram_asic_array #(
  parameter int MODE         = 0,
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  parameter int MACRO        = 0,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  a_ce,
  input  wire logic                  a_we,
  input  wire logic [MASK_WIDTH-1:0] a_wmask,
  input  wire logic [AW-1:0]         a_addr,
  input  wire logic [DATA_WIDTH-1:0] a_wdata,
  output logic      [DATA_WIDTH-1:0] a_rdata,
  input  wire logic                  b_ce,
  input  wire logic                  b_we,
  input  wire logic [MASK_WIDTH-1:0] b_wmask,
  input  wire logic [AW-1:0]         b_addr,
  input  wire logic [DATA_WIDTH-1:0] b_wdata,
  output logic      [DATA_WIDTH-1:0] b_rdata
);
  `include "sram_macro_funcs.svh"

  localparam int FAM  = sram_macro_family(MACRO);
  localparam int TOPO = sram_macro_topology(MACRO);
  localparam int MG   = sram_macro_mask_gran(MACRO);
  localparam int MLAT = sram_macro_latency(MACRO);
  localparam int MW   = (sram_macro_width(MACRO) > 0) ? sram_macro_width(MACRO) : 1;
  localparam int MD   = (sram_macro_words(MACRO) > 0) ? sram_macro_words(MACRO) : 1;
  localparam int MAW  = (sram_macro_addr_width(MACRO) > 0) ? sram_macro_addr_width(MACRO) : 1;
  localparam int NC   = (DATA_WIDTH + MW - 1) / MW;
  localparam int NR   = (DEPTH + MD - 1) / MD;
  localparam int PW   = NC * MW;
  localparam int RW   = (NR > 1) ? $clog2(NR) : 1;
  localparam int LW   = DATA_WIDTH / MASK_WIDTH;
  localparam int XL   = (READ_LATENCY > MLAT) ? READ_LATENCY - MLAT : 0;  // extra output stages
  localparam int SL   = (MLAT > 0) ? MLAT : 1;

  // ------------------------------------------------------------ configuration checks
  if (FAM == 0) begin : g_err_macro_not_in_catalogue
    `SRAM_CFG_FATAL("sram_asic_array: MACRO is not a catalogue entry (see sram_macro_ids.svh)")
  end else if (FAM == 9) begin : g_err_macro_pending_no_licensed_compiler_output
    `SRAM_CFG_FATAL("sram_asic_array: commercial placeholder selected; no macro exists (manifest status PENDING_NO_MACRO)")
  end
  if (MODE == 1 && !(TOPO == 2 || TOPO == 3)) begin : g_err_macro_cannot_do_1r1w
    `SRAM_CFG_FATAL("sram_asic_array: 1R1W requested but the macro has no independent read port")
  end
  if (MODE == 2 && TOPO != 3) begin : g_err_macro_cannot_do_2rw
    `SRAM_CFG_FATAL("sram_asic_array: 2RW requested but the macro is not a true dual-port macro")
  end
  if (MODE < 0 || MODE > 2) begin : g_err_bad_mode
    `SRAM_CFG_FATAL("sram_asic_array: MODE must be 0, 1 or 2")
  end
  if (READ_LATENCY < MLAT) begin : g_err_latency_below_macro_latency
    `SRAM_CFG_FATAL("sram_asic_array: READ_LATENCY is below the macro's native read latency")
  end
  if (MASK_WIDTH < 1 || (DATA_WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_not_divisor
    `SRAM_CFG_FATAL("sram_asic_array: MASK_WIDTH must divide DATA_WIDTH")
  end
  if (MG > 1 && MASK_WIDTH != 1 && (LW % MG) != 0) begin : g_err_lane_not_multiple_of_macro_mask_granularity
    `SRAM_CFG_FATAL("sram_asic_array: lane width is not a multiple of the macro write-mask granularity")
  end

  // ------------------------------------------------------------ port shaping
  logic [PW-1:0] a_bm, b_bm, a_wd, b_wd;
  always_comb begin
    a_bm = '0; b_bm = '0; a_wd = '0; b_wd = '0;
    for (int b = 0; b < PW; b++) begin
      if (b < DATA_WIDTH) begin
        a_bm[b] = a_wmask[b / LW];
        b_bm[b] = b_wmask[b / LW];
        a_wd[b] = a_wdata[b];
        b_wd[b] = b_wdata[b];
      end else if (MASK_WIDTH == 1) begin   // padding bits ride with the single lane
        a_bm[b] = a_wmask[0];
        b_bm[b] = b_wmask[0];
      end
    end
  end

  logic [RW-1:0]  a_row, b_row;
  logic [MAW-1:0] a_la, b_la;
  if (NR > 1) begin : g_rows
    assign a_row = RW'(a_addr >> MAW);
    assign b_row = RW'(b_addr >> MAW);
    assign a_la  = a_addr[MAW-1:0];
    assign b_la  = b_addr[MAW-1:0];
  end else begin : g_onerow
    assign a_row = '0;
    assign b_row = '0;
    assign a_la  = MAW'(a_addr);
    assign b_la  = MAW'(b_addr);
  end

  // read-select pipelines (aligned with the macro latency)
  wire a_rd = a_ce & ~a_we & (MODE != 1);
  wire b_rd = b_ce & ((MODE == 1) ? 1'b1 : ~b_we) & (MODE != 0);
  logic [RW-1:0] a_sel [SL];
  logic [RW-1:0] b_sel [SL];
  always_ff @(posedge clk) begin
    if (a_rd) a_sel[0] <= a_row;
    if (b_rd) b_sel[0] <= b_row;
    for (int k = 1; k < SL; k++) begin
      a_sel[k] <= a_sel[k-1];
      b_sel[k] <= b_sel[k-1];
    end
  end

  // ------------------------------------------------------------ macro grid
  logic [NR*PW-1:0] a_q_all, b_q_all;
  for (genvar r = 0; r < NR; r++) begin : g_r
    wire a_ce_r = a_ce & (a_row == RW'(r));
    wire b_ce_r = b_ce & (b_row == RW'(r)) & (MODE != 0);
    for (genvar c = 0; c < NC; c++) begin : g_c
      logic [MW-1:0] qa, qb;
      if (FAM == 1) begin : g_sky130
        sram_leaf_sky130 #(.MACRO(MACRO), .MODE(MODE), .MW(MW), .MAW(MAW)) u_leaf (
          .clk, .a_ce(a_ce_r), .a_we, .a_bm(a_bm[c*MW +: MW]), .a_addr(a_la), .a_wdata(a_wd[c*MW +: MW]), .a_rdata(qa),
          .b_ce(b_ce_r), .b_we, .b_bm(b_bm[c*MW +: MW]), .b_addr(b_la), .b_wdata(b_wd[c*MW +: MW]), .b_rdata(qb));
      end else if (FAM == 2) begin : g_gf180
        sram_leaf_gf180 #(.MACRO(MACRO), .MODE(MODE), .MW(MW), .MAW(MAW)) u_leaf (
          .clk, .a_ce(a_ce_r), .a_we, .a_bm(a_bm[c*MW +: MW]), .a_addr(a_la), .a_wdata(a_wd[c*MW +: MW]), .a_rdata(qa),
          .b_ce(b_ce_r), .b_we, .b_bm(b_bm[c*MW +: MW]), .b_addr(b_la), .b_wdata(b_wd[c*MW +: MW]), .b_rdata(qb));
      end else if (FAM == 3) begin : g_ihp1p
        sram_leaf_ihp1p #(.MACRO(MACRO), .MODE(MODE), .MW(MW), .MAW(MAW)) u_leaf (
          .clk, .a_ce(a_ce_r), .a_we, .a_bm(a_bm[c*MW +: MW]), .a_addr(a_la), .a_wdata(a_wd[c*MW +: MW]), .a_rdata(qa),
          .b_ce(b_ce_r), .b_we, .b_bm(b_bm[c*MW +: MW]), .b_addr(b_la), .b_wdata(b_wd[c*MW +: MW]), .b_rdata(qb));
      end else if (FAM == 4) begin : g_ihp2p
        sram_leaf_ihp2p #(.MACRO(MACRO), .MODE(MODE), .MW(MW), .MAW(MAW)) u_leaf (
          .clk, .a_ce(a_ce_r), .a_we, .a_bm(a_bm[c*MW +: MW]), .a_addr(a_la), .a_wdata(a_wd[c*MW +: MW]), .a_rdata(qa),
          .b_ce(b_ce_r), .b_we, .b_bm(b_bm[c*MW +: MW]), .b_addr(b_la), .b_wdata(b_wd[c*MW +: MW]), .b_rdata(qb));
      end else begin : g_none
        assign qa = '0;
        assign qb = '0;
      end
      assign a_q_all[r*PW + c*MW +: MW] = qa;
      assign b_q_all[r*PW + c*MW +: MW] = qb;
    end
  end

  // ------------------------------------------------------------ read mux + extra stages
  logic [PW-1:0] a_q, b_q;
  always_comb begin
    a_q = a_q_all[0 +: PW];
    b_q = b_q_all[0 +: PW];
    for (int r = 1; r < NR; r++) begin
      if (a_sel[SL-1] == RW'(r)) a_q = a_q_all[r*PW +: PW];
      if (b_sel[SL-1] == RW'(r)) b_q = b_q_all[r*PW +: PW];
    end
  end

  if (XL == 0) begin : g_noextra
    assign a_rdata = a_q[DATA_WIDTH-1:0];
    assign b_rdata = b_q[DATA_WIDTH-1:0];
  end else begin : g_extra
    logic [DATA_WIDTH-1:0] pa [XL];
    logic [DATA_WIDTH-1:0] pb [XL];
    always_ff @(posedge clk) begin
      pa[0] <= a_q[DATA_WIDTH-1:0];
      pb[0] <= b_q[DATA_WIDTH-1:0];
      for (int k = 1; k < XL; k++) begin
        pa[k] <= pa[k-1];
        pb[k] <= pb[k-1];
      end
    end
    assign a_rdata = pa[XL-1];
    assign b_rdata = pb[XL-1];
  end

`ifndef SYNTHESIS
`ifdef SRAMLIB_VERBOSE
  initial $display("[sramlib] %m: ASIC macro id %0d family %0d: %0d col x %0d row = %0d instance(s) of %0dx%0d for %0dx%0d, latency %0d+%0d",
                   MACRO, FAM, NC, NR, NC*NR, MD, MW, DEPTH, DATA_WIDTH, MLAT, XL);
`endif
`endif

endmodule

`default_nettype wire
