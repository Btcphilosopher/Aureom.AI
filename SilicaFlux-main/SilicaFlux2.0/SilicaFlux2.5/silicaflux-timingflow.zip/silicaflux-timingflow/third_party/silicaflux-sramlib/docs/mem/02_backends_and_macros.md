# 02 — Backends and the foundry-macro adapter framework

## 1. Backends

| | GENERIC | FPGA | ASIC |
|---|---|---|---|
| Files | `rtl/mem/backends/generic/sram_generic_{1rw,1r1w,2rw}.sv` | `rtl/mem/backends/fpga/sram_fpga_{1rw,1r1w,2rw}.sv` | `rtl/mem/backends/asic/sram_asic_array.sv` + generated `sram_leaf_*.sv` |
| Storage | behavioural / inferred array | block-RAM inference template (`ram_style="block"`, per-lane write loop, no-change read on 1RW) | real macro instances (black boxes in synthesis, vendor models in simulation) |
| Purpose | RTL simulation, early logic synthesis, formal | FPGA validation boards | silicon |
| Extras | sim-only fault injection (SA0/SA1/TF↑/TF↓/CFid/AF) and X-poisoning of non-valid read slots | optional `INIT_FILE`; latency 2 uses the BRAM output register | width/depth tiling, mask mapping, registered row-select read mux |
| Fallback to flip-flops | — | — | **never**: `BACKEND=ASIC` without a catalogue macro is an elaboration error |

`sram_backend_{1rw,1r1w,2rw}` select the backend; every wrapper instantiates only these selectors.

## 2. Open-PDK SRAM macros investigated

All facts below are extracted by `scripts/mem/build_manifests.py` from the public sources (Apache-2.0) at the
pinned commits, with file hashes recorded in each manifest's `provenance`:

| PDK | Source (commit) | Macros found | Topology | Write mask | Ctrl polarity | Output | Cross-port collision |
|---|---|---|---|---|---|---|---|
| SKY130 (OpenRAM) | `efabless/sky130_sram_macros` @ `ebfbf57` | `sky130_sram_1kbyte_1rw1r_32x256_8`, `_2kbyte_1rw1r_32x512_8`, `_1kbyte_1rw1r_8x1024_8` | 1RW + 1R | byte (`wmask0`, active high) | `csb*`, `web0` active low | **not held**: X one `T_HOLD` after each edge | undefined (model warns) |
| GF180MCU | `google/globalfoundries-pdk-ip-gf180mcu_fd_ip_sram` @ `9c41192` | `gf180mcu_fd_ip_sram__sram{64,128,256,512}x8m8wm1` | 1RW | **bit** (`WEN`, active low) | `CEN`, `GWEN` active low | held (truth table) | n/a |
| IHP SG13G2 | `IHP-GmbH/IHP-Open-PDK` @ `5e6d592` (`libs.ref/sg13g2_sram`) | 18 × `RM_IHPSG13_1P_*_bm_bist`, 9 × `RM_IHPSG13_2P_*_bm_bist` (8 b … 64 b, 64 … 4096 words) | 1P: 1RW; 2P: **true 2RW** | bit (`*_BM`, active high) | `*_MEN/WEN/REN` active high | held | 2P: "no conflict handling included" (datasheet) |

Notes recorded in the manifests: the SKY130 README advertises single-port, pseudo-dual-port and true-dual-port
configurations, but the repository at that commit contains **only 1RW1R** macros; GF180 requires `CEN` high
before the first access (the model ignores accesses until it sees a CEN 1→0 transition) and its spec CSV for the
512×8 cell lists `A[6:0]` although the Verilog model and LEF have `A[8:0]` (the manifest uses the model/LEF);
IHP requires `*_DLY` tied to 1 and forbids accesses one cycle around `*_BIST_EN` changes.  The IHP macros
`1P_64x16_c2`, `1P_8192x32_c4` and `2P_64x32_c2` have a different pin set (no BIST/BM) and are not adapted.

Not available from these sources: sleep/retention pins (none of the macros has one), characterised minimum cycle
time for SKY130 and IHP in a form the manifests extract (GF180 provides `Tcyc` per corner in its spec CSV), and any
silicon qualification data.

## 3. Manifests

`manifests/<macro>.json` (34 real + 3 commercial placeholders) carry every field the brief requires: macro name,
foundry/process, data width, words, port topology, read latency, write-mask granularity and polarity, clock,
chip-enable and write-enable polarity, sleep/retention, collision behaviour, output-hold behaviour, supply pins,
Liberty / LEF / GDS / Verilog / CDL views (as present in the source tree), physical size and its source file,
timing source, licence and access status, constraints, and the **pin map** from the generic port to the macro
pins.  Example (`manifests/RM_IHPSG13_1P_1024x32_c2_bm_bist.json`):

```
generic clk  -> A_CLK            generic ce -> A_MEN      generic we -> A_WEN
generic re   -> A_REN = ce & ~we (write-through never used)
wmask lane l -> A_BM[bits of lane l]      addr -> A_ADDR   wdata -> A_DIN   rdata -> A_DOUT
tied         -> A_DLY = 1, A_BIST_EN = 0, other A_BIST_* = 0
```

`scripts/mem/build_catalog.py` turns the manifests into RTL: `sram_macro_ids.svh` (IDs), `sram_macro_funcs.svh`
(width/words/family/mask granularity/latency/topology lookups used at elaboration), the per-family leaf adapters
and `stubs/sram_macro_blackboxes.sv`.  `make mem-catalog-check` fails if the RTL and manifests drift.

## 4. Tiling and rejection rules (`sram_asic_array`)

* `NC = ceil(DATA_WIDTH / macro width)` columns, `NR = ceil(DEPTH / macro words)` rows; padding bits are written
  as 0 with mask 0 (or with the single lane's mask when `MASK_WIDTH = 1`).
* Row select is registered at the read edge and pipelined with the macro latency; extra `READ_LATENCY` stages are
  plain registers.
* Rejected at elaboration with a message: unknown macro; commercial placeholder; 1R1W on a macro without an
  independent read port (GF180, IHP 1P); 2RW on anything but IHP 2P; `READ_LATENCY` below the macro latency;
  lane widths not representable by byte-mask macros (e.g. 9-bit lanes on SKY130); `COLLISION=READ_OLD` on ASIC;
  `INIT_FILE` on ASIC.  All are exercised by the lint suite's negative tests.

## 5. Evidence that the adapters are right

* **Vendor-model equivalence** (`make mem-equiv`): the same self-checking testbench and seed run twice in Icarus,
  once on GENERIC and once on the ASIC backend compiled with the *vendor* Verilog models (IHP in its documented
  `FUNCTIONAL` mode).  Both must pass and their request/response traces must be byte-identical.  Configurations
  include native and tiled (2×4, 2×3, 1×2, 2×1) arrays, byte- and bit-mask macros, 1RW on 1RW1R/1P macros, 1R1W on
  SKY130 and IHP 2P, true 2RW on IHP 2P and a 4-bank controller on SKY130 macros.  Results:
  `reports/mem/regression.md` (equiv section).
* **Vendor-model hold time** (simulation only): the generated leaves contain a delay stage that is active only when
  `SRAMLIB_VENDOR_MODELS` is defined — `assign #1 {ce, we, bm, addr, wdata}` into the macro.  The GF180MCU
  model samples its write inputs `Tdly` = 100 ps *after* the clock edge, so a zero-delay adapter feeding it from
  registers clocked on the same edge races (hold violation in zero-delay simulation; it corrupted writes in the
  first equivalence run).  The 1 ns delay models the real clock-to-Q of the driving flops; it is a simulation
  artefact only — without the define (synthesis, GENERIC simulation) the leaf is zero-delay wiring.  Real hold
  margins must come from STA with the Liberty views.
* **Macro integrity in synthesis** (`make mem-synth`): Yosys with the black-box stubs must keep exactly the
  expected number of macro instances and no `$mem` cells.  Results: `reports/mem/synth.md`.

What is **not** shown: timing closure against the Liberty views, LEF-based placement, power-pin connection, DRC/LVS,
or behaviour of any macro in silicon.

## 6. Commercial 130 / 65 / 28 nm

`manifests/commercial_{130,65,28}nm_pending.json` define IDs 90-92 with status `PENDING_NO_MACRO` and every
technical field `null`.  Selecting them fails elaboration.  Integration steps (also in each manifest):

1. obtain the memory-compiler outputs (Verilog model, Liberty per corner, LEF, GDS/OASIS, datasheet) under licence;
2. fill the manifest from those files (never from memory) and set `status`;
3. add a family leaf to `scripts/mem/build_catalog.py` mapping the generic leaf port (active-high `ce/we`, bit mask
   `bm`, `addr`, `wdata` → `rdata`) to the macro pins, including test/retention pins and tie-offs;
4. `make mem-catalog`, then `make mem-equiv` against the vendor model and `make mem-synth` for macro integrity.

No proprietary macro source, model, LEF or Liberty is included in this library.
