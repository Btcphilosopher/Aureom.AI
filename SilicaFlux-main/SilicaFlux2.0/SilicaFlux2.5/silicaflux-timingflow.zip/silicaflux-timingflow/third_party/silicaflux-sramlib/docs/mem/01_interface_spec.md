# 01 — Memory interface specification

The library has two interface levels.  Both are identical for every backend (GENERIC, FPGA, ASIC); changing
`BACKEND`/`MACRO` never changes ports, timing or ordering.

| Level | Modules | Used by |
|---|---|---|
| **Raw (macro-shaped)** | `sram_backend_1rw`, `sram_backend_1r1w`, `sram_backend_2rw` | tightly coupled pipelines that already own arbitration and credits (e.g. the SilicaFlux 2.5 `memory_controller` banks) |
| **Handshake** | `sram_sp`, `sram_1r1w`, `sram_tdp`, `sram_bank_controller` | CPU, vector, tensor and DMA masters |

## 1. Parameters

| Parameter | Meaning | Rules (violations fail elaboration) |
|---|---|---|
| `DATA_WIDTH` | bits per word | ≥ 1 |
| `DEPTH` | words | ≥ 2; any value (non-powers of two supported) |
| `AW` (localparam) | address width = `clog2(DEPTH)` (min 1) | derived; never set by the user |
| `MASK_WIDTH` | write-mask lanes; lane width `LW = DATA_WIDTH / MASK_WIDTH` | must divide `DATA_WIDTH`.  `DATA_WIDTH/8` = byte lanes (default when divisible), `DATA_WIDTH` = bit mask, `1` = whole-word writes, 9-bit lanes etc. allowed |
| `READ_LATENCY` | cycles from the read edge to valid data | ≥ 1; ASIC ≥ macro native latency (1 for every supported macro); FPGA 1 = BRAM latch, 2 = + BRAM output register |
| `BACKEND` | `SRAM_BACKEND_GENERIC` (0), `_FPGA` (1), `_ASIC` (2) | ASIC requires an explicit `MACRO` |
| `MACRO` | catalogue ID (`sram_macro_ids.svh`, generated from `manifests/`) | must be a real macro; commercial placeholders 90-92 fail |
| `RSP_FIFO_DEPTH` | response credits per port | default `READ_LATENCY+1` (sustains 1 access/cycle); `0` = no backpressure allowed |
| `WRITE_ACK` | 1: every write answered (`rsp_we=1`); 0: posted | 0 or 1 |
| `ID_WIDTH` | request tag echoed on the response | ≥ 1 |
| `TEST_EN` | include the MBIST test-port mux | 0/1 |
| `COLLISION` | `sram_1r1w` / `sram_tdp` same-address policy (§6) | only modes the backend can honour |
| `INIT_FILE` | `$readmemh` image | **FPGA backend only** (§9) |
| Reset behaviour | control/status/output-valid registers reset asynchronously by `rst_n`; arrays and data registers are never reset | fixed by design |

## 2. Addressing, lanes, endianness

* Library primitives use **word addresses**.  Address `a` selects word `a` (0 … `DEPTH-1`).
* `sram_bank_controller` additionally accepts **byte addresses** (`ADDR_MODE = SRAM_ADDR_BYTE`): the low
  `log2(DATA_WIDTH/8)` bits must be zero, else the request completes with `rsp_err=1` (misaligned).
* Lane `l` of `wdata/rdata/wmask` is bits `[l*LW +: LW]`.  With byte lanes and byte addressing, byte `k` of the
  word at byte address `A` is lane `k` (**little-endian**).
* **Invalid addresses** (`addr ≥ DEPTH`, only representable when `DEPTH` is not a power of two, or any
  out-of-range system address in the bank controller) are accepted, never touch the array, and produce a response
  with `rsp_err = 1` and zero data — also for writes when `WRITE_ACK = 0` (errors are never silent); `sram_1r1w`
  writes pulse `wr_err`.

## 3. Raw backend contract

```
clk  ce  we  wmask[MW]  addr[AW]  wdata[DW]  ->  rdata[DW]      (1RW)
clk  we wmask waddr wdata ; re raddr          ->  rdata          (1R1W)
two independent 1RW ports a_*, b_*                               (2RW)
```

1. One access per port per cycle; inputs sampled on the rising edge.
2. Write: lanes with `wmask=1` take `wdata`; other lanes keep their value.  A write produces no read data.
3. Read: `rdata` is valid **exactly `READ_LATENCY` cycles after the read edge, for that one cycle**.  It is **not
   held** afterwards: the SKY130 OpenRAM model drives X one hold time after every following clock edge, so the
   library never relies on hold, and in simulation the GENERIC backend drives X (`SRAMLIB_POISON`) in every cycle
   that is not a valid read slot to catch consumers that do.
4. `addr < DEPTH` (the handshake wrappers guarantee it; GENERIC simulation reports violations).
5. 2RW: same-address accesses on both ports in one cycle with a write on either are **outside** the contract.
6. No reset of the array; no initial content except `INIT_FILE` on FPGA.

## 4. Handshake contract (`sram_sp`, per port of `sram_tdp`, per master of `sram_bank_controller`)

```
request : req_valid, req_ready, req_we, req_addr, req_wdata, req_wmask, req_id
response: rsp_valid, rsp_ready, rsp_rdata, rsp_err, rsp_we, rsp_id
```

| Item | Rule |
|---|---|
| Transfer | request accepted on a rising edge with `req_valid && req_ready`; response delivered with `rsp_valid && rsp_ready` |
| Master obligations | hold `req_valid` and the payload stable until accepted; never drive valid in reset (checked by `sram_if` assertions and assumed by the formal harnesses) |
| `req_ready` | 0 in reset and the cycle after; 0 in test mode; otherwise 1 when a response credit is free (posted writes need none).  It may depend combinationally on the request payload and, for 1R1W/2RW/banked ports, on the other channel (collision/arbitration) — never on `rsp_ready` |
| Read completion | response `READ_LATENCY` cycles after acceptance when not back-pressured |
| Write completion | the write is architecturally complete at the acceptance edge: any read accepted in a **later** cycle returns it.  `WRITE_ACK=1` adds an acknowledgement in order |
| Ordering | exactly one response per response-producing request, strictly in acceptance order per port/master, carrying that request's `req_id` — never dropped, duplicated or unsolicited |
| Backpressure | `rsp_*` hold stable while `rsp_valid && !rsp_ready`; credits bound outstanding responses to `RSP_FIFO_DEPTH`, so the response FIFO can never overflow; there is no combinational path `rsp_ready → req_ready` |
| Back-to-back | one request per cycle per port sustained when `RSP_FIFO_DEPTH ≥ READ_LATENCY+1` and the response channel is not stalled (measured in `tb_sram_sp` P2/P3) |
| No-backpressure mode | `RSP_FIFO_DEPTH = 0`: zero storage; master must keep `rsp_ready = 1` (assertion) |
| Response data | read data for reads; all-zero for write acknowledgements and error responses |

## 5. 1R1W contract (`sram_1r1w`)

Write channel `wr_valid/wr_ready/wr_addr/wr_data/wr_mask` (posted, `wr_err` on invalid address); read channel
`rd_valid/rd_ready/rd_addr/rd_id` with the response channel of §4 (`rsp_we` not present).  Reads and writes to
different addresses are accepted in the same cycle (measured: thousands of dual-issue cycles per test).

**Ordering rule (all policies): a read returns the data written by every write accepted in an earlier cycle and
never that of a write accepted in the same cycle.**

## 6. Collision policies

| Policy | 1R1W | 2RW | Behaviour | Allowed backends |
|---|---|---|---|---|
| `SRAM_COLL_STALL` (default) | ✓ | ✓ | a same-address pair involving a write is never issued; the side without priority is back-pressured; priority alternates after each collision (starvation-free: ≤ 2 cycles wait without backpressure — simulated and formally bounded-proven) | all |
| `SRAM_COLL_READ_OLD` | ✓ | — | both issued; read returns the old word | GENERIC, FPGA (inference must preserve RTL read-first semantics).  **Rejected for ASIC**: SKY130 OpenRAM and IHP 2P define cross-port same-address access as undefined |
| `SRAM_COLL_FORBID` | ✓ | ✓ | master guarantees no collision; assertion; colliding read returns X in simulation; no arbitration logic | all |

`sram_tdp` outcome under STALL: the two accesses behave as if executed sequentially in acceptance order
(write/write: the later accepted write wins).

## 7. Bank controller

See `03_banking.md`.  Each master port follows §4 with its own credits and ID-ordered responses; a bank grants one
master per cycle; requests are accepted in the cycle their bank grants them.

## 8. MBIST test port

`tst_active, tst_ce, tst_we, tst_addr, tst_wdata → tst_rdata` (bank controller: plus `tst_sel[NUM_BANKS]`).
`tst_active` hands the array to the test bus for as long as it is high (functional `req_ready = 0`; requests
already accepted complete normally).  Test writes cover all lanes; test reads return raw array data exactly
`READ_LATENCY` cycles later (never held).  Test addresses ≥ DEPTH are ignored (gated; found by formal).  Same
contract as the TestCore `tc_mbist_collar` bus — see `04_mbist.md`.

## 9. Initialisation

| Target | Policy |
|---|---|
| ASIC SRAM | no defined power-up content; software/hardware must write before reading.  `INIT_FILE` is rejected at elaboration.  A boot ROM is a different macro class and is out of scope |
| FPGA | `INIT_FILE` → `$readmemh` (bitstream-initialised block RAM) |
| GENERIC simulation | testbench-controlled loading through the functional or test port (preferred), or a simulation-only backdoor (`<inst>.u_array.g_generic.u_mem.mem[i]`) |
| SilicaFlux 2.5 controller | keeps its own `INIT_ON_RESET` zeroing sweep through the port — macro-compatible |

## 10. Timing summary

| Event | Cycle |
|---|---|
| request accepted | t (edge at end of cycle t) |
| array read | edge t |
| response visible (no backpressure) | t + `READ_LATENCY` |
| write visible to reads accepted at | ≥ t + 1 |
| raw test-port read data | exactly t + `READ_LATENCY` |
