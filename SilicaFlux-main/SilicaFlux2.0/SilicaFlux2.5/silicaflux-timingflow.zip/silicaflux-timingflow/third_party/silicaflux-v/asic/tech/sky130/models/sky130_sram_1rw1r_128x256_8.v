// BEHAVIOURAL stand-in for the OpenRAM sky130_sram_1rw1r_128x256_8 macro
// (pin-compatible, port 0 only, 1-cycle read, active-low csb/web, byte wmask).
// Used ONLY to simulate the macro-tiling wrapper; timing/area come from the
// macro's LIB/LEF.  Replace with the OpenRAM-generated model for signoff sim.
module sky130_sram_1rw1r_128x256_8 (
  input clk0, input csb0, input web0, input [15:0] wmask0, input [7:0] addr0,
  input [127:0] din0, output reg [127:0] dout0,
  input clk1, input csb1, input [7:0] addr1, output [127:0] dout1);
  reg [127:0] mem [0:255];
  integer b;
  always @(posedge clk0) if (!csb0) begin
    if (!web0) begin
      for (b = 0; b < 16; b = b + 1) if (wmask0[b]) mem[addr0][b*8 +: 8] <= din0[b*8 +: 8];
    end else dout0 <= mem[addr0];
  end
  assign dout1 = 128'd0;
endmodule
