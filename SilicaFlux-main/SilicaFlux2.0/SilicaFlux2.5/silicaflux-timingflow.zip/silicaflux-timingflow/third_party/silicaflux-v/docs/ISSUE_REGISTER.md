# Engineering issue register

Severity: **B** = blocker for tape-out, **H** high, **M** medium, **L** low.
Status: OPEN / RESOLVED (with the evidence of the fix).

## Open

| ID | Sev | Area | Issue | Required action |
|---|---|---|---|---|
| ISS-001 | B | physical | No physical signoff: no CTS, detailed routing, parasitic extraction, multi-corner STA, DRC/LVS/antenna, IR-drop/EM.  Timing/power in this release are post-placement estimates with ideal clocks at the typical corner. | Full P&R in the target PDK; MCMM signoff (ss/ff, temperature); hold fixing post-CTS. |
| ISS-002 | B | foundry IP | Commercial SRAM compiler macros, I/O pad library (+ESD, power pads), and optionally a ROM macro are not integrated (open baselines use sky130 OpenRAM / IHP SG13G2 macros). | Select node/foundry, generate SRAM instances (4× 8192×32, 4× 1024×32 SP, byte-write), implement `asic/tech/<pdk>/` wrappers, pad ring. |
| ISS-003 | B | DFT | Scan insertion, ATPG, compression and at-speed test (no on-chip clock controller) not done. | Commercial DFT flow (docs/DFT.md §Remaining); add OCC; ≥98 % SA coverage target. |
| ISS-004 | H | DFT | No boundary-scan register: EXTEST/SAMPLE/PRELOAD unimplemented → not IEEE 1149.1 compliant; no BSDL. | Add BSR with the pad ring (testcore `tc_bsr` reference), generate BSDL, run compliance patterns. |
| ISS-005 | H | cost/area | sky130 OpenRAM macros are 0.72 mm² per 4 KiB: 144 KiB of SRAM needs 36 macros ≈ 26 mm² of the ≈ 34 mm² die.  IHP SG13G2 compiled SRAM is ≈ 6× denser. | For an open-PDK MPW use IHP SG13G2, or a reduced-SRAM sky130 configuration (e.g. `SRAM_BANK_WORDS=2048` → 32 KiB, firmware linker update). |
| ISS-006 | H | timing | Reset distribution: `sys_rst_n` has > 2 000 asynchronous reset sinks driven from one test-mode mux; recovery/removal must be closed with a balanced, buffered reset tree after CTS. | Reset-tree synthesis (or CTS-style buffering), recovery/removal signoff; consider a per-region reset synchroniser. |
| ISS-007 | H | verification | FPGA bitstream built (post-route Fmax 39.2 MHz vs 25 MHz target) but **not tested on hardware**. | Execute docs/FPGA.md §bring-up on a ULX3S-85F; record results. |
| ISS-008 | M | CDC | `sfv_sync` uses generic flops; no characterised synchroniser cells, no MTBF analysis, no structural CDC tool run. | Map to library synchroniser cells (dont_touch), run a CDC/RDC checker. |
| ISS-009 | M | debug | No RISC-V External Debug (DM/DTM): JTAG gives bus access, CPU hold/reset and boot override, but no halt/step/breakpoints/register access. | Add a minimal DM (abstract commands) if interactive debug of silicon is required; OpenOCD config. |
| ISS-010 | M | identity | JEDEC manufacturer ID placeholder (`JTAG_MFR = 0x000`), `mvendorid`/`marchid` = 0. | Obtain JEDEC ID; register marchid with RISC-V International if desired. |
| ISS-011 | M | formal | CPU bus-protocol properties proven by BMC to depth 16 only (PDR did not converge in 15 min); no formal on VE/TE/sequencer equivalence. | Add invariants/abstractions for induction; consider riscv-formal integration (RVFI trace port exists: `rt_*`). |
| ISS-012 | M | verification | No gate-level simulation with SDF; no power-aware simulation. | Run the SoC firmware regression on the post-route netlist. |
| ISS-013 | M | performance | Tensor engine fetches A and B words sequentially from single-port banks: 8 MAC/cycle peak. | Operand double-buffering / 4-word beat fetch → 16 MAC/cycle (next revision). |
| ISS-014 | M | memory | No ECC/parity on SRAM/TSPM. | Add parity or SECDED (memoryflow `sf_ecc_secded_*` available) if the reliability target requires it. |
| ISS-015 | L | architecture | No DMA engine; the CPU moves accelerator operands (~4 cycles/word). | Optional SFB master DMA (memoryflow `sf_dma` as reference). |
| ISS-016 | L | security | Boot image check is an integrity check, not authentication; JTAG is always open. | Secure boot / JTAG lock (testcore `tc_mode_ctrl` unlock scheme) for a product. |
| ISS-017 | L | bus | CPU instruction port may change an ungranted request's address after a redirect (documented exception to the OBI stability rule; crossbar samples only on grant). | Keep documented, or register the redirect address one cycle earlier. |
| ISS-018 | L | power | No power domains / retention / DVFS; power numbers use 10 % default input activity. | VCD-based power from the firmware regression on the final netlist. |
| ISS-019 | L | boot | SPI boot reads from flash offset 0 (the FPGA's configuration flash cannot be shared without an offset). | Optional ROM build flag for an image offset. |
| ISS-020 | L | clocking | No on-chip PLL or clock monitor; frequency set by the board oscillator. | Add a PLL only if a measured requirement appears (keeps analog IP out of first silicon). |

## Resolved during this release (defects found by verification)

| ID | Area | Defect | Found by | Fix / evidence |
|---|---|---|---|---|
| ISS-101 | CPU | `SRA/SRAI` computed a logical shift: `$signed(x) >>> s` inside a ternary with an unsigned arm is evaluated unsigned. | riscv-tests `sra`, `srai`, `lui` | dedicated signed wire; 55/55 tests pass |
| ISS-102 | CPU | A write to `minstreth`/`mcycleh` did not suppress the 64-bit counter increment of that instruction (low half advanced). | riscv-tests `rv32mi/instret_overflow` | increment suppressed on any half write |
| ISS-103 | CPU | `FENCE.I` did not flush the prefetch buffer (stale instructions after self-modifying code). | design review against `rv32ui/fence_i` | FENCE.I redirects to pc+4; test passes |
| ISS-104 | tile | TSPM lock handshake cost an extra cycle; CYCLES started at 1 (formula mismatch). | firmware T4/T5 latency checks | combinational grant when free; CYCLES = BUSY cycles; formulas checked in RTL, firmware, Python |
| ISS-105 | VE | tail-lane mask of a read issued for beat+1 was computed from the current beat. | design review | mask computed from the issued beat; tail sentinels checked in T4 and cocotb |
| ISS-106 | SYSCTRL | MBIST status read right after START could show the previous run's DONE (1-cycle race). | design review of ROM polling loop | BUSY forced / DONE masked in the start cycle |
| ISS-107 | SYSCTRL | boot straps loaded by an asynchronous *data* load in the reset branch (not scan-safe). | design review | straps sampled 3 cycles after reset release |
| ISS-108 | testbench | Async-reset flops of an idle clock domain (TCK) stayed X in Icarus because the reset pin had no edge; Verilator hid it (X→0). | Icarus vs Verilator divergence | reset asserted with an edge in all testbenches; Icarus SoC smoke passes |
| ISS-110 | build | SoC simulation build failed in a clean checkout: Verilator `-Mdir` creates only one directory level (`build/soc/` missing). | clean-room test of the release zip | `mkdir -p build/soc` in Makefile/regress.sh; full flow re-run from a fresh extract passes |
| ISS-109 | flow | Pre-layout STA reported −185 ns WNS: unbuffered reset net (2 045 sinks). | OpenSTA | OpenROAD `repair_design` stage added; recovery reported separately (ISS-006 tracks closure) |
