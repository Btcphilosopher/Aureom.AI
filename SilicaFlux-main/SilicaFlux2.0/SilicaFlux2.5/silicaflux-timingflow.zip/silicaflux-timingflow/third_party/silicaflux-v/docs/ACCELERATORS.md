# Vector and tensor engines

Both engines live in the compute tile (`rtl/accel/sfv_tile.sv`) and operate
memory-to-memory on the **tile scratchpad (TSPM)**: 16 KiB at `0x2000_0000`,
four word-interleaved single-port banks (bank = byte address[3:2]).  The CPU
(or the JTAG host) places operands in the TSPM with ordinary loads/stores,
programs the engine's register page, writes `CTRL.START`, and polls
`STATUS` or takes the completion interrupt (INTC sources 3 / 4).

Common register conventions: `CTRL[0]` START (write-1), `CTRL[1]` IRQ_EN,
`STATUS[0]` BUSY, `[1]` DONE (W1C), `[2]` ERR (W1C), `[7:4]` ERRCODE
(1 ALIGN, 2 RANGE, 3 BADOP, 4 BUSY).  Configuration registers are ignored
while BUSY.  An illegal command sets ERR and is **not** executed; START while
busy sets ERR/BUSY and the running command completes unaffected.  `CYCLES`
holds the number of BUSY cycles of the last command.

Arbitration: one engine holds the TSPM lock per command (TE wins a
same-cycle tie); the lock holder has priority over the fabric on every bank,
so **engine latency depends only on the command** (verified under random
concurrent fabric traffic, `tb/unit/test_tile.py`).

## Vector engine (VE page `0x4001_0000`)

| Off | Register | |
|---|---|---|
| 0x08 | CMD | [3:0] OP, [8] BSCALAR (b = SCALAR), [9] ACC (DOT adds to RESULT), [10] WRES (DOT stores RESULT at DST) |
| 0x0C/0x10/0x14 | SRC_A / SRC_B / DST | TSPM byte offsets, 16-byte aligned (DOT DST: 4-byte) |
| 0x18 | LEN | elements (0 = no memory access) |
| 0x1C | SCALAR | broadcast operand |
| 0x20 | RESULT | DOT accumulator (RW) |
| 0x24 | CYCLES | RO |
| 0x28 | INFO | [7:0] LANES, [15:8] MUL_W, [31:16] TSPM KiB |

Operations (32-bit two's-complement lanes, wrapping): ADD SUB MUL MIN MAX AND
OR XOR SLL SRA SRL (shift by b[4:0]) and DOT (Σ aᵢ·bᵢ).  MUL/DOT use the
signed product of the low `MUL_W` bits (default 32 → exact C `int32_t`
multiply).  Tail lanes of the last beat are masked (destination words beyond
LEN are not written).

Latency: `CYCLES = 3 + B·P (+1 for DOT with WRES)`, `B = ⌈LEN/4⌉`,
`P = 3` vector–vector, `2` vector–scalar or DOT vector–vector, `1` DOT
vector–scalar (P = number of single-port bank accesses per beat: read A,
read B, write D).  Throughput 4/3 … 4 elements per cycle.

## Tensor engine (TE page `0x4001_1000`)

`C[i][j] (+)= Σ_k A[i][k]·B[k][j]`, i, j ∈ 0..3, int8/uint8 operands,
32-bit accumulators (output-stationary 4×4 MAC array).

| Off | Register | |
|---|---|---|
| 0x00 | CTRL | [0] START, [1] IRQ_EN, [2] CLEAR (zero accumulators) |
| 0x08 | CFG | [0] ACC (accumulate onto ACCn), [1] WB (write C), [2] A_UNSIGNED, [3] B_UNSIGNED |
| 0x0C | A_ADDR | word k at A_ADDR + k·A_STRIDE = column k of A: bytes {A[0][k],A[1][k],A[2][k],A[3][k]} |
| 0x10 | B_ADDR | word k at B_ADDR + k·B_STRIDE = row k of B: bytes {B[k][0..3]} |
| 0x14 | C_ADDR | row i (4 words) at C_ADDR + i·C_STRIDE (16-byte aligned) |
| 0x18 | K | 1…1024 |
| 0x1C/0x20/0x24 | A_STRIDE / B_STRIDE / C_STRIDE | bytes; 0 selects 4 / 4 / 16 |
| 0x28 | CYCLES | RO |
| 0x40–0x7C | ACC0…ACC15 | row-major C, RO |

Latency: `CYCLES = 3 + 2K (+4 with WB)`.  The A and B words of each k are read
from single-port banks in two cycles, so the array sustains 8 MAC/cycle
(16 MACs every 2 cycles).  Larger GEMMs are tiled by firmware: K-accumulation
with `CFG.ACC`, M/N tiling over 4×4 output blocks.

## Golden models
Python: `tb/models/sfv_golden.py` (bit-exact; also generates the boot-ROM POST
vectors and the latency formulas).  C: `firmware/common/sfv_accel.c`
(`ve_ref_elem`, `te_ref`) — every accelerator result in the acceptance
firmware is compared against it.
