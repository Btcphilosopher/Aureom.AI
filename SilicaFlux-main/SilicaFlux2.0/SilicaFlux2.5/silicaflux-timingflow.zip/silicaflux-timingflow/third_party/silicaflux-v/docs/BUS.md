# SFB — SilicaFlux Bus

An OBI-style request/grant + response protocol (subset), chosen because it is
the simplest protocol that maps directly onto synchronous SRAM macros.

| Signal | Dir (master view) | Meaning |
|---|---|---|
| req | out | request valid |
| gnt | in | request accepted this cycle (transfer = req & gnt) |
| addr[31:0] | out | byte address (masters drive word-aligned addresses) |
| we | out | 1 = write |
| be[3:0] | out | byte enables (reads: 1111) |
| wdata[31:0] | out | write data |
| rvalid | in | response valid (exactly one per transfer, in order) |
| rdata[31:0] | in | read data (0 on writes and errors) |
| err | in | bus error (decode error, ROM write, peripheral sub-word write …) |

Rules
1. `gnt` may depend combinationally on `req`/`addr`; `req` must not depend
   combinationally on `gnt`.
2. The response arrives ≥ 1 cycle after the grant; masters always accept it
   (no response back-pressure).
3. Each master has at most one transaction outstanding; a new request may be
   granted in the same cycle as the previous response (full throughput).
4. Data port: once `req` is asserted it is held, with stable attributes, until
   `gnt` (OBI rule; checked formally).  Instruction port: the CPU may change
   the address of an ungranted request after a redirect; the crossbar samples
   attributes only on `req & gnt`, so this is benign (documented exception).
5. Slaves must hold at most one transaction outstanding (the crossbar enforces
   it).

Register bus (behind `sfv_periph_bridge`): `rb_sel[page]` strobe, `rb_we`,
`rb_addr[11:0]`, `rb_wdata`; the page answers `rb_rdata`/`rb_err`
combinationally in the strobe cycle; side effects take place at the end of the
strobe cycle.  Peripheral registers are 32-bit and word-accessed.

Formal (ABC PDR, unbounded, `formal/fv_xbar.sv`): no response without an
outstanding request; single outstanding per master and per slave; at most one
winner per slave; every slave response reaches the master that owns it with
the slave's data and error flag.  Simulation (`tb/unit/test_xbar.py`): 3
concurrent random masters, randomised slave grant/latency, byte lanes, decode
and access-mask errors, slave errors.
