# SilicaFlux PowerLink - SilicaFlux-X power, package and PCB co-design report

Generated 2026-11-04 15:08 from `silicaflux_x_future.yaml`; chip status: **HYPOTHETICAL future-variant scenario (not a design)**.  Baseline package `fc_bga`, reference cooling `active_heatsink`.  Runtime 166 s.  Input SHA-256 hashes are in `manifest.json`.

**Provenance of uncertain inputs:** assumption: 169, datasheet: 34, literature: 69, spec: 1.  Activity source: assumption.  Every number in this report inherits those tags; nothing here is a signoff result.

## 1. Executive summary

- Core rail `VDD_TILE` (0.80 V): maximum load 2633.2 mA (max_simultaneous, 70 C ambient); chip total 3388 mW incl. I/O.
- Static IR drop (worst cell) 7.10 mV nominal / 27.60 mV adverse corner against a 24 mV allocation.
- Dynamic drop on the die grid (wake-up event + clock-synchronous pulses) 54.8 mV total; dynamic component 47.7 mV against a 40 mV allocation.
- Power-integrity margin to the 0.72 V library corner: 14.5 mV nominal, -126.9 mV RSS, -136.6 mV worst-case linear stack; Monte-Carlo P(margin<0) = 22.55% (n=4000).
- Core regulator loop: crossover 80 kHz, phase margin 92 deg; ripple at die 0.48 mV p-p.
- Dominant PDN anti-resonance 238 MHz at 160 mOhm (package inductance vs on-die capacitance).  Against the flat target 16 mOhm up to 1000 MHz the peak ratio is 9.89 (exceeds target); the anti-resonance lies inside that band but is excited by clock harmonics - the time-domain cycle-noise analysis governs.
- Package study: highest-scoring feasible option `fc_bga` (score 0.60, but NOT robust at the adverse corner: passes nominal, fails at adverse corner: sso_noise). Baseline `fc_bga`: feasible (passes nominal, fails at adverse corner: sso_noise); pins 322/324.
- Thermal: T_j 76.7 C with `active_heatsink` at 70 C ambient (limit 105 C); electro-thermal iteration converged for all workloads: True.
- Highest risks: Core total PI margin (worst-case stack) (critical); Core static IR drop (critical); Core dynamic droop / cycle noise (critical); Technology data are generic (no PDK selected) (critical).

### Are the proposed rails, package and PCB realistic?

- Rail `VDD_TILE` (0.80 V, min 0.72 V): **not robust as specified (Monte-Carlo failure probability > 5 %)** - margin 14.5 mV nominal, -126.9 mV RSS, -136.6 mV worst-case, MC P(fail) 22.55% (surrogate, n=4000) / 27.00% (full model, n=200); dominant term: dynamic droop + cycle noise (175.1 mV corner vs 40 mV allocated).
- Rail `VDD_CPU` (0.90 V, min 0.81 V): **realistic statistically (passes RSS)** - margin 48.7 mV nominal, 0.5 mV RSS, -12.0 mV worst-case; dominant term: regulator setpoint (13.5 mV corner vs 9 mV allocated).
- Rail `VDD_SRAM` (0.90 V, min 0.84 V): **not robust as specified** - margin -14.6 mV nominal, -77.0 mV RSS, -90.2 mV worst-case; dominant term: dynamic droop + cycle noise (118.8 mV corner vs 27 mV allocated).
- Rail `VDDIO` (1.80 V, min 1.62 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 83.4 mV nominal, 77.8 mV RSS, 49.3 mV worst-case; dominant term: regulator setpoint (36.0 mV corner vs 27 mV allocated).
- Rail `VDDA_PLL` (0.90 V, min 0.85 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 29.9 mV nominal, 20.2 mV RSS, 20.2 mV worst-case; dominant term: regulator setpoint (18.0 mV corner vs 9 mV allocated).
- Capacitance-only alternative from the decap search: on-die capacitance x4.0 (153.2 nF, +9.57 mm^2 decap cells) gives 20.3 mV dynamic noise (<= 60 % of allocation) with the die-package resonance at 109 MHz, away from clock harmonics.
- Package `fc_bga`: adequate at nominal; corner issues: passes nominal, fails at adverse corner: sso_noise.
- PCB: plane + decap network meets the flat target impedance in the PCB-effective band (max |Z|/Z_t 0.27).  Above that band only on-die capacitance and package inductance matter.
- These conclusions are conditional on the assumed activity, generic technology data and family-level package parasitics recorded in the assumption register; they identify where signoff effort is needed, they do not replace it.

## 2. Power-delivery architecture

![Power-delivery path per rail: regulator, PCB plane, decaps, package pins, substrate, bond wires/bumps, on-die grid and die capacitance (loop values).](figures/pdn_path.png)

*Power-delivery path per rail: regulator, PCB plane, decaps, package pins, substrate, bond wires/bumps, on-die grid and die capacitance (loop values).*

![Voltage domains, macro regions, core ring and supply connections.](figures/voltage_domains.png)

*Voltage domains, macro regions, core ring and supply connections.*

| rail | V_nom | V_min | V_max | regulator | topology | kind | I_max mA (max_simultaneous) |
|---|---|---|---|---|---|---|---|
| VDD_TILE | 0.8 | 0.72 | 0.88 | buck_tile | buck_peak_current_mode | digital_core | 2.63e+03 |
| VDD_CPU | 0.9 | 0.81 | 0.99 | buck_cpu | buck_peak_current_mode | digital | 201.974 |
| VDD_SRAM | 0.9 | 0.84 | 0.99 | buck_sram | buck_peak_current_mode | sram | 762.49 |
| VDDIO | 1.8 | 1.62 | 1.98 | buck_io | buck_peak_current_mode | io | 226.404 |
| VDDA_PLL | 0.9 | 0.855 | 0.945 | ldo_pll | ldo | analog | 6.667 |

## 3. Power consumption

![Power per workload profile split into data switching, clock, SRAM, leakage, I/O and analogue.](figures/power_profiles.png)

*Power per workload profile split into data switching, clock, SRAM, leakage, I/O and analogue.*

| profile | VDD_TILE mW | leakage mW | I/O mW | total mW @70C | total mW @25C | T_j max C |
|---|---|---|---|---|---|---|
| idle | 124.036 | 123.969 | 0.583 | 155.984 | 61.855 | 70.781 |
| cpu_intensive | 142.89 | 125.898 | 63.31 | 384.576 | 288.973 | 71.668 |
| vector_intensive | 1.22e+03 | 138.802 | 140.033 | 1.86e+03 | 1.76e+03 | 74.451 |
| tensor_intensive | 1.34e+03 | 139.52 | 140.033 | 1.97e+03 | 1.87e+03 | 74.598 |
| sram_heavy | 474.759 | 134.762 | 204.055 | 1.48e+03 | 1.38e+03 | 73.88 |
| max_simultaneous | 2.11e+03 | 152.969 | 407.527 | 3.39e+03 | 3.27e+03 | 77.653 |

![Block power breakdown for max_simultaneous.](figures/power_blocks.png)

*Block power breakdown for max_simultaneous.*

Dynamic power uses P = alpha C V^2 f with alpha = P(0->1 per cycle); C from gate-equivalent counts x switchable capacitance per GE; clock power from flop counts.  Leakage is technology-dependent and evaluated at the self-consistent electro-thermal temperature.  All activity values are planning assumptions unless a SAIF/VCD file is attached in the workload configuration.

Activity-import pipeline demonstration (not used for the power numbers): parsed `tb_sf_pwr_seq.vcd` (110 nets, 18.7 us), block toggle rates sf_pwr_seq (dut): TR=0.0023/cycle (alpha 0.0011), pg filter: TR=0.0012/cycle (alpha 0.0006); SAIF written and re-read with identical toggle counts: True.

## 4. Static IR drop and current density

![Static IR-drop heat map of the core grid at the maximum workload.](figures/ir_drop_static.png)

*Static IR-drop heat map of the core grid at the maximum workload.*

| component | mV |
|---|---|
| off-die (PCB plane, pins, substrate) | 4.235 |
| die connections (bond wires/bumps + pad stubs) | 0.423 |
| on-die, worst cell | 2.439 |
| on-die, current-weighted mean | 1.23 |
| total worst cell | 7.098 |

Effective on-die grid resistance (power-weighted) 0.5 mOhm, used in the lumped model.  Grid notes: none.

![Strap current density as a fraction of the EM limit, per layer.](figures/current_density.png)

*Strap current density as a fraction of the EM limit, per layer.*

| item | worst | limit | unit | ratio |
|---|---|---|---|---|
| VDD_CPU/M1 strap | 0.017 | 0.873 | mA/um | 0.02 |
| VDD_CPU/M4 strap | 0.046 | 1.019 | mA/um | 0.045 |
| VDD_CPU/M7 strap | 0.12 | 3.783 | mA/um | 0.032 |
| VDD_CPU/M8 strap | 0.746 | 10.186 | mA/um | 0.073 |
| VDD_CPU/M9 strap | 1.152 | 29.103 | mA/um | 0.04 |
| VDD_SRAM/M4 strap | 0.057 | 1.019 | mA/um | 0.056 |
| VDD_SRAM/M7 strap | 0.11 | 3.783 | mA/um | 0.029 |
| VDD_SRAM/M8 strap | 0.886 | 10.186 | mA/um | 0.087 |
| VDD_SRAM/M9 strap | 1.055 | 29.103 | mA/um | 0.036 |
| VDD_TILE/M1 strap | 0.018 | 0.873 | mA/um | 0.021 |
| VDD_TILE/M4 strap | 0.042 | 1.019 | mA/um | 0.042 |
| VDD_TILE/M7 strap | 0.127 | 3.783 | mA/um | 0.034 |
| VDD_TILE/M8 strap | 0.693 | 10.186 | mA/um | 0.068 |
| VDD_TILE/M9 strap | 1.221 | 29.103 | mA/um | 0.042 |
| VSS/M1 strap | 0.012 | 0.873 | mA/um | 0.014 |
| VSS/M4 strap | 0.027 | 1.019 | mA/um | 0.026 |
| VSS/M7 strap | 0.079 | 3.783 | mA/um | 0.021 |
| VSS/M8 strap | 0.442 | 10.186 | mA/um | 0.043 |
| VSS/M9 strap | 0.759 | 29.103 | mA/um | 0.026 |
| VDD_CPU via M1-M4 | 0.0026 | 0.073 | mA/cut | 0.036 |
| VDD_CPU via M4-M7 | 0.02 | 0.175 | mA/cut | 0.117 |
| VDD_CPU via M7-M8 | 0.066 | 0.175 | mA/cut | 0.38 |
| VDD_CPU via M8-M9 | 0.232 | 0.728 | mA/cut | 0.318 |
| VDD_SRAM via M4-M7 | 0.0098 | 0.175 | mA/cut | 0.056 |
| VDD_SRAM via M7-M8 | 0.047 | 0.175 | mA/cut | 0.269 |
| VDD_SRAM via M8-M9 | 0.198 | 0.728 | mA/cut | 0.272 |
| VDD_TILE via M1-M4 | 0.00232 | 0.073 | mA/cut | 0.032 |
| VDD_TILE via M4-M7 | 0.019 | 0.175 | mA/cut | 0.107 |
| VDD_TILE via M7-M8 | 0.064 | 0.175 | mA/cut | 0.366 |
| VDD_TILE via M8-M9 | 0.221 | 0.728 | mA/cut | 0.303 |
| VSS via M1-M4 | 0.00248 | 0.073 | mA/cut | 0.034 |
| VSS via M4-M7 | 0.018 | 0.175 | mA/cut | 0.101 |
| VSS via M7-M8 | 0.05 | 0.175 | mA/cut | 0.286 |
| VSS via M8-M9 | 0.153 | 0.728 | mA/cut | 0.211 |
| VDD_CPU via M8-M9(bump farm) | 0.128 | 0.728 | mA/cut | 0.176 |
| VDD_SRAM via M8-M9(bump farm) | 0.106 | 0.728 | mA/cut | 0.146 |
| VDD_TILE via M8-M9(bump farm) | 0.124 | 0.728 | mA/cut | 0.171 |
| VSS via M8-M9(bump farm) | 0.085 | 0.728 | mA/cut | 0.116 |
| VDD_CPU bump (worst of 17) | 25.781 | 150 | mA | 0.172 |
| VDD_SRAM bump (worst of 84) | 22.427 | 150 | mA | 0.15 |
| VDD_TILE bump (worst of 188) | 25.484 | 150 | mA | 0.17 |
| VSS bump (worst of 289) | 17.029 | 150 | mA | 0.114 |

## 5. PDN impedance, regulator response and supply noise

![Impedance seen by the die: nominal, adverse corner and without PCB decaps.](figures/impedance_core.png)

*Impedance seen by the die: nominal, adverse corner and without PCB decaps.*

| rail | Z_target mOhm | max \|Z\|/Z_t | peak f MHz | peak \|Z\| mOhm | VRM f_c kHz | PM deg | ripple at die mV p-p |
|---|---|---|---|---|---|---|---|
| VDD_TILE | 16.141 | 9.891 | 237.618 | 159.655 | 79.511 | 91.568 | 0.476 |
| VDD_CPU | 250.476 | 2.646 | 355.555 | 662.835 | 99.995 | 61.758 | 0.759 |
| VDD_SRAM | 35.685 | 15.826 | 251.7 | 564.763 | 99.995 | 61.757 | 0.748 |
| VDDIO | 318.471 | 10.205 | 141.528 | 3.25e+03 | 99.991 | 65.556 | 0.543 |
| VDDA_PLL | 1.8e+05 | 0.02 | 158.8 | 3.64e+03 | nan | nan | 0.00751 |

![Core regulator loop gain (magnitude and phase as separate panels).](figures/vrm_loop_core.png)

*Core regulator loop gain (magnitude and phase as separate panels).*

Regulator slew check: inductor current can rise at 25.45 A/us; the largest load step needs 97.4 ns of inductor slew versus a loop response time of 1.99 us - the step is carried by the output and PCB capacitors, as modelled.

![Steady-state cycle-level supply noise at the die and its contributions.](figures/supply_noise.png)

*Steady-state cycle-level supply noise at the die and its contributions.*

## 6. Transient droop and dynamic IR

![Die-voltage response to the configured load events (cycle-average currents).](figures/transient_droop.png)

*Die-voltage response to the configured load events (cycle-average currents).*

| event | max droop mV | first (<100 ns) mV | second (0.1-1 us) mV | third (>1 us) mV | overshoot mV | settle us |
|---|---|---|---|---|---|---|
| tiles_wake_simultaneous | 39.979 | 39.979 | 7.935 | 7.909 | 26.001 | 15.41 |
| tiles_wake_staggered | 10.355 | 6.008 | 10.355 | 7.809 | 3.25 | 15.57 |
| vector_burst | 16.605 | 16.605 | 4.32 | 4.306 | 9.805 | 11.798 |
| load_release | 26.001 | 26.001 | -4.94 | -3.676 | 36.288 | 15.434 |

Resonant-workload check: a program can modulate activity at up to f_clk/2.  A load toggling at the 238 MHz anti-resonance (160 mOhm) produces 252.6 mV droop (first-harmonic estimate 251.9 mV) versus 40.0 mV for a single step.

![Dynamic IR drop on the die grid during the primary wake-up event.](figures/ir_drop_dynamic.png)

*Dynamic IR drop on the die grid during the primary wake-up event.*

## 7. Decoupling

| quantity | value |
|---|---|
| first-droop loop inductance (die connections + min(package path, package-cap ESL)) | 14 pH |
| on-die capacitance (intrinsic + explicit) | 38.30 nF |
| explicit decap cells | 35.21 nF over 2.934 mm^2 |
| first-droop bound C >= L (dI/dV)^2 | 53.64 nF |
| per-cycle charge rule | 41.05 nF (Q_cycle 2463 pC) |
| additional decap area to meet both | 1.279 mm^2 (4.7% of core) |
| PCB-decap optimiser band | 1 kHz - 50.0 MHz, max \|Z\|/Z_t before = 0.27 |
| PCB decaps added by optimiser | none needed |

| C scale | on-die C (nF) | extra decap area (mm^2) | die-pkg resonance (MHz) | offset from nearest clock harmonic | total drop (mV) | dynamic beyond DC (mV) |
|---|---|---|---|---|---|---|
| 1 | 38.296 | 0 | 217.546 | 78% | 53.07 | 48.07 |
| 1.5 | 57.444 | 1.596 | 177.626 | 82% | 40.633 | 35.633 |
| 2 | 76.593 | 3.191 | 153.828 | 85% | 34.273 | 29.273 |
| 2.5 | 95.741 | 4.787 | 137.588 | 86% | 32.03 | 27.03 |
| 3 | 114.889 | 6.383 | 125.6 | 87% | 29.576 | 24.576 |
| 4 | 153.185 | 9.574 | 108.773 | 89% | 25.266 | 20.266 |
| 5 | 191.482 | 12.765 | 97.29 | 90% | 21.987 | 16.987 |
| 6 | 229.778 | 15.957 | 88.813 | 91% | 20.604 | 15.604 |

| power/ground pairs scale | on-die C scale | extra pins | extra decap (mm^2) | first-droop L (pH) | die-pkg resonance (MHz) | dynamic beyond DC (mV) |
|---|---|---|---|---|---|---|
| 1 | 1 | 0 | 0 | 13.976 | 217.546 | 48.07 |
| 1.5 | 1 | 42 | 0 | 13.901 | 218.135 | 47.885 |
| 2 | 1 | 84 | 0 | 13.863 | 218.431 | 47.78 |
| 1.5 | 2 | 42 | 3.191 | 13.901 | 154.245 | 28.975 |
| 2 | 2 | 84 | 3.191 | 13.863 | 154.454 | 28.809 |

Package-inductance what-if: more VDD/VSS bond-wire/lead pairs (pin budget permitting) reduce the loop inductance and the anti-resonance peak; combined with moderate decap this is usually cheaper in silicon area than capacitance alone.

**Recommended:** scale on-die capacitance x4.0 (+9.57 mm^2 of decap cells) - smallest step with dynamic noise <= 60 % of the 40 mV allocation and the resonance >15 % away from clock harmonics.  Note the non-monotonic behaviour: capacitance that moves the resonance onto a clock harmonic makes noise worse.

What-if table: lumped clocked model of the primary wake-up event as the on-die capacitance is scaled (ESR scaled inversely).  Use it to trade decap area (and its gate leakage) against noise margin.

## 8. Thermal coupling and cooling

![Die temperature map at the maximum workload (2-D conduction, compact boundary).](figures/thermal_map.png)

*Die temperature map at the maximum workload (2-D conduction, compact boundary).*

![Junction temperature for every package and cooling option at worst ambient.](figures/cooling_comparison.png)

*Junction temperature for every package and cooling option at worst ambient.*

| cooling | wb_qfn88 | wb_bga256 | fc_bga | adv_organic | si_interposer | theta_ja (fc_bga) |
|---|---|---|---|---|---|---|
| natural_convection | 185.563 | 205.482 | 233.358 | 204.989 | 139.956 | 20.963 |
| small_passive_heatsink | 130.672 | 127.941 | 108.832 | 107.88 | 107.005 | 10.633 |
| large_passive_heatsink | 115.685 | 107.055 | 87.461 | 87.375 | 87.51 | 5.065 |
| active_heatsink | 110.19 | 99.179 | 76.707 | 76.825 | 77.27 | 1.98 |
| vapor_chamber_fan | 108.509 | 96.728 | 72.965 | 73.107 | 73.619 | 0.88 |

Thermal-network notes: computed theta_jc_top 0.478 C/W vs library 0.350 C/W; computed theta_jc_top 0.487 C/W vs library 0.350 C/W; computed theta_jc_top 0.490 C/W vs library 0.350 C/W; computed theta_jc_top 0.491 C/W vs library 0.350 C/W

Specialist thermal results can be imported (`powerlink thermal-import`); the PowerLink map is exported in the same CSV format to `thermal_map_export.csv`.

## 9. Package comparison

![Package sub-scores and overall weighted score (status = hard-constraint check).](figures/package_comparison.png)

*Package sub-scores and overall weighted score (status = hard-constraint check).*

| package | family | pins | L_pkg pH | pkg DC mV | first droop bound mV | SSO mV | SI Gb/s | T_j passive C | USD/unit @vol | NRE USD | score | status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| fc_bga | flip_chip_bga | 322/324 | 13.976 | 2.673 | 5.918 | 61.091 | 16 | 87.159 | 15 | 9e+04 | 0.597 | nominal only |
| adv_organic | advanced_organic | 317/900 | 13.765 | 3.094 | 5.873 | 52.364 | 24 | 87.077 | 43 | 2.5e+05 | 0.555 | nominal only |
| si_interposer | silicon_interposer | 317/2500 | 3.892 | 7.045 | 3.123 | 48.257 | 32 | 87.206 | 200 | 1.2e+06 | 0.426 | nominal only |
| wb_qfn88 | wire_bond_qfn | 304/88 | 172.521 | 24.745 | 20.791 | 285.247 | 0.6 | 111.248 | 0.6 | 3e+03 | 0 | infeasible |
| wb_bga256 | wire_bond_bga | 434/256 | 152.136 | 44.584 | 19.524 | 304.665 | 1.5 | 104.591 | 3.2 | 2e+04 | 0 | infeasible |

- `fc_bga`: passes nominal, fails at adverse corner: sso_noise
- `adv_organic`: passes nominal, fails at adverse corner: sso_noise
- `si_interposer`: passes nominal, fails at adverse corner: core_pkg_dc_drop, sso_noise
- `wb_qfn88`: fails: pin_budget, pad_ring, core_pkg_dc_drop, si_rate, sso_noise, thermal_any_cooling
- `wb_bga256`: fails: pin_budget, pad_ring, core_pkg_dc_drop, si_rate, sso_noise

## 10. Power-integrity margins

### VDD_TILE

![VDD_TILE budget waterfall (worst-case stack).](figures/margin_VDD_TILE.png)

*VDD_TILE budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 6.4 | 9.6 | 8 | FAIL | assumption |
| ripple (half p-p) | 0.238 | 0.331 | 8 | True | model |
| static IR (worst cell) | 7.098 | 27.599 | 24 | FAIL | grid solver |
| dynamic droop + cycle noise | 47.716 | 175.069 | 40 | FAIL | dynamic grid x lumped corner |
| guardband | 4 | 4 | 4 | PASS | spec |

Available 76.0 mV (V_nom - V_min - guardband).  Margin: nominal 14.5 mV, RSS -126.9 mV, worst-case -136.6 mV.  Monte-Carlo (n=4000): P(fail) 22.55%, 1st percentile margin -46.4 mV, median 17.6 mV; surrogate error at the worst corner 1.7%.

Direct Monte-Carlo with the full lumped model on the first 200 draws: P(fail) 27.00% (surrogate on the same draws 26.00%); correlation of the dynamic term between full model and surrogate r = 1.00.  Where they disagree, the full-model figure governs.

![Monte-Carlo margin distribution.](figures/margin_monte_carlo.png)

*Monte-Carlo margin distribution.*

| parameter | elasticity of dynamic droop (d ln m / d ln p) |
|---|---|
| activity_scale | 0.713 |
| csw_scale | 0.713 |
| kge_scale | 0.711 |
| c_die | -0.671 |
| clk_cap_scale | 0.288 |
| plane_r | -0.023 |
| sub_l | 0.021 |
| r_grid | -0.017 |

### VDD_CPU

![VDD_CPU budget waterfall (worst-case stack).](figures/margin_VDD_CPU.png)

*VDD_CPU budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 9 | 13.5 | 9 | FAIL | assumption |
| ripple (half p-p) | 0.38 | 0.422 | 9 | True | model |
| static IR (worst cell) | 6.023 | 20.798 | 27 | PASS | grid solver |
| dynamic droop + cycle noise | 21.423 | 62.774 | 45 | FAIL | dynamic grid x lumped corner |
| guardband | 4.5 | 4.5 | 4.5 | PASS | spec |

Available 85.5 mV (V_nom - V_min - guardband).  Margin: nominal 48.7 mV, RSS 0.5 mV, worst-case -12.0 mV.

### VDD_SRAM

![VDD_SRAM budget waterfall (worst-case stack).](figures/margin_VDD_SRAM.png)

*VDD_SRAM budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 9 | 13.5 | 9 | FAIL | assumption |
| ripple (half p-p) | 0.374 | 0.415 | 4.5 | True | model |
| static IR (worst cell) | 6.421 | 15.673 | 18 | PASS | grid solver |
| dynamic droop + cycle noise | 57.009 | 118.776 | 27 | FAIL | dynamic grid x lumped corner |
| guardband | 1.8 | 1.8 | 1.8 | PASS | spec |

Available 58.2 mV (V_nom - V_min - guardband).  Margin: nominal -14.6 mV, RSS -77.0 mV, worst-case -90.2 mV.

### VDDIO

![VDDIO budget waterfall (worst-case stack).](figures/margin_VDDIO.png)

*VDDIO budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 27 | 36 | 27 | FAIL | assumption |
| ripple (half p-p) | 0.272 | 0.304 | 18 | True | model |
| static IR (path) | 3.735 | 5.974 | 36 | PASS | lumped path |
| dynamic droop | 56.546 | 79.398 | 72 | FAIL | lumped transient |
| guardband | 9 | 9 | 9 | PASS | spec |

Available 171.0 mV (V_nom - V_min - guardband).  Margin: nominal 83.4 mV, RSS 77.8 mV, worst-case 49.3 mV.

### VDDA_PLL

![VDDA_PLL budget waterfall (worst-case stack).](figures/margin_VDDA_PLL.png)

*VDDA_PLL budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 9 | 18 | 9 | FAIL | assumption |
| ripple (half p-p) | 0.00375 | 0.00751 | 4.5 | True | model |
| static IR (path) | 1.58 | 2.27 | 9 | PASS | lumped path |
| dynamic droop | 0 | 0 | 18 | PASS | lumped transient |
| guardband | 4.5 | 4.5 | 4.5 | PASS | spec |

Available 40.5 mV (V_nom - V_min - guardband).  Margin: nominal 29.9 mV, RSS 20.2 mV, worst-case 20.2 mV.

## 11. Risk summary

![Risk matrix (likelihood from computed utilisation ratios; impact by engineering judgement).](figures/risk_matrix.png)

*Risk matrix (likelihood from computed utilisation ratios; impact by engineering judgement).*

| # | risk | metric | L | I | score | status | mitigation |
|---|---|---|---|---|---|---|---|
| 1 | Core total PI margin (worst-case stack) | margin -136.6 mV worst, -126.9 mV RSS, P(fail) MC 22.55% | 5 | 5 | 25 | critical | re-balance budget; tighten regulator setpoint; more decap |
| 2 | Core static IR drop | 27.6 mV worst corner vs 24 mV | 5 | 4 | 20 | critical | add M8/M9 straps or pads; signoff static IR (RedHawk-SC/Voltus) |
| 3 | Core dynamic droop / cycle noise | 175.1 mV worst corner vs 40 mV | 5 | 4 | 20 | critical | increase on-die decap (see decap what-if), staggered tile wake, vectored dynamic IR |
| 4 | Technology data are generic (no PDK selected) | technology 'generic_28nm' tagged assumption | 4 | 4 | 16 | critical | select PDK; replace metal/via/EM/decap/leakage values; implement and sign off |
| 5 | I/O simultaneous-switching noise (chiplet link) | 61 mV nominal / 261 mV fast-edge corner vs 180 mV | 5 | 3 | 15 | serious | slew-rate-controlled pads, more VDDIO/VSSIO pairs, LVDS/low-swing link |
| 6 | On-die decoupling sufficiency | 38.30 nF vs 53.64 nF rule-of-thumb | 5 | 3 | 15 | serious | allocate decap-cell area per what-if table; MOS-cap leakage trade-off |
| 7 | Package pin budget | 322 of 324 (incl. 10% spare) | 4 | 3 | 12 | serious | larger body or BGA if I/O grows |
| 8 | Switching activity is assumed, not measured | activity source: assumption | 4 | 3 | 12 | serious | gate-level SAIF/VCD from representative firmware; re-run PowerLink |
| 9 | Electromigration (straps, vias, bond wires) | worst VDD_CPU via M7-M8: 38% of limit | 2 | 5 | 10 | serious | foundry EM rule deck at signoff temperature; via arrays at ring/strap ends |
| 10 | Leakage-temperature non-convergence (runaway) in some package/cooling options | natural_convection/wb_qfn88, natural_convection/wb_bga256, natural_convection/fc_bga, natural_convection/adv_organic - none is the reference cooling with the baseline package | 1 | 5 | 5 | warning | exclude those combinations; keep the reference cooling |
| 11 | Core regulator loop stability | phase margin 92 deg at 80 kHz (averaged model) | 1 | 4 | 4 | good | verify with the PMIC vendor model and a load-step bench measurement |
| 12 | PLL analogue supply noise | 0.01 mV p-p vs 10 mV limit | 1 | 4 | 4 | good | dedicated LDO + RC filter, separate VSSA, guard ring |
| 13 | Junction temperature | 76.7 C at 70 C ambient vs 105 C | 1 | 4 | 4 | good | cooling option per comparison; thermal signoff (Icepak/Celsius) |
| 14 | PDN resonance near clock harmonics | none within 15% | 1 | 3 | 3 | good | move resonance with decap/ESR damping; check with vectored dynamic IR |
| 15 | Regulator ripple at die | 0.48 mV p-p vs 8 mV | 1 | 2 | 2 | good | output-cap ESR/ESL selection, layout |

## 12. On-die PDN configuration and OpenROAD scripts

| layer | direction | width um | pitch um | PG track usage |
|---|---|---|---|---|
| M1 | H | 0.1 | 1.8 | 0.111 |
| M4 | V | 0.8 | 10 | 0.24 |
| M7 | H | 2 | 20 | 0.3 |
| M8 | V | 4 | 30 | 0.4 |
| M9 | H | 10 | 75 | 0.4 |

Configuration checks: no errors; no warnings.

Generated scripts (example only - no DRC/LVS correctness is asserted without the chosen PDK and a real implementation run): `pdn_silicaflux_x_generic.tcl`, `silicaflux_x_power_intent.upf`.

## 13. Validation

Independent cross-check of the in-house MNA solver against ngspice on the circuits used above:

| check | PowerLink | ngspice | abs diff | rel diff | tolerance | result |
|---|---|---|---|---|---|---|
| ladder DC V(die) | 0.8 | 0.8 | 8.9e-12 | 1.11e-11 | 1e-06 V /  rel | PASS |
| ladder \|Z(f)\| max rel. error (61 points, 1 kHz-1 GHz) | 0.108 | 0.108 | 2.21e-10 | 1.48e-07 | 1e-3 rel | PASS |
| ladder transient V_min | 0.8 | 0.8 | 3.76e-08 | 4.7e-08 | 0.0002 V /  rel (ngspice gear, reltol 1e-6) | PASS |
| ladder transient waveform RMS difference | 0.8 | 0.8 | 4.6e-08 | 5.76e-08 | 1e-4 V | PASS |
| grid DC node voltages, max \|diff\| over 29016 nodes | 0 | 0 | 1.26e-11 | 1.26e-11 | 1e-6 V | PASS |

Unit tests (pytest) cover the MNA solver against analytic RC/RLC/divider solutions, the grid solver against the analytic uniform-sheet solution and current conservation, the VRM loop against the analytic crossover, the thermal solver against 1-D and Song-Lee-Au limits, VCD/SAIF parsing and the package/margin logic.  Commercial signoff experiments are specified in docs/VALIDATION_AND_SIGNOFF.md.

## 14. Assumption register

273 uncertain inputs (full list in `assumptions.csv`).  Largest relative spans:

| path | nominal | min | max | source | note |
|---|---|---|---|---|---|
| technology.decap_cell.leak_na_per_um2 | 0.4 | 0.1 | 2 | assumption |  |
| technology.stdcell.leak_per_ge_na_25c | 3 | 0.8 | 15 | assumption |  |
| technology.sram.macro_types.sp_8192x64.leak_ua_25c | 40 | 10 | 160 | assumption |  |
| technology.sram.macro_types.sp_2048x32.leak_ua_25c | 8 | 2 | 32 | assumption |  |
| packages.packages.wb_qfn88.cost.nre_usd | 3e+03 | 0 | 1e+04 | assumption | standard leadframe |
| packages.packages.si_interposer.interposer_decap.nf_per_mm2 | 300 | 100 | 1e+03 | literature | if the interposer process offers DTC |
| thermal.ambient_c | 25 | 0 | 70 | spec | 70C = sealed enclosure worst case |
| packages.packages.wb_qfn88.cost.proto_unit_usd | 15 | 5 | 40 | assumption | MPW engineering lot |
| packages.packages.si_interposer.cost.proto_unit_usd | 3e+03 | 1e+03 | 8e+03 | assumption |  |
| technology.decap_cell.esr_ohm_um2 | 1.5e+03 | 600 | 4e+03 | assumption |  |
| packages.packages.wb_bga256.cost.proto_unit_usd | 40 | 15 | 100 | assumption |  |
| packages.packages.adv_organic.cost.proto_unit_usd | 800 | 300 | 2e+03 | assumption |  |
| pcb.regulators.ldo_pll.r_out_ohm | 0.02 | 0.01 | 0.05 | assumption |  |
| packages.packages.fc_bga.cost.proto_unit_usd | 250 | 100 | 600 | assumption |  |
| packages.packages.si_interposer.interposer_decap.esr_ohm | 0.002 | 0.001 | 0.005 | assumption | whole bank |
| packages.packages.si_interposer.cost.unit_usd | 80 | 40 | 200 | literature |  |
| packages.packages.wb_bga256.cost.nre_usd | 2e+04 | 8e+03 | 4.5e+04 | assumption | substrate design + tooling |
| packages.packages.adv_organic.cost.unit_usd | 18 | 9 | 40 | literature |  |
| packages.packages.si_interposer.cost.nre_usd | 1.2e+06 | 5e+05 | 2.5e+06 | assumption |  |
| packages.packages.si_interposer.interposer_decap.esl_h | 5e-12 | 2e-12 | 1e-11 | assumption | whole bank incl. interposer RDL |
