# SilicaFlux PowerLink - SilicaFlux-V power, package and PCB co-design report

Generated 2026-11-04 15:05 from `silicaflux_v.yaml`; chip status: **pre-synthesis planning model**.  Baseline package `wb_qfn88`, reference cooling `natural_convection`.  Runtime 63 s.  Input SHA-256 hashes are in `manifest.json`.

**Provenance of uncertain inputs:** assumption: 133, datasheet: 20, literature: 69, spec: 1.  Activity source: assumption.  Every number in this report inherits those tags; nothing here is a signoff result.

## 1. Executive summary

- Core rail `VDD_CORE` (1.00 V): maximum load 44.4 mA (max_simultaneous, 70 C ambient); chip total 172 mW incl. I/O.
- Static IR drop (worst cell) 4.77 mV nominal / 24.52 mV adverse corner against a 30 mV allocation.
- Dynamic drop on the die grid (wake-up event + clock-synchronous pulses) 38.4 mV total; dynamic component 33.6 mV against a 50 mV allocation.
- Power-integrity margin to the 0.90 V library corner: 46.4 mV nominal, -163.9 mV RSS, -178.7 mV worst-case linear stack; Monte-Carlo P(margin<0) = 15.50% (n=4000).
- Core regulator loop: crossover 100 kHz, phase margin 65 deg; ripple at die 0.53 mV p-p.
- Dominant PDN anti-resonance 178 MHz at 3428 mOhm (package inductance vs on-die capacitance).  Against the flat target 1388 mOhm up to 100 MHz the peak ratio is 0.26 (within target); the anti-resonance lies above that band but is excited by clock harmonics - the time-domain cycle-noise analysis governs.
- Package study: highest-scoring feasible option `wb_qfn88` (score 0.76, but NOT robust at the adverse corner: passes nominal, fails at adverse corner: sso_noise). Baseline `wb_qfn88`: feasible (passes nominal, fails at adverse corner: sso_noise); pins 79/88.
- Thermal: T_j 74.1 C with `natural_convection` at 70 C ambient (limit 105 C); electro-thermal iteration converged for all workloads: True.
- Highest risks: Core total PI margin (worst-case stack) (critical); Core dynamic droop / cycle noise (critical); Technology data are generic (no PDK selected) (critical); I/O simultaneous-switching noise (chiplet link) (serious).

### Are the proposed rails, package and PCB realistic?

- Rail `VDD_CORE` (1.00 V, min 0.90 V): **not robust as specified (Monte-Carlo failure probability > 5 %)** - margin 46.4 mV nominal, -163.9 mV RSS, -178.7 mV worst-case, MC P(fail) 15.50% (surrogate, n=4000) / 7.50% (full model, n=200); dominant term: dynamic droop + cycle noise (233.9 mV corner vs 50 mV allocated).
- Rail `VDDIO` (3.30 V, min 3.00 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 226.2 mV nominal, 209.7 mV RSS, 199.1 mV worst-case; dominant term: regulator setpoint (66.0 mV corner vs 49 mV allocated).
- Rail `VDDA_PLL` (1.00 V, min 0.95 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 33.6 mV nominal, 22.5 mV RSS, 22.5 mV worst-case; dominant term: regulator setpoint (20.0 mV corner vs 10 mV allocated).
- Cheapest mitigation found: x2.0 core power/ground connection pairs (+8 pins, 17 free) and x1.0 on-die decoupling (+0.00 mm^2) bring the dynamic term to 25.6 mV (<= 60 % of allocation) in the lumped clocked model; confirm with dynamic-IR signoff.
- Capacitance-only alternative from the decap search: on-die capacitance x6.0 (10.9 nF, +1.30 mm^2 decap cells) gives 17.2 mV dynamic noise (<= 60 % of allocation) with the die-package resonance at 82 MHz, away from clock harmonics.
- Package `wb_qfn88`: adequate at nominal; corner issues: passes nominal, fails at adverse corner: sso_noise.
- PCB: plane + decap network meets the flat target impedance in the PCB-effective band (max |Z|/Z_t 0.11).  Above that band only on-die capacitance and package inductance matter.
- These conclusions are conditional on the assumed activity, generic technology data and family-level package parasitics recorded in the assumption register; they identify where signoff effort is needed, they do not replace it.

## 2. Power-delivery architecture

![Power-delivery path per rail: regulator, PCB plane, decaps, package pins, substrate, bond wires/bumps, on-die grid and die capacitance (loop values).](figures/pdn_path.png)

*Power-delivery path per rail: regulator, PCB plane, decaps, package pins, substrate, bond wires/bumps, on-die grid and die capacitance (loop values).*

![Voltage domains, macro regions, core ring and supply connections.](figures/voltage_domains.png)

*Voltage domains, macro regions, core ring and supply connections.*

| rail | V_nom | V_min | V_max | regulator | topology | kind | I_max mA (max_simultaneous) |
|---|---|---|---|---|---|---|---|
| VDD_CORE | 1 | 0.9 | 1.1 | buck_core | buck_peak_current_mode | digital_core | 44.404 |
| VDDIO | 3.3 | 3 | 3.6 | buck_io | buck_peak_current_mode | io | 38.065 |
| VDDA_PLL | 1 | 0.95 | 1.05 | ldo_pll | ldo | analog | 2 |

## 3. Power consumption

![Power per workload profile split into data switching, clock, SRAM, leakage, I/O and analogue.](figures/power_profiles.png)

*Power per workload profile split into data switching, clock, SRAM, leakage, I/O and analogue.*

| profile | VDD_CORE mW | leakage mW | I/O mW | total mW @70C | total mW @25C | T_j max C |
|---|---|---|---|---|---|---|
| idle | 8.391 | 7.845 | 0.146 | 10.537 | 4.935 | 70.384 |
| cpu_intensive | 12.442 | 7.904 | 7.116 | 21.557 | 15.914 | 70.655 |
| vector_intensive | 29.123 | 8.285 | 62.219 | 93.342 | 87.427 | 72.331 |
| tensor_intensive | 26.51 | 8.269 | 62.219 | 90.729 | 84.825 | 72.265 |
| sram_heavy | 19.871 | 8.232 | 62.219 | 84.09 | 78.213 | 72.123 |
| max_simultaneous | 44.404 | 8.722 | 125.616 | 172.02 | 165.792 | 74.226 |

![Block power breakdown for max_simultaneous.](figures/power_blocks.png)

*Block power breakdown for max_simultaneous.*

Dynamic power uses P = alpha C V^2 f with alpha = P(0->1 per cycle); C from gate-equivalent counts x switchable capacitance per GE; clock power from flop counts.  Leakage is technology-dependent and evaluated at the self-consistent electro-thermal temperature.  All activity values are planning assumptions unless a SAIF/VCD file is attached in the workload configuration.

Activity-import pipeline demonstration (not used for the power numbers): parsed `tb_sf_pwr_seq.vcd` (110 nets, 18.7 us), block toggle rates sf_pwr_seq (dut): TR=0.0023/cycle (alpha 0.0011), pg filter: TR=0.0012/cycle (alpha 0.0006); SAIF written and re-read with identical toggle counts: True.

## 4. Static IR drop and current density

![Static IR-drop heat map of the core grid at the maximum workload.](figures/ir_drop_static.png)

*Static IR-drop heat map of the core grid at the maximum workload.*

| component | mV |
|---|---|
| off-die (PCB plane, pins, substrate) | 0.121 |
| die connections (bond wires/bumps + pad stubs) | 1.697 |
| on-die, worst cell | 2.951 |
| on-die, current-weighted mean | 1.722 |
| total worst cell | 4.769 |

Effective on-die grid resistance (power-weighted) 38.8 mOhm, used in the lumped model.  Grid notes: VDD_CORE: M6->M8 has 0.27 intersections per cell; cell size below strap pitch reduces homogenisation accuracy; VDD_CORE: M8->M9 has 0.11 intersections per cell; cell size below strap pitch reduces homogenisation accuracy; VSS: M6->M8 has 0.27 intersections per cell; cell size below strap pitch reduces homogenisation accuracy; VSS: M8->M9 has 0.11 intersections per cell; cell size below strap pitch reduces homogenisation accuracy.

![Strap current density as a fraction of the EM limit, per layer.](figures/current_density.png)

*Strap current density as a fraction of the EM limit, per layer.*

| item | worst | limit | unit | ratio |
|---|---|---|---|---|
| VDD_CORE/M1 strap | 0.021 | 2.595 | mA/um | 0.00824 |
| VDD_CORE/M6 strap | 0.063 | 5.406 | mA/um | 0.012 |
| VDD_CORE/M8 strap | 0.28 | 12.974 | mA/um | 0.022 |
| VDD_CORE/M9 strap | 0.298 | 12.974 | mA/um | 0.023 |
| VSS/M1 strap | 0.021 | 2.595 | mA/um | 0.00825 |
| VSS/M6 strap | 0.065 | 5.406 | mA/um | 0.012 |
| VSS/M8 strap | 0.282 | 12.974 | mA/um | 0.022 |
| VSS/M9 strap | 0.272 | 12.974 | mA/um | 0.021 |
| VDD_CORE via M1-M6 | 0.00472 | 0.216 | mA/cut | 0.022 |
| VDD_CORE via M6-M8 | 0.075 | 0.541 | mA/cut | 0.138 |
| VDD_CORE via M8-M9 | 0.113 | 1.297 | mA/cut | 0.087 |
| VSS via M1-M6 | 0.00473 | 0.216 | mA/cut | 0.022 |
| VSS via M6-M8 | 0.067 | 0.541 | mA/cut | 0.125 |
| VSS via M8-M9 | 0.115 | 1.297 | mA/cut | 0.088 |
| VDD_CORE via M8-M9(ring) | 0.036 | 1.297 | mA/cut | 0.028 |
| VSS via M8-M9(ring) | 0.037 | 1.297 | mA/cut | 0.028 |
| VDD_CORE bondwire (worst of 8) | 6.554 | 250 | mA | 0.026 |
| VSS bondwire (worst of 8) | 6.644 | 250 | mA | 0.027 |

## 5. PDN impedance, regulator response and supply noise

![Impedance seen by the die: nominal, adverse corner and without PCB decaps.](figures/impedance_core.png)

*Impedance seen by the die: nominal, adverse corner and without PCB decaps.*

| rail | Z_target mOhm | max \|Z\|/Z_t | peak f MHz | peak \|Z\| mOhm | VRM f_c kHz | PM deg | ripple at die mV p-p |
|---|---|---|---|---|---|---|---|
| VDD_CORE | 1.39e+03 | 0.256 | 178.18 | 3.43e+03 | 99.992 | 65.139 | 0.525 |
| VDDIO | 3.47e+03 | 0.164 | 237.618 | 1.03e+04 | 58.883 | 63.293 | 0.911 |
| VDDA_PLL | 2e+05 | 0.017 | 158.8 | 1.53e+04 | nan | nan | 0.00485 |

![Core regulator loop gain (magnitude and phase as separate panels).](figures/vrm_loop_core.png)

*Core regulator loop gain (magnitude and phase as separate panels).*

Regulator slew check: inductor current can rise at 2.30 A/us; the largest load step needs 15.7 ns of inductor slew versus a loop response time of 1.59 us - the step is carried by the output and PCB capacitors, as modelled.

![Steady-state cycle-level supply noise at the die and its contributions.](figures/supply_noise.png)

*Steady-state cycle-level supply noise at the die and its contributions.*

## 6. Transient droop and dynamic IR

![Die-voltage response to the configured load events (cycle-average currents).](figures/transient_droop.png)

*Die-voltage response to the configured load events (cycle-average currents).*

| event | max droop mV | first (<100 ns) mV | second (0.1-1 us) mV | third (>1 us) mV | overshoot mV | settle us |
|---|---|---|---|---|---|---|
| tiles_wake_simultaneous | 4.211 | 4.211 | 2.882 | 3.289 | 3.09e-07 | 4.52 |
| tiles_wake_staggered | 3.275 | 1.053 | 2.366 | 3.275 | 3.09e-07 | 5.088 |
| vector_burst | 1.524 | 1.489 | 1.333 | 1.524 | 3.09e-07 | 5e-05 |
| load_release | -3.09e-07 | -3.09e-07 | -2.231 | -2.159 | 2.05 | 4.538 |

Resonant-workload check: a program can modulate activity at up to f_clk/2.  A load toggling at the 0.0563 MHz anti-resonance (102 mOhm) produces 3.3 mV droop (first-harmonic estimate 2.3 mV) versus 4.2 mV for a single step.

![Dynamic IR drop on the die grid during the primary wake-up event.](figures/ir_drop_dynamic.png)

*Dynamic IR drop on the die grid during the primary wake-up event.*

## 7. Decoupling

| quantity | value |
|---|---|
| first-droop loop inductance (die connections + min(package path, package-cap ESL)) | 345 pH |
| on-die capacitance (intrinsic + explicit) | 1.82 nF |
| explicit decap cells | 1.31 nF over 0.187 mm^2 |
| first-droop bound C >= L (dI/dV)^2 | 0.18 nF |
| per-cycle charge rule | 4.76 nF (Q_cycle 357 pC) |
| additional decap area to meet both | 0.420 mm^2 (21.4% of core) |
| PCB-decap optimiser band | 1 kHz - 50.0 MHz, max \|Z\|/Z_t before = 0.11 |
| PCB decaps added by optimiser | none needed |

| C scale | on-die C (nF) | extra decap area (mm^2) | die-pkg resonance (MHz) | offset from nearest clock harmonic | total drop (mV) | dynamic beyond DC (mV) |
|---|---|---|---|---|---|---|
| 1 | 1.821 | 0 | 200.786 | 0% | 40.271 | 37.619 |
| 1.5 | 2.731 | 0.13 | 163.941 | 18% | 33.527 | 30.876 |
| 2 | 3.642 | 0.26 | 141.977 | 29% | 38.312 | 35.66 |
| 2.5 | 4.552 | 0.39 | 126.988 | 27% | 50.715 | 48.063 |
| 3 | 5.463 | 0.52 | 115.924 | 16% | 62.818 | 60.166 |
| 4 | 7.284 | 0.78 | 100.393 | 0% | 41.771 | 39.119 |
| 5 | 9.105 | 1.041 | 89.794 | 10% | 27.2 | 24.548 |
| 6 | 10.926 | 1.301 | 81.97 | 18% | 19.823 | 17.171 |

| power/ground pairs scale | on-die C scale | extra pins | extra decap (mm^2) | first-droop L (pH) | die-pkg resonance (MHz) | dynamic beyond DC (mV) |
|---|---|---|---|---|---|---|
| 1 | 1 | 0 | 0 | 345.042 | 200.786 | 37.619 |
| 1.5 | 1 | 4 | 0 | 230.028 | 245.911 | 42.341 |
| 2 | 1 | 8 | 0 | 172.521 | 283.954 | 25.574 |
| 1.5 | 2 | 4 | 0.26 | 230.028 | 173.886 | 22.736 |
| 2 | 2 | 8 | 0.26 | 172.521 | 200.786 | 18.313 |

**Lowest-cost combined option meeting the criterion:** x2.0 power/ground connection pairs (+8 package pins of 17 free) with x1.0 on-die capacitance (+0.00 mm^2) -> 25.6 mV.

Package-inductance what-if: more VDD/VSS bond-wire/lead pairs (pin budget permitting) reduce the loop inductance and the anti-resonance peak; combined with moderate decap this is usually cheaper in silicon area than capacitance alone.

**Recommended:** scale on-die capacitance x6.0 (+1.30 mm^2 of decap cells) - smallest step with dynamic noise <= 60 % of the 50 mV allocation and the resonance >15 % away from clock harmonics.  Note the non-monotonic behaviour: capacitance that moves the resonance onto a clock harmonic makes noise worse.

What-if table: lumped clocked model of the primary wake-up event as the on-die capacitance is scaled (ESR scaled inversely).  Use it to trade decap area (and its gate leakage) against noise margin.

## 8. Thermal coupling and cooling

![Die temperature map at the maximum workload (2-D conduction, compact boundary).](figures/thermal_map.png)

*Die temperature map at the maximum workload (2-D conduction, compact boundary).*

![Junction temperature for every package and cooling option at worst ambient.](figures/cooling_comparison.png)

*Junction temperature for every package and cooling option at worst ambient.*

| cooling | wb_qfn88 | wb_bga256 | fc_bga | adv_organic | si_interposer | theta_ja (wb_qfn88) |
|---|---|---|---|---|---|---|
| natural_convection | 74.116 | 74.468 | 73.604 | 73.331 | 72.775 | 23.924 |
| small_passive_heatsink | 72.562 | 72.489 | 71.899 | 71.857 | 71.817 | 14.927 |
| large_passive_heatsink | 72.089 | 71.751 | 71.033 | 71.025 | 71.024 | 12.175 |
| active_heatsink | 71.878 | 71.412 | 70.567 | 70.571 | 70.585 | 10.95 |
| vapor_chamber_fan | 71.81 | 71.301 | 70.403 | 70.409 | 70.428 | 10.557 |

Specialist thermal results can be imported (`powerlink thermal-import`); the PowerLink map is exported in the same CSV format to `thermal_map_export.csv`.

## 9. Package comparison

![Package sub-scores and overall weighted score (status = hard-constraint check).](figures/package_comparison.png)

*Package sub-scores and overall weighted score (status = hard-constraint check).*

| package | family | pins | L_pkg pH | pkg DC mV | first droop bound mV | SSO mV | SI Gb/s | T_j passive C | USD/unit @vol | NRE USD | score | status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| wb_qfn88 | wire_bond_qfn | 79/88 | 345.042 | 0.826 | 15.676 | 111.23 | 0.6 | 72.094 | 0.6 | 3e+03 | 0.764 | nominal only |
| fc_bga | flip_chip_bga | 76/324 | 184.25 | 0.145 | 11.455 | 23.822 | 16 | 71.037 | 15 | 9e+04 | 0.726 | robust |
| adv_organic | advanced_organic | 76/900 | 160.821 | 0.13 | 10.702 | 20.419 | 24 | 71.029 | 43 | 2.5e+05 | 0.664 | robust |
| wb_bga256 | wire_bond_bga | 79/256 | 2e+03 | 5.701 | 37.699 | 118.802 | 1.5 | 71.756 | 3.2 | 2e+04 | 0.633 | nominal only |
| si_interposer | silicon_interposer | 76/2500 | 5.151 | 0.196 | 1.915 | 18.817 | 32 | 71.028 | 200 | 1.2e+06 | 0.599 | robust |

- `wb_qfn88`: passes nominal, fails at adverse corner: sso_noise
- `fc_bga`: all checks pass at nominal and adverse corner
- `adv_organic`: all checks pass at nominal and adverse corner
- `wb_bga256`: passes nominal, fails at adverse corner: core_first_droop, sso_noise
- `si_interposer`: all checks pass at nominal and adverse corner

## 10. Power-integrity margins

### VDD_CORE

![VDD_CORE budget waterfall (worst-case stack).](figures/margin_VDD_CORE.png)

*VDD_CORE budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 10 | 15 | 10 | FAIL | assumption |
| ripple (half p-p) | 0.263 | 0.335 | 10 | True | model |
| static IR (worst cell) | 4.769 | 24.525 | 30 | PASS | grid solver |
| dynamic droop + cycle noise | 33.606 | 233.852 | 50 | FAIL | dynamic grid x lumped corner |
| guardband | 5 | 5 | 5 | PASS | spec |

Available 95.0 mV (V_nom - V_min - guardband).  Margin: nominal 46.4 mV, RSS -163.9 mV, worst-case -178.7 mV.  Monte-Carlo (n=4000): P(fail) 15.50%, 1st percentile margin -143.0 mV, median 54.9 mV; surrogate error at the worst corner 7.1%.

Direct Monte-Carlo with the full lumped model on the first 200 draws: P(fail) 7.50% (surrogate on the same draws 19.50%); correlation of the dynamic term between full model and surrogate r = 0.67.  Where they disagree, the full-model figure governs.

![Monte-Carlo margin distribution.](figures/margin_monte_carlo.png)

*Monte-Carlo margin distribution.*

| parameter | elasticity of dynamic droop (d ln m / d ln p) |
|---|---|
| c_die | -2.69 |
| activity_scale | 0.749 |
| conn_l | -0.725 |
| csw_scale | 0.711 |
| kge_scale | 0.711 |
| pin_l | -0.633 |
| pcb_esl | -0.231 |
| clk_cap_scale | 0.215 |

### VDDIO

![VDDIO budget waterfall (worst-case stack).](figures/margin_VDDIO.png)

*VDDIO budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 49.5 | 66 | 49.5 | FAIL | assumption |
| ripple (half p-p) | 0.456 | 0.714 | 33 | True | model |
| static IR (path) | 3.41 | 6.925 | 66 | PASS | lumped path |
| dynamic droop | 3.934 | 10.776 | 132 | PASS | lumped transient |
| guardband | 16.5 | 16.5 | 16.5 | PASS | spec |

Available 283.5 mV (V_nom - V_min - guardband).  Margin: nominal 226.2 mV, RSS 209.7 mV, worst-case 199.1 mV.

### VDDA_PLL

![VDDA_PLL budget waterfall (worst-case stack).](figures/margin_VDDA_PLL.png)

*VDDA_PLL budget waterfall (worst-case stack).*

| component | nominal mV | adverse corner mV | allocation mV | within allocation | source |
|---|---|---|---|---|---|
| regulator setpoint | 10 | 20 | 10 | FAIL | assumption |
| ripple (half p-p) | 0.00243 | 0.00485 | 5 | True | model |
| static IR (path) | 1.407 | 2.526 | 10 | PASS | lumped path |
| dynamic droop | 0 | 0 | 20 | PASS | lumped transient |
| guardband | 5 | 5 | 5 | PASS | spec |

Available 45.0 mV (V_nom - V_min - guardband).  Margin: nominal 33.6 mV, RSS 22.5 mV, worst-case 22.5 mV.

## 11. Risk summary

![Risk matrix (likelihood from computed utilisation ratios; impact by engineering judgement).](figures/risk_matrix.png)

*Risk matrix (likelihood from computed utilisation ratios; impact by engineering judgement).*

| # | risk | metric | L | I | score | status | mitigation |
|---|---|---|---|---|---|---|---|
| 1 | Core total PI margin (worst-case stack) | margin -178.7 mV worst, -163.9 mV RSS, P(fail) MC 15.50% | 5 | 5 | 25 | critical | re-balance budget; tighten regulator setpoint; more decap |
| 2 | Core dynamic droop / cycle noise | 233.9 mV worst corner vs 50 mV | 5 | 4 | 20 | critical | increase on-die decap (see decap what-if), staggered tile wake, vectored dynamic IR |
| 3 | Technology data are generic (no PDK selected) | technology 'generic_65nm' tagged assumption | 4 | 4 | 16 | critical | select PDK; replace metal/via/EM/decap/leakage values; implement and sign off |
| 4 | I/O simultaneous-switching noise (chiplet link) | 111 mV nominal / 542 mV fast-edge corner vs 330 mV | 5 | 3 | 15 | serious | slew-rate-controlled pads, more VDDIO/VSSIO pairs, LVDS/low-swing link |
| 5 | On-die decoupling sufficiency | 1.82 nF vs 4.76 nF rule-of-thumb | 5 | 3 | 15 | serious | allocate decap-cell area per what-if table; MOS-cap leakage trade-off |
| 6 | Core static IR drop | 24.5 mV worst corner vs 30 mV | 3 | 4 | 12 | serious | add M8/M9 straps or pads; signoff static IR (RedHawk-SC/Voltus) |
| 7 | Switching activity is assumed, not measured | activity source: assumption | 4 | 3 | 12 | serious | gate-level SAIF/VCD from representative firmware; re-run PowerLink |
| 8 | Package pin budget | 79 of 88 (incl. 10% spare) | 3 | 3 | 9 | warning | larger body or BGA if I/O grows |
| 9 | PDN resonance near clock harmonics | 178 MHz (3428 mOhm) | 3 | 3 | 9 | warning | move resonance with decap/ESR damping; check with vectored dynamic IR |
| 10 | Electromigration (straps, vias, bond wires) | worst VDD_CORE via M6-M8: 14% of limit | 1 | 5 | 5 | warning | foundry EM rule deck at signoff temperature; via arrays at ring/strap ends |
| 11 | Core regulator loop stability | phase margin 65 deg at 100 kHz (averaged model) | 1 | 4 | 4 | good | verify with the PMIC vendor model and a load-step bench measurement |
| 12 | PLL analogue supply noise | 0.00 mV p-p vs 10 mV limit | 1 | 4 | 4 | good | dedicated LDO + RC filter, separate VSSA, guard ring |
| 13 | Junction temperature | 74.1 C at 70 C ambient vs 105 C | 1 | 4 | 4 | good | cooling option per comparison; thermal signoff (Icepak/Celsius) |
| 14 | Regulator ripple at die | 0.53 mV p-p vs 10 mV | 1 | 2 | 2 | good | output-cap ESR/ESL selection, layout |

## 12. On-die PDN configuration and OpenROAD scripts

| layer | direction | width um | pitch um | PG track usage |
|---|---|---|---|---|
| M1 | H | 0.24 | 3.6 | 0.133 |
| M6 | V | 1.6 | 25 | 0.128 |
| M8 | H | 6 | 60 | 0.2 |
| M9 | V | 6 | 60 | 0.2 |

Configuration checks: no errors; no warnings.

Generated scripts (example only - no DRC/LVS correctness is asserted without the chosen PDK and a real implementation run): `pdn_silicaflux_v_generic.tcl`, `pdn_silicaflux_v_sky130.tcl`, `pdn_silicaflux_v_gf180mcu.tcl`, `silicaflux_v_power_intent.upf`.

## 13. Validation

Independent cross-check of the in-house MNA solver against ngspice on the circuits used above:

| check | PowerLink | ngspice | abs diff | rel diff | tolerance | result |
|---|---|---|---|---|---|---|
| ladder DC V(die) | 0.998 | 0.998 | 6.41e-10 | 6.42e-10 | 1e-06 V /  rel | PASS |
| ladder \|Z(f)\| max rel. error (61 points, 1 kHz-1 GHz) | 2.005 | 2.005 | 5.84e-08 | 1.11e-07 | 1e-3 rel | PASS |
| ladder transient V_min | 0.995 | 0.995 | 2.01e-07 | 2.02e-07 | 0.0002 V /  rel (ngspice trap, reltol 1e-6) | PASS |
| ladder transient waveform RMS difference | 0.996 | 0.996 | 2.78e-08 | 2.79e-08 | 1e-4 V | PASS |
| grid DC node voltages, max \|diff\| over 1504 nodes | 0 | 0 | 3.56e-11 | 3.56e-11 | 1e-6 V | PASS |

Unit tests (pytest) cover the MNA solver against analytic RC/RLC/divider solutions, the grid solver against the analytic uniform-sheet solution and current conservation, the VRM loop against the analytic crossover, the thermal solver against 1-D and Song-Lee-Au limits, VCD/SAIF parsing and the package/margin logic.  Commercial signoff experiments are specified in docs/VALIDATION_AND_SIGNOFF.md.

## 14. Assumption register

223 uncertain inputs (full list in `assumptions.csv`).  Largest relative spans:

| path | nominal | min | max | source | note |
|---|---|---|---|---|---|
| technology.decap_cell.leak_na_per_um2 | 0.05 | 0.01 | 0.3 | assumption |  |
| technology.sram.macro_types.sp_1024x32.leak_ua_25c | 6 | 1.5 | 25 | assumption |  |
| technology.sram.macro_types.sp_256x32.leak_ua_25c | 2 | 0.5 | 8 | assumption |  |
| technology.stdcell.leak_per_ge_na_25c | 5 | 1.5 | 20 | assumption | mixed HVT/SVT; GP/LP flavour unknown until PDK chosen |
| packages.packages.wb_qfn88.cost.nre_usd | 3e+03 | 0 | 1e+04 | assumption | standard leadframe |
| packages.packages.si_interposer.interposer_decap.nf_per_mm2 | 300 | 100 | 1e+03 | literature | if the interposer process offers DTC |
| thermal.ambient_c | 25 | 0 | 70 | spec | 70C = sealed enclosure worst case |
| packages.packages.wb_qfn88.cost.proto_unit_usd | 15 | 5 | 40 | assumption | MPW engineering lot |
| packages.packages.si_interposer.cost.proto_unit_usd | 3e+03 | 1e+03 | 8e+03 | assumption |  |
| packages.packages.wb_bga256.cost.proto_unit_usd | 40 | 15 | 100 | assumption |  |
| packages.packages.adv_organic.cost.proto_unit_usd | 800 | 300 | 2e+03 | assumption |  |
| technology.decap_cell.esr_ohm_um2 | 2e+03 | 800 | 5e+03 | assumption | area-normalised series resistance (R*area) of MOS decap |
| pcb.regulators.ldo_pll.r_out_ohm | 0.02 | 0.01 | 0.05 | assumption |  |
| packages.packages.fc_bga.cost.proto_unit_usd | 250 | 100 | 600 | assumption |  |
| packages.packages.si_interposer.interposer_decap.esr_ohm | 0.002 | 0.001 | 0.005 | assumption | whole bank |
| packages.packages.si_interposer.cost.unit_usd | 80 | 40 | 200 | literature |  |
| packages.packages.wb_bga256.cost.nre_usd | 2e+04 | 8e+03 | 4.5e+04 | assumption | substrate design + tooling |
| packages.packages.adv_organic.cost.unit_usd | 18 | 9 | 40 | literature |  |
| packages.packages.si_interposer.cost.nre_usd | 1.2e+06 | 5e+05 | 2.5e+06 | assumption |  |
| packages.packages.si_interposer.interposer_decap.esl_h | 5e-12 | 2e-12 | 1e-11 | assumption | whole bank incl. interposer RDL |
