#!/usr/bin/env python3
"""Assemble FINDINGS.md from the per-chip results (results/<chip>/summary.json).

usage: python3 scripts/make_findings.py
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CHIPS = [("silicaflux_v", "SilicaFlux-V (first silicon, 65 nm)"),
         ("silicaflux_x_future", "SilicaFlux-X (HYPOTHETICAL future variant, 28 nm)")]


def fmt(x, nd=1):
    return f"{x:.{nd}f}"


def main():
    out = ["# SilicaFlux PowerLink - findings", "",
           "Generated from `results/*/summary.json` by `scripts/make_findings.py`.  All numbers inherit the "
           "provenance tags of their inputs (planning assumptions, literature ranges); see each chip's "
           "`report.html` for the evidence, figures and the full assumption register.", ""]
    for key, title in CHIPS:
        f = ROOT / "results" / key / "summary.json"
        if not f.exists():
            continue
        s = json.loads(f.read_text())
        out += [f"## {title}", ""]
        out += ["**Verdict**", ""] + [f"- {v}" for v in s["verdict"]] + [""]
        out += ["**Power by workload (worst ambient, electro-thermal)**", "",
                "| profile | total mW |", "|---|---|"]
        out += [f"| {k} | {fmt(v)} |" for k, v in s["power_mw"].items()] + [""]
        out += ["**Rail margins**", "", "| rail | nominal mV | RSS mV | worst-case mV | MC P(fail) |", "|---|---|---|---|---|"]
        for r, b in s["budgets"].items():
            pf = f"{b['mc_p_fail']:.2%}" if "mc_p_fail" in b else "-"
            out.append(f"| {r} | {fmt(b['margin_nominal_mv'])} | {fmt(b['margin_rss_mv'])} | {fmt(b['margin_worst_mv'])} | {pf} |")
        out += ["", "**Package ranking**", "", "| package | score | feasible | robust | notes |", "|---|---|---|---|---|"]
        for p in s["packages"]:
            out.append(f"| {p['key']} | {fmt(p['score'], 2)} | {p['feasible']} | {p['robust']} | {'; '.join(p['notes'])} |")
        out += ["", "**Top risks**", ""]
        out += [f"- {r['title']} - {r['status']} (score {r['score']})" for r in s["risks"][:6]]
        out += ["", f"Solver cross-check against ngspice: {'all pass' if s.get('crosscheck_all_pass') else 'see report'}.", ""]
    notes = ROOT / "docs" / "FINDINGS_NOTES.md"
    if notes.exists():
        out += [notes.read_text()]
    (ROOT / "FINDINGS.md").write_text("\n".join(out) + "\n")
    print("wrote FINDINGS.md")


if __name__ == "__main__":
    main()
