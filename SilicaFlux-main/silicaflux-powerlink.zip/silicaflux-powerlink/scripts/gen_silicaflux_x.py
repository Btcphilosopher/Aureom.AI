#!/usr/bin/env python3
"""Generate the SilicaFlux-X (hypothetical future variant) chip, PDN and workload
configuration files.  The 16-tile floorplan is regular, so it is generated
rather than hand-written; the output YAML files are committed alongside.

SilicaFlux-X is a SCENARIO, not a design: 28 nm, 1 GHz, 4x4 compute tiles
(16-lane vector, 8x8 MAC tensor array, 2 x 64 KiB SRAM each), a central
control spine with a 4-core scalar cluster and 128 KiB L2, a 64-lane die-to-die
link and an LPDDR-class memory interface.  It exists to test whether the
SilicaFlux power/package approach scales (flip-chip, multiple rails, interposer).

usage: python3 scripts/gen_silicaflux_x.py
"""
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
CORE = 5200.0
TILE_W, TILE_H = 1300.0, 1200.0
SPINE_Y0, SPINE_Y1 = 2400.0, 2800.0


def u(nom, lo, hi, src="assumption", note=None):
    d = {"nom": nom, "min": lo, "max": hi, "source": src}
    if note:
        d["note"] = note
    return d


def tile_blocks(k, x0, y0):
    t = f"tile{k:02d}"
    R = lambda a, b, c, d: [x0 + a, y0 + b, x0 + c, y0 + d]  # noqa: E731
    return [
        {"name": f"{t}_vec", "kind": "logic", "group": "vector", "rail": "VDD_TILE", "rect_um": R(20, 640, 800, 1180),
         "kge": u(400, 300, 520), "flops": 20000},
        {"name": f"{t}_tensor", "kind": "logic", "group": "tensor", "rail": "VDD_TILE", "rect_um": R(20, 20, 800, 620),
         "kge": u(250, 180, 330), "flops": 16000},
        {"name": f"{t}_noc", "kind": "logic", "group": "noc", "rail": "VDD_TILE", "rect_um": R(820, 570, 1280, 630),
         "kge": u(40, 28, 55), "flops": 4000},
        {"name": f"{t}_sram_a", "kind": "sram", "group": "sram_tile", "rail": "VDD_SRAM",
         "rect_um": R(820, 640, 1280, 1180), "macro": "sp_8192x64", "pin_layer": "M4"},
        {"name": f"{t}_sram_b", "kind": "sram", "group": "sram_tile", "rail": "VDD_SRAM",
         "rect_um": R(820, 20, 1280, 560), "macro": "sp_8192x64", "pin_layer": "M4"},
    ]


def main():
    blocks = []
    k = 0
    for row, y in enumerate([0.0, TILE_H, SPINE_Y1, SPINE_Y1 + TILE_H]):
        for col in range(4):
            blocks += tile_blocks(k, col * TILE_W, y)
            k += 1
    spine = [
        {"name": "cpu_cluster", "kind": "logic", "group": "cpu", "rail": "VDD_CPU",
         "rect_um": [100, SPINE_Y0 + 20, 2000, SPINE_Y1 - 20], "kge": u(600, 450, 800), "flops": 60000},
        {"name": "scheduler", "kind": "logic", "group": "scheduler", "rail": "VDD_CPU",
         "rect_um": [2050, SPINE_Y0 + 20, 3050, SPINE_Y1 - 20], "kge": u(80, 55, 110), "flops": 8000},
        {"name": "l2_sram_a", "kind": "sram", "group": "sram_l2", "rail": "VDD_SRAM",
         "rect_um": [3100, SPINE_Y0 + 20, 3600, SPINE_Y1 - 20], "macro": "sp_8192x64", "pin_layer": "M4"},
        {"name": "l2_sram_b", "kind": "sram", "group": "sram_l2", "rail": "VDD_SRAM",
         "rect_um": [3650, SPINE_Y0 + 20, 4150, SPINE_Y1 - 20], "macro": "sp_8192x64", "pin_layer": "M4"},
        {"name": "periph_ctrl", "kind": "logic", "group": "periph", "rail": "VDD_CPU",
         "rect_um": [4200, SPINE_Y0 + 20, 4950, SPINE_Y1 - 20], "kge": u(60, 40, 80), "flops": 6000},
        {"name": "pll", "kind": "analog", "group": "pll", "rail": "VDDA_PLL",
         "rect_um": [5000, SPINE_Y0 + 20, 5200, SPINE_Y0 + 220], "fixed_power_mw": u(6.0, 3.0, 10.0)},
    ]
    blocks = spine + blocks
    sram_rects = [b["rect_um"] for b in blocks if b["kind"] == "sram"]
    chip = {
        "references": {"technology": "../tech/generic_28nm.yaml", "pcb": "../pcb/silicaflux_x_board.yaml",
                       "packages": "../packages/package_library.yaml", "pdn": "../pdn/silicaflux_x_pdn.yaml",
                       "workloads": "../workloads/silicaflux_x_workloads.yaml", "thermal": "../thermal/cooling.yaml"},
        "chip": {"name": "SilicaFlux-X", "status": "HYPOTHETICAL future-variant scenario (not a design)",
                 "die": {"width_mm": 6.0, "height_mm": 6.0, "thickness_um": 775},
                 "core": {"x0_mm": 0.4, "y0_mm": 0.4, "width_mm": 5.2, "height_mm": 5.2},
                 "clock_mhz": 1000, "baseline_package": "fc_bga", "tj_max_c": 105, "activity_source": "assumed"},
        "analysis": {"reference_cooling": "active_heatsink"},
        "package_study": {"volume_units": 10000, "design_delta_i_event": "tiles_wake_staggered"},
        "rails": {
            "VDD_TILE": {"nominal_v": 0.80, "min_v": 0.72, "max_v": 0.88, "regulator": "buck_tile", "kind": "digital_core",
                         "ground": "VSS", "on_die_grid": True,
                         "budget": {"setpoint": 0.010, "ripple": 0.010, "dc_ir": 0.030, "dynamic": 0.050, "guardband": 0.005}},
            "VDD_CPU": {"nominal_v": 0.90, "min_v": 0.81, "max_v": 0.99, "regulator": "buck_cpu", "kind": "digital",
                        "ground": "VSS", "on_die_grid": True,
                        "budget": {"setpoint": 0.010, "ripple": 0.010, "dc_ir": 0.030, "dynamic": 0.050, "guardband": 0.005}},
            "VDD_SRAM": {"nominal_v": 0.90, "min_v": 0.84, "max_v": 0.99, "regulator": "buck_sram", "kind": "sram",
                         "ground": "VSS", "on_die_grid": True,
                         "budget": {"setpoint": 0.010, "ripple": 0.005, "dc_ir": 0.020, "dynamic": 0.030, "guardband": 0.002}},
            "VDDIO": {"nominal_v": 1.8, "min_v": 1.62, "max_v": 1.98, "regulator": "buck_io", "kind": "io", "ground": "VSS",
                      "on_die_grid": False, "die_cap_nf": u(4.0, 2.0, 8.0), "die_r_grid_ohm": u(0.01, 0.005, 0.02),
                      "budget": {"setpoint": 0.015, "ripple": 0.010, "dc_ir": 0.020, "dynamic": 0.040, "guardband": 0.005}},
            "VDDA_PLL": {"nominal_v": 0.90, "min_v": 0.855, "max_v": 0.945, "regulator": "ldo_pll", "kind": "analog",
                         "ground": "VSSA", "on_die_grid": False, "noise_limit_mv_pp": 10,
                         "die_cap_nf": u(1.0, 0.5, 2.0), "die_r_grid_ohm": u(0.2, 0.1, 0.4),
                         "budget": {"setpoint": 0.010, "ripple": 0.005, "dc_ir": 0.010, "dynamic": 0.020, "guardband": 0.005}},
        },
        "io": {
            "signals": {
                "d2d_link": {"pins": 72, "rate_mbps": 2000, "load_pf": 0.5, "activity": 0.25,
                             "note": "64 data + 8 clock/control, short-reach die-to-die"},
                "lpddr": {"pins": 56, "rate_mbps": 1600, "load_pf": 2.0, "activity": 0.25},
                "misc": {"pins": 36, "rate_mbps": 25, "load_pf": 10.0, "activity": 0.02,
                         "note": "JTAG, SPI, UART, GPIO, reset, clocks, power status"},
            },
            "max_signal_rate_gbps": 2.0,
            "io_rail": "VDDIO",
            "simultaneous_switching_outputs": 64,
            "sso_load_pf": 1.0,
            "sso_swing_v": 0.4,
            "sso_per_power_pair": 3,
            "output_edge_ns": u(0.2, 0.12, 0.35),
            "spare_fraction": 0.10,
        },
        "blocks": blocks,
    }
    hdr = ("# GENERATED by scripts/gen_silicaflux_x.py - edit the generator, not this file.\n"
           "# SilicaFlux-X is a HYPOTHETICAL future-variant scenario used to test how the SilicaFlux\n"
           "# power/package approach scales (28 nm, 1 GHz, 16 tiles, 5 rails, flip-chip).  All gate\n"
           "# counts and activities are planning assumptions.\n")
    (ROOT / "configs/chips/silicaflux_x_future.yaml").write_text(hdr + yaml.safe_dump(chip, sort_keys=False, width=120))

    pdn = {
        "name": "silicaflux_x_pdn",
        "analysis": {"static_resolution_um": 50, "dynamic_resolution_um": 130, "metal_temperature_c": 95},
        "regions": {"core": [0, 0, CORE, CORE], "tiles_s": [0, 0, CORE, SPINE_Y0], "tiles_n": [0, SPINE_Y1, CORE, CORE],
                    "spine": [0, SPINE_Y0, CORE, SPINE_Y1], "pll_keepout": [4990, SPINE_Y0, CORE, SPINE_Y0 + 240],
                    **{f"sram{i}": r for i, r in enumerate(sram_rects)}},
        "nets": {
            "VDD_CPU": {"type": "power", "rail": "VDD_CPU", "region": "spine", "exclude": ["pll_keepout"],
                        "layers": ["M1", "M4", "M7", "M8", "M9"]},
            "VDD_SRAM": {"type": "power", "rail": "VDD_SRAM", "region": [f"sram{i}" for i in range(len(sram_rects))],
                         "layers": ["M4", "M7", "M8", "M9"]},
            "VDD_TILE": {"type": "power", "rail": "VDD_TILE", "region": ["tiles_s", "tiles_n"],
                         "layers": ["M1", "M4", "M7", "M8", "M9"]},
            "VSS": {"type": "ground", "region": "core", "exclude": ["pll_keepout"], "layers": ["M1", "M4", "M7", "M8", "M9"]},
        },
        "voltage_domains": {
            "CPU": {"power": "VDD_CPU", "ground": "VSS", "region": "core",
                    "contains": ["cpu", "scheduler", "periph"], "elements": ["u_cpu_cluster", "u_scheduler", "u_periph"]},
            "TILES_S": {"power": "VDD_TILE", "ground": "VSS", "region": "tiles_s", "switched": True,
                        "switched_power": "VDD_TILE_SW_S", "elements": [f"u_tile{k:02d}" for k in range(8)],
                        "note": "header power switches; IR model treats switches as ideal"},
            "TILES_N": {"power": "VDD_TILE", "ground": "VSS", "region": "tiles_n", "switched": True,
                        "switched_power": "VDD_TILE_SW_N", "elements": [f"u_tile{k:02d}" for k in range(8, 16)],
                        "note": "header power switches; IR model treats switches as ideal"},
            "PLL": {"power": "VDDA_PLL", "ground": "VSSA", "region": "pll_keepout", "analog": True, "contains": ["pll"]},
        },
        "layers": [
            {"name": "M1", "role": "followpin", "direction": "H", "width_um": 0.10, "pitch_um": 1.8},
            {"name": "M4", "role": "strap", "direction": "V", "width_um": 0.8, "pitch_um": 10.0, "offset_um": 1.0, "spacing_um": 0.3},
            {"name": "M7", "role": "strap", "direction": "H", "width_um": 2.0, "pitch_um": 20.0, "offset_um": 2.0, "spacing_um": 0.6},
            {"name": "M8", "role": "strap", "direction": "V", "width_um": 4.0, "pitch_um": 30.0, "offset_um": 4.0, "spacing_um": 1.0},
            {"name": "M9", "role": "strap", "direction": "H", "width_um": 10.0, "pitch_um": 75.0, "offset_um": 8.0, "spacing_um": 3.0},
        ],
        "vias": [
            {"from": "M1", "to": "M4", "levels": ["low", "low", "low"], "cuts_per_level": 2},
            {"from": "M4", "to": "M7", "levels": ["mid", "mid", "mid"], "cuts_per_level": 4},
            {"from": "M7", "to": "M8", "levels": ["mid"], "cuts_per_level": 8},
            {"from": "M8", "to": "M9", "levels": ["top"], "cuts_per_level": 16},
        ],
        "rings": [],
        "macros": {"pattern": "*sram*", "halo_um": 5.0, "pin_layer": "M4", "blocked_layers": ["M1"]},
        "supply": {"flip_chip": {"bump_to_grid_ohm": u(0.01, 0.005, 0.02), "pattern": "checkerboard",
                                 "via_farm_cuts": 64},
                   "wire_bond": {"pads_per_side": {"VDD_TILE": 6, "VDD_CPU": 2, "VDD_SRAM": 2, "VSS": 8},
                                 "pad_to_ring_ohm": u(0.05, 0.03, 0.1)}},
        "decap": {"logic_fill_fraction": u(0.20, 0.12, 0.25, note="high-performance design: decap filler in logic"),
                  "regions": [{"name": "spine_gap", "rail": "VDD_CPU", "rect_um": [100, SPINE_Y0 + 5, 5000, SPINE_Y0 + 20],
                               "fill_fraction": 0.8}]},
        "openroad": {"stdcell_power_pin": "^VDD$", "stdcell_ground_pin": "^VSS$", "macro_instance_pattern": "*sram*",
                     "macro_secondary_supplies": [{"net": "VDD_SRAM", "inst_pattern": ".*sram.*", "pin_pattern": "^VDDM$"}],
                     "pdk_targets": ["generic"]},
    }
    (ROOT / "configs/pdn/silicaflux_x_pdn.yaml").write_text(hdr + yaml.safe_dump(pdn, sort_keys=False, width=120))

    act = lambda a, g: {"alpha": a, "clock_enable": g}  # noqa: E731
    sram = lambda r, w: {"reads_per_cycle": r, "writes_per_cycle": w}  # noqa: E731
    wl = {
        "activity_convention": "alpha = P(0->1 per cycle); TR = 2*alpha",
        "assumed_activity_scale": u(1.0, 0.6, 1.5, note="global multiplier on every assumed alpha"),
        "activity_files": {},
        "activity_block_map": {},
        "profiles": {
            "idle": {"description": "cluster in WFI, tiles clock-gated", "activity": {
                "cpu": act(0.005, 0.1), "scheduler": act(0.002, 0.05), "periph": act(0.01, 0.3), "noc": act(0.001, 0.05),
                "vector": act(0.0, 0.02), "tensor": act(0.0, 0.02), "sram_tile": sram(0, 0), "sram_l2": sram(0.01, 0.0)},
                "io_activity": {"d2d_link": 0.0, "lpddr": 0.0}},
            "cpu_intensive": {"description": "scalar cluster busy", "activity": {
                "cpu": act(0.15, 1.0), "scheduler": act(0.03, 1.0), "periph": act(0.02, 0.5), "noc": act(0.01, 0.3),
                "vector": act(0.0, 0.02), "tensor": act(0.0, 0.02), "sram_tile": sram(0, 0), "sram_l2": sram(0.6, 0.3)},
                "io_activity": {"d2d_link": 0.02, "lpddr": 0.1}},
            "vector_intensive": {"description": "16-lane vector kernels on all tiles", "activity": {
                "cpu": act(0.05, 1.0), "scheduler": act(0.1, 1.0), "periph": act(0.01, 0.3), "noc": act(0.1, 1.0),
                "vector": act(0.2, 1.0), "tensor": act(0.01, 0.2), "sram_tile": sram(0.8, 0.4), "sram_l2": sram(0.2, 0.1)},
                "io_activity": {"d2d_link": 0.1, "lpddr": 0.2}},
            "tensor_intensive": {"description": "8x8 MAC arrays saturated", "activity": {
                "cpu": act(0.05, 1.0), "scheduler": act(0.08, 1.0), "periph": act(0.01, 0.3), "noc": act(0.08, 1.0),
                "vector": act(0.05, 1.0), "tensor": act(0.22, 1.0), "sram_tile": sram(0.9, 0.3), "sram_l2": sram(0.2, 0.1)},
                "io_activity": {"d2d_link": 0.1, "lpddr": 0.2}},
            "sram_heavy": {"description": "tile-to-tile and DRAM streaming", "activity": {
                "cpu": act(0.05, 1.0), "scheduler": act(0.05, 1.0), "periph": act(0.01, 0.3), "noc": act(0.2, 1.0),
                "vector": act(0.02, 0.5), "tensor": act(0.0, 0.1), "sram_tile": sram(1.0, 1.0), "sram_l2": sram(1.0, 1.0)},
                "io_activity": {"d2d_link": 0.25, "lpddr": 0.25}},
            "max_simultaneous": {"description": "STRESS BOUND: all units active (not a realistic program)", "activity": {
                "cpu": act(0.2, 1.0), "scheduler": act(0.15, 1.0), "periph": act(0.05, 1.0), "noc": act(0.2, 1.0),
                "vector": act(0.25, 1.0), "tensor": act(0.25, 1.0), "sram_tile": sram(1.0, 1.0), "sram_l2": sram(1.0, 1.0)},
                "io_activity": {"d2d_link": 0.5, "lpddr": 0.5}},
        },
        "cycle_current": {"peak_to_average": u(3.0, 2.0, 5.0)},
        "transient_events": {
            "tiles_wake_simultaneous": {"description": "all 16 tiles un-gated in one cycle", "from": "idle",
                                        "to": "max_simultaneous", "at_ns": 500, "rise_ns": 1},
            "tiles_wake_staggered": {"description": "one tile group every 50 ns", "from": "idle", "to": "max_simultaneous",
                                     "at_ns": 500, "rise_ns": 1, "stagger_steps": 8, "stagger_interval_ns": 50},
            "vector_burst": {"description": "cluster launches vector kernel", "from": "cpu_intensive",
                             "to": "vector_intensive", "at_ns": 500, "rise_ns": 2},
            "load_release": {"description": "kernel end", "from": "max_simultaneous", "to": "idle", "at_ns": 500, "rise_ns": 1},
        },
        "primary_event": "tiles_wake_simultaneous",
    }
    (ROOT / "configs/workloads/silicaflux_x_workloads.yaml").write_text(
        hdr + "# ACTIVITY VALUES ARE PLANNING ASSUMPTIONS, NOT MEASUREMENTS.\n" + yaml.safe_dump(wl, sort_keys=False, width=120))
    print("wrote silicaflux_x_future.yaml, silicaflux_x_pdn.yaml, silicaflux_x_workloads.yaml")


if __name__ == "__main__":
    main()
