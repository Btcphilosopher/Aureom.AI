#!/usr/bin/env bash
# Generic (technology-independent) Yosys synthesis to prove synthesizability and
# report cell counts.  Uses yosys' built-in SystemVerilog front-end (-sv).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"; mkdir -p results/rtl
for top in sf_pwr_seq sf_rst_clk_ctrl; do
  yosys -q -l "results/rtl/synth_$top.log" -p "read_verilog -sv rtl/sf_pwr_pkg.sv rtl/sf_sync.sv rtl/$top.sv; \
     synth -top $top -flatten; check -assert; stat" >/dev/null
  echo "== $top"; grep -A40 "Printing statistics" "results/rtl/synth_$top.log" | grep -E "Number of cells|\\\$_DFF|\\\$_SDFF|DFF" | head -8
done
