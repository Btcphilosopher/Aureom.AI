# Syntax / option checker for generated OpenROAD PDN scripts.
#
# Each OpenROAD PDN command used by PowerLink is replaced by a stub that
# verifies every "-option" against the option list documented for that
# command in the OpenROAD pdn module, and that value-taking options are
# followed by a value.  This validates Tcl syntax and option spelling only;
# it does NOT validate the PDN against a database, a PDK or DRC rules.
#
# usage: tclsh openroad_stub_check.tcl <script.tcl>
set ::errors 0
set ::ncmd 0
proc stub {name flags valued} {
    proc $name {args} [string map [list @NAME@ $name @FLAGS@ $flags @VALUED@ $valued] {
        incr ::ncmd
        set i 0
        while {$i < [llength $args]} {
            set a [lindex $args $i]
            if {[string index $a 0] eq "-"} {
                if {[lsearch -exact {@FLAGS@} $a] >= 0} {
                    incr i
                } elseif {[lsearch -exact {@VALUED@} $a] >= 0} {
                    if {$i + 1 >= [llength $args]} {
                        puts "ERROR: @NAME@: option $a needs a value"; incr ::errors
                    }
                    incr i 2
                } else {
                    puts "ERROR: @NAME@: unknown option $a"; incr ::errors; incr i
                }
            } else {
                puts "ERROR: @NAME@: unexpected positional argument '$a'"; incr ::errors; incr i
            }
        }
    }]
}
stub add_global_connection {-power -ground -defer_connection} {-net -inst_pattern -pin_pattern -region}
stub global_connect {} {}
stub set_voltage_domain {} {-name -power -ground -region -secondary_power -switched_power}
stub define_pdn_grid {-macro -default -grid_over_pg_pins -grid_over_boundary} \
    {-name -voltage_domains -pins -starts_with -instances -cells -halo -orient -obstructions -power_switch_cell -power_control -power_control_network}
stub add_pdn_ring {-add_connect -extend_to_boundary -connect_to_pads -allow_out_of_die} \
    {-grid -layers -widths -spacings -core_offsets -pad_offsets -connect_to_pad_layers -starts_with -nets -ring_offset}
stub add_pdn_stripe {-followpins -extend_to_core_ring -extend_to_boundary -snap_to_grid} \
    {-grid -layer -width -pitch -spacing -offset -starts_with -number_of_straps -nets}
stub add_pdn_connect {} {-grid -layers -cut_pitch -fixed_vias -dont_use_vias -max_rows -max_columns -ongrid -split_cuts}
stub pdngen {-skip_trim -dont_add_pins -reset -ripup -report_only -verbose} {-failed_via_report}
if {[catch {source [lindex $argv 0]} msg]} {
    puts "ERROR: Tcl evaluation failed: $msg"
    exit 2
}
puts "checked $::ncmd commands, $::errors errors"
exit [expr {$::errors > 0}]
