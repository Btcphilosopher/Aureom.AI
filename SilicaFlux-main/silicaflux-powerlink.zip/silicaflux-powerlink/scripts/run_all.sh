#!/usr/bin/env bash
# Reproduce every PowerLink deliverable: tests, RTL checks, OpenROAD scripts, both chip analyses.
#   MC=<samples> bash scripts/run_all.sh        (default 4000 Monte-Carlo samples)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
MC="${MC:-4000}"
echo "== RTL simulation";        bash scripts/sim_rtl.sh | grep -E "PASS|FAIL"
echo "== RTL lint";              bash scripts/lint_rtl.sh | tail -1
echo "== RTL synthesis";         bash scripts/synth_rtl.sh
echo "== unit tests";            python3 -m pytest -q
echo "== SilicaFlux-X configs";  python3 scripts/gen_silicaflux_x.py
for chip in silicaflux_v silicaflux_x_future; do
  echo "== OpenROAD scripts: $chip"
  python3 -m powerlink openroad --chip "configs/chips/$chip.yaml" --out openroad
  echo "== analysis: $chip"
  python3 -m powerlink run --chip "configs/chips/$chip.yaml" --out "results/$chip" --mc "$MC"
done
for f in openroad/*.tcl; do tclsh scripts/openroad_stub_check.tcl "$f"; done
python3 scripts/make_findings.py
echo "done - see results/*/report.html and FINDINGS.md"
