#!/usr/bin/env bash
# Verilator lint (all warnings enabled) of the synthesizable RTL.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"; mkdir -p results/rtl
for top in sf_pwr_seq sf_rst_clk_ctrl; do
  echo "== verilator --lint-only -Wall $top"
  verilator --lint-only -Wall -Wno-DECLFILENAME --top-module "$top" -f rtl/filelist.f 2>&1 | tee "results/rtl/lint_$top.log"
done
echo "lint clean"
