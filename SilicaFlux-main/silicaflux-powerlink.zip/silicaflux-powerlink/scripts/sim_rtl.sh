#!/usr/bin/env bash
# Run the self-checking power-sequencing testbenches with Icarus Verilog.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/results/rtl"; mkdir -p "$OUT"
cd "$ROOT"
status=0
for tb in tb_sf_pwr_seq:sf_pwr_seq.sv tb_sf_rst_clk_ctrl:sf_rst_clk_ctrl.sv; do
  name="${tb%%:*}"; dut="${tb##*:}"
  iverilog -g2012 -o "$OUT/$name.vvp" rtl/sf_pwr_pkg.sv rtl/sf_sync.sv "rtl/$dut" "rtl/tb/$name.sv"
  (cd "$OUT" && vvp -n "$name.vvp" | tee "$name.log")
  grep -q "PASS" "$OUT/$name.log" || status=1
done
exit $status
