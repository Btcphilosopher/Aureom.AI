# SilicaFlux PowerLink - findings

Generated from `results/*/summary.json` by `scripts/make_findings.py`.  All numbers inherit the provenance tags of their inputs (planning assumptions, literature ranges); see each chip's `report.html` for the evidence, figures and the full assumption register.

## SilicaFlux-V (first silicon, 65 nm)

**Verdict**

- Rail `VDD_CORE` (1.00 V, min 0.90 V): **not robust as specified (Monte-Carlo failure probability > 5 %)** - margin 46.4 mV nominal, -163.9 mV RSS, -178.7 mV worst-case, MC P(fail) 15.50% (surrogate, n=4000) / 7.50% (full model, n=200); dominant term: dynamic droop + cycle noise (233.9 mV corner vs 50 mV allocated).
- Rail `VDDIO` (3.30 V, min 3.00 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 226.2 mV nominal, 209.7 mV RSS, 199.1 mV worst-case; dominant term: regulator setpoint (66.0 mV corner vs 49 mV allocated).
- Rail `VDDA_PLL` (1.00 V, min 0.95 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 33.6 mV nominal, 22.5 mV RSS, 22.5 mV worst-case; dominant term: regulator setpoint (20.0 mV corner vs 10 mV allocated).
- Cheapest mitigation found: x2.0 core power/ground connection pairs (+8 pins, 17 free) and x1.0 on-die decoupling (+0.00 mm^2) bring the dynamic term to 25.6 mV (<= 60 % of allocation) in the lumped clocked model; confirm with dynamic-IR signoff.
- Capacitance-only alternative from the decap search: on-die capacitance x6.0 (10.9 nF, +1.30 mm^2 decap cells) gives 17.2 mV dynamic noise (<= 60 % of allocation) with the die-package resonance at 82 MHz, away from clock harmonics.
- Package `wb_qfn88`: adequate at nominal; corner issues: passes nominal, fails at adverse corner: sso_noise.
- PCB: plane + decap network meets the flat target impedance in the PCB-effective band (max |Z|/Z_t 0.11).  Above that band only on-die capacitance and package inductance matter.
- These conclusions are conditional on the assumed activity, generic technology data and family-level package parasitics recorded in the assumption register; they identify where signoff effort is needed, they do not replace it.

**Power by workload (worst ambient, electro-thermal)**

| profile | total mW |
|---|---|
| idle | 10.5 |
| cpu_intensive | 21.6 |
| vector_intensive | 93.3 |
| tensor_intensive | 90.7 |
| sram_heavy | 84.1 |
| max_simultaneous | 172.0 |

**Rail margins**

| rail | nominal mV | RSS mV | worst-case mV | MC P(fail) |
|---|---|---|---|---|
| VDD_CORE | 46.4 | -163.9 | -178.7 | 15.50% |
| VDDIO | 226.2 | 209.7 | 199.1 | - |
| VDDA_PLL | 33.6 | 22.5 | 22.5 | - |

**Package ranking**

| package | score | feasible | robust | notes |
|---|---|---|---|---|
| wb_qfn88 | 0.76 | True | False | passes nominal, fails at adverse corner: sso_noise |
| fc_bga | 0.73 | True | True |  |
| adv_organic | 0.66 | True | True |  |
| wb_bga256 | 0.63 | True | False | passes nominal, fails at adverse corner: core_first_droop, sso_noise |
| si_interposer | 0.60 | True | True |  |

**Top risks**

- Core total PI margin (worst-case stack) - critical (score 25)
- Core dynamic droop / cycle noise - critical (score 20)
- Technology data are generic (no PDK selected) - critical (score 16)
- I/O simultaneous-switching noise (chiplet link) - serious (score 15)
- On-die decoupling sufficiency - serious (score 15)
- Core static IR drop - serious (score 12)

Solver cross-check against ngspice: all pass.

## SilicaFlux-X (HYPOTHETICAL future variant, 28 nm)

**Verdict**

- Rail `VDD_TILE` (0.80 V, min 0.72 V): **not robust as specified (Monte-Carlo failure probability > 5 %)** - margin 14.5 mV nominal, -126.9 mV RSS, -136.6 mV worst-case, MC P(fail) 22.55% (surrogate, n=4000) / 27.00% (full model, n=200); dominant term: dynamic droop + cycle noise (175.1 mV corner vs 40 mV allocated).
- Rail `VDD_CPU` (0.90 V, min 0.81 V): **realistic statistically (passes RSS)** - margin 48.7 mV nominal, 0.5 mV RSS, -12.0 mV worst-case; dominant term: regulator setpoint (13.5 mV corner vs 9 mV allocated).
- Rail `VDD_SRAM` (0.90 V, min 0.84 V): **not robust as specified** - margin -14.6 mV nominal, -77.0 mV RSS, -90.2 mV worst-case; dominant term: dynamic droop + cycle noise (118.8 mV corner vs 27 mV allocated).
- Rail `VDDIO` (1.80 V, min 1.62 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 83.4 mV nominal, 77.8 mV RSS, 49.3 mV worst-case; dominant term: regulator setpoint (36.0 mV corner vs 27 mV allocated).
- Rail `VDDA_PLL` (0.90 V, min 0.85 V): **realistic with margin (passes the all-adverse worst-case stack)** - margin 29.9 mV nominal, 20.2 mV RSS, 20.2 mV worst-case; dominant term: regulator setpoint (18.0 mV corner vs 9 mV allocated).
- Capacitance-only alternative from the decap search: on-die capacitance x4.0 (153.2 nF, +9.57 mm^2 decap cells) gives 20.3 mV dynamic noise (<= 60 % of allocation) with the die-package resonance at 109 MHz, away from clock harmonics.
- Package `fc_bga`: adequate at nominal; corner issues: passes nominal, fails at adverse corner: sso_noise.
- PCB: plane + decap network meets the flat target impedance in the PCB-effective band (max |Z|/Z_t 0.27).  Above that band only on-die capacitance and package inductance matter.
- These conclusions are conditional on the assumed activity, generic technology data and family-level package parasitics recorded in the assumption register; they identify where signoff effort is needed, they do not replace it.

**Power by workload (worst ambient, electro-thermal)**

| profile | total mW |
|---|---|
| idle | 156.0 |
| cpu_intensive | 384.6 |
| vector_intensive | 1864.5 |
| tensor_intensive | 1973.3 |
| sram_heavy | 1481.1 |
| max_simultaneous | 3388.1 |

**Rail margins**

| rail | nominal mV | RSS mV | worst-case mV | MC P(fail) |
|---|---|---|---|---|
| VDD_TILE | 14.5 | -126.9 | -136.6 | 22.55% |
| VDD_CPU | 48.7 | 0.5 | -12.0 | - |
| VDD_SRAM | -14.6 | -77.0 | -90.2 | - |
| VDDIO | 83.4 | 77.8 | 49.3 | - |
| VDDA_PLL | 29.9 | 20.2 | 20.2 | - |

**Package ranking**

| package | score | feasible | robust | notes |
|---|---|---|---|---|
| fc_bga | 0.60 | True | False | passes nominal, fails at adverse corner: sso_noise |
| adv_organic | 0.56 | True | False | passes nominal, fails at adverse corner: sso_noise |
| si_interposer | 0.43 | True | False | passes nominal, fails at adverse corner: core_pkg_dc_drop, sso_noise |
| wb_qfn88 | 0.00 | False | False | fails: pin_budget, pad_ring, core_pkg_dc_drop, si_rate, sso_noise, thermal_any_cooling |
| wb_bga256 | 0.00 | False | False | fails: pin_budget, pad_ring, core_pkg_dc_drop, si_rate, sso_noise |

**Top risks**

- Core total PI margin (worst-case stack) - critical (score 25)
- Core static IR drop - critical (score 20)
- Core dynamic droop / cycle noise - critical (score 20)
- Technology data are generic (no PDK selected) - critical (score 16)
- I/O simultaneous-switching noise (chiplet link) - serious (score 15)
- On-die decoupling sufficiency - serious (score 15)

Solver cross-check against ngspice: all pass.

## Engineering interpretation

### SilicaFlux-V - are the proposed rails, package and PCB realistic?

**Yes for DC and thermal, conditionally for dynamic noise, and the I/O dominates the power.**

1. **Power is small and I/O-dominated.**  The core draws about 44 mA (44 mW) in the
   max-simultaneous stress case at 70 C ambient; the whole chip is about 172 mW, of which about
   126 mW is I/O - almost all of it the 22-pin 3.3 V LVCMOS chiplet link.  The cheapest power saving available is a
   low-swing link or a 1.8 V I/O option, not core optimisation.  Thermally, a QFN with a
   soldered exposed pad and no heatsink stays about 4 C above a 70 C ambient.
2. **Static IR drop is not a problem.**  About 5 mV worst cell (0.5 %): roughly 1.8 mV in the
   bond wires/pad stubs and 3.2 mV on die.  Even the all-adverse corner (25 mV) fits the 30 mV
   allocation.  Strap EM is about 2 % of the limit; vias and bond wires are below 10 %.  The
   PDN straps could be thinned if routing needs the tracks.
3. **The regulator and PCB are adequate.**  The 2 MHz PMIC buck closes at 100 kHz with a
   65-degree phase margin (averaged model); ripple at the die is 0.5 mV p-p; the PCB plane and
   decaps meet the flat target impedance up to the band where the package takes over
   (|Z|/Z_t 0.11).  No PCB decaps were added by the optimiser.
4. **The real issue is cycle-level noise from a die-package resonance.**  The 345 pH package
   loop (bond wires + leads) against about 1.8 nF of on-die capacitance resonates near
   180-200 MHz, i.e. on the second harmonic of the 100 MHz clock, with a 3.4 Ohm peak.
   Clock-synchronous current pulses (assumed peak-to-average 3) then produce about 34 mV of
   dynamic drop on the die grid against a 50 mV allocation, versus only about 4 mV for the
   cycle-averaged wake-up step.  The nominal margin to the 0.90 V library corner is +46 mV, but
   the full-model Monte-Carlo failure probability is about 7.5 % and the all-adverse stack fails.
5. **Cheapest mitigation:** double the VDD_CORE bond-wire/lead pairs (8 -> 16; +8 leads, which
   the QFN-88 has free because VSS is down-bonded to the exposed pad).  This lowers the loop
   inductance and moves the resonance, giving about 26 mV in the lumped clocked model with no
   extra silicon.  Capacitance alone needs about 6x (+1.3 mm^2 of decap cells, two-thirds of the
   core) because intermediate values move the resonance onto 100 MHz and make noise worse -
   the what-if table shows this non-monotonic behaviour.  Damping (decap ESR) and gate-level
   per-cycle current shapes must be confirmed in vectored dynamic-IR signoff.
6. **Package:** QFN-88 is the right first-silicon package (lowest cost, 79/88 leads with the
   10 % spare, adequate PDN/thermal), but chiplet-link SSO fails at the fast-edge (1 ns) corner:
   specify slew-rate-controlled pads and keep at least four VDDIO/VSSIO pairs.  FCBGA is the
   robust fallback at about 25x the unit cost.

### SilicaFlux-X (hypothetical) - does the approach scale?

1. **Wire-bond packages are excluded** on pin count, pad ring, package DC drop, signal rate and
   thermal; FCBGA is the best feasible option but its 324-ball body is full (322 required) - a
   larger body is needed.  Advanced organic and interposer options are feasible; the interposer's
   deep-trench capacitance helps the first droop but its thin-metal DC drop and cost count
   against it.
2. **Wake policy is a package-level decision.**  Waking all 16 tiles in one cycle (2.4 A in 1 ns)
   gives about 40 mV of first droop at 0.8 V; the 8-step stagger (`sf_rst_clk_ctrl`-style) cuts
   the first droop to about 6 mV (10 mV including the second droop).  The package study is evaluated with the staggered step.
3. **On-die decap is the dominant 1 GHz problem.**  About 38 nF against about 41 nF from the per-cycle-charge
   rule (54 nF from the first-droop bound of a simultaneous wake); the VDD_TILE nominal margin is only +15 mV and the Monte-Carlo failure probability is
   about 23-27 % (surrogate / full model).  The decap search needs about 4x (about 150 nF), i.e. deep-trench capacitors
   (interposer or on-die MIM) rather than MOS decap.
4. **Power-virus exposure:** a loop toggling the full tile current at the 238 MHz anti-resonance
   would produce about 250 mV - firmware power-management (activity ramp limits) or droop
   detectors with clock stretching are required for a design of this class.
5. **Thermal:** 3.4 W needs at least a large passive heatsink; natural convection leads to
   leakage-temperature non-convergence in four of the five packages.

### What would change these conclusions

Measured activity (SAIF) and gate-level per-cycle current shapes, the selected PDK's metal,
via, EM, decap and leakage data, OSAT-extracted package models and the PMIC vendor's regulator
model.  Replace them in the configuration files and re-run `scripts/run_all.sh`; every number
above is regenerated with the new provenance tags.

