// ============================================================================
// sf_rst_clk_ctrl.sv - SilicaFlux-V on-chip reset and clock-readiness controller
//
// Lives in the VDD_CORE domain and runs from the reference oscillator clock
// (clk_ref) so that it works before the PLL is locked.  Board hardware (PMIC)
// performs all voltage regulation and rail sequencing; this block only
// observes the board power-good (pg_in) and brown-out warning (bor_n) pads.
//
// Sequence:  RESET -> WAIT_PG (pg stable T_PG_STABLE) -> PLL_START (pll_en,
//   T_PLL_SETTLE, release pll_rst_n) -> WAIT_LOCK (timeout T_LOCK_TIMEOUT,
//   skipped in pll_bypass) -> CLK_SWITCH (clk_sel_pll, T_CLKSW) ->
//   REL_PERIPH -> (T_RST_STAGGER) -> REL_CPU -> RUN
// In RUN, tile clock enables follow tile_req but change at most one tile per
// T_TILE_STAGGER clk_ref cycles, bounding the supply di/dt of tile wake-up
// (see PowerLink transient analysis 'tiles_wake_staggered').
//
// Brown-out: bor_n low asynchronously asserts every output reset (through
// the reset synchronisers' async inputs) and gates tile clocks; the FSM then
// waits for bor_n and pg_in to be stable before a full restart.
// PLL lock loss in RUN or lock timeout -> fault, cool-down, retry (PLL
// restart) up to MAX_RETRIES, then LOCKOUT until por_n is re-asserted.
//
// CDC: clk_ref -> clk_core crossings are synchronised (sf_sync2 for enables,
// sf_rst_sync for resets); tile_req crosses clk_core -> clk_ref via sf_sync2.
// Synthesizable; no initial blocks.
// ============================================================================
module sf_rst_clk_ctrl #(
  parameter int CW              = 16,
  parameter int N_TILES         = 4,
  parameter int T_PG_STABLE     = 64,
  parameter int T_PLL_SETTLE    = 32,
  parameter int T_LOCK_TIMEOUT  = 4096,
  parameter int T_CLKSW         = 16,
  parameter int T_RST_STAGGER   = 8,
  parameter int T_TILE_STAGGER  = 10,
  parameter int T_FAULT_WAIT    = 256,
  parameter int MAX_RETRIES     = 3,
  parameter int FILTER          = 4
) (
  input  logic               clk_ref,
  input  logic               clk_core,
  input  logic               por_n,         // power-on reset (async, active low)
  input  logic               pg_in,         // board power-good (async)
  input  logic               bor_n,         // brown-out warning (async, active low)
  input  logic               pll_lock,      // PLL lock indicator (async)
  input  logic               pll_bypass,    // static strap
  input  logic [N_TILES-1:0] tile_req,      // clk_core domain: requested tile clock state
  output logic               pll_en,
  output logic               pll_rst_n,
  output logic               clk_sel_pll,   // to glitch-free clock mux
  output logic               clk_ready,     // core clock valid and selected
  output logic               periph_rst_n,  // clk_core domain
  output logic               cpu_rst_n,     // clk_core domain
  output logic [N_TILES-1:0] tile_rst_n,    // clk_core domain
  output logic [N_TILES-1:0] tile_clk_en,   // clk_core domain, to tile ICGs
  output logic [3:0]         state_o,
  output logic [3:0]         fault_o,
  output logic [3:0]         retries_o,
  output logic               lockout_o
);
  // ---------------------------------------------------------- conditioning
  logic arst_n;
  assign arst_n = por_n;

  logic pg_ok, bor_ok, lock_ok;
  /* verilator lint_off UNUSEDSIGNAL */
  logic pg_gl, bor_gl, lock_gl;          // glitch pulses: available for debug counters
  /* verilator lint_on UNUSEDSIGNAL */
  sf_pg_filter #(.N(1), .FILTER(FILTER)) u_pg   (.clk(clk_ref), .rst_n(arst_n), .in_raw(pg_in),
                                                 .out_filt(pg_ok), .glitch(pg_gl));
  sf_pg_filter #(.N(1), .FILTER(FILTER)) u_bor  (.clk(clk_ref), .rst_n(arst_n), .in_raw(bor_n),
                                                 .out_filt(bor_ok), .glitch(bor_gl));
  sf_pg_filter #(.N(1), .FILTER(FILTER)) u_lock (.clk(clk_ref), .rst_n(arst_n), .in_raw(pll_lock),
                                                 .out_filt(lock_ok), .glitch(lock_gl));
  logic [N_TILES-1:0] req_ref;
  sf_sync2 #(.N(N_TILES)) u_req (.clk(clk_ref), .rst_n(arst_n), .d(tile_req), .q(req_ref));

  // ---------------------------------------------------------- FSM (clk_ref)
  sf_pwr_pkg::rc_state_e     state;
  sf_pwr_pkg::fault_e        fault;
  logic [CW-1:0] cnt;
  logic [CW-1:0] tcnt;
  logic [3:0]    retries;
  logic          rel_periph, rel_cpu;
  logic [N_TILES-1:0] tile_en_q;

  assign state_o   = state;
  assign fault_o   = fault;
  assign retries_o = retries;
  assign lockout_o = (state == sf_pwr_pkg::RC_LOCKOUT);

  // lowest index where requested and granted tile state differ
  function automatic int first_diff(input logic [N_TILES-1:0] a, input logic [N_TILES-1:0] b);
    first_diff = N_TILES;
    for (int k = N_TILES - 1; k >= 0; k--) if (a[k] != b[k]) first_diff = k;
  endfunction

  always_ff @(posedge clk_ref or negedge arst_n) begin
    if (!arst_n) begin
      state       <= sf_pwr_pkg::RC_RESET;
      fault       <= sf_pwr_pkg::F_NONE;
      cnt         <= '0;
      tcnt        <= '0;
      retries     <= '0;
      pll_en      <= 1'b0;
      pll_rst_n   <= 1'b0;
      clk_sel_pll <= 1'b0;
      clk_ready   <= 1'b0;
      rel_periph  <= 1'b0;
      rel_cpu     <= 1'b0;
      tile_en_q   <= '0;
    end else begin
      // brown-out and power-good loss pre-empt every state except LOCKOUT
      if (state != sf_pwr_pkg::RC_LOCKOUT && state != sf_pwr_pkg::RC_RESET && state != sf_pwr_pkg::RC_WAIT_PG &&
          state != sf_pwr_pkg::RC_BROWNOUT && (!bor_ok || !pg_ok)) begin
        state       <= sf_pwr_pkg::RC_BROWNOUT;
        fault       <= sf_pwr_pkg::F_BROWNOUT;
        rel_periph  <= 1'b0;
        rel_cpu     <= 1'b0;
        tile_en_q   <= '0;
        clk_ready   <= 1'b0;
        clk_sel_pll <= 1'b0;
        pll_rst_n   <= 1'b0;
        cnt         <= '0;
      end else begin
        unique case (state)
          sf_pwr_pkg::RC_RESET: begin
            cnt   <= '0;
            state <= sf_pwr_pkg::RC_WAIT_PG;
          end
          sf_pwr_pkg::RC_WAIT_PG: begin
            if (pg_ok && bor_ok) begin
              if (cnt >= CW'(T_PG_STABLE)) begin
                cnt    <= '0;
                pll_en <= ~pll_bypass;
                state  <= sf_pwr_pkg::RC_PLL_START;
              end else cnt <= cnt + 1'b1;
            end else cnt <= '0;
          end
          sf_pwr_pkg::RC_PLL_START: begin
            if (pll_bypass) begin
              cnt   <= '0;
              state <= sf_pwr_pkg::RC_CLK_SWITCH;
            end else if (cnt >= CW'(T_PLL_SETTLE)) begin
              pll_rst_n <= 1'b1;
              cnt       <= '0;
              state     <= sf_pwr_pkg::RC_WAIT_LOCK;
            end else cnt <= cnt + 1'b1;
          end
          sf_pwr_pkg::RC_WAIT_LOCK: begin
            if (lock_ok) begin
              cnt   <= '0;
              state <= sf_pwr_pkg::RC_CLK_SWITCH;
            end else if (cnt >= CW'(T_LOCK_TIMEOUT)) begin
              fault     <= sf_pwr_pkg::F_PLL_LOCK_TIMEOUT;
              pll_en    <= 1'b0;
              pll_rst_n <= 1'b0;
              cnt       <= '0;
              state     <= sf_pwr_pkg::RC_FAULT_WAIT;
            end else cnt <= cnt + 1'b1;
          end
          sf_pwr_pkg::RC_CLK_SWITCH: begin
            clk_sel_pll <= ~pll_bypass;
            if (cnt >= CW'(T_CLKSW)) begin
              clk_ready <= 1'b1;
              cnt       <= '0;
              state     <= sf_pwr_pkg::RC_REL_PERIPH;
            end else cnt <= cnt + 1'b1;
          end
          sf_pwr_pkg::RC_REL_PERIPH: begin
            rel_periph <= 1'b1;
            if (cnt >= CW'(T_RST_STAGGER)) begin
              cnt   <= '0;
              state <= sf_pwr_pkg::RC_REL_CPU;
            end else cnt <= cnt + 1'b1;
          end
          sf_pwr_pkg::RC_REL_CPU: begin
            rel_cpu <= 1'b1;
            tcnt    <= CW'(T_TILE_STAGGER);
            fault   <= sf_pwr_pkg::F_NONE;
            state   <= sf_pwr_pkg::RC_RUN;
          end
          sf_pwr_pkg::RC_RUN: begin
            if (!pll_bypass && !lock_ok) begin
              fault       <= sf_pwr_pkg::F_PLL_LOCK_LOST;
              rel_periph  <= 1'b0;
              rel_cpu     <= 1'b0;
              tile_en_q   <= '0;
              clk_ready   <= 1'b0;
              clk_sel_pll <= 1'b0;
              pll_en      <= 1'b0;
              pll_rst_n   <= 1'b0;
              cnt         <= '0;
              state       <= sf_pwr_pkg::RC_FAULT_WAIT;
            end else begin
              // di/dt-limited tile clock enable / disable
              if (tcnt < CW'(T_TILE_STAGGER)) tcnt <= tcnt + 1'b1;
              if (tcnt >= CW'(T_TILE_STAGGER) && first_diff(req_ref, tile_en_q) < N_TILES) begin
                tile_en_q[first_diff(req_ref, tile_en_q)] <= req_ref[first_diff(req_ref, tile_en_q)];
                tcnt <= '0;
              end
            end
          end
          sf_pwr_pkg::RC_BROWNOUT: begin
            // hold everything in reset until supplies are back and stable
            if (bor_ok && pg_ok) begin
              if (cnt >= CW'(T_PG_STABLE)) begin
                cnt    <= '0;
                pll_en <= ~pll_bypass;
                state  <= sf_pwr_pkg::RC_PLL_START;
              end else cnt <= cnt + 1'b1;
            end else cnt <= '0;
          end
          sf_pwr_pkg::RC_FAULT_WAIT: begin
            if (cnt >= CW'(T_FAULT_WAIT)) begin
              cnt <= '0;
              if (retries >= 4'(MAX_RETRIES)) begin
                state <= sf_pwr_pkg::RC_LOCKOUT;
              end else begin
                retries <= retries + 1'b1;
                pll_en  <= ~pll_bypass;
                state   <= sf_pwr_pkg::RC_PLL_START;
              end
            end else cnt <= cnt + 1'b1;
          end
          sf_pwr_pkg::RC_LOCKOUT: begin
            pll_en      <= 1'b0;
            pll_rst_n   <= 1'b0;
            clk_sel_pll <= 1'b0;
            clk_ready   <= 1'b0;
            rel_periph  <= 1'b0;
            rel_cpu     <= 1'b0;
            tile_en_q   <= '0;
          end
          default: state <= sf_pwr_pkg::RC_RESET;
        endcase
      end
    end
  end

  // ---------------------------------------------------------- outputs in clk_core domain
  logic core_arst_n;
  assign core_arst_n = por_n & bor_n;           // brown-out asserts resets asynchronously

  sf_rst_sync u_rst_periph (.clk(clk_core), .arst_n(core_arst_n), .release_i(rel_periph), .rst_n(periph_rst_n));
  sf_rst_sync u_rst_cpu    (.clk(clk_core), .arst_n(core_arst_n), .release_i(rel_cpu),    .rst_n(cpu_rst_n));
  genvar g;
  generate
    for (g = 0; g < N_TILES; g++) begin : gen_tile
      sf_rst_sync u_rst_tile (.clk(clk_core), .arst_n(core_arst_n), .release_i(rel_cpu), .rst_n(tile_rst_n[g]));
    end
  endgenerate
  logic [N_TILES-1:0] tile_en_core;
  sf_sync2 #(.N(N_TILES)) u_ten (.clk(clk_core), .rst_n(core_arst_n), .d(tile_en_q), .q(tile_en_core));
  // enable register is asynchronously cleared by brown-out through core_arst_n
  assign tile_clk_en = tile_en_core;
endmodule
