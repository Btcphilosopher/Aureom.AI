// ============================================================================
// tb_sf_rst_clk_ctrl.sv - self-checking testbench for sf_rst_clk_ctrl
//
//   R1 power-on: PG stable -> PLL enable -> lock -> clock switch -> periph
//      reset release -> CPU/tile reset release (order checked)
//   R2 tile clock enables are staggered by >= T_TILE_STAGGER reference cycles
//   R3 brown-out asserts all resets asynchronously and gates tile clocks;
//      recovery repeats the PLL start-up
//   R4 PLL lock loss in RUN -> fault, cool-down, retry, recovery
//   R5 PLL never locks -> lock timeout retries -> LOCKOUT; POR clears it
//   R6 PLL bypass strap: runs from the reference clock without waiting for lock
// ============================================================================
`timescale 1ns/1ps
import sf_pwr_pkg::*;

module tb_sf_rst_clk_ctrl;
  localparam int NT = 4;
  localparam int STAGGER = 10;
  logic clk_ref = 0, clk_core = 0;
  always #20 clk_ref  = ~clk_ref;     // 25 MHz reference oscillator
  always #5  clk_core = ~clk_core;    // 100 MHz core clock (mux output, modelled free-running)

  logic por_n = 0, pg_in = 0, bor_n = 1, pll_lock = 0, pll_bypass = 0;
  logic [NT-1:0] tile_req = '0;
  logic pll_en, pll_rst_n, clk_sel_pll, clk_ready, periph_rst_n, cpu_rst_n, lockout;
  logic [NT-1:0] tile_rst_n, tile_clk_en;
  logic [3:0] state, fault, retries;

  sf_rst_clk_ctrl #(
    .N_TILES(NT), .T_PG_STABLE(16), .T_PLL_SETTLE(8), .T_LOCK_TIMEOUT(200), .T_CLKSW(4),
    .T_RST_STAGGER(4), .T_TILE_STAGGER(STAGGER), .T_FAULT_WAIT(32), .MAX_RETRIES(2), .FILTER(3)
  ) dut (.*, .state_o(state), .fault_o(fault), .retries_o(retries), .lockout_o(lockout));

  // ------------------------------------------------------------- PLL model
  int lock_delay_ns = 2000;
  logic pll_broken = 0;
  always @(posedge pll_rst_n or negedge pll_rst_n or negedge pll_en) begin
    pll_lock = 0;
    if (pll_rst_n && pll_en) begin
      #(lock_delay_ns);
      if (pll_rst_n && pll_en && !pll_broken) pll_lock = 1;
    end
  end

  int errors = 0;
  task automatic check(input bit cond, input string msg);
    if (!cond) begin $display("ERROR: %s (t=%0t state=%0d fault=%0d)", msg, $time, state, fault); errors++; end
    else $display("  ok: %s", msg);
  endtask
  task automatic wait_state(input int s, input int timeout_cycles, input string msg);
    int k;
    k = 0;
    while (k < timeout_cycles && state != s) begin
      @(posedge clk_ref);
      k++;
    end
    check(state == s, msg);
  endtask

  // ------------------------------------------------------------- order monitors
  time t_lock, t_sel, t_periph, t_cpu;
  always @(posedge pll_lock)     t_lock   = $time;
  always @(posedge clk_sel_pll)  t_sel    = $time;
  always @(posedge periph_rst_n) t_periph = $time;
  always @(posedge cpu_rst_n)    t_cpu    = $time;
  time t_tile [NT];
  genvar g;
  generate for (g = 0; g < NT; g++) begin : gen_mon
    always @(posedge tile_clk_en[g]) t_tile[g] = $time;
  end endgenerate

  initial begin
    $dumpfile("tb_sf_rst_clk_ctrl.vcd");
    $dumpvars(0, tb_sf_rst_clk_ctrl);
    #100 por_n = 1;
    // ---------------------------------------------------------------- R1
    $display("R1 power-on reset / clock sequence");
    #200 pg_in = 1;
    wait_state(RC_RUN, 2000, "reached RUN");
    check(t_lock < t_sel, "clock switched only after PLL lock");
    check(t_sel < t_periph && t_periph < t_cpu, "periph reset released before CPU reset");
    check(clk_ready && periph_rst_n && cpu_rst_n && &tile_rst_n, "all resets released, clock ready");
    // ---------------------------------------------------------------- R2
    $display("R2 staggered tile clock enable");
    @(posedge clk_core); tile_req = 4'b1111;
    wait (tile_clk_en == 4'b1111);
    #1;                                   // let the edge monitors record the last enable
    begin
      bit ok;
      ok = 1;
      for (int k = 1; k < NT; k++)
        if (t_tile[k] === 'x || t_tile[k] - t_tile[k-1] < STAGGER * 40) ok = 0;
      check(ok, $sformatf("tile enables spaced >= %0d ref cycles (%0t %0t %0t %0t)", STAGGER,
                          t_tile[0], t_tile[1], t_tile[2], t_tile[3]));
    end
    // ---------------------------------------------------------------- R3
    $display("R3 brown-out");
    #13 bor_n = 0;
    #1;
    check(!periph_rst_n && !cpu_rst_n && tile_rst_n == 0 && tile_clk_en == 0,
          "resets asserted and tile clocks gated asynchronously on brown-out");
    wait_state(RC_BROWNOUT, 20, "FSM in BROWNOUT");
    #400 bor_n = 1;
    wait_state(RC_RUN, 3000, "recovered to RUN after brown-out");
    check(periph_rst_n && cpu_rst_n, "resets released after recovery");
    // ---------------------------------------------------------------- R4
    $display("R4 PLL lock loss");
    force pll_lock = 0;
    wait_state(RC_FAULT_WAIT, 50, "lock loss -> FAULT_WAIT");
    check(fault == F_PLL_LOCK_LOST && !cpu_rst_n && !clk_sel_pll, "fault code, reset asserted, ref clock selected");
    release pll_lock;
    wait_state(RC_RUN, 3000, "retry recovered to RUN");
    check(retries == 1, "retry counted");
    // ---------------------------------------------------------------- R5
    $display("R5 lock timeout -> lockout");
    pll_broken = 1;
    force pll_lock = 0;
    wait_state(RC_LOCKOUT, 5000, "LOCKOUT after lock-timeout retries");
    check(fault == F_PLL_LOCK_TIMEOUT && !cpu_rst_n && !pll_en, "lock-timeout fault, held in reset, PLL off");
    release pll_lock;
    pll_broken = 0;
    // ---------------------------------------------------------------- R6
    $display("R6 POR clears lockout; PLL bypass");
    pll_bypass = 1;
    por_n = 0; #100 por_n = 1;
    wait_state(RC_RUN, 2000, "bypass mode reached RUN");
    check(!pll_en && !clk_sel_pll && clk_ready, "PLL unused in bypass, reference clock selected");
    if (errors == 0) $display("TB_SF_RST_CLK_CTRL: PASS");
    else             $display("TB_SF_RST_CLK_CTRL: FAIL (%0d errors)", errors);
    $finish;
  end
endmodule
