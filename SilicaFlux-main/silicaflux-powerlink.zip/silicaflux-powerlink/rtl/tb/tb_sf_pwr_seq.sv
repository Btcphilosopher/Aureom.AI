// ============================================================================
// tb_sf_pwr_seq.sv - self-checking testbench for sf_pwr_seq
//
// A behavioural PMIC model ramps each rail after its enable and reports PG
// after a programmable delay; tasks inject faults.  Checks:
//   T1 power-up order and PG gating, reset release after all rails good
//   T2 PG glitch shorter than the filter is ignored in RUN
//   T3 brown-out warning: reset asserted, rails kept on, warm restart
//   T4 PG loss in RUN: fault, reverse-order shutdown, cool-down, retry, recovery
//   T5 PG timeout on rail 1 repeatedly -> retries exhausted -> LOCKOUT -> clear
//   T6 over-temperature shutdown
//   T7 graceful power-off: reset first, then rails in reverse order
// ============================================================================
`timescale 1ns/1ps
import sf_pwr_pkg::*;

module tb_sf_pwr_seq;
  localparam int N  = 3;
  localparam int CW = 16;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;                         // 100 MHz AON clock (scaled timing)

  logic pwr_on_req = 0, pwr_off_req = 0, uv_warn_n = 1, ot_n = 1, fault_clear = 0;
  logic [N-1:0] pg_raw;
  logic [N-1:0] rail_en;
  logic sys_pwr_good, sys_rst_n, lockout;
  logic [3:0] state, fault, retries;
  logic [1:0] fault_rail;
  logic [7:0] bo_cnt, gl_cnt;

  sf_pwr_seq #(
    .N_RAILS(N), .CW(CW),
    .T_PG_TIMEOUT({16'd300, 16'd300, 16'd300}),
    .T_STABLE({16'd20, 16'd20, 16'd20}),
    .T_OFF({16'd50, 16'd50, 16'd50}),
    .T_RST_HOLD(16), .T_RST_TO_OFF(8), .T_BO_MAX(200), .T_COOLDOWN(100),
    .T_RETRY_CLEAR(5000), .MAX_RETRIES(2), .FILTER(4)
  ) dut (
    .clk(clk), .rst_n(rst_n), .pwr_on_req(pwr_on_req), .pwr_off_req(pwr_off_req),
    .pg_raw(pg_raw), .uv_warn_n(uv_warn_n), .ot_n(ot_n), .fault_clear(fault_clear),
    .rail_en(rail_en), .sys_pwr_good(sys_pwr_good), .sys_rst_n(sys_rst_n),
    .state_o(state), .fault_o(fault), .fault_rail_o(fault_rail), .retries_o(retries),
    .brownout_count_o(bo_cnt), .glitch_count_o(gl_cnt), .lockout_o(lockout)
  );

  // ------------------------------------------------------------- PMIC model
  int ramp_delay [N];                           // ns from EN to PG
  int fall_delay [N];
  initial begin
    ramp_delay[0] = 60; ramp_delay[1] = 80; ramp_delay[2] = 40;
    fall_delay[0] = 30; fall_delay[1] = 30; fall_delay[2] = 30;
  end
  logic [N-1:0] pg_force_low = '0;              // fault injection
  logic [N-1:0] pg_model;
  // 1 ns time-step model: PG rises ramp_delay ns after EN has been continuously
  // high and falls fall_delay ns after EN has been continuously low.
  int on_ns [N];
  int off_ns [N];
  genvar g;
  generate
    for (g = 0; g < N; g++) begin : gen_pmic
      initial begin pg_model[g] = 1'b0; on_ns[g] = 0; off_ns[g] = 0; end
      always #1 begin
        if (rail_en[g] === 1'b1) begin
          off_ns[g] = 0;
          if (on_ns[g] < ramp_delay[g]) on_ns[g] = on_ns[g] + 1;
          else pg_model[g] = 1'b1;
        end else begin
          on_ns[g] = 0;
          if (off_ns[g] < fall_delay[g]) off_ns[g] = off_ns[g] + 1;
          else pg_model[g] = 1'b0;
        end
      end
    end
  endgenerate
  assign pg_raw = pg_model & ~pg_force_low;

  // ------------------------------------------------------------- order monitor
  int errors = 0;
  int en_time [N];
  int dis_time [N];
  int rst_fall_time;
  always @(posedge rail_en[0]) en_time[0] = $time;
  always @(posedge rail_en[1]) begin
    en_time[1] = $time;
    if (!pg_raw[0]) begin $display("ERROR: rail1 enabled before rail0 PG"); errors++; end
  end
  always @(posedge rail_en[2]) begin
    en_time[2] = $time;
    if (!pg_raw[1]) begin $display("ERROR: rail2 enabled before rail1 PG"); errors++; end
  end
  always @(negedge rail_en[0]) dis_time[0] = $time;
  always @(negedge rail_en[1]) dis_time[1] = $time;
  always @(negedge rail_en[2]) dis_time[2] = $time;
  always @(negedge sys_rst_n) rst_fall_time = $time;
  always @(posedge sys_rst_n) begin
    if (pg_raw !== {N{1'b1}}) begin $display("ERROR: reset released while a rail is not good"); errors++; end
  end

  task automatic check(input bit cond, input string msg);
    if (!cond) begin $display("ERROR: %s (t=%0t state=%0d fault=%0d)", msg, $time, state, fault); errors++; end
    else $display("  ok: %s", msg);
  endtask

  task automatic wait_state(input int s, input int timeout_cycles, input string msg);
    int k;
    k = 0;
    while (k < timeout_cycles && state != s) begin
      @(posedge clk);
      k++;
    end
    check(state == s, msg);
  endtask

  initial begin
    $dumpfile("tb_sf_pwr_seq.vcd");
    $dumpvars(0, tb_sf_pwr_seq);
    repeat (5) @(posedge clk);
    rst_n = 1;
    // ---------------------------------------------------------------- T1
    $display("T1 power-up sequencing");
    pwr_on_req = 1;
    wait_state(PS_RUN, 2000, "reached RUN");
    check(rail_en == 3'b111 && sys_pwr_good && sys_rst_n, "all rails enabled, power good, reset released");
    check(en_time[0] < en_time[1] && en_time[1] < en_time[2], "rails enabled in index order");
    // ---------------------------------------------------------------- T2
    $display("T2 PG glitch filtering");
    pg_force_low[1] = 1; #20; pg_force_low[1] = 0;      // 2 samples < FILTER
    repeat (20) @(posedge clk);
    check(state == PS_RUN, "short PG glitch ignored");
    check(gl_cnt > 0, "glitch counted");
    // ---------------------------------------------------------------- T3
    $display("T3 brown-out warning");
    uv_warn_n = 0;
    wait_state(PS_BROWNOUT, 50, "entered BROWNOUT");
    check(!sys_rst_n && rail_en == 3'b111, "reset asserted, rails kept enabled");
    #300; uv_warn_n = 1;
    wait_state(PS_RUN, 500, "warm restart back to RUN");
    check(bo_cnt == 1, "brown-out event counted");
    // ---------------------------------------------------------------- T4
    $display("T4 PG lost in RUN -> fault shutdown and retry");
    pg_force_low[2] = 1;
    wait_state(PS_SHDN_RST, 50, "fault shutdown started");
    check(fault == F_PG_LOST && fault_rail == 2, "fault = PG_LOST on rail 2");
    pg_force_low[2] = 0;
    wait_state(PS_COOLDOWN, 2000, "cool-down after shutdown");
    check(dis_time[2] <= dis_time[1] && dis_time[1] <= dis_time[0], "rails disabled in reverse order");
    check(rst_fall_time <= dis_time[2], "reset asserted before first rail disabled");
    wait_state(PS_RUN, 3000, "automatic retry reached RUN");
    check(retries == 1, "retry counted");
    // ---------------------------------------------------------------- T5
    $display("T5 repeated PG timeout -> lockout");
    pwr_on_req = 0;
    wait_state(PS_OFF, 2000, "graceful off before T5");
    ramp_delay[1] = 100000;                               // rail 1 never comes up
    pwr_on_req = 1;
    wait_state(PS_LOCKOUT, 20000, "LOCKOUT after retries exhausted");
    check(fault == F_PG_TIMEOUT && fault_rail == 1, "fault = PG_TIMEOUT on rail 1");
    check(rail_en == 3'b000 && !sys_rst_n, "all rails off and reset held in LOCKOUT");
    ramp_delay[1] = 80;
    @(posedge clk); #1 fault_clear = 1; repeat (2) @(posedge clk); #1 fault_clear = 0;
    wait_state(PS_RUN, 3000, "fault_clear then power-up to RUN");
    // ---------------------------------------------------------------- T6
    $display("T6 over-temperature");
    ot_n = 0;
    wait_state(PS_SHDN_RST, 50, "over-temperature shutdown");
    check(fault == F_OVERTEMP, "fault = OVERTEMP");
    wait_state(PS_COOLDOWN, 2000, "cool-down");
    #500;
    check(state == PS_COOLDOWN && rail_en == 3'b000, "no restart while over-temperature persists");
    ot_n = 1;
    wait_state(PS_RUN, 3000, "restart after temperature recovers");
    // ---------------------------------------------------------------- T7
    $display("T7 graceful power-off");
    pwr_off_req = 1;
    wait_state(PS_OFF, 3000, "graceful power-off reached OFF");
    check(rst_fall_time <= dis_time[2] && dis_time[2] <= dis_time[1] && dis_time[1] <= dis_time[0],
          "reset first, then rails in reverse order");
    check(fault == F_NONE, "no fault after graceful power-off");
    // ---------------------------------------------------------------- done
    if (errors == 0) $display("TB_SF_PWR_SEQ: PASS");
    else             $display("TB_SF_PWR_SEQ: FAIL (%0d errors)", errors);
    $finish;
  end
endmodule
