// ============================================================================
// sf_pwr_pkg.sv - shared types for SilicaFlux power sequencing / reset control
//
// Part of SilicaFlux PowerLink.  See docs/POWER_SEQUENCING_SPEC.md.
// ============================================================================
package sf_pwr_pkg;

  // -------- rail sequencer (sf_pwr_seq) states ----------------------------
  typedef enum logic [3:0] {
    PS_OFF        = 4'd0,
    PS_RAMP       = 4'd1,   // rail enabled, waiting for its power-good
    PS_STABLE     = 4'd2,   // power-good seen, waiting stabilisation time
    PS_RST_HOLD   = 4'd3,   // all rails good, holding system reset
    PS_RUN        = 4'd4,
    PS_BROWNOUT   = 4'd5,   // under-voltage warning: reset held, rails kept on
    PS_SHDN_RST   = 4'd6,   // shutdown: assert reset first
    PS_SHDN_RAIL  = 4'd7,   // shutdown: disable one rail (reverse order)
    PS_SHDN_WAIT  = 4'd8,   // shutdown: wait for rail discharge
    PS_COOLDOWN   = 4'd9,   // after a fault, before retry
    PS_LOCKOUT    = 4'd10   // retries exhausted, needs fault_clear
  } pseq_state_e;

  // -------- reset / clock controller (sf_rst_clk_ctrl) states ------------
  typedef enum logic [3:0] {
    RC_RESET      = 4'd0,
    RC_WAIT_PG    = 4'd1,
    RC_PLL_START  = 4'd2,
    RC_WAIT_LOCK  = 4'd3,
    RC_CLK_SWITCH = 4'd4,
    RC_REL_PERIPH = 4'd5,
    RC_REL_CPU    = 4'd6,
    RC_RUN        = 4'd7,
    RC_BROWNOUT   = 4'd8,
    RC_FAULT_WAIT = 4'd9,
    RC_LOCKOUT    = 4'd10
  } rc_state_e;

  // -------- fault codes (latched until cleared / next successful run) ----
  typedef enum logic [3:0] {
    F_NONE             = 4'd0,
    F_PG_TIMEOUT       = 4'd1,  // rail did not reach power-good in time
    F_PG_LOST          = 4'd2,  // power-good dropped after being good
    F_BROWNOUT_TIMEOUT = 4'd3,  // under-voltage warning persisted too long
    F_OVERTEMP         = 4'd4,
    F_PLL_LOCK_TIMEOUT = 4'd5,
    F_PLL_LOCK_LOST    = 4'd6,
    F_BROWNOUT         = 4'd7   // brown-out event (recoverable) - informational
  } fault_e;

endpackage
