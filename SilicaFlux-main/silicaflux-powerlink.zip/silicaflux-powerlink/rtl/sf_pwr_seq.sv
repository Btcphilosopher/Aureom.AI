// ============================================================================
// sf_pwr_seq.sv - N-rail power sequencer (always-on domain or board CPLD)
//
// Placement:
//   * SilicaFlux-V (single core domain): the board PMIC performs regulation
//     and its built-in sequencer, or a board CPLD running this module, drives
//     the rail enables.  The chip itself contains sf_rst_clk_ctrl only.
//   * Future variants with an always-on (AON) domain: instantiate in the AON
//     domain to drive PMIC enables / on-die power-switch controls.
//
// Behaviour (see docs/POWER_SEQUENCING_SPEC.md for timing tables):
//   power-up    rail 0..N-1 enabled in index order; rail k+1 is enabled only
//               after PG[k] is good (debounced) and stable for T_STABLE[k];
//               PG[k] must arrive within T_PG_TIMEOUT[k] of EN[k].
//   reset       sys_rst_n held low for T_RST_HOLD after all rails are good.
//   brown-out   uv_warn_n (early under-voltage warning, above PG threshold)
//               during RUN asserts sys_rst_n immediately while rails stay on;
//               recovery within T_BO_MAX -> warm restart, else fault shutdown.
//   faults      PG timeout, PG loss, brown-out timeout, over-temperature ->
//               reset asserted, rails disabled in REVERSE order with T_OFF[k]
//               discharge wait, cool-down T_COOLDOWN, automatic retry up to
//               MAX_RETRIES, then LOCKOUT until fault_clear.
//   retry count is cleared after T_RETRY_CLEAR cycles of uninterrupted RUN.
//
// All timing parameters are in clk cycles of the always-on clock.
// Synthesizable; no initial blocks; asynchronous active-low reset.
// ============================================================================
module sf_pwr_seq #(
  parameter int N_RAILS        = 3,
  parameter int CW             = 16,
  parameter logic [N_RAILS*CW-1:0] T_PG_TIMEOUT = {N_RAILS{16'd2000}},
  parameter logic [N_RAILS*CW-1:0] T_STABLE     = {N_RAILS{16'd100}},
  parameter logic [N_RAILS*CW-1:0] T_OFF        = {N_RAILS{16'd200}},
  parameter int T_RST_HOLD     = 64,
  parameter int T_RST_TO_OFF   = 16,
  parameter int T_BO_MAX       = 1000,
  parameter int T_COOLDOWN     = 1000,
  parameter int T_RETRY_CLEAR  = 10000,
  parameter int MAX_RETRIES    = 3,
  parameter int FILTER         = 4
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 pwr_on_req,      // level: request system power
  input  logic                 pwr_off_req,     // level: graceful power-down
  input  logic [N_RAILS-1:0]   pg_raw,          // power-good from PMIC/supervisors (async)
  input  logic                 uv_warn_n,       // early under-voltage warning (async, active low)
  input  logic                 ot_n,            // over-temperature (async, active low)
  input  logic                 fault_clear,     // leave LOCKOUT
  output logic [N_RAILS-1:0]   rail_en,
  output logic                 sys_pwr_good,
  output logic                 sys_rst_n,
  output logic [3:0]           state_o,
  output logic [3:0]           fault_o,
  output logic [$clog2(N_RAILS+1)-1:0] fault_rail_o,
  output logic [3:0]           retries_o,
  output logic [7:0]           brownout_count_o,
  output logic [7:0]           glitch_count_o,
  output logic                 lockout_o
);
  localparam int RW = (N_RAILS < 2) ? 1 : $clog2(N_RAILS);
  localparam int FW = $clog2(N_RAILS + 1);

  // ---------------------------------------------------------- input conditioning
  logic [N_RAILS-1:0] pg, pg_glitch;
  logic uv_ok, ot_ok;
  /* verilator lint_off UNUSEDSIGNAL */
  logic uv_glitch, ot_glitch;            // available for debug/status; not used by the FSM
  /* verilator lint_on UNUSEDSIGNAL */
  sf_pg_filter #(.N(N_RAILS), .FILTER(FILTER)) u_pgf
    (.clk(clk), .rst_n(rst_n), .in_raw(pg_raw), .out_filt(pg), .glitch(pg_glitch));
  sf_pg_filter #(.N(1), .FILTER(FILTER), .RESET_VAL(1'b1)) u_uvf
    (.clk(clk), .rst_n(rst_n), .in_raw(uv_warn_n), .out_filt(uv_ok), .glitch(uv_glitch));
  sf_pg_filter #(.N(1), .FILTER(FILTER), .RESET_VAL(1'b1)) u_otf
    (.clk(clk), .rst_n(rst_n), .in_raw(ot_n), .out_filt(ot_ok), .glitch(ot_glitch));

  // ---------------------------------------------------------- helpers
  function automatic logic [CW-1:0] tsel(input logic [N_RAILS*CW-1:0] v, input logic [RW-1:0] i);
    tsel = v[i*CW +: CW];
  endfunction

  // first rail (lowest index) among 'mask' whose filtered PG is low
  function automatic logic [FW-1:0] first_low(input logic [N_RAILS-1:0] pgv,
                                               input logic [N_RAILS-1:0] mask);
    first_low = FW'(N_RAILS);
    for (int k = N_RAILS - 1; k >= 0; k--) begin
      if (mask[k] && !pgv[k]) first_low = FW'(k);
    end
  endfunction

  // mask of rails strictly below index i
  function automatic logic [N_RAILS-1:0] below(input logic [RW-1:0] i);
    below = '0;
    for (int k = 0; k < N_RAILS; k++) if (k < {{(32-RW){1'b0}}, i}) below[k] = 1'b1;
  endfunction

  // ---------------------------------------------------------- state
  sf_pwr_pkg::pseq_state_e state;
  logic [RW-1:0] idx;
  logic [CW-1:0] cnt;
  logic [31:0]   run_cnt;
  logic [3:0]    retries;
  sf_pwr_pkg::fault_e        fault;
  logic [FW-1:0] fault_rail;
  logic          shdn_fault;     // current shutdown caused by a fault
  logic [7:0]    bo_count, gl_count;

  assign state_o          = state;
  assign fault_o          = fault;
  assign fault_rail_o     = fault_rail;
  assign retries_o        = retries;
  assign lockout_o        = (state == sf_pwr_pkg::PS_LOCKOUT);
  assign brownout_count_o = bo_count;
  assign glitch_count_o   = gl_count;

  logic [N_RAILS-1:0] all_mask;
  assign all_mask = {N_RAILS{1'b1}};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state        <= sf_pwr_pkg::PS_OFF;
      idx          <= '0;
      cnt          <= '0;
      run_cnt      <= '0;
      retries      <= '0;
      fault        <= sf_pwr_pkg::F_NONE;
      fault_rail   <= FW'(N_RAILS);
      shdn_fault   <= 1'b0;
      rail_en      <= '0;
      sys_pwr_good <= 1'b0;
      sys_rst_n    <= 1'b0;
      bo_count     <= '0;
      gl_count     <= '0;
    end else begin
      if ((|pg_glitch) && gl_count != 8'hFF) gl_count <= gl_count + 1'b1;
      unique case (state)
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_OFF: begin
          rail_en      <= '0;
          sys_rst_n    <= 1'b0;
          sys_pwr_good <= 1'b0;
          if (pwr_on_req && !pwr_off_req && ot_ok) begin
            idx        <= '0;
            cnt        <= '0;
            rail_en[0] <= 1'b1;
            state      <= sf_pwr_pkg::PS_RAMP;
          end
        end
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_RAMP: begin
          if (!ot_ok) begin
            fault <= sf_pwr_pkg::F_OVERTEMP; shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (first_low(pg, below(idx)) != FW'(N_RAILS)) begin
            fault <= sf_pwr_pkg::F_PG_LOST; fault_rail <= first_low(pg, below(idx));
            shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (pg[idx]) begin
            cnt   <= '0;
            state <= sf_pwr_pkg::PS_STABLE;
          end else if (cnt >= tsel(T_PG_TIMEOUT, idx)) begin
            fault <= sf_pwr_pkg::F_PG_TIMEOUT; fault_rail <= FW'(idx);
            shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_STABLE: begin
          if (!ot_ok) begin
            fault <= sf_pwr_pkg::F_OVERTEMP; shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (first_low(pg, below(idx) | (N_RAILS'(1) << idx)) != FW'(N_RAILS)) begin
            fault <= sf_pwr_pkg::F_PG_LOST; fault_rail <= first_low(pg, below(idx) | (N_RAILS'(1) << idx));
            shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (cnt >= tsel(T_STABLE, idx)) begin
            cnt <= '0;
            if (idx == RW'(N_RAILS - 1)) begin
              sys_pwr_good <= 1'b1;
              state        <= sf_pwr_pkg::PS_RST_HOLD;
            end else begin
              idx              <= idx + 1'b1;
              rail_en[idx + 1] <= 1'b1;
              state            <= sf_pwr_pkg::PS_RAMP;
            end
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_RST_HOLD: begin
          sys_rst_n <= 1'b0;
          if (first_low(pg, all_mask) != FW'(N_RAILS)) begin
            fault <= sf_pwr_pkg::F_PG_LOST; fault_rail <= first_low(pg, all_mask);
            shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (cnt >= CW'(T_RST_HOLD)) begin
            sys_rst_n <= 1'b1;
            run_cnt   <= '0;
            state     <= sf_pwr_pkg::PS_RUN;
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_RUN: begin
          if (run_cnt < T_RETRY_CLEAR) run_cnt <= run_cnt + 1;
          else retries <= '0;
          if (pwr_off_req || !pwr_on_req) begin
            shdn_fault <= 1'b0; sys_rst_n <= 1'b0; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (!ot_ok) begin
            fault <= sf_pwr_pkg::F_OVERTEMP; shdn_fault <= 1'b1; sys_rst_n <= 1'b0; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (first_low(pg, all_mask) != FW'(N_RAILS)) begin
            fault <= sf_pwr_pkg::F_PG_LOST; fault_rail <= first_low(pg, all_mask);
            shdn_fault <= 1'b1; sys_rst_n <= 1'b0; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (!uv_ok) begin
            sys_rst_n <= 1'b0;          // protect state immediately; rails stay enabled
            fault     <= sf_pwr_pkg::F_BROWNOUT;
            if (bo_count != 8'hFF) bo_count <= bo_count + 1'b1;
            cnt       <= '0;
            state     <= sf_pwr_pkg::PS_BROWNOUT;
          end
        end
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_BROWNOUT: begin
          sys_rst_n <= 1'b0;
          if (first_low(pg, all_mask) != FW'(N_RAILS)) begin
            fault <= sf_pwr_pkg::F_PG_LOST; fault_rail <= first_low(pg, all_mask);
            shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else if (uv_ok) begin
            cnt   <= '0;
            state <= sf_pwr_pkg::PS_RST_HOLD;       // warm restart through the reset hold time
          end else if (cnt >= CW'(T_BO_MAX)) begin
            fault <= sf_pwr_pkg::F_BROWNOUT_TIMEOUT; shdn_fault <= 1'b1; cnt <= '0; state <= sf_pwr_pkg::PS_SHDN_RST;
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_SHDN_RST: begin
          sys_rst_n    <= 1'b0;
          sys_pwr_good <= 1'b0;
          if (cnt >= CW'(T_RST_TO_OFF)) begin
            cnt   <= '0;
            state <= sf_pwr_pkg::PS_SHDN_RAIL;
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
        sf_pwr_pkg::PS_SHDN_RAIL: begin
          rail_en[idx] <= 1'b0;
          cnt          <= '0;
          state        <= sf_pwr_pkg::PS_SHDN_WAIT;
        end
        sf_pwr_pkg::PS_SHDN_WAIT: begin
          if (!pg[idx] || cnt >= tsel(T_OFF, idx)) begin
            cnt <= '0;
            if (idx == '0) begin
              state <= shdn_fault ? sf_pwr_pkg::PS_COOLDOWN : sf_pwr_pkg::PS_OFF;
              if (!shdn_fault) fault <= sf_pwr_pkg::F_NONE;
            end else begin
              idx   <= idx - 1'b1;
              state <= sf_pwr_pkg::PS_SHDN_RAIL;
            end
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
        // ------------------------------------------------------------------
        sf_pwr_pkg::PS_COOLDOWN: begin
          rail_en <= '0;
          if (cnt >= CW'(T_COOLDOWN)) begin
            cnt <= '0;
            if (retries >= 4'(MAX_RETRIES)) begin
              state <= sf_pwr_pkg::PS_LOCKOUT;
            end else if (ot_ok && pwr_on_req && !pwr_off_req) begin
              retries    <= retries + 1'b1;
              shdn_fault <= 1'b0;
              idx        <= '0;
              rail_en[0] <= 1'b1;
              state      <= sf_pwr_pkg::PS_RAMP;
            end else if (!pwr_on_req || pwr_off_req) begin
              state <= sf_pwr_pkg::PS_OFF;
            end
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
        sf_pwr_pkg::PS_LOCKOUT: begin
          rail_en      <= '0;
          sys_rst_n    <= 1'b0;
          sys_pwr_good <= 1'b0;
          if (fault_clear) begin
            retries    <= '0;
            fault      <= sf_pwr_pkg::F_NONE;
            fault_rail <= FW'(N_RAILS);
            shdn_fault <= 1'b0;
            state      <= sf_pwr_pkg::PS_OFF;
          end
        end
        default: state <= sf_pwr_pkg::PS_OFF;
      endcase
    end
  end
endmodule
