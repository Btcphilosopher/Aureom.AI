// ============================================================================
// sf_sync.sv - synchronisers and filters used by the power-sequencing logic
//
//   sf_sync2      : N-bit two-flop synchroniser (asynchronous inputs)
//   sf_rst_sync   : reset synchroniser, asynchronous assert / synchronous release
//   sf_pg_filter  : synchronise + debounce power-good style signals; a change is
//                   accepted only after FILTER consecutive identical samples;
//                   shorter excursions are reported on 'glitch' and ignored.
//
// In an ASIC flow the first stage of each synchroniser should be mapped to the
// library's dedicated synchroniser cell (or constrained with a CDC
// set_false_path/max_delay and checked by a CDC tool).
// ============================================================================
module sf_sync2 #(
  parameter int N = 1,
  parameter logic [N-1:0] RESET_VAL = '0
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] d,
  output logic [N-1:0] q
);
  logic [N-1:0] meta;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      meta <= RESET_VAL;
      q    <= RESET_VAL;
    end else begin
      meta <= d;
      q    <= meta;
    end
  end
endmodule

module sf_rst_sync #(
  parameter int STAGES = 2
) (
  input  logic clk,
  input  logic arst_n,     // asynchronous assertion (active low)
  input  logic release_i,  // synchronous release request (1 = allow reset release)
  output logic rst_n       // synchronised reset for the clk domain
);
  logic [STAGES-1:0] sh;
  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) sh <= '0;
    else         sh <= {sh[STAGES-2:0], release_i};
  end
  assign rst_n = sh[STAGES-1];
endmodule

module sf_pg_filter #(
  parameter int N      = 1,
  parameter int FILTER = 4,                 // samples (>= 1)
  parameter logic [N-1:0] RESET_VAL = '0
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] in_raw,
  output logic [N-1:0] out_filt,
  output logic [N-1:0] glitch               // one-cycle pulse: excursion shorter than FILTER
);
  localparam int CW = (FILTER < 2) ? 1 : $clog2(FILTER + 1);
  logic [N-1:0] in_s;
  sf_sync2 #(.N(N), .RESET_VAL(RESET_VAL)) u_sync (.clk(clk), .rst_n(rst_n), .d(in_raw), .q(in_s));

  genvar g;
  generate
    for (g = 0; g < N; g++) begin : gen_bit
      logic [CW-1:0] cnt;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          cnt         <= '0;
          out_filt[g] <= RESET_VAL[g];
          glitch[g]   <= 1'b0;
        end else begin
          glitch[g] <= 1'b0;
          if (in_s[g] == out_filt[g]) begin
            if (cnt != '0) glitch[g] <= 1'b1;   // excursion ended before acceptance
            cnt <= '0;
          end else if (cnt == CW'(FILTER - 1)) begin
            out_filt[g] <= in_s[g];
            cnt         <= '0;
          end else begin
            cnt <= cnt + 1'b1;
          end
        end
      end
    end
  endgenerate
endmodule
