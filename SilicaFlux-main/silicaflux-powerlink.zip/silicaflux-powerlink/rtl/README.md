# Power-sequencing RTL

Synthesizable SystemVerilog (IEEE 1800-2012 subset accepted by Icarus 12, Verilator 5 and Yosys 0.33).

| File | Module(s) | Purpose |
|---|---|---|
| `sf_pwr_pkg.sv` | `sf_pwr_pkg` | state and fault-code enums |
| `sf_sync.sv` | `sf_sync2`, `sf_rst_sync`, `sf_pg_filter` | 2-FF synchroniser, async-assert/sync-release reset synchroniser, PG debounce/glitch filter |
| `sf_pwr_seq.sv` | `sf_pwr_seq` | N-rail sequencer for an always-on domain or a board CPLD: ordered enable with PG gating and timeouts, reset hold, brown-out handling, reverse-order fault shutdown, cool-down, retry, lockout |
| `sf_rst_clk_ctrl.sv` | `sf_rst_clk_ctrl` | SilicaFlux-V on-chip controller: PG/BOR qualification, PLL enable/lock/timeout, glitch-free clock-select, staggered reset release, di/dt-limited tile clock enables, brown-out async reset, lock-loss retry |
| `tb/tb_sf_pwr_seq.sv` | testbench | behavioural PMIC model, 7 self-checking scenarios |
| `tb/tb_sf_rst_clk_ctrl.sv` | testbench | PLL model, 6 self-checking scenarios |
| `filelist.f` | | synthesizable sources |

```bash
bash scripts/sim_rtl.sh     # iverilog + vvp, prints PASS/FAIL per testbench
bash scripts/lint_rtl.sh    # verilator --lint-only -Wall
bash scripts/synth_rtl.sh   # yosys generic synthesis, check -assert, cell statistics
```

Specification: `docs/POWER_SEQUENCING_SPEC.md`.  The board PMIC performs all regulation.
