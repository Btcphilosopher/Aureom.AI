# SilicaFlux PowerLink

**Semiconductor power integrity, package modelling and power-delivery optimisation for
SilicaFlux-V and future SilicaFlux processors.**

PowerLink is a reproducible power/package/PCB co-design toolkit.  From one set of YAML
configuration files it models the complete power-delivery path

```
external supply -> PCB regulator -> PCB planes -> package balls/leads -> package distribution
                -> bond wires / bumps -> on-die power grid -> compute and memory cells
```

for every supply rail, and answers one question with stated assumptions and uncertainty:
*are the proposed rails, package and PCB realistic?*

It contains working Python models with unit tests and ngspice cross-checks, synthesizable
SystemVerilog sequencing logic with self-checking testbenches, generated OpenROAD PDN
scripts and UPF, generated figures and reports, and engineering documentation.

> **Scope and honesty.**  Every technology, package and activity number is a planning value
> tagged with its provenance (`assumption`, `literature`, `datasheet`, ...).  No PDK has
> been selected, so no DRC correctness is asserted for the generated scripts.  No switching
> activity has been measured; workload activities are assumptions until SAIF/VCD is
> attached.  Results show where signoff effort is needed; they are not signoff results
> (see `docs/VALIDATION_AND_SIGNOFF.md`).

## Quick start

```bash
pip install -r requirements.txt          # numpy, scipy, matplotlib, PyYAML, pytest
```

```bash
python3 -m powerlink run --chip configs/chips/silicaflux_v.yaml --out results/silicaflux_v
```

```bash
bash scripts/run_all.sh                  # everything: tests, RTL sim/lint/synth, OpenROAD, both chips
```

Optional tools, used automatically when present: `ngspice` (solver cross-checks),
`iverilog` (RTL simulation), `verilator` (lint), `yosys` (synthesis check), `tclsh`
(OpenROAD script syntax check).

Other commands: `power`, `ir`, `packages`, `openroad`, `activity` (VCD/SAIF import),
`thermal-import` (specialist thermal maps), `crosscheck`, `assumptions` - see
`python3 -m powerlink -h`.

## What is modelled

| Area | Implementation |
|---|---|
| Circuit engine | sparse MNA (DC/AC/transient, trapezoidal with exact algebraic rows), SPICE export, ngspice runner |
| DC drop, path resistance, current density | multi-layer homogenised on-die grid (rings, straps, followpins, via stacks, macro pins), PCB planes, package pins, bond wires/bumps; per-layer current density and EM screening |
| Load distribution, local voltage variation | floorplan block currents mapped onto the grid; IR and dynamic-drop heat maps |
| Dynamic current demand, transient droop | workload events (simultaneous / staggered wake, bursts, release), clock-synchronous pulse currents, resonant workloads; first/second/third droop |
| Decoupling networks | MLCC/polymer/land-side/interposer-trench capacitors with ESR/ESL/mounting/DC-bias derating; first-droop bound; decap what-ifs; PCB decap optimiser |
| Package parasitics | bond-wire loop inductance (Grover), plane-pair, via and spreading inductance, package-family library |
| Regulator response | averaged peak-current-mode buck with type-II compensation (crossover refined numerically, loop gain, phase margin), ripple, slew; LDO output impedance and PSRR |
| PI margins | setpoint + ripple + static IR + dynamic per rail; worst-case, RSS and Monte-Carlo (surrogate + full-model subset) |
| Dynamic / leakage power | P = alpha C V^2 f per block, clock gating, SRAM energy per access, I/O power; leakage(T, V) separate and technology-dependent; six workload profiles; VCD/SAIF import |
| Thermal | compact theta_ja networks per package/cooling, Lee-Song-Au-Moran spreading, 2-D die conduction on power maps, leakage-temperature fixed point, CSV import of specialist maps |
| Package comparison | wire-bond QFN, wire-bond BGA, flip-chip BGA, advanced organic, silicon interposer vs I/O count, current, SI, SSO, thermal, cost |
| On-die PDN config | rings, straps, layers, VDD/VSS grids, macro pins, SRAM/CPU/vector/tensor regions, decap regions, voltage domains |
| OpenROAD | `pdngen` Tcl for a generic 65 nm stack plus sky130/gf180mcu flow vehicles; UPF for multi-domain variants |
| Power sequencing | `sf_pwr_seq` (N-rail sequencer, brown-out, fault shutdown, retry/lockout) and `sf_rst_clk_ctrl` (POR/PG, PLL lock, clock readiness, staggered tile clock enable, reset release) |
| Reports | IR-drop and current-density heat maps, voltage-domain diagram, PDN path diagram, impedance and Bode plots, supply-noise and droop plots, power reports, package and cooling comparisons, margin waterfalls, Monte-Carlo histograms, risk matrix; Markdown + self-contained HTML |

## Chips analysed

* **SilicaFlux-V**: the first-silicon target from the SilicaFlux design documents
  (65 nm, 100 MHz, 2x2 compute tiles around a control spine, 2.5 mm pad-limited die,
  single core domain, PLL on an isolated analogue supply, QFN-88 baseline).
* **SilicaFlux-X**: a **hypothetical** future-variant scenario (28 nm, 1 GHz, 16 tiles,
  five rails, flip-chip baseline) used to test how the approach scales and to exercise
  flip-chip, advanced-organic and interposer options.  Generated by `scripts/gen_silicaflux_x.py`.

## Headline findings (SilicaFlux-V, from `FINDINGS.md`)

* **DC and thermal are comfortable**: ~5 mV worst static IR drop (0.5 %), EM below 10 % of
  the screening limits, T_j ~74 C at 70 C ambient in the QFN-88 without a heatsink.
* **I/O dominates power**: ~172 mW total at the stress bound, ~126 mW of it the 3.3 V LVCMOS
  chiplet link; the core needs ~44 mA.
* **Cycle-level noise is the real PI risk**: the bond-wire/lead inductance (~345 pH) against
  ~1.8 nF of on-die capacitance resonates near 2 x f_clk, giving ~34 mV of dynamic drop against
  a 50 mV allocation.  Nominal margin is +46 mV, but the full-model Monte-Carlo failure
  probability is ~7.5 % under the stated assumptions.
* **Cheapest fix found**: double the VDD_CORE bond-wire/lead pairs (+8 of 17 free leads; VSS
  is down-bonded to the exposed pad), which brings the dynamic term to ~26 mV with no extra
  silicon.  Capacitance alone would need ~6x (+1.3 mm^2).
* **Package**: QFN-88 remains the best first-silicon choice; chiplet-link SSO needs
  slew-controlled pads.  FCBGA is the robust fallback at ~25x the unit cost.
* The hypothetical 28 nm / 1 GHz SilicaFlux-X needs flip-chip (in a larger body than 324
  balls), staggered tile wake and roughly 4x more on-die decoupling (deep-trench class).

## Results

`results/<chip>/report.html` (self-contained) and `REPORT.md`, with `figures/`, CSV tables,
`summary.json` and `manifest.json` (input hashes and tool versions).  A cross-chip summary of
the findings is in `FINDINGS.md`.

## Repository layout

See `docs/ARCHITECTURE.md`.  Documentation index:

| Document | Content |
|---|---|
| `docs/ARCHITECTURE.md` | physical system, software layout, data flow, config files, reproducibility |
| `docs/MODELLING.md` | equations and abstractions of every electrical model, and their limits |
| `docs/POWER_AND_ACTIVITY.md` | dynamic/leakage power, workloads, VCD/SAIF workflow |
| `docs/THERMAL.md` | thermal networks, die solver, coupling, import format |
| `docs/PACKAGE_COMPARISON.md` | package options, constraints and scoring |
| `docs/ONDIE_PDN_AND_OPENROAD.md` | on-die PDN schema, checks, OpenROAD/UPF generation |
| `docs/POWER_SEQUENCING_SPEC.md` | power-up controller specification and RTL verification |
| `docs/VALIDATION_AND_SIGNOFF.md` | unit tests, ngspice cross-checks, required commercial signoff experiments |
