"""MNA solver against closed-form circuit solutions and ngspice."""
import math

import numpy as np
import pytest

from powerlink.circuit.mna import PWL, Circuit
from powerlink.circuit.spice import ngspice_available, run_ngspice, spice_node


def test_divider_dc_exact():
    c = Circuit()
    c.add_V("a", "0", dc=1.2, name="vs")
    c.add_R("a", "b", 3e3)
    c.add_R("b", "0", 1e3)
    sol = c.dc()
    assert sol.v("b") == pytest.approx(0.3, rel=1e-9)
    # SPICE convention: branch current flows into the + terminal; 1e-12 S gmin per node limits exactness
    assert sol.i("vs") == pytest.approx(-1.2 / 4e3, rel=1e-7)


def test_kcl_random_network_current_conservation():
    rng = np.random.default_rng(0)
    c = Circuit()
    n = c.new_nodes(30)
    for k in range(29):
        c.add_R(int(n[k]), int(n[k + 1]), float(rng.uniform(1, 10)))
    for _ in range(40):
        a, b = rng.choice(n, 2, replace=False)
        c.add_R(int(a), int(b), float(rng.uniform(1, 100)))
    c.add_V(int(n[0]), "0", dc=1.0, name="vs")
    loads = rng.uniform(1e-3, 5e-3, 10)
    for k, i in zip(n[10:20], loads):
        c.add_I(int(k), "0", dc=float(i))
    sol = c.dc()
    assert -sol.i("vs") == pytest.approx(loads.sum(), rel=1e-6)


def test_rc_step_matches_exponential():
    tau = 1e-6
    c = Circuit()
    c.add_V("in", "0", dc=0.0, wave=PWL([0, 1e-12, 1.0], [0, 1, 1]), name="v")
    c.add_R("in", "out", 1e3)
    c.add_C("out", "0", 1e-9)
    r = c.tran([(5e-6, 2e-9)], probes=["out"])
    ana = 1 - np.exp(-r.t / tau)
    assert np.max(np.abs(r["out"] - ana)) < 2e-3


def test_trapezoidal_second_order_convergence():
    """Smooth sinusoidal drive of an RC low-pass (analytic solution known):
    halving the step must cut the error ~4x for trapezoidal and ~2x for backward Euler."""
    R, C = 1e3, 1e-9
    tau = R * C
    w = 1.0 / tau

    def exact(t):
        x = w * tau
        return (math.sin(w * t) - x * math.cos(w * t) + x * math.exp(-t / tau)) / (1 + x * x)

    def err(dt, method):
        c = Circuit()
        c.add_V("in", "0", dc=0.0, wave=lambda t: math.sin(w * t), name="v")
        c.add_R("in", "out", R)
        c.add_C("out", "0", C)
        r = c.tran([(3e-6, dt)], probes=["out"], method=method)
        return abs(r["out"][-1] - exact(3e-6))

    tr = err(40e-9, "trap") / err(20e-9, "trap")
    be = err(40e-9, "be") / err(20e-9, "be")
    assert tr == pytest.approx(4.0, rel=0.15)
    assert be == pytest.approx(2.0, rel=0.15)


def test_series_rlc_underdamped_step():
    R, L, C = 0.05, 1e-9, 1e-9
    c = Circuit()
    c.add_V("s", "0", dc=0.0, wave=PWL([0, 1e-13, 1.0], [0, 1, 1]), name="v")
    c.add_R("s", "a", R)
    c.add_L("a", "b", L, name="l")
    c.add_C("b", "0", C)
    r = c.tran([(100e-9, 5e-12)], probes=["b"])
    a = R / (2 * L)
    w0 = 1 / math.sqrt(L * C)
    wd = math.sqrt(w0 ** 2 - a ** 2)
    t = r.t
    ana = 1 - np.exp(-a * t) * (np.cos(wd * t) + a / wd * np.sin(wd * t))
    assert np.max(np.abs(r["b"] - ana)) < 5e-3


def test_ac_rc_lowpass_and_rlc_resonance():
    c = Circuit()
    c.add_V("in", "0", ac=1.0, name="v")
    c.add_R("in", "out", 1e3)
    c.add_C("out", "0", 1e-9)
    fc = 1 / (2 * math.pi * 1e3 * 1e-9)
    res = c.ac([fc], ["out"])
    assert abs(res["out"][0]) == pytest.approx(1 / math.sqrt(2), rel=1e-6)
    # series RLC driven by 1 A: |Z| at resonance = R
    c = Circuit()
    c.add_I("0", "a", ac=1.0)
    c.add_R("a", "b", 0.1)
    c.add_L("b", "d", 1e-9)
    c.add_C("d", "0", 1e-6)
    f0 = 1 / (2 * math.pi * math.sqrt(1e-15))
    res = c.ac([f0], ["a"])
    assert abs(res["a"][0]) == pytest.approx(0.1, rel=1e-4)


def test_controlled_sources():
    c = Circuit()
    c.add_V("in", "0", dc=0.25, name="v")
    c.add_E("o", "0", "in", "0", 4.0, name="e")
    c.add_R("o", "0", 1e3)
    c.add_G("0", "x", "in", "0", 2e-3)        # injects 0.5 mA into x
    c.add_R("x", "0", 2e3)
    sol = c.dc()
    assert sol.v("o") == pytest.approx(1.0, rel=1e-9)
    assert sol.v("x") == pytest.approx(1.0, rel=1e-6)


def test_current_group_equals_individual_sources():
    def build(group):
        c = Circuit()
        n = c.new_nodes(5)
        c.add_V(int(n[0]), "0", dc=1.0, name="v")
        for k in range(4):
            c.add_R(int(n[k]), int(n[k + 1]), 1.0)
        amps = np.array([1e-3, 2e-3, 3e-3])
        if group:
            c.add_I_group(n[2:5], np.zeros(3, dtype=int), amps)
        else:
            for k, i in zip(n[2:5], amps):
                c.add_I(int(k), "0", dc=float(i))
        return c.dc().x
    assert np.allclose(build(True), build(False), atol=1e-12)


@pytest.mark.skipif(not ngspice_available(), reason="ngspice not installed")
def test_ngspice_crosscheck_rlc_transient():
    c = Circuit()
    c.add_V("in", "0", dc=1.0, name="vs")
    c.add_R("in", "a", 0.02)
    c.add_L("a", "b", 0.5e-9, name="l1")
    c.add_C("b", "0", 2e-9)
    c.add_I("b", "0", dc=0.0, wave=PWL([0, 2e-9, 3e-9, 1], [0, 0, 0.5, 0.5]), name="iload")
    r = c.tran([(150e-9, 1e-11)], probes=["b"])
    node = spice_node(c, c.node_index("b"))
    d = run_ngspice(c, "tran 1e-11 150e-9 0 1e-11", [f"v({node})"])
    assert abs(d[f"v({node.lower()})"].min() - r["b"].min()) < 1e-4
