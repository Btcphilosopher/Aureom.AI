"""Generated OpenROAD scripts (Tcl syntax/options) and the sequencing RTL (sim, lint, synth)."""
import copy
import shutil
import subprocess
from pathlib import Path

import pytest

from powerlink.config import load_project
from powerlink.pdn_onchip.openroad import check_pdn, generate_pdn_tcl, generate_upf, write_scripts

ROOT = Path(__file__).resolve().parent.parent


@pytest.mark.parametrize("chip", ["silicaflux_v", "silicaflux_x_future"])
def test_pdn_config_checks_clean(chip):
    p = load_project(ROOT / f"configs/chips/{chip}.yaml")
    chk = check_pdn(p)
    assert chk.errors == []


def test_pdn_check_catches_too_narrow_strap():
    p = load_project(ROOT / "configs/chips/silicaflux_v.yaml")
    q = copy.deepcopy(p)
    q.pdn["layers"][1]["width_um"] = 0.05
    assert any("min width" in e for e in check_pdn(q).errors)


@pytest.mark.skipif(shutil.which("tclsh") is None, reason="tclsh not installed")
@pytest.mark.parametrize("chip", ["silicaflux_v", "silicaflux_x_future"])
def test_generated_tcl_passes_stub_checker(chip, tmp_path):
    p = load_project(ROOT / f"configs/chips/{chip}.yaml")
    files = write_scripts(p, tmp_path)
    for k, f in files.items():
        if k == "upf":
            continue
        r = subprocess.run(["tclsh", str(ROOT / "scripts/openroad_stub_check.tcl"), f], capture_output=True, text=True)
        assert r.returncode == 0, r.stdout + r.stderr
        assert "0 errors" in r.stdout


def test_sky130_target_drops_unmapped_layer():
    p = load_project(ROOT / "configs/chips/silicaflux_v.yaml")
    t = generate_pdn_tcl(p, "sky130")
    assert "met5" in t and "M9" not in t.split("WARNINGS")[1].split("\n", 1)[1]
    assert "dropped" in t


def test_upf_has_domains():
    p = load_project(ROOT / "configs/chips/silicaflux_x_future.yaml")
    u = generate_upf(p)
    assert "create_power_domain PD_TILES_S" in u and "create_power_switch SW_TILES_N" in u
    assert "create_supply_net VDD_SRAM" in u


def _run(cmd):
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=600)


@pytest.mark.skipif(shutil.which("iverilog") is None, reason="iverilog not installed")
def test_rtl_testbenches_pass():
    r = _run(["bash", "scripts/sim_rtl.sh"])
    assert r.returncode == 0, r.stdout[-3000:]
    assert r.stdout.count("PASS") >= 2


@pytest.mark.skipif(shutil.which("verilator") is None, reason="verilator not installed")
def test_rtl_lint_clean():
    r = _run(["bash", "scripts/lint_rtl.sh"])
    assert r.returncode == 0 and "%Warning" not in r.stdout and "%Error" not in r.stdout, r.stdout


@pytest.mark.skipif(shutil.which("yosys") is None, reason="yosys not installed")
def test_rtl_synthesizes():
    r = _run(["bash", "scripts/synth_rtl.sh"])
    assert r.returncode == 0, r.stdout + r.stderr
    assert "Number of cells" in r.stdout
