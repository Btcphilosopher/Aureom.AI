"""On-die grid solver: analytic Poisson solution, conservation, linearity, convergence."""
import copy

import numpy as np
import pytest

from powerlink.circuit.mna import Circuit
from powerlink.config import load_project
from powerlink.electrical.grid import build_grid, add_loads, rect_weights, solve_static
from powerlink.electrical.path import build_rail_path
from powerlink.power.dynamic import evaluate_workload

PROJ = "configs/chips/silicaflux_v.yaml"


def test_uniform_sheet_matches_poisson_series():
    """Square sheet, uniform sink, edges held at 0 V: centre drop = 0.0736713 q a^2 / sigma."""
    n = 61
    a = 1.0
    h = a / (n - 1)
    sigma = 2.0
    q = 1.0                          # A/m^2
    c = Circuit()
    idx = np.zeros((n, n), dtype=int)
    interior = np.zeros((n, n), dtype=bool)
    interior[1:-1, 1:-1] = True
    idx[interior] = c.new_nodes(int(interior.sum()))
    g = sigma                         # conductance between neighbours of a square mesh = sigma
    for (ai, bi) in (((slice(None), slice(0, -1)), (slice(None), slice(1, None))),
                     ((slice(0, -1), slice(None)), (slice(1, None), slice(None)))):
        A, B = idx[ai], idx[bi]
        ok = (A > 0) | (B > 0)
        c.add_R_bulk(A[ok], B[ok], np.full(int(ok.sum()), 1 / g))
    nodes = idx[interior]
    c.add_I_group(np.zeros(len(nodes), dtype=int), nodes, np.full(len(nodes), -q * h * h))
    x = c.dc().x
    centre = x[idx[n // 2, n // 2] - 1]
    # sink current drawn from the node -> node voltage negative; magnitude compared
    assert abs(centre) == pytest.approx(0.0736713 * q * a * a / sigma, rel=0.01)


@pytest.fixture(scope="module")
def solved():
    p = load_project(PROJ)
    pr = evaluate_workload(p, "max_simultaneous", temp_c=85)
    cur = {b.name: b.current_a for b in pr.blocks}
    paths = {r: build_rail_path(p, r, i_max=pr.rail_current(r), delta_i=0.03, compensate=False) for r in p.rails}
    ir = solve_static(p, cur, rail_paths=paths, resolution_um=40)
    return p, pr, cur, paths, ir


def test_supply_current_equals_load(solved):
    p, pr, cur, paths, ir = solved
    tot = sum(s["current_a"] for s in ir.supply_currents if s["net"] == "VDD_CORE")
    load = sum(v for k, v in cur.items() if next(b for b in p.blocks if b["name"] == k)["rail"] == "VDD_CORE")
    assert tot == pytest.approx(load, rel=1e-6)
    tot_g = sum(s["current_a"] for s in ir.supply_currents if s["net"] == "VSS")
    assert tot_g == pytest.approx(load, rel=1e-6)


def test_ir_is_linear_in_load(solved):
    p, pr, cur, paths, ir = solved
    ir2 = solve_static(p, {k: 2 * v for k, v in cur.items()}, rail_paths=paths, resolution_um=40)
    assert ir2.worst_drop_v["VDD_CORE"] == pytest.approx(2 * ir.worst_drop_v["VDD_CORE"], rel=1e-6)


def test_wider_top_straps_reduce_drop(solved):
    p, pr, cur, paths, ir = solved
    p2 = copy.deepcopy(p)
    for L in p2.pdn["layers"]:
        if L["name"] in ("M8", "M9"):
            L["width_um"] *= 2
    ir2 = solve_static(p2, cur, rail_paths=paths, resolution_um=40)
    assert ir2.drop_breakdown["VDD_CORE"]["on_die_worst_v"] < ir.drop_breakdown["VDD_CORE"]["on_die_worst_v"]


def test_mesh_convergence(solved):
    p, pr, cur, paths, ir = solved
    fine = solve_static(p, cur, rail_paths=paths, resolution_um=25)
    assert fine.worst_drop_v["VDD_CORE"] == pytest.approx(ir.worst_drop_v["VDD_CORE"], rel=0.15)


def test_rect_weights_sum_to_one():
    w = rect_weights([10, 10, 95, 47], 20, 20, 5.0, 5.0)
    assert w.sum() == pytest.approx(1.0)


def test_effective_sheet_conductance():
    p = load_project(PROJ)
    from powerlink.electrical.grid import layer_models
    lm = layer_models(p, 25.0)
    m8 = lm["M8"]
    assert m8.sigma == pytest.approx(m8.width_um / (m8.pitch_um * m8.rs))
