"""Geometry formulas, regulator models, impedance, decap, transient, EM and margins."""
import math

import numpy as np
import pytest

from powerlink.circuit.mna import Circuit
from powerlink.config import load_project
from powerlink.constants import MU0
from powerlink.electrical import geometry as geo
from powerlink.electrical import margins as mg
from powerlink.electrical.decap import CapacitorPart, CapBank, die_decap_required, first_droop_estimate, select_decaps
from powerlink.electrical.em import em_limit_at, lifetime_ratio
from powerlink.electrical.impedance import find_resonances, loop_gain, stability_margins, target_impedance, z_die
from powerlink.electrical.path import build_rail_path
from powerlink.electrical.transient import ClockedLoad, StepLoad, build_event_wave, simulate_droop
from powerlink.electrical.vrm import LDO

PROJ = "configs/chips/silicaflux_v.yaml"


def test_bondwire_inductance_rule_of_thumb():
    l = geo.l_wire_self(1e-3, 12.5e-6)
    assert 0.7e-9 < l < 1.1e-9                      # ~1 nH/mm
    loop = geo.l_bondwire(1.5e-3, 25e-6, 100e-6)
    assert 0.0 < loop < 2 * geo.l_wire_self(1.5e-3, 12.5e-6)


def test_plane_pair_inductance_and_resistance():
    assert geo.l_plane_pair(100e-6, 0.02, 0.01) == pytest.approx(MU0 * 100e-6 * 2.0)
    assert geo.r_plane_pair(1.7e-8, 0.02, 0.01, 35e-6) == pytest.approx(2 * 1.7e-8 * 0.02 / (0.01 * 35e-6))
    assert geo.oz_to_m(1.0) == pytest.approx(34.79e-6)


def test_vrm_crossover_and_phase_margin():
    p = load_project(PROJ)
    path = build_rail_path(p, "VDD_CORE", i_max=0.05, delta_i=0.04)
    f, T = loop_gain(path, np.logspace(3, 7, 401))
    m = stability_margins(f, T)
    assert m["crossover_hz"] == pytest.approx(path.regulator.f_c_target, rel=0.05)
    assert m["phase_margin_deg"] > 45.0


def test_buck_ripple_formula():
    p = load_project(PROJ)
    reg = build_rail_path(p, "VDD_CORE", compensate=False).regulator
    r = reg.ripple()
    d = reg.v_out / reg.v_in
    di = (reg.v_in - reg.v_out) * d / (reg.l_ind * reg.f_sw)
    assert r["ripple_current_pp_a"] == pytest.approx(di)
    assert r["dv_cap_pp_v"] == pytest.approx(di / (8 * reg.f_sw * r["c_out_f"]))


def test_ldo_output_impedance_limits():
    ldo = LDO("x", 3.3, 1.0, r_out=0.02, r_ol=1.0, bandwidth_hz=3e5, psrr_db_at_fsw=40, dropout_v=0.2, i_max=0.1)
    z = np.abs(ldo.z_out(np.array([1.0, 1e9])))
    assert z[0] == pytest.approx(0.02, rel=1e-3)
    assert z[1] == pytest.approx(1.02, rel=1e-3)
    assert ldo.ripple(0.01)["ripple_pp_v"] == pytest.approx(1e-4)        # 40 dB = x100


def test_impedance_low_frequency_and_resonance():
    p = load_project(PROJ)
    path = build_rail_path(p, "VDD_CORE", i_max=0.05, delta_i=0.04, r_grid=0.01)
    f, Z = z_die(path, np.logspace(3, 9.3, 400))
    res = find_resonances(f, Z)
    f_lc = 1 / (2 * math.pi * math.sqrt(path.l_package() * path.c_die))
    top = max(res, key=lambda r: r["z_ohm"])
    assert top["f_hz"] == pytest.approx(f_lc, rel=0.15)
    assert target_impedance(1.0, 0.05, 0.05) == pytest.approx(1.0)


def test_first_droop_estimate_matches_simulation():
    L, C, dI = 0.5e-9, 2e-9, 0.1
    est = first_droop_estimate(dI, L, C, r_series=0.0, t_rise=1e-12)
    assert est == pytest.approx(dI * math.sqrt(L / C), rel=1e-6)
    c = Circuit()
    c.add_V("s", "0", dc=1.0, name="v")
    c.add_R("s", "a", 1e-6)
    c.add_L("a", "b", L, name="l")
    c.add_C("b", "0", C)
    c.add_I("b", "0", dc=0.0, wave=StepLoad(0.0, dI, 1e-9, 1e-12))
    r = c.tran([(30e-9, 2e-12)], probes=["b"])
    assert 1.0 - r["b"].min() == pytest.approx(est, rel=0.03)
    assert die_decap_required(dI, est, L) == pytest.approx(C, rel=1e-6)


def test_decap_selection_reduces_impedance():
    f = np.logspace(5, 8, 50)
    base = CapBank(CapacitorPart("c1", 1e-6, 0.01, 0.5e-9, 0.0), 1)
    cands = [CapacitorPart("c100n", 100e-9, 0.03, 0.3e-9), CapacitorPart("c10n", 10e-9, 0.06, 0.3e-9)]

    def zfn(extra):
        y = 1 / base.z(f) + sum(1 / b.z(f) for b in extra) if extra else 1 / base.z(f)
        return 1 / y
    chosen = select_decaps(zfn, f, np.full(len(f), 0.05), cands, max_parts=30)
    assert np.max(np.abs(zfn(chosen))) < np.max(np.abs(zfn([])))


def test_clocked_load_has_unit_mean_shape():
    w = ClockedLoad(StepLoad(0, 0, 0, 1e-9), StepLoad(1, 1, 0, 1e-9), 1e8, 3.0, 1e-7)
    t = np.linspace(0, 1e-8, 20001)[:-1]
    assert np.mean([w(x) for x in t]) == pytest.approx(1.0, rel=2e-3)
    assert max(w(x) for x in t) == pytest.approx(3.0, rel=1e-2)


def test_droop_increases_with_package_inductance():
    p = load_project(PROJ)
    ev = {"at_ns": 200, "rise_ns": 5}
    w = build_event_wave(ev, (0.01, 0.0), (0.01, 0.04))
    a = build_rail_path(p, "VDD_CORE", r_grid=0.01, compensate=False)
    b = build_rail_path(p, "VDD_CORE", r_grid=0.01, compensate=False, scales={"conn_l": 3.0, "pin_l": 3.0})
    da = simulate_droop(a, w, 200e-9, 2e-6, 0.05e-9, 1e-9, 1e-6).first_droop_v
    db = simulate_droop(b, w, 200e-9, 2e-6, 0.05e-9, 1e-9, 1e-6).first_droop_v
    assert db > da


def test_em_black_scaling():
    assert em_limit_at(1.0, 105.0) == pytest.approx(1.0)
    assert em_limit_at(1.0, 85.0) > 1.0
    assert lifetime_ratio(1.0, 1.0, 105.0) == pytest.approx(1.0)
    assert lifetime_ratio(0.5, 1.0, 105.0) == pytest.approx(4.0)        # n = 2


def test_margin_budget_arithmetic():
    comps = [mg.BudgetComponent("a", 0.01, 0.02, 0.03, False), mg.BudgetComponent("b", 0.02, 0.03, 0.04, True),
             mg.BudgetComponent("c", 0.01, 0.04, 0.05, True)]
    b = mg.RailBudget("R", 1.0, 0.9, comps, 0.005)
    assert b.available_v == pytest.approx(0.095)
    assert b.margin_worst_v == pytest.approx(0.095 - 0.09)
    assert b.margin_rss_v == pytest.approx(0.095 - 0.02 - math.hypot(0.03, 0.04))
    mc = mg.monte_carlo_margin(b, {"x": np.full(1000, 0.1)})
    assert mc["p_fail"] == 1.0
