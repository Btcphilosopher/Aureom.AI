"""Power model, activity import, thermal model, package study, uncertainty and configuration."""
import copy
import math
from pathlib import Path

import numpy as np
import pytest

from powerlink.config import ConfigError, load_project, validate_project
from powerlink.power.activity import block_activity, parse_saif, parse_vcd, write_saif
from powerlink.power.dynamic import evaluate_workload, io_power, leakage_scale
from powerlink.thermal.model import (compact_network, export_map_csv, import_map_csv, power_map,
                                     solve_die_temperature, song_spreading_resistance)
from powerlink.uncertainty import ParameterSet, UncertainValue, build_surrogate, parse_value
from powerlink.uncertainty import nom

V = "configs/chips/silicaflux_v.yaml"
X = "configs/chips/silicaflux_x_future.yaml"


# ---------------------------------------------------------------- power
def test_dynamic_power_formula_single_block():
    p = load_project(V)
    pr = evaluate_workload(p, "vector_intensive", temp_c=25.0)
    b = pr.by_block()["tile0_vec"]
    blk = next(x for x in p.blocks if x["name"] == "tile0_vec")
    sc = p.technology["stdcell"]
    c = nom(blk["kge"]) * 1e3 * nom(sc["c_sw_per_ge_ff"]) * 1e-15
    alpha = p.workloads["profiles"]["vector_intensive"]["activity"]["vector"]["alpha"]
    assert b.p_data_w == pytest.approx(alpha * c * 1.0 ** 2 * 100e6, rel=1e-9)
    assert b.activity_source == "assumption"


def test_leakage_temperature_and_voltage_scaling():
    assert leakage_scale(50.0, 1.0, 1.0, 25.0, 0.6) == pytest.approx(2.0)
    assert leakage_scale(25.0, 1.6, 1.0, 25.0, 0.6) == pytest.approx(10.0)


def test_clock_gating_reduces_clock_power():
    p = load_project(V)
    idle = evaluate_workload(p, "idle").by_block()["tile0_vec"]
    vec = evaluate_workload(p, "vector_intensive").by_block()["tile0_vec"]
    assert idle.p_clock_w < 0.05 * vec.p_clock_w


def test_io_power_formula():
    p = load_project(V)
    io = io_power(p, {"VDDIO": 3.3})
    s = p.chip["io"]["signals"]["chiplet_link"]
    assert io["chiplet_link"] == pytest.approx(s["pins"] * s["activity"] * s["load_pf"] * 1e-12 * 3.3 ** 2 * s["rate_mbps"] * 1e6)


def test_profiles_ordered_sensibly():
    p = load_project(V)
    pw = {k: evaluate_workload(p, k).rail_power("VDD_CORE") for k in p.workloads["profiles"]}
    assert pw["idle"] < pw["cpu_intensive"] < pw["max_simultaneous"]
    assert max(pw, key=pw.get) == "max_simultaneous"


# ---------------------------------------------------------------- activity
VCD = """$timescale 1ns $end
$scope module tb $end
$scope module dut $end
$var wire 1 ! clk $end
$var wire 1 " a $end
$var wire 4 # bus [3:0] $end
$upscope $end
$upscope $end
$enddefinitions $end
#0
$dumpvars
0!
0"
b0000 #
$end
#5
1!
#10
0!
1"
b0011 #
#15
1!
#20
0!
0"
b0000 #
#25
1!
#30
0!
x"
#40
"""


def test_vcd_toggle_counts_and_saif_roundtrip(tmp_path):
    f = tmp_path / "t.vcd"
    f.write_text(VCD)
    d = parse_vcd(f)
    assert d.duration == 40.0
    assert d.nets["tb.dut.a"].tc == 2               # 0->1->0 ; ->x is not a toggle
    assert d.nets["tb.dut.a"].ig == 1
    assert d.nets["tb.dut.bus"].tc == 4             # two bits up then down
    assert d.nets["tb.dut.clk"].tc == 6
    assert d.nets["tb.dut.a"].t1 == pytest.approx(10.0)
    s = write_saif(d, tmp_path / "t.saif")
    back = parse_saif(s)
    for k, v in d.nets.items():
        assert back.nets[k].tc == v.tc
    act = block_activity(d, {"dut": ["tb.dut"]}, f_clk_hz=1e8)     # clock excluded
    cycles = 40e-9 * 1e8
    assert act["dut"].toggle_rate == pytest.approx((2 + 4) / (5 * cycles))
    assert act["dut"].alpha == pytest.approx(act["dut"].toggle_rate / 2)


# ---------------------------------------------------------------- thermal
def test_song_spreading_limits():
    r = song_spreading_resistance(1e-3, 1e-3, 1e-3, 400.0, 1e4)
    assert r["r_spreading"] == pytest.approx(0.0, abs=1e-12)
    small = song_spreading_resistance(0.5e-3, 10e-3, 1e-3, 400.0, 1e4)["r_spreading"]
    big = song_spreading_resistance(2e-3, 10e-3, 1e-3, 400.0, 1e4)["r_spreading"]
    assert small > big > 0


def test_uniform_power_gives_compact_network_temperature():
    p = load_project(V)
    net = compact_network(p, "wb_qfn88", "natural_convection")
    W = nom(p.die["width_mm"]) * 1e3
    nx = 40
    pm = np.full((nx, nx), 0.2 / nx ** 2)
    tm = solve_die_temperature(p, pm, W / nx, W / nx, net, 25.0)
    assert tm.temp_c.mean() == pytest.approx(25.0 + 0.2 * net.theta_ja, rel=1e-3)
    assert tm.temp_c.max() - tm.temp_c.min() < 0.05


def test_thermal_map_export_import_roundtrip(tmp_path):
    p = load_project(V)
    pr = evaluate_workload(p, "max_simultaneous")
    pm, dx, dy = power_map(p, {b.name: b.total_w for b in pr.blocks}, 0.0, 50.0)
    tm = solve_die_temperature(p, pm, dx, dy, compact_network(p, "wb_qfn88", "natural_convection"), 25.0)
    f = export_map_csv(tm, tmp_path / "m.csv")
    back = import_map_csv(f)
    assert np.allclose(back.temp_c, tm.temp_c, atol=1e-3)
    assert back.block_temperatures(p)["cpu_ctrl"] == pytest.approx(tm.block_temperatures(p)["cpu_ctrl"], abs=1e-3)


# ---------------------------------------------------------------- packages
def _study(path):
    from powerlink.packaging.compare import package_study
    from powerlink.power.dynamic import all_profiles
    p = load_project(path)
    prof = all_profiles(p, temp_c=85)
    core = next(r for r, c in p.rails.items() if c.get("on_die_grid"))
    i_max = {r: max(x.rail_current(r) for x in prof.values()) for r in p.rails}
    i_min = {r: min(x.rail_current(r) for x in prof.values()) for r in p.rails}
    return {it.key: it for it in package_study(p, i_max, {r: i_max[r] - i_min[r] for r in p.rails},
                                                  max(x.total_w() for x in prof.values()), core)}


def test_package_study_silicaflux_v():
    s = _study(V)
    assert s["wb_qfn88"].feasible                       # 88 leads suffice for SilicaFlux-V
    assert s["wb_qfn88"].metrics["pins_required"] <= 88


def test_package_study_future_variant_needs_flip_chip():
    s = _study(X)
    assert not s["wb_qfn88"].feasible and not s["wb_bga256"].feasible
    assert s["fc_bga"].feasible


# ---------------------------------------------------------------- uncertainty / config
def test_uncertain_value_sampling_within_bounds():
    u = parse_value({"nom": 1.0, "min": 0.8, "max": 1.3, "dist": "triangular"})
    x = u.sample(np.random.default_rng(0), 5000)
    assert x.min() >= 0.8 and x.max() <= 1.3
    with pytest.raises(ValueError):
        UncertainValue(1.0, 1.1, 1.2)


def test_power_law_surrogate_is_exact_for_power_law():
    ps = ParameterSet()
    ps.add("L", {"nom": 1.0, "min": 0.5, "max": 2.0})
    ps.add("C", {"nom": 1.0, "min": 0.5, "max": 2.0})
    model = lambda v: 3.0 * math.sqrt(v["L"] / v["C"])  # noqa: E731
    s = build_surrogate(model, ps)
    assert s.elasticity["L"] == pytest.approx(0.5, abs=1e-9)
    assert s.elasticity["C"] == pytest.approx(-0.5, abs=1e-9)
    assert float(s({"L": 2.0, "C": 0.5})) == pytest.approx(model({"L": 2.0, "C": 0.5}))


def test_config_validation_rejects_bad_rail():
    p = load_project(V)
    q = copy.deepcopy(p)
    q.chip["blocks"][0]["rail"] = "NOPE"
    with pytest.raises(ConfigError):
        validate_project(q)
    q = copy.deepcopy(p)
    q.chip["rails"]["VDD_CORE"]["min_v"] = 1.2
    with pytest.raises(ConfigError):
        validate_project(q)


def test_yaml_float_forms_parsed():
    p = load_project(V)
    assert isinstance(p.pcb["regulators"]["buck_core"]["ea_ro_ohm"], float)
