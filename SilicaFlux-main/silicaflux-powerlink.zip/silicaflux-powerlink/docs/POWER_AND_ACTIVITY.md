# Dynamic power, leakage and switching activity

## Equations

Per logic block (gate-equivalent count N_GE, flop count N_FF):

```
P_data  = alpha * C_sw * V^2 * f          C_sw  = N_GE * c_sw_per_GE
P_clock = g_clk * C_clk * V^2 * f          C_clk = N_FF * c_clk_per_flop
P_leak  = V * N_GE * I_leak,GE(25C) * 2^((T-25)/T_double) * 10^((V-V_nom)/S_dibl)
```

Per SRAM macro: `P = (reads E_read + writes E_write) f (V/V_char)^2 + V I_leak(T, V)`.
Analogue blocks (PLL): fixed power (datasheet placeholder).
I/O: `P = pins * alpha * C_load * V_io^2 * f_data` per interface, with per-workload alpha.

* `alpha` is the probability of a 0->1 transition per clock cycle, so a node toggling every
  cycle (a clock) has alpha = 1 in this convention (energy C V^2 per cycle) and the SAIF/VCD
  toggle rate per cycle is TR = 2 alpha.
* `g_clk` is the fraction of cycles the block clock is not gated (clock-gating model).
* Leakage is **technology-dependent and separate**: its parameters are in the technology
  file, flagged `assumption` until replaced with .lib leakage data, and it is evaluated at
  the self-consistent electro-thermal temperature of each block.

## Workload profiles

`configs/workloads/*.yaml` defines idle, cpu_intensive, vector_intensive, tensor_intensive,
sram_heavy and max_simultaneous (a stress bound, not a program) with per-group alpha,
clock-enable, SRAM accesses per cycle and I/O activity, plus transient events (from/to
profile, time, rise time, optional stagger).

**No activity number in these files is a measurement.**  They are planning assumptions
chosen to bracket behaviour and carry a global uncertainty multiplier
(`assumed_activity_scale`).  Reports print the activity source of every block.

## Using measured activity (VCD / SAIF)

1. Run gate-level (preferred) or RTL simulation of representative firmware and dump VCD or SAIF.
2. Map hierarchy to floorplan blocks in `activity_block_map` (instance-path patterns).
3. Attach the file: `activity_files: {vector_intensive: ../activity/vector_kernel.saif}`.
4. Re-run.  For the mapped blocks the measured alpha replaces the assumption and the report
   tags the source `saif`/`vcd`.

Inspect a file without changing the configuration:

```
python -m powerlink activity --chip configs/chips/silicaflux_v.yaml --file sim.vcd --saif sim.saif
```

The VCD parser counts 0<->1 transitions per bit (transitions through X/Z are counted
separately and not as toggles), integrates T0/T1/TX, handles vectors and aliases, and can
write SAIF 2.0 (`write_saif`) for downstream tools.  Clock nets are excluded from the block
data activity because clock power is modelled separately.

Caveats: RTL-level toggle rates miss glitch power and synthesis restructuring; use
gate-level SAIF with SDF-annotated delays for power signoff.  A testbench is not a
workload: the shipped demonstration (activity of the sequencer testbench in
`results/rtl/`) shows the pipeline working and is deliberately **not** used for chip power.
