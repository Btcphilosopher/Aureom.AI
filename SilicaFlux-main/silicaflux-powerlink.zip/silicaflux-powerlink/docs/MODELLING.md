# Electrical modelling: equations, abstractions and limits

All quantities SI unless stated.  "Loop" R/L means supply plus return path, the usual
single-ended equivalent for PDN impedance.  Every input may carry `{nom, min, max, dist,
source}`; the source tag (`assumption`, `literature`, `datasheet`, `measured`, `pdk`, ...) is
propagated to the reports.

## 1. Circuit engine (`powerlink/circuit/mna.py`)

Modified nodal analysis, `G x + C dx/dt = b(t)`, sparse (SciPy SuperLU).

* Elements: R, C, L (branch current), independent V/I (DC, AC, waveform), grouped current
  sources (one waveform scaling many sinks - used for floorplan load maps), VCCS, VCVS.
* DC: capacitors open, inductors short, `gmin = 1e-12 S` from every node to ground.
* AC: `(G + j w C) x = b_ac`.
* Transient: fixed step per segment.  Trapezoidal integration on rows that contain a
  capacitive/inductive term, exact enforcement of purely algebraic rows (KCL nodes without
  capacitance, source constraints) - avoids the spurious oscillation of plain trapezoidal
  DAE integration.  Backward Euler available.  LU factorisation reused within a segment.
* SPICE export of the same object for ngspice cross-checks (`circuit/spice.py`).

## 2. Power-delivery path (`electrical/path.py`)

```
regulator -> [VRM caps] -> PCB plane -> [PCB decaps + spreading L] -> package pins/balls
 -> package substrate -> [package caps] -> bond wires / bumps -> on-die grid R_eff -> [C_die + ESR] -> load
```

| Segment | Model |
|---|---|
| PCB plane pair | R = 2 rho_Cu(40 C) L/(w t), L = mu0 h L / w |
| Cap mounting / spreading | L_spread = (mu0 h / pi) ln(d / r_via); 0.3x for caps under the package |
| Decap bank | ESR/N + j w (ESL+L_mount)/N + 1/(j w C N); C derated for DC bias (datasheet range) |
| Pins / balls | R = r/N_vdd + r/N_vss; L = L_loop / (N eta), eta = mutual-coupling efficiency |
| Bond wires | R from rho(T) l / A; loop L = 2 (L_self - M), Rosa/Grover self and parallel-wire mutual inductance |
| Bumps / micro-bumps | per-bump R and loop L from the package library |
| Interposer DTC | C = density x die area x usable fraction, bank ESR/ESL (if the package offers it) |
| On-die grid | R_eff = power-weighted mean drop / I from the grid solver |
| On-die capacitance | intrinsic (fraction of switchable C of logic + SRAM array C) + explicit decap cells (area x density), ESR = (R x area)/area_eq |

Connection counts come from the chip pin plan for the baseline package, otherwise from
rules: current headroom n >= 1.5 I / I_max, first-droop inductance n >= L_pair /(eta
C_die (dV/dI)^2), SSO pairs for the I/O rail, all PG bumps over the region for flip-chip.

## 3. Regulators (`electrical/vrm.py`)

**Buck, peak-current mode, averaged and linearised.**  Below ~f_sw/2 the power stage is a
transconductance `i_L = G_ps v_c` (G_ps = I_max / 1 V) with a current-loop pole at f_sw/2.
Transconductance error amplifier (gm, R_o) with type-II network (R_c + C_c || C_p); sense
divider H = V_ref/V_out; local or remote sense.

Design: `R_c = 2 pi f_c C_total / (gm H G_ps)`, zero at f_c/4, pole at min(8 f_c, f_sw/2);
R_c is then refined so the *numerical* crossover of the full circuit equals the target.
Loop gain is measured by breaking the loop at the VCCS control input (exact, the input
draws no current): `T = -V(comp)/V(x)`.

Analytic additions: ripple `dI_L = (Vin - Vout) D / (L f_sw)`,
`dV = dI_L/(8 f_sw C) + dI_L ESR (+ ESL dI/dt)`; die ripple = 2 |Z21(f_sw)| (4 dI_L / pi^2);
inductor slew `dI/dt = (Vin - Vout)/L` per phase compared with the load step.

Not modelled: duty saturation, current limit, DCM, slope compensation (assumed adequate),
multiphase ripple cancellation (conservative).

**LDO**: `Z = R_out + (s L || R_ol)`, `L = R_ol / (2 pi f_bw)`; PSRR attenuates upstream ripple.

## 4. Impedance and target (`electrical/impedance.py`)

Closed-loop |Z(f)| at the die with the regulator in place.  Target `Z_t = V_nom x dynamic
allocation / dI` as a *screening* criterion up to max(f_clk, 0.35/t_rise).  Anti-resonances
are reported; the governing check is the time-domain droop because flat-Z design can be
both pessimistic (slow edges) and optimistic (resonant workloads).

## 5. Transients (`electrical/transient.py`, `flows.py`)

* Event loads: ramp, staggered sub-steps, clock-synchronous triangular pulses of unit mean
  and configurable peak-to-average ratio PAR (pulse base 2/PAR of the cycle) on top of a
  static (leakage) current, resonant square waves at the strongest anti-resonance a program
  can excite (<= f_clk/2).
* Droop metrics: first (< 100 ns), second (0.1-1 us), third (> 1 us) droop, overshoot, settling.
* Windows for clocked simulations are defined in clock cycles (step count independent of f_clk).

## 6. On-die grid (`electrical/grid.py`)

Homogenised multi-layer mesh (see module docstring).  Effective sheet conductance of a strap
layer `sigma = w / (p Rs(T))` along its direction, zero across.  Vias: intersections per cell
`(dx/p_V)(dy/p_H)` times `1/R_stack`, `R_stack = sum(R_cut/cuts)`.  Rings add boundary
conductance and strap-end via arrays.  Macros remove followpins and load at their pin layer.
Supplies: wire-bond pads on the ring (bond wire + pad-stub R) or bumps over the core
(checkerboard, signal sites removed by the PG fraction); islands without a supply at the
chosen resolution are detected and fed (noted in the report).  Metal R uses the thin-film
TCR at the analysis temperature.

Static: DC solve with block currents distributed by area overlap; outputs effective
VDD-VSS map, breakdown (off-die / connections / on-die), power-weighted R_eff, per-layer
current density (mA/um of strap width), via current per cut, connection currents.

Dynamic: same mesh at coarser resolution with per-cell on-die capacitance + ESR, R-L per
supply connection, the rail ladder attached at the package node, and per-cell currents
`S_from + dS u(t) + [D_from + dD u(t)] s(t)` (static/dynamic split, wake ramp u, clock
pulse shape s).  The running minimum of the cell supply gives the dynamic-drop map.

## 7. Electromigration (`electrical/em.py`)

Black's equation; limits specified at 105 C scaled by `exp(Ea/(n k)(1/T - 1/T_ref))`,
Ea = 0.9 eV, n = 2 (assumptions).  Screening only; foundry rules supersede.

## 8. Margins and uncertainty (`electrical/margins.py`, `uncertainty.py`, `flows.py`)

`V_cell = V_nom - setpoint error - ripple/2 - static IR - dynamic`, margin to the library
corner minus guardband.  Reported three ways:

1. **Worst-case linear stack**: every uncertain input at its adverse bound simultaneously
   (deliberately pessimistic - e.g. activity, capacitance per gate and gate count all high).
2. **RSS**: DC IR linear, random terms root-sum-squared.
3. **Monte-Carlo**: inputs sampled from their distributions.  Static IR scales exactly with
   current and resistance factors.  The dynamic term uses a power-law (elasticity) surrogate
   built from the full lumped clocked model, validated at the worst corner, **and** a direct
   Monte-Carlo with the full model on a subset of the same draws; where they differ (the
   response is non-monotonic near resonances) the full-model value governs.

## 9. Power (`power/dynamic.py`) and thermal (`thermal/model.py`)

See docs/POWER_AND_ACTIVITY.md and docs/THERMAL.md.
