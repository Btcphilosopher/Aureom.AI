## Engineering interpretation

### SilicaFlux-V - are the proposed rails, package and PCB realistic?

**Yes for DC and thermal, conditionally for dynamic noise, and the I/O dominates the power.**

1. **Power is small and I/O-dominated.**  The core draws about 44 mA (44 mW) in the
   max-simultaneous stress case at 70 C ambient; the whole chip is about 172 mW, of which about
   126 mW is I/O - almost all of it the 22-pin 3.3 V LVCMOS chiplet link.  The cheapest power saving available is a
   low-swing link or a 1.8 V I/O option, not core optimisation.  Thermally, a QFN with a
   soldered exposed pad and no heatsink stays about 4 C above a 70 C ambient.
2. **Static IR drop is not a problem.**  About 5 mV worst cell (0.5 %): roughly 1.8 mV in the
   bond wires/pad stubs and 3.2 mV on die.  Even the all-adverse corner (25 mV) fits the 30 mV
   allocation.  Strap EM is about 2 % of the limit; vias and bond wires are below 10 %.  The
   PDN straps could be thinned if routing needs the tracks.
3. **The regulator and PCB are adequate.**  The 2 MHz PMIC buck closes at 100 kHz with a
   65-degree phase margin (averaged model); ripple at the die is 0.5 mV p-p; the PCB plane and
   decaps meet the flat target impedance up to the band where the package takes over
   (|Z|/Z_t 0.11).  No PCB decaps were added by the optimiser.
4. **The real issue is cycle-level noise from a die-package resonance.**  The 345 pH package
   loop (bond wires + leads) against about 1.8 nF of on-die capacitance resonates near
   180-200 MHz, i.e. on the second harmonic of the 100 MHz clock, with a 3.4 Ohm peak.
   Clock-synchronous current pulses (assumed peak-to-average 3) then produce about 34 mV of
   dynamic drop on the die grid against a 50 mV allocation, versus only about 4 mV for the
   cycle-averaged wake-up step.  The nominal margin to the 0.90 V library corner is +46 mV, but
   the full-model Monte-Carlo failure probability is about 7.5 % and the all-adverse stack fails.
5. **Cheapest mitigation:** double the VDD_CORE bond-wire/lead pairs (8 -> 16; +8 leads, which
   the QFN-88 has free because VSS is down-bonded to the exposed pad).  This lowers the loop
   inductance and moves the resonance, giving about 26 mV in the lumped clocked model with no
   extra silicon.  Capacitance alone needs about 6x (+1.3 mm^2 of decap cells, two-thirds of the
   core) because intermediate values move the resonance onto 100 MHz and make noise worse -
   the what-if table shows this non-monotonic behaviour.  Damping (decap ESR) and gate-level
   per-cycle current shapes must be confirmed in vectored dynamic-IR signoff.
6. **Package:** QFN-88 is the right first-silicon package (lowest cost, 79/88 leads with the
   10 % spare, adequate PDN/thermal), but chiplet-link SSO fails at the fast-edge (1 ns) corner:
   specify slew-rate-controlled pads and keep at least four VDDIO/VSSIO pairs.  FCBGA is the
   robust fallback at about 25x the unit cost.

### SilicaFlux-X (hypothetical) - does the approach scale?

1. **Wire-bond packages are excluded** on pin count, pad ring, package DC drop, signal rate and
   thermal; FCBGA is the best feasible option but its 324-ball body is full (322 required) - a
   larger body is needed.  Advanced organic and interposer options are feasible; the interposer's
   deep-trench capacitance helps the first droop but its thin-metal DC drop and cost count
   against it.
2. **Wake policy is a package-level decision.**  Waking all 16 tiles in one cycle (2.4 A in 1 ns)
   gives about 40 mV of first droop at 0.8 V; the 8-step stagger (`sf_rst_clk_ctrl`-style) cuts
   the first droop to about 6 mV (10 mV including the second droop).  The package study is evaluated with the staggered step.
3. **On-die decap is the dominant 1 GHz problem.**  About 38 nF against about 41 nF from the per-cycle-charge
   rule (54 nF from the first-droop bound of a simultaneous wake); the VDD_TILE nominal margin is only +15 mV and the Monte-Carlo failure probability is
   about 23-27 % (surrogate / full model).  The decap search needs about 4x (about 150 nF), i.e. deep-trench capacitors
   (interposer or on-die MIM) rather than MOS decap.
4. **Power-virus exposure:** a loop toggling the full tile current at the 238 MHz anti-resonance
   would produce about 250 mV - firmware power-management (activity ramp limits) or droop
   detectors with clock stretching are required for a design of this class.
5. **Thermal:** 3.4 W needs at least a large passive heatsink; natural convection leads to
   leakage-temperature non-convergence in four of the five packages.

### What would change these conclusions

Measured activity (SAIF) and gate-level per-cycle current shapes, the selected PDK's metal,
via, EM, decap and leakage data, OSAT-extracted package models and the PMIC vendor's regulator
model.  Replace them in the configuration files and re-run `scripts/run_all.sh`; every number
above is regenerated with the new provenance tags.
