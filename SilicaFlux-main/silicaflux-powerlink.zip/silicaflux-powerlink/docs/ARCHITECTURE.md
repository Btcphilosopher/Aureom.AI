# SilicaFlux PowerLink - system and software architecture

## 1. Physical system modelled

```
 External supply (5 V USB-C / bench, 12 V for SilicaFlux-X)
   -> PCB regulators (PMIC bucks, PLL LDO)            electrical/vrm.py
   -> PCB power planes + decoupling                    electrical/path.py, decap.py
   -> package solder balls / leads                     packaging library + path.py
   -> package power distribution (substrate/RDL/TSV)   path.py
   -> die pads (bond wires) or bumps                   path.py, grid.py (_add_supplies)
   -> on-die power grid (rings, straps, vias, rails)   electrical/grid.py
   -> compute and memory cells (block current maps)    power/dynamic.py
```

Multiple rails are first-class: every rail has its regulator, PCB plane, decaps, package
connection allocation, on-die net(s) (or a lumped die model for I/O and analogue rails),
budget and sequencing position.

| Chip | Rails |
|---|---|
| SilicaFlux-V (65 nm, 100 MHz) | VDD_CORE 1.0 V (buck), VDDIO 3.3 V (buck), VDDA_PLL 1.0 V (LDO) |
| SilicaFlux-X (hypothetical 28 nm, 1 GHz) | VDD_TILE 0.8 V (2-phase buck), VDD_CPU 0.9 V, VDD_SRAM 0.9 V, VDDIO 1.8 V, VDDA_PLL 0.9 V (LDO) |

## 2. Software layout

```
powerlink/
  uncertainty.py        UncertainValue {nom,min,max,dist,source}, ParameterSet, power-law surrogate
  config.py             YAML loading (YAML-1.2 floats), validation, SHA-256 manifest, assumption register
  constants.py          physical constants and bulk material data
  circuit/mna.py        sparse MNA: DC / AC / transient, grouped sources, controlled sources
  circuit/spice.py      SPICE export, ngspice batch runner, ASCII rawfile parser
  electrical/geometry.py   R/L of planes, vias, bond wires, bumps, spreading
  electrical/decap.py      capacitor models, first-droop bounds, decap optimiser
  electrical/vrm.py        averaged current-mode buck (type-II), LDO
  electrical/path.py       rail ladder builder, connection allocation, die capacitance
  electrical/impedance.py  Z(f), target impedance, resonances, loop gain, ripple transfer
  electrical/transient.py  load waveforms (step, stagger, clocked pulses, resonant), droop metrics
  electrical/grid.py       multi-layer on-die grid: static and dynamic IR, current density
  electrical/em.py         Black's-equation EM screening
  electrical/margins.py    PI budgets: worst-case, RSS, Monte-Carlo
  power/dynamic.py         alpha C V^2 f, clock, SRAM, leakage(T,V), I/O, intrinsic decap
  power/activity.py        VCD / SAIF parsers, SAIF writer, block mapping
  thermal/model.py         compact networks, spreading resistance, 2-D die solver, electro-thermal, CSV import/export
  packaging/compare.py     package feasibility and scoring
  pdn_onchip/openroad.py   PDN checks, OpenROAD Tcl and UPF generation
  reports/plots.py, diagrams.py, risk.py, report.py   figures, risk register, Markdown/HTML report
  validation.py            ngspice cross-checks
  flows.py                 end-to-end analysis
  cli.py                   command-line interface
rtl/                       synthesizable SystemVerilog sequencing logic + testbenches
configs/                   technology, chips, PCB, packages, PDN, workloads, thermal
scripts/                   RTL sim/lint/synth, Tcl stub checker, run_all.sh, SilicaFlux-X generator
tests/                     pytest suite
docs/                      this documentation
```

## 3. Data flow of `powerlink run`

```
configs --load/validate--> Project (+ input hashes)
  -> power stage: every workload x electro-thermal fixed point (nominal and worst ambient)
  -> rail paths (VRM compensation designed + numerically refined)
  -> static grid solve (max workload) -> R_eff back into the rail paths, EM screening
  -> Z(f), loop gain, ripple, slew; transient events; cycle noise; resonant workload
  -> dynamic grid solve (primary wake event)
  -> decap sizing and what-ifs (C and package L), PCB decap optimiser
  -> thermal maps, cooling x package table
  -> package study (nominal + adverse corner)
  -> margin budgets: worst-case, RSS, Monte-Carlo (surrogate + direct full-model subset)
  -> risk register, OpenROAD/UPF, ngspice cross-checks, activity-pipeline demo
  -> REPORT.md, report.html, CSV tables, figures/, manifest.json, summary.json
```

## 4. Configuration files

| File | Content |
|---|---|
| `configs/chips/<chip>.yaml` | references, die/core, clock, rails with budgets, I/O list and pin plan, floorplan blocks (kind, group, rail, rect, kGE/flops or SRAM macro, pin layer) |
| `configs/tech/<node>.yaml` | metal stack Rs/thickness/EM, via cut R, std-cell C/leakage, decap density/ESR, SRAM macro energies, OpenROAD targets |
| `configs/pcb/<board>.yaml` | regulators, per-rail plane/decaps/package caps, capacitor library, optimiser candidates |
| `configs/packages/package_library.yaml` | package families (see PACKAGE_COMPARISON.md) |
| `configs/pdn/<chip>_pdn.yaml` | on-die PDN (see ONDIE_PDN_AND_OPENROAD.md) |
| `configs/workloads/<chip>_workloads.yaml` | profiles, transient events, cycle-current shape, activity files |
| `configs/thermal/cooling.yaml` | ambient, TIMs, spreader, board, cooling options |

## 5. Reproducibility

* Deterministic: fixed seeds for every random draw (`--seed`), no wall-clock dependence.
* `manifest.json` records SHA-256 of every input file, Python/NumPy/SciPy versions, platform,
  Monte-Carlo size and seed.
* Same inputs + same seed + same library versions => identical numbers.
