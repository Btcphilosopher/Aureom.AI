# Validation and signoff plan

PowerLink is a **planning** toolkit.  This document states what has been validated, how,
and which commercial physical-signoff experiments are required before any conclusion is
used for tapeout or board release.

## 1. Numerical-solver validation (automated, `pytest`)

| Test file | What is checked | Reference |
|---|---|---|
| `tests/test_mna.py` | DC divider; KCL conservation on a random network; RC step vs exponential; trapezoidal (order 2) and backward-Euler (order 1) convergence on a sinusoidally driven RC; underdamped series RLC step vs closed form; AC RC corner and RLC resonance; VCVS/VCCS; grouped current sources | closed-form circuit theory |
| `tests/test_mna.py::test_ngspice_crosscheck_rlc_transient` | RLC droop vs ngspice | ngspice (independent simulator) |
| `tests/test_grid.py` | square sheet with uniform sink vs the Poisson series constant 0.0736713 q a^2/sigma (1 %); supply current = load current; IR linear in load; wider straps reduce drop; mesh convergence; effective sheet conductance | analytic PDE solution, conservation laws |
| `tests/test_electrical.py` | bond-wire ~1 nH/mm; plane-pair L/R; VRM crossover = target (5 %) and PM > 45 deg; buck ripple formula; LDO impedance limits; die-package resonance frequency; first-droop estimate vs simulated LC step (3 %); decap optimiser; clocked-load mean; droop monotonic in L; Black's-equation scaling; margin arithmetic | closed form / physics |
| `tests/test_power_thermal_package.py` | alpha C V^2 f for a block; leakage T/V scaling; clock gating; I/O power; VCD toggle counting incl. X handling, SAIF round-trip, block mapping; spreading-resistance limits; uniform-power thermal map = compact network; thermal CSV round-trip; package feasibility (V: QFN-88 feasible; X: wire-bond infeasible, FCBGA feasible); uncertainty sampling; power-law surrogate exactness; config validation | analytic / consistency |
| `tests/test_openroad_rtl.py` | PDN config checks; min-width violation detected; generated Tcl passes the option-level stub checker; UPF contains domains/switches; RTL testbenches pass; Verilator lint; Yosys synthesis | tool runs |

## 2. Cross-checks against an established circuit simulator (every `run`)

The circuits actually used in the analysis are exported to SPICE and simulated with
**ngspice** (`powerlink/validation.py`, report section 13):

* rail ladder DC operating point (including the averaged VRM with VCVS/VCCS),
* closed-loop |Z(f)| at 61 frequencies from 1 kHz to 1 GHz,
* load-step transient (minimum voltage and RMS waveform difference),
* on-die multi-layer grid DC solution at every node (coarse resolution).

Measured agreement on SilicaFlux-V: relative errors below about 1e-7 for every check
(see `results/*/REPORT.md` section 13).  This validates the *solver*, not the *model*.

## 3. What is NOT validated by PowerLink

* Parasitic values (package, PCB, on-die) - family-level literature ranges, not extraction.
* The homogenised on-die grid - accurate for averaged drop, blind to via-level crowding,
  rail-end effects and macro pin access.
* Activity - assumed planning values until SAIF/VCD from gate-level simulation is attached.
* Regulator models - averaged linear model; real PMIC loop, current limit, phase shedding
  and soft-start require the vendor model.
* Thermal - compact network and 2-D die conduction; no airflow, no package 3-D field.

## 4. Required commercial physical-signoff experiments

### 4.1 Static IR drop
* **Tools**: Ansys RedHawk-SC or Cadence Voltus (with Quantus/StarRC extraction).
* **Inputs**: post-route DEF/OASIS with full PG geometry, tech file and EM rule deck of the
  selected PDK, library power views (.lib/LEF/APL or CCS-power), average power from
  vectorless and SAIF-annotated analysis for each PowerLink workload, package model
  (CPM-compatible S-parameter/RLC subcircuit from 4.4), regulator model at the bumps/balls.
* **Corners**: SS/0.9 V/125 C for drop; FF/1.1 V/-40 C for current; metal RCmax.
* **Acceptance (proposal)**: worst instance drop <= 3 % VDD (the PowerLink allocation), no
  instance below library characterisation voltage; resistance-check (R-map) with no
  isolated or weakly connected cells; via/strap connectivity report clean.

### 4.2 Dynamic IR drop
* **Vectorless**: toggle-rate-based switching with timing windows, worst-cycle analysis.
* **Vectored**: VCD/FSDB from gate-level simulation of the PowerLink stress cases -
  simultaneous four-tile VMUL/DOT, tile wake (simultaneous and staggered), SRAM burst,
  and a resonance-exciting loop at the PDN anti-resonance.
* **Must include**: on-die intrinsic and explicit decap, package model, PCB/VRM reduced model.
* **Acceptance (proposal)**: effective-VDD drop <= 5 % (allocation), timing-aware DvD
  (STA with voltage-annotated delays) closes with positive slack.
* PowerLink flags the 190 MHz die-package anti-resonance near 2 x f_clk for SilicaFlux-V;
  dynamic signoff must confirm or refute the cycle-noise prediction.

### 4.3 Electromigration
* **Tools**: RedHawk-SC / Voltus power-EM and signal-EM (Totem for custom/analogue).
* **Checks**: DC (average) EM on PG straps, rails and vias with temperature-dependent limits;
  RMS and peak EM on clock and high-activity signal nets; via-count rules; Blech-length
  credit only if the foundry deck allows; bump/bond-wire current limits from the OSAT.
* **Conditions**: lifetime (e.g. 10 years), junction temperature from 4.6, worst workload duty.
* **Acceptance**: zero violations against the foundry EM deck.

### 4.4 Package parasitic extraction
* **Tools**: Ansys SIwave / Q3D Extractor / HFSS, or Cadence Sigrity PowerSI / XtractIM / Clarity.
* **Deliverables**: per-rail PDN S-parameters (bump-to-ball, DC-to >= 5 GHz), lumped RLC
  per rail for early use, bond-wire 3-D extraction (QFN/WB-BGA), plane-resonance scan,
  per-pin R/L/C and coupling matrices for signal I/O, DC IR drop in the substrate.
* **Use**: replace PowerLink's `package_library.yaml` values; re-run PowerLink and signoff 4.1/4.2.

### 4.5 Signal integrity
* **Tools**: Keysight ADS, Cadence Sigrity SystemSI / Clarity, Siemens HyperLynx.
* **Scope**: chiplet link (tile_interface PHY) and SPI flash with IBIS(-AMI) models of the
  I/O cells, package S-parameters and the PCB channel; eye diagrams/BER at the target rate,
  crosstalk, and simultaneous-switching output (SSO) with the power-aware IBIS model and
  the real VDDIO/VSSIO pin assignment.
* **Acceptance**: eye margins per interface spec; SSO ground bounce below the input
  threshold margin (PowerLink screening limit 10 % VDDIO; QFN-88 fails this at the fast-edge corner).

### 4.6 Thermal signoff
* **Tools**: Ansys Icepak or RedHawk-SC Electrothermal, Cadence Celsius, Siemens Simcenter FloTHERM.
* **Setup**: JESD51 environments (natural convection 51-2, board 51-7) and the real enclosure,
  die power maps from 4.1/4.2 per workload, package and heatsink CAD, TIM data from the vendor.
* **Outputs**: T_j maps, theta_ja / psi_jt for the datasheet, hotspot location; export as CSV
  (`x_um,y_um,temp_c`) and import with `powerlink thermal-import` to close the
  leakage-temperature loop in PowerLink.
* **Acceptance**: T_j <= 105 C (planning limit) at worst ambient with margin for
  leakage uncertainty; no thermal runaway.

### 4.7 Bench validation (post-silicon)
* PDN impedance measurement (2-port shunt-through VNA) at the package balls/pins.
* Load-step droop with an on-board electronic load and on-die droop detectors / ring-oscillator sensors.
* Power per workload with real firmware; compare to PowerLink (update activity assumptions).
* Thermal: T_j via on-die diode/sensor versus PowerLink and CFD.
