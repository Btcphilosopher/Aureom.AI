# On-die PDN configuration and OpenROAD script generation

One YAML file per chip (`configs/pdn/<chip>_pdn.yaml`) describes the on-die power grid.
It drives both the PowerLink grid solver and the OpenROAD script generator, so the analysed
grid and the implemented grid are the same description.

## Schema

```yaml
analysis: {static_resolution_um, dynamic_resolution_um, metal_temperature_c}
regions:  {name: [x0, y0, x1, y1]}            # core coordinates, um
nets:                                          # one entry per PG net
  VDD_CORE: {type: power, rail: VDD_CORE, region: core | [r1, r2], exclude: [pll_keepout],
             layers: [M1, M6, M8, M9]}
  VSS:      {type: ground, region: core, layers: [...]}
voltage_domains:                               # for OpenROAD set_voltage_domain and UPF
  CORE:  {power: VDD_CORE, ground: VSS, region: core, contains: [cpu, vector, tensor, sram_tile, ...]}
  PLL:   {power: VDDA_PLL, ground: VSSA, region: pll_keepout, analog: true}
  TILES: {power: VDD_TILE, ground: VSS, region: tiles_s, switched_power: VDD_TILE_SW}   # power-gated
layers:                                        # bottom -> top; alternate directions
  - {name: M1, role: followpin, direction: H, width_um, pitch_um}
  - {name: M6, role: strap, direction: V, width_um, pitch_um, offset_um, spacing_um}
vias:     [{from: M1, to: M6, levels: [low, low, ...], cuts_per_level: 2}]
rings:    [{name, layers: [M8, M9], width_um, spacing_um, core_offset_um, nets, via_cuts_per_strap_end}]
macros:   {pattern: "*sram*", halo_um, pin_layer: M6, blocked_layers: [M1]}
supply:   {wire_bond: {pads_per_side: {...}, pad_to_ring_ohm}, flip_chip: {bump_to_grid_ohm, pattern}}
decap:    {logic_fill_fraction, regions: [{name, rail, rect_um, fill_fraction}]}
openroad: {stdcell_power_pin, stdcell_ground_pin, macro_instance_pattern, pdk_targets: [generic, sky130, gf180mcu]}
```

Floorplan blocks (chip file) carry the rail, rectangle, kind (`logic`/`sram`/`analog`) and
group (`cpu`, `vector`, `tensor`, `sram_tile`, ...), which defines the **CPU supply region,
SRAM supply regions, vector/tensor power domains** and **macro power pins** used by both the
solver and the generator.  Decoupling regions are explicit rectangles plus a logic fill fraction.

## Checks (`check_pdn`)

Minimum width per layer, nets x width + spacing fitting in the pitch, preferred direction,
alternating directions, two-layer rings, macro pin layer modelled, and PG track usage per
layer (warning above 50 %, computed from nets that actually coexist).  These are
configuration sanity checks, **not DRC**.

## Generated outputs (`openroad/`)

* `pdn_<chip>_<target>.tcl`: `add_global_connection` (std cells, analogue macro pins),
  `global_connect`, `set_voltage_domain`, `define_pdn_grid` (std-cell grid per domain and a
  default macro grid with halo), `add_pdn_ring`, `add_pdn_stripe` (followpins, straps with
  pitch/offset/spacing, `-extend_to_core_ring`), `add_pdn_connect`, `pdngen`.
* `<chip>_power_intent.upf`: supply ports/nets, power domains, power switches and isolation
  for switched domains, port states.

Targets: `generic` (abstract layer names) and, for SilicaFlux-V, `sky130` and `gf180mcu`
layer maps so the scripts can be *exercised* in OpenROAD-flow-scripts.  Unmapped layers are
dropped with a warning and rings fall back to the two highest mapped layers.  sky130 and
gf180mcu are 130/180 nm processes used only as flow vehicles; they are not electrical
stand-ins for 65 nm.

## Verification performed

Each script is sourced by `tclsh` against stub implementations of the OpenROAD PDN commands
(`scripts/openroad_stub_check.tcl`) that reject unknown options and missing values.  This
proves Tcl syntax and option spelling only.  OpenROAD itself was not run here: whether
`pdngen` accepts the grid for a given database, whether vias are legal and whether the
result is DRC/LVS clean can only be established with the chosen PDK and an actual
implementation run.  **No DRC correctness is asserted.**

Typical next steps with a real PDK: map layer names and widths to the tech LEF, set
followpin width to the library rail width, run `pdngen -report_only`, then `pdngen`,
`check_power_grid -net VDD_CORE`, `analyze_power_grid` (OpenROAD PSM) and compare with
PowerLink's static IR before commercial signoff.
