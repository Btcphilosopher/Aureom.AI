# Package comparison methodology

Options in `configs/packages/package_library.yaml` (family-level literature ranges, tagged):

| Key | Family | Die connection | Body / pins | Typical role |
|---|---|---|---|---|
| `wb_qfn88` | wire-bond QFN | Au bond wires, VSS down-bonds to exposed pad | 10 mm, 88 leads | lowest cost prototype |
| `wb_bga256` | wire-bond BGA | bond wires to laminate rings/planes | 17 mm, 256 balls | more I/O, still wire-bond |
| `fc_bga` | flip-chip BGA | C4 area-array bumps (150 um) | 15 mm, 324 balls | low-inductance PDN, higher power |
| `adv_organic` | advanced organic substrate | 40-55 um micro-bumps, fine-line RDL | 20 mm, 900 balls | chiplet-ready, high I/O density |
| `si_interposer` | 2.5D silicon interposer | 36-55 um micro-bumps, TSVs, optional deep-trench caps | 35 mm, 2500 balls | future multi-die variants |

## Hard constraints (pass/fail, evaluated at nominal and at the adverse corner)

1. **Pin budget**: signals + power/ground pins (allocation rules in docs/MODELLING.md) +
   spare fraction <= available leads/balls.
2. **Die size** <= package maximum; **pad ring** (wire-bond: 4 x (edge - corners)/pad pitch) or
   **bump array** (area/pitch^2) capacity.
3. **Core package DC drop** <= half the DC-IR allocation.
4. **First-droop bound** `dI sqrt(L_first / C_die)` <= dynamic allocation, where L_first is the
   die-connection inductance plus the lower of (pins + substrate) and the package-capacitor
   ESL, and dI is the full rail swing or, if `package_study.design_delta_i_event` names a
   staggered event, its per-step swing.
5. **Connection current**: per-bump/wire and per-pin current <= limit.
6. **Signal-integrity rate**: required data rate <= package family capability.
7. **SSO ground bounce**: `L_eff N di/dt` <= 10 % of VDDIO, `i_pk = 1.5 C V_swing / t_r`.
8. **Thermal**: T_j at maximum workload and worst ambient <= limit for at least one cooling option.

## Scores (feasible options only)

Weighted sum (weights in `packaging/compare.py`, overridable per chip):
electrical 0.30 (first-droop and DC headroom), signal integrity 0.15 (rate headroom, SSO),
thermal 0.20 (best passive T_j headroom), cost 0.25 (log of unit + NRE/volume), availability
0.10.  A package is **robust** only if every constraint also passes at the adverse corner.

## Caveats

Library values are not quotes or extracted parasitics.  Before selection: obtain the OSAT
design kit, extract the real substrate (docs/VALIDATION_AND_SIGNOFF.md 4.4) and re-run.
Costs are indicative and volume-dependent; NRE for interposers is dominated by foundry
programme access.
