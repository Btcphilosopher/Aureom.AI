# Power-up controller specification (proposed)

Status: **proposal**, implemented as synthesizable SystemVerilog in `rtl/` and verified by
self-checking simulation (`scripts/sim_rtl.sh`), Verilator lint (`scripts/lint_rtl.sh`) and
generic Yosys synthesis (`scripts/synth_rtl.sh`).  Board PMIC hardware performs all voltage
regulation; nothing in this specification regulates a voltage.

## 1. Partitioning

| Function | SilicaFlux-V (single digital core domain) | Future variants with an always-on (AON) domain |
|---|---|---|
| Voltage regulation | Board PMIC / regulators | Board PMIC / regulators |
| Rail enable sequencing | PMIC built-in sequencer **or** board CPLD running `sf_pwr_seq` | `sf_pwr_seq` in the AON domain driving PMIC enables (GPIO/PMBus) or on-die power-switch controls |
| Power-good monitoring | PMIC PG outputs, combined into `PG_IN` pad | `sf_pwr_seq` per-rail PG inputs |
| Reset assertion / release | `sf_rst_clk_ctrl` on chip (VDD_CORE domain) | `sf_rst_clk_ctrl` per switchable domain + `sf_pwr_seq.sys_rst_n` |
| Clock readiness | `sf_rst_clk_ctrl` (PLL enable, lock, glitch-free mux select) | same |
| Brown-out | PMIC/supervisor UV warning on `BOR_N` pad -> `sf_rst_clk_ctrl` | `sf_pwr_seq.uv_warn_n` + `sf_rst_clk_ctrl` |
| Fault shutdown / safe restart | PMIC (rails) + `sf_rst_clk_ctrl` (resets/clocks) | `sf_pwr_seq` (rails) + `sf_rst_clk_ctrl` |

Rationale: logic that enables a rail cannot be powered by that rail.  SilicaFlux-V has one
digital domain, so rail sequencing must live off-chip; the on-chip block starts working once
VDD_CORE is valid and is held in reset by the on-die POR until then.

## 2. Rail order (SilicaFlux-V)

| Step | Rail | Nominal | Enable after | PG timeout | Stable time before next | Notes |
|---|---|---|---|---|---|---|
| 1 | VDDIO | 3.3 V | system power request | 5 ms | 1 ms | input to the core buck and PLL LDO, therefore first; I/O cells must provide power-on control (POC) so pads stay Hi-Z while the core is unpowered - **confirm with the I/O library** |
| 2 | VDD_CORE | 1.0 V | PG(VDDIO) stable | 5 ms | 1 ms | monotonic ramp 0.1-10 ms (PMIC soft-start); in-rush limited by soft-start |
| 3 | VDDA_PLL | 1.0 V | PG(VDD_CORE) stable | 2 ms | 0.5 ms | low-noise LDO; PLL held disabled until on-chip controller enables it |
| - | reset release | - | all PG stable + T_RST_HOLD | - | - | then `sf_rst_clk_ctrl` sequences PLL, clocks and resets |

Power-down is the exact reverse: assert reset, stop/gate clocks, disable VDDA_PLL, then
VDD_CORE, then VDDIO, each after its discharge wait (`T_OFF`) or PG low.

For SilicaFlux-X (hypothetical) the order is VDDIO -> VDD_SRAM -> VDD_CPU -> VDD_TILE -> VDDA_PLL
(SRAM array supply never below the periphery supply, avoiding bit-cell disturb), reverse on power-down.

## 3. `sf_pwr_seq` - N-rail sequencer

Parameters (cycles of the AON clock): `N_RAILS`, per-rail `T_PG_TIMEOUT`, `T_STABLE`, `T_OFF`
(packed vectors), `T_RST_HOLD`, `T_RST_TO_OFF`, `T_BO_MAX`, `T_COOLDOWN`, `T_RETRY_CLEAR`,
`MAX_RETRIES`, `FILTER`.

Inputs are asynchronous and pass through two-flop synchronisers and a debounce filter
(`sf_pg_filter`): a change is accepted only after `FILTER` identical consecutive samples;
shorter excursions are reported as glitches and counted (`glitch_count_o`), never acted on.

| State | Outputs | Exit |
|---|---|---|
| OFF | all EN=0, reset low | `pwr_on_req` & no over-temperature -> RAMP(rail 0) |
| RAMP(k) | EN[0..k]=1 | PG[k] good -> STABLE(k); timeout -> fault PG_TIMEOUT; PG[j<k] lost -> fault PG_LOST; OT -> fault OVERTEMP |
| STABLE(k) | | `T_STABLE[k]` elapsed with PG[0..k] good -> RAMP(k+1) or RST_HOLD |
| RST_HOLD | `sys_pwr_good`=1, reset low | `T_RST_HOLD` -> RUN |
| RUN | reset released | off request -> graceful shutdown; PG lost -> fault; OT -> fault; UV warning -> BROWNOUT |
| BROWNOUT | reset asserted **immediately**, rails stay on | UV cleared -> RST_HOLD (warm restart); PG lost -> fault; `T_BO_MAX` -> fault BROWNOUT_TIMEOUT |
| SHDN_RST | reset low, PG-good low | `T_RST_TO_OFF` -> SHDN_RAIL |
| SHDN_RAIL / SHDN_WAIT | EN[k]=0, wait PG low or `T_OFF[k]`, k decrements | k=0 -> COOLDOWN (fault) or OFF (graceful) |
| COOLDOWN | all off | `T_COOLDOWN`; retries < MAX and no OT -> RAMP(0) with retries+1; retries = MAX -> LOCKOUT |
| LOCKOUT | all off, reset low | `fault_clear` -> OFF |

The retry counter is cleared after `T_RETRY_CLEAR` cycles of uninterrupted RUN, so a
genuinely recovered system is not locked out by an old event, while a fault that recurs
during start-up exhausts the retries.  Fault code and failing rail are latched for
diagnostics (`fault_o`, `fault_rail_o`).

## 4. `sf_rst_clk_ctrl` - on-chip reset and clock readiness (SilicaFlux-V)

Runs on the reference oscillator clock (`clk_ref`) so it works before the PLL locks.

| State | Action | Exit / timing |
|---|---|---|
| RESET | after `por_n` release | -> WAIT_PG |
| WAIT_PG | everything held in reset | `PG_IN` and `BOR_N` stable for `T_PG_STABLE` -> PLL_START |
| PLL_START | `pll_en`=1 (unless bypass strap) | `T_PLL_SETTLE` -> release `pll_rst_n` -> WAIT_LOCK |
| WAIT_LOCK | | lock (debounced) -> CLK_SWITCH; `T_LOCK_TIMEOUT` -> fault PLL_LOCK_TIMEOUT |
| CLK_SWITCH | `clk_sel_pll` to the glitch-free clock mux | `T_CLKSW` -> `clk_ready`, REL_PERIPH |
| REL_PERIPH | peripheral/debug reset released | `T_RST_STAGGER` -> REL_CPU |
| REL_CPU | CPU and tile resets released | -> RUN |
| RUN | tile clock enables follow `tile_req`, **one tile change per `T_TILE_STAGGER`** | lock loss -> fault PLL_LOCK_LOST |
| BROWNOUT | entered from any active state on `BOR_N` low or `PG_IN` low | supplies stable `T_PG_STABLE` -> PLL_START |
| FAULT_WAIT | resets low, PLL off, ref clock selected | `T_FAULT_WAIT`; retry (PLL restart) or LOCKOUT after `MAX_RETRIES` |
| LOCKOUT | held in reset | only `por_n` exits |

* **Brown-out**: `BOR_N` low asserts every core-domain reset *asynchronously* (it feeds the
  asynchronous input of each reset synchroniser) and clears the tile clock-enable
  registers, so no state is corrupted while the supply collapses; release is synchronous.
* **Reset release** uses asynchronous-assert / synchronous-deassert synchronisers
  (`sf_rst_sync`) in the `clk_core` domain.
* **di/dt control**: the staggered tile enable is a power-integrity feature.  PowerLink's
  transient analysis (`tiles_wake_staggered` vs `tiles_wake_simultaneous`) quantifies the
  droop reduction; the stagger interval in the workload file (400 ns) matches
  `T_TILE_STAGGER` = 10 cycles of a 25 MHz reference.
* **CDC**: `tile_req` (core domain) is synchronised into `clk_ref`; tile enables are
  synchronised into `clk_core` before the clock-gating cells.  First-stage flops should map
  to the library synchroniser cell and be covered by CDC verification.

## 5. Timing parameters (SilicaFlux-V proposal, 25 MHz reference)

| Parameter | Cycles | Time | Basis |
|---|---|---|---|
| T_PG_STABLE | 2500 | 100 us | > PMIC PG de-glitch; board-dependent |
| T_PLL_SETTLE | 250 | 10 us | PLL IP datasheet (placeholder) |
| T_LOCK_TIMEOUT | 25000 | 1 ms | 10x typical lock time of the foundry PLL (placeholder) |
| T_CLKSW | 16 | 640 ns | glitch-free mux settling |
| T_RST_STAGGER | 8 | 320 ns | peripheral/boot ROM ahead of CPU |
| T_TILE_STAGGER | 10 | 400 ns | PowerLink droop analysis |
| FILTER | 4 | 160 ns | debounce of PG/BOR/lock |
| MAX_RETRIES | 3 | - | then lockout |

Testbench parameters are scaled down to keep simulations short; the RTL is fully parameterised.

## 6. Verification evidence

* `rtl/tb/tb_sf_pwr_seq.sv`: power-up order and PG gating; PG glitch rejection; brown-out
  warm restart with rails held; PG loss -> reverse-order shutdown with reset first, cool-down,
  retry; repeated PG timeout -> lockout and `fault_clear`; over-temperature hold-off;
  graceful power-off.  Result: `TB_SF_PWR_SEQ: PASS`.
* `rtl/tb/tb_sf_rst_clk_ctrl.sv`: lock-before-switch, periph-before-CPU reset release,
  tile-enable spacing >= `T_TILE_STAGGER`, asynchronous reset on brown-out with recovery,
  lock loss retry, lock timeout lockout, POR exit, PLL bypass.  Result:
  `TB_SF_RST_CLK_CTRL: PASS`.
* Verilator `-Wall` lint clean; Yosys generic synthesis with `check -assert` clean
  (sf_pwr_seq ~1.35 k generic cells / 118 flops, sf_rst_clk_ctrl ~0.9 k cells / 91 flops).

Not yet done (required before tapeout): formal property checking of the FSMs (e.g. SBY),
CDC/RDC analysis with a commercial or open tool, gate-level simulation with SDF, and
integration with the PMIC vendor's sequencing configuration and power-good timing.
