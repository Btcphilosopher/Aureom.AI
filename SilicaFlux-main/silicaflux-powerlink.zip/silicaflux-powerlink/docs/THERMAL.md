# Thermal coupling

## Compact network (`thermal/model.py::compact_network`)

Two parallel paths from junction to ambient:

| Path | Wire-bond (face-up) | Flip-chip (lidded) |
|---|---|---|
| top | theta_jc,top + (TIM2/A_pkg + R_sa) or 1/(h A_pkg) without heatsink | TIM1''/A_die + R_lid |
| bottom | theta_jc,bottom (exposed pad / thermal balls) + R_board | theta_jc,bottom (balls) + R_board |

`theta_ja = R_top || R_bottom`.  The lid (heat spreader) uses the Lee-Song-Au-Moran
average-temperature spreading resistance for a source of area-equivalent radius a on a plate
of radius b, thickness t, conductivity k, cooled by `h_eff = 1/(TIM2'' + R_sa A_lid)`:

```
eps = a/b, tau = t/b, Bi = h b / k, lambda_c = pi + 1/(sqrt(pi) eps)
phi_c = (tanh(lambda_c tau) + lambda_c/Bi) / (1 + (lambda_c/Bi) tanh(lambda_c tau))
psi = 0.5 (1 - eps)^1.5 phi_c,   R_sp = psi / (sqrt(pi) k a)
R = R_sp + t/(k pi b^2) + 1/(h pi b^2)
```

The report compares the computed flip-chip theta_jc,top with the library (large-die) value;
for the 2.5 mm SilicaFlux-V die the computed value is much higher (TIM1 over a small area),
which is physically expected.

## Die power map (`solve_die_temperature`)

2-D finite-volume conduction in silicon (k(T) = 148 (300/T)^1.3 W/m.K, die thickness from
the chip file) on a die-level power map (blocks + I/O ring power), mid-plane nodes, uniform
area-specific boundary conductance to ambient equal to theta_ja less half the die's 1-D
vertical resistance.  Exact for uniform power (unit-tested); resolves lateral hotspot
spreading; does not resolve the package/heatsink 3-D field.

## Electro-thermal coupling (`electro_thermal`)

Iterate leakage(T) -> power map -> temperature map -> block temperatures until the change is
below 0.01 C.  Divergence (T > 200 C) is reported as thermal runaway, never clipped.  The
cooling comparison applies the same fixed point to every package x cooling option at the
worst ambient.

## Assumptions

Cooling options (natural convection, small/large passive heatsink, active heatsink,
vapour chamber), TIM1/TIM2, lid, die-attach and board resistances are generic literature
ranges in `configs/thermal/cooling.yaml`; ambient 25 C nominal, 70 C worst; T_j limit 105 C.

## Importing specialist results

Export a temperature map from Icepak / Celsius / FloTHERM / RedHawk-SC-ET as CSV with
columns `x_um, y_um, temp_c` (die coordinates):

```
python -m powerlink thermal-import --chip configs/chips/silicaflux_v.yaml --csv icepak.csv --out block_temps.json
```

Scattered points are resampled (linear, nearest outside the hull) to block temperatures,
which can be passed to the power model (`evaluate_workload(..., temp_c=block_temps)`).  Each
PowerLink run writes its own map in the same format (`thermal_map_export.csv`).
