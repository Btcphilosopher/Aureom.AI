"""SilicaFlux PowerLink - power-integrity, package and PCB co-design toolkit for SilicaFlux processors."""
__version__ = "0.1.0"
