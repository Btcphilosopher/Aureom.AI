"""Block-level power model.

Dynamic (switching) power, per block::

    P_data  = alpha * C_sw * V^2 * f          C_sw = N_GE * c_sw_per_GE
    P_clock = g_clk * C_clk * V^2 * f          C_clk = N_flops * c_clk_per_flop
    P_sram  = (reads * E_read + writes * E_write) * f * (V / V_char)^2

Leakage (static, technology dependent, reported separately)::

    I_leak(T, V) = I_ref(25 C) * 2^((T - 25)/T_double) * 10^((V - V_nom)/S_dibl)
    P_leak = V * I_leak

``alpha`` is the 0->1 transition probability per cycle (see
configs/workloads).  Every input carries an uncertainty range; scale
factors exposed through :func:`power_parameters` are used by the
Monte-Carlo machinery.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional

import numpy as np

from ..config import Project
from ..uncertainty import ParameterSet, nom, parse_value
from .activity import BlockActivity


@dataclass
class BlockPower:
    name: str
    group: str
    rail: str
    kind: str
    p_data_w: float = 0.0
    p_clock_w: float = 0.0
    p_sram_w: float = 0.0
    p_fixed_w: float = 0.0
    p_leak_w: float = 0.0
    alpha: float = 0.0
    clock_enable: float = 0.0
    activity_source: str = "assumption"
    temp_c: float = 25.0
    v: float = 0.0

    @property
    def p_dyn_w(self) -> float:
        return self.p_data_w + self.p_clock_w + self.p_sram_w

    @property
    def total_w(self) -> float:
        return self.p_dyn_w + self.p_fixed_w + self.p_leak_w

    @property
    def current_a(self) -> float:
        return self.total_w / self.v if self.v > 0 else 0.0


@dataclass
class PowerResult:
    profile: str
    blocks: List[BlockPower]
    io: Dict[str, float]               # VDDIO interface power (W)
    rails_v: Dict[str, float]
    io_rail: str = "VDDIO"

    def rail_power(self, rail: str) -> float:
        p = sum(b.total_w for b in self.blocks if b.rail == rail)
        if rail == self.io_rail:
            p += sum(self.io.values())
        return p

    def rail_current(self, rail: str) -> float:
        return self.rail_power(rail) / self.rails_v[rail]

    def total_w(self) -> float:
        return sum(self.rail_power(r) for r in self.rails_v)

    def breakdown(self) -> Dict[str, float]:
        return {"data": sum(b.p_data_w for b in self.blocks),
                "clock": sum(b.p_clock_w for b in self.blocks),
                "sram": sum(b.p_sram_w for b in self.blocks),
                "fixed/analog": sum(b.p_fixed_w for b in self.blocks),
                "leakage": sum(b.p_leak_w for b in self.blocks),
                "io": sum(self.io.values())}

    def by_block(self) -> Dict[str, BlockPower]:
        return {b.name: b for b in self.blocks}

    def activity_sources(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for b in self.blocks:
            out[b.activity_source] = out.get(b.activity_source, 0) + 1
        return out


def leakage_scale(temp_c: float, v: float, v_nom: float, t_double: float, s_dibl: float,
                  t_ref: float = 25.0) -> float:
    return 2.0 ** ((temp_c - t_ref) / t_double) * 10.0 ** ((v - v_nom) / s_dibl)


def power_parameters(p: Project) -> ParameterSet:
    """Scale-factor parameters (nominal 1.0) spanning the configured ranges."""
    sc = p.technology["stdcell"]
    ps = ParameterSet()

    def ratio(v: Any) -> Dict[str, float]:
        u = parse_value(v)
        return {"nom": 1.0, "min": u.min / u.nom, "max": u.max / u.nom, "source": u.source,
                "dist": u.dist if u.dist != "fixed" else "uniform"}

    act = p.workloads.get("assumed_activity_scale", 1.0)
    ps.add("activity_scale", ratio(act), adverse_high=True, group="power")
    ps.add("csw_scale", ratio(sc["c_sw_per_ge_ff"]), adverse_high=True, group="power")
    ps.add("clk_cap_scale", ratio(sc["c_clk_per_flop_ff"]), adverse_high=True, group="power")
    ps.add("leak_scale", ratio(sc["leak_per_ge_na_25c"]), adverse_high=True, group="power")
    # gate count uncertainty: use the first logic block's relative range as a global scale
    kge_vals = [parse_value(b["kge"]) for b in p.blocks if "kge" in b]
    if kge_vals:
        lo = min(u.min / u.nom for u in kge_vals)
        hi = max(u.max / u.nom for u in kge_vals)
        ps.add("kge_scale", {"nom": 1.0, "min": lo, "max": hi, "source": "assumption"}, True, "power")
    macros = p.technology.get("sram", {}).get("macro_types", {})
    if macros:
        first = next(iter(macros.values()))
        ps.add("sram_energy_scale", ratio(first["read_pj"]), True, "power")
    return ps


def evaluate_workload(p: Project, profile: str, temp_c: Any = 25.0,
                      rail_v: Optional[Mapping[str, float]] = None,
                      scales: Optional[Mapping[str, float]] = None,
                      measured: Optional[Mapping[str, BlockActivity]] = None) -> PowerResult:
    """Power of every block for one workload profile.

    ``temp_c`` is a scalar or a mapping block-name -> temperature (from the
    thermal model).  ``measured`` maps block names to activity extracted
    from VCD/SAIF, which overrides the assumed alpha.
    """
    scales = dict(scales or {})
    s = lambda k: float(scales.get(k, 1.0))  # noqa: E731
    tech = p.technology
    sc = tech["stdcell"]
    f = p.clock_hz
    rails = {r: (rail_v or {}).get(r, nom(cfg["nominal_v"])) for r, cfg in p.rails.items()}
    prof = p.workloads["profiles"][profile]["activity"]
    c_ge = nom(sc["c_sw_per_ge_ff"]) * 1e-15 * s("csw_scale")
    c_ff = nom(sc["c_clk_per_flop_ff"]) * 1e-15 * s("clk_cap_scale")
    leak_ge = nom(sc["leak_per_ge_na_25c"]) * 1e-9 * s("leak_scale")
    t_double = nom(sc["leak_temp_doubling_c"])
    s_dibl = nom(sc["leak_dibl_v_per_decade"])
    macros = tech.get("sram", {}).get("macro_types", {})
    blocks: List[BlockPower] = []
    for b in p.blocks:
        name, group, rail = b["name"], b.get("group", b["name"]), b["rail"]
        v = rails[rail]
        v_nom = nom(p.rails[rail]["nominal_v"])
        t = temp_c[name] if isinstance(temp_c, Mapping) else float(temp_c)
        bp = BlockPower(name, group, rail, b["kind"], temp_c=t, v=v)
        act = dict(prof.get(name, prof.get(group, prof.get("default", {}))))
        if b["kind"] == "logic":
            kge = nom(b["kge"]) * 1e3 * s("kge_scale")
            alpha = nom(act.get("alpha", 0.0)) * s("activity_scale")
            src = "assumption"
            if measured and name in measured:
                alpha = measured[name].alpha
                src = measured[name].source
            g_clk = nom(act.get("clock_enable", 1.0))
            bp.alpha, bp.clock_enable, bp.activity_source = alpha, g_clk, src
            bp.p_data_w = alpha * kge * c_ge * v * v * f
            bp.p_clock_w = g_clk * float(b.get("flops", 0)) * c_ff * v * v * f
            bp.p_leak_w = v * kge * leak_ge * leakage_scale(t, v, v_nom, t_double, s_dibl)
        elif b["kind"] == "sram":
            m = macros[b["macro"]]
            rd = min(nom(act.get("reads_per_cycle", 0.0)) * s("activity_scale"), 1.0)
            wr = min(nom(act.get("writes_per_cycle", 0.0)) * s("activity_scale"), 1.0)
            e = (rd * nom(m["read_pj"]) + wr * nom(m["write_pj"])) * 1e-12 * s("sram_energy_scale")
            bp.p_sram_w = e * f * (v / v_nom) ** 2
            bp.alpha = rd + wr
            bp.clock_enable = 1.0
            bp.p_leak_w = v * nom(m["leak_ua_25c"]) * 1e-6 * s("leak_scale") * \
                leakage_scale(t, v, v_nom, t_double, s_dibl)
        elif b["kind"] == "analog":
            bp.p_fixed_w = nom(b.get("fixed_power_mw", 0.0)) * 1e-3
            bp.activity_source = "assumption"
        else:
            raise ValueError(f"unknown block kind {b['kind']}")
        blocks.append(bp)
    io = io_power(p, rails, p.workloads["profiles"][profile].get("io_activity", {}))
    return PowerResult(profile, blocks, io, rails, p.chip.get("io", {}).get("io_rail", "VDDIO"))


def io_power(p: Project, rails: Mapping[str, float],
             activity_override: Optional[Mapping[str, Any]] = None) -> Dict[str, float]:
    """I/O switching power: P = pins * alpha * C_load * V_io^2 * f_data.

    ``activity_override`` (from the workload profile's ``io_activity``)
    replaces the interface default alpha for that workload."""
    activity_override = activity_override or {}
    io = p.chip.get("io", {})
    rail = io.get("io_rail", "VDDIO")
    if rail not in rails:
        return {}
    v = rails[rail]
    out = {}
    for name, sig in io.get("signals", {}).items():
        alpha = nom(activity_override.get(name, sig.get("activity", 0.0)))
        out[name] = (nom(sig["pins"]) * alpha * nom(sig.get("load_pf", 0.0)) * 1e-12
                     * v * v * nom(sig.get("rate_mbps", 0.0)) * 1e6)
    return out


def switched_capacitance(p: Project, block: Mapping[str, Any], scales: Optional[Mapping[str, float]] = None) -> float:
    """Total switchable capacitance of a logic block (alpha = 1), farads."""
    scales = scales or {}
    sc = p.technology["stdcell"]
    if block["kind"] != "logic":
        return 0.0
    return nom(block["kge"]) * 1e3 * nom(sc["c_sw_per_ge_ff"]) * 1e-15 * scales.get("csw_scale", 1.0) \
        * scales.get("kge_scale", 1.0)


def block_intrinsic_decap(p: Project, b: Mapping[str, Any], scales: Optional[Mapping[str, float]] = None) -> float:
    """Intrinsic decoupling of one block: a fraction of the switchable capacitance of a
    logic block, or the array capacitance of an SRAM macro (technology file)."""
    scales = scales or {}
    if b["kind"] == "logic":
        frac = nom(p.technology["stdcell"]["intrinsic_decap_fraction"]) * scales.get("intrinsic_scale", 1.0)
        return frac * switched_capacitance(p, b, scales)
    if b["kind"] == "sram":
        m = p.technology.get("sram", {}).get("macro_types", {}).get(b.get("macro"), {})
        return nom(m.get("intrinsic_decap_pf", 0.0)) * 1e-12
    return 0.0


def intrinsic_decap(p: Project, rail: str, scales: Optional[Mapping[str, float]] = None) -> float:
    """Non-switching gate/well/array capacitance acting as decap on ``rail`` (F)."""
    return sum(block_intrinsic_decap(p, b, scales) for b in p.blocks if b["rail"] == rail)


def all_profiles(p: Project, temp_c: Any = 25.0, **kw) -> Dict[str, PowerResult]:
    return {name: evaluate_workload(p, name, temp_c=temp_c, **kw) for name in p.workloads["profiles"]}
