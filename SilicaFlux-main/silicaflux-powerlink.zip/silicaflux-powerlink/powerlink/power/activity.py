"""Switching-activity import: VCD and SAIF parsers, VCD->SAIF conversion,
and mapping of hierarchical nets onto floorplan blocks.

PowerLink never invents activity measurements: when no activity file is
attached, workload alphas are taken from the configuration and tagged
``source=assumption``.  When a file is attached, the measured toggle rates
replace the assumptions for the blocks that the file covers and are tagged
``source=vcd`` / ``source=saif``.

Toggle-rate convention: TC counts 0<->1 transitions of each bit (transitions
through X/Z are counted in TX-related statistics, not in TC).  Toggle rate per
clock cycle TR = TC / (bits * cycles); alpha (0->1 probability per cycle) =
TR / 2.
"""
from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple, Union

TIMESCALE_S = {"s": 1.0, "ms": 1e-3, "us": 1e-6, "ns": 1e-9, "ps": 1e-12, "fs": 1e-15}


@dataclass
class NetActivity:
    name: str                 # full hierarchical name, '.'-separated
    width: int = 1
    tc: int = 0               # 0<->1 toggles summed over bits
    t0: float = 0.0           # time (in timescale units) summed over bits at 0
    t1: float = 0.0
    tx: float = 0.0
    ig: int = 0               # transitions involving X/Z

    def toggle_rate(self, cycles: float) -> float:
        return self.tc / (self.width * cycles) if cycles > 0 else 0.0

    def static_probability(self) -> float:
        tot = self.t0 + self.t1
        return self.t1 / tot if tot > 0 else 0.0


@dataclass
class ActivityData:
    nets: Dict[str, NetActivity]
    duration: float                   # in timescale units
    timescale_s: float
    source: str                       # 'vcd' | 'saif'
    file: str = ""

    @property
    def duration_s(self) -> float:
        return self.duration * self.timescale_s

    def cycles(self, f_clk_hz: float) -> float:
        return self.duration_s * f_clk_hz


# ============================================================================
# VCD
# ============================================================================
def _vcd_tokens(text: str) -> Iterator[str]:
    for tok in text.split():
        yield tok


def _expand(value: str, width: int) -> str:
    if len(value) >= width:
        return value[-width:]
    pad = value[0] if value[0] in "xXzZ" else "0"
    return pad * (width - len(value)) + value


def parse_vcd(path: Union[str, Path], include: Optional[Sequence[str]] = None) -> ActivityData:
    """Parse a four-state VCD file and accumulate per-net toggle statistics.

    ``include`` optionally restricts accumulation to hierarchical names
    matching any of the fnmatch patterns (reduces memory on large dumps).
    """
    path = Path(path)
    text = path.read_text(errors="replace")
    toks = _vcd_tokens(text)
    scope: List[str] = []
    timescale = 1e-9
    id_vars: Dict[str, List[Tuple[str, int]]] = {}
    # header -----------------------------------------------------------------
    for tok in toks:
        if tok == "$timescale":
            parts = []
            for t in toks:
                if t == "$end":
                    break
                parts.append(t)
            ts = "".join(parts)
            m = re.match(r"(\d+)\s*([a-z]+)", ts)
            if not m:
                raise ValueError(f"bad $timescale '{ts}'")
            timescale = int(m.group(1)) * TIMESCALE_S[m.group(2)]
        elif tok == "$scope":
            _kind = next(toks)
            name = next(toks)
            scope.append(name)
            next(toks)  # $end
        elif tok == "$upscope":
            scope.pop()
            next(toks)
        elif tok == "$var":
            _vtype = next(toks)
            width = int(next(toks))
            code = next(toks)
            ref = next(toks)
            rest = []
            for t in toks:
                if t == "$end":
                    break
                rest.append(t)
            full = ".".join(scope + [ref])
            if include and not any(fnmatch.fnmatch(full, p) for p in include):
                continue
            id_vars.setdefault(code, []).append((full, width))
        elif tok == "$enddefinitions":
            next(toks)
            break
        elif tok.startswith("$") and tok not in ("$dumpvars", "$end", "$dumpall", "$dumpon", "$dumpoff"):
            for t in toks:  # skip $date/$version/$comment bodies
                if t == "$end":
                    break
    # body ---------------------------------------------------------------------
    widths = {code: max(w for _, w in vs) for code, vs in id_vars.items()}
    cur: Dict[str, str] = {}
    last_t: Dict[str, float] = {}
    stats = {code: NetActivity(vs[0][0], widths[code]) for code, vs in id_vars.items()}
    t_now = 0.0
    t_first: Optional[float] = None

    def accumulate_time(code: str, t: float) -> None:
        v = cur.get(code)
        if v is None:
            return
        dt = t - last_t[code]
        if dt <= 0:
            return
        st = stats[code]
        n1 = v.count("1")
        n0 = v.count("0")
        st.t1 += dt * n1
        st.t0 += dt * n0
        st.tx += dt * (len(v) - n0 - n1)

    def change(code: str, newv: str) -> None:
        if code not in stats:
            return
        w = widths[code]
        newv = _expand(newv.lower(), w)
        old = cur.get(code)
        if old is not None:
            accumulate_time(code, t_now)
            st = stats[code]
            for a, b in zip(old, newv):
                if a != b:
                    if (a in "01") and (b in "01"):
                        st.tc += 1
                    else:
                        st.ig += 1
        cur[code] = newv
        last_t[code] = t_now

    for tok in toks:
        c = tok[0]
        if c == "#":
            t_now = float(tok[1:])
            if t_first is None:
                t_first = t_now
        elif c in "01xXzZ" and len(tok) > 1:
            change(tok[1:], c)
        elif c in "bB":
            val = tok[1:]
            code = next(toks)
            change(code, val)
        elif c in "rR":
            next(toks)  # real values: not toggle-counted
        elif tok.startswith("$"):
            continue
    for code in list(cur):
        accumulate_time(code, t_now)
    duration = t_now - (t_first or 0.0)
    nets: Dict[str, NetActivity] = {}
    for code, vs in id_vars.items():
        for full, w in vs:
            st = stats[code]
            nets[full] = NetActivity(full, st.width, st.tc, st.t0, st.t1, st.tx, st.ig)
    return ActivityData(nets, duration, timescale, "vcd", str(path))


# ============================================================================
# SAIF
# ============================================================================
def _saif_tokens(text: str) -> Iterator[str]:
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
        elif ch in "()":
            yield ch
            i += 1
        elif ch == '"':
            j = text.index('"', i + 1)
            yield text[i:j + 1]
            i = j + 1
        elif text.startswith("//", i):
            i = text.index("\n", i) if "\n" in text[i:] else n
        else:
            j = i
            while j < n and not text[j].isspace() and text[j] not in "()":
                if text[j] == "\\" and j + 1 < n:
                    j += 2
                else:
                    j += 1
            yield text[i:j]
            i = j


def _saif_tree(tokens: Iterator[str]) -> list:
    stack: List[list] = [[]]
    for t in tokens:
        if t == "(":
            stack.append([])
        elif t == ")":
            node = stack.pop()
            stack[-1].append(node)
        else:
            stack[-1].append(t)
    return stack[0]


def _unescape(name: str) -> str:
    return name.replace("\\", "")


def parse_saif(path: Union[str, Path]) -> ActivityData:
    text = Path(path).read_text(errors="replace")
    tree = _saif_tree(_saif_tokens(text))
    if not tree or not isinstance(tree[0], list) or tree[0][0] != "SAIFILE":
        raise ValueError("not a SAIF file (missing SAIFILE)")
    root = tree[0]
    timescale = 1e-9
    duration = 0.0
    divider = "/"
    nets: Dict[str, NetActivity] = {}

    def walk(node: list, hier: List[str]) -> None:
        for item in node:
            if not isinstance(item, list) or not item:
                continue
            key = item[0]
            if key == "INSTANCE":
                # (INSTANCE [type] name ...)
                rest = item[1:]
                names = [x for x in rest if not isinstance(x, list)]
                inst = _unescape(names[-1]) if names else "?"
                walk(item, hier + [inst])
            elif key in ("NET", "PORT"):
                for net in item[1:]:
                    if not isinstance(net, list):
                        continue
                    name = _unescape(net[0])
                    na = NetActivity(".".join(hier + [name]))
                    for f in net[1:]:
                        if isinstance(f, list) and len(f) >= 2:
                            try:
                                val = float(f[1])
                            except ValueError:
                                continue
                            k = f[0].upper()
                            if k == "T0":
                                na.t0 = val
                            elif k == "T1":
                                na.t1 = val
                            elif k == "TX":
                                na.tx = val
                            elif k == "TC":
                                na.tc = int(val)
                            elif k == "IG":
                                na.ig = int(val)
                    nets[na.name] = na

    for item in root[1:]:
        if isinstance(item, list) and item:
            if item[0] == "TIMESCALE":
                vals = "".join(item[1:])
                m = re.match(r"(\d+)\s*([a-z]+)", vals)
                if m:
                    timescale = int(m.group(1)) * TIMESCALE_S[m.group(2)]
            elif item[0] == "DURATION":
                duration = float(item[1])
            elif item[0] == "DIVIDER":
                divider = item[1] if len(item) > 1 else "/"
    walk(root, [])
    return ActivityData(nets, duration, timescale, "saif", str(path))


def write_saif(data: ActivityData, path: Union[str, Path], design: str = "") -> Path:
    """Write activity as a (flat-per-instance) SAIF 2.0 file."""
    ts_unit = min(TIMESCALE_S.items(), key=lambda kv: abs(kv[1] - data.timescale_s))
    tree: Dict = {}
    for name, na in data.nets.items():
        parts = name.split(".")
        node = tree
        for p in parts[:-1]:
            node = node.setdefault(p, {})
        node.setdefault("__nets__", []).append((parts[-1], na))

    def esc(n: str) -> str:
        return re.sub(r"([\[\]])", r"\\\1", n)

    lines = ['(SAIFILE', '(SAIFVERSION "2.0")', '(DIRECTION "backward")', f'(DESIGN "{design}")',
             '(VENDOR "SilicaFlux PowerLink")', '(PROGRAM_NAME "powerlink")', '(DIVIDER . )',
             f'(TIMESCALE 1 {ts_unit[0]})', f'(DURATION {data.duration:.6g})']

    def emit(node: Dict, name: str, depth: int) -> None:
        ind = "  " * depth
        lines.append(f"{ind}(INSTANCE {esc(name)}")
        if "__nets__" in node:
            lines.append(f"{ind}  (NET")
            for nm, na in node["__nets__"]:
                lines.append(f"{ind}    ({esc(nm)} (T0 {na.t0:.6g}) (T1 {na.t1:.6g}) (TX {na.tx:.6g}) "
                             f"(TC {na.tc}) (IG {na.ig}))")
            lines.append(f"{ind}  )")
        for k, v in node.items():
            if k != "__nets__":
                emit(v, k, depth + 1)
        lines.append(f"{ind})")

    for k, v in tree.items():
        if k != "__nets__":
            emit(v, k, 0)
    lines.append(")")
    Path(path).write_text("\n".join(lines) + "\n")
    return Path(path)


def load_activity(path: Union[str, Path]) -> ActivityData:
    p = str(path).lower()
    if p.endswith(".vcd"):
        return parse_vcd(path)
    if p.endswith(".saif"):
        return parse_saif(path)
    raise ValueError(f"unsupported activity file type: {path}")


# ============================================================================
# block mapping
# ============================================================================
@dataclass
class BlockActivity:
    block: str
    alpha: float
    toggle_rate: float
    nets: int
    bits: int
    source: str
    file: str


def block_activity(data: ActivityData, block_map: Mapping[str, Sequence[str]], f_clk_hz: float,
                   exclude_clocks: Sequence[str] = ("*clk*", "*clock*")) -> Dict[str, BlockActivity]:
    """Average toggle rate of all nets whose hierarchical name contains one of
    the block's instance patterns (bit-weighted).  Clock nets are excluded
    because clock power is modelled separately."""
    cycles = data.cycles(f_clk_hz)
    out: Dict[str, BlockActivity] = {}
    for block, patterns in block_map.items():
        tc = 0
        bits = 0
        n = 0
        for name, na in data.nets.items():
            low = name.lower()
            if any(fnmatch.fnmatch(low.split(".")[-1], c) for c in exclude_clocks):
                continue
            if any(_hier_match(name, p) for p in patterns):
                tc += na.tc
                bits += na.width
                n += 1
        if n == 0:
            continue
        tr = tc / (bits * cycles) if cycles > 0 else 0.0
        out[block] = BlockActivity(block, tr / 2.0, tr, n, bits, data.source, data.file)
    return out


def _hier_match(name: str, pattern: str) -> bool:
    if any(ch in pattern for ch in "*?["):
        return fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(name, f"*{pattern}*")
    segs = name.split(".")
    psegs = pattern.split(".")
    for i in range(len(segs) - len(psegs) + 1):
        if segs[i:i + len(psegs)] == psegs:
            return True
    return False
