"""Simplified thermal modelling: compact resistance networks, a 2-D die
finite-volume solver for power maps, electro-thermal (leakage) coupling and
import/export of specialist thermal-simulation maps.

Compact network (per package family and cooling option)
------------------------------------------------------
Two parallel heat paths from the junction to ambient::

    top:     wire-bond  theta_jc_top + [TIM2/A_pkg + R_sa | 1/(h A_pkg)]
             flip-chip  TIM1/A_die + R_lid(spreading, Song-Lee-Au) with
                        h_eff = 1/(TIM2'' + R_sa A_lid)
    bottom:  theta_jc_bottom + R_board

    theta_ja = R_top || R_bottom

Die power map
-------------
Lateral conduction in the silicon (k(T) = 148 (300/T)^1.3 W/m.K, thickness
t_die) with a uniform area-specific conductance from every cell to ambient
equal to theta_ja minus the die's own 1-D vertical resistance.  This
captures hotspot spreading within the die; it does not resolve the 3-D
package/heatsink field, which requires CFD/FEA for signoff.
"""
from __future__ import annotations

import csv
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from ..config import Project
from ..constants import T0_K
from ..uncertainty import nom, parse_value


def k_si(temp_c: float, k300: float = 148.0, expo: float = 1.3) -> float:
    return k300 * (300.0 / (temp_c + T0_K)) ** expo


def song_spreading_resistance(a: float, b: float, t: float, k: float, h: float) -> Dict[str, float]:
    """Spreading + 1-D resistance of a circular source (radius a) centred on a
    circular plate (radius b, thickness t, conductivity k) cooled by a uniform
    heat-transfer coefficient h on the opposite face.

    Average-source-temperature form of Song, Lee & Au (1994) / Lee, Song, Au &
    Moran (1995):  eps = a/b, tau = t/b, Bi = h b / k,
        lambda_c = pi + 1/(sqrt(pi) eps)
        phi_c = (tanh(lambda_c tau) + lambda_c/Bi) / (1 + (lambda_c/Bi) tanh(lambda_c tau))
        psi_avg = 0.5 (1 - eps)^1.5 phi_c,   R_sp = psi_avg / (sqrt(pi) k a)
        R_1D = t/(k pi b^2) + 1/(h pi b^2),  R_total = R_sp + R_1D.
    Rectangles use area-equivalent radii.  R_sp -> 0 as eps -> 1.
    """
    eps = min(a / b, 1.0)
    tau = t / b
    bi = h * b / k
    lam = math.pi + 1.0 / (math.sqrt(math.pi) * eps)
    th = math.tanh(lam * tau)
    phi = (th + lam / bi) / (1.0 + lam / bi * th)
    psi = 0.5 * (1.0 - eps) ** 1.5 * phi
    r_sp = psi / (math.sqrt(math.pi) * k * a)
    r_1d = t / (k * math.pi * b * b) + 1.0 / (h * math.pi * b * b)
    return {"r_spreading": r_sp, "r_1d": r_1d, "r_total": r_sp + r_1d, "psi": psi, "phi_c": phi}


@dataclass
class ThermalNetwork:
    package: str
    cooling: str
    r_top: float
    r_bottom: float
    theta_ja: float
    elements: Dict[str, float] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)

    def tj(self, power_w: float, t_amb: float) -> float:
        return t_amb + power_w * self.theta_ja


def compact_network(p: Project, package: str, cooling: str, use: str = "nom") -> ThermalNetwork:
    th = p.thermal
    pkg = p.package(package)

    def g(v: Any, adverse_high: bool = True) -> float:
        u = parse_value(v)
        if use == "nom":
            return u.nom
        return u.max if (use == "worst") == adverse_high else u.min

    copt = th["cooling_options"][cooling]
    a_die = nom(p.die["width_mm"]) * nom(p.die["height_mm"]) * 1e-6
    a_pkg = nom(pkg["body_mm"]) ** 2 * 1e-6
    pth = pkg["thermal"]
    el: Dict[str, float] = {}
    notes: List[str] = []
    r_sa = None if copt.get("r_sa_c_w") is None else g(copt["r_sa_c_w"])
    flip = pkg["die_connection"]["type"] == "bump"
    if flip:
        r_tim1 = g(th["tim1"]["r_area_k_cm2_w"]) * 1e-4 / a_die
        t_lid = g(th["heat_spreader"]["thickness_mm"], False) * 1e-3
        k_lid = nom(th["heat_spreader"]["k_w_mk"])
        if r_sa is None:
            h_eff = g(copt.get("top_h_w_m2k", 10.0), False)
        else:
            h_eff = 1.0 / (g(th["tim2"]["r_area_k_cm2_w"]) * 1e-4 + r_sa * a_pkg)
        sp_ = song_spreading_resistance(math.sqrt(a_die / math.pi), math.sqrt(a_pkg / math.pi), t_lid, k_lid, h_eff)
        r_top = r_tim1 + sp_["r_total"]
        el.update({"tim1": r_tim1, "lid_spreading": sp_["r_spreading"], "lid_1d_and_sink": sp_["r_1d"]})
        jc_calc = r_tim1 + sp_["r_spreading"] + t_lid / (k_lid * a_pkg)
        notes.append(f"computed theta_jc_top {jc_calc:.3f} C/W vs library "
                     f"{nom(pth.get('theta_jc_top_c_w', float('nan'))):.3f} C/W")
    else:
        jc_top = g(pth["theta_jc_top_c_w"])
        if r_sa is None:
            r_case = 1.0 / (g(copt.get("top_h_w_m2k", 10.0), False) * a_pkg)
        else:
            r_case = g(th["tim2"]["r_area_k_cm2_w"]) * 1e-4 / a_pkg + r_sa
        r_top = jc_top + r_case
        el.update({"theta_jc_top": jc_top, "case_to_ambient_top": r_case})
    jc_bot = g(pth["theta_jc_bottom_c_w"])
    r_board = g(th["board"]["r_board_to_ambient_c_w"][pth.get("board_path", "balls")])
    r_bot = jc_bot + r_board
    el.update({"theta_jc_bottom": jc_bot, "board_to_ambient": r_board})
    theta = 1.0 / (1.0 / r_top + 1.0 / r_bot)
    return ThermalNetwork(pkg["key"], cooling, r_top, r_bot, theta, el, notes)


# ----------------------------------------------------------------------- FDM
@dataclass
class ThermalMap:
    x_um: np.ndarray
    y_um: np.ndarray
    temp_c: np.ndarray          # (ny, nx), die coordinates
    power_w: np.ndarray
    t_amb: float
    theta_ja: float

    @property
    def t_max(self) -> float:
        return float(self.temp_c.max())

    @property
    def t_mean(self) -> float:
        return float(np.average(self.temp_c, weights=None))

    def at(self, x_um: float, y_um: float) -> float:
        i = int(np.clip(np.searchsorted(self.x_um, x_um), 0, len(self.x_um) - 1))
        j = int(np.clip(np.searchsorted(self.y_um, y_um), 0, len(self.y_um) - 1))
        return float(self.temp_c[j, i])

    def block_temperatures(self, p: Project) -> Dict[str, float]:
        """Area-averaged temperature of each block (core rect offset to die coordinates)."""
        from ..electrical.grid import rect_weights
        x0 = nom(p.core["x0_mm"]) * 1e3
        y0 = nom(p.core["y0_mm"]) * 1e3
        dx = self.x_um[1] - self.x_um[0]
        dy = self.y_um[1] - self.y_um[0]
        out = {}
        for b in p.blocks:
            r = b["rect_um"]
            w = rect_weights([r[0] + x0, r[1] + y0, r[2] + x0, r[3] + y0], len(self.x_um), len(self.y_um), dx, dy)
            out[b["name"]] = float((w * self.temp_c).sum()) if w.sum() > 0 else self.t_mean
        return out


def power_map(p: Project, block_power: Mapping[str, float], io_power_w: float, res_um: float = 25.0) -> Tuple[np.ndarray, float, float]:
    """Die-level power map (W per cell).  IO power spread over the pad ring band."""
    from ..electrical.grid import rect_weights
    W = nom(p.die["width_mm"]) * 1e3
    H = nom(p.die["height_mm"]) * 1e3
    nx, ny = max(4, int(round(W / res_um))), max(4, int(round(H / res_um)))
    dx, dy = W / nx, H / ny
    pm = np.zeros((ny, nx))
    x0 = nom(p.core["x0_mm"]) * 1e3
    y0 = nom(p.core["y0_mm"]) * 1e3
    for b in p.blocks:
        r = b["rect_um"]
        pw = float(block_power.get(b["name"], 0.0))
        if pw:
            pm += pw * rect_weights([r[0] + x0, r[1] + y0, r[2] + x0, r[3] + y0], nx, ny, dx, dy)
    if io_power_w > 0:
        band = 0.12 * min(W, H)
        xc = (np.arange(nx) + 0.5) * dx
        yc = (np.arange(ny) + 0.5) * dy
        X, Y = np.meshgrid(xc, yc)
        ring = (X < band) | (X > W - band) | (Y < band) | (Y > H - band)
        pm[ring] += io_power_w / ring.sum()
    return pm, dx, dy


def solve_die_temperature(p: Project, pm: np.ndarray, dx_um: float, dy_um: float, net: ThermalNetwork,
                          t_amb: float, iterations: int = 3) -> ThermalMap:
    ny, nx = pm.shape
    t_die = nom(p.die.get("thickness_um", 300.0)) * 1e-6
    a_die = nx * dx_um * ny * dy_um * 1e-12
    k300 = nom(p.thermal.get("materials", {}).get("silicon_k", 148.0))
    expo = nom(p.thermal.get("materials", {}).get("silicon_k_temp_exponent", 1.3))
    t_avg = t_amb + pm.sum() * net.theta_ja
    T = np.full((ny, nx), t_avg)
    for _ in range(iterations):
        k = k_si(float(T.mean()), k300, expo)
        r_vert = t_die / (k * a_die)
        # node = die mid-plane: half the die thickness above it is applied locally,
        # the other half plus the package/cooling path forms the boundary
        r_rest = max(net.theta_ja - 0.5 * r_vert, 1e-6)
        a_cell = dx_um * dy_um * 1e-12
        g_v = a_cell / (r_rest * a_die)
        gx = k * t_die * dy_um / dx_um
        gy = k * t_die * dx_um / dy_um
        n = nx * ny
        idx = np.arange(n).reshape(ny, nx)
        a = idx[:, :-1].ravel(); b = idx[:, 1:].ravel()
        ga = np.full(a.shape, gx)
        rows_ = np.concatenate([a, b, a, b]); cols_ = np.concatenate([a, b, b, a])
        vals_ = np.concatenate([ga, ga, -ga, -ga])
        a2 = idx[:-1, :].ravel(); b2 = idx[1:, :].ravel()
        gb = np.full(a2.shape, gy)
        rows_ = np.concatenate([rows_, a2, b2, a2, b2]); cols_ = np.concatenate([cols_, a2, b2, b2, a2])
        vals_ = np.concatenate([vals_, gb, gb, -gb, -gb])
        rows_ = np.concatenate([rows_, np.arange(n)]); cols_ = np.concatenate([cols_, np.arange(n)])
        vals_ = np.concatenate([vals_, np.full(n, g_v)])
        A = sp.coo_matrix((vals_, (rows_, cols_)), shape=(n, n)).tocsc()
        dT = spla.spsolve(A, pm.ravel())
        # active-surface to mid-plane drop under each cell (1-D)
        T = t_amb + dT.reshape(ny, nx) + pm * t_die / (k * a_cell) * 0.5
    xs = (np.arange(nx) + 0.5) * dx_um
    ys = (np.arange(ny) + 0.5) * dy_um
    return ThermalMap(xs, ys, T, pm, t_amb, net.theta_ja)


# --------------------------------------------------------- electro-thermal
@dataclass
class ElectroThermalResult:
    converged: bool
    iterations: int
    runaway: bool
    power: Any
    tmap: ThermalMap
    history: List[float]


def electro_thermal(p: Project, profile: str, package: str, cooling: str, t_amb: float,
                    scales: Optional[Mapping[str, float]] = None, use: str = "nom",
                    max_iter: int = 40, tol_c: float = 0.01, res_um: float = 25.0) -> ElectroThermalResult:
    """Iterate leakage(T) <-> temperature until self-consistent.

    Divergence (T rising each iteration beyond 200 C) is reported as thermal
    runaway rather than silently clipped.
    """
    from ..power.dynamic import evaluate_workload
    net = compact_network(p, package, cooling, use=use)
    temps: Any = t_amb + 10.0
    hist: List[float] = []
    pr = None
    tm = None
    for it in range(1, max_iter + 1):
        pr = evaluate_workload(p, profile, temp_c=temps, scales=scales)
        bp = {b.name: b.total_w for b in pr.blocks}
        io_w = sum(pr.io.values())
        pm, dx, dy = power_map(p, bp, io_w, res_um)
        tm = solve_die_temperature(p, pm, dx, dy, net, t_amb)
        new = tm.block_temperatures(p)
        hist.append(tm.t_max)
        if tm.t_max > 200.0:
            return ElectroThermalResult(False, it, True, pr, tm, hist)
        if isinstance(temps, dict):
            delta = max(abs(new[k] - temps[k]) for k in new)
            if delta < tol_c:
                return ElectroThermalResult(True, it, False, pr, tm, hist)
        temps = new
    return ElectroThermalResult(False, max_iter, False, pr, tm, hist)


# --------------------------------------------------------- import / export
def export_map_csv(tm: ThermalMap, path: Path) -> Path:
    with Path(path).open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["x_um", "y_um", "temp_c", "power_w"])
        for j, y in enumerate(tm.y_um):
            for i, x in enumerate(tm.x_um):
                w.writerow([f"{x:.3f}", f"{y:.3f}", f"{tm.temp_c[j, i]:.4f}", f"{tm.power_w[j, i]:.6e}"])
    return Path(path)


def import_map_csv(path: Path, nx: Optional[int] = None, ny: Optional[int] = None,
                   die_w_um: Optional[float] = None, die_h_um: Optional[float] = None) -> ThermalMap:
    """Import a temperature map produced by a specialist tool (Icepak, Celsius,
    FloTHERM, RedHawk-SC ET...) exported as CSV with columns x_um, y_um, temp_c
    in die coordinates.  Scattered points are resampled (linear, nearest
    outside the hull) onto a regular grid."""
    from scipy.interpolate import griddata
    xs, ys, ts = [], [], []
    with Path(path).open() as fh:
        r = csv.DictReader(fh)
        for row in r:
            xs.append(float(row["x_um"])); ys.append(float(row["y_um"])); ts.append(float(row["temp_c"]))
    xs, ys, ts = np.array(xs), np.array(ys), np.array(ts)
    ux, uy = np.unique(xs), np.unique(ys)
    if nx is None and len(ux) * len(uy) == len(xs):
        T = np.full((len(uy), len(ux)), np.nan)
        ix = np.searchsorted(ux, xs); iy = np.searchsorted(uy, ys)
        T[iy, ix] = ts
        return ThermalMap(ux, uy, T, np.zeros_like(T), float("nan"), float("nan"))
    nx = nx or 50
    ny = ny or 50
    W = die_w_um or xs.max()
    H = die_h_um or ys.max()
    gx = (np.arange(nx) + 0.5) * W / nx
    gy = (np.arange(ny) + 0.5) * H / ny
    GX, GY = np.meshgrid(gx, gy)
    T = griddata((xs, ys), ts, (GX, GY), method="linear")
    Tn = griddata((xs, ys), ts, (GX, GY), method="nearest")
    T = np.where(np.isnan(T), Tn, T)
    return ThermalMap(gx, gy, T, np.zeros_like(T), float("nan"), float("nan"))
