"""End-to-end analysis flow: one reproducible run from configuration to report.

``run_all(project_yaml, outdir)`` executes, in order:
  1. workload power with electro-thermal (leakage <-> temperature) coupling
  2. lumped rail paths (regulator -> PCB -> package -> die), VRM compensation
  3. static on-die IR drop, current density and EM screening
  4. PDN impedance vs target, resonances, VRM loop stability and ripple
  5. transient droop for the configured events, cycle-level supply noise,
     resonant-workload excitation, dynamic on-die IR
  6. decoupling sizing (on-die bound, PCB decap optimiser)
  7. thermal maps and cooling comparison
  8. package suitability study
  9. power-integrity margin budgets with corner, RSS and Monte-Carlo
 10. risk register, OpenROAD PDN scripts, optional ngspice cross-checks
 11. Markdown + HTML report and a manifest with input hashes
"""
from __future__ import annotations

import copy
import math
import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

import numpy as np

from .config import Project, assumption_register, load_project, write_json
from .electrical import margins as mg
from .electrical.decap import CapBank, die_decap_required, part_from_config, select_decaps
from .electrical.em import em_summary
from .electrical.grid import solve_dynamic, solve_static
from .electrical.impedance import (default_freqs, find_resonances, loop_gain, ripple_at_die,
                                   stability_margins, target_impedance, z_die)
from .electrical.path import RailPath, build_rail_path, die_capacitance, explicit_decap_f, path_parameters
from .electrical.transient import (ClockedLoad, StepLoad, analyse_droop, build_event_wave, resonant_wave,
                                   simulate_droop)
from .electrical.vrm import LDO, BuckVRM
from .packaging.compare import package_study
from .pdn_onchip.openroad import check_pdn, write_scripts
from .power.activity import block_activity, load_activity
from .power.dynamic import evaluate_workload, power_parameters
from .thermal.model import (compact_network, electro_thermal, export_map_csv)
from .uncertainty import ParameterSet, build_surrogate, nom, parse_value, summarize_samples

T_EVENT = 500e-9


def _log(msg: str) -> None:
    print(f"[powerlink] {msg}", flush=True)


# ============================================================================ power
def rail_currents(pr, p: Project) -> Dict[str, Tuple[float, float]]:
    """(static, dynamic) current per rail; IO switching counted as dynamic on the IO rail."""
    out = {}
    for r in p.rails:
        v = pr.rails_v[r]
        st = sum(b.p_leak_w for b in pr.blocks if b.rail == r) / v
        dy = sum(b.p_dyn_w + b.p_fixed_w for b in pr.blocks if b.rail == r) / v
        if r == pr.io_rail:
            dy += sum(pr.io.values()) / v
        out[r] = (st, dy)
    return out


def block_split(pr) -> Dict[str, Tuple[float, float]]:
    return {b.name: (b.p_leak_w / b.v if b.v else 0.0, (b.p_dyn_w + b.p_fixed_w) / b.v if b.v else 0.0)
            for b in pr.blocks}


def measured_activity(p: Project) -> Dict[str, Dict[str, Any]]:
    out = {}
    for prof, f in (p.workloads.get("activity_files") or {}).items():
        path = (p.path.parent / f).resolve()
        data = load_activity(path)
        out[prof] = block_activity(data, p.workloads.get("activity_block_map", {}), p.clock_hz)
    return out


def power_stage(p: Project, package: str, cooling: str, t_amb: float, scales=None) -> Dict[str, Any]:
    profiles = {}
    temps = {}
    measured = measured_activity(p)
    for name in p.workloads["profiles"]:
        et = electro_thermal(p, name, package, cooling, t_amb, scales=scales)
        pr = et.power
        if name in measured:
            temps_b = et.tmap.block_temperatures(p)
            pr = evaluate_workload(p, name, temp_c=temps_b, scales=scales, measured=measured[name])
        profiles[name] = pr
        temps[name] = {"t_max_c": et.tmap.t_max, "converged": et.converged, "runaway": et.runaway,
                       "iterations": et.iterations, "tmap": et.tmap}
    return {"profiles": profiles, "thermal": temps, "measured": measured}


# ============================================================================ helpers
def _event_currents(p: Project, profiles: Mapping[str, Any], event: Mapping[str, Any], rail: str):
    a = rail_currents(profiles[event["from"]], p)[rail]
    b = rail_currents(profiles[event["to"]], p)[rail]
    return a, b


def _par(p: Project) -> float:
    return nom(p.workloads.get("cycle_current", {}).get("peak_to_average", 3.0))


def clocked_droop_metric(path: RailPath, i_from, i_to, f_clk: float, par: float, t_stop: Optional[float] = None,
                         rise: float = 10e-9, pre_cycles: int = 40, post_cycles: int = 100) -> Dict[str, float]:
    """Clock-synchronous pulsed load stepping from state i_from to i_to; the window is
    defined in clock cycles so the step count is independent of the clock frequency."""
    T = 1.0 / f_clk
    t_ev = pre_cycles * T
    t_stop = t_ev + post_cycles * T if t_stop is None else t_stop
    stat = StepLoad(i_from[0], i_to[0], t_ev, rise)
    dyn = StepLoad(i_from[1], i_to[1], t_ev, rise)
    wave = ClockedLoad(stat, dyn, f_clk, par, t_stop)
    dt = 1.0 / f_clk / 50.0
    c, n = path.circuit(load_dc=wave(0.0), load_wave=wave)
    res = c.tran([(t_stop, dt)], probes=[n["die_load"]])
    v = res[n["die_load"]]
    i_tot = i_to[0] + i_to[1]
    dc = i_tot * path.series_r()
    vmin = float(v[res.t >= t_ev].min())
    return {"v_min": vmin, "total_drop": path.v_nom - vmin, "dynamic_beyond_dc": max(path.v_nom - vmin - dc, 1e-6),
            "t": res.t, "v": v}


def steady_noise(path: RailPath, i_state, f_clk: float, par: float, cycles: int = 60) -> Dict[str, Any]:
    t_stop = cycles / f_clk
    wave = ClockedLoad(StepLoad(i_state[0], i_state[0], 0, 1e-9), StepLoad(i_state[1], i_state[1], 0, 1e-9),
                       f_clk, par, t_stop)
    c, n = path.circuit(load_dc=i_state[0] + i_state[1], load_wave=wave)
    res = c.tran([(t_stop, 1.0 / f_clk / 50.0)], probes=[n["die_load"]])
    t, v = res.t, res[n["die_load"]]
    m = t > t_stop * 0.5
    return {"t": t[m] - t[m][0], "v": v[m], "pp_v": float(v[m].max() - v[m].min()), "mean_v": float(v[m].mean())}


# ============================================================================ main flow
def run_all(project_path: str | Path, outdir: str | Path, mc_samples: int = 4000, seed: int = 1,
            crosscheck: bool = True, quick: bool = False) -> Dict[str, Any]:
    t0 = time.time()
    p = load_project(project_path)
    out = Path(outdir)
    fig = out / "figures"
    fig.mkdir(parents=True, exist_ok=True)
    ctx: Dict[str, Any] = {"project": p, "out": out, "figures": {}, "tables": {}, "notes": [], "results": {}}
    from .reports import plots as pl
    from .reports import diagrams as dg
    study = p.chip.get("analysis", {})
    pkg = p.baseline_package
    cooling = study.get("reference_cooling", "natural_convection")
    amb = parse_value(p.thermal.get("ambient_c", 25.0))
    t_hot = amb.max
    f_clk = p.clock_hz
    par = _par(p)
    core_rail = next(r for r, c in p.rails.items() if c.get("on_die_grid"))
    events = p.workloads.get("transient_events", {})
    primary = events[p.workloads.get("primary_event", next(iter(events)))]

    # -------------------------------------------------------------- 1 power
    _log("power + electro-thermal")
    pw_hot = power_stage(p, pkg, cooling, t_hot)
    pw_nom = power_stage(p, pkg, cooling, amb.nom)
    prof = pw_hot["profiles"]
    ctx["results"]["power_hot"] = pw_hot
    ctx["results"]["power_nom"] = pw_nom
    max_prof = max(prof, key=lambda k: prof[k].rail_power(core_rail))
    ctx["results"]["max_profile"] = max_prof
    i_rail_max = {r: max(prof[k].rail_current(r) for k in prof) for r in p.rails}
    i_rail_min = {r: min(prof[k].rail_current(r) for k in prof) for r in p.rails}
    delta_i = {r: i_rail_max[r] - i_rail_min[r] for r in p.rails}
    ctx["figures"]["power_profiles"] = pl.power_bars(prof, fig / "power_profiles.png",
                                                     f"{p.name} power by workload (ambient {t_hot:.0f} C, electro-thermal)")
    ctx["figures"]["power_blocks"] = pl.block_power_bars(prof[max_prof], fig / "power_blocks.png",
                                                         f"{p.name} block power - {max_prof}")

    # -------------------------------------------------------------- 2 rail paths
    _log("rail paths and VRM compensation")
    paths: Dict[str, RailPath] = {}
    for r in p.rails:
        paths[r] = build_rail_path(p, r, pkg, i_max=i_rail_max[r], delta_i=delta_i[r])

    # -------------------------------------------------------------- 3 static IR
    _log("static on-die IR drop")
    blk_cur = {b.name: b.current_a for b in prof[max_prof].blocks}
    ir = solve_static(p, blk_cur, rail_paths=paths, package=pkg)
    net = next(n for n, c in p.pdn["nets"].items() if c.get("rail") == core_rail)
    for n_, c_ in p.pdn["nets"].items():
        if c_["type"] == "power" and c_.get("rail") in paths:
            r_ = c_["rail"]
            paths[r_] = build_rail_path(p, r_, pkg, i_max=i_rail_max[r_], delta_i=delta_i[r_],
                                        r_grid=ir.r_grid_eff[n_])
    ctx["results"]["ir"] = ir
    em_rows = em_summary(ir, float(p.pdn.get("analysis", {}).get("metal_temperature_c", 85.0)))
    ctx["tables"]["em"] = em_rows
    ctx["figures"]["ir_static"] = pl.ir_heatmap(ir, net, fig / "ir_drop_static.png",
                                                f"{p.name} {net} static IR drop - {max_prof}, {pkg}")
    ctx["figures"]["current_density"] = pl.current_density_maps(ir, net, fig / "current_density.png")
    ctx["figures"]["domains"] = dg.voltage_domain_diagram(p, fig / "voltage_domains.png", ir.grid.supplies)
    ctx["figures"]["pdn_chain"] = dg.pdn_chain_diagram(paths, fig / "pdn_path.png",
                                                       f"{p.name} power-delivery path ({pkg})")

    # -------------------------------------------------------------- 4 frequency domain
    _log("impedance, VRM loop, ripple")
    zres = {}
    for r, pth in paths.items():
        cfg = p.rails[r]
        freqs = default_freqs(1e3, 2e9, 40)
        f, Z = z_die(pth, freqs)
        zt = target_impedance(pth.v_nom, nom(cfg["budget"]["dynamic"]), max(delta_i[r], 1e-4))
        res = find_resonances(f, Z)
        f_knee = max(f_clk, 0.35 / (float(primary.get("rise_ns", 10)) * 1e-9))
        zres[r] = {"f": f, "Z": Z, "z_target": zt, "resonances": res, "f_target_max": f_knee,
                   "violation_ratio": float(np.max(np.abs(Z[f <= f_knee]) / zt))}
        if isinstance(pth.regulator, BuckVRM):
            fl, T = loop_gain(pth, np.logspace(2, 7, 401))
            zres[r]["loop"] = {"f": fl, "T": T, "margins": stability_margins(fl, T)}
            rp = pth.regulator.ripple()
            zres[r]["ripple"] = {**rp, **ripple_at_die(pth, pth.regulator.f_sw, rp["ripple_current_pp_a"])}
            zres[r]["slew"] = pth.regulator.slew_check(delta_i[r])
    # PLL LDO: upstream ripple attenuated by PSRR
    for r, pth in paths.items():
        if isinstance(pth.regulator, LDO):
            up = next((zres[k]["ripple"]["ripple_vrm_pp_v_fundamental"] for k in zres if "ripple" in zres[k]
                       and p.rails[k].get("kind") == "io"), 0.0)
            zres[r]["ripple"] = {"ripple_die_pp_v": pth.regulator.ripple(up)["ripple_pp_v"],
                                 "upstream_pp_v": up, "psrr_db": pth.regulator.psrr_db_at_fsw}
    ctx["results"]["z"] = zres
    worst_core = build_rail_path(p, core_rail, pkg, paths[core_rail].connections, i_rail_max[core_rail],
                                 delta_i[core_rail], ir.r_grid_eff[net], use="worst")
    fz, Zw = z_die(worst_core, zres[core_rail]["f"])
    no_pcb = copy.copy(paths[core_rail])
    no_pcb.pcb_banks, no_pcb.pcb_bank_extra_l = [], []
    _, Znp = z_die(no_pcb, zres[core_rail]["f"])
    ctx["figures"]["impedance"] = pl.impedance_plot(
        {"full PDN (nominal)": (fz, zres[core_rail]["Z"]), "full PDN (adverse corner)": (fz, Zw),
         "without PCB decaps": (fz, Znp)},
        zres[core_rail]["z_target"], zres[core_rail]["f_target_max"], fig / "impedance_core.png",
        f"{p.name} {core_rail} impedance at the die", zres[core_rail]["resonances"])
    if "loop" in zres[core_rail]:
        L = zres[core_rail]["loop"]
        ctx["figures"]["bode"] = pl.bode_plot(L["f"], L["T"], L["margins"], fig / "vrm_loop_core.png",
                                              f"{core_rail} regulator loop gain")

    # -------------------------------------------------------------- 5 transient
    _log("transient droop")
    droops: Dict[str, Any] = {}
    pth = paths[core_rail]
    for ename, ev in events.items():
        a, b = _event_currents(p, prof, ev, core_rail)
        wave = build_event_wave(ev, a, b)
        droops[ename] = simulate_droop(pth, wave, float(ev["at_ns"]) * 1e-9, 30e-6 if not quick else 8e-6,
                                       0.05e-9, 2e-9, fine_window=2.5e-6)
    ctx["results"]["droop"] = droops
    v_min_core = nom(p.rails[core_rail]["min_v"])
    show = {k: v for k, v in droops.items() if k != "load_release"}
    ctx["figures"]["droop"] = pl.droop_plot(show, pth.v_nom, v_min_core, fig / "transient_droop.png",
                                            f"{p.name} {core_rail} transient droop (cycle-average load)")
    i_max_state = rail_currents(prof[max_prof], p)[core_rail]
    noise = steady_noise(pth, i_max_state, f_clk, par)
    ctx["results"]["noise"] = noise
    ripple_die = zres[core_rail].get("ripple", {}).get("ripple_die_pp_v", 0.0)
    ctx["figures"]["noise"] = pl.supply_noise_plot(
        noise["t"], noise["v"], pth.v_nom,
        {"cycle noise (lumped)": noise["pp_v"], "VRM ripple at die": ripple_die,
         "first droop (wake)": droops[p.workloads.get("primary_event")].first_droop_v},
        fig / "supply_noise.png", f"{p.name} {core_rail} supply noise")
    # resonant workload: a program can modulate activity at up to f_clk/2; excite the anti-resonance
    # with the largest expected response dI * |Z| (square-wave fundamental 4/pi)
    exc = [r for r in zres[core_rail]["resonances"] if r["f_hz"] <= f_clk / 2]
    if exc:
        a, b = _event_currents(p, prof, primary, core_rail)
        di = abs(sum(b) - sum(a))
        best = max(exc, key=lambda r: r["z_ohm"])
        fr = best["f_hz"]
        n_cyc = 20
        dt_r = min(1.0 / (fr * 200.0), 2e-9)
        wave = resonant_wave(sum(a), sum(b), fr, T_EVENT, cycles=n_cyc)
        t_end = T_EVENT + (n_cyc + 2) / fr
        rr = simulate_droop(pth, wave, T_EVENT, t_end, dt_r, dt_r, fine_window=t_end)
        ctx["results"]["resonant"] = {"f_hz": fr, "z_ohm": best["z_ohm"], "estimate_v": di * best["z_ohm"] * 4 / math.pi / 2,
                                      "droop_v": rr.droop_v,
                                      "step_droop_v": droops[p.workloads.get("primary_event")].droop_v}
    # dynamic on-die IR
    _log("dynamic on-die IR drop")
    cur_from = block_split(prof[primary["from"]])
    cur_to = block_split(prof[primary["to"]])
    t_ev_d = 10.0 / f_clk
    t_post = max((20.0 if quick else 35.0) / f_clk, 150e-9)
    dyn = solve_dynamic(p, cur_from, cur_to, paths, t_event=t_ev_d, t_stop=t_ev_d + t_post,
                        dt=1.0 / f_clk / 20.0, f_clk=f_clk, par=par, rise=float(primary.get("rise_ns", 10)) * 1e-9,
                        package=pkg)
    ctx["results"]["dyn"] = dyn
    ctx["figures"]["dyn_ir"] = pl.dynamic_ir_plot(dyn, net, fig / "ir_drop_dynamic.png")

    # -------------------------------------------------------------- 6 decap sizing
    _log("decoupling sizing")
    ctx["results"]["decap"] = decap_study(p, paths, core_rail, delta_i, dyn, ir, net, f_clk, par, prof, max_prof)

    # -------------------------------------------------------------- 7 thermal
    _log("thermal and cooling")
    ctx["results"]["thermal"] = thermal_study(p, prof, max_prof, pw_hot, t_hot, cooling, pkg, fig, ctx)

    # -------------------------------------------------------------- 8 packages
    _log("package study")
    tot_max = max(prof[k].total_w() for k in prof)
    items = package_study(p, i_rail_max, delta_i, tot_max, core_rail, r_grid=ir.r_grid_eff[net])
    ctx["results"]["packages"] = items
    ctx["figures"]["packages"] = pl.package_comparison_plot(items, fig / "package_comparison.png",
                                                            f"{p.name} package suitability")

    # -------------------------------------------------------------- 9 margins
    _log("margin budgets and Monte-Carlo")
    ctx["results"]["budgets"] = margin_study(p, paths, ir, net, dyn, droops, zres, prof, primary, core_rail,
                                             delta_i, i_rail_max, f_clk, par, mc_samples, seed, quick, fig, ctx)

    # -------------------------------------------------------------- 10 risks, OpenROAD, cross-check
    from .reports.risk import build_risks
    ctx["results"]["pdn_check"] = check_pdn(p)
    ctx["results"]["openroad"] = write_scripts(p, out / "openroad")
    risks = build_risks(p, ctx)
    ctx["results"]["risks"] = risks
    ctx["figures"]["risk"] = pl.risk_matrix(risks, fig / "risk_matrix.png", f"{p.name} power/package risk summary")
    if crosscheck:
        from .validation import crosscheck_all
        _log("ngspice cross-checks")
        ctx["results"]["crosscheck"] = crosscheck_all(p, paths[core_rail], blk_cur, paths, out / "crosscheck",
                                                      quick=quick)
    act_demo = Path(__file__).resolve().parent.parent / "results" / "rtl" / "tb_sf_pwr_seq.vcd"
    if act_demo.exists():
        ctx["results"]["activity_demo"] = activity_demo(act_demo, out)

    # -------------------------------------------------------------- 11 report
    _log("report")
    ctx["assumptions"] = assumption_register(p)
    ctx["runtime_s"] = time.time() - t0
    from .reports.report import write_reports
    summary = write_reports(p, ctx)
    manifest = p.manifest() | {"mc_samples": mc_samples, "seed": seed, "runtime_s": ctx["runtime_s"],
                               "figures": ctx["figures"], "openroad": ctx["results"]["openroad"]}
    write_json(out / "manifest.json", manifest)
    write_json(out / "summary.json", summary)
    _log(f"done in {ctx['runtime_s']:.1f} s -> {out}")
    return summary


# ============================================================================ sub-studies
def decap_study(p, paths, core_rail, delta_i, dyn, ir, net, f_clk, par, prof, max_prof) -> Dict[str, Any]:
    pth = paths[core_rail]
    cfg = p.rails[core_rail]
    v = pth.v_nom
    dyn_alloc = nom(cfg["budget"]["dynamic"]) * v
    l_pkg = pth.l_first_droop()
    c_req_first = die_decap_required(delta_i[core_rail], dyn_alloc, l_pkg)
    i_dyn = rail_currents(prof[max_prof], p)[core_rail][1]
    q_cycle = i_dyn / f_clk
    # per-cycle charge rule: the die capacitance must supply most of the pulse charge in-cycle
    c_req_cycle = 0.5 * q_cycle / dyn_alloc * (1.0 - 1.0 / par) * 2.0
    exp = explicit_decap_f(p, core_rail)
    dens = nom(p.technology["decap_cell"]["density_ff_per_um2"]) * 1e-15
    c_now = pth.c_die
    c_need = max(c_req_first, c_req_cycle)
    add_area_um2 = max(0.0, (c_need - c_now) / dens)
    core_area = nom(p.core["width_mm"]) * nom(p.core["height_mm"]) * 1e6
    dyn_worst = dyn.worst_dyn_drop_v[net] - ir.worst_drop_v[net]
    # what-if: scale the on-die capacitance to see the dynamic-noise sensitivity (lumped clocked model)
    whatif = []
    ev_p = p.workloads["transient_events"][p.workloads["primary_event"]]
    rise_p = float(ev_p.get("rise_ns", 10)) * 1e-9
    i_from = rail_currents(prof[p.workloads["transient_events"][p.workloads["primary_event"]]["from"]], p)[core_rail]
    i_to = rail_currents(prof[p.workloads["transient_events"][p.workloads["primary_event"]]["to"]], p)[core_rail]
    recommended = None
    for k in (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0):
        alt = copy.copy(pth)
        alt.c_die = pth.c_die * k
        alt.r_die_esr = pth.r_die_esr / k
        m = clocked_droop_metric(alt, i_from, i_to, f_clk, par, rise=rise_p)
        f_r = 1.0 / (2 * math.pi * math.sqrt(l_pkg * alt.c_die))
        near = min(abs(f_r / (h * f_clk) - 1.0) for h in (1, 2, 3))
        row = {"c_scale": k, "c_die_nf": alt.c_die * 1e9, "total_drop_mv": m["total_drop"] * 1e3,
               "dynamic_beyond_dc_mv": m["dynamic_beyond_dc"] * 1e3, "f_res_mhz": f_r / 1e6,
               "nearest_harmonic_offset": near,
               "extra_decap_area_mm2": (alt.c_die - pth.c_die) / dens / 1e6}
        whatif.append(row)
        if recommended is None and m["dynamic_beyond_dc"] <= 0.6 * dyn_alloc and near > 0.15:
            recommended = row
    l_whatif = []
    for kp, kc in ((1.0, 1.0), (1.5, 1.0), (2.0, 1.0), (1.5, 2.0), (2.0, 2.0)):
        alt = copy.copy(pth)
        alt.pins = replace(pth.pins, l=pth.pins.l / kp, r=pth.pins.r / kp)
        alt.conn = replace(pth.conn, l=pth.conn.l / kp, r=pth.conn.r / kp)
        alt.c_die = pth.c_die * kc
        alt.r_die_esr = pth.r_die_esr / kc
        m = clocked_droop_metric(alt, i_from, i_to, f_clk, par, rise=rise_p)
        l_alt = alt.l_first_droop()
        extra_pins = int(math.ceil((kp - 1.0) * (pth.connections.n_power_pins + pth.connections.n_ground_pins)))
        l_whatif.append({"pairs_scale": kp, "c_scale": kc, "l_pkg_ph": l_alt * 1e12,
                         "f_res_mhz": 1.0 / (2 * math.pi * math.sqrt(l_alt * alt.c_die)) / 1e6,
                         "dynamic_beyond_dc_mv": m["dynamic_beyond_dc"] * 1e3, "extra_pins": extra_pins,
                         "extra_decap_area_mm2": (alt.c_die - pth.c_die) / dens / 1e6})
    # cheapest combined option meeting the criterion (decap area first, then pins), pin budget permitting
    pkg_cfg = p.package()
    sig = sum(nom(x["pins"]) for x in p.chip.get("io", {}).get("signals", {}).values())
    used = sig + sum(c.connections.n_power_pins + c.connections.n_ground_pins for c in paths.values())
    pins_free = int(pkg_cfg["max_connections"] - used)
    ok = [w for w in l_whatif if w["dynamic_beyond_dc_mv"] <= 0.6 * dyn_alloc * 1e3 and w["extra_pins"] <= pins_free]
    recommended_combined = min(ok, key=lambda w: (w["extra_decap_area_mm2"], w["extra_pins"])) if ok else None
    # PCB decap optimiser in the band where PCB caps are effective
    f_res_pkg = 1.0 / (2 * math.pi * math.sqrt(l_pkg * c_now))
    f_hi = min(f_res_pkg / 3.0, 50e6)
    freqs = np.logspace(3, math.log10(f_hi), 60)
    zt = target_impedance(v, nom(cfg["budget"]["dynamic"]), max(delta_i[core_rail], 1e-4))
    lib = p.pcb["capacitor_library"]
    cands = [part_from_config(n, lib[n]) for n in p.pcb.get("decap_candidates", [])]

    def zfn(extra_banks):
        alt = copy.copy(pth)
        alt.pcb_banks = list(pth.pcb_banks) + list(extra_banks)
        alt.pcb_bank_extra_l = list(pth.pcb_bank_extra_l) + [pth.pcb_bank_extra_l[-1] if pth.pcb_bank_extra_l else 0.0] * len(extra_banks)
        return z_die(alt, freqs)[1]

    z0 = np.abs(zfn([]))
    chosen = select_decaps(zfn, freqs, np.full(len(freqs), zt), cands, max_parts=16) if np.max(z0 / zt) > 1 else []
    return {"l_pkg_h": l_pkg, "c_die_f": c_now, "c_explicit_f": exp["c_f"], "decap_area_um2": exp["area_um2"],
            "c_required_first_droop_f": c_req_first, "c_required_cycle_charge_f": c_req_cycle,
            "q_cycle_c": q_cycle, "additional_decap_area_um2": add_area_um2,
            "additional_decap_fraction_of_core": add_area_um2 / core_area,
            "dynamic_component_grid_v": dyn_worst, "whatif": whatif, "recommended": recommended,
            "l_whatif": l_whatif, "recommended_combined": recommended_combined, "pins_free": pins_free,
            "dynamic_allocation_v": dyn_alloc,
            "pcb_band_hz": [float(freqs[0]), float(freqs[-1])], "pcb_z_target_ohm": zt,
            "pcb_max_ratio_before": float(np.max(z0 / zt)),
            "pcb_added": [{"part": b.part.name, "count": b.count} for b in chosen]}


def thermal_study(p, prof, max_prof, pw_hot, t_hot, cooling, pkg, fig, ctx) -> Dict[str, Any]:
    from .reports import plots as pl
    from .power.dynamic import evaluate_workload
    tj_lim = float(p.thermal.get("tj_limit_c", 105.0))
    table: Dict[str, Dict[str, float]] = {}
    runaway = []
    for cool in p.thermal["cooling_options"]:
        table[cool] = {}
        for key in p.packages["packages"]:
            net = compact_network(p, key, cool)
            t = t_hot + 10
            ok = False
            for _ in range(40):
                pr = evaluate_workload(p, max_prof, temp_c=t)
                t_new = net.tj(pr.total_w(), t_hot)
                if t_new > 250:
                    break
                if abs(t_new - t) < 0.01:
                    ok = True
                    t = t_new
                    break
                t = t_new
            if not ok:
                runaway.append((cool, key))
            table[cool][key] = t
    ctx["figures"]["cooling"] = pl.cooling_plot(table, tj_lim, fig / "cooling_comparison.png",
                                                f"{p.name} junction temperature - {max_prof}, ambient {t_hot:.0f} C")
    tm = pw_hot["thermal"][max_prof]["tmap"]
    ctx["figures"]["thermal_map"] = pl.thermal_map_plot(tm, p, fig / "thermal_map.png",
                                                        f"{p.name} die temperature - {max_prof}, {pkg}, {cooling}")
    csv = export_map_csv(tm, ctx["out"] / "thermal_map_export.csv")
    nets = {c: compact_network(p, pkg, c) for c in p.thermal["cooling_options"]}
    return {"table": table, "runaway": runaway, "tj_limit": tj_lim, "t_amb": t_hot,
            "baseline_tmax": tm.t_max, "export_csv": str(csv),
            "theta_ja": {c: n.theta_ja for c, n in nets.items()},
            "network_notes": {c: n.notes for c, n in nets.items()},
            "converged": {k: v["converged"] for k, v in pw_hot["thermal"].items()},
            "tmax_by_profile": {k: v["t_max_c"] for k, v in pw_hot["thermal"].items()}}


def margin_study(p, paths, ir, net, dyn, droops, zres, prof, primary, core_rail, delta_i, i_rail_max, f_clk, par,
                 mc_samples, seed, quick, fig, ctx) -> Dict[str, Any]:
    from .reports import plots as pl
    budgets: Dict[str, Any] = {}
    for r, pth in paths.items():
        cfg = p.rails[r]
        v = pth.v_nom
        bud = cfg["budget"]
        reg_cfg = p.pcb["regulators"][cfg["regulator"]]
        acc = parse_value(reg_cfg.get("setpoint_accuracy", 0.01))
        comps: List[mg.BudgetComponent] = []
        rip = zres[r].get("ripple", {}).get("ripple_die_pp_v", 0.0)
        worst_path = build_rail_path(p, r, p.baseline_package, pth.connections, i_rail_max[r], delta_i[r],
                                     pth.r_grid, use="worst")
        if isinstance(worst_path.regulator, BuckVRM):
            rip_w = ripple_at_die(worst_path, worst_path.regulator.f_sw,
                                  worst_path.regulator.ripple()["ripple_current_pp_a"])["ripple_die_pp_v"]
        else:
            rip_w = rip * 2.0
        comps.append(mg.BudgetComponent("regulator setpoint", acc.nom * v, acc.max * v, nom(bud["setpoint"]) * v, True,
                                        acc.source))
        comps.append(mg.BudgetComponent("ripple (half p-p)", rip / 2, max(rip, rip_w) / 2, nom(bud["ripple"]) * v, True))
        if cfg.get("on_die_grid"):
            net_r = next(n for n, c in p.pdn["nets"].items() if c.get("rail") == r)
            info = ir_corner(p, ir, net_r, prof, ctx)
            comps.append(mg.BudgetComponent("static IR (worst cell)", ir.worst_drop_v[net_r], info["worst_v"],
                                            nom(bud["dc_ir"]) * v, False, "grid solver"))
            dyn_c = max(dyn.worst_dyn_drop_v[net_r] - ir.worst_drop_v[net_r], 0.0)
            if r == core_rail:
                mc = droop_corner_and_mc(p, pth, primary, prof, core_rail, f_clk, par, mc_samples, seed,
                                         n_direct=60 if quick else 200)
                ratio_w = mc["ratio_worst"]
                m_n = m_w = 1.0
            else:
                mc = None
                a, b_ = _event_currents(p, prof, primary, r)
                rise_p = float(primary.get("rise_ns", 10)) * 1e-9
                m_n = clocked_droop_metric(pth, a, b_, f_clk, par, rise=rise_p)["dynamic_beyond_dc"]
                pps = power_parameters(p)
                wc = pps.worst_case()
                aw = rail_currents(evaluate_workload(p, primary["from"], temp_c=85.0, scales=wc), p)[r]
                bw = rail_currents(evaluate_workload(p, primary["to"], temp_c=85.0, scales=wc), p)[r]
                m_w = clocked_droop_metric(worst_path, aw, bw, f_clk, par, rise=rise_p)["dynamic_beyond_dc"]
                ratio_w = m_w / m_n if m_n > 1e-3 else None
            # multiplicative corner when the nominal term is resolvable, additive otherwise
            dyn_w = dyn_c * ratio_w if ratio_w is not None else dyn_c + max(m_w - m_n, 0.0)
            comps.append(mg.BudgetComponent("dynamic droop + cycle noise", dyn_c, dyn_w,
                                            nom(bud["dynamic"]) * v, True, "dynamic grid x lumped corner"))
        else:
            i = i_rail_max[r]
            dc = i * pth.series_r()
            dcw = i * worst_path.series_r() * 1.3
            comps.append(mg.BudgetComponent("static IR (path)", dc, dcw, nom(bud["dc_ir"]) * v, False, "lumped path"))
            ev = dict(primary)
            a, b = _event_currents(p, prof, ev, r)
            if abs(sum(b) - sum(a)) > 1e-6:
                d = simulate_droop(pth, build_event_wave(ev, a, b), T_EVENT, 6e-6, 0.05e-9, 2e-9, 2e-6)
                dd = max(d.droop_v - abs(sum(b) - sum(a)) * pth.series_r(), 0.0)
                dw = simulate_droop(worst_path, build_event_wave(ev, a, b), T_EVENT, 6e-6, 0.05e-9, 2e-9, 2e-6)
                ddw = max(dw.droop_v - abs(sum(b) - sum(a)) * worst_path.series_r(), dd)
            else:
                dd = ddw = 0.0
            comps.append(mg.BudgetComponent("dynamic droop", dd, ddw, nom(bud["dynamic"]) * v, True, "lumped transient"))
            mc = None
        b = mg.RailBudget(r, v, nom(cfg["min_v"]), comps, nom(bud.get("guardband", 0.0)) * v)
        if cfg.get("on_die_grid") and mc is not None and r == core_rail:
            rng = np.random.default_rng(seed)
            n = mc_samples
            a_s = rng.uniform(acc.min, acc.max, n)
            setp = rng.uniform(-1.0, 1.0, n) * a_s * v
            ripple_s = rng.uniform(rip, max(rip, rip_w), n) / 2
            static_s = info["surrogate"](mc["samples"], n)
            dyn_s = comps[3].value_v * mc["surrogate"](mc["samples"]) / mc["surrogate"].m0
            b.mc = mg.monte_carlo_margin(b, {"setpoint": setp, "ripple": ripple_s, "static_ir": static_s,
                                             "dynamic": dyn_s})
            b.mc["surrogate_error_at_worst_corner"] = mc["surrogate_error"]
            # direct (full-model) MC on the first n_direct samples, same draws
            nd = mc["n_direct"]
            dyn_d = comps[3].value_v * mc["direct_ratio"]
            marg_d = b.available_v - (setp[:nd] + ripple_s[:nd] + static_s[:nd] + dyn_d)
            marg_s = b.available_v - (setp[:nd] + ripple_s[:nd] + static_s[:nd] + comps[3].value_v * mc["surrogate_ratio_subset"])
            b.mc["direct"] = {"n": nd, "p_fail": float(np.mean(marg_d < 0)), "margin_mv": summarize_samples(marg_d * 1e3),
                              "p_fail_surrogate_same_draws": float(np.mean(marg_s < 0)),
                              "dyn_ratio_corr": float(np.corrcoef(mc["direct_ratio"], mc["surrogate_ratio_subset"])[0, 1])}
            b.mc["elasticities"] = mc["surrogate"].elasticity
            b.mc["parameters"] = mc["pset"].table()
            ctx["figures"]["mc"] = pl.mc_histogram(b.mc["margin_samples_mv"], fig / "margin_monte_carlo.png",
                                                   f"{p.name} {r} margin distribution", b.mc["p_fail"])
        budgets[r] = b
        ctx["figures"][f"waterfall_{r}"] = pl.margin_waterfall(b, fig / f"margin_{r}.png",
                                                               f"{p.name} {r} power-integrity budget")
    return budgets


def ir_corner(p, ir, net, prof, ctx) -> Dict[str, Any]:
    """Static IR at the adverse corner via exact linear scaling of the solved
    components (on-die metal, die connection, off-die) and the current."""
    from .power.dynamic import power_parameters
    brk = ir.drop_breakdown[net]
    tech = p.technology
    rs = parse_value(tech["metal_stack"]["M1"]["rs_ohm_sq"])
    rs_w = rs.max / rs.nom
    pkg = p.package()
    dc = pkg["die_connection"]
    if dc["type"] == "bondwire":
        u = parse_value(dc["length_mm"])
    else:
        u = parse_value(dc["r_ohm"])
    conn_w = u.max / u.nom
    pps = power_parameters(p)
    wc = pps.worst_case()
    max_prof = ctx["results"]["max_profile"]
    t_hot = parse_value(p.thermal.get("ambient_c", 25)).max
    i0 = prof[max_prof].rail_current(p.pdn["nets"][net]["rail"])
    from .power.dynamic import evaluate_workload
    temps = ctx["results"]["power_hot"]["thermal"][max_prof]["tmap"].block_temperatures(p)
    iw = evaluate_workload(p, max_prof, temp_c=temps, scales=wc).rail_current(p.pdn["nets"][net]["rail"])
    k_i = iw / i0
    worst = k_i * (brk["on_die_worst_v"] * rs_w + brk["die_connection_v"] * conn_w + brk["off_die_v"] * 1.3)

    def surrogate(samples, n):
        # current scales with the power parameters; resistances with metal / connection parameters
        rng = np.random.default_rng(7)
        rs_s = rng.uniform(rs.min / rs.nom, rs_w, n)
        cn_s = rng.uniform(u.min / u.nom, conn_w, n)
        ki = samples.get("_i_scale", np.ones(n))      # current scale from the power parameters
        return ki * (brk["on_die_worst_v"] * rs_s + brk["die_connection_v"] * cn_s + brk["off_die_v"])

    return {"worst_v": worst, "k_i": k_i, "rs_scale": rs_w, "conn_scale": conn_w, "surrogate": surrogate}


def droop_corner_and_mc(p, pth, primary, prof, core_rail, f_clk, par, n_samples, seed,
                        n_direct: int = 150) -> Dict[str, Any]:
    """Elasticity surrogate of the dynamic droop beyond DC (lumped clocked model)
    over path parameters and power scale factors."""
    from .power.dynamic import evaluate_workload
    pset = path_parameters(p, core_rail)
    pps = power_parameters(p)
    for k, prm in pps.params.items():
        pset.params[k] = prm
    path_keys = [k for k in pset.params if k not in pps.params]
    max_prof = primary["to"]
    from_prof = primary["from"]
    rise_p = float(primary.get("rise_ns", 10)) * 1e-9
    cache: Dict[Tuple, Tuple] = {}

    def currents(vals):
        key = tuple(round(vals[k], 6) for k in pps.params)
        if key not in cache:
            sc = {k: vals[k] for k in pps.params}
            a = rail_currents(evaluate_workload(p, from_prof, temp_c=85.0, scales=sc), p)[core_rail]
            b = rail_currents(evaluate_workload(p, max_prof, temp_c=85.0, scales=sc), p)[core_rail]
            cache[key] = (a, b)
        return cache[key]

    def model(vals):
        sc = {k: vals[k] for k in path_keys}
        alt = build_rail_path(p, core_rail, p.baseline_package, pth.connections, 0.05, 0.04,
                              r_grid=pth.r_grid, scales=sc, compensate=False)
        a, b = currents(vals)
        return clocked_droop_metric(alt, a, b, f_clk, par, rise=rise_p)["dynamic_beyond_dc"]

    sur = build_surrogate(model, pset, rel_step=0.05)
    worst = pset.worst_case()
    m_w = model(worst)
    ratio = m_w / sur.m0
    pred = float(sur(worst) / sur.m0)
    samples = pset.sample(n_samples, seed=seed + 2)
    # current scale for the static-IR surrogate: power elasticity of I_max (linearised)
    i0 = sum(currents(pset.nominal())[1])
    el_i = {}
    for k in pps.params:
        up = pset.nominal(); up[k] *= 1.05
        dn = pset.nominal(); dn[k] *= 0.95
        el_i[k] = (math.log(sum(currents(up)[1])) - math.log(sum(currents(dn)[1]))) / (math.log(1.05) - math.log(0.95))
    i_scale = np.ones(len(next(iter(samples.values()))))
    for k, e in el_i.items():
        i_scale = i_scale * samples[k] ** e
    samples["_i_scale"] = i_scale
    # direct Monte-Carlo with the full lumped model on a subset (checks the surrogate where the
    # response is non-monotonic, e.g. near the die-package resonance)
    n_direct = min(n_direct, n_samples)
    direct = np.array([model({k: float(samples[k][j]) for k in pset.params}) for j in range(n_direct)]) / sur.m0
    sur_sub = np.asarray(sur({k: samples[k][:n_direct] for k in pset.params})) / sur.m0
    return {"surrogate": sur, "ratio_worst": ratio, "surrogate_error": abs(pred - ratio) / ratio,
            "samples": samples, "pset": pset, "current_elasticity": el_i, "direct_ratio": direct,
            "surrogate_ratio_subset": sur_sub, "n_direct": n_direct}


def activity_demo(vcd: Path, out: Path) -> Dict[str, Any]:
    """Demonstrate the VCD -> toggle-rate -> SAIF pipeline on the RTL testbench dump."""
    from .power.activity import parse_vcd, write_saif
    data = parse_vcd(vcd, include=["tb_sf_pwr_seq.dut.*"])
    f_clk = 100e6
    bm = {"sf_pwr_seq (dut)": ["tb_sf_pwr_seq.dut"], "pg filter": ["tb_sf_pwr_seq.dut.u_pgf"]}
    act = block_activity(data, bm, f_clk)
    saif = write_saif(data, out / "tb_sf_pwr_seq.saif", design="sf_pwr_seq")
    from .power.activity import parse_saif
    back = parse_saif(saif)
    tc_ok = all(back.nets[k].tc == v.tc for k, v in data.nets.items() if k in back.nets)
    return {"vcd": str(vcd), "nets": len(data.nets), "duration_s": data.duration_s,
            "blocks": {k: {"alpha": v.alpha, "toggle_rate": v.toggle_rate, "nets": v.nets} for k, v in act.items()},
            "saif": str(saif), "saif_roundtrip_ok": tc_ok}
