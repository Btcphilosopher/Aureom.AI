"""Physical constants and bulk material properties (SI units).

Bulk values are textbook/literature values at 20-25 C.  Thin-film and
nanoscale interconnect resistivities are *higher* than bulk (surface and
grain-boundary scattering, barrier layers); technology files therefore
specify sheet resistance directly rather than deriving it from these.
"""
MU0 = 4e-7 * 3.141592653589793      # H/m (vacuum permeability, classical value)
EPS0 = 8.8541878128e-12              # F/m
K_BOLTZMANN_EV = 8.617333262e-5      # eV/K
T0_K = 273.15

# resistivity at 20 C [ohm.m] and linear temperature coefficient [1/K]
RESISTIVITY = {
    "copper": (1.68e-8, 0.00393),
    "aluminium": (2.65e-8, 0.00429),
    "gold": (2.44e-8, 0.0034),
    "silver": (1.59e-8, 0.0038),
    "sac305": (1.32e-7, 0.0040),     # Sn-3.0Ag-0.5Cu solder (literature ~11-13 uohm.cm)
    "snpb_eutectic": (1.45e-7, 0.0040),
    "sn_ag_bump": (1.25e-7, 0.0040),
}

# thermal conductivity [W/m.K] at ~300 K
THERMAL_K = {
    "silicon": 148.0,
    "copper": 390.0,
    "aluminium": 205.0,
    "fr4_inplane": 0.8,
    "fr4_through": 0.3,
    "mold_compound": 0.9,
    "solder": 57.0,
    "die_attach_epoxy": 2.0,
    "die_attach_sinter_ag": 150.0,
}


def resistivity(material: str, temp_c: float = 20.0) -> float:
    rho20, alpha = RESISTIVITY[material]
    return rho20 * (1.0 + alpha * (temp_c - 20.0))


def k_silicon(temp_c: float) -> float:
    """Silicon thermal conductivity vs temperature, k ~ 148*(300/T)^1.3 W/m.K."""
    t_k = temp_c + T0_K
    return 148.0 * (300.0 / t_k) ** 1.3
