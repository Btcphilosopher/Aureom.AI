"""Matplotlib report figures (static PNG).

Colour rules (reference data-viz palette):
* categorical series use a fixed slot order, never cycled;
* magnitude maps (IR drop, current density) use a single-hue blue ramp
  light->dark; temperature uses a single-hue orange ramp (second sequential
  context);
* pass/warn/fail and risk use the reserved status palette, always paired with
  a text label;
* one y-axis per panel (magnitude and phase are separate panels).
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
STATUS = {"good": "#0ca30c", "warning": "#fab219", "serious": "#ec835a", "critical": "#d03b3b"}
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
SURFACE = "#fcfcfb"
BLUE_RAMP = ["#cde2fb", "#b7d3f6", "#9ec5f4", "#86b6ef", "#6da7ec", "#5598e7", "#3987e5", "#2a78d6",
             "#256abf", "#1c5cab", "#184f95", "#104281", "#0d366b"]
ORANGE_RAMP = ["#fde6db", "#f9c6ad", "#f4a37f", "#ef8457", "#eb6834", "#c9521f", "#a03f15", "#76300f"]
CMAP_BLUE = LinearSegmentedColormap.from_list("pl_blue", BLUE_RAMP)
CMAP_ORANGE = LinearSegmentedColormap.from_list("pl_orange", ORANGE_RAMP)


def setup_style() -> None:
    plt.rcParams.update({
        "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
        "axes.edgecolor": AXIS, "axes.labelcolor": INK2, "axes.titlecolor": INK,
        "axes.titlesize": 11, "axes.titleweight": "bold", "axes.labelsize": 9,
        "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelsize": 8, "ytick.labelsize": 8,
        "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
        "legend.fontsize": 8, "font.family": "sans-serif", "lines.linewidth": 1.6,
        "figure.dpi": 110, "savefig.dpi": 150, "savefig.bbox": "tight",
    })


setup_style()


def _save(fig, path: Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cap = getattr(fig, "_pl_caption", None)
    if cap:
        # place the caption below everything already drawn (tick labels, legends)
        fig.canvas.draw()
        r = fig.canvas.get_renderer()
        y0 = min(a.get_tightbbox(r).y0 for a in fig.axes) / fig.bbox.height
        for t in fig.texts:
            y0 = min(y0, t.get_window_extent(r).y0 / fig.bbox.height)
        fig.text(0.01, y0 - 0.015, cap, fontsize=7, color=MUTED, ha="left", va="top", wrap=True)
    fig.savefig(path)
    plt.close(fig)
    return str(path)


def _caption(fig, text: str) -> None:
    fig._pl_caption = text


def _fmt_hz(f: float) -> str:
    if f >= 1e9:
        return f"{f/1e9:.2f} GHz"
    if f >= 1e6:
        return f"{f/1e6:.0f} MHz"
    if f >= 1e3:
        return f"{f/1e3:.0f} kHz"
    return f"{f:.0f} Hz"


def _outline_blocks(ax, blocks: Sequence[Mapping[str, Any]], offset=(0.0, 0.0), label: bool = True,
                    kinds=("logic", "sram", "analog")) -> None:
    for b in blocks:
        if b["kind"] not in kinds:
            continue
        x0, y0, x1, y1 = b["rect_um"]
        ax.add_patch(Rectangle((x0 + offset[0], y0 + offset[1]), x1 - x0, y1 - y0, fill=False,
                               lw=0.6, ec=INK2, alpha=0.55))
        if label and (x1 - x0) > 120 and (y1 - y0) > 50:
            ax.text((x0 + x1) / 2 + offset[0], (y0 + y1) / 2 + offset[1], b["name"].replace("_", "\n", 1),
                    ha="center", va="center", fontsize=5.5, color=INK2)


# ============================================================ heatmaps
def ir_heatmap(ir, net: str, path: Path, title: Optional[str] = None) -> str:
    gm = ir.grid
    d = ir.ir_drop[net] * 1e3
    fig, ax = plt.subplots(figsize=(6.4, 5.4))
    im = ax.imshow(np.ma.masked_invalid(d), origin="lower", cmap=CMAP_BLUE,
                   extent=[0, gm.width, 0, gm.height], interpolation="nearest")
    _outline_blocks(ax, gm.project.blocks, label=len(gm.project.blocks) <= 30)
    for s in gm.supplies:
        if s.net == net:
            ax.plot(s.x_um, s.y_um, marker="s", ms=4, color=SERIES[1], mec=SURFACE, mew=0.8, ls="none")
    j, i = np.unravel_index(np.nanargmax(np.where(ir.load_map.get(net, np.ones_like(d)) > 0, d, np.nan)), d.shape)
    ax.plot((i + 0.5) * gm.dx, (j + 0.5) * gm.dy, marker="x", ms=8, color=INK, mew=1.5)
    dy_off = -14 if j > 0.8 * gm.ny else 6
    dx_off, ha = (-6, "right") if i > 0.7 * gm.nx else (6, "left")
    ax.annotate(f"worst {d[j, i]:.2f} mV", ((i + 0.5) * gm.dx, (j + 0.5) * gm.dy), xytext=(dx_off, dy_off),
                textcoords="offset points", fontsize=8, color=INK, ha=ha,
                bbox=dict(boxstyle="round,pad=0.2", fc=SURFACE, ec="none", alpha=0.85))
    cb = fig.colorbar(im, ax=ax, shrink=0.85)
    cb.set_label("static IR drop VDD-VSS (mV)", color=INK2)
    ax.set_xlabel("x (um, core)")
    ax.set_ylabel("y (um, core)")
    ax.grid(False)
    ax.set_title(title or f"{gm.project.name} {net} static IR drop")
    _caption(fig, "Squares: supply connections (pads/bumps).  Effective supply = V(VDD) - V(VSS) at the "
                  "load layer; homogenised multi-layer grid model (planning accuracy).")
    return _save(fig, path)


def current_density_maps(ir, net: str, path: Path) -> str:
    from ..electrical.em import em_limit_at
    gm = ir.grid
    layers = [l for (n, l) in ir.current_density if n == net]
    temp = float(gm.project.pdn.get("analysis", {}).get("metal_temperature_c", 85.0))
    ratios = []
    for l in layers:
        lim = em_limit_at(gm.layers[l].em_limit_ma_um, temp)
        ratios.append(ir.current_density[(net, l)] / lim * 100.0)
    vmax = max(float(r.max()) for r in ratios) if ratios else 1.0
    n = len(layers)
    fig, axes = plt.subplots(1, n, figsize=(3.0 * n + 0.8, 3.2), squeeze=False)
    for ax, l, r in zip(axes[0], layers, ratios):
        im = ax.imshow(r, origin="lower", cmap=CMAP_BLUE, vmin=0, vmax=vmax,
                       extent=[0, gm.width, 0, gm.height], interpolation="nearest")
        _outline_blocks(ax, gm.project.blocks, label=False)
        ax.set_title(f"{l}  max {r.max():.1f}%", fontsize=9)
        ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
    cb = fig.colorbar(im, ax=axes[0].tolist(), shrink=0.85)
    cb.set_label("DC current density / EM limit (%)", color=INK2)
    fig.suptitle(f"{gm.project.name} {net} strap current density (EM limit at {temp:.0f} C)", fontsize=11,
                 fontweight="bold", color=INK)
    _caption(fig, "Limit per layer from the technology file, scaled from 105 C with Black's equation "
                  "(Ea 0.9 eV, n 2 - assumption).  Foundry EM rules supersede.")
    return _save(fig, path)


def dynamic_ir_plot(dyn, net: str, path: Path) -> str:
    gm = dyn.grid
    d = dyn.dyn_drop_map[net] * 1e3
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.4), gridspec_kw={"width_ratios": [1, 1.25]})
    im = ax1.imshow(np.ma.masked_invalid(d), origin="lower", cmap=CMAP_BLUE,
                    extent=[0, gm.width, 0, gm.height], interpolation="nearest")
    _outline_blocks(ax1, gm.project.blocks, label=False)
    ax1.grid(False)
    ax1.set_title(f"peak dynamic drop (worst {np.nanmax(d):.1f} mV)")
    ax1.set_xlabel("x (um)"); ax1.set_ylabel("y (um)")
    cb = fig.colorbar(im, ax=ax1, shrink=0.85)
    cb.set_label("max over time of V_nom - (V_VDD - V_VSS) (mV)", color=INK2)
    t = dyn.t * 1e9
    ax2.plot(t, dyn.mean_trace, color=SERIES[0], lw=1.2, label="core average")
    ax2.plot(t, dyn.worst_trace, color=SERIES[1], lw=1.2, label="worst cell")
    ax2.set_xlabel("time (ns)"); ax2.set_ylabel("effective supply (V)")
    ax2.set_title("cell supply during wake-up event")
    ax2.legend(loc="lower left")
    fig.suptitle(f"{gm.project.name} {net} dynamic IR drop (vectorless, clock-synchronous pulses)",
                 fontsize=11, fontweight="bold", color=INK)
    _caption(fig, "Per-cycle current pulses use an ASSUMED peak-to-average ratio; replace with gate-level "
                  "per-cycle power waveforms for signoff-relevant dynamic IR.")
    return _save(fig, path)


def thermal_map_plot(tm, project, path: Path, title: str) -> str:
    fig, ax = plt.subplots(figsize=(6.0, 5.0))
    W = tm.x_um[-1] + (tm.x_um[1] - tm.x_um[0]) / 2
    H = tm.y_um[-1] + (tm.y_um[1] - tm.y_um[0]) / 2
    im = ax.imshow(tm.temp_c, origin="lower", cmap=CMAP_ORANGE, extent=[0, W, 0, H], interpolation="bilinear")
    from ..uncertainty import nom
    off = (nom(project.core["x0_mm"]) * 1e3, nom(project.core["y0_mm"]) * 1e3)
    _outline_blocks(ax, project.blocks, offset=off, label=False)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, shrink=0.85)
    cb.set_label("junction temperature (C)", color=INK2)
    ax.set_title(title)
    ax.set_xlabel("x (um, die)"); ax.set_ylabel("y (um, die)")
    _caption(fig, f"max {tm.t_max:.2f} C, ambient {tm.t_amb:.0f} C, theta_ja {tm.theta_ja:.1f} C/W.  "
                  "2-D die conduction with compact package/cooling boundary - not a CFD result.")
    return _save(fig, path)


# ============================================================ frequency domain
def impedance_plot(curves: Mapping[str, tuple], z_target: float, f_max: float, path: Path, title: str,
                   resonances: Optional[List[Dict[str, float]]] = None) -> str:
    fig, ax = plt.subplots(figsize=(7.4, 4.4))
    for k, (name, (f, z)) in enumerate(curves.items()):
        ax.loglog(f, np.abs(z), color=SERIES[k % len(SERIES)], label=name, lw=1.6)
    ax.hlines(z_target, f[0], f_max, color=STATUS["critical"], lw=1.2, ls="--")
    ax.text(f[0] * 1.3, z_target * 1.12, f"target {z_target*1e3:.0f} mOhm (to {f_max/1e6:.0f} MHz)",
            fontsize=8, color=INK2)
    for r in (resonances or [])[:3]:
        ax.annotate(f"{_fmt_hz(r['f_hz'])}\n{r['z_ohm']*1e3:.0f} mOhm", (r["f_hz"], r["z_ohm"]),
                    xytext=(8, 4), textcoords="offset points", fontsize=7, color=INK2)
    ax.set_xlabel("frequency (Hz)"); ax.set_ylabel("|Z| seen by the die (Ohm)")
    ax.set_title(title)
    ax.legend(loc="upper left")
    ax.grid(True, which="both", lw=0.4)
    _caption(fig, "Closed-loop PDN impedance (VRM averaged model + planes + decaps + package + die). "
                  "Flat target impedance is a screening criterion; time-domain droop governs.")
    return _save(fig, path)


def bode_plot(f, T, margins: Mapping[str, float], path: Path, title: str) -> str:
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(7.0, 5.0), sharex=True)
    a1.semilogx(f, 20 * np.log10(np.abs(T)), color=SERIES[0])
    a1.axhline(0, color=AXIS, lw=0.8)
    a1.set_ylabel("loop gain (dB)")
    a1.set_title(title)
    ph = np.degrees(np.unwrap(np.angle(T)))
    a2.semilogx(f, ph, color=SERIES[0])
    a2.axhline(-180, color=STATUS["critical"], lw=0.8, ls="--")
    a2.set_ylabel("phase (deg)"); a2.set_xlabel("frequency (Hz)")
    fc, pm = margins.get("crossover_hz"), margins.get("phase_margin_deg")
    if fc and not math.isnan(fc):
        for a in (a1, a2):
            a.axvline(fc, color=MUTED, lw=0.8, ls=":")
        a1.text(fc * 1.15, 5, f"f_c {fc/1e3:.0f} kHz", fontsize=8, color=INK2)
        a2.text(fc * 1.15, -170, f"PM {pm:.0f} deg", fontsize=8, color=INK2)
    _caption(fig, "Averaged peak-current-mode buck, type-II compensation; loop broken at the power-stage "
                  "control input (exact for a VCCS).")
    return _save(fig, path)


# ============================================================ time domain
def droop_plot(results: Mapping[str, Any], v_nom: float, v_min: float, path: Path, title: str,
               zoom_ns: float = 300.0, t_event: float = 500e-9) -> str:
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.0), gridspec_kw={"width_ratios": [1.4, 1]})
    for k, (name, r) in enumerate(results.items()):
        c = SERIES[k % len(SERIES)]
        a1.plot(r.t * 1e6, r.v_die, color=c, lw=1.2, label=f"{name} (droop {r.droop_v*1e3:.1f} mV)")
        m = (r.t >= t_event - 50e-9) & (r.t <= t_event + zoom_ns * 1e-9)
        a2.plot((r.t[m] - t_event) * 1e9, r.v_die[m], color=c, lw=1.2)
    lo = min(float(r.v_die.min()) for r in results.values())
    hi = max(float(r.v_die.max()) for r in results.values())
    span = max(hi - lo, 2e-3)
    ylo, yhi = lo - 0.3 * span, hi + 0.2 * span
    for a in (a1, a2):
        a.set_ylim(ylo, yhi)
        if ylo <= v_min <= yhi:
            a.axhline(v_min, color=STATUS["critical"], lw=1.0, ls="--")
    a1.text(0.02, 0.04, f"V_min (library corner) {v_min:.3f} V = {(lo - v_min)*1e3:.0f} mV below the lowest point"
            if v_min < ylo else f"V_min {v_min:.3f} V", transform=a1.transAxes, fontsize=8, color=INK2)
    a1.set_xlabel("time (us)"); a1.set_ylabel("die supply (V)")
    a1.set_title("full response (first / second / third droop)")
    a2.set_xlabel("time after event (ns)"); a2.set_title("first-droop zoom")
    a1.legend(loc="upper right", fontsize=7)
    fig.suptitle(title, fontsize=11, fontweight="bold", color=INK)
    _caption(fig, "Lumped rail model, MNA transient (trapezoidal).  Event currents from the workload power "
                  "model (assumed activity).")
    return _save(fig, path)


def supply_noise_plot(t, v, v_nom, ripple: Mapping[str, float], path: Path, title: str) -> str:
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 3.8), gridspec_kw={"width_ratios": [1.6, 1]})
    a1.plot(t * 1e9, (v - v_nom) * 1e3, color=SERIES[0], lw=1.0)
    a1.set_xlabel("time (ns)"); a1.set_ylabel("die supply - V_nom (mV)")
    a1.set_title("steady-state cycle noise (max workload)")
    names = list(ripple.keys())
    vals = [ripple[k] * 1e3 for k in names]
    a2.barh(names, vals, color=SERIES[0], height=0.5)
    for y, val in enumerate(vals):
        a2.text(val, y, f" {val:.2f}", va="center", fontsize=8, color=INK2)
    a2.set_xlabel("peak-to-peak (mV)"); a2.set_title("noise contributions")
    a2.grid(axis="y", visible=False)
    fig.suptitle(title, fontsize=11, fontweight="bold", color=INK)
    return _save(fig, path)


# ============================================================ power
POWER_COMPONENTS = ["data", "clock", "sram", "leakage", "io", "fixed/analog"]


def power_bars(results: Mapping[str, Any], path: Path, title: str) -> str:
    profiles = list(results.keys())
    comp = {c: [results[p].breakdown()[c] * 1e3 for p in profiles] for c in POWER_COMPONENTS}
    fig, ax = plt.subplots(figsize=(8.4, 0.55 * len(profiles) + 1.8))
    left = np.zeros(len(profiles))
    for k, c in enumerate(POWER_COMPONENTS):
        vals = np.array(comp[c])
        ax.barh(profiles, vals, left=left, color=SERIES[k], height=0.55, label=c, edgecolor=SURFACE, lw=1.0)
        left += vals
    for y, tot in enumerate(left):
        ax.text(tot, y, f"  {tot:.1f} mW", va="center", fontsize=8, color=INK)
    ax.set_xlabel("power (mW)"); ax.set_title(title)
    ax.invert_yaxis()
    ax.grid(axis="y", visible=False)
    ax.legend(ncol=6, loc="upper center", bbox_to_anchor=(0.5, -0.12), fontsize=7)
    ax.set_xlim(0, left.max() * 1.18)
    _caption(fig, "Dynamic = alpha C V^2 f (assumed activity unless SAIF/VCD attached); leakage evaluated at "
                  "the electro-thermal operating temperature.")
    return _save(fig, path)


def block_power_bars(result, path: Path, title: str, top: int = 14) -> str:
    bl = sorted(result.blocks, key=lambda b: -b.total_w)[:top]
    names = [b.name for b in bl]
    parts = {"dynamic": [b.p_dyn_w * 1e3 for b in bl], "leakage": [b.p_leak_w * 1e3 for b in bl],
             "fixed/analog": [b.p_fixed_w * 1e3 for b in bl]}
    fig, ax = plt.subplots(figsize=(7.6, 0.32 * len(names) + 1.4))
    left = np.zeros(len(names))
    for k, (c, vals) in enumerate(parts.items()):
        ax.barh(names, vals, left=left, color=SERIES[[0, 3, 5][k]], height=0.6, label=c, edgecolor=SURFACE, lw=1)
        left += np.array(vals)
    ax.invert_yaxis(); ax.grid(axis="y", visible=False)
    ax.set_xlabel("power (mW)"); ax.set_title(title)
    ax.legend(loc="lower right")
    return _save(fig, path)


# ============================================================ comparisons
def package_comparison_plot(items, path: Path, title: str) -> str:
    keys = [it.key for it in items]
    subs = ["electrical", "signal_integrity", "thermal", "cost", "availability"]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.2), gridspec_kw={"width_ratios": [1.5, 1]})
    x = np.arange(len(keys))
    w = 0.8 / len(subs)
    for k, s in enumerate(subs):
        a1.bar(x + (k - 2) * w, [it.metrics["subscores"][s] for it in items], width=w * 0.92, color=SERIES[k], label=s)
    a1.set_xticks(x, keys, rotation=0, fontsize=8)
    a1.set_ylabel("normalised sub-score (0-1)"); a1.set_ylim(0, 1.15)
    a1.set_title("sub-scores")
    a1.legend(ncol=5, fontsize=7, loc="upper center")
    a1.grid(axis="x", visible=False)
    colors = [STATUS["good"] if it.robust else (STATUS["warning"] if it.feasible else STATUS["critical"]) for it in items]
    a2.barh(keys, [it.score for it in items], color=colors, height=0.55)
    for y, it in enumerate(items):
        lab = "robust" if it.robust else ("nominal only" if it.feasible else "infeasible")
        a2.text(it.score, y, f"  {it.score:.2f}  {lab}", va="center", fontsize=8, color=INK)
    a2.invert_yaxis(); a2.set_xlim(0, 1.25); a2.grid(axis="y", visible=False)
    a2.set_xlabel("weighted score"); a2.set_title("overall (status = constraint check)")
    fig.suptitle(title, fontsize=11, fontweight="bold", color=INK)
    _caption(fig, "Library values are family-level literature ranges, not supplier quotes or extracted parasitics. "
                  "'nominal only' = passes at nominal, fails at the adverse parameter corner.")
    return _save(fig, path)


def cooling_plot(table: Mapping[str, Mapping[str, float]], tj_limit: float, path: Path, title: str) -> str:
    """table[cooling][package] -> T_j."""
    coolings = list(table.keys())
    pkgs = list(next(iter(table.values())).keys())
    fig, ax = plt.subplots(figsize=(9.5, 4.2))
    x = np.arange(len(coolings))
    w = 0.8 / len(pkgs)
    for k, pk in enumerate(pkgs):
        vals = [table[c][pk] for c in coolings]
        ax.bar(x + (k - (len(pkgs) - 1) / 2) * w, vals, width=w * 0.92, color=SERIES[k], label=pk)
    ax.axhline(tj_limit, color=STATUS["critical"], lw=1.2, ls="--")
    ax.text(x[0] - 0.45, tj_limit, f"T_j limit {tj_limit:.0f} C", ha="left", va="bottom", fontsize=8, color=INK2)
    ax.set_xticks(x, [c.replace("_", "\n") for c in coolings], fontsize=8)
    ax.set_ylabel("junction temperature (C)"); ax.set_title(title)
    ax.legend(ncol=len(pkgs), fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.2))
    ax.set_ylim(0, max(tj_limit, max(max(v.values()) for v in table.values())) * 1.12)
    ax.grid(axis="x", visible=False)
    _caption(fig, "Compact theta_ja network at the worst-case ambient with electro-thermal leakage; "
                  "heatsink/TIM values are generic literature ranges.")
    return _save(fig, path)


def margin_waterfall(budget, path: Path, title: str) -> str:
    rows = budget.table()
    names = [r["component"] for r in rows]
    vals = [r["worst_mv"] for r in rows]
    start = budget.v_nom * 1e3
    fig, ax = plt.subplots(figsize=(8.6, 3.8))
    level = start
    ax.bar(0, start, color=SERIES[0], width=0.6)
    ax.text(0, start, f"{start:.0f}", ha="center", va="bottom", fontsize=8)
    ax.set_title(title)
    for k, (n, v) in enumerate(zip(names, vals), start=1):
        ax.bar(k, -v, bottom=level, color=SERIES[1], width=0.6)
        ax.text(k, level, f"-{v:.1f}", ha="center", va="bottom", fontsize=8, color=INK2)
        level -= v
    k = len(names) + 1
    ok = level >= budget.v_min * 1e3
    bottom = min(level, budget.v_min * 1e3)
    lo = bottom - 0.12 * (start - bottom)
    ax.bar(k, level, color=STATUS["good"] if ok else STATUS["critical"], width=0.6)
    ax.text(k, max(level, lo), f"{level:.1f} mV\n{'PASS' if ok else 'FAIL'}", ha="center", va="bottom", fontsize=8,
            color=INK)
    ax.axhline(budget.v_min * 1e3, color=STATUS["critical"], ls="--", lw=1)
    ax.set_xticks(range(k + 1), ["V_nom"] + names + ["worst cell"], rotation=25, ha="right", fontsize=8)
    ax.set_ylim(lo, start + 0.06 * (start - bottom) + 2)
    ax.set_ylabel("mV"); ax.set_title(title)
    ax.grid(axis="x", visible=False)
    _caption(fig, f"Worst-case linear stack.  Margin {budget.margin_worst_v*1e3:.1f} mV worst-case, "
                  f"{budget.margin_rss_v*1e3:.1f} mV RSS.  V_min = library corner {budget.v_min:.3f} V.")
    return _save(fig, path)


def mc_histogram(samples_mv: Sequence[float], path: Path, title: str, p_fail: float) -> str:
    fig, ax = plt.subplots(figsize=(7.0, 3.6))
    s = np.asarray(samples_mv)
    ax.hist(s, bins=60, color=SERIES[0], edgecolor=SURFACE, lw=0.5)
    ax.axvline(0, color=STATUS["critical"], lw=1.2, ls="--")
    ax.text(0, ax.get_ylim()[1] * 0.92, "  margin = 0", fontsize=8, color=INK2)
    ax.set_xlabel("worst-cell voltage margin (mV)"); ax.set_ylabel("samples")
    ax.set_title(title)
    ax.grid(axis="x", visible=False)
    _caption(fig, f"{len(s)} Monte-Carlo samples over configured input distributions; P(margin<0) = {p_fail:.2%}. "
                  "Power-law surrogate for dynamic droop, exact linear scaling for IR.")
    return _save(fig, path)


def risk_matrix(risks: Sequence[Mapping[str, Any]], path: Path, title: str) -> str:
    fig, ax = plt.subplots(figsize=(7.6, 5.6))
    lvl = {1: "good", 2: "good", 3: "warning", 4: "serious", 5: "critical"}
    for li in range(1, 6):
        for im in range(1, 6):
            sc = li * im
            st = "good" if sc <= 4 else "warning" if sc <= 9 else "serious" if sc <= 15 else "critical"
            ax.add_patch(Rectangle((im - 0.5, li - 0.5), 1, 1, color=STATUS[st], alpha=0.22, lw=0))
    cells: Dict[tuple, List[str]] = {}
    for k, r in enumerate(risks, start=1):
        cells.setdefault((r["likelihood"], r["impact"]), []).append(str(k))
    for (li, im), ids in cells.items():
        ax.text(im, li, ",".join(ids), ha="center", va="center", fontsize=9, color=INK, fontweight="bold")
    ax.set_xlim(0.5, 5.5); ax.set_ylim(0.5, 5.5)
    ax.set_xticks(range(1, 6), ["negligible", "minor", "moderate", "major", "severe"], fontsize=8)
    ax.set_yticks(range(1, 6), ["rare", "unlikely", "possible", "likely", "almost\ncertain"], fontsize=8)
    ax.set_xlabel("impact"); ax.set_ylabel("likelihood")
    ax.grid(False)
    ax.set_title(title)
    legend = "\n".join(f"{k}. {r['title']} [{r['status']}]" for k, r in enumerate(risks, start=1))
    fig.text(1.0, 0.5, legend, fontsize=7, color=INK2, va="center", ha="left")
    return _save(fig, path)
