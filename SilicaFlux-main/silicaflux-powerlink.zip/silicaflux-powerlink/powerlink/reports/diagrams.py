"""Engineering diagrams: voltage-domain floorplan and power-delivery path chain."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Mapping

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

from ..uncertainty import nom
from .plots import AXIS, INK, INK2, MUTED, SERIES, SURFACE, _save


def voltage_domain_diagram(p, path: Path, supplies=None) -> str:
    """Die floorplan coloured by supply rail / voltage domain, with pads or bumps."""
    W = nom(p.die["width_mm"]) * 1e3
    H = nom(p.die["height_mm"]) * 1e3
    x0 = nom(p.core["x0_mm"]) * 1e3
    y0 = nom(p.core["y0_mm"]) * 1e3
    cw = nom(p.core["width_mm"]) * 1e3
    ch = nom(p.core["height_mm"]) * 1e3
    rails = list(p.rails.keys())
    color = {r: SERIES[k % len(SERIES)] for k, r in enumerate(rails)}
    fig, ax = plt.subplots(figsize=(7.6, 7.0))
    ax.add_patch(Rectangle((0, 0), W, H, fill=False, ec=INK, lw=1.2))
    io_rail = p.chip.get("io", {}).get("io_rail", "VDDIO")
    band = min(x0, y0) * 0.55
    # pad ring band
    for rect in ((0, 0, W, band), (0, H - band, W, band), (0, 0, band, H), (W - band, 0, band, H)):
        ax.add_patch(Rectangle(rect[:2], rect[2], rect[3], color=color.get(io_rail, SERIES[1]), alpha=0.18, lw=0))
    ax.text(W / 2, band / 2, f"I/O pad ring ({io_rail})", ha="center", va="center", fontsize=8, color=INK2)
    ax.add_patch(Rectangle((x0, y0), cw, ch, fill=False, ec=INK2, lw=0.8, ls="--"))
    # domains: shade blocks by their rail
    for b in p.blocks:
        bx0, by0, bx1, by1 = b["rect_um"]
        r = b["rail"]
        hatch = "///" if b["kind"] == "sram" else None
        ax.add_patch(Rectangle((bx0 + x0, by0 + y0), bx1 - bx0, by1 - by0, facecolor=color[r], alpha=0.35,
                               edgecolor=color[r], lw=0.8, hatch=hatch))
        if (bx1 - bx0) > 110 and (by1 - by0) > 45:
            ax.text((bx0 + bx1) / 2 + x0, (by0 + by1) / 2 + y0, b["name"].replace("_", "\n", 1), fontsize=5.5,
                    ha="center", va="center", color=INK)
    # rings
    for ring in p.pdn.get("rings", []):
        off = float(ring.get("core_offset_um", 4.0)) + float(ring.get("width_um", 10)) / 2
        ax.add_patch(Rectangle((x0 - off, y0 - off), cw + 2 * off, ch + 2 * off, fill=False,
                               ec=color[rails[0]], lw=2.0))
    # supply connections
    if supplies:
        for s in supplies:
            mk = "s" if s.kind == "bondwire" else "o"
            c = INK if s.net.startswith("VSS") else color.get(p.pdn["nets"][s.net].get("rail", ""), SERIES[0])
            ax.plot(s.x_um + x0, s.y_um + y0, marker=mk, ms=3.5, color=c, ls="none")
    handles = [Rectangle((0, 0), 1, 1, facecolor=color[r], alpha=0.5) for r in rails]
    labels = [f"{r}  {nom(p.rails[r]['nominal_v']):.2f} V  ({p.rails[r].get('kind', '')})" for r in rails]
    handles.append(Rectangle((0, 0), 1, 1, facecolor="none", hatch="///", edgecolor=INK2))
    labels.append("SRAM macro (macro grid, pins on " + str(p.pdn.get("macros", {}).get("pin_layer", "?")) + ")")
    ax.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, -0.09), ncol=2, fontsize=7)
    doms = p.pdn.get("voltage_domains", {})
    dtxt = "; ".join(f"{k}: {d['power']}/{d['ground']}" + (" (analogue)" if d.get("analog") else "")
                     + (" (switched)" if d.get("switched_power") else "") for k, d in doms.items())
    ax.set_title(f"{p.name} voltage domains and supply connections\n{dtxt}", fontsize=9)
    ax.set_xlim(-20, W + 20); ax.set_ylim(-20, H + 20)
    ax.set_aspect("equal"); ax.grid(False)
    ax.set_xlabel("x (um, die)"); ax.set_ylabel("y (um, die)")
    return _save(fig, path)


def pdn_chain_diagram(paths: Mapping[str, Any], path: Path, title: str) -> str:
    """Power-delivery path from regulator to die for each rail with R/L values."""
    rails = list(paths.keys())
    fig, ax = plt.subplots(figsize=(13, 1.5 + 1.25 * len(rails)))
    stages = ["Regulator", "PCB plane", "PCB decaps", "Pkg pins/balls", "Pkg substrate", "Bond wire/bump",
              "On-die grid", "Die C / load"]
    for k, st in enumerate(stages):
        ax.text(k * 1.6 + 0.65, len(rails) + 0.05, st, ha="center", va="bottom", fontsize=8, color=INK, fontweight="bold")
    for j, rail in enumerate(rails):
        pth = paths[rail]
        y = len(rails) - 1 - j
        reg = pth.regulator
        reg_txt = (f"{type(reg).__name__}\n{reg.v_out:.2f} V") if hasattr(reg, "v_out") else type(reg).__name__
        if hasattr(reg, "f_sw"):
            reg_txt += f"\nfsw {reg.f_sw/1e6:.1f} MHz"
        caps = "\n".join(f"{b.count}x {b.part.name.split('_')[1]}" for b in pth.pcb_banks)
        texts = [reg_txt,
                 f"R {pth.plane.r*1e3:.2f} mOhm\nL {pth.plane.l*1e12:.0f} pH",
                 caps or "-",
                 f"R {pth.pins.r*1e3:.2f} mOhm\nL {pth.pins.l*1e12:.0f} pH\n{pth.connections.n_power_pins} pwr",
                 f"R {pth.substrate.r*1e3:.2f} mOhm\nL {pth.substrate.l*1e12:.0f} pH",
                 f"R {pth.conn.r*1e3:.2f} mOhm\nL {pth.conn.l*1e12:.0f} pH\n{pth.connections.n_power_conn} pwr",
                 f"R_eff {pth.r_grid*1e3:.1f} mOhm",
                 f"C {pth.c_die*1e9:.2f} nF\nESR {pth.r_die_esr*1e3:.1f} mOhm"]
        c = SERIES[j % len(SERIES)]
        for k, t in enumerate(texts):
            ax.add_patch(FancyBboxPatch((k * 1.6, y + 0.08), 1.3, 0.78, boxstyle="round,pad=0.02",
                                        fc=SURFACE, ec=c, lw=1.2))
            ax.text(k * 1.6 + 0.65, y + 0.47, t, ha="center", va="center", fontsize=6.5, color=INK2)
            if k < len(texts) - 1:
                ax.add_patch(FancyArrowPatch((k * 1.6 + 1.3, y + 0.47), (k * 1.6 + 1.6, y + 0.47),
                                             arrowstyle="-|>", mutation_scale=8, color=MUTED))
        ax.text(-0.15, y + 0.47, f"{rail}\n{pth.v_nom:.2f} V", ha="right", va="center", fontsize=8, color=INK,
                fontweight="bold")
    ax.set_xlim(-1.0, len(stages) * 1.6)
    ax.set_ylim(-0.1, len(rails) + 0.45)
    ax.axis("off")
    ax.set_title(title, fontsize=11, fontweight="bold", color=INK)
    fig.text(0.01, 0.0, "External supply -> PCB regulator -> PCB planes -> package pins/balls -> package "
                        "distribution -> bond wires/bumps -> on-die grid -> compute & memory cells.  Loop values.",
             fontsize=7, color=MUTED)
    return _save(fig, path)
