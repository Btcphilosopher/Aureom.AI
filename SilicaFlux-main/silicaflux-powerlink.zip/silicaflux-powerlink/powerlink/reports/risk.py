"""Risk register derived from analysis results.

Likelihood (1-5) is derived from computed utilisation ratios (metric /
allowance) where a metric exists, so that the register moves when the
design or the inputs change; impact (1-5) is an engineering judgement
recorded with each item.  Score = likelihood x impact:
<=4 good, <=9 warning, <=15 serious, >15 critical.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List

from ..uncertainty import nom


def likelihood_from_ratio(r: float) -> int:
    if r is None or math.isnan(r):
        return 3
    if r < 0.3:
        return 1
    if r < 0.6:
        return 2
    if r < 0.9:
        return 3
    if r < 1.0:
        return 4
    return 5


def status(score: int) -> str:
    return "good" if score <= 4 else "warning" if score <= 9 else "serious" if score <= 15 else "critical"


def _item(title, metric, ratio, impact, mitigation, likelihood=None) -> Dict[str, Any]:
    li = likelihood if likelihood is not None else likelihood_from_ratio(ratio)
    sc = li * impact
    return {"title": title, "metric": metric, "ratio": ratio, "likelihood": li, "impact": impact,
            "score": sc, "status": status(sc), "mitigation": mitigation}


def build_risks(p, ctx) -> List[Dict[str, Any]]:
    R = ctx["results"]
    risks: List[Dict[str, Any]] = []
    core = next(r for r, c in p.rails.items() if c.get("on_die_grid"))
    net = next(n for n, c in p.pdn["nets"].items() if c.get("rail") == core)
    v = nom(p.rails[core]["nominal_v"])
    bud = p.rails[core]["budget"]
    b = R["budgets"][core]
    comp = {c.name: c for c in b.components}
    st = comp["static IR (worst cell)"]
    risks.append(_item("Core static IR drop", f"{st.worst_v*1e3:.1f} mV worst corner vs {st.allocation_v*1e3:.0f} mV",
                       st.worst_v / st.allocation_v, 4, "add M8/M9 straps or pads; signoff static IR (RedHawk-SC/Voltus)"))
    dy = comp["dynamic droop + cycle noise"]
    risks.append(_item("Core dynamic droop / cycle noise",
                       f"{dy.worst_v*1e3:.1f} mV worst corner vs {dy.allocation_v*1e3:.0f} mV",
                       dy.worst_v / dy.allocation_v, 4,
                       "increase on-die decap (see decap what-if), staggered tile wake, vectored dynamic IR"))
    mw = b.margin_worst_v
    risks.append(_item("Core total PI margin (worst-case stack)",
                       f"margin {mw*1e3:.1f} mV worst, {b.margin_rss_v*1e3:.1f} mV RSS, "
                       f"P(fail) MC {b.mc['p_fail']:.2%}" if b.mc else f"margin {mw*1e3:.1f} mV",
                       None, 5, "re-balance budget; tighten regulator setpoint; more decap",
                       likelihood=5 if mw < 0 else (3 if b.margin_rss_v < 0.25 * b.available_v else
                                                     2 if mw < 0.25 * b.available_v else 1)))
    em_max = max((r["ratio"] for r in ctx["tables"]["em"]), default=0.0)
    worst_em = max(ctx["tables"]["em"], key=lambda r: r["ratio"]) if ctx["tables"]["em"] else {"item": "-"}
    risks.append(_item("Electromigration (straps, vias, bond wires)",
                       f"worst {worst_em['item']}: {em_max:.0%} of limit", em_max, 5,
                       "foundry EM rule deck at signoff temperature; via arrays at ring/strap ends"))
    z = R["z"][core]
    if "loop" in z:
        pm = z["loop"]["margins"]["phase_margin_deg"]
        li = 1 if pm >= 60 else 2 if pm >= 45 else 4 if pm >= 30 else 5
        risks.append(_item("Core regulator loop stability", f"phase margin {pm:.0f} deg at "
                           f"{z['loop']['margins']['crossover_hz']/1e3:.0f} kHz (averaged model)", None, 4,
                           "verify with the PMIC vendor model and a load-step bench measurement", likelihood=li))
        rip = z["ripple"]["ripple_die_pp_v"]
        risks.append(_item("Regulator ripple at die", f"{rip*1e3:.2f} mV p-p vs {nom(bud['ripple'])*v*1e3:.0f} mV",
                           rip / (nom(bud["ripple"]) * v), 2, "output-cap ESR/ESL selection, layout"))
    pll = next((r for r, c in p.rails.items() if c.get("kind") == "analog"), None)
    if pll:
        lim = nom(p.rails[pll].get("noise_limit_mv_pp", 10)) * 1e-3
        rp = R["z"][pll].get("ripple", {}).get("ripple_die_pp_v", 0.0)
        bp = R["budgets"][pll]
        dd = next((c.worst_v for c in bp.components if c.name == "dynamic droop"), 0.0)
        risks.append(_item("PLL analogue supply noise", f"{(rp + dd)*1e3:.2f} mV p-p vs {lim*1e3:.0f} mV limit",
                           (rp + dd) / lim, 4, "dedicated LDO + RC filter, separate VSSA, guard ring"))
    base = next((it for it in R["packages"] if it.key == p.baseline_package), None)
    if base:
        m = base.metrics
        risks.append(_item("I/O simultaneous-switching noise (chiplet link)",
                           f"{m['sso_noise_v']*1e3:.0f} mV nominal / {m['sso_noise_v_worst']*1e3:.0f} mV fast-edge "
                           f"corner vs {m['sso_limit_v']*1e3:.0f} mV", m["sso_noise_v_worst"] / m["sso_limit_v"], 3,
                           "slew-rate-controlled pads, more VDDIO/VSSIO pairs, LVDS/low-swing link"))
        spare = (m["pins_available"] - m["pins_required"]) / m["pins_available"]
        risks.append(_item("Package pin budget", f"{m['pins_required']} of {m['pins_available']} "
                           f"(incl. {int(p.chip.get('io', {}).get('spare_fraction', 0.1)*100)}% spare)",
                           m["pins_required"] / m["pins_available"], 3, "larger body or BGA if I/O grows"))
    th = R["thermal"]
    tj = th["table"][ctx["project"].chip.get("analysis", {}).get("reference_cooling", "natural_convection")][p.baseline_package]
    risks.append(_item("Junction temperature", f"{tj:.1f} C at {th['t_amb']:.0f} C ambient vs {th['tj_limit']:.0f} C",
                       (tj - th["t_amb"]) / max(th["tj_limit"] - th["t_amb"], 1e-3), 4,
                       "cooling option per comparison; thermal signoff (Icepak/Celsius)"))
    srcs = set()
    for pr in R["power_hot"]["profiles"].values():
        srcs |= set(pr.activity_sources())
    assumed = "assumption" in srcs
    risks.append(_item("Switching activity is assumed, not measured",
                       "activity source: " + ", ".join(sorted(srcs)), None, 3,
                       "gate-level SAIF/VCD from representative firmware; re-run PowerLink",
                       likelihood=4 if assumed else 1))
    risks.append(_item("Technology data are generic (no PDK selected)",
                       f"technology '{p.technology.get('name')}' tagged assumption", None, 4,
                       "select PDK; replace metal/via/EM/decap/leakage values; implement and sign off",
                       likelihood=4))
    dec = R["decap"]
    risks.append(_item("On-die decoupling sufficiency",
                       f"{dec['c_die_f']*1e9:.2f} nF vs {max(dec['c_required_first_droop_f'], dec['c_required_cycle_charge_f'])*1e9:.2f} nF rule-of-thumb",
                       max(dec["c_required_first_droop_f"], dec["c_required_cycle_charge_f"]) / dec["c_die_f"] * 0.8, 3,
                       "allocate decap-cell area per what-if table; MOS-cap leakage trade-off"))
    f_clk = p.clock_hz
    near = [r for r in z["resonances"] for k in (1, 2, 3) if abs(r["f_hz"] / (k * f_clk) - 1) < 0.15]
    risks.append(_item("PDN resonance near clock harmonics",
                       ", ".join(f"{r['f_hz']/1e6:.0f} MHz ({r['z_ohm']*1e3:.0f} mOhm)" for r in near) or "none within 15%",
                       None, 3, "move resonance with decap/ESR damping; check with vectored dynamic IR",
                       likelihood=3 if near else 1))
    if th["runaway"]:
        ref_c = ctx["project"].chip.get("analysis", {}).get("reference_cooling", "natural_convection")
        hit = (ref_c, p.baseline_package) in th["runaway"]
        risks.append(_item("Leakage-temperature non-convergence (runaway) in some package/cooling options",
                           ", ".join(f"{c}/{k}" for c, k in th["runaway"]) +
                           ("" if hit else " - none is the reference cooling with the baseline package"),
                           None, 5, "exclude those combinations; keep the reference cooling",
                           likelihood=4 if hit else 1))
    risks.sort(key=lambda r: -r["score"])
    return risks
