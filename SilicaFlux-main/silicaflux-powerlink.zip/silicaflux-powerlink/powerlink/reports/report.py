"""Report generation: one structured document rendered to Markdown and to a
self-contained HTML file (figures embedded as base64), plus CSV tables."""
from __future__ import annotations

import base64
import csv
import datetime as _dt
import html
import os
from pathlib import Path
from typing import Any, Dict, List, Sequence

import numpy as np

from ..uncertainty import nom, parse_value


class Doc:
    def __init__(self) -> None:
        self.blocks: List[tuple] = []

    def h(self, level: int, text: str):
        self.blocks.append(("h", level, text))

    def p(self, text: str):
        self.blocks.append(("p", text))

    def ul(self, items: Sequence[str]):
        self.blocks.append(("ul", list(items)))

    def table(self, headers: Sequence[str], rows: Sequence[Sequence[Any]]):
        self.blocks.append(("table", list(headers), [list(r) for r in rows]))

    def img(self, path: str, caption: str):
        self.blocks.append(("img", path, caption))

    # ------------------------------------------------------------------ render
    def markdown(self, base: Path) -> str:
        out = []
        for b in self.blocks:
            if b[0] == "h":
                out.append("#" * b[1] + " " + b[2] + "\n")
            elif b[0] == "p":
                out.append(b[1] + "\n")
            elif b[0] == "ul":
                out.append("\n".join(f"- {x}" for x in b[1]) + "\n")
            elif b[0] == "table":
                esc = lambda t: str(t).replace("|", "\\|")  # noqa: E731
                out.append("| " + " | ".join(esc(h) for h in b[1]) + " |")
                out.append("|" + "|".join("---" for _ in b[1]) + "|")
                for r in b[2]:
                    out.append("| " + " | ".join(esc(_fmt(x)) for x in r) + " |")
                out.append("")
            elif b[0] == "img":
                rel = os.path.relpath(b[1], base)
                out.append(f"![{b[2]}]({rel})\n\n*{b[2]}*\n")
        return "\n".join(out)

    def html(self, title: str) -> str:
        css = """
:root{--surface:#fcfcfb;--page:#f9f9f7;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;--grid:#e1e0d9;
--good:#0ca30c;--warn:#fab219;--serious:#ec835a;--crit:#d03b3b}
body{margin:0;background:var(--page);color:var(--ink);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1100px;margin:0 auto;padding:24px 16px;background:var(--surface)}
h1{font-size:26px}h2{font-size:20px;border-bottom:1px solid var(--grid);padding-bottom:4px;margin-top:36px}
h3{font-size:16px;margin-top:24px}table{border-collapse:collapse;width:100%;font-size:12.5px;margin:8px 0 16px;
display:block;overflow-x:auto}th,td{border-bottom:1px solid var(--grid);padding:4px 8px;text-align:left;
font-variant-numeric:tabular-nums;white-space:nowrap}th{color:var(--ink2);font-weight:600}
figure{margin:16px 0}figure img{max-width:100%;height:auto;border:1px solid var(--grid)}
figcaption{color:var(--muted);font-size:12px}
.good{color:var(--good);font-weight:600}.warning{color:#b07800;font-weight:600}
.serious{color:#c0582b;font-weight:600}.critical{color:var(--crit);font-weight:600}
code{background:#f0efec;padding:0 3px;border-radius:3px}"""
        out = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' "
               f"content='width=device-width,initial-scale=1'><title>{html.escape(title)}</title>"
               f"<style>{css}</style></head><body><main>"]
        for b in self.blocks:
            if b[0] == "h":
                out.append(f"<h{b[1]}>{html.escape(b[2])}</h{b[1]}>")
            elif b[0] == "p":
                out.append(f"<p>{_inline(b[1])}</p>")
            elif b[0] == "ul":
                out.append("<ul>" + "".join(f"<li>{_inline(x)}</li>" for x in b[1]) + "</ul>")
            elif b[0] == "table":
                th = "".join(f"<th>{html.escape(h)}</th>" for h in b[1])
                rows = "".join("<tr>" + "".join(f"<td{_cls(x)}>{html.escape(_fmt(x))}</td>" for x in r) + "</tr>"
                               for r in b[2])
                out.append(f"<table><thead><tr>{th}</tr></thead><tbody>{rows}</tbody></table>")
            elif b[0] == "img":
                data = base64.b64encode(Path(b[1]).read_bytes()).decode()
                out.append(f"<figure><img alt='{html.escape(b[2])}' src='data:image/png;base64,{data}'>"
                           f"<figcaption>{html.escape(b[2])}</figcaption></figure>")
        out.append("</main></body></html>")
        return "\n".join(out)


def _inline(s: str) -> str:
    import re
    s = html.escape(s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"`(.+?)`", r"<code>\1</code>", s)
    return s


def _cls(x: Any) -> str:
    if isinstance(x, str) and x.lower() in ("good", "warning", "serious", "critical"):
        return f" class='{x.lower()}'"
    if isinstance(x, str) and x in ("PASS", "FAIL"):
        return " class='good'" if x == "PASS" else " class='critical'"
    return ""


def _fmt(x: Any) -> str:
    if isinstance(x, bool):
        return "PASS" if x else "FAIL"
    if isinstance(x, (float, np.floating)):
        if x == 0:
            return "0"
        a = abs(x)
        if a >= 1000 or a < 0.01:
            return f"{x:.3g}"
        return f"{x:.3f}".rstrip("0").rstrip(".")
    return str(x)


def _write_csv(path: Path, headers, rows) -> None:
    with path.open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(headers)
        for r in rows:
            w.writerow(r)


# ============================================================================
def write_reports(p, ctx) -> Dict[str, Any]:
    out: Path = ctx["out"]
    R = ctx["results"]
    F = ctx["figures"]
    core = next(r for r, c in p.rails.items() if c.get("on_die_grid"))
    net = next(n for n, c in p.pdn["nets"].items() if c.get("rail") == core)
    prof = R["power_hot"]["profiles"]
    prof_nom = R["power_nom"]["profiles"]
    max_prof = R["max_profile"]
    ir = R["ir"]
    dyn = R["dyn"]
    z = R["z"]
    budgets = R["budgets"]
    items = R["packages"]
    th = R["thermal"]
    risks = R["risks"]
    dec = R["decap"]
    t_hot = th["t_amb"]
    v_core = nom(p.rails[core]["nominal_v"])
    d = Doc()
    d.h(1, f"SilicaFlux PowerLink - {p.name} power, package and PCB co-design report")
    d.p(f"Generated {_dt.datetime.now().strftime('%Y-%m-%d %H:%M')} from `{p.path.name}`; chip status: "
        f"**{p.chip['chip'].get('status', '')}**.  Baseline package `{p.baseline_package}`, reference cooling "
        f"`{p.chip.get('analysis', {}).get('reference_cooling', 'natural_convection')}`.  Runtime "
        f"{ctx['runtime_s']:.0f} s.  Input SHA-256 hashes are in `manifest.json`.")
    srcs: Dict[str, int] = {}
    for row in ctx["assumptions"]:
        srcs[row["source"]] = srcs.get(row["source"], 0) + 1
    d.p("**Provenance of uncertain inputs:** " + ", ".join(f"{k}: {v}" for k, v in sorted(srcs.items())) +
        ".  Activity source: " + ", ".join(sorted({s for pr in prof.values() for s in pr.activity_sources()})) +
        ".  Every number in this report inherits those tags; nothing here is a signoff result.")

    # ------------------------------------------------------------ executive summary
    d.h(2, "1. Executive summary")
    bc = budgets[core]
    best = next((it for it in items if it.feasible), None)
    base = next(it for it in items if it.key == p.baseline_package)
    findings = [
        f"Core rail `{core}` ({v_core:.2f} V): maximum load {prof[max_prof].rail_current(core)*1e3:.1f} mA "
        f"({max_prof}, {t_hot:.0f} C ambient); chip total {prof[max_prof].total_w()*1e3:.0f} mW incl. I/O.",
        f"Static IR drop (worst cell) {ir.worst_drop_v[net]*1e3:.2f} mV nominal / "
        f"{next(c for c in bc.components if c.name.startswith('static')).worst_v*1e3:.2f} mV adverse corner "
        f"against a {nom(p.rails[core]['budget']['dc_ir'])*v_core*1e3:.0f} mV allocation.",
        f"Dynamic drop on the die grid (wake-up event + clock-synchronous pulses) "
        f"{dyn.worst_dyn_drop_v[net]*1e3:.1f} mV total; dynamic component "
        f"{dec['dynamic_component_grid_v']*1e3:.1f} mV against a "
        f"{nom(p.rails[core]['budget']['dynamic'])*v_core*1e3:.0f} mV allocation.",
        f"Power-integrity margin to the {bc.v_min:.2f} V library corner: {bc.margin_nominal_v*1e3:.1f} mV nominal, "
        f"{bc.margin_rss_v*1e3:.1f} mV RSS, {bc.margin_worst_v*1e3:.1f} mV worst-case linear stack"
        + (f"; Monte-Carlo P(margin<0) = {bc.mc['p_fail']:.2%} (n={bc.mc['n']})." if bc.mc else "."),
    ]
    if "loop" in z[core]:
        mm = z[core]["loop"]["margins"]
        findings.append(f"Core regulator loop: crossover {mm['crossover_hz']/1e3:.0f} kHz, phase margin "
                        f"{mm['phase_margin_deg']:.0f} deg; ripple at die {z[core]['ripple']['ripple_die_pp_v']*1e3:.2f} mV p-p.")
    if z[core]["resonances"]:
        r0 = z[core]["resonances"][0]
        vr = z[core]["violation_ratio"]
        findings.append(f"Dominant PDN anti-resonance {r0['f_hz']/1e6:.0f} MHz at {r0['z_ohm']*1e3:.0f} mOhm "
                        f"(package inductance vs on-die capacitance).  Against the flat target "
                        f"{z[core]['z_target']*1e3:.0f} mOhm up to {z[core]['f_target_max']/1e6:.0f} MHz the peak ratio is "
                        f"{vr:.2f} ({'within' if vr <= 1 else 'exceeds'} target); the anti-resonance "
                        f"{'lies above' if r0['f_hz'] > z[core]['f_target_max'] else 'lies inside'} that band but is "
                        f"excited by clock harmonics - the time-domain cycle-noise analysis governs.")
    if best:
        findings.append(f"Package study: highest-scoring feasible option `{best.key}` (score {best.score:.2f}"
                        f"{', robust at the adverse corner' if best.robust else ', but NOT robust at the adverse corner: ' + '; '.join(best.notes)}). "
                        f"Baseline `{base.key}`: {'feasible' if base.feasible else 'infeasible'}"
                        f"{'' if base.robust else ' (' + '; '.join(base.notes) + ')'}; pins {base.metrics['pins_required']}/"
                        f"{base.metrics['pins_available']}.")
    tref = p.chip.get("analysis", {}).get("reference_cooling", "natural_convection")
    findings.append(f"Thermal: T_j {th['table'][tref][p.baseline_package]:.1f} C with `{tref}` at {t_hot:.0f} C "
                    f"ambient (limit {th['tj_limit']:.0f} C); electro-thermal iteration converged for all workloads: "
                    f"{all(th['converged'].values())}.")
    top = [r for r in risks if r["status"] in ("serious", "critical")]
    findings.append("Highest risks: " + ("; ".join(f"{r['title']} ({r['status']})" for r in top[:4])
                                         if top else "none above 'warning'") + ".")
    d.ul(findings)
    verdict = _verdict(p, ctx)
    d.h(3, "Are the proposed rails, package and PCB realistic?")
    d.ul(verdict)

    # ------------------------------------------------------------ architecture
    d.h(2, "2. Power-delivery architecture")
    d.img(F["pdn_chain"], "Power-delivery path per rail: regulator, PCB plane, decaps, package pins, substrate, "
                          "bond wires/bumps, on-die grid and die capacitance (loop values).")
    d.img(F["domains"], "Voltage domains, macro regions, core ring and supply connections.")
    rows = []
    for r, c in p.rails.items():
        pth = None
        rows.append([r, nom(c["nominal_v"]), nom(c["min_v"]), nom(c["max_v"]), c["regulator"],
                     p.pcb["regulators"][c["regulator"]]["topology"], c.get("kind", ""),
                     prof[max_prof].rail_current(r) * 1e3])
    d.table(["rail", "V_nom", "V_min", "V_max", "regulator", "topology", "kind", f"I_max mA ({max_prof})"], rows)

    # ------------------------------------------------------------ power
    d.h(2, "3. Power consumption")
    d.img(F["power_profiles"], "Power per workload profile split into data switching, clock, SRAM, leakage, "
                               "I/O and analogue.")
    rows = []
    for k, pr in prof.items():
        bd = pr.breakdown()
        rows.append([k, pr.rail_power(core) * 1e3, bd["leakage"] * 1e3, sum(pr.io.values()) * 1e3,
                     pr.total_w() * 1e3, prof_nom[k].total_w() * 1e3, th["tmax_by_profile"][k]])
    d.table(["profile", f"{core} mW", "leakage mW", "I/O mW", f"total mW @{t_hot:.0f}C",
             f"total mW @{nom(parse_value(p.thermal['ambient_c']).nom):.0f}C", "T_j max C"], rows)
    d.img(F["power_blocks"], f"Block power breakdown for {max_prof}.")
    d.p("Dynamic power uses P = alpha C V^2 f with alpha = P(0->1 per cycle); C from gate-equivalent counts x "
        "switchable capacitance per GE; clock power from flop counts.  Leakage is technology-dependent and "
        "evaluated at the self-consistent electro-thermal temperature.  All activity values are planning "
        "assumptions unless a SAIF/VCD file is attached in the workload configuration.")
    if "activity_demo" in R:
        a = R["activity_demo"]
        d.p(f"Activity-import pipeline demonstration (not used for the power numbers): parsed "
            f"`{Path(a['vcd']).name}` ({a['nets']} nets, {a['duration_s']*1e6:.1f} us), block toggle rates "
            + ", ".join(f"{k}: TR={v['toggle_rate']:.4f}/cycle (alpha {v['alpha']:.4f})" for k, v in a["blocks"].items())
            + f"; SAIF written and re-read with identical toggle counts: {a['saif_roundtrip_ok']}.")

    # ------------------------------------------------------------ static IR
    d.h(2, "4. Static IR drop and current density")
    d.img(F["ir_static"], "Static IR-drop heat map of the core grid at the maximum workload.")
    brk = ir.drop_breakdown[net]
    d.table(["component", "mV"], [["off-die (PCB plane, pins, substrate)", brk["off_die_v"] * 1e3],
                                  ["die connections (bond wires/bumps + pad stubs)", brk["die_connection_v"] * 1e3],
                                  ["on-die, worst cell", brk["on_die_worst_v"] * 1e3],
                                  ["on-die, current-weighted mean", brk["on_die_mean_v"] * 1e3],
                                  ["total worst cell", ir.worst_drop_v[net] * 1e3]])
    d.p(f"Effective on-die grid resistance (power-weighted) {ir.r_grid_eff[net]*1e3:.1f} mOhm, used in the "
        f"lumped model.  Grid notes: " + ("; ".join(sorted(set(ir.grid.notes))) or "none") + ".")
    d.img(F["current_density"], "Strap current density as a fraction of the EM limit, per layer.")
    d.table(["item", "worst", "limit", "unit", "ratio"],
            [[r["item"], r["worst"], r["limit"], r["unit"], r["ratio"]] for r in ctx["tables"]["em"]])

    # ------------------------------------------------------------ frequency domain
    d.h(2, "5. PDN impedance, regulator response and supply noise")
    d.img(F["impedance"], "Impedance seen by the die: nominal, adverse corner and without PCB decaps.")
    rows = []
    for r, zz in z.items():
        res = zz["resonances"][0] if zz["resonances"] else {"f_hz": float("nan"), "z_ohm": float("nan")}
        lm = zz.get("loop", {}).get("margins", {})
        rows.append([r, zz["z_target"] * 1e3, zz["violation_ratio"], res["f_hz"] / 1e6, res["z_ohm"] * 1e3,
                     lm.get("crossover_hz", float("nan")) / 1e3, lm.get("phase_margin_deg", float("nan")),
                     zz.get("ripple", {}).get("ripple_die_pp_v", float("nan")) * 1e3])
    d.table(["rail", "Z_target mOhm", "max |Z|/Z_t", "peak f MHz", "peak |Z| mOhm", "VRM f_c kHz", "PM deg",
             "ripple at die mV p-p"], rows)
    if "bode" in F:
        d.img(F["bode"], "Core regulator loop gain (magnitude and phase as separate panels).")
    sl = z[core].get("slew")
    if sl:
        d.p(f"Regulator slew check: inductor current can rise at {sl['di_dt_up_a_per_s']/1e6:.2f} A/us; the "
            f"largest load step needs {sl['t_slew_up_s']*1e9:.1f} ns of inductor slew versus a loop response time of "
            f"{sl['loop_response_time_s']*1e6:.2f} us - the step is carried by the output and PCB capacitors, "
            f"as modelled.")
    d.img(F["noise"], "Steady-state cycle-level supply noise at the die and its contributions.")

    # ------------------------------------------------------------ transient
    d.h(2, "6. Transient droop and dynamic IR")
    d.img(F["droop"], "Die-voltage response to the configured load events (cycle-average currents).")
    rows = []
    for k, r in R["droop"].items():
        rows.append([k, r.droop_v * 1e3, r.first_droop_v * 1e3, r.second_droop_v * 1e3, r.third_droop_v * 1e3,
                     r.overshoot_v * 1e3, r.settle_time_s * 1e6])
    d.table(["event", "max droop mV", "first (<100 ns) mV", "second (0.1-1 us) mV", "third (>1 us) mV",
             "overshoot mV", "settle us"], rows)
    if "resonant" in R:
        rs = R["resonant"]
        d.p(f"Resonant-workload check: a program can modulate activity at up to f_clk/2.  A load toggling at the "
            f"{rs['f_hz']/1e6:.3g} MHz anti-resonance ({rs['z_ohm']*1e3:.0f} mOhm) produces {rs['droop_v']*1e3:.1f} mV droop "
            f"(first-harmonic estimate {rs['estimate_v']*1e3:.1f} mV) versus {rs['step_droop_v']*1e3:.1f} mV for a single step.")
    d.img(F["dyn_ir"], "Dynamic IR drop on the die grid during the primary wake-up event.")

    # ------------------------------------------------------------ decap
    d.h(2, "7. Decoupling")
    d.table(["quantity", "value"], [
        ["first-droop loop inductance (die connections + min(package path, package-cap ESL))", f"{dec['l_pkg_h']*1e12:.0f} pH"],
        ["on-die capacitance (intrinsic + explicit)", f"{dec['c_die_f']*1e9:.2f} nF"],
        ["explicit decap cells", f"{dec['c_explicit_f']*1e9:.2f} nF over {dec['decap_area_um2']/1e6:.3f} mm^2"],
        ["first-droop bound C >= L (dI/dV)^2", f"{dec['c_required_first_droop_f']*1e9:.2f} nF"],
        ["per-cycle charge rule", f"{dec['c_required_cycle_charge_f']*1e9:.2f} nF (Q_cycle {dec['q_cycle_c']*1e12:.0f} pC)"],
        ["additional decap area to meet both", f"{dec['additional_decap_area_um2']/1e6:.3f} mm^2 "
                                               f"({dec['additional_decap_fraction_of_core']:.1%} of core)"],
        ["PCB-decap optimiser band", f"{dec['pcb_band_hz'][0]/1e3:.0f} kHz - {dec['pcb_band_hz'][1]/1e6:.1f} MHz, "
                                     f"max |Z|/Z_t before = {dec['pcb_max_ratio_before']:.2f}"],
        ["PCB decaps added by optimiser", ", ".join(f"{a['count']}x {a['part']}" for a in dec["pcb_added"]) or "none needed"],
    ])
    d.table(["C scale", "on-die C (nF)", "extra decap area (mm^2)", "die-pkg resonance (MHz)",
             "offset from nearest clock harmonic", "total drop (mV)", "dynamic beyond DC (mV)"],
            [[w["c_scale"], w["c_die_nf"], w["extra_decap_area_mm2"], w["f_res_mhz"], f"{w['nearest_harmonic_offset']:.0%}",
              w["total_drop_mv"], w["dynamic_beyond_dc_mv"]] for w in dec["whatif"]])
    if dec.get("l_whatif"):
        d.table(["power/ground pairs scale", "on-die C scale", "extra pins", "extra decap (mm^2)", "first-droop L (pH)",
                 "die-pkg resonance (MHz)", "dynamic beyond DC (mV)"],
                [[w["pairs_scale"], w["c_scale"], w["extra_pins"], w["extra_decap_area_mm2"], w["l_pkg_ph"],
                  w["f_res_mhz"], w["dynamic_beyond_dc_mv"]] for w in dec["l_whatif"]])
        rc2 = dec.get("recommended_combined")
        if rc2:
            d.p(f"**Lowest-cost combined option meeting the criterion:** x{rc2['pairs_scale']:.1f} power/ground "
                f"connection pairs (+{rc2['extra_pins']} package pins of {dec['pins_free']} free) with x{rc2['c_scale']:.1f} "
                f"on-die capacitance (+{rc2['extra_decap_area_mm2']:.2f} mm^2) -> {rc2['dynamic_beyond_dc_mv']:.1f} mV.")
        d.p("Package-inductance what-if: more VDD/VSS bond-wire/lead pairs (pin budget permitting) reduce the "
            "loop inductance and the anti-resonance peak; combined with moderate decap this is usually cheaper "
            "in silicon area than capacitance alone.")
    if dec.get("recommended"):
        rc = dec["recommended"]
        d.p(f"**Recommended:** scale on-die capacitance x{rc['c_scale']:.1f} (+{rc['extra_decap_area_mm2']:.2f} mm^2 of "
            f"decap cells) - smallest step with dynamic noise <= 60 % of the {dec['dynamic_allocation_v']*1e3:.0f} mV "
            f"allocation and the resonance >15 % away from clock harmonics.  Note the non-monotonic behaviour: "
            f"capacitance that moves the resonance onto a clock harmonic makes noise worse.")
    else:
        d.p("No capacitance scaling up to x6 met the criterion; damping (decap ESR / package changes) is needed.")
    d.p("What-if table: lumped clocked model of the primary wake-up event as the on-die capacitance is scaled "
        "(ESR scaled inversely).  Use it to trade decap area (and its gate leakage) against noise margin.")

    # ------------------------------------------------------------ thermal
    d.h(2, "8. Thermal coupling and cooling")
    d.img(F["thermal_map"], "Die temperature map at the maximum workload (2-D conduction, compact boundary).")
    d.img(F["cooling"], "Junction temperature for every package and cooling option at worst ambient.")
    pk = list(next(iter(th["table"].values())).keys())
    d.table(["cooling"] + pk + [f"theta_ja ({p.baseline_package})"],
            [[c] + [th["table"][c][k] for k in pk] + [th["theta_ja"][c]] for c in th["table"]])
    notes = sorted({n for v in th["network_notes"].values() for n in v})
    if notes:
        d.p("Thermal-network notes: " + "; ".join(notes))
    d.p(f"Specialist thermal results can be imported (`powerlink thermal-import`); the PowerLink map is exported "
        f"in the same CSV format to `{Path(th['export_csv']).name}`.")

    # ------------------------------------------------------------ packages
    d.h(2, "9. Package comparison")
    d.img(F["packages"], "Package sub-scores and overall weighted score (status = hard-constraint check).")
    rows = []
    for it in items:
        m = it.metrics
        rows.append([it.key, it.family, f"{m['pins_required']}/{m['pins_available']}",
                     m["core_pkg_l_h"] * 1e12, m["core_pkg_dc_drop_v"] * 1e3, m["core_first_droop_bound_v"] * 1e3,
                     m["sso_noise_v"] * 1e3, m["si_capability_gbps"], m["tj_best_passive_c"],
                     m["cost_per_unit_at_volume_usd"], m["nre_usd"], it.score,
                     "robust" if it.robust else ("nominal only" if it.feasible else "infeasible")])
    d.table(["package", "family", "pins", "L_pkg pH", "pkg DC mV", "first droop bound mV", "SSO mV",
             "SI Gb/s", "T_j passive C", "USD/unit @vol", "NRE USD", "score", "status"], rows)
    d.ul([f"`{it.key}`: " + ("; ".join(it.notes) if it.notes else "all checks pass at nominal and adverse corner")
          for it in items])

    # ------------------------------------------------------------ margins
    d.h(2, "10. Power-integrity margins")
    for r, b in budgets.items():
        d.h(3, f"{r}")
        if f"waterfall_{r}" in F:
            d.img(F[f"waterfall_{r}"], f"{r} budget waterfall (worst-case stack).")
        d.table(["component", "nominal mV", "adverse corner mV", "allocation mV", "within allocation", "source"],
                [[t["component"], t["nominal_mv"], t["worst_mv"], t["allocation_mv"], t["within_allocation"],
                  t["source"]] for t in b.table()])
        s = b.summary()
        txt = (f"Available {s['available_mv']:.1f} mV (V_nom - V_min - guardband).  Margin: nominal "
               f"{s['margin_nominal_mv']:.1f} mV, RSS {s['margin_rss_mv']:.1f} mV, worst-case {s['margin_worst_mv']:.1f} mV.")
        if b.mc:
            txt += (f"  Monte-Carlo (n={b.mc['n']}): P(fail) {b.mc['p_fail']:.2%}, 1st percentile margin "
                    f"{b.mc['margin_mv']['p01']:.1f} mV, median {b.mc['margin_mv']['p50']:.1f} mV; surrogate error at "
                    f"the worst corner {b.mc['surrogate_error_at_worst_corner']:.1%}.")
        d.p(txt)
        if b.mc and "direct" in b.mc:
            dd = b.mc["direct"]
            d.p(f"Direct Monte-Carlo with the full lumped model on the first {dd['n']} draws: P(fail) {dd['p_fail']:.2%} "
                f"(surrogate on the same draws {dd['p_fail_surrogate_same_draws']:.2%}); correlation of the dynamic "
                f"term between full model and surrogate r = {dd['dyn_ratio_corr']:.2f}.  Where they disagree, "
                f"the full-model figure governs.")
        if b.mc and "mc" in F:
            d.img(F["mc"], "Monte-Carlo margin distribution.")
            el = sorted(b.mc["elasticities"].items(), key=lambda kv: -abs(kv[1]))[:8]
            d.table(["parameter", "elasticity of dynamic droop (d ln m / d ln p)"], [[k, v] for k, v in el])

    # ------------------------------------------------------------ risks
    d.h(2, "11. Risk summary")
    d.img(F["risk"], "Risk matrix (likelihood from computed utilisation ratios; impact by engineering judgement).")
    d.table(["#", "risk", "metric", "L", "I", "score", "status", "mitigation"],
            [[k + 1, r["title"], r["metric"], r["likelihood"], r["impact"], r["score"], r["status"], r["mitigation"]]
             for k, r in enumerate(risks)])

    # ------------------------------------------------------------ on-die PDN
    d.h(2, "12. On-die PDN configuration and OpenROAD scripts")
    chk = R["pdn_check"]
    d.table(["layer", "direction", "width um", "pitch um", "PG track usage"],
            [[L["name"], L["direction"], L["width_um"], L["pitch_um"], chk.layer_usage.get(L["name"], 0.0)]
             for L in p.pdn["layers"]])
    d.p("Configuration checks: " + ("errors: " + "; ".join(chk.errors) if chk.errors else "no errors") +
        ("; warnings: " + "; ".join(chk.warnings) if chk.warnings else "; no warnings") + ".")
    d.p("Generated scripts (example only - no DRC/LVS correctness is asserted without the chosen PDK and a real "
        "implementation run): " + ", ".join(f"`{Path(v).name}`" for v in R["openroad"].values()) + ".")

    # ------------------------------------------------------------ validation
    d.h(2, "13. Validation")
    cc = R.get("crosscheck")
    if cc and cc.get("available"):
        d.p("Independent cross-check of the in-house MNA solver against ngspice on the circuits used above:")
        d.table(["check", "PowerLink", "ngspice", "abs diff", "rel diff", "tolerance", "result"],
                [[r["check"], r["powerlink"], r["ngspice"], r["abs_diff"], r["rel_diff"], r["tolerance"], r["pass"]]
                 for r in cc["rows"]])
    elif cc:
        d.p(cc.get("note", "cross-check unavailable"))
    d.p("Unit tests (pytest) cover the MNA solver against analytic RC/RLC/divider solutions, the grid solver "
        "against the analytic uniform-sheet solution and current conservation, the VRM loop against the "
        "analytic crossover, the thermal solver against 1-D and Song-Lee-Au limits, VCD/SAIF parsing and the "
        "package/margin logic.  Commercial signoff experiments are specified in docs/VALIDATION_AND_SIGNOFF.md.")

    # ------------------------------------------------------------ assumptions
    d.h(2, "14. Assumption register")
    d.p(f"{len(ctx['assumptions'])} uncertain inputs (full list in `assumptions.csv`).  Largest relative spans:")
    ar = sorted(ctx["assumptions"], key=lambda r: -(abs(r["max"] - r["min"]) / abs(r["nominal"]) if r["nominal"] else 0))[:20]
    d.table(["path", "nominal", "min", "max", "source", "note"],
            [[r["path"], r["nominal"], r["min"], r["max"], r["source"], r["note"]] for r in ar])

    # ------------------------------------------------------------ write
    md = d.markdown(out)
    (out / "REPORT.md").write_text(md)
    (out / "report.html").write_text(d.html(f"{p.name} PowerLink report"))
    _write_csv(out / "assumptions.csv", ["path", "nominal", "min", "max", "dist", "source", "note"],
               [[r["path"], r["nominal"], r["min"], r["max"], r["dist"], r["source"], r["note"]] for r in ctx["assumptions"]])
    _write_csv(out / "power_by_block.csv", ["profile", "block", "rail", "kind", "p_data_w", "p_clock_w", "p_sram_w",
                                            "p_leak_w", "p_fixed_w", "alpha", "clock_enable", "activity_source", "temp_c"],
               [[k, b.name, b.rail, b.kind, b.p_data_w, b.p_clock_w, b.p_sram_w, b.p_leak_w, b.p_fixed_w, b.alpha,
                 b.clock_enable, b.activity_source, b.temp_c] for k, pr in prof.items() for b in pr.blocks])
    _write_csv(out / "risks.csv", ["title", "metric", "likelihood", "impact", "score", "status", "mitigation"],
               [[r["title"], r["metric"], r["likelihood"], r["impact"], r["score"], r["status"], r["mitigation"]]
                for r in risks])
    np.savetxt(out / "ir_drop_static_mv.csv", ir.ir_drop[net] * 1e3, delimiter=",", fmt="%.5f")
    summary = {
        "chip": p.name, "max_profile": max_prof,
        "power_mw": {k: pr.total_w() * 1e3 for k, pr in prof.items()},
        "core_current_ma": {k: pr.rail_current(core) * 1e3 for k, pr in prof.items()},
        "static_ir_worst_mv": ir.worst_drop_v[net] * 1e3, "dynamic_ir_worst_mv": dyn.worst_dyn_drop_v[net] * 1e3,
        "budgets": {r: b.summary() for r, b in budgets.items()},
        "packages": [{"key": it.key, "score": it.score, "feasible": it.feasible, "robust": it.robust,
                      "notes": it.notes} for it in items],
        "tj_c": th["table"], "risks": [{k: r[k] for k in ("title", "status", "score")} for r in risks],
        "crosscheck_all_pass": (cc or {}).get("all_pass"),
        "verdict": verdict,
    }
    return summary


def rail_verdict(b) -> str:
    s = b.summary()
    if s["pass_worst_case"]:
        return "realistic with margin (passes the all-adverse worst-case stack)"
    pf = None
    if b.mc:
        pf = b.mc.get("direct", {}).get("p_fail", b.mc["p_fail"])
    if pf is not None:
        if pf < 1e-3:
            return "realistic statistically (passes Monte-Carlo; fails only the all-adverse stack)"
        if pf < 0.05:
            return "marginal (Monte-Carlo failure probability 0.1-5 %)"
        return "not robust as specified (Monte-Carlo failure probability > 5 %)"
    return "realistic statistically (passes RSS)" if s["pass_rss"] else "not robust as specified"


def dominant(b) -> str:
    c = max(b.components, key=lambda c: c.worst_v / c.allocation_v if c.allocation_v else 0)
    return f"{c.name} ({c.worst_v*1e3:.1f} mV corner vs {c.allocation_v*1e3:.0f} mV allocated)"


def _verdict(p, ctx) -> List[str]:
    R = ctx["results"]
    out = []
    for r, b in R["budgets"].items():
        s = b.summary()
        mc = ""
        if b.mc:
            mc = f", MC P(fail) {b.mc['p_fail']:.2%} (surrogate, n={b.mc['n']})"
            if "direct" in b.mc:
                mc += f" / {b.mc['direct']['p_fail']:.2%} (full model, n={b.mc['direct']['n']})"
        out.append(f"Rail `{r}` ({b.v_nom:.2f} V, min {b.v_min:.2f} V): **{rail_verdict(b)}** - margin "
                   f"{s['margin_nominal_mv']:.1f} mV nominal, {s['margin_rss_mv']:.1f} mV RSS, "
                   f"{s['margin_worst_mv']:.1f} mV worst-case{mc}; dominant term: {dominant(b)}.")
    dec = R["decap"]
    rc2 = dec.get("recommended_combined")
    if rc2:
        out.append(f"Cheapest mitigation found: x{rc2['pairs_scale']:.1f} core power/ground connection pairs "
                   f"(+{rc2['extra_pins']} pins, {dec['pins_free']} free) and x{rc2['c_scale']:.1f} on-die decoupling "
                   f"(+{rc2['extra_decap_area_mm2']:.2f} mm^2) bring the dynamic term to {rc2['dynamic_beyond_dc_mv']:.1f} mV "
                   f"(<= 60 % of allocation) in the lumped clocked model; confirm with dynamic-IR signoff.")
    if dec.get("recommended"):
        rc = dec["recommended"]
        out.append(f"Capacitance-only alternative from the decap search: on-die capacitance x{rc['c_scale']:.1f} "
                   f"({rc['c_die_nf']:.1f} nF, +{rc['extra_decap_area_mm2']:.2f} mm^2 decap cells) gives "
                   f"{rc['dynamic_beyond_dc_mv']:.1f} mV dynamic noise (<= 60 % of allocation) with the die-package "
                   f"resonance at {rc['f_res_mhz']:.0f} MHz, away from clock harmonics.")
    base = next(it for it in R["packages"] if it.key == p.baseline_package)
    out.append(f"Package `{base.key}`: " + ("adequate and robust" if base.robust else
                                            "adequate at nominal; corner issues: " + "; ".join(base.notes)
                                            if base.feasible else "inadequate: " + "; ".join(base.notes)) + ".")
    dec = R["decap"]
    out.append(f"PCB: plane + decap network {'meets' if dec['pcb_max_ratio_before'] <= 1 else 'does not meet'} the "
               f"flat target impedance in the PCB-effective band "
               f"(max |Z|/Z_t {dec['pcb_max_ratio_before']:.2f})"
               + ("" if dec['pcb_max_ratio_before'] <= 1 else
                  "; optimiser proposes " + (", ".join(f"{a['count']}x {a['part']}" for a in dec["pcb_added"]) or "no parts"))
               + ".  Above that band only on-die capacitance and package inductance matter.")
    out.append("These conclusions are conditional on the assumed activity, generic technology data and "
               "family-level package parasitics recorded in the assumption register; they identify where "
               "signoff effort is needed, they do not replace it.")
    return out
