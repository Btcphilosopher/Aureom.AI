"""Explicit representation of modelling uncertainty.

Every physical input in a PowerLink configuration may be written either as a
plain number or as a mapping::

    sheet_res_ohm_sq: {nom: 0.022, min: 0.018, max: 0.028,
                       dist: uniform, source: assumption,
                       note: "generic 65 nm thick top metal"}

The value is carried through the code as an :class:`UncertainValue`.  Models
call :func:`nom` to obtain the nominal value, :func:`corner` to obtain the
adverse/benign bound and :meth:`UncertainValue.sample` for Monte-Carlo
analysis.  The ``source`` tag is propagated into reports so that it is always
visible whether a number is a *measurement*, a *datasheet* value, a
*literature* value or an engineering *assumption*.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional

import numpy as np

VALID_SOURCES = ("assumption", "literature", "datasheet", "measured", "derived", "spec",
                 "pdk", "simulation")
VALID_DISTS = ("uniform", "normal", "triangular", "lognormal", "fixed")


@dataclass(frozen=True)
class UncertainValue:
    """A scalar with a nominal value, bounds, a distribution and a provenance tag."""

    nom: float
    min: float
    max: float
    dist: str = "uniform"
    source: str = "assumption"
    note: str = ""
    unit: str = ""

    def __post_init__(self) -> None:
        if not (self.min <= self.nom <= self.max):
            raise ValueError(f"UncertainValue requires min <= nom <= max, got "
                             f"{self.min} <= {self.nom} <= {self.max} ({self.note})")
        if self.dist not in VALID_DISTS:
            raise ValueError(f"unknown distribution '{self.dist}'")
        if self.source not in VALID_SOURCES:
            raise ValueError(f"unknown source tag '{self.source}' (valid: {VALID_SOURCES})")

    # ------------------------------------------------------------------ helpers
    @property
    def is_fixed(self) -> bool:
        return self.min == self.max

    @property
    def rel_span(self) -> float:
        """Half-span relative to nominal, e.g. 0.1 for +/-10 %."""
        if self.nom == 0:
            return 0.0
        return 0.5 * (self.max - self.min) / abs(self.nom)

    def sample(self, rng: np.random.Generator, n: int) -> np.ndarray:
        if self.is_fixed or self.dist == "fixed":
            return np.full(n, self.nom, dtype=float)
        if self.dist == "uniform":
            return rng.uniform(self.min, self.max, n)
        if self.dist == "triangular":
            return rng.triangular(self.min, self.nom, self.max, n)
        if self.dist == "normal":
            # bounds interpreted as +/-3 sigma, truncated to the bounds
            sigma = (self.max - self.min) / 6.0
            x = rng.normal(self.nom, sigma, n)
            return np.clip(x, self.min, self.max)
        if self.dist == "lognormal":
            if self.min <= 0:
                raise ValueError("lognormal requires positive bounds")
            mu = np.log(self.nom)
            sigma = (np.log(self.max) - np.log(self.min)) / 6.0
            return np.clip(rng.lognormal(mu, sigma, n), self.min, self.max)
        raise AssertionError(self.dist)

    def scaled(self, k: float) -> "UncertainValue":
        lo, hi = sorted((self.min * k, self.max * k))
        return UncertainValue(self.nom * k, lo, hi, self.dist, self.source, self.note, self.unit)

    def describe(self) -> str:
        if self.is_fixed:
            return f"{self.nom:g}{self.unit} [{self.source}]"
        return (f"{self.nom:g}{self.unit} ({self.min:g}..{self.max:g}, {self.dist}) "
                f"[{self.source}]")

    def __float__(self) -> float:  # allows float(uv)
        return float(self.nom)


def parse_value(v: Any, default_source: str = "assumption", unit: str = "") -> UncertainValue:
    """Convert a config entry (number or mapping) into an :class:`UncertainValue`."""
    if isinstance(v, UncertainValue):
        return v
    if isinstance(v, str):
        try:
            v = float(v)
        except ValueError:
            raise TypeError(f"cannot interpret {v!r} as a numeric value") from None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return UncertainValue(float(v), float(v), float(v), "fixed", default_source, "", unit)
    if isinstance(v, Mapping):
        if "nom" not in v:
            raise ValueError(f"uncertain value mapping requires 'nom': {v}")
        nomv = float(v["nom"])
        if "tol" in v:  # relative tolerance shorthand
            tol = float(v["tol"])
            lo, hi = sorted((nomv * (1 - tol), nomv * (1 + tol)))
        else:
            lo = float(v.get("min", nomv))
            hi = float(v.get("max", nomv))
        dist = v.get("dist", "uniform" if lo != hi else "fixed")
        return UncertainValue(nomv, lo, hi, dist, v.get("source", default_source),
                              str(v.get("note", "")), v.get("unit", unit))
    raise TypeError(f"cannot interpret {v!r} as a numeric value")


def nom(v: Any) -> float:
    """Nominal value of a number / mapping / UncertainValue."""
    if isinstance(v, UncertainValue):
        return v.nom
    if isinstance(v, Mapping):
        return float(v["nom"])
    return float(v)


def corner(v: Any, adverse_high: bool) -> float:
    """Return the bound that is adverse for the metric.

    ``adverse_high=True`` returns the maximum (e.g. resistance for IR drop),
    ``False`` returns the minimum (e.g. capacitance for droop).
    """
    u = parse_value(v)
    return u.max if adverse_high else u.min


def source_of(v: Any) -> str:
    if isinstance(v, UncertainValue):
        return v.source
    if isinstance(v, Mapping):
        return str(v.get("source", "assumption"))
    return "assumption"


# --------------------------------------------------------------------------
# Parameter registry used by the Monte-Carlo / sensitivity machinery
# --------------------------------------------------------------------------
@dataclass
class Parameter:
    """A named uncertain model parameter and the direction that hurts margins."""

    name: str
    value: UncertainValue
    adverse_high: bool = True
    group: str = "general"


@dataclass
class ParameterSet:
    params: Dict[str, Parameter] = field(default_factory=dict)

    def add(self, name: str, value: Any, adverse_high: bool = True, group: str = "general") -> None:
        self.params[name] = Parameter(name, parse_value(value), adverse_high, group)

    def nominal(self) -> Dict[str, float]:
        return {k: p.value.nom for k, p in self.params.items()}

    def worst_case(self) -> Dict[str, float]:
        return {k: (p.value.max if p.adverse_high else p.value.min) for k, p in self.params.items()}

    def best_case(self) -> Dict[str, float]:
        return {k: (p.value.min if p.adverse_high else p.value.max) for k, p in self.params.items()}

    def sample(self, n: int, seed: int = 1) -> Dict[str, np.ndarray]:
        rng = np.random.default_rng(seed)
        return {k: p.value.sample(rng, n) for k, p in self.params.items()}

    def uncertain_names(self) -> List[str]:
        return [k for k, p in self.params.items() if not p.value.is_fixed]

    def table(self) -> List[Dict[str, Any]]:
        rows = []
        for k, p in self.params.items():
            rows.append({"parameter": k, "nominal": p.value.nom, "min": p.value.min,
                         "max": p.value.max, "dist": p.value.dist, "source": p.value.source,
                         "adverse": "high" if p.adverse_high else "low",
                         "note": p.value.note})
        return rows


# --------------------------------------------------------------------------
# Elasticity (log-log sensitivity) surrogate for fast Monte-Carlo
# --------------------------------------------------------------------------
@dataclass
class PowerLawSurrogate:
    """metric ~= m0 * prod_i (p_i / p_i0) ** e_i.

    Elasticities ``e_i`` are obtained from central finite differences of the
    full model in log space.  Power laws are exact for the dominant PDN
    relations (IR = I.R ; first droop ~ dI.sqrt(L/C)) and are a documented
    approximation otherwise.  The surrogate is always validated against the
    full model at the worst-case corner (see :func:`build_surrogate`).
    """

    m0: float
    p0: Dict[str, float]
    elasticity: Dict[str, float]

    def __call__(self, values: Mapping[str, np.ndarray | float]) -> np.ndarray:
        out = np.asarray(self.m0, dtype=float)
        for k, e in self.elasticity.items():
            if e == 0.0:
                continue
            out = out * (np.asarray(values[k], dtype=float) / self.p0[k]) ** e
        return out


def build_surrogate(model: Callable[[Dict[str, float]], float], pset: ParameterSet,
                    rel_step: float = 0.05) -> PowerLawSurrogate:
    p0 = pset.nominal()
    m0 = float(model(dict(p0)))
    el: Dict[str, float] = {}
    for name in pset.uncertain_names():
        x0 = p0[name]
        if x0 == 0 or m0 == 0:
            el[name] = 0.0
            continue
        up = dict(p0)
        dn = dict(p0)
        up[name] = x0 * (1 + rel_step)
        dn[name] = x0 * (1 - rel_step)
        mu, md = float(model(up)), float(model(dn))
        if mu <= 0 or md <= 0:
            el[name] = 0.0
            continue
        el[name] = (np.log(mu) - np.log(md)) / (np.log(1 + rel_step) - np.log(1 - rel_step))
    return PowerLawSurrogate(m0, p0, el)


def summarize_samples(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    return {"mean": float(np.mean(x)), "std": float(np.std(x)),
            "p01": float(np.percentile(x, 1)), "p05": float(np.percentile(x, 5)),
            "p50": float(np.percentile(x, 50)), "p95": float(np.percentile(x, 95)),
            "p99": float(np.percentile(x, 99)), "min": float(np.min(x)), "max": float(np.max(x))}


def provenance_counts(values: Iterable[Any]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for v in values:
        s = source_of(v)
        counts[s] = counts.get(s, 0) + 1
    return counts
