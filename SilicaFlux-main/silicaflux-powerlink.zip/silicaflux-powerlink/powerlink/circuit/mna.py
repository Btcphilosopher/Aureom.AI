"""Sparse Modified Nodal Analysis (MNA) circuit solver.

Supports R, C, L, independent V and I sources (DC, AC and time-varying),
grouped current sources (many sinks sharing one waveform - used for on-die
load maps), voltage-controlled current sources (G) and voltage-controlled
voltage sources (E).  Analyses:

* ``dc()``   - operating point (capacitors open, inductors short, gmin to ground)
* ``ac()``   - small-signal frequency response  (G + j w C) x = b_ac
* ``tran()`` - fixed-step transient (trapezoidal on differential rows with
  exact enforcement of algebraic rows, or backward Euler), piecewise-constant
  step size, LU factorisation reused within each step segment.

Formulation: G x + C dx/dt = b(t), x = [node voltages (ground removed),
branch currents of L, V and E elements].  Sign convention follows SPICE:
an independent current source ``I n1 n2`` drives current from n1 through the
source to n2 (it *draws* current out of n1); a VCCS ``G n+ n- nc+ nc-``
drives gm*V(nc+,nc-) from n+ through the source to n-.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple, Union

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

NodeRef = Union[int, str]
Wave = Callable[[float], float]

GMIN_DEFAULT = 1e-12


class PWL:
    """Piece-wise linear waveform (SPICE PWL semantics, held flat outside)."""

    def __init__(self, t: Sequence[float], v: Sequence[float]):
        self.t = np.asarray(t, dtype=float)
        self.v = np.asarray(v, dtype=float)
        if self.t.ndim != 1 or self.t.shape != self.v.shape or np.any(np.diff(self.t) < 0):
            raise ValueError("PWL requires monotonically non-decreasing 1-D time points")

    def __call__(self, t: float) -> float:
        return float(np.interp(t, self.t, self.v))

    def points(self) -> Tuple[np.ndarray, np.ndarray]:
        return self.t, self.v


@dataclass
class Solution:
    circuit: "Circuit"
    x: np.ndarray

    def v(self, node: NodeRef) -> float:
        idx = self.circuit.node_index(node)
        return 0.0 if idx == 0 else float(np.real(self.x[idx - 1]))

    def i(self, branch: Union[str, int]) -> float:
        row = self.circuit.branch_row(branch)
        return float(np.real(self.x[row]))

    def node_voltages(self, nodes: np.ndarray) -> np.ndarray:
        nodes = np.asarray(nodes, dtype=int)
        out = np.zeros(nodes.shape, dtype=self.x.dtype)
        mask = nodes > 0
        out[mask] = self.x[nodes[mask] - 1]
        return out


@dataclass
class TranResult:
    t: np.ndarray
    probes: Dict[str, np.ndarray]
    final: Optional[np.ndarray] = None

    def __getitem__(self, key: str) -> np.ndarray:
        return self.probes[key]


@dataclass
class _Branch:
    kind: str
    name: str


class Circuit:
    def __init__(self, title: str = "powerlink circuit", gmin: float = GMIN_DEFAULT):
        self.title = title
        self.gmin = gmin
        self._names: Dict[str, int] = {"0": 0, "gnd": 0}
        self._rev_names: Dict[int, str] = {0: "0"}
        self.n_nodes = 1
        # passive element arrays (lists of numpy chunks)
        self._R: List[Tuple[np.ndarray, np.ndarray, np.ndarray]] = []
        self._C: List[Tuple[np.ndarray, np.ndarray, np.ndarray]] = []
        self._L: List[Tuple[int, int, float, int]] = []      # n1, n2, L, branch
        self._Lbulk: List[Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = []
        self._V: List[Dict[str, Any]] = []
        self._I: List[Dict[str, Any]] = []
        self._Igroups: List[Dict[str, Any]] = []
        self._G: List[Tuple[int, int, int, int, float]] = []
        self._E: List[Tuple[int, int, int, int, float, int]] = []
        self.branches: List[_Branch] = []
        self._branch_by_name: Dict[str, int] = {}
        self._assembled: Optional[Dict[str, Any]] = None

    # ------------------------------------------------------------------ nodes
    def node(self, name: NodeRef) -> int:
        if isinstance(name, (int, np.integer)):
            if not 0 <= int(name) < self.n_nodes:
                raise KeyError(f"node index {name} does not exist")
            return int(name)
        if name in self._names:
            return self._names[name]
        idx = self.n_nodes
        self.n_nodes += 1
        self._names[name] = idx
        self._rev_names[idx] = name
        self._assembled = None
        return idx

    def node_index(self, name: NodeRef) -> int:
        if isinstance(name, (int, np.integer)):
            return int(name)
        if name not in self._names:
            raise KeyError(f"unknown node '{name}'")
        return self._names[name]

    def new_nodes(self, count: int) -> np.ndarray:
        start = self.n_nodes
        self.n_nodes += int(count)
        self._assembled = None
        return np.arange(start, start + count, dtype=int)

    def node_name(self, idx: int) -> str:
        return self._rev_names.get(int(idx), f"n{int(idx)}")

    def has_node(self, name: str) -> bool:
        return name in self._names

    # --------------------------------------------------------------- branches
    def _new_branch(self, kind: str, name: Optional[str]) -> int:
        b = len(self.branches)
        name = name or f"{kind}{b}"
        if name in self._branch_by_name:
            raise ValueError(f"duplicate branch name '{name}'")
        self.branches.append(_Branch(kind, name))
        self._branch_by_name[name] = b
        return b

    def branch_row(self, branch: Union[str, int]) -> int:
        b = self._branch_by_name[branch] if isinstance(branch, str) else int(branch)
        return (self.n_nodes - 1) + b

    @property
    def size(self) -> int:
        return (self.n_nodes - 1) + len(self.branches)

    # --------------------------------------------------------------- elements
    def add_R(self, n1: NodeRef, n2: NodeRef, r: float) -> None:
        if not r > 0:
            raise ValueError(f"resistance must be positive, got {r}")
        self._R.append((np.array([self.node(n1)]), np.array([self.node(n2)]), np.array([float(r)])))
        self._assembled = None

    def add_R_bulk(self, n1: np.ndarray, n2: np.ndarray, r: np.ndarray) -> None:
        r = np.broadcast_to(np.asarray(r, dtype=float), np.shape(n1)).copy()
        if np.any(r <= 0):
            raise ValueError("all bulk resistances must be positive")
        self._R.append((np.asarray(n1, dtype=int), np.asarray(n2, dtype=int), r))
        self._assembled = None

    def add_C(self, n1: NodeRef, n2: NodeRef, c: float) -> None:
        if not c > 0:
            raise ValueError(f"capacitance must be positive, got {c}")
        self._C.append((np.array([self.node(n1)]), np.array([self.node(n2)]), np.array([float(c)])))
        self._assembled = None

    def add_C_bulk(self, n1: np.ndarray, n2: np.ndarray, c: np.ndarray) -> None:
        c = np.broadcast_to(np.asarray(c, dtype=float), np.shape(n1)).copy()
        keep = c > 0
        self._C.append((np.asarray(n1, dtype=int)[keep], np.asarray(n2, dtype=int)[keep], c[keep]))
        self._assembled = None

    def add_L(self, n1: NodeRef, n2: NodeRef, l: float, name: Optional[str] = None) -> int:
        if not l > 0:
            raise ValueError(f"inductance must be positive, got {l}")
        b = self._new_branch("L", name)
        self._L.append((self.node(n1), self.node(n2), float(l), b))
        self._assembled = None
        return b

    def add_L_bulk(self, n1: np.ndarray, n2: np.ndarray, l: np.ndarray, prefix: str = "Lb") -> np.ndarray:
        n1 = np.asarray(n1, dtype=int)
        n2 = np.asarray(n2, dtype=int)
        l = np.broadcast_to(np.asarray(l, dtype=float), n1.shape).copy()
        if np.any(l <= 0):
            raise ValueError("all bulk inductances must be positive")
        start = len(self.branches)
        for k in range(len(n1)):
            self._new_branch("L", f"{prefix}{start + k}")
        br = np.arange(start, start + len(n1))
        self._Lbulk.append((n1, n2, l, br))
        self._assembled = None
        return br

    def add_V(self, n1: NodeRef, n2: NodeRef, dc: float = 0.0, wave: Optional[Wave] = None,
              ac: float = 0.0, name: Optional[str] = None) -> int:
        b = self._new_branch("V", name)
        self._V.append({"n1": self.node(n1), "n2": self.node(n2), "dc": float(dc),
                        "wave": wave, "ac": complex(ac), "branch": b})
        self._assembled = None
        return b

    def add_I(self, n1: NodeRef, n2: NodeRef, dc: float = 0.0, wave: Optional[Wave] = None,
              ac: float = 0.0, name: Optional[str] = None) -> None:
        self._I.append({"n1": self.node(n1), "n2": self.node(n2), "dc": float(dc),
                        "wave": wave, "ac": complex(ac), "name": name or f"I{len(self._I)}"})
        self._assembled = None

    def add_I_group(self, n1: np.ndarray, n2: np.ndarray, amplitude: np.ndarray,
                    wave: Optional[Wave] = None, name: str = "Igrp") -> None:
        """Many current sources i_k(t) = amplitude_k * wave(t) (wave defaults to 1)."""
        self._Igroups.append({"n1": np.asarray(n1, dtype=int), "n2": np.asarray(n2, dtype=int),
                              "amp": np.asarray(amplitude, dtype=float), "wave": wave, "name": name})
        self._assembled = None

    def add_G(self, np_: NodeRef, nn: NodeRef, cp: NodeRef, cn: NodeRef, gm: float) -> None:
        self._G.append((self.node(np_), self.node(nn), self.node(cp), self.node(cn), float(gm)))
        self._assembled = None

    def add_E(self, np_: NodeRef, nn: NodeRef, cp: NodeRef, cn: NodeRef, gain: float,
              name: Optional[str] = None) -> int:
        b = self._new_branch("E", name)
        self._E.append((self.node(np_), self.node(nn), self.node(cp), self.node(cn), float(gain), b))
        self._assembled = None
        return b

    # --------------------------------------------------------------- assembly
    def _assemble(self) -> Dict[str, Any]:
        if self._assembled is not None:
            return self._assembled
        n = self.size
        nn = self.n_nodes - 1
        gi: List[np.ndarray] = []
        gj: List[np.ndarray] = []
        gv: List[np.ndarray] = []
        ci: List[np.ndarray] = []
        cj: List[np.ndarray] = []
        cv: List[np.ndarray] = []

        def stamp_two_terminal(rows_i, rows_j, vals, ti, tj, tv):
            a = rows_i - 1
            b = rows_j - 1
            ma = rows_i > 0
            mb = rows_j > 0
            mab = ma & mb
            ti += [a[ma], b[mb], a[mab], b[mab]]
            tj += [a[ma], b[mb], b[mab], a[mab]]
            tv += [vals[ma], vals[mb], -vals[mab], -vals[mab]]

        for n1, n2, r in self._R:
            stamp_two_terminal(n1, n2, 1.0 / r, gi, gj, gv)
        for n1, n2, c in self._C:
            stamp_two_terminal(n1, n2, c, ci, cj, cv)
        # gmin on every node
        gi.append(np.arange(nn)); gj.append(np.arange(nn)); gv.append(np.full(nn, self.gmin))

        def stamp_branch(n1, n2, row):
            # KCL contributions of branch current and branch voltage equation
            r_i, r_j, r_v = [], [], []
            if n1 > 0:
                r_i += [n1 - 1, row]; r_j += [row, n1 - 1]; r_v += [1.0, 1.0]
            if n2 > 0:
                r_i += [n2 - 1, row]; r_j += [row, n2 - 1]; r_v += [-1.0, -1.0]
            return r_i, r_j, r_v

        for n1, n2, l, b in self._L:
            row = nn + b
            r_i, r_j, r_v = stamp_branch(n1, n2, row)
            gi.append(np.array(r_i, dtype=int)); gj.append(np.array(r_j, dtype=int)); gv.append(np.array(r_v))
            ci.append(np.array([row])); cj.append(np.array([row])); cv.append(np.array([-l]))
        for n1, n2, l, br in self._Lbulk:
            rows = nn + br
            m1 = n1 > 0
            m2 = n2 > 0
            gi += [n1[m1] - 1, rows[m1], n2[m2] - 1, rows[m2]]
            gj += [rows[m1], n1[m1] - 1, rows[m2], n2[m2] - 1]
            gv += [np.ones(m1.sum()), np.ones(m1.sum()), -np.ones(m2.sum()), -np.ones(m2.sum())]
            ci.append(rows); cj.append(rows); cv.append(-l)
        for v in self._V:
            row = nn + v["branch"]
            r_i, r_j, r_v = stamp_branch(v["n1"], v["n2"], row)
            gi.append(np.array(r_i, dtype=int)); gj.append(np.array(r_j, dtype=int)); gv.append(np.array(r_v))
        for np_, nneg, cp, cn, gm in self._G:
            r_i, r_j, r_v = [], [], []
            for nout, so in ((np_, 1.0), (nneg, -1.0)):
                if nout == 0:
                    continue
                for nc, sc in ((cp, 1.0), (cn, -1.0)):
                    if nc == 0:
                        continue
                    r_i.append(nout - 1); r_j.append(nc - 1); r_v.append(so * sc * gm)
            if r_i:
                gi.append(np.array(r_i)); gj.append(np.array(r_j)); gv.append(np.array(r_v))
        for np_, nneg, cp, cn, gain, b in self._E:
            row = nn + b
            r_i, r_j, r_v = stamp_branch(np_, nneg, row)
            if cp > 0:
                r_i.append(row); r_j.append(cp - 1); r_v.append(-gain)
            if cn > 0:
                r_i.append(row); r_j.append(cn - 1); r_v.append(gain)
            gi.append(np.array(r_i, dtype=int)); gj.append(np.array(r_j, dtype=int)); gv.append(np.array(r_v))

        G = sp.coo_matrix((np.concatenate(gv), (np.concatenate(gi), np.concatenate(gj))),
                          shape=(n, n)).tocsc()
        if ci:
            C = sp.coo_matrix((np.concatenate(cv), (np.concatenate(ci), np.concatenate(cj))),
                              shape=(n, n)).tocsc()
        else:
            C = sp.csc_matrix((n, n))

        # source vectors -----------------------------------------------------
        b_const = np.zeros(n)
        b_ac = np.zeros(n, dtype=complex)
        varying: List[Tuple[np.ndarray, np.ndarray, Wave]] = []
        for v in self._V:
            row = nn + v["branch"]
            b_ac[row] += v["ac"]
            if v["wave"] is None:
                b_const[row] += v["dc"]
            else:
                varying.append((np.array([row]), np.array([1.0]), v["wave"]))
        for s in self._I:
            rows, coefs = [], []
            if s["n1"] > 0:
                rows.append(s["n1"] - 1); coefs.append(-1.0)
            if s["n2"] > 0:
                rows.append(s["n2"] - 1); coefs.append(1.0)
            rows_a, coefs_a = np.array(rows, dtype=int), np.array(coefs)
            np.add.at(b_ac, rows_a, coefs_a * s["ac"])
            if s["wave"] is None:
                np.add.at(b_const, rows_a, coefs_a * s["dc"])
            else:
                varying.append((rows_a, coefs_a, s["wave"]))
        for g in self._Igroups:
            vec = np.zeros(n)
            m1 = g["n1"] > 0
            m2 = g["n2"] > 0
            np.add.at(vec, g["n1"][m1] - 1, -g["amp"][m1])
            np.add.at(vec, g["n2"][m2] - 1, g["amp"][m2])
            nz = np.nonzero(vec)[0]
            if g["wave"] is None:
                b_const += vec
            else:
                varying.append((nz, vec[nz], g["wave"]))
        diff_rows = np.zeros(n, dtype=bool)
        Cc = C.tocsr()
        diff_rows[np.unique(Cc.nonzero()[0])] = True
        self._assembled = {"G": G, "C": C, "b_const": b_const, "b_ac": b_ac,
                           "varying": varying, "diff_rows": diff_rows}
        return self._assembled

    def b_at(self, t: float) -> np.ndarray:
        a = self._assemble()
        b = a["b_const"].copy()
        for rows, coefs, wave in a["varying"]:
            b[rows] += coefs * wave(t)
        return b

    # ---------------------------------------------------------------- analyses
    def dc(self, t: float = 0.0) -> Solution:
        a = self._assemble()
        G = a["G"]
        x = spla.spsolve(G.tocsc(), self.b_at(t))
        if not np.all(np.isfinite(x)):
            raise np.linalg.LinAlgError("DC solution is not finite (floating subcircuit?)")
        return Solution(self, np.atleast_1d(x))

    def ac(self, freqs: Iterable[float], probes: Sequence[NodeRef]) -> Dict[str, np.ndarray]:
        a = self._assemble()
        G, C, b = a["G"], a["C"], a["b_ac"]
        freqs = np.asarray(list(freqs), dtype=float)
        out = {str(p): np.zeros(len(freqs), dtype=complex) for p in probes}
        idx = {str(p): self._probe_row(p) for p in probes}
        for k, f in enumerate(freqs):
            A = (G + 1j * 2 * np.pi * f * C).tocsc()
            x = spla.splu(A).solve(b)
            for p, row in idx.items():
                out[p][k] = 0.0 if row is None else x[row]
        out["freq"] = freqs
        return out

    def _probe_row(self, p: NodeRef) -> Optional[int]:
        if isinstance(p, str) and p.startswith("I(") and p.endswith(")"):
            return self.branch_row(p[2:-1])
        idx = self.node_index(p)
        return None if idx == 0 else idx - 1

    def tran(self, segments: Sequence[Tuple[float, float]], probes: Sequence[NodeRef] = (),
             method: str = "trap", callback: Optional[Callable[[float, np.ndarray], None]] = None,
             x0: Optional[np.ndarray] = None, decimate: int = 1) -> TranResult:
        """Fixed-step transient.

        ``segments`` is a list of ``(t_end, dt)``; the step size is constant
        within a segment and the system matrix is refactorised at each
        segment boundary.  ``probes`` are node names/indices or ``"I(branch)"``.
        ``callback(t, x)`` is called after every accepted step (used e.g. to
        track per-node minimum voltage on large grids without storing the
        full history).
        """
        if method not in ("trap", "be"):
            raise ValueError("method must be 'trap' or 'be'")
        a = self._assemble()
        G, C = a["G"], a["C"]
        diff = a["diff_rows"]
        alg = ~diff
        x = self.dc(0.0).x if x0 is None else np.array(x0, dtype=float)
        rows = {str(p): self._probe_row(p) for p in probes}
        t_list = [0.0]
        rec = {p: [0.0 if r is None else float(x[r])] for p, r in rows.items()}
        t = 0.0
        b_prev = self.b_at(0.0)
        Gd = sp.diags(diff.astype(float))
        Ga = sp.diags(alg.astype(float))
        step_count = 0
        for t_end, dt in segments:
            if t_end <= t + 1e-18:
                continue
            nsteps = int(np.ceil((t_end - t) / dt - 1e-9))
            h = (t_end - t) / nsteps
            if method == "be":
                A = (C / h + G).tocsc()
            else:
                # differential rows: (C/h + G/2) x+ = (C/h - G/2) x + (b+ + b)/2
                # algebraic rows:    G x+ = b+
                A = (Gd @ (C / h + 0.5 * G) + Ga @ G).tocsc()
                Bm = (Gd @ (C / h - 0.5 * G)).tocsr()
            lu = spla.splu(A)
            Ch = (C / h).tocsr()
            for _ in range(nsteps):
                t_new = t + h
                b_new = self.b_at(t_new)
                if method == "be":
                    rhs = Ch @ x + b_new
                else:
                    rhs = Bm @ x + diff * 0.5 * (b_new + b_prev) + alg * b_new
                x = lu.solve(rhs)
                t = t_new
                b_prev = b_new
                step_count += 1
                if callback is not None:
                    callback(t, x)
                if step_count % decimate == 0:
                    t_list.append(t)
                    for p, r in rows.items():
                        rec[p].append(0.0 if r is None else float(x[r]))
        return TranResult(np.array(t_list), {p: np.array(v) for p, v in rec.items()}, final=x)

    # -------------------------------------------------------------- inspection
    def element_counts(self) -> Dict[str, int]:
        return {"nodes": self.n_nodes - 1,
                "R": int(sum(len(r[2]) for r in self._R)),
                "C": int(sum(len(c[2]) for c in self._C)),
                "L": len(self._L) + int(sum(len(l[2]) for l in self._Lbulk)),
                "V": len(self._V), "I": len(self._I) + int(sum(len(g["amp"]) for g in self._Igroups)),
                "G": len(self._G), "E": len(self._E), "unknowns": self.size}

    # exported for the SPICE writer ---------------------------------------
    def iter_R(self):
        for n1, n2, r in self._R:
            for a, b, v in zip(n1, n2, r):
                yield int(a), int(b), float(v)

    def iter_C(self):
        for n1, n2, c in self._C:
            for a, b, v in zip(n1, n2, c):
                yield int(a), int(b), float(v)

    def iter_L(self):
        for n1, n2, l, b in self._L:
            yield n1, n2, l, self.branches[b].name
        for n1, n2, l, br in self._Lbulk:
            for a, b2, v, k in zip(n1, n2, l, br):
                yield int(a), int(b2), float(v), self.branches[int(k)].name

    def iter_V(self):
        for v in self._V:
            yield v, self.branches[v["branch"]].name

    def iter_I(self):
        for s in self._I:
            yield s
        for g in self._Igroups:
            for k, (a, b, amp) in enumerate(zip(g["n1"], g["n2"], g["amp"])):
                yield {"n1": int(a), "n2": int(b), "dc": float(amp), "scale_wave": g["wave"],
                       "wave": None, "ac": 0.0, "name": f"{g['name']}_{k}"}

    def iter_G(self):
        return iter(self._G)

    def iter_E(self):
        for np_, nn, cp, cn, gain, b in self._E:
            yield np_, nn, cp, cn, gain, self.branches[b].name
