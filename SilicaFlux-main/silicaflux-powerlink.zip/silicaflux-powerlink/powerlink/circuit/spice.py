"""SPICE netlist export and ngspice batch runner for independent cross-checks.

The same :class:`~powerlink.circuit.mna.Circuit` object that PowerLink solves
internally is written out as a plain SPICE deck, simulated with ngspice in
batch mode and the ASCII rawfile is parsed back.  This gives an independent
check of the in-house MNA engine against an established circuit simulator.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .mna import PWL, Circuit


def ngspice_available() -> bool:
    return shutil.which("ngspice") is not None


def _sanitize(name: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_]", "_", name)
    return s if s else "n"


def spice_node(c: Circuit, idx: int) -> str:
    """Unique SPICE node name: named nodes -> 'N_<name>', anonymous nodes -> 'U<index>'."""
    if idx == 0:
        return "0"
    if idx in c._rev_names:
        return "N_" + _sanitize(c._rev_names[idx])
    return f"U{int(idx)}"


def _pwl_string(t: np.ndarray, v: np.ndarray) -> str:
    pts = " ".join(f"{ti:.6e} {vi:.9e}" for ti, vi in zip(t, v))
    return f"PWL({pts})"


def _wave_points(wave, t_sample: Optional[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
    if isinstance(wave, PWL):
        return wave.points()
    if hasattr(wave, "points"):
        return wave.points()
    if t_sample is None:
        raise ValueError("time-varying source without PWL points needs t_sample for export")
    return t_sample, np.array([wave(t) for t in t_sample])


def write_netlist(c: Circuit, path: Path, analysis: str, t_sample: Optional[np.ndarray] = None,
                  options: str = ".options gmin=1e-12 reltol=1e-6 abstol=1e-6 vntol=1e-9 "
                                 "method=trap itl4=100") -> Path:
    # abstol is a *current* tolerance: 1 uA suits amp-level PDN currents (1 pA makes the
    # local-truncation-error control unsatisfiable and ngspice aborts on the VRM loop)
    """Write ``c`` as a SPICE deck.  ``analysis`` is the analysis card(s), e.g. '.op'."""
    lines: List[str] = [f"* {c.title} - exported by SilicaFlux PowerLink"]
    k = 0
    for a, b, r in c.iter_R():
        lines.append(f"R{k} {spice_node(c, a)} {spice_node(c, b)} {r:.12e}")
        k += 1
    k = 0
    for a, b, cap in c.iter_C():
        lines.append(f"C{k} {spice_node(c, a)} {spice_node(c, b)} {cap:.12e}")
        k += 1
    for a, b, l, name in c.iter_L():
        lines.append(f"L_{_sanitize(name)} {spice_node(c, a)} {spice_node(c, b)} {l:.12e}")
    for v, name in c.iter_V():
        card = f"V_{_sanitize(name)} {spice_node(c, v['n1'])} {spice_node(c, v['n2'])}"
        if v["wave"] is not None:
            t, vals = _wave_points(v["wave"], t_sample)
            card += f" DC {vals[0]:.9e} {_pwl_string(t, vals)}"
        else:
            card += f" DC {v['dc']:.12e}"
        if v["ac"] != 0:
            card += f" AC {abs(v['ac']):.6e}"
        lines.append(card)
    for s in c.iter_I():
        card = f"I_{_sanitize(s['name'])} {spice_node(c, s['n1'])} {spice_node(c, s['n2'])}"
        wave = s.get("wave")
        scale_wave = s.get("scale_wave")
        if wave is not None:
            t, vals = _wave_points(wave, t_sample)
            card += f" DC {vals[0]:.9e} {_pwl_string(t, vals)}"
        elif scale_wave is not None:
            t, vals = _wave_points(scale_wave, t_sample)
            vals = vals * s["dc"]
            card += f" DC {vals[0]:.9e} {_pwl_string(t, vals)}"
        else:
            card += f" DC {s['dc']:.12e}"
        if s["ac"] != 0:
            card += f" AC {abs(s['ac']):.6e}"
        lines.append(card)
    for k, (np_, nn, cp, cn, gm) in enumerate(c.iter_G()):
        lines.append(f"G{k} {spice_node(c, np_)} {spice_node(c, nn)} {spice_node(c, cp)} "
                     f"{spice_node(c, cn)} {gm:.12e}")
    for np_, nn, cp, cn, gain, name in c.iter_E():
        lines.append(f"E_{_sanitize(name)} {spice_node(c, np_)} {spice_node(c, nn)} "
                     f"{spice_node(c, cp)} {spice_node(c, cn)} {gain:.12e}")
    lines.append(options)
    lines.append(analysis)
    lines.append(".end")
    path.write_text("\n".join(lines) + "\n")
    return path


def parse_raw_ascii(path: Path) -> Dict[str, np.ndarray]:
    """Parse an ngspice ASCII rawfile (possibly multiple plots; the last wins)."""
    text = path.read_text(errors="replace").splitlines()
    i = 0
    result: Dict[str, np.ndarray] = {}
    while i < len(text):
        line = text[i]
        if line.startswith("No. Variables:"):
            nvars = int(line.split(":")[1])
            i += 1
            while not text[i].startswith("No. Points:"):
                i += 1
            npts = int(text[i].split(":")[1])
            while not text[i].startswith("Variables:"):
                i += 1
            names = []
            for k in range(nvars):
                parts = text[i + 1 + k].split()
                names.append(parts[1].lower())
            i += 1 + nvars
            while not text[i].startswith("Values:"):
                i += 1
            i += 1
            tokens: List[str] = []
            while i < len(text) and len(tokens) < npts * (nvars + 1):
                if text[i].startswith(("Title:", "Plotname:")):
                    break
                tokens.extend(text[i].split())
                i += 1
            data = {nm: [] for nm in names}
            p = 0
            complex_mode = any("," in t for t in tokens[:4])
            for _ in range(npts):
                p += 1  # point index
                for nm in names:
                    tok = tokens[p]
                    p += 1
                    if complex_mode:
                        re_s, im_s = tok.split(",")
                        data[nm].append(complex(float(re_s), float(im_s)))
                    else:
                        data[nm].append(float(tok))
            result = {nm: np.array(v) for nm, v in data.items()}
            continue
        i += 1
    return result


NGSPICE_OPTION_SETS = (
    ".options gmin=1e-12 reltol=1e-6 abstol=1e-6 vntol=1e-9 method=trap itl4=100",
    ".options gmin=1e-12 reltol=1e-6 abstol=1e-6 vntol=1e-9 method=gear maxord=2 itl4=100",
    ".options gmin=1e-12 reltol=1e-5 abstol=1e-5 vntol=1e-8 method=gear maxord=2 itl4=200",
)


def run_ngspice(c: Circuit, analysis: str, save: Sequence[str], workdir: Optional[Path] = None,
                t_sample: Optional[np.ndarray] = None, timeout: int = 600,
                keep_files: bool = False, options: Optional[str] = None) -> Dict[str, np.ndarray]:
    """Simulate ``c`` with ngspice.

    ``analysis`` is an interactive analysis command (e.g. ``"op"``,
    ``"ac dec 20 1e3 1e9"``, ``"tran 1e-10 2e-6 0 1e-10"``) executed inside a
    ``.control`` block; ``save`` is a list of vectors such as ``v(node)``.
    """
    if not ngspice_available():
        raise RuntimeError("ngspice not found on PATH")
    tmp = Path(workdir) if workdir else Path(tempfile.mkdtemp(prefix="pl_ngspice_"))
    tmp.mkdir(parents=True, exist_ok=True)
    deck = tmp / "deck.cir"
    raw = tmp / "out.raw"
    ctrl = [".control", "set filetype=ascii", "set noaskquit", analysis,
            f"write {raw.name} {' '.join(save)}".rstrip(), "quit", ".endc"]
    if options:
        write_netlist(c, deck, "\n".join(ctrl), t_sample=t_sample, options=options)
    else:
        write_netlist(c, deck, "\n".join(ctrl), t_sample=t_sample)
    proc = subprocess.run(["ngspice", "-b", deck.name], cwd=tmp, capture_output=True, text=True,
                          timeout=timeout)
    if not raw.exists():
        raise RuntimeError(f"ngspice failed:\n{proc.stdout[-2000:]}\n{proc.stderr[-2000:]}")
    data = parse_raw_ascii(raw)
    log = proc.stdout + proc.stderr
    data["_aborted"] = np.array([("aborted" in log) or ("too small" in log)])
    if not keep_files and workdir is None:
        shutil.rmtree(tmp, ignore_errors=True)
    return data
