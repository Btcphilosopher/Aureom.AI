"""Independent cross-checks of the PowerLink MNA engine against ngspice.

The *same* circuit objects used by the analysis are exported to SPICE and
simulated with ngspice (an established, independently developed circuit
simulator).  Agreement demonstrates that the in-house solver, element
stamps, source conventions and transient integration are correct for the
circuits actually analysed.  It does NOT validate the physical model
(parasitic values, homogenisation) - that requires extraction and signoff
tools (docs/VALIDATION_AND_SIGNOFF.md).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Mapping

import numpy as np

from .circuit.mna import PWL
from .circuit.spice import NGSPICE_OPTION_SETS, ngspice_available, run_ngspice, spice_node


def _row(name, ours, ref, tol_abs=None, tol_rel=None, unit="") -> Dict[str, Any]:
    d = abs(ours - ref)
    rel = d / abs(ref) if ref != 0 else float("inf") if d else 0.0
    ok = (tol_abs is not None and d <= tol_abs) or (tol_rel is not None and rel <= tol_rel)
    return {"check": name, "powerlink": ours, "ngspice": ref, "abs_diff": d, "rel_diff": rel,
            "tolerance": f"{tol_abs if tol_abs is not None else ''} {unit} / {tol_rel if tol_rel is not None else ''} rel",
            "pass": bool(ok)}


def crosscheck_all(p, core_path, block_currents: Mapping[str, float], paths, outdir: Path,
                   quick: bool = False) -> Dict[str, Any]:
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    if not ngspice_available():
        return {"available": False, "rows": [], "note": "ngspice not installed - cross-check skipped"}
    rows: List[Dict[str, Any]] = []
    i_load = 0.04
    # 1. DC operating point of the rail ladder (incl. VRM averaged model)
    c, n = core_path.circuit(load_dc=i_load)
    ours = c.dc().v(n["die_load"])
    ng = run_ngspice(c, "op", [f"v({spice_node(c, c.node_index(n['die_load']))})"], workdir=outdir / "dc")
    ref = float(np.real([v for k, v in ng.items() if k != "_aborted"][-1][0]))
    rows.append(_row("ladder DC V(die)", ours, ref, tol_abs=1e-6, unit="V"))
    # 2. AC impedance
    c, n = core_path.circuit(ac_load=True)
    ng = run_ngspice(c, "ac dec 10 1e3 1e9", [f"v({spice_node(c, c.node_index(n['die_load']))})"],
                     workdir=outdir / "ac")
    f_ng = np.real(ng["frequency"])
    z_ng = np.abs(list(v for k, v in ng.items() if k not in ("frequency", "_aborted"))[0])
    res = c.ac(f_ng, [n["die_load"]])
    z_ours = np.abs(res[n["die_load"]])
    rel = np.max(np.abs(z_ours - z_ng) / z_ng)
    rows.append({"check": f"ladder |Z(f)| max rel. error ({len(f_ng)} points, 1 kHz-1 GHz)",
                 "powerlink": float(np.max(z_ours)), "ngspice": float(np.max(z_ng)), "abs_diff": float(np.max(np.abs(z_ours - z_ng))),
                 "rel_diff": float(rel), "tolerance": "1e-3 rel", "pass": bool(rel < 1e-3)})
    # 3. transient droop for a load step
    wave = PWL([0, 200e-9, 210e-9, 1.0], [0.01, 0.01, 0.01 + i_load, 0.01 + i_load])
    t_stop = 3e-6 if not quick else 1.5e-6
    c, n = core_path.circuit(load_dc=0.01, load_wave=wave)
    tr = c.tran([(t_stop, 0.05e-9)], probes=[n["die_load"]])
    node = spice_node(c, c.node_index(n["die_load"]))
    # ngspice's timestep control occasionally gives up on stiff VRM-loop decks: retry with
    # standard alternative option sets (Gear, relaxed tolerances) and record which converged
    used = None
    for k, opts in enumerate(NGSPICE_OPTION_SETS):
        ng = run_ngspice(c, f"tran 0.05n {t_stop} 0 0.05n", [f"v({node})"], workdir=outdir / f"tran{k}",
                         options=opts)
        t_ng = np.real(ng["time"])
        v_ng = np.real(ng[f"v({node.lower()})"])
        if not bool(ng.get("_aborted", [False])[0]) and t_ng[-1] >= 0.999 * t_stop:
            used = opts.split("options ")[1]
            break
    if used is None:
        rows.append({"check": "ladder transient", "powerlink": float(tr[n['die_load']].min()), "ngspice": float("nan"),
                     "abs_diff": float("nan"), "rel_diff": float("nan"),
                     "tolerance": f"ngspice aborted at t={t_ng[-1]:.3g} s (timestep control)", "pass": False})
        return {"available": True, "rows": rows, "all_pass": False}
    rows.append(_row("ladder transient V_min", float(tr[n['die_load']].min()), float(v_ng.min()),
                     tol_abs=2e-4, unit="V"))
    rows[-1]["tolerance"] += f" (ngspice {used.split('method=')[1].split()[0]}, reltol {used.split('reltol=')[1].split()[0]})"
    v_i = np.interp(t_ng, tr.t, tr[n["die_load"]])
    rows.append({"check": "ladder transient waveform RMS difference", "powerlink": float(np.sqrt(np.mean(v_i ** 2))),
                 "ngspice": float(np.sqrt(np.mean(v_ng ** 2))), "abs_diff": float(np.sqrt(np.mean((v_i - v_ng) ** 2))),
                 "rel_diff": float(np.sqrt(np.mean((v_i - v_ng) ** 2)) / np.mean(v_ng)), "tolerance": "1e-4 V",
                 "pass": bool(np.sqrt(np.mean((v_i - v_ng) ** 2)) < 1e-4)})
    # 4. on-die grid DC (coarse resolution keeps the deck small)
    from .electrical.grid import add_loads, build_grid
    gm = build_grid(p, resolution_um=100.0, rail_paths=paths)
    add_loads(gm, block_currents)
    sol = gm.circuit.dc()
    ng = run_ngspice(gm.circuit, "op", [], workdir=outdir / "grid", timeout=900)
    diffs = []
    for k in range(1, gm.circuit.n_nodes):
        key = f"v({spice_node(gm.circuit, k).lower()})"
        if key in ng:
            diffs.append(abs(float(np.real(ng[key][0])) - float(sol.x[k - 1])))
        elif spice_node(gm.circuit, k).lower() in ng:
            diffs.append(abs(float(np.real(ng[spice_node(gm.circuit, k).lower()][0])) - float(sol.x[k - 1])))
    md = max(diffs) if diffs else float("nan")
    rows.append({"check": f"grid DC node voltages, max |diff| over {len(diffs)} nodes", "powerlink": 0.0,
                 "ngspice": 0.0, "abs_diff": md, "rel_diff": md, "tolerance": "1e-6 V",
                 "pass": bool(len(diffs) > 0 and md < 1e-6)})
    return {"available": True, "rows": rows, "all_pass": all(r["pass"] for r in rows)}
