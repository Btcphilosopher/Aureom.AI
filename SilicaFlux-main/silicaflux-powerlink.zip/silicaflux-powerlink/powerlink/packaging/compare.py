"""Package suitability study.

For every package option in the library the study evaluates, for a given
chip variant:

* pin / ball / pad / bump budget (signals + power/ground allocation + spare)
* die-size fit and wire-bond pad-ring capacity
* core-rail package DC drop, first-droop estimate and peak |Z| (full AC model)
* signal integrity: required data rate vs package capability, and
  simultaneous-switching-output (SSO) ground bounce on the I/O rail
* thermal: junction temperature at the maximum workload, worst ambient,
  for the passive and active cooling options
* cost: unit, prototype and NRE amortised over the planned volume

Hard constraints give pass/fail; a weighted score ranks feasible options.
Every metric is evaluated at nominal *and* at the adverse corner of the
package parameters, so a recommendation is only called robust if it holds
at the corner.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional

import numpy as np

from ..config import Project
from ..electrical import geometry as geo
from ..electrical.impedance import default_freqs, z_die
from ..electrical.path import allocate_connections, build_rail_path, die_capacitance
from ..thermal.model import compact_network
from ..uncertainty import nom, parse_value

DEFAULT_WEIGHTS = {"electrical": 0.30, "signal_integrity": 0.15, "thermal": 0.20, "cost": 0.25,
                   "availability": 0.10}
AVAILABILITY_SCORE = {"high": 1.0, "medium": 0.7, "medium-low": 0.5, "low": 0.25}


@dataclass
class PackageAssessment:
    key: str
    family: str
    description: str
    metrics: Dict[str, Any] = field(default_factory=dict)
    checks: Dict[str, bool] = field(default_factory=dict)
    corner_checks: Dict[str, bool] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)
    score: float = 0.0

    @property
    def feasible(self) -> bool:
        return all(self.checks.values())

    @property
    def robust(self) -> bool:
        return self.feasible and all(self.corner_checks.values())


def signal_pin_count(p: Project) -> int:
    return int(sum(nom(s["pins"]) for s in p.chip.get("io", {}).get("signals", {}).values()))


def sso_noise(p: Project, pkg: Mapping[str, Any], n_io_pairs: int, use: str = "nom") -> Dict[str, float]:
    """Ground bounce from N simultaneously switching outputs through the I/O
    rail's package inductance:  dV = L_eff * N * di/dt,
    with i_pk ~= 1.5 C V / t_r and di/dt ~= i_pk / (t_r / 2)."""
    io = p.chip.get("io", {})
    rail = io.get("io_rail", "VDDIO")
    v = nom(p.rails[rail]["nominal_v"])
    v_sw = nom(io.get("sso_swing_v", v))        # signal swing (low-swing links < rail voltage)
    n = int(io.get("simultaneous_switching_outputs", 8))
    c_load = nom(io.get("sso_load_pf", 5.0)) * 1e-12
    tr = parse_value(io.get("output_edge_ns", 1.0))
    t_r = (tr.min if use == "worst" else tr.nom) * 1e-9
    dc = pkg["die_connection"]
    eff = nom(pkg.get("parallel_efficiency", 0.75))
    if dc["type"] == "bondwire":
        l_pair = geo.l_bondwire(nom(dc["length_mm"]) * 1e-3, nom(dc["diameter_um"]) * 1e-6,
                                nom(dc["return_spacing_um"]) * 1e-6)
    else:
        l_pair = nom(dc["l_loop_h"])
    l_pin = parse_value(pkg["pin"]["l_loop_h"])
    l_tot = l_pair + (l_pin.max if use == "worst" else l_pin.nom)
    l_eff = l_tot / (max(1, n_io_pairs) * eff)
    i_pk = 1.5 * c_load * v_sw / t_r
    didt = i_pk / (t_r / 2.0)
    dv = l_eff * n * didt
    return {"sso_noise_v": dv, "sso_limit_v": 0.1 * v, "l_eff_h": l_eff, "di_dt_a_per_s": n * didt}


def assess_package(p: Project, key: str, rail_currents: Mapping[str, float],
                   rail_delta_i: Mapping[str, float], total_power_w: float, core_rail: str,
                   r_grid: Optional[float] = None, volume: int = 10000, t_amb_worst: float = 70.0) -> PackageAssessment:
    pkg = p.package(key)
    a = PackageAssessment(key, pkg["family"], pkg.get("description", ""))
    m = a.metrics
    # ---- connection budget --------------------------------------------------------
    n_sig = signal_pin_count(p)
    conns = {r: allocate_connections(p, pkg, r, rail_currents.get(r, 0.0), rail_delta_i.get(r, 0.0))
             for r in p.rails}
    n_pg_pins = sum(c.n_power_pins + c.n_ground_pins for c in conns.values())
    n_pg_conn = sum(c.n_power_conn + c.n_ground_conn for c in conns.values())
    spare = float(p.chip.get("io", {}).get("spare_fraction", 0.1))
    need = int(math.ceil((n_sig + n_pg_pins) * (1 + spare)))
    m.update({"signal_pins": n_sig, "power_ground_pins": n_pg_pins, "pins_required": need,
              "pins_available": int(pkg["max_connections"]), "power_ground_die_connections": n_pg_conn,
              "allocation": {r: c.__dict__ for r, c in conns.items()}})
    a.checks["pin_budget"] = need <= int(pkg["max_connections"])
    die = max(nom(p.die["width_mm"]), nom(p.die["height_mm"]))
    a.checks["die_size"] = die <= nom(pkg["max_die_mm"])
    dc = pkg["die_connection"]
    if dc["type"] == "bondwire":
        pitch = nom(pkg.get("pad_pitch_um", 60))
        per_side = int((min(nom(p.die["width_mm"]), nom(p.die["height_mm"])) * 1e3 - 2 * 150) / pitch)
        cap = 4 * per_side
        m["die_pads_required"] = n_sig + n_pg_conn
        m["die_pads_available"] = cap
        a.checks["pad_ring"] = n_sig + n_pg_conn <= cap
    else:
        pitch = nom(dc["pitch_um"])
        cap = int(nom(p.die["width_mm"]) * 1e3 / pitch) * int(nom(p.die["height_mm"]) * 1e3 / pitch)
        m["die_bumps_required"] = n_sig + n_pg_conn
        m["die_bumps_available"] = cap
        a.checks["bump_array"] = n_sig + n_pg_conn <= cap
    # ---- electrical (core rail) ------------------------------------------------------
    cfg = p.rails[core_rail]
    v = nom(cfg["nominal_v"])
    budget = cfg.get("budget", {})
    i_core = rail_currents.get(core_rail, 0.0)
    di_core = rail_delta_i.get(core_rail, 0.0)
    for use in ("nom", "worst"):
        path = build_rail_path(p, core_rail, key, conns[core_rail], i_max=i_core, delta_i=di_core,
                               r_grid=r_grid, use=use, compensate=False)
        r_pkg = path.pins.r + path.substrate.r + path.conn.r
        l_pkg = path.l_first_droop()
        z0 = math.sqrt(l_pkg / path.c_die)
        f_res = 1.0 / (2 * math.pi * math.sqrt(l_pkg * path.c_die))
        first = di_core * z0
        dc_drop = i_core * r_pkg
        ok_dc = dc_drop <= 0.5 * nom(budget.get("dc_ir", 0.03)) * v
        ok_first = first <= nom(budget.get("dynamic", 0.05)) * v
        if use == "nom":
            freqs = default_freqs(1e5, 2e9, 30)
            f, Z = z_die(path, freqs)
            k = int(np.argmax(np.abs(Z)))
            m.update({"core_dynamic_budget_v": nom(budget.get("dynamic", 0.05)) * v,
                      "core_dc_budget_v": nom(budget.get("dc_ir", 0.03)) * v, "core_pkg_r_ohm": r_pkg, "core_pkg_l_h": l_pkg, "core_first_droop_bound_v": first,
                      "core_pkg_dc_drop_v": dc_drop, "core_die_pkg_resonance_hz": f_res,
                      "core_z_peak_ohm": float(abs(Z[k])), "core_z_peak_hz": float(f[k]),
                      "core_c_die_f": path.c_die})
            a.checks["core_pkg_dc_drop"] = ok_dc
            a.checks["core_first_droop"] = ok_first
        else:
            m.update({"core_first_droop_bound_v_worst": first, "core_pkg_dc_drop_v_worst": dc_drop})
            a.corner_checks["core_pkg_dc_drop"] = ok_dc
            a.corner_checks["core_first_droop"] = ok_first
    # EM / current capacity of connections
    worst_ratio = 0.0
    for r, cn in conns.items():
        i = rail_currents.get(r, 0.0)
        worst_ratio = max(worst_ratio, i / max(1, cn.n_power_conn) / nom(dc["i_max_a"]),
                          i / max(1, cn.n_power_pins) / nom(pkg["pin"]["i_max_a"]))
    m["connection_current_ratio"] = worst_ratio
    a.checks["connection_current"] = worst_ratio <= 1.0
    # ---- signal integrity ------------------------------------------------------------------
    req = float(p.chip.get("io", {}).get("max_signal_rate_gbps", 0.1))
    cap_rate = parse_value(pkg["si"]["max_rate_gbps"])
    m["si_required_gbps"] = req
    m["si_capability_gbps"] = cap_rate.nom
    a.checks["si_rate"] = req <= cap_rate.nom
    a.corner_checks["si_rate"] = req <= cap_rate.min
    io_rail = p.chip.get("io", {}).get("io_rail", "VDDIO")
    n_io = conns[io_rail].n_power_conn if io_rail in conns else 4
    for use in ("nom", "worst"):
        s = sso_noise(p, pkg, n_io, use)
        if use == "nom":
            m.update({"sso_noise_v": s["sso_noise_v"], "sso_limit_v": s["sso_limit_v"]})
            a.checks["sso_noise"] = s["sso_noise_v"] <= s["sso_limit_v"]
        else:
            m["sso_noise_v_worst"] = s["sso_noise_v"]
            a.corner_checks["sso_noise"] = s["sso_noise_v"] <= s["sso_limit_v"]
    # ---- thermal -----------------------------------------------------------------------------
    tj_lim = float(p.thermal.get("tj_limit_c", p.chip["chip"].get("tj_max_c", 105)))
    tj = {}
    for cool in p.thermal["cooling_options"]:
        net = compact_network(p, key, cool)
        tj[cool] = net.tj(total_power_w, t_amb_worst)
    m["tj_by_cooling_c"] = tj
    m["tj_limit_c"] = tj_lim
    passive = [c for c in tj if "passive" in c or c == "natural_convection"]
    best_passive = min(tj[c] for c in passive)
    m["tj_best_passive_c"] = best_passive
    m["tj_natural_c"] = tj.get("natural_convection", float("nan"))
    a.checks["thermal_any_cooling"] = min(tj.values()) <= tj_lim
    worst_net = {c: compact_network(p, key, c, use="worst").tj(total_power_w, t_amb_worst) for c in tj}
    a.corner_checks["thermal_any_cooling"] = min(worst_net.values()) <= tj_lim
    m["tj_by_cooling_c_worst"] = worst_net
    # ---- cost --------------------------------------------------------------------------------
    cost = pkg["cost"]
    unit = nom(cost["unit_usd"])
    nre = nom(cost["nre_usd"])
    m["unit_cost_usd"] = unit
    m["proto_unit_usd"] = nom(cost["proto_unit_usd"])
    m["nre_usd"] = nre
    m["cost_per_unit_at_volume_usd"] = unit + nre / max(1, volume)
    m["availability"] = cost.get("availability", "medium")
    return a


def score_assessments(items: List[PackageAssessment], weights: Optional[Mapping[str, float]] = None) -> None:
    w = dict(DEFAULT_WEIGHTS)
    w.update(weights or {})
    costs = [it.metrics["cost_per_unit_at_volume_usd"] for it in items]
    cmin, cmax = math.log(min(costs)), math.log(max(costs))
    for it in items:
        m = it.metrics
        e = 1.0 - min(1.0, 0.5 * m["core_first_droop_bound_v"] / max(m["core_dynamic_budget_v"], 1e-12)
                      + 0.5 * m["core_pkg_dc_drop_v"] / max(0.5 * m["core_dc_budget_v"], 1e-12))
        e = max(0.0, e)
        si = min(1.0, m["si_capability_gbps"] / max(m["si_required_gbps"], 1e-3) / 10.0) * \
            max(0.0, 1.0 - m["sso_noise_v"] / max(m["sso_limit_v"], 1e-9) * 0.5)
        th = max(0.0, min(1.0, (m["tj_limit_c"] - m["tj_best_passive_c"]) / 50.0))
        cs = 1.0 if cmax == cmin else 1.0 - (math.log(m["cost_per_unit_at_volume_usd"]) - cmin) / (cmax - cmin)
        av = AVAILABILITY_SCORE.get(str(m["availability"]), 0.5)
        it.metrics["subscores"] = {"electrical": e, "signal_integrity": si, "thermal": th, "cost": cs,
                                   "availability": av}
        it.score = sum(w[k] * v for k, v in it.metrics["subscores"].items()) * (1.0 if it.feasible else 0.0)


def package_study(p: Project, rail_currents: Mapping[str, float], rail_delta_i: Mapping[str, float],
                  total_power_w: float, core_rail: str, r_grid: Optional[float] = None) -> List[PackageAssessment]:
    """Assess every library package.  ``package_study.design_delta_i_event`` (chip config) names
    the transient event whose *per-step* current change the package must support (e.g. a
    staggered wake); by default the full rail current swing is used."""
    study = p.chip.get("package_study", {})
    ev_name = study.get("design_delta_i_event")
    if ev_name:
        ev = p.workloads["transient_events"][ev_name]
        steps = int(ev.get("stagger_steps", 1))
        rail_delta_i = dict(rail_delta_i)
        rail_delta_i[core_rail] = rail_delta_i[core_rail] / steps
    volume = int(study.get("volume_units", 10000))
    t_amb = nom(parse_value(p.thermal.get("ambient_c", 25.0)).max)
    items = [assess_package(p, k, rail_currents, rail_delta_i, total_power_w, core_rail, r_grid, volume, t_amb)
             for k in p.packages["packages"]]
    score_assessments(items, study.get("weights"))
    items.sort(key=lambda it: -it.score)
    for it in items:
        failed = [k for k, v in it.checks.items() if not v]
        cfailed = [k for k, v in it.corner_checks.items() if not v]
        if failed:
            it.notes.append("fails: " + ", ".join(failed))
        if cfailed and not failed:
            it.notes.append("passes nominal, fails at adverse corner: " + ", ".join(cfailed))
    return items
