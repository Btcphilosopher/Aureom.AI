"""SilicaFlux PowerLink command-line interface.

    python -m powerlink run      --chip configs/chips/silicaflux_v.yaml --out results/silicaflux_v
    python -m powerlink power    --chip ... [--profile max_simultaneous] [--temp 85]
    python -m powerlink ir       --chip ... [--profile ...] [--res 20]
    python -m powerlink packages --chip ...
    python -m powerlink openroad --chip ... --out openroad/
    python -m powerlink activity --chip ... --file sim.vcd [--saif out.saif]
    python -m powerlink thermal-import --chip ... --csv icepak_map.csv
    python -m powerlink crosscheck --chip ...
    python -m powerlink assumptions --chip ...
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .config import assumption_register, load_project


def _table(rows, headers):
    w = [max(len(str(h)), *(len(f"{r[i]:.4g}" if isinstance(r[i], float) else str(r[i])) for r in rows))
         for i, h in enumerate(headers)]
    fmt = lambda v: f"{v:.4g}" if isinstance(v, float) else str(v)  # noqa: E731
    print("  ".join(str(h).ljust(w[i]) for i, h in enumerate(headers)))
    for r in rows:
        print("  ".join(fmt(v).ljust(w[i]) for i, v in enumerate(r)))


def cmd_run(a):
    from .flows import run_all
    s = run_all(a.chip, a.out, mc_samples=a.mc, seed=a.seed, crosscheck=not a.no_crosscheck, quick=a.quick)
    print("\n".join(s["verdict"]))


def cmd_power(a):
    from .power.dynamic import evaluate_workload
    p = load_project(a.chip)
    profs = [a.profile] if a.profile else list(p.workloads["profiles"])
    rows = []
    for pr_name in profs:
        pr = evaluate_workload(p, pr_name, temp_c=a.temp)
        bd = pr.breakdown()
        rows.append([pr_name] + [pr.rail_power(r) * 1e3 for r in p.rails] + [bd["leakage"] * 1e3, pr.total_w() * 1e3])
    _table(rows, ["profile"] + [f"{r} mW" for r in p.rails] + ["leakage mW", "total mW"])
    print(f"(junction temperature {a.temp} C; activity source: assumed unless SAIF/VCD attached)")


def cmd_ir(a):
    from .electrical.em import em_summary
    from .electrical.grid import solve_static
    from .electrical.path import build_rail_path
    from .power.dynamic import evaluate_workload
    p = load_project(a.chip)
    pr = evaluate_workload(p, a.profile, temp_c=a.temp)
    paths = {r: build_rail_path(p, r, i_max=pr.rail_current(r), delta_i=pr.rail_current(r)) for r in p.rails}
    ir = solve_static(p, {b.name: b.current_a for b in pr.blocks}, rail_paths=paths, resolution_um=a.res)
    for net in ir.worst_drop_v:
        print(f"{net}: worst {ir.worst_drop_v[net]*1e3:.3f} mV, mean {ir.mean_drop_v[net]*1e3:.3f} mV, "
              f"R_eff {ir.r_grid_eff[net]*1e3:.2f} mOhm, breakdown {ir.drop_breakdown[net]}")
    _table([[r["item"], r["worst"], r["limit"], r["unit"], r["ratio"]] for r in em_summary(ir, a.temp)],
           ["item", "worst", "limit", "unit", "ratio"])
    for n in sorted(set(ir.grid.notes)):
        print("note:", n)


def cmd_packages(a):
    from .packaging.compare import package_study
    from .power.dynamic import all_profiles
    p = load_project(a.chip)
    prof = all_profiles(p, temp_c=a.temp)
    core = next(r for r, c in p.rails.items() if c.get("on_die_grid"))
    i_max = {r: max(x.rail_current(r) for x in prof.values()) for r in p.rails}
    i_min = {r: min(x.rail_current(r) for x in prof.values()) for r in p.rails}
    tot = max(x.total_w() for x in prof.values())
    items = package_study(p, i_max, {r: i_max[r] - i_min[r] for r in p.rails}, tot, core)
    _table([[it.key, it.score, it.feasible, it.robust, f"{it.metrics['pins_required']}/{it.metrics['pins_available']}",
             it.metrics["core_first_droop_bound_v"] * 1e3, it.metrics["tj_best_passive_c"], "; ".join(it.notes)]
            for it in items], ["package", "score", "feasible", "robust", "pins", "droop mV", "Tj C", "notes"])


def cmd_openroad(a):
    from .pdn_onchip.openroad import check_pdn, write_scripts
    p = load_project(a.chip)
    chk = check_pdn(p)
    for e in chk.errors:
        print("ERROR:", e)
    for w in chk.warnings:
        print("warning:", w)
    for k, v in write_scripts(p, a.out).items():
        print(f"{k}: {v}")
    if chk.errors:
        sys.exit(1)


def cmd_activity(a):
    from .power.activity import block_activity, load_activity, write_saif
    p = load_project(a.chip)
    data = load_activity(a.file)
    bm = p.workloads.get("activity_block_map", {})
    if a.map:
        bm = json.loads(a.map)
    act = block_activity(data, bm, p.clock_hz if not a.fclk else a.fclk * 1e6)
    print(f"{data.source}: {len(data.nets)} nets, duration {data.duration_s*1e6:.3f} us, "
          f"{data.cycles(p.clock_hz if not a.fclk else a.fclk*1e6):.0f} cycles")
    _table([[k, v.alpha, v.toggle_rate, v.nets, v.bits] for k, v in act.items()],
           ["block", "alpha", "TR/cycle", "nets", "bits"])
    if a.saif:
        write_saif(data, a.saif)
        print("wrote", a.saif)
    print("To use these values, add the file under 'activity_files: {<profile>: <path>}' in the workload YAML.")


def cmd_thermal_import(a):
    from .thermal.model import import_map_csv
    from .uncertainty import nom
    p = load_project(a.chip)
    tm = import_map_csv(a.csv, die_w_um=nom(p.die["width_mm"]) * 1e3, die_h_um=nom(p.die["height_mm"]) * 1e3)
    bt = tm.block_temperatures(p)
    print(f"imported map: {tm.temp_c.shape[1]}x{tm.temp_c.shape[0]}, max {tm.t_max:.2f} C")
    _table([[k, v] for k, v in bt.items()], ["block", "temp C"])
    if a.out:
        Path(a.out).write_text(json.dumps(bt, indent=2))
        print("wrote block temperatures to", a.out, "(pass as temp_c to power.evaluate_workload)")


def cmd_crosscheck(a):
    from .electrical.path import build_rail_path
    from .power.dynamic import evaluate_workload
    from .validation import crosscheck_all
    p = load_project(a.chip)
    pr = evaluate_workload(p, a.profile, temp_c=85.0)
    paths = {r: build_rail_path(p, r, i_max=pr.rail_current(r), delta_i=pr.rail_current(r)) for r in p.rails}
    core = next(r for r, c in p.rails.items() if c.get("on_die_grid"))
    res = crosscheck_all(p, paths[core], {b.name: b.current_a for b in pr.blocks}, paths, Path(a.out))
    if not res.get("available"):
        print(res.get("note"))
        return
    _table([[r["check"], r["abs_diff"], r["rel_diff"], "PASS" if r["pass"] else "FAIL"] for r in res["rows"]],
           ["check", "abs diff", "rel diff", "result"])
    sys.exit(0 if res["all_pass"] else 1)


def cmd_assumptions(a):
    p = load_project(a.chip)
    rows = assumption_register(p)
    _table([[r["path"], r["nominal"], r["min"], r["max"], r["source"]] for r in rows],
           ["path", "nominal", "min", "max", "source"])


def main(argv=None):
    ap = argparse.ArgumentParser(prog="powerlink", description="SilicaFlux PowerLink power/package co-design toolkit")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def chip(sp):
        sp.add_argument("--chip", default="configs/chips/silicaflux_v.yaml")

    sp = sub.add_parser("run", help="full analysis + report"); chip(sp)
    sp.add_argument("--out", default="results/silicaflux_v")
    sp.add_argument("--mc", type=int, default=4000, help="Monte-Carlo samples")
    sp.add_argument("--seed", type=int, default=1)
    sp.add_argument("--quick", action="store_true", help="shorter transient windows / fewer direct MC runs")
    sp.add_argument("--no-crosscheck", action="store_true")
    sp.set_defaults(fn=cmd_run)
    sp = sub.add_parser("power", help="workload power table"); chip(sp)
    sp.add_argument("--profile"); sp.add_argument("--temp", type=float, default=85.0)
    sp.set_defaults(fn=cmd_power)
    sp = sub.add_parser("ir", help="static IR drop and EM"); chip(sp)
    sp.add_argument("--profile", default="max_simultaneous"); sp.add_argument("--temp", type=float, default=85.0)
    sp.add_argument("--res", type=float, default=None)
    sp.set_defaults(fn=cmd_ir)
    sp = sub.add_parser("packages", help="package comparison"); chip(sp)
    sp.add_argument("--temp", type=float, default=85.0)
    sp.set_defaults(fn=cmd_packages)
    sp = sub.add_parser("openroad", help="generate OpenROAD PDN scripts / UPF"); chip(sp)
    sp.add_argument("--out", default="openroad")
    sp.set_defaults(fn=cmd_openroad)
    sp = sub.add_parser("activity", help="VCD/SAIF toggle-rate import"); chip(sp)
    sp.add_argument("--file", required=True); sp.add_argument("--saif"); sp.add_argument("--map")
    sp.add_argument("--fclk", type=float, help="clock frequency in MHz (default: chip clock)")
    sp.set_defaults(fn=cmd_activity)
    sp = sub.add_parser("thermal-import", help="import a specialist thermal map (CSV)"); chip(sp)
    sp.add_argument("--csv", required=True); sp.add_argument("--out")
    sp.set_defaults(fn=cmd_thermal_import)
    sp = sub.add_parser("crosscheck", help="ngspice cross-check of the MNA engine"); chip(sp)
    sp.add_argument("--profile", default="max_simultaneous"); sp.add_argument("--out", default="results/crosscheck")
    sp.set_defaults(fn=cmd_crosscheck)
    sp = sub.add_parser("assumptions", help="list every uncertain input and its provenance"); chip(sp)
    sp.set_defaults(fn=cmd_assumptions)
    a = ap.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
