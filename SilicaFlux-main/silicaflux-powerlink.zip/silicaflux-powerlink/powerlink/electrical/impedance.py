"""Frequency-domain PDN analysis: impedance seen by the die, target
impedance, resonances, VRM loop gain / phase margin and ripple transfer."""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from ..circuit.mna import Circuit
from .vrm import BuckVRM


def default_freqs(f_lo: float = 1e3, f_hi: float = 2e9, points_per_decade: int = 40) -> np.ndarray:
    n = int(points_per_decade * math.log10(f_hi / f_lo)) + 1
    return np.logspace(math.log10(f_lo), math.log10(f_hi), n)


def z_die(path, freqs: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
    """Closed-loop PDN impedance looking from the die load node, Z(f) [ohm]."""
    freqs = default_freqs() if freqs is None else freqs
    c, n = path.circuit(ac_load=True)
    # 1 A AC injected *out of* die_load by the load source -> V(die_load) = -Z
    res = c.ac(freqs, [n["die_load"]])
    return freqs, -res[n["die_load"]]


def z_at_nodes(path, freqs: np.ndarray) -> Dict[str, np.ndarray]:
    """Impedance seen at intermediate nodes (die, package, PCB), for plotting."""
    c, n = path.circuit(ac_load=True)
    res = c.ac(freqs, [n["die_load"], n["die_pad"], n["pkg_die"], n["pcb_dev"]])
    return {"freq": freqs, **{k: -res[n[k]] for k in ("die_load", "die_pad", "pkg_die", "pcb_dev")}}


def loop_gain(path, freqs: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """VRM voltage-loop gain T(jw) with the loop broken at the power-stage control.

    The power stage is a VCCS whose control input draws no current, so
    breaking the loop there and driving it with an ideal source gives the
    exact loop gain:  T = -V(comp) / V(x).
    """
    if not isinstance(path.regulator, BuckVRM):
        raise TypeError("loop gain only defined for switching regulators")
    c, n = path.circuit(open_loop=True)
    comp = "vrm_comp"
    res = c.ac(freqs, [comp])
    return freqs, -res[comp]


def stability_margins(freqs: np.ndarray, T: np.ndarray) -> Dict[str, float]:
    mag = np.abs(T)
    ph = np.unwrap(np.angle(T))
    out = {"crossover_hz": float("nan"), "phase_margin_deg": float("nan"),
           "gain_margin_db": float("inf")}
    idx = np.where((mag[:-1] >= 1.0) & (mag[1:] < 1.0))[0]
    if len(idx):
        k = idx[0]
        # log-linear interpolation
        f1, f2 = math.log(freqs[k]), math.log(freqs[k + 1])
        m1, m2 = math.log(mag[k]), math.log(mag[k + 1])
        x = (0 - m1) / (m2 - m1)
        fc = math.exp(f1 + x * (f2 - f1))
        phc = ph[k] + x * (ph[k + 1] - ph[k])
        out["crossover_hz"] = fc
        out["phase_margin_deg"] = 180.0 + math.degrees(phc)
        # normalise to (-180, 180]
        pm = out["phase_margin_deg"]
        while pm > 180:
            pm -= 360
        while pm <= -180:
            pm += 360
        out["phase_margin_deg"] = pm
    # gain margin at phase = -180 (first crossing above crossover)
    phd = np.degrees(ph)
    cross = np.where((phd[:-1] > -180) & (phd[1:] <= -180))[0]
    for k in cross:
        if not np.isnan(out["crossover_hz"]) and freqs[k] < out["crossover_hz"]:
            continue
        out["gain_margin_db"] = float(-20 * math.log10(mag[k] + 1e-30))
        break
    return out


def target_impedance(v_nom: float, dynamic_fraction: float, delta_i: float) -> float:
    """Classic flat target impedance Z_t = V * tolerance / dI.

    A screening criterion only: a flat-Z design can still violate droop for
    resonant workloads, and can be over-conservative for slow edges; the
    time-domain droop analysis is the governing check.
    """
    return v_nom * dynamic_fraction / max(delta_i, 1e-9)


def find_resonances(freqs: np.ndarray, z: np.ndarray, min_ratio: float = 1.15) -> List[Dict[str, float]]:
    """Local maxima of |Z| that stand out from their neighbourhood (anti-resonances)."""
    mag = np.abs(z)
    peaks = []
    for k in range(2, len(mag) - 2):
        if mag[k] >= mag[k - 1] and mag[k] > mag[k + 1]:
            lo = mag[max(0, k - 20):k].min()
            hi = mag[k + 1:k + 21].min()
            if mag[k] / max(min(lo, hi), 1e-30) >= min_ratio:
                peaks.append({"f_hz": float(freqs[k]), "z_ohm": float(mag[k])})
    peaks.sort(key=lambda d: -d["z_ohm"])
    return peaks


def ripple_at_die(path, f_sw: float, ripple_current_pp: float) -> Dict[str, float]:
    """Switching ripple reaching the die.

    The averaged regulator injects its inductor ripple current (triangle,
    peak-to-peak dI) into the output node.  Fundamental peak amplitude of a
    triangle of p-p dI is 4 dI / pi^2.  The die ripple is that current times
    the transimpedance Z21(f_sw) from the VRM output node to the die node
    (higher harmonics are attenuated further and neglected).
    """
    c, n = path.circuit(vrm_ac_inject=True)
    res = c.ac([f_sw], [n["die_load"], n["vrm_out"]])
    z21 = abs(res[n["die_load"]][0])
    z11 = abs(res[n["vrm_out"]][0])
    i1 = 4.0 * ripple_current_pp / math.pi ** 2
    return {"z21_ohm": z21, "z11_ohm": z11, "ripple_die_pp_v": 2 * z21 * i1,
            "ripple_vrm_pp_v_fundamental": 2 * z11 * i1}
