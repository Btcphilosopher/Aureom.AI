"""Power-integrity margin budgets.

For a rail with nominal voltage V_nom and minimum device voltage V_min
(library characterisation corner), the voltage seen by the worst cell is

    V_cell = V_nom - e_setpoint - ripple/2 - IR_static - droop_dynamic

and the margin is V_cell - V_min - guardband.  Three combinations are
reported:

* **worst-case linear stack** - every component at its adverse bound;
* **RSS** - DC IR stacked linearly, independent random terms (setpoint,
  ripple, dynamic) root-sum-squared;
* **Monte-Carlo** - every uncertain input sampled from its configured
  distribution (power-law surrogate for the dynamic term, exact linear
  scaling for IR), giving a margin distribution and a violation
  probability.  The surrogate is validated against the full model at the
  worst-case corner and the error is reported.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional

import numpy as np

from ..uncertainty import summarize_samples


@dataclass
class BudgetComponent:
    name: str
    value_v: float          # nominal-estimate contribution (positive = reduces voltage)
    worst_v: float          # adverse-corner contribution
    allocation_v: float     # budgeted allocation
    random: bool            # include in RSS group
    source: str = "model"

    @property
    def within_allocation(self) -> bool:
        return self.worst_v <= self.allocation_v


@dataclass
class RailBudget:
    rail: str
    v_nom: float
    v_min: float
    components: List[BudgetComponent]
    guardband_v: float
    mc: Optional[Dict[str, Any]] = None
    notes: List[str] = field(default_factory=list)

    @property
    def total_nominal_v(self) -> float:
        return sum(c.value_v for c in self.components)

    @property
    def total_worst_v(self) -> float:
        return sum(c.worst_v for c in self.components)

    @property
    def available_v(self) -> float:
        return self.v_nom - self.v_min - self.guardband_v

    @property
    def margin_nominal_v(self) -> float:
        return self.available_v - self.total_nominal_v

    @property
    def margin_worst_v(self) -> float:
        return self.available_v - self.total_worst_v

    @property
    def margin_rss_v(self) -> float:
        lin = sum(c.worst_v for c in self.components if not c.random)
        rss = math.sqrt(sum(c.worst_v ** 2 for c in self.components if c.random))
        return self.available_v - lin - rss

    def table(self) -> List[Dict[str, Any]]:
        rows = [{"component": c.name, "nominal_mv": c.value_v * 1e3, "worst_mv": c.worst_v * 1e3,
                 "allocation_mv": c.allocation_v * 1e3, "within_allocation": c.within_allocation,
                 "source": c.source} for c in self.components]
        rows.append({"component": "guardband", "nominal_mv": self.guardband_v * 1e3,
                     "worst_mv": self.guardband_v * 1e3, "allocation_mv": self.guardband_v * 1e3,
                     "within_allocation": True, "source": "spec"})
        return rows

    def summary(self) -> Dict[str, Any]:
        out = {"rail": self.rail, "v_nom": self.v_nom, "v_min": self.v_min,
               "available_mv": self.available_v * 1e3, "margin_nominal_mv": self.margin_nominal_v * 1e3,
               "margin_worst_mv": self.margin_worst_v * 1e3, "margin_rss_mv": self.margin_rss_v * 1e3,
               "pass_worst_case": self.margin_worst_v >= 0, "pass_rss": self.margin_rss_v >= 0}
        if self.mc:
            out["mc_p_fail"] = self.mc["p_fail"]
            out["mc_margin_p01_mv"] = self.mc["margin_mv"]["p01"]
            out["mc_margin_p50_mv"] = self.mc["margin_mv"]["p50"]
        return out


def monte_carlo_margin(budget: RailBudget, samples: Mapping[str, np.ndarray]) -> Dict[str, Any]:
    """Combine sampled component arrays (volts, positive = loss) into a margin distribution."""
    n = len(next(iter(samples.values())))
    loss = np.zeros(n)
    for k, v in samples.items():
        loss = loss + np.asarray(v)
    margin = budget.available_v - loss
    return {"n": n, "p_fail": float(np.mean(margin < 0)), "margin_mv": summarize_samples(margin * 1e3),
            "components_mv": {k: summarize_samples(np.asarray(v) * 1e3) for k, v in samples.items()},
            "margin_samples_mv": (margin * 1e3).tolist() if n <= 20000 else None}
