"""Decoupling capacitor models and decap-network selection.

A capacitor (or a bank of N identical parts in parallel) is modelled as a
series R-L-C:  Z = ESR/N + j w (ESL + L_mount)/N + 1/(j w C_eff N).
C_eff includes DC-bias and temperature derating for class-II ceramics,
which commonly removes 30-70 % of the nameplate value for small cases at
rated-voltage fractions above ~20 %.  All derating values are inputs with
uncertainty, never fixed constants.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Any, Dict, List, Mapping, Optional, Sequence

import numpy as np

from ..uncertainty import nom, parse_value


@dataclass
class CapacitorPart:
    name: str
    c_f: float
    esr_ohm: float
    esl_h: float
    mount_l_h: float = 0.0
    derating: float = 1.0          # retained fraction of nameplate C at operating bias/temp
    dielectric: str = "X5R"
    case: str = ""
    rated_v: float = 0.0

    @property
    def c_eff(self) -> float:
        return self.c_f * self.derating

    @property
    def l_total(self) -> float:
        return self.esl_h + self.mount_l_h

    @property
    def srf_hz(self) -> float:
        return 1.0 / (2 * math.pi * math.sqrt(self.l_total * self.c_eff))

    def z(self, f: np.ndarray, count: int = 1) -> np.ndarray:
        w = 2 * np.pi * np.asarray(f, dtype=float)
        return (self.esr_ohm + 1j * w * self.l_total + 1.0 / (1j * w * self.c_eff)) / count


@dataclass
class CapBank:
    part: CapacitorPart
    count: int
    location: str = "pcb_near"     # vrm | pcb_near | pcb_under | package | die

    def z(self, f: np.ndarray) -> np.ndarray:
        return self.part.z(f, self.count)

    @property
    def c_total(self) -> float:
        return self.part.c_eff * self.count

    def rlc(self) -> tuple:
        """Equivalent (R, L, C) of the bank."""
        return (self.part.esr_ohm / self.count, self.part.l_total / self.count,
                self.part.c_eff * self.count)


def part_from_config(name: str, cfg: Mapping[str, Any], mount_l_h: Optional[float] = None,
                     use: str = "nom") -> CapacitorPart:
    """Create a part from a library entry.  ``use`` = 'nom' | 'worst' | 'best'."""
    def pick(key: str, adverse_high: bool, default: float = 0.0) -> float:
        if key not in cfg:
            return default
        uv = parse_value(cfg[key])
        if use == "nom":
            return uv.nom
        if use == "worst":
            return uv.max if adverse_high else uv.min
        return uv.min if adverse_high else uv.max

    return CapacitorPart(
        name=name,
        c_f=pick("c_f", False),
        esr_ohm=pick("esr_ohm", True),
        esl_h=pick("esl_h", True),
        mount_l_h=pick("mount_l_h", True) if mount_l_h is None else mount_l_h,
        derating=pick("dc_bias_retained", False, 1.0),
        dielectric=str(cfg.get("dielectric", "")),
        case=str(cfg.get("case", "")),
        rated_v=float(nom(cfg.get("rated_v", 0.0))),
    )


def banks_from_config(entries: Sequence[Mapping[str, Any]], library: Mapping[str, Any],
                      use: str = "nom", overrides: Optional[Dict[str, float]] = None) -> List[CapBank]:
    banks = []
    for e in entries:
        part = part_from_config(e["part"], library[e["part"]], use=use)
        if overrides:
            if "derating_scale" in overrides:
                part = replace(part, derating=min(1.0, part.derating * overrides["derating_scale"]))
            if "esl_scale" in overrides:
                part = replace(part, esl_h=part.esl_h * overrides["esl_scale"],
                               mount_l_h=part.mount_l_h * overrides["esl_scale"])
        banks.append(CapBank(part, int(e["count"]), str(e.get("location", "pcb_near"))))
    return banks


def die_decap_required(delta_i: float, delta_v: float, l_loop: float) -> float:
    """Minimum on-die capacitance to keep the *first droop* below delta_v.

    For an abrupt current step into a lossless series L feeding a capacitor
    C, the peak droop is delta_i * sqrt(L/C)  ->  C >= L (delta_i/delta_v)^2.
    Damping (ESR, grid resistance) and finite rise time reduce the droop,
    so this bound is conservative.
    """
    return l_loop * (delta_i / delta_v) ** 2


def first_droop_estimate(delta_i: float, l_loop: float, c_die: float, r_series: float = 0.0,
                         t_rise: float = 0.0) -> float:
    """Peak first-droop estimate for a ramped current step into series R-L / shunt C.

    Uses the characteristic impedance Z0 = sqrt(L/C), a damping correction
    from the series R (zeta = R/(2 Z0)) and the ramp correction factor
    |sin(w0 tr/2)/(w0 tr/2)| for a linear ramp of duration tr exciting an
    oscillator of natural frequency w0 (exact for the undamped case).
    """
    z0 = math.sqrt(l_loop / c_die)
    w0 = 1.0 / math.sqrt(l_loop * c_die)
    zeta = r_series / (2.0 * z0)
    if zeta < 1.0:
        overshoot = math.exp(-math.pi * zeta / (2.0 * math.sqrt(1 - zeta ** 2)) * 1.0)
    else:
        overshoot = 0.0
    x = 0.5 * w0 * t_rise
    ramp = 1.0 if x < 1e-9 else abs(math.sin(x) / x)
    # droop = IR component + resonant component
    return delta_i * r_series + delta_i * z0 * overshoot * ramp


def select_decaps(z_network_fn, f: np.ndarray, z_target: np.ndarray,
                  candidates: Sequence[CapacitorPart], max_parts: int = 64,
                  location: str = "pcb_under") -> List[CapBank]:
    """Greedy decap selection.

    ``z_network_fn(banks)`` must return |Z(f)| of the full PDN with the extra
    banks added.  At each iteration the frequency with the worst violation
    ratio |Z|/Z_target is found and the candidate that most reduces the
    maximum violation is added.  Stops when |Z| <= Z_target everywhere or
    when ``max_parts`` is reached.  This is a heuristic (not a global
    optimum); results must be confirmed in the time domain.
    """
    chosen: Dict[str, int] = {}
    banks: List[CapBank] = []

    def as_banks(ch: Dict[str, int]) -> List[CapBank]:
        out = []
        for nm, cnt in ch.items():
            part = next(p for p in candidates if p.name == nm)
            out.append(CapBank(part, cnt, location))
        return out

    total = 0
    zcur = np.abs(z_network_fn(banks))
    while total < max_parts:
        ratio = zcur / z_target
        if np.max(ratio) <= 1.0:
            break
        best = None
        for p in candidates:
            trial = dict(chosen)
            trial[p.name] = trial.get(p.name, 0) + 1
            zt = np.abs(z_network_fn(as_banks(trial)))
            score = np.max(zt / z_target)
            if best is None or score < best[0] - 1e-12:
                best = (score, p.name, zt)
        if best is None:
            break
        chosen[best[1]] = chosen.get(best[1], 0) + 1
        zcur = best[2]
        total += 1
    return as_banks(chosen)
