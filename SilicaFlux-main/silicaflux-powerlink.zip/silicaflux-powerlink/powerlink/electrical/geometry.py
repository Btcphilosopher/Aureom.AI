"""Closed-form resistance / inductance of power-delivery structures.

All functions use SI units.  The formulas are standard low-frequency
(quasi-static) approximations; each docstring states its validity range.
They are used to *build* equivalent circuits from geometry when extracted
parasitics are not yet available.  Once a package/PCB layout exists, they
should be replaced by extracted values (see docs/VALIDATION_AND_SIGNOFF.md).
"""
from __future__ import annotations

import math

from ..constants import MU0, resistivity


# ------------------------------------------------------------------ resistance
def r_bar(rho: float, length: float, width: float, thickness: float) -> float:
    """DC resistance of a rectangular conductor, R = rho L / (w t)."""
    return rho * length / (width * thickness)


def r_sheet_strip(rs_ohm_sq: float, length: float, width: float) -> float:
    """Resistance of a strip from its sheet resistance: R = Rs * (L / w)."""
    return rs_ohm_sq * length / width


def r_cylinder(rho: float, length: float, diameter: float) -> float:
    return rho * length / (math.pi * (diameter / 2.0) ** 2)


def r_plane_pair(rho: float, length: float, width: float, t_cu: float) -> float:
    """Loop DC resistance of a power plane and its return plane (two identical sheets)."""
    return 2.0 * r_bar(rho, length, width, t_cu)


def r_sphere_ball(rho: float, diameter: float, pad_diameter: float) -> float:
    """Approximate DC resistance of a collapsed solder ball.

    The ball is approximated by a cylinder whose diameter is the mean of the
    ball and pad diameters and whose height is 0.8 x the ball diameter
    (collapse).  Accuracy ~ +/-30 %; use extracted values for signoff.
    """
    h = 0.8 * diameter
    d_eff = 0.5 * (diameter + pad_diameter)
    return r_cylinder(rho, h, d_eff)


def oz_to_m(oz: float) -> float:
    """Copper weight to thickness: 1 oz/ft^2 = 34.79 um (nominal 35 um)."""
    return oz * 34.79e-6


# ------------------------------------------------------------------ inductance
def l_wire_self(length: float, radius: float) -> float:
    """Partial self-inductance of a straight round wire (Rosa/Grover, DC current).

    L = mu0 l / (2 pi) * (ln(2 l / r) - 3/4),   valid for l >> r.
    """
    return MU0 * length / (2 * math.pi) * (math.log(2 * length / radius) - 0.75)


def m_parallel_wires(length: float, spacing: float) -> float:
    """Partial mutual inductance of two parallel filaments of equal length (Grover).

    M = mu0 l / (2 pi) * (ln(l/d + sqrt(1 + l^2/d^2)) - sqrt(1 + d^2/l^2) + d/l)
    """
    l, d = length, spacing
    return MU0 * l / (2 * math.pi) * (math.log(l / d + math.sqrt(1 + (l / d) ** 2))
                                       - math.sqrt(1 + (d / l) ** 2) + d / l)


def l_loop_wire_pair(length: float, radius: float, spacing: float) -> float:
    """Loop inductance of a supply wire and its adjacent return wire, 2 (L - M)."""
    return 2.0 * (l_wire_self(length, radius) - m_parallel_wires(length, spacing))


def l_bondwire(length: float, diameter: float, return_spacing: float) -> float:
    """Loop inductance of a VDD bond wire with an adjacent VSS bond wire."""
    return l_loop_wire_pair(length, diameter / 2.0, return_spacing)


def l_plane_pair_per_square(separation: float) -> float:
    """Inductance of a plane pair per square of current path: L = mu0 h."""
    return MU0 * separation


def l_plane_pair(separation: float, length: float, width: float) -> float:
    """Uniform-current plane-pair inductance between two edges: mu0 h L / w."""
    return MU0 * separation * length / width


def l_plane_spreading(separation: float, distance: float, via_radius: float) -> float:
    """Spreading inductance between two vias in a plane pair (radial-flow approximation).

    L ~= (mu0 h / pi) * ln(d / r_via), for d >> r_via.
    """
    return MU0 * separation / math.pi * math.log(distance / via_radius)


def l_via_pair(height: float, radius: float, pitch: float) -> float:
    """Loop inductance of a power via and an adjacent return via (two-wire line)."""
    return MU0 * height / math.pi * math.log(pitch / radius)


def l_effective_parallel(l_single: float, n: int, efficiency: float = 1.0) -> float:
    """Effective inductance of n identical connections in parallel.

    Mutual coupling between same-direction currents makes the result larger
    than l/n; ``efficiency`` (0..1] captures that: L_eff = l / (n * eff).
    """
    if n < 1:
        raise ValueError("need at least one connection")
    return l_single / (n * efficiency)


# ---------------------------------------------------------------- convenience
def bondwire_rl(length_m: float, diameter_m: float, material: str, return_spacing_m: float,
                temp_c: float = 25.0):
    """(R_loop, L_loop) of one VDD/VSS bond-wire pair, R counted for both wires."""
    rho = resistivity(material, temp_c)
    r = 2.0 * r_cylinder(rho, length_m, diameter_m)
    l = l_bondwire(length_m, diameter_m, return_spacing_m)
    return r, l


def bump_rl(height_m: float, diameter_m: float, pitch_m: float, material: str = "sn_ag_bump",
            temp_c: float = 25.0):
    """(R_loop, L_loop) of a power bump with its neighbouring ground bump."""
    rho = resistivity(material, temp_c)
    r = 2.0 * r_cylinder(rho, height_m, 0.9 * diameter_m)
    l = l_loop_wire_pair(max(height_m, 1e-6), diameter_m / 2.0, pitch_m)
    return r, l
