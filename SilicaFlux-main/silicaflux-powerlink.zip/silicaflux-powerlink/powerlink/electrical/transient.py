"""Load-current waveforms and time-domain droop simulation of a rail path.

Waveforms are callables of time with a ``points()`` method that returns an
equivalent SPICE PWL, so the identical stimulus is used by the internal MNA
solver and by ngspice.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from ..circuit.mna import PWL


class StepLoad:
    """I = i0 before t0, linear ramp of duration tr to i1, then i1."""

    def __init__(self, i0: float, i1: float, t0: float, tr: float):
        self.i0, self.i1, self.t0, self.tr = i0, i1, t0, max(tr, 1e-15)

    def __call__(self, t: float) -> float:
        if t <= self.t0:
            return self.i0
        if t >= self.t0 + self.tr:
            return self.i1
        return self.i0 + (self.i1 - self.i0) * (t - self.t0) / self.tr

    def points(self) -> Tuple[np.ndarray, np.ndarray]:
        return (np.array([0.0, self.t0, self.t0 + self.tr, 1.0]),
                np.array([self.i0, self.i0, self.i1, self.i1]))


class StaggeredLoad:
    """N equal sub-steps of (i1-i0)/N separated by ``interval``."""

    def __init__(self, i0: float, i1: float, t0: float, tr: float, steps: int, interval: float):
        self.parts = [StepLoad(0.0, (i1 - i0) / steps, t0 + k * interval, tr) for k in range(steps)]
        self.i0 = i0

    def __call__(self, t: float) -> float:
        return self.i0 + sum(s(t) for s in self.parts)

    def points(self) -> Tuple[np.ndarray, np.ndarray]:
        ts = sorted({0.0, 1.0} | {s.t0 for s in self.parts} | {s.t0 + s.tr for s in self.parts})
        return np.array(ts), np.array([self(t) for t in ts])


class ClockedLoad:
    """Clock-synchronous current pulses on top of a slowly varying envelope.

    i(t) = I_static(t) + I_dyn(t) * s(t mod T) where s is a triangular pulse
    of unit mean starting at the clock edge.  For a triangle of base b*T,
    peak = 2/b, so the peak-to-average ratio PAR = 2/b (b = 2/PAR <= 1).
    """

    def __init__(self, static: StepLoad, dynamic, f_clk: float, par: float, t_stop: float):
        if par < 2.0:
            raise ValueError("triangular pulse model needs peak-to-average >= 2")
        self.static, self.dynamic = static, dynamic
        self.T = 1.0 / f_clk
        self.b = 2.0 / par
        self.a = self.b / 3.0
        self.peak = 2.0 / self.b
        self.t_stop = t_stop

    def shape(self, t: float) -> float:
        x = (t % self.T) / self.T
        if x < self.a:
            return self.peak * x / self.a
        if x < self.b:
            return self.peak * (self.b - x) / (self.b - self.a)
        return 0.0

    def __call__(self, t: float) -> float:
        return self.static(t) + self.dynamic(t) * self.shape(t)

    def points(self) -> Tuple[np.ndarray, np.ndarray]:
        n = int(math.ceil(self.t_stop / self.T)) + 1
        base = np.arange(n) * self.T
        ts = np.concatenate([base, base + self.a * self.T, base + self.b * self.T])
        ts = np.unique(np.concatenate([ts[ts <= self.t_stop], [self.t_stop]]))
        return ts, np.array([self(t) for t in ts])


def build_event_wave(event: Dict, i_from: Tuple[float, float], i_to: Tuple[float, float],
                     f_clk: Optional[float] = None, par: Optional[float] = None,
                     t_stop: float = 20e-6):
    """Create the load waveform for a configured transient event.

    ``i_from`` / ``i_to`` are (static, dynamic) current pairs of the two
    workload states.  If ``f_clk`` and ``par`` are given the dynamic part is
    pulsed at the clock frequency; otherwise the waveform is the cycle average.
    """
    t0 = float(event["at_ns"]) * 1e-9
    tr = float(event.get("rise_ns", 10.0)) * 1e-9
    steps = int(event.get("stagger_steps", 1))
    interval = float(event.get("stagger_interval_ns", 0.0)) * 1e-9
    if steps > 1:
        dyn = StaggeredLoad(i_from[1], i_to[1], t0, tr, steps, interval)
        stat = StaggeredLoad(i_from[0], i_to[0], t0, tr, steps, interval)
    else:
        dyn = StepLoad(i_from[1], i_to[1], t0, tr)
        stat = StepLoad(i_from[0], i_to[0], t0, tr)
    if f_clk and par:
        return ClockedLoad(stat, dyn, f_clk, par, t_stop)
    tot = lambda t: stat(t) + dyn(t)  # noqa: E731
    ts = np.union1d(stat.points()[0], dyn.points()[0])
    ts = ts[ts <= 1.0]
    return PWL(ts, [tot(t) for t in ts])


def resonant_wave(i_lo: float, i_hi: float, f_res: float, t_start: float, cycles: int, tr_frac: float = 0.1) -> PWL:
    """Square-wave current at the PDN resonance (the 'resonant workload' worst case)."""
    T = 1.0 / f_res
    ts, vs = [0.0, t_start], [i_lo, i_lo]
    tr = tr_frac * T / 2
    for k in range(cycles):
        t = t_start + k * T
        ts += [t + tr, t + T / 2, t + T / 2 + tr, t + T]
        vs += [i_hi, i_hi, i_lo, i_lo]
    ts.append(1.0)
    vs.append(i_lo)
    return PWL(ts, vs)


@dataclass
class DroopResult:
    t: np.ndarray
    v_die: np.ndarray
    i_pins: np.ndarray
    v_pre: float
    v_min: float
    t_min: float
    droop_v: float
    first_droop_v: float
    second_droop_v: float
    third_droop_v: float
    overshoot_v: float
    v_final: float
    settle_time_s: float


def simulate_droop(path, wave, t_event: float, t_stop: float, dt_fine: float, dt_coarse: float,
                   fine_window: float = 2e-6, method: str = "trap") -> DroopResult:
    load0 = wave(0.0)
    c, n = path.circuit(load_dc=load0, load_wave=wave)
    t_fine_end = min(t_stop, t_event + fine_window)
    segs = [(t_fine_end, dt_fine)]
    if t_stop > t_fine_end:
        segs.append((t_stop, dt_coarse))
    res = c.tran(segs, probes=[n["die_load"], "I(L_pins)" if path.pins.l > 0 else n["pkg_sub"]],
                 method=method)
    t = res.t
    v = res[n["die_load"]]
    ip = res.probes.get("I(L_pins)", np.zeros_like(t))
    return analyse_droop(t, v, ip, t_event)


def analyse_droop(t: np.ndarray, v: np.ndarray, ip: np.ndarray, t_event: float) -> DroopResult:
    pre = v[t < t_event]
    v_pre = float(np.mean(pre[-max(1, len(pre) // 4):])) if len(pre) else float(v[0])
    after = t >= t_event
    k = int(np.argmin(np.where(after, v, np.inf)))

    def window_min(a, b):
        m = (t >= t_event + a) & (t < t_event + b)
        return float(v_pre - v[m].min()) if m.any() else 0.0

    first = window_min(0.0, 100e-9)
    second = window_min(100e-9, 1e-6)
    third = window_min(1e-6, t[-1] - t_event + 1e-12)
    tail = v[t >= t[-1] - 0.1 * (t[-1] - t_event)]
    v_final = float(np.mean(tail))
    over = float(max(0.0, np.max(np.where(after, v, -np.inf)) - max(v_pre, v_final)))
    tol = max(1e-3 * abs(v_pre), 0.5e-3)       # settle to within 0.1 % (>= 0.5 mV)
    outside = np.where(after & (np.abs(v - v_final) > tol))[0]
    settle = float(t[outside[-1]] - t_event) if len(outside) else 0.0
    return DroopResult(t, v, ip, v_pre, float(v[k]), float(t[k]), float(v_pre - v[k]), first, second,
                       third, over, v_final, settle)
