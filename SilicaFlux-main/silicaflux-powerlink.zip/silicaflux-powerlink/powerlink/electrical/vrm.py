"""PCB voltage regulator models.

Buck converter (peak-current-mode, averaged, linearised)
---------------------------------------------------------
Below roughly half the switching frequency a peak-current-mode buck behaves
as a transconductance power stage: the averaged inductor current follows
the control voltage, i_L = G_ps * v_c, with the current-loop dynamics
approximated by a single pole at ``f_ci`` (default f_sw/2, the sampling
limit).  The voltage loop is closed by a transconductance error amplifier
(gm, finite output resistance R_o) with a type-II network
(R_c + C_c in series, C_p in parallel).  Everything is linear, so the same
netlist serves DC, AC (closed-loop output impedance) and transient
analyses, and it exports unchanged to SPICE for cross-checking.

What it does *not* capture (documented limits): inductor-current slew
limiting (checked separately by :meth:`BuckVRM.slew_check`), duty-cycle
saturation, current limit, discontinuous conduction, sub-harmonic
instability (slope compensation is assumed adequate), and switching ripple
(computed analytically by :meth:`BuckVRM.ripple`).

LDO
---
Modelled as an ideal source behind its closed-loop output impedance
(see :class:`LDO`), with a specified PSRR used to attenuate upstream ripple.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Tuple

import numpy as np

from ..circuit.mna import Circuit
from ..uncertainty import nom, parse_value
from .decap import CapBank


@dataclass
class BuckVRM:
    name: str
    v_in: float
    v_out: float
    f_sw: float
    l_ind: float
    dcr: float
    i_max: float
    out_banks: List[CapBank]
    f_c_target: float
    gm_ea: float = 1e-3
    r_o_ea: float = 1e7
    v_ref: float = 0.6
    f_ci: Optional[float] = None
    k_zero: float = 4.0            # compensation zero at f_c / k_zero
    k_pole: float = 8.0            # high-frequency pole at k_pole * f_c (capped at f_sw/2)
    v_ctrl_span: float = 1.0       # control voltage for full-scale current (sets G_ps)
    setpoint_accuracy: float = 0.01
    sense: str = "local"
    phases: int = 1
    # filled by design_compensation()
    rc: float = 0.0
    cc: float = 0.0
    cp: float = 0.0

    @property
    def h_sense(self) -> float:
        return self.v_ref / self.v_out

    @property
    def g_ps(self) -> float:
        return self.i_max / self.v_ctrl_span

    @property
    def f_current_loop(self) -> float:
        return self.f_ci if self.f_ci else self.f_sw / 2.0

    # --------------------------------------------------------------- design
    def design_compensation(self, c_loop_total: float) -> None:
        """Choose R_c, C_c, C_p for crossover ``f_c_target`` on a capacitive plant.

        At f_c the plant |G_ps / (j w C)| times the mid-band compensator gain
        gm * H * R_c must equal one:  R_c = 2 pi f_c C / (gm H G_ps).
        """
        fc = self.f_c_target
        self.rc = 2 * math.pi * fc * c_loop_total / (self.gm_ea * self.h_sense * self.g_ps)
        self.cc = 1.0 / (2 * math.pi * self.rc * fc / self.k_zero)
        fp = min(self.k_pole * fc, self.f_sw / 2.0)
        self.cp = 1.0 / (2 * math.pi * self.rc * fp)

    def refine_compensation(self, loop_fn, iterations: int = 4) -> None:
        """Rescale R_c (keeping zero/pole frequencies) so that the numerically
        computed crossover equals the target.  ``loop_fn(vrm)`` returns
        (f, T) for the complete circuit."""
        for _ in range(iterations):
            f, T = loop_fn(self)
            mag = np.abs(T)
            k = int(np.argmin(np.abs(np.log(f / self.f_c_target))))
            g = mag[k]
            if abs(math.log(g)) < 0.02:
                break
            fz = 1.0 / (2 * math.pi * self.rc * self.cc)
            fp = 1.0 / (2 * math.pi * self.rc * self.cp)
            self.rc /= g
            self.cc = 1.0 / (2 * math.pi * self.rc * fz)
            self.cp = 1.0 / (2 * math.pi * self.rc * fp)

    # ---------------------------------------------------------------- build
    def build(self, c: Circuit, out: str, sense: Optional[str] = None, prefix: Optional[str] = None,
              open_loop: bool = False) -> Dict[str, str]:
        """Insert the averaged regulator into circuit ``c`` driving node ``out``.

        Output capacitors are *not* added here (they are part of the PDN
        ladder so that their location is explicit).  If ``open_loop`` the
        power stage is driven from node ``<p>x`` (for loop-gain measurement).
        """
        p = prefix or f"{self.name}_"
        sense = sense or out
        ref, fb, comp, mid, ci_in, ci, x = (p + s for s in ("ref", "fb", "comp", "mid", "ciin", "ci", "x"))
        c.add_V(ref, "0", dc=self.v_ref, name=p + "Vref")
        c.add_E(fb, "0", sense, "0", self.h_sense, name=p + "Esense")
        c.add_G("0", comp, ref, fb, self.gm_ea)
        c.add_R(comp, "0", self.r_o_ea)
        c.add_R(comp, mid, self.rc)
        c.add_C(mid, "0", self.cc)
        c.add_C(comp, "0", self.cp)
        ctrl = comp
        if open_loop:
            c.add_V(x, "0", dc=0.0, ac=1.0, name=p + "Vinj")
            ctrl = x
        # current-loop pole
        c.add_E(ci_in, "0", ctrl, "0", 1.0, name=p + "Eci")
        r_ci = 1.0e3
        c.add_R(ci_in, ci, r_ci)
        c.add_C(ci, "0", 1.0 / (2 * math.pi * self.f_current_loop * r_ci))
        # power stage: averaged inductor current injected into the output node
        c.add_G("0", out, ci, "0", self.g_ps)
        return {"ref": ref, "fb": fb, "comp": comp, "ctrl": ctrl, "out": out}

    # -------------------------------------------------------------- analytic
    @property
    def duty(self) -> float:
        return self.v_out / self.v_in

    def ripple(self, esr_eff: Optional[float] = None, esl_eff: Optional[float] = None) -> Dict[str, float]:
        """Steady-state switching ripple at the regulator output (CCM, ideal switches).

        dI_L = (Vin - Vout) D / (L fsw);  dV = dI_L / (8 fsw C) + dI_L ESR + ESL dI/dt.
        For N interleaved phases the ripple-current cancellation factor is
        not modelled (conservative): the single-phase result is reported.
        """
        c_tot = sum(b.c_total for b in self.out_banks)
        if esr_eff is None:
            g = sum(b.count / b.part.esr_ohm for b in self.out_banks)
            esr_eff = 1.0 / g
        if esl_eff is None:
            g = sum(b.count / b.part.l_total for b in self.out_banks)
            esl_eff = 1.0 / g
        di = (self.v_in - self.v_out) * self.duty / (self.l_ind * self.f_sw)
        dv_c = di / (8 * self.f_sw * c_tot)
        dv_esr = di * esr_eff
        dv_esl = esl_eff * (self.v_in - self.v_out) / self.l_ind
        return {"ripple_current_pp_a": di, "dv_cap_pp_v": dv_c, "dv_esr_pp_v": dv_esr,
                "dv_esl_spike_v": dv_esl, "ripple_pp_v": dv_c + dv_esr,
                "ripple_pp_incl_esl_v": dv_c + dv_esr + dv_esl, "c_out_f": c_tot}

    def slew_check(self, delta_i: float) -> Dict[str, float]:
        """Minimum time for the inductor current to slew by ``delta_i``.

        Rising: dI/dt = (Vin - Vout)/L per phase; falling: Vout/L.
        """
        up = (self.v_in - self.v_out) / self.l_ind * self.phases
        dn = self.v_out / self.l_ind * self.phases
        return {"di_dt_up_a_per_s": up, "di_dt_down_a_per_s": dn,
                "t_slew_up_s": delta_i / up, "t_slew_down_s": delta_i / dn,
                "loop_response_time_s": 1.0 / (2 * math.pi * self.f_c_target)}

    def efficiency_estimate(self, i_load: float, q_g: float = 5e-9, r_on: float = 0.02,
                            t_sw: float = 5e-9) -> float:
        """First-order efficiency: conduction + switching + gate charge + DCR losses."""
        p_out = self.v_out * i_load
        i_rms2 = i_load ** 2 + (self.ripple()["ripple_current_pp_a"] ** 2) / 12.0
        p_cond = i_rms2 * (r_on + self.dcr)
        p_sw = 0.5 * self.v_in * i_load * t_sw * 2 * self.f_sw
        p_gate = q_g * 5.0 * self.f_sw * 2
        return p_out / (p_out + p_cond + p_sw + p_gate) if p_out > 0 else 0.0


@dataclass
class LDO:
    """Linear regulator: closed-loop output impedance Z = R_out + (s L || R_ol).

    With a dominant-pole loop of DC gain A0 and gain-bandwidth f_bw the
    closed-loop impedance is R_ol/(1+T(s)) ~= R_out + s R_ol/(2 pi f_bw) up
    to f_bw, levelling off at the open-loop pass-device resistance R_ol
    beyond it.  L_out = R_ol / (2 pi f_bw).
    """

    name: str
    v_in: float
    v_out: float
    r_out: float              # closed-loop output resistance at low frequency
    r_ol: float               # open-loop output resistance of the pass device
    bandwidth_hz: float       # unity-gain bandwidth of the regulation loop
    psrr_db_at_fsw: float
    dropout_v: float
    i_max: float
    setpoint_accuracy: float = 0.01
    out_banks: List[CapBank] = field(default_factory=list)

    @property
    def l_out(self) -> float:
        return self.r_ol / (2 * math.pi * self.bandwidth_hz)

    def z_out(self, f: np.ndarray) -> np.ndarray:
        jwl = 1j * 2 * np.pi * np.asarray(f) * self.l_out
        return self.r_out + jwl * self.r_ol / (jwl + self.r_ol)

    def build(self, c: Circuit, out: str, prefix: Optional[str] = None, **_: Any) -> Dict[str, str]:
        p = prefix or f"{self.name}_"
        src, mid = p + "src", p + "mid"
        c.add_V(src, "0", dc=self.v_out, name=p + "V")
        c.add_R(src, mid, self.r_out)
        c.add_L(mid, out, self.l_out, name=p + "Lout")
        c.add_R(mid, out, self.r_ol)
        return {"out": out}

    def ripple(self, upstream_ripple_pp: float = 0.0) -> Dict[str, float]:
        att = 10 ** (-self.psrr_db_at_fsw / 20.0)
        return {"ripple_pp_v": upstream_ripple_pp * att, "psrr_db": self.psrr_db_at_fsw}

    def headroom_ok(self) -> bool:
        return self.v_in - self.v_out >= self.dropout_v


def regulator_from_config(name: str, cfg: Mapping[str, Any], v_out: float,
                          out_banks: List[CapBank], use: str = "nom"):
    def g(key, default=None, adverse_high=True):
        if key not in cfg:
            return default
        uv = parse_value(cfg[key])
        if use == "nom":
            return uv.nom
        return uv.max if (use == "worst") == adverse_high else uv.min

    topo = cfg["topology"]
    if topo == "buck_peak_current_mode":
        return BuckVRM(name=name, v_in=g("v_in"), v_out=v_out, f_sw=g("f_sw_hz", adverse_high=False),
                       l_ind=g("inductor_h"), dcr=g("inductor_dcr_ohm", 0.01), i_max=g("i_max_a"),
                       out_banks=out_banks, f_c_target=g("crossover_hz", adverse_high=False),
                       gm_ea=g("ea_gm_s", 1e-3), r_o_ea=g("ea_ro_ohm", 1e7), v_ref=g("v_ref", 0.6),
                       f_ci=g("current_loop_pole_hz"), setpoint_accuracy=g("setpoint_accuracy", 0.01),
                       sense=str(cfg.get("sense", "local")), phases=int(nom(cfg.get("phases", 1))))
    if topo == "ldo":
        return LDO(name=name, v_in=g("v_in"), v_out=v_out, r_out=g("r_out_ohm"),
                   r_ol=g("r_ol_ohm", 1.0),
                   bandwidth_hz=g("bandwidth_hz", adverse_high=False),
                   psrr_db_at_fsw=g("psrr_db_at_fsw", adverse_high=False),
                   dropout_v=g("dropout_v"), i_max=g("i_max_a"),
                   setpoint_accuracy=g("setpoint_accuracy", 0.01), out_banks=out_banks)
    raise ValueError(f"unknown regulator topology '{topo}'")
