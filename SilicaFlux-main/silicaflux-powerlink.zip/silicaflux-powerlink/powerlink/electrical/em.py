"""Electromigration screening.

DC electromigration lifetime follows Black's equation,
    MTTF = A * J^-n * exp(Ea / (k T)),
so a current-density limit J_ref specified at T_ref scales to temperature T
for equal lifetime as
    J_lim(T) = J_ref * exp( Ea/(n k) * (1/T - 1/T_ref) ).
Ea and n are technology-specific; the defaults (Cu, Ea = 0.9 eV, n = 2)
are literature-typical ASSUMPTIONS.  Foundry EM rules (per-layer, per-width,
DC/RMS/peak, with via-count and Blech-length effects) supersede this
screening calculation.
"""
from __future__ import annotations

import math
from typing import Dict, List, Mapping

from ..constants import K_BOLTZMANN_EV, T0_K

EA_EV_DEFAULT = 0.9
N_DEFAULT = 2.0
T_REF_C = 105.0


def em_limit_at(j_ref: float, temp_c: float, t_ref_c: float = T_REF_C, ea_ev: float = EA_EV_DEFAULT,
                n: float = N_DEFAULT) -> float:
    t = temp_c + T0_K
    tr = t_ref_c + T0_K
    return j_ref * math.exp(ea_ev / (n * K_BOLTZMANN_EV) * (1.0 / t - 1.0 / tr))


def lifetime_ratio(j: float, j_ref: float, temp_c: float, t_ref_c: float = T_REF_C,
                   ea_ev: float = EA_EV_DEFAULT, n: float = N_DEFAULT) -> float:
    """MTTF(j, T) / MTTF(j_ref, T_ref).  >1 means longer life than the rule point."""
    if j <= 0:
        return float("inf")
    t = temp_c + T0_K
    tr = t_ref_c + T0_K
    return (j_ref / j) ** n * math.exp(ea_ev / K_BOLTZMANN_EV * (1.0 / t - 1.0 / tr))


def em_summary(ir_result, temp_c: float) -> List[Dict[str, float]]:
    """Per (net, layer) worst current density vs limit, plus vias and connections."""
    gm = ir_result.grid
    rows = []
    for (net, layer), ratio in ir_result.em_ratio.items():
        jmax = float(ir_result.current_density[(net, layer)].max())
        lim = em_limit_at(gm.layers[layer].em_limit_ma_um, temp_c)
        rows.append({"item": f"{net}/{layer} strap", "worst": jmax, "limit": lim, "unit": "mA/um",
                     "ratio": ratio})
    from ..uncertainty import nom
    vlim = gm.project.technology.get("via_em_ma_per_cut_105c", 0.1)
    levels = {(vs.net, vs.lower, vs.upper): vs.levels for vs in gm.vias}
    for (net, lo, hi), i_cut in ir_result.via_current_per_cut_ma.items():
        if isinstance(vlim, dict):          # per via class; a stack is limited by its weakest level
            lim0 = min(nom(vlim[lv]) for lv in levels.get((net, lo, hi), ("low",)))
        else:
            lim0 = nom(vlim)
        lim = em_limit_at(lim0, temp_c)
        rows.append({"item": f"{net} via {lo}-{hi}", "worst": i_cut, "limit": lim, "unit": "mA/cut",
                     "ratio": i_cut / lim})
    by_net: Dict[str, List[Dict]] = {}
    for s in ir_result.supply_currents:
        by_net.setdefault(s["net"], []).append(s)
    for net, lst in by_net.items():
        w = max(lst, key=lambda d: d["ratio"])
        rows.append({"item": f"{net} {w['kind']} (worst of {len(lst)})", "worst": w["current_a"] * 1e3,
                     "limit": w["i_max_a"] * 1e3, "unit": "mA", "ratio": w["ratio"]})
    return rows
