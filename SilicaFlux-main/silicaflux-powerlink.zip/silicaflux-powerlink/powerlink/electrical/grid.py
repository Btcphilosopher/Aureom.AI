"""On-die power grid: multi-layer homogenised resistive / RC mesh.

Model
-----
The core is divided into nx x ny cells.  Every modelled metal layer of every
net has one node per cell (where the net/layer exists).  A layer made of
parallel straps of width w at same-net pitch p with sheet resistance Rs has
an *effective* sheet conductance sigma = w / (p Rs) along its routing
direction and none across it; the conductance between neighbouring cells is
sigma * (cross-section length) / (cell pitch).  Adjacent modelled layers are
joined in every cell by via stacks: count = strap intersections in the cell,
R_stack = sum over via levels of R_cut / cuts.  Core rings add boundary
conductance on their layers.  Supply connections (bond-wire pads on the
ring, or bumps over the core) tie grid nodes to package nodes; loads draw
block currents from the lowest available layer (std-cell followpins) or
from the macro pin layer.

Validity: homogenisation is accurate when the cell pitch is comparable to
or larger than the strap pitch of the layers it averages; it does not
resolve current crowding at individual vias or rail ends.  It is a
planning-level complement to, not a replacement for, signoff IR analysis
(RedHawk-SC / Voltus) on the extracted layout.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from ..circuit.mna import Circuit
from ..config import ConfigError, Project
from ..uncertainty import nom, parse_value


# ---------------------------------------------------------------- data classes
@dataclass
class LayerModel:
    name: str
    direction: str
    width_um: float
    pitch_um: float
    rs: float                 # ohm/sq at analysis temperature
    sigma: float              # effective sheet conductance (S per square) along direction
    em_limit_ma_um: float     # DC EM limit per um of width at 105 C
    role: str = "strap"


@dataclass
class EdgeSet:
    net: str
    layer: str
    direction: str
    n1: np.ndarray
    n2: np.ndarray
    g: np.ndarray
    cell_j: np.ndarray        # row index of the first cell
    cell_i: np.ndarray        # column index
    width_per_edge_um: np.ndarray   # total strap width in the edge cross-section


@dataclass
class ViaSet:
    net: str
    lower: str
    upper: str
    n1: np.ndarray
    n2: np.ndarray
    g: np.ndarray
    count: np.ndarray          # via stacks per cell
    cuts: int
    cell_j: np.ndarray
    cell_i: np.ndarray
    levels: tuple = ("low",)


@dataclass
class SupplyConn:
    net: str
    name: str
    node: int
    r: float
    l: float
    x_um: float
    y_um: float
    kind: str
    i_max_a: float


@dataclass
class GridModel:
    project: Project
    nx: int
    ny: int
    dx: float
    dy: float
    width: float
    height: float
    nets: Dict[str, Dict[str, Any]]
    layers: Dict[str, LayerModel]
    node_map: Dict[Tuple[str, str], np.ndarray]     # (net, layer) -> (ny, nx) node index or 0 (absent)
    edges: List[EdgeSet]
    vias: List[ViaSet]
    supplies: List[SupplyConn]
    circuit: Circuit
    load_layer_nodes: Dict[str, np.ndarray]         # net -> (ny, nx) node used for loads
    pkg_nodes: Dict[str, int]
    notes: List[str] = field(default_factory=list)

    def xc(self) -> np.ndarray:
        return (np.arange(self.nx) + 0.5) * self.dx

    def yc(self) -> np.ndarray:
        return (np.arange(self.ny) + 0.5) * self.dy


@dataclass
class IRResult:
    grid: GridModel
    v_nodes: np.ndarray                       # full solution vector (node voltages first)
    eff_supply: Dict[str, np.ndarray]         # power net -> (ny, nx) V_p - V_g at load layer (nan absent)
    ir_drop: Dict[str, np.ndarray]            # power net -> (ny, nx) V_nom - eff
    load_map: Dict[str, np.ndarray]           # power net -> (ny, nx) current (A)
    worst_drop_v: Dict[str, float]
    mean_drop_v: Dict[str, float]
    drop_breakdown: Dict[str, Dict[str, float]]
    r_grid_eff: Dict[str, float]
    current_density: Dict[Tuple[str, str], np.ndarray]   # (net, layer) -> (ny,nx) mA/um
    em_ratio: Dict[Tuple[str, str], float]
    via_current_per_cut_ma: Dict[Tuple[str, str, str], float]
    supply_currents: List[Dict[str, Any]]


# ------------------------------------------------------------------ helpers
def _tcr_scale(p: Project, temp_c: float) -> float:
    tcr = nom(p.technology.get("metal_tcr_per_c", 0.0035))
    t_ref = nom(p.technology.get("reference_temp_c", 25.0))
    return 1.0 + tcr * (temp_c - t_ref)


def rect_weights(rect: Sequence[float], nx: int, ny: int, dx: float, dy: float) -> np.ndarray:
    """Fraction of the rectangle's area falling into each cell (sums to 1 inside the grid)."""
    x0, y0, x1, y1 = rect
    xe = np.arange(nx + 1) * dx
    ye = np.arange(ny + 1) * dy
    ox = np.clip(np.minimum(xe[1:], x1) - np.maximum(xe[:-1], x0), 0, None)
    oy = np.clip(np.minimum(ye[1:], y1) - np.maximum(ye[:-1], y0), 0, None)
    w = np.outer(oy, ox)
    tot = w.sum()
    return w / tot if tot > 0 else w


def rect_mask(rect: Sequence[float], nx: int, ny: int, dx: float, dy: float) -> np.ndarray:
    """Cells whose centre lies inside the rectangle."""
    x0, y0, x1, y1 = rect
    xc = (np.arange(nx) + 0.5) * dx
    yc = (np.arange(ny) + 0.5) * dy
    return np.outer((yc >= y0) & (yc <= y1), (xc >= x0) & (xc <= x1))


def via_stack_resistance(p: Project, spec: Mapping[str, Any], scale: float = 1.0) -> float:
    cut = p.technology["via_cut_ohm"]
    cuts = int(spec.get("cuts_per_level", 1))
    return sum(nom(cut[lv]) / cuts for lv in spec["levels"]) * scale


def layer_models(p: Project, temp_c: float, scales: Optional[Mapping[str, float]] = None) -> Dict[str, LayerModel]:
    scales = scales or {}
    out = {}
    tscale = _tcr_scale(p, temp_c)
    stack = p.technology["metal_stack"]
    for L in p.pdn["layers"]:
        name = L["name"]
        if name not in stack:
            raise ConfigError(f"PDN layer {name} not in technology metal stack")
        rs = nom(stack[name]["rs_ohm_sq"]) * tscale * scales.get(f"rs_{name}", scales.get("rs_all", 1.0))
        w, pitch = float(L["width_um"]), float(L["pitch_um"])
        if w <= 0 or pitch <= w:
            raise ConfigError(f"layer {name}: require 0 < width < pitch")
        if w < nom(stack[name].get("min_width_um", 0.0)):
            raise ConfigError(f"layer {name}: width {w} below technology minimum")
        out[name] = LayerModel(name, L["direction"], w, pitch, rs, w / (pitch * rs),
                               nom(stack[name].get("em_dc_ma_per_um_105c", 1.0)), L.get("role", "strap"))
    return out


# ------------------------------------------------------------------ builder
def build_grid(p: Project, resolution_um: Optional[float] = None, temp_c: Optional[float] = None,
               scales: Optional[Mapping[str, float]] = None, package: Optional[str] = None,
               rail_paths: Optional[Mapping[str, Any]] = None, dynamic: bool = False) -> GridModel:
    """Build the multi-layer grid network for all gridded nets.

    ``rail_paths`` (rail -> RailPath) supplies package/PCB parasitics.  For
    a DC build the power net's package node is tied to an ideal source at the
    regulator setpoint through the remaining series resistance (planes,
    pins, substrate); for a dynamic build, use :func:`attach_dynamic`.
    """
    scales = dict(scales or {})
    pdn = p.pdn
    ana = pdn.get("analysis", {})
    res = float(resolution_um or ana.get("static_resolution_um", 20.0))
    temp_c = float(temp_c if temp_c is not None else ana.get("metal_temperature_c", 85.0))
    W = nom(p.core["width_mm"]) * 1e3
    H = nom(p.core["height_mm"]) * 1e3
    nx = max(4, int(round(W / res)))
    ny = max(4, int(round(H / res)))
    dx, dy = W / nx, H / ny
    layers = layer_models(p, temp_c, scales)
    tscale = _tcr_scale(p, temp_c)
    c = Circuit(f"{p.name} on-die grid")
    node_map: Dict[Tuple[str, str], np.ndarray] = {}
    edges: List[EdgeSet] = []
    vias: List[ViaSet] = []
    regions = pdn["regions"]
    macros = [b for b in p.blocks if b["kind"] == "sram"]
    mcfg = pdn.get("macros", {})
    halo = float(mcfg.get("halo_um", 0.0))
    blocked = set(mcfg.get("blocked_layers", []))
    notes: List[str] = []
    order = [L["name"] for L in pdn["layers"]]

    for net, ncfg in pdn["nets"].items():
        reg_names = ncfg.get("region", "core")
        reg_names = reg_names if isinstance(reg_names, list) else [reg_names]
        mask = np.zeros((ny, nx), dtype=bool)
        for rn in reg_names:
            mask |= rect_mask(regions[rn], nx, ny, dx, dy)
        for rn in ncfg.get("exclude", []):
            mask &= ~rect_mask(regions[rn], nx, ny, dx, dy)
        net_layers = [l for l in order if l in ncfg.get("layers", order)]
        for lname in net_layers:
            lm = mask.copy()
            if lname in blocked:
                for m in macros:
                    x0, y0, x1, y1 = m["rect_um"]
                    lm &= ~rect_mask([x0 - halo, y0 - halo, x1 + halo, y1 + halo], nx, ny, dx, dy)
            idx = np.zeros((ny, nx), dtype=int)
            cnt = int(lm.sum())
            idx[lm] = c.new_nodes(cnt)
            node_map[(net, lname)] = idx
            L = layers[lname]
            if L.direction == "H":
                a, b = idx[:, :-1], idx[:, 1:]
                g = L.sigma * dy / dx
                width = dy / L.pitch_um * L.width_um
            else:
                a, b = idx[:-1, :], idx[1:, :]
                g = L.sigma * dx / dy
                width = dx / L.pitch_um * L.width_um
            ok = (a > 0) & (b > 0)
            jj, ii = np.nonzero(ok)
            n1, n2 = a[ok], b[ok]
            gv = np.full(n1.shape, g)
            c.add_R_bulk(n1, n2, 1.0 / gv)
            edges.append(EdgeSet(net, lname, L.direction, n1, n2, gv, jj, ii, np.full(n1.shape, width)))
        # vias between consecutive net layers
        vspecs = {(v["from"], v["to"]): v for v in pdn.get("vias", [])}
        for lo, hi in zip(net_layers[:-1], net_layers[1:]):
            spec = vspecs.get((lo, hi))
            if spec is None:
                raise ConfigError(f"no via definition between {lo} and {hi}")
            Llo, Lhi = layers[lo], layers[hi]
            if Llo.direction == Lhi.direction:
                raise ConfigError(f"via {lo}->{hi}: layers share direction; intersections undefined")
            p_h = Llo.pitch_um if Llo.direction == "H" else Lhi.pitch_um
            p_v = Llo.pitch_um if Llo.direction == "V" else Lhi.pitch_um
            count = (dx / p_v) * (dy / p_h)
            r_stack = via_stack_resistance(p, spec, tscale * scales.get("via_scale", 1.0))
            a, b = node_map[(net, lo)], node_map[(net, hi)]
            ok = (a > 0) & (b > 0)
            jj, ii = np.nonzero(ok)
            gv = np.full(int(ok.sum()), count / r_stack)
            c.add_R_bulk(a[ok], b[ok], 1.0 / gv)
            vias.append(ViaSet(net, lo, hi, a[ok], b[ok], gv, np.full(gv.shape, count),
                               int(spec.get("cuts_per_level", 1)), jj, ii, tuple(spec["levels"])))
            if count < 1.0:
                notes.append(f"{net}: {lo}->{hi} has {count:.2f} intersections per cell; "
                             f"cell size below strap pitch reduces homogenisation accuracy")
    # rings -----------------------------------------------------------------------
    for ring in pdn.get("rings", []):
        for net in ring["nets"]:
            for lname in ring["layers"]:
                if (net, lname) not in node_map:
                    continue
                L = layers[lname]
                idx = node_map[(net, lname)]
                wr = float(ring["width_um"])
                if L.direction == "H":
                    for row in (0, ny - 1):
                        a, b = idx[row, :-1], idx[row, 1:]
                        ok = (a > 0) & (b > 0)
                        c.add_R_bulk(a[ok], b[ok], np.full(int(ok.sum()), L.rs * dx / wr))
                else:
                    for col in (0, nx - 1):
                        a, b = idx[:-1, col], idx[1:, col]
                        ok = (a > 0) & (b > 0)
                        c.add_R_bulk(a[ok], b[ok], np.full(int(ok.sum()), L.rs * dy / wr))
        # strap-end via arrays where straps terminate on the ring (between ring layers)
        rl = [l for l in order if l in ring["layers"]]
        if len(rl) == 2:
            lo, hi = rl
            spec = {(v["from"], v["to"]): v for v in pdn.get("vias", [])}.get((lo, hi))
            if spec is not None:
                cut = p.technology["via_cut_ohm"]
                cuts = int(ring.get("via_cuts_per_strap_end", 48))
                r_end = sum(nom(cut[lv]) for lv in spec["levels"]) / cuts * tscale
                p_v = layers[lo].pitch_um if layers[lo].direction == "V" else layers[hi].pitch_um
                p_h = layers[lo].pitch_um if layers[lo].direction == "H" else layers[hi].pitch_um
                for net in ring["nets"]:
                    if (net, lo) not in node_map or (net, hi) not in node_map:
                        continue
                    a, b = node_map[(net, lo)], node_map[(net, hi)]
                    bnd = np.zeros((ny, nx), dtype=bool)
                    cnt = np.zeros((ny, nx))
                    bnd[[0, ny - 1], :] = True
                    cnt[[0, ny - 1], :] += dx / p_v
                    bnd[:, [0, nx - 1]] = True
                    cnt[:, [0, nx - 1]] += dy / p_h
                    ok = bnd & (a > 0) & (b > 0)
                    jj, ii = np.nonzero(ok)
                    gv = cnt[ok] / r_end
                    c.add_R_bulk(a[ok], b[ok], 1.0 / gv)
                    vias.append(ViaSet(net, lo, hi + "(ring)", a[ok], b[ok], gv, cnt[ok], cuts, jj, ii,
                                       tuple(spec["levels"])))
    # load-layer node maps -----------------------------------------------------------
    load_nodes: Dict[str, np.ndarray] = {}
    for net in pdn["nets"]:
        net_layers = [l for l in order if (net, l) in node_map]
        base = np.zeros((ny, nx), dtype=int)
        for lname in net_layers:          # lowest layer present wins
            m = (base == 0) & (node_map[(net, lname)] > 0)
            base[m] = node_map[(net, lname)][m]
        load_nodes[net] = base
    gm = GridModel(p, nx, ny, dx, dy, W, H, pdn["nets"], layers, node_map, edges, vias, [], c,
                   load_nodes, {}, notes)
    _add_supplies(gm, package, rail_paths, scales, temp_c, dynamic)
    return gm


def _net_ground(p: Project, power_net: str) -> str:
    rail = p.pdn["nets"][power_net]["rail"]
    return p.rails[rail].get("ground", "VSS")


def _supply_sites(gm: GridModel, package: Mapping[str, Any]) -> Dict[str, List[Tuple[float, float, int, str]]]:
    """Positions (x, y, node, kind) of supply connections for each net."""
    p = gm.project
    sup = p.pdn.get("supply", {})
    out: Dict[str, List[Tuple[float, float, int, str]]] = {n: [] for n in p.pdn["nets"]}
    order = [L["name"] for L in p.pdn["layers"]]
    if package["die_connection"]["type"] == "bondwire":
        pps = sup["wire_bond"]["pads_per_side"]
        ring_layers = {}
        for ring in p.pdn.get("rings", []):
            for lname in ring["layers"]:
                ring_layers[gm.layers[lname].direction] = lname
        for net, n_side in pps.items():
            if net not in out:
                continue
            # interleave nets along each side: offset by net index
            nets = list(pps.keys())
            k_net = nets.index(net)
            for side in ("S", "N", "W", "E"):
                horiz = side in ("S", "N")
                lname = ring_layers.get("H" if horiz else "V", order[-1])
                idx = gm.node_map[(net, lname)]
                n_tot = n_side * len(nets)
                for k in range(n_side):
                    slot = k * len(nets) + k_net
                    frac = (slot + 0.5) / n_tot
                    if horiz:
                        i = min(gm.nx - 1, int(frac * gm.nx))
                        j = 0 if side == "S" else gm.ny - 1
                    else:
                        j = min(gm.ny - 1, int(frac * gm.ny))
                        i = 0 if side == "W" else gm.nx - 1
                    node = int(idx[j, i])
                    if node == 0:
                        continue
                    out[net].append(((i + 0.5) * gm.dx, (j + 0.5) * gm.dy, node, f"pad_{side}{k}"))
    else:
        pitch = nom(package["die_connection"]["pitch_um"])
        frac = nom(package["die_connection"].get("power_fraction_core", 0.6))
        top = order[-1]
        power_nets = [n for n, cfg in p.pdn["nets"].items() if cfg["type"] == "power"]
        ground_nets = [n for n, cfg in p.pdn["nets"].items() if cfg["type"] == "ground"]
        nxb = int(gm.width // pitch)
        nyb = int(gm.height // pitch)
        x_off = (gm.width - (nxb - 1) * pitch) / 2
        y_off = (gm.height - (nyb - 1) * pitch) / 2
        keep_every = max(1, int(round(1.0 / max(1e-3, 1.0 - frac)))) if frac < 1 else 10 ** 9
        site = 0
        for jb in range(nyb):
            for ib in range(nxb):
                x = x_off + ib * pitch
                y = y_off + jb * pitch
                site += 1
                if frac < 1.0 and site % keep_every == 0:
                    continue        # signal bump site
                i = min(gm.nx - 1, int(x / gm.dx))
                j = min(gm.ny - 1, int(y / gm.dy))
                if (ib + jb) % 2 == 0:
                    cands = power_nets
                else:
                    cands = ground_nets
                for net in cands:
                    key = (net, top) if (net, top) in gm.node_map else None
                    if key is None:
                        continue
                    node = int(gm.node_map[key][j, i])
                    if node > 0:
                        out[net].append((x, y, node, f"bump_{ib}_{jb}"))
                        break
    return out


def _ensure_island_supplies(gm: GridModel, sites: Dict[str, List[Tuple[float, float, int, str]]]) -> None:
    """Every electrically separate island of a net must have at least one supply
    connection; otherwise it would float (on gmin) in the solve.  Coarse grids can
    lose all bump sites of a small island to an overlapping net.  Missing islands get
    one connection at the top-layer node nearest their centroid, and a note."""
    from scipy.sparse.csgraph import connected_components
    c = gm.circuit
    a = c._assemble()
    nn = c.n_nodes - 1
    Gn = a["G"][:nn, :nn]
    Gn = Gn - __import__("scipy.sparse", fromlist=["diags"]).diags(Gn.diagonal())
    _, lab = connected_components(abs(Gn) > 0, directed=False)
    order = [L["name"] for L in gm.project.pdn["layers"]]
    for net, lst in sites.items():
        layers = [l for l in order if (net, l) in gm.node_map]
        if not layers:
            continue
        top = gm.node_map[(net, layers[-1])]
        nodes = np.concatenate([gm.node_map[(net, l)][gm.node_map[(net, l)] > 0] for l in layers])
        comps = set(lab[nodes - 1])
        fed = {lab[n - 1] for (_, _, n, _) in lst}
        for comp in comps - fed:
            jj, ii = np.nonzero((top > 0) & (lab[np.maximum(top, 1) - 1] == comp))
            if len(jj) == 0:
                continue
            jc, ic = jj.mean(), ii.mean()
            k = int(np.argmin((jj - jc) ** 2 + (ii - ic) ** 2))
            j, i = int(jj[k]), int(ii[k])
            lst.append(((i + 0.5) * gm.dx, (j + 0.5) * gm.dy, int(top[j, i]), f"island_{comp}"))
            gm.notes.append(f"{net}: island without supply at this resolution - one connection added at "
                            f"({(i + 0.5) * gm.dx:.0f}, {(j + 0.5) * gm.dy:.0f}) um")


def _add_supplies(gm: GridModel, package: Optional[str], rail_paths, scales, temp_c, dynamic) -> None:
    from ..constants import resistivity
    from . import geometry as geo
    p = gm.project
    pkg = p.package(package)
    sites = _supply_sites(gm, pkg)
    _ensure_island_supplies(gm, sites)
    dc = pkg["die_connection"]
    sup = p.pdn.get("supply", {})
    eff = nom(pkg.get("parallel_efficiency", 0.75))
    c = gm.circuit
    for net, lst in sites.items():
        if not lst:
            raise ConfigError(f"net {net} has no supply connections in package {pkg['key']}")
        ncfg = p.pdn["nets"][net]
        is_power = ncfg["type"] == "power"
        n_conn = len(lst)
        if dc["type"] == "bondwire":
            ep = pkg.get("exposed_pad", False) and not is_power
            length = nom(dc.get("downbond_length_mm" if ep else "length_mm", dc["length_mm"])) * 1e-3
            d = nom(dc["diameter_um"]) * 1e-6
            r_one = geo.r_cylinder(resistivity(dc.get("material", "gold"), temp_c), length, d)
            r_one += nom(sup["wire_bond"].get("pad_to_ring_ohm", 0.05))
            l_one = 0.5 * geo.l_bondwire(length, d, nom(dc["return_spacing_um"]) * 1e-6) / eff
            imax = nom(dc["i_max_a"])
        else:
            r_one = 0.5 * nom(dc["r_ohm"]) + nom(sup.get("flip_chip", {}).get("bump_to_grid_ohm", 0.02))
            l_one = 0.5 * nom(dc["l_loop_h"]) / eff
            imax = nom(dc["i_max_a"])
        r_one *= scales.get("conn_r", 1.0)
        l_one *= scales.get("conn_l", 1.0)
        pkg_node = c.node(f"pkg_{net}")
        gm.pkg_nodes[net] = pkg_node
        if dc["type"] == "bump":
            _add_bump_via_farms(gm, net, [n for (_, _, n, _) in lst], sup.get("flip_chip", {}), temp_c)
        for x, y, node, name in lst:
            gm.supplies.append(SupplyConn(net, name, node, r_one, l_one, x, y,
                                          "bondwire" if dc["type"] == "bondwire" else "bump", imax))
        if not dynamic:
            nodes = np.array([s.node for s in gm.supplies if s.net == net])
            c.add_R_bulk(nodes, np.full(nodes.shape, pkg_node), np.full(nodes.shape, r_one))
            # remainder of the path to the regulator (half of loop R on each side)
            r_rest = 0.0
            v_src = 0.0
            if rail_paths is not None:
                rail = ncfg.get("rail") if is_power else None
                ref = rail_paths.get(rail) if rail else next(iter(rail_paths.values()))
                if ref is not None:
                    r_rest = 0.5 * (ref.plane.r + ref.pins.r + ref.substrate.r)
            if is_power:
                v_src = nom(p.rails[ncfg["rail"]]["nominal_v"])
            src = f"src_{net}"
            c.add_V(src, "0", dc=v_src, name=f"V_{net}")
            c.add_R(src, pkg_node, max(r_rest, 1e-9))


def _add_bump_via_farms(gm: GridModel, net: str, top_nodes: List[int], fc_cfg: Mapping[str, Any],
                        temp_c: float) -> None:
    """Bump landings carry a dense via farm between the top two layers (bump pad -> top metal ->
    next metal), far denser than the strap-intersection vias of the homogenised grid."""
    order = [L["name"] for L in gm.project.pdn["layers"]]
    layers = [l for l in order if (net, l) in gm.node_map]
    if len(layers) < 2:
        return
    hi, lo = layers[-1], layers[-2]
    spec = {(v["from"], v["to"]): v for v in gm.project.pdn.get("vias", [])}.get((lo, hi))
    if spec is None:
        return
    cuts = int(nom(fc_cfg.get("via_farm_cuts", 64)))
    cut = gm.project.technology["via_cut_ohm"]
    r_farm = sum(nom(cut[lv]) for lv in spec["levels"]) / cuts * _tcr_scale(gm.project, temp_c)
    top = gm.node_map[(net, hi)]
    low = gm.node_map[(net, lo)]
    pos = {int(n): (j, i) for (j, i), n in np.ndenumerate(top) if n > 0}
    a, b, jj, ii = [], [], [], []
    for n in set(top_nodes):
        j, i = pos[int(n)]
        if low[j, i] > 0:
            a.append(int(n)); b.append(int(low[j, i])); jj.append(j); ii.append(i)
    if not a:
        return
    g = np.full(len(a), 1.0 / r_farm)
    gm.circuit.add_R_bulk(np.array(a), np.array(b), 1.0 / g)
    gm.vias.append(ViaSet(net, lo, hi + "(bump farm)", np.array(b), np.array(a), g, np.ones(len(a)), cuts,
                          np.array(jj), np.array(ii), tuple(spec["levels"])))


def add_loads(gm: GridModel, block_currents: Mapping[str, float]) -> Dict[str, np.ndarray]:
    """Add DC block currents (A) as sinks; returns the load map per power net."""
    p = gm.project
    maps: Dict[str, np.ndarray] = {}
    nets_by_rail = {cfg["rail"]: n for n, cfg in p.pdn["nets"].items() if cfg["type"] == "power"}
    for b in p.blocks:
        rail = b["rail"]
        if rail not in nets_by_rail:
            continue
        pnet = nets_by_rail[rail]
        gnet = _net_ground(p, pnet)
        i_b = float(block_currents.get(b["name"], 0.0))
        if i_b == 0:
            continue
        w = rect_weights(b["rect_um"], gm.nx, gm.ny, gm.dx, gm.dy)
        pn = _load_nodes_for_block(gm, pnet, b)
        gn = _load_nodes_for_block(gm, gnet, b)
        ok = (w > 0) & (pn > 0) & (gn > 0)
        if not ok.any():
            raise ConfigError(f"block {b['name']} has no grid nodes")
        wv = w[ok] / w[ok].sum()
        gm.circuit.add_I_group(pn[ok], gn[ok], i_b * wv, name=f"I_{b['name']}")
        m = maps.setdefault(pnet, np.zeros((gm.ny, gm.nx)))
        m[ok] += i_b * wv
    return maps


def _load_nodes_for_block(gm: GridModel, net: str, b: Mapping[str, Any]) -> np.ndarray:
    if b["kind"] == "sram":
        pin = b.get("pin_layer", gm.project.pdn.get("macros", {}).get("pin_layer"))
        if (net, pin) in gm.node_map:
            return gm.node_map[(net, pin)]
    return gm.load_layer_nodes[net]


# ------------------------------------------------------------------ solving
def solve_static(p: Project, block_currents: Mapping[str, float], rail_paths=None,
                 package: Optional[str] = None, resolution_um: Optional[float] = None,
                 temp_c: Optional[float] = None, scales: Optional[Mapping[str, float]] = None) -> IRResult:
    gm = build_grid(p, resolution_um, temp_c, scales, package, rail_paths)
    load_maps = add_loads(gm, block_currents)
    sol = gm.circuit.dc()
    return _postprocess(gm, sol.x, load_maps, temp_c if temp_c is not None
                        else float(p.pdn.get("analysis", {}).get("metal_temperature_c", 85.0)))


def _v(x: np.ndarray, nodes: np.ndarray) -> np.ndarray:
    out = np.full(nodes.shape, np.nan)
    m = nodes > 0
    out[m] = x[nodes[m] - 1]
    return out


def _postprocess(gm: GridModel, x: np.ndarray, load_maps: Dict[str, np.ndarray], temp_c: float) -> IRResult:
    from .em import em_limit_at
    p = gm.project
    eff, drop, worst, mean, brk, reff = {}, {}, {}, {}, {}, {}
    for net, cfg in p.pdn["nets"].items():
        if cfg["type"] != "power":
            continue
        gnet = _net_ground(p, net)
        vp = _v(x, gm.load_layer_nodes[net])
        vg = _v(x, gm.load_layer_nodes[gnet])
        e = vp - vg
        v_nom = nom(p.rails[cfg["rail"]]["nominal_v"])
        eff[net] = e
        d = v_nom - e
        drop[net] = d
        lm = load_maps.get(net, np.zeros_like(e))
        loaded = lm > 0
        worst[net] = float(np.nanmax(d[loaded])) if loaded.any() else float(np.nanmax(d))
        tot = lm.sum()
        mean[net] = float(np.nansum(d * lm) / tot) if tot > 0 else float(np.nanmean(d))
        # breakdown: package/pcb remainder, connections, on-die
        vpk = x[gm.pkg_nodes[net] - 1]
        vgk = x[gm.pkg_nodes[gnet] - 1]
        p_attach = np.array([x[s.node - 1] for s in gm.supplies if s.net == net])
        g_attach = np.array([x[s.node - 1] for s in gm.supplies if s.net == gnet])
        pad_eff = float(p_attach.mean() - g_attach.mean())
        brk[net] = {"off_die_v": float(v_nom - (vpk - vgk)),
                    "die_connection_v": float((vpk - vgk) - pad_eff),
                    "on_die_worst_v": float(pad_eff - np.nanmin(e[loaded])) if loaded.any() else 0.0,
                    "on_die_mean_v": float(pad_eff - np.nansum(e * lm) / tot) if tot > 0 else 0.0}
        reff[net] = float(np.nansum((pad_eff - e) * lm) / tot ** 2) if tot > 0 else 0.0
    # current density per layer ------------------------------------------------------
    jd: Dict[Tuple[str, str], np.ndarray] = {}
    em: Dict[Tuple[str, str], float] = {}
    for es in gm.edges:
        dv = _vpair(x, es.n1) - _vpair(x, es.n2)
        i = es.g * dv
        j_ma_um = np.abs(i) / es.width_per_edge_um * 1e3
        m = jd.setdefault((es.net, es.layer), np.zeros((gm.ny, gm.nx)))
        np.maximum.at(m, (es.cell_j, es.cell_i), j_ma_um)
        if es.direction == "H":
            np.maximum.at(m, (es.cell_j, np.minimum(es.cell_i + 1, gm.nx - 1)), j_ma_um)
        else:
            np.maximum.at(m, (np.minimum(es.cell_j + 1, gm.ny - 1), es.cell_i), j_ma_um)
        lim = em_limit_at(gm.layers[es.layer].em_limit_ma_um, temp_c)
        em[(es.net, es.layer)] = float(m.max() / lim) if lim > 0 else float("inf")
    vias_out: Dict[Tuple[str, str, str], float] = {}
    for vs in gm.vias:
        i = vs.g * (_vpair(x, vs.n1) - _vpair(x, vs.n2))
        per_cut = np.abs(i) / vs.count / vs.cuts * 1e3
        vias_out[(vs.net, vs.lower, vs.upper)] = float(per_cut.max()) if per_cut.size else 0.0
    sc = []
    for s in gm.supplies:
        i = (x[s.node - 1] - x[gm.pkg_nodes[s.net] - 1]) / s.r
        sc.append({"net": s.net, "name": s.name, "x_um": s.x_um, "y_um": s.y_um, "current_a": float(abs(i)),
                   "i_max_a": s.i_max_a, "ratio": float(abs(i) / s.i_max_a), "kind": s.kind})
    return IRResult(gm, x, eff, drop, load_maps, worst, mean, brk, reff, jd, em, vias_out, sc)


def _vpair(x: np.ndarray, nodes: np.ndarray) -> np.ndarray:
    out = np.zeros(nodes.shape)
    m = nodes > 0
    out[m] = x[nodes[m] - 1]
    return out


# ------------------------------------------------------------------ dynamic
@dataclass
class DynamicIRResult:
    t: np.ndarray
    worst_trace: np.ndarray
    mean_trace: np.ndarray
    min_eff_map: Dict[str, np.ndarray]
    dyn_drop_map: Dict[str, np.ndarray]
    worst_dyn_drop_v: Dict[str, float]
    grid: GridModel
    decap_map: Dict[str, np.ndarray]


def solve_dynamic(p: Project, cur_from: Mapping[str, Tuple[float, float]],
                  cur_to: Mapping[str, Tuple[float, float]], rail_paths: Mapping[str, Any],
                  t_event: float, t_stop: float, dt: float, f_clk: float, par: float, rise: float,
                  package: Optional[str] = None, resolution_um: Optional[float] = None,
                  temp_c: Optional[float] = None, block_cap: Optional[Mapping[str, float]] = None) -> DynamicIRResult:
    """Transient (dynamic) IR drop on a coarse grid.

    Per cell: i(t) = S_from + dS u(t) + [D_from + dD u(t)] s(t), where S are
    static (leakage) currents, D cycle-average dynamic currents, u a ramp of
    duration ``rise`` at ``t_event`` and s the unit-mean clock pulse shape of
    peak-to-average ``par``.  On-die capacitance (intrinsic per block +
    explicit decap regions, with ESR) is placed between the power and ground
    load-layer nodes.  Each supply connection carries its R and L share; the
    power-side package node is attached to the rail's lumped package/PCB/VRM
    ladder.
    """
    from .transient import ClockedLoad, StepLoad
    res = resolution_um or p.pdn.get("analysis", {}).get("dynamic_resolution_um", 50.0)
    gm = build_grid(p, res, temp_c, None, package, rail_paths, dynamic=True)
    c = gm.circuit
    tech = p.technology["decap_cell"]
    dens = nom(tech["density_ff_per_um2"]) * 1e-15
    esr_a = nom(tech["esr_ohm_um2"])
    # supply connections with R and L -----------------------------------------------
    for net in gm.pkg_nodes:
        sup = [s for s in gm.supplies if s.net == net]
        n1 = np.array([s.node for s in sup])
        mids = c.new_nodes(len(sup))
        c.add_R_bulk(n1, mids, np.array([s.r for s in sup]))
        c.add_L_bulk(mids, np.full(len(sup), gm.pkg_nodes[net]), np.array([s.l for s in sup]), prefix=f"Ls_{net}_")
    for net, cfg in p.pdn["nets"].items():
        if cfg["type"] == "ground":
            c.add_R(gm.pkg_nodes[net], "0", 1e-6)
        else:
            path = rail_paths[cfg["rail"]]
            n = path.build(c, upto_pkg_die=True, prefix=f"{net}_")
            c.add_R(n["pkg_die"], gm.pkg_nodes[net], 1e-6)
    # on-die capacitance ----------------------------------------------------------------
    from .path import die_capacitance
    decap_maps: Dict[str, np.ndarray] = {}
    for pnet, cfg in p.pdn["nets"].items():
        if cfg["type"] != "power":
            continue
        gnet = _net_ground(p, pnet)
        cmap = np.zeros((gm.ny, gm.nx))
        rail = cfg["rail"]
        dc_info = die_capacitance(p, rail)
        # intrinsic decap distributed over each block (logic: fraction of switched C; SRAM: array C)
        from ..power.dynamic import block_intrinsic_decap
        for b in p.blocks:
            if b["rail"] != rail:
                continue
            cb = block_intrinsic_decap(p, b) if block_cap is None else block_cap.get(b["name"], 0.0)
            if cb > 0:
                cmap += cb * rect_weights(b["rect_um"], gm.nx, gm.ny, gm.dx, gm.dy)
        dec = p.pdn.get("decap", {})
        first_grid = next((rn for rn, c_ in p.rails.items() if c_.get("on_die_grid")), rail)
        for r in dec.get("regions", []):
            if r.get("rail", first_grid) != rail:
                continue
            x0, y0, x1, y1 = r["rect_um"]
            cmap += (x1 - x0) * (y1 - y0) * nom(r.get("fill_fraction", 0.0)) * dens * \
                rect_weights(r["rect_um"], gm.nx, gm.ny, gm.dx, gm.dy)
        lf = nom(dec.get("logic_fill_fraction", 0.0))
        for b in p.blocks:
            if b["rail"] == rail and b["kind"] == "logic":
                x0, y0, x1, y1 = b["rect_um"]
                cmap += (x1 - x0) * (y1 - y0) * lf * dens * rect_weights(b["rect_um"], gm.nx, gm.ny, gm.dx, gm.dy)
        pn, gn = gm.load_layer_nodes[pnet], gm.load_layer_nodes[gnet]
        ok = (cmap > 0) & (pn > 0) & (gn > 0)
        mids = c.new_nodes(int(ok.sum()))
        cvals = cmap[ok]
        c.add_R_bulk(pn[ok], mids, esr_a / (cvals / dens))
        c.add_C_bulk(mids, gn[ok], cvals)
        decap_maps[pnet] = cmap
        gm.notes.append(f"{pnet}: on-die C in dynamic grid {cmap.sum()*1e9:.2f} nF "
                        f"(lumped model {dc_info['c_f']*1e9:.2f} nF)")
    # loads -----------------------------------------------------------------------------------
    u = StepLoad(0.0, 1.0, t_event, rise)
    shaper = ClockedLoad(StepLoad(0, 0, 0, 1e-9), StepLoad(1, 1, 0, 1e-9), f_clk, par, t_stop)
    shape = shaper.shape
    S0 = {k: v[0] for k, v in cur_from.items()}
    D0 = {k: v[1] for k, v in cur_from.items()}
    dS = {k: cur_to[k][0] - cur_from[k][0] for k in cur_to}
    dD = {k: cur_to[k][1] - cur_from[k][1] for k in cur_to}
    load_map_to: Dict[str, np.ndarray] = {}
    for vec, wave, tag in ((S0, None, "S0"), (dS, u, "dS"), (D0, shape, "D0"),
                           (dD, lambda t: u(t) * shape(t), "dD")):
        _add_load_group(gm, vec, wave, tag, load_map_to)
    # transient with running minimum -----------------------------------------------------------
    pnets = [n for n, cfg in p.pdn["nets"].items() if cfg["type"] == "power"]
    pidx = {n: gm.load_layer_nodes[n] for n in pnets}
    gidx = {n: gm.load_layer_nodes[_net_ground(p, n)] for n in pnets}
    mins = {n: np.full((gm.ny, gm.nx), np.inf) for n in pnets}
    trace_w, trace_m, ts = [], [], []
    first = pnets[0]
    valid = (pidx[first] > 0) & (gidx[first] > 0)

    def cb(t, x):
        for n in pnets:
            e = _v(x, pidx[n]) - _v(x, gidx[n])
            np.fmin(mins[n], e, out=mins[n])
        e = _v(x, pidx[first]) - _v(x, gidx[first])
        ts.append(t)
        trace_w.append(np.nanmin(e[valid]))
        trace_m.append(np.nanmean(e[valid]))

    c.tran([(t_stop, dt)], probes=[], callback=cb)
    dyn = {}
    worst = {}
    for n in pnets:
        v_nom = nom(p.rails[p.pdn["nets"][n]["rail"]]["nominal_v"])
        m = mins[n].copy()
        m[~np.isfinite(m)] = np.nan
        mins[n] = m
        dyn[n] = v_nom - m
        worst[n] = float(np.nanmax(dyn[n]))
    return DynamicIRResult(np.array(ts), np.array(trace_w), np.array(trace_m), mins, dyn, worst, gm, decap_maps)


def _add_load_group(gm: GridModel, currents: Mapping[str, float], wave, tag: str, acc) -> None:
    p = gm.project
    nets_by_rail = {cfg["rail"]: n for n, cfg in p.pdn["nets"].items() if cfg["type"] == "power"}
    n1s, n2s, amps = [], [], []
    for b in p.blocks:
        if b["rail"] not in nets_by_rail:
            continue
        i_b = float(currents.get(b["name"], 0.0))
        if i_b == 0.0:
            continue
        pnet = nets_by_rail[b["rail"]]
        gnet = _net_ground(p, pnet)
        w = rect_weights(b["rect_um"], gm.nx, gm.ny, gm.dx, gm.dy)
        pn = _load_nodes_for_block(gm, pnet, b)
        gn = _load_nodes_for_block(gm, gnet, b)
        ok = (w > 0) & (pn > 0) & (gn > 0)
        wv = w[ok] / w[ok].sum()
        n1s.append(pn[ok]); n2s.append(gn[ok]); amps.append(i_b * wv)
    if n1s:
        gm.circuit.add_I_group(np.concatenate(n1s), np.concatenate(n2s), np.concatenate(amps), wave,
                               name=f"I{tag}")
