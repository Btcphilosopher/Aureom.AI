"""End-to-end lumped power-delivery path for one supply rail.

    regulator -> [VRM output caps] -> PCB plane (R,L) -> [PCB decaps]
      -> package pins/balls (R,L) -> package substrate (R,L) -> [package caps]
      -> bond wires / bumps (R,L) -> on-die grid (R_eff) -> [on-die C + ESR] -> load

All R and L are *loop* values (supply + return), the usual single-ended
equivalent for PDN impedance work.  Parameters come from the project
configuration; ``scales`` multiplies individual parasitics for
sensitivity / Monte-Carlo / corner analysis.  The resulting
:class:`RailPath` builds itself into an MNA circuit for DC, AC and
transient analysis and can be exported to SPICE unchanged.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Any, Dict, List, Mapping, Optional

import numpy as np

from ..circuit.mna import Circuit
from ..config import Project
from ..constants import MU0, resistivity
from ..uncertainty import ParameterSet, nom, parse_value
from . import geometry as geo
from .decap import CapBank, banks_from_config
from .vrm import LDO, BuckVRM, regulator_from_config

RTINY = 1e-9  # ohm, used to join nodes when a segment has zero R


@dataclass
class Segment:
    name: str
    r: float
    l: float


@dataclass
class Connections:
    n_power_conn: int
    n_ground_conn: int
    n_power_pins: int
    n_ground_pins: int
    ground_on_ep: bool
    rationale: str = ""


@dataclass
class RailPath:
    rail: str
    v_nom: float
    regulator: Any
    vrm_banks: List[CapBank]
    plane: Segment
    pcb_banks: List[CapBank]
    pcb_bank_extra_l: List[float]
    pins: Segment
    substrate: Segment
    pkg_banks: List[CapBank]
    conn: Segment
    r_grid: float
    c_die: float
    r_die_esr: float
    package: str
    connections: Connections
    sense: str = "local"
    notes: List[str] = field(default_factory=list)

    # ---------------------------------------------------------------- helpers
    def segments(self) -> List[Segment]:
        return [self.plane, self.pins, self.substrate, self.conn, Segment("die_grid", self.r_grid, 0.0)]

    def series_r(self) -> float:
        return sum(s.r for s in self.segments())

    def l_package(self) -> float:
        """Inductance between the PCB device node and the die (pins+substrate+conn)."""
        return self.pins.l + self.substrate.l + self.conn.l

    def l_first_droop(self) -> float:
        """Loop inductance that limits the first droop.  Package-level capacitors
        (land-side caps, interposer trench caps) supply the die through the die
        connections only, shielding it from the ball/substrate inductance when
        their own ESL is lower than that path."""
        if not self.pkg_banks:
            return self.l_package()
        g = sum(b.count / b.part.l_total for b in self.pkg_banks)
        l_caps = 1.0 / g if g > 0 else float("inf")
        return self.conn.l + min(self.pins.l + self.substrate.l, l_caps)

    def dc_drops(self, current: float) -> Dict[str, float]:
        return {s.name: current * s.r for s in self.segments()}

    # ---------------------------------------------------------------- builder
    def build(self, c: Circuit, load_dc: float = 0.0, load_wave=None, ac_load: bool = False,
              open_loop: bool = False, prefix: str = "", vrm_ac_inject: bool = False,
              upto_pkg_die: bool = False) -> Dict[str, str]:
        """Insert the path into ``c``.  ``upto_pkg_die`` stops at the package
        die-side node (used when the die is represented by the full grid)."""
        p = prefix
        n = {k: p + k for k in ("vrm_out", "pcb_dev", "pkg_sub", "pkg_die", "die_pad", "die_load")}
        sense_node = n["vrm_out"] if self.sense == "local" else n["pcb_dev"]
        if isinstance(self.regulator, BuckVRM):
            self.regulator.build(c, n["vrm_out"], sense=sense_node, prefix=p + "vrm_", open_loop=open_loop)
        else:
            self.regulator.build(c, n["vrm_out"], prefix=p + "vrm_")
        if vrm_ac_inject:
            c.add_I("0", n["vrm_out"], dc=0.0, ac=1.0, name=p + "Iripple")
        for k, b in enumerate(self.vrm_banks):
            _add_bank(c, n["vrm_out"], b, f"{p}vcap{k}_", 0.0)
        _add_series(c, n["vrm_out"], n["pcb_dev"], self.plane, p + "plane")
        for k, b in enumerate(self.pcb_banks):
            _add_bank(c, n["pcb_dev"], b, f"{p}pcap{k}_", self.pcb_bank_extra_l[k])
        _add_series(c, n["pcb_dev"], n["pkg_sub"], self.pins, p + "pins")
        _add_series(c, n["pkg_sub"], n["pkg_die"], self.substrate, p + "sub")
        for k, b in enumerate(self.pkg_banks):
            _add_bank(c, n["pkg_die"], b, f"{p}kcap{k}_", 0.0)
        if upto_pkg_die:
            return n
        _add_series(c, n["pkg_die"], n["die_pad"], self.conn, p + "conn")
        c.add_R(n["die_pad"], n["die_load"], max(self.r_grid, RTINY))
        mid = p + "diecap"
        c.add_R(n["die_load"], mid, max(self.r_die_esr, RTINY))
        c.add_C(mid, "0", self.c_die)
        c.add_I(n["die_load"], "0", dc=load_dc, wave=load_wave, ac=1.0 if ac_load else 0.0,
                name=p + "Iload")
        return n

    def circuit(self, **kw) -> tuple:
        c = Circuit(f"{self.rail} PDN via {self.package}")
        nodes = self.build(c, **kw)
        return c, nodes


def _add_series(c: Circuit, a: str, b: str, seg: Segment, name: str) -> None:
    if seg.l > 0:
        mid = name + "_m"
        c.add_R(a, mid, max(seg.r, RTINY))
        c.add_L(mid, b, seg.l, name="L_" + name)
    else:
        c.add_R(a, b, max(seg.r, RTINY))


def _add_bank(c: Circuit, node: str, bank: CapBank, prefix: str, extra_l: float) -> None:
    r, l, cap = bank.rlc()
    l = l + extra_l
    c.add_R(node, prefix + "a", max(r, RTINY))
    c.add_L(prefix + "a", prefix + "b", l, name="L_" + prefix + "esl")
    c.add_C(prefix + "b", "0", cap)


# ============================================================================
# parameter derivation from the project
# ============================================================================
SCALE_KEYS = ("plane_r", "plane_l", "pcb_cap", "pcb_esl", "pin_r", "pin_l", "sub_r", "sub_l",
              "conn_r", "conn_l", "c_die", "r_grid", "die_esr", "vrm_cap")


def _pick(v: Any, use: str, adverse_high: bool) -> float:
    u = parse_value(v)
    if use == "nom":
        return u.nom
    if use == "worst":
        return u.max if adverse_high else u.min
    return u.min if adverse_high else u.max


def explicit_decap_f(p: Project, rail: str, scales: Optional[Mapping[str, float]] = None) -> Dict[str, float]:
    """Explicit on-die decap cell capacitance (and its silicon area) on a gridded rail."""
    tech = p.technology["decap_cell"]
    dens = nom(tech["density_ff_per_um2"]) * 1e-15
    dec = p.pdn.get("decap", {})
    area = 0.0
    first_grid = next((rn for rn, c in p.rails.items() if c.get("on_die_grid")), rail)
    for r in dec.get("regions", []):
        if r.get("rail", first_grid) != rail:
            continue
        x0, y0, x1, y1 = r["rect_um"]
        area += (x1 - x0) * (y1 - y0) * nom(r.get("fill_fraction", 0.0))
    logic_area = sum((b["rect_um"][2] - b["rect_um"][0]) * (b["rect_um"][3] - b["rect_um"][1])
                     for b in p.blocks if b["kind"] == "logic" and b["rail"] == rail)
    area += logic_area * nom(dec.get("logic_fill_fraction", 0.0))
    return {"area_um2": area, "c_f": area * dens}


def die_capacitance(p: Project, rail: str, scales: Optional[Mapping[str, float]] = None) -> Dict[str, float]:
    from ..power.dynamic import intrinsic_decap
    scales = scales or {}
    cfg = p.rails[rail]
    tech = p.technology["decap_cell"]
    if cfg.get("on_die_grid", False):
        exp = explicit_decap_f(p, rail)
        intr = intrinsic_decap(p, rail, scales)
        c = (exp["c_f"] + intr) * scales.get("c_die", 1.0)
        dens = nom(tech["density_ff_per_um2"]) * 1e-15
        area_eq = c / dens if c > 0 else 1.0
        esr = nom(tech["esr_ohm_um2"]) / area_eq * scales.get("die_esr", 1.0)
        return {"c_f": c, "explicit_f": exp["c_f"], "intrinsic_f": intr, "decap_area_um2": exp["area_um2"],
                "esr_ohm": esr}
    c = nom(cfg.get("die_cap_nf", 0.5)) * 1e-9 * scales.get("c_die", 1.0)
    dens = nom(tech["density_ff_per_um2"]) * 1e-15
    esr = nom(tech["esr_ohm_um2"]) / (c / dens) * scales.get("die_esr", 1.0)
    return {"c_f": c, "explicit_f": c, "intrinsic_f": 0.0, "decap_area_um2": c / dens, "esr_ohm": esr}


def rail_region_area_um2(p: Project, rail: str) -> float:
    """Area of the on-die region served by a rail (core area minus exclusions for gridded rails)."""
    for net, cfg in p.pdn.get("nets", {}).items():
        if cfg.get("rail") == rail:
            regions = p.pdn["regions"]
            names = cfg.get("region", "core")
            names = names if isinstance(names, list) else [names]
            a = 0.0
            for rn in names:
                x0, y0, x1, y1 = regions[rn]
                a += (x1 - x0) * (y1 - y0)
            for rn in cfg.get("exclude", []):
                x0, y0, x1, y1 = regions[rn]
                a -= (x1 - x0) * (y1 - y0)
            return a
    rects = [b["rect_um"] for b in p.blocks if b["rail"] == rail]
    return sum((r[2] - r[0]) * (r[3] - r[1]) for r in rects) or 1e4


def allocate_connections(p: Project, pkg: Mapping[str, Any], rail: str, i_max: float,
                         delta_i: float) -> Connections:
    """Number of power/ground die connections and package pins for a rail.

    Baseline package with a pin plan -> the plan.  Otherwise:
      * current:    n >= 1.5 * I_max / I_max_per_connection (EM / fusing headroom)
      * inductance: n >= L_pair / (eff * L_allowed), L_allowed = C_die (dV/dI)^2
        (first-droop bound, see decap.die_decap_required)
      * flip-chip:  all bumps over the rail's region at the PG fraction are used
    These are planning allocations, not a bump/ball map.
    """
    cfg = p.rails[rail]
    plan = p.chip.get("io", {}).get("pin_plan", {})
    dc = pkg["die_connection"]
    eff = nom(pkg.get("parallel_efficiency", 0.75))
    if pkg["key"] == p.baseline_package and rail in plan:
        e = plan[rail]
        n_p = int(e["power"])
        n_g = int(e["ground"])
        ep = bool(e.get("ground_on_exposed_pad", False)) and bool(pkg.get("exposed_pad", False))
        return Connections(n_p, n_g, n_p, 0 if ep else n_g, ep, "baseline pin plan")
    v = nom(cfg["nominal_v"])
    dyn_budget = nom(cfg.get("budget", {}).get("dynamic", 0.05)) * v
    c_die = die_capacitance(p, rail)["c_f"]
    n_min = 2 if cfg.get("kind") == "digital_core" else 1
    i_conn = nom(dc["i_max_a"])
    n_i = math.ceil(1.5 * i_max / i_conn) if i_max > 0 else 1
    if dc["type"] == "bondwire":
        l_pair = geo.l_bondwire(nom(dc["length_mm"]) * 1e-3, nom(dc["diameter_um"]) * 1e-6,
                                nom(dc["return_spacing_um"]) * 1e-6)
    else:
        l_pair = nom(dc["l_loop_h"])
    l_allowed = c_die * (dyn_budget / max(delta_i, 1e-6)) ** 2
    n_l = math.ceil(l_pair / (eff * l_allowed)) if l_allowed > 0 else n_min
    why = f"I-limited n>={n_i}, L-limited n>={n_l}"
    if dc["type"] == "bump" and cfg.get("on_die_grid", False):
        pitch = nom(dc["pitch_um"])
        area = rail_region_area_um2(p, rail)
        avail = int(area / pitch ** 2 * nom(dc.get("power_fraction_core", 0.6)) / 2)
        n_p = max(n_min, n_i, min(avail, max(n_l, avail)))
        why += f", {avail} PG bump pairs available over region"
    else:
        n_p = max(n_min, n_i, min(n_l, 64))
    if cfg.get("kind") == "io":
        io = p.chip.get("io", {})
        n_sso = int(io.get("simultaneous_switching_outputs", 0))
        n_p = max(n_p, math.ceil(n_sso / max(1, int(io.get("sso_per_power_pair", 3)))))
        why += f", SSO-limited n>={math.ceil(n_sso / max(1, int(io.get('sso_per_power_pair', 3))))}"
    ep = bool(pkg.get("exposed_pad", False)) and cfg.get("kind") != "analog"
    i_pin = nom(pkg["pin"]["i_max_a"])
    n_pins = max(n_min, math.ceil(1.5 * i_max / i_pin))
    if dc["type"] == "bondwire":
        n_pins = n_p           # one wire per lead
    else:
        # bump-to-ball fan-in: ~8 C4 bumps (150 um pitch) per ball, scaled with bump density
        per_ball = 8.0 * (150.0 / nom(dc.get("pitch_um", 150.0))) ** 2
        n_pins = max(n_pins, math.ceil(n_p / per_ball))
    return Connections(n_p, n_p, n_pins, 0 if ep else n_pins, ep, why)


def build_rail_path(p: Project, rail: str, package: Optional[str] = None,
                    connections: Optional[Connections] = None, i_max: float = 0.05,
                    delta_i: float = 0.04, r_grid: Optional[float] = None, use: str = "nom",
                    scales: Optional[Mapping[str, float]] = None, temp_c: float = 85.0,
                    compensate: bool = True) -> RailPath:
    scales = {k: 1.0 for k in SCALE_KEYS} | dict(scales or {})
    pkg = p.package(package)
    cfg = p.rails[rail]
    v_nom = nom(cfg["nominal_v"])
    pcb = p.pcb
    lib = pcb["capacitor_library"]
    rp = pcb["rail_pcb"][rail]
    notes: List[str] = []
    if connections is None:
        connections = allocate_connections(p, pkg, rail, i_max, delta_i)
    # ---- regulator ---------------------------------------------------------
    reg_cfg = pcb["regulators"][cfg["regulator"]]
    vrm_banks = banks_from_config(reg_cfg.get("output_caps", []), lib, use=use)
    vrm_banks = [CapBank(replace(b.part, derating=b.part.derating * scales["vrm_cap"]), b.count, "vrm")
                 for b in vrm_banks]
    reg = regulator_from_config(cfg["regulator"], reg_cfg, v_nom, vrm_banks, use=use)
    # ---- PCB plane ----------------------------------------------------------
    pl = rp["plane"]
    length = _pick(pl["length_mm"], use, True) * 1e-3
    width = nom(pl["width_mm"]) * 1e-3
    h = _pick(pl["separation_um"], use, True) * 1e-6
    t_cu = geo.oz_to_m(nom(pl.get("cu_oz", 1.0)))
    rho = resistivity("copper", 40.0)
    plane = Segment("pcb_plane", geo.r_plane_pair(rho, length, width, t_cu) * scales["plane_r"],
                    geo.l_plane_pair(h, length, width) * scales["plane_l"])
    # ---- PCB decaps -----------------------------------------------------------
    pcb_banks = banks_from_config(rp.get("decaps", []), lib, use=use)
    pcb_banks = [CapBank(replace(b.part, derating=min(1.0, b.part.derating * scales["pcb_cap"]),
                                 esl_h=b.part.esl_h * scales["pcb_esl"],
                                 mount_l_h=b.part.mount_l_h * scales["pcb_esl"]), b.count, b.location)
                 for b in pcb_banks]
    sp_cfg = rp.get("spreading", {})
    l_spread = geo.l_plane_spreading(h, nom(sp_cfg.get("distance_mm", 3.0)) * 1e-3,
                                     nom(sp_cfg.get("via_radius_um", 125)) * 1e-6)
    extra = [l_spread * (0.3 if b.location == "pcb_under" else 1.0) for b in pcb_banks]
    # ---- package pins -------------------------------------------------------
    pin = pkg["pin"]
    eff = _pick(pkg.get("parallel_efficiency", 0.75), use, False)
    n_pp = max(1, connections.n_power_pins)
    n_gp = connections.n_ground_pins
    r_pin = _pick(pin["r_ohm"], use, True)
    r_pins = r_pin / n_pp + (r_pin / n_gp if n_gp > 0 else 0.2e-3)
    l_pins = _pick(pin["l_loop_h"], use, True) / (n_pp * eff)
    pins = Segment("package_pins", r_pins * scales["pin_r"], l_pins * scales["pin_l"])
    sub_cfg = pkg.get("substrate", {})
    substrate = Segment("package_substrate", _pick(sub_cfg.get("r_ohm", 0.0), use, True) * scales["sub_r"],
                        _pick(sub_cfg.get("l_h", 0.0), use, True) * scales["sub_l"])
    pkg_banks = banks_from_config(rp.get("package_decaps", []), lib, use=use) \
        if pkg.get("package_decap_allowed") else []
    if "interposer_decap" in pkg and cfg.get("on_die_grid", False):
        from .decap import CapacitorPart
        idc = pkg["interposer_decap"]
        share = rail_region_area_um2(p, rail) / (nom(p.core["width_mm"]) * nom(p.core["height_mm"]) * 1e6)
        area_mm2 = nom(p.die["width_mm"]) * nom(p.die["height_mm"]) * share
        c_dtc = _pick(idc["nf_per_mm2"], use, False) * 1e-9 * area_mm2 * _pick(idc["usable_fraction"], use, False)
        part = CapacitorPart("interposer_dtc", c_dtc, _pick(idc["esr_ohm"], use, True) / max(share, 1e-3),
                             _pick(idc["esl_h"], use, True) / max(share, 1e-3), 0.0, 1.0, "DTC", "interposer")
        pkg_banks.append(CapBank(part, 1, "package"))
        notes.append(f"interposer deep-trench decap {c_dtc*1e9:.0f} nF added at the package die-side node")
    # ---- die connection -------------------------------------------------------
    dc = pkg["die_connection"]
    n_pc = max(1, connections.n_power_conn)
    n_gc = max(1, connections.n_ground_conn)
    if dc["type"] == "bondwire":
        d = _pick(dc["diameter_um"], use, False) * 1e-6
        l_w = _pick(dc["length_mm"], use, True) * 1e-3
        l_g = _pick(dc.get("downbond_length_mm", dc["length_mm"]), use, True) * 1e-3 \
            if connections.ground_on_ep else l_w
        s_ret = _pick(dc["return_spacing_um"], use, True) * 1e-6
        rho_w = resistivity(dc.get("material", "gold"), temp_c)
        r_conn = geo.r_cylinder(rho_w, l_w, d) / n_pc + geo.r_cylinder(rho_w, l_g, d) / n_gc
        l_conn = geo.l_bondwire(0.5 * (l_w + l_g), d, s_ret) / (n_pc * eff)
    else:
        r_b = _pick(dc["r_ohm"], use, True)
        r_conn = r_b / n_pc + r_b / n_gc
        l_conn = _pick(dc["l_loop_h"], use, True) / (n_pc * eff)
    conn = Segment("die_connection", r_conn * scales["conn_r"], l_conn * scales["conn_l"])
    # ---- on-die --------------------------------------------------------------
    dcap = die_capacitance(p, rail, scales)
    if r_grid is None:
        r_grid = _pick(cfg.get("die_r_grid_ohm", 0.005), use, True)
        if cfg.get("on_die_grid", False):
            notes.append("r_grid not supplied from grid solver; using config/default value")
    r_grid *= scales["r_grid"]
    path = RailPath(rail, v_nom, reg, vrm_banks, plane, pcb_banks, extra, pins, substrate, pkg_banks,
                    conn, r_grid, dcap["c_f"], dcap["esr_ohm"], pkg["key"], connections,
                    sense=str(reg_cfg.get("sense", "local")), notes=notes)
    if isinstance(reg, BuckVRM):
        # analytic type-II design always; numerical refinement of the crossover if requested
        c_tot = sum(b.c_total for b in vrm_banks) + sum(b.c_total for b in pcb_banks) + dcap["c_f"]
        reg.design_compensation(c_tot)
        if compensate:
            from .impedance import loop_gain
            reg.refine_compensation(lambda r: loop_gain(path, np.logspace(3, 7, 161)))
    return path


def path_parameters(p: Project, rail: str, package: Optional[str] = None) -> ParameterSet:
    """Scale-factor uncertainties for one rail path, derived from config ranges."""
    pkg = p.package(package)
    rp = p.pcb["rail_pcb"][rail]
    ps = ParameterSet()

    def rel(v: Any) -> Dict[str, Any]:
        u = parse_value(v)
        if u.nom == 0:
            return {"nom": 1.0, "min": 1.0, "max": 1.0}
        return {"nom": 1.0, "min": u.min / u.nom, "max": u.max / u.nom, "source": u.source}

    ps.add("plane_l", rel(rp["plane"]["separation_um"]), True, "pcb")
    ps.add("plane_r", rel(rp["plane"]["length_mm"]), True, "pcb")
    first = rp.get("decaps", [{}])[0].get("part")
    if first:
        part = p.pcb["capacitor_library"][first]
        ps.add("pcb_cap", rel(part.get("dc_bias_retained", 1.0)), False, "pcb")
        ps.add("pcb_esl", rel(part.get("mount_l_h", 0.0)), True, "pcb")
    ps.add("pin_l", rel(pkg["pin"]["l_loop_h"]), True, "package")
    ps.add("pin_r", rel(pkg["pin"]["r_ohm"]), True, "package")
    dc = pkg["die_connection"]
    if dc["type"] == "bondwire":
        ps.add("conn_l", rel(dc["length_mm"]), True, "package")
        ps.add("conn_r", rel(dc["length_mm"]), True, "package")
    else:
        ps.add("conn_l", rel(dc["l_loop_h"]), True, "package")
        ps.add("conn_r", rel(dc["r_ohm"]), True, "package")
    sub = pkg.get("substrate", {})
    if "l_h" in sub:
        ps.add("sub_l", rel(sub["l_h"]), True, "package")
    tech = p.technology
    if p.rails[rail].get("on_die_grid"):
        lo = min(parse_value(tech["decap_cell"]["density_ff_per_um2"]).min / nom(tech["decap_cell"]["density_ff_per_um2"]),
                 parse_value(tech["stdcell"]["intrinsic_decap_fraction"]).min / nom(tech["stdcell"]["intrinsic_decap_fraction"]))
        hi = max(parse_value(tech["decap_cell"]["density_ff_per_um2"]).max / nom(tech["decap_cell"]["density_ff_per_um2"]),
                 parse_value(tech["stdcell"]["intrinsic_decap_fraction"]).max / nom(tech["stdcell"]["intrinsic_decap_fraction"]))
        ps.add("c_die", {"nom": 1.0, "min": lo, "max": hi, "source": "assumption"}, False, "die")
        ps.add("die_esr", rel(tech["decap_cell"]["esr_ohm_um2"]), True, "die")
        rs = parse_value(tech["metal_stack"]["M1"]["rs_ohm_sq"])
        ps.add("r_grid", {"nom": 1.0, "min": rs.min / rs.nom, "max": rs.max / rs.nom, "source": rs.source}, True, "die")
    else:
        ps.add("c_die", rel(p.rails[rail].get("die_cap_nf", 0.5)), False, "die")
        ps.add("r_grid", rel(p.rails[rail].get("die_r_grid_ohm", 0.005)), True, "die")
    return ps
