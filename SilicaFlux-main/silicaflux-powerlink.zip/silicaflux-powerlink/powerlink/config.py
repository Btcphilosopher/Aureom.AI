"""Configuration loading with provenance tracking and reproducibility hashing.

A *project* file (``configs/chips/<chip>.yaml``) references the technology,
PCB, package library, on-die PDN, workload and thermal files by relative
path.  :func:`load_project` resolves those references, records the SHA-256
of every file read, and returns a :class:`Project` object.  The hashes are
written into every results manifest so that an analysis can be reproduced
bit-for-bit from the same inputs.
"""
from __future__ import annotations

import hashlib
import json
import platform
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from .uncertainty import UncertainValue, nom, parse_value

REFERENCE_KEYS = ("technology", "pcb", "packages", "pdn", "workloads", "thermal")


class ConfigError(ValueError):
    pass


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


class _Loader(yaml.SafeLoader):
    """SafeLoader that also accepts YAML-1.2 style floats such as 1e6 / 2.0e7
    (PyYAML's YAML-1.1 resolver otherwise reads them as strings)."""


_Loader.add_implicit_resolver(
    "tag:yaml.org,2002:float",
    re.compile(r"""^(?:[-+]?(?:[0-9][0-9_]*)\.[0-9_]*(?:[eE][-+]?[0-9]+)?
                  |[-+]?(?:[0-9][0-9_]*)(?:[eE][-+]?[0-9]+)
                  |\.[0-9_]+(?:[eE][-+]?[0-9]+)?
                  |[-+]?\.(?:inf|Inf|INF)
                  |\.(?:nan|NaN|NAN))$""", re.X),
    list("-+0123456789."))


def load_yaml(path: Path | str) -> Dict[str, Any]:
    path = Path(path)
    if not path.exists():
        raise ConfigError(f"configuration file not found: {path}")
    with path.open("r", encoding="utf-8") as fh:
        data = yaml.load(fh, Loader=_Loader) or {}
    if not isinstance(data, dict):
        raise ConfigError(f"{path}: top level must be a mapping")
    return data


@dataclass
class Project:
    """All configuration needed to analyse one chip variant."""

    path: Path
    chip: Dict[str, Any]
    technology: Dict[str, Any]
    pcb: Dict[str, Any]
    packages: Dict[str, Any]
    pdn: Dict[str, Any]
    workloads: Dict[str, Any]
    thermal: Dict[str, Any]
    file_hashes: Dict[str, str] = field(default_factory=dict)

    # ---------------------------------------------------------------- access
    @property
    def name(self) -> str:
        return str(self.chip["chip"]["name"])

    @property
    def rails(self) -> Dict[str, Dict[str, Any]]:
        return self.chip["rails"]

    @property
    def blocks(self) -> List[Dict[str, Any]]:
        return self.chip["blocks"]

    @property
    def core(self) -> Dict[str, Any]:
        return self.chip["chip"]["core"]

    @property
    def die(self) -> Dict[str, Any]:
        return self.chip["chip"]["die"]

    @property
    def clock_hz(self) -> float:
        return nom(self.chip["chip"]["clock_mhz"]) * 1e6

    @property
    def baseline_package(self) -> str:
        return str(self.chip["chip"]["baseline_package"])

    def package(self, key: Optional[str] = None) -> Dict[str, Any]:
        key = key or self.baseline_package
        lib = self.packages["packages"]
        if key not in lib:
            raise ConfigError(f"package '{key}' not in package library ({list(lib)})")
        d = dict(lib[key])
        d["key"] = key
        return d

    def rail_names(self) -> List[str]:
        return list(self.rails.keys())

    def manifest(self) -> Dict[str, Any]:
        import numpy
        import scipy
        return {
            "project": str(self.path),
            "chip": self.name,
            "input_sha256": self.file_hashes,
            "python": sys.version.split()[0],
            "numpy": numpy.__version__,
            "scipy": scipy.__version__,
            "platform": platform.platform(),
        }


def load_project(path: Path | str) -> Project:
    path = Path(path).resolve()
    chip = load_yaml(path)
    hashes = {str(path.name): _sha256(path)}
    refs: Dict[str, Dict[str, Any]] = {}
    ref_block = chip.get("references", {})
    for key in REFERENCE_KEYS:
        if key not in ref_block:
            raise ConfigError(f"{path}: 'references' must define '{key}'")
        p = (path.parent / ref_block[key]).resolve()
        refs[key] = load_yaml(p)
        hashes[str(Path(ref_block[key]).as_posix())] = _sha256(p)
    proj = Project(path=path, chip=chip, file_hashes=hashes, **refs)
    validate_project(proj)
    return proj


# --------------------------------------------------------------------------
# validation
# --------------------------------------------------------------------------
def _require(d: Dict[str, Any], keys: List[str], ctx: str) -> None:
    missing = [k for k in keys if k not in d]
    if missing:
        raise ConfigError(f"{ctx}: missing keys {missing}")


def validate_project(p: Project) -> None:
    _require(p.chip, ["chip", "rails", "blocks", "references"], "chip")
    _require(p.chip["chip"], ["name", "die", "core", "clock_mhz", "baseline_package"], "chip.chip")
    for rname, r in p.rails.items():
        _require(r, ["nominal_v", "min_v", "max_v", "regulator"], f"rail {rname}")
        if not nom(r["min_v"]) < nom(r["nominal_v"]) < nom(r["max_v"]):
            raise ConfigError(f"rail {rname}: require min_v < nominal_v < max_v")
        if r["regulator"] not in p.pcb.get("regulators", {}):
            raise ConfigError(f"rail {rname}: regulator '{r['regulator']}' not defined in PCB config")
    core = p.core
    die = p.die
    if nom(core["x0_mm"]) + nom(core["width_mm"]) > nom(die["width_mm"]) + 1e-9:
        raise ConfigError("core extends beyond die in x")
    if nom(core["y0_mm"]) + nom(core["height_mm"]) > nom(die["height_mm"]) + 1e-9:
        raise ConfigError("core extends beyond die in y")
    names = set()
    groups = set()
    for b in p.blocks:
        groups.add(b.get("group", b.get("name")))
        _require(b, ["name", "rail", "rect_um", "kind"], f"block {b.get('name')}")
        if b["name"] in names:
            raise ConfigError(f"duplicate block name {b['name']}")
        names.add(b["name"])
        if b["rail"] not in p.rails:
            raise ConfigError(f"block {b['name']}: unknown rail {b['rail']}")
        x0, y0, x1, y1 = b["rect_um"]
        if not (x1 > x0 and y1 > y0):
            raise ConfigError(f"block {b['name']}: rect_um must be [x0, y0, x1, y1] with x1>x0, y1>y0")
    for wname, w in p.workloads.get("profiles", {}).items():
        for bname in w.get("activity", {}):
            if bname not in names and bname not in groups and bname != "default":
                raise ConfigError(f"workload {wname}: unknown block or group '{bname}'")
    if p.baseline_package not in p.packages.get("packages", {}):
        raise ConfigError(f"baseline package '{p.baseline_package}' not in library")


def collect_uncertain(d: Any, prefix: str = "") -> List[tuple]:
    """Walk a config tree and list every uncertain (non-fixed) value with its path."""
    out = []
    if isinstance(d, dict):
        if "nom" in d and all(isinstance(v, (int, float, str)) for v in d.values()):
            try:
                uv = parse_value(d)
                out.append((prefix, uv))
                return out
            except (TypeError, ValueError):
                pass
        for k, v in d.items():
            out.extend(collect_uncertain(v, f"{prefix}.{k}" if prefix else str(k)))
    elif isinstance(d, list):
        for i, v in enumerate(d):
            out.extend(collect_uncertain(v, f"{prefix}[{i}]"))
    return out


def assumption_register(p: Project) -> List[Dict[str, Any]]:
    """Every uncertain value in the project with its provenance, for the reports."""
    rows = []
    for section in ("chip", "technology", "pcb", "packages", "pdn", "workloads", "thermal"):
        for path, uv in collect_uncertain(getattr(p, section), section):
            rows.append({"path": path, "nominal": uv.nom, "min": uv.min, "max": uv.max,
                         "dist": uv.dist, "source": uv.source, "note": uv.note})
    return rows


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, default=_json_default)


def _json_default(o: Any) -> Any:
    import numpy as np
    if isinstance(o, UncertainValue):
        return {"nom": o.nom, "min": o.min, "max": o.max, "source": o.source}
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"not JSON serialisable: {type(o)}")
