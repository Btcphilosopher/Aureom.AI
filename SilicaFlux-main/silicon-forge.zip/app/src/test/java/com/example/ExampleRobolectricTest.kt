package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.siliconforge.data.BenchmarkRepository
import com.example.siliconforge.hardware.HardwareDiscovery
import com.example.siliconforge.model.BenchmarkCategory
import com.example.siliconforge.model.BenchmarkRun
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Silicon Forge", appName)
    }

    @Test
    fun `test hardware discovery capture`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val hardware = HardwareDiscovery.captureHardwareSnapshot(context)
        assertNotNull(hardware)
        assertTrue(hardware.coreCount >= 1)
        assertNotNull(hardware.memory)
        assertNotNull(hardware.cacheHierarchy)
    }

    @Test
    fun `test benchmark repository database persistence`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = BenchmarkRepository(context)

        val testRun = BenchmarkRun(
            id = "test-run-123",
            benchmarkId = "cpu_int_alu",
            benchmarkName = "Integer ALU Test",
            category = BenchmarkCategory.INTEGER,
            threadCount = 1,
            iterations = 3,
            samples = listOf(100.0, 102.0, 101.0),
            mean = 101.0,
            median = 101.0,
            stdDev = 1.0,
            iqr = 1.5,
            ci95Lower = 100.2,
            ci95Upper = 101.8,
            cvPercent = 0.99,
            rawScore = 101.0,
            unit = "MOP/s",
            normalizedScore = 1000.0
        )

        repo.saveRun(testRun)
        val allRuns = repo.allRuns.first()
        assertTrue("Run should be persisted", allRuns.any { it.id == "test-run-123" })

        val json = repo.exportToJson(allRuns)
        assertTrue("JSON export should include run id", json.contains("test-run-123"))

        val csv = repo.exportToCsv(allRuns)
        assertTrue("CSV export should include benchmark id", csv.contains("cpu_int_alu"))
    }
}
