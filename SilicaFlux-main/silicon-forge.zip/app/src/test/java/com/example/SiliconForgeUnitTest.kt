package com.example

import com.example.siliconforge.benchmark.kernels.AiKernels
import com.example.siliconforge.benchmark.kernels.FloatingPointKernels
import com.example.siliconforge.benchmark.kernels.IntegerKernels
import com.example.siliconforge.benchmark.kernels.MemoryKernels
import com.example.siliconforge.model.ArchitectureConfig
import com.example.siliconforge.simulation.SemiconductorSimulator
import com.example.siliconforge.statistics.StatisticalEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SiliconForgeUnitTest {

    @Test
    fun testStatisticalEngineBootstrapAndMoments() {
        val samples = listOf(100.0, 102.0, 98.0, 105.0, 95.0, 101.0, 99.0)
        val analysis = StatisticalEngine.analyze(samples)

        assertEquals(100.0, analysis.mean, 1.0)
        assertEquals(100.0, analysis.median, 1.0)
        assertTrue("Standard deviation should be positive", analysis.stdDev > 0.0)
        assertTrue("CV% should be small for stable samples", analysis.cvPercent < 5.0)
        assertTrue("Lower CI should be less than upper CI", analysis.ci95Lower <= analysis.ci95Upper)
        assertTrue("Lower CI should be reasonable", analysis.ci95Lower in 90.0..105.0)
        assertTrue("Upper CI should be reasonable", analysis.ci95Upper in 95.0..110.0)
    }

    @Test
    fun testRooflineModelCalculation() {
        val config = ArchitectureConfig(
            coreCount = 16,
            clockGhz = 4.0,
            executionWidth = 8,
            memoryBandwidthGbps = 100.0
        )
        val roofline = SemiconductorSimulator.calculateRoofline(config)

        // Peak compute = 16 * 4.0 * 8 * 2.0 = 1024 GFLOP/s
        assertEquals(1024.0, roofline.peakComputeGFlops, 0.1)
        assertEquals(100.0, roofline.peakMemoryBandwidthGBps, 0.1)
        // Ridge point = 1024 / 100 = 10.24 FLOP/Byte
        assertEquals(10.24, roofline.ridgePointIntensity, 0.1)
        assertTrue("Curve points should not be empty", roofline.curvePoints.isNotEmpty())
    }

    @Test
    fun testAmdahlLawScaling() {
        val amdahl = SemiconductorSimulator.calculateAmdahl(coreCount = 16, parallelFraction = 0.95)
        // Amdahl speedup for 95% parallel across 16 cores ~ 9.41x
        assertTrue("Speedup should be > 5.0 for 16 cores", amdahl.theoreticalSpeedup > 5.0)
        assertTrue("Speedup must be <= 16.0", amdahl.theoreticalSpeedup <= 16.0)
        assertTrue("Parallel efficiency must be in (0, 1]", amdahl.parallelEfficiency in 0.0..1.0)
    }

    @Test
    fun testThermalRCModel() {
        val config = ArchitectureConfig(
            tdpWatts = 150.0,
            thermalResistanceCPerWatt = 0.6,
            ambientTempC = 25.0
        )
        // Steady state temp = 25 + 150 * 0.6 = 115°C -> Will throttle at 95°C
        val thermal = SemiconductorSimulator.calculateThermalRC(config)
        assertTrue("High TDP configuration should predict throttling", thermal.willThrottle)
        assertTrue("Time to throttle should be positive", thermal.timeToThermalThrottleSec > 0.0)
        assertEquals(115.0, thermal.steadyStateJunctionTempC, 0.1)
    }

    @Test
    fun testIntegerKernelsExecution() {
        val mops = IntegerKernels.runIntegerAluThroughput(100_000)
        assertTrue("ALU throughput should be positive", mops > 0.0)

        val branchScore = IntegerKernels.runBranchPredictionTest(50_000)
        assertTrue("Branch score should be positive", branchScore > 0.0)

        val hashScore = IntegerKernels.runHashKernel(64 * 1024)
        assertTrue("Hash score should be positive", hashScore > 0.0)
    }

    @Test
    fun testFloatingPointKernelsExecution() {
        val fp32Gflops = FloatingPointKernels.runFp32MatrixMultiplication(32)
        assertTrue("FP32 GFLOP/s should be positive", fp32Gflops > 0.0)

        val fftGflops = FloatingPointKernels.runFastFourierTransform(512, 5)
        assertTrue("FFT GFLOP/s should be positive", fftGflops > 0.0)
    }

    @Test
    fun testMemoryKernelsExecution() {
        val triadGbps = MemoryKernels.runStreamTriad(50_000)
        assertTrue("Stream Triad GB/s should be positive", triadGbps > 0.0)

        val latencyNs = MemoryKernels.measurePointerChasingLatency(16 * 1024, iterations = 10_000)
        assertTrue("Cache latency should be positive", latencyNs > 0.0)
    }

    @Test
    fun testAiKernelsExecution() {
        val mmacs = AiKernels.runInt8AttentionGemm(seqLen = 32, headDim = 32, iterations = 5)
        assertTrue("INT8 MMAC/s should be positive", mmacs > 0.0)

        val tokensPerSec = AiKernels.runTokenGenerationBenchmark(contextLength = 64, targetTokens = 20)
        assertTrue("Tokens/sec should be positive", tokensPerSec > 0.0)
    }
}
