package com.example.siliconforge.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [BenchmarkRunEntity::class], version = 1, exportSchema = false)
abstract class SiliconForgeDatabase : RoomDatabase() {

    abstract fun benchmarkDao(): BenchmarkDao

    companion object {
        @Volatile
        private var INSTANCE: SiliconForgeDatabase? = null

        fun getDatabase(context: Context): SiliconForgeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SiliconForgeDatabase::class.java,
                    "silicon_forge_benchmarks.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
