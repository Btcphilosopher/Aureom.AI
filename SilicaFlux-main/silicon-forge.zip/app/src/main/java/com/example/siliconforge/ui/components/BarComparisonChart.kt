package com.example.siliconforge.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class BarComparisonItem(
    val label: String,
    val value: Double,
    val formattedValue: String,
    val isHighlighted: Boolean = false,
    val color: Color = CyanAccent
)

@Composable
fun BarComparisonChart(
    items: List<BarComparisonItem>,
    modifier: Modifier = Modifier,
    title: String? = null,
    unit: String = ""
) {
    val maxValue = (items.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(1.0)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
            .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        if (title != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextMuted,
                    letterSpacing = 0.6.sp,
                    modifier = Modifier.weight(1f)
                )
                if (unit.isNotBlank()) {
                    Text(
                        text = unit,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        items.forEach { item ->
            val fraction = (item.value / maxValue).toFloat().coerceIn(0.02f, 1f)
            val animatedFraction by animateFloatAsState(targetValue = fraction, label = "bar_width")

            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.label,
                        style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                        color = if (item.isHighlighted) TextPrimary else TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = item.formattedValue,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = if (item.isHighlighted) item.color else TextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(SiliconPanelElevated)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedFraction)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (item.isHighlighted) item.color else item.color.copy(alpha = 0.5f))
                    )
                }
            }
        }
    }
}
