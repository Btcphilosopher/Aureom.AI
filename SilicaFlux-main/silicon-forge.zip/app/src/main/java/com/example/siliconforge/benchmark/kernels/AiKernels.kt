package com.example.siliconforge.benchmark.kernels

import java.util.Random

object AiKernels {

    @Volatile
    var blackHoleSink: Long = 0L

    /**
     * Quantized INT8 Attention Matrix Multiplication (Q x K^T)
     * Simulates a multi-head attention projection (batch=1, seq_len=128, dim=64).
     * Measures INT8 MACs (Multiply-Accumulate) throughput.
     */
    fun runInt8AttentionGemm(seqLen: Int = 128, headDim: Int = 64, iterations: Int = 120): Double {
        val q = ByteArray(seqLen * headDim) { ((it * 3) and 0x7F).toByte() }
        val k = ByteArray(seqLen * headDim) { ((it * 7) and 0x7F).toByte() }
        val scores = IntArray(seqLen * seqLen)

        val start = System.nanoTime()
        for (rep in 0 until iterations) {
            for (i in 0 until seqLen) {
                val rowQ = i * headDim
                for (j in 0 until seqLen) {
                    val rowK = j * headDim
                    var acc = 0
                    for (d in 0 until headDim) {
                        acc += q[rowQ + d].toInt() * k[rowK + d].toInt()
                    }
                    scores[i * seqLen + j] = acc
                }
            }
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = scores[0].toLong() + scores[seqLen * seqLen - 1].toLong()

        val elapsedSec = elapsedNs / 1_000_000_000.0
        // MACs = seqLen * seqLen * headDim operations per repetition
        val totalMacs = seqLen.toDouble() * seqLen.toDouble() * headDim.toDouble() * iterations.toDouble()
        val megaMacs = (totalMacs / 1_000_000.0)
        return megaMacs / elapsedSec // MMAC/s (Mega-MACs per second)
    }

    /**
     * Autoregressive Token Generation Throughput
     * Simulates KV-cache lookup, linear projection, and softmax top-1 sampling.
     * Returns generated tokens / second.
     */
    fun runTokenGenerationBenchmark(contextLength: Int = 512, targetTokens: Int = 250): Double {
        val rand = Random(42)
        val hiddenDim = 256
        val stateVector = FloatArray(hiddenDim) { rand.nextFloat() }
        val projectionWeights = FloatArray(hiddenDim * 64) { (rand.nextFloat() - 0.5f) * 0.1f }

        val start = System.nanoTime()
        var tokenCount = 0
        while (tokenCount < targetTokens) {
            // Simulated token step: vector-matrix projection
            var maxVal = -Float.MAX_VALUE
            var bestIdx = 0
            for (row in 0 until 64) {
                var dot = 0f
                val wOffset = row * hiddenDim
                for (col in 0 until hiddenDim) {
                    dot += stateVector[col] * projectionWeights[wOffset + col]
                }
                if (dot > maxVal) {
                    maxVal = dot
                    bestIdx = row
                }
            }
            // Update state with selected token
            stateVector[bestIdx % hiddenDim] += 0.05f
            tokenCount++
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = tokenCount.toLong() + stateVector[0].toLong()

        val elapsedSec = elapsedNs / 1_000_000_000.0
        return tokenCount.toDouble() / elapsedSec // Tokens per second
    }
}
