package com.example.siliconforge.model

data class CpuCoreInfo(
    val coreIndex: Int,
    val clusterType: CoreClusterType, // PRIME, PERFORMANCE, EFFICIENCY
    val curFreqKHz: Long,
    val minFreqKHz: Long,
    val maxFreqKHz: Long,
    val governor: String = "schedutil",
    val isOnline: Boolean = true
)

enum class CoreClusterType {
    PRIME,
    PERFORMANCE,
    EFFICIENCY,
    UNKNOWN
}

data class CacheHierarchy(
    val l1iSizeKB: Int,
    val l1dSizeKB: Int,
    val l2SizeKB: Int,
    val l3SizeKB: Int,
    val l1LatencyNs: Double = 1.0,
    val l2LatencyNs: Double = 3.5,
    val l3LatencyNs: Double = 12.0
)

data class GpuInfo(
    val renderer: String,
    val vendor: String,
    val version: String,
    val glslVersion: String,
    val extensionsCount: Int,
    val isAvailable: Boolean
)

data class MemoryInfo(
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val swapTotalBytes: Long,
    val swapFreeBytes: Long,
    val pageSizeBytes: Long = 4096
) {
    val totalRamMB: Long get() = totalRamBytes / (1024 * 1024)
    val availableRamMB: Long get() = availableRamBytes / (1024 * 1024)
    val usedRamMB: Long get() = totalRamMB - availableRamMB
    val usagePercent: Float get() = if (totalRamBytes > 0) ((totalRamBytes - availableRamBytes).toFloat() / totalRamBytes.toFloat()) * 100f else 0f
}

data class TelemetrySnapshot(
    val timestamp: Long = System.currentTimeMillis(),
    val batteryPercent: Int = 100,
    val batteryTemperatureC: Float = 25.0f,
    val batteryVoltageMv: Int = 4000,
    val currentNowMicroAmp: Long = 0,
    val thermalStatus: String = "NORMAL", // NORMAL, LIGHT, MODERATE, SEVERE, CRITICAL
    val isThrottling: Boolean = false,
    val cpuFrequenciesKHz: List<Long> = emptyList(),
    val memoryUsagePercent: Float = 0f
)

data class HardwareSnapshot(
    val socModel: String,
    val vendor: String,
    val abi: String,
    val coreCount: Int,
    val cores: List<CpuCoreInfo>,
    val cpuFeatures: List<String>,
    val bogoMips: String,
    val kernelVersion: String,
    val cacheHierarchy: CacheHierarchy,
    val memory: MemoryInfo,
    val gpu: GpuInfo,
    val osBuild: String,
    val isVirtualMachine: Boolean = false
)
