package com.example.siliconforge.simulation

import com.example.siliconforge.model.AmdahlResult
import com.example.siliconforge.model.ArchitectureConfig
import com.example.siliconforge.model.ChipletModelResult
import com.example.siliconforge.model.RooflinePoint
import com.example.siliconforge.model.RooflineResult
import com.example.siliconforge.model.SimulationResult
import com.example.siliconforge.model.ThermalRCResult
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min

object SemiconductorSimulator {

    const val SIMULATION_DISCLAIMER = "SIMULATED — NOT MEASURED ON PHYSICAL SILICON"

    fun simulate(config: ArchitectureConfig, targetParallelFraction: Double = 0.94): SimulationResult {
        val roofline = calculateRoofline(config)
        val amdahl = calculateAmdahl(config.coreCount, targetParallelFraction)
        val chiplet = calculateChipletModel(config)
        val thermal = calculateThermalRC(config)

        return SimulationResult(
            config = config,
            roofline = roofline,
            amdahl = amdahl,
            chiplet = chiplet,
            thermal = thermal
        )
    }

    /**
     * Calculates Williams et al. Roofline Model
     * Peak Compute (GFLOP/s) = CoreCount * Clock (GHz) * ExecutionWidth * IPC_Factor
     */
    fun calculateRoofline(config: ArchitectureConfig): RooflineResult {
        // FMA (Fused Multiply Add) provides 2 FLOPs per execution port
        val peakComputeGFlops = config.coreCount * config.clockGhz * config.executionWidth * 2.0
        val peakMemoryBandwidthGBps = config.memoryBandwidthGbps

        // Ridge Point (FLOP/Byte) = Peak Compute / Memory Bandwidth
        val ridgePoint = if (peakMemoryBandwidthGBps > 0.0) peakComputeGFlops / peakMemoryBandwidthGBps else 1.0

        // Generate roofline curve points across arithmetic intensity from 0.0625 to 64 FLOP/Byte
        val testIntensities = listOf(0.0625, 0.125, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0)
        val curvePoints = testIntensities.map { intensity ->
            val memBoundGFlops = intensity * peakMemoryBandwidthGBps
            val attainable = min(peakComputeGFlops, memBoundGFlops)
            RooflinePoint(
                operationalIntensityFlopPerByte = intensity,
                attainableGFlops = attainable,
                isMemoryBound = memBoundGFlops < peakComputeGFlops
            )
        }

        // Operational Point for standard Matrix GEMM (Arithmetic Intensity ~ 4.0 FLOP/Byte)
        val opIntensity = 4.0
        val opAttainable = min(peakComputeGFlops, opIntensity * peakMemoryBandwidthGBps)
        val opPoint = RooflinePoint(
            operationalIntensityFlopPerByte = opIntensity,
            attainableGFlops = opAttainable,
            isMemoryBound = opAttainable < peakComputeGFlops
        )

        return RooflineResult(
            peakComputeGFlops = peakComputeGFlops,
            peakMemoryBandwidthGBps = peakMemoryBandwidthGBps,
            ridgePointIntensity = ridgePoint,
            curvePoints = curvePoints,
            operationalPoint = opPoint
        )
    }

    /**
     * Amdahl's Law Speedup Curve
     * Speedup = 1 / ((1 - p) + p / N)
     */
    fun calculateAmdahl(coreCount: Int, parallelFraction: Double): AmdahlResult {
        val p = parallelFraction.coerceIn(0.5, 0.999)
        val maxCores = maxOf(64, coreCount * 2)

        val coreSteps = listOf(1, 2, 4, 8, 12, 16, 24, 32, 48, 64).filter { it <= maxCores }
        val scalingCurve = coreSteps.map { n ->
            val speedup = 1.0 / ((1.0 - p) + (p / n.toDouble()))
            Pair(n, speedup)
        }

        val theoreticalSpeedup = 1.0 / ((1.0 - p) + (p / coreCount.toDouble()))
        val parallelEfficiency = theoreticalSpeedup / coreCount.toDouble()

        return AmdahlResult(
            parallelFraction = p,
            theoreticalSpeedup = theoreticalSpeedup,
            parallelEfficiency = parallelEfficiency,
            scalingCurve = scalingCurve
        )
    }

    /**
     * Chiplet & NUMA Interconnect Latency & Contention Model
     */
    fun calculateChipletModel(config: ArchitectureConfig): ChipletModelResult {
        val localLatency = config.memoryLatencyNs
        val remoteLatency = localLatency + config.interconnectLatencyPenaltyNs
        val crossDieTrafficFraction = if (config.chipletCount > 1) {
            (config.chipletCount - 1).toDouble() / config.chipletCount.toDouble()
        } else {
            0.0
        }

        val crossDiePenalty = if (localLatency > 0) ((remoteLatency - localLatency) / localLatency) * 100.0 else 0.0
        // Interconnect saturation core threshold
        val bPerCore = config.memoryBandwidthGbps / config.coreCount.coerceAtLeast(1)
        val saturationCores = if (bPerCore > 0) (config.interconnectBandwidthGbps / (bPerCore * 1.5)).toInt() else config.coreCount

        val effectiveBw = if (config.chipletCount > 1) {
            config.memoryBandwidthGbps * (1.0 - (crossDieTrafficFraction * 0.15))
        } else {
            config.memoryBandwidthGbps
        }

        return ChipletModelResult(
            localMemoryLatencyNs = localLatency,
            remoteMemoryLatencyNs = remoteLatency,
            crossDiePenaltyPercent = crossDiePenalty,
            interconnectSaturationAtCoreCount = saturationCores.coerceIn(2, 128),
            effectiveAggregateBandwidthGBps = effectiveBw
        )
    }

    /**
     * First-Order RC Lumped Thermal Junction Model
     * T(t) = T_ambient + P * R_th * (1 - e^(-t / tau))
     * tau = R_th * C_th (Thermal time constant, typically ~12.0 seconds for silicon package)
     */
    fun calculateThermalRC(config: ArchitectureConfig, throttleThresholdC: Double = 95.0): ThermalRCResult {
        val ambient = config.ambientTempC
        val power = config.tdpWatts
        val rTh = config.thermalResistanceCPerWatt
        val tau = 14.0 // Package thermal time constant (seconds)

        val steadyStateTemp = ambient + (power * rTh)
        val willThrottle = steadyStateTemp >= throttleThresholdC

        val timeToThrottleSec = if (willThrottle && steadyStateTemp > ambient) {
            val ratio = (throttleThresholdC - ambient) / (steadyStateTemp - ambient)
            if (ratio < 1.0) -tau * ln(1.0 - ratio) else 0.0
        } else {
            Double.POSITIVE_INFINITY
        }

        // Generate 60-second heating trajectory
        val trajectory = (0..60 step 2).map { tSec ->
            val t = tSec.toDouble()
            val temp = ambient + (power * rTh) * (1.0 - exp(-t / tau))
            Pair(t, min(temp, throttleThresholdC + 3.0))
        }

        return ThermalRCResult(
            steadyStateJunctionTempC = steadyStateTemp,
            timeToThermalThrottleSec = if (willThrottle) timeToThrottleSec else -1.0,
            willThrottle = willThrottle,
            tempTrajectory = trajectory
        )
    }
}
