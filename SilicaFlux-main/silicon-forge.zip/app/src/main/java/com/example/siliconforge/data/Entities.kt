package com.example.siliconforge.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.example.siliconforge.model.BenchmarkCategory
import com.example.siliconforge.model.BenchmarkRun
import com.example.siliconforge.model.ProvenanceManifest

@Entity(tableName = "benchmark_runs")
data class BenchmarkRunEntity(
    @PrimaryKey val id: String,
    val benchmarkId: String,
    val benchmarkName: String,
    val category: String,
    val timestamp: Long,
    val threadCount: Int,
    val iterations: Int,
    val samplesCsv: String,
    val mean: Double,
    val median: Double,
    val stdDev: Double,
    val iqr: Double,
    val ci95Lower: Double,
    val ci95Upper: Double,
    val cvPercent: Double,
    val rawScore: Double,
    val unit: String,
    val normalizedScore: Double,
    val parallelEfficiency: Double,
    val initialTempC: Float,
    val peakTempC: Float,
    val throttlingDetected: Boolean,
    val validationHash: String,
    val engineVersion: String
) {
    fun toDomain(): BenchmarkRun {
        val sampleList = if (samplesCsv.isBlank()) emptyList() else samplesCsv.split(",").mapNotNull { it.toDoubleOrNull() }
        val cat = try {
            BenchmarkCategory.valueOf(category)
        } catch (_: Exception) {
            BenchmarkCategory.INTEGER
        }

        return BenchmarkRun(
            id = id,
            benchmarkId = benchmarkId,
            benchmarkName = benchmarkName,
            category = cat,
            timestamp = timestamp,
            threadCount = threadCount,
            iterations = iterations,
            samples = sampleList,
            mean = mean,
            median = median,
            stdDev = stdDev,
            iqr = iqr,
            ci95Lower = ci95Lower,
            ci95Upper = ci95Upper,
            cvPercent = cvPercent,
            rawScore = rawScore,
            unit = unit,
            normalizedScore = normalizedScore,
            parallelEfficiency = parallelEfficiency,
            initialTempC = initialTempC,
            peakTempC = peakTempC,
            throttlingDetected = throttlingDetected,
            validationHash = validationHash,
            provenance = ProvenanceManifest(engineVersion = engineVersion)
        )
    }

    companion object {
        fun fromDomain(run: BenchmarkRun): BenchmarkRunEntity {
            return BenchmarkRunEntity(
                id = run.id,
                benchmarkId = run.benchmarkId,
                benchmarkName = run.benchmarkName,
                category = run.category.name,
                timestamp = run.timestamp,
                threadCount = run.threadCount,
                iterations = run.iterations,
                samplesCsv = run.samples.joinToString(","),
                mean = run.mean,
                median = run.median,
                stdDev = run.stdDev,
                iqr = run.iqr,
                ci95Lower = run.ci95Lower,
                ci95Upper = run.ci95Upper,
                cvPercent = run.cvPercent,
                rawScore = run.rawScore,
                unit = run.unit,
                normalizedScore = run.normalizedScore,
                parallelEfficiency = run.parallelEfficiency,
                initialTempC = run.initialTempC,
                peakTempC = run.peakTempC,
                throttlingDetected = run.throttlingDetected,
                validationHash = run.validationHash,
                engineVersion = run.provenance.engineVersion
            )
        }
    }
}
