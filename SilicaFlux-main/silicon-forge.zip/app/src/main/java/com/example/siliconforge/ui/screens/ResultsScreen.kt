package com.example.siliconforge.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.BenchmarkRun
import com.example.siliconforge.ui.components.LineGraph
import com.example.siliconforge.ui.components.MetricsCard
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalCritical
import com.example.ui.theme.ThermalWarning

@Composable
fun ResultsScreen(
    runs: List<BenchmarkRun>,
    onExportJson: () -> String,
    onExportCsv: () -> String,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedRun by remember(runs) { mutableStateOf(runs.firstOrNull()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .padding(16.dp)
    ) {
        // Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Assessment, contentDescription = null, tint = CyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("RESULTS & STATISTICAL ANALYTICS", style = MaterialTheme.typography.titleLarge, fontSize = 18.sp)
                Text("${runs.size} validated records with bootstrap CI and provenance", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Export & Clear History Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    val json = onExportJson()
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("SiliconForge JSON", json))
                    Toast.makeText(context, "JSON exported & copied to clipboard", Toast.LENGTH_SHORT).show()
                },
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("export_json_button")
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.height(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Export JSON", fontSize = 11.sp)
            }

            OutlinedButton(
                onClick = {
                    val csv = onExportCsv()
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("SiliconForge CSV", csv))
                    Toast.makeText(context, "CSV exported & copied to clipboard", Toast.LENGTH_SHORT).show()
                },
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("export_csv_button")
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.height(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Export CSV", fontSize = 11.sp)
            }

            if (runs.isNotEmpty()) {
                OutlinedButton(
                    onClick = onClearHistory,
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ThermalCritical),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ThermalCritical.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.height(14.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (runs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
                    .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No benchmark runs recorded in local database.", style = MaterialTheme.typography.bodyLarge, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Run tests from the Benchmark Laboratory to build your statistical dataset.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Detailed Breakdown of Selected Run
                selectedRun?.let { run ->
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, CyanAccent.copy(alpha = 0.8f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TechnicalBadge(text = run.category.name, color = CyanAccent)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${run.threadCount}T Execution",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 11.sp,
                                        color = CircuitGold
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    TechnicalBadge(
                                        text = if (run.cvPercent < 2.0) "HIGH REPEATABILITY" else if (run.cvPercent < 5.0) "STABLE" else "HIGH VARIANCE",
                                        color = if (run.cvPercent < 2.0) SiliconEmerald else if (run.cvPercent < 5.0) CircuitGold else ThermalWarning
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(run.benchmarkName, style = MaterialTheme.typography.titleLarge, fontSize = 16.sp)

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = String.format("%.2f", run.rawScore),
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 28.sp,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = run.unit,
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 14.sp,
                                        color = CyanAccent,
                                        modifier = Modifier.padding(bottom = 3.dp)
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text(
                                        text = "SCORE: ${run.normalizedScore.toInt()}",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 14.sp,
                                        color = CircuitGold,
                                        modifier = Modifier.padding(bottom = 3.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Statistical Confidence Interval Whiskers & Moments
                                Text("STATISTICAL DISPERSION (1,000 BOOTSTRAP REPLICATES)", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                                Spacer(modifier = Modifier.height(4.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(SiliconPanelElevated, RoundedCornerShape(6.dp))
                                        .padding(10.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            Text("95% Confidence Interval:", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                                            Text("[${String.format("%.2f", run.ci95Lower)}, ${String.format("%.2f", run.ci95Upper)}] ${run.unit}", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = CyanAccent)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            Text("Mean ± StdDev:", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                                            Text("${String.format("%.2f", run.mean)} ± ${String.format("%.2f", run.stdDev)} (CV: ${String.format("%.2f", run.cvPercent)}%)", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextPrimary)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            Text("Interquartile Range (IQR):", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                                            Text("${String.format("%.2f", run.iqr)} ${run.unit}", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextPrimary)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            Text("Thermal Delta:", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                                            Text("${String.format("%.1f", run.initialTempC)}°C -> ${String.format("%.1f", run.peakTempC)}°C", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = if (run.throttlingDetected) ThermalCritical else SiliconEmerald)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Trial Samples Line Graph
                                if (run.samples.size > 1) {
                                    Text("TRIAL SAMPLE SEQUENCE", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LineGraph(
                                        dataPoints = run.samples.map { it.toFloat() },
                                        lineColor = ElectricBlue,
                                        modifier = Modifier.height(90.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }

                                // Provenance & Reproducibility Footprint
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Verified, contentDescription = null, tint = SiliconEmerald, modifier = Modifier.height(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${run.provenance.engineVersion} • ${run.validationHash}",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 10.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "HISTORICAL RUN DATABASE (${runs.size})",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = TextMuted,
                        letterSpacing = 0.8.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                items(runs, key = { it.id }) { itemRun ->
                    val isSelected = selectedRun?.id == itemRun.id
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) SiliconPanelElevated else SiliconDarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) CyanAccent else SiliconBorder),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedRun = itemRun }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(itemRun.benchmarkName, style = MaterialTheme.typography.titleMedium, fontSize = 13.sp)
                                Text(
                                    text = "${itemRun.threadCount}T • ${itemRun.iterations} Trials • CV: ${String.format("%.1f", itemRun.cvPercent)}%",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${String.format("%.2f", itemRun.rawScore)} ${itemRun.unit}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 13.sp,
                                    color = CyanAccent
                                )
                                Text(
                                    text = "Score: ${itemRun.normalizedScore.toInt()}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    color = CircuitGold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
