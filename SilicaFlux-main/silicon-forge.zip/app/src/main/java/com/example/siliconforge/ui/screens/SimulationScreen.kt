package com.example.siliconforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.ArchitectureConfig
import com.example.siliconforge.simulation.SemiconductorSimulator
import com.example.siliconforge.ui.components.LineGraph
import com.example.siliconforge.ui.components.MetricsCard
import com.example.siliconforge.ui.components.RooflineChart
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalCritical
import com.example.ui.theme.ThermalWarning

@Composable
fun SimulationScreen(
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Configurable Architecture Parameters
    var coreCount by remember { mutableIntStateOf(16) }
    var clockGhz by remember { mutableDoubleStateOf(3.8) }
    var executionWidth by remember { mutableIntStateOf(8) }
    var memoryBandwidth by remember { mutableDoubleStateOf(128.0) }
    var chipletCount by remember { mutableIntStateOf(2) }
    var tdpWatts by remember { mutableDoubleStateOf(65.0) }
    var parallelFraction by remember { mutableFloatStateOf(0.95f) }

    val config = ArchitectureConfig(
        architectureName = "Parametric Microarchitecture Model",
        coreCount = coreCount,
        clockGhz = clockGhz,
        executionWidth = executionWidth,
        memoryBandwidthGbps = memoryBandwidth,
        chipletCount = chipletCount,
        tdpWatts = tdpWatts
    )

    val simResult = remember(config, parallelFraction) {
        SemiconductorSimulator.simulate(config, parallelFraction.toDouble())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Screen Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Architecture, contentDescription = null, tint = CyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("SEMICONDUCTOR SIMULATION LABORATORY", style = MaterialTheme.typography.titleLarge, fontSize = 17.sp)
                Text("Analytical modeling of hypothetical microarchitectures", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Mandatory Simulation Warning Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ThermalWarning.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .border(1.dp, ThermalWarning, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = ThermalWarning)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "SIMULATED — NOT MEASURED ON PHYSICAL SILICON",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        fontSize = 11.sp,
                        color = ThermalWarning
                    )
                    Text(
                        text = "Analytical models predict theoretical limits under given architectural assumptions.",
                        fontSize = 11.sp,
                        color = TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Architectural Controls Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("ARCHITECTURAL PARAMETERS", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextMuted)
                Spacer(modifier = Modifier.height(10.dp))

                // Core Count Slider
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Cores: $coreCount", fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp, color = TextPrimary, modifier = Modifier.width(100.dp))
                    Slider(
                        value = coreCount.toFloat(),
                        onValueChange = { coreCount = it.toInt() },
                        valueRange = 1f..64f,
                        steps = 63,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                    )
                }

                // Clock Frequency Slider
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Clock: ${String.format("%.1f", clockGhz)} GHz", fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp, color = TextPrimary, modifier = Modifier.width(100.dp))
                    Slider(
                        value = clockGhz.toFloat(),
                        onValueChange = { clockGhz = it.toDouble() },
                        valueRange = 1.0f..6.0f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = ElectricBlue)
                    )
                }

                // Memory Bandwidth Slider
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("DRAM: ${memoryBandwidth.toInt()} GB/s", fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp, color = TextPrimary, modifier = Modifier.width(100.dp))
                    Slider(
                        value = memoryBandwidth.toFloat(),
                        onValueChange = { memoryBandwidth = it.toDouble() },
                        valueRange = 20.0f..512.0f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = CircuitGold, activeTrackColor = CircuitGold)
                    )
                }

                // TDP Watts Slider
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("TDP: ${tdpWatts.toInt()} Watts", fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp, color = TextPrimary, modifier = Modifier.width(100.dp))
                    Slider(
                        value = tdpWatts.toFloat(),
                        onValueChange = { tdpWatts = it.toDouble() },
                        valueRange = 5.0f..250.0f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = ThermalWarning, activeTrackColor = ThermalWarning)
                    )
                }

                // Chiplet Configuration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 2, 4, 8).forEach { chips ->
                        val sel = chipletCount == chips
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (sel) CyanAccent else SiliconPanelElevated, RoundedCornerShape(4.dp))
                                .border(1.dp, if (sel) CyanAccent else SiliconBorder, RoundedCornerShape(4.dp))
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            androidx.compose.foundation.text.BasicText(
                                text = if (chips == 1) "Monolithic" else "$chips Chiplets",
                                style = androidx.compose.ui.text.TextStyle(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    color = if (sel) androidx.compose.ui.graphics.Color(0xFF032830) else TextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Williams Roofline Analysis
        RooflineChart(roofline = simResult.roofline)

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Amdahl's Law Speedup Model
        Card(
            colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("AMDAHL'S LAW PARALLEL SCALING", fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                    TechnicalBadge(text = "${String.format("%.1f", parallelFraction * 100)}% PARALLEL", color = ElectricBlue)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Workload Parallel Fraction:", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.width(8.dp))
                    Slider(
                        value = parallelFraction,
                        onValueChange = { parallelFraction = it },
                        valueRange = 0.50f..0.99f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = ElectricBlue)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricsCard(
                        title = "Amdahl Speedup",
                        value = "${String.format("%.2f", simResult.amdahl.theoreticalSpeedup)}x",
                        unit = "Speedup",
                        subtitle = "Over single-core baseline",
                        accentColor = ElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                    MetricsCard(
                        title = "Parallel Efficiency",
                        value = "${String.format("%.1f", simResult.amdahl.parallelEfficiency * 100)}%",
                        unit = "Efficiency",
                        subtitle = "Speedup / $coreCount cores",
                        accentColor = SiliconEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Chiplet Interconnect Latency & Saturation
        Card(
            colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("CHIPLET INTERCONNECT & NUMA BEHAVIOUR", fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricsCard(
                        title = "Cross-Die Latency",
                        value = "${String.format("%.1f", simResult.chiplet.remoteMemoryLatencyNs)}",
                        unit = "ns",
                        subtitle = "+${String.format("%.0f", simResult.chiplet.crossDiePenaltyPercent)}% NUMA penalty",
                        accentColor = CircuitGold,
                        modifier = Modifier.weight(1f)
                    )
                    MetricsCard(
                        title = "Saturation Core Limit",
                        value = "${simResult.chiplet.interconnectSaturationAtCoreCount}",
                        unit = "Cores",
                        subtitle = "Bus saturation threshold",
                        accentColor = CyanAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. First-Order RC Thermal Junction Heating Model
        Card(
            colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("RC THERMAL JUNCTION PREDICTION", fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                    TechnicalBadge(
                        text = if (simResult.thermal.willThrottle) "THROTTLE PREDICTED" else "STEADY STATE SAFE",
                        color = if (simResult.thermal.willThrottle) ThermalCritical else SiliconEmerald
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Steady State Temp: ${String.format("%.1f", simResult.thermal.steadyStateJunctionTempC)}°C" +
                            if (simResult.thermal.willThrottle) " (Throttles in ~${String.format("%.1f", simResult.thermal.timeToThermalThrottleSec)}s)" else "",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.sp,
                    color = if (simResult.thermal.willThrottle) ThermalCritical else SiliconEmerald
                )

                Spacer(modifier = Modifier.height(8.dp))

                LineGraph(
                    dataPoints = simResult.thermal.tempTrajectory.map { it.second.toFloat() },
                    lineColor = if (simResult.thermal.willThrottle) ThermalCritical else CyanAccent,
                    minY = 20f,
                    maxY = 110f,
                    modifier = Modifier.height(110.dp)
                )
            }
        }
    }
}
