package com.example.siliconforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SettingsSystemDaydream
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.CoreClusterType
import com.example.siliconforge.model.HardwareSnapshot
import com.example.siliconforge.ui.components.MetricsCard
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalWarning

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HardwareScreen(
    hardware: HardwareSnapshot,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Section Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DeveloperBoard, contentDescription = null, tint = CyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("HARDWARE EXPLORER", style = MaterialTheme.typography.titleLarge, fontSize = 18.sp)
                Text("Silicon microarchitecture topology & physical capabilities", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // CPU Core Cluster Topology
        Text(
            text = "CPU CLUSTER TOPOLOGY (${hardware.coreCount} LOGICAL / PHYSICAL CORES)",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            hardware.cores.forEach { core ->
                val (clusterLabel, badgeColor) = when (core.clusterType) {
                    CoreClusterType.PRIME -> "PRIME CORE" to CircuitGold
                    CoreClusterType.PERFORMANCE -> "PERF CORE" to ElectricBlue
                    CoreClusterType.EFFICIENCY -> "EFFICIENCY" to SiliconEmerald
                    CoreClusterType.UNKNOWN -> "CORE" to TextMuted
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CPU ${core.coreIndex}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 14.sp,
                            color = TextPrimary,
                            modifier = Modifier.width(64.dp)
                        )
                        TechnicalBadge(text = clusterLabel, color = badgeColor)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${core.curFreqKHz / 1000} MHz",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 13.sp,
                                color = CyanAccent
                            )
                            Text(
                                text = "Range: ${core.minFreqKHz / 1000} - ${core.maxFreqKHz / 1000} MHz • ${core.governor}",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                        TechnicalBadge(
                            text = if (core.isOnline) "ONLINE" else "OFFLINE",
                            color = if (core.isOnline) SiliconEmerald else ThermalWarning
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cache Hierarchy Breakdown
        Text(
            text = "CACHE SUBSYSTEM HIERARCHY",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricsCard(
                title = "L1I / L1D",
                value = "${hardware.cacheHierarchy.l1iSizeKB}K / ${hardware.cacheHierarchy.l1dSizeKB}K",
                unit = "",
                subtitle = "~${hardware.cacheHierarchy.l1LatencyNs} ns latency",
                accentColor = CyanAccent,
                modifier = Modifier.weight(1f)
            )
            MetricsCard(
                title = "L2 Cache",
                value = "${hardware.cacheHierarchy.l2SizeKB} KB",
                unit = "",
                subtitle = "~${hardware.cacheHierarchy.l2LatencyNs} ns latency",
                accentColor = ElectricBlue,
                modifier = Modifier.weight(1f)
            )
            MetricsCard(
                title = "L3 / LLC",
                value = "${hardware.cacheHierarchy.l3SizeKB / 1024} MB",
                unit = "",
                subtitle = "~${hardware.cacheHierarchy.l3LatencyNs} ns latency",
                accentColor = CircuitGold,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // GPU & Acceleration Adapter
        Text(
            text = "GRAPHICS & COMPUTE ACCELERATOR",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
                .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = hardware.gpu.renderer,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 14.sp,
                        color = CyanAccent,
                        modifier = Modifier.weight(1f)
                    )
                    TechnicalBadge(
                        text = if (hardware.gpu.isAvailable) "EGL ACTIVE" else "FALLBACK",
                        color = if (hardware.gpu.isAvailable) SiliconEmerald else ThermalWarning
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Vendor: ${hardware.gpu.vendor}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = "Version: ${hardware.gpu.version}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = "Shading Language: ${hardware.gpu.glslVersion} (${hardware.gpu.extensionsCount} extensions registered)",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // CPU Instruction Set Extensions
        Text(
            text = "CPU INSTRUCTION SET EXTENSIONS & REGISTERS",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
                .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                hardware.cpuFeatures.forEach { feature ->
                    TechnicalBadge(
                        text = feature.uppercase(),
                        color = when {
                            feature.contains("neon", true) || feature.contains("simd", true) || feature.contains("sve", true) -> CircuitGold
                            feature.contains("fp", true) || feature.contains("fma", true) -> ElectricBlue
                            feature.contains("aes", true) || feature.contains("sha", true) -> CyanAccent
                            else -> TextSecondary
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Operating System & Kernel Environment
        Text(
            text = "EXECUTION RUNTIME & OS PROVENANCE",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
                .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Build: ${hardware.osBuild}", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextSecondary)
                Text("Kernel: ${hardware.kernelVersion}", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextMuted)
                Text("BogoMIPS: ${hardware.bogoMips}", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextMuted)
                Text("Page Size: ${hardware.memory.pageSizeBytes} bytes", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextMuted)
            }
        }
    }
}
