package com.example.siliconforge.benchmark.kernels

import java.util.Random

object IntegerKernels {

    @Volatile
    var blackHoleSink: Long = 0L

    /**
     * 64-bit ALU & Bitwise throughput
     * Prevents compiler constant folding and dead code elimination using chained state.
     */
    fun runIntegerAluThroughput(iterations: Int = 15_000_000): Double {
        var stateA = 0x123456789ABCDEF0L
        var stateB = 0x7EDCBA9876543210L
        var accumulator = 0L

        val start = System.nanoTime()
        for (i in 0 until iterations) {
            // Unrolled 64-bit integer arithmetic and bit manipulation
            stateA = (stateA xor (stateA shl 13)) xor (stateA ushr 7) xor (stateA shl 17)
            stateB = (stateB + 0x7E3779B97F4A7C15L) xor (stateA ushr 11)
            val mixed = (stateA * 6364136223846793005L) + stateB
            accumulator = accumulator xor (mixed rotatedLeft (i and 63))
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = accumulator xor stateA xor stateB

        val elapsedSec = elapsedNs / 1_000_000_000.0
        val operations = iterations.toDouble() * 6.0 // 6 ALU ops per loop
        return (operations / 1_000_000.0) / elapsedSec // MegaOperations / sec (MOP/s)
    }

    /**
     * Branch Prediction Penalty Characterisation
     * Compares 50% alternating pseudo-random branches against 100% predictable branches.
     */
    fun runBranchPredictionTest(iterations: Int = 10_000_000): Double {
        val rand = Random(1337)
        val branchArray = BooleanArray(2048) { rand.nextBoolean() }
        var sumPredictable = 0L
        var sumUnpredictable = 0L

        // Predictable run (100% true branch)
        val t0 = System.nanoTime()
        for (i in 0 until iterations) {
            if (i >= 0) { // Always true
                sumPredictable += i and 15
            } else {
                sumPredictable -= i and 15
            }
        }
        val predictableTimeNs = System.nanoTime() - t0

        // Unpredictable run (50% random mispredict pattern)
        val t1 = System.nanoTime()
        for (i in 0 until iterations) {
            val cond = branchArray[i and 2047]
            if (cond) {
                sumUnpredictable += i and 15
            } else {
                sumUnpredictable -= i and 15
            }
        }
        val unpredictableTimeNs = System.nanoTime() - t1

        blackHoleSink = sumPredictable xor sumUnpredictable

        val predictableMops = (iterations / 1_000_000.0) / (predictableTimeNs / 1_000_000_000.0)
        val unpredictableMops = (iterations / 1_000_000.0) / (unpredictableTimeNs / 1_000_000_000.0)

        return unpredictableMops // Report throughput under branch pressure (MOP/s)
    }

    /**
     * Fast 64-bit Non-Cryptographic Hash (Murmur3/xxHash mixing)
     */
    fun runHashKernel(bufferSizeBytes: Int = 4 * 1024 * 1024): Double {
        val buffer = ByteArray(bufferSizeBytes) { (it and 0xFF).toByte() }
        var h: Long = 0x4BF29CE484222325L
        val prime: Long = 0x100000001B3L

        val start = System.nanoTime()
        var i = 0
        while (i < buffer.size) {
            val b: Long = buffer[i].toLong()
            h = (h xor b) * prime
            h = h xor (h ushr 33)
            i++
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = h
        val elapsedSec = elapsedNs / 1_000_000_000.0
        val mBytes = bufferSizeBytes / (1024.0 * 1024.0)
        return mBytes / elapsedSec // MB/s hash throughput
    }

    /**
     * Sorting & Cache-Miss Memory Graph Traversal
     */
    fun runSortAndSearchKernel(size: Int = 100_000): Double {
        val rand = Random(42)
        val array = IntArray(size) { rand.nextInt() }

        val start = System.nanoTime()
        array.sort() // Dual-pivot quicksort

        var searchSink = 0
        for (k in 0 until 50_000) {
            val target = rand.nextInt()
            val idx = array.binarySearch(target)
            searchSink += idx
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = searchSink.toLong()
        val elapsedSec = elapsedNs / 1_000_000_000.0
        return (150_000.0 / 1_000.0) / elapsedSec // KiloOperations / sec
    }

    private infix fun Long.rotatedLeft(bits: Int): Long {
        val b = bits and 63
        return (this shl b) or (this ushr (64 - b))
    }
}
