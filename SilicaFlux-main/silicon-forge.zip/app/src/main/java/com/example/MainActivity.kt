package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.siliconforge.ui.SiliconForgeApp
import com.example.siliconforge.ui.SiliconForgeViewModel
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconForgeTheme

class MainActivity : ComponentActivity() {

    private val viewModel: SiliconForgeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SiliconForgeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SiliconDeepSlate
                ) {
                    SiliconForgeApp(viewModel = viewModel)
                }
            }
        }
    }
}
