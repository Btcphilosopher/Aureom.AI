package com.example.siliconforge.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface

@Composable
fun LineGraph(
    dataPoints: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: Color = CyanAccent,
    fillColor: Color = lineColor.copy(alpha = 0.15f),
    minY: Float? = null,
    maxY: Float? = null,
    strokeWidth: Float = 3f,
    showPoints: Boolean = true
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
            .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            if (dataPoints.isEmpty()) return@Canvas

            val effectiveMinY = minY ?: (dataPoints.minOrNull() ?: 0f)
            val effectiveMaxY = (maxY ?: (dataPoints.maxOrNull() ?: 100f)).let { if (it == effectiveMinY) it + 1f else it }
            val rangeY = effectiveMaxY - effectiveMinY

            val w = size.width
            val h = size.height

            // Draw subtle horizontal grid lines (3 divisions)
            val gridColor = SiliconBorder.copy(alpha = 0.4f)
            for (step in 0..3) {
                val y = h * (step / 3f)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
            }

            if (dataPoints.size < 2) {
                val y = h - ((dataPoints[0] - effectiveMinY) / rangeY) * h
                drawCircle(color = lineColor, radius = 5f, center = Offset(w / 2f, y))
                return@Canvas
            }

            val stepX = w / (dataPoints.size - 1)
            val path = Path()
            val fillPath = Path()

            dataPoints.forEachIndexed { idx, value ->
                val x = idx * stepX
                val normalizedY = ((value - effectiveMinY) / rangeY).coerceIn(0f, 1f)
                val y = h - (normalizedY * h)

                if (idx == 0) {
                    path.moveTo(x, y)
                    fillPath.moveTo(x, h)
                    fillPath.lineTo(x, y)
                } else {
                    path.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
            }

            fillPath.lineTo(w, h)
            fillPath.close()

            // Draw translucent gradient fill under the line
            drawPath(path = fillPath, color = fillColor)

            // Draw crisp line
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Draw dots at sample points
            if (showPoints) {
                dataPoints.forEachIndexed { idx, value ->
                    val x = idx * stepX
                    val normalizedY = ((value - effectiveMinY) / rangeY).coerceIn(0f, 1f)
                    val y = h - (normalizedY * h)
                    drawCircle(color = SiliconDarkSurface, radius = 4f, center = Offset(x, y))
                    drawCircle(color = lineColor, radius = 3f, center = Offset(x, y))
                }
            }
        }
    }
}
