package com.example.siliconforge.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.RooflineResult
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalWarning
import kotlin.math.ln
import kotlin.math.min

@Composable
fun RooflineChart(
    roofline: RooflineResult,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
            .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ROOFLINE PERFORMANCE CEILING",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 12.sp,
                color = TextSecondary,
                letterSpacing = 0.5.sp,
                modifier = Modifier.weight(1f)
            )
            TechnicalBadge(
                text = "SIMULATED",
                color = ThermalWarning,
                backgroundColor = ThermalWarning.copy(alpha = 0.15f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val w = size.width
                val h = size.height

                // Margin for axis
                val padL = 40f
                val padB = 30f
                val chartW = w - padL - 10f
                val chartH = h - padB - 10f

                // Log scale range: X from 0.0625 (2^-4) to 64 (2^6) => ln(64) - ln(0.0625)
                val minLogX = ln(0.0625)
                val maxLogX = ln(64.0)
                val rangeLogX = maxLogX - minLogX

                // Y scale: Peak compute GFLOPs * 1.25 as top
                val maxCompute = roofline.peakComputeGFlops.coerceAtLeast(10.0) * 1.2
                val minLogY = ln(1.0)
                val maxLogY = ln(maxCompute)
                val rangeLogY = maxLogY - minLogY

                fun mapX(intensity: Double): Float {
                    val logVal = ln(intensity.coerceIn(0.0625, 64.0))
                    val norm = ((logVal - minLogX) / rangeLogX).toFloat()
                    return padL + norm * chartW
                }

                fun mapY(gflops: Double): Float {
                    val logVal = ln(gflops.coerceIn(1.0, maxCompute))
                    val norm = ((logVal - minLogY) / rangeLogY).toFloat().coerceIn(0f, 1f)
                    return (h - padB) - norm * chartH
                }

                // Grid lines
                val gridColor = SiliconBorder.copy(alpha = 0.4f)
                drawLine(gridColor, Offset(padL, h - padB), Offset(w, h - padB), 1.5f) // X axis
                drawLine(gridColor, Offset(padL, 10f), Offset(padL, h - padB), 1.5f) // Y axis

                // Draw Roofline Curve
                val curvePath = Path()
                val ridgeX = roofline.ridgePointIntensity
                val peakY = roofline.peakComputeGFlops

                // 1. Diagonal Memory-Bound Section (from 0.0625 to ridgeX)
                val startX = mapX(0.0625)
                val startY = mapY(0.0625 * roofline.peakMemoryBandwidthGBps)
                val ridgePixelX = mapX(ridgeX)
                val ridgePixelY = mapY(peakY)

                curvePath.moveTo(startX, startY)
                curvePath.lineTo(ridgePixelX, ridgePixelY)

                // 2. Horizontal Compute-Bound Section (from ridgeX to 64.0)
                val endX = mapX(64.0)
                curvePath.lineTo(endX, ridgePixelY)

                // Draw the Roofline contour
                drawPath(
                    path = curvePath,
                    color = CircuitGold,
                    style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                )

                // Draw Ridge Point Indicator
                drawCircle(color = CircuitGold, radius = 5f, center = Offset(ridgePixelX, ridgePixelY))

                // Operational Point (e.g. GEMM with intensity ~4.0 FLOP/Byte)
                val opX = mapX(roofline.operationalPoint.operationalIntensityFlopPerByte)
                val opY = mapY(roofline.operationalPoint.attainableGFlops)

                // Draw dotted drop line to X-axis
                drawLine(
                    color = CyanAccent.copy(alpha = 0.5f),
                    start = Offset(opX, opY),
                    end = Offset(opX, h - padB),
                    strokeWidth = 1.5f
                )

                // Draw Glowing Operational Point
                drawCircle(color = CyanAccent.copy(alpha = 0.35f), radius = 9f, center = Offset(opX, opY))
                drawCircle(color = CyanAccent, radius = 5f, center = Offset(opX, opY))
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Legend & Parameter Metrics
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Peak Compute: ${String.format("%.1f", roofline.peakComputeGFlops)} GFLOP/s",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = CircuitGold
                )
                Text(
                    text = "Memory Bandwidth: ${String.format("%.1f", roofline.peakMemoryBandwidthGBps)} GB/s",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Ridge Intensity: ${String.format("%.2f", roofline.ridgePointIntensity)} F/B",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Text(
                    text = if (roofline.operationalPoint.isMemoryBound) "MEMORY BOUND" else "COMPUTE BOUND",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = if (roofline.operationalPoint.isMemoryBound) ThermalWarning else SiliconEmerald
                )
            }
        }
    }
}
