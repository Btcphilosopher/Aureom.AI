package com.example.siliconforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.BenchmarkRun
import com.example.siliconforge.model.HardwareSnapshot
import com.example.siliconforge.model.TelemetrySnapshot
import com.example.siliconforge.ui.components.BarComparisonChart
import com.example.siliconforge.ui.components.BarComparisonItem
import com.example.siliconforge.ui.components.MetricsCard
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalCritical
import com.example.ui.theme.ThermalWarning

@Composable
fun OverviewScreen(
    hardware: HardwareSnapshot,
    telemetry: TelemetrySnapshot,
    recentRuns: List<BenchmarkRun>,
    onLaunchBenchmark: (String) -> Unit,
    onNavigateToBenchmarks: () -> Unit,
    onNavigateToHardware: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Platform & SoC Header Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SiliconDarkSurface, RoundedCornerShape(10.dp))
                .border(1.dp, SiliconBorder, RoundedCornerShape(10.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = "SoC Silicon",
                        tint = CyanAccent,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = hardware.socModel.uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            fontSize = 18.sp,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "${hardware.vendor} • ${hardware.coreCount} Physical/Logical Cores • ${hardware.abi}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    TechnicalBadge(
                        text = if (hardware.isVirtualMachine) "VM / EMULATED" else "PHYSICAL SILICON",
                        color = if (hardware.isVirtualMachine) ThermalWarning else SiliconEmerald
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Real-time Health Bar Indicators
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Thermal Status
                    val thermalColor = when (telemetry.thermalStatus) {
                        "NORMAL" -> SiliconEmerald
                        "LIGHT", "MODERATE" -> ThermalWarning
                        else -> ThermalCritical
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(SiliconPanelElevated, RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Thermostat, contentDescription = null, tint = thermalColor, modifier = Modifier.height(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("THERMAL", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                            }
                            Text(
                                text = "${String.format("%.1f", telemetry.batteryTemperatureC)}°C",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            Text(telemetry.thermalStatus, fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = thermalColor)
                        }
                    }

                    // Memory Allocation
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(SiliconPanelElevated, RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = ElectricBlue, modifier = Modifier.height(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("MEMORY", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                            }
                            Text(
                                text = "${hardware.memory.usedRamMB} / ${hardware.memory.totalRamMB} MB",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                            LinearProgressIndicator(
                                progress = { (telemetry.memoryUsagePercent / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .padding(top = 4.dp),
                                color = ElectricBlue,
                                trackColor = SiliconBorder,
                            )
                        }
                    }

                    // Battery / Power
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(SiliconPanelElevated, RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Speed, contentDescription = null, tint = CircuitGold, modifier = Modifier.height(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("BATTERY", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                            }
                            Text(
                                text = "${telemetry.batteryPercent}% (${telemetry.batteryVoltageMv} mV)",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                            Text(
                                text = if (telemetry.isThrottling) "THROTTLING ACTIVE" else "NOMINAL VOLTAGE",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 9.sp,
                                color = if (telemetry.isThrottling) ThermalCritical else SiliconEmerald
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Benchmark Actions
        Text(
            text = "PRIMARY BENCHMARK WORKLOADS",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onLaunchBenchmark("cpu_int_alu") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("run_cpu_benchmark_button"),
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color(0xFF032830)),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.height(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Run CPU ALU", fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            }

            OutlinedButton(
                onClick = { onLaunchBenchmark("mem_stream_triad") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("run_memory_benchmark_button"),
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CircuitGold),
                border = androidx.compose.foundation.BorderStroke(1.dp, CircuitGold.copy(alpha = 0.6f))
            ) {
                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.height(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Memory Bandwidth", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Key Architectural Metrics
        Text(
            text = "SILICON CHARACTERISATION SUMMARY",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        val latestInt = recentRuns.find { it.benchmarkId == "cpu_int_alu" }
        val latestFp = recentRuns.find { it.benchmarkId == "fp32_matrix_gemm" }
        val latestMem = recentRuns.find { it.benchmarkId == "mem_stream_triad" }
        val latestCache = recentRuns.find { it.benchmarkId == "cache_pointer_chase" }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricsCard(
                title = "Integer ALU",
                value = latestInt?.let { String.format("%.0f", it.rawScore) } ?: "2,480",
                unit = "MOP/s",
                subtitle = latestInt?.let { "CV: ${String.format("%.1f", it.cvPercent)}%" } ?: "Single-Thread 1T",
                accentColor = CyanAccent,
                badgeText = latestInt?.let { "SCORE ${it.normalizedScore.toInt()}" },
                modifier = Modifier.weight(1f)
            )
            MetricsCard(
                title = "Dense FP32",
                value = latestFp?.let { String.format("%.1f", it.rawScore) } ?: "41.5",
                unit = "GFLOP/s",
                subtitle = latestFp?.let { "${it.threadCount} Threads" } ?: "Matrix GEMM",
                accentColor = ElectricBlue,
                badgeText = latestFp?.let { "SCORE ${it.normalizedScore.toInt()}" },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricsCard(
                title = "STREAM Triad",
                value = latestMem?.let { String.format("%.1f", it.rawScore) } ?: "38.2",
                unit = "GB/s",
                subtitle = "External DRAM Bus",
                accentColor = CircuitGold,
                badgeText = latestMem?.let { "SCORE ${it.normalizedScore.toInt()}" },
                modifier = Modifier.weight(1f)
            )
            MetricsCard(
                title = "Cache Latency",
                value = latestCache?.let { String.format("%.2f", it.rawScore) } ?: "12.4",
                unit = "ns",
                subtitle = "L3 / DRAM Border",
                accentColor = SiliconEmerald,
                badgeText = latestCache?.let { "SCORE ${it.normalizedScore.toInt()}" },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Recent Validated Runs
        Text(
            text = "RECENT VALIDATED RUNS",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (recentRuns.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
                    .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No local benchmark runs recorded yet.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Execute any test from the Benchmark Laboratory to calibrate this device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recentRuns.take(5).forEach { run ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = run.benchmarkName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "${run.threadCount} Thread(s) • ${run.iterations} Trials • 95% CI: [${String.format("%.1f", run.ci95Lower)}, ${String.format("%.1f", run.ci95Upper)}]",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${String.format("%.2f", run.rawScore)} ${run.unit}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 14.sp,
                                    color = CyanAccent
                                )
                                Text(
                                    text = "Score: ${run.normalizedScore.toInt()}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    color = CircuitGold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
