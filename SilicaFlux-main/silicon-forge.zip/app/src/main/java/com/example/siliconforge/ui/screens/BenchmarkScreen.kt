package com.example.siliconforge.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.benchmark.BenchmarkRegistry
import com.example.siliconforge.model.BenchmarkCategory
import com.example.siliconforge.model.BenchmarkDefinition
import com.example.siliconforge.model.ExecutionState
import com.example.siliconforge.model.LiveBenchmarkState
import com.example.siliconforge.model.ThreadingMode
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalCritical
import com.example.ui.theme.ThermalWarning

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BenchmarkScreen(
    liveState: LiveBenchmarkState,
    onExecuteBenchmark: (BenchmarkDefinition, ThreadingMode, Int) -> Unit,
    onCancelBenchmark: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<BenchmarkCategory?>(null) }
    var configModalBenchmark by remember { mutableStateOf<BenchmarkDefinition?>(null) }
    var selectedThreadingMode by remember { mutableStateOf(ThreadingMode.SINGLE_THREAD) }
    var selectedIterations by remember { mutableIntStateOf(5) }

    val filteredBenchmarks = if (selectedCategory == null) {
        BenchmarkRegistry.benchmarks
    } else {
        BenchmarkRegistry.benchmarks.filter { it.category == selectedCategory }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .padding(16.dp)
    ) {
        // Top Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Science, contentDescription = null, tint = CyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("BENCHMARK LABORATORY", style = MaterialTheme.typography.titleLarge, fontSize = 18.sp)
                Text("Repeatable hardware characterisation & execution suites", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Active Execution Live Banner
        AnimatedVisibility(visible = liveState.state != ExecutionState.IDLE) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .background(SiliconPanelElevated, RoundedCornerShape(8.dp))
                    .border(1.dp, if (liveState.state == ExecutionState.CANCELLED) ThermalCritical else CyanAccent, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val stateBadgeColor = when (liveState.state) {
                            ExecutionState.WARMING_UP -> ThermalWarning
                            ExecutionState.RUNNING -> CyanAccent
                            ExecutionState.VALIDATING -> CircuitGold
                            ExecutionState.COMPLETED -> SiliconEmerald
                            ExecutionState.CANCELLED, ExecutionState.FAILED -> ThermalCritical
                            else -> TextSecondary
                        }
                        TechnicalBadge(text = liveState.state.name, color = stateBadgeColor)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = liveState.activeBenchmark?.name ?: "Benchmark Execution",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        if (liveState.state in listOf(ExecutionState.WARMING_UP, ExecutionState.RUNNING, ExecutionState.VALIDATING)) {
                            IconButton(
                                onClick = onCancelBenchmark,
                                modifier = Modifier.testTag("cancel_benchmark_button")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = ThermalCritical)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { liveState.progressPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = CyanAccent,
                        trackColor = SiliconBorder
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = liveState.statusMessage,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        if (liveState.currentSample > 0.0) {
                            Text(
                                text = "Live: ${String.format("%.2f", liveState.currentSample)} ${liveState.activeBenchmark?.unit ?: ""}",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                color = CyanAccent
                            )
                        }
                    }
                }
            }
        }

        // Category Filter Tabs
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val allSelected = selectedCategory == null
            Box(
                modifier = Modifier
                    .background(if (allSelected) CyanAccent else SiliconDarkSurface, RoundedCornerShape(4.dp))
                    .border(1.dp, if (allSelected) CyanAccent else SiliconBorder, RoundedCornerShape(4.dp))
                    .clickable { selectedCategory = null }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "ALL (${BenchmarkRegistry.benchmarks.size})",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = if (allSelected) Color(0xFF032830) else TextSecondary
                )
            }

            BenchmarkCategory.entries.forEach { cat ->
                val isSelected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .background(if (isSelected) CyanAccent else SiliconDarkSurface, RoundedCornerShape(4.dp))
                        .border(1.dp, if (isSelected) CyanAccent else SiliconBorder, RoundedCornerShape(4.dp))
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = cat.displayName.uppercase(),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = if (isSelected) Color(0xFF032830) else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Benchmark Catalogue List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredBenchmarks, key = { it.id }) { def ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TechnicalBadge(text = def.category.displayName.uppercase(), color = CyanAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = def.unit,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                color = CircuitGold
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "Ref: ${def.referenceScore.toInt()} ${def.unit}",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = def.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = def.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Default: ${def.defaultIterations} trials (${def.defaultWarmupRuns} warmup)",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextMuted,
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedButton(
                                onClick = {
                                    configModalBenchmark = def
                                    selectedIterations = def.defaultIterations
                                    selectedThreadingMode = def.supportedThreading.firstOrNull() ?: ThreadingMode.SINGLE_THREAD
                                },
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.height(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Configure", fontSize = 11.sp)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Button(
                                onClick = {
                                    onExecuteBenchmark(
                                        def,
                                        def.supportedThreading.firstOrNull() ?: ThreadingMode.SINGLE_THREAD,
                                        def.defaultIterations
                                    )
                                },
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color(0xFF032830)),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("run_benchmark_${def.id}")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.height(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Run", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // Workload Configuration Modal Dialog
    configModalBenchmark?.let { def ->
        AlertDialog(
            onDismissRequest = { configModalBenchmark = null },
            title = {
                Text("Configure Benchmark Protocol", fontFamily = JetBrainsMonoFontFamily, fontSize = 15.sp, color = TextPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(def.name, style = MaterialTheme.typography.titleMedium, color = CyanAccent)
                    Text("Select threading configuration and repeat iterations for statistical validation.", fontSize = 12.sp, color = TextSecondary)

                    Text("THREADING MODEL", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                    def.supportedThreading.forEach { mode ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedThreadingMode = mode }
                        ) {
                            RadioButton(
                                selected = selectedThreadingMode == mode,
                                onClick = { selectedThreadingMode = mode },
                                colors = RadioButtonDefaults.colors(selectedColor = CyanAccent)
                            )
                            Text(mode.label, fontSize = 12.sp, color = TextPrimary)
                        }
                    }

                    Text("MEASUREMENT TRIALS", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(3, 5, 10).forEach { iters ->
                            val sel = selectedIterations == iters
                            Box(
                                modifier = Modifier
                                    .background(if (sel) CyanAccent else SiliconPanelElevated, RoundedCornerShape(4.dp))
                                    .border(1.dp, if (sel) CyanAccent else SiliconBorder, RoundedCornerShape(4.dp))
                                    .clickable { selectedIterations = iters }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "$iters Trials",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    color = if (sel) Color(0xFF032830) else TextPrimary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val chosen = def
                        configModalBenchmark = null
                        onExecuteBenchmark(chosen, selectedThreadingMode, selectedIterations)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color(0xFF032830))
                ) {
                    Text("Execute Protocol", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { configModalBenchmark = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = SiliconDarkSurface
        )
    }
}
