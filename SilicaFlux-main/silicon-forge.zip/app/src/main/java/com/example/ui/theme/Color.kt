package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Silicon Forge Semiconductor Palette
val SiliconDeepSlate = Color(0xFF090D16)       // Primary background
val SiliconDarkSurface = Color(0xFF0F172A)     // Cards / panels
val SiliconPanelElevated = Color(0xFF1E293B)   // Elevated cards / headers
val SiliconBorder = Color(0xFF334155)          // Crisp technical dividers

// Accent & Semiconductor Telemetry Colors
val CyanAccent = Color(0xFF00E5FF)             // Primary active accent / core logic
val CyanAccentDim = Color(0xFF0097A7)          // Secondary accent
val ElectricBlue = Color(0xFF38BDF8)           // Instruction sets & data lines
val CircuitGold = Color(0xFFFBBF24)            // Cache / memory / interconnects
val SiliconEmerald = Color(0xFF10B981)         // Pass / Optimal / Good efficiency
val ThermalWarning = Color(0xFFF97316)         // Thermal warm
val ThermalCritical = Color(0xFFEF4444)        // Thermal throttle / Critical

// Monochromatic text & surface variants
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val CodeHighlight = Color(0xFF38BDF8)
