package com.example.siliconforge.model

data class ReferenceSiliconProfile(
    val id: String,
    val name: String,
    val vendor: String,
    val architecture: String,
    val processNode: String,
    val coreConfig: String,
    val tdpWatts: Double,
    val singleCoreIntegerOpsPerSec: Double, // normalized MOP/s
    val multiCoreGFlops: Double,
    val memoryBandwidthGBps: Double,
    val l3LatencyNs: Double,
    val aiTops: Double,
    val perfPerWattScore: Double,
    val summary: String
)

object ReferenceDatabase {
    val referenceArchitectures: List<ReferenceSiliconProfile> = listOf(
        ReferenceSiliconProfile(
            id = "apple_m4_max",
            name = "Apple M4 Max",
            vendor = "Apple Silicon",
            architecture = "ARMv9.2-A (16-core)",
            processNode = "TSMC N3E (3nm)",
            coreConfig = "12 P-cores (4.4 GHz) + 4 E-cores (2.9 GHz)",
            tdpWatts = 65.0,
            singleCoreIntegerOpsPerSec = 4120.0,
            multiCoreGFlops = 1450.0,
            memoryBandwidthGBps = 546.0,
            l3LatencyNs = 8.5,
            aiTops = 38.0,
            perfPerWattScore = 94.2,
            summary = "Unified 16-core architecture with 512-bit wide memory bus and hardware Ray Tracing."
        ),
        ReferenceSiliconProfile(
            id = "amd_ryzen_9950x",
            name = "AMD Ryzen 9 9950X",
            vendor = "AMD",
            architecture = "x86-64 Zen 5 (16C/32T)",
            processNode = "TSMC N4X (4nm CCD)",
            coreConfig = "16 Zen 5 Cores (5.7 GHz Boost)",
            tdpWatts = 170.0,
            singleCoreIntegerOpsPerSec = 3880.0,
            multiCoreGFlops = 1820.0,
            memoryBandwidthGBps = 96.0,
            l3LatencyNs = 10.8,
            aiTops = 16.0, // AVX-512 VNNI
            perfPerWattScore = 78.5,
            summary = "Dual-CCD Zen 5 desktop flagship featuring 512-bit data path and dual decode."
        ),
        ReferenceSiliconProfile(
            id = "intel_ultra_285k",
            name = "Intel Core Ultra 9 285K",
            vendor = "Intel",
            architecture = "x86-64 Arrow Lake-S",
            processNode = "TSMC N3B (3nm Compute)",
            coreConfig = "8 Lion Cove (5.7 GHz) + 16 Skymont (4.6 GHz)",
            tdpWatts = 125.0,
            singleCoreIntegerOpsPerSec = 3790.0,
            multiCoreGFlops = 1680.0,
            memoryBandwidthGBps = 102.4,
            l3LatencyNs = 12.2,
            aiTops = 36.0,
            perfPerWattScore = 76.1,
            summary = "Disaggregated tile architecture with integrated 13 TOPS NPU and Lion Cove cores."
        ),
        ReferenceSiliconProfile(
            id = "snapdragon_8_elite",
            name = "Qualcomm Snapdragon 8 Elite",
            vendor = "Qualcomm",
            architecture = "ARMv9 Oryon Gen 2",
            processNode = "TSMC N3E (3nm)",
            coreConfig = "2 Prime (4.32 GHz) + 6 Performance (3.53 GHz)",
            tdpWatts = 12.5,
            singleCoreIntegerOpsPerSec = 3450.0,
            multiCoreGFlops = 780.0,
            memoryBandwidthGBps = 77.0,
            l3LatencyNs = 11.5,
            aiTops = 45.0,
            perfPerWattScore = 91.0,
            summary = "All-Big core Oryon microarchitecture for mobile flagships with Hexagon NPU."
        ),
        ReferenceSiliconProfile(
            id = "google_tensor_g4",
            name = "Google Tensor G4",
            vendor = "Google",
            architecture = "ARMv9.2-A",
            processNode = "Samsung 4nm (4LPP+)",
            coreConfig = "1 Cortex-X4 (3.1 GHz) + 3 A720 (2.6 GHz) + 4 A520 (1.95 GHz)",
            tdpWatts = 10.0,
            singleCoreIntegerOpsPerSec = 2650.0,
            multiCoreGFlops = 510.0,
            memoryBandwidthGBps = 64.0,
            l3LatencyNs = 13.8,
            aiTops = 35.0,
            perfPerWattScore = 82.4,
            summary = "Mobile AI-optimized SoC tuned for on-device Gemini Nano inference."
        ),
        ReferenceSiliconProfile(
            id = "sifive_p870",
            name = "SiFive Performance P870",
            vendor = "SiFive",
            architecture = "RISC-V 64-bit (RVA22)",
            processNode = "TSMC N5 (5nm)",
            coreConfig = "8 Out-of-Order P870 Cores (3.0 GHz)",
            tdpWatts = 18.0,
            singleCoreIntegerOpsPerSec = 2240.0,
            multiCoreGFlops = 390.0,
            memoryBandwidthGBps = 51.2,
            l3LatencyNs = 14.5,
            aiTops = 12.0,
            perfPerWattScore = 84.7,
            summary = "Open-standard RISC-V application processor with Vector 1.0 acceleration."
        )
    )
}
