package com.example.siliconforge.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BenchmarkDao {

    @Query("SELECT * FROM benchmark_runs ORDER BY timestamp DESC")
    fun getAllRuns(): Flow<List<BenchmarkRunEntity>>

    @Query("SELECT * FROM benchmark_runs WHERE benchmarkId = :benchmarkId ORDER BY timestamp DESC")
    fun getRunsForBenchmark(benchmarkId: String): Flow<List<BenchmarkRunEntity>>

    @Query("SELECT * FROM benchmark_runs ORDER BY timestamp DESC LIMIT 10")
    fun getRecentRuns(): Flow<List<BenchmarkRunEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRun(run: BenchmarkRunEntity)

    @Query("DELETE FROM benchmark_runs WHERE id = :id")
    suspend fun deleteRunById(id: String)

    @Query("DELETE FROM benchmark_runs")
    suspend fun clearAll()
}
