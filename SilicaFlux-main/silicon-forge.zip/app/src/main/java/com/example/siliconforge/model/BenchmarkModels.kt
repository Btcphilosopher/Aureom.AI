package com.example.siliconforge.model

enum class BenchmarkCategory(val displayName: String, val description: String) {
    INTEGER("Integer ALU", "Integer arithmetic, bit-manipulation, hashing, and branch characterisation"),
    FLOATING_POINT("Floating Point", "Dense FP32/FP64 linear algebra, matrix tiling, and Cooley-Tukey FFT"),
    MEMORY_BANDWIDTH("Memory Subsystem", "Sustained stream copy/read/write/triad bandwidth in GB/s"),
    CACHE_LATENCY("Cache Hierarchy", "Pointer-chasing dependent-load latency across L1/L2/L3 working sets"),
    AI_INFERENCE("AI Acceleration", "Quantized INT8/FP16 matrix attention and token generation throughput"),
    MULTICORE_SCALING("Multi-Core Scaling", "Parallel speedup, thread contention, and parallel efficiency")
}

enum class ThreadingMode(val label: String) {
    SINGLE_THREAD("Single Thread (1T)"),
    MULTI_THREAD("Multi-Core (All Threads)"),
    SCALING_SWEEP("Thread Scaling Sweep")
}

data class BenchmarkDefinition(
    val id: String,
    val name: String,
    val category: BenchmarkCategory,
    val description: String,
    val unit: String,
    val defaultIterations: Int = 5,
    val defaultWarmupRuns: Int = 1,
    val referenceScore: Double, // Baseline machine score for 1000-point normalization
    val supportedThreading: List<ThreadingMode> = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
)

data class BenchmarkRun(
    val id: String,
    val benchmarkId: String,
    val benchmarkName: String,
    val category: BenchmarkCategory,
    val timestamp: Long = System.currentTimeMillis(),
    val threadCount: Int,
    val iterations: Int,
    val samples: List<Double>,
    val mean: Double,
    val median: Double,
    val stdDev: Double,
    val iqr: Double,
    val ci95Lower: Double,
    val ci95Upper: Double,
    val cvPercent: Double,
    val rawScore: Double, // primary metric (median)
    val unit: String,
    val normalizedScore: Double, // 1000 * (score / reference)
    val parallelEfficiency: Double = 1.0,
    val initialTempC: Float = 25f,
    val peakTempC: Float = 25f,
    val throttlingDetected: Boolean = false,
    val validationHash: String = "VALIDATED_OK",
    val provenance: ProvenanceManifest = ProvenanceManifest()
)

data class ProvenanceManifest(
    val engineVersion: String = "SiliconForge-2.4-Core",
    val compilerOptimization: String = "Kotlin-2.2 / Android ART JIT",
    val timerSource: String = "CLOCK_MONOTONIC_RAW (System.nanoTime)",
    val timestampUtc: String = "UTC_TIMESTAMP",
    val environmentHash: String = "sha256-kernel-env-checked"
)

enum class ExecutionState {
    IDLE,
    WARMING_UP,
    RUNNING,
    VALIDATING,
    COMPLETED,
    CANCELLED,
    FAILED
}

data class LiveBenchmarkState(
    val activeBenchmark: BenchmarkDefinition? = null,
    val state: ExecutionState = ExecutionState.IDLE,
    val currentIteration: Int = 0,
    val totalIterations: Int = 0,
    val currentSample: Double = 0.0,
    val progressPercent: Float = 0f,
    val statusMessage: String = "Idle - Select a benchmark to execute",
    val intermediateScores: List<Double> = emptyList(),
    val liveThroughput: Double = 0.0
)
