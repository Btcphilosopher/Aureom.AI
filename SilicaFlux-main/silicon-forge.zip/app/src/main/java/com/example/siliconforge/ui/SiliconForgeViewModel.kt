package com.example.siliconforge.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.siliconforge.benchmark.BenchmarkEngine
import com.example.siliconforge.benchmark.BenchmarkRegistry
import com.example.siliconforge.data.BenchmarkRepository
import com.example.siliconforge.hardware.HardwareDiscovery
import com.example.siliconforge.model.BenchmarkDefinition
import com.example.siliconforge.model.BenchmarkRun
import com.example.siliconforge.model.HardwareSnapshot
import com.example.siliconforge.model.LiveBenchmarkState
import com.example.siliconforge.model.TelemetrySnapshot
import com.example.siliconforge.model.ThreadingMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class SiliconForgeUiState(
    val hardware: HardwareSnapshot,
    val telemetry: TelemetrySnapshot,
    val temperatureHistory: List<Float> = emptyList(),
    val isSampling: Boolean = true
)

class SiliconForgeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BenchmarkRepository(application)
    private val engine = BenchmarkEngine(application)

    val benchmarkRuns: StateFlow<List<BenchmarkRun>> = repository.allRuns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveBenchmarkState: StateFlow<LiveBenchmarkState> = engine.liveState

    private val initialHardware = HardwareDiscovery.captureHardwareSnapshot(application)
    private val initialTelemetry = HardwareDiscovery.captureTelemetry(application)

    private val _uiState = MutableStateFlow(
        SiliconForgeUiState(
            hardware = initialHardware,
            telemetry = initialTelemetry,
            temperatureHistory = listOf(initialTelemetry.batteryTemperatureC)
        )
    )
    val uiState: StateFlow<SiliconForgeUiState> = _uiState.asStateFlow()

    init {
        // Start background telemetry polling loop (every 1.5s)
        viewModelScope.launch {
            while (isActive) {
                try {
                    val sample = HardwareDiscovery.captureTelemetry(getApplication())
                    val currentHistory = _uiState.value.temperatureHistory
                    val updatedHistory = (currentHistory + sample.batteryTemperatureC).takeLast(30)
                    _uiState.value = _uiState.value.copy(
                        telemetry = sample,
                        temperatureHistory = updatedHistory
                    )
                } catch (_: Exception) {}
                delay(1500)
            }
        }
    }

    fun executeBenchmark(
        definition: BenchmarkDefinition,
        threadingMode: ThreadingMode = ThreadingMode.SINGLE_THREAD,
        iterations: Int = definition.defaultIterations
    ) {
        viewModelScope.launch {
            try {
                val run = engine.executeBenchmark(
                    definition = definition,
                    threadingMode = threadingMode,
                    iterations = iterations
                )
                repository.saveRun(run)
            } catch (e: Exception) {
                // Cancelled or failed handled in engine live state
            }
        }
    }

    fun launchQuickBenchmark(benchmarkId: String) {
        val def = BenchmarkRegistry.getById(benchmarkId) ?: return
        executeBenchmark(def, ThreadingMode.SINGLE_THREAD, def.defaultIterations)
    }

    fun cancelActiveBenchmark() {
        engine.cancelActiveRun()
    }

    fun clearAllRuns() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun exportRunsJson(): String {
        return repository.exportToJson(benchmarkRuns.value)
    }

    fun exportRunsCsv(): String {
        return repository.exportToCsv(benchmarkRuns.value)
    }
}
