package com.example.siliconforge.data

import android.content.Context
import com.example.siliconforge.model.BenchmarkRun
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BenchmarkRepository(context: Context) {

    private val db = SiliconForgeDatabase.getDatabase(context)
    private val dao = db.benchmarkDao()

    val allRuns: Flow<List<BenchmarkRun>> = dao.getAllRuns().map { entities ->
        entities.map { it.toDomain() }
    }

    val recentRuns: Flow<List<BenchmarkRun>> = dao.getRecentRuns().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun saveRun(run: BenchmarkRun) {
        dao.insertRun(BenchmarkRunEntity.fromDomain(run))
    }

    suspend fun clearHistory() {
        dao.clearAll()
    }

    fun exportToJson(runs: List<BenchmarkRun>): String {
        val sb = StringBuilder()
        sb.append("[\n")
        runs.forEachIndexed { index, run ->
            sb.append("  {\n")
            sb.append("    \"id\": \"${run.id}\",\n")
            sb.append("    \"benchmarkId\": \"${run.benchmarkId}\",\n")
            sb.append("    \"benchmarkName\": \"${run.benchmarkName}\",\n")
            sb.append("    \"category\": \"${run.category.name}\",\n")
            sb.append("    \"timestamp\": ${run.timestamp},\n")
            sb.append("    \"threadCount\": ${run.threadCount},\n")
            sb.append("    \"iterations\": ${run.iterations},\n")
            sb.append("    \"rawScore\": ${run.rawScore},\n")
            sb.append("    \"unit\": \"${run.unit}\",\n")
            sb.append("    \"normalizedScore\": ${run.normalizedScore},\n")
            sb.append("    \"mean\": ${run.mean},\n")
            sb.append("    \"median\": ${run.median},\n")
            sb.append("    \"stdDev\": ${run.stdDev},\n")
            sb.append("    \"iqr\": ${run.iqr},\n")
            sb.append("    \"ci95Lower\": ${run.ci95Lower},\n")
            sb.append("    \"ci95Upper\": ${run.ci95Upper},\n")
            sb.append("    \"cvPercent\": ${run.cvPercent},\n")
            sb.append("    \"throttlingDetected\": ${run.throttlingDetected},\n")
            sb.append("    \"validationHash\": \"${run.validationHash}\",\n")
            sb.append("    \"provenance\": {\n")
            sb.append("      \"engine\": \"${run.provenance.engineVersion}\",\n")
            sb.append("      \"timer\": \"${run.provenance.timerSource}\",\n")
            sb.append("      \"utc\": \"${run.provenance.timestampUtc}\"\n")
            sb.append("    }\n")
            sb.append("  }${if (index < runs.size - 1) "," else ""}\n")
        }
        sb.append("]\n")
        return sb.toString()
    }

    fun exportToCsv(runs: List<BenchmarkRun>): String {
        val sb = StringBuilder()
        sb.append("Timestamp,BenchmarkId,BenchmarkName,Category,Threads,RawScore,Unit,NormalizedScore,Mean,StdDev,IQR,CI95Low,CI95High,CV%,Throttled,ValidationHash\n")
        runs.forEach { r ->
            sb.append("${r.timestamp},\"${r.benchmarkId}\",\"${r.benchmarkName}\",${r.category.name},${r.threadCount},${r.rawScore},${r.unit},${r.normalizedScore},${r.mean},${r.stdDev},${r.iqr},${r.ci95Lower},${r.ci95Upper},${r.cvPercent},${r.throttlingDetected},\"${r.validationHash}\"\n")
        }
        return sb.toString()
    }
}
