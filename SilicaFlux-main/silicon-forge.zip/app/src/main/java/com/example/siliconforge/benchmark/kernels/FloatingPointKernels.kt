package com.example.siliconforge.benchmark.kernels

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object FloatingPointKernels {

    @Volatile
    var blackHoleSink: Double = 0.0

    /**
     * Dense FP32 Matrix Multiplication (C = A x B)
     * Matrix dimension N x N. Total floating point operations = 2 * N^3 (multiplication + addition).
     * Uses block-tiling (B=32) for cache-friendly L1/L2 spatial locality.
     */
    fun runFp32MatrixMultiplication(n: Int = 128): Double {
        val a = FloatArray(n * n) { (it % 17).toFloat() * 0.125f }
        val b = FloatArray(n * n) { ((it + 3) % 19).toFloat() * 0.25f }
        val c = FloatArray(n * n)

        val blockSize = 32
        val start = System.nanoTime()

        for (i0 in 0 until n step blockSize) {
            val iMax = minOf(i0 + blockSize, n)
            for (j0 in 0 until n step blockSize) {
                val jMax = minOf(j0 + blockSize, n)
                for (k0 in 0 until n step blockSize) {
                    val kMax = minOf(k0 + blockSize, n)

                    for (i in i0 until iMax) {
                        val rowA = i * n
                        for (k in k0 until kMax) {
                            val aVal = a[rowA + k]
                            val rowB = k * n
                            for (j in j0 until jMax) {
                                c[rowA + j] += aVal * b[rowB + j]
                            }
                        }
                    }
                }
            }
        }
        val elapsedNs = System.nanoTime() - start

        var checkSum = 0.0
        for (i in 0 until minOf(100, n * n)) {
            checkSum += c[i]
        }
        blackHoleSink = checkSum

        val elapsedSec = elapsedNs / 1_000_000_000.0
        val totalFlops = 2.0 * n.toDouble() * n.toDouble() * n.toDouble()
        val gFlops = (totalFlops / 1_000_000_000.0) / elapsedSec
        return gFlops // GFLOP/s
    }

    /**
     * Dense FP64 Double Precision Matrix Multiplication
     */
    fun runFp64MatrixMultiplication(n: Int = 96): Double {
        val a = DoubleArray(n * n) { (it % 13).toDouble() * 0.03125 }
        val b = DoubleArray(n * n) { ((it + 5) % 23).toDouble() * 0.0625 }
        val c = DoubleArray(n * n)

        val start = System.nanoTime()
        for (i in 0 until n) {
            val rowA = i * n
            for (k in 0 until n) {
                val aVal = a[rowA + k]
                val rowB = k * n
                for (j in 0 until n) {
                    c[rowA + j] += aVal * b[rowB + j]
                }
            }
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = c[0] + c[n * n - 1]

        val elapsedSec = elapsedNs / 1_000_000_000.0
        val totalFlops = 2.0 * n.toDouble() * n.toDouble() * n.toDouble()
        val gFlops = (totalFlops / 1_000_000_000.0) / elapsedSec
        return gFlops // GFLOP/s
    }

    /**
     * 1D Complex Fast Fourier Transform (Cooley-Tukey Radix-2)
     * N = 4096 points. Measures numerical arithmetic intensity and butterfly memory strides.
     */
    fun runFastFourierTransform(n: Int = 4096, repetitions: Int = 80): Double {
        val real = DoubleArray(n) { sin(2.0 * PI * it / n * 17.0) }
        val imag = DoubleArray(n)

        val start = System.nanoTime()
        for (rep in 0 until repetitions) {
            fftRadix2(real, imag, n)
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = real[0] + imag[1]

        val elapsedSec = elapsedNs / 1_000_000_000.0
        // FFT FLOPs: 5 * N * log2(N) per transform
        val log2N = (kotlin.math.ln(n.toDouble()) / kotlin.math.ln(2.0))
        val flopsPerFft = 5.0 * n * log2N
        val totalFlops = flopsPerFft * repetitions
        return (totalFlops / 1_000_000_000.0) / elapsedSec // GFLOP/s
    }

    private fun fftRadix2(real: DoubleArray, imag: DoubleArray, n: Int) {
        var j = 0
        for (i in 0 until n - 1) {
            if (i < j) {
                val tempR = real[i]; real[i] = real[j]; real[j] = tempR
                val tempI = imag[i]; imag[i] = imag[j]; imag[j] = tempI
            }
            var k = n shr 1
            while (k <= j) {
                j -= k
                k = k shr 1
            }
            j += k
        }

        var len = 2
        while (len <= n) {
            val halfLen = len shr 1
            val angle = -2.0 * PI / len
            val wStepR = cos(angle)
            val wStepI = sin(angle)

            var i = 0
            while (i < n) {
                var wR = 1.0
                var wI = 0.0
                for (k in 0 until halfLen) {
                    val uR = real[i + k]
                    val uI = imag[i + k]
                    val vR = real[i + k + halfLen] * wR - imag[i + k + halfLen] * wI
                    val vI = real[i + k + halfLen] * wI + imag[i + k + halfLen] * wR

                    real[i + k] = uR + vR
                    imag[i + k] = uI + vI
                    real[i + k + halfLen] = uR - vR
                    imag[i + k + halfLen] = uI - vI

                    val nextWR = wR * wStepR - wI * wStepI
                    val nextWI = wR * wStepI + wI * wStepR
                    wR = nextWR
                    wI = nextWI
                }
                i += len
            }
            len = len shl 1
        }
    }
}
