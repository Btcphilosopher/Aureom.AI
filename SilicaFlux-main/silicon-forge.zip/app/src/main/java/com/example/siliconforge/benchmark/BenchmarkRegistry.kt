package com.example.siliconforge.benchmark

import com.example.siliconforge.model.BenchmarkCategory
import com.example.siliconforge.model.BenchmarkDefinition
import com.example.siliconforge.model.ThreadingMode

object BenchmarkRegistry {

    val benchmarks: List<BenchmarkDefinition> = listOf(
        BenchmarkDefinition(
            id = "cpu_int_alu",
            name = "64-bit Integer ALU & Bitwise Throughput",
            category = BenchmarkCategory.INTEGER,
            description = "Unrolled 64-bit arithmetic, bit-manipulation, shifts and chained cryptographic mixing.",
            unit = "MOP/s",
            defaultIterations = 5,
            defaultWarmupRuns = 1,
            referenceScore = 2500.0, // baseline reference MOP/s
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "cpu_branch_predict",
            name = "Branch Predictor Pipeline Characterisation",
            category = BenchmarkCategory.INTEGER,
            description = "Measures pipeline bubble latency under 50% pseudo-random branch misprediction pressure.",
            unit = "MOP/s",
            defaultIterations = 4,
            defaultWarmupRuns = 1,
            referenceScore = 1800.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD)
        ),
        BenchmarkDefinition(
            id = "cpu_hash_murmur",
            name = "Non-Cryptographic Memory Hashing (Murmur3-64)",
            category = BenchmarkCategory.INTEGER,
            description = "High-throughput 64-bit hashing over 4 MB continuous block, exercising byte-packing.",
            unit = "MB/s",
            defaultIterations = 5,
            defaultWarmupRuns = 1,
            referenceScore = 3200.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "cpu_sort_graph",
            name = "Quicksort & Pointer Graph Search",
            category = BenchmarkCategory.INTEGER,
            description = "Dual-pivot quicksort on 100K randomized keys followed by binary search traversal.",
            unit = "KOP/s",
            defaultIterations = 4,
            defaultWarmupRuns = 1,
            referenceScore = 140.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD)
        ),
        BenchmarkDefinition(
            id = "fp32_matrix_gemm",
            name = "Dense FP32 Matrix Multiplication (GEMM)",
            category = BenchmarkCategory.FLOATING_POINT,
            description = "Block-tiled matrix multiplication (C = A x B) measuring sustained floating-point throughput.",
            unit = "GFLOP/s",
            defaultIterations = 5,
            defaultWarmupRuns = 1,
            referenceScore = 42.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "fp64_matrix_gemm",
            name = "Double-Precision FP64 Matrix Multiplication",
            category = BenchmarkCategory.FLOATING_POINT,
            description = "High-precision 64-bit IEEE 754 floating point arithmetic stress.",
            unit = "GFLOP/s",
            defaultIterations = 4,
            defaultWarmupRuns = 1,
            referenceScore = 21.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "fp_fft_radix2",
            name = "Cooley-Tukey 1D Fast Fourier Transform (FFT)",
            category = BenchmarkCategory.FLOATING_POINT,
            description = "4096-point complex radix-2 FFT measuring butterfly stride and trigonometric convergence.",
            unit = "GFLOP/s",
            defaultIterations = 5,
            defaultWarmupRuns = 1,
            referenceScore = 18.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "mem_stream_triad",
            name = "STREAM Triad Memory Bandwidth",
            category = BenchmarkCategory.MEMORY_BANDWIDTH,
            description = "Standard STREAM Triad benchmark (A = B + q*C) exercising external DRAM memory channels.",
            unit = "GB/s",
            defaultIterations = 6,
            defaultWarmupRuns = 2,
            referenceScore = 48.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "mem_stream_copy",
            name = "STREAM Copy Memory Bandwidth",
            category = BenchmarkCategory.MEMORY_BANDWIDTH,
            description = "Direct block memory transfer (A = B) testing sequential read/write saturation.",
            unit = "GB/s",
            defaultIterations = 5,
            defaultWarmupRuns = 1,
            referenceScore = 42.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "cache_pointer_chase",
            name = "Cache Hierarchy Dependent-Load Latency",
            category = BenchmarkCategory.CACHE_LATENCY,
            description = "Pointer-chasing cyclic permutation measuring nanosecond latency across L1, L2, L3 and DRAM.",
            unit = "ns",
            defaultIterations = 4,
            defaultWarmupRuns = 1,
            referenceScore = 12.0, // Reference L3 latency (lower is better)
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD)
        ),
        BenchmarkDefinition(
            id = "ai_int8_attention",
            name = "Quantized INT8 Attention Matrix (Q x K^T)",
            category = BenchmarkCategory.AI_INFERENCE,
            description = "Multi-head attention projection simulating transformer neural accelerator layers.",
            unit = "MMAC/s",
            defaultIterations = 5,
            defaultWarmupRuns = 1,
            referenceScore = 1250.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "ai_token_throughput",
            name = "Autoregressive LLM Token Generation Rate",
            category = BenchmarkCategory.AI_INFERENCE,
            description = "Simulates vector projection, KV-cache lookup, and token sampling.",
            unit = "Tokens/s",
            defaultIterations = 4,
            defaultWarmupRuns = 1,
            referenceScore = 45.0,
            supportedThreading = listOf(ThreadingMode.SINGLE_THREAD, ThreadingMode.MULTI_THREAD)
        ),
        BenchmarkDefinition(
            id = "multicore_scaling",
            name = "Multi-Core Scaling & Parallel Efficiency",
            category = BenchmarkCategory.MULTICORE_SCALING,
            description = "Measures single-core baseline vs all-core parallel execution to evaluate speedup and contention.",
            unit = "x Speedup",
            defaultIterations = 4,
            defaultWarmupRuns = 1,
            referenceScore = 6.5,
            supportedThreading = listOf(ThreadingMode.MULTI_THREAD)
        )
    )

    fun getById(id: String): BenchmarkDefinition? = benchmarks.find { it.id == id }
}
