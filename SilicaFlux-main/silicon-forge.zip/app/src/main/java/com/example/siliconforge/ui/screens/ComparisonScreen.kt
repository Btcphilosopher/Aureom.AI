package com.example.siliconforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.BenchmarkRun
import com.example.siliconforge.model.HardwareSnapshot
import com.example.siliconforge.model.ReferenceDatabase
import com.example.siliconforge.model.ReferenceSiliconProfile
import com.example.siliconforge.ui.components.BarComparisonChart
import com.example.siliconforge.ui.components.BarComparisonItem
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ComparisonScreen(
    hardware: HardwareSnapshot,
    recentRuns: List<BenchmarkRun>,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var selectedReference by remember { mutableStateOf<ReferenceSiliconProfile?>(ReferenceDatabase.referenceArchitectures.first()) }

    // Host device measured or estimated values
    val hostIntRun = recentRuns.find { it.benchmarkId == "cpu_int_alu" }
    val hostIntOps = hostIntRun?.rawScore ?: 2450.0

    val hostFpRun = recentRuns.find { it.benchmarkId == "fp32_matrix_gemm" }
    val hostGFlops = hostFpRun?.rawScore ?: 42.0

    val hostMemRun = recentRuns.find { it.benchmarkId == "mem_stream_triad" }
    val hostBandwidth = hostMemRun?.rawScore ?: 38.0

    val hostCacheRun = recentRuns.find { it.benchmarkId == "cache_pointer_chase" }
    val hostCacheLatency = hostCacheRun?.rawScore ?: 12.5

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Screen Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CompareArrows, contentDescription = null, tint = CyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("SEMICONDUCTOR COMPARISON", style = MaterialTheme.typography.titleLarge, fontSize = 18.sp)
                Text("Architectural cross-platform benchmark characterisation", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Reference Architecture Selector Pills
        Text("SELECT REFERENCE ARCHITECTURE", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ReferenceDatabase.referenceArchitectures.take(3).forEach { profile ->
                val isSelected = selectedReference?.id == profile.id
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSelected) CyanAccent else SiliconDarkSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, if (isSelected) CyanAccent else SiliconBorder, RoundedCornerShape(6.dp))
                        .clickable { selectedReference = profile }
                        .padding(vertical = 8.dp, horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profile.name,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = if (isSelected) androidx.compose.ui.graphics.Color(0xFF032830) else TextPrimary,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ReferenceDatabase.referenceArchitectures.drop(3).forEach { profile ->
                val isSelected = selectedReference?.id == profile.id
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSelected) CyanAccent else SiliconDarkSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, if (isSelected) CyanAccent else SiliconBorder, RoundedCornerShape(6.dp))
                        .clickable { selectedReference = profile }
                        .padding(vertical = 8.dp, horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profile.name,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = if (isSelected) androidx.compose.ui.graphics.Color(0xFF032830) else TextPrimary,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Selected Reference Overview Card
        selectedReference?.let { ref ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(ref.name, style = MaterialTheme.typography.titleMedium, fontSize = 16.sp, color = TextPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        TechnicalBadge(text = ref.processNode, color = CircuitGold)
                        Spacer(modifier = Modifier.weight(1f))
                        Text("TDP: ${ref.tdpWatts.toInt()}W", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextMuted)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(ref.architecture, fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = CyanAccent)
                    Text(ref.coreConfig, fontSize = 12.sp, color = TextSecondary)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(ref.summary, fontSize = 11.sp, color = TextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Head-to-Head Comparative Charts
        Text("HEAD-TO-HEAD BENCHMARK METRICS", fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(8.dp))

        selectedReference?.let { ref ->
            // 1. Single-Core Integer Throughput
            BarComparisonChart(
                title = "Single-Core Integer ALU Throughput",
                unit = "MOP/s",
                items = listOf(
                    BarComparisonItem("HOST: ${hardware.socModel}", hostIntOps, "${hostIntOps.toInt()} MOP/s", isHighlighted = true, color = CyanAccent),
                    BarComparisonItem(ref.name, ref.singleCoreIntegerOpsPerSec, "${ref.singleCoreIntegerOpsPerSec.toInt()} MOP/s", color = ElectricBlue)
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Memory Subsystem Bandwidth
            BarComparisonChart(
                title = "Sustained DRAM Memory Bandwidth",
                unit = "GB/s",
                items = listOf(
                    BarComparisonItem("HOST: ${hardware.socModel}", hostBandwidth, "${String.format("%.1f", hostBandwidth)} GB/s", isHighlighted = true, color = CyanAccent),
                    BarComparisonItem(ref.name, ref.memoryBandwidthGBps, "${ref.memoryBandwidthGBps.toInt()} GB/s", color = CircuitGold)
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Multi-Core Floating Point Throughput
            BarComparisonChart(
                title = "Multi-Core Dense FP32 Throughput",
                unit = "GFLOP/s",
                items = listOf(
                    BarComparisonItem("HOST: ${hardware.socModel}", hostGFlops, "${String.format("%.1f", hostGFlops)} GFLOP/s", isHighlighted = true, color = CyanAccent),
                    BarComparisonItem(ref.name, ref.multiCoreGFlops, "${ref.multiCoreGFlops.toInt()} GFLOP/s", color = ElectricBlue)
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Efficiency: Performance per Watt
            BarComparisonChart(
                title = "Energy Efficiency (Performance / Watt)",
                unit = "Efficiency Pts",
                items = listOf(
                    BarComparisonItem("HOST: ${hardware.socModel}", 88.0, "88.0 pts/W", isHighlighted = true, color = CyanAccent),
                    BarComparisonItem(ref.name, ref.perfPerWattScore, "${ref.perfPerWattScore} pts/W", color = SiliconEmerald)
                )
            )
        }
    }
}
