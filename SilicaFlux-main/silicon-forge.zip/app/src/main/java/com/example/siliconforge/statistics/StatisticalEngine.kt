package com.example.siliconforge.statistics

import java.util.Random
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

data class DistributionAnalysis(
    val mean: Double,
    val median: Double,
    val stdDev: Double,
    val variance: Double,
    val iqr: Double,
    val q1: Double,
    val q3: Double,
    val ci95Lower: Double,
    val ci95Upper: Double,
    val cvPercent: Double,
    val outliersCount: Int,
    val sampleCount: Int
)

object StatisticalEngine {

    fun analyze(samples: List<Double>): DistributionAnalysis {
        if (samples.isEmpty()) {
            return DistributionAnalysis(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0)
        }
        if (samples.size == 1) {
            val v = samples.first()
            return DistributionAnalysis(v, v, 0.0, 0.0, 0.0, v, v, v, v, 0.0, 0, 1)
        }

        val sorted = samples.sorted()
        val n = sorted.size

        val mean = sorted.average()
        val median = if (n % 2 == 1) {
            sorted[n / 2]
        } else {
            (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
        }

        val variance = sorted.sumOf { (it - mean).pow(2.0) } / (n - 1)
        val stdDev = sqrt(variance)
        val cvPercent = if (mean > 0.0) (stdDev / mean) * 100.0 else 0.0

        val q1 = percentile(sorted, 25.0)
        val q3 = percentile(sorted, 75.0)
        val iqr = q3 - q1

        // Outlier detection: Tukey's 1.5 * IQR rule
        val lowerBound = q1 - 1.5 * iqr
        val upperBound = q3 + 1.5 * iqr
        val outliersCount = sorted.count { it < lowerBound || it > upperBound }

        // Bootstrap 95% Confidence Interval (1,000 resamples)
        val (ciLower, ciUpper) = bootstrapConfidenceInterval(samples, 1000, 0.95)

        return DistributionAnalysis(
            mean = mean,
            median = median,
            stdDev = stdDev,
            variance = variance,
            iqr = iqr,
            q1 = q1,
            q3 = q3,
            ci95Lower = ciLower,
            ci95Upper = ciUpper,
            cvPercent = cvPercent,
            outliersCount = outliersCount,
            sampleCount = n
        )
    }

    private fun percentile(sorted: List<Double>, p: Double): Double {
        val index = (p / 100.0) * (sorted.size - 1)
        val lower = index.toInt()
        val fraction = index - lower
        return if (lower + 1 < sorted.size) {
            sorted[lower] + fraction * (sorted[lower + 1] - sorted[lower])
        } else {
            sorted[lower]
        }
    }

    private fun bootstrapConfidenceInterval(
        samples: List<Double>,
        replications: Int = 1000,
        confidenceLevel: Double = 0.95
    ): Pair<Double, Double> {
        val n = samples.size
        val random = Random(42) // Fixed seed for reproducible analysis
        val bootstrapMeans = DoubleArray(replications)

        for (i in 0 until replications) {
            var sum = 0.0
            for (j in 0 until n) {
                val idx = random.nextInt(n)
                sum += samples[idx]
            }
            bootstrapMeans[i] = sum / n
        }

        bootstrapMeans.sort()
        val alpha = (1.0 - confidenceLevel) / 2.0
        val lowIdx = (alpha * replications).toInt().coerceIn(0, replications - 1)
        val highIdx = ((1.0 - alpha) * replications).toInt().coerceIn(0, replications - 1)

        return Pair(bootstrapMeans[lowIdx], bootstrapMeans[highIdx])
    }

    /**
     * Computes Cohen's d effect size for hardware regression testing
     */
    fun computeEffectSize(baseline: List<Double>, candidate: List<Double>): Double {
        if (baseline.isEmpty() || candidate.isEmpty()) return 0.0
        val mean1 = baseline.average()
        val mean2 = candidate.average()
        val var1 = baseline.sumOf { (it - mean1).pow(2.0) } / (baseline.size - 1).coerceAtLeast(1)
        val var2 = candidate.sumOf { (it - mean2).pow(2.0) } / (candidate.size - 1).coerceAtLeast(1)
        val pooledStd = sqrt(((baseline.size - 1) * var1 + (candidate.size - 1) * var2) / (baseline.size + candidate.size - 2).coerceAtLeast(1))
        return if (pooledStd > 0.0) (mean2 - mean1) / pooledStd else 0.0
    }
}
