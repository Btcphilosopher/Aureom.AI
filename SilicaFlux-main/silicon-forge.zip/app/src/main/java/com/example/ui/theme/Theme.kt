package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SiliconDarkColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = Color(0xFF032830),
    primaryContainer = Color(0xFF083344),
    onPrimaryContainer = Color(0xFFA5F3FC),
    secondary = ElectricBlue,
    onSecondary = Color(0xFF0C243C),
    secondaryContainer = Color(0xFF162A45),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = CircuitGold,
    onTertiary = Color(0xFF332000),
    tertiaryContainer = Color(0xFF452B00),
    onTertiaryContainer = Color(0xFFFDE68A),
    background = SiliconDeepSlate,
    onBackground = TextPrimary,
    surface = SiliconDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = SiliconPanelElevated,
    onSurfaceVariant = TextSecondary,
    outline = SiliconBorder,
    outlineVariant = Color(0xFF1E293B),
    error = ThermalCritical,
    onError = Color.White
)

@Composable
fun SiliconForgeTheme(
    darkTheme: Boolean = true, // Silicon Forge defaults to dedicated dark engineering theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SiliconDarkColorScheme,
        typography = SiliconTypography,
        content = content
    )
}
