package com.example.siliconforge.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.siliconforge.model.BenchmarkCategory
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.siliconforge.ui.screens.BenchmarkScreen
import com.example.siliconforge.ui.screens.ComparisonScreen
import com.example.siliconforge.ui.screens.HardwareScreen
import com.example.siliconforge.ui.screens.OverviewScreen
import com.example.siliconforge.ui.screens.ReportsScreen
import com.example.siliconforge.ui.screens.ResultsScreen
import com.example.siliconforge.ui.screens.SimulationScreen
import com.example.siliconforge.ui.screens.TelemetryScreen
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalCritical
import com.example.ui.theme.ThermalWarning

enum class SiliconForgeNavDestination(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    OVERVIEW("overview", "Overview", Icons.Default.Dashboard),
    HARDWARE("hardware", "Hardware", Icons.Default.DeveloperBoard),
    BENCHMARKS("benchmarks", "Bench", Icons.Default.Science),
    TELEMETRY("telemetry", "Telemetry", Icons.Default.Thermostat),
    RESULTS("results", "Results", Icons.Default.Assessment),
    COMPARISON("comparison", "Compare", Icons.Default.CompareArrows),
    SIMULATION("simulation", "Sim Lab", Icons.Default.Architecture),
    REPORTS("reports", "Reports", Icons.Default.Description)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SiliconForgeApp(
    viewModel: SiliconForgeViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val runs by viewModel.benchmarkRuns.collectAsStateWithLifecycle()
    val liveState by viewModel.liveBenchmarkState.collectAsStateWithLifecycle()

    var currentDestination by remember { mutableStateOf(SiliconForgeNavDestination.OVERVIEW) }

    // Intercept back button to return to Overview from secondary screens
    BackHandler(enabled = currentDestination != SiliconForgeNavDestination.OVERVIEW) {
        currentDestination = SiliconForgeNavDestination.OVERVIEW
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = SiliconDeepSlate,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(SiliconPanelElevated, RoundedCornerShape(4.dp))
                                .border(1.dp, CyanAccent, RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = "Logo",
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "SILICON FORGE",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = TextPrimary,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                TechnicalBadge(text = "v2.4", color = CyanAccent)
                            }
                            Text(
                                text = "${uiState.hardware.socModel} • ${uiState.hardware.coreCount} Cores",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                    }
                },
                actions = {
                    val temp = uiState.telemetry.batteryTemperatureC
                    val tempColor = if (temp >= 40f) ThermalCritical else if (temp >= 35f) ThermalWarning else SiliconEmerald
                    TechnicalBadge(
                        text = "${String.format("%.1f", temp)}°C",
                        color = tempColor,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SiliconDarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        bottomBar = {
            // Horizontal scrollable technical engineering navigation bar
            val navScroll = rememberScrollState()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SiliconDarkSurface)
                    .border(
                        width = 1.dp,
                        color = SiliconBorder,
                        shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)
                    )
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(navScroll)
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SiliconForgeNavDestination.entries.forEach { dest ->
                        val isSelected = currentDestination == dest
                        val activeColor = if (dest == SiliconForgeNavDestination.SIMULATION) CircuitGold else CyanAccent

                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .background(
                                    color = if (isSelected) activeColor.copy(alpha = 0.18f) else Color.Transparent,
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) activeColor else Color.Transparent,
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .testTag("nav_tab_${dest.route}")
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .clickable { currentDestination = dest }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = dest.icon,
                                    contentDescription = dest.title,
                                    tint = if (isSelected) activeColor else TextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = dest.title.uppercase(),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal,
                                    color = if (isSelected) activeColor else TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentDestination) {
                SiliconForgeNavDestination.OVERVIEW -> {
                    OverviewScreen(
                        hardware = uiState.hardware,
                        telemetry = uiState.telemetry,
                        recentRuns = runs,
                        onLaunchBenchmark = { benchId ->
                            viewModel.launchQuickBenchmark(benchId)
                            currentDestination = SiliconForgeNavDestination.BENCHMARKS
                        },
                        onNavigateToBenchmarks = { currentDestination = SiliconForgeNavDestination.BENCHMARKS },
                        onNavigateToHardware = { currentDestination = SiliconForgeNavDestination.HARDWARE }
                    )
                }

                SiliconForgeNavDestination.HARDWARE -> {
                    HardwareScreen(hardware = uiState.hardware)
                }

                SiliconForgeNavDestination.BENCHMARKS -> {
                    BenchmarkScreen(
                        liveState = liveState,
                        onExecuteBenchmark = { def, mode, iters ->
                            viewModel.executeBenchmark(def, mode, iters)
                        },
                        onCancelBenchmark = { viewModel.cancelActiveBenchmark() }
                    )
                }

                SiliconForgeNavDestination.TELEMETRY -> {
                    TelemetryScreen(
                        telemetry = uiState.telemetry,
                        hardware = uiState.hardware,
                        temperatureHistory = uiState.temperatureHistory
                    )
                }

                SiliconForgeNavDestination.RESULTS -> {
                    ResultsScreen(
                        runs = runs,
                        onExportJson = { viewModel.exportRunsJson() },
                        onExportCsv = { viewModel.exportRunsCsv() },
                        onClearHistory = { viewModel.clearAllRuns() }
                    )
                }

                SiliconForgeNavDestination.COMPARISON -> {
                    ComparisonScreen(
                        hardware = uiState.hardware,
                        recentRuns = runs
                    )
                }

                SiliconForgeNavDestination.SIMULATION -> {
                    SimulationScreen()
                }

                SiliconForgeNavDestination.REPORTS -> {
                    ReportsScreen(
                        hardware = uiState.hardware,
                        runs = runs
                    )
                }
            }
        }
    }
}
