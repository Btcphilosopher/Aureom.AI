package com.example.siliconforge.model

data class ArchitectureConfig(
    val architectureName: String = "Hypothetical Zen/Oryon Hybrid",
    val coreCount: Int = 16,
    val clockGhz: Double = 3.6,
    val ipc: Double = 3.2,
    val executionWidth: Int = 8, // instructions / cycle
    val l1CacheKb: Int = 64,
    val l1LatencyNs: Double = 1.0,
    val l2CacheMb: Int = 2,
    val l2LatencyNs: Double = 3.5,
    val l3CacheMb: Int = 32,
    val l3LatencyNs: Double = 12.0,
    val memoryBandwidthGbps: Double = 120.0,
    val memoryLatencyNs: Double = 75.0,
    val chipletCount: Int = 2,
    val interconnectBandwidthGbps: Double = 400.0,
    val interconnectLatencyPenaltyNs: Double = 25.0,
    val tdpWatts: Double = 65.0,
    val thermalResistanceCPerWatt: Double = 0.45,
    val ambientTempC: Double = 24.0
)

data class RooflinePoint(
    val operationalIntensityFlopPerByte: Double,
    val attainableGFlops: Double,
    val isMemoryBound: Boolean
)

data class RooflineResult(
    val peakComputeGFlops: Double,
    val peakMemoryBandwidthGBps: Double,
    val ridgePointIntensity: Double, // Flops/byte where transition occurs
    val curvePoints: List<RooflinePoint>,
    val operationalPoint: RooflinePoint
)

data class AmdahlResult(
    val parallelFraction: Double, // 0.0 to 1.0 (e.g. 0.95 = 95%)
    val theoreticalSpeedup: Double,
    val parallelEfficiency: Double,
    val scalingCurve: List<Pair<Int, Double>> // coreCount to speedup
)

data class ChipletModelResult(
    val localMemoryLatencyNs: Double,
    val remoteMemoryLatencyNs: Double,
    val crossDiePenaltyPercent: Double,
    val interconnectSaturationAtCoreCount: Int,
    val effectiveAggregateBandwidthGBps: Double
)

data class ThermalRCResult(
    val steadyStateJunctionTempC: Double,
    val timeToThermalThrottleSec: Double,
    val willThrottle: Boolean,
    val tempTrajectory: List<Pair<Double, Double>> // time (seconds) to temperature (°C)
)

data class SimulationResult(
    val config: ArchitectureConfig,
    val roofline: RooflineResult,
    val amdahl: AmdahlResult,
    val chiplet: ChipletModelResult,
    val thermal: ThermalRCResult,
    val simulationTimestamp: Long = System.currentTimeMillis()
)
