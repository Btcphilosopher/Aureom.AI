package com.example.siliconforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.HardwareSnapshot
import com.example.siliconforge.model.TelemetrySnapshot
import com.example.siliconforge.ui.components.LineGraph
import com.example.siliconforge.ui.components.MetricsCard
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconEmerald
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThermalCritical
import com.example.ui.theme.ThermalWarning

@Composable
fun TelemetryScreen(
    telemetry: TelemetrySnapshot,
    hardware: HardwareSnapshot,
    temperatureHistory: List<Float>,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Top Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Thermostat, contentDescription = null, tint = CyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("LIVE TELEMETRY & THERMALS", style = MaterialTheme.typography.titleLarge, fontSize = 18.sp)
                Text("Synchronous frequency, temperature & power sampling", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Thermal Throttling Alert Banner
        if (telemetry.isThrottling) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ThermalCritical.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .border(1.dp, ThermalCritical, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = ThermalCritical)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("THERMAL THROTTLING DETECTED", fontFamily = JetBrainsMonoFontFamily, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 12.sp, color = ThermalCritical)
                        Text("Operating system kernel has lowered CPU scaling frequency to protect silicon junction.", fontSize = 11.sp, color = TextPrimary)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Live Telemetry Metric Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricsCard(
                title = "Silicon Temp",
                value = "${String.format("%.1f", telemetry.batteryTemperatureC)}",
                unit = "°C",
                subtitle = "Junction / Battery sensor",
                accentColor = if (telemetry.batteryTemperatureC > 38f) ThermalWarning else SiliconEmerald,
                badgeText = telemetry.thermalStatus,
                modifier = Modifier.weight(1f)
            )
            MetricsCard(
                title = "Battery Bus",
                value = "${telemetry.batteryVoltageMv}",
                unit = "mV",
                subtitle = "Level: ${telemetry.batteryPercent}%",
                accentColor = CircuitGold,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Real-Time Temperature Trajectory Curve
        Text(
            text = "JUNCTION TEMPERATURE TRAJECTORY (°C)",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        LineGraph(
            dataPoints = if (temperatureHistory.isNotEmpty()) temperatureHistory else listOf(25f, 26f, 27f, 28f, 28.5f),
            lineColor = if (telemetry.batteryTemperatureC > 38f) ThermalWarning else CyanAccent,
            minY = 20f,
            maxY = 55f
        )

        Spacer(modifier = Modifier.height(16.dp))

        // CPU Core Frequencies in Real-time
        Text(
            text = "LIVE CLOCK FREQUENCIES PER LOGICAL CORE",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        val freqs = telemetry.cpuFrequenciesKHz.ifEmpty { hardware.cores.map { it.curFreqKHz } }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            freqs.forEachIndexed { idx, freqKHz ->
                val coreInfo = hardware.cores.getOrNull(idx)
                val maxFreq = coreInfo?.maxFreqKHz ?: 2800000L
                val freqPercent = (freqKHz.toFloat() / maxFreq.toFloat()).coerceIn(0.1f, 1f)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SiliconDarkSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, SiliconBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "CORE $idx",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                color = TextMuted,
                                modifier = Modifier.width(60.dp)
                            )
                            coreInfo?.clusterType?.let {
                                TechnicalBadge(text = it.name, color = if (it.name == "PRIME") CircuitGold else ElectricBlue)
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "${freqKHz / 1000} MHz",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 12.sp,
                                color = CyanAccent
                            )
                            Text(
                                text = " / ${maxFreq / 1000} MHz",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { freqPercent },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp),
                            color = if (freqPercent > 0.85f) CircuitGold else ElectricBlue,
                            trackColor = SiliconBorder
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Memory Utilization Meter
        Text(
            text = "DRAM ALLOCATION & SWAP UTILIZATION",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SiliconDarkSurface, RoundedCornerShape(8.dp))
                .border(1.dp, SiliconBorder, RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Physical DRAM:", fontSize = 12.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                    Text(
                        "${hardware.memory.usedRamMB} MB used / ${hardware.memory.totalRamMB} MB total",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                }
                LinearProgressIndicator(
                    progress = { (telemetry.memoryUsagePercent / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp),
                    color = ElectricBlue,
                    trackColor = SiliconBorder
                )
                if (hardware.memory.swapTotalBytes > 0) {
                    val swapUsed = (hardware.memory.swapTotalBytes - hardware.memory.swapFreeBytes) / (1024 * 1024)
                    val swapTotal = hardware.memory.swapTotalBytes / (1024 * 1024)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text("ZRAM / Swap:", fontSize = 12.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                        Text(
                            "$swapUsed MB used / $swapTotal MB total",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}
