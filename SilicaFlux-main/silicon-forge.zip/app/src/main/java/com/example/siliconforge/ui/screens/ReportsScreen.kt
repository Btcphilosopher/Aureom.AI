package com.example.siliconforge.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siliconforge.model.BenchmarkRun
import com.example.siliconforge.model.HardwareSnapshot
import com.example.siliconforge.ui.components.TechnicalBadge
import com.example.ui.theme.CircuitGold
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SiliconBorder
import com.example.ui.theme.SiliconDarkSurface
import com.example.ui.theme.SiliconDeepSlate
import com.example.ui.theme.SiliconPanelElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ReportsScreen(
    hardware: HardwareSnapshot,
    runs: List<BenchmarkRun>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val generatedReport = remember(hardware, runs) {
        buildTechnicalReportMarkdown(hardware, runs)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiliconDeepSlate)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Description, contentDescription = null, tint = CyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("ENGINEERING REPORTS", style = MaterialTheme.typography.titleLarge, fontSize = 18.sp)
                Text("Validation certificate & reproducibility manifest", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Copy / Export Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("SiliconForge Engineering Report", generatedReport))
                    Toast.makeText(context, "Full Markdown report copied to clipboard", Toast.LENGTH_SHORT).show()
                },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = androidx.compose.ui.graphics.Color(0xFF032830)),
                modifier = Modifier
                    .weight(1f)
                    .testTag("copy_report_button")
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.height(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Copy Markdown Report", fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val sendIntent = android.content.Intent().apply {
                        action = android.content.Intent.ACTION_SEND
                        putExtra(android.content.Intent.EXTRA_TEXT, generatedReport)
                        type = "text/plain"
                    }
                    val shareIntent = android.content.Intent.createChooser(sendIntent, "Share Silicon Forge Report")
                    context.startActivity(shareIntent)
                },
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.height(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Share Report", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Formatted Engineering Report Viewer
        Card(
            colors = CardDefaults.cardColors(containerColor = SiliconDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, SiliconBorder),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SILICON FORGE LAB REPORT",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        fontSize = 14.sp,
                        color = CyanAccent,
                        modifier = Modifier.weight(1f)
                    )
                    TechnicalBadge(text = "ISO/IEC 29119 FORMAT", color = CircuitGold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SiliconPanelElevated, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = generatedReport,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

private fun buildTechnicalReportMarkdown(
    hardware: HardwareSnapshot,
    runs: List<BenchmarkRun>
): String {
    val sb = StringBuilder()
    sb.append("# SILICON FORGE ENGINEERING CHARACTERISATION REPORT\n")
    sb.append("Generated by Silicon Forge v2.4 Platform\n\n")

    sb.append("## 1. EXECUTIVE SUMMARY\n")
    sb.append("- Target Silicon: ${hardware.socModel} (${hardware.vendor})\n")
    sb.append("- Core Topology: ${hardware.coreCount} Cores (${hardware.cores.count { it.clusterType.name == "PRIME" }} Prime, ${hardware.cores.count { it.clusterType.name == "PERFORMANCE" }} Performance, ${hardware.cores.count { it.clusterType.name == "EFFICIENCY" }} Efficiency)\n")
    sb.append("- Total Validated Runs: ${runs.size}\n")
    sb.append("- Environmental Integrity: ${if (hardware.isVirtualMachine) "Virtualised Guest Container" else "Physical Silicon Device"}\n\n")

    sb.append("## 2. HARDWARE TOPOLOGY SPECIFICATION\n")
    sb.append("- Primary Architecture ABI: ${hardware.abi}\n")
    sb.append("- Kernel Release: ${hardware.kernelVersion}\n")
    sb.append("- DRAM Capacity: ${hardware.memory.totalRamMB} MB (${hardware.memory.availableRamMB} MB free at test)\n")
    sb.append("- Cache Hierarchy: L1D ${hardware.cacheHierarchy.l1dSizeKB}KB | L2 ${hardware.cacheHierarchy.l2SizeKB}KB | L3 ${hardware.cacheHierarchy.l3SizeKB / 1024}MB\n")
    sb.append("- GPU Accelerator: ${hardware.gpu.renderer} (${hardware.gpu.version})\n")
    sb.append("- Supported SIMD Extensions: ${hardware.cpuFeatures.filter { it in listOf("fp", "asimd", "neon", "aes", "sha1", "sha2", "crc32", "atomics", "fma", "sse4_2", "avx", "avx2") }.joinToString(", ")}\n\n")

    sb.append("## 3. MEASURED BENCHMARK CHARACTERISATION TABLE\n")
    sb.append("| Workload | Threads | Score | Unit | Normalized | 95% CI | CV% |\n")
    sb.append("| :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n")
    if (runs.isEmpty()) {
        sb.append("| (No completed benchmarks recorded) | - | - | - | - | - | - |\n")
    } else {
        runs.forEach { r ->
            sb.append("| ${r.benchmarkName} | ${r.threadCount}T | ${String.format("%.2f", r.rawScore)} | ${r.unit} | ${r.normalizedScore.toInt()} | [${String.format("%.1f", r.ci95Lower)}, ${String.format("%.1f", r.ci95Upper)}] | ${String.format("%.1f", r.cvPercent)}% |\n")
        }
    }
    sb.append("\n")

    sb.append("## 4. REPRODUCIBILITY & PROVENANCE MANIFEST\n")
    sb.append("- High-Resolution Timer Source: System.nanoTime() (CLOCK_MONOTONIC_RAW)\n")
    sb.append("- Statistical Bootstrap Iterations: 1,000 resamples\n")
    sb.append("- Verification Algorithm: Zero-suppression chained state sink (prevents compiler folding)\n")
    sb.append("- Platform Compliance: SILICON FORGE Master Engineering Standard\n")

    return sb.toString()
}
