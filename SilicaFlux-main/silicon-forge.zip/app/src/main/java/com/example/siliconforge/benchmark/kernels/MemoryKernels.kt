package com.example.siliconforge.benchmark.kernels

import java.util.Random

object MemoryKernels {

    @Volatile
    var blackHoleSink: Double = 0.0

    /**
     * STREAM Triad Benchmark: A[i] = B[i] + scalar * C[i]
     * Byte transferred per element = 3 * 8 bytes = 24 bytes (Read B, Read C, Write A).
     * Buffer size: 2,000,000 double elements (16 MB per array, 48 MB total), exceeding CPU L3 cache.
     */
    fun runStreamTriad(elements: Int = 1_500_000): Double {
        val a = DoubleArray(elements) { 1.0 }
        val b = DoubleArray(elements) { 2.0 }
        val c = DoubleArray(elements) { 3.0 }
        val scalar = 3.1415926535

        val start = System.nanoTime()
        for (i in 0 until elements) {
            a[i] = b[i] + scalar * c[i]
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = a[elements / 2]

        val elapsedSec = elapsedNs / 1_000_000_000.0
        val bytesTransferred = 3.0 * elements.toDouble() * 8.0 // 24 bytes per iteration
        val gigabytes = bytesTransferred / (1024.0 * 1024.0 * 1024.0)
        return gigabytes / elapsedSec // GB/s
    }

    /**
     * STREAM Copy Benchmark: A[i] = B[i]
     * Bytes transferred per element = 2 * 8 bytes = 16 bytes (Read B, Write A).
     */
    fun runStreamCopy(elements: Int = 2_000_000): Double {
        val a = DoubleArray(elements)
        val b = DoubleArray(elements) { it.toDouble() }

        val start = System.nanoTime()
        for (i in 0 until elements) {
            a[i] = b[i]
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = a[elements - 1]

        val elapsedSec = elapsedNs / 1_000_000_000.0
        val bytesTransferred = 2.0 * elements.toDouble() * 8.0
        val gigabytes = bytesTransferred / (1024.0 * 1024.0 * 1024.0)
        return gigabytes / elapsedSec // GB/s
    }

    /**
     * Pointer Chasing Cache-Hierarchy Latency Ladder
     * Constructs a cyclic pseudo-random permutation over an array of size workingSetBytes.
     * Traverses dependent pointer chain so CPU out-of-order and prefetcher cannot predict addresses.
     * Returns average access latency in nanoseconds per load.
     */
    fun measurePointerChasingLatency(workingSetBytes: Int, iterations: Int = 1_000_000): Double {
        val numElements = (workingSetBytes / 4).coerceAtLeast(64)
        val pointerArray = IntArray(numElements)

        // Build a randomized cyclic permutation to disable hardware strided prefetcher
        val indices = IntArray(numElements) { it }
        val random = Random(12345)
        for (i in indices.indices.reversed()) {
            val j = random.nextInt(i + 1)
            val tmp = indices[i]; indices[i] = indices[j]; indices[j] = tmp
        }
        for (i in 0 until numElements - 1) {
            pointerArray[indices[i]] = indices[i + 1]
        }
        pointerArray[indices[numElements - 1]] = indices[0]

        // Pointer-chasing loop (strict serial dependency: next = array[curr])
        var curr = 0
        val start = System.nanoTime()
        for (i in 0 until iterations) {
            curr = pointerArray[curr]
        }
        val elapsedNs = System.nanoTime() - start

        blackHoleSink = curr.toDouble()

        return elapsedNs.toDouble() / iterations.toDouble() // ns per memory access
    }

    /**
     * Executes the full Cache Ladder across standard semiconductor boundaries:
     * 8 KB (L1), 32 KB (L1), 128 KB (L2), 512 KB (L2), 2 MB (L2/L3), 8 MB (L3), 32 MB (DRAM)
     */
    fun runCacheLatencyLadder(): List<Pair<Int, Double>> {
        val workingSetsKb = listOf(8, 32, 128, 512, 2048, 8192, 32768)
        return workingSetsKb.map { kb ->
            val latencyNs = measurePointerChasingLatency(kb * 1024, iterations = 800_000)
            Pair(kb, latencyNs)
        }
    }
}
