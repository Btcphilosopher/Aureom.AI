package com.example.siliconforge.hardware

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.siliconforge.model.CacheHierarchy
import com.example.siliconforge.model.CoreClusterType
import com.example.siliconforge.model.CpuCoreInfo
import com.example.siliconforge.model.GpuInfo
import com.example.siliconforge.model.HardwareSnapshot
import com.example.siliconforge.model.MemoryInfo
import com.example.siliconforge.model.TelemetrySnapshot
import java.io.File
import java.io.RandomAccessFile

object HardwareDiscovery {

    fun captureHardwareSnapshot(context: Context): HardwareSnapshot {
        val cores = discoverCpuCores()
        val cpuFeatures = parseCpuFeatures()
        val bogoMips = parseBogoMips()
        val kernelVersion = parseKernelVersion()
        val memory = getMemoryInfo(context)
        val gpu = discoverGpuInfo()

        val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.takeIf { it.isNotBlank() && it != Build.UNKNOWN }
                ?: Build.HARDWARE
        } else {
            Build.HARDWARE
        }

        val cache = estimateCacheHierarchy(cores.size)

        return HardwareSnapshot(
            socModel = socModel.ifBlank { "Host Application Processor" },
            vendor = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",
            coreCount = cores.size.coerceAtLeast(Runtime.getRuntime().availableProcessors()),
            cores = cores,
            cpuFeatures = cpuFeatures,
            bogoMips = bogoMips,
            kernelVersion = kernelVersion,
            cacheHierarchy = cache,
            memory = memory,
            gpu = gpu,
            osBuild = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) - ${Build.DISPLAY}",
            isVirtualMachine = Build.FINGERPRINT.startsWith("generic") ||
                    Build.MODEL.contains("google_sdk") ||
                    Build.HARDWARE.contains("goldfish") ||
                    Build.HARDWARE.contains("ranchu")
        )
    }

    private fun discoverCpuCores(): List<CpuCoreInfo> {
        val coreList = mutableListOf<CpuCoreInfo>()
        val runtimeCores = Runtime.getRuntime().availableProcessors()
        var maxObservedFreq = 0L

        // First pass: identify frequencies
        val rawFreqs = (0 until 32).mapNotNull { idx ->
            val cur = readLongFromFile("/sys/devices/system/cpu/cpu$idx/cpufreq/scaling_cur_freq")
            val max = readLongFromFile("/sys/devices/system/cpu/cpu$idx/cpufreq/cpuinfo_max_freq")
            val min = readLongFromFile("/sys/devices/system/cpu/cpu$idx/cpufreq/cpuinfo_min_freq")
            val gov = readStringFromFile("/sys/devices/system/cpu/cpu$idx/cpufreq/scaling_governor") ?: "schedutil"
            val isOnline = readStringFromFile("/sys/devices/system/cpu/cpu$idx/online")?.trim() != "0"

            if (max != null || cur != null) {
                val effectiveMax = max ?: (cur ?: 2400000L)
                if (effectiveMax > maxObservedFreq) maxObservedFreq = effectiveMax
                Pair(idx, Triple(cur ?: effectiveMax, min ?: 400000L, effectiveMax to gov))
            } else {
                null
            }
        }

        val effectiveCount = if (rawFreqs.isNotEmpty()) rawFreqs.size else runtimeCores

        for (idx in 0 until effectiveCount) {
            val freqData = rawFreqs.find { it.first == idx }
            val cur = freqData?.second?.first ?: 2000000L
            val min = freqData?.second?.second ?: 400000L
            val (max, gov) = freqData?.second?.third ?: (2400000L to "schedutil")

            // Determine cluster type (Prime > 2.8GHz, Performance > 2.0GHz, Efficiency <= 2.0GHz)
            val clusterType = when {
                max >= 2800000L || (maxObservedFreq > 0 && max == maxObservedFreq && idx >= effectiveCount - 2) -> CoreClusterType.PRIME
                max >= 2000000L -> CoreClusterType.PERFORMANCE
                else -> CoreClusterType.EFFICIENCY
            }

            coreList.add(
                CpuCoreInfo(
                    coreIndex = idx,
                    clusterType = clusterType,
                    curFreqKHz = cur,
                    minFreqKHz = min,
                    maxFreqKHz = max,
                    governor = gov,
                    isOnline = true
                )
            )
        }

        return coreList.ifEmpty {
            (0 until runtimeCores).map { idx ->
                CpuCoreInfo(
                    coreIndex = idx,
                    clusterType = if (idx == runtimeCores - 1) CoreClusterType.PRIME else CoreClusterType.PERFORMANCE,
                    curFreqKHz = 2400000L,
                    minFreqKHz = 600000L,
                    maxFreqKHz = 2800000L,
                    governor = "schedutil",
                    isOnline = true
                )
            }
        }
    }

    private fun parseCpuFeatures(): List<String> {
        val features = mutableSetOf<String>()
        try {
            val file = File("/proc/cpuinfo")
            if (file.exists()) {
                file.forEachLine { line ->
                    if (line.startsWith("Features", ignoreCase = true) || line.startsWith("flags", ignoreCase = true)) {
                        val parts = line.substringAfter(":").trim().split(" ")
                        features.addAll(parts.filter { it.isNotBlank() })
                    }
                }
            }
        } catch (_: Exception) {}

        if (features.isEmpty()) {
            // Sensible architectural defaults based on supported ABIs
            if (Build.SUPPORTED_ABIS.any { it.contains("arm64") }) {
                features.addAll(listOf("fp", "asimd", "evtstrm", "aes", "pmull", "sha1", "sha2", "crc32", "atomics", "fphp", "asimdhp"))
            } else if (Build.SUPPORTED_ABIS.any { it.contains("x86") }) {
                features.addAll(listOf("fpu", "vme", "de", "pse", "tsc", "msr", "pae", "cx8", "apic", "sep", "mtrr", "sse", "sse2", "sse3", "ssse3", "sse4_1", "sse4_2", "avx", "avx2", "fma"))
            }
        }
        return features.toList().sorted()
    }

    private fun parseBogoMips(): String {
        return try {
            val file = File("/proc/cpuinfo")
            if (file.exists()) {
                file.useLines { lines ->
                    lines.firstOrNull { it.contains("BogoMIPS", ignoreCase = true) }
                        ?.substringAfter(":")?.trim() ?: "N/A"
                }
            } else "N/A"
        } catch (_: Exception) {
            "N/A"
        }
    }

    private fun parseKernelVersion(): String {
        return try {
            val file = File("/proc/version")
            if (file.exists()) file.readText().trim() else System.getProperty("os.version") ?: "Linux"
        } catch (_: Exception) {
            System.getProperty("os.version") ?: "Linux"
        }
    }

    private fun getMemoryInfo(context: Context): MemoryInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)

        var swapTotal = 0L
        var swapFree = 0L

        try {
            File("/proc/meminfo").forEachLine { line ->
                if (line.startsWith("SwapTotal:")) {
                    swapTotal = parseMeminfoKb(line) * 1024L
                } else if (line.startsWith("SwapFree:")) {
                    swapFree = parseMeminfoKb(line) * 1024L
                }
            }
        } catch (_: Exception) {}

        return MemoryInfo(
            totalRamBytes = if (memInfo.totalMem > 0) memInfo.totalMem else Runtime.getRuntime().maxMemory() * 4,
            availableRamBytes = if (memInfo.availMem > 0) memInfo.availMem else Runtime.getRuntime().freeMemory() * 2,
            swapTotalBytes = swapTotal,
            swapFreeBytes = swapFree,
            pageSizeBytes = 4096
        )
    }

    private fun parseMeminfoKb(line: String): Long {
        return line.substringAfter(":").trim().substringBefore(" ").toLongOrNull() ?: 0L
    }

    private fun estimateCacheHierarchy(coreCount: Int): CacheHierarchy {
        // Look up sysfs cache directories if readable
        var l1i = 0
        var l1d = 0
        var l2 = 0
        var l3 = 0

        for (index in 0 until 4) {
            val sizeStr = readStringFromFile("/sys/devices/system/cpu/cpu0/cache/index$index/size")
            val level = readStringFromFile("/sys/devices/system/cpu/cpu0/cache/index$index/level")?.trim()?.toIntOrNull()
            val type = readStringFromFile("/sys/devices/system/cpu/cpu0/cache/index$index/type")?.trim()

            if (sizeStr != null && level != null) {
                val sizeKb = parseCacheSizeKb(sizeStr)
                when (level) {
                    1 -> if (type?.contains("Instruction", ignoreCase = true) == true) l1i = sizeKb else l1d = sizeKb
                    2 -> l2 = sizeKb
                    3 -> l3 = sizeKb
                }
            }
        }

        return CacheHierarchy(
            l1iSizeKB = if (l1i > 0) l1i else 64,
            l1dSizeKB = if (l1d > 0) l1d else 64,
            l2SizeKB = if (l2 > 0) l2 else (coreCount * 512).coerceAtLeast(1024),
            l3SizeKB = if (l3 > 0) l3 else (coreCount * 2048).coerceAtLeast(8192),
            l1LatencyNs = 1.05,
            l2LatencyNs = 3.8,
            l3LatencyNs = 12.5
        )
    }

    private fun parseCacheSizeKb(sizeStr: String): Int {
        val clean = sizeStr.trim()
        val num = clean.filter { it.isDigit() }.toIntOrNull() ?: 0
        return when {
            clean.endsWith("M", ignoreCase = true) || clean.endsWith("MB", ignoreCase = true) -> num * 1024
            clean.endsWith("K", ignoreCase = true) || clean.endsWith("KB", ignoreCase = true) -> num
            else -> num / 1024
        }
    }

    private fun discoverGpuInfo(): GpuInfo {
        var renderer = "Standard Hardware GLES Accelerator"
        var vendor = "Qualcomm / ARM / Android Subsystem"
        var version = "OpenGL ES 3.2"
        var glsl = "OpenGL ES GLSL ES 3.20"
        var extensionsCount = 48
        var success = false

        try {
            val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                val vers = IntArray(2)
                if (EGL14.eglInitialize(dpy, vers, 0, vers, 1)) {
                    val configAttribs = intArrayOf(
                        EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                        EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                        EGL14.EGL_NONE
                    )
                    val configs = arrayOfNulls<EGLConfig>(1)
                    val numConfigs = IntArray(1)
                    EGL14.eglChooseConfig(dpy, configAttribs, 0, configs, 0, 1, numConfigs, 0)

                    val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
                    val ctx = EGL14.eglCreateContext(dpy, configs[0], EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
                    val surfAttribs = intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE)
                    val surf = EGL14.eglCreatePbufferSurface(dpy, configs[0], surfAttribs, 0)

                    if (ctx != EGL14.EGL_NO_CONTEXT && surf != EGL14.EGL_NO_SURFACE) {
                        EGL14.eglMakeCurrent(dpy, surf, surf, ctx)
                        val r = GLES20.glGetString(GLES20.GL_RENDERER)
                        val v = GLES20.glGetString(GLES20.GL_VENDOR)
                        val ver = GLES20.glGetString(GLES20.GL_VERSION)
                        val g = GLES20.glGetString(GLES20.GL_SHADING_LANGUAGE_VERSION)
                        val ext = GLES20.glGetString(GLES20.GL_EXTENSIONS)

                        if (!r.isNullOrBlank()) renderer = r
                        if (!v.isNullOrBlank()) vendor = v
                        if (!ver.isNullOrBlank()) version = ver
                        if (!g.isNullOrBlank()) glsl = g
                        if (!ext.isNullOrBlank()) extensionsCount = ext.split(" ").size
                        success = true

                        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                        EGL14.eglDestroySurface(dpy, surf)
                        EGL14.eglDestroyContext(dpy, ctx)
                    }
                    EGL14.eglTerminate(dpy)
                }
            }
        } catch (_: Exception) {}

        return GpuInfo(
            renderer = renderer,
            vendor = vendor,
            version = version,
            glslVersion = glsl,
            extensionsCount = extensionsCount,
            isAvailable = success
        )
    }

    fun captureTelemetry(context: Context): TelemetrySnapshot {
        var tempC = 25.0f
        var voltageMv = 4000
        var batteryLevel = 100
        var currentMicroAmp = 0L

        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent = context.registerReceiver(null, filter)
            if (intent != null) {
                val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 250)
                tempC = tempRaw / 10.0f
                voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 4000)
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level >= 0 && scale > 0) {
                    batteryLevel = (level * 100) / scale
                }
            }
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            currentMicroAmp = bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0L
        } catch (_: Exception) {}

        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val thermalStatusStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (pm?.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "NORMAL"
                PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
                PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
                PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
                PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
                else -> "NORMAL"
            }
        } else {
            if (tempC >= 42.0f) "SEVERE" else if (tempC >= 38.0f) "MODERATE" else "NORMAL"
        }

        val isThrottling = thermalStatusStr in listOf("SEVERE", "CRITICAL", "EMERGENCY", "SHUTDOWN")

        // Read current frequencies across cores
        val runtimeCores = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until runtimeCores).map { idx ->
            readLongFromFile("/sys/devices/system/cpu/cpu$idx/cpufreq/scaling_cur_freq") ?: 2200000L
        }

        val mem = getMemoryInfo(context)

        return TelemetrySnapshot(
            timestamp = System.currentTimeMillis(),
            batteryPercent = batteryLevel,
            batteryTemperatureC = tempC,
            batteryVoltageMv = voltageMv,
            currentNowMicroAmp = currentMicroAmp,
            thermalStatus = thermalStatusStr,
            isThrottling = isThrottling,
            cpuFrequenciesKHz = freqs,
            memoryUsagePercent = mem.usagePercent
        )
    }

    private fun readStringFromFile(path: String): String? {
        return try {
            val file = File(path)
            if (file.exists() && file.canRead()) file.readText().trim() else null
        } catch (_: Exception) {
            null
        }
    }

    private fun readLongFromFile(path: String): Long? {
        return readStringFromFile(path)?.toLongOrNull()
    }
}
