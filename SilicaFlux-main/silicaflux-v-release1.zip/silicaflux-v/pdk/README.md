# PDK collateral

No PDK files are committed (size, licences).  Baselines use public PDKs:

| PDK | Node | Source | Used for |
|---|---|---|---|
| SkyWater SKY130 (sky130_fd_sc_hd) + OpenRAM `sky130_sram_1rw1r_128x256_8` | 130 nm | OpenROAD-flow-scripts `flow/platforms/{sky130hd,sky130ram}` | baseline synthesis, placement, STA, power |
| IHP SG13G2 + `RM_IHPSG13_1P_{2048,512}x64_c2_bm_bist` | 130 nm | OpenROAD-flow-scripts `flow/platforms/ihp-sg13g2`, IHP-Open-PDK (SRAM behavioural core) | baseline synthesis, placement, STA, power, macro-model simulation |

`pdk/fetch_open_pdks.sh <dir>` reproduces the setup.  Commercial 130 nm and
65 nm implementations use `asic/configs/commercial_{130,65}nm.cfg.template`
plus a `asic/tech/<pdk>/` directory (ICG + SRAM tiling wrappers) filled from
the foundry kit; no foundry IP is or will be included here.
