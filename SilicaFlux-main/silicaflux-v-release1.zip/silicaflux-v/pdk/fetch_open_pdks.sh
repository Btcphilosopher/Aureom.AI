#!/usr/bin/env bash
# Fetch the public PDK collateral used by the baseline ASIC flow (sky130hd,
# sky130 OpenRAM macros, IHP SG13G2 incl. SRAM macros) and OpenROAD.
#   pdk/fetch_open_pdks.sh <deps_dir>
# Afterwards: export PLATFORMS=<deps_dir>/orfs/flow/platforms
#             export STA=<deps_dir>/openroad-env/bin/sta OPENROAD=<deps_dir>/openroad-env/bin/openroad
set -euo pipefail
D=${1:-deps}; mkdir -p "$D"; cd "$D"
git clone --depth 1 --filter=blob:none --sparse https://github.com/The-OpenROAD-Project/OpenROAD-flow-scripts orfs
git -C orfs sparse-checkout set flow/platforms/sky130hd flow/platforms/sky130ram flow/platforms/ihp-sg13g2
mkdir -p ihp_sram
curl -fsSL -o ihp_sram/RM_IHPSG13_1P_core_behavioral_bm_bist.v \
  https://raw.githubusercontent.com/IHP-GmbH/IHP-Open-PDK/main/ihp-sg13g2/libs.ref/sg13g2_sram/verilog/RM_IHPSG13_1P_core_behavioral_bm_bist.v
git clone --depth 1 https://github.com/riscv-software-src/riscv-tests riscv-tests
git clone https://github.com/riscv/riscv-test-env riscv-tests/env && git -C riscv-tests/env checkout 6de71ed
# OpenROAD + OpenSTA from the litex-hub conda channel (any OpenROAD >= 2.0 works)
if [ ! -x openroad-env/bin/openroad ]; then
  echo "install micromamba, then:"
  echo "  micromamba create -y -p $PWD/openroad-env -c litex-hub -c https://repo.anaconda.com/pkgs/main openroad"
fi
