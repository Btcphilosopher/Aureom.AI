/* =============================================================================
 * SilicaFlux-V boot ROM.
 *   BOOT_SPI  (0): load image from SPI NOR flash (READ 0x03) -> SRAM, verify,
 *                  jump.  Image = sfv_img_hdr_t + payload (scripts/mkimage.py)
 *   BOOT_JTAG (1): wait for a host to load SRAM over JTAG and post the mailbox
 *                  (SCRATCH1 = 0xB007C0DE, SCRATCH0 = entry), then jump.
 *   BOOT_POST (2): power-on self test (SRAM, vector, tensor vs. golden
 *                  constants), report on UART + TEST_STATUS, halt.
 *   BOOT_SRAM (3): jump to SRAM base (image preloaded by tester/JTAG/sim).
 * ===========================================================================*/
#include "../common/sfv_accel.h"
#include "../common/sfv_lib.h"
#include "post_vectors.h"

typedef void (*entry_fn)(void);

static uint8_t spi_xfer(uint8_t b) {
  SPI_DATA = b;
  while (SPI_STATUS & SPI_BUSY) {
  }
  return (uint8_t)SPI_DATA;
}

static uint32_t flash_read_word(void) {
  uint32_t w = 0;
  for (int i = 0; i < 4; i++) w |= (uint32_t)spi_xfer(0) << (8 * i);
  return w;
}

static uint32_t img_check(uint32_t c, uint32_t w) { return ((c << 1) | (c >> 31)) ^ w; }

static uint32_t spi_boot(void) {
  SPI_DIV = 0;                               /* SCK = clk/2 */
  SPI_CTRL = SPI_CS0;                        /* mode 0, CS0 asserted */
  spi_xfer(0x03);                            /* READ, address 0x000000 */
  spi_xfer(0); spi_xfer(0); spi_xfer(0);
  sfv_img_hdr_t h;
  h.magic = flash_read_word();
  h.load = flash_read_word();
  h.length = flash_read_word();
  h.entry = flash_read_word();
  h.check = flash_read_word();
  uint32_t lim = SFV_SRAM_BASE + SFV_SRAM_SIZE - 2048u;   /* ROM stack */
  if (h.magic != SFV_IMG_MAGIC || h.load < SFV_SRAM_BASE || h.length > lim - h.load ||
      h.entry < h.load || h.entry >= h.load + h.length) {
    SPI_CTRL = 0;
    print_kv("boot: bad image header magic", h.magic);
    return 0;
  }
  volatile uint32_t *dst = (volatile uint32_t *)(uintptr_t)h.load;
  uint32_t c = 0;
  for (uint32_t i = 0; i < h.length / 4u; i++) {
    uint32_t w = flash_read_word();
    dst[i] = w;
    c = img_check(c, w);
  }
  SPI_CTRL = 0;
  if (c != h.check) {
    print_kv("boot: image check FAIL", c);
    return 0;
  }
  print_kv("boot: loaded bytes", h.length);
  return h.entry;
}

static int post_sram(void) {
  int err = 0;
  for (uint32_t bank = 0; bank < 4; bank++) {
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)(SFV_SRAM_BASE + bank * SFV_SRAM_BANK);
    for (uint32_t i = 0; i < 64; i++) p[i] = 0xA5000000u ^ (bank << 16) ^ i;
    for (uint32_t i = 0; i < 64; i++) err |= (p[i] != (0xA5000000u ^ (bank << 16) ^ i));
    volatile uint8_t *b = (volatile uint8_t *)p;
    volatile uint16_t *h = (volatile uint16_t *)p;
    b[1] = 0x5A;                    /* byte lane 1 */
    h[1] = 0xBEEF;                  /* upper half-word; byte 0 must survive */
    err |= p[0] != 0xBEEF5A00u;
  }
  return err;
}

static int post_vector(void) {
  volatile uint32_t *t = TSPM_PTR(0);
  for (int i = 0; i < 8; i++) { t[i] = post_va[i]; t[8 + i] = post_vb[i]; }
  int err = 0;
  err |= (ve_run(VOP_ADD, 0, 0, 32, 64, 8, 0) & ACC_ERR) != 0;
  for (int i = 0; i < 8; i++) err |= t[16 + i] != post_vadd[i];
  err |= (ve_run(VOP_MUL, 0, 0, 32, 64, 8, 0) & ACC_ERR) != 0;
  for (int i = 0; i < 8; i++) err |= t[16 + i] != post_vmul[i];
  err |= (ve_run(VOP_DOT, 0, 0, 32, 0, 8, 0) & ACC_ERR) != 0;
  err |= VE_RESULT != POST_VDOT;
  return err;
}

static int post_tensor(void) {
  volatile uint32_t *t = TSPM_PTR(0x100);
  for (int k = 0; k < 4; k++) { t[k] = post_ta[k]; t[4 + k] = post_tb[k]; }
  int err = (te_run(TE_CFG_WB, 0x100, 0x110, 0x140, 4, 0, 0, 0) & ACC_ERR) != 0;
  for (int i = 0; i < 16; i++) {
    err |= TE_ACC(i) != post_tc[i];
    err |= t[16 + i] != post_tc[i];
  }
  return err;
}

void rom_main(uint32_t mbist, uint32_t mode) {
  uart_puts("\nSilicaFlux-V boot ROM\n");
  print_kv("chip_id", SYS_CHIP_ID);
  print_kv("boot_mode", mode);
  if (mbist & 0x100000u) {
    print_kv("mbist", mbist & 0xFFFFFu);
    if (mbist & 4u) {                       /* FAIL bit */
      uart_puts("MBIST FAIL\n");
      uart_flush();
      test_status(TEST_FAIL, 0x01);
      return;
    }
  }
  uint32_t entry = 0;
  switch (mode) {
    case BOOT_SPI:
      entry = spi_boot();
      break;
    case BOOT_JTAG:
      uart_puts("boot: waiting for JTAG host\n");
      while (SYS_SCRATCH1 != SFV_JTAG_MAGIC) {
      }
      entry = SYS_SCRATCH0;
      break;
    case BOOT_POST: {
      uint32_t e = (uint32_t)post_sram() | ((uint32_t)post_vector() << 1) |
                   ((uint32_t)post_tensor() << 2);
      print_kv("post", e);
      uart_puts(e ? "POST FAIL\n" : "POST PASS\n");
      uart_flush();
      test_status(e ? TEST_FAIL : TEST_PASS, e);
      return;
    }
    default:
      entry = SFV_SRAM_BASE;
      break;
  }
  if (!entry) {
    uart_flush();
    test_status(TEST_FAIL, 0x02);
    return;
  }
  print_kv("boot: jump", entry);
  uart_flush();
  ((entry_fn)(uintptr_t)entry)();
}
