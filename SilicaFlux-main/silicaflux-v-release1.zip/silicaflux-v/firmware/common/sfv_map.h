/* =============================================================================
 * SilicaFlux-V memory map and register definitions.
 * Must match rtl/pkg/sfv_pkg.sv and docs/MEMORY_MAP.md (checked by
 * scripts/check_map.py).
 * ===========================================================================*/
#ifndef SFV_MAP_H
#define SFV_MAP_H
#include <stdint.h>

#define REG32(a) (*(volatile uint32_t *)(uintptr_t)(a))

/* ---- address map ---------------------------------------------------------*/
#define SFV_ROM_BASE    0x00000000u
#define SFV_SRAM_BASE   0x10000000u
#define SFV_SRAM_SIZE   (128u * 1024u)           /* 4 banks x 32 KiB */
#define SFV_SRAM_BANK   (32u * 1024u)
#define SFV_TSPM_BASE   0x20000000u
#define SFV_TSPM_SIZE   (16u * 1024u)
#define SFV_PERIPH_BASE 0x40000000u

#define SFV_SYSCTRL 0x40000000u
#define SFV_INTC    0x40001000u
#define SFV_TIMER   0x40002000u
#define SFV_UART    0x40003000u
#define SFV_SPI     0x40004000u
#define SFV_GPIO    0x40005000u
#define SFV_VE      0x40010000u
#define SFV_TE      0x40011000u

/* ---- SYSCTRL -------------------------------------------------------------*/
#define SYS_CHIP_ID      REG32(SFV_SYSCTRL + 0x00)
#define SYS_BOOT_MODE    REG32(SFV_SYSCTRL + 0x04)
#define SYS_SCRATCH0     REG32(SFV_SYSCTRL + 0x08)
#define SYS_SCRATCH1     REG32(SFV_SYSCTRL + 0x0C)
#define SYS_TEST_STATUS  REG32(SFV_SYSCTRL + 0x10)
#define SYS_SOFT_RESET   REG32(SFV_SYSCTRL + 0x14)
#define SYS_RESET_CAUSE  REG32(SFV_SYSCTRL + 0x18)
#define SYS_CLK_CTRL     REG32(SFV_SYSCTRL + 0x1C)
#define SYS_BUSERR_ADDR  REG32(SFV_SYSCTRL + 0x20)
#define SYS_BUSERR_INFO  REG32(SFV_SYSCTRL + 0x24)
#define SYS_MBIST_CTRL   REG32(SFV_SYSCTRL + 0x28)
#define SYS_MBIST_STATUS REG32(SFV_SYSCTRL + 0x2C)
#define SYS_DOORBELL     REG32(SFV_SYSCTRL + 0x30)
#define SFV_CHIP_ID_VAL  0x53465601u
#define SFV_SOFT_RESET_KEY 0x5AFE0001u
#define SFV_JTAG_MAGIC   0xB007C0DEu
#define TEST_RUNNING 0u
#define TEST_PASS    1u
#define TEST_FAIL    2u
#define BOOT_SPI     0u
#define BOOT_JTAG    1u
#define BOOT_POST    2u
#define BOOT_SRAM    3u

/* ---- INTC ----------------------------------------------------------------*/
#define INTC_PENDING REG32(SFV_INTC + 0x00)
#define INTC_ENABLE  REG32(SFV_INTC + 0x04)
#define INTC_CLAIM   REG32(SFV_INTC + 0x08)
#define IRQ_UART 0
#define IRQ_SPI  1
#define IRQ_GPIO 2
#define IRQ_VE   3
#define IRQ_TE   4
#define IRQ_MBIST 5
#define IRQ_BUSERR 6
#define IRQ_DBG  7

/* ---- TIMER ---------------------------------------------------------------*/
#define TIMER_MTIME_LO REG32(SFV_TIMER + 0x00)
#define TIMER_MTIME_HI REG32(SFV_TIMER + 0x04)
#define TIMER_CMP_LO   REG32(SFV_TIMER + 0x08)
#define TIMER_CMP_HI   REG32(SFV_TIMER + 0x0C)
#define TIMER_MSIP     REG32(SFV_TIMER + 0x10)
#define TIMER_PRESCALE REG32(SFV_TIMER + 0x14)

/* ---- UART ----------------------------------------------------------------*/
#define UART_DATA   REG32(SFV_UART + 0x00)
#define UART_STATUS REG32(SFV_UART + 0x04)
#define UART_CTRL   REG32(SFV_UART + 0x08)
#define UART_BAUD   REG32(SFV_UART + 0x0C)
#define UART_TX_READY  (1u << 0)
#define UART_TX_IDLE   (1u << 1)
#define UART_RX_VALID  (1u << 2)
#define UART_LOOPBACK  (1u << 2)

/* ---- SPI -----------------------------------------------------------------*/
#define SPI_DATA   REG32(SFV_SPI + 0x00)
#define SPI_STATUS REG32(SFV_SPI + 0x04)
#define SPI_CTRL   REG32(SFV_SPI + 0x08)
#define SPI_DIV    REG32(SFV_SPI + 0x0C)
#define SPI_BUSY   (1u << 0)
#define SPI_CS0    (1u << 8)

/* ---- GPIO ----------------------------------------------------------------*/
#define GPIO_IN    REG32(SFV_GPIO + 0x00)
#define GPIO_OUT   REG32(SFV_GPIO + 0x04)
#define GPIO_OE    REG32(SFV_GPIO + 0x08)
#define GPIO_RISE  REG32(SFV_GPIO + 0x0C)
#define GPIO_FALL  REG32(SFV_GPIO + 0x10)
#define GPIO_PEND  REG32(SFV_GPIO + 0x14)

/* ---- vector engine -------------------------------------------------------*/
#define VE_CTRL   REG32(SFV_VE + 0x00)
#define VE_STATUS REG32(SFV_VE + 0x04)
#define VE_CMD    REG32(SFV_VE + 0x08)
#define VE_SRC_A  REG32(SFV_VE + 0x0C)
#define VE_SRC_B  REG32(SFV_VE + 0x10)
#define VE_DST    REG32(SFV_VE + 0x14)
#define VE_LEN    REG32(SFV_VE + 0x18)
#define VE_SCALAR REG32(SFV_VE + 0x1C)
#define VE_RESULT REG32(SFV_VE + 0x20)
#define VE_CYCLES REG32(SFV_VE + 0x24)
#define VE_INFO   REG32(SFV_VE + 0x28)
enum { VOP_ADD, VOP_SUB, VOP_MUL, VOP_MIN, VOP_MAX, VOP_AND, VOP_OR, VOP_XOR,
       VOP_SLL, VOP_SRA, VOP_SRL, VOP_DOT, VOP_COUNT };
#define VE_CMD_BSCALAR (1u << 8)
#define VE_CMD_ACC     (1u << 9)
#define VE_CMD_WRES    (1u << 10)

/* ---- tensor engine -------------------------------------------------------*/
#define TE_CTRL     REG32(SFV_TE + 0x00)
#define TE_STATUS   REG32(SFV_TE + 0x04)
#define TE_CFG      REG32(SFV_TE + 0x08)
#define TE_A_ADDR   REG32(SFV_TE + 0x0C)
#define TE_B_ADDR   REG32(SFV_TE + 0x10)
#define TE_C_ADDR   REG32(SFV_TE + 0x14)
#define TE_K        REG32(SFV_TE + 0x18)
#define TE_A_STRIDE REG32(SFV_TE + 0x1C)
#define TE_B_STRIDE REG32(SFV_TE + 0x20)
#define TE_C_STRIDE REG32(SFV_TE + 0x24)
#define TE_CYCLES   REG32(SFV_TE + 0x28)
#define TE_INFO     REG32(SFV_TE + 0x2C)
#define TE_ACC(i)   REG32(SFV_TE + 0x40 + 4u * (i))
#define TE_CFG_ACC   (1u << 0)
#define TE_CFG_WB    (1u << 1)
#define TE_CFG_AUNS  (1u << 2)
#define TE_CFG_BUNS  (1u << 3)

/* accelerator CTRL/STATUS common bits */
#define ACC_START   (1u << 0)
#define ACC_IRQ_EN  (1u << 1)
#define TE_CLEAR    (1u << 2)
#define ACC_BUSY    (1u << 0)
#define ACC_DONE    (1u << 1)
#define ACC_ERR     (1u << 2)
#define ACC_ECODE(s) (((s) >> 4) & 0xFu)
#define AERR_ALIGN 1u
#define AERR_RANGE 2u
#define AERR_BADOP 3u
#define AERR_BUSY  4u

/* ---- flash boot image ----------------------------------------------------*/
#define SFV_IMG_MAGIC 0x49564653u      /* "SFVI" little-endian */
typedef struct {
  uint32_t magic, load, length, entry, check;
} sfv_img_hdr_t;

#endif
