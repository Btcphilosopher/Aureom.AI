/* SilicaFlux-V accelerator drivers and software golden models. */
#include "sfv_accel.h"

uint32_t ve_run(uint32_t op, uint32_t flags, uint32_t src_a, uint32_t src_b,
                uint32_t dst, uint32_t len, uint32_t scalar) {
  VE_STATUS = ACC_DONE | ACC_ERR;          /* clear sticky flags */
  VE_CMD = op | flags;
  VE_SRC_A = src_a;
  VE_SRC_B = src_b;
  VE_DST = dst;
  VE_LEN = len;
  VE_SCALAR = scalar;
  VE_CTRL = ACC_START;
  uint32_t s;
  do {
    s = VE_STATUS;
  } while (!(s & (ACC_DONE | ACC_ERR)));
  return s;
}

static int32_t sext(uint32_t v, uint32_t w) {
  if (w >= 32) return (int32_t)v;
  uint32_t m = 1u << (w - 1);
  v &= (m << 1) - 1u;
  return (int32_t)((v ^ m) - m);
}

uint32_t ve_ref_elem(uint32_t op, uint32_t a, uint32_t b, uint32_t mul_w) {
  int32_t as = (int32_t)a, bs = (int32_t)b;
  switch (op) {
    case VOP_ADD: return a + b;
    case VOP_SUB: return a - b;
    case VOP_MUL:
    case VOP_DOT: return (uint32_t)(sext(a, mul_w) * sext(b, mul_w));
    case VOP_MIN: return as < bs ? a : b;
    case VOP_MAX: return as > bs ? a : b;
    case VOP_AND: return a & b;
    case VOP_OR:  return a | b;
    case VOP_XOR: return a ^ b;
    case VOP_SLL: return a << (b & 31u);
    case VOP_SRA: return (uint32_t)(as >> (b & 31u));
    case VOP_SRL: return a >> (b & 31u);
    default:      return 0;
  }
}

uint32_t te_run(uint32_t cfg, uint32_t a, uint32_t b, uint32_t c, uint32_t k,
                uint32_t as, uint32_t bs, uint32_t cs) {
  TE_STATUS = ACC_DONE | ACC_ERR;
  TE_CFG = cfg;
  TE_A_ADDR = a;
  TE_B_ADDR = b;
  TE_C_ADDR = c;
  TE_K = k;
  TE_A_STRIDE = as;
  TE_B_STRIDE = bs;
  TE_C_STRIDE = cs;
  TE_CTRL = ACC_START;
  uint32_t s;
  do {
    s = TE_STATUS;
  } while (!(s & (ACC_DONE | ACC_ERR)));
  return s;
}

static int32_t lane8(uint32_t w, int i, int uns) {
  uint32_t v = (w >> (8 * i)) & 0xFFu;
  return uns ? (int32_t)v : (int32_t)(int8_t)v;
}

void te_ref(const uint32_t *a_cols, const uint32_t *b_rows, uint32_t k,
            int a_uns, int b_uns, int32_t c[16]) {
  for (uint32_t kk = 0; kk < k; kk++)
    for (int i = 0; i < 4; i++)
      for (int j = 0; j < 4; j++)
        c[4 * i + j] += lane8(a_cols[kk], i, a_uns) * lane8(b_rows[kk], j, b_uns);
}
