/* SilicaFlux-V accelerator drivers and software golden models. */
#ifndef SFV_ACCEL_H
#define SFV_ACCEL_H
#include <stdint.h>
#include "sfv_map.h"

#define TSPM_PTR(off) ((volatile uint32_t *)(uintptr_t)(SFV_TSPM_BASE + (off)))

/* Vector engine: returns STATUS at completion (DONE or ERR). */
uint32_t ve_run(uint32_t op, uint32_t flags, uint32_t src_a, uint32_t src_b,
                uint32_t dst, uint32_t len, uint32_t scalar);
/* Golden model: element op on 32-bit lanes, MUL_W-bit signed products. */
uint32_t ve_ref_elem(uint32_t op, uint32_t a, uint32_t b, uint32_t mul_w);

/* Tensor engine: returns STATUS at completion. */
uint32_t te_run(uint32_t cfg, uint32_t a, uint32_t b, uint32_t c, uint32_t k,
                uint32_t as, uint32_t bs, uint32_t cs);
/* Golden model: C (+)= A*B; a_cols[k] = A[0..3][k] packed bytes,
 * b_rows[k] = B[k][0..3] packed bytes. */
void te_ref(const uint32_t *a_cols, const uint32_t *b_rows, uint32_t k,
            int a_uns, int b_uns, int32_t c[16]);

#endif
