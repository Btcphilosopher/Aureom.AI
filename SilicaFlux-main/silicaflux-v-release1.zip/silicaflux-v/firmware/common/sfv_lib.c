/* SilicaFlux-V bare-metal support library. */
#include "sfv_lib.h"

void uart_putc(char c) {
  while (!(UART_STATUS & UART_TX_READY)) {
  }
  UART_DATA = (uint8_t)c;
}

void uart_puts(const char *s) {
  while (*s) {
    if (*s == '\n') uart_putc('\r');
    uart_putc(*s++);
  }
}

void uart_puthex(uint32_t v) {
  for (int i = 28; i >= 0; i -= 4) {
    uint32_t d = (v >> i) & 0xF;
    uart_putc((char)(d < 10 ? '0' + d : 'a' + d - 10));
  }
}

void uart_putdec(uint32_t v) {
  char buf[11];
  int n = 0;
  do {
    buf[n++] = (char)('0' + v % 10u);
    v /= 10u;
  } while (v && n < 10);
  while (n) uart_putc(buf[--n]);
}

void uart_flush(void) {
  while (!(UART_STATUS & UART_TX_IDLE)) {
  }
}

void print_kv(const char *k, uint32_t v) {
  uart_puts(k);
  uart_puts("=0x");
  uart_puthex(v);
  uart_puts("\n");
}

void *memcpy(void *d, const void *s, size_t n) {
  uint8_t *dp = d;
  const uint8_t *sp = s;
  while (n--) *dp++ = *sp++;
  return d;
}

void *memset(void *d, int c, size_t n) {
  uint8_t *dp = d;
  while (n--) *dp++ = (uint8_t)c;
  return d;
}

int memcmp(const void *a, const void *b, size_t n) {
  const uint8_t *x = a, *y = b;
  for (; n; n--, x++, y++)
    if (*x != *y) return *x < *y ? -1 : 1;
  return 0;
}

uint32_t rand32(uint32_t *s) {
  uint32_t x = *s;
  x ^= x << 13;
  x ^= x >> 17;
  x ^= x << 5;
  return *s = x;
}

void test_status(uint32_t state, uint32_t code) { SYS_TEST_STATUS = (code << 8) | state; }

/* ---- RV32I has no M extension: compiler support routines ---------------*/
uint32_t __mulsi3(uint32_t a, uint32_t b) {
  uint32_t r = 0;
  while (b) {
    if (b & 1u) r += a;
    a <<= 1;
    b >>= 1;
  }
  return r;
}

uint32_t __udivsi3(uint32_t n, uint32_t d) {
  uint32_t q = 0, r = 0;
  if (!d) return 0xFFFFFFFFu;
  for (int i = 31; i >= 0; i--) {
    r = (r << 1) | ((n >> i) & 1u);
    if (r >= d) {
      r -= d;
      q |= 1u << i;
    }
  }
  return q;
}

uint32_t __umodsi3(uint32_t n, uint32_t d) {
  if (!d) return n;
  return n - __mulsi3(__udivsi3(n, d), d);
}
