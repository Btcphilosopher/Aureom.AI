/* SilicaFlux-V bare-metal support library (freestanding, no libc). */
#ifndef SFV_LIB_H
#define SFV_LIB_H
#include <stddef.h>
#include <stdint.h>
#include "sfv_map.h"

#define csr_read(csr) ({ uint32_t __v; __asm__ volatile("csrr %0, " #csr : "=r"(__v)); __v; })
#define csr_write(csr, v) __asm__ volatile("csrw " #csr ", %0" ::"r"((uint32_t)(v)))
#define csr_set(csr, v) __asm__ volatile("csrs " #csr ", %0" ::"r"((uint32_t)(v)))
#define csr_clear(csr, v) __asm__ volatile("csrc " #csr ", %0" ::"r"((uint32_t)(v)))
#define MSTATUS_MIE (1u << 3)
#define MIE_MSIE (1u << 3)
#define MIE_MTIE (1u << 7)
#define MIE_MEIE (1u << 11)

void uart_putc(char c);
void uart_puts(const char *s);
void uart_puthex(uint32_t v);          /* 8 hex digits */
void uart_putdec(uint32_t v);
void uart_flush(void);
void print_kv(const char *k, uint32_t v); /* "k=0x........\n" */

void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
int memcmp(const void *a, const void *b, size_t n);

uint32_t rand32(uint32_t *state);       /* xorshift32 */
void test_status(uint32_t state, uint32_t code);

#endif
