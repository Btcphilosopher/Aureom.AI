/* =============================================================================
 * SilicaFlux-V bring-up / acceptance application.
 *
 * Demonstrates and checks, against software golden models:
 *   T1 reset state and identity        T5 tensor engine (4x4 INT8 MAC)
 *   T2 UART output + loopback          T6 traps and interrupts
 *   T3 SRAM read/write (all widths)    T7 GPIO edge interrupt
 *   T4 vector engine (all ops/modes)   T8 soft reset round trip
 * Result: UART summary, TEST_STATUS (PASS/FAIL + fail count), GPIO LEDs
 * (gpio[7] pass, gpio[6] fail).
 * ===========================================================================*/
#include "../common/sfv_accel.h"
#include "../common/sfv_lib.h"

static uint32_t fails, checks, seed = 0x5EED1234u;

static void check(int ok, uint32_t id, uint32_t got, uint32_t exp) {
  checks++;
  if (!ok) {
    fails++;
    if (fails <= 16) {
      uart_puts("  FAIL id=");
      uart_puthex(id);
      uart_puts(" got=");
      uart_puthex(got);
      uart_puts(" exp=");
      uart_puthex(exp);
      uart_puts("\n");
    }
  }
}
#define CHECK_EQ(id, got, exp)        \
  do {                                \
    uint32_t _g = (got), _e = (exp);  \
    check(_g == _e, (id), _g, _e);    \
  } while (0)

static void section(const char *name) {
  uart_puts("[");
  uart_puts(name);
  uart_puts("] checks so far=");
  uart_putdec(checks);
  uart_puts(" fails=");
  uart_putdec(fails);
  uart_puts("\n");
}

/* ---------------------------------------------------------------- traps */
volatile uint32_t trap_count, last_cause, last_tval, resume_pc;
volatile uint32_t n_timer, n_soft, n_ext, ext_claim, n_gpio;

__attribute__((interrupt("machine"))) void trap_entry(void) {
  uint32_t cause = csr_read(mcause);
  if (cause & 0x80000000u) {
    switch (cause & 0x1Fu) {
      case 7:
        TIMER_CMP_HI = 0xFFFFFFFFu;
        TIMER_CMP_LO = 0xFFFFFFFFu;
        n_timer++;
        break;
      case 3:
        TIMER_MSIP = 0;
        n_soft++;
        break;
      case 11: {
        uint32_t c = INTC_CLAIM;
        ext_claim = c;
        if (c == IRQ_VE + 1) VE_STATUS = ACC_DONE | ACC_ERR;
        else if (c == IRQ_TE + 1) TE_STATUS = ACC_DONE | ACC_ERR;
        else if (c == IRQ_GPIO + 1) { GPIO_PEND = 0xFFu; n_gpio++; }
        else INTC_ENABLE = 0;                       /* unexpected: mask all */
        n_ext++;
        break;
      }
      default:
        break;
    }
    return;
  }
  trap_count++;
  last_cause = cause;
  last_tval = csr_read(mtval);
  if (cause == 1u && resume_pc) {
    csr_write(mepc, resume_pc);                    /* fetch fault: resume */
    resume_pc = 0;
  } else {
    csr_write(mepc, csr_read(mepc) + 4u);
  }
}

/* ---------------------------------------------------------------- T1 */
static void t1_reset(void) {
  section("T1 reset/identity");
  CHECK_EQ(0x101, SYS_CHIP_ID, SFV_CHIP_ID_VAL);
  CHECK_EQ(0x102, csr_read(misa), 0x40000100u);          /* RV32I */
  CHECK_EQ(0x103, csr_read(mhartid), 0);
  CHECK_EQ(0x104, csr_read(mimpid), 0x00010000u);
  CHECK_EQ(0x105, csr_read(mstatus) & MSTATUS_MIE, 0);
  CHECK_EQ(0x106, VE_STATUS & ACC_BUSY, 0);
  CHECK_EQ(0x107, TE_STATUS & ACC_BUSY, 0);
  CHECK_EQ(0x108, INTC_ENABLE, 0);
  CHECK_EQ(0x109, VE_INFO, 0x00102004u);                  /* 16 KiB, MUL_W 32, 4 lanes */
  CHECK_EQ(0x10A, TE_INFO, 0x00100804u);
  uint32_t c0 = csr_read(mcycle), i0 = csr_read(minstret);
  __asm__ volatile("nop; nop; nop; nop");
  check(csr_read(mcycle) > c0, 0x10B, csr_read(mcycle), c0);
  check(csr_read(minstret) > i0 + 4, 0x10C, csr_read(minstret), i0);
}

/* ---------------------------------------------------------------- T2 */
static void t2_uart(void) {
  section("T2 uart");
  uart_flush();
  UART_CTRL = UART_LOOPBACK;
  const char msg[4] = {'L', 'O', 'O', 'P'};
  for (int i = 0; i < 4; i++) uart_putc(msg[i]);
  uart_flush();
  for (int i = 0; i < 4; i++) {
    uint32_t d = 0x80000000u;
    for (int t = 0; t < 2000 && (d & 0x80000000u); t++) d = UART_DATA;
    CHECK_EQ(0x200 + i, d, (uint32_t)msg[i]);
  }
  UART_CTRL = 0;
  CHECK_EQ(0x210, UART_STATUS & 0x38u, 0);                /* no overrun/frame */
  uart_puts("\n");
}

/* ---------------------------------------------------------------- T3 */
static void t3_sram(void) {
  section("T3 sram");
  /* bank 1, bank 2 full; bank 3 lower half (stack lives at the top) */
  static const uint32_t base[3] = {SFV_SRAM_BASE + 1 * SFV_SRAM_BANK,
                                   SFV_SRAM_BASE + 2 * SFV_SRAM_BANK,
                                   SFV_SRAM_BASE + 3 * SFV_SRAM_BANK};
  static const uint32_t words[3] = {SFV_SRAM_BANK / 4, SFV_SRAM_BANK / 4, SFV_SRAM_BANK / 8};
  for (int pass = 0; pass < 2; pass++) {
    uint32_t bad = 0, first = 0;
    for (int r = 0; r < 3; r++) {
      volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)base[r];
      for (uint32_t i = 0; i < words[r]; i++) {
        uint32_t v = (base[r] + 4 * i) ^ 0x5A5A5A5Au;
        p[i] = pass ? ~v : v;
      }
      for (uint32_t i = 0; i < words[r]; i++) {
        uint32_t v = (base[r] + 4 * i) ^ 0x5A5A5A5Au;
        if (p[i] != (pass ? ~v : v)) {
          if (!bad) first = base[r] + 4 * i;
          bad++;
        }
      }
    }
    check(bad == 0, 0x300 + pass, bad, first);
  }
  /* sub-word lanes and sign/zero extension */
  volatile uint32_t *w = (volatile uint32_t *)(uintptr_t)(SFV_SRAM_BASE + SFV_SRAM_BANK);
  volatile uint8_t *b = (volatile uint8_t *)w;
  volatile uint16_t *h = (volatile uint16_t *)w;
  volatile int8_t *sb = (volatile int8_t *)w;
  volatile int16_t *sh = (volatile int16_t *)w;
  w[0] = 0;
  b[0] = 0x11; b[1] = 0x82; b[2] = 0x33; b[3] = 0xC4;
  CHECK_EQ(0x310, w[0], 0xC4338211u);
  CHECK_EQ(0x311, (uint32_t)sb[1], 0xFFFFFF82u);
  CHECK_EQ(0x312, (uint32_t)b[1], 0x82u);
  h[1] = 0x8001;
  CHECK_EQ(0x313, w[0], 0x80018211u);
  CHECK_EQ(0x314, (uint32_t)sh[1], 0xFFFF8001u);
  CHECK_EQ(0x315, (uint32_t)h[1], 0x8001u);
}

/* ---------------------------------------------------------------- T4 */
#define VA 0x0000u
#define VB 0x0400u
#define VD 0x0800u
static uint32_t ve_expected_cycles(uint32_t op, uint32_t len, int bsc, int wres) {
  uint32_t beats = (len + 3u) / 4u;
  int dot = (op == VOP_DOT);
  uint32_t p = (bsc ? 0u : 1u) + 1u + (dot ? 0u : 1u);
  if (!len) return 2;
  return 3u + beats * p + ((dot && wres) ? 1u : 0u);
}

static void t4_vector(void) {
  section("T4 vector engine");
  volatile uint32_t *a = TSPM_PTR(VA), *bb = TSPM_PTR(VB), *d = TSPM_PTR(VD);
  static const uint32_t lens[4] = {1, 5, 16, 33};
  for (uint32_t op = 0; op < VOP_COUNT; op++) {
    for (int bsc = 0; bsc < 2; bsc++) {
      for (int li = 0; li < 4; li++) {
        uint32_t len = lens[li];
        uint32_t scal = rand32(&seed);
        /* sentinel-fill the destination past the last (partial) beat so that
           tail-lane masking is checked */
        for (uint32_t i = 0; i < ((len + 3u) & ~3u) + 4u; i++) {
          a[i] = rand32(&seed);
          bb[i] = rand32(&seed);
          d[i] = 0xDEADBEEFu;
        }
        uint32_t id = 0x4000u | (op << 8) | ((uint32_t)bsc << 4) | (uint32_t)li;
        uint32_t st = ve_run(op, bsc ? VE_CMD_BSCALAR : 0, VA, VB, VD, len, scal);
        check(!(st & ACC_ERR), id, st, 0);
        CHECK_EQ(id | 0x80, VE_CYCLES, ve_expected_cycles(op, len, bsc, 0));
        if (op == VOP_DOT) {
          uint32_t r = 0;
          for (uint32_t i = 0; i < len; i++) r += ve_ref_elem(op, a[i], bsc ? scal : bb[i], 32);
          CHECK_EQ(id, VE_RESULT, r);
        } else {
          uint32_t bad = 0;
          for (uint32_t i = 0; i < len; i++)
            bad += d[i] != ve_ref_elem(op, a[i], bsc ? scal : bb[i], 32);
          for (uint32_t i = len; i < ((len + 3u) & ~3u) + 4u; i++) bad += d[i] != 0xDEADBEEFu;
          CHECK_EQ(id, bad, 0);
        }
      }
    }
  }
  /* DOT accumulate + result write-back */
  for (uint32_t i = 0; i < 8; i++) { a[i] = i + 1; bb[i] = 2 * i + 1; }
  VE_RESULT = 1000;
  uint32_t st = ve_run(VOP_DOT, VE_CMD_ACC | VE_CMD_WRES, VA, VB, VD + 4, 8, 0);
  check(!(st & ACC_ERR), 0x4C00, st, 0);
  uint32_t r = 1000;
  for (uint32_t i = 0; i < 8; i++) r += (i + 1) * (2 * i + 1);
  CHECK_EQ(0x4C01, VE_RESULT, r);
  CHECK_EQ(0x4C02, d[1], r);
  CHECK_EQ(0x4C03, VE_CYCLES, ve_expected_cycles(VOP_DOT, 8, 0, 1));
  /* error detection */
  st = ve_run(VOP_ADD, 0, VA + 4, VB, VD, 4, 0);
  CHECK_EQ(0x4D00, st & 0xF7u, ACC_ERR | (AERR_ALIGN << 4));
  st = ve_run(VOP_ADD, 0, 0x3FF0u, VB, VD, 16, 0);
  CHECK_EQ(0x4D01, st & 0xF7u, ACC_ERR | (AERR_RANGE << 4));
  st = ve_run(12, 0, VA, VB, VD, 4, 0);
  CHECK_EQ(0x4D02, st & 0xF7u, ACC_ERR | (AERR_BADOP << 4));
  /* START while busy: rejected, running command unaffected */
  for (uint32_t i = 0; i < 256; i++) { a[i] = i; bb[i] = 3; }
  VE_STATUS = ACC_DONE | ACC_ERR;
  VE_CMD = VOP_MUL; VE_SRC_A = VA; VE_SRC_B = VB; VE_DST = VD; VE_LEN = 256;
  VE_CTRL = ACC_START;
  VE_CTRL = ACC_START;
  while (VE_STATUS & ACC_BUSY) {
  }
  st = VE_STATUS;
  CHECK_EQ(0x4D03, st & 0xF7u, ACC_DONE | ACC_ERR | (AERR_BUSY << 4));
  uint32_t bad = 0;
  for (uint32_t i = 0; i < 256; i++) bad += d[i] != 3 * i;
  CHECK_EQ(0x4D04, bad, 0);
}

/* ---------------------------------------------------------------- T5 */
#define TA 0x1000u
#define TB 0x1400u
#define TC 0x1800u
static void t5_tensor(void) {
  section("T5 tensor engine");
  volatile uint32_t *ta = TSPM_PTR(TA), *tb = TSPM_PTR(TB), *tc = TSPM_PTR(TC);
  static const uint32_t ks[4] = {1, 4, 7, 16};
  uint32_t acols[32], brows[32];
  for (int ki = 0; ki < 4; ki++) {
    for (int mode = 0; mode < 4; mode++) {
      uint32_t k = ks[ki];
      int au = mode & 1, bu = (mode >> 1) & 1;
      uint32_t astr = (ki == 2) ? 8u : 4u;          /* strided operand case */
      uint32_t cstr = (ki == 3) ? 32u : 16u;
      for (uint32_t i = 0; i < k; i++) {
        acols[i] = rand32(&seed);
        brows[i] = rand32(&seed);
        ta[i * astr / 4] = acols[i];
        tb[i] = brows[i];
      }
      for (int i = 0; i < 32; i++) tc[i] = 0xDEADBEEFu;
      uint32_t cfg = TE_CFG_WB | (au ? TE_CFG_AUNS : 0) | (bu ? TE_CFG_BUNS : 0);
      uint32_t st = te_run(cfg, TA, TB, TC, k, astr, 4, cstr);
      uint32_t id = 0x5000u | ((uint32_t)ki << 4) | (uint32_t)mode;
      check(!(st & ACC_ERR), id, st, 0);
      int32_t c[16] = {0};
      te_ref(acols, brows, k, au, bu, c);
      uint32_t bad = 0;
      for (int i = 0; i < 16; i++) {
        bad += TE_ACC(i) != (uint32_t)c[i];
        bad += tc[(i / 4) * (cstr / 4) + (i % 4)] != (uint32_t)c[i];
      }
      CHECK_EQ(id, bad, 0);
      CHECK_EQ(id | 0x100, TE_CYCLES, 3u + 2u * k + 4u);
      /* accumulate a second product onto the first (no write-back) */
      for (uint32_t i = 0; i < k; i++) {
        acols[i] = rand32(&seed);
        ta[i * astr / 4] = acols[i];
      }
      st = te_run(TE_CFG_ACC | (au ? TE_CFG_AUNS : 0) | (bu ? TE_CFG_BUNS : 0), TA, TB, TC, k, astr, 4, cstr);
      te_ref(acols, brows, k, au, bu, c);
      bad = 0;
      for (int i = 0; i < 16; i++) bad += TE_ACC(i) != (uint32_t)c[i];
      CHECK_EQ(id | 0x200, bad, 0);
      CHECK_EQ(id | 0x300, TE_CYCLES, 3u + 2u * k);
    }
  }
  /* CLEAR, error detection */
  TE_CTRL = TE_CLEAR;
  uint32_t nz = 0;
  for (int i = 0; i < 16; i++) nz += TE_ACC(i) != 0;
  CHECK_EQ(0x5F00, nz, 0);
  CHECK_EQ(0x5F01, te_run(0, TA, TB, TC, 0, 0, 0, 0) & 0xF7u, ACC_ERR | (AERR_RANGE << 4));
  CHECK_EQ(0x5F02, te_run(0, TA + 2, TB, TC, 4, 0, 0, 0) & 0xF7u, ACC_ERR | (AERR_ALIGN << 4));
  CHECK_EQ(0x5F03, te_run(TE_CFG_WB, TA, TB, TC + 4, 4, 0, 0, 0) & 0xF7u, ACC_ERR | (AERR_ALIGN << 4));
  CHECK_EQ(0x5F04, te_run(0, 0x3FFCu, TB, TC, 4, 0, 0, 0) & 0xF7u, ACC_ERR | (AERR_RANGE << 4));
  /* VE and TE started back to back: TSPM lock serialises, both correct */
  volatile uint32_t *a = TSPM_PTR(VA), *bb = TSPM_PTR(VB), *d = TSPM_PTR(VD);
  for (uint32_t i = 0; i < 64; i++) { a[i] = i; bb[i] = i ^ 0x55u; }
  for (uint32_t i = 0; i < 4; i++) { ta[i] = 0x01010101u; tb[i] = 0x04030201u; }
  VE_STATUS = ACC_DONE | ACC_ERR; TE_STATUS = ACC_DONE | ACC_ERR;
  VE_CMD = VOP_XOR; VE_SRC_A = VA; VE_SRC_B = VB; VE_DST = VD; VE_LEN = 64;
  TE_CFG = 0; TE_A_ADDR = TA; TE_B_ADDR = TB; TE_K = 4; TE_A_STRIDE = 0; TE_B_STRIDE = 0;
  VE_CTRL = ACC_START;
  TE_CTRL = ACC_START;
  while ((VE_STATUS & ACC_BUSY) || (TE_STATUS & ACC_BUSY)) {
  }
  uint32_t bad = 0;
  for (uint32_t i = 0; i < 64; i++) bad += d[i] != (i ^ (i ^ 0x55u));
  for (int i = 0; i < 16; i++) bad += TE_ACC(i) != 4u * (uint32_t)((i % 4) + 1);
  CHECK_EQ(0x5F10, bad, 0);
  CHECK_EQ(0x5F11, (VE_STATUS | TE_STATUS) & ACC_ERR, 0);
}

/* ---------------------------------------------------------------- T6 */
static void t6_traps(void) {
  section("T6 traps & interrupts");
  uint32_t n0 = trap_count;
  __asm__ volatile("ecall");
  CHECK_EQ(0x600, last_cause, 11);
  __asm__ volatile(".word 0x00000000");
  CHECK_EQ(0x601, last_cause, 2);
  CHECK_EQ(0x602, last_tval, 0);
  SYS_BUSERR_INFO = 1;                                      /* clear capture */
  volatile uint32_t x = REG32(0x30000000u);
  (void)x;
  CHECK_EQ(0x603, last_cause, 5);
  CHECK_EQ(0x604, last_tval, 0x30000000u);
  CHECK_EQ(0x605, SYS_BUSERR_INFO & 7u, 1u | (1u << 1));    /* valid, master CPU-D */
  CHECK_EQ(0x606, SYS_BUSERR_ADDR, 0x30000000u);
  SYS_BUSERR_INFO = 1;
  REG32(0x00000100u) = 0x1234;                              /* store to ROM */
  CHECK_EQ(0x607, last_cause, 7);
  volatile uint32_t y = *(volatile uint32_t *)(uintptr_t)(SFV_SRAM_BASE + 0x10002u);
  (void)y;
  CHECK_EQ(0x608, last_cause, 4);
  __asm__ volatile("ebreak");
  CHECK_EQ(0x609, last_cause, 3);
  /* execute-never: fetch from the peripheral window -> instruction access fault */
  __asm__ volatile(
      "la t0, 1f\n"
      "la t1, resume_pc\n"
      "sw t0, 0(t1)\n"
      "li t2, 0x40000000\n"
      "jr t2\n"
      "1:\n" ::: "t0", "t1", "t2", "memory");
  CHECK_EQ(0x60A, last_cause, 1);
  CHECK_EQ(0x60B, last_tval, 0x40000000u);
  CHECK_EQ(0x60C, trap_count - n0, 7);   /* ecall illegal lfault sfault misal ebreak ifault */
  SYS_BUSERR_INFO = 1;

  /* machine timer interrupt */
  csr_write(mie, MIE_MTIE);
  csr_set(mstatus, MSTATUS_MIE);
  uint32_t t = TIMER_MTIME_LO;
  TIMER_CMP_HI = 0;
  TIMER_CMP_LO = t + 200;
  for (int i = 0; i < 100000 && !n_timer; i++) __asm__ volatile("wfi");
  CHECK_EQ(0x610, n_timer, 1);
  check((uint32_t)(TIMER_MTIME_LO - t) >= 200u, 0x611, TIMER_MTIME_LO - t, 200);
  /* machine software interrupt */
  csr_write(mie, MIE_MSIE);
  TIMER_MSIP = 1;
  for (int i = 0; i < 100 && !n_soft; i++) __asm__ volatile("nop");
  CHECK_EQ(0x612, n_soft, 1);
  /* external interrupt: vector-engine completion through the INTC */
  csr_write(mie, MIE_MEIE);
  INTC_ENABLE = 1u << IRQ_VE;
  VE_STATUS = ACC_DONE | ACC_ERR;
  VE_CMD = VOP_ADD; VE_SRC_A = VA; VE_SRC_B = VB; VE_DST = VD; VE_LEN = 128;
  VE_CTRL = ACC_START | ACC_IRQ_EN;
  for (int i = 0; i < 100000 && !n_ext; i++) __asm__ volatile("wfi");
  CHECK_EQ(0x613, n_ext, 1);
  CHECK_EQ(0x614, ext_claim, IRQ_VE + 1);
  VE_CTRL = 0;
  /* tensor completion interrupt */
  INTC_ENABLE = 1u << IRQ_TE;
  TE_STATUS = ACC_DONE | ACC_ERR;
  TE_CFG = 0; TE_A_ADDR = TA; TE_B_ADDR = TB; TE_K = 8;
  TE_CTRL = ACC_START | ACC_IRQ_EN;
  for (int i = 0; i < 100000 && n_ext < 2; i++) __asm__ volatile("wfi");
  CHECK_EQ(0x615, n_ext, 2);
  CHECK_EQ(0x616, ext_claim, IRQ_TE + 1);
  TE_CTRL = 0;
  csr_clear(mstatus, MSTATUS_MIE);
  INTC_ENABLE = 0;
  csr_write(mie, 0);
  CHECK_EQ(0x617, csr_read(mip) & 0x888u, 0);
}

/* ---------------------------------------------------------------- T7 */
static void t7_gpio(void) {
  section("T7 gpio");
  /* gpio[5:4] are looped back on the test board / testbench (pad level) */
  GPIO_OE = 0xD0u;                    /* 7,6 LEDs, 4 output; 5 input */
  GPIO_OUT = 0;
  GPIO_RISE = 1u << 5;
  GPIO_PEND = 0xFFu;
  INTC_ENABLE = 1u << IRQ_GPIO;
  csr_write(mie, MIE_MEIE);
  csr_set(mstatus, MSTATUS_MIE);
  GPIO_OUT = 1u << 4;                 /* drive pin 4 high -> pin 5 rises */
  for (int i = 0; i < 1000 && !n_gpio; i++) __asm__ volatile("nop");
  csr_clear(mstatus, MSTATUS_MIE);
  CHECK_EQ(0x700, n_gpio, 1);
  CHECK_EQ(0x701, (GPIO_IN >> 4) & 3u, 3u);
  GPIO_OUT = 0;
  INTC_ENABLE = 0;
  GPIO_RISE = 0;
}

/* ---------------------------------------------------------------- main */
int main(void) {
  uint32_t cause = SYS_RESET_CAUSE;
  GPIO_OE = 0xC0u;
  if (cause & 2u) {
    /* second life after T8 soft reset: bss cleared by start-up */
    uart_puts("\nSFV-APP: restarted by soft reset\n");
    CHECK_EQ(0x800, cause & 3u, 2u);
    /* the pre-reset sentinel must have been destroyed by the system reset
       (a JTAG host may legitimately have re-posted SCRATCH0 = entry) */
    check(SYS_SCRATCH0 != 0x12345678u, 0x801, SYS_SCRATCH0, 0x12345678u);
    CHECK_EQ(0x802, VE_STATUS & ACC_DONE, 0);
  } else {
    uart_puts("\nSFV-APP: SilicaFlux-V acceptance test\n");
    t1_reset();
    t2_uart();
    t3_sram();
    t4_vector();
    t5_tensor();
    t6_traps();
    t7_gpio();
    section("T8 soft reset");
    if (fails) goto done;                                   /* keep evidence */
    SYS_SCRATCH0 = 0x12345678u;
    uart_puts("SFV-APP PHASE1 PASS checks=");
    uart_putdec(checks);
    uart_puts(" fails=0\nSFV-APP: issuing soft reset\n");
    uart_flush();
    SYS_SOFT_RESET = SFV_SOFT_RESET_KEY;
    for (;;) {
    }
  }
done:
  uart_puts("SFV-APP RESULT ");
  uart_puts(fails ? "FAIL" : "PASS");
  uart_puts(" checks=");
  uart_putdec(checks);
  uart_puts(" fails=");
  uart_putdec(fails);
  uart_puts("\n");
  uart_flush();
  GPIO_OUT = fails ? 0x40u : 0x80u;
  test_status(fails ? TEST_FAIL : TEST_PASS, fails);
  return 0;
}
