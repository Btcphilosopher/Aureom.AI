# CI
`ci/github-actions.yml` is the workflow (copy to `.github/workflows/`).  It
runs `scripts/regress.sh` (firmware, lint, riscv-tests, SoC firmware
scenarios, no-clock-gate equivalence, Icarus cross-check, cocotb units,
formal) on every push and builds the ULX3S bitstream nightly.  The same
script is the local entry point: `make regress`.
