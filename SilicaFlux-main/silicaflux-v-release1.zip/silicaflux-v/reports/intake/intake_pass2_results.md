# Intake pass 2 — corrected re-runs of the repository's own testbenches

Environment: Verilator 5.020, Icarus 12.0, Yosys 0.33 (docs/TOOL_VERSIONS.md).
Archives extracted from `SilicaFlux-main/` into an isolated directory.

| Project | Command (in extracted dir) | Result |
|---|---|---|
| SilicaFlux v1.0 (`silicaflux.zip`) | `sim/run_sim.sh all` (vvp `-n`, timeout raised) | 7/7 testbenches report PASS (vec 7, tensor 15, mem 6, sched 9, noc 6, tile 15, top 3 checks); script prints `0: syntax error in expression` (counting bug) |
| `RISC-V CPU.zip` | `iverilog -g2012 … rv32i_tb.sv; vvp` in its own dir | "ALL CHECKS PASSED — PIPELINE CORRECT" (fails from another dir: relative `program.hex`) |
| `cpu_core.zip` | Makefile sources, Icarus | `FINAL: TB=27/0 SB=91/0`, "ALL TESTS PASSED" (165 `$error` lines from an `x0 != 0` RTL assertion during reset — X before reset) |
| `soc_integration.tar.gz` | `tb_soc_top` | 20 PASS / 0 FAIL, 51 BFM transactions |
| `silicaflux-testcore` | `scripts/run_sv.sh <tb>` | tb_tap_fsm, tb_tap_bsr, tb_mbist, tb_rst_clk, tb_debug, tb_dft_iso, tb_mode_sec: 7/7 PASS; Verilator lint of `tc_top`: 0 errors, 3 warnings |
| `silicaflux-memoryflow` v2.0.0 | `iverilog -c sim/rtl_files.f -I tb/common …` | tb_accel PASS (2572 checks), tb_mbist PASS (6), tb_spm PASS (46658); tb_sram_prims/tb_sram_bank need the macro stub file in the list |
| `pipelined_cpu.zip` | Icarus/Verilator | elaboration error: `IMEM_INIT_FILE` unbound in `cpu_top` |
| `comm_protocols.zip` | Icarus/Verilator/Yosys | UART: duplicate enum literal `DATA_BITS`; SPI: `inside` unsupported (Icarus) |
| `memory_cache_repo.zip` | Icarus/Yosys | `sp_ram.sv:126` syntax errors |
| SilicaFlux 2.x `.sf` | Verilator per module with candidate packages | see docs/REPO_INTAKE.md §2; agrees with TimingLab `docs/DISCOVERY.md` |
