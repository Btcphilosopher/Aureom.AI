# SilicaFlux-V regression summary

Generated 2026-11-05 16:43:27 UTC by scripts/regress.sh

| Suite | Result | Detail |
|---|---|---|
| firmware | PASS | build/fw/bootrom.elf text=2792 build/fw/app.elf text=8624  |
| lint | PASS | verilator errors=0, yosys latches inferred: 2 (unintended: 0) |
| riscv-tests | PASS | TOTAL pass=55 fail=0 |
| soc-firmware | PASS | 6/6 scenarios, app checks=432 |
| soc-no-clock-gate | PASS | TB_SOC RESULT PASS status=00000001 cycles=3101307 chars=807 |
| soc-sky130-macro-tiling | PASS | TB_SOC RESULT PASS status=00000001 cycles=3101307 chars=807 |
| soc-ihp-vendor-sram-models | PASS | TB_SOC RESULT PASS status=00000001 cycles=3101307 chars=807 |
| icarus-soc-smoke | PASS | TB_SOC RESULT PASS stop_on="[T3 sram] checks so far=17 fails=0" cycles=42166 chars=254 |
| cocotb-tile | PASS | TESTS=3 PASS=3 FAIL=0 |
| cocotb-xbar | PASS | TESTS=1 PASS=1 FAIL=0 |
| cocotb-periph | PASS | TESTS=3 PASS=3 FAIL=0 |
| cocotb-mbist | PASS | TESTS=1 PASS=1 FAIL=0 |
| formal | PASS | fv_xbar prove: PASS;fv_xbar bmc: PASS;fv_fifo: PASS;fv_tap: PASS;fv_cpu_bus bmc: PASS; |

**OVERALL: PASS**
