## ASIC baseline: sky130hd, reduced SRAM 32 KiB (synthesis/placement only) @ 20 ns (50 MHz), typical corner

Synthesis: Yosys. Physical estimate: OpenROAD floorplan + macro placement + global
placement + repair_design/repair_timing, placement-estimated wire RC, ideal clocks
(no CTS, no routing): post-placement ESTIMATES, not signoff.

| metric | value | source |
|---|---|---|
| synthesized cells (total / std / flops / ICG) | 46730 / 46718 / 3850 / 2 | Yosys stat |
| standard-cell area (synthesis) | 0.3861 mm² | Yosys stat -liberty |
| SRAM macro area | 8.665 mm² | liberty area × count |
| macro sky130_sram_1rw1r_128x256_8 | 12 × 0.7221 mm² | Yosys stat + liberty |
| placed design area (after repair) / core util. | 9.193 mm² / 80.0% | OpenROAD report_design_area |
| die (floorplan used) | 3.476 × 3.476 mm = 12.08 mm² | OpenROAD floorplan (core sized by script) |
| reg-to-reg worst slack | -5.179 ns (u_tile.g_bank[2].u_ram.u_macro.g_m[0].u_mac → _86200_) | OpenROAD/OpenSTA |
| reset recovery worst slack | 15.909 ns | OpenROAD/OpenSTA |
| WNS / TNS (all groups) | -5.18 / -592.26 ns | OpenROAD/OpenSTA |
| worst hold slack (ideal clocks) | 0.05 ns | OpenROAD/OpenSTA |
| estimated Fmax (reg-to-reg) | 39.7 MHz | DERIVED 1/(T − slack), ideal clocks, typical corner |
| power int / switch / leak / total | 112.00 / 0.34 / 0.958 / 114.00 mW | OpenSTA, 10% input toggle, @50 MHz |
