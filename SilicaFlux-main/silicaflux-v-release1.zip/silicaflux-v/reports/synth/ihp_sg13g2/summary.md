## ASIC baseline: ihp_sg13g2 @ 20 ns (50 MHz), typical corner

Synthesis: Yosys. Physical estimate: OpenROAD floorplan + macro placement + global
placement + repair_design/repair_timing, placement-estimated wire RC, ideal clocks
(no CTS, no routing): post-placement ESTIMATES, not signoff.

| metric | value | source |
|---|---|---|
| synthesized cells (total / std / flops / ICG) | 50482 / 50470 / 3832 / 2 | Yosys stat |
| standard-cell area (synthesis) | 0.6838 mm² | Yosys stat -liberty |
| SRAM macro area | 4.533 mm² | liberty area × count |
| macro RM_IHPSG13_1P_2048x64_c2_bm_bist | 8 × 0.4916 mm² | Yosys stat + liberty |
| macro RM_IHPSG13_1P_512x64_c2_bm_bist | 4 × 0.1501 mm² | Yosys stat + liberty |
| placed design area (after repair) / core util. | 5.394 mm² / 78.0% | OpenROAD report_design_area |
| die (floorplan used) | 2.709 × 2.709 mm = 7.34 mm² | OpenROAD floorplan (core sized by script) |
| reg-to-reg worst slack | 6.579 ns (u_tile.g_bank[3].u_ram.u_macro.g_m[0].genblk1.genblk1.g512.u_mac → _96097_) | OpenROAD/OpenSTA |
| reset recovery worst slack | 16.562 ns | OpenROAD/OpenSTA |
| WNS / TNS (all groups) | 6.58 / 0.0 ns | OpenROAD/OpenSTA |
| worst hold slack (ideal clocks) | -0.14 ns | OpenROAD/OpenSTA |
| estimated Fmax (reg-to-reg) | 74.5 MHz | DERIVED 1/(T − slack), ideal clocks, typical corner |
| power int / switch / leak / total | 8.29 / 2.76 / 0.026 / 11.10 mW | OpenSTA, 10% input toggle, @50 MHz |
