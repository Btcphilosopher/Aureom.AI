## ASIC baseline: sky130hd @ 20 ns (50 MHz), typical corner

Synthesis: Yosys. Physical estimate: OpenROAD floorplan + macro placement + global
placement + repair_design/repair_timing, placement-estimated wire RC, ideal clocks
(no CTS, no routing): post-placement ESTIMATES, not signoff.

| metric | value | source |
|---|---|---|
| synthesized cells (total / std / flops / ICG) | 48077 / 48041 / 3843 / 2 | Yosys stat |
| standard-cell area (synthesis) | 0.3978 mm² | Yosys stat -liberty |
| SRAM macro area | 25.996 mm² | liberty area × count |
| macro sky130_sram_1rw1r_128x256_8 | 36 × 0.7221 mm² | Yosys stat + liberty |
| placed design area (after repair) / core util. | 26.991 mm² / 81.0% | OpenROAD report_design_area |
| die (floorplan used) | 5.844 × 5.844 mm = 34.15 mm² | OpenROAD floorplan (core sized by script) |
| reg-to-reg worst slack | -6.76 ns (u_tile.g_bank[0].u_ram.u_macro.g_m[0].u_mac → _91864_) | OpenROAD/OpenSTA |
| reset recovery worst slack | 15.62 ns | OpenROAD/OpenSTA |
| WNS / TNS (all groups) | -6.76 / -1313.58 ns | OpenROAD/OpenSTA |
| worst hold slack (ideal clocks) | 0.13 ns | OpenROAD/OpenSTA |
| estimated Fmax (reg-to-reg) | 37.4 MHz | DERIVED 1/(T − slack), ideal clocks, typical corner |
| power int / switch / leak / total | 327.00 / 0.55 / 2.870 / 331.00 mW | OpenSTA, 10% input toggle, @50 MHz |
