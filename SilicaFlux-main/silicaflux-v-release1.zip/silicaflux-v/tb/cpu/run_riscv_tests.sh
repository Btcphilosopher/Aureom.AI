#!/usr/bin/env bash
# Build the official riscv-tests (rv32ui, rv32mi) with clang/lld and run each
# on the stand-alone CPU testbench under several bus-backpressure profiles.
#
# usage: tb/cpu/run_riscv_tests.sh [RISCV_TESTS_DIR]
# env  : PROFILES="gnt:lat ..." (default "100:1 70:2 40:4"), SEEDS="1 2"
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
RT="${1:-${RISCV_TESTS:-$ROOT/../deps/riscv-tests}}"
OUT="$ROOT/build/riscv-tests"; mkdir -p "$OUT"
REPORT="$ROOT/reports/sim/riscv_tests.txt"; mkdir -p "$(dirname "$REPORT")"
CC="${CC:-clang}"
CFLAGS="--target=riscv32-unknown-elf -march=rv32i_zicsr_zifencei -mabi=ilp32 -nostdlib -nostartfiles -static -mno-relax -fuse-ld=lld"
PROFILES="${PROFILES:-100:1 70:2 40:4}"
SEEDS="${SEEDS:-1 2}"

[ -d "$RT/isa" ] || { echo "riscv-tests not found at $RT"; exit 2; }

# ---- simulator
SIMDIR="$OUT/obj_dir"
verilator --binary --timing -Wno-fatal -Wno-WIDTH -O2 --top-module tb_cpu \
  -Mdir "$SIMDIR" -o vtb_cpu \
  "$ROOT/rtl/pkg/sfv_pkg.sv" "$ROOT/rtl/cpu/sfv_cpu.sv" "$ROOT/tb/cpu/tb_cpu.sv" \
  > "$OUT/verilator_build.log" 2>&1 || { tail -30 "$OUT/verilator_build.log"; exit 1; }
SIM="$SIMDIR/vtb_cpu"

# Tests excluded and why (see docs/VERIFICATION_REPORT.md):
#   rv32ui/ma_data   : requires hardware misaligned access (spec option; core traps)
#   rv32mi/pmpaddr   : PMP not implemented (not required for M-only MCU)
#   rv32mi/breakpoint: debug trigger module (tselect/tdata/tcontrol) not
#                      implemented; LLVM also has no 'tcontrol' CSR name
SKIP=" rv32ui/ma_data rv32mi/pmpaddr rv32mi/breakpoint "

pass=0; fail=0; : > "$REPORT"
echo "# riscv-tests on sfv_cpu  ($(date -u +%F' '%T) UTC)" >> "$REPORT"
echo "# riscv-tests commit: $(git -C "$RT" rev-parse --short HEAD 2>/dev/null)" >> "$REPORT"
echo "# profiles (grant%:maxlatency): $PROFILES ; seeds: $SEEDS" >> "$REPORT"
for suite in rv32ui rv32mi; do
  for src in "$RT"/isa/$suite/*.S; do
    t="$suite/$(basename "$src" .S)"
    case "$SKIP" in *" $t "*) echo "SKIP $t" >> "$REPORT"; continue;; esac
    elf="$OUT/${t//\//-}.elf"
    # LLVM's assembler rejects a '.weak' symbol later made '.global' (GNU as
    # accepts it): drop the env's weak default when the test defines a handler.
    pre="$OUT/${t//\//-}.s"
    $CC $CFLAGS -E -I"$RT/env/p" -I"$RT/isa/macros/scalar" "$src" -o "$pre" 2> "$elf.log"
    for h in mtvec_handler stvec_handler; do
      if grep -qE "\.glob(a)?l[[:space:]]+$h" "$pre"; then sed -i "s/\.weak $h;//" "$pre"; fi
    done
    if ! $CC $CFLAGS -x assembler -T"$RT/env/p/link.ld" "$pre" -o "$elf" >> "$elf.log" 2>&1; then
      echo "BUILD-FAIL $t"; echo "BUILD-FAIL $t" >> "$REPORT"; fail=$((fail+1)); continue
    fi
    llvm-objcopy -O binary "$elf" "$elf.bin"
    python3 "$ROOT/scripts/bin2hex.py" "$elf.bin" "$elf.hex"
    tohost=$(llvm-nm "$elf" | awk '$3=="tohost"{print $1}')
    ok=1
    for prof in $PROFILES; do for seed in $SEEDS; do
      g=${prof%%:*}; l=${prof##*:}
      r=$("$SIM" +hex="$elf.hex" +tohost="$tohost" +gnt=$g +lat=$l +seed=$seed 2>&1 | grep "TB_CPU RESULT")
      case "$r" in *PASS*) ;; *) ok=0; echo "FAIL $t gnt=$g lat=$l seed=$seed : $r" >> "$REPORT";; esac
    done; done
    if [ $ok = 1 ]; then pass=$((pass+1)); echo "PASS $t" >> "$REPORT"; else fail=$((fail+1)); echo "FAIL $t"; fi
  done
done
echo "TOTAL pass=$pass fail=$fail" | tee -a "$REPORT"
[ $fail = 0 ]
