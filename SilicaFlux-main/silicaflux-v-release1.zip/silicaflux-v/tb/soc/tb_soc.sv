// =============================================================================
// SilicaFlux-V :: tb_soc -- end-to-end SoC testbench (firmware level)
//
// Board models: UART receiver (prints to stdout + log), SPI NOR flash
// (READ 0x03, mode 0) preloaded with the application image, GPIO pads
// (gpio[1:0] = boot straps, gpio[5] <- gpio[4] loopback, others pulled low),
// JTAG host tasks.
//
// plusargs:
//   +boot=<0..3>      strap value (0 SPI, 1 JTAG, 2 POST, 3 SRAM)
//   +flash=<hex>      byte-per-line flash image   (boot 0)
//   +sram=<hex>       word-per-line SRAM bank-0 image (boot 1 via JTAG, 3 backdoor)
//   +jtag=1           JTAG scenario: IDCODE, CPU hold, SBA loads the image,
//                     mailbox boot (use with +boot=1 and +sram)
//   +maxcyc=<n>       timeout in clk cycles (default 30M)
//   +log=<file>       UART transcript
// Exit: PASS when TEST_STATUS reports pass, FAIL on fail/timeout (prints
// "TB_SOC RESULT ...").
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_soc;
  localparam int BAUD = 16;                       // UART bit period (clk cycles)

  // reset starts high and is asserted with an edge at t=1ns: event-driven
  // simulators only apply `@(negedge rst_n)` async resets on a real edge
  // (silicon resets on the level), e.g. TCK-domain flops that never see TCK.
  logic clk = 0, rst_n = 1;
  initial #1 rst_n = 0;
  always #5 clk = ~clk;

  logic tck = 0, tms = 1, tdi = 0, tdo, tdo_oe;
  logic uart_tx, uart_rx = 1;
  logic spi_sck, spi_mosi, spi_miso, spi_cs0_n;
  logic [7:0] gpio_i, gpio_o, gpio_oe;
  logic test_pass, test_fail, cpu_sleep;
  logic [31:0] test_status;
  logic [1:0] straps;

  sfv_soc #(.UART_BAUD_RESET(16'(BAUD))) u_soc (
    .clk, .rst_ni(rst_n), .test_mode(1'b0),
    .tck, .tms, .tdi, .tdo, .tdo_oe,
    .uart_tx, .uart_rx,
    .spi_sck, .spi_mosi, .spi_miso, .spi_cs0_n,
    .gpio_i, .gpio_o, .gpio_oe,
    .test_pass, .test_fail, .test_status, .cpu_sleep
  );

  // ------------------------------------------------------------ GPIO pads
  logic [7:0] pad;
  always_comb begin
    for (int k = 0; k < 8; k++) pad[k] = gpio_oe[k] ? gpio_o[k] : 1'b0;
    gpio_i = pad;
    if (!gpio_oe[1]) gpio_i[1] = straps[1];
    if (!gpio_oe[0]) gpio_i[0] = straps[0];
    if (!gpio_oe[5]) gpio_i[5] = pad[4];
  end

  // ------------------------------------------------------------ UART monitor
  int    logfd = 0;
  string logname;
  string line = "";
  int    n_chars = 0;
  int    n_prompt = 0;                           // ROM "waiting for JTAG host" lines
  initial begin : uart_mon
    logic [7:0] ch;
    forever begin
      @(negedge uart_tx);
      repeat (BAUD / 2) @(posedge clk);
      if (uart_tx == 1'b0) begin
        for (int i = 0; i < 8; i++) begin
          repeat (BAUD) @(posedge clk);
          ch[i] = uart_tx;
        end
        repeat (BAUD) @(posedge clk);
        if (uart_tx != 1'b1) $display("TB_SOC UART framing error");
        n_chars++;
        if (ch == 8'h0A) begin
          $display("UART| %s", line);
          if (line == "boot: waiting for JTAG host") n_prompt++;
          if (stop_on != "" && line == stop_on) stop_hit = 1;
          if (logfd != 0) $fdisplay(logfd, "%s", line);
          line = "";
        end else if (ch != 8'h0D) begin
          line = {line, string'(ch)};
        end
      end
    end
  end

  // ------------------------------------------------------------ SPI flash
  logic [7:0] flash [0:262143];                  // 256 KiB
  int         f_bits;
  logic [7:0] f_cmd;
  logic [23:0] f_addr;
  logic [7:0] f_sh_in, f_sh_out;
  int         f_state;                           // 0 cmd, 1 addr, 2 data
  logic       miso_q = 1'b0;
  assign spi_miso = miso_q;
  always @(negedge spi_cs0_n) begin
    f_bits = 0; f_state = 0; f_addr = 0; f_sh_out = 8'h00;
  end
  always @(posedge spi_sck) if (!spi_cs0_n) begin
    f_sh_in = {f_sh_in[6:0], spi_mosi};
    f_bits++;
    if (f_bits % 8 == 0) begin
      case (f_state)
        0: begin f_cmd = f_sh_in; f_state = (f_cmd == 8'h03) ? 1 : 3; end
        1: begin
          f_addr = {f_addr[15:0], f_sh_in};
          if (f_bits == 32) begin f_state = 2; f_sh_out = flash[f_addr[17:0]]; end
        end
        2: begin f_addr = f_addr + 1; f_sh_out = flash[f_addr[17:0]]; end
        default: ;
      endcase
    end
  end
  // mode 0: data changes on the falling edge; first bit valid after the last
  // address bit's falling edge
  always @(negedge spi_sck) if (!spi_cs0_n) begin
    if (f_state == 2) begin
      miso_q   = f_sh_out[7];
      f_sh_out = {f_sh_out[6:0], 1'b0};
    end
  end

  // ------------------------------------------------------------ JTAG host
  localparam int TCK_HALF = 20;                  // ns -> 25 MHz TCK
  task automatic jtag_clk(input logic m, input logic d, output logic q);
    tms = m; tdi = d;
    #(TCK_HALF) tck = 1; q = tdo;
    #(TCK_HALF) tck = 0;
  endtask
  task automatic jtag_reset();
    logic q;
    for (int i = 0; i < 6; i++) jtag_clk(1, 0, q);
    jtag_clk(0, 0, q);                           // -> Run-Test/Idle
  endtask
  task automatic jtag_ir(input logic [4:0] ir);
    logic q;
    jtag_clk(1, 0, q); jtag_clk(1, 0, q);        // Select-DR, Select-IR
    jtag_clk(0, 0, q); jtag_clk(0, 0, q);        // Capture-IR, Shift-IR
    for (int i = 0; i < 5; i++) jtag_clk(i == 4, ir[i], q);
    jtag_clk(1, 0, q); jtag_clk(0, 0, q);        // Update-IR, RTI
  endtask
  task automatic jtag_dr(input int n, input logic [127:0] din, output logic [127:0] dout);
    logic q;
    dout = '0;
    jtag_clk(1, 0, q); jtag_clk(0, 0, q); jtag_clk(0, 0, q);   // Sel-DR, Capture, Shift
    for (int i = 0; i < n; i++) begin
      jtag_clk(i == n - 1, din[i], q);
      dout[i] = q;
    end
    jtag_clk(1, 0, q); jtag_clk(0, 0, q);        // Update-DR, RTI
  endtask
  // TDO is launched on the falling edge; the bit sampled at TCK rise i is
  // DR bit i (capture value is shifted out LSB first).
  task automatic sba(input logic [1:0] op, input logic [31:0] a, input logic [31:0] d,
                     output logic [31:0] rd, output logic err);
    logic [127:0] o;
    jtag_ir(5'h10);
    jtag_dr(66, {62'd0, op, d, a}, o);
    do begin
      jtag_dr(66, 128'd0, o);                    // poll
    end while (o[65]);
    rd  = o[63:32];
    err = o[64];
  endtask

  // ------------------------------------------------------------ main
  string  flashf, sramf, stop_on;
  int     boot, maxcyc, jtag_scn, cyc, expect_fail, fbank, faddr, fbit, fval;
  bit     stop_hit = 0;
  logic [31:0] sram_img [0:32767];
  bit     done = 0;
  initial begin
    if (!$value$plusargs("boot=%d", boot)) boot = 0;
    if (!$value$plusargs("maxcyc=%d", maxcyc)) maxcyc = 30_000_000;
    if (!$value$plusargs("jtag=%d", jtag_scn)) jtag_scn = 0;
    if ($value$plusargs("log=%s", logname)) logfd = $fopen(logname, "w");
    straps = 2'(boot);
    for (int i = 0; i < 262144; i++) flash[i] = 8'hFF;
    if ($value$plusargs("flash=%s", flashf)) $readmemh(flashf, flash);
    if ($value$plusargs("sram=%s", sramf)) begin
      for (int i = 0; i < 32768; i++) sram_img[i] = 32'h0;
      $readmemh(sramf, sram_img);
`ifndef SFV_SRAM_MACRO
      if (boot == 3)
        for (int i = 0; i < 8192; i++) u_soc.g_sram[0].u_bank.u_ram.mem[i] = sram_img[i];
`endif
    end
    if (!$value$plusargs("stop_on=%s", stop_on)) stop_on = "";
    if (!$value$plusargs("expect_fail=%d", expect_fail)) expect_fail = 0;
    // +fault_bank=<b> +fault_addr=<word> +fault_bit=<n> +fault_val=<0|1>:
    // stuck-at fault in a main SRAM bank (simulation-only hook in sfv_sram_sp)
`ifndef SFV_SRAM_MACRO
    if ($value$plusargs("fault_bank=%d", fbank)) begin
      if (!$value$plusargs("fault_addr=%d", faddr)) faddr = 0;
      if (!$value$plusargs("fault_bit=%d", fbit)) fbit = 0;
      if (!$value$plusargs("fault_val=%d", fval)) fval = 1;
      if (fbank == 0) begin
        u_soc.g_sram[0].u_bank.u_ram.fi_addr = faddr; u_soc.g_sram[0].u_bank.u_ram.fi_bit = fbit[4:0];
        u_soc.g_sram[0].u_bank.u_ram.fi_val = fval[0]; u_soc.g_sram[0].u_bank.u_ram.fi_en = 1'b1;
      end else if (fbank == 1) begin
        u_soc.g_sram[1].u_bank.u_ram.fi_addr = faddr; u_soc.g_sram[1].u_bank.u_ram.fi_bit = fbit[4:0];
        u_soc.g_sram[1].u_bank.u_ram.fi_val = fval[0]; u_soc.g_sram[1].u_bank.u_ram.fi_en = 1'b1;
      end else if (fbank == 2) begin
        u_soc.g_sram[2].u_bank.u_ram.fi_addr = faddr; u_soc.g_sram[2].u_bank.u_ram.fi_bit = fbit[4:0];
        u_soc.g_sram[2].u_bank.u_ram.fi_val = fval[0]; u_soc.g_sram[2].u_bank.u_ram.fi_en = 1'b1;
      end else begin
        u_soc.g_sram[3].u_bank.u_ram.fi_addr = faddr; u_soc.g_sram[3].u_bank.u_ram.fi_bit = fbit[4:0];
        u_soc.g_sram[3].u_bank.u_ram.fi_val = fval[0]; u_soc.g_sram[3].u_bank.u_ram.fi_en = 1'b1;
      end
      $display("TB_SOC fault injected: bank %0d word %0d bit %0d stuck-at-%0d", fbank, faddr, fbit, fval);
    end
`endif
    $display("TB_SOC boot_mode=%0d jtag=%0d", boot, jtag_scn);
    repeat (5) @(posedge clk);
    rst_n = 1;
  end

  // JTAG scenario (runs in parallel with the system)
  initial begin
    logic [127:0] o;
    logic [31:0]  rd;
    logic         e;
    int           errs;
    #1;
    if (jtag_scn) begin
      errs = 0;
      #(200);
      jtag_reset();
      jtag_dr(32, 128'd0, o);                    // IDCODE selected after TLR
      $display("TB_SOC JTAG IDCODE=%08x", o[31:0]);
      if (o[31:0] !== {4'h1, sfv_pkg::JTAG_PART, sfv_pkg::JTAG_MFR, 1'b1}) errs++;
      jtag_ir(5'h1F);                            // BYPASS: 1-bit DR
      jtag_dr(9, 128'h1A5, o);
      if (o[8:1] !== 8'hA5 || o[0] !== 1'b0) begin errs++; $display("TB_SOC JTAG bypass bad %h", o[8:0]); end
      jtag_ir(5'h11);                            // DBGCTRL: hold CPU
      jtag_dr(8, 128'h01, o);
      sba(2'd1, 32'h4000_0000, 0, rd, e);        // read CHIP_ID over SBA
      $display("TB_SOC JTAG SBA CHIP_ID=%08x err=%0d", rd, e);
      if (rd !== sfv_pkg::CHIP_ID || e) errs++;
      sba(2'd1, 32'h3000_0000, 0, rd, e);        // unmapped -> error
      if (!e) begin errs++; $display("TB_SOC JTAG SBA missing bus error"); end
      for (int i = 0; i < 2400; i++) begin       // load the app (first 9.6 KiB)
        sba(2'd2, 32'h1000_0000 + 4 * i, sram_img[i], rd, e);
        if (e) errs++;
      end
      for (int i = 0; i < 2400; i += 97) begin   // spot read-back
        sba(2'd1, 32'h1000_0000 + 4 * i, 0, rd, e);
        if (rd !== sram_img[i]) errs++;
      end
      sba(2'd2, 32'h4000_0008, 32'h1000_0000, rd, e);   // SCRATCH0 = entry
      sba(2'd2, 32'h4000_000C, 32'hB007_C0DE, rd, e);   // SCRATCH1 = go
      $display("TB_SOC JTAG image loaded, errors=%0d; releasing CPU", errs);
      if (errs) begin $display("TB_SOC RESULT FAIL jtag_errors=%0d", errs); $finish; end
      jtag_ir(5'h11);
      jtag_dr(8, 128'h00, o);                    // release CPU hold
      // After the application's soft reset the mailbox is cleared (system
      // reset domain) and the ROM prompts again: the host re-posts it.
      wait (n_prompt >= 2);
      sba(2'd2, 32'h4000_0008, 32'h1000_0000, rd, e);
      sba(2'd2, 32'h4000_000C, 32'hB007_C0DE, rd, e);
      $display("TB_SOC JTAG mailbox re-posted after soft reset");
    end
  end

  initial begin
    cyc = 0;
    @(posedge rst_n);
    while (!done && cyc < maxcyc) begin
      @(posedge clk);
      cyc++;
      if (stop_hit) begin
        $display("TB_SOC RESULT PASS stop_on=\"%s\" cycles=%0d chars=%0d", stop_on, cyc, n_chars);
        done = 1;
      end else if (test_fail) begin
        repeat (2000) @(posedge clk);
        if (expect_fail)
          $display("TB_SOC RESULT PASS expected-failure-detected status=%08x cycles=%0d", test_status, cyc);
        else
          $display("TB_SOC RESULT FAIL status=%08x cycles=%0d chars=%0d", test_status, cyc, n_chars);
        done = 1;
      end else if (test_pass) begin
        repeat (200 * BAUD) @(posedge clk);      // let the UART drain
        if (expect_fail)
          $display("TB_SOC RESULT FAIL expected a failure status=%08x", test_status);
        else
          $display("TB_SOC RESULT PASS status=%08x cycles=%0d chars=%0d", test_status, cyc, n_chars);
        done = 1;
      end
    end
    if (!done) $display("TB_SOC RESULT TIMEOUT cycles=%0d pc=%08x", cyc, u_soc.u_cpu.fb0_pc_q);
    if (logfd != 0) $fclose(logfd);
    $finish;
  end
endmodule

`default_nettype wire
