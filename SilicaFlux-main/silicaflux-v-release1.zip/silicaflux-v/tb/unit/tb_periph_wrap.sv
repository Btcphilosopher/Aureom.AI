// Peripheral unit-test wrapper: UART, SPI (MOSI->MISO loopback), GPIO,
// timer and interrupt controller on one register bus with per-block selects.
`timescale 1ns/1ps
module tb_periph_wrap (
  input  logic clk, rst_n,
  input  logic sel_uart, sel_spi, sel_gpio, sel_timer, sel_intc,
  input  logic rb_we,
  input  logic [11:0] rb_addr,
  input  logic [31:0] rb_wdata,
  output logic [31:0] rd_uart, rd_spi, rd_gpio, rd_timer, rd_intc,
  output logic er_uart, er_spi, er_gpio, er_timer, er_intc,
  output logic txd, input logic rxd,
  output logic sck, mosi, cs0_n,
  input  logic [7:0] gpio_i, output logic [7:0] gpio_o, gpio_oe,
  input  logic [7:0] irq_src_ext,
  output logic irq_uart, irq_spi, irq_gpio, irq_timer, irq_soft, irq_ext,
  output logic [15:0] sck_edges
);
  sfv_uart #(.BAUD_RESET(16'd8)) u_uart (.clk, .rst_n, .rb_sel(sel_uart), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rd_uart), .rb_err(er_uart), .txd, .rxd, .irq(irq_uart));
  sfv_spi u_spi (.clk, .rst_n, .rb_sel(sel_spi), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rd_spi), .rb_err(er_spi), .sck, .mosi, .miso(mosi), .cs0_n, .irq(irq_spi));
  sfv_gpio #(.N(8)) u_gpio (.clk, .rst_n, .rb_sel(sel_gpio), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rd_gpio), .rb_err(er_gpio), .gpio_i, .gpio_o, .gpio_oe, .irq(irq_gpio));
  sfv_timer u_tmr (.clk, .rst_n, .rb_sel(sel_timer), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rd_timer), .rb_err(er_timer), .irq_timer, .irq_soft);
  sfv_intc #(.N(8)) u_intc (.clk, .rst_n, .rb_sel(sel_intc), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rd_intc), .rb_err(er_intc), .src(irq_src_ext), .irq_ext);
  // count SCK transitions (edges) for protocol checks
  logic sck_q;
  always_ff @(posedge clk) begin
    if (!rst_n) begin sck_edges <= '0; sck_q <= 1'b0; end
    else begin sck_q <= sck; if (sck != sck_q) sck_edges <= sck_edges + 1'b1; end
  end
endmodule
