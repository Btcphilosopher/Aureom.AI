"""cocotb: UART, SPI, GPIO, timer, interrupt controller."""
import random

import cocotb
from cocotb.triggers import ClockCycles, FallingEdge, ReadOnly, RisingEdge

from sfv_cocotb import RegBus, start


def bus(dut, name):
    return RegBus(dut, getattr(dut, f"sel_{name}"), getattr(dut, f"rd_{name}"),
                  getattr(dut, f"er_{name}"))


async def setup(dut):
    for n in ("uart", "spi", "gpio", "timer", "intc"):
        getattr(dut, f"sel_{n}").value = 0
    dut.rxd.value = 1
    dut.gpio_i.value = 0
    dut.irq_src_ext.value = 0
    await start(dut)


async def uart_rx_byte(dut, baud):
    """Decode one 8N1 frame from txd (testbench side)."""
    while int(dut.txd.value) == 1:
        await RisingEdge(dut.clk)
    await ClockCycles(dut.clk, baud // 2)
    assert int(dut.txd.value) == 0, "start bit"
    v = 0
    for i in range(8):
        await ClockCycles(dut.clk, baud)
        v |= int(dut.txd.value) << i
    await ClockCycles(dut.clk, baud)
    assert int(dut.txd.value) == 1, "stop bit"
    return v


async def uart_tx_byte(dut, v, baud):
    bits = [0] + [(v >> i) & 1 for i in range(8)] + [1]
    for b in bits:
        dut.rxd.value = b
        await ClockCycles(dut.clk, baud)


@cocotb.test()
async def uart(dut):
    await setup(dut)
    u = bus(dut, "uart")
    rnd = random.Random(3)
    for baud in (8, 13, 32):
        await u.write(0x0C, baud)
        data = [rnd.getrandbits(8) for _ in range(6)]
        rx = cocotb.start_soon(_collect(dut, len(data), baud))
        for b in data:
            while not (await u.read(0x04))[0] & 1:          # TX_READY
                pass
            await u.write(0x00, b)
        got = await rx
        assert got == data, f"baud {baud}: tx {got} != {data}"
        # receive path
        sent = [rnd.getrandbits(8) for _ in range(3)]
        for b in sent:
            await uart_tx_byte(dut, b, baud)
        await ClockCycles(dut.clk, baud)
        for b in sent:
            v, _ = await u.read(0x00)
            assert v == b, f"baud {baud}: rx {v:#x} != {b:#x}"
        v, _ = await u.read(0x00)
        assert v >> 31 == 1, "RX_EMPTY flag"
    # overrun: 5 bytes into a 4-deep FIFO
    for b in range(5):
        await uart_tx_byte(dut, 0x40 + b, 32)
    await ClockCycles(dut.clk, 40)
    s, _ = await u.read(0x04)
    assert s & 0x8, "RX_OVF not set"
    await u.write(0x04, 0x38)
    s, _ = await u.read(0x04)
    assert not s & 0x38
    # framing error: stop bit low
    for b in [0] + [1] * 8 + [0]:
        dut.rxd.value = b
        await ClockCycles(dut.clk, 32)
    dut.rxd.value = 1
    await ClockCycles(dut.clk, 64)
    s, _ = await u.read(0x04)
    assert s & 0x10, "FRAME_ERR not set"
    # interrupts
    await u.write(0x04, 0x38)
    for _ in range(5):
        await u.read(0x00)
    await u.write(0x08, 0x1)                                # TX idle irq
    await ClockCycles(dut.clk, 2)
    assert int(dut.irq_uart.value) == 1
    await u.write(0x08, 0x0)
    _, e = await u.read(0x40)
    assert e == 1


async def _collect(dut, n, baud):
    return [await uart_rx_byte(dut, baud) for _ in range(n)]


@cocotb.test()
async def spi_modes(dut):
    await setup(dut)
    s = bus(dut, "spi")
    rnd = random.Random(5)
    for mode in range(4):
        cpol, cpha = mode >> 1, mode & 1
        for div in (0, 1, 3):
            await s.write(0x0C, div)
            await s.write(0x08, (1 << 8) | (cpha << 1) | cpol)   # CS0 + mode
            await ClockCycles(dut.clk, 2)
            assert int(dut.sck.value) == cpol, "SCK idle level"
            assert int(dut.cs0_n.value) == 0
            for _ in range(3):
                b = rnd.getrandbits(8)
                e0 = int(dut.sck_edges.value)
                await s.write(0x00, b)
                while (await s.read(0x04))[0] & 1:
                    pass
                v, _ = await s.read(0x00)
                assert v == b, f"mode {mode} div {div}: loopback {v:#x} != {b:#x}"
                assert int(dut.sck_edges.value) - e0 == 16, "16 SCK edges per byte"
                assert int(dut.sck.value) == cpol
            await s.write(0x08, (cpha << 1) | cpol)
            await ClockCycles(dut.clk, 1)
            assert int(dut.cs0_n.value) == 1
    # write while busy -> bus error
    await s.write(0x0C, 7)
    await s.write(0x00, 0x55)
    s.sel.value, s.we.value, s.addr.value, s.wdata.value = 1, 1, 0, 0xAA
    await ReadOnly()
    assert int(dut.er_spi.value) == 1, "write while busy must error"
    await RisingEdge(dut.clk)
    s.sel.value, s.we.value = 0, 0
    while (await s.read(0x04))[0] & 1:
        pass
    v, _ = await s.read(0x00)
    assert v == 0x55, "busy write must not disturb the transfer"


@cocotb.test()
async def gpio_timer_intc(dut):
    await setup(dut)
    g, t, i = bus(dut, "gpio"), bus(dut, "timer"), bus(dut, "intc")
    await g.write(0x08, 0x0F)
    await g.write(0x04, 0x05)
    await ClockCycles(dut.clk, 1)
    assert int(dut.gpio_o.value) == 0x05 and int(dut.gpio_oe.value) == 0x0F
    await g.write(0x0C, 0x10)                               # rise on pin 4
    await g.write(0x10, 0x20)                               # fall on pin 5
    dut.gpio_i.value = 0x20
    await ClockCycles(dut.clk, 4)
    dut.gpio_i.value = 0x10
    await ClockCycles(dut.clk, 4)
    p, _ = await g.read(0x14)
    assert p == 0x30, f"gpio pend {p:#x}"
    assert int(dut.irq_gpio.value) == 1
    await g.write(0x14, 0x30)
    await ClockCycles(dut.clk, 1)
    assert int(dut.irq_gpio.value) == 0
    v, _ = await g.read(0x00)
    assert v == 0x10
    # timer: compare match, prescale, msip
    assert int(dut.irq_timer.value) == 0, "mtimecmp must reset to max"
    await t.write(0x14, 3)                                  # tick every 4 cycles
    await t.write(0x00, 0)
    await t.write(0x04, 0)
    await t.write(0x0C, 0)
    await t.write(0x08, 10)
    n = 0
    while not int(dut.irq_timer.value):
        await RisingEdge(dut.clk)
        n += 1
    assert 36 <= n <= 44, f"prescaled compare after {n} cycles"
    await t.write(0x10, 1)
    await ClockCycles(dut.clk, 1)
    assert int(dut.irq_soft.value) == 1
    # intc: enable mask and claim priority (lowest index first)
    dut.irq_src_ext.value = 0b1010_0100
    await i.write(0x04, 0b1010_0000)
    await ClockCycles(dut.clk, 1)
    c, _ = await i.read(0x08)
    assert c == 6 and int(dut.irq_ext.value) == 1, f"claim {c}"
    await i.write(0x04, 0)
    await ClockCycles(dut.clk, 1)
    assert int(dut.irq_ext.value) == 0
    c, _ = await i.read(0x08)
    assert c == 0
