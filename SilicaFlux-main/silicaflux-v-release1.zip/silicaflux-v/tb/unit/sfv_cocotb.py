"""Shared cocotb helpers: clock/reset, register-bus and SFB drivers."""
import random

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ReadOnly, RisingEdge, Timer


async def start(dut, period_ns=10, reset_cycles=5):
    cocotb.start_soon(Clock(dut.clk, period_ns, units="ns").start())
    dut.rst_n.value = 0
    for _ in range(reset_cycles):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


class RegBus:
    """Single-cycle register bus (rb_sel strobe, comb. read data)."""

    def __init__(self, dut, sel, rdata, err, prefix="rb_"):
        self.dut, self.sel, self.rdata, self.err = dut, sel, rdata, err
        self.we = getattr(dut, prefix + "we")
        self.addr = getattr(dut, prefix + "addr")
        self.wdata = getattr(dut, prefix + "wdata")
        self.sel.value = 0
        self.we.value = 0

    async def write(self, off, val):
        self.sel.value, self.we.value = 1, 1
        self.addr.value, self.wdata.value = off, val & 0xFFFFFFFF
        await RisingEdge(self.dut.clk)
        self.sel.value, self.we.value = 0, 0

    async def read(self, off):
        self.sel.value, self.we.value, self.addr.value = 1, 0, off
        await ReadOnly()
        v, e = int(self.rdata.value), int(self.err.value)
        await RisingEdge(self.dut.clk)
        self.sel.value = 0
        return v, e


class SfbMaster:
    """SFB master driving req/addr/we/be/wdata, waiting gnt and rvalid."""

    def __init__(self, dut, prefix=""):
        p = prefix
        self.dut = dut
        self.req = getattr(dut, p + "req")
        self.gnt = getattr(dut, p + "gnt")
        self.addr = getattr(dut, p + "addr")
        self.we = getattr(dut, p + "we")
        self.be = getattr(dut, p + "be")
        self.wdata = getattr(dut, p + "wdata")
        self.rvalid = getattr(dut, p + "rvalid")
        self.rdata = getattr(dut, p + "rdata")
        self.err = getattr(dut, p + "err")
        self.req.value = 0
        self.wait_states = 0

    async def access(self, addr, we=0, wdata=0, be=0xF):
        self.req.value, self.addr.value, self.we.value = 1, addr, we
        self.be.value, self.wdata.value = be, wdata & 0xFFFFFFFF
        while True:
            await ReadOnly()
            g = int(self.gnt.value)
            await RisingEdge(self.dut.clk)
            if g:
                break
            self.wait_states += 1
        self.req.value = 0
        while True:
            await ReadOnly()
            if int(self.rvalid.value):
                d, e = int(self.rdata.value), int(self.err.value)
                await RisingEdge(self.dut.clk)
                return d, e
            await RisingEdge(self.dut.clk)

    async def write(self, addr, val, be=0xF):
        return (await self.access(addr, 1, val, be))[1]

    async def read(self, addr):
        return await self.access(addr, 0)
