"""cocotb: compute tile (TSPM + vector engine + tensor engine) vs golden model.

Random vector and tensor commands; operands are loaded and results read back
through the SFB fabric port.  A background task injects random fabric traffic
into the TSPM while engines run: results and CYCLES must be unaffected
(engine priority => deterministic completion), and the fabric port must see
wait states (backpressure exercised).
"""
import os
import random
import sys

import cocotb
from cocotb.triggers import RisingEdge

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "models"))
import sfv_golden as g  # noqa: E402
from sfv_cocotb import RegBus, SfbMaster, start  # noqa: E402

TSPM_WORDS = int(os.environ.get("TSPM_WORDS", "1024"))
TSPM_BYTES = TSPM_WORDS * 4
VE = dict(CTRL=0x00, STATUS=0x04, CMD=0x08, SA=0x0C, SB=0x10, DST=0x14, LEN=0x18, SCAL=0x1C,
          RES=0x20, CYC=0x24)
TE = dict(CTRL=0x00, STATUS=0x04, CFG=0x08, A=0x0C, B=0x10, C=0x14, K=0x18, AS=0x1C, BS=0x20,
          CS=0x24, CYC=0x28)


class Tile:
    def __init__(self, dut):
        self.dut = dut
        dut.test_mode.value = 0
        dut.cg_off.value = 0
        dut.bist_en.value = 0
        dut.bist_ce.value = 0
        dut.bist_we.value = 0
        dut.bist_addr.value = 0
        dut.bist_wdata.value = 0
        dut.ve_sel.value = 0
        dut.te_sel.value = 0
        self.ve = RegBus(dut, dut.ve_sel, dut.ve_rdata, dut.ve_err)
        self.te = RegBus(dut, dut.te_sel, dut.te_rdata, dut.te_err)
        self.fab = SfbMaster(dut)
        self.mem = [0] * TSPM_WORDS          # shadow of TSPM contents

    async def wr(self, word, val):
        self.mem[word] = val & 0xFFFFFFFF
        assert await self.fab.write(word * 4, val) == 0

    async def rd(self, word):
        d, e = await self.fab.read(word * 4)
        assert e == 0
        return d

    async def init(self):
        """SRAM powers up undefined: give every word a known value."""
        for w in range(TSPM_WORDS):
            await self.wr(w, 0)

    async def wait_done(self, rb):
        while True:
            s, _ = await rb.read(0x04)
            if not s & 1:
                return s


async def noise(tile, stop, region):
    """Random fabric reads inside `region` (word range) while engines run."""
    lo, hi = region
    while not stop[0]:
        w = random.randrange(lo, hi)
        d = await tile.rd(w)
        assert d == tile.mem[w], f"noise read mismatch @{w}: {d:#x} != {tile.mem[w]:#x}"


@cocotb.test()
async def vector_random(dut):
    random.seed(int(os.environ.get("SEED", "1")))
    await start(dut)
    t = Tile(dut)
    await t.init()
    n_cmds = int(os.environ.get("N_VEC", "120"))
    quarter = TSPM_WORDS // 4
    for c in range(n_cmds):
        op = random.randrange(len(g.VOPS))
        n = random.choice([0, 1, 2, 3, 4, 5, 7, 8, 13, 16, 31, 64, random.randrange(1, quarter // 2)])
        bsc = random.random() < 0.3
        acc = random.random() < 0.3
        wres = (op == g.VOP["DOT"]) and random.random() < 0.5
        sa, sb, sd = 0, quarter * 4, 2 * quarter * 4         # byte offsets
        a = [random.getrandbits(32) for _ in range(n)]
        b = [random.getrandbits(32) for _ in range(n)]
        if g.VOPS[op] in ("SLL", "SRA", "SRL") and random.random() < 0.5:
            b = [x & 31 for x in b]
        for i in range(n):
            await t.wr(sa // 4 + i, a[i])
            await t.wr(sb // 4 + i, b[i])
        span = ((n + 3) // 4) * 4 + 4
        for i in range(span):
            await t.wr(sd // 4 + i, 0xDEADBEEF)
        scal = random.getrandbits(32)
        acc_in = random.getrandbits(32)
        await t.ve.write(VE["RES"], acc_in)
        flags = op | (0x100 if bsc else 0) | (0x200 if acc else 0) | (0x400 if wres else 0)
        await t.ve.write(VE["CMD"], flags)
        await t.ve.write(VE["SA"], sa)
        await t.ve.write(VE["SB"], sb)
        await t.ve.write(VE["DST"], sd)
        await t.ve.write(VE["LEN"], n)
        await t.ve.write(VE["SCAL"], scal)
        await t.ve.write(VE["STATUS"], 0x6)
        stop = [False]
        nt = cocotb.start_soon(noise(t, stop, (0, quarter * 2)))   # contend on A/B rows
        await t.ve.write(VE["CTRL"], 1)
        s = await t.wait_done(t.ve)
        stop[0] = True
        await nt
        assert s & 0x6 == 0x2, f"cmd {c}: status {s:#x}"
        vec, dot = g.ve_command(op, a, b, scal, bsc, acc_in, acc)
        cyc, _ = await t.ve.read(VE["CYC"])
        assert cyc == g.ve_cycles(op, n, bsc, wres), f"cmd {c} op {g.VOPS[op]} n={n}: cycles {cyc}"
        if vec is not None:
            for i in range(span):
                d = await t.rd(sd // 4 + i)
                exp = vec[i] if i < n else 0xDEADBEEF
                assert d == exp, f"cmd {c} {g.VOPS[op]} n={n} bsc={bsc} elem {i}: {d:#x} != {exp:#x}"
                t.mem[sd // 4 + i] = d
        else:
            r, _ = await t.ve.read(VE["RES"])
            assert r == dot, f"cmd {c} DOT n={n}: {r:#x} != {dot:#x}"
            if wres and n:
                d = await t.rd(sd // 4)
                assert d == dot
                t.mem[sd // 4] = d
    dut._log.info("vector: %d random commands OK, fabric wait states=%d", n_cmds, t.fab.wait_states)
    assert t.fab.wait_states > 0, "fabric backpressure never exercised"


@cocotb.test()
async def tensor_random(dut):
    random.seed(int(os.environ.get("SEED", "1")) + 7)
    await start(dut)
    t = Tile(dut)
    await t.init()
    n_cmds = int(os.environ.get("N_TEN", "60"))
    acc_state = [0] * 16
    for c in range(n_cmds):
        k = random.choice([1, 2, 3, 4, 5, 8, 16, random.randrange(1, 40)])
        a_s = random.choice([4, 8, 12])
        b_s = random.choice([4, 4, 8])
        c_s = random.choice([16, 32])
        a_uns, b_uns = random.random() < 0.5, random.random() < 0.5
        acc = random.random() < 0.3
        wb = random.random() < 0.7
        a0, b0, c0 = 0, (TSPM_BYTES // 2) & ~15, (3 * TSPM_BYTES // 4) & ~15
        a_cols = [random.getrandbits(32) for _ in range(k)]
        b_rows = [random.getrandbits(32) for _ in range(k)]
        for i in range(k):
            await t.wr((a0 + i * a_s) // 4, a_cols[i])
            await t.wr((b0 + i * b_s) // 4, b_rows[i])
        cfg = (1 if acc else 0) | (2 if wb else 0) | (4 if a_uns else 0) | (8 if b_uns else 0)
        for reg, v in (("CFG", cfg), ("A", a0), ("B", b0), ("C", c0), ("K", k), ("AS", a_s),
                       ("BS", b_s), ("CS", c_s)):
            await t.te.write(TE[reg], v)
        await t.te.write(TE["STATUS"], 0x6)
        stop = [False]
        nt = cocotb.start_soon(noise(t, stop, (0, TSPM_WORDS // 2)))
        await t.te.write(TE["CTRL"], 1)
        s = await t.wait_done(t.te)
        stop[0] = True
        await nt
        assert s & 0x6 == 0x2, f"cmd {c}: status {s:#x}"
        exp = g.te_command(a_cols, b_rows, k, a_uns, b_uns, acc_state if acc else None)
        acc_state = exp
        cyc, _ = await t.te.read(TE["CYC"])
        assert cyc == g.te_cycles(k, wb), f"cmd {c} k={k}: cycles {cyc} != {g.te_cycles(k, wb)}"
        for i in range(16):
            v, _ = await t.te.read(0x40 + 4 * i)
            assert v == exp[i], f"cmd {c} k={k} acc[{i}] {v:#x} != {exp[i]:#x}"
        if wb:
            for i in range(4):
                for j in range(4):
                    w = (c0 + i * c_s) // 4 + j
                    d = await t.rd(w)
                    assert d == exp[4 * i + j]
                    t.mem[w] = d
    dut._log.info("tensor: %d random commands OK, fabric wait states=%d", n_cmds, t.fab.wait_states)


@cocotb.test()
async def errors_and_lock(dut):
    await start(dut)
    t = Tile(dut)
    # misaligned / out of range / bad op / K=0
    for regs, code in (({"SA": 4, "LEN": 4, "CMD": 0}, 1), ({"SA": TSPM_BYTES - 16, "LEN": 8, "CMD": 0}, 2),
                       ({"SA": 0, "LEN": 4, "CMD": 12}, 3)):
        await t.ve.write(VE["STATUS"], 6)
        for r, v in regs.items():
            await t.ve.write(VE[r], v)
        await t.ve.write(VE["CTRL"], 1)
        s, _ = await t.ve.read(VE["STATUS"])
        assert s & 0xF7 == 0x4 | (code << 4), f"VE error {code}: status {s:#x}"
    await t.te.write(TE["K"], 0)
    await t.te.write(TE["CTRL"], 1)
    s, _ = await t.te.read(TE["STATUS"])
    assert s & 0xF7 == 0x4 | (2 << 4)
    # both engines started in the same window: lock serialises, TE first
    await t.ve.write(VE["STATUS"], 6)
    await t.te.write(TE["STATUS"], 6)
    for r, v in (("CMD", 0), ("SA", 0), ("SB", 0), ("DST", 1024), ("LEN", 64)):
        await t.ve.write(VE[r], v)
    for r, v in (("CFG", 0), ("A", 0), ("B", 0), ("K", 8), ("AS", 0), ("BS", 0)):
        await t.te.write(TE[r], v)
    await t.te.write(TE["CTRL"], 1)
    await t.ve.write(VE["CTRL"], 1)
    s = await t.wait_done(t.ve)
    s2 = await t.wait_done(t.te)
    assert s & 6 == 2 and s2 & 6 == 2
    vc, _ = await t.ve.read(VE["CYC"])
    assert vc > g.ve_cycles(0, 64, False, False), "VE did not wait for the TE lock"
    # unmapped register offsets return err
    _, e = await t.ve.read(0x100)
    assert e == 1
