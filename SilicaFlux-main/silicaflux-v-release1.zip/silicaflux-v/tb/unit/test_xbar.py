"""cocotb: crossbar -- 3 concurrent random masters, randomised slave timing.

Checks: data integrity per master (disjoint address sub-ranges, shadow
memory), in-order single response per request, decode errors for unmapped
addresses and for the access-mask (master 2 -> S2), slave error propagation,
error capture, and the slave single-outstanding protocol assertion.
"""
import os
import random

import cocotb
from cocotb.triggers import RisingEdge

from sfv_cocotb import SfbMaster, start

BASES = [0x0000_0000, 0x1000_0000, 0x2000_0000]


async def master(dut, m, n, log):
    rnd = random.Random(1000 + m)
    port = SfbMaster(dut, prefix=f"m{m}_")
    shadow = {}
    stats = dict(ok=0, derr=0, serr=0)
    for _ in range(n):
        r = rnd.random()
        if r < 0.05:                                        # unmapped
            d, e = await port.read(0x3000_0000 + 4 * rnd.randrange(16))
            assert e == 1 and d == 0
            stats["derr"] += 1
            continue
        s = rnd.randrange(3)
        if m == 2 and s == 2:                               # access mask
            e = await port.write(BASES[2] + 4 * rnd.randrange(16), 1)
            assert e == 1
            stats["derr"] += 1
            continue
        if s == 1 and rnd.random() < 0.03:                  # slave error word
            _, e = await port.read(BASES[1] + 0xFFC)
            assert e == 1
            stats["serr"] += 1
            continue
        w = m * 300 + rnd.randrange(300)                    # disjoint per master
        a = BASES[s] + 4 * w
        if rnd.random() < 0.5 or a not in shadow:
            be = rnd.choice([0xF, 0xF, 0x1, 0x2, 0x4, 0x8, 0x3, 0xC])
            v = rnd.getrandbits(32)
            assert await port.write(a, v, be) == 0
            old = shadow.get(a, 0)
            nv = 0
            for b in range(4):
                src = v if (be >> b) & 1 else old
                nv |= src & (0xFF << (8 * b))
            shadow[a] = nv if (a in shadow or be == 0xF) else None
            if shadow[a] is None:
                del shadow[a]                               # partially unknown
        else:
            d, e = await port.read(a)
            assert e == 0
            assert d == shadow[a], f"m{m} read {a:#x}: {d:#x} != {shadow[a]:#x}"
            stats["ok"] += 1
    log[m] = (stats, port.wait_states)


@cocotb.test()
async def random_traffic(dut):
    dut.seed.value = int(os.environ.get("SEED", "7"))
    for m in range(3):
        getattr(dut, f"m{m}_req").value = 0
    await start(dut)
    n = int(os.environ.get("N_XBAR", "1500"))
    log = {}
    tasks = [cocotb.start_soon(master(dut, m, n, log)) for m in range(3)]
    for t in tasks:
        await t
    for _ in range(5):
        await RisingEdge(dut.clk)
    assert int(dut.protocol_error.value) == 0, "slave protocol violated"
    for m in range(3):
        dut._log.info("master %d: %s wait_states=%d", m, log[m][0], log[m][1])
        assert log[m][1] > 0
