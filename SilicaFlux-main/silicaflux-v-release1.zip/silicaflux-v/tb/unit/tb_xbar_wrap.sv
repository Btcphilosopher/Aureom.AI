// Crossbar unit-test wrapper: 3 masters (cocotb) x 3 memory slaves with
// randomised grant and response latency, plus protocol assertions.
// Map: S0 0x0000_0xxx  S1 0x1000_0xxx  S2 0x2000_0xxx (4 KiB each);
// master 2 may not access S2 (MST_SLV_EN) -> decode error.
`timescale 1ns/1ps
module tb_xbar_wrap (
  input  logic clk, rst_n,
  input  logic m0_req, m1_req, m2_req,
  output logic m0_gnt, m1_gnt, m2_gnt,
  input  logic [31:0] m0_addr, m1_addr, m2_addr,
  input  logic m0_we, m1_we, m2_we,
  input  logic [3:0] m0_be, m1_be, m2_be,
  input  logic [31:0] m0_wdata, m1_wdata, m2_wdata,
  output logic m0_rvalid, m1_rvalid, m2_rvalid,
  output logic [31:0] m0_rdata, m1_rdata, m2_rdata,
  output logic m0_err, m1_err, m2_err,
  output logic err_evt,
  output logic [31:0] err_addr,
  output logic [1:0] err_master,
  output logic protocol_error,
  input  logic [31:0] seed
);
  localparam int NM = 3, NS = 3;
  logic [NM-1:0] mreq, mgnt, mwe, mrv, merr;
  logic [NM*32-1:0] maddr, mwd, mrd;
  logic [NM*4-1:0] mbe;
  assign mreq = {m2_req, m1_req, m0_req};
  assign maddr = {m2_addr, m1_addr, m0_addr};
  assign mwe = {m2_we, m1_we, m0_we};
  assign mbe = {m2_be, m1_be, m0_be};
  assign mwd = {m2_wdata, m1_wdata, m0_wdata};
  assign {m2_gnt, m1_gnt, m0_gnt} = mgnt;
  assign {m2_rvalid, m1_rvalid, m0_rvalid} = mrv;
  assign {m2_err, m1_err, m0_err} = merr;
  assign {m2_rdata, m1_rdata, m0_rdata} = mrd;

  logic [NS-1:0] sreq, sgnt, swe, srv, serr;
  logic [NS*32-1:0] saddr, swd, srd;
  logic [NS*4-1:0] sbe;

  sfv_xbar #(.NM(NM), .NS(NS),
    .SLV_BASE({32'h2000_0000, 32'h1000_0000, 32'h0000_0000}),
    .SLV_MASK({32'hFFFF_F000, 32'hFFFF_F000, 32'hFFFF_F000}),
    .MST_SLV_EN(9'b011_111_111)) u_dut (
    .clk, .rst_n,
    .m_req(mreq), .m_gnt(mgnt), .m_addr(maddr), .m_we(mwe), .m_be(mbe), .m_wdata(mwd),
    .m_rvalid(mrv), .m_rdata(mrd), .m_err(merr),
    .s_req(sreq), .s_gnt(sgnt), .s_addr(saddr), .s_we(swe), .s_be(sbe), .s_wdata(swd),
    .s_rvalid(srv), .s_rdata(srd), .s_err(serr),
    .err_evt, .err_addr, .err_master, .err_we());

  // slave models: 1 KiW memory, random gnt (75%), latency 1..3; S1 returns an
  // error for word address 0x3FF (slave error path)
  logic [31:0] mem [0:NS-1][0:1023];
  int unsigned rng;
  logic [NS-1:0] pend;
  int cnt [0:NS-1];
  logic [31:0] pa [0:NS-1], pwd [0:NS-1];
  logic [3:0] pbe [0:NS-1];
  logic pwe [0:NS-1];
  initial rng = 1;
  function automatic int unsigned nxt();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    nxt = rng;
  endfunction
  logic [NS-1:0] gnt_r;
  always_ff @(posedge clk) begin
    if (!rst_n) rng <= (seed == 0) ? 1 : seed;
    for (int s = 0; s < NS; s++) gnt_r[s] <= (nxt() % 4) != 0;
  end
  assign sgnt = gnt_r;
  always_ff @(posedge clk) begin
    srv <= '0;
    if (!rst_n) begin
      pend <= '0;
    end else begin
      for (int s = 0; s < NS; s++) begin
        if (pend[s]) begin
          if (cnt[s] <= 1) begin
            srv[s] <= 1'b1;
            pend[s] <= 1'b0;
            srd[s*32 +: 32] <= (pwe[s] || (s == 1 && pa[s][11:2] == 10'h3FF)) ? 32'd0 : mem[s][pa[s][11:2]];
            serr[s] <= (s == 1) && (pa[s][11:2] == 10'h3FF);
            if (pwe[s]) for (int b = 0; b < 4; b++)
              if (pbe[s][b]) mem[s][pa[s][11:2]][b*8 +: 8] <= pwd[s][b*8 +: 8];
          end else cnt[s] <= cnt[s] - 1;
        end
        if (sreq[s] && sgnt[s]) begin
          pend[s] <= 1'b1; pa[s] <= saddr[s*32 +: 32]; pwe[s] <= swe[s];
          pbe[s] <= sbe[s*4 +: 4]; pwd[s] <= swd[s*32 +: 32]; cnt[s] <= nxt() % 3;
        end
      end
    end
  end

  // protocol assertions: a slave never gets a new request while it still owes
  // a response (unless the response is delivered in that cycle)
  always_ff @(posedge clk) begin
    if (!rst_n) protocol_error <= 1'b0;
    else for (int s = 0; s < NS; s++)
      if (sreq[s] && sgnt[s] && pend[s] && !(cnt[s] <= 1)) protocol_error <= 1'b1;
  end
endmodule
