"""cocotb: March C- MBIST controller with injected memory faults.

Four Python bank models (1-cycle read latency) respond on the broadcast BIST
port.  Fault models: stuck-at-0/1, transition (0->1 blocked), address-decoder
alias, idempotent coupling (aggressor write forces victim).  Each fault must be
detected with the right bank mask; stuck-at faults must also be located.
A fault-free run must pass, and the run length must be the March C- count.
"""
import cocotb
from cocotb.triggers import ReadOnly, RisingEdge

from sfv_cocotb import start

N = 256           # AW = 8
NB = 4


class Banks:
    def __init__(self, fault=None):
        self.m = [[0] * N for _ in range(NB)]
        self.f = fault or {}

    def write(self, b, a, v):
        f = self.f
        if f.get("bank") == b:
            if f["kind"] == "alias" and a == f["alias"]:
                self.m[b][f["addr"]] = v                     # decoder fault
            if f["kind"] == "transition" and a == f["addr"]:
                old = self.m[b][a]
                bit = 1 << f["bit"]
                if not old & bit:
                    v &= ~bit                                # 0 -> 1 fails
            if f["kind"] == "coupling" and a == f["aggr"]:
                self.m[b][f["addr"]] |= 1 << f["bit"]       # aggressor forces 1
        self.m[b][a] = v

    def read(self, b, a):
        v = self.m[b][a]
        f = self.f
        if f.get("bank") == b and f["kind"] == "stuck" and a == f["addr"]:
            bit = 1 << f["bit"]
            v = (v | bit) if f["val"] else (v & ~bit)
        return v


async def run(dut, fault, bg):
    banks = Banks(fault)
    dut.start.value = 0
    dut.bg_chk.value = bg
    dut.last.value = N - 1
    dut.bist_rdata.value = 0
    await RisingEdge(dut.clk)
    dut.start.value = 1
    await RisingEdge(dut.clk)
    dut.start.value = 0
    cycles = 0
    pending = None
    while True:
        await ReadOnly()
        busy = int(dut.busy.value)
        ce, we = int(dut.bist_ce.value), int(dut.bist_we.value)
        a, wd = int(dut.bist_addr.value), int(dut.bist_wdata.value)
        await RisingEdge(dut.clk)
        cycles += 1
        rd = None
        if ce and not we:
            rd = sum(banks.read(b, a) << (32 * b) for b in range(NB))
        if ce and we:
            for b in range(NB):
                banks.write(b, a, wd)
        if rd is not None:
            dut.bist_rdata.value = rd
        if not busy and cycles > 2:
            break
    await ReadOnly()
    r = dict(done=int(dut.done.value), fail=int(dut.fail.value),
             bank=int(dut.fail_bank.value), addr=int(dut.fail_addr.value), cycles=cycles)
    await RisingEdge(dut.clk)                 # leave the read-only phase
    return r


@cocotb.test()
async def march_faults(dut):
    await start(dut)
    for bg in (0, 1):
        r = await run(dut, None, bg)
        assert r["done"] and not r["fail"], f"fault-free run failed: {r}"
        # M0: N, M1..M4: 2N each, M5: 2N  -> 11N (+ start/finish)
        assert abs(r["cycles"] - 11 * N) <= 4, f"cycle count {r['cycles']}"
        dut._log.info("bg=%d fault-free: %d cycles (11N = %d)", bg, r["cycles"], 11 * N)
    cases = [
        (dict(kind="stuck", bank=2, addr=0x37, bit=5, val=1), 0b0100, 0x37),
        (dict(kind="stuck", bank=0, addr=0x00, bit=0, val=0), 0b0001, 0x00),
        (dict(kind="stuck", bank=3, addr=0xFF, bit=31, val=1), 0b1000, 0xFF),
        (dict(kind="transition", bank=1, addr=0x80, bit=17), 0b0010, None),
        (dict(kind="alias", bank=3, addr=0x40, alias=0x41), 0b1000, None),
        (dict(kind="coupling", bank=0, addr=0x10, aggr=0x90, bit=3), 0b0001, None),
    ]
    for fault, mask, addr in cases:
        for bg in (0, 1):
            r = await run(dut, fault, bg)
            assert r["done"] and r["fail"], f"{fault} bg={bg} not detected: {r}"
            assert r["bank"] == mask, f"{fault}: bank mask {r['bank']:#x}"
            if addr is not None:
                assert r["addr"] == addr, f"{fault}: fail addr {r['addr']:#x}"
        dut._log.info("detected %s", fault["kind"])
