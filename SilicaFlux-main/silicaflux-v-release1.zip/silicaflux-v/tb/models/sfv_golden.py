"""SilicaFlux-V software golden models (bit-exact reference for RTL tests).

Used by: cocotb unit tests (tb/unit), POST vector generation for the boot ROM
(scripts/gen_post_vectors.py) and the SoC firmware cross-check.
"""
from __future__ import annotations

M32 = 0xFFFFFFFF
VOPS = ["ADD", "SUB", "MUL", "MIN", "MAX", "AND", "OR", "XOR", "SLL", "SRA", "SRL", "DOT"]
VOP = {n: i for i, n in enumerate(VOPS)}


def s32(v: int) -> int:
    v &= M32
    return v - (1 << 32) if v & 0x80000000 else v


def sext(v: int, w: int) -> int:
    v &= (1 << w) - 1
    return v - (1 << w) if v >> (w - 1) else v


def ve_elem(op: int, a: int, b: int, mul_w: int = 32) -> int:
    a &= M32
    b &= M32
    n = VOPS[op]
    if n == "ADD": r = a + b
    elif n == "SUB": r = a - b
    elif n in ("MUL", "DOT"): r = sext(a, mul_w) * sext(b, mul_w)
    elif n == "MIN": r = a if s32(a) < s32(b) else b
    elif n == "MAX": r = a if s32(a) > s32(b) else b
    elif n == "AND": r = a & b
    elif n == "OR": r = a | b
    elif n == "XOR": r = a ^ b
    elif n == "SLL": r = a << (b & 31)
    elif n == "SRA": r = s32(a) >> (b & 31)
    elif n == "SRL": r = a >> (b & 31)
    else: raise ValueError(op)
    return r & M32


def ve_command(op, a, b, scalar=0, bscalar=False, acc_in=0, acc=False, mul_w=32):
    """Return (vector_result or None, dot_result).  a, b: element lists."""
    n = len(a)
    bv = [scalar] * n if bscalar else b
    if VOPS[op] == "DOT":
        r = acc_in if acc else 0
        for i in range(n):
            r = (r + ve_elem(op, a[i], bv[i], mul_w)) & M32
        return None, r
    return [ve_elem(op, a[i], bv[i], mul_w) for i in range(n)], None


def ve_cycles(op, n, bscalar, wres, lanes=4):
    """Deterministic command latency (STATUS.BUSY high cycles) - see RTL doc."""
    beats = (n + lanes - 1) // lanes
    dot = VOPS[op] == "DOT"
    p = (0 if bscalar else 1) + 1 + (0 if dot else 1)
    if n == 0:
        return 2
    return 3 + beats * p + (1 if (dot and wres) else 0)


def te_command(a_cols, b_rows, k, a_uns=False, b_uns=False, acc_in=None):
    """C (+)= A*B. a_cols[k] packs A[0..3][k] (byte i = row i); b_rows[k]
    packs B[k][0..3] (byte j = col j).  Returns 16 uint32 (row-major)."""
    def lane(w, i, uns):
        v = (w >> (8 * i)) & 0xFF
        return v if uns else (v - 256 if v & 0x80 else v)
    c = list(acc_in) if acc_in is not None else [0] * 16
    for kk in range(k):
        for i in range(4):
            for j in range(4):
                c[4 * i + j] += lane(a_cols[kk], i, a_uns) * lane(b_rows[kk], j, b_uns)
    return [x & M32 for x in c]


def te_cycles(k, wb):
    return 3 + 2 * k + (4 if wb else 0)
