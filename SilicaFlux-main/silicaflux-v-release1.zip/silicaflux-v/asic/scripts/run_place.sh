#!/usr/bin/env bash
# OpenROAD post-placement estimate on the netlist from run_asic.sh.
#   asic/scripts/run_place.sh <sky130hd|ihp_sg13g2>     env: OPENROAD, PLATFORMS
set -euo pipefail
cd "$(dirname "$0")/.."
CFG=$1; source configs/$CFG.cfg
export OUT=${2:-../build/asic/$CFG}
export SDC=$(pwd)/constraints/sfv_soc.sdc
export LEF_TECH LEF_STD LEF_MACROS LIB_STD LIB_MACROS SETRC SITE HOR_LAYER VER_LAYER STD_UTIL MACRO_HALO_UM TIELO CLK_PERIOD_NS
${OPENROAD:-openroad} -no_init -exit scripts/or_place.tcl > "$OUT/openroad.log" 2>&1 || { tail -30 "$OUT/openroad.log"; exit 1; }
grep -E "^SFV" "$OUT/openroad.log"
