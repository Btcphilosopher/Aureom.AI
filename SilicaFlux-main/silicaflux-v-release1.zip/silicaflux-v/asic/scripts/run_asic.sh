#!/usr/bin/env bash
# SilicaFlux-V ASIC baseline: Yosys synthesis + OpenSTA pre-layout timing/power
#   asic/scripts/run_asic.sh <sky130hd|ihp_sg13g2> [out_dir]
# env: PLATFORMS (ORFS flow/platforms dir), STA (OpenSTA binary), YOSYS,
#      CLK_PERIOD_NS (default 20), SOC_PARAMS ("-chparam SRAM_BANK_WORDS 2048 ...")
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT=..
CFG=$1
source configs/$CFG.cfg
OUT=${2:-$ROOT/build/asic/$CFG}
mkdir -p "$OUT"
YOSYS=${YOSYS:-yosys}
STA=${STA:-sta}
RTL=$(grep -v sfv_clkgate $ROOT/rtl/files.f | sed "s|^|$ROOT/|" | tr "\n" " ")
SRC="$RTL $TECH_DIR/sfv_clkgate.sv $TECH_DIR/sfv_sram_macro_bank.sv $ROOT/build/sfv_bootrom_image.sv"
PERIOD_PS=$(python3 -c "print(int(float('$CLK_PERIOD_NS')*1000))")
read -r TH_CELL TH_PORT <<< "$TIEHI"; read -r TL_CELL TL_PORT <<< "$TIELO"
read -r BUF_CELL BUF_I BUF_O <<< "$BUF"
MACRO_RD=""; MACRO_ST=""
for l in $LIB_MACROS; do MACRO_RD="$MACRO_RD read_liberty -lib $l;"; MACRO_ST="$MACRO_ST -liberty $l"; done

cat > "$OUT/synth.ys" <<YS
read_liberty -lib $LIB_STD
$MACRO_RD
read_verilog -sv -DSYNTHESIS -DSFV_SRAM_MACRO $SRC
hierarchy -check -top sfv_soc ${SOC_PARAMS:-}
synth -top sfv_soc -flatten
opt -purge
dfflibmap -liberty $LIB_STD
abc -liberty $LIB_STD -D $PERIOD_PS
opt_clean -purge
hilomap -singleton -hicell $TH_CELL $TH_PORT -locell $TL_CELL $TL_PORT
setundef -zero
insbuf -buf $BUF_CELL $BUF_I $BUF_O
opt_clean -purge
check -assert
tee -o $OUT/synth_stat.txt stat -liberty $LIB_STD $MACRO_ST
tee -o $OUT/latches.txt select -list t:*lat* t:\$dlatch t:\$_DLATCH*
write_verilog -noattr -noexpr -nohex -nodec $OUT/sfv_soc.netlist.v
YS
echo "[run_asic] yosys synthesis ($CFG, ${CLK_PERIOD_NS} ns)"
$YOSYS -l "$OUT/yosys.log" -q -s "$OUT/synth.ys"

cat > "$OUT/sta.tcl" <<TCL
read_liberty $LIB_STD
foreach l {$LIB_MACROS} { read_liberty \$l }
read_verilog $OUT/sfv_soc.netlist.v
link_design sfv_soc
read_sdc constraints/sfv_soc.sdc
report_checks -path_delay max -group_count 5 -fields {fanout cap slew} -digits 3 > $OUT/timing_max.rpt
report_checks -path_delay min -digits 3 > $OUT/timing_min.rpt
report_wns > $OUT/wns.rpt
report_tns > $OUT/tns.rpt
report_check_types -max_slew -max_capacitance -max_fanout -violators > $OUT/drv.rpt
set_power_activity -input -activity 0.1
report_power > $OUT/power.rpt
exit
TCL
echo "[run_asic] OpenSTA pre-layout timing/power"
CLK_PERIOD_NS=$CLK_PERIOD_NS $STA -no_splash -exit "$OUT/sta.tcl" > "$OUT/sta.log" 2>&1 || { tail -20 "$OUT/sta.log"; exit 1; }
python3 $ROOT/scripts/asic_summary.py "$OUT" "$CFG" "$CLK_PERIOD_NS" | tee "$OUT/summary.md"
