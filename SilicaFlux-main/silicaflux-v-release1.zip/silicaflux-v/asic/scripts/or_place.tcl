# =============================================================================
# SilicaFlux-V OpenROAD physical estimate: floorplan -> macro grid placement ->
# global placement -> parasitic estimate -> repair_design/repair_timing ->
# reports.  No CTS/routing (ideal clocks): numbers are POST-PLACEMENT ESTIMATES.
# env: OUT LEF_TECH LEF_STD LEF_MACROS LIB_STD LIB_MACROS SETRC SITE
#      CLK_PERIOD_NS HOR_LAYER VER_LAYER STD_UTIL MACRO_HALO_UM
# =============================================================================
set out $::env(OUT)
read_lef $::env(LEF_TECH)
read_lef $::env(LEF_STD)
foreach l $::env(LEF_MACROS) { read_lef $l }
read_liberty $::env(LIB_STD)
foreach l $::env(LIB_MACROS) { read_liberty $l }
read_verilog $out/sfv_soc.netlist.v
link_design sfv_soc
read_sdc $::env(SDC)
source $::env(SETRC)

set block [ord::get_db_block]
set dbu [[ord::get_db_tech] getDbUnitsPerMicron]
set macros {}
set marea 0.0; set sarea 0.0; set maxh 0.0
foreach inst [$block getInsts] {
  set m [$inst getMaster]
  set w [expr {[$m getWidth] / double($dbu)}]; set h [expr {[$m getHeight] / double($dbu)}]
  if {[$m isBlock]} { lappend macros $inst; set marea [expr {$marea + $w*$h}]
                      if {$h > $maxh} {set maxh $h} } else { set sarea [expr {$sarea + $w*$h}] }
}
set halo $::env(MACRO_HALO_UM)
set util $::env(STD_UTIL)
# square core sized for macros (+halo) and std cells at the target utilisation
set side [expr {sqrt($marea * 1.25 + $sarea / $util)}]
set margin 40.0
set die [expr {$side + 2*$margin}]
initialize_floorplan -die_area "0 0 $die $die" -core_area "$margin $margin [expr {$die-$margin}] [expr {$die-$margin}]" -site $::env(SITE)
make_tracks
place_pins -hor_layers $::env(HOR_LAYER) -ver_layers $::env(VER_LAYER)

# deterministic grid placement of the SRAM macros from the lower-left corner
set x [expr {$margin + $halo}]; set y [expr {$margin + $halo}]; set rowh 0.0
set urx [expr {$die - $margin}]
foreach inst $macros {
  set m [$inst getMaster]
  set w [expr {[$m getWidth] / double($dbu)}]; set h [expr {[$m getHeight] / double($dbu)}]
  if {$x + $w + $halo > $urx} { set x [expr {$margin + $halo}]; set y [expr {$y + $rowh + 2*$halo}]; set rowh 0.0 }
  $inst setLocation [expr {int($x*$dbu)}] [expr {int($y*$dbu)}]
  $inst setOrient R0
  $inst setPlacementStatus FIRM
  set x [expr {$x + $w + 2*$halo}]
  if {$h > $rowh} { set rowh $h }
}
puts "SFV: die ${die}x${die} um, macros [llength $macros] area [format %.0f $marea] um2, std [format %.0f $sarea] um2"

global_placement -density [expr {$util + 0.1}] -skip_io
estimate_parasitics -placement
puts "SFV_AREA_PRE"; report_design_area
repair_design
repair_tie_fanout -separation 5 [lindex $::env(TIELO) 0]/[lindex $::env(TIELO) 1]
repair_timing -setup -setup_margin 0.0 -max_passes 10
estimate_parasitics -placement
puts "SFV_AREA_POST"; report_design_area
report_checks -path_delay max -path_group clk -digits 3 -fields {fanout cap slew} > $out/or_timing_clk.rpt
report_checks -path_delay max -path_group asynchronous -digits 3 > $out/or_timing_async.rpt
report_checks -path_delay min -path_group clk -digits 3 > $out/or_timing_hold.rpt
report_worst_slack -max > $out/or_wns.rpt
report_worst_slack -min > $out/or_whs.rpt
report_tns > $out/or_tns.rpt
report_check_types -max_slew -max_capacitance -max_fanout -violators > $out/or_drv.rpt
set_power_activity -input -activity 0.1
report_power > $out/or_power.rpt
puts "SFV_DIE_UM $die"
write_def $out/sfv_soc_placed.def
exit
