// =============================================================================
// SilicaFlux-V FPGA prototype top -- Radiona ULX3S (Lattice ECP5 LFE5U-85F)
//
//   clk_25mhz   25 MHz oscillator used directly as the SoC clock (no PLL:
//               removes a vendor-IP dependency; Fmax is reported by nextpnr)
//   btn[1]      reset (active high on ULX3S); a power-on counter also resets
//   btn[3:2]    boot straps, inverted so that no button = mode 2 (POST):
//               none: POST  | btn2: SRAM/3 | btn3: SPI/0 | both: JTAG/1
//   ftdi_*      UART console on the on-board FT231X (115200 8N1)
//   gp/gn[0..3] JTAG (TCK TMS TDI TDO) for an external adapter
//   gp/gn[4..5] SPI flash PMOD (SCK MOSI / MISO CS#) for boot mode 0
//   led[7:0]    {pass, fail, test_pass, test_fail, sleep, heartbeat[2:0]}
// gpio[5] is looped back from gpio[4] here (as on the test board model),
// gpio[7:6] drive the pass/fail LEDs.
// =============================================================================
`default_nettype none

module sfv_ulx3s_top (
  input  wire logic       clk_25mhz,
  input  wire logic [6:0] btn,
  output logic [7:0]      led,
  output logic            ftdi_rxd,     // FPGA -> host
  input  wire logic       ftdi_txd,     // host -> FPGA
  input  wire logic       jtag_tck,
  input  wire logic       jtag_tms,
  input  wire logic       jtag_tdi,
  output logic            jtag_tdo,
  output logic            spi_sck,
  output logic            spi_mosi,
  input  wire logic       spi_miso,
  output logic            spi_csn,
  output logic            wifi_gpio0    // keep ESP32 from resetting the board
);
  assign wifi_gpio0 = 1'b1;
  wire clk = clk_25mhz;

  logic [3:0] por_cnt = 4'd0;
  always_ff @(posedge clk) if (por_cnt != 4'hF) por_cnt <= por_cnt + 4'd1;
  wire rst_n = (por_cnt == 4'hF) && !btn[1];

  logic [7:0]  gpio_i, gpio_o, gpio_oe;
  logic        test_pass, test_fail, cpu_sleep, tdo_oe, tdo;
  logic [31:0] test_status;

  // straps = 2'b10 ^ {btn3, btn2}: none -> 2 POST, btn2 -> 3 SRAM,
  // btn3 -> 0 SPI, both -> 1 JTAG
  always_comb begin
    gpio_i      = gpio_oe & gpio_o;
    gpio_i[1:0] = 2'b10 ^ {btn[3], btn[2]};
    gpio_i[5]   = gpio_o[4];
  end

  sfv_soc #(.UART_BAUD_RESET(16'd217)) u_soc (
    .clk, .rst_ni(rst_n), .test_mode(1'b0),
    .tck(jtag_tck), .tms(jtag_tms), .tdi(jtag_tdi), .tdo, .tdo_oe,
    .uart_tx(ftdi_rxd), .uart_rx(ftdi_txd),
    .spi_sck, .spi_mosi, .spi_miso, .spi_cs0_n(spi_csn),
    .gpio_i, .gpio_o, .gpio_oe,
    .test_pass, .test_fail, .test_status, .cpu_sleep
  );
  assign jtag_tdo = tdo_oe ? tdo : 1'b1;

  logic [24:0] hb;
  always_ff @(posedge clk) hb <= hb + 25'd1;
  assign led = {gpio_o[7], gpio_o[6], test_pass, test_fail, cpu_sleep, hb[24:22]};
  wire unused_ok = ^{btn[0], btn[6:4], test_status};
endmodule

`default_nettype wire
