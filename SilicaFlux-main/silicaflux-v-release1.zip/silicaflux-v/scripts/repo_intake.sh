#!/usr/bin/env bash
# Forensic intake: compile/lint/elaborate every SilicaFlux RTL candidate and run
# its shipped testbench.  Usage: intake_run.sh <intake_dir> <out_dir>
set -u
I=$1; O=$2; mkdir -p "$O"; : > "$O/summary.tsv"
log(){ printf "%s\t%s\t%s\t%s\n" "$1" "$2" "$3" "$4" >> "$O/summary.tsv"; }

# check <name> <top|-> <tbtop|-> <files...>
check() {
  local name=$1 top=$2 tbtop=$3; shift 3
  local rtl=() tb=()
  for f in "$@"; do case "$f" in TB:*) tb+=("${f#TB:}");; *) rtl+=("$f");; esac; done
  local L="$O/$name"; mkdir -p "$L"
  # 1. Icarus elaboration of RTL only
  if timeout 120 iverilog -g2012 -o /dev/null $( [ "$top" != - ] && echo -s $top) "${rtl[@]}" > "$L/iverilog_rtl.log" 2>&1; then r1=PASS; else r1="FAIL($(grep -ciE 'error' "$L/iverilog_rtl.log") err)"; fi
  # 2. Verilator lint
  local vt=""; [ "$top" != - ] && vt="--top-module $top"
  if timeout 300 verilator --lint-only -Wall -Wno-fatal $vt "${rtl[@]}" > "$L/verilator.log" 2>&1; then
     r2="PASS($(grep -c '%Warning' "$L/verilator.log") warn)"; else r2="FAIL($(grep -c '%Error' "$L/verilator.log") err)"; fi
  # 3. Yosys elaboration + latch check
  local yt="-auto-top"; [ "$top" != - ] && yt="-top $top"
  if timeout 600 yosys -q -p "read_verilog -sv ${rtl[*]}; hierarchy $yt; proc; opt_clean; select -list t:\$dlatch t:\$adlatch t:\$dlatchsr; stat" > "$L/yosys.log" 2>&1; then
     r3="PASS(latch=$(grep -cE '\$(ad)?latch' "$L/yosys.log"))"; else r3="FAIL"; fi
  # 4. Testbench
  r4=NA
  if [ "$tbtop" != - ]; then
    if timeout 120 iverilog -g2012 -s "$tbtop" -o "$L/tb.vvp" "${rtl[@]}" "${tb[@]}" > "$L/tb_compile.log" 2>&1; then
      (cd "$L" && timeout 300 vvp -n tb.vvp > "$L/tb_run.log" 2>&1); rc=$?
      np=$(grep -ciE '\bPASS' "$L/tb_run.log"); nf=$(grep -ciE '\bFAIL|ERROR|mismatch' "$L/tb_run.log")
      r4="RAN(rc=$rc,pass~$np,fail~$nf)"
    else r4="TB_COMPILE_FAIL($(grep -ciE 'error' "$L/tb_compile.log") err)"; fi
  fi
  log "$name" "icarus=$r1" "verilator=$r2 yosys=$r3" "tb=$r4"
  echo "$name | $r1 | $r2 | $r3 | $r4"
}

cd "$I"
R=riscv_cpu
check rv32i_core rv32i_core rv32i_tb $R/rv32i_pkg.sv $R/alu.sv $R/regfile.sv $R/imm_gen.sv $R/control.sv $R/alu_control.sv $R/hazard_unit.sv $R/instr_mem.sv $R/data_mem.sv $R/rv32i_core.sv TB:$R/rv32i_tb.sv
C=cpu_core/cpu_core
check cpu_core cpu_top tb_cpu_top $C/rtl/cpu_pkg.sv $C/rtl/alu.sv $C/rtl/register_file.sv $C/rtl/hazard_unit.sv $C/rtl/forward_unit.sv $C/rtl/instr_mem.sv $C/rtl/data_mem.sv $C/rtl/cpu_core.sv $C/rtl/cpu_top.sv TB:$C/tb/cpu_scoreboard.sv TB:$C/tb/instr_gen.sv TB:$C/tb/tb_cpu_top.sv
P=pipelined_cpu/pipelined_cpu/rtl
check pipelined_cpu cpu_top cpu_tb $P/cpu_pkg.sv $P/register_file.sv $P/alu.sv $P/memories.sv $P/if_stage.sv $P/id_stage.sv $P/ex_stage.sv $P/mem_stage.sv $P/wb_stage.sv $P/pipeline_regs.sv $P/hazard_unit.sv $P/forwarding_unit.sv $P/cpu_top.sv TB:pipelined_cpu/pipelined_cpu/tb/cpu_tb.sv
S=sf_v1/silicaflux/rtl; ST=sf_v1/silicaflux/tb
SFV1=($S/silicaflux_pkg.sv $S/alu.sv $S/forwarding_unit.sv $S/fetch_unit.sv $S/decoder.sv $S/register_bank.sv $S/vector_engine.sv $S/tensor_unit.sv $S/memory_controller.sv $S/control_core.sv $S/scheduler.sv $S/compute_tile.sv $S/noc_router.sv $S/noc_interconnect.sv $S/tile_interface.sv $S/silicaflux_top.sv)
check sf_v1_top silicaflux_top tb_silicaflux_top "${SFV1[@]}" TB:$ST/tb_silicaflux_top.sv
check sf_v1_vector vector_engine tb_vector_engine $S/silicaflux_pkg.sv $S/vector_engine.sv TB:$ST/tb_vector_engine.sv
check sf_v1_tensor tensor_unit tb_tensor_unit $S/silicaflux_pkg.sv $S/tensor_unit.sv TB:$ST/tb_tensor_unit.sv
check sf_v1_memctrl memory_controller tb_memory_controller $S/silicaflux_pkg.sv $S/memory_controller.sv TB:$ST/tb_memory_controller.sv
check sf_v1_sched scheduler tb_scheduler $S/silicaflux_pkg.sv $S/scheduler.sv TB:$ST/tb_scheduler.sv
check sf_v1_noc noc_interconnect tb_noc_interconnect $S/silicaflux_pkg.sv $S/noc_router.sv $S/noc_interconnect.sv TB:$ST/tb_noc_interconnect.sv
check sf_v1_tile compute_tile tb_compute_tile $S/silicaflux_pkg.sv $S/vector_engine.sv $S/tensor_unit.sv $S/memory_controller.sv $S/compute_tile.sv TB:$ST/tb_compute_tile.sv
# SilicaFlux 2.5 .sf sources (SystemVerilog-2017 with .sf extension)
F=sf25
for m in "alu (1)" vector_engine tile_interface noc_interconnect register_bank memory_controller scheduler compute_tile silicaflux_top forwarding_unit sram-decoder; do
  check "sf25_${m// /_}" - - $F/"silicaflux_pkg (1).sf" "$F/$m.sf" 2>/dev/null
done
T=sf_top
for m in alu decoder fetch_unit forwarding_unit memory_controller "register_bank (1)" tensor_unit "vector_engine (1)"; do
  check "sftop_${m// /_}" - - $T/silicaflux_pkg.sf $T/sf_frontend_pkg.sf "$T/$m.sf"
done
check sftop_tensor_tb tensor_unit tb_tensor_unit $T/tensor_unit.sf TB:$T/tb_tensor_unit.sf
check sf25_vector_tb vector_engine tb_vector_engine $F/vector_engine.sf TB:$F/tb_vector_engine.sf
Q=soc_integration/soc_integration
check soc_integration soc_top tb_soc_top $Q/rtl/soc_pkg.sv $Q/rtl/bus/soc_bus_if.sv $Q/rtl/bus/soc_fabric.sv $Q/rtl/peripherals/soc_irq_ctrl.sv $Q/rtl/peripherals/soc_uart.sv $Q/rtl/peripherals/soc_gpio.sv $Q/rtl/peripherals/soc_timer.sv $Q/rtl/cpu/cpu_if_adapter.sv $Q/rtl/memory/soc_sram.sv $Q/rtl/memory/boot_rom.sv $Q/rtl/soc_top.sv TB:$Q/tb/models/uart_mon.sv TB:$Q/tb/models/cpu_bfm.sv TB:$Q/tb/tb_soc_top.sv
K=comm_protocols/comm_protocols/rtl; KT=comm_protocols/comm_protocols/tb
check uart uart_top uart_tb $K/uart/uart_tx.sv $K/uart/uart_rx.sv $K/uart/uart_top.sv TB:$KT/uart_tb.sv
check spi spi_top spi_tb $K/spi/spi_master.sv $K/spi/spi_slave.sv $K/spi/spi_top.sv TB:$KT/spi_tb.sv
M=memory_cache/memory_cache_repo/rtl
check sp_ram sp_ram tb_sp_ram $M/mem_pkg.sv $M/sp_ram.sv TB:memory_cache/memory_cache_repo/tb/tb_sp_ram.sv
check dp_ram dp_ram tb_dp_ram $M/mem_pkg.sv $M/dp_ram.sv TB:memory_cache/memory_cache_repo/tb/tb_dp_ram.sv
X=testcore/silicaflux-testcore/rtl
check testcore - - $(sed "s|^|$X/|" $X/rtl_files.f | grep -v '^\s*$' | grep -v '#' | tr '\n' ' ')
check tc_tap tc_tap tb_tap_fsm $X/tc_pkg.sv $X/tc_spec_pkg.sv $X/tc_tap.sv TB:testcore/silicaflux-testcore/tb/tb_tap_fsm.sv
A=sf_ai/silicaflux-ai/rtl
check sfx_systolic sfx_systolic_array tb_sfx_systolic_array_4x4 $(ls $A/common/*.sv $A/arithmetic/*.sv $A/tensor/*.sv 2>/dev/null) TB:sf_ai/silicaflux-ai/tb/unit/tb_sfx_systolic_array_4x4.sv
W=memoryflow2/silicaflux-memoryflow/rtl
check mf_sram sf_sram_1rw - $W/sram/sf_sram_1rw_inferred.sv $W/sram/sf_sram_1rw.sv
check mf_mbist sf_mbist_march - $(ls $W/mbist/*.sv)
check mf_vec sf_vec_unit - $(ls $W/common/*.sv) $W/accel/sf_vec_unit.sv
check mf_tensor sf_tensor_array - $(ls $W/common/*.sv) $W/accel/sf_tensor_array.sv
PL=powerlink/silicaflux-powerlink/rtl
check pl_rstclk sf_rst_clk_ctrl tb_sf_rst_clk_ctrl $PL/sf_pwr_pkg.sv $PL/sf_sync.sv $PL/sf_rst_clk_ctrl.sv TB:$PL/tb/tb_sf_rst_clk_ctrl.sv
echo DONE
