#!/usr/bin/env bash
# Lint and elaboration checks for the synthesizable hierarchy.
#  1. Verilator --lint-only -Wall over the full SoC: errors must be 0;
#     warnings are counted by class and reviewed (docs/VERIFICATION_REPORT.md).
#  2. Yosys 0.33 elaboration of sfv_soc (proc + flatten): must succeed;
#     latches are listed and must be exactly the ICG enable latches.
set -uo pipefail
cd "$(dirname "$0")/.."
OUT=reports/lint; mkdir -p "$OUT"
FILES="$(cat rtl/files.f | tr '\n' ' ') build/sfv_bootrom_image.sv"
verilator --lint-only -Wall --top-module sfv_soc $FILES > "$OUT/verilator_lint.log" 2>&1
nerr=$(grep -c '^%Error' "$OUT/verilator_lint.log" | grep -v Exiting || true)
nerr=$(grep '^%Error' "$OUT/verilator_lint.log" | grep -vc 'Exiting due to' || true)
{
  echo "# Verilator $(verilator --version | awk '{print $2}') lint -Wall, top sfv_soc"
  echo "errors: $nerr"
  echo "warnings by class:"
  grep -oE '^%Warning-[A-Z]+' "$OUT/verilator_lint.log" | sort | uniq -c | sort -rn
} > "$OUT/verilator_summary.txt"
yosys -p "read_verilog -sv $FILES; hierarchy -check -top sfv_soc; proc; flatten; opt -purge; \
  tee -o $OUT/yosys_latches.txt select -list t:\$dlatch t:\$adlatch t:\$dlatchsr; stat" \
  > "$OUT/yosys_elab.log" 2>&1; yrc=$?
nlat=$(grep -c 'dlatch' "$OUT/yosys_latches.txt" || true)
nbad=$(grep 'dlatch' "$OUT/yosys_latches.txt" | grep -vc 'u_cg_' || true)
{
  echo "# Yosys $(yosys -V | awk '{print $2}') elaboration of sfv_soc"
  echo "exit code: $yrc"
  echo "latches inferred: $nlat (unintended: $nbad)"
  cat "$OUT/yosys_latches.txt"
  grep -E 'Number of cells' "$OUT/yosys_elab.log" | tail -1
} > "$OUT/yosys_summary.txt"
python3 scripts/check_map.py > "$OUT/memory_map_check.txt"; mrc=$?
cat "$OUT/verilator_summary.txt" "$OUT/yosys_summary.txt" "$OUT/memory_map_check.txt"
[ "$nerr" = 0 ] && [ $yrc = 0 ] && [ "$nbad" = 0 ] && [ $mrc = 0 ]
