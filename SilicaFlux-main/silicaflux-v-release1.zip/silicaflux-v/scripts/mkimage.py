#!/usr/bin/env python3
"""Wrap an application binary into a SilicaFlux-V SPI-flash boot image.

    mkimage.py <app.bin> <load_addr> <entry> <out.bin> [--hex out.hex]

Header (5 little-endian words): magic "SFVI", load, length, entry, check.
check = rotate-left-1-then-xor over payload words (must match bootrom.c).
This is an integrity check against transfer errors, not an authentication.
"""
import argparse, struct

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bin"); ap.add_argument("load", type=lambda x: int(x, 0))
    ap.add_argument("entry", type=lambda x: int(x, 0)); ap.add_argument("out")
    ap.add_argument("--hex")
    a = ap.parse_args()
    p = open(a.bin, "rb").read()
    p += b"\0" * ((-len(p)) % 4)
    c = 0
    for (w,) in struct.iter_unpack("<I", p):
        c = (((c << 1) | (c >> 31)) & 0xFFFFFFFF) ^ w
    img = struct.pack("<5I", 0x49564653, a.load, len(p), a.entry, c) + p
    open(a.out, "wb").write(img)
    if a.hex:   # byte-per-line for the SPI flash simulation model
        with open(a.hex, "w") as f:
            for b in img:
                f.write(f"{b:02x}\n")
    print(f"mkimage: payload {len(p)} bytes, check 0x{c:08x}")

if __name__ == "__main__":
    main()
