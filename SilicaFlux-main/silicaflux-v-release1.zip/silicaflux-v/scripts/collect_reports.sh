#!/usr/bin/env bash
# Copy tool outputs from build/ into reports/ (the release evidence set).
set -uo pipefail
cd "$(dirname "$0")/.."
for d in build/asic/*/; do
  n=$(basename "$d"); o=reports/synth/$n; mkdir -p "$o"
  for f in summary.md summary.json synth_stat.txt latches.txt synth.ys wns.rpt tns.rpt timing_max.rpt \
           or_timing_clk.rpt or_timing_async.rpt or_timing_hold.rpt or_wns.rpt or_whs.rpt or_tns.rpt \
           or_drv.rpt or_power.rpt power.rpt; do
    [ -f "$d/$f" ] && cp "$d/$f" "$o/"
  done
  [ -f "$d/openroad.log" ] && grep -E "^SFV|RSZ-00|GPL-0|Design area|utilization" "$d/openroad.log" > "$o/openroad_key.log"
  [ -f "$d/yosys.log" ] && grep -iE "warning|error" "$d/yosys.log" | sort | uniq -c | sort -rn | head -40 > "$o/yosys_warnings.txt"
  [ -f "$d/sfv_soc.netlist.v" ] && gzip -c "$d/sfv_soc.netlist.v" > "$o/sfv_soc.netlist.v.gz"
done
mkdir -p reports/fpga
cp build/fpga/yosys_stat.txt reports/fpga/ 2>/dev/null
grep -E "Max frequency|Device utilisation|TRELLIS_|DP16KD|MULT18|EHXPLL|Info: Program finished|Warning" build/fpga/nextpnr.log > reports/fpga/nextpnr_key.log 2>/dev/null
cp build/fpga/nextpnr_report.json reports/fpga/ 2>/dev/null
[ -f build/fpga/sfv_ulx3s.bit ] && cp build/fpga/sfv_ulx3s.bit reports/fpga/ && sha256sum build/fpga/sfv_ulx3s.bit > reports/fpga/sfv_ulx3s.bit.sha256
mkdir -p reports/firmware
cp build/fw/bootrom.bin build/fw/app.bin build/fw/app_flash.bin build/fw/app_flash.hex build/fw/app_sram.hex reports/firmware/ 2>/dev/null
cp build/sfv_bootrom_image.sv reports/firmware/ 2>/dev/null
llvm-size build/fw/bootrom.elf build/fw/app.elf > reports/firmware/sizes.txt 2>/dev/null
cp build/soc/logs/*.uart.log reports/sim/ 2>/dev/null
echo "collected"
