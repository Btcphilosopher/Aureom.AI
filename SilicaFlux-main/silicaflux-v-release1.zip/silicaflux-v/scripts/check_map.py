#!/usr/bin/env python3
"""Cross-check the memory map shared by RTL (rtl/pkg/sfv_pkg.sv) and firmware
(firmware/common/sfv_map.h).  Exit 1 on any mismatch."""
import re, sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
pkg = (root / "rtl/pkg/sfv_pkg.sv").read_text()
hdr = (root / "firmware/common/sfv_map.h").read_text()

def sv(name):
    m = re.search(rf"localparam\s+(?:logic\s*\[[^\]]*\]|int)\s+{name}\s*=\s*(?:32'h([0-9A-Fa-f_]+)|(\d+))", pkg)
    return int(m.group(1).replace("_", ""), 16) if m.group(1) else int(m.group(2))

def c(name):
    m = re.search(rf"#define\s+{name}\s+\(?(0x[0-9A-Fa-f]+|\d+)u?", hdr)
    return int(m.group(1), 0)

pages = {"PG_SYSCTRL": "SFV_SYSCTRL", "PG_INTC": "SFV_INTC", "PG_TIMER": "SFV_TIMER",
         "PG_UART": "SFV_UART", "PG_SPI": "SFV_SPI", "PG_GPIO": "SFV_GPIO",
         "PG_VE": "SFV_VE", "PG_TE": "SFV_TE"}
checks = [("ROM_BASE", "SFV_ROM_BASE"), ("SRAM_BASE", "SFV_SRAM_BASE"),
          ("TSPM_BASE", "SFV_TSPM_BASE"), ("PERIPH_BASE", "SFV_PERIPH_BASE")]
bad = 0
for s, h in checks:
    if sv(s) != c(h):
        print(f"MISMATCH {s}={sv(s):#x} vs {h}={c(h):#x}"); bad += 1
for s, h in pages.items():
    a = sv("PERIPH_BASE") + (sv(s) << 12)
    if a != c(h):
        print(f"MISMATCH page {s}: {a:#x} vs {h}={c(h):#x}"); bad += 1
if sv("CHIP_ID") != c("SFV_CHIP_ID_VAL"):
    print("MISMATCH CHIP_ID"); bad += 1
irqs = ["UART", "SPI", "GPIO", "VE", "TE", "MBIST", "BUSERR", "DBG"]
for n in irqs:
    if sv(f"IRQ_{n}") != c(f"IRQ_{n}"):
        print(f"MISMATCH IRQ_{n}"); bad += 1
print("check_map:", "OK" if not bad else f"{bad} mismatches",
      f"({len(checks) + len(pages) + 1 + len(irqs)} items)")
sys.exit(1 if bad else 0)
