#!/usr/bin/env python3
"""Convert a flat little-endian binary image to a word-per-line hex file for
$readmemh / Verilator, optionally padding to a fixed number of words.

usage: bin2hex.py <in.bin> <out.hex> [--words N]
"""
import argparse
import struct
import sys


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("inp")
    ap.add_argument("out")
    ap.add_argument("--words", type=int, default=0, help="pad/limit to N words")
    a = ap.parse_args()
    data = open(a.inp, "rb").read()
    if len(data) % 4:
        data += b"\0" * (4 - len(data) % 4)
    words = list(struct.unpack("<%dI" % (len(data) // 4), data))
    if a.words:
        if len(words) > a.words:
            print(f"error: image {len(words)} words exceeds {a.words}", file=sys.stderr)
            return 1
        words += [0] * (a.words - len(words))
    with open(a.out, "w") as f:
        for w in words:
            f.write(f"{w:08x}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
