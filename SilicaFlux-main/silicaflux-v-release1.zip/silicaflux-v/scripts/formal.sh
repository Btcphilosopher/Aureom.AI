#!/usr/bin/env bash
# SymbiYosys formal checks (ABC PDR / BMC3 engines; z3 only for smtbmc tasks).
set -uo pipefail
cd "$(dirname "$0")/../formal"
OUT=../reports/formal; mkdir -p "$OUT"; R="$OUT/formal_summary.txt"; : > "$R"
fail=0
for job in "fv_xbar.sby prove" "fv_xbar.sby bmc" "fv_fifo.sby" "fv_tap.sby" "fv_cpu_bus.sby bmc"; do
  res=$(timeout ${FORMAL_TIMEOUT:-1200} sby -f $job 2>&1 | grep -E "DONE" | tail -1)
  printf "%-22s %s\n" "$job" "${res:-TIMEOUT}" | tee -a "$R"
  case "$res" in *PASS*) ;; *) fail=1;; esac
done
exit $fail
