#!/usr/bin/env python3
"""Summarise a SilicaFlux-V ASIC baseline run.

    asic_summary.py <run_dir> <cfg> <clk_period_ns> [macro.lib ...]

Sources: Yosys `stat -liberty` (synth_stat.txt), macro liberty `area`,
OpenROAD post-placement reports (or_*.rpt, openroad.log).  Every number is
copied from a tool report, except rows marked DERIVED.
"""
import json
import math
import re
import sys
from pathlib import Path

out, cfg, period = Path(sys.argv[1]), sys.argv[2], float(sys.argv[3])
libs = sys.argv[4:]


def rd(name):
    p = out / name
    return p.read_text(errors="ignore") if p.exists() else ""


stat = rd("synth_stat.txt")
cells = {m.group(1): int(m.group(2)) for m in re.finditer(r"^\s+(\S+)\s+(\d+)\s*$", stat, re.M)}
ncell = int(re.search(r"Number of cells:\s+(\d+)", stat).group(1))
chip = float(re.search(r"Chip area for (?:top )?module '\\?sfv_soc':\s+([\d.]+)", stat).group(1))
marea = {}
for lib in libs:
    t = Path(lib).read_text(errors="ignore")
    for m in re.finditer(r"cell\s*\(\s*\"?(\w+)\"?\s*\)", t):
        a = re.search(r"\barea\s*:\s*([\d.]+)", t[m.end():m.end() + 4000])
        if a:
            marea[m.group(1)] = float(a.group(1))
macros = {k: v for k, v in cells.items() if k in marea}
macro_area = sum(marea[k] * v for k, v in macros.items())
std_area = chip - macro_area
ff = sum(v for k, v in cells.items() if re.search(r"__(dfr|dfs|dfx|dfb|dfrt|edf|sdf)|sg13g2_(dfr|sdf|dll)", k))
icg = sum(v for k, v in cells.items() if "clkp" in k or "lgcp" in k)


def num(pat, txt, cast=float):
    m = re.search(pat, txt, re.M)
    return cast(m.group(1)) if m else None


orlog = rd("openroad.log")
die_um = num(r"SFV_DIE_UM ([\d.]+)", orlog)
area_rpt = orlog.split("SFV_AREA_POST")[-1] if "SFV_AREA_POST" in orlog else ""
design_area = num(r"Design area ([\d.]+) u\^2", area_rpt)
util = num(r"([\d.]+)% utilization", area_rpt)
wns = num(r"worst slack\s+(-?[\d.]+)", rd("or_wns.rpt")) or num(r"(-?[\d.]+)", rd("or_wns.rpt"))
whs = num(r"worst slack\s+(-?[\d.]+)", rd("or_whs.rpt")) or num(r"(-?[\d.]+)", rd("or_whs.rpt"))
tns = num(r"tns\s+(-?[\d.]+)", rd("or_tns.rpt"))
tclk = rd("or_timing_clk.rpt")
sp = num(r"Startpoint: (\S+)", tclk, str)
ep = num(r"Endpoint: (\S+)", tclk, str)
slack_clk = num(r"^\s*(-?[\d.]+)\s+slack", tclk)
slack_async = num(r"^\s*(-?[\d.]+)\s+slack", rd("or_timing_async.rpt"))
pw = rd("or_power.rpt")
tot = re.search(r"^Total\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)", pw, re.M)
fmax = 1000.0 / (period - slack_clk) if slack_clk is not None else None   # achievable reg-to-reg estimate

res = dict(pdk=cfg, clk_period_ns=period, synth_cells_total=ncell, synth_std_cells=ncell - sum(macros.values()),
           synth_flops=ff, synth_icg=icg, synth_std_area_um2=round(std_area, 1),
           macro_area_um2=round(macro_area, 1), macros=macros, macro_unit_area_um2=marea,
           placed_design_area_um2=design_area, placed_utilisation_pct=util, die_side_um=die_um,
           die_area_mm2=round((die_um / 1000.0) ** 2, 3) if die_um else None,
           wns_ns=wns, tns_ns=tns, worst_hold_ns=whs, reg2reg_slack_ns=slack_clk,
           recovery_slack_ns=slack_async, critical_start=sp, critical_end=ep,
           fmax_est_mhz=round(fmax, 1) if fmax else None,
           power_w=dict(internal=float(tot.group(1)), switching=float(tot.group(2)),
                        leakage=float(tot.group(3)), total=float(tot.group(4))) if tot else None)
(out / "summary.json").write_text(json.dumps(res, indent=2))

L = [f"## ASIC baseline: {cfg} @ {period:g} ns ({1000/period:.0f} MHz), typical corner\n",
     "Synthesis: Yosys. Physical estimate: OpenROAD floorplan + macro placement + global",
     "placement + repair_design/repair_timing, placement-estimated wire RC, ideal clocks",
     "(no CTS, no routing): post-placement ESTIMATES, not signoff.\n",
     "| metric | value | source |", "|---|---|---|",
     f"| synthesized cells (total / std / flops / ICG) | {ncell} / {ncell - sum(macros.values())} / {ff} / {icg} | Yosys stat |",
     f"| standard-cell area (synthesis) | {std_area/1e6:.4f} mm² | Yosys stat -liberty |",
     f"| SRAM macro area | {macro_area/1e6:.3f} mm² | liberty area × count |"]
for k, v in macros.items():
    L.append(f"| macro {k} | {v} × {marea[k]/1e6:.4f} mm² | Yosys stat + liberty |")
if design_area:
    L.append(f"| placed design area (after repair) / core util. | {design_area/1e6:.3f} mm² / {util}% | OpenROAD report_design_area |")
if die_um:
    L.append(f"| die (floorplan used) | {die_um/1000:.3f} × {die_um/1000:.3f} mm = {(die_um/1000)**2:.2f} mm² | OpenROAD floorplan (core sized by script) |")
L.append(f"| reg-to-reg worst slack | {slack_clk} ns ({sp} → {ep}) | OpenROAD/OpenSTA |")
L.append(f"| reset recovery worst slack | {slack_async} ns | OpenROAD/OpenSTA |")
L.append(f"| WNS / TNS (all groups) | {wns} / {tns} ns | OpenROAD/OpenSTA |")
L.append(f"| worst hold slack (ideal clocks) | {whs} ns | OpenROAD/OpenSTA |")
if fmax:
    L.append(f"| estimated Fmax (reg-to-reg) | {fmax:.1f} MHz | DERIVED 1/(T − slack), ideal clocks, typical corner |")
if tot:
    p = res["power_w"]
    L.append(f"| power int / switch / leak / total | {p['internal']*1e3:.2f} / {p['switching']*1e3:.2f} / "
             f"{p['leakage']*1e3:.3f} / {p['total']*1e3:.2f} mW | OpenSTA, 10% input toggle, @{1000/period:.0f} MHz |")
print("\n".join(L))
