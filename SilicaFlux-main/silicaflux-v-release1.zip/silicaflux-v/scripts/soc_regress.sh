#!/usr/bin/env bash
# End-to-end firmware regression on the Verilator SoC model.
set -uo pipefail
cd "$(dirname "$0")/.."
SIM=${SIM:-build/soc/obj/vtb_soc}
OUT=reports/sim; mkdir -p "$OUT" build/soc/logs
R="$OUT/soc_regression.txt"; : > "$R"
run() {   # name, args...
  local n=$1; shift
  local line
  line=$("$SIM" "$@" +log=build/soc/logs/$n.uart.log 2>&1 | tee build/soc/logs/$n.sim.log | grep 'TB_SOC RESULT')
  printf "%-26s %s\n" "$n" "$line" | tee -a "$R"
  case "$line" in *PASS*) return 0;; *) return 1;; esac
}
fail=0
run spi_flash_boot_app   +boot=0 +flash=build/fw/app_flash.hex || fail=1
run jtag_load_boot_app   +boot=1 +jtag=1 +sram=build/fw/app_sram.hex || fail=1
run rom_post_selftest    +boot=2 || fail=1
run sram_direct_boot_app +boot=3 +sram=build/fw/app_sram.hex || fail=1
run mbist_fault_detect   +boot=2 +fault_bank=2 +fault_addr=4660 +fault_bit=13 +fault_val=1 +expect_fail=1 || fail=1
run mbist_fault_bank0    +boot=2 +fault_bank=0 +fault_addr=8191 +fault_bit=0 +fault_val=0 +expect_fail=1 || fail=1
grep -h "SFV-APP PHASE1\|SFV-APP RESULT" build/soc/logs/spi_flash_boot_app.uart.log >> "$R"
exit $fail
