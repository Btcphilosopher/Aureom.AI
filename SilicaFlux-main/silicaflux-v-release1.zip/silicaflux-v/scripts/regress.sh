#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-V full regression (everything except the long FPGA/ASIC runs).
# Writes reports/REGRESSION_SUMMARY.md.  Optional inputs:
#   RISCV_TESTS=<riscv-tests checkout>   (CPU ISA tests)
#   PLATFORMS=<orfs>/flow/platforms IHP_SRAM_CORE=<RM_IHPSG13_1P_core_behavioral_bm_bist.v>
#                                        (macro-tiled SoC simulations)
# =============================================================================
set -uo pipefail
cd "$(dirname "$0")/.."
S=reports/REGRESSION_SUMMARY.md; mkdir -p reports/sim reports/formal reports/lint build/soc
VF="--binary --timing --timescale 1ns/1ps -O2 -j 4 -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-MULTIDRIVEN"
RTL=$(cat rtl/files.f | tr '\n' ' ')
declare -a ROWS; ok=1
row() { ROWS+=("| $1 | $2 | $3 |"); case "$2" in PASS*) ;; SKIP*) ;; *) ok=0;; esac; echo "[regress] $1: $2 $3"; }

make -s -C firmware > reports/sim/firmware_build.log 2>&1 && row firmware PASS "$(llvm-size build/fw/bootrom.elf build/fw/app.elf | awk 'NR>1{printf "%s text=%s ", $6, $1}')" || row firmware FAIL "see reports/sim/firmware_build.log"

if scripts/lint.sh > reports/lint/lint.out 2>&1; then row lint PASS "verilator errors=$(awk '/^errors/{print $2}' reports/lint/verilator_summary.txt), yosys $(grep 'latches inferred' reports/lint/yosys_summary.txt)"; else row lint FAIL "reports/lint"; fi

if [ -n "${RISCV_TESTS:-}" ] && [ -d "$RISCV_TESTS/isa" ]; then
  tb/cpu/run_riscv_tests.sh "$RISCV_TESTS" > reports/sim/riscv_tests.out 2>&1 && row riscv-tests PASS "$(tail -1 reports/sim/riscv_tests.txt)" || row riscv-tests FAIL "$(tail -1 reports/sim/riscv_tests.txt)"
else row riscv-tests SKIP "set RISCV_TESTS"; fi

verilator $VF --top-module tb_soc -Mdir build/soc/obj -o vtb_soc $RTL build/sfv_bootrom_image.sv tb/soc/tb_soc.sv > build/soc_build.log 2>&1
scripts/soc_regress.sh > /dev/null 2>&1 && row soc-firmware PASS "$(grep -c 'TB_SOC RESULT PASS' reports/sim/soc_regression.txt)/$(grep -c 'TB_SOC RESULT' reports/sim/soc_regression.txt) scenarios, app $(grep -o 'checks=[0-9]*' reports/sim/soc_regression.txt | head -1)" || row soc-firmware FAIL "reports/sim/soc_regression.txt"

verilator $VF -DSFV_NO_CLOCK_GATE --top-module tb_soc -Mdir build/soc/obj_nocg -o vtb_soc $RTL build/sfv_bootrom_image.sv tb/soc/tb_soc.sv > build/soc_build_nocg.log 2>&1
r=$(build/soc/obj_nocg/vtb_soc +boot=0 +flash=build/fw/app_flash.hex 2>&1 | grep "TB_SOC RESULT"); echo "$r" > reports/sim/soc_no_clock_gate.txt
case "$r" in *PASS*) row soc-no-clock-gate PASS "$r";; *) row soc-no-clock-gate FAIL "$r";; esac

if [ -n "${PLATFORMS:-}" ]; then
  RTLM=$(grep -v sfv_clkgate rtl/files.f | tr '\n' ' ')
  verilator $VF -DSFV_SRAM_MACRO --top-module tb_soc -Mdir build/soc/obj_sky130 -o vtb $RTLM rtl/common/sfv_clkgate.sv asic/tech/sky130/sfv_sram_macro_bank.sv asic/tech/sky130/models/sky130_sram_1rw1r_128x256_8.v build/sfv_bootrom_image.sv tb/soc/tb_soc.sv > build/soc_build_sky130.log 2>&1
  r=$(build/soc/obj_sky130/vtb +boot=0 +flash=build/fw/app_flash.hex 2>&1 | grep "TB_SOC RESULT"); echo "$r" > reports/sim/soc_sky130_macros.txt
  case "$r" in *PASS*) row soc-sky130-macro-tiling PASS "$r";; *) row soc-sky130-macro-tiling FAIL "$r";; esac
  if [ -n "${IHP_SRAM_CORE:-}" ]; then
    verilator $VF -DSFV_SRAM_MACRO -DFUNCTIONAL --top-module tb_soc -Mdir build/soc/obj_ihp -o vtb $RTLM rtl/common/sfv_clkgate.sv asic/tech/ihp_sg13g2/sfv_sram_macro_bank.sv $PLATFORMS/ihp-sg13g2/verilog/RM_IHPSG13_1P_2048x64_c2_bm_bist.v $PLATFORMS/ihp-sg13g2/verilog/RM_IHPSG13_1P_512x64_c2_bm_bist.v $IHP_SRAM_CORE build/sfv_bootrom_image.sv tb/soc/tb_soc.sv > build/soc_build_ihp.log 2>&1
    r=$(build/soc/obj_ihp/vtb +boot=0 +flash=build/fw/app_flash.hex 2>&1 | grep "TB_SOC RESULT"); echo "$r" > reports/sim/soc_ihp_vendor_macros.txt
    case "$r" in *PASS*) row soc-ihp-vendor-sram-models PASS "$r";; *) row soc-ihp-vendor-sram-models FAIL "$r";; esac
  fi
else row soc-macro-tiling SKIP "set PLATFORMS"; fi

iverilog -g2012 -s tb_soc -o build/icarus_tb_soc.vvp $RTL build/sfv_bootrom_image.sv tb/soc/tb_soc.sv > build/icarus_build.log 2>&1
r=$(timeout 1800 vvp -n build/icarus_tb_soc.vvp +boot=3 +sram=build/fw/app_sram.hex "+stop_on=[T3 sram] checks so far=17 fails=0" 2>&1 | grep "TB_SOC RESULT"); echo "$r" > reports/sim/icarus_soc_smoke.txt
case "$r" in *PASS*) row icarus-soc-smoke PASS "$r";; *) row icarus-soc-smoke FAIL "$r";; esac

for t in tile xbar periph mbist; do
  extra=""; [ $t = tile ] && extra="N_VEC=${N_VEC:-200} N_TEN=${N_TEN:-100}"
  make -C tb/unit TEST=$t $extra > reports/sim/cocotb_$t.log 2>&1
  res=$(grep -E "TESTS=" reports/sim/cocotb_$t.log | tail -1 | sed 's/\*//g' | awk '{print $1,$2,$3}')
  case "$res" in *FAIL=0*) row cocotb-$t PASS "$res";; *) row cocotb-$t FAIL "$res";; esac
done

fdet() { sed -E 's/\.sby//; s/ +SBY .*DONE \(([A-Z]+), rc=[0-9]+\)/: \1/' reports/formal/formal_summary.txt | tr '\n' ';'; }
scripts/formal.sh > reports/formal/formal.out 2>&1 && row formal PASS "$(fdet)" || row formal FAIL "$(fdet)"

{
  echo "# SilicaFlux-V regression summary"
  echo; echo "Generated $(date -u +%F' '%T) UTC by scripts/regress.sh"; echo
  echo "| Suite | Result | Detail |"; echo "|---|---|---|"
  printf '%s\n' "${ROWS[@]}"
  echo; [ $ok = 1 ] && echo "**OVERALL: PASS**" || echo "**OVERALL: FAIL**"
} > "$S"
cat "$S"
[ $ok = 1 ]
