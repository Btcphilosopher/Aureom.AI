// Formal harness: sfv_cpu bus-protocol properties against an unconstrained
// bus environment (any grant timing, any latency, any data, any IRQs).
module fv_cpu_bus (
  input logic clk,
  input logic i_gnt, i_rvalid, i_err, d_gnt, d_rvalid, d_err,
  input logic [31:0] i_rdata, d_rdata,
  input logic irq_ext, irq_timer, irq_soft
);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic i_req, d_req, d_we, sleeping;
  logic [31:0] i_addr, d_addr, d_wdata;
  logic [3:0] d_be;
  /* verilator lint_off PINCONNECTEMPTY */
  sfv_cpu dut (.clk, .rst_n, .i_req, .i_gnt, .i_addr, .i_rvalid, .i_rdata, .i_err,
    .d_req, .d_gnt, .d_addr, .d_we, .d_be, .d_wdata, .d_rvalid, .d_rdata, .d_err,
    .irq_ext, .irq_timer, .irq_soft, .sleeping,
    .rt_valid(), .rt_pc(), .rt_insn(), .rt_trap(), .rt_cause(), .rt_rd(), .rt_rd_wdata(), .rt_rd_we());
`ifdef FORMAL
  logic i_out = 1'b0, d_out = 1'b0, d_hold = 1'b0;
  logic [31:0] d_addr_q, d_wdata_q;
  logic [3:0]  d_be_q;
  logic        d_we_q;
  always_ff @(posedge clk) begin
    if (!rst_n) begin i_out <= 1'b0; d_out <= 1'b0; d_hold <= 1'b0; end
    else begin
      if (i_req && i_gnt) i_out <= 1'b1; else if (i_rvalid) i_out <= 1'b0;
      if (d_req && d_gnt) d_out <= 1'b1; else if (d_rvalid) d_out <= 1'b0;
      d_hold <= d_req && !d_gnt;
      d_addr_q <= d_addr; d_wdata_q <= d_wdata; d_be_q <= d_be; d_we_q <= d_we;
    end
  end
  // environment: responses only for outstanding requests
  always_comb if (rst_n) begin
    assume (!i_rvalid || i_out);
    assume (!d_rvalid || d_out);
  end
  always_ff @(posedge clk) if (rst_n) begin
    assert (i_addr[1:0] == 2'b00);                  // aligned fetch
    assert (d_addr[1:0] == 2'b00);                  // word-aligned data bus
    assert (!(i_req && i_out && !i_rvalid));        // <= 1 outstanding fetch
    assert (!(d_req && d_out && !d_rvalid));        // <= 1 outstanding access
    if (d_hold) begin                               // OBI: no retraction/change
      assert (d_req);
      assert (d_addr == d_addr_q && d_we == d_we_q && d_be == d_be_q);
      if (d_we) assert (d_wdata == d_wdata_q);
    end
    if (d_req && !d_we) assert (d_be == 4'b1111);
    if (d_req && d_we)  assert (d_be != 4'b0000);
  end
`endif
endmodule
