// Formal harness: sfv_fifo -- flags/count consistency and FIFO ordering
// (a symbolic tagged element must leave after exactly the elements before it).
module fv_fifo (input logic clk, input logic clr, input logic push, input logic pop,
                input logic [7:0] wdata);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [7:0] rdata; logic empty, full; logic [2:0] count;
  sfv_fifo #(.WIDTH(8), .DEPTH(4)) dut (.clk, .rst_n, .clr, .push, .wdata, .pop, .rdata,
                                        .empty, .full, .count);
`ifdef FORMAL
  logic [2:0] ref_cnt = 3'd0;
  always_ff @(posedge clk) begin
    if (!rst_n || clr) ref_cnt <= 3'd0;
    else ref_cnt <= ref_cnt + 3'(push && !full) - 3'(pop && !empty);
  end
  // track one element: armed when pushed, then count pops ahead of it
  logic armed = 1'b0; logic [7:0] tag; logic [2:0] ahead;
  always_ff @(posedge clk) begin
    if (!rst_n || clr) armed <= 1'b0;
    else if (!armed && push && !full && !(pop && !empty) && wdata == 8'hA5) begin
      armed <= 1'b1; tag <= wdata; ahead <= ref_cnt;
    end else if (armed && pop && !empty) begin
      if (ahead == 3'd0) armed <= 1'b0; else ahead <= ahead - 3'd1;
    end
  end
  always_ff @(posedge clk) if (rst_n) begin
    assert (count == ref_cnt);
    assert (empty == (ref_cnt == 3'd0));
    assert (full  == (ref_cnt == 3'd4));
    assert (count <= 3'd4);
    if (armed && ahead == 3'd0 && !clr) assert (rdata == tag);
  end
`endif
endmodule
