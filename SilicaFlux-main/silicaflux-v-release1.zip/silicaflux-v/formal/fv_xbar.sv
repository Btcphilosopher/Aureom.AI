// Formal harness: sfv_xbar, 3 masters x 2 slaves, unconstrained masters,
// slaves constrained only to answer >= 1 cycle after grant (never spuriously).
module fv_xbar (
  input logic clk,
  input logic [2:0] m_req, m_we,
  input logic [95:0] m_addr, m_wdata,
  input logic [11:0] m_be,
  input logic [1:0] s_gnt, s_rvalid, s_err,
  input logic [63:0] s_rdata
);
  localparam int NM = 3, NS = 2;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [2:0] m_gnt, m_rvalid, m_err;
  logic [95:0] m_rdata;
  logic [1:0] s_req, s_we;
  logic [63:0] s_addr, s_wdata;
  logic [7:0] s_be;
  logic err_evt, err_we;
  logic [31:0] err_addr;
  logic [1:0] err_master;
  sfv_xbar #(.NM(NM), .NS(NS), .SLV_BASE({32'h1000_0000, 32'h0000_0000}),
             .SLV_MASK({32'hF000_0000, 32'hF000_0000}), .MST_SLV_EN(6'b01_11_11)) dut (
    .clk, .rst_n, .m_req, .m_gnt, .m_addr, .m_we, .m_be, .m_wdata, .m_rvalid, .m_rdata, .m_err,
    .s_req, .s_gnt, .s_addr, .s_we, .s_be, .s_wdata, .s_rvalid, .s_rdata, .s_err,
    .err_evt, .err_addr, .err_master, .err_we);

`ifdef FORMAL
  // reference bookkeeping
  logic [NS-1:0] s_out;
  logic [1:0]    s_own [0:NS-1];
  logic [NM-1:0] m_out;
  localparam logic [NM*NS-1:0] EN = 6'b01_11_11;
  // master m targets slave s with a legal (mapped and permitted) access
  function automatic logic tgt(input int m, input int s, input logic [95:0] a);
    tgt = (a[m*32+28 +: 4] == 4'(s)) && EN[m*NS + s];
  endfunction
  initial begin s_out = '0; m_out = '0; end
  always_ff @(posedge clk) begin
    if (!rst_n) begin s_out <= '0; m_out <= '0; end
    else begin
      for (int s = 0; s < NS; s++) begin
        if (s_req[s] && s_gnt[s]) begin
          s_out[s] <= 1'b1;
          for (int m = 0; m < NM; m++)
            if (m_gnt[m] && tgt(m, s, m_addr)) s_own[s] <= 2'(m);
        end else if (s_rvalid[s]) s_out[s] <= 1'b0;
      end
      for (int m = 0; m < NM; m++) begin
        if (m_gnt[m]) m_out[m] <= 1'b1;
        else if (m_rvalid[m]) m_out[m] <= 1'b0;
      end
    end
  end
  // environment: slaves respond only to an outstanding transfer
  always_comb if (rst_n) for (int s = 0; s < NS; s++) assume (!s_rvalid[s] || s_out[s]);

  always_ff @(posedge clk) if (rst_n) begin
    for (int m = 0; m < NM; m++) begin
      // no response without an outstanding request
      assert (!m_rvalid[m] || m_out[m]);
      // single outstanding: new grant only when the old response returns now
      assert (!(m_gnt[m] && m_out[m] && !m_rvalid[m]));
    end
    for (int s = 0; s < NS; s++) begin
      // slave single outstanding
      assert (!(s_req[s] && s_gnt[s] && s_out[s] && !s_rvalid[s]));
      // a slave response reaches its owner with the slave's data
      if (s_rvalid[s] && s_out[s]) begin
        assert (m_rvalid[s_own[s]]);
        assert (m_rdata[s_own[s]*32 +: 32] == s_rdata[s*32 +: 32]);
        assert (m_err[s_own[s]] == s_err[s]);
      end
    end
    // at most one master granted per slave (masters map by addr[28])
    for (int s = 0; s < NS; s++) begin
      int n;
      n = 0;
      for (int m = 0; m < NM; m++)
        if (m_gnt[m] && s_req[s] && s_gnt[s] && tgt(m, s, m_addr)) n++;
      assert (n <= 1);
    end
  end
`endif
endmodule
