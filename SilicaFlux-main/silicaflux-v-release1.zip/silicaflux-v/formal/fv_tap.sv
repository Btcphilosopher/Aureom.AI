// Formal harness: JTAG TAP -- five consecutive TMS=1 clocks reach
// Test-Logic-Reset from ANY state (IEEE 1149.1 6.1.1), and IR = IDCODE there.
module fv_tap (input logic tck, input logic tms, input logic tdi, input logic [7:0] dr_tdo_any);
  logic trst_n = 1'b0;
  always_ff @(posedge tck) trst_n <= 1'b1;
  logic tdo, tdo_oe, cdr, sdr, udr;
  logic [4:0] ir;
  logic [3:0] st;
  sfv_jtag_tap dut (.tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .ir, .capture_dr(cdr),
                    .shift_dr(sdr), .update_dr(udr), .state_o(st), .dr_tdo(dr_tdo_any[0]));
`ifdef FORMAL
  logic [2:0] ones = 3'd0;
  always_ff @(posedge tck) ones <= tms ? ((ones == 3'd5) ? 3'd5 : ones + 3'd1) : 3'd0;
  always_ff @(posedge tck) if (trst_n) begin
    if (ones == 3'd5) assert (st == 4'hF);              // Test-Logic-Reset
    if (ones == 3'd5) assert (ir == 5'h01);             // IDCODE selected
    assert (!(cdr && sdr) && !(sdr && udr) && !(cdr && udr));   // one-hot strobes
  end
`endif
endmodule
