# Repository forensic intake and module reuse matrix

Scope: `btcphilosopher/Aureom.AI` @ `5026935` (branch `claude/blissful-goldberg-qf7vbs`).
The repository is a mixed archive (rail, finance, web apps, PDFs…); the
SilicaFlux material is in `SilicaFlux-main/` (162 files, of which 39 zip/tar
archives) plus `silicafluxai.zip`, `silicafluxbitcoinasic.zip`, `SilicaFluxML.zip`
and `neurax-gpu-core/` at the root.

Method (reproducible: `scripts/repo_intake.sh <extracted-archives> <out>`):
every HDL candidate was extracted into an isolated directory and run through
**Icarus 12** (elaboration), **Verilator 5.020** (`--lint-only -Wall`),
**Yosys 0.33** (`read_verilog -sv; hierarchy; proc`, latch listing) and, where
one exists, its **shipped testbench**.  Raw results:
`reports/intake/intake_pass1_summary.tsv`.  First-pass failures caused by the
harness (missing `-I`, file-list prefixes, file names with spaces, testbenches
needing their own working directory) were re-run with corrected settings; the
table below reports the corrected result.  The prior TimingLab discovery report
(`SilicaFlux2.0/SilicaFlux2.5/silicaflux-timinglab (1).zip:docs/DISCOVERY.md`,
pyslang-based) was used as an independent cross-check and agrees on every
SilicaFlux 2.x finding.

## 1. What `.sf` / `.sfx` are

* `.sf` = SystemVerilog IEEE 1800-2017 (header banner "Language : Silica
  Flux-2017 … IEEE 1800-2017 language semantics"). 45 files; plus one DSL
  sketch (`SilicaFluxML.zip:dsl/silicaflux_ml.sf`, self-declared non-parseable).
* `.sfx` = assembly for the SilicaFlux v1.0 custom ISA (`sfx_asm.py`).

## 2. Inventory and evidence

| Candidate (location) | Content | Evidence (this intake) | Status |
|---|---|---|---|
| SilicaFlux 2.x `.sf` RTL (`SilicaFlux-main/*.sf`, `SilicaFlux2.5/*.sf`, `silicaflux_rtl*.zip`) | OoO-style fetch/decode (4-wide), ALU, forwarding, register bank 32×32+16×128, vector engine, 20-stage tensor unit, banked memory controller, scheduler, 2×2 NoC, tile interface, `silicaflux_top` | Icarus: all fail (concurrent SVA, package forms). Verilator: `sf_alu`, `sf_decoder`, `fetch_unit`, `register_bank`, `tensor_unit` lint with the matching package; `forwarding_unit`, `memory_controller`, `vector_engine (1)`, `noc_interconnect`, `scheduler`, `compute_tile`, `tile_interface`, `silicaflux_top` fail (undefined types). `silicaflux_pkg` has 7 incompatible definitions; `silicaflux_top.sf` instantiates 27 modules defined nowhere; 0/9 `.sf` testbenches match their DUT ports (TimingLab confirms). | **Not elaborable as a system.** Retained as architectural reference only. |
| SilicaFlux v1.0 (`silicaflux.zip`) | Custom 32-bit ISA (5-bit opcode), 6-stage control core, LANES-parametric vector engine, 4×4 tensor unit (one sequential 32-bit MAC, ~66 cycles), NoC, tiles | Needs `-I rtl`. All 7 testbenches PASS under Icarus (3–15 checks each; shallow). `run_sim.sh` arithmetic bug (`0\n0` from `grep -c … \|\| echo 0`). Yosys 0.33: syntax error `silicaflux_pkg.sv:218`. No C compiler exists for the ISA. | Not used as CPU (C firmware is required). Vector op semantics (ADD/SUB/MUL/DOT/broadcast) and the "tile = vector + tensor + local SRAM" structure **preserved**. |
| `RISC-V CPU.zip` (`rv32i_core`) | RV32I 5-stage, internal IMEM/DMEM | Lints (12 warnings). Own directed test PASSES when run in its directory (fails elsewhere: relative `program.hex`). No CSR, traps, interrupts or bus interface. | Reference. |
| `cpu_core.zip` (`cpu_core`) | RV32I 5-stage with forwarding, byte enables, random-program scoreboard TB | TB: 27/0 directed + 91/0 scoreboard, "ALL TESTS PASSED". Defects for silicon: combinational instruction memory (not SRAM-macro compatible), no CSR/trap/IRQ, **async reset OR-ed with synchronous flush** in `always_ff @(posedge clk or negedge rst_n) if (!rst_n \|\| if_id_flush)` (synthesis hazard), ungated `$error` checks in RTL. | **Adapted**: decode tables and immediate generation reused in `sfv_cpu`; pipeline, bus, CSRs, traps new. |
| `pipelined_cpu.zip` | RV32-like 5-stage | Elaboration fails: unbound parameter `IMEM_INIT_FILE` (cpu_top.sv:118). | Not used. |
| `soc_integration.tar.gz` | Single-master SoC fabric, UART, GPIO, timer, IRQ ctrl, boot ROM, CPU BFM | TB: 20 PASS / 0 FAIL (BFM, no real CPU). Yosys 0.33 cannot parse `return` in a package function (`soc_pkg.sv:126`). Fabric has one master port only. | **Adapted**: UART register map / FIFO organisation (`sfv_uart`); memory-map/error-test style. Fabric not reused (single master). |
| `comm_protocols.zip` | UART, SPI master/slave, I²C, AXI-lite slave | UART: duplicate enum literal `DATA_BITS` in two modules → compile error. SPI: `inside` unsupported by Icarus. | Not used. |
| `memory_cache_repo.zip` | sp/dp RAM, caches, FIFOs | `sp_ram.sv:126` syntax errors (Icarus/Yosys). | Not used. |
| `silicaflux-memoryflow` v2.0.0 | SRAM abstraction (inferred / macro tiling / blackbox), March C- MBIST, outer-product tensor array, streaming vector unit, banked SPM, DMA | Verilator + Yosys clean. `tb_accel` PASS (2572 checks), `tb_mbist` PASS, `tb_spm` PASS (46658 checks). Tensor accumulators have no reset; vector unit needs 2×IN_FIFO×DW flops (2×16×128). | **Adapted**: `sfv_sram_sp` contract, `sfv_mbist` (from `sf_mbist_march`, + runtime depth + checkerboard), `sfv_mac_array` (from `sf_tensor_array`, FIFOs/double buffer removed, reset/clear/signedness added). |
| `silicaflux-testcore` | IEEE 1149.1 TAP, BSR, microcoded MBIST, test modes, LBIST eval, ATPG collateral, Python host | 7/7 SV testbenches PASS; Verilator 0 errors (3 warnings). Yosys 0.33 rejects `import` in module headers. MBIST is feature-rich (19 KB + 25 KB spec package). | **Adapted**: `sfv_jtag_tap` (from `tc_tap`: state encoding, capture/update/TDO edges). MBIST/BSR/ATPG collateral kept as the reference for the commercial DFT step. |
| `silicaflux-ai` | 4×4/16×16 systolic arrays, MAC, DMA, FIFOs | Verilator clean; Yosys 0.33 syntax error in `sfx_fifo.sv:193`. | Not used (output-stationary outer-product chosen: fewer operand registers). |
| `silicaflux-powerlink` | reset/clock controller, power sequencer, PDN Tcl | Lint/Yosys clean, TB PASS. | Reference (SilicaFlux-V uses a simpler single-domain reset tree). |
| `silicaflux-timinglab` | Yosys-slang/OpenSTA/OpenROAD runs on 2.5 blocks | Reports reviewed. | Numbers **not** reused (different RTL). |
| bitcoin-asic, SilicaFluxML, FSM/DSP/digital libraries, UVM FIFO, formal examples | unrelated to the processor | — | Not used. |

## 3. Unsupported synthesis constructs found

* async reset combined with synchronous conditions in one `if` (`cpu_core.sv`);
* `$error`/`$display` checks in synthesizable `always` blocks without
  `ifndef SYNTHESIS` (`cpu_core.sv`);
* combinational (asynchronous-read) instruction memories (`cpu_core`, `rv32i_core`)
  — incompatible with SRAM macros;
* constructs outside the Yosys 0.33 frontend: package `import` in module
  headers, `return`, `inside`, interfaces (testcore, soc_integration, comm_protocols);
* 2.x RTL depends on SystemVerilog types/packages that do not exist in the repo.

## 4. Missing third-party / foundry IP

No third-party soft IP is required by SilicaFlux-V (CPU, bus, peripherals, DFT
are in-repo).  Required at tape-out and **not** supplied (foundry/PDK IP):
SRAM compiler macros (sky130 OpenRAM and IHP SG13G2 macros are used for the
open baselines), I/O pad library, optional ROM macro, JEDEC manufacturer ID
(placeholder 0x000 in `sfv_pkg::JTAG_MFR`).

## 5. Build/compilation failures in the existing repo (summary)

28 of 46 first-pass compile targets failed; after harness corrections the
genuine failures are: SilicaFlux 2.x top/tile/scheduler/NoC/tile-interface
(missing modules/types), `pipelined_cpu` (unbound parameter),
`comm_protocols` UART (duplicate enum), `memory_cache_repo` `sp_ram` (syntax),
SilicaFlux v1.0 under Yosys 0.33, plus the v1.0 `run_sim.sh` reporting bug.
