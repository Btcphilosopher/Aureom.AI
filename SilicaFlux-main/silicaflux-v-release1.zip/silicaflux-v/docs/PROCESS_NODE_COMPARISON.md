# Process-node comparison: 130 nm vs 65 nm CMOS for SilicaFlux-V

**Provenance key.**  **[T]** = tool-derived in this release (Yosys/OpenROAD/
OpenSTA on IHP SG13G2 or SKY130, docs/ASIC_FLOW.md).  **[E]** = engineering
estimate; the assumption is stated in the same row.  No public 65 nm PDK
exists, so every 65 nm figure is [E], anchored to the [T] 130 nm design
(same netlist structure: ≈ 94 k NAND2-equivalents of logic, 3.8 k flops,
144 KiB SRAM in 12 macros).  Prices are deliberately not quoted as numbers:
MPW price lists change and must be obtained from the broker for the chosen
run; the comparison is made through the cost *drivers*.

| Criterion | 130 nm | 65 nm |
|---|---|---|
| Standard-cell area | **[T]** 0.68 mm² synthesized, ≈ 0.86 mm² placed incl. repair buffers (IHP SG13G2); 0.40 mm² on SKY130 hd | **[E]** 0.15–0.25 mm²: 94 k GE × 1.4–1.8 µm²/GE (typical 65 nm 9–12-track NAND2) + ~30 % repair buffers |
| SRAM macro area (144 KiB) | **[T]** 4.53 mm² IHP compiled SP macros (3.8 µm²/bit incl. periphery); 26.0 mm² SKY130 OpenRAM (22 µm²/bit). A commercial 130 nm compiler is expected near the IHP figure **[E]** | **[E]** 1.0–1.4 mm²: 0.8–1.2 µm²/bit incl. periphery for 4–16 KiB SP instances (bitcell ≈ 0.5 µm²) |
| Core / die | **[T]** 7.34 mm² core (IHP, no pad ring); **[E]** ≈ 11 mm² with a 0.3 mm wire-bond pad ring | **[E]** core 1.8–2.2 mm², die ≈ 3.5–4 mm² with pad ring; becomes **pad-limited** (≈ 32 pads) — SRAM reduction no longer shrinks the die |
| Clock frequency feasibility | **[T]** 74.5 MHz typical, ideal clocks (IHP); 37 MHz SKY130 (half-cycle SRAM paths). **[E]** 45–55 MHz signoff at ss/125 °C after CTS → **50 MHz target** | **[E]** 150–200 MHz signoff (gate delay ≈ 2.5–3× lower, SRAM access ≈ 1–1.5 ns vs 3.9 ns) |
| Dynamic power | **[T]** logic 11.1 mW @ 50 MHz, 10 % activity, 1.2 V (IHP) — excludes clock tree and SRAM. **[E]** total 15–30 mW @ 50 MHz incl. clock tree and SRAM accesses | **[E]** ≈ 0.3–0.4× of 130 nm per MHz (C × V²: ~0.5× capacitance, 1.0–1.2 V): 5–10 mW @ 50 MHz, 15–35 mW @ 150 MHz |
| Static power | **[T]** 26 µW logic leakage typical/25 °C (IHP); SRAM leakage not characterised | **[E]** 65 nm LP: 0.1–1 mW at 25 °C, 10× at 125 °C; GP flavour 10–50× higher — choose LP/ULL for this product |
| Required pin count | 21 mandatory signals + 2 optional + 8–10 power/ground = 32–40 pads | identical (architecture-determined); two supply domains in both (core 1.2 V / 1.0–1.2 V, I/O 3.3 V or 2.5 V) |
| Package cost | QFN-32/40 or ceramic DIL for prototypes; same package class at both nodes; small die fits any open-tool QFN cavity | same package; 65 nm die is pad-limited, so no package saving |
| Test infrastructure | identical on-chip DFT (JTAG + SBA, MBIST, POST, TEST_PASS/FAIL); stuck-at scan sufficient for prototypes | same + at-speed (transition) testing more important at 150–200 MHz → needs OCC (ISS-003) |
| MPW access | open PDKs with public collateral (IHP SG13G2, SKY130) usable with the fully open flow of this repo; commercial 130 nm (several foundries) via MPW brokers | commercial only (no open 65 nm PDK); available on broker MPW shuttles, NDA + export controls apply |
| EDA / IP licensing | open PDK path: **no EDA licence** needed (Yosys, OpenROAD, KLayout/Magic, Netgen); SRAM macros come with the PDK | NDA PDK; signoff DRC/LVS decks usually require commercial verification tools; SRAM compiler, I/O library and possibly standard cells under licence; commercial P&R/STA strongly advisable for closure at 150–200 MHz |
| Engineering cost drivers | lowest: this repo's flow runs as-is (ASIC_FLOW.md); remaining work = signoff, pads, DFT insertion | higher: tool licences, foundry IP onboarding, tighter timing/SI/IR closure, leakage/corner management; per-mm² MPW price typically several× the 130 nm price while the die is only ~3× smaller → MPW cost similar or higher |

## Recommendation
**First silicon at 130 nm (IHP SG13G2-class process), 50 MHz, 144 KiB SRAM.**
* It is the only option that is reproducible end-to-end with the open flow
  delivered here (tool-derived area, placement and timing exist today).
* Timing has margin at the target (+6.6 ns at 50 MHz typical), the die is
  ≈ 11 mm² with pads, and the design is not pad-limited, so SRAM can be traded
  directly against cost.
* 65 nm becomes attractive for a **product** revision once the architecture is
  silicon-proven: ~3× higher frequency and ~3× lower energy per operation,
  but pad-limited die, NDA/licensed IP and higher closure effort; it does not
  reduce MPW cost for a design this small.
* Avoid SKY130 + OpenRAM for this configuration: 26 mm² of SRAM macros and
  half-cycle SRAM timing (tool-derived) make it the most expensive and the
  slowest option; if SKY130 must be used, reduce SRAM (see the 32 KiB variant
  in docs/ASIC_FLOW.md).
