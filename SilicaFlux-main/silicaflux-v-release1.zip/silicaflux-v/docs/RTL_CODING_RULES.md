# RTL coding rules (enforced by review + `scripts/lint.sh`)

1. One synthesizable SystemVerilog subset accepted unchanged by Verilator
   5.020, Icarus 12 and the Yosys 0.33 frontend (the baseline ASIC/FPGA flow
   has no slang/sv2v dependency):
   * no package `import` (use `sfv_pkg::NAME`), no `return`, no `inside`,
     no interfaces, no structs/unions, no unpacked-array ports;
   * functions assign their result to the function name.
2. `always_ff` with non-blocking assignments only; `always_comb` fully
   assigns every output on every path (defaults at the top) — no unintended
   latches (Yosys latch list must contain only `sfv_clkgate` instances).
3. Clocks: one functional clock + TCK; the only gated clocks come from
   `sfv_clkgate`.  Resets: active-low asynchronous assert / synchronous
   de-assert through `sfv_rst_sync`; never combine an async reset with a
   synchronous condition in the same `if`; never load non-constant data on
   reset (straps are sampled after reset).
4. Datapath/storage flops that are qualified by valid state need no reset
   (fetch buffer, register file, SRAM output registers); control state is
   always reset.
5. Every vendor-specific cell (ICG, SRAM macro, synchroniser, pads, ROM)
   sits behind a wrapper with a technology-independent contract; per-PDK
   implementations live in `asic/tech/<pdk>/`.
6. Simulation-only code (fault injection, `$display`) is enclosed in
   `` `ifndef SYNTHESIS `` and never feeds synthesizable logic.
7. Widths are explicit in arithmetic (`32'(…)`, sized literals); arithmetic
   shifts are computed on a `signed` wire, never inside a mixed-sign ternary
   (bug found by riscv-tests `sra`/`srai`, see ISS-011).
8. Bus masters follow docs/BUS.md; slaves never assume request stability
   before grant.
