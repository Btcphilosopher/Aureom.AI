# FPGA prototype — Radiona ULX3S (Lattice ECP5 LFE5U-85F-6BG381C)

**Status: bitstream built with the open flow; NOT yet tested on hardware.**
No hardware was available to this release; "FPGA validated" must not be
claimed until the procedure in §4 has been executed on a board.

## Why this board
ECP5-85F: 84 k LUT4, 208 × 18 Kb EBR (enough for 128 KiB SRAM + 16 KiB TSPM
= 72 EBR), 156 multipliers, 25 MHz oscillator, FT231X USB-UART, fully
supported by Yosys + nextpnr + Trellis (no vendor licence).  The 25F variant
has only 56 EBR: build with `SRAM_BANK_WORDS=4096` (64 KiB) and rebuild the
firmware linker scripts accordingly.

## Build (tool-reported results of this release)
```
make fw            # ROM image is part of the bitstream
make -C fpga/ulx3s # yosys synth_ecp5 -abc9 -> nextpnr-ecp5 --85k -> ecppack
```
| Resource | Used | Source |
|---|---|---|
| LUT4 / FF | 13 258 / 2 829 | `build/fpga/yosys_stat.txt` |
| DP16KD (EBR) | 72 | SRAM 64 + TSPM 8 (ROM in LUTs) |
| MULT18X18D | 28 | vector lanes + tensor array |
| TRELLIS_DPR16X4 | 36 | register file in distributed RAM |
| Fmax `clk` / `tck` (post-route) | 39.24 MHz / 93.39 MHz (target 25 MHz: PASS) | `reports/fpga/nextpnr_key.log` |
| Bitstream | `reports/fpga/sfv_ulx3s.bit` (688 KB, compressed; sha256 alongside) | ecppack |

FPGA-specific choices: `SFV_NO_CLOCK_GATE` (no gated clocks on FPGA fabric),
SRAMs inferred to EBR by `sfv_sram_sp`, 25 MHz used directly (no PLL), POR
counter + button reset.

## Pins / board use (`fpga/ulx3s/ulx3s_v20.lpf`)
* UART: FT231X (`/dev/ttyUSB0`, 115200 8N1).
* Reset: F1 (`btn[1]`).  Boot straps `straps = 2'b10 ^ {btn3, btn2}` held
  while pressing reset: none → POST, F2 → SRAM, UP → SPI, both → JTAG.
* JTAG for the SilicaFlux-V TAP on J1 gp0/gn0/gp1/gn1 (TCK TMS TDI TDO) for an
  external adapter (the FT231X JTAG is wired to the ECP5 configuration TAP).
* SPI boot flash: PMOD on J1 gp2/gn2/gp3/gn3 (SCK MOSI MISO CS#).
* LEDs: {pass, fail, TEST_PASS, TEST_FAIL, WFI, heartbeat[2:0]}.
* gpio5 is looped back from gpio4 inside the top (acceptance test T7).
Pin names follow the board's published `ulx3s_v20.lpf`; verify against your
board revision before programming.

## Bring-up / diagnostic procedure
1. `openFPGALoader -b ulx3s build/fpga/sfv_ulx3s.bit` (SRAM configuration).
2. Open the console (`picocom -b 115200 /dev/ttyUSB0`), press F1: expect
   `SilicaFlux-V boot ROM`, `chip_id=0x53465601`, `boot_mode=0x00000002`,
   `mbist=0x00000002`, `POST PASS` and LED[7]… pattern.
3. No output: heartbeat LEDs[2:0] toggling? (clock/bitstream OK) → check
   FT231X wiring (`ftdi_rxd` = FPGA TX).  LED TEST_FAIL lit with code 0xEE →
   ROM trap.  `mbist` FAIL bit → EBR mapping or timing problem: rebuild with
   `--freq 25` report review.
4. Full acceptance app: program a SPI flash PMOD with `build/fw/app_flash.bin`
   at offset 0, hold UP while pressing F1 → expect `SFV-APP RESULT PASS`.
   Alternatively load over the SilicaFlux-V JTAG with the host procedure in
   docs/DFT.md (IR 0x11 hold, IR 0x10 SBA writes, mailbox).
