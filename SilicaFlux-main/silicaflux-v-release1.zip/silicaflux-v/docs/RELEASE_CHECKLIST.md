# Release acceptance checklist — SilicaFlux-V RTL release 1

Legend: ✅ met (evidence linked) · ⚠️ met with stated limits · ❌ not met (blocker).

## Synthesis-ready criteria (task §11)

| # | Criterion | Status | Evidence |
|---|---|---|---|
| 1 | Entire selected RTL hierarchy elaborates | ✅ | Verilator `-Wall` 0 errors; Yosys 0.33 `hierarchy -check` + flatten OK; Icarus compiles full SoC (`reports/lint/`, `reports/sim/icarus_soc_smoke.txt`) |
| 2 | Required functional tests pass | ✅ | `reports/REGRESSION_SUMMARY.md`: riscv-tests 55/55, 6 SoC firmware scenarios, cocotb tile/xbar/periph/MBIST, formal |
| 3 | No unintended latches | ✅ | Yosys latch list = the two `sfv_clkgate` ICG enable latches only (RTL); mapped netlists: 0 latches + 2 library ICGs |
| 4 | Clock/reset risks reviewed | ⚠️ | docs/CLOCK_RESET.md; CDC by construction (toggle handshakes, quasi-static levels); open: library synchroniser cells (ISS-008), reset-tree closure (ISS-006) |
| 5 | CPU firmware boots in simulation | ✅ | boot ROM → MBIST → SPI-flash / JTAG / SRAM boot → acceptance app PASS (432 + 3 checks) |
| 6 | Vector and tensor workloads pass | ✅ | firmware T4/T5 vs C golden model; cocotb random commands vs Python golden model under fabric contention; POST vs golden constants |
| 7 | SRAM interfaces compatible with intended macros | ✅ | same firmware regression passes with the macro-tiled SRAM for sky130 (OpenRAM pinout stand-in) and IHP SG13G2 (**vendor functional models**), identical cycle counts |
| 8 | Synthesis produces a valid mapped netlist for the selected libraries | ✅ | Yosys → sky130_fd_sc_hd and sg13g2 netlists, `check -assert` clean; OpenROAD loads/links/places them (`reports/synth/`) |
| 9 | Timing and power constraints documented | ✅ | `asic/constraints/sfv_soc.sdc`; post-placement STA + power estimates in docs/ASIC_FLOW.md (typical corner, ideal clocks) |
| 10 | DFT integration requirements satisfied (RTL level) | ⚠️ | JTAG TAP + SBA, MBIST on all SRAM, test mode, ICG test enable, scan-friendly netlist (docs/DFT.md); scan/ATPG/BSR are commercial-flow items (ISS-003/004) |
| 11 | Every unresolved blocker recorded | ✅ | docs/ISSUE_REGISTER.md (20 open, 10 resolved) |
| 12 | Release package reproducible from the zip alone | ✅ | fresh extract: `make fw lint soc-sim unit formal cpu-tests` all PASS, identical cycle counts |

## Tape-out readiness (NOT claimed)

| Item | Status |
|---|---|
| Physical signoff (CTS, route, extraction, MCMM STA, DRC/LVS, IR/EM) | ❌ ISS-001 |
| Foundry IP integration (SRAM compiler, pads, ESD) | ❌ ISS-002 |
| Manufacturing test (scan, ATPG, BSR, test program) | ❌ ISS-003, ISS-004 |
| FPGA prototype tested on hardware | ❌ ISS-007 (bitstream built only) |
| Gate-level simulation | ❌ ISS-012 |
