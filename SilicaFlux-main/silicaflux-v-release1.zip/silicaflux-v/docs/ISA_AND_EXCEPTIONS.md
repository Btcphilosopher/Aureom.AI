# CPU instruction set, exception and interrupt model

## ISA
RV32I base (all 37 user instructions + FENCE) + Zicsr, machine mode only.
`FENCE` is a no-op (single in-order hart, stores complete before the next
instruction).  `FENCE.I` flushes the 2-entry prefetch buffer (self-modifying
code / code loaded by DMA-less copy is fetched afresh).  `WFI` stalls until
`(mip & mie) != 0` regardless of `mstatus.MIE`.  `MRET` returns to `mepc`.
Optional RV32E (`RV32E=1`): accesses to x16–x31 raise illegal-instruction.
Not implemented: M, A, C, F, U/S modes, PMP, debug triggers, misaligned
access emulation in hardware.

## CSRs

| CSR | Addr | Implementation |
|---|---|---|
| mstatus | 0x300 | MIE[3], MPIE[7] RW; MPP[12:11] reads 11 |
| misa | 0x301 | RO 0x4000_0100 (RV32I) / 0x4000_0010 (RV32E); writes ignored |
| mie | 0x304 | MSIE[3], MTIE[7], MEIE[11] |
| mtvec | 0x305 | BASE[31:2], MODE[0] (0 direct, 1 vectored); reset = boot address |
| mstatush | 0x310 | reads 0 |
| mcountinhibit | 0x320 | CY[0], IR[2] |
| mscratch, mepc, mcause, mtval | 0x340–0x343 | full; mepc[1:0]=0 |
| mip | 0x344 | MSIP/MTIP/MEIP live from timer/INTC (RO) |
| mcycle(h), minstret(h) | 0xB00/B80/B02/B82 | 64-bit; a write to either half suppresses that cycle's increment |
| cycle(h), instret(h) | 0xC00/C80/C02/C82 | RO shadows |
| mvendorid, marchid, mimpid, mhartid, mconfigptr | 0xF11–0xF15 | 0, 0, 0x0001_0000, 0, 0 |
Any other address, or a write to a read-only CSR, raises illegal instruction.

## Exceptions (precise; no architectural state changes for the trapping instruction)

| mcause | Cause | mtval |
|---|---|---|
| 0 | instruction address misaligned (taken branch/jump to target[1]=1; reported on the branch) | target |
| 1 | instruction access fault (bus error on fetch, incl. execute-never region) | pc |
| 2 | illegal instruction | instruction word |
| 3 | breakpoint (EBREAK) | pc |
| 4 / 6 | load / store address misaligned | address |
| 5 / 7 | load / store access fault (bus error) | address |
| 11 | ECALL from M-mode | 0 |
Priority when several apply: fetch fault > illegal > EBREAK/ECALL > misaligned
data > misaligned target > data access fault (spec order for one instruction).

## Interrupts
Sources: MEI (11) from `sfv_intc` (8 level sources), MTI (7) and MSI (3) from
`sfv_timer` (CLINT-style).  Priority MEI > MSI > MTI.  Taken between
instructions, only before an instruction has issued a bus request (a pending
load/store always completes first, so bus requests are never retracted).
Interrupting a `WFI` sets `mepc` to the instruction after the WFI.  Vectored
mode jumps to `BASE + 4*cause`.  Trap entry: `mepc`, `mcause`, `mtval`,
`MPIE←MIE`, `MIE←0`.

## Pipeline timing

| Instruction class | Cycles (zero-wait memory) |
|---|---|
| ALU / LUI / AUIPC / CSR / FENCE | 1 |
| load / store | 2 (+ bus wait states) |
| taken branch, JAL, JALR, MRET, FENCE.I, trap entry | 3 |
| not-taken branch | 1 |

## Verification
Official riscv-tests rv32ui (40) + rv32mi (15) pass under six bus
grant/latency profiles (`tb/cpu/run_riscv_tests.sh`); skipped with reason:
`ma_data` (hardware misaligned access), `pmpaddr` (no PMP), `breakpoint`
(no trigger module).  Interrupts, WFI, vectored traps and all exception causes
are checked by the acceptance firmware (T6).  Bus-protocol properties are
checked formally (BMC depth 16, `formal/fv_cpu_bus.sv`).
