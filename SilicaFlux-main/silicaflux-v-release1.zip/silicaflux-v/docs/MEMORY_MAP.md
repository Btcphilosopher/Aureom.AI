# Memory map and register map

Source of truth: `rtl/pkg/sfv_pkg.sv` (RTL) and `firmware/common/sfv_map.h`
(firmware).  All unmapped addresses return a bus error (load/store access
fault; instruction access fault on fetch).

| Base | Size | Region | Access |
|---|---|---|---|
| 0x0000_0000 | 4 KiB | Boot ROM (reset vector 0x0) | R X; write → bus error |
| 0x1000_0000 | 128 KiB | SRAM, banks 0–3 at +0x0000/+0x8000/+0x10000/+0x18000 | R W X |
| 0x2000_0000 | 16 KiB | Tile scratchpad (TSPM), 4-way word-interleaved | R W X |
| 0x4000_0000 | 4 KiB | SYSCTRL | R W, word only, **execute-never** |
| 0x4000_1000 | 4 KiB | INTC | " |
| 0x4000_2000 | 4 KiB | TIMER (CLINT-style) | " |
| 0x4000_3000 | 4 KiB | UART | " |
| 0x4000_4000 | 4 KiB | SPI | " |
| 0x4000_5000 | 4 KiB | GPIO | " |
| 0x4001_0000 | 4 KiB | Vector engine | " |
| 0x4001_1000 | 4 KiB | Tensor engine | " |
DMA: not included — operand sets for the 4×4 tensor and 4-lane vector engines
are small and the CPU moves them at ~4 cycles/word; a DMA master is the first
optional addition (docs/ISSUE_REGISTER.md ISS-015).

## SYSCTRL (0x4000_0000)
| Off | Name | Description |
|---|---|---|
| 0x00 | CHIP_ID | RO 0x5346_5601 |
| 0x04 | BOOT_MODE | [1:0] straps (GPIO[1:0]) sampled 3 cycles after reset, or JTAG override: 0 SPI, 1 JTAG, 2 POST, 3 SRAM |
| 0x08 / 0x0C | SCRATCH0/1 | JTAG mailbox: entry point / 0xB007_C0DE = go |
| 0x10 | TEST_STATUS | [1:0] 0 running, 1 pass, 2 fail; [15:8] code — drives TEST_PASS/TEST_FAIL |
| 0x14 | SOFT_RESET | write 0x5AFE_0001: 8-cycle system reset (CPU, bus, peripherals, tile) |
| 0x18 | RESET_CAUSE | [0] pin, [1] soft, [2] JTAG CPU hold active |
| 0x1C | CLK_CTRL | [0] TILE_CG_OFF (keep accelerator clocks on) |
| 0x20 / 0x24 | BUSERR_ADDR / INFO | first decode error: address; [0] valid (W1C), [2:1] master (0 JTAG, 1 CPU-D, 2 CPU-I), [3] write |
| 0x28 | MBIST_CTRL | [0] START, [1] checkerboard, [4] group (0 SRAM, 1 TSPM), [8] IRQ_EN |
| 0x2C | MBIST_STATUS | [0] BUSY [1] DONE [2] FAIL [11:8] bank mask [14:12] element [31:16] address |
| 0x30 | DOORBELL | [0] software/JTAG interrupt (source 7) |

## INTC (0x4000_1000)
0x00 PENDING (RO levels), 0x04 ENABLE, 0x08 CLAIM (1 + lowest active
source, 0 none).  Sources: 0 UART, 1 SPI, 2 GPIO, 3 VE, 4 TE, 5 MBIST done,
6 bus error, 7 doorbell.  Level-sensitive; cleared at the source.

## TIMER (0x4000_2000)
0x00/0x04 MTIME lo/hi, 0x08/0x0C MTIMECMP lo/hi (reset all-ones), 0x10 MSIP,
0x14 PRESCALE (mtime += 1 every PRESCALE+1 cycles).

## UART (0x4000_3000)
0x00 DATA (W push TX; R [7:0] data, [31] RX_EMPTY), 0x04 STATUS ([0] TX_READY
[1] TX_IDLE [2] RX_VALID [3] RX_OVF [4] FRAME_ERR [5] TX_OVF; W1C [5:3]),
0x08 CTRL ([0] TX_IRQ_EN [1] RX_IRQ_EN [2] LOOPBACK), 0x0C BAUD (bit period in
cycles, ≥ 4; reset value is a SoC parameter: 217 = 115200 Bd @ 25 MHz).

## SPI (0x4000_4000)
0x00 DATA (W start byte — bus error if busy; R last received), 0x04 STATUS
([0] BUSY [1] DONE W1C), 0x08 CTRL ([0] CPOL [1] CPHA [2] IRQ_EN [8] CS0),
0x0C DIV (SCK half period = DIV+1 cycles).

## GPIO (0x4000_5000)
0x00 IN, 0x04 OUT, 0x08 OE, 0x0C IRQ_RISE_EN, 0x10 IRQ_FALL_EN, 0x14 IRQ_PEND (W1C).

## VE / TE
See [ACCELERATORS.md](ACCELERATORS.md).
