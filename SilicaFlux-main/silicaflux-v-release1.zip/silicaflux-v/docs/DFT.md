# Design-for-test readiness

## Implemented in RTL (verified)

| Feature | Implementation | Evidence |
|---|---|---|
| JTAG TAP | `sfv_jtag_tap` (IEEE 1149.1 16-state FSM, 5-bit IR, Capture-IR = 01, IR/TDO on TCK fall, TDO enable only in Shift states) | formal: 5×TMS=1 → Test-Logic-Reset with IDCODE from any state, one-hot DR strobes (`formal/fv_tap.sv`, PDR PASS); SoC sim: IDCODE 0x15F05001, BYPASS |
| IDCODE | `{4'h1, 16'h5F05, 11'h000, 1}` | JEDEC manufacturer ID is a placeholder (ISS-010) |
| System-bus access (SBA) | IR 0x10, 66-bit DR, toggle-handshake CDC, crossbar master 0 | SoC sim: CHIP_ID read, bus-error detection, 2 400-word image load + read-back |
| Debug control | IR 0x11: CPU hold (reset), system reset, boot override | SoC sim: hold → load → mailbox boot |
| MBIST | `sfv_mbist` March C- (10N + checkerboard background), parallel banks, per-bank fail mask, first fail address/element, collars in `sfv_sram_slave` / `sfv_tile`; groups: 4 SRAM banks, 4 TSPM banks; reachable from CPU (SYSCTRL) **and JTAG (SBA)** | cocotb: stuck-at-0/1, transition, address-decoder alias, coupling faults detected (both backgrounds), exact location for stuck-at; SoC: boot ROM detects an injected stuck-at in bank 2 and refuses to boot |
| Test mode | `TEST_MODE` pin: every synchronised reset bypassed to RST_N (tester-controlled async resets); ICG `SCE` forces gated clocks on | RTL review; STA treats TEST_MODE as static (false path) |
| Clock-test control | `SYSCTRL.CLK_CTRL.TILE_CG_OFF` (functional override), ICG scan enable | regression identical with gating disabled |
| Clock gating cells | library ICGs (`sky130_fd_sc_hd__sdlclkp_1`, `sg13g2_slgcp_1`) via `asic/tech/*/sfv_clkgate.sv` | synthesis: exactly 2 ICG, 0 latches |
| Wafer/package self-test | boot mode 2 (POST): MBIST + SRAM + vector + tensor vs golden constants, PASS/FAIL on `TEST_PASS`/`TEST_FAIL` pins, UART log | SoC sim |

## Scan-insertion compatibility (synthesized netlist, sky130hd)
* 3 843 flops: 2 572 async-reset, 80 async-set, 1 185 non-reset, 6 TCK
  negative-edge (TAP IR/TDO, IEEE-mandated); 0 latches; 2 ICGs with scan
  enable; no combinational loops (`check -assert` passes); no internally
  generated clocks other than ICG outputs.
* All asynchronous resets are controllable from RST_N in TEST_MODE.
* Negative-edge TCK flops must be placed on a separate chain (or ordered at
  chain end) or excluded and covered by JTAG compliance patterns.
* SRAM macros are black boxes for ATPG: use the vendor's RAM-sequential
  models, or add bypass/observation logic around the collars (testcore
  `tc_mbist_collar` SCAN_BYPASS is the in-repo reference design).
* Scan in/out/enable pins: multiplex onto GPIO[7:0] in TEST_MODE at scan
  insertion (keeps the package at ≤ 32 signal leads).

## Remaining for commercial DFT signoff (not done in this release)
1. Scan insertion and stitching (Tessent / DFT Compiler / Genus; OpenROAD
   `insert_dft` is an experimental open alternative) with compression if the
   tester budget requires it; scan-shift timing.
2. ATPG: stuck-at and transition-delay pattern generation, fault coverage
   target ≥ 98 % stuck-at / ≥ 90 % TDF, with on-chip clock controller (OCC)
   for at-speed capture (not present — ISS-007).
3. Boundary-scan register and EXTEST/SAMPLE/PRELOAD (mandatory for 1149.1
   compliance; requires the pad ring) and BSDL — ISS-005.  The testcore
   `tc_bsr` + `silicaflux_v_testcore.bsd` are the starting point.
4. Production MBIST: vendor MBIST with repair (if redundancy macros are used),
   retention / data-retention tests, MBIST diagnosis output to ATE.
5. ROM signature (MISR) test and IDDQ test hooks.
6. JTAG compliance patterns, ATE test program, probe card, wafer map, binning,
   and the qualification plan (`SilicaFlux Production Test & Qualification
   Plan.pdf` in the source repository).
