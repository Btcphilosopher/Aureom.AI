import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

/**
 * SilicaFlux TwinLab Semiconductor Digital Twin API Endpoints
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    service: 'SilicaFlux TwinLab Simulation Engine',
    version: '4.2.0',
    mode: 'Demonstration Mode',
    supportedNodes: ['SKY130', 'GF180MCU', 'TSMC 65nm', 'TSMC 28nm', 'IHP SG13G2', '2nm GAAFET'],
    timestamp: new Date().toISOString()
  });
});

app.get('/api/eda/stages', (req, res) => {
  res.json({
    pipeline: 'ASIC Physical Design Flow',
    totalStages: 14,
    status: 'READY'
  });
});

app.post('/api/simulate/wafer', (req, res) => {
  const { waferDiameterMm = 200, dieWidthMm = 2.4, dieHeightMm = 2.4, d0 = 0.18, edgeExclusionMm = 3 } = req.body || {};
  const dieAreaMm2 = dieWidthMm * dieHeightMm;
  const usableDiameter = waferDiameterMm - 2 * edgeExclusionMm;
  const usableRadius = usableDiameter / 2;
  const gdpw = Math.floor(
    (Math.PI * Math.pow(usableRadius, 2)) / dieAreaMm2 -
    (Math.PI * usableDiameter) / Math.sqrt(2 * dieAreaMm2)
  );
  const d0A = d0 * (dieAreaMm2 / 100);
  const yieldMurphy = d0A > 0 ? Math.pow((1 - Math.exp(-d0A)) / d0A, 2) : 1.0;
  const netGood = Math.floor(gdpw * yieldMurphy);

  res.json({
    waferDiameterMm,
    dieAreaMm2,
    grossDiesPerWafer: gdpw,
    netGoodDies: netGood,
    yieldPct: Number((yieldMurphy * 100).toFixed(2))
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
