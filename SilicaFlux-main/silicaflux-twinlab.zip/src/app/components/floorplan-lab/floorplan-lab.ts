import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';
import { SemiconductorPhysicsService, FloorplanAnnealResult } from '../../services/semiconductor-physics';
import { SemiconductorBlock } from '../../models/semiconductor.models';

@Component({
  selector: 'app-floorplan-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './floorplan-lab.html'
})
export class FloorplanLab {
  public state = inject(TwinLabStateService);
  private physics = inject(SemiconductorPhysicsService);

  public isOptimizing = signal<boolean>(false);
  public annealProgress = signal<number>(0);
  public currentCost = signal<number>(142800);
  public initialCost = signal<number>(245000);
  public annealHistory = signal<{ iteration: number; cost: number; temp: number }[]>([]);

  // Dragging state
  public activeDragBlockId = signal<string | null>(null);
  private dragStartX = 0;
  private dragStartY = 0;
  private blockOrigX = 0;
  private blockOrigY = 0;

  // Selected block for property editing
  public selectedBlock = this.state.selectedBlock;

  // Current HPWL (Half Perimeter Wire Length)
  public hpwlMetric = computed(() => {
    const blocks = this.state.blocks();
    let hpwl = 0;
    const blockMap = new Map<string, SemiconductorBlock>();
    blocks.forEach(b => blockMap.set(b.id, b));

    const nets = [
      { b1: 'cpu_core_0', b2: 'vector_unit' },
      { b1: 'vector_unit', b2: 'tensor_array' },
      { b1: 'tensor_array', b2: 'sram_bank_1' },
      { b1: 'sram_bank_0', b2: 'noc_router' },
      { b1: 'noc_router', b2: 'mem_ctrl' }
    ];

    for (const net of nets) {
      const b1 = blockMap.get(net.b1);
      const b2 = blockMap.get(net.b2);
      if (b1 && b2) {
        const c1x = b1.x + b1.width / 2;
        const c1y = b1.y + b1.height / 2;
        const c2x = b2.x + b2.width / 2;
        const c2y = b2.y + b2.height / 2;
        hpwl += Math.abs(c1x - c2x) + Math.abs(c1y - c2y);
      }
    }
    return Math.round(hpwl);
  });

  public runAnnealingOptimizer() {
    this.isOptimizing.set(true);
    this.annealProgress.set(10);
    this.state.logConsole('INFO', 'Initiating Simulated Annealing Floorplan Optimization...', 'FloorplanEngine');

    setTimeout(() => {
      const res: FloorplanAnnealResult = this.physics.runSimulatedAnnealing(
        this.state.dieWidthUm(),
        this.state.dieHeightUm(),
        this.state.blocks(),
        350
      );

      this.initialCost.set(res.initialCost);
      this.currentCost.set(res.finalCost);
      this.annealHistory.set(res.history);
      this.state.setBlocks(res.blocks);
      this.isOptimizing.set(false);
      this.annealProgress.set(100);

      this.state.logConsole('SUCCESS', `Floorplan converged. HPWL reduced to ${res.hpwl} μm. Area utilization: ${res.areaUtilizationPct}%.`, 'FloorplanEngine');
    }, 600);
  }

  public rotateBlock(blockId: string) {
    this.state.blocks.update(blocks => 
      blocks.map(b => {
        if (b.id === blockId && !b.locked) {
          const w = b.width;
          return { ...b, width: b.height, height: w };
        }
        return b;
      })
    );
    this.state.logConsole('INFO', `Rotated block ${blockId} by 90 degrees.`, 'Floorplan');
  }

  public toggleLockBlock(blockId: string) {
    this.state.blocks.update(blocks => 
      blocks.map(b => b.id === blockId ? { ...b, locked: !b.locked } : b)
    );
  }

  // Pointer drag for block movement
  public onBlockPointerDown(e: PointerEvent, block: SemiconductorBlock) {
    if (block.locked || block.type === 'IO_PAD_RING') return;
    this.activeDragBlockId.set(block.id);
    this.state.selectBlock(block.id);
    this.dragStartX = e.clientX;
    this.dragStartY = e.clientY;
    this.blockOrigX = block.x;
    this.blockOrigY = block.y;
    e.stopPropagation();
  }

  public onCanvasPointerMove(e: PointerEvent) {
    const id = this.activeDragBlockId();
    if (!id) return;

    // Scale factor: canvas 600px = 2400um -> 1px = 4um
    const scaleFactor = 2400 / 600;
    const deltaX = (e.clientX - this.dragStartX) * scaleFactor;
    const deltaY = (e.clientY - this.dragStartY) * scaleFactor;

    let newX = Math.round((this.blockOrigX + deltaX) / 10) * 10;
    let newY = Math.round((this.blockOrigY + deltaY) / 10) * 10;

    newX = Math.max(120, Math.min(2400 - 300, newX));
    newY = Math.max(120, Math.min(2400 - 300, newY));

    this.state.updateBlockPosition(id, newX, newY);
  }

  public onCanvasPointerUp() {
    this.activeDragBlockId.set(null);
  }
}
