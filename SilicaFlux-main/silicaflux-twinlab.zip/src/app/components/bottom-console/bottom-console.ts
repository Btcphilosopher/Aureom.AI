import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

@Component({
  selector: 'app-bottom-console',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './bottom-console.html'
})
export class BottomConsole {
  public state = inject(TwinLabStateService);

  public isExpanded = signal<boolean>(false);
  public activeFilter = signal<'ALL' | 'INFO' | 'WARN' | 'ERROR' | 'TIMING'>('ALL');

  public toggleExpand() {
    this.isExpanded.update(v => !v);
  }

  public setFilter(filter: 'ALL' | 'INFO' | 'WARN' | 'ERROR' | 'TIMING') {
    this.activeFilter.set(filter);
  }

  public clearLogs() {
    this.state.consoleLogs.set([]);
    this.state.logConsole('INFO', 'Console telemetry log cleared.', 'System');
  }
}
