import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';
import { TapeoutGate } from '../../models/semiconductor.models';

@Component({
  selector: 'app-tapeout-readiness',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './tapeout-readiness.html'
})
export class TapeoutReadiness {
  public state = inject(TwinLabStateService);

  public gates = this.state.tapeoutGates;

  public approvedCount = computed(() => {
    return this.gates().filter(g => g.status === 'APPROVED').length;
  });

  public isTapeoutApproved = computed(() => {
    return this.approvedCount() === 10;
  });

  public toggleGateStatus(gate: TapeoutGate) {
    this.gates.update(list => 
      list.map(g => {
        if (g.gateNumber === gate.gateNumber) {
          const nextStatus = g.status === 'APPROVED' ? 'IN_REVIEW' : 'APPROVED';
          return { ...g, status: nextStatus };
        }
        return g;
      })
    );
    this.state.logConsole('INFO', `Gate ${gate.gateNumber} status toggled.`, 'TapeoutEngine');
  }
}
