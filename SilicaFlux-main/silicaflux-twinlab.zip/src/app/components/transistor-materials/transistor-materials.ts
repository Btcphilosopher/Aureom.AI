import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

export type DeviceModelType = 'planar' | 'finfet' | 'gaafet' | 'sram_6t' | 'metal_stack';

@Component({
  selector: 'app-transistor-materials',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './transistor-materials.html'
})
export class TransistorMaterials {
  public state = inject(TwinLabStateService);

  public selectedDevice = signal<DeviceModelType>('planar');

  public selectDevice(dev: DeviceModelType) {
    this.selectedDevice.set(dev);
    this.state.logConsole('INFO', `Switched Transistor & Materials device inspection to: ${dev.toUpperCase()}`, 'MaterialsLab');
  }
}
