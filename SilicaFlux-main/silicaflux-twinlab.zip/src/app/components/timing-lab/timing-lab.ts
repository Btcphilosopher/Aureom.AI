import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';
import { TimingPath } from '../../models/semiconductor.models';

@Component({
  selector: 'app-timing-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './timing-lab.html'
})
export class TimingLab {
  public state = inject(TwinLabStateService);

  public selectedPath = signal<TimingPath>(this.state.timingPaths()[0]);
  public targetFreqMhz = signal<number>(125);
  public clockUncertaintyPs = signal<number>(150);

  // Recalculated slack based on interactive frequency target
  public dynamicWnsPs = computed(() => {
    const periodPs = (1000 / this.targetFreqMhz()) * 1000;
    const path = this.selectedPath();
    const effectiveRequired = periodPs - this.clockUncertaintyPs();
    return Math.round(effectiveRequired - path.dataDelayPs);
  });

  public isTimingViolated = computed(() => {
    return this.dynamicWnsPs() < 0;
  });

  public selectPath(path: TimingPath) {
    this.selectedPath.set(path);
    this.state.logConsole('INFO', `Selected timing path: ${path.id} (${path.name})`, 'OpenSTA');
  }

  public updateFreq(freq: number) {
    this.targetFreqMhz.set(freq);
  }
}
