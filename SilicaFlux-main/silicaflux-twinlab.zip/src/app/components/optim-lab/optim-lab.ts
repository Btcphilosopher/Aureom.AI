import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

export interface ParetoPoint {
  id: string;
  name: string;
  family: string;
  node: string;
  cores: number;
  lanes: number;
  tensorDim: number;
  throughputGflops: number;
  powerMw: number;
  areaMm2: number;
  costUsd: number;
  confidence: 'MEASURED' | 'EDA-DERIVED' | 'MODELLED' | 'HYPOTHETICAL';
  isParetoOptimal: boolean;
}

@Component({
  selector: 'app-optim-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './optim-lab.html'
})
export class OptimLab {
  public state = inject(TwinLabStateService);

  public selectedPoint = signal<ParetoPoint | null>(null);

  public paretoPoints: ParetoPoint[] = [
    {
      id: 'cfg_01',
      name: 'SilicaFlux-V (1-Core, 4-Lane, 4x4 MAC)',
      family: 'SilicaFlux-V',
      node: 'SKY130 (130nm)',
      cores: 1,
      lanes: 4,
      tensorDim: 4,
      throughputGflops: 5.25,
      powerMw: 195,
      areaMm2: 2.18,
      costUsd: 14.80,
      confidence: 'EDA-DERIVED',
      isParetoOptimal: true
    },
    {
      id: 'cfg_02',
      name: 'SilicaFlux Full (4-Core, 8-Lane, 8x8 MAC)',
      family: 'SilicaFlux',
      node: 'TSMC 65nm',
      cores: 4,
      lanes: 8,
      tensorDim: 8,
      throughputGflops: 68.4,
      powerMw: 840,
      areaMm2: 4.85,
      costUsd: 28.50,
      confidence: 'MODELLED',
      isParetoOptimal: true
    },
    {
      id: 'cfg_03',
      name: 'SilicaFlux-X (2-Core, 8-Lane, 16x16 Tensor)',
      family: 'SilicaFlux-X',
      node: 'TSMC 28nm',
      cores: 2,
      lanes: 8,
      tensorDim: 16,
      throughputGflops: 486.0,
      powerMw: 2450,
      areaMm2: 6.20,
      costUsd: 42.00,
      confidence: 'MODELLED',
      isParetoOptimal: true
    },
    {
      id: 'cfg_04',
      name: 'SilicaFlux-M (16-Core Tiled Manycore)',
      family: 'SilicaFlux-M',
      node: 'TSMC 28nm',
      cores: 16,
      lanes: 4,
      tensorDim: 8,
      throughputGflops: 320.0,
      powerMw: 3800,
      areaMm2: 14.50,
      costUsd: 85.00,
      confidence: 'HYPOTHETICAL',
      isParetoOptimal: false
    },
    {
      id: 'cfg_05',
      name: 'SilicaFlux-C (8-Core 2.5D Chiplet)',
      family: 'SilicaFlux-C',
      node: '2nm GAAFET + 65nm I/O',
      cores: 8,
      lanes: 16,
      tensorDim: 16,
      throughputGflops: 1250.0,
      powerMw: 4200,
      areaMm2: 18.00,
      costUsd: 145.00,
      confidence: 'HYPOTHETICAL',
      isParetoOptimal: true
    }
  ];

  constructor() {
    this.selectedPoint.set(this.paretoPoints[0]);
  }

  public selectPoint(pt: ParetoPoint) {
    this.selectedPoint.set(pt);
  }
}
