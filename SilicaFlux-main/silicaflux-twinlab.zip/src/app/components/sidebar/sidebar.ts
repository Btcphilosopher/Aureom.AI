import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService, MainNavTab } from '../../services/twinlab-state';

export interface NavItem {
  id: MainNavTab;
  label: string;
  icon: string;
  badge?: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './sidebar.html'
})
export class Sidebar {
  public state = inject(TwinLabStateService);

  public navItems: NavItem[] = [
    { id: 'twin3d', label: 'Digital Twin 3D', icon: 'view_in_ar' },
    { id: 'rtl', label: 'RTL Explorer', icon: 'code', badge: '8 files' },
    { id: 'arch', label: 'Architecture', icon: 'tune' },
    { id: 'nodes', label: 'Process Nodes', icon: 'precision_manufacturing', badge: '6 PDKs' },
    { id: 'floorplan', label: 'Floorplan Lab', icon: 'dashboard_customize' },
    { id: 'materials', label: 'Transistor & Materials', icon: 'layers' },
    { id: 'memory', label: 'Memory & Roofline', icon: 'speed' },
    { id: 'timing', label: 'Clock & Timing', icon: 'timer', badge: '+65ps' },
    { id: 'power', label: 'Power Integrity', icon: 'bolt', badge: '1.8V' },
    { id: 'thermal', label: 'Thermal Digital Twin', icon: 'thermostat', badge: '44°C' },
    { id: 'interconnect', label: 'Placement & Routing', icon: 'route' },
    { id: 'manufacturing', label: 'Wafer Yield & Cost', icon: 'monetization_on' },
    { id: 'optim', label: 'Optimisation Lab', icon: 'stacked_line_chart' },
    { id: 'verification', label: 'Verification & DFT', icon: 'fact_check' },
    { id: 'tapeout', label: 'Tapeout Readiness', icon: 'gavel', badge: '10/10' },
    { id: 'reports', label: 'Reports & Export', icon: 'description' }
  ];

  public selectTab(id: MainNavTab) {
    this.state.setTab(id);
    this.state.logConsole('INFO', `Navigated to workspace: ${id.toUpperCase()}`, 'Navigation');
  }
}
