import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';
import { ProcessNodeProfile } from '../../models/semiconductor.models';

@Component({
  selector: 'app-process-nodes',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './process-nodes.html'
})
export class ProcessNodes {
  public state = inject(TwinLabStateService);

  public selectNode(node: ProcessNodeProfile) {
    this.state.setProcessNode(node.id);
  }
}
