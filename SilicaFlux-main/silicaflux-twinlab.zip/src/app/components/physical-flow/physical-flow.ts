import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';
import { EdaStage } from '../../models/semiconductor.models';

@Component({
  selector: 'app-physical-flow',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './physical-flow.html'
})
export class PhysicalFlow {
  public state = inject(TwinLabStateService);

  public selectedStage = signal<EdaStage>(this.state.edaStages()[2]); // Synthesis by default
  public isRunningPipeline = signal<boolean>(false);

  public selectStage(stage: EdaStage) {
    this.selectedStage.set(stage);
    this.state.logConsole('INFO', `Inspecting EDA Stage ${stage.number}: ${stage.name} (${stage.tool})`, 'FlowOrchestrator');
  }

  public runFullFlow() {
    this.isRunningPipeline.set(true);
    this.state.runEdaFlow();
    setTimeout(() => {
      this.isRunningPipeline.set(false);
    }, 1400);
  }
}
