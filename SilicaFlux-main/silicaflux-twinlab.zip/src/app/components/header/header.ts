import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';
import { SilicaFluxFamily, FidelityLevel } from '../../models/semiconductor.models';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './header.html'
})
export class Header {
  public state = inject(TwinLabStateService);

  public families: SilicaFluxFamily[] = [
    'SilicaFlux-V',
    'SilicaFlux',
    'SilicaFlux-X',
    'SilicaFlux-M',
    'SilicaFlux-C'
  ];

  public fidelityLevels: FidelityLevel[] = ['LEVEL_1', 'LEVEL_2', 'LEVEL_3'];

  public setFamily(family: SilicaFluxFamily) {
    this.state.setFamily(family);
  }

  public setProcessNode(nodeId: string) {
    this.state.setProcessNode(nodeId);
  }

  public setFidelity(lvl: FidelityLevel) {
    this.state.setFidelity(lvl);
  }
}
