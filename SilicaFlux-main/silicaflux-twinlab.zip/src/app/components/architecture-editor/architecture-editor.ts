import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

@Component({
  selector: 'app-architecture-editor',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './architecture-editor.html'
})
export class ArchitectureEditor {
  public state = inject(TwinLabStateService);

  public arch = this.state.archConfig;

  // Real-time calculated gate count impact
  public estimatedGateCount = computed(() => {
    const a = this.arch();
    const cpuGates = a.cpu.coreCount * 42000 * (a.cpu.pipelineStages / 5);
    const vecGates = a.vector.laneCount * 17000 * (a.vector.datapathWidthBits / 128);
    const tensorGates = (a.tensor.macArrayDim * a.tensor.macArrayDim) * 5800;
    const sramLogic = a.memory.sramBankCount * 12000;
    const xbarGates = (a.interconnect.busWidthBits / 32) * 14000;
    return Math.round(cpuGates + vecGates + tensorGates + sramLogic + xbarGates);
  });

  public estimatedDieAreaMm2 = computed(() => {
    const gates = this.estimatedGateCount();
    const density = this.state.activeNode().gateDensityKgatesPerMm2;
    // Core area + 35% routing whitespace + IO ring
    const rawMm2 = (gates / 1000) / density;
    return Number((rawMm2 * 1.35 + 0.55).toFixed(2));
  });

  public updateCpuCores(cores: number) {
    this.arch.update(c => ({
      ...c,
      cpu: { ...c.cpu, coreCount: cores }
    }));
    this.state.logConsole('INFO', `CPU Core count updated to ${cores}. RTL parameter: PARAM_CPU_CORES`, 'ArchEditor');
  }

  public updateCpuFreq(freq: number) {
    this.arch.update(c => ({
      ...c,
      cpu: { ...c.cpu, freqTargetMhz: freq }
    }));
  }

  public updateVectorLanes(lanes: number) {
    this.arch.update(c => ({
      ...c,
      vector: { ...c.vector, laneCount: lanes }
    }));
    this.state.logConsole('INFO', `Vector SIMD lanes updated to ${lanes}. RTL parameter: SIMD_LANES`, 'ArchEditor');
  }

  public updateTensorDim(dim: number) {
    this.arch.update(c => ({
      ...c,
      tensor: { ...c.tensor, macArrayDim: dim }
    }));
    this.state.logConsole('INFO', `Tensor MAC Array dimension set to ${dim}x${dim}. RTL parameter: TENSOR_DIM`, 'ArchEditor');
  }

  public updateSramBanks(banks: number) {
    this.arch.update(c => ({
      ...c,
      memory: { ...c.memory, sramBankCount: banks }
    }));
  }

  public updateSramMacroSize(sizeKb: number) {
    this.arch.update(c => ({
      ...c,
      memory: { ...c.memory, sramMacroSizeKb: sizeKb }
    }));
  }

  public updateInterconnectTopology(topology: 'Crossbar' | 'Ring' | '2D-Mesh' | 'Bus') {
    this.arch.update(c => ({
      ...c,
      interconnect: { ...c.interconnect, topology }
    }));
  }

  public updateEccMode(ecc: 'None' | 'Parity' | 'SECDED') {
    this.arch.update(c => ({
      ...c,
      memory: { ...c.memory, eccMode: ecc }
    }));
  }
}
