import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

@Component({
  selector: 'app-wafer-economics',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './wafer-economics.html'
})
export class WaferEconomics {
  public state = inject(TwinLabStateService);

  public wafer = this.state.waferYieldResult;

  public productionVolume = signal<number>(50000);
  public selectedYieldModel = signal<'murphy' | 'poisson'>('murphy');

  public updateVolume(vol: number) {
    this.productionVolume.set(vol);
  }
}
