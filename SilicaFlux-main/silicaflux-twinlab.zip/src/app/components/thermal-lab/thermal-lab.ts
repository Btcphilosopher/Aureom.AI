import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

@Component({
  selector: 'app-thermal-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './thermal-lab.html'
})
export class ThermalLab {
  public state = inject(TwinLabStateService);

  public thermal = this.state.thermalResult;

  public selectedCooling = signal<'passive' | 'active_air' | 'vapor_chamber' | 'liquid'>('active_air');
  public ambientTempC = signal<number>(25.0);

  public selectCooling(cooling: 'passive' | 'active_air' | 'vapor_chamber' | 'liquid') {
    this.selectedCooling.set(cooling);
    this.state.logConsole('INFO', `Thermal cooling package switched to: ${cooling.toUpperCase()}`, 'ThermalSolver');
  }

  public updateAmbient(temp: number) {
    this.ambientTempC.set(temp);
  }
}
