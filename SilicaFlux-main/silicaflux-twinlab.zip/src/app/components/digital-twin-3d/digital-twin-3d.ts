import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  OnDestroy, 
  OnInit, 
  ViewChild, 
  inject, 
  signal,
  effect,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { TwinLabStateService } from '../../services/twinlab-state';
import { SemiconductorBlock, OverlayMode, MetalLayerInfo } from '../../models/semiconductor.models';

@Component({
  selector: 'app-digital-twin-3d',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './digital-twin-3d.html',
  styleUrl: './digital-twin-3d.css'
})
export class DigitalTwin3d implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  public state = inject(TwinLabStateService);

  // Viewport State
  public isWireframe = signal<boolean>(false);
  public isAutorotate = signal<boolean>(false);
  public activeHoverBlock = signal<string | null>(null);

  // Three.js internal objects
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private blockMeshes = new Map<string, THREE.Mesh>();
  private layerGroup = new THREE.Group();
  private clockTreeGroup = new THREE.Group();
  private powerMeshGroup = new THREE.Group();
  private timingPathGroup = new THREE.Group();
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // Camera Orbit & Pan state
  private isPointerDown = false;
  private pointerButton = 0; // 0: left, 2: right
  private prevPointerX = 0;
  private prevPointerY = 0;
  private spherical = { radius: 3800, theta: Math.PI / 4, phi: Math.PI / 3 };
  private target = new THREE.Vector3(1200, 0, 1200);

  private platformId = inject(PLATFORM_ID);

  constructor() {
    // React to overlay changes
    effect(() => {
      const overlay = this.state.activeOverlay();
      if (isPlatformBrowser(this.platformId)) {
        this.updateBlockMaterials(overlay);
      }
    });

    // React to 2D vs 3D changes
    effect(() => {
      const is2d = this.state.is2dView();
      if (isPlatformBrowser(this.platformId)) {
        if (is2d) {
          this.spherical.theta = 0;
          this.spherical.phi = 0.001; // directly looking down
        } else {
          this.spherical.theta = Math.PI / 4;
          this.spherical.phi = Math.PI / 3;
        }
        this.updateCameraPosition();
      }
    });

    // React to layer visibility changes
    effect(() => {
      const layers = this.state.metalLayers();
      if (isPlatformBrowser(this.platformId)) {
        this.updateMetalLayersVisibility(layers);
      }
    });

    // React to block positions update (e.g. from floorplan optimizer)
    effect(() => {
      const blocks = this.state.blocks();
      if (isPlatformBrowser(this.platformId)) {
        this.syncBlockPositions(blocks);
      }
    });

    // React to exploded view
    effect(() => {
      const isExploded = this.state.isExplodedView();
      if (isPlatformBrowser(this.platformId)) {
        this.applyExplodedView(isExploded);
      }
    });
  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.initThreeJs();
    }
  }

  ngOnDestroy() {
    if (isPlatformBrowser(this.platformId)) {
      if (this.animationFrameId !== null) {
        cancelAnimationFrame(this.animationFrameId);
      }
      if (this.renderer) {
        this.renderer.dispose();
      }
      window.removeEventListener('resize', this.onResize);
      window.removeEventListener('pointermove', this.onPointerMove);
      window.removeEventListener('pointerup', this.onPointerUp);
    }
  }

  private initThreeJs() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x040810);

    // Camera
    this.camera = new THREE.PerspectiveCamera(40, width / height, 50, 25000);
    this.updateCameraPosition();

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xfff7ed, 1.6);
    dirLight1.position.set(2000, 4000, 2000);
    dirLight1.castShadow = true;
    dirLight1.shadow.mapSize.width = 2048;
    dirLight1.shadow.mapSize.height = 2048;
    this.scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x0ea5e9, 0.6); // Cyan rim light
    dirLight2.position.set(-2000, 1500, -2000);
    this.scene.add(dirLight2);

    // Build Silicon Substrate, Seal Ring, and Blocks
    this.buildSiliconSubstrate();
    this.buildSemiconductorBlocks();
    this.buildMetalRoutingLayers();
    this.buildClockTreeNetwork();
    this.buildPowerMeshGrid();
    this.buildCriticalTimingArc();

    // Event listeners
    container.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    container.addEventListener('wheel', this.onWheel, { passive: false });
    window.addEventListener('resize', this.onResize);

    // Render loop
    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);

      if (this.isAutorotate()) {
        this.spherical.theta += 0.003;
        this.updateCameraPosition();
      }

      this.renderer.render(this.scene, this.camera);
    };
    animate();
  }

  private buildSiliconSubstrate() {
    const dieW = this.state.dieWidthUm();
    const dieH = this.state.dieHeightUm();

    // Bulk Silicon Base (Dark polished gray-blue wafer material)
    const subGeo = new THREE.BoxGeometry(dieW, 80, dieH);
    const subMat = new THREE.MeshStandardMaterial({
      color: 0x090f1d,
      roughness: 0.25,
      metalness: 0.85,
    });
    const subMesh = new THREE.Mesh(subGeo, subMat);
    subMesh.position.set(dieW / 2, -40, dieH / 2);
    subMesh.receiveShadow = true;
    this.scene.add(subMesh);

    // Silicon Substrate Bevel / Chamfer Seal Ring (Golden edge barrier)
    const sealGeo = new THREE.BoxGeometry(dieW + 80, 85, dieH + 80);
    const sealEdges = new THREE.EdgesGeometry(sealGeo);
    const sealLine = new THREE.LineSegments(
      sealEdges,
      new THREE.LineBasicMaterial({ color: 0xd97706, linewidth: 2 })
    );
    sealLine.position.set(dieW / 2, -40, dieH / 2);
    this.scene.add(sealLine);

    // Coordinate grid overlay on substrate (Fine EDA track grid)
    const gridHelper = new THREE.GridHelper(dieW, 24, 0x0ea5e9, 0x1e293b);
    gridHelper.position.set(dieW / 2, 0.5, dieH / 2);
    this.scene.add(gridHelper);

    // Die Orientation Notch (Foundry Corner Fiducial at origin)
    const fiducialGeo = new THREE.ConeGeometry(50, 100, 4);
    const fiducialMat = new THREE.MeshBasicMaterial({ color: 0xd97706 });
    const fiducial = new THREE.Mesh(fiducialGeo, fiducialMat);
    fiducial.position.set(60, 50, 60);
    this.scene.add(fiducial);
  }

  private buildSemiconductorBlocks() {
    const blocks = this.state.blocks();
    this.blockMeshes.clear();

    for (const b of blocks) {
      if (b.type === 'IO_PAD_RING') {
        this.buildIoPadRingMesh();
        continue;
      }

      const h = 45; // Block 3D thickness
      const geo = new THREE.BoxGeometry(b.width, h, b.height);
      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(b.color),
        roughness: 0.35,
        metalness: 0.65,
        transparent: true,
        opacity: 0.92
      });

      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(b.x + b.width / 2, h / 2, b.y + b.height / 2);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData = { 
        blockId: b.id, 
        originalColor: b.color,
        initialWidth: b.width,
        initialDepth: b.height
      };

      // Add wireframe boundary edge
      const edges = new THREE.EdgesGeometry(geo);
      const edgeLine = new THREE.LineSegments(
        edges,
        new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 })
      );
      mesh.add(edgeLine);

      this.scene.add(mesh);
      this.blockMeshes.set(b.id, mesh);
    }
  }

  private buildIoPadRingMesh() {
    const dieW = this.state.dieWidthUm();
    const dieH = this.state.dieHeightUm();
    const padGroup = new THREE.Group();
    padGroup.name = 'io_pads';

    const padCountPerSide = 16;
    const padSize = 65;
    const padHeight = 25;
    const padMat = new THREE.MeshStandardMaterial({
      color: 0xd97706, // Gold bond pads
      metalness: 0.95,
      roughness: 0.15
    });

    // Perimeter pads
    const padSpacingX = (dieW - 200) / padCountPerSide;
    const padSpacingY = (dieH - 200) / padCountPerSide;

    for (let i = 0; i < padCountPerSide; i++) {
      // Top & Bottom pads
      const pTop = new THREE.Mesh(new THREE.BoxGeometry(padSize, padHeight, padSize), padMat);
      pTop.position.set(100 + i * padSpacingX, padHeight / 2, 70);
      padGroup.add(pTop);

      const pBottom = new THREE.Mesh(new THREE.BoxGeometry(padSize, padHeight, padSize), padMat);
      pBottom.position.set(100 + i * padSpacingX, padHeight / 2, dieH - 70);
      padGroup.add(pBottom);

      // Left & Right pads
      const pLeft = new THREE.Mesh(new THREE.BoxGeometry(padSize, padHeight, padSize), padMat);
      pLeft.position.set(70, padHeight / 2, 100 + i * padSpacingY);
      padGroup.add(pLeft);

      const pRight = new THREE.Mesh(new THREE.BoxGeometry(padSize, padHeight, padSize), padMat);
      pRight.position.set(dieW - 70, padHeight / 2, 100 + i * padSpacingY);
      padGroup.add(pRight);
    }

    this.scene.add(padGroup);
  }

  private buildMetalRoutingLayers() {
    this.layerGroup.clear();
    const dieW = this.state.dieWidthUm();
    const dieH = this.state.dieHeightUm();
    const layers = this.state.metalLayers();

    // Render stylized physical routing tracks for each metal layer
    layers.forEach((layer, idx) => {
      const subLayerGroup = new THREE.Group();
      subLayerGroup.name = layer.layer;

      const trackCount = 18;
      const trackThickness = 6;
      const trackWidth = layer.layer === 'M5' ? 14 : 6;
      const zElev = 55 + idx * 22;

      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(layer.color),
        metalness: 0.9,
        roughness: 0.25,
        transparent: true,
        opacity: layer.layer === 'M5' ? 0.95 : 0.65
      });

      if (layer.direction === 'horizontal') {
        const step = (dieH - 400) / trackCount;
        for (let i = 0; i < trackCount; i++) {
          if (i % 2 === 0) continue; // sparse realistic channels
          const trackGeo = new THREE.BoxGeometry(dieW - 400, trackThickness, trackWidth);
          const trackMesh = new THREE.Mesh(trackGeo, mat);
          trackMesh.position.set(dieW / 2, zElev, 200 + i * step);
          subLayerGroup.add(trackMesh);
        }
      } else {
        const step = (dieW - 400) / trackCount;
        for (let i = 0; i < trackCount; i++) {
          if (i % 2 === 0) continue;
          const trackGeo = new THREE.BoxGeometry(trackWidth, trackThickness, dieH - 400);
          const trackMesh = new THREE.Mesh(trackGeo, mat);
          trackMesh.position.set(200 + i * step, zElev, dieH / 2);
          subLayerGroup.add(trackMesh);
        }
      }

      // Add vertical via columns connecting between layers
      if (idx > 0) {
        const viaGeo = new THREE.CylinderGeometry(4, 4, 22, 6);
        const viaMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.2 });
        for (let v = 0; v < 12; v++) {
          const via = new THREE.Mesh(viaGeo, viaMat);
          via.position.set(400 + (v % 4) * 450, zElev - 11, 400 + Math.floor(v / 4) * 450);
          subLayerGroup.add(via);
        }
      }

      this.layerGroup.add(subLayerGroup);
    });

    this.scene.add(this.layerGroup);
  }

  private buildClockTreeNetwork() {
    this.clockTreeGroup.clear();
    const dieW = this.state.dieWidthUm();
    const dieH = this.state.dieHeightUm();

    // H-Tree symmetrical clock distribution network in electric cyan
    const lineMat = new THREE.LineBasicMaterial({ color: 0x06b6d4, linewidth: 3 });
    const points: THREE.Vector3[] = [];

    // Root PLL to Central Spine
    const yElev = 175;
    const cx = dieW / 2;
    const cy = dieH / 2;

    // PLL source at (530, yElev, 1690)
    points.push(new THREE.Vector3(530, yElev, 1690));
    points.push(new THREE.Vector3(cx, yElev, cy));

    // Level 1 H-Tree
    points.push(new THREE.Vector3(cx - 500, yElev, cy));
    points.push(new THREE.Vector3(cx + 500, yElev, cy));

    // Left vertical spine
    points.push(new THREE.Vector3(cx - 500, yElev, cy - 400));
    points.push(new THREE.Vector3(cx - 500, yElev, cy + 400));

    // Right vertical spine
    points.push(new THREE.Vector3(cx + 500, yElev, cy - 400));
    points.push(new THREE.Vector3(cx + 500, yElev, cy + 400));

    const geo = new THREE.BufferGeometry().setFromPoints(points);
    const treeLines = new THREE.LineSegments(geo, lineMat);
    this.clockTreeGroup.add(treeLines);

    // Clock Buffers at branch nodes
    const bufGeo = new THREE.BoxGeometry(22, 16, 22);
    const bufMat = new THREE.MeshBasicMaterial({ color: 0x0ea5e9 });
    [
      { x: cx, z: cy },
      { x: cx - 500, z: cy },
      { x: cx + 500, z: cy },
      { x: cx - 500, z: cy - 400 },
      { x: cx - 500, z: cy + 400 },
      { x: cx + 500, z: cy - 400 },
      { x: cx + 500, z: cy + 400 }
    ].forEach(pos => {
      const buf = new THREE.Mesh(bufGeo, bufMat);
      buf.position.set(pos.x, yElev, pos.z);
      this.clockTreeGroup.add(buf);
    });

    this.scene.add(this.clockTreeGroup);
  }

  private buildPowerMeshGrid() {
    this.powerMeshGroup.clear();
    const dieW = this.state.dieWidthUm();

    // VDD and VSS heavy top-metal straps
    const vddMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9, roughness: 0.3 }); // Amber
    const vssMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8, roughness: 0.4 }); // Slate

    const strapY = 195;
    for (let i = 0; i < 8; i++) {
      const z = 300 + i * 240;
      const isVdd = i % 2 === 0;
      const strapGeo = new THREE.BoxGeometry(dieW - 240, 10, 18);
      const mesh = new THREE.Mesh(strapGeo, isVdd ? vddMat : vssMat);
      mesh.position.set(dieW / 2, strapY, z);
      this.powerMeshGroup.add(mesh);
    }

    this.scene.add(this.powerMeshGroup);
  }

  private buildCriticalTimingArc() {
    this.timingPathGroup.clear();

    // Critical timing arc between Vector Unit and Tensor Array
    const curve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(1250, 60, 580),
      new THREE.Vector3(1250, 240, 730),
      new THREE.Vector3(1250, 60, 920)
    );

    const points = curve.getPoints(32);
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    const mat = new THREE.LineBasicMaterial({ color: 0xec4899, linewidth: 4 });
    const arc = new THREE.Line(geo, mat);
    this.timingPathGroup.add(arc);

    // Glowing endpoint markers
    const markerGeo = new THREE.SphereGeometry(14, 16, 16);
    const markerMat = new THREE.MeshBasicMaterial({ color: 0xec4899 });
    const startM = new THREE.Mesh(markerGeo, markerMat);
    startM.position.copy(points[0]);
    const endM = new THREE.Mesh(markerGeo, markerMat);
    endM.position.copy(points[points.length - 1]);

    this.timingPathGroup.add(startM);
    this.timingPathGroup.add(endM);

    this.scene.add(this.timingPathGroup);
  }

  private updateBlockMaterials(overlay: OverlayMode) {
    const blocks = this.state.blocks();

    for (const b of blocks) {
      const mesh = this.blockMeshes.get(b.id);
      if (!mesh) continue;

      const mat = mesh.material as THREE.MeshStandardMaterial;

      if (overlay === 'none') {
        mat.color.set(b.color);
        mat.emissive.set(0x000000);
      } else if (overlay === 'thermal') {
        // Temperature gradient from 25C (cyan/blue) to 75C+ (hot red/white)
        const temp = b.temperatureC || 40;
        const normalized = Math.min(1, Math.max(0, (temp - 25) / 50));
        const color = new THREE.Color();
        color.setHSL(0.65 * (1 - normalized), 0.95, 0.5);
        mat.color.copy(color);
        mat.emissive.copy(color).multiplyScalar(0.2);
      } else if (overlay === 'irdrop') {
        // IR drop gradient: 0mV (cyan) to 50mV (amber/red)
        const drop = b.irDropMv || 10;
        const normalized = Math.min(1, Math.max(0, drop / 50));
        const color = new THREE.Color();
        color.setHSL(0.55 * (1 - normalized), 0.9, 0.45);
        mat.color.copy(color);
        mat.emissive.copy(color).multiplyScalar(0.15);
      } else if (overlay === 'congestion') {
        // Metal density congestion
        const density = b.metalDensity;
        const color = density > 0.75 ? new THREE.Color(0xef4444) : (density > 0.6 ? new THREE.Color(0xf59e0b) : new THREE.Color(0x10b981));
        mat.color.copy(color);
        mat.emissive.copy(color).multiplyScalar(0.1);
      } else if (overlay === 'critical_path') {
        const isCritical = b.id === 'tensor_array' || b.id === 'vector_unit';
        mat.color.set(isCritical ? 0xec4899 : 0x1e293b);
        mat.emissive.set(isCritical ? 0x3b0764 : 0x000000);
      }
    }
  }

  private updateMetalLayersVisibility(layers: MetalLayerInfo[]) {
    layers.forEach(layer => {
      const obj = this.layerGroup.getObjectByName(layer.layer);
      if (obj) {
        obj.visible = layer.visible;
      }
    });
  }

  private syncBlockPositions(blocks: SemiconductorBlock[]) {
    for (const b of blocks) {
      const mesh = this.blockMeshes.get(b.id);
      if (mesh && mesh.userData['initialWidth']) {
        mesh.position.x = b.x + b.width / 2;
        mesh.position.z = b.y + b.height / 2;
        mesh.scale.x = b.width / mesh.userData['initialWidth'];
        mesh.scale.z = b.height / mesh.userData['initialDepth'];
      }
    }
  }

  private applyExplodedView(isExploded: boolean) {
    this.layerGroup.position.y = isExploded ? 180 : 0;
    this.clockTreeGroup.position.y = isExploded ? 260 : 0;
    this.powerMeshGroup.position.y = isExploded ? 340 : 0;
    this.timingPathGroup.position.y = isExploded ? 120 : 0;
  }

  private updateCameraPosition() {
    if (!this.camera) return;

    const r = this.spherical.radius;
    const theta = this.spherical.theta;
    const phi = Math.max(0.001, Math.min(Math.PI / 2 - 0.05, this.spherical.phi));

    const x = this.target.x + r * Math.sin(phi) * Math.sin(theta);
    const y = this.target.y + r * Math.cos(phi);
    const z = this.target.z + r * Math.sin(phi) * Math.cos(theta);

    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.target);
  }

  // Pointer Interaction Handlers
  private onPointerDown = (e: PointerEvent) => {
    this.isPointerDown = true;
    this.pointerButton = e.button;
    this.prevPointerX = e.clientX;
    this.prevPointerY = e.clientY;

    if (e.button === 0) {
      this.checkRaycastSelection(e);
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.isPointerDown) {
      this.checkRaycastHover(e);
      return;
    }

    const deltaX = e.clientX - this.prevPointerX;
    const deltaY = e.clientY - this.prevPointerY;
    this.prevPointerX = e.clientX;
    this.prevPointerY = e.clientY;

    if (this.pointerButton === 0) {
      // Orbit
      if (!this.state.is2dView()) {
        this.spherical.theta -= deltaX * 0.005;
        this.spherical.phi -= deltaY * 0.005;
        this.updateCameraPosition();
      } else {
        // Pan in 2D
        this.target.x -= deltaX * 2.5;
        this.target.z -= deltaY * 2.5;
        this.updateCameraPosition();
      }
    } else if (this.pointerButton === 2) {
      // Pan
      const panSpeed = 2.0;
      this.target.x -= deltaX * panSpeed;
      this.target.z -= deltaY * panSpeed;
      this.updateCameraPosition();
    }
  };

  private onPointerUp = () => {
    this.isPointerDown = false;
  };

  private onWheel = (e: WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY > 0 ? 1.08 : 0.92;
    this.spherical.radius = Math.max(800, Math.min(12000, this.spherical.radius * zoomFactor));
    this.updateCameraPosition();
  };

  private onResize = () => {
    if (!this.canvasContainer || !this.renderer || !this.camera) return;
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private checkRaycastSelection(e: PointerEvent) {
    const rect = this.canvasContainer.nativeElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const meshes = Array.from(this.blockMeshes.values());
    const intersects = this.raycaster.intersectObjects(meshes);

    if (intersects.length > 0) {
      const selected = intersects[0].object as THREE.Mesh;
      const blockId = selected.userData['blockId'];
      this.state.selectBlock(blockId);
      this.state.logConsole('INFO', `Selected block: ${selected.userData['blockId']}`, '3D CAD');
    }
  }

  private checkRaycastHover(e: PointerEvent) {
    const rect = this.canvasContainer.nativeElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const meshes = Array.from(this.blockMeshes.values());
    const intersects = this.raycaster.intersectObjects(meshes);

    if (intersects.length > 0) {
      const hovered = intersects[0].object as THREE.Mesh;
      this.activeHoverBlock.set(hovered.userData['blockId']);
    } else {
      this.activeHoverBlock.set(null);
    }
  }

  // Public Viewport Actions
  public resetView() {
    this.spherical.radius = 3800;
    this.spherical.theta = Math.PI / 4;
    this.spherical.phi = Math.PI / 3;
    this.target.set(1200, 0, 1200);
    this.state.is2dView.set(false);
    this.state.isExplodedView.set(false);
    this.updateCameraPosition();
  }

  public toggle2d() {
    this.state.is2dView.update(v => !v);
  }

  public toggleExploded() {
    this.state.isExplodedView.update(v => !v);
  }

  public toggleWireframe() {
    this.isWireframe.update(w => {
      const next = !w;
      this.blockMeshes.forEach(mesh => {
        (mesh.material as THREE.MeshStandardMaterial).wireframe = next;
      });
      return next;
    });
  }

  public toggleAutorotate() {
    this.isAutorotate.update(r => !r);
  }

  public setOverlay(mode: OverlayMode) {
    this.state.setOverlay(mode);
  }
}
