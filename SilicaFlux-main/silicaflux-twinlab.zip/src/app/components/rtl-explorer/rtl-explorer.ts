import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

export interface RtlFile {
  path: string;
  name: string;
  extension: 'v' | 'sv' | 'sf' | 'rep' | 'tcl';
  sizeBytes: number;
  content: string;
}

@Component({
  selector: 'app-rtl-explorer',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './rtl-explorer.html'
})
export class RtlExplorer {
  public state = inject(TwinLabStateService);

  public selectedCompiler = signal<'sf_translator' | 'verilator' | 'yosys' | 'opensta'>('sf_translator');
  public searchQuery = signal<string>('');
  public selectedFilePath = signal<string>('silicaflux_v_top.v');
  public compilerOutput = signal<string>('');
  public isRunningCompiler = signal<boolean>(false);

  // Pre-loaded SilicaFlux Repository Files
  public rtlFiles: RtlFile[] = [
    {
      path: 'silicaflux_v_top.v',
      name: 'silicaflux_v_top.v',
      extension: 'v',
      sizeBytes: 4820,
      content: `// ============================================================================
// SilicaFlux-V Reference Architecture — Top-Level ASIC Wrapper
// Target Process: SkyWater SKY130 / GF180MCU
// Copyright (c) 2026 Aureom.AI. All rights reserved.
// ============================================================================

\`timescale 1ns / 1ps

module silicaflux_v_top #(
    parameter integer SIMD_LANES         = 4,
    parameter integer TENSOR_DIM         = 4,
    parameter integer SRAM_BANKS         = 4,
    parameter integer DATA_WIDTH         = 32,
    parameter integer ADDR_WIDTH         = 32
)(
    // Clocks and Resets
    input  wire                  clk_core_i,
    input  wire                  clk_tensor_i,
    input  wire                  rst_n_i,

    // JTAG / Boundary Scan Test Interface
    input  wire                  tck_i,
    input  wire                  tms_i,
    input  wire                  tdi_i,
    output wire                  tdo_o,
    output wire                  tdo_en_o,

    // HyperBus / External Memory Interface
    output wire [7:0]            hb_dq_o,
    input  wire [7:0]            hb_dq_i,
    output wire                  hb_dq_oe_o,
    output wire                  hb_rwds_o,
    input  wire                  hb_rwds_i,
    output wire                  hb_cs_n_o,
    output wire                  hb_ck_o,

    // GPIO / Diagnostic UART
    input  wire                  uart_rx_i,
    output wire                  uart_tx_o,
    inout  wire [15:0]           gpio_io
);

    // Internal AXI4-Lite interconnect wires
    wire [ADDR_WIDTH-1:0]        xbar_m0_awaddr;
    wire                         xbar_m0_awvalid;
    wire                         xbar_m0_awready;
    wire [DATA_WIDTH-1:0]        xbar_m0_wdata;
    wire [DATA_WIDTH/8-1:0]      xbar_m0_wstrb;
    wire                         xbar_m0_wvalid;
    wire                         xbar_m0_wready;

    // Vector coprocessor command queue signals
    wire                         vec_cmd_valid;
    wire [63:0]                  vec_cmd_payload;
    wire                         vec_cmd_ready;

    // Tensor systolic array activation lines
    wire                         tensor_start_pulse;
    wire [15:0]                  tensor_weight_addr;
    wire [15:0]                  tensor_act_addr;
    wire                         tensor_busy_flag;

    // ------------------------------------------------------------------------
    // Submodule 1: SilicaFlux-V RV32IMF 5-Stage CPU Core
    // ------------------------------------------------------------------------
    sfv_core_pipeline u_cpu (
        .clk_i         (clk_core_i),
        .rst_n_i       (rst_n_i),
        .m_axi_awaddr  (xbar_m0_awaddr),
        .m_axi_awvalid (xbar_m0_awvalid),
        .m_axi_awready (xbar_m0_awready),
        .m_axi_wdata   (xbar_m0_wdata),
        .m_axi_wstrb   (xbar_m0_wstrb),
        .m_axi_wvalid  (xbar_m0_wvalid),
        .m_axi_wready  (xbar_m0_wready),
        .vec_cmd_val_o (vec_cmd_valid),
        .vec_cmd_dat_o (vec_cmd_payload),
        .vec_cmd_rdy_i (vec_cmd_ready)
    );

    // ------------------------------------------------------------------------
    // Submodule 2: SIMD-4 Vector Execution Engine
    // ------------------------------------------------------------------------
    sfv_vector_unit #(
        .LANES(SIMD_LANES)
    ) u_vector (
        .clk_i         (clk_core_i),
        .rst_n_i       (rst_n_i),
        .cmd_valid_i   (vec_cmd_valid),
        .cmd_payload_i (vec_cmd_payload),
        .cmd_ready_o   (vec_cmd_ready),
        .tensor_trig_o (tensor_start_pulse)
    );

    // ------------------------------------------------------------------------
    // Submodule 3: 4x4 Systolic INT8 Tensor MAC Array
    // ------------------------------------------------------------------------
    sfv_tensor_array #(
        .DIM(TENSOR_DIM)
    ) u_tensor (
        .clk_i         (clk_tensor_i),
        .rst_n_i       (rst_n_i),
        .start_i       (tensor_start_pulse),
        .busy_o        (tensor_busy_flag)
    );

    // ------------------------------------------------------------------------
    // Submodule 4: Banked Multi-Port SRAM Scratchpad Subsystem (256 KiB)
    // ------------------------------------------------------------------------
    sfv_sram_subsystem #(
        .BANKS(SRAM_BANKS)
    ) u_sram (
        .clk_i         (clk_core_i),
        .rst_n_i       (rst_n_i)
    );

endmodule`
    },
    {
      path: 'sfv_tensor_array.v',
      name: 'sfv_tensor_array.v',
      extension: 'v',
      sizeBytes: 3650,
      content: `// ============================================================================
// SilicaFlux-V 4x4 Systolic Tensor MAC Array
// Features: Weight Stationary Dataflow, INT8 Multiply, INT32 Accumulate
// ============================================================================

\`timescale 1ns / 1ps

module sfv_tensor_array #(
    parameter integer DIM = 4
)(
    input  wire        clk_i,
    input  wire        rst_n_i,
    input  wire        start_i,
    output reg         busy_o,
    output reg  [31:0] acc_out_o [0:DIM-1][0:DIM-1]
);

    // Systolic PE Array Interconnect Wires
    wire [7:0]  act_horiz   [0:DIM-1][0:DIM];
    wire [7:0]  wgt_vert    [0:DIM][0:DIM-1];
    wire [31:0] psum_accum  [0:DIM][0:DIM-1];

    genvar r, c;
    generate
        for (r = 0; r < DIM; r = r + 1) begin : gen_row
            for (c = 0; c < DIM; c = c + 1) begin : gen_col
                sfv_mac_pe u_pe (
                    .clk_i       (clk_i),
                    .rst_n_i     (rst_n_i),
                    .act_in      (act_horiz[r][c]),
                    .act_out     (act_horiz[r][c+1]),
                    .wgt_in      (wgt_vert[r][c]),
                    .wgt_out     (wgt_vert[r+1][c]),
                    .psum_in     (psum_accum[r][c]),
                    .psum_out    (psum_accum[r+1][c])
                );
            end
        end
    endgenerate

    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            busy_o <= 1'b0;
        end else if (start_i) begin
            busy_o <= 1'b1;
        end
    end

endmodule`
    },
    {
      path: 'silicaflux_core.sf',
      name: 'silicaflux_core.sf',
      extension: 'sf',
      sizeBytes: 2150,
      content: `// ============================================================================
// SilicaFlux Hardware Architecture Specification (.sf)
// Aureom SilicaFlux Compiler Engine v4.2
// ============================================================================

architecture SilicaFluxV {
    target_process = "SkyWater_SKY130A";
    nominal_vdd = 1.8V;
    max_frequency = 125MHz;

    pipeline Core_RV32IMF {
        stages = 5;
        forwarding = full;
        hazard_detection = hardware;
        branch_predictor = bimodal(entries: 128);
    }

    accelerator VectorUnit {
        lanes = 4;
        element_types = [int8, int16, fp16];
        vrf_capacity = 8KiB;
        reduction_topology = tree;
    }

    accelerator SystolicTensorArray {
        dimensions = 4 x 4;
        dataflow = weight_stationary;
        operand_precision = int8;
        accumulator_precision = int32;
        peak_throughput = 32_OPS_PER_CYCLE;
    }

    memory_hierarchy BankedSRAM {
        banks = 4;
        bank_capacity = 64KiB;
        total_capacity = 256KiB;
        bus_width = 128bit;
        arbitration = round_robin;
        ecc = secded;
    }
}
`
    },
    {
      path: 'synth_sky130.rep',
      name: 'synth_sky130.rep',
      extension: 'rep',
      sizeBytes: 1840,
      content: `=== Yosys 0.44 Gate Level Area Report for SilicaFlux-V ===
Target PDK: sky130_fd_sc_hd (SkyWater 130nm High Density)

Module Hierarchy Breakdown:
--------------------------------------------------------------------------------
Module                      Cell Count    Area (um^2)    % of Total Area
--------------------------------------------------------------------------------
silicaflux_v_top               365,400     2,184,200             100.0%
 |-- u_cpu (RV32 Core)          42,100       285,400              13.1%
 |-- u_vector (SIMD-4)          68,500       462,800              21.2%
 |-- u_tensor (4x4 MAC)         92,400       624,100              28.6%
 |-- u_sram (4x Macro)         112,000       580,200              26.6%
 |-- u_xbar (NOC Crossbar)      18,200       122,800               5.6%
 |-- u_mem_ctrl (HyperBus)      31,000        98,400               4.5%
 |-- clk_pll / dft_jtag          1,200        10,500               0.5%
--------------------------------------------------------------------------------
Total Die Area Utilized: 2.18 mm^2 in 2.4 mm x 2.4 mm die envelope (37.8% core fill factor).
Sequential Cells: 48,220 flip-flops (sky130_fd_sc_hd__dfxtp_1)
Combinational Logic: 317,180 gates (NAND, NOR, XOR, FA, MUX)
`
    },
    {
      path: 'timing_sta.rep',
      name: 'timing_sta.rep',
      extension: 'rep',
      sizeBytes: 1520,
      content: `=== OpenSTA 2.6 Signoff Timing Summary ===
Corner: Slow-Slow (SS) | Temperature: 125 C | Voltage: 1.62 V (1.8V - 10%)
Target Clock Period: 8.000 ns (125.0 MHz)

Path 1: MET
  Endpoint: sfv_tensor_array/gen_mac[3][3].u_mac/reg_acc_d[31]
  Startpoint: sfv_tensor_array/gen_mac[3][3].u_mac/reg_weight_q[7]
  Path Group: clk_tensor
  Path Type: max
  Data Path Delay: 7.320 ns
  Required Time:   7.385 ns
  Slack:          +0.065 ns (MET)

Path 2: MET
  Endpoint: sfv_vector_unit/u_vrf/ram_bank0_din[63]
  Startpoint: sfv_vector_unit/lane[3].u_alu/operand_b_reg[15]
  Path Group: clk_core
  Data Path Delay: 7.890 ns
  Required Time:   8.000 ns
  Slack:          +0.110 ns (MET)

Worst Negative Slack (WNS): +0.065 ns
Total Negative Slack (TNS):  0.000 ns
Worst Hold Slack (WHS):     +0.180 ns (MET)
TIMING SIGN OFF: PASSED. Zero setup or hold violations.
`
    }
  ];

  public activeFile = signal<RtlFile>(this.rtlFiles[0]);

  public selectFile(file: RtlFile) {
    this.activeFile.set(file);
    this.selectedFilePath.set(file.path);
  }

  public runCompilerTool() {
    this.isRunningCompiler.set(true);
    const tool = this.selectedCompiler();
    const filename = this.activeFile().name;

    this.state.logConsole('INFO', `Executing EDA tool: ${tool} on target file: ${filename}...`, tool.toUpperCase());

    setTimeout(() => {
      this.isRunningCompiler.set(false);
      if (tool === 'sf_translator') {
        this.compilerOutput.set(`[Aureom SilicaFlux Compiler v4.2]
Input: ${filename}
Phase 1: Lexical analysis -> 412 tokens parsed.
Phase 2: Semantic verification -> Architecture 'SilicaFluxV' valid.
Phase 3: RTL generation -> Generated SystemVerilog target: silicaflux_v_top.sv
Status: Translation completed in 0.18s. Exit code 0.`);
      } else if (tool === 'verilator') {
        this.compilerOutput.set(`verilator --lint-only -Wall --timing ${filename}
%Warning-UNUSED: Signal debug_trace_o not connected at top level.
Verilated 1 source file: 0 errors, 1 warning.
[SUCCESS] RTL syntax verified.`);
      } else if (tool === 'yosys') {
        this.compilerOutput.set(`Yosys 0.44 (git sha1 92b10a):
Executing elaboration on top module 'silicaflux_v_top'...
Mapping to generic gates: 365,400 cells instantiated.
Synthesis status: SUCCESS.`);
      } else {
        this.compilerOutput.set(`OpenSTA 2.6:
Read SPEF parasitics: OK
Evaluating setup/hold slack for corner SS_125C:
WNS: +0.065 ns (MET)
STA Check PASSED.`);
      }
    }, 450);
  }
}
