import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

@Component({
  selector: 'app-power-integrity',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './power-integrity.html'
})
export class PowerIntegrity {
  public state = inject(TwinLabStateService);

  public powerGrid = this.state.powerGridResult;

  public strapPitchUm = signal<number>(25);
  public decapDensity = signal<number>(85); // % coverage
  public selectedMetalStrap = signal<'M4' | 'M5'>('M5');

  public updateStrapPitch(pitch: number) {
    this.strapPitchUm.set(pitch);
    this.state.logConsole('INFO', `Power strap pitch updated to ${pitch} μm. Recomputing resistive mesh...`, 'PowerSolver');
  }
}
