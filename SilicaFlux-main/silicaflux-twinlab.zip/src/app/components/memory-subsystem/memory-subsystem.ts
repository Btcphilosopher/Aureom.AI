import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TwinLabStateService } from '../../services/twinlab-state';

@Component({
  selector: 'app-memory-subsystem',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './memory-subsystem.html'
})
export class MemorySubsystem {
  public state = inject(TwinLabStateService);

  public roofline = this.state.rooflineResult;

  public activeWorkload = signal<string>('4x4 GEMM (Systolic Tensor)');
  public queueContentionCycles = signal<number>(14);
  public sramBankConflicts = signal<number>(3);
  public dmaBandwidthUtilization = signal<number>(76.4);
}
