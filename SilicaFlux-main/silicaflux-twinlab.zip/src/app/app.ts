import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TwinLabStateService } from './services/twinlab-state';

import { Header } from './components/header/header';
import { Sidebar } from './components/sidebar/sidebar';
import { InspectorSidebar } from './components/inspector-sidebar/inspector-sidebar';
import { BottomConsole } from './components/bottom-console/bottom-console';
import { DigitalTwin3d } from './components/digital-twin-3d/digital-twin-3d';
import { RtlExplorer } from './components/rtl-explorer/rtl-explorer';
import { ArchitectureEditor } from './components/architecture-editor/architecture-editor';
import { FloorplanLab } from './components/floorplan-lab/floorplan-lab';
import { ProcessNodes } from './components/process-nodes/process-nodes';
import { TimingLab } from './components/timing-lab/timing-lab';
import { PowerIntegrity } from './components/power-integrity/power-integrity';
import { ThermalLab } from './components/thermal-lab/thermal-lab';
import { MemorySubsystem } from './components/memory-subsystem/memory-subsystem';
import { TransistorMaterials } from './components/transistor-materials/transistor-materials';
import { PhysicalFlow } from './components/physical-flow/physical-flow';
import { WaferEconomics } from './components/wafer-economics/wafer-economics';
import { OptimLab } from './components/optim-lab/optim-lab';
import { VerificationDft } from './components/verification-dft/verification-dft';
import { TapeoutReadiness } from './components/tapeout-readiness/tapeout-readiness';
import { ReportsExport } from './components/reports-export/reports-export';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    Header,
    Sidebar,
    InspectorSidebar,
    BottomConsole,
    DigitalTwin3d,
    RtlExplorer,
    ArchitectureEditor,
    FloorplanLab,
    ProcessNodes,
    TimingLab,
    PowerIntegrity,
    ThermalLab,
    MemorySubsystem,
    TransistorMaterials,
    PhysicalFlow,
    WaferEconomics,
    OptimLab,
    VerificationDft,
    TapeoutReadiness,
    ReportsExport
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public state = inject(TwinLabStateService);
}
