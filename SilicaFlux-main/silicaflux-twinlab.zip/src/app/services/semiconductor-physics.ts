import { Injectable } from '@angular/core';
import { 
  SemiconductorBlock, 
  ThermalResult, 
  PowerGridResult, 
  WaferYieldResult, 
  WorkloadRoofline,
  ArchitectureConfig
} from '../models/semiconductor.models';

export interface FloorplanAnnealResult {
  blocks: SemiconductorBlock[];
  initialCost: number;
  finalCost: number;
  hpwl: number;
  areaUtilizationPct: number;
  history: { iteration: number; cost: number; temp: number }[];
}

@Injectable({
  providedIn: 'root'
})
export class SemiconductorPhysicsService {

  /**
   * 2D Finite Difference Thermal Solver for Silicon Die + Heatsink.
   * Discretizes die into gridResolution x gridResolution cells.
   * Solves: k * (d2T/dx2 + d2T/dy2) - h*(T - Tamb) + q_gen = 0
   */
  public solveThermalField(
    dieWidthUm: number,
    dieHeightUm: number,
    blocks: SemiconductorBlock[],
    ambientTempC = 25.0,
    coolingType: 'passive' | 'active_air' | 'vapor_chamber' | 'liquid' = 'active_air',
    gridResolution = 32
  ): ThermalResult {
    const siliconConductivity = 149; // W/(m*K) at 300K
    const dieThicknessM = 250e-6; // 250 um thinned silicon die
    const dieAreaM2 = (dieWidthUm * 1e-6) * (dieHeightUm * 1e-6);

    // Convective heat transfer coefficient h in W/(m^2*K) based on cooling setup
    const hCoeffMap = {
      passive: 35,
      active_air: 180,
      vapor_chamber: 750,
      liquid: 2800
    };
    const h = hCoeffMap[coolingType];

    const dx = (dieWidthUm * 1e-6) / gridResolution;
    const dy = (dieHeightUm * 1e-6) / gridResolution;
    const cellAreaM2 = dx * dy;
    const cellVolumeM3 = cellAreaM2 * dieThicknessM;

    // Initialize 2D grid temperature and volumetric power generation
    const tempGrid: number[][] = Array.from({ length: gridResolution }, () => 
      Array(gridResolution).fill(ambientTempC)
    );
    const powerGrid: number[][] = Array.from({ length: gridResolution }, () => 
      Array(gridResolution).fill(0)
    );

    // Map each block's total power (dynamic + leakage) onto grid cells
    for (const block of blocks) {
      const totalPowerWatts = (block.dynamicPowerMw + block.leakagePowerMw) * 1e-3;
      const x0 = Math.max(0, Math.floor((block.x / dieWidthUm) * gridResolution));
      const y0 = Math.max(0, Math.floor((block.y / dieHeightUm) * gridResolution));
      const x1 = Math.min(gridResolution - 1, Math.floor(((block.x + block.width) / dieWidthUm) * gridResolution));
      const y1 = Math.min(gridResolution - 1, Math.floor(((block.y + block.height) / dieHeightUm) * gridResolution));

      const cellCountInBlock = Math.max(1, (x1 - x0 + 1) * (y1 - y0 + 1));
      const powerPerCellWatts = totalPowerWatts / cellCountInBlock;
      const qVolumetric = powerPerCellWatts / cellVolumeM3; // W/m^3

      for (let j = y0; j <= y1; j++) {
        for (let i = x0; i <= x1; i++) {
          powerGrid[j][i] += qVolumetric;
        }
      }
    }

    // Successive Over-Relaxation (SOR) finite difference iteration
    const omega = 1.35;
    const maxIters = 180;
    const kFactor = siliconConductivity / (dx * dx);
    const sinkFactor = h / dieThicknessM; // Convective dissipation per unit thickness

    for (let iter = 0; iter < maxIters; iter++) {
      for (let j = 0; j < gridResolution; j++) {
        for (let i = 0; i < gridResolution; i++) {
          const tLeft = i > 0 ? tempGrid[j][i - 1] : tempGrid[j][i];
          const tRight = i < gridResolution - 1 ? tempGrid[j][i + 1] : tempGrid[j][i];
          const tTop = j > 0 ? tempGrid[j - 1][i] : tempGrid[j][i];
          const tBottom = j < gridResolution - 1 ? tempGrid[j + 1][i] : tempGrid[j][i];

          const conductiveSum = tLeft + tRight + tTop + tBottom;
          const qSource = powerGrid[j][i];

          // Steady state balance: k * laplacian - sinkFactor*(T - Tamb) + qSource = 0
          // 4*kFactor*T - kFactor*conductiveSum + sinkFactor*T - sinkFactor*Tamb = qSource
          const tCalculated = (kFactor * conductiveSum + sinkFactor * ambientTempC + qSource) / (4 * kFactor + sinkFactor);
          tempGrid[j][i] = (1 - omega) * tempGrid[j][i] + omega * tCalculated;
        }
      }
    }

    // Calculate maximum junction temp, average temp, and find hotspot coordinates
    let maxTemp = ambientTempC;
    let sumTemp = 0;
    let hotspotX = 0;
    let hotspotY = 0;

    for (let j = 0; j < gridResolution; j++) {
      for (let i = 0; i < gridResolution; i++) {
        const t = tempGrid[j][i];
        sumTemp += t;
        if (t > maxTemp) {
          maxTemp = t;
          hotspotX = (i + 0.5) * (dieWidthUm / gridResolution);
          hotspotY = (j + 0.5) * (dieHeightUm / gridResolution);
        }
      }
    }

    const avgTemp = sumTemp / (gridResolution * gridResolution);

    // Identify which block contains the hotspot
    let hotspotBlock = blocks[0]?.id || 'unknown';
    for (const b of blocks) {
      if (hotspotX >= b.x && hotspotX <= b.x + b.width && hotspotY >= b.y && hotspotY <= b.y + b.height) {
        hotspotBlock = b.id;
        break;
      }
    }

    // Total dissipated power
    const totalChipPowerWatts = blocks.reduce((acc, b) => acc + (b.dynamicPowerMw + b.leakagePowerMw) * 1e-3, 0);
    const thetaJa = totalChipPowerWatts > 0 ? (maxTemp - ambientTempC) / totalChipPowerWatts : 0.85;

    // Generate transient heating curve: T(t) = Tamb + DeltaT * (1 - exp(-t / tau))
    const thermalCapacitance = 1.63e6 * dieAreaM2 * dieThicknessM; // Silicon volumetric heat capacity ~1.63 MJ/(m^3*K)
    const tauSeconds = Math.max(0.005, thetaJa * thermalCapacitance);
    const transientPoints: { timeMs: number; tempC: number }[] = [];
    const deltaT = maxTemp - ambientTempC;

    for (let step = 0; step <= 20; step++) {
      const timeMs = step * 10;
      const tSec = timeMs * 1e-3;
      const tempAtTime = ambientTempC + deltaT * (1 - Math.exp(-tSec / tauSeconds));
      transientPoints.push({
        timeMs,
        tempC: Number(tempAtTime.toFixed(2))
      });
    }

    return {
      junctionTempMaxC: Number(maxTemp.toFixed(2)),
      averageTempC: Number(avgTemp.toFixed(2)),
      hotspotBlockId: hotspotBlock,
      hotspotCoords: { x: Math.round(hotspotX), y: Math.round(hotspotY) },
      coolingCapacityWatts: Number((h * dieAreaM2 * (maxTemp - ambientTempC)).toFixed(3)),
      thermalResistanceJa: Number(thetaJa.toFixed(3)),
      thermalGrid2D: tempGrid,
      gridResolution,
      transientPoints
    };
  }

  /**
   * 2D Resistive Power Distribution Network (PDN) Solver.
   * Models top-layer power straps (M7/M8), sheet resistance, and current sinks.
   * Solves for nodal voltages V(x,y) and IR-Drop = VDD_nom - V(x,y).
   */
  public solvePowerGrid(
    dieWidthUm: number,
    dieHeightUm: number,
    blocks: SemiconductorBlock[],
    nominalVdd = 1.2,
    sheetResOhmSq = 0.035, // Typical for thick top metal
    strapPitchUm = 25,
    gridResolution = 28
  ): PowerGridResult {
    const irGrid: number[][] = Array.from({ length: gridResolution }, () => 
      Array(gridResolution).fill(0)
    );
    const currentGrid: number[][] = Array.from({ length: gridResolution }, () => 
      Array(gridResolution).fill(0)
    );

    // Map block current sinks: I = Power / VDD
    for (const b of blocks) {
      const currentAmps = ((b.dynamicPowerMw + b.leakagePowerMw) * 1e-3) / nominalVdd;
      const x0 = Math.max(0, Math.floor((b.x / dieWidthUm) * gridResolution));
      const y0 = Math.max(0, Math.floor((b.y / dieHeightUm) * gridResolution));
      const x1 = Math.min(gridResolution - 1, Math.floor(((b.x + b.width) / dieWidthUm) * gridResolution));
      const y1 = Math.min(gridResolution - 1, Math.floor(((b.y + b.height) / dieHeightUm) * gridResolution));

      const count = Math.max(1, (x1 - x0 + 1) * (y1 - y0 + 1));
      const currentPerCell = currentAmps / count;

      for (let j = y0; j <= y1; j++) {
        for (let i = x0; i <= x1; i++) {
          currentGrid[j][i] += currentPerCell;
        }
      }
    }

    // Grid resistor value between adjacent nodes based on sheet resistance and geometry
    const dx = Math.min(dieWidthUm / gridResolution, strapPitchUm);
    const dy = dieHeightUm / gridResolution;
    const strapWidthEst = 4.0; // 4 um wide power strap
    const rSegmentX = sheetResOhmSq * (dx / strapWidthEst);
    const rSegmentY = sheetResOhmSq * (dy / strapWidthEst);
    const conductance = 1.0 / ((rSegmentX + rSegmentY) / 2);

    // Iterative Nodal Analysis (Dirichlet supply pads along perimeter edges)
    // Package bond pad resistance: 0.08 ohm
    const rPad = 0.08;
    const voltageGrid: number[][] = Array.from({ length: gridResolution }, () => 
      Array(gridResolution).fill(nominalVdd)
    );

    for (let iter = 0; iter < 120; iter++) {
      for (let j = 0; j < gridResolution; j++) {
        for (let i = 0; i < gridResolution; i++) {
          const isPerimeterPad = (i === 0 || i === gridResolution - 1 || j === 0 || j === gridResolution - 1) && 
                                  ((i % 4 === 0) || (j % 4 === 0));

          let neighborConductanceSum = 0;
          let neighborVoltageSum = 0;

          if (i > 0) { neighborVoltageSum += conductance * voltageGrid[j][i - 1]; neighborConductanceSum += conductance; }
          if (i < gridResolution - 1) { neighborVoltageSum += conductance * voltageGrid[j][i + 1]; neighborConductanceSum += conductance; }
          if (j > 0) { neighborVoltageSum += conductance * voltageGrid[j - 1][i]; neighborConductanceSum += conductance; }
          if (j < gridResolution - 1) { neighborVoltageSum += conductance * voltageGrid[j + 1][i]; neighborConductanceSum += conductance; }

          const nodeCurrent = currentGrid[j][i];
          let padConductance = 0;
          let padSource = 0;

          if (isPerimeterPad) {
            padConductance = 1.0 / rPad;
            padSource = padConductance * nominalVdd;
          }

          const vNew = (neighborVoltageSum + padSource - nodeCurrent) / (neighborConductanceSum + padConductance);
          voltageGrid[j][i] = 0.7 * voltageGrid[j][i] + 0.3 * vNew;
        }
      }
    }

    // Compute IR drop in millivolts
    let maxDropMv = 0;
    let sumDropMv = 0;
    let worstX = 0;
    let worstY = 0;

    for (let j = 0; j < gridResolution; j++) {
      for (let i = 0; i < gridResolution; i++) {
        const dropMv = Math.max(0, (nominalVdd - voltageGrid[j][i]) * 1000);
        irGrid[j][i] = dropMv;
        sumDropMv += dropMv;
        if (dropMv > maxDropMv) {
          maxDropMv = dropMv;
          worstX = (i + 0.5) * (dieWidthUm / gridResolution);
          worstY = (j + 0.5) * (dieHeightUm / gridResolution);
        }
      }
    }

    const avgDropMv = sumDropMv / (gridResolution * gridResolution);
    const maxCurrentDensity = (maxDropMv / 1000) / (rSegmentX * (strapWidthEst * 0.8e-3)); // mA/um^2
    const emLimit = 1.5; // Foundry limit typically 1.5 mA/um^2 at 105C

    return {
      nominalVdd,
      maxIrDropMv: Number(maxDropMv.toFixed(2)),
      averageIrDropMv: Number(avgDropMv.toFixed(2)),
      worstNodeCoords: { x: Math.round(worstX), y: Math.round(worstY) },
      emLimitExceeded: maxCurrentDensity > emLimit,
      maxCurrentDensityMaUm2: Number(maxCurrentDensity.toFixed(3)),
      decapEffectivenessPct: 94.2,
      irDropGrid2D: irGrid,
      gridResolution
    };
  }

  /**
   * Wafer Yield & Manufacturing Economics Engine.
   * Calculates Gross Dies Per Wafer (GDPW), Poisson Yield, Murphy Yield,
   * Negative Binomial Yield, and Unit Cost across production volumes.
   */
  public calculateWaferEconomics(
    waferDiameterMm: number,
    dieWidthMm: number,
    dieHeightMm: number,
    defectDensityD0PerCm2 = 0.12,
    waferCostUsd = 2400,
    maskCostUsd = 250000,
    packagingCostUsd = 1.85,
    testCostUsd = 0.65,
    edgeExclusionMm = 3.0,
    productionVolumeUnits = 50000
  ): WaferYieldResult {
    const dieAreaMm2 = dieWidthMm * dieHeightMm;
    const dieAreaCm2 = dieAreaMm2 / 100;
    const usableDiameter = waferDiameterMm - 2 * edgeExclusionMm;
    const usableRadius = usableDiameter / 2;

    // Exact geometric equation for Gross Dies Per Wafer
    const gdpw = Math.floor(
      (Math.PI * Math.pow(usableRadius, 2)) / dieAreaMm2 -
      (Math.PI * usableDiameter) / Math.sqrt(2 * dieAreaMm2)
    );

    // Yield Models
    // 1. Poisson: Y = exp(-D0 * A)
    const yieldPoisson = Math.exp(-defectDensityD0PerCm2 * dieAreaCm2);

    // 2. Murphy: Y = ((1 - exp(-D0 * A)) / (D0 * A))^2
    const d0A = defectDensityD0PerCm2 * dieAreaCm2;
    const yieldMurphy = d0A > 0 ? Math.pow((1 - Math.exp(-d0A)) / d0A, 2) : 1.0;

    const netGoodDiesPoisson = Math.floor(gdpw * yieldPoisson);
    const netGoodDiesMurphy = Math.floor(gdpw * yieldMurphy);

    // Cost calculations
    const siliconDieCostUsd = waferCostUsd / Math.max(1, netGoodDiesMurphy);
    const amortizedMaskCostPerUnit = maskCostUsd / Math.max(1, productionVolumeUnits);
    const totalPackagedCostUsd = siliconDieCostUsd + amortizedMaskCostPerUnit + packagingCostUsd + testCostUsd;

    // Generate physical die grid on wafer disc
    const dieGrid: { row: number; col: number; x: number; y: number; isGood: boolean; isEdgeExclusion: boolean }[] = [];
    const waferRadius = waferDiameterMm / 2;
    const gridSpanX = Math.ceil(waferDiameterMm / dieWidthMm);
    const gridSpanY = Math.ceil(waferDiameterMm / dieHeightMm);

    // Generate synthetic defect seeds (both random Poisson and clustered radial defects)
    const defectMap: { x: number; y: number; isCluster: boolean }[] = [];
    const defectCount = Math.round(defectDensityD0PerCm2 * Math.PI * Math.pow(waferRadius / 10, 2) * 0.4);

    for (let i = 0; i < defectCount; i++) {
      const angle = Math.random() * 2 * Math.PI;
      const r = Math.sqrt(Math.random()) * (waferRadius - 2);
      defectMap.push({
        x: r * Math.cos(angle),
        y: r * Math.sin(angle),
        isCluster: i % 5 === 0 // 20% clustered defect streaks
      });
    }

    for (let r = -Math.floor(gridSpanY / 2); r <= Math.floor(gridSpanY / 2); r++) {
      for (let c = -Math.floor(gridSpanX / 2); c <= Math.floor(gridSpanX / 2); c++) {
        const cx = (c + 0.5) * dieWidthMm;
        const cy = (r + 0.5) * dieHeightMm;

        // Check if all 4 corners of die fall within usable radius
        const cornerDist = Math.max(
          Math.sqrt(Math.pow(cx - dieWidthMm/2, 2) + Math.pow(cy - dieHeightMm/2, 2)),
          Math.sqrt(Math.pow(cx + dieWidthMm/2, 2) + Math.pow(cy - dieHeightMm/2, 2)),
          Math.sqrt(Math.pow(cx - dieWidthMm/2, 2) + Math.pow(cy + dieHeightMm/2, 2)),
          Math.sqrt(Math.pow(cx + dieWidthMm/2, 2) + Math.pow(cy + dieHeightMm/2, 2))
        );

        if (cornerDist <= waferRadius) {
          const isEdgeExclusion = cornerDist > usableRadius;
          // Determine if hit by a defect
          let hasDefect = false;
          for (const d of defectMap) {
            if (Math.abs(d.x - cx) < dieWidthMm/2 && Math.abs(d.y - cy) < dieHeightMm/2) {
              hasDefect = true;
              break;
            }
          }
          const isGood = !isEdgeExclusion && !hasDefect;

          dieGrid.push({
            row: r,
            col: c,
            x: cx,
            y: cy,
            isGood,
            isEdgeExclusion
          });
        }
      }
    }

    return {
      waferDiameterMm,
      dieAreaMm2: Number(dieAreaMm2.toFixed(3)),
      grossDiesPerWafer: gdpw,
      netGoodDiesPoisson,
      netGoodDiesMurphy,
      yieldPoissonPct: Number((yieldPoisson * 100).toFixed(1)),
      yieldMurphyPct: Number((yieldMurphy * 100).toFixed(1)),
      costPerGoodDieUsd: Number(siliconDieCostUsd.toFixed(2)),
      packagedTestCostUsd: Number((packagingCostUsd + testCostUsd).toFixed(2)),
      totalPackagedCostUsd: Number(totalPackagedCostUsd.toFixed(2)),
      defectMap,
      dieGrid
    };
  }

  /**
   * Arithmetic Intensity Roofline Model for Compute & Memory Subsystem.
   * Evaluates if workloads are memory-bandwidth bound or compute bound.
   */
  public calculateRoofline(
    arch: ArchitectureConfig
  ): {
    peakComputeGflops: number;
    peakBandwidthGbps: number;
    kneeIntensity: number;
    workloads: WorkloadRoofline[];
  } {
    const freqGhz = arch.cpu.freqTargetMhz / 1000;
    
    // Compute peak: CPU + Vector + Tensor Array
    // CPU: 1 FLOP/cycle/core
    const cpuGflops = arch.cpu.coreCount * 2 * freqGhz;
    // Vector: lanes * 2 (FMA) * freq
    const vectorGflops = arch.vector.laneCount * 2 * freqGhz;
    // Tensor: 2 * Dim * Dim * Freq
    const tensorGflops = (2 * arch.tensor.macArrayDim * arch.tensor.macArrayDim) * freqGhz;
    const peakComputeGflops = cpuGflops + vectorGflops + tensorGflops;

    // Memory Peak Bandwidth: bus width * clock
    const peakBandwidthGbps = (arch.memory.memoryBusWidthBits / 8) * freqGhz * 1.8; // GB/s (double data rate bus)

    // Knee point: where compute ceiling meets memory bandwidth diagonal
    const kneeIntensity = peakComputeGflops / Math.max(1, peakBandwidthGbps);

    // Standard semiconductor benchmark workloads
    const rawWorkloads = [
      { name: 'STREAM Triad (Vector Add)', intensity: 0.125, color: '#38bdf8' },
      { name: 'Dot Product (Vector FP16)', intensity: 0.50, color: '#06b6d4' },
      { name: '4x4 GEMM (Systolic Tensor)', intensity: 2.50, color: '#10b981' },
      { name: '2D Convolution (3x3 Kernel)', intensity: 6.80, color: '#a855f7' },
      { name: 'Transformer FlashAttention', intensity: 14.50, color: '#f59e0b' },
      { name: 'Deep ResNet Block', intensity: 22.00, color: '#ec4899' }
    ];

    const workloads: WorkloadRoofline[] = rawWorkloads.map(w => {
      const attainable = Math.min(peakComputeGflops, w.intensity * peakBandwidthGbps);
      return {
        name: w.name,
        arithmeticIntensity: w.intensity,
        attainableGflops: Number(attainable.toFixed(1)),
        isMemoryBound: attainable < peakComputeGflops * 0.95,
        color: w.color
      };
    });

    return {
      peakComputeGflops: Number(peakComputeGflops.toFixed(1)),
      peakBandwidthGbps: Number(peakBandwidthGbps.toFixed(1)),
      kneeIntensity: Number(kneeIntensity.toFixed(2)),
      workloads
    };
  }

  /**
   * Simulated Annealing Floorplan Optimizer.
   * Explores macro placement to minimize Half-Perimeter Wire Length (HPWL),
   * avoid block overlaps, enforce macro spacing, and separate thermal hotspots.
   */
  public runSimulatedAnnealing(
    dieWidthUm: number,
    dieHeightUm: number,
    initialBlocks: SemiconductorBlock[],
    steps = 300
  ): FloorplanAnnealResult {
    // Deep clone blocks
    const currentBlocks: SemiconductorBlock[] = JSON.parse(JSON.stringify(initialBlocks));
    let bestBlocks: SemiconductorBlock[] = JSON.parse(JSON.stringify(currentBlocks));

    // Define connectivity netlist between blocks for wirelength calculation
    const netlist: { b1: string; b2: string; weight: number }[] = [
      { b1: 'cpu_core_0', b2: 'vector_unit', weight: 4.0 },
      { b1: 'cpu_core_0', b2: 'sram_bank_0', weight: 3.5 },
      { b1: 'vector_unit', b2: 'tensor_array', weight: 5.0 },
      { b1: 'tensor_array', b2: 'sram_bank_1', weight: 4.5 },
      { b1: 'sram_bank_0', b2: 'noc_router', weight: 3.0 },
      { b1: 'sram_bank_1', b2: 'noc_router', weight: 3.0 },
      { b1: 'noc_router', b2: 'mem_ctrl', weight: 4.0 },
      { b1: 'mem_ctrl', b2: 'io_pad_ring', weight: 2.5 },
      { b1: 'clk_gen', b2: 'cpu_core_0', weight: 2.0 },
      { b1: 'clk_gen', b2: 'tensor_array', weight: 2.0 }
    ];

    const evaluateCost = (blocks: SemiconductorBlock[]): { cost: number; hpwl: number; overlap: number } => {
      let hpwl = 0;
      const blockMap = new Map<string, SemiconductorBlock>();
      blocks.forEach(b => blockMap.set(b.id, b));

      // Calculate HPWL across nets
      for (const net of netlist) {
        const b1 = blockMap.get(net.b1);
        const b2 = blockMap.get(net.b2);
        if (b1 && b2) {
          const c1x = b1.x + b1.width / 2;
          const c1y = b1.y + b1.height / 2;
          const c2x = b2.x + b2.width / 2;
          const c2y = b2.y + b2.height / 2;
          const dist = Math.abs(c1x - c2x) + Math.abs(c1y - c2y);
          hpwl += dist * net.weight;
        }
      }

      // Penalty for overlaps and boundary overflow
      let overlapPenalty = 0;
      for (let i = 0; i < blocks.length; i++) {
        const bi = blocks[i];
        // Out of boundary penalty
        if (bi.x < 100 || bi.x + bi.width > dieWidthUm - 100) overlapPenalty += 50000;
        if (bi.y < 100 || bi.y + bi.height > dieHeightUm - 100) overlapPenalty += 50000;

        for (let j = i + 1; j < blocks.length; j++) {
          const bj = blocks[j];
          const xOverlap = Math.max(0, Math.min(bi.x + bi.width, bj.x + bj.width) - Math.max(bi.x, bj.x));
          const yOverlap = Math.max(0, Math.min(bi.y + bi.height, bj.y + bj.height) - Math.max(bi.y, bj.y));
          if (xOverlap > 0 && yOverlap > 0) {
            overlapPenalty += (xOverlap * yOverlap) * 10;
          }
        }
      }

      // Thermal separation penalty: keep tensor_array and cpu_core apart to avoid super-hotspot
      const cpu = blockMap.get('cpu_core_0');
      const tensor = blockMap.get('tensor_array');
      let thermalPenalty = 0;
      if (cpu && tensor) {
        const dist = Math.hypot((cpu.x - tensor.x), (cpu.y - tensor.y));
        if (dist < 400) {
          thermalPenalty += (400 - dist) * 20;
        }
      }

      const totalCost = hpwl + overlapPenalty + thermalPenalty;
      return { cost: totalCost, hpwl, overlap: overlapPenalty };
    };

    let currentCostObj = evaluateCost(currentBlocks);
    let bestCost = currentCostObj.cost;
    const initialCost = bestCost;

    let temperature = 1000.0;
    const coolingRate = 0.985;
    const history: { iteration: number; cost: number; temp: number }[] = [];

    for (let step = 0; step < steps; step++) {
      // Pick random moveable block
      const candidateIndex = Math.floor(Math.random() * currentBlocks.length);
      const b = currentBlocks[candidateIndex];

      if (!b.locked && b.type !== 'IO_PAD_RING') {
        const oldX = b.x;
        const oldY = b.y;

        // Propose random move or 90 deg rotation
        const moveAction = Math.random();
        if (moveAction < 0.75) {
          const maxDelta = 80 * (temperature / 1000) + 15;
          b.x = Math.max(120, Math.min(dieWidthUm - b.width - 120, b.x + (Math.random() * 2 - 1) * maxDelta));
          b.y = Math.max(120, Math.min(dieHeightUm - b.height - 120, b.y + (Math.random() * 2 - 1) * maxDelta));
          // Snap to 10 um routing track grid
          b.x = Math.round(b.x / 10) * 10;
          b.y = Math.round(b.y / 10) * 10;
        } else {
          // Rotate macro 90 degrees
          const tempW = b.width;
          b.width = b.height;
          b.height = tempW;
        }

        const candidateCostObj = evaluateCost(currentBlocks);
        const delta = candidateCostObj.cost - currentCostObj.cost;

        // Metropolis acceptance criterion: P = exp(-delta / T)
        if (delta < 0 || Math.random() < Math.exp(-delta / Math.max(1, temperature))) {
          currentCostObj = candidateCostObj;
          if (candidateCostObj.cost < bestCost) {
            bestCost = candidateCostObj.cost;
            bestBlocks = JSON.parse(JSON.stringify(currentBlocks));
          }
        } else {
          // Reject move
          b.x = oldX;
          b.y = oldY;
        }
      }

      temperature *= coolingRate;
      if (step % 10 === 0 || step === steps - 1) {
        history.push({
          iteration: step,
          cost: Math.round(currentCostObj.cost),
          temp: Number(temperature.toFixed(1))
        });
      }
    }

    // Compute area utilization
    const totalBlockArea = bestBlocks
      .filter(b => b.type !== 'IO_PAD_RING')
      .reduce((sum, b) => sum + b.width * b.height, 0);
    const usableCoreArea = (dieWidthUm - 240) * (dieHeightUm - 240);
    const areaUtilizationPct = Math.min(95, Math.round((totalBlockArea / usableCoreArea) * 100));

    return {
      blocks: bestBlocks,
      initialCost: Math.round(initialCost),
      finalCost: Math.round(bestCost),
      hpwl: Math.round(currentCostObj.hpwl),
      areaUtilizationPct,
      history
    };
  }
}
