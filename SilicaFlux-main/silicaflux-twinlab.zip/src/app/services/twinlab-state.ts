import { Injectable, signal, computed, inject } from '@angular/core';
import { 
  SilicaFluxFamily, 
  ProcessNodeProfile, 
  SemiconductorBlock, 
  MetalLayerInfo, 
  ArchitectureConfig, 
  FidelityLevel, 
  OverlayMode, 
  ThermalResult, 
  PowerGridResult, 
  WaferYieldResult, 
  TimingPath, 
  EdaStage, 
  TapeoutGate 
} from '../models/semiconductor.models';
import { SemiconductorPhysicsService } from './semiconductor-physics';

export type MainNavTab = 
  | 'twin3d'
  | 'rtl'
  | 'arch'
  | 'nodes'
  | 'floorplan'
  | 'materials'
  | 'memory'
  | 'interconnect'
  | 'timing'
  | 'power'
  | 'thermal'
  | 'manufacturing'
  | 'optim'
  | 'verification'
  | 'tapeout'
  | 'reports';

@Injectable({
  providedIn: 'root'
})
export class TwinLabStateService {
  private physics = inject(SemiconductorPhysicsService);

  // Available Process Nodes with rigorous provenance tagging
  public readonly processNodes: ProcessNodeProfile[] = [
    {
      id: 'sky130',
      name: 'SkyWater SKY130 (130nm CMOS)',
      foundry: 'SkyWater Technology',
      nodeNm: 130,
      provenance: 'VERIFIED_PDK',
      nominalVdd: 1.8,
      metalStackCount: 5,
      gateLengthNm: 150,
      contactedPolyPitchNm: 500,
      sramBitcellAreaUm2: 4.80,
      waferDiameterMm: 200,
      waferCostUsd: 1850,
      maskSetCostUsd: 75000,
      defectDensityD0PerCm2: 0.18,
      typicalFmaxMhz: 125,
      gateDensityKgatesPerMm2: 95,
      description: 'Open source silicon-proven PDK for IoT and first-silicon silicon validation.',
      pdkAvailable: true
    },
    {
      id: 'gf180mcu',
      name: 'GlobalFoundries GF180MCU (180nm)',
      foundry: 'GlobalFoundries',
      nodeNm: 180,
      provenance: 'VERIFIED_PDK',
      nominalVdd: 3.3,
      metalStackCount: 5,
      gateLengthNm: 280,
      contactedPolyPitchNm: 750,
      sramBitcellAreaUm2: 8.50,
      waferDiameterMm: 200,
      waferCostUsd: 1250,
      maskSetCostUsd: 45000,
      defectDensityD0PerCm2: 0.22,
      typicalFmaxMhz: 85,
      gateDensityKgatesPerMm2: 55,
      description: 'High-voltage robust open source automotive and mixed-signal PDK.',
      pdkAvailable: true
    },
    {
      id: 'tsmc65',
      name: 'TSMC 65nm GP (General Purpose)',
      foundry: 'TSMC',
      nodeNm: 65,
      provenance: 'PUBLISHED_VENDOR',
      nominalVdd: 1.2,
      metalStackCount: 7,
      gateLengthNm: 60,
      contactedPolyPitchNm: 220,
      sramBitcellAreaUm2: 0.52,
      waferDiameterMm: 300,
      waferCostUsd: 3200,
      maskSetCostUsd: 280000,
      defectDensityD0PerCm2: 0.09,
      typicalFmaxMhz: 450,
      gateDensityKgatesPerMm2: 380,
      description: 'Mature commercial bulk CMOS with balanced performance and leakage.',
      pdkAvailable: false
    },
    {
      id: 'tsmc28',
      name: 'TSMC 28nm HPC+ (High Performance Compact)',
      foundry: 'TSMC',
      nodeNm: 28,
      provenance: 'PUBLISHED_VENDOR',
      nominalVdd: 0.9,
      metalStackCount: 8,
      gateLengthNm: 28,
      contactedPolyPitchNm: 115,
      sramBitcellAreaUm2: 0.127,
      waferDiameterMm: 300,
      waferCostUsd: 4800,
      maskSetCostUsd: 850000,
      defectDensityD0PerCm2: 0.06,
      typicalFmaxMhz: 950,
      gateDensityKgatesPerMm2: 1200,
      description: 'High-K Metal Gate (HKMG) planar node for enterprise vector and tensor workloads.',
      pdkAvailable: false
    },
    {
      id: 'ihp_sg13g2',
      name: 'IHP SG13G2 (130nm BiCMOS)',
      foundry: 'IHP Microelectronics',
      nodeNm: 130,
      provenance: 'VERIFIED_PDK',
      nominalVdd: 1.2,
      metalStackCount: 5,
      gateLengthNm: 130,
      contactedPolyPitchNm: 480,
      sramBitcellAreaUm2: 4.20,
      waferDiameterMm: 200,
      waferCostUsd: 2100,
      maskSetCostUsd: 95000,
      defectDensityD0PerCm2: 0.15,
      typicalFmaxMhz: 160,
      gateDensityKgatesPerMm2: 110,
      description: 'High-speed European open research BiCMOS process with SiGe HBT.',
      pdkAvailable: true
    },
    {
      id: 'gaafet2nm',
      name: 'Advanced 2nm GAAFET (Experimental)',
      foundry: 'Advanced Foundries Consortium',
      nodeNm: 2,
      provenance: 'ANALYTICAL',
      nominalVdd: 0.65,
      metalStackCount: 10,
      gateLengthNm: 12,
      contactedPolyPitchNm: 42,
      sramBitcellAreaUm2: 0.021,
      waferDiameterMm: 300,
      waferCostUsd: 14500,
      maskSetCostUsd: 4500000,
      defectDensityD0PerCm2: 0.08,
      typicalFmaxMhz: 2400,
      gateDensityKgatesPerMm2: 6800,
      description: 'Stacked horizontal silicon nanosheets with backside power delivery (BSPDN).',
      pdkAvailable: false
    }
  ];

  // Core State Signals
  public activeTab = signal<MainNavTab>('twin3d');
  public activeFamily = signal<SilicaFluxFamily>('SilicaFlux-V');
  public selectedNodeId = signal<string>('sky130');
  public fidelityLevel = signal<FidelityLevel>('LEVEL_2');
  public activeOverlay = signal<OverlayMode>('none');
  public is2dView = signal<boolean>(false);
  public isExplodedView = signal<boolean>(false);
  public selectedBlockId = signal<string | null>('cpu_core_0');

  // Die Dimension (in micrometers)
  public dieWidthUm = signal<number>(2400); // 2.4 mm x 2.4 mm
  public dieHeightUm = signal<number>(2400);

  // Architecture Configuration for SilicaFlux
  public archConfig = signal<ArchitectureConfig>({
    family: 'SilicaFlux-V',
    cpu: {
      coreCount: 1,
      pipelineStages: 5,
      freqTargetMhz: 125,
      branchPredictor: 'Bimodal',
      registersCount: 32,
      l1iCacheKb: 16,
      l1dCacheKb: 16
    },
    vector: {
      laneCount: 4,
      datapathWidthBits: 128,
      precisionModes: ['INT8', 'FP16'],
      registerFileSizeKb: 8,
      scratchpadCapacityKb: 32
    },
    tensor: {
      macArrayDim: 4, // 4x4 array
      arithmeticType: 'INT8',
      accumulatorPrecision: 'INT32',
      tilingDepth: 16,
      localBufferKb: 32
    },
    memory: {
      sramBankCount: 4,
      sramMacroSizeKb: 64, // 256KB total
      memoryBusWidthBits: 128,
      l2CacheKb: 0,
      eccMode: 'SECDED'
    },
    interconnect: {
      topology: 'Crossbar',
      arbitration: 'Round-Robin',
      busWidthBits: 128,
      cdcFifoDepth: 8
    }
  });

  // Metal Stack Definition
  public metalLayers = signal<MetalLayerInfo[]>([
    { layer: 'M1', name: 'Metal 1 (Local StdCell Routing)', direction: 'horizontal', pitchUm: 0.34, minWidthUm: 0.14, thicknessUm: 0.28, sheetResOhmSq: 0.125, color: '#0ea5e9', visible: true, elevationUm: 0.8 },
    { layer: 'M2', name: 'Metal 2 (Vertical Signal Routes)', direction: 'vertical', pitchUm: 0.38, minWidthUm: 0.16, thicknessUm: 0.32, sheetResOhmSq: 0.110, color: '#38bdf8', visible: true, elevationUm: 1.4 },
    { layer: 'M3', name: 'Metal 3 (Horizontal Intermediate)', direction: 'horizontal', pitchUm: 0.44, minWidthUm: 0.20, thicknessUm: 0.38, sheetResOhmSq: 0.095, color: '#6366f1', visible: true, elevationUm: 2.1 },
    { layer: 'M4', name: 'Metal 4 (Vertical Intermediate)', direction: 'vertical', pitchUm: 0.52, minWidthUm: 0.24, thicknessUm: 0.45, sheetResOhmSq: 0.075, color: '#8b5cf6', visible: true, elevationUm: 2.8 },
    { layer: 'M5', name: 'Metal 5 (Clock Trunk & Top Straps)', direction: 'horizontal', pitchUm: 1.20, minWidthUm: 0.60, thicknessUm: 0.85, sheetResOhmSq: 0.035, color: '#f59e0b', visible: true, elevationUm: 3.8 }
  ]);

  // Semiconductor Layout Blocks (Micrometers)
  public blocks = signal<SemiconductorBlock[]>([
    {
      id: 'cpu_core_0',
      name: 'SilicaFlux-V CPU Core (RV32IMF)',
      type: 'CPU_CORE',
      x: 320,
      y: 320,
      width: 580,
      height: 520,
      zLevel: 0.2,
      color: '#6366f1',
      dynamicPowerMw: 38.5,
      leakagePowerMw: 2.1,
      activityFactor: 0.65,
      cellCount: 42100,
      timingSlackPs: 240,
      metalDensity: 0.68,
      voltageDomain: 'VDD_CORE (1.8V)',
      clockDomain: 'clk_core (125 MHz)',
      temperatureC: 44.2,
      irDropMv: 18.5
    },
    {
      id: 'vector_unit',
      name: 'SIMD-4 Vector Execution Engine',
      type: 'VECTOR_UNIT',
      x: 940,
      y: 320,
      width: 620,
      height: 520,
      zLevel: 0.2,
      color: '#06b6d4',
      dynamicPowerMw: 62.0,
      leakagePowerMw: 4.5,
      activityFactor: 0.78,
      cellCount: 68500,
      timingSlackPs: 110,
      metalDensity: 0.74,
      voltageDomain: 'VDD_CORE (1.8V)',
      clockDomain: 'clk_core (125 MHz)',
      temperatureC: 56.4,
      irDropMv: 32.1
    },
    {
      id: 'tensor_array',
      name: '4x4 Systolic Tensor MAC Array',
      type: 'TENSOR_ARRAY',
      x: 940,
      y: 880,
      width: 620,
      height: 580,
      zLevel: 0.2,
      color: '#10b981',
      dynamicPowerMw: 95.0,
      leakagePowerMw: 6.8,
      activityFactor: 0.88,
      cellCount: 92400,
      timingSlackPs: 65,
      metalDensity: 0.81,
      voltageDomain: 'VDD_CORE (1.8V)',
      clockDomain: 'clk_tensor (125 MHz)',
      temperatureC: 68.9,
      irDropMv: 48.6
    },
    {
      id: 'sram_bank_0',
      name: 'SRAM Macro Bank 0 (64 KiB L1 Scratchpad)',
      type: 'SRAM_BANK',
      x: 320,
      y: 880,
      width: 580,
      height: 280,
      zLevel: 0.2,
      color: '#d97706',
      dynamicPowerMw: 24.0,
      leakagePowerMw: 5.2,
      activityFactor: 0.45,
      cellCount: 262144, // bits
      timingSlackPs: 380,
      metalDensity: 0.58,
      voltageDomain: 'VDD_SRAM (1.8V)',
      clockDomain: 'clk_core (125 MHz)',
      temperatureC: 41.5,
      irDropMv: 14.2
    },
    {
      id: 'sram_bank_1',
      name: 'SRAM Macro Bank 1 (64 KiB Tensor Buffer)',
      type: 'SRAM_BANK',
      x: 320,
      y: 1180,
      width: 580,
      height: 280,
      zLevel: 0.2,
      color: '#d97706',
      dynamicPowerMw: 26.5,
      leakagePowerMw: 5.2,
      activityFactor: 0.52,
      cellCount: 262144,
      timingSlackPs: 360,
      metalDensity: 0.59,
      voltageDomain: 'VDD_SRAM (1.8V)',
      clockDomain: 'clk_tensor (125 MHz)',
      temperatureC: 43.1,
      irDropMv: 16.4
    },
    {
      id: 'noc_router',
      name: 'AXI4-Lite Non-Blocking Interconnect Crossbar',
      type: 'NOC_ROUTER',
      x: 1600,
      y: 320,
      width: 480,
      height: 520,
      zLevel: 0.2,
      color: '#475569',
      dynamicPowerMw: 18.2,
      leakagePowerMw: 1.5,
      activityFactor: 0.55,
      cellCount: 18200,
      timingSlackPs: 420,
      metalDensity: 0.72,
      voltageDomain: 'VDD_CORE (1.8V)',
      clockDomain: 'clk_core (125 MHz)',
      temperatureC: 38.6,
      irDropMv: 11.5
    },
    {
      id: 'mem_ctrl',
      name: 'HyperBus / QSPI Memory Controller',
      type: 'MEM_CTRL',
      x: 1600,
      y: 880,
      width: 480,
      height: 580,
      zLevel: 0.2,
      color: '#8b5cf6',
      dynamicPowerMw: 28.0,
      leakagePowerMw: 2.8,
      activityFactor: 0.60,
      cellCount: 31000,
      timingSlackPs: 310,
      metalDensity: 0.65,
      voltageDomain: 'VDD_CORE (1.8V)',
      clockDomain: 'clk_mem (100 MHz)',
      temperatureC: 42.8,
      irDropMv: 17.2
    },
    {
      id: 'clk_gen',
      name: 'Phase-Locked Loop (PLL) & Clock Tree Root',
      type: 'CLK_GEN',
      x: 320,
      y: 1500,
      width: 420,
      height: 380,
      zLevel: 0.2,
      color: '#ec4899',
      dynamicPowerMw: 14.5,
      leakagePowerMw: 1.2,
      activityFactor: 1.0,
      cellCount: 12000,
      timingSlackPs: 600,
      metalDensity: 0.52,
      voltageDomain: 'VDD_ANALOG (1.8V)',
      clockDomain: 'ref_clk (25 MHz)',
      temperatureC: 36.4,
      irDropMv: 8.4
    },
    {
      id: 'dft_jtag',
      name: 'IEEE 1149.1 JTAG TAP & Scan Aggregator',
      type: 'DFT_JTAG',
      x: 780,
      y: 1500,
      width: 380,
      height: 380,
      zLevel: 0.2,
      color: '#14b8a6',
      dynamicPowerMw: 6.2,
      leakagePowerMw: 0.8,
      activityFactor: 0.15,
      cellCount: 9800,
      timingSlackPs: 850,
      metalDensity: 0.44,
      voltageDomain: 'VDD_CORE (1.8V)',
      clockDomain: 'tck (20 MHz)',
      temperatureC: 32.1,
      irDropMv: 5.2
    },
    {
      id: 'power_mgmt',
      name: 'Low-Dropout LDOs & Bandgap Reference',
      type: 'POWER_MGMT',
      x: 1200,
      y: 1500,
      width: 420,
      height: 380,
      zLevel: 0.2,
      color: '#f97316',
      dynamicPowerMw: 11.0,
      leakagePowerMw: 1.6,
      activityFactor: 0.35,
      cellCount: 8500,
      timingSlackPs: 750,
      metalDensity: 0.49,
      voltageDomain: 'VDD_ANALOG (1.8V)',
      clockDomain: 'dc',
      temperatureC: 35.8,
      irDropMv: 7.9
    },
    {
      id: 'io_pad_ring',
      name: 'ESD Protected 3.3V/1.8V I/O Pad Ring (64 Pins)',
      type: 'IO_PAD_RING',
      x: 60,
      y: 60,
      width: 2280,
      height: 2280,
      zLevel: 0.05,
      color: '#b45309',
      dynamicPowerMw: 32.0,
      leakagePowerMw: 3.2,
      activityFactor: 0.40,
      cellCount: 64, // IO cells
      timingSlackPs: 500,
      metalDensity: 0.35,
      voltageDomain: 'VDD_IO (3.3V)',
      clockDomain: 'async',
      temperatureC: 34.0,
      irDropMv: 12.0,
      locked: true
    }
  ]);

  // Timing Paths (OpenSTA Reports)
  public timingPaths = signal<TimingPath[]>([
    {
      id: 'path_01',
      name: 'Tensor MAC Multiplier to Accumulator Register',
      startpoint: 'sfv_tensor_array/gen_mac[3][3].u_mac/reg_weight_q[7]',
      endpoint: 'sfv_tensor_array/gen_mac[3][3].u_mac/reg_acc_d[31]',
      clockDomain: 'clk_tensor (125 MHz)',
      dataDelayPs: 7320,
      requiredTimePs: 7385,
      slackPs: 65, // Met
      logicLevels: 14,
      isViolating: false,
      criticalArc: {
        fromBlock: 'tensor_array',
        toBlock: 'tensor_array',
        stages: [
          { name: 'sky130_fd_sc_hd__dfxtp_1', cell: 'reg_weight', delayPs: 380 },
          { name: 'sky130_fd_sc_hd__fa_1', cell: 'carry_save_adder_l1', delayPs: 620 },
          { name: 'sky130_fd_sc_hd__fa_1', cell: 'wallace_tree_l2', delayPs: 580 },
          { name: 'sky130_fd_sc_hd__cla_4', cell: 'carry_lookahead_adder', delayPs: 840 },
          { name: 'sky130_fd_sc_hd__buf_2', cell: 'driver_buf', delayPs: 210 },
          { name: 'sky130_fd_sc_hd__dfxtp_1', cell: 'reg_acc_setup', delayPs: 190 }
        ]
      }
    },
    {
      id: 'path_02',
      name: 'Vector ALU Reduction Tree to Vector Register File',
      startpoint: 'sfv_vector_unit/lane[3].u_alu/operand_b_reg[15]',
      endpoint: 'sfv_vector_unit/u_vrf/ram_bank0_din[63]',
      clockDomain: 'clk_core (125 MHz)',
      dataDelayPs: 7890,
      requiredTimePs: 8000,
      slackPs: 110,
      logicLevels: 18,
      isViolating: false,
      criticalArc: {
        fromBlock: 'vector_unit',
        toBlock: 'vector_unit',
        stages: [
          { name: 'sky130_fd_sc_hd__dfxtp_1', cell: 'alu_in_ff', delayPs: 410 },
          { name: 'sky130_fd_sc_hd__xnor2_1', cell: 'addsub_mux', delayPs: 340 },
          { name: 'sky130_fd_sc_hd__fa_1', cell: 'tree_stage0', delayPs: 550 },
          { name: 'sky130_fd_sc_hd__mux2_2', cell: 'vrf_write_mux', delayPs: 310 }
        ]
      }
    },
    {
      id: 'path_03',
      name: 'CPU ALU Branch Comparator to PC Fetch Unit',
      startpoint: 'sfv_core/u_execute/reg_rs1_val[31]',
      endpoint: 'sfv_core/u_fetch/reg_target_pc[31]',
      clockDomain: 'clk_core (125 MHz)',
      dataDelayPs: 7760,
      requiredTimePs: 8000,
      slackPs: 240,
      logicLevels: 12,
      isViolating: false,
      criticalArc: {
        fromBlock: 'cpu_core_0',
        toBlock: 'cpu_core_0',
        stages: [
          { name: 'sky130_fd_sc_hd__dfxtp_1', cell: 'rs1_reg', delayPs: 390 },
          { name: 'sky130_fd_sc_hd__sub_4', cell: 'branch_cmp', delayPs: 790 },
          { name: 'sky130_fd_sc_hd__mux2_1', cell: 'pc_sel_mux', delayPs: 280 }
        ]
      }
    },
    {
      id: 'path_04',
      name: 'Crossbar Matrix Arbiter Request to Grant Handshake',
      startpoint: 'sfv_noc/u_xbar/req_arb_vec[2]',
      endpoint: 'sfv_noc/u_xbar/gnt_ack_vec[2]',
      clockDomain: 'clk_core (125 MHz)',
      dataDelayPs: 7580,
      requiredTimePs: 8000,
      slackPs: 420,
      logicLevels: 9,
      isViolating: false,
      criticalArc: {
        fromBlock: 'noc_router',
        toBlock: 'noc_router',
        stages: [
          { name: 'sky130_fd_sc_hd__dfxtp_1', cell: 'req_ff', delayPs: 350 },
          { name: 'sky130_fd_sc_hd__priority_4', cell: 'arbiter_tree', delayPs: 520 },
          { name: 'sky130_fd_sc_hd__dfxtp_1', cell: 'gnt_ff', delayPs: 290 }
        ]
      }
    }
  ]);

  // EDA 14-Stage Execution Pipeline
  public edaStages = signal<EdaStage[]>([
    {
      id: 'stage_rtl',
      number: 1,
      name: 'RTL Discovery & Parsing',
      category: 'Frontend',
      tool: 'SilicaFlux AST Parser v3.2',
      status: 'SUCCESS',
      runtimeSec: 4.2,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        '[INFO] Scanning repository for .sf and .v / .sv files...',
        '[INFO] Found candidate top module: silicaflux_v_top',
        '[INFO] Module declarations identified: 8 valid, 0 duplicates',
        '[INFO] AST tree constructed successfully with zero dangling parameters.'
      ],
      artifacts: [{ filename: 'module_hierarchy.json', sizeKb: 34, type: 'JSON' }]
    },
    {
      id: 'stage_lint',
      number: 2,
      name: 'RTL Linting & Structural Verification',
      category: 'Frontend',
      tool: 'Verilator 5.028',
      status: 'SUCCESS',
      runtimeSec: 8.5,
      warningsCount: 2,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'verilator --lint-only -Wall --timing -f flist.f',
        '%Warning-WIDTH: sfv_tensor_array.v:142: Operator ASSIGNW expects 32 bits on RHS, got 16',
        '%Warning-UNUSED: sfv_core_pipeline.v:88: Signal is not used: debug_halt_ack_i',
        '[PASS] Zero fatal syntax errors. All clock-domain crossing synchronizers verified.'
      ],
      artifacts: [{ filename: 'verilator_lint.log', sizeKb: 18, type: 'LOG' }]
    },
    {
      id: 'stage_synth',
      number: 3,
      name: 'Logic Synthesis & Gate Mapping',
      category: 'Frontend',
      tool: 'Yosys 0.44',
      status: 'SUCCESS',
      runtimeSec: 42.1,
      warningsCount: 4,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'yosys -c synth_sky130.tcl',
        'Executing techmap with sky130_fd_sc_hd target library...',
        'ABC: Area-driven logic optimization completed in 12.8s.',
        'Chip gate count summary: 365,400 standard cell instances.',
        'Total cell area: 2.18 mm^2. Estimated sequential cell count: 48,220.'
      ],
      artifacts: [
        { filename: 'silicaflux_v.synth.v', sizeKb: 1420, type: 'NETLIST' },
        { filename: 'synth_area_report.rep', sizeKb: 64, type: 'REPORT' }
      ]
    },
    {
      id: 'stage_floorplan',
      number: 4,
      name: 'Floorplanning & Macro Placement',
      category: 'Physical Design',
      tool: 'OpenROAD / TritonMacroPlace',
      status: 'SUCCESS',
      runtimeSec: 18.2,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'initialize_floorplan -die_area {0 0 2400 2400} -core_area {120 120 2280 2280}',
        'Placing 4x SRAM macro arrays with 60um keepout halo...',
        'Macro placement converged with 0 overlap violations. Target core density: 64.2%.'
      ],
      artifacts: [{ filename: 'floorplan.def', sizeKb: 2840, type: 'DEF' }]
    },
    {
      id: 'stage_pdn',
      number: 5,
      name: 'Power Delivery Network (PDN) Insertion',
      category: 'Physical Design',
      tool: 'OpenROAD PDNGlobal',
      status: 'SUCCESS',
      runtimeSec: 12.0,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'add_pdn_stripe -grid stdcell -layer met4 -width 1.6 -pitch 40.0',
        'add_pdn_stripe -grid stdcell -layer met5 -width 4.0 -pitch 80.0',
        'Power mesh connectivity verified. 100% standard cell rows connected to VDD/VSS.'
      ],
      artifacts: [{ filename: 'pdn_mesh.def', sizeKb: 3120, type: 'DEF' }]
    },
    {
      id: 'stage_place',
      number: 6,
      name: 'Global & Detailed Standard Cell Placement',
      category: 'Physical Design',
      tool: 'RePlAce / OpenDP',
      status: 'SUCCESS',
      runtimeSec: 85.4,
      warningsCount: 1,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'global_placement -density 0.65 -timing_driven',
        'Detailed placement legalised 365,400 instances.',
        'Max displacement: 8.4 um. Zero cell overlapping.'
      ],
      artifacts: [{ filename: 'placed.def', sizeKb: 8900, type: 'DEF' }]
    },
    {
      id: 'stage_cts',
      number: 7,
      name: 'Clock Tree Synthesis (CTS)',
      category: 'Physical Design',
      tool: 'TritonCTS',
      status: 'SUCCESS',
      runtimeSec: 34.6,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'clock_tree_synthesis -root_clk clk_core -buf_list {sky130_fd_sc_hd__clkbuf_4 sky130_fd_sc_hd__clkbuf_8}',
        'Total clock buffers inserted: 2,410. Clock tree depth: 6 levels.',
        'Worst clock skew across all sinks: 78 ps. Maximum insertion delay: 920 ps.'
      ],
      artifacts: [{ filename: 'cts.def', sizeKb: 9200, type: 'DEF' }]
    },
    {
      id: 'stage_route',
      number: 8,
      name: 'Global & Detailed Routing',
      category: 'Physical Design',
      tool: 'FastRoute / TritonRoute',
      status: 'SUCCESS',
      runtimeSec: 142.0,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'global_route -guide_file route.guide',
        'detailed_route -bottom_routing_layer met1 -top_routing_layer met5',
        'Routing completed with 0 DRC violations. Total routed wirelength: 4.82 meters.',
        'Total via count: 482,190. Layer utilization: M1=64%, M2=58%, M3=49%, M4=38%, M5=22%.'
      ],
      artifacts: [{ filename: 'routed.def', sizeKb: 14500, type: 'DEF' }]
    },
    {
      id: 'stage_sta',
      number: 9,
      name: 'Static Timing Analysis (Signoff STA)',
      category: 'Signoff',
      tool: 'OpenSTA 2.6',
      status: 'SUCCESS',
      runtimeSec: 28.3,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'read_spef extracted.spef',
        'report_checks -path_delay max -format full_clock_expanded',
        'Worst Negative Slack (WNS): +65 ps (MET)',
        'Total Negative Slack (TNS): 0 ps',
        'Worst Hold Slack (WHS): +180 ps (MET)',
        'Design meets timing target of 125 MHz across Slow-Slow (SS) corner at 125C.'
      ],
      artifacts: [{ filename: 'timing_signoff.rep', sizeKb: 420, type: 'REPORT' }]
    },
    {
      id: 'stage_drc',
      number: 10,
      name: 'Design Rule Checking (DRC)',
      category: 'Signoff',
      tool: 'Magic 8.3 / KLayout 0.28',
      status: 'SUCCESS',
      runtimeSec: 62.0,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'Running foundry signoff rule deck: sky130A.drc',
        'Checking minimum spacing, width, notch, well tap density, and antenna rules...',
        'Total DRC violations: 0. Clean signoff.'
      ],
      artifacts: [{ filename: 'drc_summary.rep', sizeKb: 92, type: 'REPORT' }]
    },
    {
      id: 'stage_lvs',
      number: 11,
      name: 'Layout Versus Schematic (LVS)',
      category: 'Signoff',
      tool: 'Netgen 1.5',
      status: 'SUCCESS',
      runtimeSec: 48.0,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'netgen -batch lvs "silicaflux_v.ext" "silicaflux_v.synth.v" sky130A_setup.tcl',
        'Devices matched: 1,420,800. Nets matched: 372,110.',
        'Result: Circuits match uniquely! Netlists are identical.'
      ],
      artifacts: [{ filename: 'lvs_match.rep', sizeKb: 140, type: 'REPORT' }]
    },
    {
      id: 'stage_ir',
      number: 12,
      name: 'Electromigration & IR-Drop Signoff',
      category: 'Signoff',
      tool: 'Voltus / PSM Solver',
      status: 'SUCCESS',
      runtimeSec: 31.0,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'Static IR-Drop max: 48.6 mV (2.7% of VDD 1.8V, limit < 5.0%).',
        'EM current density max: 0.84 mA/um^2 (foundry limit 1.5 mA/um^2).',
        'All power rails comply with signoff reliability thresholds.'
      ],
      artifacts: [{ filename: 'ir_drop_signoff.rep', sizeKb: 210, type: 'REPORT' }]
    },
    {
      id: 'stage_gds',
      number: 13,
      name: 'GDSII / OASIS Stream-Out',
      category: 'Signoff',
      tool: 'KLayout Stream Engine',
      status: 'SUCCESS',
      runtimeSec: 19.5,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'Merging standard cell LEF/GDS with top routed DEF...',
        'Adding seal ring, dummy metal fill patterns, and foundry barcode.',
        'GDSII stream-out successful: silicaflux_v_tapeout.gds (44.8 MB).'
      ],
      artifacts: [{ filename: 'silicaflux_v_tapeout.gds', sizeKb: 44800, type: 'GDSII' }]
    },
    {
      id: 'stage_manifest',
      number: 14,
      name: 'Tapeout Manifest & Cryptographic Signoff',
      category: 'Signoff',
      tool: 'Aureom Tapeout Verifier',
      status: 'SUCCESS',
      runtimeSec: 3.1,
      warningsCount: 0,
      errorsCount: 0,
      sourceHash: 'sha256:7b91d84f...c120',
      logLines: [
        'Generating cryptographic checksums for all fabrication artifacts.',
        'SHA256(silicaflux_v_tapeout.gds) = b4f8c92a1...e702',
        'Signoff manifest signed with release key. Ready for foundry submission.'
      ],
      artifacts: [{ filename: 'tapeout_manifest.json', sizeKb: 12, type: 'JSON' }]
    }
  ]);

  // Tapeout Readiness 10-Gate System
  public tapeoutGates = signal<TapeoutGate[]>([
    {
      gateNumber: 1,
      title: 'Gate 1: RTL Syntactically & Structurally Valid',
      category: 'Frontend RTL',
      criteria: 'Zero syntax errors, 100% parameter resolution, clean elaboration, zero latches.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-RTL-LINT-001 (Verilator clean log)',
      owner: 'Lead RTL Architect (Aureom.AI)',
      lastUpdated: '2026-11-01',
      blockingIssues: []
    },
    {
      gateNumber: 2,
      title: 'Gate 2: Functional Verification Closure',
      category: 'Verification',
      criteria: '100% line coverage, 95%+ branch/toggle coverage, 10,000+ random instruction regression runs passed.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-VERIF-REGRESS-042 (Cocotb / UVM suite)',
      owner: 'Principal Verification Engineer',
      lastUpdated: '2026-11-02',
      blockingIssues: []
    },
    {
      gateNumber: 3,
      title: 'Gate 3: Synthesis & Gate-Level Equivalence',
      category: 'Frontend RTL',
      criteria: 'Target library mapping clean, formal LEC match against golden RTL, zero multidriven nets.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-SYNTH-AREA-019 (Yosys + Formality rep)',
      owner: 'ASIC Physical Design Lead',
      lastUpdated: '2026-11-02',
      blockingIssues: []
    },
    {
      gateNumber: 4,
      title: 'Gate 4: Memory & Analog Hard-IP Signoff',
      category: 'Physical IP',
      criteria: 'Silicon-proven SRAM compiler macros, PLL locking range verified, ESD I/O clamp structures validated.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-HARD-IP-SIGNOFF-008',
      owner: 'Foundry IP Specialist',
      lastUpdated: '2026-10-28',
      blockingIssues: []
    },
    {
      gateNumber: 5,
      title: 'Gate 5: DFT Integration & Scan Coverage > 95%',
      category: 'Manufacturing Test',
      criteria: 'Stuck-at fault coverage > 98.0%, transition delay coverage > 94%, SRAM MBIST controller verified.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-DFT-ATPG-014 (TetraMAX ATPG rep)',
      owner: 'DFT Test Engineer',
      lastUpdated: '2026-11-02',
      blockingIssues: []
    },
    {
      gateNumber: 6,
      title: 'Gate 6: Static Timing Closure Across All PVT Corners',
      category: 'Signoff',
      criteria: 'WNS >= 0 ps across SS (0.9V/125C) and FF (1.1V/-40C), min hold slack >= 0 ps, clock skew < 100 ps.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-STA-SIGNOFF-033 (OpenSTA report)',
      owner: 'Timing Closure Lead',
      lastUpdated: '2026-11-02',
      blockingIssues: []
    },
    {
      gateNumber: 7,
      title: 'Gate 7: Physical Verification (DRC & LVS)',
      category: 'Physical Signoff',
      criteria: 'Zero foundry rule violations (DRC=0), zero electrical schematic mismatches (LVS=0), antenna clean.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-CALIBRE-DRC-LVS-009',
      owner: 'Physical Design Engineer',
      lastUpdated: '2026-11-02',
      blockingIssues: []
    },
    {
      gateNumber: 8,
      title: 'Gate 8: Power Integrity & Electromigration Signoff',
      category: 'Reliability',
      criteria: 'Static IR-drop < 5% VDD, dynamic voltage droop < 10%, metal wire EM current density below foundry limits.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-VOLTUS-IR-EM-017',
      owner: 'Power Integrity Specialist',
      lastUpdated: '2026-11-02',
      blockingIssues: []
    },
    {
      gateNumber: 9,
      title: 'Gate 9: Foundry-Required Tapeout Review & Mask Prep',
      category: 'Foundry Ops',
      criteria: 'Seal ring, dummy metal fill, PCM test structures placed, foundry signoff waiver package signed.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-FOUNDRY-CHECKLIST-SKY130-A',
      owner: 'Foundry Technical Interface',
      lastUpdated: '2026-11-03',
      blockingIssues: []
    },
    {
      gateNumber: 10,
      title: 'Gate 10: Release Package Approval & Cryptographic Hash',
      category: 'Executive Signoff',
      criteria: 'Final GDSII / OASIS stream verified, multi-party cryptographic signature completed, tapeout authorization signed.',
      status: 'APPROVED',
      evidenceDoc: 'DOC-TAPEOUT-AUTH-2026-V1',
      owner: 'VP of Silicon Engineering',
      lastUpdated: '2026-11-03',
      blockingIssues: []
    }
  ]);

  // Derived Computed Values
  public activeNode = computed(() => {
    return this.processNodes.find(n => n.id === this.selectedNodeId()) || this.processNodes[0];
  });

  public selectedBlock = computed(() => {
    const id = this.selectedBlockId();
    if (!id) return null;
    return this.blocks().find(b => b.id === id) || null;
  });

  public totalChipPowerMw = computed(() => {
    return this.blocks().reduce((acc, b) => acc + b.dynamicPowerMw + b.leakagePowerMw, 0);
  });

  public totalCellCount = computed(() => {
    return this.blocks().reduce((acc, b) => acc + (b.type !== 'IO_PAD_RING' ? b.cellCount : 0), 0);
  });

  public dieAreaMm2 = computed(() => {
    return (this.dieWidthUm() * 1e-3) * (this.dieHeightUm() * 1e-3);
  });

  // Physics Simulation Results
  public thermalResult = computed<ThermalResult>(() => {
    return this.physics.solveThermalField(
      this.dieWidthUm(),
      this.dieHeightUm(),
      this.blocks(),
      25.0,
      'active_air',
      32
    );
  });

  public powerGridResult = computed<PowerGridResult>(() => {
    return this.physics.solvePowerGrid(
      this.dieWidthUm(),
      this.dieHeightUm(),
      this.blocks(),
      this.activeNode().nominalVdd,
      0.035,
      25,
      28
    );
  });

  public waferYieldResult = computed<WaferYieldResult>(() => {
    const node = this.activeNode();
    return this.physics.calculateWaferEconomics(
      node.waferDiameterMm,
      this.dieWidthUm() * 1e-3,
      this.dieHeightUm() * 1e-3,
      node.defectDensityD0PerCm2,
      node.waferCostUsd,
      node.maskSetCostUsd,
      1.85,
      0.65,
      3.0,
      50000
    );
  });

  public rooflineResult = computed(() => {
    return this.physics.calculateRoofline(this.archConfig());
  });

  // Console Telemetry & Logs
  public consoleLogs = signal<{ timestamp: string; level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS' | 'TIMING'; message: string; tool?: string }[]>([
    { timestamp: '00:01:14.204', level: 'INFO', message: 'SilicaFlux TwinLab v4.2 initialized in Demonstration Mode.', tool: 'System' },
    { timestamp: '00:01:14.288', level: 'INFO', message: 'Loaded SilicaFlux-V reference architecture (32-bit RV32IMF, 4x SIMD lanes, 4x4 Systolic INT8 MAC, 256KB SRAM).', tool: 'Architecture' },
    { timestamp: '00:01:14.390', level: 'SUCCESS', message: 'SkyWater SKY130 verified open PDK profiles loaded. 5-metal stack configured.', tool: 'PDK Engine' },
    { timestamp: '00:01:14.512', level: 'TIMING', message: 'OpenSTA STA report imported. Worst Negative Slack: +65 ps. Frequency: 125 MHz (MET).', tool: 'OpenSTA' },
    { timestamp: '00:01:14.650', level: 'INFO', message: '2D/3D semiconductor digital twin ready for interactive physical inspection.', tool: '3D Engine' }
  ]);

  // Methods
  public setTab(tab: MainNavTab) {
    this.activeTab.set(tab);
  }

  public setFamily(family: SilicaFluxFamily) {
    this.activeFamily.set(family);
    this.archConfig.update(cfg => {
      const updated = { ...cfg, family };
      if (family === 'SilicaFlux-V') {
        updated.cpu.coreCount = 1;
        updated.vector.laneCount = 4;
        updated.tensor.macArrayDim = 4;
        updated.memory.sramMacroSizeKb = 64;
      } else if (family === 'SilicaFlux') {
        updated.cpu.coreCount = 4;
        updated.vector.laneCount = 8;
        updated.tensor.macArrayDim = 8;
        updated.memory.sramMacroSizeKb = 128;
      } else if (family === 'SilicaFlux-X') {
        updated.cpu.coreCount = 2;
        updated.vector.laneCount = 8;
        updated.tensor.macArrayDim = 16;
        updated.memory.sramMacroSizeKb = 256;
      } else if (family === 'SilicaFlux-M') {
        updated.cpu.coreCount = 16;
        updated.vector.laneCount = 4;
        updated.tensor.macArrayDim = 8;
        updated.memory.sramMacroSizeKb = 128;
      } else if (family === 'SilicaFlux-C') {
        updated.cpu.coreCount = 8;
        updated.vector.laneCount = 16;
        updated.tensor.macArrayDim = 16;
        updated.memory.sramMacroSizeKb = 512;
      }
      return updated;
    });

    this.logConsole('INFO', `Switched architecture profile to ${family}. Parameters reloaded.`, 'ArchEngine');
  }

  public setProcessNode(nodeId: string) {
    this.selectedNodeId.set(nodeId);
    const node = this.activeNode();
    this.logConsole('INFO', `Active process node changed to ${node.name} (${node.provenance}).`, 'PDK Engine');
  }

  public setFidelity(level: FidelityLevel) {
    this.fidelityLevel.set(level);
    this.logConsole('INFO', `Fidelity set to ${level}: ${
      level === 'LEVEL_1' ? 'Conceptual Architecture' :
      level === 'LEVEL_2' ? 'Placement & Macro Positions' : 'Imported DEF/GDSII Layer Geometry'
    }`, '3D Engine');
  }

  public setOverlay(mode: OverlayMode) {
    this.activeOverlay.set(mode);
  }

  public toggleLayerVisibility(layerName: string) {
    this.metalLayers.update(layers => 
      layers.map(l => l.layer === layerName ? { ...l, visible: !l.visible } : l)
    );
  }

  public selectBlock(blockId: string | null) {
    this.selectedBlockId.set(blockId);
  }

  public updateBlockPosition(blockId: string, x: number, y: number) {
    this.blocks.update(blocks => 
      blocks.map(b => b.id === blockId ? { ...b, x, y } : b)
    );
  }

  public setBlocks(newBlocks: SemiconductorBlock[]) {
    this.blocks.set(newBlocks);
  }

  public logConsole(level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS' | 'TIMING', message: string, tool?: string) {
    const now = new Date();
    const pad = (n: number, z = 2) => String(n).padStart(z, '0');
    const timestamp = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}.${pad(now.getMilliseconds(), 3)}`;
    this.consoleLogs.update(logs => [{ timestamp, level, message, tool }, ...logs.slice(0, 199)]);
  }

  public runEdaFlow() {
    this.logConsole('INFO', 'Starting full ASIC implementation run (RTL -> GDSII Stream-out)...', 'EDA Runner');
    // Simulate real pipeline execution step
    setTimeout(() => {
      this.logConsole('SUCCESS', 'All 14 implementation stages completed with zero violations.', 'EDA Runner');
    }, 1200);
  }
}
