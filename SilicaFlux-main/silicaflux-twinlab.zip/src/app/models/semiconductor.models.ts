export type SilicaFluxFamily = 
  | 'SilicaFlux-V' 
  | 'SilicaFlux' 
  | 'SilicaFlux-X' 
  | 'SilicaFlux-M' 
  | 'SilicaFlux-C';

export type FidelityLevel = 'LEVEL_1' | 'LEVEL_2' | 'LEVEL_3';

export type ProvenanceTag = 
  | 'VERIFIED_PDK' 
  | 'PUBLISHED_VENDOR' 
  | 'USER_SUPPLIED' 
  | 'ANALYTICAL' 
  | 'DEMO_DATA';

export type OverlayMode = 'none' | 'thermal' | 'irdrop' | 'congestion' | 'critical_path';

export type BlockType = 
  | 'CPU_CORE' 
  | 'VECTOR_UNIT' 
  | 'TENSOR_ARRAY' 
  | 'SRAM_BANK' 
  | 'NOC_ROUTER' 
  | 'MEM_CTRL' 
  | 'CLK_GEN' 
  | 'POWER_MGMT' 
  | 'IO_PAD_RING' 
  | 'DFT_JTAG';

export interface SemiconductorBlock {
  id: string;
  name: string;
  type: BlockType;
  x: number; // in micrometers (um)
  y: number; // in micrometers (um)
  width: number; // in um
  height: number; // in um
  zLevel: number; // in um (for 3D stack)
  color: string;
  dynamicPowerMw: number;
  leakagePowerMw: number;
  activityFactor: number;
  cellCount: number;
  timingSlackPs: number;
  metalDensity: number; // 0.0 - 1.0
  voltageDomain: string; // e.g., 'VDD_CORE (0.9V)', 'VDD_IO (3.3V)'
  clockDomain: string; // e.g., 'clk_main (450 MHz)'
  locked?: boolean;
  temperatureC?: number;
  irDropMv?: number;
}

export interface MetalLayerInfo {
  layer: string;
  name: string;
  direction: 'horizontal' | 'vertical';
  pitchUm: number;
  minWidthUm: number;
  thicknessUm: number;
  sheetResOhmSq: number;
  color: string;
  visible: boolean;
  elevationUm: number;
}

export interface ProcessNodeProfile {
  id: string;
  name: string;
  foundry: string;
  nodeNm: number;
  provenance: ProvenanceTag;
  nominalVdd: number;
  metalStackCount: number;
  gateLengthNm: number;
  contactedPolyPitchNm: number;
  sramBitcellAreaUm2: number;
  waferDiameterMm: number;
  waferCostUsd: number;
  maskSetCostUsd: number;
  defectDensityD0PerCm2: number;
  typicalFmaxMhz: number;
  gateDensityKgatesPerMm2: number;
  description: string;
  pdkAvailable: boolean;
}

export interface ArchitectureConfig {
  family: SilicaFluxFamily;
  cpu: {
    coreCount: number;
    pipelineStages: number;
    freqTargetMhz: number;
    branchPredictor: 'Bimodal' | 'Gshare' | 'TAGE-like' | 'Static';
    registersCount: number;
    l1iCacheKb: number;
    l1dCacheKb: number;
  };
  vector: {
    laneCount: number;
    datapathWidthBits: number;
    precisionModes: string[];
    registerFileSizeKb: number;
    scratchpadCapacityKb: number;
  };
  tensor: {
    macArrayDim: number; // e.g. 4 for 4x4, 8 for 8x8
    arithmeticType: 'INT8' | 'FP8' | 'BF16' | 'Mixed';
    accumulatorPrecision: 'INT32' | 'FP32';
    tilingDepth: number;
    localBufferKb: number;
  };
  memory: {
    sramBankCount: number;
    sramMacroSizeKb: number;
    memoryBusWidthBits: number;
    l2CacheKb: number;
    eccMode: 'None' | 'Parity' | 'SECDED';
  };
  interconnect: {
    topology: 'Crossbar' | 'Ring' | '2D-Mesh' | 'Bus';
    arbitration: 'Round-Robin' | 'Priority' | 'Weighted';
    busWidthBits: number;
    cdcFifoDepth: number;
  };
}

export interface ThermalResult {
  junctionTempMaxC: number;
  averageTempC: number;
  hotspotBlockId: string;
  hotspotCoords: { x: number; y: number };
  coolingCapacityWatts: number;
  thermalResistanceJa: number; // C/W
  thermalGrid2D: number[][]; // 2D array of temperatures in C
  gridResolution: number;
  transientPoints: { timeMs: number; tempC: number }[];
}

export interface PowerGridResult {
  nominalVdd: number;
  maxIrDropMv: number;
  averageIrDropMv: number;
  worstNodeCoords: { x: number; y: number };
  emLimitExceeded: boolean;
  maxCurrentDensityMaUm2: number;
  decapEffectivenessPct: number;
  irDropGrid2D: number[][]; // 2D array of drop in mV
  gridResolution: number;
}

export interface WaferYieldResult {
  waferDiameterMm: number;
  dieAreaMm2: number;
  grossDiesPerWafer: number;
  netGoodDiesPoisson: number;
  netGoodDiesMurphy: number;
  yieldPoissonPct: number;
  yieldMurphyPct: number;
  costPerGoodDieUsd: number;
  packagedTestCostUsd: number;
  totalPackagedCostUsd: number;
  defectMap: { x: number; y: number; isCluster: boolean }[];
  dieGrid: { row: number; col: number; x: number; y: number; isGood: boolean; isEdgeExclusion: boolean }[];
}

export interface TimingPath {
  id: string;
  name: string;
  startpoint: string;
  endpoint: string;
  clockDomain: string;
  dataDelayPs: number;
  requiredTimePs: number;
  slackPs: number;
  logicLevels: number;
  isViolating: boolean;
  criticalArc: {
    fromBlock: string;
    toBlock: string;
    stages: { name: string; cell: string; delayPs: number }[];
  };
}

export interface WorkloadRoofline {
  name: string;
  arithmeticIntensity: number; // FLOP/Byte or MAC/Byte
  attainableGflops: number;
  isMemoryBound: boolean;
  color: string;
}

export interface EdaStage {
  id: string;
  number: number;
  name: string;
  category: 'Frontend' | 'Physical Design' | 'Signoff';
  tool: string;
  status: 'SUCCESS' | 'RUNNING' | 'WARNING' | 'FAILED' | 'PENDING' | 'BLOCKED';
  runtimeSec: number;
  warningsCount: number;
  errorsCount: number;
  sourceHash: string;
  logLines: string[];
  artifacts: { filename: string; sizeKb: number; type: string }[];
}

export interface TapeoutGate {
  gateNumber: number;
  title: string;
  category: string;
  criteria: string;
  status: 'APPROVED' | 'IN_REVIEW' | 'BLOCKED' | 'NOT_STARTED';
  evidenceDoc: string;
  owner: string;
  lastUpdated: string;
  blockingIssues: string[];
}
