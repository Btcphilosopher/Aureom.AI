# SilicaFlux MemoryLab - run report

Generated 2026-11-05T22:13:40+00:00 by SilicaFlux MemoryLab 0.1.0; git f5aa0d9ba97f98d564a4cd82fde264129e56c02a (dirty=False); seed 1.

Result categories are reported separately and never merged.

## ANALYTICAL CEILING

| profile | workload | engine | rate_unit | peak | ceiling | binding | bound | unused_compute_fraction |
|---|---|---|---|---|---|---|---|---|
| silicaflux_v_release1_rtl | gemm_64x64x64_naive | tensor | MAC/s | 8e+08 | 6.77e+07 | tspm_fill | BANDWIDTH_BOUND | 0.915 |
| silicaflux_v_release1_rtl | gemm_64x64x64_blocked | tensor | MAC/s | 8e+08 | 3.48e+08 | tspm_fill | BANDWIDTH_BOUND | 0.565 |
| silicaflux_v_release1_rtl | gemm_64x64x64_double_buffered | tensor | MAC/s | 8e+08 | 3.05e+08 | tspm_fill | BANDWIDTH_BOUND | 0.619 |
| silicaflux_v_release1_rtl | gemm_64x64x64_dma_streaming | tensor | MAC/s | 8e+08 | 3.05e+08 | tspm_fill | BANDWIDTH_BOUND | 0.619 |
| silicaflux_v_release1_rtl | gemm_4x4x4_scratchpad_resident | tensor | MAC/s | 8e+08 | 2.54e+07 | tspm_fill | BANDWIDTH_BOUND | 0.968 |
| silicaflux_v_release1_rtl | conv2d_16x16x8_k3x3_c16 | tensor | MAC/s | 8e+08 | 4e+08 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v_release1_rtl | vector_add_n4096 | vector | OPS/s | 2e+08 | 3.17e+06 | tspm_fill | BANDWIDTH_BOUND | 0.984 |
| silicaflux_v_release1_rtl | axpy_n4096 | vector | OPS/s | 2e+08 | 6.35e+06 | tspm_fill | BANDWIDTH_BOUND | 0.968 |
| silicaflux_v_release1_rtl | dot_n4096 | vector | OPS/s | 2e+08 | 9.52e+06 | tspm_fill | BANDWIDTH_BOUND | 0.952 |
| silicaflux_v_release1_rtl | gemv_32x64 | vector | OPS/s | 2e+08 | 1.82e+07 | tspm_fill | BANDWIDTH_BOUND | 0.909 |
| silicaflux_v_release1_rtl | fir_n1024_t16 | vector | OPS/s | 2e+08 | 8e+07 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_v_release1_rtl | stencil3x3_32x32 | vector | OPS/s | 2e+08 | 8e+07 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_v_release1_rtl | cpu_seq_sum_2048w | cpu | OPS/s | 5e+07 | 2.5e+07 | cpu_ldst | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v_release1_rtl | cpu_random_512x_65536B | cpu | OPS/s | 5e+07 | 2.5e+07 | cpu_ldst | BANDWIDTH_BOUND | 0.501 |
| silicaflux_v_release1_rtl | fir_n512_t8 | cpu | MAC/s | 1.39e+06 | 1.39e+06 | compute | COMPUTE_BOUND | 0 |
| silicaflux_v | gemm_64x64x64_naive | tensor | MAC/s | 3.2e+09 | 1.6e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v | gemm_64x64x64_blocked | tensor | MAC/s | 3.2e+09 | 1.6e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v | gemm_64x64x64_double_buffered | tensor | MAC/s | 3.2e+09 | 1.6e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v | gemm_64x64x64_dma_streaming | tensor | MAC/s | 3.2e+09 | 1.6e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v | gemm_4x4x4_scratchpad_resident | tensor | MAC/s | 3.2e+09 | 9.48e+08 | tspm_fill | BANDWIDTH_BOUND | 0.704 |
| silicaflux_v | conv2d_16x16x8_k3x3_c16 | tensor | MAC/s | 3.2e+09 | 1.6e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v | vector_add_n4096 | vector | OPS/s | 8e+08 | 1.19e+08 | tspm_fill | BANDWIDTH_BOUND | 0.852 |
| silicaflux_v | axpy_n4096 | vector | OPS/s | 8e+08 | 2.37e+08 | tspm_fill | BANDWIDTH_BOUND | 0.704 |
| silicaflux_v | dot_n4096 | vector | OPS/s | 8e+08 | 3.56e+08 | tspm_fill | BANDWIDTH_BOUND | 0.556 |
| silicaflux_v | gemv_32x64 | vector | OPS/s | 8e+08 | 6.79e+08 | tspm_fill | BANDWIDTH_BOUND | 0.151 |
| silicaflux_v | fir_n1024_t16 | vector | OPS/s | 8e+08 | 3.2e+08 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_v | stencil3x3_32x32 | vector | OPS/s | 8e+08 | 3.2e+08 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_v | cpu_seq_sum_2048w | cpu | OPS/s | 2e+08 | 1e+08 | cpu_ldst | BANDWIDTH_BOUND | 0.5 |
| silicaflux_v | cpu_random_512x_65536B | cpu | OPS/s | 2e+08 | 9.98e+07 | cpu_ldst | BANDWIDTH_BOUND | 0.501 |
| silicaflux_v | fir_n512_t8 | cpu | MAC/s | 5.56e+06 | 5.56e+06 | compute | COMPUTE_BOUND | 0 |
| silicaflux_130nm_demo | gemm_64x64x64_naive | tensor | MAC/s | 8e+08 | 2.84e+08 | tspm_fill | BANDWIDTH_BOUND | 0.644 |
| silicaflux_130nm_demo | gemm_64x64x64_blocked | tensor | MAC/s | 8e+08 | 4e+08 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_130nm_demo | gemm_64x64x64_double_buffered | tensor | MAC/s | 8e+08 | 4e+08 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_130nm_demo | gemm_64x64x64_dma_streaming | tensor | MAC/s | 8e+08 | 4e+08 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_130nm_demo | gemm_4x4x4_scratchpad_resident | tensor | MAC/s | 8e+08 | 1.07e+08 | tspm_fill | BANDWIDTH_BOUND | 0.867 |
| silicaflux_130nm_demo | conv2d_16x16x8_k3x3_c16 | tensor | MAC/s | 8e+08 | 4e+08 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_130nm_demo | vector_add_n4096 | vector | OPS/s | 2e+08 | 1.33e+07 | tspm_fill | BANDWIDTH_BOUND | 0.933 |
| silicaflux_130nm_demo | axpy_n4096 | vector | OPS/s | 2e+08 | 2.67e+07 | tspm_fill | BANDWIDTH_BOUND | 0.867 |
| silicaflux_130nm_demo | dot_n4096 | vector | OPS/s | 2e+08 | 4e+07 | tspm_fill | BANDWIDTH_BOUND | 0.8 |
| silicaflux_130nm_demo | gemv_32x64 | vector | OPS/s | 2e+08 | 7.64e+07 | tspm_fill | BANDWIDTH_BOUND | 0.618 |
| silicaflux_130nm_demo | fir_n1024_t16 | vector | OPS/s | 2e+08 | 8e+07 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_130nm_demo | stencil3x3_32x32 | vector | OPS/s | 2e+08 | 8e+07 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_130nm_demo | cpu_seq_sum_2048w | cpu | OPS/s | 5e+07 | 2.5e+07 | cpu_ldst | BANDWIDTH_BOUND | 0.5 |
| silicaflux_130nm_demo | cpu_random_512x_65536B | cpu | OPS/s | 5e+07 | 2.5e+07 | cpu_ldst | BANDWIDTH_BOUND | 0.501 |
| silicaflux_130nm_demo | fir_n512_t8 | cpu | MAC/s | 1.39e+06 | 1.39e+06 | compute | COMPUTE_BOUND | 0 |
| silicaflux_65nm_demo | gemm_64x64x64_naive | tensor | MAC/s | 2.4e+09 | 8.53e+08 | tspm_fill | BANDWIDTH_BOUND | 0.644 |
| silicaflux_65nm_demo | gemm_64x64x64_blocked | tensor | MAC/s | 2.4e+09 | 1.2e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_65nm_demo | gemm_64x64x64_double_buffered | tensor | MAC/s | 2.4e+09 | 1.2e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_65nm_demo | gemm_64x64x64_dma_streaming | tensor | MAC/s | 2.4e+09 | 1.2e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_65nm_demo | gemm_4x4x4_scratchpad_resident | tensor | MAC/s | 2.4e+09 | 3.2e+08 | tspm_fill | BANDWIDTH_BOUND | 0.867 |
| silicaflux_65nm_demo | conv2d_16x16x8_k3x3_c16 | tensor | MAC/s | 2.4e+09 | 1.2e+09 | te_operand_port | BANDWIDTH_BOUND | 0.5 |
| silicaflux_65nm_demo | vector_add_n4096 | vector | OPS/s | 6e+08 | 4e+07 | tspm_fill | BANDWIDTH_BOUND | 0.933 |
| silicaflux_65nm_demo | axpy_n4096 | vector | OPS/s | 6e+08 | 8e+07 | tspm_fill | BANDWIDTH_BOUND | 0.867 |
| silicaflux_65nm_demo | dot_n4096 | vector | OPS/s | 6e+08 | 1.2e+08 | tspm_fill | BANDWIDTH_BOUND | 0.8 |
| silicaflux_65nm_demo | gemv_32x64 | vector | OPS/s | 6e+08 | 2.29e+08 | tspm_fill | BANDWIDTH_BOUND | 0.618 |
| silicaflux_65nm_demo | fir_n1024_t16 | vector | OPS/s | 6e+08 | 2.4e+08 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_65nm_demo | stencil3x3_32x32 | vector | OPS/s | 6e+08 | 2.4e+08 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_65nm_demo | cpu_seq_sum_2048w | cpu | OPS/s | 1.5e+08 | 7.5e+07 | cpu_ldst | BANDWIDTH_BOUND | 0.5 |
| silicaflux_65nm_demo | cpu_random_512x_65536B | cpu | OPS/s | 1.5e+08 | 7.49e+07 | cpu_ldst | BANDWIDTH_BOUND | 0.501 |
| silicaflux_65nm_demo | fir_n512_t8 | cpu | MAC/s | 4.17e+06 | 4.17e+06 | compute | COMPUTE_BOUND | 1.11e-16 |
| silicaflux_full | gemm_64x64x64_naive | tensor | MAC/s | 1.02e+11 | 2.02e+10 | tspm_fill | BANDWIDTH_BOUND | 0.802 |
| silicaflux_full | gemm_64x64x64_blocked | tensor | MAC/s | 1.02e+11 | 1.02e+11 | compute | COMPUTE_BOUND | 0 |
| silicaflux_full | gemm_64x64x64_double_buffered | tensor | MAC/s | 1.02e+11 | 1.02e+11 | compute | COMPUTE_BOUND | 0 |
| silicaflux_full | gemm_64x64x64_dma_streaming | tensor | MAC/s | 1.02e+11 | 1.02e+11 | compute | COMPUTE_BOUND | 0 |
| silicaflux_full | gemm_4x4x4_scratchpad_resident | tensor | MAC/s | 1.02e+11 | 1.6e+09 | te_operand_port_writeback | BANDWIDTH_BOUND | 0.984 |
| silicaflux_full | conv2d_16x16x8_k3x3_c16 | tensor | MAC/s | 1.02e+11 | 1.02e+11 | compute | COMPUTE_BOUND | 0 |
| silicaflux_full | vector_add_n4096 | vector | OPS/s | 3.2e+09 | 9.48e+08 | tspm_fill | BANDWIDTH_BOUND | 0.704 |
| silicaflux_full | axpy_n4096 | vector | OPS/s | 3.2e+09 | 1.28e+09 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_full | dot_n4096 | vector | OPS/s | 3.2e+09 | 2.84e+09 | tspm_fill | BANDWIDTH_BOUND | 0.111 |
| silicaflux_full | gemv_32x64 | vector | OPS/s | 3.2e+09 | 3.18e+09 | ve_operand_port | BANDWIDTH_BOUND | 0.00775 |
| silicaflux_full | fir_n1024_t16 | vector | OPS/s | 3.2e+09 | 1.28e+09 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_full | stencil3x3_32x32 | vector | OPS/s | 3.2e+09 | 1.28e+09 | ve_operand_port | BANDWIDTH_BOUND | 0.6 |
| silicaflux_full | cpu_seq_sum_2048w | cpu | OPS/s | 1.6e+09 | 8e+08 | cpu_ldst | BANDWIDTH_BOUND | 0.5 |
| silicaflux_full | cpu_random_512x_65536B | cpu | OPS/s | 1.6e+09 | 7.98e+08 | cpu_ldst | BANDWIDTH_BOUND | 0.501 |
| silicaflux_full | fir_n512_t8 | cpu | MAC/s | 4e+08 | 4e+08 | compute | COMPUTE_BOUND | 0 |

## EVENT-SIMULATED PERFORMANCE

| profile | workload | engine | achieved_ops_per_s | compute_utilisation | bound | busiest_resource | makespan_cycles |
|---|---|---|---|---|---|---|---|
| silicaflux_v_release1_rtl | gemm_64x64x64_naive | tensor | 5.75e+07 | 0.0718 | BANDWIDTH_BOUND | cpu_copy | 2.28e+05 |
| silicaflux_v_release1_rtl | gemm_64x64x64_blocked | tensor | 1.82e+08 | 0.227 | SERIALISATION_BOUND | cpu_copy | 7.22e+04 |
| silicaflux_v_release1_rtl | gemm_64x64x64_double_buffered | tensor | 2.63e+08 | 0.329 | BANDWIDTH_BOUND | cpu_copy | 4.98e+04 |
| silicaflux_v_release1_rtl | gemm_4x4x4_scratchpad_resident | tensor | 2.27e+07 | 0.0284 | BANDWIDTH_BOUND | cpu_copy | 141 |
| silicaflux_v_release1_rtl | conv2d_16x16x8_k3x3_c16 | tensor | 2.61e+08 | 0.326 | BANDWIDTH_BOUND | cpu_copy | 5.65e+04 |
| silicaflux_v_release1_rtl | vector_add_n4096 | vector | 3.03e+06 | 0.0151 | BANDWIDTH_BOUND | cpu_copy | 6.76e+04 |
| silicaflux_v_release1_rtl | axpy_n4096 | vector | 5.88e+06 | 0.0294 | BANDWIDTH_BOUND | cpu_copy | 6.97e+04 |
| silicaflux_v_release1_rtl | dot_n4096 | vector | 9.09e+06 | 0.0454 | BANDWIDTH_BOUND | cpu_copy | 4.51e+04 |
| silicaflux_v_release1_rtl | gemv_32x64 | vector | 1.65e+07 | 0.0825 | BANDWIDTH_BOUND | cpu_copy | 1.24e+04 |
| silicaflux_v_release1_rtl | fir_n1024_t16 | vector | 5.23e+07 | 0.261 | SERIALISATION_BOUND | cpu_copy | 3.13e+04 |
| silicaflux_v_release1_rtl | cpu_seq_sum_2048w | cpu | 1.25e+07 | 0.25 | LATENCY_BOUND | interconnect:sram | 8.19e+03 |
| silicaflux_v_release1_rtl | cpu_random_512x_65536B | cpu | 1e+07 | 0.2 | LATENCY_BOUND | interconnect:sram | 2.56e+03 |
| silicaflux_v_release1_rtl | dma_copy_8192B | dma | 0 |  | BANDWIDTH_BOUND | cpu_copy | 1.08e+04 |
| silicaflux_v | gemm_64x64x64_naive | tensor | 7.59e+08 | 0.237 | CONTENTION_BOUND | dma | 6.91e+04 |
| silicaflux_v | gemm_64x64x64_blocked | tensor | 1.37e+09 | 0.428 | COMPUTE_BOUND | dma | 3.83e+04 |
| silicaflux_v | gemm_64x64x64_double_buffered | tensor | 1.47e+09 | 0.46 | COMPUTE_BOUND | dma | 3.56e+04 |
| silicaflux_v | gemm_4x4x4_scratchpad_resident | tensor | 1.94e+08 | 0.0606 | OVERHEAD_BOUND | dma | 66 |
| silicaflux_v | conv2d_16x16x8_k3x3_c16 | tensor | 1.5e+09 | 0.468 | COMPUTE_BOUND | dma | 3.94e+04 |
| silicaflux_v | vector_add_n4096 | vector | 8.63e+07 | 0.108 | BANDWIDTH_BOUND | dma | 9.49e+03 |
| silicaflux_v | axpy_n4096 | vector | 1.41e+08 | 0.176 | BANDWIDTH_BOUND | dma | 1.16e+04 |
| silicaflux_v | dot_n4096 | vector | 2.64e+08 | 0.33 | BANDWIDTH_BOUND | dma | 6.21e+03 |
| silicaflux_v | gemv_32x64 | vector | 3.54e+08 | 0.442 | SERIALISATION_BOUND | dma | 2.32e+03 |
| silicaflux_v | fir_n1024_t16 | vector | 3.02e+08 | 0.377 | COMPUTE_BOUND | dma | 2.17e+04 |
| silicaflux_v | cpu_seq_sum_2048w | cpu | 5e+07 | 0.25 | LATENCY_BOUND | interconnect:sram | 8.19e+03 |
| silicaflux_v | cpu_random_512x_65536B | cpu | 4e+07 | 0.2 | LATENCY_BOUND | interconnect:sram | 2.56e+03 |
| silicaflux_v | dma_copy_8192B | dma | 0 |  | BANDWIDTH_BOUND | dma | 1.17e+03 |
| silicaflux_130nm_demo | gemm_64x64x64_naive | tensor | 1.61e+08 | 0.201 | CONTENTION_BOUND | dma | 8.14e+04 |
| silicaflux_130nm_demo | gemm_64x64x64_blocked | tensor | 3.14e+08 | 0.392 | SERIALISATION_BOUND | dma | 4.18e+04 |
| silicaflux_130nm_demo | gemm_64x64x64_double_buffered | tensor | 3.58e+08 | 0.447 | COMPUTE_BOUND | dma | 3.66e+04 |
| silicaflux_130nm_demo | gemm_4x4x4_scratchpad_resident | tensor | 4.1e+07 | 0.0513 | OVERHEAD_BOUND | dma | 78 |
| silicaflux_130nm_demo | conv2d_16x16x8_k3x3_c16 | tensor | 3.68e+08 | 0.46 | COMPUTE_BOUND | dma | 4.01e+04 |
| silicaflux_130nm_demo | vector_add_n4096 | vector | 1.31e+07 | 0.0657 | BANDWIDTH_BOUND | dma | 1.56e+04 |
| silicaflux_130nm_demo | axpy_n4096 | vector | 2.32e+07 | 0.116 | BANDWIDTH_BOUND | dma | 1.77e+04 |
| silicaflux_130nm_demo | dot_n4096 | vector | 3.97e+07 | 0.199 | BANDWIDTH_BOUND | dma | 1.03e+04 |
| silicaflux_130nm_demo | gemv_32x64 | vector | 6.1e+07 | 0.305 | CONTENTION_BOUND | dma | 3.36e+03 |
| silicaflux_130nm_demo | fir_n1024_t16 | vector | 7.2e+07 | 0.36 | COMPUTE_BOUND | dma | 2.27e+04 |
| silicaflux_130nm_demo | cpu_seq_sum_2048w | cpu | 1.25e+07 | 0.25 | LATENCY_BOUND | interconnect:sram | 8.19e+03 |
| silicaflux_130nm_demo | cpu_random_512x_65536B | cpu | 1e+07 | 0.2 | LATENCY_BOUND | interconnect:sram | 2.56e+03 |
| silicaflux_130nm_demo | dma_copy_8192B | dma | 0 |  | BANDWIDTH_BOUND | dma | 2.57e+03 |
| silicaflux_65nm_demo | gemm_64x64x64_naive | tensor | 4.83e+08 | 0.201 | CONTENTION_BOUND | dma | 8.14e+04 |
| silicaflux_65nm_demo | gemm_64x64x64_blocked | tensor | 9.41e+08 | 0.392 | SERIALISATION_BOUND | dma | 4.18e+04 |
| silicaflux_65nm_demo | gemm_64x64x64_double_buffered | tensor | 1.07e+09 | 0.447 | COMPUTE_BOUND | dma | 3.66e+04 |
| silicaflux_65nm_demo | gemm_4x4x4_scratchpad_resident | tensor | 1.23e+08 | 0.0513 | OVERHEAD_BOUND | dma | 78 |
| silicaflux_65nm_demo | conv2d_16x16x8_k3x3_c16 | tensor | 1.1e+09 | 0.46 | COMPUTE_BOUND | dma | 4.01e+04 |
| silicaflux_65nm_demo | vector_add_n4096 | vector | 3.94e+07 | 0.0657 | BANDWIDTH_BOUND | dma | 1.56e+04 |
| silicaflux_65nm_demo | axpy_n4096 | vector | 6.95e+07 | 0.116 | BANDWIDTH_BOUND | dma | 1.77e+04 |
| silicaflux_65nm_demo | dot_n4096 | vector | 1.19e+08 | 0.199 | BANDWIDTH_BOUND | dma | 1.03e+04 |
| silicaflux_65nm_demo | gemv_32x64 | vector | 1.83e+08 | 0.305 | CONTENTION_BOUND | dma | 3.36e+03 |
| silicaflux_65nm_demo | fir_n1024_t16 | vector | 2.16e+08 | 0.36 | COMPUTE_BOUND | dma | 2.27e+04 |
| silicaflux_65nm_demo | cpu_seq_sum_2048w | cpu | 3.75e+07 | 0.25 | LATENCY_BOUND | interconnect:sram | 8.19e+03 |
| silicaflux_65nm_demo | cpu_random_512x_65536B | cpu | 3e+07 | 0.2 | LATENCY_BOUND | interconnect:sram | 2.56e+03 |
| silicaflux_65nm_demo | dma_copy_8192B | dma | 0 |  | BANDWIDTH_BOUND | dma | 2.57e+03 |
| silicaflux_full | gemm_64x64x64_naive | tensor | 2.23e+10 | 0.218 | SERIALISATION_BOUND | dma | 4.7e+03 |
| silicaflux_full | gemm_64x64x64_blocked | tensor | 3.88e+10 | 0.378 | SERIALISATION_BOUND | dma | 2.71e+03 |
| silicaflux_full | gemm_64x64x64_double_buffered | tensor | 3.88e+10 | 0.378 | OVERHEAD_BOUND | dma | 2.71e+03 |
| silicaflux_full | gemm_4x4x4_scratchpad_resident | tensor | 2.21e+08 | 0.00216 | SERIALISATION_BOUND | dma | 116 |
| silicaflux_full | conv2d_16x16x8_k3x3_c16 | tensor | 3.7e+10 | 0.361 | OVERHEAD_BOUND | dma | 3.19e+03 |
| silicaflux_full | vector_add_n4096 | vector | 5.19e+08 | 0.162 | SERIALISATION_BOUND | dma | 3.16e+03 |
| silicaflux_full | axpy_n4096 | vector | 7.84e+08 | 0.245 | SERIALISATION_BOUND | dma | 4.18e+03 |
| silicaflux_full | dot_n4096 | vector | 1.55e+09 | 0.483 | SERIALISATION_BOUND | dma | 2.12e+03 |
| silicaflux_full | gemv_32x64 | vector | 1.72e+09 | 0.539 | SERIALISATION_BOUND | dma | 950 |
| silicaflux_full | fir_n1024_t16 | vector | 1.23e+09 | 0.385 | COMPUTE_BOUND | dma | 1.06e+04 |
| silicaflux_full | cpu_seq_sum_2048w | cpu | 2e+08 | 0.125 | COMPUTE_BOUND | interconnect:sram | 4.1e+03 |
| silicaflux_full | cpu_random_512x_65536B | cpu | 5.5e+07 | 0.0344 | LATENCY_BOUND | interconnect:dram | 3.72e+03 |
| silicaflux_full | dma_copy_8192B | dma | 0 |  | BANDWIDTH_BOUND | dma | 301 |

## RTL-OBSERVED PERFORMANCE

* **bank_equivalence**: 15/15 equivalent
* **tile_latency**: 54/54 exact
* **dma_calibration**: mean rel err 9.3% -> 9.1%
* **sramlib_bench**: avg_latency mean rel err 0.0%; conflict_rate mean rel err 4.9%; words_per_cycle mean rel err 1.6%

## SILICON-MEASURED PERFORMANCE

None. No silicon exists.

## Known limitations

* Analytical results are upper bounds (Roofline ceilings), not predictions of achieved performance.
* The system simulator is transaction-level and approximately timed; only the SRAM bank controller model is cycle-level and validated against RTL (Verilator + Icarus) for the configurations listed in rtl/.
* The DRAM model is a timing abstraction, not JEDEC-accurate; the cache model has no coherence protocol.
* Area coefficients per MAC/lane/bank/bus bit are hypothetical (repository synthesis is flattened); SRAM area is macro-only (IHP SG13G2 datasheet), a lower bound.
* No power model is calibrated: energy is not reported.
* No silicon exists: SILICON_MEASURED is empty by construction.
* The provisional SilicaFlux-V profile (256 KiB, 200 MHz, 64-bit bus, DMA) is not the RTL release (128 KiB, 50 MHz, 32-bit SFB crossbar, no DMA).

## Missing inputs

* silicon measurements (none exist)
* calibrated power model
* per-block synthesis area
* 65 nm / commercial SRAM macro data
* SilicaFlux-V DMA RTL (not implemented)
