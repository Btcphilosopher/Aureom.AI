# Exact commands executed and actual results

Environment: Linux 6.18 x86_64 container; Python 3.12.3 venv (`numpy 2.5.4, scipy 1.18.1, pandas 3.1.1,
matplotlib 3.11.2, plotly 7.1.0, pydantic 2.14.3, PyYAML 6.0.3, pytest 9.2.0, hypothesis 6.170.14`);
Verilator 5.020 (Debian 5.020-1); Icarus Verilog 12.0. Repository `btcphilosopher/Aureom.AI` @ `f5aa0d9`.
In the commands below, `$P` is the package root and `$REPO` is the Aureom.AI checkout.

## Setup

```bash
python3.12 -m venv venv312 && . venv312/bin/activate
pip install numpy scipy pandas matplotlib plotly pydantic pyyaml pytest hypothesis
apt-get install -y iverilog verilator
```

## Repository inspection (read-only)

```bash
unzip -q <each SilicaFlux-main/**/*.zip> -d <scratch>/audit/<name>     # 32 archives + soc_integration.tar.gz
grep -c '^\s*module\b' / 'endmodule' / 'always_ff' / '\blogic\b' on all 33 loose .sf files
```

## RTL evidence

```bash
# sfv_tile engine latency (unmodified SilicaFlux-V RTL)
verilator --binary --timing --timescale 1ns/1ps -Wno-fatal -Wno-DECLFILENAME -Wno-MULTITOP -Wno-UNUSEDSIGNAL \
  -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -DSFV_NO_CLOCK_GATE rtl/pkg/sfv_pkg.sv rtl/common/sfv_common.sv \
  rtl/common/sfv_clkgate.sv rtl/mem/sfv_sram_sp.sv rtl/accel/sfv_vec_engine.sv rtl/accel/sfv_tensor_engine.sv \
  rtl/accel/sfv_tile.sv $P/rtl_harness/tb_memorylab_tile_latency.sv --top-module tb_memorylab_tile_latency \
  --Mdir obj -o Vtile && ./obj/Vtile
# sramlib bank controller: the exact command for every case is stored in
# reports/memorylab/example_run/rtl/bank_controller_equivalence.csv (rtl_command column), e.g.
verilator --binary --timing --timescale 1ns/1ps --assert -DSRAMLIB_ASSERT -DSRAMLIB_POISON --x-assign unique \
  --x-initial unique ... <sramlib rtl/mem sources> rtl_harness/tb_memorylab_bank_trace.sv \
  --top-module tb_memorylab_bank_trace -GNM=4 -GNB=4 -GDW=32 -GMW=4 -GBD=256 -GLAT=1 -GARB=0 -GILV=0 -GFIFO=2 -GWACK=1 \
  -GMAXN=512 && Vtb_memorylab_bank_trace +stim=<file> +log=<file> +bp=30 +bpseed=1002
iverilog -g2012 -DSRAMLIB_POISON -I... -s tb_memorylab_bank_trace -P... <sources> && vvp -n <vvp> +stim=... [+vcd=...]
```

## Test suite

```bash
cd $P && SILICAFLUX_REPO=$REPO make memorylab-test PY=python
#   -> PYTHONPATH=python python -m pytest -q tests/memorylab
```

Result (final run, with Verilator and Icarus present and the repository archives available):

| File | Passed |
|---|---|
| test_cli.py | 4 |
| test_compute.py | 106 |
| test_event_engine.py | 9 |
| test_interconnect_dma.py | 18 |
| test_machine.py | 59 |
| test_optimisation.py | 9 |
| test_roofline.py | 24 |
| test_rtl_equivalence.py | 7 (runs Verilator and Icarus) |
| test_simulation.py | 48 |
| test_sram.py | 24 |
| test_trace_import.py | 6 |
| test_workloads.py | 16 |
| **total** | **330 passed, 0 skipped, 0 failed** (about 63 s, including the RTL builds) |

Without Verilator, Icarus or the repository archives, `test_rtl_equivalence.py` skips (7 tests) and the other 323
run unchanged.

### Failures found during development (and fixed)

These came from the tests and cross-checks themselves. Each became a regression test or an invariant.

1. **Tensor writeback charged to the operand-read port.** The analytical ceiling came out *below* the engine model
   (1422 vs 1517 MMAC/s). Fix: writeback is a separate interface level. Invariant test: the engine-side ceiling is ≥
   the engine model for every profile and workload.
2. **Naive GEMM defined inconsistently between the layers.** The event simulation beat its own analytical ceiling
   (44 vs 17 MMAC/s). Fix: "naive" means no reuse beyond the array's own operand registers. Invariant test: simulated
   ≤ analytical ceiling (4 profiles × 9 workloads).
3. **Posted writes (`WRITE_ACK=0`) produced a response in the bank model**, unlike the RTL. Fixed and covered by RTL
   equivalence case 10.
4. **Interconnect timing was one cycle pessimistic** compared with the documented SilicaFlux-V 2-cycle load. Fix:
   cut-through channels.
5. **Remainder tiles were charged full-tile compute** (found through an anomalous TSPM-size trend). Fixed, with a
   regression test.
6. **DMA serialised large bursts** (wrong trend against memoryflow's RTL: 72% error). Fix: decoupled read/write
   streams and an issue interval; error now 9.1%.
7. **Cross-port arbitration deadlock** (caught by the deadlock detector). Fixed, with a regression test.
8. **YAML `200.0e6` read as a string** by PyYAML. Fix: numeric coercion.

## Example run (all outputs in `reports/memorylab/example_run/`)

```bash
cd $P && SILICAFLUX_REPO=$REPO make memorylab-all PY=python
#   -> PYTHONPATH=python python -m memorylab all --out reports/memorylab/example_run
```

See `final_analysis.md` for the numbers. `provenance.json` records the git revision, versions, configuration hashes,
seed, limitations and missing inputs.
