# SilicaFlux MemoryLab — repository audit

Repository: `btcphilosopher/Aureom.AI`, revision `f5aa0d9ba97f98d564a4cd82fde264129e56c02a` (2026-11-05),
branch `claude/affectionate-mendel-3rykie`. The SilicaFlux material is in `SilicaFlux-main/`. Most RTL lives
inside zip and tar archives, which were extracted read-only into a scratch directory; **no repository file was
modified**. Archive members are cited below as `archive.zip:member`.

> **Git branch.** The brief asks for a feature branch `feature/silicaflux-memorylab`. The user instructed
> *"produce as a zip, do not commit to github"*, so no branch, commit or push was made. To integrate later, unzip into
> `SilicaFlux-main/silicaflux-memorylab/` and branch from there (see `integration.md`).

## 1. What `.sf` is

`.sf` files are **plain SystemVerilog (IEEE 1800-2017) with a renamed extension**. They need no translation;
tools only have to be told to treat `.sf` as SystemVerilog.

Evidence, checked in this audit:

* 33 loose `.sf` files: 14 in `SilicaFlux-main/` and 19 in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`.
  29 contain `module … endmodule` and 4 contain only a `package`. All of them use `logic`, and the RTL files use
  `always_ff`.
* Every header says `Language : Silica Flux-2017`. No SilicaFlux compiler, preprocessor or translator exists anywhere
  in the repository.
* Earlier projects reached the same conclusion independently. `silicaflux-timinglab` (docs/DISCOVERY.md) found 45 of
  48 `.sf` files parse with slang with zero syntax errors. `silicaflux-sramlib` (docs/mem/00_repository_evidence.md)
  parsed them with Verilator using `+1800-2017ext+sf`.
* One exception: `SilicaFluxML.zip:dsl/silicaflux_ml.sf` describes itself as a non-parseable DSL sketch. It is not
  RTL.

`.sfx` files are assembly for the SilicaFlux v1 custom ISA (`SilicaFlux2.5/sfx_asm.py`).

## 2. Components found (real modules and paths)

`R1` = `SilicaFlux-main/silicaflux-v-release1.zip:silicaflux-v/` (the SilicaFlux-V reduced-ASIC RTL release).
`SL` = `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip:silicaflux-sramlib/` (Project 01).
`MF` = `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memoryflow-v2.0.0.zip:silicaflux-memoryflow/`.

| Area | SilicaFlux-V (R1) | Other SilicaFlux RTL in the repository |
|---|---|---|
| CPU | `rtl/cpu/sfv_cpu.sv`: RV32I_Zicsr, 2-stage in-order, M-mode. CPI 1 (ALU), 2 (load/store, zero wait), 3 (taken branch). **No M extension**: firmware calls `__mulsi3` (docs/ARCHITECTURE.md §2). | `SilicaFlux2.5/silicaflux_top.sf`: 2 complexes × 4 cores, but it references undefined types (`sf_axi_req_t`). Also `cpu_core.zip`, `pipelined_cpu.zip`, `RISC-V CPU.zip`, and `soc_integration.tar.gz` (SSB bus, 50 MHz, 128 KB SRAM). |
| Vector | `rtl/accel/sfv_vec_engine.sv`: 4 lanes × 32 bit, memory-to-memory on the TSPM. `CYCLES = 3 + ⌈LEN/4⌉·P (+1 DOT WRES)`. | `SilicaFlux2.5/vector_engine.sf`: LANES=4, EX_STAGES 1/2, 1 uop/cycle. `vector_engine (1).sf`: LANES=8. MF `sf_vec_unit`. |
| Tensor | `rtl/accel/sfv_tensor_engine.sv`: 4×4 INT8/UINT8 output-stationary array with 32-bit accumulators. `CYCLES = 3 + 2K (+4 WB)`. **It sustains 8 of 16 MAC/cycle**, because A and B words are read sequentially from single-port banks (header lines 25–30). | `SilicaFlux-main/tensor_unit.sf`: DIM=4, one 4×4×4 product per cycle, 21-cycle latency. MF `sf_tensor_array` (8×8). `silicafluxai.zip`: `sfx_systolic_array` (16×16, weight-stationary). |
| SRAM wrapper | `rtl/mem/sfv_sram_sp.sv`: 1RW, 32 bit, byte enables, 1-cycle read. Banks are SFB slaves (`rtl/mem/sfv_mem_slaves.sv`). | **SL** (Project 01): `rtl/mem/sram_sp.sv`, `sram_1r1w.sv`, `sram_tdp.sv`, `sram_bank_controller.sv`, `sram_rsp_path.sv`, presets, and 34 open-PDK macro manifests (SKY130, GF180MCU, IHP SG13G2). MF `sf_sram_bank` (2-cycle). |
| Memories | SRAM 4 × 32 KiB = 128 KiB (`rtl/top/sfv_soc.sv:20-21`); TSPM 16 KiB in 4 word-interleaved banks (`:22`, `rtl/accel/sfv_tile.sv:6`); boot ROM 4 KiB. | SF 2.5 `memory_controller.sf:98`: 8 banks × 512 × 128 b = 64 KiB, 32-bit scalar + 128-bit vector + burst ports. |
| Cache | **none** | `memory_cache_repo.zip`: `set_assoc_cache.sv` (32 KiB, 64 B lines, 4-way PLRU, write-back, blocking) and `direct_mapped_cache.sv`. |
| DMA | **none** (no DMA RTL in R1; the TSPM is filled by CPU load/store) | MF `rtl/dma/sf_dma.sv:50`: 2 channels, 64 bit, NSO 4, DFIFO 16, DESC 4, WOUT 8, burst ≤ 16 beats. `silicafluxai` `rtl/dma/sfx_dma.sv`: single channel, 32 bit. |
| Interconnect | `rtl/bus/sfv_xbar.sv`: 3 masters × 7 slaves SFB crossbar, 32 bit, fixed priority, **1 outstanding per master and per slave**, response ≥ 1 cycle after grant. | SF 2.5 `noc_interconnect.sf`: 2×2 XY mesh, 2 cycles/hop (packet type undefined). `comm_protocols.zip`: AXI-Lite, SPI, I2C, UART. MF `sf_mem_router`. |
| Clock / reset | Single functional clock with a 20 ns SDC target (50 MHz) and an asynchronous TCK (docs/CLOCK_RESET.md). IHP SG13G2 Fmax estimate 74.5 MHz; SKY130 37.4 MHz (`reports/synth/*/summary.md`: post-placement estimates, ideal clocks, not signoff). | timinglab `docs/RESULTS.md`: per-module Fmax* (e.g. SF 2.x `tensor_unit` 281 MHz IHP, `vector_engine_pipe` 134 MHz IHP). |
| Firmware / workloads | `firmware/app/app.c`, `firmware/common/sfv_accel.c` (C reference models), POST vectors, `tb/models/sfv_golden.py` (bit-exact golden + latency formulas). | `.sfx` programs: `fibonacci`, `dot_product_parallel`, `matmul_4x4`. |
| Python models | `tb/models/sfv_golden.py` | **MF** `memoryflow/models/`: analytical Roofline, Little's-law DMA, cycle-level SPM banking, cache, tiling, DSE. `silicafluxai` GEMM estimator. `SilicaFluxML` fabric. |
| Existing performance models | — | MF (closest; it targets the memoryflow SPM/DMA/8×8-tensor subsystem, not SilicaFlux-V's TSPM/xbar). `silicaflux-twinlab.zip` (Angular app, **hard-coded demo data**, no import path; its Roofline adds CPU+vector+tensor peaks across op kinds and scales bandwidth ×1.8, see §5). |

## 3. SRAM Wrapper Library (Project 01) integration

The library exists and is implemented (SL). MemoryLab integrates it as follows:

* **Configuration adapter**: `memorylab.rtl_integration.sramlib_profile()` reads the real module list, the
  `sram_bank_controller` defaults and the documented semantics (interface spec §4–§7). Rules carried over from the
  library: per-bank round robin with pointer ← granted+1, acceptance == issue, `RSP_FIFO_DEPTH` credits from
  registered state, in-order ID responses, `WRITE_ACK` posting, error responses for out-of-range and misaligned
  requests, and power-of-two banks.
* **Cycle-level model**: `memorylab.sram.BankController` mirrors `sram_bank_controller.sv` + `sram_rsp_path.sv`.
* **Trace harness**: `rtl_harness/tb_memorylab_bank_trace.sv` drives the unmodified controller from a stimulus file
  that the Python model also executes.
* **Result**: transaction-by-transaction equivalence (acceptance cycle, conflict stalls, response cycle/order/ID/flags,
  read data on known bits) for 11 configurations under Verilator 5.020 and 4 under Icarus 12. See
  `reports/memorylab/example_run/rtl/`. Equivalence is claimed **only for these configurations**.

## 4. Parameter classification (the four classes required by the brief)

Each parameter in every profile YAML carries `provenance` and `source`. `memorylab audit-params --config <yaml>`
prints the full table. Summary:

| Class | Parameters (examples) | Source |
|---|---|---|
| **1. Verified from the repository** | CPU: 1 core, RV32, CPI 1/2/3, no HW multiply, 1 outstanding. VE: 4 × 32 bit, P = 3/2/2/1, overhead 3, LEN=0 → 2, WRES +1. TE: 4×4, 1 MAC/PE/k-step, operand fetch 4 B/cycle, writeback 16 B/cycle, overhead 3, K ≤ 1024. TSPM 16 KiB / 4 banks / 1-cycle. SRAM 128 KiB / 4 banks / 1-cycle. SFB 32 bit, fixed priority, 1 outstanding. Clock target 50 MHz. SRAM macro area 0.4916 mm² per 16 KiB (IHP `RM_IHPSG13_1P_2048x64`). Whole-SoC std-cell area 0.6838 mm² (IHP). | R1 RTL headers, docs, `rtl/top/sfv_soc.sv`, `asic/constraints/sfv_soc.sdc`, `reports/synth/ihp_sg13g2/summary.md`; SL manifests |
| **2. Extracted from actual RTL simulations** | (a) Run in this session: VE/TE `CYCLES` for 54 commands on `sfv_tile` (Verilator, all equal to the model); bank-controller traces (17,600+ requests, Verilator and Icarus). (b) Results of earlier RTL runs held in the repository: SL `reports/mem/analysis.json` (48 Verilator benchmark rows) and MF `reports/calibration_dma.csv` (sf_dma cycle counts). DMA parameters calibrated to (b) are stored as `RTL_SIMULATED` in `calibrated/`. | `rtl/`, `calibrated/` in the run directory |
| **3. External engineering measurements** | **None supplied.** Synthesis and STA reports in the repository are tool estimates (pre-signoff), recorded as VERIFIED_REPO implementation estimates, not as measurements. | — |
| **4. Hypothetical design assumptions** | 200 MHz (brief; R1 targets 50 MHz at 130 nm), 256 KiB SRAM (R1: 128 KiB), 64-bit bus (R1: 32 bit), the DMA (R1 has none), word interleave of the provisional SRAM, `mul_sw` = 35 cycles, every per-MAC/lane/bank/bus-bit area coefficient, every 65 nm and "full" profile throughput value, and the DRAM timing. | profile YAML `source` fields |

## 5. Discrepancies between the brief, the documentation and the code

1. **SRAM**: the brief says 256 KiB; the RTL has 128 KiB in 4 banks plus a 16 KiB TSPM.
2. **Clock**: the brief says 200 MHz. The RTL targets 50 MHz at 130 nm; IHP is estimated at 74.5 MHz and SKY130 at
   37.4 MHz. The 200 MHz figure comes from a documented 65 nm target (MF `explore.py` budget `silicaflux-v-65`, which
   cites the reduced-ASIC PDF) and from R1 `PROCESS_NODE_COMPARISON.md` ("[E] 150–200 MHz" estimate). No 65 nm
   implementation exists.
3. **DMA**: the brief assumes one channel; SilicaFlux-V has none.
4. **Bus**: the brief offers 32/64/128 bit; the RTL is 32-bit SFB with one outstanding transaction per master.
5. **Tensor throughput**: the "4×4 MAC array" peaks at 16 MAC/cycle but sustains 8, because of sequential operand
   fetch (documented in the RTL and measured here).
6. **Vector precision**: the vector lanes are int32 only. INT8/INT16 data must be widened, and MemoryLab refuses an
   INT16 workload on the INT32 vector engine rather than converting silently.
7. **Documentation without implementation**:
   * MF `tb/common/sf_extmem_model.sv` refers to `memoryflow.models.extmem`, which does not exist.
   * MF's recommended `WOUT=32` is not applied in `sf_memflow_top.sv:126`.
   * SF 2.x `noc_packet_t` and `sf_axi_req_t` are never defined.
   * SF 2.5 `compute_tile.sf` does not elaborate (timinglab FINDINGS F2).
   * The SilicaFlux README's `rtl/*.sv` list exists only inside `silicaflux.zip`.
   * TwinLab's configuration (125 MHz, 4 × 64 KB SRAM, 128-bit bus) is demonstration data, not RTL.
   * TwinLab's Roofline sums peaks of different engines and op kinds, which MemoryLab's unit system forbids.
8. **No HBM or external DRAM** exists in any SilicaFlux-V RTL; external memory appears only in the "full"
   hypothetical profile.

## 6. What MemoryLab adds, and how it relates to memoryflow

memoryflow models its own SPM/DMA/8×8-tensor subsystem analytically, with some cycle-level submodels. MemoryLab adds
the following:

* Unit-checked hierarchical Rooflines per engine for SilicaFlux-V and the other profiles.
* A general discrete-event simulator (DMA, crossbar/bus, SRAM arrays, DRAM, cache, compute clients).
* An RTL-validated model of Project 01's bank controller.
* RTL-measured SilicaFlux-V engine latencies.
* Provenance on every parameter and every result.

memoryflow's RTL calibration data is reused as calibration evidence, not duplicated.

## 7. Tools found and used

* Python 3.12.3 venv (the system default 3.13 was not used).
* Verilator 5.020 and Icarus Verilog 12.0 (installed from Ubuntu packages in this session).
* Not available: Yosys, OpenROAD, OpenSTA and cocotb. The integrations take their **report files** as inputs (synthesis
  area and STA figures are already in the repository), so these tools are not required.
