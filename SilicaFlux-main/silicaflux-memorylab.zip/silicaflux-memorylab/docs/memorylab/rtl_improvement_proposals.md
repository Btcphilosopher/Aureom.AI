# Proposed improvements to SilicaFlux RTL

Ranked by the performance gained per unit of added silicon and engineering risk. The evidence comes from the
delivered example run (`reports/memorylab/example_run/`). Every gain quoted is **EVENT_SIMULATED or
ANALYTICAL_CEILING on model configurations**. None is a silicon measurement, and none has been implemented in RTL.

## Before first silicon (SilicaFlux-V)

### P1 — Tensor engine: fetch A and B in the same cycle (`rtl/accel/sfv_tensor_engine.sv`)

* **Finding.** The 4×4 array peaks at 16 MAC/cycle but sustains 8. Each k-step reads the A-column word and the B-row
  word one after the other from single-port TSPM banks (header lines 25–30; measured `CYCLES = 3 + 2K` on the RTL,
  `rtl/sfv_tile_latency.csv`).
* **Change.** Issue both reads in one cycle and constrain the layout so that `bank(A_ADDR + k·A_STRIDE)` ≠
  `bank(B_ADDR + k·B_STRIDE)` (for example B offset by one word), or add a 2-entry operand prefetch FIFO. The banks
  are already separate and independently addressed (`sfv_tile.sv` arbitrates per bank), so no SRAM macro changes.
* **Gain.** ×1.85 GEMM 64³ (double-buffered), ×1.75 blocked, ×1.88 conv2d (`sweeps/architecture_sweep.csv`,
  `tensor_operand_ports`). The analytical operand-port ceiling rises from 8 to 16 MAC/cycle.
* **Cost.** About a second read-address path and one 32-bit operand register (hypothetical; synthesis is flattened).
  The RTL already lists this as a next-revision item.

### P2 — Add a DMA engine (new `rtl/dma/`, crossbar master)

* **Finding.** The RTL release has no DMA. The TSPM is filled by the CPU load/store loop at about 0.76 B/cycle
  (38 MB/s at 50 MHz). That is the binding roof for every streaming kernel and for tiled GEMM
  (`analytical/silicaflux_v_release1_rtl.json`).
* **Change.** One channel, 16–64 B bursts, at least 2 outstanding reads (the crossbar must allow more than one
  outstanding transaction for this master), and a descriptor queue. memoryflow's `sf_dma` is a candidate starting
  point (already in the repository; its timing is calibrated here to a 9.1% mean error).
* **Gain at the same 50 MHz / 32-bit bus.** ×4.3–4.4 for streaming vector kernels, ×1.36 for double-buffered GEMM,
  ×1.73 for blocked GEMM, ×1.41 for conv2d (`studies/what_if_studies.csv`, `dma_vs_cpu_copy_50MHz`). It also frees
  the CPU from data movement.
* **Diminishing returns.** Two outstanding bursts already saturate the bus: from 2 to 16 outstanding gains less than
  5% (`architecture_sweep`, `dma_outstanding`).

### P3 — TSPM ping-pong halves, so the fabric is not starved by an engine that has priority (`rtl/accel/sfv_tile.sv`)

* **Finding.** The engine holding the TSPM lock has fixed priority on every bank. The vector engine accesses a whole
  row (all 4 banks) every cycle, so DMA writes into the TSPM stall for the entire duration of a vector command, and
  double buffering cannot overlap.
* **Change.** Split the TSPM into two halves with separate engine and fabric ownership (engine on half A while DMA
  fills half B), or give the fabric a guaranteed slot.
* **Gain.** ×1.43 vector_add, ×1.30 dot, ×1.02 FIR, ×1.00 GEMM (`studies/what_if_studies.csv`, `tspm_ping_pong`).
  The TE uses only 25% of bank cycles, so it is unaffected.
* **Cost.** Bank-select logic and lock arbitration per half. No SRAM is added.

### P4 — Interconnect: 64-bit fabric to the TSPM and DMA, once P2 exists (`rtl/bus/sfv_xbar.sv`)

* **Gain.** Going from 32 to 64 bits gives ×1.66 on streaming kernels, and 64 to 128 bits gives ×1.49 at 200 MHz.
  Beyond 128 bits there is no gain, because the DMA becomes the limit (`bus_bits`). GEMM gains under 10%: it is
  compute-bound inside the TE.
* **Condition.** A bus wider than one bank needs word-interleaved SRAM banks. With high-order interleave (the RTL's
  one-slave-per-bank arrangement) a sequential burst hits a single 32-bit bank, which caps it at 4 B/cycle. The event
  simulator shows this; the conflict-free analytical bound does not.

### Keep as is for first silicon

* **SRAM capacity: keep 128 KiB.** Without external memory, SRAM size is a feasibility limit, not a throughput knob.
  None of the evaluated workloads gains from 256 KiB (`sram_kib` flat), and the extra 128 KiB costs ≈ 3.9 mm² of IHP
  macro area (0.0307 mm²/KiB, macro only).
* **SRAM banks: 4 are sufficient.** Above 2 word-interleaved banks a 64-bit bus gains nothing (`sram_banks`). With
  the 32-bit bus, the current 4 independent slaves are adequate.
* **Vector lanes: keep 4.** Streaming kernels are bound by data movement. Going to 8 lanes gains 20% only when the
  provisional 200 MHz DMA and 64-bit bus are present; on the RTL release it gains nothing (the CPU-copy roof binds).
* **CPU: one RV32I core.** A software multiply (`__mulsi3`) makes scalar MAC loops about 36× slower than ALU ops.
  This is acceptable, because MACs belong on the accelerators.

## Deferred to the full SilicaFlux processor

* **Larger tensor arrays** (8×8 → 16×16). These scale strongly only if operand bandwidth scales with the array: going
  from d=4 to 8 gives ×3.6, then 8 to 16 gives only ×1.5 more, as data movement takes over. They need 32 B/cycle of
  operand delivery (2 ports × 16 B) and K-split accumulator preload.
* **External DRAM/HBM with SRAM ≥ 64–128 KiB.** In the DRAM-backed profile, GEMM's DRAM-interface intensity passes
  the DRAM ridge (≈ 9 MAC/B) at 64–128 KiB of SRAM. Beyond that, SRAM capacity no longer pays and the scratchpad-fill
  interface binds (`analytical/sram_capacity_study.csv`).
* **Vector FMA (one AXPY command).** It cuts AXPY port traffic from 5 to 3 element streams. It only helps when the VE
  port binds, which is not the case on SilicaFlux-V.
* **Multi-core control, caches (with a coherence protocol), multiple DMA channels, NoC.**
