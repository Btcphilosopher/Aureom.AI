# Final analysis — SilicaFlux MemoryLab example run

Every number below comes from `reports/memorylab/example_run/`, which `make memorylab-all` produced with the delivered
code. Provenance: git `f5aa0d9` (clean), seed 1, Python 3.12.3, Verilator 5.020, Icarus 12. Result categories are kept
apart:

* **[A]** ANALYTICAL_CEILING: an upper bound.
* **[S]** EVENT_SIMULATED: the transaction-level model.
* **[R]** RTL_OBSERVED: Verilator/Icarus runs of the repository RTL.
* **SILICON_MEASURED: none.** No silicon exists.

Profiles:

* **RTL release** (`silicaflux_v_release1_rtl`): what the RTL implements. 50 MHz, 128 KiB SRAM, 16 KiB TSPM, 32-bit
  crossbar, **no DMA**.
* **130 nm demo**: the RTL release plus a proposed DMA, at the same 50 MHz.
* **Provisional** (`silicaflux_v`): the brief's profile. 200 MHz, 256 KiB, 64-bit bus, DMA. **These values are
  hypothetical.**
* **Full**: the research configuration. Hypothetical.

## What the evidence supports, and how far

* **SRAM bank controller.** **[R]** Python and RTL agree on every transaction (15/15 configurations, Verilator and
  Icarus): the same acceptance cycle, conflict stalls, response cycle and order, IDs, flags and data.
* **Engine latencies.** **[R]** VE/TE `CYCLES` match the RTL in 54/54 commands.
* **Achieved ≤ ceiling.** **[S] ≤ [A] ≤ peak** for every profile and workload tested.
* **What is not validated.** System-level timing (interconnect, DMA, task pipeline) is a model. For example, the DMA
  calibration against memoryflow's sf_dma RTL still has a 9.1% mean error. Trends and classifications are the
  intended use; absolute system cycle counts are not RTL-exact.

## The central question: what limits each configuration, and which change gives the most?

| Configuration | Limit | Largest marginal gain found |
|---|---|---|
| RTL release | **Bandwidth**: TSPM fill by the CPU load/store loop (0.76 B/cycle, 38 MB/s). It binds every accelerator workload. | **Add a DMA**: ×4.3–4.4 streaming kernels, ×1.36–1.73 GEMM, ×1.41 conv [S] |
| 130 nm demo (with DMA) | GEMM: **compute-limited inside the TE** (operand delivery 8 of 16 MAC/cycle). Streaming: **bandwidth** (DMA / 32-bit bus). | **TE dual operand fetch** for GEMM; a ping-pong TSPM for streaming kernels |
| Provisional | GEMM: TE-internal operand delivery (1.47 GMAC/s = 92% of the 1.6 GMAC/s port roof). Streaming: **DMA bandwidth**. CPU: **latency** (blocking loads). | **TE dual operand fetch: ×1.85 GEMM, ×1.88 conv** [S]; 64→128-bit bus ×1.49 for streaming [S] |
| Full | Small GEMM 64³ is **overhead-bound** (16×16 fill/drain). Large GEMM is compute-bound once on-chip SRAM is ≥ 64–128 KiB. | Larger problems, or a K-split accumulator preload |

## 1. What currently limits each simulated SilicaFlux workload?

RTL release, 50 MHz. Peaks: TE 800 MMAC/s, VE 200 MOPS, CPU 50 MOPS.

| Workload | [A] ceiling (binding interface) | [S] achieved | [S] classification |
|---|---|---|---|
| GEMM 64³ double-buffered | 305 MMAC/s (tspm_fill) | 263 MMAC/s (33%) | BANDWIDTH_BOUND: cpu_copy |
| GEMM 64³ blocked | 348 MMAC/s (tspm_fill) | 182 MMAC/s (23%) | SERIALISATION_BOUND: no overlap |
| GEMM 64³ naive | 68 MMAC/s (tspm_fill) | 58 MMAC/s (7%) | BANDWIDTH_BOUND: cpu_copy |
| GEMM 4×4×4 (on the 4×4 array) | 25 MMAC/s (tspm_fill) | 23 MMAC/s (3%) | BANDWIDTH_BOUND: cpu_copy |
| conv2d 16×16×8→16 | 400 MMAC/s (TE port) | 261 MMAC/s (33%) | BANDWIDTH_BOUND: cpu_copy |
| vector add / AXPY / dot (4096) | 3.2 / 6.3 / 9.5 MOPS (tspm_fill) | 3.0 / 5.9 / 9.1 MOPS (1.5–4.5%) | BANDWIDTH_BOUND: cpu_copy |
| GEMV 32×64 | 18 MOPS (tspm_fill) | 16.5 MOPS | BANDWIDTH_BOUND |
| FIR int32 (vector) | 80 MOPS (VE port) | 52 MOPS (26%) | SERIALISATION_BOUND |
| CPU sequential / random loads | 25 MOPS (ld/st port) | 12.5 / 10 MOPS | LATENCY_BOUND: one blocking load at a time |
| CPU FIR int16 | 1.39 MMAC/s | — | COMPUTE_BOUND: software multiply (no M extension) |

On the provisional profile at 200 MHz:

* GEMM 64³ is COMPUTE_BOUND at 1.37–1.47 GMAC/s. The engine is 90–97% busy and the TE-internal operand limit is
  reported (8 of 16 MAC/cycle).
* conv2d reaches 1.50 GMAC/s.
* Naive GEMM is CONTENTION_BOUND (0.76 GMAC/s).
* Streaming kernels are BANDWIDTH_BOUND by the DMA: vector_add 86 MOPS, dot 264 MOPS.
* FIR is COMPUTE_BOUND on the VE port (302 MOPS).
* CPU loads are LATENCY_BOUND.

## 2. How much theoretical compute capacity is left unused?

[S] utilisation = achieved / peak:

| Profile | GEMM / conv (TE) | Streaming vector kernels | CPU |
|---|---|---|---|
| RTL release | 67–97% unused | 92–98.5% unused | 75–80% unused |
| 130 nm demo | 54–95% unused | 69–93% unused | 75–80% unused |
| Provisional | 53–57% unused, of which **50 points are structural** (the TE operand port caps it at 50% of peak) | 56–89% unused | 75–80% unused |

[A] On every SilicaFlux-V profile the TE's own operand port leaves 50% of the array idle even with all data resident.
The RTL confirms this: K=1024 runs at 2051 cycles for 16,384 MACs = 8.0 MAC/cycle.

## 3. Would adding more vector lanes improve throughput?

**Not on SilicaFlux-V as built, and only moderately even with a DMA.**

* **RTL release.** No [A]. The streaming roof is the 38 MB/s CPU copy, versus an 800 MB/s VE port.
* **Provisional profile** [S]. From 4 to 8 lanes: +20% (dot, vector_add). From 8 to 16: +11%. From 16 to 32: +6%.
  The gain saturates at 16 lanes because the DMA binds. GEMM and conv gain 0%.
* **Recommendation.** Keep 4 lanes for first silicon.

## 4. Would a larger tensor array improve throughput?

**Yes, but only once operand delivery and data movement scale with it.**

* [S] Provisional profile, operand fetch scaled to d bytes per cycle. Going from d = 4 to 8 gives ×3.57 (GEMM 64³,
  double-buffered). Going from 8 to 16 gives only ×1.51 more, a quarter of the 4× MAC increase. Data movement and
  per-tile fill/drain take over.
* [A] RTL release. A larger array gains **nothing**: the 305 MMAC/s TSPM-fill roof (CPU copy) is below even the
  current 4×4 array's 400 MMAC/s operand-port roof.
* **Order of changes.** First the DMA (P2), then dual operand fetch (P1: ×1.85 at the same 16 PEs), and only then a
  larger array (deferred to the full processor).

## 5. How many SRAM banks are justified?

**As many as the bus is wide in banks (bus width ÷ bank width), and no more.**

* [S] Provisional profile (64-bit bus, 32-bit banks, word-interleaved). Going from 1 to 2 banks gives ×1.43 on dot and
  ×1.03 on GEMM. From 2 to 16 banks the gain is 0%. The analytical result agrees.
* The RTL release's 4 high-interleaved 32-bit banks on a 32-bit crossbar are sufficient. A sequential stream there
  stays inside one bank at 4 B/cycle, which equals the bus.
* A 64-bit bus over high-interleaved 32-bit banks would waste half the bus. The event simulator shows this; the
  conflict-free analytical bank bound does not. **Recommendation:** 4 banks; switch to word interleave only together
  with a wider bus.

## 6. When does additional SRAM stop providing material benefit?

* **SilicaFlux-V (no external memory).** SRAM capacity is a **feasibility limit, not a throughput knob**. Workloads
  that do not fit cannot run: 32 KiB rejects dot, vector_add (n=4096) and conv2d, and 128 KiB rejects vector_add at
  n=16384.
  Every workload that fits runs at **identical** throughput from 64 KiB up to 1 MiB [S]. Moving from 256 KiB back to
  128 KiB loses nothing on these workloads and saves ≈ 3.9 mm² of IHP macro area (macro-only, VERIFIED_REPO
  datasheet value).
* **With DRAM** (full profile, 16 KiB TSPM) [A]. GEMM's DRAM-interface intensity rises with SRAM size and reaches the
  DRAM ridge (102.4 GMAC/s ÷ 11.4 GB/s ≈ 9 MAC/B):
  * GEMM 512³: at 32 KiB.
  * GEMM 1024³: at 64–128 KiB (97 GMAC/s at 64 KiB, peak at 128 KiB).

  Beyond that point more SRAM gives 0%: the binding interface moves inward to the scratchpad fill
  (`analytical/sram_capacity_study.csv`). Rule of thumb: stop adding SRAM once the DRAM-interface intensity reaches
  `P_peak / B_DRAM`.

## 7. When does the memory interconnect become the bottleneck?

* **RTL release.** Never. The CPU copy loop (0.76 B/cycle) binds long before the 32-bit crossbar (4 B/cycle).
* **With a DMA** (130 nm demo, 32-bit bus at 50 MHz). Streaming kernels become DMA/bus-bound: vector_add 13.1 MOPS
  and dot 39.7 MOPS, against a VE port that could sustain 4× more.
* **Provisional profile** [S]. Streaming kernels are bus-bound:
  * 32 → 64 bit: ×1.66.
  * 64 → 128 bit: ×1.49.
  * 128 → 256 bit: no gain (the DMA takes over).

  GEMM changes by less than 10% across bus widths, because it is compute-bound inside the TE.
* **Rule.** The interconnect binds whenever bus width × f is below the engine's data demand: the VE port needs
  16 B/cycle, while the bus delivers 4–8 B/cycle.

## 8. Is DMA double buffering worthwhile?

**Yes, on every profile where transfers are a significant share of the time.**

* [S] Double-buffered against blocked GEMM 64³:
  * RTL release (the CPU moves the data, so the gain comes from overlapping CPU copies with TE compute): **×1.45**.
  * 130 nm demo: ×1.14.
  * Provisional: ×1.07.
  * Full: ×1.00, because a single tile covers the whole problem.
* **Cost.** Each tile buffer halves. For small problems, double-buffered tiles should be sized for overlap, not only
  for minimum traffic (OI-11).
* **Caveat.** For vector kernels, double buffering is partly defeated by the TSPM's engine priority. A ping-pong TSPM
  recovers ×1.30–1.43 [S] (P3).

## 9. Which changes should be made to SilicaFlux-V before first silicon?

See `rtl_improvement_proposals.md` for the evidence and costs.

1. **P2 — add a 1-channel DMA** (16–64 B bursts, ≥ 2 outstanding; allow ≥ 2 outstanding transactions for that
   crossbar master). This is the largest gain for the RTL as it stands: ×4.3 on streaming kernels and ×1.4–1.7 on
   GEMM [S], at the same 50 MHz and 32-bit bus.
2. **P1 — TE dual operand fetch** (A and B in one cycle from different banks): ×1.85 GEMM, ×1.88 conv [S]. The RTL
   already lists this as a next-revision item.
3. **P3 — TSPM ping-pong halves, or a guaranteed fabric slot**: ×1.30–1.43 on streaming kernels [S].
4. Keep **128 KiB SRAM, 4 banks, 4 vector lanes, the 4×4 array, and 50 MHz at 130 nm** (IHP estimated Fmax 74.5 MHz;
   SKY130 misses 50 MHz).
5. Optional: widen the DMA/TSPM path to 64 bits, with word-interleaved banks (P4).

## 10. Which improvements should be deferred to the full processor?

* Larger tensor arrays (8×8/16×16), with operand delivery scaled to 2·d bytes/cycle and a K-split accumulator
  preload.
* More vector lanes, together with a wider DMA/bus (lanes saturate at 16 even at 200 MHz with a 64-bit bus).
* External DRAM/HBM with ≥ 64–128 KiB of on-chip SRAM per array (§6).
* Multiple DMA channels; multi-core control with caches and a coherence protocol; a NoC.
* Vector FMA.
* 150–200 MHz operation, which needs 65 nm implementation data (none exists).

## Model-based Pareto view (not proof of physical-design optimality)

Area per MAC, lane, bank and bus bit is HYPOTHETICAL. SRAM area is macro-only. Across a deterministic sample of 48
configurations [S + area model], **every Pareto-optimal point uses 128 KiB SRAM**. For comparison, the 256 KiB
provisional baseline is at 1.0× / 9.31 mm². The front:

| Configuration | Geomean speedup | Area |
|---|---|---|
| 8 lanes, 4×4 TE + dual fetch, 16 KiB TSPM, 64-bit bus, 2 DMA outstanding | 1.60× | 5.49 mm² |
| 16 lanes, 16×16 + dual fetch, 128-bit bus | 7.9× | 6.72 mm² |
| 16 lanes, 16×16 + dual fetch, 128-bit bus, 32 KiB TSPM | 8.0× | 7.21 mm² |

## Limitations of this analysis

* No silicon data and no external measurements exist.
* There is no power model, so energy is not reported.
* DES CPU workloads are single-threaded.
* DRAM and cache are first-order models.
* The DMA model has a 9.1% residual against memoryflow's RTL.

See `open_issues.md`.
