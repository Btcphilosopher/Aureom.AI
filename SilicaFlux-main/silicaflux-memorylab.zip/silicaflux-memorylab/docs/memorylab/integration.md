# Repository integration instructions

## Placement

```bash
cd Aureom.AI/SilicaFlux-main
unzip silicaflux-memorylab.zip        # creates SilicaFlux-main/silicaflux-memorylab/
cd silicaflux-memorylab
```

This mirrors `silicaflux-sramlib`, which is meant to sit at `SilicaFlux-main/silicaflux-sramlib/`. From this
location `memorylab.rtl_integration.find_repo_root()` locates the repository's archives itself:
`SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip`, `silicaflux-v-release1.zip` and
`silicaflux-memoryflow-v2.0.0.zip`. Elsewhere, set `SILICAFLUX_REPO=<path to Aureom.AI>`. Archives are extracted into
`build/memorylab/`; the repository is never modified.

## Environment

```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
sudo apt-get install verilator iverilog        # optional: RTL evidence (Verilator 5.020, Icarus 12 were used)
```

Container: `docker build -t memorylab . && docker run -v <Aureom.AI>:/work/repo memorylab make memorylab-test`.

## Git (when committing is wanted)

```bash
git checkout -b feature/silicaflux-memorylab
git add SilicaFlux-main/silicaflux-memorylab
cp SilicaFlux-main/silicaflux-memorylab/ci/github-actions-memorylab.yml .github/workflows/memorylab.yml
```

No existing SilicaFlux file needs to change.

## Commands

| Make target | CLI |
|---|---|
| `make memorylab-test` | `PYTHONPATH=python python -m pytest -q tests/memorylab` |
| `make memorylab-roofline` | `python -m memorylab roofline --config python/memorylab/configs/silicaflux_v.yaml` |
| `make memorylab-sim` | `python -m memorylab simulate --config python/memorylab/configs/silicaflux_v.yaml --workload all` |
| `make memorylab-sweep` | `python -m memorylab sweep --config python/memorylab/configs/architecture_sweep.yaml` |
| `make memorylab-rtl` | `python -m memorylab rtl --out reports/memorylab/example_run` |
| `make memorylab-report` | `python -m memorylab report --run-dir reports/memorylab/example_run` |
| `make memorylab-all` | `python -m memorylab all --out reports/memorylab/example_run` |

Also available: `python -m memorylab audit-params --config <profile>` (parameter provenance table) and
`python -m memorylab import-trace --trace <csv|json>` (or `--vcd --clock clk --valid v --ready r`).

## SilicaFlux TwinLab

TwinLab (`silicaflux-twinlab.zip`) has no import path: its data are hard-coded Angular signals. MemoryLab writes
structured JSON (`analytical/*.json`, `simulated/*.json`) that maps onto TwinLab's model types as follows:

* `WorkloadRoofline {name, arithmeticIntensity, attainableGflops, isMemoryBound}` ← `workload`, binding `intensity`,
  `ceiling`, `bound != COMPUTE_BOUND`.
* `ProvenanceTag`: `VERIFIED_REPO` → `VERIFIED_PDK|PUBLISHED_VENDOR`; `HYPOTHETICAL` → `ANALYTICAL`. Analytical
  results stay ANALYTICAL; event-simulated results stay separate.

TwinLab needs a loader before it can consume these files (open issue OI-07). Its own Roofline should stop adding
peaks of different engines and op kinds.

## SRAM Wrapper Library contract (if the library moves or changes)

MemoryLab depends only on:

* `rtl/mem/sram_bank_controller.sv` ports and parameters (`NUM_MASTERS`, `NUM_BANKS`, `DATA_WIDTH`, `MASK_WIDTH`,
  `BANK_DEPTH`, `READ_LATENCY`, `ARB`, `INTERLEAVE`, `ADDR_MODE`, `ID_WIDTH`, `RSP_FIFO_DEPTH`, `WRITE_ACK`,
  `TEST_EN`, `ADDR_WIDTH`);
* the handshake semantics of `docs/mem/01_interface_spec.md` §4 and §7;
* the GENERIC backend sources.

Any change there should be followed by `make memorylab-test-rtl`, which re-establishes or refutes equivalence.
