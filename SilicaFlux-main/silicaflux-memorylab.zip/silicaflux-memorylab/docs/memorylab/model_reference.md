# MemoryLab model reference

## 1. Units and operation conventions (`memorylab/units.py`)

| Quantity | Unit | Rule |
|---|---|---|
| MAC | one multiply-accumulate | `OpKind.MAC` |
| integer op | one integer arithmetic operation | `OpKind.INT_OP` (rates in OPS/s) |
| FLOP | one floating-point operation | `OpKind.FLOP` |
| MAC → ops | **1 MAC = 2 ops** by default (`OpConvention(ops_per_mac=2)`) | the only kind conversion; explicit; recorded in every result |
| INT ↔ FP | **never converted** | raises `UnitMismatchError` (INT8 TOPS are never compared with FP32 TFLOP/s) |
| precision | must match between workload and engine peak | the engine's peak at the workload's precision is used, or an error is raised |
| bytes | 8-bit octets; KiB = 1024 B; GB/s = 10⁹ B/s | |
| time | DES: integer femtoseconds; clocks: integer-fs period | quantisation error recorded per clock |

A Roofline plot only combines results of one engine, one op kind and one precision (`check_same_domain`).

## 2. Analytical Roofline (`memorylab/roofline.py`)

Single level: `P = min(P_peak, I·B)`, `I = W/Q` (operations per byte), ridge `I* = P_peak/B`.

Hierarchical, per engine and interface level *l* with its own traffic `Q_l` (reads + writes crossing that interface,
each byte counted once) and sustained bandwidth `B_l`:

```
P ≤ min(P_peak, B_1·I_1, …, B_n·I_n),   I_l = W / Q_l
T ≥ max(W / P_peak, Q_1/B_1, …, Q_n/B_n)            (equivalent time form; both are computed and checked)
```

Bandwidths are never added across levels. A level whose traffic is zero does not constrain.

Latency (Little's law): with request latency `L` and `O` bytes in flight, `B_eff = min(B, O/L)`. If that limit binds,
the result is `LATENCY_BOUND`.

Concurrent workloads on different engines: `T ≥ max(max_e W_e/P_e, max_l Σ_e Q_{e,l}/B_l)`.

Level bandwidths are derived from the profile (`machine.py`) as the minimum of the declared limits:

| Limit | Formula |
|---|---|
| `engine_port` | tensor: operand bytes/cycle × f (reads) and writeback bytes/cycle × f (a separate level); vector: ldst bytes/cycle × f; CPU: load bytes / CPI_load × f |
| `memory` | banks × width × ports × f_mem (peak, conflict-free); DRAM: channels × width × MT/s |
| `interconnect` | `txn / (⌈txn/width⌉ + overhead) × f` with the transfer size in use (DMA burst or CPU word) |
| `dma` | `min(bus, channels × outstanding × burst / (overhead + latency + beats) × f)` |
| `cpu_copy` | `word / (CPI_load + CPI_store + (2·CPI_alu + CPI_br)/4) × f` |

A derived bandwidth carries the combined provenance of its inputs: any hypothetical input makes it hypothetical.

## 3. Compute models (`memorylab/compute.py`)

* **CPU**: the peak is `cores·f·issue/CPI_alu` (OPS/s). For MACs it is `cores·f/(CPI_mul + CPI_alu)`, where `mul_sw` is
  used when there is no hardware multiplier. The estimate is `Σ count·CPI` with an Amdahl split across cores.
* **Vector**: the peak is `lanes·elems/lane·f`. A command takes
  `overhead + ⌈LEN/lanes⌉·max(1/issue, streams·lanes·elem/port) + dependency + conflict (+ WRES)`. The breakdown
  separates ideal, tail, memory-stall, overhead, dependency and conflict cycles.
* **Tensor** (output-stationary rows×cols array, k-step depth d): the peak is `rows·cols·MAC/PE/cycle·f`. A step takes
  `max(d/rate, ⌈(rows+cols)·d·b / operand_port⌉)` cycles. A tile takes
  `overhead + fill + ⌈K/d⌉·step + drain (+ ⌈rows·cols·acc/wb_port⌉)`. A GEMM is tiled over output tiles (padding
  counted) and split into K ≤ max_k commands.

With the SilicaFlux-V parameters these reproduce the RTL exactly (tests `test_compute.py`; RTL run
`rtl/sfv_tile_latency.csv`, 54/54 cases): VE `3 + ⌈LEN/4⌉·P (+1)`, TE `3 + 2K (+4)`.

## 4. Workload traffic (`memorylab/workloads.py`)

The traffic at an interface is evaluated with `capacity` = the storage on the compute side of that interface.
Compulsory traffic (inputs read once, outputs written once) is the lower bound. GEMM strategies:

| Strategy | Traffic at the interface |
|---|---|
| naive | `M·K·b·⌈N/a⌉ + K·N·b·⌈M/a⌉ + M·N·out`, where a = the array dimension (a = 1 for a scalar CPU, which gives 2MNK) |
| blocked | output-stationary `Tm×Tn` tiles (multiples of a), buffers `(Tm·Tk + Tk·Tn)·b + Tm·Tn·acc ≤ C`, with `A·⌈N/Tn⌉ + B·⌈M/Tm⌉ + C` |
| scratchpad_resident | compulsory only; infeasible if `A+B+C_acc > C` |
| double_buffered | as blocked, with 2 copies of every buffer |
| dma_streaming | as double_buffered, with transfers executed by DMA bursts |

K stays whole inside a tile (the SilicaFlux-V TE accumulates only in its 16 registers). It is split only when no
full-K tile fits; each split then adds a partial-sum spill and reload and a vector-engine merge.

## 5. Discrete-event simulator

* **Kernel** (`event_engine.py`): a heap ordered by (time, priority, sequence). Integer-fs time; no negative delays;
  limits on events, time and wall clock; deadlock detection across registered components.
* **SRAM, cycle-level** (`sram.BankController`): mirrors sramlib's bank controller (see `repository_audit.md` §3).
  Validated against RTL.
* **SRAM, transaction-level** (`sram.SramArray`): word-level bank reservation, 1RW/1R1W/2RW, queue-depth backpressure,
  engine-priority windows.
* **Interconnect** (`interconnect.py`): split request/response channels per target (crossbar) or one shared port
  (bus). Per-transaction overhead, cut-through data, RR or fixed arbitration, per-master outstanding limits and queues.
* **DMA** (`dma.py`): descriptor queues per channel, burst split, issue interval, read-outstanding and
  write-outstanding limits, and decoupled read/write streams.
* **DRAM** (`dram.py`): channels, bus rate, latency, queue and optional row hit/miss. It is **not** JEDEC-accurate.
* **Cache** (`cache.py`): set-associative, LRU/FIFO/random, write-back or write-through, MSHRs with merging. **No
  coherence.**
* **Execution** (`simulator.py`): task graph with buffer slots (1 = sequential, 2 = double buffering), loads → compute
  → stores, dependencies, engine-priority bank windows, and DMA or CPU-copy data movement.

Bottleneck classification (`simulator.classify`; thresholds recorded in every result), first match wins:

1. `COMPUTE_BOUND`: engine busy ≥ 85%. The engine-internal limit is reported when there is one (e.g. TE operand
   delivery).
2. `BANDWIDTH_BOUND`: some resource (interconnect channel, SRAM banks, DRAM bus, DMA, CPU copy) ≥ 75% utilised.
3. `CONTENTION_BOUND`: bank-conflict stalls ≥ 25% of bank time.
4. `LATENCY_BOUND`: the outstanding-request limit is reached on ≥ 50% of issue attempts.
5. `SERIALISATION_BOUND`: busy plus transfer ≥ 85% with a single buffer (no overlap).
6. `OVERHEAD_BOUND`: otherwise.

Invariants enforced or tested:

* achieved ≤ peak (a violation raises `SimulationError`) and achieved ≤ analytical ceiling (tested over 4 profiles × 9
  workloads);
* no channel above width × f;
* no completion without acceptance, no loss or duplication, no negative latency;
* reads never overtake an earlier write to the same address (data checked);
* fixed seed → identical results.

## 6. Area / cost (`optimisation.area_model`)

`area = SRAM_KiB·mm²/KiB + fixed logic + Σ units·coefficient`. Only the SRAM coefficient (IHP macro datasheet,
macro-only lower bound) and the fixed logic area (whole-SoC synthesis) are VERIFIED_REPO for SilicaFlux-V. Every
per-unit coefficient is HYPOTHETICAL. Pareto fronts are model-based and **not** proof of physical-design optimality.
Energy is not reported (no calibrated power model).
