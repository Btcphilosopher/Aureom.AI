# SilicaFlux MemoryLab

Computational Roofline, bandwidth, latency and memory-architecture simulator for the SilicaFlux processor family
(Project 02, Aureom.AI / SilicaFlux Semiconductor Engineering).

It answers one question: **is a SilicaFlux configuration compute-bound, bandwidth-bound, latency-bound or limited by
internal contention, and which architectural change buys the most performance per unit of silicon?**

MemoryLab has two independently tested engines:

| Engine | Module | Result category |
|---|---|---|
| Analytical hierarchical Roofline (unit-checked) | `memorylab.roofline`, `memorylab.machine` | `ANALYTICAL_CEILING` (upper bounds) |
| Discrete-event memory-performance simulator | `memorylab.event_engine`, `sram`, `interconnect`, `dma`, `dram`, `cache`, `simulator` | `EVENT_SIMULATED` |

Evidence from RTL simulation is a separate category, `RTL_OBSERVED`, produced by `memorylab.rtl_integration` with
Verilator 5.020 and Icarus 12. `SILICON_MEASURED` is empty because no silicon exists. Results from different
categories are never merged.

## What is validated against real RTL

* **SRAM bank controller.** `memorylab.sram.BankController` is checked transaction by transaction against the
  unmodified `sram_bank_controller.sv` from the SilicaFlux SRAM Wrapper Library (Project 01), using the same stimulus
  file in both. The comparison covers acceptance cycle, conflict stalls, response cycle, order, ID and flags, and read
  data. It passes for 11 configurations under Verilator and 4 under Icarus.
* **SilicaFlux-V engine latency.** The VE and TE latency models give the same `CYCLES` as the unmodified
  `sfv_tile.sv` in 54 of 54 commands (Verilator).
* **Calibration.** DMA parameters are calibrated against memoryflow's `sf_dma` RTL cycle counts. The bank model is
  also compared statistically with sramlib's 48 published Verilator benchmark rows.

Everything else in the system simulator (interconnect, DMA, DRAM, cache, task execution) is transaction-level and
approximately timed. **It is not cycle-accurate against SilicaFlux RTL.**

## Quick start

```bash
python3.12 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
make memorylab-test                       # unit + property + RTL-equivalence tests (RTL tests skip without tools)
make memorylab-all                        # every stage -> reports/memorylab/example_run/ (dashboard.html, REPORT.md)
python -m memorylab roofline --config python/memorylab/configs/silicaflux_v.yaml   # with PYTHONPATH=python
```

Open `reports/memorylab/example_run/dashboard.html` in a browser; it loads `plotly.min.js` from the same folder.

## Profiles (`python/memorylab/configs/`)

| Profile | Meaning |
|---|---|
| `silicaflux_v.yaml` | The brief's **provisional** reference: 256 KiB SRAM, 200 MHz, 64-bit bus, 1 DMA channel. These values are hypothetical. |
| `silicaflux_v_release1_rtl.yaml` | What the **RTL release implements**: 128 KiB SRAM, 50 MHz, 32-bit crossbar, no DMA. |
| `silicaflux_130nm_demo.yaml` | The RTL release plus a proposed DMA, at the 50 MHz supported by the IHP SG13G2 evidence. |
| `silicaflux_65nm_demo.yaml` | The same architecture at 150 MHz. That frequency is the repository's own estimate; there is no 65 nm implementation. |
| `silicaflux_full.yaml` | A larger research configuration (4 cores, 16×16 tensor array, 1 MiB SRAM, DRAM). Hypothetical. |
| `architecture_sweep.yaml`, `memory_sweep.yaml`, `pareto_sweep.yaml` | Sweep definitions. |

Every parameter carries `provenance` (VERIFIED_REPO, RTL_SIMULATED, EXTERNAL_MEASURED or HYPOTHETICAL) and a `source`.
A plain value with no source counts as HYPOTHETICAL. Run `python -m memorylab audit-params --config <profile>` to see
the full table.

## Documentation (`docs/memorylab/`)

| File | Content |
|---|---|
| `repository_audit.md` | What exists in the repository, what `.sf` is, parameter classes, discrepancies |
| `model_reference.md` | Equations, unit conventions, fidelity, classification rules, invariants |
| `final_analysis.md` | Answers to the engineering questions, with the numbers from the example run |
| `rtl_improvement_proposals.md` | Proposed SilicaFlux-V RTL changes, ranked |
| `open_issues.md` | Open engineering issues and known model limitations |
| `integration.md` | Placement in the repository, TwinLab, the SRAM-library contract |
| `commands_and_results.md` | Exact commands executed and actual test results |

## Layout

```
python/memorylab/   units provenance config machine roofline compute workloads          (analytical)
                    event_engine sram bankbench interconnect dma dram cache simulator     (event-driven)
                    sweep optimisation calibration trace_import rtl_integration           (exploration / evidence)
                    plotting dashboard report cli                                         (outputs)
rtl_harness/        tb_memorylab_bank_trace.sv, tb_memorylab_tile_latency.sv              (SV harnesses, sim only)
tests/memorylab/    pytest + hypothesis suites
reports/memorylab/example_run/   outputs produced by the delivered code
```
