"""Cycle-level bank controller (sramlib mirror) and transaction-level SRAM array."""
import pytest

from memorylab import bankbench as bb
from memorylab.bankbench import Req
from memorylab.event_engine import ClockDomain, DeadlockError, EventEngine, Trace, Transaction
from memorylab.sram import BankController, BankCtrlConfig, SramArray, SramConfigError, bank_map


def cfg(**kw):
    base = dict(num_masters=1, num_banks=1, data_width=32, bank_depth=64, read_latency=1)
    base.update(kw)
    return BankCtrlConfig(**base)


def reqs(addrs, we=0, nb0=0, gap=0):
    out, c = [], nb0
    for i, a in enumerate(addrs):
        out.append(Req(c, we, a, 0x1000 + i, 0xF, i))
        c += 1 + gap
    return out


# ---------------------------------------------------------------- single / back-to-back
def test_single_read_latency_is_read_latency():
    for lat in (1, 2, 3):
        r = bb.run(cfg(read_latency=lat), [reqs([5])])
        assert r["accepts"] == [(0, 0, 0)]
        assert r["responses"][0][0] == lat
        assert r["stats"]["avg_latency_cycles"] == lat


def test_back_to_back_one_per_cycle_with_default_credits():
    r = bb.run(cfg(read_latency=2), [reqs(range(50))])
    acc_cycles = [a[0] for a in r["accepts"]]
    assert acc_cycles == list(range(50))
    assert r["stats"]["words_per_cycle"] == pytest.approx(50 / 52)


def test_insufficient_credits_throttle():
    r = bb.run(cfg(read_latency=2, rsp_fifo_depth=1), [reqs(range(20))])
    acc = [a[0] for a in r["accepts"]]
    # can_issue comes from the registered credit counter (no rsp_ready -> req_ready path), so with one
    # credit a new request is accepted LATENCY + 1 cycles after the previous one (sram_rsp_path.sv)
    assert all(b - a == 3 for a, b in zip(acc, acc[1:]))


# ---------------------------------------------------------------- banking & contention
def test_independent_banks_run_in_parallel():
    c = cfg(num_masters=4, num_banks=4)
    stim = [reqs([m + 4 * i for i in range(40)]) for m in range(4)]       # master m -> bank m always
    r = bb.run(c, stim)
    assert r["stats"]["conflict_stalls"] == 0
    assert r["stats"]["words_per_cycle"] == pytest.approx(160 / 41)


def test_same_bank_contention_serialises():
    c = cfg(num_masters=4, num_banks=4)
    stim = [reqs([4 * i for i in range(40)]) for m in range(4)]            # all masters -> bank 0
    r = bb.run(c, stim)
    assert r["stats"]["words_per_cycle"] == pytest.approx(1.0, rel=0.03)
    assert r["stats"]["conflict_stalls"] > 0


def test_parallel_banks_reduce_time_vs_single_bank():
    one = bb.run(cfg(num_masters=4, num_banks=1, bank_depth=256), bb.generate("vector", cfg(num_masters=4, num_banks=1, bank_depth=256), 200, 7))
    four = bb.run(cfg(num_masters=4, num_banks=4), bb.generate("vector", cfg(num_masters=4, num_banks=4), 200, 7))
    assert four["stats"]["cycles"] < one["stats"]["cycles"]


def test_round_robin_fairness_and_fixed_starvation():
    stim = [reqs([0] * 30) for _ in range(3)]
    rr = bb.run(cfg(num_masters=3, num_banks=1), stim)
    order = [a[1] for a in rr["accepts"]][:9]
    assert order == [0, 1, 2] * 3
    fx = bb.run(cfg(num_masters=3, num_banks=1, arbitration="fixed"), stim)
    order = [a[1] for a in fx["accepts"]]
    assert order[:30] == [0] * 30                                          # master 0 starves the others


def test_stride_by_banks_hits_one_bank():
    c = cfg(num_masters=4, num_banks=8, bank_depth=256)
    r = bb.run(c, bb.generate("stride", c, 300, 3))
    acc = r["stats"]["bank_accesses"]
    assert acc[0] == sum(acc)
    assert r["stats"]["words_per_cycle"] == pytest.approx(1.0, rel=0.02)


def test_non_power_of_two_banks():
    with pytest.raises(SramConfigError, match="power of two"):
        cfg(num_banks=3)
    c = cfg(num_masters=3, num_banks=3, allow_non_pow2_banks=True)
    assert not c.rtl_compatible
    stim = [reqs([m + 3 * i for i in range(30)]) for m in range(3)]
    r = bb.run(c, stim)
    assert r["stats"]["conflict_stalls"] == 0
    assert bank_map(7, 3, 64, "low") == (1, 2)


# ---------------------------------------------------------------- ordering & data
def test_read_after_write_returns_written_data_and_masks():
    stim = [[Req(0, 1, 9, 0xAABBCCDD, 0xF, 1), Req(0, 1, 9, 0x00001100, 0b0010, 2), Req(0, 0, 9, 0, 0xF, 3)]]
    r = bb.run(cfg(), stim)
    rsp = {x[2]: x for x in r["responses"]}
    assert rsp[3][3] == 0xAABB11DD                                         # lane 1 replaced only
    assert rsp[1][5] == 1 and rsp[1][3] == 0                               # write ack carries zero data


def test_responses_in_acceptance_order_per_master_with_backpressure():
    c = cfg(num_masters=2, num_banks=2, read_latency=2)
    stim = bb.generate("random", c, 300, 11)
    r = bb.run(c, stim, bp_pct=40, seed=5)
    for m in range(2):
        acc_ids = [a[2] for a in r["accepts"] if a[1] == m]
        rsp_ids = [x[2] for x in r["responses"] if x[1] == m]
        assert rsp_ids == acc_ids                                           # no loss, no dup, in order
    st = r["stats"]
    assert max(st["max_rsp_fifo_occupancy"]) <= c.rsp_fifo_depth
    assert st["max_latency_cycles"] > c.read_latency                       # backpressure visible
    assert sum(st["backpressure_cycles"]) > 0


def test_posted_writes_need_no_credit():
    c = cfg(write_ack=False, read_latency=2, rsp_fifo_depth=1)
    r = bb.run(c, [reqs(range(20), we=1)])
    assert [a[0] for a in r["accepts"]] == list(range(20))
    assert r["responses"] == []


def test_error_responses_in_order():
    c = cfg(bank_depth=16)
    stim = [[Req(0, 0, 3, 0, 0xF, 1), Req(0, 0, 999, 0, 0xF, 2), Req(0, 1, 500, 5, 0xF, 3), Req(0, 0, 4, 0, 0xF, 4)]]
    r = bb.run(c, stim)
    assert [x[2] for x in r["responses"]] == [1, 2, 3, 4]
    errs = {x[2]: x[4] for x in r["responses"]}
    assert errs == {1: 0, 2: 1, 3: 1, 4: 0}


def test_byte_addressing_misaligned_is_error():
    c = cfg(addr_mode="byte", bank_depth=16)
    eng = EventEngine()
    clk = ClockDomain("c", 1e8)
    got = []
    ctl = BankController(eng, clk, c, on_response=lambda m, t, cy: got.append((t.addr, t.error)))
    ctl.present(0, Transaction(eng.new_id(), "m", "R", 6, 4, 0))
    eng.run()
    assert got == [(6, True)]


def test_invariants_and_trace():
    c = cfg(num_masters=4, num_banks=4, read_latency=2)
    r = bb.run(c, bb.generate("mixed", c, 200, 21), bp_pct=20, seed=2, trace=True)
    assert r["trace"].check_invariants() == []
    assert r["stats"]["words_per_cycle"] <= min(4, 4) + 1e-12


def test_reproducible_for_fixed_seed():
    c = cfg(num_masters=4, num_banks=4)
    a = bb.run(c, bb.generate("cpu", c, 200, 99), bp_pct=10, seed=3)
    b = bb.run(c, bb.generate("cpu", c, 200, 99), bp_pct=10, seed=3)
    assert a["accepts"] == b["accepts"] and a["responses"] == b["responses"]
    d = bb.run(c, bb.generate("cpu", c, 200, 98), bp_pct=10, seed=3)
    assert d["accepts"] != a["accepts"]


def test_holding_valid_twice_rejected():
    eng = EventEngine()
    ctl = BankController(eng, ClockDomain("c", 1e8), cfg())
    ctl.present(0, Transaction(1, "m", "R", 0, 4, 0))
    with pytest.raises(RuntimeError):
        ctl.present(0, Transaction(2, "m", "R", 0, 4, 0))


def test_invalid_bank_configs():
    with pytest.raises(SramConfigError):
        cfg(read_latency=0)
    with pytest.raises(SramConfigError):
        cfg(num_masters=17)
    with pytest.raises(SramConfigError):
        cfg(interleave="high", bank_depth=24)


# ---------------------------------------------------------------- transaction-level array
def mk_array(**kw):
    eng = EventEngine()
    clk = ClockDomain("c", 1e8)
    a = SramArray(eng, clk, **{**dict(name="sram", capacity=4096, banks=4, width_bytes=4), **kw})
    return eng, clk, a


def test_array_burst_spreads_over_banks():
    eng, clk, a = mk_array()
    done = []
    t = Transaction(1, "dma", "R", 0, 64, 0)
    assert a.access(t, lambda x: done.append(eng.now), port_bytes_per_cycle=16)
    eng.run()
    assert done == [clk.edge(3 + 1)]                     # 16 words / 4 per cycle = 4 cycles, +1 latency
    assert a.stats()["bank_conflict_cycles"] == [0, 0, 0, 0]


def test_array_same_bank_conflicts_and_service_rate_bound():
    eng, clk, a = mk_array()
    n = 0
    for i in range(10):
        a.access(Transaction(i + 1, f"m{i}", "R", 0, 4, 0), lambda x: None)
        n += 1
    eng.run()
    st = a.stats()
    assert st["bank_accesses"][0] == 10 and sum(st["bank_conflict_cycles"]) == sum(range(10))
    # never more than one access per bank-port per cycle
    for b, row in a.timeline.items():
        assert (row <= a.bucket).all()


def test_array_queue_backpressure():
    eng, clk, a = mk_array(queue_depth=2)
    ok = [a.access(Transaction(i + 1, "m", "R", 4 * i, 4, 0), lambda x: None) for i in range(3)]
    assert ok == [True, True, False]
    eng.run()
    assert a.stats()["rejects"] == 1


def test_array_engine_window_slows_fabric():
    eng, clk, a = mk_array()
    a.add_engine_window(0, 1000, 1.0)
    done = []
    a.access(Transaction(1, "m", "R", 0, 4, 0), lambda x: done.append(clk.to_cycles(eng.now)))
    eng.run()
    assert done == [1001]
    eng, clk, a = mk_array()
    a.add_engine_window(0, 1000, 0.25)
    for i in range(30):
        a.access(Transaction(i + 1, "m", "R", 0, 4, 0), lambda x: None)
    eng.run()
    assert sum(a.stats()["bank_conflict_cycles"]) > sum(range(30))


def test_array_bounds_and_geometry():
    eng, clk, a = mk_array()
    with pytest.raises(ValueError):
        a.access(Transaction(1, "m", "R", 4094, 4, 0), lambda x: None)
    with pytest.raises(SramConfigError):
        mk_array(read_latency=0)
    with pytest.raises(SramConfigError):
        mk_array(ports="3RW")


def test_array_dual_port_doubles_rate():
    e1, c1, one = mk_array()
    e2, c2, two = mk_array(ports="2RW")
    for arr, eng in ((one, e1), (two, e2)):
        for i in range(20):
            arr.access(Transaction(i + 1, "m", "R", 0, 4, 0), lambda x: None)
        eng.run()
    assert sum(two.stats()["bank_conflict_cycles"]) < sum(one.stats()["bank_conflict_cycles"])
