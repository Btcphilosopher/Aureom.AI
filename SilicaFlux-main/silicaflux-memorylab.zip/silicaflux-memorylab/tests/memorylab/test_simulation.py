"""End-to-end event simulation: physical bounds, dependencies, overlap, reproducibility, errors."""
import pytest

from conftest import CONFIGS
from memorylab import machine, simulator as sim, workloads as wl
from memorylab.compute import UnsupportedConfiguration
from memorylab.config import load_profile
from memorylab.event_engine import FS_PER_S, DeadlockError, EventEngine

PROFILES = ["silicaflux_v_release1_rtl", "silicaflux_v", "silicaflux_130nm_demo", "silicaflux_full"]
CASES = [(wl.gemm(32, 32, 32, "blocked"), "tensor"), (wl.gemm(32, 32, 32, "double_buffered"), "tensor"),
         (wl.gemm(8, 8, 8, "scratchpad_resident"), "tensor"), (wl.gemm(16, 16, 16, "naive"), "tensor"),
         (wl.vector_add(2048), "vector"), (wl.dot(2048), "vector"), (wl.axpy(1024), "vector"),
         (wl.gemv(16, 64), "vector"), (wl.cpu_sequential(512), "cpu")]


def prof(name):
    return load_profile(CONFIGS / f"{name}.yaml")


@pytest.mark.parametrize("pname", PROFILES)
@pytest.mark.parametrize("w,eng", CASES, ids=lambda x: getattr(x, "name", x))
def test_simulated_never_exceeds_peak_or_analytical_ceiling(pname, w, eng):
    p = prof(pname)
    r = sim.simulate(p, w, eng, trace=True)
    assert r["trace_invariant_errors"] == []
    assert r["achieved_ops_per_s"] <= r["peak_ops_per_s"] * (1 + 1e-9)
    ceil = machine.analyse(p, w, eng)["ceiling"]
    assert r["achieved_ops_per_s"] <= ceil * (1 + 1e-6), (r["achieved_ops_per_s"], ceil)
    for port in r["interconnect"]["ports"].values():
        assert port["read_Bps"] <= port["peak_Bps_per_direction"] * (1 + 1e-9)
        assert port["write_Bps"] <= port["peak_Bps_per_direction"] * (1 + 1e-9)
        assert port["req_busy_fraction"] <= 1 + 1e-9 and port["rsp_busy_fraction"] <= 1 + 1e-9
    assert r["makespan_s"] > 0 and r["classification"]["bound"]


def test_dependencies_and_ordering_honoured():
    r = sim.simulate(prof("silicaflux_v"), wl.gemm(64, 64, 64, "double_buffered"), "tensor")
    tasks = r["tasks"]
    by = {t["name"]: t for t in tasks}
    for t in tasks:
        assert t["load_start"] <= t["loaded"] <= t["compute_start"] <= t["compute_end"] <= t["done"]
    eng_iv = sorted((t["compute_start"], t["compute_end"]) for t in tasks)
    assert all(b[0] >= a[1] for a, b in zip(eng_iv, eng_iv[1:]))         # one engine: no overlap of computes


def test_double_buffering_overlaps_and_helps_when_transfers_matter():
    for pname in ("silicaflux_v_release1_rtl", "silicaflux_130nm_demo"):
        p = prof(pname)
        a = sim.simulate(p, wl.gemm(64, 64, 64, "blocked"), "tensor")
        b = sim.simulate(p, wl.gemm(64, 64, 64, "double_buffered"), "tensor")
        assert b["makespan_s"] < a["makespan_s"]
        tasks = b["tasks"]
        overlap = any(x["load_start"] < y["compute_end"] and x["loaded"] > y["compute_start"]
                      for x in tasks for y in tasks if x["name"] != y["name"])
        assert overlap                                                    # transfer concurrent with compute


def test_reproducible_fixed_seed():
    p = prof("silicaflux_full")
    w = wl.cpu_random(300, 64 * 1024)
    a = sim.simulate(p, w, "cpu", seed=7, trace=True)
    b = sim.simulate(p, w, "cpu", seed=7, trace=True)
    c = sim.simulate(p, w, "cpu", seed=8, trace=True)
    assert a["makespan_s"] == b["makespan_s"] and a["latency_cycles"] == b["latency_cycles"]
    assert a["events"] == b["events"]
    addrs = lambda r: [row[6] for row in r["_trace_rows"] if row[1] == "ISSUE"]
    assert addrs(a) == addrs(b)
    assert addrs(c) != addrs(a)            # the seed drives the address stream


def test_cpu_random_on_dram_is_latency_bound():
    r = sim.simulate(prof("silicaflux_full"), wl.cpu_random(400, 512 * 1024), "cpu")
    assert r["classification"]["bound"] in ("LATENCY_BOUND", "COMPUTE_BOUND")
    assert r["latency_cycles"]["mean"] > 20


def test_release1_data_movement_by_cpu_is_the_bottleneck():
    r = sim.simulate(prof("silicaflux_v_release1_rtl"), wl.vector_add(4096), "vector")
    assert r["mover"] == "cpu_copy"
    assert r["classification"]["bound"] == "BANDWIDTH_BOUND" and "cpu_copy" in r["classification"]["busiest_resource"]


def test_tensor_internal_operand_limit_reported():
    r = sim.simulate(prof("silicaflux_v"), wl.gemm(64, 64, 64, "double_buffered"), "tensor")
    assert "8 of 16 MAC/cycle" in r["engine_internal_limit"]


def test_engine_priority_slows_concurrent_fabric_traffic():
    p = prof("silicaflux_v")
    alone = sim.simulate_mixed(p, [(wl.cpu_sequential(256), "cpu")])
    mixed = sim.simulate_mixed(p, [(wl.cpu_sequential(256), "cpu"), (wl.vector_add(4096), "vector"),
                                   (wl.gemm(32, 32, 32, "double_buffered"), "tensor")])
    t_alone = alone["parts"][0]["time_s"]
    t_mixed = next(x for x in mixed["parts"] if x["engine"] == "cpu")["time_s"]
    assert t_mixed >= t_alone
    assert len(mixed["parts"]) == 3 and mixed["makespan_s"] >= max(x["time_s"] for x in mixed["parts"]) - 1e-15


def test_workload_too_large_for_memory_is_an_error():
    with pytest.raises(UnsupportedConfiguration, match="exceeds sram capacity"):
        sim.simulate(prof("silicaflux_v_release1_rtl"), wl.gemm(512, 512, 512, "blocked"), "tensor")
    with pytest.raises(UnsupportedConfiguration):
        sim.simulate(prof("silicaflux_v"), wl.vector_add(100, precision=wl.Precision.INT8), "vector")


def test_unsupported_engine_and_resident_infeasible():
    with pytest.raises(UnsupportedConfiguration):
        sim.simulate(prof("silicaflux_v"), wl.cpu_sequential(10), "gpu")
    with pytest.raises(wl.InfeasibleStrategy):
        sim.simulate(prof("silicaflux_v"), wl.gemm(128, 128, 128, "scratchpad_resident"), "tensor")


def test_event_limit_is_enforced():
    with pytest.raises(Exception, match="event limit"):
        sim.simulate(prof("silicaflux_v"), wl.vector_add(8192), "vector", max_events=100)


def test_deadlock_detected_when_work_cannot_progress():
    class Never:
        name = "never_served"

        def outstanding(self):
            return 1
    e = EventEngine()
    e.register(Never())
    with pytest.raises(DeadlockError):
        e.run()


def test_remainder_tiles_not_charged_full_compute():
    # tile sizes that do not divide M must not inflate TE compute (regression: tm=36 for M=64)
    p = prof("silicaflux_v")
    r = sim.simulate(p, wl.gemm(64, 64, 64, "blocked"), "tensor")
    te_cycles = sum(t["compute_end"] - t["compute_start"] for t in r["tasks"]) / (1e15 / p.f)
    exact = (64 // 4) * (64 // 4) * (3 + 2 * 64 + 4)
    assert te_cycles == pytest.approx(exact)
