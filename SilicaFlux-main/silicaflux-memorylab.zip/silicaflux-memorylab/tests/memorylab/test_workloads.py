"""Workload operation counts, footprints and per-interface traffic."""
import math

import pytest
from hypothesis import given, settings, strategies as st

from memorylab import workloads as wl
from memorylab.units import KiB, OpConvention, OpKind, Precision


def test_gemm_op_counts_mac_vs_ops():
    g = wl.gemm(8, 16, 32, "blocked")
    assert g.macs == 8 * 16 * 32
    assert g.work(OpKind.MAC).value == 4096
    assert g.work(OpKind.INT_OP).value == 2 * 4096          # 1 MAC = 2 ops by default
    g1 = wl.gemm(8, 16, 32, "blocked")
    g1.convention = OpConvention(1)
    assert g1.work(OpKind.INT_OP).value == 4096
    with pytest.raises(ValueError):
        g.work(OpKind.FLOP)                                  # int8 GEMM has no FLOPs


def test_fp32_gemm_counts_flops():
    g = wl.gemm(4, 4, 4, "naive", precision=Precision.FP32)
    assert g.work(OpKind.FLOP).value == 128


def test_gemm_traffic_bounds_and_monotonic_in_capacity():
    m = n = k = 64
    naive = wl.gemm(m, n, k, "naive").traffic(16 * KiB).total
    comp = wl.gemm(m, n, k, "blocked").compulsory().total
    prev = math.inf
    for cap in [1 * KiB, 2 * KiB, 4 * KiB, 8 * KiB, 16 * KiB, 64 * KiB]:
        t = wl.gemm(m, n, k, "blocked").traffic(cap).total
        assert comp <= t <= naive
        assert t <= prev + 1e-9            # more capacity never increases traffic
        prev = t


def test_reuse_increases_intensity_not_bandwidth():
    g = wl.gemm(128, 128, 128, "blocked")
    i_small = g.intensity(2 * KiB, OpKind.MAC)
    i_large = g.intensity(64 * KiB, OpKind.MAC)
    assert i_large > 2 * i_small


def test_scratchpad_resident_requires_fit():
    g = wl.gemm(64, 64, 64, "scratchpad_resident")
    with pytest.raises(wl.InfeasibleStrategy):
        g.traffic(8 * KiB)
    assert g.traffic(64 * KiB).total == g.compulsory().total


def test_double_buffered_uses_half_capacity():
    b = wl.gemm(128, 128, 128, "blocked").traffic_detail(16 * KiB)[1]
    d = wl.gemm(128, 128, 128, "double_buffered").traffic_detail(16 * KiB)[1]
    assert d["working_set_bytes"] <= 16 * KiB and d["buffers"] == 2
    assert d["tm"] * d["tn"] <= b["tm"] * b["tn"]
    assert wl.gemm(128, 128, 128, "double_buffered").traffic(16 * KiB).total >= \
        wl.gemm(128, 128, 128, "blocked").traffic(16 * KiB).total


def test_dma_streaming_same_bytes_as_double_buffered():
    a = wl.gemm(96, 96, 96, "double_buffered").traffic(16 * KiB)
    b = wl.gemm(96, 96, 96, "dma_streaming").traffic(16 * KiB)
    assert a == b


def test_tile_infeasible_when_tiny():
    with pytest.raises(wl.InfeasibleStrategy):
        wl.gemm(64, 64, 64, "blocked").traffic(64)


def test_streaming_kernels():
    va = wl.vector_add(1000)
    assert va.traffic(0).read_bytes == 8000 and va.traffic(0).write_bytes == 4000
    assert va.intensity(0) == pytest.approx(1000 / 12000)
    ax = wl.axpy(1000)
    assert ax.work(OpKind.INT_OP).value == 2000 and ax.work(OpKind.MAC).value == 1000
    d = wl.dot(1000)
    assert d.traffic(0).write_bytes == 4


def test_gemv_x_reuse():
    g = wl.gemv(64, 64)
    assert g.traffic(1 * KiB).read_bytes == 64 * 64 * 4 + 64 * 4
    assert g.traffic(64).read_bytes == 2 * 64 * 64 * 4


def test_conv2d_counts_and_modes():
    c = wl.conv2d(16, 16, 8, 16, 3, 3, 1, 1)
    assert c.dims["p"] == 16 and c.macs == 16 * 16 * 16 * 9 * 8
    resident = c.traffic_detail(1e9)
    assert resident[1]["mode"] == "resident"
    lb = c.traffic_detail(2 * KiB)           # weights (1152 B) + 3-row line buffer (432 B) fit
    assert lb[1]["mode"] == "weights_resident_line_buffer" and lb[0].total == resident[0].total
    small = c.traffic_detail(1 * KiB)        # weights no longer fit -> output-channel chunks re-read input
    assert small[1]["mode"].startswith("cout_chunks") and small[0].total > resident[0].total


def test_fir_and_stencil():
    f = wl.fir(1024, 32)
    assert f.macs == 1024 * 32 and f.traffic(1 * KiB).read_bytes == 1024 * 2 + 32 * 2
    s = wl.stencil2d(64, 64)
    assert s.traffic(1 * KiB).read_bytes == 64 * 64
    assert s.traffic(10).read_bytes == 64 * 64 * 9


def test_memory_kernels():
    d = wl.dma_copy(4096)
    assert d.traffic(0).total == 8192 and d.arithmetic_ops == 0
    r = wl.cpu_random(1000, 64 * KiB, line_bytes=64)
    assert r.traffic(32 * KiB).read_bytes == pytest.approx(1000 * 0.5 * 64)


def test_tensor_port_traffic():
    t = wl.gemm_tensor_port_traffic(8, 8, 16, 4, 4, 1, Precision.INT8)
    assert t.read_bytes == 4 * 16 * 8 and t.write_bytes == 4 * 16 * 4


def test_library_sizes_build():
    for size in ("small", "medium", "large"):
        for w in wl.library(size):
            assert w.describe(16 * KiB)["traffic_bytes"] >= 0


@settings(max_examples=60, deadline=None)
@given(m=st.integers(1, 80), n=st.integers(1, 80), k=st.integers(1, 80),
       cap=st.integers(512, 128 * 1024))
def test_gemm_blocked_never_below_compulsory(m, n, k, cap):
    g = wl.gemm(m, n, k, "blocked")
    try:
        t, info = g.traffic_detail(cap)
    except wl.InfeasibleStrategy:
        return
    assert t.total >= g.compulsory().total - 1e-9
    if not info["split_k"]:
        # a capacity-forced K split pays partial-sum spills and may then exceed streaming naive traffic
        assert t.total <= wl.gemm(m, n, k, "naive").traffic(cap).total + 1e-9
