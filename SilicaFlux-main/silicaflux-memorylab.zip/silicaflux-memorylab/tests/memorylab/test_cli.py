"""Command-line interface: commands run and errors are meaningful."""
import json

import pytest

from conftest import CONFIGS
from memorylab.cli import main


def test_roofline_command(tmp_path, capsys):
    rc = main(["roofline", "--config", str(CONFIGS / "silicaflux_v.yaml"), "--workload", "gemm_64", "--out", str(tmp_path)])
    assert rc == 0
    assert (tmp_path / "roofline_silicaflux_v.csv").exists()
    assert any(p.suffix == ".png" for p in tmp_path.iterdir())
    d = json.loads((tmp_path / "roofline_silicaflux_v.json").read_text())
    assert d["category"] == "ANALYTICAL_CEILING" and d["provenance"]["simulator"] == "SilicaFlux MemoryLab"


def test_simulate_command(tmp_path):
    rc = main(["simulate", "--config", str(CONFIGS / "silicaflux_v.yaml"), "--workload", "dot", "--size", "small",
               "--out", str(tmp_path), "--trace"])
    assert rc == 0 and (tmp_path / "simulated_silicaflux_v.csv").exists()


def test_audit_params(tmp_path, capsys):
    assert main(["audit-params", "--config", str(CONFIGS / "silicaflux_v_release1_rtl.yaml"),
                 "--csv", str(tmp_path / "p.csv")]) == 0
    assert "VERIFIED_REPO" in (tmp_path / "p.csv").read_text()


def test_meaningful_errors(tmp_path, capsys):
    assert main(["roofline", "--config", str(tmp_path / "missing.yaml")]) == 2
    assert "not found" in capsys.readouterr().err
    assert main(["sweep", "--config", str(CONFIGS / "silicaflux_v.yaml")]) == 2
    assert "sweep" in capsys.readouterr().err
    assert main(["roofline", "--config", str(CONFIGS / "silicaflux_v.yaml"), "--workload", "nonsense_kernel"]) == 2
    assert main(["report", "--run-dir", str(tmp_path / "nothing")]) == 2
    with pytest.raises(SystemExit):
        main(["frobnicate"])
