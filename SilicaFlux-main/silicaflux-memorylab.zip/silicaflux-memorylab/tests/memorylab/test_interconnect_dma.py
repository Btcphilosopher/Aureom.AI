"""Interconnect, DMA, DRAM and cache models."""
import pytest

from memorylab.cache import Cache
from memorylab.dma import Descriptor, Dma
from memorylab.dram import Dram
from memorylab.event_engine import FS_PER_S, ClockDomain, EventEngine, Transaction
from memorylab.interconnect import Interconnect
from memorylab.sram import SramArray


def system(width=8, overhead=1, max_out=4, qdepth=8, topology="crossbar", arb="rr"):
    eng = EventEngine()
    clk = ClockDomain("clk", 100e6)
    ic = Interconnect(eng, clk, width_bytes=width, overhead_cycles=overhead, max_outstanding_per_master=max_out,
                      queue_depth=qdepth, topology=topology, arbitration=arb)
    a = SramArray(eng, clk, name="sram", capacity=64 * 1024, banks=4, width_bytes=4)
    b = SramArray(eng, clk, name="spm", capacity=16 * 1024, banks=4, width_bytes=4, base_addr=0x10000)
    ic.connect("sram", a, port_bytes_per_cycle=width)
    ic.connect("spm", b, port_bytes_per_cycle=width)
    return eng, clk, ic, a, b


def test_single_read_latency_components():
    eng, clk, ic, a, _ = system(width=4, overhead=1)
    done = []
    ic.request("cpu", Transaction(1, "cpu", "R", 0, 4, 0), "sram", lambda t: done.append(clk.to_cycles(eng.now)))
    eng.run()
    # SFB-like: address phase (cycle 0), SRAM data cycle with rvalid (cycle 1) -> sampled at edge 2,
    # matching SilicaFlux-V's documented zero-wait load (CPI 2)
    assert done == [2.0]
    eng, clk, ic, a, _ = system(width=4, overhead=1)
    ic.request("cpu", Transaction(1, "cpu", "W", 0, 4, 0), "sram", lambda t: done.append(clk.to_cycles(eng.now)))
    eng.run()
    assert done[-1] == 2.0


def test_bandwidth_never_exceeds_width_times_f():
    eng, clk, ic, a, _ = system(width=8, overhead=0, max_out=16, qdepth=64)
    for i in range(64):
        ic.request("dma", Transaction(i + 1, "dma", "R", 64 * i, 64, 0), "sram", lambda t: None)
    eng.run()
    st = ic.stats(eng.now)
    port = st["ports"]["sram"]
    assert port["read_Bps"] <= port["peak_Bps_per_direction"] * (1 + 1e-9)
    # occupancy intervals never overlap on one channel
    iv = sorted(ic.rsp_ch["sram"].intervals)
    assert all(b[0] >= a_[1] for a_, b in zip(iv, iv[1:]))
    assert port["rsp_busy_fraction"] <= 1.0 + 1e-12


def test_crossbar_parallel_vs_bus_serial():
    res = {}
    for topo in ("crossbar", "bus"):
        eng, clk, ic, a, b = system(width=4, overhead=1, topology=topo, max_out=8, qdepth=64)
        for i in range(32):
            ic.request("m0", Transaction(2 * i + 1, "m0", "R", 4 * i, 4, 0), "sram", lambda t: None)
            ic.request("m1", Transaction(2 * i + 2, "m1", "R", 0x10000 + 4 * i, 4, 0), "spm", lambda t: None)
        eng.run()
        res[topo] = eng.now
    assert res["crossbar"] < res["bus"]


def test_round_robin_shares_port_and_fixed_prefers_first():
    for arb, expect_fair in (("rr", True), ("fixed", False)):
        eng, clk, ic, a, _ = system(width=4, overhead=1, max_out=1, qdepth=64, arb=arb)
        order = []
        for i in range(10):
            for m in ("m0", "m1"):
                ic.request(m, Transaction(eng.new_id(), m, "R", 0, 4, 0), "sram", lambda t, m=m: order.append(m))
        eng.run()
        first10 = order[:10]
        if expect_fair:
            assert abs(first10.count("m0") - first10.count("m1")) <= 1
        assert len(order) == 20


def test_outstanding_limit_and_queue_backpressure():
    eng, clk, ic, a, _ = system(width=4, max_out=1, qdepth=2)
    oks = [ic.request("m", Transaction(i + 1, "m", "R", 4 * i, 4, 0), "sram", lambda t: None) for i in range(3)]
    assert oks == [True, True, False]
    eng.run()
    assert ic.stats(eng.now)["masters"]["m"]["rejects"] == 1


def test_unknown_target_and_bad_config():
    eng, clk, ic, a, _ = system()
    with pytest.raises(KeyError):
        ic.request("m", Transaction(1, "m", "R", 0, 4, 0), "nope", lambda t: None)
    with pytest.raises(ValueError):
        Interconnect(eng, clk, width_bytes=0)


# ---------------------------------------------------------------- DMA
def test_dma_copy_moves_all_bytes_src_and_dst():
    eng, clk, ic, a, b = system(width=8, max_out=8, qdepth=8)
    dma = Dma(eng, clk, ic, burst_bytes=64, max_outstanding=4)
    done = []
    dma.submit(Descriptor("sram", 0, "spm", 0x10000, 4096, on_done=lambda d: done.append(d)))
    eng.run()
    assert len(done) == 1 and done[0].written == 4096
    assert a.stats()["reads"] == 64 and b.stats()["writes"] == 64
    assert a.stats()["bytes"] == 4096 and b.stats()["bytes"] == 4096
    st = dma.stats(eng.now)
    assert st["bytes"] == 4096 and st["bursts"] == 64


def test_dma_more_outstanding_is_faster_until_bus_bound():
    times = {}
    for mo in (1, 2, 4, 8, 16):
        eng, clk, ic, a, b = system(width=8, max_out=16, qdepth=16)
        dma = Dma(eng, clk, ic, burst_bytes=64, max_outstanding=mo)
        dma.submit(Descriptor("sram", 0, "spm", 0x10000, 8192))
        eng.run()
        times[mo] = eng.now
    # reads and writes are decoupled: two outstanding bursts already saturate the 8 B/cycle channels
    assert times[1] > times[2]
    assert all(times[k] == pytest.approx(times[2], rel=0.02) for k in (4, 8, 16))    # saturated: no further gain
    bw = 8192 / (times[16] / FS_PER_S)
    assert bw <= 8 * 100e6 * (1 + 1e-9) and bw >= 0.95 * 8 * 100e6


def test_dma_issue_interval_limits_small_bursts():
    t = {}
    for iv in (1, 4):
        eng, clk, ic, a, b = system(width=8, max_out=16, qdepth=16)
        dma = Dma(eng, clk, ic, burst_bytes=8, max_outstanding=16, issue_interval_cycles=iv)
        dma.submit(Descriptor("sram", 0, "spm", 0x10000, 2048))
        eng.run()
        t[iv] = clk.to_cycles(eng.now)
    assert t[4] >= 4 * 2048 / 8 and t[4] > t[1]


def test_dma_queue_depth_and_invalid():
    eng, clk, ic, a, b = system()
    dma = Dma(eng, clk, ic, queue_depth=1)
    assert dma.submit(Descriptor("sram", 0, "spm", 0x10000, 64))
    assert dma.submit(Descriptor("sram", 64, "spm", 0x10040, 64)) in (True, False)
    with pytest.raises(ValueError):
        Descriptor("sram", 0, "spm", 0, 0)
    eng.run()


def test_concurrent_dma_and_cpu_contend():
    eng, clk, ic, a, b = system(width=4, max_out=4, qdepth=64)
    dma = Dma(eng, clk, ic, burst_bytes=64, max_outstanding=4)
    dma.submit(Descriptor("sram", 0, "spm", 0x10000, 4096))
    cpu_lat = []
    for i in range(50):
        ic.request("cpu", Transaction(eng.new_id(), "cpu", "R", 40000 + 4 * i, 4, 0), "sram",
                   lambda t: cpu_lat.append(1))
    eng.run()
    m = ic.stats(eng.now)["masters"]
    assert m["cpu"]["avg_latency_cycles"] > 4                     # slowed by DMA traffic on the sram port
    assert len(cpu_lat) == 50


# ---------------------------------------------------------------- DRAM
def test_dram_bandwidth_and_latency():
    eng = EventEngine()
    d = Dram(eng, channels=1, bus_width_bytes=4, data_rate_mtps=1000, read_latency_ns=50, queue_depth=64)
    t0 = []
    d.access(Transaction(1, "m", "R", 0, 64, 0), lambda t: t0.append(eng.now))
    eng.run()
    assert t0[0] == pytest.approx(50e6 + 64 / 4e9 * 1e15)
    eng = EventEngine()
    d = Dram(eng, channels=2, bus_width_bytes=4, data_rate_mtps=1000, read_latency_ns=50, queue_depth=64)
    for i in range(100):
        d.access(Transaction(i + 1, "m", "R", 64 * i, 64, 0), lambda t: None)
    eng.run()
    assert d.stats(eng.now)["Bps"] <= d.peak_Bps * (1 + 1e-9)


def test_dram_rows_and_backpressure():
    eng = EventEngine()
    d = Dram(eng, model_rows=True, queue_depth=2)
    assert d.access(Transaction(1, "m", "R", 0, 32, 0), lambda t: None)
    assert d.access(Transaction(2, "m", "R", 32, 32, 0), lambda t: None)
    assert not d.access(Transaction(3, "m", "R", 64, 32, 0), lambda t: None)
    eng.run()
    assert d.row_hits == 1 and d.row_misses == 1


# ---------------------------------------------------------------- cache
def cache(**kw):
    eng = EventEngine()
    clk = ClockDomain("c", 100e6)
    mem = SramArray(eng, clk, name="mem", capacity=1 << 20, banks=1, width_bytes=8)
    c = Cache(eng, clk, name="l1", capacity=1024, line_bytes=64, ways=2, downstream=mem, downstream_name="mem",
              **kw)
    return eng, clk, c, mem


def test_cache_hit_miss_and_lru():
    eng, clk, c, mem = cache()
    # 8 sets x 2 ways; lines 0, 8, 16 (addr 0, 512, 1024) share set 0
    # 0 miss, 4 hit, 64 miss, 0 hit, 512 miss, 1024 miss (evicts LRU line 0), 0 miss (evicts line 8)
    for addr in [0, 4, 64, 0, 512, 1024, 0]:
        c.access(Transaction(eng.new_id(), "cpu", "R", addr, 4, eng.now), lambda t: None)
        eng.run()
    st = c.stats()
    assert st["hits"] == 2 and st["misses"] == 5
    assert mem.stats()["reads"] == 5
    eng, clk, c, mem = cache(replacement="fifo")
    for addr in [0, 512, 0, 1024, 0]:            # FIFO ignores the hit on 0: 1024 evicts 0
        c.access(Transaction(eng.new_id(), "cpu", "R", addr, 4, eng.now), lambda t: None)
        eng.run()
    assert c.stats()["misses"] == 4


def test_cache_mshr_merge_and_limit():
    eng, clk, c, mem = cache(mshrs=1)
    assert c.access(Transaction(1, "cpu", "R", 0, 4, 0), lambda t: None)
    assert c.access(Transaction(2, "cpu", "R", 8, 4, 0), lambda t: None)       # secondary miss merges
    assert not c.access(Transaction(3, "cpu", "R", 128, 4, 0), lambda t: None)  # MSHR full
    eng.run()
    assert c.stats()["merged_secondary_misses"] == 1


def test_cache_write_back_dirty_eviction():
    eng, clk, c, mem = cache()
    for addr, op in [(0, "W"), (512, "R"), (1024, "R")]:
        c.access(Transaction(eng.new_id(), "cpu", op, addr, 4, eng.now), lambda t: None)
        eng.run()
    assert c.stats()["writebacks"] == 1 and mem.stats()["writes"] == 1


def test_cache_write_through_no_allocate():
    eng, clk, c, mem = cache(write_policy="write_through")
    c.access(Transaction(1, "cpu", "W", 0, 4, 0), lambda t: None)
    eng.run()
    assert mem.stats()["writes"] == 1 and c.stats()["misses"] == 1
    with pytest.raises(ValueError):
        c.access(Transaction(2, "cpu", "R", 62, 4, 0), lambda t: None)      # crosses a line


def test_no_deadlock_when_next_request_targets_other_port():
    # regression: one master, 1 outstanding, alternating targets (CPU copy loop sharing cpu.d)
    eng, clk, ic, a, b = system(width=4, max_out=1, qdepth=8)
    done = []
    for i in range(6):
        tgt, base = ("sram", 0) if i % 2 == 0 else ("spm", 0x10000)
        ic.request("cpu.d", Transaction(i + 1, "cpu", "R", base + 4 * i, 4, 0), tgt, lambda t: done.append(t.tid))
    eng.run()
    assert done == [1, 2, 3, 4, 5, 6]
