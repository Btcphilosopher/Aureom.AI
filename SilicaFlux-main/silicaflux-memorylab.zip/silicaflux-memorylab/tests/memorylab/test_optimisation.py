"""Sweep selection/limits, marginal gains, diminishing returns and Pareto analysis."""
import math

import pandas as pd
import pytest

from conftest import CONFIGS
from memorylab import optimisation as opt, sweep as sw
from memorylab.config import ConfigError, load_profile, read_profile_dict


def spec(tmp_path, body):
    p = tmp_path / "s.yaml"
    p.write_text(body.replace("BASE", str(CONFIGS / "silicaflux_v.yaml")))
    return sw.load_sweep(p)


def test_ofat_selection_counts_and_baseline(tmp_path):
    s = spec(tmp_path, "sweep:\n  base_profile: BASE\n  mode: ofat\n  parameters:\n    vector_lanes: [2, 4, 8]\n"
                       "    bus_bits: [32, 64, 128]\n  workloads: [{kind: dot}]\n")
    pts = sw.select_points(s, read_profile_dict(s.base_profile))
    assert pts[0]["_vary"] == "baseline" and pts[0]["vector_lanes"] == 4 and pts[0]["bus_bits"] == 64
    assert len(pts) == 1 + 2 + 2                  # baseline values are not repeated


def test_grid_refused_when_too_large(tmp_path):
    s = spec(tmp_path, "sweep:\n  base_profile: BASE\n  mode: grid\n  parameters:\n    vector_lanes: [2, 4, 8, 16, 32]\n"
                       "    bus_bits: [32, 64, 128, 256]\n    sram_banks: [1, 2, 4, 8, 16]\n  limits: {max_runs: 50}\n")
    with pytest.raises(ConfigError, match="exceeds max_runs"):
        sw.select_points(s, read_profile_dict(s.base_profile))


def test_sample_is_deterministic_and_constrained(tmp_path):
    body = ("sweep:\n  base_profile: BASE\n  mode: sample\n  sample: {n: 12, seed: 5}\n  parameters:\n"
            "    tspm_kib: [4, 8, 16, 32, 64]\n    sram_kib: [8, 16, 32, 64]\n  constraints: ['tspm_kib <= sram_kib']\n")
    s = spec(tmp_path, body)
    a = sw.select_points(s, read_profile_dict(s.base_profile))
    b = sw.select_points(s, read_profile_dict(s.base_profile))
    assert a == b
    assert all(p["tspm_kib"] <= p["sram_kib"] for p in a if p["_vary"] != "baseline")


def test_unknown_knob_and_wrong_file_type(tmp_path):
    with pytest.raises(ConfigError, match="unknown sweep parameters"):
        spec(tmp_path, "sweep:\n  base_profile: BASE\n  parameters:\n    warp_drive: [1]\n")
    with pytest.raises(ConfigError, match="sweep"):
        sw.load_sweep(CONFIGS / "silicaflux_v.yaml")


def test_build_point_preserves_baseline_and_couplings():
    base = read_profile_dict(CONFIGS / "silicaflux_full.yaml")
    p0 = sw.build_point(base, {"tensor_dim": 16, "vector_lanes": 8})          # = baseline values
    ref = load_profile(CONFIGS / "silicaflux_full.yaml")
    assert p0.tensor.operand_bytes_per_cycle.v == ref.tensor.operand_bytes_per_cycle.v
    base_v = read_profile_dict(CONFIGS / "silicaflux_v.yaml")
    p = sw.build_point(base_v, {"vector_lanes": 8})
    assert p.vector.ldst_bytes_per_cycle.v == 32 and p.memory("tspm").banks.v == 8
    q = sw.build_point(base_v, {"tensor_dim": 8, "tensor_operand_ports": 2})
    assert q.tensor.rows.v == 8 and q.tensor.operand_bytes_per_cycle.v == 16
    assert q.tensor.operand_bytes_per_cycle.provenance.value == "HYPOTHETICAL"


def test_sweep_runs_with_limits(tmp_path):
    s = spec(tmp_path, "sweep:\n  base_profile: BASE\n  mode: ofat\n  parameters:\n    tensor_operand_ports: [1, 2]\n"
                       "  workloads: [{kind: gemm, n: 16}]\n  sizes: [small]\n")
    res = sw.run_sweep(s)
    df = res["df"]
    assert set(df["status"]) == {"ok"} and len(df) == 2
    two = df[df.tensor_operand_ports == 2].iloc[0]
    assert two["sim_throughput_vs_baseline"] > 1.2
    s.max_wall_s = 0.0
    assert sw.run_sweep(s)["stopped"].startswith("max_wall_s")


def synth():
    rows = [{"_vary": "baseline", "point": 0, "workload": "w", "lanes_k": 4, "sim_throughput": 100.0, "area_mm2": 1.0,
             "sim_time_s": 1.0, "sustained_Bps": 10.0, "sim_bound": "COMPUTE_BOUND", "busiest_resource": "x"}]
    for i, (v, perf, area) in enumerate([(8, 190.0, 1.2), (16, 200.0, 1.6), (32, 201.0, 2.4)], start=1):
        rows.append({"_vary": "lanes_k", "point": i, "workload": "w", "lanes_k": v, "sim_throughput": perf,
                     "area_mm2": area, "sim_time_s": 100.0 / perf, "sustained_Bps": 10.0,
                     "sim_bound": "BANDWIDTH_BOUND", "busiest_resource": "dma"})
    return pd.DataFrame(rows)


def test_marginal_gain_math_and_saturation():
    mg = opt.marginal_gains(synth(), {"lanes_k": "lanes"})
    first = mg.iloc[0]
    assert first["abs_gain"] == 90 and first["rel_gain"] == pytest.approx(0.9)
    assert first["gain_per_unit"] == pytest.approx(90 / 4) and first["gain_per_mm2"] == pytest.approx(90 / 0.2)
    assert list(mg["diminishing"]) == [False, True, True]
    sat = opt.saturation_points(mg)
    assert sat.iloc[0]["saturates_at"] == 8 and sat.iloc[0]["limited_by"] == "dma"


def test_pareto_front():
    df = pd.DataFrame({"perf": [1, 2, 3, 3, 2.5], "area": [1, 2, 3, 4, 3.5]})
    f = opt.pareto(df, objectives={"perf": "max", "area": "min"})
    assert list(f["pareto"]) == [True, True, True, False, False]
    g = opt.pareto(df, objectives={"perf": "max", "area": "min"}, constraints={"area": 2.5})
    assert len(g) == 2 and g["pareto"].all()


def test_area_model_provenance_and_units():
    a = opt.area_model(load_profile(CONFIGS / "silicaflux_v.yaml"))
    assert a["units"]["macs"] == 16 and a["units"]["sram_kib"] == 272
    assert a["parts"]["sram_mm2"] == pytest.approx(272 * 0.03073)
    assert a["provenance"] == "HYPOTHETICAL"           # per-unit logic coefficients are assumptions
