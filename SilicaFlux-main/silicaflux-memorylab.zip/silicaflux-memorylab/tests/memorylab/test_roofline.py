"""Analytical Roofline engine, tested independently of the event simulator."""
import math

import pytest
from hypothesis import given, settings, strategies as st

from memorylab.roofline import (Bound, LevelTraffic, MemoryLevel, concurrent_roofline, ConcurrentPart,
                                check_same_domain, classify_single, hierarchical_roofline, ridge_point,
                                roofline_ceiling)
from memorylab.units import (GB, OpConvention, OpCount, OpKind, Precision, Throughput, UnitMismatchError,
                             convert_count, parse_size)

G = 1e9


# ---------------------------------------------------------------- brief s.14 hand-calculated examples
def test_example_a_memory_bound():
    # 64 GOPS peak, 8 GB/s, I = 2 ops/B -> 16 GOPS, memory-bound
    assert roofline_ceiling(64 * G, 2.0, 8 * GB) == pytest.approx(16 * G)
    assert classify_single(64 * G, 2.0, 8 * GB) == Bound.BANDWIDTH_BOUND


def test_example_b_compute_bound():
    # 64 GOPS peak, 8 GB/s, I = 16 ops/B -> 64 GOPS, compute-bound
    assert roofline_ceiling(64 * G, 16.0, 8 * GB) == pytest.approx(64 * G)
    assert classify_single(64 * G, 16.0, 8 * GB) == Bound.COMPUTE_BOUND


def test_examples_via_hierarchical_api_with_units():
    peak = Throughput(64 * G, OpKind.INT_OP, Precision.INT32)
    lv = [MemoryLevel("dram", 8 * GB)]
    for ops_per_byte, exp, bound in ((2, 16 * G, Bound.BANDWIDTH_BOUND), (16, 64 * G, Bound.COMPUTE_BOUND)):
        w = OpCount(ops_per_byte * 1e6, OpKind.INT_OP, Precision.INT32)
        r = hierarchical_roofline(workload="ex", engine="e", work=w, peak=peak, levels=lv,
                                  traffic={"dram": LevelTraffic(1e6, 0)})
        assert r.ceiling == pytest.approx(exp)
        assert r.bound == bound
        assert r.levels[0].intensity == pytest.approx(ops_per_byte)


def test_ridge_point():
    assert ridge_point(64 * G, 8 * GB) == pytest.approx(8.0)


# ---------------------------------------------------------------- hierarchical semantics
def test_hierarchical_takes_minimum_not_sum():
    peak = Throughput(100 * G, OpKind.INT_OP, Precision.INT32)
    levels = [MemoryLevel("sram", 50 * GB), MemoryLevel("dram", 5 * GB)]
    w = OpCount(1e9, OpKind.INT_OP, Precision.INT32)
    tr = {"sram": LevelTraffic(1e8, 0), "dram": LevelTraffic(1e8, 0)}   # same bytes at both levels
    r = hierarchical_roofline(workload="w", engine="e", work=w, peak=peak, levels=levels, traffic=tr)
    # I = 10 ops/B at both; sram roof 500 G (> peak), dram roof 50 G -> 50 G; summing bandwidths would give 100+ G
    assert r.ceiling == pytest.approx(50 * G)
    assert r.binding == "dram"
    assert r.bound == Bound.BANDWIDTH_BOUND


def test_hierarchical_uses_per_level_traffic():
    peak = Throughput(100 * G, OpKind.INT_OP, Precision.INT32)
    levels = [MemoryLevel("l1", 40 * GB), MemoryLevel("dram", 4 * GB)]
    w = OpCount(1e9, OpKind.INT_OP, Precision.INT32)
    # reuse: l1 sees 10x more bytes than dram
    tr = {"l1": LevelTraffic(1e9, 0), "dram": LevelTraffic(1e7, 0)}
    r = hierarchical_roofline(workload="w", engine="e", work=w, peak=peak, levels=levels, traffic=tr)
    by = {x.level: x for x in r.levels}
    assert by["l1"].intensity == pytest.approx(1.0)
    assert by["dram"].intensity == pytest.approx(100.0)
    assert r.ceiling == pytest.approx(40 * G)    # l1 binds: 1 op/B x 40 GB/s
    assert r.binding == "l1"


def test_reads_and_writes_counted_once():
    tr = LevelTraffic(300, 100)
    assert tr.total == 400


def test_latency_bound_littles_law():
    peak = Throughput(10 * G, OpKind.INT_OP, Precision.INT32)
    # 10 GB/s peak link, but only 64 B in flight with 100 ns latency -> 0.64 GB/s
    lv = [MemoryLevel("dram", 10 * GB, latency_s=100e-9, max_inflight_bytes=64)]
    w = OpCount(1e6, OpKind.INT_OP, Precision.INT32)
    r = hierarchical_roofline(workload="rand", engine="cpu", work=w, peak=peak, levels=lv,
                              traffic={"dram": LevelTraffic(1e6, 0)})
    assert r.levels[0].effective_bandwidth_Bps == pytest.approx(0.64e9)
    assert r.bound == Bound.LATENCY_BOUND
    assert r.ceiling == pytest.approx(0.64e9)


def test_compute_wins_exact_ridge_tie():
    peak = Throughput(8 * G, OpKind.INT_OP, Precision.INT32)
    w = OpCount(8e6, OpKind.INT_OP, Precision.INT32)
    r = hierarchical_roofline(workload="t", engine="e", work=w, peak=peak, levels=[MemoryLevel("m", 1 * GB)],
                              traffic={"m": LevelTraffic(1e6, 0)})
    assert r.bound == Bound.COMPUTE_BOUND and r.ceiling == pytest.approx(8 * G)


def test_zero_traffic_level_does_not_bind():
    peak = Throughput(8 * G, OpKind.INT_OP, Precision.INT32)
    w = OpCount(1e6, OpKind.INT_OP, Precision.INT32)
    r = hierarchical_roofline(workload="t", engine="e", work=w, peak=peak, levels=[MemoryLevel("m", 1 * GB)],
                              traffic={"m": LevelTraffic(0, 0)})
    assert math.isinf(r.levels[0].intensity) and r.ceiling == pytest.approx(8 * G)


def test_missing_level_traffic_is_an_error():
    peak = Throughput(8 * G, OpKind.INT_OP, Precision.INT32)
    w = OpCount(1e6, OpKind.INT_OP, Precision.INT32)
    with pytest.raises(ValueError, match="no traffic"):
        hierarchical_roofline(workload="t", engine="e", work=w, peak=peak,
                              levels=[MemoryLevel("a", 1 * GB), MemoryLevel("b", 1 * GB)],
                              traffic={"a": LevelTraffic(1, 0)})


def test_unused_compute_fraction():
    peak = Throughput(64 * G, OpKind.INT_OP, Precision.INT32)
    w = OpCount(2e6, OpKind.INT_OP, Precision.INT32)
    r = hierarchical_roofline(workload="t", engine="e", work=w, peak=peak, levels=[MemoryLevel("m", 8 * GB)],
                              traffic={"m": LevelTraffic(1e6, 0)})
    assert r.unused_compute_fraction == pytest.approx(0.75)


# ---------------------------------------------------------------- units & conventions
def test_mac_to_ops_is_explicit_and_two_by_default():
    assert convert_count(10, OpKind.MAC, OpKind.INT_OP, Precision.INT8) == 20
    assert convert_count(10, OpKind.MAC, OpKind.INT_OP, Precision.INT8, OpConvention(1)) == 10
    assert convert_count(20, OpKind.INT_OP, OpKind.MAC, Precision.INT8) == 10


def test_int_and_float_never_interconvert():
    with pytest.raises(UnitMismatchError):
        convert_count(1, OpKind.INT_OP, OpKind.FLOP, Precision.INT8)
    with pytest.raises(UnitMismatchError):
        OpCount(1, OpKind.FLOP, Precision.INT8)
    with pytest.raises(UnitMismatchError):
        Throughput(1, OpKind.INT_OP, Precision.FP32)


def test_int8_tops_not_compared_with_fp32_flops():
    peak = Throughput(1e12, OpKind.FLOP, Precision.FP32)
    w = OpCount(1e9, OpKind.INT_OP, Precision.INT8)
    with pytest.raises(UnitMismatchError):
        hierarchical_roofline(workload="t", engine="e", work=w, peak=peak, levels=[MemoryLevel("m", 1e9)],
                              traffic={"m": LevelTraffic(1, 0)})


def test_precision_mismatch_rejected():
    peak = Throughput(1e12, OpKind.MAC, Precision.INT8)
    w = OpCount(1e9, OpKind.MAC, Precision.INT16)
    with pytest.raises(UnitMismatchError, match="precision"):
        hierarchical_roofline(workload="t", engine="e", work=w, peak=peak, levels=[MemoryLevel("m", 1e9)],
                              traffic={"m": LevelTraffic(1, 0)})


def test_mac_peak_vs_ops_workload_converts_consistently():
    peak = Throughput(16e9, OpKind.MAC, Precision.INT8)       # 16 GMAC/s = 32 GOPS
    w = OpCount(2e9, OpKind.INT_OP, Precision.INT8)           # 1 GMAC
    lv = [MemoryLevel("m", 1e12)]
    r1 = hierarchical_roofline(workload="t", engine="e", work=w, peak=peak, levels=lv,
                               traffic={"m": LevelTraffic(1, 0)})
    r2 = hierarchical_roofline(workload="t", engine="e", work=w, peak=peak, levels=lv,
                               traffic={"m": LevelTraffic(1, 0)}, kind=OpKind.INT_OP)
    assert r1.ceiling == pytest.approx(16e9) and r1.kind == OpKind.MAC
    assert r2.ceiling == pytest.approx(32e9) and r2.kind == OpKind.INT_OP
    assert r1.time_lower_bound_s == pytest.approx(r2.time_lower_bound_s)


def test_mixed_domains_cannot_share_one_plot():
    peak8 = Throughput(1e9, OpKind.MAC, Precision.INT8)
    peak32 = Throughput(1e9, OpKind.INT_OP, Precision.INT32)
    lv = [MemoryLevel("m", 1e9)]
    a = hierarchical_roofline(workload="a", engine="t", work=OpCount(1e6, OpKind.MAC, Precision.INT8),
                              peak=peak8, levels=lv, traffic={"m": LevelTraffic(1e3, 0)})
    b = hierarchical_roofline(workload="b", engine="v", work=OpCount(1e6, OpKind.INT_OP, Precision.INT32),
                              peak=peak32, levels=lv, traffic={"m": LevelTraffic(1e3, 0)})
    with pytest.raises(UnitMismatchError):
        check_same_domain([a, b])


def test_parse_size():
    assert parse_size("256KiB") == 262144 and parse_size("1MiB") == 1048576 and parse_size(64) == 64
    with pytest.raises(ValueError):
        parse_size("12 parsecs")


def test_invalid_inputs():
    with pytest.raises(ValueError):
        roofline_ceiling(0, 1, 1)
    with pytest.raises(ValueError):
        roofline_ceiling(1, -1, 1)
    with pytest.raises(ValueError):
        MemoryLevel("x", 0)
    with pytest.raises(ValueError):
        MemoryLevel("x", 1, latency_s=1e-9)       # latency without in-flight bytes
    with pytest.raises(ValueError):
        LevelTraffic(-1, 0)


def test_concurrent_roofline_shares_bandwidth():
    lv = [MemoryLevel("sram", 10e9)]
    a = ConcurrentPart("a", "vector", OpCount(1e9, OpKind.INT_OP, Precision.INT32),
                       Throughput(20e9, OpKind.INT_OP, Precision.INT32), {"sram": LevelTraffic(5e8, 0)})
    b = ConcurrentPart("b", "tensor", OpCount(1e9, OpKind.MAC, Precision.INT8),
                       Throughput(100e9, OpKind.MAC, Precision.INT8), {"sram": LevelTraffic(5e8, 0)})
    r = concurrent_roofline([a, b], lv)
    assert r["makespan_lower_bound_s"] == pytest.approx(0.1)      # 1 GB shared over 10 GB/s
    assert r["binding"] == "level:sram"
    with pytest.raises(ValueError):
        concurrent_roofline([a, a], lv)


# ---------------------------------------------------------------- property-based
pos = st.floats(min_value=1e-3, max_value=1e15, allow_nan=False, allow_infinity=False)


@settings(max_examples=300, deadline=None)
@given(peak=pos, intensity=st.floats(min_value=0, max_value=1e6), bw=pos)
def test_ceiling_bounded_by_peak_and_bandwidth(peak, intensity, bw):
    c = roofline_ceiling(peak, intensity, bw)
    assert c <= peak * (1 + 1e-12)
    assert c <= intensity * bw * (1 + 1e-12) + 1e-300
    assert c >= 0


@settings(max_examples=200, deadline=None)
@given(peak=pos, i1=st.floats(min_value=1e-6, max_value=1e5), i2=st.floats(min_value=1e-6, max_value=1e5), bw=pos)
def test_ceiling_monotonic_in_intensity(peak, i1, i2, bw):
    lo, hi = sorted((i1, i2))
    assert roofline_ceiling(peak, lo, bw) <= roofline_ceiling(peak, hi, bw) * (1 + 1e-12)


@settings(max_examples=200, deadline=None)
@given(work=st.floats(min_value=1, max_value=1e12), peak=st.floats(min_value=1e3, max_value=1e13),
       q=st.lists(st.floats(min_value=0, max_value=1e10), min_size=1, max_size=4),
       b=st.lists(st.floats(min_value=1e3, max_value=1e12), min_size=4, max_size=4))
def test_hierarchical_equals_min_of_roofs(work, peak, q, b):
    levels = [MemoryLevel(f"l{i}", b[i]) for i in range(len(q))]
    tr = {f"l{i}": LevelTraffic(q[i], 0) for i in range(len(q))}
    r = hierarchical_roofline(workload="p", engine="e", work=OpCount(work, OpKind.INT_OP, Precision.INT32),
                              peak=Throughput(peak, OpKind.INT_OP, Precision.INT32), levels=levels, traffic=tr)
    expect = min([peak] + [(work / q[i]) * b[i] for i in range(len(q)) if q[i] > 0])
    assert r.ceiling == pytest.approx(expect, rel=1e-9)
    assert r.ceiling <= peak * (1 + 1e-12)
