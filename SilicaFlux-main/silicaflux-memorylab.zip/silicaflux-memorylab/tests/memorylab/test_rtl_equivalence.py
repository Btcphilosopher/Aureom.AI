"""Python models vs real RTL (Verilator / Icarus).  Skipped when tools or the repository are absent.

These tests are the evidence behind every "matches the RTL" statement in the reports; they
cover only the configurations listed here.
"""
import os
from pathlib import Path

import pytest

from memorylab import bankbench as bb, rtl_integration as ri, trace_import as ti
from memorylab.sram import BankCtrlConfig

WORK = Path(os.environ.get("MEMORYLAB_RTL_WORK", Path(__file__).resolve().parents[2] / "build" / "rtl_tests"))


def _sramlib():
    try:
        return ri.locate_sramlib(build_dir=WORK)
    except ri.RtlUnavailable as e:
        pytest.skip(str(e))


need_vl = pytest.mark.skipif(not ri.simulator_available("verilator"), reason="verilator not installed")
need_iv = pytest.mark.skipif(not ri.simulator_available("icarus"), reason="icarus not installed")

CASES = [(BankCtrlConfig(4, 4, 32, 256, 1), "random", 30), (BankCtrlConfig(4, 2, 32, 256, 2), "mixed", 20),
         (BankCtrlConfig(3, 4, 32, 256, 1, arbitration="fixed"), "cpu", 0),
         (BankCtrlConfig(4, 4, 32, 256, 2, rsp_fifo_depth=1), "random", 25),
         (BankCtrlConfig(4, 4, 32, 256, 1, write_ack=False), "dma", 15)]


@need_vl
@pytest.mark.parametrize("cfg,wl,bp", CASES, ids=lambda x: str(x)[:40] if not isinstance(x, BankCtrlConfig) else
                         f"NM{x.num_masters}NB{x.num_banks}L{x.read_latency}{x.arbitration}F{x.rsp_fifo_depth}W{int(x.write_ack)}")
def test_bank_controller_matches_verilator(cfg, wl, bp):
    root = _sramlib()
    stim = bb.generate(wl, cfg, 200, 31, err_pct=3 if wl == "random" else 0)
    py = bb.run(cfg, stim, bp_pct=bp, seed=31)
    rtl = ri.run_rtl_bank_trace(cfg, stim, work=WORK, root=root, bp_pct=bp, bp_seed=31)
    c = ri.compare_traces(py, rtl)
    assert c["equivalent"], c["mismatches"]


@need_iv
def test_bank_controller_matches_icarus_and_vcd_decoder():
    root = _sramlib()
    cfg = BankCtrlConfig(4, 4, 32, 256, 1)
    stim = bb.generate("mixed", cfg, 120, 9)
    py = bb.run(cfg, stim, bp_pct=15, seed=9)
    vcd = WORK / "bank.vcd"
    rtl = ri.run_rtl_bank_trace(cfg, stim, work=WORK, root=root, bp_pct=15, bp_seed=9, sim="icarus", vcd=vcd)
    assert ri.compare_traces(py, rtl)["equivalent"]
    # decode master 0's request handshakes from the raw VCD and compare with the harness log
    df = ti.decode_handshake(vcd, clock="clk", valid="req_valid", ready="req_ready", valid_bit=0, ready_bit=0,
                             fields={"req_id": "req_id"})
    ids = [(v & 0xFFFF) for v in df["req_id"]]
    assert ids == [a[2] for a in rtl.accepts if a[1] == 0]


@need_vl
def test_sfv_tile_engine_latency_matches_models():
    try:
        res = ri.run_tile_latency(WORK)
    except ri.RtlUnavailable as e:
        pytest.skip(str(e))
    assert len(res["rows"]) >= 50
    assert res["all_exact"], [r for r in res["rows"] if r["abs_error_cycles"]]
    assert all(r["err_flag"] == 0 for r in res["rows"])
