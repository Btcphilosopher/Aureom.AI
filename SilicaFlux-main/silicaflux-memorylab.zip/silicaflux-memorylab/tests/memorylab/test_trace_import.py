"""Trace / counter / structured-result import and the VCD handshake decoder."""
import json

import pandas as pd
import pytest

from memorylab import bankbench as bb, trace_import as ti
from memorylab.sram import BankCtrlConfig


def test_csv_and_json_roundtrip(tmp_path):
    rows = [{"cycle": 0, "event": "ACCEPT", "master": 0, "id": 1}, {"cycle": 2, "event": "RESPONSE", "master": 0, "id": 1},
            {"cycle": 1, "event": "ACCEPT", "master": 0, "id": 2}, {"cycle": 3, "event": "RESPONSE", "master": 0, "id": 2}]
    pd.DataFrame(rows).to_csv(tmp_path / "t.csv", index=False)
    (tmp_path / "t.json").write_text(json.dumps({"transactions": rows}))
    for f in ("t.csv", "t.json"):
        df = ti.read_trace(tmp_path / f)
        m = ti.trace_metrics(df)
        assert m["accepted"] == 2 and m["avg_latency_cycles"] == 2 and m["problems"] == []


def test_time_ns_requires_clock(tmp_path):
    pd.DataFrame([{"time_ns": 10, "event": "ACCEPT", "master": 0, "id": 1}]).to_csv(tmp_path / "t.csv", index=False)
    with pytest.raises(ti.TraceFormatError, match="clock"):
        ti.read_trace_csv(tmp_path / "t.csv")
    df = ti.read_trace_csv(tmp_path / "t.csv", clock_hz=200e6)
    assert df["cycle"].iloc[0] == 2


def test_bad_traces_detected(tmp_path):
    pd.DataFrame([{"cycle": 0, "event": "TELEPORT", "master": 0, "id": 1}]).to_csv(tmp_path / "a.csv", index=False)
    with pytest.raises(ti.TraceFormatError, match="unknown trace events"):
        ti.read_trace_csv(tmp_path / "a.csv")
    rows = [{"cycle": 5, "event": "ACCEPT", "master": 0, "id": 1}, {"cycle": 3, "event": "RESPONSE", "master": 0, "id": 1},
            {"cycle": 6, "event": "ACCEPT", "master": 0, "id": 1}]
    m = ti.trace_metrics(pd.DataFrame(rows))
    assert any("negative" in p for p in m["problems"]) and any("duplicated" in p for p in m["problems"])
    with pytest.raises(ti.TraceFormatError):
        ti.read_trace(tmp_path / "x.vcd")
    with pytest.raises(ti.TraceFormatError, match="not found"):
        ti.read_trace_csv(tmp_path / "missing.csv")


def test_model_trace_metrics_match_model_stats():
    cfg = BankCtrlConfig(4, 4, 32, 64, 2)
    r = bb.run(cfg, bb.generate("random", cfg, 100, 4), bp_pct=10, seed=4)
    m = ti.trace_metrics(ti.from_bankbench(r))
    assert m["accepted"] == r["stats"]["accepted"] and m["problems"] == []
    assert m["avg_latency_cycles"] == pytest.approx(r["stats"]["avg_latency_cycles"])


def test_counters(tmp_path):
    (tmp_path / "c.json").write_text(json.dumps({"cycles": 100, "stalls": 7, "name": "x", "bad": float("nan")}))
    assert ti.read_counters(tmp_path / "c.json") == {"cycles": 100.0, "stalls": 7.0}


VCD = """$timescale 1ns $end
$scope module tb $end
$var wire 1 ! clk $end
$var wire 2 " valid [1:0] $end
$var wire 1 # ready $end
$var wire 8 $ data [7:0] $end
$upscope $end
$enddefinitions $end
#0
0!
b00 "
1#
b0 $
#5
1!
#7
b01 "
b101 $
#10
0!
#15
1!
#17
b00 "
#20
0!
#25
1!
"""


def test_vcd_decoder_samples_before_edge(tmp_path):
    p = tmp_path / "w.vcd"
    p.write_text(VCD)
    df = ti.decode_handshake(p, clock="clk", valid="valid", ready="ready", fields={"data": "data"}, valid_bit=0)
    assert list(df["time"]) == [15] and list(df["data"]) == [5]      # valid set at 7 -> sampled at the 15 edge
    v = ti.Vcd(p)
    assert v.rising_edges("clk") == [5, 15, 25]
    with pytest.raises(ti.TraceFormatError):
        v.signal("nope")
