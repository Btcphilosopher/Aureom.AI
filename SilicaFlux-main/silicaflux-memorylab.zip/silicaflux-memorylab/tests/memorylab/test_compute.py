"""CPU / vector / tensor peak and workload-dependent models."""
import math

import pytest

from memorylab.compute import (CpuModel, InstructionMix, TensorModel, UnsupportedConfiguration, VectorModel)
from memorylab.units import OpKind, Precision


def sfv_vector(f=50e6):
    return VectorModel("ve", lanes=4, freq_hz=f, ldst_bytes_per_cycle=16, fixed_overhead_cycles=3)


def sfv_tensor(f=50e6):
    return TensorModel("te", rows=4, cols=4, freq_hz=f, operand_bytes_per_cycle=4,
                       writeback_bytes_per_cycle=16, fixed_overhead_cycles=3)


def golden_ve_cycles(op, n, bscalar, wres, lanes=4):
    """Re-statement of SilicaFlux-V tb/models/sfv_golden.py ve_cycles (documented RTL formula)."""
    if n == 0:
        return 2
    b = math.ceil(n / lanes)
    dot = op == "dot"
    p = (1 if bscalar else 2) if dot else (2 if bscalar else 3)
    return 3 + b * p + (1 if dot and wres else 0)


@pytest.mark.parametrize("n", [0, 1, 3, 4, 5, 16, 17, 100, 1023, 4096])
@pytest.mark.parametrize("op,bscalar", [("add", False), ("add", True), ("dot", False), ("dot", True)])
@pytest.mark.parametrize("wres", [False, True])
def test_vector_model_reproduces_sfv_formula(n, op, bscalar, wres):
    ve = sfv_vector()
    cls = ("dot_vs" if bscalar else "dot_vv") if op == "dot" else ("vs" if bscalar else "vv")
    assert ve.command_cycles(cls, n, wres=wres) == golden_ve_cycles(op, n, bscalar, wres)


@pytest.mark.parametrize("k", [1, 2, 4, 16, 255, 1024])
@pytest.mark.parametrize("wb", [False, True])
def test_tensor_model_reproduces_sfv_formula(k, wb):
    te = sfv_tensor()
    assert te.tile(k, Precision.INT8, writeback=wb)["cycles"] == 3 + 2 * k + (4 if wb else 0)


def test_tensor_sustains_8_mac_per_cycle_not_16():
    te = sfv_tensor()
    assert te.peak(OpKind.MAC, Precision.INT8).value == pytest.approx(16 * 50e6)      # theoretical
    big = te.tile(1024, Precision.INT8, writeback=False)
    sustained = big["macs"] / big["cycles"]
    assert sustained == pytest.approx(8.0, rel=0.01)                                  # operand-port bound


def test_tensor_doubling_operand_port_doubles_throughput():
    te2 = TensorModel("te2", 4, 4, 50e6, operand_bytes_per_cycle=8, fixed_overhead_cycles=3)
    big = te2.tile(1024, Precision.INT8, writeback=False)
    assert big["macs"] / big["cycles"] == pytest.approx(16.0, rel=0.01)


def test_tensor_breakdown_sums_to_cycles():
    te = sfv_tensor()
    for m, n, k in [(4, 4, 4), (5, 7, 3), (64, 64, 64), (17, 3, 2000)]:
        r = te.gemm(m, n, k, Precision.INT8)
        total = r["ideal_cycles"] + r["padding_loss_cycles"] + r["operand_stall"] + r["overhead"] + r["writeback"]
        assert total == pytest.approx(r["cycles"])
        assert r["utilisation"] <= 1.0 + 1e-12
        assert r["achieved_mac_per_s"] <= r["peak_mac_per_s"] * (1 + 1e-12)


def test_small_gemm_is_overhead_dominated():
    r = sfv_tensor().gemm(4, 4, 4, Precision.INT8)
    assert r["cycles"] == 3 + 8 + 4
    assert r["utilisation"] < 0.3


def test_tile_padding_loss():
    r = sfv_tensor().gemm(5, 5, 16, Precision.INT8)          # 4 tiles for 25 outputs
    assert r["padded_macs"] == 4 * 16 * 16
    assert r["padding_loss_cycles"] > 0


def test_k_larger_than_max_k_is_split():
    te = sfv_tensor()
    r = te.gemm(4, 4, 2500, Precision.INT8)
    assert r["commands"] == 3
    assert r["cycles"] == (3 + 2 * 1024) * 2 + (3 + 2 * 452 + 4)


def test_tensor_unsupported_precision():
    with pytest.raises(UnsupportedConfiguration):
        sfv_tensor().peak(OpKind.MAC, Precision.FP16)
    with pytest.raises(UnsupportedConfiguration):
        sfv_tensor().tile(0, Precision.INT8)


def test_vector_breakdown_sums_and_tail():
    ve = sfv_vector()
    r = ve.command("vv", 5)
    assert r["beats"] == 2 and r["tail"] == pytest.approx(2 - 5 / 4)
    total = r["overhead"] + r["ideal"] + r["tail"] + r["memory_stall"] + r["dependency"] + r["conflict"] + r["writeback"]
    assert total == pytest.approx(r["cycles"])


def test_vector_misalignment_rejected_on_sfv():
    with pytest.raises(UnsupportedConfiguration):
        sfv_vector().command("vv", 16, aligned=False)
    ve = VectorModel("g", 4, 1e8, misaligned_extra_beats=1)
    assert ve.command("vv", 16, aligned=False)["beats"] == 5


def test_vector_peak_kinds():
    ve = sfv_vector(200e6)
    assert ve.peak(OpKind.INT_OP, Precision.INT32).value == pytest.approx(800e6)
    assert ve.peak(OpKind.MAC, Precision.INT32).value == pytest.approx(800e6)
    with pytest.raises(UnsupportedConfiguration):
        ve.peak(OpKind.INT_OP, Precision.INT8)


def test_more_lanes_without_more_port_bandwidth_does_not_help():
    narrow = VectorModel("a", 4, 1e8, ldst_bytes_per_cycle=16)
    wide = VectorModel("b", 8, 1e8, ldst_bytes_per_cycle=16)
    assert wide.command_cycles("vv", 4096) == pytest.approx(narrow.command_cycles("vv", 4096))


def cpu():
    return CpuModel("cpu", 1, 50e6, cpi={"alu": 1, "load": 2, "store": 2, "branch_taken": 3, "mul_sw": 35})


def test_cpu_peak_and_estimate():
    c = cpu()
    assert c.peak(OpKind.INT_OP, Precision.INT32).value == pytest.approx(50e6)
    assert c.peak(OpKind.MAC, Precision.INT32).value == pytest.approx(50e6 / 36)
    mix = InstructionMix({"load": 100, "alu": 100}, useful_ops=100, useful_kind=OpKind.INT_OP,
                         precision=Precision.INT32)
    e = c.estimate(mix)
    assert e["cycles"] == 300 and e["utilisation"] == pytest.approx(1 / 3)
    with pytest.raises(UnsupportedConfiguration):
        c.peak(OpKind.FLOP, Precision.FP32)


def test_cpu_amdahl():
    c = CpuModel("cpu", 4, 1e8, cpi={"alu": 1})
    mix = InstructionMix({"alu": 1000}, 1000, OpKind.INT_OP, Precision.INT32, parallel_fraction=0.5)
    assert c.estimate(mix)["cycles"] == pytest.approx(500 + 125)


def test_cpu_missing_cpi():
    with pytest.raises(UnsupportedConfiguration):
        cpu().estimate(InstructionMix({"div": 1}, 1, OpKind.INT_OP, Precision.INT32))
