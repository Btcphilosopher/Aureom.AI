"""Discrete-event kernel: ordering, determinism, units, limits, deadlock detection."""
import pytest

from memorylab.event_engine import (FS_PER_S, PRIO_ISSUE, PRIO_TICK, ClockDomain, DeadlockError, EventEngine,
                                    LimitExceeded, Trace, Transaction)


def test_ordering_time_priority_sequence():
    e = EventEngine()
    seen = []
    e.schedule(10, lambda: seen.append("t10-p10-a"), PRIO_ISSUE)
    e.schedule(10, lambda: seen.append("t10-p20"), PRIO_TICK)
    e.schedule(10, lambda: seen.append("t10-p10-b"), PRIO_ISSUE)
    e.schedule(5, lambda: seen.append("t5"))
    e.run()
    assert seen == ["t5", "t10-p10-a", "t10-p10-b", "t10-p20"]


def test_no_negative_delay_or_past():
    e = EventEngine()
    with pytest.raises(ValueError):
        e.schedule(-1, lambda: None)
    e.schedule(100, lambda: None)
    e.run()
    with pytest.raises(ValueError):
        e.schedule_at(50, lambda: None)
    with pytest.raises(TypeError):
        e.schedule(1.5, lambda: None)


def test_clock_domain_conversion():
    c = ClockDomain("c", 200e6)
    assert c.period_fs == 5_000_000          # 5 ns
    assert c.cycles(3) == 15_000_000
    assert c.to_seconds(200e6) == pytest.approx(1.0)
    assert c.next_edge(0) == 0 and c.next_edge(1) == 5_000_000
    assert c.next_edge(5_000_000, strictly_after=True) == 10_000_000
    with pytest.raises(ValueError):
        c.cycles(-1)
    with pytest.raises(ValueError):
        c.cycles(0.5)
    odd = ClockDomain("odd", 3e9)
    assert odd.quantisation_error < 1e-5


def test_two_clock_domains_interleave_exactly():
    e = EventEngine()
    a, b = ClockDomain("a", 100e6), ClockDomain("b", 250e6)
    ta, tb = [], []
    for k in range(5):
        e.schedule_at(a.edge(k), lambda k=k: ta.append(e.now))
        e.schedule_at(b.edge(k), lambda k=k: tb.append(e.now))
    e.run()
    assert ta == [k * 10 ** 7 for k in range(5)]
    assert tb == [k * 4 * 10 ** 6 for k in range(5)]
    assert FS_PER_S // 10 ** 7 == 100_000_000


def test_event_limit_and_time_limit():
    e = EventEngine(max_events=10)

    def loop():
        e.schedule(1, loop)
    e.schedule(0, loop)
    with pytest.raises(LimitExceeded):
        e.run()
    e2 = EventEngine(max_time_fs=100)
    e2.schedule(1000, lambda: None)
    with pytest.raises(LimitExceeded):
        e2.run()


class Stuck:
    name = "stuck_component"

    def outstanding(self):
        return 3


def test_deadlock_detection():
    e = EventEngine()
    e.register(Stuck())
    with pytest.raises(DeadlockError, match="stuck_component"):
        e.run()


def test_transaction_validation():
    with pytest.raises(ValueError):
        Transaction(1, "m", "X", 0, 4, 0)
    with pytest.raises(ValueError):
        Transaction(1, "m", "R", 0, 0, 0)        # no zero-byte transfers


def test_trace_invariants_detect_problems():
    tr = Trace()
    t = Transaction(1, "m", "R", 0, 4, 0)
    tr.log(10, "COMPLETE", "x", t)
    assert any("without acceptance" in s for s in tr.check_invariants())
    tr2 = Trace()
    tr2.log(10, "ACCEPT", "x", t)
    assert any("lost" in s for s in tr2.check_invariants())
    tr3 = Trace()
    tr3.log(10, "ACCEPT", "x", t)
    tr3.log(20, "COMPLETE", "x", t)
    tr3.log(30, "COMPLETE", "x", t)
    assert any("duplicate" in s for s in tr3.check_invariants())


def test_ids_monotonic_unique():
    e = EventEngine()
    ids = [e.new_id() for _ in range(100)]
    assert ids == sorted(set(ids))
