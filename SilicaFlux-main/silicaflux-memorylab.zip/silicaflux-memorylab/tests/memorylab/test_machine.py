"""Profiles -> engines -> hierarchical Roofline; cross-checks between analytical models."""
import glob
from pathlib import Path

import pytest

from conftest import CONFIGS
from memorylab import machine, workloads as wl
from memorylab.compute import UnsupportedConfiguration
from memorylab.config import ConfigError, load_profile, profile_from_dict, read_profile_dict
from memorylab.units import KiB, Precision

PROFILES = sorted(Path(x).stem for x in glob.glob(str(CONFIGS / "silicaflux_*.yaml")))
TENSOR_WL = [wl.gemm(64, 64, 64, "blocked"), wl.gemm(16, 16, 16, "scratchpad_resident"),
             wl.gemm(4, 4, 4, "scratchpad_resident"), wl.gemm(128, 64, 256, "double_buffered"),
             wl.conv2d(16, 16, 8, 16)]
VECTOR_WL = [wl.vector_add(4096), wl.axpy(4096), wl.dot(4096), wl.gemv(32, 64), wl.fir(1024, 8, precision=Precision.INT32)]


def engine_side_ceiling(r):
    port = [lv["ceiling"] for lv in r["levels"] if lv["level"] in r["level_details"]
            and r["level_details"][lv["level"]]["capacity_bytes"] is None]
    return min([r["peak"]] + port)


def test_all_profiles_load():
    assert {"silicaflux_v", "silicaflux_v_release1_rtl", "silicaflux_130nm_demo", "silicaflux_65nm_demo",
            "silicaflux_full"} <= set(PROFILES)
    for n in PROFILES:
        p = load_profile(CONFIGS / f"{n}.yaml")
        assert p.f > 0


@pytest.mark.parametrize("prof", PROFILES)
@pytest.mark.parametrize("w", TENSOR_WL, ids=lambda w: w.name)
def test_tensor_ceiling_upper_bounds_engine_model(prof, w):
    p = load_profile(CONFIGS / f"{prof}.yaml")
    try:
        r = machine.analyse(p, w, "tensor")
    except wl.InfeasibleStrategy:
        pytest.skip("strategy infeasible for this capacity")
    achieved = w.macs / r["engine_model"]["engine_time_s"]
    # the engine model assumes resident operands, so compare with the engine-side roofs only
    assert engine_side_ceiling(r) >= achieved * (1 - 1e-9), (engine_side_ceiling(r), achieved)
    # adding outer levels can only lower the bound
    assert r["ceiling"] <= engine_side_ceiling(r) * (1 + 1e-12)
    assert r["ceiling"] <= r["peak"] * (1 + 1e-12)


@pytest.mark.parametrize("prof", PROFILES)
@pytest.mark.parametrize("w", VECTOR_WL, ids=lambda w: w.name)
def test_vector_ceiling_upper_bounds_engine_model(prof, w):
    p = load_profile(CONFIGS / f"{prof}.yaml")
    r = machine.analyse(p, w, "vector")
    achieved = w.arithmetic_ops / r["engine_model"]["engine_time_s"]
    assert engine_side_ceiling(r) >= achieved * (1 - 1e-9)
    assert r["ceiling"] <= engine_side_ceiling(r) * (1 + 1e-12)


def test_release1_tensor_port_ceiling_is_8_mac_per_cycle():
    p = load_profile(CONFIGS / "silicaflux_v_release1_rtl.yaml")
    r = machine.analyse(p, wl.gemm(4, 4, 1024, "scratchpad_resident"), "tensor")
    port = next(x for x in r["levels"] if x["level"] == "te_operand_port")
    assert port["ceiling"] / p.f == pytest.approx(8.0, rel=1e-6)
    assert r["peak"] / p.f == pytest.approx(16.0)


def test_release1_tspm_fill_by_cpu_copy():
    p = load_profile(CONFIGS / "silicaflux_v_release1_rtl.yaml")
    bw = machine.bw_cpu_copy(p)
    assert bw.Bps / p.f == pytest.approx(4 / 5.25)
    assert bw.provenance == "VERIFIED_REPO"


def test_hypothetical_inputs_make_derived_hypothetical():
    p = load_profile(CONFIGS / "silicaflux_v.yaml")      # 200 MHz is hypothetical
    for eng in ("tensor", "vector", "cpu"):
        for _, m, _ in machine.memory_levels(p, eng):
            assert m.provenance == "HYPOTHETICAL"


def test_extends_and_override_provenance():
    d = read_profile_dict(CONFIGS / "silicaflux_v_release1_rtl.yaml")
    sram = next(m for m in d["memories"] if m["name"] == "sram")
    assert sram["capacity"]["value"] == "128KiB" and sram["capacity"]["provenance"] == "VERIFIED_REPO"
    assert sram["banks"]["value"] == 4                  # inherited
    assert d.get("dma") is None


def test_unknown_engine_and_unsupported_mapping():
    p = load_profile(CONFIGS / "silicaflux_v.yaml")
    with pytest.raises(UnsupportedConfiguration):
        machine.analyse(p, wl.cpu_sequential(100), "tensor")
    with pytest.raises(UnsupportedConfiguration):
        machine.analyse(p, wl.dma_copy(100))
    with pytest.raises(UnsupportedConfiguration):
        machine.analyse(p, wl.vector_add(100, precision=__import__("memorylab.units", fromlist=["Precision"]).Precision.INT8), "vector")


def test_invalid_profiles_give_meaningful_errors(tmp_path):
    with pytest.raises(ConfigError, match="not found"):
        load_profile(tmp_path / "nope.yaml")
    bad = tmp_path / "bad.yaml"
    bad.write_text("name: x\nclock: {frequency_hz: 0}\nmemories: []\ninterconnect: {width_bits: 32}\n")
    with pytest.raises(ConfigError, match="frequency"):
        load_profile(bad)
    bad.write_text("name: x\nclock: {frequency_hz: 1e8}\nmemories: [{name: a, kind: sram, capacity: 1KiB, "
                   "read_latency_cycles: 0}]\ninterconnect: {width_bits: 32}\n")
    with pytest.raises(ConfigError, match="zero-cycle"):
        load_profile(bad)
    bad.write_text("name: x\nclock: {frequency_hz: 1e8}\nmemories: [{name: a, kind: sram, capacity: 1KiB}]\n"
                   "interconnect: {width_bits: 32}\nroofline: {tensor: [{name: l, capacity_of: [zz], limits: "
                   "[{via: interconnect}]}]}\n")
    with pytest.raises(ConfigError, match="unknown memory"):
        load_profile(bad)
    bad.write_text("name: x\nclock: {frequency_hz: 1e8}\nmemories: [{name: a, kind: sram, capacity: 1KiB}]\n"
                   "interconnect: {width_bits: 32}\nbogus_key: 1\n")
    with pytest.raises(ConfigError, match="bogus_key"):
        load_profile(bad)


def test_plain_values_default_to_hypothetical():
    p = profile_from_dict({"name": "x", "clock": {"frequency_hz": 1e8},
                           "memories": [{"name": "a", "kind": "sram", "capacity": "1KiB"}],
                           "interconnect": {"width_bits": 32}})
    assert p.clock.frequency_hz.provenance.value == "HYPOTHETICAL"


def test_int16_fir_rejected_on_int32_only_vector_engine():
    p = load_profile(CONFIGS / "silicaflux_v.yaml")
    with pytest.raises(UnsupportedConfiguration, match="int16"):
        machine.analyse(p, wl.fir(1024, 8), "vector")
