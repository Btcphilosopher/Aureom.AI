// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1: device discovery, queue memory, start/quiesce and reset primitives.
 * Everything here talks to the device only through sdev->ops (PCI or mock).
 */
#include <linux/bitfield.h>
#include <linux/dma-mapping.h>
#include <linux/iopoll.h>
#include <linux/log2.h>
#include <linux/minmax.h>
#include <linux/overflow.h>
#include <linux/sizes.h>

#include "sfg1_drv.h"

static int sfg1_wait_ready(struct sfg1_device *sdev, unsigned int timeout_ms)
{
	u32 st;
	int ret;

	ret = read_poll_timeout(sfg1_rd, st,
				st == SFG1_ALL_ONES ||
				((st & SFG1_STATUS_READY) && !(st & SFG1_STATUS_RESET_ACTIVE)),
				100, (u64)timeout_ms * 1000, false, sdev, SFG1_REG_STATUS);
	if (ret)
		return ret;
	if (st == SFG1_ALL_ONES) {
		WRITE_ONCE(sdev->hw_gone, true);
		return -ENODEV;
	}
	if (st & SFG1_STATUS_FATAL)
		return -EIO;
	return 0;
}

/*
 * Device discovery. Every value is sanity-checked before it is trusted: a
 * wrong or hostile register file must fail probe, not corrupt memory later.
 */
int sfg1_hw_discover(struct sfg1_device *sdev)
{
	struct device *dev = sdev->dev;
	u32 id, ver, caps, lim0, lim1, lo, hi, win_kib, probe;
	u64 need;
	int ret;

	id = sfg1_rd(sdev, SFG1_REG_ID);
	if (id == SFG1_ALL_ONES) {
		dev_err(dev, "device does not respond (all-ones read)\n");
		return -ENODEV;
	}
	if (id != SFG1_CHIP_ID) {
		dev_err(dev, "unexpected chip id %#x (want %#x)\n", id, SFG1_CHIP_ID);
		return -ENODEV;
	}

	ver = sfg1_rd(sdev, SFG1_REG_HW_VERSION);
	if ((u32)FIELD_GET(GENMASK(31, 16), ver) != SFG1_HW_VERSION_MAJOR) {
		dev_err(dev, "unsupported hardware interface version %u.%u.%u\n",
			(u32)FIELD_GET(GENMASK(31, 16), ver), (u32)FIELD_GET(GENMASK(15, 8), ver),
			(u32)FIELD_GET(GENMASK(7, 0), ver));
		return -ENODEV;
	}

	ret = sfg1_wait_ready(sdev, 1000);
	if (ret) {
		dev_err(dev, "device not ready (%d)\n", ret);
		return ret;
	}

	caps = sfg1_rd(sdev, SFG1_REG_CAPS);
	if ((caps & SFG1_CAPS_REQUIRED) != SFG1_CAPS_REQUIRED) {
		dev_err(dev, "missing mandatory capabilities (caps=%#x)\n", caps);
		return -ENODEV;
	}

	lim0 = sfg1_rd(sdev, SFG1_REG_LIMITS0);
	lim1 = sfg1_rd(sdev, SFG1_REG_LIMITS1);
	lo = sfg1_rd(sdev, SFG1_REG_DEVMEM_LO);
	hi = sfg1_rd(sdev, SFG1_REG_DEVMEM_HI);

	sdev->max_ctx = FIELD_GET(SFG1_LIMITS0_MAX_CTX, lim0);
	sdev->max_qent = FIELD_GET(SFG1_LIMITS0_MAX_QENT, lim0);
	sdev->dma_bits = FIELD_GET(SFG1_LIMITS1_DMA_BITS, lim1);
	win_kib = FIELD_GET(SFG1_LIMITS1_CTX_WIN_KIB, lim1);
	sdev->devmem_size = ((u64)hi << 32) | lo;

	if (!sdev->max_ctx || sdev->max_ctx > SFG1_MAX_CTX_LIMIT) {
		dev_err(dev, "invalid MAX_CTX %u\n", sdev->max_ctx);
		return -EINVAL;
	}
	if (!is_power_of_2(sdev->max_qent) || sdev->max_qent < SFG1_QUEUE_ENTRIES_MIN ||
	    sdev->max_qent > SFG1_QUEUE_ENTRIES_MAX) {
		dev_err(dev, "invalid MAX_QUEUE_ENTRIES %u\n", sdev->max_qent);
		return -EINVAL;
	}
	if (sdev->dma_bits < 32 || sdev->dma_bits > 64) {
		dev_err(dev, "invalid DMA_ADDR_BITS %u\n", sdev->dma_bits);
		return -EINVAL;
	}
	if (!win_kib) {
		dev_err(dev, "invalid CTX_WIN_KIB 0\n");
		return -EINVAL;
	}
	sdev->ctx_win_size = win_kib * SZ_1K;
	if (check_mul_overflow((u64)sdev->max_ctx, (u64)sdev->ctx_win_size, &need) ||
	    sdev->devmem_size < need) {
		dev_err(dev, "device memory %llu too small for %u windows of %u bytes\n",
			sdev->devmem_size, sdev->max_ctx, sdev->ctx_win_size);
		return -EINVAL;
	}

	/* register-file sanity: SCRATCH must hold two complementary patterns */
	sfg1_wr(sdev, SFG1_REG_SCRATCH, 0xa5a5a5a5);
	probe = sfg1_rd(sdev, SFG1_REG_SCRATCH);
	sfg1_wr(sdev, SFG1_REG_SCRATCH, 0x5a5a5a5a);
	if (probe != 0xa5a5a5a5 || sfg1_rd(sdev, SFG1_REG_SCRATCH) != 0x5a5a5a5a) {
		dev_err(dev, "register self-test failed\n");
		return -EIO;
	}
	sfg1_wr(sdev, SFG1_REG_SCRATCH, 0);

	sdev->hw_version = ver;
	sdev->caps = caps;
	dev_info(dev, "SF-G1 hw %u.%u.%u caps=%#x ctx=%u x %u KiB devmem=%llu MiB maxq=%u dma=%u bits\n",
		 (u32)FIELD_GET(GENMASK(31, 16), ver), (u32)FIELD_GET(GENMASK(15, 8), ver),
		 (u32)FIELD_GET(GENMASK(7, 0), ver), caps, sdev->max_ctx, win_kib,
		 sdev->devmem_size >> 20, sdev->max_qent, sdev->dma_bits);
	return 0;
}

int sfg1_rings_alloc(struct sfg1_device *sdev)
{
	u32 entries = sdev->cfg.queue_entries;

	sdev->sq.entries = entries;
	sdev->cq.entries = entries;	/* CQ >= SQ guarantees the CQ cannot overflow */
	sdev->sq.size = (size_t)entries * sizeof(struct sfg1_sq_entry);
	sdev->cq.size = (size_t)entries * sizeof(struct sfg1_cq_entry);

	sdev->sq.vaddr = dma_alloc_coherent(sdev->dev, sdev->sq.size, &sdev->sq.dma, GFP_KERNEL);
	if (!sdev->sq.vaddr)
		return -ENOMEM;
	sdev->cq.vaddr = dma_alloc_coherent(sdev->dev, sdev->cq.size, &sdev->cq.dma, GFP_KERNEL);
	if (!sdev->cq.vaddr) {
		dma_free_coherent(sdev->dev, sdev->sq.size, sdev->sq.vaddr, sdev->sq.dma);
		sdev->sq.vaddr = NULL;
		return -ENOMEM;
	}
	if (sdev->ops->dma_region_add) {
		sdev->ops->dma_region_add(sdev, sdev->sq.dma, sdev->sq.vaddr, sdev->sq.size, 0);
		sdev->ops->dma_region_add(sdev, sdev->cq.dma, sdev->cq.vaddr, sdev->cq.size, 0);
	}
	return 0;
}

void sfg1_rings_free(struct sfg1_device *sdev)
{
	if (sdev->sq.vaddr) {
		if (sdev->ops->dma_region_del)
			sdev->ops->dma_region_del(sdev, sdev->sq.dma);
		dma_free_coherent(sdev->dev, sdev->sq.size, sdev->sq.vaddr, sdev->sq.dma);
		sdev->sq.vaddr = NULL;
	}
	if (sdev->cq.vaddr) {
		if (sdev->ops->dma_region_del)
			sdev->ops->dma_region_del(sdev, sdev->cq.dma);
		dma_free_coherent(sdev->dev, sdev->cq.size, sdev->cq.vaddr, sdev->cq.dma);
		sdev->cq.vaddr = NULL;
	}
}

/*
 * Program queues and enable the device. Precondition: the device has just been
 * reset (or just probed): ENABLE=0, queue indexes 0, READY set.
 */
int sfg1_hw_start(struct sfg1_device *sdev)
{
	int ret;

	ret = sfg1_wait_ready(sdev, sdev->cfg.reset_timeout_ms);
	if (ret)
		return ret;

	/* Stale phase bits would be mistaken for new completions. */
	memset(sdev->sq.vaddr, 0, sdev->sq.size);
	memset(sdev->cq.vaddr, 0, sdev->cq.size);
	dma_wmb();
	sfg1_ring_reset_state(sdev);

	sfg1_wr(sdev, SFG1_REG_SQ_BASE_LO, lower_32_bits(sdev->sq.dma));
	sfg1_wr(sdev, SFG1_REG_SQ_BASE_HI, upper_32_bits(sdev->sq.dma));
	sfg1_wr(sdev, SFG1_REG_SQ_ENTRIES, sdev->sq.entries);
	sfg1_wr(sdev, SFG1_REG_CQ_BASE_LO, lower_32_bits(sdev->cq.dma));
	sfg1_wr(sdev, SFG1_REG_CQ_BASE_HI, upper_32_bits(sdev->cq.dma));
	sfg1_wr(sdev, SFG1_REG_CQ_ENTRIES, sdev->cq.entries);

	sfg1_wr(sdev, SFG1_REG_IRQ_STATUS, SFG1_IRQ_ALL);	/* drop stale causes */
	sfg1_wr(sdev, SFG1_REG_IRQ_MASK, SFG1_IRQ_ALL);
	sfg1_wr(sdev, SFG1_REG_CTRL, SFG1_CTRL_ENABLE);

	if (sfg1_rd(sdev, SFG1_REG_STATUS) & (SFG1_STATUS_FATAL | SFG1_STATUS_HALTED)) {
		dev_err(sdev->dev, "device failed to start\n");
		return -EIO;
	}
	return 0;
}

/*
 * Stop the device and make sure no DMA is outstanding before queue/BO memory
 * is freed. Safe to call on a device that is already gone.
 */
void sfg1_hw_quiesce(struct sfg1_device *sdev)
{
	u32 st;

	if (READ_ONCE(sdev->hw_gone))
		return;
	sfg1_wr(sdev, SFG1_REG_IRQ_MASK, 0);
	sfg1_wr(sdev, SFG1_REG_CTRL, 0);
	if (read_poll_timeout(sfg1_rd, st, st == SFG1_ALL_ONES || !(st & SFG1_STATUS_BUSY),
			      100, 100 * 1000, false, sdev, SFG1_REG_STATUS)) {
		dev_warn(sdev->dev, "device still busy at quiesce, forcing engine reset\n");
		(void)sfg1_hw_engine_reset(sdev);
	}
}

int sfg1_hw_engine_reset(struct sfg1_device *sdev)
{
	int ret;

	sfg1_wr(sdev, SFG1_REG_CTRL, SFG1_CTRL_ENGINE_RESET);
	ret = sfg1_wait_ready(sdev, sdev->cfg.reset_timeout_ms);
	if (ret)
		return ret;
	if (sfg1_rd(sdev, SFG1_REG_STATUS) & SFG1_STATUS_HALTED)
		return -EIO;
	return 0;
}

int sfg1_hw_function_reset(struct sfg1_device *sdev)
{
	sfg1_wr(sdev, SFG1_REG_RESET, SFG1_RESET_MAGIC);
	return sfg1_wait_ready(sdev, sdev->cfg.reset_timeout_ms);
}
