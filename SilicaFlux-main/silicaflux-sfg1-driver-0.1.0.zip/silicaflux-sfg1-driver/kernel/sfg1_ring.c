// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 submission/completion rings.
 *
 * Memory-ordering contract with the hardware (normative text:
 * docs/02-hw-interface.md section 5):
 *
 *  Host -> device (SQ):
 *    1. fill SQ entries (plain stores to coherent DMA memory)
 *    2. dma_wmb(); writel(SQ_TAIL)  -- the doorbell publishes the entries
 *    The device only reads entries in [SQ_HEAD, SQ_TAIL).
 *
 *  Device -> host (CQ):
 *    The device writes the 16-byte CQE payload, then makes the 16-bit
 *    status_phase field (offset 14) visible LAST, then raises the interrupt.
 *    The host therefore does:
 *        sp = READ_ONCE(cqe->status_phase);   // look at the phase tag only
 *        if ((sp & PHASE) != expected) stop;
 *        dma_rmb();                           // order payload reads after it
 *        read the rest of the CQE
 *    and returns credit with writel(CQ_HEAD).
 *
 * All of this runs under ring_lock.
 */
#include <linux/dma-fence.h>
#include <linux/ktime.h>

#include "sfg1_drv.h"

bool sfg1_state_is(struct sfg1_device *sdev, enum sfg1_state s)
{
	return READ_ONCE(sdev->state) == s;
}

void sfg1_ring_reset_state(struct sfg1_device *sdev)
{
	spin_lock(&sdev->ring_lock);
	sdev->sq_tail = 0;
	sdev->sq_free = sdev->sq.entries - 1;	/* one slot kept empty */
	sdev->cq_head = 0;
	sdev->cq_phase = 1;			/* device writes phase=1 on lap 1 */
	sdev->fault = SFG1_FAULT_NONE;
	sdev->fault_status = 0;
	sdev->last_progress = jiffies;
	sdev->last_busy_end = ktime_get();
	spin_unlock(&sdev->ring_lock);
}

/*
 * Copy a job's pre-built descriptors into the SQ and ring the doorbell.
 * Called from run_job(); drm_sched credits (== SQ capacity) guarantee space,
 * so failure here means a driver bug or a device that is no longer running.
 */
int sfg1_ring_push_job(struct sfg1_device *sdev, struct sfg1_job *job)
{
	const u32 mask = sdev->sq.entries - 1;
	struct sfg1_sq_entry *sq = sdev->sq.vaddr;
	u32 i, slot;

	spin_lock(&sdev->ring_lock);
	if (sdev->state != SFG1_STATE_RUNNING) {
		spin_unlock(&sdev->ring_lock);
		return -ENODEV;
	}
	if (WARN_ON_ONCE(job->n_cmds > sdev->sq_free)) {
		spin_unlock(&sdev->ring_lock);
		return -EBUSY;
	}

	if (list_empty(&sdev->inflight))
		sdev->last_progress = jiffies;	/* idle -> busy edge restarts the hang window */

	job->first_slot = sdev->sq_tail;
	job->cmds_done = 0;
	for (i = 0; i < job->n_cmds; i++) {
		slot = (sdev->sq_tail + i) & mask;
		memcpy(&sq[slot], &job->cmds[i], sizeof(*sq));
		sq[slot].cid = cpu_to_le16(slot);	/* cid == slot, see HW contract */
	}
	sdev->sq_tail = (sdev->sq_tail + job->n_cmds) & mask;
	sdev->sq_free -= job->n_cmds;
	job->t_start = ktime_get();
	list_add_tail(&job->node, &sdev->inflight);

	/*
	 * Publish. writel() already orders prior coherent-memory stores before
	 * the MMIO write; dma_wmb() makes the rule explicit and independent of
	 * that implicit barrier.
	 */
	dma_wmb();
	sfg1_wr(sdev, SFG1_REG_SQ_TAIL, sdev->sq_tail);
	spin_unlock(&sdev->ring_lock);
	return 0;
}

/*
 * Drain the CQ. Completed jobs are moved to @done (their fences are signalled
 * by the caller outside ring_lock). On a device error or protocol violation
 * the fault is recorded, reaping stops, and the offending job stays on the
 * in-flight list so recovery can attribute it.
 */
void sfg1_ring_reap(struct sfg1_device *sdev, struct list_head *done)
{
	const u32 mask = sdev->cq.entries - 1;
	const struct sfg1_cq_entry *cq = sdev->cq.vaddr;
	bool consumed = false;

	lockdep_assert_held(&sdev->ring_lock);

	for (;;) {
		const struct sfg1_cq_entry *cqe = &cq[sdev->cq_head];
		struct sfg1_job *job;
		u16 sp, cid, status;

		sp = le16_to_cpu(READ_ONCE(cqe->status_phase));
		if ((sp & SFG1_CQE_PHASE) != sdev->cq_phase)
			break;
		dma_rmb();	/* payload reads must not pass the phase read */

		status = sp >> SFG1_CQE_STATUS_SHIFT;
		cid = le16_to_cpu(cqe->cid);

		sdev->cq_head = (sdev->cq_head + 1) & mask;
		if (!sdev->cq_head)
			sdev->cq_phase ^= 1;
		consumed = true;

		job = list_first_entry_or_null(&sdev->inflight, struct sfg1_job, node);
		if (!job || cid != ((job->first_slot + job->cmds_done) & (sdev->sq.entries - 1))) {
			dev_err(sdev->dev, "protocol error: CQE cid=%u status=%u %s\n", cid, status,
				job ? "does not match the oldest in-flight command" :
				      "with nothing in flight");
			sdev->fault = SFG1_FAULT_PROTOCOL;
			sdev->fault_status = status;
			break;
		}

		job->cmds_done++;
		sdev->sq_free++;
		sdev->retired_cmds++;
		sdev->last_progress = jiffies;

		if (status != SFG1_ST_OK) {
			job->dev_error = status;
			sdev->fault = SFG1_FAULT_DEVICE_ERROR;
			sdev->fault_status = status;
			break;
		}
		if (job->cmds_done == job->n_cmds) {
			ktime_t now = ktime_get();
			ktime_t start = ktime_after(job->t_start, sdev->last_busy_end) ?
					job->t_start : sdev->last_busy_end;

			job->busy_ns = max_t(s64, 0, ktime_to_ns(ktime_sub(now, start)));
			sdev->last_busy_end = now;
			list_move_tail(&job->node, done);
		}
	}

	if (consumed)
		sfg1_wr(sdev, SFG1_REG_CQ_HEAD, sdev->cq_head);
}

void sfg1_job_set_result(struct sfg1_job *job, u32 status)
{
	if (!job->res)
		return;
	WRITE_ONCE(job->res->dev_error, job->dev_error);
	/* release: a waiter that sees the fence signalled also sees these */
	smp_store_release(&job->res->status, status);
}

/*
 * Retire a job that reached a final state: record the result first, then
 * signal the hardware fence (waiters read the result after the fence).
 */
void sfg1_job_finish(struct sfg1_job *job, u32 status, int fence_err)
{
	struct sfg1_ctx *ctx = job->ctx;

	sfg1_job_set_result(job, status);
	if (ctx) {
		switch (status) {
		case DRM_SFG1_JOB_OK:
			atomic64_inc(&ctx->jobs_ok);
			atomic64_add(job->busy_ns, &ctx->busy_ns);
			break;
		case DRM_SFG1_JOB_ERROR:
			atomic64_inc(&ctx->jobs_error);
			break;
		case DRM_SFG1_JOB_TIMEOUT:
			atomic64_inc(&ctx->jobs_timeout);
			break;
		default:
			atomic64_inc(&ctx->jobs_canceled);
			break;
		}
	}
	if (job->hw_fence_inited) {
		if (fence_err)
			dma_fence_set_error(job->hw_fence, fence_err);
		dma_fence_signal(job->hw_fence);
	}
}

void sfg1_complete_done_jobs(struct sfg1_device *sdev, struct list_head *done)
{
	struct sfg1_job *job, *tmp;

	list_for_each_entry_safe(job, tmp, done, node) {
		list_del_init(&job->node);
		sfg1_job_finish(job, DRM_SFG1_JOB_OK, 0);
	}
}
