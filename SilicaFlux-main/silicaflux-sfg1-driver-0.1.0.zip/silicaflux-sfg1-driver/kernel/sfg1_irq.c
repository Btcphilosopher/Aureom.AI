// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 interrupt handling: acknowledge-then-drain.
 *
 * Top half: read IRQ_STATUS, W1C-acknowledge exactly the causes seen, defer.
 * Thread  : drain the CQ until empty.
 *
 * Because the acknowledge happens BEFORE the drain, a CQE that lands after
 * the ack re-raises the interrupt (hardware rule R6, docs/02-hw-interface.md),
 * so a wake-up can never be lost. The reverse order (drain, then ack) would
 * lose completions that arrive between the two.
 */
#include <linux/dma-fence.h>
#include <linux/interrupt.h>

#include "sfg1_drv.h"

irqreturn_t sfg1_irq_top(int irq, void *arg)
{
	struct sfg1_device *sdev = arg;
	u32 st;

	if (READ_ONCE(sdev->hw_gone))
		return IRQ_NONE;

	st = sfg1_rd(sdev, SFG1_REG_IRQ_STATUS);
	if (st == SFG1_ALL_ONES) {		/* surprise removal */
		WRITE_ONCE(sdev->hw_gone, true);
		return IRQ_NONE;
	}
	st &= SFG1_IRQ_ALL;
	if (!st)
		return IRQ_NONE;		/* shared INTx: not ours */

	sfg1_wr(sdev, SFG1_REG_IRQ_STATUS, st);
	atomic_or(st, &sdev->irq_pending);
	return IRQ_WAKE_THREAD;
}

irqreturn_t sfg1_irq_thread(int irq, void *arg)
{
	struct sfg1_device *sdev = arg;
	u32 pending = atomic_xchg(&sdev->irq_pending, 0);
	LIST_HEAD(done);
	bool fault = false, busy = false, cookie;

	cookie = dma_fence_begin_signalling();
	spin_lock(&sdev->ring_lock);
	if (sdev->state == SFG1_STATE_RUNNING) {
		sfg1_ring_reap(sdev, &done);

		if (!sdev->fault && (pending & (SFG1_IRQ_FATAL | SFG1_IRQ_ERROR))) {
			/* Reported without a matching error CQE: hardware broke its contract. */
			dev_err(sdev->dev, "device raised irq cause %#x without a failing CQE\n",
				pending);
			sdev->fault = SFG1_FAULT_PROTOCOL;
		}
		fault = sdev->fault != SFG1_FAULT_NONE;
		busy = !list_empty(&sdev->inflight);
	}
	spin_unlock(&sdev->ring_lock);

	sfg1_complete_done_jobs(sdev, &done);
	dma_fence_end_signalling(cookie);

	if (fault) {
		/* One recovery path: the scheduler's timeout handler. */
		if (busy)
			drm_sched_fault(&sdev->sched);
		else
			queue_work(sdev->reset_wq, &sdev->reset_work);
	}
	return IRQ_HANDLED;
}
