// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 command submission.
 *
 * SUBMIT is the trust boundary. Userspace describes work in terms of
 *     (GEM handle, offset, length)  and  (offset into its own device window)
 * and NEVER supplies a bus address, a context id, or a register. This file
 * resolves handles in the caller's own drm_file, checks BO ownership, checks
 * every range with overflow-safe arithmetic against the BO and against the
 * context's device-memory window, and only then writes the hardware
 * descriptors itself.
 *
 * One drm_sched job = one SUBMIT = up to SFG1_MAX_CMDS_PER_SUBMIT commands.
 */
#include <linux/dma-fence.h>
#include <linux/minmax.h>
#include <linux/overflow.h>
#include <linux/uaccess.h>

#include <drm/drm_gem.h>
#include <drm/drm_managed.h>
#include <drm/drm_utils.h>

#include "sfg1_drv.h"

/* ------------------------------------------------------------------------ */
/* hardware fence                                                            */
/* ------------------------------------------------------------------------ */
static const char *sfg1_fence_driver_name(struct dma_fence *f)
{
	return SFG1_DRV_NAME;
}

static const char *sfg1_fence_timeline_name(struct dma_fence *f)
{
	return "sfg1-hw";
}

static const struct dma_fence_ops sfg1_fence_ops = {
	.get_driver_name = sfg1_fence_driver_name,
	.get_timeline_name = sfg1_fence_timeline_name,
};

/* ------------------------------------------------------------------------ */
/* results                                                                   */
/* ------------------------------------------------------------------------ */
static void sfg1_result_release(struct kref *ref)
{
	struct sfg1_result *res = container_of(ref, struct sfg1_result, ref);

	if (res->finished)
		dma_fence_put(res->finished);
	kfree(res);
}

void sfg1_result_put(struct sfg1_result *res)
{
	kref_put(&res->ref, sfg1_result_release);
}

/* ------------------------------------------------------------------------ */
/* drm_sched backend                                                         */
/* ------------------------------------------------------------------------ */
static struct dma_fence *sfg1_run_job(struct drm_sched_job *sjob)
{
	struct sfg1_job *job = to_sfg1_job(sjob);
	struct sfg1_device *sdev = job->sdev;
	struct dma_fence *fence;
	int ret;

	/* Jobs of a banned/lost context, or on a dead device, never reach the HW. */
	if (job->ctx) {
		ret = sfg1_ctx_usable(job->ctx);
		if (ret) {
			sfg1_job_set_result(job, DRM_SFG1_JOB_CANCELED);
			atomic64_inc(&job->ctx->jobs_canceled);
			return ERR_PTR(ret);
		}
	} else if (READ_ONCE(sdev->state) != SFG1_STATE_RUNNING) {
		sfg1_job_set_result(job, DRM_SFG1_JOB_CANCELED);
		return ERR_PTR(-ENODEV);
	}

	/* Initialise now (not at submit) so fence seqnos follow device order. */
	dma_fence_init(job->hw_fence, &sfg1_fence_ops, &sdev->fence_lock, sdev->fence_ctx,
		       ++sdev->fence_seqno);
	job->hw_fence_inited = true;
	fence = dma_fence_get(job->hw_fence);	/* the scheduler's reference */

	ret = sfg1_ring_push_job(sdev, job);
	if (ret) {
		/* Never reached the device. */
		sfg1_job_finish(job, DRM_SFG1_JOB_CANCELED, ret);
	}
	return fence;
}

static void sfg1_free_job(struct drm_sched_job *sjob)
{
	struct sfg1_job *job = to_sfg1_job(sjob);
	struct sfg1_ctx *ctx = job->ctx;
	u32 i;

	drm_sched_job_cleanup(sjob);
	for (i = 0; i < job->n_bos; i++)
		drm_gem_object_put(job->bos[i]);
	kfree(job->bos);
	if (job->hw_fence) {
		if (job->hw_fence_inited)
			dma_fence_put(job->hw_fence);
		else
			kfree(job->hw_fence);
	}
	if (job->res)
		sfg1_result_put(job->res);
	kvfree(job);
	if (ctx) {
		atomic_dec(&ctx->jobs_alive);
		wake_up(&ctx->idle_wq);
		sfg1_ctx_put(ctx);
	}
}

static void sfg1_cancel_job(struct drm_sched_job *sjob)
{
	struct sfg1_job *job = to_sfg1_job(sjob);

	/* drm_sched_fini(): make sure no hardware fence is left unsignalled. */
	if (job->hw_fence_inited && !dma_fence_is_signaled(job->hw_fence))
		sfg1_job_finish(job, DRM_SFG1_JOB_CANCELED, -ECANCELED);
}

const struct drm_sched_backend_ops sfg1_sched_ops = {
	.run_job = sfg1_run_job,
	.timedout_job = sfg1_timedout_job,
	.free_job = sfg1_free_job,
	.cancel_job = sfg1_cancel_job,
};

static void sfg1_sched_fini(struct drm_device *drm, void *arg)
{
	struct sfg1_device *sdev = arg;

	if (!sdev->sched_ready)
		return;
	/* All files are closed by now (drm_device release): entities are gone. */
	drm_sched_entity_destroy(&sdev->kentity);
	drm_sched_fini(&sdev->sched);
	sdev->sched_ready = false;
}

/*
 * The scheduler lives as long as the drm_device, NOT as long as the hardware:
 * drm_sched_fini() would otherwise leave entities of still-open files pointing
 * at freed run-queues (documented race in the 6.18 scheduler).
 */
int sfg1_sched_init(struct sfg1_device *sdev)
{
	struct drm_sched_init_args args = {
		.ops = &sfg1_sched_ops,
		.num_rqs = DRM_SCHED_PRIORITY_COUNT,
		.credit_limit = sdev->sq.entries - 1,	/* never more commands than SQ slots */
		.timeout = msecs_to_jiffies(sdev->cfg.job_timeout_ms),
		.timeout_wq = sdev->reset_wq,		/* ordered: recoveries never overlap */
		.name = SFG1_DRV_NAME,
		.dev = sdev->dev,
	};
	int ret;

	ret = drm_sched_init(&sdev->sched, &args);
	if (ret)
		return ret;
	sdev->sched_list[0] = &sdev->sched;
	ret = drm_sched_entity_init(&sdev->kentity, DRM_SCHED_PRIORITY_KERNEL, sdev->sched_list, 1,
				    NULL);
	if (ret) {
		drm_sched_fini(&sdev->sched);
		return ret;
	}
	sdev->sched_ready = true;
	return drmm_add_action_or_reset(&sdev->drm, sfg1_sched_fini, sdev);
}

/* ------------------------------------------------------------------------ */
/* validation                                                                */
/* ------------------------------------------------------------------------ */
/* [off, off+len) lies inside [0, limit) — no overflow possible. */
static inline bool sfg1_range_ok(u64 off, u64 len, u64 limit)
{
	return len <= limit && off <= limit - len;
}

static int sfg1_win_check(const struct sfg1_device *sdev, u64 off, u64 len)
{
	return sfg1_range_ok(off, len, sdev->ctx_win_size) ? 0 : -EINVAL;
}

/* Find (or look up and add) the BO for @handle; takes a reference stored in the job. */
static struct sfg1_bo *sfg1_job_get_bo(struct drm_file *file, struct sfg1_job *job,
				       struct sfg1_ctx *ctx, u32 handle)
{
	struct drm_gem_object *obj;
	struct sfg1_bo *bo;
	u32 i;

	obj = drm_gem_object_lookup(file, handle);	/* per-file: other files' handles miss */
	if (!obj)
		return ERR_PTR(-ENOENT);

	/* Defence in depth: even a handle that reached this file by privileged GEM
	 * flink/open must belong to this context.
	 */
	if (!sfg1_is_bo(obj)) {
		drm_gem_object_put(obj);
		return ERR_PTR(-EINVAL);
	}
	bo = to_sfg1_bo(obj);
	if (bo->ctx != ctx) {
		drm_gem_object_put(obj);
		return ERR_PTR(-EACCES);
	}

	for (i = 0; i < job->n_bos; i++) {
		if (job->bos[i] == obj) {	/* already held by this job: drop the extra ref */
			drm_gem_object_put(obj);
			return bo;
		}
	}
	if (job->n_bos >= SFG1_MAX_CMDS_PER_SUBMIT) {
		drm_gem_object_put(obj);
		return ERR_PTR(-EINVAL);
	}
	job->bos[job->n_bos++] = obj;
	return bo;
}

static int sfg1_build_cmd(struct drm_file *file, struct sfg1_job *job, struct sfg1_ctx *ctx,
			  const struct drm_sfg1_cmd *c, struct sfg1_sq_entry *e)
{
	struct sfg1_device *sdev = job->sdev;
	u64 bytes_in, bytes_c, a_len, b_len, c_len;
	struct sfg1_bo *bo;
	int ret;

	if (c->reserved)
		return -EINVAL;

	memset(e, 0, sizeof(*e));
	e->opcode = cpu_to_le16(c->op);
	e->ctx_id = cpu_to_le16(ctx->id);	/* from the file, never from userspace */

	switch (c->op) {
	case DRM_SFG1_OP_NOP:
		if (c->flags || c->bo_handle || c->exec_op || c->bo_offset || c->len || c->dev_a ||
		    c->dev_b || c->dev_c)
			return -EINVAL;
		return 0;

	case DRM_SFG1_OP_DMA_H2D:
	case DRM_SFG1_OP_DMA_D2H:
		if (c->flags || c->exec_op || c->dev_b || c->dev_c)
			return -EINVAL;
		if (!c->len || !IS_ALIGNED(c->len, 4) || !IS_ALIGNED(c->bo_offset, 4) ||
		    !IS_ALIGNED(c->dev_a, 4))
			return -EINVAL;
		bo = sfg1_job_get_bo(file, job, ctx, c->bo_handle);
		if (IS_ERR(bo))
			return PTR_ERR(bo);
		if (bo->hw_released)
			return -ENODEV;
		if (!sfg1_range_ok(c->bo_offset, c->len, bo->size))
			return -EINVAL;
		ret = sfg1_win_check(sdev, c->dev_a, c->len);
		if (ret)
			return ret;
		e->host_addr = cpu_to_le64(bo->dma + c->bo_offset);	/* kernel-computed */
		e->len = cpu_to_le64(c->len);
		e->dev_a = cpu_to_le64(c->dev_a);
		return 0;

	case DRM_SFG1_OP_VEC:
		if (!(sdev->caps & SFG1_CAP_VEC) || c->flags || c->bo_handle || c->bo_offset)
			return -EINVAL;
		if (c->exec_op > DRM_SFG1_VEC_DOT8 || !c->len)
			return -EINVAL;
		if (!IS_ALIGNED(c->dev_a, 4) || !IS_ALIGNED(c->dev_b, 4) ||
		    !IS_ALIGNED(c->dev_c, 4))
			return -EINVAL;
		if (check_mul_overflow(c->len, 4ULL, &bytes_in))
			return -EINVAL;
		a_len = bytes_in;
		b_len = (c->exec_op == DRM_SFG1_VEC_RELU8) ? 0 : bytes_in;
		c_len = (c->exec_op == DRM_SFG1_VEC_DOT8) ? 4 : bytes_in;
		if (c->exec_op == DRM_SFG1_VEC_RELU8 && c->dev_b)
			return -EINVAL;
		if (sfg1_win_check(sdev, c->dev_a, a_len) ||
		    (b_len && sfg1_win_check(sdev, c->dev_b, b_len)) ||
		    sfg1_win_check(sdev, c->dev_c, c_len))
			return -EINVAL;
		e->exec_op = cpu_to_le32(c->exec_op);
		e->len = cpu_to_le64(c->len);
		e->dev_a = cpu_to_le64(c->dev_a);
		e->dev_b = cpu_to_le64(c->dev_b);
		e->dev_c = cpu_to_le64(c->dev_c);
		return 0;

	case DRM_SFG1_OP_TEN:
		if (!(sdev->caps & SFG1_CAP_TEN) || (c->flags & ~SFG1_CMDF_VALID_MASK) ||
		    c->bo_handle || c->bo_offset || c->exec_op || !c->len)
			return -EINVAL;
		if (!IS_ALIGNED(c->dev_a, 4) || !IS_ALIGNED(c->dev_b, 4) ||
		    !IS_ALIGNED(c->dev_c, 4))
			return -EINVAL;
		if (check_mul_overflow(c->len, 16ULL, &bytes_in) ||
		    check_mul_overflow(c->len, 64ULL, &bytes_c))
			return -EINVAL;
		if (sfg1_win_check(sdev, c->dev_a, bytes_in) ||
		    sfg1_win_check(sdev, c->dev_b, bytes_in) ||
		    sfg1_win_check(sdev, c->dev_c, bytes_c))
			return -EINVAL;
		e->flags = cpu_to_le16(c->flags);
		e->len = cpu_to_le64(c->len);
		e->dev_a = cpu_to_le64(c->dev_a);
		e->dev_b = cpu_to_le64(c->dev_b);
		e->dev_c = cpu_to_le64(c->dev_c);
		return 0;

	default:
		/* includes SCRUB (kernel only) and every unknown opcode */
		return -EINVAL;
	}
}

/* ------------------------------------------------------------------------ */
/* SUBMIT                                                                    */
/* ------------------------------------------------------------------------ */
int sfg1_ioctl_submit(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct sfg1_device *sdev = to_sfg1(drm);
	struct sfg1_ctx *ctx = file->driver_priv;
	struct drm_sfg1_submit *args = data;
	const u32 max_cmds = min_t(u32, SFG1_MAX_CMDS_PER_SUBMIT, sdev->sq.entries - 1);
	void __user *uptr = u64_to_user_ptr(args->cmds_ptr);
	struct sfg1_result *res = NULL;
	struct sfg1_job *job;
	u32 i;
	int idx, ret;

	if (args->flags || args->pad || args->reserved)
		return -EINVAL;
	if (!args->cmd_count || args->cmd_count > max_cmds)
		return -EINVAL;
	if (args->cmd_stride < DRM_SFG1_CMD_SIZE_V1 || args->cmd_stride > PAGE_SIZE ||
	    !IS_ALIGNED(args->cmd_stride, 8))
		return -EINVAL;
	if (!args->cmds_ptr)
		return -EFAULT;

	if (!drm_dev_enter(drm, &idx))
		return -ENODEV;

	ret = sfg1_ctx_usable(ctx);
	if (ret)
		goto out_exit;

	/* Quotas first: nothing is committed if a limit is hit. */
	if (atomic_inc_return(&ctx->jobs_alive) > sdev->cfg.max_inflight_jobs) {
		ret = -EBUSY;
		goto err_alive;
	}
	if (atomic_inc_return(&ctx->unreaped) > sdev->cfg.max_pending_results) {
		ret = -EBUSY;
		goto err_unreaped;
	}

	job = kvzalloc(struct_size(job, cmds, args->cmd_count), GFP_KERNEL);
	if (!job) {
		ret = -ENOMEM;
		goto err_unreaped;
	}
	job->bos = kcalloc(args->cmd_count, sizeof(*job->bos), GFP_KERNEL);
	job->hw_fence = kzalloc(sizeof(*job->hw_fence), GFP_KERNEL);
	res = kzalloc(sizeof(*res), GFP_KERNEL);
	if (!job->bos || !job->hw_fence || !res) {
		ret = -ENOMEM;
		goto err_job;
	}
	kref_init(&res->ref);
	res->status = SFG1_RESULT_UNSET;
	INIT_LIST_HEAD(&job->node);
	job->sdev = sdev;
	job->n_cmds = args->cmd_count;

	for (i = 0; i < args->cmd_count; i++) {
		struct drm_sfg1_cmd c;

		/* Fails with -E2BIG if a newer userspace set unknown trailing fields. */
		ret = copy_struct_from_user(&c, sizeof(c), uptr + (size_t)i * args->cmd_stride,
					    args->cmd_stride);
		if (ret)
			goto err_job;
		ret = sfg1_build_cmd(file, job, ctx, &c, &job->cmds[i]);
		if (ret)
			goto err_job;
	}

	ret = drm_sched_job_init(&job->base, &ctx->entity, args->cmd_count, ctx, file->client_id);
	if (ret)
		goto err_job;

	job->id = (u64)atomic64_inc_return(&ctx->job_seq);
	res->id = job->id;
	ret = xa_err(xa_store(&ctx->results, job->id, res, GFP_KERNEL));
	if (ret)
		goto err_sched_job;

	/* ---- point of no return: arm + push cannot fail ---- */
	drm_sched_job_arm(&job->base);
	kref_get(&res->ref);			/* the job's reference */
	job->res = res;
	job->ctx = sfg1_ctx_get(ctx);
	/* Publish the fence: pairs with smp_load_acquire() in WAIT_JOB, so a waiter that sees
	 * the pointer also sees a fully initialised fence.
	 */
	smp_store_release(&res->finished, dma_fence_get(&job->base.s_fence->finished));

	atomic64_inc(&ctx->jobs_submitted);
	atomic64_add(args->cmd_count, &ctx->cmds_submitted);
	args->job_id = job->id;
	drm_sched_entity_push_job(&job->base);
	drm_dev_exit(idx);
	return 0;

err_sched_job:
	drm_sched_job_cleanup(&job->base);
err_job:
	for (i = 0; job->bos && i < job->n_bos; i++)
		drm_gem_object_put(job->bos[i]);
	kfree(job->bos);
	kfree(job->hw_fence);
	kfree(res);
	kvfree(job);
err_unreaped:
	atomic_dec(&ctx->unreaped);
err_alive:
	atomic_dec(&ctx->jobs_alive);
out_exit:
	drm_dev_exit(idx);
	return ret;
}

/* ------------------------------------------------------------------------ */
/* WAIT_JOB                                                                  */
/* ------------------------------------------------------------------------ */
int sfg1_ioctl_wait_job(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct sfg1_ctx *ctx = file->driver_priv;
	struct drm_sfg1_wait_job *args = data;
	struct sfg1_result *res;
	struct dma_fence *fence;
	unsigned long timeout;
	u32 st;
	long r;
	int idx;

	if (args->flags || args->pad || args->reserved)
		return -EINVAL;
	if (!drm_dev_enter(drm, &idx))
		return -ENODEV;
	drm_dev_exit(idx);	/* never hold the unplug SRCU across a wait */

	xa_lock(&ctx->results);
	res = xa_load(&ctx->results, args->job_id);
	if (res)
		kref_get(&res->ref);
	xa_unlock(&ctx->results);
	if (!res)
		return -ENOENT;

	/* Pairs with the smp_store_release() in SUBMIT (fence fully initialised). */
	fence = smp_load_acquire(&res->finished);
	if (!fence) {			/* id guessed before SUBMIT returned */
		sfg1_result_put(res);
		return -ENOENT;
	}
	fence = dma_fence_get(fence);

	if (!args->timeout_ns) {
		if (!dma_fence_is_signaled(fence)) {
			r = -EBUSY;
			goto out;
		}
	} else {
		timeout = drm_timeout_abs_to_jiffies(args->timeout_ns);
		r = dma_fence_wait_timeout(fence, true, timeout);
		if (r < 0)
			goto out;			/* -ERESTARTSYS: not reaped */
		if (r == 0) {
			r = -ETIMEDOUT;		/* not reaped */
			goto out;
		}
	}

	/* Reap: exactly one waiter wins. */
	if (xa_erase(&ctx->results, args->job_id) != res) {
		r = -ENOENT;
		goto out;
	}
	/* Pairs with smp_store_release() in sfg1_job_set_result(): dev_error is visible too. */
	st = smp_load_acquire(&res->status);
	if (st == SFG1_RESULT_UNSET)		/* finished without an explicit verdict */
		st = fence->error ? DRM_SFG1_JOB_CANCELED : DRM_SFG1_JOB_OK;
	args->status = st;
	args->dev_error = READ_ONCE(res->dev_error);
	atomic_dec(&ctx->unreaped);
	sfg1_result_put(res);			/* the xarray's reference */
	r = 0;
out:
	dma_fence_put(fence);
	sfg1_result_put(res);
	return r;
}
