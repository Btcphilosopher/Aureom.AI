// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 buffer objects.
 *
 * A BO is a zero-initialised, DMA-contiguous, CPU-mmappable buffer owned by
 * exactly one context. Design points (docs/01-design.md section 2):
 *
 *  - The DMA memory is owned by the driver, not by drm_gem_dma_helper, so it
 *    can be released at unplug time while the device is still valid. The small
 *    software object may outlive the hardware (open fds, in-flight jobs).
 *  - Memory is explicitly zeroed: a recycled page must never leak another
 *    process's data.
 *  - dma-buf export/import is refused: a BO can never be handed to another
 *    process (PRIME_HANDLE_TO_FD is DRM_RENDER_ALLOW and reachable on accel
 *    nodes, so it must be blocked here).
 *  - Quotas are charged before anything is allocated and refunded in one
 *    place (.free).
 */
#include <linux/dma-buf.h>
#include <linux/dma-mapping.h>
#include <linux/minmax.h>
#include <linux/overflow.h>

#include <drm/drm_gem.h>
#include <drm/drm_vma_manager.h>

#include "sfg1_drv.h"

/* caller holds sdev->bo_lock */
static void sfg1_bo_release_dma_locked(struct sfg1_bo *bo)
{
	struct sfg1_device *sdev = bo->sdev;
	const struct sfg1_backend_ops *ops = READ_ONCE(sdev->ops);

	lockdep_assert_held(&sdev->bo_lock);
	if (bo->hw_released)
		return;
	if (ops->dma_region_del)
		ops->dma_region_del(sdev, bo->dma);
	dma_free_wc(sdev->dev, bo->size, bo->vaddr, bo->dma);
	bo->vaddr = NULL;
	bo->hw_released = true;
}

/* Unplug: free every BO's DMA memory while the device is still valid. */
void sfg1_bos_release_all_dma(struct sfg1_device *sdev)
{
	struct sfg1_bo *bo;

	mutex_lock(&sdev->bo_lock);
	list_for_each_entry(bo, &sdev->bo_list, node)
		sfg1_bo_release_dma_locked(bo);
	mutex_unlock(&sdev->bo_lock);
}

static void sfg1_bo_free(struct drm_gem_object *obj)
{
	struct sfg1_bo *bo = to_sfg1_bo(obj);
	struct sfg1_device *sdev = bo->sdev;
	struct sfg1_ctx *ctx = bo->ctx;

	mutex_lock(&sdev->bo_lock);
	list_del(&bo->node);
	sfg1_bo_release_dma_locked(bo);
	mutex_unlock(&sdev->bo_lock);

	atomic64_sub(bo->size, &sdev->total_bo_bytes);
	atomic64_sub(bo->size, &ctx->bo_bytes);
	atomic_dec(&ctx->bo_count);
	sfg1_ctx_put(ctx);

	drm_gem_object_release(obj);
	kfree(bo);
}

static int sfg1_bo_mmap(struct drm_gem_object *obj, struct vm_area_struct *vma)
{
	struct sfg1_bo *bo = to_sfg1_bo(obj);
	int idx, ret;

	/* drm_gem_mmap() already enforced per-file mmap authorisation. */
	vma->vm_pgoff -= drm_vma_node_start(&obj->vma_node);
	vm_flags_mod(vma, VM_DONTEXPAND, VM_PFNMAP);

	/*
	 * No bo_lock here: dma_mmap_wc() allocates (page tables) and bo_lock is taken from the
	 * free_job path that recovery waits for (lockdep: bo_lock -> fs_reclaim -> dma_fence_map
	 * -> work_free_job -> bo_lock). Unplug is what releases BO DMA memory, and it first
	 * synchronises with every drm_dev_enter() section, so this guard is sufficient; the
	 * mapping itself holds a GEM reference, so .free() cannot race with us either.
	 */
	if (!drm_dev_enter(&bo->sdev->drm, &idx))
		return -ENODEV;		/* drm_gem_mmap_obj() drops the mapping reference */
	ret = dma_mmap_wc(bo->sdev->dev, vma, bo->vaddr, bo->dma, vma->vm_end - vma->vm_start);
	drm_dev_exit(idx);
	/* on error drm_gem_mmap_obj() drops the mapping reference */
	return ret;
}

static struct dma_buf *sfg1_bo_export(struct drm_gem_object *obj, int flags)
{
	return ERR_PTR(-EPERM);	/* BOs are never shareable across processes */
}

struct drm_gem_object *sfg1_prime_import_denied(struct drm_device *dev, struct dma_buf *buf)
{
	return ERR_PTR(-EPERM);
}

static const struct vm_operations_struct sfg1_vm_ops = {
	.open = drm_gem_vm_open,
	.close = drm_gem_vm_close,
};

static const struct drm_gem_object_funcs sfg1_gem_funcs = {
	.free = sfg1_bo_free,
	.mmap = sfg1_bo_mmap,
	.export = sfg1_bo_export,
	.vm_ops = &sfg1_vm_ops,
};

bool sfg1_is_bo(const struct drm_gem_object *obj)
{
	return obj->funcs == &sfg1_gem_funcs;
}

static void sfg1_peak_update(atomic64_t *peak, s64 val)
{
	s64 old = atomic64_read(peak);

	while (val > old && !atomic64_try_cmpxchg(peak, &old, val))
		;
}

int sfg1_ioctl_bo_create(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct sfg1_device *sdev = to_sfg1(drm);
	struct sfg1_ctx *ctx = file->driver_priv;
	struct drm_sfg1_bo_create *args = data;
	struct sfg1_cfg *cfg = &sdev->cfg;
	struct sfg1_bo *bo;
	u64 size;
	s64 ctx_bytes, total;
	u32 handle;
	int idx, ret;

	if (args->flags || args->reserved)
		return -EINVAL;
	/*
	 * cfg->max_bo_size is page-aligned and far below U64_MAX (enforced in
	 * sfg1_cfg_load), so after this test PAGE_ALIGN() cannot overflow and
	 * cannot exceed the limit.
	 */
	if (!args->size || args->size > cfg->max_bo_size)
		return -EINVAL;
	size = PAGE_ALIGN(args->size);

	if (!drm_dev_enter(drm, &idx))
		return -ENODEV;

	ret = sfg1_ctx_usable(ctx);
	if (ret)
		goto out_exit;

	/* Charge quotas first; refund on any failure. Nothing is allocated yet. */
	if (atomic_inc_return(&ctx->bo_count) > cfg->max_bos) {
		ret = -ENOSPC;
		goto err_count;
	}
	ctx_bytes = atomic64_add_return(size, &ctx->bo_bytes);
	if (ctx_bytes > (s64)cfg->max_bo_bytes) {
		ret = -ENOSPC;
		goto err_ctx_bytes;
	}
	total = atomic64_add_return(size, &sdev->total_bo_bytes);
	if (total > (s64)cfg->max_total_bo_bytes) {
		ret = -ENOSPC;
		goto err_total;
	}

	bo = kzalloc(sizeof(*bo), GFP_KERNEL);
	if (!bo) {
		ret = -ENOMEM;
		goto err_total;
	}
	bo->vaddr = dma_alloc_wc(sdev->dev, size, &bo->dma, GFP_KERNEL | __GFP_ZERO | __GFP_NOWARN);
	if (!bo->vaddr) {
		kfree(bo);
		ret = -ENOMEM;
		goto err_total;
	}
	memset(bo->vaddr, 0, size);		/* never rely on the allocator for isolation */

	bo->sdev = sdev;
	bo->size = size;
	bo->ctx = sfg1_ctx_get(ctx);
	drm_gem_private_object_init(drm, &bo->base, size);
	bo->base.funcs = &sfg1_gem_funcs;

	/*
	 * From here on, failure is handled by dropping the GEM reference.
	 * The (test-only) audit hook may allocate, so it runs BEFORE bo_lock is taken: bo_lock
	 * must never be held across an allocation (see sfg1_drv.h locking notes).
	 */
	if (sdev->ops->dma_region_add)
		sdev->ops->dma_region_add(sdev, bo->dma, bo->vaddr, size, ctx->serial);
	mutex_lock(&sdev->bo_lock);
	list_add_tail(&bo->node, &sdev->bo_list);
	mutex_unlock(&sdev->bo_lock);

	sfg1_peak_update(&ctx->bo_bytes_peak, ctx_bytes);

	ret = drm_gem_create_mmap_offset(&bo->base);
	if (ret) {
		drm_gem_object_put(&bo->base);
		goto out_exit;
	}
	ret = drm_gem_handle_create(file, &bo->base, &handle);
	args->mmap_offset = drm_vma_node_offset_addr(&bo->base.vma_node);
	drm_gem_object_put(&bo->base);	/* the handle (if created) owns it now */
	if (ret)
		goto out_exit;

	args->handle = handle;
	args->real_size = size;
	drm_dev_exit(idx);
	return 0;

err_total:
	atomic64_sub(size, &sdev->total_bo_bytes);
err_ctx_bytes:
	atomic64_sub(size, &ctx->bo_bytes);
err_count:
	atomic_dec(&ctx->bo_count);
out_exit:
	drm_dev_exit(idx);
	return ret;
}
