// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 PCI glue: BAR0 mapping, DMA mask, MSI-X/MSI/INTx, shutdown, AER stub.
 *
 * PRIVILEGED HARDWARE INTEGRATION POINT. Nothing in this file has been run
 * against real hardware (none existed); see docs/07-hw-bringup.md.
 *
 * PCI vendor/device IDs: none are assigned to SF-G1 in any document available
 * when this was written, and none are invented here. The static table is empty
 * unless the build defines SFG1_PCI_VENDOR_ID / SFG1_PCI_DEVICE_ID, e.g.
 *     make SFG1_PCI_VENDOR_ID=0x1234 SFG1_PCI_DEVICE_ID=0x5678
 * or bind at runtime:  echo "<vid> <did>" > /sys/bus/pci/drivers/sfg1/new_id
 * Either way the driver then verifies SFG1_REG_ID before trusting the device.
 */
#include <linux/dma-mapping.h>
#include <linux/interrupt.h>
#include <linux/module.h>
#include <linux/pci.h>

#include "sfg1_drv.h"

struct sfg1_pci {
	struct pci_dev *pdev;
	void __iomem *bar0;
};

static u32 sfg1_pci_rd32(struct sfg1_device *sdev, u32 off)
{
	struct sfg1_pci *p = sdev->backend;

	return readl(p->bar0 + off);
}

static void sfg1_pci_wr32(struct sfg1_device *sdev, u32 off, u32 val)
{
	struct sfg1_pci *p = sdev->backend;

	writel(val, p->bar0 + off);
}

static void sfg1_pci_disable_dma(struct sfg1_device *sdev)
{
	struct sfg1_pci *p = sdev->backend;

	pci_clear_master(p->pdev);	/* the function can no longer initiate DMA */
}

static const struct sfg1_backend_ops sfg1_pci_ops = {
	.rd32 = sfg1_pci_rd32,
	.wr32 = sfg1_pci_wr32,
	.disable_dma = sfg1_pci_disable_dma,
};

static int sfg1_pci_probe(struct pci_dev *pdev, const struct pci_device_id *id)
{
	struct sfg1_device *sdev;
	struct sfg1_pci *p;
	unsigned long irqf;
	int ret, nvec;

	ret = pcim_enable_device(pdev);
	if (ret)
		return ret;

	if (!(pci_resource_flags(pdev, SFG1_BAR0) & IORESOURCE_MEM) ||
	    pci_resource_len(pdev, SFG1_BAR0) < SFG1_BAR0_MIN_SIZE) {
		dev_err(&pdev->dev, "BAR0 is not a >= %#x byte MMIO region\n", SFG1_BAR0_MIN_SIZE);
		return -ENODEV;
	}

	p = devm_kzalloc(&pdev->dev, sizeof(*p), GFP_KERNEL);
	if (!p)
		return -ENOMEM;
	p->pdev = pdev;
	p->bar0 = pcim_iomap_region(pdev, SFG1_BAR0, SFG1_DRV_NAME);
	if (IS_ERR(p->bar0))
		return PTR_ERR(p->bar0);

	sdev = sfg1_device_create(&pdev->dev, &sfg1_pci_ops, p);
	if (IS_ERR(sdev))
		return PTR_ERR(sdev);
	pci_set_drvdata(pdev, sdev);

	/*
	 * Hardware rule R3 (docs/02-hw-interface.md): the device must not use Relaxed
	 * Ordering or No-Snoop for SQ reads, CQ writes or interrupt messages, because the
	 * phase-bit protocol and "CQE before interrupt" depend on strict posted-write
	 * ordering and on coherent (snooped) access to the queue memory. Do not rely on
	 * firmware having left these disabled.
	 */
	pcie_capability_clear_word(pdev, PCI_EXP_DEVCTL,
				   PCI_EXP_DEVCTL_RELAX_EN | PCI_EXP_DEVCTL_NOSNOOP_EN);

	/* Identify the device before it may become a bus master. */
	ret = sfg1_hw_discover(sdev);
	if (ret)
		return ret;

	ret = dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(sdev->dma_bits));
	if (ret) {
		dev_err(&pdev->dev, "no usable %u-bit DMA mask (%d)\n", sdev->dma_bits, ret);
		return ret;
	}

	nvec = pci_alloc_irq_vectors(pdev, 1, 1, PCI_IRQ_MSIX | PCI_IRQ_MSI | PCI_IRQ_INTX);
	if (nvec < 0)
		return nvec;
	irqf = (pdev->msi_enabled || pdev->msix_enabled) ? 0 : IRQF_SHARED;

	pci_set_master(pdev);
	ret = sfg1_device_bringup(sdev, pci_irq_vector(pdev, 0), irqf);
	if (ret) {
		pci_clear_master(pdev);
		pci_free_irq_vectors(pdev);
		return ret;
	}
	return 0;
}

static void sfg1_pci_remove(struct pci_dev *pdev)
{
	struct sfg1_device *sdev = pci_get_drvdata(pdev);

	sfg1_device_remove(sdev);	/* quiesces, clears bus mastering, frees the IRQ */
	pci_free_irq_vectors(pdev);
}

static void sfg1_pci_shutdown(struct pci_dev *pdev)
{
	struct sfg1_device *sdev = pci_get_drvdata(pdev);

	/* kexec/reboot: stop DMA so the next kernel does not inherit a bus master. */
	sfg1_hw_quiesce(sdev);
	pci_clear_master(pdev);
}

/*
 * AER recovery is NOT implemented in v1: the device is treated as lost and the
 * PCI core removes it, which runs sfg1_pci_remove() (safe-removal path).
 */
static pci_ers_result_t sfg1_pci_error_detected(struct pci_dev *pdev, pci_channel_state_t state)
{
	struct sfg1_device *sdev = pci_get_drvdata(pdev);

	dev_err(&pdev->dev, "PCI error (channel state %d): treating the device as lost\n", state);
	WRITE_ONCE(sdev->hw_gone, true);
	return PCI_ERS_RESULT_DISCONNECT;
}

static const struct pci_error_handlers sfg1_pci_err_handler = {
	.error_detected = sfg1_pci_error_detected,
};

static const struct pci_device_id sfg1_pci_ids[] = {
#if defined(SFG1_PCI_VENDOR_ID) && defined(SFG1_PCI_DEVICE_ID)
	{ PCI_DEVICE(SFG1_PCI_VENDOR_ID, SFG1_PCI_DEVICE_ID) },
#endif
	{ }
};
MODULE_DEVICE_TABLE(pci, sfg1_pci_ids);

static struct pci_driver sfg1_pci_driver = {
	.name = SFG1_DRV_NAME,
	.id_table = sfg1_pci_ids,
	.probe = sfg1_pci_probe,
	.remove = sfg1_pci_remove,
	.shutdown = sfg1_pci_shutdown,
	.err_handler = &sfg1_pci_err_handler,
};

int sfg1_pci_register(void)
{
	return pci_register_driver(&sfg1_pci_driver);
}

void sfg1_pci_unregister(void)
{
	pci_unregister_driver(&sfg1_pci_driver);
}
