// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 process contexts.
 *
 * One context per open file descriptor. A context owns:
 *   - a hardware context slot = a fixed, disjoint window of device memory
 *     (window = slot * ctx_win_size, enforced by the device from SQ.ctx_id);
 *   - a drm_sched entity (fair scheduling between contexts);
 *   - quotas / counters (resource accounting);
 *   - a table of job results awaiting WAIT_JOB.
 *
 * Isolation of device memory between consecutive owners of a slot is by
 * scrubbing: the window is zeroed by the device (OP_SCRUB) before a new owner
 * may use it. If the device cannot scrub, the slot is quarantined, never reused.
 */
#include <linux/delay.h>
#include <linux/minmax.h>
#include <linux/overflow.h>

#include <drm/drm_file.h>
#include <drm/drm_print.h>

#include "sfg1_drv.h"

static void sfg1_ctx_release(struct kref *ref)
{
	struct sfg1_ctx *ctx = container_of(ref, struct sfg1_ctx, ref);

	xa_destroy(&ctx->results);
	kfree(ctx);
}

void sfg1_ctx_put(struct sfg1_ctx *ctx)
{
	kref_put(&ctx->ref, sfg1_ctx_release);
}

/* 0 if the context may use the device, else the errno documented in the UAPI. */
int sfg1_ctx_usable(struct sfg1_ctx *ctx)
{
	enum sfg1_state st = READ_ONCE(ctx->sdev->state);

	if (st == SFG1_STATE_REMOVED || st == SFG1_STATE_DEAD ||
	    test_bit(SFG1_CTXF_DEVICE_GONE, &ctx->flags))
		return -ENODEV;
	if (test_bit(SFG1_CTXF_BANNED, &ctx->flags))
		return -ECANCELED;
	if (test_bit(SFG1_CTXF_LOST, &ctx->flags))
		return -ECONNRESET;
	return 0;
}

static u32 sfg1_ctx_state_bits(const struct sfg1_ctx *ctx)
{
	u32 s = 0;

	if (test_bit(SFG1_CTXF_BANNED, &ctx->flags))
		s |= DRM_SFG1_CTX_BANNED;
	if (test_bit(SFG1_CTXF_LOST, &ctx->flags))
		s |= DRM_SFG1_CTX_LOST;
	if (test_bit(SFG1_CTXF_DEVICE_GONE, &ctx->flags) ||
	    READ_ONCE(ctx->sdev->state) == SFG1_STATE_REMOVED ||
	    READ_ONCE(ctx->sdev->state) == SFG1_STATE_DEAD)
		s |= DRM_SFG1_CTX_DEVICE_GONE;
	return s;
}

void sfg1_ctx_note_strike(struct sfg1_ctx *ctx)
{
	if (atomic_inc_return(&ctx->strikes) >= ctx->sdev->cfg.strike_limit &&
	    !test_and_set_bit(SFG1_CTXF_BANNED, &ctx->flags))
		dev_warn(ctx->sdev->dev, "context %u banned after %d hangs/errors\n", ctx->id,
			 atomic_read(&ctx->strikes));
}

/*
 * Kernel-internal job: zero the whole device-memory window of @ctx_id.
 * Uses the kernel entity so it needs no user context. Uninterruptible and
 * bounded: it runs from open()/close() where a pending SIGKILL must not make
 * us skip the scrub.
 *
 * The verdict comes from the scrub job's OWN recorded result (not from the
 * scheduler's fence error, which reports -ECANCELED for every job that was on
 * the device during a reset): a scrub that was merely caught in someone else's
 * reset is TRANSIENT; only a scrub command that itself timed out or errored is
 * FAILED.
 */
enum sfg1_scrub_result sfg1_scrub_window(struct sfg1_device *sdev, u32 ctx_id)
{
	enum sfg1_scrub_result verdict = SFG1_SCRUB_TRANSIENT;
	struct sfg1_result *res;
	struct sfg1_job *job;
	struct dma_fence *fence;
	long r;
	u32 st;
	int ret;

	job = kvzalloc(struct_size(job, cmds, 1), GFP_KERNEL);
	if (!job)
		return SFG1_SCRUB_TRANSIENT;
	job->hw_fence = kzalloc(sizeof(*job->hw_fence), GFP_KERNEL);
	res = kzalloc(sizeof(*res), GFP_KERNEL);
	if (!job->hw_fence || !res) {
		kfree(job->hw_fence);
		kfree(res);
		kvfree(job);
		return SFG1_SCRUB_TRANSIENT;
	}
	kref_init(&res->ref);
	kref_get(&res->ref);			/* one for the job, one for us */
	res->status = SFG1_RESULT_UNSET;
	job->res = res;
	job->sdev = sdev;
	job->n_cmds = 1;
	INIT_LIST_HEAD(&job->node);
	job->cmds[0].opcode = cpu_to_le16(SFG1_OP_SCRUB);
	job->cmds[0].ctx_id = cpu_to_le16(ctx_id);

	ret = drm_sched_job_init(&job->base, &sdev->kentity, 1, NULL, 0);
	if (ret) {
		kfree(job->hw_fence);
		kvfree(job);
		sfg1_result_put(res);		/* the job's reference */
		sfg1_result_put(res);		/* ours */
		return SFG1_SCRUB_TRANSIENT;
	}
	drm_sched_job_arm(&job->base);
	fence = dma_fence_get(&job->base.s_fence->finished);
	drm_sched_entity_push_job(&job->base);	/* free_job() releases the job and its ref */

	r = dma_fence_wait_timeout(fence, false,
				   msecs_to_jiffies(sdev->cfg.job_timeout_ms * 4 + 1000));
	if (r > 0) {
		/* pairs with smp_store_release() in sfg1_job_set_result() */
		st = smp_load_acquire(&res->status);
		if (st == DRM_SFG1_JOB_OK)
			verdict = SFG1_SCRUB_OK;
		else if (st == DRM_SFG1_JOB_TIMEOUT || st == DRM_SFG1_JOB_ERROR)
			verdict = SFG1_SCRUB_FAILED;
	}
	dma_fence_put(fence);
	sfg1_result_put(res);
	return verdict;
}

/*
 * Scrub a window, attributing failures. Returns 0 (clean), -ENODEV (hardware
 * gone: moot), -EIO (the scrub command itself failed twice: the device cannot
 * scrub this window) or -EAGAIN (could not complete: transient, NOT a verdict
 * on the slot). Only -EIO justifies quarantining the slot.
 */
static int sfg1_scrub_retry(struct sfg1_device *sdev, u32 ctx_id)
{
	int attempt, hard = 0;

	for (attempt = 0; attempt < 6; attempt++) {
		enum sfg1_scrub_result v = sfg1_scrub_window(sdev, ctx_id);
		enum sfg1_state st = READ_ONCE(sdev->state);

		if (v == SFG1_SCRUB_OK)
			return 0;
		if (st == SFG1_STATE_DEAD || st == SFG1_STATE_REMOVED)
			return -ENODEV;
		if (v == SFG1_SCRUB_FAILED && ++hard >= 2)
			return -EIO;
		msleep(25 + 50 * attempt);	/* back off: a recovery is probably running */
	}
	return -EAGAIN;
}

static void sfg1_slot_release(struct sfg1_device *sdev, struct sfg1_ctx *ctx, bool clean,
			      bool quarantine)
{
	mutex_lock(&sdev->ctx_lock);
	list_del_init(&ctx->node);
	sdev->slots[ctx->id].ctx = NULL;
	sdev->slots[ctx->id].needs_scrub = !clean;
	if (quarantine) {
		sdev->slots[ctx->id].quarantine_until =
			jiffies + msecs_to_jiffies(sdev->cfg.quarantine_ms) ?: 1;
		dev_warn(sdev->dev,
			 "context window %u: the scrub command failed repeatedly; withheld for %u ms\n",
			 ctx->id, sdev->cfg.quarantine_ms);
	}
	mutex_unlock(&sdev->ctx_lock);
}

int sfg1_open(struct drm_device *drm, struct drm_file *file)
{
	struct sfg1_device *sdev = to_sfg1(drm);
	struct sfg1_ctx *ctx;
	u32 i, slot = U32_MAX;
	enum sfg1_state st;
	bool scrub;
	int idx, ret;

	if (!drm_dev_enter(drm, &idx))
		return -ENODEV;

	st = READ_ONCE(sdev->state);
	if (st != SFG1_STATE_RUNNING && st != SFG1_STATE_RESETTING) {
		ret = -ENODEV;
		goto out;
	}

	/* allocate everything before taking ctx_lock (it is on the signalling path) */
	ctx = kzalloc(sizeof(*ctx), GFP_KERNEL);
	if (!ctx) {
		ret = -ENOMEM;
		goto out;
	}
	kref_init(&ctx->ref);
	ctx->sdev = sdev;
	init_waitqueue_head(&ctx->idle_wq);
	xa_init(&ctx->results);
	INIT_LIST_HEAD(&ctx->node);
	ret = drm_sched_entity_init(&ctx->entity, DRM_SCHED_PRIORITY_NORMAL, sdev->sched_list, 1,
				    NULL);
	if (ret) {
		xa_destroy(&ctx->results);
		kfree(ctx);
		goto out;
	}

	mutex_lock(&sdev->ctx_lock);
	for (i = 0; i < sdev->max_ctx; i++) {
		if (!sdev->slots[i].ctx && !sfg1_slot_quarantined(&sdev->slots[i])) {
			slot = i;
			break;
		}
	}
	if (slot == U32_MAX) {
		mutex_unlock(&sdev->ctx_lock);
		ret = -EBUSY;			/* all hardware contexts in use */
		goto err_entity;
	}
	sdev->slots[slot].ctx = ctx;
	ctx->id = slot;
	ctx->serial = ++sdev->ctx_serial;
	scrub = sdev->slots[slot].needs_scrub;
	list_add_tail(&ctx->node, &sdev->ctx_list);
	mutex_unlock(&sdev->ctx_lock);

	if (scrub) {
		ret = sfg1_scrub_retry(sdev, slot);
		if (ret) {
			/* only a scrub COMMAND that failed (-EIO) puts the slot on cooldown */
			sfg1_slot_release(sdev, ctx, false, ret == -EIO);
			goto err_entity;
		}
		mutex_lock(&sdev->ctx_lock);
		sdev->slots[slot].needs_scrub = false;
		mutex_unlock(&sdev->ctx_lock);
	}

	if (READ_ONCE(sdev->ops)->ctx_bind)
		READ_ONCE(sdev->ops)->ctx_bind(sdev, slot, ctx->serial);
	file->driver_priv = ctx;
	drm_dev_exit(idx);
	return 0;

err_entity:
	drm_sched_entity_destroy(&ctx->entity);
	if (!list_empty(&ctx->node))
		sfg1_slot_release(sdev, ctx, false, false);
	sfg1_ctx_put(ctx);
out:
	drm_dev_exit(idx);
	return ret;
}

void sfg1_postclose(struct drm_device *drm, struct drm_file *file)
{
	struct sfg1_device *sdev = to_sfg1(drm);
	struct sfg1_ctx *ctx = file->driver_priv;
	struct sfg1_result *res;
	enum sfg1_state st;
	unsigned long idx;
	bool clean = false, hard_fail = false;

	if (!ctx)
		return;
	file->driver_priv = NULL;
	set_bit(SFG1_CTXF_CLOSING, &ctx->flags);

	/* Queued jobs are drained or killed; nothing new can start. */
	drm_sched_entity_destroy(&ctx->entity);

	/*
	 * Jobs already on the device still hold BO references and may still
	 * be DMA-ing. Wait until every job of this context has been freed.
	 */
	if (wait_event_timeout(ctx->idle_wq, !atomic_read(&ctx->jobs_alive),
			       msecs_to_jiffies(sdev->cfg.job_timeout_ms * 4 + 1000))) {
		st = READ_ONCE(sdev->state);
		if (st == SFG1_STATE_RUNNING || st == SFG1_STATE_RESETTING) {
			int sr = sfg1_scrub_retry(sdev, ctx->id);

			clean = sr == 0;
			hard_fail = sr == -EIO;
		}
	} else {
		dev_warn(sdev->dev, "context %u: jobs still alive at close; window will be scrubbed on reuse\n",
			 ctx->id);
	}

	if (READ_ONCE(sdev->ops)->ctx_bind)
		READ_ONCE(sdev->ops)->ctx_bind(sdev, ctx->id, 0);
	/* not clean => "needs scrub" at next open; only a failing scrub command quarantines */
	sfg1_slot_release(sdev, ctx, clean, hard_fail);

	xa_for_each(&ctx->results, idx, res) {
		xa_erase(&ctx->results, idx);
		sfg1_result_put(res);
	}
	sfg1_ctx_put(ctx);	/* BOs that outlive the file keep it alive for accounting */
}

/* ------------------------------------------------------------------------ */
/* ioctls and fdinfo                                                         */
/* ------------------------------------------------------------------------ */
int sfg1_ioctl_get_param(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct sfg1_device *sdev = to_sfg1(drm);
	struct sfg1_ctx *ctx = file->driver_priv;
	struct drm_sfg1_get_param *args = data;
	u64 v;
	int idx;

	if (args->pad)
		return -EINVAL;
	if (!drm_dev_enter(drm, &idx))
		return -ENODEV;

	switch (args->param) {
	case DRM_SFG1_PARAM_UAPI_VERSION:
		v = (DRM_SFG1_UAPI_MAJOR << 16) | DRM_SFG1_UAPI_MINOR;
		break;
	case DRM_SFG1_PARAM_HW_VERSION:
		v = sdev->hw_version;
		break;
	case DRM_SFG1_PARAM_HW_CAPS:
		v = sdev->caps;
		break;
	case DRM_SFG1_PARAM_CTX_ID:
		v = ctx->id;
		break;
	case DRM_SFG1_PARAM_CTX_WINDOW_SIZE:
		v = sdev->ctx_win_size;
		break;
	case DRM_SFG1_PARAM_MAX_BO_SIZE:
		v = sdev->cfg.max_bo_size;
		break;
	case DRM_SFG1_PARAM_MAX_BOS:
		v = sdev->cfg.max_bos;
		break;
	case DRM_SFG1_PARAM_MAX_BO_BYTES:
		v = sdev->cfg.max_bo_bytes;
		break;
	case DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT:
		v = min_t(u32, SFG1_MAX_CMDS_PER_SUBMIT, sdev->sq.entries - 1);
		break;
	case DRM_SFG1_PARAM_MAX_INFLIGHT_JOBS:
		v = sdev->cfg.max_inflight_jobs;
		break;
	case DRM_SFG1_PARAM_MAX_PENDING_RESULTS:
		v = sdev->cfg.max_pending_results;
		break;
	case DRM_SFG1_PARAM_JOB_TIMEOUT_MS:
		v = sdev->cfg.job_timeout_ms;
		break;
	case DRM_SFG1_PARAM_CTX_STATE:
		v = sfg1_ctx_state_bits(ctx);
		break;
	case DRM_SFG1_PARAM_VEC_OPS:
		v = (sdev->caps & SFG1_CAP_VEC) ? GENMASK(SFG1_VEC_OP_MAX, 0) : 0;
		break;
	default:
		drm_dev_exit(idx);
		return -EINVAL;
	}
	args->value = v;
	drm_dev_exit(idx);
	return 0;
}

int sfg1_ioctl_get_stats(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct sfg1_device *sdev = to_sfg1(drm);
	struct sfg1_ctx *ctx = file->driver_priv;
	struct drm_sfg1_get_stats *s = data;
	int idx, i;

	for (i = 0; i < ARRAY_SIZE(s->reserved); i++)
		if (s->reserved[i])
			return -EINVAL;
	if (!drm_dev_enter(drm, &idx))
		return -ENODEV;

	memset(s, 0, sizeof(*s));
	s->ctx_id = ctx->id;
	s->ctx_state = sfg1_ctx_state_bits(ctx);
	s->bo_count = atomic_read(&ctx->bo_count);
	s->bo_bytes = atomic64_read(&ctx->bo_bytes);
	s->bo_bytes_peak = atomic64_read(&ctx->bo_bytes_peak);
	s->jobs_submitted = atomic64_read(&ctx->jobs_submitted);
	s->jobs_ok = atomic64_read(&ctx->jobs_ok);
	s->jobs_error = atomic64_read(&ctx->jobs_error);
	s->jobs_timeout = atomic64_read(&ctx->jobs_timeout);
	s->jobs_canceled = atomic64_read(&ctx->jobs_canceled);
	s->cmds_submitted = atomic64_read(&ctx->cmds_submitted);
	s->busy_ns = atomic64_read(&ctx->busy_ns);
	s->device_engine_resets = sdev->engine_resets;
	s->device_func_resets = sdev->func_resets;
	drm_dev_exit(idx);
	return 0;
}

static u32 sfg1_count_quarantined(struct sfg1_device *sdev)
{
	u32 i, n = 0;

	mutex_lock(&sdev->ctx_lock);
	for (i = 0; i < sdev->max_ctx; i++)
		n += sfg1_slot_quarantined(&sdev->slots[i]);
	mutex_unlock(&sdev->ctx_lock);
	return n;
}

/* /proc/<pid>/fdinfo/<fd>; key names follow Documentation/gpu/drm-usage-stats.rst */
void sfg1_show_fdinfo(struct drm_printer *p, struct drm_file *file)
{
	struct sfg1_ctx *ctx = file->driver_priv;
	u64 bo_kib;

	if (!ctx)
		return;
	bo_kib = (u64)atomic64_read(&ctx->bo_bytes) >> 10;
	drm_printf(p, "drm-engine-compute:\t%llu ns\n", (u64)atomic64_read(&ctx->busy_ns));
	drm_printf(p, "drm-total-memory:\t%llu KiB\n", bo_kib);
	drm_printf(p, "drm-resident-memory:\t%llu KiB\n", bo_kib);
	drm_printf(p, "drm-peak-memory:\t%llu KiB\n",
		   (u64)atomic64_read(&ctx->bo_bytes_peak) >> 10);
	drm_printf(p, "sfg1-ctx-id:\t%u\n", ctx->id);
	drm_printf(p, "sfg1-quarantined-windows:\t%u\n", sfg1_count_quarantined(ctx->sdev));
	drm_printf(p, "sfg1-ctx-state:\t%#x\n", sfg1_ctx_state_bits(ctx));
	drm_printf(p, "sfg1-jobs-submitted:\t%llu\n", (u64)atomic64_read(&ctx->jobs_submitted));
	drm_printf(p, "sfg1-jobs-failed:\t%llu\n",
		   (u64)atomic64_read(&ctx->jobs_error) + atomic64_read(&ctx->jobs_timeout));
	drm_printf(p, "sfg1-jobs-canceled:\t%llu\n", (u64)atomic64_read(&ctx->jobs_canceled));
}
