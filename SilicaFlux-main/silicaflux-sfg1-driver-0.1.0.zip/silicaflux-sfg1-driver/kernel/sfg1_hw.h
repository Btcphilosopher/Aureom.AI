/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * SilicaFlux SF-G1 — host/device hardware contract (DRAFT v1.0 proposal).
 *
 * IMPORTANT: no SF-G1 hardware specification existed when this was written.
 * This header *is* the proposed contract (see docs/02-hw-interface.md). It
 * reuses vocabulary from the SilicaFlux p40 stand-in RTL (chip ID, opcode
 * numbering, error codes, VEC/TEN op semantics) but is NOT an existing
 * hardware spec. The hardware team must ratify or replace it before this
 * driver is used on silicon. rtl/sfg1_pkg.sv mirrors these constants and is
 * kept in step by tests/check_contract.sh.
 *
 * All registers are 32-bit, little-endian, naturally aligned. 64-bit values
 * are split into LO/HI registers; LO must be written before HI and the pair
 * is only sampled by the device when ENABLE is set.
 */
#ifndef SFG1_HW_H
#define SFG1_HW_H

#include <linux/bits.h>
#include <linux/build_bug.h>
#include <linux/types.h>

/* ---- identity / discovery -------------------------------------------- */
#define SFG1_CHIP_ID			0x53464001u	/* "SF" 0x4001 (p40 CHIP_ID) */
#define SFG1_HW_VERSION_MAJOR		1u		/* driver supports major 1 */
#define SFG1_BAR0			0
#define SFG1_BAR0_MIN_SIZE		0x1000
#define SFG1_ALL_ONES			0xffffffffu	/* read of a dead/absent device */

#define SFG1_REG_ID			0x000	/* RO  == SFG1_CHIP_ID */
#define SFG1_REG_HW_VERSION		0x004	/* RO  [31:16] major [15:8] minor [7:0] patch */
#define SFG1_REG_CAPS			0x008	/* RO  capability bits below */
#define SFG1_REG_LIMITS0		0x00c	/* RO  [15:0] MAX_CTX [31:16] MAX_QUEUE_ENTRIES */
#define SFG1_REG_LIMITS1		0x010	/* RO  [7:0] DMA_ADDR_BITS [31:16] CTX_WIN_KIB */
#define SFG1_REG_DEVMEM_LO		0x014	/* RO  total device-local memory, bytes */
#define SFG1_REG_DEVMEM_HI		0x018	/* RO */

#define SFG1_CAP_ENGINE_RESET		BIT(0)	/* CTRL.ENGINE_RESET supported (mandatory) */
#define SFG1_CAP_FUNC_RESET		BIT(1)	/* RESET register supported (mandatory) */
#define SFG1_CAP_SCRUB			BIT(2)	/* OP_SCRUB supported (mandatory) */
#define SFG1_CAP_VEC			BIT(3)
#define SFG1_CAP_TEN			BIT(4)
#define SFG1_CAPS_REQUIRED \
	(SFG1_CAP_ENGINE_RESET | SFG1_CAP_FUNC_RESET | SFG1_CAP_SCRUB)

#define SFG1_LIMITS0_MAX_CTX		GENMASK(15, 0)
#define SFG1_LIMITS0_MAX_QENT		GENMASK(31, 16)
#define SFG1_LIMITS1_DMA_BITS		GENMASK(7, 0)
#define SFG1_LIMITS1_CTX_WIN_KIB	GENMASK(31, 16)

/* ---- control / status -------------------------------------------------- */
#define SFG1_REG_CTRL			0x020	/* RW */
#define   SFG1_CTRL_ENABLE		BIT(0)	/* fetch+execute SQ; queue regs sampled on 0->1 */
#define   SFG1_CTRL_ENGINE_RESET	BIT(1)	/* W1S, self-clearing; see reset rules */
#define   SFG1_CTRL_CLEAR_HALT		BIT(2)	/* W1S, self-clearing */
#define SFG1_REG_STATUS			0x024	/* RO */
#define   SFG1_STATUS_READY		BIT(0)	/* config interface usable */
#define   SFG1_STATUS_BUSY		BIT(1)
#define   SFG1_STATUS_HALTED		BIT(2)	/* stopped after a command error */
#define   SFG1_STATUS_FATAL		BIT(3)	/* unrecoverable by ENGINE_RESET */
#define   SFG1_STATUS_RESET_ACTIVE	BIT(4)
#define   SFG1_STATUS_LAST_ERR		GENMASK(15, 8)
#define SFG1_REG_RESET			0x028	/* WO  FUNCTION reset, magic below */
#define   SFG1_RESET_MAGIC		0x52455345u	/* "RESE" */

#define SFG1_REG_IRQ_STATUS		0x030	/* RW1C */
#define SFG1_REG_IRQ_MASK		0x034	/* RW, 1 = enabled */
#define   SFG1_IRQ_CQ			BIT(0)	/* >=1 CQE written since last ack */
#define   SFG1_IRQ_ERROR		BIT(1)	/* a command failed, queue HALTED */
#define   SFG1_IRQ_FATAL		BIT(2)	/* device-detected protocol/internal fault */
#define   SFG1_IRQ_ALL			(SFG1_IRQ_CQ | SFG1_IRQ_ERROR | SFG1_IRQ_FATAL)

/* ---- queues ------------------------------------------------------------ */
#define SFG1_REG_SQ_BASE_LO		0x040	/* RW (only while ENABLE=0) */
#define SFG1_REG_SQ_BASE_HI		0x044
#define SFG1_REG_SQ_ENTRIES		0x048	/* power of two, 16..MAX_QUEUE_ENTRIES */
#define SFG1_REG_SQ_TAIL		0x04c	/* RW doorbell: producer index */
#define SFG1_REG_CQ_BASE_LO		0x050
#define SFG1_REG_CQ_BASE_HI		0x054
#define SFG1_REG_CQ_ENTRIES		0x058	/* power of two, >= SQ_ENTRIES */
#define SFG1_REG_CQ_HEAD		0x05c	/* RW doorbell: consumer index */
#define SFG1_REG_SQ_HEAD		0x060	/* RO consumer index (debug only) */
#define SFG1_REG_CQ_TAIL		0x064	/* RO producer index (debug only) */
#define SFG1_REG_DONE_COUNT		0x068	/* RO commands retired, wraps */
#define SFG1_REG_ERR_COUNT		0x06c	/* RO commands failed, wraps */
#define SFG1_REG_HEARTBEAT		0x070	/* RO free-running while ENABLE */
#define SFG1_REG_SCRATCH		0x07c	/* RW, no side effects (probe self-test) */

#define SFG1_QUEUE_ENTRIES_MIN		16u
#define SFG1_QUEUE_ENTRIES_MAX		4096u
#define SFG1_MAX_CTX_LIMIT		256u

/* ---- command opcodes (numbering follows p40 sf_control_core) ----------- */
#define SFG1_OP_NOP			0
#define SFG1_OP_DMA_H2D			1	/* host -> device window */
#define SFG1_OP_VEC			2	/* INT8x4 SIMD op on window words */
#define SFG1_OP_TEN			3	/* 4x4 INT8 matmul tile(s), INT32 acc */
/* 4 is reserved (p40 IRQ opcode) */
#define SFG1_OP_DMA_D2H			5	/* device window -> host */
#define SFG1_OP_SCRUB			6	/* zero the whole window of ctx_id (kernel only) */

/* VEC sub-ops (SQ.exec_op); semantics from p40 sf_vector_cluster */
#define SFG1_VEC_ADD8			0
#define SFG1_VEC_SUB8			1
#define SFG1_VEC_MAX8			2
#define SFG1_VEC_RELU8			3	/* unary on A; dev_b must be 0 */
#define SFG1_VEC_XOR32			4
#define SFG1_VEC_AND32			5
#define SFG1_VEC_MUL8			6	/* low byte of each lane product */
#define SFG1_VEC_DOT8			7	/* C[0] (one word) = sum of lane products */
#define SFG1_VEC_OP_MAX			7

/* SQ.flags */
#define SFG1_CMDF_TEN_ACC		BIT(0)	/* TEN: C += A*B instead of C = A*B */
#define SFG1_CMDF_VALID_MASK		SFG1_CMDF_TEN_ACC

/* ---- completion status codes (numbering follows p40 error codes) ------- */
#define SFG1_ST_OK			0
#define SFG1_ST_BAD_OPCODE		1
#define SFG1_ST_BAD_CTX			2
#define SFG1_ST_ENGINE_DISABLED		3
#define SFG1_ST_BOUNDS			4	/* window range / alignment violation */
#define SFG1_ST_FETCH_ERROR		5	/* SQ entry fetch failed */
#define SFG1_ST_DMA_ERROR		6	/* host DMA fault */
#define SFG1_ST_BAD_ARGS		7	/* reserved bits/flags/exec_op invalid */

/*
 * Submission-queue entry: 64 bytes, little-endian, written by the host.
 * Unused fields and 'rsvd*' MUST be zero; the device raises BAD_ARGS otherwise.
 * The host driver sets cid = SQ slot index.
 */
struct sfg1_sq_entry {
	__le16 opcode;
	__le16 ctx_id;
	__le16 cid;
	__le16 flags;
	__le32 exec_op;
	__le32 rsvd0;
	__le64 host_addr;	/* bus/IOVA; DMA ops only */
	__le64 len;		/* DMA: bytes; VEC: 32-bit words; TEN: tiles */
	__le64 dev_a;		/* window offset: DMA dev addr / operand A */
	__le64 dev_b;		/* operand B */
	__le64 dev_c;		/* operand C (result) */
	__le64 rsvd1;
};
static_assert(sizeof(struct sfg1_sq_entry) == 64);

/*
 * Completion-queue entry: 16 bytes, written by the device. The 16-bit
 * status_phase field (offset 14) is the LAST field the device makes visible:
 *   bit 0      phase tag (device writes 1 on the first lap, toggles each wrap)
 *   bits 15:1  SFG1_ST_* status
 */
struct sfg1_cq_entry {
	__le32 result;		/* op-specific, 0 in v1 */
	__le32 rsvd;
	__le16 sq_head;		/* SQ consumer index after this command */
	__le16 ctx_id;
	__le16 cid;
	__le16 status_phase;
};
static_assert(sizeof(struct sfg1_cq_entry) == 16);
#define SFG1_CQE_PHASE			BIT(0)
#define SFG1_CQE_STATUS_SHIFT		1

#endif /* SFG1_HW_H */
