// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 timeout / fault recovery.
 *
 * There is exactly one recovery path. It is entered from
 *   - drm_sched's timedout_job()   (no CQ progress for job_timeout_ms), and
 *   - drm_sched_fault()            (error CQE / protocol fault, from the IRQ thread),
 *   - reset_work                   (fault while nothing is in flight).
 *
 * Policy (see docs/01-design.md section 6):
 *   1. Final CQ reap. If nothing is actually wrong (lost interrupt, slow but
 *      progressing) return NO_HANG: no reset, no scheduler stop/start.
 *   2. drm_sched_stop(), mask the interrupt, final reap, take ownership of the
 *      in-flight list.
 *   3. ENGINE_RESET (device memory retained). If that fails: FUNCTION reset
 *      (device memory lost). If that fails: DEAD.
 *   4. The oldest in-flight job is the culprit (the device is strictly in
 *      order). It completes TIMEOUT or ERROR and its context gets a strike;
 *      every other in-flight job completes CANCELED. Nothing is replayed:
 *      commands are not idempotent (TEN accumulate) and 6.18 deprecates
 *      drm_sched_resubmit_jobs().
 *   5. After a function reset (or DEAD) all contexts are marked LOST.
 *   6. Restart: jobs not yet handed to the device run normally (or are
 *      cancelled by run_job() if their context is banned/lost).
 */
#include <linux/dma-fence.h>
#include <linux/interrupt.h>

#include "sfg1_drv.h"

void sfg1_fail_all_inflight(struct sfg1_device *sdev, u32 status, int fence_err)
{
	struct sfg1_job *job, *tmp;
	LIST_HEAD(victims);
	bool cookie = dma_fence_begin_signalling();

	spin_lock(&sdev->ring_lock);
	list_splice_init(&sdev->inflight, &victims);
	spin_unlock(&sdev->ring_lock);

	list_for_each_entry_safe(job, tmp, &victims, node) {
		list_del_init(&job->node);
		sfg1_job_finish(job, status, fence_err);
	}
	dma_fence_end_signalling(cookie);
}

void sfg1_mark_all_ctx(struct sfg1_device *sdev, int flag_bit)
{
	struct sfg1_ctx *ctx;
	u32 i;

	mutex_lock(&sdev->ctx_lock);
	list_for_each_entry(ctx, &sdev->ctx_list, node)
		set_bit(flag_bit, &ctx->flags);
	for (i = 0; i < sdev->max_ctx; i++)
		sdev->slots[i].needs_scrub = true;	/* window content now unknown */
	mutex_unlock(&sdev->ctx_lock);
}

static int sfg1_hw_recover(struct sfg1_device *sdev, bool *func_reset)
{
	int ret;

	ret = sfg1_hw_engine_reset(sdev);
	if (!ret) {
		sdev->engine_resets++;
		ret = sfg1_hw_start(sdev);
		if (!ret)
			return 0;
	}
	dev_err(sdev->dev, "engine reset did not recover the device (%d); trying function reset\n",
		ret);

	*func_reset = true;
	ret = sfg1_hw_function_reset(sdev);
	if (ret) {
		dev_err(sdev->dev, "function reset failed (%d)\n", ret);
		return ret;
	}
	sdev->func_resets++;
	return sfg1_hw_start(sdev);
}

static enum drm_gpu_sched_stat sfg1_recover(struct sfg1_device *sdev, struct drm_sched_job *sjob)
{
	struct sfg1_job *guilty, *job, *tmp;
	enum sfg1_fault fault;
	enum sfg1_state state;
	u32 fault_status;
	bool func_reset = false, hung, cookie;
	LIST_HEAD(victims);
	LIST_HEAD(done);
	int ret;

	mutex_lock(&sdev->reset_lock);
	cookie = dma_fence_begin_signalling();

	state = READ_ONCE(sdev->state);
	if (state == SFG1_STATE_REMOVED || state == SFG1_STATE_DEAD) {
		/*
		 * The hardware is out of the picture and whoever changed the
		 * state already failed every in-flight fence. Just let the
		 * scheduler retire what it holds.
		 */
		if (sjob) {
			drm_sched_stop(&sdev->sched, sjob);
			drm_sched_start(&sdev->sched, -ENODEV);
		}
		goto out;
	}

	/* 1. Is anything actually wrong? */
	spin_lock(&sdev->ring_lock);
	sfg1_ring_reap(sdev, &done);
	hung = sdev->fault != SFG1_FAULT_NONE ||
	       (!list_empty(&sdev->inflight) &&
		time_after(jiffies, sdev->last_progress +
				    msecs_to_jiffies(sdev->cfg.job_timeout_ms)));
	spin_unlock(&sdev->ring_lock);
	sfg1_complete_done_jobs(sdev, &done);

	if (!hung) {
		/* Lost interrupt or a slow-but-progressing job. Do not reset. */
		dma_fence_end_signalling(cookie);
		mutex_unlock(&sdev->reset_lock);
		return DRM_GPU_SCHED_STAT_NO_HANG;
	}

	/* 2. Stop the world. */
	drm_sched_stop(&sdev->sched, sjob);

	spin_lock(&sdev->ring_lock);
	sdev->state = SFG1_STATE_RESETTING;
	spin_unlock(&sdev->ring_lock);
	if (sdev->irq_requested)
		disable_irq(sdev->irq);		/* waits for the top half and the thread */

	spin_lock(&sdev->ring_lock);
	sfg1_ring_reap(sdev, &done);		/* CQEs that landed since the check above */
	fault = sdev->fault;
	fault_status = sdev->fault_status;
	sdev->fault = SFG1_FAULT_NONE;
	list_splice_init(&sdev->inflight, &victims);
	spin_unlock(&sdev->ring_lock);
	sfg1_complete_done_jobs(sdev, &done);

	guilty = list_first_entry_or_null(&victims, struct sfg1_job, node);
	dev_warn(sdev->dev, "recovering: %s (status %u), %s job %llu\n",
		 fault == SFG1_FAULT_DEVICE_ERROR ? "device-reported error" :
		 fault == SFG1_FAULT_PROTOCOL ? "protocol violation" : "no forward progress",
		 fault_status, guilty ? "culprit" : "no in-flight",
		 guilty ? guilty->id : 0ULL);

	/* 3. Reset the hardware. */
	ret = sfg1_hw_recover(sdev, &func_reset);

	/* 4. Dispose of every job that was on the device. Never replay. */
	list_for_each_entry_safe(job, tmp, &victims, node) {
		u32 st = DRM_SFG1_JOB_CANCELED;
		int err = -ECANCELED;

		list_del_init(&job->node);
		if (job == guilty) {
			if (fault == SFG1_FAULT_NONE) {
				st = DRM_SFG1_JOB_TIMEOUT;
				err = -ETIMEDOUT;
			} else {
				st = DRM_SFG1_JOB_ERROR;
				err = -EIO;
				if (!job->dev_error)
					job->dev_error = fault_status;
			}
		}
		sfg1_job_finish(job, st, err);
	}
	/* A protocol fault is the hardware's fault, not the user's: no strike. */
	if (guilty && guilty->ctx && fault != SFG1_FAULT_PROTOCOL)
		sfg1_ctx_note_strike(guilty->ctx);

	/* 5. Device memory lost (or device unusable): every context is invalid. */
	if (func_reset || ret)
		sfg1_mark_all_ctx(sdev, SFG1_CTXF_LOST);

	spin_lock(&sdev->ring_lock);
	sdev->state = ret ? SFG1_STATE_DEAD : SFG1_STATE_RUNNING;
	sdev->last_progress = jiffies;
	spin_unlock(&sdev->ring_lock);

	if (ret) {
		dev_err(sdev->dev, "device could not be recovered (%d): marking it dead\n", ret);
		sfg1_hw_quiesce(sdev);
		if (READ_ONCE(sdev->ops)->disable_dma)
			READ_ONCE(sdev->ops)->disable_dma(sdev);
		/* IRQ stays disabled: a dead device must not storm us. */
	} else if (sdev->irq_requested) {
		enable_irq(sdev->irq);
	}

	/* 6. Restart: pending jobs whose parent fence was dropped finish -ECANCELED. */
	drm_sched_start(&sdev->sched, 0);
out:
	dma_fence_end_signalling(cookie);
	mutex_unlock(&sdev->reset_lock);
	return DRM_GPU_SCHED_STAT_RESET;
}

enum drm_gpu_sched_stat sfg1_timedout_job(struct drm_sched_job *sjob)
{
	return sfg1_recover(to_sfg1_job(sjob)->sdev, sjob);
}

void sfg1_reset_work(struct work_struct *work)
{
	struct sfg1_device *sdev = container_of(work, struct sfg1_device, reset_work);

	sfg1_recover(sdev, NULL);
}
