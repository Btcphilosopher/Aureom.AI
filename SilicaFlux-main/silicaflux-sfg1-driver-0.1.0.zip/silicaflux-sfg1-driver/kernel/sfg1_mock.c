// SPDX-License-Identifier: GPL-2.0-only
/*
 * SF-G1 software mock device — TEST ONLY (CONFIG_DRM_ACCEL_SFG1_MOCK).
 *
 * What this is: a software implementation of the register/queue contract in
 * sfg1_hw.h so the *whole* driver (rings, scheduler, IRQ path, reset, unplug,
 * quotas) can run without hardware. It executes DMA / VEC / TEN commands for
 * real so tests can check data, and it can inject faults.
 *
 * What this is NOT: evidence about physical hardware. It follows the same
 * contract the driver was written against, so it shares the contract's
 * assumptions; it has no real PCIe ordering, IOMMU, timing, power or error
 * behaviour. A pass here proves the driver logic is self-consistent with the
 * contract, nothing more (docs/06-limitations.md).
 *
 * Isolation oracle: every host-memory DMA the device performs is checked
 * against the regions the driver registered (dma_region_add): the target must
 * lie inside one registered region AND that region must belong to the context
 * named in the command. Anything else is counted in dma_violations and fails
 * the command with DMA_ERROR. The cross-process tests assert this counter
 * stays 0 under hostile workloads.
 */
#include <linux/bitfield.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/dma-mapping.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/irq_sim.h>
#include <linux/irqdomain.h>
#include <linux/log2.h>
#include <linux/module.h>
#include <linux/overflow.h>
#include <linux/platform_device.h>
#include <linux/sizes.h>
#include <linux/unaligned.h>
#include <linux/vmalloc.h>
#include <linux/workqueue.h>

#include "sfg1_drv.h"

static uint mock_devices;
module_param(mock_devices, uint, 0444);
MODULE_PARM_DESC(mock_devices, "TEST ONLY: number of software SF-G1 devices to create");
static uint mock_max_ctx = 8;
module_param(mock_max_ctx, uint, 0444);
MODULE_PARM_DESC(mock_max_ctx, "mock: hardware contexts (1..256)");
static uint mock_ctx_win_kib = 1024;
module_param(mock_ctx_win_kib, uint, 0444);
MODULE_PARM_DESC(mock_ctx_win_kib, "mock: device-memory window per context, KiB");
static uint mock_cmd_delay_us;
module_param(mock_cmd_delay_us, uint, 0444);
MODULE_PARM_DESC(mock_cmd_delay_us, "mock: artificial latency per command, microseconds");

#define MOCK_OFF_NONE	U32_MAX
#define MOCK_FILL_AFTER_FUNC_RESET 0xdd

struct sfg1_mock_region {
	struct list_head node;
	dma_addr_t dma;
	void *cpu;
	size_t size;
	u64 owner;		/* context serial; 0 = kernel (rings) */
};

struct sfg1_mock {
	struct platform_device *pdev;
	struct sfg1_device *sdev;

	spinlock_t lock;	/* register state; taken from hard-IRQ context too */
	bool enable, halted, hung, fatal, reset_active, executing;
	u32 last_err;
	u32 sq_base_lo, sq_base_hi, sq_entries, sq_tail, sq_head;
	u32 cq_base_lo, cq_base_hi, cq_entries, cq_head, cq_tail, cq_phase;
	u32 irq_status, irq_mask, scratch, done_count, err_count;

	u32 max_ctx, win_kib;
	u64 win_size;
	u8 *devmem;
	u64 ctx_serial[SFG1_MAX_CTX_LIMIT];

	struct mutex region_lock;
	struct list_head regions;

	struct workqueue_struct *wq;
	struct work_struct work;

	struct fwnode_handle *fwnode;
	struct irq_domain *domain;
	int virq;

	/* fault injection (debugfs); U32_MAX / 0 = off */
	u32 inj_hang_after;	/* hang on the command after this many successes */
	u32 inj_fail_after;	/* fail the command after this many successes */
	u32 inj_fail_status;
	u32 inj_drop_irq;	/* swallow the next N interrupt messages */
	u32 inj_reset_mode;	/* 1: ENGINE_RESET sticks; 2: ENGINE and FUNCTION reset stick */
	u32 inj_corrupt_cqe;	/* write a wrong cid in the next CQE */
	u32 cmd_delay_us;	/* per-command latency (debugfs-adjustable at runtime) */
	u32 inj_scrub_fail;	/* every SCRUB command fails (persistent scrub failure) */

	/* observability (debugfs, read-only) */
	u32 st_dma_accesses, st_dma_violations, st_cmds, st_scrubs, st_irqs_sent, st_irqs_dropped;
	struct dentry *dbg;
};

/* ------------------------------------------------------------------------ */
/* host-memory DMA with ownership audit                                      */
/* ------------------------------------------------------------------------ */
/* Copy between device window memory and host memory. Returns SFG1_ST_*. */
static u16 mock_dma(struct sfg1_mock *m, u64 host, void *win, u64 len, u64 owner, bool to_host)
{
	struct sfg1_mock_region *r;
	u16 ret = SFG1_ST_DMA_ERROR;

	mutex_lock(&m->region_lock);
	m->st_dma_accesses++;
	list_for_each_entry(r, &m->regions, node) {
		u64 end;

		if (host < r->dma || check_add_overflow(host, len, &end) || end > r->dma + r->size)
			continue;
		if (r->owner != owner) {
			dev_err(&m->pdev->dev,
				"ISOLATION VIOLATION: dma %#llx+%llu belongs to ctx serial %llu, cmd is for %llu\n",
				host, len, r->owner, owner);
			break;
		}
		if (to_host)
			memcpy((u8 *)r->cpu + (host - r->dma), win, len);
		else
			memcpy(win, (u8 *)r->cpu + (host - r->dma), len);
		mutex_unlock(&m->region_lock);
		return SFG1_ST_OK;
	}
	m->st_dma_violations++;
	mutex_unlock(&m->region_lock);
	return ret;
}

/* Plain access to a registered region (SQ fetch / CQ write), owner 0. */
static void *mock_kern_ptr(struct sfg1_mock *m, u64 addr, u64 len)
{
	struct sfg1_mock_region *r;
	void *p = NULL;

	mutex_lock(&m->region_lock);
	list_for_each_entry(r, &m->regions, node) {
		if (r->owner == 0 && addr >= r->dma && addr + len <= r->dma + r->size) {
			p = (u8 *)r->cpu + (addr - r->dma);
			break;
		}
	}
	mutex_unlock(&m->region_lock);
	return p;
}

/* ------------------------------------------------------------------------ */
/* command execution                                                         */
/* ------------------------------------------------------------------------ */
static bool win_ok(const struct sfg1_mock *m, u64 off, u64 len)
{
	return len <= m->win_size && off <= m->win_size - len;
}

static u32 lane_op(u32 op, u32 a, u32 b)
{
	u32 r = 0;
	int k;

	switch (op) {
	case SFG1_VEC_XOR32:
		return a ^ b;
	case SFG1_VEC_AND32:
		return a & b;
	}
	for (k = 0; k < 4; k++) {
		s8 la = (s8)(a >> (8 * k)), lb = (s8)(b >> (8 * k));
		u8 lr = 0;

		switch (op) {
		case SFG1_VEC_ADD8:
			lr = (u8)(la + lb);
			break;
		case SFG1_VEC_SUB8:
			lr = (u8)(la - lb);
			break;
		case SFG1_VEC_MAX8:
			lr = (u8)(la > lb ? la : lb);
			break;
		case SFG1_VEC_RELU8:
			lr = la < 0 ? 0 : (u8)la;
			break;
		case SFG1_VEC_MUL8:
			lr = (u8)((int)la * (int)lb);
			break;
		}
		r |= (u32)lr << (8 * k);
	}
	return r;
}

static u16 mock_exec(struct sfg1_mock *m, const struct sfg1_sq_entry *e)
{
	const u16 op = le16_to_cpu(e->opcode), ctx = le16_to_cpu(e->ctx_id);
	const u32 flags = le16_to_cpu(e->flags), exec = le32_to_cpu(e->exec_op);
	const u64 len = le64_to_cpu(e->len), a = le64_to_cpu(e->dev_a), b = le64_to_cpu(e->dev_b),
		  c = le64_to_cpu(e->dev_c), host = le64_to_cpu(e->host_addr);
	u64 serial, nbytes, cbytes, i;
	u8 *w;

	if (ctx >= m->max_ctx)
		return SFG1_ST_BAD_CTX;
	if (e->rsvd0 || e->rsvd1)
		return SFG1_ST_BAD_ARGS;
	w = m->devmem + (u64)ctx * m->win_size;

	mutex_lock(&m->region_lock);
	serial = m->ctx_serial[ctx];
	mutex_unlock(&m->region_lock);

	switch (op) {
	case SFG1_OP_NOP:
		if (flags || exec || host || len || a || b || c)
			return SFG1_ST_BAD_ARGS;
		return SFG1_ST_OK;

	case SFG1_OP_SCRUB:
		if (flags || exec || host || len || a || b || c)
			return SFG1_ST_BAD_ARGS;
		if (READ_ONCE(m->inj_scrub_fail))
			return SFG1_ST_ENGINE_DISABLED;
		memset(w, 0, m->win_size);
		m->st_scrubs++;
		return SFG1_ST_OK;

	case SFG1_OP_DMA_H2D:
	case SFG1_OP_DMA_D2H:
		if (!serial)
			return SFG1_ST_BAD_CTX;
		if (flags || exec || b || c)
			return SFG1_ST_BAD_ARGS;
		if (!len || (len | a) & 3)
			return SFG1_ST_BOUNDS;
		if (!win_ok(m, a, len))
			return SFG1_ST_BOUNDS;
		return mock_dma(m, host, w + a, len, serial, op == SFG1_OP_DMA_D2H);

	case SFG1_OP_VEC:
		if (!serial)
			return SFG1_ST_BAD_CTX;
		if (flags || host || exec > SFG1_VEC_OP_MAX)
			return SFG1_ST_BAD_ARGS;
		if (!len || ((a | b | c) & 3) || check_mul_overflow(len, 4ULL, &nbytes))
			return SFG1_ST_BOUNDS;
		if (exec == SFG1_VEC_RELU8 && b)
			return SFG1_ST_BAD_ARGS;
		cbytes = exec == SFG1_VEC_DOT8 ? 4 : nbytes;
		if (!win_ok(m, a, nbytes) || (exec != SFG1_VEC_RELU8 && !win_ok(m, b, nbytes)) ||
		    !win_ok(m, c, cbytes))
			return SFG1_ST_BOUNDS;
		if (exec == SFG1_VEC_DOT8) {
			s32 acc = 0;

			for (i = 0; i < len; i++) {
				u32 x = get_unaligned_le32(w + a + 4 * i);
				u32 y = get_unaligned_le32(w + b + 4 * i);
				int k;

				for (k = 0; k < 4; k++)
					acc += (int)(s8)(x >> (8 * k)) * (int)(s8)(y >> (8 * k));
			}
			put_unaligned_le32((u32)acc, w + c);
			return SFG1_ST_OK;
		}
		for (i = 0; i < len; i++) {
			u32 x = get_unaligned_le32(w + a + 4 * i);
			u32 y = exec == SFG1_VEC_RELU8 ? 0 : get_unaligned_le32(w + b + 4 * i);

			put_unaligned_le32(lane_op(exec, x, y), w + c + 4 * i);
		}
		return SFG1_ST_OK;

	case SFG1_OP_TEN:
		if (!serial)
			return SFG1_ST_BAD_CTX;
		if ((flags & ~SFG1_CMDF_VALID_MASK) || exec || host)
			return SFG1_ST_BAD_ARGS;
		if (!len || ((a | b | c) & 3) || check_mul_overflow(len, 16ULL, &nbytes) ||
		    check_mul_overflow(len, 64ULL, &cbytes))
			return SFG1_ST_BOUNDS;
		if (!win_ok(m, a, nbytes) || !win_ok(m, b, nbytes) || !win_ok(m, c, cbytes))
			return SFG1_ST_BOUNDS;
		for (i = 0; i < len; i++) {
			const s8 *ta = (const s8 *)(w + a + 16 * i);
			const s8 *tb = (const s8 *)(w + b + 16 * i);
			u8 *tc = w + c + 64 * i;
			s32 out[16];
			int r, q, k;

			for (r = 0; r < 4; r++) {
				for (q = 0; q < 4; q++) {
					s32 acc = (flags & SFG1_CMDF_TEN_ACC) ?
						  (s32)get_unaligned_le32(tc + 4 * (4 * r + q)) : 0;

					for (k = 0; k < 4; k++)
						acc += (int)ta[4 * r + k] * (int)tb[4 * k + q];
					out[4 * r + q] = acc;
				}
			}
			for (r = 0; r < 16; r++)
				put_unaligned_le32((u32)out[r], tc + 4 * r);
		}
		return SFG1_ST_OK;
	}
	return SFG1_ST_BAD_OPCODE;
}

/* ------------------------------------------------------------------------ */
/* interrupts                                                                */
/* ------------------------------------------------------------------------ */
/* Called without m->lock held. */
static void mock_send_irq(struct sfg1_mock *m)
{
	unsigned long flags;
	bool drop = false;

	spin_lock_irqsave(&m->lock, flags);
	if (m->inj_drop_irq) {
		m->inj_drop_irq--;
		m->st_irqs_dropped++;
		drop = true;
	} else {
		m->st_irqs_sent++;
	}
	spin_unlock_irqrestore(&m->lock, flags);
	if (!drop)
		irq_set_irqchip_state(m->virq, IRQCHIP_STATE_PENDING, true);
}

/* ------------------------------------------------------------------------ */
/* the engine: strictly in-order, one command at a time                      */
/* ------------------------------------------------------------------------ */
static void mock_work_fn(struct work_struct *w)
{
	struct sfg1_mock *m = container_of(w, struct sfg1_mock, work);
	unsigned long flags;

	for (;;) {
		struct sfg1_sq_entry e;
		struct sfg1_cq_entry cqe = {};
		u64 sq_base, cq_base;
		u32 idx, cq_n, sq_n, cq_idx, phase;
		struct sfg1_sq_entry *sqp;
		struct sfg1_cq_entry *cqp;
		u16 status;
		bool irq;

		spin_lock_irqsave(&m->lock, flags);
		if (!m->enable || m->halted || m->hung || m->fatal || m->sq_head == m->sq_tail) {
			m->executing = false;
			spin_unlock_irqrestore(&m->lock, flags);
			return;
		}
		if (m->inj_hang_after == 0) {
			m->hung = true;			/* wedge: no CQE, SQ_HEAD frozen */
			m->inj_hang_after = MOCK_OFF_NONE;
			m->executing = false;
			spin_unlock_irqrestore(&m->lock, flags);
			return;
		}
		if (m->inj_hang_after != MOCK_OFF_NONE)
			m->inj_hang_after--;
		m->executing = true;
		idx = m->sq_head;
		sq_n = m->sq_entries;
		cq_n = m->cq_entries;
		sq_base = ((u64)m->sq_base_hi << 32) | m->sq_base_lo;
		cq_base = ((u64)m->cq_base_hi << 32) | m->cq_base_lo;
		cq_idx = m->cq_tail;
		phase = m->cq_phase;
		if (((cq_idx + 1) & (cq_n - 1)) == m->cq_head) {	/* CQ would overflow */
			m->fatal = true;
			m->irq_status |= SFG1_IRQ_FATAL;
			m->executing = false;
			spin_unlock_irqrestore(&m->lock, flags);
			mock_send_irq(m);
			return;
		}
		spin_unlock_irqrestore(&m->lock, flags);

		{
			u32 dly = READ_ONCE(m->cmd_delay_us);

			if (dly && dly < 1000)
				udelay(dly);		/* deterministic, no timer dependence */
			else if (dly)
				usleep_range(dly, dly + 50);
		}

		sqp = mock_kern_ptr(m, sq_base + (u64)idx * sizeof(e), sizeof(e));
		if (!sqp) {
			status = SFG1_ST_FETCH_ERROR;
		} else {
			memcpy(&e, sqp, sizeof(e));
			status = mock_exec(m, &e);
			cqe.cid = e.cid;
			cqe.ctx_id = e.ctx_id;
		}

		spin_lock_irqsave(&m->lock, flags);
		if (m->inj_fail_after == 0 && status == SFG1_ST_OK) {
			status = m->inj_fail_status ?: SFG1_ST_ENGINE_DISABLED;
			m->inj_fail_after = MOCK_OFF_NONE;
		} else if (m->inj_fail_after != MOCK_OFF_NONE && m->inj_fail_after) {
			m->inj_fail_after--;
		}
		if (m->inj_corrupt_cqe) {
			m->inj_corrupt_cqe = 0;
			cqe.cid = cpu_to_le16(le16_to_cpu(cqe.cid) ^ 0x7);
		}
		spin_unlock_irqrestore(&m->lock, flags);

		/*
		 * CQE write ordering (hardware rule R3): payload first, the
		 * status_phase field LAST, so a host that sees the phase also
		 * sees the payload.
		 */
		cqe.sq_head = cpu_to_le16((idx + 1) & (sq_n - 1));
		cqp = mock_kern_ptr(m, cq_base + (u64)cq_idx * sizeof(*cqp), sizeof(*cqp));
		if (cqp) {
			memcpy(cqp, &cqe, offsetof(struct sfg1_cq_entry, status_phase));
			dma_wmb();
			WRITE_ONCE(cqp->status_phase,
				   cpu_to_le16((status << SFG1_CQE_STATUS_SHIFT) | phase));
		}

		spin_lock_irqsave(&m->lock, flags);
		m->sq_head = (idx + 1) & (sq_n - 1);
		m->cq_tail = (cq_idx + 1) & (cq_n - 1);
		if (!m->cq_tail)
			m->cq_phase ^= 1;
		m->done_count++;
		m->st_cmds++;
		if (status) {
			m->halted = true;
			m->err_count++;
			m->last_err = status;
			m->irq_status |= SFG1_IRQ_ERROR;
		}
		m->irq_status |= SFG1_IRQ_CQ;	/* after the CQE is visible (rule R3) */
		irq = !!(m->irq_status & m->irq_mask);
		spin_unlock_irqrestore(&m->lock, flags);
		if (irq)
			mock_send_irq(m);
	}
}

/* ------------------------------------------------------------------------ */
/* resets                                                                    */
/* ------------------------------------------------------------------------ */
static void mock_reset(struct sfg1_mock *m, bool function)
{
	unsigned long flags;

	spin_lock_irqsave(&m->lock, flags);
	m->reset_active = true;
	m->enable = false;
	spin_unlock_irqrestore(&m->lock, flags);

	cancel_work_sync(&m->work);	/* engine stopped; a hung one already returned */

	/* spec: device memory is undefined after a function reset (can be large: no irq-off) */
	if (function)
		memset(m->devmem, MOCK_FILL_AFTER_FUNC_RESET, m->win_size * m->max_ctx);

	spin_lock_irqsave(&m->lock, flags);
	m->sq_head = m->sq_tail = m->cq_head = m->cq_tail = 0;
	m->cq_phase = 1;
	m->halted = m->hung = m->executing = false;
	m->irq_status = 0;
	m->last_err = 0;
	if (function) {
		m->fatal = false;
		m->sq_base_lo = m->sq_base_hi = m->cq_base_lo = m->cq_base_hi = 0;
		m->sq_entries = m->cq_entries = 0;
		m->irq_mask = 0;
		m->done_count = m->err_count = 0;
	}
	/* injected stuck resets: READY never returns */
	if (!(function ? m->inj_reset_mode == 2 : m->inj_reset_mode >= 1))
		m->reset_active = false;
	spin_unlock_irqrestore(&m->lock, flags);
}

/* ------------------------------------------------------------------------ */
/* register file                                                             */
/* ------------------------------------------------------------------------ */
static u32 mock_rd32(struct sfg1_device *sdev, u32 off)
{
	struct sfg1_mock *m = sdev->backend;
	unsigned long flags;
	u32 v = 0;

	spin_lock_irqsave(&m->lock, flags);
	switch (off) {
	case SFG1_REG_ID:
		v = SFG1_CHIP_ID;
		break;
	case SFG1_REG_HW_VERSION:
		v = 1u << 16;			/* 1.0.0 */
		break;
	case SFG1_REG_CAPS:
		v = SFG1_CAP_ENGINE_RESET | SFG1_CAP_FUNC_RESET | SFG1_CAP_SCRUB | SFG1_CAP_VEC |
		    SFG1_CAP_TEN;
		break;
	case SFG1_REG_LIMITS0:
		v = FIELD_PREP(SFG1_LIMITS0_MAX_CTX, m->max_ctx) |
		    FIELD_PREP(SFG1_LIMITS0_MAX_QENT, 1024);
		break;
	case SFG1_REG_LIMITS1:
		v = FIELD_PREP(SFG1_LIMITS1_DMA_BITS, 64) |
		    FIELD_PREP(SFG1_LIMITS1_CTX_WIN_KIB, m->win_kib);
		break;
	case SFG1_REG_DEVMEM_LO:
		v = lower_32_bits(m->win_size * m->max_ctx);
		break;
	case SFG1_REG_DEVMEM_HI:
		v = upper_32_bits(m->win_size * m->max_ctx);
		break;
	case SFG1_REG_CTRL:
		v = m->enable ? SFG1_CTRL_ENABLE : 0;
		break;
	case SFG1_REG_STATUS:
		v = (m->reset_active ? SFG1_STATUS_RESET_ACTIVE : SFG1_STATUS_READY) |
		    (m->executing ? SFG1_STATUS_BUSY : 0) | (m->halted ? SFG1_STATUS_HALTED : 0) |
		    (m->fatal ? SFG1_STATUS_FATAL : 0) |
		    FIELD_PREP(SFG1_STATUS_LAST_ERR, m->last_err);
		break;
	case SFG1_REG_IRQ_STATUS:
		v = m->irq_status;
		break;
	case SFG1_REG_IRQ_MASK:
		v = m->irq_mask;
		break;
	case SFG1_REG_SQ_BASE_LO:
		v = m->sq_base_lo;
		break;
	case SFG1_REG_SQ_BASE_HI:
		v = m->sq_base_hi;
		break;
	case SFG1_REG_SQ_ENTRIES:
		v = m->sq_entries;
		break;
	case SFG1_REG_SQ_TAIL:
		v = m->sq_tail;
		break;
	case SFG1_REG_CQ_BASE_LO:
		v = m->cq_base_lo;
		break;
	case SFG1_REG_CQ_BASE_HI:
		v = m->cq_base_hi;
		break;
	case SFG1_REG_CQ_ENTRIES:
		v = m->cq_entries;
		break;
	case SFG1_REG_CQ_HEAD:
		v = m->cq_head;
		break;
	case SFG1_REG_SQ_HEAD:
		v = m->sq_head;
		break;
	case SFG1_REG_CQ_TAIL:
		v = m->cq_tail;
		break;
	case SFG1_REG_DONE_COUNT:
		v = m->done_count;
		break;
	case SFG1_REG_ERR_COUNT:
		v = m->err_count;
		break;
	case SFG1_REG_HEARTBEAT:
		v = (u32)jiffies;
		break;
	case SFG1_REG_SCRATCH:
		v = m->scratch;
		break;
	default:
		v = 0;
	}
	spin_unlock_irqrestore(&m->lock, flags);
	return v;
}

static void mock_wr32(struct sfg1_device *sdev, u32 off, u32 val)
{
	struct sfg1_mock *m = sdev->backend;
	unsigned long flags;
	bool kick = false, irq = false;

	if (off == SFG1_REG_CTRL && (val & SFG1_CTRL_ENGINE_RESET)) {
		mock_reset(m, false);
		return;
	}
	if (off == SFG1_REG_RESET && val == SFG1_RESET_MAGIC) {
		mock_reset(m, true);
		return;
	}

	spin_lock_irqsave(&m->lock, flags);
	switch (off) {
	case SFG1_REG_CTRL:
		if (val & SFG1_CTRL_CLEAR_HALT) {
			m->halted = false;
			kick = true;
		}
		if ((val & SFG1_CTRL_ENABLE) && !m->enable) {
			/* queue registers are sampled on 0 -> 1 */
			if (!is_power_of_2(m->sq_entries) ||
			    m->sq_entries < SFG1_QUEUE_ENTRIES_MIN ||
			    !is_power_of_2(m->cq_entries) || m->cq_entries < m->sq_entries ||
			    m->cq_entries > 1024 || m->sq_entries > 1024) {
				m->fatal = true;
				m->irq_status |= SFG1_IRQ_FATAL;
				irq = !!(m->irq_status & m->irq_mask);
			} else {
				m->enable = true;
				m->sq_head = m->sq_tail = 0;
				m->cq_head = m->cq_tail = 0;
				m->cq_phase = 1;
				kick = true;
			}
		} else if (!(val & SFG1_CTRL_ENABLE)) {
			m->enable = false;
		}
		break;
	case SFG1_REG_IRQ_STATUS:
		m->irq_status &= ~val;		/* W1C */
		irq = !!(m->irq_status & m->irq_mask);	/* rule R6: level semantics */
		break;
	case SFG1_REG_IRQ_MASK:
		m->irq_mask = val & SFG1_IRQ_ALL;
		irq = !!(m->irq_status & m->irq_mask);
		break;
	case SFG1_REG_SQ_BASE_LO:
		if (!m->enable)
			m->sq_base_lo = val;
		break;
	case SFG1_REG_SQ_BASE_HI:
		if (!m->enable)
			m->sq_base_hi = val;
		break;
	case SFG1_REG_SQ_ENTRIES:
		if (!m->enable)
			m->sq_entries = val;
		break;
	case SFG1_REG_CQ_BASE_LO:
		if (!m->enable)
			m->cq_base_lo = val;
		break;
	case SFG1_REG_CQ_BASE_HI:
		if (!m->enable)
			m->cq_base_hi = val;
		break;
	case SFG1_REG_CQ_ENTRIES:
		if (!m->enable)
			m->cq_entries = val;
		break;
	case SFG1_REG_SQ_TAIL:
		if (m->enable && m->sq_entries) {
			m->sq_tail = val & (m->sq_entries - 1);
			kick = true;
		}
		break;
	case SFG1_REG_CQ_HEAD:
		if (m->cq_entries)
			m->cq_head = val & (m->cq_entries - 1);
		break;
	case SFG1_REG_SCRATCH:
		m->scratch = val;
		break;
	default:
		break;
	}
	spin_unlock_irqrestore(&m->lock, flags);

	if (kick)
		queue_work(m->wq, &m->work);
	if (irq)
		mock_send_irq(m);
}

static void mock_region_add(struct sfg1_device *sdev, dma_addr_t dma, void *cpu, size_t size,
			    u64 owner)
{
	struct sfg1_mock *m = sdev->backend;
	struct sfg1_mock_region *r = kzalloc(sizeof(*r), GFP_KERNEL);

	if (!r)
		return;		/* the audit then reports a violation: fails loudly, not silently */
	r->dma = dma;
	r->cpu = cpu;
	r->size = size;
	r->owner = owner;
	mutex_lock(&m->region_lock);
	list_add_tail(&r->node, &m->regions);
	mutex_unlock(&m->region_lock);
}

static void mock_region_del(struct sfg1_device *sdev, dma_addr_t dma)
{
	struct sfg1_mock *m = sdev->backend;
	struct sfg1_mock_region *r, *tmp;

	mutex_lock(&m->region_lock);
	list_for_each_entry_safe(r, tmp, &m->regions, node) {
		if (r->dma == dma) {
			list_del(&r->node);
			kfree(r);
			break;
		}
	}
	mutex_unlock(&m->region_lock);
}

static void mock_ctx_bind(struct sfg1_device *sdev, u32 ctx_id, u64 serial)
{
	struct sfg1_mock *m = sdev->backend;

	if (ctx_id < SFG1_MAX_CTX_LIMIT) {
		mutex_lock(&m->region_lock);
		m->ctx_serial[ctx_id] = serial;
		mutex_unlock(&m->region_lock);
	}
}

static const struct sfg1_backend_ops sfg1_mock_ops = {
	.rd32 = mock_rd32,
	.wr32 = mock_wr32,
	.dma_region_add = mock_region_add,
	.dma_region_del = mock_region_del,
	.ctx_bind = mock_ctx_bind,
};

/* ------------------------------------------------------------------------ */
/* platform device / driver                                                  */
/* ------------------------------------------------------------------------ */

/*
 * Oracle self-test (negative control): a "0 isolation violations" result is
 * only meaningful if the audit can actually see one. Writing to this file makes
 * the model attempt (1) a DMA to an address no region covers and (2) a DMA into
 * a registered user region as the wrong owner. Each must bump dma_violations.
 */
static ssize_t mock_oracle_selftest_write(struct file *f, const char __user *u, size_t n,
					  loff_t *off)
{
	struct sfg1_mock *m = file_inode(f)->i_private;
	struct sfg1_mock_region *r;
	u64 victim_owner = 0;
	dma_addr_t victim = 0;
	u8 scratch[8] = {};

	(void)mock_dma(m, 0x10, scratch, 4, 1, true);	/* (1) unmapped address */

	mutex_lock(&m->region_lock);
	list_for_each_entry(r, &m->regions, node) {
		if (r->owner) {
			victim = r->dma;
			victim_owner = r->owner;
			break;
		}
	}
	mutex_unlock(&m->region_lock);
	if (victim_owner)				/* (2) right address, wrong owner */
		(void)mock_dma(m, victim, scratch, 4, victim_owner + 1, false);
	return n;
}

/*
 * kmemleak positive control: deliberately leak one object so the test can
 * prove the leak detector is live (a "0 leaks" result is otherwise vacuous).
 */
static void *mock_leak_sink;

static noinline void sfg1_mock_leak_selftest(void)
{
	WRITE_ONCE(mock_leak_sink, kzalloc(64, GFP_KERNEL));
	WRITE_ONCE(mock_leak_sink, NULL);	/* the only reference is dropped: a leak */
}

static ssize_t mock_leak_write(struct file *f, const char __user *u, size_t n, loff_t *off)
{
	sfg1_mock_leak_selftest();
	return n;
}

static const struct file_operations mock_leak_fops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = mock_leak_write,
};

static const struct file_operations mock_oracle_fops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = mock_oracle_selftest_write,
};

static void mock_debugfs_init(struct sfg1_mock *m, int id)
{
	char name[32];

	snprintf(name, sizeof(name), "sfg1-mock%d", id);
	m->dbg = debugfs_create_dir(name, NULL);
	debugfs_create_u32("hang_after", 0644, m->dbg, &m->inj_hang_after);
	debugfs_create_u32("fail_after", 0644, m->dbg, &m->inj_fail_after);
	debugfs_create_u32("fail_status", 0644, m->dbg, &m->inj_fail_status);
	debugfs_create_u32("drop_irq", 0644, m->dbg, &m->inj_drop_irq);
	debugfs_create_u32("reset_mode", 0644, m->dbg, &m->inj_reset_mode);
	debugfs_create_u32("corrupt_cqe", 0644, m->dbg, &m->inj_corrupt_cqe);
	debugfs_create_u32("cmd_delay_us", 0644, m->dbg, &m->cmd_delay_us);
	debugfs_create_u32("scrub_fail", 0644, m->dbg, &m->inj_scrub_fail);
	debugfs_create_u32("dma_accesses", 0444, m->dbg, &m->st_dma_accesses);
	debugfs_create_u32("dma_violations", 0444, m->dbg, &m->st_dma_violations);
	debugfs_create_u32("cmds", 0444, m->dbg, &m->st_cmds);
	debugfs_create_u32("scrubs", 0444, m->dbg, &m->st_scrubs);
	debugfs_create_u32("irqs_sent", 0444, m->dbg, &m->st_irqs_sent);
	debugfs_create_u32("irqs_dropped", 0444, m->dbg, &m->st_irqs_dropped);
	debugfs_create_file("oracle_selftest", 0200, m->dbg, m, &mock_oracle_fops);
	debugfs_create_file("leak_selftest", 0200, m->dbg, m, &mock_leak_fops);
}

static int sfg1_mock_probe(struct platform_device *pdev)
{
	struct sfg1_mock *m;
	struct sfg1_device *sdev;
	int ret;

	m = kzalloc(sizeof(*m), GFP_KERNEL);
	if (!m)
		return -ENOMEM;
	m->pdev = pdev;
	spin_lock_init(&m->lock);
	mutex_init(&m->region_lock);
	INIT_LIST_HEAD(&m->regions);
	INIT_WORK(&m->work, mock_work_fn);
	m->max_ctx = clamp(mock_max_ctx, 1u, SFG1_MAX_CTX_LIMIT);
	m->win_kib = clamp(mock_ctx_win_kib, 4u, 16384u);
	m->win_size = (u64)m->win_kib * SZ_1K;
	m->inj_hang_after = MOCK_OFF_NONE;
	m->inj_fail_after = MOCK_OFF_NONE;
	m->cmd_delay_us = mock_cmd_delay_us;
	m->devmem = vzalloc(m->win_size * m->max_ctx);
	if (!m->devmem) {
		ret = -ENOMEM;
		goto err_free;
	}
	m->wq = alloc_ordered_workqueue("sfg1-mock%d", 0, pdev->id);
	if (!m->wq) {
		ret = -ENOMEM;
		goto err_mem;
	}
	ret = dma_coerce_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(64));
	if (ret)
		goto err_wq;

	m->fwnode = irq_domain_alloc_named_id_fwnode("sfg1-mock", pdev->id);
	if (!m->fwnode) {
		ret = -ENOMEM;
		goto err_wq;
	}
	m->domain = irq_domain_create_sim(m->fwnode, 1);
	if (IS_ERR(m->domain)) {
		ret = PTR_ERR(m->domain);
		goto err_fwnode;
	}
	m->virq = irq_create_mapping(m->domain, 0);
	if (!m->virq) {
		ret = -ENOMEM;
		goto err_domain;
	}

	sdev = sfg1_device_create(&pdev->dev, &sfg1_mock_ops, m);
	if (IS_ERR(sdev)) {
		ret = PTR_ERR(sdev);
		goto err_domain;
	}
	m->sdev = sdev;
	platform_set_drvdata(pdev, sdev);

	ret = sfg1_hw_discover(sdev);
	if (ret)
		goto err_domain;
	ret = sfg1_device_bringup(sdev, m->virq, 0);
	if (ret)
		goto err_domain;
	mock_debugfs_init(m, pdev->id);
	return 0;

err_domain:
	irq_domain_remove_sim(m->domain);
err_fwnode:
	irq_domain_free_fwnode(m->fwnode);
err_wq:
	destroy_workqueue(m->wq);
err_mem:
	vfree(m->devmem);
err_free:
	kfree(m);
	return ret;
}

static void sfg1_mock_remove(struct platform_device *pdev)
{
	struct sfg1_device *sdev = platform_get_drvdata(pdev);
	struct sfg1_mock *m = sdev->backend;
	struct sfg1_mock_region *r, *tmp;

	debugfs_remove_recursive(m->dbg);
	sfg1_device_remove(sdev);	/* quiesces via registers; installs the dead backend */

	cancel_work_sync(&m->work);
	destroy_workqueue(m->wq);
	irq_domain_remove_sim(m->domain);
	irq_domain_free_fwnode(m->fwnode);
	list_for_each_entry_safe(r, tmp, &m->regions, node) {
		list_del(&r->node);
		kfree(r);
	}
	vfree(m->devmem);
	kfree(m);
}

static struct platform_driver sfg1_mock_driver = {
	.probe = sfg1_mock_probe,
	.remove = sfg1_mock_remove,
	.driver = { .name = "sfg1-mock" },
};

static struct platform_device *sfg1_mock_pdevs[16];

int sfg1_mock_init(void)
{
	unsigned int i, n = min_t(unsigned int, mock_devices, ARRAY_SIZE(sfg1_mock_pdevs));
	int ret;

	if (!n)
		return 0;
	pr_warn("sfg1: MOCK DEVICES ENABLED (%u) - test configuration, never use in production\n",
		n);
	ret = platform_driver_register(&sfg1_mock_driver);
	if (ret)
		return ret;
	for (i = 0; i < n; i++) {
		sfg1_mock_pdevs[i] = platform_device_register_simple("sfg1-mock", i, NULL, 0);
		if (IS_ERR(sfg1_mock_pdevs[i])) {
			ret = PTR_ERR(sfg1_mock_pdevs[i]);
			sfg1_mock_pdevs[i] = NULL;
			while (i--)
				platform_device_unregister(sfg1_mock_pdevs[i]);
			platform_driver_unregister(&sfg1_mock_driver);
			return ret;
		}
	}
	return 0;
}

void sfg1_mock_exit(void)
{
	unsigned int i;

	for (i = 0; i < ARRAY_SIZE(sfg1_mock_pdevs); i++)
		if (sfg1_mock_pdevs[i])
			platform_device_unregister(sfg1_mock_pdevs[i]);
	if (mock_devices)
		platform_driver_unregister(&sfg1_mock_driver);
}
