/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * SilicaFlux SF-G1 DRM accel driver — internal definitions.
 *
 * Locking (outermost first). Never allocate with GFP_KERNEL while holding a
 * lock marked [sig]: those are taken on the dma-fence signalling path
 * (run_job, IRQ thread, timedout_job) and lockdep will flag reclaim recursion.
 *
 *   reset_lock   mutex  [sig] serialises recovery, removal and quiesce
 *   ctx_lock     mutex  [sig] slot table, ctx list (open/close/reset walks)
 *   bo_lock      mutex  [sig] BO list, BO DMA memory release vs. free. It is taken from
 *                       free_job (via sfg1_bo_free), which recovery waits for, so it
 *                       too must NEVER be held across an allocation or dma_mmap
 *                       (lockdep found exactly that cycle; see docs/05-testing.md)
 *   ring_lock    spin   [sig] SQ/CQ state, in-flight job list, fault state
 *   fence_lock   spin   [sig] shared lock for hardware dma_fences
 */
#ifndef SFG1_DRV_H
#define SFG1_DRV_H

#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 18, 0)
#error "sfg1 targets Linux >= 6.18 (see docs/01-design.md)"
#endif

#include <linux/atomic.h>
#include <linux/completion.h>
#include <linux/dma-fence.h>
#include <linux/jiffies.h>
#include <linux/kref.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/spinlock.h>
#include <linux/wait.h>
#include <linux/xarray.h>

#include <drm/drm_device.h>
#include <drm/drm_drv.h>
#include <drm/drm_file.h>
#include <drm/drm_gem.h>
#include <drm/gpu_scheduler.h>
#include <drm/sfg1_accel.h>

#include "sfg1_hw.h"

#define SFG1_DRV_NAME		"sfg1"
#define SFG1_MAX_CMDS_PER_SUBMIT 64u
#define SFG1_RESULT_UNSET	0xffffffffu

struct sfg1_device;
struct sfg1_ctx;
struct sfg1_job;

/* ------------------------------------------------------------------------ */
/* Backend: how registers are reached (PCI BAR0 or the software mock).       */
/* ------------------------------------------------------------------------ */
struct sfg1_backend_ops {
	u32  (*rd32)(struct sfg1_device *sdev, u32 off);
	void (*wr32)(struct sfg1_device *sdev, u32 off, u32 val);
	/*
	 * Optional, mock only: let the model audit every device DMA against the
	 * host memory the driver registered. 'owner' is a context serial
	 * (0 = kernel: rings). NULL on real hardware.
	 */
	void (*dma_region_add)(struct sfg1_device *sdev, dma_addr_t dma, void *cpu,
			       size_t size, u64 owner);
	void (*dma_region_del)(struct sfg1_device *sdev, dma_addr_t dma);
	void (*ctx_bind)(struct sfg1_device *sdev, u32 ctx_id, u64 serial);
	/* Optional: stop the device being a bus master (PCI: pci_clear_master). */
	void (*disable_dma)(struct sfg1_device *sdev);
};

/* ------------------------------------------------------------------------ */
/* Tunables (module parameters, snapshotted at probe).                       */
/* ------------------------------------------------------------------------ */
struct sfg1_cfg {
	u32 queue_entries;
	u32 job_timeout_ms;
	u32 max_bos;
	u64 max_bo_bytes;	/* per ctx */
	u64 max_bo_size;
	u64 max_total_bo_bytes;	/* whole device */
	u32 max_inflight_jobs;
	u32 max_pending_results;
	u32 strike_limit;
	u32 reset_timeout_ms;
	u32 quarantine_ms;
};

enum sfg1_state {
	SFG1_STATE_INIT = 0,
	SFG1_STATE_RUNNING,
	SFG1_STATE_RESETTING,
	SFG1_STATE_DEAD,	/* hardware unusable; jobs fail; ioctls -ENODEV */
	SFG1_STATE_REMOVED,	/* unplugged; hardware must not be touched */
};

enum sfg1_fault {
	SFG1_FAULT_NONE = 0,
	SFG1_FAULT_DEVICE_ERROR,	/* error CQE / HALTED */
	SFG1_FAULT_PROTOCOL,		/* malformed CQE, FATAL irq, bad cid */
};

struct sfg1_ring {
	void *vaddr;
	dma_addr_t dma;
	size_t size;
	u32 entries;
};

struct sfg1_slot {
	struct sfg1_ctx *ctx;	/* owner, NULL if free */
	/*
	 * Cooldown after the device's scrub command itself failed repeatedly: the slot is not
	 * handed out until this jiffies value passes (0 = not quarantined). It is ALWAYS rescrubbed
	 * before reuse (needs_scrub), so quarantine only limits how often a broken scrub is
	 * retried (each failure resets the engine for everyone); it is not what keeps old data
	 * from a new owner.
	 */
	unsigned long quarantine_until;
	bool needs_scrub;	/* window content unknown: must be scrubbed before reuse */
};

static inline bool sfg1_slot_quarantined(const struct sfg1_slot *slot)
{
	return slot->quarantine_until && time_before(jiffies, slot->quarantine_until);
}

struct sfg1_device {
	struct drm_device drm;
	struct device *dev;
	const struct sfg1_backend_ops *ops;
	void *backend;
	struct sfg1_cfg cfg;

	/* discovered at probe (immutable afterwards) */
	u32 hw_version, caps, max_ctx, max_qent, dma_bits;
	u64 devmem_size;
	u32 ctx_win_size;	/* bytes */

	/* interrupts */
	int irq;
	bool irq_requested;
	atomic_t irq_pending;

	/* scheduler (lifetime == drm_device, see docs/01-design.md) */
	struct drm_gpu_scheduler sched;
	struct drm_gpu_scheduler *sched_list[1];
	struct drm_sched_entity kentity;	/* kernel jobs (scrub) */
	bool sched_ready;
	struct workqueue_struct *reset_wq;
	struct work_struct reset_work;	/* recovery when idle (no job to hang a TDR on) */
	u64 fence_ctx;
	u64 fence_seqno;
	spinlock_t fence_lock;

	/* rings + in-flight state; guarded by ring_lock */
	spinlock_t ring_lock;
	struct sfg1_ring sq, cq;
	u32 sq_tail;		/* producer idx (host) */
	u32 sq_free;		/* free slots */
	u32 cq_head;		/* consumer idx (host) */
	u32 cq_phase;		/* expected phase of next CQE */
	struct list_head inflight;	/* struct sfg1_job.node, submission order */
	unsigned long last_progress;	/* jiffies of last CQE / idle->busy edge */
	enum sfg1_fault fault;
	u32 fault_status;
	u64 retired_cmds;
	ktime_t last_busy_end;
	enum sfg1_state state;

	/* contexts */
	struct mutex ctx_lock;
	struct sfg1_slot *slots;
	struct list_head ctx_list;
	u64 ctx_serial;

	/* BOs */
	struct mutex bo_lock;
	struct list_head bo_list;
	atomic64_t total_bo_bytes;

	/* recovery */
	struct mutex reset_lock;
	u64 engine_resets, func_resets;

	bool hw_gone;		/* reads return all-ones: stop touching HW */
};

static inline struct sfg1_device *to_sfg1(struct drm_device *drm)
{
	return container_of(drm, struct sfg1_device, drm);
}

/* ------------------------------------------------------------------------ */
/* Contexts                                                                  */
/* ------------------------------------------------------------------------ */
#define SFG1_CTXF_BANNED	0
#define SFG1_CTXF_LOST		1
#define SFG1_CTXF_DEVICE_GONE	2
#define SFG1_CTXF_CLOSING	3

struct sfg1_result {
	struct kref ref;
	u64 id;
	u32 status;		/* DRM_SFG1_JOB_* or SFG1_RESULT_UNSET */
	u32 dev_error;
	struct dma_fence *finished;	/* set (release) after drm_sched_job_arm() */
};

struct sfg1_ctx {
	struct kref ref;
	struct sfg1_device *sdev;
	struct list_head node;	/* sdev->ctx_list */
	u64 serial;		/* unique for the life of the module */
	u32 id;			/* hardware context slot */
	unsigned long flags;	/* SFG1_CTXF_* */
	struct drm_sched_entity entity;

	/* accounting */
	atomic64_t bo_bytes, bo_bytes_peak;
	atomic_t bo_count;
	atomic_t jobs_alive;	/* submit .. free_job */
	atomic_t unreaped;
	wait_queue_head_t idle_wq;
	struct xarray results;
	atomic64_t job_seq;
	atomic_t strikes;
	atomic64_t jobs_submitted, jobs_ok, jobs_error, jobs_timeout, jobs_canceled;
	atomic64_t cmds_submitted, busy_ns;
};

static inline bool sfg1_ctx_flag(const struct sfg1_ctx *ctx, int bit)
{
	return test_bit(bit, &ctx->flags);
}

/* ------------------------------------------------------------------------ */
/* Buffer objects                                                            */
/* ------------------------------------------------------------------------ */
struct sfg1_bo {
	struct drm_gem_object base;
	struct sfg1_device *sdev;
	struct sfg1_ctx *ctx;	/* owner; holds a ctx reference (accounting) */
	void *vaddr;
	dma_addr_t dma;
	size_t size;
	bool hw_released;	/* DMA memory freed at unplug; guarded by bo_lock */
	struct list_head node;	/* sdev->bo_list */
};
#define to_sfg1_bo(o) container_of(o, struct sfg1_bo, base)

/* ------------------------------------------------------------------------ */
/* Jobs                                                                      */
/* ------------------------------------------------------------------------ */
struct sfg1_job {
	struct drm_sched_job base;
	struct sfg1_device *sdev;
	struct sfg1_ctx *ctx;		/* NULL for kernel jobs (scrub) */
	struct sfg1_result *res;	/* NULL for kernel jobs */
	struct dma_fence *hw_fence;	/* allocated at submit, init'd in run_job */
	bool hw_fence_inited;
	u64 id;
	struct list_head node;		/* sdev->inflight */
	u32 first_slot;
	u32 cmds_done;
	u32 dev_error;
	ktime_t t_start;
	s64 busy_ns;			/* computed under ring_lock at retirement */
	struct drm_gem_object **bos;	/* held references */
	u32 n_bos;
	u32 n_cmds;
	struct sfg1_sq_entry cmds[];
};
#define to_sfg1_job(j) container_of(j, struct sfg1_job, base)

/* ------------------------------------------------------------------------ */
/* Register helpers                                                          */
/* ------------------------------------------------------------------------ */
/*
 * ops is swapped for a dead backend at removal (sfg1_removed_ops), so late
 * callers (free_job, postclose, stats) can never reach freed backend state.
 */
static inline u32 sfg1_rd(struct sfg1_device *sdev, u32 off)
{
	return READ_ONCE(sdev->ops)->rd32(sdev, off);
}

static inline void sfg1_wr(struct sfg1_device *sdev, u32 off, u32 val)
{
	READ_ONCE(sdev->ops)->wr32(sdev, off, val);
}

/* sfg1_main.c */
struct sfg1_device *sfg1_device_create(struct device *parent,
				       const struct sfg1_backend_ops *ops, void *backend);
int sfg1_device_bringup(struct sfg1_device *sdev, int irq, unsigned long irq_flags);
void sfg1_device_remove(struct sfg1_device *sdev);
void sfg1_cfg_load(struct sfg1_cfg *cfg);
extern const struct drm_driver sfg1_drm_driver;

/* sfg1_hw.c (discovery, start, reset primitives) */
int sfg1_hw_discover(struct sfg1_device *sdev);
int sfg1_hw_start(struct sfg1_device *sdev);
void sfg1_hw_quiesce(struct sfg1_device *sdev);
int sfg1_hw_engine_reset(struct sfg1_device *sdev);
int sfg1_hw_function_reset(struct sfg1_device *sdev);
int sfg1_rings_alloc(struct sfg1_device *sdev);
void sfg1_rings_free(struct sfg1_device *sdev);

/* sfg1_ring.c */
bool sfg1_state_is(struct sfg1_device *sdev, enum sfg1_state s);
int sfg1_ring_push_job(struct sfg1_device *sdev, struct sfg1_job *job);
void sfg1_ring_reap(struct sfg1_device *sdev, struct list_head *done);
void sfg1_ring_reset_state(struct sfg1_device *sdev);
void sfg1_complete_done_jobs(struct sfg1_device *sdev, struct list_head *done);
void sfg1_job_finish(struct sfg1_job *job, u32 status, int fence_err);
void sfg1_job_set_result(struct sfg1_job *job, u32 status);

/* sfg1_irq.c */
irqreturn_t sfg1_irq_top(int irq, void *arg);
irqreturn_t sfg1_irq_thread(int irq, void *arg);

/* sfg1_reset.c */
enum drm_gpu_sched_stat sfg1_timedout_job(struct drm_sched_job *sjob);
void sfg1_fail_all_inflight(struct sfg1_device *sdev, u32 status, int fence_err);
void sfg1_mark_all_ctx(struct sfg1_device *sdev, int flag_bit);
void sfg1_reset_work(struct work_struct *work);

/* sfg1_ctx.c */
int sfg1_open(struct drm_device *drm, struct drm_file *file);
void sfg1_postclose(struct drm_device *drm, struct drm_file *file);
void sfg1_ctx_put(struct sfg1_ctx *ctx);
static inline struct sfg1_ctx *sfg1_ctx_get(struct sfg1_ctx *ctx)
{
	kref_get(&ctx->ref);
	return ctx;
}
/* Outcome of one scrub attempt: who is to blame decides what happens next. */
enum sfg1_scrub_result {
	SFG1_SCRUB_OK,
	SFG1_SCRUB_TRANSIENT,	/* cancelled by a reset/fault caused by something else, or never ran */
	SFG1_SCRUB_FAILED,	/* the scrub command itself timed out or errored */
};
enum sfg1_scrub_result sfg1_scrub_window(struct sfg1_device *sdev, u32 ctx_id);
void sfg1_ctx_note_strike(struct sfg1_ctx *ctx);
int sfg1_ctx_usable(struct sfg1_ctx *ctx);
int sfg1_ioctl_get_stats(struct drm_device *drm, void *data, struct drm_file *file);
int sfg1_ioctl_get_param(struct drm_device *drm, void *data, struct drm_file *file);
void sfg1_show_fdinfo(struct drm_printer *p, struct drm_file *file);

/* sfg1_gem.c */
int sfg1_ioctl_bo_create(struct drm_device *drm, void *data, struct drm_file *file);
bool sfg1_is_bo(const struct drm_gem_object *obj);
struct drm_gem_object *sfg1_prime_import_denied(struct drm_device *dev, struct dma_buf *buf);
void sfg1_bos_release_all_dma(struct sfg1_device *sdev);

/* sfg1_job.c */
int sfg1_sched_init(struct sfg1_device *sdev);
int sfg1_ioctl_submit(struct drm_device *drm, void *data, struct drm_file *file);
int sfg1_ioctl_wait_job(struct drm_device *drm, void *data, struct drm_file *file);
void sfg1_result_put(struct sfg1_result *res);
extern const struct drm_sched_backend_ops sfg1_sched_ops;

/* sfg1_mock.c */
#if IS_ENABLED(CONFIG_DRM_ACCEL_SFG1_MOCK)
int sfg1_mock_init(void);
void sfg1_mock_exit(void);
#else
static inline int sfg1_mock_init(void) { return 0; }
static inline void sfg1_mock_exit(void) { }
#endif

/* sfg1_pci.c */
int sfg1_pci_register(void);
void sfg1_pci_unregister(void);

#endif /* SFG1_DRV_H */
