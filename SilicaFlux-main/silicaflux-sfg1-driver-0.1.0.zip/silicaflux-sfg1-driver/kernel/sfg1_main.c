// SPDX-License-Identifier: GPL-2.0-only
/*
 * SilicaFlux SF-G1 — DRM compute-accelerator driver: core.
 *
 * Bus-independent: PCI (sfg1_pci.c) and the software mock (sfg1_mock.c) both
 * call sfg1_device_create() / sfg1_device_bringup() / sfg1_device_remove().
 */
#include <linux/interrupt.h>
#include <linux/log2.h>
#include <linux/minmax.h>
#include <linux/module.h>
#include <linux/sizes.h>

#include <drm/drm_accel.h>
#include <drm/drm_drv.h>
#include <drm/drm_file.h>
#include <drm/drm_gem.h>
#include <drm/drm_ioctl.h>
#include <drm/drm_managed.h>

#include "sfg1_drv.h"

/* ------------------------------------------------------------------------ */
/* module parameters (read at probe; all conservative by default)            */
/* ------------------------------------------------------------------------ */
static uint queue_entries = 256;
module_param(queue_entries, uint, 0444);
MODULE_PARM_DESC(queue_entries, "SQ/CQ entries, power of two 16..4096 (default 256)");

static uint job_timeout_ms = 2000;
module_param(job_timeout_ms, uint, 0444);
MODULE_PARM_DESC(job_timeout_ms, "No-progress hang timeout in ms (10..600000, default 2000)");

static uint max_bos = 256;
module_param(max_bos, uint, 0444);
MODULE_PARM_DESC(max_bos, "Max buffer objects per context (default 256)");

static uint max_bo_size_mib = 16;
module_param(max_bo_size_mib, uint, 0444);
MODULE_PARM_DESC(max_bo_size_mib, "Max size of one BO in MiB (1..1024, default 16)");

static uint max_ctx_bo_mib = 64;
module_param(max_ctx_bo_mib, uint, 0444);
MODULE_PARM_DESC(max_ctx_bo_mib, "Max total BO MiB per context (default 64)");

static uint max_total_bo_mib = 512;
module_param(max_total_bo_mib, uint, 0444);
MODULE_PARM_DESC(max_total_bo_mib, "Max total BO MiB for the whole device (default 512)");

static uint max_inflight_jobs = 64;
module_param(max_inflight_jobs, uint, 0444);
MODULE_PARM_DESC(max_inflight_jobs, "Max jobs alive per context (default 64)");

static uint max_pending_results = 256;
module_param(max_pending_results, uint, 0444);
MODULE_PARM_DESC(max_pending_results, "Max submitted-but-unreaped jobs per context (default 256)");

static uint strike_limit = 3;
module_param(strike_limit, uint, 0444);
MODULE_PARM_DESC(strike_limit, "Hangs/errors before a context is banned (default 3)");

static uint reset_timeout_ms = 1000;
module_param(reset_timeout_ms, uint, 0444);
MODULE_PARM_DESC(reset_timeout_ms, "Wait for the device to become READY after a reset (default 1000)");

static uint quarantine_ms = 10000;
module_param(quarantine_ms, uint, 0444);
MODULE_PARM_DESC(quarantine_ms,
		 "Cooldown for a context window whose scrub command keeps failing (default 10000)");

void sfg1_cfg_load(struct sfg1_cfg *cfg)
{
	u64 bo_size, ctx_bytes, total_bytes;
	u32 qent;

	/* queue entries: power of two within the contract's bounds */
	qent = max(queue_entries, SFG1_QUEUE_ENTRIES_MIN);
	qent = min(qent, SFG1_QUEUE_ENTRIES_MAX);
	cfg->queue_entries = roundup_pow_of_two(qent);

	cfg->job_timeout_ms = clamp(job_timeout_ms, 10u, 600000u);
	cfg->max_bos = max(max_bos, 1u);

	/* max_bo_size is a PAGE_SIZE multiple and <= 1 GiB (sfg1_ioctl_bo_create relies on it) */
	bo_size = (u64)clamp(max_bo_size_mib, 1u, 1024u) * SZ_1M;
	bo_size = rounddown(bo_size, PAGE_SIZE);
	cfg->max_bo_size = max_t(u64, bo_size, PAGE_SIZE);

	ctx_bytes = (u64)min(max_ctx_bo_mib, 1u << 20) * SZ_1M;
	cfg->max_bo_bytes = max(ctx_bytes, cfg->max_bo_size);
	total_bytes = (u64)min(max_total_bo_mib, 1u << 20) * SZ_1M;
	cfg->max_total_bo_bytes = max(total_bytes, cfg->max_bo_bytes);

	cfg->max_inflight_jobs = max(max_inflight_jobs, 1u);
	cfg->max_pending_results = max(max_pending_results, cfg->max_inflight_jobs);
	cfg->strike_limit = max(strike_limit, 1u);
	cfg->reset_timeout_ms = clamp(reset_timeout_ms, 10u, 60000u);
	cfg->quarantine_ms = clamp(quarantine_ms, 100u, 3600000u);
}

/* ------------------------------------------------------------------------ */
/* DRM driver                                                                */
/* ------------------------------------------------------------------------ */
static const struct drm_ioctl_desc sfg1_ioctls[] = {
	/* flags 0: accel clients are not "render" clients, no master/auth semantics */
	DRM_IOCTL_DEF_DRV(SFG1_GET_PARAM, sfg1_ioctl_get_param, 0),
	DRM_IOCTL_DEF_DRV(SFG1_BO_CREATE, sfg1_ioctl_bo_create, 0),
	DRM_IOCTL_DEF_DRV(SFG1_SUBMIT, sfg1_ioctl_submit, 0),
	DRM_IOCTL_DEF_DRV(SFG1_WAIT_JOB, sfg1_ioctl_wait_job, 0),
	DRM_IOCTL_DEF_DRV(SFG1_GET_STATS, sfg1_ioctl_get_stats, 0),
};

static const struct file_operations sfg1_fops = {
	.owner = THIS_MODULE,
	DRM_ACCEL_FOPS,
	.show_fdinfo = drm_show_fdinfo,
};

const struct drm_driver sfg1_drm_driver = {
	.driver_features = DRIVER_COMPUTE_ACCEL | DRIVER_GEM,
	.open = sfg1_open,
	.postclose = sfg1_postclose,
	.gem_prime_import = sfg1_prime_import_denied,
	.show_fdinfo = sfg1_show_fdinfo,
	.ioctls = sfg1_ioctls,
	.num_ioctls = ARRAY_SIZE(sfg1_ioctls),
	.fops = &sfg1_fops,
	.name = SFG1_DRV_NAME,
	.desc = "SilicaFlux SF-G1 compute accelerator",
	.major = DRM_SFG1_UAPI_MAJOR,
	.minor = DRM_SFG1_UAPI_MINOR,
};

/* ------------------------------------------------------------------------ */
/* device lifecycle                                                          */
/* ------------------------------------------------------------------------ */

/* Backend installed at removal: nothing can reach freed backend state. */
static u32 sfg1_dead_rd32(struct sfg1_device *sdev, u32 off)
{
	return SFG1_ALL_ONES;
}

static void sfg1_dead_wr32(struct sfg1_device *sdev, u32 off, u32 val)
{
}

static const struct sfg1_backend_ops sfg1_removed_ops = {
	.rd32 = sfg1_dead_rd32,
	.wr32 = sfg1_dead_wr32,
};

struct sfg1_device *sfg1_device_create(struct device *parent, const struct sfg1_backend_ops *ops,
				       void *backend)
{
	struct sfg1_device *sdev;

	sdev = devm_drm_dev_alloc(parent, &sfg1_drm_driver, struct sfg1_device, drm);
	if (IS_ERR(sdev))
		return sdev;

	sdev->dev = parent;
	sdev->ops = ops;
	sdev->backend = backend;
	sfg1_cfg_load(&sdev->cfg);

	spin_lock_init(&sdev->ring_lock);
	spin_lock_init(&sdev->fence_lock);
	mutex_init(&sdev->ctx_lock);
	mutex_init(&sdev->bo_lock);
	mutex_init(&sdev->reset_lock);
	INIT_LIST_HEAD(&sdev->inflight);
	INIT_LIST_HEAD(&sdev->ctx_list);
	INIT_LIST_HEAD(&sdev->bo_list);
	INIT_WORK(&sdev->reset_work, sfg1_reset_work);
	atomic_set(&sdev->irq_pending, 0);
	atomic64_set(&sdev->total_bo_bytes, 0);
	sdev->fence_ctx = dma_fence_context_alloc(1);
	sdev->state = SFG1_STATE_INIT;
	return sdev;
}

int sfg1_device_bringup(struct sfg1_device *sdev, int irq, unsigned long irq_flags)
{
	u32 i;
	int ret;

	/* Precondition: sfg1_hw_discover() succeeded and the DMA mask is set. */
	sdev->cfg.queue_entries = min(sdev->cfg.queue_entries, sdev->max_qent);

	sdev->slots = drmm_kcalloc(&sdev->drm, sdev->max_ctx, sizeof(*sdev->slots), GFP_KERNEL);
	if (!sdev->slots)
		return -ENOMEM;
	for (i = 0; i < sdev->max_ctx; i++)
		sdev->slots[i].needs_scrub = true;	/* power-up content is unknown */

	sdev->reset_wq = drmm_alloc_ordered_workqueue(&sdev->drm, "sfg1-reset", 0);
	if (IS_ERR(sdev->reset_wq))
		return PTR_ERR(sdev->reset_wq);

	ret = sfg1_rings_alloc(sdev);
	if (ret)
		return ret;

	ret = sfg1_sched_init(sdev);
	if (ret)
		goto err_rings;

	sdev->irq = irq;
	ret = request_threaded_irq(irq, sfg1_irq_top, sfg1_irq_thread,
				   irq_flags | IRQF_NO_AUTOEN, SFG1_DRV_NAME, sdev);
	if (ret) {
		dev_err(sdev->dev, "cannot request irq %d (%d)\n", irq, ret);
		goto err_rings;
	}
	sdev->irq_requested = true;

	ret = sfg1_hw_start(sdev);
	if (ret)
		goto err_irq;

	spin_lock(&sdev->ring_lock);
	sdev->state = SFG1_STATE_RUNNING;
	spin_unlock(&sdev->ring_lock);
	enable_irq(irq);

	ret = drm_dev_register(&sdev->drm, 0);
	if (ret)
		goto err_run;
	dev_info(sdev->dev, "registered: %u contexts, SQ/CQ %u entries, job timeout %u ms\n",
		 sdev->max_ctx, sdev->sq.entries, sdev->cfg.job_timeout_ms);
	return 0;

err_run:
	disable_irq(irq);
	spin_lock(&sdev->ring_lock);
	sdev->state = SFG1_STATE_REMOVED;
	spin_unlock(&sdev->ring_lock);
	sfg1_hw_quiesce(sdev);
err_irq:
	free_irq(irq, sdev);
	sdev->irq_requested = false;
err_rings:
	sfg1_rings_free(sdev);
	return ret;
}

/*
 * Safe removal. Order matters:
 *   1. hardware first (under reset_lock, so a recovery in progress finishes):
 *      mark REMOVED, stop the device, stop DMA, free the IRQ, fail every
 *      in-flight fence. Anything blocked in an ioctl now fails fast.
 *   2. drm_dev_unplug(): ioctls fail with -ENODEV, user mmaps are revoked,
 *      in-flight ioctl sections are waited for.
 *   3. only then free BO DMA memory and queue memory, while the device (and
 *      its IOMMU state) is still valid, and swap in the dead backend.
 * Open files, the drm_device and its scheduler live on until the last close;
 * close never touches hardware again.
 */
void sfg1_device_remove(struct sfg1_device *sdev)
{
	if (sfg1_rd(sdev, SFG1_REG_ID) == SFG1_ALL_ONES)
		WRITE_ONCE(sdev->hw_gone, true);	/* surprise removal */

	mutex_lock(&sdev->reset_lock);
	spin_lock(&sdev->ring_lock);
	sdev->state = SFG1_STATE_REMOVED;
	spin_unlock(&sdev->ring_lock);

	sfg1_hw_quiesce(sdev);
	if (sdev->ops->disable_dma)
		sdev->ops->disable_dma(sdev);	/* from here the device cannot touch host memory */
	if (sdev->irq_requested) {
		free_irq(sdev->irq, sdev);
		sdev->irq_requested = false;
	}
	sfg1_fail_all_inflight(sdev, DRM_SFG1_JOB_CANCELED, -ENODEV);
	sfg1_mark_all_ctx(sdev, SFG1_CTXF_DEVICE_GONE);
	mutex_unlock(&sdev->reset_lock);

	drm_dev_unplug(&sdev->drm);
	cancel_work_sync(&sdev->reset_work);

	sfg1_bos_release_all_dma(sdev);
	sfg1_rings_free(sdev);
	WRITE_ONCE(sdev->ops, &sfg1_removed_ops);
}

/* ------------------------------------------------------------------------ */
/* module                                                                    */
/* ------------------------------------------------------------------------ */
static int __init sfg1_init(void)
{
	int ret;

	ret = sfg1_pci_register();
	if (ret)
		return ret;
	ret = sfg1_mock_init();
	if (ret) {
		sfg1_pci_unregister();
		return ret;
	}
	return 0;
}

static void __exit sfg1_exit(void)
{
	sfg1_mock_exit();
	sfg1_pci_unregister();
}

module_init(sfg1_init);
module_exit(sfg1_exit);

MODULE_DESCRIPTION("SilicaFlux SF-G1 compute accelerator driver (DRM accel)");
MODULE_AUTHOR("SilicaFlux driver contributors");
MODULE_LICENSE("GPL");
