/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) OR MIT */
/*
 * SilicaFlux SF-G1 accelerator — userspace API (DRM accel), version 1.0.
 *
 * Design rules (see docs/03-uapi.md):
 *  - Userspace never supplies a device address, bus address or register offset.
 *    It names buffers by per-file GEM handle and addresses device memory by an
 *    offset into *its own* device-memory window.
 *  - Every struct is explicitly padded; every pad/reserved field MUST be zero
 *    (the kernel returns -EINVAL otherwise), so fields can be added later.
 *  - The command array element size is passed in 'cmd_stride' so a newer
 *    userspace can talk to an older kernel (and vice versa) safely:
 *    unknown non-zero trailing bytes -> -E2BIG.
 *  - Query DRM_SFG1_PARAM_UAPI_VERSION first. Major changes break the ABI.
 *
 * Error conventions (errno):
 *   -ENODEV      device removed or dead
 *   -ECANCELED   context banned after repeated hangs/errors
 *   -ECONNRESET  context lost: the device was reset and its memory discarded;
 *                close the fd and open a new context
 *   -ENOSPC      a resource quota would be exceeded (nothing was committed)
 *   -EBUSY       too many jobs in flight / unreaped results; wait and retry
 *   -ETIMEDOUT   WAIT_JOB deadline passed (the job remains waitable)
 *   -ENOENT      unknown handle / job id (also: another file's handle)
 *   -EPERM       operation not permitted (e.g. dma-buf export)
 */
#ifndef _UAPI_SFG1_ACCEL_H_
#define _UAPI_SFG1_ACCEL_H_

#include <drm/drm.h>

#if defined(__cplusplus)
extern "C" {
#endif

#define DRM_SFG1_UAPI_MAJOR	1
#define DRM_SFG1_UAPI_MINOR	0

#define DRM_SFG1_GET_PARAM	0x00
#define DRM_SFG1_BO_CREATE	0x01
#define DRM_SFG1_SUBMIT		0x02
#define DRM_SFG1_WAIT_JOB	0x03
#define DRM_SFG1_GET_STATS	0x04

/* ------------------------------ GET_PARAM -------------------------------- */
enum drm_sfg1_param {
	DRM_SFG1_PARAM_UAPI_VERSION	 = 0, /* (major << 16) | minor */
	DRM_SFG1_PARAM_HW_VERSION	 = 1, /* raw SF-G1 HW_VERSION register */
	DRM_SFG1_PARAM_HW_CAPS		 = 2, /* raw SF-G1 CAPS register */
	DRM_SFG1_PARAM_CTX_ID		 = 3, /* this context's hardware slot */
	DRM_SFG1_PARAM_CTX_WINDOW_SIZE	 = 4, /* bytes of device memory owned by this ctx */
	DRM_SFG1_PARAM_MAX_BO_SIZE	 = 5, /* bytes */
	DRM_SFG1_PARAM_MAX_BOS		 = 6, /* per context */
	DRM_SFG1_PARAM_MAX_BO_BYTES	 = 7, /* per context, total */
	DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT = 8,
	DRM_SFG1_PARAM_MAX_INFLIGHT_JOBS = 9, /* per context */
	DRM_SFG1_PARAM_MAX_PENDING_RESULTS = 10, /* submitted-but-not-yet-waited jobs */
	DRM_SFG1_PARAM_JOB_TIMEOUT_MS	 = 11, /* no-progress hang timeout */
	DRM_SFG1_PARAM_CTX_STATE	 = 12, /* DRM_SFG1_CTX_* flags */
	DRM_SFG1_PARAM_VEC_OPS		 = 13, /* bitmask of supported DRM_SFG1_VEC_* */
};

struct drm_sfg1_get_param {
	__u32 param;		/* in:  enum drm_sfg1_param */
	__u32 pad;		/* must be 0 */
	__u64 value;		/* out */
};

/* ctx state flags (DRM_SFG1_PARAM_CTX_STATE, drm_sfg1_get_stats.ctx_state) */
#define DRM_SFG1_CTX_BANNED	(1u << 0)
#define DRM_SFG1_CTX_LOST	(1u << 1)
#define DRM_SFG1_CTX_DEVICE_GONE (1u << 2)

/* ------------------------------ BO_CREATE -------------------------------- */
/*
 * Allocates a zero-initialised, DMA-contiguous buffer owned by the calling
 * context. The returned handle is valid only on this fd. mmap() the fd at
 * 'mmap_offset' (length <= size) to access it from the CPU. dma-buf export
 * is not supported (-EPERM). Release with DRM_IOCTL_GEM_CLOSE.
 */
struct drm_sfg1_bo_create {
	__u64 size;		/* in: bytes (rounded up to PAGE_SIZE) */
	__u32 flags;		/* in: must be 0 */
	__u32 handle;		/* out */
	__u64 mmap_offset;	/* out */
	__u64 real_size;	/* out: size actually allocated */
	__u64 reserved;		/* must be 0 */
};

/* ------------------------------- SUBMIT ---------------------------------- */
#define DRM_SFG1_OP_NOP		0
#define DRM_SFG1_OP_DMA_H2D	1	/* BO[bo_offset..+len] -> window[dev_a..+len] */
#define DRM_SFG1_OP_VEC		2	/* INT8x4 SIMD op; len in 32-bit words */
#define DRM_SFG1_OP_TEN		3	/* 4x4 INT8 matmul tiles; len = tiles */
#define DRM_SFG1_OP_DMA_D2H	5	/* window[dev_a..+len] -> BO[bo_offset..+len] */

#define DRM_SFG1_VEC_ADD8	0
#define DRM_SFG1_VEC_SUB8	1
#define DRM_SFG1_VEC_MAX8	2
#define DRM_SFG1_VEC_RELU8	3	/* unary: A -> C, dev_b must be 0 */
#define DRM_SFG1_VEC_XOR32	4
#define DRM_SFG1_VEC_AND32	5
#define DRM_SFG1_VEC_MUL8	6
#define DRM_SFG1_VEC_DOT8	7	/* C[0] = sum_i sum_lanes A*B (1 int32 result) */

#define DRM_SFG1_CMDF_TEN_ACC	(1u << 0) /* TEN: C += A*B (INT32 accumulate) */

/*
 * One device command. All offsets/lengths are in BYTES except VEC (len = words)
 * and TEN (len = tiles). Everything must be 4-byte aligned.
 *
 *  DMA_H2D/D2H : bo_handle, bo_offset, len, dev_a          (others must be 0)
 *  VEC         : exec_op, len(words), dev_a=A, dev_b=B, dev_c=C
 *  TEN         : flags, len(tiles); per tile A=16 B, B=16 B (4x4 INT8 row-major),
 *                C=64 B (4x4 INT32 row-major); dev_a/b/c = first tile of each
 *  NOP         : all fields zero
 * The kernel validates every range (overflow-safe) against the BO and against
 * the context's device-memory window before anything is queued.
 */
struct drm_sfg1_cmd {
	__u32 op;		/* DRM_SFG1_OP_* */
	__u32 flags;		/* DRM_SFG1_CMDF_* */
	__u32 bo_handle;	/* DMA ops only; else 0 */
	__u32 exec_op;		/* VEC only: DRM_SFG1_VEC_*; else 0 */
	__u64 bo_offset;
	__u64 len;
	__u64 dev_a;
	__u64 dev_b;
	__u64 dev_c;
	__u64 reserved;		/* must be 0 */
};

#define DRM_SFG1_CMD_SIZE_V1	64

/*
 * Submit an ordered batch (= one job). Commands in a job run in order; jobs of
 * one context run in submission order; jobs of different contexts may be
 * interleaved by the scheduler. A job is atomic from the API's viewpoint: it
 * either completes, fails, times out or is cancelled as a whole.
 */
struct drm_sfg1_submit {
	__u64 cmds_ptr;		/* in: user pointer to cmd_count * cmd_stride bytes */
	__u32 cmd_count;	/* in: 1..DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT */
	__u32 cmd_stride;	/* in: >= DRM_SFG1_CMD_SIZE_V1, multiple of 8 */
	__u32 flags;		/* in: must be 0 */
	__u32 pad;		/* must be 0 */
	__u64 job_id;		/* out: per-context monotonically increasing id (>=1) */
	__u64 reserved;		/* must be 0 */
};

/* ------------------------------ WAIT_JOB --------------------------------- */
#define DRM_SFG1_JOB_OK		0	/* every command completed successfully */
#define DRM_SFG1_JOB_ERROR	1	/* device reported 'dev_error' for a command */
#define DRM_SFG1_JOB_TIMEOUT	2	/* device made no progress; reset; ctx got a strike */
/*
 * CANCELED: not completed because of a reset, a ban or a removal. Effects on
 * device memory are undefined; re-upload inputs and resubmit.
 */
#define DRM_SFG1_JOB_CANCELED	3

/*
 * Wait for, and reap, a job. A job's result is held until it is reaped (or the
 * fd is closed); a second WAIT_JOB for the same id returns -ENOENT.
 * 'timeout_ns' is an ABSOLUTE CLOCK_MONOTONIC deadline; 0 = poll (-EBUSY if
 * not finished). On -ETIMEDOUT/-EBUSY/-EINTR the job is NOT reaped.
 */
struct drm_sfg1_wait_job {
	__u64 job_id;		/* in */
	__s64 timeout_ns;	/* in: absolute CLOCK_MONOTONIC ns, 0 = poll */
	__u32 flags;		/* in: must be 0 */
	__u32 status;		/* out: DRM_SFG1_JOB_* (valid when ioctl returns 0) */
	__u32 dev_error;	/* out: raw SF-G1 completion status when status==ERROR */
	__u32 pad;		/* must be 0 */
	__u64 reserved;		/* must be 0 */
};

/* ------------------------------ GET_STATS -------------------------------- */
struct drm_sfg1_get_stats {
	__u32 ctx_id;
	__u32 ctx_state;	/* DRM_SFG1_CTX_* */
	__u64 bo_count;
	__u64 bo_bytes;
	__u64 bo_bytes_peak;
	__u64 jobs_submitted;
	__u64 jobs_ok;
	__u64 jobs_error;
	__u64 jobs_timeout;
	__u64 jobs_canceled;
	__u64 cmds_submitted;
	__u64 busy_ns;		/* approximate device time attributed to this ctx */
	__u64 device_engine_resets;	/* device-wide since probe */
	__u64 device_func_resets;	/* device-wide since probe */
	__u64 reserved[4];	/* must be 0 */
};

#define DRM_IOCTL_SFG1_GET_PARAM \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_SFG1_GET_PARAM, struct drm_sfg1_get_param)
#define DRM_IOCTL_SFG1_BO_CREATE \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_SFG1_BO_CREATE, struct drm_sfg1_bo_create)
#define DRM_IOCTL_SFG1_SUBMIT \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_SFG1_SUBMIT, struct drm_sfg1_submit)
#define DRM_IOCTL_SFG1_WAIT_JOB \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_SFG1_WAIT_JOB, struct drm_sfg1_wait_job)
#define DRM_IOCTL_SFG1_GET_STATS \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_SFG1_GET_STATS, struct drm_sfg1_get_stats)

#if defined(__cplusplus)
}
#endif

#endif /* _UAPI_SFG1_ACCEL_H_ */
