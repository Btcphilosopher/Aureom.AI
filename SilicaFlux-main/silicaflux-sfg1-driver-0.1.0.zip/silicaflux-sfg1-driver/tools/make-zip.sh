#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
# Create ../silicaflux-sfg1-driver-<version>.zip from this directory, leaving
# out build artifacts. Does not touch git: nothing is committed or staged.
set -eu
PKG=$(cd "$(dirname "$0")/.." && pwd)
NAME=$(basename "$PKG")
VERSION=${VERSION:-0.1.0}
OUT=${1:-"$PKG/../$NAME-$VERSION.zip"}
cd "$PKG/.."
rm -f "$OUT"
zip -r -q "$OUT" "$NAME" \
	-x "*/.git/*" "*/build/*" "*.o" "*.ko" "*.mod" "*.mod.c" "*/.*.cmd" "*/.*.d" \
	   "*/modules.order" "*/Module.symvers" "*/.tmp_versions/*" "*.vvp" "*/obj_dir/*" "*~"
echo "wrote $OUT"
unzip -l "$OUT" | tail -1
