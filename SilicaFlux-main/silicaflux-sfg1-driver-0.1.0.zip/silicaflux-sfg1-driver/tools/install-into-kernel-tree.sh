#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
# Install the SF-G1 driver into a Linux 6.18 source tree (drivers/accel/sfg1).
# Usage: tools/install-into-kernel-tree.sh /path/to/linux
# Idempotent. Touches only: drivers/accel/{Kconfig,Makefile,sfg1/},
# include/uapi/drm/sfg1_accel.h.
set -eu
KSRC=${1:?usage: $0 /path/to/linux-6.18-tree}
PKG=$(cd "$(dirname "$0")/.." && pwd)

[ -f "$KSRC/drivers/accel/Kconfig" ] || { echo "not a kernel tree: $KSRC" >&2; exit 1; }
ver=$(make -sC "$KSRC" kernelversion 2>/dev/null || true)
case "$ver" in
6.18*) ;;
*) echo "warning: tree is '$ver', this driver targets 6.18.x" >&2 ;;
esac

mkdir -p "$KSRC/drivers/accel/sfg1"
cp "$PKG"/kernel/Kconfig "$PKG"/kernel/Makefile "$PKG"/kernel/*.c "$PKG"/kernel/*.h \
   "$KSRC/drivers/accel/sfg1/"
cp "$PKG/include/uapi/drm/sfg1_accel.h" "$KSRC/include/uapi/drm/sfg1_accel.h"

grep -q 'accel/sfg1/Kconfig' "$KSRC/drivers/accel/Kconfig" ||
	sed -i 's|^source "drivers/accel/rocket/Kconfig"|&\nsource "drivers/accel/sfg1/Kconfig"|' \
		"$KSRC/drivers/accel/Kconfig"
mk="$KSRC/drivers/accel/Makefile"
if ! grep -q 'CONFIG_DRM_ACCEL_SFG1' "$mk"; then
	# upstream's Makefile may lack a trailing newline: appending blindly would
	# fuse our line onto the previous one and silently disable the driver
	[ -n "$(tail -c1 "$mk")" ] && echo >> "$mk"
	echo 'obj-$(CONFIG_DRM_ACCEL_SFG1)		+= sfg1/' >> "$mk"
fi
# fail loudly if the hook did not take
grep -q '^obj-$(CONFIG_DRM_ACCEL_SFG1)' "$mk" || { echo "Makefile hook missing" >&2; exit 1; }
echo "installed into $KSRC/drivers/accel/sfg1"
