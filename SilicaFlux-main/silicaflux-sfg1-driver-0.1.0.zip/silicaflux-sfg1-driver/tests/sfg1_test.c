// SPDX-License-Identifier: GPL-2.0-only
/*
 * sfg1_test.c — end-to-end test suite for the SF-G1 driver against the MOCK
 * device. Runs as PID 1 inside a QEMU-booted 6.18 kernel (tests/run-qemu.sh),
 * so a kernel oops/lockdep/KASAN/kmemleak report fails the run.
 *
 * What a pass means: the driver is self-consistent with the draft hardware
 * contract and behaves correctly under injected faults, on the software model.
 * It is NOT evidence about physical hardware (docs/06-limitations.md).
 */
#define _GNU_SOURCE
#include <linux/reboot.h>
#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <sys/mount.h>
#include <sys/reboot.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/wait.h>

#include "../examples/sfg1_user.h"

#define DBG "/sys/kernel/debug/sfg1-mock0/"
#define MOD_PARAMS                                                                      \
	"mock_devices=1 mock_max_ctx=4 mock_ctx_win_kib=1024 mock_cmd_delay_us=300 "    \
	"queue_entries=64 job_timeout_ms=300 reset_timeout_ms=200 quarantine_ms=2500 max_bos=64 "\
	"max_bo_size_mib=4 max_ctx_bo_mib=8 max_total_bo_mib=16 max_inflight_jobs=16 "  \
	"max_pending_results=32 strike_limit=3"
/* device completion status codes (docs/02-hw-interface.md); userspace sees them as dev_error */
#define HW_ST_BAD_OPCODE 1
#define HW_ST_DMA_ERROR 6
#define IGNORE(expr) do { ssize_t _ign = (expr); (void)_ign; } while (0)
#define WINDOW (1024u * 1024u)
#define MAXCMDS 63u			/* queue_entries=64 -> 63 usable slots */

static int g_pass, g_fail;
static const char *g_test = "?";
static char g_path[64];

#define EXPECT(cond, ...)                                                                \
	do {                                                                             \
		if (cond) {                                                              \
			g_pass++;                                                        \
		} else {                                                                 \
			g_fail++;                                                        \
			printf("  FAIL [%s] %s:%d: (%s) ", g_test, __FILE__, __LINE__, #cond); \
			printf(__VA_ARGS__);                                             \
			putchar('\n');                                                   \
		}                                                                        \
	} while (0)

/* expect ioctl-style result == -errno */
#define EXPECT_ERR(expr, err)                                                            \
	do {                                                                             \
		int _r = (expr);                                                         \
		EXPECT(_r == -(err), "%s -> %d (%s), want -%s", #expr, _r,               \
		       _r < 0 ? strerror(-_r) : "ok", #err);                             \
	} while (0)

#define NEED(cond, ...)                                                                  \
	do {                                                                             \
		if (!(cond)) {                                                           \
			g_fail++;                                                        \
			printf("  FAIL [%s] %s:%d: precondition (%s) ", g_test, __FILE__,  \
			       __LINE__, #cond);                                         \
			printf(__VA_ARGS__);                                             \
			putchar('\n');                                                   \
			return;                                                          \
		}                                                                        \
	} while (0)

/* ------------------------------------------------------------------------ */
/* plumbing                                                                  */
/* ------------------------------------------------------------------------ */
static long dbg_get(const char *name)
{
	char p[128], buf[32] = "";
	int fd;

	snprintf(p, sizeof(p), DBG "%s", name);
	fd = open(p, O_RDONLY);
	if (fd < 0)
		return -1;
	if (read(fd, buf, sizeof(buf) - 1) < 0)
		buf[0] = 0;
	close(fd);
	return strtol(buf, NULL, 0);
}

static int dbg_set(const char *name, unsigned long v)
{
	char p[128], buf[32];
	int fd, n;

	snprintf(p, sizeof(p), DBG "%s", name);
	fd = open(p, O_WRONLY);
	if (fd < 0)
		return -errno;
	n = snprintf(buf, sizeof(buf), "%lu\n", v);
	n = write(fd, buf, n) < 0 ? -errno : 0;
	close(fd);
	return n;
}

static void inject_clear(void)
{
	dbg_set("hang_after", 0xffffffffu);
	dbg_set("fail_after", 0xffffffffu);
	dbg_set("fail_status", 0);
	dbg_set("drop_irq", 0);
	dbg_set("reset_mode", 0);
	dbg_set("corrupt_cqe", 0);
}

static int write_file(const char *path, const char *s)
{
	int fd = open(path, O_WRONLY);
	int r = 0;

	if (fd < 0)
		return -errno;
	if (write(fd, s, strlen(s)) < 0)
		r = -errno;
	close(fd);
	return r;
}

static int load_module(const char *path, const char *params)
{
	int fd = open(path, O_RDONLY | O_CLOEXEC), r = 0;

	if (fd < 0)
		return -errno;
	if (syscall(SYS_finit_module, fd, params, 0))
		r = -errno;
	close(fd);
	return r;
}

static int unload_module(const char *name)
{
	return syscall(SYS_delete_module, name, O_NONBLOCK) ? -errno : 0;
}

static int wait_for_node(unsigned ms)
{
	for (unsigned t = 0; t < ms; t += 10) {
		if (!sfg1_find_device(g_path, sizeof(g_path)))
			return 0;
		usleep(10000);
	}
	return -ETIMEDOUT;
}

static int open_ctx(struct sfg1_dev *d)
{
	int r = sfg1_open(g_path, d);

	EXPECT(r == 0, "open_ctx: %s", strerror(-r));
	return r;
}

static int node_gone(void)
{
	char p[64];

	return sfg1_find_device(p, sizeof(p)) != 0;
}

static void get_stats(struct sfg1_dev *d, struct drm_sfg1_get_stats *s)
{
	memset(s, 0, sizeof(*s));
	EXPECT(sfg1_ioctl(d->fd, DRM_IOCTL_SFG1_GET_STATS, s) == 0, "GET_STATS");
}

static uint64_t param_or0(struct sfg1_dev *d, uint32_t p)
{
	uint64_t v = 0;

	sfg1_param(d, p, &v);
	return v;
}

static uint32_t rnd_state = 0x12345678;
static uint32_t rnd(void)
{
	rnd_state ^= rnd_state << 13;
	rnd_state ^= rnd_state >> 17;
	rnd_state ^= rnd_state << 5;
	return rnd_state;
}

/* ---- reference model (written from the spec, independent of the driver) -- */
static uint32_t ref_vec_word(uint32_t op, uint32_t x, uint32_t y)
{
	uint32_t out = 0;

	if (op == DRM_SFG1_VEC_XOR32)
		return x ^ y;
	if (op == DRM_SFG1_VEC_AND32)
		return x & y;
	for (int k = 0; k < 4; k++) {
		int a = (int8_t)(x >> (8 * k)), b = (int8_t)(y >> (8 * k)), r = 0;

		switch (op) {
		case DRM_SFG1_VEC_ADD8:  r = a + b; break;
		case DRM_SFG1_VEC_SUB8:  r = a - b; break;
		case DRM_SFG1_VEC_MAX8:  r = a > b ? a : b; break;
		case DRM_SFG1_VEC_RELU8: r = a < 0 ? 0 : a; break;
		case DRM_SFG1_VEC_MUL8:  r = a * b; break;
		}
		out |= (uint32_t)(uint8_t)r << (8 * k);
	}
	return out;
}

/* One job: stage in -> window -> op -> window -> stage out. Returns job result. */
static int vec_job(struct sfg1_dev *d, struct sfg1_bo *bo, uint32_t op, uint32_t words)
{
	const uint64_t n = (uint64_t)words * 4;
	const uint64_t out_words = op == DRM_SFG1_VEC_DOT8 ? 1 : words;
	struct drm_sfg1_cmd c[] = {
		sfg1_cmd_h2d(bo, 0, 0, n),
		sfg1_cmd_h2d(bo, n, n, n),
		/* RELU8 is unary: the contract requires dev_b == 0 */
		sfg1_cmd_vec(op, 0, op == DRM_SFG1_VEC_RELU8 ? 0 : n, 2 * n, words),
		sfg1_cmd_d2h(bo, 2 * n, 2 * n, out_words * 4),
	};

	return sfg1_run(d, c, 4);
}

/* ------------------------------------------------------------------------ */
/* functional tests                                                          */
/* ------------------------------------------------------------------------ */
static void t_discovery(void)
{
	struct sfg1_dev d;
	uint64_t v;
	struct drm_sfg1_get_param p;

	if (open_ctx(&d))
		return;
	EXPECT(!sfg1_param(&d, DRM_SFG1_PARAM_UAPI_VERSION, &v) && v == ((1u << 16) | 0),
	       "uapi version %#llx", (unsigned long long)v);
	EXPECT(!sfg1_param(&d, DRM_SFG1_PARAM_HW_VERSION, &v) && (v >> 16) == 1, "hw version");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_WINDOW_SIZE) == WINDOW, "window");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT) == MAXCMDS, "max cmds %llu",
	       (unsigned long long)param_or0(&d, DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT));
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_JOB_TIMEOUT_MS) == 300, "timeout");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_MAX_BO_SIZE) == 4u << 20, "max bo size");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_ID) < 4, "ctx id");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_STATE) == 0, "ctx state");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_VEC_OPS) == 0xff, "vec ops");

	p = (struct drm_sfg1_get_param){ .param = 9999 };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_GET_PARAM, &p), EINVAL);
	p = (struct drm_sfg1_get_param){ .param = 0, .pad = 1 };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_GET_PARAM, &p), EINVAL);
	sfg1_close(&d);
}

static void t_bo_basic(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo = {};
	struct drm_sfg1_bo_create a;
	struct drm_gem_close gc;
	uint8_t *m;

	if (open_ctx(&d))
		return;
	EXPECT(sfg1_bo_create(&d, 1, &bo) == 0, "create 1 byte");
	EXPECT(bo.size == (uint64_t)sysconf(_SC_PAGESIZE), "rounded to a page: %llu",
	       (unsigned long long)bo.size);
	m = bo.map;
	NEED(m, "mapped");
	for (uint64_t i = 0; i < bo.size; i++)
		EXPECT(m[i] == 0, "fresh BO must be zero (byte %llu)", (unsigned long long)i);
	memset(m, 0xa5, bo.size);
	EXPECT(m[bo.size - 1] == 0xa5, "CPU write visible");
	gc.handle = bo.handle;
	gc.pad = 0;
	sfg1_bo_destroy(&d, &bo);
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_GEM_CLOSE, &gc), EINVAL);	/* already closed */

	a = (struct drm_sfg1_bo_create){ .size = 0 };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_BO_CREATE, &a), EINVAL);
	a = (struct drm_sfg1_bo_create){ .size = 4096, .flags = 1 };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_BO_CREATE, &a), EINVAL);
	a = (struct drm_sfg1_bo_create){ .size = 4096, .reserved = 1 };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_BO_CREATE, &a), EINVAL);
	a = (struct drm_sfg1_bo_create){ .size = (4u << 20) + 1 };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_BO_CREATE, &a), EINVAL);
	a = (struct drm_sfg1_bo_create){ .size = UINT64_MAX };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_BO_CREATE, &a), EINVAL);
	EXPECT(sfg1_bo_create(&d, 4u << 20, &bo) == 0, "max size BO");
	sfg1_bo_destroy(&d, &bo);

	/* mapping more than the buffer is refused */
	EXPECT(sfg1_bo_create(&d, 4096, &bo) == 0, "create");
	void *big = mmap(NULL, 8192, PROT_READ, MAP_SHARED, d.fd, (off_t)bo.mmap_offset);
	EXPECT(big == MAP_FAILED, "over-size mmap must fail");
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
}

/* Recycled memory must never leak a previous owner's data. */
static void t_bo_zero_on_reuse(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	int dirty = 0;

	if (open_ctx(&d))
		return;
	for (int i = 0; i < 24; i++) {
		NEED(sfg1_bo_create(&d, 1u << 20, &bo) == 0, "create");
		for (size_t k = 0; k < bo.size; k += 8)
			dirty += *(uint64_t *)((uint8_t *)bo.map + k) != 0;
		memset(bo.map, 0xaa, bo.size);	/* poison, then free: next one may reuse it */
		sfg1_bo_destroy(&d, &bo);
	}
	EXPECT(dirty == 0, "%d non-zero words in freshly allocated BOs", dirty);
	sfg1_close(&d);
}

static void t_dma_roundtrip(void)
{
	struct sfg1_dev d;
	struct sfg1_bo in, out;
	const uint64_t n = 8192;

	if (open_ctx(&d))
		return;
	NEED(!sfg1_bo_create(&d, n, &in) && !sfg1_bo_create(&d, n + 4096, &out), "bos");
	for (uint64_t i = 0; i < n; i++)
		((uint8_t *)in.map)[i] = (uint8_t)rnd();
	struct drm_sfg1_cmd c[] = {
		sfg1_cmd_h2d(&in, 0, 0x1000, n),
		sfg1_cmd_d2h(&out, 0, 0x1000, n),
		/* the very last bytes of the window */
		sfg1_cmd_h2d(&in, 0, WINDOW - 64, 64),
		sfg1_cmd_d2h(&out, n, WINDOW - 64, 64),	/* beyond the compared region */
	};
	EXPECT(sfg1_run(&d, c, 4) == 0, "job");
	EXPECT(!memcmp(in.map, out.map, n), "round trip data mismatch");
	EXPECT(!memcmp(in.map, (uint8_t *)out.map + n, 64), "window-end copy mismatch");
	sfg1_bo_destroy(&d, &in);
	sfg1_bo_destroy(&d, &out);
	sfg1_close(&d);
}

static void t_vec_ops(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	const uint32_t words = 61;	/* odd on purpose */
	const uint64_t n = words * 4;

	if (open_ctx(&d))
		return;
	NEED(!sfg1_bo_create(&d, 4096, &bo), "bo");
	for (uint32_t op = 0; op <= DRM_SFG1_VEC_DOT8; op++) {
		uint32_t *w = bo.map;
		int bad = 0;

		for (uint32_t i = 0; i < 2 * words; i++)
			w[i] = rnd();
		memset((uint8_t *)bo.map + 2 * n, 0xee, 2048);
		EXPECT(vec_job(&d, &bo, op, words) == 0, "vec op %u job", op);
		if (op == DRM_SFG1_VEC_DOT8) {
			int32_t acc = 0;

			for (uint32_t i = 0; i < words; i++)
				for (int k = 0; k < 4; k++)
					acc += (int8_t)(w[i] >> (8 * k)) *
					       (int8_t)(w[words + i] >> (8 * k));
			bad = ((uint32_t *)((uint8_t *)bo.map + 2 * n))[0] != (uint32_t)acc;
		} else {
			uint32_t *o = (uint32_t *)((uint8_t *)bo.map + 2 * n);

			for (uint32_t i = 0; i < words; i++)
				bad += o[i] != ref_vec_word(op, w[i], w[words + i]);
		}
		EXPECT(!bad, "vec op %u: %d wrong results", op, bad);
	}
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
}

static void t_ten(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	const uint32_t tiles = 5;
	const uint64_t asz = 16u * tiles, csz = 64u * tiles;

	if (open_ctx(&d))
		return;
	NEED(!sfg1_bo_create(&d, 8192, &bo), "bo");
	int8_t *a = bo.map, *b = a + asz;
	int32_t *c = (int32_t *)((uint8_t *)bo.map + 2048);

	for (uint32_t i = 0; i < 2 * asz; i++)
		a[i] = (int8_t)rnd();
	struct drm_sfg1_cmd j[] = {
		sfg1_cmd_h2d(&bo, 0, 0, 2 * asz),
		sfg1_cmd_ten(0, asz, 2 * asz, tiles, 0),
		sfg1_cmd_d2h(&bo, 2048, 2 * asz, csz),
		sfg1_cmd_ten(0, asz, 2 * asz, tiles, 1),	/* accumulate: now 2x */
		sfg1_cmd_d2h(&bo, 4096, 2 * asz, csz),
	};
	EXPECT(sfg1_run(&d, j, 5) == 0, "job");
	int bad1 = 0, bad2 = 0;
	int32_t *c2 = (int32_t *)((uint8_t *)bo.map + 4096);

	for (uint32_t t = 0; t < tiles; t++)
		for (int i = 0; i < 4; i++)
			for (int jj = 0; jj < 4; jj++) {
				int32_t acc = 0;

				for (int k = 0; k < 4; k++)
					acc += a[16 * t + 4 * i + k] * b[16 * t + 4 * k + jj];
				bad1 += c[16 * t + 4 * i + jj] != acc;
				bad2 += c2[16 * t + 4 * i + jj] != 2 * acc;
			}
	EXPECT(!bad1, "TEN C=A*B: %d wrong", bad1);
	EXPECT(!bad2, "TEN C+=A*B: %d wrong", bad2);
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
}

/* Ordering: commands in a job, and jobs in a context, run strictly in order. */
static void t_ordering(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	uint64_t ids[12];
	uint32_t st, *w;

	if (open_ctx(&d))
		return;
	NEED(!sfg1_bo_create(&d, 4096, &bo), "bo");
	w = bo.map;
	w[0] = 0x01010101;	/* x */
	w[1] = 0x01010101;	/* y: result of "x += y" repeated */
	EXPECT(sfg1_run(&d, (struct drm_sfg1_cmd[]){ sfg1_cmd_h2d(&bo, 0, 0, 8) }, 1) == 0, "upload");
	/* 10 dependent jobs: dev[0] += dev[4] each time (in-place ADD8) */
	for (int i = 0; i < 10; i++) {
		struct drm_sfg1_cmd c = sfg1_cmd_vec(DRM_SFG1_VEC_ADD8, 0, 4, 0, 1);

		EXPECT(sfg1_submit(&d, &c, 1, &ids[i]) == 0, "submit %d", i);
		if (i)
			EXPECT(ids[i] == ids[i - 1] + 1, "job ids increase by one");
	}
	for (int i = 0; i < 10; i++)
		EXPECT(sfg1_wait(&d, ids[i], 2000, &st, NULL) == 0 && st == DRM_SFG1_JOB_OK, "wait %d", i);
	EXPECT(sfg1_run(&d, (struct drm_sfg1_cmd[]){ sfg1_cmd_d2h(&bo, 64, 0, 4) }, 1) == 0, "download");
	EXPECT(*(uint32_t *)((uint8_t *)bo.map + 64) == 0x0b0b0b0b, "10 in-order adds: got %#x",
	       *(uint32_t *)((uint8_t *)bo.map + 64));
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
}

static void t_wait_semantics(void)
{
	struct sfg1_dev d;
	struct drm_sfg1_cmd c[MAXCMDS];
	struct drm_sfg1_wait_job w;
	uint64_t id;
	uint32_t st;
	int r, spins = 0;

	if (open_ctx(&d))
		return;
	for (unsigned i = 0; i < MAXCMDS; i++)
		c[i] = sfg1_cmd_nop();
	NEED(!sfg1_submit(&d, c, MAXCMDS, &id), "submit");	/* ~63 x 300us */
	r = sfg1_wait(&d, id, 0, &st, NULL);			/* poll right away */
	EXPECT(r == -EBUSY || r == 0, "poll -> %d", r);
	if (r == -EBUSY) {
		w = (struct drm_sfg1_wait_job){ .job_id = id, .timeout_ns = sfg1_now_ns() + 100000 };
		EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_WAIT_JOB, &w), ETIMEDOUT);
		while ((r = sfg1_wait(&d, id, 0, &st, NULL)) == -EBUSY && spins++ < 5000)
			usleep(500);
	}
	EXPECT(r == 0 && st == DRM_SFG1_JOB_OK, "eventually OK (r=%d st=%u)", r, st);
	EXPECT_ERR(sfg1_wait(&d, id, 0, &st, NULL), ENOENT);	/* reaped: second wait fails */
	EXPECT_ERR(sfg1_wait(&d, 424242, 0, &st, NULL), ENOENT);
	w = (struct drm_sfg1_wait_job){ .job_id = 1, .flags = 1 };
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_WAIT_JOB, &w), EINVAL);
	sfg1_close(&d);
}

/* ------------------------------------------------------------------------ */
/* input validation                                                          */
/* ------------------------------------------------------------------------ */
struct bad_case {
	const char *name;
	struct drm_sfg1_cmd cmd;
	int err;
};

static void t_validation(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	struct drm_sfg1_get_stats s0, s1;
	struct drm_sfg1_submit sub;
	struct drm_sfg1_cmd good = sfg1_cmd_nop(), ext[2];
	const uint64_t W = WINDOW;
	long v0 = dbg_get("dma_violations");

	if (open_ctx(&d))
		return;
	NEED(!sfg1_bo_create(&d, 4096, &bo), "bo");
	get_stats(&d, &s0);

#define C(...) ((struct drm_sfg1_cmd){ __VA_ARGS__ })
	const struct bad_case cases[] = {
		{ "unknown opcode",        C(.op = 99), EINVAL },
		{ "SCRUB is kernel-only",  C(.op = 6), EINVAL },
		{ "reserved opcode 4",     C(.op = 4), EINVAL },
		{ "reserved field set",    C(.op = 0, .reserved = 1), EINVAL },
		{ "NOP with garbage",      C(.op = 0, .len = 4), EINVAL },
		{ "NOP with flags",        C(.op = 0, .flags = 1), EINVAL },
		{ "h2d handle 0",          C(.op = 1, .bo_handle = 0, .len = 4), ENOENT },
		{ "h2d unknown handle",    C(.op = 1, .bo_handle = 0xdeadbeef, .len = 4), ENOENT },
		{ "h2d len 0",             C(.op = 1, .bo_handle = bo.handle, .len = 0), EINVAL },
		{ "h2d len unaligned",     C(.op = 1, .bo_handle = bo.handle, .len = 3), EINVAL },
		{ "h2d bo_off unaligned",  C(.op = 1, .bo_handle = bo.handle, .bo_offset = 2, .len = 4), EINVAL },
		{ "h2d dev unaligned",     C(.op = 1, .bo_handle = bo.handle, .dev_a = 2, .len = 4), EINVAL },
		{ "h2d past BO end",       C(.op = 1, .bo_handle = bo.handle, .bo_offset = 4096, .len = 4), EINVAL },
		{ "h2d BO len too big",    C(.op = 1, .bo_handle = bo.handle, .len = 4100), EINVAL },
		{ "h2d bo_off overflow",   C(.op = 1, .bo_handle = bo.handle, .bo_offset = UINT64_MAX - 3, .len = 8), EINVAL },
		{ "h2d len overflow",      C(.op = 1, .bo_handle = bo.handle, .bo_offset = 8, .len = UINT64_MAX - 3), EINVAL },
		{ "h2d window end+4",      C(.op = 1, .bo_handle = bo.handle, .dev_a = W - 4, .len = 8), EINVAL },
		{ "h2d dev_a huge",        C(.op = 1, .bo_handle = bo.handle, .dev_a = UINT64_MAX & ~3ULL, .len = 4), EINVAL },
		{ "h2d extra dev_b",       C(.op = 1, .bo_handle = bo.handle, .dev_b = 4, .len = 4), EINVAL },
		{ "h2d with flags",        C(.op = 1, .bo_handle = bo.handle, .flags = 1, .len = 4), EINVAL },
		{ "d2h past BO end",       C(.op = 5, .bo_handle = bo.handle, .bo_offset = 4092, .len = 8), EINVAL },
		{ "vec bad exec_op",       C(.op = 2, .exec_op = 8, .len = 1), EINVAL },
		{ "vec len 0",             C(.op = 2, .exec_op = 0, .len = 0), EINVAL },
		{ "vec len*4 overflow",    C(.op = 2, .exec_op = 0, .len = 1ULL << 62), EINVAL },
		{ "vec A past window",     C(.op = 2, .exec_op = 0, .len = W / 4, .dev_a = 4, .dev_b = 0, .dev_c = 0), EINVAL },
		{ "vec len > window",      C(.op = 2, .exec_op = 0, .len = W / 4 + 1), EINVAL },
		{ "vec C past window",     C(.op = 2, .exec_op = 0, .len = 4, .dev_c = W - 8), EINVAL },
		{ "vec unaligned A",       C(.op = 2, .exec_op = 0, .len = 1, .dev_a = 1), EINVAL },
		{ "vec with handle",       C(.op = 2, .exec_op = 0, .len = 1, .bo_handle = bo.handle), EINVAL },
		{ "vec with flags",        C(.op = 2, .exec_op = 0, .len = 1, .flags = 1), EINVAL },
		{ "relu with dev_b",       C(.op = 2, .exec_op = 3, .len = 1, .dev_b = 8), EINVAL },
		{ "dot C past window",     C(.op = 2, .exec_op = 7, .len = 1, .dev_c = W - 2), EINVAL },
		{ "ten len 0",             C(.op = 3, .len = 0), EINVAL },
		{ "ten len*16 overflow",   C(.op = 3, .len = 1ULL << 60), EINVAL },
		{ "ten C too big",         C(.op = 3, .len = W / 64 + 1), EINVAL },
		{ "ten bad flag",          C(.op = 3, .len = 1, .flags = 2), EINVAL },
		{ "ten with exec_op",      C(.op = 3, .len = 1, .exec_op = 1), EINVAL },
		{ "ten C at window end",   C(.op = 3, .len = 1, .dev_c = W - 32), EINVAL },
	};
	for (unsigned i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
		int r = sfg1_submit(&d, &cases[i].cmd, 1, NULL);

		EXPECT(r == -cases[i].err, "%s -> %d (%s), want -%d", cases[i].name, r,
		       r < 0 ? strerror(-r) : "accepted", cases[i].err);
	}

	/* submit-level argument checks */
	sub = (struct drm_sfg1_submit){ .cmds_ptr = (uintptr_t)&good, .cmd_count = 1, .cmd_stride = 64 };
	EXPECT(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_SUBMIT, &sub) == 0, "baseline NOP submit");
	{ uint32_t st; EXPECT(sfg1_wait(&d, sub.job_id, 1000, &st, NULL) == 0 && st == 0, "reap baseline"); }
#define SUBCASE(name, field, val, err) do {                                              \
		sub = (struct drm_sfg1_submit){ .cmds_ptr = (uintptr_t)&good, .cmd_count = 1,\
						.cmd_stride = 64 };                  \
		sub.field = (val);                                                           \
		EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_SUBMIT, &sub), err);              \
	} while (0)
	SUBCASE("count 0", cmd_count, 0, EINVAL);
	SUBCASE("count max+1", cmd_count, MAXCMDS + 1, EINVAL);
	SUBCASE("stride too small", cmd_stride, 56, EINVAL);
	SUBCASE("stride unaligned", cmd_stride, 68, EINVAL);
	SUBCASE("stride > page", cmd_stride, 8192, EINVAL);
	SUBCASE("flags", flags, 1, EINVAL);
	SUBCASE("pad", pad, 1, EINVAL);
	SUBCASE("reserved", reserved, 1, EINVAL);
	SUBCASE("null cmds", cmds_ptr, 0, EFAULT);
	SUBCASE("kernel-range cmds", cmds_ptr, 0xffff800000000000ULL, EFAULT);
	SUBCASE("unmapped cmds", cmds_ptr, 1, EFAULT);

	/* forward compatibility: a larger stride with a zero tail is accepted ... */
	memset(ext, 0, sizeof(ext));
	sub = (struct drm_sfg1_submit){ .cmds_ptr = (uintptr_t)ext, .cmd_count = 1, .cmd_stride = 72 };
	{ struct { struct drm_sfg1_cmd c; uint64_t tail; } wide[2] = {};
	  sub.cmds_ptr = (uintptr_t)wide; sub.cmd_stride = sizeof(wide[0]);
	  EXPECT(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_SUBMIT, &sub) == 0, "stride 72, zero tail accepted");
	  { uint32_t st; sfg1_wait(&d, sub.job_id, 1000, &st, NULL); }
	  /* ... and a non-zero tail (unknown newer field) is rejected, not ignored */
	  wide[0].tail = 1;
	  sub.cmd_count = 1;
	  EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_SUBMIT, &sub), E2BIG);
	  /* second command's tail is checked too */
	  wide[0].tail = 0; wide[1].tail = 1; sub.cmd_count = 2;
	  EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_SUBMIT, &sub), E2BIG); }

	/* A command whose LATER entry is bad must reject the whole batch: nothing runs. */
	{ struct drm_sfg1_cmd mix[3] = { sfg1_cmd_nop(), sfg1_cmd_nop(), C(.op = 99) };
	  EXPECT_ERR(sfg1_submit(&d, mix, 3, NULL), EINVAL); }

	get_stats(&d, &s1);
	EXPECT(s1.jobs_submitted == s0.jobs_submitted + 2, "rejected submits must not create jobs (%llu vs %llu)",
	       (unsigned long long)s1.jobs_submitted, (unsigned long long)s0.jobs_submitted);
	EXPECT(s1.bo_count == 1 && s1.bo_bytes == 4096, "BO accounting unchanged by rejected submits");
	EXPECT(sfg1_run(&d, &good, 1) == 0, "device still healthy after hostile input");
	EXPECT(dbg_get("dma_violations") == v0, "hostile input must not cause a device-side violation");
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
#undef C
#undef SUBCASE
}

/* ------------------------------------------------------------------------ */
/* quotas / resource accounting                                              */
/* ------------------------------------------------------------------------ */
static void t_quota(void)
{
	struct sfg1_dev d, e, f, g, h;
	struct sfg1_bo bos[70];
	struct drm_sfg1_get_stats s;
	int n = 0, r;

	if (open_ctx(&d))
		return;

	/* per-context BO count (max_bos=64) */
	for (; n < 64; n++) {
		r = sfg1_bo_create(&d, 4096, &bos[n]);
		if (r)
			break;
	}
	EXPECT(n == 64, "created %d BOs, want 64", n);
	EXPECT_ERR(sfg1_bo_create(&d, 4096, &bos[64]), ENOSPC);
	get_stats(&d, &s);
	EXPECT(s.bo_count == 64 && s.bo_bytes == 64 * 4096ULL, "count=%llu bytes=%llu",
	       (unsigned long long)s.bo_count, (unsigned long long)s.bo_bytes);
	for (int i = 0; i < n; i++)
		sfg1_bo_destroy(&d, &bos[i]);
	get_stats(&d, &s);
	EXPECT(s.bo_count == 0 && s.bo_bytes == 0, "all refunded after close: %llu/%llu",
	       (unsigned long long)s.bo_count, (unsigned long long)s.bo_bytes);
	EXPECT(s.bo_bytes_peak == 64 * 4096ULL, "peak tracked %llu", (unsigned long long)s.bo_bytes_peak);

	/* per-context bytes (8 MiB) and device total (16 MiB) */
	EXPECT(!sfg1_bo_create(&d, 4u << 20, &bos[0]), "4 MiB #1");
	EXPECT(!sfg1_bo_create(&d, 4u << 20, &bos[1]), "4 MiB #2");
	EXPECT_ERR(sfg1_bo_create(&d, 4096, &bos[2]), ENOSPC);	/* ctx cap reached */
	get_stats(&d, &s);
	EXPECT(s.bo_bytes == 8ULL << 20, "ctx bytes %llu", (unsigned long long)s.bo_bytes);
	EXPECT(!sfg1_open(g_path, &e) && !sfg1_bo_create(&e, 4u << 20, &bos[3]) &&
	       !sfg1_bo_create(&e, 4u << 20, &bos[4]), "second ctx 8 MiB (device total now 16 MiB)");
	EXPECT(!sfg1_open(g_path, &f), "third ctx");
	EXPECT_ERR(sfg1_bo_create(&f, 4096, &bos[5]), ENOSPC);	/* device-wide cap */
	get_stats(&f, &s);
	EXPECT(s.bo_count == 0 && s.bo_bytes == 0, "failed device-wide charge fully refunded");
	sfg1_bo_destroy(&d, &bos[0]);
	EXPECT(!sfg1_bo_create(&f, 4u << 20, &bos[5]), "space freed by another ctx is reusable");
	sfg1_bo_destroy(&f, &bos[5]);
	sfg1_bo_destroy(&d, &bos[1]);
	sfg1_bo_destroy(&e, &bos[3]);
	sfg1_bo_destroy(&e, &bos[4]);

	/* hardware contexts (mock_max_ctx=4): d, e, f open; two more -> one succeeds, then EBUSY */
	EXPECT(!sfg1_open(g_path, &g), "4th context");
	r = sfg1_open(g_path, &h);
	EXPECT(r == -EBUSY, "5th context -> %d (%s), want EBUSY", r, strerror(-r));
	sfg1_close(&g);
	EXPECT(!sfg1_open(g_path, &h), "slot freed by close is reusable");
	sfg1_close(&h);
	sfg1_close(&f);
	sfg1_close(&e);

	/* in-flight job cap (16) and unreaped-result cap (32) */
	{
		struct drm_sfg1_cmd slow[MAXCMDS];
		uint64_t ids[40];
		uint32_t st;
		int ok = 0;

		for (unsigned i = 0; i < MAXCMDS; i++)
			slow[i] = sfg1_cmd_nop();
		dbg_set("cmd_delay_us", 3000);		/* ~190 ms per job: cannot retire while we submit */
		for (int i = 0; i < 20; i++) {
			r = sfg1_submit(&d, slow, MAXCMDS, &ids[ok]);
			if (r == 0)
				ok++;
			else
				break;
		}
		EXPECT(r == -EBUSY && ok == 16, "in-flight cap: %d accepted (want 16), r=%d (%s)", ok, r,
		       r < 0 ? strerror(-r) : "ok");
		for (int i = 0; i < ok; i++)
			EXPECT(sfg1_wait(&d, ids[i], 20000, &st, NULL) == 0 && st == 0, "drain %d", i);
		dbg_set("cmd_delay_us", 300);
		/* now fill the unreaped table: submit NOPs, let them finish, do not wait */
		struct drm_sfg1_cmd nop = sfg1_cmd_nop();
		int unreaped = 0;

		for (int i = 0; i < 40; i++) {
			r = sfg1_submit(&d, &nop, 1, &ids[unreaped % 40]);
			if (r == -EBUSY && i < 32) {
				usleep(20000);	/* alive cap, not result cap: let jobs retire */
				i--;
				continue;
			}
			if (r)
				break;
			unreaped++;
			usleep(2000);
		}
		EXPECT(unreaped == 32 && r == -EBUSY, "unreaped cap: accepted %d, r=%d", unreaped, r);
		struct drm_sfg1_wait_job w = { .job_id = 1, .timeout_ns = sfg1_now_ns() + 2000000000LL };
		/* reap everything so the context is clean */
		for (uint64_t id = 1; id <= 200; id++) {
			w.job_id = id;
			w.timeout_ns = 0;
			ioctl(d.fd, DRM_IOCTL_SFG1_WAIT_JOB, &w);
		}
		EXPECT(sfg1_run(&d, &nop, 1) == 0, "submits possible again after reaping");
	}
	sfg1_close(&d);
}

/* ------------------------------------------------------------------------ */
/* isolation between processes                                               */
/* ------------------------------------------------------------------------ */
static int child_result(pid_t pid)
{
	int st = 0;

	waitpid(pid, &st, 0);
	return WIFEXITED(st) ? WEXITSTATUS(st) : 100 + WTERMSIG(st);
}

static void t_isolation(void)
{
	struct sfg1_dev a;
	struct sfg1_bo secret, scratch;
	struct drm_gem_flink fl;
	int up[2], down[2];
	pid_t pid;
	long v0 = dbg_get("dma_violations");

	if (open_ctx(&a))
		return;
	NEED(!sfg1_bo_create(&a, 8192, &secret) && !sfg1_bo_create(&a, 4096, &scratch), "bos");
	memset(secret.map, 0x5a, 8192);
	/* A also puts a secret into ITS device window and keeps the context open */
	EXPECT(sfg1_run(&a, (struct drm_sfg1_cmd[]){ sfg1_cmd_h2d(&secret, 0, 0, 8192) }, 1) == 0, "A upload");

	/* a flink name for A's BO (we are root in this VM, so FLINK is permitted: it is the
	 * hardest case for the driver's own ownership check) */
	fl.handle = secret.handle;
	NEED(sfg1_ioctl(a.fd, DRM_IOCTL_GEM_FLINK, &fl) == 0, "flink (root)");
	NEED(!pipe(up) && !pipe(down), "pipes");

	pid = fork();
	if (pid == 0) {
		struct sfg1_dev b;
		struct sfg1_bo mine;
		struct drm_gem_open go = { .name = fl.name };
		struct drm_prime_handle ph;
		int bad = 0, r;
		void *m;
		uint8_t buf[64];

		if (sfg1_open(g_path, &b))
			_exit(90);
		if (sfg1_bo_create(&b, 4096, &mine))
			_exit(91);
		bad += b.ctx_id == 0 + (uint32_t)-1;	/* silence unused */

		/* 1. A's handle number on B's fd */
		for (uint32_t h = 1; h < 40; h++) {
			struct sfg1_bo fake = { .handle = h };
			struct drm_sfg1_cmd c = sfg1_cmd_d2h(&fake, 0, 0, 4096);

			r = sfg1_submit(&b, &c, 1, NULL);
			/* B's own BO sits at some small handle: that one is B's, others must miss */
			if (h != mine.handle && r != -ENOENT) {
				printf("  child: foreign handle %u -> %d\n", h, r);
				bad++;
			}
		}
		/* 2. A's mmap offset */
		m = mmap(NULL, 8192, PROT_READ, MAP_SHARED, b.fd, (off_t)secret.mmap_offset);
		if (m != MAP_FAILED) {
			printf("  child: MAPPED A's buffer!\n");
			bad++;
		}
		/* 3. dma-buf export of own BO is refused */
		ph = (struct drm_prime_handle){ .handle = mine.handle };
		r = sfg1_ioctl(b.fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph);
		if (r != -EPERM) {
			printf("  child: dma-buf export of own BO -> %d (%s), want EPERM\n", r,
			       r < 0 ? strerror(-r) : "SUCCEEDED");
			bad++;
		}
		/* 4. via flink + GEM_OPEN the handle DOES reach B's fd (root) ... */
		r = sfg1_ioctl(b.fd, DRM_IOCTL_GEM_OPEN, &go);
		if (r == 0) {
			struct sfg1_bo stolen = { .handle = go.handle };
			struct drm_sfg1_cmd c = sfg1_cmd_d2h(&stolen, 0, 0, 4096);

			/* ... but the driver's own ownership check must still refuse to use it */
			r = sfg1_submit(&b, &c, 1, NULL);
			if (r != -EACCES) {
				printf("  child: flink'd handle accepted by SUBMIT (%d)\n", r);
				bad++;
			}
			/* and mapping it is refused too (mmap offset not authorised for this file) */
			m = mmap(NULL, 8192, PROT_READ, MAP_SHARED, b.fd, (off_t)go.size /*unused*/);
			(void)m;
		}
		/* 5. device-memory window: B's window starts zeroed and is private */
		memset(mine.map, 0xff, 4096);
		struct drm_sfg1_cmd c = sfg1_cmd_d2h(&mine, 0, 0, 64);

		if (sfg1_run(&b, &c, 1)) {
			printf("  child: window read failed\n");
			bad++;
		}
		memcpy(buf, mine.map, 64);
		for (int i = 0; i < 64; i++)
			if (buf[i]) {
				printf("  child: saw non-zero byte %#x in own fresh window (A's data?)\n", buf[i]);
				bad++;
				break;
			}
		/* B cannot address beyond its window to reach a neighbour's */
		c = sfg1_cmd_d2h(&mine, 0, WINDOW, 64);
		if (sfg1_submit(&b, &c, 1, NULL) != -EINVAL)
			bad++;
		c = sfg1_cmd_d2h(&mine, 0, (uint64_t)-1024 & ~3ULL, 64);	/* "negative" offset */
		if (sfg1_submit(&b, &c, 1, NULL) != -EINVAL)
			bad++;
		IGNORE(write(up[1], "x", 1));			/* tell the parent B is done probing */
		IGNORE(read(down[0], buf, 1));			/* wait until parent has closed A */
		sfg1_close(&b);
		_exit(bad ? 1 : 0);
	}

	/* parent: wait for the child's probing, then verify A's data is intact */
	{
		char c;

		IGNORE(read(up[0], &c, 1));
		memset(scratch.map, 0, 4096);
		EXPECT(sfg1_run(&a, (struct drm_sfg1_cmd[]){ sfg1_cmd_d2h(&scratch, 0, 0, 64) }, 1) == 0, "A read back");
		EXPECT(((uint8_t *)scratch.map)[0] == 0x5a && ((uint8_t *)scratch.map)[63] == 0x5a,
		       "A's window data was disturbed by B");
		EXPECT(((uint8_t *)secret.map)[100] == 0x5a, "A's host BO was disturbed by B");
	}

	/* A exits; its context slot is reused by a new process which must see ZEROS (scrub) */
	{
		uint32_t a_slot = a.ctx_id;
		struct sfg1_dev c;
		struct sfg1_bo chk;
		uint8_t *p;
		int nonzero = 0;

		sfg1_bo_destroy(&a, &secret);
		sfg1_bo_destroy(&a, &scratch);
		sfg1_close(&a);
		usleep(100000);			/* postclose scrubs the window */
		IGNORE(write(down[1], "x", 1));
		EXPECT(child_result(pid) == 0, "child (hostile process B) reported a breach");

		/* open contexts until we get A's old slot */
		struct sfg1_dev tmp[4];
		int nt = 0, found = 0;

		for (; nt < 4; nt++) {
			if (sfg1_open(g_path, &tmp[nt]))
				break;
			if (tmp[nt].ctx_id == a_slot) {
				c = tmp[nt];
				found = 1;
				nt++;
				break;
			}
		}
		EXPECT(found, "could not get A's old slot back");
		if (found && !sfg1_bo_create(&c, 8192, &chk)) {
			memset(chk.map, 0xff, 8192);
			EXPECT(sfg1_run(&c, (struct drm_sfg1_cmd[]){ sfg1_cmd_d2h(&chk, 0, 0, 8192) }, 1) == 0, "read reused window");
			p = chk.map;
			for (int i = 0; i < 8192; i++)
				nonzero += p[i] != 0;
			EXPECT(nonzero == 0, "reused window leaked %d bytes of the previous owner's data", nonzero);
			sfg1_bo_destroy(&c, &chk);
		}
		for (int i = 0; i < nt; i++)
			sfg1_close(&tmp[i]);
	}
	EXPECT(dbg_get("dma_violations") == v0, "device observed %ld isolation violations during hostile run",
	       dbg_get("dma_violations") - v0);
	close(up[0]); close(up[1]); close(down[0]); close(down[1]);
}

/* The "0 violations" result is only meaningful if the audit can see one. */
static void t_oracle_selftest(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	long v0, v1;

	if (open_ctx(&d))
		return;
	NEED(!sfg1_bo_create(&d, 4096, &bo), "bo");
	v0 = dbg_get("dma_violations");
	EXPECT(dbg_set("oracle_selftest", 1) == 0, "trigger");
	v1 = dbg_get("dma_violations");
	EXPECT(v1 == v0 + 2, "audit missed the deliberate violations: %ld -> %ld (want +2)", v0, v1);
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
}

/*
 * An unprivileged process (uid 1000, node made world-accessible for the test) can use its own
 * context normally but cannot create cross-process handles: GEM flink/open need
 * CAP_SYS_ADMIN on accel nodes, and dma-buf export is refused for everyone.
 */
static void t_unprivileged(void)
{
	pid_t pid;

	EXPECT(chmod(g_path, 0666) == 0, "chmod node");
	pid = fork();
	if (pid == 0) {
		struct sfg1_dev d;
		struct sfg1_bo bo;
		struct drm_gem_flink fl;
		struct drm_gem_open go = { .name = 1 };
		struct drm_prime_handle ph;
		int bad = 0, r;

		if (setgid(1000) || setuid(1000) || geteuid() != 1000)
			_exit(90);
		if (sfg1_open(g_path, &d))
			_exit(91);
		if (sfg1_bo_create(&d, 4096, &bo))
			_exit(92);
		fl.handle = bo.handle;
		fl.name = 0;
		r = sfg1_ioctl(d.fd, DRM_IOCTL_GEM_FLINK, &fl);
		if (r != -EACCES) {
			printf("  unprivileged flink -> %d (%s), want EACCES\n", r, r ? strerror(-r) : "ok");
			bad++;
		}
		r = sfg1_ioctl(d.fd, DRM_IOCTL_GEM_OPEN, &go);
		if (r != -EACCES) {
			printf("  unprivileged GEM_OPEN -> %d (%s), want EACCES\n", r, r ? strerror(-r) : "ok");
			bad++;
		}
		ph = (struct drm_prime_handle){ .handle = bo.handle };
		r = sfg1_ioctl(d.fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph);
		if (r != -EPERM) {
			printf("  unprivileged prime export -> %d, want EPERM\n", r);
			bad++;
		}
		if (sfg1_run(&d, (struct drm_sfg1_cmd[]){ sfg1_cmd_nop() }, 1)) {
			printf("  unprivileged job failed\n");
			bad++;
		}
		_exit(bad);
	}
	EXPECT(child_result(pid) == 0, "unprivileged client misbehaved (see lines above)");
	chmod(g_path, 0600);
}

static void t_stats_fdinfo(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	struct drm_sfg1_get_stats s;
	struct drm_sfg1_cmd c[3] = { sfg1_cmd_nop(), sfg1_cmd_nop(), sfg1_cmd_nop() };
	char p[64], buf[1024] = "";
	int fd, n;

	if (open_ctx(&d))
		return;
	NEED(!sfg1_bo_create(&d, 8192, &bo), "bo");
	for (int i = 0; i < 4; i++)
		EXPECT(sfg1_run(&d, c, 3) == 0, "job");
	get_stats(&d, &s);
	EXPECT(s.jobs_submitted == 4 && s.jobs_ok == 4 && s.cmds_submitted == 12, "counters %llu/%llu/%llu",
	       (unsigned long long)s.jobs_submitted, (unsigned long long)s.jobs_ok,
	       (unsigned long long)s.cmds_submitted);
	EXPECT(s.jobs_error == 0 && s.jobs_timeout == 0 && s.jobs_canceled == 0, "no failures");
	EXPECT(s.busy_ns > 0, "busy time attributed");
	EXPECT(s.bo_bytes == 8192 && s.ctx_state == 0, "bytes/state");
	snprintf(p, sizeof(p), "/proc/self/fdinfo/%d", d.fd);
	fd = open(p, O_RDONLY);
	n = fd >= 0 ? (int)read(fd, buf, sizeof(buf) - 1) : -1;
	if (fd >= 0)
		close(fd);
	EXPECT(n > 0 && strstr(buf, "drm-driver:\tsfg1") && strstr(buf, "drm-engine-compute:") &&
	       strstr(buf, "drm-total-memory:\t8 KiB") && strstr(buf, "sfg1-ctx-id:"),
	       "fdinfo missing fields:\n%s", buf);
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
}

static int spawn_wait(const char *prog)
{
	pid_t pid = fork();

	if (pid == 0) {
		execl(prog, prog, (char *)NULL);
		_exit(127);
	}
	return child_result(pid);
}

static void t_examples(void)
{
	static const char *progs[] = { "/ex1_info", "/ex2_vector_add", "/ex3_matmul",
				       "/ex4_isolation_demo", "/ex5_error_handling" };

	for (unsigned i = 0; i < sizeof(progs) / sizeof(progs[0]); i++) {
		int r = spawn_wait(progs[i]);

		EXPECT(r == 0, "%s exited with %d", progs[i], r);
	}
}

/* continued in sfg1_test_faults.inc (recovery, removal, stress, alloc failure) */
#include "sfg1_test_faults.inc"
