#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-only
# Boot a Linux 6.18 test kernel under QEMU, load sfg1.ko with MOCK devices and
# run tests/sfg1_test.c as PID 1. Fails on any test failure OR any kernel splat
# (KASAN, lockdep, UBSAN, WARNING, oops, kmemleak, ...).
#
#   tests/run-qemu.sh <kernel-build-dir> [sfg1.ko] [timeout-seconds]
#
# <kernel-build-dir> must be a 6.18 build made with tests/kernel-test.config
# (see docs/05-testing.md); gpu-sched.ko is taken from it.
set -euo pipefail

KBUILD=$(readlink -f "${1:?usage: $0 <kernel-build-dir> [sfg1.ko] [timeout]}")
PKG=$(cd "$(dirname "$0")/.." && pwd)
KO=$(readlink -f "${2:-$PKG/kernel/sfg1.ko}")
TMO=${3:-1500}
WORK=${WORK:-$(mktemp -d)}
LOG=${LOG:-$WORK/console.log}

for f in "$KBUILD/arch/x86/boot/bzImage" "$KBUILD/drivers/gpu/drm/scheduler/gpu-sched.ko" "$KO"; do
	[ -f "$f" ] || { echo "missing $f" >&2; exit 2; }
done

mkdir -p "$WORK/root"
CFLAGS="-O2 -static -Wall -Wextra -Werror -Wno-error=unused-result -I$PKG/include/uapi"
gcc $CFLAGS -o "$WORK/root/init" "$PKG/tests/sfg1_test.c"
for ex in ex1_info ex2_vector_add ex3_matmul ex4_isolation_demo ex5_error_handling; do
	gcc $CFLAGS -o "$WORK/root/$ex" "$PKG/examples/$ex.c"
done
cp "$KO" "$WORK/root/sfg1.ko"
cp "$KBUILD/drivers/gpu/drm/scheduler/gpu-sched.ko" "$WORK/root/gpu-sched.ko"
(cd "$WORK/root" && find . | cpio -o -H newc --quiet | gzip -1) > "$WORK/initramfs.gz"

echo "booting (log: $LOG) ..."
set +e
timeout "$TMO" qemu-system-x86_64 -machine pc -cpu max -smp 4 -m 1536 -nographic -no-reboot \
	-accel tcg,thread=multi \
	-kernel "$KBUILD/arch/x86/boot/bzImage" -initrd "$WORK/initramfs.gz" \
	-append "console=ttyS0 panic=-1 oops=panic rdinit=/init loglevel=6" \
	> "$LOG" 2>&1
RC=$?
set -e

echo "---- test output ----"
sed -n '/SFG1 TEST START/,$p' "$LOG" | tr -d '\r' | grep -v '^\[ *[0-9.]*\] *$' | head -600
echo "---------------------"

FAIL=0
grep -q "SFG1 TEST RESULT: PASS" "$LOG" || { echo "RESULT line missing or FAIL (qemu rc=$RC)"; FAIL=1; }
SPLAT='BUG:|WARNING:|KASAN:|UBSAN:|Oops|general protection|possible (circular|recursive)|inconsistent lock|suspicious RCU|kernel BUG|Kernel panic|Call Trace|unable to handle|lockdep'
if grep -En "$SPLAT" "$LOG" | tr -d '\r' | grep -v "Call Trace.*fault-injection"; then
	echo "KERNEL SPLAT(S) FOUND in console log"; FAIL=1
fi
[ $FAIL -eq 0 ] && echo "ALL GOOD: tests passed and no kernel splats" || echo "FAILED"
exit $FAIL
