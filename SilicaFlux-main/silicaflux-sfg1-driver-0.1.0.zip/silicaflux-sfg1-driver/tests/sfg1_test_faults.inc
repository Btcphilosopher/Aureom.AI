/* SPDX-License-Identifier: GPL-2.0-only */
/* Second half of sfg1_test.c: recovery, removal, allocation failure, stress, main(). */

static struct drm_sfg1_cmd NOP1;
static long quarantined_windows(struct sfg1_dev *d);
static int unbind_bind(const char *what);

static uint64_t engine_resets(struct sfg1_dev *d)
{
	struct drm_sfg1_get_stats s;

	get_stats(d, &s);
	return s.device_engine_resets;
}

/* ------------------------------------------------------------------------ */
/* device-reported errors and protocol faults                                */
/* ------------------------------------------------------------------------ */
static void t_error_cqe(void)
{
	struct sfg1_dev d, o;
	struct drm_sfg1_get_stats s;
	struct drm_sfg1_cmd three[3] = { NOP1, NOP1, NOP1 };
	uint64_t id, r0;
	uint32_t st, de;

	if (open_ctx(&d) || open_ctx(&o))
		return;
	r0 = engine_resets(&d);

	/* second command of a job fails with DMA_ERROR */
	inject_clear();
	dbg_set("fail_status", HW_ST_DMA_ERROR);
	dbg_set("fail_after", 1);
	NEED(!sfg1_submit(&d, three, 3, &id), "submit");
	EXPECT(sfg1_wait(&d, id, 5000, &st, &de) == 0, "wait");
	EXPECT(st == DRM_SFG1_JOB_ERROR && de == HW_ST_DMA_ERROR, "status=%s dev_error=%u",
	       sfg1_job_status_str(st), de);
	get_stats(&d, &s);
	EXPECT(s.jobs_error == 1, "jobs_error=%llu", (unsigned long long)s.jobs_error);
	EXPECT(s.device_engine_resets == r0 + 1, "an error must reset the engine once (%llu -> %llu)",
	       (unsigned long long)r0, (unsigned long long)s.device_engine_resets);
	EXPECT(sfg1_run(&d, &NOP1, 1) == 0, "same context still usable after one failure");
	EXPECT(sfg1_run(&o, &NOP1, 1) == 0, "other context unaffected");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_STATE) == 0, "one strike is not a ban");
	sfg1_close(&d);

	/* every documented device status is reported verbatim */
	for (uint32_t code = 1; code <= 7; code++) {
		if (open_ctx(&d))
			return;
		dbg_set("fail_status", code);
		dbg_set("fail_after", 0);
		NEED(!sfg1_submit(&d, &NOP1, 1, &id), "submit");
		EXPECT(sfg1_wait(&d, id, 5000, &st, &de) == 0 && st == DRM_SFG1_JOB_ERROR && de == code,
		       "code %u -> status=%u dev_error=%u", code, st, de);
		sfg1_close(&d);
	}

	/* a hardware PROTOCOL violation (bad cid in a CQE) is not the user's fault: no strike */
	if (open_ctx(&d))
		return;
	for (int i = 0; i < 5; i++) {
		dbg_set("corrupt_cqe", 1);
		NEED(!sfg1_submit(&d, &NOP1, 1, &id), "submit");
		EXPECT(sfg1_wait(&d, id, 5000, &st, NULL) == 0 && st == DRM_SFG1_JOB_ERROR,
		       "protocol fault -> %s", sfg1_job_status_str(st));
	}
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_STATE) == 0, "protocol faults must not ban the context");
	EXPECT(sfg1_run(&d, &NOP1, 1) == 0, "recovered from protocol faults");
	inject_clear();
	sfg1_close(&d);
	sfg1_close(&o);
}

/* ------------------------------------------------------------------------ */
/* hang -> timeout -> engine reset -> strike -> ban                          */
/* ------------------------------------------------------------------------ */
static void t_hang_timeout_ban(void)
{
	struct sfg1_dev d, o, n;
	struct drm_sfg1_get_stats s;
	uint64_t id, id2, r0;
	uint32_t st;
	int64_t t0;

	if (open_ctx(&d) || open_ctx(&o))
		return;
	inject_clear();
	r0 = engine_resets(&d);

	for (int i = 0; i < 3; i++) {
		dbg_set("hang_after", 0);
		t0 = sfg1_now_ns();
		NEED(!sfg1_submit(&d, &NOP1, 1, &id), "submit hang %d", i);
		if (i == 0) {
			/* an innocent job queued behind the hung one must be cancelled, not replayed */
			NEED(!sfg1_submit(&o, &NOP1, 1, &id2), "submit innocent");
		}
		EXPECT(sfg1_wait(&d, id, 10000, &st, NULL) == 0, "wait %d", i);
		EXPECT(st == DRM_SFG1_JOB_TIMEOUT, "hang %d -> %s", i, sfg1_job_status_str(st));
		EXPECT(sfg1_now_ns() - t0 >= 250000000LL, "timeout fired too early (%lld ms)",
		       (long long)((sfg1_now_ns() - t0) / 1000000));
		EXPECT(sfg1_now_ns() - t0 < 3000000000LL, "recovery took too long");
		if (i == 0) {
			EXPECT(sfg1_wait(&o, id2, 10000, &st, NULL) == 0 && st == DRM_SFG1_JOB_CANCELED,
			       "innocent job behind a hang -> %s (want CANCELED)", sfg1_job_status_str(st));
		}
		if (i < 2)
			EXPECT(sfg1_run(&d, &NOP1, 1) == 0, "device recovered after hang %d", i);
	}
	get_stats(&d, &s);
	EXPECT(s.jobs_timeout == 3, "jobs_timeout=%llu", (unsigned long long)s.jobs_timeout);
	EXPECT(s.device_engine_resets >= r0 + 3, "engine resets %llu -> %llu", (unsigned long long)r0,
	       (unsigned long long)s.device_engine_resets);
	EXPECT(s.device_func_resets == 0, "engine reset sufficed, no function reset");

	/* three strikes: the context is banned; everybody else keeps working */
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_STATE) & DRM_SFG1_CTX_BANNED, "banned flag");
	EXPECT_ERR(sfg1_submit(&d, &NOP1, 1, NULL), ECANCELED);
	{ struct sfg1_bo b; EXPECT_ERR(sfg1_bo_create(&d, 4096, &b), ECANCELED); }
	EXPECT(sfg1_run(&o, &NOP1, 1) == 0, "bystander unaffected by the ban");
	EXPECT(!sfg1_open(g_path, &n) && sfg1_run(&n, &NOP1, 1) == 0, "new context works");
	sfg1_close(&n);
	sfg1_close(&d);
	sfg1_close(&o);
}

/* Lost interrupt: the CQE is written but the MSI never arrives. No reset must happen. */
static void t_lost_irq(void)
{
	struct sfg1_dev d;
	uint64_t id, r0;
	uint32_t st;
	int64_t t0;

	if (open_ctx(&d))
		return;
	inject_clear();
	r0 = engine_resets(&d);
	dbg_set("drop_irq", 1);
	t0 = sfg1_now_ns();
	NEED(!sfg1_submit(&d, &NOP1, 1, &id), "submit");
	EXPECT(sfg1_wait(&d, id, 10000, &st, NULL) == 0 && st == DRM_SFG1_JOB_OK,
	       "lost-irq job must still complete OK, got %s", sfg1_job_status_str(st));
	EXPECT(sfg1_now_ns() - t0 >= 200000000LL, "completion should only come from the timeout path");
	EXPECT(engine_resets(&d) == r0, "a lost interrupt must NOT cause a reset");
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_STATE) == 0, "no strike for a lost interrupt");
	t0 = sfg1_now_ns();
	EXPECT(sfg1_run(&d, &NOP1, 1) == 0, "next job completes normally");
	EXPECT(sfg1_now_ns() - t0 < 150000000LL, "and promptly (interrupts work again)");
	sfg1_close(&d);
}

/* Engine reset sticks -> function reset -> every context lost -> windows scrubbed. */
static void t_func_reset(void)
{
	struct sfg1_dev d, o, n;
	struct sfg1_bo bo, chk;
	struct drm_sfg1_get_stats s;
	uint64_t id;
	uint32_t st;
	int nonzero = 0;

	if (open_ctx(&d) || open_ctx(&o))
		return;
	NEED(!sfg1_bo_create(&o, 8192, &bo), "bo");
	memset(bo.map, 0x77, 8192);
	EXPECT(sfg1_run(&o, (struct drm_sfg1_cmd[]){ sfg1_cmd_h2d(&bo, 0, 0, 8192) }, 1) == 0, "bystander data");

	inject_clear();
	dbg_set("reset_mode", 1);		/* ENGINE_RESET never completes */
	dbg_set("hang_after", 0);
	NEED(!sfg1_submit(&d, &NOP1, 1, &id), "submit");
	EXPECT(sfg1_wait(&d, id, 15000, &st, NULL) == 0 && st == DRM_SFG1_JOB_TIMEOUT, "hang -> %s",
	       sfg1_job_status_str(st));
	dbg_set("reset_mode", 0);
	get_stats(&o, &s);
	EXPECT(s.device_func_resets == 1, "function resets=%llu", (unsigned long long)s.device_func_resets);

	/* device memory was lost: EVERY context is invalid, including the innocent bystander */
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_STATE) & DRM_SFG1_CTX_LOST, "guilty ctx lost");
	EXPECT(param_or0(&o, DRM_SFG1_PARAM_CTX_STATE) & DRM_SFG1_CTX_LOST, "bystander ctx lost");
	EXPECT_ERR(sfg1_submit(&o, &NOP1, 1, NULL), ECONNRESET);
	EXPECT_ERR(sfg1_submit(&d, &NOP1, 1, NULL), ECONNRESET);
	sfg1_bo_destroy(&o, &bo);
	sfg1_close(&d);
	sfg1_close(&o);

	/* the mock fills device memory with 0xdd after a function reset (undefined per spec):
	 * a fresh context must still see zeros, proving scrub-before-reuse */
	for (int k = 0; k < 4; k++) {
		if (sfg1_open(g_path, &n))
			break;
		if (!sfg1_bo_create(&n, 8192, &chk)) {
			memset(chk.map, 0xff, 8192);
			EXPECT(sfg1_run(&n, (struct drm_sfg1_cmd[]){ sfg1_cmd_d2h(&chk, 0, 0, 8192) }, 1) == 0, "read window");
			for (int i = 0; i < 8192; i++)
				nonzero += ((uint8_t *)chk.map)[i] != 0;
			sfg1_bo_destroy(&n, &chk);
		}
		sfg1_close(&n);
	}
	EXPECT(nonzero == 0, "windows after function reset leaked %d non-zero bytes", nonzero);
	EXPECT(!sfg1_open(g_path, &n) && sfg1_run(&n, &NOP1, 1) == 0, "device usable after function reset");
	sfg1_close(&n);
}

static int unbind_bind(const char *what)
{
	return write_file(what, "sfg1-mock.0");
}

/* ------------------------------------------------------------------------ */
/* scrub policy: attribution decides whether a slot is condemned             */
/* ------------------------------------------------------------------------ */
/* number of quarantined hardware-context windows, read from this fd's fdinfo */
static long quarantined_windows(struct sfg1_dev *d)
{
	char p[64], buf[1536] = "";
	char *q;
	int fd, n;

	snprintf(p, sizeof(p), "/proc/self/fdinfo/%d", d->fd);
	fd = open(p, O_RDONLY);
	n = fd >= 0 ? (int)read(fd, buf, sizeof(buf) - 1) : -1;
	if (fd >= 0)
		close(fd);
	q = n > 0 ? strstr(buf, "sfg1-quarantined-windows:") : NULL;
	return q ? strtol(q + strlen("sfg1-quarantined-windows:"), NULL, 10) : -1;
}

static void t_scrub_policy(void)
{
	struct sfg1_dev a, b, x, y, probe[4];
	uint64_t id;
	uint32_t st;
	int n = 0, r;

	inject_clear();

	/* 1. the scrub command itself hangs ONCE: one hard failure is not a verdict on the slot */
	if (open_ctx(&a))
		return;
	dbg_set("hang_after", 0);		/* the next command on the device (a's scrub at close) hangs */
	sfg1_close(&a);				/* postclose: scrub TIMEOUT, retried, then succeeds */
	if (open_ctx(&b))
		return;
	EXPECT(quarantined_windows(&b) == 0, "a single failed scrub must not quarantine (got %ld)",
	       quarantined_windows(&b));
	EXPECT(sfg1_run(&b, &NOP1, 1) == 0, "device healthy after a retried scrub");
	sfg1_close(&b);

	/* 2. the scrub is caught in SOMEONE ELSE'S hang: transient, must not quarantine */
	if (open_ctx(&x) || open_ctx(&y))
		return;
	dbg_set("hang_after", 0);
	NEED(!sfg1_submit(&y, &NOP1, 1, &id), "submit hanging job");	/* the guilty one */
	sfg1_close(&x);				/* x's scrub queues behind y's hung job -> CANCELED -> retry */
	EXPECT(sfg1_wait(&y, id, 10000, &st, NULL) == 0 && st == DRM_SFG1_JOB_TIMEOUT, "y's job -> %s",
	       sfg1_job_status_str(st));
	EXPECT(quarantined_windows(&y) == 0, "a scrub cancelled by another context's hang must not quarantine (got %ld)",
	       quarantined_windows(&y));
	sfg1_close(&y);

	/*
	 * 3. the scrub command PERSISTENTLY fails: the window cannot be confirmed clean. It is
	 *    withheld for a cooldown, its old contents NEVER reach a new owner, and the capacity
	 *    comes back afterwards (rescrubbed first).
	 */
	{
		struct sfg1_bo sec, chk;
		uint32_t a_slot;
		int found = 0, nonzero = 0;

		if (open_ctx(&a))
			return;
		a_slot = a.ctx_id;
		NEED(!sfg1_bo_create(&a, 4096, &sec), "bo");
		memset(sec.map, 0xC3, 4096);
		EXPECT(sfg1_run(&a, (struct drm_sfg1_cmd[]){ sfg1_cmd_h2d(&sec, 0, 0, 4096) }, 1) == 0,
		       "plant a secret in the window");
		sfg1_bo_destroy(&a, &sec);
		dbg_set("scrub_fail", 1);
		sfg1_close(&a);			/* two hard failures -> cooldown; the secret is still there */
		dbg_set("scrub_fail", 0);

		if (open_ctx(&b))
			return;
		EXPECT(quarantined_windows(&b) == 1, "persistent scrub failure must withhold exactly one slot (got %ld)",
		       quarantined_windows(&b));
		probe[n++] = b;
		while (n < 4 && !(r = sfg1_open(g_path, &probe[n]))) {
			EXPECT(probe[n].ctx_id != a_slot, "the withheld window was handed out during its cooldown");
			n++;
		}
		EXPECT(n == 3 && r == -EBUSY, "withheld slot must not be reused: opened %d, last r=%d (%s)", n, r,
		       r ? strerror(-r) : "ok");
		for (int i = 0; i < n; i++)
			sfg1_close(&probe[i]);

		/* after the cooldown (quarantine_ms=2500) the slot is back, and it is rescrubbed first */
		usleep(2800000);
		n = 0;
		while (n < 4 && !(r = sfg1_open(g_path, &probe[n])))
			n++;
		EXPECT(n == 4, "capacity must return after the cooldown: opened %d (r=%d)", n, r);
		EXPECT(n < 1 || quarantined_windows(&probe[0]) == 0, "cooldown expired");
		for (int i = 0; i < n; i++) {
			if (probe[i].ctx_id != a_slot)
				continue;
			found = 1;
			NEED(!sfg1_bo_create(&probe[i], 4096, &chk), "bo");
			memset(chk.map, 0xff, 4096);
			EXPECT(sfg1_run(&probe[i], (struct drm_sfg1_cmd[]){ sfg1_cmd_d2h(&chk, 0, 0, 4096) }, 1) == 0,
			       "read the previously failed window");
			for (int k = 0; k < 4096; k++)
				nonzero += ((uint8_t *)chk.map)[k] != 0;
			sfg1_bo_destroy(&probe[i], &chk);
		}
		EXPECT(found, "never got the withheld slot back");
		EXPECT(nonzero == 0, "a window whose scrub had failed leaked %d bytes of the previous owner's data",
		       nonzero);
		for (int i = 0; i < n; i++)
			sfg1_close(&probe[i]);
	}
	inject_clear();
}

/* Both resets stick -> device DEAD -> -ENODEV everywhere -> revived by unbind/bind. */
static void t_dead_and_rebind(void)
{
	struct sfg1_dev d, n;
	struct sfg1_bo bo;
	uint64_t id;
	uint32_t st;

	if (open_ctx(&d))
		return;
	inject_clear();
	dbg_set("reset_mode", 2);
	dbg_set("hang_after", 0);
	NEED(!sfg1_submit(&d, &NOP1, 1, &id), "submit");
	EXPECT(sfg1_wait(&d, id, 15000, &st, NULL) == 0 && st == DRM_SFG1_JOB_TIMEOUT, "guilty job -> %s",
	       sfg1_job_status_str(st));
	EXPECT_ERR(sfg1_submit(&d, &NOP1, 1, NULL), ENODEV);
	EXPECT_ERR(sfg1_bo_create(&d, 4096, &bo), ENODEV);
	EXPECT(param_or0(&d, DRM_SFG1_PARAM_CTX_STATE) & DRM_SFG1_CTX_DEVICE_GONE, "state reports device gone");
	EXPECT_ERR(sfg1_open(g_path, &n), ENODEV);

	/* an administrator can recover by rebinding; the old fd stays harmless */
	EXPECT(unbind_bind("/sys/bus/platform/drivers/sfg1-mock/unbind") == 0, "unbind");
	EXPECT(node_gone(), "device node must disappear on unbind");
	EXPECT_ERR(sfg1_submit(&d, &NOP1, 1, NULL), ENODEV);
	EXPECT(unbind_bind("/sys/bus/platform/drivers/sfg1-mock/bind") == 0, "bind");
	EXPECT(wait_for_node(3000) == 0, "node back");
	sfg1_close(&d);
	EXPECT(!sfg1_open(g_path, &n) && sfg1_run(&n, &NOP1, 1) == 0, "fresh device works after rebind");
	sfg1_close(&n);
}

/* ------------------------------------------------------------------------ */
/* safe removal with processes still attached                                */
/* ------------------------------------------------------------------------ */
static sigjmp_buf g_jmp;
static void on_sigbus(int sig)
{
	(void)sig;
	siglongjmp(g_jmp, 1);
}

struct waiter {
	struct sfg1_dev *d;
	uint64_t id;
	int r;
	uint32_t st;
};

static void *waiter_fn(void *p)
{
	struct waiter *w = p;

	w->r = sfg1_wait(w->d, w->id, 10000, &w->st, NULL);
	return NULL;
}

static void t_removal_with_open_fds(void)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	struct drm_sfg1_cmd slow[MAXCMDS];
	struct drm_gem_close gc;
	struct waiter w;
	pthread_t th;
	struct sigaction sa = { .sa_handler = on_sigbus }, old;
	volatile uint8_t sink;
	uint64_t id;

	if (open_ctx(&d))
		return;
	inject_clear();
	NEED(!sfg1_bo_create(&d, 8192, &bo), "bo");
	((uint8_t *)bo.map)[0] = 0x42;
	for (unsigned i = 0; i < MAXCMDS; i++)
		slow[i] = NOP1;
	NEED(!sfg1_submit(&d, slow, MAXCMDS, &id), "submit slow job");
	w = (struct waiter){ .d = &d, .id = id, .r = 12345 };
	NEED(!pthread_create(&th, NULL, waiter_fn, &w), "thread");
	usleep(3000);

	/* hot-unplug while a job is in flight and a thread is blocked in WAIT_JOB */
	EXPECT(unbind_bind("/sys/bus/platform/drivers/sfg1-mock/unbind") == 0, "unbind");
	pthread_join(th, NULL);
	EXPECT(w.r == 0 && (w.st == DRM_SFG1_JOB_OK || w.st == DRM_SFG1_JOB_CANCELED),
	       "blocked waiter must be released with OK/CANCELED, got r=%d st=%u", w.r, w.st);
	EXPECT(node_gone(), "node removed");

	EXPECT_ERR(sfg1_submit(&d, &NOP1, 1, NULL), ENODEV);
	{ struct sfg1_bo b2; EXPECT_ERR(sfg1_bo_create(&d, 4096, &b2), ENODEV); }
	{ uint64_t v; EXPECT_ERR(sfg1_param(&d, DRM_SFG1_PARAM_CTX_ID, &v), ENODEV); }
	gc.handle = bo.handle;
	gc.pad = 0;
	EXPECT_ERR(sfg1_ioctl(d.fd, DRM_IOCTL_GEM_CLOSE, &gc), ENODEV);

	/* CPU mappings were revoked: touching them must fault, never read freed DMA memory */
	sigaction(SIGBUS, &sa, &old);
	if (!sigsetjmp(g_jmp, 1)) {
		sink = ((volatile uint8_t *)bo.map)[0];
		(void)sink;
		EXPECT(0, "revoked mapping was still readable");
	} else {
		g_pass++;	/* SIGBUS as intended */
	}
	sigaction(SIGBUS, &old, NULL);

	munmap(bo.map, bo.size);
	close(d.fd);		/* close() on a removed device must not touch hardware */
	EXPECT(unbind_bind("/sys/bus/platform/drivers/sfg1-mock/bind") == 0, "bind");
	EXPECT(wait_for_node(3000) == 0, "node back");
	EXPECT(!sfg1_open(g_path, &d) && sfg1_run(&d, &NOP1, 1) == 0, "new device instance works");
	sfg1_close(&d);
}

/* ------------------------------------------------------------------------ */
/* allocation-failure injection: every error path of open/BO/submit          */
/* ------------------------------------------------------------------------ */
static int op_open_close(void *arg)
{
	(void)arg;
	struct sfg1_dev d;
	int r = sfg1_open(g_path, &d);

	if (!r)
		sfg1_close(&d);
	return r;
}

static int op_bo(void *arg)
{
	struct sfg1_dev *d = arg;
	struct sfg1_bo bo = {};
	int r = sfg1_bo_create(d, 3 * 4096, &bo);

	if (r) {
		if (bo.handle)
			sfg1_bo_destroy(d, &bo);
		return r;
	}
	sfg1_bo_destroy(d, &bo);
	return 0;
}

static int op_submit(void *arg)
{
	struct sfg1_dev *d = arg;
	struct sfg1_bo *bo = (struct sfg1_bo *)((char *)d + sizeof(*d));
	struct drm_sfg1_cmd c[3] = { sfg1_cmd_h2d(bo, 0, 0, 64), NOP1, sfg1_cmd_d2h(bo, 64, 0, 64) };
	uint64_t id;
	uint32_t st;
	int r = sfg1_submit(d, c, 3, &id);

	if (r)
		return r;
	r = sfg1_wait(d, id, 5000, &st, NULL);
	return r ? r : (st ? -EIO : 0);
}

struct nth_ctx {
	struct sfg1_dev d;
	struct sfg1_bo bo;
};

static void inject_loop(const char *name, int (*op)(void *), void *arg, struct sfg1_dev *chk)
{
	char path[96], buf[16];
	int tid = (int)syscall(SYS_gettid), n, fired = 0, errs = 0;
	struct drm_sfg1_get_stats s;
	uint64_t cnt0 = 0, bytes0 = 0;

	snprintf(path, sizeof(path), "/proc/self/task/%d/fail-nth", tid);
	get_stats(chk, &s);
	cnt0 = s.bo_count;
	bytes0 = s.bo_bytes;

	for (n = 1; n <= 400; n++) {
		int fd, left, r;

		snprintf(buf, sizeof(buf), "%d", n);
		if (write_file(path, buf)) {
			EXPECT(0, "%s: cannot arm fail-nth (%s)", name, strerror(errno));
			return;
		}
		r = op(arg);
		fd = open(path, O_RDWR);
		left = -1;
		if (fd >= 0) {
			memset(buf, 0, sizeof(buf));
			if (read(fd, buf, sizeof(buf) - 1) > 0)
				left = atoi(buf);
			IGNORE(write(fd, "0", 1));
			close(fd);
		}
		if (left != 0) {
			EXPECT(r == 0 || name[0] == 's', "%s: un-failed run returned %d", name, r);
			break;			/* fewer than n allocation points: done */
		}
		fired++;
		if (r)
			errs++;
		/* after any (injected) failure the accounting must be exactly as before */
		get_stats(chk, &s);
		EXPECT(s.bo_count == cnt0 && s.bo_bytes == bytes0,
		       "%s: failure #%d leaked quota (count %llu->%llu bytes %llu->%llu)", name, n,
		       (unsigned long long)cnt0, (unsigned long long)s.bo_count,
		       (unsigned long long)bytes0, (unsigned long long)s.bo_bytes);
	}
	printf("  %s: %d injection points exercised (%d surfaced as errors)\n", name, fired, errs);
	EXPECT(fired >= 3, "%s: only %d injectable allocation points found", name, fired);
}

static void t_alloc_failures(void)
{
	static struct nth_ctx c;
	struct sfg1_dev other;
	struct sfg1_dev *dummy = &c.d;

	if (access("/sys/kernel/debug/failslab/ignore-gfp-wait", W_OK)) {
		printf("  SKIP: fault injection not available\n");
		return;
	}
	write_file("/sys/kernel/debug/failslab/verbose", "0");
	write_file("/sys/kernel/debug/fail_page_alloc/verbose", "0");
	write_file("/sys/kernel/debug/failslab/ignore-gfp-wait", "0");
	write_file("/sys/kernel/debug/failslab/times", "-1");
	write_file("/sys/kernel/debug/fail_page_alloc/ignore-gfp-wait", "0");
	write_file("/sys/kernel/debug/fail_page_alloc/times", "-1");
	write_file("/sys/kernel/debug/fail_page_alloc/min-order", "0");

	if (open_ctx(&c.d))
		return;
	NEED(!sfg1_bo_create(&c.d, 4096, &c.bo), "bo");
	(void)dummy;
	NEED(!sfg1_open(g_path, &other), "second ctx");

	inject_loop("open", op_open_close, NULL, &other);
	inject_loop("bo_create", op_bo, &c.d, &other);
	/* the submit loop checks the persistent ctx's accounting through itself */
	inject_loop("submit", op_submit, &c.d, &c.d);

	/* after thousands of forced failures everything must still work */
	EXPECT(op_submit(&c.d) == 0, "device healthy after allocation-failure injection");
	sfg1_bo_destroy(&c.d, &c.bo);
	sfg1_close(&c.d);
	sfg1_close(&other);
}

/* ------------------------------------------------------------------------ */
/* stress                                                                    */
/* ------------------------------------------------------------------------ */
static int stress_child(int seconds, int chaos)
{
	struct sfg1_dev d;
	struct sfg1_bo bo;
	int64_t end = sfg1_now_ns() + seconds * 1000000000LL;
	int bad = 0, iters = 0, reopened = 0;

	rnd_state ^= (uint32_t)getpid() * 2654435761u;
	if (sfg1_open(g_path, &d) || sfg1_bo_create(&d, 4096, &bo))
		return 10;
	while (sfg1_now_ns() < end) {
		uint32_t words = 1 + rnd() % 120, op = rnd() % 8;
		uint32_t *w = bo.map;
		int r;

		for (uint32_t i = 0; i < 2 * words; i++)
			w[i] = rnd();
		memset((uint8_t *)bo.map + 8 * words, 0xee, 1024);
		r = vec_job(&d, &bo, op, words);
		iters++;
		if (r == 0) {
			uint32_t *o = (uint32_t *)((uint8_t *)bo.map + 8 * words);
			int wrong = 0;

			if (op == DRM_SFG1_VEC_DOT8) {
				int32_t acc = 0;

				for (uint32_t i = 0; i < words; i++)
					for (int k = 0; k < 4; k++)
						acc += (int8_t)(w[i] >> (8 * k)) *
						       (int8_t)(w[words + i] >> (8 * k));
				wrong = o[0] != (uint32_t)acc;
			} else {
				for (uint32_t i = 0; i < words; i++)
					wrong += o[i] != ref_vec_word(op, w[i], w[words + i]);
			}
			if (wrong) {
				printf("  stress: %d wrong results in an OK job\n", wrong);
				bad++;
			}
		} else if (!chaos) {
			printf("  stress: job failed without injection: %d\n", r);
			bad++;
			if (bad > 5)
				break;
		} else if (r == -ECANCELED || r == -ECONNRESET || r == -ENODEV) {
			/* banned / lost: a real client reopens (ex5) */
			sfg1_bo_destroy(&d, &bo);
			sfg1_close(&d);
			if (sfg1_open(g_path, &d) || sfg1_bo_create(&d, 4096, &bo)) {
				usleep(50000);
				if (sfg1_open(g_path, &d) || sfg1_bo_create(&d, 4096, &bo))
					return bad ? 1 : 0;
			}
			reopened++;
		} else if (r > -1000 && r != -EBUSY) {
			printf("  stress: unexpected errno %d (%s)\n", r, strerror(-r));
			bad++;
		}
		if ((rnd() & 15) == 0) {		/* hostile garbage mixed in */
			struct drm_sfg1_cmd junk = { .op = rnd() % 9, .exec_op = rnd() % 12,
						     .bo_handle = bo.handle, .len = rnd() % 100,
						     .dev_a = (uint64_t)rnd() << (rnd() % 32), .dev_b = rnd(),
						     .dev_c = rnd(), .bo_offset = rnd() % 5000 };
			uint64_t id;

			if (junk.op == 6)
				junk.op = 7;	/* never SCRUB, rejected anyway */
			if (!sfg1_submit(&d, &junk, 1, &id)) {	/* valid by luck: reap it */
				uint32_t st;

				sfg1_wait(&d, id, 5000, &st, NULL);
			}
		}
	}
	printf("  stress child %d: %d iterations, %d reopen(s)%s\n", (int)getpid(), iters, reopened,
	       bad ? " BAD" : "");
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
	return bad ? 1 : 0;
}

static void run_stress(int seconds, int chaos)
{
	pid_t pids[3];
	long v0 = dbg_get("dma_violations");
	int64_t end = sfg1_now_ns() + (int64_t)seconds * 1000000000LL;

	inject_clear();
	for (int i = 0; i < 3; i++) {
		pids[i] = fork();
		if (pids[i] == 0)
			_exit(stress_child(seconds, chaos));
	}
	while (chaos && sfg1_now_ns() < end - 500000000LL) {
		usleep(60000 + rnd() % 80000);
		switch (rnd() % 5) {
		case 0: dbg_set("drop_irq", 1 + rnd() % 2); break;
		case 1: dbg_set("hang_after", rnd() % 6); break;
		case 2: dbg_set("fail_status", 1 + rnd() % 7); dbg_set("fail_after", rnd() % 6); break;
		case 3: dbg_set("corrupt_cqe", 1); break;
		default: break;
		}
	}
	for (int i = 0; i < 3; i++)
		EXPECT(child_result(pids[i]) == 0, "stress child %d failed", i);
	inject_clear();
	usleep(1200000);			/* let any recovery in flight finish */
	{
		struct sfg1_dev d;
		int r = -1;

		for (int t = 0; t < 8 && r; t++) {
			if (!sfg1_open(g_path, &d)) {
				r = sfg1_run(&d, &NOP1, 1);
				sfg1_close(&d);
			}
			if (r)
				usleep(300000);
		}
		EXPECT(r == 0, "device must be usable after stress (last r=%d)", r);
	}
	EXPECT(dbg_get("dma_violations") == v0, "stress produced isolation violations");
	if (chaos) {
		struct sfg1_dev d, all[4];
		long q = -1;
		int opened = 0;

		/* a failed scrub may withhold a window for a cooldown, never permanently */
		for (int t = 0; t < 70; t++) {
			if (!sfg1_open(g_path, &d)) {
				q = quarantined_windows(&d);
				sfg1_close(&d);
				if (q == 0)
					break;
			}
			usleep(100000);
		}
		EXPECT(q == 0, "context windows still withheld long after the chaos ended (%ld)", q);
		while (opened < 4 && !sfg1_open(g_path, &all[opened]))
			opened++;
		EXPECT(opened == 4, "all 4 hardware contexts usable after chaos: opened %d", opened);
		for (int i = 0; i < opened; i++)
			sfg1_close(&all[i]);
	}
}

static void t_stress_clean(void) { run_stress(4, 0); }
static void t_stress_chaos(void) { run_stress(8, 1); }

/* ------------------------------------------------------------------------ */
/* kmemleak                                                                  */
/* ------------------------------------------------------------------------ */
/*
 * kmemleak, two phases:
 *   1. BEFORE unload (module symbols resolvable): exactly the one deliberate leak
 *      (mock leak_selftest) must be reported => the detector is live; and nothing
 *      driver-related besides it.
 *   2. AFTER unload: no NEW reports at all.
 */
static int kmemleak_scan(char *buf, size_t sz)
{
	int fd, n;

	if (access("/sys/kernel/debug/kmemleak", W_OK))
		return -1;
	sleep(6);			/* kmemleak ignores objects younger than 5 s */
	write_file("/sys/kernel/debug/kmemleak", "scan");
	sleep(1);
	write_file("/sys/kernel/debug/kmemleak", "scan");
	fd = open("/sys/kernel/debug/kmemleak", O_RDONLY);
	n = fd >= 0 ? (int)read(fd, buf, sz - 1) : 0;
	if (fd >= 0)
		close(fd);
	buf[n > 0 ? n : 0] = 0;
	return 0;
}

static int kmemleak_count(char *buf, int *control, int *related)
{
	char *p;
	int total = 0;

	*control = *related = 0;
	for (p = buf; (p = strstr(p, "unreferenced object")); p += 10) {
		char *e = strstr(p + 10, "unreferenced object");
		char save = e ? *e : 0;

		total++;
		if (e)
			*e = 0;
		if (strstr(p, "leak_selftest")) {
			(*control)++;
		} else if (strstr(p, "sfg1") || strstr(p, "drm_sched") || strstr(p, "drm_gem") ||
			   strstr(p, "dma_fence") || strstr(p, "drm_file") || strstr(p, "drm_dev")) {
			(*related)++;
			printf("  LEAK (driver-related):\n%.900s\n", p);
		}
		if (e)
			*e = save;
	}
	return total;
}

static char g_leakbuf[1 << 17];

static void check_kmemleak_before_unload(void)
{
	int total, control, related;

	g_test = "kmemleak_before_unload";
	printf("RUN  kmemleak_before_unload\n");
	if (kmemleak_scan(g_leakbuf, sizeof(g_leakbuf))) {
		printf("  SKIP: kmemleak not available\n");
		return;
	}
	total = kmemleak_count(g_leakbuf, &control, &related);
	printf("  kmemleak: %d report(s): %d deliberate control, %d other driver-related\n", total,
	       control, related);
	EXPECT(control == 1, "kmemleak did not report the deliberate leak (control=%d): detector not live", control);
	EXPECT(related == 0, "kmemleak found %d driver-related leaks", related);
	printf("%s kmemleak_before_unload\n", control == 1 && !related ? "PASS" : "FAIL");
	/* reading lists ALL current leaks: forget the deliberate one so phase 2 sees only new ones */
	write_file("/sys/kernel/debug/kmemleak", "clear");
}

static void check_kmemleak_after_unload(void)
{
	int total, control, related;

	g_test = "kmemleak_after_unload";
	printf("RUN  kmemleak_after_unload\n");
	if (kmemleak_scan(g_leakbuf, sizeof(g_leakbuf))) {
		printf("  SKIP: kmemleak not available\n");
		return;
	}
	total = kmemleak_count(g_leakbuf, &control, &related);
	printf("  kmemleak after unload: %d new report(s)\n", total);
	if (total)
		printf("%.1500s\n", g_leakbuf);
	EXPECT(total == 0, "kmemleak reported %d new leak(s) after unload", total);
	printf("%s kmemleak_after_unload\n", total ? "FAIL" : "PASS");
}

/* ------------------------------------------------------------------------ */
/* main                                                                      */
/* ------------------------------------------------------------------------ */
#define RUN(fn)                                                                          \
	do {                                                                             \
		int _f0 = g_fail;                                                        \
		g_test = #fn;                                                            \
		printf("RUN  %s\n", #fn);                                                \
		fn();                                                                    \
		printf("%s %s\n", g_fail == _f0 ? "PASS" : "FAIL", #fn);                 \
	} while (0)

static void finish(void)
{
	printf("SFG1 TEST RESULT: %s (checks passed=%d failed=%d)\n", g_fail ? "FAIL" : "PASS",
	       g_pass, g_fail);
	fflush(stdout);
	sync();
	reboot(LINUX_REBOOT_CMD_RESTART);	/* qemu -no-reboot exits */
	for (;;)
		sleep(1);
}

int main(void)
{
	struct sfg1_dev held;
	int r;

	setvbuf(stdout, NULL, _IOLBF, 0);
	mkdir("/proc", 0555); mkdir("/sys", 0555); mkdir("/dev", 0755);
	mount("proc", "/proc", "proc", 0, NULL);
	mount("sysfs", "/sys", "sysfs", 0, NULL);
	mount("devtmpfs", "/dev", "devtmpfs", 0, NULL);
	mount("debugfs", "/sys/kernel/debug", "debugfs", 0, NULL);
	NOP1 = sfg1_cmd_nop();

	printf("SFG1 TEST START\n");
	r = load_module("/gpu-sched.ko", "");
	if (r && r != -EEXIST) {
		printf("cannot load gpu-sched.ko: %s\n", strerror(-r));
		g_fail++;
		finish();
	}
	r = load_module("/sfg1.ko", MOD_PARAMS);
	if (r) {
		printf("cannot load sfg1.ko: %s\n", strerror(-r));
		g_fail++;
		finish();
	}
	if (wait_for_node(5000)) {
		printf("no /dev/accel node appeared\n");
		g_fail++;
		finish();
	}
	inject_clear();
	dbg_set("leak_selftest", 1);		/* kmemleak positive control (checked before unload) */

	RUN(t_discovery);
	RUN(t_bo_basic);
	RUN(t_bo_zero_on_reuse);
	RUN(t_dma_roundtrip);
	RUN(t_vec_ops);
	RUN(t_ten);
	RUN(t_ordering);
	RUN(t_wait_semantics);
	RUN(t_validation);
	RUN(t_quota);
	RUN(t_oracle_selftest);
	RUN(t_isolation);
	RUN(t_unprivileged);
	RUN(t_stats_fdinfo);
	RUN(t_examples);
	RUN(t_stress_clean);
	RUN(t_error_cqe);
	RUN(t_hang_timeout_ban);
	RUN(t_lost_irq);
	RUN(t_func_reset);
	RUN(t_scrub_policy);
	RUN(t_dead_and_rebind);
	RUN(t_stress_chaos);
	RUN(t_alloc_failures);
	RUN(t_removal_with_open_fds);

	check_kmemleak_before_unload();

	/* module unload: refused while a file is open, clean afterwards */
	g_test = "module_unload";
	{
		int f0 = g_fail;

		printf("RUN  module_unload\n");
		if (wait_for_node(2000) == 0 && !sfg1_open(g_path, &held)) {
			/* O_NONBLOCK delete_module on a busy module returns EWOULDBLOCK: the point is
			 * that the unload is REFUSED while a file is open (drm_open holds a module ref) */
			r = unload_module("sfg1");
			EXPECT(r == -EWOULDBLOCK, "rmmod with an open fd must be refused, got %d (%s)", r,
			       r ? strerror(-r) : "unloaded!");
			sfg1_close(&held);
		}
		usleep(300000);
		r = unload_module("sfg1");
		EXPECT(r == 0, "rmmod sfg1 -> %s", strerror(-r));
		r = unload_module("gpu_sched");
		EXPECT(r == 0, "rmmod gpu_sched -> %s", strerror(-r));
		EXPECT(node_gone(), "no accel node after unload");
		printf("%s module_unload\n", g_fail == f0 ? "PASS" : "FAIL");
	}

	check_kmemleak_after_unload();
	finish();
	return 0;
}
