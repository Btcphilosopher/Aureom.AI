#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-only
# Build the Linux 6.18 TEST kernel used by tests/run-qemu.sh.
#
#   tests/build-test-kernel.sh <linux-6.18-source-tree> <build-dir>
#
# NOTE: this INSTALLS the driver into <source-tree>/drivers/accel/sfg1 (see
# tools/install-into-kernel-tree.sh). Use a scratch checkout, not your working tree.
# Needs: gcc, make, flex, bison, bc, libelf-dev, libssl-dev, pahole (for BTF is not required).
set -euo pipefail
KSRC=$(readlink -f "${1:?usage: $0 <linux-6.18-tree> <build-dir>}")
KBUILD=$(mkdir -p "${2:?}" && readlink -f "$2")
PKG=$(cd "$(dirname "$0")/.." && pwd)

"$PKG/tools/install-into-kernel-tree.sh" "$KSRC"
cd "$KSRC"
make O="$KBUILD" ARCH=x86_64 tinyconfig
./scripts/kconfig/merge_config.sh -m -O "$KBUILD" "$KBUILD/.config" "$PKG/tests/kernel-test.config"
make O="$KBUILD" ARCH=x86_64 olddefconfig
for sym in KASAN PROVE_LOCKING DEBUG_KMEMLEAK FAILSLAB DRM_ACCEL_SFG1 DRM_ACCEL_SFG1_MOCK; do
	grep -q "^CONFIG_$sym=" "$KBUILD/.config" || { echo "config symbol $sym did not take effect" >&2; exit 1; }
done
make O="$KBUILD" ARCH=x86_64 -j"$(nproc)" bzImage modules
echo "test kernel ready: $KBUILD/arch/x86/boot/bzImage"
