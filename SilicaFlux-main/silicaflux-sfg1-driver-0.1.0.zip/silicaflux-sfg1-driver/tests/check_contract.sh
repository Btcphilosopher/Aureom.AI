#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
# Fail if any constant shared by kernel/sfg1_hw.h and rtl/sfg1_pkg.sv differs.
set -eu
PKG=$(cd "$(dirname "$0")/.." && pwd)
exec python3 -I - "$PKG/kernel/sfg1_hw.h" "$PKG/rtl/sfg1_pkg.sv" <<'PY'
import re, sys
h = open(sys.argv[1]).read()
v = open(sys.argv[2]).read()

def num(s):
    s = s.strip().rstrip('uU')
    m = re.match(r"(\d+)'[hHdD]([0-9a-fA-F_]+)$", s)
    if m:
        return int(m.group(2).replace('_', ''), 16 if s[len(m.group(1))+1] in 'hH' else 10)
    return int(s, 0)

c = {}
for m in re.finditer(r'#define\s+(SFG1_\w+)\s+(0x[0-9a-fA-F]+|\d+)u?\b', h):
    c[m.group(1)] = int(m.group(2), 0)
for m in re.finditer(r'#define\s+(SFG1_\w+)\s+BIT\((\d+)\)', h):
    c[m.group(1)] = int(m.group(2))          # bit position (SV side stores positions)
sv = {}
for m in re.finditer(r'localparam\s+(?:logic\s*\[[^\]]+\]|int)\s+(SFG1_\w+)\s*=\s*([^;]+);', v):
    sv[m.group(1)] = num(m.group(2))

# C side stores BIT() as position, but plain hex defines as value; SV bit params are positions.
shared = sorted(set(c) & set(sv))
bad = [(k, c[k], sv[k]) for k in shared if c[k] != sv[k]]
print(f"{len(shared)} shared constants compared")
for k, a, b in bad:
    print(f"MISMATCH {k}: C={a:#x} SV={b:#x}")
need = ["SFG1_REG_ID", "SFG1_REG_SQ_TAIL", "SFG1_REG_CQ_HEAD", "SFG1_OP_SCRUB", "SFG1_ST_BAD_ARGS",
        "SFG1_IRQ_FATAL", "SFG1_CHIP_ID", "SFG1_RESET_MAGIC"]
missing = [k for k in need if k not in shared]
if missing:
    print("expected shared constants missing:", missing)
sys.exit(1 if bad or missing else 0)
PY
