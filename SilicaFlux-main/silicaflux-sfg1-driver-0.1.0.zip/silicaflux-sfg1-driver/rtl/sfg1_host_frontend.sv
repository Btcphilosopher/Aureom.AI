// SPDX-License-Identifier: GPL-2.0-only
// -----------------------------------------------------------------------------
// SF-G1 host front-end — REFERENCE RTL of the host-visible contract (DRAFT v1.0)
//
// What this is: the block a host driver actually talks to — BAR0 CSR file,
// submission-queue (SQ) fetch, completion-queue (CQ) write-back with a
// phase tag, interrupt-message generation, halt-on-error and the two resets.
// It exists to make the memory-ordering rules in docs/02-hw-interface.md
// *executable*: tb_sfg1_host_frontend.sv checks them against this RTL, and
// kernel/sfg1_ring.c implements the matching host side.
//
// What this is NOT: the SF-G1 compute fabric. DMA / VEC / TEN / SCRUB execution
// and the per-context device-memory windows are behind the `eng_*` interface
// (stubbed in the testbench). Nothing here has been synthesised, timed or
// taped out; there is no claim about area, frequency or physical behaviour.
//
// Ordering guarantees implemented here (hardware rules R3/R6):
//   R3  For every command the device issues four posted writes to the CQ slot
//       in the order  dw0, dw1, dw2, dw3  where dw3 carries {status_phase,cid}
//       and is therefore the LAST thing that makes the entry visible. Only
//       after dw3 has been issued are IRQ_STATUS set and the interrupt message
//       issued. (The testbench models the posted-write channel as in-order,
//       as PCIe requires without Relaxed Ordering.)
//   R6  An interrupt message is issued when (IRQ_STATUS & IRQ_MASK) goes
//       0 -> non-zero, and again whenever a W1C / mask write leaves it
//       non-zero.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfg1_host_frontend
  import sfg1_pkg::*;
#(
  parameter int MAX_CTX      = 8,
  parameter int MAX_QENT     = 1024,
  parameter int WIN_KIB      = 1024,
  parameter int RESET_CYCLES = 6,
  // MUTATION KNOB, verification only. 0 = correct. 1 = write the phase dword FIRST;
  // 2 = publish the interrupt before the CQE is complete. The testbench must FAIL on 1 and 2
  // (tests that the ordering checkers have teeth). Never non-zero in a real build.
  parameter int ORDER_BUG    = 0
) (
  input  logic        clk,
  input  logic        rst_n,

  // BAR0 register interface: writes apply on the clock edge, reads are combinational
  input  logic        csr_wr,
  input  logic [11:0] csr_addr,
  input  logic [31:0] csr_wdata,
  output logic [31:0] csr_rdata,

  // host-memory master: 32-bit read (request, then wait for valid); posted writes
  output logic        mrd_req,
  output logic [63:0] mrd_addr,
  input  logic        mrd_valid,
  input  logic [31:0] mrd_data,
  output logic        mwr_req,
  output logic [63:0] mwr_addr,
  output logic [31:0] mwr_data,

  // one pulse = one interrupt message (a posted write ordered after all earlier mwr_*)
  output logic        irq_msg,

  // execution engine (DMA/VEC/TEN/SCRUB live behind this)
  output logic        eng_start,
  output logic [15:0] eng_opcode,
  output logic [15:0] eng_ctx,
  output logic [15:0] eng_flags,
  output logic [31:0] eng_exec_op,
  output logic [63:0] eng_host_addr,
  output logic [63:0] eng_len,
  output logic [63:0] eng_a,
  output logic [63:0] eng_b,
  output logic [63:0] eng_c,
  input  logic        eng_done,
  input  logic [2:0]  eng_status,
  output logic        eng_abort
);

  typedef enum logic [3:0] {
    S_IDLE, S_RD_REQ, S_RD_WAIT, S_DECODE, S_EXEC, S_WB0, S_WB1, S_WB2, S_WB3, S_COMMIT
  } state_t;
  state_t state;

  // ---- architectural state --------------------------------------------------
  logic        enable, halted, fatal, reset_active;
  logic [7:0]  reset_cnt;
  logic [7:0]  last_err;
  logic [63:0] sq_base, cq_base;
  logic [31:0] sq_n, cq_n;
  logic [15:0] sq_tail, sq_head, cq_head, cq_tail;
  logic        cq_phase;
  logic [2:0]  irq_status, irq_mask;
  logic [31:0] scratch, done_count, err_count, heartbeat;

  // ---- command latch ---------------------------------------------------------
  logic [31:0] ent [0:15];
  logic [3:0]  rd_idx;
  logic [2:0]  status;

  assign eng_opcode    = ent[0][15:0];
  assign eng_ctx       = ent[0][31:16];
  assign eng_flags     = ent[1][31:16];
  assign eng_exec_op   = ent[2];
  assign eng_host_addr = {ent[5], ent[4]};
  assign eng_len       = {ent[7], ent[6]};
  assign eng_a         = {ent[9], ent[8]};
  assign eng_b         = {ent[11], ent[10]};
  assign eng_c         = {ent[13], ent[12]};

  wire [15:0] sq_mask      = 16'(sq_n - 1);
  wire [15:0] cq_mask      = 16'(cq_n - 1);
  wire [15:0] sq_head_next = (sq_head + 16'd1) & sq_mask;
  wire [15:0] cq_tail_next = (cq_tail + 16'd1) & cq_mask;
  wire [15:0] cmd_cid      = ent[1][15:0];
  wire [15:0] cmd_ctx      = ent[0][31:16];
  wire [15:0] cmd_op       = ent[0][15:0];

  function automatic logic queue_cfg_ok(input logic [31:0] s, input logic [31:0] c);
    queue_cfg_ok = (s >= 32'd16) && (s <= MAX_QENT) && ((s & (s - 1)) == 0) &&
                   (c >= s) && (c <= MAX_QENT) && ((c & (c - 1)) == 0);
  endfunction

  // ---- CQE write-back order (rule R3): dw0,dw1,dw2 then dw3 = {status_phase,cid} LAST ----
  function automatic logic [31:0] cqe_dw(input int dw);
    case (dw)
      0:       cqe_dw = 32'd0;                                   // result
      1:       cqe_dw = 32'd0;                                   // reserved
      2:       cqe_dw = {cmd_ctx, sq_head_next};                 // ctx_id | sq_head
      default: cqe_dw = {12'd0, status, cq_phase, cmd_cid};      // status_phase | cid
    endcase
  endfunction
  // k-th write of the sequence -> which dword (mutation 1 puts the phase dword first)
  function automatic int dw_of(input int k);
    dw_of = (ORDER_BUG == 1) ? ((k + 3) % 4) : k;
  endfunction

  // ---- interrupt message logic (rule R6) -------------------------------------
  // irq_set / irq_clr are blocking variables assigned inside the clocked process below; the
  // "next" values MUST therefore also be computed inside that process (after every cause is
  // known). Computing them with continuous wires lags one cycle behind (found by simulation:
  // the device re-issued a message after the host had acknowledged every cause).
  logic [2:0] irq_set, irq_clr, irq_status_n, irq_mask_n;
  logic       pend_next;
  wire        pend_now     = |(irq_status & irq_mask);
  wire        csr_irq_ev   = csr_wr && (csr_addr == SFG1_REG_IRQ_STATUS || csr_addr == SFG1_REG_IRQ_MASK);

  // ---- CSR read mux ------------------------------------------------------------
  always_comb begin
    csr_rdata = 32'h0;
    case (csr_addr)
      SFG1_REG_ID:         csr_rdata = SFG1_CHIP_ID;
      SFG1_REG_HW_VERSION: csr_rdata = 32'h0001_0000;
      SFG1_REG_CAPS:       csr_rdata = (32'd1 << SFG1_CAP_ENGINE_RESET) | (32'd1 << SFG1_CAP_FUNC_RESET) |
                                       (32'd1 << SFG1_CAP_SCRUB) | (32'd1 << SFG1_CAP_VEC) |
                                       (32'd1 << SFG1_CAP_TEN);
      SFG1_REG_LIMITS0:    csr_rdata = {16'(MAX_QENT), 16'(MAX_CTX)};
      SFG1_REG_LIMITS1:    csr_rdata = {16'(WIN_KIB), 8'd0, 8'd64};
      SFG1_REG_DEVMEM_LO:  csr_rdata = 32'(MAX_CTX * WIN_KIB * 1024);
      SFG1_REG_DEVMEM_HI:  csr_rdata = 32'h0;
      SFG1_REG_CTRL:       csr_rdata = {31'd0, enable};
      SFG1_REG_STATUS:     csr_rdata = {16'd0, last_err, 3'd0,
                                        reset_active, fatal, halted, (state != S_IDLE), !reset_active};
      SFG1_REG_IRQ_STATUS: csr_rdata = {29'd0, irq_status};
      SFG1_REG_IRQ_MASK:   csr_rdata = {29'd0, irq_mask};
      SFG1_REG_SQ_BASE_LO: csr_rdata = sq_base[31:0];
      SFG1_REG_SQ_BASE_HI: csr_rdata = sq_base[63:32];
      SFG1_REG_SQ_ENTRIES: csr_rdata = sq_n;
      SFG1_REG_SQ_TAIL:    csr_rdata = {16'd0, sq_tail};
      SFG1_REG_CQ_BASE_LO: csr_rdata = cq_base[31:0];
      SFG1_REG_CQ_BASE_HI: csr_rdata = cq_base[63:32];
      SFG1_REG_CQ_ENTRIES: csr_rdata = cq_n;
      SFG1_REG_CQ_HEAD:    csr_rdata = {16'd0, cq_head};
      SFG1_REG_SQ_HEAD:    csr_rdata = {16'd0, sq_head};
      SFG1_REG_CQ_TAIL:    csr_rdata = {16'd0, cq_tail};
      SFG1_REG_DONE_COUNT: csr_rdata = done_count;
      SFG1_REG_ERR_COUNT:  csr_rdata = err_count;
      SFG1_REG_HEARTBEAT:  csr_rdata = heartbeat;
      SFG1_REG_SCRATCH:    csr_rdata = scratch;
      default:             csr_rdata = 32'h0;
    endcase
  end

  // ---- sequential logic --------------------------------------------------------
  logic do_engine_reset, do_func_reset;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; enable <= 1'b0; halted <= 1'b0; fatal <= 1'b0;
      reset_active <= 1'b0; reset_cnt <= '0; last_err <= '0;
      sq_base <= '0; cq_base <= '0; sq_n <= '0; cq_n <= '0;
      sq_tail <= '0; sq_head <= '0; cq_head <= '0; cq_tail <= '0; cq_phase <= 1'b1;
      irq_status <= '0; irq_mask <= '0; scratch <= '0; done_count <= '0; err_count <= '0;
      heartbeat <= '0; rd_idx <= '0; status <= '0;
      mrd_req <= 1'b0; mwr_req <= 1'b0; mrd_addr <= '0; mwr_addr <= '0; mwr_data <= '0;
      eng_start <= 1'b0; eng_abort <= 1'b0; irq_msg <= 1'b0;
      for (int i = 0; i < 16; i++) ent[i] <= '0;
    end else begin
      mrd_req   <= 1'b0;
      mwr_req   <= 1'b0;
      eng_start <= 1'b0;
      eng_abort <= 1'b0;
      irq_set    = '0;
      irq_clr    = '0;
      do_engine_reset = 1'b0;
      do_func_reset   = 1'b0;
      if (enable) heartbeat <= heartbeat + 32'd1;

      if (reset_active) begin
        if (reset_cnt == 8'd0) reset_active <= 1'b0;
        else reset_cnt <= reset_cnt - 8'd1;
      end

      // ---- command FSM ----
      case (state)
        S_IDLE:
          if (enable && !halted && !fatal && !reset_active && sq_head != sq_tail) begin
            rd_idx <= '0;
            state  <= S_RD_REQ;
          end
        S_RD_REQ: begin
          mrd_req  <= 1'b1;
          mrd_addr <= sq_base + 64'(sq_head) * 64 + 64'(rd_idx) * 4;
          state    <= S_RD_WAIT;
        end
        S_RD_WAIT:
          if (mrd_valid) begin
            ent[rd_idx] <= mrd_data;
            if (rd_idx == 4'd15) state <= S_DECODE;
            else begin rd_idx <= rd_idx + 4'd1; state <= S_RD_REQ; end
          end
        S_DECODE: begin
          if (cmd_ctx >= 16'(MAX_CTX)) begin
            status <= SFG1_ST_BAD_CTX;     state <= S_WB0;
          end else if (ent[3] != 32'd0 || ent[14] != 32'd0 || ent[15] != 32'd0) begin
            status <= SFG1_ST_BAD_ARGS;    state <= S_WB0;     // reserved fields must be zero
          end else if (cmd_op == SFG1_OP_NOP) begin
            status <= SFG1_ST_OK;          state <= S_WB0;
          end else if (cmd_op == SFG1_OP_DMA_H2D || cmd_op == SFG1_OP_VEC || cmd_op == SFG1_OP_TEN ||
                       cmd_op == SFG1_OP_DMA_D2H || cmd_op == SFG1_OP_SCRUB) begin
            eng_start <= 1'b1;             state <= S_EXEC;
          end else begin
            status <= SFG1_ST_BAD_OPCODE;  state <= S_WB0;
          end
        end
        S_EXEC:
          if (eng_done) begin status <= eng_status; state <= S_WB0; end

        // CQE write-back: dw0, dw1, dw2, then dw3 (phase + status) LAST.
        S_WB0:
          if (cq_tail_next == cq_head) begin        // CQ full: protocol violation by the host
            fatal <= 1'b1; irq_set = irq_set | (3'd1 << SFG1_IRQ_FATAL); state <= S_IDLE;
          end else begin
            mwr_req <= 1'b1; mwr_addr <= cq_base + 64'(cq_tail) * 16 + 64'(4 * dw_of(0));
            mwr_data <= cqe_dw(dw_of(0));
            state <= S_WB1;
          end
        S_WB1: begin
          mwr_req <= 1'b1; mwr_addr <= cq_base + 64'(cq_tail) * 16 + 64'(4 * dw_of(1));
          mwr_data <= cqe_dw(dw_of(1));
          state <= S_WB2;
        end
        S_WB2: begin
          mwr_req <= 1'b1; mwr_addr <= cq_base + 64'(cq_tail) * 16 + 64'(4 * dw_of(2));
          mwr_data <= cqe_dw(dw_of(2));
          if (ORDER_BUG == 2) irq_set = irq_set | (3'd1 << SFG1_IRQ_CQ);   // MUTATION: cause published too early
          state <= S_WB3;
        end
        S_WB3: begin
          mwr_req <= 1'b1; mwr_addr <= cq_base + 64'(cq_tail) * 16 + 64'(4 * dw_of(3));
          mwr_data <= cqe_dw(dw_of(3));
          state <= S_COMMIT;
        end
        S_COMMIT: begin
          // the visibility-making write (dw3) was issued last cycle; only now publish the cause
          sq_head    <= sq_head_next;
          cq_tail    <= cq_tail_next;
          if (cq_tail_next == 16'd0) cq_phase <= ~cq_phase;
          done_count <= done_count + 32'd1;
          irq_set    = irq_set | (3'd1 << SFG1_IRQ_CQ);
          if (status != SFG1_ST_OK) begin
            halted     <= 1'b1;
            err_count  <= err_count + 32'd1;
            last_err   <= {5'd0, status};
            irq_set    = irq_set | (3'd1 << SFG1_IRQ_ERROR);
          end
          state <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase

      // ---- CSR writes ----
      if (csr_wr) begin
        case (csr_addr)
          SFG1_REG_CTRL: begin
            if (csr_wdata[SFG1_CTRL_ENGINE_RESET]) do_engine_reset = 1'b1;
            if (csr_wdata[SFG1_CTRL_CLEAR_HALT])   halted <= 1'b0;
            if (!csr_wdata[SFG1_CTRL_ENGINE_RESET]) begin
              if (csr_wdata[SFG1_CTRL_ENABLE] && !enable) begin
                if (queue_cfg_ok(sq_n, cq_n) && !fatal && !reset_active) begin
                  enable <= 1'b1;                      // queue registers sampled on 0 -> 1
                  sq_head <= '0; sq_tail <= '0; cq_head <= '0; cq_tail <= '0; cq_phase <= 1'b1;
                end else begin
                  fatal <= 1'b1; irq_set = irq_set | (3'd1 << SFG1_IRQ_FATAL);
                end
              end else if (!csr_wdata[SFG1_CTRL_ENABLE]) begin
                enable <= 1'b0;
              end
            end
          end
          SFG1_REG_RESET:      if (csr_wdata == SFG1_RESET_MAGIC) do_func_reset = 1'b1;
          SFG1_REG_IRQ_STATUS: irq_clr = csr_wdata[2:0];               // W1C
          SFG1_REG_IRQ_MASK:   irq_mask <= csr_wdata[2:0];
          SFG1_REG_SQ_BASE_LO: if (!enable) sq_base[31:0]  <= csr_wdata;
          SFG1_REG_SQ_BASE_HI: if (!enable) sq_base[63:32] <= csr_wdata;
          SFG1_REG_SQ_ENTRIES: if (!enable) sq_n <= csr_wdata;
          SFG1_REG_CQ_BASE_LO: if (!enable) cq_base[31:0]  <= csr_wdata;
          SFG1_REG_CQ_BASE_HI: if (!enable) cq_base[63:32] <= csr_wdata;
          SFG1_REG_CQ_ENTRIES: if (!enable) cq_n <= csr_wdata;
          SFG1_REG_SQ_TAIL:    if (enable && sq_n != 0) sq_tail <= csr_wdata[15:0] & sq_mask;
          SFG1_REG_CQ_HEAD:    if (cq_n != 0) cq_head <= csr_wdata[15:0] & cq_mask;
          SFG1_REG_SCRATCH:    scratch <= csr_wdata;
          default: ;
        endcase
      end

      // ---- interrupt status / message (rule R6) ----
      irq_status_n = (irq_status & ~irq_clr) | irq_set;
      irq_mask_n   = (csr_wr && csr_addr == SFG1_REG_IRQ_MASK) ? csr_wdata[2:0] : irq_mask;
      pend_next    = |(irq_status_n & irq_mask_n);
      irq_status <= irq_status_n;
      irq_msg    <= pend_next && (!pend_now || csr_irq_ev);

      // ---- resets (override everything above) ----
      if (do_engine_reset || do_func_reset) begin
        reset_active <= 1'b1;
        reset_cnt    <= 8'(RESET_CYCLES);
        enable       <= 1'b0;
        eng_abort    <= 1'b1;
        state        <= S_IDLE;
        mwr_req      <= 1'b0;                 // an aborted command writes NO completion
        sq_head <= '0; sq_tail <= '0; cq_head <= '0; cq_tail <= '0; cq_phase <= 1'b1;
        halted <= 1'b0; last_err <= '0; irq_status <= '0; irq_msg <= 1'b0;
        if (do_func_reset) begin
          fatal <= 1'b0; sq_base <= '0; cq_base <= '0; sq_n <= '0; cq_n <= '0;
          irq_mask <= '0; done_count <= '0; err_count <= '0;
        end
      end
    end
  end
endmodule
