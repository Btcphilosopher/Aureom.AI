// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 host/device contract constants (DRAFT v1.0 proposal).
// Names intentionally match kernel/sfg1_hw.h; tests/check_contract.sh fails if
// any shared constant differs. See docs/02-hw-interface.md.
`timescale 1ns/1ps
package sfg1_pkg;
  localparam logic [31:0] SFG1_CHIP_ID = 32'h53464001;

  // BAR0 register offsets (byte)
  localparam logic [11:0] SFG1_REG_ID         = 12'h000;
  localparam logic [11:0] SFG1_REG_HW_VERSION = 12'h004;
  localparam logic [11:0] SFG1_REG_CAPS       = 12'h008;
  localparam logic [11:0] SFG1_REG_LIMITS0    = 12'h00c;
  localparam logic [11:0] SFG1_REG_LIMITS1    = 12'h010;
  localparam logic [11:0] SFG1_REG_DEVMEM_LO  = 12'h014;
  localparam logic [11:0] SFG1_REG_DEVMEM_HI  = 12'h018;
  localparam logic [11:0] SFG1_REG_CTRL       = 12'h020;
  localparam logic [11:0] SFG1_REG_STATUS     = 12'h024;
  localparam logic [11:0] SFG1_REG_RESET      = 12'h028;
  localparam logic [11:0] SFG1_REG_IRQ_STATUS = 12'h030;
  localparam logic [11:0] SFG1_REG_IRQ_MASK   = 12'h034;
  localparam logic [11:0] SFG1_REG_SQ_BASE_LO = 12'h040;
  localparam logic [11:0] SFG1_REG_SQ_BASE_HI = 12'h044;
  localparam logic [11:0] SFG1_REG_SQ_ENTRIES = 12'h048;
  localparam logic [11:0] SFG1_REG_SQ_TAIL    = 12'h04c;
  localparam logic [11:0] SFG1_REG_CQ_BASE_LO = 12'h050;
  localparam logic [11:0] SFG1_REG_CQ_BASE_HI = 12'h054;
  localparam logic [11:0] SFG1_REG_CQ_ENTRIES = 12'h058;
  localparam logic [11:0] SFG1_REG_CQ_HEAD    = 12'h05c;
  localparam logic [11:0] SFG1_REG_SQ_HEAD    = 12'h060;
  localparam logic [11:0] SFG1_REG_CQ_TAIL    = 12'h064;
  localparam logic [11:0] SFG1_REG_DONE_COUNT = 12'h068;
  localparam logic [11:0] SFG1_REG_ERR_COUNT  = 12'h06c;
  localparam logic [11:0] SFG1_REG_HEARTBEAT  = 12'h070;
  localparam logic [11:0] SFG1_REG_SCRATCH    = 12'h07c;

  localparam logic [31:0] SFG1_RESET_MAGIC = 32'h52455345;

  // CTRL / STATUS / IRQ bit positions
  localparam int SFG1_CTRL_ENABLE       = 0;
  localparam int SFG1_CTRL_ENGINE_RESET = 1;
  localparam int SFG1_CTRL_CLEAR_HALT   = 2;
  localparam int SFG1_STATUS_READY        = 0;
  localparam int SFG1_STATUS_BUSY         = 1;
  localparam int SFG1_STATUS_HALTED       = 2;
  localparam int SFG1_STATUS_FATAL        = 3;
  localparam int SFG1_STATUS_RESET_ACTIVE = 4;
  localparam int SFG1_IRQ_CQ    = 0;
  localparam int SFG1_IRQ_ERROR = 1;
  localparam int SFG1_IRQ_FATAL = 2;

  // capabilities
  localparam int SFG1_CAP_ENGINE_RESET = 0;
  localparam int SFG1_CAP_FUNC_RESET   = 1;
  localparam int SFG1_CAP_SCRUB        = 2;
  localparam int SFG1_CAP_VEC          = 3;
  localparam int SFG1_CAP_TEN          = 4;

  // opcodes
  localparam logic [15:0] SFG1_OP_NOP     = 16'd0;
  localparam logic [15:0] SFG1_OP_DMA_H2D = 16'd1;
  localparam logic [15:0] SFG1_OP_VEC     = 16'd2;
  localparam logic [15:0] SFG1_OP_TEN     = 16'd3;
  localparam logic [15:0] SFG1_OP_DMA_D2H = 16'd5;
  localparam logic [15:0] SFG1_OP_SCRUB   = 16'd6;

  // completion status codes
  localparam logic [2:0] SFG1_ST_OK              = 3'd0;
  localparam logic [2:0] SFG1_ST_BAD_OPCODE      = 3'd1;
  localparam logic [2:0] SFG1_ST_BAD_CTX         = 3'd2;
  localparam logic [2:0] SFG1_ST_ENGINE_DISABLED = 3'd3;
  localparam logic [2:0] SFG1_ST_BOUNDS          = 3'd4;
  localparam logic [2:0] SFG1_ST_FETCH_ERROR     = 3'd5;
  localparam logic [2:0] SFG1_ST_DMA_ERROR       = 3'd6;
  localparam logic [2:0] SFG1_ST_BAD_ARGS        = 3'd7;
endpackage
