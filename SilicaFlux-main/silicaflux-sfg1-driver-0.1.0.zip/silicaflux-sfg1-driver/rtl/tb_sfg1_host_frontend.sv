// SPDX-License-Identifier: GPL-2.0-only
// Self-checking testbench for sfg1_host_frontend.
//
// The "host" half mirrors kernel/sfg1_ring.c: fill SQ entries, ring SQ_TAIL,
// detect completions by the CQE phase tag, read the payload only after the
// phase matched, return credit through CQ_HEAD, acknowledge interrupts with a
// W1C write BEFORE draining. The "link" half models PCIe posted-write
// ordering: device writes and interrupt messages travel through ONE in-order
// channel with random latency (as PCIe guarantees without Relaxed Ordering).
//
// Ordering is checked three independent ways:
//   M1  continuous: whenever a CQE's phase is visible in host memory, its
//       payload is already correct (payload-before-phase, rule R3);
//   M2  at every delivered interrupt message, the CQE it announces is complete;
//   M3  device-side issue order: dw0,dw1,dw2,dw3 then (later) the message.
`timescale 1ns/1ps
module tb_sfg1_host_frontend #(parameter int ORDER_BUG = 0);
  import sfg1_pkg::*;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ---- DUT ------------------------------------------------------------------
  logic        csr_wr = 1'b0;
  logic [11:0] csr_addr = '0;
  logic [31:0] csr_wdata = '0, csr_rdata;
  logic        mrd_req, mrd_valid = 1'b0, mwr_req, irq_msg;
  logic [63:0] mrd_addr, mwr_addr;
  logic [31:0] mrd_data = '0, mwr_data;
  logic        eng_start, eng_done = 1'b0, eng_abort;
  logic [15:0] eng_opcode, eng_ctx, eng_flags;
  logic [31:0] eng_exec_op;
  logic [63:0] eng_host_addr, eng_len, eng_a, eng_b, eng_c;
  logic [2:0]  eng_status = '0;

  sfg1_host_frontend #(.MAX_CTX(8), .MAX_QENT(1024), .WIN_KIB(1024), .RESET_CYCLES(6), .ORDER_BUG(ORDER_BUG)) dut (.*);

  // ---- bookkeeping ------------------------------------------------------------
  bit dbg = 1'b0;
  initial dbg = $test$plusargs("dbg");
  always @(posedge clk) if (dbg) begin
    if (csr_wr) $display("[%0d] CSR WR %03h <= %08h", cyc, csr_addr, csr_wdata);
    if (mwr_req) $display("[%0d]   DEV WR  %05h <= %08h", cyc, mwr_addr[19:0], mwr_data);
    if (irq_msg) $display("[%0d]   DEV IRQ MSG  (status&mask=%0d)", cyc, |(dut.irq_status & dut.irq_mask));
    if (eng_start) $display("[%0d]   ENG START op=%0d", cyc, eng_opcode);
    if (eng_done) $display("[%0d]   ENG DONE st=%0d", cyc, eng_status);
  end
  int checks = 0, errors = 0;
  task automatic check(input bit cond, input string msg);
    checks++;
    if (!cond) begin
      errors++;
      $display("  FAIL @%0d: %s", cyc, msg);
    end
  endtask

  // ---- host memory + in-order posted-write channel ---------------------------------
  localparam logic [63:0] SQ_BASE = 64'h1000;
  localparam logic [63:0] CQ_BASE = 64'h3000;
  logic [15:0] exp_ctx [0:1023];
  logic [31:0] hmem [0:16383];                       // 64 KiB
  initial for (int i = 0; i < 16384; i++) hmem[i] = 32'h0;   // 4-state simulators start with X
  initial for (int i = 0; i < 1024; i++) exp_ctx[i] = 16'h0;

  localparam int PW = 256;
  logic [63:0] pw_addr [0:PW-1];
  logic [31:0] pw_data [0:PW-1];
  bit          pw_msg  [0:PW-1];
  int          pw_due  [0:PW-1];
  int pw_head = 0, pw_tail = 0, pw_last_due = 0;
  int msgs_delivered = 0, msgs_issued = 0;
  int lat_max = 5;

  // M3 state
  int  m3_slot = -1, m3_next_dw = 0;
  int  m3_last_dw3_cycle = -1;
  int  cqe_issue_count = 0;

  function automatic int next_due();
    int d = cyc + 1 + ($urandom % lat_max);
    if (d <= pw_last_due) d = pw_last_due + 1;     // channel is strictly in-order
    return d;
  endfunction

  // forward declaration of host model state used by M1/M2
  int h_sq_n = 16;
  int h_tail = 0, h_cq_head = 0, h_phase = 1;
  int mon_head = 0, mon_phase = 1;                   // M1 monitor's own consumer view
  bit  m1_enabled = 1'b0;

  function automatic bit slot_phase_visible(input int slot, input int ph);
    logic [31:0] dw3 = hmem[(CQ_BASE >> 2) + slot * 4 + 3];
    return dw3[16] == ph[0];
  endfunction

  // device -> link
  always @(posedge clk) begin
    if (mwr_req) begin
      pw_addr[pw_tail % PW] <= mwr_addr; pw_data[pw_tail % PW] <= mwr_data; pw_msg[pw_tail % PW] <= 1'b0;
      pw_due[pw_tail % PW]  <= next_due(); pw_last_due <= next_due(); pw_tail <= pw_tail + 1;
      // M3: dw order inside a CQE slot
      begin
        int off = int'(mwr_addr - CQ_BASE);
        int slot = off / 16, dw = (off % 16) / 4;
        if (dw == 0) begin m3_slot <= slot; m3_next_dw <= 1; end
        else begin
          check(slot == m3_slot && dw == m3_next_dw, $sformatf("M3: CQE write order violated (slot %0d dw %0d, expected slot %0d dw %0d)", slot, dw, m3_slot, m3_next_dw));
          m3_next_dw <= dw + 1;
          if (dw == 3) begin m3_last_dw3_cycle <= cyc; cqe_issue_count <= cqe_issue_count + 1; end
        end
        if (dw == 3 && m3_next_dw != 3) check(1'b0, "M3: phase dword (dw3) was not the last write of its CQE");
      end
    end
    if (irq_msg) begin
      msgs_issued <= msgs_issued + 1;
      pw_addr[(pw_tail + (mwr_req ? 1 : 0)) % PW] <= 64'hFEE0_0000; pw_data[(pw_tail + (mwr_req ? 1 : 0)) % PW] <= 32'h1;
      pw_msg[(pw_tail + (mwr_req ? 1 : 0)) % PW] <= 1'b1;
      pw_due[(pw_tail + (mwr_req ? 1 : 0)) % PW] <= next_due() + (mwr_req ? 1 : 0);
      pw_last_due <= next_due() + (mwr_req ? 1 : 0);
      pw_tail <= pw_tail + (mwr_req ? 2 : 1);
    end
  end

  // link -> host memory (deliver in order, one per cycle)
  int msg_pending_check = 0;
  always @(posedge clk) begin
    if (pw_head != pw_tail && cyc >= pw_due[pw_head % PW]) begin
      if (pw_msg[pw_head % PW]) begin
        msgs_delivered <= msgs_delivered + 1;
        msg_pending_check <= msg_pending_check + 1;     // M2 evaluated by the host task on delivery
      end else begin
        hmem[pw_addr[pw_head % PW][15:2]] <= pw_data[pw_head % PW];
      end
      pw_head <= pw_head + 1;
    end
  end

  // M1: payload-before-phase, checked every cycle
  always @(posedge clk) begin
    if (m1_enabled && slot_phase_visible(mon_head, mon_phase)) begin
      logic [31:0] dw2 = hmem[(CQ_BASE >> 2) + mon_head * 4 + 2];
      logic [31:0] dw3 = hmem[(CQ_BASE >> 2) + mon_head * 4 + 3];
      check(dw3[15:0] == 16'(mon_head), $sformatf("M1: cid=%0d in visible CQE slot %0d", dw3[15:0], mon_head));
      check(dw2[15:0] == 16'((mon_head + 1) % h_sq_n),
            $sformatf("M1: phase visible but payload (sq_head) not yet: slot %0d dw2=%h", mon_head, dw2));
      check(dw2[31:16] == exp_ctx[mon_head], $sformatf("M1: ctx %h in slot %0d, want %h", dw2[31:16], mon_head, exp_ctx[mon_head]));
      mon_head = (mon_head + 1) % h_sq_n;
      if (mon_head == 0) mon_phase = ~mon_phase;
    end
  end

  // device -> host reads (SQ fetch)
  int rd_due = -1;
  logic [63:0] rd_a;
  always @(posedge clk) begin
    mrd_valid <= 1'b0;
    if (mrd_req) begin rd_due <= cyc + 2 + ($urandom % 3); rd_a <= mrd_addr; end
    if (rd_due >= 0 && cyc >= rd_due) begin
      mrd_valid <= 1'b1; mrd_data <= hmem[rd_a[15:2]]; rd_due <= -1;
    end
  end

  // ---- engine stub ----------------------------------------------------------------
  int  eng_lat = 3;
  bit  eng_hang = 1'b0;
  logic [2:0] eng_status_inj = '0;
  int  eng_cnt = -1;
  int  eng_started = 0, eng_aborts = 0;
  always @(posedge clk) begin
    eng_done <= 1'b0;
    if (eng_abort) begin eng_cnt <= -1; eng_aborts <= eng_aborts + 1; end
    else if (eng_start) begin eng_cnt <= eng_lat; eng_started <= eng_started + 1; end
    else if (eng_cnt > 0) eng_cnt <= eng_cnt - 1;
    else if (eng_cnt == 0 && !eng_hang) begin
      eng_done <= 1'b1; eng_status <= eng_status_inj; eng_cnt <= -1;
    end
  end

  // ---- CSR access (drive on the falling edge so inputs are stable at the rising edge) ----
  task automatic csr_write(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); csr_wr = 1'b1; csr_addr = a; csr_wdata = d;
    @(negedge clk); csr_wr = 1'b0;
  endtask
  task automatic csr_peek(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk); csr_addr = a; #1; d = csr_rdata;
  endtask

  // ---- host-side driver model (mirrors kernel/sfg1_ring.c) ---------------------------------
  task automatic zero_queues();
    for (int i = 0; i < 16384; i++) hmem[i] = 32'h0;
  endtask

  task automatic host_setup(input int entries);
    logic [31:0] st;
    h_sq_n = entries; h_tail = 0; h_cq_head = 0; h_phase = 1; mon_head = 0; mon_phase = 1;
    // Queue registers are frozen while ENABLE=1 and the indices restart on ENABLE 0->1
    // (contract rule R9), so reprogramming starts by disabling.
    csr_write(SFG1_REG_CTRL, 32'(1 << SFG1_CTRL_CLEAR_HALT));   // HALTED survives ENABLE toggles
    csr_write(SFG1_REG_CTRL, 32'h0);
    repeat (40) @(posedge clk);                       // let the in-order channel drain
    pw_head = 0; pw_tail = 0; pw_last_due = cyc; msg_pending_check = 0;
    zero_queues();
    csr_write(SFG1_REG_SQ_BASE_LO, SQ_BASE[31:0]); csr_write(SFG1_REG_SQ_BASE_HI, SQ_BASE[63:32]);
    csr_write(SFG1_REG_SQ_ENTRIES, entries);
    csr_write(SFG1_REG_CQ_BASE_LO, CQ_BASE[31:0]); csr_write(SFG1_REG_CQ_BASE_HI, CQ_BASE[63:32]);
    csr_write(SFG1_REG_CQ_ENTRIES, entries);
    csr_write(SFG1_REG_IRQ_STATUS, 32'h7);
    csr_write(SFG1_REG_IRQ_MASK, 32'h7);
    csr_write(SFG1_REG_CTRL, 32'(1 << SFG1_CTRL_ENABLE));
    csr_peek(SFG1_REG_STATUS, st);
    check(!st[SFG1_STATUS_FATAL] && st[SFG1_STATUS_READY], "device failed to start");
  endtask

  // fill one SQ entry and ring the doorbell. dword layout = struct sfg1_sq_entry
  task automatic host_submit(input logic [15:0] op, input logic [15:0] ctx, input logic [31:0] rsvd0 = 32'h0);
    int base = (SQ_BASE >> 2) + h_tail * 16;
    for (int k = 0; k < 16; k++) hmem[base + k] = 32'h0;
    hmem[base + 0] = {ctx, op};
    hmem[base + 1] = {16'h0, 16'(h_tail)};            // cid == SQ slot
    hmem[base + 3] = rsvd0;
    exp_ctx[h_tail] = ctx;
    h_tail = (h_tail + 1) % h_sq_n;
    // entries are plain stores; the doorbell publishes them (rule R1)
    csr_write(SFG1_REG_SQ_TAIL, 32'(h_tail));
  endtask

  // wait for the next CQE the way the driver does: phase first, THEN payload
  task automatic host_wait_cqe(output logic [2:0] status, output int cid, input int timeout);
    int t = 0;
    int slot = h_cq_head;
    status = 3'd7; cid = -1;
    while (!slot_phase_visible(slot, h_phase) && t < timeout) begin @(posedge clk); t++; end
    if (t >= timeout) begin
      check(1'b0, "timeout waiting for a completion");
    end else begin
      // phase matched -> (rmb) -> only now read the payload
      logic [31:0] dw3 = hmem[(CQ_BASE >> 2) + slot * 4 + 3];
      logic [31:0] dw2 = hmem[(CQ_BASE >> 2) + slot * 4 + 2];
      cid = int'(dw3[15:0]);
      status = dw3[19:17];
      check(dw2[15:0] == 16'((slot + 1) % h_sq_n), "sq_head in CQE");
      h_cq_head = (h_cq_head + 1) % h_sq_n;
      if (h_cq_head == 0) h_phase = 1 - h_phase;
      csr_write(SFG1_REG_CQ_HEAD, 32'(h_cq_head));         // return the credit
    end
  endtask

  // M2: the instant an interrupt message is delivered, the CQE it announces must already be
  // complete in host memory (payload AND phase). Violated if the device publishes the cause early.
  task automatic host_wait_irq(input int timeout);
    int t = 0;
    while (msg_pending_check == 0 && t < timeout) begin @(posedge clk); t++; end
    check(msg_pending_check > 0, "interrupt message expected");
    if (msg_pending_check > 0) begin
      msg_pending_check--;
      check(slot_phase_visible(h_cq_head, h_phase),
            "M2: interrupt message delivered before the CQE it announces was visible");
      begin
        logic [31:0] dw2 = hmem[(CQ_BASE >> 2) + h_cq_head * 4 + 2];
        check(dw2[15:0] == 16'((h_cq_head + 1) % h_sq_n), "M2: announced CQE payload incomplete at interrupt time");
      end
    end
  endtask

  // poll DONE_COUNT instead of guessing a delay (a 64-byte SQ entry over a 32-bit port is ~100 cycles)
  task automatic wait_done_count(input int n, input int timeout);
    logic [31:0] c;
    int t = 0;
    csr_peek(SFG1_REG_DONE_COUNT, c);
    while (int'(c) < n && t < timeout) begin repeat (20) @(posedge clk); t += 20; csr_peek(SFG1_REG_DONE_COUNT, c); end
    check(int'(c) >= n, $sformatf("DONE_COUNT reached %0d (is %0d)", n, c));
  endtask

  // ---- scenarios ------------------------------------------------------------------------------
  logic [31:0] v;
  logic [2:0]  st;
  int          cid;

  initial begin
    $display("tb_sfg1_host_frontend: start");
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (2) @(negedge clk);

    // ---- T1 discovery / register file -----------------------------------------------------------
    csr_peek(SFG1_REG_ID, v);          check(v == SFG1_CHIP_ID, "T1 chip id");
    csr_peek(SFG1_REG_HW_VERSION, v);  check(v[31:16] == 16'd1, "T1 hw major");
    csr_peek(SFG1_REG_CAPS, v);        check((v & 32'h7) == 32'h7, "T1 mandatory caps");
    csr_peek(SFG1_REG_LIMITS0, v);     check(v[15:0] == 16'd8 && v[31:16] == 16'd1024, "T1 limits0");
    csr_peek(SFG1_REG_LIMITS1, v);     check(v[7:0] == 8'd64 && v[31:16] == 16'd1024, "T1 limits1");
    csr_write(SFG1_REG_SCRATCH, 32'hA5A5A5A5); csr_peek(SFG1_REG_SCRATCH, v); check(v == 32'hA5A5A5A5, "T1 scratch a");
    csr_write(SFG1_REG_SCRATCH, 32'h5A5A5A5A); csr_peek(SFG1_REG_SCRATCH, v); check(v == 32'h5A5A5A5A, "T1 scratch b");
    csr_peek(SFG1_REG_STATUS, v);      check(v[SFG1_STATUS_READY] && !v[SFG1_STATUS_BUSY], "T1 ready & idle");

    // ---- T2 one NOP, full driver protocol (ack-then-drain) -----------------------------------------------
    host_setup(16);
    m1_enabled = 1'b1;
    host_submit(SFG1_OP_NOP, 16'd3);
    host_wait_irq(200);
    csr_write(SFG1_REG_IRQ_STATUS, 32'(1 << SFG1_IRQ_CQ));       // ack FIRST ...
    host_wait_cqe(st, cid, 100);                                  // ... then drain
    check(st == SFG1_ST_OK && cid == 0, "T2 completion status/cid");
    csr_peek(SFG1_REG_SQ_HEAD, v); check(v == 1, "T2 SQ_HEAD");
    csr_peek(SFG1_REG_CQ_TAIL, v); check(v == 1, "T2 CQ_TAIL");
    csr_peek(SFG1_REG_DONE_COUNT, v); check(v == 1, "T2 DONE_COUNT");
    csr_peek(SFG1_REG_IRQ_STATUS, v); check(v[SFG1_IRQ_CQ] == 1'b0, "T2 IRQ_STATUS acked");

    // ---- T3 40 commands through a 16-entry ring: wraps, phase toggles, credits (R1,R3) ---------------------------
    for (int i = 0; i < 40; i++) begin
      eng_status_inj = 3'd0;
      host_submit((i % 3 == 0) ? SFG1_OP_NOP : SFG1_OP_VEC, 16'(i % 8));
      host_wait_cqe(st, cid, 400);
      check(st == SFG1_ST_OK, $sformatf("T3 cmd %0d status %0d", i, st));
    end
    // drain stale interrupt messages from the in-order channel, then ack
    repeat (30) @(posedge clk); msg_pending_check = 0;
    csr_write(SFG1_REG_IRQ_STATUS, 32'h7);
    // 41 completions through 16 slots: 2 full laps + 9 -> host phase must have toggled twice
    check(h_phase == 1 && h_cq_head == 41 % 16, $sformatf("T3 phase/head bookkeeping (phase=%0d head=%0d)", h_phase, h_cq_head));
    csr_peek(SFG1_REG_DONE_COUNT, v); check(v == 41, "T3 DONE_COUNT");

    // ---- T3b interrupt-driven: wait for the message, check the CQE is complete (M2), ack-then-drain ----
    for (int i = 0; i < 6; i++) begin
      repeat (30) @(posedge clk); msg_pending_check = 0;
      csr_write(SFG1_REG_IRQ_STATUS, 32'h7);
      repeat (10) @(posedge clk); msg_pending_check = 0;
      host_submit(SFG1_OP_NOP, 16'd2);
      host_wait_irq(300);
      csr_write(SFG1_REG_IRQ_STATUS, 32'(1 << SFG1_IRQ_CQ));
      host_wait_cqe(st, cid, 100);
      check(st == SFG1_ST_OK, "T3b status");
    end

    // ---- T4 interrupt semantics (rule R6) ---------------------------------------------------------------------
    csr_write(SFG1_REG_IRQ_STATUS, 32'h7);
    repeat (20) @(posedge clk); msg_pending_check = 0;
    begin
      int m0 = msgs_issued;
      csr_write(SFG1_REG_IRQ_MASK, 32'h0);                       // masked: no message
      host_submit(SFG1_OP_NOP, 16'd0);
      host_wait_cqe(st, cid, 400);
      repeat (20) @(posedge clk);
      check(msgs_issued == m0, "T4 no message while masked");
      csr_peek(SFG1_REG_IRQ_STATUS, v); check(v[SFG1_IRQ_CQ], "T4 cause latched while masked");
      csr_write(SFG1_REG_IRQ_MASK, 32'h7);                       // unmask with a pending cause: message
      repeat (10) @(posedge clk);
      check(msgs_issued == m0 + 1, "T4 message on unmask");
      // two causes pending, ack only one: the remaining one must re-fire (level semantics)
      csr_write(SFG1_REG_IRQ_MASK, 32'h0);
      eng_status_inj = 3'd0;
      host_submit(SFG1_OP_NOP, 16'd0); host_wait_cqe(st, cid, 400);
      csr_write(SFG1_REG_IRQ_MASK, 32'h7);
      repeat (10) @(posedge clk);
      m0 = msgs_issued;
      csr_write(SFG1_REG_IRQ_STATUS, 32'(1 << SFG1_IRQ_FATAL));  // acks a cause that is not set: CQ stays pending
      repeat (10) @(posedge clk);
      check(msgs_issued == m0 + 1, "T4 message re-fires when a W1C leaves a cause pending");
      csr_write(SFG1_REG_IRQ_STATUS, 32'h7);
      repeat (10) @(posedge clk);
      check(msgs_issued == m0 + 1, "T4 no message once everything is acked");
    end
    repeat (30) @(posedge clk); msg_pending_check = 0;

    // ---- T5 error halts the queue; CLEAR_HALT resumes ---------------------------------------------------------------
    host_setup(16);
    host_submit(16'd99, 16'd1);                                  // unknown opcode
    host_wait_cqe(st, cid, 400);
    check(st == SFG1_ST_BAD_OPCODE, "T5 BAD_OPCODE status");
    csr_peek(SFG1_REG_STATUS, v); check(v[SFG1_STATUS_HALTED], "T5 halted");
    csr_peek(SFG1_REG_STATUS, v); check(v[15:8] == 8'd1, "T5 LAST_ERR");
    csr_peek(SFG1_REG_IRQ_STATUS, v); check(v[SFG1_IRQ_ERROR], "T5 ERROR cause");
    host_submit(SFG1_OP_NOP, 16'd1);                             // must NOT run while halted
    repeat (60) @(posedge clk);
    csr_peek(SFG1_REG_SQ_HEAD, v); check(v == 1, "T5 SQ_HEAD frozen while halted");
    csr_write(SFG1_REG_CTRL, 32'((1 << SFG1_CTRL_ENABLE) | (1 << SFG1_CTRL_CLEAR_HALT)));
    host_wait_cqe(st, cid, 400);
    check(st == SFG1_ST_OK && cid == 1, "T5 resumed after CLEAR_HALT");
    csr_peek(SFG1_REG_ERR_COUNT, v); check(v == 1, "T5 ERR_COUNT");

    // ---- T6 argument checks done by the front-end ---------------------------------------------------------------------
    host_setup(16);
    host_submit(SFG1_OP_NOP, 16'd8);                             // ctx >= MAX_CTX
    host_wait_cqe(st, cid, 400);
    check(st == SFG1_ST_BAD_CTX, "T6 BAD_CTX");
    csr_write(SFG1_REG_CTRL, 32'((1 << SFG1_CTRL_ENABLE) | (1 << SFG1_CTRL_CLEAR_HALT)));
    host_submit(SFG1_OP_NOP, 16'd1, 32'h1);                      // reserved field set
    host_wait_cqe(st, cid, 400);
    check(st == SFG1_ST_BAD_ARGS, "T6 BAD_ARGS");
    csr_write(SFG1_REG_CTRL, 32'((1 << SFG1_CTRL_ENABLE) | (1 << SFG1_CTRL_CLEAR_HALT)));
    eng_status_inj = SFG1_ST_BOUNDS;                             // engine-reported failure is passed through
    host_submit(SFG1_OP_DMA_H2D, 16'd2);
    host_wait_cqe(st, cid, 400);
    check(st == SFG1_ST_BOUNDS, "T6 engine status passed through");
    eng_status_inj = 3'd0;

    // ---- T7 hang -> ENGINE_RESET recovery; an aborted command writes NO completion ---------------------------------------------
    host_setup(16);
    eng_hang = 1'b1;
    host_submit(SFG1_OP_VEC, 16'd0);
    repeat (80) @(posedge clk);
    csr_peek(SFG1_REG_STATUS, v); check(v[SFG1_STATUS_BUSY], "T7 busy while hung");
    csr_peek(SFG1_REG_SQ_HEAD, v); check(v == 0, "T7 SQ_HEAD frozen while hung");
    csr_peek(SFG1_REG_CQ_TAIL, v); check(v == 0, "T7 no completion while hung");
    m1_enabled = 1'b0;
    csr_write(SFG1_REG_CTRL, 32'(1 << SFG1_CTRL_ENGINE_RESET));
    csr_peek(SFG1_REG_STATUS, v); check(v[SFG1_STATUS_RESET_ACTIVE] && !v[SFG1_STATUS_READY], "T7 reset active");
    repeat (RESET_WAIT) @(posedge clk);
    csr_peek(SFG1_REG_STATUS, v); check(v[SFG1_STATUS_READY] && !v[SFG1_STATUS_RESET_ACTIVE] && !v[SFG1_STATUS_BUSY], "T7 ready after reset");
    csr_peek(SFG1_REG_SQ_HEAD, v); check(v == 0, "T7 indices cleared");
    csr_peek(SFG1_REG_CTRL, v);    check(v[SFG1_CTRL_ENABLE] == 1'b0, "T7 ENABLE cleared by reset");
    eng_hang = 1'b0;
    // spec: after the reset the host zeroes the CQ and re-programs; the device starts at phase 1
    repeat (20) @(posedge clk);
    host_setup(16);
    m1_enabled = 1'b1;
    host_submit(SFG1_OP_NOP, 16'd5);
    host_wait_cqe(st, cid, 400);
    check(st == SFG1_ST_OK && cid == 0, "T7 normal operation after recovery");

    // ---- T8 FUNCTION reset clears the queue configuration ---------------------------------------------------------------------------
    csr_write(SFG1_REG_RESET, SFG1_RESET_MAGIC);
    repeat (RESET_WAIT) @(posedge clk);
    csr_peek(SFG1_REG_SQ_ENTRIES, v); check(v == 0, "T8 queue config cleared");
    csr_peek(SFG1_REG_IRQ_MASK, v);   check(v == 0, "T8 irq mask cleared");
    csr_write(SFG1_REG_RESET, 32'hDEADBEEF);                      // wrong magic: ignored
    repeat (3) @(posedge clk);
    csr_peek(SFG1_REG_STATUS, v);     check(v[SFG1_STATUS_READY], "T8 wrong magic ignored");

    // ---- T9 invalid queue configuration is refused at enable ------------------------------------------------------------------------
    csr_write(SFG1_REG_SQ_BASE_LO, 32'h1000); csr_write(SFG1_REG_SQ_BASE_HI, 32'h0);
    csr_write(SFG1_REG_SQ_ENTRIES, 32'd24);                       // not a power of two
    csr_write(SFG1_REG_CQ_BASE_LO, 32'h3000); csr_write(SFG1_REG_CQ_BASE_HI, 32'h0);
    csr_write(SFG1_REG_CQ_ENTRIES, 32'd32);
    csr_write(SFG1_REG_CTRL, 32'(1 << SFG1_CTRL_ENABLE));
    csr_peek(SFG1_REG_STATUS, v);  check(v[SFG1_STATUS_FATAL], "T9 non-power-of-two SQ rejected (FATAL)");
    csr_peek(SFG1_REG_CTRL, v);    check(v[SFG1_CTRL_ENABLE] == 1'b0, "T9 not enabled");
    csr_write(SFG1_REG_RESET, SFG1_RESET_MAGIC);
    repeat (RESET_WAIT) @(posedge clk);

    // ---- T10 queue registers are frozen while enabled -------------------------------------------------------------------------------
    m1_enabled = 1'b0;
    host_setup(16);
    csr_write(SFG1_REG_SQ_ENTRIES, 32'd64);
    csr_peek(SFG1_REG_SQ_ENTRIES, v); check(v == 16, "T10 SQ_ENTRIES write ignored while enabled");
    csr_write(SFG1_REG_SQ_BASE_LO, 32'h8000);
    csr_peek(SFG1_REG_SQ_BASE_LO, v); check(v == SQ_BASE[31:0], "T10 SQ_BASE write ignored while enabled");

    // ---- T11 CQ overflow protection ----------------------------------------------------------------------------------------------
    // A host that reuses SQ slots WITHOUT returning CQ credit (never writing CQ_HEAD) would make the
    // device overwrite a completion the host has not consumed yet. The device must refuse: FATAL,
    // no CQE written, CQ_TAIL not advanced.
    csr_write(SFG1_REG_CTRL, 32'(1 << SFG1_CTRL_ENGINE_RESET));
    repeat (RESET_WAIT) @(posedge clk);
    m1_enabled = 1'b0;
    host_setup(16);
    for (int i = 0; i < 15; i++) host_submit(SFG1_OP_NOP, 16'd0);        // 15 = SQ capacity (one slot kept empty)
    wait_done_count(15, 6000);
    csr_peek(SFG1_REG_CQ_TAIL, v);   check(v == 15, $sformatf("T11 15 completions posted (CQ_TAIL=%0d)", v));
    csr_peek(SFG1_REG_SQ_HEAD, v);   check(v == 15, $sformatf("T11 all 15 consumed (SQ_HEAD=%0d)", v));
    check(!(hmem[(CQ_BASE >> 2) + 15 * 4 + 3] != 32'h0), "T11 slot 15 still untouched");
    host_submit(SFG1_OP_NOP, 16'd0);                                      // slot 15: would need CQ slot 15, whose successor is unconsumed slot 0
    repeat (400) @(posedge clk);
    csr_peek(SFG1_REG_STATUS, v);    check(v[SFG1_STATUS_FATAL], "T11 device raised FATAL instead of overwriting");
    csr_peek(SFG1_REG_IRQ_STATUS, v); check(v[SFG1_IRQ_FATAL], "T11 FATAL interrupt cause");
    csr_peek(SFG1_REG_CQ_TAIL, v);   check(v == 15, "T11 CQ_TAIL not advanced");
    check(hmem[(CQ_BASE >> 2) + 15 * 4 + 3] == 32'h0, "T11 no CQE written into the would-be-overwritten region");

    $display("tb_sfg1_host_frontend: %0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB_RESULT PASS checks=%0d", checks);
    else             $display("TB_RESULT FAIL checks=%0d errors=%0d", checks, errors);
    $finish;
  end

  localparam int RESET_WAIT = 14;

  // watchdog
  initial begin
    #5_000_000;
    $display("TB_RESULT FAIL (watchdog)");
    $finish;
  end
endmodule
