#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-only
# Simulate the SF-G1 host front-end reference RTL.
#   rtl/run_sim.sh            # needs Verilator >= 5 (tested: 5.020 with --binary --timing)
#
# Icarus Verilog 12 is NOT supported: it cannot elaborate the DUT correctly
# ("constant selects in always_* processes are not currently supported" -> X).
#
# Runs THREE configurations:
#   ORDER_BUG=0  the correct design          -> testbench must PASS
#   ORDER_BUG=1  phase dword written first   -> testbench must FAIL (mutant)
#   ORDER_BUG=2  interrupt before CQE done   -> testbench must FAIL (mutant)
# A checker that cannot fail proves nothing; the mutants show these can.
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
OUT=${OUT:-$(mktemp -d)}
mkdir -p "$OUT"
FILES="$HERE/sfg1_pkg.sv $HERE/sfg1_host_frontend.sv $HERE/tb_sfg1_host_frontend.sv"
rc=0

run_one() {
	local bug=$1 expect=$2 log="$OUT/sim_bug$1.log"
	command -v verilator >/dev/null || { echo "verilator not found (apt install verilator)"; return 2; }
	verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module tb_sfg1_host_frontend \
		-GORDER_BUG=$bug --Mdir "$OUT/obj$bug" -o sim $FILES > "$OUT/build$bug.log" 2>&1 || {
		echo "verilator build failed (bug=$bug):"; tail -30 "$OUT/build$bug.log"; return 2; }
	"$OUT/obj$bug/sim" > "$log" 2>&1
	local res; res=$(grep -E "TB_RESULT" "$log" | tail -1)
	local nfail; nfail=$(grep -c "FAIL @" "$log" || true)
	printf "ORDER_BUG=%s  expect %-4s -> %s  (%s failing checks)\n" "$bug" "$expect" "${res:-no result}" "$nfail"
	if [ "$expect" = PASS ]; then
		echo "$res" | grep -q "TB_RESULT PASS" || { sed -n '1,25p' "$log"; return 1; }
	else
		echo "$res" | grep -q "TB_RESULT FAIL" || return 1
	fi
	return 0
}

run_one 0 PASS || rc=1
run_one 1 FAIL || rc=1
run_one 2 FAIL || rc=1
[ $rc -eq 0 ] && echo "RTL SIM OK: design passes, both ordering mutants are caught" || echo "RTL SIM FAILED"
exit $rc
