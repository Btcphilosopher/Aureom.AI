# SilicaFlux SF-G1 — Linux host driver (DRM accel), with mock device and reference RTL

Host-side Linux driver for the **SilicaFlux SF-G1** accelerator: device discovery, register
mapping, DMA buffer management, command submission, completion handling, interrupts,
per-process contexts, resource accounting, timeout/reset recovery and safe removal — behind
a small, versioned userspace API with input validation and per-process buffer isolation.
The driver runs on the CPU; the device hardware is SystemVerilog.

> ## Read this before relying on anything here
> 1. **No SF-G1 hardware spec existed** in the source repository (only a p40 *stand-in*
>    RTL with a 16-bit fabric and no host DMA/PCIe/queues). The hardware/driver contract in
>    [`docs/02-hw-interface.md`](docs/02-hw-interface.md) is a **proposal authored with the
>    driver** and must be ratified or replaced by the hardware team.
> 2. **Nothing has run on physical hardware.** Everything was exercised against a
>    **software mock** and a **reference RTL model** that follow the same draft contract.
>    A simulated device does **not** prove physical-hardware reliability or production-grade
>    isolation. See [`docs/06-limitations.md`](docs/06-limitations.md).
> 3. The **PCI glue is compile-tested only.** No PCI vendor/device ID is invented; the table
>    is empty until you supply one.
> 4. Privileged hardware integration steps are listed explicitly in
>    [`docs/07-hw-bringup.md`](docs/07-hw-bringup.md).

## Target and interface (decided before implementation — `docs/01-design.md`)

* **Kernel: Linux 6.18 LTS.** All APIs were checked against the real `v6.18` source tree.
* **Interface: DRM compute-accelerator subsystem** (`DRIVER_COMPUTE_ACCEL`,
  `/dev/accel/accelN`) — the upstream home for NPUs/AI accelerators (ivpu, qaic, rocket,
  amdxdna). It supplies exactly what was asked for: per-open process contexts, per-file GEM
  handles (the basis of buffer isolation), `drm_sched` scheduling and hang detection,
  `dma_fence` completion, `drm_dev_unplug` safe removal, fdinfo accounting. Rejected:
  custom char device (re-implements all of it), render node (wrong subsystem for compute),
  VFIO/UIO (hands the device to applications — the opposite of the requirement).

## Layout

```
kernel/        driver (drop-in for drivers/accel/sfg1; also builds out-of-tree)
  sfg1_hw.h      hardware contract: registers, SQ/CQ formats, opcodes, status codes
  sfg1_main.c    drm_driver, module params, device bring-up / safe removal
  sfg1_hw.c      discovery (range-checked), queue memory, start/quiesce, resets
  sfg1_ring.c    SQ/CQ, doorbells, phase-bit reaping — the memory-ordering rules
  sfg1_irq.c     top half (ack) + threaded drain (acknowledge-then-drain)
  sfg1_job.c     SUBMIT validation -> descriptors, drm_sched ops, WAIT_JOB
  sfg1_reset.c   timeout / error recovery (one path), ENGINE -> FUNCTION -> DEAD
  sfg1_ctx.c     process contexts, window slots + scrub, quotas, stats, fdinfo
  sfg1_gem.c     driver-owned DMA buffers, ownership, dma-buf export blocked
  sfg1_pci.c     PCI glue (compile-tested only)
  sfg1_mock.c    software SF-G1 (TEST ONLY): register file, engine, irq_sim, fault injection
include/uapi/drm/sfg1_accel.h   userspace API v1.0
rtl/           SystemVerilog host front-end (reference), package, self-checking TB, runner
examples/      sfg1_user.h helper + 5 example programs
tests/         QEMU test suite, kernel test config, contract cross-check
tools/         install into a kernel tree, zip builder
docs/          01 design  02 hw contract  03 uapi  04 security  05 testing  06 limitations  07 bring-up
  evidence/      raw logs of the final verification pass
LICENSES/      GPL-2.0, MIT, Linux-syscall-note (copied from the 6.18 tree)
```

## Quick start

```sh
# 1. Build the module for a running 6.18 kernel (real-hardware configuration, no mock)
make module KDIR=/lib/modules/$(uname -r)/build
# 2. ...or against a 6.18 source/build tree, with the software mock for testing
make module KSRC=~/linux-6.18 KBUILD=~/kbuild-6.18 MOCK=1
# 3. Load it with one mock device (TEST ONLY) and try the examples
sudo insmod gpu-sched.ko                      # from the same kernel build, if built as a module
sudo insmod kernel/sfg1.ko mock_devices=1
make examples && build/ex1_info && build/ex2_vector_add && build/ex4_isolation_demo
```

Userspace API walk-through: [`docs/03-uapi.md`](docs/03-uapi.md). In-tree: run
`tools/install-into-kernel-tree.sh <linux-6.18>` and enable `CONFIG_DRM_ACCEL_SFG1`.

## Verification summary (details and exact numbers: [`docs/05-testing.md`](docs/05-testing.md))

| Check | Result |
|---|---|
| Compiles against v6.18, in-tree and out-of-tree, `W=1` | 0 warnings |
| `sparse` with endian checking (`C=2 __CHECK_ENDIAN__`) | 0 diagnostics |
| `checkpatch --strict` | 0 errors |
| End-to-end suite in a QEMU-booted 6.18 test kernel (KASAN, UBSAN, lockdep, debug-atomic-sleep, kmemleak, fault injection) against the **mock** | **8/8 consecutive runs pass**, ~4,600 checks each, 0 kernel splats (3 of 9 earlier runs failed intermittently; root-caused and fixed — see 05 §5) |
| Reference RTL (Verilator): design passes (566 checks); **both deliberately-wrong ordering mutants are caught** | pass |
| C header ↔ SV package constant cross-check (with proven negative control) | 58 constants identical |
| Physical SF-G1 hardware | **not tested** — no hardware and no ratified spec were available |

## Licensing

Kernel sources: GPL-2.0-only. UAPI header: `GPL-2.0 WITH Linux-syscall-note OR MIT`.
Examples: MIT. RTL and tests: SPDX tags as in each file (GPL-2.0-only); choose the licence
that suits your hardware IP before publishing. Texts are in `LICENSES/`.
