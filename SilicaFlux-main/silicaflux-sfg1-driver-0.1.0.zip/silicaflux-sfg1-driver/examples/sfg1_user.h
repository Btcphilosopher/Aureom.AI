/* SPDX-License-Identifier: MIT */
/*
 * sfg1_user.h — tiny header-only userspace helper for the SF-G1 accel UAPI.
 *
 * Depends only on <drm/drm.h> (package linux-libc-dev / kernel uapi headers),
 * not on libdrm. Build:  cc -I<pkg>/include/uapi examples/exN.c -o exN
 *
 * This is a convenience, not a stable library: the stable interface is the
 * ioctl ABI in include/uapi/drm/sfg1_accel.h (see docs/03-uapi.md).
 */
#ifndef SFG1_USER_H
#define SFG1_USER_H

#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

#include <drm/sfg1_accel.h>

struct sfg1_dev {
	int fd;
	uint32_t ctx_id;
	uint64_t window;	/* bytes of device memory owned by this context */
	uint32_t max_cmds;	/* max commands per SUBMIT */
	uint64_t max_bo_size;
};

struct sfg1_bo {
	uint32_t handle;
	uint64_t size;
	uint64_t mmap_offset;
	void *map;		/* CPU mapping (NULL if not mapped) */
};

/* ioctl wrapper: retries EINTR/EAGAIN like libdrm; returns 0 or -errno. */
static inline int sfg1_ioctl(int fd, unsigned long req, void *arg)
{
	int r;

	do {
		r = ioctl(fd, req, arg);
	} while (r < 0 && (errno == EINTR || errno == EAGAIN));
	return r < 0 ? -errno : 0;
}

/* Find the lowest-numbered /dev/accel/accelN. Returns 0 and fills path. */
static inline int sfg1_find_device(char *path, size_t len)
{
	static const char prefix[] = "/dev/accel/";
	DIR *d = opendir("/dev/accel");
	struct dirent *e;
	char best[64] = "";

	if (!d)
		return -errno;
	while ((e = readdir(d))) {
		size_t nl = strlen(e->d_name);

		if (strncmp(e->d_name, "accel", 5) || nl >= sizeof(best))
			continue;
		if (!best[0] || strcmp(e->d_name, best) < 0)
			memcpy(best, e->d_name, nl + 1);
	}
	closedir(d);
	if (!best[0] || sizeof(prefix) - 1 + strlen(best) + 1 > len)
		return -ENODEV;
	memcpy(path, prefix, sizeof(prefix) - 1);
	memcpy(path + sizeof(prefix) - 1, best, strlen(best) + 1);
	return 0;
}

static inline int sfg1_param(const struct sfg1_dev *d, uint32_t param, uint64_t *v)
{
	struct drm_sfg1_get_param p = { .param = param };
	int r = sfg1_ioctl(d->fd, DRM_IOCTL_SFG1_GET_PARAM, &p);

	if (!r)
		*v = p.value;
	return r;
}

/* Open a context (one per open fd) and read the limits needed to use it. */
static inline int sfg1_open(const char *path, struct sfg1_dev *d)
{
	uint64_t v;
	int r;

	memset(d, 0, sizeof(*d));
	d->fd = open(path, O_RDWR | O_CLOEXEC);
	if (d->fd < 0)
		return -errno;
	r = sfg1_param(d, DRM_SFG1_PARAM_UAPI_VERSION, &v);
	if (r || (v >> 16) != DRM_SFG1_UAPI_MAJOR) {	/* major mismatch = ABI break */
		close(d->fd);
		return r ? r : -EPROTO;
	}
	if (!sfg1_param(d, DRM_SFG1_PARAM_CTX_ID, &v))
		d->ctx_id = (uint32_t)v;
	if (!sfg1_param(d, DRM_SFG1_PARAM_CTX_WINDOW_SIZE, &v))
		d->window = v;
	if (!sfg1_param(d, DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT, &v))
		d->max_cmds = (uint32_t)v;
	if (!sfg1_param(d, DRM_SFG1_PARAM_MAX_BO_SIZE, &v))
		d->max_bo_size = v;
	return 0;
}

static inline void sfg1_close(struct sfg1_dev *d)
{
	if (d->fd >= 0)
		close(d->fd);
	d->fd = -1;
}

/* Allocate a buffer and map it. Returns 0 or -errno. */
static inline int sfg1_bo_create(struct sfg1_dev *d, uint64_t size, struct sfg1_bo *bo)
{
	struct drm_sfg1_bo_create a = { .size = size };
	int r = sfg1_ioctl(d->fd, DRM_IOCTL_SFG1_BO_CREATE, &a);

	if (r)
		return r;
	bo->handle = a.handle;
	bo->size = a.real_size;
	bo->mmap_offset = a.mmap_offset;
	bo->map = mmap(NULL, bo->size, PROT_READ | PROT_WRITE, MAP_SHARED, d->fd,
		       (off_t)a.mmap_offset);
	if (bo->map == MAP_FAILED) {
		bo->map = NULL;
		r = -errno;
	}
	return r;
}

static inline void sfg1_bo_destroy(struct sfg1_dev *d, struct sfg1_bo *bo)
{
	struct drm_gem_close c = { .handle = bo->handle };

	if (bo->map)
		munmap(bo->map, bo->size);
	bo->map = NULL;
	if (bo->handle)
		sfg1_ioctl(d->fd, DRM_IOCTL_GEM_CLOSE, &c);
	bo->handle = 0;
}

/* ---- command builders ------------------------------------------------- */
static inline struct drm_sfg1_cmd sfg1_cmd_nop(void)
{
	struct drm_sfg1_cmd c = { .op = DRM_SFG1_OP_NOP };
	return c;
}

static inline struct drm_sfg1_cmd sfg1_cmd_h2d(const struct sfg1_bo *bo, uint64_t bo_off,
					       uint64_t dev_off, uint64_t len)
{
	struct drm_sfg1_cmd c = { .op = DRM_SFG1_OP_DMA_H2D, .bo_handle = bo->handle,
				  .bo_offset = bo_off, .dev_a = dev_off, .len = len };
	return c;
}

static inline struct drm_sfg1_cmd sfg1_cmd_d2h(const struct sfg1_bo *bo, uint64_t bo_off,
					       uint64_t dev_off, uint64_t len)
{
	struct drm_sfg1_cmd c = { .op = DRM_SFG1_OP_DMA_D2H, .bo_handle = bo->handle,
				  .bo_offset = bo_off, .dev_a = dev_off, .len = len };
	return c;
}

/* words = number of 32-bit words (4 INT8 lanes each) */
static inline struct drm_sfg1_cmd sfg1_cmd_vec(uint32_t vop, uint64_t a, uint64_t b, uint64_t c_,
					       uint64_t words)
{
	struct drm_sfg1_cmd c = { .op = DRM_SFG1_OP_VEC, .exec_op = vop, .len = words,
				  .dev_a = a, .dev_b = b, .dev_c = c_ };
	return c;
}

/* tiles of 4x4 INT8 x 4x4 INT8 -> 4x4 INT32; acc != 0: C += A*B */
static inline struct drm_sfg1_cmd sfg1_cmd_ten(uint64_t a, uint64_t b, uint64_t c_,
					       uint64_t tiles, int acc)
{
	struct drm_sfg1_cmd c = { .op = DRM_SFG1_OP_TEN, .len = tiles, .dev_a = a, .dev_b = b,
				  .dev_c = c_, .flags = acc ? DRM_SFG1_CMDF_TEN_ACC : 0 };
	return c;
}

/* ---- submit / wait ----------------------------------------------------- */
static inline int sfg1_submit(struct sfg1_dev *d, const struct drm_sfg1_cmd *cmds, uint32_t n,
			      uint64_t *job_id)
{
	struct drm_sfg1_submit s = { .cmds_ptr = (uintptr_t)cmds, .cmd_count = n,
				     .cmd_stride = sizeof(*cmds) };
	int r = sfg1_ioctl(d->fd, DRM_IOCTL_SFG1_SUBMIT, &s);

	if (!r && job_id)
		*job_id = s.job_id;
	return r;
}

static inline int64_t sfg1_now_ns(void)
{
	struct timespec ts;

	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

/*
 * Wait for (and reap) a job. timeout_ms < 0: forever; 0: poll.
 * Returns 0 and fills *status (DRM_SFG1_JOB_*), or -errno
 * (-ETIMEDOUT/-EBUSY: the job was NOT reaped and can be waited again).
 */
static inline int sfg1_wait(struct sfg1_dev *d, uint64_t job, int64_t timeout_ms,
			    uint32_t *status, uint32_t *dev_error)
{
	struct drm_sfg1_wait_job w = { .job_id = job };
	int r;

	if (timeout_ms < 0)
		w.timeout_ns = INT64_MAX;
	else if (timeout_ms == 0)
		w.timeout_ns = 0;
	else
		w.timeout_ns = sfg1_now_ns() + timeout_ms * 1000000LL;
	r = sfg1_ioctl(d->fd, DRM_IOCTL_SFG1_WAIT_JOB, &w);
	if (!r) {
		if (status)
			*status = w.status;
		if (dev_error)
			*dev_error = w.dev_error;
	}
	return r;
}

/*
 * Submit a batch and wait for it. Returns 0 only if the job completed OK;
 * otherwise a negative errno, or -(1000 + DRM_SFG1_JOB_*) for a job that ran
 * but did not complete OK (ERROR / TIMEOUT / CANCELED).
 */
static inline int sfg1_run(struct sfg1_dev *d, const struct drm_sfg1_cmd *cmds, uint32_t n)
{
	uint64_t id;
	uint32_t st = 0;
	int r = sfg1_submit(d, cmds, n, &id);

	if (r)
		return r;
	r = sfg1_wait(d, id, -1, &st, NULL);
	if (r)
		return r;
	return st == DRM_SFG1_JOB_OK ? 0 : -(1000 + (int)st);
}

static inline const char *sfg1_job_status_str(uint32_t s)
{
	switch (s) {
	case DRM_SFG1_JOB_OK:       return "OK";
	case DRM_SFG1_JOB_ERROR:    return "ERROR";
	case DRM_SFG1_JOB_TIMEOUT:  return "TIMEOUT";
	case DRM_SFG1_JOB_CANCELED: return "CANCELED";
	default:                    return "?";
	}
}

#endif /* SFG1_USER_H */
