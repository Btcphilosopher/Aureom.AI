/* SPDX-License-Identifier: MIT */
/* ex1_info: open an SF-G1 context, print driver/hardware limits and accounting. */
#include "sfg1_user.h"

int main(int argc, char **argv)
{
	char path[64] = "";
	struct sfg1_dev d;
	struct drm_sfg1_get_stats s = {};
	uint64_t v;
	int r;

	if (argc > 1)
		snprintf(path, sizeof(path), "%s", argv[1]);
	else if ((r = sfg1_find_device(path, sizeof(path)))) {
		fprintf(stderr, "no /dev/accel device: %s\n", strerror(-r));
		return 1;
	}
	if ((r = sfg1_open(path, &d))) {
		fprintf(stderr, "open %s: %s\n", path, strerror(-r));
		return 1;
	}

	sfg1_param(&d, DRM_SFG1_PARAM_UAPI_VERSION, &v);
	printf("device            %s\n", path);
	printf("uapi version      %u.%u\n", (unsigned)(v >> 16), (unsigned)(v & 0xffff));
	sfg1_param(&d, DRM_SFG1_PARAM_HW_VERSION, &v);
	printf("hw version        %u.%u.%u\n", (unsigned)(v >> 16), (unsigned)((v >> 8) & 0xff),
	       (unsigned)(v & 0xff));
	sfg1_param(&d, DRM_SFG1_PARAM_HW_CAPS, &v);
	printf("hw caps           %#llx\n", (unsigned long long)v);
	printf("context id        %u\n", d.ctx_id);
	printf("device window     %llu KiB (this context's private device memory)\n",
	       (unsigned long long)(d.window >> 10));
	printf("max cmds/submit   %u\n", d.max_cmds);
	printf("max BO size       %llu KiB\n", (unsigned long long)(d.max_bo_size >> 10));
	sfg1_param(&d, DRM_SFG1_PARAM_JOB_TIMEOUT_MS, &v);
	printf("hang timeout      %llu ms\n", (unsigned long long)v);

	if (!(r = sfg1_ioctl(d.fd, DRM_IOCTL_SFG1_GET_STATS, &s))) {
		printf("ctx state         %#x\n", s.ctx_state);
		printf("jobs ok/err/to/ca %llu/%llu/%llu/%llu\n", (unsigned long long)s.jobs_ok,
		       (unsigned long long)s.jobs_error, (unsigned long long)s.jobs_timeout,
		       (unsigned long long)s.jobs_canceled);
		printf("device resets     engine=%llu function=%llu\n",
		       (unsigned long long)s.device_engine_resets,
		       (unsigned long long)s.device_func_resets);
	}
	sfg1_close(&d);
	return 0;
}
