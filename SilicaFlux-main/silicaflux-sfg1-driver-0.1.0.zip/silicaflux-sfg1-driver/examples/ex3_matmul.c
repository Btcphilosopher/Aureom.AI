/* SPDX-License-Identifier: MIT */
/* ex3_matmul: 4x4 INT8 tiles -> INT32, with and without accumulation. */
#include "sfg1_user.h"

#define TILES 4

int main(void)
{
	char path[64];
	struct sfg1_dev d;
	struct sfg1_bo bo;
	const uint64_t a_sz = 16 * TILES, c_sz = 64 * TILES;
	const uint64_t a_off = 0, b_off = a_sz, c_off = 2 * a_sz;
	uint8_t *h;
	int32_t *c;
	int r, bad = 0;

	if ((r = sfg1_find_device(path, sizeof(path))) || (r = sfg1_open(path, &d)) ||
	    (r = sfg1_bo_create(&d, 4096, &bo))) {
		fprintf(stderr, "setup: %s\n", strerror(-r));
		return 1;
	}
	h = bo.map;
	for (unsigned i = 0; i < 2 * a_sz; i++)
		h[i] = (uint8_t)(i * 13 + 5);
	c = (int32_t *)(h + 2048);

	struct drm_sfg1_cmd up[] = {
		sfg1_cmd_h2d(&bo, 0, a_off, 2 * a_sz),		/* A tiles then B tiles */
		sfg1_cmd_ten(a_off, b_off, c_off, TILES, 0),	/* C  = A*B */
		sfg1_cmd_ten(a_off, b_off, c_off, TILES, 1),	/* C += A*B  (== 2*A*B) */
		sfg1_cmd_d2h(&bo, 2048, c_off, c_sz),
	};
	if ((r = sfg1_run(&d, up, 4))) {
		fprintf(stderr, "job failed: %d\n", r);
		return 1;
	}
	for (unsigned t = 0; t < TILES; t++)
		for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++) {
				int32_t acc = 0;

				for (int k = 0; k < 4; k++)
					acc += (int8_t)h[16 * t + 4 * i + k] *
					       (int8_t)h[a_sz + 16 * t + 4 * k + j];
				if (c[16 * t + 4 * i + j] != 2 * acc)
					bad++;
			}
	printf("%d 4x4 matmul tiles (C = A*B; C += A*B): %s\n", TILES, bad ? "FAILED" : "OK");
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
	return bad ? 1 : 0;
}
