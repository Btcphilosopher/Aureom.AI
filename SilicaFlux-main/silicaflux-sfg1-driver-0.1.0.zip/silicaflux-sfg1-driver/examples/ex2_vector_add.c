/* SPDX-License-Identifier: MIT */
/*
 * ex2_vector_add: the canonical SF-G1 workflow.
 *   1. allocate a staging buffer (BO) and fill it from the CPU
 *   2. one job: upload A and B to the device window, VEC ADD8, download C
 *   3. verify against a CPU reference
 * Device addresses are offsets into THIS context's window; the kernel adds the
 * hardware base and checks every range. Nothing here is a physical address.
 */
#include "sfg1_user.h"

#define WORDS 256			/* 32-bit words; each holds 4 INT8 lanes */

int main(void)
{
	char path[64];
	struct sfg1_dev d;
	struct sfg1_bo bo;
	const uint64_t bytes = WORDS * 4, a_off = 0, b_off = bytes, c_off = 2 * bytes;
	int8_t *host;
	int r, bad = 0;

	if ((r = sfg1_find_device(path, sizeof(path))) || (r = sfg1_open(path, &d))) {
		fprintf(stderr, "open: %s\n", strerror(-r));
		return 1;
	}
	if ((r = sfg1_bo_create(&d, 3 * bytes, &bo))) {
		fprintf(stderr, "bo_create: %s\n", strerror(-r));
		return 1;
	}
	host = bo.map;
	for (unsigned i = 0; i < 2 * bytes; i++)
		host[i] = (int8_t)(i * 7 + 3);	/* A at [0,bytes), B at [bytes,2*bytes) */

	struct drm_sfg1_cmd job[] = {
		sfg1_cmd_h2d(&bo, 0, a_off, bytes),				/* A -> dev */
		sfg1_cmd_h2d(&bo, bytes, b_off, bytes),				/* B -> dev */
		sfg1_cmd_vec(DRM_SFG1_VEC_ADD8, a_off, b_off, c_off, WORDS),	/* C = A + B */
		sfg1_cmd_d2h(&bo, 2 * bytes, c_off, bytes),			/* dev -> C */
	};

	r = sfg1_run(&d, job, 4);
	if (r) {
		fprintf(stderr, "job failed: %d\n", r);
		return 1;
	}
	for (unsigned i = 0; i < bytes; i++) {
		int8_t want = (int8_t)(host[i] + host[bytes + i]);

		if (host[2 * bytes + i] != want && ++bad < 5)
			fprintf(stderr, "mismatch at %u: got %d want %d\n", i, host[2 * bytes + i],
				want);
	}
	printf("vector add of %u INT8 lanes: %s\n", WORDS * 4, bad ? "FAILED" : "OK");
	sfg1_bo_destroy(&d, &bo);
	sfg1_close(&d);
	return bad ? 1 : 0;
}
