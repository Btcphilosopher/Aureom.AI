/* SPDX-License-Identifier: MIT */
/*
 * ex4_isolation_demo: one process cannot reach another process's buffers.
 * The parent creates a buffer holding a secret. The child opens its OWN
 * context and then tries every route to it: using the parent's handle number,
 * mapping the parent's mmap offset, exporting it as a dma-buf. All must fail.
 * Exit status 0 means every attempt was refused (the intended behaviour).
 */
#include "sfg1_user.h"
#include <sys/wait.h>

int main(void)
{
	char path[64];
	struct sfg1_dev d;
	struct sfg1_bo secret;
	int pfd[2], r, errors = 0;
	pid_t pid;

	if ((r = sfg1_find_device(path, sizeof(path))) || (r = sfg1_open(path, &d)) ||
	    (r = sfg1_bo_create(&d, 4096, &secret))) {
		fprintf(stderr, "setup: %s\n", strerror(-r));
		return 1;
	}
	memset(secret.map, 0x5a, 4096);
	if (pipe(pfd))
		return 1;

	pid = fork();
	if (pid == 0) {
		struct sfg1_dev e;
		struct drm_sfg1_cmd c;
		struct drm_prime_handle ph = { .handle = secret.handle, .flags = 0 };
		void *m;

		if (sfg1_open(path, &e))
			_exit(2);

		/* 1. the parent's handle number means nothing on the child's fd */
		struct sfg1_bo fake = { .handle = secret.handle };
		c = sfg1_cmd_h2d(&fake, 0, 0, 4096);
		r = sfg1_submit(&e, &c, 1, NULL);
		printf("child: submit with parent's handle      -> %s (want ENOENT)\n", strerror(-r));
		errors += (r != -ENOENT);

		/* 2. the parent's mmap offset is not authorised for the child's fd */
		m = mmap(NULL, 4096, PROT_READ, MAP_SHARED, e.fd, (off_t)secret.mmap_offset);
		printf("child: mmap parent's buffer offset      -> %s (want mapping refused)\n",
		       m == MAP_FAILED ? strerror(errno) : "MAPPED!");
		errors += (m != MAP_FAILED);

		/* 3. dma-buf export is refused outright, even for the caller's OWN buffer */
		struct sfg1_bo own;

		if (sfg1_bo_create(&e, 4096, &own))
			_exit(3);
		ph.handle = own.handle;
		r = sfg1_ioctl(e.fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph);
		printf("child: export own buffer as dma-buf     -> %s (want EPERM)\n",
		       r ? strerror(-r) : "EXPORTED!");
		errors += (r != -EPERM);

		sfg1_close(&e);
		_exit(errors ? 1 : 0);
	}
	{
		int st = 0;

		waitpid(pid, &st, 0);
		errors += !(WIFEXITED(st) && WEXITSTATUS(st) == 0);
	}
	sfg1_bo_destroy(&d, &secret);
	sfg1_close(&d);
	printf("isolation demo: %s\n", errors ? "FAILED" : "all cross-process attempts refused");
	return errors ? 1 : 0;
}
