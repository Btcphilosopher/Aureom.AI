/* SPDX-License-Identifier: MIT */
/*
 * ex5_error_handling: how a well-behaved client reacts to the documented
 * failure modes (docs/03-uapi.md). Shows the control flow only: it does not
 * inject faults itself.
 */
#include "sfg1_user.h"

/* Run one job, retrying only where retrying is meaningful. */
static int run_with_recovery(const char *path, struct sfg1_dev *d,
			     const struct drm_sfg1_cmd *cmds, uint32_t n)
{
	int r, attempt;

	for (attempt = 0; attempt < 3; attempt++) {
		r = sfg1_run(d, cmds, n);
		if (r == 0)
			return 0;
		switch (r) {
		case -(1000 + DRM_SFG1_JOB_CANCELED):
			/* A reset interrupted the job. Device memory effects are undefined:
			 * re-upload inputs, then resubmit. (Safe to retry: nothing replays.) */
			fprintf(stderr, "job canceled by a device reset; retrying\n");
			continue;
		case -(1000 + DRM_SFG1_JOB_TIMEOUT):
		case -(1000 + DRM_SFG1_JOB_ERROR):
			/* This job hung or faulted. Repeating the same job will get the context
			 * banned; fix the job instead of retrying. */
			fprintf(stderr, "job failed (%s): not retrying\n",
				sfg1_job_status_str(-r - 1000));
			return r;
		case -ECONNRESET:
			/* Context lost: device memory was discarded. Open a new one. */
			fprintf(stderr, "context lost; reopening\n");
			sfg1_close(d);
			if ((r = sfg1_open(path, d)))
				return r;
			continue;
		case -ECANCELED:	/* banned for repeated failures: do not hammer the device */
		case -ENODEV:		/* device removed or dead */
		default:
			fprintf(stderr, "fatal: %s\n", strerror(-r));
			return r;
		case -EBUSY:		/* too many jobs in flight: back off */
			usleep(1000);
			continue;
		}
	}
	return r;
}

int main(void)
{
	char path[64];
	struct sfg1_dev d;
	struct drm_sfg1_cmd nop = sfg1_cmd_nop();
	int r;

	if ((r = sfg1_find_device(path, sizeof(path))) || (r = sfg1_open(path, &d))) {
		fprintf(stderr, "open: %s\n", strerror(-r));
		return 1;
	}
	r = run_with_recovery(path, &d, &nop, 1);
	printf("job result: %s\n", r ? "failed" : "OK");
	sfg1_close(&d);
	return r ? 1 : 0;
}
