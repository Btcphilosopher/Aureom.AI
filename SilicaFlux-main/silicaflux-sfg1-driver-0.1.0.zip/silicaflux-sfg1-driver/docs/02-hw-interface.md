# 02 — SF-G1 host/device hardware contract (DRAFT v1.0 — proposal)

> **Provenance — read first.** No SF-G1 hardware specification existed in the source
> repository. This document is a **proposal authored together with the driver**.
> It reuses vocabulary from the SilicaFlux *p40 stand-in RTL* (chip ID `0x53464001`,
> opcode numbering, error-code numbering, VEC/TEN arithmetic) but the p40 stand-in has
> a 16-bit address fabric, a private on-die command RAM and no host DMA, PCIe, MSI-X or
> completion queue — so everything about host memory, queues, interrupts and resets is
> **new here**. The hardware team must ratify or replace it (§12 lists the open
> questions) before this driver is used on silicon.
>
> Machine-readable form: [`kernel/sfg1_hw.h`](../kernel/sfg1_hw.h) (driver) and
> [`rtl/sfg1_pkg.sv`](../rtl/sfg1_pkg.sv) (RTL). `tests/check_contract.sh` fails if any
> shared constant differs (58 constants today).

## 1. Model

SF-G1 is a PCIe endpoint with one BAR0 (≥ 4 KiB MMIO) and one interrupt (MSI-X
preferred, then MSI, then INTx). The host talks to it through:

* **BAR0 registers** (§3) — configuration, doorbells, status, reset;
* a **submission queue (SQ)** in host memory — 64-byte command entries written by
  the host, fetched by the device;
* a **completion queue (CQ)** in host memory — 16-byte entries written by the device;
* **device-local memory** (SRAM/DRAM on the card), statically partitioned into one
  **window per hardware context** (§9).

The device executes commands **strictly in order, one at a time** (v1). There is one
queue pair per function.

## 2. Discovery sequence (what the driver does, in this order)

1. Map BAR0; require `len ≥ 0x1000` and an MMIO resource.
2. Read `ID`; all-ones → device absent/dead; `≠ 0x53464001` → reject.
3. Read `HW_VERSION`; require **major == 1** (minor/patch are informational).
4. Wait for `STATUS.READY` (1 s).
5. Read `CAPS`; require `ENGINE_RESET`, `FUNC_RESET`, `SCRUB` (mandatory);
   `VEC`/`TEN` gate those opcodes.
6. Read and **range-check** every limit before trusting it:
   `MAX_CTX ∈ [1,256]`; `MAX_QUEUE_ENTRIES` power of two in `[16,4096]`;
   `DMA_ADDR_BITS ∈ [32,64]`; `CTX_WIN_KIB ≥ 1`;
   `DEVMEM ≥ MAX_CTX × window` (overflow-safe).
7. Register self-test: `SCRATCH` must hold `0xA5A5A5A5` then `0x5A5A5A5A`.
8. Only now: set the DMA mask to `DMA_ADDR_BITS`, clear PCIe Relaxed-Ordering and
   No-Snoop enables (rule R3), enable bus mastering, allocate queues, request the
   interrupt, program the queue registers, set `CTRL.ENABLE`.

## 3. BAR0 register map

32-bit, little-endian, naturally aligned accesses only. 64-bit values are LO/HI pairs.
Offsets are bytes.

| Off | Name | Acc | Description |
|---|---|---|---|
| 0x000 | `ID` | RO | `0x53464001` ("SF", 0x4001) |
| 0x004 | `HW_VERSION` | RO | `[31:16]` major, `[15:8]` minor, `[7:0]` patch |
| 0x008 | `CAPS` | RO | b0 ENGINE_RESET, b1 FUNC_RESET, b2 SCRUB (mandatory); b3 VEC, b4 TEN |
| 0x00C | `LIMITS0` | RO | `[15:0]` MAX_CTX, `[31:16]` MAX_QUEUE_ENTRIES |
| 0x010 | `LIMITS1` | RO | `[7:0]` DMA_ADDR_BITS, `[31:16]` CTX_WIN_KIB |
| 0x014/18 | `DEVMEM_LO/HI` | RO | total device-local memory, bytes |
| 0x020 | `CTRL` | RW | b0 ENABLE; b1 ENGINE_RESET (W1S, self-clearing); b2 CLEAR_HALT (W1S, self-clearing) |
| 0x024 | `STATUS` | RO | b0 READY, b1 BUSY, b2 HALTED, b3 FATAL, b4 RESET_ACTIVE, `[15:8]` LAST_ERR |
| 0x028 | `RESET` | WO | write `0x52455345` ("RESE") → FUNCTION reset; other values ignored |
| 0x030 | `IRQ_STATUS` | RW1C | b0 CQ, b1 ERROR, b2 FATAL |
| 0x034 | `IRQ_MASK` | RW | 1 = enabled |
| 0x040/44 | `SQ_BASE_LO/HI` | RW* | bus address of SQ; *only while ENABLE=0* |
| 0x048 | `SQ_ENTRIES` | RW* | power of two, 16 … MAX_QUEUE_ENTRIES |
| 0x04C | `SQ_TAIL` | RW | **doorbell**: host producer index |
| 0x050/54 | `CQ_BASE_LO/HI` | RW* | bus address of CQ |
| 0x058 | `CQ_ENTRIES` | RW* | power of two, **≥ SQ_ENTRIES**, ≤ MAX_QUEUE_ENTRIES |
| 0x05C | `CQ_HEAD` | RW | **doorbell**: host consumer index (returns credit) |
| 0x060 | `SQ_HEAD` | RO | device consumer index (diagnostics) |
| 0x064 | `CQ_TAIL` | RO | device producer index (diagnostics) |
| 0x068 / 0x06C | `DONE_COUNT` / `ERR_COUNT` | RO | commands retired / failed (wrap) |
| 0x070 | `HEARTBEAT` | RO | free-running while ENABLE |
| 0x07C | `SCRATCH` | RW | no side effects |

The first slots (`ID`, `CTRL`, tail/head, `STATUS`, counters, `SCRATCH`) follow the p40
stand-in's CSR vocabulary, re-based to byte offsets and widened.

## 4. Queue entry formats

### 4.1 SQ entry — 64 bytes, written by the host (`struct sfg1_sq_entry`)

| Byte | Field | Notes |
|---|---|---|
| 0 | `opcode` u16 | §8 |
| 2 | `ctx_id` u16 | hardware context; selects the device-memory window |
| 4 | `cid` u16 | command id; the reference driver sets **cid = SQ slot index** |
| 6 | `flags` u16 | b0 = TEN accumulate |
| 8 | `exec_op` u32 | VEC sub-op |
| 12 | `rsvd0` u32 | **must be 0** |
| 16 | `host_addr` u64 | bus/IOVA; DMA opcodes only |
| 24 | `len` u64 | DMA: bytes; VEC: 32-bit words; TEN: tiles |
| 32 / 40 / 48 | `dev_a` / `dev_b` / `dev_c` u64 | **window-relative** byte offsets |
| 56 | `rsvd1` u64 | **must be 0** |

Fields an opcode does not use must be zero. Non-zero reserved fields complete with
`BAD_ARGS`.

### 4.2 CQ entry — 16 bytes, written by the device (`struct sfg1_cq_entry`)

| Byte | Field | Notes |
|---|---|---|
| 0 | `result` u32 | op-specific; 0 in v1 |
| 4 | `rsvd` u32 | |
| 8 | `sq_head` u16 | SQ consumer index after this command (frees the slot) |
| 10 | `ctx_id` u16 | echoed |
| 12 | `cid` u16 | echoed |
| 14 | `status_phase` u16 | **last field made visible.** b0 = phase tag, b15:1 = status |

Phase tag: the device writes **1** on the first lap of the CQ and toggles at every wrap.
The host zeroes the CQ whenever the device is (re)started.

## 5. Memory-ordering rules (normative)

These are the rules the driver (`kernel/sfg1_ring.c`, `sfg1_irq.c`) is written against and
the reference RTL (`rtl/sfg1_host_frontend.sv`) implements. They assume PCIe: posted writes
(including MSI/MSI-X, which are posted writes) are delivered in order **unless** the
Relaxed-Ordering or ID-based-Ordering attribute is set.

| # | Rule |
|---|---|
| **R1** | The host fills SQ entries with ordinary stores to coherent DMA memory, then publishes them with an MMIO write to `SQ_TAIL`. The device reads only entries in `[SQ_HEAD, SQ_TAIL)`. Driver: `dma_wmb(); writel()` (`writel()` already orders prior coherent stores; the explicit barrier removes the dependency on that). |
| **R2** | A published SQ slot is not modified until its CQE has been consumed (the CQE's `sq_head` frees it). |
| **R3** | For each command the device issues four posted writes to the CQ slot in this order: dw0, dw1, dw2, then **dw3 = {status_phase, cid}** (last). Only after dw3 has been issued may it set `IRQ_STATUS` and emit the interrupt message. The device **must not** use Relaxed Ordering or No-Snoop for SQ reads, CQ writes or interrupt messages. The driver clears the PCIe `RELAX_EN` and `NOSNOOP_EN` bits at probe so this does not depend on firmware. |
| **R4** | Host consumption: `READ_ONCE(status_phase)`; if the phase ≠ expected, stop; else `dma_rmb()`; then read the rest of the entry. (Payload reads must not be reordered before the phase read.) |
| **R5** | The host returns credit with a write to `CQ_HEAD` after consuming. The device must never overwrite an unconsumed CQE; if posting would make `CQ_TAIL+1 == CQ_HEAD` it must stop and raise `FATAL` instead. (CQ ≥ SQ and host occupancy ≤ SQ−1 make this unreachable for a conforming host.) |
| **R6** | Interrupts are level-derived: a message is sent when `(IRQ_STATUS & IRQ_MASK)` goes 0→non-zero, **and again** when a W1C or mask write leaves it non-zero. Host: read `IRQ_STATUS`, **write-1-clear exactly the bits read, then drain the CQ until empty** (acknowledge-then-drain). A CQE that lands after the ack sets the bit again and sends a new message, so no wake-up is lost; the reverse order (drain, then ack) would lose completions that land between the two. |
| **R7** | On a failing command the device writes the error CQE (normal R3 order), sets `STATUS.HALTED`, `LAST_ERR`, `IRQ_ERROR`, and **stops fetching**. `SQ_HEAD` has advanced past the failing command. `HALTED` is cleared only by `CTRL.CLEAR_HALT` or a reset (it survives `ENABLE` toggles). |
| **R8** | Execution and completion are strictly in SQ order (v1). Therefore, when the host sees a CQE for slot *n*, every earlier slot has completed. |
| **R9** | `SQ/CQ` base and size registers are sampled on `ENABLE` 0→1 and are frozen while `ENABLE=1`. On 0→1 the device sets `SQ_HEAD=SQ_TAIL=CQ_TAIL=CQ_HEAD=0` and phase=1. Invalid configuration (non-power-of-two, `CQ < SQ`, over limit) → `STATUS.FATAL` + `IRQ_FATAL`, not enabled. |

## 6. Resets

| | ENGINE_RESET (`CTRL` b1) | FUNCTION reset (`RESET` ← magic) |
|---|---|---|
| Aborts running/queued commands | yes — **no CQE** is written for an aborted command | yes |
| Queue indexes, phase, `IRQ_STATUS`, `HALTED`, `LAST_ERR` | cleared | cleared |
| `ENABLE` | cleared | cleared |
| Queue base/size, `IRQ_MASK`, counters, `FATAL` | retained | **cleared** |
| **Device-local memory** | **retained** (the aborted command's destination bytes are undefined) | **undefined** (the mock fills it with `0xDD`) |
| Completion | `STATUS.RESET_ACTIVE` until done, then `READY` | same |

The driver's recovery policy built on this is in [`01-design.md` §6](01-design.md).
`FUNCTION reset` is a *device* reset through the vendor register; it must **not** clear PCI
configuration space (if the real mechanism is an FLR the PCI glue needs
`pci_save_state/restore_state` and MSI-X re-enable — a bring-up item).

## 7. DMA addressing and memory safety

* The device performs host DMA only to bus addresses that appear in an SQ entry
  (`host_addr`, covering `[host_addr, host_addr+len)`), plus its own SQ reads and CQ/MSI
  writes. It performs **no address arithmetic on host addresses** beyond `+len`.
* Host buffers are **bus-contiguous** (no scatter-gather in v1). The driver allocates
  them with `dma_alloc_wc`, bounds their size, and never lets userspace choose an address.
* There is **no PASID/ATS**: all contexts share one PCI function. Isolation of *host*
  memory between processes is therefore enforced by the driver's validation and by the
  device honouring descriptor addresses — not by per-process hardware translation (see
  [`04-security.md`](04-security.md)). With an IOMMU the function can only reach what the
  driver mapped for it.

## 8. Commands

| Opcode | Name | Fields used | Semantics |
|---|---|---|---|
| 0 | `NOP` | — | completes OK |
| 1 | `DMA_H2D` | `host_addr, len, dev_a` | host → window; `len` bytes, 4-byte aligned |
| 2 | `VEC` | `exec_op, len, dev_a, dev_b, dev_c` | INT8×4 SIMD on 32-bit words (below) |
| 3 | `TEN` | `flags, len, dev_a, dev_b, dev_c` | 4×4 INT8 matmul tiles → INT32 |
| 4 | *reserved* | | (p40 `IRQ` opcode) |
| 5 | `DMA_D2H` | `host_addr, len, dev_a` | window → host |
| 6 | `SCRUB` | — | zero the entire window of `ctx_id`; **kernel only** |

**VEC** (semantics lifted from the p40 vector cluster). A word holds four signed INT8
lanes, lane *k* = byte *k*. `len` = words. A, B, C at `dev_a/b/c`:
`0 ADD8, 1 SUB8, 2 MAX8 (signed), 3 RELU8 (unary on A, `dev_b` must be 0), 4 XOR32, 5 AND32,
6 MUL8 (low byte of each lane product), 7 DOT8` → `C[0]` = Σ lane products as one INT32.
In-place use (C aliasing A or B) is element-wise safe; partial overlap yields undefined
*values* but stays inside the context's window.

**TEN.** Per tile *t*: A = 16 B (INT8 4×4, row-major) at `dev_a+16t`; B = 16 B (row-major)
at `dev_b+16t`; C = 64 B (INT32 4×4, row-major) at `dev_c+64t`. `C = A·B`, or `C += A·B`
when `flags.ACC` (INT32 wrap-around). (The p40 stand-in stores B column-major; the
row-major layout here is a deliberate API simplification.)

**Bounds.** All offsets/lengths are validated **in the kernel and again by the device**:
`len ≤ window`, `off ≤ window − len`, 4-byte alignment; products such as `len×4`,
`len×16`, `len×64` are checked for overflow. Device-side violations complete with `BOUNDS`.

## 9. Device-local memory windows

`window_size = CTX_WIN_KIB × 1024`; context *c* owns `[c·window_size, (c+1)·window_size)`.
The device derives the base from `ctx_id` and enforces the bound; there is no per-context
base register to program, so windows cannot overlap. Because the next owner of a slot must
not see the previous owner's data, the driver **scrubs** a window (`OP_SCRUB`) before
handing the slot to a new process and again at close; a slot whose scrub cannot be
confirmed is quarantined.

## 10. Completion status codes (CQE `status_phase >> 1`)

| 0 | OK | 1 | BAD_OPCODE | 2 | BAD_CTX (`ctx_id ≥ MAX_CTX`, or unbound) |
|---|---|---|---|---|---|
| 3 | ENGINE_DISABLED | 4 | BOUNDS | 5 | FETCH_ERROR |
| 6 | DMA_ERROR | 7 | BAD_ARGS | | |

(Numbers 1–6 follow the p40 error codes; 7 is new.) Userspace sees the raw value as
`dev_error`.

## 11. What implements this

| | Implements | Does **not** model |
|---|---|---|
| `kernel/sfg1_*.c` | the host side of every rule above | — |
| `kernel/sfg1_mock.c` | the full register file, queues, in-order engine with real VEC/TEN/DMA arithmetic, interrupts via `irq_sim`, both resets, fault injection, a DMA ownership audit | real PCIe, IOMMU, timing, power, hardware errata |
| `rtl/sfg1_host_frontend.sv` | CSR file, SQ fetch, CQE write-back (R3), interrupt generation (R6), halt (R7), queue enable (R9), both resets, CQ overflow (R5) | DMA/VEC/TEN execution, device windows (behind `eng_*`), anything about synthesis/timing |

## 12. Open questions for the hardware team

1. PCI vendor/device IDs (none are assigned; the driver contains none).
2. Is FUNCTION reset the vendor `RESET` register or a PCIe FLR? Does it preserve PCI config space and MSI-X state?
3. Does `ENGINE_RESET` really retain device memory? How long does each reset take (sets `reset_timeout_ms`)?
4. Worst-case latency of one command (sets the no-progress `job_timeout_ms`; the default 2 s is a placeholder).
5. Is strict in-order *posted-write* delivery guaranteed end to end (root complex, switches, any CXL/NTB hop)? Is ID-based ordering ever enabled?
6. Interrupt vectors: one (as assumed) or per-queue? Does MSI-X masking behave as R6 assumes?
7. DMA address width and IOMMU/ATS/PASID plans; whether PASID could provide per-process host-memory isolation in a later revision.
8. Scatter-gather: v1 requires bus-contiguous buffers. Is a page-list/SG descriptor planned?
9. Multiple queues / hardware contexts running concurrently (the driver assumes one in-order queue).
10. Exact INT32/INT8 overflow, rounding and lane-ordering behaviour of VEC/TEN against the real datapath (the mock follows p40 prose and RTL).
11. Error injection / debug features the bring-up team wants exposed.

## 13. Versioning

`HW_VERSION.major` changes break the contract; the driver refuses unknown majors. Minor
and patch are informational. New optional features are announced in `CAPS`.
