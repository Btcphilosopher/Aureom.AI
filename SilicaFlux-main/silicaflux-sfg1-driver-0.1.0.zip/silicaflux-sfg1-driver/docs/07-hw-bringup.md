# 07 — Hardware bring-up: where privileged integration is explicit

Nothing here has been done against hardware. This is the list of steps, **each of which
needs root, a physical card, or information only the hardware team has**, in the order they
should be taken. Do not skip the early ones: a driver that binds the wrong device with bus
mastering enabled can corrupt memory.

## 0. Before touching a card
* [ ] Obtain the **ratified** hardware spec; reconcile it with `docs/02-hw-interface.md` and
      `kernel/sfg1_hw.h` / `rtl/sfg1_pkg.sv`. Run `tests/check_contract.sh`.
* [ ] Obtain the PCI vendor/device IDs. **Do not invent any.**
      Build: `make module SFG1_PCI_VENDOR_ID=0x.... SFG1_PCI_DEVICE_ID=0x....`
      or bind explicitly: `echo "<vid> <did>" > /sys/bus/pci/drivers/sfg1/new_id`.
* [ ] Decide FUNCTION reset: vendor `RESET` register vs PCIe FLR; if the vendor register can
      clear PCI config space or MSI-X, add `pci_save_state()/pci_restore_state()` and MSI-X
      re-enable to the recovery path (`sfg1_reset.c`).
* [ ] Use a **debug kernel** (KASAN, lockdep, kmemleak, `CONFIG_DMA_API_DEBUG`) and a
      machine with an **IOMMU enabled, not in passthrough**, on a non-production host.

## 1. Privileged steps (root)
| Step | Command / action | Why privileged |
|---|---|---|
| Build for the exact running kernel (6.18.y) | `make module KDIR=/lib/modules/$(uname -r)/build` (`MOCK` **unset**) | needs headers; module signing if Secure Boot |
| Load | `insmod kernel/sfg1.ko` (add `queue_entries=`, `job_timeout_ms=` etc. as needed) | module load |
| Bind | automatic with an ID table, else `new_id` | PCI sysfs write |
| Device node policy | install the udev rule below | `/dev/accel/accelN` permissions |
| IOMMU group check | `ls /sys/kernel/iommu_groups/*/devices` — the function must be alone in its group or the group's members must be trusted | isolation depends on it |
| Disable the mock | `CONFIG_DRM_ACCEL_SFG1_MOCK=n` (or never pass `mock_devices`) | the mock bypasses all hardware |

```
# /etc/udev/rules.d/70-sfg1.rules  — adjust the group to your site policy
SUBSYSTEM=="accel", KERNEL=="accel*", GROUP="sfg1", MODE="0660"
```

## 2. First contact (read-only, then enable)
1. Confirm `lspci -vv` shows BAR0 ≥ 4 KiB and MSI-X; note the vector count.
2. The driver identifies the device (`ID`, `HW_VERSION`, `CAPS`, limits, `SCRATCH` self-test —
   see 02 §2) **before** it sets the DMA mask or calls `pci_set_master()`, and logs what it
   found with `dev_info`. For first contact, make `sfg1_pci_probe()` return `-ENODEV`
   right after `sfg1_hw_discover()` (one-line local patch), load, and check the logged values
   against the spec. Only remove the early return once they match.
3. Verify `PCI_EXP_DEVCTL` `RELAX_EN`/`NOSNOOP_EN` read back as cleared after probe
   (`setpci`/`lspci -vv`). If the platform re-enables them, the ordering rules R3/R4 are void.
4. `echo 'file sfg1_* +p' > /sys/kernel/debug/dynamic_debug/control` for tracing.

## 3. Things only hardware can confirm (record the result for each)
- [ ] CQE visibility order under real PCIe (R3) — run `ex2/ex3` and the stress test for hours
      with a PCIe protocol analyser or at least `DMA_API_DEBUG` and repeated phase-bit checks.
- [ ] Interrupt behaviour matches R6 (message re-fire after W1C leaves a cause pending).
- [ ] `ENGINE_RESET`: really retains device memory? duration? Sets `reset_timeout_ms`.
- [ ] Worst-case command latency → set `job_timeout_ms` (default 2000 ms is a placeholder).
- [ ] Hardware re-checks window bounds and descriptor reserved fields (negative tests with a
      patched driver that emits bad descriptors — **only on an isolated test host**).
- [ ] Hot-unplug (`echo 1 > /sys/bus/pci/devices/<bdf>/remove`) and surprise removal while
      jobs are in flight; module unload; repeated.
- [ ] Behaviour with the IOMMU in strict mode, and with passthrough (document the difference).
- [ ] Power-state transitions (the driver has no PM support; confirm the platform does not
      suspend the device while open).
- [ ] Re-run `tests/run-qemu.sh` on the target kernel *and* the C test logic against hardware
      (the test harness' mock-specific debugfs knobs will not exist; port the functional tests).

## 4. Rollback
`rmmod sfg1` (refuses while any fd is open). If the device wedges: `echo 1 > /sys/bus/pci/devices/<bdf>/reset`
(FLR if the device supports it), then reload. Keep the card out of production until §3 is complete.
