# 01 — Design: target kernel, interface choice, architecture

Status: **draft v0.1** — written *before* the implementation, then kept in sync with it.

> **Read this first.** There is no SF-G1 hardware specification in the source
> repository this work was done against (`btcphilosopher/aureom.ai`). The nearest
> artefact is the *stand-in* RTL in `silicaflux-p40-floorplanbuild.zip`
> (`rtl/standin/sf_control_core.sv`, `sf_host_if.sv`), which has a 16-bit address
> fabric, a private on-die command RAM and no host-memory DMA, PCIe, MSI-X or
> completion queue. The host/device contract in
> [`02-hw-interface.md`](02-hw-interface.md) is therefore **authored here as a
> proposal**. It reuses p40 vocabulary (chip ID `0x53464001`, opcode numbering,
> error codes, VEC/TEN op semantics) but it is *not* an existing specification, and
> the real SF-G1 silicon team must ratify or replace it before this driver
> touches hardware. See [`06-limitations.md`](06-limitations.md).

## 1. Target kernel

| Item | Decision |
|---|---|
| Target | **Linux 6.18 LTS** (`v6.18` and 6.18.y stable) |
| Why | Current long-term-support series at the time of writing; also the kernel this development host runs. All kernel APIs below were checked against the `v6.18` source tree, not recalled from memory. |
| Compiled against | `v6.18` (commit `7d0a66e4bb90…`), x86_64, `W=1`, with lockdep / `DEBUG_ATOMIC_SLEEP` / KASAN enabled in the test kernel |
| Older kernels | **Not supported.** The code uses `struct drm_sched_init_args`, `drm_sched_backend_ops.cancel_job` and other recent DRM APIs as they exist in 6.18 (which release introduced each was not checked — the verification tree is a shallow clone). `kernel/sfg1_drv.h` has a compile-time `#error` for `< 6.18`. |
| Newer kernels | **Not verified.** DRM scheduler and GEM APIs move quickly; expect small porting work on 6.19/7.x. No claim is made. |

## 2. Interface choice: DRM compute-accelerator subsystem

The driver registers as a **DRM accel driver** (`DRIVER_COMPUTE_ACCEL | DRIVER_GEM`),
exposing `/dev/accel/accelN`, in the style of `drivers/accel/{ivpu,qaic,rocket,amdxdna}`.

### Why this fits SF-G1

The requested feature list (command submission, completion, interrupts, process
contexts, resource accounting, timeout/reset recovery, safe removal, per-process
buffer isolation) maps almost one-to-one to infrastructure that DRM already provides
and that upstream reviewers expect:

| Need | DRM accel provides | Alternative cost |
|---|---|---|
| Process context | `struct drm_file` per `open()`, `driver->open/postclose` | hand-rolled `struct file` bookkeeping |
| Buffer ownership / isolation | GEM handles are **per-`drm_file`**; mmap offsets are per-file (`drm_vma_node_allow`) | re-implement handle tables and mmap authorisation |
| Job scheduling, fairness | `drm_sched` (one entity per context, round-robin) | hand-rolled run-queues |
| Timeout / hang detection | `drm_sched` TDR (`timedout_job`, `drm_sched_fault`) | hand-rolled delayed work |
| Completion | `dma_fence` (hardware fence) | hand-rolled waitqueues |
| Safe removal | `drm_dev_unplug()` / `drm_dev_enter()` SRCU, user-mmap revocation | easy to get wrong |
| Accounting UI | `drm_driver.show_fdinfo` (`/proc/<pid>/fdinfo`) | custom procfs |
| ioctl dispatch / versioning | `drm_ioctl_desc`, size-versioned `DRM_IOWR` | custom |

### Alternatives considered and rejected

* **Custom `misc`/char device + ioctls** — would re-implement all of the above.
  Not upstream-acceptable for a new compute accelerator.
* **DRM *render* node (GPU style)** — carries display/KMS/legacy baggage and is
  documented as the wrong home for non-graphics compute; accel exists for this.
* **VFIO / UIO (user-space driver)** — gives applications direct device access.
  With an IOMMU that is *contained*, but it is the opposite of the requirement
  ("do not expose arbitrary register access or unrestricted DMA to applications").
* **RDMA / io_uring / uAPI-less sysfs** — wrong abstraction for buffer + job semantics.

### Accel-specific hazards found while reading the 6.18 source (and how they are handled)

1. **`PRIME_HANDLE_TO_FD` is `DRM_RENDER_ALLOW`** and `drm_ioctl_permit()` only
   restricts *render* clients, so an unprivileged accel client could export a BO as a
   dma-buf and pass it to another process. → The driver sets
   `gem_object_funcs.export` and `drm_driver.gem_prime_import` to return `-EPERM`.
   `GEM_FLINK/GEM_OPEN` are `DRM_AUTH`, which on accel nodes means
   `file->authenticated` (true only for `CAP_SYS_ADMIN`); as defence in depth the
   submit path *also* checks BO ownership itself (§5), so even a privileged
   cross-file handle cannot be used by a non-owner.
2. **`drm_sched_fini()` leaves entities of still-open files pointing at freed
   run-queues** (the kernel source documents this as a known race). → The scheduler is
   initialised under a `drmm` action so it is finalised only when the `drm_device`
   itself is released, i.e. after every `drm_file` (and entity) is gone. Hardware
   teardown at unplug is *separate* from scheduler lifetime.
3. **`drm_sched_resubmit_jobs()` is deprecated** and re-running `run_job()` is
   documented as violating dma_fence rules. → After a device reset the driver does
   **not** replay in-flight jobs; they are completed with `SFG1_JOB_CANCELED` (innocent)
   or `SFG1_JOB_TIMEOUT`/`SFG1_JOB_ERROR` (guilty). Replaying is unsafe in general
   because commands are not idempotent (e.g. TEN accumulate).
4. **`drm_gem_dma_helper` frees coherent memory in the GEM release path**, which can
   run *after* a PCI hot-unplug when the device's IOMMU/DMA state may be stale. →
   The driver owns BO DMA memory itself and frees it at unplug while the device is
   still valid; only the small software object outlives the hardware.

## 3. Architecture

```
 userspace  ── /dev/accel/accelN ──▶ DRM accel core (drm_file per open)
                                        │ ioctls: GET_PARAM BO_CREATE SUBMIT WAIT_JOB GET_STATS (+GEM_CLOSE)
 ┌──────────────────────────────────────▼───────────────────────────────────────┐
 │ sfg1 driver (kernel/)                                                         │
 │  sfg1_main.c  drm_driver, open/postclose, ioctl table, fdinfo, device init/fini│
 │  sfg1_hw.c    discovery (range-checked), queue memory, start/quiesce, resets   │
 │  sfg1_ctx.c   per-open context: HW ctx slot, quotas, stats, result table      │
 │  sfg1_gem.c   driver-owned DMA BOs, per-ctx ownership, prime blocked          │
 │  sfg1_job.c   SUBMIT validation → HW descriptors; drm_sched ops; WAIT_JOB     │
 │  sfg1_ring.c  SQ/CQ rings, doorbells, phase-bit reaping, memory ordering      │
 │  sfg1_irq.c   top-half ack, threaded drain                                    │
 │  sfg1_reset.c timeout/fault recovery, ENGINE/FUNCTION reset, dead state       │
 │  sfg1_pci.c   PCI glue: discovery, BAR0, MSI-X/MSI/INTx, remove/shutdown      │
 │  sfg1_mock.c  software SF-G1 (platform device + irq_sim) — test only          │
 └──────────────┬─────────────────────────────────────────────┬─────────────────┘
        backend ops (rd32/wr32, optional dma-region audit)      │
        PCI: readl/writel on BAR0                                │ mock: register model + worker
 ┌──────────────▼─────────────────────────────────────────────▼─────────────────┐
 │ SF-G1 device (SystemVerilog): BAR0 CSRs, SQ fetch DMA, CQE writeback,          │
 │ per-context device-memory windows, DMA / VEC / TEN engines   (rtl/ = host IF)   │
 └────────────────────────────────────────────────────────────────────────────────┘
```

### Backend abstraction

All register access goes through `struct sfg1_backend_ops { rd32, wr32, … }`. PCI
uses `readl/writel`; the mock implements the register file in software. The indirect
call is negligible next to an MMIO transaction and is what lets the *whole* driver
(rings, scheduler, reset, unplug) run unmodified against the mock.

### Data path

1. `BO_CREATE` allocates a **DMA-contiguous write-combined buffer** (`dma_alloc_wc`),
   returns a per-file GEM handle and an mmap offset. Contiguity is a hardware-contract
   decision (no device scatter-gather in v1) and bounds BO size (`max_bo_size`).
2. `SUBMIT` takes an array of typed commands. **Userspace never supplies an address.**
   It supplies *(handle, offset, length)* and *device-window offsets*. The kernel
   resolves the handle in the caller's own file, checks ownership and every range with
   overflow-safe arithmetic, then writes the hardware descriptors itself.
3. One drm_sched job = up to 64 commands. Credits = number of SQ slots, so `run_job`
   can never overflow the ring.
4. The device executes strictly in order, writes a 16-byte completion entry (phase-bit
   protocol), then raises an interrupt. The threaded handler drains the CQ, retires
   commands, signals hardware fences. `WAIT_JOB` reports the per-job result.
5. A hang (no CQE progress within `job_timeout_ms`) or a device error CQE routes into
   a single recovery path (§6).

### Process contexts

`open()` allocates a context: a **hardware context ID** (indexing a fixed per-context
*device-memory window*), a `drm_sched_entity`, quotas, counters and a result table.
Device memory is statically partitioned (`window = ctx_id × window_size`), so windows
can never overlap; before a window is handed to a new owner it is **scrubbed**
(zeroed by the device) and it is scrubbed again at close. The scrub's outcome is **attributed**, because a reset caused by *another* context's hang
cancels every job on the device, including an innocent scrub. The verdict is read from the
scrub job's own recorded result (not from the scheduler's fence error, which is `-ECANCELED`
for every victim):

| Scrub outcome | Meaning | Action |
|---|---|---|
| `OK` | window zeroed | proceed |
| cancelled / never ran | a reset or fault caused by something else | back off and retry (up to 6 attempts); if it never completes, release the slot **marked "needs scrub"** and return `-EAGAIN` |
| the scrub command itself timed out or errored, **twice** | the device cannot (currently) scrub this window | **withhold the slot for a cooldown** (`quarantine_ms`, default 10 s); `open()` → `-EIO` |
| device dead/removed | moot | `-ENODEV`; slot marked "needs scrub" |

**The safety property does not depend on the cooldown.** A window is handed to a new owner
only after a scrub has succeeded since the previous owner, and that is guaranteed by the
per-slot `needs_scrub` flag alone. The cooldown only limits how often a *broken* scrub is
retried (every failed scrub resets the engine for everyone). A withheld slot is visible as
`sfg1-quarantined-windows` in `/proc/<pid>/fdinfo` and comes back automatically — rescrubbed
first. (Verification showed that treating *any* scrub failure as permanent loses slots
under fault injection — `05-testing.md`, defects 2 and 7.)

### Resource accounting

Per context: BO count, BO bytes (+peak), in-flight jobs, unreaped results, commands,
job outcome counters, device-busy nanoseconds. Per device: total BO bytes. All limits
are module parameters with conservative defaults; exceeding one returns `-ENOSPC`/
`-EBUSY` *before* any resource is committed. Exposed via `GET_STATS` and
`/proc/<pid>/fdinfo/<fd>`. (DMA-contiguous memory is **not** memcg-charged — see limitations.)

## 4. Memory ordering (summary; normative text in 02-hw-interface.md §5)

| Step | Rule used by the driver |
|---|---|
| Publish SQ entries | plain stores to coherent DMA memory, then `writel(SQ_TAIL)` (doorbell). `writel()` orders prior coherent-memory stores before the MMIO write; the driver additionally issues `dma_wmb()` so the rule does not depend on that implicit barrier. |
| Detect completion | CQ entries carry a **phase bit** in the *last-written* field. Driver: `READ_ONCE(status_phase)` → compare phase → `dma_rmb()` → read remaining fields. |
| Return CQ credit | `writel(CQ_HEAD)` after consuming. |
| Interrupt | **Acknowledge-then-drain:** top half W1C-acks `IRQ_STATUS`, thread drains CQ until empty. A CQE landing after the ack re-raises the interrupt, so no wake-up is lost. |
| Device side (hardware requirement) | CQ payload visible before the phase field; CQ writes visible before the interrupt message; no Relaxed-Ordering/No-Snoop on SQ reads, CQ writes or MSI-X. The PCI glue **clears the PCIe `RELAX_EN`/`NOSNOOP_EN` bits at probe** so this does not depend on firmware (compile-tested only; no hardware). |

## 5. Isolation model (summary; see 04-security.md)

* Handles are per-`drm_file`; the driver additionally stores the *owning context* in
  each BO and rejects any command whose BO is not owned by the submitting context.
* dma-buf export/import blocked; mmap authorisation is per-file.
* Descriptors are built only by the kernel; the context ID in every descriptor comes
  from the file, never from userspace.
* Device-window offsets are bounds-checked in the kernel **and** (per the hardware
  contract) by the device.
* **Not provided:** per-process hardware isolation of *host* memory. All contexts share
  one PCI function / IOMMU domain; isolation of host memory is by driver validation and
  by the device honouring the descriptor addresses it is given. A device bug or a
  malicious *device program* could reach any host page the function has mapped.

## 6. Timeout and reset recovery

One recovery path (`sfg1_reset.c`), entered from `drm_sched`'s `timedout_job`:

1. **Final reap** of the CQ. If the oldest job actually completed (lost interrupt) or
   the device made progress within the window → return `DRM_GPU_SCHED_STAT_NO_HANG`
   (no reset).
2. `drm_sched_stop()`; quiesce the IRQ thread; fence off ring access.
3. **ENGINE_RESET** (queue/engine reset; device memory retained). On failure →
   **FUNCTION reset** (device memory lost). On failure → device **DEAD**.
4. Guilty job (oldest in flight) completes `TIMEOUT`/`ERROR`; every other in-flight job
   `CANCELED`; the guilty context gets a strike (ban after `strike_limit`); after a
   function reset *all* contexts are marked **lost**.
5. Re-program rings, re-enable the device, `drm_sched_start()`.

A device-reported error CQE does not run a separate path: it records the fault and calls
`drm_sched_fault()`, which invokes the same handler immediately.

## 7. Safe removal

The order matters (`sfg1_device_remove()`):

1. **Hardware first**, under `reset_lock` (so a recovery in progress finishes first): mark the
   device `REMOVED`; quiesce it (`ENABLE=0`, wait for `BUSY=0`; skipped if reads return
   all-ones, i.e. surprise removal); stop it being a bus master (PCI: `pci_clear_master`);
   free the IRQ; signal **every in-flight hardware fence** with an error; mark every context
   `DEVICE_GONE`. Anything blocked in an ioctl (e.g. a `WAIT_JOB`, or an `open()` waiting on a
   scrub) is released immediately instead of stalling the next step.
2. `drm_dev_unplug()`: new ioctls fail with `-ENODEV`, user mmaps are revoked, and in-flight
   `drm_dev_enter()` sections (ioctls, the mmap hook) are waited for.
3. Only then free every BO's DMA memory and the queue memory — while the device (and its
   IOMMU state) is still valid and no DMA can be in flight — and install a dead backend so no
   late caller can reach freed backend state.

The `drm_device`, its scheduler and any still-open files live on harmlessly until the last
`close()`. `close()` on a removed device never touches hardware. A module cannot be unloaded
while a file is open (`drm_open` holds a module reference).

## 8. What is verified, and what is not

See [`05-testing.md`](05-testing.md). In short: compiled against real 6.18 with `W=1`;
run end-to-end (insmod → ioctls → fault injection → unbind → rmmod) in a QEMU-booted
6.18 kernel with lockdep/KASAN against the **mock** device; the host-interface RTL is
simulated. **Nothing here has run on physical SF-G1 hardware**, and a simulated device
cannot prove physical reliability or production-grade isolation.
