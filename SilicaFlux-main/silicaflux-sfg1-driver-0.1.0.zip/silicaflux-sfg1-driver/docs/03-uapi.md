# 03 — Userspace API (DRM accel, version 1.0)

Header: [`include/uapi/drm/sfg1_accel.h`](../include/uapi/drm/sfg1_accel.h)
(`GPL-2.0 WITH Linux-syscall-note OR MIT`). Device node: `/dev/accel/accelN`.
Helper (not a stable library): [`examples/sfg1_user.h`](../examples/sfg1_user.h).

## 1. Design rules

1. **No addresses from userspace.** An application never supplies a bus address, a
   register offset or a context id. It names buffers by *per-file GEM handle* and device
   memory by an *offset into its own window*. The kernel builds every hardware descriptor.
2. **One open file = one context.** The context owns a device-memory window, a scheduling
   entity, quotas and a table of job results. Handles, mmap offsets and job ids are all
   per-file.
3. **Strict, extensible structs.** Every pad/reserved field must be zero (`-EINVAL`
   otherwise); the command array carries its element size (`cmd_stride`) so a newer
   userspace is rejected (`-E2BIG`) rather than silently truncated.
4. **Versioning.** Read `DRM_SFG1_PARAM_UAPI_VERSION` (`major<<16 | minor`) first. A major
   mismatch is an ABI break; minors only add (new params, new flags, reserved fields
   becoming meaningful).

## 2. ioctls

| ioctl | Dir | Purpose |
|---|---|---|
| `DRM_IOCTL_SFG1_GET_PARAM` | RW | query version, limits, context id/window, state |
| `DRM_IOCTL_SFG1_BO_CREATE` | RW | allocate a zeroed DMA-contiguous buffer → handle + mmap offset |
| `DRM_IOCTL_SFG1_SUBMIT` | RW | queue one job (≤ `MAX_CMDS_PER_SUBMIT` commands) → job id |
| `DRM_IOCTL_SFG1_WAIT_JOB` | RW | wait for, and reap, a job → status |
| `DRM_IOCTL_SFG1_GET_STATS` | RW | per-context accounting |
| `DRM_IOCTL_GEM_CLOSE` | W | (core DRM) release a buffer handle |

`DRM_IOCTL_PRIME_*` (dma-buf export/import) is **refused with `-EPERM`**. `GEM_FLINK/OPEN`
are core ioctls that on accel nodes require `CAP_SYS_ADMIN`; even then a foreign handle is
rejected by `SUBMIT` (`-EACCES`).

## 3. Typical flow

```c
struct sfg1_dev d;           // examples/sfg1_user.h
sfg1_open("/dev/accel/accel0", &d);          // context + window
struct sfg1_bo bo;
sfg1_bo_create(&d, 4096, &bo);               // handle + mmap'd, zero-filled
/* ... fill bo.map with inputs ... */
struct drm_sfg1_cmd job[] = {
    sfg1_cmd_h2d(&bo, 0, 0,   256),          // BO[0..256)   -> window[0..256)
    sfg1_cmd_h2d(&bo, 256, 256, 256),
    sfg1_cmd_vec(DRM_SFG1_VEC_ADD8, 0, 256, 512, 64),   // 64 words
    sfg1_cmd_d2h(&bo, 512, 512, 256),        // window[512..768) -> BO[512..768)
};
int r = sfg1_run(&d, job, 4);                // submit + wait; 0 == all OK
```

See `examples/ex2_vector_add.c` (complete program) and `ex3_matmul.c`.

## 4. GET_PARAM

`value` is 64-bit. Parameters: `UAPI_VERSION`, `HW_VERSION`, `HW_CAPS`, `CTX_ID`,
`CTX_WINDOW_SIZE` (bytes), `MAX_BO_SIZE`, `MAX_BOS`, `MAX_BO_BYTES`,
`MAX_CMDS_PER_SUBMIT`, `MAX_INFLIGHT_JOBS`, `MAX_PENDING_RESULTS`, `JOB_TIMEOUT_MS`,
`CTX_STATE` (`BANNED` | `LOST` | `DEVICE_GONE` flags), `VEC_OPS` (bitmask).
Unknown parameter → `-EINVAL`.

## 5. BO_CREATE and memory

`size` is rounded up to a page; `real_size` returns the allocation. The buffer is
**zero-initialised explicitly** (never trusting the allocator) and is DMA-contiguous
write-combined memory. Map it with `mmap(NULL, real_size, …, fd, mmap_offset)`; the
offset is authorised only for the creating file (another file gets `-EACCES`).
Limits (module parameters): per-BO size, BOs per context, bytes per context, bytes per
device. A refused allocation commits nothing (`-ENOSPC`).

## 6. SUBMIT

```c
struct drm_sfg1_cmd {            // 64 bytes (DRM_SFG1_CMD_SIZE_V1)
    u32 op, flags, bo_handle, exec_op;
    u64 bo_offset, len, dev_a, dev_b, dev_c, reserved /*0*/;
};
```

| `op` | fields | notes |
|---|---|---|
| `NOP` | none | |
| `DMA_H2D`/`DMA_D2H` | `bo_handle, bo_offset, len, dev_a` | bytes, 4-byte aligned |
| `VEC` | `exec_op, len (words), dev_a/b/c` | `RELU8` needs `dev_b == 0`; `DOT8` writes one word at `dev_c` |
| `TEN` | `flags (ACC), len (tiles), dev_a/b/c` | A,B: 16 B/tile; C: 64 B/tile |

The kernel rejects the **whole batch** if any command is invalid; nothing is queued.
Checks include: unknown opcode (including the kernel-only `SCRUB`), non-zero unused or
reserved fields, 4-byte alignment, `bo_offset+len ≤ BO size`, `dev + extent ≤ window` —
all with overflow-safe arithmetic (`len*4/16/64` too) — handle lookup **in the caller's
own file**, and BO ownership.

A job is atomic from the API's viewpoint. Commands run in order; jobs of one context run
in submission order; jobs of different contexts may interleave.

## 7. WAIT_JOB

`timeout_ns` is an **absolute `CLOCK_MONOTONIC` deadline**; `0` polls. A job's result is
held until reaped (a second wait → `-ENOENT`) or the file closes. On `-ETIMEDOUT`,
`-EBUSY` (poll) or `-EINTR` the job is **not** reaped.

| `status` | Meaning | Client action |
|---|---|---|
| `OK` | every command completed | — |
| `ERROR` | the device reported `dev_error` | fix the job; repeating it earns strikes |
| `TIMEOUT` | no progress; device reset; **strike** | fix the job |
| `CANCELED` | a reset/ban/removal prevented completion; effects on device memory are undefined | re-upload inputs and resubmit (never silently replayed by the kernel) |

## 8. errno reference

| errno | Where | Meaning |
|---|---|---|
| `ENODEV` | any | device removed or dead |
| `ECANCELED` | submit, bo_create | context **banned** after `strike_limit` hangs/errors |
| `ECONNRESET` | submit, bo_create | context **lost** (device reset discarded its memory): close and reopen |
| `ENOSPC` | bo_create | a quota would be exceeded (nothing committed) |
| `EBUSY` | submit; open | too many jobs in flight / unreaped results; or no free hardware context |
| `EINVAL` | all | bad argument, range, flag, alignment, non-zero reserved |
| `E2BIG` | submit | unknown non-zero trailing bytes in a newer `cmd_stride` |
| `EFAULT` | submit | bad `cmds_ptr` |
| `ENOENT` | submit, wait | unknown handle / job id (also: another file's handle) |
| `EACCES` | submit, mmap | object not owned by this context / mmap not authorised |
| `EPERM` | prime export | cross-process sharing is not supported |
| `EAGAIN` | open | the window scrub could not be completed in time because the device was busy recovering from someone else's fault; **transient — retry** |
| `EIO` | open | the device's scrub command itself failed repeatedly; that hardware context is withheld for `quarantine_ms` (default 10 s) and rescrubbed before it is handed out again (`sfg1-quarantined-windows` in fdinfo) |

## 9. Accounting

`GET_STATS`: BO count/bytes/peak, jobs submitted/ok/error/timeout/canceled, commands,
`busy_ns` (approximate device time attributed to the context), device-wide reset counts.
`/proc/<pid>/fdinfo/<fd>` exposes `drm-engine-compute`, `drm-total-memory`,
`drm-resident-memory`, `drm-peak-memory` (names per `Documentation/gpu/drm-usage-stats.rst`)
plus `sfg1-*` keys. DMA-contiguous memory is **not** charged to the process's memcg —
the per-context and per-device quotas are the control.
