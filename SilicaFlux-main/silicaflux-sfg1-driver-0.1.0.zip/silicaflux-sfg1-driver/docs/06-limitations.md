# 06 — Limitations and claims discipline

## What a passing test run does and does not mean

A simulated device — the software **mock** (`kernel/sfg1_mock.c`) or the reference **RTL**
simulation — **does not prove physical-hardware reliability or production-grade
isolation**, and nothing in this package claims it does.

* The mock and the driver were written by the same author against the same draft
  contract. They therefore share its assumptions; a pass shows the driver is
  **self-consistent with that contract** and robust to the faults the mock can inject,
  not that the contract matches any real device.
* The mock has no real PCIe (no TLP ordering, no Relaxed Ordering, no completion
  timeouts), no IOMMU, no real interrupt controller behaviour (it uses `irq_sim`), no power
  or clock behaviour, no real DMA engine, no thermal/ECC/link errors, no hardware errata,
  and none of the timing that makes real hangs and real races.
* The RTL is a *reference model of the host-visible block*, simulated in Verilator. It
  is not synthesised, not timed, not DFT-ready, and does not contain the compute fabric.

## Status table

| Item | Status |
|---|---|
| SF-G1 hardware specification | **did not exist**; `docs/02-hw-interface.md` is an unratified proposal |
| PCI vendor/device IDs | **none assigned/invented**; table empty unless `SFG1_PCI_VENDOR_ID/DEVICE_ID` are defined or `new_id` is used |
| Driver builds against 6.18 | yes — in-tree and out-of-tree, `W=1`, 0 warnings |
| Driver core runs | yes — QEMU/TCG, KASAN+UBSAN+lockdep+kmemleak+fault injection, **mock device only** |
| **PCI glue (`sfg1_pci.c`) runs** | **no** — compiled only. Never executed: BAR mapping, MSI-X/MSI/INTx, DMA mask, `RELAX_EN/NOSNOOP_EN` clearing, shutdown, AER stub |
| Behaviour on physical SF-G1 hardware | **never run** |
| Reset behaviour on real hardware | unknown; the FLR-vs-vendor-register question is open (02 §12) |
| IOMMU enabled / passthrough / ATS | not exercised |
| Production-grade isolation | **not claimed** (see 04 §4) |
| Independent security review / fuzzing | **not done** |

## Functional limitations (v1)

* **One in-order queue**, one command at a time; no concurrency inside the device.
* **Bus-contiguous buffers** only (max BO size bounded; `dma_alloc_wc` must find contiguous memory). No scatter-gather.
* **No replay after reset**: in-flight jobs finish `CANCELED`/`TIMEOUT`/`ERROR`; userspace resubmits.
* **After a function reset every context is lost**; clients must reopen.
* **No explicit sync**: no `dma_fence` import/export, no syncobj, no implicit sync. Completion is `WAIT_JOB` only.
* **No dma-buf sharing** between processes or with other devices (deliberate, for isolation).
* **No power management**: no runtime PM, no system suspend/resume support; device state is lost across S3/S4 and the driver does not recover it.
* **AER**: the device is treated as lost (`PCI_ERS_RESULT_DISCONNECT`); no slot-reset recovery.
* **Single device per module instance model is fine, multiple devices untested** beyond `mock_devices=N` registration; module-global state is minimal but unreviewed for multi-device.
* **No NUMA awareness**, no SR-IOV, no peer-to-peer.
* **64-bit kernels only** (`depends on 64BIT`); little-endian host assumed by `__le*` use but big-endian untested.
* **Local DoS**: a user can hold all hardware contexts by opening many fds (no per-uid limit); DMA memory is not memcg-charged.
* Memory limits are module parameters read at probe; no live reconfiguration.
* `job_timeout_ms` default (2 s) is a **placeholder** until the hardware's worst-case command latency is known.

## Verification limitations

* Tests ran on x86_64 under QEMU **TCG** (no KVM): timing and race windows differ from
  bare metal; a clean run is not an absence of races.
* Chaos/stress runs are seconds long and use a fixed-seed PRNG per run; they are not
  fuzzing and not a soak test.
* The `t_alloc_failures` exercises only allocation failures **in the calling task**;
  failures in kernel threads/workers (scheduler work, IRQ thread) are not injected.
* `kmemleak` only reports unreferenced objects; it does not find "still-referenced but
  never freed" leaks (e.g. a lost refcount on an object that stays on a list).
* The contract cross-check compares names/values present in both the C header and the SV
  package; it cannot detect a semantic mismatch.
* Kernel 6.19 / 7.x were **not** tested.

## Known upstream observation (not changed here)

While reading `drm_gem_dma_helper.c` (6.18) I noticed `drm_gem_dma_mmap()` calls
`drm_gem_vm_close()` on failure while its caller `drm_gem_mmap_obj()` also drops the
mapping reference — this looks like a double drop. This driver does not use that helper
(its own mmap hook returns the error and lets the core drop once). Not verified further.
