# Evidence

Raw output of the final verification pass on the packaged sources (see `../05-testing.md`).
Paths were rewritten to `<pkg>/` and `<scratch>/`. `qemu-run-N.txt` is the filtered test
section of each QEMU run's console (kernel messages from the mock's recoveries are expected
output of the fault-injection tests, not errors).

* `final-pass-summary.txt` — builds (W=1, sparse), contract check, RTL, QEMU runs 1–4
* `qemu-runs-5-8-summary.txt` — four further consecutive runs, identical sources
* `rtl-sim-*.txt` — Verilator logs: the design and the two deliberately-wrong mutants
