# 05 — Testing: what was run, what it shows, and what it cannot show

> **Scope.** All device-facing results are against the **software mock**
> (`kernel/sfg1_mock.c`) and the **reference RTL** (`rtl/`), both written to the draft
> contract in `02-hw-interface.md`. They show the *driver* is self-consistent with that
> contract and robust to injected faults. They do **not** prove physical-hardware
> reliability or production-grade isolation ([`06-limitations.md`](06-limitations.md)).

## 1. Layers of verification

| # | Layer | Tool | Where | What it can find |
|---|---|---|---|---|
| 1 | Compile against real v6.18, in-tree and out-of-tree | gcc 13, `W=1` | `make module` | API misuse, warnings |
| 2 | Static analysis | `sparse` (`C=2`, `__CHECK_ENDIAN__`), `checkpatch --strict` | | endianness/`__le*` mistakes, lock-context, style |
| 3 | **End-to-end suite** in a booted 6.18 kernel | QEMU/TCG + KASAN, UBSAN, lockdep (`PROVE_LOCKING`), `DEBUG_ATOMIC_SLEEP`, kmemleak, `DEBUG_OBJECTS`, fault injection (`failslab`, `fail_page_alloc`) | `tests/run-qemu.sh` | functional bugs, races, UAF/OOB, lock inversions, sleeping-in-atomic, leaks, bad error paths |
| 4 | Reference RTL simulation incl. **mutation testing** | Verilator 5.020 | `rtl/run_sim.sh` | RTL bugs; proves the ordering checkers can fail |
| 5 | Contract cross-check (C header ↔ SV package), with a proven negative control | python | `tests/check_contract.sh` | constant drift between driver and RTL |

## 2. How to run

```sh
# kernel test build (installs the driver into the given 6.18 tree — use a scratch checkout)
tests/build-test-kernel.sh ~/linux-6.18 ~/kbuild-6.18
make module KSRC=~/linux-6.18 KBUILD=~/kbuild-6.18 MOCK=1
tests/run-qemu.sh ~/kbuild-6.18 kernel/sfg1.ko        # boots QEMU; fails on test failure OR any kernel splat
tests/check_contract.sh
rtl/run_sim.sh                                         # needs Verilator >= 5
```

`run-qemu.sh` treats **any** of `BUG: WARNING: KASAN: UBSAN: Oops lockdep "possible
circular/recursive locking" "suspicious RCU" "Kernel panic" "Call Trace"` in the console log
as a failure, in addition to the suite's own verdict line.

## 3. What the QEMU suite checks (`tests/sfg1_test.c`, `sfg1_test_faults.inc`)

The mock runs with deliberately tight limits (64-entry rings, 4 contexts × 1 MiB windows,
300 ms hang timeout, 64 BOs, 4 MiB BO, 8 MiB/ctx, 16 MiB total, 16 jobs in flight, 3 strikes)
so every limit has a boundary the tests can hit.

| Test | Proves |
|---|---|
| `t_discovery` | UAPI/HW version, limits, errno for bad params |
| `t_bo_basic`, `t_bo_zero_on_reuse` | BO create/mmap, page rounding, size limits, **fresh BOs are zero even when the allocator recycles poisoned pages** (24 × 1 MiB) |
| `t_dma_roundtrip`, `t_vec_ops`, `t_ten`, `t_ordering`, `t_wait_semantics` | H2D/D2H integrity incl. last bytes of the window; all 8 VEC ops (odd length) and TEN (multi-tile, accumulate) against an **independent** reference; 10 dependent jobs execute in order; WAIT poll/timeout/reap/second-wait semantics |
| `t_validation` | 38 malformed commands, 11 submit-argument cases (overflow of `off+len`, `len×4/16/64`, window end, misalignment, reserved fields, SCRUB from userspace, bad pointers), forward-compat stride (`-E2BIG` on non-zero tail, incl. in the 2nd command), **whole-batch rejection**; rejected submits create no job, leave accounting untouched, and cause **0 device-side DMA violations** |
| `t_quota` | BO count / per-ctx bytes / per-device bytes (with exact refunds on a failed charge), hardware-context exhaustion (`EBUSY`), **in-flight cap hit deterministically** (device slowed at runtime), unreaped-result cap |
| `t_oracle_selftest` | the DMA ownership audit **can fire** (negative control: +2 violations on demand) |
| `t_isolation` | two processes: foreign handles 1–39 → `ENOENT`; foreign mmap offset refused; dma-buf export `EPERM`; **root flink + `GEM_OPEN` hands process B a handle to A's buffer, yet `SUBMIT` refuses it (`EACCES`)**; A's host and device data undisturbed; after A exits the reused window reads **zeros**; 0 violations |
| `t_unprivileged` | uid 1000: flink/open → `EACCES`, prime → `EPERM`, normal use works |
| `t_stats_fdinfo`, `t_examples` | counters, `/proc/<pid>/fdinfo` fields; all five example programs exit 0 |
| `t_stress_clean` | 3 processes × 4 s, random ops, every OK job verified bit-exact, hostile garbage mixed in |
| `t_error_cqe` | each device status 1…7 reported verbatim; one engine reset per error; hardware **protocol** faults (bad cid) do **not** ban a context |
| `t_hang_timeout_ban` | hang → `TIMEOUT` after ≥ 250 ms and < 3 s; innocent queued job → `CANCELED` (not replayed); 3 strikes → `BANNED` (`ECANCELED`); bystander and new contexts unaffected |
| `t_lost_irq` | completion without an interrupt → job still `OK`, **no reset**, no strike |
| `t_func_reset` | stuck engine reset → function reset; **every** context `LOST` (`ECONNRESET`); mock fills memory with `0xDD` yet fresh contexts read zeros |
| `t_scrub_policy` | scrub attribution: a scrub that hangs **once** does not withhold the slot; a scrub caught behind **another context's** hang does not either; a scrub command that **persistently fails** withholds exactly that slot for the cooldown (`EBUSY` for the 4th context), the **planted secret never reaches a new owner**, and capacity returns afterwards (rescrubbed → zeros) |
| `t_dead_and_rebind` | both resets stuck → device `DEAD`: `ENODEV` everywhere, node gone on unbind; revived by rebind |
| `t_stress_chaos` | the stress load while the harness randomly injects lost IRQs, hangs, error statuses, protocol faults; every wait returns, no crash, device usable afterwards |
| `t_alloc_failures` | `failslab` + `fail_page_alloc` `fail-nth` loops over **every** allocation point in `open` (21–29 points across the 8 final runs), `BO_CREATE` (19–27) and `SUBMIT` (14–17): accounting exact after each injected failure |
| `t_removal_with_open_fds` | unbind with a job in flight and a thread blocked in `WAIT_JOB` (released with OK/CANCELED); `ENODEV` afterwards; mmap'd memory raises **SIGBUS**; `close()` safe; rebind works |
| `module_unload` | `rmmod` refused while a file is open; clean afterwards |
| `kmemleak_*` | **positive control**: a deliberate leak is reported (detector live) and nothing else driver-related; **0 new leaks after unload** |

## 4. Recorded results (final run on the packaged sources)

Environment: Linux **v6.18** (`tinyconfig` + `tests/kernel-test.config`: KASAN, UBSAN, lockdep,
debug-atomic-sleep, kmemleak, debug-objects, fault injection), gcc 13.3, Verilator 5.020, QEMU 8.2.2
(TCG, 4 vCPUs). Raw logs: [`evidence/`](evidence/).

| Check | Result |
|---|---|
| Out-of-tree build vs v6.18, `W=1` | **0 warnings, 0 errors** |
| `sparse` (`C=2`, `-D__CHECK_ENDIAN__`) | **0 diagnostics** |
| In-tree build (`drivers/accel/sfg1`) | success, 0 warnings |
| `checkpatch --strict` (kernel sources + UAPI) | **0 errors**; the remaining notes are style-level (one comment line of 103 columns; `LINUX_VERSION_CODE` guard is deliberate for an out-of-tree-capable build; UAPI headers correctly do not use the kernel-only `BIT()` macro) |
| C header ↔ SV package | **58** shared constants identical; negative control proven (injected mismatches fail) |
| RTL, correct design | **PASS**, 566 checks |
| RTL mutant 1 (phase dword written first) | **FAIL as required**, 136 failing checks (M1 payload-before-phase, M3 write order) |
| RTL mutant 2 (interrupt before CQE complete) | **FAIL as required**, 7 failing checks (all M2) |
| **QEMU suite, final sources, 8 consecutive runs** | **8/8 PASS** — 4,592–4,608 checks each, **0 failed, 0 kernel splats** in every run |

Test inventory: 25 test functions + 2 kmemleak phases + module unload.

The **shipped zip itself** was also unzipped into a fresh directory and built and tested
from there with the documented commands: module build `W=1` 0 warnings, contract check, RTL
simulation (as above), and a ninth consecutive QEMU run — PASS, 4,610 checks, 0 kernel splats.

**Transparency about the road to 8/8.** Before the last two fixes (defects 7 and 8 below),
**3 of the 9 runs** made during the final-verification phase failed intermittently: two runs on
a context slot being withheld after injected faults, and one run in which every check passed
but the runner's kernel-splat scan found a lockdep cycle. These were root-caused and fixed
(causally: deterministic tests for the former, removal of the offending lock edge for the
latter), not retried until green. Eight clean runs after a roughly one-in-three failure rate
is good evidence, not proof — keep running the suite (and ideally under `CONFIG_PROVE_LOCKING`
on the target kernel) as a regression gate.

## 5. Defects found by this verification (and fixed)

| # | Found by | Defect | Fix |
|---|---|---|---|
| 1 | build check | installer appended the `drivers/accel/Makefile` hook without a trailing newline, fusing it onto upstream's last line, so the driver was **silently never built** | newline-safe append + fail-loudly check |
| 2 | chaos stress | a reset that cancelled a scrub job **permanently quarantined** a context slot (`cannot scrub context window 0 (-5): quarantined`) | first fix: retry the scrub — **insufficient** (see 7) |
| 3 | RTL simulation | interrupt next-state was computed with continuous wires from blocking variables set inside the clocked process → lagged one cycle: the device **re-issued an interrupt after the host had acknowledged every cause** | compute inside the process after all causes are known |
| 4 | self-review while writing 02 | PCI glue *assumed* firmware had left PCIe Relaxed Ordering/No-Snoop off, though the ordering rules depend on it | probe clears `RELAX_EN`/`NOSNOOP_EN` |
| 5 | `sparse` | `sfg1_cfg_load` too deeply nested for the checker | restructured |
| 6 | review of my own tests | two *vacuous* checks (`… \|\| 1`) in the RTL testbench would always pass | removed; replaced by real ordering checks + mutation testing |
| 7 | the **same** symptom recurring intermittently in the final verification pass (1 of 3 runs: two slots quarantined → `open` → `EBUSY`), and again in a later run via a new assertion | root cause was the *policy*, not the retry count: a scrub failure was never attributed, so one context's hang (which cancels every job on the device, including an innocent scrub) or an injected fault condemned a slot permanently. Fixed in three parts: the verdict comes from the scrub job's **own** recorded result (fence errors are `-ECANCELED` for every reset victim, so they cannot be used); only a scrub command that itself failed twice withholds a slot; and withholding is a **cooldown**, not permanent — the safety property rests on `needs_scrub` (a window is never handed out unscrubbed), not on quarantine | `t_scrub_policy`, chaos end-assertion |
| 8 | **lockdep** ("possible circular locking dependency detected"), in 1 of 4 consecutive runs of the final pass — every functional check had passed; only the splat scan caught it | `bo_lock` was held across operations that allocate memory (the mock's `kzalloc` in `BO_CREATE`; `dma_mmap_wc` page-table allocation in the mmap hook) while `bo_lock` is also taken from `free_job`, which recovery waits for (`drm_sched_stop` → `cancel_work_sync(work_free_job)`) inside a fence-signalling section. Cycle: `bo_lock → fs_reclaim → dma_fence_map → work_free_job → bo_lock`. **Not mock-specific** (the mmap edge exists on hardware too) | audit hook now runs before `bo_lock` is taken; mmap hook no longer takes `bo_lock` (it uses `drm_dev_enter`, which unplug already synchronises with, and the mapping holds a GEM reference); the rule is now stated in `sfg1_drv.h` |

Several further failures during development were **bugs in the tests** (e.g. RELU8 given a
non-zero `dev_b`, which the driver correctly rejected; a fixed delay too short for a 100-cycle
command; `delete_module(O_NONBLOCK)` returning `EWOULDBLOCK`, not `EBUSY`); they are not
listed as driver defects.

## 6. Limits of this testing

See [`06-limitations.md`](06-limitations.md). In particular: QEMU **TCG** (no KVM), seconds-long
stress rather than a soak, no fuzzing of the ioctl surface, allocation-failure injection only
in the calling task, **PCI glue never executed**, and no physical device.
