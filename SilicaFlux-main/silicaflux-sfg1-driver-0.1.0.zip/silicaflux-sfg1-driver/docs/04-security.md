# 04 — Security model, isolation, and what is *not* claimed

This document states what the driver defends against, how, how that is tested, and — just
as important — what it does **not** provide. It is a design-level threat model, not a
security audit; no independent review has been performed.

## 1. Assets and adversaries

| | |
|---|---|
| **Assets** | (a) confidentiality/integrity of each process's host buffers; (b) confidentiality/integrity of each process's device-memory window; (c) kernel memory and the rest of the system; (d) availability of the accelerator to other processes |
| **Adversary A** | a local, *unprivileged* process with access to `/dev/accel/accelN` that sends arbitrary, malformed or hostile ioctls and commands |
| **Adversary B** | a second such process trying to read/write/steal **another process's** buffers or device memory |
| **Out of scope** | root / `CAP_SYS_ADMIN` (can already do anything); a malicious *device* or malicious device firmware; physical attacks; side channels (timing, power, contention) |

Access control to the node is the first line of defence: install the udev rule in
[`07-hw-bringup.md`](07-hw-bringup.md) (group-restricted, mode 0660), never world-accessible.

## 2. Requirement-by-requirement

### 2.1 "Do not expose arbitrary register access to applications"
There is no ioctl, mmap, sysfs or debugfs path from an application to BAR0 or to any
register offset. The UAPI has no register concept. BAR0 is mapped only by the kernel
(`pcim_iomap_region`) and is never exposed to `mmap`. *(The mock's debugfs fault-injection
files exist only when `CONFIG_DRM_ACCEL_SFG1_MOCK` is built — a test option documented as
never-for-production — and debugfs is root-only.)*

### 2.2 "Do not expose unrestricted physical-memory DMA to applications"
* Applications never provide an address. `SUBMIT` takes *(GEM handle, offset, length)*;
  the kernel resolves the handle **in the caller's own `drm_file`**, checks ownership and
  every range, then writes `bo->dma + offset` itself (`sfg1_build_cmd`).
* The **context id** in every descriptor is taken from the file, never from userspace.
* Host DMA is possible only to buffers the driver allocated and mapped for the function
  (and, with an IOMMU, only to those mappings).
* The device-memory side is bounded by the per-context window, checked in the kernel
  *and* (per the contract) by the device.

### 2.3 "Prevent one process from accessing another process's buffers"

| Attack | Defence | Tested by |
|---|---|---|
| Use another process's handle number | GEM handles are per-`drm_file`; lookup misses → `-ENOENT` | `t_isolation` (probes handles 1–39), `ex4` |
| mmap another process's buffer (guess the fake offset) | `drm_gem_mmap` → `drm_vma_node_is_allowed()` per file → `-EACCES` | `t_isolation`, `ex4` |
| Export a buffer as a dma-buf and pass the fd | `export` and `gem_prime_import` return `-EPERM` | `t_isolation`, `t_unprivileged` (own BO → `EPERM`) |
| Get a handle through GEM flink/open | needs `CAP_SYS_ADMIN` on accel nodes (unprivileged → `-EACCES`) | `t_unprivileged` |
| …as root, then submit with the foreign handle | **driver's own ownership check**: `bo->ctx != submitting ctx` → `-EACCES`, independent of the GEM layer | `t_isolation` (root flink + `GEM_OPEN`) |
| Read leftovers from freed memory | BO memory is zeroed explicitly at creation | `t_bo_zero_on_reuse`, `t_bo_basic` |
| Read a previous owner's device memory | windows are disjoint by construction; scrubbed (device-side `OP_SCRUB`) before reuse and at close; a window is handed out only after a scrub has *succeeded* since its last owner (`needs_scrub`); if the scrub command keeps failing the slot is withheld for a cooldown; after a function reset (memory undefined) every window is rescrubbed | `t_isolation` (reused slot reads zeros), `t_func_reset` (mock fills `0xDD`; new contexts still read zeros), `t_scrub_policy` (**a secret left in a window whose scrub then fails persistently is never visible to a new owner**) |
| Address another context's window | window base derives from the kernel-chosen `ctx_id`; offsets bounds-checked | `t_validation`, `t_isolation` |
| Survive in kernel memory after unplug | CPU mappings revoked (`drm_dev_unplug`), DMA memory freed while the device is valid | `t_removal_with_open_fds` (SIGBUS, no UAF under KASAN) |

**The DMA oracle.** The mock records, for every host-memory DMA the "device" performs,
whether the target lies inside a region the driver registered **and** whether that region
belongs to the context named in the command. A violation fails the command and increments
`dma_violations`. Every hostile test asserts the counter did not move, and
`t_oracle_selftest` proves the audit can fire (it performs one unmapped and one
wrong-owner DMA and requires +2).

### 2.4 Input validation (all in `sfg1_ioctl_submit` / `sfg1_build_cmd` / BO create)

* every `pad`/`reserved`/unused field must be zero; unknown flags rejected;
* `cmd_count`, `cmd_stride` (multiple of 8, ≥ 64, ≤ PAGE_SIZE), `cmds_ptr` validated;
* `copy_struct_from_user()` (rejects non-zero unknown tail → `-E2BIG`);
* `check_mul_overflow` / `check_add_overflow` on `len×4`, `len×16`, `len×64`, `off+len`;
* all device offsets `≤ window − len`; BO ranges `≤ bo->size`; alignment checks;
* `SCRUB` and every unknown opcode rejected;
* the **whole batch** is validated before anything is queued;
* quotas are charged first and refunded in one place; an allocation failure at any of the
  14–29 injected allocation points (the count varies with allocator state) in `open`/`BO_CREATE`/`SUBMIT` leaves accounting exact
  (`t_alloc_failures`).

## 3. Availability (denial of service)

| Threat | Mitigation | Residual |
|---|---|---|
| Flood the device with jobs | per-context in-flight and unreaped-result caps (`-EBUSY`); one scheduler entity per context (fair round-robin) | many contexts can still saturate the single in-order engine |
| Exhaust memory | per-BO, per-context and per-device byte caps; BO count cap | **not memcg-charged** (DMA-contiguous memory) |
| Hang the device repeatedly | no-progress timeout → engine reset → strike; **ban after `strike_limit`**; other contexts keep working | each hang costs ~`job_timeout_ms` of device time for everyone |
| Exhaust hardware contexts | `-EBUSY` when all `MAX_CTX` slots are taken | **a local user can hold all slots by opening many fds**; no per-uid limit — rely on node permissions / cgroups `devices` |
| Trigger resets to degrade others | driver validates before submit so device-detected errors indicate hardware faults or driver bugs; strikes ban the offender | a *valid* but pathological workload can't be told from a hang until it times out |

## 4. What is NOT provided (do not assume otherwise)

1. **Per-process hardware isolation of host memory.** All contexts share one PCI function
   and IOMMU domain. Isolation of host memory is by driver validation and by the device
   honouring descriptor addresses. A device-side bug, malicious firmware or a hypothetical
   user-supplied *device program* could reach any host page mapped for the function. PASID /
   per-process translation would be needed for hardware-enforced isolation; SF-G1 v1 has none.
2. **Hardware-enforced window bounds.** The kernel checks bounds; the contract requires the
   device to re-check, but that requirement is only exercised against the **mock** and the
   reference front-end — never against silicon.
3. **Protection from root**, from kernel bugs elsewhere, or from a compromised device.
4. **Side-channel resistance** of any kind.
5. **Confidential computing / encrypted device memory.** Scrubbing zeroes memory; it does
   not defend against physical remanence or a debugging interface on the card.
6. **Verified fail-safe behaviour on real hardware.** Reset, timeout, interrupt and
   removal behaviour were exercised against a *model* that follows the same assumptions as
   the driver. That cannot reveal where the assumptions are wrong.
7. **An independent review or fuzzing campaign.** The tests are the author's. syzkaller-style
   fuzzing of the ioctl surface has not been done.

## 5. Reporting and hardening checklist for a real deployment
* restrict the device node (udev, group) and, where possible, a cgroup `devices` rule;
* enable the IOMMU (`intel_iommu=on` / `amd_iommu=on`, no passthrough) so the function can
  only reach what the driver maps;
* run the test suite on the **target kernel and a debug kernel** (KASAN/lockdep) before release;
* build with `CONFIG_DRM_ACCEL_SFG1_MOCK=n`;
* do not enable `max_*` limits above what the card's memory can serve.
