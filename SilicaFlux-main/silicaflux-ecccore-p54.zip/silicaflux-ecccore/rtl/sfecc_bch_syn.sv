// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_bch_syn -- byte-parallel syndrome update
//
// Combinational next-state of the T odd syndromes S_E = r(alpha^E), E = 1,3,..,2T-1
// (even syndromes are squares: S_2i = S_i^2, formed in the KES).  Horner's rule
// on 8 stream bits at once (MSB first = highest degree):
//     S_E' = S_E * a^(8E)  +  sum_{i=0..7} d[i] * a^(E*i)
// For the last byte of a codeword whose parity ends in TPAD padding bits only the
// V = 8 - TPAD top bits are valid:
//     S_E' = S_E * a^(V*E) +  sum_{i=8-V..7} d[i] * a^(E*(i-8+V))
// Leading padding bits (LPAD) are masked to zero by the caller.  All alpha powers
// are elaboration-time constants: each update is a pure XOR network.
// Classification: SYNTHESIZABLE (combinational)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfecc_bch_syn #(
  parameter integer GF_M    = 8,
  parameter integer GF_PRIM = 'h11D,
  parameter integer T       = 4,
  parameter integer V       = 8           // valid bits of a 'partial' byte (1..8)
) (
  input  wire [T*GF_M-1:0] s_i,
  input  wire [7:0]        d_i,
  input  wire              partial_i,    // use the V-bit update
  output wire [T*GF_M-1:0] s_o
);
  `include "sfecc_gf_funcs.svh"

  // Accumulations are written as functions used in continuous assignments, not as
  // always_comb blocks that re-assign a variable: Icarus Verilog 12 treats variables written
  // inside always_comb as sensitivities and loops forever on the intermediate values.
  function automatic [GF_M-1:0] xor_red8(input [GF_M-1:0] base, input [8*GF_M-1:0] tv);
    integer n;
    reg [GF_M-1:0] a;
    begin
      a = base;
      for (n = 0; n < 8; n = n + 1) a = a ^ tv[n*GF_M +: GF_M];
      xor_red8 = a;
    end
  endfunction

  genvar j, i;
  generate
    for (j = 0; j < T; j = j + 1) begin : g_s
      localparam integer E    = 2 * j + 1;
      localparam integer C8   = sfecc_gfc_apow(8 * E);
      localparam integer CV   = sfecc_gfc_apow(V * E);
      wire [GF_M-1:0]   s = s_i[j*GF_M +: GF_M];
      wire [8*GF_M-1:0] tf, tp;               // per-bit constant terms
      wire [GF_M-1:0]   accf, accp;
      for (i = 0; i < 8; i = i + 1) begin : g_b
        localparam integer CF = sfecc_gfc_apow(E * i);
        localparam integer CP = (i >= 8 - V) ? sfecc_gfc_apow(E * (i - 8 + V)) : 0;
        assign tf[i*GF_M +: GF_M] = d_i[i] ? CF[GF_M-1:0] : {GF_M{1'b0}};
        assign tp[i*GF_M +: GF_M] = (d_i[i] && i >= 8 - V) ? CP[GF_M-1:0] : {GF_M{1'b0}};
      end
      assign accf = xor_red8(sfecc_gf_mul(s, C8[GF_M-1:0]), tf);
      assign accp = xor_red8(sfecc_gf_mul(s, CV[GF_M-1:0]), tp);
      assign s_o[j*GF_M +: GF_M] = partial_i ? accp : accf;
    end
  endgenerate
endmodule

`default_nettype wire
