// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_crc16.svh
// CRC-16/IBM-3740 ("CCITT-FALSE"): poly 0x1021, init 0xFFFF, MSB first, no
// reflection, xorout 0; check value CRC("123456789") = 0x29B1.  Byte update,
// included inside module bodies.  Same function as crc16_ccitt_false() in
// ref/sfecc_page.py.
// =============================================================================
  function automatic [15:0] sfecc_crc16_upd(input [15:0] c, input [7:0] d);
    integer i;
    reg [15:0] x;
    begin
      x = c ^ {d, 8'h00};
      for (i = 0; i < 8; i = i + 1)
        x = x[15] ? ((x << 1) ^ 16'h1021) : (x << 1);
      sfecc_crc16_upd = x;
    end
  endfunction
