// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_bch_dec -- pipelined binary BCH decoder
//
//   in (stored codeword bytes) --> [SYN] --> [KES] --> [CHIEN+CORRECT] --> out (message bytes)
//                                    |  NBANKS x CW_BYTES codeword buffer       ^      + status
//                                    +-----------------------------------------+
// SYN    byte-parallel syndromes S_1,S_3,..,S_2T-1 while the raw bytes are written
//        to a free buffer bank (erased-page MASK removed from the parity bytes on the
//        syndrome path only; the buffer keeps the raw stored bytes).
// KES    simplified inversionless Berlekamp-Massey, 2T+2 cycles (1 if clean).
// CHIEN  8-position Chien search per cycle, correction while streaming the
//        message bytes out of the buffer, success/failure/erased classification.
// The three stages overlap across codewords: codeword j+1 is received while
// codeword j is solved and corrected (NBANKS buffer banks).  Sustained input rate
// (measured, docs/07): 2 banks 0.93 B/cycle for 32-byte BCH(255,223) words and
// ~0.98 for 527-byte sectors; 3 banks ~0.97 / ~0.99 at 1.5x the buffer.
// Latency (first byte in -> first corrected byte out) = CW_BYTES + KES + ~4 cycles.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfecc_bch_dec #(
  parameter integer GF_M      = 8,
  parameter integer GF_PRIM   = 'h11D,
  parameter integer T         = 4,
  parameter integer R         = 32,
  parameter integer MSG_BYTES = 28,
  parameter integer LPAD      = 1,
  parameter [R-1:0] MASK      = {R{1'b0}},
  parameter integer NBANKS    = 2,             // codeword buffer banks (2: min area, 3: full rate on short words)
  localparam integer NW       = $clog2(T + 1)
) (
  input  wire          clk,
  input  wire          rst_n,
  input  wire          in_valid,
  output wire          in_ready,
  input  wire [7:0]    in_data,
  input  wire          in_last,
  output wire          out_valid,
  input  wire          out_ready,
  output wire [7:0]    out_data,
  output wire          out_last,
  output wire          st_valid,
  input  wire          st_ready,
  output wire [1:0]    st_code,
  output wire [NW-1:0] st_nerr,
  output wire          st_frame_err,
  output wire          busy
);
  `include "sfecc_gf_funcs.svh"

  localparam integer PAR_BYTES = (R + 7) / 8;
  localparam integer PW        = 8 * PAR_BYTES;
  localparam integer TPAD      = PW - R;
  localparam integer CW_BYTES  = MSG_BYTES + PAR_BYTES;
  localparam integer AW        = $clog2(NBANKS * CW_BYTES);
  localparam integer KW        = (NBANKS > 2) ? 2 : 1;      // bank id width
  localparam integer BW        = $clog2(CW_BYTES + 1);
  localparam integer LW        = $clog2(2 * T + 1);
  localparam integer PRIM_OK   = sfecc_gfc_prim_ok(0);

  generate
    if (PRIM_OK != 1) begin : g_bad_prim
      `SFECC_CFG_FATAL("sfecc_bch_dec: GF_PRIM is not a primitive polynomial of degree GF_M")
    end
    if (NBANKS < 2 || NBANKS > 3 || T < 2 || R < GF_M || R > GF_M * T || LPAD < 0 || LPAD > 7 || MSG_BYTES < 1 ||
        8 * MSG_BYTES - LPAD + R > GF_N) begin : g_bad_len
      `SFECC_CFG_FATAL("sfecc_bch_dec: illegal T / R / LPAD / MSG_BYTES (codeword longer than 2^m-1?)")
    end
  endgenerate

  // stored-parity mask vector (MASK then TPAD zero bits)
  function automatic [PW-1:0] mk_maskv(input [R-1:0] p);
    integer i;
    begin
      mk_maskv = {PW{1'b0}};
      for (i = 0; i < R; i = i + 1) mk_maskv[PW-1-i] = p[R-1-i];
    end
  endfunction
  localparam [PW-1:0] MASKV = mk_maskv(MASK);
  localparam [7:0]    LMASK = 8'hFF >> LPAD;      // valid bits of byte 0

  // ================================================================== SYN stage
  reg  [BW-1:0]      b;
  reg  [KW-1:0]      wbank;
  reg  [NBANKS-1:0]  bank_busy;
  reg  [T*GF_M-1:0]  syn;
  reg                ferr;                    // framing error seen in this codeword
  reg                h_valid;                 // SYN -> KES hand-off
  reg  [T*GF_M-1:0]  h_syn;
  reg  [KW:0]        h_tag;                   // {frame_err, bank}

  wire       is_last  = (b == BW'(CW_BYTES - 1));
  assign in_ready = !bank_busy[wbank] && !(is_last && h_valid);
  wire       in_fire  = in_valid && in_ready;
  wire [BW-1:0] pidx  = b - BW'(MSG_BYTES);
  wire [7:0] mbyte    = (b >= BW'(MSG_BYTES)) ? MASKV[(PW - 8) - 8 * pidx +: 8] : 8'h00;
  wire [7:0] dsyn     = ((b == '0) ? (in_data & LMASK) : in_data) ^ mbyte;
  wire [T*GF_M-1:0] syn_nx;
  sfecc_bch_syn #(.GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .V((TPAD == 0) ? 8 : 8 - TPAD)) u_syn (
    .s_i      ((b == '0) ? {T*GF_M{1'b0}} : syn),
    .d_i      (dsyn),
    .partial_i(is_last && (TPAD != 0)),
    .s_o      (syn_nx)
  );
  wire       ferr_nx  = ferr || (in_last != is_last);

  // KES side
  wire                  k_in_ready;
  wire                  k_valid, k_ready;
  wire [(T+1)*GF_M-1:0] k_lam;
  wire [LW-1:0]         k_l;
  wire [KW:0]           k_tag;
  // CHIEN side
  wire                  bank_rel;
  wire [KW-1:0]         bank_rel_id;
  wire                  ram_re;
  wire [AW-1:0]         ram_raddr;
  reg  [7:0]            ram_rdata;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      b <= '0; wbank <= '0; bank_busy <= '0; syn <= '0; ferr <= 1'b0;
      h_valid <= 1'b0; h_syn <= '0; h_tag <= '0;
    end else begin
      if (h_valid && k_in_ready) h_valid <= 1'b0;
      if (bank_rel) bank_busy[bank_rel_id] <= 1'b0;
      if (in_fire) begin
        if (is_last) begin
          h_valid          <= 1'b1;
          h_syn            <= syn_nx;
          h_tag            <= {ferr_nx, wbank};
          bank_busy[wbank] <= 1'b1;
          wbank            <= (wbank == KW'(NBANKS - 1)) ? '0 : wbank + 1'b1;
          b                <= '0;
          ferr             <= 1'b0;
          syn              <= '0;
        end else begin
          b    <= b + 1'b1;
          syn  <= syn_nx;
          ferr <= ferr_nx;
        end
      end
    end
  end

  // ================================================================== codeword buffer (NBANKS banks)
  reg [7:0] mem [0:NBANKS*CW_BYTES-1];
  wire [AW-1:0] waddr = AW'(wbank) * AW'(CW_BYTES) + AW'(b);
  always_ff @(posedge clk) begin
    if (in_fire) mem[waddr] <= in_data;
    if (ram_re)  ram_rdata  <= mem[ram_raddr];
  end

  // ================================================================== KES
  sfecc_bch_kes #(.GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .TAGW(KW + 1)) u_kes (
    .clk, .rst_n,
    .in_valid (h_valid), .in_ready(k_in_ready), .in_syn(h_syn), .in_tag(h_tag),
    .out_valid(k_valid), .out_ready(k_ready), .out_lam(k_lam), .out_l(k_l), .out_tag(k_tag)
  );

  // ================================================================== CHIEN + correction
  sfecc_bch_chien #(.GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .R(R), .MSG_BYTES(MSG_BYTES), .LPAD(LPAD),
                    .NBANKS(NBANKS)) u_chien (
    .clk, .rst_n,
    .k_valid, .k_ready, .k_lam, .k_l, .k_bank(k_tag[KW-1:0]), .k_frame_err(k_tag[KW]),
    .ram_re, .ram_raddr, .ram_rdata, .bank_rel, .bank_rel_id,
    .out_valid, .out_ready, .out_data, .out_last,
    .st_valid, .st_ready, .st_code, .st_nerr, .st_frame_err
  );

  assign busy = (b != '0) || h_valid || (bank_busy != '0) || !k_in_ready || k_valid;
endmodule

`default_nettype wire
