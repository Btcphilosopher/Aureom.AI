// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_bch_chien -- Chien search + correction
//
// Evaluates lam(alpha^-d) for the 8 bit positions of one stored byte per cycle,
// in stream order (highest degree first), and XORs the error mask into the byte
// read back from the codeword buffer.  Byte b, lane l (l = 0 is the MSB):
//     d(b,l) = D0 - 8b - l,   D0 = 8*MSG_BYTES + R - 1 (degree of stream bit 0)
//     Rj(b)  = lam_j * alpha^(-j*D0) * alpha^(8jb)     (registers, j = 1..T)
//     lam(alpha^-d(b,l)) = lam_0 + sum_j Rj(b) * alpha^(j*l)
// Padding bits (LPAD leading, TPAD trailing) and positions outside the
// shortened code are never valid roots.  All alpha powers are constants.
//
// Decision (end of codeword), see docs/04_FAILURE_MODES.md:
//   L > T                    -> UNCORRECTABLE, data passed through raw
//   #roots in range != L     -> UNCORRECTABLE (roots found were applied)
//   corrected word all ones  -> ERASED (nerr = flips corrected)
//   L == 0                   -> CLEAN,  else CORRECTED (nerr = L)
// Output order: the status of a codeword is presented only after its last data
// byte was accepted; the next codeword's data may already follow (data and status
// are two in-order channels).  The next locator is accepted while the previous
// codeword's last byte retires, so back-to-back codewords have no idle cycles.
// Throughput: 1 byte/cycle (parity bytes are scanned but not output).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfecc_bch_chien #(
  parameter integer GF_M      = 8,
  parameter integer GF_PRIM   = 'h11D,
  parameter integer T         = 4,
  parameter integer R         = 32,
  parameter integer MSG_BYTES = 28,
  parameter integer LPAD      = 1,
  parameter integer NBANKS    = 2,
  localparam integer KW       = (NBANKS > 2) ? 2 : 1,
  localparam integer LW       = $clog2(2 * T + 1),
  localparam integer NW       = $clog2(T + 1),
  localparam integer PAR_BYTES = (R + 7) / 8,
  localparam integer CW_BYTES  = MSG_BYTES + PAR_BYTES,
  localparam integer AW        = $clog2(NBANKS * CW_BYTES)
) (
  input  wire                  clk,
  input  wire                  rst_n,
  // from the key-equation solver
  input  wire                  k_valid,
  output wire                  k_ready,
  input  wire [(T+1)*GF_M-1:0] k_lam,
  input  wire [LW-1:0]         k_l,
  input  wire [KW-1:0]         k_bank,
  input  wire                  k_frame_err,
  // codeword buffer read port (1-cycle synchronous read)
  output wire                  ram_re,
  output wire [AW-1:0]         ram_raddr,
  input  wire [7:0]            ram_rdata,
  output reg                   bank_rel,         // pulse: bank_rel_id is free again
  output reg  [KW-1:0]         bank_rel_id,
  // corrected message stream
  output wire                  out_valid,
  input  wire                  out_ready,
  output wire [7:0]            out_data,
  output wire                  out_last,
  // status
  output wire                  st_valid,
  input  wire                  st_ready,
  output reg  [1:0]            st_code,
  output reg  [NW-1:0]         st_nerr,
  output reg                   st_frame_err
);
  `include "sfecc_gf_funcs.svh"

  localparam integer TPAD = 8 * PAR_BYTES - R;
  localparam integer D0   = 8 * MSG_BYTES + R - 1;
  localparam integer BW   = $clog2(CW_BYTES + 1);
  localparam integer RCW  = $clog2(T + 2);         // root counter, saturates at T+1

  // ------------------------------------------------------------------ state
  localparam [1:0] C_IDLE = 2'd0, C_RUN = 2'd1, C_FIN = 2'd2;
  reg  [1:0]            cs;
  reg  [T*GF_M-1:0]     rj;                 // R_1 .. R_T
  reg  [GF_M-1:0]       r0;                 // lam_0
  reg  [BW-1:0]         b;                  // next byte to issue
  reg  [KW-1:0]         bank;
  reg  [LW-1:0]         lq;
  reg                   fail_early, frame_q;
  reg  [RCW-1:0]        roots;
  reg                   ones;
  reg                   st_pend;
  // decision stage: final root count / erased flag registered, status formed one cycle later
  reg                   fin_v, fin_ones, fin_fe, fin_frame;
  reg  [RCW-1:0]        fin_roots;
  reg  [LW-1:0]         fin_lq;
  reg  [1:0]            ndone;              // message-last bytes popped, status not yet taken
  // pipeline stage p1: RAM data arrives
  reg                   p1_v, p1_msg, p1_lmsg, p1_lcw;
  reg  [7:0]            p1_em, p1_pad;
  // output FIFO (4 x {last, data})
  reg  [8:0]            fifo [0:3];
  reg  [1:0]            f_wp, f_rp;
  reg  [2:0]            f_cnt;

  // a new locator is accepted while the previous word's last byte is retired (C_FIN)
  assign k_ready = (cs == C_IDLE) || (cs == C_FIN);

  // ------------------------------------------------------------------ Chien evaluation of the current byte
  wire [7:0] ev_zero;
  // Accumulations are written as functions used in continuous assignments, not as
  // always_comb blocks that re-assign a variable: Icarus Verilog 12 treats variables written
  // inside always_comb as sensitivities and loops forever on the intermediate values.
  function automatic [GF_M-1:0] xor_redt(input [GF_M-1:0] base, input [T*GF_M-1:0] tv);
    integer n;
    reg [GF_M-1:0] a;
    begin
      a = base;
      for (n = 0; n < T; n = n + 1) a = a ^ tv[n*GF_M +: GF_M];
      xor_redt = a;
    end
  endfunction
  genvar j, l;
  generate
    for (l = 0; l < 8; l = l + 1) begin : g_lane
      wire [T*GF_M-1:0] term;
      wire [GF_M-1:0]   acc;
      for (j = 1; j <= T; j = j + 1) begin : g_term
        localparam integer CJL = sfecc_gfc_apow(j * l);
        assign term[(j-1)*GF_M +: GF_M] = (l == 0) ? rj[(j-1)*GF_M +: GF_M]
                                                   : sfecc_gf_mul(rj[(j-1)*GF_M +: GF_M], CJL[GF_M-1:0]);
      end
      assign acc = xor_redt(r0, term);
      assign ev_zero[l] = (acc == {GF_M{1'b0}});
    end
  endgenerate

  // next-byte register step and load values
  wire [T*GF_M-1:0] rj_step, rj_load;
  generate
    for (j = 1; j <= T; j = j + 1) begin : g_rj
      localparam integer C8J = sfecc_gfc_apow(8 * j);
      localparam integer CIN = sfecc_gfc_apow(-(j * D0));
      assign rj_step[(j-1)*GF_M +: GF_M] = sfecc_gf_mul(rj[(j-1)*GF_M +: GF_M], C8J[GF_M-1:0]);
      assign rj_load[(j-1)*GF_M +: GF_M] = sfecc_gf_mul(k_lam[j*GF_M +: GF_M], CIN[GF_M-1:0]);
    end
  endgenerate

  // lane validity of byte b (padding / outside-code positions are never roots)
  wire       is_first = (b == '0);
  wire       is_lastb = (b == BW'(CW_BYTES - 1));
  // {error mask, padding mask} of the byte; bit 7 = lane 0 = MSB
  function automatic [15:0] lanes(input [7:0] evz, input first, input lastb, input fe);
    integer li;
    reg ok;
    begin
      lanes = 16'h0000;
      for (li = 0; li < 8; li = li + 1) begin
        ok = !((first && li < LPAD) || (lastb && li >= 8 - TPAD));
        lanes[15 - li] = evz[li] && ok && !fe;
        lanes[7 - li]  = !ok;
      end
    end
  endfunction
  wire [15:0] lanes_c = lanes(ev_zero, is_first, is_lastb, fail_early);
  wire [7:0]  em_c    = lanes_c[15:8];
  wire [7:0]  pad_c   = lanes_c[7:0];
  function automatic [3:0] popc8(input [7:0] v);
    integer n;
    begin
      popc8 = 4'd0;
      for (n = 0; n < 8; n = n + 1) popc8 = popc8 + {3'd0, v[n]};
    end
  endfunction
  // roots are counted one stage after the Chien evaluation, from the registered mask p1_em
  // (keeps the popcount/accumulate off the evaluation path)
  wire [RCW+3:0] roots_sum = {4'd0, roots} + {{RCW{1'b0}}, popc8(p1_em)};
  wire [RCW-1:0] roots_nx  = (roots_sum > (RCW+4)'(T + 1)) ? RCW'(T + 1) : roots_sum[RCW-1:0];

  // ------------------------------------------------------------------ issue control
  wire b_is_msg = (b < BW'(MSG_BYTES));
  wire issue    = (cs == C_RUN) && (b < BW'(CW_BYTES)) && !(is_lastb && (st_pend || fin_v)) &&
                  (!b_is_msg || ({1'b0, f_cnt} + {3'd0, p1_v && p1_msg}) <= 4'd2);
  assign ram_re    = issue;
  assign ram_raddr = AW'(bank) * AW'(CW_BYTES) + AW'(b);

  // ------------------------------------------------------------------ corrected byte, end of word
  wire [7:0] cor      = ram_rdata ^ p1_em;
  wire       ones_nx  = ones && ((cor | p1_pad) == 8'hFF);
  wire       f_push   = p1_v && p1_msg;
  wire       f_pop    = out_valid && out_ready;
  wire       fail_fin = fin_fe || ({{(32-RCW){1'b0}}, fin_roots} != {{(32-LW){1'b0}}, fin_lq});

  assign out_valid = (f_cnt != 3'd0);
  assign out_data  = fifo[f_rp][7:0];
  assign out_last  = fifo[f_rp][8];
  assign st_valid  = st_pend && (ndone != 2'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cs <= C_IDLE; rj <= '0; r0 <= '0; b <= '0; bank <= '0; lq <= '0; fail_early <= 1'b0;
      frame_q <= 1'b0; roots <= '0; ones <= 1'b0; st_pend <= 1'b0; ndone <= 2'd0;
      p1_v <= 1'b0; p1_msg <= 1'b0; p1_lmsg <= 1'b0; p1_lcw <= 1'b0; p1_em <= '0; p1_pad <= '0;
      f_wp <= '0; f_rp <= '0; f_cnt <= '0;
      bank_rel <= 1'b0; bank_rel_id <= '0;
      st_code <= 2'd0; st_nerr <= '0; st_frame_err <= 1'b0;
      fin_v <= 1'b0; fin_ones <= 1'b0; fin_fe <= 1'b0; fin_frame <= 1'b0; fin_roots <= '0; fin_lq <= '0;
    end else begin
      bank_rel <= 1'b0;
      // ---------------- accept a new locator
      if (cs == C_FIN) cs <= C_IDLE;           // the last byte is retired this cycle
      if (k_ready && k_valid) begin
        cs         <= C_RUN;
        rj         <= rj_load;
        r0         <= k_lam[GF_M-1:0];
        lq         <= k_l;
        fail_early <= ({{(32-LW){1'b0}}, k_l} > T);
        frame_q    <= k_frame_err;
        bank       <= k_bank;
        b          <= '0;
        roots      <= '0;
        ones       <= 1'b1;
      end
      // ---------------- issue one byte
      p1_v <= issue;
      if (issue) begin
        p1_msg  <= b_is_msg;
        p1_lmsg <= (b == BW'(MSG_BYTES - 1));
        p1_lcw  <= is_lastb;
        p1_em   <= em_c;
        p1_pad  <= pad_c;
        rj      <= rj_step;
        b       <= b + 1'b1;
        if (is_lastb) cs <= C_FIN;
      end
      // ---------------- data back from the buffer
      if (p1_v) begin
        if (!p1_lcw) begin
          ones  <= ones_nx;                       // final values are used below; a new word may load them
          roots <= roots_nx;
        end
        if (p1_lcw) begin
          bank_rel    <= 1'b1;
          bank_rel_id <= bank;
          fin_v       <= 1'b1;
          fin_roots   <= roots_nx;
          fin_ones    <= ones_nx;
          fin_lq      <= lq;
          fin_fe      <= fail_early;
          fin_frame   <= frame_q;
        end
      end
      // ---------------- decision (one cycle after the last byte)
      if (fin_v) begin
        fin_v        <= 1'b0;
        st_pend      <= 1'b1;
        st_frame_err <= fin_frame;
        if (fail_fin) begin
          st_code <= `SFECC_ST_UNCORR;     st_nerr <= '0;
        end else if (fin_ones) begin
          st_code <= `SFECC_ST_ERASED;     st_nerr <= NW'(fin_lq);
        end else if (fin_lq == '0) begin
          st_code <= `SFECC_ST_CLEAN;      st_nerr <= '0;
        end else begin
          st_code <= `SFECC_ST_CORRECTED;  st_nerr <= NW'(fin_lq);
        end
      end
      // ---------------- output FIFO
      if (f_push) begin
        fifo[f_wp] <= {p1_lmsg, cor};
        f_wp       <= f_wp + 1'b1;
      end
      if (f_pop) begin
        f_rp <= f_rp + 1'b1;
      end
      f_cnt <= f_cnt + {2'd0, f_push} - {2'd0, f_pop};
      ndone <= ndone + {1'b0, f_pop && out_last} - {1'b0, st_valid && st_ready};
      // ---------------- status hand-off frees the stage
      if (st_valid && st_ready) begin
        st_pend <= 1'b0;
      end
    end
  end
endmodule

`default_nettype wire
