// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_defs.svh
// Library-wide constants.  `define header, not a package (Yosys 0.33 cannot
// resolve package references in parameter lists -- same convention as
// silicaflux-sramlib and silicaflux-ras).  Values are part of the firmware /
// status contract: never renumber, only append.
// =============================================================================
`ifndef SFECC_DEFS_SVH
`define SFECC_DEFS_SVH

// ---------------------------------------------------- codec status (2 bits)
`define SFECC_ST_CLEAN      2'd0   // syndromes zero: no error detected
`define SFECC_ST_CORRECTED  2'd1   // 1..t bit errors located and corrected
`define SFECC_ST_ERASED     2'd2   // decoded word is all ones (erased), nerr = flips corrected
`define SFECC_ST_UNCORR     2'd3   // decoder failure: L > t or #roots != L (detected uncorrectable)

// ---------------------------------------------------- page sector status (3 bits)
`define SFECC_SS_CLEAN      3'd0
`define SFECC_SS_CORRECTED  3'd1
`define SFECC_SS_ERASED     3'd2
`define SFECC_SS_UNCORR     3'd3
`define SFECC_SS_INTEGRITY  3'd4   // codec reported success but the CRC-16 failed (miscorrection detected)

// ---------------------------------------------------- codec selection
`define SFECC_CODEC_BCH     0
`define SFECC_CODEC_LDPC    1

// ---------------------------------------------------- LDPC proof-of-concept code geometry (QC-LDPC (128,64))
`define SFECC_LDPC_MSG_BYTES 8
`define SFECC_LDPC_PAR_BYTES 8

// ---------------------------------------------------- identification
`define SFECC_ID            32'h5345_4343   // "SECC"
`define SFECC_VERSION       32'h0001_0000   // 1.0.0

// ---------------------------------------------------- configuration errors
`ifdef __ICARUS__
  `define SFECC_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SFECC_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SFECC_DEFS_SVH
