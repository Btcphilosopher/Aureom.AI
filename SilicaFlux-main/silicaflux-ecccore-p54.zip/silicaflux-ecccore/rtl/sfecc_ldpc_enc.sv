// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_ldpc_enc -- QC-LDPC(128,64) encoder (proof of concept)
//
// Systematic: 8 message bytes in -> 8 message bytes out (unchanged) + 8 parity bytes.
// parity = XOR of the generator rows of the set message bits (constant 64x64 GF(2)
// matrix, rtl/generated/sfecc_ldpc_code.svh) XOR the erased-page mask.  Codeword bit
// 8b+j is bit (7-j) of byte b.  Same ports as sfecc_bch_enc (codec interface).
// Classification: SYNTHESIZABLE (proof of concept, docs/05)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfecc_ldpc_enc (
  input  wire       clk,
  input  wire       rst_n,
  input  wire       in_valid,
  output wire       in_ready,
  input  wire [7:0] in_data,
  input  wire       in_last,
  output reg        out_valid,
  input  wire       out_ready,
  output reg  [7:0] out_data,
  output reg        out_last,
  output reg        frame_err
);
  /* verilator lint_off UNUSEDPARAM */
  `include "sfecc_ldpc_code.svh"                   // (LDPC_BASE is used by the decoder only)
  /* verilator lint_on UNUSEDPARAM */

  reg  [63:0] msg;                 // codeword bit i at msg[i]
  reg  [63:0] par_sh;              // parity, codeword bit 64+j at par_sh[63-j] after load (MSB first out)
  reg  [3:0]  cnt;
  wire        msg_phase = (cnt < 4'd8);
  wire        adv = !out_valid || out_ready;
  assign in_ready = msg_phase && adv;
  wire        in_fire = in_valid && in_ready;

  // message with the incoming last byte merged in
  // (a function, not an always_comb that re-assigns msg_nx: Icarus Verilog 12 loops on the latter)
  function automatic [63:0] merge(input [63:0] m, input [7:0] d, input [2:0] bi);
    integer j;
    begin
      merge = m;
      for (j = 0; j < 8; j = j + 1) merge[{26'd0, bi, 3'b000} + j] = d[7 - j];
    end
  endfunction
  wire [63:0] msg_nx = merge(msg, in_data, cnt[2:0]);
  function automatic [63:0] parity(input [63:0] msgv);
    integer i;
    reg [63:0] p;
    begin
      p = LDPC_MASK;
      for (i = 0; i < 64; i = i + 1) if (msgv[i]) p = p ^ LDPC_GEN[i*64 +: 64];
      parity = p;
    end
  endfunction
  function automatic [63:0] rev64(input [63:0] v);
    integer i;
    begin
      for (i = 0; i < 64; i = i + 1) rev64[63 - i] = v[i];
    end
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      msg <= '0; par_sh <= '0; cnt <= '0; out_valid <= 1'b0; out_data <= 8'h00; out_last <= 1'b0;
      frame_err <= 1'b0;
    end else begin
      frame_err <= 1'b0;
      if (adv) out_valid <= 1'b0;
      if (msg_phase) begin
        if (in_fire) begin
          out_valid <= 1'b1;
          out_data  <= in_data;
          out_last  <= 1'b0;
          msg       <= msg_nx;
          cnt       <= cnt + 1'b1;
          frame_err <= (in_last != (cnt == 4'd7));
          if (cnt == 4'd7) par_sh <= rev64(parity(msg_nx));
        end
      end else if (adv) begin
        out_valid <= 1'b1;
        out_data  <= par_sh[63:56];
        par_sh    <= par_sh << 8;
        out_last  <= (cnt == 4'd15);
        cnt       <= (cnt == 4'd15) ? 4'd0 : cnt + 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
