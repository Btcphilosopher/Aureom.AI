// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_bch_kes -- key-equation solver
//
// Simplified inversionless Berlekamp-Massey for binary BCH (t iterations; the
// discrepancies of the odd steps of the 2t-step algorithm are identically zero
// because S_2i = S_i^2, proven/checked in docs/01 and scripts/validate_ref.py):
//   lam = 1, B = 1, L = 0, gamma = 1
//   for q = 0 .. T-1   (r = 2q)
//     delta = sum_{i=0..T} lam_i * S_{2q+1-i}            (S_x = 0 for x < 1)
//     lam'  = gamma*lam + delta*x*B
//     if delta != 0 and L <= q :  B' = x*lam ; L' = 2q+1-L ; gamma' = delta
//     else                       :  B' = x^2*B
// Identical, step for step, to BCHCode.ibm_simplified() in ref/sfecc_bch.py.
// No field inversion.  lam and B are held to degree T: when the final L <= T no
// non-zero coefficient is ever truncated (docs/01 §5); when L > T the decoder
// declares failure regardless of lam.
//
// Timing: 2 cycles per iteration (cycle D: delta = one multiplier + XOR tree;
// cycle U: lam/B update = one multiplier + XOR), 2T+2 cycles per codeword,
// 1 cycle when all syndromes are zero.  3(T+1) GF multipliers.
// Even syndromes are formed here: S_(2^a o) = S_o^(2^a), a constant GF(2)-linear
// (Frobenius) XOR map per output bit.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfecc_bch_kes #(
  parameter integer GF_M    = 8,
  parameter integer GF_PRIM = 'h11D,
  parameter integer T       = 4,
  parameter integer TAGW    = 2,
  localparam integer LW     = $clog2(2 * T + 1)
) (
  input  wire                  clk,
  input  wire                  rst_n,
  input  wire                  in_valid,
  output wire                  in_ready,
  input  wire [T*GF_M-1:0]     in_syn,          // S_1, S_3, ..., S_2T-1 (S_1 at [GF_M-1:0])
  input  wire [TAGW-1:0]       in_tag,
  output wire                  out_valid,
  input  wire                  out_ready,
  output wire [(T+1)*GF_M-1:0] out_lam,         // lam_0 at [GF_M-1:0]
  output wire [LW-1:0]         out_l,
  output wire [TAGW-1:0]       out_tag
);
  `include "sfecc_gf_funcs.svh"

  localparam integer NQ = (2 * T - 2 > 0) ? 2 * T - 2 : 1;    // S_2 .. S_2T-1 queue
  localparam integer QW = $clog2(T + 1);

  // ------------------------------------------------------------------ all syndromes S_1 .. S_2T-1
  // S_x for x = 2^a * o (o odd) is S_o^(2^a).  The Frobenius map v -> v^(2^a) is GF(2)-linear:
  // v^(2^a) = XOR over set bits i of v of alpha^(i * 2^a) -- one constant XOR level per output
  // bit (instead of a chain of a general squarers, which was the decoder's longest path).
  function automatic integer odd_part(input integer v);
    integer n, o;
    begin
      o = v;
      for (n = 0; n < 8; n = n + 1) if (o % 2 == 0) o = o / 2;
      odd_part = o;
    end
  endfunction
  function automatic integer two_pow(input integer v);
    integer n, o, a;
    begin
      o = v; a = 0;
      for (n = 0; n < 8; n = n + 1) if (o % 2 == 0) begin o = o / 2; a = a + 1; end
      two_pow = a;
    end
  endfunction
  // Accumulations are written as functions used in continuous assignments, not as
  // always_comb blocks that re-assign a variable: Icarus Verilog 12 treats variables written
  // inside always_comb as sensitivities and loops forever on the intermediate values.
  function automatic [GF_M-1:0] xor_redm(input [GF_M*GF_M-1:0] tv);
    integer n;
    reg [GF_M-1:0] a;
    begin
      a = {GF_M{1'b0}};
      for (n = 0; n < GF_M; n = n + 1) a = a ^ tv[n*GF_M +: GF_M];
      xor_redm = a;
    end
  endfunction
  function automatic [GF_M-1:0] disc(input [(T+1)*GF_M-1:0] lv, input [(T+1)*GF_M-1:0] wv);
    integer n;
    reg [GF_M-1:0] a;
    begin
      a = {GF_M{1'b0}};
      for (n = 0; n <= T; n = n + 1) a = a ^ sfecc_gf_mul(lv[n*GF_M +: GF_M], wv[n*GF_M +: GF_M]);
      disc = a;
    end
  endfunction
  /* verilator lint_off UNUSEDSIGNAL */
  wire [(2*T)*GF_M-1:0] sall;      // sall[x] = S_x, x = 1..2T-1 (index 0 unused = 0)
  /* verilator lint_on UNUSEDSIGNAL */
  assign sall[GF_M-1:0] = {GF_M{1'b0}};
  genvar x, fi;
  generate
    for (x = 1; x < 2 * T; x = x + 1) begin : g_sall
      localparam integer O = odd_part(x);
      localparam integer A = two_pow(x);
      wire [GF_M-1:0] so = in_syn[((O-1)/2)*GF_M +: GF_M];
      if (A == 0) begin : g_odd
        assign sall[x*GF_M +: GF_M] = so;
      end else begin : g_frob
        wire [GF_M*GF_M-1:0] tm;                 // term of input bit fi: alpha^(fi * 2^A) if set
        for (fi = 0; fi < GF_M; fi = fi + 1) begin : g_b
          localparam integer CF = sfecc_gfc_apow(fi * (1 << A));
          assign tm[fi*GF_M +: GF_M] = so[fi] ? CF[GF_M-1:0] : {GF_M{1'b0}};
        end
        assign sall[x*GF_M +: GF_M] = xor_redm(tm);
      end
    end
  endgenerate
  wire syn_zero = (in_syn == {T*GF_M{1'b0}});

  // ------------------------------------------------------------------ state
  localparam [1:0] K_IDLE = 2'd0, K_DELTA = 2'd1, K_UPD = 2'd2, K_DONE = 2'd3;
  reg [1:0]              st;
  reg [(T+1)*GF_M-1:0]   lam, bb, sw;
  reg [NQ*GF_M-1:0]      sq;
  reg [GF_M-1:0]         gamma, delta;
  reg [LW-1:0]           L;
  reg [QW-1:0]           q;
  reg [TAGW-1:0]         tag;

  assign in_ready  = (st == K_IDLE);
  assign out_valid = (st == K_DONE);
  assign out_lam   = lam;
  assign out_l     = L;
  assign out_tag   = tag;

  // delta = sum lam_i * sw_i
  wire [GF_M-1:0] delta_c = disc(lam, sw);

  // lam/B update and syndrome window shift (function: see the note above)
  wire chg = (delta != {GF_M{1'b0}}) && ({{(32-LW){1'b0}}, L} <= {{(32-QW){1'b0}}, q});
  function automatic [3*(T+1)*GF_M+NQ*GF_M-1:0] upd_f(input [(T+1)*GF_M-1:0] lv, input [(T+1)*GF_M-1:0] bv,
                                                     input [(T+1)*GF_M-1:0] wv, input [NQ*GF_M-1:0] qv,
                                                     input [GF_M-1:0] gm, input [GF_M-1:0] dl, input ch);
    reg [(T+1)*GF_M-1:0] ln, bn, wn;
    integer k;
    begin
      for (k = 0; k <= T; k = k + 1) begin
        ln[k*GF_M +: GF_M] = sfecc_gf_mul(gm, lv[k*GF_M +: GF_M]) ^
                             ((k >= 1) ? sfecc_gf_mul(dl, bv[(k-1)*GF_M +: GF_M]) : {GF_M{1'b0}});
        if (ch) bn[k*GF_M +: GF_M] = (k >= 1) ? lv[(k-1)*GF_M +: GF_M] : {GF_M{1'b0}};
        else    bn[k*GF_M +: GF_M] = (k >= 2) ? bv[(k-2)*GF_M +: GF_M] : {GF_M{1'b0}};
        // window: sw'[0] = S_2q+3 = sq[1], sw'[1] = S_2q+2 = sq[0], sw'[k] = sw[k-2]
        if (k == 0)      wn[k*GF_M +: GF_M] = (NQ > 1) ? qv[1*GF_M +: GF_M] : {GF_M{1'b0}};
        else if (k == 1) wn[k*GF_M +: GF_M] = qv[0 +: GF_M];
        else             wn[k*GF_M +: GF_M] = wv[(k-2)*GF_M +: GF_M];
      end
      upd_f = {ln, bn, wn, qv >> (2 * GF_M)};
    end
  endfunction
  wire [3*(T+1)*GF_M+NQ*GF_M-1:0] upd = upd_f(lam, bb, sw, sq, gamma, delta, chg);
  wire [(T+1)*GF_M-1:0] lam_n = upd[3*(T+1)*GF_M+NQ*GF_M-1 -: (T+1)*GF_M];
  wire [(T+1)*GF_M-1:0] bb_n  = upd[2*(T+1)*GF_M+NQ*GF_M-1 -: (T+1)*GF_M];
  wire [(T+1)*GF_M-1:0] sw_n  = upd[(T+1)*GF_M+NQ*GF_M-1 -: (T+1)*GF_M];
  wire [NQ*GF_M-1:0]    sq_n  = upd[NQ*GF_M-1:0];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= K_IDLE; lam <= '0; bb <= '0; sw <= '0; sq <= '0; gamma <= '0; delta <= '0;
      L <= '0; q <= '0; tag <= '0;
    end else begin
      case (st)
        K_IDLE: if (in_valid) begin
          tag   <= in_tag;
          lam   <= {{(T*GF_M){1'b0}}, {{(GF_M-1){1'b0}}, 1'b1}};
          bb    <= {{(T*GF_M){1'b0}}, {{(GF_M-1){1'b0}}, 1'b1}};
          gamma <= {{(GF_M-1){1'b0}}, 1'b1};
          L     <= '0;
          q     <= '0;
          sw    <= {{(T*GF_M){1'b0}}, sall[1*GF_M +: GF_M]};
          sq    <= sall[2*GF_M +: NQ*GF_M];
          st    <= syn_zero ? K_DONE : K_DELTA;
        end
        K_DELTA: begin
          delta <= delta_c;
          st    <= K_UPD;
        end
        K_UPD: begin
          lam <= lam_n;
          bb  <= bb_n;
          sw  <= sw_n;
          sq  <= sq_n;
          if (chg) begin
            L     <= LW'(2 * q + 1) - L;
            gamma <= delta;
          end
          q  <= q + 1'b1;
          st <= (q == QW'(T - 1)) ? K_DONE : K_DELTA;
        end
        default: if (out_ready) st <= K_IDLE;      // K_DONE
      endcase
    end
  end
endmodule

`default_nettype wire
