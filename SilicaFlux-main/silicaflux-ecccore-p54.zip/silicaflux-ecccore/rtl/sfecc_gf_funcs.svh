// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_gf_funcs.svh
// GF(2^m) arithmetic, included INSIDE module bodies.  The including module
// must declare
//     parameter integer GF_M    -- field degree m (2..16)
//     parameter integer GF_PRIM -- primitive polynomial, bit i = coef of x^i,
//                                  bit m set (e.g. 'h11D for m = 8, 'h201B for 13)
// Elements are m-bit vectors in the polynomial basis {1, a, ..., a^(m-1)},
// a = alpha = root of GF_PRIM.
//
// Two flavours:
//   sfecc_gf_mul(a, b)        run-time bit-parallel multiplier (logic);
//                             with a constant operand synthesis folds it into
//                             an XOR network (constant multiplier).
//   sfecc_gfc_mul / _apow     elaboration-time (integer) versions used to build
//                             constants (alpha powers) for localparams.
// Verilog-2001 function style (assignment to the function name, loop variables
// declared up front, no 'return'): Yosys 0.33 accepts nothing else in constant
// functions.
// =============================================================================
// (no include guard on purpose: every module that needs the functions includes
//  this file once)

  localparam integer GF_N      = (1 << GF_M) - 1;
  localparam integer GF_PRIM_L = GF_PRIM & GF_N;      // p(x) without the x^m term

  // ---------------------------------------------------------------- run time
  // shift-and-add multiplication modulo p(x): m AND rows + m-1 conditional
  // reductions -- the classic Mastrovito-style bit-parallel multiplier.
  function automatic [GF_M-1:0] sfecc_gf_mul(input [GF_M-1:0] a, input [GF_M-1:0] b);
    integer i;
    reg [GF_M-1:0] p, aa;
    begin
      p  = {GF_M{1'b0}};
      aa = a;
      for (i = 0; i < GF_M; i = i + 1) begin
        if (b[i]) p = p ^ aa;
        aa = aa[GF_M-1] ? ((aa << 1) ^ GF_PRIM_L[GF_M-1:0]) : (aa << 1);
      end
      sfecc_gf_mul = p;
    end
  endfunction

  // ---------------------------------------------------------------- elaboration time
  function automatic integer sfecc_gfc_mul(input integer a, input integer b);
    integer i, p, aa;
    begin
      p  = 0;
      aa = a;
      for (i = 0; i < GF_M; i = i + 1) begin
        if (((b >> i) & 1) != 0) p = p ^ aa;
        aa = aa << 1;
        if (((aa >> GF_M) & 1) != 0) aa = aa ^ GF_PRIM;
      end
      sfecc_gfc_mul = p;
    end
  endfunction

  // alpha^e for any integer e (negative exponents allowed)
  function automatic integer sfecc_gfc_apow(input integer e);
    integer i, r, b, x;
    begin
      x = e % GF_N;
      if (x < 0) x = x + GF_N;
      r = 1;
      b = 2;                                  // alpha in the polynomial basis
      for (i = 0; i < 17; i = i + 1) begin
        if (((x >> i) & 1) != 0) r = sfecc_gfc_mul(r, b);
        b = sfecc_gfc_mul(b, b);
      end
      sfecc_gfc_apow = r;
    end
  endfunction

  // Primitivity of GF_PRIM: degree m, alpha^(2^m-1) = 1 and alpha^(N/q) != 1 for
  // every divisor 1 < q < N of N = 2^m-1 (this covers every prime factor of N:
  // for m <= 16 all prime factors that are < N are <= 8191).
  function automatic integer sfecc_gfc_prim_ok(input integer dummy);
    integer q, ok;
    begin
      ok = (((GF_PRIM >> GF_M) == 1) && GF_M >= 2 && GF_M <= 16) ? 1 : 0;
      if (sfecc_gfc_apow(GF_N) != 1) ok = 0;
      for (q = 2; q <= 8191; q = q + 1)
        if ((GF_N % q) == 0 && q != GF_N) begin
          if (sfecc_gfc_apow(GF_N / q) == 1) ok = 0;
        end
      sfecc_gfc_prim_ok = ok + 0 * dummy;
    end
  endfunction
