// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_page_enc -- NAND page encoder (program path)
//
// Split ("ECC in OOB") page layout, one codeword per sector (docs/03_PAGE_FORMAT.md):
//   column 0 .. PAGE_DATA-1           sector 0 | sector 1 | ... | sector S-1
//   column PAGE_DATA + i*SLOT_STRIDE  slot i = RSVD | UMETA | CRC-16 | PARITY
//   codeword i = sector i || UMETA_i || CRC_i  (message)  ||  PARITY_i
// RSVD (1 byte, slot 0's is the bad-block-marker byte) and unused spare bytes are
// always programmed 0xFF.  The CRC-16 over sector||UMETA is the independent
// integrity check that catches decoder miscorrections.
//
// Streams: payload (PAGE_DATA bytes/page) + user metadata (UMETA bytes per sector,
// requested after that sector's payload) -> raw page in column order
// (PAGE_DATA + PAGE_SPARE bytes, raw_last on the last).  Data-area bytes leave as
// they are encoded; metadata/CRC/parity collect in a PAGE_SPARE-byte spare buffer
// that is emitted after the data area.  Elaboration fails if the ECC does not fit
// in the OOB area (the OOB budget is part of the configuration).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfecc_page_enc #(
  parameter integer CODEC      = 0,
  parameter integer GF_M       = 13,
  parameter integer GF_PRIM    = 'h201B,
  parameter integer T          = 8,
  parameter integer R          = 104,
  parameter [R:0]   GPOLY      = 105'h115f914e07b0c138741c5c4fb23,
  parameter integer MSG_BYTES  = 514,
  parameter integer LPAD       = 0,
  parameter [R-1:0] MASK       = 104'h6443109f38abc78fb78bc9a779,
  parameter integer PAGE_DATA  = 2048,
  parameter integer PAGE_SPARE = 64,
  parameter integer SECTOR     = 512,
  parameter integer UMETA      = 0,
  parameter integer CRC_EN     = 1
) (
  input  wire       clk,
  input  wire       rst_n,
  input  wire       pay_valid,
  output wire       pay_ready,
  input  wire [7:0] pay_data,
  input  wire       pay_last,
  input  wire       um_valid,
  output wire       um_ready,
  input  wire [7:0] um_data,
  output wire       raw_valid,
  input  wire       raw_ready,
  output wire [7:0] raw_data,
  output wire       raw_last,
  output reg        frame_err,
  output wire       busy
);
  `include "sfecc_crc16.svh"

  localparam integer SECTORS   = PAGE_DATA / SECTOR;
  localparam integer CRCB      = (CRC_EN != 0) ? 2 : 0;
  localparam integer PAR_BYTES = (CODEC == `SFECC_CODEC_BCH) ? (R + 7) / 8 : `SFECC_LDPC_PAR_BYTES;
  localparam integer CMSG      = (CODEC == `SFECC_CODEC_BCH) ? MSG_BYTES : `SFECC_LDPC_MSG_BYTES;
  localparam integer CW_BYTES  = CMSG + PAR_BYTES;
  localparam integer RSVD      = 1;
  localparam integer SLOT      = RSVD + UMETA + CRCB + PAR_BYTES;
  localparam integer STRIDE    = PAGE_SPARE / SECTORS;
  localparam integer RAW_BYTES = PAGE_DATA + PAGE_SPARE;
  localparam integer IW        = $clog2(CW_BYTES + 1);
  localparam integer SW        = $clog2(SECTORS + 1);
  localparam integer PW        = $clog2(RAW_BYTES + 1);
  localparam integer XW        = $clog2(PAGE_SPARE + 1);
  localparam integer SAW       = (PAGE_SPARE > 1) ? $clog2(PAGE_SPARE) : 1;   // spare-buffer address

  generate
    if (PAGE_DATA % SECTOR != 0 || SECTORS < 1) begin : g_bad_sec
      `SFECC_CFG_FATAL("sfecc_page_enc: PAGE_DATA is not a whole number of sectors")
    end
    if (CMSG != SECTOR + UMETA + CRCB || LPAD != 0) begin : g_bad_msg
      `SFECC_CFG_FATAL("sfecc_page_enc: codec message != SECTOR + UMETA + CRC (or LPAD != 0)")
    end
    if (SLOT > STRIDE) begin : g_bad_oob
      `SFECC_CFG_FATAL("sfecc_page_enc: OOB overflow -- RSVD+UMETA+CRC+PARITY exceeds the spare bytes per sector")
    end
  endgenerate

  // ================================================================== codec input side
  reg  [IW-1:0] i_idx;                 // byte of the current message
  reg  [SW-1:0] i_sec;
  reg  [PW-1:0] p_cnt;                 // payload bytes of this page (framing check)
  reg  [15:0]   crc;
  wire          src_pay = (i_idx < IW'(SECTOR));
  wire          src_um  = !src_pay && (i_idx < IW'(SECTOR + UMETA));
  wire          src_crc = !src_pay && !src_um;
  wire [7:0]    crc_byte = (i_idx == IW'(SECTOR + UMETA)) ? crc[15:8] : crc[7:0];
  wire          c_iv = src_pay ? pay_valid : (src_um ? um_valid : 1'b1);
  wire [7:0]    c_id = src_pay ? pay_data  : (src_um ? um_data  : crc_byte);
  wire          c_il = (i_idx == IW'(CMSG - 1));
  wire          c_ir;
  wire          c_ifire = c_iv && c_ir;
  assign pay_ready = src_pay && c_ir;
  assign um_ready  = src_um && c_ir;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      i_idx <= '0; i_sec <= '0; p_cnt <= '0; crc <= 16'hFFFF; frame_err <= 1'b0;
    end else begin
      frame_err <= 1'b0;
      if (c_ifire) begin
        if (!src_crc) crc <= sfecc_crc16_upd(crc, c_id);
        if (src_pay) begin
          p_cnt     <= (p_cnt == PW'(PAGE_DATA - 1)) ? '0 : p_cnt + 1'b1;
          frame_err <= (pay_last != (p_cnt == PW'(PAGE_DATA - 1)));
        end
        if (c_il) begin
          i_idx <= '0;
          crc   <= 16'hFFFF;
          i_sec <= (i_sec == SW'(SECTORS - 1)) ? '0 : i_sec + 1'b1;
        end else
          i_idx <= i_idx + 1'b1;
      end
    end
  end

  // ================================================================== codec
  wire       c_ov, c_ol, c_ferr;
  wire       c_or;
  wire [7:0] c_od;
  sfecc_codec_enc #(.CODEC(CODEC), .GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .R(R), .GPOLY(GPOLY),
                    .MSG_BYTES(MSG_BYTES), .LPAD(LPAD), .MASK(MASK)) u_codec (
    .clk, .rst_n, .in_valid(c_iv), .in_ready(c_ir), .in_data(c_id), .in_last(c_il),
    .out_valid(c_ov), .out_ready(c_or), .out_data(c_od), .out_last(c_ol), .frame_err(c_ferr));

  // ================================================================== codec output side
  reg  [IW-1:0] o_idx;
  reg  [SW-1:0] o_sec;
  reg           sp_phase;               // emitting the spare area
  reg  [XW-1:0] sp_j;                   // next spare byte to fetch
  reg  [SW-1:0] sp_slot;                // slot of sp_j
  reg  [XW-1:0] sp_off;                 // offset of sp_j in its slot
  // output FIFO (4 x {last, data})
  reg  [8:0]    fifo [0:3];
  reg  [1:0]    f_wp, f_rp;
  reg  [2:0]    f_cnt;
  reg           rd_v, rd_ram, rd_last;  // spare fetch in flight
  reg  [7:0]    rd_ff;
  wire          o_data = (o_idx < IW'(SECTOR));
  // codec output: data bytes need FIFO room; spare-buffer bytes are always accepted
  assign c_or = !sp_phase && !rd_v && (o_data ? (f_cnt <= 3'd2) : 1'b1);
  wire          c_ofire = c_ov && c_or;

  // spare buffer (1W1R, synchronous read)
  reg  [7:0]    sbuf [0:PAGE_SPARE-1];
  reg  [7:0]    sbuf_q;
  wire [XW-1:0] s_waddr = XW'(o_sec) * XW'(STRIDE) + XW'(RSVD) + XW'(o_idx - IW'(SECTOR));
  wire          s_we = c_ofire && !o_data;
  wire          sp_in_slot = (sp_slot < SW'(SECTORS)) && (sp_off >= XW'(RSVD)) && (sp_off < XW'(SLOT));
  wire          sp_issue = sp_phase && (sp_j < XW'(PAGE_SPARE)) && ((f_cnt + {2'd0, rd_v}) <= 3'd2);
  always_ff @(posedge clk) begin
    if (s_we) sbuf[s_waddr[SAW-1:0]] <= c_od;
    if (sp_issue) sbuf_q <= sbuf[sp_j[SAW-1:0]];
  end

  wire       f_push = (c_ofire && o_data) || rd_v;
  wire [8:0] f_in   = rd_v ? {rd_last, rd_ram ? sbuf_q : rd_ff} : {1'b0, c_od};
  wire       f_pop  = raw_valid && raw_ready;
  assign raw_valid = (f_cnt != 3'd0);
  assign raw_data  = fifo[f_rp][7:0];
  assign raw_last  = fifo[f_rp][8];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      o_idx <= '0; o_sec <= '0; sp_phase <= 1'b0; sp_j <= '0; sp_slot <= '0; sp_off <= '0;
      f_wp <= '0; f_rp <= '0; f_cnt <= '0; rd_v <= 1'b0; rd_ram <= 1'b0; rd_last <= 1'b0; rd_ff <= 8'hFF;
    end else begin
      if (c_ofire) begin
        if (o_idx == IW'(CW_BYTES - 1)) begin
          o_idx <= '0;
          if (o_sec == SW'(SECTORS - 1)) begin
            o_sec    <= '0;
            sp_phase <= 1'b1;
            sp_j     <= '0;
            sp_slot  <= '0;
            sp_off   <= '0;
          end else
            o_sec <= o_sec + 1'b1;
        end else
          o_idx <= o_idx + 1'b1;
      end
      rd_v <= sp_issue;
      if (sp_issue) begin
        rd_ram  <= sp_in_slot;
        rd_ff   <= 8'hFF;
        rd_last <= (sp_j == XW'(PAGE_SPARE - 1));
        sp_j    <= sp_j + 1'b1;
        if (sp_off == XW'(STRIDE - 1)) begin sp_off <= '0; sp_slot <= sp_slot + 1'b1; end
        else sp_off <= sp_off + 1'b1;
        if (sp_j == XW'(PAGE_SPARE - 1)) sp_phase <= 1'b0;
      end
      if (f_push) begin
        fifo[f_wp] <= f_in;
        f_wp       <= f_wp + 1'b1;
      end
      if (f_pop) f_rp <= f_rp + 1'b1;
      f_cnt <= f_cnt + {2'd0, f_push} - {2'd0, f_pop};
    end
  end

  assign busy = (i_idx != '0) || (i_sec != '0) || (o_idx != '0) || (o_sec != '0) || sp_phase || rd_v ||
                (f_cnt != 3'd0) || c_ov;
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = c_ol ^ c_ferr ^ ^s_waddr ^ ^sp_j;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
