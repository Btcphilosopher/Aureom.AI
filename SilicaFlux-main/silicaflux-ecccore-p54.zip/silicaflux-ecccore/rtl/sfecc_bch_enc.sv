// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_bch_enc -- systematic binary BCH encoder
//
// Byte-parallel (8 bits/cycle) LFSR division by the generator polynomial g(x):
//   c(x) = u(x) x^R + (u(x) x^R mod g(x)),  stored parity = remainder XOR MASK.
// Stream: MSG_BYTES message bytes in  ->  MSG_BYTES message bytes out (unchanged)
//         followed by PAR_BYTES = ceil(R/8) parity bytes, MSB first.
//   * The first LPAD bits (MSBs of message byte 0) are padding: passed through,
//     not encoded (LPAD = 1 makes the unshortened BCH(255,223) byte-framed).
//   * The last 8*PAR_BYTES - R bits of the last parity byte are padding = 1.
//   * MASK is the erased-page mask (parity of the all-ones message XOR all ones)
//     so that an erased (all-ones) codeword is valid -- see docs/03.
// Throughput: one output byte per cycle; message input stalls while the parity
// bytes are emitted ((MSG+PAR) cycles per codeword, no bubbles between codewords).
// Interfaces: ready/valid, registered output (pipeline register).  in_last is
// checked against the byte count (frame_err pulse); framing itself is by count.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfecc_bch_enc #(
  parameter integer GF_M      = 8,
  parameter integer GF_PRIM   = 'h11D,
  parameter integer T         = 4,
  parameter integer R         = 32,                      // deg g(x) = parity bits
  parameter [R:0]   GPOLY     = 33'h1EE5B42FD,           // g(x), bit d = coef x^d
  parameter integer MSG_BYTES = 28,
  parameter integer LPAD      = 1,
  parameter [R-1:0] MASK      = {R{1'b0}}
) (
  input  wire       clk,
  input  wire       rst_n,
  input  wire       in_valid,
  output wire       in_ready,
  input  wire [7:0] in_data,
  input  wire       in_last,
  output reg        out_valid,
  input  wire       out_ready,
  output reg  [7:0] out_data,
  output reg        out_last,
  output reg        frame_err
);
  `include "sfecc_gf_funcs.svh"

  localparam integer PAR_BYTES = (R + 7) / 8;
  localparam integer PW        = 8 * PAR_BYTES;
  localparam integer CW_BYTES  = MSG_BYTES + PAR_BYTES;
  localparam integer CNTW      = $clog2(CW_BYTES + 1);

  // ------------------------------------------------------------------ elaboration checks
  // g(x) must have degree R, constant term 1 and roots alpha^1 .. alpha^2T.  Its
  // coefficients are binary, so g(alpha^2i) = g(alpha^i)^2: checking odd powers suffices.
  function automatic integer gpoly_ok(input integer dummy);
    integer e, d, acc, ae, ok;
    begin
      ok = (GPOLY[R] == 1'b1 && GPOLY[0] == 1'b1) ? 1 : 0;
      for (e = 1; e < 2 * T; e = e + 2) begin
        ae  = sfecc_gfc_apow(e);
        acc = 0;
        for (d = R; d >= 0; d = d - 1)
          acc = sfecc_gfc_mul(acc, ae) ^ (GPOLY[d] ? 1 : 0);
        if (acc != 0) ok = 0;
      end
      gpoly_ok = ok + 0 * dummy;
    end
  endfunction
  localparam integer PRIM_OK  = sfecc_gfc_prim_ok(0);
  localparam integer GPOLY_OK = gpoly_ok(0);
  generate
    if (PRIM_OK != 1) begin : g_bad_prim
      `SFECC_CFG_FATAL("sfecc_bch_enc: GF_PRIM is not a primitive polynomial of degree GF_M")
    end
    if (GPOLY_OK != 1) begin : g_bad_g
      `SFECC_CFG_FATAL("sfecc_bch_enc: GPOLY is not a BCH generator with roots alpha^1..alpha^2T")
    end
    if (R < 2 || R > GF_M * T || LPAD < 0 || LPAD > 7 || MSG_BYTES < 1 ||
        8 * MSG_BYTES - LPAD + R > GF_N) begin : g_bad_len
      `SFECC_CFG_FATAL("sfecc_bch_enc: illegal R / LPAD / MSG_BYTES (codeword longer than 2^m-1?)")
    end
  endgenerate

  // ------------------------------------------------------------------ helpers
  // 8 (or 8-nskip) steps of the division LFSR, message bits MSB first
  function automatic [R-1:0] lfsr8(input [R-1:0] s, input [7:0] d, input integer nskip);
    integer i;
    reg     fb;
    reg [R-1:0] x;
    begin
      x = s;
      for (i = 0; i < 8; i = i + 1)
        if (i >= nskip) begin
          fb = d[7-i] ^ x[R-1];
          x  = {x[R-2:0], 1'b0} ^ (fb ? GPOLY[R-1:0] : {R{1'b0}});
        end
      lfsr8 = x;
    end
  endfunction
  // stored parity vector: R parity bits (MSB = highest degree) then pad ones
  function automatic [PW-1:0] mk_par(input [R-1:0] p);
    integer i;
    begin
      mk_par = {PW{1'b1}};
      for (i = 0; i < R; i = i + 1) mk_par[PW-1-i] = p[R-1-i];
    end
  endfunction

  // ------------------------------------------------------------------ datapath
  reg  [R-1:0]    lfsr;
  reg  [PW-1:0]   par_sh;
  reg  [CNTW-1:0] cnt;                      // byte index inside the codeword
  wire            msg_phase = (cnt < CNTW'(MSG_BYTES));
  wire            adv       = !out_valid || out_ready;
  wire            in_fire   = in_valid && in_ready;
  wire [R-1:0]    lfsr_nx   = (cnt == '0) ? lfsr8(lfsr, in_data, LPAD) : lfsr8(lfsr, in_data, 0);
  assign in_ready = msg_phase && adv;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lfsr <= '0; par_sh <= '0; cnt <= '0;
      out_valid <= 1'b0; out_data <= 8'h00; out_last <= 1'b0; frame_err <= 1'b0;
    end else begin
      frame_err <= 1'b0;
      if (adv) out_valid <= 1'b0;
      if (msg_phase) begin
        if (in_fire) begin
          out_valid <= 1'b1;
          out_data  <= in_data;
          out_last  <= 1'b0;
          cnt       <= cnt + 1'b1;
          if (cnt == CNTW'(MSG_BYTES - 1)) begin
            par_sh    <= mk_par(lfsr_nx ^ MASK);
            lfsr      <= '0;
            frame_err <= !in_last;
          end else begin
            lfsr      <= lfsr_nx;
            frame_err <= in_last;
          end
        end
      end else if (adv) begin
        out_valid <= 1'b1;
        out_data  <= par_sh[PW-1 -: 8];
        par_sh    <= par_sh << 8;
        out_last  <= (cnt == CNTW'(CW_BYTES - 1));
        cnt       <= (cnt == CNTW'(CW_BYTES - 1)) ? '0 : cnt + 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
