// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_page_dec -- NAND page decoder (read path)
//
// Input: the raw page in SPARE-FIRST order -- PAGE_SPARE spare bytes, then the
// PAGE_DATA data bytes (the channel issues Change Read Column 05h-E0h to the
// spare area, reads it, then changes column back to 0).  The spare area is held
// in a PAGE_SPARE-byte buffer; every sector is then decoded as it streams in:
//   codeword i = sector i (from the NAND stream) || UMETA_i || CRC_i || PARITY_i (from the buffer)
// so no page buffer is needed: only the codec's own codeword banks.
// Outputs, in page order: corrected payload (pay_last on the page's last byte),
// user metadata, one sector status per codeword and one page status per page.
//   sector code: CLEAN / CORRECTED / ERASED / UNCORRECTABLE (decoder failure) /
//                INTEGRITY_FAIL (decoder claimed success, CRC-16 mismatch:
//                miscorrection or undetected error caught by the integrity check)
//   page: counts per class, max / total bit flips, all-erased, bad-block-marker
//         byte (first spare byte as read), ok, scrub hint (max flips >= flip_thr).
// The next page's spare area is captured while the previous page's last sectors
// are still being decoded.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfecc_page_dec #(
  parameter integer CODEC      = 0,
  parameter integer GF_M       = 13,
  parameter integer GF_PRIM    = 'h201B,
  parameter integer T          = 8,
  parameter integer R          = 104,
  /* verilator lint_off UNUSEDPARAM */
  parameter [R:0]   GPOLY      = 105'h115f914e07b0c138741c5c4fb23,   // interface symmetry (decoder needs no g(x))
  /* verilator lint_on UNUSEDPARAM */
  parameter integer MSG_BYTES  = 514,
  parameter integer LPAD       = 0,
  parameter [R-1:0] MASK       = 104'h6443109f38abc78fb78bc9a779,
  parameter integer PAGE_DATA  = 2048,
  parameter integer PAGE_SPARE = 64,
  parameter integer SECTOR     = 512,
  parameter integer UMETA      = 0,
  parameter integer CRC_EN     = 1,
  parameter integer NBANKS     = 2,
  parameter integer LLR_W      = 5,
  parameter integer SOFT_EN    = 0
) (
  input  wire        clk,
  input  wire        rst_n,
  // raw page, spare-first
  input  wire        raw_valid,
  output wire        raw_ready,
  input  wire [7:0]  raw_data,
  input  wire        raw_last,
  // corrected payload / user metadata
  output wire        pay_valid,
  input  wire        pay_ready,
  output wire [7:0]  pay_data,
  output wire        pay_last,
  output wire        um_valid,
  input  wire        um_ready,
  output wire [7:0]  um_data,
  // sector status
  output wire        sst_valid,
  input  wire        sst_ready,
  output wire [2:0]  sst_code,
  output wire [7:0]  sst_nerr,
  output wire [7:0]  sst_aux,
  output wire [7:0]  sst_sector,
  output wire        sst_crc_ok,
  // page status
  output wire        pst_valid,
  input  wire        pst_ready,
  output reg  [7:0]  pst_n_corr,
  output reg  [7:0]  pst_n_uncorr,
  output reg  [7:0]  pst_n_integ,
  output reg  [7:0]  pst_n_erased,
  output reg  [7:0]  pst_max_flips,
  output reg  [15:0] pst_tot_flips,
  output reg         pst_all_erased,
  output reg  [7:0]  pst_bbm,
  output reg         pst_ok,
  output reg         pst_scrub,
  output reg         pst_frame_err,
  input  wire [7:0]  flip_thr,
  output wire        busy
);
  `include "sfecc_crc16.svh"

  localparam integer SECTORS   = PAGE_DATA / SECTOR;
  localparam integer CRCB      = (CRC_EN != 0) ? 2 : 0;
  localparam integer PAR_BYTES = (CODEC == `SFECC_CODEC_BCH) ? (R + 7) / 8 : `SFECC_LDPC_PAR_BYTES;
  localparam integer CMSG      = (CODEC == `SFECC_CODEC_BCH) ? MSG_BYTES : `SFECC_LDPC_MSG_BYTES;
  localparam integer CW_BYTES  = CMSG + PAR_BYTES;
  localparam integer RSVD      = 1;
  localparam integer SLOT      = RSVD + UMETA + CRCB + PAR_BYTES;
  localparam integer STRIDE    = PAGE_SPARE / SECTORS;
  localparam integer KSP       = CW_BYTES - SECTOR;          // codeword bytes from the spare buffer
  localparam integer IW        = $clog2(CW_BYTES + 1);
  localparam integer SW        = $clog2(SECTORS + 1);
  localparam integer XW        = $clog2(PAGE_SPARE + 1);
  localparam integer SAW       = (PAGE_SPARE > 1) ? $clog2(PAGE_SPARE) : 1;   // spare-buffer address

  generate
    if (PAGE_DATA % SECTOR != 0 || SECTORS < 1 || SECTORS > 255) begin : g_bad_sec
      `SFECC_CFG_FATAL("sfecc_page_dec: PAGE_DATA is not a whole number (1..255) of sectors")
    end
    if (CMSG != SECTOR + UMETA + CRCB || LPAD != 0) begin : g_bad_msg
      `SFECC_CFG_FATAL("sfecc_page_dec: codec message != SECTOR + UMETA + CRC (or LPAD != 0)")
    end
    if (SLOT > STRIDE) begin : g_bad_oob
      `SFECC_CFG_FATAL("sfecc_page_dec: OOB overflow -- RSVD+UMETA+CRC+PARITY exceeds the spare bytes per sector")
    end
  endgenerate

  // ================================================================== input side
  reg            cap;                       // capturing the spare area
  reg  [XW-1:0]  cj;                        // spare byte being captured
  reg  [IW-1:0]  i_idx;                     // codeword byte fed to the codec
  reg  [SW-1:0]  i_sec;
  reg  [IW-1:0]  kf;                        // spare bytes fetched for this sector
  reg  [7:0]     sbuf [0:PAGE_SPARE-1];
  reg  [7:0]     sbuf_q;
  reg            rd_v;
  reg  [7:0]     sf [0:1];                  // spare prefetch FIFO
  reg            sf_wp, sf_rp;
  reg  [1:0]     sf_cnt;
  reg            in_ferr;
  // bad-block-marker / framing queue to the page status (2 pages in flight)
  reg  [8:0]     bq [0:1];
  reg            bq_wp, bq_rp;
  reg  [1:0]     bq_cnt;

  wire           from_raw = !cap && (i_idx < IW'(SECTOR));
  wire           c_ir;
  wire           c_iv  = cap ? 1'b0 : (from_raw ? raw_valid : (sf_cnt != 2'd0));
  wire [7:0]     c_id  = from_raw ? raw_data : sf[sf_rp];
  wire           c_il  = (i_idx == IW'(CW_BYTES - 1));
  wire           c_ifire = c_iv && c_ir;
  assign raw_ready = cap ? (bq_cnt != 2'd2 || cj != '0) : (from_raw && c_ir);
  wire           cap_fire = cap && raw_valid && raw_ready;
  wire [XW-1:0]  rd_addr = XW'(i_sec) * XW'(STRIDE) + XW'(RSVD) + XW'(kf);
  wire           rd_issue = !cap && (kf < IW'(KSP)) && ({1'b0, sf_cnt} + {2'd0, rd_v} <= 3'd1);
  wire           sf_pop  = c_ifire && !from_raw;
  wire           last_raw = from_raw && (i_sec == SW'(SECTORS - 1)) && (i_idx == IW'(SECTOR - 1));

  always_ff @(posedge clk) begin
    if (cap_fire) sbuf[cj[SAW-1:0]] <= raw_data;
    if (rd_issue) sbuf_q <= sbuf[rd_addr[SAW-1:0]];
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cap <= 1'b1; cj <= '0; i_idx <= '0; i_sec <= '0; kf <= '0; rd_v <= 1'b0;
      sf_wp <= 1'b0; sf_rp <= 1'b0; sf_cnt <= 2'd0; in_ferr <= 1'b0;
      bq_wp <= 1'b0; bq_cnt <= 2'd0;
    end else begin
      // ---- spare capture
      if (cap_fire) begin
        if (raw_last) in_ferr <= 1'b1;                       // raw_last inside the spare area
        if (cj == XW'(PAGE_SPARE - 1)) begin
          cj  <= '0;
          cap <= 1'b0;
        end else
          cj <= cj + 1'b1;
        if (cj == '0) begin
          bq[bq_wp] <= {1'b0, raw_data};                     // BBM byte; framing bit filled at page end
        end
      end
      // ---- spare prefetch for the current sector
      rd_v <= rd_issue;
      if (rd_issue) kf <= kf + 1'b1;
      if (rd_v) begin
        sf[sf_wp] <= sbuf_q;
        sf_wp     <= !sf_wp;
      end
      if (sf_pop) sf_rp <= !sf_rp;
      sf_cnt <= sf_cnt + {1'b0, rd_v} - {1'b0, sf_pop};
      // ---- codeword feed
      if (c_ifire) begin
        if (from_raw && (raw_last != last_raw)) in_ferr <= 1'b1;
        if (c_il) begin
          i_idx <= '0;
          kf    <= '0;
          if (i_sec == SW'(SECTORS - 1)) begin
            i_sec     <= '0;
            cap       <= 1'b1;
            bq[bq_wp] <= {in_ferr, bq[bq_wp][7:0]};
            bq_wp     <= !bq_wp;
            in_ferr   <= 1'b0;
          end else
            i_sec <= i_sec + 1'b1;
        end else
          i_idx <= i_idx + 1'b1;
      end
      bq_cnt <= bq_cnt + {1'b0, c_ifire && c_il && (i_sec == SW'(SECTORS - 1))} -
                {1'b0, pst_valid && pst_ready};
    end
  end

  // ================================================================== codec
  wire       c_ov, c_ol, c_sv, c_sferr, c_busy;
  wire       c_or, c_sr;
  wire [7:0] c_od, c_snerr, c_saux;
  wire [1:0] c_scode;
  sfecc_codec_dec #(.CODEC(CODEC), .GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .R(R), .MSG_BYTES(MSG_BYTES),
                    .LPAD(LPAD), .MASK(MASK), .NBANKS(NBANKS), .LLR_W(LLR_W), .SOFT_EN(SOFT_EN)) u_codec (
    .clk, .rst_n, .in_valid(c_iv), .in_ready(c_ir), .in_data(c_id), .in_last(c_il),
    .in_llr({8*LLR_W{1'b0}}),
    .out_valid(c_ov), .out_ready(c_or), .out_data(c_od), .out_last(c_ol),
    .st_valid(c_sv), .st_ready(c_sr), .st_code(c_scode), .st_nerr(c_snerr), .st_aux(c_saux),
    .st_frame_err(c_sferr), .busy(c_busy));

  // ================================================================== output side
  reg  [IW-1:0] o_idx;
  reg  [SW-1:0] o_sec;
  reg  [15:0]   crc_c;
  reg  [7:0]    crc_hi;
  reg  [1:0]    cqm;                        // CRC verdicts awaiting their codec status (2-entry FIFO)
  reg           cq_wp, cq_rp;
  reg  [1:0]    cq_cnt;
  reg  [SW-1:0] s_sec;                      // sector of the next status
  // page accumulators
  reg  [7:0]    a_corr, a_uncorr, a_integ, a_erased, a_max;
  reg  [15:0]   a_tot;
  reg           pst_pend;

  wire o_pay = (o_idx < IW'(SECTOR));
  wire o_um  = !o_pay && (o_idx < IW'(SECTOR + UMETA));
  assign pay_valid = c_ov && o_pay;
  assign pay_data  = c_od;
  assign pay_last  = o_pay && (o_sec == SW'(SECTORS - 1)) && (o_idx == IW'(SECTOR - 1));
  assign um_valid  = c_ov && o_um;
  assign um_data   = c_od;
  assign c_or      = o_pay ? pay_ready : (o_um ? um_ready : 1'b1);
  wire o_fire      = c_ov && c_or;
  wire o_lastmsg   = (o_idx == IW'(CMSG - 1));
  wire crc_ok_now  = (CRC_EN == 0) ? 1'b1 : (crc_c == {crc_hi, c_od});

  // sector status
  wire cq_head     = cqm[cq_rp];
  wire s_ok        = !pst_pend && (cq_cnt != 2'd0);
  assign sst_valid = c_sv && s_ok;
  assign c_sr      = sst_ready && s_ok;
  wire s_fire      = sst_valid && sst_ready;
  assign sst_code  = (c_scode == `SFECC_ST_UNCORR) ? `SFECC_SS_UNCORR :
                     (c_scode == `SFECC_ST_ERASED) ? `SFECC_SS_ERASED :
                     (!cq_head)                    ? `SFECC_SS_INTEGRITY :
                     {1'b0, c_scode};
  assign sst_nerr   = c_snerr;
  assign sst_aux    = c_saux;
  assign sst_sector = {{(8-SW){1'b0}}, s_sec};
  assign sst_crc_ok = cq_head;
  assign pst_valid  = pst_pend;

  wire       is_corr = (sst_code == `SFECC_SS_CORRECTED);
  wire       is_unc  = (sst_code == `SFECC_SS_UNCORR);
  wire       is_int  = (sst_code == `SFECC_SS_INTEGRITY);
  wire       is_era  = (sst_code == `SFECC_SS_ERASED);
  wire [7:0] n_corr  = a_corr + {7'd0, is_corr};
  wire [7:0] n_unc   = a_uncorr + {7'd0, is_unc};
  wire [7:0] n_int   = a_integ + {7'd0, is_int};
  wire [7:0] n_era   = a_erased + {7'd0, is_era};
  wire [7:0] n_max   = (c_snerr > a_max) ? c_snerr : a_max;
  wire [15:0] n_tot  = a_tot + {8'd0, c_snerr};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      o_idx <= '0; o_sec <= '0; crc_c <= 16'hFFFF; crc_hi <= 8'h00; cqm <= 2'b00; cq_wp <= 1'b0; cq_rp <= 1'b0;
      cq_cnt <= 2'd0;
      s_sec <= '0; a_corr <= '0; a_uncorr <= '0; a_integ <= '0; a_erased <= '0; a_max <= '0; a_tot <= '0;
      pst_pend <= 1'b0; bq_rp <= 1'b0;
      pst_n_corr <= '0; pst_n_uncorr <= '0; pst_n_integ <= '0; pst_n_erased <= '0; pst_max_flips <= '0;
      pst_tot_flips <= '0; pst_all_erased <= 1'b0; pst_bbm <= 8'hFF; pst_ok <= 1'b0; pst_scrub <= 1'b0;
      pst_frame_err <= 1'b0;
    end else begin
      // ---- message bytes: CRC check
      if (o_fire) begin
        if (o_pay || o_um) crc_c <= sfecc_crc16_upd(crc_c, c_od);
        if (o_idx == IW'(SECTOR + UMETA)) crc_hi <= c_od;
        if (o_lastmsg) begin
          o_idx <= '0;
          crc_c <= 16'hFFFF;
          o_sec <= (o_sec == SW'(SECTORS - 1)) ? '0 : o_sec + 1'b1;
        end else
          o_idx <= o_idx + 1'b1;
      end
      // CRC verdict FIFO (pointer based: the pop is a pointer toggle, not a shift)
      if (o_fire && o_lastmsg) begin
        cqm[cq_wp] <= crc_ok_now;
        cq_wp      <= !cq_wp;
      end
      if (s_fire) cq_rp <= !cq_rp;
      cq_cnt <= cq_cnt + {1'b0, o_fire && o_lastmsg} - {1'b0, s_fire};
      // ---- sector status accumulation
      if (s_fire) begin
        if (s_sec == SW'(SECTORS - 1)) begin
          s_sec          <= '0;
          pst_pend       <= 1'b1;
          pst_n_corr     <= n_corr;
          pst_n_uncorr   <= n_unc;
          pst_n_integ    <= n_int;
          pst_n_erased   <= n_era;
          pst_max_flips  <= n_max;
          pst_tot_flips  <= n_tot;
          pst_all_erased <= (n_era == 8'(SECTORS));
          pst_ok         <= (n_unc == 8'd0) && (n_int == 8'd0);
          pst_scrub      <= (flip_thr != 8'd0) && (n_max >= flip_thr);
          pst_bbm        <= bq[bq_rp][7:0];
          pst_frame_err  <= bq[bq_rp][8];
          a_corr <= '0; a_uncorr <= '0; a_integ <= '0; a_erased <= '0; a_max <= '0; a_tot <= '0;
        end else begin
          s_sec    <= s_sec + 1'b1;
          a_corr   <= n_corr;  a_uncorr <= n_unc;  a_integ <= n_int;  a_erased <= n_era;
          a_max    <= n_max;   a_tot    <= n_tot;
        end
      end
      if (pst_valid && pst_ready) begin
        pst_pend <= 1'b0;
        bq_rp    <= !bq_rp;
      end
    end
  end

  assign busy = !cap || (cj != '0) || c_busy || c_ov || pst_pend || (o_idx != '0) || (o_sec != '0);
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = c_ol ^ c_sferr ^ ^rd_addr ^ ^cj;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
