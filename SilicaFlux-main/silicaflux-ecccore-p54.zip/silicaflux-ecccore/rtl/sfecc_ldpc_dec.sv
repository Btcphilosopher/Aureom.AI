// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_ldpc_dec -- layered offset-min-sum LDPC decoder
// (proof of concept; QC-LDPC(128,64), Z = 16, 4 layers x 8 block columns)
//
// Bit-exact with QCLDPC.decode_oms_fixed() in ref/sfecc_ldpc.py:
//   load     16 stored bytes (+ optional per-bit soft LLRs, SOFT_EN) -> channel LLRs,
//            erased-page mask removed (parity LLRs negated where MASK = 1), P = LLR, R = 0
//   check    H x = 0 on the signs of P (x = 1 where P < 0) -> done
//   layer l  (one block row = Z = 16 independent checks, one cycle):
//            Q = sat8(P - R_old); min1/argmin(first)/min2 of min(|Q|,31); total sign;
//            R_new = sign * max(min - OFFSET, 0); P = sat8(Q + R_new)
//   iterate  4 layer cycles + 1 check cycle per iteration, at most MAXIT iterations
//   output   8 message bytes (hard decisions), then status {code, nerr, aux = iterations}
//   status   CLEAN (no iteration needed) / CORRECTED / ERASED (stored word all ones) / UNCORR
// Circulant routing: row r of layer l touches variable c*Z + (r + shift(l,c)) mod Z of every
// active block column c -- a fixed rotation per (l, c), i.e. a 4:1 mux of wires.
// Not pipelined: one codeword at a time (proof of concept; see docs/05 for a production
// architecture).  Same ports as sfecc_bch_dec plus in_llr (codec interface).
// Classification: SYNTHESIZABLE (proof of concept)
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfecc_ldpc_dec #(
  parameter integer LLR_W   = 5,
  parameter integer SOFT_EN = 0,
  parameter integer MAXIT   = 20,
  parameter integer OFFSET  = 1
) (
  input  wire               clk,
  input  wire               rst_n,
  input  wire               in_valid,
  output wire               in_ready,
  input  wire [7:0]         in_data,
  input  wire               in_last,
  input  wire [8*LLR_W-1:0] in_llr,           // lane j = stream bit j of the byte (j = 0 is the MSB)
  output wire               out_valid,
  input  wire               out_ready,
  output wire [7:0]         out_data,
  output wire               out_last,
  output wire               st_valid,
  input  wire               st_ready,
  output reg  [1:0]         st_code,
  output reg  [7:0]         st_nerr,
  output reg  [7:0]         st_aux,
  output reg                st_frame_err,
  output wire               busy
);
  /* verilator lint_off UNUSEDPARAM */
  `include "sfecc_ldpc_code.svh"                   // (LDPC_GEN is used by the encoder only)
  /* verilator lint_on UNUSEDPARAM */

  localparam integer Z = 16, JB = 4, KB = 8, N = 128, K = 64;
  localparam integer PW = 8, RW = 6;
  localparam integer PMAX = (1 << (PW - 1)) - 1;     // 127
  localparam integer RMAX = (1 << (RW - 1)) - 1;     // 31
  localparam integer HARD = (1 << (LLR_W - 1)) - 1;

  // ------------------------------------------------------------------ state
  localparam [2:0] S_IN = 3'd0, S_CHK = 3'd1, S_LAY = 3'd2, S_OUT = 3'd3, S_ST = 3'd4;
  reg [2:0]        st;
  reg [N*PW-1:0]   P;                          // posteriors, variable v at [v*PW +: PW]
  reg [JB*Z*KB*RW-1:0] R;                      // check messages, (l, r, c) at [((l*Z+r)*KB+c)*RW +: RW]
  reg [N-1:0]      xin;                        // input hard decisions (mask removed)
  reg [3:0]        bcnt;
  reg [1:0]        lay;
  reg [7:0]        it;
  reg              ferr;
  reg              succ;

  assign in_ready  = (st == S_IN);
  assign busy      = (st != S_IN) || (bcnt != 4'd0);

  // ------------------------------------------------------------------ helpers
  localparam signed [PW+1:0] PMAX_X = (PW+2)'(PMAX);
  localparam signed [PW-1:0] PMAX_P = PW'(PMAX);
  function automatic signed [PW-1:0] sat_p(input signed [PW+1:0] v);
    begin
      if (v > PMAX_X)       sat_p = PMAX_P;
      else if (v < -PMAX_X) sat_p = -PMAX_P;
      else                  sat_p = v[PW-1:0];
    end
  endfunction
  function automatic integer shift_of(input integer l, input integer c);
    shift_of = {28'd0, LDPC_BASE[(l*KB+c)*5 +: 4]};
  endfunction
  function automatic integer act_of(input integer l, input integer c);
    act_of = {31'd0, LDPC_BASE[(l*KB+c)*5 + 4]};
  endfunction

  // hard decisions and syndrome
  wire [N-1:0] xh;
  genvar gv;
  generate
    for (gv = 0; gv < N; gv = gv + 1) begin : g_x
      assign xh[gv] = P[gv*PW + PW - 1];
    end
  endgenerate
  // Combinational blocks are functions used in continuous assignments (Icarus Verilog 12 loops
  // forever on always_comb blocks that re-assign a variable they also read).
  function automatic syn_nz_f(input [N-1:0] x);
    integer sl, sr, sc;
    reg p, nz;
    begin
      nz = 1'b0;
      for (sl = 0; sl < JB; sl = sl + 1)
        for (sr = 0; sr < Z; sr = sr + 1) begin
          p = 1'b0;
          for (sc = 0; sc < KB; sc = sc + 1)
            if (act_of(sl, sc) != 0) p = p ^ x[sc*Z + (sr + shift_of(sl, sc)) % Z];
          nz = nz | p;
        end
      syn_nz_f = nz;
    end
  endfunction
  wire syn_nz = syn_nz_f(xh);

  // ------------------------------------------------------------------ one layer of check-node updates
  // All accesses use constant indices under a 4-way layer select (no variable shifters).
  function automatic [Z*KB*RW-1:0] rsel_f(input [JB*Z*KB*RW-1:0] Rv, input [1:0] ly);
    integer ls;
    begin
      rsel_f = '0;
      for (ls = 0; ls < JB; ls = ls + 1)
        if (ly == ls[1:0]) rsel_f = Rv[ls*Z*KB*RW +: Z*KB*RW];
    end
  endfunction
  // returns {R of the layer (new), P after the layer}
  function automatic [Z*KB*RW+N*PW-1:0] layer_f(input [N*PW-1:0] Pv, input [Z*KB*RW-1:0] Rc, input [1:0] ly);
    reg [N*PW-1:0]      pn;
    reg [Z*KB*RW-1:0]   rl;
    reg [KB*PW-1:0]     qv;                    // Q per block column
    reg [KB*RW-1:0]     mgv;                   // min(|Q|, 31), 32 for an inactive column
    reg [KB-1:0]        sgv, actv;
    reg signed [PW-1:0] pin, qc;
    reg [RW-1:0]        min1, min2, mag;
    reg [3:0]           idx1;
    reg                 stot;
    reg signed [RW-1:0] rold, rnew;
    reg signed [PW+1:0] diff;
    reg [PW-1:0]        aq;
    reg signed [PW-1:0] pnew;
    integer r, c, l;
    begin
      pn = Pv;
      rl = '0;
      for (r = 0; r < Z; r = r + 1) begin
        stot = 1'b0;
        for (c = 0; c < KB; c = c + 1) begin
          actv[c] = 1'b0;
          pin     = '0;
          for (l = 0; l < JB; l = l + 1)
            if (ly == l[1:0] && act_of(l, c) != 0) begin
              actv[c] = 1'b1;
              pin     = Pv[(c * Z + (r + shift_of(l, c)) % Z) * PW +: PW];
            end
          rold = Rc[(r*KB + c)*RW +: RW];
          diff = $signed({{2{pin[PW-1]}}, pin}) - $signed({{(PW+2-RW){rold[RW-1]}}, rold});
          qc   = sat_p(diff);
          qv[c*PW +: PW] = qc;
          sgv[c] = qc[PW-1];
          aq     = qc[PW-1] ? -qc : qc;
          mgv[c*RW +: RW] = !actv[c] ? RW'(RMAX + 1) : ((aq > PW'(RMAX)) ? RW'(RMAX) : aq[RW-1:0]);
          if (actv[c]) stot = stot ^ sgv[c];
        end
        min1 = RW'(RMAX + 1); idx1 = 4'd15;
        for (c = 0; c < KB; c = c + 1)
          if (mgv[c*RW +: RW] < min1) begin min1 = mgv[c*RW +: RW]; idx1 = c[3:0]; end
        min2 = RW'(RMAX + 1);
        for (c = 0; c < KB; c = c + 1)
          if (c[3:0] != idx1 && mgv[c*RW +: RW] < min2) min2 = mgv[c*RW +: RW];
        for (c = 0; c < KB; c = c + 1) begin
          mag  = (c[3:0] == idx1) ? min2 : min1;
          mag  = (mag > RW'(RMAX)) ? RW'(RMAX) : mag;
          mag  = (mag > RW'(OFFSET)) ? mag - RW'(OFFSET) : RW'(0);
          rnew = (stot ^ sgv[c]) ? -$signed(mag) : $signed(mag);
          qc   = qv[c*PW +: PW];
          diff = $signed({{2{qc[PW-1]}}, qc}) + $signed({{(PW+2-RW){rnew[RW-1]}}, rnew});
          pnew = sat_p(diff);
          if (actv[c]) rl[(r*KB + c)*RW +: RW] = rnew;
          for (l = 0; l < JB; l = l + 1)
            if (ly == l[1:0] && act_of(l, c) != 0)
              pn[(c * Z + (r + shift_of(l, c)) % Z) * PW +: PW] = pnew;
        end
      end
      layer_f = {rl, pn};
    end
  endfunction
  wire [Z*KB*RW-1:0]         R_cur  = rsel_f(R, lay);
  wire [Z*KB*RW+N*PW-1:0]    lay_o  = layer_f(P, R_cur, lay);
  wire [N*PW-1:0]            P_nx   = lay_o[N*PW-1:0];         // P after the current layer
  wire [Z*KB*RW-1:0]         R_lay  = lay_o[Z*KB*RW+N*PW-1:N*PW];  // new R of the current layer

  // ------------------------------------------------------------------ input LLRs of one byte
  function automatic [8*PW-1:0] llr_f(input [7:0] din, input [8*LLR_W-1:0] lin, input [3:0] bc);
    reg signed [LLR_W-1:0] lv;
    reg signed [PW-1:0]    pv;
    integer bj, idx;
    begin
      llr_f = '0;
      for (bj = 0; bj < 8; bj = bj + 1) begin
        idx = {25'd0, bc, 3'b000} + bj;
        if (SOFT_EN != 0) lv = lin[bj*LLR_W +: LLR_W];
        else              lv = din[7 - bj] ? -$signed(LLR_W'(HARD)) : $signed(LLR_W'(HARD));
        pv = {{(PW-LLR_W){lv[LLR_W-1]}}, lv};
        if (idx >= K && LDPC_MASK[idx - K]) pv = -pv;
        llr_f[bj*PW +: PW] = pv;
      end
    end
  endfunction
  wire [8*PW-1:0] llr_b = llr_f(in_data, in_llr, bcnt);

  // ------------------------------------------------------------------ output
  reg  [3:0] ocnt;
  wire [7:0] obyte;
  generate
    for (gv = 0; gv < 8; gv = gv + 1) begin : g_ob
      assign obyte[7 - gv] = xh[{ocnt[2:0], 3'b000} + gv];
    end
  endgenerate
  assign out_valid = (st == S_OUT);
  assign out_data  = obyte;
  assign out_last  = (ocnt == 4'd7);
  assign st_valid  = (st == S_ST);

  function automatic [7:0] popc128(input [N-1:0] v);
    integer i;
    begin
      popc128 = 8'd0;
      for (i = 0; i < N; i = i + 1) popc128 = popc128 + {7'd0, v[i]};
    end
  endfunction
  wire [N-1:0] stored_hd = {xh[N-1:K] ^ LDPC_MASK, xh[K-1:0]};

  integer wi, wb, wl;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IN; P <= '0; R <= '0; xin <= '0; bcnt <= '0; lay <= '0; it <= '0; ferr <= 1'b0; succ <= 1'b0;
      ocnt <= '0; st_code <= 2'd0; st_nerr <= '0; st_aux <= '0; st_frame_err <= 1'b0;
    end else begin
      case (st)
        S_IN: if (in_valid) begin
          for (wb = 0; wb < 16; wb = wb + 1)
            if (bcnt == wb[3:0])
              for (wi = 0; wi < 8; wi = wi + 1) begin
                P[(wb*8 + wi)*PW +: PW] <= llr_b[wi*PW +: PW];
                xin[wb*8 + wi]          <= llr_b[wi*PW + PW - 1];
              end
          ferr <= ferr | (in_last != (bcnt == 4'd15));
          bcnt <= bcnt + 1'b1;
          if (bcnt == 4'd15) begin
            st  <= S_CHK;
            R   <= '0;
            it  <= '0;
            lay <= '0;
          end
        end
        S_CHK: begin
          if (!syn_nz || it == 8'(MAXIT)) begin
            succ <= !syn_nz;
            st   <= S_OUT;
            ocnt <= '0;
          end else begin
            it  <= it + 1'b1;
            lay <= '0;
            st  <= S_LAY;
          end
        end
        S_LAY: begin
          P <= P_nx;
          for (wl = 0; wl < JB; wl = wl + 1)
            if (lay == wl[1:0]) R[wl*Z*KB*RW +: Z*KB*RW] <= R_lay;
          lay <= lay + 1'b1;
          if (lay == 2'd3) st <= S_CHK;
        end
        S_OUT: if (out_ready) begin
          ocnt <= ocnt + 1'b1;
          if (ocnt == 4'd7) begin
            st           <= S_ST;
            st_aux       <= it;
            st_frame_err <= ferr;
            if (!succ) begin
              st_code <= `SFECC_ST_UNCORR;     st_nerr <= 8'd0;
            end else begin
              st_nerr <= popc128(xin ^ xh);
              if (&stored_hd)       st_code <= `SFECC_ST_ERASED;
              else if (it == 8'd0)  st_code <= `SFECC_ST_CLEAN;
              else                  st_code <= `SFECC_ST_CORRECTED;
            end
          end
        end
        default: if (st_ready) begin                // S_ST
          st   <= S_IN;
          ferr <= 1'b0;
        end
      endcase
    end
  end
endmodule

`default_nettype wire
