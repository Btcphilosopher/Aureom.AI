// ECCCore RTL file list (compile order); include paths: rtl, rtl/generated
rtl/sfecc_bch_enc.sv
rtl/sfecc_bch_syn.sv
rtl/sfecc_bch_kes.sv
rtl/sfecc_bch_chien.sv
rtl/sfecc_bch_dec.sv
rtl/sfecc_ldpc_enc.sv
rtl/sfecc_ldpc_dec.sv
rtl/sfecc_codec_enc.sv
rtl/sfecc_codec_dec.sv
rtl/sfecc_page_enc.sv
rtl/sfecc_page_dec.sv
rtl/silicaflux_storage_ecc.sv
