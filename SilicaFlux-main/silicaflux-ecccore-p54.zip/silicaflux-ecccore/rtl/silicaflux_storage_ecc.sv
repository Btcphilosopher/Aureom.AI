// =============================================================================
// SilicaFlux-STORE :: Project 54 -- ECCCore
// silicaflux_storage_ecc -- hardware NAND error-correction engine (primary RTL)
// Aureom.AI | SilicaFlux-STORE
//
//   program path:  payload + user meta --> [page encoder: CRC-16 + BCH encoder] --> raw page (column order)
//   read path:     raw page (spare-first) --> [page decoder: BCH decoder + CRC check] --> payload, meta,
//                                                                    sector status, page status
//   control:       32-bit register window (P51 firmware-page style rb_*), statistics, RAS events, IRQ
//
// Code: binary primitive narrow-sense BCH over GF(2^GF_M), t = T, one codeword per
// SECTOR-byte sector, split OOB layout (RSVD/BBM | UMETA | CRC-16 | PARITY per slot),
// erased-page mask, 8 bits/cycle encoder and decoder.  CODEC selects the codec behind
// the replaceable codec interface (BCH = production path; LDPC = proof of concept,
// docs/05).  Parameter sets: rtl/generated/sfecc_cfg.svh (`SFECC_PAGE_<cfg>).
//
// What this is NOT: a claim that the configured BCH strength suffices for a given NAND
// technology (TLC/QLC need LDPC with soft information, docs/05), nor verified SSD
// endurance.  RTL simulation and Yosys / nextpnr estimates only.
//
// Register map (word offsets of rb_addr[7:2]; see docs/02_ARCHITECTURE.md §6)
//   0x00 ID        "SECC"                    0x24 PAGES_DEC
//   0x04 VERSION                             0x28 CW_DEC
//   0x08 CFG0      {sectors, codec, t, m}    0x2C CW_CORRECTED
//   0x0C CFG1      {umeta, parity B, sector} 0x30 BITS_CORRECTED
//   0x10 CFG2      {spare, data} bytes       0x34 CW_UNCORR
//   0x14 CTRL      [0] W1 clear counters     0x38 CW_INTEGRITY
//                  [8] irq enable            0x3C CW_ERASED
//                  [23:16] scrub flip thr    0x40 PAGES_SCRUB
//   0x18 STATUS    [0] enc busy [1] dec busy 0x44 LAST_FAIL {page[20:0], code[2:0], sector[7:0]}
//   0x1C IRQ       [0] pending (W1C)         0x48 MAX_FLIPS (running maximum)
//   0x20 PAGES_ENC
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module silicaflux_storage_ecc #(
  parameter integer CODEC      = `SFECC_CODEC_BCH,
  parameter integer GF_M       = 13,
  parameter integer GF_PRIM    = 'h201B,
  parameter integer T          = 8,
  parameter integer R          = 104,
  parameter [R:0]   GPOLY      = 105'h115f914e07b0c138741c5c4fb23,
  parameter integer MSG_BYTES  = 514,
  parameter integer LPAD       = 0,
  parameter [R-1:0] MASK       = 104'h6443109f38abc78fb78bc9a779,
  parameter integer PAGE_DATA  = 2048,
  parameter integer PAGE_SPARE = 64,
  parameter integer SECTOR     = 512,
  parameter integer UMETA      = 0,
  parameter integer CRC_EN     = 1,
  parameter integer NBANKS     = 2,
  parameter integer FLIP_THR   = (3 * T + 3) / 4        // reset value of the scrub threshold
) (
  input  wire        clk,
  input  wire        rst_n,
  // ---------------- register window
  input  wire        rb_sel,
  input  wire        rb_we,
  input  wire [7:0]  rb_addr,
  input  wire [31:0] rb_wdata,
  output reg  [31:0] rb_rdata,
  // ---------------- program path
  input  wire        wr_pay_valid,
  output wire        wr_pay_ready,
  input  wire [7:0]  wr_pay_data,
  input  wire        wr_pay_last,
  input  wire        wr_um_valid,
  output wire        wr_um_ready,
  input  wire [7:0]  wr_um_data,
  output wire        wr_raw_valid,
  input  wire        wr_raw_ready,
  output wire [7:0]  wr_raw_data,
  output wire        wr_raw_last,
  // ---------------- read path
  input  wire        rd_raw_valid,
  output wire        rd_raw_ready,
  input  wire [7:0]  rd_raw_data,
  input  wire        rd_raw_last,
  output wire        rd_pay_valid,
  input  wire        rd_pay_ready,
  output wire [7:0]  rd_pay_data,
  output wire        rd_pay_last,
  output wire        rd_um_valid,
  input  wire        rd_um_ready,
  output wire [7:0]  rd_um_data,
  output wire        rd_sst_valid,
  input  wire        rd_sst_ready,
  output wire [2:0]  rd_sst_code,
  output wire [7:0]  rd_sst_nerr,
  output wire [7:0]  rd_sst_aux,
  output wire [7:0]  rd_sst_sector,
  output wire        rd_sst_crc_ok,
  output wire        rd_pst_valid,
  input  wire        rd_pst_ready,
  output wire [7:0]  rd_pst_n_corr,
  output wire [7:0]  rd_pst_n_uncorr,
  output wire [7:0]  rd_pst_n_integ,
  output wire [7:0]  rd_pst_n_erased,
  output wire [7:0]  rd_pst_max_flips,
  output wire [15:0] rd_pst_tot_flips,
  output wire        rd_pst_all_erased,
  output wire [7:0]  rd_pst_bbm,
  output wire        rd_pst_ok,
  output wire        rd_pst_scrub,
  output wire        rd_pst_frame_err,
  // ---------------- RAS events (one-cycle pulses) and interrupt
  output reg         ev_corrected,        // a codeword was corrected (>= 1 bit)
  output reg         ev_uncorr,           // decoder failure (detected uncorrectable)
  output reg         ev_integrity,        // CRC-16 caught a miscorrection / undetected error
  output reg         ev_scrub,            // a page reached the flip threshold (refresh / relocate hint)
  output wire        irq,
  output wire        enc_busy,
  output wire        dec_busy
);
  localparam integer SECTORS   = PAGE_DATA / SECTOR;
  localparam integer PAR_BYTES = (CODEC == `SFECC_CODEC_BCH) ? (R + 7) / 8 : `SFECC_LDPC_PAR_BYTES;

  // ================================================================== registers
  reg  [7:0]  flip_thr;
  reg         irq_en, irq_pend;
  reg  [31:0] c_pg_enc, c_pg_dec, c_cw_dec, c_cw_corr, c_bits, c_cw_unc, c_cw_int, c_cw_era, c_pg_scrub;
  reg  [31:0] last_fail;
  reg  [7:0]  max_flips;
  wire        wr_ctrl = rb_sel && rb_we && (rb_addr[7:2] == 6'h05);
  wire        clr     = wr_ctrl && rb_wdata[0];
  wire        wr_irq  = rb_sel && rb_we && (rb_addr[7:2] == 6'h07);

  // ================================================================== engines
  wire enc_ferr;
  sfecc_page_enc #(.CODEC(CODEC), .GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .R(R), .GPOLY(GPOLY),
                   .MSG_BYTES(MSG_BYTES), .LPAD(LPAD), .MASK(MASK), .PAGE_DATA(PAGE_DATA),
                   .PAGE_SPARE(PAGE_SPARE), .SECTOR(SECTOR), .UMETA(UMETA), .CRC_EN(CRC_EN)) u_enc (
    .clk, .rst_n,
    .pay_valid(wr_pay_valid), .pay_ready(wr_pay_ready), .pay_data(wr_pay_data), .pay_last(wr_pay_last),
    .um_valid(wr_um_valid), .um_ready(wr_um_ready), .um_data(wr_um_data),
    .raw_valid(wr_raw_valid), .raw_ready(wr_raw_ready), .raw_data(wr_raw_data), .raw_last(wr_raw_last),
    .frame_err(enc_ferr), .busy(enc_busy));

  sfecc_page_dec #(.CODEC(CODEC), .GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .R(R), .GPOLY(GPOLY),
                   .MSG_BYTES(MSG_BYTES), .LPAD(LPAD), .MASK(MASK), .PAGE_DATA(PAGE_DATA),
                   .PAGE_SPARE(PAGE_SPARE), .SECTOR(SECTOR), .UMETA(UMETA), .CRC_EN(CRC_EN),
                   .NBANKS(NBANKS)) u_dec (
    .clk, .rst_n,
    .raw_valid(rd_raw_valid), .raw_ready(rd_raw_ready), .raw_data(rd_raw_data), .raw_last(rd_raw_last),
    .pay_valid(rd_pay_valid), .pay_ready(rd_pay_ready), .pay_data(rd_pay_data), .pay_last(rd_pay_last),
    .um_valid(rd_um_valid), .um_ready(rd_um_ready), .um_data(rd_um_data),
    .sst_valid(rd_sst_valid), .sst_ready(rd_sst_ready), .sst_code(rd_sst_code), .sst_nerr(rd_sst_nerr),
    .sst_aux(rd_sst_aux), .sst_sector(rd_sst_sector), .sst_crc_ok(rd_sst_crc_ok),
    .pst_valid(rd_pst_valid), .pst_ready(rd_pst_ready), .pst_n_corr(rd_pst_n_corr),
    .pst_n_uncorr(rd_pst_n_uncorr), .pst_n_integ(rd_pst_n_integ), .pst_n_erased(rd_pst_n_erased),
    .pst_max_flips(rd_pst_max_flips), .pst_tot_flips(rd_pst_tot_flips), .pst_all_erased(rd_pst_all_erased),
    .pst_bbm(rd_pst_bbm), .pst_ok(rd_pst_ok), .pst_scrub(rd_pst_scrub), .pst_frame_err(rd_pst_frame_err),
    .flip_thr(flip_thr), .busy(dec_busy));

  // ================================================================== statistics / events
  // the status handshakes are snooped into registers first, so the 32-bit statistics adders are not
  // in series with the ready/valid handshake logic (one cycle of extra latency for counters/events)
  wire s_fire_c = rd_sst_valid && rd_sst_ready;
  wire p_fire_c = rd_pst_valid && rd_pst_ready;
  wire e_fire_c = wr_raw_valid && wr_raw_ready && wr_raw_last;
  reg        s_fire, p_fire, e_fire, s_scrub;
  reg  [2:0] s_code;
  reg  [7:0] s_nerr, s_sec;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_fire <= 1'b0; p_fire <= 1'b0; e_fire <= 1'b0; s_scrub <= 1'b0; s_code <= '0; s_nerr <= '0; s_sec <= '0;
    end else begin
      s_fire  <= s_fire_c;
      p_fire  <= p_fire_c;
      e_fire  <= e_fire_c;
      s_code  <= rd_sst_code;
      s_nerr  <= rd_sst_nerr;
      s_sec   <= rd_sst_sector;
      s_scrub <= rd_pst_scrub;
    end
  end
  assign irq = irq_pend;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      flip_thr <= 8'(FLIP_THR); irq_en <= 1'b0; irq_pend <= 1'b0;
      c_pg_enc <= '0; c_pg_dec <= '0; c_cw_dec <= '0; c_cw_corr <= '0; c_bits <= '0; c_cw_unc <= '0;
      c_cw_int <= '0; c_cw_era <= '0; c_pg_scrub <= '0; last_fail <= '0; max_flips <= '0;
      ev_corrected <= 1'b0; ev_uncorr <= 1'b0; ev_integrity <= 1'b0; ev_scrub <= 1'b0;
    end else begin
      ev_corrected <= s_fire && (s_code == `SFECC_SS_CORRECTED);
      ev_uncorr    <= s_fire && (s_code == `SFECC_SS_UNCORR);
      ev_integrity <= s_fire && (s_code == `SFECC_SS_INTEGRITY);
      ev_scrub     <= p_fire && s_scrub;
      if (wr_ctrl) begin
        irq_en   <= rb_wdata[8];
        flip_thr <= rb_wdata[23:16];
      end
      if (wr_irq && rb_wdata[0]) irq_pend <= 1'b0;
      if (clr) begin
        c_pg_enc <= '0; c_pg_dec <= '0; c_cw_dec <= '0; c_cw_corr <= '0; c_bits <= '0; c_cw_unc <= '0;
        c_cw_int <= '0; c_cw_era <= '0; c_pg_scrub <= '0; last_fail <= '0; max_flips <= '0;
      end else begin
        if (e_fire) c_pg_enc <= c_pg_enc + 1;
        if (s_fire) begin
          c_cw_dec <= c_cw_dec + 1;
          if (s_code == `SFECC_SS_CORRECTED) c_cw_corr <= c_cw_corr + 1;
          if (s_code == `SFECC_SS_UNCORR)    c_cw_unc  <= c_cw_unc + 1;
          if (s_code == `SFECC_SS_INTEGRITY) c_cw_int  <= c_cw_int + 1;
          if (s_code == `SFECC_SS_ERASED)    c_cw_era  <= c_cw_era + 1;
          c_bits <= c_bits + {24'd0, s_nerr};
          if (s_nerr > max_flips) max_flips <= s_nerr;
          if (s_code == `SFECC_SS_UNCORR || s_code == `SFECC_SS_INTEGRITY) begin
            last_fail <= {c_pg_dec[20:0], s_code, s_sec};
            if (irq_en) irq_pend <= 1'b1;
          end
        end
        if (p_fire) begin
          c_pg_dec <= c_pg_dec + 1;
          if (s_scrub) c_pg_scrub <= c_pg_scrub + 1;
        end
      end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_rb = ^{rb_wdata[31:24], rb_wdata[15:9], rb_wdata[7:1], rb_addr[1:0]};
  /* verilator lint_on UNUSEDSIGNAL */
  always_comb begin
    case (rb_addr[7:2])
      6'h00:   rb_rdata = `SFECC_ID;
      6'h01:   rb_rdata = `SFECC_VERSION;
      6'h02:   rb_rdata = {12'(SECTORS), 4'(CODEC), 8'(T), 8'(GF_M)};
      6'h03:   rb_rdata = {8'(UMETA), 8'(PAR_BYTES), 16'(SECTOR)};
      6'h04:   rb_rdata = {16'(PAGE_SPARE), 16'(PAGE_DATA)};
      6'h05:   rb_rdata = {8'd0, flip_thr, 7'd0, irq_en, 7'd0, 1'b0};
      6'h06:   rb_rdata = {29'd0, enc_ferr, dec_busy, enc_busy};
      6'h07:   rb_rdata = {31'd0, irq_pend};
      6'h08:   rb_rdata = c_pg_enc;
      6'h09:   rb_rdata = c_pg_dec;
      6'h0A:   rb_rdata = c_cw_dec;
      6'h0B:   rb_rdata = c_cw_corr;
      6'h0C:   rb_rdata = c_bits;
      6'h0D:   rb_rdata = c_cw_unc;
      6'h0E:   rb_rdata = c_cw_int;
      6'h0F:   rb_rdata = c_cw_era;
      6'h10:   rb_rdata = c_pg_scrub;
      6'h11:   rb_rdata = last_fail;
      6'h12:   rb_rdata = {24'd0, max_flips};
      default: rb_rdata = 32'd0;
    endcase
  end
endmodule

`default_nettype wire
