// =============================================================================
// SilicaFlux ECCCore (Project 54) :: sfecc_codec_dec (decoder half)
// Replaceable codec interface (docs/05_LDPC_RESEARCH.md §6).
//
// Every codec plugged into the page engine presents the same two blocks:
//   encoder: msg bytes (ready/valid/last) -> stored codeword bytes (msg || parity)
//   decoder: stored codeword bytes + optional per-bit soft information
//            -> msg bytes + one status word per codeword
//            status = {code[1:0] (CLEAN/CORRECTED/ERASED/UNCORR), nerr[7:0]
//                      (bits corrected, saturating), aux[7:0] (LDPC: iterations)}
//            status of a codeword follows its last data byte.
// Soft input: in_llr carries 8 x LLR_W-bit signed LLRs for the 8 bits of in_data
// (bit 7 first; positive = '0' more likely).  The BCH codec is hard-decision and
// ignores it; the LDPC proof of concept uses it when SOFT_EN = 1.
// CODEC = `SFECC_CODEC_BCH (0) or `SFECC_CODEC_LDPC (1).  MSG/PAR byte counts of
// the selected codec are exported by sfecc_codec_geom (functions below) so the
// page engine can size its OOB layout and refuse codecs that do not fit.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfecc_codec_dec #(
  parameter integer CODEC     = 0,
  parameter integer GF_M      = 8,
  parameter integer GF_PRIM   = 'h11D,
  parameter integer T         = 4,
  parameter integer R         = 32,
  parameter integer MSG_BYTES = 28,
  parameter integer LPAD      = 1,
  parameter [R-1:0] MASK      = {R{1'b0}},
  parameter integer NBANKS    = 2,
  parameter integer LLR_W     = 5,
  parameter integer SOFT_EN   = 0
) (
  input  wire             clk, rst_n,
  input  wire             in_valid, output wire in_ready, input wire [7:0] in_data, input wire in_last,
  input  wire [8*LLR_W-1:0] in_llr,
  output wire             out_valid, input wire out_ready, output wire [7:0] out_data, output wire out_last,
  output wire             st_valid, input wire st_ready,
  output wire [1:0]       st_code,
  output wire [7:0]       st_nerr,
  output wire [7:0]       st_aux,
  output wire             st_frame_err,
  output wire             busy
);
  generate
    if (CODEC == `SFECC_CODEC_BCH) begin : g_bch
      localparam integer NW = $clog2(T + 1);
      wire [NW-1:0] nerr;
      sfecc_bch_dec #(.GF_M(GF_M), .GF_PRIM(GF_PRIM), .T(T), .R(R), .MSG_BYTES(MSG_BYTES), .LPAD(LPAD),
                      .MASK(MASK), .NBANKS(NBANKS)) u_dec (
        .clk, .rst_n, .in_valid, .in_ready, .in_data, .in_last,
        .out_valid, .out_ready, .out_data, .out_last,
        .st_valid, .st_ready, .st_code, .st_nerr(nerr), .st_frame_err, .busy);
      if (NW >= 8) begin : g_n8
        assign st_nerr = nerr[7:0];
      end else begin : g_nn
        assign st_nerr = {{(8-NW){1'b0}}, nerr};
      end
      assign st_aux  = 8'd0;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_llr = ^in_llr;
      /* verilator lint_on UNUSEDSIGNAL */
    end else begin : g_ldpc
      sfecc_ldpc_dec #(.LLR_W(LLR_W), .SOFT_EN(SOFT_EN)) u_dec (
        .clk, .rst_n, .in_valid, .in_ready, .in_data, .in_last, .in_llr,
        .out_valid, .out_ready, .out_data, .out_last,
        .st_valid, .st_ready, .st_code, .st_nerr, .st_aux, .st_frame_err, .busy);
    end
  endgenerate
endmodule

`default_nettype wire
