# SilicaFlux NANDLab — NAND flash digital twin and fault simulator (Project 52)

**Main sources:** [`nand_flash_model.sv`](nand_flash_model.sv) (pin-level SystemVerilog device model) and
[`nand_flash_twin.py`](nand_flash_twin.py) (Python reference twin) — Aureom.AI | SilicaFlux-STORE

A behavioural, persistent, fault-injectable digital twin of **external NAND flash devices**, built so the
SilicaFlux storage controller can be developed and verified against something that behaves like NAND:
pages, blocks and erase, a one-way 1→0 program rule, busy/ready timing, factory bad blocks, wear, retention,
read disturb, program/erase failures and power loss.

> **Status — read first.**
> * This models memory devices the controller talks to. It is **not** a claim that SilicaFlux fabricates NAND cells.
> * Device semantics are **SLC**. MLC/TLC/QLC exist only as a threshold-voltage **research model, unvalidated**.
> * Every reliability number (error rates, failure probabilities, factory-bad rate) is **illustrative**, chosen to
>   exercise controller behaviour. None of it is measured NAND reliability. Array times (tR, tPROG, tBERS, …) are
>   illustrative SLC-datasheet-range values. The ONFI asynchronous timing-mode table is a transcription to be
>   checked against the ONFI revision or datasheet you target. Only an ONFI-style **subset** is modelled; no
>   ONFI compliance is claimed. See [MODEL_LIMITATIONS.md](MODEL_LIMITATIONS.md).

## Results at a glance (bundled `outputs/`)

* **Python reference suite: 32/32 pass** (`make verify`), covering fresh device, read after program, invalid
  bit transitions, block erase, page boundaries, factory bad blocks, persistence after controller reset and
  process restart (including a killed process and a torn journal), injected bit errors, power interruption,
  error reproducibility, read retry, timing, contention and the research-model checks. During development,
  deliberately breaking erase or read retry made the relevant tests fail (mutation check).
* **SystemVerilog regression: 128/128 testbench checks pass on both Verilator 5.020 and Icarus Verilog 12**
  (`make sv`, `make sv-iverilog`). The testbench drives the model at pin level through a controller BFM,
  in six phases, each a **separate simulator process** on the same on-disk store.
* **SV and Python agree bit-exactly.** Every phase's SV operation trace (634 array operations, including
  8,893 injected bit errors after a retention bake, partial programs and erases from power cuts, and two
  targets on a shared bus) was replayed through the Python model. Result codes, busy times, sensed data,
  status and all 1,533 journal records match exactly, on both simulators. The SV-manufactured device (factory
  bad blocks and markers) and the ONFI parameter page are byte-identical to Python's.
* **pytest: 35/35 pass** (`make test`: the 32 reference tests, numpy vs pure-Python equivalence, and both SV
  regressions).
* **Fault scenario** (target 0, `stress` profile, 400 h unpowered bake at 55 °C): a read sweep shows
  73,487 retention (0→1), 5,757 wear, 88 read-disturb (1→0) and 67 read-noise bit errors. 17 blocks are bad
  or failed by ground truth, but a controller marker scan sees only the 4 factory-marked ones. Blocks that go
  bad in use must be tracked by the controller.
* **Contention** (illustrative timing, synthetic 30 k ops/s workload on 2 channels × 2 targets × 2 LUNs):
  in-order FIFO issue at ONFI mode 0 gives a read p50 of 18.5 ms. Interleaving across LUNs brings this
  to 1.1 ms, and the mode-5 bus to 40 µs. Multi-plane doubles read throughput (9.2 → 18.5 MB/s). After a
  stress-profile bake, 31 read retries recover most pages; 5 remain uncorrectable for a 4-bit/512-B ECC.
  A write-heavy run triggers 158 block erases, and reads queued behind them stretch p99 to 2.2 ms
  (erase suspend is not modelled).
* **Threshold research model:** 13/13 internal consistency checks pass (Gray adjacency, probability
  conservation, Monte-Carlo vs analytic RBER, monotone retention, optimal ≤ default references, SLC < MLC
  < TLC < QLC). These test the mathematics, not agreement with silicon.

Full tables: [`outputs/report/NANDLAB_REPORT.md`](outputs/report/NANDLAB_REPORT.md). Interactive viewer:
open [`outputs/viewer/nandlab_viewer.html`](outputs/viewer/nandlab_viewer.html) in a browser (self-contained,
works offline).

## Quick start

Python ≥ 3.8; nothing else is required (numpy is used for speed if present). SV needs Verilator ≥ 5 or Icarus ≥ 12.

```bash
python3 nand_flash_twin.py verify
```

```bash
make sv
```

```bash
make demo
```

```bash
make test
```

Other commands: `create`, `info`, `read`, `program`, `erase`, `bake`, `compact`, `export-sv`, `workload`, `vt`,
`cosim`, `init-configs` — see `python3 nand_flash_twin.py --help`. Commands on an existing store reuse the
configuration saved in its manifest unless `--config`/`--profile` is given.

```bash
python3 nand_flash_twin.py create --store /tmp/dev --profile nominal
```

```bash
python3 nand_flash_twin.py program --store /tmp/dev --lun 0 --block 2 --page 0 --fill 0x5A
```

```bash
python3 nand_flash_twin.py bake --store /tmp/dev --hours 1000 --temp 85
```

```bash
python3 nand_flash_twin.py read --store /tmp/dev --lun 0 --block 2 --page 0
```

## Deliverables

| Requirement | Where |
|---|---|
| `nand_flash_model.sv` | Pin-level model of one target (CE#) with N LUNs: ONFI-style async interface, per-LUN busy, sparse page pool, NLSF journal, seeded fault model, AC timing checker, power-loss input, trace output, back-door API. `nand_flash_device` adds an `inout` DQ wrapper for shared channels. |
| `nand_flash_twin.py` | Reference model: geometry, configuration and provenance, NLSF store, fault model, `NandTarget` and `NandFlashTwin` (channels × packages × targets), latency engine, research Vt model, reference tests, SV export, regression, co-simulation, viewer and report generation, CLI. |
| NAND geometry configuration | [`config/slc_tiny.json`](config/slc_tiny.json) (default small SLC-like device), [`config/slc_1gbit_class.json`](config/slc_1gbit_class.json), [`config/fault_profiles.json`](config/fault_profiles.json). Every value has a provenance label (`_sources`). |
| Persistent backing store | NLSF journal, one file per target: [docs/NLSF_STORE_FORMAT.md](docs/NLSF_STORE_FORMAT.md). Example: `outputs/stores/fault_scenario/`. |
| Failure-injection framework | Seeded statistical faults (profiles `ideal`, `nominal`, `stress`) plus directed faults (forced program/erase failure, stuck cells, explicit factory-bad blocks), power cut, reset abort, bake. |
| Reference tests | `REFERENCE_TESTS` in `nand_flash_twin.py` (also `tests/test_nand_flash_twin.py`), `tb/tb_nand_flash_model.sv` (5 phases), `tb/tb_nand_channel.sv`, `tb/nand_ctrl_bfm.sv`. |
| Visualisation | [`viewer/nandlab_viewer_template.html`](viewer/nandlab_viewer_template.html) → `outputs/viewer/nandlab_viewer.html` |
| Model limitations | [MODEL_LIMITATIONS.md](MODEL_LIMITATIONS.md) |
| Controller integration | [docs/CONTROLLER_INTEGRATION.md](docs/CONTROLLER_INTEGRATION.md) |

## How the pieces fit

```
 SilicaFlux controller RTL ── or ── tb/nand_ctrl_bfm.sv
              │ CE# CLE ALE WE# RE# WP# DQ[7:0] R/B#   (+ vcc_ok)
              ▼
   nand_flash_model.sv  (one instance per CE#, N LUNs)
     │ appends committed state            │ writes every array decision
     ▼                                    ▼
   <dir>/target<N>.nlsf  ◄── same format ──►  nand_flash_twin.py ──► replay_trace(): bit-exact compare
   (journal, survives restarts)               (golden model, latency engine, Vt research, viewer)
```

Both models implement the same array semantics and the same fault model. The fault model uses integer
splitmix64 hashing for every random decision and the same IEEE-754 floating-point expressions for every
probability, so the Python twin can serve as a scoreboard for SV simulations.

## 1. Memory organisation

`channels → packages → targets (CE#) → dies → LUNs → planes → blocks → pages (data + spare/OOB)`. A target is
the unit that shares a chip enable and is one SV model instance. Addressing is ONFI-style: 2 column cycles
and 3 row cycles. In the row address, the page bits are lowest, then block bits, then LUN bits; the plane is
the low block bits.

Default `slc_tiny`: 2 ch × 1 pkg × 2 CE × 2 dies (1 LUN each) × 2 planes × 32 blocks × 16 pages ×
(512 + 16) B = 4 MiB of user data. It is small enough that whole-device sweeps take seconds. Storage is
sparse in both models: erased pages are not stored, and the SV model uses a page pool sized by `POOL_PAGES`.
`slc_1gbit_class` (2048 + 64 B pages, 64 pages/block, 1024 blocks per die, 4 channels) is provided for the
Python twin.

## 2. Programming rules (SLC)

* Erased cells read **1**. PROGRAM can only move bits 1→0. ERASE works on whole blocks and returns all bits to 1.
* `policy.invalid_transition_policy`:
  * `reject` (default) — any loaded byte that asks for 0→1 makes the program FAIL with no change. This is a
    verification aid that catches controller bugs real silicon would hide.
  * `reject_non_ff` — the same, but loaded 0xFF bytes are treated as padding.
  * `and` — device-faithful: a 1 bit inhibits programming, the cell keeps its 0, and a warning is logged.
* `max_programs_per_page` (NOP, default 4) and `sequential_page_program` (default on) are configurable.
  Bytes not loaded after 80h are not programmed, so partial-page programming of spare or sectors works.
* Out-of-range columns are ignored or read as FFh, with a protocol warning. WP# low blocks program and erase.

## 3. Operations

| Operation | Opcodes | SV | Python |
|---|---|---|---|
| Reset | FFh (aborts in-flight program/erase) | ✓ | ✓ |
| Read ID | 90h-00h (5 bytes), 90h-20h ("ONFI") | ✓ | ✓ |
| Read parameter page | ECh-00h (3 redundant copies, ONFI CRC-16) | ✓ | ✓ |
| Read page | 00h-addr×5-30h; change read column 05h-E0h | ✓ | ✓ |
| Program page | 80h-addr×5-data-10h; change write column 85h | ✓ | ✓ |
| Erase block | 60h-addr×3-D0h | ✓ | ✓ |
| Read status / enhanced | 70h / 78h-row×3 (LUN select) | ✓ | ✓ |
| Set/Get features | EFh/EEh: 01h timing mode, A0h read-retry level (model-specific) | ✓ | ✓ |
| Multi-LUN interleaving | operations on idle LUNs while another is busy | ✓ | ✓ |
| Multi-plane | concurrent planes, shared program time | – | latency engine |
| Cache, copyback, unique ID, NV-DDR/Toggle | – | – | – |

Busy times: tR, tPROG and tBERS. Program time shortens and erase time lengthens with wear. Failed operations
run `fail_time_factor` × longer, rejected operations take `t_reject_ns`, and reset aborts take
`t_rst_prog_ns`/`t_rst_erase_ns`. R/B# falls tWB after the confirm command.

## 4. Persistence

The store holds committed cell contents, OOB, bad-block state, erase counts, reads since erase, program
timestamps, page and block flags, and model metadata. Changes are journalled as they happen.

* **Controller reset** (FFh) and **process restart** never restore erased data. Volatile state is gone after a
  power cycle.
* **Process crash**: a killed writer leaves a valid prefix. A torn final record is detected and ignored.
* **Power loss** (`vcc_ok` low, or `power_off()` in Python) during a program leaves only some of the intended
  0s written. During an erase it leaves only some 0s returned to 1. Both are proportional to the elapsed busy
  time and chosen by seeded hash, flagged unstable, and persisted. The erase still counts as a P/E cycle.
* **Retention clock**: powered time is Arrhenius-scaled (Ea = 1.1 eV, as in JEDEC JESD218) to a reference
  temperature. `bake` and `+NANDLAB_BAKE_HOURS` add unpowered time.

## 5. Error model (bit level, SLC device)

For a page in block erase epoch *e*, every cell gets a fixed 32-bit weakness `u = splitmix64(seed, address,
e, bit) >> 32`. With `c = P/E cycles / rated endurance`:

```
p_wear   = rber_fresh + rber_wear_at_rated · c^wear_exponent           (+ interrupted_rber if unstable)
p_ret    = retention_rber_ref · (age_h / retention_ref_hours)^retention_exponent · (1 + retention_wear_gain · c)
p_rd     = read_disturb_rber_ref · (reads_since_erase / read_disturb_ref_reads) · (1 + read_disturb_wear_gain · c)
stored 0 reads wrong iff  u < 2^32 · (p_wear + p_ret · g^r)      (charge loss: 0 → 1)
stored 1 reads wrong iff  u < 2^32 · (p_wear + p_rd / g^r)       (charge gain: 1 → 0)
```

Here `r` is the read-retry level and `g = retry_gain`. A separate per-read hash stream adds transient
`read_noise_rber`.

* Because `u` is fixed per epoch, the set of failing cells only grows as age, reads or wear grow, and it is
  exactly reproducible. The same seed and history give the same bits. A different seed gives different weak
  cells.
* Program and erase failure probabilities follow `fresh + at_rated · c^exponent`. Failures leave partial data,
  set FAIL, run long and flag the block. Erase failure is sticky, and erasing is refused beyond the hard
  endurance limit.
* Factory bad blocks are chosen from a seeded rate (block 0 is guaranteed good, capped at the ONFI
  "max bad blocks per LUN"), plus an explicit list. They carry a 00h marker in spare byte 0 of the first
  and last pages.
* Directed faults: forced program/erase failure per address, and stuck-at cells.

Profiles: **ideal** (no stochastic faults), **nominal** (low illustrative rates), **stress** (deliberately
exaggerated so error handling is exercised quickly). The SV model takes all of these at run time from
`nandlab.svcfg`.

## 6. SLC / MLC / TLC / QLC

The device is SLC. `nand_flash_twin.py vt` and the viewer's *Threshold distributions* tab run a separate
**research** model. It models each of the 2^b states as a Gaussian Vt distribution, Gray-coded with erased =
all ones. Wear widens the states and lifts the erased state, retention moves programmed states toward a
neutral Vt in log time, and read disturb lifts the erased state. The model reports RBER for fixed and optimal
read references, per-page bit error, a read-retry scan and a Monte-Carlo histogram. Its coefficients are
illustrative and were tuned only so RBERs land in commonly reported orders of magnitude. It is a first-order
textbook abstraction (cf. Cai et al., *Proc. IEEE* 105(9), 2017; Parnell et al., GLOBECOM 2014); it is
**not** a device model and is **unvalidated**. The viewer plots its SLC curve next to the bit-level device
model's, to show how far apart two uncalibrated abstractions can be.

## 7. Latency and contention

`ArraySimulator` books a shared DQ bus per channel, using command, address and data cycles at the target's
ONFI timing mode. It also books one array per LUN; a LUN stays busy until its page register has been
transferred. It models multi-plane loads (tDBSY) and shared program time, FIFO versus LUN-interleaving
issue, and **read retry** driven by a controller ECC model: if a codeword has more than *t* raw errors, the
engine issues SET FEATURES (A0h) and re-reads, following `latency.retry_sequence`. Array operations really
execute on the twin, so wear, faults and retries are those of the device model. `make_workload` produces a
synthetic Poisson workload with FTL-like block reuse, which generates erases.

## 8. Viewer

`outputs/viewer/nandlab_viewer.html` is self-contained, with no network access needed, in the SilicaFlux
navy/gold/cyan style. It has these tabs:

* **3-D cell array** — NAND strings through stacked wordline layers, bitlines, select gates and source line,
  for real blocks from the fault scenario: a worn block, a read-hammered block, power cuts during program and
  erase, a healthy block and an erase failure. Cells are shown as erased, programmed or bit error.
* **Blocks** — erase-count, read-count, fill and error heat maps per LUN and plane, with factory-bad,
  failed, worn and marginal markers.
* **Simulated errors** — per-page error map by mechanism, RBER versus P/E and retention, and the research
  versus bit-level comparison.
* **Threshold distributions**, **Latency & contention** (histograms and a channel/LUN timeline),
  **Verification** and **Limitations**.

## Layout

```
nand_flash_model.sv            SV package + nand_flash_model + nand_flash_device (inout wrapper)
nand_flash_twin.py             Python twin, tests, regression, viewer/report generation, CLI
config/                        slc_tiny.json, slc_1gbit_class.json, fault_profiles.json
tb/                            nand_ctrl_bfm.sv, tb_nand_flash_model.sv, tb_nand_channel.sv
tests/test_nand_flash_twin.py  pytest wrapper
viewer/                        viewer template (data injected by `demo`)
docs/                          NLSF_STORE_FORMAT.md, CONTROLLER_INTEGRATION.md
outputs/                       report/, viewer/, verification/, sv_regression*/ (logs, traces, stores), stores/fault_scenario/
MODEL_LIMITATIONS.md, Makefile, requirements.txt
```

## References (context only; no coefficients were taken from them)

* Open NAND Flash Interface (ONFI) specification — command set, status register, addressing, parameter page.
* JEDEC JESD218, *Solid-State Drive (SSD) Requirements and Endurance Test Method* — 1.1 eV retention acceleration.
* N. Mielke et al., "Bit error rate in NAND Flash memories", IEEE IRPS 2008.
* Y. Cai, S. Ghose, E. F. Haratsch, Y. Luo, O. Mutlu, "Error Characterization, Mitigation, and Recovery in
  Flash-Memory-Based Solid-State Drives", *Proceedings of the IEEE* 105(9), 2017.
* T. Parnell, N. Papandreou, T. Mittelholzer, H. Pozidis, "Modelling of the threshold voltage distributions of
  sub-20nm NAND flash memory", IEEE GLOBECOM 2014.
