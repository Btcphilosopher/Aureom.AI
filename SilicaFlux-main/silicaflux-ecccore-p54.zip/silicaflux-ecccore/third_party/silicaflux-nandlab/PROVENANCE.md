# Provenance — SilicaFlux NANDLab (Project 52), vendored unmodified

Source archive: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-nandlab-v0.1.0.zip` in the Aureom.AI repository
(sha256 `7aded486670de98679e3946dd890c3b30c54cf3b614aaa5bace2f0dda6fbde46`), directory `silicaflux-nandlab/`.

Files copied byte-for-byte (see `SHA256SUMS`; `scripts/check_vendor.py` re-verifies them against the archive):
`nand_flash_model.sv`, `nand_flash_twin.py`, `tb/nand_ctrl_bfm.sv`, `config/*.json`, `MODEL_LIMITATIONS.md`, `README.md`.

Use in Project 54: the pin-level SV device model and its controller BFM are the NAND digital twin of
`tb/tb_sfecc_nand_twin.sv`; `nand_flash_twin.py` exports the device configuration (`export-sv`) and provides the
Python NAND model (`NandTarget`) for the statistical fault campaign.  All reliability numbers of the twin are
**illustrative** (see MODEL_LIMITATIONS.md) — outcomes measured against it are outcomes for that error model,
not NAND reliability data.
