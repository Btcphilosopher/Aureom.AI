# Model limitations — SilicaFlux NANDLab v0.1.0

## What this model is

A behavioural digital twin of **external** NAND flash devices for developing and verifying the SilicaFlux
storage controller. It is not a model of, and makes no claim about, NAND cells fabricated by SilicaFlux. It
has not been compared with any physical NAND device.

## Validation status

| Aspect | Status | Evidence |
|---|---|---|
| SLC array semantics (erase → 1, program 1→0, block erase, NOP, sequential rule, bad blocks) | **Verified against the specification written for this model** | Python reference suite; SV testbench at pin level |
| SV model ≡ Python model | **Verified, bit-exact** for the regression histories (data, injected errors, status, busy times, journal) on Verilator 5.020 and Icarus 12 | `sv-regress` trace replay |
| Persistence and crash behaviour | **Verified** for controller reset, process restart, killed writer, torn journal, power loss | reference tests, `restart` / `powercut` phases |
| ONFI command subset, status bits, parameter page and CRC | **Implemented from the ONFI structure**; not checked by an ONFI conformance suite | parameter page CRC and geometry checks |
| ONFI async timing-mode values | **Transcribed**, not checked against a specific ONFI revision | `SOURCES["onfi_timing"]` |
| Array timing (tR, tPROG, tBERS, tRST, tFEAT) | **Illustrative** SLC-datasheet-range values | `config/*.json` `_sources` |
| Error rates, failure probabilities, factory-bad rate, wear/retention/disturb coefficients | **Illustrative; not measured; not calibrated** | `config/fault_profiles.json` |
| MLC/TLC/QLC threshold-voltage model | **Research model, unvalidated**; internally consistent (13 checks) | `vt` command, viewer |

Nothing in the bundled outputs is measured NAND reliability. Numbers from the `stress` profile are
deliberately exaggerated.

## Limitations by area

### Device and interface
* Only an ONFI-style **subset** is modelled: RESET, READ ID, READ PARAMETER PAGE, READ (with change read
  column), PROGRAM (with change write column), ERASE, READ STATUS (70h/78h), and SET/GET FEATURES (timing mode
  and a model-specific read-retry address A0h). Cache read/program, multi-plane commands (in SV), copyback,
  read unique ID, the synchronous, NV-DDR and Toggle interfaces, ZQ calibration, ODT, volume addressing,
  program/erase suspend and LUN reset are not modelled.
* The SV model handles one target per instance, with multi-LUN interleaving. Multi-plane concurrency exists
  only in the Python latency engine.
* The AC timing checker covers tWP, tWH, tWC, tRP, tREH, tRC, tCLS, tALS, tDS, tWHR, tADL, tRR and tCCS.
  Hold times, CE#-related timings and output-enable/hi-Z timing are not checked. DQ is driven tREA after RE#
  falls and, in the `inout` wrapper, released about 15 ns after RE# rises.
* Reset keeps the selected timing mode and read-retry level, while power loss returns them to their
  defaults. This is a model choice; check your device's datasheet.
* A program or erase rejected by policy (0→1 request, NOP exceeded, out-of-order page) reports FAIL and is
  busy for `t_reject_ns`. Real devices do not reject these; the `and` policy reproduces device behaviour.
* WP# low makes a program or erase report FAIL with WP# = 0 and no busy period. Device behaviour varies.
* Stuck cells are applied at read time only. They do not cause program-verify failures.

### Reliability physics
* Device semantics are SLC only. There is no multi-bit device model, no paired-page or program-order (LSB/MSB)
  constraint, and no cell-to-cell interference.
* Errors are independent per cell, drawn from deterministic hashes. Spatial correlation (bitline or wordline
  defects, edge wordlines, string effects), data-pattern dependence, program temperature,
  temperature-dependent read noise and early (infant-mortality) failures are not modelled.
* Retention is an illustrative power law in time at the reference temperature, scaled by an Arrhenius factor
  with Ea = 1.1 eV (the JESD218 value). A single activation energy is a simplification.
* Read disturb is linear in reads since erase, at block granularity. The page being read is disturbed as much
  as the other pages in its block.
* Wear and failure curves are `fresh + at_rated · c^n`. The hard endurance limit
  (`endurance_hard_limit_factor`) is a model choice.
* Read retry in the bit-level model scales the retention and disturb terms by `g^±level`. That is an
  abstraction of moving the read reference, not a voltage computation.
* Partial-page programs update the page's program timestamp, so retention of bytes programmed earlier on the
  same page is slightly underestimated.
* Power loss and failure leave partial results: intended 0s, or erased 1s, are chosen by hash in proportion
  to elapsed busy time. This is plausible, not characterised. An interrupted erase counts as one P/E cycle.

### Research threshold-voltage model
* Gaussian state distributions are a first-order approximation; real distributions have non-Gaussian tails.
  Program-verify levels are evenly spaced, and the shift laws are illustrative. Coefficients were tuned only
  so RBERs land in commonly reported orders of magnitude.
* It is not connected to the device model's behaviour. The viewer plots both models so the gap between two
  uncalibrated abstractions is visible.

### Performance model
* The latency engine models bus cycles, array busy time and channel/LUN/plane contention. It is not a full
  SSD/FTL model: there is no garbage-collection policy beyond block reuse in the synthetic workload, no
  write buffer, no power or thermal throttling, and no controller firmware overheads (`controller_overhead_ns`
  defaults to 0).
* The ECC model only counts raw errors per codeword against a threshold *t*. It is not an LDPC or BCH decoder.
* The small test geometry (512 B pages) limits absolute throughput. Compare scenarios, not absolute numbers.

### Persistence and determinism
* The text journal is meant for test-sized devices. A 1 Gbit-class device with every page written produces
  large files; compact it periodically.
* Bit-exact SV/Python agreement assumes the same operation history and IEEE-754 double arithmetic. Both
  models call the C library's `exp` and `pow`. A last-ulp difference between platforms could, extremely
  rarely, flip a threshold comparison.
* `fsync` is off by default: data is flushed on every record, which survives a crashed process but not an
  operating-system crash. Set `store.fsync` to true if you need that.

## Making it quantitative

To turn the fault model into a quantitative tool, replace the illustrative coefficients with calibrated
data for the target device. That data comes from the device vendor or your own characterisation:
* RBER against P/E cycles, retention time and temperature, and read count;
* program/erase failure rates against cycles; factory and grown bad-block rates;
* tR, tPROG and tBERS distributions against wear;
* read-retry tables;
* for MLC and above: Vt distributions per state.

Then re-run `make test` and the demo, and record the data source in each changed parameter's provenance label.
