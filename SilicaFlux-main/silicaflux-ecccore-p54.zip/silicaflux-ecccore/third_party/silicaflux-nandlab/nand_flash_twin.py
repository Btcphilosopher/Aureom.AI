#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SilicaFlux NANDLab -- NAND flash digital twin and fault simulator (Project 52)
==============================================================================
Aureom.AI | SilicaFlux-STORE

Primary sources: ``nand_flash_twin.py`` (this file, reference model) and
``nand_flash_model.sv`` (pin-level behavioural device model for controller
testbenches).

What this is
------------
A behavioural *digital twin of external NAND flash devices* that a SilicaFlux
storage controller will talk to.  It is NOT a claim that SilicaFlux fabricates
NAND cells, and every reliability number in it is illustrative unless the user
supplies calibrated device data.

The two models implement the SAME array semantics, the SAME seeded fault model
(integer splitmix64 hashing, identical floating-point formulas) and the SAME
persistent backing-store format (NLSF, see ``BackingStore``).  The Python model
is the golden reference: ``sv-regress`` replays the SystemVerilog model's own
operation trace through this file and requires bit-exact agreement of read
data, status, busy times and journal records.

Sections
--------
 0. provenance labels           8. ONFI parameter page / ID
 1. deterministic hashing       9. NandTarget (device behaviour, power cut)
 2. configuration dataclasses  10. NandFlashTwin (channels/packages/targets)
 3. ONFI timing tables          11. latency / contention engine + read retry
 4. fault profiles              12. threshold-voltage research model (SLC..QLC)
 5. backing store (NLSF)        13. SystemVerilog export, regression, co-sim
 6. bit-level fault model       14. reference verification suite
 7. result codes / status       15. viewer generation, demo, CLI

Only the Python standard library is required.  numpy is used when available to
vectorise the per-bit fault hashing (results are identical either way).
"""
from __future__ import annotations

import argparse
import copy
import dataclasses
import hashlib
import json
import math
import os
import random
import shutil
import struct
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

try:  # optional acceleration only; never changes results
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None

MODEL_NAME = "SilicaFlux NANDLab"
MODEL_VERSION = "0.1.0"
PROJECT = "Aureom.AI | SilicaFlux-STORE | Project 52"
STORE_MAGIC = "NLSF"
STORE_VERSION = 1
TRACE_MAGIC = "NANDLAB-TRACE"
HERE = os.path.dirname(os.path.abspath(__file__))

# =============================================================================
# 0. Provenance labels -- every configurable number carries one of these.
# =============================================================================
SOURCES: Dict[str, str] = {
    "onfi": "ONFI-defined structure/encoding (command opcodes, status bits, "
            "row/column addressing, parameter-page layout and CRC). Subset only; "
            "no ONFI compliance is claimed.",
    "onfi_timing": "Nominal ONFI asynchronous SDR timing-mode values as commonly "
                   "reproduced in ONFI-1.x-era SLC datasheets. Transcribed for "
                   "illustration; verify against the ONFI revision / datasheet you target.",
    "illustrative_datasheet": "Illustrative value in the range of public SLC NAND "
                              "datasheets. Not taken from, and not representative of, "
                              "any specific device.",
    "illustrative_model": "Illustrative functional form and coefficient chosen to "
                          "exercise controller behaviour. NOT calibrated against "
                          "measured NAND reliability data.",
    "jedec_ea": "Arrhenius activation energy of 1.1 eV, the value used for NAND "
                "data-retention acceleration in JEDEC JESD218. Applied here to the "
                "illustrative retention term only.",
    "model_choice": "Modelling decision of this twin (documented in MODEL_LIMITATIONS.md).",
    "research": "Research threshold-voltage abstraction (Gaussian states, Gray "
                "coding). Parameters illustrative; model UNVALIDATED against silicon.",
    "user": "Value supplied by the user configuration.",
}

# =============================================================================
# 1. Deterministic hashing (bit-identical in nand_flash_model.sv)
# =============================================================================
M64 = 0xFFFFFFFFFFFFFFFF
GOLDEN = 0x9E3779B97F4A7C15
MIX1 = 0xBF58476D1CE4E5B9
MIX2 = 0x94D049BB133111EB
TWO32 = 4294967296.0

# Domain-separation constants (ASCII tags) -- keep in sync with the SV package.
D_TARGET = 0x4E414E444C414231   # "NANDLAB1"
D_PERSIST = 0x5745414B43454C4C  # "WEAKCELL"  persistent per-cell weakness
D_NOISE = 0x524541444E4F4953    # "READNOIS"  per-read transient noise
D_PFAIL = 0x50524F474641494C    # "PROGFAIL"  program failure decision
D_EFAIL = 0x4552415345464C30    # "ERASEFL0"  erase failure decision
D_PPART = 0x50524F4750415254    # "PROGPART"  partial program bit selection
D_EPART = 0x4552415350415254    # "ERASPART"  partial erase bit selection
D_FBAD = 0x464143544F525942     # "FACTORYB"  factory bad block selection


def mix64(x: int) -> int:
    """splitmix64 finaliser (Steele/Lea/Flood); 64-bit wrap-around arithmetic."""
    z = (x + GOLDEN) & M64
    z = ((z ^ (z >> 30)) * MIX1) & M64
    z = ((z ^ (z >> 27)) * MIX2) & M64
    return z ^ (z >> 31)


def target_seed(global_seed: int, target_index: int) -> int:
    return mix64((global_seed ^ D_TARGET ^ (target_index & M64)) & M64)


def hkey(tseed: int, domain: int, *fields: int) -> int:
    k = mix64((tseed ^ domain) & M64)
    for f in fields:
        k = mix64((k ^ (int(f) & M64)) & M64)
    return k


def thr32(p: float) -> int:
    """Probability -> 32-bit integer threshold. A cell with weakness u (32-bit)
    is affected iff u < thr32(p). Identical expression in SV ($floor)."""
    if not (p > 0.0):
        return 0
    if p >= 1.0:
        return 1 << 32
    return int(math.floor(p * TWO32))


_IDX_CACHE: Dict[int, Any] = {}


def bit_weakness(key: int, nbits: int):
    """u_i = mix64(key ^ i) >> 32 for i in [0, nbits). numpy array or list."""
    if np is not None:
        idx = _IDX_CACHE.get(nbits)
        if idx is None:
            idx = np.arange(nbits, dtype=np.uint64)
            _IDX_CACHE[nbits] = idx
        with np.errstate(over="ignore"):
            z = idx ^ np.uint64(key)
            z = z + np.uint64(GOLDEN)
            z = (z ^ (z >> np.uint64(30))) * np.uint64(MIX1)
            z = (z ^ (z >> np.uint64(27))) * np.uint64(MIX2)
            z = z ^ (z >> np.uint64(31))
        return z >> np.uint64(32)
    return [mix64(key ^ i) >> 32 for i in range(nbits)]


def bytes_to_bits(data: bytes):
    """LSB-first bit order: bit i = (data[i>>3] >> (i&7)) & 1."""
    if np is not None:
        return np.unpackbits(np.frombuffer(bytes(data), dtype=np.uint8), bitorder="little")
    out = []
    for b in data:
        for k in range(8):
            out.append((b >> k) & 1)
    return out


def bits_to_mask_bytes(flags, nbytes: int) -> bytearray:
    """Boolean per-bit vector -> bytes (LSB-first)."""
    if np is not None:
        return bytearray(np.packbits(np.asarray(flags, dtype=np.uint8), bitorder="little").tobytes()[:nbytes])
    out = bytearray(nbytes)
    for i, f in enumerate(flags):
        if f:
            out[i >> 3] |= 1 << (i & 7)
    return out


def popcount_bytes(data: bytes) -> int:
    return sum(bin(b).count("1") for b in data)


def fmt_real(x: float) -> str:
    """Store/trace real format. SV writes with $fwrite("%.17g") -> identical."""
    return "%.17g" % x


# =============================================================================
# 2. Configuration
# =============================================================================
def _ilog2_ceil(n: int) -> int:
    return 0 if n <= 1 else (n - 1).bit_length()


@dataclass
class Geometry:
    """Physical organisation. A *target* is one chip-enable (CE#); the SV model
    instance represents exactly one target. LUN == independently operating
    unit (normally one per die). Plane = low-order block-address bits (ONFI)."""
    channels: int = 2
    packages_per_channel: int = 1
    targets_per_package: int = 2
    dies_per_target: int = 2
    luns_per_die: int = 1
    planes_per_lun: int = 2
    blocks_per_plane: int = 32
    pages_per_block: int = 16
    page_data_bytes: int = 512
    page_spare_bytes: int = 16
    bits_per_cell: int = 1          # device model is SLC; MLC+ is research-only (section 12)
    # visualisation-only mapping of a block onto a 3-D NAND string structure
    viz_wordline_layers: int = 8
    viz_string_select_lines: int = 2

    # ---- derived ----
    @property
    def luns_per_target(self) -> int:
        return self.dies_per_target * self.luns_per_die

    @property
    def blocks_per_lun(self) -> int:
        return self.planes_per_lun * self.blocks_per_plane

    @property
    def page_bytes(self) -> int:
        return self.page_data_bytes + self.page_spare_bytes

    @property
    def page_bits(self) -> int:
        return self.page_bytes * 8

    @property
    def targets(self) -> int:
        return self.channels * self.packages_per_channel * self.targets_per_package

    @property
    def pages_per_target(self) -> int:
        return self.luns_per_target * self.blocks_per_lun * self.pages_per_block

    @property
    def row_page_bits(self) -> int:
        return _ilog2_ceil(self.pages_per_block)

    @property
    def row_block_bits(self) -> int:
        return _ilog2_ceil(self.blocks_per_lun)

    @property
    def row_lun_bits(self) -> int:
        return _ilog2_ceil(self.luns_per_target)

    @property
    def plane_bits(self) -> int:
        return _ilog2_ceil(self.planes_per_lun)

    def validate(self) -> None:
        def pow2(n):
            return n > 0 and (n & (n - 1)) == 0
        for name in ("channels", "packages_per_channel", "targets_per_package", "dies_per_target",
                     "luns_per_die", "planes_per_lun", "blocks_per_plane", "pages_per_block",
                     "page_data_bytes"):
            if getattr(self, name) < 1:
                raise ValueError(f"geometry.{name} must be >= 1")
        if self.page_spare_bytes < 1:
            raise ValueError("geometry.page_spare_bytes must be >= 1 (bad-block marker lives in spare byte 0)")
        if not pow2(self.planes_per_lun):
            raise ValueError("geometry.planes_per_lun must be a power of two (plane = low block-address bits)")
        if self.row_page_bits + self.row_block_bits + self.row_lun_bits > 24:
            raise ValueError("row address exceeds 3 ONFI row-address cycles (24 bits)")
        if self.page_bytes > 65535:
            raise ValueError("page + spare exceeds 2 column-address cycles")
        if self.bits_per_cell != 1:
            raise ValueError("The device model implements SLC semantics only (bits_per_cell=1). "
                             "MLC/TLC/QLC are available as the research threshold model "
                             "(`vt` command), not as a device model.")
        if self.pages_per_block < 2:
            raise ValueError("pages_per_block must be >= 2")

    def row_address(self, lun: int, block: int, page: int) -> int:
        return page | (block << self.row_page_bits) | (lun << (self.row_page_bits + self.row_block_bits))

    def decode_row(self, row: int) -> Tuple[int, int, int]:
        page = row & ((1 << self.row_page_bits) - 1)
        block = (row >> self.row_page_bits) & ((1 << self.row_block_bits) - 1)
        lun = row >> (self.row_page_bits + self.row_block_bits)
        return lun, block, page

    def plane_of(self, block: int) -> int:
        return block & (self.planes_per_lun - 1)

    def valid(self, lun: int, block: int, page: int = 0) -> bool:
        return (0 <= lun < self.luns_per_target and 0 <= block < self.blocks_per_lun
                and 0 <= page < self.pages_per_block)

    def target_index(self, ch: int, pkg: int, tgt: int) -> int:
        return (ch * self.packages_per_channel + pkg) * self.targets_per_package + tgt

    def target_coords(self, idx: int) -> Tuple[int, int, int]:
        tgt = idx % self.targets_per_package
        pkg = (idx // self.targets_per_package) % self.packages_per_channel
        ch = idx // (self.targets_per_package * self.packages_per_channel)
        return ch, pkg, tgt

    def summary(self) -> str:
        cap = self.targets * self.pages_per_target * self.page_data_bytes
        return (f"{self.channels} ch x {self.packages_per_channel} pkg x {self.targets_per_package} CE x "
                f"{self.dies_per_target} die x {self.luns_per_die} LUN x {self.planes_per_lun} plane x "
                f"{self.blocks_per_plane} blk x {self.pages_per_block} pg x "
                f"({self.page_data_bytes}+{self.page_spare_bytes}) B = {cap / 1048576:.2f} MiB user data")


@dataclass
class TimingParams:
    timing_mode: int = 0                 # ONFI async SDR timing mode at power-on (mode 0 per ONFI)
    t_r_ns: float = 25000.0              # array read (tR)
    t_prog_ns: float = 200000.0          # page program, typical (tPROG)
    t_bers_ns: float = 2000000.0         # block erase, typical (tBERS)
    t_rst_idle_ns: float = 5000.0        # reset while idle / reading
    t_rst_prog_ns: float = 10000.0       # reset aborting a program
    t_rst_erase_ns: float = 500000.0     # reset aborting an erase
    t_rst_poweron_ns: float = 1000000.0  # first reset after power-on
    t_feat_ns: float = 1000.0            # SET/GET FEATURES busy (tFEAT)
    t_reject_ns: float = 2000.0          # model choice: busy for a policy-rejected operation
    t_ccs_ns: float = 500.0              # change-column setup (reported in parameter page)
    prog_time_wear_speedup: float = 0.2  # tPROG shrinks by this fraction at rated endurance
    prog_time_floor: float = 0.6
    erase_time_wear_slowdown: float = 1.0  # tBERS grows by this fraction at rated endurance
    fail_time_factor: float = 3.0        # failed program/erase run to the max-loop time
    timing_checks: bool = True           # SV: check host-side AC timing
    timing_fatal: bool = False


@dataclass
class PolicyParams:
    max_programs_per_page: int = 4                  # NOP (partial-page programs per page per erase)
    sequential_page_program: bool = True            # first program of a page must be the next page in the block
    invalid_transition_policy: str = "reject"       # "reject" | "reject_non_ff" | "and" (device-like AND)
    factory_bad_erase: str = "fail_keep_marker"     # | "erase_marker_lost"
    require_reset_after_power_on: bool = True
    bad_block_marker_byte: int = 0                  # offset within the spare area


# reject: any loaded byte requesting a 0->1 transition fails the program (verification aid)
# reject_non_ff: as reject, but loaded 0xFF bytes are treated as padding/inhibit
# and: device-faithful -- '1' data bits inhibit programming, the cell keeps its 0
INVALID_POLICIES = {"reject": 0, "and": 1, "reject_non_ff": 2}


@dataclass
class IdentParams:
    manufacturer_id: int = 0x00     # 0x00 is not a valid JEP106 code (parity) -> impersonates nobody
    device_id: int = 0x5A
    id_byte3: int = 0x00
    id_byte4: int = 0x15
    id_byte5: int = 0x00
    manufacturer: str = "SILICAFLUX"
    model: str = "NANDLAB-SLC-TWIN"
    max_bad_blocks_per_lun: int = -1   # -1 -> derived: max(1, blocks_per_lun // 25)
    ecc_bits_required: int = 4         # ONFI byte 112 (host ECC requirement), illustrative


@dataclass
class FaultParams:
    profile: str = "nominal"
    seed: int = 0x5F1CAF10C552
    rated_endurance_cycles: float = 100000.0
    endurance_hard_limit_factor: float = 3.0   # erase always fails beyond factor x rated (<=0 disables)
    # persistent, bidirectional "weak cell" component (wear-out)
    rber_fresh: float = 1.0e-10
    rber_wear_at_rated: float = 1.0e-7
    wear_exponent: float = 2.0
    # retention: programmed (0) cells read as erased (1)
    retention_rber_ref: float = 1.0e-8
    retention_ref_hours: float = 8760.0
    retention_exponent: float = 1.0
    retention_wear_gain: float = 50.0
    # read disturb: erased (1) cells read as programmed (0)
    read_disturb_rber_ref: float = 1.0e-8
    read_disturb_ref_reads: float = 100000.0
    read_disturb_wear_gain: float = 10.0
    # transient per-read noise (bidirectional, not persistent)
    read_noise_rber: float = 0.0
    # pages left by an interrupted/failed operation
    interrupted_rber: float = 5.0e-3
    # operation failures
    prog_fail_fresh: float = 1.0e-7
    prog_fail_at_rated: float = 1.0e-4
    prog_fail_exponent: float = 3.0
    erase_fail_fresh: float = 1.0e-6
    erase_fail_at_rated: float = 1.0e-3
    erase_fail_exponent: float = 3.0
    erase_fail_sticky: bool = True
    prog_fail_partial_fraction: float = 0.5
    erase_fail_partial_fraction: float = 0.7
    # factory bad blocks (written into the store at "manufacture")
    factory_bad_block_rate: float = 0.02
    factory_bad_blocks: List[List[int]] = field(default_factory=list)  # [[target, lun, block], ...]
    # read retry (bit-level): +level lowers V_ref (helps retention, hurts disturb)
    retry_gain: float = 0.5
    retry_max_level: int = 7
    # temperature
    activation_energy_ev: float = 1.1
    reference_temp_c: float = 40.0
    operating_temp_c: float = 40.0


@dataclass
class DirectedFaults:
    force_prog_fail: List[List[int]] = field(default_factory=list)   # [target, lun, block, page]
    force_erase_fail: List[List[int]] = field(default_factory=list)  # [target, lun, block]
    stuck_bits: List[List[int]] = field(default_factory=list)        # [target, lun, block, page, bit, value]


@dataclass
class LatencyParams:
    scheduler: str = "interleave"        # "fifo" (in-order per channel) | "interleave"
    ecc_codeword_bytes: int = 512
    ecc_bits_per_codeword: int = 4       # controller ECC strength used by the read-retry model
    max_read_retries: int = 6
    retry_sequence: List[int] = field(default_factory=lambda: [1, 2, 3, -1, -2, 4, 5])
    t_dbsy_ns: float = 500.0             # multi-plane dummy busy between plane loads (illustrative)
    controller_overhead_ns: float = 0.0


@dataclass
class StoreParams:
    fsync: bool = False                  # flush() always; fsync() optionally (host-crash durability)
    persist_read_counts: bool = True     # journal an R record on every page read


@dataclass
class Config:
    name: str = "slc_tiny"
    description: str = "Small SLC-like test device (illustrative)."
    geometry: Geometry = field(default_factory=Geometry)
    timing: TimingParams = field(default_factory=TimingParams)
    policy: PolicyParams = field(default_factory=PolicyParams)
    ident: IdentParams = field(default_factory=IdentParams)
    faults: FaultParams = field(default_factory=FaultParams)
    directed: DirectedFaults = field(default_factory=DirectedFaults)
    latency: LatencyParams = field(default_factory=LatencyParams)
    store: StoreParams = field(default_factory=StoreParams)

    # ---- helpers ----
    def max_bad_blocks_per_lun(self) -> int:
        m = self.ident.max_bad_blocks_per_lun
        return max(1, self.geometry.blocks_per_lun // 25) if m < 0 else m

    def validate(self) -> "Config":
        self.geometry.validate()
        if self.policy.invalid_transition_policy not in INVALID_POLICIES:
            raise ValueError(f"policy.invalid_transition_policy must be one of {list(INVALID_POLICIES)}")
        if self.policy.factory_bad_erase not in ("fail_keep_marker", "erase_marker_lost"):
            raise ValueError("policy.factory_bad_erase must be 'fail_keep_marker' or 'erase_marker_lost'")
        if self.timing.timing_mode not in ONFI_ASYNC_MODES:
            raise ValueError("timing.timing_mode must be 0..5")
        if self.policy.max_programs_per_page < 1:
            raise ValueError("policy.max_programs_per_page must be >= 1")
        if not (0 <= self.policy.bad_block_marker_byte < self.geometry.page_spare_bytes):
            raise ValueError("policy.bad_block_marker_byte must lie inside the spare area")
        if self.latency.scheduler not in ("fifo", "interleave"):
            raise ValueError("latency.scheduler must be 'fifo' or 'interleave'")
        return self

    def to_dict(self) -> dict:
        d = asdict(self)
        d["_sources"] = CONFIG_SOURCES
        d["_note"] = ("All reliability and timing values are illustrative unless replaced with "
                      "calibrated device data. See MODEL_LIMITATIONS.md.")
        return d

    def geometry_fingerprint(self) -> str:
        g = asdict(self.geometry)
        g.pop("viz_wordline_layers", None)
        g.pop("viz_string_select_lines", None)
        return hashlib.sha256(json.dumps(g, sort_keys=True).encode()).hexdigest()[:16]

    def fingerprint(self) -> str:
        d = asdict(self)
        return hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()[:16]


CONFIG_SOURCES = {
    "geometry": "model_choice (small SLC-like test device; edit freely)",
    "timing.timing_mode / interface table": "onfi_timing",
    "timing.t_r_ns, t_prog_ns, t_bers_ns, t_rst_*": "illustrative_datasheet",
    "timing.t_feat_ns, t_ccs_ns": "illustrative_datasheet",
    "timing.prog_time_wear_speedup, erase_time_wear_slowdown, fail_time_factor": "illustrative_model",
    "timing.t_reject_ns": "model_choice",
    "policy.*": "model_choice (configurable program restrictions)",
    "ident.manufacturer_id": "model_choice (0x00 is not a valid JEP106 code)",
    "ident.*": "model_choice",
    "faults.activation_energy_ev": "jedec_ea",
    "faults.* (all other)": "illustrative_model",
    "latency.*": "model_choice / illustrative_model",
}


def _apply_dict(obj: Any, d: dict, path: str = "") -> None:
    for k, v in d.items():
        if k.startswith("_"):
            continue
        if not hasattr(obj, k):
            raise KeyError(f"unknown configuration key '{path}{k}'")
        cur = getattr(obj, k)
        if dataclasses.is_dataclass(cur) and isinstance(v, dict):
            _apply_dict(cur, v, f"{path}{k}.")
        else:
            if isinstance(cur, bool):
                v = bool(v)
            elif isinstance(cur, int) and not isinstance(cur, bool) and isinstance(v, str):
                v = int(v, 0)
            elif isinstance(cur, float) and isinstance(v, int):
                v = float(v)
            setattr(obj, k, v)


def config_from_dict(d: dict) -> Config:
    cfg = Config()
    prof = (d.get("faults") or {}).get("profile", cfg.faults.profile)
    cfg.faults = fault_profile(prof)
    _apply_dict(cfg, d)
    return cfg.validate()


def load_config(path: Optional[str] = None, profile: Optional[str] = None,
                overrides: Optional[dict] = None) -> Config:
    if path:
        with open(path) as f:
            d = json.load(f)
    else:
        d = {}
    d = copy.deepcopy(d)
    if profile:
        d.setdefault("faults", {})
        fd = d["faults"]
        # a profile switch replaces the profile defaults but keeps explicit lists
        keep = {k: fd[k] for k in ("factory_bad_blocks", "seed") if k in fd}
        d["faults"] = {"profile": profile, **keep}
    if overrides:
        _deep_merge(d, overrides)
    return config_from_dict(d)


def _deep_merge(dst: dict, src: dict) -> None:
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _deep_merge(dst[k], v)
        else:
            dst[k] = copy.deepcopy(v)


# =============================================================================
# 3. ONFI asynchronous timing modes (ns). Source label: "onfi_timing".
# =============================================================================
ONFI_ASYNC_MODES: Dict[int, Dict[str, float]] = {
    0: dict(tWC=100, tWP=50, tWH=30, tRC=100, tRP=50, tREH=30, tREA=40, tCLS=50, tALS=50,
            tDS=40, tDH=20, tWB=200, tWHR=120, tADL=200, tRR=40),
    1: dict(tWC=45, tWP=25, tWH=15, tRC=50, tRP=25, tREH=15, tREA=30, tCLS=25, tALS=25,
            tDS=20, tDH=10, tWB=100, tWHR=80, tADL=100, tRR=20),
    2: dict(tWC=35, tWP=17, tWH=15, tRC=35, tRP=17, tREH=15, tREA=25, tCLS=15, tALS=15,
            tDS=15, tDH=5, tWB=100, tWHR=80, tADL=100, tRR=20),
    3: dict(tWC=30, tWP=15, tWH=10, tRC=30, tRP=15, tREH=10, tREA=20, tCLS=10, tALS=10,
            tDS=10, tDH=5, tWB=100, tWHR=80, tADL=100, tRR=20),
    4: dict(tWC=25, tWP=12, tWH=10, tRC=25, tRP=12, tREH=10, tREA=20, tCLS=10, tALS=10,
            tDS=10, tDH=5, tWB=100, tWHR=80, tADL=70, tRR=20),
    5: dict(tWC=20, tWP=10, tWH=7, tRC=20, tRP=10, tREH=7, tREA=16, tCLS=10, tALS=10,
            tDS=7, tDH=5, tWB=100, tWHR=80, tADL=70, tRR=20),
}


# =============================================================================
# 4. Fault profiles (all "illustrative_model")
# =============================================================================
def fault_profile(name: str) -> FaultParams:
    f = FaultParams()
    f.profile = name
    if name == "nominal":
        return f
    if name == "ideal":
        for k in ("rber_fresh", "rber_wear_at_rated", "retention_rber_ref", "read_disturb_rber_ref",
                  "read_noise_rber", "interrupted_rber", "prog_fail_fresh", "prog_fail_at_rated",
                  "erase_fail_fresh", "erase_fail_at_rated", "factory_bad_block_rate"):
            setattr(f, k, 0.0)
        f.endurance_hard_limit_factor = 0.0
        return f
    if name == "stress":
        f.rber_fresh = 2.0e-5
        f.rber_wear_at_rated = 2.0e-3
        f.retention_rber_ref = 1.0e-3
        f.retention_ref_hours = 1000.0
        f.read_disturb_rber_ref = 1.0e-3
        f.read_disturb_ref_reads = 1000.0
        f.read_noise_rber = 2.0e-5
        f.interrupted_rber = 2.0e-2
        f.prog_fail_fresh = 2.0e-3
        f.prog_fail_at_rated = 5.0e-2
        f.erase_fail_fresh = 5.0e-3
        f.erase_fail_at_rated = 0.1
        f.factory_bad_block_rate = 0.05
        return f
    raise ValueError(f"unknown fault profile '{name}' (ideal | nominal | stress)")


FAULT_PROFILE_NOTES = {
    "ideal": "No stochastic faults, no factory bad blocks (directed faults and power-cut "
             "physics still apply). For functional controller bring-up.",
    "nominal": "Low, illustrative SLC-like rates. Not measured data.",
    "stress": "Deliberately exaggerated rates so error handling is exercised in short "
              "simulations. Not representative of any device.",
}


# =============================================================================
# 5. Persistent backing store: NLSF (NANDLab Store Format) v1
# =============================================================================
# One text file per target. Every line is one record and ends with the token ';'.
# The file is a replayable journal: a "snapshot" is simply a compacted record
# list, and every committed array change is appended as it happens. A torn
# final line (process killed mid-write) lacks the ';' and is ignored on load.
#
#   NLSF 1 <data> <spare> <pages/blk> <blocks/LUN> <planes> <LUNs> <seed:016x> <target> ;
#   M <key> <value> ;                         metadata (ignored by replay)
#   C <clock_s> ;                             retention clock checkpoint
#   B <lun> <blk> <erase_count> <flags:02x> <reads> ;   absolute block state
#   R <lun> <blk> <reads> ;                   reads since erase (read disturb)
#   E <lun> <blk> <clock_s> ;                 erase all pages of a block
#   P <lun> <blk> <pg> <nop> <flags:02x> <t_prog_s> <b0> ... <bN-1> ;  page state
#
# "clock_s" is the retention clock: seconds at the reference temperature
# (Arrhenius-scaled). Reals are written with %.17g (round-trip exact) by both
# models, so journals written by SV and Python can be compared textually.

PF_PROG_FAILED = 0x02
PF_PROG_INTERRUPTED = 0x04
PF_FACTORY_MARKER = 0x08
PF_PARTIAL_ERASE = 0x10
PF_UNSTABLE = PF_PROG_FAILED | PF_PROG_INTERRUPTED | PF_PARTIAL_ERASE

BF_FACTORY_BAD = 0x01
BF_ERASE_FAILED = 0x02
BF_PROG_FAILED = 0x04
BF_WORN_OUT = 0x08
BF_MARGINAL = 0x10
BF_ERASE_INTERRUPTED = 0x20

PAGE_FLAG_NAMES = {PF_PROG_FAILED: "prog_failed", PF_PROG_INTERRUPTED: "prog_interrupted",
                   PF_FACTORY_MARKER: "factory_marker", PF_PARTIAL_ERASE: "partial_erase"}
BLOCK_FLAG_NAMES = {BF_FACTORY_BAD: "factory_bad", BF_ERASE_FAILED: "erase_failed",
                    BF_PROG_FAILED: "prog_failed", BF_WORN_OUT: "worn_out",
                    BF_MARGINAL: "marginal", BF_ERASE_INTERRUPTED: "erase_interrupted"}


def flag_names(flags: int, table: Dict[int, str]) -> List[str]:
    return [n for b, n in table.items() if flags & b]


class StoreError(RuntimeError):
    pass


@dataclass
class PageState:
    data: bytearray
    nop: int = 0
    flags: int = 0
    t_prog: float = 0.0


@dataclass
class BlockState:
    ec: int = 0
    flags: int = 0
    reads: int = 0

    def is_default(self) -> bool:
        return self.ec == 0 and self.flags == 0 and self.reads == 0


@dataclass
class StoreImage:
    header: Dict[str, int]
    pages: Dict[Tuple[int, int, int], PageState]
    blocks: Dict[Tuple[int, int], BlockState]
    clock: float
    meta: Dict[str, str]
    records: int
    torn_tail: bool
    torn_text: str = ""
    torn_count: int = 0


def rec_header(g: Geometry, seed: int, tidx: int) -> str:
    return (f"{STORE_MAGIC} {STORE_VERSION} {g.page_data_bytes} {g.page_spare_bytes} {g.pages_per_block} "
            f"{g.blocks_per_lun} {g.planes_per_lun} {g.luns_per_target} {seed & M64:016x} {tidx} ;")


def rec_P(lun: int, blk: int, pg: int, ps: PageState) -> str:
    return (f"P {lun} {blk} {pg} {ps.nop} {ps.flags & 0xFF:02x} {fmt_real(ps.t_prog)} "
            f"{bytes(ps.data).hex(' ')} ;")


def rec_B(lun: int, blk: int, b: BlockState) -> str:
    return f"B {lun} {blk} {b.ec} {b.flags & 0xFF:02x} {b.reads} ;"


def rec_R(lun: int, blk: int, reads: int) -> str:
    return f"R {lun} {blk} {reads} ;"


def rec_E(lun: int, blk: int, clock: float) -> str:
    return f"E {lun} {blk} {fmt_real(clock)} ;"


def rec_C(clock: float) -> str:
    return f"C {fmt_real(clock)} ;"


def rec_M(key: str, value: str) -> str:
    return f"M {key} {str(value).replace(' ', '_')} ;"


def parse_store(path: str, geometry: Optional[Geometry] = None) -> StoreImage:
    with open(path, "r") as f:
        text = f.read()
    lines = text.split("\n")
    pages: Dict[Tuple[int, int, int], PageState] = {}
    blocks: Dict[Tuple[int, int], BlockState] = {}
    meta: Dict[str, str] = {}
    header: Dict[str, int] = {}
    clock = 0.0
    nrec = 0
    torn = False
    torn_text = ""
    ntorn = 0
    for i, line in enumerate(lines):
        if not line.strip():
            continue
        toks = line.split()
        if toks[-1] != ";":
            # A record is committed only once its terminating ';' is on disk. An
            # unterminated line is a torn write (process killed mid-append); a
            # later session starts on a fresh line, so torn lines may also
            # appear mid-file. They are skipped and reported, never applied.
            torn = True
            ntorn += 1
            torn_text = line[:80]
            continue
        toks = toks[:-1]
        tag = toks[0]
        try:
            if tag == STORE_MAGIC:
                if int(toks[1]) != STORE_VERSION:
                    raise StoreError(f"unsupported store version {toks[1]}")
                keys = ("page_data_bytes", "page_spare_bytes", "pages_per_block", "blocks_per_lun",
                        "planes_per_lun", "luns")
                header = {k: int(v) for k, v in zip(keys, toks[2:8])}
                header["seed"] = int(toks[8], 16)
                header["target"] = int(toks[9])
                if geometry is not None:
                    exp = (geometry.page_data_bytes, geometry.page_spare_bytes, geometry.pages_per_block,
                           geometry.blocks_per_lun, geometry.planes_per_lun, geometry.luns_per_target)
                    got = tuple(header[k] for k in keys)
                    if exp != got:
                        raise StoreError(f"{path}: store geometry {got} does not match configuration {exp}")
            elif tag == "M":
                meta[toks[1]] = toks[2] if len(toks) > 2 else ""
            elif tag == "C":
                clock = max(clock, float(toks[1]))
            elif tag == "B":
                blocks[(int(toks[1]), int(toks[2]))] = BlockState(int(toks[3]), int(toks[4], 16), int(toks[5]))
            elif tag == "R":
                key = (int(toks[1]), int(toks[2]))
                b = blocks.get(key) or BlockState()
                b.reads = int(toks[3])
                blocks[key] = b
            elif tag == "E":
                lun, blk = int(toks[1]), int(toks[2])
                for k in [k for k in pages if k[0] == lun and k[1] == blk]:
                    del pages[k]
                clock = max(clock, float(toks[3]))
            elif tag == "P":
                lun, blk, pg = int(toks[1]), int(toks[2]), int(toks[3])
                data = bytearray.fromhex("".join(toks[7:]))
                if header and len(data) != header["page_data_bytes"] + header["page_spare_bytes"]:
                    raise StoreError(f"{path}:{i + 1}: page record has {len(data)} bytes")
                t_prog = float(toks[6])
                pages[(lun, blk, pg)] = PageState(data, int(toks[4]), int(toks[5], 16), t_prog)
                clock = max(clock, t_prog)
            else:
                pass  # unknown record types are skipped (forward compatibility)
        except StoreError:
            raise
        except Exception as e:  # malformed field
            raise StoreError(f"{path}:{i + 1}: malformed '{tag}' record: {e}") from e
        nrec += 1
    if not header:
        raise StoreError(f"{path}: missing NLSF header")
    return StoreImage(header, pages, blocks, clock, meta, nrec, torn, torn_text, ntorn)


class BackingStore:
    """Append-only journal file with atomic compaction."""

    def __init__(self, path: str, fsync: bool = False):
        self.path = path
        self.fsync = fsync
        self._fh = None
        self.appended = 0

    def exists(self) -> bool:
        return os.path.exists(self.path)

    def create(self, lines: List[str]) -> None:
        self._atomic_write(lines)

    def _atomic_write(self, lines: List[str]) -> None:
        d = os.path.dirname(os.path.abspath(self.path))
        os.makedirs(d, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".nlsf-", dir=d)
        with os.fdopen(fd, "w") as f:
            f.write("\n".join(lines) + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.path)

    def open_append(self) -> None:
        if self._fh is None:
            needs_nl = False
            if os.path.getsize(self.path) > 0:
                with open(self.path, "rb") as f:
                    f.seek(-1, os.SEEK_END)
                    needs_nl = f.read(1) != b"\n"
            self._fh = open(self.path, "a")
            if needs_nl:   # never glue a new record onto a torn line
                self._fh.write("\n")

    def append(self, lines: Sequence[str]) -> None:
        if not lines:
            return
        self.open_append()
        self._fh.write("\n".join(lines) + "\n")
        self._fh.flush()
        if self.fsync:
            os.fsync(self._fh.fileno())
        self.appended += len(lines)

    def close(self) -> None:
        if self._fh is not None:
            self._fh.close()
            self._fh = None

    def compact(self, lines: List[str]) -> None:
        self.close()
        self._atomic_write(lines)


def store_semantic_state(path: str, geometry: Optional[Geometry] = None) -> dict:
    """Canonical semantic content of a store (independent of journal history)."""
    img = parse_store(path, geometry)
    return {
        "header": img.header,
        "clock": img.clock,
        "blocks": {f"{k[0]}:{k[1]}": [b.ec, b.flags, b.reads] for k, b in sorted(img.blocks.items())
                   if not b.is_default()},
        "pages": {f"{k[0]}:{k[1]}:{k[2]}": [p.nop, p.flags, fmt_real(p.t_prog),
                                            hashlib.sha256(bytes(p.data)).hexdigest()[:24]]
                  for k, p in sorted(img.pages.items())},
    }


def journal_records(path: str, skip=("M", "C")) -> List[str]:
    out = []
    with open(path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip() or line.split()[0] in skip or line.startswith(STORE_MAGIC):
                continue
            out.append(" ".join(line.split()))
    return out


# =============================================================================
# 6. Bit-level fault model (deterministic, seeded; mirrored in SV)
# =============================================================================
KB_EV = 8.617333262e-5


def arrhenius(ea_ev: float, tref_c: float, t_c: float) -> float:
    return math.exp((ea_ev / KB_EV) * (1.0 / (tref_c + 273.15) - 1.0 / (t_c + 273.15)))


class FaultModel:
    """SLC bit-level error model.

    Persistent errors: each cell gets a fixed 32-bit weakness u (hash of seed,
    address, erase-cycle epoch and bit). The cell reads wrong while
    u < thr32(p), where p depends on the cell's stored value:
        stored 0 : p = p_wear + p_retention      (charge loss -> reads 1)
        stored 1 : p = p_wear + p_read_disturb   (charge gain -> reads 0)
    Because u is fixed per erase epoch, the set of failing cells only grows as
    retention time / read count / wear grow (nested, physically monotone) and
    is exactly reproducible. A new erase epoch re-draws all weaknesses.
    Transient read noise uses an independent per-read hash stream.
    """

    def __init__(self, cfg: Config, tidx: int):
        self.cfg = cfg
        self.f = cfg.faults
        self.g = cfg.geometry
        self.tidx = tidx
        self.tseed = target_seed(self.f.seed, tidx)
        self.af_op = arrhenius(self.f.activation_energy_ev, self.f.reference_temp_c, self.f.operating_temp_c)
        d = cfg.directed
        self.force_prog = {(l, b, p) for (t, l, b, p) in d.force_prog_fail if t == tidx}
        self.force_erase = {(l, b) for (t, l, b) in d.force_erase_fail if t == tidx}
        self.stuck: Dict[Tuple[int, int, int], List[Tuple[int, int]]] = {}
        for (t, l, b, p, bit, v) in d.stuck_bits:
            if t == tidx:
                self.stuck.setdefault((l, b, p), []).append((bit, v))

    # ---- rates (identical expression order in SV) ----
    def cn(self, ec: int) -> float:
        if self.f.rated_endurance_cycles > 0.0:
            return float(ec) / self.f.rated_endurance_cycles
        return 0.0

    def p_wear(self, ec: int) -> float:
        return self.f.rber_fresh + self.f.rber_wear_at_rated * math.pow(self.cn(ec), self.f.wear_exponent)

    def p_ret(self, age_h: float, ec: int) -> float:
        f = self.f
        if age_h <= 0.0 or f.retention_ref_hours <= 0.0:
            return 0.0
        return f.retention_rber_ref * math.pow(age_h / f.retention_ref_hours, f.retention_exponent) * \
            (1.0 + f.retention_wear_gain * self.cn(ec))

    def p_rd(self, reads: int, ec: int) -> float:
        f = self.f
        if f.read_disturb_ref_reads <= 0.0:
            return 0.0
        return f.read_disturb_rber_ref * (float(reads) / f.read_disturb_ref_reads) * \
            (1.0 + f.read_disturb_wear_gain * self.cn(ec))

    def p_prog_fail(self, ec: int) -> float:
        return self.f.prog_fail_fresh + self.f.prog_fail_at_rated * math.pow(self.cn(ec), self.f.prog_fail_exponent)

    def p_erase_fail(self, ec: int) -> float:
        return self.f.erase_fail_fresh + self.f.erase_fail_at_rated * math.pow(self.cn(ec), self.f.erase_fail_exponent)

    def rber_components(self, ec: int, age_h: float, reads: int, unstable: bool, retry: int) -> Dict[str, float]:
        pw = self.p_wear(ec)
        if unstable:
            pw = pw + self.f.interrupted_rber
        pr = self.p_ret(age_h, ec)
        pd = self.p_rd(reads, ec)
        if retry != 0:
            gr = math.pow(self.f.retry_gain, float(retry))
            pr = pr * gr
            pd = pd / gr
        return {"wear": pw, "retention": pr, "read_disturb": pd, "noise": self.f.read_noise_rber}

    # ---- decisions ----
    def prog_fails(self, lun: int, blk: int, pg: int, ec: int, nop: int) -> bool:
        u = hkey(self.tseed, D_PFAIL, lun, blk, pg, ec, nop) >> 32
        return u < thr32(self.p_prog_fail(ec))

    def erase_fails(self, lun: int, blk: int, ec: int) -> bool:
        u = hkey(self.tseed, D_EFAIL, lun, blk, ec) >> 32
        return u < thr32(self.p_erase_fail(ec))

    def factory_bad(self, lun: int) -> List[int]:
        g = self.g
        explicit = sorted({b for (t, l, b) in self.f.factory_bad_blocks if t == self.tidx and l == lun})
        if 0 in explicit:
            raise ValueError("block 0 is guaranteed valid (ONFI); it cannot be listed as factory bad")
        cap = self.cfg.max_bad_blocks_per_lun()
        thr = thr32(self.f.factory_bad_block_rate)
        rnd = []
        if thr:
            for blk in range(1, g.blocks_per_lun):
                if blk in explicit:
                    continue
                if (hkey(self.tseed, D_FBAD, lun, blk) >> 32) < thr:
                    rnd.append(blk)
        room = max(0, cap - len(explicit))
        return sorted(set(explicit) | set(rnd[:room]))

    # ---- bit-level effects ----
    def sense(self, stored: bytes, lun: int, blk: int, pg: int, ec: int, reads: int, unstable: bool,
              age_h: float, retry: int, attribution: bool = False) -> Tuple[bytearray, Dict[str, int]]:
        comp = self.rber_components(ec, age_h, reads, unstable, retry)
        pw, pr, pd = comp["wear"], comp["retention"], comp["read_disturb"]
        thr_w = thr32(pw)
        thr0 = thr32(pw + pr)
        thr1 = thr32(pw + pd)
        thr_n = thr32(self.f.read_noise_rber)
        nbits = len(stored) * 8
        out = bytearray(stored)
        counts = {"wear": 0, "retention": 0, "read_disturb": 0, "noise": 0, "stuck": 0}
        flips = None
        if thr0 or thr1:
            kp = hkey(self.tseed, D_PERSIST, lun, blk, pg, ec)
            u = bit_weakness(kp, nbits)
            bits = bytes_to_bits(stored)
            if np is not None:
                thr = np.where(bits == 0, np.uint64(thr0), np.uint64(thr1))
                fp = u < thr
                if attribution and fp.any():
                    w = fp & (u < np.uint64(thr_w))
                    counts["wear"] = int(w.sum())
                    counts["retention"] = int((fp & ~w & (bits == 0)).sum())
                    counts["read_disturb"] = int((fp & ~w & (bits == 1)).sum())
            else:
                fp = [u[i] < (thr0 if bits[i] == 0 else thr1) for i in range(nbits)]
                if attribution:
                    for i in range(nbits):
                        if fp[i]:
                            if u[i] < thr_w:
                                counts["wear"] += 1
                            elif bits[i] == 0:
                                counts["retention"] += 1
                            else:
                                counts["read_disturb"] += 1
            flips = fp
        if thr_n:
            kn = hkey(self.tseed, D_NOISE, lun, blk, pg, ec, reads)
            un = bit_weakness(kn, nbits)
            if np is not None:
                fn = un < np.uint64(thr_n)
                if attribution:
                    counts["noise"] = int((fn & ~flips).sum()) if flips is not None else int(fn.sum())
                flips = fn if flips is None else (flips | fn)
            else:
                fn = [x < thr_n for x in un]
                if attribution:
                    counts["noise"] = sum(1 for i in range(nbits) if fn[i] and not (flips and flips[i]))
                flips = fn if flips is None else [a or b for a, b in zip(flips, fn)]
        if flips is not None:
            m = bits_to_mask_bytes(flips, len(stored))
            for i, mb in enumerate(m):
                if mb:
                    out[i] ^= mb
        for (bit, v) in self.stuck.get((lun, blk, pg), ()):
            if 0 <= bit < nbits:
                before = (out[bit >> 3] >> (bit & 7)) & 1
                if v:
                    out[bit >> 3] |= 1 << (bit & 7)
                else:
                    out[bit >> 3] &= ~(1 << (bit & 7)) & 0xFF
                if before != (1 if v else 0):
                    counts["stuck"] += 1
        return out, counts

    def partial_program(self, old: bytes, reg: bytes, lun: int, blk: int, pg: int, ec: int, nop: int,
                        frac: float) -> bytearray:
        if frac >= 1.0:
            return bytearray(a & b for a, b in zip(old, reg))
        thr = thr32(frac)
        new = bytearray(old)
        if thr == 0:
            return new
        k = hkey(self.tseed, D_PPART, lun, blk, pg, ec, nop)
        sel = bits_to_mask_bytes(_lt(bit_weakness(k, len(old) * 8), thr), len(old))
        for i in range(len(old)):
            intended = old[i] & ~reg[i] & 0xFF
            new[i] = old[i] & ~(intended & sel[i]) & 0xFF
        return new

    def partial_erase(self, data: bytes, lun: int, blk: int, pg: int, ec_before: int, frac: float) -> bytearray:
        thr = thr32(frac)
        if thr == 0:
            return bytearray(data)
        k = hkey(self.tseed, D_EPART, lun, blk, pg, ec_before)
        sel = bits_to_mask_bytes(_lt(bit_weakness(k, len(data) * 8), thr), len(data))
        return bytearray(a | b for a, b in zip(data, sel))


def _lt(u, thr: int):
    if np is not None:
        return u < np.uint64(thr) if thr < (1 << 64) else np.ones(len(u), dtype=bool)
    return [x < thr for x in u]


# =============================================================================
# 7. Result codes, status register (ONFI bit positions)
# =============================================================================
RC_OK = 0
RC_FAIL_RANDOM = 1
RC_FAIL_FORCED = 2
RC_FAIL_BAD_BLOCK = 3
RC_FAIL_WORN = 4
RC_REJECT_TRANSITION = 5
RC_REJECT_NOP = 6
RC_REJECT_SEQUENCE = 7
RC_REJECT_ADDRESS = 8
RC_WP = 9
RC_NAMES = {RC_OK: "OK", RC_FAIL_RANDOM: "FAIL_RANDOM", RC_FAIL_FORCED: "FAIL_FORCED",
            RC_FAIL_BAD_BLOCK: "FAIL_BAD_BLOCK", RC_FAIL_WORN: "FAIL_WORN",
            RC_REJECT_TRANSITION: "REJECT_TRANSITION", RC_REJECT_NOP: "REJECT_NOP",
            RC_REJECT_SEQUENCE: "REJECT_SEQUENCE", RC_REJECT_ADDRESS: "REJECT_ADDRESS",
            RC_WP: "WRITE_PROTECTED"}
RC_EXECUTES = (RC_OK, RC_FAIL_RANDOM, RC_FAIL_FORCED, RC_FAIL_WORN)  # touch the array

ST_FAIL = 0x01
ST_FAILC = 0x02
ST_ARDY = 0x20
ST_RDY = 0x40
ST_WP_N = 0x80

FEAT_TIMING_MODE = 0x01
FEAT_READ_RETRY = 0xA0   # model-specific (ONFI vendor-specific range 80h-FFh)

ONFI_CMDS = {"READ_1": 0x00, "READ_2": 0x30, "CHANGE_READ_COL_1": 0x05, "CHANGE_READ_COL_2": 0xE0,
             "PROGRAM_1": 0x80, "PROGRAM_2": 0x10, "CHANGE_WRITE_COL": 0x85, "ERASE_1": 0x60,
             "ERASE_2": 0xD0, "READ_STATUS": 0x70, "READ_STATUS_ENH": 0x78, "READ_ID": 0x90,
             "READ_PARAM_PAGE": 0xEC, "GET_FEATURES": 0xEE, "SET_FEATURES": 0xEF, "RESET": 0xFF}


# =============================================================================
# 8. ONFI parameter page and IDs
# =============================================================================
def onfi_crc16(data: bytes) -> int:
    """ONFI parameter-page CRC: poly 0x8005, init 0x4F4E, MSB first, no reflection."""
    crc = 0x4F4E
    for b in data:
        for i in range(7, -1, -1):
            bit = ((crc >> 15) & 1) ^ ((b >> i) & 1)
            crc = (crc << 1) & 0xFFFF
            if bit:
                crc ^= 0x8005
    return crc


def _endurance_code(cycles: float) -> Tuple[int, int]:
    v = int(round(cycles))
    m = 0
    while v > 255 and v % 10 == 0:
        v //= 10
        m += 1
    while v > 255:
        v //= 10
        m += 1
    return v, m


def build_parameter_page(cfg: Config) -> bytes:
    g, t, f, idn, pol = cfg.geometry, cfg.timing, cfg.faults, cfg.ident, cfg.policy
    p = bytearray(256)
    p[0:4] = b"ONFI"
    struct.pack_into("<H", p, 4, 0x0002)                     # ONFI 1.0-style page (no compliance claimed)
    feats = 0
    if g.luns_per_target > 1:
        feats |= 1 << 1                                      # multiple LUN operations
    if not pol.sequential_page_program:
        feats |= 1 << 2                                      # non-sequential page programming
    struct.pack_into("<H", p, 6, feats)
    struct.pack_into("<H", p, 8, (1 << 2) | (1 << 3))        # Get/Set Features, Read Status Enhanced
    p[32:44] = idn.manufacturer.encode("ascii")[:12].ljust(12, b" ")
    p[44:64] = idn.model.encode("ascii")[:20].ljust(20, b" ")
    p[64] = idn.manufacturer_id & 0xFF
    struct.pack_into("<I", p, 80, g.page_data_bytes)
    struct.pack_into("<H", p, 84, g.page_spare_bytes)
    struct.pack_into("<I", p, 92, g.pages_per_block)
    struct.pack_into("<I", p, 96, g.blocks_per_lun)
    p[100] = g.luns_per_target
    p[101] = (2 << 4) | 3                                    # 2 column, 3 row address cycles
    p[102] = g.bits_per_cell
    struct.pack_into("<H", p, 103, cfg.max_bad_blocks_per_lun())
    ev, em = _endurance_code(f.rated_endurance_cycles)
    p[105], p[106] = ev, em
    p[107] = 1                                               # block 0 guaranteed valid
    p[110] = pol.max_programs_per_page & 0xFF
    p[112] = idn.ecc_bits_required & 0xFF
    p[113] = g.plane_bits
    p[128] = 10                                              # I/O capacitance pF (illustrative)
    struct.pack_into("<H", p, 129, 0x003F)                   # async timing modes 0..5
    struct.pack_into("<H", p, 133, min(65535, int(math.ceil(t.t_prog_ns * t.fail_time_factor / 1000.0))))
    struct.pack_into("<H", p, 135, min(65535, int(math.ceil(
        t.t_bers_ns * (1.0 + t.erase_time_wear_slowdown) * t.fail_time_factor / 1000.0))))
    struct.pack_into("<H", p, 137, min(65535, int(math.ceil(t.t_r_ns / 1000.0))))
    struct.pack_into("<H", p, 139, min(65535, int(math.ceil(t.t_ccs_ns))))
    struct.pack_into("<H", p, 164, 0x0001)
    vend = b"NANDLAB SIMULATION MODEL"
    p[166:166 + len(vend)] = vend
    struct.pack_into("<H", p, 254, onfi_crc16(bytes(p[:254])))
    return bytes(p) * 3


def parse_parameter_page(pp: bytes) -> dict:
    """Controller-style decode: first copy whose CRC is valid."""
    for c in range(len(pp) // 256):
        p = pp[c * 256:(c + 1) * 256]
        if p[0:4] != b"ONFI":
            continue
        crc_ok = struct.unpack_from("<H", p, 254)[0] == onfi_crc16(p[:254])
        if not crc_ok:
            continue
        return {
            "copy": c, "crc_ok": True,
            "revision": struct.unpack_from("<H", p, 4)[0],
            "features": struct.unpack_from("<H", p, 6)[0],
            "optional_cmds": struct.unpack_from("<H", p, 8)[0],
            "manufacturer": p[32:44].decode("ascii").strip(),
            "model": p[44:64].decode("ascii").strip(),
            "jedec_id": p[64],
            "page_data_bytes": struct.unpack_from("<I", p, 80)[0],
            "page_spare_bytes": struct.unpack_from("<H", p, 84)[0],
            "pages_per_block": struct.unpack_from("<I", p, 92)[0],
            "blocks_per_lun": struct.unpack_from("<I", p, 96)[0],
            "luns": p[100], "addr_cycles": p[101], "bits_per_cell": p[102],
            "max_bad_blocks_per_lun": struct.unpack_from("<H", p, 103)[0],
            "endurance": p[105] * (10 ** p[106]),
            "guaranteed_blocks": p[107], "nop": p[110], "ecc_bits": p[112], "plane_bits": p[113],
            "timing_modes": struct.unpack_from("<H", p, 129)[0],
            "tPROG_us": struct.unpack_from("<H", p, 133)[0],
            "tBERS_us": struct.unpack_from("<H", p, 135)[0],
            "tR_us": struct.unpack_from("<H", p, 137)[0],
            "tCCS_ns": struct.unpack_from("<H", p, 139)[0],
        }
    return {"crc_ok": False}


def read_id_bytes(cfg: Config, addr: int) -> bytes:
    i = cfg.ident
    if addr == 0x20:
        return b"ONFI\x00"
    return bytes([i.manufacturer_id & 0xFF, i.device_id & 0xFF, i.id_byte3 & 0xFF, i.id_byte4 & 0xFF,
                  i.id_byte5 & 0xFF])


def manufacture_records(cfg: Config, tidx: int, creator: str = "python") -> List[str]:
    """Records written when a target's store is created ("leaves the factory").
    The SV model produces the identical record sequence (apart from M creator)."""
    g = cfg.geometry
    fm = FaultModel(cfg, tidx)
    lines = [rec_header(g, cfg.faults.seed, tidx),
             rec_M("model", "SilicaFlux-NANDLab"), rec_M("version", MODEL_VERSION),
             rec_M("creator", creator), rec_M("config", cfg.fingerprint()),
             rec_C(0.0)]
    mb = cfg.policy.bad_block_marker_byte
    for lun in range(g.luns_per_target):
        for blk in fm.factory_bad(lun):
            lines.append(rec_B(lun, blk, BlockState(0, BF_FACTORY_BAD, 0)))
            for pg in (0, g.pages_per_block - 1):
                d = bytearray(b"\xff" * g.page_bytes)
                d[g.page_data_bytes + mb] = 0x00
                lines.append(rec_P(lun, blk, pg, PageState(d, 0, PF_FACTORY_MARKER, 0.0)))
    return lines


# =============================================================================
# 9. NandTarget -- one chip-enable worth of NAND (== one SV model instance)
# =============================================================================
class ProtocolError(RuntimeError):
    """Host misuse of the device interface (e.g. command to a busy LUN)."""


@dataclass
class InFlight:
    kind: str                      # READ | PROG | ERASE
    lun: int
    blk: int
    pg: int
    t_start: float
    dur: float
    rc: int
    final_frac: float = 1.0
    reg: Optional[bytearray] = None
    mask: Optional[bytearray] = None
    data: Optional[bytearray] = None
    ec: int = 0
    nop: int = 0
    seq: int = 0
    info: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OpResult:
    op: str
    rc: int
    status: int
    busy_ns: float
    t_start: float
    lun: int = 0
    blk: int = 0
    pg: int = 0
    data: Optional[bytes] = None
    info: Dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.rc == RC_OK

    @property
    def code(self) -> str:
        return RC_NAMES.get(self.rc, str(self.rc))


class NandTarget:
    """Behavioural NAND target with persistent, journalled array state.

    Two-phase operations (begin_* / finish / abort) let a scheduler or a power
    cut interrupt an operation part-way; the convenience methods
    (read_page/program_page/erase_block) run an operation to completion and
    advance the target's powered time (``now_ns``) by its busy time.
    """

    def __init__(self, cfg: Config, path: str, target_index: int = 0, create: bool = True,
                 creator: str = "python", journal: bool = True):
        cfg.validate()
        self.cfg = cfg
        self.g = cfg.geometry
        self.tidx = target_index
        self.fm = FaultModel(cfg, target_index)
        self.path = path
        self.store = BackingStore(path, fsync=cfg.store.fsync)
        self.journal_enabled = journal
        self.created = False
        self.warnings: List[str] = []
        if not self.store.exists():
            if not create:
                raise StoreError(f"store {path} does not exist")
            self.store.create(manufacture_records(cfg, target_index, creator))
            self.created = True
        img = parse_store(path, self.g)
        if img.header["target"] != target_index:
            raise StoreError(f"{path} belongs to target {img.header['target']}, not {target_index}")
        if img.header["seed"] != (cfg.faults.seed & M64):
            raise StoreError(f"{path} was manufactured with seed {img.header['seed']:#x}; the configuration "
                             f"uses {cfg.faults.seed:#x}. Cell weaknesses are seed-derived, so the seed "
                             f"of an existing device cannot change.")
        if img.torn_tail:
            self.warnings.append(f"{img.torn_count} torn (unterminated) journal record(s) ignored: "
                                 f"'{img.torn_text}...'")
        self.load_stats = {"records": img.records, "torn_records": img.torn_count}
        self.pages: Dict[Tuple[int, int, int], PageState] = img.pages
        self.blocks: Dict[Tuple[int, int], BlockState] = img.blocks
        self.meta = img.meta
        self.clock_base = img.clock
        self.now_ns = 0.0
        self.auto_advance = True
        self.powered = True
        self.needs_reset = cfg.policy.require_reset_after_power_on
        self.poweron_reset_pending = True
        self.wp_n = True
        self.retry_level = 0
        self.timing_mode = cfg.timing.timing_mode
        L = self.g.luns_per_target
        self.inflight: List[Optional[InFlight]] = [None] * L
        self.fail = [0] * L
        self.failc = [0] * L
        self.page_register: List[Optional[bytearray]] = [None] * L
        self.sel_lun = 0
        self.seq = 0
        self.violations: List[Dict[str, Any]] = []
        self.history: List[Dict[str, Any]] = []
        self.history_limit = 20000
        self.counters = {"reads": 0, "programs": 0, "erases": 0, "prog_fail": 0, "erase_fail": 0,
                         "rejects": 0, "aborts": 0, "bit_errors": 0}

    # ------------------------------------------------------------------ time
    def clock(self, t_ns: Optional[float] = None) -> float:
        t = self.now_ns if t_ns is None else t_ns
        return self.clock_base + (t * 1e-9) * self.fm.af_op

    def advance(self, ns: float) -> None:
        self.now_ns += ns

    def bake(self, hours: float, temp_c: float) -> float:
        """Time spent unpowered at temp_c (retention bake / shelf time)."""
        f = self.cfg.faults
        self.clock_base = self.clock_base + hours * 3600.0 * arrhenius(f.activation_energy_ev,
                                                                        f.reference_temp_c, temp_c)
        self._j(rec_C(self.clock()))
        return self.clock()

    # ----------------------------------------------------------------- state
    def block(self, lun: int, blk: int) -> BlockState:
        return self.blocks.get((lun, blk)) or BlockState()

    def _block_mut(self, lun: int, blk: int) -> BlockState:
        b = self.blocks.get((lun, blk))
        if b is None:
            b = BlockState()
            self.blocks[(lun, blk)] = b
        return b

    def page(self, lun: int, blk: int, pg: int) -> Optional[PageState]:
        return self.pages.get((lun, blk, pg))

    def peek(self, lun: int, blk: int, pg: int) -> bytes:
        """Backdoor: committed cell contents without read errors."""
        ps = self.pages.get((lun, blk, pg))
        return bytes(ps.data) if ps else b"\xff" * self.g.page_bytes

    def highest_programmed(self, lun: int, blk: int) -> int:
        hp = -1
        for pg in range(self.g.pages_per_block):
            ps = self.pages.get((lun, blk, pg))
            if ps is not None and ps.nop > 0:
                hp = pg
        return hp

    def t_prog(self, ec: int) -> float:
        t = self.cfg.timing
        fct = 1.0 - t.prog_time_wear_speedup * self.fm.cn(ec)
        if fct < t.prog_time_floor:
            fct = t.prog_time_floor
        return t.t_prog_ns * fct

    def t_erase(self, ec: int) -> float:
        t = self.cfg.timing
        return t.t_bers_ns * (1.0 + t.erase_time_wear_slowdown * self.fm.cn(ec))

    def iface(self) -> Dict[str, float]:
        return ONFI_ASYNC_MODES[self.timing_mode]

    def worn(self, ec: int) -> bool:
        f = self.cfg.faults
        return f.endurance_hard_limit_factor > 0.0 and float(ec) >= f.endurance_hard_limit_factor * f.rated_endurance_cycles

    # --------------------------------------------------------------- journal
    def _j(self, *lines: str) -> None:
        if self.journal_enabled:
            self.store.append(lines)

    def _jpage(self, lun: int, blk: int, pg: int) -> None:
        self._j(rec_P(lun, blk, pg, self.pages[(lun, blk, pg)]))

    def _jblock(self, lun: int, blk: int) -> None:
        self._j(rec_B(lun, blk, self.block(lun, blk)))

    def _violation(self, kind: str, msg: str, **kw) -> None:
        v = {"t_ns": self.now_ns, "kind": kind, "msg": msg}
        v.update(kw)
        self.violations.append(v)

    def _hist(self, op: str, lun: int, blk: int, pg: int, rc: int, t: float, dur: float, **kw) -> None:
        if len(self.history) < self.history_limit:
            h = {"t_ns": t, "op": op, "lun": lun, "blk": blk, "pg": pg, "rc": RC_NAMES[rc], "busy_ns": dur}
            h.update(kw)
            self.history.append(h)

    # ------------------------------------------------------------ host rules
    def _require_ready(self, lun: Optional[int] = None) -> None:
        if not self.powered:
            raise ProtocolError("target is powered off")
        if self.needs_reset:
            raise ProtocolError("RESET (FFh) must be the first command after power-on")
        if lun is not None:
            if not (0 <= lun < self.g.luns_per_target):
                raise ProtocolError(f"LUN {lun} does not exist")
            if self.inflight[lun] is not None:
                raise ProtocolError(f"LUN {lun} is busy")

    def _t(self, t_ns: Optional[float]) -> float:
        return self.now_ns if t_ns is None else float(t_ns)

    # =========================================================== operations
    def begin_read(self, lun: int, blk: int, pg: int, t_ns: Optional[float] = None,
                   attribution: bool = False) -> InFlight:
        self._require_ready(lun)
        t = self._t(t_ns)
        self.seq += 1
        g = self.g
        if not g.valid(lun, blk, pg):
            op = InFlight("READ", lun, blk, pg, t, self.cfg.timing.t_reject_ns, RC_REJECT_ADDRESS, seq=self.seq,
                          data=bytearray(b"\xff" * g.page_bytes))
        else:
            b = self._block_mut(lun, blk)
            b.reads += 1
            if self.cfg.store.persist_read_counts:
                self._j(rec_R(lun, blk, b.reads))
            ps = self.pages.get((lun, blk, pg))
            stored = ps.data if ps else b"\xff" * g.page_bytes
            age_h = 0.0
            unstable = bool(b.flags & BF_MARGINAL)
            if ps is not None:
                age_h = (self.clock(t) - ps.t_prog) / 3600.0
                unstable = unstable or bool(ps.flags & PF_UNSTABLE)
            data, counts = self.fm.sense(stored, lun, blk, pg, b.ec, b.reads, unstable, age_h,
                                         self.retry_level, attribution)
            op = InFlight("READ", lun, blk, pg, t, self.cfg.timing.t_r_ns, RC_OK, seq=self.seq, data=data,
                          ec=b.ec, info={"errors": counts, "age_h": age_h, "reads": b.reads,
                                         "retry": self.retry_level})
        self.inflight[lun] = op
        self.sel_lun = lun
        return op

    def begin_program(self, lun: int, blk: int, pg: int, reg: bytes, mask: bytes,
                      t_ns: Optional[float] = None) -> InFlight:
        self._require_ready(lun)
        t = self._t(t_ns)
        self.seq += 1
        g, tm, pol = self.g, self.cfg.timing, self.cfg.policy
        reg = bytearray(reg)
        mask = bytearray(mask)
        info: Dict[str, Any] = {}
        if not g.valid(lun, blk, pg):
            rc, dur, ff, ec, nop = RC_REJECT_ADDRESS, tm.t_reject_ns, 0.0, 0, 0
        else:
            b = self.block(lun, blk)
            ec = b.ec
            ps = self.pages.get((lun, blk, pg))
            old = ps.data if ps else b"\xff" * g.page_bytes
            nop = ps.nop if ps else 0
            ff = 1.0
            if not self.wp_n:
                rc, dur = RC_WP, 0.0
            elif b.flags & BF_FACTORY_BAD:
                rc, dur = RC_FAIL_BAD_BLOCK, self.t_prog(ec) * tm.fail_time_factor
            elif nop >= pol.max_programs_per_page:
                rc, dur = RC_REJECT_NOP, tm.t_reject_ns
            elif pol.sequential_page_program and nop == 0 and pg != self.highest_programmed(lun, blk) + 1:
                rc, dur = RC_REJECT_SEQUENCE, tm.t_reject_ns
                info["expected_page"] = self.highest_programmed(lun, blk) + 1
            else:
                bad = 0
                skip_ff = pol.invalid_transition_policy == "reject_non_ff"
                for i in range(g.page_bytes):
                    if mask[i] and (reg[i] & ~old[i] & 0xFF) and not (skip_ff and reg[i] == 0xFF):
                        bad += 1
                info["zero_to_one_bytes"] = bad
                if bad and pol.invalid_transition_policy in ("reject", "reject_non_ff"):
                    rc, dur = RC_REJECT_TRANSITION, tm.t_reject_ns
                elif (lun, blk, pg) in self.fm.force_prog:
                    rc, dur, ff = RC_FAIL_FORCED, self.t_prog(ec) * tm.fail_time_factor, \
                        self.cfg.faults.prog_fail_partial_fraction
                elif self.fm.prog_fails(lun, blk, pg, ec, nop):
                    rc, dur, ff = RC_FAIL_RANDOM, self.t_prog(ec) * tm.fail_time_factor, \
                        self.cfg.faults.prog_fail_partial_fraction
                else:
                    rc, dur = RC_OK, self.t_prog(ec)
                if bad and pol.invalid_transition_policy == "and":
                    self._violation("zero_to_one", f"{bad} byte(s) request 0->1; AND semantics applied",
                                    lun=lun, blk=blk, pg=pg)
        if rc in (RC_REJECT_NOP, RC_REJECT_SEQUENCE, RC_REJECT_TRANSITION, RC_REJECT_ADDRESS):
            self._violation(RC_NAMES[rc].lower(), f"program rejected at lun {lun} blk {blk} pg {pg}",
                            lun=lun, blk=blk, pg=pg)
        op = InFlight("PROG", lun, blk, pg, t, dur, rc, ff, reg, mask, None, ec, nop, self.seq, info)
        self.inflight[lun] = op
        self.sel_lun = lun
        return op

    def begin_erase(self, lun: int, blk: int, t_ns: Optional[float] = None) -> InFlight:
        self._require_ready(lun)
        t = self._t(t_ns)
        self.seq += 1
        g, tm, f = self.g, self.cfg.timing, self.cfg.faults
        ff = 1.0
        if not g.valid(lun, blk, 0):
            rc, dur, ec = RC_REJECT_ADDRESS, tm.t_reject_ns, 0
            self._violation("reject_address", f"erase rejected lun {lun} blk {blk}", lun=lun, blk=blk)
        else:
            b = self.block(lun, blk)
            ec = b.ec
            te = self.t_erase(ec)
            if not self.wp_n:
                rc, dur = RC_WP, 0.0
            elif (b.flags & BF_FACTORY_BAD) and self.cfg.policy.factory_bad_erase == "fail_keep_marker":
                rc, dur = RC_FAIL_BAD_BLOCK, te * tm.fail_time_factor
                self._violation("erase_factory_bad", f"erase issued to factory-bad block {blk}", lun=lun, blk=blk)
            elif (lun, blk) in self.fm.force_erase:
                rc, dur, ff = RC_FAIL_FORCED, te * tm.fail_time_factor, f.erase_fail_partial_fraction
            elif self.worn(ec) or (f.erase_fail_sticky and (b.flags & BF_ERASE_FAILED)):
                rc, dur, ff = RC_FAIL_WORN, te * tm.fail_time_factor, f.erase_fail_partial_fraction
            elif self.fm.erase_fails(lun, blk, ec):
                rc, dur, ff = RC_FAIL_RANDOM, te * tm.fail_time_factor, f.erase_fail_partial_fraction
            else:
                rc, dur = RC_OK, te
                if b.flags & BF_FACTORY_BAD:
                    self._violation("erase_factory_bad", f"factory-bad block {blk} erased; marker lost",
                                    lun=lun, blk=blk)
        op = InFlight("ERASE", lun, blk, 0, t, dur, rc, ff, ec=ec, seq=self.seq)
        self.inflight[lun] = op
        self.sel_lun = lun
        return op

    # ------------------------------------------------------------- complete
    def _set_fail(self, lun: int, rc: int) -> None:
        self.failc[lun] = self.fail[lun]
        self.fail[lun] = 0 if rc == RC_OK else 1

    def finish(self, op: InFlight) -> OpResult:
        if self.inflight[op.lun] is not op:
            raise ProtocolError("operation is not in flight")
        self.inflight[op.lun] = None
        lun, blk, pg = op.lun, op.blk, op.pg
        out = None
        if op.kind == "READ":
            self.page_register[lun] = op.data
            out = bytes(op.data)
            self.counters["reads"] += 1
            e = op.info.get("errors")
            if e:
                self.counters["bit_errors"] += sum(e.values())
        elif op.kind == "PROG":
            self.counters["programs"] += 1
            if op.rc in RC_EXECUTES:
                self._apply_program(op, op.final_frac, PF_PROG_FAILED if op.rc != RC_OK else 0)
                if op.rc != RC_OK:
                    self._block_mut(lun, blk).flags |= BF_PROG_FAILED
                    self._jblock(lun, blk)
                    self.counters["prog_fail"] += 1
            elif op.rc != RC_WP:
                self.counters["rejects"] += 1
        elif op.kind == "ERASE":
            self.counters["erases"] += 1
            if op.rc == RC_OK:
                self._apply_erase_ok(op)
            elif op.rc in RC_EXECUTES:
                self._apply_erase_partial(op, op.final_frac, BF_ERASE_FAILED | BF_MARGINAL)
                self.counters["erase_fail"] += 1
        self._set_fail(lun, op.rc)
        self._hist(op.kind, lun, blk, pg, op.rc, op.t_start, op.dur)
        return OpResult(op.kind, op.rc, self.read_status(lun), op.dur, op.t_start, lun, blk, pg, out, op.info)

    def abort(self, op: InFlight, frac: float, cause: str = "PCUT") -> None:
        """Interrupt an in-flight operation after `frac` of its busy time."""
        if self.inflight[op.lun] is not op:
            raise ProtocolError("operation is not in flight")
        self.inflight[op.lun] = None
        frac = min(1.0, max(0.0, frac))
        self.counters["aborts"] += 1
        if op.kind == "PROG" and op.rc in RC_EXECUTES and frac > 0.0:
            self._apply_program(op, frac * op.final_frac, PF_PROG_INTERRUPTED)
        elif op.kind == "ERASE" and op.rc in RC_EXECUTES and frac > 0.0:
            self._apply_erase_partial(op, frac * op.final_frac, BF_MARGINAL | BF_ERASE_INTERRUPTED)
        self.page_register[op.lun] = None
        self._hist(op.kind + "_ABORT", op.lun, op.blk, op.pg, op.rc, op.t_start, op.dur, cause=cause, frac=frac)

    def _apply_program(self, op: InFlight, frac: float, flag: int) -> None:
        key = (op.lun, op.blk, op.pg)
        ps = self.pages.get(key)
        old = ps.data if ps else bytearray(b"\xff" * self.g.page_bytes)
        new = self.fm.partial_program(old, op.reg, op.lun, op.blk, op.pg, op.ec, op.nop, frac)
        nps = PageState(new, (ps.nop if ps else 0) + 1, (ps.flags if ps else 0) | flag, self.clock(op.t_start))
        self.pages[key] = nps
        self._jpage(*key)

    def _apply_erase_ok(self, op: InFlight) -> None:
        lun, blk = op.lun, op.blk
        for pg in range(self.g.pages_per_block):
            self.pages.pop((lun, blk, pg), None)
        b = self._block_mut(lun, blk)
        b.ec += 1
        b.reads = 0
        b.flags &= ~(BF_MARGINAL | BF_ERASE_INTERRUPTED) & 0xFF
        if self.worn(b.ec):
            b.flags |= BF_WORN_OUT
        self._j(rec_E(lun, blk, self.clock(op.t_start)))
        self._jblock(lun, blk)

    def _apply_erase_partial(self, op: InFlight, frac: float, bflags: int) -> None:
        lun, blk = op.lun, op.blk
        b = self._block_mut(lun, blk)
        ec_before = b.ec
        for pg in range(self.g.pages_per_block):
            ps = self.pages.get((lun, blk, pg))
            if ps is None:
                continue
            ps.data = self.fm.partial_erase(ps.data, lun, blk, pg, ec_before, frac)
            ps.flags |= PF_PARTIAL_ERASE
            self._jpage(lun, blk, pg)
        b.ec += 1
        b.flags |= bflags
        if self.worn(b.ec):
            b.flags |= BF_WORN_OUT
        self._jblock(lun, blk)

    def _sync(self, op: InFlight) -> OpResult:
        res = self.finish(op)
        if self.auto_advance:
            self.now_ns = op.t_start + op.dur
        return res

    # ------------------------------------------------- convenience (atomic)
    def read_page(self, lun: int, blk: int, pg: int, col: int = 0, length: Optional[int] = None,
                  t_ns: Optional[float] = None, retry: Optional[int] = None,
                  attribution: bool = False) -> OpResult:
        saved = self.retry_level
        if retry is not None:
            self.retry_level = self._clamp_retry(retry)
        try:
            res = self._sync(self.begin_read(lun, blk, pg, t_ns, attribution))
        finally:
            self.retry_level = saved
        n = self.g.page_bytes
        length = n - col if length is None else length
        d = res.data or b""
        res.data = (d + b"\xff" * max(0, col + length - n))[col:col + length]
        return res

    def program_page(self, lun: int, blk: int, pg: int, data: bytes, col: int = 0,
                     t_ns: Optional[float] = None) -> OpResult:
        n = self.g.page_bytes
        reg = bytearray(b"\xff" * n)
        mask = bytearray(n)
        over = 0
        for i, v in enumerate(data):
            c = col + i
            if c < n:
                reg[c] = v
                mask[c] = 1
            else:
                over += 1
        if over:
            self._violation("column_overflow", f"{over} data byte(s) beyond end of page ignored",
                            lun=lun, blk=blk, pg=pg)
        return self._sync(self.begin_program(lun, blk, pg, reg, mask, t_ns))

    def program_register(self, lun: int, blk: int, pg: int, reg: bytes, mask: bytes,
                         t_ns: Optional[float] = None) -> OpResult:
        return self._sync(self.begin_program(lun, blk, pg, reg, mask, t_ns))

    def erase_block(self, lun: int, blk: int, t_ns: Optional[float] = None) -> OpResult:
        return self._sync(self.begin_erase(lun, blk, t_ns))

    # --------------------------------------------------------- target-level
    def read_status(self, lun: Optional[int] = None) -> int:
        lun = self.sel_lun if lun is None else lun
        st = ST_WP_N if self.wp_n else 0
        if self.inflight[lun] is None:
            st |= ST_RDY | ST_ARDY
        if self.fail[lun]:
            st |= ST_FAIL
        if self.failc[lun]:
            st |= ST_FAILC
        return st

    def reset(self, t_ns: Optional[float] = None) -> OpResult:
        if not self.powered:
            raise ProtocolError("target is powered off")
        t = self._t(t_ns)
        tm = self.cfg.timing
        dur = tm.t_rst_poweron_ns if self.poweron_reset_pending else tm.t_rst_idle_ns
        for lun, op in enumerate(self.inflight):
            if op is None:
                continue
            frac = (t - op.t_start) / op.dur if op.dur > 0 else 1.0
            if op.kind == "PROG":
                dur = max(dur, tm.t_rst_prog_ns)
            elif op.kind == "ERASE":
                dur = max(dur, tm.t_rst_erase_ns)
            self.abort(op, frac, "RESET")
        self.needs_reset = False
        self.poweron_reset_pending = False
        L = self.g.luns_per_target
        self.fail = [0] * L
        self.failc = [0] * L
        self.page_register = [None] * L
        if self.auto_advance:
            self.now_ns = t + dur
        return OpResult("RESET", RC_OK, self.read_status(0), dur, t)

    def power_off(self, t_ns: Optional[float] = None) -> List[Dict[str, Any]]:
        t = self._t(t_ns)
        cut = []
        for op in list(self.inflight):
            if op is None:
                continue
            frac = (t - op.t_start) / op.dur if op.dur > 0 else 1.0
            cut.append({"op": op.kind, "lun": op.lun, "blk": op.blk, "pg": op.pg, "frac": frac})
            self.abort(op, frac, "PCUT")
        self.powered = False
        L = self.g.luns_per_target
        self.fail = [0] * L
        self.failc = [0] * L
        self.page_register = [None] * L
        self.retry_level = 0
        self.timing_mode = 0
        self.now_ns = t
        return cut

    def power_on(self, t_ns: Optional[float] = None) -> None:
        self.now_ns = self._t(t_ns)
        self.powered = True
        self.needs_reset = self.cfg.policy.require_reset_after_power_on
        self.poweron_reset_pending = True

    def set_write_protect(self, protected: bool) -> None:
        self.wp_n = not protected

    def read_id(self, addr: int = 0x00) -> bytes:
        self._require_ready()
        return read_id_bytes(self.cfg, addr)

    def read_parameter_page(self, t_ns: Optional[float] = None) -> bytes:
        self._require_ready()
        if any(op is not None for op in self.inflight):
            raise ProtocolError("READ PARAMETER PAGE requires all LUNs idle")
        if self.auto_advance:
            self.now_ns = self._t(t_ns) + self.cfg.timing.t_r_ns
        return build_parameter_page(self.cfg)

    def _clamp_retry(self, lvl: int) -> int:
        m = self.cfg.faults.retry_max_level
        return max(-m, min(m, int(lvl)))

    def set_feature(self, addr: int, params: Sequence[int], t_ns: Optional[float] = None) -> OpResult:
        self._require_ready()
        t = self._t(t_ns)
        p = list(params) + [0, 0, 0, 0]
        if addr == FEAT_TIMING_MODE:
            m = p[0] & 0x0F
            if m in ONFI_ASYNC_MODES:
                self.timing_mode = m
            else:
                self._violation("feature", f"unsupported timing mode {m}")
        elif addr == FEAT_READ_RETRY:
            v = p[0] & 0xFF
            self.retry_level = self._clamp_retry(v - 256 if v >= 128 else v)
        else:
            self._violation("feature", f"unsupported feature address {addr:#04x}")
        if self.auto_advance:
            self.now_ns = t + self.cfg.timing.t_feat_ns
        return OpResult("SETF", RC_OK, self.read_status(), self.cfg.timing.t_feat_ns, t)

    def get_feature(self, addr: int) -> bytes:
        self._require_ready()
        if addr == FEAT_TIMING_MODE:
            return bytes([self.timing_mode, 0, 0, 0])
        if addr == FEAT_READ_RETRY:
            return bytes([self.retry_level & 0xFF, 0, 0, 0])
        return b"\x00\x00\x00\x00"

    # -------------------------------------------------------------- backdoor
    def precondition_wear(self, lun: int, blk: int, cycles: int) -> None:
        """Accelerated preconditioning: add P/E cycles to a block's history
        without simulating each erase (documented shortcut)."""
        b = self._block_mut(lun, blk)
        b.ec += int(cycles)
        if self.worn(b.ec):
            b.flags |= BF_WORN_OUT
        self._jblock(lun, blk)

    def scan_bad_block_markers(self, use_reads: bool = False) -> List[Tuple[int, int]]:
        """Controller-style factory bad-block scan (spare byte of first/last page)."""
        g = self.g
        off = g.page_data_bytes + self.cfg.policy.bad_block_marker_byte
        bad = []
        for lun in range(g.luns_per_target):
            for blk in range(g.blocks_per_lun):
                marks = []
                for pg in (0, g.pages_per_block - 1):
                    if use_reads:
                        marks.append(self.read_page(lun, blk, pg, col=off, length=1).data[0])
                    else:
                        marks.append(self.peek(lun, blk, pg)[off])
                if any(m != 0xFF for m in marks):
                    bad.append((lun, blk))
        return bad

    def ground_truth_bad(self) -> List[Tuple[int, int, List[str]]]:
        out = []
        for (lun, blk), b in sorted(self.blocks.items()):
            names = flag_names(b.flags & (BF_FACTORY_BAD | BF_ERASE_FAILED | BF_PROG_FAILED | BF_WORN_OUT),
                               BLOCK_FLAG_NAMES)
            if names:
                out.append((lun, blk, names))
        return out

    # ----------------------------------------------------------- lifecycle
    def snapshot_lines(self) -> List[str]:
        lines = [rec_header(self.g, self.cfg.faults.seed, self.tidx)]
        for k in ("model", "version", "creator", "config"):
            if k in self.meta:
                lines.append(rec_M(k, self.meta[k]))
        lines.append(rec_M("compacted", "1"))
        lines.append(rec_C(self.clock()))
        for (lun, blk), b in sorted(self.blocks.items()):
            if not b.is_default():
                lines.append(rec_B(lun, blk, b))
        for (lun, blk, pg), ps in sorted(self.pages.items()):
            lines.append(rec_P(lun, blk, pg, ps))
        return lines

    def compact(self) -> None:
        self.store.compact(self.snapshot_lines())

    def close(self, checkpoint: bool = True) -> None:
        if checkpoint and self.journal_enabled:
            self._j(rec_C(self.clock()))
        self.store.close()


# =============================================================================
# 10. NandFlashTwin -- the whole array (channels x packages x targets)
# =============================================================================
class NandFlashTwin:
    MANIFEST = "nandlab.json"

    def __init__(self, cfg: Config, store_dir: str, create: bool = True, reset: bool = True):
        self.cfg = cfg.validate()
        self.dir = store_dir
        os.makedirs(store_dir, exist_ok=True)
        mpath = os.path.join(store_dir, self.MANIFEST)
        if os.path.exists(mpath):
            with open(mpath) as f:
                man = json.load(f)
            if man.get("geometry_fingerprint") != cfg.geometry_fingerprint():
                raise StoreError(f"{store_dir}: store geometry differs from configuration")
        else:
            if not create:
                raise StoreError(f"{store_dir} is not a NANDLab store")
            man = {"model": MODEL_NAME, "version": MODEL_VERSION, "project": PROJECT,
                   "store_format": f"{STORE_MAGIC} v{STORE_VERSION}",
                   "geometry_fingerprint": cfg.geometry_fingerprint(),
                   "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   "config": cfg.to_dict()}
            with open(mpath, "w") as f:
                json.dump(man, f, indent=2)
        self.manifest = man
        export_svcfg(cfg, os.path.join(store_dir, "nandlab.svcfg"))
        g = cfg.geometry
        self.targets: List[NandTarget] = [
            NandTarget(cfg, os.path.join(store_dir, f"target{i}.nlsf"), i, create) for i in range(g.targets)]
        if reset:
            for t in self.targets:
                t.reset()

    def t(self, ch: int, pkg: int = 0, tgt: int = 0) -> NandTarget:
        return self.targets[self.cfg.geometry.target_index(ch, pkg, tgt)]

    def bake(self, hours: float, temp_c: float) -> None:
        for t in self.targets:
            t.bake(hours, temp_c)

    def close(self) -> None:
        for t in self.targets:
            t.close()

    def compact(self) -> None:
        for t in self.targets:
            t.compact()


# =============================================================================
# 13a. SystemVerilog configuration export (runtime config read by the SV model)
# =============================================================================
def export_svcfg(cfg: Config, path: str) -> str:
    g, t, p, i, f, d = cfg.geometry, cfg.timing, cfg.policy, cfg.ident, cfg.faults, cfg.directed
    R = fmt_real
    L = ["nandlab_svcfg 1",
         f"page_data_bytes {g.page_data_bytes}", f"page_spare_bytes {g.page_spare_bytes}",
         f"pages_per_block {g.pages_per_block}", f"blocks_per_lun {g.blocks_per_lun}",
         f"planes_per_lun {g.planes_per_lun}", f"luns {g.luns_per_target}",
         f"seed {f.seed & M64:016x}", f"config_fp {cfg.fingerprint()}", f"profile {f.profile}",
         f"nop {p.max_programs_per_page}", f"sequential {int(p.sequential_page_program)}",
         f"invalid_policy {INVALID_POLICIES[p.invalid_transition_policy]}",
         f"factory_bad_erase {0 if p.factory_bad_erase == 'fail_keep_marker' else 1}",
         f"require_reset {int(p.require_reset_after_power_on)}", f"bbm_byte {p.bad_block_marker_byte}",
         f"max_bad_per_lun {cfg.max_bad_blocks_per_lun()}", f"ecc_bits {i.ecc_bits_required}",
         f"id_mfr {i.manufacturer_id & 0xFF:02x}", f"id_dev {i.device_id & 0xFF:02x}",
         f"id_b3 {i.id_byte3 & 0xFF:02x}", f"id_b4 {i.id_byte4 & 0xFF:02x}", f"id_b5 {i.id_byte5 & 0xFF:02x}",
         f"mfr_name {i.manufacturer.replace(' ', '_')[:12]}", f"model_name {i.model.replace(' ', '_')[:20]}",
         f"timing_mode {t.timing_mode}",
         f"t_r_ns {R(t.t_r_ns)}", f"t_prog_ns {R(t.t_prog_ns)}", f"t_bers_ns {R(t.t_bers_ns)}",
         f"t_rst_idle_ns {R(t.t_rst_idle_ns)}", f"t_rst_prog_ns {R(t.t_rst_prog_ns)}",
         f"t_rst_erase_ns {R(t.t_rst_erase_ns)}", f"t_rst_poweron_ns {R(t.t_rst_poweron_ns)}",
         f"t_feat_ns {R(t.t_feat_ns)}", f"t_reject_ns {R(t.t_reject_ns)}", f"t_ccs_ns {R(t.t_ccs_ns)}",
         f"prog_time_wear_speedup {R(t.prog_time_wear_speedup)}", f"prog_time_floor {R(t.prog_time_floor)}",
         f"erase_time_wear_slowdown {R(t.erase_time_wear_slowdown)}",
         f"fail_time_factor {R(t.fail_time_factor)}",
         f"timing_checks {int(t.timing_checks)}", f"timing_fatal {int(t.timing_fatal)}",
         f"rated_endurance {R(f.rated_endurance_cycles)}", f"hard_limit_factor {R(f.endurance_hard_limit_factor)}",
         f"rber_fresh {R(f.rber_fresh)}", f"rber_wear_at_rated {R(f.rber_wear_at_rated)}",
         f"wear_exponent {R(f.wear_exponent)}",
         f"retention_rber_ref {R(f.retention_rber_ref)}", f"retention_ref_hours {R(f.retention_ref_hours)}",
         f"retention_exponent {R(f.retention_exponent)}", f"retention_wear_gain {R(f.retention_wear_gain)}",
         f"read_disturb_rber_ref {R(f.read_disturb_rber_ref)}",
         f"read_disturb_ref_reads {R(f.read_disturb_ref_reads)}",
         f"read_disturb_wear_gain {R(f.read_disturb_wear_gain)}",
         f"read_noise_rber {R(f.read_noise_rber)}", f"interrupted_rber {R(f.interrupted_rber)}",
         f"prog_fail_fresh {R(f.prog_fail_fresh)}", f"prog_fail_at_rated {R(f.prog_fail_at_rated)}",
         f"prog_fail_exponent {R(f.prog_fail_exponent)}",
         f"erase_fail_fresh {R(f.erase_fail_fresh)}", f"erase_fail_at_rated {R(f.erase_fail_at_rated)}",
         f"erase_fail_exponent {R(f.erase_fail_exponent)}", f"erase_fail_sticky {int(f.erase_fail_sticky)}",
         f"prog_fail_partial {R(f.prog_fail_partial_fraction)}",
         f"erase_fail_partial {R(f.erase_fail_partial_fraction)}",
         f"factory_bad_rate {R(f.factory_bad_block_rate)}",
         f"retry_gain {R(f.retry_gain)}", f"retry_max_level {f.retry_max_level}",
         f"ea_ev {R(f.activation_energy_ev)}", f"ref_temp_c {R(f.reference_temp_c)}",
         f"op_temp_c {R(f.operating_temp_c)}", f"persist_read_counts {int(cfg.store.persist_read_counts)}"]
    for (tt, l, b) in f.factory_bad_blocks:
        L.append(f"factory_bad {tt} {l} {b}")
    for (tt, l, b, pg) in d.force_prog_fail:
        L.append(f"force_prog_fail {tt} {l} {b} {pg}")
    for (tt, l, b) in d.force_erase_fail:
        L.append(f"force_erase_fail {tt} {l} {b}")
    for (tt, l, b, pg, bit, v) in d.stuck_bits:
        L.append(f"stuck_bit {tt} {l} {b} {pg} {bit} {v}")
    L.append("end")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as fh:
        fh.write("\n".join(L) + "\n")
    return path


def export_sv_geometry(cfg: Config, path: str) -> str:
    g = cfg.geometry
    txt = (f"// generated by nand_flash_twin.py export-sv -- geometry for nand_flash_model parameters\n"
           f"`define NANDLAB_PAGE_DATA_BYTES {g.page_data_bytes}\n"
           f"`define NANDLAB_PAGE_SPARE_BYTES {g.page_spare_bytes}\n"
           f"`define NANDLAB_PAGES_PER_BLOCK {g.pages_per_block}\n"
           f"`define NANDLAB_BLOCKS_PER_PLANE {g.blocks_per_plane}\n"
           f"`define NANDLAB_PLANES_PER_LUN {g.planes_per_lun}\n"
           f"`define NANDLAB_LUNS {g.luns_per_target}\n")
    with open(path, "w") as fh:
        fh.write(txt)
    return path


# =============================================================================
# 13b. SV trace replay (co-simulation) and SV regression driver
# =============================================================================
def parse_trace(path: str) -> List[List[str]]:
    recs = []
    with open(path) as f:
        for line in f:
            toks = line.split()
            if toks and toks[-1] == ";":
                recs.append(toks[:-1])
    return recs


def replay_trace(cfg: Config, store_before: str, trace_path: str, work_path: str,
                 target_index: int = 0, max_mismatch: int = 50) -> Dict[str, Any]:
    """Replay the SV model's own operation trace through the Python golden model,
    starting from the store as it was before the SV run. Every BEGIN decision
    (result code, busy time, sensed data incl. bit errors, read counter),
    every DONE status and the resulting journal are compared exactly."""
    shutil.copyfile(store_before, work_path)
    t = NandTarget(cfg, work_path, target_index, create=False)
    mism: List[str] = []
    n = {"BEGIN": 0, "DONE": 0, "ABORT": 0, "RESET": 0, "SETF": 0, "POWERDOWN": 0, "POWERUP": 0, "BAKE": 0}
    reads_with_errors = 0
    bits_flipped = 0
    aborted_kinds: List[str] = []

    def bad(msg):
        if len(mism) < max_mismatch:
            mism.append(msg)

    for rec in parse_trace(trace_path):
        tag = rec[0]
        if tag in n:
            n[tag] += 1
        try:
            if tag == "BEGIN":
                seq, ts, kind = int(rec[1]), float(rec[2]), rec[3]
                lun, blk, pg, rc, dur = int(rec[4]), int(rec[5]), int(rec[6]), int(rec[7]), float(rec[8])
                x1, x2 = int(rec[9]), int(rec[10])
                data = rec[rec.index(":") + 1:]
                t.now_ns = ts
                if kind == "READ":
                    if t.retry_level != x1:
                        bad(f"seq {seq}: retry level py {t.retry_level} sv {x1}")
                    op = t.begin_read(lun, blk, pg, ts)
                    sv = bytes(int(x, 16) for x in data)
                    if op.data != sv:
                        diff = sum(bin(a ^ b).count("1") for a, b in zip(op.data, sv))
                        bad(f"seq {seq}: READ lun{lun} blk{blk} pg{pg} data differs in {diff} bit(s)")
                    if op.rc == RC_OK:
                        stored = t.peek(lun, blk, pg)
                        e = sum(bin(a ^ b).count("1") for a, b in zip(stored, op.data))
                        bits_flipped += e
                        reads_with_errors += 1 if e else 0
                        if op.info.get("reads") != x2:
                            bad(f"seq {seq}: read counter py {op.info.get('reads')} sv {x2}")
                elif kind == "PROG":
                    t.wp_n = bool(x1)
                    reg = bytearray(b"\xff" * t.g.page_bytes)
                    mask = bytearray(t.g.page_bytes)
                    for i, x in enumerate(data):
                        if x != "--":
                            reg[i] = int(x, 16)
                            mask[i] = 1
                    op = t.begin_program(lun, blk, pg, reg, mask, ts)
                    if op.nop != x2:
                        bad(f"seq {seq}: nop py {op.nop} sv {x2}")
                else:
                    t.wp_n = bool(x1)
                    op = t.begin_erase(lun, blk, ts)
                    if op.ec != x2:
                        bad(f"seq {seq}: erase count py {op.ec} sv {x2}")
                if op.rc != rc:
                    bad(f"seq {seq}: {kind} lun{lun} blk{blk} pg{pg} rc py {RC_NAMES[op.rc]} sv {RC_NAMES.get(rc, rc)}")
                if op.dur != dur:
                    bad(f"seq {seq}: {kind} busy py {op.dur!r} sv {dur!r}")
            elif tag == "DONE":
                lun, stv = int(rec[3]), int(rec[4], 16)
                op = t.inflight[lun]
                if op is None:
                    bad(f"DONE seq {rec[1]}: nothing in flight on lun {lun}")
                    continue
                res = t.finish(op)
                if (res.status & 0x7F) != (stv & 0x7F):
                    bad(f"DONE seq {rec[1]}: status py {res.status:02x} sv {stv:02x}")
            elif tag == "ABORT":
                lun, frac, cause = int(rec[3]), float(rec[4]), rec[5]
                op = t.inflight[lun]
                if op is None:
                    bad(f"ABORT seq {rec[1]}: nothing in flight")
                    continue
                aborted_kinds.append(op.kind)
                t.abort(op, frac, cause)
            elif tag == "RESET":
                ts, dur = float(rec[1]), float(rec[2])
                tm = cfg.timing
                exp = tm.t_rst_poweron_ns if t.poweron_reset_pending else tm.t_rst_idle_ns
                for k in aborted_kinds:
                    exp = max(exp, tm.t_rst_prog_ns if k == "PROG" else tm.t_rst_erase_ns if k == "ERASE" else exp)
                if exp != dur:
                    bad(f"RESET busy py {exp} sv {dur}")
                aborted_kinds = []
                t.reset(ts)
            elif tag == "SETF":
                t.set_feature(int(rec[2], 16), [int(x, 16) for x in rec[3:7]], float(rec[1]))
            elif tag == "POWERDOWN":
                aborted_kinds = []
                t.power_off(float(rec[1]))
            elif tag == "POWERUP":
                t.power_on(float(rec[1]))
            elif tag == "BAKE":
                t.now_ns = float(rec[1])
                t.bake(float(rec[2]), float(rec[3]))
        except Exception as e:  # pragma: no cover - reported as mismatch
            bad(f"replay exception at {' '.join(rec[:6])}: {type(e).__name__}: {e}")
    t.close(checkpoint=False)
    # journal equality (M and C records excluded; blank lines ignored)
    sv_store = os.path.join(os.path.dirname(trace_path), f"target{target_index}.nlsf")
    js, jp = journal_records(sv_store), journal_records(work_path)
    journal_equal = js == jp
    if not journal_equal:
        k = next((i for i, (a, b) in enumerate(zip(js, jp)) if a != b), min(len(js), len(jp)))
        bad(f"journal differs at record {k}: sv '{(js[k] if k < len(js) else '<end>')[:70]}' "
            f"py '{(jp[k] if k < len(jp) else '<end>')[:70]}' (sv {len(js)} / py {len(jp)} records)")
    sem_equal = store_semantic_state(sv_store) == store_semantic_state(work_path)
    sem_equal_wo_clock = sem_equal
    if not sem_equal:
        a, b = store_semantic_state(sv_store), store_semantic_state(work_path)
        a.pop("clock"); b.pop("clock")
        sem_equal_wo_clock = a == b
        if not sem_equal_wo_clock:
            bad("semantic store state differs")
    return {"records": n, "mismatches": mism, "journal_records": len(js), "journal_equal": journal_equal,
            "semantic_equal": sem_equal_wo_clock, "reads_with_bit_errors": reads_with_errors,
            "bit_errors_replayed": bits_flipped, "ok": not mism and journal_equal and sem_equal_wo_clock}


def _parse_tb_result(path: str) -> Dict[str, Any]:
    out = {"checks": [], "info": [], "summary": None}
    if not os.path.exists(path):
        return out
    with open(path) as f:
        for line in f:
            line = line.rstrip("\n")
            if line.startswith("CHECK "):
                parts = line.split(" ", 2)
                out["checks"].append({"pass": parts[1] == "PASS", "name": parts[2] if len(parts) > 2 else ""})
            elif line.startswith("INFO "):
                out["info"].append(line[5:])
            elif line.startswith("SUMMARY "):
                toks = line.split()
                out["summary"] = {toks[i]: toks[i + 1] for i in range(1, len(toks) - 1, 2)}
    return out


SV_PHASES_FUNCTIONAL = ["fresh", "restart", "powercut"]
SV_PHASES_FAULTS = ["faults", "faults_bake"]


def sv_functional_config(base: Optional[str] = None) -> Config:
    return load_config(base, profile="ideal", overrides={"faults": {"factory_bad_blocks": [[0, 0, 5], [0, 1, 9]]}})


def sv_faults_config(base: Optional[str] = None) -> Config:
    return load_config(base, profile="stress", overrides={"directed": {
        "force_prog_fail": [[0, 0, 24, 0]], "force_erase_fail": [[0, 0, 25]],
        "stuck_bits": [[0, 0, 26, 0, 3, 0]]}})


def _sv_channel_phase(sim: str, build: str, outdir: str, cfg: Config, log) -> Dict[str, Any]:
    sdir = os.path.join(outdir, "store_channel")
    os.makedirs(sdir)
    export_svcfg(cfg, os.path.join(sdir, "nandlab.svcfg"))
    srcs = [os.path.join(HERE, "nand_flash_model.sv"), os.path.join(HERE, "tb", "nand_ctrl_bfm.sv"),
            os.path.join(HERE, "tb", "tb_nand_channel.sv")]
    if sim == "verilator":
        cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN",
               "-DNANDLAB_GEOM_FILE", f"-I{build}", "--top-module", "tb_nand_channel",
               "-Mdir", os.path.join(build, "obj_dir_channel"), "-o", "tb_channel", *srcs]
        run_cmd = [os.path.join(build, "obj_dir_channel", "tb_channel")]
    else:
        vvp = os.path.join(build, "tb_channel.vvp")
        cmd = ["iverilog", "-g2012", "-DNANDLAB_GEOM_FILE", f"-I{build}", "-s", "tb_nand_channel", "-o", vvp, *srcs]
        run_cmd = ["vvp", "-n", vvp]
    cp = subprocess.run(cmd, capture_output=True, text=True)
    with open(os.path.join(build, "compile_channel.log"), "w") as f:
        f.write(cp.stdout + cp.stderr)
    if cp.returncode != 0:
        raise RuntimeError(f"{sim} compile of tb_nand_channel failed; see {build}/compile_channel.log")
    befores = []
    for tid in (0, 1):
        b = os.path.join(sdir, f"before_channel_t{tid}.nlsf")
        BackingStore(b).create(manufacture_records(cfg, tid, "python"))
        befores.append(b)
    t1 = time.time()
    rp = subprocess.run(run_cmd + [f"+NANDLAB_DIR={sdir}", "+NANDLAB_QUIET"], capture_output=True, text=True, cwd=sdir)
    wall = time.time() - t1
    with open(os.path.join(sdir, "sim_channel.log"), "w") as f:
        f.write(rp.stdout + rp.stderr)
    tb = _parse_tb_result(os.path.join(sdir, "tb_channel.result"))
    cos = [replay_trace(cfg, befores[tid], os.path.join(sdir, f"target{tid}.trace"),
                        os.path.join(sdir, f"py_replay_channel_t{tid}.nlsf"), tid) for tid in (0, 1)]
    merged = {"records": {k: cos[0]["records"][k] + cos[1]["records"][k] for k in cos[0]["records"]},
              "mismatches": cos[0]["mismatches"] + cos[1]["mismatches"],
              "journal_records": cos[0]["journal_records"] + cos[1]["journal_records"],
              "journal_equal": cos[0]["journal_equal"] and cos[1]["journal_equal"],
              "semantic_equal": cos[0]["semantic_equal"] and cos[1]["semantic_equal"],
              "reads_with_bit_errors": 0, "bit_errors_replayed": 0, "ok": cos[0]["ok"] and cos[1]["ok"]}
    npass = sum(c["pass"] for c in tb["checks"])
    nfail = sum(not c["pass"] for c in tb["checks"])
    entry = {"store": "store_channel", "phase": "channel (2 targets, shared bus)", "sim_wall_s": round(wall, 2),
             "exit_code": rp.returncode, "tb": tb, "cosim": merged,
             "ok": rp.returncode == 0 and nfail == 0 and npass > 0 and merged["ok"]}
    log(f"store_channel/channel: TB {npass} pass / {nfail} fail; co-sim "
        f"{'EXACT' if merged['ok'] else 'MISMATCH'} ({merged['records']['BEGIN']} ops on 2 targets); {wall:.1f}s")
    for c in tb["checks"]:
        if not c["pass"]:
            log("   TB FAIL:", c["name"])
    for m in merged["mismatches"][:5]:
        log("   mismatch:", m)
    return entry


def sv_regress(sim: str = "verilator", outdir: str = "outputs/sv_regression", base_cfg: Optional[str] = None,
               verbose: bool = True) -> Dict[str, Any]:
    """Compile the SV model + testbench, run all phases as separate simulator
    processes against persistent stores, then replay every trace in Python."""
    def log(*a):
        if verbose:
            print("[sv-regress]", *a, flush=True)
    outdir = os.path.abspath(outdir)
    if os.path.exists(outdir):
        shutil.rmtree(outdir)
    build = os.path.join(outdir, "build")
    os.makedirs(build)
    cfg_f = sv_functional_config(base_cfg)
    cfg_x = sv_faults_config(base_cfg)
    for c in (cfg_x,):
        bad = set(FaultModel(c, 0).factory_bad(0))
        assert not bad & {24, 25, 26}, f"directed-fault blocks collide with factory-bad blocks {bad}"
    export_sv_geometry(cfg_f, os.path.join(build, "nandlab_geom.svh"))
    srcs = [os.path.join(HERE, "nand_flash_model.sv"), os.path.join(HERE, "tb", "nand_ctrl_bfm.sv"),
            os.path.join(HERE, "tb", "tb_nand_flash_model.sv")]
    t0 = time.time()
    if sim == "verilator":
        cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN",
               "-DNANDLAB_GEOM_FILE", f"-I{build}", "--top-module", "tb_nand_flash_model",
               "-Mdir", os.path.join(build, "obj_dir"), "-o", "tb_nand", *srcs]
        run_cmd = [os.path.join(build, "obj_dir", "tb_nand")]
    elif sim == "iverilog":
        vvp = os.path.join(build, "tb_nand.vvp")
        cmd = ["iverilog", "-g2012", "-DNANDLAB_GEOM_FILE", f"-I{build}", "-s", "tb_nand_flash_model",
               "-o", vvp, *srcs]
        run_cmd = ["vvp", "-n", vvp]
    else:
        raise ValueError("sim must be verilator or iverilog")
    log("compile:", " ".join(os.path.basename(c) for c in cmd[:1]), "...")
    cp = subprocess.run(cmd, capture_output=True, text=True)
    with open(os.path.join(build, "compile.log"), "w") as f:
        f.write(cp.stdout + cp.stderr)
    if cp.returncode != 0:
        raise RuntimeError(f"{sim} compile failed; see {build}/compile.log\n{cp.stderr[-2000:]}")
    t_compile = time.time() - t0
    report: Dict[str, Any] = {"simulator": sim, "compile_s": round(t_compile, 1), "phases": [],
                              "model": MODEL_NAME, "version": MODEL_VERSION}
    for store_name, cfg, phases in (("store_functional", cfg_f, SV_PHASES_FUNCTIONAL),
                                    ("store_faults", cfg_x, SV_PHASES_FAULTS)):
        sdir = os.path.join(outdir, store_name)
        os.makedirs(sdir)
        export_svcfg(cfg, os.path.join(sdir, "nandlab.svcfg"))
        with open(os.path.join(sdir, "config.json"), "w") as f:
            json.dump(cfg.to_dict(), f, indent=2)
        store = os.path.join(sdir, "target0.nlsf")
        for ph in phases:
            before = os.path.join(sdir, f"before_{ph}.nlsf")
            manufactured_by_sv = not os.path.exists(store)
            if manufactured_by_sv:
                BackingStore(before).create(manufacture_records(cfg, 0, "python"))
            else:
                shutil.copyfile(store, before)
            args = [f"+PHASE={ph}", f"+NANDLAB_DIR={sdir}", "+NANDLAB_QUIET"]
            if ph == "faults_bake":
                args += ["+NANDLAB_BAKE_HOURS=1000", "+NANDLAB_BAKE_TEMP_C=85"]
            t1 = time.time()
            rp = subprocess.run(run_cmd + args, capture_output=True, text=True, cwd=sdir)
            wall = time.time() - t1
            with open(os.path.join(sdir, f"sim_{ph}.log"), "w") as f:
                f.write(rp.stdout + rp.stderr)
            shutil.copyfile(os.path.join(sdir, "target0.trace"), os.path.join(sdir, f"trace_{ph}.trace"))
            tb = _parse_tb_result(os.path.join(sdir, f"tb_{ph}.result"))
            entry: Dict[str, Any] = {"store": store_name, "phase": ph, "sim_wall_s": round(wall, 2),
                                     "exit_code": rp.returncode, "tb": tb}
            if manufactured_by_sv:
                sv_lines = [l for l in journal_records(store, skip=("C",)) if not l.startswith("M ")]
                py_lines = [l for l in journal_records(before, skip=("C",)) if not l.startswith("M ")]
                entry["manufacture_equal"] = sv_lines[:len(py_lines)] == py_lines
                with open(store) as f:
                    entry["header_equal"] = f.readline().strip() == open(before).readline().strip()
            entry["cosim"] = replay_trace(cfg, before, os.path.join(sdir, f"trace_{ph}.trace"),
                                          os.path.join(sdir, f"py_replay_{ph}.nlsf"))
            if ph == "fresh":
                pp = build_parameter_page(cfg)
                hexf = os.path.join(sdir, "param_page.hex")
                if os.path.exists(hexf):
                    with open(hexf) as f:
                        sv_pp = bytes(int(x, 16) for x in f.read().split())
                    entry["param_page_equal"] = sv_pp == pp
            npass = sum(c["pass"] for c in tb["checks"])
            nfail = sum(not c["pass"] for c in tb["checks"])
            entry["ok"] = (rp.returncode == 0 and nfail == 0 and npass > 0 and entry["cosim"]["ok"]
                           and entry.get("manufacture_equal", True) and entry.get("param_page_equal", True))
            log(f"{store_name}/{ph}: TB {npass} pass / {nfail} fail; co-sim "
                f"{'EXACT' if entry['cosim']['ok'] else 'MISMATCH'} "
                f"({entry['cosim']['records']['BEGIN']} ops, {entry['cosim']['bit_errors_replayed']} bit errors "
                f"replayed); {wall:.1f}s")
            for m in entry["cosim"]["mismatches"][:5]:
                log("   mismatch:", m)
            for c in tb["checks"]:
                if not c["pass"]:
                    log("   TB FAIL:", c["name"])
            report["phases"].append(entry)
    # ---- shared-channel test: two targets on one DQ bus via nand_flash_device ----
    report["phases"].append(_sv_channel_phase(sim, build, outdir, cfg_f, log))
    report["ok"] = all(p["ok"] for p in report["phases"])
    report["total_checks"] = sum(len(p["tb"]["checks"]) for p in report["phases"])
    report["total_failed"] = sum(sum(not c["pass"] for c in p["tb"]["checks"]) for p in report["phases"])
    with open(os.path.join(outdir, f"sv_regression_{sim}.json"), "w") as f:
        json.dump(report, f, indent=2)
    log("RESULT:", "PASS" if report["ok"] else "FAIL", f"({report['total_checks']} TB checks)")
    return report


# =============================================================================
# 11. Latency / contention engine (channel bus, LUN array, multi-plane, retry)
# =============================================================================
import bisect


class IntervalBook:
    """Booked busy intervals of a shared resource; earliest-fit gap search."""

    def __init__(self):
        self.starts: List[float] = []
        self.ends: List[float] = []
        self.busy = 0.0

    def earliest(self, t: float, dur: float) -> float:
        i = bisect.bisect_right(self.ends, t)
        s = t
        while i < len(self.starts):
            if s + dur <= self.starts[i]:
                return s
            s = max(s, self.ends[i])
            i += 1
        return s

    def book(self, s: float, dur: float) -> None:
        if dur <= 0:
            return
        i = bisect.bisect_left(self.starts, s)
        self.starts.insert(i, s)
        self.ends.insert(i, s + dur)
        self.busy += dur


@dataclass
class WorkloadOp:
    t_arrival: float
    kind: str           # READ | PROG | ERASE
    target: int
    lun: int
    blk: int
    pg: int = 0
    planes: int = 1     # multi-plane: blocks blk, blk+1, ... (one per plane), same page
    seed: int = 0


class ArraySimulator:
    """Discrete-event timing of operations on a NandFlashTwin.

    Resources: one shared DQ bus per channel (command/address/data cycles at the
    target's current ONFI timing mode), one array per LUN (busy for tR/tPROG/
    tBERS returned by the device model). A LUN stays occupied until its page
    register has been transferred. Read retry is driven by a controller ECC
    model (t correctable bits per codeword): an uncorrectable read triggers
    SET FEATURES(read-retry level) + re-read, following latency.retry_sequence.
    Array operations really execute on the twin, so data, faults and wear are
    those of the device model."""

    def __init__(self, twin: NandFlashTwin, scheduler: Optional[str] = None):
        self.tw = twin
        self.cfg = twin.cfg
        self.g = twin.cfg.geometry
        self.lat = twin.cfg.latency
        self.scheduler = scheduler or self.lat.scheduler
        self.chan = [IntervalBook() for _ in range(self.g.channels)]
        self.lun_free: Dict[Tuple[int, int], float] = {}
        self.lun_busy: Dict[Tuple[int, int], float] = {}
        self.chan_cursor = [0.0] * self.g.channels
        self.records: List[Dict[str, Any]] = []
        self.gantt: List[Dict[str, Any]] = []
        self.gantt_limit = 400

    def _g(self, res: str, s: float, d: float, kind: str) -> None:
        if len(self.gantt) < self.gantt_limit and d > 0:
            self.gantt.append({"res": res, "s": s, "d": d, "op": kind})

    def _bus(self, ch: int, t: float, dur: float, kind: str) -> float:
        s = self.chan[ch].earliest(t, dur)
        self.chan[ch].book(s, dur)
        self._g(f"CH{ch}", s, dur, kind)
        return s

    def _uncorrectable(self, tgt: NandTarget, lun: int, blk: int, pg: int, data: bytes) -> Tuple[bool, int]:
        stored = tgt.peek(lun, blk, pg)
        cw = self.lat.ecc_codeword_bytes
        worst = 0
        total = 0
        for o in range(0, len(data), cw):
            e = sum(bin(a ^ b).count("1") for a, b in zip(data[o:o + cw], stored[o:o + cw]))
            worst = max(worst, e)
            total += e
        return worst > self.lat.ecc_bits_per_codeword, total

    def run(self, ops: Sequence[WorkloadOp]) -> List[Dict[str, Any]]:
        for op in sorted(ops, key=lambda o: o.t_arrival):
            self.records.append(self._one(op))
        return self.records

    def _one(self, op: WorkloadOp) -> Dict[str, Any]:
        g, tm = self.g, self.cfg.timing
        tgt = self.tw.targets[op.target]
        ch = g.target_coords(op.target)[0]
        io = ONFI_ASYNC_MODES[tgt.timing_mode]
        tWC, tRC, tWB, tADL, tRR = io["tWC"], io["tRC"], io["tWB"], io["tADL"], io["tRR"]
        key = (op.target, op.lun)
        lun_free = self.lun_free.get(key, 0.0)
        ready = max(op.t_arrival + self.lat.controller_overhead_ns, lun_free)
        if self.scheduler == "fifo":
            ready = max(ready, self.chan_cursor[ch])
        res_name = f"T{op.target}L{op.lun}"
        nbytes = g.page_bytes
        rec: Dict[str, Any] = {"kind": op.kind, "target": op.target, "lun": op.lun, "blk": op.blk, "pg": op.pg,
                               "planes": op.planes, "t_arrival": op.t_arrival, "retries": 0, "bit_errors": 0,
                               "uncorrectable": False, "rc": "OK"}
        blocks = [op.blk + k for k in range(op.planes)]
        if op.kind == "READ":
            t_setup = 7 * tWC * op.planes
            s = self._bus(ch, ready, t_setup, "cmd")
            a0 = s + t_setup + tWB
            res = tgt.read_page(op.lun, blocks[0], op.pg, t_ns=a0)
            arr = tm.t_r_ns
            datas = [res.data]
            for b in blocks[1:]:
                datas.append(tgt.read_page(op.lun, b, op.pg, t_ns=a0).data)
            unc, errs = False, 0
            for b, d in zip(blocks, datas):
                u, e = self._uncorrectable(tgt, op.lun, b, op.pg, d)
                unc |= u
                errs += e
            rec["bit_errors_first"] = errs
            t = a0 + arr
            retries = 0
            seqn = list(self.lat.retry_sequence)[: self.lat.max_read_retries]
            while unc and retries < len(seqn):
                lvl = seqn[retries]
                sf = self._bus(ch, t, 6 * tWC + tADL, "setf")
                t = sf + 6 * tWC + tADL + tWB + tm.t_feat_ns
                tgt.retry_level = tgt._clamp_retry(lvl)
                s2 = self._bus(ch, t, t_setup, "cmd")
                a2 = s2 + t_setup + tWB
                unc, errs = False, 0
                for b in blocks:
                    d = tgt.read_page(op.lun, b, op.pg, t_ns=a2, retry=tgt.retry_level).data
                    u, e = self._uncorrectable(tgt, op.lun, b, op.pg, d)
                    unc |= u
                    errs += e
                t = a2 + arr
                retries += 1
            rec["bit_errors"] = errs
            dstart = t + tRR
            for k in range(op.planes):
                xfer = nbytes * tRC + (0 if k == 0 else (7 * tWC + tm.t_ccs_ns))
                dstart = self._bus(ch, dstart, xfer, "data-out") + xfer
            end = dstart
            if retries:
                sf = self._bus(ch, end, 6 * tWC + tADL, "setf")
                end = sf + 6 * tWC + tADL + tWB + tm.t_feat_ns
                tgt.retry_level = 0
            rec.update(retries=retries, uncorrectable=unc, t_bus_start=s, t_array_start=a0, t_end=end)
            self._g(res_name, a0, end - a0, "READ")
        elif op.kind == "PROG":
            per_plane = 6 * tWC + tADL + nbytes * tWC
            t_bus = per_plane * op.planes + tWC + (op.planes - 1) * (tWC + self.lat.t_dbsy_ns)
            s = self._bus(ch, ready, t_bus, "data-in")
            a0 = s + t_bus + tWB
            dur = 0.0
            for b in blocks:
                data = bytearray(random.Random(op.seed * 1000003 + b).getrandbits(8) for _ in range(nbytes))
                data[g.page_data_bytes + self.cfg.policy.bad_block_marker_byte] = 0xFF  # keep BBM byte erased
                r = tgt.program_page(op.lun, b, op.pg, data, t_ns=a0)
                dur = max(dur, r.busy_ns)
                if not r.ok:
                    rec["rc"] = r.code
            end = a0 + dur
            rec.update(t_bus_start=s, t_array_start=a0, t_end=end)
            self._g(res_name, a0, dur, "PROG")
        else:  # ERASE
            t_bus = (5 * tWC) * op.planes
            s = self._bus(ch, ready, t_bus, "cmd")
            a0 = s + t_bus + tWB
            dur = 0.0
            for b in blocks:
                r = tgt.erase_block(op.lun, b, t_ns=a0)
                dur = max(dur, r.busy_ns)
                if not r.ok:
                    rec["rc"] = r.code
            end = a0 + dur
            rec.update(t_bus_start=s, t_array_start=a0, t_end=end)
            self._g(res_name, a0, dur, "ERASE")
        self.lun_free[key] = rec["t_end"]
        self.lun_busy[key] = self.lun_busy.get(key, 0.0) + (rec["t_end"] - rec["t_array_start"])
        if self.scheduler == "fifo":
            self.chan_cursor[ch] = rec["t_bus_start"]
        rec["latency_ns"] = rec["t_end"] - op.t_arrival
        rec["wait_ns"] = rec["t_bus_start"] - op.t_arrival
        return rec

    def summary(self) -> Dict[str, Any]:
        recs = self.records
        if not recs:
            return {}
        t_end = max(r["t_end"] for r in recs)
        t0 = min(r["t_arrival"] for r in recs)
        span = max(1.0, t_end - t0)
        out: Dict[str, Any] = {"ops": len(recs), "span_us": span / 1000.0, "scheduler": self.scheduler}
        for kind in ("READ", "PROG", "ERASE"):
            lat = sorted(r["latency_ns"] for r in recs if r["kind"] == kind)
            if not lat:
                continue

            def pct(p):
                return lat[min(len(lat) - 1, int(math.ceil(p * len(lat))) - 1)] / 1000.0
            out[kind] = {"count": len(lat), "mean_us": sum(lat) / len(lat) / 1000.0, "p50_us": pct(0.50),
                         "p99_us": pct(0.99), "p999_us": pct(0.999), "max_us": lat[-1] / 1000.0}
        pb = self.g.page_data_bytes
        out["read_MBps"] = sum(r["planes"] for r in recs if r["kind"] == "READ") * pb / (span * 1e-9) / 1e6
        out["write_MBps"] = sum(r["planes"] for r in recs if r["kind"] == "PROG") * pb / (span * 1e-9) / 1e6
        out["channel_utilisation"] = [c.busy / span for c in self.chan]
        out["lun_utilisation"] = {f"T{k[0]}L{k[1]}": v / span for k, v in sorted(self.lun_busy.items())}
        out["read_retries"] = sum(r["retries"] for r in recs)
        out["reads_retried"] = sum(1 for r in recs if r["retries"])
        out["uncorrectable_reads"] = sum(1 for r in recs if r["uncorrectable"])
        out["failed_ops"] = sum(1 for r in recs if r["rc"] != "OK")
        return out


def make_workload(twin: NandFlashTwin, n_ops: int = 2000, read_fraction: float = 0.6,
                  rate_kiops: float = 20.0, seed: int = 7, multi_plane: bool = False,
                  targets: Optional[Sequence[int]] = None) -> List[WorkloadOp]:
    """Synthetic host workload with FTL-like block management: pages are
    programmed sequentially into open blocks, full blocks are reused after an
    ERASE when the LUN runs out of free blocks, reads hit programmed pages.
    Arrivals are Poisson at `rate_kiops` thousand ops/s."""
    rnd = random.Random(seed)
    g = twin.cfg.geometry
    targets = list(range(g.targets)) if targets is None else list(targets)
    P = g.planes_per_lun if multi_plane else 1
    state: Dict[Tuple[int, int], Dict[str, Any]] = {}
    for t in targets:
        bad = set(twin.targets[t].scan_bad_block_markers())
        for lun in range(g.luns_per_target):
            groups = []
            for b0 in range(0, g.blocks_per_lun, P):
                grp = list(range(b0, b0 + P))
                if all((lun, b) not in bad for b in grp) and all(
                        twin.targets[t].highest_programmed(lun, b) < 0 for b in grp):
                    groups.append(b0)
            state[(t, lun)] = {"free": groups, "open": None, "wp": 0, "closed": [], "programmed": []}
    ops: List[WorkloadOp] = []
    t = 0.0
    mean_gap = 1e6 / max(1e-9, rate_kiops)  # ns
    for i in range(n_ops):
        t += rnd.expovariate(1.0) * mean_gap
        tg = rnd.choice(targets)
        lun = rnd.randrange(g.luns_per_target)
        st = state[(tg, lun)]
        if st["programmed"] and rnd.random() < read_fraction:
            b0, pg = rnd.choice(st["programmed"])
            ops.append(WorkloadOp(t, "READ", tg, lun, b0, pg, P))
            continue
        if st["open"] is None or st["wp"] >= g.pages_per_block:
            if st["open"] is not None:
                st["closed"].append(st["open"])
            if not st["free"]:
                victim = st["closed"].pop(0)
                st["programmed"] = [x for x in st["programmed"] if x[0] != victim]
                ops.append(WorkloadOp(t, "ERASE", tg, lun, victim, 0, P))
                st["free"].append(victim)
                t += 1.0
            st["open"] = st["free"].pop(0)
            st["wp"] = 0
        ops.append(WorkloadOp(t, "PROG", tg, lun, st["open"], st["wp"], P, seed=i))
        st["programmed"].append((st["open"], st["wp"]))
        st["wp"] += 1
    return ops


def latency_histogram(records: List[Dict[str, Any]], kind: str, bins: int = 40) -> Dict[str, Any]:
    lat = [r["latency_ns"] / 1000.0 for r in records if r["kind"] == kind]
    if not lat:
        return {"edges": [], "counts": []}
    lo, hi = 0.0, max(lat) * 1.0001
    w = (hi - lo) / bins if hi > lo else 1.0
    counts = [0] * bins
    for x in lat:
        counts[min(bins - 1, int((x - lo) / w))] += 1
    return {"edges": [lo + i * w for i in range(bins + 1)], "counts": counts}


# =============================================================================
# 12. Threshold-voltage research model (SLC / MLC / TLC / QLC) -- UNVALIDATED
# =============================================================================
# This is NOT the device model. The device model (sections 6/9) is SLC with
# bit-level errors. Here each programmed state is a Gaussian V_t distribution
# (first-order textbook abstraction, cf. Cai et al., Proc. IEEE 105(9), 2017;
# Parnell et al., GLOBECOM 2014, who also discuss non-Gaussian tails). States
# are Gray-coded; reads compare V_t against references. Wear widens the states
# and lifts the erased state, retention moves programmed states toward a
# neutral V_t (log-time charge loss), read disturb lifts the erased state.
# Every coefficient is illustrative; no silicon data was used.

@dataclass
class VtParams:
    bits_per_cell: int = 1
    erase_mean: float = -2.0
    erase_sigma: float = 0.40
    prog_first: float = 2.0
    prog_last: float = 2.0
    prog_sigma: float = 0.25
    rated_cycles: float = 100000.0
    pe_sigma_gain: float = 0.6       # sigma *= 1 + gain * cn
    pe_erase_shift: float = 0.35     # erased mean += shift * cn  [V]
    ret_shift: float = 0.035         # top state shift per ln(1 + t/t0)  [V]
    ret_t0_h: float = 1.0
    ret_pe_gain: float = 2.0
    ret_sigma_gain: float = 0.012    # sigma += gain * ln(1 + t/t0)
    rd_shift: float = 0.05           # erased mean += rd_shift * ln(1 + reads/r0)  [V]
    rd_r0: float = 1000.0
    v_neutral: float = 0.0


VT_DEFAULTS = {   # illustrative; tuned only so RBERs land in commonly reported orders of magnitude
    1: VtParams(1, -2.2, 0.35, 2.4, 2.4, 0.28, 100000.0, pe_sigma_gain=0.45, pe_erase_shift=0.30,
                ret_shift=0.012, ret_pe_gain=2.0, ret_sigma_gain=0.004, rd_shift=0.03),
    2: VtParams(2, -2.5, 0.38, 0.7, 3.5, 0.15, 3000.0, pe_sigma_gain=0.45, pe_erase_shift=0.30,
                ret_shift=0.010, ret_pe_gain=2.0, ret_sigma_gain=0.003, rd_shift=0.03),
    3: VtParams(3, -2.5, 0.38, 0.2, 4.4, 0.11, 1000.0, pe_sigma_gain=0.35, pe_erase_shift=0.25,
                ret_shift=0.008, ret_pe_gain=2.0, ret_sigma_gain=0.002, rd_shift=0.03),
    4: VtParams(4, -2.5, 0.38, -0.3, 4.9, 0.064, 300.0, pe_sigma_gain=0.25, pe_erase_shift=0.20,
                ret_shift=0.006, ret_pe_gain=2.0, ret_sigma_gain=0.0015, rd_shift=0.03),
}
VT_NAMES = {1: "SLC", 2: "MLC", 3: "TLC", 4: "QLC"}


def _phi(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def gray_value(i: int, b: int) -> int:
    """State i -> stored bits (erased state = all ones; adjacent states differ in 1 bit)."""
    return (~(i ^ (i >> 1))) & ((1 << b) - 1)


class VtModel:
    def __init__(self, p: VtParams):
        self.p = p
        self.b = p.bits_per_cell
        self.S = 1 << self.b
        self.vals = [gray_value(i, self.b) for i in range(self.S)]
        if self.S == 2:
            self.base_means = [p.erase_mean, p.prog_first]
        else:
            step = (p.prog_last - p.prog_first) / (self.S - 2)
            self.base_means = [p.erase_mean] + [p.prog_first + k * step for k in range(self.S - 1)]
        self.base_sigmas = [p.erase_sigma] + [p.prog_sigma] * (self.S - 1)
        m = self.base_means
        self.default_refs = [(m[i] + m[i + 1]) / 2.0 for i in range(self.S - 1)]

    def states(self, cycles: float = 0.0, ret_h: float = 0.0, reads: float = 0.0) -> Tuple[List[float], List[float]]:
        p = self.p
        cn = cycles / p.rated_cycles
        lt = math.log1p(ret_h / p.ret_t0_h) if ret_h > 0 else 0.0
        top = self.base_means[-1] - p.v_neutral
        mu, sg = [], []
        for i, (m, s) in enumerate(zip(self.base_means, self.base_sigmas)):
            s2 = s * (1.0 + p.pe_sigma_gain * cn)
            if i == 0:
                m2 = m + p.pe_erase_shift * cn + p.rd_shift * math.log1p(reads / p.rd_r0)
            else:
                rel = (m - p.v_neutral) / top if top > 0 else 0.0
                m2 = m - p.ret_shift * rel * lt * (1.0 + p.ret_pe_gain * cn)
                s2 = s2 + p.ret_sigma_gain * lt
            mu.append(m2)
            sg.append(s2)
        return mu, sg

    def transition(self, mu: List[float], sg: List[float], refs: Sequence[float]) -> List[List[float]]:
        edges = [-math.inf] + list(refs) + [math.inf]
        T = []
        for i in range(self.S):
            row = []
            for j in range(self.S):
                lo = 0.0 if edges[j] == -math.inf else _phi((edges[j] - mu[i]) / sg[i])
                hi = 1.0 if edges[j + 1] == math.inf else _phi((edges[j + 1] - mu[i]) / sg[i])
                row.append(max(0.0, hi - lo))
            T.append(row)
        return T

    def rber(self, mu, sg, refs) -> Dict[str, Any]:
        T = self.transition(mu, sg, refs)
        tot = 0.0
        per_page = [0.0] * self.b
        for i in range(self.S):
            for j in range(self.S):
                x = self.vals[i] ^ self.vals[j]
                if x:
                    w = T[i][j] / self.S
                    tot += w * bin(x).count("1")
                    for k in range(self.b):
                        if (x >> k) & 1:
                            per_page[k] += w
        return {"rber": tot / self.b, "per_page": per_page, "row_sums": [sum(r) for r in T]}

    def optimal_refs(self, mu, sg) -> List[float]:
        refs = []
        for i in range(self.S - 1):
            m1, s1, m2, s2 = mu[i], sg[i], mu[i + 1], sg[i + 1]
            # equal-density point of two Gaussians (equal priors): a v^2 + b v + c = 0
            a = 1.0 / (2 * s1 * s1) - 1.0 / (2 * s2 * s2)
            bq = m2 / (s2 * s2) - m1 / (s1 * s1)
            c = (m1 * m1) / (2 * s1 * s1) - (m2 * m2) / (2 * s2 * s2) - math.log(s2 / s1)
            v = (m1 + m2) / 2.0
            if abs(a) < 1e-12:
                if abs(bq) > 1e-12:
                    v = -c / bq
            else:
                disc = bq * bq - 4 * a * c
                if disc >= 0:
                    r = [(-bq + sgn * math.sqrt(disc)) / (2 * a) for sgn in (1, -1)]
                    inside = [x for x in r if min(m1, m2) <= x <= max(m1, m2)]
                    if inside:
                        v = inside[0]
            refs.append(v)
        return refs

    def retry_scan(self, mu, sg, offsets=None) -> Dict[str, Any]:
        """Read retry modelled as a common shift of all references."""
        offsets = offsets if offsets is not None else [x * 0.05 for x in range(-12, 13)]
        best = None
        rows = []
        for d in offsets:
            r = self.rber(mu, sg, [x + d for x in self.default_refs])["rber"]
            rows.append([d, r])
            if best is None or r < best[1]:
                best = (d, r)
        return {"scan": rows, "best_offset_V": best[0], "best_rber": best[1]}

    def monte_carlo(self, mu, sg, cells_per_state: int, seed: int, refs=None,
                    lo: float = -4.5, hi: float = 6.0, bins: int = 140) -> Dict[str, Any]:
        rnd = random.Random(seed)
        refs = refs or self.default_refs
        w = (hi - lo) / bins
        hist = [[0] * bins for _ in range(self.S)]
        bit_err = 0
        for i in range(self.S):
            for _ in range(cells_per_state):
                v = rnd.gauss(mu[i], sg[i])
                k = int((v - lo) / w)
                if 0 <= k < bins:
                    hist[i][k] += 1
                j = bisect.bisect_right(refs, v)
                bit_err += bin(self.vals[i] ^ self.vals[j]).count("1")
        n_bits = cells_per_state * self.S * self.b
        return {"lo": lo, "hi": hi, "bins": bins, "hist": hist, "rber": bit_err / n_bits, "n_bits": n_bits}

    def pdf_curves(self, mu, sg, lo=-4.5, hi=6.0, n=220) -> Dict[str, Any]:
        xs = [lo + (hi - lo) * k / (n - 1) for k in range(n)]
        ys = [[math.exp(-0.5 * ((x - m) / s) ** 2) / (s * math.sqrt(2 * math.pi)) / self.S for x in xs]
              for m, s in zip(mu, sg)]
        return {"x": xs, "pdf": ys}


VT_CONDITIONS = [
    ("fresh", 0.0, 0.0, 0.0),
    ("1 year retention", 0.0, 8760.0, 0.0),
    ("rated P/E", 1.0, 0.0, 0.0),
    ("rated P/E + 1 year", 1.0, 8760.0, 0.0),
    ("100k reads (disturb)", 0.0, 0.0, 100000.0),
]


def vt_research_report(seed: int = 52) -> Dict[str, Any]:
    out: Dict[str, Any] = {"status": "RESEARCH MODEL - UNVALIDATED (no silicon calibration data)",
                           "source": SOURCES["research"], "modes": {}, "checks": []}

    def chk(name, ok, detail=""):
        out["checks"].append({"name": name, "pass": bool(ok), "detail": detail})

    for b in (1, 2, 3, 4):
        p = copy.deepcopy(VT_DEFAULTS[b])
        m = VtModel(p)
        mode: Dict[str, Any] = {"name": VT_NAMES[b], "bits_per_cell": b, "params": asdict(p),
                                "gray_values": m.vals, "default_refs": m.default_refs, "conditions": []}
        chk(f"{VT_NAMES[b]} Gray adjacency (1 bit between neighbouring states)",
            all(bin(m.vals[i] ^ m.vals[i + 1]).count("1") == 1 for i in range(m.S - 1)))
        prev = -1.0
        mono = True
        for name, cyc_frac, ret_h, reads in VT_CONDITIONS:
            mu, sg = m.states(cyc_frac * p.rated_cycles, ret_h, reads)
            d = m.rber(mu, sg, m.default_refs)
            o = m.optimal_refs(mu, sg)
            do = m.rber(mu, sg, o)
            rs = m.retry_scan(mu, sg)
            mode["conditions"].append({
                "name": name, "cycles": cyc_frac * p.rated_cycles, "retention_h": ret_h, "reads": reads,
                "means": mu, "sigmas": sg, "rber_default": d["rber"], "rber_per_page": d["per_page"],
                "optimal_refs": o, "rber_optimal": do["rber"], "retry_best_offset_V": rs["best_offset_V"],
                "rber_retry_best": rs["best_rber"], "pdf": m.pdf_curves(mu, sg)})
            if not all(abs(x - 1.0) < 1e-9 for x in d["row_sums"]):
                chk(f"{VT_NAMES[b]} {name}: transition rows sum to 1", False)
            if do["rber"] > d["rber"] * (1 + 1e-9) + 1e-300:
                chk(f"{VT_NAMES[b]} {name}: optimal refs no worse than defaults", False,
                    f"{do['rber']:.3e} vs {d['rber']:.3e}")
        # monotonic in retention time
        for hrs in (0, 10, 100, 1000, 8760, 87600):
            mu, sg = m.states(0.0, float(hrs), 0.0)
            r = m.rber(mu, sg, m.default_refs)["rber"]
            if r < prev * (1 - 1e-9):
                mono = False
            prev = r
        chk(f"{VT_NAMES[b]} RBER non-decreasing with retention time", mono)
        # Monte Carlo vs analytic at a degraded condition
        mu, sg = m.states(1.0 * p.rated_cycles, 8760.0, 0.0)
        ana = m.rber(mu, sg, m.default_refs)["rber"]
        # SLC RBER at this condition is ~2e-5: 2 x 300k cells gives ~13 expected errors
        mc = m.monte_carlo(mu, sg, 40000 // m.S if b > 1 else 300000, seed + b)
        sd = math.sqrt(max(ana, 1e-12) * (1 - ana) / mc["n_bits"])
        chk(f"{VT_NAMES[b]} Monte-Carlo RBER within 5 sigma of analytic",
            abs(mc["rber"] - ana) <= 5 * sd + 2.0 / mc["n_bits"], f"MC {mc['rber']:.3e} vs {ana:.3e}")
        mode["monte_carlo"] = {"condition": "rated P/E + 1 year", **{k: mc[k] for k in ("lo", "hi", "bins", "hist", "rber", "n_bits")},
                               "analytic_rber": ana}
        out["modes"][VT_NAMES[b]] = mode
    # ordering sanity at a common condition (rated P/E + 1 year)
    r = [out["modes"][VT_NAMES[b]]["conditions"][3]["rber_default"] for b in (1, 2, 3, 4)]
    chk("RBER ordering SLC < MLC < TLC < QLC at rated P/E + 1 year", r[0] < r[1] < r[2] < r[3],
        ", ".join(f"{x:.2e}" for x in r))
    out["all_checks_pass"] = all(c["pass"] for c in out["checks"])
    return out


def slc_model_bridge(cfg: Config) -> Dict[str, Any]:
    """Side-by-side SLC RBER from the Vt research model and from the device's
    bit-level model, over P/E cycles and retention. Different abstractions,
    neither calibrated; shown so users can see how far apart they are."""
    vm = VtModel(copy.deepcopy(VT_DEFAULTS[1]))
    fm = FaultModel(cfg, 0)
    rows = []
    for frac in (0.0, 0.1, 0.25, 0.5, 1.0, 1.5):
        cyc = frac * cfg.faults.rated_endurance_cycles
        for hrs in (0.0, 1000.0, 8760.0):
            mu, sg = vm.states(frac * vm.p.rated_cycles, hrs, 0.0)
            vt = vm.rber(mu, sg, vm.default_refs)["rber"]
            c = fm.rber_components(int(cyc), hrs, 0, False, 0)
            bit = c["wear"] + 0.5 * c["retention"]  # retention acts on ~half the cells (programmed 0s)
            rows.append({"pe_fraction": frac, "retention_h": hrs, "vt_rber": vt, "bitlevel_rber": bit})
    return {"note": "Independent abstractions; neither calibrated to silicon.", "rows": rows}


# =============================================================================
# 14. Reference verification suite (also collected by tests/test_nand_flash_twin.py)
# =============================================================================
REFERENCE_TESTS: List[Tuple[str, str, Callable[[str], Optional[dict]]]] = []


def reftest(area: str):
    def deco(fn):
        REFERENCE_TESTS.append((fn.__name__.replace("t_", "", 1), area, fn))
        return fn
    return deco


def _tcfg(profile: str = "ideal", **over) -> Config:
    o = {"faults": {"factory_bad_blocks": [[0, 0, 5], [0, 1, 9]]}}
    _deep_merge(o, over)
    return load_config(None, profile=profile, overrides=o)


def _target(d: str, profile: str = "ideal", **over) -> NandTarget:
    t = NandTarget(_tcfg(profile, **over), os.path.join(d, "target0.nlsf"), 0)
    t.reset()
    return t


def _pat(seed: int, n: int) -> bytes:
    r = random.Random(seed)
    return bytes(r.getrandbits(8) for _ in range(n))


def _bitdiff(a: bytes, b: bytes) -> int:
    return sum(bin(x ^ y).count("1") for x, y in zip(a, b))


@reftest("Fresh device")
def t_fresh_device_reads_erased(d):
    t = _target(d)
    PB = t.g.page_bytes
    for (l, b, p) in [(0, 0, 0), (0, 63, 15), (1, 31, 7)]:
        assert t.read_page(l, b, p).data == b"\xff" * PB
    assert t.read_status() == 0xE0
    assert t.read_id(0x00) == bytes([0x00, 0x5A, 0x00, 0x15, 0x00]) and t.read_id(0x20)[:4] == b"ONFI"
    return {"pages_checked": 3}


@reftest("Fresh device")
def t_reset_required_after_power_on(d):
    t = NandTarget(_tcfg(), os.path.join(d, "target0.nlsf"), 0)
    try:
        t.read_page(0, 1, 0)
        raise AssertionError("read before RESET accepted")
    except ProtocolError:
        pass
    r = t.reset()
    assert r.busy_ns == t.cfg.timing.t_rst_poweron_ns
    assert t.reset().busy_ns == t.cfg.timing.t_rst_idle_ns


@reftest("Fresh device")
def t_parameter_page(d):
    t = _target(d)
    pp = t.read_parameter_page()
    assert len(pp) == 768 and pp[:256] == pp[256:512] == pp[512:]
    info = parse_parameter_page(pp)
    g = t.g
    assert info["crc_ok"] and info["page_data_bytes"] == g.page_data_bytes
    assert info["page_spare_bytes"] == g.page_spare_bytes and info["pages_per_block"] == g.pages_per_block
    assert info["blocks_per_lun"] == g.blocks_per_lun and info["luns"] == g.luns_per_target
    assert info["nop"] == t.cfg.policy.max_programs_per_page and info["bits_per_cell"] == 1
    bad = bytearray(pp)
    bad[100] ^= 1
    assert parse_parameter_page(bytes(bad))["copy"] == 1, "corrupt copy 0 must fall back to copy 1"
    return {"crc": f"{struct.unpack_from('<H', pp, 254)[0]:04x}"}


@reftest("Read after program")
def t_program_read_roundtrip(d):
    t = _target(d)
    PB = t.g.page_bytes
    data = _pat(1, PB)
    r = t.program_page(0, 2, 0, data)
    assert r.ok and r.status == 0xE0 and r.busy_ns == 200000.0
    rr = t.read_page(0, 2, 0)
    assert rr.data == data and rr.busy_ns == 25000.0
    assert t.read_page(0, 2, 0, col=t.g.page_data_bytes).data == data[t.g.page_data_bytes:]


@reftest("Read after program")
def t_partial_page_programming_nop(d):
    t = _target(d)
    PD, PS = t.g.page_data_bytes, t.g.page_spare_bytes
    a, s = _pat(2, PD), _pat(3, PS)
    assert t.program_page(0, 2, 0, a).ok
    assert t.program_page(0, 2, 0, s, col=PD).ok
    assert t.read_page(0, 2, 0).data == a + s
    assert t.program_page(0, 2, 0, a).ok and t.program_page(0, 2, 0, a).ok   # NOP 3 and 4
    r = t.program_page(0, 2, 0, a)
    assert r.code == "REJECT_NOP" and r.status & ST_FAIL
    assert t.page(0, 2, 0).nop == 4


@reftest("Invalid bit transitions")
def t_invalid_transition_policies(d):
    PB = 528
    data = _pat(4, PB)
    flip = bytearray(data)
    i = next(k for k in range(PB) if data[k] != 0xFF)
    flip[i] |= (~data[i]) & 0xFF                                   # request 0->1 in byte i
    t = _target(os.path.join(d, "reject"))
    t.program_page(0, 2, 0, data)
    r = t.program_page(0, 2, 0, bytes(flip))
    assert r.code == "REJECT_TRANSITION" and t.peek(0, 2, 0) == data and r.busy_ns == t.cfg.timing.t_reject_ns
    t2 = _target(os.path.join(d, "and"), policy={"invalid_transition_policy": "and"})
    t2.program_page(0, 2, 0, data)
    r2 = t2.program_page(0, 2, 0, bytes(flip))
    assert r2.ok and t2.peek(0, 2, 0) == data and t2.violations, "AND semantics: 1s inhibit, cells keep 0"
    t3 = _target(os.path.join(d, "nonff"), policy={"invalid_transition_policy": "reject_non_ff"})
    t3.program_page(0, 2, 0, data[:100], col=0)
    pad = bytearray(b"\xff" * PB)
    pad[200:210] = data[200:210]
    assert t3.program_page(0, 2, 0, bytes(pad)).ok, "FFh padding accepted under reject_non_ff"
    assert t3.peek(0, 2, 0)[:100] == data[:100]


@reftest("Invalid bit transitions")
def t_sequential_program_rule(d):
    t = _target(d)
    PB = t.g.page_bytes
    assert t.program_page(0, 2, 0, _pat(5, PB)).ok
    r = t.program_page(0, 2, 3, _pat(6, PB))
    assert r.code == "REJECT_SEQUENCE" and r.info["expected_page"] == 1
    assert t.program_page(0, 2, 1, _pat(6, PB)).ok
    t2 = _target(os.path.join(d, "noseq"), policy={"sequential_page_program": False})
    assert t2.program_page(0, 2, 7, _pat(6, PB)).ok


@reftest("Block erase")
def t_block_erase(d):
    t = _target(d)
    PB = t.g.page_bytes
    for p in range(t.g.pages_per_block):
        t.program_page(0, 2, p, _pat(10 + p, PB))
    t.program_page(0, 3, 0, _pat(30, PB))      # other plane
    t.program_page(1, 2, 0, _pat(31, PB))      # other LUN
    r = t.erase_block(0, 2)
    assert r.ok and r.busy_ns == 2000000.0
    assert all(t.read_page(0, 2, p).data == b"\xff" * PB for p in range(t.g.pages_per_block))
    assert t.block(0, 2).ec == 1 and t.block(0, 2).reads == t.g.pages_per_block
    assert t.read_page(0, 3, 0).data == _pat(30, PB) and t.read_page(1, 2, 0).data == _pat(31, PB)
    assert t.program_page(0, 2, 0, _pat(32, PB)).busy_ns == t.t_prog(1)
    return {"erase_busy_ns": r.busy_ns}


@reftest("Page boundaries")
def t_page_boundaries(d):
    t = _target(d)
    g = t.g
    PB = g.page_bytes
    last = (g.luns_per_target - 1, g.blocks_per_lun - 1, g.pages_per_block - 1)
    for p in range(g.pages_per_block):
        assert t.program_page(last[0], last[1], p, _pat(40 + p, PB)).ok
    assert t.read_page(*last, col=PB - 1, length=1).data == _pat(40 + last[2], PB)[-1:]
    assert t.read_page(*last, col=PB - 1, length=3).data[1:] == b"\xff\xff", "beyond page returns FFh"
    r = t.program_page(1, 4, 0, _pat(50, PB + 5))
    assert r.ok and t.peek(1, 4, 0) == _pat(50, PB + 5)[:PB] and t.violations[-1]["kind"] == "column_overflow"
    assert t.program_page(0, g.blocks_per_lun, 0, b"\x00").code == "REJECT_ADDRESS"
    assert t.read_page(0, 0, g.pages_per_block).code == "REJECT_ADDRESS"
    assert g.decode_row(g.row_address(*last)) == last


@reftest("Factory bad blocks")
def t_factory_bad_blocks(d):
    t = _target(d)
    assert sorted(t.scan_bad_block_markers()) == [(0, 5), (1, 9)]
    assert sorted(t.scan_bad_block_markers(use_reads=True)) == [(0, 5), (1, 9)]
    PB = t.g.page_bytes
    r = t.program_page(0, 5, 0, _pat(1, PB))
    assert r.code == "FAIL_BAD_BLOCK" and r.busy_ns == t.t_prog(0) * t.cfg.timing.fail_time_factor
    r = t.erase_block(0, 5)
    assert r.code == "FAIL_BAD_BLOCK" and t.peek(0, 5, 0)[t.g.page_data_bytes] == 0x00
    t2 = _target(os.path.join(d, "lost"), policy={"factory_bad_erase": "erase_marker_lost"})
    assert t2.erase_block(0, 5).ok and (0, 5) not in t2.scan_bad_block_markers()
    assert t2.program_page(0, 5, 0, _pat(1, PB)).code == "FAIL_BAD_BLOCK", "block stays defective"
    cfgn = load_config(None, profile="nominal")
    fm = FaultModel(cfgn, 0)
    for lun in range(2):
        fb = fm.factory_bad(lun)
        assert 0 not in fb and len(fb) <= cfgn.max_bad_blocks_per_lun()
        assert fb == FaultModel(cfgn, 0).factory_bad(lun), "deterministic"
    return {"nominal_factory_bad_lun0": fm.factory_bad(0), "nominal_factory_bad_lun1": fm.factory_bad(1)}


@reftest("Persistence")
def t_controller_reset_preserves_array(d):
    t = _target(d)
    PB = t.g.page_bytes
    t.program_page(0, 2, 0, _pat(60, PB))
    t.program_page(0, 3, 0, _pat(61, PB))
    t.erase_block(0, 3)
    t.reset()
    assert t.read_page(0, 2, 0).data == _pat(60, PB)
    assert t.read_page(0, 3, 0).data == b"\xff" * PB, "controller reset must not restore erased data"


@reftest("Persistence")
def t_process_restart(d):
    t = _target(d)
    PB = t.g.page_bytes
    t.program_page(0, 2, 0, _pat(70, PB))
    t.program_page(0, 3, 0, _pat(71, PB))
    t.erase_block(0, 3)
    for _ in range(5):
        t.read_page(0, 2, 0)
    t.precondition_wear(1, 7, 1234)
    t.bake(100.0, 70.0)
    clk = t.clock()
    t.close()
    t2 = NandTarget(_tcfg(), os.path.join(d, "target0.nlsf"), 0, create=False)
    t2.reset()
    assert t2.read_page(0, 2, 0).data == _pat(70, PB)
    assert t2.read_page(0, 3, 0).data == b"\xff" * PB
    assert t2.block(0, 3).ec == 1 and t2.block(0, 2).reads == 6 and t2.block(1, 7).ec == 1234
    assert t2.block(0, 5).flags & BF_FACTORY_BAD
    assert t2.clock_base >= clk, "retention clock never runs backwards"


@reftest("Persistence")
def t_crash_consistency_subprocess(d):
    """A separate Python process programs and erases, then dies via os._exit
    (no close, no checkpoint). Everything committed must survive."""
    store = os.path.join(d, "target0.nlsf")
    code = (f"import sys; sys.path.insert(0, {HERE!r}); import os, nand_flash_twin as N\n"
            f"cfg = N.load_config(None, profile='ideal', overrides={{'faults': {{'factory_bad_blocks': [[0,0,5],[0,1,9]]}}}})\n"
            f"t = N.NandTarget(cfg, {store!r}, 0); t.reset()\n"
            f"import random\n"
            f"for p in range(4): t.program_page(1, 3, p, bytes([p]) * 528)\n"
            f"t.program_page(1, 4, 0, b'\\x00' * 528); t.erase_block(1, 4)\n"
            f"os._exit(0)\n")
    rp = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    assert rp.returncode == 0, rp.stderr
    t = NandTarget(_tcfg(), store, 0, create=False)
    t.reset()
    assert all(t.read_page(1, 3, p).data == bytes([p]) * 528 for p in range(4))
    assert t.read_page(1, 4, 0).data == b"\xff" * 528 and t.block(1, 4).ec == 1


@reftest("Persistence")
def t_torn_journal_tail(d):
    t = _target(d)
    PB = t.g.page_bytes
    t.program_page(0, 2, 0, _pat(80, PB))
    t.program_page(0, 2, 1, _pat(81, PB))
    t.close(checkpoint=False)
    path = os.path.join(d, "target0.nlsf")
    with open(path) as f:
        text = f.read()
    cut = text.rstrip("\n").rfind("\n") + 1 + 200          # tear the last P record mid-line
    with open(path, "w") as f:
        f.write(text[:cut])
    t2 = NandTarget(_tcfg(), path, 0, create=False)
    t2.reset()
    assert t2.load_stats["torn_records"] == 1 and t2.warnings
    assert t2.read_page(0, 2, 0).data == _pat(80, PB)
    assert t2.read_page(0, 2, 1).data == b"\xff" * PB, "torn (uncommitted) program is not applied"
    assert t2.program_page(0, 2, 1, _pat(82, PB)).ok
    t2.close()
    t3 = NandTarget(_tcfg(), path, 0, create=False)
    assert t3.peek(0, 2, 1) == _pat(82, PB), "append after a torn line starts a fresh record"


@reftest("Persistence")
def t_compaction_equivalence(d):
    t = _target(d, "stress")
    PB = t.g.page_bytes
    for p in range(6):
        t.program_page(1, 20, p, _pat(90 + p, PB))
    t.erase_block(1, 20)
    for p in range(3):
        t.program_page(1, 20, p, _pat(95 + p, PB))
    for _ in range(4):
        t.read_page(1, 20, 1)
    path = os.path.join(d, "target0.nlsf")
    before = store_semantic_state(path)
    lines_before = sum(1 for _ in open(path))
    t.compact()
    after = store_semantic_state(path)
    before.pop("clock"); after.pop("clock")
    assert before == after
    return {"journal_lines": lines_before, "compacted_lines": sum(1 for _ in open(path))}


@reftest("Persistence")
def t_manufacture_determinism(d):
    cfg = load_config(None, profile="nominal")
    a = manufacture_records(cfg, 1)
    b = manufacture_records(cfg, 1)
    c = manufacture_records(load_config(None, profile="nominal", overrides={"faults": {"seed": 12345}}), 1)
    assert a == b and a != c


@reftest("Injected bit errors")
def t_bit_error_statistics(d):
    """Measured error count of the persistent component matches its binomial mean."""
    t = _target(d, "ideal", faults={"rber_fresh": 2e-3})
    PB = t.g.page_bytes
    n_pages, errs = 0, 0
    for b in range(10, 14):
        for p in range(t.g.pages_per_block):
            t.program_page(0, b, p, _pat(b * 100 + p, PB))
            errs += _bitdiff(t.read_page(0, b, p).data, t.peek(0, b, p))
            n_pages += 1
    n = n_pages * PB * 8
    mean = n * 2e-3
    assert abs(errs - mean) < 5 * math.sqrt(mean), f"{errs} vs {mean:.0f}"
    return {"bits": n, "errors": errs, "expected": round(mean, 1)}


@reftest("Injected bit errors")
def t_error_physics_direction(d):
    t = _target(d, "ideal", faults={"retention_rber_ref": 1e-2, "retention_ref_hours": 100.0,
                                     "read_disturb_rber_ref": 2e-2, "read_disturb_ref_reads": 100.0})
    PB = t.g.page_bytes
    data = _pat(7, PB)
    t.program_page(0, 2, 0, data)
    t.bake(200.0, 40.0)
    r = t.read_page(0, 2, 0, attribution=True)
    e01 = sum(bin(~s & x & 0xFF).count("1") for s, x in zip(data, r.data))
    e10 = sum(bin(s & ~x & 0xFF).count("1") for s, x in zip(data, r.data))
    assert e01 > 20 and e10 == r.info["errors"]["read_disturb"] and r.info["errors"]["retention"] == e01
    t.program_page(0, 3, 0, b"\xff" * PB)
    for _ in range(300):
        t.read_page(0, 3, 5)
    r2 = t.read_page(0, 3, 0, attribution=True)
    e10b = sum(bin(0xFF & ~x).count("1") for x in r2.data)
    assert e10b > 20 and r2.info["errors"]["retention"] == 0, "read disturb only flips erased (1) cells to 0"
    return {"retention_0to1": e01, "disturb_1to0": e10b}


@reftest("Injected bit errors")
def t_stuck_bits_and_directed_failures(d):
    t = _target(d, "ideal", directed={"stuck_bits": [[0, 0, 2, 0, 11, 0], [0, 0, 2, 0, 12, 1]],
                                      "force_prog_fail": [[0, 0, 3, 0]], "force_erase_fail": [[0, 0, 4]]})
    PB = t.g.page_bytes
    t.program_page(0, 2, 0, bytes([0xFF, 0x00]) + b"\xff" * (PB - 2))
    r = t.read_page(0, 2, 0)
    assert (r.data[1] >> 3) & 1 == 0 and (r.data[1] >> 4) & 1 == 1
    data = _pat(9, PB)
    r = t.program_page(0, 3, 0, data)
    stored = t.peek(0, 3, 0)
    assert r.code == "FAIL_FORCED" and stored != data
    assert all(((~s & 0xFF) & x) == 0 for s, x in zip(stored, data)), "partial program clears only intended bits"
    assert t.page(0, 3, 0).flags & PF_PROG_FAILED and t.block(0, 3).flags & BF_PROG_FAILED
    t.program_page(0, 4, 0, data)
    r = t.erase_block(0, 4)
    assert r.code == "FAIL_FORCED" and t.block(0, 4).flags & BF_ERASE_FAILED and t.block(0, 4).ec == 1
    assert t.erase_block(0, 4).code in ("FAIL_FORCED", "FAIL_WORN")


@reftest("Injected bit errors")
def t_endurance_degradation(d):
    t = _target(d, "nominal")
    PB = t.g.page_bytes
    fm = t.fm
    E = t.cfg.faults.rated_endurance_cycles
    rb = [fm.p_wear(int(f * E)) for f in (0, 0.25, 0.5, 1.0, 2.0)]
    assert all(a < b for a, b in zip(rb, rb[1:])), "RBER grows with P/E cycles"
    assert fm.p_prog_fail(int(E)) > fm.p_prog_fail(0) and fm.p_erase_fail(int(E)) > fm.p_erase_fail(0)
    assert t.t_erase(int(E)) > t.t_erase(0) and t.t_prog(int(E)) < t.t_prog(0)
    blk = 30
    t.precondition_wear(0, blk, int(t.cfg.faults.endurance_hard_limit_factor * E))
    assert t.block(0, blk).flags & BF_WORN_OUT
    assert t.erase_block(0, blk).code == "FAIL_WORN"
    return {"rber_vs_pe": [f"{x:.2e}" for x in rb]}


@reftest("Power interruption")
def t_power_cut_during_program(d):
    t = _target(d)
    PB = t.g.page_bytes
    data = _pat(11, PB)
    op = t.begin_program(1, 3, 0, data, b"\x01" * PB)
    cut = t.power_off(op.t_start + 0.4 * op.dur)
    assert cut and abs(cut[0]["frac"] - 0.4) < 1e-12
    t.power_on()
    try:
        t.read_page(1, 3, 0)
        raise AssertionError("must require RESET after power-on")
    except ProtocolError:
        pass
    assert t.reset().busy_ns == t.cfg.timing.t_rst_poweron_ns
    st = t.peek(1, 3, 0)
    z_s = sum(8 - bin(x).count("1") for x in st)
    z_d = sum(8 - bin(x).count("1") for x in data)
    assert 0 < z_s < z_d and all(((~s & 0xFF) & x) == 0 for s, x in zip(st, data))
    assert t.page(1, 3, 0).flags & PF_PROG_INTERRUPTED
    assert t.program_page(1, 3, 0, data).ok and t.peek(1, 3, 0) == data, "re-program completes the page"
    return {"intended_zeros": z_d, "written_zeros": z_s}


@reftest("Power interruption")
def t_power_cut_during_erase(d):
    t = _target(d)
    PB = t.g.page_bytes
    for p in range(3):
        t.program_page(1, 6, p, _pat(20 + p, PB))
    op = t.begin_erase(1, 6)
    t.power_off(op.t_start + 0.5 * op.dur)
    t.power_on()
    t.reset()
    st = t.peek(1, 6, 0)
    ones = sum(bin(x).count("1") for x in st)
    assert all((x & ~s & 0xFF) == 0 for s, x in zip(st, _pat(20, PB))) and sum(
        bin(x).count("1") for x in _pat(20, PB)) < ones < PB * 8
    b = t.block(1, 6)
    assert b.flags & BF_MARGINAL and b.flags & BF_ERASE_INTERRUPTED and b.ec == 1
    assert t.erase_block(1, 6).ok and t.peek(1, 6, 0) == b"\xff" * PB and not (t.block(1, 6).flags & BF_MARGINAL)


@reftest("Power interruption")
def t_power_cut_persists_across_restart(d):
    t = _target(d)
    PB = t.g.page_bytes
    op = t.begin_program(0, 8, 0, _pat(12, PB), b"\x01" * PB)
    t.power_off(op.t_start + 0.3 * op.dur)
    partial = t.peek(0, 8, 0)
    t.close()
    t2 = NandTarget(_tcfg(), os.path.join(d, "target0.nlsf"), 0, create=False)
    assert t2.peek(0, 8, 0) == partial and t2.page(0, 8, 0).flags & PF_PROG_INTERRUPTED


@reftest("Error reproducibility")
def t_error_reproducibility(d):
    prof = {"rber_fresh": 1e-3, "read_noise_rber": 0.0}

    def run(sub, seed):
        t = _target(os.path.join(d, sub), "ideal", faults={**prof, "seed": seed})
        t.program_page(0, 2, 0, _pat(13, 528))
        return t.read_page(0, 2, 0).data, t.read_page(0, 2, 0).data
    a1, a2 = run("a", 1)
    b1, b2 = run("b", 1)
    c1, _ = run("c", 2)
    assert a1 == a2 == b1 == b2, "same seed + same history -> identical errors"
    assert a1 != c1, "different seed -> different weak cells"


@reftest("Error reproducibility")
def t_nested_monotonic_retention(d):
    t = _target(d, "ideal", faults={"retention_rber_ref": 1e-3, "retention_ref_hours": 1000.0})
    PB = t.g.page_bytes
    data = _pat(14, PB)
    t.program_page(0, 2, 0, data)
    prev, counts = None, []
    for hours in (100, 300, 1000, 3000, 10000):
        t.bake(hours, 40.0)
        r = t.read_page(0, 2, 0).data
        err = bytes(a ^ b for a, b in zip(data, r))
        if prev is not None:
            assert all((p & ~e & 0xFF) == 0 for p, e in zip(prev, err)), "failing-cell set only grows"
        prev = err
        counts.append(_bitdiff(data, r))
    assert counts == sorted(counts) and counts[-1] > counts[0]
    return {"errors_vs_bake": counts}


@reftest("Error reproducibility")
def t_restart_reproduces_errors(d):
    t = _target(d, "stress")
    PB = t.g.page_bytes
    t.program_page(1, 30, 0, _pat(15, PB))
    t.bake(500, 40)
    t.close()
    reads = []
    for k in range(2):
        shutil.copyfile(os.path.join(d, "target0.nlsf"), os.path.join(d, f"copy{k}.nlsf"))
        tk = NandTarget(_tcfg("stress"), os.path.join(d, f"copy{k}.nlsf"), 0, create=False)
        tk.reset()
        reads.append(tk.read_page(1, 30, 0).data)
    assert reads[0] == reads[1] and reads[0] != _pat(15, PB)


@reftest("Read retry")
def t_read_retry_recovers_retention(d):
    t = _target(d, "ideal", faults={"retention_rber_ref": 5e-3, "retention_ref_hours": 1000.0})
    PB = t.g.page_bytes
    data = _pat(16, PB)
    t.program_page(0, 2, 0, data)
    t.bake(2000, 40)
    e = {lvl: _bitdiff(data, t.read_page(0, 2, 0, retry=lvl).data) for lvl in (0, 1, 2, 3, -2)}
    assert e[3] < e[2] < e[1] < e[0] < e[-2]
    t.set_feature(FEAT_READ_RETRY, [0xFD])
    assert t.retry_level == -3 and t.get_feature(FEAT_READ_RETRY)[0] == 0xFD
    return {"errors_by_retry_level": e}


@reftest("Timing")
def t_busy_times_and_wp(d):
    t = _target(d)
    tm = t.cfg.timing
    PB = t.g.page_bytes
    assert t.read_page(0, 2, 0).busy_ns == tm.t_r_ns
    t.set_write_protect(True)
    r = t.program_page(0, 2, 0, _pat(1, PB))
    assert r.code == "WRITE_PROTECTED" and not (r.status & ST_WP_N) and r.status & ST_FAIL
    assert t.erase_block(0, 2).code == "WRITE_PROTECTED" and t.peek(0, 2, 0) == b"\xff" * PB
    t.set_write_protect(False)
    assert t.set_feature(FEAT_TIMING_MODE, [5]).busy_ns == tm.t_feat_ns and t.timing_mode == 5
    assert t.iface()["tRC"] == 20


@reftest("Latency and contention")
def t_latency_contention(d):
    cfg = _tcfg("ideal")
    tw = NandFlashTwin(cfg, os.path.join(d, "arr"))
    tm = cfg.timing
    sim = ArraySimulator(tw, "interleave")
    io = ONFI_ASYNC_MODES[0]
    # two reads to the SAME LUN serialise; reads to different LUNs overlap
    for k in range(2):
        tw.targets[0].program_page(0, 2, k, _pat(k, 528))
        tw.targets[0].program_page(1, 2, k, _pat(k, 528))
    r = sim.run([WorkloadOp(0.0, "READ", 0, 0, 2, 0), WorkloadOp(0.0, "READ", 0, 0, 2, 1)])
    assert r[1]["t_array_start"] >= r[0]["t_end"]
    sim2 = ArraySimulator(tw, "interleave")
    r2 = sim2.run([WorkloadOp(0.0, "READ", 0, 0, 2, 0), WorkloadOp(0.0, "READ", 0, 1, 2, 0)])
    assert r2[1]["t_array_start"] < r2[0]["t_end"], "different LUNs overlap array time"
    xfer = 528 * io["tRC"]
    d0, d1 = r2[0]["t_end"] - xfer, r2[1]["t_end"] - xfer
    assert abs(d1 - d0) >= xfer - 1e-6, "data-out transfers serialise on the shared channel"
    # FIFO head-of-line blocking vs interleave
    ops = [WorkloadOp(0.0, "PROG", 0, 0, 3, 0, seed=1), WorkloadOp(1.0, "PROG", 0, 0, 3, 1, seed=2),
           WorkloadOp(2.0, "READ", 0, 1, 2, 0)]
    f = ArraySimulator(tw, "fifo").run(ops)
    i = ArraySimulator(tw, "interleave").run([WorkloadOp(o.t_arrival, o.kind, o.target, o.lun, 4 if o.kind == "PROG" else o.blk, o.pg, seed=o.seed) for o in ops])
    assert i[2]["latency_ns"] < f[2]["latency_ns"]
    return {"fifo_read_latency_us": f[2]["latency_ns"] / 1000, "interleave_read_latency_us": i[2]["latency_ns"] / 1000}


@reftest("Latency and contention")
def t_read_retry_latency(d):
    cfg = _tcfg("ideal", faults={"retention_rber_ref": 2e-2, "retention_ref_hours": 1000.0})
    tw = NandFlashTwin(cfg, os.path.join(d, "arr"))
    t = tw.targets[0]
    t.program_page(0, 2, 0, _pat(3, 528))
    t.bake(3000, 40)
    sim = ArraySimulator(tw, "interleave")
    r = sim.run([WorkloadOp(0.0, "READ", 0, 0, 2, 0)])[0]
    assert r["retries"] >= 1 and r["bit_errors"] < r["bit_errors_first"]
    assert r["latency_ns"] > (1 + r["retries"]) * cfg.timing.t_r_ns
    return {"retries": r["retries"], "errors_first": r["bit_errors_first"], "errors_final": r["bit_errors"]}


@reftest("Threshold research model")
def t_vt_model_consistency(d):
    rep = vt_research_report()
    bad = [c for c in rep["checks"] if not c["pass"]]
    assert not bad, bad
    return {"checks": len(rep["checks"])}


@reftest("SV interface")
def t_svcfg_export(d):
    cfg = _tcfg("stress", directed={"force_prog_fail": [[0, 0, 3, 1]]})
    p = export_svcfg(cfg, os.path.join(d, "x.svcfg"))
    txt = open(p).read()
    assert "seed 00005f1caf10c552" in txt and "force_prog_fail 0 0 3 1" in txt and txt.strip().endswith("end")
    for line in txt.splitlines():
        if line.startswith(("rber_fresh", "t_prog_ns")):
            assert float(line.split()[1]) in (cfg.faults.rber_fresh, cfg.timing.t_prog_ns)


def run_reference_tests(workdir: Optional[str] = None, select: Optional[str] = None,
                        verbose: bool = True) -> Dict[str, Any]:
    base = workdir or tempfile.mkdtemp(prefix="nandlab-verify-")
    results = []
    for name, area, fn in REFERENCE_TESTS:
        if select and select not in name:
            continue
        d = os.path.join(base, name)
        os.makedirs(d, exist_ok=True)
        t0 = time.time()
        try:
            detail = fn(d) or {}
            ok, err = True, ""
        except Exception as e:
            ok, err, detail = False, f"{type(e).__name__}: {e}", {}
        results.append({"name": name, "area": area, "pass": ok, "error": err, "detail": detail,
                        "seconds": round(time.time() - t0, 3)})
        if verbose:
            print(f"  [{'PASS' if ok else 'FAIL'}] {area:28s} {name}" + (f"  -- {err}" if err else ""))
    return {"passed": sum(r["pass"] for r in results), "total": len(results), "results": results,
            "numpy": np is not None}


# =============================================================================
# 15. Demo scenario, viewer data, report, CLI
# =============================================================================
LIMITATIONS = [
    "Behavioural model of external NAND devices; it does not model, and makes no claim about, SilicaFlux-fabricated NAND cells.",
    "All reliability numbers (RBER coefficients, failure probabilities, factory-bad rate, read-disturb and retention terms) are illustrative. They are not measured NAND reliability and must be replaced with calibrated device data before any quantitative conclusion.",
    "Array timing (tR, tPROG, tBERS, tRST, tFEAT) are illustrative SLC-datasheet-range values; the ONFI async timing-mode table is a transcription to be checked against the ONFI revision / datasheet in use.",
    "ONFI subset only: no cache read/program, multi-plane commands in SV, copyback, read unique ID, synchronous/NV-DDR/Toggle interfaces, ZQ calibration, volume addressing or ODT. Multi-plane and multi-LUN concurrency are modelled in the Python latency engine; the SV model supports multi-LUN interleaving.",
    "Device semantics are SLC only. MLC/TLC/QLC exist only as a Gaussian threshold-voltage research model (unvalidated); there is no multi-bit device model, no program-order (LSB/MSB) constraint model and no cell-to-cell interference.",
    "Bit errors are drawn per cell from deterministic hashes; spatial correlation (bitline/wordline faults, edge wordlines), temperature during programming, program/erase suspend, and data-pattern dependence are not modelled.",
    "Retention uses an Arrhenius time scaling (Ea = 1.1 eV) of an illustrative power-law term; read disturb is a linear function of reads since erase; both are bit-level abstractions, not charge-transport physics.",
    "Partial-page programs update the page's program timestamp, so retention of earlier-programmed bytes on the same page is slightly underestimated.",
    "Power-loss behaviour (partially programmed/erased cells chosen by hash, proportional to elapsed busy time) is a plausible abstraction, not a characterised device behaviour.",
    "Stuck bits are applied at read time only; they do not cause program-verify failures.",
    "The SV model checks a subset of host AC timing (tWP, tWH, tWC, tRP, tREH, tRC, tCLS, tALS, tDS, tWHR, tADL, tRR, tCCS); hold times and CE#-related timings are not checked.",
    "The latency engine is a timing-accurate resource model (bus cycles, array busy, LUN/plane/channel contention), not a full SSD/FTL simulator; its workload generator is synthetic.",
    "Python and SV agreement is bit-exact for identical operation histories on the same platform; both rely on IEEE-754 double arithmetic and the C math library for exp/pow.",
]


def _round_list(xs, nd=4):
    return [float(f"{x:.{nd}g}") for x in xs]


def rber_curves(cfg_by_profile: Dict[str, Config]) -> Dict[str, Any]:
    out: Dict[str, Any] = {"pe": {}, "retention": {}, "note": SOURCES["illustrative_model"]}
    for name, cfg in cfg_by_profile.items():
        fm = FaultModel(cfg, 0)
        E = cfg.faults.rated_endurance_cycles
        xs = [k / 20.0 for k in range(0, 31)]
        out["pe"][name] = {"x": xs, "wear": [fm.p_wear(int(x * E)) for x in xs],
                           "prog_fail": [fm.p_prog_fail(int(x * E)) for x in xs],
                           "erase_fail": [fm.p_erase_fail(int(x * E)) for x in xs]}
        hrs = [10 ** (k / 4.0) for k in range(0, 21)]
        out["retention"][name] = {"x": hrs, "fresh": [fm.p_ret(h, 0) for h in hrs],
                                  "rated": [fm.p_ret(h, int(E)) for h in hrs]}
    return out


def _block_summary(t: NandTarget, errors: Dict[Tuple[int, int], int]) -> List[Dict[str, Any]]:
    g = t.g
    luns = []
    for lun in range(g.luns_per_target):
        blocks = []
        for blk in range(g.blocks_per_lun):
            b = t.block(lun, blk)
            np_ = sum(1 for p in range(g.pages_per_block) if (lun, blk, p) in t.pages and t.pages[(lun, blk, p)].nop > 0)
            blocks.append({"b": blk, "ec": b.ec, "fl": b.flags, "rd": b.reads, "np": np_,
                           "err": errors.get((lun, blk), 0)})
        luns.append({"blocks": blocks})
    return luns


def build_demo(outdir: str, config_path: Optional[str] = None, quick: bool = False,
               sv_report: Optional[str] = None, verbose: bool = True) -> Dict[str, Any]:
    """Run the reference demonstration and write viewer data + report."""
    def log(*a):
        if verbose:
            print("[demo]", *a, flush=True)
    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)
    work = os.path.join(outdir, "stores")
    if os.path.exists(work):
        shutil.rmtree(work)
    os.makedirs(work)
    base = load_config(config_path) if config_path else load_config(os.path.join(HERE, "config", "slc_tiny.json")) \
        if os.path.exists(os.path.join(HERE, "config", "slc_tiny.json")) else load_config()
    # ---- 1. fault scenario on target 0 (stress profile, directed faults) ----
    cfg = load_config(None, profile="stress", overrides={
        "geometry": asdict(base.geometry),
        "directed": {"force_erase_fail": [[0, 0, 45]], "force_prog_fail": [[0, 1, 46, 3]],
                     "stuck_bits": [[0, 1, 12, 2, 70, 0]]}})
    log("fault scenario:", cfg.geometry.summary())
    tw = NandFlashTwin(cfg, os.path.join(work, "fault_scenario"))
    t = tw.targets[0]
    g = cfg.geometry
    PB = g.page_bytes
    bad = set(t.scan_bad_block_markers())
    E = cfg.faults.rated_endurance_cycles

    bbm = g.page_data_bytes + cfg.policy.bad_block_marker_byte

    def page_data(seed):
        d = bytearray(_pat(seed, PB))
        d[bbm] = 0xFF            # controller convention: never write the bad-block-marker byte
        return bytes(d)

    def fill(lun, blk, npages, seed):
        if (lun, blk) in bad:
            return
        for p in range(npages):
            t.program_page(lun, blk, p, page_data(seed * 1000 + blk * 37 + p))
    # wear gradient on LUN0 blocks 8..31 (accelerated preconditioning), then data
    for i, blk in enumerate(range(8, 32)):
        if (0, blk) in bad:
            continue
        t.precondition_wear(0, blk, int(E * 1.5 * i / 23))
        fill(0, blk, g.pages_per_block, 1)
    for blk in range(2, 8):
        fill(0, blk, g.pages_per_block, 2)
    for blk in range(2, 24):
        fill(1, blk, g.pages_per_block if blk % 3 else g.pages_per_block // 2, 3)
    # read hammer (read disturb) on LUN1 block 4, page 0
    if (1, 4) not in bad:
        for _ in range(60 if quick else 600):
            t.read_page(1, 4, 0)
    # power cuts
    op = t.begin_program(0, 40, 0, page_data(4), b"\x01" * PB)
    t.power_off(op.t_start + 0.45 * op.dur)
    t.power_on(); t.reset()
    fill(1, 41, 6, 5)
    op = t.begin_erase(1, 41)
    t.power_off(op.t_start + 0.5 * op.dur)
    t.power_on(); t.reset()
    # directed failures
    fill(0, 45, 4, 6)
    t.erase_block(0, 45)
    fill(1, 46, 3, 7)
    t.program_page(1, 46, 3, page_data(8))
    fill(1, 12, 3, 9)
    # erase/reprogram cycles on a few blocks
    for blk in (50, 51):
        for k in range(3):
            fill(0, blk, 4, 10 + k)
            t.erase_block(0, blk)
    # unpowered retention bake
    t.bake(400.0, 55.0)
    log("bake: retention clock", f"{t.clock() / 3600.0:.0f} h @ reference temperature")
    # read sweep with mechanism attribution
    errmap = [[[0] * g.pages_per_block for _ in range(g.blocks_per_lun)] for _ in range(g.luns_per_target)]
    mech_map = {k: [[[0] * g.pages_per_block for _ in range(g.blocks_per_lun)] for _ in range(g.luns_per_target)]
                for k in ("wear", "retention", "read_disturb", "noise", "stuck")}
    mech_tot = {k: 0 for k in mech_map}
    blk_err: Dict[Tuple[int, int], int] = {}
    read_data: Dict[Tuple[int, int, int], bytes] = {}
    t.journal_enabled = True
    for lun in range(g.luns_per_target):
        for blk in range(g.blocks_per_lun):
            for p in range(g.pages_per_block):
                if (lun, blk, p) not in t.pages:
                    continue
                r = t.read_page(lun, blk, p, attribution=True)
                e = _bitdiff(r.data, t.peek(lun, blk, p))
                errmap[lun][blk][p] = e
                blk_err[(lun, blk)] = blk_err.get((lun, blk), 0) + e
                for k, v in r.info["errors"].items():
                    mech_map[k][lun][blk][p] = v
                    mech_tot[k] += v
                read_data[(lun, blk, p)] = r.data
    log("read sweep: bit errors by mechanism", mech_tot)
    # 3-D cell windows for interesting blocks
    cells3d = []

    def window(lun, blk, label):
        WB = 4                                   # window = 4 bytes = 32 bitlines
        best, best_e = 0, -1
        for w in range(0, g.page_data_bytes // WB):
            e = 0
            for p in range(g.pages_per_block):
                d = read_data.get((lun, blk, p))
                if d is not None:
                    s = t.peek(lun, blk, p)
                    e += _bitdiff(d[w * WB:w * WB + WB], s[w * WB:w * WB + WB])
            if e > best_e:
                best, best_e = w, e
        pages = []
        for p in range(g.pages_per_block):
            s = t.peek(lun, blk, p)
            d = read_data.get((lun, blk, p), s)
            bits_s = [(s[best * WB + (i >> 3)] >> (i & 7)) & 1 for i in range(WB * 8)]
            bits_e = [((s[best * WB + (i >> 3)] ^ d[best * WB + (i >> 3)]) >> (i & 7)) & 1 for i in range(WB * 8)]
            ps = t.page(lun, blk, p)
            pages.append({"pg": p, "s": bits_s, "e": bits_e, "fl": ps.flags if ps else 0,
                          "nop": ps.nop if ps else 0, "errors": errmap[lun][blk][p]})
        b = t.block(lun, blk)
        cells3d.append({"label": label, "target": 0, "lun": lun, "blk": blk, "bl0": best * WB * 8,
                        "ec": b.ec, "fl": b.flags, "rd": b.reads, "pages": pages})
    choices = [(0, 31, "Worn block (1.5x rated P/E) after retention bake"),
               (1, 4, "Read-disturbed block (hammered page 0)"),
               (0, 40, "Power cut during PROGRAM (page 0)"),
               (1, 41, "Power cut during ERASE"),
               (0, 3, "Healthy block after bake"),
               (0, 45, "Erase failure (directed)")]
    for lun, blk, label in choices:
        if (lun, blk) not in bad:
            window(lun, blk, label)
    fault_targets = [{"index": 0, "coords": g.target_coords(0), "luns": _block_summary(t, blk_err),
                      "ground_truth_bad": [list(x[:2]) + [",".join(x[2])] for x in t.ground_truth_bad()],
                      "marker_scan": [list(x) for x in t.scan_bad_block_markers()],
                      "counters": t.counters, "clock_h": t.clock() / 3600.0}]
    for ti in range(1, g.targets):
        tt = tw.targets[ti]
        fault_targets.append({"index": ti, "coords": g.target_coords(ti), "luns": _block_summary(tt, {}),
                              "ground_truth_bad": [list(x[:2]) + [",".join(x[2])] for x in tt.ground_truth_bad()],
                              "marker_scan": [list(x) for x in tt.scan_bad_block_markers()],
                              "counters": tt.counters, "clock_h": tt.clock() / 3600.0})
    tw.close()
    # ---- 2. latency / contention scenarios ----
    scen_defs = [("FIFO, mode 0", "fifo", 0, False, "nominal"),
                 ("Interleave, mode 0", "interleave", 0, False, "nominal"),
                 ("Interleave, mode 5", "interleave", 5, False, "nominal"),
                 ("Interleave, mode 5, multi-plane", "interleave", 5, True, "nominal"),
                 ("Interleave, mode 5, stress + retention bake", "interleave", 5, False, "stress")]
    n_ops = 800 if quick else 3000
    scenarios = []
    gantt = []
    for k, (name, sched, mode, mp, prof) in enumerate(scen_defs):
        c = load_config(None, profile=prof, overrides={"geometry": asdict(base.geometry)})
        twl = NandFlashTwin(c, os.path.join(work, f"latency_{k}"))
        for tt in twl.targets:
            tt.timing_mode = mode
        if prof == "stress":
            pre = make_workload(twl, n_ops // 2, 0.0, 30.0, seed=11, multi_plane=mp)
            ArraySimulator(twl, sched).run(pre)
            twl.bake(150.0, 40.0)
            # read back everything that was written, in random order, after the bake
            ops = [WorkloadOp(o.t_arrival, "READ", o.target, o.lun, o.blk, o.pg, o.planes)
                   for o in pre if o.kind == "PROG"]
            rr = random.Random(5)
            rr.shuffle(ops)
            tbase = 0.0
            for o in ops:
                tbase += rr.expovariate(1.0) * 1e6 / 30.0
                o.t_arrival = tbase
            ops = ops[:n_ops]
        else:
            ops = make_workload(twl, n_ops, 0.6, 30.0, seed=11, multi_plane=mp, targets=None)
        sim = ArraySimulator(twl, sched)
        recs = sim.run(ops)
        s = sim.summary()
        s["name"] = name
        s["timing_mode"] = mode
        s["multi_plane"] = mp
        s["profile"] = prof
        s["hist_read"] = latency_histogram(recs, "READ")
        s["hist_prog"] = latency_histogram(recs, "PROG")
        scenarios.append(s)
        if k == 1:
            gantt = sim.gantt
        twl.close()
        log(f"latency '{name}': read p50 {s.get('READ', {}).get('p50_us', 0):.0f} us, "
            f"p99 {s.get('READ', {}).get('p99_us', 0):.0f} us, retries {s['read_retries']}")
    # GC-heavy run on one target to show erase traffic
    c = load_config(None, profile="nominal", overrides={"geometry": asdict(base.geometry)})
    twg = NandFlashTwin(c, os.path.join(work, "latency_gc"))
    for tt in twg.targets:
        tt.timing_mode = 5
    ops = make_workload(twg, 3600 if quick else 6000, 0.25, 4.0, seed=21, targets=[0])
    simg = ArraySimulator(twg, "interleave")
    simg.run(ops)
    sg = simg.summary()
    sg["name"] = "Single target, write-heavy (block reuse -> erases)"
    sg["timing_mode"] = 5
    sg["multi_plane"] = False
    sg["profile"] = "nominal"
    sg["hist_read"] = latency_histogram(simg.records, "READ")
    sg["hist_prog"] = latency_histogram(simg.records, "PROG")
    scenarios.append(sg)
    twg.close()
    # ---- 3. research threshold model, curves, verification ----
    log("threshold research model ...")
    vt = vt_research_report()
    for mname, m in vt["modes"].items():
        for cnd in m["conditions"]:
            cnd["pdf"]["x"] = _round_list(cnd["pdf"]["x"][::2])
            cnd["pdf"]["pdf"] = [_round_list(y[::2]) for y in cnd["pdf"]["pdf"]]
    curves = rber_curves({"nominal": load_config(None, profile="nominal"),
                          "stress": load_config(None, profile="stress")})
    bridge = slc_model_bridge(load_config(None, profile="nominal"))
    log("python reference tests ...")
    ver = run_reference_tests(os.path.join(work, "verify"), verbose=False)
    sv = None
    for cand in ([sv_report] if sv_report else []) + [
            os.path.join(outdir, "sv_regression", "sv_regression_verilator.json"),
            os.path.join(outdir, "sv_regression", "sv_regression_iverilog.json")]:
        if cand and os.path.exists(cand):
            with open(cand) as f:
                sv = json.load(f)
            break
    if sv:
        sv = {"simulator": sv["simulator"], "ok": sv["ok"], "total_checks": sv["total_checks"],
              "total_failed": sv["total_failed"],
              "phases": [{"store": p["store"], "phase": p["phase"], "ok": p["ok"],
                          "checks": len(p["tb"]["checks"]),
                          "failed": sum(not c["pass"] for c in p["tb"]["checks"]),
                          "ops": p["cosim"]["records"]["BEGIN"], "bit_errors": p["cosim"]["bit_errors_replayed"],
                          "cosim_exact": p["cosim"]["ok"], "check_names": [c["name"] for c in p["tb"]["checks"]],
                          "info": p["tb"]["info"]} for p in sv["phases"]]}
    data = {
        "meta": {"model": MODEL_NAME, "version": MODEL_VERSION, "project": PROJECT,
                 "generated_utc": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime()),
                 "geometry_summary": g.summary(), "fault_profile": cfg.faults.profile,
                 "profile_note": FAULT_PROFILE_NOTES[cfg.faults.profile], "sources": SOURCES},
        "geometry": {**asdict(g), "blocks_per_lun": g.blocks_per_lun, "luns_per_target": g.luns_per_target,
                     "page_bytes": g.page_bytes, "targets": g.targets},
        "flags": {"page": {str(k): v for k, v in PAGE_FLAG_NAMES.items()},
                  "block": {str(k): v for k, v in BLOCK_FLAG_NAMES.items()}},
        "targets": fault_targets,
        "errors": {"target": 0, "total": errmap, "mechanisms": mech_map, "mech_totals": mech_tot},
        "cells3d": cells3d,
        "rber_curves": curves, "bridge": bridge, "vt": vt,
        "latency": {"scenarios": scenarios, "gantt": gantt,
                    "gantt_scenario": scen_defs[1][0]},
        "verification": {"python": ver, "sv": sv, "vt_checks": vt["checks"]},
        "limitations": LIMITATIONS,
    }
    vdir = os.path.join(outdir, "viewer")
    os.makedirs(vdir, exist_ok=True)
    with open(os.path.join(vdir, "viewer_data.json"), "w") as f:
        json.dump(data, f, separators=(",", ":"))
    html = write_viewer(data, os.path.join(vdir, "nandlab_viewer.html"))
    rep = write_report(data, os.path.join(outdir, "report", "NANDLAB_REPORT.md"))
    log("viewer:", html)
    log("report:", rep)
    return data


def write_viewer(data: dict, out_html: str) -> str:
    tpl_path = os.path.join(HERE, "viewer", "nandlab_viewer_template.html")
    with open(tpl_path) as f:
        tpl = f.read()
    blob = json.dumps(data, separators=(",", ":")).replace("</", "<\\/")
    html = tpl.replace("/*__NANDLAB_DATA__*/null", blob)
    os.makedirs(os.path.dirname(out_html), exist_ok=True)
    with open(out_html, "w") as f:
        f.write(html)
    return out_html


def write_report(data: dict, path: str) -> str:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    m = data["meta"]
    L = [f"# {m['model']} -- engineering report (v{m['version']})", "",
         f"_{m['project']} -- generated {m['generated_utc']}_", "",
         "> Simulated results from a behavioural model of external NAND devices. Every reliability and array-timing "
         "value is illustrative (see MODEL_LIMITATIONS.md); nothing here is measured NAND data.", "",
         "## Device under simulation", "", f"* Geometry: {m['geometry_summary']}",
         f"* Fault scenario profile: `{m['fault_profile']}` -- {m['profile_note']}", ""]
    ver = data["verification"]["python"]
    L += ["## Verification", "", f"* Python reference suite: **{ver['passed']}/{ver['total']} pass**", ""]
    L += ["| Area | Test | Result | Detail |", "|---|---|---|---|"]
    for r in ver["results"]:
        det = json.dumps(r["detail"])[:110] if r["detail"] else ""
        L.append(f"| {r['area']} | `{r['name']}` | {'PASS' if r['pass'] else 'FAIL'} | {det} |")
    sv = data["verification"]["sv"]
    if sv:
        L += ["", f"* SystemVerilog regression ({sv['simulator']}): **{'PASS' if sv['ok'] else 'FAIL'}**, "
                  f"{sv['total_checks'] - sv['total_failed']}/{sv['total_checks']} testbench checks; every phase "
                  "replayed through the Python golden model.", "",
              "| Store | Phase | TB checks | Co-simulation | Ops replayed | Bit errors replayed |", "|---|---|---|---|---|---|"]
        for p in sv["phases"]:
            L.append(f"| {p['store']} | {p['phase']} | {p['checks'] - p['failed']}/{p['checks']} | "
                     f"{'bit-exact' if p['cosim_exact'] else 'MISMATCH'} | {p['ops']} | {p['bit_errors']} |")
    else:
        L += ["", "* SystemVerilog regression: not run in this build (run `make sv`)."]
    e = data["errors"]["mech_totals"]
    L += ["", "## Fault scenario (target 0, stress profile, 400 h unpowered bake at 55 degC)", "",
          "Bit errors observed in a full read sweep, attributed by mechanism:", "",
          "| Wear | Retention | Read disturb | Read noise | Stuck |", "|---|---|---|---|---|",
          f"| {e['wear']} | {e['retention']} | {e['read_disturb']} | {e['noise']} | {e['stuck']} |", ""]
    t0 = data["targets"][0]
    L += [f"* Ground-truth bad/failed blocks: {len(t0['ground_truth_bad'])}; controller-visible factory markers: "
          f"{len(t0['marker_scan'])}", ""]
    L += ["## Latency and contention (illustrative timing)", "",
          "| Scenario | Read p50 (us) | Read p99 (us) | Program p50 (us) | Erases | Read MB/s | Write MB/s | Ch util | Retries | Uncorrectable |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for s in data["latency"]["scenarios"]:
        rd, pr = s.get("READ", {}), s.get("PROG", {})
        L.append(f"| {s['name']} | {rd.get('p50_us', 0):.0f} | {rd.get('p99_us', 0):.0f} | {pr.get('p50_us', 0):.0f} | "
                 f"{s.get('ERASE', {}).get('count', 0)} | {s['read_MBps']:.1f} | {s['write_MBps']:.1f} | "
                 f"{max(s['channel_utilisation']):.2f} | {s['read_retries']} | {s['uncorrectable_reads']} |")
    vt = data["vt"]
    L += ["", "## Threshold-voltage research model (UNVALIDATED)", "",
          "RBER with fixed default read references / optimal references:", "",
          "| Mode | " + " | ".join(c[0] for c in VT_CONDITIONS) + " |", "|---|" + "---|" * len(VT_CONDITIONS)]
    for name, mo in vt["modes"].items():
        L.append(f"| {name} | " + " | ".join(f"{c['rber_default']:.1e} / {c['rber_optimal']:.1e}"
                                             for c in mo["conditions"]) + " |")
    L += ["", f"Internal consistency checks: {sum(c['pass'] for c in vt['checks'])}/{len(vt['checks'])} pass. "
              "These test the mathematics, not agreement with silicon.", "",
          "## Limitations", ""] + [f"* {x}" for x in data["limitations"]]
    with open(path, "w") as f:
        f.write("\n".join(L) + "\n")
    return path


def init_configs(dirpath: str) -> List[str]:
    os.makedirs(dirpath, exist_ok=True)
    out = []
    tiny = load_config(None, profile="nominal")
    tiny.name, tiny.description = "slc_tiny", ("Small SLC-like test device: 2 channels x 1 package x 2 CE, "
                                                "2 LUN/CE, 2 planes, 64 blocks/LUN, 16 pages/block, 512+16 B pages. "
                                                "Illustrative values.")
    big = load_config(None, profile="nominal", overrides={"geometry": {
        "channels": 4, "packages_per_channel": 1, "targets_per_package": 2, "dies_per_target": 1,
        "luns_per_die": 1, "planes_per_lun": 2, "blocks_per_plane": 512, "pages_per_block": 64,
        "page_data_bytes": 2048, "page_spare_bytes": 64, "viz_wordline_layers": 16,
        "viz_string_select_lines": 4}, "ident": {"device_id": 0x5B}})
    big.name, big.description = "slc_1gbit_class", ("SLC 1 Gbit-class die geometry (2048+64 B pages, 64 pages/block, "
                                                     "1024 blocks) on 4 channels. For the Python twin; the SV model "
                                                     "needs POOL_PAGES set for this size. Illustrative values.")
    for c in (tiny, big):
        p = os.path.join(dirpath, f"{c.name}.json")
        with open(p, "w") as f:
            json.dump(c.to_dict(), f, indent=2)
        out.append(p)
    prof = {k: {**asdict(fault_profile(k)), "_note": FAULT_PROFILE_NOTES[k]} for k in ("ideal", "nominal", "stress")}
    p = os.path.join(dirpath, "fault_profiles.json")
    with open(p, "w") as f:
        json.dump({"_source": SOURCES["illustrative_model"], **prof}, f, indent=2)
    out.append(p)
    return out


def _cli_cfg(a) -> Config:
    """--config/--profile if given; otherwise the configuration saved with an existing store."""
    store = getattr(a, "store", None)
    if not a.config and not getattr(a, "profile", None) and store:
        man = os.path.join(store, NandFlashTwin.MANIFEST)
        if os.path.exists(man):
            with open(man) as f:
                return config_from_dict(json.load(f)["config"])
    return load_config(a.config, profile=getattr(a, "profile", None))


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="nand_flash_twin.py", description=f"{MODEL_NAME} {MODEL_VERSION} -- {PROJECT}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name, help_):
        p = sub.add_parser(name, help=help_)
        p.add_argument("--config", default=None, help="configuration JSON (default: built-in slc_tiny)")
        p.add_argument("--profile", default=None, choices=["ideal", "nominal", "stress"], help="fault profile")
        return p
    p = sub.add_parser("init-configs", help="write default configuration files")
    p.add_argument("--dir", default=os.path.join(HERE, "config"))
    p = add("create", "create (manufacture) a persistent device store")
    p.add_argument("--store", required=True)
    p = add("info", "summarise a store")
    p.add_argument("--store", required=True)
    p = add("read", "read a page (hex)")
    p.add_argument("--store", required=True)
    for k in ("target", "lun", "block", "page"):
        p.add_argument(f"--{k}", type=int, default=0)
    p.add_argument("--retry", type=int, default=0)
    p = add("program", "program a page from hex or a repeated byte")
    p.add_argument("--store", required=True)
    for k in ("target", "lun", "block", "page", "col"):
        p.add_argument(f"--{k}", type=int, default=0)
    p.add_argument("--hex", default=None)
    p.add_argument("--fill", default=None, help="byte value to fill the whole page, e.g. 0x5A")
    p = add("erase", "erase a block")
    p.add_argument("--store", required=True)
    for k in ("target", "lun", "block"):
        p.add_argument(f"--{k}", type=int, default=0)
    p = add("bake", "unpowered retention bake of every target")
    p.add_argument("--store", required=True)
    p.add_argument("--hours", type=float, required=True)
    p.add_argument("--temp", type=float, required=True)
    p = add("compact", "rewrite journals as compact snapshots")
    p.add_argument("--store", required=True)
    p = add("export-sv", "write nandlab.svcfg + nandlab_geom.svh for the SV model")
    p.add_argument("--out", required=True)
    p = add("workload", "latency/contention simulation")
    p.add_argument("--store", required=True)
    p.add_argument("--ops", type=int, default=2000)
    p.add_argument("--read-fraction", type=float, default=0.6)
    p.add_argument("--rate-kiops", type=float, default=20.0)
    p.add_argument("--mode", type=int, default=0)
    p.add_argument("--scheduler", default=None, choices=["fifo", "interleave"])
    p.add_argument("--multi-plane", action="store_true")
    p.add_argument("--csv", default=None)
    p = sub.add_parser("vt", help="threshold-voltage research model (SLC..QLC, unvalidated)")
    p.add_argument("--out", default=None)
    p = sub.add_parser("verify", help="run the Python reference verification suite")
    p.add_argument("--json", default=None)
    p.add_argument("-k", default=None, help="substring filter")
    p = sub.add_parser("sv-regress", help="compile + run the SV testbench phases and replay traces in Python")
    p.add_argument("--sim", default="verilator", choices=["verilator", "iverilog"])
    p.add_argument("--out", default=os.path.join(HERE, "outputs", "sv_regression"))
    p = sub.add_parser("cosim", help="replay one SV trace against a store snapshot")
    p.add_argument("--config", required=True)
    p.add_argument("--before", required=True)
    p.add_argument("--trace", required=True)
    p.add_argument("--target", type=int, default=0)
    p = sub.add_parser("demo", help="run the reference demonstration, write viewer + report")
    p.add_argument("--out", default=os.path.join(HERE, "outputs"))
    p.add_argument("--config", default=None)
    p.add_argument("--quick", action="store_true")
    a = ap.parse_args(argv)

    if a.cmd == "init-configs":
        for p in init_configs(a.dir):
            print("wrote", p)
    elif a.cmd == "create":
        tw = NandFlashTwin(_cli_cfg(a), a.store, reset=False)
        print(f"store {a.store}: {tw.cfg.geometry.summary()}")
        for t in tw.targets:
            print(f"  target{t.tidx}: factory bad blocks {t.scan_bad_block_markers()}")
        tw.close()
    elif a.cmd == "info":
        tw = NandFlashTwin(_cli_cfg(a), a.store, create=False, reset=False)
        print(json.dumps({"geometry": tw.cfg.geometry.summary(), "manifest_created": tw.manifest.get("created_utc"),
                          "targets": [{"target": t.tidx, "programmed_pages": len([p for p in t.pages.values() if p.nop]),
                                       "blocks_with_state": len(t.blocks), "retention_clock_h": t.clock() / 3600.0,
                                       "bad_or_failed": t.ground_truth_bad(), "load": t.load_stats,
                                       "warnings": t.warnings} for t in tw.targets]}, indent=2))
        tw.close()
    elif a.cmd in ("read", "program", "erase"):
        tw = NandFlashTwin(_cli_cfg(a), a.store, create=False)
        t = tw.targets[a.target]
        if a.cmd == "read":
            r = t.read_page(a.lun, a.block, a.page, retry=a.retry)
            print(f"{r.code} status={r.status:02x} busy={r.busy_ns:.0f}ns errors={r.info.get('errors')}")
            print(r.data.hex())
        elif a.cmd == "program":
            data = bytes.fromhex(a.hex) if a.hex else bytes([int(a.fill or "0x00", 0)]) * (t.g.page_bytes - a.col)
            r = t.program_page(a.lun, a.block, a.page, data, col=a.col)
            print(f"{r.code} status={r.status:02x} busy={r.busy_ns:.0f}ns")
        else:
            r = t.erase_block(a.lun, a.block)
            print(f"{r.code} status={r.status:02x} busy={r.busy_ns:.0f}ns erase_count={t.block(a.lun, a.block).ec}")
        tw.close()
    elif a.cmd == "bake":
        tw = NandFlashTwin(_cli_cfg(a), a.store, create=False, reset=False)
        tw.bake(a.hours, a.temp)
        print(f"retention clock now {tw.targets[0].clock() / 3600.0:.1f} h at reference temperature")
        tw.close()
    elif a.cmd == "compact":
        tw = NandFlashTwin(_cli_cfg(a), a.store, create=False, reset=False)
        tw.compact()
        tw.close()
        print("compacted")
    elif a.cmd == "export-sv":
        cfg = _cli_cfg(a)
        os.makedirs(a.out, exist_ok=True)
        print("wrote", export_svcfg(cfg, os.path.join(a.out, "nandlab.svcfg")))
        print("wrote", export_sv_geometry(cfg, os.path.join(a.out, "nandlab_geom.svh")))
    elif a.cmd == "workload":
        tw = NandFlashTwin(_cli_cfg(a), a.store)
        for t in tw.targets:
            t.timing_mode = a.mode
        ops = make_workload(tw, a.ops, a.read_fraction, a.rate_kiops, multi_plane=a.multi_plane)
        sim = ArraySimulator(tw, a.scheduler)
        recs = sim.run(ops)
        print(json.dumps(sim.summary(), indent=2))
        if a.csv:
            keys = ["kind", "target", "lun", "blk", "pg", "planes", "t_arrival", "t_bus_start", "t_array_start",
                    "t_end", "latency_ns", "wait_ns", "retries", "bit_errors", "uncorrectable", "rc"]
            with open(a.csv, "w") as f:
                f.write(",".join(keys) + "\n")
                for r in recs:
                    f.write(",".join(str(r.get(k, "")) for k in keys) + "\n")
        tw.close()
    elif a.cmd == "vt":
        rep = vt_research_report()
        print(rep["status"])
        for name, m in rep["modes"].items():
            print(f"  {name}: " + "; ".join(f"{c['name']}: {c['rber_default']:.2e} (opt {c['rber_optimal']:.2e})"
                                          for c in m["conditions"]))
        print(f"  checks: {sum(c['pass'] for c in rep['checks'])}/{len(rep['checks'])} pass")
        if a.out:
            with open(a.out, "w") as f:
                json.dump(rep, f)
    elif a.cmd == "verify":
        print(f"{MODEL_NAME} {MODEL_VERSION} reference verification (numpy: {np is not None})")
        rep = run_reference_tests(select=a.k)
        print(f"{rep['passed']}/{rep['total']} passed")
        if a.json:
            os.makedirs(os.path.dirname(os.path.abspath(a.json)), exist_ok=True)
            with open(a.json, "w") as f:
                json.dump(rep, f, indent=2)
        return 0 if rep["passed"] == rep["total"] else 1
    elif a.cmd == "sv-regress":
        rep = sv_regress(a.sim, a.out)
        return 0 if rep["ok"] else 1
    elif a.cmd == "cosim":
        cfg = load_config(a.config)
        rep = replay_trace(cfg, a.before, a.trace, a.before + ".pyreplay", a.target)
        print(json.dumps(rep, indent=2))
        return 0 if rep["ok"] else 1
    elif a.cmd == "demo":
        build_demo(a.out, a.config, quick=a.quick)
    return 0


if __name__ == "__main__":
    sys.exit(main())
