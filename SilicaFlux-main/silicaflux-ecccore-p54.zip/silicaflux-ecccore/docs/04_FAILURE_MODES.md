# 04 — Failure detection and what is (not) guaranteed

## 1. Outcome classes

| Class | What the hardware reports | When | Guarantee |
|---|---|---|---|
| **No errors** | `CLEAN` (syndromes all zero) | received word is a codeword | Correct **unless** the error pattern is itself a non-zero codeword (weight ≥ 2t+1) — then the error is *undetectable by BCH*. |
| **Corrected within capability** | `CORRECTED`, `nerr` = bits fixed (1…t) | L ≤ t and L distinct roots in range | **Always correct when ≤ t errors occurred** (BCH bound d ≥ 2t+1). With > t errors the same report can be a *miscorrection* (below). |
| **Erased** | `ERASED`, `nerr` = flips fixed | corrected word is all ones | Erased page with ≤ t flips per codeword. |
| **Decoder failure** (detected uncorrectable) | `UNCORRECTABLE`, `nerr` = 0 | L > t, repeated roots, roots outside the shortened range or in padding | Never wrong data with a success status; data passed through (raw, or with the roots found applied — documented, bit-exact with the reference). |
| **Detected by the integrity check** | `INTEGRITY_FAIL` (page level) | decoder claimed CLEAN/CORRECTED but CRC-16 of sector‖meta mismatches | Catches a miscorrection or an undetectable pattern with probability 1 − 2⁻¹⁶ (CRC check of a random corruption). |
| **Potential undetected error** | `CLEAN`/`CORRECTED` with wrong data | decoder miscorrected **and** the CRC happens to match | Residual risk: P(miscorrection) × 2⁻¹⁶ for random-like patterns (table below). Not observable in hardware by construction; measured only in the testbenches, which know the truth. |

**For BCH we do not promise detection of every pattern beyond t.**  A received word with more than t errors that
falls inside the decoding sphere (radius t) of another codeword is decoded to that codeword with a success
status.  The decoder cannot know; only an independent check can.

## 2. Miscorrection probability

For a pattern far beyond t (received word ≈ uniformly random), the probability of landing in some decoding sphere
is ≈ V(n', t) / 2^r with V(n', t) = Σ_{i≤t} C(n', i):

| Config | n' | t | r | P(miscorrection \| heavy errors) ≈ V/2^r | with CRC-16 (× 2⁻¹⁶) |
|---|---|---|---|---|---|
| B255T4 | 255 | 4 | 32 | 4.1 × 10⁻² | 6.2 × 10⁻⁷ |
| N512T4 | 4212 | 4 | 52 | 2.9 × 10⁻³ | 4.4 × 10⁻⁸ |
| N512T8 / N2KT8 | 4216 | 8 | 104 | 1.2 × 10⁻⁷ | 1.9 × 10⁻¹² |
| N8KT40 | 8928 | 40 | 560 | 3 × 10⁻⁵⁹ | ≈ 0 |

**Measured** (core testbench, RTL = reference bit-exact; `reports/coverage.md` §2): B255T4 with 5–9 random errors
is miscorrected in **3.1–4.6 %** of trials (1 071 trials at weight 5, 356 at 6, 327 at 7, 237 at 8),
matching the estimate.  The NAND-sector codes produced **no** miscorrection in the 768 (t = 4) and 755 (t = 8)
core-vector codewords beyond t — consistent with 2.9 × 10⁻³ and 1.2 × 10⁻⁷.  On the twin, the retention campaign
(576 codewords beyond t, up to 30 raw errors) and the statistical campaign (≈ 840 codewords beyond t at t = 4,
≈ 1 710 at t = 8) also saw **zero undetected errors**; at t = 4 a few miscorrections would be expected only after
~10³ failing codewords, so this sample cannot resolve that rate — the estimate, not the sample, is the number to
use.

### Structured patterns can be much worse than the estimate

Measured with the reference (and reproduced bit-exactly by the RTL in the BURST vectors): for BCH(255,223)
**every solid burst of exactly 10 bits is miscorrected** (400/400 trials), while solid bursts of 5–9 and 11–15
bits are always detected.  The burst polynomial x^a(1 + x + … + x⁹) lies within distance 4 of a codeword of this
particular code, and the code is cyclic, so every position behaves alike.  The 512-byte codes showed no such
weakness for bursts up to 2t+9 bits (40 trials per length), but the lesson stands: the random-error estimate is
not a bound for correlated NAND failures (bit-line or word-line defects), which is why the integrity check is
mandatory, not optional.

## 3. The independent integrity check

* CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF) over sector ‖ user metadata, computed before encoding, stored
  inside the codeword (so it is itself BCH-protected) and re-computed over the *corrected* output.
* Verdict precedence (`sfecc_page_dec`): decoder failure → `UNCORRECTABLE`; erased → `ERASED` (CRC not
  applicable); otherwise CRC mismatch → `INTEGRITY_FAIL`.  The comparison result is reported for every sector
  (`crc_ok`) as a diagnostic.
* Exercised deliberately: the page vectors construct miscorrections (received = c + x^j·g(x) + e, wt(e) ≤ t, the
  decoder lands on the codeword c + x^j g(x)) and error patterns that *are* codewords (syndromes zero, BCH reports
  `CLEAN`).  Every one of them is reported `INTEGRITY_FAIL`; with the miscorrections that random heavy patterns
  produce on their own, the page testbenches see 56 (N2KT8), 14 (N512T4) and 168 (L24, LDPC codec)
  `INTEGRITY_FAIL` sectors, each bit-exact with the reference (`reports/coverage.md` §3).
* Residual: a CRC-16 misses a random corruption with probability 2⁻¹⁶.  For t = 4 at end of life this is the
  dominant undetected-error term (4.4 × 10⁻⁸ per failing codeword); a 32-bit CRC (4 spare bytes, available in the
  N512T4 slot if UMETA shrinks to 4) lowers it to 6.8 × 10⁻¹³.  End-to-end protection (host-generated guard tags,
  T10-DIF style) is outside this engine.

## 4. Other detected conditions

* **Framing**: `in_last` / `raw_last` on the wrong byte → `frame_err` (encoder pulse, decoder per-codeword flag,
  page `frame_err`); framing itself follows the byte count.  Tested (core testbench FRAME phase).
* **Erased page with > t flips** → `UNCORRECTABLE` (tested on the twin).
* **Bad-block marker** ≠ 0xFF → reported in the page status; data still decoded (tested on the twin: stuck BBM
  bit → `bbm = 0x7f`, sectors CLEAN).

## 5. What the FTL must do with each outcome (recommended policy, not implemented in P51 yet)

| Outcome | Action |
|---|---|
| CLEAN / CORRECTED, max flips < threshold | use data |
| CORRECTED with `scrub` (max flips ≥ ⌈3t/4⌉) | use data, schedule relocation (refresh) of the block |
| ERASED (all sectors) | page never written / erased: treat as unmapped |
| UNCORRECTABLE or INTEGRITY_FAIL | read retry with shifted read references (NANDLab supports feature A0h retry levels), then soft-decision decode (LDPC path), then RAID/parity across dies, then report a media error |
