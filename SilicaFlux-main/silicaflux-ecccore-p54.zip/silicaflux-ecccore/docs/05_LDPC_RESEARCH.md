# 05 — LDPC research extension

Status: **research + a small, independently validated proof of concept** behind the replaceable codec
interface.  The PoC is not a NAND-grade LDPC engine (see §5 for what one needs).  Reference:
`ref/sfecc_ldpc.py`; RTL: `rtl/sfecc_ldpc_enc.sv`, `rtl/sfecc_ldpc_dec.sv`; validation:
`reports/ldpc_validation.md`; RTL test: `tb/tb_sfecc_ldpc.sv`.

## 1. Why LDPC for modern NAND

BCH decoding is hard-decision and bounded-distance: it corrects exactly t errors and needs ≈ m·t parity bits.
TLC/QLC end-of-life raw BER is 10⁻³…10⁻² per bit; at 1 KiB codewords that is 8–80 errors, needing t = 60–120
(105–210 parity bytes per KiB) with a bounded-distance decoder whose failure rate falls off a cliff.  LDPC codes
with soft-decision belief propagation operate within ~1 dB of capacity, use *probabilities* from multiple reads
and degrade gracefully.  Every current TLC/QLC controller uses LDPC (typically 2–4 KiB codewords, rate 0.88–0.94)
with BCH or CRC as an outer check and RAID-like parity across dies.

## 2. Research topics

| Topic | Findings / design guidance |
|---|---|
| **Parity-check matrices** | Quasi-cyclic (QC) codes defined by a base (proto)graph of Z×Z circulant permutation blocks: routing becomes fixed rotations, memory is organised by block columns, the encoder can be a staircase/dual-diagonal accumulator (linear time).  Design for girth ≥ 8, avoid small trapping/absorbing sets (PEG-like or ACE-constrained searches), choose the degree distribution by density evolution / EXIT analysis for the target rate.  Irregular codes (variable degrees 2…~10) reach thresholds closer to capacity. |
| **Soft-decision decoding** | Sum-product (tanh rule) is optimal on cycle-free graphs; hardware uses (normalised/offset) min-sum: check node = sign product + two smallest magnitudes, within ~0.1–0.3 dB.  Fixed point: 3–5-bit channel LLRs, 6–8-bit posteriors are typical (the PoC: 5 / 8 / 6 bits, measured within ~0.1 dB of float BP, §4). |
| **Read-retry information** | One read gives a hard decision (BSC).  Additional reads at shifted references (read-retry offsets or dedicated soft-read commands) split the threshold-voltage axis into regions; each region maps to an LLR from the two state distributions.  LLR tables must track wear, retention and temperature (calibration per block/word line, or learned on the fly).  The NANDLab twin supports retry levels (feature A0h) and has an *unvalidated* MLC/TLC/QLC Vt research model — the place to generate LLR tables next. |
| **Decoder iterations** | Layered (row-by-row) scheduling converges ~2× faster than flooding.  Average iterations with early termination (syndrome = 0) are 1–3 at moderate RBER (PoC: 1.2–2.6 at Eb/N0 3–5 dB, §4) and climb to the cap near the waterfall: latency/QoS is set by the iteration cap, throughput by the average. |
| **Error floor** | At high SNR, failures are dominated by trapping sets, not by minimum distance; floors around 10⁻⁸…10⁻¹² FER are common if not designed out.  Countermeasures: graph design, offset/normalisation choice, post-processing (bit-flip of unsatisfied-check neighbourhoods), an outer BCH/CRC, RAID.  Floors below 10⁻¹² cannot be measured in software simulation; FPGA emulation or importance sampling is required — none of that is done here. |
| **Throughput and SRAM** | Example sizing (estimate, not built): 4 KiB codeword, rate ≈ 0.9 → n ≈ 36.4 kbit, Z = 256, ~3.6 k checks.  Posterior memory n × 8 b ≈ 290 kbit; compressed check messages (min1, min2, index, d_c signs) ≈ 3.6 k × ~90 b ≈ 320 kbit; soft-input double buffer 2 × n × 3 b ≈ 220 kbit → **≈ 0.8 Mbit SRAM per decoder**.  Z-parallel layered processing ≈ nnz/Z ≈ 500 cycles per iteration; at 500 MHz and 10 iterations ≈ 3.6 Gbit/s per core, more at low RBER with early termination. |

## 3. Proof of concept (implemented)

* **Code**: QC-LDPC(128, 64), Z = 16, base matrix 4 × 8, `H = [H_I | H_P]`.  H_I: 4 × 4 circulants (column weight
  4), shifts from a seeded search that rejects every 4-cycle; H_P: staircase of identities (invertible, k = 64
  exactly, accumulate encoding).  Base matrix `[[15,1,15,3,0,-,-,-],[13,4,1,4,0,0,-,-],[1,7,8,10,-,0,0,-],[6,9,1,0,-,-,0,0]]`.
  Erased-page coset mask exactly as for BCH (here MASK = all ones: every row of H_I has even weight).
* **Decoder** (`sfecc_ldpc_dec`): layered offset-min-sum, one block row (16 independent checks) per cycle, 4 layer
  cycles + 1 syndrome-check cycle per iteration, early termination, ≤ 20 iterations; 5-bit channel LLRs (soft
  input via `in_llr`, or ±15 from hard bits), 8-bit posteriors, 6-bit check messages, offset 1.  Circulant
  routing = constant rotations selected by a 4:1 layer mux.  Status: CLEAN / CORRECTED / ERASED / UNCORRECTABLE,
  `nerr` = bits changed, `aux` = iterations.
* **Encoder** (`sfecc_ldpc_enc`): constant 64 × 64 generator (from the staircase) + mask.
* **Timing (measured, not optimised):** the whole layer — 16 check nodes × 8 edges of subtract, min1/min2 search,
  offset, add — is one combinational cycle: ≈ 47 k generic gates, 183 logic levels, ≈ 25 k ECP5 LUT4 and
  **≈ 9 MHz** post-route.  This proves function, not speed; a production decoder pipelines the check-node unit
  (read Q / min-find / write-back stages with hazard control between layers) and keeps P and R in SRAM banks.

### Independent validation (`reports/ldpc_validation.md`, 7/7)

| Check | Result |
|---|---|
| GF(2) rank of the dense H (Gaussian elimination, not the staircase argument) | 64 |
| H·c = 0 (dense product) for 500 random encodings | 0 failures |
| Tanner-graph girth (breadth-first search) | 6 (no 4-cycles) |
| Float sum-product == **pyldpc**'s independent flooding log-BP kernel (BSD-3), same LLRs | 300 / 300 frames that needed decoding |
| Hard-decision OMS: every single-bit error corrected | 128 / 128 |
| 3-read soft sensing never worse than 1-read hard (FER) | 4 / 4 points |

(pyldpc's top-level `decode()` crashes on irregular codes — a broadcast between the unique column- and row-weight
arrays — so its irregular log-BP kernel `_logbp_numba` is driven with the same outer loop.)

### RTL vs fixed-point reference (`tb/tb_sfecc_ldpc.sv`)

1 646 records (clean, BI-AWGN 1–5 dB soft LLRs, 1–8 hard bit flips, erased words with flips), soft and hard
decoder instances, random back-pressure: **message, status, corrected-bit count and iteration count bit-exact on
every record** (55 964 checks).  Average 3.45 iterations soft vs 6.35 hard on the same frames.

### Measured behaviour (small samples; characterises the PoC only)

| Eb/N0 (dB) | FER sum-product (float) | FER layered OMS 5-bit | FER OMS hard decisions | avg. iterations OMS |
|---|---|---|---|---|
| 2 | 0.108 | 0.122 | 0.670 | 5.3 |
| 3 | 0.015 | 0.018 | 0.367 | 2.6 |
| 4 | 0.0017 | 0.0017 | 0.137 | 1.6 |
| 5 | 0 / 600 | 0 / 600 | 0.038 | 1.2 |

NAND soft-sensing study (illustrative SLC model: two Gaussian Vt states, reads at 0 and ±0.6σ):

| Raw BER | FER, 1 read (hard) | FER, 3 reads (2-bit soft) |
|---|---|---|
| 0.62 % | 0 / 600 | 0 / 600 |
| 1.36 % | 0.50 % | 0 / 600 |
| 2.18 % | 0.50 % | 0 / 600 |
| 3.47 % | 3.67 % | 0 / 600 |

Hard-decision patterns (measured, not guaranteed): 1 error 100 %, 2 errors 8 112 / 8 128, 6 errors 97 %.

## 4. Replaceable codec interface (implemented and exercised)

`sfecc_codec_enc/dec` (docs/02 §7): one port list, `CODEC` parameter, `in_llr` soft input, status
`{code, nerr, aux}`.  The page engine (`silicaflux_storage_ecc`) was run unchanged with the LDPC codec (`L24`
configuration: 6-byte sectors + CRC-16 = the 8-byte LDPC message; 11-byte slots): 200 pages, 800 codewords, all
five sector outcomes including CRC-caught miscorrections — **0 mismatches** with the reference page model, which
itself takes the codec as a parameter (`PageFormat(codec=LDPCFormat())`).

## 5. From proof of concept to a production LDPC engine (not done)

1. Code design for the target page: n ≈ 18–36 kbit, rate from the OOB budget (docs/03), irregular QC protograph
   optimised by density evolution, girth ≥ 8, trapping-set screening; outer CRC kept.
2. Soft-information path: soft-read command sequences in the NAND controller (P51), LLR tables per
   block/word-line class from the NANDLab Vt model (once calibrated) and from field data; 2–3-bit LLR transport
   through the page engine (`in_llr` exists at codec level; the page decoder's spare buffer would carry LLRs too).
3. Architecture: memory-based (SRAM banks per block column), Z-parallel CNUs, pipelined layers with
   hazard handling, compressed check messages, double-buffered input; target 0.5–2 GB/s per core.
4. Verification: bit-exact fixed-point model (as done here) at scale, FPGA emulation for error-floor
   characterisation to 10⁻¹²…10⁻¹⁵, QoS (iteration distribution) under realistic read-retry flows.
