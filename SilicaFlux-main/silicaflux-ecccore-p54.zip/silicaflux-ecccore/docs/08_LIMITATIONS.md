# 08 — Limitations and what is not claimed

Everything here is RTL simulation, a Python reference, open-source synthesis estimates and an FPGA
place-and-route estimate.  Nothing ran on an FPGA board or silicon.

## Not claimed

* **Sufficiency for modern NAND.**  BCH(255,223) is a verification baseline only.  The 512-byte t = 4 / t = 8
  configurations match an SLC-class requirement (the NANDLab twin's ONFI parameter page asks for 4 bits per
  512 B).  t = 40 per KiB (N8KT40) is a scaling study.  **None of this is claimed sufficient for TLC/QLC NAND**,
  which needs LDPC with soft information (docs/05); the LDPC code here is a 128-bit proof of concept.
* **SSD endurance or UBER.**  Correction coverage was measured for the *tested error models* (directed patterns,
  random independent errors, bursts, the NANDLab twin's illustrative retention/disturb/noise physics).  It is
  not verified endurance, retention or uncorrectable-bit-error rate of any device; the twin itself is
  uncalibrated (its MODEL_LIMITATIONS.md).
* **Detection of every pattern beyond t.**  BCH miscorrects some patterns beyond t (measured 3–5 % for
  BCH(255,223), 100 % for solid 10-bit bursts on that code); the CRC-16 leaves a 2⁻¹⁶ residual (docs/04).
* **Timing closure / ASIC area.**  Yosys generic gate counts and an ECP5 (LFE5U-85F, speed grade 6) out-of-context
  place & route at seed 1 are estimates; no standard-cell library, no SDC sign-off, no SRAM macros (the buffers
  synthesise to LUT RAM / block RAM on ECP5 and to `$mem` in the generic flow).
* **ONFI compliance.**  The spare-first read uses the common 00h-30h / 05h-E0h commands as modelled by NANDLab;
  no NV-DDR/Toggle data interface, no vendor soft-read commands.

## Simplifications that matter for future work

* **Not integrated into P51.**  The P51 NAND controller still uses per-word SECDED; the integration (byte-stream
  re-routing, spare-first read sequencing, completion/status plumbing, FTL policy for UNCORRECTABLE / INTEGRITY /
  scrub) is specified in docs/00 §4 and docs/03 §6 but not implemented or run with the P51 firmware.
* **One decoder per channel, 8 bits/cycle.**  Sufficient for async SDR buses (≤ 50 MB/s) at the measured
  74–111 MHz (ECP5 estimates); NV-DDR2/3 (200–800 MT/s) needs wider datapaths (16/32 bits/cycle) or several codec instances, and
  more pipelining (docs/02 §4, docs/07).
* **KES area for large t** is fully parallel (3(t+1) multipliers); for t = 40 a folded KES would save most of
  it (KES time 82 cycles vs 1116-cycle codewords).  The t = 40 decoder (84 k gates, 56 k ECP5 LUT4) did not
  complete routing on an LFE5U-85F; its Fmax is unknown (pre-route estimate ≈ 20 MHz).
* **Full-engine timing**: the post-route critical path is the Chien saturating root counter; a wider
  non-saturating counter is the next step (not done: the RTL was frozen for the final regression).
* **Decoder output on failure** is the raw word or the word with the roots found applied (documented and
  bit-exact with the reference); consumers must check status before using data.
* **Status of codeword j may arrive after data of codeword j+1 has started** (two in-order channels).
* **LDPC PoC**: single-codeword, not pipelined (≈ 30–130 cycles per 16-byte codeword, ≈ 9 MHz on ECP5 because a
  whole layer is one combinational cycle), 128-bit code, girth 6,
  error floor not characterised, page engine feeds it hard decisions only (soft LLRs exist at codec level).
* **CRC-16** (not 32) because of the 16-byte spare per 512 B at t = 8; a CRC-32 fits the t = 4 layout if user
  metadata shrinks to 4 bytes.
* Icarus Verilog runs every core vector set except N8KT40 (first 120 records) and every page/LDPC set; the
  t = 40 configuration is slow in an event-driven simulator.

## Tool notes

* Yosys 0.33: constant functions written in Verilog-2001 style and included in module bodies (no packages in
  parameter lists), as in P26/P51.
* Verilator 5.020 `--binary` does not write coverage; coverage builds use `tb/cov/cov_main.cpp`.
* pyldpc 0.7.9's `decode()` fails on irregular codes; its BP kernel is called directly (docs/05).
* bchlib's Python build fails on this toolchain (setuptools `install_layout`); the Linux `lib/bch.c` it wraps is
  compiled directly with gcc (`ext/linux_bch`, GPL-2.0, test-only).
