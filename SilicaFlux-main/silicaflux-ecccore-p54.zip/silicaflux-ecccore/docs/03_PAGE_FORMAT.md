# 03 — NAND page integration

Reference: `ref/sfecc_page.py` (`PageFormat`).  RTL: `rtl/sfecc_page_enc.sv`, `rtl/sfecc_page_dec.sv`,
`rtl/silicaflux_storage_ecc.sv`.  OOB budget per configuration: [OOB_BUDGET.md](OOB_BUDGET.md) (generated).

## 1. Layout (split "ECC in OOB", one codeword per sector)

```
column 0                     PAGE_DATA                                   PAGE_DATA+PAGE_SPARE
| sector 0 | sector 1 | ... | slot 0 | slot 1 | ... | slot S-1 | unused (0xFF) |
                               slot i = RSVD(1) | UMETA_i | CRC-16_i | PARITY_i     (SLOT_STRIDE = PAGE_SPARE / S)

codeword i (stream order) = sector i || UMETA_i || CRC_i      (message, k bits)
                            || PARITY_i                       (ceil(r/8) bytes, last TPAD bits = 1)
```

* **Bad-block marker.**  Slot 0's RSVD byte is the first spare byte (column PAGE_DATA), where NAND vendors and
  the NANDLab twin (`bad_block_marker_byte 0`) put the factory bad-block marker.  It is **outside every
  codeword**, always programmed 0xFF, and reported as read (`rd_pst_bbm`), so a marker is never "corrected" away
  and a scan sees it.  Other slots' RSVD bytes keep the slot layout uniform.
* **User metadata** (UMETA bytes per sector, e.g. the FTL's LBA tag / sequence number) is ECC- and CRC-protected.
* **CRC-16/CCITT-FALSE** over sector || UMETA is inside the codeword (protected by BCH) and is the independent
  integrity check against miscorrection (docs/04).
* **Multiple codewords per page**: S = PAGE_DATA / SECTOR, each with its own slot; every sector is decoded and
  reported independently (`rd_sst_*`), the page status aggregates them.
* The layout keeps the data area contiguous (DMA-friendly, no BBM swap needed) — the reason for choosing the
  split layout over an interleaved data|spare|data|spare layout, which would put the BBM column inside a data
  sector on 2 KiB+ pages.

## 2. OOB capacity accounting

The spare area must hold, per sector, RSVD + UMETA + CRC + ⌈r/8⌉ parity bytes.  `PageFormat` raises and the RTL
refuses to elaborate (`SFECC_CFG_FATAL`) otherwise.

| Config | Page | Codewords | Per-slot use (RSVD + meta + CRC + parity) | Fits | t | Parity overhead |
|---|---|---|---|---|---|---|
| N512T4 | 512 + 16 (NANDLab `slc_tiny`, ONFI *ECC bits* = 4) | 1 | 1 + 6 + 2 + 7 = 16 / 16 | yes | 4 | 1.37 % |
| N512T8 | 512 + 16 | 1 | 1 + 0 + 2 + 13 = 16 / 16 | yes | 8 | 2.54 % |
| N2KT8 | 2048 + 64 (NANDLab `slc_1gbit_class`) | 4 | 1 + 0 + 2 + 13 = 16 / 16 | yes | 8 | 2.54 % |
| N8KT40 | 8192 + 744 | 8 | 1 + 20 + 2 + 70 = 93 / 93 | yes | 40 | 6.84 % |
| L24 (LDPC demo) | 24 + 44 | 4 | 1 + 0 + 2 + 8 = 11 / 11 | yes | — | 33 % (rate-1/2 PoC code) |

Examples of what does **not** fit (rejected): t = 9 on a 512+16 page (1 + 2 + 15 > 16); t = 40 per 1 KiB on a
16 KiB + 1952 B page with 20 B metadata (16 × 93 = 1488 fits, 16 × 128 B for t = 60 does not).  The table is the
budget a NAND part's spare size and ECC requirement must be checked against before a configuration is chosen.

## 3. Read order: spare area first

The page decoder expects the raw page **spare-first**: `00h, col = PAGE_DATA, row, 30h`, read PAGE_SPARE bytes,
then `05h col = 0 E0h` (Change Read Column), read PAGE_DATA bytes.  The parity of every sector is then known
before its data streams through the decoder, so no page buffer is needed (only the decoder's codeword banks and a
PAGE_SPARE-byte spare buffer).  The NANDLab BFM implements exactly this sequence (`read_page` +
`change_read_col`) and the twin reports **0 protocol errors and 0 timing violations** in every run.  The extra
05h-E0h costs tCCS (≈ 0.5 µs) per page against tR = 25 µs.  The program path emits the natural column order.

## 4. Erased pages according to the device model

The device model (NANDLab, SLC semantics) erases to all ones and models 1→0 flips on erased cells (read disturb,
read noise, stuck bits).  The engine handles erased pages with the coset MASK (docs/01 §7):

| Raw page | Decoder result | Sector status |
|---|---|---|
| all 0xFF | valid codeword of the all-ones message | ERASED, nerr = 0, payload all 0xFF |
| all 0xFF with ≤ t flips in a codeword | corrected to all ones | ERASED, nerr = number of flips |
| all 0xFF with > t flips in a codeword | decoder failure | UNCORRECTABLE |
| written page whose data is all 0xFF | CRC-16 ≠ 0xFFFF in the metadata ⇒ not all ones | CLEAN / CORRECTED |

The page status sets `all_erased` when every sector is ERASED, which the FTL uses to recognise unwritten pages
(e.g. after power loss) without a separate erased-page check.  Verified directly on the twin: erased page with 0,
1 flip per codeword (ERASED(1) × 4) and t+1 flips (UNCORRECTABLE) — `reports/nand_twin.md`.

## 5. Status reporting

* Sector status `{code, nerr, crc_ok, sector}` for every codeword, in page order, after the sector's data.
* Page status: `n_corr, n_uncorr, n_integ, n_erased, max_flips, tot_flips, all_erased, bbm, ok, scrub,
  frame_err`.  `scrub` = max_flips ≥ CTRL.flip_thr (default ⌈3t/4⌉): the FTL's refresh/relocate trigger before
  the page becomes uncorrectable.
* Statistics registers and RAS event pulses (docs/02 §6).

## 6. Where it sits in the P51 storage controller

```
host DMA ◄─► buffer SRAM (SECDED, P26) ◄─► [silicaflux_storage_ecc] ◄─► sfs_nand_ctrl byte stream ◄─► NAND DQ
                                             wr_pay/rd_pay               wr_raw/rd_raw (spare first)
```
The P51 controller keeps its command sequencing; its per-word SECDED beat logic is removed and its page byte
stream is routed through the engine.  Not done here (docs/08).
