# 02 — Hardware architecture

```
                    silicaflux_storage_ecc  (primary RTL)
 ┌────────────────────────────────────────────────────────────────────────────────────────┐
 │  program path                                                                          │
 │  wr_pay ─┐   ┌──────────────── sfecc_page_enc ───────────────────────────┐            │
 │  wr_um ──┴─► │ CRC-16 ─► sfecc_codec_enc (BCH | LDPC) ─► data bytes ─────┼─► wr_raw  │
 │              │                               └─► meta/CRC/parity ─► spare buf ─┘ (column order)
 │              └────────────────────────────────────────────────────────────┘            │
 │  read path                                                                             │
 │  rd_raw ───► ┌──────────────── sfecc_page_dec ───────────────────────────┐            │
 │ (spare first)│ spare buf ─┐                                               │            │
 │              │ data bytes ┴► sfecc_codec_dec ─► payload ─► rd_pay          │            │
 │              │                     │           ─► user meta ─► rd_um       │            │
 │              │                     │           ─► CRC check                │            │
 │              │                     └─► status ─► sector status ─► rd_sst  │            │
 │              │                                 ─► page status   ─► rd_pst  │            │
 │              └────────────────────────────────────────────────────────────┘            │
 │  rb_* register window: ID, configuration, statistics, scrub threshold, IRQ             │
 │  ev_corrected / ev_uncorr / ev_integrity / ev_scrub → P26 RAS event controller        │
 └────────────────────────────────────────────────────────────────────────────────────────┘

 sfecc_bch_dec (inside sfecc_codec_dec):
   in ─► [SYN: 8-bit Horner, t odd syndromes] ─► [KES: simplified iBM] ─► [CHIEN: 8 roots/cycle + correct] ─► out
            │ write                                                          ▲ read            + status
            └─────────────────── NBANKS × CW_BYTES codeword buffer ──────────┘
```

## 1. Interfaces

All data ports are **ready/valid byte streams** (AXI-Stream semantics: transfer when `valid && ready`, `valid`
never depends on `ready`, data stable while `valid && !ready`), with `last` on the final byte of a codeword /
page.  Status channels are ready/valid words.  Every module has one clock and an asynchronous active-low reset
(assert asynchronously, release synchronously upstream); all outputs are registered or come from registered
state except the documented `ready` paths.

| Port group | Codec level (`sfecc_codec_enc/dec`) | Page level (`silicaflux_storage_ecc`) |
|---|---|---|
| Encoder in | message bytes, `in_last` checked against the count | payload (`wr_pay`) + user metadata (`wr_um`) |
| Encoder out | stored codeword (message unchanged + parity) | raw page in column order (`wr_raw`) |
| Decoder in | stored codeword bytes, optional per-bit LLRs (`in_llr`) | raw page, spare area first (`rd_raw`) |
| Decoder out | message bytes; status {code, nerr, aux, frame_err} after the last byte | payload, metadata, sector status, page status |
| Framing | by byte count; a misplaced `last` raises `frame_err` (tested) | `rd_pst_frame_err`, encoder `frame_err` |

Status codes (`rtl/sfecc_defs.svh`): `CLEAN` 0, `CORRECTED` 1, `ERASED` 2, `UNCORRECTABLE` 3; page sectors add
`INTEGRITY_FAIL` 4.  `nerr` = bits corrected (also for ERASED: flips corrected); 0 when uncorrectable.

## 2. Encoder — `sfecc_bch_enc`

8 message bits per cycle into an r-bit division LFSR (unrolled 8 steps, each next-state bit an XOR of state and
input bits), registered output.  Message bytes pass straight through; after the last one the PAR_BYTES parity
bytes (⊕ erased MASK, TPAD padding ones) are shifted out while the input is held.  **One output byte per cycle,
no bubbles between codewords**: (MSG + PAR) cycles per codeword.

## 3. Decoder — `sfecc_bch_dec`: a three-stage pipeline

| Stage | Work | Cycles per codeword |
|---|---|---|
| SYN | t odd syndromes, 8-bit Horner update (constants only) + write raw byte to a free buffer bank; erased MASK removed on the syndrome path only | CW_BYTES (1 byte/cycle) |
| KES | simplified inversionless BM: cycle D = discrepancy (t+1 multipliers + XOR tree), cycle U = Λ/B update (2(t+1) multipliers); even syndromes S_(2^a·o) = S_o^(2^a) by a constant Frobenius XOR map at load | 2t + 2 (1 if all syndromes are 0) |
| CHIEN | read the buffered byte, evaluate Λ at its 8 positions (8·t constant multipliers), XOR error mask, emit message bytes through a 4-entry FIFO; one stage later count roots (popcount of the registered mask) and AND-reduce for the erased test | CW_BYTES (parity bytes are scanned, not output) |

Stages hand over through registered valid/ready slots; codeword j+1 is received while j is solved and corrected.
The next locator is accepted in the cycle the previous codeword's last byte retires, and the status of codeword j
is released only after its last data byte was accepted (data and status are two in-order channels).

**Buffer**: NBANKS × CW_BYTES bytes, one write port (SYN) and one synchronous read port (CHIEN).

## 4. Throughput / area trade-off (chosen and alternatives)

| Decision | Chosen | Why | Alternative (cost) |
|---|---|---|---|
| Parallelism | **8 bits/cycle** in every stage | matches an x8 NAND bus (one byte per bus cycle) and keeps the Chien search at 8·t constant multipliers | 16/32 bits/cycle: 2–4× SYN/Chien/LFSR XOR logic for 2–4× throughput; or several codec instances per channel |
| KES | **fully parallel per iteration, 2 cycles/iteration** | 2t+2 ≪ CW_BYTES (18 vs 527 cycles for t = 8): never the bottleneck | serial discrepancy (1 multiplier): ≈ t² cycles, ~3(t+1)→3 multipliers; still hidden for t ≤ ~20 at 527-byte words; a folded KES is the obvious area saving for t = 40 (82 cycles now) |
| Buffer banks | **NBANKS = 2** (default) | minimum memory (2 × 527 B per decoder) at 0.98 B/cycle on 527-byte sectors | NBANKS = 3: +50 % buffer; 32-byte BCH(255,223) words 0.927 → 0.954 B/cycle (measured) |
| Root search | Chien, 8 positions/cycle, merged with correction | no extra pass: correction streams out as positions are evaluated | separate Chien pass (2× latency) or BTZ/factoring (Linux style, software-friendly, poor in hardware) |
| Failure detection | roots-in-range = L (docs/01 §6) | exact, no second syndrome pass | re-syndrome the corrected word (one more pass) |
| Erased handling | **coset MASK** (constant XOR) | erased pages get the full t-bit guarantee; zero cost | zero-counting threshold (Linux fallback): ambiguous near t, extra counter |

Measured rates (no back-pressure, Verilator, `tb_sfecc_bch` PERF phase):

| Config | Codeword | Sustained input | First byte in → first byte out | → status |
|---|---|---|---|---|
| B255T4, NBANKS 2 | 32 B | 0.927 B/cycle | 36 cycles | 68 cycles |
| B255T4, NBANKS 3 | 32 B | 0.954 B/cycle | 36 | 68 |
| N512T4 / N512T8 | 527 B | 0.981 B/cycle | 531 | 1058 |
| N8KT40 | 1116 B | 0.956 B/cycle (KES 82 cycles) | 1120 | 2236 |

The decoder is store-and-forward per codeword (the error locator needs all syndromes), hence the latency of one
codeword plus KES; the encoder adds one cycle.

### Timing optimisation applied (measured)

The first synthesis showed a 31-gate-level path: the KES load formed S₈ = ((S₁²)²)² with three chained general
multipliers, and the Chien stage counted roots in the same cycle as the evaluation.  Replacing the squarer chain
by the Frobenius map (squaring is GF(2)-linear: one XOR level of constants per output bit) and counting roots
from the registered error mask cut the depth to 20–21 levels and raised the ECP5 post-route Fmax from 77 to 98 MHz
(B255T4 decoder) and from 64 to 85 MHz (N512T4 decoder) while *reducing* area; every configuration was re-verified
bit-exact afterwards.  A second round moved the once-per-codeword status decision (root count vs L, erased
flag) into its own register stage (status one cycle later: 68 instead of 67 cycles for B255T4) and registered
the statistics snoop in `silicaflux_storage_ecc`, which had put the 32-bit counters behind the sector-status
ready/valid handshake, and replaced the page decoder's shift-based CRC-verdict queue by a pointer FIFO.  Final
post-route numbers: BCH(255,223) decoder 111 MHz, N512T4 decoder 93 MHz, N512T8 81 MHz, full engine 74–78 MHz
(docs/07, `reports/synthesis.md`).

## 5. Page engine — `sfecc_page_enc` / `sfecc_page_dec`

* **Program**: payload sector i → CRC-16 + codec encoder; data bytes leave in column order immediately;
  UMETA / CRC / parity bytes go to a PAGE_SPARE-byte spare buffer that is emitted after the data area
  (RSVD/BBM and unused spare bytes are always 0xFF).  Raw output 0.97 B/cycle (2048+64 page, measured).
* **Read**: the spare area arrives first (Change Read Column 05h-E0h, docs/03 §3) into the spare buffer; each
  sector then streams through the decoder followed by its slot's UMETA/CRC/parity from the buffer — **no page
  buffer**.  The CRC-16 of the corrected sector || UMETA is compared with the decoded CRC; the sector status
  combines decoder status and CRC verdict; page status counts classes, max/total flips, all-erased, the BBM byte
  as read, `ok` and the scrub hint.  The next page's spare area is captured while the last sectors decode.
* OOB accounting is enforced at elaboration (`SFECC_CFG_FATAL` if RSVD+UMETA+CRC+PARITY exceeds the spare bytes
  per sector) and in the reference (`PageFormat` raises).

## 6. Register window (`rb_*`, word offsets)

| Off | Name | Access | Content |
|---|---|---|---|
| 0x00 | ID | RO | 0x53454343 "SECC" |
| 0x04 | VERSION | RO | 0x00010000 |
| 0x08 | CFG0 | RO | [31:20] sectors/page, [19:16] codec, [15:8] t, [7:0] m |
| 0x0C | CFG1 | RO | [31:24] user meta B, [23:16] parity B, [15:0] sector B |
| 0x10 | CFG2 | RO | [31:16] spare B, [15:0] data B |
| 0x14 | CTRL | RW | [0] W1 clear statistics, [8] IRQ enable, [23:16] scrub flip threshold (reset (3t+3)/4) |
| 0x18 | STATUS | RO | [0] encoder busy, [1] decoder busy, [2] encoder framing error |
| 0x1C | IRQ | W1C | [0] pending: a sector was UNCORRECTABLE or INTEGRITY_FAIL |
| 0x20…0x40 | PAGES_ENC, PAGES_DEC, CW_DEC, CW_CORRECTED, BITS_CORRECTED, CW_UNCORR, CW_INTEGRITY, CW_ERASED, PAGES_SCRUB | RO | 32-bit statistics |
| 0x44 | LAST_FAIL | RO | {page[20:0], code[2:0], sector[7:0]} of the last failing sector |
| 0x48 | MAX_FLIPS | RO | largest corrected-bit count seen |

The page testbench reads the identification/configuration registers, checks every statistic against the sum of
the reference statuses and checks the clear.

## 7. Replaceable codec interface

`sfecc_codec_enc` / `sfecc_codec_dec` select the codec with `CODEC` (0 BCH, 1 LDPC) behind one port list, with an
`in_llr` soft-information input (8 × LLR_W bits per byte) that the BCH codec ignores and the LDPC codec uses.  The
page engine derives MSG/PAR byte counts from the selected codec and re-checks the OOB budget.  The same page
engine and page testbench run with the LDPC proof of concept (`L24`, docs/05) — 200 pages, 0 mismatches.
