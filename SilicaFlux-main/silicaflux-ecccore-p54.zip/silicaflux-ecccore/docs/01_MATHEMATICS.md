# 01 — Mathematical foundation

Reference implementation: `ref/sfecc_gf.py`, `ref/sfecc_bch.py`.  RTL: `rtl/sfecc_gf_funcs.svh` and the BCH
modules.  Independent validation: `scripts/validate_ref.py` → `reports/reference_validation.md` (64 checks).

## 1. Finite field GF(2^m)

* Representation: polynomial basis.  An element is an m-bit vector a = Σ aᵢ αⁱ, i < m, where α is a root of a
  **primitive** polynomial p(x) of degree m.  Addition = XOR.
* Multiplication: a·b = Σ_{i: bᵢ=1} a·αⁱ mod p(x), computed by shift-and-add with conditional reduction
  (`sfecc_gf_mul` in RTL: m AND-rows and m−1 reductions; with a constant operand it folds into a pure XOR
  network).  The reference also keeps log/antilog tables; both multiplications agree **exhaustively for
  m ≤ 10 and on 200 000 random pairs for m = 11…16**.
* Primitive polynomials (Linux `lib/bch.c` defaults; m = 8 is also Lin & Costello's 435₈):

| m | p(x) | hex | n = 2^m − 1 |
|---|---|---|---|
| 8 | x⁸+x⁴+x³+x²+1 | 0x11D | 255 |
| 13 | x¹³+x⁴+x³+x+1 | 0x201B | 8191 |
| 14 | x¹⁴+x⁵+x³+x+1 | 0x402B | 16383 |

  Primitivity is checked twice in the reference (the antilog table must reach every non-zero element before
  repeating; α^{(2^m−1)/q} ≠ 1 for every prime q | 2^m − 1) and once more in the RTL at elaboration
  (`sfecc_gfc_prim_ok`; the module refuses to elaborate otherwise).

## 2. Binary primitive narrow-sense BCH codes

* Cyclotomic coset of i: C_i = {i·2^j mod n}.  Minimal polynomial M_i(x) = Π_{j∈C_i} (x − α^j) ∈ GF(2)[x].
* Designed distance δ = 2t + 1: **g(x) = lcm{M_1, M_3, …, M_{2t−1}}** (M_{2i} = M_i, so even indices are
  redundant).  r = deg g ≤ m·t parity bits, k = n − r.  The BCH bound gives d_min ≥ 2t + 1.
* All 8 generator polynomials of BCH(255, k), t = 1…8, equal the published table (Lin & Costello, App. C,
  octal) — e.g. t = 4: g = 75626641375₈, k = 223.  For every configuration g(x) also equals galois' and the
  RTL re-checks g(α^i) = 0, i = 1, 3, …, 2t−1 at elaboration (binary coefficients ⇒ g(α^{2i}) = g(α^i)² = 0).

### Configurations

| Name | m | t | r | n (bits) | k (bits) | Parent code | Shortened by | Bytes (msg + parity) | Rate |
|---|---|---|---|---|---|---|---|---|---|
| **B255T4** (baseline) | 8 | 4 | 32 | 255 | 223 | BCH(255,223) | 0 | 28 (1 pad bit) + 4 | 0.875 |
| N512T4 | 13 | 4 | 52 | 4212 | 4160 | BCH(8191,8139) | 3979 | 520 + 7 (4 pad bits) | 0.988 |
| N512T8 / N2KT8 | 13 | 8 | 104 | 4216 | 4112 | BCH(8191,8087) | 3975 | 514 + 13 | 0.975 |
| N8KT40 (scaling) | 14 | 40 | 560 | 8928 | 8368 | BCH(16383,15823) | 7455 | 1046 + 70 | 0.937 |

## 3. Shortening

A shortened code uses the k' < k lowest information positions; the k − k' highest are implicitly zero.  It is
a linear code of length n' = k' + r with the same generator polynomial and **d_min ≥ 2t + 1** (a subcode of the
parent).  The decoder evaluates syndromes on the n' received bits only; the error-locator search covers only
positions 0 … n' − 1 and **a root outside that range means decoder failure** (the true pattern cannot have
errors in positions that were never transmitted).  Byte framing adds padding: LPAD leading bits (B255T4 makes the
223-bit message 28 bytes) and TPAD trailing bits in the last parity byte (r not a multiple of 8); padding bits
are never part of the code, are written 1, and are excluded from syndromes, roots and the erased test.  The
shortened configurations are checked against Linux `lib/bch.c` (which only supports byte-aligned shortened
messages) and galois (which supports shortening directly).

## 4. Systematic encoding

c(x) = u(x)·x^r + (u(x)·x^r mod g(x)).  The remainder is the state of an r-bit division LFSR fed with the message
MSB first (highest degree first).  The RTL unrolls 8 LFSR steps per cycle (`sfecc_bch_enc`): each next-state bit
is an XOR of state and input bits.  Stream bit s of a codeword is the coefficient of x^{n'−1+LPAD−s}.

## 5. Decoding

1. **Syndromes** S_j = r(α^j), j = 1 … 2t.  Hardware computes only the t odd ones, byte-parallel by Horner:
   S' = S·α^{8j} + Σ_{i=0..7} d_i α^{j·i} (constants only, a pure XOR network); a partial last byte uses
   α^{V·j}, V = 8 − TPAD.  Even syndromes follow from S_{2i} = S_i² (squaring is linear in GF(2^m)).
2. **Key equation** Λ(x)·S(x) ≡ Ω(x) mod x^{2t}, Λ(x) = Π(1 − X_l x).  Solved by the **simplified inversionless
   Berlekamp–Massey** algorithm (no field inversion, t iterations):
   ```
   Λ = 1, B = 1, L = 0, γ = 1
   for q = 0 … t−1  (r = 2q)
       δ  = Σ_{i=0..L} Λ_i · S_{2q+1−i}
       Λ' = γ·Λ + δ·x·B
       if δ ≠ 0 and L ≤ q:   B' = x·Λ,  L' = 2q+1−L,  γ' = δ
       else:                 B' = x²·B
   ```
   *Derivation.*  In the 2t-step inversionless BM the discrepancy of every odd step (r = 1, 3, …) is zero for
   binary codes because S_{2i} = S_i² (Berlekamp).  An odd step therefore only scales Λ by γ (roots unchanged)
   and shifts B by x; dropping the scaling and folding the shift into the even step gives B' = x²B (no length
   change) or B' = x·Λ (length change).  Empirically confirmed: on 3720 syndrome sets the 2t-step algorithm has
   **zero odd discrepancies** and its Λ equals the t-step Λ up to a scalar.
   *Cross-checks.*  On the same syndrome sets the t-step iBM equals (up to scaling) the classic BM with
   inversion (Massey 1969) and, whenever L ≤ t, Sugiyama's extended-Euclid solution.
   *Register bounds.*  L never decreases.  While L ≤ t, deg Λ ≤ L ≤ t and every x·B that is actually added
   (δ ≠ 0) has degree ≤ L, so registers holding t+1 coefficients never drop a non-zero coefficient; once L > t
   the decoder fails regardless of Λ.  (Truncation is therefore invisible: the RTL equals the unbounded
   reference on every vector.)
3. **Chien search** finds the positions d ∈ [0, n') with Λ(α^{−d}) = 0, 8 positions per cycle in stream order
   (R_j ← R_j·α^{8j}, lane l adds the constant α^{j·l}), and the correction XORs the error mask into the byte
   read back from the codeword buffer.

## 6. Failure detection — why "roots = L" is the right test

The decoder declares success iff **L ≤ t and Λ has exactly L distinct roots in the valid range**.  If so, the
corrected word is a codeword: let X₁…X_L be the roots' locators.  The Vandermonde system S_j = Σ Y_l X_l^j,
j = 1…L, has a unique solution Y, and since Λ is the minimal LFSR generating S₁…S_{2t}, the same Y reproduces all
2t syndromes.  For binary words S_{2j} = S_j² gives Σ (Y_l − Y_l²) X_l^{2j} = 0 for j = 1…t, and with L ≤ t
distinct X_l² the Vandermonde matrix is non-singular, so Y_l ∈ {0, 1}; minimality of L excludes 0.  Hence all
error values are 1, flipping the L located bits zeroes every syndrome, and the result is a codeword.  Any other
outcome (L > t, repeated roots, roots outside the shortened range, roots in padding positions) is a
**detected** decoder failure.  What this test cannot do is see an error pattern that lands within distance t of
a *different* codeword: see docs/04.

## 7. Erased pages: a coset of the code

NAND erases to all ones, and an all-ones word is generally not a codeword of a shortened BCH code.  Following
Linux `nand_bch`, the stored parity is p(u) ⊕ MASK with **MASK = p(1^k) ⊕ 1^r**.  Because p is linear,
p(1^k) ⊕ MASK = 1^r: an erased page (all ones) is the stored image of the message 1^k.  Decoding removes the
mask on the syndrome path only (S ← S(stored ⊕ MASK)), so an erased page with up to t bit flips is corrected
with the full BCH guarantee and reported **ERASED** with the number of flips; more flips are a detected failure.
A written all-0xFF sector is distinguished from an erased one by the CRC-16 stored in the protected metadata
(CRC of 512 × 0xFF = 0x6995 ≠ 0xFFFF).  For the unshortened B255T4 the all-ones word is already a codeword
(g(1) ≠ 0 ⇒ (x^n − 1)/(x − 1) is divisible by g), so MASK = 0.

## 8. Validation summary (`reports/reference_validation.md`)

| Check | Result |
|---|---|
| GF(2^m), m = 3…16: table vs shift-and-add multiplication, inverses, primitivity | pass (exhaustive for m ≤ 10) |
| BCH(255, k), t = 1…8 generator polynomials vs published octal table | 8 / 8 |
| Generator, parity and decode vs **galois** (independent Python) — every configuration incl. t = 40 | 0 mismatches |
| Parity and error locations vs **Linux kernel `lib/bch.c`** (BM + BTZ root finding, no Chien) — 5 geometries | 0 mismatches |
| Classic BM = simplified iBM = Euclid; zero odd-step discrepancies | 0 mismatches |
| B255T4: all 255 single and all 32 385 double errors corrected | pass |
| Erased codewords with ≤ t flips → ERASED, every configuration | pass |
| CRC-16/CCITT-FALSE check value 0x29B1 | pass |
