# 00 — Audit of the existing SilicaFlux-STORE code base

Scope: everything in the Aureom.AI repository that touches error correction, NAND, DMA, storage buffers,
polynomial arithmetic or verification tooling, as of 2026-11-12.  Archives were extracted read-only into a
scratch area; nothing in the repository was modified.

## 1. What exists

| Area | Where (archive in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`) | What it is | Relevance to P54 |
|---|---|---|---|
| **SRAM SECDED** (Project 26, RAS) | `silicaflux-ras-project26.zip` → `rtl/sfras_secded_enc.sv`, `sfras_secded_dec.sv`, `sfras_ecc_funcs.svh`, `sfras_ecc_sram.sv`, `sfras_scrub.sv` | Extended Hamming SECDED, K = 8…128 data bits per *word*, R+1 check bits, scrubber, fault injection, RAS event controller | Correct tool for SRAM/DRAM words. **Not** a NAND page code (see §2). Its coding style (Verilog-2001 constant functions included in module bodies, `SFRAS_CFG_FATAL`) is reused. |
| **NAND controller** (Project 51, StorageCore) | `silicaflux-storagecore-p51.zip` → `rtl/sfs_nand_ctrl.sv` | ONFI-style async SDR channel: RESET / READ_ID / READ_PAGE / PROGRAM / ERASE, op & completion queues, R/B# synchroniser | The integration point.  Page data is protected by **per-word SECDED**: every 32/64-bit fabric word is followed on the bus by one ECC beat (`ENABLE_ECC`), decoded on the fly.  Its own docs call this "a placeholder for a NAND-grade code (BCH/LDPC)" (`docs/05_NAND_AND_FTL.md`, `docs/08_LIMITATIONS.md`). |
| NAND flash model (P51) | `tb/models/sfs_nand_flash_model.sv` | Behavioural SLC LUN, 768-B raw pages, `flip_bit` hook | Superseded by NANDLab for this project. |
| **NAND digital twin** (Project 52, NANDLab) | `silicaflux-nandlab-v0.1.0.zip` → `nand_flash_model.sv`, `nand_flash_twin.py`, `tb/nand_ctrl_bfm.sv` | Pin-level persistent SV device model + bit-exact Python twin: program 1→0 rule, erase, factory bad blocks, wear, retention (Arrhenius), read disturb, read noise, directed `stuck_bit` faults, ONFI parameter page (*ECC bits required* = 4 per 512 B), 512+16 and 2048+64 geometries | **Used unmodified** as the fault-injection environment (`third_party/silicaflux-nandlab`, byte-identical, `scripts/check_vendor.py`). All its reliability numbers are illustrative (its `MODEL_LIMITATIONS.md`). |
| DMA | P51 `rtl/sfs_dma.sv`; DataFabric `dma_burst_engine.sv`, `dma_transfer_engine.sv` (in `silicaflux-hpc-m05-dma-adapter.zip`, vendored in P26/P51) | Descriptor DMA between host memory and the buffer SRAM | Not modified.  The P54 engine has byte-stream ready/valid ports so it can sit between the NAND channel and the buffer/DMA (docs/03 §6). |
| Storage buffers | P51 buffer SRAM behind `sfras_ecc_sram` (SECDED-protected), SRAMLIB `sram_generic_1r1w.sv` etc. | On-chip page buffers | The ECC engine needs only its own codeword banks + a spare-area buffer (docs/02 §4); SRAMLIB macros can back them in an ASIC flow. |
| **Polynomial arithmetic** | P26 Hamming (GF(2) parity matrices); ControlCore `firmware/common/crc32.c`; NANDLab ONFI CRC-16 (`onfi_crc16_step`); P51 FTL CRC32 checkpoints | GF(2) only | **No GF(2^m) arithmetic, no BCH, no LDPC anywhere in the repository** (`grep -ri "bch\|galois\|gf(2\|berlekamp\|chien\|ldpc"` finds only the "placeholder" remarks).  Built from scratch here. |
| Verification tools | P51/P52/P26 flows | Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python 3 reference models | Same tool versions installed here (Ubuntu packages) + nextpnr-ecp5 for a place-and-route Fmax estimate. |

## 2. SRAM SECDED vs NAND page error correction

| | SRAM SECDED (P26, and P51's current NAND path) | NAND page ECC (this project) |
|---|---|---|
| Error source | rare single-event upsets; errors are *independent and rare per word* | raw bit-error rate grows with P/E cycles, retention time and temperature, read disturb; tens of errors per KiB are normal late in life |
| Code | extended Hamming, d = 4 | binary BCH (d ≥ 2t+1, t = 4…40+) or LDPC (soft-decision, iterative) |
| Granularity | one 32/64/128-bit word | one 512 B–4 KiB codeword per sector, several codewords per page |
| Capability | correct 1, detect 2 per word | correct t per codeword; LDPC: no fixed radius, near-capacity with soft reads |
| Overhead | 7–8 bits per 32–64 bits (12.5–22 %) | 52–104 bits per 512 B here (1.3–2.5 %); 70 B per KiB for t = 40 |
| Erased state | n/a (memory always written) | erased cells read 1: an erased page must decode as "erased", including with a few 1→0 flips |
| Spare area | none | the page's OOB/spare area must hold parity + metadata + the bad-block marker: capacity must be budgeted |
| Decoder | combinational, 1 cycle | syndromes → key-equation solver → root search → correction: a multi-cycle pipeline |

P51's per-word SECDED on a NAND page corrects at most one error *per 32-bit word* and is defeated by two errors in
the same word; at a raw BER of 10⁻³ a 512-byte page carries ≈ 4 errors on average and ≈ 9 % of pages have two
errors in one 39-bit word (128 words × C(39,2)·10⁻⁶) — an uncorrectable page every ~11 reads, against SSD
targets of ~10⁻¹⁵ per bit.  It also spends 20 % of the raw page on check bits (640 B raw per 512 B user).  It is
replaced, not extended.

## 3. Gaps closed by Project 54

1. GF(2^m) arithmetic (reference and RTL), BCH code construction, encoder, syndrome/BM/Chien decoder — none existed.
2. A page format with OOB budgeting, multiple codewords per page, bad-block-marker protection, erased-page handling.
3. An independent integrity check (CRC-16) to catch decoder miscorrections.
4. A codec interface that admits LDPC with soft information; an LDPC proof of concept.
5. Fault injection against the NAND twin with measured outcomes.

## 4. Integration plan for P51 (not executed in this deliverable)

`sfs_nand_ctrl` streams page bytes between the NAND bus and the buffer SRAM and inserts one SECDED beat per word.
Replace the beat logic by `silicaflux_storage_ecc`: program path `buffer → wr_pay → wr_raw → NAND DQ`; read path
`NAND DQ (spare first, 05h-E0h) → rd_raw → rd_pay → buffer`, sector/page status into the completion `INFO0/1`
words, `ev_corrected / ev_uncorr / ev_integrity` into the P26 RAS event controller, the register window into the
channel's firmware page.  The FTL (`firmware/app/ftl.c`) must issue the spare-first read and act on
`UNCORRECTABLE` (read retry), `INTEGRITY_FAIL` (treat as uncorrectable) and the scrub hint (relocate).  This is a
firmware + controller change in P51 and is listed in docs/08.
