# Synthesis estimates — Yosys 0.33 (generic gates) and Yosys + nextpnr-ecp5 (LFE5U-85F)

Generic: 2-input gate library after ABC, memories kept as RAM (bits listed separately), flip-flops
excluding RAM.  Logic levels = Yosys `ltp` longest combinational path in gates.  ECP5: LUT4, CCU2C
carry, flip-flops, DP16KD 18 kbit block RAM, distributed RAM (DPR16X4), post-route Fmax of an
out-of-context place & route at a 100 MHz target (seed 1).  **Estimates, not sign-off.**

| Block (config) | generic gates | of which XOR/XNOR | FF | RAM bits | logic levels | ECP5 LUT4 | ECP5 FF | DP16KD | DPR16X4 | Fmax MHz |
|---|---|---|---|---|---|---|---|---|---|---|
| `syn_bch_enc_B255T4` | 364 | 228 | 81 | 0 | 22 | 448 | 81 | 0 | 0 | 127.7 |
| `syn_bch_dec_B255T4` | 3242 | 1638 | 397 | 512 | 16 | 2598 | 405 | 0 | 8 | 111.3 |
| `syn_bch_dec_B255T4_nb3` | 3259 | 1639 | 403 | 768 | 16 | 2640 | 411 | 0 | 12 | 106.6 |
| `syn_bch_enc_N512T4` | 303 | 153 | 126 | 0 | 11 | 348 | 126 | 0 | 0 | 146.3 |
| `syn_bch_dec_N512T4` | 7378 | 3808 | 574 | 8432 | 18 | 6625 | 603 | 1 | 0 | 93.5 |
| `syn_bch_enc_N512T8` | 533 | 275 | 229 | 0 | 9 | 961 | 229 | 0 | 0 | 133.1 |
| `syn_bch_dec_N512T8` | 13999 | 7823 | 997 | 8432 | 22 | 11486 | 1026 | 1 | 0 | 81.2 |
| `syn_ecc_N512T4` | 10069 | 4268 | 1268 | 8688 | 35 | 7886 | 1423 | 1 | 4 | 74.2 |
| `syn_ecc_N2KT8` | 17241 | 8498 | 1930 | 9456 | 36 | 13971 | 1975 | 1 | 16 | 78.1 |
| `syn_ldpc_enc` | 791 | 404 | 143 | 0 | 19 | 3496 | 143 | 0 | 0 | 44.3 |
| `syn_ldpc_dec` | 46993 | 5336 | 4266 | 0 | 183 | 25257 | 4266 | 0 | 0 | 9.1 |
| `syn_ecc_L24` | 50969 | 6205 | 5092 | 704 | 180 | 26948 | 5108 | 0 | 12 | 9.5 |
| `syn_bch_enc_N8KT40` | 2899 | 1721 | 1142 | 0 | 11 | 2973 | 1142 | 0 | 0 | 97.6 |
| `syn_bch_dec_N8KT40` | 84096 | 53248 | 4663 | 17856 | 55 | 55850 | 4693 | 2 | 0 | 19.6 ¹ |

¹ `syn_bch_dec_N8KT40`: routing did not converge: stopped after ~100 min with ~3 500 overused wires at 66 % LUT use (LFE5U-85F); the figure is nextpnr's pre-route (placement) estimate, not a routed result.
