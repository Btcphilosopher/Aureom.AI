# Regression — `scripts/run_regress.py`

**29 / 29 steps PASS.**  Tools: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, Python 3.13.18.

Rows marked *(resumed)* come from the first pass of this same run on the same frozen RTL: the run was interrupted once after the Icarus N512T8 step and resumed with `--resume` so that the remaining Icarus jobs could run in parallel (`scripts/run_regress.py --resume <log>`).

| Step | Simulator | What | Result | Time (s) | Detail |
|---|---|---|---|---|---|
| 1 | python | generated SV/doc files up to date | PASS | 0.1 | generated files up to date |
| 1 | python | vendored third-party files unmodified | PASS | 0.1 | 14/14 vendored files verified unmodified |
| 2 | python | reference model validation | PASS | 191.6 | 65/65 checks pass in 191.1 s (resumed) |
| 3 | python | LDPC reference validation | PASS | 32.6 | 7/7 checks pass in 32.2 s (resumed) |
| 4 | python | core vectors | PASS | 93.1 | B255T4: 38554 records {'CLEAN': 400, 'SINGLE': 255, 'MULTI': 400, 'EXACT_T': 800, 'T_PLUS_ | N512T4: 6037 records {'CLEAN': 120, 'SINGLE': 4212, 'MULTI': 120, 'EXACT_T': 240, 'T_PLUS_ | N512T8: 6073 records {'CLEAN': 120, 'SINGLE': 4216, 'MULTI': 120, 'EXACT_T': 240, 'T_PLUS_ | N8KT40: 600 records {'CLEAN': 12, 'SINGLE': 12, 'MULTI': 12, 'EXACT_T': 24, 'T_PLUS_1': 24 (resumed) |
| 4 | python | page vectors | PASS | 10.6 | N512T8: 60 pages {'CLEAN': 6, 'CORRECTABLE': 6, 'MIXED': 6, 'UNCORR': 6, 'ERASED': 6, 'ERA | N2KT8: 60 pages {'CLEAN': 6, 'CORRECTABLE': 6, 'MIXED': 6, 'UNCORR': 6, 'ERASED': 6, 'ERAS | N8KT40: 20 pages {'CLEAN': 2, 'CORRECTABLE': 2, 'MIXED': 2, 'UNCORR': 2, 'ERASED': 2, 'ERA | L24: 200 pages {'CLEAN': 20, 'CORRECTABLE': 20, 'MIXED': 20, 'UNCORR': 20, 'ERASED': 20, ' (resumed) |
| 4 | python | LDPC vectors | PASS | 5.4 | LDPC: 1646 records; soft codes Counter({1: 1267, 2: 180, 3: 128, 0: 71}); hard codes Count (resumed) |
| 5 | verilator | core BCH B255T4 NBANKS=2 bp=30% | PASS | 3.0 | tb_sfecc_bch cfg=B255T4 records=38554 checks=2360800 errors=0 -> PASS (resumed) |
| 5 | verilator | core BCH B255T4 NBANKS=3 bp=30% | PASS | 2.8 | tb_sfecc_bch cfg=B255T4 records=38554 checks=2360802 errors=0 -> PASS (resumed) |
| 5 | verilator | core BCH B255T4 NBANKS=2 bp=70% | PASS | 5.9 | tb_sfecc_bch cfg=B255T4 records=38554 checks=2360477 errors=0 -> PASS (resumed) |
| 5 | verilator | core BCH N512T4 NBANKS=2 bp=30% | PASS | 11.4 | tb_sfecc_bch cfg=N512T4 records=6037 checks=6478401 errors=0 -> PASS (resumed) |
| 5 | verilator | core BCH N512T8 NBANKS=2 bp=30% | PASS | 19.6 | tb_sfecc_bch cfg=N512T8 records=6073 checks=6478836 errors=0 -> PASS (resumed) |
| 5 | verilator | core BCH N8KT40 NBANKS=2 bp=30% | PASS | 34.1 | tb_sfecc_bch cfg=N8KT40 records=600 checks=1611442 errors=0 -> PASS (resumed) |
| 6 | verilator | page engine N512T4 | PASS | 0.2 | tb_sfecc_page cfg=N512T4 pages=60 checks=92086 errors=0 -> PASS (resumed) |
| 6 | verilator | page engine N512T8 | PASS | 0.4 | tb_sfecc_page cfg=N512T8 pages=60 checks=91576 errors=0 -> PASS (resumed) |
| 6 | verilator | page engine N2KT8 | PASS | 1.3 | tb_sfecc_page cfg=N2KT8 pages=60 checks=369562 errors=0 -> PASS (resumed) |
| 6 | verilator | page engine N8KT40 | PASS | 20.2 | tb_sfecc_page cfg=N8KT40 pages=20 checks=843227 errors=0 -> PASS (resumed) |
| 6 | verilator | page engine L24 (LDPC codec) | PASS | 0.4 | tb_sfecc_page cfg=L24 pages=200 checks=22251 errors=0 -> PASS (resumed) |
| 7 | verilator | LDPC PoC encoder + soft/hard decoders | PASS | 1.4 | tb_sfecc_ldpc records=1646 checks=55964 errors=0 -> PASS (resumed) |
| 8 | iverilog | tb_sfecc_bch B255T4 (all vectors) | PASS | 611.4 | tb_sfecc_bch cfg=B255T4 records=38554 checks=2360802 errors=0 -> PASS (resumed) |
| 8 | iverilog | tb_sfecc_bch N512T4 (all vectors) | PASS | 1561.8 | tb_sfecc_bch cfg=N512T4 records=6037 checks=6478345 errors=0 -> PASS (resumed) |
| 8 | iverilog | tb_sfecc_bch N512T8 (all vectors) | PASS | 2946.9 | tb_sfecc_bch cfg=N512T8 records=6073 checks=6478942 errors=0 -> PASS (resumed) |
| 8 | iverilog | tb_sfecc_bch N8KT40 (+MAXREC=120 +NRST=3) | PASS | 1697.9 | tb_sfecc_bch cfg=N8KT40 records=120 checks=445985 errors=0 -> PASS |
| 8 | iverilog | tb_sfecc_page N512T4 (all vectors) | PASS | 36.1 | tb_sfecc_page cfg=N512T4 pages=60 checks=92086 errors=0 -> PASS |
| 8 | iverilog | tb_sfecc_page N2KT8 (all vectors) | PASS | 227.5 | tb_sfecc_page cfg=N2KT8 pages=60 checks=369562 errors=0 -> PASS |
| 8 | iverilog | tb_sfecc_page L24 (all vectors) | PASS | 89.3 | tb_sfecc_page cfg=L24 pages=200 checks=22251 errors=0 -> PASS |
| 8 | iverilog | tb_sfecc_ldpc LDPC (all vectors) | PASS | 601.4 | tb_sfecc_ldpc records=1646 checks=55964 errors=0 -> PASS |
| 9 | verilator | NAND digital twin: directed + retention (RTL), statistical (Python) | PASS | 191.5 | N2KT8 directed: {'CLEAN/correct': 17, 'CORRECTED/correct': 10, 'ERASED/correct': 11, 'UNCORRECTABLE/detected': 2}; N512T4 directed: {'CLEAN/correct': 2, 'CORRECTED/correct': 3, 'ERASED/correct': 2, 'UNCORRECTABLE/detected': 3} |
| 10 | verilator | lint -Wall, 14 tops | PASS | 9.2 | syn_ldpc_dec               RTL warnings 0  wrapper warnings 6 |
