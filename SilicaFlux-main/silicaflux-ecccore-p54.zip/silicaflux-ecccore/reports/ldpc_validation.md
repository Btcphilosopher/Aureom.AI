# LDPC proof of concept — validation (`scripts/validate_ldpc.py`)

QC-LDPC(128,64), Z = 16, base matrix (shifts, -1 = zero block): `[[15, 1, 15, 3, 0, -1, -1, -1], [13, 4, 1, 4, 0, 0, -1, -1], [1, 7, 8, 10, -1, 0, 0, -1], [6, 9, 1, 0, -1, -1, 0, 0]]`, girth 6.

| Result | Check | Detail |
|---|---|---|
| PASS | dense H has GF(2) rank 64 (k = 64) | rank 64 |
| PASS | H c = 0 (dense product) for 500 random encodings | failures 0 |
| PASS | Tanner-graph girth >= 6 (BFS) | girth 6 |
| PASS | erased (all-ones) stored word is a codeword after the mask |  |
| PASS | sum-product == pyldpc flooding log-BP kernel on 300 noisy frames that need decoding (same LLRs, <= 30 iterations) | agree 300/300 |
| PASS | hard-decision OMS corrects every 1-bit error pattern | 128/128 |
| PASS | 3-read soft sensing never does worse than 1-read hard decisions (FER, each sigma) | 4/4 points |

## Hard-decision error patterns (fixed-point layered OMS, 20 iterations) — measured

| Errors | Patterns | Corrected |
|---|---|---|
| 1 | 128 | 128 (100.0 %) |
| 2 | 8128 | 8112 (99.8 %) |
| 3 | 300 | 300 (100.0 %) |
| 4 | 300 | 298 (99.3 %) |
| 5 | 300 | 291 (97.0 %) |
| 6 | 300 | 291 (97.0 %) |

## BI-AWGN, rate 1/2 — frame-error rate (sampled, small frame counts)

| Eb/N0 dB | frames | sum-product float | layered OMS 5-bit | OMS hard | avg it. OMS | avg it. BP |
|---|---|---|---|---|---|---|
| 1.0 | 600 | 0.4500 | 0.5100 | 0.9333 | 12.58 | 17.77 |
| 2.0 | 600 | 0.1083 | 0.1217 | 0.6700 | 5.29 | 8.26 |
| 3.0 | 600 | 0.0150 | 0.0183 | 0.3667 | 2.61 | 4.13 |
| 4.0 | 600 | 0.0017 | 0.0017 | 0.1367 | 1.56 | 2.51 |
| 5.0 | 600 | 0.0000 | 0.0000 | 0.0383 | 1.19 | 1.75 |

## NAND soft sensing (illustrative SLC threshold model) — FER

| sigma | raw BER | frames | 1 read (hard) | 3 reads (2-bit soft) |
|---|---|---|---|---|
| 0.4 | 0.0062 | 600 | 0.0000 | 0.0000 |
| 0.45 | 0.0136 | 600 | 0.0050 | 0.0000 |
| 0.5 | 0.0218 | 600 | 0.0050 | 0.0000 |
| 0.55 | 0.0347 | 600 | 0.0367 | 0.0000 |

Small code, small samples: these numbers characterise the proof of concept, not a NAND product.
