# Coverage

## 1. Code coverage — Verilator 5.020 line + toggle, merged over 8 instrumented runs

Runs: `core_B255T4`, `core_B255T4_nb3`, `core_N512T4`, `core_N512T8`, `page_N2KT8`, `page_N512T4`, `page_L24`, `ldpc`.

Line points inside elaboration-time constant functions (sfecc_gfc_mul, sfecc_gfc_apow, sfecc_gfc_prim_ok, gpoly_ok, mk_maskv, mk_par, odd_part, two_pow, shift_of, act_of) execute in the
compiler, never in simulation; their 210 points are excluded from the line columns.

| RTL file | line points hit | line % | toggle points hit | toggle % |
|---|---|---|---|---|
| `rtl/sfecc_bch_chien.sv` | 55/55 | 100.0 | 2338/2493 | 93.8 |
| `rtl/sfecc_bch_dec.sv` | 10/10 | 100.0 | 1898/1931 | 98.3 |
| `rtl/sfecc_bch_enc.sv` | 16/16 | 100.0 | 1025/1028 | 99.7 |
| `rtl/sfecc_bch_kes.sv` | 84/84 | 100.0 | 5779/6179 | 93.5 |
| `rtl/sfecc_bch_syn.sv` | 10/10 | 100.0 | 730/733 | 99.6 |
| `rtl/sfecc_codec_dec.sv` | 0/0 | 0.0 | 70/172 | 40.7 |
| `rtl/sfecc_codec_enc.sv` | 0/0 | 0.0 | 48/50 | 96.0 |
| `rtl/sfecc_crc16.svh` | 8/8 | 100.0 | 0/0 | 0.0 |
| `rtl/sfecc_gf_funcs.svh` | 32/50 | 64.0 | 0/0 | 0.0 |
| `rtl/sfecc_ldpc_dec.sv` | 96/102 | 94.1 | 1582/1698 | 93.2 |
| `rtl/sfecc_ldpc_enc.sv` | 16/16 | 100.0 | 446/448 | 99.6 |
| `rtl/sfecc_page_dec.sv` | 6/6 | 100.0 | 710/1036 | 68.5 |
| `rtl/sfecc_page_enc.sv` | 6/6 | 100.0 | 547/581 | 94.1 |
| `rtl/silicaflux_storage_ecc.sv` | 44/46 | 95.7 | 511/1232 | 41.5 |
| **total** | 383/409 | **93.6** | 15684/17581 | **89.2** |

Uncovered points (every one is listed; see the classification in docs/06_VERIFICATION.md §5):

<details><summary><code>rtl/sfecc_bch_chien.sv</code>: 155 points</summary>

```
toggle line 101 f_cnt[2] (u_chien)
toggle line 162 lanes_c[0] (u_chien)
toggle line 162 lanes_c[1] (u_chien)
toggle line 162 lanes_c[2] (u_chien)
toggle line 162 lanes_c[3] (u_chien)
toggle line 162 lanes_c[4] (u_chien)
toggle line 162 lanes_c[5] (u_chien)
toggle line 162 lanes_c[6] (u_chien)
toggle line 162 lanes_c[7] (u_chien)
toggle line 164 pad_c[0] (u_chien)
toggle line 164 pad_c[1] (u_chien)
toggle line 164 pad_c[2] (u_chien)
toggle line 164 pad_c[3] (u_chien)
toggle line 164 pad_c[4] (u_chien)
toggle line 164 pad_c[5] (u_chien)
toggle line 164 pad_c[6] (u_chien)
toggle line 164 pad_c[7] (u_chien)
toggle line 174 roots_sum[4] (u_chien)
toggle line 174 roots_sum[5] (u_chien)
toggle line 174 roots_sum[6] (u_chien)
toggle line 174 roots_sum[7] (u_chien)
toggle line 50 k_l[3] (u_chien)
toggle line 50 k_l[4] (u_chien)
toggle line 52 k_frame_err (u_chien)
toggle line 69 st_frame_err (u_chien)
toggle line 85 lq[3] (u_chien)
toggle line 85 lq[4] (u_chien)
toggle line 86 fail_early (u_chien)
toggle line 86 frame_q (u_chien)
toggle line 91 fin_fe (u_chien)
toggle line 91 fin_frame (u_chien)
toggle line 93 fin_lq[3] (u_chien)
toggle line 93 fin_lq[4] (u_chien)
toggle line 94 ndone[1] (u_chien)
toggle line 97 p1_pad[0] (u_chien)
toggle line 97 p1_pad[1] (u_chien)
toggle line 97 p1_pad[2] (u_chien)
toggle line 97 p1_pad[3] (u_chien)
toggle line 97 p1_pad[4] (u_chien)
toggle line 97 p1_pad[5] (u_chien)
toggle line 97 p1_pad[6] (u_chien)
toggle line 97 p1_pad[7] (u_chien)
toggle line 99 fifo[0][8] (u_chien)
toggle line 99 fifo[1][8] (u_chien)
toggle line 99 fifo[2][8] (u_chien)
```
</details>

<details><summary><code>rtl/sfecc_bch_dec.sv</code>: 33 points</summary>

```
toggle line 108 ferr_nx (u_dec)
toggle line 114 k_l[3] (u_dec)
toggle line 114 k_l[4] (u_dec)
toggle line 115 k_tag[1] (u_dec)
toggle line 49 st_frame_err (u_dec)
toggle line 86 b[5] (u_dec)
toggle line 90 ferr (u_dec)
toggle line 93 h_tag[1] (u_dec)
toggle line 99 mbyte[0] (u_dec)
toggle line 99 mbyte[1] (u_dec)
toggle line 99 mbyte[2] (u_dec)
toggle line 99 mbyte[3] (u_dec)
toggle line 99 mbyte[4] (u_dec)
toggle line 99 mbyte[5] (u_dec)
toggle line 99 mbyte[6] (u_dec)
toggle line 99 mbyte[7] (u_dec)
```
</details>

<details><summary><code>rtl/sfecc_bch_enc.sv</code>: 16 points</summary>

```
branch line 141 else (u_enc)
branch line 64 else (u_enc)
branch line 64 if (u_enc)
branch line 93 else (u_enc)
toggle line 112 cnt[5] (u_enc)
toggle line 43 frame_err (u_enc)
```
</details>

<details><summary><code>rtl/sfecc_bch_kes.sv</code>: 424 points</summary>

```
branch line 60 else (u_kes)
branch line 60 if (u_kes)
branch line 68 else (u_kes)
branch line 68 if (u_kes)
toggle line 120 bb[10] (u_kes)
toggle line 120 bb[11] (u_kes)
toggle line 120 bb[12] (u_kes)
toggle line 120 bb[1] (u_kes)
toggle line 120 bb[2] (u_kes)
toggle line 120 bb[3] (u_kes)
toggle line 120 bb[4] (u_kes)
toggle line 120 bb[5] (u_kes)
toggle line 120 bb[6] (u_kes)
toggle line 120 bb[7] (u_kes)
toggle line 120 bb[8] (u_kes)
toggle line 120 bb[9] (u_kes)
toggle line 123 L[3] (u_kes)
toggle line 123 L[4] (u_kes)
toggle line 125 tag[1] (u_kes)
toggle line 157 upd[32] (u_kes)
toggle line 157 upd[33] (u_kes)
toggle line 157 upd[34] (u_kes)
toggle line 157 upd[35] (u_kes)
toggle line 157 upd[36] (u_kes)
toggle line 157 upd[37] (u_kes)
toggle line 157 upd[38] (u_kes)
toggle line 157 upd[39] (u_kes)
toggle line 157 upd[40] (u_kes)
toggle line 157 upd[41] (u_kes)
toggle line 157 upd[42] (u_kes)
toggle line 157 upd[43] (u_kes)
toggle line 157 upd[44] (u_kes)
toggle line 157 upd[45] (u_kes)
toggle line 157 upd[46] (u_kes)
toggle line 157 upd[47] (u_kes)
toggle line 157 upd[88] (u_kes)
toggle line 157 upd[89] (u_kes)
toggle line 157 upd[90] (u_kes)
toggle line 157 upd[91] (u_kes)
toggle line 157 upd[92] (u_kes)
toggle line 157 upd[93] (u_kes)
toggle line 157 upd[94] (u_kes)
toggle line 157 upd[95] (u_kes)
toggle line 159 bb_n[0] (u_kes)
toggle line 159 bb_n[10] (u_kes)
toggle line 159 bb_n[11] (u_kes)
toggle line 159 bb_n[12] (u_kes)
toggle line 159 bb_n[1] (u_kes)
toggle line 159 bb_n[2] (u_kes)
toggle line 159 bb_n[3] (u_kes)
toggle line 159 bb_n[4] (u_kes)
toggle line 159 bb_n[5] (u_kes)
toggle line 159 bb_n[6] (u_kes)
toggle line 159 bb_n[7] (u_kes)
toggle line 159 bb_n[8] (u_kes)
toggle line 159 bb_n[9] (u_kes)
toggle line 161 sq_n[156] (u_kes)
toggle line 161 sq_n[157] (u_kes)
toggle line 161 sq_n[158] (u_kes)
toggle line 161 sq_n[159] (u_kes)
toggle line 161 sq_n[160] (u_kes)
toggle line 161 sq_n[161] (u_kes)
toggle line 161 sq_n[162] (u_kes)
toggle line 161 sq_n[163] (u_kes)
toggle line 161 sq_n[164] (u_kes)
toggle line 161 sq_n[165] (u_kes)
toggle line 161 sq_n[166] (u_kes)
toggle line 161 sq_n[167] (u_kes)
toggle line 161 sq_n[168] (u_kes)
toggle line 161 sq_n[169] (u_kes)
toggle line 161 sq_n[170] (u_kes)
toggle line 161 sq_n[171] (u_kes)
toggle line 161 sq_n[172] (u_kes)
toggle line 161 sq_n[173] (u_kes)
toggle line 161 sq_n[174] (u_kes)
toggle line 161 sq_n[175] (u_kes)
toggle line 161 sq_n[176] (u_kes)
toggle line 161 sq_n[177] (u_kes)
toggle line 161 sq_n[178] (u_kes)
toggle line 161 sq_n[179] (u_kes)
toggle line 161 sq_n[180] (u_kes)
toggle line 161 sq_n[181] (u_kes)
toggle line 161 sq_n[32] (u_kes)
toggle line 161 sq_n[33] (u_kes)
toggle line 161 sq_n[34] (u_kes)
toggle line 161 sq_n[35] (u_kes)
toggle line 161 sq_n[36] (u_kes)
toggle line 161 sq_n[37] (u_kes)
toggle line 161 sq_n[38] (u_kes)
toggle line 161 sq_n[39] (u_kes)
toggle line 161 sq_n[40] (u_kes)
toggle line 161 sq_n[41] (u_kes)
toggle line 161 sq_n[42] (u_kes)
toggle line 161 sq_n[43] (u_kes)
toggle line 161 sq_n[44] (u_kes)
toggle line 161 sq_n[45] (u_kes)
toggle line 161 sq_n[46] (u_kes)
toggle line 161 sq_n[47] (u_kes)
toggle line 161 sq_n[52] (u_kes)
toggle line 161 sq_n[53] (u_kes)
toggle line 161 sq_n[54] (u_kes)
toggle line 161 sq_n[55] (u_kes)
toggle line 161 sq_n[56] (u_kes)
toggle line 161 sq_n[57] (u_kes)
toggle line 161 sq_n[58] (u_kes)
toggle line 161 sq_n[59] (u_kes)
toggle line 161 sq_n[60] (u_kes)
toggle line 161 sq_n[61] (u_kes)
toggle line 161 sq_n[62] (u_kes)
toggle line 161 sq_n[63] (u_kes)
toggle line 161 sq_n[64] (u_kes)
toggle line 161 sq_n[65] (u_kes)
toggle line 161 sq_n[66] (u_kes)
toggle line 161 sq_n[67] (u_kes)
toggle line 161 sq_n[68] (u_kes)
toggle line 161 sq_n[69] (u_kes)
toggle line 161 sq_n[70] (u_kes)
toggle line 161 sq_n[71] (u_kes)
toggle line 161 sq_n[72] (u_kes)
toggle line 161 sq_n[73] (u_kes)
toggle line 161 sq_n[74] (u_kes)
toggle line 161 sq_n[75] (u_kes)
toggle line 161 sq_n[76] (u_kes)
toggle line 161 sq_n[77] (u_kes)
toggle line 40 in_tag[1] (u_kes)
toggle line 44 out_l[3] (u_kes)
toggle line 44 out_l[4] (u_kes)
toggle line 45 out_tag[1] (u_kes)
toggle line 94 sall[0] (u_kes)
toggle line 94 sall[10] (u_kes)
toggle line 94 sall[11] (u_kes)
toggle line 94 sall[12] (u_kes)
toggle line 94 sall[1] (u_kes)
toggle line 94 sall[2] (u_kes)
toggle line 94 sall[3] (u_kes)
toggle line 94 sall[4] (u_kes)
toggle line 94 sall[5] (u_kes)
toggle line 94 sall[6] (u_kes)
toggle line 94 sall[7] (u_kes)
toggle line 94 sall[8] (u_kes)
toggle line 94 sall[9] (u_kes)
```
</details>

<details><summary><code>rtl/sfecc_bch_syn.sv</code>: 3 points</summary>

```
toggle line 26 partial_i (u_syn)
```
</details>

<details><summary><code>rtl/sfecc_codec_dec.sv</code>: 102 points</summary>

```
toggle line 39 in_llr[0] (u_codec)
toggle line 39 in_llr[10] (u_codec)
toggle line 39 in_llr[11] (u_codec)
toggle line 39 in_llr[12] (u_codec)
toggle line 39 in_llr[13] (u_codec)
toggle line 39 in_llr[14] (u_codec)
toggle line 39 in_llr[15] (u_codec)
toggle line 39 in_llr[16] (u_codec)
toggle line 39 in_llr[17] (u_codec)
toggle line 39 in_llr[18] (u_codec)
toggle line 39 in_llr[19] (u_codec)
toggle line 39 in_llr[1] (u_codec)
toggle line 39 in_llr[20] (u_codec)
toggle line 39 in_llr[21] (u_codec)
toggle line 39 in_llr[22] (u_codec)
toggle line 39 in_llr[23] (u_codec)
toggle line 39 in_llr[24] (u_codec)
toggle line 39 in_llr[25] (u_codec)
toggle line 39 in_llr[26] (u_codec)
toggle line 39 in_llr[27] (u_codec)
toggle line 39 in_llr[28] (u_codec)
toggle line 39 in_llr[29] (u_codec)
toggle line 39 in_llr[2] (u_codec)
toggle line 39 in_llr[30] (u_codec)
toggle line 39 in_llr[31] (u_codec)
toggle line 39 in_llr[32] (u_codec)
toggle line 39 in_llr[33] (u_codec)
toggle line 39 in_llr[34] (u_codec)
toggle line 39 in_llr[35] (u_codec)
toggle line 39 in_llr[36] (u_codec)
toggle line 39 in_llr[37] (u_codec)
toggle line 39 in_llr[38] (u_codec)
toggle line 39 in_llr[39] (u_codec)
toggle line 39 in_llr[3] (u_codec)
toggle line 39 in_llr[4] (u_codec)
toggle line 39 in_llr[5] (u_codec)
toggle line 39 in_llr[6] (u_codec)
toggle line 39 in_llr[7] (u_codec)
toggle line 39 in_llr[8] (u_codec)
toggle line 39 in_llr[9] (u_codec)
toggle line 43 st_nerr[4] (u_codec)
toggle line 43 st_nerr[5] (u_codec)
toggle line 43 st_nerr[6] (u_codec)
toggle line 43 st_nerr[7] (u_codec)
toggle line 44 st_aux[0] (u_codec)
toggle line 44 st_aux[1] (u_codec)
toggle line 44 st_aux[2] (u_codec)
toggle line 44 st_aux[3] (u_codec)
toggle line 44 st_aux[4] (u_codec)
toggle line 44 st_aux[5] (u_codec)
toggle line 44 st_aux[6] (u_codec)
toggle line 44 st_aux[7] (u_codec)
toggle line 45 st_frame_err (u_codec)
```
</details>

<details><summary><code>rtl/sfecc_codec_enc.sv</code>: 2 points</summary>

```
toggle line 38 frame_err (u_codec)
```
</details>

<details><summary><code>rtl/sfecc_gf_funcs.svh</code>: 386 points</summary>

```
branch line 37 else (u_dec)
branch line 37 else (u_enc)
branch line 37 if (u_dec)
branch line 37 if (u_enc)
branch line 51 else (u_chien)
branch line 51 else (u_dec)
branch line 51 else (u_enc)
branch line 51 else (u_kes)
branch line 51 else (u_syn)
branch line 51 if (u_chien)
branch line 51 if (u_dec)
branch line 51 if (u_enc)
branch line 51 if (u_kes)
branch line 51 if (u_syn)
branch line 53 else (u_chien)
branch line 53 else (u_dec)
branch line 53 else (u_enc)
branch line 53 else (u_kes)
branch line 53 else (u_syn)
branch line 53 if (u_chien)
branch line 53 if (u_dec)
branch line 53 if (u_enc)
branch line 53 if (u_kes)
branch line 53 if (u_syn)
branch line 64 else (u_chien)
branch line 64 else (u_dec)
branch line 64 else (u_enc)
branch line 64 else (u_kes)
branch line 64 else (u_syn)
branch line 64 if (u_chien)
branch line 64 if (u_dec)
branch line 64 if (u_enc)
branch line 64 if (u_kes)
branch line 64 if (u_syn)
branch line 68 else (u_chien)
branch line 68 else (u_dec)
branch line 68 else (u_enc)
branch line 68 else (u_kes)
branch line 68 else (u_syn)
branch line 68 if (u_chien)
branch line 68 if (u_dec)
branch line 68 if (u_enc)
branch line 68 if (u_kes)
branch line 68 if (u_syn)
branch line 82 else (u_chien)
branch line 82 else (u_dec)
branch line 82 else (u_enc)
branch line 82 else (u_kes)
branch line 82 else (u_syn)
branch line 82 if (u_chien)
branch line 82 if (u_dec)
branch line 82 if (u_enc)
branch line 82 if (u_kes)
branch line 82 if (u_syn)
branch line 84 else (u_chien)
branch line 84 else (u_dec)
branch line 84 else (u_enc)
branch line 84 else (u_kes)
branch line 84 else (u_syn)
branch line 84 if (u_chien)
branch line 84 if (u_dec)
branch line 84 if (u_enc)
branch line 84 if (u_kes)
branch line 84 if (u_syn)
branch line 85 else (u_chien)
branch line 85 else (u_dec)
branch line 85 else (u_enc)
branch line 85 else (u_kes)
branch line 85 else (u_syn)
branch line 85 if (u_chien)
branch line 85 if (u_dec)
branch line 85 if (u_enc)
branch line 85 if (u_kes)
branch line 85 if (u_syn)
line line 30 block (u_dec)
line line 30 block (u_enc)
line line 36 block (u_dec)
line line 36 block (u_enc)
```
</details>

<details><summary><code>rtl/sfecc_ldpc_dec.sv</code>: 125 points</summary>

```
branch line 204 else (u_soft)
branch line 204 if (u_dec)
branch line 204 if (u_hard)
line line 80 elsif (u_dec)
line line 80 elsif (u_hard)
line line 80 elsif (u_soft)
line line 81 if (u_dec)
line line 81 if (u_hard)
line line 81 if (u_soft)
toggle line 37 in_llr[0] (u_dec)
toggle line 37 in_llr[0] (u_hard)
toggle line 37 in_llr[10] (u_dec)
toggle line 37 in_llr[10] (u_hard)
toggle line 37 in_llr[11] (u_dec)
toggle line 37 in_llr[11] (u_hard)
toggle line 37 in_llr[12] (u_dec)
toggle line 37 in_llr[12] (u_hard)
toggle line 37 in_llr[13] (u_dec)
toggle line 37 in_llr[13] (u_hard)
toggle line 37 in_llr[14] (u_dec)
toggle line 37 in_llr[14] (u_hard)
toggle line 37 in_llr[15] (u_dec)
toggle line 37 in_llr[15] (u_hard)
toggle line 37 in_llr[16] (u_dec)
toggle line 37 in_llr[16] (u_hard)
toggle line 37 in_llr[17] (u_dec)
toggle line 37 in_llr[17] (u_hard)
toggle line 37 in_llr[18] (u_dec)
toggle line 37 in_llr[18] (u_hard)
toggle line 37 in_llr[19] (u_dec)
toggle line 37 in_llr[19] (u_hard)
toggle line 37 in_llr[1] (u_dec)
toggle line 37 in_llr[1] (u_hard)
toggle line 37 in_llr[20] (u_dec)
toggle line 37 in_llr[20] (u_hard)
toggle line 37 in_llr[21] (u_dec)
toggle line 37 in_llr[21] (u_hard)
toggle line 37 in_llr[22] (u_dec)
toggle line 37 in_llr[22] (u_hard)
toggle line 37 in_llr[23] (u_dec)
toggle line 37 in_llr[23] (u_hard)
toggle line 37 in_llr[24] (u_dec)
toggle line 37 in_llr[24] (u_hard)
toggle line 37 in_llr[25] (u_dec)
toggle line 37 in_llr[25] (u_hard)
toggle line 37 in_llr[26] (u_dec)
toggle line 37 in_llr[26] (u_hard)
toggle line 37 in_llr[27] (u_dec)
toggle line 37 in_llr[27] (u_hard)
toggle line 37 in_llr[28] (u_dec)
toggle line 37 in_llr[28] (u_hard)
toggle line 37 in_llr[29] (u_dec)
toggle line 37 in_llr[29] (u_hard)
toggle line 37 in_llr[2] (u_dec)
toggle line 37 in_llr[2] (u_hard)
toggle line 37 in_llr[30] (u_dec)
toggle line 37 in_llr[30] (u_hard)
toggle line 37 in_llr[31] (u_dec)
toggle line 37 in_llr[31] (u_hard)
toggle line 37 in_llr[32] (u_dec)
toggle line 37 in_llr[32] (u_hard)
toggle line 37 in_llr[33] (u_dec)
toggle line 37 in_llr[33] (u_hard)
toggle line 37 in_llr[34] (u_dec)
toggle line 37 in_llr[34] (u_hard)
toggle line 37 in_llr[35] (u_dec)
toggle line 37 in_llr[35] (u_hard)
toggle line 37 in_llr[36] (u_dec)
toggle line 37 in_llr[36] (u_hard)
toggle line 37 in_llr[37] (u_dec)
toggle line 37 in_llr[37] (u_hard)
toggle line 37 in_llr[38] (u_dec)
toggle line 37 in_llr[38] (u_hard)
toggle line 37 in_llr[39] (u_dec)
toggle line 37 in_llr[39] (u_hard)
toggle line 37 in_llr[3] (u_dec)
toggle line 37 in_llr[3] (u_hard)
toggle line 37 in_llr[4] (u_dec)
toggle line 37 in_llr[4] (u_hard)
toggle line 37 in_llr[5] (u_dec)
toggle line 37 in_llr[5] (u_hard)
toggle line 37 in_llr[6] (u_dec)
toggle line 37 in_llr[6] (u_hard)
toggle line 37 in_llr[7] (u_dec)
toggle line 37 in_llr[7] (u_hard)
toggle line 37 in_llr[8] (u_dec)
toggle line 37 in_llr[8] (u_hard)
toggle line 37 in_llr[9] (u_dec)
toggle line 37 in_llr[9] (u_hard)
toggle line 45 st_nerr[4] (u_dec)
toggle line 45 st_nerr[4] (u_hard)
toggle line 45 st_nerr[5] (u_dec)
toggle line 45 st_nerr[5] (u_hard)
toggle line 45 st_nerr[5] (u_soft)
toggle line 45 st_nerr[6] (u_dec)
toggle line 45 st_nerr[6] (u_hard)
toggle line 45 st_nerr[6] (u_soft)
toggle line 45 st_nerr[7] (u_dec)
toggle line 45 st_nerr[7] (u_hard)
toggle line 45 st_nerr[7] (u_soft)
toggle line 46 st_aux[3] (u_dec)
toggle line 46 st_aux[5] (u_dec)
toggle line 46 st_aux[5] (u_hard)
toggle line 46 st_aux[5] (u_soft)
toggle line 46 st_aux[6] (u_dec)
toggle line 46 st_aux[6] (u_hard)
toggle line 46 st_aux[6] (u_soft)
toggle line 46 st_aux[7] (u_dec)
toggle line 46 st_aux[7] (u_hard)
toggle line 46 st_aux[7] (u_soft)
toggle line 47 st_frame_err (u_dec)
toggle line 47 st_frame_err (u_hard)
toggle line 47 st_frame_err (u_soft)
toggle line 68 it[5] (u_dec)
toggle line 68 it[5] (u_hard)
toggle line 68 it[5] (u_soft)
toggle line 68 it[6] (u_dec)
toggle line 68 it[6] (u_hard)
toggle line 68 it[6] (u_soft)
toggle line 68 it[7] (u_dec)
toggle line 68 it[7] (u_hard)
toggle line 68 it[7] (u_soft)
toggle line 69 ferr (u_dec)
toggle line 69 ferr (u_hard)
toggle line 69 ferr (u_soft)
```
</details>

<details><summary><code>rtl/sfecc_ldpc_enc.sv</code>: 5 points</summary>

```
branch line 53 if (u_enc)
branch line 81 else (u_enc)
toggle line 24 frame_err (u_enc)
```
</details>

<details><summary><code>rtl/sfecc_page_dec.sv</code>: 330 points</summary>

```
branch line 158 if (u_dec)
branch line 179 if (u_dec)
toggle line 116 cj[6] (u_dec)
toggle line 118 i_sec[2] (u_dec)
toggle line 119 kf[4] (u_dec)
toggle line 119 kf[5] (u_dec)
toggle line 119 kf[6] (u_dec)
toggle line 119 kf[7] (u_dec)
toggle line 119 kf[8] (u_dec)
toggle line 119 kf[9] (u_dec)
toggle line 126 in_ferr (u_dec)
toggle line 128 bq[0][8] (u_dec)
toggle line 128 bq[1][8] (u_dec)
toggle line 130 bq_cnt[1] (u_dec)
toggle line 200 c_sferr (u_dec)
toggle line 202 c_saux[0] (u_dec)
toggle line 202 c_saux[1] (u_dec)
toggle line 202 c_saux[2] (u_dec)
toggle line 202 c_saux[3] (u_dec)
toggle line 202 c_saux[4] (u_dec)
toggle line 202 c_saux[5] (u_dec)
toggle line 202 c_saux[6] (u_dec)
toggle line 202 c_saux[7] (u_dec)
toggle line 202 c_snerr[4] (u_dec)
toggle line 202 c_snerr[5] (u_dec)
toggle line 202 c_snerr[6] (u_dec)
toggle line 202 c_snerr[7] (u_dec)
toggle line 214 o_sec[2] (u_dec)
toggle line 219 cq_cnt[1] (u_dec)
toggle line 220 s_sec[2] (u_dec)
toggle line 222 a_corr[2] (u_dec)
toggle line 222 a_corr[3] (u_dec)
toggle line 222 a_corr[4] (u_dec)
toggle line 222 a_corr[5] (u_dec)
toggle line 222 a_corr[6] (u_dec)
toggle line 222 a_corr[7] (u_dec)
toggle line 222 a_erased[2] (u_dec)
toggle line 222 a_erased[3] (u_dec)
toggle line 222 a_erased[4] (u_dec)
toggle line 222 a_erased[5] (u_dec)
toggle line 222 a_erased[6] (u_dec)
toggle line 222 a_erased[7] (u_dec)
toggle line 222 a_integ[2] (u_dec)
toggle line 222 a_integ[3] (u_dec)
toggle line 222 a_integ[4] (u_dec)
toggle line 222 a_integ[5] (u_dec)
toggle line 222 a_integ[6] (u_dec)
toggle line 222 a_integ[7] (u_dec)
toggle line 222 a_max[4] (u_dec)
toggle line 222 a_max[5] (u_dec)
toggle line 222 a_max[6] (u_dec)
toggle line 222 a_max[7] (u_dec)
toggle line 222 a_uncorr[1] (u_dec)
toggle line 222 a_uncorr[2] (u_dec)
toggle line 222 a_uncorr[3] (u_dec)
toggle line 222 a_uncorr[4] (u_dec)
toggle line 222 a_uncorr[5] (u_dec)
toggle line 222 a_uncorr[6] (u_dec)
toggle line 222 a_uncorr[7] (u_dec)
toggle line 223 a_tot[10] (u_dec)
toggle line 223 a_tot[11] (u_dec)
toggle line 223 a_tot[12] (u_dec)
toggle line 223 a_tot[13] (u_dec)
toggle line 223 a_tot[14] (u_dec)
toggle line 223 a_tot[15] (u_dec)
toggle line 223 a_tot[5] (u_dec)
toggle line 223 a_tot[6] (u_dec)
toggle line 223 a_tot[7] (u_dec)
toggle line 223 a_tot[8] (u_dec)
toggle line 223 a_tot[9] (u_dec)
toggle line 227 o_um (u_dec)
toggle line 258 n_corr[3] (u_dec)
toggle line 258 n_corr[4] (u_dec)
toggle line 258 n_corr[5] (u_dec)
toggle line 258 n_corr[6] (u_dec)
toggle line 258 n_corr[7] (u_dec)
toggle line 259 n_unc[2] (u_dec)
toggle line 259 n_unc[3] (u_dec)
toggle line 259 n_unc[4] (u_dec)
toggle line 259 n_unc[5] (u_dec)
toggle line 259 n_unc[6] (u_dec)
toggle line 259 n_unc[7] (u_dec)
toggle line 260 n_int[3] (u_dec)
toggle line 260 n_int[4] (u_dec)
toggle line 260 n_int[5] (u_dec)
toggle line 260 n_int[6] (u_dec)
toggle line 260 n_int[7] (u_dec)
toggle line 261 n_era[3] (u_dec)
toggle line 261 n_era[4] (u_dec)
toggle line 261 n_era[5] (u_dec)
toggle line 261 n_era[6] (u_dec)
toggle line 261 n_era[7] (u_dec)
toggle line 262 n_max[4] (u_dec)
toggle line 262 n_max[5] (u_dec)
toggle line 262 n_max[6] (u_dec)
toggle line 262 n_max[7] (u_dec)
toggle line 263 n_tot[10] (u_dec)
toggle line 263 n_tot[11] (u_dec)
toggle line 263 n_tot[12] (u_dec)
toggle line 263 n_tot[13] (u_dec)
toggle line 263 n_tot[14] (u_dec)
toggle line 263 n_tot[15] (u_dec)
toggle line 263 n_tot[5] (u_dec)
toggle line 263 n_tot[6] (u_dec)
toggle line 263 n_tot[7] (u_dec)
toggle line 263 n_tot[8] (u_dec)
toggle line 263 n_tot[9] (u_dec)
toggle line 58 um_valid (u_dec)
toggle line 65 sst_nerr[4] (u_dec)
toggle line 65 sst_nerr[5] (u_dec)
toggle line 65 sst_nerr[6] (u_dec)
toggle line 65 sst_nerr[7] (u_dec)
toggle line 66 sst_aux[0] (u_dec)
toggle line 66 sst_aux[1] (u_dec)
toggle line 66 sst_aux[2] (u_dec)
toggle line 66 sst_aux[3] (u_dec)
toggle line 66 sst_aux[4] (u_dec)
toggle line 66 sst_aux[5] (u_dec)
toggle line 66 sst_aux[6] (u_dec)
toggle line 66 sst_aux[7] (u_dec)
toggle line 67 sst_sector[2] (u_dec)
toggle line 67 sst_sector[3] (u_dec)
toggle line 67 sst_sector[4] (u_dec)
toggle line 67 sst_sector[5] (u_dec)
toggle line 67 sst_sector[6] (u_dec)
toggle line 67 sst_sector[7] (u_dec)
toggle line 72 pst_n_corr[3] (u_dec)
toggle line 72 pst_n_corr[4] (u_dec)
toggle line 72 pst_n_corr[5] (u_dec)
toggle line 72 pst_n_corr[6] (u_dec)
toggle line 72 pst_n_corr[7] (u_dec)
toggle line 73 pst_n_uncorr[1] (u_dec)
toggle line 73 pst_n_uncorr[2] (u_dec)
toggle line 73 pst_n_uncorr[3] (u_dec)
toggle line 73 pst_n_uncorr[4] (u_dec)
toggle line 73 pst_n_uncorr[5] (u_dec)
toggle line 73 pst_n_uncorr[6] (u_dec)
toggle line 73 pst_n_uncorr[7] (u_dec)
toggle line 74 pst_n_integ[0] (u_dec)
toggle line 74 pst_n_integ[1] (u_dec)
toggle line 74 pst_n_integ[3] (u_dec)
toggle line 74 pst_n_integ[4] (u_dec)
toggle line 74 pst_n_integ[5] (u_dec)
toggle line 74 pst_n_integ[6] (u_dec)
toggle line 74 pst_n_integ[7] (u_dec)
toggle line 75 pst_n_erased[0] (u_dec)
toggle line 75 pst_n_erased[1] (u_dec)
toggle line 75 pst_n_erased[3] (u_dec)
toggle line 75 pst_n_erased[4] (u_dec)
toggle line 75 pst_n_erased[5] (u_dec)
toggle line 75 pst_n_erased[6] (u_dec)
toggle line 75 pst_n_erased[7] (u_dec)
toggle line 76 pst_max_flips[4] (u_dec)
toggle line 76 pst_max_flips[5] (u_dec)
toggle line 76 pst_max_flips[6] (u_dec)
toggle line 76 pst_max_flips[7] (u_dec)
toggle line 77 pst_tot_flips[10] (u_dec)
toggle line 77 pst_tot_flips[11] (u_dec)
toggle line 77 pst_tot_flips[12] (u_dec)
toggle line 77 pst_tot_flips[13] (u_dec)
toggle line 77 pst_tot_flips[14] (u_dec)
toggle line 77 pst_tot_flips[15] (u_dec)
toggle line 77 pst_tot_flips[5] (u_dec)
toggle line 77 pst_tot_flips[6] (u_dec)
toggle line 77 pst_tot_flips[7] (u_dec)
toggle line 77 pst_tot_flips[8] (u_dec)
toggle line 77 pst_tot_flips[9] (u_dec)
toggle line 82 pst_frame_err (u_dec)
toggle line 83 flip_thr[0] (u_dec)
toggle line 83 flip_thr[2] (u_dec)
toggle line 83 flip_thr[3] (u_dec)
toggle line 83 flip_thr[4] (u_dec)
toggle line 83 flip_thr[5] (u_dec)
toggle line 83 flip_thr[6] (u_dec)
toggle line 83 flip_thr[7] (u_dec)
```
</details>

<details><summary><code>rtl/sfecc_page_enc.sv</code>: 34 points</summary>

```
toggle line 124 c_ferr (u_enc)
toggle line 134 o_sec[2] (u_enc)
toggle line 138 sp_off[4] (u_enc)
toggle line 138 sp_off[5] (u_enc)
toggle line 138 sp_off[6] (u_enc)
toggle line 140 fifo[0][8] (u_enc)
toggle line 140 fifo[1][8] (u_enc)
toggle line 140 fifo[2][8] (u_enc)
toggle line 142 f_cnt[2] (u_enc)
toggle line 151 sbuf[0][0] (u_enc)
toggle line 151 sbuf[0][1] (u_enc)
toggle line 151 sbuf[0][2] (u_enc)
toggle line 151 sbuf[0][3] (u_enc)
toggle line 151 sbuf[0][4] (u_enc)
toggle line 151 sbuf[0][5] (u_enc)
toggle line 151 sbuf[0][6] (u_enc)
toggle line 151 sbuf[0][7] (u_enc)
toggle line 46 um_valid (u_enc)
toggle line 47 um_ready (u_enc)
toggle line 53 frame_err (u_enc)
toggle line 87 i_sec[2] (u_enc)
toggle line 88 p_cnt[11] (u_enc)
toggle line 88 p_cnt[9] (u_enc)
toggle line 91 src_um (u_enc)
```
</details>

<details><summary><code>rtl/silicaflux_storage_ecc.sv</code>: 723 points</summary>

```
line line 248 case (dut)
toggle line 100 rd_pst_n_integ[0] (dut)
toggle line 100 rd_pst_n_integ[1] (dut)
toggle line 100 rd_pst_n_integ[3] (dut)
toggle line 100 rd_pst_n_integ[4] (dut)
toggle line 100 rd_pst_n_integ[5] (dut)
toggle line 100 rd_pst_n_integ[6] (dut)
toggle line 100 rd_pst_n_integ[7] (dut)
toggle line 101 rd_pst_n_erased[0] (dut)
toggle line 101 rd_pst_n_erased[1] (dut)
toggle line 101 rd_pst_n_erased[3] (dut)
toggle line 101 rd_pst_n_erased[4] (dut)
toggle line 101 rd_pst_n_erased[5] (dut)
toggle line 101 rd_pst_n_erased[6] (dut)
toggle line 101 rd_pst_n_erased[7] (dut)
toggle line 102 rd_pst_max_flips[4] (dut)
toggle line 102 rd_pst_max_flips[5] (dut)
toggle line 102 rd_pst_max_flips[6] (dut)
toggle line 102 rd_pst_max_flips[7] (dut)
toggle line 103 rd_pst_tot_flips[10] (dut)
toggle line 103 rd_pst_tot_flips[11] (dut)
toggle line 103 rd_pst_tot_flips[12] (dut)
toggle line 103 rd_pst_tot_flips[13] (dut)
toggle line 103 rd_pst_tot_flips[14] (dut)
toggle line 103 rd_pst_tot_flips[15] (dut)
toggle line 103 rd_pst_tot_flips[5] (dut)
toggle line 103 rd_pst_tot_flips[6] (dut)
toggle line 103 rd_pst_tot_flips[7] (dut)
toggle line 103 rd_pst_tot_flips[8] (dut)
toggle line 103 rd_pst_tot_flips[9] (dut)
toggle line 108 rd_pst_frame_err (dut)
toggle line 122 flip_thr[0] (dut)
toggle line 122 flip_thr[2] (dut)
toggle line 122 flip_thr[3] (dut)
toggle line 122 flip_thr[4] (dut)
toggle line 122 flip_thr[5] (dut)
toggle line 122 flip_thr[6] (dut)
toggle line 122 flip_thr[7] (dut)
toggle line 124 c_bits[10] (dut)
toggle line 124 c_bits[11] (dut)
toggle line 124 c_bits[12] (dut)
toggle line 124 c_bits[13] (dut)
toggle line 124 c_bits[14] (dut)
toggle line 124 c_bits[15] (dut)
toggle line 124 c_bits[16] (dut)
toggle line 124 c_bits[17] (dut)
toggle line 124 c_bits[18] (dut)
toggle line 124 c_bits[19] (dut)
toggle line 124 c_bits[20] (dut)
toggle line 124 c_bits[21] (dut)
toggle line 124 c_bits[22] (dut)
toggle line 124 c_bits[23] (dut)
toggle line 124 c_bits[24] (dut)
toggle line 124 c_bits[25] (dut)
toggle line 124 c_bits[26] (dut)
toggle line 124 c_bits[27] (dut)
toggle line 124 c_bits[28] (dut)
toggle line 124 c_bits[29] (dut)
toggle line 124 c_bits[30] (dut)
toggle line 124 c_bits[31] (dut)
toggle line 124 c_bits[9] (dut)
toggle line 124 c_cw_corr[10] (dut)
toggle line 124 c_cw_corr[11] (dut)
toggle line 124 c_cw_corr[12] (dut)
toggle line 124 c_cw_corr[13] (dut)
toggle line 124 c_cw_corr[14] (dut)
toggle line 124 c_cw_corr[15] (dut)
toggle line 124 c_cw_corr[16] (dut)
toggle line 124 c_cw_corr[17] (dut)
toggle line 124 c_cw_corr[18] (dut)
toggle line 124 c_cw_corr[19] (dut)
toggle line 124 c_cw_corr[20] (dut)
toggle line 124 c_cw_corr[21] (dut)
toggle line 124 c_cw_corr[22] (dut)
toggle line 124 c_cw_corr[23] (dut)
toggle line 124 c_cw_corr[24] (dut)
toggle line 124 c_cw_corr[25] (dut)
toggle line 124 c_cw_corr[26] (dut)
toggle line 124 c_cw_corr[27] (dut)
toggle line 124 c_cw_corr[28] (dut)
toggle line 124 c_cw_corr[29] (dut)
toggle line 124 c_cw_corr[30] (dut)
toggle line 124 c_cw_corr[31] (dut)
toggle line 124 c_cw_corr[6] (dut)
toggle line 124 c_cw_corr[7] (dut)
toggle line 124 c_cw_corr[8] (dut)
toggle line 124 c_cw_corr[9] (dut)
toggle line 124 c_cw_dec[10] (dut)
toggle line 124 c_cw_dec[11] (dut)
toggle line 124 c_cw_dec[12] (dut)
toggle line 124 c_cw_dec[13] (dut)
toggle line 124 c_cw_dec[14] (dut)
toggle line 124 c_cw_dec[15] (dut)
toggle line 124 c_cw_dec[16] (dut)
toggle line 124 c_cw_dec[17] (dut)
toggle line 124 c_cw_dec[18] (dut)
toggle line 124 c_cw_dec[19] (dut)
toggle line 124 c_cw_dec[20] (dut)
toggle line 124 c_cw_dec[21] (dut)
toggle line 124 c_cw_dec[22] (dut)
toggle line 124 c_cw_dec[23] (dut)
toggle line 124 c_cw_dec[24] (dut)
toggle line 124 c_cw_dec[25] (dut)
toggle line 124 c_cw_dec[26] (dut)
toggle line 124 c_cw_dec[27] (dut)
toggle line 124 c_cw_dec[28] (dut)
toggle line 124 c_cw_dec[29] (dut)
toggle line 124 c_cw_dec[30] (dut)
toggle line 124 c_cw_dec[31] (dut)
toggle line 124 c_cw_dec[8] (dut)
toggle line 124 c_cw_dec[9] (dut)
toggle line 124 c_cw_era[10] (dut)
toggle line 124 c_cw_era[11] (dut)
toggle line 124 c_cw_era[12] (dut)
toggle line 124 c_cw_era[13] (dut)
toggle line 124 c_cw_era[14] (dut)
toggle line 124 c_cw_era[15] (dut)
toggle line 124 c_cw_era[16] (dut)
toggle line 124 c_cw_era[17] (dut)
toggle line 124 c_cw_era[18] (dut)
toggle line 124 c_cw_era[19] (dut)
toggle line 124 c_cw_era[20] (dut)
toggle line 124 c_cw_era[21] (dut)
toggle line 124 c_cw_era[22] (dut)
toggle line 124 c_cw_era[23] (dut)
toggle line 124 c_cw_era[24] (dut)
toggle line 124 c_cw_era[25] (dut)
toggle line 124 c_cw_era[26] (dut)
toggle line 124 c_cw_era[27] (dut)
toggle line 124 c_cw_era[28] (dut)
toggle line 124 c_cw_era[29] (dut)
toggle line 124 c_cw_era[30] (dut)
toggle line 124 c_cw_era[31] (dut)
toggle line 124 c_cw_era[6] (dut)
toggle line 124 c_cw_era[7] (dut)
toggle line 124 c_cw_era[8] (dut)
toggle line 124 c_cw_era[9] (dut)
toggle line 124 c_cw_int[10] (dut)
toggle line 124 c_cw_int[11] (dut)
toggle line 124 c_cw_int[12] (dut)
toggle line 124 c_cw_int[13] (dut)
toggle line 124 c_cw_int[14] (dut)
toggle line 124 c_cw_int[15] (dut)
toggle line 124 c_cw_int[16] (dut)
toggle line 124 c_cw_int[17] (dut)
toggle line 124 c_cw_int[18] (dut)
toggle line 124 c_cw_int[19] (dut)
toggle line 124 c_cw_int[20] (dut)
toggle line 124 c_cw_int[21] (dut)
toggle line 124 c_cw_int[22] (dut)
toggle line 124 c_cw_int[23] (dut)
toggle line 124 c_cw_int[24] (dut)
toggle line 124 c_cw_int[25] (dut)
toggle line 124 c_cw_int[26] (dut)
toggle line 124 c_cw_int[27] (dut)
toggle line 124 c_cw_int[28] (dut)
toggle line 124 c_cw_int[29] (dut)
toggle line 124 c_cw_int[30] (dut)
toggle line 124 c_cw_int[31] (dut)
toggle line 124 c_cw_int[6] (dut)
toggle line 124 c_cw_int[7] (dut)
toggle line 124 c_cw_int[8] (dut)
toggle line 124 c_cw_int[9] (dut)
toggle line 124 c_cw_unc[10] (dut)
toggle line 124 c_cw_unc[11] (dut)
toggle line 124 c_cw_unc[12] (dut)
toggle line 124 c_cw_unc[13] (dut)
toggle line 124 c_cw_unc[14] (dut)
toggle line 124 c_cw_unc[15] (dut)
toggle line 124 c_cw_unc[16] (dut)
toggle line 124 c_cw_unc[17] (dut)
toggle line 124 c_cw_unc[18] (dut)
toggle line 124 c_cw_unc[19] (dut)
toggle line 124 c_cw_unc[20] (dut)
toggle line 124 c_cw_unc[21] (dut)
toggle line 124 c_cw_unc[22] (dut)
toggle line 124 c_cw_unc[23] (dut)
toggle line 124 c_cw_unc[24] (dut)
toggle line 124 c_cw_unc[25] (dut)
toggle line 124 c_cw_unc[26] (dut)
toggle line 124 c_cw_unc[27] (dut)
toggle line 124 c_cw_unc[28] (dut)
toggle line 124 c_cw_unc[29] (dut)
toggle line 124 c_cw_unc[30] (dut)
toggle line 124 c_cw_unc[31] (dut)
toggle line 124 c_cw_unc[4] (dut)
toggle line 124 c_cw_unc[5] (dut)
toggle line 124 c_cw_unc[6] (dut)
toggle line 124 c_cw_unc[7] (dut)
toggle line 124 c_cw_unc[8] (dut)
toggle line 124 c_cw_unc[9] (dut)
toggle line 124 c_pg_dec[10] (dut)
toggle line 124 c_pg_dec[11] (dut)
toggle line 124 c_pg_dec[12] (dut)
toggle line 124 c_pg_dec[13] (dut)
toggle line 124 c_pg_dec[14] (dut)
toggle line 124 c_pg_dec[15] (dut)
toggle line 124 c_pg_dec[16] (dut)
toggle line 124 c_pg_dec[17] (dut)
toggle line 124 c_pg_dec[18] (dut)
toggle line 124 c_pg_dec[19] (dut)
toggle line 124 c_pg_dec[20] (dut)
toggle line 124 c_pg_dec[21] (dut)
toggle line 124 c_pg_dec[22] (dut)
toggle line 124 c_pg_dec[23] (dut)
toggle line 124 c_pg_dec[24] (dut)
toggle line 124 c_pg_dec[25] (dut)
toggle line 124 c_pg_dec[26] (dut)
toggle line 124 c_pg_dec[27] (dut)
toggle line 124 c_pg_dec[28] (dut)
toggle line 124 c_pg_dec[29] (dut)
toggle line 124 c_pg_dec[30] (dut)
toggle line 124 c_pg_dec[31] (dut)
toggle line 124 c_pg_dec[6] (dut)
toggle line 124 c_pg_dec[7] (dut)
toggle line 124 c_pg_dec[8] (dut)
toggle line 124 c_pg_dec[9] (dut)
toggle line 124 c_pg_enc[10] (dut)
toggle line 124 c_pg_enc[11] (dut)
toggle line 124 c_pg_enc[12] (dut)
toggle line 124 c_pg_enc[13] (dut)
toggle line 124 c_pg_enc[14] (dut)
toggle line 124 c_pg_enc[15] (dut)
toggle line 124 c_pg_enc[16] (dut)
toggle line 124 c_pg_enc[17] (dut)
toggle line 124 c_pg_enc[18] (dut)
toggle line 124 c_pg_enc[19] (dut)
toggle line 124 c_pg_enc[20] (dut)
toggle line 124 c_pg_enc[21] (dut)
toggle line 124 c_pg_enc[22] (dut)
toggle line 124 c_pg_enc[23] (dut)
toggle line 124 c_pg_enc[24] (dut)
toggle line 124 c_pg_enc[25] (dut)
toggle line 124 c_pg_enc[26] (dut)
toggle line 124 c_pg_enc[27] (dut)
toggle line 124 c_pg_enc[28] (dut)
toggle line 124 c_pg_enc[29] (dut)
toggle line 124 c_pg_enc[30] (dut)
toggle line 124 c_pg_enc[31] (dut)
toggle line 124 c_pg_enc[6] (dut)
toggle line 124 c_pg_enc[7] (dut)
toggle line 124 c_pg_enc[8] (dut)
toggle line 124 c_pg_enc[9] (dut)
toggle line 124 c_pg_scrub[10] (dut)
toggle line 124 c_pg_scrub[11] (dut)
toggle line 124 c_pg_scrub[12] (dut)
toggle line 124 c_pg_scrub[13] (dut)
toggle line 124 c_pg_scrub[14] (dut)
toggle line 124 c_pg_scrub[15] (dut)
toggle line 124 c_pg_scrub[16] (dut)
toggle line 124 c_pg_scrub[17] (dut)
toggle line 124 c_pg_scrub[18] (dut)
toggle line 124 c_pg_scrub[19] (dut)
toggle line 124 c_pg_scrub[20] (dut)
toggle line 124 c_pg_scrub[21] (dut)
toggle line 124 c_pg_scrub[22] (dut)
toggle line 124 c_pg_scrub[23] (dut)
toggle line 124 c_pg_scrub[24] (dut)
toggle line 124 c_pg_scrub[25] (dut)
toggle line 124 c_pg_scrub[26] (dut)
toggle line 124 c_pg_scrub[27] (dut)
toggle line 124 c_pg_scrub[28] (dut)
toggle line 124 c_pg_scrub[29] (dut)
toggle line 124 c_pg_scrub[30] (dut)
toggle line 124 c_pg_scrub[31] (dut)
toggle line 124 c_pg_scrub[5] (dut)
toggle line 124 c_pg_scrub[6] (dut)
toggle line 124 c_pg_scrub[7] (dut)
toggle line 124 c_pg_scrub[8] (dut)
toggle line 124 c_pg_scrub[9] (dut)
toggle line 125 last_fail[17] (dut)
toggle line 125 last_fail[18] (dut)
toggle line 125 last_fail[19] (dut)
toggle line 125 last_fail[20] (dut)
toggle line 125 last_fail[21] (dut)
toggle line 125 last_fail[22] (dut)
toggle line 125 last_fail[23] (dut)
toggle line 125 last_fail[24] (dut)
toggle line 125 last_fail[25] (dut)
toggle line 125 last_fail[26] (dut)
toggle line 125 last_fail[27] (dut)
toggle line 125 last_fail[28] (dut)
toggle line 125 last_fail[29] (dut)
toggle line 125 last_fail[2] (dut)
toggle line 125 last_fail[30] (dut)
toggle line 125 last_fail[31] (dut)
toggle line 125 last_fail[3] (dut)
toggle line 125 last_fail[4] (dut)
toggle line 125 last_fail[5] (dut)
toggle line 125 last_fail[6] (dut)
toggle line 125 last_fail[7] (dut)
toggle line 126 max_flips[4] (dut)
toggle line 126 max_flips[5] (dut)
toggle line 126 max_flips[6] (dut)
toggle line 126 max_flips[7] (dut)
toggle line 132 enc_ferr (dut)
toggle line 166 s_nerr[4] (dut)
toggle line 166 s_nerr[5] (dut)
toggle line 166 s_nerr[6] (dut)
toggle line 166 s_nerr[7] (dut)
toggle line 166 s_sec[2] (dut)
toggle line 166 s_sec[3] (dut)
toggle line 166 s_sec[4] (dut)
toggle line 166 s_sec[5] (dut)
toggle line 166 s_sec[6] (dut)
toggle line 166 s_sec[7] (dut)
toggle line 225 unused_rb (dut)
toggle line 62 rb_addr[0] (dut)
toggle line 62 rb_addr[1] (dut)
toggle line 62 rb_addr[7] (dut)
toggle line 63 rb_wdata[10] (dut)
toggle line 63 rb_wdata[11] (dut)
toggle line 63 rb_wdata[12] (dut)
toggle line 63 rb_wdata[13] (dut)
toggle line 63 rb_wdata[14] (dut)
toggle line 63 rb_wdata[15] (dut)
toggle line 63 rb_wdata[16] (dut)
toggle line 63 rb_wdata[18] (dut)
toggle line 63 rb_wdata[19] (dut)
toggle line 63 rb_wdata[1] (dut)
toggle line 63 rb_wdata[20] (dut)
toggle line 63 rb_wdata[21] (dut)
toggle line 63 rb_wdata[22] (dut)
toggle line 63 rb_wdata[23] (dut)
toggle line 63 rb_wdata[24] (dut)
toggle line 63 rb_wdata[25] (dut)
toggle line 63 rb_wdata[26] (dut)
toggle line 63 rb_wdata[27] (dut)
toggle line 63 rb_wdata[28] (dut)
toggle line 63 rb_wdata[29] (dut)
toggle line 63 rb_wdata[2] (dut)
toggle line 63 rb_wdata[30] (dut)
toggle line 63 rb_wdata[31] (dut)
toggle line 63 rb_wdata[3] (dut)
toggle line 63 rb_wdata[4] (dut)
toggle line 63 rb_wdata[5] (dut)
toggle line 63 rb_wdata[6] (dut)
toggle line 63 rb_wdata[7] (dut)
toggle line 63 rb_wdata[9] (dut)
toggle line 64 rb_rdata[12] (dut)
toggle line 64 rb_rdata[13] (dut)
toggle line 64 rb_rdata[20] (dut)
toggle line 64 rb_rdata[21] (dut)
toggle line 64 rb_rdata[23] (dut)
toggle line 64 rb_rdata[26] (dut)
toggle line 64 rb_rdata[27] (dut)
toggle line 64 rb_rdata[29] (dut)
toggle line 64 rb_rdata[31] (dut)
toggle line 70 wr_um_valid (dut)
toggle line 71 wr_um_ready (dut)
toggle line 86 rd_um_valid (dut)
toggle line 92 rd_sst_nerr[4] (dut)
toggle line 92 rd_sst_nerr[5] (dut)
toggle line 92 rd_sst_nerr[6] (dut)
toggle line 92 rd_sst_nerr[7] (dut)
toggle line 93 rd_sst_aux[0] (dut)
toggle line 93 rd_sst_aux[1] (dut)
toggle line 93 rd_sst_aux[2] (dut)
toggle line 93 rd_sst_aux[3] (dut)
toggle line 93 rd_sst_aux[4] (dut)
toggle line 93 rd_sst_aux[5] (dut)
toggle line 93 rd_sst_aux[6] (dut)
toggle line 93 rd_sst_aux[7] (dut)
toggle line 94 rd_sst_sector[2] (dut)
toggle line 94 rd_sst_sector[3] (dut)
toggle line 94 rd_sst_sector[4] (dut)
toggle line 94 rd_sst_sector[5] (dut)
toggle line 94 rd_sst_sector[6] (dut)
toggle line 94 rd_sst_sector[7] (dut)
toggle line 98 rd_pst_n_corr[3] (dut)
toggle line 98 rd_pst_n_corr[4] (dut)
toggle line 98 rd_pst_n_corr[5] (dut)
toggle line 98 rd_pst_n_corr[6] (dut)
toggle line 98 rd_pst_n_corr[7] (dut)
toggle line 99 rd_pst_n_uncorr[1] (dut)
toggle line 99 rd_pst_n_uncorr[2] (dut)
toggle line 99 rd_pst_n_uncorr[3] (dut)
toggle line 99 rd_pst_n_uncorr[4] (dut)
toggle line 99 rd_pst_n_uncorr[5] (dut)
toggle line 99 rd_pst_n_uncorr[6] (dut)
toggle line 99 rd_pst_n_uncorr[7] (dut)
```
</details>

## 2. Functional coverage (core testbench, MAIN phase)

### B255T4 — 38554 records, truth: correct 35932, detected 2445, miscorrected (undetected by BCH) 177

| error category | CLEAN | CORRECTED | ERASED | UNCORR | miscorrected | correct |
|---|---|---|---|---|---|---|
| CLEAN | 400 | 0 | 0 | 0 | 0 | 400 |
| SINGLE | 0 | 255 | 0 | 0 | 0 | 255 |
| MULTI | 0 | 400 | 0 | 0 | 0 | 400 |
| EXACT_T | 0 | 800 | 0 | 0 | 0 | 800 |
| T_PLUS_1 | 0 | 30 | 0 | 770 | 30 | 0 |
| BEYOND | 0 | 40 | 0 | 760 | 40 | 0 |
| BURST | 0 | 354 | 0 | 446 | 92 | 262 |
| ERASED | 0 | 0 | 50 | 0 | 0 | 50 |
| ERASED_FLIP | 0 | 0 | 400 | 0 | 0 | 400 |
| ERASED_BEYOND | 0 | 7 | 0 | 193 | 7 | 0 |
| BOUNDARY | 1 | 27 | 0 | 0 | 0 | 28 |
| PATTERN | 5 | 20 | 5 | 6 | 0 | 30 |
| EXH_DOUBLE | 0 | 32385 | 0 | 0 | 0 | 32385 |
| RANDOM_RBER | 164 | 766 | 0 | 270 | 8 | 922 |

| errors in codeword | correct | detected | miscorrected |
|---|---|---|---|
| 0 | 621 | 0 | 0 |
| 1 | 610 | 0 | 0 |
| 2 | 33034 | 0 | 0 |
| 3 | 542 | 0 | 0 |
| 4 | 1125 | 0 | 0 |
| 5 | 0 | 1034 | 37 |
| 6 | 0 | 345 | 11 |
| 7 | 0 | 315 | 12 |
| 8 | 0 | 226 | 11 |
| 9 | 0 | 257 | 4 |
| 10 | 0 | 141 | 98 |
| 11 | 0 | 123 | 4 |
| 12 | 0 | 3 | 0 |
| 13 | 0 | 1 | 0 |

Corrected-bit count reported (0..t): 0: 3066, 1: 610, 2: 33034, 3: 543, 4: 1301

### N512T4 — 6037 records, truth: correct 5271, detected 765, miscorrected (undetected by BCH) 1

| error category | CLEAN | CORRECTED | ERASED | UNCORR | miscorrected | correct |
|---|---|---|---|---|---|---|
| CLEAN | 120 | 0 | 0 | 0 | 0 | 120 |
| SINGLE | 0 | 4212 | 0 | 0 | 0 | 4212 |
| MULTI | 0 | 120 | 0 | 0 | 0 | 120 |
| EXACT_T | 0 | 240 | 0 | 0 | 0 | 240 |
| T_PLUS_1 | 0 | 0 | 0 | 240 | 0 | 0 |
| BEYOND | 0 | 1 | 0 | 239 | 1 | 0 |
| BURST | 0 | 80 | 0 | 160 | 0 | 80 |
| ERASED | 0 | 0 | 15 | 0 | 0 | 15 |
| ERASED_FLIP | 0 | 0 | 120 | 0 | 0 | 120 |
| ERASED_BEYOND | 0 | 0 | 0 | 60 | 0 | 0 |
| BOUNDARY | 4 | 30 | 0 | 0 | 0 | 34 |
| PATTERN | 5 | 20 | 5 | 6 | 0 | 30 |
| RANDOM_RBER | 71 | 229 | 0 | 60 | 0 | 300 |

| errors in codeword | correct | detected | miscorrected |
|---|---|---|---|
| 0 | 216 | 0 | 0 |
| 1 | 4340 | 0 | 0 |
| 2 | 193 | 0 | 0 |
| 3 | 174 | 0 | 0 |
| 4 | 348 | 0 | 0 |
| 5 | 0 | 311 | 0 |
| 6 | 0 | 99 | 0 |
| 7 | 0 | 112 | 0 |
| 8 | 0 | 68 | 0 |
| 9 | 0 | 67 | 1 |
| 10 | 0 | 67 | 0 |
| 11 | 0 | 41 | 0 |

Corrected-bit count reported (0..t): 0: 981, 1: 4340, 2: 193, 3: 174, 4: 349

### N512T8 — 6073 records, truth: correct 5324, detected 749, miscorrected (undetected by BCH) 0

| error category | CLEAN | CORRECTED | ERASED | UNCORR | miscorrected | correct |
|---|---|---|---|---|---|---|
| CLEAN | 120 | 0 | 0 | 0 | 0 | 120 |
| SINGLE | 0 | 4216 | 0 | 0 | 0 | 4216 |
| MULTI | 0 | 120 | 0 | 0 | 0 | 120 |
| EXACT_T | 0 | 240 | 0 | 0 | 0 | 240 |
| T_PLUS_1 | 0 | 0 | 0 | 240 | 0 | 0 |
| BEYOND | 0 | 0 | 0 | 240 | 0 | 0 |
| BURST | 0 | 99 | 0 | 141 | 0 | 99 |
| ERASED | 0 | 0 | 15 | 0 | 0 | 15 |
| ERASED_FLIP | 0 | 0 | 120 | 0 | 0 | 120 |
| ERASED_BEYOND | 0 | 0 | 0 | 60 | 0 | 0 |
| BOUNDARY | 0 | 42 | 0 | 0 | 0 | 42 |
| PATTERN | 5 | 40 | 9 | 6 | 0 | 54 |
| RANDOM_RBER | 13 | 285 | 0 | 62 | 0 | 298 |

| errors in codeword | correct | detected | miscorrected |
|---|---|---|---|
| 0 | 154 | 0 | 0 |
| 1 | 4294 | 0 | 0 |
| 2 | 112 | 0 | 0 |
| 3 | 97 | 0 | 0 |
| 4 | 96 | 0 | 0 |
| 5 | 97 | 0 | 0 |
| 6 | 93 | 0 | 0 |
| 7 | 87 | 0 | 0 |
| 8 | 294 | 0 | 0 |
| 9 | 0 | 295 | 0 |
| 10 | 0 | 66 | 0 |
| 11 | 0 | 73 | 0 |
| 12 | 0 | 54 | 0 |
| 13 | 0 | 45 | 0 |
| 14 | 0 | 40 | 0 |
| 15 | 0 | 37 | 0 |
| 16 | 0 | 44 | 0 |
| 17 | 0 | 44 | 0 |
| 18 | 0 | 35 | 0 |
| 19 | 0 | 16 | 0 |

Corrected-bit count reported (0..t): 0: 903, 1: 4294, 2: 112, 3: 97, 4: 96, 5: 97, 6: 93, 7: 87, 8: 294

### N8KT40 — 600 records, truth: correct 520, detected 80, miscorrected (undetected by BCH) 0

| error category | CLEAN | CORRECTED | ERASED | UNCORR | miscorrected | correct |
|---|---|---|---|---|---|---|
| CLEAN | 12 | 0 | 0 | 0 | 0 | 12 |
| SINGLE | 0 | 12 | 0 | 0 | 0 | 12 |
| MULTI | 0 | 12 | 0 | 0 | 0 | 12 |
| EXACT_T | 0 | 24 | 0 | 0 | 0 | 24 |
| T_PLUS_1 | 0 | 0 | 0 | 24 | 0 | 0 |
| BEYOND | 0 | 0 | 0 | 24 | 0 | 0 |
| BURST | 0 | 7 | 0 | 17 | 0 | 7 |
| ERASED | 0 | 0 | 4 | 0 | 0 | 4 |
| ERASED_FLIP | 0 | 0 | 12 | 0 | 0 | 12 |
| ERASED_BEYOND | 0 | 0 | 0 | 6 | 0 | 0 |
| BOUNDARY | 0 | 170 | 0 | 0 | 0 | 170 |
| PATTERN | 5 | 200 | 41 | 6 | 0 | 246 |
| RANDOM_RBER | 0 | 21 | 0 | 3 | 0 | 21 |

| errors in codeword | correct | detected | miscorrected |
|---|---|---|---|
| 0 | 22 | 0 | 0 |
| 1 | 32 | 0 | 0 |
| 2 | 12 | 0 | 0 |
| 3 | 11 | 0 | 0 |
| 4 | 10 | 0 | 0 |
| 5 | 11 | 0 | 0 |
| 6 | 10 | 0 | 0 |
| 7 | 12 | 0 | 0 |
| 8 | 10 | 0 | 0 |
| 9 | 11 | 0 | 0 |
| 10 | 40 | 0 | 0 |
| 11 | 14 | 0 | 0 |
| 12 | 10 | 0 | 0 |
| 13 | 10 | 0 | 0 |
| 14 | 10 | 0 | 0 |
| 15 | 10 | 0 | 0 |
| 16 | 10 | 0 | 0 |
| 17 | 10 | 0 | 0 |
| 18 | 11 | 0 | 0 |
| 19 | 11 | 0 | 0 |
| 20 | 10 | 0 | 0 |
| 21 | 10 | 0 | 0 |
| 22 | 11 | 0 | 0 |
| 23 | 10 | 0 | 0 |
| 24 | 11 | 0 | 0 |
| 25 | 9 | 0 | 0 |
| 26 | 9 | 0 | 0 |
| 27 | 10 | 0 | 0 |
| 28 | 14 | 0 | 0 |
| 29 | 13 | 0 | 0 |
| 30 | 9 | 0 | 0 |
| 31 | 9 | 0 | 0 |
| 32 | 9 | 0 | 0 |
| 33 | 11 | 0 | 0 |
| 34 | 13 | 0 | 0 |
| 35 | 10 | 0 | 0 |
| 36 | 11 | 0 | 0 |
| 37 | 11 | 0 | 0 |
| 38 | 10 | 0 | 0 |
| 39 | 10 | 0 | 0 |
| 40 | 33 | 0 | 0 |
| 41 | 0 | 35 | 0 |
| 42 | 0 | 2 | 0 |
| 43 | 0 | 3 | 0 |
| 44 | 0 | 1 | 0 |
| 45 | 0 | 3 | 0 |
| 46 | 0 | 2 | 0 |
| 47 | 0 | 4 | 0 |
| 48 | 0 | 2 | 0 |
| 51 | 0 | 3 | 0 |
| 53 | 0 | 2 | 0 |
| 54 | 0 | 2 | 0 |
| 55 | 0 | 3 | 0 |
| 56 | 0 | 1 | 0 |
| 57 | 0 | 2 | 0 |
| 59 | 0 | 1 | 0 |
| 61 | 0 | 1 | 0 |
| 62 | 0 | 1 | 0 |
| 63+ | 0 | 12 | 0 |

Corrected-bit count reported (0..t): 0: 102, 1: 32, 2: 12, 3: 11, 4: 10, 5: 11, 6: 10, 7: 12, 8: 10, 9: 11, 10: 40, 11: 14, 12: 10, 13: 10, 14: 10, 15: 10, 16: 10, 17: 10, 18: 11, 19: 11, 20: 10, 21: 10, 22: 11, 23: 10, 24: 11, 25: 9, 26: 9, 27: 10, 28: 14, 29: 13, 30: 9, 31: 9, 32: 9, 33: 11, 34: 13, 35: 10, 36: 11, 37: 11, 38: 10, 39: 10, 40: 33

## 3. Page-level sector outcomes

| config | pages | CLEAN | CORRECTED | ERASED | UNCORR | INTEGRITY |
|---|---|---|---|---|---|---|
| N512T4 | 60 | 11 | 29 | 15 | 13 | 18 |
| N2KT8 | 60 | 69 | 91 | 71 | 47 | 72 |
| N8KT40 | 20 | 73 | 98 | 81 | 53 | 80 |
| L24 | 200 | 179 | 363 | 182 | 1 | 184 |
