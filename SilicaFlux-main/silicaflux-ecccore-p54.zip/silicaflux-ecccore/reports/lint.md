# Lint — Verilator 5.020 `--lint-only -Wall`

Every synthesis wrapper (one per block and configuration) elaborated with all RTL. Intentional
exceptions are waived in the source with `verilator lint_off` comments and a reason.

| Top | RTL warnings | wrapper-only warnings |
|---|---|---|
| `syn_ecc_N2KT8` | 0 | 6 |
| `syn_ecc_N512T4` | 0 | 6 |
| `syn_ecc_L24` | 0 | 6 |
| `syn_bch_enc_B255T4` | 0 | 6 |
| `syn_bch_dec_B255T4` | 0 | 6 |
| `syn_bch_dec_B255T4_nb3` | 0 | 6 |
| `syn_bch_enc_N512T4` | 0 | 6 |
| `syn_bch_dec_N512T4` | 0 | 6 |
| `syn_bch_enc_N512T8` | 0 | 6 |
| `syn_bch_dec_N512T8` | 0 | 6 |
| `syn_bch_enc_N8KT40` | 0 | 6 |
| `syn_bch_dec_N8KT40` | 0 | 6 |
| `syn_ldpc_enc` | 0 | 6 |
| `syn_ldpc_dec` | 0 | 6 |

**Total RTL warnings: 0.**  Wrapper warnings are unused outputs/ports of the
thin synthesis shells (`synth/sfecc_synth_tops.sv`).
