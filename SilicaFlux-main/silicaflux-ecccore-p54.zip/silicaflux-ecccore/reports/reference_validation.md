# Reference-model validation (`scripts/validate_ref.py`)

**65 / 65 checks pass** (191.1 s).

| Result | Check | Detail |
|---|---|---|
| PASS | GF(2^3) p=0xb: primitive, table==poly multiply (64 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^4) p=0x13: primitive, table==poly multiply (256 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^5) p=0x25: primitive, table==poly multiply (1024 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^6) p=0x43: primitive, table==poly multiply (4096 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^7) p=0x83: primitive, table==poly multiply (16384 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^8) p=0x11d: primitive, table==poly multiply (65536 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^9) p=0x211: primitive, table==poly multiply (262144 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^10) p=0x409: primitive, table==poly multiply (1048576 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^11) p=0x805: primitive, table==poly multiply (200000 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^12) p=0x1053: primitive, table==poly multiply (200000 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^13) p=0x201b: primitive, table==poly multiply (200000 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^14) p=0x402b: primitive, table==poly multiply (200000 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^15) p=0x8003: primitive, table==poly multiply (200000 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | GF(2^16) p=0x1002d: primitive, table==poly multiply (200000 pairs), inverses | mult mismatches 0, inverse mismatches 0 |
| PASS | BCH(255,247) t=1 generator == Lin&Costello octal 435 | got 435 k=247 |
| PASS | BCH(255,239) t=2 generator == Lin&Costello octal 267543 | got 267543 k=239 |
| PASS | BCH(255,231) t=3 generator == Lin&Costello octal 156720665 | got 156720665 k=231 |
| PASS | BCH(255,223) t=4 generator == Lin&Costello octal 75626641375 | got 75626641375 k=223 |
| PASS | BCH(255,215) t=5 generator == Lin&Costello octal 23157564726421 | got 23157564726421 k=215 |
| PASS | BCH(255,207) t=6 generator == Lin&Costello octal 16176560567636227 | got 16176560567636227 k=207 |
| PASS | BCH(255,199) t=7 generator == Lin&Costello octal 7633031270420722341 | got 7633031270420722341 k=199 |
| PASS | BCH(255,191) t=8 generator == Lin&Costello octal 2663470176115333714567 | got 2663470176115333714567 k=191 |
| PASS | B255T4: BM(inversion) == simplified iBM (hardware) on 3000 syndrome sets | mismatches 0 |
| PASS | B255T4: 2t-step iBM == t-step simplified iBM; all odd-step discrepancies zero | locator mismatches 0, non-zero odd discrepancies 0 |
| PASS | B255T4: Sugiyama Euclid == iBM whenever L <= t | mismatches 0 |
| PASS | N512T8: BM(inversion) == simplified iBM (hardware) on 600 syndrome sets | mismatches 0 |
| PASS | N512T8: 2t-step iBM == t-step simplified iBM; all odd-step discrepancies zero | locator mismatches 0, non-zero odd discrepancies 0 |
| PASS | N512T8: Sugiyama Euclid == iBM whenever L <= t | mismatches 0 |
| PASS | N8KT40: BM(inversion) == simplified iBM (hardware) on 120 syndrome sets | mismatches 0 |
| PASS | N8KT40: 2t-step iBM == t-step simplified iBM; all odd-step discrepancies zero | locator mismatches 0, non-zero odd discrepancies 0 |
| PASS | N8KT40: Sugiyama Euclid == iBM whenever L <= t | mismatches 0 |
| PASS | B255T4: all 255 single-bit errors corrected | failures 0 |
| PASS | B255T4: all 32385 double-bit errors corrected | failures 0 |
| PASS | B255T4: encode(all-ones) == all-ones stored codeword (ECC mask); erased+<=t flips -> ERASED | bad flip cases 0 |
| PASS | N512T4: encode(all-ones) == all-ones stored codeword (ECC mask); erased+<=t flips -> ERASED | bad flip cases 0 |
| PASS | N512T8: encode(all-ones) == all-ones stored codeword (ECC mask); erased+<=t flips -> ERASED | bad flip cases 0 |
| PASS | N8KT40: encode(all-ones) == all-ones stored codeword (ECC mask); erased+<=t flips -> ERASED | bad flip cases 0 |
| PASS | CRC-16/CCITT-FALSE('123456789') == 0x29B1 (catalogue check value) |  |
| PASS | N512T4: CRC of an all-0xFF sector (0x85f8) != 0xFFFF, so a written all-FF sector is distinguishable from an erased one |  |
| PASS | N512T8: CRC of an all-0xFF sector (0x6995) != 0xFFFF, so a written all-FF sector is distinguishable from an erased one |  |
| PASS | N2KT8: CRC of an all-0xFF sector (0x6995) != 0xFFFF, so a written all-FF sector is distinguishable from an erased one |  |
| PASS | N8KT40: CRC of an all-0xFF sector (0xeaea) != 0xFFFF, so a written all-FF sector is distinguishable from an erased one |  |
| PASS | L24: CRC of an all-0xFF sector (0x99cf) != 0xFFFF, so a written all-FF sector is distinguishable from an erased one |  |
| PASS | BCH(255,223) shortened to 216 data bits (m=8, t=4, 27 B): 1000 parities == Linux lib/bch.c | mismatches 0 |
| PASS | BCH(255,223) shortened to 216 data bits: 1000 decodes (0..t+3 errors) == Linux lib/bch.c (status, error locations) | location mismatches 0, status disagreements 0 |
| PASS | N512T4 geometry (m=13, t=4, 520 B): 1000 parities == Linux lib/bch.c | mismatches 0 |
| PASS | N512T4 geometry: 1000 decodes (0..t+3 errors) == Linux lib/bch.c (status, error locations) | location mismatches 0, status disagreements 0 |
| PASS | N512T8 geometry (m=13, t=8, 514 B): 1000 parities == Linux lib/bch.c | mismatches 0 |
| PASS | N512T8 geometry: 1000 decodes (0..t+3 errors) == Linux lib/bch.c (status, error locations) | location mismatches 0, status disagreements 0 |
| PASS | N8KT40 geometry (m=14, t=40, 1046 B): 1000 parities == Linux lib/bch.c | mismatches 0 |
| PASS | N8KT40 geometry: 1000 decodes (0..t+3 errors) == Linux lib/bch.c (status, error locations) | location mismatches 0, status disagreements 0 |
| PASS | m14 t24 1 KiB (m=14, t=24, 1024 B): 1000 parities == Linux lib/bch.c | mismatches 0 |
| PASS | m14 t24 1 KiB: 1000 decodes (0..t+3 errors) == Linux lib/bch.c (status, error locations) | location mismatches 0, status disagreements 0 |
| PASS | B255T4: generator polynomial == galois | deg 32 |
| PASS | B255T4: 400 parities == galois | mismatches 0 |
| PASS | B255T4: 400 decodes (0..t+3 errors) == galois (status, message, error count) | data/count mismatches 0, success/failure disagreements 0, 8.3s |
| PASS | N512T4: generator polynomial == galois | deg 52 |
| PASS | N512T4: 400 parities == galois | mismatches 0 |
| PASS | N512T4: 400 decodes (0..t+3 errors) == galois (status, message, error count) | data/count mismatches 0, success/failure disagreements 0, 17.1s |
| PASS | N512T8: generator polynomial == galois | deg 104 |
| PASS | N512T8: 400 parities == galois | mismatches 0 |
| PASS | N512T8: 400 decodes (0..t+3 errors) == galois (status, message, error count) | data/count mismatches 0, success/failure disagreements 0, 13.2s |
| PASS | N8KT40: generator polynomial == galois | deg 560 |
| PASS | N8KT40: 40 parities == galois | mismatches 0 |
| PASS | N8KT40: 40 decodes (0..t+3 errors) == galois (status, message, error count) | data/count mismatches 0, success/failure disagreements 0, 16.3s |
