# Mutation check — `scripts/run_mutants.py`

Each mutant is one deliberate RTL bug; the named testbench (every vector of the configuration) must fail.

| Mutant | File | Bug | Testbench / config | Result |
|---|---|---|---|---|
| M1 | `rtl/sfecc_bch_kes.sv` | Berlekamp-Massey length-change condition 2L <= r written as 2L < r | core / B255T4 | KILLED (78731 errors) |
| M2 | `rtl/sfecc_bch_chien.sv` | Chien search accepts roots in the leading padding bit (LPAD) | core / B255T4 | KILLED (872 errors) |
| M3 | `rtl/sfecc_bch_dec.sv` | erased-page MASK not removed on the syndrome path | core / N512T4 | KILLED (20191 errors) |
| M4 | `rtl/sfecc_bch_syn.sv` | partial last parity byte (TPAD) processed as a full byte | core / N512T4 | KILLED (20473 errors) |
| M5 | `rtl/sfecc_bch_chien.sv` | decoder failure check 'roots == L' removed (only L > t detected) | core / N512T8 | KILLED (1498 errors) |
| M6 | `rtl/sfecc_bch_enc.sv` | encoder includes the LPAD padding bit in the division | core / B255T4 | KILLED (650 errors) |
| M7 | `rtl/sfecc_page_dec.sv` | page decoder ignores the CRC-16 verdict (miscorrections reported as success) | page / N2KT8 | KILLED (87 errors) |
| M8 | `rtl/sfecc_bch_kes.sv` | inversionless BM: gamma not updated on a length change | core / N512T8 | KILLED (7276 errors) |
| M9 | `rtl/sfecc_bch_dec.sv` | SYN stage overwrites the KES hand-off register (needs 3 codewords in flight: NBANKS = 3, 80 % output back-pressure) | core3 / B255T4 | SURVIVED — equivalent mutant (see below) |

**8 / 9 mutants killed.**

## Survivor analysis

**M9 is an equivalent mutant** for NBANKS ≤ 3.  The guard `!(is_last && h_valid)` stops the syndrome stage
from completing a codeword while the SYN→KES hand-off slot is still full.  That slot is full only while the KES
holds a finished locator that the Chien stage has not yet accepted, i.e. while the Chien stage is busy with an
older codeword in another bank.  The Chien stage releases that bank in the same cycle it accepts the waiting
locator, which frees the KES one cycle later.  A further codeword therefore always finds the slot empty long
before its last byte (≥ CW_BYTES cycles later).  The guard is kept as defensive logic for deeper buffer
configurations; with the supported NBANKS = 2…3 no input sequence can make it fire, so no test can kill the
mutant.  (M5, M6 and M8 survived a first run that used only the first 3 000 vectors of each file — the files are
sorted by error category — and are killed on the full vector sets, as shown above.)
