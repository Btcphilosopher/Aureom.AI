// =============================================================================
// SilicaFlux ECCCore (Project 54) :: synthesis / lint wrappers, one per measured block
// and configuration (parameter sets from rtl/generated/sfecc_cfg.svh).
// =============================================================================
`include "sfecc_cfg.svh"
`default_nettype none

`define SFECC_ENC_TOP(NAME, P) \
module NAME (input wire clk, rst_n, input wire in_valid, output wire in_ready, input wire [7:0] in_data, \
             input wire in_last, output wire out_valid, input wire out_ready, output wire [7:0] out_data, \
             output wire out_last, output wire frame_err); \
  sfecc_bch_enc #(P) u (.clk, .rst_n, .in_valid, .in_ready, .in_data, .in_last, .out_valid, .out_ready, \
                        .out_data, .out_last, .frame_err); \
endmodule

`define SFECC_DEC_TOP(NAME, P, NB) \
module NAME (input wire clk, rst_n, input wire in_valid, output wire in_ready, input wire [7:0] in_data, \
             input wire in_last, output wire out_valid, input wire out_ready, output wire [7:0] out_data, \
             output wire out_last, output wire st_valid, input wire st_ready, output wire [1:0] st_code, \
             output wire [7:0] st_nerr, output wire st_frame_err, output wire busy); \
  wire [7:0] nerr_w; \
  sfecc_codec_dec #(.CODEC(0), P, .NBANKS(NB)) u (.clk, .rst_n, .in_valid, .in_ready, .in_data, .in_last, \
    .in_llr(40'd0), .out_valid, .out_ready, .out_data, .out_last, .st_valid, .st_ready, .st_code, \
    .st_nerr(nerr_w), .st_aux(), .st_frame_err, .busy); \
  assign st_nerr = nerr_w; \
endmodule

`SFECC_ENC_TOP(syn_bch_enc_B255T4, `SFECC_ENC_B255T4)
`SFECC_DEC_TOP(syn_bch_dec_B255T4, `SFECC_DEC_B255T4, 2)
`SFECC_DEC_TOP(syn_bch_dec_B255T4_nb3, `SFECC_DEC_B255T4, 3)
`SFECC_ENC_TOP(syn_bch_enc_N512T4, `SFECC_ENC_N512T4)
`SFECC_DEC_TOP(syn_bch_dec_N512T4, `SFECC_DEC_N512T4, 2)
`SFECC_ENC_TOP(syn_bch_enc_N512T8, `SFECC_ENC_N512T8)
`SFECC_DEC_TOP(syn_bch_dec_N512T8, `SFECC_DEC_N512T8, 2)
`SFECC_ENC_TOP(syn_bch_enc_N8KT40, `SFECC_ENC_N8KT40)
`SFECC_DEC_TOP(syn_bch_dec_N8KT40, `SFECC_DEC_N8KT40, 2)

// LDPC proof of concept (soft input)
module syn_ldpc_dec (input wire clk, rst_n, input wire in_valid, output wire in_ready, input wire [7:0] in_data,
                     input wire in_last, input wire [39:0] in_llr, output wire out_valid, input wire out_ready,
                     output wire [7:0] out_data, output wire out_last, output wire st_valid, input wire st_ready,
                     output wire [1:0] st_code, output wire [7:0] st_nerr, output wire [7:0] st_aux,
                     output wire st_frame_err, output wire busy);
  sfecc_ldpc_dec #(.LLR_W(5), .SOFT_EN(1)) u (.clk, .rst_n, .in_valid, .in_ready, .in_data, .in_last, .in_llr,
    .out_valid, .out_ready, .out_data, .out_last, .st_valid, .st_ready, .st_code, .st_nerr, .st_aux,
    .st_frame_err, .busy);
endmodule
module syn_ldpc_enc (input wire clk, rst_n, input wire in_valid, output wire in_ready, input wire [7:0] in_data,
                     input wire in_last, output wire out_valid, input wire out_ready, output wire [7:0] out_data,
                     output wire out_last, output wire frame_err);
  sfecc_ldpc_enc u (.clk, .rst_n, .in_valid, .in_ready, .in_data, .in_last, .out_valid, .out_ready, .out_data,
                    .out_last, .frame_err);
endmodule

// full primary RTL (page engine + registers)
`define SFECC_TOP(NAME, P) \
module NAME (input wire clk, rst_n, input wire rb_sel, rb_we, input wire [7:0] rb_addr, input wire [31:0] rb_wdata, \
  output wire [31:0] rb_rdata, input wire wpv, output wire wpr, input wire [7:0] wpd, input wire wpl, input wire wuv, \
  output wire wur, input wire [7:0] wud, output wire wrv, input wire wrr, output wire [7:0] wrd, output wire wrl, \
  input wire rrv, output wire rrr, input wire [7:0] rrd, input wire rrl, output wire rpv, input wire rpr, \
  output wire [7:0] rpd, output wire rpl, output wire ruv, input wire rur, output wire [7:0] rud, output wire ssv, \
  input wire ssr, output wire [2:0] ssc, output wire [7:0] ssn, output wire [7:0] ssa, output wire [7:0] sss, \
  output wire ssk, output wire psv, input wire psr, output wire [7:0] p0, p1, p2, p3, p4, output wire [15:0] p5, \
  output wire p6, output wire [7:0] p7, output wire p8, p9, p10, output wire e0, e1, e2, e3, irq, eb, db); \
  silicaflux_storage_ecc #(P) u (.clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, \
    .wr_pay_valid(wpv), .wr_pay_ready(wpr), .wr_pay_data(wpd), .wr_pay_last(wpl), .wr_um_valid(wuv), \
    .wr_um_ready(wur), .wr_um_data(wud), .wr_raw_valid(wrv), .wr_raw_ready(wrr), .wr_raw_data(wrd), \
    .wr_raw_last(wrl), .rd_raw_valid(rrv), .rd_raw_ready(rrr), .rd_raw_data(rrd), .rd_raw_last(rrl), \
    .rd_pay_valid(rpv), .rd_pay_ready(rpr), .rd_pay_data(rpd), .rd_pay_last(rpl), .rd_um_valid(ruv), \
    .rd_um_ready(rur), .rd_um_data(rud), .rd_sst_valid(ssv), .rd_sst_ready(ssr), .rd_sst_code(ssc), \
    .rd_sst_nerr(ssn), .rd_sst_aux(ssa), .rd_sst_sector(sss), .rd_sst_crc_ok(ssk), .rd_pst_valid(psv), \
    .rd_pst_ready(psr), .rd_pst_n_corr(p0), .rd_pst_n_uncorr(p1), .rd_pst_n_integ(p2), .rd_pst_n_erased(p3), \
    .rd_pst_max_flips(p4), .rd_pst_tot_flips(p5), .rd_pst_all_erased(p6), .rd_pst_bbm(p7), .rd_pst_ok(p8), \
    .rd_pst_scrub(p9), .rd_pst_frame_err(p10), .ev_corrected(e0), .ev_uncorr(e1), .ev_integrity(e2), \
    .ev_scrub(e3), .irq, .enc_busy(eb), .dec_busy(db)); \
endmodule

`SFECC_TOP(syn_ecc_N512T4, `SFECC_PAGE_N512T4)
`SFECC_TOP(syn_ecc_N2KT8, `SFECC_PAGE_N2KT8)
`SFECC_TOP(syn_ecc_L24, `SFECC_PAGE_L24)

`default_nettype wire
