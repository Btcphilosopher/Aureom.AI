// =============================================================================
// SilicaFlux ECCCore (Project 54) :: tb_sfecc_nand_twin -- ECC engine against the
// NANDLab digital twin (Project 52 pin-level NAND model, vendored unmodified)
//
//   payload --> silicaflux_storage_ecc (page encoder) --> raw page --> BFM PROGRAM --> NAND model
//   NAND model --> BFM READ (spare first: 00h-30h at column PAGE_DATA, then 05h-E0h to column 0)
//              --> silicaflux_storage_ecc (page decoder) --> payload + sector/page status
// Faults come from the twin itself: directed stuck bits (svcfg 'stuck_bit', applied at
// read time), erased (never programmed) pages, and -- in later runs on the same
// persistent store -- the twin's retention / disturb physics after an unpowered bake
// (+NANDLAB_BAKE_HOURS).  The testbench records every raw page read and every decoder
// result; scripts/nand_twin_campaign.py re-decodes each raw page with the reference
// model (bit-exact check) and classifies the outcome against the programmed truth.
//
// Plusargs: +NANDLAB_DIR=<store dir> +JOBS=<memh> +PAY=<memh> +DUMP=<file>
//           +PHASE=0 program+read | 1 program only | 2 read only
// =============================================================================
`timescale 1ns/1ps
`include "sfecc_defs.svh"
`include "sfecc_cfg.svh"
`include "tbn_cfg.svh"
`default_nettype none

module tb_sfecc_nand_twin;
  `include "tb_common.svh"
  localparam integer DATA  = `TBN_DATA;
  localparam integer SPARE = `TBN_SPARE;
  localparam integer S     = `TBN_SECTORS;
  localparam integer RAW   = DATA + SPARE;
  localparam integer NJ    = `TBN_NJOBS;

  reg clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;                       // 100 MHz ECC clock

  // ------------------------------------------------------------------ NAND twin + controller BFM
  wire       ce_n, cle, ale, we_n, re_n, wp_n, rb_n, dq_oe;
  wire [7:0] dq_c2n, dq_n2c;
  reg        vcc_ok = 1'b0;
  nand_flash_model #(.PAGE_DATA_BYTES(DATA), .PAGE_SPARE_BYTES(SPARE), .PAGES_PER_BLOCK(`TBN_PPB),
                     .BLOCKS_PER_PLANE(`TBN_BPP), .PLANES_PER_LUN(`TBN_PLANES), .LUNS(1), .TARGET_ID(0)) u_nand (
    .ce_n, .cle, .ale, .we_n, .re_n, .wp_n, .dq_in(dq_c2n), .dq_out(dq_n2c), .dq_oe, .rb_n, .vcc_ok);
  nand_ctrl_bfm #(.PAGE_BYTES(RAW), .RP_BITS(`TBN_RP_BITS), .RB_BITS(`TBN_RB_BITS)) u_bfm (
    .ce_n, .cle, .ale, .we_n, .re_n, .wp_n, .dq_out(dq_c2n), .dq_in(dq_n2c), .rb_n);

  // ------------------------------------------------------------------ ECC engine
  reg         wp_v = 1'b0, rr_v = 1'b0;
  reg  [7:0]  wp_d = 8'h00, rr_d = 8'h00;
  reg         wp_l = 1'b0, rr_l = 1'b0;
  wire        wp_r, wu_r, wr_v, wr_l, rr_r, rp_v, rp_l, ru_v, ss_v, ps_v;
  wire [7:0]  wr_d, rp_d, ru_d, ss_nerr, ss_aux, ss_sec, pn_corr, pn_unc, pn_int, pn_era, p_max, p_bbm;
  wire [2:0]  ss_code;
  wire [15:0] p_tot;
  wire        ss_crc, p_alle, p_ok, p_scrub, p_ferr, ev_c, ev_u, ev_i, ev_s, irq, ebusy, dbusy;
  wire [31:0] rb_rdata;
  silicaflux_storage_ecc #(`TBN_P) u_ecc (
    .clk, .rst_n, .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(8'h00), .rb_wdata(32'h0), .rb_rdata,
    .wr_pay_valid(wp_v), .wr_pay_ready(wp_r), .wr_pay_data(wp_d), .wr_pay_last(wp_l),
    .wr_um_valid(1'b1), .wr_um_ready(wu_r), .wr_um_data(8'hA5),
    .wr_raw_valid(wr_v), .wr_raw_ready(1'b1), .wr_raw_data(wr_d), .wr_raw_last(wr_l),
    .rd_raw_valid(rr_v), .rd_raw_ready(rr_r), .rd_raw_data(rr_d), .rd_raw_last(rr_l),
    .rd_pay_valid(rp_v), .rd_pay_ready(1'b1), .rd_pay_data(rp_d), .rd_pay_last(rp_l),
    .rd_um_valid(ru_v), .rd_um_ready(1'b1), .rd_um_data(ru_d),
    .rd_sst_valid(ss_v), .rd_sst_ready(1'b1), .rd_sst_code(ss_code), .rd_sst_nerr(ss_nerr), .rd_sst_aux(ss_aux),
    .rd_sst_sector(ss_sec), .rd_sst_crc_ok(ss_crc),
    .rd_pst_valid(ps_v), .rd_pst_ready(1'b1), .rd_pst_n_corr(pn_corr), .rd_pst_n_uncorr(pn_unc),
    .rd_pst_n_integ(pn_int), .rd_pst_n_erased(pn_era), .rd_pst_max_flips(p_max), .rd_pst_tot_flips(p_tot),
    .rd_pst_all_erased(p_alle), .rd_pst_bbm(p_bbm), .rd_pst_ok(p_ok), .rd_pst_scrub(p_scrub),
    .rd_pst_frame_err(p_ferr),
    .ev_corrected(ev_c), .ev_uncorr(ev_u), .ev_integrity(ev_i), .ev_scrub(ev_s), .irq,
    .enc_busy(ebusy), .dec_busy(dbusy));

  // ------------------------------------------------------------------ jobs and data
  reg [31:0] jobs [0:NJ-1];                   // {flags[31:24] (1 program, 2 read), blk[23:8], pg[7:0]}
  reg [7:0]  pay  [0:NJ*DATA-1];
  reg [7:0]  rawb [0:RAW-1];                  // encoder output / raw page read (column order)
  reg [7:0]  dpay [0:DATA-1];
  integer    rawn, dpn, ssn;
  reg [31:0] sst  [0:S-1];
  reg        pdone;
  reg [31:0] pst0, pst1;
  string     dump, jf, pf;
  integer    fd, errors = 0, phase = 0, n_prog = 0, n_read = 0, n_erase = 0;

  // encoder output collector / decoder output collectors (always accept)
  always @(posedge clk) begin
    if (wr_v) begin rawb[rawn] <= wr_d; rawn <= rawn + 1; end
    if (rp_v) begin dpay[dpn] <= rp_d; dpn <= dpn + 1; end
    if (ss_v) begin sst[ssn] <= {13'd0, ss_crc, ss_nerr, ss_sec, 5'd0, ss_code}; ssn <= ssn + 1; end
    if (ps_v) begin
      pst0  <= {pn_era, pn_int, pn_unc, pn_corr};
      pst1  <= {p_ferr, 4'd0, p_scrub, p_ok, p_alle, p_tot, p_max};
      pdone <= 1'b1;
    end
  end

  // drive one byte on a ready/valid input from the initial process (set at negedge,
  // transfer at the first posedge with ready, as seen at that negedge or later)
  task automatic enc_page(input integer j);
    integer i;
    begin
      rawn = 0;
      for (i = 0; i < DATA; i = i + 1) begin
        @(negedge clk);
        wp_v = 1'b1; wp_d = pay[j * DATA + i]; wp_l = (i == DATA - 1);
        while (!wp_r) @(negedge clk);
      end
      @(negedge clk) wp_v = 1'b0;
      while (rawn < RAW) @(negedge clk);
    end
  endtask
  task automatic dec_page();
    integer i;
    begin
      dpn = 0; ssn = 0; pdone = 1'b0;
      for (i = 0; i < RAW; i = i + 1) begin
        @(negedge clk);
        rr_v = 1'b1; rr_d = (i < SPARE) ? rawb[DATA + i] : rawb[i - SPARE]; rr_l = (i == RAW - 1);
        while (!rr_r) @(negedge clk);
      end
      @(negedge clk) rr_v = 1'b0;
      while (!pdone) @(negedge clk);
    end
  endtask

  integer j, i, blk, pg;
  reg [7:0] st;
  initial begin
    if (!$value$plusargs("JOBS=%s", jf)) jf = "jobs.memh";
    if (!$value$plusargs("PAY=%s", pf)) pf = "pay.memh";
    if (!$value$plusargs("DUMP=%s", dump)) dump = "twin_dump.txt";
    if (!$value$plusargs("PHASE=%d", phase)) phase = 0;
    $readmemh(jf, jobs);
    $readmemh(pf, pay);
    fd = $fopen(dump, "w");
    #20 rst_n = 1'b1;
    #100 vcc_ok = 1'b1;
    #2000 u_bfm.reset();
    // ---------------- program
    if (phase != 2)
      for (j = 0; j < NJ; j = j + 1) begin
        blk = (jobs[j] >> 8) & 16'hFFFF; pg = jobs[j] & 8'hFF;
        if (jobs[j][24]) begin
          if (pg == 0) begin
            u_bfm.erase_block(0, blk, st);
            n_erase = n_erase + 1;
            if (st[0]) begin errors = errors + 1; $display("ERROR erase blk %0d status %02h", blk, st); end
          end
          enc_page(j);
          for (i = 0; i < RAW; i = i + 1) u_bfm.wbuf[i] = rawb[i];
          u_bfm.program_page(0, blk, pg, 0, RAW, st);
          n_prog = n_prog + 1;
          if (st[0]) begin errors = errors + 1; $display("ERROR program blk %0d pg %0d status %02h", blk, pg, st); end
        end else if (pg == 0 && jobs[j][26]) begin
          u_bfm.erase_block(0, blk, st);                 // erased-page tests start from an erased block
          n_erase = n_erase + 1;
        end
      end
    // ---------------- read back through the decoder
    if (phase != 1)
      for (j = 0; j < NJ; j = j + 1) begin
        blk = (jobs[j] >> 8) & 16'hFFFF; pg = jobs[j] & 8'hFF;
        if (jobs[j][25]) begin
          u_bfm.read_page(0, blk, pg, DATA, SPARE);        // spare area first
          for (i = 0; i < SPARE; i = i + 1) rawb[DATA + i] = u_bfm.rbuf[i];
          u_bfm.change_read_col(0, DATA);                  // then the data area
          for (i = 0; i < DATA; i = i + 1) rawb[i] = u_bfm.rbuf[i];
          dec_page();
          n_read = n_read + 1;
          $fwrite(fd, "P %0d %0d %0d\nR ", j, blk, pg);
          for (i = 0; i < RAW; i = i + 1) $fwrite(fd, "%02x", rawb[i]);
          $fwrite(fd, "\nD ");
          for (i = 0; i < DATA; i = i + 1) $fwrite(fd, "%02x", dpay[i]);
          $fwrite(fd, "\n");
          for (i = 0; i < S; i = i + 1) $fwrite(fd, "S %0d %0d %0d %0d\n", sst[i][15:8], sst[i][2:0], sst[i][23:16], sst[i][24]);
          $fwrite(fd, "G %08x %08x\n", pst0, pst1);
        end
      end
    $fclose(fd);
    u_bfm.idle();
    #1000;
    $display("TB RESULT tb_sfecc_nand_twin phase=%0d programmed=%0d read=%0d erased_blocks=%0d nand_protocol_errors=%0d nand_timing_violations=%0d errors=%0d -> %0s",
             phase, n_prog, n_read, n_erase, u_nand.n_proto_errors, u_nand.n_timing_violations, errors,
             (errors == 0 && u_nand.n_proto_errors == 0 && u_nand.n_timing_violations == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule

`default_nettype wire
