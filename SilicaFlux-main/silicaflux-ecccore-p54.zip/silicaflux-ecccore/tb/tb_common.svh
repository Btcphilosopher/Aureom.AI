// =============================================================================
// SilicaFlux ECCCore (Project 54) :: tb_common.svh -- testbench helpers
// Deterministic xorshift32 PRNG: the same +SEED gives identical random
// back-pressure on both simulators (Icarus and the Verilator build).
// =============================================================================
  function automatic [31:0] tb_xs(input [31:0] x);
    reg [31:0] y;
    begin
      y = x;
      y = y ^ (y << 13);
      y = y ^ (y >> 17);
      y = y ^ (y << 5);
      tb_xs = (y == 32'd0) ? 32'h1234_5678 : y;
    end
  endfunction
  // 1 with probability pct/100 (pct in 0..100), from PRNG state x
  function automatic bit tb_hit(input [31:0] x, input integer pct);
    tb_hit = ((x % 100) < pct);
  endfunction
