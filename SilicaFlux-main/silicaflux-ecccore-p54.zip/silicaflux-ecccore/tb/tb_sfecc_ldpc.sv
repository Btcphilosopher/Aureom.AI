// =============================================================================
// SilicaFlux ECCCore (Project 54) :: tb_sfecc_ldpc -- LDPC proof-of-concept testbench
//
// Vectors from ref/sfecc_ldpc.py (scripts/gen_ldpc_vectors.py).  Checks, per record:
//   encoder   stored codeword == reference (byte for byte)
//   decoder S soft input (5-bit channel LLRs per bit, SOFT_EN = 1): message bytes,
//             status code, corrected-bit count and iteration count == fixed-point reference
//   decoder H hard input (SOFT_EN = 0, LLR = +-15 from the received bits): same checks
// Random back-pressure on every port.  Prints TB RESULT; JSON summary (+OUT).
// =============================================================================
`timescale 1ns/1ps
`include "sfecc_defs.svh"
`include "tb_ldpc_cfg.svh"
`default_nettype none

module tb_sfecc_ldpc;
  `include "tb_common.svh"
  localparam integer NREC  = `TBL_NREC;
  localparam integer LLR_W = `TBL_LLR_W;
  localparam integer RB    = 56;

  reg clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  integer cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  reg [7:0]       vb [0:NREC*RB-1];
  reg [LLR_W-1:0] vl [0:NREC*128-1];
  reg [31:0]      vs [0:NREC*2-1];
  string          vdir, outf;
  integer         errors = 0, checks = 0, bp = 30;
  reg [31:0]      r0 = 1, r1 = 2, r2 = 3, r3 = 4, r4 = 5, r5 = 6, r6 = 7, r7 = 8;
  integer         codes_s [0:3], codes_h [0:3], iters_s = 0, iters_h = 0;

  // ------------------------------------------------------------------ DUTs
  reg  e_iv, d0_iv, d1_iv;
  wire e_ir, d0_ir, d1_ir;
  integer e_rec, e_b, d0_rec, d0_b, d1_rec, d1_b;
  wire e_ov, e_ol, e_fe;
  reg  e_or;
  wire [7:0] e_od;
  sfecc_ldpc_enc u_enc (.clk, .rst_n, .in_valid(e_iv), .in_ready(e_ir), .in_data(vb[e_rec*RB + e_b]),
    .in_last(e_b == 7), .out_valid(e_ov), .out_ready(e_or), .out_data(e_od), .out_last(e_ol), .frame_err(e_fe));

  wire [8*LLR_W-1:0] llr0;
  genvar g;
  generate
    for (g = 0; g < 8; g = g + 1) begin : g_llr
      assign llr0[g*LLR_W +: LLR_W] = vl[d0_rec*128 + d0_b*8 + g];
    end
  endgenerate
  wire       s_ov, s_ol, s_sv, s_fe, s_busy, h_ov, h_ol, h_sv, h_fe, h_busy;
  reg        s_or, s_sr, h_or, h_sr;
  wire [7:0] s_od, s_nerr, s_aux, h_od, h_nerr, h_aux;
  wire [1:0] s_code, h_code;
  sfecc_ldpc_dec #(.LLR_W(LLR_W), .SOFT_EN(1)) u_soft (.clk, .rst_n,
    .in_valid(d0_iv), .in_ready(d0_ir), .in_data(vb[d0_rec*RB + 24 + d0_b]), .in_last(d0_b == 15), .in_llr(llr0),
    .out_valid(s_ov), .out_ready(s_or), .out_data(s_od), .out_last(s_ol),
    .st_valid(s_sv), .st_ready(s_sr), .st_code(s_code), .st_nerr(s_nerr), .st_aux(s_aux), .st_frame_err(s_fe),
    .busy(s_busy));
  sfecc_ldpc_dec #(.LLR_W(LLR_W), .SOFT_EN(0)) u_hard (.clk, .rst_n,
    .in_valid(d1_iv), .in_ready(d1_ir), .in_data(vb[d1_rec*RB + 24 + d1_b]), .in_last(d1_b == 15),
    .in_llr({8*LLR_W{1'b0}}),
    .out_valid(h_ov), .out_ready(h_or), .out_data(h_od), .out_last(h_ol),
    .st_valid(h_sv), .st_ready(h_sr), .st_code(h_code), .st_nerr(h_nerr), .st_aux(h_aux), .st_frame_err(h_fe),
    .busy(h_busy));

  // ------------------------------------------------------------------ drivers
  always @(posedge clk) begin
    if (!rst_n) begin
      e_rec <= 0; e_b <= 0; e_iv <= 1'b0; d0_rec <= 0; d0_b <= 0; d0_iv <= 1'b0; d1_rec <= 0; d1_b <= 0; d1_iv <= 1'b0;
    end else begin
      r0 <= tb_xs(r0); r1 <= tb_xs(r1); r2 <= tb_xs(r2);
      if (e_iv && e_ir) begin
        if (e_b == 7) begin e_b <= 0; e_rec <= e_rec + 1; end else e_b <= e_b + 1;
        e_iv <= ((e_b != 7) || (e_rec + 1 < NREC)) && !tb_hit(r0, bp);
      end else if (!e_iv) e_iv <= (e_rec < NREC) && !tb_hit(r0, bp);
      if (d0_iv && d0_ir) begin
        if (d0_b == 15) begin d0_b <= 0; d0_rec <= d0_rec + 1; end else d0_b <= d0_b + 1;
        d0_iv <= ((d0_b != 15) || (d0_rec + 1 < NREC)) && !tb_hit(r1, bp);
      end else if (!d0_iv) d0_iv <= (d0_rec < NREC) && !tb_hit(r1, bp);
      if (d1_iv && d1_ir) begin
        if (d1_b == 15) begin d1_b <= 0; d1_rec <= d1_rec + 1; end else d1_b <= d1_b + 1;
        d1_iv <= ((d1_b != 15) || (d1_rec + 1 < NREC)) && !tb_hit(r2, bp);
      end else if (!d1_iv) d1_iv <= (d1_rec < NREC) && !tb_hit(r2, bp);
    end
  end

  // ------------------------------------------------------------------ checkers
  integer eo_rec, eo_b, so_rec, so_b, ss_rec, ho_rec, ho_b, hs_rec;
  task automatic fail(input [8*48-1:0] what, input integer rec, input integer idx, input integer got, input integer exp);
    begin
      errors = errors + 1;
      if (errors <= 20) $display("ERROR %0s rec %0d idx %0d got %0h exp %0h", what, rec, idx, got, exp);
    end
  endtask
  always @(posedge clk) begin
    if (!rst_n) begin
      eo_rec <= 0; eo_b <= 0; so_rec <= 0; so_b <= 0; ss_rec <= 0; ho_rec <= 0; ho_b <= 0; hs_rec <= 0;
      e_or <= 1'b0; s_or <= 1'b0; s_sr <= 1'b0; h_or <= 1'b0; h_sr <= 1'b0;
    end else begin
      r3 <= tb_xs(r3); r4 <= tb_xs(r4); r5 <= tb_xs(r5); r6 <= tb_xs(r6); r7 <= tb_xs(r7);
      e_or <= !tb_hit(r3, bp); s_or <= !tb_hit(r4, bp); s_sr <= !tb_hit(r5, bp); h_or <= !tb_hit(r6, bp);
      h_sr <= !tb_hit(r7, bp);
      if (e_ov && e_or) begin
        checks = checks + 1;
        if (e_od !== vb[eo_rec*RB + 8 + eo_b]) fail("enc", eo_rec, eo_b, e_od, vb[eo_rec*RB + 8 + eo_b]);
        if (eo_b == 15) begin eo_b <= 0; eo_rec <= eo_rec + 1; end else eo_b <= eo_b + 1;
      end
      if (e_fe) fail("enc frame", eo_rec, 0, 1, 0);
      if (s_ov && s_or) begin
        checks = checks + 1;
        if (s_od !== vb[so_rec*RB + 40 + so_b]) fail("soft data", so_rec, so_b, s_od, vb[so_rec*RB + 40 + so_b]);
        if (so_b == 7) begin so_b <= 0; so_rec <= so_rec + 1; end else so_b <= so_b + 1;
      end
      if (s_sv && s_sr) begin
        checks = checks + 1;
        if ({s_aux, s_nerr, 6'd0, s_code} !== vs[ss_rec*2][23:0] || s_fe)
          fail("soft status {it,nerr,code}", ss_rec, 0, {s_aux, s_nerr, 6'd0, s_code}, vs[ss_rec*2][23:0]);
        codes_s[s_code] = codes_s[s_code] + 1; iters_s = iters_s + s_aux;
        ss_rec <= ss_rec + 1;
      end
      if (h_ov && h_or) begin
        checks = checks + 1;
        if (h_od !== vb[ho_rec*RB + 48 + ho_b]) fail("hard data", ho_rec, ho_b, h_od, vb[ho_rec*RB + 48 + ho_b]);
        if (ho_b == 7) begin ho_b <= 0; ho_rec <= ho_rec + 1; end else ho_b <= ho_b + 1;
      end
      if (h_sv && h_sr) begin
        checks = checks + 1;
        if ({h_aux, h_nerr, 6'd0, h_code} !== vs[hs_rec*2 + 1][23:0] || h_fe)
          fail("hard status {it,nerr,code}", hs_rec, 0, {h_aux, h_nerr, 6'd0, h_code}, vs[hs_rec*2 + 1][23:0]);
        codes_h[h_code] = codes_h[h_code] + 1; iters_h = iters_h + h_aux;
        hs_rec <= hs_rec + 1;
      end
    end
  end

  integer k, fd, t0;
  initial begin
    if (!$value$plusargs("VEC=%s", vdir)) vdir = ".";
    if (!$value$plusargs("OUT=%s", outf)) outf = "tb_sfecc_ldpc.json";
    if (!$value$plusargs("BP=%d", bp)) bp = 30;
    $readmemh({vdir, "/ldpc_bytes.memh"}, vb);
    $readmemh({vdir, "/ldpc_llr.memh"}, vl);
    $readmemh({vdir, "/ldpc_st.memh"}, vs);
    for (k = 0; k < 4; k = k + 1) begin codes_s[k] = 0; codes_h[k] = 0; end
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    t0 = cyc;
    while (!(ss_rec >= NREC && hs_rec >= NREC && eo_rec >= NREC) && cyc - t0 < 20000000) @(posedge clk);
    if (cyc - t0 >= 20000000) begin errors = errors + 1; $display("ERROR timeout"); end
    $display("TB LDPC soft: CLEAN %0d CORRECTED %0d ERASED %0d UNCORR %0d, avg iterations %0.2f",
             codes_s[0], codes_s[1], codes_s[2], codes_s[3], (1.0 * iters_s) / NREC);
    $display("TB LDPC hard: CLEAN %0d CORRECTED %0d ERASED %0d UNCORR %0d, avg iterations %0.2f",
             codes_h[0], codes_h[1], codes_h[2], codes_h[3], (1.0 * iters_h) / NREC);
    fd = $fopen(outf, "w");
    $fwrite(fd, "{\"records\": %0d, \"soft\": [%0d,%0d,%0d,%0d], \"hard\": [%0d,%0d,%0d,%0d], \"iters_soft\": %0d, \"iters_hard\": %0d, \"cycles\": %0d, \"checks\": %0d, \"errors\": %0d}\n",
            NREC, codes_s[0], codes_s[1], codes_s[2], codes_s[3], codes_h[0], codes_h[1], codes_h[2], codes_h[3],
            iters_s, iters_h, cyc - t0, checks, errors);
    $fclose(fd);
    $display("TB RESULT tb_sfecc_ldpc records=%0d checks=%0d errors=%0d -> %0s", NREC, checks, errors,
             (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule

`default_nettype wire
