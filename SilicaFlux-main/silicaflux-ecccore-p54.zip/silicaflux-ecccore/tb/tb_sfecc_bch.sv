// =============================================================================
// SilicaFlux ECCCore (Project 54) :: tb_sfecc_bch -- BCH encoder/decoder core testbench
//
// Vector-driven (build/vec/<CFG>/, scripts/gen_vectors.py, reference model
// ref/sfecc_bch.py).  For every record the encoder output must equal the
// reference codeword byte for byte, and the decoder (fed independently with the
// reference received word = codeword XOR error pattern) must return the reference
// message bytes, status code and corrected-bit count bit-exactly.
// Phases:
//   PERF   no back-pressure, back-to-back codewords: throughput and latency
//   MAIN   every record, random back-pressure on every input/output (+BP_* %)
//   RESET  NRST asynchronous resets in the middle of traffic (encoder and decoder
//          mid-codeword, KES and Chien busy), each followed by a clean re-run
// The testbench also classifies each decode against the TRUTH (original message):
// correct / detected-uncorrectable / miscorrected (undetected), per error category.
// Output: "TB RESULT ..." line + JSON (+OUT=<file>).
// Portable: Icarus Verilog 12 (-g2012) and Verilator 5 (--timing).
// =============================================================================
`timescale 1ns/1ps
`include "sfecc_defs.svh"
`include "sfecc_cfg.svh"
`include "tb_cfg.svh"
`default_nettype none

module tb_sfecc_bch #(parameter integer NBANKS_TB = 2);
  `include "tb_common.svh"
  localparam integer MSG  = `TB_MSG;
  localparam integer CW   = `TB_CW;
  localparam integer NREC = `TB_NREC;
  localparam integer T    = `TB_T;
  localparam integer RB   = 2 * MSG + 2 * CW;
  localparam integer NW   = $clog2(T + 1);
  localparam integer NCAT = 14;

  reg clk = 1'b0;
  reg rst_n = 1'b0;
  always #5 clk = ~clk;
  integer cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ------------------------------------------------------------------ vectors
  reg [7:0]  vb [0:NREC*RB-1];
  reg [31:0] vs [0:NREC-1];
  reg [0:0]  dok [0:NREC-1];
  string     vdir, outf;

  // ------------------------------------------------------------------ control
  integer start_rec = 0, stop_rec = 0;
  integer frame_rec = -1;                 // FRAME phase: in_last misplaced on this record
  integer n_eferr = 0, n_dferr = 0;
  integer bp_in = 0, bp_out = 0, bp_st = 0;
  integer errors = 0, checks = 0;
  reg [31:0] seed;

  // ------------------------------------------------------------------ DUTs
  reg        e_iv;
  wire       e_ir;
  wire       e_ov, e_ol, e_ferr;
  reg        e_or;
  wire [7:0] e_od;
  integer    e_rec, e_byte;
  wire [7:0] e_id = vb[e_rec * RB + e_byte];
  sfecc_bch_enc #(`TB_ENC_P) u_enc (
    .clk, .rst_n, .in_valid(e_iv), .in_ready(e_ir), .in_data(e_id), .in_last((e_rec == frame_rec) ? (e_byte == 0) : (e_byte == MSG - 1)),
    .out_valid(e_ov), .out_ready(e_or), .out_data(e_od), .out_last(e_ol), .frame_err(e_ferr)
  );

  reg        d_iv;
  wire       d_ir;
  wire       d_ov, d_ol, d_sv, d_sferr, d_busy;
  reg        d_or, d_sr;
  wire [7:0] d_od;
  wire [1:0] d_scode;
  wire [NW-1:0] d_snerr;
  integer    d_rec, d_byte;
  wire [7:0] d_id = vb[d_rec * RB + MSG + CW + d_byte];
  sfecc_bch_dec #(`TB_DEC_P, .NBANKS(NBANKS_TB)) u_dec (
    .clk, .rst_n, .in_valid(d_iv), .in_ready(d_ir), .in_data(d_id), .in_last((d_rec == frame_rec) ? (d_byte == 0) : (d_byte == CW - 1)),
    .out_valid(d_ov), .out_ready(d_or), .out_data(d_od), .out_last(d_ol),
    .st_valid(d_sv), .st_ready(d_sr), .st_code(d_scode), .st_nerr(d_snerr), .st_frame_err(d_sferr),
    .busy(d_busy)
  );

  // ------------------------------------------------------------------ input drivers
  reg [31:0] r_e, r_d, r_eo, r_do, r_ds;
  always @(posedge clk) begin
    if (!rst_n) begin
      e_rec <= start_rec; e_byte <= 0; e_iv <= 1'b0;
      d_rec <= start_rec; d_byte <= 0; d_iv <= 1'b0;
    end else begin
      r_e <= tb_xs(r_e);
      r_d <= tb_xs(r_d);
      if (e_iv && e_ir) begin
        if (e_byte == MSG - 1) begin e_byte <= 0; e_rec <= e_rec + 1; end
        else e_byte <= e_byte + 1;
        e_iv <= ((e_byte != MSG - 1) || (e_rec + 1 < stop_rec)) && !tb_hit(r_e, bp_in);
      end else if (!e_iv)
        e_iv <= (e_rec < stop_rec) && !tb_hit(r_e, bp_in);
      if (d_iv && d_ir) begin
        if (d_byte == CW - 1) begin d_byte <= 0; d_rec <= d_rec + 1; end
        else d_byte <= d_byte + 1;
        d_iv <= ((d_byte != CW - 1) || (d_rec + 1 < stop_rec)) && !tb_hit(r_d, bp_in);
      end else if (!d_iv)
        d_iv <= (d_rec < stop_rec) && !tb_hit(r_d, bp_in);
    end
  end

  // ------------------------------------------------------------------ checkers
  integer eo_rec, eo_byte, do_rec, do_byte, ds_rec;
  integer n_enc_cw, n_dec_st;
  reg     cur_ok, cur_exact;
  integer cov [0:NCAT-1][0:5];          // [cat][0..3 status, 4 = miscorrected, 5 = correct]
  integer cov_w [0:63][0:2];            // [error weight][correct, detected, miscorrected]
  integer cov_nerr [0:63];
  integer n_correct = 0, n_detected = 0, n_miscorr = 0;
  integer first_in_cyc = -1, first_out_cyc = -1, first_st_cyc = -1;
  integer last_st_cyc;
  integer k;

  task automatic fail(input [8*96-1:0] what, input integer rec, input integer idx, input integer got,
                      input integer exp);
    begin
      errors = errors + 1;
      if (errors <= 20)
        $display("ERROR %0s rec %0d idx %0d got %0h exp %0h (cyc %0d)", what, rec, idx, got, exp, cyc);
    end
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      eo_rec <= start_rec; eo_byte <= 0; do_rec <= start_rec; do_byte <= 0; ds_rec <= start_rec;
      n_enc_cw <= 0; n_dec_st <= 0; cur_ok <= 1'b1; cur_exact <= 1'b1;
      e_or <= 1'b0; d_or <= 1'b0; d_sr <= 1'b0;
    end else begin
      r_eo <= tb_xs(r_eo); r_do <= tb_xs(r_do); r_ds <= tb_xs(r_ds);
      e_or <= !tb_hit(r_eo, bp_out);
      d_or <= !tb_hit(r_do, bp_out);
      d_sr <= !tb_hit(r_ds, bp_st);
      // encoder output == reference stored codeword
      if (e_ov && e_or) begin
        checks = checks + 1;
        if (e_od !== vb[eo_rec * RB + MSG + eo_byte]) fail("enc data", eo_rec, eo_byte, e_od, vb[eo_rec * RB + MSG + eo_byte]);
        if (e_ol !== (eo_byte == CW - 1))            fail("enc last", eo_rec, eo_byte, e_ol, eo_byte == CW - 1);
        if (eo_byte == CW - 1) begin eo_byte <= 0; eo_rec <= eo_rec + 1; n_enc_cw <= n_enc_cw + 1; end
        else eo_byte <= eo_byte + 1;
      end
      if (e_ferr) begin
        n_eferr = n_eferr + 1;
        if (frame_rec < 0) fail("enc frame_err", eo_rec, 0, 1, 0);
      end
      // decoder data == reference output; truth = original message
      if (d_ov && d_or) begin
        checks = checks + 1;
        if (first_out_cyc < 0) first_out_cyc <= cyc;
        if (d_od !== vb[do_rec * RB + MSG + 2 * CW + do_byte])
          fail("dec data", do_rec, do_byte, d_od, vb[do_rec * RB + MSG + 2 * CW + do_byte]);
        if (d_ol !== (do_byte == MSG - 1)) fail("dec last", do_rec, do_byte, d_ol, do_byte == MSG - 1);
        if (((d_od ^ vb[do_rec * RB + do_byte]) & ((do_byte == 0) ? `TB_LMASK : 8'hFF)) != 8'h00)
          dok[do_rec] = 1'b0;
        else if (do_byte == 0)
          dok[do_rec] = 1'b1;
        if (do_byte == MSG - 1) begin do_byte <= 0; do_rec <= do_rec + 1; end
        else do_byte <= do_byte + 1;
      end
      // decoder status == reference; classification against the truth
      if (d_sv && d_sr) begin : st_chk
        reg [31:0] v;
        integer cat, w, cls;
        v   = vs[ds_rec];
        cat = (v >> 10) & 63;
        w   = (v >> 20) & 255;
        checks = checks + 1;
        if (first_st_cyc < 0) first_st_cyc <= cyc;
        last_st_cyc = cyc;
        if (d_scode !== v[1:0])           fail("dec code", ds_rec, 0, d_scode, v[1:0]);
        if (d_snerr !== v[2 +: NW])       fail("dec nerr", ds_rec, 0, d_snerr, v[2 +: NW]);
        if (d_sferr !== (ds_rec == frame_rec)) fail("dec frame_err", ds_rec, 0, d_sferr, ds_rec == frame_rec);
        if (d_sferr) n_dferr = n_dferr + 1;
        if (ds_rec >= do_rec && !(do_rec == ds_rec + 1))
          fail("status before data", ds_rec, 0, do_rec, ds_rec + 1);
        if (d_scode == `SFECC_ST_UNCORR) cls = 1;
        else if (dok[ds_rec] == 1'b1)    cls = 0;
        else                             cls = 2;
        cov[cat][d_scode] = cov[cat][d_scode] + 1;
        if (cls == 2) cov[cat][4] = cov[cat][4] + 1;
        if (cls == 0) cov[cat][5] = cov[cat][5] + 1;
        cov_w[(w > 63) ? 63 : w][cls] = cov_w[(w > 63) ? 63 : w][cls] + 1;
        cov_nerr[d_snerr] = cov_nerr[d_snerr] + 1;
        if (cls == 0) n_correct = n_correct + 1;
        if (cls == 1) n_detected = n_detected + 1;
        if (cls == 2) n_miscorr = n_miscorr + 1;
        ds_rec   <= ds_rec + 1;
        n_dec_st <= n_dec_st + 1;
      end
    end
  end
  always @(posedge clk) if (rst_n && d_iv && d_ir && first_in_cyc < 0) first_in_cyc <= cyc;

  // ------------------------------------------------------------------ phase control
  integer maxcyc, nperf, nrst, t0, t_perf, perf_n, lat_out, lat_st, i0, rcyc, nrun;
  integer fd;
  task automatic do_reset(input integer cycles);
    begin
      @(negedge clk) rst_n = 1'b0;
      repeat (cycles) @(negedge clk);
      // reset must leave every output idle
      if (e_ov !== 1'b0 || d_ov !== 1'b0 || d_sv !== 1'b0 || e_ir === 1'bx) begin
        errors = errors + 1; $display("ERROR outputs not idle in reset");
      end
      rst_n = 1'b1;
    end
  endtask
  task automatic run_until_done(input integer nrec);
    integer tstart;
    begin
      tstart = cyc;
      while (!(n_dec_st >= nrec && n_enc_cw >= nrec) && (cyc - tstart) < maxcyc) @(posedge clk);
      if (cyc - tstart >= maxcyc) begin
        errors = errors + 1;
        $display("ERROR timeout: enc %0d dec %0d of %0d", n_enc_cw, n_dec_st, nrec);
      end
    end
  endtask

  initial begin
    if (!$value$plusargs("VEC=%s", vdir)) vdir = ".";
    if (!$value$plusargs("OUT=%s", outf)) outf = "tb_sfecc_bch.json";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("BP_IN=%d", bp_in)) bp_in = 30;
    if (!$value$plusargs("BP_OUT=%d", bp_out)) bp_out = 30;
    if (!$value$plusargs("BP_ST=%d", bp_st)) bp_st = 30;
    if (!$value$plusargs("NRST=%d", nrst)) nrst = 12;
    if (!$value$plusargs("MAXCYC=%d", maxcyc)) maxcyc = 200000000;
    if (!$value$plusargs("MAXREC=%d", nrun)) nrun = NREC;
    if (nrun > NREC) nrun = NREC;
    $readmemh({vdir, "/core_bytes.memh"}, vb);
    $readmemh({vdir, "/core_st.memh"}, vs);
    r_e = seed ^ 32'h1111; r_d = seed ^ 32'h2222; r_eo = seed ^ 32'h3333; r_do = seed ^ 32'h4444;
    r_ds = seed ^ 32'h5555;
    for (k = 0; k < NCAT; k = k + 1) begin cov[k][0] = 0; cov[k][1] = 0; cov[k][2] = 0; cov[k][3] = 0;
                                           cov[k][4] = 0; cov[k][5] = 0; end
    for (k = 0; k < 64; k = k + 1) begin cov_w[k][0] = 0; cov_w[k][1] = 0; cov_w[k][2] = 0; cov_nerr[k] = 0; end
    for (k = 0; k < NREC; k = k + 1) dok[k] = 1'b0;
    $display("TB tb_sfecc_bch cfg %0s NBANKS %0d: %0d records, MSG %0d CW %0d T %0d, back-pressure in/out/st %0d/%0d/%0d %%",
             `TB_CFG_NAME, NBANKS_TB, NREC, MSG, CW, T, bp_in, bp_out, bp_st);

    // ---------------- PERF: no back-pressure
    i0 = bp_in; t0 = bp_out; rcyc = bp_st;
    bp_in = 0; bp_out = 0; bp_st = 0;
    nperf = (nrun < 64) ? nrun : 64;
    start_rec = 0; stop_rec = nperf;
    do_reset(4);
    t_perf = cyc;
    run_until_done(nperf);
    repeat (2) @(posedge clk);
    t_perf = last_st_cyc - first_in_cyc + 1;
    lat_out = first_out_cyc - first_in_cyc;
    lat_st  = first_st_cyc - first_in_cyc;
    perf_n  = nperf;
    $display("TB PERF %0d codewords back-to-back: %0d cycles (%0.3f stored bytes/cycle in), first-byte-in -> first-byte-out %0d cycles, -> first status %0d cycles",
             nperf, t_perf, (1.0 * nperf * CW) / t_perf, lat_out, lat_st);

    // ---------------- MAIN: all records with back-pressure
    bp_in = i0; bp_out = t0; bp_st = rcyc;
    start_rec = 0; stop_rec = nrun;
    for (k = 0; k < NCAT; k = k + 1) begin cov[k][0] = 0; cov[k][1] = 0; cov[k][2] = 0; cov[k][3] = 0;
                                           cov[k][4] = 0; cov[k][5] = 0; end
    for (k = 0; k < 64; k = k + 1) begin cov_w[k][0] = 0; cov_w[k][1] = 0; cov_w[k][2] = 0; cov_nerr[k] = 0; end
    n_correct = 0; n_detected = 0; n_miscorr = 0;
    do_reset(3);
    run_until_done(nrun);
    $display("TB MAIN %0d records: correct %0d, detected-uncorrectable %0d, miscorrected %0d", nrun, n_correct,
             n_detected, n_miscorr);
    begin : cov_dump
      fd = $fopen(outf, "w");
      $fwrite(fd, "{\"cfg\": \"%0s\", \"nbanks\": %0d, \"records\": %0d, \"perf\": {\"codewords\": %0d, \"cycles\": %0d, \"lat_first_out\": %0d, \"lat_first_status\": %0d, \"cw_bytes\": %0d},\n",
              `TB_CFG_NAME, NBANKS_TB, NREC, perf_n, t_perf, lat_out, lat_st, CW);
      $fwrite(fd, " \"truth\": {\"correct\": %0d, \"detected\": %0d, \"miscorrected\": %0d},\n", n_correct, n_detected, n_miscorr);
      $fwrite(fd, " \"cat_status\": [");
      for (k = 0; k < NCAT; k = k + 1)
        $fwrite(fd, "%0s[%0d,%0d,%0d,%0d,%0d,%0d]", (k == 0) ? "" : ",", cov[k][0], cov[k][1], cov[k][2], cov[k][3], cov[k][4], cov[k][5]);
      $fwrite(fd, "],\n \"weight_class\": [");
      for (k = 0; k < 64; k = k + 1)
        $fwrite(fd, "%0s[%0d,%0d,%0d]", (k == 0) ? "" : ",", cov_w[k][0], cov_w[k][1], cov_w[k][2]);
      $fwrite(fd, "],\n \"nerr_hist\": [");
      for (k = 0; k <= T; k = k + 1) $fwrite(fd, "%0s%0d", (k == 0) ? "" : ",", cov_nerr[k]);
      $fwrite(fd, "],\n");
    end

    // ---------------- RESET: interrupt traffic at varied points, then re-run cleanly
    for (k = 0; k < nrst; k = k + 1) begin
      start_rec = (k * 97) % nrun;
      stop_rec  = (start_rec + 6 < nrun) ? start_rec + 6 : nrun;
      do_reset(2);
      // run for a varying fraction of a codeword (hits SYN, KES, CHIEN, parity output)
      repeat (3 + (k * (CW + 2 * T + 7)) / 5) @(posedge clk);
      do_reset(1 + k % 4);
      run_until_done(stop_rec - start_rec);
    end
    $display("TB RESET %0d mid-traffic resets, each followed by a clean re-run", nrst);
    // ---------------- FRAME: in_last on the wrong byte of one codeword (framing is by count;
    // the violation must be flagged: encoder frame_err pulses, decoder st_frame_err on that word)
    start_rec = 0; stop_rec = (NREC < 4) ? NREC : 4; frame_rec = 1;
    n_eferr = 0; n_dferr = 0;
    do_reset(2);
    run_until_done(stop_rec - start_rec);
    repeat (4) @(posedge clk);
    checks = checks + 2;
    if (n_eferr != 2) begin errors = errors + 1; $display("ERROR FRAME: encoder frame_err pulses %0d, expected 2", n_eferr); end
    if (n_dferr != 1) begin errors = errors + 1; $display("ERROR FRAME: decoder st_frame_err %0d, expected 1", n_dferr); end
    $display("TB FRAME misplaced in_last flagged: encoder %0d pulses, decoder %0d codeword", n_eferr, n_dferr);
    frame_rec = -1;
    $fwrite(fd, " \"resets\": %0d, \"checks\": %0d, \"errors\": %0d}\n", nrst, checks, errors);
    $fclose(fd);
    $display("TB RESULT tb_sfecc_bch cfg=%0s records=%0d checks=%0d errors=%0d -> %0s", `TB_CFG_NAME, nrun,
             checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule

`default_nettype wire
