// Verilator main for coverage builds: runs the (self-timed) testbench and saves coverage.dat
// (the --binary main does not write coverage).  the model class comes from -DSFECC_COV_TOP=<class> -DSFECC_COV_TOPH=<header>.
#include <memory>
#include "verilated.h"
#include "verilated_cov.h"
#define STR2(x) #x
#define STR(x) STR2(x)
#include STR(SFECC_COV_TOPH)
int main(int argc, char** argv) {
    const std::unique_ptr<VerilatedContext> ctx{new VerilatedContext};
    ctx->commandArgs(argc, argv);
    const std::unique_ptr<SFECC_COV_TOP> top{new SFECC_COV_TOP{ctx.get()}};
    while (!ctx->gotFinish()) {
        top->eval();
        if (!top->eventsPending()) break;
        ctx->time(top->nextTimeSlot());
    }
    top->final();
    const char* f = "coverage.dat";
    for (int i = 1; i < argc; ++i)
        if (std::string(argv[i]).rfind("+COVFILE=", 0) == 0) f = argv[i] + 9;
    ctx->coveragep()->write(f);
    return 0;
}
