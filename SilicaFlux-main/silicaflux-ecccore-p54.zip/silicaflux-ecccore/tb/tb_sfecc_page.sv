// =============================================================================
// SilicaFlux ECCCore (Project 54) :: tb_sfecc_page -- page-level testbench of the
// primary RTL silicaflux_storage_ecc (page encoder + page decoder + registers)
//
// Vectors: build/vec/<CFG>/page_*.memh (scripts/gen_vectors.py --page, reference
// ref/sfecc_page.py).  Per page:
//   program path: payload + user metadata in -> raw page (column order) must equal the
//                 reference byte for byte (layout, CRC-16, parity, 0xFF RSVD/unused bytes)
//   read path:    reference received page (spare-first) in -> corrected payload, user
//                 metadata, every sector status {code, nerr, crc_ok, sector} and the page
//                 status {counts, max/total flips, all-erased, ok, scrub, BBM} must match.
// Page categories: clean, correctable, mixed, uncorrectable, erased, erased+flips,
// constructed miscorrection (CRC must catch), error pattern = codeword (BCH blind,
// CRC must catch), bad-block-marker byte, bursts.  Random back-pressure everywhere,
// PERF phase without back-pressure, register-window counters checked at the end,
// mid-page resets followed by clean re-runs.
// =============================================================================
`timescale 1ns/1ps
`include "sfecc_defs.svh"
`include "sfecc_cfg.svh"
`include "tb_page_cfg.svh"
`default_nettype none

module tb_sfecc_page;
  `include "tb_common.svh"
  localparam integer DATA  = `TBP_DATA;
  localparam integer SPARE = `TBP_SPARE;
  localparam integer S     = `TBP_SECTORS;
  localparam integer UM    = `TBP_UMETA;
  localparam integer NP    = `TBP_NPAGE;
  localparam integer RAW   = DATA + SPARE;
  localparam integer UMT   = (S * UM > 0) ? S * UM : 1;
  localparam integer PB    = 2 * DATA + 2 * S * UM + 2 * RAW;
  localparam integer O_UMI = DATA, O_RAW = DATA + S * UM, O_RX = O_RAW + RAW, O_PAY = O_RX + RAW,
                     O_UMO = O_PAY + DATA;
  localparam integer SW_   = S + 3;                         // status words per page

  reg clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  integer cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  reg [7:0]  vb [0:NP*PB-1];
  reg [31:0] vs [0:NP*SW_-1];
  string     vdir, outf;
  integer    errors = 0, checks = 0;
  integer    bp = 30, start_pg = 0, stop_pg = 0;
  reg [31:0] r0, r1, r2, r3, r4, r5, r6, r7;

  // ------------------------------------------------------------------ DUT
  reg         rb_sel = 1'b0, rb_we = 1'b0;
  reg  [7:0]  rb_addr = 8'h00;
  reg  [31:0] rb_wdata = 32'h0;
  wire [31:0] rb_rdata;
  reg         wp_v, wu_v, rr_v;
  wire        wp_r, wu_r, wr_v, wr_l, rr_r, rp_v, rp_l, ru_v, ss_v, ps_v;
  reg         wr_r, rp_r, ru_r, ss_r, ps_r;
  wire [7:0]  wr_d, rp_d, ru_d;
  wire [2:0]  ss_code;
  wire [7:0]  ss_nerr, ss_aux, ss_sec, pn_corr, pn_unc, pn_int, pn_era, p_max, p_bbm;
  wire [15:0] p_tot;
  wire        ss_crc, p_alle, p_ok, p_scrub, p_ferr;
  wire        ev_c, ev_u, ev_i, ev_s, irq, ebusy, dbusy;
  integer     wp_pg, wp_b, wu_pg, wu_b, rr_pg, rr_b;
  wire [7:0]  wp_d = vb[wp_pg * PB + wp_b];
  wire [7:0]  wu_d = vb[wu_pg * PB + O_UMI + wu_b];
  wire [7:0]  rr_d = vb[rr_pg * PB + O_RX + ((rr_b < SPARE) ? DATA + rr_b : rr_b - SPARE)];

  silicaflux_storage_ecc #(`TBP_P) dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata,
    .wr_pay_valid(wp_v), .wr_pay_ready(wp_r), .wr_pay_data(wp_d), .wr_pay_last(wp_b == DATA - 1),
    .wr_um_valid(wu_v), .wr_um_ready(wu_r), .wr_um_data(wu_d),
    .wr_raw_valid(wr_v), .wr_raw_ready(wr_r), .wr_raw_data(wr_d), .wr_raw_last(wr_l),
    .rd_raw_valid(rr_v), .rd_raw_ready(rr_r), .rd_raw_data(rr_d), .rd_raw_last(rr_b == RAW - 1),
    .rd_pay_valid(rp_v), .rd_pay_ready(rp_r), .rd_pay_data(rp_d), .rd_pay_last(rp_l),
    .rd_um_valid(ru_v), .rd_um_ready(ru_r), .rd_um_data(ru_d),
    .rd_sst_valid(ss_v), .rd_sst_ready(ss_r), .rd_sst_code(ss_code), .rd_sst_nerr(ss_nerr), .rd_sst_aux(ss_aux),
    .rd_sst_sector(ss_sec), .rd_sst_crc_ok(ss_crc),
    .rd_pst_valid(ps_v), .rd_pst_ready(ps_r), .rd_pst_n_corr(pn_corr), .rd_pst_n_uncorr(pn_unc),
    .rd_pst_n_integ(pn_int), .rd_pst_n_erased(pn_era), .rd_pst_max_flips(p_max), .rd_pst_tot_flips(p_tot),
    .rd_pst_all_erased(p_alle), .rd_pst_bbm(p_bbm), .rd_pst_ok(p_ok), .rd_pst_scrub(p_scrub),
    .rd_pst_frame_err(p_ferr),
    .ev_corrected(ev_c), .ev_uncorr(ev_u), .ev_integrity(ev_i), .ev_scrub(ev_s), .irq, .enc_busy(ebusy),
    .dec_busy(dbusy));

  // ------------------------------------------------------------------ drivers
  always @(posedge clk) begin
    if (!rst_n) begin
      wp_pg <= start_pg; wp_b <= 0; wp_v <= 1'b0;
      wu_pg <= start_pg; wu_b <= 0; wu_v <= 1'b0;
      rr_pg <= start_pg; rr_b <= 0; rr_v <= 1'b0;
    end else begin
      r0 <= tb_xs(r0); r1 <= tb_xs(r1); r2 <= tb_xs(r2);
      if (wp_v && wp_r) begin
        if (wp_b == DATA - 1) begin wp_b <= 0; wp_pg <= wp_pg + 1; end else wp_b <= wp_b + 1;
        wp_v <= ((wp_b != DATA - 1) || (wp_pg + 1 < stop_pg)) && !tb_hit(r0, bp);
      end else if (!wp_v) wp_v <= (wp_pg < stop_pg) && !tb_hit(r0, bp);
      if (UM > 0) begin
        if (wu_v && wu_r) begin
          if (wu_b == S * UM - 1) begin wu_b <= 0; wu_pg <= wu_pg + 1; end else wu_b <= wu_b + 1;
          wu_v <= ((wu_b != S * UM - 1) || (wu_pg + 1 < stop_pg)) && !tb_hit(r1, bp);
        end else if (!wu_v) wu_v <= (wu_pg < stop_pg) && !tb_hit(r1, bp);
      end
      if (rr_v && rr_r) begin
        if (rr_b == RAW - 1) begin rr_b <= 0; rr_pg <= rr_pg + 1; end else rr_b <= rr_b + 1;
        rr_v <= ((rr_b != RAW - 1) || (rr_pg + 1 < stop_pg)) && !tb_hit(r2, bp);
      end else if (!rr_v) rr_v <= (rr_pg < stop_pg) && !tb_hit(r2, bp);
    end
  end

  // ------------------------------------------------------------------ checkers
  integer wr_pg, wr_b, rp_pg, rp_b, ru_pg, ru_b, ss_pg, ss_s, ps_pg, n_pages_done, n_enc_done;
  integer e_corr = 0, e_unc = 0, e_int = 0, e_era = 0, e_bits = 0, e_scrub = 0, e_cw = 0;
  // written only by the checker process (reset with rst_n) -- see docs/06 §6 on a Verilator 5.020 quirk
  integer e_maxf, e_pgdone;
  reg [31:0] e_lastfail;
  integer cnt_code [0:7];
  integer first_in = -1, last_ps = -1, last_wr = -1, first_wr_in = -1;
  task automatic fail(input [8*64-1:0] what, input integer pg, input integer idx, input integer got, input integer exp);
    begin
      errors = errors + 1;
      if (errors <= 20) $display("ERROR %0s page %0d idx %0d got %0h exp %0h (cyc %0d)", what, pg, idx, got, exp, cyc);
    end
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      wr_pg <= start_pg; wr_b <= 0; rp_pg <= start_pg; rp_b <= 0; ru_pg <= start_pg; ru_b <= 0;
      ss_pg <= start_pg; ss_s <= 0; ps_pg <= start_pg; n_pages_done <= 0; n_enc_done <= 0;
      e_maxf = 0; e_pgdone = 0; e_lastfail = 32'd0;
      wr_r <= 1'b0; rp_r <= 1'b0; ru_r <= 1'b0; ss_r <= 1'b0; ps_r <= 1'b0;
    end else begin
      r3 <= tb_xs(r3); r4 <= tb_xs(r4); r5 <= tb_xs(r5); r6 <= tb_xs(r6); r7 <= tb_xs(r7);
      wr_r <= !tb_hit(r3, bp); rp_r <= !tb_hit(r4, bp); ru_r <= !tb_hit(r5, bp);
      ss_r <= !tb_hit(r6, bp); ps_r <= !tb_hit(r7, bp);
      // program path: raw page == reference
      if (wr_v && wr_r) begin
        checks = checks + 1;
        if (wr_d !== vb[wr_pg * PB + O_RAW + wr_b]) fail("raw page", wr_pg, wr_b, wr_d, vb[wr_pg * PB + O_RAW + wr_b]);
        if (wr_l !== (wr_b == RAW - 1)) fail("raw last", wr_pg, wr_b, wr_l, wr_b == RAW - 1);
        if (wr_b == RAW - 1) begin wr_b <= 0; wr_pg <= wr_pg + 1; n_enc_done <= n_enc_done + 1; last_wr = cyc; end
        else wr_b <= wr_b + 1;
      end
      // read path
      if (rp_v && rp_r) begin
        checks = checks + 1;
        if (rp_d !== vb[rp_pg * PB + O_PAY + rp_b]) fail("payload", rp_pg, rp_b, rp_d, vb[rp_pg * PB + O_PAY + rp_b]);
        if (rp_l !== (rp_b == DATA - 1)) fail("payload last", rp_pg, rp_b, rp_l, rp_b == DATA - 1);
        if (rp_b == DATA - 1) begin rp_b <= 0; rp_pg <= rp_pg + 1; end else rp_b <= rp_b + 1;
      end
      if (ru_v && ru_r) begin
        checks = checks + 1;
        if (ru_d !== vb[ru_pg * PB + O_UMO + ru_b]) fail("umeta", ru_pg, ru_b, ru_d, vb[ru_pg * PB + O_UMO + ru_b]);
        if (ru_b == S * UM - 1) begin ru_b <= 0; ru_pg <= ru_pg + 1; end else ru_b <= ru_b + 1;
      end
      if (ss_v && ss_r) begin : sschk
        reg [31:0] v;
        v = vs[ss_pg * SW_ + ss_s];
        checks = checks + 1;
        if (ss_code !== v[2:0])   fail("sector code", ss_pg, ss_s, ss_code, v[2:0]);
        if (ss_nerr !== v[15:8])  fail("sector nerr", ss_pg, ss_s, ss_nerr, v[15:8]);
        if (ss_crc !== v[16])     fail("sector crc_ok", ss_pg, ss_s, ss_crc, v[16]);
        if (ss_sec !== ss_s[7:0]) fail("sector index", ss_pg, ss_s, ss_sec, ss_s);
        cnt_code[ss_code] = cnt_code[ss_code] + 1;
        e_cw = e_cw + 1; e_bits = e_bits + v[15:8];
        if (v[15:8] > e_maxf) e_maxf = v[15:8];
        if (v[2:0] == `SFECC_SS_UNCORR || v[2:0] == `SFECC_SS_INTEGRITY)
          e_lastfail = {e_pgdone[20:0], v[2:0], ss_s[7:0]};
        if (v[2:0] == `SFECC_SS_CORRECTED) e_corr = e_corr + 1;
        if (v[2:0] == `SFECC_SS_UNCORR)    e_unc = e_unc + 1;
        if (v[2:0] == `SFECC_SS_INTEGRITY) e_int = e_int + 1;
        if (v[2:0] == `SFECC_SS_ERASED)    e_era = e_era + 1;
        if (ss_s == S - 1) begin ss_s <= 0; ss_pg <= ss_pg + 1; end else ss_s <= ss_s + 1;
      end
      if (ps_v && ps_r) begin : pschk
        reg [31:0] a, b, c;
        a = vs[ps_pg * SW_ + S]; b = vs[ps_pg * SW_ + S + 1]; c = vs[ps_pg * SW_ + S + 2];
        checks = checks + 1;
        if ({pn_era, pn_int, pn_unc, pn_corr} !== a) fail("page counts", ps_pg, 0, {pn_era, pn_int, pn_unc, pn_corr}, a);
        if ({p_scrub, p_ok, p_alle, p_tot, p_max} !== b[26:0]) fail("page flags", ps_pg, 1, {p_scrub, p_ok, p_alle, p_tot, p_max}, b);
        if (p_bbm !== c[7:0]) fail("page bbm", ps_pg, 2, p_bbm, c[7:0]);
        if (p_ferr !== 1'b0) fail("page frame_err", ps_pg, 3, p_ferr, 0);
        if (b[26]) e_scrub = e_scrub + 1;
        last_ps = cyc;
        e_pgdone = e_pgdone + 1;
        ps_pg <= ps_pg + 1;
        n_pages_done <= n_pages_done + 1;
      end
    end
  end
  always @(posedge clk) if (rst_n && rr_v && rr_r && first_in < 0) first_in = cyc;
  always @(posedge clk) if (rst_n && wp_v && wp_r && first_wr_in < 0) first_wr_in = cyc;

  // ------------------------------------------------------------------ helpers
  task automatic do_reset(input integer n);
    begin
      @(negedge clk) rst_n = 1'b0;
      repeat (n) @(negedge clk);
      rst_n = 1'b1;
    end
  endtask
  task automatic wait_done(input integer npg);
    integer t0;
    begin
      t0 = cyc;
      while (!(n_pages_done >= npg && n_enc_done >= npg) && (cyc - t0) < 50000000) @(posedge clk);
      if (cyc - t0 >= 50000000) begin errors = errors + 1; $display("ERROR timeout %0d/%0d pages", n_pages_done, npg); end
      repeat (4) @(posedge clk);
    end
  endtask
  task automatic rb_read(input [7:0] a, output [31:0] d);
    begin
      @(negedge clk) rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a;
      #1 d = rb_rdata;
      @(negedge clk) rb_sel = 1'b0;
    end
  endtask
  task automatic rb_write(input [7:0] a, input [31:0] d);
    begin
      @(negedge clk) rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d;
      @(negedge clk) rb_sel = 1'b0; rb_we = 1'b0;
    end
  endtask
  task automatic rb_expect(input [7:0] a, input [31:0] e, input [8*32-1:0] name);
    reg [31:0] d;
    begin
      rb_read(a, d);
      checks = checks + 1;
      if (d !== e) begin errors = errors + 1; $display("ERROR register %0s @%02h got %0d exp %0d", name, a, d, e); end
    end
  endtask

  integer perf_pages, t_dec, t_enc, k, nrst, fd, npr;
  reg [31:0] rd;
  initial begin
    if (!$value$plusargs("VEC=%s", vdir)) vdir = ".";
    if (!$value$plusargs("OUT=%s", outf)) outf = "tb_sfecc_page.json";
    if (!$value$plusargs("BP=%d", bp)) bp = 30;
    if (!$value$plusargs("NRST=%d", nrst)) nrst = 6;
    if (!$value$plusargs("MAXPAGE=%d", npr)) npr = NP;
    if (npr > NP) npr = NP;
    $readmemh({vdir, "/page_bytes.memh"}, vb);
    $readmemh({vdir, "/page_st.memh"}, vs);
    r0 = 32'h1; r1 = 32'h22; r2 = 32'h333; r3 = 32'h4444; r4 = 32'h5555; r5 = 32'h666; r6 = 32'h77; r7 = 32'h8;
    for (k = 0; k < 8; k = k + 1) cnt_code[k] = 0;
    $display("TB tb_sfecc_page cfg %0s: %0d pages of %0d+%0d B, %0d sectors, umeta %0d", `TBP_CFG_NAME, NP, DATA,
             SPARE, S, UM);
    // ---------------- identification / configuration registers
    do_reset(3);
    rb_expect(8'h00, `SFECC_ID, "ID");
    rb_expect(8'h04, `SFECC_VERSION, "VERSION");
    rb_expect(8'h08, {12'(S), 4'(dut.CODEC), 8'(dut.T), 8'(dut.GF_M)}, "CFG0");
    rb_expect(8'h14, {8'd0, 8'(dut.FLIP_THR), 16'd0}, "CTRL reset value");
    rb_expect(8'h18, 32'd0, "STATUS idle");
    rb_expect(8'h1C, 32'd0, "IRQ idle");
    rb_expect(8'h0C, {8'(UM), 8'(dut.PAR_BYTES), 16'(DATA / S)}, "CFG1");
    rb_expect(8'h10, {16'(SPARE), 16'(DATA)}, "CFG2");
    // ---------------- PERF: no back-pressure
    k = bp; bp = 0;
    perf_pages = (npr < 8) ? npr : 8;
    start_pg = 0; stop_pg = perf_pages;
    do_reset(2);
    first_in = -1; first_wr_in = -1;
    wait_done(perf_pages);
    t_dec = last_ps - first_in + 1;
    t_enc = last_wr - first_wr_in + 1;
    $display("TB PERF %0d pages: decode %0d cycles (%0.3f raw B/cycle), encode %0d cycles (%0.3f raw B/cycle)",
             perf_pages, t_dec, (1.0 * perf_pages * RAW) / t_dec, t_enc, (1.0 * perf_pages * RAW) / t_enc);
    // ---------------- MAIN: every page, back-pressure, then the statistics registers
    bp = k;
    start_pg = 0; stop_pg = npr;
    e_corr = 0; e_unc = 0; e_int = 0; e_era = 0; e_bits = 0; e_scrub = 0; e_cw = 0;
    do_reset(2);
    rb_write(8'h14, {8'd0, 8'(dut.FLIP_THR), 7'd0, 1'b1, 8'd0});    // IRQ enable, threshold unchanged
    wait_done(npr);
    rb_expect(8'h20, npr, "PAGES_ENC");
    rb_expect(8'h24, npr, "PAGES_DEC");
    rb_expect(8'h28, e_cw, "CW_DEC");
    rb_expect(8'h2C, e_corr, "CW_CORRECTED");
    rb_expect(8'h30, e_bits, "BITS_CORRECTED");
    rb_expect(8'h34, e_unc, "CW_UNCORR");
    rb_expect(8'h38, e_int, "CW_INTEGRITY");
    rb_expect(8'h3C, e_era, "CW_ERASED");
    rb_expect(8'h40, e_scrub, "PAGES_SCRUB");
    rb_expect(8'h44, e_lastfail, "LAST_FAIL");
    rb_expect(8'h48, e_maxf, "MAX_FLIPS");
    rb_expect(8'h1C, (e_unc + e_int > 0) ? 32'd1 : 32'd0, "IRQ pending");
    checks = checks + 1;
    if (irq !== ((e_unc + e_int > 0) ? 1'b1 : 1'b0)) begin errors = errors + 1; $display("ERROR irq pin"); end
    rb_write(8'h1C, 32'd1);                             // W1C
    rb_expect(8'h1C, 32'd0, "IRQ after W1C");
    rb_write(8'h14, 32'h0000_0001);                     // clear counters
    rb_expect(8'h28, 0, "CW_DEC after clear");
    $display("TB MAIN %0d pages / %0d codewords: CLEAN %0d CORRECTED %0d ERASED %0d UNCORR %0d INTEGRITY %0d",
             npr, e_cw, cnt_code[0], cnt_code[1], cnt_code[2], cnt_code[3], cnt_code[4]);
    // ---------------- RESET in the middle of pages
    for (k = 0; k < nrst; k = k + 1) begin
      start_pg = (k * 7) % npr; stop_pg = (start_pg + 3 < npr) ? start_pg + 3 : npr;
      do_reset(2);
      repeat (50 + k * (RAW / 3)) @(posedge clk);
      do_reset(1 + k % 3);
      wait_done(stop_pg - start_pg);
    end
    fd = $fopen(outf, "w");
    $fwrite(fd, "{\"cfg\": \"%0s\", \"pages\": %0d, \"sectors\": %0d, \"perf_pages\": %0d, \"dec_cycles\": %0d, \"enc_cycles\": %0d, \"raw_bytes\": %0d, ",
            `TBP_CFG_NAME, NP, S, perf_pages, t_dec, t_enc, RAW);
    $fwrite(fd, "\"sector_codes\": [%0d,%0d,%0d,%0d,%0d], \"resets\": %0d, \"checks\": %0d, \"errors\": %0d}\n",
            cnt_code[0], cnt_code[1], cnt_code[2], cnt_code[3], cnt_code[4], nrst, checks, errors);
    $fclose(fd);
    $display("TB RESULT tb_sfecc_page cfg=%0s pages=%0d checks=%0d errors=%0d -> %0s", `TBP_CFG_NAME, npr, checks,
             errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule

`default_nettype wire
