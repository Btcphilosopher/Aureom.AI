"""
sfecc_ldpc.py -- LDPC proof-of-concept reference (SilicaFlux Project 54, ECCCore).

A deliberately SMALL quasi-cyclic LDPC code used to prove the replaceable codec interface
and a soft-decision iterative decoder in RTL.  It is not a NAND-grade LDPC code (those use
n = 9k..36k bits, Z = 64..512, rate 0.88..0.94, see docs/05_LDPC_RESEARCH.md).

Code: QC-LDPC(128, 64), lifting Z = 16, base matrix 4 x 8, H = [H_I | H_P]
  H_I  4 x 4 circulant permutation blocks (column weight 4) with shifts found by a seeded search
       that rejects every 4-cycle (girth >= 6, checked independently);
  H_P  lower bidiagonal staircase of identity blocks -> invertible, k = 64 exactly, and
       linear-time "accumulate" encoding: p_0 = s_0, p_r = s_r + p_{r-1}, s_r = H_I,r u.
Codeword c = [u (64 bits) | p (64 bits)]; byte b, MSB first, holds c[8b .. 8b+7].
Erased-page mask: stored parity = p XOR MASK, MASK = p(1^64) XOR 1^64, so an all-ones stored
word is a valid codeword (same scheme as the BCH codec).

Decoders
  decode_bp_float   flooding sum-product (tanh rule) in floating point -- the textbook
                    algorithm; cross-checked against pyldpc's independent implementation.
  decode_oms_fixed  layered offset-min-sum in fixed point: BIT-EXACT model of
                    rtl/sfecc_ldpc_dec.sv (LLR_W-bit channel LLRs, 8-bit posteriors, 6-bit
                    check messages, offset 1, layer = one block row of Z checks, early stop
                    when H x = 0, checked before iteration 1 and after every iteration).
LLR convention: positive = bit 0 more likely.
"""
import math
import random
from typing import Dict, List, Optional, Tuple

Z = 16
JB = 4          # block rows (layers)
KB = 8          # block columns
N = Z * KB      # 128
K = N - Z * JB  # 64
P_W = 8         # posterior width (signed, saturating)
R_W = 6         # check-message width (signed, |R| <= 31)
P_MAX = (1 << (P_W - 1)) - 1
R_MAX = (1 << (R_W - 1)) - 1
OFFSET = 1


def search_shifts(seed: int = 54, tries: int = 20000) -> List[List[int]]:
    """Info-part shifts with no 4-cycle anywhere in H (including against the staircase)."""
    rnd = random.Random(seed)
    for _ in range(tries):
        B = staircase_base([[rnd.randrange(Z) for _ in range(4)] for _ in range(JB)])
        if not has_4cycle(B):
            return B
    raise RuntimeError("no 4-cycle-free base matrix found")


def staircase_base(info: List[List[int]]) -> List[List[int]]:
    B = [[-1] * KB for _ in range(JB)]
    for r in range(JB):
        for c in range(4):
            B[r][c] = info[r][c]
        B[r][4 + r] = 0
        if r >= 1:
            B[r][4 + r - 1] = 0
    return B


def has_4cycle(B) -> bool:
    for r1 in range(JB):
        for r2 in range(r1 + 1, JB):
            for c1 in range(KB):
                for c2 in range(c1 + 1, KB):
                    a, b, c, d = B[r1][c1], B[r1][c2], B[r2][c1], B[r2][c2]
                    if min(a, b, c, d) < 0:
                        continue
                    if (a - b + d - c) % Z == 0:
                        return True
    return False


class QCLDPC:
    def __init__(self, base: Optional[List[List[int]]] = None, seed: int = 54):
        self.B = base or search_shifts(seed)
        # check rows: list of variable indices (in block-column order)
        self.rows: List[List[int]] = []
        for l in range(JB):
            for r in range(Z):
                vs = []
                for c in range(KB):
                    s = self.B[l][c]
                    if s >= 0:
                        vs.append(c * Z + (r + s) % Z)
                self.rows.append(vs)
        self.cols: List[List[int]] = [[] for _ in range(N)]
        for i, vs in enumerate(self.rows):
            for v in vs:
                self.cols[v].append(i)
        ones = [1] * K
        self.mask = self._parity(ones)               # p(1^k); stored = p ^ mask ^ ... see below
        self.mask = [b ^ 1 for b in self.mask]       # MASK = p(1^k) XOR 1

    # ---------------------------------------------------------------- structure
    def H_dense(self) -> List[List[int]]:
        H = [[0] * N for _ in range(len(self.rows))]
        for i, vs in enumerate(self.rows):
            for v in vs:
                H[i][v] = 1
        return H

    def syndrome(self, x: List[int]) -> List[int]:
        return [sum(x[v] for v in vs) & 1 for vs in self.rows]

    def is_codeword(self, x: List[int]) -> bool:
        return not any(self.syndrome(x))

    def _parity(self, u: List[int]) -> List[int]:
        """Accumulate encoding through the staircase."""
        p = [0] * (N - K)
        prev = [0] * Z
        for l in range(JB):
            blk = []
            for r in range(Z):
                s = 0
                for c in range(4):
                    sh = self.B[l][c]
                    s ^= u[c * Z + (r + sh) % Z]
                blk.append(s ^ prev[r])
            p[l * Z:(l + 1) * Z] = blk
            prev = blk
        return p

    def encode_bits(self, u: List[int]) -> List[int]:
        return list(u) + self._parity(u)

    def stored_bits(self, u: List[int]) -> List[int]:
        c = self.encode_bits(u)
        return c[:K] + [a ^ m for a, m in zip(c[K:], self.mask)]

    def generator_parity_rows(self) -> List[int]:
        """Row i = parity of unit message e_i, as a 64-bit int (bit j = parity bit j)."""
        rows = []
        for i in range(K):
            u = [0] * K
            u[i] = 1
            p = self._parity(u)
            rows.append(sum(b << j for j, b in enumerate(p)))
        return rows

    # ---------------------------------------------------------------- bytes
    @staticmethod
    def bits_to_bytes(bits: List[int]) -> bytes:
        return bytes(sum(bits[8 * b + j] << (7 - j) for j in range(8)) for b in range(len(bits) // 8))

    @staticmethod
    def bytes_to_bits(data: bytes) -> List[int]:
        return [(x >> (7 - j)) & 1 for x in data for j in range(8)]

    def encode(self, msg: bytes) -> bytes:
        assert len(msg) == K // 8
        return msg + self.bits_to_bytes(self.stored_bits(self.bytes_to_bits(msg))[K:])

    # ---------------------------------------------------------------- decoders
    def stored_llr_to_code(self, llr: List[float]) -> List[float]:
        """Remove the erased-page mask: negate parity LLRs where MASK = 1."""
        return [(-v if (i >= K and self.mask[i - K]) else v) for i, v in enumerate(llr)]

    def decode_bp_float(self, llr: List[float], maxit: int = 50) -> Tuple[List[int], bool, int]:
        """Flooding sum-product on codeword (mask-removed) LLRs."""
        m = {(i, v): 0.0 for i, vs in enumerate(self.rows) for v in vs}     # check -> var
        x = [1 if v < 0 else 0 for v in llr]
        if self.is_codeword(x):
            return x, True, 0
        for it in range(1, maxit + 1):
            # variable -> check
            q = {}
            for v in range(N):
                tot = llr[v] + sum(m[(i, v)] for i in self.cols[v])
                for i in self.cols[v]:
                    q[(i, v)] = tot - m[(i, v)]
            for i, vs in enumerate(self.rows):
                th = [math.tanh(max(-30.0, min(30.0, q[(i, v)])) / 2.0) for v in vs]
                for k, v in enumerate(vs):
                    prod = 1.0
                    for kk, t in enumerate(th):
                        if kk != k:
                            prod *= t
                    prod = max(-0.999999999999, min(0.999999999999, prod))
                    m[(i, v)] = 2.0 * math.atanh(prod)
            post = [llr[v] + sum(m[(i, v)] for i in self.cols[v]) for v in range(N)]
            x = [1 if p < 0 else 0 for p in post]
            if self.is_codeword(x):
                return x, True, it
        return x, False, maxit

    def decode_oms_fixed(self, llr_q: List[int], maxit: int = 20, trace: Optional[list] = None) -> Dict:
        """Bit-exact model of rtl/sfecc_ldpc_dec.sv.  llr_q: integer channel LLRs for the
        STORED word (mask is removed here, as the RTL does)."""
        L = self.stored_llr_to_code(llr_q)
        P = [max(-P_MAX, min(P_MAX, int(v))) for v in L]
        R = {}                          # (row, v) -> int
        x_in = [1 if v < 0 else 0 for v in P]

        def hard():
            return [1 if p < 0 else 0 for p in P]

        it_used = 0
        ok = self.is_codeword(hard())
        while not ok and it_used < maxit:
            it_used += 1
            for l in range(JB):
                for r in range(Z):
                    i = l * Z + r
                    vs = self.rows[i]
                    Q = [max(-P_MAX, min(P_MAX, P[v] - R.get((i, v), 0))) for v in vs]
                    sg = [1 if q < 0 else 0 for q in Q]
                    mg = [min(abs(q), R_MAX) for q in Q]
                    stot = 0
                    for s in sg:
                        stot ^= s
                    min1, idx1 = R_MAX + 1, -1
                    for k, mm in enumerate(mg):
                        if mm < min1:
                            min1, idx1 = mm, k
                    min2 = R_MAX + 1
                    for k, mm in enumerate(mg):
                        if k != idx1 and mm < min2:
                            min2 = mm
                    for k, v in enumerate(vs):
                        mag = min2 if k == idx1 else min1
                        mag = max(min(mag, R_MAX) - OFFSET, 0)
                        val = -mag if (stot ^ sg[k]) else mag
                        R[(i, v)] = val
                        P[v] = max(-P_MAX, min(P_MAX, Q[k] + val))
            ok = self.is_codeword(hard())
            if trace is not None:
                trace.append((it_used, list(P)))
        x = hard()
        nerr = sum(a ^ b for a, b in zip(x, x_in))
        stored = x[:K] + [a ^ m for a, m in zip(x[K:], self.mask)]
        if not ok:
            code = 3
        elif all(stored):
            code = 2
        elif it_used == 0:
            code = 0
        else:
            code = 1
        return dict(bits=x, ok=ok, iters=it_used, nerr=(0 if code == 3 else min(nerr, 255)), code=code,
                    msg=self.bits_to_bytes(x[:K]))


def hard_llr(stored_bits: List[int], mag: int = 15) -> List[int]:
    return [(-mag if b else mag) for b in stored_bits]


def quantize(llr: List[float], scale: float, bits: int = 5) -> List[int]:
    lim = (1 << (bits - 1)) - 1
    return [max(-lim, min(lim, int(round(v * scale)))) for v in llr]


class LDPCFormat:
    """Byte framing of the LDPC proof of concept with the same API as BCHFormat, so the page
    reference (sfecc_page.PageFormat) can use either codec -- the reference side of the
    replaceable codec interface.  Hard-decision decoding (+-15 LLRs), as the page engine feeds."""

    def __init__(self, name: str = "LDPC"):
        self.name = name
        self.code = QCLDPC()
        self.msg_bytes, self.par_bytes, self.cw_bytes = K // 8, (N - K) // 8, N // 8
        self.lpad = self.tpad = 0
        self.k, self.r, self.ns, self.t, self.m = K, N - K, N, 2, None   # t: nominal, for test planning only

    def encode(self, msg: bytes) -> bytes:
        return self.code.encode(msg)

    def decode(self, cw: bytes):
        r = self.code.decode_oms_fixed(hard_llr(QCLDPC.bytes_to_bits(cw), 15))
        return r["msg"], dict(code=r["code"], nerr=r["nerr"], ok=r["ok"], iters=r["iters"], L=r["nerr"],
                              positions=[])

    def valid_stream_bits(self):
        return list(range(N))

    def stream_bit_degree(self, s):
        return s if 0 <= s < N else None

    def flip(self, cw: bytes, stream_bits) -> bytes:
        b = bytearray(cw)
        for s in stream_bits:
            b[s >> 3] ^= 0x80 >> (s & 7)
        return bytes(b)

    def nonzero_codeword_bits(self, rnd) -> List[int]:
        """Stream bits of a non-zero codeword (adding it maps a stored codeword to another one)."""
        u = [0] * K
        u[rnd.randrange(K)] = 1
        c = self.code.encode_bits(u)
        return [i for i, v in enumerate(c) if v]

    def describe(self):
        return dict(name=self.name, codec="LDPC", n=N, k=K, msg_bytes=self.msg_bytes, par_bytes=self.par_bytes)
