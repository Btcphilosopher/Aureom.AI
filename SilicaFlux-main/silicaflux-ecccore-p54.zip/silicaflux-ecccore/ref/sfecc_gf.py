"""
sfecc_gf.py -- GF(2^m) arithmetic reference (SilicaFlux Project 54, ECCCore).

Representation
--------------
An element of GF(2^m) is an integer 0 <= a < 2^m whose bit i is the coefficient of
alpha^i in the polynomial basis {1, alpha, ..., alpha^(m-1)}, where alpha is a root of
the primitive polynomial p(x) (bit m of `prim` set, bit i = coefficient of x^i).

Two independent multiplication paths are provided:
  * mul()      -- log/antilog tables (fast path used by the BCH reference);
  * mul_poly() -- carry-less shift-and-add multiplication followed by reduction
                  modulo p(x) (the same bit-serial algorithm the RTL uses).
The validation script checks that both agree exhaustively for m <= 10 and on random
samples otherwise, and that alpha has multiplicative order exactly 2^m - 1.
"""

from typing import List

# Default primitive polynomials.  They are the defaults of the Linux kernel BCH library
# (lib/bch.c, prim_poly_tab) for m = 5..15 and the polynomial used by Lin & Costello's
# BCH tables for m = 8 (x^8+x^4+x^3+x^2+1, octal 435).
DEFAULT_PRIM = {
    3: 0x0B, 4: 0x13, 5: 0x25, 6: 0x43, 7: 0x83, 8: 0x11D, 9: 0x211, 10: 0x409,
    11: 0x805, 12: 0x1053, 13: 0x201B, 14: 0x402B, 15: 0x8003, 16: 0x1002D,
}


def prime_factors(n: int) -> List[int]:
    out, d = [], 2
    while d * d <= n:
        if n % d == 0:
            out.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        out.append(n)
    return out


def poly_str(p: int, var: str = "x") -> str:
    terms = []
    for d in range(p.bit_length() - 1, -1, -1):
        if (p >> d) & 1:
            terms.append("1" if d == 0 else (var if d == 1 else f"{var}^{d}"))
    return " + ".join(terms) if terms else "0"


class GF2m:
    def __init__(self, m: int, prim: int = None):
        if not 2 <= m <= 16:
            raise ValueError("m must be in 2..16")
        prim = DEFAULT_PRIM[m] if prim is None else prim
        if prim.bit_length() != m + 1:
            raise ValueError(f"primitive polynomial 0x{prim:x} is not of degree {m}")
        self.m, self.prim, self.n, self.size = m, prim, (1 << m) - 1, 1 << m
        exp = [0] * (2 * self.n + 2)
        log = [-1] * self.size
        x = 1
        for i in range(self.n):
            if log[x] != -1:
                raise ValueError(f"0x{prim:x} is not primitive over GF(2): alpha has order {i}")
            exp[i] = x
            log[x] = i
            x <<= 1
            if x >> m:
                x ^= prim
        if x != 1:
            raise ValueError(f"0x{prim:x}: alpha^(2^m-1) != 1")
        for i in range(self.n, len(exp)):
            exp[i] = exp[i - self.n]
        self.exp, self.log = exp, log

    # ------------------------------------------------------------------ basic ops
    def mul(self, a: int, b: int) -> int:
        if a == 0 or b == 0:
            return 0
        return self.exp[self.log[a] + self.log[b]]

    def mul_poly(self, a: int, b: int) -> int:
        """Bit-serial shift-and-add multiplication modulo p(x) (table-free)."""
        p, aa = 0, a
        for i in range(self.m):
            if (b >> i) & 1:
                p ^= aa
            aa <<= 1
            if aa >> self.m:
                aa ^= self.prim
        return p

    def sq(self, a: int) -> int:
        return self.mul(a, a)

    def inv(self, a: int) -> int:
        if a == 0:
            raise ZeroDivisionError("inverse of 0 in GF(2^m)")
        return self.exp[(self.n - self.log[a]) % self.n]

    def div(self, a: int, b: int) -> int:
        return self.mul(a, self.inv(b))

    def alpha(self, e: int) -> int:
        """alpha^e for any integer e (negative allowed)."""
        return self.exp[e % self.n]

    def pow(self, a: int, e: int) -> int:
        if a == 0:
            return 0 if e > 0 else 1
        return self.exp[(self.log[a] * e) % self.n]

    # ------------------------------------------------------------------ polynomials over GF(2^m)
    # coefficient lists, index = degree
    def poly_eval(self, c: List[int], x: int) -> int:
        acc = 0
        for coef in reversed(c):
            acc = self.mul(acc, x) ^ coef
        return acc

    def poly_mul(self, a: List[int], b: List[int]) -> List[int]:
        out = [0] * (len(a) + len(b) - 1)
        for i, ai in enumerate(a):
            if ai:
                for j, bj in enumerate(b):
                    if bj:
                        out[i + j] ^= self.mul(ai, bj)
        return out

    def minimal_poly(self, i: int) -> int:
        """Minimal polynomial of alpha^i over GF(2) as a binary bitmask (bit d = coef x^d)."""
        coset = cyclotomic_coset(i, self.m)
        poly = [1]
        for j in coset:
            poly = self.poly_mul(poly, [self.alpha(j), 1])
        bits = 0
        for d, c in enumerate(poly):
            if c not in (0, 1):
                raise ArithmeticError("minimal polynomial has a non-binary coefficient")
            bits |= c << d
        return bits

    def is_primitive_order(self) -> bool:
        """Independent primitivity test: x^((2^m-1)/q) != 1 mod p(x) for every prime q | 2^m-1."""
        for q in prime_factors(self.n):
            if self.pow(2, self.n // q) == 1:      # element 2 == alpha in polynomial basis
                return False
        return self.pow(2, self.n) == 1


def cyclotomic_coset(i: int, m: int) -> List[int]:
    n = (1 << m) - 1
    out, j = [], i % n
    while j not in out:
        out.append(j)
        j = (2 * j) % n
    return out


def gf2_poly_mul(a: int, b: int) -> int:
    """Carry-less product of binary polynomials (bitmasks)."""
    out = 0
    while b:
        if b & 1:
            out ^= a
        a <<= 1
        b >>= 1
    return out


def gf2_poly_mod(a: int, g: int) -> int:
    dg = g.bit_length() - 1
    while a.bit_length() - 1 >= dg:
        a ^= g << (a.bit_length() - 1 - dg)
    return a
