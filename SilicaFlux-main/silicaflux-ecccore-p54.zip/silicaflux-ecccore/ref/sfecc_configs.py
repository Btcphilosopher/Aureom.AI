"""
sfecc_configs.py -- named ECCCore configurations (single source of truth).

B255T4  verification baseline: primitive narrow-sense BCH(255,223), t = 4, GF(2^8),
        unshortened.  28 message bytes with one leading pad bit (223 = 28*8 - 1),
        4 parity bytes (r = 32).
N512T4  512 B sector, GF(2^13), t = 4 (the NANDLab twin's ONFI 'ECC bits required' = 4 per
        512 B), 6 B user metadata + CRC-16, shortened BCH(4212, 4160): 512+16 B page.
N512T8  512 B sector, GF(2^13), t = 8, CRC-16, shortened BCH(4216, 4112): one 16 B slot per
        sector -> 512+16 B and 2048+64 B pages (1 or 4 codewords per page).
N1KT40  scalability study: 1 KiB sector, GF(2^14), t = 40, 20 B user meta + CRC-16,
        8192+744 B page.  Reference + synthesis + short RTL run; NOT a claim that
        BCH-40 suffices for modern TLC/QLC (see docs/05_LDPC_RESEARCH.md).
"""

from sfecc_bch import BCHFormat
from sfecc_page import PageFormat

CORE_CONFIGS = {
    "B255T4": dict(m=8, t=4, msg_bytes=28, lpad=1),
}

PAGE_CONFIGS = {
    "N512T4":    dict(page_data=512,  page_spare=16,  sector=512,  umeta=6,  crc_bytes=2, m=13, t=4),
    "N512T8":    dict(page_data=512,  page_spare=16,  sector=512,  umeta=0,  crc_bytes=2, m=13, t=8),
    "N2KT8":     dict(page_data=2048, page_spare=64,  sector=512,  umeta=0,  crc_bytes=2, m=13, t=8),
    "N8KT40":    dict(page_data=8192, page_spare=744, sector=1024, umeta=20, crc_bytes=2, m=14, t=40),
    # replaceable-codec demonstration: the page engine with the LDPC proof-of-concept codec
    # (8-byte message = 6-byte sector + CRC-16; slot = 1 + 2 + 8 = 11 B)
    "L24":       dict(page_data=24,   page_spare=44,  sector=6,    umeta=0,  crc_bytes=2, m=None, t=None,
                      codec="LDPC"),
}


def core(name: str) -> BCHFormat:
    if name in CORE_CONFIGS:
        c = CORE_CONFIGS[name]
        return BCHFormat(c["m"], c["t"], c["msg_bytes"], c["lpad"], None, True, name)
    return page(name).bch


def page(name: str) -> PageFormat:
    c = PAGE_CONFIGS[name]
    codec = None
    if c.get("codec") == "LDPC":
        from sfecc_ldpc import LDPCFormat
        codec = LDPCFormat(name + "_ldpc")
    return PageFormat(name, c["page_data"], c["page_spare"], c["sector"], c["umeta"], c["crc_bytes"],
                      c["m"], c["t"], codec=codec)
