"""
sfecc_page.py -- NAND page format reference (SilicaFlux Project 54, ECCCore).

Split ("ECC in OOB") layout, one BCH codeword per sector:

    column 0                                   PAGE_DATA                      PAGE_DATA+PAGE_SPARE
    | sector 0 | sector 1 | ... | sector S-1 | slot 0 | slot 1 | ... | slot S-1 | unused (0xFF) |
                                              slot i = RSVD | UMETA | CRC | PARITY   (SLOT bytes)

    codeword i (stream order) = sector i (D bytes) || UMETA_i || CRC_i || PARITY_i
    RSVD byte of slot 0 is the bad-block-marker byte (first spare byte) and is never
    ECC-protected; the controller always programs it 0xFF.  RSVD of other slots is 0xFF.

CRC: CRC-16/IBM-3740 ("CCITT-FALSE": poly 0x1021, init 0xFFFF, MSB first, no reflection,
xorout 0) over sector || UMETA.  It is the independent integrity check that detects BCH
miscorrections (decoder "success" with wrong data) and is skipped for erased sectors.

Read order (decode): the RTL page decoder expects the raw page in SPARE-FIRST order
(PAGE_SPARE bytes, then PAGE_DATA bytes): the channel issues Change Read Column to
PAGE_DATA, reads the spare area, then Change Read Column to 0.  The program (encode)
path emits the natural column order 0 .. PAGE_DATA+PAGE_SPARE-1.
"""

from typing import Dict, List, Optional, Tuple

from sfecc_bch import BCHFormat, ST_CLEAN, ST_CORRECTED, ST_ERASED, ST_UNCORR

# sector status codes (page level); 0..3 identical to the BCH codec status
SS_CLEAN, SS_CORRECTED, SS_ERASED, SS_UNCORR, SS_INTEGRITY = 0, 1, 2, 3, 4
SS_NAMES = {0: "CLEAN", 1: "CORRECTED", 2: "ERASED", 3: "UNCORRECTABLE", 4: "INTEGRITY_FAIL"}


def crc16_ccitt_false(data: bytes, crc: int = 0xFFFF) -> int:
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


class PageFormat:
    def __init__(self, name: str, page_data: int, page_spare: int, sector: int, umeta: int,
                 crc_bytes: int, m: int, t: int, prim: Optional[int] = None, rsvd: int = 1, codec=None):
        self.name = name
        self.page_data, self.page_spare, self.sector = page_data, page_spare, sector
        self.umeta, self.crc_bytes, self.rsvd = umeta, crc_bytes, rsvd
        if page_data % sector:
            raise ValueError("page data area is not a whole number of sectors")
        if crc_bytes not in (0, 2):
            raise ValueError("crc_bytes must be 0 or 2")
        self.sectors = page_data // sector
        # the codec behind the replaceable interface: BCH (default) or e.g. sfecc_ldpc.LDPCFormat
        self.bch = codec if codec is not None else BCHFormat(m, t, sector + umeta + crc_bytes, 0, prim, True,
                                                              name + "_bch")
        if self.bch.msg_bytes != sector + umeta + crc_bytes:
            raise ValueError("codec message length != sector + user metadata + CRC")
        self.slot = rsvd + umeta + crc_bytes + self.bch.par_bytes
        self.slot_stride = page_spare // self.sectors
        if self.slot > self.slot_stride:
            raise ValueError(f"OOB overflow: slot needs {self.slot} B, {self.slot_stride} B available "
                             f"per sector ({page_spare} B spare / {self.sectors} sectors)")
        self.raw_bytes = page_data + page_spare

    # ------------------------------------------------------------------ OOB accounting
    def oob_budget(self) -> Dict:
        b = self.bch
        return dict(name=self.name, page=f"{self.page_data}+{self.page_spare}", sectors=self.sectors,
                    sector_bytes=self.sector, slot_stride=self.slot_stride, rsvd=self.rsvd,
                    umeta=self.umeta, crc=self.crc_bytes, parity_bytes=b.par_bytes, parity_bits=b.r,
                    slot_used=self.slot, unused_per_slot=self.slot_stride - self.slot,
                    unused_total=self.page_spare - self.sectors * self.slot,
                    m=b.m, t=b.t, n_bits=b.ns, k_bits=b.k,
                    code_rate=b.k / b.ns, overhead_pct=100.0 * b.par_bytes * self.sectors / self.page_data)

    def slot_base(self, i: int) -> int:
        return self.page_data + i * self.slot_stride

    # ------------------------------------------------------------------ program path
    def encode_page(self, payload: bytes, umeta: Optional[List[bytes]] = None) -> bytes:
        assert len(payload) == self.page_data
        umeta = umeta or [b"\xff" * self.umeta] * self.sectors
        raw = bytearray(b"\xff" * self.raw_bytes)
        for i in range(self.sectors):
            data = payload[i * self.sector:(i + 1) * self.sector]
            um = bytes(umeta[i])
            assert len(um) == self.umeta
            msg = data + um
            if self.crc_bytes:
                msg += crc16_ccitt_false(msg).to_bytes(2, "big")
            cw = self.bch.encode(msg)
            raw[i * self.sector:(i + 1) * self.sector] = data
            base = self.slot_base(i)
            raw[base] = 0xFF                                   # RSVD / BBM byte
            raw[base + self.rsvd:base + self.slot] = cw[self.sector:]
        return bytes(raw)

    def codeword_of(self, raw: bytes, i: int) -> bytes:
        base = self.slot_base(i)
        return raw[i * self.sector:(i + 1) * self.sector] + raw[base + self.rsvd:base + self.slot]

    def codeword_stream_to_raw(self, i: int, s: int) -> int:
        """Codeword i stream bit s -> raw page bit index (column*8 + MSB-first bit)."""
        byte = s >> 3
        if byte < self.sector:
            col = i * self.sector + byte
        else:
            col = self.slot_base(i) + self.rsvd + (byte - self.sector)
        return col * 8 + (s & 7)

    def spare_first(self, raw: bytes) -> bytes:
        return raw[self.page_data:] + raw[:self.page_data]

    # ------------------------------------------------------------------ read path
    def decode_page(self, raw: bytes) -> Tuple[bytes, List[bytes], List[Dict], Dict]:
        assert len(raw) == self.raw_bytes
        payload, umeta_out, sts = bytearray(), [], []
        for i in range(self.sectors):
            cw = self.codeword_of(raw, i)
            msg, st = self.bch.decode(cw)
            data, um = msg[:self.sector], msg[self.sector:self.sector + self.umeta]
            # the CRC comparison is reported for every sector (diagnostic); it only changes the
            # verdict of sectors the decoder claims to have decoded (CLEAN / CORRECTED)
            crc_ok = True
            code = st["code"]
            if self.crc_bytes:
                crc_rx = int.from_bytes(msg[self.sector + self.umeta:], "big")
                crc_ok = crc16_ccitt_false(msg[:self.sector + self.umeta]) == crc_rx
                if not crc_ok and code in (ST_CLEAN, ST_CORRECTED):
                    code = SS_INTEGRITY
            payload += data
            umeta_out.append(bytes(um))
            sts.append(dict(code=code, nerr=st["nerr"], crc_ok=crc_ok, bch=st))
        page = dict(
            n_corrected=sum(1 for s in sts if s["code"] == SS_CORRECTED),
            n_uncorr=sum(1 for s in sts if s["code"] == SS_UNCORR),
            n_integrity=sum(1 for s in sts if s["code"] == SS_INTEGRITY),
            n_erased=sum(1 for s in sts if s["code"] == SS_ERASED),
            max_bitflips=max(s["nerr"] for s in sts),
            total_bitflips=sum(s["nerr"] for s in sts),
            bbm=raw[self.page_data],
        )
        page["all_erased"] = page["n_erased"] == self.sectors
        page["ok"] = page["n_uncorr"] == 0 and page["n_integrity"] == 0
        return bytes(payload), umeta_out, sts, page
