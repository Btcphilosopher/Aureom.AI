"""
sfecc_bch.py -- binary primitive narrow-sense BCH reference model (SilicaFlux Project 54).

Mathematics (see docs/01_MATHEMATICS.md)
----------------------------------------
* Field GF(2^m) with primitive polynomial p(x); n = 2^m - 1.
* Designed distance 2t+1: g(x) = LCM{ M_1(x), M_3(x), ..., M_{2t-1}(x) } where M_i is the
  minimal polynomial of alpha^i (even i are redundant because M_{2i} = M_i).
  r = deg g(x) parity bits, k_full = n - r.
* Shortening: messages of k <= k_full bits are encoded as if the k_full - k highest
  information positions were zero; codeword length ns = k + r.  The minimum distance
  stays >= 2t+1.  A decoder must reject any error-locator root outside [0, ns).
* Systematic encoding: c(x) = u(x) x^r + (u(x) x^r mod g(x)).
* Decoding: S_j = r(alpha^j), j = 1..2t;  key equation solved by
    (A) classic Berlekamp-Massey with inversion (Massey 1969),
    (B) simplified inversionless Berlekamp-Massey -- t iterations, the HARDWARE algorithm,
    (C) Sugiyama's extended-Euclid algorithm,
  Chien search over the ns valid positions, success iff L <= t and the number of distinct
  roots in [0, ns) equals L.  (A), (B), (C) are cross-checked in scripts/validate_ref.py.

Bit / byte conventions (shared with the RTL)
--------------------------------------------
A codeword is stored as MSG_BYTES message bytes followed by PAR_BYTES parity bytes,
most significant bit first.  Stream bit s = 8*byte + (7 - bitpos).  The first LPAD
stream bits are padding (not part of the code), the last TPAD stream bits are padding.
Stream bit s (LPAD <= s < LPAD + ns) is the coefficient of x^(ns - 1 + LPAD - s):
message bits occupy degrees ns-1 .. r, parity bits degrees r-1 .. 0.

Erased-page handling ("ECC mask", the scheme of Linux nand_bch): the stored parity is
p(u) XOR MASK with MASK = p(1^k) XOR 1^r.  Because the code is linear, an all-ones
(erased) message with all-ones stored parity is then a valid codeword, so erased pages
with up to t bit flips are corrected like any other page.  Padding bits are written 1.
"""

from typing import Dict, List, Optional, Tuple

from sfecc_gf import GF2m, cyclotomic_coset, gf2_poly_mod, gf2_poly_mul

ST_CLEAN, ST_CORRECTED, ST_ERASED, ST_UNCORR = 0, 1, 2, 3
ST_NAMES = {ST_CLEAN: "CLEAN", ST_CORRECTED: "CORRECTED", ST_ERASED: "ERASED", ST_UNCORR: "UNCORRECTABLE"}


class BCHCode:
    """Binary primitive narrow-sense BCH code, optionally shortened, bit level."""

    def __init__(self, m: int, t: int, prim: Optional[int] = None, k: Optional[int] = None):
        self.gf = GF2m(m, prim)
        self.m, self.t, self.n, self.prim = m, t, self.gf.n, self.gf.prim
        if not 1 <= t or 2 * t >= self.n:
            raise ValueError("bad t")
        # generator polynomial = product of the distinct minimal polynomials M_i, i odd < 2t
        seen, g, cosets = set(), 1, []
        for i in range(1, 2 * t, 2):
            c = cyclotomic_coset(i, m)
            if c[0] in seen or any(j in seen for j in c):
                continue
            seen.update(c)
            cosets.append(sorted(c))
            g = gf2_poly_mul(g, self.gf.minimal_poly(i))
        self.cosets = cosets
        self.g = g
        self.r = g.bit_length() - 1
        self.k_full = self.n - self.r
        self.k = self.k_full if k is None else k
        if not 1 <= self.k <= self.k_full:
            raise ValueError(f"message length {self.k} outside 1..{self.k_full}")
        self.ns = self.k + self.r
        # roots of g must include alpha^1..alpha^2t (designed distance check)
        for j in range(1, 2 * t + 1):
            if self._eval_binary(g, j) != 0:
                raise ArithmeticError(f"g(alpha^{j}) != 0")

    # ------------------------------------------------------------------ helpers
    def _eval_binary(self, poly: int, j: int) -> int:
        """Evaluate a binary polynomial (bitmask) at alpha^j."""
        acc, d, n = 0, 0, self.n
        exp = self.gf.exp
        while poly:
            if poly & 1:
                acc ^= exp[(j * d) % n]
            poly >>= 1
            d += 1
        return acc

    # ------------------------------------------------------------------ encoding (bitmask polys)
    def encode_poly(self, u: int) -> int:
        """u: message polynomial (bit i = coef x^i, i < k).  Returns parity polynomial (deg < r)."""
        if u >> self.k:
            raise ValueError("message wider than k")
        return gf2_poly_mod(u << self.r, self.g)

    def codeword_poly(self, u: int) -> int:
        return (u << self.r) | self.encode_poly(u)

    def is_codeword(self, c: int) -> bool:
        return gf2_poly_mod(c, self.g) == 0

    # ------------------------------------------------------------------ decoding
    def syndromes(self, rpoly: int) -> List[int]:
        """S[0] unused; S[j] = r(alpha^j) for j = 1..2t, all computed directly (no squaring)."""
        S = [0] * (2 * self.t + 1)
        exp, n = self.gf.exp, self.n
        degs = []
        d, p = 0, rpoly
        while p:
            if p & 1:
                degs.append(d)
            p >>= 1
            d += 1
        for j in range(1, 2 * self.t + 1):
            acc = 0
            for d in degs:
                acc ^= exp[(j * d) % n]
            S[j] = acc
        return S

    def bm_massey(self, S: List[int]) -> Tuple[List[int], int]:
        """(A) Classic Berlekamp-Massey with field inversion over all 2t syndromes."""
        gf = self.gf
        C, B, L, mm, b = [1], [1], 0, 1, 1
        for nn in range(2 * self.t):
            d = S[nn + 1]
            for i in range(1, L + 1):
                if i < len(C):
                    d ^= gf.mul(C[i], S[nn + 1 - i])
            if d == 0:
                mm += 1
                continue
            coef = gf.div(d, b)
            Tc = C[:]
            shifted = [0] * mm + [gf.mul(coef, x) for x in B]
            if len(shifted) > len(C):
                C = C + [0] * (len(shifted) - len(C))
            for i, v in enumerate(shifted):
                C[i] ^= v
            if 2 * L <= nn:
                L, B, b, mm = nn + 1 - L, Tc, d, 1
            else:
                mm += 1
        while len(C) > 1 and C[-1] == 0:
            C.pop()
        return C, L

    def ibm_simplified(self, S: List[int], trace: Optional[list] = None) -> Tuple[List[int], int]:
        """(B) Simplified inversionless BM for binary BCH: t iterations (even steps only).
        This is the algorithm implemented by rtl/sfecc_bch_kes.sv, step for step:
            delta = sum_{i=0..L} lam_i S_{r+1-i}            (r = 2q)
            lam'  = gamma*lam + delta*x*B
            if delta != 0 and 2L <= r: B' = x*lam, L' = r+1-L, gamma' = delta
            else:                      B' = x^2*B
        """
        gf, t = self.gf, self.t
        lam, B, L, gamma = [1], [1], 0, 1
        for q in range(t):
            r = 2 * q
            delta = 0
            for i in range(len(lam)):
                if 1 <= r + 1 - i:
                    delta ^= gf.mul(lam[i], S[r + 1 - i])
            xB = [0] + B
            new = [0] * max(len(lam), len(xB))
            for i, v in enumerate(lam):
                new[i] ^= gf.mul(gamma, v)
            for i, v in enumerate(xB):
                new[i] ^= gf.mul(delta, v)
            if delta != 0 and 2 * L <= r:
                B, L, gamma = [0] + lam, r + 1 - L, delta
            else:
                B = [0, 0] + B
            lam = new
            while len(lam) > 1 and lam[-1] == 0:
                lam.pop()
            while len(B) > 1 and B[-1] == 0:
                B.pop()
            if trace is not None:
                trace.append((q, delta, L, gamma, lam[:]))
        return lam, L

    def ibm_full(self, S: List[int]) -> Tuple[List[int], int, List[int]]:
        """Inversionless BM over all 2t steps; returns odd-step discrepancies (must be 0)."""
        gf = self.gf
        lam, B, L, gamma, odd = [1], [1], 0, 1, []
        for r in range(2 * self.t):
            delta = 0
            for i in range(len(lam)):
                if 1 <= r + 1 - i:
                    delta ^= gf.mul(lam[i], S[r + 1 - i])
            if r % 2 == 1:
                odd.append(delta)
            xB = [0] + B
            new = [0] * max(len(lam), len(xB))
            for i, v in enumerate(lam):
                new[i] ^= gf.mul(gamma, v)
            for i, v in enumerate(xB):
                new[i] ^= gf.mul(delta, v)
            if delta != 0 and 2 * L <= r:
                B, L, gamma = lam[:], r + 1 - L, delta
            else:
                B = [0] + B
            lam = new
            while len(lam) > 1 and lam[-1] == 0:
                lam.pop()
        return lam, L, odd

    def euclid(self, S: List[int]) -> List[int]:
        """(C) Sugiyama: extended Euclid on (x^2t, S(x)), S(x) = sum S_j x^(j-1)."""
        gf, t = self.gf, self.t

        def deg(p):
            for i in range(len(p) - 1, -1, -1):
                if p[i]:
                    return i
            return -1

        def sub_scaled(a, b, c, sh):  # a - c * x^sh * b
            out = a[:] + [0] * max(0, len(b) + sh - len(a))
            for i, v in enumerate(b):
                if v:
                    out[i + sh] ^= gf.mul(c, v)
            return out

        r0 = [0] * (2 * t) + [1]
        r1 = S[1:2 * t + 1]
        t0, t1 = [0], [1]
        if deg(r1) < 0:
            return [1]
        while deg(r1) >= t:
            q_t0, q_t1 = t0, t1
            rem = r0[:]
            tnew = q_t0[:]
            while deg(rem) >= deg(r1):
                sh = deg(rem) - deg(r1)
                c = gf.div(rem[deg(rem)], r1[deg(r1)])
                rem = sub_scaled(rem, r1, c, sh)
                tnew = sub_scaled(tnew, q_t1, c, sh)
            r0, r1, t0, t1 = r1, rem, t1, tnew
        lam = t1[:]
        while len(lam) > 1 and lam[-1] == 0:
            lam.pop()
        if lam[0] == 0:
            return lam
        c = gf.inv(lam[0])
        return [gf.mul(c, v) for v in lam]

    def chien(self, lam: List[int], lo: int = 0, hi: Optional[int] = None) -> List[int]:
        """Positions d in [lo, hi) with lam(alpha^-d) == 0 (error at degree d)."""
        hi = self.ns if hi is None else hi
        gf, out = self.gf, []
        for d in range(lo, hi):
            if gf.poly_eval(lam, gf.alpha(-d)) == 0:
                out.append(d)
        return out

    def decode_poly(self, rpoly: int, algo: str = "ibm") -> Dict:
        """Hardware-equivalent decode at bit level.  Returns dict with keys
        ok, L, lam, positions (roots found in [0, ns)), corrected (poly), syn_zero."""
        S = self.syndromes(rpoly)
        syn_zero = all(s == 0 for s in S[1:])
        if syn_zero:
            return dict(ok=True, L=0, lam=[1], positions=[], corrected=rpoly, syn_zero=True)
        if algo == "ibm":
            lam, L = self.ibm_simplified(S)
        elif algo == "massey":
            lam, L = self.bm_massey(S)
        elif algo == "euclid":
            lam = self.euclid(S)
            L = len(lam) - 1
        else:
            raise ValueError(algo)
        if L > self.t:
            return dict(ok=False, L=L, lam=lam, positions=[], corrected=rpoly, syn_zero=False)
        pos = self.chien(lam)
        corr = rpoly
        for d in pos:
            corr ^= 1 << d
        return dict(ok=(len(pos) == L), L=L, lam=lam, positions=pos, corrected=corr, syn_zero=False)


class BCHFormat:
    """Byte framing of a (shortened) BCH code exactly as the RTL sees it."""

    def __init__(self, m: int, t: int, msg_bytes: int, lpad: int = 0, prim: Optional[int] = None,
                 erased_mask: bool = True, name: str = ""):
        self.name = name
        self.msg_bytes, self.lpad = msg_bytes, lpad
        k = 8 * msg_bytes - lpad
        self.code = BCHCode(m, t, prim, k)
        c = self.code
        self.m, self.t, self.r, self.k, self.ns, self.prim, self.g = m, t, c.r, k, c.ns, c.prim, c.g
        self.par_bytes = (c.r + 7) // 8
        self.tpad = 8 * self.par_bytes - c.r
        self.cw_bytes = msg_bytes + self.par_bytes
        self.erased_mask = erased_mask
        ones_k = (1 << k) - 1
        self.mask = (c.encode_poly(ones_k) ^ ((1 << c.r) - 1)) if erased_mask else 0

    # -------------------------------------------------------------- bytes <-> polynomial
    def msg_to_poly(self, msg: bytes) -> int:
        """Message bytes -> u(x) (LPAD leading bits ignored)."""
        v = int.from_bytes(msg, "big")
        return v & ((1 << self.k) - 1)

    def poly_to_msg(self, u: int, orig_first: int) -> bytes:
        """u(x) -> message bytes; LPAD bits taken from orig_first (passed through)."""
        v = u
        if self.lpad:
            hi = (orig_first >> (8 - self.lpad)) << (8 * self.msg_bytes - self.lpad)
            v |= hi
        return v.to_bytes(self.msg_bytes, "big")

    def parity_to_bytes(self, p: int) -> bytes:
        stored = p ^ self.mask
        v = (stored << self.tpad) | ((1 << self.tpad) - 1)      # pad bits written as 1
        return v.to_bytes(self.par_bytes, "big")

    def bytes_to_parity(self, pb: bytes) -> int:
        v = int.from_bytes(pb, "big") >> self.tpad
        return v ^ self.mask

    def encode(self, msg: bytes) -> bytes:
        """Returns the full stored codeword: msg bytes (unchanged) + stored parity bytes."""
        assert len(msg) == self.msg_bytes
        u = self.msg_to_poly(msg)
        return bytes(msg) + self.parity_to_bytes(self.code.encode_poly(u))

    def stored_to_poly(self, cw: bytes) -> int:
        u = self.msg_to_poly(cw[:self.msg_bytes])
        p = self.bytes_to_parity(cw[self.msg_bytes:])
        return (u << self.r) | p

    def decode(self, cw: bytes, algo: str = "ibm") -> Tuple[bytes, Dict]:
        """Bit-exact model of rtl/sfecc_bch_dec.sv: returns (message bytes out, status)."""
        assert len(cw) == self.cw_bytes
        rpoly = self.stored_to_poly(cw)
        res = self.code.decode_poly(rpoly, algo)
        if res["ok"]:
            corr = res["corrected"]
        elif res["L"] > self.t:
            corr = rpoly                      # no root search: data passed through raw
        else:
            corr = res["corrected"]           # roots found were applied while streaming
        u = corr >> self.r
        msg_out = self.poly_to_msg(u, cw[0])
        status = dict(ok=res["ok"], L=res["L"], positions=res["positions"])
        if not res["ok"]:
            status.update(code=ST_UNCORR, nerr=0)
        else:
            # erased: corrected message bits and corrected STORED parity bits all one
            stored_par = (corr & ((1 << self.r) - 1)) ^ self.mask
            all_ones = (u == (1 << self.k) - 1) and stored_par == (1 << self.r) - 1
            if all_ones:
                status.update(code=ST_ERASED, nerr=res["L"])
            elif res["L"] == 0:
                status.update(code=ST_CLEAN, nerr=0)
            else:
                status.update(code=ST_CORRECTED, nerr=res["L"])
        return msg_out, status

    # -------------------------------------------------------------- bit position helpers
    def stream_bit_degree(self, s: int) -> Optional[int]:
        """Degree of stream bit s, or None for a padding bit."""
        if s < self.lpad or s >= self.lpad + self.ns:
            return None
        return self.ns - 1 + self.lpad - s

    def degree_stream_bit(self, d: int) -> int:
        return self.ns - 1 + self.lpad - d

    def valid_stream_bits(self) -> List[int]:
        return list(range(self.lpad, self.lpad + self.ns))

    def flip(self, cw: bytes, stream_bits) -> bytes:
        b = bytearray(cw)
        for s in stream_bits:
            b[s >> 3] ^= 0x80 >> (s & 7)
        return bytes(b)

    def describe(self) -> Dict:
        return dict(name=self.name, m=self.m, t=self.t, prim=hex(self.prim), n=self.code.n,
                    k_full=self.code.k_full, k=self.k, r=self.r, ns=self.ns,
                    msg_bytes=self.msg_bytes, par_bytes=self.par_bytes, cw_bytes=self.cw_bytes,
                    lpad=self.lpad, tpad=self.tpad, g_hex=hex(self.g), mask_hex=hex(self.mask),
                    rate=self.k / self.ns, shortened_by=self.code.k_full - self.k)
