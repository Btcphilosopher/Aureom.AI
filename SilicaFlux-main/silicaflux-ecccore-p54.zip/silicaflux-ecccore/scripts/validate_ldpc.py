#!/usr/bin/env python3
"""
validate_ldpc.py -- independent validation and characterisation of the LDPC proof of concept.

  1. Structure, computed without the construction's own shortcuts: GF(2) rank of the dense H
     (Gaussian elimination) = 64, H c = 0 for random encodings (dense product), girth of the
     Tanner graph by breadth-first search (no 4-cycles claimed by construction).
  2. The floating-point sum-product decoder agrees with pyldpc's independent flooding log-BP
     (ext/pyldpc, BSD-3, Hicham Janati) on the same received LLRs.
  3. Hard-decision behaviour of the fixed-point layered offset-min-sum decoder (the RTL
     algorithm): every 1-bit and every 2-bit error pattern, plus 3..6-bit samples.  LDPC has no
     guaranteed correction radius; these are measured numbers.
  4. Frame-error rate vs Eb/N0 on BI-AWGN: sum-product (float) vs fixed-point OMS (5-bit LLR)
     vs hard-decision OMS; average iterations.
  5. NAND soft-sensing study (illustrative SLC read-threshold model): FER vs raw BER with one
     read (hard) and three reads (2-bit soft, read-retry-style offset references).
Writes reports/ldpc_validation.{json,md}.
"""
import json
import math
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "ref"))
import sfecc_ldpc as LD  # noqa: E402

RES = []
FAIL = []


def check(name, ok, detail=""):
    RES.append(dict(check=name, ok=bool(ok), detail=detail))
    print(("PASS " if ok else "FAIL ") + name + (f"  ({detail})" if detail else ""))
    if not ok:
        FAIL.append(name)


def gf2_rank(rows):
    rows = [int("".join(map(str, r)), 2) for r in rows]
    rank, n = 0, len(rows)
    for bit in reversed(range(LD.N)):
        piv = None
        for i in range(rank, n):
            if (rows[i] >> bit) & 1:
                piv = i
                break
        if piv is None:
            continue
        rows[rank], rows[piv] = rows[piv], rows[rank]
        for i in range(n):
            if i != rank and (rows[i] >> bit) & 1:
                rows[i] ^= rows[rank]
        rank += 1
    return rank


def girth(code):
    """Shortest cycle in the Tanner graph (BFS from every variable node)."""
    best = 10 ** 9
    adj_v = code.cols
    adj_c = code.rows
    for s in range(LD.N):
        dist = {("v", s): 0}
        parent = {("v", s): None}
        q = [("v", s)]
        while q:
            nq = []
            for node in q:
                kind, idx = node
                nbrs = [("c", i) for i in adj_v[idx]] if kind == "v" else [("v", v) for v in adj_c[idx]]
                for nb in nbrs:
                    if nb == parent[node]:
                        continue
                    if nb in dist:
                        best = min(best, dist[node] + dist[nb] + 1)
                    else:
                        dist[nb] = dist[node] + 1
                        parent[nb] = node
                        nq.append(nb)
            q = nq
            if q and dist[q[0]] * 2 >= best:
                break
    return best


def awgn_llr(stored, ebn0_db, rnd, rate=0.5):
    sigma = math.sqrt(1.0 / (2 * rate * 10 ** (ebn0_db / 10)))
    y = [(1.0 - 2.0 * b) + rnd.gauss(0, sigma) for b in stored]
    return [2.0 * v / sigma ** 2 for v in y], sigma


def main():
    quick = "--quick" in sys.argv
    t0 = time.time()
    code = LD.QCLDPC()
    rnd = random.Random(11)
    rep = dict(base_matrix=code.B, z=LD.Z, n=LD.N, k=LD.K)
    # ------------------------------------------------------------ 1. structure
    H = code.H_dense()
    rk = gf2_rank(H)
    check("dense H has GF(2) rank 64 (k = 64)", rk == 64, f"rank {rk}")
    bad = 0
    for _ in range(500):
        u = [rnd.getrandbits(1) for _ in range(LD.K)]
        c = code.encode_bits(u)
        if any(sum(H[i][j] & c[j] for j in range(LD.N)) & 1 for i in range(len(H))):
            bad += 1
    check("H c = 0 (dense product) for 500 random encodings", bad == 0, f"failures {bad}")
    g = girth(code)
    rep["girth"] = g
    check("Tanner-graph girth >= 6 (BFS)", g >= 6, f"girth {g}")
    check("erased (all-ones) stored word is a codeword after the mask",
          code.is_codeword([1] * LD.K + [1 ^ m for m in code.mask]))
    # ------------------------------------------------------------ 2. pyldpc cross-check
    try:
        import numpy as np
        sys.path.insert(0, os.path.join(ROOT, "ext"))
        from pyldpc import decoder as pyd                       # noqa: E402
        Hn = np.array(H, dtype=np.int64)
        from pyldpc import utils as pyu                         # noqa: E402

        def py_decode(Hm, Lc, maxiter):
            m, n = Hm.shape
            bh, bv, nh, nv = pyu._bitsandnodes(Hm)
            Lc = Lc[:, None]
            Lq = np.zeros((m, n, 1))
            Lr = np.zeros((m, n, 1))
            x = None
            for it in range(maxiter):
                Lq, Lr, post = pyd._logbp_numba(bh, bv, nh, nv, Lc, Lq, Lr, it)
                x = np.array(post <= 0).astype(int)
                if pyu.incode(Hm, x):
                    break
            return x.squeeze()
        agree = total = 0
        nfr = 60 if quick else 300
        for f in range(nfr):
            u = [rnd.getrandbits(1) for _ in range(LD.K)]
            c = code.encode_bits(u)
            llr, sigma = awgn_llr(c, 1.5 + (f % 5) * 0.5, rnd)
            x_ours, ok, it = code.decode_bp_float(llr, maxit=30)
            if code.is_codeword([1 if v < 0 else 0 for v in llr]):
                continue                     # pyldpc always runs >= 1 iteration; compare real decodes
            # pyldpc's decode() mis-dispatches irregular codes (np.unique(col weights) * np.unique(row
            # weights) broadcast error), so its irregular log-BP kernel is driven directly with the
            # same outer loop as pyldpc.decode: Lc = channel LLRs, stop when H x = 0.
            x_py = py_decode(Hn, np.array(llr, dtype=float), 30)
            total += 1
            agree += int(list(map(int, x_py)) == x_ours)
        check(f"sum-product == pyldpc flooding log-BP kernel on {total} noisy frames that need decoding (same LLRs, <= 30 iterations)",
              agree == total, f"agree {agree}/{total}")
    except Exception as e:  # pragma: no cover
        check("pyldpc cross-check ran", False, repr(e))
    # ------------------------------------------------------------ 3. hard-decision patterns
    u = [rnd.getrandbits(1) for _ in range(LD.K)]
    st = code.stored_bits(u)
    hard = {}
    for w in (1, 2):
        tot = ok = 0
        pats = ([(i,) for i in range(LD.N)] if w == 1 else
                [(i, j) for i in range(LD.N) for j in range(i + 1, LD.N)])
        if quick and w == 2:
            pats = pats[::16]
        for pat in pats:
            s = st[:]
            for i in pat:
                s[i] ^= 1
            r = code.decode_oms_fixed(LD.hard_llr(s), maxit=20)
            tot += 1
            ok += int(r["ok"] and r["bits"][:LD.K] == u)
        hard[w] = dict(patterns=tot, corrected=ok)
    for w in (3, 4, 5, 6):
        tot = ok = 0
        for _ in range(300 if not quick else 50):
            s = st[:]
            for i in rnd.sample(range(LD.N), w):
                s[i] ^= 1
            r = code.decode_oms_fixed(LD.hard_llr(s), maxit=20)
            tot += 1
            ok += int(r["ok"] and r["bits"][:LD.K] == u)
        hard[w] = dict(patterns=tot, corrected=ok)
    rep["hard_decision"] = hard
    check("hard-decision OMS corrects every 1-bit error pattern", hard[1]["corrected"] == hard[1]["patterns"],
          f"{hard[1]['corrected']}/{hard[1]['patterns']}")
    print("  hard-decision correction (measured):", {w: f"{v['corrected']}/{v['patterns']}" for w, v in hard.items()})
    # ------------------------------------------------------------ 4. FER vs Eb/N0
    curves = []
    nfr = 150 if quick else 600
    for eb in (1.0, 2.0, 3.0, 4.0, 5.0):
        cnt = dict(bp=0, oms=0, hard=0, it_oms=0, it_bp=0)
        for _ in range(nfr):
            u = [rnd.getrandbits(1) for _ in range(LD.K)]
            st = code.stored_bits(u)
            llr, sigma = awgn_llr(st, eb, rnd)
            x, ok, it = code.decode_bp_float(code.stored_llr_to_code(llr), maxit=30)
            cnt["bp"] += int(not ok or x[:LD.K] != u)
            cnt["it_bp"] += it
            r = code.decode_oms_fixed(LD.quantize(llr, 2.0, 5), maxit=20)
            cnt["oms"] += int(not r["ok"] or r["bits"][:LD.K] != u)
            cnt["it_oms"] += r["iters"]
            rh = code.decode_oms_fixed(LD.hard_llr([1 if v < 0 else 0 for v in llr]), maxit=20)
            cnt["hard"] += int(not rh["ok"] or rh["bits"][:LD.K] != u)
        row = dict(ebn0_db=eb, frames=nfr, fer_bp_float=cnt["bp"] / nfr, fer_oms_5bit=cnt["oms"] / nfr,
                   fer_oms_hard=cnt["hard"] / nfr, avg_iter_oms=cnt["it_oms"] / nfr, avg_iter_bp=cnt["it_bp"] / nfr)
        curves.append(row)
        print("  ", row)
    rep["awgn"] = curves
    # ------------------------------------------------------------ 5. NAND soft sensing (illustrative)
    # SLC: erased '1' ~ N(-1, s), programmed '0' ~ N(+1, s) (normalised); one read at 0 (hard) or
    # three reads at {-d, 0, +d} (2-bit soft): region LLRs from the two Gaussians.
    def q(x):
        return 0.5 * math.erfc(x / math.sqrt(2))

    soft = []
    for sigma in (0.40, 0.45, 0.50, 0.55):
        p_raw = q(1.0 / sigma)
        d = 0.6 * sigma
        edges = [-1e9, -d, 0.0, d, 1e9]
        llr_reg = []
        for a, b in zip(edges[:-1], edges[1:]):
            p0 = q((a - 1.0) / sigma) - q((b - 1.0) / sigma)
            p1 = q((a + 1.0) / sigma) - q((b + 1.0) / sigma)
            llr_reg.append(math.log(max(p0, 1e-300) / max(p1, 1e-300)))
        cnt = dict(hard=0, soft=0, raw=0, nbits=0)
        nfr2 = 150 if quick else 600
        for _ in range(nfr2):
            u = [rnd.getrandbits(1) for _ in range(LD.K)]
            st = code.stored_bits(u)
            vt = [(1.0 if b == 0 else -1.0) + rnd.gauss(0, sigma) for b in st]
            hard_bits = [0 if v > 0 else 1 for v in vt]
            cnt["raw"] += sum(a != b for a, b in zip(hard_bits, st))
            cnt["nbits"] += LD.N
            rh = code.decode_oms_fixed(LD.hard_llr(hard_bits), maxit=20)
            cnt["hard"] += int(not rh["ok"] or rh["bits"][:LD.K] != u)
            reg = [0 if v < -d else (1 if v < 0 else (2 if v < d else 3)) for v in vt]
            sl = LD.quantize([llr_reg[r] for r in reg], 2.0, 5)
            rs = code.decode_oms_fixed(sl, maxit=20)
            cnt["soft"] += int(not rs["ok"] or rs["bits"][:LD.K] != u)
        row = dict(sigma=sigma, raw_ber_model=p_raw, raw_ber_measured=cnt["raw"] / cnt["nbits"], frames=nfr2,
                   fer_1read_hard=cnt["hard"] / nfr2, fer_3read_soft=cnt["soft"] / nfr2,
                   region_llr=[round(v, 2) for v in llr_reg])
        soft.append(row)
        print("  ", row)
    rep["nand_soft"] = soft
    soft_gain = sum(r["fer_3read_soft"] <= r["fer_1read_hard"] for r in soft)
    check("3-read soft sensing never does worse than 1-read hard decisions (FER, each sigma)",
          soft_gain == len(soft), f"{soft_gain}/{len(soft)} points")
    rep["checks"] = RES
    rep["seconds"] = round(time.time() - t0, 1)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(rep, open(os.path.join(ROOT, "reports", "ldpc_validation.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "ldpc_validation.md"), "w") as fh:
        fh.write("# LDPC proof of concept — validation (`scripts/validate_ldpc.py`)\n\n")
        fh.write(f"QC-LDPC(128,64), Z = 16, base matrix (shifts, -1 = zero block): `{code.B}`, girth {g}.\n\n")
        fh.write("| Result | Check | Detail |\n|---|---|---|\n")
        for r in RES:
            fh.write(f"| {'PASS' if r['ok'] else '**FAIL**'} | {r['check']} | {r['detail']} |\n")
        fh.write("\n## Hard-decision error patterns (fixed-point layered OMS, 20 iterations) — measured\n\n")
        fh.write("| Errors | Patterns | Corrected |\n|---|---|---|\n")
        for w, v in hard.items():
            fh.write(f"| {w} | {v['patterns']} | {v['corrected']} ({100.0 * v['corrected'] / v['patterns']:.1f} %) |\n")
        fh.write("\n## BI-AWGN, rate 1/2 — frame-error rate (sampled, small frame counts)\n\n")
        fh.write("| Eb/N0 dB | frames | sum-product float | layered OMS 5-bit | OMS hard | avg it. OMS | avg it. BP |\n|---|---|---|---|---|---|---|\n")
        for r in curves:
            fh.write(f"| {r['ebn0_db']} | {r['frames']} | {r['fer_bp_float']:.4f} | {r['fer_oms_5bit']:.4f} | "
                     f"{r['fer_oms_hard']:.4f} | {r['avg_iter_oms']:.2f} | {r['avg_iter_bp']:.2f} |\n")
        fh.write("\n## NAND soft sensing (illustrative SLC threshold model) — FER\n\n")
        fh.write("| sigma | raw BER | frames | 1 read (hard) | 3 reads (2-bit soft) |\n|---|---|---|---|---|\n")
        for r in soft:
            fh.write(f"| {r['sigma']} | {r['raw_ber_measured']:.4f} | {r['frames']} | {r['fer_1read_hard']:.4f} | "
                     f"{r['fer_3read_soft']:.4f} |\n")
        fh.write("\nSmall code, small samples: these numbers characterise the proof of concept, not a NAND product.\n")
    print(f"{len(RES) - len(FAIL)}/{len(RES)} checks pass in {rep['seconds']} s")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
