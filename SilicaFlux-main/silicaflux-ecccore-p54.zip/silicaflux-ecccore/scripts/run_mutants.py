#!/usr/bin/env python3
"""
run_mutants.py -- does the verification have teeth?  Each mutant is a deliberate, plausible RTL bug;
the core (or page) testbench must FAIL on every one.  Writes reports/mutation.md.
"""
import os
import re
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, "build", "mutants")

# (id, file, original text, mutated text, testbench, config, description)
MUTANTS = [
    ("M1", "rtl/sfecc_bch_kes.sv", "({{(32-LW){1'b0}}, L} <= {{(32-QW){1'b0}}, q})",
     "({{(32-LW){1'b0}}, L} < {{(32-QW){1'b0}}, q})", "core", "B255T4",
     "Berlekamp-Massey length-change condition 2L <= r written as 2L < r"),
    ("M2", "rtl/sfecc_bch_chien.sv", "ok = !((first && li < LPAD) || (lastb && li >= 8 - TPAD));",
     "ok = !(lastb && li >= 8 - TPAD);", "core", "B255T4",
     "Chien search accepts roots in the leading padding bit (LPAD)"),
    ("M3", "rtl/sfecc_bch_dec.sv", "wire [7:0] dsyn     = ((b == '0) ? (in_data & LMASK) : in_data) ^ mbyte;",
     "wire [7:0] dsyn     = ((b == '0) ? (in_data & LMASK) : in_data);", "core", "N512T4",
     "erased-page MASK not removed on the syndrome path"),
    ("M4", "rtl/sfecc_bch_syn.sv", "assign s_o[j*GF_M +: GF_M] = partial_i ? accp : accf;",
     "assign s_o[j*GF_M +: GF_M] = accf;", "core", "N512T4",
     "partial last parity byte (TPAD) processed as a full byte"),
    ("M5", "rtl/sfecc_bch_chien.sv", "  wire       fail_fin = fin_fe || ({{(32-RCW){1'b0}}, fin_roots} != {{(32-LW){1'b0}}, fin_lq});",
     "  wire       fail_fin = fin_fe;", "core", "N512T8",
     "decoder failure check 'roots == L' removed (only L > t detected)"),
    ("M6", "rtl/sfecc_bch_enc.sv", "wire [R-1:0]    lfsr_nx   = (cnt == '0) ? lfsr8(lfsr, in_data, LPAD) : lfsr8(lfsr, in_data, 0);",
     "wire [R-1:0]    lfsr_nx   = lfsr8(lfsr, in_data, 0);", "core", "B255T4",
     "encoder includes the LPAD padding bit in the division"),
    ("M7", "rtl/sfecc_page_dec.sv", "                     (!cq_head)                    ? `SFECC_SS_INTEGRITY :",
     "                     1'b0                          ? `SFECC_SS_INTEGRITY :", "page", "N2KT8",
     "page decoder ignores the CRC-16 verdict (miscorrections reported as success)"),
    ("M8", "rtl/sfecc_bch_kes.sv", "            gamma <= delta;\n", "", "core", "N512T8",
     "inversionless BM: gamma not updated on a length change"),
    ("M9", "rtl/sfecc_bch_dec.sv", "  assign in_ready = !bank_busy[wbank] && !(is_last && h_valid);",
     "  assign in_ready = !bank_busy[wbank];", "core3", "B255T4",
     "SYN stage overwrites the KES hand-off register (needs 3 codewords in flight: NBANKS = 3, 80 % output back-pressure)"),
]


def run(mid, path, old, new, tb, cfg):
    d = os.path.join(B, mid)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl"), os.path.join(d, "rtl"))
    p = os.path.join(d, path)
    s = open(p).read()
    if old not in s:
        return "NOT APPLIED"
    open(p, "w").write(s.replace(old, new, 1))
    files = [os.path.join(d, l.strip()) for l in open(os.path.join(ROOT, "rtl", "files.f"))
             if l.strip() and not l.startswith("//")]
    gen = []
    if tb in ("core", "core3"):
        files = [f for f in files if "bch_" in f]
        top, plus = "tb_sfecc_bch", ["+NRST=2"]          # every vector (the files are sorted by category)
        if tb == "core3":
            gen = ["-GNBANKS_TB=3"]
            plus += ["+BP_IN=0", "+BP_OUT=80", "+BP_ST=80"]
    else:
        top, plus = "tb_sfecc_page", ["+NRST=1"]
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O1", "--top-module", top,
           "-I" + os.path.join(d, "rtl"), "-I" + os.path.join(d, "rtl", "generated"), "-I" + os.path.join(ROOT, "tb"),
           "-I" + os.path.join(ROOT, "build", "vec", cfg), "--Mdir", os.path.join(d, "obj"), "-o", "sim"] + gen + files + \
          [os.path.join(ROOT, "tb", top + ".sv")]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        return "KILLED (does not compile)"
    r = subprocess.run([os.path.join(d, "obj", "sim"), f"+VEC={os.path.join(ROOT, 'build', 'vec', cfg)}",
                        f"+OUT={os.path.join(d, 'out.json')}"] + plus, capture_output=True, text=True, timeout=3600)
    line = [l for l in r.stdout.splitlines() if "TB RESULT" in l]
    if not line:
        return "KILLED (no result / crash)"
    m = re.search(r"errors=(\d+)", line[0])
    return f"KILLED ({m.group(1)} errors)" if "FAIL" in line[0] else "SURVIVED"


def main():
    rows = []
    only = sys.argv[1:]
    for mid, path, old, new, tb, cfg, desc in MUTANTS:
        if only and mid not in only:
            continue
        res = run(mid, path, old, new, tb, cfg)
        print(mid, res, desc)
        rows.append((mid, path, desc, tb, cfg, res))
    with open(os.path.join(ROOT, "reports", "mutation.md"), "w") as fh:
        fh.write("# Mutation check — `scripts/run_mutants.py`\n\nEach mutant is one deliberate RTL bug; the named "
                 "testbench (every vector of the configuration) must fail.\n\n| Mutant | File | Bug | Testbench / config | Result |\n|---|---|---|---|---|\n")
        for r in rows:
            fh.write(f"| {r[0]} | `{r[1]}` | {r[2]} | {r[3]} / {r[4]} | {r[5]} |\n")
        k = sum(r[5].startswith("KILLED") for r in rows)
        fh.write(f"\n**{k} / {len(rows)} mutants killed.**\n")
        fh.write("\nSurvivor analysis: M9 is an equivalent mutant for NBANKS <= 3 (the hand-off slot is always empty\n"
                 "before the next codeword's last byte); see docs/06 §5.\n")
    sys.exit(0)


if __name__ == "__main__":
    main()
