#!/usr/bin/env python3
"""lint.py -- Verilator -Wall lint of every synthesis wrapper / configuration; writes reports/lint.md.
Warnings inside synth/sfecc_synth_tops.sv (the thin wrappers) are listed separately."""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOPS = ["syn_ecc_N2KT8", "syn_ecc_N512T4", "syn_ecc_L24", "syn_bch_enc_B255T4", "syn_bch_dec_B255T4",
        "syn_bch_dec_B255T4_nb3", "syn_bch_enc_N512T4", "syn_bch_dec_N512T4", "syn_bch_enc_N512T8",
        "syn_bch_dec_N512T8", "syn_bch_enc_N8KT40", "syn_bch_dec_N8KT40", "syn_ldpc_enc", "syn_ldpc_dec"]


def main():
    files = [os.path.join(ROOT, l.strip()) for l in open(os.path.join(ROOT, "rtl", "files.f"))
             if l.strip() and not l.startswith("//")]
    rows, total = [], 0
    for top in TOPS:
        out = subprocess.run(["verilator", "--lint-only", "-Wall", "-I" + os.path.join(ROOT, "rtl"),
                              "-I" + os.path.join(ROOT, "rtl", "generated"), "--top-module", top] + files +
                             [os.path.join(ROOT, "synth", "sfecc_synth_tops.sv")], capture_output=True, text=True)
        msgs = [l for l in out.stderr.splitlines() if re.match(r"^%(Warning|Error)-", l)]
        rtl = [m for m in msgs if "sfecc_synth_tops.sv" not in m]
        wrap = [m for m in msgs if "sfecc_synth_tops.sv" in m]
        total += len(rtl)
        rows.append((top, len(rtl), len(wrap), rtl))
        print(f"{top:26s} RTL warnings {len(rtl)}  wrapper warnings {len(wrap)}")
    with open(os.path.join(ROOT, "reports", "lint.md"), "w") as fh:
        fh.write("# Lint — Verilator 5.020 `--lint-only -Wall`\n\n")
        fh.write("Every synthesis wrapper (one per block and configuration) elaborated with all RTL. Intentional\n"
                 "exceptions are waived in the source with `verilator lint_off` comments and a reason.\n\n")
        fh.write("| Top | RTL warnings | wrapper-only warnings |\n|---|---|---|\n")
        for top, n, w, msgs in rows:
            fh.write(f"| `{top}` | {n} | {w} |\n")
        for top, n, w, msgs in rows:
            if msgs:
                fh.write(f"\n## {top}\n\n```\n" + "\n".join(msgs) + "\n```\n")
        fh.write(f"\n**Total RTL warnings: {total}.**  Wrapper warnings are unused outputs/ports of the\n"
                 "thin synthesis shells (`synth/sfecc_synth_tops.sv`).\n")
    sys.exit(1 if total else 0)


if __name__ == "__main__":
    main()
