#!/usr/bin/env python3
"""
synth.py -- open-source synthesis estimates for every block / configuration.

  generic  Yosys 0.33: synth -flatten (memories kept as $mem to count bits separately), stat,
           ltp (longest topological path = logic levels, a technology-neutral timing proxy);
           second pass with memories mapped to flip-flops for a total cell count
  ecp5     Yosys synth_ecp5 -> nextpnr-ecp5 (LFE5U-85F, out-of-context, 100 MHz target):
           LUT4 / FF / DP16KD / LUTRAM use and the post-route maximum frequency.
Estimates only: no ASIC library, no timing sign-off.  Writes reports/synthesis.{json,md}.
    python3 scripts/synth.py [top ...] [--jobs N] [--no-pnr]
"""
import json
import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOPS = ["syn_bch_enc_B255T4", "syn_bch_dec_B255T4", "syn_bch_dec_B255T4_nb3", "syn_bch_enc_N512T4",
        "syn_bch_dec_N512T4", "syn_bch_enc_N512T8", "syn_bch_dec_N512T8", "syn_ecc_N512T4", "syn_ecc_N2KT8",
        "syn_ldpc_enc", "syn_ldpc_dec", "syn_ecc_L24", "syn_bch_enc_N8KT40", "syn_bch_dec_N8KT40"]
B = os.path.join(ROOT, "build", "synth")


def files():
    fl = [os.path.join(ROOT, l.strip()) for l in open(os.path.join(ROOT, "rtl", "files.f"))
          if l.strip() and not l.startswith("//")]
    return fl + [os.path.join(ROOT, "synth", "sfecc_synth_tops.sv")]


def rd():
    inc = f"-I{ROOT}/rtl -I{ROOT}/rtl/generated"
    return f"read_verilog -sv -DSYNTHESIS {inc} " + " ".join(files())


def yosys(script, log):
    with open(log + ".ys", "w") as fh:
        fh.write(script)
    r = subprocess.run(["yosys", "-q", "-l", log, log + ".ys"], capture_output=True, text=True)
    return r.returncode, open(log).read() if os.path.exists(log) else r.stderr


def parse_stat(txt):
    """last 'Number of cells' block of a stat output"""
    blk = txt[txt.rfind("Number of wires"):]
    cells = re.search(r"Number of cells:\s+(\d+)", blk)
    out = dict(cells=int(cells.group(1)) if cells else None)
    for name, n in re.findall(r"^\s+(\$?[\w$]+)\s+(\d+)\s*$", blk, re.M):
        out[name] = int(n)
    return out


def run_top(top, pnr=True):
    os.makedirs(B, exist_ok=True)
    res = dict(top=top)
    # ---- generic, memories kept
    rc, txt = yosys(f"{rd()}\nhierarchy -check -top {top}\nsynth -flatten -top {top} -run begin:fine\n"
                    f"memory -nomap\nopt -full\ntechmap\nopt -fast\nabc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX\n"
                    f"opt_clean\nstat\nltp -noff\n", os.path.join(B, top + ".generic.log"))
    if rc != 0:
        res["error"] = "generic synthesis failed"
        return res
    st = parse_stat(txt)
    memb = 0
    for m in re.finditer(r"\$mem(?:_v2)?\s+(\d+)", txt[txt.rfind("Number of wires"):]):
        pass
    # memory bits: from the $mem cells' parameters via a separate query
    rc2, txt2 = yosys(f"{rd()}\nhierarchy -check -top {top}\nsynth -flatten -top {top} -run begin:fine\n"
                      f"memory -nomap\nselect -list t:$mem_v2\ntee -o {B}/{top}.mem.txt dump t:$mem_v2\n",
                      os.path.join(B, top + ".mem.log"))
    try:
        dump = open(f"{B}/{top}.mem.txt").read()
        for w, s in zip(re.findall(r"parameter \\WIDTH (\d+)", dump), re.findall(r"parameter \\SIZE (\d+)", dump)):
            memb += int(w) * int(s)
    except FileNotFoundError:
        pass
    ff = sum(v for k, v in st.items() if re.match(r"^\$_(S?DFF|DFFE|ADFF|ADFFE|SDFFE|SDFFCE|DLATCH|ALDFF)", k))
    gates = sum(v for k, v in st.items() if re.match(r"^\$_(AND|NAND|OR|NOR|XOR|XNOR|ANDNOT|ORNOT|NOT|MUX)_$", k))
    xor = st.get("$_XOR_", 0) + st.get("$_XNOR_", 0)
    ltp = re.findall(r"Longest topological path in \S+ \(length=(\d+)\)", txt)
    res.update(generic_cells=st.get("cells"), gates=gates, xor_gates=xor, flip_flops=ff, memory_bits=memb,
               logic_levels=int(ltp[-1]) if ltp else None)
    # ---- ECP5 + nextpnr
    js = os.path.join(B, top + ".ecp5.json")
    rc, txt = yosys(f"{rd()}\nhierarchy -check -top {top}\nsynth_ecp5 -top {top} -json {js}\nstat\n",
                    os.path.join(B, top + ".ecp5.log"))
    if rc == 0:
        st = parse_stat(txt)
        res.update(ecp5_lut4=st.get("LUT4", 0), ecp5_ccu2c=st.get("CCU2C", 0), ecp5_pfu_ff=st.get("TRELLIS_FF", 0),
                   ecp5_dp16kd=st.get("DP16KD", 0), ecp5_lutram=st.get("TRELLIS_DPR16X4", 0),
                   ecp5_mux=st.get("PFUMX", 0) + st.get("L6MUX21", 0))
        if pnr:
            log = os.path.join(B, top + ".nextpnr.log")
            r = subprocess.run(["nextpnr-ecp5", "--85k", "--package", "CABGA381", "--json", js, "--out-of-context",
                                "--freq", "100", "--timing-allow-fail", "--seed", "1", "--log", log, "--quiet"],
                               capture_output=True, text=True)
            t = open(log).read() if os.path.exists(log) else r.stderr
            f = re.findall(r"Max frequency for clock\s+'[^']*':\s+([\d.]+) MHz", t)
            res["ecp5_fmax_mhz"] = float(f[-1]) if f else None
            u = re.findall(r"Info:\s+TRELLIS_SLICE:\s+(\d+)/\s*(\d+)", t)
            if u:
                res["ecp5_slices"] = f"{u[-1][0]}/{u[-1][1]}"
    else:
        res["ecp5_error"] = "synth_ecp5 failed"
    print(json.dumps(res))
    return res


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    jobs = 4
    if "--jobs" in sys.argv:
        jobs = int(sys.argv[sys.argv.index("--jobs") + 1])
        args = [a for a in args if a != str(jobs)]
    tops = args or TOPS
    pnr = "--no-pnr" not in sys.argv
    path = os.path.join(ROOT, "reports", "synthesis.json")
    if "--report-only" in sys.argv:
        allr = json.load(open(path))
    else:
        with ThreadPoolExecutor(jobs) as ex:
            results = list(ex.map(lambda t: run_top(t, pnr), tops))
        old = {r["top"]: r for r in (json.load(open(path)) if os.path.exists(path) else [])}
        for r in results:
            old[r["top"]] = r
        allr = [old[t] for t in TOPS if t in old]
        json.dump(allr, open(path, "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "synthesis.md"), "w") as fh:
        fh.write("# Synthesis estimates — Yosys 0.33 (generic gates) and Yosys + nextpnr-ecp5 (LFE5U-85F)\n\n")
        fh.write("Generic: 2-input gate library after ABC, memories kept as RAM (bits listed separately), flip-flops\n"
                 "excluding RAM.  Logic levels = Yosys `ltp` longest combinational path in gates.  ECP5: LUT4, CCU2C\n"
                 "carry, flip-flops, DP16KD 18 kbit block RAM, distributed RAM (DPR16X4), post-route Fmax of an\n"
                 "out-of-context place & route at a 100 MHz target (seed 1).  **Estimates, not sign-off.**\n\n")
        fh.write("| Block (config) | generic gates | of which XOR/XNOR | FF | RAM bits | logic levels | ECP5 LUT4 | ECP5 FF | DP16KD | DPR16X4 | Fmax MHz |\n")
        fh.write("|---|---|---|---|---|---|---|---|---|---|---|\n")
        for r in allr:
            fm = r.get("ecp5_fmax_mhz")
            fms = f"{fm:.1f}" if isinstance(fm, (int, float)) else "—"
            if r.get("pnr_note"):
                fms += " ¹"
            fh.write(f"| `{r['top']}` | {r.get('gates')} | {r.get('xor_gates')} | {r.get('flip_flops')} | "
                     f"{r.get('memory_bits')} | {r.get('logic_levels')} | {r.get('ecp5_lut4')} | {r.get('ecp5_pfu_ff')} | "
                     f"{r.get('ecp5_dp16kd')} | {r.get('ecp5_lutram')} | {fms} |\n")
        notes = [r for r in allr if r.get("pnr_note")]
        for r in notes:
            fh.write(f"\n¹ `{r['top']}`: {r['pnr_note']}\n")


if __name__ == "__main__":
    main()
