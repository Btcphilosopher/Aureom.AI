#!/usr/bin/env python3
"""
gen_ldpc_vectors.py -- vectors for tb/tb_sfecc_ldpc.sv from ref/sfecc_ldpc.py.

Per record: msg (8 B) | stored codeword (16 B) | received hard bytes (16 B) |
            expected message out, soft decoder (8 B) | expected message out, hard decoder (8 B)
            -> ldpc_bytes.memh;  128 channel LLRs (5-bit two's complement) -> ldpc_llr.memh;
            {it, nerr, code} for the soft and the hard decoder -> ldpc_st.memh (2 words/record).
Channels: clean, BI-AWGN at Eb/N0 = 1..5 dB (LLR scale 2, 5 bits), hard bit-flip patterns
(1..8 flips), erased (all-ones) words with 0..4 flips.
"""
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "ref"))
import sfecc_ldpc as LD  # noqa: E402

LLR_W = 5


def main():
    code = LD.QCLDPC()
    rnd = random.Random(128)
    recs = []

    def add(u_bytes, stored, llr_q):
        rx_bits = [1 if v < 0 else 0 for v in llr_q]
        soft = code.decode_oms_fixed(llr_q)
        hard = code.decode_oms_fixed(LD.hard_llr(rx_bits, (1 << (LLR_W - 1)) - 1))
        recs.append((u_bytes, LD.QCLDPC.bits_to_bytes(stored), LD.QCLDPC.bits_to_bytes(rx_bits), soft, hard, llr_q))

    def rand_msg():
        return bytes(rnd.getrandbits(8) for _ in range(8))

    n = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    for _ in range(n // 10):
        m = rand_msg()
        st = code.stored_bits(LD.QCLDPC.bytes_to_bits(m))
        add(m, st, LD.hard_llr(st))
    for eb in (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0):
        for _ in range(n // 7):
            m = rand_msg()
            st = code.stored_bits(LD.QCLDPC.bytes_to_bits(m))
            sigma = (1.0 / (2 * 0.5 * 10 ** (eb / 10))) ** 0.5
            llr = [2.0 * ((1.0 - 2.0 * b) + rnd.gauss(0, sigma)) / sigma ** 2 for b in st]
            add(m, st, LD.quantize(llr, 2.0, LLR_W))
    for w in range(1, 9):
        for _ in range(n // 8):
            m = rand_msg()
            st = code.stored_bits(LD.QCLDPC.bytes_to_bits(m))
            rx = st[:]
            for i in rnd.sample(range(LD.N), w):
                rx[i] ^= 1
            add(m, st, LD.hard_llr(rx))
    for w in range(0, 5):
        for _ in range(n // 20 + 1):
            st = [1] * LD.N
            rx = st[:]
            for i in rnd.sample(range(LD.N), w):
                rx[i] ^= 1
            add(b"\xff" * 8, st, LD.hard_llr(rx))
    d = os.path.join(ROOT, "build", "vec", "LDPC")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "ldpc_bytes.memh"), "w") as fb, open(os.path.join(d, "ldpc_llr.memh"), "w") as fl, \
            open(os.path.join(d, "ldpc_st.memh"), "w") as fs:
        for (m, cw, rx, so, ha, llr) in recs:
            fb.write("\n".join(f"{x:02x}" for x in m + cw + rx + so["msg"] + ha["msg"]) + "\n")
            fl.write("\n".join(f"{v & ((1 << LLR_W) - 1):02x}" for v in llr) + "\n")
            for r in (so, ha):
                fs.write(f"{(r['iters'] << 16) | (r['nerr'] << 8) | r['code']:08x}\n")
    with open(os.path.join(d, "tb_ldpc_cfg.svh"), "w") as fh:
        fh.write(f"`define TBL_NREC {len(recs)}\n`define TBL_LLR_W {LLR_W}\n")
    from collections import Counter
    print(f"LDPC: {len(recs)} records; soft codes {Counter(r[3]['code'] for r in recs)}; "
          f"hard codes {Counter(r[4]['code'] for r in recs)}; max soft iterations {max(r[3]['iters'] for r in recs)}")


if __name__ == "__main__":
    main()
