#!/usr/bin/env python3
"""
nand_twin_campaign.py -- fault injection with the NANDLab digital twin (Project 52).

Three campaigns, all on the vendored, unmodified twin (third_party/silicaflux-nandlab):

  directed    RTL (tb/tb_sfecc_nand_twin.sv, Verilator): ECC engine + pin-level SV NAND model.
              Directed 'stuck_bit' faults of the twin (applied at read time) placed on chosen
              codeword bits: 0 errors, 1 per codeword, exactly t, t+1, an 8-bit burst, random
              multi-bit, a stuck BBM bit, erased pages with 0 / 1-per-codeword / t+1 flips.
  retention   RTL: pages programmed through the ECC engine in one simulator run; the same
              persistent store is then read in later runs after cumulative unpowered bakes
              (+NANDLAB_BAKE_HOURS): the twin's own retention / read-disturb / read-noise
              physics produce the raw bit errors.
  statistical Python only: the twin's Python model (NandTarget, same physics) and the
              reference decoder, thousands of codewords per bake point, for t = 4 and t = 8.

Every raw page the RTL read is re-decoded with the reference model (bit-exact check of
payload, sector status, page status) and every sector outcome is classified against the
programmed truth: correct / detected (UNCORR or INTEGRITY) / undetected (wrong data, OK status).
Raw bit errors per codeword are counted against the programmed codeword.  The twin's
reliability numbers are illustrative (MODEL_LIMITATIONS.md): these are outcomes for that
error model, not NAND reliability.

    python3 scripts/nand_twin_campaign.py [directed] [retention] [statistical] [--quick]
"""
import json
import os
import random
import shutil
import subprocess
import sys
import time
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TWIN = os.path.join(ROOT, "third_party", "silicaflux-nandlab")
sys.path.insert(0, os.path.join(ROOT, "ref"))
sys.path.insert(0, TWIN)
import sfecc_configs as CFG                                            # noqa: E402
from sfecc_page import SS_NAMES                                         # noqa: E402
import nand_flash_twin as NT                                            # noqa: E402

NJ = 128                      # job slots compiled into the testbench
GEOM = dict(channels=1, packages_per_channel=1, targets_per_package=1, dies_per_target=1, luns_per_die=1,
            planes_per_lun=2, blocks_per_plane=4, pages_per_block=16)
UMETA_BYTE = 0xA5             # tb_sfecc_nand_twin drives constant user metadata

RTL = ["sfecc_bch_enc.sv", "sfecc_bch_syn.sv", "sfecc_bch_kes.sv", "sfecc_bch_chien.sv", "sfecc_bch_dec.sv",
       "sfecc_ldpc_enc.sv", "sfecc_ldpc_dec.sv", "sfecc_codec_enc.sv", "sfecc_codec_dec.sv", "sfecc_page_enc.sv", "sfecc_page_dec.sv", "silicaflux_storage_ecc.sv"]


# ------------------------------------------------------------------------------------ twin config
def twin_cfg(pf, profile, stuck=(), geom=None, bits_only=True):
    d = json.load(open(os.path.join(TWIN, "config", "slc_1gbit_class.json")))
    d["geometry"].update(geom or GEOM)
    d["geometry"]["page_data_bytes"] = pf.page_data
    d["geometry"]["page_spare_bytes"] = pf.page_spare
    d["faults"] = {"profile": profile}
    cfg = NT.load_config(None, profile, overrides={"geometry": d["geometry"]})
    if bits_only:
        # isolate bit errors: no factory-bad blocks, no program/erase failures
        f = cfg.faults
        f.factory_bad_block_rate = 0.0
        f.factory_bad_blocks = []
        f.prog_fail_fresh = f.prog_fail_at_rated = 0.0
        f.erase_fail_fresh = f.erase_fail_at_rated = 0.0
    cfg.directed.stuck_bits = [list(s) for s in stuck]
    return cfg.validate()


def rows_bits(cfg):
    g = cfg.geometry
    return g.row_page_bits, g.row_block_bits


# ------------------------------------------------------------------------------------ RTL build
def build_tb(name, pf, cfg, outdir):
    rp, rb = rows_bits(cfg)
    g = cfg.geometry
    inc = os.path.join(outdir, "inc")
    os.makedirs(inc, exist_ok=True)
    with open(os.path.join(inc, "tbn_cfg.svh"), "w") as fh:
        fh.write(f"`define TBN_P `SFECC_PAGE_{name}\n`define TBN_DATA {pf.page_data}\n`define TBN_SPARE {pf.page_spare}\n"
                 f"`define TBN_SECTORS {pf.sectors}\n`define TBN_NJOBS {NJ}\n`define TBN_PPB {g.pages_per_block}\n"
                 f"`define TBN_BPP {g.blocks_per_plane}\n`define TBN_PLANES {g.planes_per_lun}\n"
                 f"`define TBN_RP_BITS {rp}\n`define TBN_RB_BITS {rb}\n")
    mdir = os.path.join(outdir, "obj")
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O2",
           "--top-module", "tb_sfecc_nand_twin", "-I" + os.path.join(ROOT, "rtl"),
           "-I" + os.path.join(ROOT, "rtl", "generated"), "-I" + os.path.join(ROOT, "tb"), "-I" + inc,
           "--Mdir", mdir, "-o", "sim"] + [os.path.join(ROOT, "rtl", f) for f in RTL] + \
          [os.path.join(TWIN, "nand_flash_model.sv"), os.path.join(TWIN, "tb", "nand_ctrl_bfm.sv"),
           os.path.join(ROOT, "tb", "tb_sfecc_nand_twin.sv")]
    with open(os.path.join(outdir, "build.log"), "w") as log:
        subprocess.check_call(cmd, stdout=log, stderr=subprocess.STDOUT)
    return os.path.join(mdir, "sim")


def write_jobs(outdir, pf, jobs, payloads):
    """jobs: list of (flags, blk, pg); flags bit0 program, bit1 read, bit2 erase block (no program)."""
    with open(os.path.join(outdir, "jobs.memh"), "w") as fh:
        for j in range(NJ):
            if j < len(jobs):
                fl, b, p = jobs[j]
                fh.write(f"{(fl << 24) | (b << 8) | p:08x}\n")
            else:
                fh.write("00000000\n")
    with open(os.path.join(outdir, "pay.memh"), "w") as fh:
        for j in range(NJ):
            data = payloads[j] if j < len(payloads) and payloads[j] is not None else b"\x00" * pf.page_data
            fh.write("\n".join(f"{x:02x}" for x in data) + "\n")


def run_tb(sim, store, outdir, phase, tag, bake=None):
    args = [sim, f"+NANDLAB_DIR={store}", f"+JOBS={os.path.join(outdir, 'jobs.memh')}",
            f"+PAY={os.path.join(outdir, 'pay.memh')}", f"+DUMP={os.path.join(outdir, tag + '.dump')}",
            f"+PHASE={phase}", "+NANDLAB_QUIET"]
    if bake:
        args += [f"+NANDLAB_BAKE_HOURS={bake[0]}", f"+NANDLAB_BAKE_TEMP_C={bake[1]}"]
    t0 = time.time()
    out = subprocess.run(args, capture_output=True, text=True, cwd=outdir)
    open(os.path.join(outdir, tag + ".log"), "w").write(out.stdout + out.stderr)
    res = [ln for ln in out.stdout.splitlines() if ln.startswith("TB RESULT")]
    return (res[0] if res else "TB RESULT missing"), time.time() - t0


# ------------------------------------------------------------------------------------ analysis
def parse_dump(path, pf):
    pages = []
    cur = None
    for ln in open(path):
        f = ln.split()
        if not f:
            continue
        if f[0] == "P":
            cur = dict(job=int(f[1]), blk=int(f[2]), pg=int(f[3]), sst=[])
            pages.append(cur)
        elif f[0] == "R":
            cur["raw"] = bytes.fromhex(f[1])
        elif f[0] == "D":
            cur["pay"] = bytes.fromhex(f[1])
        elif f[0] == "S":
            cur["sst"].append(dict(sector=int(f[1]), code=int(f[2]), nerr=int(f[3]), crc_ok=int(f[4])))
        elif f[0] == "G":
            a, b = int(f[1], 16), int(f[2], 16)
            cur["pst"] = dict(n_corr=a & 255, n_unc=(a >> 8) & 255, n_int=(a >> 16) & 255, n_era=(a >> 24) & 255,
                              max=b & 255, tot=(b >> 8) & 0xFFFF, all_erased=(b >> 24) & 1, ok=(b >> 25) & 1,
                              ferr=(b >> 31) & 1)
    return pages


def analyse(pf, pages, truth):
    """truth[job] = (payload, programmed:bool).  Returns dict of checks and outcome tallies."""
    mism = []
    outc = Counter()
    per_cw = []
    um = [bytes([UMETA_BYTE]) * pf.umeta] * pf.sectors
    for p in pages:
        pay_t, programmed = truth[p["job"]]
        ref_pay, _, ref_sts, ref_pg = pf.decode_page(p["raw"])
        # 1. RTL == reference on the very same raw page
        if p["pay"] != ref_pay:
            mism.append((p["job"], "payload"))
        for s, r in zip(p["sst"], ref_sts):
            if (s["code"], s["nerr"], s["crc_ok"]) != (r["code"], r["nerr"], int(r["crc_ok"])):
                mism.append((p["job"], f"sector {s['sector']} rtl {s} ref {r['code'], r['nerr'], r['crc_ok']}"))
        pg = p["pst"]
        if (pg["n_corr"], pg["n_unc"], pg["n_int"], pg["n_era"], pg["max"], pg["tot"], pg["ok"]) != \
                (ref_pg["n_corrected"], ref_pg["n_uncorr"], ref_pg["n_integrity"], ref_pg["n_erased"],
                 ref_pg["max_bitflips"], ref_pg["total_bitflips"], int(ref_pg["ok"])):
            mism.append((p["job"], "page status"))
        # 2. truth: programmed codeword (or erased) vs raw read
        prog = pf.encode_page(pay_t, um) if programmed else b"\xff" * pf.raw_bytes
        for i, s in enumerate(p["sst"]):
            cw_t = pf.codeword_of(prog, i)
            cw_r = pf.codeword_of(p["raw"], i)
            nbits = sum(bin(a ^ b).count("1") for a, b in zip(cw_t, cw_r))
            sec_t = pay_t[i * pf.sector:(i + 1) * pf.sector] if programmed else b"\xff" * pf.sector
            sec_o = p["pay"][i * pf.sector:(i + 1) * pf.sector]
            code = s["code"]
            if code in (3, 4):
                cls = "detected"
            elif sec_o == sec_t:
                cls = "correct"
            else:
                cls = "undetected"
            outc[(SS_NAMES[code], cls)] += 1
            per_cw.append(dict(job=p["job"], sector=i, raw_errors=nbits, code=SS_NAMES[code], nerr=s["nerr"],
                               outcome=cls))
    return dict(mismatches=mism, outcomes={f"{a}/{b}": n for (a, b), n in sorted(outc.items())}, per_cw=per_cw)


# ------------------------------------------------------------------------------------ directed
def stream_to_twin_bit(pf, sec, s):
    """Codeword stream bit -> twin page bit index (byte*8 + LSB-numbered bit)."""
    rb = pf.codeword_stream_to_raw(sec, s)            # raw page bit, MSB-first numbering
    return (rb >> 3) * 8 + (7 - (rb & 7))


def directed(name="N2KT8", seed=54):
    pf = CFG.page(name)
    b = pf.bch
    t = b.t
    rnd = random.Random(seed)
    um = [bytes([UMETA_BYTE]) * pf.umeta] * pf.sectors
    payloads, jobs, plan, stuck = [], [], [], []

    def add_prog(blk, pg, desc, per_sector):
        """per_sector[i] = list of codeword stream bits to corrupt (stuck at the complement)."""
        pay = bytes(rnd.getrandbits(8) for _ in range(pf.page_data))
        raw = pf.encode_page(pay, um)
        for i, bits in enumerate(per_sector):
            for s in bits:
                rbit = pf.codeword_stream_to_raw(i, s)
                val = (raw[rbit >> 3] >> (7 - (rbit & 7))) & 1
                stuck.append((0, 0, blk, pg, stream_to_twin_bit(pf, i, s), 1 - val))
        jobs.append((3, blk, pg))
        payloads.append(pay)
        plan.append(dict(job=len(jobs) - 1, blk=blk, pg=pg, desc=desc, injected=[len(x) for x in per_sector]))

    def add_erased(blk, pg, desc, per_sector, erase_first):
        for i, bits in enumerate(per_sector):
            for s in bits:
                stuck.append((0, 0, blk, pg, stream_to_twin_bit(pf, i, s), 0))
        jobs.append(((4 if erase_first else 0) | 2, blk, pg))
        payloads.append(b"\xff" * pf.page_data)
        plan.append(dict(job=len(jobs) - 1, blk=blk, pg=pg, desc=desc, injected=[len(x) for x in per_sector]))

    V = b.valid_stream_bits()
    S = pf.sectors

    def on(k, bits):
        """bits on codeword k (mod S), no errors elsewhere"""
        return [bits if i == k % S else [] for i in range(S)]

    none = [[] for _ in range(S)]
    add_prog(0, 0, "no error", none)
    add_prog(0, 1, "1 error per codeword", [rnd.sample(V, 1) for _ in range(S)])
    add_prog(0, 2, f"exactly t={t} errors in codeword 0", on(0, rnd.sample(V, t)))
    add_prog(0, 3, f"t+1={t + 1} errors in codeword {1 % S} (beyond t)", on(1, rnd.sample(V, t + 1)))
    st0 = rnd.randint(0, b.ns - 8)
    add_prog(0, 4, f"8-bit burst in codeword {S - 1}", on(S - 1, list(range(st0, st0 + 8))))
    add_prog(0, 5, "random multi-bit errors (3/5/2/6 per codeword)", [rnd.sample(V, n) for n in ([3, 5, 2, 6] * S)[:S]])
    # BBM byte (spare offset 0, not ECC protected): stuck-at-0 on its MSB
    jobs.append((3, 0, 6))
    pay6 = bytes(rnd.getrandbits(8) for _ in range(pf.page_data))
    payloads.append(pay6)
    stuck.append((0, 0, 0, 6, pf.page_data * 8 + 7, 0))
    plan.append(dict(job=len(jobs) - 1, blk=0, pg=6, desc="bad-block-marker byte bit stuck at 0", injected=[0] * S))
    add_erased(1, 0, "erased page, no flips", none, True)
    add_erased(1, 1, "erased page, 1 flip per codeword", [rnd.sample(V, 1) for _ in range(S)], False)
    add_erased(1, 2, f"erased page, t+1={t + 1} flips in codeword {S - 1}", on(S - 1, rnd.sample(V, t + 1)), False)
    assert len(stuck) <= 64, len(stuck)
    cfg = twin_cfg(pf, "ideal", stuck)
    out = os.path.join(ROOT, "build", "twin", f"{name}_directed")
    shutil.rmtree(out, ignore_errors=True)
    store = os.path.join(out, "store")
    os.makedirs(store)
    NT.export_svcfg(cfg, os.path.join(store, "nandlab.svcfg"))
    write_jobs(out, pf, jobs, payloads)
    sim = build_tb(name, pf, cfg, out)
    res, secs = run_tb(sim, store, out, 0, "run")
    pages = parse_dump(os.path.join(out, "run.dump"), pf)
    truth = {j: (payloads[j], bool(jobs[j][0] & 1)) for j in range(len(jobs))}
    an = analyse(pf, pages, truth)
    for p in plan:
        cws = [c for c in an["per_cw"] if c["job"] == p["job"]]
        p["raw_errors"] = [c["raw_errors"] for c in cws]
        p["status"] = [f"{c['code']}({c['nerr']})" for c in cws]
        p["outcome"] = [c["outcome"] for c in cws]
        pg = [x for x in pages if x["job"] == p["job"]][0]
        p["bbm"] = f"0x{pg['raw'][pf.page_data]:02x}"
    return dict(cfg=name, sim=res, seconds=round(secs, 1), stuck_bits=len(stuck), plan=plan,
                rtl_vs_ref_mismatches=an["mismatches"], outcomes=an["outcomes"])


# ------------------------------------------------------------------------------------ retention
def retention(name="N2KT8", steps=((0, 40.0), (2000, 40.0), (2000, 40.0), (4000, 40.0)), seed=7, quick=False):
    pf = CFG.page(name)
    rnd = random.Random(seed)
    blocks = range(2, 8) if not quick else range(2, 4)
    jobs, payloads = [], []
    for blk in blocks:
        for pg in range(GEOM["pages_per_block"]):
            jobs.append((3, blk, pg))
            payloads.append(bytes(rnd.getrandbits(8) for _ in range(pf.page_data)))
    cfg = twin_cfg(pf, "stress")
    out = os.path.join(ROOT, "build", "twin", f"{name}_retention")
    shutil.rmtree(out, ignore_errors=True)
    store = os.path.join(out, "store")
    os.makedirs(store)
    NT.export_svcfg(cfg, os.path.join(store, "nandlab.svcfg"))
    write_jobs(out, pf, jobs, payloads)
    sim = build_tb(name, pf, cfg, out)
    res_prog, s0 = run_tb(sim, store, out, 1, "program")
    truth = {j: (payloads[j], True) for j in range(len(jobs))}
    results = []
    cum = 0.0
    for i, (h, temp) in enumerate(steps):
        cum += h
        res, secs = run_tb(sim, store, out, 2, f"read{i}", bake=(h, temp) if h else None)
        pages = parse_dump(os.path.join(out, f"read{i}.dump"), pf)
        an = analyse(pf, pages, truth)
        errs = [c["raw_errors"] for c in an["per_cw"]]
        hist = Counter(min(e, 4 * pf.bch.t) for e in errs)
        results.append(dict(step=i, bake_hours=h, cumulative_hours_at_40C=cum, sim=res, seconds=round(secs, 1),
                            codewords=len(errs), mean_raw_errors=round(sum(errs) / max(1, len(errs)), 3),
                            max_raw_errors=max(errs) if errs else 0,
                            beyond_t=sum(1 for e in errs if e > pf.bch.t),
                            raw_ber=sum(errs) / max(1, len(errs) * pf.bch.ns),
                            outcomes=an["outcomes"], rtl_vs_ref_mismatches=an["mismatches"],
                            raw_error_hist={str(k): v for k, v in sorted(hist.items())}))
        print(f"  retention step {i}: +{h} h -> {results[-1]['mean_raw_errors']} raw errors/cw, "
              f"outcomes {an['outcomes']}, mismatches {len(an['mismatches'])}")
    return dict(cfg=name, program_run=res_prog, program_seconds=round(s0, 1), pages=len(jobs), steps=results)


# ------------------------------------------------------------------------------------ statistical (Python twin)
def statistical(names=("N512T4", "N2KT8"), hours=(0, 1000, 2000, 3000, 4000, 6000), npages=None, quick=False):
    out = {}
    tmp = os.path.join(ROOT, "build", "twin", "pystores")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    for name in names:
        pf = CFG.page(name)
        geom = dict(GEOM, blocks_per_plane=8)
        cfg = twin_cfg(pf, "stress", geom=geom)
        tgt = NT.NandTarget(cfg, os.path.join(tmp, f"{name}.nlsf"), journal=False)
        tgt.reset()
        rnd = random.Random(99)
        um = [bytes([UMETA_BYTE]) * pf.umeta] * pf.sectors
        blocks = range(0, 16) if not quick else range(0, 2)
        truth = {}
        for blk in blocks:
            tgt.erase_block(0, blk)
            for pg in range(geom["pages_per_block"]):
                pay = bytes(rnd.getrandbits(8) for _ in range(pf.page_data))
                r = tgt.program_page(0, blk, pg, pf.encode_page(pay, um))
                truth[(blk, pg)] = pay
        rows = []
        for h in hours:
            if h:
                tgt.bake(h - (rows[-1]["hours_at_40C"] if rows else 0), 40.0)
            outc, errs = Counter(), []
            for (blk, pg), pay in truth.items():
                raw = tgt.read_page(0, blk, pg).data
                pay_o, _, sts, _ = pf.decode_page(raw)
                prog = pf.encode_page(pay, um)
                for i, s in enumerate(sts):
                    errs.append(sum(bin(a ^ b).count("1") for a, b in zip(pf.codeword_of(prog, i), pf.codeword_of(raw, i))))
                    sec_t, sec_o = pay[i * pf.sector:(i + 1) * pf.sector], pay_o[i * pf.sector:(i + 1) * pf.sector]
                    cls = "detected" if s["code"] in (3, 4) else ("correct" if sec_o == sec_t else "undetected")
                    outc[cls] += 1
                    outc["status_" + SS_NAMES[s["code"]]] += 1
            n = len(errs)
            rows.append(dict(hours_at_40C=h, codewords=n, raw_ber=sum(errs) / (n * pf.bch.ns),
                             mean_raw_errors=sum(errs) / n, frac_beyond_t=sum(1 for e in errs if e > pf.bch.t) / n,
                             correct=outc["correct"], detected=outc["detected"], undetected=outc["undetected"],
                             statuses={k[7:]: v for k, v in outc.items() if k.startswith("status_")}))
            print(f"  {name} {h:>5} h: RBER {rows[-1]['raw_ber']:.2e} mean {rows[-1]['mean_raw_errors']:.2f} "
                  f">t {rows[-1]['frac_beyond_t']:.3f} correct {outc['correct']} detected {outc['detected']} "
                  f"undetected {outc['undetected']}")
        out[name] = dict(t=pf.bch.t, n_bits=pf.bch.ns, rows=rows)
    return out


def main():
    quick = "--quick" in sys.argv
    which = [a for a in sys.argv[1:] if not a.startswith("--")] or ["directed", "retention", "statistical"]
    rep_path = os.path.join(ROOT, "reports", "nand_twin.json")
    rep = json.load(open(rep_path)) if os.path.exists(rep_path) else {}
    if "directed" in which:
        print("directed (RTL + SV twin) ...")
        rep["directed"] = [directed("N2KT8"), directed("N512T4")]
        for d in rep["directed"]:
            print(" ", d["cfg"], d["sim"], "mismatches", len(d["rtl_vs_ref_mismatches"]), d["outcomes"])
    if "retention" in which:
        print("retention (RTL + SV twin, persistent store, bakes) ...")
        rep["retention"] = retention("N2KT8", quick=quick)
    if "statistical" in which:
        print("statistical (Python twin + reference decoder) ...")
        rep["statistical"] = statistical(quick=quick)
    os.makedirs(os.path.dirname(rep_path), exist_ok=True)
    json.dump(rep, open(rep_path, "w"), indent=1, default=str)
    print("wrote", os.path.relpath(rep_path, ROOT))


if __name__ == "__main__":
    main()
