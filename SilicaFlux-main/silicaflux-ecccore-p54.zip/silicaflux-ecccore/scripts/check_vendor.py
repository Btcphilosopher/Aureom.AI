#!/usr/bin/env python3
"""check_vendor.py -- vendored third-party files are unmodified.

Checks every SHA256SUMS file under third_party/ and ext/.  With --repo <Aureom.AI checkout> it also
compares third_party/silicaflux-nandlab byte for byte with the files inside the original archive
SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-nandlab-v0.1.0.zip."""
import hashlib
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    bad, n = [], 0
    for base in ("third_party/silicaflux-nandlab", "ext/linux_bch", "ext/pyldpc"):
        d = os.path.join(ROOT, base)
        for line in open(os.path.join(d, "SHA256SUMS")):
            h, f = line.split(None, 1)
            f = f.strip()
            p = os.path.join(d, f) if not os.path.isabs(f) else f
            if not os.path.exists(p):
                p = os.path.join(d, os.path.basename(f))
            n += 1
            if hashlib.sha256(open(p, "rb").read()).hexdigest() != h:
                bad.append(os.path.join(base, f))
    if "--repo" in sys.argv:
        repo = sys.argv[sys.argv.index("--repo") + 1]
        z = zipfile.ZipFile(os.path.join(repo, "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-nandlab-v0.1.0.zip"))
        d = os.path.join(ROOT, "third_party", "silicaflux-nandlab")
        for rel in ("nand_flash_model.sv", "nand_flash_twin.py", "tb/nand_ctrl_bfm.sv", "MODEL_LIMITATIONS.md",
                    "README.md", "config/fault_profiles.json", "config/slc_tiny.json", "config/slc_1gbit_class.json"):
            n += 1
            if z.read("silicaflux-nandlab/" + rel) != open(os.path.join(d, rel), "rb").read():
                bad.append("archive mismatch: " + rel)
    for b in bad:
        print("MODIFIED", b)
    print(f"{n - len(bad)}/{n} vendored files verified unmodified")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
