#!/usr/bin/env python3
"""
run_coverage.py -- code coverage (Verilator line + toggle) and functional coverage.

Builds coverage-instrumented models of the core, page and LDPC testbenches for the
configurations that exercise different RTL paths (LPAD: B255T4; TPAD + user metadata:
N512T4; t = 8: N512T8 / N2KT8; 3 buffer banks; the LDPC codec behind the page engine),
runs them, merges the coverage databases and writes reports/coverage.md:
  * line and toggle coverage per RTL file (elaboration-time functions excluded from the
    interpretation; unreachable toggle bits are listed, not hidden);
  * functional coverage from the testbench JSON: error category x decoder status, error
    weight x truth outcome, corrected-bit histogram, sector-status classes.
"""
import glob
import json
import os
import re
import subprocess
import sys
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
C = os.path.join(ROOT, "build", "cov")
RTL = [l.strip() for l in open(os.path.join(ROOT, "rtl", "files.f")) if l.strip() and not l.startswith("//")]
CATS = ["CLEAN", "SINGLE", "MULTI", "EXACT_T", "T_PLUS_1", "BEYOND", "BURST", "ERASED", "ERASED_FLIP",
        "ERASED_BEYOND", "BOUNDARY", "PATTERN", "EXH_DOUBLE", "RANDOM_RBER"]

RUNS = [
    # name, top, include dir, extra -G, plusargs, rtl subset
    ("core_B255T4", "tb_sfecc_bch", "build/vec/B255T4", [], ["+VEC=../vec/B255T4"], "bch"),
    ("core_B255T4_nb3", "tb_sfecc_bch", "build/vec/B255T4", ["-GNBANKS_TB=3"], ["+VEC=../vec/B255T4"], "bch"),
    ("core_N512T4", "tb_sfecc_bch", "build/vec/N512T4", [], ["+VEC=../vec/N512T4"], "bch"),
    ("core_N512T8", "tb_sfecc_bch", "build/vec/N512T8", [], ["+VEC=../vec/N512T8"], "bch"),
    ("page_N2KT8", "tb_sfecc_page", "build/vec/N2KT8", [], ["+VEC=../vec/N2KT8"], "all"),
    ("page_N512T4", "tb_sfecc_page", "build/vec/N512T4", [], ["+VEC=../vec/N512T4"], "all"),
    ("page_L24", "tb_sfecc_page", "build/vec/L24", [], ["+VEC=../vec/L24"], "all"),
    ("ldpc", "tb_sfecc_ldpc", "build/vec/LDPC", [], ["+VEC=../vec/LDPC"], "ldpc"),
]


def build_and_run(name, top, inc, gen, plus, subset):
    obj = os.path.join(C, "obj_" + name)
    files = {"bch": [f for f in RTL if "bch_" in f], "ldpc": [f for f in RTL if "ldpc_" in f], "all": RTL}[subset]
    tb = os.path.join("tb", top + ".sv")
    cmd = ["verilator", "--cc", "--exe", "--build", "--timing", "--coverage-line", "--coverage-toggle",
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O1", "--top-module", top, "-Irtl", "-Irtl/generated", "-Itb",
           "-I" + inc, "--Mdir", obj, "-o", "sim", "-CFLAGS", f"-DSFECC_COV_TOP=V{top} -DSFECC_COV_TOPH=V{top}.h"] + \
          gen + files + [tb, os.path.join(ROOT, "tb", "cov", "cov_main.cpp")]
    with open(os.path.join(C, name + ".build.log"), "w") as log:
        subprocess.check_call(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    r = subprocess.run([os.path.join(obj, "sim")] + plus + [f"+OUT={name}.json", f"+COVFILE={name}.dat"],
                       cwd=C, capture_output=True, text=True)
    res = [l for l in r.stdout.splitlines() if "TB RESULT" in l]
    print(name, res[0] if res else r.stdout[-300:])
    return res[0] if res else "no result"


def parse_dat(path):
    pts = {}
    for ln in open(path, errors="replace"):
        if not ln.startswith("C '"):
            continue
        body, cnt = ln[3:].rsplit("' ", 1)
        kv = dict(x.split("\x02", 1) for x in body.split("\x01") if "\x02" in x)
        pts[body] = (kv, int(cnt))
    return pts


ELAB_FUNCS = ("sfecc_gfc_mul", "sfecc_gfc_apow", "sfecc_gfc_prim_ok", "gpoly_ok", "mk_maskv", "mk_par", "odd_part",
              "two_pow", "shift_of", "act_of")


def elab_lines():
    """(file, line) pairs inside elaboration-time (constant) functions: they run in the compiler, never in
    simulation, so their line points are structurally 0 and are reported separately."""
    out = set()
    for f in RTL + ["rtl/sfecc_gf_funcs.svh", "rtl/sfecc_crc16.svh"]:
        lines = open(os.path.join(ROOT, f)).read().splitlines()
        inside = False
        for i, ln in enumerate(lines, 1):
            m = re.search(r"function\s+automatic\s+.*?(\w+)\s*\(", ln)
            if m and m.group(1) in ELAB_FUNCS:
                inside = True
            if inside:
                out.add((f, str(i)))
                if "endfunction" in ln:
                    inside = False
    return out


def main():
    os.makedirs(C, exist_ok=True)
    results = {}
    if "--report-only" not in sys.argv:
        for run in RUNS:
            results[run[0]] = build_and_run(*run)
        dats = [os.path.join(C, r[0] + ".dat") for r in RUNS]
        subprocess.check_call(["verilator_coverage", "--write", os.path.join(C, "merged.dat")] + dats)
    pts = parse_dat(os.path.join(C, "merged.dat"))
    agg = defaultdict(lambda: [0, 0])
    zero = defaultdict(list)
    elab = elab_lines()
    n_elab = 0
    for key, (kv, cnt) in pts.items():
        f = kv.get("f", "?")
        if not f.startswith("rtl/"):
            continue
        typ = kv.get("page", "").split("/")[0].replace("v_", "")
        if typ == "line" and (f, kv.get("l")) in elab:
            n_elab += 1
            continue
        agg[(f, typ)][1] += 1
        if cnt > 0:
            agg[(f, typ)][0] += 1
        else:
            zero[f].append(f"{typ} line {kv.get('l')} {kv.get('o', '')} ({kv.get('h', '').split('.')[-1]})")
    files = sorted({f for f, _ in agg})
    tot = defaultdict(lambda: [0, 0])
    with open(os.path.join(ROOT, "reports", "coverage.md"), "w") as fh:
        fh.write("# Coverage\n\n## 1. Code coverage — Verilator 5.020 line + toggle, merged over "
                 f"{len(RUNS)} instrumented runs\n\n")
        fh.write("Runs: " + ", ".join(f"`{r[0]}`" for r in RUNS) + ".\n\n")
        fh.write(f"Line points inside elaboration-time constant functions ({', '.join(ELAB_FUNCS)}) execute in the\n"
                 f"compiler, never in simulation; their {n_elab} points are excluded from the line columns.\n\n")
        fh.write("| RTL file | line points hit | line % | toggle points hit | toggle % |\n|---|---|---|---|---|\n")
        for f in files:
            lh, lt = agg[(f, "line")]
            th, tt = agg[(f, "toggle")]
            tot["line"][0] += lh; tot["line"][1] += lt; tot["toggle"][0] += th; tot["toggle"][1] += tt
            fh.write(f"| `{f}` | {lh}/{lt} | {100.0 * lh / max(1, lt):.1f} | {th}/{tt} | {100.0 * th / max(1, tt):.1f} |\n")
        fh.write(f"| **total** | {tot['line'][0]}/{tot['line'][1]} | **{100.0 * tot['line'][0] / max(1, tot['line'][1]):.1f}** | "
                 f"{tot['toggle'][0]}/{tot['toggle'][1]} | **{100.0 * tot['toggle'][0] / max(1, tot['toggle'][1]):.1f}** |\n\n")
        fh.write("Uncovered points (every one is listed; see the classification in docs/06_VERIFICATION.md §5):\n\n")
        for f in files:
            if zero[f]:
                fh.write(f"<details><summary><code>{f}</code>: {len(zero[f])} points</summary>\n\n```\n" +
                         "\n".join(sorted(set(zero[f]))[:400]) + "\n```\n</details>\n\n")
        # ---------------- functional coverage
        fh.write("## 2. Functional coverage (core testbench, MAIN phase)\n\n")
        for cfg in ["B255T4", "N512T4", "N512T8", "N8KT40"]:
            p = os.path.join(ROOT, "build", f"tb_bch_{cfg}_nb2.json")
            if not os.path.exists(p):
                continue
            j = json.load(open(p))
            fh.write(f"### {cfg} — {j['records']} records, truth: correct {j['truth']['correct']}, detected "
                     f"{j['truth']['detected']}, miscorrected (undetected by BCH) {j['truth']['miscorrected']}\n\n")
            fh.write("| error category | CLEAN | CORRECTED | ERASED | UNCORR | miscorrected | correct |\n|---|---|---|---|---|---|---|\n")
            for i, row in enumerate(j["cat_status"]):
                if sum(row[:4]):
                    fh.write(f"| {CATS[i]} | " + " | ".join(str(x) for x in row) + " |\n")
            fh.write("\n| errors in codeword | correct | detected | miscorrected |\n|---|---|---|---|\n")
            for w, row in enumerate(j["weight_class"]):
                if sum(row):
                    fh.write(f"| {w}{'+' if w == 63 else ''} | {row[0]} | {row[1]} | {row[2]} |\n")
            fh.write("\nCorrected-bit count reported (0..t): " + ", ".join(f"{i}: {n}" for i, n in enumerate(j["nerr_hist"])) + "\n\n")
        fh.write("## 3. Page-level sector outcomes\n\n| config | pages | CLEAN | CORRECTED | ERASED | UNCORR | INTEGRITY |\n|---|---|---|---|---|---|---|\n")
        for cfg in ["N512T4", "N2KT8", "N8KT40", "L24"]:
            p = os.path.join(ROOT, "build", f"tb_page_{cfg}.json")
            if os.path.exists(p):
                j = json.load(open(p))
                fh.write(f"| {cfg} | {j['pages']} | " + " | ".join(str(x) for x in j["sector_codes"]) + " |\n")
    json.dump(dict(runs=results, totals={k: v for k, v in tot.items()}), open(os.path.join(ROOT, "reports", "coverage.json"), "w"), indent=1)
    print("line", tot["line"], "toggle", tot["toggle"])


if __name__ == "__main__":
    main()
