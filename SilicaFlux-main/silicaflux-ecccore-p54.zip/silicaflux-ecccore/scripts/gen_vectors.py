#!/usr/bin/env python3
"""
gen_vectors.py -- reference-model test vectors for the RTL testbenches.

Core vectors (tb/tb_sfecc_bch.sv), build/vec/<CFG>/:
  core_bytes.memh  per record: msg (MSG_BYTES) | stored codeword (CW_BYTES) |
                   received word = codeword XOR error pattern (CW_BYTES) |
                   expected decoder output (MSG_BYTES)            -- one byte per line
  core_st.memh     per record: {weight[27:20], cat[15:10], nerr[9:2], code[1:0]}
  tb_cfg.svh       parameter macros for the testbench
  core_meta.json   category counts
Every expected value comes from ref/sfecc_bch.py (BCHFormat.encode / .decode), which is
validated against galois and Linux lib/bch.c (scripts/validate_ref.py).

Error categories (fault-injection classes of the task):
   0 CLEAN       no error                       7 ERASED        all-ones stored word
   1 SINGLE      1 error (exhaustive or random)  8 ERASED_FLIP   erased + 1..t flips (1->0)
   2 MULTI       2..t-1 errors                   9 ERASED_BEYOND erased + t+1..t+3 flips
   3 EXACT_T     exactly t errors               10 BOUNDARY      first/last/region-edge/pad bits
   4 T_PLUS_1    t+1 errors                     11 PATTERN       0x00/0xFF/0x55/walking data + 0..t
   5 BEYOND      t+2 .. 2t+3 errors             12 EXH_DOUBLE    every 2-bit pattern (B255T4)
   6 BURST       contiguous burst 2..2t+2 bits  13 RANDOM_RBER   binomial errors at a raw BER
"""
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "ref"))
import sfecc_configs as CFG                     # noqa: E402
from sfecc_bch import ST_UNCORR                 # noqa: E402

CATS = ["CLEAN", "SINGLE", "MULTI", "EXACT_T", "T_PLUS_1", "BEYOND", "BURST", "ERASED", "ERASED_FLIP",
        "ERASED_BEYOND", "BOUNDARY", "PATTERN", "EXH_DOUBLE", "RANDOM_RBER"]
C = {n: i for i, n in enumerate(CATS)}

# records per category for each configuration (EXH_* handled separately)
PLAN = {
    "B255T4": dict(n_rand=400, exh_single=True, exh_double=True, rber=[0.004, 0.01, 0.02]),
    "N512T4": dict(n_rand=120, exh_single=True, exh_double=False, rber=[2e-4, 5e-4, 1e-3]),
    "N512T8": dict(n_rand=120, exh_single=True, exh_double=False, rber=[5e-4, 1e-3, 2e-3]),
    "N8KT40": dict(n_rand=12, exh_single=False, exh_double=False, rber=[2e-3, 4e-3]),
}


class Gen:
    def __init__(self, name, seed):
        self.name = name
        self.f = CFG.core(name)
        self.rnd = random.Random(seed)
        self.recs = []
        self.valid = self.f.valid_stream_bits()

    def rand_msg(self):
        f = self.f
        m = bytearray(self.rnd.getrandbits(8) for _ in range(f.msg_bytes))
        if f.lpad:
            m[0] &= 0xFF >> f.lpad
        return bytes(m)

    def add(self, cat, msg, err_bits, base=None):
        """err_bits: stream bit indices to flip (may include padding bits)."""
        f = self.f
        cw = f.encode(msg) if base is None else base
        rx = f.flip(cw, err_bits)
        out, st = f.decode(rx)
        w = sum(1 for s in set(err_bits) if f.stream_bit_degree(s) is not None)
        self.recs.append((msg, cw, rx, out, st["code"], st["nerr"], cat, min(w, 255)))

    def pos(self, w):
        return self.rnd.sample(self.valid, w)

    def build(self, plan):
        f, t, n = self.f, self.f.t, plan["n_rand"]
        for _ in range(n):
            self.add(C["CLEAN"], self.rand_msg(), [])
        if plan["exh_single"]:
            msg = self.rand_msg()
            cw = f.encode(msg)
            for s in self.valid:
                self.add(C["SINGLE"], msg, [s], cw)
        else:
            for _ in range(n):
                self.add(C["SINGLE"], self.rand_msg(), self.pos(1))
        for _ in range(n):
            self.add(C["MULTI"], self.rand_msg(), self.pos(self.rnd.randint(2, max(2, t - 1))))
        for _ in range(2 * n):
            self.add(C["EXACT_T"], self.rand_msg(), self.pos(t))
        for _ in range(2 * n):
            self.add(C["T_PLUS_1"], self.rand_msg(), self.pos(t + 1))
        for _ in range(2 * n):
            self.add(C["BEYOND"], self.rand_msg(), self.pos(self.rnd.randint(t + 2, 2 * t + 3)))
        for _ in range(2 * n):
            ln = self.rnd.randint(2, 2 * t + 2)
            st = self.rnd.randint(f.lpad, f.lpad + f.ns - ln)
            self.add(C["BURST"], self.rand_msg(), list(range(st, st + ln)))
        ones = b"\xff" * f.msg_bytes
        er = b"\xff" * f.cw_bytes
        for _ in range(max(4, n // 8)):
            self.add(C["ERASED"], ones, [], er)
        for _ in range(n):
            self.add(C["ERASED_FLIP"], ones, self.pos(self.rnd.randint(1, t)), er)
        for _ in range(n // 2):
            self.add(C["ERASED_BEYOND"], ones, self.pos(self.rnd.randint(t + 1, t + 3)), er)
        # boundaries: first/last valid bit, message/parity edge, byte edges, padding bits
        lo, hi = f.lpad, f.lpad + f.ns - 1
        msg_end = 8 * f.msg_bytes - 1          # last message stream bit
        edges = [lo, lo + 1, msg_end, msg_end + 1, hi, hi - 1, 7, 8, 8 * (f.msg_bytes // 2) - 1,
                 8 * (f.msg_bytes // 2)]
        pads = list(range(0, f.lpad)) + list(range(hi + 1, 8 * f.cw_bytes))
        for e in edges:
            self.add(C["BOUNDARY"], self.rand_msg(), [e])
        for k in range(1, t + 1):
            self.add(C["BOUNDARY"], self.rand_msg(), edges[:k])
            self.add(C["BOUNDARY"], self.rand_msg(), list(range(hi - k + 1, hi + 1)))     # tail
            self.add(C["BOUNDARY"], self.rand_msg(), list(range(lo, lo + k)))             # head
            self.add(C["BOUNDARY"], self.rand_msg(), list(range(msg_end - k // 2, msg_end - k // 2 + k)))
        for p in pads:                                  # flips in padding are not errors
            self.add(C["BOUNDARY"], self.rand_msg(), [p])
            self.add(C["BOUNDARY"], self.rand_msg(), [p] + self.pos(t))
        # data patterns
        pats = [b"\x00" * f.msg_bytes, b"\xff" * f.msg_bytes, b"\x55" * f.msg_bytes, b"\xaa" * f.msg_bytes,
                bytes((1 << (i % 8)) for i in range(f.msg_bytes)), bytes(i & 0xFF for i in range(f.msg_bytes))]
        for p in pats:
            if f.lpad:
                p = bytes([p[0] & (0xFF >> f.lpad)]) + p[1:]
            for w in range(0, t + 2):
                self.add(C["PATTERN"], p, self.pos(w))
        if plan["exh_double"]:
            msg = self.rand_msg()
            cw = f.encode(msg)
            v = self.valid
            for i in range(len(v)):
                for j in range(i + 1, len(v)):
                    self.add(C["EXH_DOUBLE"], msg, [v[i], v[j]], cw)
        for ber in plan["rber"]:
            for _ in range(n):
                errs = [s for s in self.valid if self.rnd.random() < ber]
                self.add(C["RANDOM_RBER"], self.rand_msg(), errs)
        return self

    def write(self, outdir):
        f = self.f
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, "core_bytes.memh"), "w") as fb, \
                open(os.path.join(outdir, "core_st.memh"), "w") as fs:
            for (msg, cw, rx, out, code, nerr, cat, w) in self.recs:
                fb.write("\n".join(f"{x:02x}" for x in msg + cw + rx + out) + "\n")
                fs.write(f"{(w << 20) | (cat << 10) | (nerr << 2) | code:08x}\n")
        counts = {}
        for r in self.recs:
            counts[CATS[r[6]]] = counts.get(CATS[r[6]], 0) + 1
        exp = {"uncorr": sum(1 for r in self.recs if r[4] == ST_UNCORR)}
        meta = dict(cfg=self.name, records=len(self.recs), categories=counts, expected=exp, code=f.describe())
        json.dump(meta, open(os.path.join(outdir, "core_meta.json"), "w"), indent=1)
        lpmask = 0xFF >> f.lpad
        with open(os.path.join(outdir, "tb_cfg.svh"), "w") as fh:
            fh.write(f"// generated by scripts/gen_vectors.py for {self.name}\n")
            fh.write(f"`define TB_CFG_NAME \"{self.name}\"\n")
            fh.write(f"`define TB_ENC_P `SFECC_ENC_{self.name}\n")
            fh.write(f"`define TB_DEC_P `SFECC_DEC_{self.name}\n")
            fh.write(f"`define TB_MSG {f.msg_bytes}\n`define TB_CW {f.cw_bytes}\n`define TB_T {f.t}\n")
            fh.write(f"`define TB_NREC {len(self.recs)}\n`define TB_LMASK 8'h{lpmask:02x}\n")
        return meta


PAGE_PLAN = {"N512T4": 60, "N512T8": 60, "N2KT8": 60, "N8KT40": 20, "L24": 200}


def main():
    if "--page" in sys.argv:
        names = [a for a in sys.argv[1:] if not a.startswith("--")] or list(PAGE_PLAN)
        for i, name in enumerate(names):
            write_page_vectors(name, PAGE_PLAN[name], 5000 + i)
        return
    cfgs = sys.argv[1:] or list(PLAN)
    for i, name in enumerate(cfgs):
        meta = Gen(name, 1000 + i).build(PLAN[name]).write(os.path.join(ROOT, "build", "vec", name))
        print(f"{name}: {meta['records']} records {meta['categories']}")



# =============================================================================================
# Page-level vectors (tb/tb_sfecc_page.sv): build/vec/<CFG>/page_*.memh
# =============================================================================================
PAGE_CATS = ["CLEAN", "CORRECTABLE", "MIXED", "UNCORR", "ERASED", "ERASED_FLIPS", "MISCORRECT", "CODEWORD_ERR",
             "BBM", "BURST"]


def page_records(name, npages, seed):
    """Returns list of (cat, payload, umeta list, raw_exp, raw_rx) with every expectation from the reference."""
    from sfecc_page import crc16_ccitt_false   # noqa: F401
    pf = CFG.page(name)
    b = pf.bch
    rnd = random.Random(seed)
    out = []

    def rand_page():
        pay = bytes(rnd.getrandbits(8) for _ in range(pf.page_data))
        um = [bytes(rnd.getrandbits(8) for _ in range(pf.umeta)) for _ in range(pf.sectors)]
        return pay, um

    def flip_cw(raw, sec, stream_bits):
        r = bytearray(raw)
        for s in stream_bits:
            bit = pf.codeword_stream_to_raw(sec, s)
            r[bit >> 3] ^= 0x80 >> (bit & 7)
        return bytes(r)

    valid = b.valid_stream_bits()
    if hasattr(b, "nonzero_codeword_bits"):                      # LDPC codec
        g_bits = None
    else:
        g_bits = [b.degree_stream_bit(d) for d in range(b.r + 1) if (b.g >> d) & 1]

    def cw_pattern():
        """stream bits of a non-zero codeword whose support reaches the sector data"""
        if g_bits is None:
            return b.nonzero_codeword_bits(rnd)
        shift = rnd.randint(8 * pf.sector // 2, 8 * pf.sector - 1)
        return [x - shift for x in g_bits if x - shift >= 0]
    for i in range(npages):
        cat = PAGE_CATS[i % len(PAGE_CATS)]
        pay, um = rand_page()
        raw = pf.encode_page(pay, um)
        rx = raw
        if cat == "CORRECTABLE":
            for s in range(pf.sectors):
                rx = flip_cw(rx, s, rnd.sample(valid, rnd.randint(1, b.t)))
        elif cat == "MIXED":
            for s in range(pf.sectors):
                w = rnd.choice([0, 1, b.t, b.t + 1, b.t + 3])
                rx = flip_cw(rx, s, rnd.sample(valid, w))
        elif cat == "UNCORR":
            for s in range(pf.sectors):
                rx = flip_cw(rx, s, rnd.sample(valid, rnd.randint(b.t + 1, 2 * b.t + 4)))
        elif cat in ("ERASED", "ERASED_FLIPS"):
            # program path still checks the encoding of an all-0xFF payload; the READ is of an
            # erased page (never programmed): every column 0xFF
            pay = b"\xff" * pf.page_data
            um = [b"\xff" * pf.umeta] * pf.sectors
            raw = pf.encode_page(pay, um)
            rx = b"\xff" * pf.raw_bytes
            if cat == "ERASED_FLIPS":
                for s in range(pf.sectors):
                    rx = flip_cw(rx, s, rnd.sample(valid, rnd.randint(0, b.t + (1 if s == 0 else 0))))
        elif cat == "MISCORRECT":
            # received = c + x^j g(x) + e2, wt(e2) <= t: the decoder lands on the codeword c + x^j g(x)
            # (a miscorrection); the CRC-16 must catch it.  j moves g into the sector data.
            for s in range(pf.sectors):
                bits = cw_pattern()
                e2 = rnd.sample(valid, rnd.randint(0, b.t))
                rx = flip_cw(rx, s, list(set(bits) ^ set(e2)))
        elif cat == "CODEWORD_ERR":
            # error pattern = a non-zero codeword: syndromes are zero, BCH reports CLEAN; CRC must catch it
            for s in range(pf.sectors):
                rx = flip_cw(rx, s, cw_pattern())
        elif cat == "BBM":
            r = bytearray(rx)
            r[pf.page_data] = 0x00                    # bad-block marker byte (not ECC covered)
            rx = flip_cw(bytes(r), 0, rnd.sample(valid, 1))
        elif cat == "BURST":
            for s in range(pf.sectors):
                ln = rnd.randint(2, b.t)
                st = rnd.randint(0, b.ns - ln)
                rx = flip_cw(rx, s, list(range(st, st + ln)))
        out.append((cat, pay, um, raw, rx))
    return pf, out


def write_page_vectors(name, npages, seed):
    pf, recs = page_records(name, npages, seed)
    d = os.path.join(ROOT, "build", "vec", name)
    os.makedirs(d, exist_ok=True)
    # scrub threshold = reset value of the RTL register: (3T+3)/4 of the T parameter (T = 4 is the
    # placeholder BCH parameter of the LDPC page configuration)
    t_rtl = 4 if CFG.PAGE_CONFIGS[name].get("codec") == "LDPC" else pf.bch.t
    thr = (3 * t_rtl + 3) // 4
    counts = {}
    with open(os.path.join(d, "page_bytes.memh"), "w") as fb, open(os.path.join(d, "page_st.memh"), "w") as fs:
        for (cat, pay, um, raw, rx) in recs:
            pay_o, um_o, sts, pg = pf.decode_page(rx)
            counts[cat] = counts.get(cat, 0) + 1
            blob = pay + b"".join(um) + raw + rx + pay_o + b"".join(um_o)
            fb.write("\n".join(f"{x:02x}" for x in blob) + "\n")
            for st in sts:
                fs.write(f"{(int(st['crc_ok']) << 16) | (st['nerr'] << 8) | st['code']:08x}\n")
            fs.write(f"{(pg['n_erased'] << 24) | (pg['n_integrity'] << 16) | (pg['n_uncorr'] << 8) | pg['n_corrected']:08x}\n")
            scrub = int(thr != 0 and pg['max_bitflips'] >= thr)
            fs.write(f"{(scrub << 26) | (int(pg['ok']) << 25) | (int(pg['all_erased']) << 24) | (pg['total_bitflips'] << 8) | pg['max_bitflips']:08x}\n")
            fs.write(f"{pg['bbm']:08x}\n")
    with open(os.path.join(d, "tb_page_cfg.svh"), "w") as fh:
        fh.write(f"// generated by scripts/gen_vectors.py --page for {name}\n")
        fh.write(f"`define TBP_CFG_NAME \"{name}\"\n`define TBP_P `SFECC_PAGE_{name}\n")
        fh.write(f"`define TBP_DATA {pf.page_data}\n`define TBP_SPARE {pf.page_spare}\n`define TBP_SECTORS {pf.sectors}\n")
        fh.write(f"`define TBP_UMETA {pf.umeta}\n`define TBP_NPAGE {len(recs)}\n`define TBP_T {pf.bch.t}\n")
    json.dump(dict(cfg=name, pages=len(recs), categories=counts, oob=pf.oob_budget()),
              open(os.path.join(d, "page_meta.json"), "w"), indent=1)
    print(f"{name}: {len(recs)} pages {counts}")


if __name__ == "__main__":
    main()
