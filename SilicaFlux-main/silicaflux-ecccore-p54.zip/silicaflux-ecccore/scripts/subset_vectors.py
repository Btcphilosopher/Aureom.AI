#!/usr/bin/env python3
"""subset_vectors.py CFG N -- first N core records of build/vec/CFG into build/vec/CFG_sN (for the slower
Icarus runs; same records, same expectations)."""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cfg, n = sys.argv[1], int(sys.argv[2])
src, dst = os.path.join(ROOT, "build", "vec", cfg), os.path.join(ROOT, "build", "vec", f"{cfg}_s{n}")
os.makedirs(dst, exist_ok=True)
txt = open(os.path.join(src, "tb_cfg.svh")).read()
msg = int(re.search(r"`define TB_MSG (\d+)", txt).group(1))
cw = int(re.search(r"`define TB_CW (\d+)", txt).group(1))
rb = 2 * msg + 2 * cw
with open(os.path.join(src, "core_bytes.memh")) as f, open(os.path.join(dst, "core_bytes.memh"), "w") as g:
    for i, line in enumerate(f):
        if i >= n * rb:
            break
        g.write(line)
with open(os.path.join(src, "core_st.memh")) as f, open(os.path.join(dst, "core_st.memh"), "w") as g:
    for i, line in enumerate(f):
        if i >= n:
            break
        g.write(line)
open(os.path.join(dst, "tb_cfg.svh"), "w").write(re.sub(r"`define TB_NREC \d+", f"`define TB_NREC {n}", txt))
print(dst)
