#!/usr/bin/env python3
"""
run_regress.py -- the complete ECCCore regression; writes reports/regression.md (+ .json).

  1  generated files current (gen_cfg --check), vendored files unmodified (check_vendor)
  2  reference validation (galois, Linux lib/bch.c, published table, 3 key-equation solvers)
  3  LDPC reference validation (rank, girth, pyldpc BP, measured behaviour)
  4  vectors (core, page, LDPC)
  5  Verilator: core BCH testbench, every configuration (+ NBANKS = 3, + heavy back-pressure seed)
  6  Verilator: page-level testbench of silicaflux_storage_ecc, every page configuration (+ LDPC codec)
  7  Verilator: LDPC proof-of-concept testbench (soft + hard decoders)
  8  Icarus Verilog 12: the same testbenches on reduced record counts (portability, second simulator)
  9  NAND digital twin campaigns (directed RTL, retention RTL, statistical Python)
 10  lint (Verilator -Wall, every top)
Synthesis (scripts/synth.py) and coverage (scripts/run_coverage.py) are separate targets.
    python3 scripts/run_regress.py [--quick] [--skip-twin] [--skip-iverilog] [--resume <previous stdout log>]
--resume re-uses the PASS rows of an interrupted run (same step names) and runs only the rest; the Icarus
jobs run in parallel (independent simulator processes).
"""
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, "build")
RTL = [l.strip() for l in open(os.path.join(ROOT, "rtl", "files.f")) if l.strip() and not l.startswith("//")]
ROWS = []
RESUMED = {}


def load_resume(path):
    """PASS rows printed by a previous run: '{result:5s} {step:4s} {sim:9s} {what:52s} {secs:7.1f}s {detail}'"""
    for line in open(path):
        if not line.startswith("PASS "):
            continue
        step, sim, rest = line[6:10].strip(), line[11:20].strip(), line[21:].rstrip("\n")
        m = re.match(r"^(.*?)\s+(\d+\.\d)s (.*)$", rest)
        if m:
            RESUMED[m.group(1).strip()] = dict(step=step, sim=sim, what=m.group(1).strip(), result="PASS",
                                               seconds=float(m.group(2)), detail=m.group(3) + " (resumed)")


def resumed(what):
    if what in RESUMED:
        ROWS.append(RESUMED[what])
        print(f"PASS  (resumed) {what}")
        return True
    return False


def sh(cmd, log, cwd=ROOT, timeout=7200):
    t0 = time.time()
    with open(log, "w") as fh:
        r = subprocess.run(cmd, cwd=cwd, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout)
    return r.returncode, open(log).read(), time.time() - t0


def row(step, sim, what, result, secs, detail=""):
    ROWS.append(dict(step=step, sim=sim, what=what, result=result, seconds=round(secs, 1), detail=detail))
    print(f"{result:5s} {step:4s} {sim:9s} {what:52s} {secs:7.1f}s {detail}")


def tb_line(txt):
    m = re.findall(r"TB RESULT .*", txt)
    return m[-1] if m else "no TB RESULT line"


def vl_build(top, inc, files, mdir, gen=()):
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O2", "--top-module", top,
           "-Irtl", "-Irtl/generated", "-Itb", "-I" + inc, "--Mdir", mdir, "-o", "sim"] + list(gen) + files + \
          [os.path.join("tb", top + ".sv")]
    rc, txt, s = sh(cmd, mdir + ".build.log")
    return rc == 0, s


def iv_build(top, inc, files, out, defs=()):
    cmd = ["iverilog", "-g2012", "-o", out, "-Irtl", "-Irtl/generated", "-Itb", "-I" + inc] + list(defs) + files + \
          [os.path.join("tb", top + ".sv")]
    rc, txt, s = sh(cmd, out + ".build.log")
    return rc == 0, s


def run_sim(cmd, log, step, simname, what):
    rc, txt, s = sh(cmd, log)
    line = tb_line(txt)
    ok = "-> PASS" in line
    m = re.search(r"checks=(\d+) errors=(\d+)", line)
    row(step, simname, what, "PASS" if ok else "FAIL", s, line.replace("TB RESULT ", ""))
    return ok


def main():
    quick = "--quick" in sys.argv
    os.makedirs(B, exist_ok=True)
    if "--resume" in sys.argv:
        load_resume(sys.argv[sys.argv.index("--resume") + 1])
    py = sys.executable
    # 1 -----------------------------------------------------------------
    rc, txt, s = sh([py, "scripts/gen_cfg.py", "--check"], os.path.join(B, "gen_cfg_check.log"))
    row("1", "python", "generated SV/doc files up to date", "PASS" if rc == 0 else "FAIL", s, txt.strip()[-80:])
    rc, txt, s = sh([py, "scripts/check_vendor.py"], os.path.join(B, "check_vendor.log"))
    row("1", "python", "vendored third-party files unmodified", "PASS" if rc == 0 else "FAIL", s, txt.strip().splitlines()[-1] if txt.strip() else "")
    # 2/3 ---------------------------------------------------------------
    if not resumed("reference model validation"):
      rc, txt, s = sh([py, "scripts/validate_ref.py"] + (["--quick"] if quick else []), os.path.join(B, "validate_ref.log"))
      row("2", "python", "reference model validation", "PASS" if rc == 0 else "FAIL", s, txt.strip().splitlines()[-1])
    if not resumed("LDPC reference validation"):
      rc, txt, s = sh([py, "scripts/validate_ldpc.py"] + (["--quick"] if quick else []), os.path.join(B, "validate_ldpc.log"))
      row("3", "python", "LDPC reference validation", "PASS" if rc == 0 else "FAIL", s, txt.strip().splitlines()[-1])
    # 4 -----------------------------------------------------------------
    for cmd, what in (([py, "scripts/gen_vectors.py"], "core vectors"), ([py, "scripts/gen_vectors.py", "--page"], "page vectors"),
                      ([py, "scripts/gen_ldpc_vectors.py", "700"], "LDPC vectors")):
        if resumed(what):
            continue
        rc, txt, s = sh(cmd, os.path.join(B, what.replace(" ", "_") + ".log"))
        row("4", "python", what, "PASS" if rc == 0 else "FAIL", s, " | ".join(l[:90] for l in txt.strip().splitlines()[-4:]))
    bch = [f for f in RTL if "bch_" in f]
    ldpc = [f for f in RTL if "ldpc_" in f]
    # 5 -----------------------------------------------------------------
    core = [("B255T4", 2, 7, 30), ("B255T4", 3, 8, 30), ("B255T4", 2, 9, 70), ("N512T4", 2, 11, 30),
            ("N512T8", 2, 12, 30), ("N8KT40", 2, 13, 30)]
    for cfg, nb, seed, bp in core:
        if resumed(f"core BCH {cfg} NBANKS={nb} bp={bp}%"):
            continue
        mdir = os.path.join(B, f"rg_vl_core_{cfg}_nb{nb}")
        ok, s = vl_build("tb_sfecc_bch", f"build/vec/{cfg}", bch, mdir, [f"-GNBANKS_TB={nb}"])
        if not ok:
            row("5", "verilator", f"core {cfg} build", "FAIL", s)
            continue
        run_sim([os.path.join(mdir, "sim"), f"+VEC=build/vec/{cfg}", f"+OUT=build/tb_bch_{cfg}_nb{nb}" +
                 ("" if (bp == 30) else f"_bp{bp}") + ".json", f"+SEED={seed}", f"+BP_IN={bp}", f"+BP_OUT={bp}",
                 f"+BP_ST={bp}"], mdir + ".log", "5", "verilator", f"core BCH {cfg} NBANKS={nb} bp={bp}%")
    # 6 -----------------------------------------------------------------
    for cfg in ["N512T4", "N512T8", "N2KT8", "N8KT40", "L24"]:
        if resumed(f"page engine {cfg}" + (" (LDPC codec)" if cfg == "L24" else "")):
            continue
        mdir = os.path.join(B, f"rg_vl_page_{cfg}")
        ok, s = vl_build("tb_sfecc_page", f"build/vec/{cfg}", RTL, mdir)
        if not ok:
            row("6", "verilator", f"page {cfg} build", "FAIL", s)
            continue
        run_sim([os.path.join(mdir, "sim"), f"+VEC=build/vec/{cfg}", f"+OUT=build/tb_page_{cfg}.json"], mdir + ".log",
                "6", "verilator", f"page engine {cfg}" + (" (LDPC codec)" if cfg == "L24" else ""))
    # 7 -----------------------------------------------------------------
    mdir = os.path.join(B, "rg_vl_ldpc")
    ok = False
    if not resumed("LDPC PoC encoder + soft/hard decoders"):
        ok, s = vl_build("tb_sfecc_ldpc", "build/vec/LDPC", ldpc, mdir)
    if ok:
        run_sim([os.path.join(mdir, "sim"), "+VEC=build/vec/LDPC", "+OUT=build/tb_ldpc.json"], mdir + ".log", "7",
                "verilator", "LDPC PoC encoder + soft/hard decoders")
    # 8 -----------------------------------------------------------------
    if "--skip-iverilog" not in sys.argv:
        iv = [("tb_sfecc_bch", "B255T4", bch, []), ("tb_sfecc_bch", "N512T4", bch, []),
              ("tb_sfecc_bch", "N512T8", bch, []), ("tb_sfecc_bch", "N8KT40", bch, ["+MAXREC=120", "+NRST=3"]),
              ("tb_sfecc_page", "N512T4", RTL, []), ("tb_sfecc_page", "N2KT8", RTL, []),
              ("tb_sfecc_page", "L24", RTL, []), ("tb_sfecc_ldpc", "LDPC", ldpc, [])]
        from concurrent.futures import ThreadPoolExecutor

        def iv_job(item):
            top, cfg, files, plus = item
            what = f"{top} {cfg}" + (f" ({' '.join(plus)})" if plus else " (all vectors)")
            if what in RESUMED:
                return ("resumed", what)
            out = os.path.join(B, f"rg_iv_{top}_{cfg}.vvp")
            ok, s = iv_build(top, f"build/vec/{cfg}", files, out)
            if not ok:
                return ("row", ("8", "iverilog", f"{top} {cfg} build", "FAIL", s, open(out + ".build.log").read()[-200:]))
            rc, txt, s = sh(["vvp", "-n", out, f"+VEC=build/vec/{cfg}", f"+OUT=build/iv_{top}_{cfg}.json"] + plus,
                            out + ".log")
            line = tb_line(txt)
            return ("row", ("8", "iverilog", what, "PASS" if "-> PASS" in line else "FAIL", s,
                            line.replace("TB RESULT ", "")))

        with ThreadPoolExecutor(int(os.environ.get("SFECC_JOBS", "4"))) as ex:
            results = list(ex.map(iv_job, iv))
        for kind, val in results:                      # report in list order
            if kind == "resumed":
                resumed(val)
            else:
                row(*val)
    # 9 -----------------------------------------------------------------
    if "--skip-twin" not in sys.argv and not resumed("NAND digital twin: directed + retention (RTL), statistical (Python)"):
        rc, txt, s = sh([py, "scripts/nand_twin_campaign.py"] + (["--quick"] if quick else []),
                        os.path.join(B, "nand_twin_campaign.log"))
        rep = json.load(open(os.path.join(ROOT, "reports", "nand_twin.json")))
        ok = rc == 0
        det = []
        for d in rep.get("directed", []):
            ok &= "-> PASS" in d["sim"] and not d["rtl_vs_ref_mismatches"]
            det.append(f"{d['cfg']} directed: {d['outcomes']}")
        r = rep.get("retention", {})
        for st in r.get("steps", []):
            ok &= "-> PASS" in st["sim"] and not st["rtl_vs_ref_mismatches"]
        ok &= all(row_["undetected"] == 0 for v in rep.get("statistical", {}).values() for row_ in v["rows"])
        row("9", "verilator", "NAND digital twin: directed + retention (RTL), statistical (Python)",
            "PASS" if ok else "FAIL", s, "; ".join(det))
        subprocess.run([py, "scripts/make_report.py"], cwd=ROOT)
    # 10 ----------------------------------------------------------------
    rc, txt, s = sh([py, "scripts/lint.py"], os.path.join(B, "lint.log"))
    row("10", "verilator", "lint -Wall, 14 tops", "PASS" if rc == 0 else "FAIL", s, txt.strip().splitlines()[-1])
    # report --------------------------------------------------------------
    npass = sum(r["result"] == "PASS" for r in ROWS)
    json.dump(ROWS, open(os.path.join(ROOT, "reports", "regression.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "regression.md"), "w") as fh:
        fh.write("# Regression — `scripts/run_regress.py`" + (" (quick)" if quick else "") + "\n\n")
        fh.write(f"**{npass} / {len(ROWS)} steps PASS.**  Tools: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, "
                 f"Python {sys.version.split()[0]}.\n\n")
        if RESUMED:
            fh.write("Rows marked *(resumed)* are PASS rows re-used from the interrupted run given to `--resume` "
                     "(same step names, same sources).\n\n")
        fh.write("| Step | Simulator | What | Result | Time (s) | Detail |\n|---|---|---|---|---|---|\n")
        for r in ROWS:
            fh.write(f"| {r['step']} | {r['sim']} | {r['what']} | {r['result']} | {r['seconds']} | {r['detail']} |\n")
    print(f"\n{npass}/{len(ROWS)} PASS")
    sys.exit(0 if npass == len(ROWS) else 1)


if __name__ == "__main__":
    main()
