#!/usr/bin/env python3
"""
validate_ref.py -- independent validation of the ECCCore Python reference model.

The reference (ref/) is the golden model every RTL vector is compared with, so it is
itself checked against sources that share no code with it:

  1. GF(2^m): table multiplication == table-free shift-and-add multiplication
     (exhaustive for m <= 10, sampled otherwise); alpha has order exactly 2^m - 1
     (prime-factor test); a * a^-1 == 1 for every non-zero a.
  2. Generator polynomials of BCH(255, k), t = 1..8 == the published table
     (Lin & Costello, "Error Control Coding", App. C, octal, p(x) = 435 octal).
  3. galois (PyPI, independent Python implementation): generator polynomial, systematic
     parity and decoding (corrected message + error count / failure) for every config,
     including the unshortened BCH(255,223).
  4. Linux kernel lib/bch.c (Ivan Djelic, as vendored by bchlib 2.1.3, compiled from
     ext/linux_bch with gcc): parity bytes and error locations.  Linux uses
     Berlekamp-Massey + the BTZ root finder (no Chien search), i.e. an independent
     decoder implementation.
  5. Three key-equation solvers in the reference agree: classic BM with inversion,
     the simplified inversionless BM used by the hardware, and Sugiyama's Euclid; the
     2t-step inversionless BM has zero discrepancy at every odd step (binary property).
  6. Exhaustive decoding of every 1- and 2-bit error pattern of BCH(255,223); erased
     codewords with flips; CRC-16 catalogue check value.

Writes reports/reference_validation.{json,md}.  Exit status != 0 on any mismatch.
"""
import ctypes
import json
import os
import random
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "ref"))

from sfecc_gf import GF2m, DEFAULT_PRIM                        # noqa: E402
from sfecc_bch import BCHCode, BCHFormat, ST_UNCORR            # noqa: E402
from sfecc_page import crc16_ccitt_false                        # noqa: E402
import sfecc_configs as CFG                                     # noqa: E402

RESULTS = []
FAIL = []


def check(name, ok, detail=""):
    RESULTS.append(dict(check=name, ok=bool(ok), detail=detail))
    print(("PASS " if ok else "FAIL ") + name + (f"  ({detail})" if detail else ""))
    if not ok:
        FAIL.append(name)


# ---------------------------------------------------------------------- 1. GF
def check_gf():
    rnd = random.Random(1)
    for m in range(3, 17):
        gf = GF2m(m)
        ok = gf.is_primitive_order()
        if m <= 10:
            pairs = ((a, b) for a in range(gf.size) for b in range(gf.size))
            cnt = gf.size * gf.size
        else:
            pairs = [(rnd.randrange(gf.size), rnd.randrange(gf.size)) for _ in range(200000)]
            cnt = len(pairs)
        bad = sum(1 for a, b in pairs if gf.mul(a, b) != gf.mul_poly(a, b))
        inv_bad = sum(1 for a in range(1, gf.size) if gf.mul(a, gf.inv(a)) != 1)
        check(f"GF(2^{m}) p=0x{gf.prim:x}: primitive, table==poly multiply ({cnt} pairs), inverses",
              ok and bad == 0 and inv_bad == 0, f"mult mismatches {bad}, inverse mismatches {inv_bad}")


# ---------------------------------------------------------------------- 2. published table
PUBLISHED_255 = {1: "435", 2: "267543", 3: "156720665", 4: "75626641375", 5: "23157564726421",
                 6: "16176560567636227", 7: "7633031270420722341", 8: "2663470176115333714567"}
PUBLISHED_K = {1: 247, 2: 239, 3: 231, 4: 223, 5: 215, 6: 207, 7: 199, 8: 191}


def check_table():
    for t, octal in PUBLISHED_255.items():
        c = BCHCode(8, t, 0x11D)
        check(f"BCH(255,{PUBLISHED_K[t]}) t={t} generator == Lin&Costello octal {octal}",
              oct(c.g)[2:] == octal and c.k_full == PUBLISHED_K[t], f"got {oct(c.g)[2:]} k={c.k_full}")


# ---------------------------------------------------------------------- 3. galois
def bits_of(v, n):
    return [(v >> (n - 1 - i)) & 1 for i in range(n)]


def check_galois(cfg_names, ntrials):
    try:
        import galois
        import numpy as np
    except ImportError:
        check("galois available", False, "pip install galois")
        return
    rnd = random.Random(2)
    for name in cfg_names:
        f = CFG.core(name)
        c = f.code
        t0 = time.time()
        ext = galois.GF(2 ** c.m, irreducible_poly=c.prim)
        gb = galois.BCH(c.n, c.k_full, extension_field=ext)
        g_gal = int("".join(str(int(x)) for x in gb.generator_poly.coeffs), 2)
        check(f"{name}: generator polynomial == galois", g_gal == c.g, f"deg {c.r}")
        par_bad = dec_bad = fail_agree = 0
        n_dec = 0
        for trial in range(ntrials):
            u = rnd.getrandbits(c.k)
            msg = np.array(bits_of(u, c.k), dtype=np.uint8)
            cw = gb.encode(galois.GF2(msg))
            p_gal = int("".join(str(int(x)) for x in cw[c.k:]), 2)
            if p_gal != c.encode_poly(u):
                par_bad += 1
            # error weights 0 .. t+3
            w = trial % (c.t + 4)
            pos = rnd.sample(range(c.ns), w)
            rx = cw.copy()
            rpoly = c.codeword_poly(u)
            for d in pos:
                rx[c.ns - 1 - d] ^= 1
                rpoly ^= 1 << d
            dm, ne = gb.decode(rx, errors=True)
            ref = c.decode_poly(rpoly)
            n_dec += 1
            gal_ok = int(ne) >= 0
            if gal_ok != ref["ok"]:
                fail_agree += 1
            elif gal_ok:
                m_gal = int("".join(str(int(x)) for x in dm), 2)
                if m_gal != (ref["corrected"] >> c.r) or int(ne) != ref["L"]:
                    dec_bad += 1
        check(f"{name}: {ntrials} parities == galois", par_bad == 0, f"mismatches {par_bad}")
        check(f"{name}: {n_dec} decodes (0..t+3 errors) == galois (status, message, error count)",
              dec_bad == 0 and fail_agree == 0,
              f"data/count mismatches {dec_bad}, success/failure disagreements {fail_agree}, {time.time()-t0:.1f}s")


# ---------------------------------------------------------------------- 4. Linux lib/bch.c
class LinuxBCH:
    def __init__(self, so):
        self.lib = ctypes.CDLL(so)
        self.lib.bch_init.restype = ctypes.c_void_p
        self.lib.bch_init.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint, ctypes.c_bool]
        self.lib.bch_encode.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint, ctypes.c_char_p]
        self.lib.bch_decode.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint, ctypes.c_char_p,
                                        ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint)]
        self.lib.bch_free.argtypes = [ctypes.c_void_p]


def build_linux():
    src = os.path.join(ROOT, "ext", "linux_bch")
    out = os.path.join(ROOT, "build", "libbch_linux.so")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    subprocess.check_call(["gcc", "-O2", "-shared", "-fPIC", "-o", out, os.path.join(src, "bch.c")])
    return out


def check_linux(cases, ntrials):
    try:
        so = build_linux()
    except Exception as e:      # pragma: no cover
        check("Linux lib/bch.c builds", False, str(e))
        return
    L = LinuxBCH(so)
    rnd = random.Random(3)
    for (m, t, nbytes, label) in cases:
        h = L.lib.bch_init(m, t, DEFAULT_PRIM[m], False)
        f = BCHFormat(m, t, nbytes, 0, None, erased_mask=False, name=label)
        c = f.code
        ecc_bytes = f.par_bytes
        par_bad = loc_bad = st_bad = 0
        errloc = (ctypes.c_uint * (t + 1))()
        for trial in range(ntrials):
            data = bytes(rnd.getrandbits(8) for _ in range(nbytes))
            ecc = ctypes.create_string_buffer(ecc_bytes)
            L.lib.bch_encode(h, data, nbytes, ecc)
            ours = f.encode(data)[nbytes:]
            # Linux leaves the pad bits 0, our encoder writes them 1
            padmask = (0xFF << f.tpad) & 0xFF
            ours_cmp = ours[:-1] + bytes([ours[-1] & padmask]) if f.tpad else ours
            if ecc.raw != ours_cmp:
                par_bad += 1
            w = trial % (t + 4)
            pos = rnd.sample(f.valid_stream_bits(), w)
            cw = f.flip(data + ours, pos)
            rdata, recc = cw[:nbytes], bytearray(cw[nbytes:])
            if f.tpad:
                recc[-1] &= padmask
            nerr = L.lib.bch_decode(h, rdata, nbytes, bytes(recc), None, None, errloc)
            _, st = f.decode(cw)
            lin_ok = nerr >= 0
            if lin_ok != st["ok"]:
                st_bad += 1
                continue
            if lin_ok:
                # Linux errloc: data bit (byte*8 + LSB-numbered bit) or 8*len + parity bit index
                lin = set()
                for i in range(nerr):
                    e = errloc[i]
                    lin.add((e >> 3) * 8 + (7 - (e & 7)))
                ours_pos = set(f.degree_stream_bit(d) for d in st["positions"])
                if lin != ours_pos or nerr != st["L"]:
                    loc_bad += 1
        L.lib.bch_free(h)
        check(f"{label} (m={m}, t={t}, {nbytes} B): {ntrials} parities == Linux lib/bch.c", par_bad == 0,
              f"mismatches {par_bad}")
        check(f"{label}: {ntrials} decodes (0..t+3 errors) == Linux lib/bch.c (status, error locations)",
              loc_bad == 0 and st_bad == 0, f"location mismatches {loc_bad}, status disagreements {st_bad}")


# ---------------------------------------------------------------------- 5. key-equation solvers
def norm(gf, lam):
    lam = list(lam)
    while len(lam) > 1 and lam[-1] == 0:
        lam.pop()
    if lam[0] == 0:
        return tuple(lam)
    c = gf.inv(lam[0])
    return tuple(gf.mul(c, v) for v in lam)


def check_solvers(name, ntrials):
    f = CFG.core(name)
    c = f.code
    gf = c.gf
    rnd = random.Random(4)
    bad_ab = bad_ac = bad_odd = bad_len = 0
    for trial in range(ntrials):
        if trial % 3 == 2:
            rpoly = rnd.getrandbits(c.ns)                     # arbitrary received word
        else:
            w = trial % (2 * c.t + 3)
            rpoly = c.codeword_poly(rnd.getrandbits(c.k))
            for d in rnd.sample(range(c.ns), w):
                rpoly ^= 1 << d
        S = c.syndromes(rpoly)
        la, La = c.bm_massey(S)
        lb, Lb = c.ibm_simplified(S)
        lf, Lf, odd = c.ibm_full(S)
        if norm(gf, la) != norm(gf, lb) or La != Lb:
            bad_ab += 1
        if norm(gf, lf) != norm(gf, lb) or Lf != Lb:
            bad_len += 1
        if any(odd):
            bad_odd += 1
        if Lb <= c.t:
            lc = c.euclid(S)
            if norm(gf, lc) != norm(gf, lb):
                bad_ac += 1
    check(f"{name}: BM(inversion) == simplified iBM (hardware) on {ntrials} syndrome sets", bad_ab == 0,
          f"mismatches {bad_ab}")
    check(f"{name}: 2t-step iBM == t-step simplified iBM; all odd-step discrepancies zero", bad_len == 0 and bad_odd == 0,
          f"locator mismatches {bad_len}, non-zero odd discrepancies {bad_odd}")
    check(f"{name}: Sugiyama Euclid == iBM whenever L <= t", bad_ac == 0, f"mismatches {bad_ac}")


# ---------------------------------------------------------------------- 6. exhaustive + misc
def check_exhaustive():
    f = CFG.core("B255T4")
    rnd = random.Random(5)
    msg = bytes(rnd.getrandbits(8) for _ in range(f.msg_bytes))
    msg = bytes([msg[0] & 0x7F]) + msg[1:]
    cw = f.encode(msg)
    bits = f.valid_stream_bits()
    bad = 0
    for s in bits:
        out, st = f.decode(f.flip(cw, [s]))
        bad += (out != msg or st["nerr"] != 1)
    check("B255T4: all 255 single-bit errors corrected", bad == 0, f"failures {bad}")
    bad = n = 0
    for i in range(len(bits)):
        for j in range(i + 1, len(bits)):
            out, st = f.decode(f.flip(cw, [bits[i], bits[j]]))
            n += 1
            bad += (out != msg or st["nerr"] != 2)
    check(f"B255T4: all {n} double-bit errors corrected", bad == 0, f"failures {bad}")
    # erased codewords
    for name in ["B255T4", "N512T4", "N512T8", "N8KT40"]:
        f = CFG.core(name)
        ones = b"\xff" * f.msg_bytes
        enc = f.encode(ones)
        er = b"\xff" * f.cw_bytes
        ok = enc == er
        _, st = f.decode(er)
        ok &= st["code"] == 2 and st["nerr"] == 0
        # t random flips on an erased codeword are corrected and still reported ERASED
        bad = 0
        for trial in range(50):
            pos = rnd.sample(f.valid_stream_bits(), 1 + trial % f.t)
            out, st = f.decode(f.flip(er, pos))
            if st["code"] != 2 or st["nerr"] != len(pos):
                bad += 1
        check(f"{name}: encode(all-ones) == all-ones stored codeword (ECC mask); erased+<=t flips -> ERASED",
              ok and bad == 0, f"bad flip cases {bad}")
    check("CRC-16/CCITT-FALSE('123456789') == 0x29B1 (catalogue check value)",
          crc16_ccitt_false(b"123456789") == 0x29B1)
    for name in CFG.PAGE_CONFIGS:
        p = CFG.page(name)
        crc = crc16_ccitt_false(b"\xff" * (p.sector + p.umeta))
        check(f"{name}: CRC of an all-0xFF sector ({crc:#06x}) != 0xFFFF, so a written all-FF sector is "
              f"distinguishable from an erased one", crc != 0xFFFF)


def main():
    quick = "--quick" in sys.argv
    t0 = time.time()
    check_gf()
    check_table()
    check_solvers("B255T4", 3000 if not quick else 300)
    check_solvers("N512T8", 600 if not quick else 60)
    check_solvers("N8KT40", 120 if not quick else 12)
    check_exhaustive()
    check_linux([(8, 4, 27, "BCH(255,223) shortened to 216 data bits"),
                 (13, 4, 520, "N512T4 geometry"), (13, 8, 514, "N512T8 geometry"),
                 (14, 40, 1046, "N8KT40 geometry"), (14, 24, 1024, "m14 t24 1 KiB")],
                1000 if not quick else 100)
    check_galois(["B255T4", "N512T4", "N512T8"], 400 if not quick else 40)
    check_galois(["N8KT40"], 40 if not quick else 8)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    summary = dict(total=len(RESULTS), passed=sum(r["ok"] for r in RESULTS), failed=FAIL,
                   seconds=round(time.time() - t0, 1), results=RESULTS)
    with open(os.path.join(ROOT, "reports", "reference_validation.json"), "w") as fh:
        json.dump(summary, fh, indent=1)
    with open(os.path.join(ROOT, "reports", "reference_validation.md"), "w") as fh:
        fh.write("# Reference-model validation (`scripts/validate_ref.py`)\n\n")
        fh.write(f"**{summary['passed']} / {summary['total']} checks pass** ({summary['seconds']} s).\n\n")
        fh.write("| Result | Check | Detail |\n|---|---|---|\n")
        for r in RESULTS:
            fh.write(f"| {'PASS' if r['ok'] else '**FAIL**'} | {r['check']} | {r['detail']} |\n")
    print(f"\n{summary['passed']}/{summary['total']} checks pass in {summary['seconds']} s")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
