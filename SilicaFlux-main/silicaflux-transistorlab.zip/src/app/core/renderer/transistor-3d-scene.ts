/**
 * SILICAFLUX TRANSISTORLAB
 * Interactive 3D Transistor Digital Twin Visualization Engine
 * Powered by Three.js
 * Project 41 — Device Physics and Transistor Simulation
 */

import * as THREE from 'three';
import { DeviceGeometry, FieldSolution2D, TransistorType } from '../models/device.types';

export type DisplayMode3D =
  | 'physical'
  | 'potential'
  | 'electric_field'
  | 'electron_density'
  | 'hole_density'
  | 'net_charge'
  | 'current_density';

export interface VisualizerSettings {
  displayMode: DisplayMode3D;
  explodeFactor: number; // 0 (closed) to 1 (fully exploded)
  clipX: number; // 0 to 1
  clipY: number; // 0 to 1
  clipZ: number; // 0 to 1
  opacity: number; // 0.1 to 1.0
  showGate: boolean;
  showDielectric: boolean;
  showDiffusions: boolean;
  showContacts: boolean;
  showSubstrate: boolean;
  showFieldVectors: boolean;
  showRuler: boolean;
  wireframe: boolean;
}

export class Transistor3DScene {
  private container: HTMLElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;

  // Groups and objects
  private rootGroup: THREE.Group;
  private substrateMesh: THREE.Mesh | null = null;
  private sourceMesh: THREE.Mesh | null = null;
  private drainMesh: THREE.Mesh | null = null;
  private channelMesh: THREE.Mesh | null = null;
  private dielectricMesh: THREE.Mesh | null = null;
  private gateMesh: THREE.Mesh | null = null;
  private contactSourceMesh: THREE.Mesh | null = null;
  private contactDrainMesh: THREE.Mesh | null = null;
  private contactGateMesh: THREE.Mesh | null = null;
  private stiLeftMesh: THREE.Mesh | null = null;
  private stiRightMesh: THREE.Mesh | null = null;
  private vectorGroup: THREE.Group;
  private rulerGroup: THREE.Group;
  private fieldCanvasTexture: THREE.CanvasTexture | null = null;

  // Materials
  private materialsList: THREE.Material[] = [];

  // Interaction controls
  private isDragging = false;
  private isRightDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraTarget = new THREE.Vector3(0, 0, 0);
  private spherical = { radius: 180, theta: Math.PI / 4, phi: Math.PI / 3 };

  private currentGeometry: DeviceGeometry | null = null;
  private currentSolution: FieldSolution2D | null = null;
  private currentType: TransistorType = 'nmos';
  private settings: VisualizerSettings = {
    displayMode: 'physical',
    explodeFactor: 0,
    clipX: 1,
    clipY: 1,
    clipZ: 1,
    opacity: 0.95,
    showGate: true,
    showDielectric: true,
    showDiffusions: true,
    showContacts: true,
    showSubstrate: true,
    showFieldVectors: true,
    showRuler: true,
    wireframe: false,
  };

  constructor(container: HTMLElement) {
    this.container = container;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x070F1E);

    // Subtle atmospheric fog
    this.scene.fog = new THREE.FogExp2(0x070F1E, 0.002);

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;
    this.camera = new THREE.PerspectiveCamera(40, width / height, 1, 2000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.localClippingEnabled = true;

    container.appendChild(this.renderer.domElement);

    this.rootGroup = new THREE.Group();
    this.scene.add(this.rootGroup);

    this.vectorGroup = new THREE.Group();
    this.rootGroup.add(this.vectorGroup);

    this.rulerGroup = new THREE.Group();
    this.rootGroup.add(this.rulerGroup);

    this.setupLighting();
    this.setupGridAndAxes();
    this.setupEventListeners();
    this.startRenderLoop();
  }

  private setupLighting(): void {
    // Ambient fill light (Midnight Navy hue)
    const ambientLight = new THREE.AmbientLight(0x233758, 1.2);
    this.scene.add(ambientLight);

    // Main directional sunlight (Metallic Gold / Warm)
    const sunLight = new THREE.DirectionalLight(0xFFF3D6, 2.0);
    sunLight.position.set(100, 150, 100);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    this.scene.add(sunLight);

    // Cyan accent rim light from opposite angle
    const rimLight = new THREE.DirectionalLight(0x1CCCE5, 1.5);
    rimLight.position.set(-100, 80, -100);
    this.scene.add(rimLight);

    // Subtle violet underlight
    const underLight = new THREE.DirectionalLight(0x814DD1, 0.8);
    underLight.position.set(0, -100, 0);
    this.scene.add(underLight);
  }

  private setupGridAndAxes(): void {
    // Custom tech grid
    const gridHelper = new THREE.GridHelper(300, 30, 0x1E3354, 0x0E1F36);
    gridHelper.position.y = -40;
    this.scene.add(gridHelper);
  }

  private setupEventListeners(): void {
    const el = this.renderer.domElement;

    el.addEventListener('mousedown', (e) => {
      e.preventDefault();
      if (e.button === 0) this.isDragging = true;
      if (e.button === 2) this.isRightDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging && !this.isRightDragging) return;

      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      if (this.isDragging) {
        // Orbit rotation
        this.spherical.theta -= deltaX * 0.008;
        this.spherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.spherical.phi - deltaY * 0.008));
        this.updateCameraPosition();
      } else if (this.isRightDragging) {
        // Pan
        const panSpeed = 0.2;
        const forward = new THREE.Vector3().subVectors(this.cameraTarget, this.camera.position).normalize();
        const right = new THREE.Vector3().crossVectors(forward, this.camera.up).normalize();
        this.cameraTarget.addScaledVector(right, -deltaX * panSpeed);
        this.cameraTarget.y += deltaY * panSpeed;
        this.updateCameraPosition();
      }

      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
      this.isRightDragging = false;
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.spherical.radius = Math.max(40, Math.min(500, this.spherical.radius + e.deltaY * 0.15));
      this.updateCameraPosition();
    }, { passive: false });

    el.addEventListener('contextmenu', (e) => e.preventDefault());

    // Window resize
    window.addEventListener('resize', this.onResize.bind(this));
  }

  private updateCameraPosition(): void {
    const sinPhiRadius = this.spherical.radius * Math.sin(this.spherical.phi);
    this.camera.position.x = this.cameraTarget.x + sinPhiRadius * Math.sin(this.spherical.theta);
    this.camera.position.y = this.cameraTarget.y + this.spherical.radius * Math.cos(this.spherical.phi);
    this.camera.position.z = this.cameraTarget.z + sinPhiRadius * Math.cos(this.spherical.theta);
    this.camera.lookAt(this.cameraTarget);
  }

  public onResize(): void {
    if (!this.container || !this.renderer) return;
    const width = this.container.clientWidth || 600;
    const height = this.container.clientHeight || 450;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  /**
   * Builds the 3D Transistor Structure from physical geometry parameters
   */
  public updateDevice(
    geometry: DeviceGeometry,
    solution: FieldSolution2D | null,
    type: TransistorType = 'nmos',
    settings?: Partial<VisualizerSettings>
  ): void {
    this.currentGeometry = geometry;
    this.currentSolution = solution;
    this.currentType = type;
    if (settings) {
      this.settings = { ...this.settings, ...settings };
    }

    // Clear previous geometries and meshes
    this.clearMeshes();

    // Scale factors: convert nanometers to 3D scene units (e.g. 1 nm = 1 scene unit)
    const scale = 1e9; // 1 nm = 1 unit
    const Lg = geometry.gateLength * scale;
    const Lsd = geometry.sourceDrainLength * scale;
    const Tox = Math.max(1.8, geometry.oxideThickness * scale * 2.5); // Slightly enhanced for clear visual presence
    const Xj = geometry.junctionDepth * scale;
    const Hsub = geometry.substrateDepth * scale;
    const W = Math.min(60, Math.max(25, geometry.gateWidth * 1e6 * 20)); // Extrusion depth Z
    const Ltotal = 2 * Lsd + Lg;

    const explode = this.settings.explodeFactor;
    const isNMOS = type === 'nmos';

    // Clipping plane setup for cutaways
    const clipPlanes: THREE.Plane[] = [];
    if (this.settings.clipX < 1.0) {
      const cutX = (this.settings.clipX - 0.5) * Ltotal;
      clipPlanes.push(new THREE.Plane(new THREE.Vector3(-1, 0, 0), cutX));
    }
    if (this.settings.clipZ < 1.0) {
      const cutZ = (this.settings.clipZ - 0.5) * W;
      clipPlanes.push(new THREE.Plane(new THREE.Vector3(0, 0, -1), cutZ));
    }

    // 1. Silicon P-Substrate Bulk (bottom)
    const subGeo = new THREE.BoxGeometry(Ltotal, Hsub, W);
    const subMat = new THREE.MeshStandardMaterial({
      color: 0x1A2B44,
      metalness: 0.6,
      roughness: 0.35,
      transparent: this.settings.opacity < 1.0,
      opacity: this.settings.opacity,
      wireframe: this.settings.wireframe,
      clippingPlanes: clipPlanes,
    });
    this.materialsList.push(subMat);
    this.substrateMesh = new THREE.Mesh(subGeo, subMat);
    this.substrateMesh.position.set(0, -Hsub / 2, 0);
    this.substrateMesh.castShadow = true;
    this.substrateMesh.receiveShadow = true;
    this.substrateMesh.visible = this.settings.showSubstrate;
    this.rootGroup.add(this.substrateMesh);

    // 2. Source Diffusion Well
    const sourceGeo = new THREE.BoxGeometry(Lsd, Xj, W * 0.98);
    const sourceMat = new THREE.MeshStandardMaterial({
      color: isNMOS ? 0x1CCCE5 : 0xD7AD59, // Cyan for N+ NMOS, Gold for P+ PMOS
      emissive: isNMOS ? 0x073542 : 0x3D2C0C,
      metalness: 0.7,
      roughness: 0.3,
      transparent: true,
      opacity: this.settings.opacity * 0.92,
      wireframe: this.settings.wireframe,
      clippingPlanes: clipPlanes,
    });
    this.materialsList.push(sourceMat);
    this.sourceMesh = new THREE.Mesh(sourceGeo, sourceMat);
    this.sourceMesh.position.set(-Ltotal / 2 + Lsd / 2, -Xj / 2, 0);
    this.sourceMesh.visible = this.settings.showDiffusions;
    this.rootGroup.add(this.sourceMesh);

    // 3. Drain Diffusion Well
    const drainGeo = new THREE.BoxGeometry(Lsd, Xj, W * 0.98);
    const drainMat = sourceMat.clone();
    this.materialsList.push(drainMat);
    this.drainMesh = new THREE.Mesh(drainGeo, drainMat);
    this.drainMesh.position.set(Ltotal / 2 - Lsd / 2, -Xj / 2, 0);
    this.drainMesh.visible = this.settings.showDiffusions;
    this.rootGroup.add(this.drainMesh);

    // 4. Channel Inversion Region under Gate
    const channelThick = Math.min(6, Xj * 0.25);
    const channelGeo = new THREE.BoxGeometry(Lg, channelThick, W * 0.98);
    // Channel lights up when Gate Voltage exceeds Vth
    const isChannelOn = solution ? Math.abs(solution.biases.vgs) > 0.45 : false;
    const channelMat = new THREE.MeshStandardMaterial({
      color: isChannelOn ? 0x00FFCC : 0x2A3E5C,
      emissive: isChannelOn ? 0x008866 : 0x000000,
      metalness: 0.5,
      roughness: 0.2,
      transparent: true,
      opacity: this.settings.opacity,
      wireframe: this.settings.wireframe,
      clippingPlanes: clipPlanes,
    });
    this.materialsList.push(channelMat);
    this.channelMesh = new THREE.Mesh(channelGeo, channelMat);
    this.channelMesh.position.set(0, -channelThick / 2, 0);
    this.rootGroup.add(this.channelMesh);

    // 5. Gate Dielectric Oxide Layer (lifts with explode factor)
    const dielGeo = new THREE.BoxGeometry(Lg + 2 * geometry.spacerWidth * scale, Tox, W * 0.98);
    const dielMat = new THREE.MeshPhysicalMaterial({
      color: 0x5EEAD4, // Light seafoam cyan dielectric
      roughness: 0.1,
      metalness: 0.1,
      transmission: 0.85,
      ior: 1.5,
      transparent: true,
      opacity: 0.8,
      wireframe: this.settings.wireframe,
      clippingPlanes: clipPlanes,
    });
    this.materialsList.push(dielMat);
    this.dielectricMesh = new THREE.Mesh(dielGeo, dielMat);
    const yDielectric = Tox / 2 + explode * 15;
    this.dielectricMesh.position.set(0, yDielectric, 0);
    this.dielectricMesh.visible = this.settings.showDielectric;
    this.rootGroup.add(this.dielectricMesh);

    // 6. Metal/Poly Gate Electrode (lifts with explode factor)
    const gateHeight = 28;
    const gateGeo = new THREE.BoxGeometry(Lg, gateHeight, W * 0.98);
    const gateMat = new THREE.MeshStandardMaterial({
      color: 0xD7AD59, // Metallic Gold
      metalness: 0.95,
      roughness: 0.2,
      transparent: this.settings.opacity < 1.0,
      opacity: this.settings.opacity,
      wireframe: this.settings.wireframe,
      clippingPlanes: clipPlanes,
    });
    this.materialsList.push(gateMat);
    this.gateMesh = new THREE.Mesh(gateGeo, gateMat);
    const yGate = Tox + gateHeight / 2 + explode * 35;
    this.gateMesh.position.set(0, yGate, 0);
    this.gateMesh.castShadow = true;
    this.gateMesh.visible = this.settings.showGate;
    this.rootGroup.add(this.gateMesh);

    // 7. Contacts (Source, Drain, Gate) - Metallic Silver plugs
    const contactThick = 18;
    const contactW = Lsd * 0.65;
    const contactMat = new THREE.MeshStandardMaterial({
      color: 0x9BAFC3, // Silicon silver
      metalness: 0.9,
      roughness: 0.15,
      clippingPlanes: clipPlanes,
    });
    this.materialsList.push(contactMat);

    // Source contact
    const cSourceGeo = new THREE.BoxGeometry(contactW, contactThick, W * 0.7);
    this.contactSourceMesh = new THREE.Mesh(cSourceGeo, contactMat);
    this.contactSourceMesh.position.set(-Ltotal / 2 + Lsd / 2, contactThick / 2 + explode * 20, 0);
    this.contactSourceMesh.visible = this.settings.showContacts;
    this.rootGroup.add(this.contactSourceMesh);

    // Drain contact
    const cDrainGeo = new THREE.BoxGeometry(contactW, contactThick, W * 0.7);
    this.contactDrainMesh = new THREE.Mesh(cDrainGeo, contactMat);
    this.contactDrainMesh.position.set(Ltotal / 2 - Lsd / 2, contactThick / 2 + explode * 20, 0);
    this.contactDrainMesh.visible = this.settings.showContacts;
    this.rootGroup.add(this.contactDrainMesh);

    // Gate top contact
    const cGateGeo = new THREE.BoxGeometry(Lg * 0.75, 12, W * 0.7);
    this.contactGateMesh = new THREE.Mesh(cGateGeo, contactMat);
    this.contactGateMesh.position.set(0, Tox + gateHeight + 6 + explode * 45, 0);
    this.contactGateMesh.visible = this.settings.showContacts && this.settings.showGate;
    this.rootGroup.add(this.contactGateMesh);

    // 8. Field Overlays and Vector Streamlines
    this.updateFieldOverlays(solution);

    // 9. Measurement Rulers
    this.updateRulers(geometry);
  }

  /**
   * Applies the solved numerical field onto the cutaway cross-section and renders 3D vectors
   */
  private updateFieldOverlays(solution: FieldSolution2D | null): void {
    // Clear vectors
    while (this.vectorGroup.children.length > 0) {
      const obj = this.vectorGroup.children[0];
      this.vectorGroup.remove(obj);
    }

    if (!solution || this.settings.displayMode === 'physical' || !this.currentGeometry) {
      return;
    }

    // Generate texture from 2D mesh numerical field
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imgData = ctx.createImageData(canvas.width, canvas.height);
    const data = imgData.data;

    const { mesh, potential, electricFieldMag, electronDensity, netChargeDensity, currentDensityX } = solution;
    const nx = mesh.nx;
    const ny = mesh.ny;

    for (let py = 0; py < canvas.height; py++) {
      const v = py / (canvas.height - 1); // 0 at top, 1 at bottom
      const j = Math.floor(v * (ny - 1));

      for (let px = 0; px < canvas.width; px++) {
        const u = px / (canvas.width - 1); // 0 at source, 1 at drain
        const i = Math.floor(u * (nx - 1));

        const pixelIdx = (py * canvas.width + px) * 4;
        let normVal = 0;

        switch (this.settings.displayMode) {
          case 'potential': {
            // Potential from -0.8V to 1.2V
            const val = potential[i] ? potential[i][j] : 0;
            normVal = (val + 0.8) / 2.0;
            break;
          }
          case 'electric_field': {
            // Electric field log scale
            const val = electricFieldMag[i] ? electricFieldMag[i][j] : 0;
            normVal = Math.log10(Math.max(1, val)) / 8.5; // up to 10^8.5 V/m
            break;
          }
          case 'electron_density': {
            // Log10 carrier density (1e10 to 1e20 cm^-3 => 1e16 to 1e26 m^-3)
            const val = electronDensity[i] ? electronDensity[i][j] : 0;
            normVal = (Math.log10(Math.max(1e10, val)) - 10) / 16.0;
            break;
          }
          case 'net_charge': {
            const val = netChargeDensity[i] ? netChargeDensity[i][j] : 0;
            normVal = (val / 1e8 + 1) * 0.5;
            break;
          }
          case 'current_density': {
            const val = currentDensityX[i] ? Math.abs(currentDensityX[i][j]) : 0;
            normVal = Math.log10(Math.max(1, val)) / 11.0;
            break;
          }
        }

        normVal = Math.max(0, Math.min(1, normVal));

        // Scientific color mapping (Turbo / Jet colormap approximation)
        const rgb = this.getColormapColor(normVal);
        data[pixelIdx] = rgb[0];
        data[pixelIdx + 1] = rgb[1];
        data[pixelIdx + 2] = rgb[2];
        data[pixelIdx + 3] = 230; // High opacity
      }
    }

    ctx.putImageData(imgData, 0, 0);

    if (this.fieldCanvasTexture) {
      this.fieldCanvasTexture.dispose();
    }
    this.fieldCanvasTexture = new THREE.CanvasTexture(canvas);

    // Apply texture to substrate front face cutaway
    if (this.substrateMesh) {
      const fieldMat = new THREE.MeshBasicMaterial({
        map: this.fieldCanvasTexture,
        transparent: true,
        opacity: 0.9,
      });
      // Replace or overlay plane on front face
      const Ltotal = (2 * this.currentGeometry.sourceDrainLength + this.currentGeometry.gateLength) * 1e9;
      const Hsub = this.currentGeometry.substrateDepth * 1e9;
      const W = Math.min(60, Math.max(25, this.currentGeometry.gateWidth * 1e6 * 20));

      const fieldPlaneGeo = new THREE.PlaneGeometry(Ltotal, Hsub);
      const fieldPlaneMesh = new THREE.Mesh(fieldPlaneGeo, fieldMat);
      fieldPlaneMesh.position.set(0, -Hsub / 2, W / 2 + 0.1);
      this.vectorGroup.add(fieldPlaneMesh);
    }

    // 3D Vector field arrows if enabled
    if (this.settings.showFieldVectors && this.settings.displayMode === 'electric_field') {
      const arrowStepX = Math.floor(nx / 10);
      const arrowStepY = Math.floor(ny / 6);
      const scale = 1e9;
      const Lsd = this.currentGeometry.sourceDrainLength * scale;
      const Lg = this.currentGeometry.gateLength * scale;
      const Ltotal = 2 * Lsd + Lg;

      for (let i = arrowStepX; i < nx; i += arrowStepX) {
        const xPos = mesh.x[i] * scale - Ltotal / 2;
        for (let j = arrowStepY; j < ny; j += arrowStepY) {
          const yPos = -mesh.y[j] * scale;
          const Ex = solution.electricFieldX[i][j];
          const Ey = solution.electricFieldY[i][j];
          const Emag = Math.sqrt(Ex * Ex + Ey * Ey);
          if (Emag > 1e6) {
            const dir = new THREE.Vector3(Ex / Emag, -Ey / Emag, 0);
            const len = Math.min(12, Math.max(3, Math.log10(Emag) * 1.5));
            const color = dir.x > 0 ? 0x1CCCE5 : 0xD7AD59;
            const arrow = new THREE.ArrowHelper(dir, new THREE.Vector3(xPos, yPos, 0), len, color, 2.5, 1.5);
            this.vectorGroup.add(arrow);
          }
        }
      }
    }
  }

  /**
   * Generates engineering dimension rulers and callout probes
   */
  private updateRulers(geometry: DeviceGeometry): void {
    while (this.rulerGroup.children.length > 0) {
      const obj = this.rulerGroup.children[0];
      this.rulerGroup.remove(obj);
    }

    if (!this.settings.showRuler) return;

    const scale = 1e9;
    const Lg = geometry.gateLength * scale;
    const W = Math.min(60, Math.max(25, geometry.gateWidth * 1e6 * 20));

    // Gate length ruler line
    const rulerMat = new THREE.LineBasicMaterial({ color: 0xD7AD59, linewidth: 2 });
    const pts = [
      new THREE.Vector3(-Lg / 2, 34, W / 2 + 3),
      new THREE.Vector3(Lg / 2, 34, W / 2 + 3),
    ];
    const rulerGeo = new THREE.BufferGeometry().setFromPoints(pts);
    const line = new THREE.Line(rulerGeo, rulerMat);
    this.rulerGroup.add(line);

    // End ticks
    const tickMat = new THREE.LineBasicMaterial({ color: 0xD7AD59 });
    const tickL = new THREE.Line(new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-Lg / 2, 31, W / 2 + 3),
      new THREE.Vector3(-Lg / 2, 37, W / 2 + 3),
    ]), tickMat);
    const tickR = new THREE.Line(new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(Lg / 2, 31, W / 2 + 3),
      new THREE.Vector3(Lg / 2, 37, W / 2 + 3),
    ]), tickMat);
    this.rulerGroup.add(tickL);
    this.rulerGroup.add(tickR);
  }

  private getColormapColor(t: number): [number, number, number] {
    // High-contrast scientific colormap: Navy -> Blue -> Cyan -> Green -> Gold -> Red
    let r = 0, g = 0, b = 0;
    if (t < 0.2) {
      const u = t / 0.2;
      r = Math.floor(11 + u * 10);
      g = Math.floor(24 + u * 60);
      b = Math.floor(60 + u * 150);
    } else if (t < 0.4) {
      const u = (t - 0.2) / 0.2;
      r = Math.floor(21 + u * 8);
      g = Math.floor(84 + u * 120);
      b = Math.floor(210 + u * 19);
    } else if (t < 0.6) {
      const u = (t - 0.4) / 0.2;
      r = Math.floor(29 + u * 100);
      g = Math.floor(204 + u * 20);
      b = Math.floor(229 - u * 140);
    } else if (t < 0.8) {
      const u = (t - 0.6) / 0.2;
      r = Math.floor(129 + u * 86);
      g = Math.floor(224 - u * 51);
      b = Math.floor(89 - u * 60);
    } else {
      const u = (t - 0.8) / 0.2;
      r = Math.floor(215 + u * 40);
      g = Math.floor(173 - u * 120);
      b = Math.floor(29 - u * 15);
    }
    return [r, g, b];
  }

  public setExplode(factor: number): void {
    this.settings.explodeFactor = Math.max(0, Math.min(1, factor));
    if (this.currentGeometry) {
      this.updateDevice(this.currentGeometry, this.currentSolution, this.currentType);
    }
  }

  public setDisplayMode(mode: DisplayMode3D): void {
    this.settings.displayMode = mode;
    if (this.currentGeometry) {
      this.updateDevice(this.currentGeometry, this.currentSolution, this.currentType);
    }
  }

  public setClipping(clipX: number, clipZ: number): void {
    this.settings.clipX = clipX;
    this.settings.clipZ = clipZ;
    if (this.currentGeometry) {
      this.updateDevice(this.currentGeometry, this.currentSolution, this.currentType);
    }
  }

  public toggleLayer(layer: 'gate' | 'dielectric' | 'diffusions' | 'contacts' | 'substrate', visible: boolean): void {
    switch (layer) {
      case 'gate': this.settings.showGate = visible; break;
      case 'dielectric': this.settings.showDielectric = visible; break;
      case 'diffusions': this.settings.showDiffusions = visible; break;
      case 'contacts': this.settings.showContacts = visible; break;
      case 'substrate': this.settings.showSubstrate = visible; break;
    }
    if (this.currentGeometry) {
      this.updateDevice(this.currentGeometry, this.currentSolution, this.currentType);
    }
  }

  public resetCamera(): void {
    this.spherical = { radius: 180, theta: Math.PI / 4, phi: Math.PI / 3 };
    this.cameraTarget.set(0, 0, 0);
    this.updateCameraPosition();
  }

  private clearMeshes(): void {
    const toRemove: THREE.Object3D[] = [];
    this.rootGroup.children.forEach(child => {
      if (child !== this.vectorGroup && child !== this.rulerGroup) {
        toRemove.push(child);
      }
    });
    toRemove.forEach(child => this.rootGroup.remove(child));

    this.materialsList.forEach(m => m.dispose());
    this.materialsList = [];
  }

  private startRenderLoop(): void {
    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);

      // Subtle slow rotation idle animation when not dragging
      if (!this.isDragging && !this.isRightDragging) {
        // Very slow drift
        this.spherical.theta += 0.0012;
        this.updateCameraPosition();
      }

      this.renderer.render(this.scene, this.camera);
    };
    animate();
  }

  public destroy(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onResize);
    this.clearMeshes();
    if (this.fieldCanvasTexture) this.fieldCanvasTexture.dispose();
    this.renderer.dispose();
    if (this.container && this.renderer.domElement) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
