/**
 * SILICAFLUX TRANSISTORLAB
 * Core Semiconductor Device Types & Physics Schemas
 * Project 41 — Device Physics and Transistor Simulation
 * Aureom.AI | SilicaFlux Semiconductor Systems
 */

export type TransistorType = 'nmos' | 'pmos';
export type TransistorArchitecture = 'planar' | 'finfet' | 'nanosheet' | 'soi' | 'hkmg';
export type DopingProfileType = 'uniform' | 'piecewise' | 'gaussian';
export type DielectricMaterial = 'sio2' | 'hfo2' | 'al2o3' | 'custom';
export type GateMaterial = 'n_poly' | 'p_poly' | 'midgap_metal' | 'custom_metal';
export type PhysicsLevel = 'analytical' | 'spice' | 'tcad_2d';
export type VthExtractionMethod = 'linear_extrapolation' | 'transconductance_peak' | 'constant_current';

export interface DeviceGeometry {
  /** Gate physical length in meters (e.g. 45e-9 m = 45 nm) */
  gateLength: number;
  /** Effective channel width in meters (e.g. 1.0e-6 m = 1.0 µm) */
  gateWidth: number;
  /** Gate dielectric physical thickness in meters (e.g. 1.4e-9 m = 1.4 nm) */
  oxideThickness: number;
  /** Source/Drain junction depth in meters (e.g. 25e-9 m = 25 nm) */
  junctionDepth: number;
  /** Substrate domain simulation depth in meters (e.g. 80e-9 m = 80 nm) */
  substrateDepth: number;
  /** Source/Drain contact length in meters (e.g. 40e-9 m = 40 nm) */
  sourceDrainLength: number;
  /** Dielectric spacer width in meters (e.g. 10e-9 m = 10 nm) */
  spacerWidth: number;
}

export interface MaterialParameters {
  /** Relative permittivity of silicon */
  siliconPermittivity: number;
  /** Silicon bandgap at 300K in eV (1.12 eV) */
  siliconBandgap: number;
  /** Intrinsic carrier concentration at 300K in m^-3 (1.5e16 m^-3 = 1.5e10 cm^-3) */
  intrinsicCarrierConcentration: number;
  /** Low-field electron mobility in m^2/(V·s) (0.14 m^2/(V·s) = 1400 cm^2/(V·s)) */
  electronLowFieldMobility: number;
  /** Low-field hole mobility in m^2/(V·s) (0.045 m^2/(V·s) = 450 cm^2/(V·s)) */
  holeLowFieldMobility: number;
  /** Electron saturation velocity in m/s (1.0e5 m/s = 1.0e7 cm/s) */
  electronSaturationVelocity: number;
  /** Hole saturation velocity in m/s (0.8e5 m/s = 0.8e7 cm/s) */
  holeSaturationVelocity: number;
  /** Gate dielectric relative permittivity (3.9 for SiO2, 22 for HfO2) */
  dielectricPermittivity: number;
  /** Dielectric material key */
  dielectricType: DielectricMaterial;
  /** Gate electrode material key */
  gateMaterialType: GateMaterial;
  /** Gate electrode workfunction in eV (e.g. 4.1 eV for n+ poly, 5.1 eV for p+ poly, 4.6 eV midgap) */
  gateWorkfunction: number;
  /** Silicon electron affinity in eV (4.05 eV) */
  siliconAffinity: number;
  /** Silicon thermal conductivity in W/(m·K) (148 W/(m·K)) */
  thermalConductivity: number;
}

export interface DopingConfiguration {
  profileType: DopingProfileType;
  /** Substrate background doping concentration in m^-3 (e.g. 1e23 m^-3 = 1e17 cm^-3) */
  substrateDoping: number;
  /** Source region peak doping in m^-3 (e.g. 1e26 m^-3 = 1e20 cm^-3) */
  sourceDoping: number;
  /** Drain region peak doping in m^-3 (e.g. 1e26 m^-3 = 1e20 cm^-3) */
  drainDoping: number;
  /** Lateral straggle ratio (fraction of junction depth Xj, e.g. 0.7) */
  lateralStraggle: number;
}

export interface OperatingBiases {
  /** Gate-to-Source voltage in Volts */
  vgs: number;
  /** Drain-to-Source voltage in Volts */
  vds: number;
  /** Body/Substrate-to-Source voltage in Volts */
  vbs: number;
  /** Device temperature in Kelvin (default 300K) */
  temperature: number;
}

export interface SolverSettings {
  meshResolution: 'coarse' | 'standard' | 'fine' | 'ultra';
  maxIterations: number;
  convergenceTolerance: number;
  dampingFactor: number;
  physicsLevel: PhysicsLevel;
  enableVelocitySaturation: boolean;
  enableDopingMobilityDegradation: boolean;
  enableRecombination: boolean;
  enableSelfHeating: boolean;
}

export interface Mesh2D {
  nx: number;
  ny: number;
  totalElements: number;
  x: number[]; // x coordinates in meters
  y: number[]; // y coordinates in meters (0 is top oxide, y_ox is oxide-silicon interface)
  dxMin: number;
  dyMin: number;
  aspectRatioMax: number;
  aspectRatioAvg: number;
  /** Node region tag: 0: oxide, 1: channel, 2: source, 3: drain, 4: substrate */
  nodeRegions: number[][];
}

export interface FieldSolution2D {
  mesh: Mesh2D;
  /** Electrostatic potential in Volts */
  potential: number[][];
  /** Electric field X component in V/m */
  electricFieldX: number[][];
  /** Electric field Y component in V/m */
  electricFieldY: number[][];
  /** Electric field magnitude in V/m */
  electricFieldMag: number[][];
  /** Electron concentration in m^-3 */
  electronDensity: number[][];
  /** Hole concentration in m^-3 */
  holeDensity: number[][];
  /** Net space charge density in C/m^3 */
  netChargeDensity: number[][];
  /** Current density X component in A/m^2 */
  currentDensityX: number[][];
  /** Net doping concentration N_net = N_D - N_A in m^-3 */
  netDoping: number[][];
  
  /** Terminal currents in Amperes */
  drainCurrent: number;
  sourceCurrent: number;
  gateCurrent: number;
  bodyCurrent: number;

  /** Solver convergence diagnostics */
  iterations: number;
  residualNorm: number;
  converged: boolean;
  runtimeMs: number;
  errorDetails?: string;
  biases: OperatingBiases;
}

export interface ExtractedMetrics {
  /** Linear threshold voltage in Volts (measured at low Vds, e.g. 50 mV) */
  vthLinear: number;
  /** Saturation threshold voltage in Volts (measured at high Vds, e.g. 1.0 V) */
  vthSat: number;
  /** Method used for extraction */
  vthMethod: VthExtractionMethod;
  /** Subthreshold swing in mV/decade */
  subthresholdSwing: number;
  /** Drain-Induced Barrier Lowering in mV/V */
  dibl: number;
  /** On-state drain current in Amperes */
  ion: number;
  /** Off-state drain current in Amperes */
  ioff: number;
  /** Ion / Ioff ratio */
  ionIoffRatio: number;
  /** Peak transconductance in Siemens (A/V) */
  gmMax: number;
  /** Transconductance normalized to width (mS/µm) */
  gmNormalized: number;
  /** Output conductance in saturation in Siemens */
  gdsSat: number;
  /** Early voltage magnitude in Volts */
  earlyVoltage: number;
}

export interface SweepCurve {
  name: string;
  biasFixedName: string;
  biasFixedValue: number;
  sweepValues: number[];
  currentValues: number[];
  spiceCurrents?: number[];
  transconductanceValues?: number[];
  convergenceStatus: boolean[];
}

export interface SweepResult {
  sweepType: 'id_vgs' | 'id_vds' | 'temperature';
  xLabel: string;
  xUnit: string;
  curves: SweepCurve[];
  metrics: ExtractedMetrics;
}

export interface SpiceModelParameters {
  modelLevel: 1 | 2 | 3 | 'bsim_approx';
  vto: number;     // Zero-bias threshold voltage (V)
  kp: number;      // Transconductance parameter (A/V^2)
  gamma: number;   // Body-effect parameter (V^0.5)
  phi: number;     // Surface inversion potential (V)
  lambda: number;  // Channel-length modulation (V^-1)
  theta: number;   // Mobility degradation factor (V^-1)
  vsat: number;    // Saturation velocity (m/s)
  tox: number;     // Gate oxide thickness (m)
  temp: number;    // Reference temperature (K)
}

export interface OptimizationGoal {
  target: 'maximize_ion' | 'minimize_ioff' | 'maximize_ion_ioff' | 'maximize_gm' | 'minimize_dibl';
  weight: number;
  constraintIoffMax?: number;
  constraintVthMin?: number;
}

export interface OptimizationResult {
  optimalGeometry: Partial<DeviceGeometry>;
  optimalDoping: Partial<DopingConfiguration>;
  predictedIon: number;
  predictedIoff: number;
  predictedVth: number;
  paretoPoints: {
    ion: number;
    ioff: number;
    lg: number;
    tox: number;
    nsub: number;
  }[];
  iterations: number;
  convergenceStatus: 'converged' | 'bounded' | 'failed';
}

export interface ExperimentPreset {
  id: string;
  title: string;
  code: 'EXPERIMENT A' | 'EXPERIMENT B' | 'EXPERIMENT C' | 'EXPERIMENT D' | 'EXPERIMENT E';
  description: string;
  type: TransistorType;
  operatingBiases: OperatingBiases;
  geometry: DeviceGeometry;
  doping: DopingConfiguration;
  materials: MaterialParameters;
  solverSettings: SolverSettings;
  expectedBehavior: string;
}
