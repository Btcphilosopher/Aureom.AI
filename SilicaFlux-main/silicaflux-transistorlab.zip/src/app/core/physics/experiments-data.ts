/**
 * SILICAFLUX TRANSISTORLAB
 * Five Canonical CMOS Engineering Experiments
 * Project 41 — Device Physics and Transistor Simulation
 */

import { ExperimentPreset } from '../models/device.types';
import { DEFAULT_PLANAR_NMOS } from './constants';

export const CANONICAL_EXPERIMENTS: ExperimentPreset[] = [
  {
    id: 'exp-a-equilibrium',
    code: 'EXPERIMENT A',
    title: 'Planar NMOS Electrostatic Equilibrium',
    description: 'Zero external bias (VGS=0V, VDS=0V, VBS=0V) to determine thermal equilibrium built-in potentials, metallurgical junction depletion widths, and flatband electrostatics.',
    type: 'nmos',
    geometry: { ...DEFAULT_PLANAR_NMOS.geometry },
    materials: { ...DEFAULT_PLANAR_NMOS.materials },
    doping: { ...DEFAULT_PLANAR_NMOS.doping },
    operatingBiases: {
      vgs: 0.0,
      vds: 0.0,
      vbs: 0.0,
      temperature: 300.0,
    },
    solverSettings: { ...DEFAULT_PLANAR_NMOS.solver },
    expectedBehavior: 'Equilibrium Fermi level is flat across all regions. Built-in potential Vbi ~ 0.98V across source/drain pn junctions. Zero net current flows through terminals (Id < 1e-15 A).',
  },
  {
    id: 'exp-b-vgs-sweep',
    code: 'EXPERIMENT B',
    title: 'NMOS Gate-Voltage Transfer Sweep (Id-Vgs)',
    description: 'Gate bias swept from 0.0V to 1.2V at linear (VDS=0.05V) and saturation (VDS=1.0V) to extract threshold voltage Vth, subthreshold swing SS, DIBL, and Ion/Ioff ratio.',
    type: 'nmos',
    geometry: { ...DEFAULT_PLANAR_NMOS.geometry },
    materials: { ...DEFAULT_PLANAR_NMOS.materials },
    doping: { ...DEFAULT_PLANAR_NMOS.doping },
    operatingBiases: {
      vgs: 0.8,
      vds: 0.8,
      vbs: 0.0,
      temperature: 300.0,
    },
    solverSettings: { ...DEFAULT_PLANAR_NMOS.solver },
    expectedBehavior: 'Sharp exponential turn-on in subthreshold regime (SS ~ 68-75 mV/dec). Strong inversion begins near Vth ~ 0.38V. Drive current exceeds 650 µA/µm at Vgs=1.0V.',
  },
  {
    id: 'exp-c-vds-family',
    code: 'EXPERIMENT C',
    title: 'NMOS Output Characteristics Family (Id-Vds)',
    description: 'Drain bias swept from 0.0V to 1.2V for multiple gate overdrive voltages (VGS = 0.4V, 0.6V, 0.8V, 1.0V, 1.2V) demonstrating channel pinch-off and velocity saturation.',
    type: 'nmos',
    geometry: { ...DEFAULT_PLANAR_NMOS.geometry },
    materials: { ...DEFAULT_PLANAR_NMOS.materials },
    doping: { ...DEFAULT_PLANAR_NMOS.doping },
    operatingBiases: {
      vgs: 1.0,
      vds: 1.0,
      vbs: 0.0,
      temperature: 300.0,
    },
    solverSettings: { ...DEFAULT_PLANAR_NMOS.solver },
    expectedBehavior: 'Clear transition from linear resistive behavior at low Vds to current saturation above Vdsat. Channel length modulation causes slight slope in saturation (finite output resistance).',
  },
  {
    id: 'exp-d-temperature',
    code: 'EXPERIMENT D',
    title: 'NMOS Temperature-Sensitivity Analysis (250K - 400K)',
    description: 'Evaluates temperature dependence of phonon scattering mobility degradation, bandgap narrowing Eg(T), intrinsic carrier surge ni(T), and threshold voltage roll-off.',
    type: 'nmos',
    geometry: { ...DEFAULT_PLANAR_NMOS.geometry },
    materials: { ...DEFAULT_PLANAR_NMOS.materials },
    doping: { ...DEFAULT_PLANAR_NMOS.doping },
    operatingBiases: {
      vgs: 0.8,
      vds: 0.8,
      vbs: 0.0,
      temperature: 375.0, // Elevated operating temperature
    },
    solverSettings: { ...DEFAULT_PLANAR_NMOS.solver },
    expectedBehavior: 'Threshold voltage shifts negatively with temperature (~ -1.2 mV/K). On-state current degrades due to increased acoustic phonon scattering. Off-state leakage increases by ~ 2 orders of magnitude.',
  },
  {
    id: 'exp-e-spice-benchmark',
    code: 'EXPERIMENT E',
    title: 'TCAD vs SPICE Compact Model Benchmark',
    description: 'Side-by-side numerical comparison between 2D finite-difference TCAD drift-diffusion simulation and calibrated SPICE Level 3 / BSIM compact model with delta error residuals.',
    type: 'nmos',
    geometry: { ...DEFAULT_PLANAR_NMOS.geometry },
    materials: { ...DEFAULT_PLANAR_NMOS.materials },
    doping: { ...DEFAULT_PLANAR_NMOS.doping },
    operatingBiases: {
      vgs: 0.9,
      vds: 0.9,
      vbs: 0.0,
      temperature: 300.0,
    },
    solverSettings: { ...DEFAULT_PLANAR_NMOS.solver },
    expectedBehavior: 'Strong correlation in linear and saturation regimes (R^2 > 0.98, RMSE < 5%). Slight divergence in transition knee due to 2D continuous space-charge accumulation in TCAD vs piecewise compact equations.',
  },
];
