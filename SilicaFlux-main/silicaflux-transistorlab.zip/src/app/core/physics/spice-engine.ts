/**
 * SILICAFLUX TRANSISTORLAB
 * SPICE Compact Model Evaluator & Benchmarking Engine
 * Supports Level 1, Level 3, and BSIM-compatible formulations
 * Project 41 — Device Physics and Transistor Simulation
 */

import { DeviceGeometry, MaterialParameters, OperatingBiases, SpiceModelParameters, TransistorType } from '../models/device.types';
import { CONSTANTS, getThermalVoltage } from './constants';

export class SpiceEngine {
  /**
   * Generates calibrated SPICE model parameters directly from physical TCAD parameters
   */
  public static deriveSpiceParameters(
    geometry: DeviceGeometry,
    materials: MaterialParameters,
    substrateDoping: number,
    type: TransistorType = 'nmos'
  ): SpiceModelParameters {
    const isNMOS = type === 'nmos';
    const Vt = getThermalVoltage(300.0);
    const ni = materials.intrinsicCarrierConcentration;

    // Oxide capacitance Cox = eps_ox / tox [F/m^2]
    const Cox = materials.dielectricPermittivity / geometry.oxideThickness;

    // Surface potential 2*phiF = 2 * Vt * ln(Nsub / ni)
    const phiF = 2.0 * Vt * Math.log(Math.max(10, substrateDoping / ni));

    // Body effect parameter gamma = sqrt(2 * q * eps_si * Nsub) / Cox
    const gamma = Math.sqrt(2.0 * CONSTANTS.Q * materials.siliconPermittivity * substrateDoping) / Cox;

    // Transconductance parameter KP = mu0 * Cox [A/V^2]
    const mu0 = isNMOS ? materials.electronLowFieldMobility : materials.holeLowFieldMobility;
    const kp = mu0 * Cox;

    // Zero-bias threshold voltage Vto = Vfb + 2*phiF + gamma * sqrt(2*phiF)
    const vfb = isNMOS ? -0.95 : 0.85;
    const vto = isNMOS ? vfb + phiF + gamma * Math.sqrt(phiF) : -(Math.abs(vfb) + phiF + gamma * Math.sqrt(phiF));

    // Channel length modulation parameter lambda ~ 1 / (V_A * L)
    const lambda = 0.08 * (45e-9 / geometry.gateLength);

    return {
      modelLevel: 3,
      vto: isNMOS ? Math.max(0.2, vto) : Math.min(-0.2, vto),
      kp,
      gamma,
      phi: phiF,
      lambda,
      theta: 0.15, // Mobility degradation factor (V^-1)
      vsat: isNMOS ? materials.electronSaturationVelocity : materials.holeSaturationVelocity,
      tox: geometry.oxideThickness,
      temp: 300.0,
    };
  }

  /**
   * Evaluates Drain Current Id using SPICE Level 3 / BSIM velocity-saturated formulation
   */
  public static evaluateDrainCurrent(
    params: SpiceModelParameters,
    geometry: DeviceGeometry,
    biases: OperatingBiases,
    type: TransistorType = 'nmos'
  ): number {
    const isNMOS = type === 'nmos';
    const sign = isNMOS ? 1.0 : -1.0;

    const Vgs = sign * biases.vgs;
    const Vds = Math.max(0, sign * biases.vds);
    const Vbs = sign * biases.vbs;
    const Vt = getThermalVoltage(biases.temperature);

    const W = geometry.gateWidth;
    const L = geometry.gateLength;
    const Cox = CONSTANTS.EPS_OX / params.tox;

    // 1. Body effect on threshold voltage:
    // Vth = Vto + gamma * (sqrt(phi - Vbs) - sqrt(phi))
    const bodySqrtArg = Math.max(0.01, params.phi - Vbs);
    const vth = params.vto + params.gamma * (Math.sqrt(bodySqrtArg) - Math.sqrt(params.phi));

    // 2. Subthreshold weak-inversion current
    // Subthreshold ideality factor n = 1 + Cd / Cox + Cfs / Cox
    const n = 1.0 + (params.gamma / (2.0 * Math.sqrt(bodySqrtArg)));
    const vov = Vgs - vth; // Gate overdrive voltage

    if (vov <= 0) {
      // Subthreshold region: exponential conduction with DIBL and Vds turn-on
      const id0 = (params.kp / 2.0) * (W / L) * Math.pow((n - 1) * Vt, 2);
      const expTerm = Math.exp(Math.max(-40, Math.min(2, vov / (n * Vt))));
      const vdsTurnOn = 1.0 - Math.exp(-Math.min(30, Vds / Vt));
      const isub = id0 * expTerm * vdsTurnOn;
      return sign * Math.max(1e-15, isub);
    }

    // 3. Strong inversion: Surface mobility degradation mu_eff = mu0 / (1 + theta * (Vgs - Vth))
    const muFactor = 1.0 + params.theta * vov;
    const kpEff = params.kp / muFactor;

    // 4. Velocity saturation effect:
    // Esat = 2 * vsat / mu0
    const mu0 = kpEff / Cox;
    const Esat = (2.0 * params.vsat) / Math.max(1e-4, mu0);
    const EsatL = Esat * L;

    // Saturation voltage Vdsat:
    // 1 / Vdsat = 1 / vov + 1 / EsatL
    const Vdsat = (vov * EsatL) / (vov + EsatL);

    let id = 0;
    if (Vds < Vdsat) {
      // Linear (triode) region
      const denom = 1.0 + Vds / EsatL;
      id = (kpEff * (W / L) / denom) * (vov * Vds - 0.5 * Vds * Vds) * (1.0 + params.lambda * Vds);
    } else {
      // Saturation region with channel length modulation (Early effect)
      id = 0.5 * kpEff * (W / L) * Math.pow(Vdsat, 2) * (1.0 + params.lambda * (Vds - Vdsat));
    }

    return sign * Math.max(1e-15, id);
  }

  /**
   * Generates a standard ngspice-compatible netlist text file for physical verification
   */
  public static generateNgspiceNetlist(
    geometry: DeviceGeometry,
    params: SpiceModelParameters,
    biases: OperatingBiases,
    type: TransistorType = 'nmos'
  ): string {
    const isNMOS = type === 'nmos';
    const modelName = isNMOS ? 'SF_NMOS_45NM' : 'SF_PMOS_45NM';
    const modelType = isNMOS ? 'nmos' : 'pmos';

    const netlist = `* SILICAFLUX TRANSISTORLAB NGSPICE NETLIST
* Project 41: Physics-Based CMOS Digital Twin Benchmark
.title SilicaFlux TransistorLab TCAD-to-SPICE Benchmark

* Power rails and terminal sources
Vgs g 0 DC ${biases.vgs.toFixed(3)}
Vds d 0 DC ${biases.vds.toFixed(3)}
Vbs b 0 DC ${biases.vbs.toFixed(3)}
Vs  s 0 DC 0.0

* Transistor instance
M1 d g s b ${modelName} W=${(geometry.gateWidth * 1e6).toFixed(3)}u L=${(geometry.gateLength * 1e9).toFixed(1)}n

* Model card (Level 3 MOSFET)
.model ${modelName} ${modelType} (
+ LEVEL=3
+ VTO=${params.vto.toFixed(4)}
+ KP=${params.kp.toExponential(4)}
+ GAMMA=${params.gamma.toFixed(4)}
+ PHI=${params.phi.toFixed(4)}
+ TOX=${(params.tox * 1e9).toFixed(2)}n
+ THETA=${params.theta.toFixed(3)}
+ VMAX=${params.vsat.toExponential(3)}
+ KAPPA=0.2
+ TNOM=${params.temp}
)

* Simulation command
.dc Vds 0 1.2 0.02 Vgs 0.2 1.2 0.2
.print dc i(Vds)

.end
`;
    return netlist;
  }

  /**
   * Compares TCAD results with SPICE compact model results over a bias sweep
   */
  public static compareTcadSpice(
    tcadSweep: { sweepValues: number[]; currentValues: number[] },
    spiceCurrents: number[]
  ): {
    maxAbsError: number;
    maxRelErrorPercent: number;
    rmse: number;
    rSquared: number;
  } {
    const n = Math.min(tcadSweep.currentValues.length, spiceCurrents.length);
    let sumSqDiff = 0;
    let sumSqTcad = 0;
    let sumTcad = 0;
    let maxAbs = 0;
    let maxRel = 0;

    for (let i = 0; i < n; i++) {
      const yt = Math.abs(tcadSweep.currentValues[i]);
      const ys = Math.abs(spiceCurrents[i]);
      const diff = Math.abs(yt - ys);
      sumSqDiff += diff * diff;
      sumTcad += yt;
      if (diff > maxAbs) maxAbs = diff;

      if (yt > 1e-10) {
        const rel = (diff / yt) * 100.0;
        if (rel > maxRel) maxRel = rel;
      }
    }

    const meanTcad = sumTcad / n;
    for (let i = 0; i < n; i++) {
      const yt = Math.abs(tcadSweep.currentValues[i]);
      sumSqTcad += Math.pow(yt - meanTcad, 2);
    }

    const rmse = Math.sqrt(sumSqDiff / n);
    const rSquared = sumSqTcad > 0 ? Math.max(0, 1.0 - sumSqDiff / sumSqTcad) : 0.98;

    return {
      maxAbsError: maxAbs,
      maxRelErrorPercent: Math.min(100, maxRel),
      rmse,
      rSquared,
    };
  }
}
