/**
 * SILICAFLUX TRANSISTORLAB
 * Fundamental Physical Constants & Silicon Semiconductor Parameters
 * Project 41 — Device Physics and Transistor Simulation
 */

import { DeviceGeometry, DopingConfiguration, MaterialParameters, OperatingBiases, SolverSettings } from '../models/device.types';

export const CONSTANTS = {
  /** Elementary electronic charge [C] */
  Q: 1.602176634e-19,
  /** Boltzmann constant [J/K] */
  KB: 1.380649e-23,
  /** Boltzmann constant in eV/K */
  KB_EV: 8.617333262e-5,
  /** Vacuum permittivity [F/m] */
  EPS0: 8.8541878128e-12,
  /** Silicon relative permittivity */
  EPS_SI_REL: 11.7,
  /** Silicon absolute permittivity [F/m] */
  EPS_SI: 11.7 * 8.8541878128e-12,
  /** Silicon dioxide relative permittivity */
  EPS_OX_REL: 3.9,
  /** Silicon dioxide absolute permittivity [F/m] */
  EPS_OX: 3.9 * 8.8541878128e-12,
  /** Hafnium dioxide relative permittivity */
  EPS_HFO2_REL: 22.0,
  /** Hafnium dioxide absolute permittivity [F/m] */
  EPS_HFO2: 22.0 * 8.8541878128e-12,
  /** Reference standard room temperature [K] */
  T_REF: 300.0,
  /** Silicon electron affinity [eV] */
  CHI_SI: 4.05,
  /** Silicon nominal bandgap at 300K [eV] */
  EG_300K: 1.12,
  /** Electron saturation velocity in silicon [m/s] */
  VSAT_N: 1.07e5,
  /** Hole saturation velocity in silicon [m/s] */
  VSAT_P: 0.83e5,
};

/**
 * Calculates silicon bandgap in eV as a function of temperature using Varshni's empirical formula:
 * Eg(T) = Eg(0) - (alpha * T^2) / (T + beta)
 */
export function getBandgapSilicon(temperatureK: number): number {
  const eg0 = 1.166; // eV at 0K
  const alpha = 4.73e-4; // eV/K
  const beta = 636.0; // K
  return Math.max(0.5, eg0 - (alpha * temperatureK * temperatureK) / (temperatureK + beta));
}

/**
 * Calculates intrinsic carrier concentration ni in m^-3 as a function of temperature:
 * ni(T) = Nc0 * Nv0 * (T/300)^1.5 * exp(-Eg(T) / (2 * kB * T))
 */
export function getIntrinsicCarrierConcentration(temperatureK: number): number {
  const ni300 = 1.5e16; // 1.5e10 cm^-3 in m^-3 at 300K
  const egT = getBandgapSilicon(temperatureK);
  const vt = (CONSTANTS.KB * temperatureK) / CONSTANTS.Q;
  const vt300 = (CONSTANTS.KB * 300.0) / CONSTANTS.Q;
  
  const factorT = Math.pow(temperatureK / 300.0, 1.5);
  const expDiff = Math.exp(-(egT / (2 * vt) - CONSTANTS.EG_300K / (2 * vt300)));
  return ni300 * factorT * expDiff;
}

/**
 * Thermal voltage Vt = kB * T / q in Volts
 */
export function getThermalVoltage(temperatureK: number): number {
  return (CONSTANTS.KB * temperatureK) / CONSTANTS.Q;
}

/**
 * Default Planar 45nm NMOS High-Performance Device Configuration
 */
export const DEFAULT_PLANAR_NMOS: {
  geometry: DeviceGeometry;
  materials: MaterialParameters;
  doping: DopingConfiguration;
  biases: OperatingBiases;
  solver: SolverSettings;
} = {
  geometry: {
    gateLength: 45e-9,      // 45 nm
    gateWidth: 1.0e-6,      // 1.0 µm
    oxideThickness: 1.4e-9, // 1.4 nm SiO2 equivalent
    junctionDepth: 25e-9,   // 25 nm
    substrateDepth: 80e-9,  // 80 nm
    sourceDrainLength: 45e-9,// 45 nm
    spacerWidth: 10e-9,     // 10 nm
  },
  materials: {
    siliconPermittivity: CONSTANTS.EPS_SI,
    siliconBandgap: CONSTANTS.EG_300K,
    intrinsicCarrierConcentration: 1.5e16, // m^-3
    electronLowFieldMobility: 0.085, // m^2/(V·s) = 850 cm^2/(V·s) accounting for high channel doping
    holeLowFieldMobility: 0.035,    // m^2/(V·s) = 350 cm^2/(V·s)
    electronSaturationVelocity: CONSTANTS.VSAT_N,
    holeSaturationVelocity: CONSTANTS.VSAT_P,
    dielectricPermittivity: CONSTANTS.EPS_OX,
    dielectricType: 'sio2',
    gateMaterialType: 'n_poly',
    gateWorkfunction: 4.15, // eV (n+ polysilicon / n-MOS metal)
    siliconAffinity: CONSTANTS.CHI_SI,
    thermalConductivity: 148.0, // W/(m·K)
  },
  doping: {
    profileType: 'gaussian',
    substrateDoping: 2.0e23, // 2e17 cm^-3 acceptor P-well
    sourceDoping: 1.0e26,    // 1e20 cm^-3 donor N+ diffusion
    drainDoping: 1.0e26,     // 1e20 cm^-3 donor N+ diffusion
    lateralStraggle: 0.65,
  },
  biases: {
    vgs: 0.8,
    vds: 0.8,
    vbs: 0.0,
    temperature: 300.0,
  },
  solver: {
    meshResolution: 'standard',
    maxIterations: 60,
    convergenceTolerance: 1e-6,
    dampingFactor: 0.65,
    physicsLevel: 'tcad_2d',
    enableVelocitySaturation: true,
    enableDopingMobilityDegradation: true,
    enableRecombination: true,
    enableSelfHeating: false,
  },
};

/**
 * Default Planar 45nm PMOS Device Configuration
 */
export const DEFAULT_PLANAR_PMOS: {
  geometry: DeviceGeometry;
  materials: MaterialParameters;
  doping: DopingConfiguration;
  biases: OperatingBiases;
  solver: SolverSettings;
} = {
  geometry: {
    gateLength: 45e-9,
    gateWidth: 1.0e-6,
    oxideThickness: 1.4e-9,
    junctionDepth: 25e-9,
    substrateDepth: 80e-9,
    sourceDrainLength: 45e-9,
    spacerWidth: 10e-9,
  },
  materials: {
    siliconPermittivity: CONSTANTS.EPS_SI,
    siliconBandgap: CONSTANTS.EG_300K,
    intrinsicCarrierConcentration: 1.5e16,
    electronLowFieldMobility: 0.085,
    holeLowFieldMobility: 0.035,
    electronSaturationVelocity: CONSTANTS.VSAT_N,
    holeSaturationVelocity: CONSTANTS.VSAT_P,
    dielectricPermittivity: CONSTANTS.EPS_OX,
    dielectricType: 'sio2',
    gateMaterialType: 'p_poly',
    gateWorkfunction: 5.15, // eV (p+ polysilicon / p-MOS metal)
    siliconAffinity: CONSTANTS.CHI_SI,
    thermalConductivity: 148.0,
  },
  doping: {
    profileType: 'gaussian',
    substrateDoping: 2.0e23, // 2e17 cm^-3 donor N-well
    sourceDoping: 1.0e26,    // 1e20 cm^-3 acceptor P+ diffusion
    drainDoping: 1.0e26,     // 1e20 cm^-3 acceptor P+ diffusion
    lateralStraggle: 0.65,
  },
  biases: {
    vgs: -0.8,
    vds: -0.8,
    vbs: 0.0,
    temperature: 300.0,
  },
  solver: {
    meshResolution: 'standard',
    maxIterations: 60,
    convergenceTolerance: 1e-6,
    dampingFactor: 0.65,
    physicsLevel: 'tcad_2d',
    enableVelocitySaturation: true,
    enableDopingMobilityDegradation: true,
    enableRecombination: true,
    enableSelfHeating: false,
  },
};
