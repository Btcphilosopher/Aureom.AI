/**
 * SILICAFLUX TRANSISTORLAB
 * 2D Non-Uniform Semiconductor Mesh Generator
 * Project 41 — Device Physics and Transistor Simulation
 */

import { DeviceGeometry, Mesh2D } from '../models/device.types';

export class MeshGenerator {
  /**
   * Generates a non-uniform tensor mesh optimized for 2D MOSFET device physics.
   * Fine mesh at the Si-SiO2 interface, channel edges, and metallurgical pn-junctions.
   */
  public static generateMesh(
    geometry: DeviceGeometry,
    resolution: 'coarse' | 'standard' | 'fine' | 'ultra' = 'standard'
  ): Mesh2D {
    const { gateLength, oxideThickness, junctionDepth, substrateDepth, sourceDrainLength } = geometry;
    const totalX = 2 * sourceDrainLength + gateLength;
    const totalY = oxideThickness + substrateDepth;

    // Density multipliers based on resolution setting
    let numXSource: number;
    let numXChannel: number;
    let numXDrain: number;
    let numYOxide: number;
    let numYChannel: number;
    let numYSubstrate: number;

    switch (resolution) {
      case 'coarse':
        numXSource = 12;
        numXChannel = 20;
        numXDrain = 12;
        numYOxide = 5;
        numYChannel = 14;
        numYSubstrate = 16;
        break;
      case 'fine':
        numXSource = 22;
        numXChannel = 40;
        numXDrain = 22;
        numYOxide = 8;
        numYChannel = 28;
        numYSubstrate = 30;
        break;
      case 'ultra':
        numXSource = 30;
        numXChannel = 56;
        numXDrain = 30;
        numYOxide = 10;
        numYChannel = 38;
        numYSubstrate = 42;
        break;
      case 'standard':
      default:
        numXSource = 16;
        numXChannel = 28;
        numXDrain = 16;
        numYOxide = 6;
        numYChannel = 20;
        numYSubstrate = 22;
        break;
    }

    // 1. Generate non-uniform X coordinates
    // Source: geometric stretching towards junction edge at x = sourceDrainLength
    const xCoords: number[] = [];
    const xJuncSource = sourceDrainLength;
    const xJuncDrain = sourceDrainLength + gateLength;

    // Source domain [0, xJuncSource]
    for (let i = 0; i < numXSource; i++) {
      const u = i / numXSource;
      // Exponential cluster towards the channel edge
      const x = xJuncSource * (1 - Math.pow(1 - u, 1.8));
      xCoords.push(x);
    }

    // Channel domain [xJuncSource, xJuncDrain]
    // Fine at both ends, slightly wider in the middle
    for (let i = 0; i <= numXChannel; i++) {
      const u = i / numXChannel; // 0 to 1
      // Cosine distribution clusters near 0 and 1
      const clusteredU = 0.5 * (1 - Math.cos(Math.PI * u));
      const x = xJuncSource + clusteredU * gateLength;
      xCoords.push(x);
    }

    // Drain domain [xJuncDrain, totalX]
    for (let i = 1; i <= numXDrain; i++) {
      const u = i / numXDrain;
      const x = xJuncDrain + (totalX - xJuncDrain) * Math.pow(u, 1.8);
      xCoords.push(x);
    }

    // Sort and deduplicate floating point precision close nodes
    const sortedX: number[] = [];
    for (const val of xCoords) {
      if (sortedX.length === 0 || val - sortedX[sortedX.length - 1] > 1e-12) {
        sortedX.push(val);
      }
    }

    // 2. Generate non-uniform Y coordinates
    // y = 0 is top of gate oxide, y = oxideThickness is interface, y = totalY is bottom substrate
    const yCoords: number[] = [];

    // Oxide layer [0, oxideThickness]
    for (let j = 0; j < numYOxide; j++) {
      const u = j / numYOxide;
      yCoords.push(oxideThickness * Math.pow(u, 1.3));
    }
    yCoords.push(oxideThickness); // Exact interface node

    // Silicon surface inversion & junction layer [oxideThickness, oxideThickness + junctionDepth]
    // Extremely dense at interface (y = oxideThickness) where inversion occurs within 2-5 nm
    const yJunc = oxideThickness + junctionDepth;
    for (let j = 1; j <= numYChannel; j++) {
      const u = j / numYChannel;
      // Strong cluster at interface: y = tox + Xj * u^2.2
      const y = oxideThickness + junctionDepth * Math.pow(u, 2.2);
      yCoords.push(y);
    }

    // Substrate bulk layer [yJunc, totalY]
    const subThickness = totalY - yJunc;
    for (let j = 1; j <= numYSubstrate; j++) {
      const u = j / numYSubstrate;
      const y = yJunc + subThickness * Math.pow(u, 1.5);
      yCoords.push(y);
    }

    const sortedY: number[] = [];
    for (const val of yCoords) {
      if (sortedY.length === 0 || val - sortedY[sortedY.length - 1] > 1e-12) {
        sortedY.push(val);
      }
    }

    const nx = sortedX.length;
    const ny = sortedY.length;

    // 3. Classify node regions and compute aspect ratio statistics
    // 0: Oxide (y < oxideThickness)
    // 1: Inversion Channel (under gate, y between tox and tox + 5nm)
    // 2: Source (x <= xJuncSource, y between tox and yJunc)
    // 3: Drain (x >= xJuncDrain, y between tox and yJunc)
    // 4: Substrate bulk
    const nodeRegions: number[][] = [];
    let dxMin = Infinity;
    let dyMin = Infinity;
    let maxRatio = 0;
    let sumRatio = 0;
    let ratioCount = 0;

    for (let i = 0; i < nx - 1; i++) {
      const dx = sortedX[i + 1] - sortedX[i];
      if (dx < dxMin) dxMin = dx;
    }

    for (let j = 0; j < ny - 1; j++) {
      const dy = sortedY[j + 1] - sortedY[j];
      if (dy < dyMin) dyMin = dy;
    }

    for (let i = 0; i < nx - 1; i++) {
      const dx = sortedX[i + 1] - sortedX[i];
      for (let j = 0; j < ny - 1; j++) {
        const dy = sortedY[j + 1] - sortedY[j];
        const ratio = Math.max(dx / dy, dy / dx);
        if (ratio > maxRatio) maxRatio = ratio;
        sumRatio += ratio;
        ratioCount++;
      }
    }

    for (let i = 0; i < nx; i++) {
      nodeRegions[i] = [];
      const x = sortedX[i];
      for (let j = 0; j < ny; j++) {
        const y = sortedY[j];

        if (y < oxideThickness) {
          nodeRegions[i][j] = 0; // Oxide
        } else if (x < xJuncSource && y <= yJunc) {
          nodeRegions[i][j] = 2; // Source diffusion
        } else if (x > xJuncDrain && y <= yJunc) {
          nodeRegions[i][j] = 3; // Drain diffusion
        } else if (x >= xJuncSource && x <= xJuncDrain && y <= oxideThickness + 6e-9) {
          nodeRegions[i][j] = 1; // Channel inversion layer
        } else {
          nodeRegions[i][j] = 4; // Substrate bulk
        }
      }
    }

    return {
      nx,
      ny,
      totalElements: (nx - 1) * (ny - 1),
      x: sortedX,
      y: sortedY,
      dxMin,
      dyMin,
      aspectRatioMax: maxRatio,
      aspectRatioAvg: ratioCount > 0 ? sumRatio / ratioCount : 1,
      nodeRegions,
    };
  }
}
