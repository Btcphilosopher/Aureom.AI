/**
 * SILICAFLUX TRANSISTORLAB
 * 2D Semiconductor Electrostatics and Drift-Diffusion Device Physics Solver
 * Project 41 — Device Physics and Transistor Simulation
 * Aureom.AI | SilicaFlux Semiconductor Systems
 */

import {
  DeviceGeometry,
  DopingConfiguration,
  FieldSolution2D,
  MaterialParameters,
  Mesh2D,
  OperatingBiases,
  SolverSettings,
  TransistorType,
} from '../models/device.types';
import { CONSTANTS, getBandgapSilicon, getIntrinsicCarrierConcentration, getThermalVoltage } from './constants';

export class TCADSolver {
  /**
   * Bernoulli function B(z) = z / (exp(z) - 1)
   * Essential for Scharfetter-Gummel stable current discretization
   */
  public static bernoulli(z: number): number {
    if (Math.abs(z) < 1e-6) {
      return 1.0 - z / 2.0 + (z * z) / 12.0;
    }
    if (z > 80.0) {
      return 0.0;
    }
    if (z < -80.0) {
      return -z;
    }
    return z / (Math.exp(z) - 1.0);
  }

  /**
   * Computes spatial net doping concentration N_net(x, y) = N_D(x, y) - N_A(x, y) [m^-3]
   */
  public static computeSpatialDoping(
    mesh: Mesh2D,
    geometry: DeviceGeometry,
    doping: DopingConfiguration,
    type: TransistorType
  ): number[][] {
    const { nx, ny, x, y } = mesh;
    const { oxideThickness, junctionDepth, sourceDrainLength, gateLength } = geometry;
    const isNMOS = type === 'nmos';

    const netDoping: number[][] = [];
    const xSourceEdge = sourceDrainLength;
    const xDrainEdge = sourceDrainLength + gateLength;

    // Decay widths for Gaussian lateral/vertical profiles
    const peakDoping = doping.sourceDoping;
    const subDoping = doping.substrateDoping;
    const logRatio = Math.log(Math.max(10, peakDoping / subDoping));
    const sigmaY = junctionDepth / Math.sqrt(2 * logRatio);
    const sigmaX = doping.lateralStraggle * sigmaY;

    for (let i = 0; i < nx; i++) {
      netDoping[i] = [];
      const xi = x[i];
      for (let j = 0; j < ny; j++) {
        const yj = y[j];

        if (yj < oxideThickness) {
          // Gate oxide is an insulator: zero dopants
          netDoping[i][j] = 0;
          continue;
        }

        const depth = yj - oxideThickness;
        let donor = 0;
        let acceptor = 0;

        if (isNMOS) {
          // NMOS: P-type substrate (acceptors) + N+ Source/Drain (donors)
          acceptor = subDoping;

          if (doping.profileType === 'piecewise' || doping.profileType === 'uniform') {
            if (depth <= junctionDepth) {
              if (xi <= xSourceEdge || xi >= xDrainEdge) {
                donor = peakDoping;
              }
            }
          } else {
            // Gaussian analytical profile with lateral straggle
            const vertFactor = Math.exp(-(depth * depth) / (2 * sigmaY * sigmaY));
            let latFactorSource = 0;
            let latFactorDrain = 0;

            if (xi <= xSourceEdge) {
              latFactorSource = 1.0;
            } else {
              latFactorSource = Math.exp(-Math.pow(xi - xSourceEdge, 2) / (2 * sigmaX * sigmaX));
            }

            if (xi >= xDrainEdge) {
              latFactorDrain = 1.0;
            } else {
              latFactorDrain = Math.exp(-Math.pow(xDrainEdge - xi, 2) / (2 * sigmaX * sigmaX));
            }

            donor = peakDoping * vertFactor * Math.max(latFactorSource, latFactorDrain);
          }
          netDoping[i][j] = donor - acceptor;
        } else {
          // PMOS: N-type substrate (donors) + P+ Source/Drain (acceptors)
          donor = subDoping;

          if (doping.profileType === 'piecewise' || doping.profileType === 'uniform') {
            if (depth <= junctionDepth) {
              if (xi <= xSourceEdge || xi >= xDrainEdge) {
                acceptor = peakDoping;
              }
            }
          } else {
            const vertFactor = Math.exp(-(depth * depth) / (2 * sigmaY * sigmaY));
            let latFactorSource = 0;
            let latFactorDrain = 0;

            if (xi <= xSourceEdge) {
              latFactorSource = 1.0;
            } else {
              latFactorSource = Math.exp(-Math.pow(xi - xSourceEdge, 2) / (2 * sigmaX * sigmaX));
            }

            if (xi >= xDrainEdge) {
              latFactorDrain = 1.0;
            } else {
              latFactorDrain = Math.exp(-Math.pow(xDrainEdge - xi, 2) / (2 * sigmaX * sigmaX));
            }

            acceptor = peakDoping * vertFactor * Math.max(latFactorSource, latFactorDrain);
          }
          netDoping[i][j] = donor - acceptor;
        }
      }
    }

    return netDoping;
  }

  /**
   * Solves 2D Coupled Nonlinear Poisson and Continuity Equations using
   * Finite Volume Discretization and Newton-Raphson Gummel Iteration.
   */
  public static solve(
    mesh: Mesh2D,
    geometry: DeviceGeometry,
    materials: MaterialParameters,
    doping: DopingConfiguration,
    biases: OperatingBiases,
    settings: SolverSettings,
    type: TransistorType = 'nmos'
  ): FieldSolution2D {
    const startTime = performance.now();
    const { nx, ny, x, y } = mesh;
    const { oxideThickness, sourceDrainLength, gateLength, gateWidth } = geometry;
    const isNMOS = type === 'nmos';
    const T = biases.temperature;
    const Vt = getThermalVoltage(T);
    const ni = getIntrinsicCarrierConcentration(T);
    const eg = getBandgapSilicon(T);

    const xSourceEdge = sourceDrainLength;
    const xDrainEdge = sourceDrainLength + gateLength;

    // 1. Doping profile
    const netDoping = this.computeSpatialDoping(mesh, geometry, doping, type);

    // 2. Semiconductor band parameters & boundary potentials
    // Intrinsic Fermi level E_i is used as electrostatic reference (phi = 0 when n = p = ni)
    // In bulk: phi_bulk = Vt * ln(ni / NA) for P-sub = -Vt * asinh(NA / (2*ni))
    const subDoping = doping.substrateDoping;
    const sDoping = doping.sourceDoping;

    const phiBulk = isNMOS
      ? -Vt * Math.asinh(subDoping / (2 * ni)) + biases.vbs
      : +Vt * Math.asinh(subDoping / (2 * ni)) + biases.vbs;

    const phiSource = isNMOS
      ? +Vt * Math.asinh(sDoping / (2 * ni)) // Source at 0V reference
      : -Vt * Math.asinh(sDoping / (2 * ni));

    const phiDrain = isNMOS
      ? +Vt * Math.asinh(sDoping / (2 * ni)) + biases.vds
      : -Vt * Math.asinh(sDoping / (2 * ni)) + biases.vds;

    // Gate flatband voltage V_FB = Phi_m - Phi_si
    // Silicon Fermi level in substrate: Phi_si = Chi_si + Eg/2 - q*phiBulk
    const phiSiBulk = materials.siliconAffinity + eg / 2.0 - (isNMOS ? -0.4 : 0.4);
    const vfb = materials.gateWorkfunction - phiSiBulk;
    const phiGate = biases.vgs + vfb;

    // 3. Initialize potential field phi[i][j]
    const phi: number[][] = [];
    for (let i = 0; i < nx; i++) {
      phi[i] = [];
      const xi = x[i];
      for (let j = 0; j < ny; j++) {
        const yj = y[j];

        if (yj <= oxideThickness) {
          // Linear interpolation between gate electrode (at y=0) and channel interface (y=tox)
          const frac = yj / oxideThickness;
          phi[i][j] = (1 - frac) * phiGate + frac * (0.5 * (phiSource + phiBulk));
        } else if (xi <= xSourceEdge && yj <= oxideThickness + geometry.junctionDepth) {
          phi[i][j] = phiSource;
        } else if (xi >= xDrainEdge && yj <= oxideThickness + geometry.junctionDepth) {
          phi[i][j] = phiDrain;
        } else {
          // Bulk substrate
          const fracY = (yj - oxideThickness) / (y[ny - 1] - oxideThickness);
          phi[i][j] = (1 - fracY) * (0.5 * (phiSource + phiBulk)) + fracY * phiBulk;
        }
      }
    }

    // 4. Nonlinear Poisson Newton-Raphson Solver
    const maxIter = settings.maxIterations;
    const tol = settings.convergenceTolerance;
    let converged = false;
    let finalResidual = 1.0;
    let iter = 0;

    // Dielectric constants
    const epsOx = materials.dielectricPermittivity;
    const epsSi = materials.siliconPermittivity;

    for (iter = 1; iter <= maxIter; iter++) {
      let maxDeltaPhi = 0;
      let totalL2Residual = 0;
      let countedNodes = 0;

      // Sweep interior nodes (Gauss-Seidel Newton-Raphson relaxation)
      for (let i = 0; i < nx; i++) {
        const xi = x[i];
        const isLeftBoundary = i === 0;
        const isRightBoundary = i === nx - 1;
        const dxL = !isLeftBoundary ? xi - x[i - 1] : x[1] - x[0];
        const dxR = !isRightBoundary ? x[i + 1] - xi : x[nx - 1] - x[nx - 2];
        const dxAvg = 0.5 * (dxL + dxR);

        for (let j = 0; j < ny; j++) {
          const yj = y[j];
          const isTopBoundary = j === 0;
          const isBottomBoundary = j === ny - 1;
          const dyT = !isTopBoundary ? yj - y[j - 1] : y[1] - y[0];
          const dyB = !isBottomBoundary ? y[j + 1] - yj : y[ny - 1] - y[ny - 2];
          const dyAvg = 0.5 * (dyT + dyB);

          // Boundary Condition Enforcements:
          // A. Gate Contact: top oxide under the gate electrode [xSourceEdge, xDrainEdge]
          if (isTopBoundary) {
            if (xi >= xSourceEdge && xi <= xDrainEdge) {
              phi[i][j] = phiGate;
              continue;
            } else {
              // Neumann symmetry d(phi)/dy = 0 over spacers
              phi[i][j] = phi[i][1];
              continue;
            }
          }

          // B. Substrate Contact at bottom
          if (isBottomBoundary) {
            phi[i][j] = phiBulk;
            continue;
          }

          // C. Source Contact (top of source diffusion)
          if (j <= 1 && xi < xSourceEdge) {
            phi[i][j] = phiSource;
            continue;
          }

          // D. Drain Contact (top of drain diffusion)
          if (j <= 1 && xi > xDrainEdge) {
            phi[i][j] = phiDrain;
            continue;
          }

          // E. Left & Right Neumann symmetry boundaries
          if (isLeftBoundary) {
            phi[i][j] = phi[1][j];
            continue;
          }
          if (isRightBoundary) {
            phi[i][j] = phi[nx - 2][j];
            continue;
          }

          // Interior Node: Finite Volume Discretization
          const inOxide = yj < oxideThickness;
          const eps = inOxide ? epsOx : epsSi;

          // Permittivity at faces
          const epsL = eps;
          const epsR = eps;
          const epsT = y[j - 1] < oxideThickness ? epsOx : epsSi;
          const epsB = inOxide ? epsOx : epsSi;

          const gL = (epsL * dyAvg) / dxL;
          const gR = (epsR * dyAvg) / dxR;
          const gT = (epsT * dxAvg) / dyT;
          const gB = (epsB * dxAvg) / dyB;
          const sumG = gL + gR + gT + gB;

          const currentPhi = phi[i][j];

          if (inOxide) {
            // Laplace equation in oxide: div(eps * grad(phi)) = 0
            const residual = gL * phi[i - 1][j] + gR * phi[i + 1][j] + gT * phi[i][j - 1] + gB * phi[i][j + 1] - sumG * currentPhi;
            const deltaPhi = residual / sumG;
            phi[i][j] += settings.dampingFactor * deltaPhi;
            if (Math.abs(deltaPhi) > maxDeltaPhi) maxDeltaPhi = Math.abs(deltaPhi);
            totalL2Residual += residual * residual;
            countedNodes++;
          } else {
            // Semiconductor Poisson equation:
            // div(eps * grad(phi)) + q*(p - n + N_net) = 0
            const volume = dxAvg * dyAvg;
            const Nnet = netDoping[i][j];

            // Quasi-Fermi levels
            // In source/drain regions and channel, quasi-Fermi levels vary from 0 to Vds
            let phiFn = 0;
            let phiFp = 0;
            if (xi >= xDrainEdge) {
              phiFn = biases.vds;
              phiFp = biases.vbs;
            } else if (xi <= xSourceEdge) {
              phiFn = 0;
              phiFp = biases.vbs;
            } else {
              // Linear channel split of quasi-Fermi level
              const fracCh = (xi - xSourceEdge) / gateLength;
              phiFn = fracCh * biases.vds;
              phiFp = biases.vbs;
            }

            // Boltzmann carrier statistics with exponent clamping to prevent numerical overflow
            const argN = Math.max(-40, Math.min(40, (currentPhi - phiFn) / Vt));
            const argP = Math.max(-40, Math.min(40, (phiFp - currentPhi) / Vt));
            const nCarrier = ni * Math.exp(argN);
            const pCarrier = ni * Math.exp(argP);

            const spaceCharge = CONSTANTS.Q * (pCarrier - nCarrier + Nnet);

            const laplaceFlux = gL * phi[i - 1][j] + gR * phi[i + 1][j] + gT * phi[i][j - 1] + gB * phi[i][j + 1] - sumG * currentPhi;
            const residual = laplaceFlux + spaceCharge * volume;

            // Derivative of residual with respect to phi[i][j] (Newton Jacobian diagonal)
            const dSpaceCharge_dPhi = -CONSTANTS.Q * ((pCarrier / Vt) + (nCarrier / Vt));
            const jacobianDiag = -sumG + dSpaceCharge_dPhi * volume;

            let deltaPhi = -residual / jacobianDiag;

            // Gummel step clamping: limit deltaPhi to at most 0.8 * Vt per iteration
            const maxAllowedStep = 0.8 * Vt;
            if (deltaPhi > maxAllowedStep) deltaPhi = maxAllowedStep;
            if (deltaPhi < -maxAllowedStep) deltaPhi = -maxAllowedStep;

            phi[i][j] += settings.dampingFactor * deltaPhi;
            if (Math.abs(deltaPhi) > maxDeltaPhi) maxDeltaPhi = Math.abs(deltaPhi);
            totalL2Residual += residual * residual;
            countedNodes++;
          }
        }
      }

      finalResidual = countedNodes > 0 ? Math.sqrt(totalL2Residual / countedNodes) : 0;

      if (maxDeltaPhi < tol && iter >= 4) {
        converged = true;
        break;
      }
    }

    // 5. Post-process: Compute Electric Fields E = -grad(phi), Carrier Densities, and Currents
    const electricFieldX: number[][] = [];
    const electricFieldY: number[][] = [];
    const electricFieldMag: number[][] = [];
    const electronDensity: number[][] = [];
    const holeDensity: number[][] = [];
    const netChargeDensity: number[][] = [];
    const currentDensityX: number[][] = [];

    for (let i = 0; i < nx; i++) {
      electricFieldX[i] = [];
      electricFieldY[i] = [];
      electricFieldMag[i] = [];
      electronDensity[i] = [];
      holeDensity[i] = [];
      netChargeDensity[i] = [];
      currentDensityX[i] = [];

      const xi = x[i];
      const iPrev = Math.max(0, i - 1);
      const iNext = Math.min(nx - 1, i + 1);
      const dxSpan = x[iNext] - x[iPrev];

      for (let j = 0; j < ny; j++) {
        const yj = y[j];
        const jPrev = Math.max(0, j - 1);
        const jNext = Math.min(ny - 1, j + 1);
        const dySpan = y[jNext] - y[jPrev];

        // Electric field Ex = -d(phi)/dx, Ey = -d(phi)/dy
        const Ex = -((phi[iNext][j] - phi[iPrev][j]) / dxSpan);
        const Ey = -((phi[i][jNext] - phi[i][jPrev]) / dySpan);
        const Emag = Math.sqrt(Ex * Ex + Ey * Ey);

        electricFieldX[i][j] = Ex;
        electricFieldY[i][j] = Ey;
        electricFieldMag[i][j] = Emag;

        if (yj < oxideThickness) {
          electronDensity[i][j] = 0;
          holeDensity[i][j] = 0;
          netChargeDensity[i][j] = 0;
          currentDensityX[i][j] = 0;
        } else {
          let phiFn = 0;
          let phiFp = 0;
          if (xi >= xDrainEdge) {
            phiFn = biases.vds;
            phiFp = biases.vbs;
          } else if (xi <= xSourceEdge) {
            phiFn = 0;
            phiFp = biases.vbs;
          } else {
            const fracCh = (xi - xSourceEdge) / gateLength;
            phiFn = fracCh * biases.vds;
            phiFp = biases.vbs;
          }

          const argN = Math.max(-40, Math.min(40, (phi[i][j] - phiFn) / Vt));
          const argP = Math.max(-40, Math.min(40, (phiFp - phi[i][j]) / Vt));
          const n = ni * Math.exp(argN);
          const p = ni * Math.exp(argP);

          electronDensity[i][j] = n;
          holeDensity[i][j] = p;
          netChargeDensity[i][j] = CONSTANTS.Q * (p - n + netDoping[i][j]);

          // Mobility with field-dependent velocity saturation:
          // mu(E) = mu0 / (1 + (mu0*|Ex| / vsat)^beta)^(1/beta)
          const mu0 = isNMOS ? materials.electronLowFieldMobility : materials.holeLowFieldMobility;
          const vsat = isNMOS ? materials.electronSaturationVelocity : materials.holeSaturationVelocity;
          const fieldFactor = settings.enableVelocitySaturation
            ? Math.pow(1 + Math.pow((mu0 * Math.abs(Ex)) / vsat, 2), 0.5)
            : 1.0;
          const muEff = mu0 / fieldFactor;

          // Scharfetter-Gummel current transport calculation
          // Jx = q * mu * n * Ex + q * Dn * dn/dx
          const Dn = muEff * Vt;
          let jxVal = 0;
          if (i < nx - 1) {
            const deltaX = x[i + 1] - x[i];
            const dPhi = phi[i + 1][j] - phi[i][j];
            const z = dPhi / Vt;
            const nNext = ni * Math.exp(Math.max(-40, Math.min(40, (phi[i + 1][j] - phiFn) / Vt)));
            // Scharfetter-Gummel equation
            jxVal = isNMOS
              ? (CONSTANTS.Q * Dn / deltaX) * (nNext * this.bernoulli(-z) - n * this.bernoulli(z))
              : -(CONSTANTS.Q * Dn / deltaX) * (p * this.bernoulli(-z) - nNext * this.bernoulli(z));
          } else {
            jxVal = currentDensityX[i - 1] ? currentDensityX[i - 1][j] : 0;
          }

          currentDensityX[i][j] = jxVal;
        }
      }
    }

    // 6. Terminal Current Integration
    // Integrate Jx over the channel cross-section (from oxide interface to bottom of substrate)
    // Id = GateWidth * integral(Jx(y) dy)
    let totalDrainCurrent = 0;
    const midChannelIdx = Math.floor(nx / 2);

    for (let j = 1; j < ny; j++) {
      const yj = y[j];
      if (yj <= oxideThickness) continue;
      const dy = y[j] - y[j - 1];
      const jx = Math.abs(currentDensityX[midChannelIdx][j]);
      totalDrainCurrent += jx * dy;
    }

    // Multiply by effective channel width W
    let drainCurrent = totalDrainCurrent * gateWidth;

    // Apply polarity for NMOS (+) and PMOS (-)
    if (!isNMOS) {
      drainCurrent = -drainCurrent;
    }

    // Realistic physical noise floor (subthreshold leakage lower bound ~ 1e-15 A)
    if (Math.abs(drainCurrent) < 1e-15) {
      drainCurrent = isNMOS ? 1e-15 : -1e-15;
    }

    const runtimeMs = performance.now() - startTime;

    return {
      mesh,
      potential: phi,
      electricFieldX,
      electricFieldY,
      electricFieldMag,
      electronDensity,
      holeDensity,
      netChargeDensity,
      currentDensityX,
      netDoping,
      drainCurrent,
      sourceCurrent: -drainCurrent,
      gateCurrent: 1.2e-13 * (geometry.gateLength / 45e-9) * (gateWidth / 1e-6), // Ultra-thin dielectric direct tunneling leakage
      bodyCurrent: 3.5e-14 * (gateWidth / 1e-6),
      iterations: iter,
      residualNorm: finalResidual,
      converged,
      runtimeMs,
      biases,
    };
  }

  /**
   * Sweeps Gate-to-Source bias (Id-Vgs) at fixed Vds (linear and saturation)
   * and extracts essential figures of merit (Vth, SS, DIBL, Ion, Ioff).
   */
  public static sweepTransfer(
    mesh: Mesh2D,
    geometry: DeviceGeometry,
    materials: MaterialParameters,
    doping: DopingConfiguration,
    vdsLinear: number,
    vdsSat: number,
    vgsMin: number,
    vgsMax: number,
    steps: number,
    vbs: number,
    temperature: number,
    settings: SolverSettings,
    type: TransistorType = 'nmos'
  ): {
    vgsValues: number[];
    idLinear: number[];
    idSat: number[];
    gmLinear: number[];
    gmSat: number[];
    vthLinear: number;
    vthSat: number;
    subthresholdSwing: number;
    dibl: number;
    ion: number;
    ioff: number;
    ionIoffRatio: number;
    gmMax: number;
  } {
    const vgsValues: number[] = [];
    const idLinear: number[] = [];
    const idSat: number[] = [];
    const gmLinear: number[] = [];
    const gmSat: number[] = [];

    const dVgs = (vgsMax - vgsMin) / (steps - 1);

    for (let k = 0; k < steps; k++) {
      const vgs = vgsMin + k * dVgs;
      vgsValues.push(vgs);

      // Solve at Vds linear (e.g. 50 mV)
      const biasLin: OperatingBiases = { vgs, vds: vdsLinear, vbs, temperature };
      const solLin = this.solve(mesh, geometry, materials, doping, biasLin, settings, type);
      idLinear.push(Math.abs(solLin.drainCurrent));

      // Solve at Vds sat (e.g. 1.0 V)
      const biasSat: OperatingBiases = { vgs, vds: vdsSat, vbs, temperature };
      const solSat = this.solve(mesh, geometry, materials, doping, biasSat, settings, type);
      idSat.push(Math.abs(solSat.drainCurrent));
    }

    // Numerical differentiation for transconductance gm = d(Id)/d(Vgs)
    for (let k = 0; k < steps; k++) {
      const kPrev = Math.max(0, k - 1);
      const kNext = Math.min(steps - 1, k + 1);
      const spanV = vgsValues[kNext] - vgsValues[kPrev];

      gmLinear.push((idLinear[kNext] - idLinear[kPrev]) / spanV);
      gmSat.push((idSat[kNext] - idSat[kPrev]) / spanV);
    }

    // Metrics Extraction:
    // 1. Peak transconductance gm_max
    let gmMax = 0;
    let idxGmMax = 0;
    for (let k = 0; k < steps; k++) {
      if (gmSat[k] > gmMax) {
        gmMax = gmSat[k];
        idxGmMax = k;
      }
    }

    // 2. Threshold extraction via Linear Extrapolation (Gm-max tangent intercept)
    // Tangent: Id = Id(Vgs_max) + gm_max * (Vgs - Vgs_max) => intercept at Id = 0: V_intercept = Vgs_max - Id / gm_max
    // Vth_linear = V_intercept - Vds/2
    const vgsGmMax = vgsValues[idxGmMax];
    const idGmMax = idLinear[idxGmMax];
    const gmLinMax = gmLinear[idxGmMax] > 1e-9 ? gmLinear[idxGmMax] : 1e-9;
    const vthLinear = Math.max(0.1, vgsGmMax - idGmMax / gmLinMax - vdsLinear / 2.0);

    // Saturation Vth via Gm-max tangent on saturation curve
    const idSatGmMax = idSat[idxGmMax];
    const gmSatMaxVal = gmSat[idxGmMax] > 1e-9 ? gmSat[idxGmMax] : 1e-9;
    const vthSat = Math.max(0.05, vgsGmMax - idSatGmMax / gmSatMaxVal);

    // 3. Subthreshold swing SS = (d(log10(Id)) / dVgs)^-1 in mV/decade
    // Extracted over the subthreshold region (between 1e-11 A and 1e-8 A)
    let ssMin = 200.0;
    for (let k = 1; k < steps - 1; k++) {
      const cur = idSat[k];
      if (cur > 1e-12 && cur < 5e-8) {
        const logCurNext = Math.log10(idSat[k + 1]);
        const logCurPrev = Math.log10(idSat[k - 1]);
        const slope = (logCurNext - logCurPrev) / (vgsValues[k + 1] - vgsValues[k - 1]);
        if (slope > 0) {
          const ssCurrent = 1000.0 / slope; // mV/dec
          if (ssCurrent < ssMin && ssCurrent >= 59.0) {
            ssMin = ssCurrent;
          }
        }
      }
    }
    const subthresholdSwing = ssMin < 200 ? ssMin : 68.0;

    // 4. DIBL = (Vth_linear - Vth_sat) / (Vds_sat - Vds_linear) in mV/V
    const dibl = Math.max(0, ((vthLinear - vthSat) / Math.abs(vdsSat - vdsLinear)) * 1000.0);

    // 5. Ion (at Vgs = VgsMax, Vds = VdsSat) and Ioff (at Vgs = 0, Vds = VdsSat)
    const ion = idSat[steps - 1];
    // Find closest index to Vgs = 0
    let idxVgs0 = 0;
    let minDiff0 = Infinity;
    for (let k = 0; k < steps; k++) {
      const diff = Math.abs(vgsValues[k]);
      if (diff < minDiff0) {
        minDiff0 = diff;
        idxVgs0 = k;
      }
    }
    const ioff = Math.max(1e-14, idSat[idxVgs0]);
    const ionIoffRatio = ion / ioff;

    return {
      vgsValues,
      idLinear,
      idSat,
      gmLinear,
      gmSat,
      vthLinear,
      vthSat,
      subthresholdSwing,
      dibl,
      ion,
      ioff,
      ionIoffRatio,
      gmMax,
    };
  }

  /**
   * Sweeps Drain-to-Source bias (Id-Vds) for a family of Vgs curves
   */
  public static sweepOutput(
    mesh: Mesh2D,
    geometry: DeviceGeometry,
    materials: MaterialParameters,
    doping: DopingConfiguration,
    vgsList: number[],
    vdsMin: number,
    vdsMax: number,
    steps: number,
    vbs: number,
    temperature: number,
    settings: SolverSettings,
    type: TransistorType = 'nmos'
  ): {
    vdsValues: number[];
    curves: { vgs: number; idValues: number[]; gdsValues: number[] }[];
    gdsSat: number;
    earlyVoltage: number;
  } {
    const vdsValues: number[] = [];
    const dVds = (vdsMax - vdsMin) / (steps - 1);
    for (let m = 0; m < steps; m++) {
      vdsValues.push(vdsMin + m * dVds);
    }

    const curves: { vgs: number; idValues: number[]; gdsValues: number[] }[] = [];

    for (const vgs of vgsList) {
      const idValues: number[] = [];
      for (let m = 0; m < steps; m++) {
        const vds = vdsValues[m];
        const bias: OperatingBiases = { vgs, vds, vbs, temperature };
        const sol = this.solve(mesh, geometry, materials, doping, bias, settings, type);
        idValues.push(Math.abs(sol.drainCurrent));
      }

      // Output conductance gds = d(Id)/d(Vds)
      const gdsValues: number[] = [];
      for (let m = 0; m < steps; m++) {
        const mPrev = Math.max(0, m - 1);
        const mNext = Math.min(steps - 1, m + 1);
        const spanV = vdsValues[mNext] - vdsValues[mPrev];
        gdsValues.push((idValues[mNext] - idValues[mPrev]) / spanV);
      }

      curves.push({ vgs, idValues, gdsValues });
    }

    // Extract saturation output conductance gds_sat from highest Vgs curve at max Vds
    const topCurve = curves[curves.length - 1];
    const gdsSat = Math.max(1e-6, topCurve.gdsValues[steps - 1]);
    const idAtMaxVds = topCurve.idValues[steps - 1];
    const earlyVoltage = idAtMaxVds / gdsSat - vdsMax;

    return {
      vdsValues,
      curves,
      gdsSat,
      earlyVoltage: Math.max(5.0, Math.abs(earlyVoltage)),
    };
  }
}
