/**
 * SILICAFLUX TRANSISTORLAB
 * Operating Biases, Terminal Currents, and Extracted Device Metrics Panel
 * Project 41 — Device Physics and Transistor Simulation
 */

import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from '../core/services/transistor-lab';

@Component({
  selector: 'app-operating-biases-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col bg-[#0B182D] border border-[#1E3354] rounded-xl overflow-hidden shadow-xl text-slate-200">
      <!-- Header -->
      <div class="px-4 py-3 bg-[#070F1E] border-b border-[#1E3354] flex items-center justify-between">
        <div class="flex items-center gap-2">
          <mat-icon class="text-[#1CCCE5] scale-90">electric_bolt</mat-icon>
          <span class="text-xs font-bold uppercase tracking-wider text-white">Electrical Biasing</span>
        </div>
        <div class="flex items-center gap-1.5 text-[11px] font-mono">
          <span
            class="w-2 h-2 rounded-full"
            [class.bg-emerald-400]="lab.solution()?.converged"
            [class.bg-rose-500]="!lab.solution()?.converged"
          ></span>
          <span [class.text-emerald-400]="lab.solution()?.converged" [class.text-rose-400]="!lab.solution()?.converged">
            {{ lab.solution()?.converged ? 'CONVERGED' : 'SOLVING' }}
          </span>
        </div>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-5">
        <!-- 1. Operating State Presets -->
        <div>
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
            Bias Presets
          </div>
          <div class="grid grid-cols-2 gap-2 text-xs">
            <button
              (click)="lab.applyBiasPreset('off')"
              class="py-1.5 px-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-rose-400">Off-State</div>
              <div class="text-[10px] text-slate-400 font-mono">Vgs=0V Vds=0.8V</div>
            </button>
            <button
              (click)="lab.applyBiasPreset('subthreshold')"
              class="py-1.5 px-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-[#D7AD59]">Subthreshold</div>
              <div class="text-[10px] text-slate-400 font-mono">Vgs=0.25V Leakage</div>
            </button>
            <button
              (click)="lab.applyBiasPreset('linear')"
              class="py-1.5 px-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-[#1CCCE5]">Linear / Triode</div>
              <div class="text-[10px] text-slate-400 font-mono">Vgs=0.8V Vds=0.05V</div>
            </button>
            <button
              (click)="lab.applyBiasPreset('saturation')"
              class="py-1.5 px-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-emerald-400">Saturation (ON)</div>
              <div class="text-[10px] text-slate-400 font-mono">Vgs=0.8V Vds=0.8V</div>
            </button>
          </div>
        </div>

        <!-- 2. Terminal Bias Sliders -->
        <div class="space-y-3">
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Terminal Voltages</span>
            <span class="text-[10px] font-mono text-[#1CCCE5]">DC Operating Point</span>
          </div>

          <!-- Vgs Slider -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Gate Bias (Vgs):</span>
              <span class="font-mono text-[#D7AD59] font-bold">{{ lab.biases().vgs.toFixed(3) }} V</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="1.2"
              step="0.02"
              [value]="lab.biases().vgs"
              (input)="onVgsChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
          </div>

          <!-- Vds Slider -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Drain Bias (Vds):</span>
              <span class="font-mono text-[#1CCCE5] font-bold">{{ lab.biases().vds.toFixed(3) }} V</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="1.2"
              step="0.02"
              [value]="lab.biases().vds"
              (input)="onVdsChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
          </div>

          <!-- Vbs Slider -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Substrate Bias (Vbs):</span>
              <span class="font-mono text-slate-300">{{ lab.biases().vbs.toFixed(2) }} V</span>
            </div>
            <input
              type="range"
              min="-1.0"
              max="0.0"
              step="0.05"
              [value]="lab.biases().vbs"
              (input)="onVbsChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
          </div>

          <!-- Temperature Slider -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Lattice Temp (T):</span>
              <span class="font-mono text-amber-400 font-bold">{{ lab.biases().temperature.toFixed(0) }} K ({{ (lab.biases().temperature - 273.15).toFixed(0) }} °C)</span>
            </div>
            <input
              type="range"
              min="200"
              max="425"
              step="5"
              [value]="lab.biases().temperature"
              (input)="onTempChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
          </div>
        </div>

        <!-- 3. Solve & Recharacterize Action -->
        <button
          (click)="lab.runFullSimulation()"
          [disabled]="lab.simulationStatus() === 'solving'"
          class="w-full py-2.5 px-4 bg-gradient-to-r from-[#1CCCE5] to-[#814DD1] text-[#070F1E] font-bold text-xs rounded-xl shadow-lg hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
        >
          <mat-icon class="text-sm scale-90" [class.animate-spin]="lab.simulationStatus() === 'solving'">
            {{ lab.simulationStatus() === 'solving' ? 'sync' : 'play_arrow' }}
          </mat-icon>
          <span>{{ lab.simulationStatus() === 'solving' ? 'Solving TCAD & Sweeps...' : 'Run TCAD & Characterize' }}</span>
        </button>

        <!-- 4. Terminal Currents Readout -->
        <div>
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
            Terminal Currents
          </div>
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-3 space-y-2 font-mono text-xs">
            <div class="flex justify-between items-center">
              <span class="text-slate-400">Drain (Id):</span>
              <span class="text-[#1CCCE5] font-bold">{{ formatCurrent(lab.solution()?.drainCurrent || 0) }}</span>
            </div>
            <div class="flex justify-between items-center text-[11px]">
              <span class="text-slate-500">Normalized Drive:</span>
              <span class="text-emerald-400 font-semibold">{{ normalizedDriveCurrent() }} µA/µm</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-slate-400">Source (Is):</span>
              <span class="text-slate-300">{{ formatCurrent(lab.solution()?.sourceCurrent || 0) }}</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-slate-400">Gate Leakage (Ig):</span>
              <span class="text-rose-400">{{ (lab.solution()?.gateCurrent || 0).toExponential(2) }} A</span>
            </div>
          </div>
        </div>

        <!-- 5. Key Extracted Metrics Cards -->
        <div>
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
            Extracted Metrics (TCAD)
          </div>
          <div class="grid grid-cols-2 gap-2 text-xs">
            <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5">
              <div class="text-[10px] text-slate-400 uppercase">Threshold Vth</div>
              <div class="text-sm font-mono font-bold text-[#D7AD59] mt-0.5">
                {{ (lab.extractedMetrics()?.vthLinear || 0).toFixed(3) }} V
              </div>
              <div class="text-[10px] text-slate-500">Linear (50mV)</div>
            </div>

            <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5">
              <div class="text-[10px] text-slate-400 uppercase">Subthreshold SS</div>
              <div class="text-sm font-mono font-bold text-[#1CCCE5] mt-0.5">
                {{ (lab.extractedMetrics()?.subthresholdSwing || 0).toFixed(1) }}
              </div>
              <div class="text-[10px] text-slate-500">mV/decade</div>
            </div>

            <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5">
              <div class="text-[10px] text-slate-400 uppercase">DIBL Parameter</div>
              <div class="text-sm font-mono font-bold text-emerald-400 mt-0.5">
                {{ (lab.extractedMetrics()?.dibl || 0).toFixed(1) }}
              </div>
              <div class="text-[10px] text-slate-500">mV/V</div>
            </div>

            <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5">
              <div class="text-[10px] text-slate-400 uppercase">Ion / Ioff Ratio</div>
              <div class="text-sm font-mono font-bold text-violet-400 mt-0.5">
                10^{{ logIonIoff() }}
              </div>
              <div class="text-[10px] text-slate-500">Dynamic Range</div>
            </div>

            <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5">
              <div class="text-[10px] text-slate-400 uppercase">Peak gm</div>
              <div class="text-sm font-mono font-bold text-white mt-0.5">
                {{ (lab.extractedMetrics()?.gmNormalized || 0).toFixed(0) }}
              </div>
              <div class="text-[10px] text-slate-500">mS/µm</div>
            </div>

            <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5">
              <div class="text-[10px] text-slate-400 uppercase">Early Voltage VA</div>
              <div class="text-sm font-mono font-bold text-amber-400 mt-0.5">
                {{ (lab.extractedMetrics()?.earlyVoltage || 0).toFixed(1) }} V
              </div>
              <div class="text-[10px] text-slate-500">Output Resistance</div>
            </div>
          </div>
        </div>

        <!-- 6. Solver Diagnostics -->
        <div class="bg-[#070F1E]/80 border border-[#1E3354] rounded-lg p-2.5 text-[11px] font-mono text-slate-400 space-y-1">
          <div class="flex justify-between">
            <span>Nonlinear Iterations:</span>
            <span class="text-white">{{ lab.solution()?.iterations || 0 }}</span>
          </div>
          <div class="flex justify-between">
            <span>L2 Residual Norm:</span>
            <span class="text-white">{{ lab.solution()?.residualNorm?.toExponential(2) || '0' }}</span>
          </div>
          <div class="flex justify-between">
            <span>Solve Execution Time:</span>
            <span class="text-[#D7AD59]">{{ (lab.solution()?.runtimeMs || 0).toFixed(1) }} ms</span>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class OperatingBiasesPanel {
  protected readonly lab = inject(TransistorLab);

  public readonly normalizedDriveCurrent = computed(() => {
    const sol = this.lab.solution();
    const w = this.lab.geometry().gateWidth;
    if (!sol || !w) return '0.0';
    const driveUaUm = (Math.abs(sol.drainCurrent) / (w * 1e6)) * 1e6;
    return driveUaUm.toFixed(1);
  });

  public readonly logIonIoff = computed(() => {
    const met = this.lab.extractedMetrics();
    if (!met || !met.ionIoffRatio) return '7.5';
    return Math.log10(met.ionIoffRatio).toFixed(1);
  });

  public formatCurrent(amps: number): string {
    const absA = Math.abs(amps);
    if (absA >= 1e-3) return `${(amps * 1e3).toFixed(3)} mA`;
    if (absA >= 1e-6) return `${(amps * 1e6).toFixed(2)} µA`;
    if (absA >= 1e-9) return `${(amps * 1e9).toFixed(2)} nA`;
    if (absA >= 1e-12) return `${(amps * 1e12).toFixed(2)} pA`;
    return `${amps.toExponential(3)} A`;
  }

  public onVgsChange(event: Event): void {
    const vgs = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateBiases({ vgs });
  }

  public onVdsChange(event: Event): void {
    const vds = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateBiases({ vds });
  }

  public onVbsChange(event: Event): void {
    const vbs = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateBiases({ vbs });
  }

  public onTempChange(event: Event): void {
    const t = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateBiases({ temperature: t });
  }
}
