/**
 * SILICAFLUX TRANSISTORLAB
 * Transistor Geometry, Materials, and Doping Profile Editor
 * Project 41 — Device Physics and Transistor Simulation
 */

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from '../core/services/transistor-lab';
import { CONSTANTS } from '../core/physics/constants';
import { DielectricMaterial, GateMaterial, TransistorArchitecture } from '../core/models/device.types';

@Component({
  selector: 'app-geometry-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col bg-[#0B182D] border border-[#1E3354] rounded-xl overflow-hidden shadow-xl text-slate-200">
      <!-- Section Header -->
      <div class="px-4 py-3 bg-[#070F1E] border-b border-[#1E3354] flex items-center justify-between">
        <div class="flex items-center gap-2">
          <mat-icon class="text-[#D7AD59] scale-90">tune</mat-icon>
          <span class="text-xs font-bold uppercase tracking-wider text-white">Device Parameters</span>
        </div>
        <span class="text-[11px] font-mono text-[#1CCCE5] bg-[#1CCCE5]/10 px-2 py-0.5 rounded border border-[#1CCCE5]/20">
          {{ lab.transistorType().toUpperCase() }} Planar
        </span>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-5">
        <!-- 1. Technology Presets -->
        <div>
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
            <mat-icon class="text-xs scale-75 text-[#D7AD59]">auto_awesome</mat-icon>
            Node Presets
          </div>
          <div class="grid grid-cols-2 gap-2 text-xs">
            <button
              (click)="applyPreset('45nm_hp')"
              class="px-2.5 py-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-white">45nm High-Perf</div>
              <div class="text-[10px] text-slate-400 font-mono">Lg=45nm Tox=1.4nm</div>
            </button>
            <button
              (click)="applyPreset('45nm_lp')"
              class="px-2.5 py-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-[#1CCCE5]">45nm Low-Power</div>
              <div class="text-[10px] text-slate-400 font-mono">Lg=55nm Tox=1.8nm</div>
            </button>
            <button
              (click)="applyPreset('45nm_pmos')"
              class="px-2.5 py-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-[#D7AD59]">45nm PMOS</div>
              <div class="text-[10px] text-slate-400 font-mono">P-Channel / N-Well</div>
            </button>
            <button
              (click)="applyPreset('90nm_legacy')"
              class="px-2.5 py-2 bg-[#070F1E] hover:bg-[#1E3354] border border-[#1E3354] rounded-lg text-left transition-colors cursor-pointer"
            >
              <div class="font-semibold text-slate-300">90nm Standard</div>
              <div class="text-[10px] text-slate-400 font-mono">Lg=90nm Tox=2.5nm</div>
            </button>
          </div>
        </div>

        <!-- 2. Device Polarity & Architecture -->
        <div>
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
            Polarity & Architecture
          </div>
          <div class="grid grid-cols-2 gap-2 mb-2">
            <button
              (click)="lab.setTransistorType('nmos')"
              class="py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              [class.bg-[#1CCCE5]]="lab.transistorType() === 'nmos'"
              [class.text-[#070F1E]]="lab.transistorType() === 'nmos'"
              [class.bg-[#070F1E]]="lab.transistorType() !== 'nmos'"
              [class.border]="lab.transistorType() !== 'nmos'"
              [class.border-[#1E3354]]="lab.transistorType() !== 'nmos'"
            >
              <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
              NMOS (e⁻)
            </button>
            <button
              (click)="lab.setTransistorType('pmos')"
              class="py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              [class.bg-[#D7AD59]]="lab.transistorType() === 'pmos'"
              [class.text-[#070F1E]]="lab.transistorType() === 'pmos'"
              [class.bg-[#070F1E]]="lab.transistorType() !== 'pmos'"
              [class.border]="lab.transistorType() !== 'pmos'"
              [class.border-[#1E3354]]="lab.transistorType() !== 'pmos'"
            >
              <span class="w-2 h-2 rounded-full bg-amber-400"></span>
              PMOS (h⁺)
            </button>
          </div>

          <!-- Architecture selector -->
          <div class="flex items-center justify-between text-xs bg-[#070F1E] border border-[#1E3354] rounded-lg p-2">
            <span class="text-slate-400">Architecture:</span>
            <select
              [value]="lab.architecture()"
              (change)="onArchitectureChange($event)"
              class="bg-[#0B182D] text-white border border-[#1E3354] rounded px-2 py-1 text-xs outline-none cursor-pointer"
            >
              <option value="planar">Planar Bulk CMOS</option>
              <option value="finfet">FinFET (3D Tri-gate Preview)</option>
              <option value="nanosheet">GAA Nanosheet (Roadmap)</option>
              <option value="soi">FD-SOI Ultra-Thin Body</option>
              <option value="hkmg">High-k Metal Gate (HKMG)</option>
            </select>
          </div>
        </div>

        <!-- 3. Geometry Parameters -->
        <div class="space-y-3">
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Dimensions</span>
            <span class="text-[10px] font-mono text-[#D7AD59]">SI Nanoscale</span>
          </div>

          <!-- Gate Length Lg -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Gate Length (Lg):</span>
              <span class="font-mono text-[#D7AD59] font-bold">{{ (lab.geometry().gateLength * 1e9).toFixed(1) }} nm</span>
            </div>
            <input
              type="range"
              min="20"
              max="130"
              step="1"
              [value]="lab.geometry().gateLength * 1e9"
              (input)="onLgChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
            <div class="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>20 nm</span>
              <span>Sub-micron</span>
              <span>130 nm</span>
            </div>
          </div>

          <!-- Channel Width W -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Effective Width (W):</span>
              <span class="font-mono text-[#1CCCE5] font-bold">{{ (lab.geometry().gateWidth * 1e6).toFixed(2) }} µm</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="5.0"
              step="0.1"
              [value]="lab.geometry().gateWidth * 1e6"
              (input)="onWidthChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
            <div class="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0.2 µm</span>
              <span>Scale W/L</span>
              <span>5.0 µm</span>
            </div>
          </div>

          <!-- Oxide Thickness Tox -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Oxide Thickness (Tox):</span>
              <span class="font-mono text-[#5EEAD4] font-bold">{{ (lab.geometry().oxideThickness * 1e9).toFixed(2) }} nm</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="4.0"
              step="0.1"
              [value]="lab.geometry().oxideThickness * 1e9"
              (input)="onToxChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
            <div class="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0.8 nm (Quantum)</span>
              <span>EOT: {{ lab.equivalentOxideThickness().toFixed(2) }}nm</span>
              <span>4.0 nm</span>
            </div>
          </div>

          <!-- Junction Depth Xj -->
          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-2.5 space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300">Junction Depth (Xj):</span>
              <span class="font-mono text-slate-200 font-bold">{{ (lab.geometry().junctionDepth * 1e9).toFixed(1) }} nm</span>
            </div>
            <input
              type="range"
              min="10"
              max="50"
              step="1"
              [value]="lab.geometry().junctionDepth * 1e9"
              (input)="onXjChange($event)"
              class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
            />
          </div>
        </div>

        <!-- 4. Material & Gate Stack -->
        <div class="space-y-3">
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Dielectric & Gate Stack
          </div>

          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-3 space-y-3 text-xs">
            <!-- Dielectric selector -->
            <div class="flex items-center justify-between">
              <span class="text-slate-300">Dielectric Material:</span>
              <select
                [value]="lab.materials().dielectricType"
                (change)="onDielectricChange($event)"
                class="bg-[#0B182D] text-white border border-[#1E3354] rounded px-2 py-1 text-xs outline-none cursor-pointer"
              >
                <option value="sio2">SiO2 (&epsilon;r = 3.9)</option>
                <option value="hfo2">HfO2 High-k (&epsilon;r = 22.0)</option>
                <option value="al2o3">Al2O3 (&epsilon;r = 9.0)</option>
              </select>
            </div>

            <!-- Gate Electrode -->
            <div class="flex items-center justify-between">
              <span class="text-slate-300">Gate Material:</span>
              <select
                [value]="lab.materials().gateMaterialType"
                (change)="onGateMaterialChange($event)"
                class="bg-[#0B182D] text-white border border-[#1E3354] rounded px-2 py-1 text-xs outline-none cursor-pointer"
              >
                <option value="n_poly">N+ Polysilicon (4.15 eV)</option>
                <option value="p_poly">P+ Polysilicon (5.15 eV)</option>
                <option value="midgap_metal">Midgap Metal (4.65 eV)</option>
                <option value="custom_metal">Custom Workfunction</option>
              </select>
            </div>

            <div class="flex justify-between items-center text-xs">
              <span class="text-slate-400">Workfunction (&Phi;m):</span>
              <span class="font-mono text-[#D7AD59]">{{ lab.materials().gateWorkfunction.toFixed(2) }} eV</span>
            </div>
          </div>
        </div>

        <!-- 5. Doping Configuration -->
        <div class="space-y-3">
          <div class="block text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Doping Concentrations
          </div>

          <div class="bg-[#070F1E] border border-[#1E3354] rounded-lg p-3 space-y-3 text-xs">
            <!-- Profile Type -->
            <div class="flex items-center justify-between">
              <span class="text-slate-300">Spatial Profile:</span>
              <select
                [value]="lab.doping().profileType"
                (change)="onProfileTypeChange($event)"
                class="bg-[#0B182D] text-white border border-[#1E3354] rounded px-2 py-1 text-xs outline-none cursor-pointer"
              >
                <option value="gaussian">Gaussian Lateral Straggle</option>
                <option value="piecewise">Piecewise Step Profile</option>
                <option value="uniform">Uniform Box Model</option>
              </select>
            </div>

            <!-- Substrate Doping -->
            <div class="space-y-1">
              <div class="flex justify-between text-xs">
                <span class="text-slate-400">{{ lab.transistorType() === 'nmos' ? 'Substrate (Na):' : 'Well (Nd):' }}</span>
                <span class="font-mono text-[#1CCCE5]">{{ (lab.doping().substrateDoping / 1e6).toExponential(1) }} cm⁻³</span>
              </div>
              <input
                type="range"
                min="16"
                max="18.5"
                step="0.1"
                [value]="getLogDoping(lab.doping().substrateDoping)"
                (input)="onSubstrateDopingChange($event)"
                class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
              />
            </div>

            <!-- Source/Drain Peak Doping -->
            <div class="space-y-1">
              <div class="flex justify-between text-xs">
                <span class="text-slate-400">Source/Drain (Nd/Na):</span>
                <span class="font-mono text-emerald-400">{{ (lab.doping().sourceDoping / 1e6).toExponential(1) }} cm⁻³</span>
              </div>
              <input
                type="range"
                min="19"
                max="20.8"
                step="0.1"
                [value]="getLogDoping(lab.doping().sourceDoping)"
                (input)="onSourceDopingChange($event)"
                class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class GeometryEditor {
  protected readonly lab = inject(TransistorLab);

  public applyPreset(presetKey: string): void {
    switch (presetKey) {
      case '45nm_hp':
        this.lab.setTransistorType('nmos');
        this.lab.updateGeometry({ gateLength: 45e-9, oxideThickness: 1.4e-9, junctionDepth: 25e-9 });
        break;
      case '45nm_lp':
        this.lab.setTransistorType('nmos');
        this.lab.updateGeometry({ gateLength: 55e-9, oxideThickness: 1.8e-9, junctionDepth: 28e-9 });
        break;
      case '45nm_pmos':
        this.lab.setTransistorType('pmos');
        this.lab.updateGeometry({ gateLength: 45e-9, oxideThickness: 1.4e-9, junctionDepth: 25e-9 });
        break;
      case '90nm_legacy':
        this.lab.setTransistorType('nmos');
        this.lab.updateGeometry({ gateLength: 90e-9, oxideThickness: 2.5e-9, junctionDepth: 35e-9 });
        break;
    }
  }

  public onArchitectureChange(event: Event): void {
    const arch = (event.target as HTMLSelectElement).value as TransistorArchitecture;
    this.lab.setArchitecture(arch);
  }

  public onLgChange(event: Event): void {
    const valNm = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateGeometry({ gateLength: valNm * 1e-9 });
  }

  public onWidthChange(event: Event): void {
    const valUm = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateGeometry({ gateWidth: valUm * 1e-6 });
  }

  public onToxChange(event: Event): void {
    const valNm = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateGeometry({ oxideThickness: valNm * 1e-9 });
  }

  public onXjChange(event: Event): void {
    const valNm = parseFloat((event.target as HTMLInputElement).value);
    this.lab.updateGeometry({ junctionDepth: valNm * 1e-9 });
  }

  public onDielectricChange(event: Event): void {
    const mat = (event.target as HTMLSelectElement).value as DielectricMaterial;
    let epsRel = 3.9;
    if (mat === 'hfo2') epsRel = 22.0;
    if (mat === 'al2o3') epsRel = 9.0;
    this.lab.updateMaterials({
      dielectricType: mat,
      dielectricPermittivity: epsRel * CONSTANTS.EPS0,
    });
  }

  public onGateMaterialChange(event: Event): void {
    const mat = (event.target as HTMLSelectElement).value as GateMaterial;
    let wf = 4.15;
    if (mat === 'p_poly') wf = 5.15;
    if (mat === 'midgap_metal') wf = 4.65;
    if (mat === 'custom_metal') wf = 4.50;
    this.lab.updateMaterials({
      gateMaterialType: mat,
      gateWorkfunction: wf,
    });
  }

  public onProfileTypeChange(event: Event): void {
    const p = (event.target as HTMLSelectElement).value as 'gaussian' | 'piecewise' | 'uniform';
    this.lab.updateDoping({ profileType: p });
  }

  public getLogDoping(dopingM3: number): number {
    return Math.log10(dopingM3 / 1e6); // convert m^-3 to cm^-3
  }

  public onSubstrateDopingChange(event: Event): void {
    const logVal = parseFloat((event.target as HTMLInputElement).value);
    const cm3 = Math.pow(10, logVal);
    this.lab.updateDoping({ substrateDoping: cm3 * 1e6 });
  }

  public onSourceDopingChange(event: Event): void {
    const logVal = parseFloat((event.target as HTMLInputElement).value);
    const cm3 = Math.pow(10, logVal);
    this.lab.updateDoping({ sourceDoping: cm3 * 1e6, drainDoping: cm3 * 1e6 });
  }
}
