/**
 * SILICAFLUX TRANSISTORLAB
 * 2D Non-Uniform Numerical Mesh Inspector Component
 * Project 41 — Device Physics and Transistor Simulation
 */

import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from '../core/services/transistor-lab';

@Component({
  selector: 'app-mesh-inspector',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full flex flex-col bg-[#0B182D] border border-[#1E3354] rounded-xl overflow-hidden shadow-2xl">
      <!-- Header -->
      <div class="px-4 py-3 bg-[#070F1E] border-b border-[#1E3354] flex items-center justify-between">
        <div class="flex items-center gap-2">
          <mat-icon class="text-[#1CCCE5] scale-90">grid_4x4</mat-icon>
          <span class="text-xs font-bold uppercase tracking-wider text-white">2D Finite-Difference / Finite-Volume Mesh</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[11px] font-mono text-[#D7AD59] bg-[#D7AD59]/10 px-2.5 py-0.5 rounded border border-[#D7AD59]/20">
            {{ lab.mesh().nx }}x{{ lab.mesh().ny }} Nodes ({{ lab.mesh().totalElements }} Elements)
          </span>
          <button
            (click)="lab.regenerateMesh()"
            class="px-2.5 py-1 text-xs bg-[#1E3354] hover:bg-[#1CCCE5] hover:text-[#070F1E] text-slate-200 rounded font-medium transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-xs scale-75">refresh</mat-icon>
            Refine Mesh
          </button>
        </div>
      </div>

      <!-- Mesh Canvas SVG -->
      <div class="flex-1 w-full p-4 flex flex-col items-center justify-center relative bg-[#070F1E]">
        <svg class="w-full h-full max-h-[380px]" viewBox="0 0 700 320" preserveAspectRatio="none">
          <!-- Background and domains -->
          <rect x="50" y="20" width="600" height="260" fill="#0E1E34" stroke="#1E3354" stroke-width="1.5" rx="4" />

          <!-- Oxide Domain Rectangle -->
          <rect
            x="50"
            y="20"
            width="600"
            [attr.height]="oxideHeightSvg()"
            fill="#0F384C"
            opacity="0.8"
          />

          <!-- Source Diffusion Domain -->
          <rect
            x="50"
            [attr.y]="20 + oxideHeightSvg()"
            [attr.width]="sourceWidthSvg()"
            [attr.height]="junctionHeightSvg()"
            fill="#1CCCE5"
            opacity="0.25"
          />

          <!-- Drain Diffusion Domain -->
          <rect
            [attr.x]="50 + 600 - drainWidthSvg()"
            [attr.y]="20 + oxideHeightSvg()"
            [attr.width]="drainWidthSvg()"
            [attr.height]="junctionHeightSvg()"
            fill="#1CCCE5"
            opacity="0.25"
          />

          <!-- Inversion Channel Highlight -->
          <rect
            [attr.x]="50 + sourceWidthSvg()"
            [attr.y]="20 + oxideHeightSvg()"
            [attr.width]="channelWidthSvg()"
            height="10"
            fill="#D7AD59"
            opacity="0.35"
          />

          <!-- Vertical Mesh Grid Lines x_i -->
          @for (xPos of meshXPositions(); track $index) {
            <line
              [attr.x1]="xPos"
              y1="20"
              [attr.x2]="xPos"
              y2="280"
              stroke="#1E3A5F"
              stroke-width="0.75"
            />
          }

          <!-- Horizontal Mesh Grid Lines y_j -->
          @for (yPos of meshYPositions(); track $index) {
            <line
              x1="50"
              [attr.y1]="yPos"
              x2="650"
              [attr.y2]="yPos"
              stroke="#1E3A5F"
              stroke-width="0.75"
            />
          }

          <!-- Interface Marker Line (y = Tox) -->
          <line
            x1="50"
            [attr.y1]="20 + oxideHeightSvg()"
            x2="650"
            [attr.y2]="20 + oxideHeightSvg()"
            stroke="#5EEAD4"
            stroke-width="2"
            stroke-dasharray="4,2"
          />

          <!-- Boundary Condition Contact Annotations -->
          <rect [attr.x]="50 + sourceWidthSvg() * 0.15" y="16" [attr.width]="sourceWidthSvg() * 0.7" height="6" fill="#9BAFC3" rx="1" />
          <text [attr.x]="50 + sourceWidthSvg() * 0.5" y="12" fill="#9BAFC3" font-size="9" font-family="monospace" text-anchor="middle">SOURCE CONTACT</text>

          <rect [attr.x]="50 + sourceWidthSvg() + channelWidthSvg() * 0.05" y="16" [attr.width]="channelWidthSvg() * 0.9" height="6" fill="#D7AD59" rx="1" />
          <text [attr.x]="50 + sourceWidthSvg() + channelWidthSvg() * 0.5" y="12" fill="#D7AD59" font-size="9" font-family="monospace" text-anchor="middle">GATE ELECTRODE</text>

          <rect [attr.x]="650 - drainWidthSvg() * 0.85" y="16" [attr.width]="drainWidthSvg() * 0.7" height="6" fill="#9BAFC3" rx="1" />
          <text [attr.x]="650 - drainWidthSvg() * 0.5" y="12" fill="#9BAFC3" font-size="9" font-family="monospace" text-anchor="middle">DRAIN CONTACT</text>

          <!-- Axes units -->
          <text x="50" y="300" fill="#9BAFC3" font-size="10" font-family="monospace">x = 0 nm</text>
          <text x="350" y="300" fill="#9BAFC3" font-size="10" font-family="monospace" text-anchor="middle">Lateral Coordinate x [nm]</text>
          <text x="650" y="300" fill="#9BAFC3" font-size="10" font-family="monospace" text-anchor="end">L_total = {{ (totalLength() * 1e9).toFixed(1) }} nm</text>
        </svg>
      </div>

      <!-- Quality Metrics Panel -->
      <div class="px-4 py-3 bg-[#070F1E] border-t border-[#1E3354] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div class="bg-[#0B182D] p-2.5 rounded-lg border border-[#1E3354]">
          <div class="text-[10px] text-slate-400">Min Cell &Delta;x</div>
          <div class="text-sm font-bold text-[#1CCCE5]">{{ (lab.mesh().dxMin * 1e9).toFixed(2) }} nm</div>
          <div class="text-[10px] text-slate-500">Channel Junctions</div>
        </div>

        <div class="bg-[#0B182D] p-2.5 rounded-lg border border-[#1E3354]">
          <div class="text-[10px] text-slate-400">Min Cell &Delta;y</div>
          <div class="text-sm font-bold text-[#5EEAD4]">{{ (lab.mesh().dyMin * 1e9).toFixed(2) }} nm</div>
          <div class="text-[10px] text-slate-500">Inversion Interface</div>
        </div>

        <div class="bg-[#0B182D] p-2.5 rounded-lg border border-[#1E3354]">
          <div class="text-[10px] text-slate-400">Max Aspect Ratio</div>
          <div class="text-sm font-bold text-[#D7AD59]">{{ lab.mesh().aspectRatioMax.toFixed(1) }}:1</div>
          <div class="text-[10px] text-slate-500">Bounded Delaunay</div>
        </div>

        <div class="bg-[#0B182D] p-2.5 rounded-lg border border-[#1E3354]">
          <div class="text-[10px] text-slate-400">Average Ratio</div>
          <div class="text-sm font-bold text-white">{{ lab.mesh().aspectRatioAvg.toFixed(1) }}:1</div>
          <div class="text-[10px] text-slate-500">Uniform Quality</div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class MeshInspector {
  protected readonly lab = inject(TransistorLab);

  public readonly totalLength = computed(() => {
    const geo = this.lab.geometry();
    return 2 * geo.sourceDrainLength + geo.gateLength;
  });

  public readonly totalDepth = computed(() => {
    const geo = this.lab.geometry();
    return geo.oxideThickness + geo.substrateDepth;
  });

  public readonly oxideHeightSvg = computed(() => {
    const geo = this.lab.geometry();
    const frac = geo.oxideThickness / this.totalDepth();
    return Math.max(16, frac * 260 * 3.5); // Enhanced visually
  });

  public readonly junctionHeightSvg = computed(() => {
    const geo = this.lab.geometry();
    const frac = geo.junctionDepth / this.totalDepth();
    return frac * 260 * 1.5;
  });

  public readonly sourceWidthSvg = computed(() => {
    const geo = this.lab.geometry();
    return (geo.sourceDrainLength / this.totalLength()) * 600;
  });

  public readonly channelWidthSvg = computed(() => {
    const geo = this.lab.geometry();
    return (geo.gateLength / this.totalLength()) * 600;
  });

  public readonly drainWidthSvg = computed(() => {
    const geo = this.lab.geometry();
    return (geo.sourceDrainLength / this.totalLength()) * 600;
  });

  public readonly meshXPositions = computed(() => {
    const m = this.lab.mesh();
    const Ltot = this.totalLength();
    return m.x.map(val => 50 + (val / Ltot) * 600);
  });

  public readonly meshYPositions = computed(() => {
    const m = this.lab.mesh();
    const Htot = this.totalDepth();
    return m.y.map(val => 20 + (val / Htot) * 260);
  });
}
