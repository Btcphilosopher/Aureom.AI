/**
 * SILICAFLUX TRANSISTORLAB
 * Interactive 3D Transistor Digital Twin Component
 * Project 41 — Device Physics and Transistor Simulation
 */

import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  effect,
  inject,
  viewChild,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from '../core/services/transistor-lab';
import { DisplayMode3D, Transistor3DScene } from '../core/renderer/transistor-3d-scene';

@Component({
  selector: 'app-transistor-3d-viewer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="relative w-full h-full flex flex-col bg-[#070F1E] border border-[#1E3354] rounded-xl overflow-hidden shadow-2xl">
      <!-- Top HUD Header -->
      <div class="absolute top-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <!-- View Mode Buttons -->
        <div class="pointer-events-auto flex items-center bg-[#0B182D]/90 backdrop-blur-md border border-[#1E3354] rounded-lg p-1 shadow-lg">
          <button
            (click)="setDisplayMode('physical')"
            class="px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="currentMode === 'physical'"
            [class.text-[#070F1E]]="currentMode === 'physical'"
            [class.font-semibold]="currentMode === 'physical'"
            [class.text-slate-300]="currentMode !== 'physical'"
            [class.hover:bg-[#1E3354]]="currentMode !== 'physical'"
            title="Physical Material Stack"
          >
            <mat-icon class="text-xs scale-75">layers</mat-icon>
            Physical
          </button>
          <button
            (click)="setDisplayMode('potential')"
            class="px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="currentMode === 'potential'"
            [class.text-[#070F1E]]="currentMode === 'potential'"
            [class.font-semibold]="currentMode === 'potential'"
            [class.text-slate-300]="currentMode !== 'potential'"
            [class.hover:bg-[#1E3354]]="currentMode !== 'potential'"
            title="Electrostatic Potential Field phi(x,y)"
          >
            <mat-icon class="text-xs scale-75">waves</mat-icon>
            Potential &phi;
          </button>
          <button
            (click)="setDisplayMode('electric_field')"
            class="px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="currentMode === 'electric_field'"
            [class.text-[#070F1E]]="currentMode === 'electric_field'"
            [class.font-semibold]="currentMode === 'electric_field'"
            [class.text-slate-300]="currentMode !== 'electric_field'"
            [class.hover:bg-[#1E3354]]="currentMode !== 'electric_field'"
            title="Electric Field Vector Lines E = -grad(phi)"
          >
            <mat-icon class="text-xs scale-75">arrow_forward</mat-icon>
            Field |E|
          </button>
          <button
            (click)="setDisplayMode('electron_density')"
            class="px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="currentMode === 'electron_density'"
            [class.text-[#070F1E]]="currentMode === 'electron_density'"
            [class.font-semibold]="currentMode === 'electron_density'"
            [class.text-slate-300]="currentMode !== 'electron_density'"
            [class.hover:bg-[#1E3354]]="currentMode !== 'electron_density'"
            title="Inversion Channel Electron Concentration n(x,y)"
          >
            <mat-icon class="text-xs scale-75">bubble_chart</mat-icon>
            Electrons n
          </button>
          <button
            (click)="setDisplayMode('current_density')"
            class="px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="currentMode === 'current_density'"
            [class.text-[#070F1E]]="currentMode === 'current_density'"
            [class.font-semibold]="currentMode === 'current_density'"
            [class.text-slate-300]="currentMode !== 'current_density'"
            [class.hover:bg-[#1E3354]]="currentMode !== 'current_density'"
            title="Current Flux Jx(x,y)"
          >
            <mat-icon class="text-xs scale-75">bolt</mat-icon>
            Current J
          </button>
        </div>

        <!-- Camera and View Actions -->
        <div class="pointer-events-auto flex items-center gap-1.5 bg-[#0B182D]/90 backdrop-blur-md border border-[#1E3354] rounded-lg p-1 shadow-lg">
          <button
            (click)="resetCamera()"
            class="px-2 py-1 text-xs text-slate-300 hover:text-white hover:bg-[#1E3354] rounded flex items-center gap-1 transition-colors cursor-pointer"
            title="Reset 3D Camera"
          >
            <mat-icon class="text-xs scale-75">restart_alt</mat-icon>
            Reset
          </button>
          <button
            (click)="toggleWireframe()"
            class="px-2 py-1 text-xs rounded flex items-center gap-1 transition-colors cursor-pointer"
            [class.bg-[#D7AD59]]="wireframeActive"
            [class.text-[#070F1E]]="wireframeActive"
            [class.text-slate-300]="!wireframeActive"
            [class.hover:bg-[#1E3354]]="!wireframeActive"
            title="Toggle Wireframe Mesh"
          >
            <mat-icon class="text-xs scale-75">grid_4x4</mat-icon>
            Wireframe
          </button>
        </div>
      </div>

      <!-- Three.js Canvas Container -->
      <div #canvasContainer class="w-full flex-1 relative cursor-grab active:cursor-grabbing"></div>

      <!-- Bottom Floating Controls Toolbar -->
      <div class="absolute bottom-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-3 bg-[#0B182D]/95 backdrop-blur-md border border-[#1E3354] px-4 py-2.5 rounded-xl shadow-2xl">
        <!-- Explode View Slider -->
        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400 font-mono flex items-center gap-1">
            <mat-icon class="text-xs scale-75 text-[#D7AD59]">open_in_full</mat-icon>
            Explode:
          </span>
          <input
            type="range"
            min="0"
            max="1"
            step="0.02"
            [value]="explodeValue"
            (input)="onExplodeChange($event)"
            class="w-24 h-1.5 bg-[#1E3354] rounded-lg appearance-none cursor-pointer"
          />
          <span class="font-mono text-[#D7AD59] w-8 text-right">{{ (explodeValue * 100).toFixed(0) }}%</span>
        </div>

        <!-- Cutaway Clipping Slider -->
        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400 font-mono flex items-center gap-1">
            <mat-icon class="text-xs scale-75 text-[#1CCCE5]">content_cut</mat-icon>
            Cutaway:
          </span>
          <input
            type="range"
            min="0.2"
            max="1.0"
            step="0.05"
            [value]="clipXValue"
            (input)="onClipChange($event)"
            class="w-24 h-1.5 bg-[#1E3354] rounded-lg appearance-none cursor-pointer"
          />
          <span class="font-mono text-[#1CCCE5] w-8 text-right">{{ (clipXValue * 100).toFixed(0) }}%</span>
        </div>

        <!-- Layer Toggles -->
        <div class="flex items-center gap-3 text-xs">
          <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer select-none">
            <input type="checkbox" [checked]="showGate" (change)="toggleLayer('gate', $event)" class="rounded text-[#D7AD59]" />
            Gate
          </label>
          <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer select-none">
            <input type="checkbox" [checked]="showDielectric" (change)="toggleLayer('dielectric', $event)" class="rounded text-[#5EEAD4]" />
            Oxide
          </label>
          <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer select-none">
            <input type="checkbox" [checked]="showDiffusions" (change)="toggleLayer('diffusions', $event)" class="rounded text-[#1CCCE5]" />
            S/D
          </label>
          <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer select-none">
            <input type="checkbox" [checked]="showContacts" (change)="toggleLayer('contacts', $event)" class="rounded text-[#9BAFC3]" />
            Contacts
          </label>
        </div>

        <!-- Geometry Badge -->
        <div class="text-[11px] font-mono text-[#9BAFC3] bg-[#070F1E] px-2.5 py-1 rounded border border-[#1E3354]">
          Lg = <span class="text-[#D7AD59] font-bold">{{ (lab.geometry().gateLength * 1e9).toFixed(0) }}nm</span> |
          Tox = <span class="text-[#1CCCE5] font-bold">{{ (lab.geometry().oxideThickness * 1e9).toFixed(1) }}nm</span> |
          W = <span class="text-white font-bold">{{ (lab.geometry().gateWidth * 1e6).toFixed(1) }}µm</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class Transistor3dViewer implements AfterViewInit, OnDestroy {
  protected readonly lab = inject(TransistorLab);
  private readonly canvasContainer = viewChild<ElementRef<HTMLElement>>('canvasContainer');

  private sceneEngine: Transistor3DScene | null = null;
  public currentMode: DisplayMode3D = 'physical';
  public explodeValue = 0;
  public clipXValue = 1.0;
  public wireframeActive = false;
  public showGate = true;
  public showDielectric = true;
  public showDiffusions = true;
  public showContacts = true;

  constructor() {
    // Automatically re-render 3D scene when geometry, solution, or polarity changes
    effect(() => {
      const geo = this.lab.geometry();
      const sol = this.lab.solution();
      const type = this.lab.transistorType();

      if (this.sceneEngine) {
        this.sceneEngine.updateDevice(geo, sol, type);
      }
    });
  }

  ngAfterViewInit(): void {
    const el = this.canvasContainer()?.nativeElement;
    if (el) {
      this.sceneEngine = new Transistor3DScene(el);
      this.sceneEngine.updateDevice(
        this.lab.geometry(),
        this.lab.solution(),
        this.lab.transistorType(),
        {
          displayMode: this.currentMode,
          explodeFactor: this.explodeValue,
          clipX: this.clipXValue,
          wireframe: this.wireframeActive,
        }
      );
    }
  }

  public setDisplayMode(mode: DisplayMode3D): void {
    this.currentMode = mode;
    this.sceneEngine?.setDisplayMode(mode);
  }

  public onExplodeChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.explodeValue = val;
    this.sceneEngine?.setExplode(val);
  }

  public onClipChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.clipXValue = val;
    this.sceneEngine?.setClipping(val, 1.0);
  }

  public toggleWireframe(): void {
    this.wireframeActive = !this.wireframeActive;
    if (this.sceneEngine) {
      this.sceneEngine.updateDevice(
        this.lab.geometry(),
        this.lab.solution(),
        this.lab.transistorType(),
        { wireframe: this.wireframeActive }
      );
    }
  }

  public toggleLayer(layer: 'gate' | 'dielectric' | 'diffusions' | 'contacts' | 'substrate', event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    switch (layer) {
      case 'gate': this.showGate = checked; break;
      case 'dielectric': this.showDielectric = checked; break;
      case 'diffusions': this.showDiffusions = checked; break;
      case 'contacts': this.showContacts = checked; break;
    }
    this.sceneEngine?.toggleLayer(layer, checked);
  }

  public resetCamera(): void {
    this.sceneEngine?.resetCamera();
  }

  ngOnDestroy(): void {
    this.sceneEngine?.destroy();
  }
}
