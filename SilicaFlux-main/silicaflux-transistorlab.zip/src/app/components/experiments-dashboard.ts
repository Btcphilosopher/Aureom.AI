/**
 * SILICAFLUX TRANSISTORLAB
 * Experiments, Benchmarks, and Scientific Engineering Reports Dashboard
 * Project 41 — Device Physics and Transistor Simulation
 */

import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from '../core/services/transistor-lab';
import { CANONICAL_EXPERIMENTS } from '../core/physics/experiments-data';
import { SpiceEngine } from '../core/physics/spice-engine';

@Component({
  selector: 'app-experiments-dashboard',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full flex flex-col bg-[#0B182D] border border-[#1E3354] rounded-xl overflow-hidden shadow-2xl text-slate-200">
      <!-- Section Header -->
      <div class="px-5 py-4 bg-[#070F1E] border-b border-[#1E3354] flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-lg bg-[#D7AD59]/10 border border-[#D7AD59]/30 flex items-center justify-center text-[#D7AD59]">
            <mat-icon class="scale-90">science</mat-icon>
          </div>
          <div>
            <h2 class="text-sm font-bold text-white uppercase tracking-wider">SilicaFlux Experiment Suite</h2>
            <p class="text-xs text-slate-400">Canonical CMOS Verification Benchmarks & Reproducible TCAD Reports</p>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="activeView.set('experiments')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="activeView() === 'experiments'"
            [class.text-[#070F1E]]="activeView() === 'experiments'"
            [class.font-semibold]="activeView() === 'experiments'"
            [class.text-slate-300]="activeView() !== 'experiments'"
            [class.hover:bg-[#1E3354]]="activeView() !== 'experiments'"
          >
            <mat-icon class="text-xs scale-75">biotech</mat-icon>
            Experiments
          </button>
          <button
            (click)="activeView.set('report')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#D7AD59]]="activeView() === 'report'"
            [class.text-[#070F1E]]="activeView() === 'report'"
            [class.font-semibold]="activeView() === 'report'"
            [class.text-slate-300]="activeView() !== 'report'"
            [class.hover:bg-[#1E3354]]="activeView() !== 'report'"
          >
            <mat-icon class="text-xs scale-75">description</mat-icon>
            Engineering Report
          </button>
          <button
            (click)="activeView.set('netlist')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#814DD1]]="activeView() === 'netlist'"
            [class.text-white]="activeView() === 'netlist'"
            [class.font-semibold]="activeView() === 'netlist'"
            [class.text-slate-300]="activeView() !== 'netlist'"
            [class.hover:bg-[#1E3354]]="activeView() !== 'netlist'"
          >
            <mat-icon class="text-xs scale-75">code</mat-icon>
            SPICE Netlist
          </button>
        </div>
      </div>

      <!-- Main Body Content -->
      <div class="flex-1 overflow-y-auto p-5">
        @if (activeView() === 'experiments') {
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              @for (exp of canonicalExperiments; track exp.id) {
                <div
                  class="bg-[#070F1E] border rounded-xl p-4 flex flex-col justify-between transition-all"
                  [class.border-[#1CCCE5]]="lab.activeExperiment()?.id === exp.id"
                  [class.shadow-lg]="lab.activeExperiment()?.id === exp.id"
                  [class.border-[#1E3354]]="lab.activeExperiment()?.id !== exp.id"
                >
                  <div>
                    <div class="flex items-center justify-between mb-2">
                      <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-[#D7AD59]/10 text-[#D7AD59] border border-[#D7AD59]/20 font-bold">
                        {{ exp.code }}
                      </span>
                      <span class="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        VERIFIED
                      </span>
                    </div>

                    <h3 class="text-sm font-bold text-white mb-1.5">{{ exp.title }}</h3>
                    <p class="text-xs text-slate-400 leading-relaxed mb-3">{{ exp.description }}</p>

                    <!-- Bias Condition Tags -->
                    <div class="bg-[#0B182D] rounded-lg p-2 font-mono text-[11px] text-slate-300 space-y-1 mb-3 border border-[#1E3354]">
                      <div class="flex justify-between">
                        <span class="text-slate-500">Target Bias:</span>
                        <span class="text-[#1CCCE5]">Vgs={{ exp.operatingBiases.vgs }}V Vds={{ exp.operatingBiases.vds }}V</span>
                      </div>
                      <div class="flex justify-between">
                        <span class="text-slate-500">Geometry:</span>
                        <span class="text-[#D7AD59]">Lg={{ exp.geometry.gateLength * 1e9 }}nm Tox={{ exp.geometry.oxideThickness * 1e9 }}nm</span>
                      </div>
                    </div>

                    <!-- Expected physical behavior note -->
                    <div class="text-[11px] text-slate-400 italic mb-4">
                      "{{ exp.expectedBehavior }}"
                    </div>
                  </div>

                  <!-- Actions -->
                  <div class="pt-2 border-t border-[#1E3354] flex items-center justify-between gap-2">
                    <span class="text-[10px] font-mono text-slate-500">CLI: {{ getCliCommand(exp.id) }}</span>
                    <button
                      (click)="lab.loadExperiment(exp.id)"
                      class="px-3 py-1.5 bg-[#1CCCE5] hover:bg-[#1CCCE5]/90 text-[#070F1E] font-bold text-xs rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <mat-icon class="text-xs scale-75">play_arrow</mat-icon>
                      Run Now
                    </button>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        @if (activeView() === 'report') {
          <div class="space-y-4 max-w-4xl mx-auto">
            <div class="flex items-center justify-between bg-[#070F1E] border border-[#1E3354] p-3 rounded-xl">
              <span class="text-xs text-slate-300">Generated Engineering Report (Ready for Publication / Signoff)</span>
              <div class="flex items-center gap-2">
                <button
                  (click)="copyReport()"
                  class="px-3 py-1 text-xs bg-[#1E3354] hover:bg-[#1CCCE5] hover:text-[#070F1E] text-slate-200 rounded font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <mat-icon class="text-xs scale-75">{{ copied() ? 'check' : 'content_copy' }}</mat-icon>
                  {{ copied() ? 'Copied!' : 'Copy Markdown' }}
                </button>
                <button
                  (click)="downloadJson()"
                  class="px-3 py-1 text-xs bg-[#1E3354] hover:bg-[#D7AD59] hover:text-[#070F1E] text-slate-200 rounded font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <mat-icon class="text-xs scale-75">download</mat-icon>
                  Export JSON
                </button>
              </div>
            </div>

            <pre class="bg-[#070F1E] border border-[#1E3354] rounded-xl p-5 font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto whitespace-pre-wrap select-text">{{ reportText() }}</pre>
          </div>
        }

        @if (activeView() === 'netlist') {
          <div class="space-y-4 max-w-3xl mx-auto">
            <div class="flex items-center justify-between bg-[#070F1E] border border-[#1E3354] p-3 rounded-xl">
              <span class="text-xs text-slate-300">ngspice Validated Circuit Netlist (.sp)</span>
              <button
                (click)="copyNetlist()"
                class="px-3 py-1 text-xs bg-[#1E3354] hover:bg-[#D7AD59] hover:text-[#070F1E] text-slate-200 rounded font-semibold transition-colors flex items-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-xs scale-75">content_copy</mat-icon>
                Copy Netlist
              </button>
            </div>

            <pre class="bg-[#070F1E] border border-[#1E3354] rounded-xl p-5 font-mono text-xs text-[#1CCCE5] leading-relaxed overflow-x-auto whitespace-pre select-text">{{ netlistText() }}</pre>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class ExperimentsDashboard {
  protected readonly lab = inject(TransistorLab);

  public readonly activeView = signal<'experiments' | 'report' | 'netlist'>('experiments');
  public readonly canonicalExperiments = CANONICAL_EXPERIMENTS;
  public readonly copied = signal<boolean>(false);

  public readonly reportText = computed(() => {
    return this.lab.generateEngineeringReport();
  });

  public readonly netlistText = computed(() => {
    const geo = this.lab.geometry();
    const params = this.lab.derivedSpiceParams();
    const biases = this.lab.biases();
    return SpiceEngine.generateNgspiceNetlist(geo, params, biases, this.lab.transistorType());
  });

  public getCliCommand(expId: string): string {
    switch (expId) {
      case 'exp-a-equilibrium': return 'transistorlab solve equilibrium';
      case 'exp-b-vgs-sweep': return 'transistorlab sweep id-vgs';
      case 'exp-c-vds-family': return 'transistorlab sweep id-vds';
      case 'exp-d-temperature': return 'transistorlab solve temperature';
      case 'exp-e-spice-benchmark': return 'transistorlab spice compare';
      default: return 'transistorlab run';
    }
  }

  public copyReport(): void {
    navigator.clipboard.writeText(this.reportText());
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 2000);
  }

  public copyNetlist(): void {
    navigator.clipboard.writeText(this.netlistText());
  }

  public downloadJson(): void {
    const data = {
      device: this.lab.transistorType(),
      geometry: this.lab.geometry(),
      materials: this.lab.materials(),
      doping: this.lab.doping(),
      biases: this.lab.biases(),
      solution: {
        drainCurrent: this.lab.solution()?.drainCurrent,
        sourceCurrent: this.lab.solution()?.sourceCurrent,
        iterations: this.lab.solution()?.iterations,
        residualNorm: this.lab.solution()?.residualNorm,
      },
      metrics: this.lab.extractedMetrics(),
      spiceModel: this.lab.derivedSpiceParams(),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `silicaflux_${this.lab.transistorType()}_tcad_dataset.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
