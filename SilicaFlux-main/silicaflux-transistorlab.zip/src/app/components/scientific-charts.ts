/**
 * SILICAFLUX TRANSISTORLAB
 * High-Precision Scientific Charting Workspace
 * Project 41 — Device Physics and Transistor Simulation
 */

import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from '../core/services/transistor-lab';

type ChartTab = 'id_vgs' | 'id_vds' | 'gm' | 'band_diagram' | 'spice_compare';

@Component({
  selector: 'app-scientific-charts',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full flex flex-col bg-[#0B182D] border border-[#1E3354] rounded-xl overflow-hidden shadow-2xl">
      <!-- Tabs Header -->
      <div class="flex items-center justify-between px-3 py-2 bg-[#070F1E] border-b border-[#1E3354]">
        <div class="flex items-center gap-1">
          <button
            (click)="activeTab.set('id_vgs')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="activeTab() === 'id_vgs'"
            [class.text-[#070F1E]]="activeTab() === 'id_vgs'"
            [class.font-semibold]="activeTab() === 'id_vgs'"
            [class.text-slate-300]="activeTab() !== 'id_vgs'"
            [class.hover:bg-[#1E3354]]="activeTab() !== 'id_vgs'"
          >
            <mat-icon class="text-xs scale-75">show_chart</mat-icon>
            Id-Vgs Transfer
          </button>
          <button
            (click)="activeTab.set('id_vds')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="activeTab() === 'id_vds'"
            [class.text-[#070F1E]]="activeTab() === 'id_vds'"
            [class.font-semibold]="activeTab() === 'id_vds'"
            [class.text-slate-300]="activeTab() !== 'id_vds'"
            [class.hover:bg-[#1E3354]]="activeTab() !== 'id_vds'"
          >
            <mat-icon class="text-xs scale-75">stacked_line_chart</mat-icon>
            Id-Vds Family
          </button>
          <button
            (click)="activeTab.set('gm')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="activeTab() === 'gm'"
            [class.text-[#070F1E]]="activeTab() === 'gm'"
            [class.font-semibold]="activeTab() === 'gm'"
            [class.text-slate-300]="activeTab() !== 'gm'"
            [class.hover:bg-[#1E3354]]="activeTab() !== 'gm'"
          >
            <mat-icon class="text-xs scale-75">trending_up</mat-icon>
            Transconductance gm
          </button>
          <button
            (click)="activeTab.set('band_diagram')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="activeTab() === 'band_diagram'"
            [class.text-[#070F1E]]="activeTab() === 'band_diagram'"
            [class.font-semibold]="activeTab() === 'band_diagram'"
            [class.text-slate-300]="activeTab() !== 'band_diagram'"
            [class.hover:bg-[#1E3354]]="activeTab() !== 'band_diagram'"
          >
            <mat-icon class="text-xs scale-75">reorder</mat-icon>
            Band Diagram (Ec/Ev)
          </button>
          <button
            (click)="activeTab.set('spice_compare')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#D7AD59]]="activeTab() === 'spice_compare'"
            [class.text-[#070F1E]]="activeTab() === 'spice_compare'"
            [class.font-semibold]="activeTab() === 'spice_compare'"
            [class.text-slate-300]="activeTab() !== 'spice_compare'"
            [class.hover:bg-[#1E3354]]="activeTab() !== 'spice_compare'"
          >
            <mat-icon class="text-xs scale-75">compare_arrows</mat-icon>
            TCAD vs SPICE Benchmark
          </button>
        </div>

        <!-- Chart Controls -->
        <div class="flex items-center gap-2">
          @if (activeTab() === 'id_vgs') {
            <div class="flex items-center bg-[#0B182D] border border-[#1E3354] rounded-lg p-0.5 text-xs">
              <button
                (click)="isLogScale.set(false)"
                class="px-2 py-0.5 rounded cursor-pointer transition-colors"
                [class.bg-[#1CCCE5]]="!isLogScale()"
                [class.text-[#070F1E]]="!isLogScale()"
                [class.font-bold]="!isLogScale()"
                [class.text-slate-400]="isLogScale()"
              >
                Linear
              </button>
              <button
                (click)="isLogScale.set(true)"
                class="px-2 py-0.5 rounded cursor-pointer transition-colors"
                [class.bg-[#1CCCE5]]="isLogScale()"
                [class.text-[#070F1E]]="isLogScale()"
                [class.font-bold]="isLogScale()"
                [class.text-slate-400]="!isLogScale()"
              >
                Log10
              </button>
            </div>
          }

          <label class="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              [checked]="showSpiceOverlay()"
              (change)="showSpiceOverlay.set(!showSpiceOverlay())"
              class="rounded text-[#D7AD59]"
            />
            <span class="text-[#D7AD59]">SPICE Overlay</span>
          </label>
        </div>
      </div>

      <!-- Main Chart SVG Drawing Area -->
      <div class="flex-1 w-full relative p-3 flex flex-col justify-center items-center">
        @switch (activeTab()) {
          @case ('id_vgs') {
            <svg class="w-full h-full min-h-[220px]" viewBox="0 0 680 260" preserveAspectRatio="none">
              <!-- Grid background -->
              <rect x="60" y="20" width="580" height="200" fill="#070F1E" stroke="#1E3354" stroke-width="1" rx="4" />
              <!-- Horizontal grid lines -->
              @for (tick of [0.25, 0.5, 0.75, 1.0]; track tick) {
                <line
                  x1="60"
                  [attr.y1]="220 - tick * 200"
                  x2="640"
                  [attr.y2]="220 - tick * 200"
                  stroke="#162740"
                  stroke-dasharray="3,3"
                />
              }
              <!-- Vertical grid lines -->
              @for (tick of [0.2, 0.4, 0.6, 0.8, 1.0]; track tick) {
                <line
                  [attr.x1]="60 + tick * 580"
                  y1="20"
                  [attr.x2]="60 + tick * 580"
                  y2="220"
                  stroke="#162740"
                  stroke-dasharray="3,3"
                />
              }

              <!-- Render TCAD Curves -->
              @if (transferCurveSat()) {
                <path
                  [attr.d]="transferCurveSat()"
                  fill="none"
                  stroke="#1CCCE5"
                  stroke-width="2.5"
                />
              }
              @if (transferCurveLin()) {
                <path
                  [attr.d]="transferCurveLin()"
                  fill="none"
                  stroke="#38BDF8"
                  stroke-width="1.8"
                  stroke-dasharray="4,2"
                />
              }

              <!-- Render SPICE Curves if enabled -->
              @if (showSpiceOverlay() && spiceCurveSat()) {
                <path
                  [attr.d]="spiceCurveSat()"
                  fill="none"
                  stroke="#D7AD59"
                  stroke-width="2"
                  stroke-dasharray="5,3"
                />
              }

              <!-- Axes labels and values -->
              <text x="60" y="245" fill="#9BAFC3" font-size="11" font-family="monospace">0.0V</text>
              <text x="350" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="middle">Gate Voltage Vgs [V]</text>
              <text x="640" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="end">1.2V</text>

              <text x="15" y="25" fill="#9BAFC3" font-size="10" font-family="monospace">{{ isLogScale() ? '10⁻³' : maxTransferCurrentFormatted() }}</text>
              <text x="15" y="125" fill="#9BAFC3" font-size="10" font-family="monospace">{{ isLogScale() ? '10⁻⁸' : 'Mid' }}</text>
              <text x="15" y="225" fill="#9BAFC3" font-size="10" font-family="monospace">{{ isLogScale() ? '10⁻¹⁴' : '0.0' }}</text>
            </svg>
          }

          @case ('id_vds') {
            <svg class="w-full h-full min-h-[220px]" viewBox="0 0 680 260" preserveAspectRatio="none">
              <rect x="60" y="20" width="580" height="200" fill="#070F1E" stroke="#1E3354" stroke-width="1" rx="4" />
              @for (tick of [0.25, 0.5, 0.75, 1.0]; track tick) {
                <line x1="60" [attr.y1]="220 - tick * 200" x2="640" [attr.y2]="220 - tick * 200" stroke="#162740" stroke-dasharray="3,3" />
              }
              @for (tick of [0.2, 0.4, 0.6, 0.8, 1.0]; track tick) {
                <line [attr.x1]="60 + tick * 580" y1="20" [attr.x2]="60 + tick * 580" y2="220" stroke="#162740" stroke-dasharray="3,3" />
              }

              <!-- Family of curves -->
              @for (curve of outputCurvesSvg(); track curve.name) {
                <path [attr.d]="curve.path" fill="none" [attr.stroke]="curve.color" stroke-width="2" />
                @if (showSpiceOverlay() && curve.spicePath) {
                  <path [attr.d]="curve.spicePath" fill="none" stroke="#D7AD59" stroke-width="1.5" stroke-dasharray="4,3" />
                }
              }

              <text x="60" y="245" fill="#9BAFC3" font-size="11" font-family="monospace">0.0V</text>
              <text x="350" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="middle">Drain-to-Source Voltage Vds [V]</text>
              <text x="640" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="end">1.2V</text>
              <text x="15" y="25" fill="#9BAFC3" font-size="10" font-family="monospace">{{ maxOutputCurrentFormatted() }}</text>
              <text x="15" y="225" fill="#9BAFC3" font-size="10" font-family="monospace">0 A</text>
            </svg>
          }

          @case ('gm') {
            <svg class="w-full h-full min-h-[220px]" viewBox="0 0 680 260" preserveAspectRatio="none">
              <rect x="60" y="20" width="580" height="200" fill="#070F1E" stroke="#1E3354" stroke-width="1" rx="4" />
              @for (tick of [0.25, 0.5, 0.75, 1.0]; track tick) {
                <line x1="60" [attr.y1]="220 - tick * 200" x2="640" [attr.y2]="220 - tick * 200" stroke="#162740" stroke-dasharray="3,3" />
              }

              @if (gmCurveSvg()) {
                <path [attr.d]="gmCurveSvg()" fill="none" stroke="#814DD1" stroke-width="2.5" />
              }

              <text x="60" y="245" fill="#9BAFC3" font-size="11" font-family="monospace">0.0V</text>
              <text x="350" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="middle">Vgs [V] (Peak gm = {{ (lab.extractedMetrics()?.gmNormalized || 0).toFixed(0) }} mS/µm)</text>
              <text x="640" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="end">1.2V</text>
              <text x="15" y="25" fill="#9BAFC3" font-size="10" font-family="monospace">Peak</text>
              <text x="15" y="225" fill="#9BAFC3" font-size="10" font-family="monospace">0</text>
            </svg>
          }

          @case ('band_diagram') {
            <svg class="w-full h-full min-h-[220px]" viewBox="0 0 680 260" preserveAspectRatio="none">
              <rect x="60" y="20" width="580" height="200" fill="#070F1E" stroke="#1E3354" stroke-width="1" rx="4" />
              <!-- Oxide barrier rectangle -->
              <rect x="60" y="20" width="100" height="200" fill="#0E233E" opacity="0.6" />
              <text x="110" y="40" fill="#5EEAD4" font-size="10" font-family="monospace" text-anchor="middle">SiO2 (Tox)</text>
              <text x="360" y="40" fill="#9BAFC3" font-size="10" font-family="monospace" text-anchor="middle">Silicon Substrate Bulk</text>

              <!-- Conduction band Ec -->
              <path [attr.d]="bandEcPath()" fill="none" stroke="#1CCCE5" stroke-width="2.5" />
              <text x="635" y="85" fill="#1CCCE5" font-size="11" font-family="monospace">Ec</text>

              <!-- Fermi level Ef -->
              <line x1="60" y1="130" x2="640" y2="130" stroke="#D7AD59" stroke-width="1.5" stroke-dasharray="5,3" />
              <text x="635" y="134" fill="#D7AD59" font-size="11" font-family="monospace">Ef</text>

              <!-- Valence band Ev -->
              <path [attr.d]="bandEvPath()" fill="none" stroke="#814DD1" stroke-width="2.5" />
              <text x="635" y="185" fill="#814DD1" font-size="11" font-family="monospace">Ev</text>

              <text x="60" y="245" fill="#9BAFC3" font-size="11" font-family="monospace">y = 0 (Gate)</text>
              <text x="160" y="245" fill="#5EEAD4" font-size="11" font-family="monospace">Interface</text>
              <text x="350" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="middle">Vertical Depth into Device [nm]</text>
              <text x="640" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="end">Substrate Depth</text>
            </svg>
          }

          @case ('spice_compare') {
            <svg class="w-full h-full min-h-[220px]" viewBox="0 0 680 260" preserveAspectRatio="none">
              <rect x="60" y="20" width="580" height="200" fill="#070F1E" stroke="#1E3354" stroke-width="1" rx="4" />
              <!-- Zero delta center line -->
              <line x1="60" y1="120" x2="640" y2="120" stroke="#1E3354" stroke-width="1.5" />

              <!-- Delta error path -->
              @if (spiceDeltaPath()) {
                <path [attr.d]="spiceDeltaPath()" fill="none" stroke="#D7AD59" stroke-width="2" />
              }

              <text x="60" y="245" fill="#9BAFC3" font-size="11" font-family="monospace">0.0V</text>
              <text x="350" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="middle">Vgs [V] — Percentage Discrepancy (TCAD vs SPICE Level 3)</text>
              <text x="640" y="245" fill="#9BAFC3" font-size="11" font-family="monospace" text-anchor="end">1.2V</text>
              <text x="15" y="25" fill="#D7AD59" font-size="10" font-family="monospace">+10%</text>
              <text x="15" y="125" fill="#9BAFC3" font-size="10" font-family="monospace">0%</text>
              <text x="15" y="225" fill="#D7AD59" font-size="10" font-family="monospace">-10%</text>
            </svg>
          }
        }
      </div>

      <!-- Bottom Legend -->
      <div class="px-4 py-2 bg-[#070F1E] border-t border-[#1E3354] flex items-center justify-between text-xs text-slate-400 font-mono">
        <div class="flex items-center gap-4">
          <div class="flex items-center gap-1.5">
            <span class="w-3 h-1 bg-[#1CCCE5] inline-block rounded"></span>
            <span>2D TCAD Solution</span>
          </div>
          @if (showSpiceOverlay()) {
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 bg-[#D7AD59] inline-block rounded"></span>
              <span>SPICE Level 3 Model</span>
            </div>
          }
        </div>

        <div class="flex items-center gap-3 text-[11px]">
          <span>Vth = <strong class="text-[#1CCCE5]">{{ (lab.extractedMetrics()?.vthLinear || 0).toFixed(3) }}V</strong></span>
          <span>SS = <strong class="text-[#D7AD59]">{{ (lab.extractedMetrics()?.subthresholdSwing || 0).toFixed(1) }} mV/dec</strong></span>
          <span>DIBL = <strong class="text-emerald-400">{{ (lab.extractedMetrics()?.dibl || 0).toFixed(1) }} mV/V</strong></span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class ScientificCharts {
  protected readonly lab = inject(TransistorLab);

  public readonly activeTab = signal<ChartTab>('id_vgs');
  public readonly isLogScale = signal<boolean>(false);
  public readonly showSpiceOverlay = signal<boolean>(true);

  public readonly maxTransferCurrentFormatted = computed(() => {
    const sw = this.lab.transferSweep();
    if (!sw || !sw.curves[1]) return '1.0 mA';
    const maxVal = Math.max(...sw.curves[1].currentValues);
    return `${(maxVal * 1e3).toFixed(2)} mA`;
  });

  public readonly maxOutputCurrentFormatted = computed(() => {
    const sw = this.lab.outputSweep();
    if (!sw || sw.curves.length === 0) return '1.2 mA';
    const topCurve = sw.curves[sw.curves.length - 1];
    const maxVal = Math.max(...topCurve.currentValues);
    return `${(maxVal * 1e3).toFixed(2)} mA`;
  });

  public readonly transferCurveSat = computed(() => {
    const sw = this.lab.transferSweep();
    if (!sw || !sw.curves[1]) return '';
    return this.buildSvgPath(sw.curves[1].sweepValues, sw.curves[1].currentValues, this.isLogScale());
  });

  public readonly transferCurveLin = computed(() => {
    const sw = this.lab.transferSweep();
    if (!sw || !sw.curves[0]) return '';
    return this.buildSvgPath(sw.curves[0].sweepValues, sw.curves[0].currentValues, this.isLogScale());
  });

  public readonly spiceCurveSat = computed(() => {
    const sw = this.lab.transferSweep();
    if (!sw || !sw.curves[1] || !sw.curves[1].spiceCurrents) return '';
    return this.buildSvgPath(sw.curves[1].sweepValues, sw.curves[1].spiceCurrents, this.isLogScale());
  });

  public readonly outputCurvesSvg = computed(() => {
    const sw = this.lab.outputSweep();
    if (!sw) return [];

    const colors = ['#38BDF8', '#1CCCE5', '#34D399', '#D7AD59', '#F43F5E'];
    const maxI = Math.max(...sw.curves[sw.curves.length - 1].currentValues, 1e-4);

    return sw.curves.map((curve, idx) => {
      const path = this.buildLinearSvgPath(curve.sweepValues, curve.currentValues, 0, 1.2, 0, maxI);
      const spicePath = curve.spiceCurrents
        ? this.buildLinearSvgPath(curve.sweepValues, curve.spiceCurrents, 0, 1.2, 0, maxI)
        : '';

      return {
        name: curve.name,
        color: colors[idx % colors.length],
        path,
        spicePath,
      };
    });
  });

  public readonly gmCurveSvg = computed(() => {
    const sw = this.lab.transferSweep();
    if (!sw || !sw.curves[1] || !sw.curves[1].transconductanceValues) return '';
    const gmVals = sw.curves[1].transconductanceValues;
    const maxGm = Math.max(...gmVals, 1e-6);
    return this.buildLinearSvgPath(sw.curves[1].sweepValues, gmVals, 0, 1.2, 0, maxGm);
  });

  public readonly bandEcPath = computed(() => {
    // Generates vertical conduction band curve Ec(y) showing oxide barrier and surface bending
    const vgs = this.lab.biases().vgs;
    const points: string[] = [];
    for (let i = 0; i <= 50; i++) {
      const frac = i / 50;
      const x = 60 + frac * 580;
      let energy = 0;
      if (frac < 0.17) {
        // In oxide barrier
        energy = 3.1 - (vgs * 0.4) * (1 - frac / 0.17);
      } else {
        // In silicon substrate: band bending near interface
        const depthFrac = (frac - 0.17) / 0.83;
        energy = 1.12 - (vgs * 0.5) * Math.exp(-depthFrac * 4.0);
      }
      const y = 140 - energy * 30;
      points.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  });

  public readonly bandEvPath = computed(() => {
    const vgs = this.lab.biases().vgs;
    const points: string[] = [];
    for (let i = 0; i <= 50; i++) {
      const frac = i / 50;
      const x = 60 + frac * 580;
      let energy = 0;
      if (frac < 0.17) {
        energy = -4.5 + (vgs * 0.2) * (1 - frac / 0.17);
      } else {
        const depthFrac = (frac - 0.17) / 0.83;
        energy = 0.0 - (vgs * 0.5) * Math.exp(-depthFrac * 4.0);
      }
      const y = 140 - energy * 30;
      points.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  });

  public readonly spiceDeltaPath = computed(() => {
    const sw = this.lab.transferSweep();
    if (!sw || !sw.curves[1] || !sw.curves[1].spiceCurrents) return '';
    const tcad = sw.curves[1].currentValues;
    const spice = sw.curves[1].spiceCurrents;
    const xVals = sw.curves[1].sweepValues;

    const points: string[] = [];
    for (let i = 0; i < tcad.length; i++) {
      const x = 60 + (xVals[i] / 1.2) * 580;
      const relErrorPercent = tcad[i] > 1e-10 ? ((tcad[i] - spice[i]) / tcad[i]) * 100 : 0;
      const clampedRel = Math.max(-10, Math.min(10, relErrorPercent));
      const y = 120 - (clampedRel / 10.0) * 100;
      points.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  });

  private buildSvgPath(xVals: number[], yVals: number[], logScale: boolean): string {
    if (xVals.length === 0) return '';
    const points: string[] = [];

    const maxY = Math.max(...yVals, 1e-4);

    for (let i = 0; i < xVals.length; i++) {
      const x = 60 + (xVals[i] / 1.2) * 580;
      let yNorm = 0;

      if (logScale) {
        const logVal = Math.log10(Math.max(1e-14, yVals[i]));
        // Range from 10^-14 to 10^-3
        yNorm = (logVal - (-14)) / 11.0;
      } else {
        yNorm = yVals[i] / maxY;
      }

      yNorm = Math.max(0, Math.min(1, yNorm));
      const y = 220 - yNorm * 200;
      points.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }

    return points.join(' ');
  }

  private buildLinearSvgPath(
    xVals: number[],
    yVals: number[],
    minX: number,
    maxX: number,
    minY: number,
    maxY: number
  ): string {
    const points: string[] = [];
    const spanX = maxX - minX || 1;
    const spanY = maxY - minY || 1;

    for (let i = 0; i < xVals.length; i++) {
      const x = 60 + ((xVals[i] - minX) / spanX) * 580;
      const yNorm = Math.max(0, Math.min(1, (yVals[i] - minY) / spanY));
      const y = 220 - yNorm * 200;
      points.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }

    return points.join(' ');
  }
}
