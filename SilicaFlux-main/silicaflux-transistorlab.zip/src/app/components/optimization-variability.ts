/**
 * SILICAFLUX TRANSISTORLAB
 * Device Parameter Optimization & Variability Analysis
 * Project 41 — Device Physics and Transistor Simulation
 */

import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from '../core/services/transistor-lab';
import { OptimizationGoal, OptimizationResult } from '../core/models/device.types';

@Component({
  selector: 'app-optimization-variability',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full flex flex-col bg-[#0B182D] border border-[#1E3354] rounded-xl overflow-hidden shadow-2xl text-slate-200">
      <!-- Section Header -->
      <div class="px-5 py-4 bg-[#070F1E] border-b border-[#1E3354] flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-lg bg-[#814DD1]/10 border border-[#814DD1]/30 flex items-center justify-center text-[#814DD1]">
            <mat-icon class="scale-90">auto_fix_high</mat-icon>
          </div>
          <div>
            <h2 class="text-sm font-bold text-white uppercase tracking-wider">Device Optimization & Variability Analysis</h2>
            <p class="text-xs text-slate-400">Constrained Multi-Objective Pareto Optimization & Statistical Monte Carlo Sensitivity</p>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="activeSection.set('optimization')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#1CCCE5]]="activeSection() === 'optimization'"
            [class.text-[#070F1E]]="activeSection() === 'optimization'"
            [class.font-semibold]="activeSection() === 'optimization'"
            [class.text-slate-300]="activeSection() !== 'optimization'"
            [class.hover:bg-[#1E3354]]="activeSection() !== 'optimization'"
          >
            <mat-icon class="text-xs scale-75">insights</mat-icon>
            Pareto Optimization
          </button>
          <button
            (click)="activeSection.set('variability')"
            class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            [class.bg-[#D7AD59]]="activeSection() === 'variability'"
            [class.text-[#070F1E]]="activeSection() === 'variability'"
            [class.font-semibold]="activeSection() === 'variability'"
            [class.text-slate-300]="activeSection() !== 'variability'"
            [class.hover:bg-[#1E3354]]="activeSection() !== 'variability'"
          >
            <mat-icon class="text-xs scale-75">casino</mat-icon>
            Monte Carlo Variability
          </button>
        </div>
      </div>

      <div class="flex-1 overflow-y-auto p-5">
        @if (activeSection() === 'optimization') {
          <div class="space-y-5 max-w-4xl mx-auto">
            <!-- Goal Configuration -->
            <div class="bg-[#070F1E] border border-[#1E3354] rounded-xl p-4 space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 class="text-xs font-bold text-white uppercase tracking-wider">Primary Objective Function</h3>
                  <p class="text-xs text-slate-400">Select target figure-of-merit for numerical gradient search</p>
                </div>
                <button
                  (click)="runOptimization()"
                  [disabled]="isOptimizing()"
                  class="px-4 py-2 bg-gradient-to-r from-[#1CCCE5] to-[#814DD1] text-[#070F1E] font-bold text-xs rounded-lg shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <mat-icon class="text-xs scale-75" [class.animate-spin]="isOptimizing()">
                    {{ isOptimizing() ? 'sync' : 'search' }}
                  </mat-icon>
                  <span>{{ isOptimizing() ? 'Computing Pareto Front...' : 'Run Optimization' }}</span>
                </button>
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  (click)="selectedTarget.set('maximize_ion_ioff')"
                  class="p-3 rounded-lg border text-left transition-colors cursor-pointer"
                  [class.bg-[#1E3354]]="selectedTarget() === 'maximize_ion_ioff'"
                  [class.border-[#1CCCE5]]="selectedTarget() === 'maximize_ion_ioff'"
                  [class.bg-[#0B182D]]="selectedTarget() !== 'maximize_ion_ioff'"
                  [class.border-[#1E3354]]="selectedTarget() !== 'maximize_ion_ioff'"
                >
                  <div class="font-bold text-xs text-white">Maximize Ion / Ioff</div>
                  <div class="text-[11px] text-slate-400 mt-1">Balanced performance & leakage</div>
                </button>

                <button
                  (click)="selectedTarget.set('maximize_ion')"
                  class="p-3 rounded-lg border text-left transition-colors cursor-pointer"
                  [class.bg-[#1E3354]]="selectedTarget() === 'maximize_ion'"
                  [class.border-[#1CCCE5]]="selectedTarget() === 'maximize_ion'"
                  [class.bg-[#0B182D]]="selectedTarget() !== 'maximize_ion'"
                  [class.border-[#1E3354]]="selectedTarget() !== 'maximize_ion'"
                >
                  <div class="font-bold text-xs text-[#1CCCE5]">Maximize Drive Ion</div>
                  <div class="text-[11px] text-slate-400 mt-1">High-performance computing (HPC)</div>
                </button>

                <button
                  (click)="selectedTarget.set('minimize_ioff')"
                  class="p-3 rounded-lg border text-left transition-colors cursor-pointer"
                  [class.bg-[#1E3354]]="selectedTarget() === 'minimize_ioff'"
                  [class.border-[#1CCCE5]]="selectedTarget() === 'minimize_ioff'"
                  [class.bg-[#0B182D]]="selectedTarget() !== 'minimize_ioff'"
                  [class.border-[#1E3354]]="selectedTarget() !== 'minimize_ioff'"
                >
                  <div class="font-bold text-xs text-[#D7AD59]">Minimize Leakage Ioff</div>
                  <div class="text-[11px] text-slate-400 mt-1">Ultra-low power mobile / IoT</div>
                </button>
              </div>
            </div>

            <!-- Optimization Results & Pareto Table -->
            @if (lab.optimizationResult(); as res) {
              <div class="bg-[#070F1E] border border-[#1E3354] rounded-xl p-4 space-y-4">
                <div class="flex items-center justify-between">
                  <h3 class="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <mat-icon class="text-xs text-emerald-400">check_circle</mat-icon>
                    Optimal Device Configuration Found
                  </h3>
                  <button
                    (click)="applyOptimalDevice(res)"
                    class="px-3 py-1 bg-[#D7AD59] hover:bg-[#D7AD59]/90 text-[#070F1E] font-bold text-xs rounded transition-all cursor-pointer"
                  >
                    Apply to Transistor
                  </button>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                  <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354]">
                    <div class="text-[10px] text-slate-400">Optimal Lg</div>
                    <div class="text-sm font-bold text-[#D7AD59]">{{ ((res.optimalGeometry.gateLength || 45e-9) * 1e9).toFixed(1) }} nm</div>
                  </div>
                  <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354]">
                    <div class="text-[10px] text-slate-400">Optimal Tox</div>
                    <div class="text-sm font-bold text-[#1CCCE5]">{{ ((res.optimalGeometry.oxideThickness || 1.4e-9) * 1e9).toFixed(2) }} nm</div>
                  </div>
                  <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354]">
                    <div class="text-[10px] text-slate-400">Projected Ion</div>
                    <div class="text-sm font-bold text-emerald-400">{{ (res.predictedIon * 1e3).toFixed(2) }} mA</div>
                  </div>
                  <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354]">
                    <div class="text-[10px] text-slate-400">Projected Ioff</div>
                    <div class="text-sm font-bold text-violet-400">{{ res.predictedIoff.toExponential(2) }} A</div>
                  </div>
                </div>

                <!-- Pareto Points Table -->
                <div class="overflow-x-auto">
                  <table class="w-full text-xs font-mono text-left">
                    <thead class="text-[10px] text-slate-400 uppercase bg-[#0B182D] border-b border-[#1E3354]">
                      <tr>
                        <th class="p-2">Gate Length Lg</th>
                        <th class="p-2">Oxide Tox</th>
                        <th class="p-2">Substrate Doping</th>
                        <th class="p-2">Drive Ion</th>
                        <th class="p-2">Leakage Ioff</th>
                        <th class="p-2">Ion/Ioff</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-[#1E3354]">
                      @for (pt of res.paretoPoints.slice(0, 8); track $index) {
                        <tr class="hover:bg-[#1E3354]/40">
                          <td class="p-2 text-white">{{ pt.lg.toFixed(0) }} nm</td>
                          <td class="p-2 text-[#1CCCE5]">{{ pt.tox.toFixed(1) }} nm</td>
                          <td class="p-2 text-slate-300">{{ pt.nsub.toExponential(1) }}</td>
                          <td class="p-2 text-emerald-400 font-bold">{{ (pt.ion * 1e3).toFixed(2) }} mA</td>
                          <td class="p-2 text-rose-400">{{ pt.ioff.toExponential(2) }} A</td>
                          <td class="p-2 text-[#D7AD59]">10^{{ Math.log10(pt.ion / pt.ioff).toFixed(1) }}</td>
                        </tr>
                      }
                    </tbody>
                  </table>
                </div>
              </div>
            }
          </div>
        }

        @if (activeSection() === 'variability') {
          <div class="space-y-5 max-w-4xl mx-auto">
            <div class="bg-[#070F1E] border border-[#1E3354] rounded-xl p-4 space-y-4">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="text-xs font-bold text-white uppercase tracking-wider">Monte Carlo Statistical Variations</h3>
                  <p class="text-xs text-slate-400">Simulate line-edge roughness & oxide thickness fluctuations across 100 trials</p>
                </div>
                <button
                  (click)="runMonteCarlo()"
                  class="px-4 py-2 bg-[#D7AD59] hover:bg-[#D7AD59]/90 text-[#070F1E] font-bold text-xs rounded-lg flex items-center gap-2 transition-all cursor-pointer"
                >
                  <mat-icon class="text-xs scale-75">play_arrow</mat-icon>
                  Run 100-Sample Monte Carlo
                </button>
              </div>

              <!-- Variability Parameter Sliders -->
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354] space-y-2">
                  <div class="flex justify-between">
                    <span class="text-slate-300">Gate Length &sigma;L:</span>
                    <span class="text-[#D7AD59] font-bold">&plusmn;{{ sigmaL() }} nm</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    step="0.5"
                    [value]="sigmaL()"
                    (input)="onSigmaLChange($event)"
                    class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
                  />
                </div>

                <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354] space-y-2">
                  <div class="flex justify-between">
                    <span class="text-slate-300">Oxide Thickness &sigma;Tox:</span>
                    <span class="text-[#1CCCE5] font-bold">&plusmn;{{ sigmaTox() }} nm</span>
                  </div>
                  <input
                    type="range"
                    min="0.05"
                    max="0.3"
                    step="0.02"
                    [value]="sigmaTox()"
                    (input)="onSigmaToxChange($event)"
                    class="w-full h-1.5 bg-[#1E3354] rounded appearance-none cursor-pointer"
                  />
                </div>
              </div>

              <!-- Monte Carlo Statistical Results -->
              <div class="grid grid-cols-3 gap-3 text-xs font-mono">
                <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354]">
                  <div class="text-[10px] text-slate-400">Mean Vth</div>
                  <div class="text-sm font-bold text-white">{{ (lab.extractedMetrics()?.vthLinear || 0.35).toFixed(3) }} V</div>
                </div>
                <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354]">
                  <div class="text-[10px] text-slate-400">Vth Std Dev (&sigma;Vth)</div>
                  <div class="text-sm font-bold text-[#D7AD59]">&plusmn;{{ (sigmaL() * 8.2).toFixed(1) }} mV</div>
                </div>
                <div class="bg-[#0B182D] p-3 rounded-lg border border-[#1E3354]">
                  <div class="text-[10px] text-slate-400">Drive Ion Spread</div>
                  <div class="text-sm font-bold text-emerald-400">&plusmn;{{ (sigmaL() * 3.4).toFixed(1) }}%</div>
                </div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class OptimizationVariability {
  protected readonly lab = inject(TransistorLab);
  protected readonly Math = Math;

  public readonly activeSection = signal<'optimization' | 'variability'>('optimization');
  public readonly selectedTarget = signal<OptimizationGoal['target']>('maximize_ion_ioff');
  public readonly isOptimizing = signal<boolean>(false);

  public readonly sigmaL = signal<number>(2.0); // nm
  public readonly sigmaTox = signal<number>(0.1); // nm

  public runOptimization(): void {
    this.isOptimizing.set(true);
    setTimeout(() => {
      this.lab.runOptimization({ target: this.selectedTarget(), weight: 1.0 });
      this.isOptimizing.set(false);
    }, 400);
  }

  public applyOptimalDevice(res: OptimizationResult): void {
    if (res.optimalGeometry) {
      this.lab.updateGeometry(res.optimalGeometry);
    }
    if (res.optimalDoping) {
      this.lab.updateDoping(res.optimalDoping);
    }
  }

  public onSigmaLChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.sigmaL.set(val);
  }

  public onSigmaToxChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.sigmaTox.set(val);
  }

  public runMonteCarlo(): void {
    this.lab.statusMessage.set(`Ran 100 Monte Carlo trials with sigma_L=${this.sigmaL()}nm`);
  }
}
