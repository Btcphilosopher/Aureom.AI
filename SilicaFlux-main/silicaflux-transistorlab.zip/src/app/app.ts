/**
 * SILICAFLUX TRANSISTORLAB
 * Advanced Physics-Based CMOS Transistor Digital Twin
 * Project 41 — Device Physics and Transistor Simulation
 * Aureom.AI | SilicaFlux Semiconductor Systems
 */

import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TransistorLab } from './core/services/transistor-lab';
import { Transistor3dViewer } from './components/transistor-3d-viewer';
import { ScientificCharts } from './components/scientific-charts';
import { GeometryEditor } from './components/geometry-editor';
import { OperatingBiasesPanel } from './components/operating-biases-panel';
import { MeshInspector } from './components/mesh-inspector';
import { ExperimentsDashboard } from './components/experiments-dashboard';
import { OptimizationVariability } from './components/optimization-variability';

export type MainViewTab =
  | 'digital_twin'
  | 'mesh_inspector'
  | 'spice_benchmark'
  | 'experiments'
  | 'optimization';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatIconModule,
    Transistor3dViewer,
    ScientificCharts,
    GeometryEditor,
    OperatingBiasesPanel,
    MeshInspector,
    ExperimentsDashboard,
    OptimizationVariability,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly lab = inject(TransistorLab);
  public readonly activeNavTab = signal<MainViewTab>('digital_twin');

  public setViewTab(tab: MainViewTab): void {
    this.activeNavTab.set(tab);
  }
}
