import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

/**
 * SILICAFLUX TRANSISTORLAB REST API ENDPOINTS
 * Project 41 — Device Physics and Transistor Simulation
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    program: 'SilicaFlux TransistorLab',
    motto: 'Engineering intelligence at the scale of silicon.',
    version: '41.2.0',
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/experiments', (req, res) => {
  res.json({
    experiments: [
      { id: 'exp-a-equilibrium', code: 'EXPERIMENT A', title: 'Planar NMOS Electrostatic Equilibrium' },
      { id: 'exp-b-vgs-sweep', code: 'EXPERIMENT B', title: 'NMOS Gate-Voltage Transfer Sweep (Id-Vgs)' },
      { id: 'exp-c-vds-family', code: 'EXPERIMENT C', title: 'NMOS Output Characteristics Family (Id-Vds)' },
      { id: 'exp-d-temperature', code: 'EXPERIMENT D', title: 'NMOS Temperature-Sensitivity Analysis (250K - 400K)' },
      { id: 'exp-e-spice-benchmark', code: 'EXPERIMENT E', title: 'TCAD vs SPICE Compact Model Benchmark' },
    ],
  });
});

app.post('/api/mesh/generate', (req, res) => {
  try {
    const geometry = req.body.geometry || {
      gateLength: 45e-9,
      gateWidth: 1.0e-6,
      oxideThickness: 1.4e-9,
      junctionDepth: 25e-9,
      substrateDepth: 80e-9,
      sourceDrainLength: 45e-9,
      spacerWidth: 10e-9,
    };
    const resolution = req.body.resolution || 'standard';
    // Return dimensions and node count
    const totalX = 2 * geometry.sourceDrainLength + geometry.gateLength;
    const totalY = geometry.oxideThickness + geometry.substrateDepth;
    res.json({
      success: true,
      geometry,
      resolution,
      totalXNm: totalX * 1e9,
      totalYNm: totalY * 1e9,
      nodeDimensions: resolution === 'coarse' ? { nx: 45, ny: 36 } : { nx: 61, ny: 49 },
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: errorMsg });
  }
});


/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
