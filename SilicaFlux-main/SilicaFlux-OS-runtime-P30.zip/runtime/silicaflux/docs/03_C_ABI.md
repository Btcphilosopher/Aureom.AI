# 03 — C ABI rules and versioning

| Rule | Detail |
|---|---|
| Single header | `include/silicaflux/silicaflux.h`, C99, depends only on `<stddef.h>` and `<stdint.h>`; `extern "C"` for C++ |
| Exported symbols | exactly the `sf_*` functions (43 in 1.0), enforced by the linker version script `src/silicaflux.map` with symbol version `SILICAFLUX_1.0`; Verilated models, the Verilator runtime and C++ internals are local. Checked: `nm -D --defined-only libsilicaflux.so.1` |
| Version | `SF_API_VERSION_MAJOR.MINOR` = **1.0**; `sf_get_api_version()` returns the loaded library's version; SONAME `libsilicaflux.so.1` follows the major |
| Minor versions | only **append**: functions, enum values, flag bits, struct fields at the end. Existing values never change meaning |
| Major versions | anything else; a program built for major M must refuse a library whose major differs (the SONAME prevents accidental loading) |
| Structs | every struct crossing the ABI starts with `uint32_t struct_size` set by the caller. The library reads/writes only `min(caller size, library size)` bytes, and reports in `struct_size` how many it filled. Zero-initialise the rest |
| Handles | opaque `uint64_t` (`sf_device_t`, `sf_buffer_t`, `sf_queue_t`) = type tag + generation + index. Stale handles are detected (`SF_ERR_INVALID_*`); `0` is never valid |
| Command ids | per-queue, monotonically increasing `uint64_t`, never reused within a queue |
| Errors | negative `sf_status`; never `abort()`, never a C++ exception across the boundary; thread-local `sf_last_error_detail()` |
| Threads | all functions are thread safe; calls on one device are serialised; `sf_interrupt` is async-signal-safe |
| Blocking | every blocking call is bounded (timeouts in device time + simulator wall-clock guard) |

## Device-side ABIs and their version checks

| Interface | Version source | Check performed | Mismatch |
|---|---|---|---|
| SFRQ runtime-queue ABI (host ↔ ControlCore firmware) | `HELLO` mailbox answer, `firmware/include/sf_rq_abi.h` | major must equal 1 | `SF_ERR_INCOMPATIBLE_VERSION` at open (also when the firmware has no SFRQ, e.g. stock P21 firmware 1.0) |
| P21 address map | `SYSCTRL.MAP_VERSION` (firmware self-test T1) + compile-time `static_assert`s against the generated `cc_memmap.h` | harness constants equal the map | build fails |
| Firmware image | boot ROM header version 1 + CRC32 | ROM | `SF_ERR_INCOMPATIBLE_VERSION` ("boot ROM rejected the firmware image") |
| HM08 tile ABI | tile `VERSION` 1.0, checked by firmware discovery | firmware | accelerator reported absent → capability not offered |
| TENSORCORE 08 ABI | `INFO[3:0] = 2`, checked by firmware discovery | firmware | accelerator reported absent |
| HostLink ABI | BAR0 `ID == 'SFHL'`, `VERSION.MAJOR == 1` | runtime at open | `SF_ERR_NO_DEVICE` (not SilicaFlux) / `SF_ERR_INCOMPATIBLE_VERSION` |

See `docs/COMPATIBILITY.md` for the version matrix.
