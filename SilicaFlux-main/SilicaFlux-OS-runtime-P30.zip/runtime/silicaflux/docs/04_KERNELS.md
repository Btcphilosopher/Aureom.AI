# 04 — Kernel library

SilicaFlux exposes **fixed hardware commands**, not a programmable instruction stream. The kernel library maps each
API call onto those commands; it is not a compiler and does not execute arbitrary kernels.

## 1. Operation → hardware command map

| API | `cpu` | `rtl-cc` (P21 system) | `rtl-hostlink` / `pcie` (P25) |
|---|---|---|---|
| `sf_vector_add` F32 / I32 | reference | tile **KERNEL** `FADD` / `IADD` (load A,B → compute → store D) | unsupported¹ |
| `sf_vector_mul` F32 / I32 | reference | tile KERNEL `FMUL` / `IMUL` | unsupported¹ |
| `sf_vector_fma` | reference | tile KERNEL `FMADD` | unsupported¹ |
| `sf_vector_axpy` | reference | tile KERNEL `FMADD`, `BCAST a`, `SCALAR = alpha` | unsupported¹ |
| `sf_vector_dot` | reference | tile KERNEL `FMUL` + `RED`; chunks chained with `SFRQ_F_CHAIN_SCALAR` | unsupported¹ |
| `sf_tensor_gemm` INT32 | reference | one TENSORCORE 08 **TENSOR_GEMM** (ABI v2), `PREFETCH` when double-buffered | DMA + one **TENSOR_GEMM** per 4×4 block and K chunk, host re-layout² |
| `sf_tensor_gemm` INT8 requant | reference | TENSOR_GEMM `OUT_FMT = INT8`, `Q_MULT/Q_SHIFT/Q_ZP`, `RELU` | unsupported¹ |
| `sf_buffer_copy` | memcpy | ControlCore **system DMA** (`SFRQ_OP_DMA_COPY`) | unsupported¹ |
| dot product of INT8 | — (express as an M=1 GEMM) | | |

¹ rejected with `SF_ERR_UNSUPPORTED`; with `SF_OPEN_ALLOW_CPU_FALLBACK` executed on the CPU and marked
`SF_EXEC_CPU_FALLBACK`. ² see §4.

## 2. Numerics (the contract every backend implements bit-exactly)

**FP32 vector operations** (HPC Modules 01/02): IEEE 754 binary32; rounding modes RNE, RTZ, RDN, RUP, RMM; full
subnormal support (no flush-to-zero); tininess detected after rounding; every NaN result is the canonical
`0x7FC00000`; `fma` rounds once and raises NV for `inf·0` even with a quiet-NaN addend; flags `{NV, DZ, OF, UF, NX}`
OR-ed over the command (`sf_cmd_result.fp_flags`).

**INT32 vector operations:** two's-complement wrap-around, low 32 bits of the product.

**Dot product — defined order** (HPC Module 03 `REDUCTION.md`): products are rounded to FP32 first (unfused). For each
beat of `vector_lanes` elements (4 on the reference tile) a pairwise tree over lane index adds present elements
(absent tail elements are skipped, never replaced by zero); beat sums are accumulated strictly in order starting from
`+0.0`. The result is reproducible bit-for-bit but is *not* the same as a sequential loop or a BLAS dot.
Long vectors are split at beat boundaries and chained (the next chunk's initial value is the previous result), which
preserves the definition exactly.

**GEMM:** `C[m][n] = Σ_k A[m][k]·B[k][n]`, INT8 operands, exact INT32 (K ≤ 131 071 excludes overflow). INT8 output:
`clamp(R_rm(acc·Q_MULT / 2^Q_SHIFT) + Q_ZP, −128, 127)`, then `max(·, Q_ZP)` with ReLU; `SF_RESULT_SATURATED` when a
pre-clamp value left [−128, 127] (TENSORCORE 05 contract).

The independent reference (`src/ref/`) implements these with integer arithmetic only. It was checked against the
host x86 FPU on 1.2 M operations in 4 rounding modes (0 mismatches; the only divergence — x86 not raising NV for
`fma(inf, 0, qNaN)` — is documented and handled), against binary128 for RMM (200 k operations, 0 mismatches), and the
RTL agrees with it bit-for-bit (tests).

## 3. Limits and chunking (rtl-cc)

| Item | Value | Source |
|---|---|---|
| Vector chunk | `min(VL_MAX, scratchpad / 16)` = 4096 elements | KERNEL staging uses 4 areas of `VL·4` bytes in the 64 KiB scratchpad |
| Vector call limit | ≤ 63 chunks per call (one ring) → ≤ 258 048 elements | |
| GEMM | M, N ≤ 65 535; K ≤ `K_MAX` (131 071) | TENSORCORE 08 `K_MAX` register |
| Requantisation | present when TC08 `INFO[24]` (quant) is set | |
| Device memory | 896 KiB + 64 KiB user regions (60 KiB reserved for rings/telemetry, 4 KiB test window) | P21 map |

## 4. HostLink GEMM (host-assisted operand layout)

The SilicaFlux-V tensor engine reachable through HostLink computes one **4×4** output block per command from operands
in its 16 KiB scratchpad: A column-major (`word k = A[0..3][k]`), B row-major (`word k = B[k][0..3]`), K ≤ 1024 per
command, accumulation across commands with `te_flags.ACC`. A general row-major GEMM therefore needs a re-layout that
the device cannot do (HostLink ABI 1.0 has no device-to-device copy). The backend:

1. DMAs the A and B footprints (and C, when rows have gaps) device → host staging;
2. per batch of output blocks: re-lays A/B blocks out on the host (zero padding at the M/N edges), DMAs them into
   the scratchpad, issues one TENSOR_GEMM per block (K > 1024: one per 1024-chunk with ACC), DMAs the C blocks back;
3. assembles C on the host and DMAs it to the C buffer.

All multiply-accumulates are performed by the RTL tensor engine; data movement is done by the RTL DMA engine; the
host only permutes bytes. The result carries `SF_RESULT_HOST_ASSISTED` and `device_commands` (DMA + GEMM entries).
This is a property of the P25 device composition, not of TENSORCORE 08, which reads row-major operands directly
(rtl-cc: one command).

## 5. What the library does not claim

* No general-purpose compiler, no user-defined kernels, no JIT: only the fixed commands above (docs/10 for the path
  towards compilation).
* No FP16/BF16/FP64, no INT8 vector ops, no transposed GEMM operands, no per-channel quantisation, no bias add
  (TENSORCORE 08 ABI v2 does not expose them — TC08 docs/09).
* No overlap of independent commands inside one queue (in-order device contract; the P21 firmware executes one entry
  at a time).
