# 06 — Performance profiling

## 1. Clock domains (never conflated)

| Domain | Fields | Meaning |
|---|---|---|
| **host** | `host_submit_ns`, `host_complete_ns`, counters with unit `host-ns`, trace `host_*_ns` | `CLOCK_MONOTONIC` of the host. For simulators it measures simulation speed, **not** device speed |
| **device** | `engine_cycles`, `device_start_cycle`, `device_end_cycle`, `device_queue_cycles`, counters with unit `cycles` | cycles of the device clock as reported by engine completion records, firmware (`mcycle`) or hardware counters; never converted to time by the library |

`nominal_clock_mhz` of a simulator is the time base used for timeouts only; it is not a measured frequency and is not
used to convert cycles in any report.

## 2. Counters (`sf_device_read_counters`)

Each counter has a stable dotted name, a unit (`cycles`, `events`, `bytes`, `ops`, `macs`, `host-ns`) and a
**source** (`hardware`, `firmware`, `simulator`, `runtime`) so that a value only a simulator can see is never
presented as a hardware counter.

| Group (device) | Source | Counters |
|---|---|---|
| `cc.*` (rtl-cc) | hardware (P21 `cc_perf`) | `cycles` (64-bit), `cpu_sleep`, `vec_busy`, `tsu_busy`, `dma_busy`, `acc_overlap`, `ext_req`, `ext_stall`, `host_req`, `irq_ext`, `irq_timer`, `acc_rb`, `bus_err`, `src_*` (per interrupt source), `iso_refused` |
| `tile.*` (rtl-cc) | hardware (HPC M07/M08) | `cycles`, `busy`, `submitted`, `completed`, `errors`, `cancelled`, `dma_active`, `dma_bytes_rd/wr`, `vec_active`, `vec_elems`, `vec_flops`, `lsu_loads/stores`, `spm_conflicts`, `overlap`, `hazard_stall`, `halted`, `cmdq_full`, `cplq_stall`, `host_spm`, `dma_cmds`, `vec_cmds`, `kernel_cmds` |
| `tensor.*` (rtl-cc) | hardware (TENSORCORE 08) | `cycles`, `busy`, `cmd_accept/done/err`, `gemm_ok`, `tiles`, `chunks`, `macs`, `compute_cycles`, `dma_active`, `overlap`, `rd_words`, `wr_words`, `bus_stall`, `desc`, `q_full`, `cpl_stall`, `saturated`, `aborts` |
| `fw.*` (rtl-cc) | firmware | `commands_executed/failed`, `entries_aborted`, `timeouts`, `accelerator_resets`, `system_dma_bytes` |
| `hostlink.*` | hardware (P25 `sfh_perf`) | `cmds_completed/failed`, `bytes_h2d/d2h`, `busy_cycles`, `host_wait_cycles`, `cq_full_cycles`, `irq_msgs`, `engine_cycles`, `doorbells` |
| `sim.*` | simulator | cycles since power-on, device-memory reads/writes/stalls (rtl-cc); host bursts, beats, MSI messages, protocol violations, IOMMU faults (rtl-hostlink) |
| `host.*`, `cpu.*` | runtime | bytes host→device / device→host, transfer time (host ns), commands completed / failed; CPU reference work |

## 3. Brief metric → where it comes from

| Metric | rtl-cc | rtl-hostlink |
|---|---|---|
| Device cycles | `cc.cycles` (64-bit); per command `engine_cycles`, `device_start/end_cycle` | per command `engine_cycles` (TE record); no free-running counter in the hardware → summary field unset |
| Vector operations | `tile.vec_elems`, `tile.vec_flops`, `tile.kernel_cmds` | — (no vector engine) |
| Tensor MAC counts | `tensor.macs` (hardware, exact: tested) | no MAC counter in the hardware → unset; `sf_cmd_result.macs` = M·N·K by definition |
| Data transfer bytes | device DMA: `tile.dma_bytes_*`, `4·tensor.rd/wr_words`, `fw.system_dma_bytes`; host transport: `host.bytes_*` | `hostlink.bytes_h2d/d2h`; host transport `host.bytes_*` |
| DMA stalls | `cc.ext_stall`, `tensor.bus_stall` (+ `sim.devmem_stall_cycles`) | `hostlink.host_wait_cycles` |
| SRAM contention | `tile.spm_conflicts` (scratchpad bank conflicts) | — |
| Queue delays | `device_queue_cycles` per command (firmware: entry first seen → engine start); `tile.cmdq_full`, `tensor.q_full` | `hostlink.cq_full_cycles` |
| RAS errors | `sf_device_get_status` (warning/fatal counts and sources) | — (no RAS block) |

`sf_device_perf_summary` returns these in a fixed struct; a field the device cannot measure is `UINT64_MAX`.

## 4. Traces (`sf_trace_start(dev, path)` … `sf_trace_stop`)

Schema `silicaflux-trace/1` (JSON):

```json
{ "schema": "silicaflux-trace/1",
  "device": {"name": "rtl-cc", "kind": 2, "is_simulator": 1, "hardware_id": "...", "nominal_clock_mhz": 100, ...},
  "clock_domains": {"host_ns": "...", "device_cycles": "..."},
  "commands": [ {"queue": "0x…", "id": 1, "op": "tensor_gemm", "status": "SF_OK", "exec_target": "rtl_simulation",
                 "host_submit_ns": 1234, "host_complete_ns": 98765,
                 "engine_cycles": 4948, "device_start_cycle": 805235, "device_end_cycle": 811483,
                 "device_queue_cycles": 1190, "device_status": 0, "device_error": 0, "fp_flags": 0,
                 "result_flags": 0, "elements": 256, "macs": 16384, "device_commands": 1} ],
  "counters_at_stop": [ {"name": "tensor.macs", "value": 16384, "unit": "macs", "source": "hardware_counter"} ] }
```

`tools/trace_to_chrome.py` converts the host timeline to Chrome / Perfetto trace events; device cycles stay in the
event arguments.

## 5. Benchmarks

`tools/run_benchmarks.sh BUILD OUT` runs `silicaflux benchmark` on every device that opens (fixed seeds and sizes),
records the environment (tool versions, CPU, firmware SHA-256) and writes `OUT/SUMMARY.md`. Results of the final run:
`reports/benchmarks/`.
