# 09 — Physical hardware backend

## 1. Status

**No SilicaFlux PCIe hardware exists.** P25's audit found no PCIe-capable board (ULX3S/ECP5 has no SERDES,
Arty A7 has no PCIe edge connector, the DE10-Nano's Cyclone V SE has no transceivers), no endpoint IP and no vendor
tools; this build machine has only an Intel host bridge and virtio functions. The hardware backend therefore
**compiles and is tested for absent-device behaviour only**. Nothing about hardware performance, enumeration or DMA on
real silicon/FPGA is claimed.

## 2. Host access method — evaluation

| Option | Assessment | Decision |
|---|---|---|
| **VFIO** (`vfio-pci`, type-1 IOMMU) | User-space access with the IOMMU as the isolation boundary: BAR0 `mmap`, DMA memory mapped explicitly (`VFIO_IOMMU_MAP_DMA`), MSI/MSI-X to eventfds, no kernel code to maintain. Requires an IOMMU-enabled host and an administrator binding the function to `vfio-pci`. Already implemented by P25 (`sfh_backend_vfio.c`) | **Chosen** for bring-up and for the user-space runtime |
| Kernel driver (`silicaflux.ko`, char device + DMA API) | Needed for multi-process sharing, a scheduler, power management and production deployment. Larger review / maintenance surface; must use `dma_map_*` (never physical addresses), `pci_enable_device_mem`, `pci_set_master`, MSI-X via `pci_alloc_irq_vectors` | **Later** (stage after hardware bring-up); the runtime backend contract (`Backend`) is the seam |
| UIO / `/dev/mem` / `setpci` + physical addresses | No IOMMU protection for DMA, user pointers or physical addresses visible to the device | **Rejected**: bypasses DMA isolation |
| VFIO `noiommu` mode | Same isolation problem | **Rejected** |

The VFIO transport never disables the IOMMU, never gives the device a user pointer (all device-visible memory comes
from `VFIO_IOMMU_MAP_DMA` mappings with guard pages), and programs HostLink windows to the same IOVA ranges as a
second, coarser fence (P25 docs/04).

## 3. Discovery and identification

HostLink PCI vendor/device IDs are **not assigned** (P25 docs/02 §1). Discovery therefore considers only
`SILICAFLUX_PCI_IDS="vvvv:dddd[,…]"` or `SILICAFLUX_PCI_BDF=<bdf>`. A matching function is listed as `pcie:<BDF>`;
it is `available` only when bound to `vfio-pci`. Opening reads BAR0 `ID` (`'SFHL'`) and `VERSION.MAJOR` (1) before
anything else: any other function is refused (`SF_ERR_NO_DEVICE` / `SF_ERR_INCOMPATIBLE_VERSION`).

Tested here (`tests/test_hardware_absent.cpp`): a real virtio function is listed as unavailable ("bound to
virtio-pci"), cannot be opened, and nothing else is reported as hardware.

## 4. Bring-up procedure (when a board exists)

1. Implement the P25 endpoint integration (vendor PCIe endpoint IP ↔ `sfh_ep_axi_shell`, P25 docs/07, requirements
   E1–E10) on a PCIe-capable FPGA board; assign or configure vendor/device IDs.
2. Host: enable the IOMMU (`intel_iommu=on` / `amd_iommu=on`), bind the function:
   `echo <BDF> > /sys/bus/pci/drivers/vfio-pci/bind` (after `driver_override`).
3. `SILICAFLUX_PCI_BDF=<BDF> silicaflux info` → expect `pcie:<BDF>`, ABI 1.0, HW_REV.
4. `silicaflux selftest --device pcie:<BDF>` (GEMM vs CPU reference), `tests/e2e_gemm` (lists and runs it
   automatically), `silicaflux benchmark --device pcie:<BDF> --json …`.
5. Only then: performance claims, interrupt mode (`sfh_irq_setup(…, 1)`), function-level reset
   (`VFIO_DEVICE_RESET`, currently refused as unvalidated), relaxed-ordering checks (`CTRL.FLUSH_ALL`).

## 5. What would change for a ControlCore-based PCIe device

A chip that puts HostLink in front of the P21 ControlCore system (P25 docs/07 §6) would let this runtime keep the
`rtl-cc` command path (SFRQ rings in device memory) and replace the harness memory window by HostLink DMA — the
`Backend` contract already separates these. That RTL integration does not exist yet.
