# 05 — Backends and transports

## 1. CPU reference (`cpu`)

* Kind `SF_DEVICE_CPU_REFERENCE`; results `SF_EXEC_CPU_REFERENCE`; `hardware_id` says "not SilicaFlux hardware".
* Same operation set and numeric contract as the engines (docs/04), 4-lane reduction order (reference tile).
* Device memory: a lazily committed 1 GiB host mapping addressed by device offsets (`0x1_0000_0000 + off`).
* Execution: one command per progress step, in the calling thread (`sf_queue_poll` / `wait` / `sync`). No threads.
* No device clock, no hardware counters (summary fields are `UINT64_MAX`, not invented values), no RAS.

## 2. RTL simulation of the P21 ControlCore system (`rtl-cc`)

| Item | Detail |
|---|---|
| Model | `third_party/controlcore` (P21, unmodified RTL: ControlCore RV32IM + M08 tile + TC08 tensor unit + DataFabric), Verilated `--cc -O3`, single thread (measured: multi-threaded is slower) |
| Harness | `src/backends/rtl_cc/cc_sim.cpp`: host SFB2 master BFM on `hs_*`, 1 MiB device memory on `dm_*` with the P21 testbench's semantics (one outstanding request, response next cycle, 4 KiB poison window), console tap, RAS input pins, host reset pin, error-range and back-pressure injection |
| Boot | power-on reset → boot ROM `WAIT_IMAGE` → firmware image written to IMEM through the host port → `IMAGE_READY` → ROM CRC check → firmware POST → `HOST_READY` pin + capability message → SFRQ `HELLO` / `INFO` (≈ 800 k cycles, ≈ 7 s on this host) |
| Firmware | `controlcore_rt.hex` (built from P21 sources + `firmware/app/{main_rt.c,rq.c}`; prebuilt copy in `firmware/prebuilt/`) |
| Data transfers | through the harness's device-memory window: zero simulated time, a model of a host-mapped device-memory BAR. The P21 system has no host DMA path (host writes to DMEM are locked after boot) — HostLink integration would provide one (docs/12) |
| Commands | SFRQ rings in device memory (docs/07), mailbox `KICK` |
| Time base | 100 MHz **nominal** (simulated time for timeouts); default timeout 100 ms simulated |
| Speed | ≈ 110 k cycles/s on this host |

Environment knobs: `SILICAFLUX_CC_FIRMWARE` (image path), `SILICAFLUX_CC_CONSOLE=1` (echo the firmware console),
`SILICAFLUX_CC_CMD_TIMEOUT_CYCLES` (per-entry firmware timeout; diagnostic), `SILICAFLUX_SIM_WALL_TIMEOUT_S`.

## 3. RTL simulation of the P25 HostLink device (`rtl-hostlink`)

| Item | Detail |
|---|---|
| Model | `third_party/hostlink` (P25, unmodified RTL: HostLink + DataFabric + 64 KiB SRAM + SilicaFlux-V tile), Verilated with tracing support |
| Host model | P25 `tb/cosim/sfh_sim.cpp`: PCIe endpoint IP + root complex + IOMMU + host memory + CPU MMIO at the AXI boundary (24-cycle read latency, strict posted-write ordering, MSI) |
| Driver | P25 `sw/lib/sfh_driver.c`, unmodified: ID/VERSION check, function reset, rings (64 entries), windows (least privilege), polling completion |
| Staging | 4 MiB job pool + 64 KiB transfer pool, both IOMMU-mapped and window-limited |
| Time base | 250 MHz nominal (P25 host model's constant) |
| Faults | `SF_INJECT_HOST_DMA_ERROR` (host bus answers SLVERR on the staging pools: IOMMU/PCIe fault) |

## 4. Physical PCIe through VFIO (`pcie:<BDF>`)

Same backend code as `rtl-hostlink`, transport = P25 `sfh_backend_vfio.c`. **Compiles; never executed** — there is no
SilicaFlux PCIe hardware (docs/09). Discovery, refusal of non-SilicaFlux functions and the absent-hardware behaviour are
tested (`tests/test_hardware_absent.cpp`).

## 5. Capability summary

| Capability | cpu | rtl-cc | rtl-hostlink | pcie |
|---|:-:|:-:|:-:|:-:|
| vector F32 / I32, dot | ✓ | ✓ | – | – |
| GEMM INT8→INT32 | ✓ | ✓ | ✓ (host-assisted layout) | ✓ (same code, untested) |
| GEMM INT8 requant + ReLU | ✓ | ✓ | – | – |
| device copy | ✓ | ✓ | – | – |
| hardware counters | – | ✓ (64) | ✓ (10) | ✓ (10) |
| RAS | – | ✓ | – | – |
| device timestamps | – | ✓ | – | – |
| firmware self-test | – | ✓ (231 checks) | – | – |
| fault injection | – | ✓ | ✓ | – |
