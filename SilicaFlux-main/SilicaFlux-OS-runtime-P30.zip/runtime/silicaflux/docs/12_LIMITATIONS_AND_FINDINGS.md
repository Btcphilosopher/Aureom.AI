# 12 — Limitations, findings and next steps

## 1. Evidence limits

* **Everything ran in RTL simulation** (Verilator 5.020) or on the CPU reference. Nothing ran on an FPGA board or on
  silicon; no hardware performance is claimed. Cycle counts are cycles of the RTL against modelled memories (P21:
  1-cycle device SRAM model; P25: 24-cycle host read latency model).
* The **VFIO hardware backend has never executed** (no hardware exists, docs/09).
* Simulated time uses **nominal** clocks (100 MHz rtl-cc, 250 MHz rtl-hostlink) for timeouts only.
* Firmware integrity is CRC32 only; **no authentication** (Project 28 absent).

## 2. Functional limits

| Limit | Cause | Consequence |
|---|---|---|
| Two separate device compositions | No RTL integrates HostLink (PCIe) with the P21 ControlCore system | vector + quantised GEMM only on `rtl-cc`; PCIe path (`rtl-hostlink`, `pcie`) offers INT8→INT32 GEMM only |
| rtl-cc host data path is the harness's memory window | P21 has no host DMA; host writes to DMEM are locked after boot | transfers take zero simulated time; counted as host-transport bytes, never as device DMA |
| HostLink GEMM needs host re-layout | SilicaFlux-V tensor engine: 4×4 blocks, fixed operand layout, scratchpad-resident; no device-to-device copy in ABI 1.0 | `SF_RESULT_HOST_ASSISTED`; extra D2H/H2D traffic |
| One entry at a time per device (rtl-cc) | firmware design (simple, deterministic) and TC08 executes one command at a time | no overlap of vector and tensor work from the runtime (P21 self-test T9 shows the hardware can overlap) |
| Vector call ≤ 258 048 elements on rtl-cc | 63 ring entries × 4096-element KERNEL chunks | split larger vectors in the application |
| No ECC in the integrated device | Project 26 SECDED not integrated | RAS = control-SRAM parity + SoC inputs + firmware reports |
| Single host thread per device | simulators are single-threaded; device mutex | concurrent calls are serialised |
| `SF_RESET_FULL` on VFIO | function-level reset not validated | refused (`SF_ERR_UNSUPPORTED`), CTRL.RESET used |
| Simulation speed | ≈ 110 k cycles/s (rtl-cc), boot ≈ 7 s | long workloads are slow to simulate (never a device-speed statement) |

## 3. Findings during integration

1. **Accelerator-domain reset with an outstanding transaction wedges the shared device-memory port** (P21 PMU +
   DataFabric). Symptom on the RTL: the ControlCore CPU stalls on its next device-memory access, the watchdog resets
   the chip. P21 firmware only reset an idle domain. **Fixed in the runtime firmware** (quiesce first —
   `acc_quiesce_reset`). Recommendation for the RTL: let the PMU wait for `EXT_IDLE` / port idle before asserting the
   domain reset, or have the memory-side fabric drop responses owed to a reset requester.
2. **x86 FMA3 vs RISC-V semantics:** `fma(inf, 0, qNaN)` raises invalid on RISC-V (and on the SilicaFlux FMA,
   verified against SoftFloat-RISCV) but not on x86. Host-FPU oracles must not be used blindly for flag checks.
3. **TC08 re-reads operands per output tile** (`tensor.rd_words` = 2048 for a 16×16×64 GEMM): ≈ 3.6 MAC/cycle of a
   16-MAC array behind the 32-bit SFB2 port — as TC08 docs/09 predicts. Operand reuse (TC06) would raise it.
4. **Vector KERNEL is memory-bound** (≈ 0.078 elements/cycle for FADD through one 32-bit port with scratchpad
   staging); VEC commands on scratchpad-resident data would avoid the staging for chained vector work (a natural
   stage-2 optimisation, docs/10).
5. **Firmware dispatch latency** ≈ 2 000 cycles per entry (ring fetch over the 32-bit port + driver validation),
   visible as `device_queue_cycles` when the queue is idle.

## 4. Next steps

1. RTL: integrate HostLink in front of the P21 system (P25 docs/07 §6); then the rtl-cc command path runs over real
   DMA and the PCIe backend gains vector and quantised GEMM.
2. Firmware: overlap vector and tensor entries from different queues (the hardware supports it), batch descriptor
   fetches, PMU reset fix (finding 1) in RTL.
3. Runtime: stage-1 command graphs (docs/10), Python bindings over the C ABI, Verilator checkpointing to skip the
   7 s boot in tests.
4. Hardware: PCIe-capable FPGA bring-up (docs/09 §4).
