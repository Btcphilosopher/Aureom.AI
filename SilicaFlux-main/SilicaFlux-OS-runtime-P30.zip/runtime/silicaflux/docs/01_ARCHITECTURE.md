# 01 — Software architecture

## 1. Layers

```
 APPLICATION                 examples/*.c, tools/silicaflux (CLI), your code
     │  C ABI 1.0            include/silicaflux/silicaflux.h  (only stable interface)
 SILICAFLUX COMPUTE API      src/core/kernels.cpp     validation + lowering of sf_vector_* / sf_tensor_gemm / copy
     │                                                (precisions, dimensions, access flags, aliasing, CPU fallback)
 KERNEL RUNTIME              src/core/runtime.cpp     devices, handle tables, in-order queues, results, timeouts,
     │                                                interruption, ownership of buffers, tracing (profile.cpp)
 COMMAND AND MEMORY MANAGER  Allocator (device memory), Command objects, BackendQueue contract (internal.h)
     │
 HOST TRANSPORT BACKEND      cpu/cpu_backend.cpp          host memory, CPU reference kernels (src/ref)
     │                       rtl_cc/cc_backend.cpp        SFRQ rings + mailbox  ─┐
     │                       hostlink/hl_backend.cpp      P25 C driver (SQ/CQ)   │ over a transport:
     │                                                                          │
 SILICAFLUX HARDWARE         rtl_cc/cc_sim.cpp            Verilated P21 silicaflux_cc_hpc_system + ControlCore firmware
   OR RTL SIMULATION         hostlink/hl_sim_transport    Verilated P25 sfh_device_top + PCIe/IOMMU host model
                             hostlink/hl_vfio_transport   Linux VFIO → physical PCIe function (compiles; no hardware)
```

Every layer above the backend is device independent; a backend implements the `Backend` / `BackendQueue` contract in
`src/core/internal.h` (open/close, memory regions, blocking transfers, `check` of a lowered command, `start`/`poll`
of commands, `advance` of device time, reset, status, counters, injection).

## 2. Backends and devices

| Device name | Kind (`sf_device_kind`) | Backend | Transport | Status |
|---|---|---|---|---|
| `cpu` | `CPU_REFERENCE` | `cpu_backend.cpp` | host memory (lazily committed 1 GiB mapping) | runs |
| `rtl-cc` | `RTL_SIMULATOR` | `cc_backend.cpp` + firmware `controlcore_rt` | Verilated P21 ControlCore system | runs |
| `rtl-hostlink` | `RTL_SIMULATOR` | `hl_backend.cpp` (P25 `sfh_driver.c`) | Verilated P25 HostLink device + host model | runs |
| `pcie:<BDF>` | `HARDWARE` | `hl_backend.cpp` (P25 `sfh_driver.c`) | VFIO (P25 `sfh_backend_vfio.c`) | compiles; **no hardware exists** |

A simulator always reports `is_simulator = 1` and `SF_EXEC_RTL_SIMULATION`; nothing in the library can label a
simulated or CPU computation as hardware execution.

## 3. Command flow (rtl-cc)

```
sf_tensor_gemm(q, A, B, C, desc)
  kernels.cpp   validate: handles, same device, DEVICE_READ/WRITE flags, footprints, types, strides, ALIAS
                lower: GemmArgs (device addresses, normalised strides)
                Backend::check -> device limits (M,N <= 65535, K <= K_MAX, requantisation present)
  runtime.cpp   queue depth check (SF_ERR_QUEUE_FULL, nothing submitted), ownership counters ++
                BackendQueue::start
  cc_backend    build the 12-word TENSORCORE 08 ABI v2 descriptor, wrap it in a 64-byte SFRQ entry,
                write it to the SQ ring in device memory, update SQ_TAIL, mailbox KICK
  firmware      rq.c: fetch entry (in order), forward the descriptor unchanged to the tensor unit
                (tsu_submit), sleep until the TENSOR interrupt (bounded, abortable), write the
                64-byte completion entry (record + timestamps), phase tag last
sf_queue_wait   loop: pump (retire completed commands in order) -> device time / interrupt / wall guard
                checks -> Backend::advance (simulator: clock cycles)
  cc_backend    read CQ entry (phase first), release the slot (CQ_HEAD), aggregate chunked commands,
                map engine status -> sf_status, fill sf_cmd_result (cycles, timestamps, flags)
```

The HostLink path is the same above the backend; below it the P25 driver writes SQEs into host-memory rings,
rings the BAR0 doorbell and consumes CQEs (phase tags) — and a GEMM is a sequence of DMA and TENSOR_GEMM entries
(docs/04 §4).

## 4. Time and progress

* A simulator only advances when the host lets it: `sf_queue_poll` advances one bounded slice, `sf_queue_wait` /
  `sf_buffer_sync` advance until done or a bound. The CPU backend executes one command per step in the calling
  thread. There are no hidden threads.
* Timeouts are in **device time**: wall clock for hardware/CPU, **simulated time** (cycles ÷ nominal clock) for
  simulators, plus a wall-clock guard for simulators (`SILICAFLUX_SIM_WALL_TIMEOUT_S`, default 900 s). No wait is
  unbounded.
* Host timestamps (`CLOCK_MONOTONIC` ns) and device cycles are separate fields everywhere (docs/06).

## 5. Concurrency and safety

* Global handle tables (index + generation); a stale handle is detected, never dereferenced.
* Each device is serialised by its own recursive mutex; `sf_interrupt()` only sets an atomic flag
  (async-signal-safe) and is observed by every wait loop.
* Devices are opened exclusively (`SF_ERR_BUSY` on a second open).
* Buffers are reference counted: commands hold references; memory is returned to the allocator when the last
  holder (handle or pending command) is gone. The device owns a buffer between submission and retirement
  (docs/02 §3).

## 6. Source map

```
include/silicaflux/silicaflux.h   public C ABI
src/core/          runtime.cpp (devices, buffers, queues, C API) · kernels.cpp (compute API) ·
                   cpu_exec.cpp (CPU execution of lowered commands) · profile.cpp (counters, traces) · internal.h
src/ref/           sf_softfloat.* (integer-only FP32, RISC-V semantics) · sf_reference.* (vector/dot/GEMM/requant)
src/backends/      registry.cpp (discovery) · cpu/ · rtl_cc/ (cc_sim harness + backend) ·
                   hostlink/ (backend + simulation and VFIO transports)
firmware/          include/sf_rq_abi.h (host<->firmware ABI) · app/main_rt.c · app/rq.c · prebuilt/
third_party/       controlcore/ (P21, unmodified) · hostlink/ (P25, unmodified) · SHA256SUMS · PROVENANCE.md
tools/             silicaflux CLI · run_benchmarks.sh · bench_report.py · trace_to_chrome.py
tests/  examples/  docs/  reports/  ci/
```
