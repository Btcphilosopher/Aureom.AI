# 10 — Staged path towards compiler integration

Nothing in this project is a compiler. SilicaFlux executes **fixed commands** (tile KERNEL/VEC/DMA, TENSOR_GEMM,
system DMA); there is no programmable instruction stream for user kernels on the accelerators, and the only
programmable core (the ControlCore RV32IM) is a control processor. The stages below say what each step needs before it
may be built; a stage is only implemented once its **executable target, command format and verification tests**
exist.

| Stage | Interface | Target | Prerequisites | Status |
|---|---|---|---|---|
| 0 | C/C++ API (`sf_vector_*`, `sf_tensor_gemm`, queues) | fixed commands via the runtime | runtime + backends | **done (this project)** |
| 1 | Explicit kernel descriptors: a serialisable list of API commands with buffer bindings (a "command graph"), validated once, submitted many times | same commands, batched into one SFRQ submission | stable descriptor schema; replay tests vs CPU reference | next step: needs only runtime work (no new hardware) |
| 2 | Graph-level fusion and scheduling (e.g. GEMM → requant → next layer without host round trips; vector chains; tiling of large GEMMs across queues) | same commands | stage 1; cost model from `silicaflux benchmark` data; differential tests | design only |
| 3 | **MLIR lowering**: a `silicaflux` dialect whose ops are exactly the hardware commands (`sf.tile_kernel`, `sf.tensor_gemm`, `sf.dma_copy`) with their legality rules as verifiers; lowering from `linalg.matmul` (i8×i8→i32), `linalg.generic` elementwise f32 add/mul/fma, `linalg.dot` (with the defined reduction order made explicit), quantisation patterns from `tosa`/`quant`; emission of stage-1 descriptors | runtime command graphs | stage 1 schema; dialect verifier tests mirroring TENSORCORE validation rules 1–15 and tile rules; numerical tests vs `src/ref` | not started |
| 4 | **LLVM / RISC-V**: compiling host-side or ControlCore-side glue (e.g. firmware-resident schedulers) with the RISC-V LLVM backend for RV32IM_Zicsr | ControlCore firmware | an ABI for loadable firmware modules (none exists: images are monolithic and CRC-checked; authentication missing, Project 28 absent) | not started; blocked on firmware loading/authentication |
| 5 | Framework integrations (PyTorch custom ops / ONNX Runtime execution provider / JAX via PJRT) | stage 3 or the C API directly | Python bindings (optional, after the C API is stable), operator coverage, model-level tests | not started |

Rules carried forward:

* lowering must reject what the hardware cannot do (no silent dtype conversion, transposition or emulation);
* every compiled artefact must report its execution target as the runtime does today;
* FP32 reductions must state their order — the hardware's order is part of the semantics (docs/04 §2).
