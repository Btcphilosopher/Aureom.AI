# 00 — Repository audit and dependency readiness

Audit of `btcphilosopher/Aureom.AI` (snapshot 2026-11-10) done before any runtime code was written. Every
SilicaFlux project is stored as a zip archive; the relevant ones (under
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`) were extracted and read, and the two that the runtime builds on were
rebuilt and re-run here.

## 1. Build machine

| Item | Finding |
|---|---|
| OS / compilers | Ubuntu 24.04, Linux 6.18 x86-64, GCC 13.3, CMake 3.28, Python 3.13 |
| HDL / firmware tools | **none installed** at the start. Installed from Ubuntu packages: Verilator 5.020, Icarus Verilog 12.0, `gcc-riscv64-unknown-elf` 13.2 — the exact versions the SilicaFlux projects' own flows record |
| PCIe hardware | Intel host bridge + virtio functions only; no FPGA / SilicaFlux function; no `/dev/vfio/*` |
| Firmware reproducibility | P21 firmware rebuilt from source: CRC32 `0x4e49b917`, **identical** to the P21 report |

## 2. Readiness of every dependency named in the brief

Readiness scale: **RTL-sim** = verified in RTL simulation by its project and re-run here; **compile-only** = code
exists, never executed; **absent** = not in the repository.

| Dependency | Where (archive) | What exists | Readiness | How P30 uses it |
|---|---|---|---|---|
| **ControlCore firmware** | `silicaflux-controlcore.zip` (Project 21) | RV32IM_Zicsr CPU + boot ROM + C firmware: boot stages, POST, interrupt-driven accelerator orchestration, mailbox command processor (PING, RUN_SELFTEST, GEMM, VECTOR_KERNEL, DMA_COPY, PERF_DUMP, RAS_DUMP, SHUTDOWN), 231-check self-test, CRC32 image check (**no authentication**) | **RTL-sim**. P21 regression 6/6; re-run here: `boot_ext` PASS. Never ran on an FPGA board or silicon | Vendored unmodified; P30 replaces only `main.c` (by `firmware/app/main_rt.c`) and adds the runtime-queue engine (`rq.c`). All other firmware files byte-identical |
| **Vector command ABI** | HPC Module 08 tile (vendored in P21) | 8-word descriptor (NOP / DMA / VEC / KERNEL), FP32 FADD…FMADD, IADD/IMUL, 5 rounding modes, sum-reduction with a *defined* order, completion record; generated header `hpc_tile_regs.h` | **RTL-sim** | Descriptors built by the runtime, carried verbatim through the firmware to the tile |
| **Tensor command ABI** | TENSORCORE 08 (vendored in P21) | 12-word GEMM descriptor ABI v2, INT8×INT8→INT32 exact or requantised INT8 (+ReLU), 15 validation rules, 6-word record, `tsu_abi.h` | **RTL-sim** | Descriptors built by the runtime, carried verbatim |
| **DataFabric memory map** | P21 `config/cc_memmap.yaml` (map v1.0) + DataFabric P03 (SFB2) | Device memory 1 MiB @ `0x2000_0000`, tile scratchpad 64 KiB @ `0x3000_0000`, register pages, mailbox, perf, RAS, PMU; SFB2 protocol | **RTL-sim**, generated & validated (P21 `check-map`) | Runtime allocator regions, firmware rings, static asserts against the generated header |
| **PCIe host interface** | `silicaflux-hostlink-project25.zip` (Project 25) | BAR0 ABI 1.0, NVMe-style SQ/CQ in host memory, DMA descriptor engine, isolation windows, MSI; generic AXI endpoint boundary; C driver with a simulated and a VFIO backend | **RTL-sim** (co-simulation 144/144 in P25); re-run here: GEMM demo PASS. **No PCIe protocol logic**, no endpoint IP, no board: physical PCIe **blocked** | Vendored unmodified; the runtime's HostLink backend drives the P25 C driver over the P25 simulation model or VFIO |
| **Performance counters** | P21 `cc_perf` (20 events + 64-bit cycles), M07/M08 tile (24), TC08 (20 + 18 DMA), P25 HostLink (10) | Counter banks with freeze/clear; P21 `PERF_DUMP` telemetry block | **RTL-sim** | `sf_device_read_counters`, `sf_device_perf_summary`, traces |
| **DMA interfaces** | P21 system DMA (`mcu_dma`), M05 tile DMA, TC07 tensor DMA, P25 HostLink DMA | On-chip copies; scratchpad staging; tensor operand streaming; host↔device over the AXI endpoint boundary | **RTL-sim** | Device-to-device copy (P21), KERNEL staging (tile), GEMM operands (TC07), all HostLink host transfers |
| **Existing host software** | TC08 `tsu_driver.c`, M08 `silicaflux_hpc.c`, P25 `sfh_driver.c`, P21 SV testbench host BFM | Bare-metal drivers (used by firmware), one user-space driver (P25), testbench host model | firmware drivers RTL-sim; P25 driver RTL-sim; P25 VFIO backend **compile-only** | Reused unmodified |
| **Existing tests** | P21 regression + cocotb + riscv-tests; P25 co-sim + mutants; TC08/M08 suites | | RTL-sim | P21 self-test re-run through the runtime (`sf_device_selftest`) |
| RAS / ECC | `silicaflux-ras-project26.zip` (Project 26) | SECDED ECC, scrubbing, event controller — **standalone**, not integrated into the P21 or P25 systems | RTL-sim (standalone) | **Not used**: the integrated device's RAS is P21 `cc_ras` (control-SRAM byte parity, SoC warning/fatal inputs, firmware reports) |
| Power management | `silicaflux-powerclock.zip` (Project 27) | Clock/reset/throttle manager — **standalone** | RTL-sim (standalone) | Not used; the P21 PMU (accelerator clock gate / reset / isolation) is |
| Authentication (Project 28), Project 29 | — | **absent** | absent | Firmware integrity = CRC32 only; nothing is claimed about authentication |

## 3. The integrated devices that exist

There is **no single RTL composition** of the whole chip. Two integrated systems exist, with different engines:

| | P21 ControlCore system (`silicaflux_cc_hpc_system`) | P25 HostLink device (`sfh_device_top`) |
|---|---|---|
| Host interface | SFB2 host access port + mailbox (the testbench is the host); shared device memory owned by the SoC | PCIe-style BAR0 + host-memory SQ/CQ behind a generic AXI endpoint boundary (simulated host) |
| Control processor | RV32IM ControlCore + firmware | none (hardware queue engine) |
| Vector engine | HPC M08 FP32 tile (4 lanes, 64 KiB scratchpad) | not reachable (opcode reserved in ABI 1.0) |
| Tensor engine | TENSORCORE 08: general M×N×K INT8 GEMM, INT32 or requantised INT8 | SilicaFlux-V tensor engine: one 4×4×K INT8 block per command, INT32 only, operands in a 16 KiB scratchpad in a fixed layout |
| Device memory | 1 MiB shared SRAM (testbench model) | 64 KiB SRAM + 16 KiB tensor scratchpad |
| RAS | `cc_ras` (parity, SoC inputs, firmware) | none (error status registers only) |

**Consequence:** the runtime has **two RTL simulation backends** (`rtl-cc`, `rtl-hostlink`) plus the CPU reference
and a VFIO hardware backend that speaks the HostLink ABI. Integrating HostLink in front of the P21 ControlCore
system (the realistic chip topology) is RTL work outside this project; P25 docs/07 §6 already sketches it.

## 4. Gaps found that shaped the design

| Gap | Decision |
|---|---|
| P21 mailbox runs **one command at a time** and blocks for its whole duration | New firmware engine (`rq.c`) consuming **host-owned rings in device memory** (SFRQ ABI, docs/07) with in-order completion, phase tags, back-pressure, per-entry timeouts, abort, timestamps |
| P21 has **no host→device data path** except the testbench's direct access to its memory model (host writes to DMEM are locked after boot) | The rtl-cc transport writes device memory through the harness's memory window (a model of a host-mapped device-memory BAR); documented, counted as host-transport bytes, never as device DMA |
| HostLink exposes no vector engine and a 4×4-block tensor engine | HostLink backend offers INT8→INT32 GEMM only, with host-side operand re-layout flagged `SF_RESULT_HOST_ASSISTED`; other ops rejected (or explicit CPU fallback) |
| PCI vendor/device IDs are **not assigned** | Discovery only considers IDs given by the user (`SILICAFLUX_PCI_IDS` / `SILICAFLUX_PCI_BDF`); opening verifies BAR0 `ID == 'SFHL'` |
| No authentication engine | Nothing claimed; image integrity is CRC32 (boot ROM) |

## 5. Defect found during integration (fixed in P30 firmware)

Resetting the accelerator domain through the P21 PMU while the tensor unit had a transaction outstanding on the
shared device-memory port left that port wedged; the ControlCore CPU then stalled on its next device-memory access
and the **watchdog reset the chip** (observed on the RTL: `reset cause=4`). P21's own firmware only resets an idle
domain, so its tests never hit it. The P30 firmware quiesces first (tensor unit `CTRL.ABORT`, tile `FLUSH`, wait for
`PMU.ACC_STATUS` busy = 0 and `EXT_IDLE`) and only then resets (`acc_quiesce_reset`, `firmware/app/rq.c`).
Test: `recovery_reset_during_execution`. See also docs/12.
