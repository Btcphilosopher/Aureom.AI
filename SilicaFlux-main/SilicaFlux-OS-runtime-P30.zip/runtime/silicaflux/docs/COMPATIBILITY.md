# Version compatibility matrix

## Library 1.0.0 (C ABI 1.0)

| Component | Version / identity | Compatible | Check | On mismatch |
|---|---|---|---|---|
| Applications built against `silicaflux.h` | C ABI 1.x | library 1.y (any y; struct_size rule) | SONAME `libsilicaflux.so.1`, `sf_get_api_version()` | loader refuses other majors |
| ControlCore runtime firmware | `controlcore_rt` 2.0, SFRQ ABI 1.0 | ✓ | `HELLO`: SFRQ major == 1 | `SF_ERR_INCOMPATIBLE_VERSION` |
| ControlCore firmware, SFRQ ABI 2.x (test build `controlcore_rt_abi2`) | — | ✗ | `HELLO` | `SF_ERR_INCOMPATIBLE_VERSION` (tested) |
| P21 stock firmware 1.0 (no SFRQ) | — | ✗ (no runtime queues) | `HELLO` → `BAD_CMD` | `SF_ERR_INCOMPATIBLE_VERSION` (tested) |
| P21 boot ROM | v1.0, image header v1, CRC32 | ✓ | ROM | image rejected → `SF_ERR_INCOMPATIBLE_VERSION` (tested) |
| P21 address map | v1.0 (`MAP_VERSION 0x0001_0000`) | ✓ | compile-time asserts + firmware T1 | build error |
| HPC M08 tile ABI | 1.0 | ✓ | firmware discovery (`ID 'SFHT'`, VERSION) | vector capability absent |
| TENSORCORE 08 ABI | v2 (`INFO[3:0] = 2`) | ✓ | firmware discovery | tensor capability absent |
| HostLink ABI | 1.x (`ID 'SFHL'`) | ✓ | BAR0 at open | `SF_ERR_NO_DEVICE` / `SF_ERR_INCOMPATIBLE_VERSION` |
| HostLink HW_REV | `0x00010000` (P25) | ✓ | reported only | — |

## Tools and environment (verified)

| Tool | Verified version | Notes |
|---|---|---|
| Verilator | 5.020 | same as the P21/P25 flows; multi-threaded models measured slower |
| riscv64-unknown-elf-gcc | 13.2.0 | firmware images reproducible byte-for-byte (`firmware/prebuilt/SHA256SUMS`) |
| GCC / CMake / Python | 13.3 / 3.28 / 3.13 | Ubuntu 24.04 |
| Linux | 6.18 (x86-64) | VFIO UAPI for the hardware backend (compile only) |

## Vendored sources

| Project | Archive (SHA-256) | Files | Modified |
|---|---|---|---|
| P21 ControlCore | `silicaflux-controlcore.zip` (`39b5b8e3…faecf530`) | `third_party/controlcore/` | **no** (P30 adds `firmware/app/main_rt.c`, `rq.c` outside it) |
| P25 HostLink | `silicaflux-hostlink-project25.zip` (`bfb5bab2…6b81b96`) | `third_party/hostlink/` | **no** |

Per-file SHA-256: `third_party/SHA256SUMS`.
