# 11 — Fault and recovery behaviour

Every case of brief §17, the documented result, and the test that exercises it on the RTL (or CPU) backend.

| Fault | Behaviour | Status returned | Recovery | Test |
|---|---|---|---|---|
| **Device absent** | listed only when configured; unavailable entries explain why; unknown names refused | `SF_ERR_NO_DEVICE` | — | `test_hardware_absent`, `api_cpu: version_and_discovery`, `rtl_cc: compat_missing_image` |
| **Unsupported hardware / firmware revision** | stock P21 firmware (no SFRQ), SFRQ ABI 2.0 firmware, image rejected by the boot ROM (CRC), HostLink ABI major ≠ 1 | `SF_ERR_INCOMPATIBLE_VERSION` | load a compatible image | `rtl_cc: compat_*` |
| **Invalid buffer** | released / never-valid / other device's handle; out-of-range; permissions | `SF_ERR_INVALID_BUFFER`, `SF_ERR_OUT_OF_RANGE`, `SF_ERR_PERMISSION` | — | `api_cpu: buffers_*`, `rtl_cc: faults_invalid_handles_and_arguments` |
| **Invalid command** | rejected by the runtime (precision, dims, strides, aliasing) **before** submission, or by the engine's own validation (reserved tile TYPE → `BAD_TYPE`; TC08 `VERSION`, `RANGE`…): nothing executed, engine recovered | `SF_ERR_UNSUPPORTED` / `SF_ERR_INVALID_ARGUMENT`; device-side: `SF_ERR_INVALID_COMMAND` with the engine code | next command executes normally | `rtl_cc: faults_invalid_commands_rejected_by_the_engines` |
| **Queue full** | submission beyond the depth is refused without side effects; rings never overwritten (firmware stalls on a full CQ; HostLink validates doorbells) | `SF_ERR_QUEUE_FULL` | retire commands | `api_cpu: queue_*`, `rtl_cc: kernels_queue_full_order_and_poll`, `rtl_hostlink: queue_full_*` |
| **DMA failure** | device memory error (tile DMA `DMA_ERR/READ_BUS`, TC08 `DMA_READ 0x18`, system DMA code 8); host-side PCIe/IOMMU error (HostLink `HOST_BUS_ERROR`); partial results never reported as success | `SF_ERR_DMA` (+ engine codes) | clear the fault; next command OK | `rtl_cc: faults_dma_failure_*`, `rtl_hostlink: host_dma_fault_*` |
| **Command timeout** | host: the wait returns, the command stays pending. Device: the firmware's per-entry timeout expires → quiesced accelerator reset → completion `TIMEOUT` | `SF_ERR_TIMEOUT` | wait again / continue (engine reset) | `rtl_cc: faults_host_timeout_never_hangs`, `faults_device_command_timeout_resets_engine`, `rtl_hostlink` |
| **Reset during execution** | `SF_RESET_ENGINES`: firmware aborts the wait, quiesces (TC08 ABORT, tile FLUSH) and resets the accelerator domain; every outstanding command → aborted; queues re-created; `SF_RESET_FULL`: cold boot | outstanding: `SF_ERR_ABORTED` | queues and buffers stay usable | `rtl_cc: recovery_reset_during_execution`, `recovery_full_reset_reboots_firmware`, `rtl_hostlink: queue_full_timeout_reset` |
| **ECC / RAS event** | SoC warning / fatal inputs → `cc_ras` → firmware ISRs record sources, counts, first error; level sources re-armed on query; device keeps working. (SECDED ECC of Project 26 is not integrated in this device) | reported by `sf_device_get_status` | — | `rtl_cc: recovery_ras_warning_and_fatal_events`; P21 self-test T11 (parity injection) |
| **Host interruption** | `sf_interrupt()` (SIGINT in the CLI) ends every wait | `SF_ERR_INTERRUPTED`, command still pending | `sf_clear_interrupt`, wait again; `sf_device_close` aborts instead of waiting | `api_cpu: threaded_interrupt_unblocks_wait`, `rtl_cc: recovery_host_interruption` |
| Device unresponsive | host-port / mailbox timeouts, protocol violations (e.g. an unsolicited boot message after a watchdog reset), HostLink FATAL | `SF_ERR_DEVICE_LOST` for everything outstanding and new | `sf_device_reset(SF_RESET_FULL)` (cold boot) | `rtl_cc: lost_unresponsive_device_then_full_reset` (`SF_INJECT_DEVICE_HANG`: device memory stops accepting requests → firmware stalls → watchdog reset → detected → full reset → GEMM correct) |

**Never hang:** every wait loop checks device time, `sf_interrupt`, and (for simulators) a wall-clock guard
(`SILICAFLUX_SIM_WALL_TIMEOUT_S`, default 900 s); every mailbox exchange and host-port access has a cycle bound; every
firmware engine wait has a cycle bound.
