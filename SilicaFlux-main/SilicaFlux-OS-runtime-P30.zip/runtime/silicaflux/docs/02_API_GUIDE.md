# 02 — SilicaFlux Compute API guide (C ABI 1.0)

Header: `include/silicaflux/silicaflux.h`. Library: `libsilicaflux.so.1`. Every function returns `sf_status`
(0 = success, 1 = `SF_PENDING`, < 0 = error); `sf_last_error_detail()` gives a thread-local explanation.

## 1. Minimal program

```c
#include <silicaflux/silicaflux.h>

sf_device_t dev;  sf_queue_t q;  sf_buffer_t a, b, c;  sf_cmd_t id;
sf_device_open_by_name("rtl-cc", 0, &dev);                 /* or "cpu", "rtl-hostlink", "pcie:0000:01:00.0" */
sf_queue_create(dev, 8, &q);
sf_buffer_create(dev, M * K, SF_MEM_INPUT, &a);           /* device memory, zeroed, 64-byte aligned */
sf_buffer_create(dev, K * N, SF_MEM_INPUT, &b);
sf_buffer_create(dev, 4 * M * N, SF_MEM_OUTPUT, &c);
sf_buffer_write(a, 0, A, M * K);  sf_buffer_write(b, 0, B, K * N);
sf_gemm_desc g = {sizeof g};  g.m = M; g.n = N; g.k = K;
g.a_type = g.b_type = SF_DTYPE_I8;  g.c_type = SF_DTYPE_I32;
sf_tensor_gemm(q, a, b, c, &g, &id);
sf_cmd_result r = {sizeof r};
sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r);              /* r.exec_target says WHERE it ran */
sf_buffer_read(c, 0, C, 4 * M * N);
sf_device_close(dev);                                      /* releases queues and buffers */
```

## 2. Devices

| Function | Notes |
|---|---|
| `sf_get_device_count`, `sf_get_device_info(index)` | Discovery without opening. Lists `cpu`, built RTL simulators, and PCIe functions whose IDs were configured (docs/09). `available = 0` entries explain why in `description`. |
| `sf_device_open(index, flags)`, `sf_device_open_by_name` | Exclusive. RTL `rtl-cc` boots the ControlCore (≈ 800 k simulated cycles, ≈ 7 s here) and performs the SFRQ handshake. Flags: `SF_OPEN_ALLOW_CPU_FALLBACK`, `SF_OPEN_TRACE_CONSOLE`. |
| `sf_device_get_info` | Full capabilities (`SF_CAP_*`), versions (device ABI, firmware, hardware revision), limits (memory, queues, lanes, GEMM dimensions), nominal clock of simulators. |
| `sf_device_reset(SF_RESET_ENGINES / SF_RESET_FULL)` | Every outstanding command completes with `SF_ERR_ABORTED`; queues and buffers stay valid. ENGINES: abort rings + quiesced accelerator reset; FULL: cold reset (ControlCore re-boot / HostLink hot reset). |
| `sf_device_get_status` | `READY / DEGRADED / ERROR / LOST`, RAS counts and source masks, command counters, a detail string. |
| `sf_device_selftest` | Device-resident suite (rtl-cc: the P21 firmware's 231-check self-test). Runs only when idle. |
| `sf_device_read_console` | Firmware console text (simulators). |
| `sf_device_close` | Bounded wait for outstanding work (aborts it when the process was interrupted), destroys queues, releases buffers, shuts the transport down. |

## 3. Memory

```c
sf_buffer_create(dev, size, flags, &buf);       sf_buffer_release(buf);
sf_buffer_write(buf, offset, src, size);         sf_buffer_read(buf, offset, dst, size);
sf_buffer_sync(buf, timeout_ms);                 sf_buffer_create_view(parent, offset, size, flags, &view);
```

| Topic | Contract |
|---|---|
| **Device vs host ownership** | A buffer is **device-owned** from the submission of a command that uses it until that command retires. `sf_buffer_write` fails with `SF_ERR_BUSY` while any pending command uses the buffer; `sf_buffer_read` fails while a pending command *writes* it. `sf_buffer_sync` waits (bounded) until ownership returns. Ownership is tracked on the root allocation (views included). |
| **Alignment** | Every allocation is aligned to `min_alignment` (64). Views must start at a multiple of 4. Engines' own rules (e.g. INT32 GEMM output 4-aligned) are guaranteed by these. |
| **Allocation failure** | `SF_ERR_OUT_OF_MEMORY` with the in-use / total figures in the detail; never fatal. First-fit allocator with coalescing. |
| **Lifetime** | Handles are reference counted. `sf_buffer_release` invalidates the handle at once; the memory is freed only after the last command using it retires. A released handle is detected (`SF_ERR_INVALID_BUFFER`), never dereferenced. Closing a device releases all its buffers. |
| **Synchronisation** | Writes/reads are blocking and complete before returning. Commands in one queue execute and complete in order; there is no ordering between queues (use `sf_queue_wait` / `sf_buffer_sync`). |
| **Permissions** | `SF_MEM_DEVICE_READ / DEVICE_WRITE` (what commands may do) and `SF_MEM_HOST_WRITE / HOST_READ` (what the host may do). Violations: `SF_ERR_PERMISSION`. Shorthands: `SF_MEM_INPUT`, `SF_MEM_OUTPUT`, `SF_MEM_READ_WRITE`. A view's flags must be a subset of its parent's. |
| **DMA mapping** | The device never sees a host pointer. On HostLink (simulated or VFIO) the runtime copies user data into an **IOMMU-mapped staging pool** whose IOVA range is the only host memory the device can reach (P25 isolation windows add a second, coarser fence). On `rtl-cc` the transport writes device memory through the harness window (model of a host-mapped BAR). On `cpu` buffers are host memory addressed by device offsets. |
| **Device addresses** | `sf_buffer_get_info(...).device_address` is informational (bus address); never dereference it. |

## 4. Queues and commands

| Function | Contract |
|---|---|
| `sf_queue_create(dev, depth, &q)` | `depth` = maximum submitted-but-not-retired commands (≤ `max_queue_depth`). |
| compute calls / `sf_queue_marker` | Non-blocking submission. Beyond `depth`: **`SF_ERR_QUEUE_FULL`, nothing submitted, no side effect** — a ring slot is never overwritten. Hardware rings have their own guard (firmware stalls rather than overwrite an unconsumed completion; HostLink validates doorbells). |
| `sf_queue_poll(q, cmd, &res)` | `SF_OK` (retired; result filled), `SF_PENDING`, or the command's error. Advances a simulator by one bounded slice. Results stay retrievable (the last 4096 per queue). |
| `sf_queue_wait(q, cmd or SF_CMD_ALL, timeout_ms, &res)` | Bounded. Returns the command's status, or `SF_ERR_TIMEOUT` / `SF_ERR_INTERRUPTED` while the command **stays pending** (wait again, or reset). |
| `sf_queue_pending` | Outstanding commands. |
| `sf_interrupt()` / `sf_clear_interrupt()` | Async-signal-safe: every wait returns `SF_ERR_INTERRUPTED` until cleared. The CLI installs it on SIGINT. |
| `sf_queue_destroy` | Bounded wait, then aborts what remains. |

**Ordering:** commands of one queue start in submission order and retire in submission order (in-order device
contract on every backend). A host-executed CPU-fallback command acts as a barrier: it runs after every older command
of its queue retired and before any younger one starts.

`sf_cmd_result` reports: `status`, **`exec_target`** (hardware / RTL simulation / CPU reference / CPU fallback /
none), raw `device_status`/`device_error`, IEEE `fp_flags`, `engine_cycles`, device timestamps
(`device_start_cycle`, `device_end_cycle`, `device_queue_cycles`), host timestamps (`host_submit_ns`,
`host_complete_ns`), `elements`, `macs`, `device_commands`, flags (`HOST_ASSISTED`, `SATURATED`, `FP_FLAGS`,
`CHUNKED`), and `scalar_bits` for dot products.

## 5. Compute API

| Call | Semantics | Precisions | Rejected |
|---|---|---|---|
| `sf_vector_add / mul` | `d = a ± b`, `d = a·b` elementwise | F32 (5 rounding modes), I32 (wrapping) | other dtypes; partial overlap of `d` with a source |
| `sf_vector_fma` | `d = fma(a, b, c)` one rounding | F32 | |
| `sf_vector_axpy` | `d = fma(alpha, x, y)` | F32 | |
| `sf_vector_dot` | `out = Σ round(a·b)` in the device's **defined order** (docs/04 §2) | F32 | |
| `sf_tensor_gemm` | `C = A·B` row-major, byte strides | A,B INT8; C INT32 exact or INT8 requantised (+ReLU) | non-INT8 operands, other outputs, `lda<k`…, C aliasing A/B, dims beyond the device |
| `sf_buffer_copy` | device-to-device copy, multiple of 4 bytes | — | overlap |
| `sf_debug_submit_raw` | a raw engine descriptor (tests of device-side validation) | — | devices without raw access |

Unsupported precisions or dimensions are **rejected** (`SF_ERR_UNSUPPORTED`); nothing is silently converted,
transposed or emulated. Only with `SF_OPEN_ALLOW_CPU_FALLBACK` does the runtime run an unsupported operation on the CPU
reference — and the result says `SF_EXEC_CPU_FALLBACK`.

## 6. Status codes

| Code | When |
|---|---|
| `SF_ERR_INVALID_ARGUMENT` | NULL pointers, zero sizes, bad enum values, bad strides, aliasing / partial overlap |
| `SF_ERR_NO_DEVICE` | unknown name, device absent / unavailable, backend not built, firmware image missing |
| `SF_ERR_UNSUPPORTED` | operation / precision / dimension the device lacks; injection on hardware |
| `SF_ERR_INCOMPATIBLE_VERSION` | firmware without SFRQ, SFRQ or HostLink ABI major ≠ 1, image rejected by the boot ROM |
| `SF_ERR_OUT_OF_MEMORY` | device memory (or HostLink staging) exhausted |
| `SF_ERR_INVALID_DEVICE / _BUFFER / _QUEUE` | bad, closed, released handles; buffer of another device |
| `SF_ERR_INVALID_COMMAND` | unknown command id; command rejected by device-side validation (engine status/error in the result) |
| `SF_ERR_OUT_OF_RANGE` | offset/size outside a buffer, footprint larger than the buffer |
| `SF_ERR_PERMISSION` | access flags forbid the access |
| `SF_ERR_BUSY` | buffer owned by the device, device already open, queue limit |
| `SF_ERR_QUEUE_FULL` | queue depth reached; nothing submitted |
| `SF_ERR_TIMEOUT` | host wait expired, or the device reported a command timeout (engine reset) |
| `SF_ERR_DMA` | bus / memory / IOMMU error during a transfer (device memory, host memory, PCIe) |
| `SF_ERR_DEVICE` | engine execution error (record codes in `device_status` / `device_error`) |
| `SF_ERR_ABORTED` | discarded by a reset or queue teardown, or skipped after an older failure |
| `SF_ERR_DEVICE_LOST` | device unresponsive or fatal; only `sf_device_reset(SF_RESET_FULL)` recovers |
| `SF_ERR_INTERRUPTED` | `sf_interrupt()` |
