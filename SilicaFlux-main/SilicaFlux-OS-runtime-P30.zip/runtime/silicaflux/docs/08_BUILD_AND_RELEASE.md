# 08 — Build, test and release engineering

## 1. Requirements

| Tool | Version used | Needed for |
|---|---|---|
| CMake ≥ 3.20, Ninja or Make, GCC/Clang with C++17 | CMake 3.28, GCC 13.3 | everything |
| Python 3 | 3.13 | firmware image tool (P21 `mkimage.py`), benchmark report |
| Verilator | **5.020** | RTL backends (`rtl-cc`, `rtl-hostlink`) |
| `gcc-riscv64-unknown-elf` | **13.2** | rebuilding ControlCore firmware (optional: prebuilt images are included) |
| Linux UAPI `<linux/vfio.h>` | 6.x | VFIO hardware backend (compile only) |

```bash
sudo apt-get install -y cmake ninja-build python3 verilator gcc-riscv64-unknown-elf
```

## 2. Build

```bash
cmake -S runtime/silicaflux -B build -G Ninja
```

```bash
cmake --build build
```

Options (auto-detected): `SF_ENABLE_RTL_CC`, `SF_ENABLE_RTL_HOSTLINK` (Verilator present), `SF_ENABLE_VFIO`
(`linux/vfio.h` present), `SF_BUILD_FIRMWARE` (RISC-V GCC present; otherwise `firmware/prebuilt/*.hex` are used),
`SF_BUILD_TESTS`, `SF_BUILD_EXAMPLES`, `SF_VERILATOR_JOBS`. A CPU-only build needs nothing but a C++ compiler:

```bash
cmake -S runtime/silicaflux -B build-cpu -DSF_ENABLE_RTL_CC=OFF -DSF_ENABLE_RTL_HOSTLINK=OFF
```

Build products: `libsilicaflux.so.1` (C ABI, hidden visibility, SONAME = API major), `silicaflux` CLI, examples,
tests, firmware images in `build/firmware/`. Verilated models are built by custom commands into
`build/verilated/{cc,hostlink}` (≈ 25 s and ≈ 13 s on 4 cores); one Verilator runtime library is shared by both.

## 3. Tests

```bash
ctest --test-dir build -L unit --output-on-failure
```

```bash
ctest --test-dir build -j 4 --output-on-failure
```

| Test (ctest name) | Label | What |
|---|---|---|
| `reference_arithmetic` | unit | soft-float vs host FPU (1.2 M ops) and binary128 (RMM), dot order, requantisation, GEMM |
| `api_cpu` | unit, fault | C API on the CPU backend: handles, ownership, permissions, queues, interruption, kernels, tracing |
| `hardware_absent` | unit, fault | physical discovery with no SilicaFlux hardware |
| `firmware_reproducible` | unit | rebuilt firmware images are byte-identical to `firmware/prebuilt/` (when RISC-V GCC is present) |
| `rtl_cc_kernels` | rtl | every kernel bit-exact vs reference, all rounding modes, chunking, counters, traces, differential vs CPU |
| `rtl_cc_faults` | rtl, fault | invalid commands, DMA failures, host and device timeouts, invalid handles |
| `rtl_cc_recovery` | rtl, fault | reset during execution, RAS events, interruption, full reset |
| `rtl_cc_compat` | rtl, fault | stock P21 firmware, SFRQ ABI 2.0 firmware, corrupted image, missing image |
| `rtl_cc_selftest` | rtl | P21 firmware self-test (231 checks) under the runtime firmware |
| `rtl_cc_lost` | rtl, fault | unresponsive device → `DEVICE_LOST` → full reset |
| `rtl_hostlink` | rtl, fault | DMA, GEMM, faults, queue/timeout/reset, counters, CPU fallback |
| `e2e_all_backends` | e2e, rtl | the 10-step GEMM flow on every available device; JSON report |
| `example_*` | examples | each example on `cpu` and on the RTL device(s) that support it |

## 4. Benchmarks

```bash
runtime/silicaflux/tools/run_benchmarks.sh build bench-results
```

Fixed seeds and sizes; environment and firmware checksum recorded; `SUMMARY.md` generated (docs/06 §5).

## 5. CI

`ci/github-actions.yml` (installed at the repository root as `.github/workflows/silicaflux-runtime.yml` by the
release archive): job **cpu-only** (no Verilator: library, CLI, examples, unit tests), job **rtl** (Ubuntu 24.04
packages Verilator 5.020 + RISC-V GCC 13.2: full build, firmware reproducibility, all ctest labels, benchmarks quick
run, artefacts: test logs, e2e report, benchmark summary).

## 6. Versioning and release

| Item | Version | Where |
|---|---|---|
| Library / C ABI | 1.0.0 / 1.0 | `CMakeLists.txt`, `silicaflux.h` (`SF_API_VERSION_*`), SONAME `.so.1` |
| SFRQ firmware ABI | 1.0 | `firmware/include/sf_rq_abi.h` |
| Runtime firmware | 2.0 | `SFRQ_FW_VERSION` |
| Trace / bench / e2e schemas | `silicaflux-trace/1`, `silicaflux-bench/1`, `silicaflux-e2e/1` | JSON `schema` field |

Install: `cmake --install build --prefix /opt/silicaflux` (library, header, CLI, firmware image, CMake package
`silicaflux::silicaflux`). Compatibility rules: docs/03; matrix: docs/COMPATIBILITY.md.
