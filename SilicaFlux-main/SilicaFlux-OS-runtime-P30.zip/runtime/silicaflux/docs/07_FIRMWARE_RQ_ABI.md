# 07 — ControlCore runtime firmware and the SFRQ ABI (version 1.0)

Normative description of the host ↔ ControlCore runtime-queue protocol. Single source:
`firmware/include/sf_rq_abi.h` (compiled unchanged into the RV32 firmware and the host runtime).

## 1. Firmware image `controlcore_rt` (firmware version 2.0)

| Part | Origin |
|---|---|
| boot ROM, `crt0`, trap entry, CRC32, platform (INTC, timer, watchdog, DMA, RAS ISRs), accelerator orchestration (`accel.c`), P21 self-test, libc subset, M08 tile driver, TC08 tensor driver | P21, **byte-identical** (vendored) |
| `app/main_rt.c` | replaces P21 `main.c`: same boot stages, POST, host lock and capability message; every P21 mailbox command kept with identical behaviour; SFRQ commands added |
| `app/rq.c` | runtime-queue engine (this document) |

Build: `riscv64-unknown-elf-gcc 13.2 -march=rv32im_zicsr_zifencei -mabi=ilp32 -Os`, P21 linker script, P21
`mkimage.py` (256-byte header + CRC32). Size: ≈ 35.7 KB of 64 KiB IMEM, ≈ 13.6 KB of 32 KiB DMEM. Builds with
`-Wall -Wextra`, no warnings. Variants built for tests: `controlcore_rt_abi2` (`-DSFRQ_ABI_MAJOR_OVERRIDE=2u`) and
`controlcore_p21_stock` (unmodified P21 `main.c`).

Responsibilities (brief §11): host command consumption (rings), DMA setup (system DMA entries, tile KERNEL staging,
TC08 operand DMA through its descriptor), vector dispatch (tile driver `hpc_submit`), tensor dispatch (`tsu_submit`),
error handling (engine errors reported and the engine recovered: `hpc_resume`, `tsu_clear_error`; timeouts →
quiesced accelerator reset), performance counter collection (`PERF_DUMP`, `PERF_CLEAR`, counts), device status and
reset (`STATUS`, `RESET`).

## 2. Mailbox commands (P21 mailbox, unused range 0x30–0x3F)

Host: write `H2F_MSG1..7`, `H2F_MSG0 = cmd`, `H2F_RING`; wait for `host_irq`; read `F2H_MSG0..7`
(`F2H_MSG0 = status | cmd << 8 | seq << 16`); write `F2H_ACK`. Before writing a new command the host waits for
`DB_STATUS.H2F_PEND = 0`.

| Cmd | Name | Arguments → answer |
|---|---|---|
| 0x30 | HELLO | → MSG1 SFRQ ABI, MSG2 firmware version, MSG3 accelerator mask \| max queues << 8 \| log2 max depth << 16, MSG4 tile CONFIG0, MSG5 TC08 INFO, MSG6 K_MAX, MSG7 tile VL_MAX |
| 0x31 | INFO | → MSG1 scratchpad base, MSG2 scratchpad bytes, MSG3/4 TC08 memory window, MSG5 tile command-queue depth, MSG6 TC08 CAPS, MSG7 lanes \| data bytes << 8 \| counters << 16 |
| 0x32 | Q_CREATE | MSG1 = control block address → MSG1 queue id; `BAD_CMD` + reason (1 align, 2 range, 3 magic, 4 version, 5 depth, 6 overlap, 7 not empty, 8 no slot) |
| 0x33 | Q_DESTROY | MSG1 = queue id (taken after the entry in flight completes) |
| 0x34 | KICK | **no answer**: wakes the firmware |
| 0x35 | RESET | MSG1 = `QUEUES` \| `ACCEL`: aborts the entry in flight, drops every queue (no further completion is written), quiesced accelerator reset → MSG1 accelerator mask, MSG2 entries dropped |
| 0x36 | PERF_CLEAR | clear ControlCore, tile and tensor counters |
| 0x37 | STATUS | RAS status / counts / first error / sources seen; re-arms level-sensitive SoC inputs |
| 0x38 | COUNTS | entries executed / failed / aborted, timeouts, accelerator resets, system-DMA bytes, active queues |

`KICK`, `PING`, `HELLO`, `INFO`, `STATUS`, `RAS_DUMP`, `COUNTS` are answered even while an entry executes; other
commands are taken between entries. `RESET` interrupts the wait of the entry in flight.

## 3. Rings in device memory

Control block (64 B, 64-aligned, host-allocated): `MAGIC 'SFRQ'`, `VERSION`, `SQ_BASE`, `CQ_BASE`, `DEPTH`
(power of two, 2..64), host-written `SQ_TAIL`, `CQ_HEAD`; firmware-written `SQ_HEAD`, `CQ_TAIL`, `STATE`.

Submission entry (64 B): `w0 = opcode | flags << 8`, `w1` cookie, `w2` timeout (device cycles, 0 = 50 M), `w3` 0,
`w4..w15` payload:

| Opcode | Payload |
|---|---|
| 0x00 NOP | — |
| 0x01 VECTOR | tile descriptor CMD0..CMD7, forwarded unchanged (flag `CHAIN_SCALAR`: CMD2 := RESULT of this queue's previous VECTOR entry) |
| 0x02 GEMM | TENSORCORE 08 ABI v2 descriptor (12 words), forwarded unchanged |
| 0x03 DMA_COPY | src, dst, bytes (ControlCore system DMA) |
| 0x04 PERF_DUMP | device address of a 72-word telemetry block |

Completion entry (64 B): `w0` cookie, `w1 = status | opcode << 8`, `w2..w7` engine record (tile CPL_* / TC08
record / DMA code + bytes), `w8` SQ head, `w9` t_fetch, `w10` t_start, `w11/w12` t_end (64-bit), `w13`
`tsu_check` prediction, `w14` t_seen, `w15[0]` **phase — written last**.

Status: 0 OK, 1 BAD_OPCODE, 2 BAD_FIELD (nothing executed), 3 ENGINE_ERROR (record holds the engine's code),
4 TIMEOUT (accelerators were reset), 5 ABORTED, 6 NO_DEVICE, 7 DMA_ERROR.

## 4. Protocol rules

1. The host writes entries, then `SQ_TAIL`, then sends `KICK` (the firmware also re-checks tails on every 20 000-cycle
   timer tick, so a lost `KICK` costs latency, never correctness).
2. The firmware fetches strictly in order, one entry at a time, round-robin across queues.
3. It never fetches past `SQ_TAIL` and never writes a completion into a slot the host has not released
   (`CQ_TAIL + 1 == CQ_HEAD` → that queue stalls).
4. Exactly one completion per fetched entry, in order, phase written last (first pass phase = 1, toggles per wrap).
   Exception: after `RESET` nothing more is written to any queue.
5. Every engine wait is bounded by the entry's timeout and interruptible by `RESET`. On timeout the firmware
   quiesces the accelerators (TC08 `ABORT`, tile `FLUSH`, wait for `PMU.ACC_STATUS` idle) and resets the domain.
6. Engine errors are reported with the engine's own record and the engine is recovered so the next entry executes.
7. Timestamps are the ControlCore `mcycle`; `w14 → w10` (seen → start) is the firmware-measured queue delay.

The host side is `src/backends/rtl_cc/cc_backend.cpp` (`CcQueue`): it keeps at most `DEPTH − 1` entries outstanding,
checks the cookie of every completion, and maps statuses to `sf_status` (docs/02 §6).
