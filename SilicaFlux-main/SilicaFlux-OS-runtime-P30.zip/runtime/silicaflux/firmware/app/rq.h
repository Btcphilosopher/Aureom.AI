/* =============================================================================
 * SilicaFlux.OS ControlCore runtime firmware -- SFRQ runtime-queue engine
 * ===========================================================================*/
#ifndef RQ_H
#define RQ_H

#include "fw.h"
#include "sf_rq_abi.h"

/* firmware DMEM budget: per-slot "first seen" stamps are kept for queue-delay measurement */
#define RQ_MAX_DEPTH_FW 64u

/* mailbox bookkeeping shared by the main loop and the executor's wait loop */
extern uint32_t g_mb_done;      /* mailbox messages consumed */
extern int      g_mb_deferred;  /* a message is waiting for the main loop */
int  mailbox_new(void);
/* handle a message from inside a wait: returns 1 if the main loop must take over (RESET pending) */
int  mailbox_inline(void);
void mailbox_snapshot(uint32_t c[8], uint32_t *pending);
void mailbox_respond(uint32_t cmd, uint32_t sts, const uint32_t *d, int n);
int  mailbox_handle_light(const uint32_t c[8]);   /* 1 = handled (inline-safe command) */

void     rq_init(void);
int      rq_service(void);                        /* executes at most one entry; 1 if it did */
int      rq_has_work(void);
void     rq_note_tails(void);                     /* stamp newly visible entries (queue-delay measurement) */
void     rq_cmd_create(const uint32_t c[8]);
void     rq_cmd_destroy(const uint32_t c[8]);
void     rq_cmd_reset(const uint32_t c[8]);
void     rq_cmd_counts(void);
uint64_t mcycle64(void);
int      acc_quiesce_reset(void);                 /* stop engines at a boundary, then PMU reset */

#endif
