/* =============================================================================
 * SilicaFlux.OS ControlCore runtime firmware -- SFRQ runtime-queue engine
 *
 * Host command consumption: the host owns SQ/CQ rings in shared device memory
 * (sf_rq_abi.h).  The firmware fetches entries in order, forwards the carried
 * descriptor UNCHANGED to the engine's own ABI through the vendored drivers
 * (tile: hpc_submit, tensor unit: tsu_submit, system DMA: dma_start), waits for
 * the engine's completion interrupt (bounded by the entry's timeout, and
 * abortable by the host), and posts one completion entry per submission entry,
 * in order, phase tag last.  It never overwrites an unconsumed completion
 * (CQ full -> the queue stalls), and never fetches past the host's tail.
 * ===========================================================================*/
#include "rq.h"

typedef struct {
  int      active;
  uint32_t cb, sq, cq, depth;
  uint32_t sq_head, cq_tail, phase;
  uint32_t last_result;          /* RESULT of the previous VECTOR command (CHAIN_SCALAR) */
  uint32_t tail_seen;            /* last SQ tail observed */
  uint32_t seen[RQ_MAX_DEPTH_FW];/* t_seen per SQ slot */
} rq_t;

static rq_t     g_q[SFRQ_MAX_QUEUES];
static uint32_t g_rr;
static struct { uint32_t executed, failed, aborted, timeouts, acc_resets, dma_bytes; } g_cnt;
static void g_cnt_acc_resets_inc(void) { g_cnt.acc_resets++; }

#define CB(q, w) REG32((q)->cb + 4u * (w))

uint64_t mcycle64(void) {
  uint32_t hi, lo, hi2;
  do {
    hi = csr_read(mcycleh);
    lo = csr_read(mcycle);
    hi2 = csr_read(mcycleh);
  } while (hi != hi2);
  return ((uint64_t)hi << 32) | lo;
}

void rq_init(void) {
  memset(g_q, 0, sizeof g_q);
  memset(&g_cnt, 0, sizeof g_cnt);
  g_rr = 0;
}

static int in_devmem(uint32_t a, uint32_t bytes) {
  return a >= CC_DEVMEM_BASE && bytes <= CC_DEVMEM_SIZE && a - CC_DEVMEM_BASE <= CC_DEVMEM_SIZE - bytes;
}
static int overlap(uint32_t a, uint32_t an, uint32_t b, uint32_t bn) { return a < b + bn && b < a + an; }

/* ------------------------------------------------------------------ safe accelerator-domain reset */
/* A PMU reset applied while an engine has a transaction outstanding on the shared
 * device-memory port leaves that port with a response nobody will accept: the
 * next ControlCore access to device memory then stalls the CPU (found on the RTL:
 * watchdog reset).  So: stop the engines at a command boundary first (tensor unit
 * CTRL.ABORT, tile FLUSH), wait until neither is busy and the external port is
 * idle, then reset.  A halted tensor unit cannot be drained: reset immediately. */
#define ACC_ST_EXT_IDLE   (1u << 3)
#define ACC_ST_VEC_BUSY   (1u << 4)
#define ACC_ST_TSU_BUSY   (1u << 5)
#define ACC_ST_TSU_HALTED (1u << 6)
int acc_quiesce_reset(void) {
  uint32_t t0 = cycles();
  if (g_acc.tsu_present) tsu_abort();
  if (g_acc.vec_present) (void)hpc_flush(CC_VECTOR_BASE, 200000u);
  for (;;) {
    uint32_t st = PMU(CC_PMU_ACC_STATUS);
    if (st & ACC_ST_TSU_HALTED) break;
    if (!(st & (ACC_ST_VEC_BUSY | ACC_ST_TSU_BUSY)) && (st & ACC_ST_EXT_IDLE)) break;
    if (cycles() - t0 > 4000000u) {
      cprintf("[rq] quiesce timeout (ACC_STATUS %x): resetting anyway\n", st);
      break;
    }
  }
  g_cnt_acc_resets_inc();
  return acc_reset();
}

/* ------------------------------------------------------------------ queue-delay stamps */
void rq_note_tails(void) {
  uint32_t now = (uint32_t)mcycle64();
  for (uint32_t i = 0; i < SFRQ_MAX_QUEUES; i++) {
    rq_t *q = &g_q[i];
    if (!q->active) continue;
    uint32_t t = CB(q, SFRQ_CB_SQ_TAIL);
    if (t >= q->depth) continue;
    while (q->tail_seen != t) {                       /* every newly visible slot */
      q->seen[q->tail_seen] = now;
      q->tail_seen = (q->tail_seen + 1u) & (q->depth - 1u);
    }
  }
}

int rq_has_work(void) {
  for (uint32_t i = 0; i < SFRQ_MAX_QUEUES; i++) {
    rq_t *q = &g_q[i];
    if (q->active && CB(q, SFRQ_CB_SQ_TAIL) != q->sq_head) return 1;
  }
  return 0;
}

/* ------------------------------------------------------------------ bounded, abortable waits */
static int ready_vec(void) { return vec_pending() != 0u; }
static int ready_tsu(void) { return tsu_pending() != 0u || g_acc.tsu_halted; }
static int ready_dma(void) { return g_dma_done != 0u; }

enum { W_READY = 0, W_ABORT = 1, W_TIMEOUT = 2 };
static int exec_wait(int (*ready)(void), uint32_t tmo) {
  uint32_t t0 = cycles();
  for (;;) {
    if (ready()) return W_READY;
    if (mailbox_new()) {
      if (mailbox_inline()) return W_ABORT;
      rq_note_tails();
      continue;
    }
    uint32_t el = cycles() - t0;
    if (el > tmo) return W_TIMEOUT;
    WAIT_UNTIL(ready() || mailbox_new(), tmo - el);
  }
}

/* ------------------------------------------------------------------ execution of one entry */
enum { X_DONE = 0, X_ABORTED = 1 };

static void post(rq_t *q, uint32_t cqe[16]) {
  uint32_t a = q->cq + SFRQ_CQE_BYTES * q->cq_tail;
  cqe[8] = (q->sq_head + 1u) & (q->depth - 1u);
  for (uint32_t w = 0; w < 15; w++) REG32(a + 4u * w) = cqe[w];
  REG32(a + 60u) = q->phase;                          /* phase tag written last */
  q->cq_tail = (q->cq_tail + 1u) & (q->depth - 1u);
  if (q->cq_tail == 0) q->phase ^= 1u;
}

static int exec_entry(rq_t *q, const uint32_t s[16], uint32_t cqe[16]) {
  uint32_t op = s[0] & 0xFFu, fl = (s[0] >> 8) & 0xFFu;
  uint32_t tmo = s[2] ? s[2] : SFRQ_DEFAULT_TIMEOUT;
  uint32_t st = SFRQ_ST_OK;
  cqe[0] = s[1];
  if ((s[0] >> 16) || s[3]) {
    st = SFRQ_ST_BAD_FIELD;
    goto out;
  }
  switch (op) {
    case SFRQ_OP_NOP:
      if (fl) st = SFRQ_ST_BAD_FIELD;
      cqe[10] = (uint32_t)mcycle64();
      break;

    case SFRQ_OP_VECTOR: {
      hpc_cmd_t c;
      hpc_cpl_t cpl;
      if (fl & ~SFRQ_F_CHAIN_SCALAR) { st = SFRQ_ST_BAD_FIELD; break; }
      if (!g_acc.vec_present) { st = SFRQ_ST_NO_DEVICE; break; }
      for (int i = 0; i < 8; i++) c.w[i] = s[4 + i];
      if (fl & SFRQ_F_CHAIN_SCALAR) c.w[2] = q->last_result;
      cqe[10] = (uint32_t)mcycle64();
      if (vec_submit(&c)) { st = SFRQ_ST_ENGINE_ERROR; cqe[2] = 0xFFFFFFFFu; break; }
      int w = exec_wait(ready_vec, tmo);
      if (w == W_ABORT) return X_ABORTED;
      if (w == W_TIMEOUT) {
        st = SFRQ_ST_TIMEOUT;
        g_cnt.timeouts++;
        acc_quiesce_reset();
        break;
      }
      vec_wait(&cpl, 0);
      cqe[2] = (uint32_t)cpl.tag | ((uint32_t)cpl.status << 8) | ((uint32_t)cpl.type << 12) |
               ((uint32_t)cpl.detail << 16) | ((uint32_t)cpl.fflags << 20) | ((uint32_t)cpl.step << 25);
      cqe[3] = cpl.seq;
      cqe[4] = cpl.count;
      cqe[5] = cpl.result;
      cqe[6] = cpl.err_addr;
      cqe[7] = cpl.cycles;
      if (cpl.status != HPC_ST_OK) {
        st = SFRQ_ST_ENGINE_ERROR;
        ras_report(0, 0xA0000000u | cpl.status);
        hpc_resume(CC_VECTOR_BASE);                    /* tile halts on error: resume for the next entry */
        cprintf("[rq] VECTOR tag %02x -> tile status %u detail %u step %u\n", cpl.tag, cpl.status, cpl.detail,
                cpl.step);
      } else {
        q->last_result = cpl.result;
      }
      break;
    }

    case SFRQ_OP_GEMM: {
      uint32_t d[TSU_DESC_WORDS];
      tsu_record_t rec;
      if (fl) { st = SFRQ_ST_BAD_FIELD; break; }
      if (!g_acc.tsu_present) { st = SFRQ_ST_NO_DEVICE; break; }
      for (unsigned i = 0; i < TSU_DESC_WORDS; i++) d[i] = s[4 + i];
      cqe[13] = (uint32_t)tsu_check(&g_acc.tsu, d);    /* driver's prediction, reported only */
      cqe[10] = (uint32_t)mcycle64();
      if (tsu_submit_irq(d)) { st = SFRQ_ST_ENGINE_ERROR; cqe[2] = 0xFFFFFFFFu; break; }
      int w = exec_wait(ready_tsu, tmo);
      if (w == W_ABORT) return X_ABORTED;
      if (w == W_TIMEOUT) {
        st = SFRQ_ST_TIMEOUT;
        g_cnt.timeouts++;
        acc_quiesce_reset();
        break;
      }
      int rc = tsu_wait_irq(&rec, 0);
      if (rc) {                                        /* halted: only a domain reset recovers */
        st = SFRQ_ST_ENGINE_ERROR;
        cqe[2] = 0xFFFFFF00u | (uint32_t)(-rc & 0xFF);
        acc_quiesce_reset();
        break;
      }
      for (int i = 0; i < 6; i++) cqe[2 + i] = rec.raw[i];
      if (rec.status != TSU_ST_OK) {
        st = SFRQ_ST_ENGINE_ERROR;
        ras_report(0, 0xB0000000u | rec.err);
        tsu_clear_error();                             /* stop-on-error: clear so the next entry executes */
        cprintf("[rq] GEMM tid %02x -> status %u err %02x (predicted %02x)\n", rec.tid, rec.status, rec.err,
                cqe[13]);
      }
      break;
    }

    case SFRQ_OP_DMA_COPY: {
      if (fl) { st = SFRQ_ST_BAD_FIELD; break; }
      cqe[10] = (uint32_t)mcycle64();
      int r = dma_start(s[4], s[5], s[6]);
      if (r) { st = SFRQ_ST_DMA_ERROR; cqe[2] = 0xFFFFFFFFu; break; }
      int w = exec_wait(ready_dma, tmo);
      if (w != W_READY) {                              /* the DMA is not abortable: let it finish (bounded) */
        uint32_t t0 = cycles();
        while ((DMA(CC_DMA_STATUS) & CC_DMA_STATUS_BUSY) && cycles() - t0 < 1000000u) {}
        if (w == W_ABORT) return X_ABORTED;
        st = SFRQ_ST_TIMEOUT;
        g_cnt.timeouts++;
        break;
      }
      cqe[3] = DMA(CC_DMA_BYTES_DONE);
      g_cnt.dma_bytes += cqe[3];
      if (g_dma_status & CC_DMA_STATUS_ERROR) {
        st = SFRQ_ST_DMA_ERROR;
        cqe[2] = DMA(CC_DMA_ERROR_CODE) & 0xFu;
        cprintf("[rq] DMA %08x -> %08x (%u B) error %u\n", s[4], s[5], s[6], cqe[2]);
      }
      break;
    }

    case SFRQ_OP_PERF_DUMP:
      if (fl || (s[4] & 3u) || !in_devmem(s[4], 72u * 4u)) { st = SFRQ_ST_BAD_FIELD; break; }
      cqe[10] = (uint32_t)mcycle64();
      cqe[2] = perf_dump(s[4]);
      break;

    default:
      st = SFRQ_ST_BAD_OPCODE;
      break;
  }
out:
  {
    uint64_t t = mcycle64();
    cqe[11] = (uint32_t)t;
    cqe[12] = (uint32_t)(t >> 32);
  }
  if (!cqe[10]) cqe[10] = cqe[11];
  cqe[1] = st | (op << 8);
  g_cnt.executed++;
  if (st != SFRQ_ST_OK) g_cnt.failed++;
  return X_DONE;
}

int rq_service(void) {
  for (uint32_t k = 0; k < SFRQ_MAX_QUEUES; k++) {
    uint32_t i = (g_rr + k) % SFRQ_MAX_QUEUES;
    rq_t *q = &g_q[i];
    if (!q->active) continue;
    uint32_t tail = CB(q, SFRQ_CB_SQ_TAIL);
    if (tail >= q->depth || tail == q->sq_head) continue;          /* empty (or an illegal doorbell value) */
    uint32_t cq_head = CB(q, SFRQ_CB_CQ_HEAD);
    if (((q->cq_tail + 1u) & (q->depth - 1u)) == cq_head) continue; /* CQ full: never overwrite */
    rq_note_tails();
    uint32_t s[16], cqe[16];
    uint32_t a = q->sq + SFRQ_SQE_BYTES * q->sq_head;
    for (int w = 0; w < 16; w++) s[w] = REG32(a + 4u * w);
    memset(cqe, 0, sizeof cqe);
    cqe[9] = (uint32_t)mcycle64();
    cqe[14] = q->seen[q->sq_head];
    if (exec_entry(q, s, cqe) == X_ABORTED) return 1;              /* RESET pending: main loop handles it */
    post(q, cqe);
    q->sq_head = (q->sq_head + 1u) & (q->depth - 1u);
    CB(q, SFRQ_CB_SQ_HEAD) = q->sq_head;
    CB(q, SFRQ_CB_CQ_TAIL) = q->cq_tail;
    g_rr = i + 1u;
    return 1;
  }
  return 0;
}

/* ------------------------------------------------------------------ control commands */
enum { CRE_OK = 0, CRE_ALIGN = 1, CRE_RANGE = 2, CRE_MAGIC = 3, CRE_VERSION = 4, CRE_DEPTH = 5, CRE_OVERLAP = 6,
       CRE_NOT_EMPTY = 7, CRE_NO_SLOT = 8 };

void rq_cmd_create(const uint32_t c[8]) {
  uint32_t cb = c[1], why = CRE_OK, id = 0;
  rq_t *q = 0;
  if (cb & 63u) { why = CRE_ALIGN; goto done; }
  if (!in_devmem(cb, SFRQ_CB_WORDS * 4u)) { why = CRE_RANGE; goto done; }
  uint32_t magic = REG32(cb + 4u * SFRQ_CB_MAGIC), ver = REG32(cb + 4u * SFRQ_CB_VERSION);
  uint32_t sq = REG32(cb + 4u * SFRQ_CB_SQ_BASE), cq = REG32(cb + 4u * SFRQ_CB_CQ_BASE);
  uint32_t depth = REG32(cb + 4u * SFRQ_CB_DEPTH);
  if (magic != SFRQ_MAGIC) { why = CRE_MAGIC; goto done; }
  if ((ver >> 16) != SFRQ_ABI_MAJOR) { why = CRE_VERSION; goto done; }
  if (depth < SFRQ_MIN_DEPTH || depth > SFRQ_MAX_DEPTH || (depth & (depth - 1u))) { why = CRE_DEPTH; goto done; }
  if ((sq | cq) & 63u) { why = CRE_ALIGN; goto done; }
  if (!in_devmem(sq, depth * SFRQ_SQE_BYTES) || !in_devmem(cq, depth * SFRQ_CQE_BYTES)) { why = CRE_RANGE; goto done; }
  if (overlap(sq, depth * SFRQ_SQE_BYTES, cq, depth * SFRQ_CQE_BYTES) ||
      overlap(sq, depth * SFRQ_SQE_BYTES, cb, 64u) || overlap(cq, depth * SFRQ_CQE_BYTES, cb, 64u)) {
    why = CRE_OVERLAP; goto done;
  }
  if (REG32(cb + 4u * SFRQ_CB_SQ_TAIL) || REG32(cb + 4u * SFRQ_CB_CQ_HEAD)) { why = CRE_NOT_EMPTY; goto done; }
  for (id = 0; id < SFRQ_MAX_QUEUES; id++)
    if (!g_q[id].active) break;
  if (id == SFRQ_MAX_QUEUES) { why = CRE_NO_SLOT; goto done; }
  q = &g_q[id];
  memset(q, 0, sizeof *q);
  q->cb = cb; q->sq = sq; q->cq = cq; q->depth = depth; q->phase = 1u;
  CB(q, SFRQ_CB_SQ_HEAD) = 0u;
  CB(q, SFRQ_CB_CQ_TAIL) = 0u;
  CB(q, SFRQ_CB_STATE) = SFRQ_STATE_ACTIVE;
  q->active = 1;
done:
  if (why) {
    uint32_t o[1] = {why};
    mailbox_respond(SFRQ_MBOX_Q_CREATE, SFRQ_MSTS_BAD_CMD, o, 1);
  } else {
    uint32_t o[1] = {id};
    mailbox_respond(SFRQ_MBOX_Q_CREATE, SFRQ_MSTS_OK, o, 1);
  }
}

void rq_cmd_destroy(const uint32_t c[8]) {
  uint32_t id = c[1];
  if (id >= SFRQ_MAX_QUEUES || !g_q[id].active) {
    mailbox_respond(SFRQ_MBOX_Q_DESTROY, SFRQ_MSTS_BAD_CMD, 0, 0);
    return;
  }
  rq_t *q = &g_q[id];
  CB(q, SFRQ_CB_STATE) = SFRQ_STATE_DESTROYED;
  q->active = 0;
  mailbox_respond(SFRQ_MBOX_Q_DESTROY, SFRQ_MSTS_OK, 0, 0);
}

void rq_cmd_reset(const uint32_t c[8]) {
  uint32_t flags = c[1], dropped = 0;
  int acc = -1;
  /* the system DMA cannot be aborted: let a running transfer finish first (bounded) */
  uint32_t t0 = cycles();
  while ((DMA(CC_DMA_STATUS) & CC_DMA_STATUS_BUSY) && cycles() - t0 < 1000000u) {}
  if (flags & SFRQ_RESET_ACCEL) acc = acc_quiesce_reset();
  for (uint32_t i = 0; i < SFRQ_MAX_QUEUES; i++) {
    rq_t *q = &g_q[i];
    if (!q->active) continue;
    uint32_t tail = CB(q, SFRQ_CB_SQ_TAIL);
    if (tail < q->depth) dropped += (tail - q->sq_head) & (q->depth - 1u);
    CB(q, SFRQ_CB_STATE) = SFRQ_STATE_ABORTED;
    q->active = 0;
  }
  g_cnt.aborted += dropped;
  cprintf("[rq] RESET flags %x: %u queued entries dropped, accelerators %d\n", flags, dropped, acc);
  uint32_t o[2] = {(uint32_t)acc, dropped};
  mailbox_respond(SFRQ_MBOX_RESET, SFRQ_MSTS_OK, o, 2);
}

void rq_cmd_counts(void) {
  uint32_t act = 0;
  for (uint32_t i = 0; i < SFRQ_MAX_QUEUES; i++) act += g_q[i].active ? 1u : 0u;
  uint32_t o[7] = {g_cnt.executed, g_cnt.failed, g_cnt.aborted, g_cnt.timeouts, g_cnt.acc_resets, g_cnt.dma_bytes, act};
  mailbox_respond(SFRQ_MBOX_COUNTS, SFRQ_MSTS_OK, o, 7);
}
