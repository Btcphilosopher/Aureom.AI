/* =============================================================================
 * SilicaFlux.OS ControlCore runtime firmware 2.0 -- main
 *
 * Replaces P21 firmware/app/main.c (every other P21 firmware file is used
 * byte-identical).  Boot stages, POST, host lock, capability message and every
 * P21 mailbox command (PING, RUN_SELFTEST, GEMM, VECTOR_KERNEL, DMA_COPY,
 * PERF_DUMP, RAS_DUMP, SHUTDOWN) behave exactly as in P21 firmware 1.0; this
 * version adds the SFRQ runtime-queue engine (rq.c, sf_rq_abi.h):
 *   HELLO / INFO       ABI handshake and capabilities
 *   Q_CREATE / DESTROY rings in device memory
 *   KICK               doorbell wake-up (no answer)
 *   RESET              abort queues, reset the accelerator domain
 *   PERF_CLEAR, STATUS (RAS + re-arm), COUNTS
 * Main loop: mailbox first, then one queue entry, then sleep (WFI) until a
 * mailbox interrupt, the timer tick, or a visible queue entry.
 * ===========================================================================*/
#include "rq.h"

static uint32_t reset_cause;
uint32_t g_mb_done;
int      g_mb_deferred;

void mailbox_respond(uint32_t cmd, uint32_t sts, const uint32_t *d, int n) {
  for (int i = 0; i < n && i < 7; i++) MBOX_F2H(1 + i) = d[i];
  MBOX_F2H(0) = sts | (cmd << 8) | ((g_cmd_seq & 0xFFFFu) << 16);
  MBOX(CC_MBOX_F2H_RING) = cmd;
}

void mailbox_snapshot(uint32_t c[8], uint32_t *pending) {
  uint32_t m = irq_save();
  for (int i = 0; i < 8; i++) c[i] = g_cmd[i];
  *pending = g_cmd_pending;
  irq_restore(m);
}

int mailbox_new(void) { return g_cmd_pending != g_mb_done && !g_mb_deferred; }

/* ------------------------------------------------------------------ P21 commands (unchanged behaviour) */
static int post(void) {
  int fails = 0;
  hpc_cpl_t cpl;
  tsu_record_t rec;
  uint32_t d[TSU_DESC_WORDS];
  if (g_acc.vec_present) {
    hpc_cmd_t c = hpc_cmd_nop(0x01, 0u);
    if (vec_run(&c, &cpl) || cpl.status != HPC_ST_OK || cpl.tag != 0x01) fails++;
  }
  if (g_acc.tsu_present) {
    tsu_build_nop(d, 0x01, 1);
    if (tsu_run(d, &rec) || rec.status != TSU_ST_OK || rec.tid != 0x01) fails++;
  }
  static uint32_t s[4] = {1, 2, 3, 4}, t[4];
  if (dma_copy((uint32_t)(uintptr_t)s, (uint32_t)(uintptr_t)t, 16u) || memcmp(s, t, 16)) fails++;
  if (RAS(CC_RAS_PAR_CHK_EN) != 1u) fails++;
  return fails;
}

static void cmd_gemm(const uint32_t *c) {
  uint32_t d[TSU_DESC_WORDS], out[7];
  tsu_record_t rec;
  if (!g_acc.tsu_present) { mailbox_respond(CC_MBOX_CMD_GEMM, CC_MBOX_STS_NO_DEVICE, 0, 0); return; }
  for (unsigned i = 0; i < TSU_DESC_WORDS; i++) d[i] = REG32(c[1] + 4u * i);
  int pred = tsu_check(&g_acc.tsu, d);
  int rc = tsu_run(d, &rec);
  for (int i = 0; i < 6; i++) out[i] = rec.raw[i];
  out[6] = (uint32_t)pred;
  uint32_t sts = rc ? CC_MBOX_STS_TIMEOUT : (rec.status == TSU_ST_OK ? CC_MBOX_STS_OK : CC_MBOX_STS_ACC_ERROR);
  if (!rc && rec.status != TSU_ST_OK) {
    ras_report(0, 0xB0000000u | rec.err);
    tsu_clear_error();
  }
  mailbox_respond(CC_MBOX_CMD_GEMM, sts, out, 7);
}

static void cmd_vector(const uint32_t *cm) {
  hpc_cmd_t c;
  hpc_cpl_t cpl;
  if (!g_acc.vec_present) { mailbox_respond(CC_MBOX_CMD_VECTOR_KERNEL, CC_MBOX_STS_NO_DEVICE, 0, 0); return; }
  for (int i = 0; i < 8; i++) c.w[i] = REG32(cm[1] + 4u * i);
  int rc = vec_run(&c, &cpl);
  uint32_t out[6] = {(uint32_t)cpl.tag | ((uint32_t)cpl.status << 8) | ((uint32_t)cpl.type << 12) |
                         ((uint32_t)cpl.detail << 16) | ((uint32_t)cpl.fflags << 20) | ((uint32_t)cpl.step << 25),
                     cpl.seq, cpl.count, cpl.result, cpl.err_addr, cpl.cycles};
  uint32_t sts = rc ? CC_MBOX_STS_TIMEOUT : (cpl.status == HPC_ST_OK ? CC_MBOX_STS_OK : CC_MBOX_STS_ACC_ERROR);
  if (!rc && cpl.status != HPC_ST_OK) {
    ras_report(0, 0xA0000000u | cpl.status);
    hpc_resume(CC_VECTOR_BASE);
  }
  mailbox_respond(CC_MBOX_CMD_VECTOR_KERNEL, sts, out, 6);
}

static void ras_status(uint32_t cmd) {
  uint32_t o[7] = {RAS(CC_RAS_STATUS), RAS(CC_RAS_WARN_COUNT), RAS(CC_RAS_FATAL_COUNT), RAS(CC_RAS_FIRST_SRC),
                   RAS(CC_RAS_FIRST_ADDR), g_ras_warn_bits, g_ras_fatal_bits};
  if (cmd == SFRQ_MBOX_STATUS) {
    /* re-arm the level-sensitive SoC inputs the ISRs masked: a source still asserted fires again */
    RAS(CC_RAS_WARN_EN) = RAS(CC_RAS_WARN_EN) | (1u << CC_RAS_SRC_EXT_WARN);
    RAS(CC_RAS_FATAL_EN) = RAS(CC_RAS_FATAL_EN) | (1u << (CC_RAS_SRC_EXT_FATAL - 8));
  }
  mailbox_respond(cmd, CC_MBOX_STS_OK, o, 7);
}

/* commands that are safe to answer while a queue entry is executing */
int mailbox_handle_light(const uint32_t c[8]) {
  uint32_t cmd = c[0];
  switch (cmd) {
    case SFRQ_MBOX_KICK:
      return 1;
    case CC_MBOX_CMD_PING: {
      uint32_t o[2] = {c[1], SFRQ_FW_VERSION};
      mailbox_respond(cmd, CC_MBOX_STS_OK, o, 2);
      return 1;
    }
    case SFRQ_MBOX_HELLO: {
      uint32_t o[7] = {SFRQ_ABI_VERSION, SFRQ_FW_VERSION,
                       (uint32_t)(g_acc.vec_present | (g_acc.tsu_present << 1)) | (SFRQ_MAX_QUEUES << 8) |
                           ((uint32_t)__builtin_ctz(SFRQ_MAX_DEPTH) << 16),
                       g_acc.vec_present ? HPC_REG(CC_VECTOR_BASE, HPC_REG_CONFIG0) : 0u, g_acc.tsu.info,
                       g_acc.tsu.k_max, g_acc.vec_present ? g_acc.vec.vl_max : 0u};
      mailbox_respond(cmd, CC_MBOX_STS_OK, o, 7);
      return 1;
    }
    case SFRQ_MBOX_INFO: {
      uint32_t o[7] = {g_acc.vec.spm_base, g_acc.vec_present ? (1u << g_acc.vec.spm_log2) : 0u, g_acc.tsu.mem_lo,
                       g_acc.tsu.mem_last, g_acc.vec.cmdq_depth, g_acc.tsu.caps,
                       g_acc.vec.lanes | (g_acc.vec.data_bytes << 8) | (g_acc.vec.num_perf << 16)};
      mailbox_respond(cmd, CC_MBOX_STS_OK, o, 7);
      return 1;
    }
    case SFRQ_MBOX_STATUS:
    case CC_MBOX_CMD_RAS_DUMP:
      ras_status(cmd);
      return 1;
    case SFRQ_MBOX_COUNTS:
      rq_cmd_counts();
      return 1;
    default:
      return 0;
  }
}

int mailbox_inline(void) {
  uint32_t c[8], p;
  mailbox_snapshot(c, &p);
  if (mailbox_handle_light(c)) {
    g_mb_done = p;
    g_cmd_seq++;
    return 0;
  }
  g_mb_deferred = 1;                                   /* the main loop answers it after this entry */
  return c[0] == SFRQ_MBOX_RESET;
}

static void mailbox_dispatch(const uint32_t c[8]) {
  uint32_t cmd = c[0];
  if (mailbox_handle_light(c)) return;
  switch (cmd) {
    case CC_MBOX_CMD_RUN_SELFTEST: {
      uint32_t c0 = g_tally.checks, f0 = g_tally.fails;
      uint32_t f = selftest_run(c[1] ? c[1] : ST_ALL);
      uint32_t o[2] = {g_tally.checks - c0, f};
      (void)f0;
      boot_stage(CC_BOOT_STAGE_HOST_READY);
      mailbox_respond(cmd, CC_MBOX_STS_OK, o, 2);
      break;
    }
    case CC_MBOX_CMD_GEMM: cmd_gemm(c); break;
    case CC_MBOX_CMD_VECTOR_KERNEL: cmd_vector(c); break;
    case CC_MBOX_CMD_DMA_COPY: {
      int rc = dma_copy(c[1], c[2], c[3]);
      uint32_t out[2] = {(uint32_t)rc, DMA(CC_DMA_BYTES_DONE)};
      mailbox_respond(cmd, rc ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK, out, 2);
      break;
    }
    case CC_MBOX_CMD_PERF_DUMP: {
      uint32_t o[1] = {perf_dump(c[1])};
      mailbox_respond(cmd, CC_MBOX_STS_OK, o, 1);
      break;
    }
    case CC_MBOX_CMD_SHUTDOWN: {
      uint32_t fails = g_tally.fails + c[1];
      cprintf("SHUTDOWN: firmware checks=%u fails=%u, host-reported fails=%u -> %s\n", g_tally.checks,
              g_tally.fails, c[1], fails ? "FAIL" : "PASS");
      uint32_t o[2] = {g_tally.checks, g_tally.fails};
      mailbox_respond(cmd, CC_MBOX_STS_OK, o, 2);
      boot_stage(CC_BOOT_STAGE_SHUTDOWN);
      SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0x80000000u | (fails ? 0x40000000u : 0u) | (fails & 0xFFFFu);
      break;
    }
    case SFRQ_MBOX_Q_CREATE: rq_cmd_create(c); break;
    case SFRQ_MBOX_Q_DESTROY: rq_cmd_destroy(c); break;
    case SFRQ_MBOX_RESET: rq_cmd_reset(c); break;
    case SFRQ_MBOX_PERF_CLEAR:
      PERF(CC_PERF_CTRL) = 2u;                          /* [1] clear all ControlCore counters */
      if (g_acc.vec_present) hpc_perf_clear(CC_VECTOR_BASE);
      if (g_acc.tsu_present) tsu_clear_counters();
      mailbox_respond(cmd, CC_MBOX_STS_OK, 0, 0);
      break;
    default:
      mailbox_respond(cmd, CC_MBOX_STS_BAD_CMD, 0, 0);
      break;
  }
}

int main(void) {
  boot_stage(CC_BOOT_STAGE_FW_INIT);
  reset_cause = SYSCTRL(CC_SYSCTRL_RESET_CAUSE);
  SYSCTRL(CC_SYSCTRL_RESET_CAUSE) = 0xFu;
  uint32_t boot_status = SYSCTRL(CC_SYSCTRL_BOOT_STATUS);
  SYSCTRL(CC_SYSCTRL_FW_VERSION) = SFRQ_FW_VERSION;
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING;
  cprintf("\nSilicaFlux ControlCore runtime firmware %x.%x (SFRQ ABI %u.%u)  RV32IM misa=%08x\n",
          SFRQ_FW_VERSION >> 16, SFRQ_FW_VERSION & 0xFFFFu, SFRQ_ABI_VERSION >> 16, SFRQ_ABI_VERSION & 0xFFFFu,
          csr_read(misa));
  cprintf("map v%u.%u  reset cause=%x  boot status=%x  image crc=%08x (integrity only, NOT authenticated)\n",
          CC_MAP_VERSION >> 16, CC_MAP_VERSION & 0xFFFFu, reset_cause, boot_status, SEC(CC_SEC_BOOT_MEASURE));
  platform_init();
  rq_init();

  if ((reset_cause & CC_RESET_CAUSE_WDT) && SYSCTRL(CC_SYSCTRL_SCRATCH0) == SCRATCH_WDT_MARK) {
    SYSCTRL(CC_SYSCTRL_SCRATCH0) = SCRATCH_WDT_PASS;
    cprintf("[T15 watchdog reset] observed: cause=WDT, early warnings before reset=%u\n", SYSCTRL(CC_SYSCTRL_SCRATCH2));
  }

  boot_stage(CC_BOOT_STAGE_ACC_DISCOVERY);
  int acc = acc_discover();
  if (g_acc.vec_present)
    cprintf("vector tile : %u lanes, %u-bit, SPM %u KiB @%08x, queue %u, VL_MAX %u\n", g_acc.vec.lanes,
            8u * g_acc.vec.data_bytes, (1u << g_acc.vec.spm_log2) >> 10, g_acc.vec.spm_base, g_acc.vec.cmdq_depth,
            g_acc.vec.vl_max);
  else
    cprintf("vector tile : NOT PRESENT\n");
  if (g_acc.tsu_present)
    cprintf("tensor unit : ABI v%u, %ux%u array, K_MAX %u, window %08x..%08x\n", g_acc.tsu.info & 0xFu,
            (g_acc.tsu.info >> 8) & 0xFFu, (g_acc.tsu.info >> 16) & 0xFFu, g_acc.tsu.k_max, g_acc.tsu.mem_lo,
            g_acc.tsu.mem_last);
  else
    cprintf("tensor unit : NOT PRESENT\n");

  boot_stage(CC_BOOT_STAGE_SELF_TEST);
  int pf = post();
  cprintf("POST: %s\n", pf ? "FAIL" : "PASS");
  if (pf) g_tally.fails += (uint32_t)pf;

  SEC(CC_SEC_CTRL) = 1u;
  boot_stage(CC_BOOT_STAGE_CMDPROC_READY);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING | CC_HOST_STATUS_CMDPROC_READY |
                                    (acc != 3 ? CC_HOST_STATUS_DEGRADED : 0u);
  boot_stage(CC_BOOT_STAGE_HOST_READY);
  uint32_t caps[6] = {(uint32_t)acc, g_acc.vec_present ? HPC_REG(CC_VECTOR_BASE, HPC_REG_CONFIG0) : 0u,
                      g_acc.tsu.info, reset_cause, SFRQ_FW_VERSION, SEC(CC_SEC_BOOT_MEASURE)};
  mailbox_respond(CC_MBOX_CMD_NONE, pf ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK, caps, 6);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = SYSCTRL(CC_SYSCTRL_HOST_STATUS) | CC_HOST_STATUS_HOST_READY;
  cprintf("HOST READY\n");

  for (;;) {
    if (g_cmd_pending != g_mb_done) {
      uint32_t c[8], p;
      mailbox_snapshot(c, &p);
      g_mb_done = p;
      g_mb_deferred = 0;
      g_cmd_seq++;
      mailbox_dispatch(c);
      continue;
    }
    if (rq_service()) continue;
    WAIT_UNTIL(g_cmd_pending != g_mb_done || rq_has_work(), 0xFFFFFFFFu);
  }
}
