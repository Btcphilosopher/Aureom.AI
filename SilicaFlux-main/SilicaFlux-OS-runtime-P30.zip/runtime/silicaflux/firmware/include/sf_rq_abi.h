/*
 * SilicaFlux.OS -- SFRQ: host <-> ControlCore runtime-queue ABI, version 1.0
 *
 * Single source of truth, compiled unchanged by the ControlCore firmware
 * (RV32IM, freestanding) and by the host runtime (C++17).  Normative text:
 * docs/07_FIRMWARE_RQ_ABI.md.
 *
 * Transport (unchanged P21 hardware):
 *   - rings and control blocks live in shared DEVICE MEMORY (CC_DEVMEM_BASE);
 *   - control commands use the P21 mailbox (H2F_MSG0..7 + H2F_RING; answer in
 *     F2H_MSG0 = status | cmd << 8 | seq << 16, F2H_MSG1..7, host F2H_ACK);
 *     SFRQ uses the unused command range 0x30..0x3F;
 *   - KICK is the only command without an answer: it just wakes the firmware.
 *
 * Descriptors are the accelerators' OWN ABIs, carried verbatim:
 *   VECTOR: 8-word HPC Module 08 tile descriptor (CMD0..7);
 *   GEMM  : 12-word TENSORCORE 08 descriptor, VERSION 2.
 * The firmware forwards them; the engines validate them.
 * All words little-endian 32-bit.  All structures 64-byte aligned.
 */
#ifndef SF_RQ_ABI_H
#define SF_RQ_ABI_H

#include <stdint.h>

#define SFRQ_ABI_MAJOR 1u
#define SFRQ_ABI_MINOR 0u
#ifdef SFRQ_ABI_MAJOR_OVERRIDE                 /* test builds only: an incompatible firmware revision */
#undef SFRQ_ABI_MAJOR
#define SFRQ_ABI_MAJOR SFRQ_ABI_MAJOR_OVERRIDE
#endif
#define SFRQ_ABI_VERSION ((SFRQ_ABI_MAJOR << 16) | SFRQ_ABI_MINOR)
#define SFRQ_MAGIC       0x51524653u           /* "SFRQ" */
#define SFRQ_FW_VERSION  0x00020000u           /* runtime firmware 2.0 (P21 firmware 1.0 + SFRQ) */

/* ------------------------------------------------------------------ mailbox commands */
#define SFRQ_MBOX_HELLO      0x30u  /* -> MSG1 abi, MSG2 fw version, MSG3 acc mask | max_queues<<8 | max_depth_log2<<16,
                                         MSG4 tile CONFIG0, MSG5 tsu INFO, MSG6 tsu K_MAX, MSG7 tile vl_max */
#define SFRQ_MBOX_INFO       0x31u  /* -> MSG1 tile spm_base, MSG2 tile spm bytes, MSG3 tsu MEM_LO, MSG4 tsu MEM_LAST,
                                         MSG5 tile cmdq depth, MSG6 tsu CAPS, MSG7 lanes | data_bytes<<8 | num_perf<<16 */
#define SFRQ_MBOX_Q_CREATE   0x32u  /* MSG1 = control block address -> MSG1 = queue id */
#define SFRQ_MBOX_Q_DESTROY  0x33u  /* MSG1 = queue id; waits for the command in flight */
#define SFRQ_MBOX_KICK       0x34u  /* no answer: new entries may be available */
#define SFRQ_MBOX_RESET      0x35u  /* MSG1 = SFRQ_RESET_*: abort every queue (+ reset the accelerator domain) */
#define SFRQ_MBOX_PERF_CLEAR 0x36u  /* clear ControlCore, tile and tensor counters */
#define SFRQ_MBOX_STATUS     0x37u  /* -> MSG1 RAS.STATUS, MSG2 warn count, MSG3 fatal count, MSG4 first src,
                                         MSG5 first addr, MSG6 warn bits seen, MSG7 fatal bits seen; re-arms level sources */
#define SFRQ_MBOX_COUNTS     0x38u  /* -> MSG1 commands executed, MSG2 failed, MSG3 aborted, MSG4 timeouts,
                                         MSG5 acc resets, MSG6 system-DMA bytes, MSG7 active queues */

#define SFRQ_RESET_QUEUES    0x1u   /* complete nothing further; drop every queue */
#define SFRQ_RESET_ACCEL     0x2u   /* PMU reset of the accelerator domain + rediscovery */

/* mailbox answer status (P21 codes, reused) */
#define SFRQ_MSTS_OK         0u
#define SFRQ_MSTS_BUSY       1u
#define SFRQ_MSTS_BAD_CMD    2u
#define SFRQ_MSTS_ACC_ERROR  3u
#define SFRQ_MSTS_TIMEOUT    4u
#define SFRQ_MSTS_NO_DEVICE  5u

/* ------------------------------------------------------------------ queue limits */
#define SFRQ_MAX_QUEUES      4u
#define SFRQ_MIN_DEPTH       2u
#define SFRQ_MAX_DEPTH       64u        /* power of two (firmware keeps a per-slot stamp in DMEM) */
#define SFRQ_SQE_BYTES       64u
#define SFRQ_CQE_BYTES       64u

/* ------------------------------------------------------------------ control block (64 B, host-allocated) */
/* word offsets */
#define SFRQ_CB_MAGIC        0u   /* host: SFRQ_MAGIC */
#define SFRQ_CB_VERSION      1u   /* host: SFRQ_ABI_VERSION */
#define SFRQ_CB_SQ_BASE      2u   /* host: device address of the SQ ring (64-aligned) */
#define SFRQ_CB_CQ_BASE      3u   /* host: device address of the CQ ring (64-aligned, zeroed) */
#define SFRQ_CB_DEPTH        4u   /* host: entries per ring, power of two, 2..64 */
#define SFRQ_CB_SQ_TAIL      5u   /* host-written doorbell: next SQ slot the host will fill */
#define SFRQ_CB_CQ_HEAD      6u   /* host-written: next CQ slot the host will consume */
#define SFRQ_CB_SQ_HEAD      8u   /* firmware-written: next SQ slot the firmware will fetch */
#define SFRQ_CB_CQ_TAIL      9u   /* firmware-written: next CQ slot the firmware will write */
#define SFRQ_CB_STATE       10u   /* firmware-written: SFRQ_STATE_* */
#define SFRQ_CB_WORDS       16u

#define SFRQ_STATE_ACTIVE    1u
#define SFRQ_STATE_DESTROYED 2u
#define SFRQ_STATE_ABORTED   3u

/* ------------------------------------------------------------------ submission entry (64 B) */
/* w0 [7:0] opcode  [15:8] flags  [31:16] 0
 * w1      cookie (host value, echoed)
 * w2      timeout in device cycles (0 = firmware default)
 * w3      0
 * w4..15  payload                                                            */
#define SFRQ_OP_NOP          0x00u  /* completes in order */
#define SFRQ_OP_VECTOR       0x01u  /* w4..w11 = tile descriptor CMD0..CMD7 */
#define SFRQ_OP_GEMM         0x02u  /* w4..w15 = TENSORCORE 08 descriptor (ABI v2) */
#define SFRQ_OP_DMA_COPY     0x03u  /* w4 src, w5 dst, w6 bytes: ControlCore system DMA */
#define SFRQ_OP_PERF_DUMP    0x04u  /* w4 = device address of a 72-word telemetry block */

#define SFRQ_F_CHAIN_SCALAR  0x01u  /* VECTOR: SCALAR (CMD2) := RESULT of this queue's previous VECTOR command */

/* ------------------------------------------------------------------ completion entry (64 B) */
/* w0      cookie
 * w1 [7:0] status  [15:8] opcode
 * w2..w7  engine record:
 *           VECTOR: CPL_INFO(tag|status<<8|type<<12|detail<<16|fflags<<20|step<<25), SEQ, COUNT, RESULT, ERR_ADDR, CYCLES
 *           GEMM  : record words CPL0..CPL5 (TID|OPCODE|ERR|STATUS..., COUNT, ERR_ADDR, SEQ, CYCLES, TILES)
 *           DMA   : DataFabric error code (0 ok), bytes done
 *           PERF  : words written
 * w8      SQ head after this entry was consumed
 * w9      t_fetch  (ControlCore cycle counter, low 32 bits, when the entry was read)
 * w10     t_start  (when the engine was started)
 * w11     t_end    (when the completion was observed)
 * w12     t_end high 32 bits
 * w13     tsu_check() predicted error code (GEMM), else 0
 * w14     t_seen   (low 32 bits: when the firmware first saw the entry -- queue delay = t_start - t_seen)
 * w15 [0] phase: written LAST; first pass = 1, toggles on every wrap          */
#define SFRQ_ST_OK            0u
#define SFRQ_ST_BAD_OPCODE    1u   /* unknown SQE opcode: nothing executed */
#define SFRQ_ST_BAD_FIELD     2u   /* reserved SQE bit set / bad DMA parameters: nothing executed */
#define SFRQ_ST_ENGINE_ERROR  3u   /* the engine rejected or failed the command: record holds its code */
#define SFRQ_ST_TIMEOUT       4u   /* no completion within the timeout: the accelerator domain was reset */
#define SFRQ_ST_ABORTED       5u   /* discarded by SFRQ_MBOX_RESET / Q_DESTROY */
#define SFRQ_ST_NO_DEVICE     6u   /* the engine is absent / not discovered */
#define SFRQ_ST_DMA_ERROR     7u   /* system DMA failed: w2 = DataFabric error code */

#define SFRQ_DEFAULT_TIMEOUT 50000000u   /* cycles */

#endif /* SF_RQ_ABI_H */
