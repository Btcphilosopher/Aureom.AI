// SilicaFlux.OS -- RTL simulation backend: P21 ControlCore system.
//
// Transport: the Verilated silicaflux_cc_hpc_system (cc_sim.h).  The host
//   * boots the ControlCore exactly like the P21 testbench (host-load boot:
//     image written to IMEM through the host access port, IMAGE_READY);
//   * performs the SFRQ handshake (HELLO / INFO) and refuses any firmware whose
//     SFRQ ABI major differs (or that has no SFRQ at all);
//   * keeps SQ/CQ rings in shared device memory (the harness's memory window,
//     zero simulated latency, like a host-mapped device-memory BAR) and rings
//     the firmware with the mailbox KICK;
//   * lowers API commands to the engines' OWN descriptor formats (HPC M08 tile
//     KERNEL, TENSORCORE 08 ABI v2 GEMM, system DMA) which the firmware forwards
//     unchanged.  Nothing is computed on the host: every result is produced by
//     the RTL and read back from device memory.
#include <algorithm>
#include <array>
#include <cstring>
#include <fstream>
#include <memory>

#include "../../core/internal.h"
#include "cc_memmap.h"
#include "cc_sim.h"
#include "hpc_tile_regs.h"
#include "sf_rq_abi.h"
#include "tsu_abi.h"

static_assert(sf::cc::kDevmemBase == CC_DEVMEM_BASE, "harness / map mismatch");
static_assert(sf::cc::kDevmemSize == CC_DEVMEM_SIZE, "harness / map mismatch");
static_assert(sf::cc::kPoisonBase == CC_TB_POISON_BASE, "harness / map mismatch");

namespace sf {

std::string cc_firmware_path() {
  if (const char *e = getenv("SILICAFLUX_CC_FIRMWARE")) return e;
#ifdef SF_CC_FIRMWARE_BUILD
  if (FILE *f = fopen(SF_CC_FIRMWARE_BUILD, "r")) {
    fclose(f);
    return SF_CC_FIRMWARE_BUILD;
  }
#endif
#ifdef SF_CC_FIRMWARE_INSTALL
  return SF_CC_FIRMWARE_INSTALL;
#else
  return "controlcore_rt.hex";
#endif
}

namespace {

constexpr uint32_t kMHz = 100;                          // nominal clock for ms <-> cycles (assumed, not measured)
constexpr uint32_t kRing = SFRQ_MAX_DEPTH;              // entries per ring (64)
constexpr uint32_t kUser0 = CC_DEVMEM_BASE, kUser0End = 0x200E0000u;
constexpr uint32_t kInternal = 0x200E0000u, kInternalEnd = CC_TB_POISON_BASE;
constexpr uint32_t kUser1 = CC_TB_POISON_BASE + CC_TB_POISON_SIZE, kUser1End = CC_DEVMEM_BASE + CC_DEVMEM_SIZE;

const char *kCcPerfNames[20] = {"cpu_sleep", "vec_busy", "tsu_busy", "dma_busy", "acc_overlap", "ext_req",
                                "ext_stall", "host_req", "irq_ext", "irq_timer", "acc_rb", "bus_err", "src_fatal",
                                "src_wdt", "src_ras_warn", "src_dma", "src_tensor", "src_vector", "src_host",
                                "iso_refused"};
const bool kCcPerfCycles[20] = {1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
const char *kTileNames[24] = {"cycles", "busy", "submitted", "completed", "errors", "cancelled", "dma_active",
                              "dma_bytes_rd", "dma_bytes_wr", "vec_active", "vec_elems", "vec_flops", "lsu_loads",
                              "lsu_stores", "spm_conflicts", "overlap", "hazard_stall", "halted", "cmdq_full",
                              "cplq_stall", "host_spm", "dma_cmds", "vec_cmds", "kernel_cmds"};
const uint32_t kTileUnits[24] = {1, 1, 2, 2, 2, 2, 1, 3, 3, 1, 4, 4, 2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2};
const char *kTsuNames[20] = {"cycles", "busy", "cmd_accept", "cmd_done", "cmd_err", "gemm_ok", "tiles", "chunks",
                             "macs", "compute_cycles", "dma_active", "overlap", "rd_words", "wr_words", "bus_stall",
                             "desc", "q_full", "cpl_stall", "saturated", "aborts"};
const uint32_t kTsuUnits[20] = {1, 1, 2, 2, 2, 2, 2, 2, 5, 1, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2};

struct Perf {
  uint64_t cc_cycles = 0;
  std::vector<uint32_t> cc, tile, tsu;
};

class CcBackend;

// per-command backend state: the SQEs it produced and what came back
struct CmdState {
  uint32_t first = 0, count = 0, done = 0;   // SQ slots [first, first+count) mod ring
  sf_status status = SF_OK;
  uint32_t dev_status = 0, dev_error = 0, fflags = 0;
  uint64_t engine_cycles = 0, elements = 0, start64 = 0, end64 = 0, queue_cycles = 0;
  uint32_t result_bits = 0;
  bool sat = false, have_start = false;
};

class CcQueue : public BackendQueue {
 public:
  CcQueue(CcBackend &be, uint32_t depth) : be_(be), depth_(depth) {}
  ~CcQueue() override;
  sf_status init();
  sf_status start(Command &c) override;
  sf_status poll(std::deque<Command *> &started) override;
  void abandon() override;
  uint32_t capacity() const override { return depth_; }

 private:
  void absorb(Command &c, CmdState &st, const uint32_t q[16]);
  CcBackend &be_;
  uint32_t depth_;
  uint32_t qid_ = 0, cb_ = 0, sq_ = 0, cq_ = 0;
  uint32_t sq_tail_ = 0, cq_head_ = 0, phase_ = 1, outstanding_ = 0;
  uint32_t cookie_ = 1;
  bool live_ = false;
};

class CcBackend : public Backend {
 public:
  explicit CcBackend(const DeviceEntry &e) : fw_path_(cc_firmware_path()) { (void)e; }
  ~CcBackend() override { close(); }

  // ------------------------------------------------------------------ lifecycle
  sf_status open(uint32_t flags) override {
    if (sf_status s = load_image()) return s;
    sim_ = std::make_unique<cc::CcSim>(1);
    sim_->echo_console = (flags & SF_OPEN_TRACE_CONSOLE) != 0 || getenv("SILICAFLUX_CC_CONSOLE") != nullptr;
    internal_.init({{kInternal, kInternalEnd - kInternal}}, 64);
    if (!internal_.alloc(72 * 4, &perf_block_)) return fail(SF_ERR_INTERNAL, "internal memory");
    sim_->power_on_reset();
    if (sf_status s = boot()) return s;
    return handshake();
  }
  void close() override { sim_.reset(); }

  sf_status load_image() {
    std::ifstream f(fw_path_);
    if (!f) return fail(SF_ERR_NO_DEVICE, "cannot read ControlCore firmware image %s", fw_path_.c_str());
    image_.clear();
    std::string l;
    while (std::getline(f, l))
      if (!l.empty()) image_.push_back((uint32_t)strtoul(l.c_str(), nullptr, 16));
    if (image_.size() < 64 || image_.size() * 4 > CC_IMEM_SIZE)
      return fail(SF_ERR_NO_DEVICE, "firmware image %s has an invalid size", fw_path_.c_str());
    return SF_OK;
  }

  // P21 host bring-up (HW_SW_INTERFACE.md section 2), host-load boot mode
  sf_status boot() {
    uint32_t v = 0;
    uint64_t t0 = sim_->cycle();
    for (;;) {
      if (!sim_->host_read(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, &v)) return lost("host port: BOOT_STAGE read");
      if (v == CC_BOOT_STAGE_WAIT_IMAGE) break;
      if (sim_->cycle() - t0 > 3000000) return lost("boot ROM did not reach WAIT_IMAGE");
      sim_->tick(200);
    }
    for (size_t i = 0; i < image_.size(); i++)
      if (!sim_->host_write(CC_IMEM_BASE + 4 * (uint32_t)i, image_[i])) return lost("host port: image write");
    uint32_t m[8];
    if (sf_status s = mbox(CC_MBOX_CMD_IMAGE_READY, {}, m, 5000000)) return s;
    if ((m[0] & 0xFF) != CC_MBOX_STS_OK)
      return fail(SF_ERR_INCOMPATIBLE_VERSION, "boot ROM rejected the firmware image %s (reason %u)",
                  fw_path_.c_str(), m[1]);
    t0 = sim_->cycle();
    while (!sim_->host_ready()) {
      sim_->tick(64);
      if (sim_->cycle() - t0 > 5000000) return lost("firmware did not reach HOST_READY");
    }
    if (sf_status s = wait_answer(m, 100000, CC_MBOX_CMD_NONE)) return s;   // unsolicited ready message
    acc_mask_ = m[1];
    boot_cycles_ = sim_->cycle();
    return SF_OK;
  }

  sf_status handshake() {
    uint32_t m[8];
    if (sf_status s = mbox(SFRQ_MBOX_HELLO, {}, m, 200000)) return s;
    if ((m[0] & 0xFF) == CC_MBOX_STS_BAD_CMD)
      return fail(SF_ERR_INCOMPATIBLE_VERSION,
                  "ControlCore firmware %08x does not implement the SFRQ runtime-queue ABI (P21 firmware 1.0?): "
                  "load controlcore_rt firmware", m[2]);
    abi_ = m[1];
    fw_ = m[2];
    if ((abi_ >> 16) != SFRQ_ABI_MAJOR)
      return fail(SF_ERR_INCOMPATIBLE_VERSION, "firmware SFRQ ABI %u.%u is not supported (this library: %u.x)",
                  abi_ >> 16, abi_ & 0xFFFF, SFRQ_ABI_MAJOR);
    acc_mask_ = m[3] & 0xFF;
    max_queues_ = (m[3] >> 8) & 0xFF;
    max_depth_ = 1u << ((m[3] >> 16) & 0xFF);
    tile_cfg_ = m[4];
    tsu_info_ = m[5];
    k_max_ = m[6];
    vl_max_ = m[7];
    if (sf_status s = mbox(SFRQ_MBOX_INFO, {}, m, 200000)) return s;
    spm_base_ = m[1];
    spm_size_ = m[2];
    tsu_lo_ = m[3];
    tsu_last_ = m[4];
    lanes_ = m[7] & 0xFF;
    data_bytes_ = (m[7] >> 8) & 0xFF;
    if (max_depth_ < kRing) return fail(SF_ERR_INCOMPATIBLE_VERSION, "firmware ring depth %u < %u", max_depth_, kRing);
    // vector KERNEL staging needs 4 operand areas of VL*4 bytes in the scratchpad window
    chunk_ = std::min<uint32_t>(vl_max_, spm_size_ / 16);
    chunk_ -= chunk_ % std::max<uint32_t>(lanes_, 1);
    return SF_OK;
  }

  void fill_info(sf_device_info &i) override {
    i.caps = SF_CAP_COPY | SF_CAP_HW_COUNTERS | SF_CAP_RAS | SF_CAP_DEVICE_TIMESTAMPS | SF_CAP_FAULT_INJECTION |
             SF_CAP_FIRMWARE_SELFTEST;
    if (acc_mask_ & 1) i.caps |= SF_CAP_VECTOR_F32 | SF_CAP_VECTOR_I32 | SF_CAP_DOT_F32;
    if (acc_mask_ & 2) i.caps |= SF_CAP_GEMM_I8_I32 | ((tsu_info_ >> 24) & 1 ? SF_CAP_GEMM_I8_Q8 : 0);
    i.device_abi_version = abi_;
    i.firmware_version = fw_;
    i.hardware_revision = tile_cfg_;
    snprintf(i.hardware_id, sizeof i.hardware_id, "SilicaFlux-HPC P21 ControlCore+M08+TC08 (RTL sim)");
    i.max_queue_depth = kRing - 1;
    i.max_queues = max_queues_;
    i.vector_lanes = lanes_;
    i.max_vector_elements = (uint64_t)(kRing - 1) * chunk_;   // one ring of KERNEL chunks (check() enforces it)
    i.gemm_max_m = 65535;
    i.gemm_max_n = 65535;
    i.gemm_max_k = k_max_;
    i.tensor_array_rows = (tsu_info_ >> 8) & 0xFF;
    i.tensor_array_cols = (tsu_info_ >> 16) & 0xFF;
    i.nominal_clock_mhz = kMHz;
    i.default_timeout_ms = 100;   // simulated: 10 M cycles
  }

  std::vector<MemRegion> memory_regions() override {
    return {{kUser0, kUser0End - kUser0}, {kUser1, kUser1End - kUser1}};
  }

  // ------------------------------------------------------------------ device memory window
  sf_status write(uint64_t a, const void *s, uint64_t n) override {
    if (!sim_->devmem_contains((uint32_t)a, n) || a > UINT32_MAX) return fail(SF_ERR_OUT_OF_RANGE, "outside device memory");
    sim_->devmem_write((uint32_t)a, s, n);
    return SF_OK;
  }
  sf_status read(uint64_t a, void *d, uint64_t n) override {
    if (!sim_->devmem_contains((uint32_t)a, n) || a > UINT32_MAX) return fail(SF_ERR_OUT_OF_RANGE, "outside device memory");
    sim_->devmem_read((uint32_t)a, d, n);
    return SF_OK;
  }

  // ------------------------------------------------------------------ mailbox (P21 protocol)
  sf_status lost(const char *what) {
    dev_lost_ = true;
    return fail(SF_ERR_DEVICE_LOST, "ControlCore not responding: %s (cycle %llu)", what,
                (unsigned long long)sim_->cycle());
  }

  sf_status send(uint32_t cmd, std::initializer_list<uint32_t> args) {
    uint32_t st = 0;
    uint64_t t0 = sim_->cycle();
    for (;;) {   // the previous host message must have been taken by the firmware
      if (!sim_->host_read(CC_MAILBOX_BASE + CC_MBOX_DB_STATUS, &st)) return lost("host port: DB_STATUS");
      if (!(st & 1)) break;
      if (sim_->cycle() - t0 > 2000000) return lost("mailbox H2F still pending");
      sim_->tick(16);
    }
    uint32_t i = 1;
    for (uint32_t a : args)
      if (!sim_->host_write(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4 * i++, a)) return lost("host port: H2F_MSG");
    if (!sim_->host_write(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd) ||
        !sim_->host_write(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd))
      return lost("host port: H2F_RING");
    return SF_OK;
  }

  sf_status wait_answer(uint32_t m[8], uint64_t timeout, uint32_t cmd) {
    uint64_t t0 = sim_->cycle();
    while (!sim_->host_irq()) {
      sim_->tick(8);
      if (sim_->cycle() - t0 > timeout) return fail(SF_ERR_TIMEOUT, "no mailbox answer to command %#x within %llu cycles",
                                                    cmd, (unsigned long long)timeout);
    }
    for (int i = 0; i < 8; i++)
      if (!sim_->host_read(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 4 * i, &m[i])) return lost("host port: F2H_MSG");
    if (!sim_->host_write(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0)) return lost("host port: F2H_ACK");
    if (((m[0] >> 8) & 0xFF) != (cmd & 0xFF)) {
      dev_lost_ = true;
      return fail(SF_ERR_DEVICE_LOST, "mailbox protocol error: answer to %#x while waiting for %#x", (m[0] >> 8) & 0xFF, cmd);
    }
    return SF_OK;
  }

  sf_status mbox(uint32_t cmd, std::initializer_list<uint32_t> args, uint32_t m[8], uint64_t timeout) {
    if (sf_status s = send(cmd, args)) return s;
    sf_status s = wait_answer(m, timeout, cmd);
    if (s == SF_ERR_TIMEOUT) {
      dev_lost_ = true;
      return fail(SF_ERR_DEVICE_LOST, "%s", sf_last_error_detail());
    }
    return s;
  }

  sf_status kick() { return send(SFRQ_MBOX_KICK, {}); }

  // ------------------------------------------------------------------ queues
  sf_status create_queue(uint32_t depth, std::unique_ptr<BackendQueue> *q) override {
    if (depth > kRing - 1) return fail(SF_ERR_INVALID_ARGUMENT, "depth %u > %u", depth, kRing - 1);
    auto cq = std::make_unique<CcQueue>(*this, depth);
    if (sf_status s = cq->init()) return s;
    *q = std::move(cq);
    return SF_OK;
  }

  // ------------------------------------------------------------------ lowering
  static uint32_t vop(const Command &c) {
    bool i32 = c.vec.dtype == SF_DTYPE_I32;
    switch (c.op) {
      case SF_OP_VECTOR_ADD: return i32 ? 0x10u : 0x01u;    // IADD / FADD
      case SF_OP_VECTOR_MUL: return i32 ? 0x11u : 0x03u;    // IMUL / FMUL
      case SF_OP_VECTOR_DOT: return 0x03u;                  // FMUL + RED
      default: return 0x04u;                                // FMADD (fma, axpy)
    }
  }

  // 64-byte SQEs for a command (descriptors in the engines' own formats)
  sf_status lower(const Command &c, uint32_t cookie, std::vector<std::array<uint32_t, 16>> &out) const {
    // per-entry firmware timeout in device cycles (0 = firmware default); diagnostic knob, docs/05
    const char *tmo_env = getenv("SILICAFLUX_CC_CMD_TIMEOUT_CYCLES");
    const uint32_t tmo = tmo_env ? (uint32_t)strtoul(tmo_env, nullptr, 0) : 0u;
    auto sqe = [&](uint32_t op, uint32_t flags) {
      std::array<uint32_t, 16> s{};
      s[0] = op | (flags << 8);
      s[1] = cookie;
      s[2] = tmo;
      return s;
    };
    switch (c.op) {
      case SF_OP_VECTOR_ADD:
      case SF_OP_VECTOR_MUL:
      case SF_OP_VECTOR_FMA:
      case SF_OP_VECTOR_AXPY:
      case SF_OP_VECTOR_DOT: {
        const VecArgs &v = c.vec;
        bool dot = c.op == SF_OP_VECTOR_DOT;
        uint32_t rm = v.dtype == SF_DTYPE_I32 ? 0u : v.rm;
        uint32_t bcast = v.axpy ? 1u : 0u;                  // {c, b, a}: a = SCALAR (alpha)
        for (uint64_t off = 0; off < v.n; off += chunk_) {
          uint32_t vl = (uint32_t)std::min<uint64_t>(chunk_, v.n - off);
          auto s = sqe(SFRQ_OP_VECTOR, dot && off ? SFRQ_F_CHAIN_SCALAR : 0u);
          s[4] = 3u | (vop(c) << 4) | (rm << 9) | (bcast << 12) | ((dot ? 1u : 0u) << 15) | ((cookie & 0xFF) << 16);
          s[5] = vl;
          s[6] = v.axpy ? v.alpha_bits : 0u;               // SCALAR: alpha, or the reduction's initial value (+0)
          s[7] = v.axpy ? 0u : (uint32_t)(v.a + 4 * off);
          s[8] = (uint32_t)(v.b + 4 * off);
          s[9] = (c.op == SF_OP_VECTOR_FMA || v.axpy) ? (uint32_t)(v.c + 4 * off) : 0u;
          s[10] = dot ? (uint32_t)v.d : (uint32_t)(v.d + 4 * off);
          s[11] = spm_base_;                               // KERNEL staging base
          out.push_back(s);
        }
        return SF_OK;
      }
      case SF_OP_GEMM: {
        const GemmArgs &g = c.gemm;
        auto s = sqe(SFRQ_OP_GEMM, 0);
        uint32_t flags = 0x01u | (((tsu_info_ >> 25) & 1) ? 0x04u : 0u);   // IRQ, PREFETCH when double-buffered
        s[4] = 0x40u | (2u << 8) | ((g.out_i8 ? g.rm : 0u) << 12) | (flags << 16) | ((cookie & 0xFF) << 24);
        s[5] = (uint32_t)g.a;
        s[6] = (uint32_t)g.b;
        s[7] = (uint32_t)g.c;
        s[8] = g.m | (g.n << 16);
        s[9] = g.k;                                        // KC = 0: TILE_K
        s[10] = g.lda;
        s[11] = g.ldb;
        s[12] = g.ldc;
        s[13] = ((g.out_i8 ? 1u : 0u) << 4) | ((g.relu ? 1u : 0u) << 14);
        s[14] = g.out_i8 ? (uint32_t)g.q_mult : 0u;
        s[15] = g.out_i8 ? (g.q_shift | ((uint32_t)(uint8_t)(int8_t)g.q_zp << 8)) : 0u;
        out.push_back(s);
        return SF_OK;
      }
      case SF_OP_COPY: {
        auto s = sqe(SFRQ_OP_DMA_COPY, 0);
        s[4] = (uint32_t)c.copy.src;
        s[5] = (uint32_t)c.copy.dst;
        s[6] = (uint32_t)c.copy.size;
        out.push_back(s);
        return SF_OK;
      }
      case SF_OP_RAW: {
        bool vec = c.raw.engine == SF_ENGINE_VECTOR;
        size_t need = vec ? 8 : 12;
        if (c.raw.words.size() != need)
          return fail(SF_ERR_INVALID_ARGUMENT, "%s descriptors are %zu words", vec ? "tile" : "tensor", need);
        auto s = sqe(vec ? SFRQ_OP_VECTOR : SFRQ_OP_GEMM, 0);
        for (size_t i = 0; i < need; i++) s[4 + i] = c.raw.words[i];
        out.push_back(s);
        return SF_OK;
      }
      default:
        return fail(SF_ERR_UNSUPPORTED, "operation %d", (int)c.op);
    }
  }

  sf_status check(const Command &c) override {
    if (dev_lost_) return fail(SF_ERR_DEVICE_LOST, "device lost");
    switch (c.op) {
      case SF_OP_VECTOR_ADD:
      case SF_OP_VECTOR_MUL:
      case SF_OP_VECTOR_FMA:
      case SF_OP_VECTOR_AXPY:
      case SF_OP_VECTOR_DOT:
        if (!(acc_mask_ & 1)) return fail(SF_ERR_UNSUPPORTED, "the vector tile is not present");
        if ((c.vec.n + chunk_ - 1) / chunk_ > kRing - 1)
          return fail(SF_ERR_UNSUPPORTED, "vector of %llu elements needs more than %u tile commands",
                      (unsigned long long)c.vec.n, kRing - 1);
        return SF_OK;
      case SF_OP_GEMM:
        if (!(acc_mask_ & 2)) return fail(SF_ERR_UNSUPPORTED, "the tensor unit is not present");
        if (c.gemm.m > 65535 || c.gemm.n > 65535 || c.gemm.k > k_max_)
          return fail(SF_ERR_UNSUPPORTED, "GEMM %ux%ux%u exceeds the tensor unit (M,N <= 65535, K <= %u)", c.gemm.m,
                      c.gemm.n, c.gemm.k, k_max_);
        if (c.gemm.out_i8 && !((tsu_info_ >> 24) & 1))
          return fail(SF_ERR_UNSUPPORTED, "this tensor unit was built without requantisation");
        return SF_OK;
      case SF_OP_COPY:
      case SF_OP_RAW:
        return SF_OK;
      default:
        return fail(SF_ERR_UNSUPPORTED, "operation %d", (int)c.op);
    }
  }

  void advance() override { sim_->tick(256); }
  uint64_t device_time_us() override { return sim_->cycle() / kMHz; }
  bool is_simulator() const override { return true; }
  sf_exec_target exec_target() const override { return SF_EXEC_RTL_SIMULATION; }

  // ------------------------------------------------------------------ management
  sf_status reset(sf_reset_level level) override {
    if (level == SF_RESET_ENGINES && !dev_lost_) {
      uint32_t m[8];
      sf_status s = mbox(SFRQ_MBOX_RESET, {SFRQ_RESET_QUEUES | SFRQ_RESET_ACCEL}, m, 5000000);
      if (s == SF_OK && (m[0] & 0xFF) == CC_MBOX_STS_OK) return SF_OK;   // queues dropped by the firmware
      // the firmware did not answer: escalate to a full reset
    }
    // cold reset of the ControlCore through the host reset pin: ROM boot, image reload
    sim_->host_reset_pulse();
    dev_lost_ = false;
    if (sf_status s = boot()) return s;
    return handshake();
  }

  sf_status status(sf_device_status &st) override {
    uint32_t m[8], k[8];
    if (sf_status s = mbox(SFRQ_MBOX_STATUS, {}, m, 60000000)) return s;
    if (sf_status s = mbox(SFRQ_MBOX_COUNTS, {}, k, 60000000)) return s;
    st.ras_status = m[1];
    st.ras_warnings = m[2];
    st.ras_fatals = m[3];
    st.ras_first_source = m[4];
    st.ras_first_address = m[5];
    st.ras_warning_sources = m[6];
    st.ras_fatal_sources = m[7];
    st.state = acc_mask_ != 3 ? SF_STATE_DEGRADED : ((m[1] >> 8) & 0xFF) ? SF_STATE_ERROR : SF_STATE_READY;
    snprintf(st.detail, sizeof st.detail,
             "fw %x.%x SFRQ %u.%u; accelerators %s%s; RAS status %#x warn %u fatal %u; fw cmds %u failed %u "
             "timeouts %u acc-resets %u",
             fw_ >> 16, fw_ & 0xFFFF, abi_ >> 16, abi_ & 0xFFFF, acc_mask_ & 1 ? "vector " : "",
             acc_mask_ & 2 ? "tensor" : "", m[1], m[2], m[3], k[1], k[2], k[4], k[5]);
    return SF_OK;
  }

  sf_status read_perf(Perf &p) {
    uint32_t m[8];
    if (sf_status s = mbox(CC_MBOX_CMD_PERF_DUMP, {(uint32_t)perf_block_}, m, 60000000)) return s;
    std::vector<uint32_t> w(m[1]);
    sim_->devmem_read((uint32_t)perf_block_, w.data(), 4 * w.size());
    size_t i = 0;
    auto take = [&](uint32_t tag, std::vector<uint32_t> &dst, bool cyc) -> bool {
      if (i >= w.size() || w[i] != tag) return false;
      i++;
      if (cyc) {
        p.cc_cycles = w[i] | ((uint64_t)w[i + 1] << 32);
        i += 2;
      }
      uint32_t n = w[i++];
      dst.assign(w.begin() + (long)i, w.begin() + (long)std::min<size_t>(i + n, w.size()));
      i += n;
      return true;
    };
    if (!take(0x43435046u, p.cc, true) || !take(0x56435046u, p.tile, false) || !take(0x54435046u, p.tsu, false))
      return fail(SF_ERR_DEVICE, "malformed telemetry block from firmware");
    return SF_OK;
  }

  sf_status read_counters(std::vector<sf_counter> &out) override {
    Perf p;
    if (sf_status s = read_perf(p)) return s;
    uint32_t k[8];
    if (sf_status s = mbox(SFRQ_MBOX_COUNTS, {}, k, 60000000)) return s;
    auto add = [&](const std::string &n, uint64_t v, uint32_t unit, uint32_t src) {
      sf_counter c{};
      snprintf(c.name, sizeof c.name, "%s", n.c_str());
      c.value = v;
      c.unit = unit;
      c.source = src;
      out.push_back(c);
    };
    add("cc.cycles", p.cc_cycles, SF_UNIT_CYCLES, SF_SRC_HARDWARE);
    for (size_t i = 0; i < p.cc.size() && i < 20; i++)
      add(std::string("cc.") + kCcPerfNames[i], p.cc[i], kCcPerfCycles[i] ? SF_UNIT_CYCLES : SF_UNIT_EVENTS,
          SF_SRC_HARDWARE);
    for (size_t i = 0; i < p.tile.size() && i < 24; i++)
      add(std::string("tile.") + kTileNames[i], p.tile[i], kTileUnits[i], SF_SRC_HARDWARE);
    for (size_t i = 0; i < p.tsu.size() && i < 20; i++)
      add(std::string("tensor.") + kTsuNames[i], p.tsu[i], kTsuUnits[i], SF_SRC_HARDWARE);
    add("fw.commands_executed", k[1], SF_UNIT_EVENTS, SF_SRC_FIRMWARE);
    add("fw.commands_failed", k[2], SF_UNIT_EVENTS, SF_SRC_FIRMWARE);
    add("fw.entries_aborted", k[3], SF_UNIT_EVENTS, SF_SRC_FIRMWARE);
    add("fw.timeouts", k[4], SF_UNIT_EVENTS, SF_SRC_FIRMWARE);
    add("fw.accelerator_resets", k[5], SF_UNIT_EVENTS, SF_SRC_FIRMWARE);
    add("fw.system_dma_bytes", k[6], SF_UNIT_BYTES, SF_SRC_FIRMWARE);
    add("sim.cycles", sim_->cycle(), SF_UNIT_CYCLES, SF_SRC_SIMULATOR);
    add("sim.devmem_reads", sim_->devmem_reads(), SF_UNIT_EVENTS, SF_SRC_SIMULATOR);
    add("sim.devmem_writes", sim_->devmem_writes(), SF_UNIT_EVENTS, SF_SRC_SIMULATOR);
    add("sim.devmem_stall_cycles", sim_->devmem_stall_cycles(), SF_UNIT_CYCLES, SF_SRC_SIMULATOR);
    return SF_OK;
  }

  sf_status clear_counters() override {
    uint32_t m[8];
    return mbox(SFRQ_MBOX_PERF_CLEAR, {}, m, 60000000);
  }

  sf_status perf_summary(sf_perf_summary &s) override {
    Perf p;
    if (sf_status rc = read_perf(p)) return rc;
    uint32_t m[8], k[8];
    if (sf_status rc = mbox(SFRQ_MBOX_STATUS, {}, m, 60000000)) return rc;
    if (sf_status rc = mbox(SFRQ_MBOX_COUNTS, {}, k, 60000000)) return rc;
    auto at = [](const std::vector<uint32_t> &v, size_t i) -> uint64_t { return i < v.size() ? v[i] : 0; };
    s.device_cycles = p.cc_cycles;
    s.vector_elements = at(p.tile, HPC_PC_VEC_ELEMS);
    s.vector_flops = at(p.tile, HPC_PC_VEC_FLOPS);
    s.tensor_macs = at(p.tsu, TSU_PC_MACS);
    s.device_dma_bytes = at(p.tile, HPC_PC_DMA_BYTES_RD) + at(p.tile, HPC_PC_DMA_BYTES_WR) +
                         4 * (at(p.tsu, TSU_PC_RD_WORDS) + at(p.tsu, TSU_PC_WR_WORDS)) + k[6];
    s.dma_stall_cycles = at(p.cc, CC_PERF_EV_EXT_STALL) + at(p.tsu, TSU_PC_BUS_STALL);
    s.sram_conflict_cycles = at(p.tile, HPC_PC_SPM_CONFLICTS);
    s.queue_full_cycles = at(p.tile, HPC_PC_CMDQ_FULL) + at(p.tsu, TSU_PC_Q_FULL);
    s.ras_events = (uint64_t)m[2] + m[3];
    return SF_OK;
  }

  sf_status selftest(uint32_t mask, sf_selftest_result &r) override {
    if (mask & 0x80000000u)
      return fail(SF_ERR_INVALID_ARGUMENT, "the destructive watchdog-reset test (bit 31) is not run from the runtime");
    uint32_t m[8];
    uint64_t c0 = sim_->cycle();
    if (sf_status s = mbox(CC_MBOX_CMD_RUN_SELFTEST, {mask}, m, 80000000)) return s;
    r.checks = m[1];
    r.failures = m[2];
    r.device_cycles = sim_->cycle() - c0;
    snprintf(r.detail, sizeof r.detail, "ControlCore firmware self-test (P21 suite) on the RTL, mask %#x", mask);
    return SF_OK;
  }

  std::string take_console() override { return sim_ ? sim_->take_console() : std::string(); }

  sf_status inject(sf_inject_kind kind, uint64_t addr, uint64_t size) override {
    switch (kind) {
      case SF_INJECT_MEM_READ_ERROR:
      case SF_INJECT_MEM_WRITE_ERROR:
        sim_->add_error_range({(uint32_t)addr, (uint32_t)(addr + size), kind == SF_INJECT_MEM_READ_ERROR,
                               kind == SF_INJECT_MEM_WRITE_ERROR});
        return SF_OK;
      case SF_INJECT_RAS_WARNING:
      case SF_INJECT_RAS_FATAL:
        if (kind == SF_INJECT_RAS_WARNING) sim_->set_ext_warn(true); else sim_->set_ext_fatal(true);
        sim_->tick(50);
        if (kind == SF_INJECT_RAS_WARNING) sim_->set_ext_warn(false); else sim_->set_ext_fatal(false);
        sim_->tick(200);
        return SF_OK;
      case SF_INJECT_CLEAR:
        sim_->clear_error_ranges();
        sim_->set_backpressure(0);
        return SF_OK;
      case SF_INJECT_DEVICE_HANG:   // every device-memory request is held off: firmware and engines stall
        sim_->set_backpressure(100);
        return SF_OK;
      default:
        return fail(SF_ERR_UNSUPPORTED, "this fault cannot be injected on the ControlCore system");
    }
  }

  // shared with CcQueue
  cc::CcSim &sim() { return *sim_; }
  Allocator internal_;
  bool dev_lost_ = false;
  uint32_t chunk_ = 4096, lanes_ = 4, spm_base_ = 0;

 private:
  std::string fw_path_;
  std::vector<uint32_t> image_;
  std::unique_ptr<cc::CcSim> sim_;
  uint64_t perf_block_ = 0, boot_cycles_ = 0;
  uint32_t acc_mask_ = 0, abi_ = 0, fw_ = 0, max_queues_ = 0, max_depth_ = 0, tile_cfg_ = 0, tsu_info_ = 0;
  uint32_t k_max_ = 0, vl_max_ = 0, spm_size_ = 0, tsu_lo_ = 0, tsu_last_ = 0, data_bytes_ = 4;

  friend class CcQueue;
};

// ===================================================================== CcQueue
sf_status CcQueue::init() {
  uint64_t a;
  if (!be_.internal_.alloc(64 + 2 * kRing * 64, &a)) return fail(SF_ERR_OUT_OF_MEMORY, "no device memory for the rings");
  cb_ = (uint32_t)a;
  sq_ = cb_ + 64;
  cq_ = sq_ + kRing * 64;
  auto &s = be_.sim();
  std::vector<uint8_t> z(64 + 2 * kRing * 64, 0);
  s.devmem_write(cb_, z.data(), z.size());                    // CQ zeroed: phase 0 everywhere
  s.devmem_wr32(cb_ + 4 * SFRQ_CB_MAGIC, SFRQ_MAGIC);
  s.devmem_wr32(cb_ + 4 * SFRQ_CB_VERSION, SFRQ_ABI_VERSION);
  s.devmem_wr32(cb_ + 4 * SFRQ_CB_SQ_BASE, sq_);
  s.devmem_wr32(cb_ + 4 * SFRQ_CB_CQ_BASE, cq_);
  s.devmem_wr32(cb_ + 4 * SFRQ_CB_DEPTH, kRing);
  uint32_t m[8];
  if (sf_status st = be_.mbox(SFRQ_MBOX_Q_CREATE, {cb_}, m, 60000000)) {
    be_.internal_.free(cb_);
    return st;
  }
  if ((m[0] & 0xFF) != CC_MBOX_STS_OK) {
    be_.internal_.free(cb_);
    return fail((m[0] & 0xFF) == CC_MBOX_STS_BAD_CMD ? SF_ERR_BUSY : SF_ERR_DEVICE,
                "firmware refused the queue (reason %u)", m[1]);
  }
  qid_ = m[1];
  live_ = true;
  return SF_OK;
}

CcQueue::~CcQueue() {
  if (!live_) return;
  if (!be_.dev_lost_) {
    uint32_t m[8];
    be_.mbox(SFRQ_MBOX_Q_DESTROY, {qid_}, m, 60000000);
  }
  be_.internal_.free(cb_);
}

void CcQueue::abandon() {
  if (live_) be_.internal_.free(cb_);
  live_ = false;
}

sf_status CcQueue::start(Command &c) {
  if (be_.dev_lost_) return fail(SF_ERR_DEVICE_LOST, "device lost");
  std::vector<std::array<uint32_t, 16>> sqes;
  uint32_t cookie = cookie_++;
  if (sf_status s = be_.lower(c, cookie, sqes)) return s;
  if (outstanding_ + sqes.size() > kRing - 1) return SF_ERR_QUEUE_FULL;   // never overwrite an unconsumed slot
  auto st = std::make_shared<CmdState>();
  st->first = sq_tail_;
  st->count = (uint32_t)sqes.size();
  auto &s = be_.sim();
  for (auto &e : sqes) {
    s.devmem_write(sq_ + 64 * sq_tail_, e.data(), 64);
    sq_tail_ = (sq_tail_ + 1) % kRing;
  }
  outstanding_ += st->count;
  s.devmem_wr32(cb_ + 4 * SFRQ_CB_SQ_TAIL, sq_tail_);         // entries are complete before the doorbell
  c.backend_state = st;
  c.backend_tag = cookie;
  c.sim_submit_cycle = s.cycle();
  c.result.exec_target = SF_EXEC_RTL_SIMULATION;
  return be_.kick();
}

void CcQueue::absorb(Command &c, CmdState &st, const uint32_t q[16]) {
  uint32_t sts = q[1] & 0xFF;
  uint64_t end64 = q[11] | ((uint64_t)q[12] << 32);
  uint64_t start64 = end64 - (uint32_t)(q[11] - q[10]);
  if (!st.have_start) {
    st.start64 = start64;
    st.queue_cycles = (uint32_t)(q[10] - q[14]);   // t_start - t_seen (firmware-measured)
    st.have_start = true;
  }
  st.end64 = end64;
  bool vec = c.op == SF_OP_VECTOR_ADD || c.op == SF_OP_VECTOR_MUL || c.op == SF_OP_VECTOR_FMA ||
             c.op == SF_OP_VECTOR_AXPY || c.op == SF_OP_VECTOR_DOT || (c.op == SF_OP_RAW && c.raw.engine == SF_ENGINE_VECTOR);
  bool gemm = c.op == SF_OP_GEMM || (c.op == SF_OP_RAW && c.raw.engine == SF_ENGINE_TENSOR);
  sf_status err = SF_OK;
  uint32_t dstat = sts, derr = 0;
  if (vec && q[2] != 0xFFFFFFFFu && (sts == SFRQ_ST_OK || sts == SFRQ_ST_ENGINE_ERROR)) {
    uint32_t tstat = (q[2] >> 8) & 0xF, detail = (q[2] >> 16) & 0xF;
    st.fflags |= (q[2] >> 20) & 0x1F;
    st.engine_cycles += q[7];
    st.elements += q[4];
    st.result_bits = q[5];
    dstat = sts | (tstat << 8);
    derr = tstat | (detail << 8) | (((q[2] >> 25) & 7) << 12);
    if (sts == SFRQ_ST_ENGINE_ERROR)
      err = (tstat >= 1 && tstat <= 7) ? SF_ERR_INVALID_COMMAND : tstat == 8 ? SF_ERR_DMA
            : tstat == 11 ? SF_ERR_ABORTED : SF_ERR_DEVICE;
  } else if (gemm && (sts == SFRQ_ST_OK || sts == SFRQ_ST_ENGINE_ERROR) && (q[2] >> 8) != 0xFFFFFFu) {
    uint32_t rstat = (q[2] >> 24) & 3, ecode = (q[2] >> 16) & 0xFF, detail = (q[2] >> 28) & 0xF;
    st.engine_cycles += q[6];
    st.sat |= (q[2] >> 27) & 1;
    if (c.op == SF_OP_GEMM && sts == SFRQ_ST_OK) st.elements += (uint64_t)c.gemm.m * c.gemm.n;
    dstat = sts | (rstat << 8);
    derr = ecode | (detail << 8);
    if (sts == SFRQ_ST_ENGINE_ERROR)
      err = rstat == 2 ? SF_ERR_ABORTED : (ecode >= 0x01 && ecode <= 0x0F) ? SF_ERR_INVALID_COMMAND
            : (ecode >= 0x18 && ecode <= 0x1B) ? SF_ERR_DMA : ecode == 0x30 ? SF_ERR_TIMEOUT : SF_ERR_DEVICE;
  } else {
    switch (sts) {
      case SFRQ_ST_OK:
        if (c.op == SF_OP_COPY) st.elements += q[3] / 4;
        break;
      case SFRQ_ST_BAD_OPCODE:
      case SFRQ_ST_BAD_FIELD: err = SF_ERR_INVALID_COMMAND; break;
      case SFRQ_ST_TIMEOUT: err = SF_ERR_TIMEOUT; break;
      case SFRQ_ST_ABORTED: err = SF_ERR_ABORTED; break;
      case SFRQ_ST_NO_DEVICE: err = SF_ERR_NO_DEVICE; break;
      case SFRQ_ST_DMA_ERROR: err = SF_ERR_DMA; derr = q[2]; break;
      default: err = SF_ERR_DEVICE; derr = q[2]; break;
    }
  }
  if (err != SF_OK && st.status == SF_OK) {   // the first failing device command decides
    st.status = err;
    st.dev_status = dstat;
    st.dev_error = derr;
  }
  if (st.status == SF_OK) {
    st.dev_status = dstat;
    st.dev_error = derr;
  }
}

sf_status CcQueue::poll(std::deque<Command *> &started) {
  if (be_.dev_lost_) return SF_ERR_DEVICE_LOST;
  auto &s = be_.sim();
  for (;;) {
    uint32_t a = cq_ + 64 * cq_head_;
    if ((s.devmem_rd32(a + 60) & 1u) != phase_) break;          // phase first, then the entry
    uint32_t q[16];
    s.devmem_read(a, q, 64);
    // the oldest started command that still waits for completions owns this entry
    Command *owner = nullptr;
    for (Command *c : started) {
      auto st = std::static_pointer_cast<CmdState>(c->backend_state);
      if (!c->done && st && st->done < st->count) {
        owner = c;
        break;
      }
    }
    cq_head_ = (cq_head_ + 1) % kRing;
    if (cq_head_ == 0) phase_ ^= 1u;
    outstanding_--;
    s.devmem_wr32(cb_ + 4 * SFRQ_CB_CQ_HEAD, cq_head_);
    if (!owner) continue;
    if (q[0] != owner->backend_tag) {
      be_.dev_lost_ = true;
      return fail(SF_ERR_DEVICE_LOST, "completion for cookie %u while expecting %u: queue protocol violated", q[0],
                  owner->backend_tag);
    }
    auto st = std::static_pointer_cast<CmdState>(owner->backend_state);
    absorb(*owner, *st, q);
    if (++st->done == st->count) {
      sf_cmd_result &r = owner->result;
      r.status = st->status;
      r.exec_target = SF_EXEC_RTL_SIMULATION;
      r.device_status = st->dev_status;
      r.device_error = st->dev_error;
      r.engine_cycles = st->engine_cycles;
      r.device_start_cycle = st->start64;
      r.device_end_cycle = st->end64;
      r.device_queue_cycles = st->queue_cycles;
      r.device_commands = st->count;
      r.elements = st->elements;
      if (st->count > 1) r.flags |= SF_RESULT_CHUNKED;
      if (owner->op >= SF_OP_VECTOR_ADD && owner->op <= SF_OP_VECTOR_DOT && owner->vec.dtype == SF_DTYPE_F32) {
        r.fp_flags = st->fflags;
        r.flags |= SF_RESULT_FP_FLAGS;
      }
      if (owner->op == SF_OP_VECTOR_DOT) r.scalar_bits = st->result_bits;
      if (owner->op == SF_OP_GEMM && st->status == SF_OK)
        r.macs = (uint64_t)owner->gemm.m * owner->gemm.n * owner->gemm.k;
      if (st->sat) r.flags |= SF_RESULT_SATURATED;
      owner->done = true;
    }
  }
  return SF_OK;
}

}  // namespace

std::unique_ptr<Backend> make_cc_backend(const DeviceEntry &e) { return std::make_unique<CcBackend>(e); }

}  // namespace sf
