// SilicaFlux.OS -- ControlCore system RTL simulation harness.  See cc_sim.h.
//
// Cycle protocol (identical to the P21 testbench's sampling):
//   1. clk = 0, eval: combinational outputs settle for the current inputs;
//   2. sample every handshake (valid && ready) and the console tap;
//   3. clk = 1, eval: the RTL registers update;
//   4. update the harness models (they behave as posedge flip-flops) and drive
//      their outputs for the next cycle.
#include "cc_sim.h"

#include <cstdio>
#include <cstring>

#include "Vsilicaflux_cc_hpc_system.h"
#include "verilated.h"

namespace sf::cc {

CcSim::CcSim(uint64_t seed) : rng_(seed) {
  ctx_ = std::make_unique<VerilatedContext>();
  ctx_->randReset(0);
  top_ = std::make_unique<Vsilicaflux_cc_hpc_system>(ctx_.get(), "cc");
  mem_.assign(kDevmemSize / 4, 0u);
  clear_error_ranges();
  top_->clk = 0;
  top_->rst_ni = 0;
  top_->test_mode = 0;
  top_->boot_mode_i = 0;      // host-load boot
  top_->host_rst_req_i = 0;
  top_->hs_req_valid = 0;
  top_->hs_req_write = 0;
  top_->hs_req_addr = 0;
  top_->hs_req_wdata = 0;
  top_->hs_req_wstrb = 0xF;
  top_->hs_rsp_ready = 1;
  top_->ext_warn_i = 0;
  top_->ext_fatal_i = 0;
  drive_dm();
  top_->eval();
}

CcSim::~CcSim() {
  if (top_) top_->final();
}

void CcSim::clear_error_ranges() {
  err_ranges_.clear();
  err_ranges_.push_back({kPoisonBase, kPoisonBase + kPoisonSize, true, true});   // P21 testbench poison window
}

bool CcSim::dm_bad(uint32_t a, bool write) const {
  if (a < kDevmemBase || a >= kDevmemBase + kDevmemSize) return true;
  for (const auto &r : err_ranges_)
    if (a >= r.lo && a < r.hi && (write ? r.write : r.read)) return true;
  return false;
}

void CcSim::drive_dm() {
  top_->dm_req_ready = (!dm_rv_ && !dm_stall_) ? 1 : 0;
  top_->dm_rsp_valid = dm_rv_ ? 1 : 0;
  top_->dm_rsp_rdata = dm_rd_;
  top_->dm_rsp_error = dm_re_ ? 1 : 0;
}

void CcSim::tick(uint64_t n) {
  for (uint64_t i = 0; i < n; i++) {
    top_->clk = 0;
    top_->eval();
    // ---- sample (values seen by the posedge)
    const bool hs_req_fire = top_->hs_req_valid && top_->hs_req_ready;
    const bool hs_rsp_fire = top_->hs_rsp_valid;          // hs_rsp_ready is tied 1
    const uint32_t hs_rdata = top_->hs_rsp_rdata;
    const bool hs_rerr = top_->hs_rsp_error;
    const bool dm_req_fire = top_->dm_req_valid && top_->dm_req_ready;
    const bool dm_req_wait = top_->dm_req_valid && !top_->dm_req_ready;
    const bool dm_req_write = top_->dm_req_write;
    const uint32_t dm_addr = top_->dm_req_addr, dm_wdata = top_->dm_req_wdata;
    const uint32_t dm_wstrb = top_->dm_req_wstrb;
    const bool dm_rsp_fire = dm_rv_ && top_->dm_rsp_ready;
    if (top_->diag_valid_o) {
      char ch = (char)top_->diag_char_o;
      console_.push_back(ch);
      console_all_.push_back(ch);
      if (echo_console) {
        if (ch == '\n') {
          fprintf(stderr, "[cc fw @%llu] %s\n", (unsigned long long)cycle_, line_.c_str());
          line_.clear();
        } else {
          line_.push_back(ch);
        }
      }
    }
    // ---- clock edge
    top_->clk = 1;
    top_->eval();
    cycle_++;
    // ---- device memory model (P21 tb_cc_system semantics)
    dm_stall_ = bp_pct_ > 0 && (int)(rng_() % 100) < bp_pct_;
    if (dm_req_wait) dm_stalls_++;
    if (dm_rsp_fire) dm_rv_ = false;
    if (dm_req_fire) {
      dm_rv_ = true;
      dm_re_ = dm_bad(dm_addr, dm_req_write);
      dm_rd_ = 0;
      if (!dm_re_) {
        uint32_t &w = mem_[(dm_addr - kDevmemBase) >> 2];
        if (dm_req_write) {
          for (int b = 0; b < 4; b++)
            if (dm_wstrb & (1u << b)) w = (w & ~(0xFFu << (8 * b))) | (dm_wdata & (0xFFu << (8 * b)));
          dm_writes_++;
        } else {
          dm_rd_ = w;
          dm_reads_++;
        }
      }
    }
    drive_dm();
    // ---- host BFM
    if (hs_ == Hs::kReq && hs_req_fire) {
      top_->hs_req_valid = 0;
      hs_ = Hs::kRsp;
    } else if (hs_ == Hs::kRsp && hs_rsp_fire) {
      hs_rdata_ = hs_rdata;
      hs_err_ = hs_rerr;
      hs_ = Hs::kDone;
    }
  }
}

void CcSim::power_on_reset(unsigned cycles) {
  top_->rst_ni = 0;
  hs_ = Hs::kIdle;
  top_->hs_req_valid = 0;
  dm_rv_ = dm_re_ = false;
  drive_dm();
  tick(cycles);
  top_->rst_ni = 1;
  tick(1);
}

void CcSim::host_reset_pulse(unsigned cycles) {
  // the device-memory controller belongs to the system reset domain: a response still
  // owed to a requester that is being reset is dropped, never delivered after the reset
  dm_rv_ = dm_re_ = false;
  drive_dm();
  top_->host_rst_req_i = 1;
  tick(cycles);
  top_->host_rst_req_i = 0;
  tick(50);
}

bool CcSim::host_access(bool wr, uint32_t addr, uint32_t wdata, uint32_t *rdata, uint64_t timeout) {
  last_timeout_ = false;
  top_->hs_req_valid = 1;
  top_->hs_req_write = wr ? 1 : 0;
  top_->hs_req_addr = addr;
  top_->hs_req_wdata = wdata;
  top_->hs_req_wstrb = 0xF;
  hs_ = Hs::kReq;
  uint64_t t0 = cycle_;
  while (hs_ != Hs::kDone) {
    tick(1);
    if (cycle_ - t0 > timeout) {
      top_->hs_req_valid = 0;   // a request not yet accepted is withdrawn; an accepted one is abandoned
      hs_ = Hs::kIdle;
      last_timeout_ = true;
      return false;
    }
  }
  hs_ = Hs::kIdle;
  if (rdata) *rdata = hs_rdata_;
  return !hs_err_;
}

bool CcSim::host_read(uint32_t addr, uint32_t *val, uint64_t timeout) {
  uint32_t v = 0xFFFFFFFFu;
  bool ok = host_access(false, addr, 0, &v, timeout);
  if (val) *val = v;
  return ok;
}

bool CcSim::host_write(uint32_t addr, uint32_t val, uint64_t timeout) {
  return host_access(true, addr, val, nullptr, timeout);
}

bool CcSim::host_irq() const { return top_->host_irq_o; }
bool CcSim::host_ready() const { return top_->host_ready_o; }
bool CcSim::cmdproc_ready() const { return top_->cmdproc_ready_o; }
bool CcSim::ras_fatal() const { return top_->ras_fatal_o; }
bool CcSim::tile_busy() const { return top_->tile_busy_o; }
bool CcSim::tsu_busy() const { return top_->tsu_busy_o; }
void CcSim::set_ext_warn(bool v) { top_->ext_warn_i = v ? 1 : 0; }
void CcSim::set_ext_fatal(bool v) { top_->ext_fatal_i = v ? 1 : 0; }

bool CcSim::devmem_contains(uint32_t addr, uint64_t bytes) const {
  return addr >= kDevmemBase && bytes <= kDevmemSize && (uint64_t)(addr - kDevmemBase) + bytes <= kDevmemSize;
}

void CcSim::devmem_write(uint32_t addr, const void *src, size_t bytes) {
  memcpy(reinterpret_cast<uint8_t *>(mem_.data()) + (addr - kDevmemBase), src, bytes);
}

void CcSim::devmem_read(uint32_t addr, void *dst, size_t bytes) const {
  memcpy(dst, reinterpret_cast<const uint8_t *>(mem_.data()) + (addr - kDevmemBase), bytes);
}

uint32_t CcSim::devmem_rd32(uint32_t addr) const { return mem_[(addr - kDevmemBase) >> 2]; }
void CcSim::devmem_wr32(uint32_t addr, uint32_t v) { mem_[(addr - kDevmemBase) >> 2] = v; }

std::string CcSim::take_console() {
  std::string s;
  s.swap(console_);
  return s;
}

}  // namespace sf::cc
