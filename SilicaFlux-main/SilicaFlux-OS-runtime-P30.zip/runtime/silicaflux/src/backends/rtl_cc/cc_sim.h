// SilicaFlux.OS -- ControlCore system RTL simulation harness.
//
// Wraps the Verilated P21 system `silicaflux_cc_hpc_system` (ControlCore RV32IM
// + HPC Module 08 FP32 vector tile + TENSORCORE 08 INT8 tensor unit, all
// unmodified RTL) and plays exactly the two roles the P21 testbench plays:
//   * HOST: an SFB2 master on the host access port (hs_*), the host reset pin;
//   * DEVICE MEMORY: the 1 MiB shared SRAM on the dm_* SFB2 slave port, with
//     the P21 testbench's semantics (one outstanding request, response one
//     cycle after acceptance, the 4 KiB "poison" window answering errors),
//     plus run-time fault injection (error ranges, random back-pressure).
// Everything else -- boot ROM, firmware, accelerator programming, interrupts --
// runs on the RTL.  Time advances only when the host calls tick().
#pragma once
#include <cstdint>
#include <memory>
#include <random>
#include <string>
#include <vector>

class Vsilicaflux_cc_hpc_system;
class VerilatedContext;

namespace sf::cc {

// P21 address map v1.0 (config/cc_memmap.yaml); checked against the generated header in the backend
constexpr uint32_t kDevmemBase = 0x20000000u;
constexpr uint32_t kDevmemSize = 0x00100000u;
constexpr uint32_t kPoisonBase = 0x200EF000u;
constexpr uint32_t kPoisonSize = 0x00001000u;

struct ErrRange {
  uint32_t lo, hi;   // [lo, hi)
  bool read, write;
};

class CcSim {
 public:
  explicit CcSim(uint64_t seed = 1);
  ~CcSim();
  CcSim(const CcSim &) = delete;
  CcSim &operator=(const CcSim &) = delete;

  // ---------------------------------------------------------------- time and reset
  void tick(uint64_t n = 1);
  uint64_t cycle() const { return cycle_; }
  void power_on_reset(unsigned cycles = 5);   // rst_ni low for `cycles`, then high
  void host_reset_pulse(unsigned cycles = 10);  // host_rst_req_i (cold boot of the ControlCore)

  // ---------------------------------------------------------------- host access port (SFB2 master)
  // Returns false on an error response or if the port did not answer within `timeout` cycles.
  bool host_read(uint32_t addr, uint32_t *val, uint64_t timeout = 200000);
  bool host_write(uint32_t addr, uint32_t val, uint64_t timeout = 200000);
  bool last_host_timeout() const { return last_timeout_; }

  // ---------------------------------------------------------------- pins
  bool host_irq() const;
  bool host_ready() const;
  bool cmdproc_ready() const;
  bool ras_fatal() const;
  bool tile_busy() const;
  bool tsu_busy() const;
  void set_ext_warn(bool v);
  void set_ext_fatal(bool v);

  // ---------------------------------------------------------------- device memory (the harness owns it)
  bool devmem_contains(uint32_t addr, uint64_t bytes) const;
  void devmem_write(uint32_t addr, const void *src, size_t bytes);   // host-visible window (no simulated time)
  void devmem_read(uint32_t addr, void *dst, size_t bytes) const;
  uint32_t devmem_rd32(uint32_t addr) const;
  void devmem_wr32(uint32_t addr, uint32_t v);
  void add_error_range(const ErrRange &r) { err_ranges_.push_back(r); }
  void clear_error_ranges();                  // keeps the P21 poison window
  void set_backpressure(int pct) { bp_pct_ = pct; }
  uint64_t devmem_reads() const { return dm_reads_; }
  uint64_t devmem_writes() const { return dm_writes_; }
  uint64_t devmem_stall_cycles() const { return dm_stalls_; }

  // ---------------------------------------------------------------- console tap (diag_valid_o / diag_char_o)
  std::string take_console();
  const std::string &console_log() const { return console_all_; }
  bool echo_console = false;

 private:
  bool host_access(bool wr, uint32_t addr, uint32_t wdata, uint32_t *rdata, uint64_t timeout);
  bool dm_bad(uint32_t addr, bool write) const;
  void drive_dm();

  std::unique_ptr<VerilatedContext> ctx_;
  std::unique_ptr<Vsilicaflux_cc_hpc_system> top_;
  uint64_t cycle_ = 0;
  std::mt19937_64 rng_;

  // device memory model
  std::vector<uint32_t> mem_;
  std::vector<ErrRange> err_ranges_;
  bool dm_rv_ = false, dm_re_ = false, dm_stall_ = false;
  uint32_t dm_rd_ = 0;
  int bp_pct_ = 0;
  uint64_t dm_reads_ = 0, dm_writes_ = 0, dm_stalls_ = 0;

  // host BFM
  enum class Hs { kIdle, kReq, kRsp, kDone } hs_ = Hs::kIdle;
  uint32_t hs_rdata_ = 0;
  bool hs_err_ = false;
  bool last_timeout_ = false;

  std::string console_, console_all_, line_;
};

}  // namespace sf::cc
