// SilicaFlux.OS -- HostLink physical transport: Linux VFIO (user space).
//
// STATUS: compiles against <linux/vfio.h>; NEVER EXECUTED.  No SilicaFlux PCIe
// device exists (no PCIe-capable board, endpoint IP or vendor tools: P25 audit).
// Uses the unmodified P25 VFIO backend, which:
//   * requires the function to be bound to vfio-pci by an administrator;
//   * maps BAR0 uncached, enables bus mastering;
//   * allocates DMA memory with mmap() and maps it into the device's IOVA space
//     with VFIO_IOMMU_MAP_DMA -- the device can reach ONLY those pages (the
//     IOMMU is the isolation boundary; HostLink windows restrict it further);
//   * routes MSI-X/MSI vectors to eventfds.
// It never bypasses the IOMMU and never hands the device a user pointer.
#include <sched.h>

#include "hl_transport.h"
extern "C" {
#include "sfh_backend_vfio.h"   // P25 C header without C++ guards
}

namespace sf::hl {
namespace {

class VfioTransport : public Transport {
 public:
  ~VfioTransport() override {
    if (open_) sfh_vfio_close(&v_);
  }
  sf_status open(const std::string &bdf) {
    if (sfh_vfio_open(&v_, bdf.c_str()) != 0)
      return fail(SF_ERR_NO_DEVICE, "VFIO open of %s failed (see stderr): is it bound to vfio-pci with the IOMMU on?",
                  bdf.c_str());
    open_ = true;
    return SF_OK;
  }
  const sfh_backend_ops *ops() override { return sfh_vfio_backend_ops(); }
  void *ctx() override { return &v_; }
  bool simulator() const override { return false; }
  const char *name() const override { return "Linux VFIO (physical PCIe)"; }
  uint32_t clock_mhz() const override { return 0; }
  void advance() override { sched_yield(); }
  uint64_t time_us() override { return host_ns() / 1000; }
  sf_status hot_reset() override {
    // a function-level reset is VFIO_DEVICE_RESET; until it has been validated on hardware
    // the runtime only uses the HostLink function reset (CTRL.RESET)
    return fail(SF_ERR_UNSUPPORTED, "function-level reset not validated on hardware");
  }

 private:
  sfh_vfio v_{};
  bool open_ = false;
};

}  // namespace

std::unique_ptr<Transport> make_vfio_transport(const std::string &bdf) {
  auto t = std::make_unique<VfioTransport>();
  if (t->open(bdf) != SF_OK) return nullptr;
  return t;
}

}  // namespace sf::hl
