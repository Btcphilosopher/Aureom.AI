// SilicaFlux.OS -- HostLink simulation transport: the P25 host model (SfhSim)
// around the Verilated sfh_device_top.  The model plays PCIe endpoint IP + root
// complex + IOMMU + host memory + CPU MMIO at the endpoint's AXI boundary; all
// SilicaFlux-side logic (BAR registers, queues, DMA engine, tensor engine) is
// the unmodified P25 RTL.
#include "hl_transport.h"
#include "sfh_sim.h"

namespace sf::hl {
namespace {

class SimTransport : public Transport {
 public:
  SimTransport() {
    SimCfg cfg;           // P25 defaults: 24-cycle host read latency, strict PCIe posted-write ordering
    cfg.seed = 1;
    sim_ = std::make_unique<SfhSim>(cfg);
  }
  const sfh_backend_ops *ops() override { return sfh_sim_backend_ops(); }
  void *ctx() override { return sim_.get(); }
  bool simulator() const override { return true; }
  const char *name() const override { return "Verilated P25 sfh_device_top + PCIe/IOMMU host model"; }
  uint32_t clock_mhz() const override { return (uint32_t)SfhSim::kMHz; }
  void advance() override { sim_->tick(64); }
  uint64_t time_us() override { return sim_->now_us(); }
  sf_status hot_reset() override {
    sim_->ep_reset();
    return SF_OK;
  }
  sf_status inject_host_error(uint64_t iova, uint64_t size) override {
    sim_->inject_error(iova, iova + size, false);   // device reads of host memory (H2D) fail
    sim_->inject_error(iova, iova + size, true);    // device writes to host memory (D2H) fail
    return SF_OK;
  }
  sf_status clear_host_errors() override {
    sim_->clear_errors();
    return SF_OK;
  }
  void counters(std::vector<sf_counter> &out) override {
    auto add = [&](const char *n, uint64_t v, uint32_t unit) {
      sf_counter c{};
      snprintf(c.name, sizeof c.name, "%s", n);
      c.value = v;
      c.unit = unit;
      c.source = SF_SRC_SIMULATOR;
      out.push_back(c);
    };
    add("sim.cycles", sim_->cycle(), SF_UNIT_CYCLES);
    add("sim.host_bursts", sim_->host_bursts, SF_UNIT_EVENTS);
    add("sim.host_read_beats", sim_->host_rd_beats, SF_UNIT_EVENTS);
    add("sim.host_write_beats", sim_->host_wr_beats, SF_UNIT_EVENTS);
    add("sim.msi_messages", sim_->irq_msgs, SF_UNIT_EVENTS);
    add("sim.protocol_violations", sim_->violations.size(), SF_UNIT_EVENTS);
    add("sim.iommu_faults", sim_->faults.size(), SF_UNIT_EVENTS);
  }

 private:
  std::unique_ptr<SfhSim> sim_;
};

}  // namespace

std::unique_ptr<Transport> make_sim_transport() { return std::make_unique<SimTransport>(); }

}  // namespace sf::hl
