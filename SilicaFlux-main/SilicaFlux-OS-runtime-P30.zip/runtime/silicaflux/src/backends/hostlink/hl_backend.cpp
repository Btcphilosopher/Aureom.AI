// SilicaFlux.OS -- HostLink backend (P25 PCIe host interface, ABI 1.0).
//
// Device: P25 sfh_device_top = HostLink (BAR0 registers, host-memory SQ/CQ
// rings, DMA descriptor engine, isolation windows, MSI) + DataFabric + 64 KiB
// device SRAM (DEVMEM0) + SilicaFlux-V tile with the 4x4 INT8 tensor engine and
// its 16 KiB scratchpad (DEVMEM1, "TSPM").  Driven through the unmodified P25 C
// driver (sfh_driver.c) over a transport (simulation or VFIO).
//
// What the device can do and what this backend therefore offers:
//   * buffers in DEVMEM0, host transfers by H2D/D2H DMA from an IOMMU-mapped
//     staging pool (user pointers are copied, never given to the device);
//   * INT8 x INT8 -> INT32 GEMM.  The tensor engine computes ONE 4x4 output
//     block per command from TSPM-resident operands in a fixed layout (A
//     column-major 4xK, B row-major Kx4).  A general GEMM therefore needs its
//     operands re-laid-out: the backend reads A and B by DMA, re-lays them out
//     on the host, DMAs the blocks into TSPM, runs one TENSOR_GEMM per 4x4 block
//     and K chunk (K-splitting with the engine's ACC flag) and DMAs C back.
//     Every multiply-accumulate runs on the tensor engine; the host re-layout
//     is reported with SF_RESULT_HOST_ASSISTED.
//   * NOT offered (rejected with SF_ERR_UNSUPPORTED): vector operations (the
//     VECTOR opcode is reserved in HostLink ABI 1.0), requantised INT8 output
//     (the SilicaFlux-V engine has none), device-to-device copy (no such
//     opcode).  With SF_OPEN_ALLOW_CPU_FALLBACK the runtime runs them on the CPU
//     and marks them SF_EXEC_CPU_FALLBACK.
#include <algorithm>
#include <cstring>
#include <deque>
#include <functional>

#include "hl_transport.h"

namespace sf {
namespace {

constexpr uint32_t kSqLog2 = 6, kCqLog2 = 6;
constexpr uint64_t kJobPool = 4u << 20;     // staging for one GEMM job (operands, packed blocks, C)
constexpr uint64_t kSyncPool = 64u << 10;   // staging for sf_buffer_write / sf_buffer_read
constexpr uint32_t kKChunk = 1024;          // TENSOR_GEMM k field: 1..1024

sf_status map_status(uint32_t st) {
  switch (st) {
    case SFH_STATUS_SUCCESS: return SF_OK;
    case SFH_STATUS_HOST_BUS_ERROR:
    case SFH_STATUS_DEV_BUS_ERROR: return SF_ERR_DMA;
    case SFH_STATUS_ENGINE_ERROR: return SF_ERR_DEVICE;
    case SFH_STATUS_ENGINE_TIMEOUT: return SF_ERR_TIMEOUT;
    default: return SF_ERR_INVALID_COMMAND;   // INVALID_OPCODE / FIELD / LENGTH / MISALIGNED / ADDR_DENIED / DEV_ADDR
  }
}

uint64_t rd8(uint64_t a) { return a & ~7ull; }
uint64_t ru8(uint64_t a) { return (a + 7) & ~7ull; }

// One API command executing as a sequence of phases; each phase does host work and
// returns HostLink entries.  Phase i+1 starts when every entry of phase i completed.
struct Job {
  Command *cmd = nullptr;
  std::vector<std::function<sf_status(Job &, std::vector<sfh_sqe> &)>> phases;
  std::function<void(Job &)> finish;
  size_t phase = 0;
  std::vector<sfh_sqe> sqes;
  size_t pushed = 0, completed = 0;
  bool started = false, failed = false;
  sf_status status = SF_OK;
  uint32_t dev_status = 0, dev_error = 0;
  uint64_t engine_cycles = 0;
  uint32_t entries = 0;
  // staging (host side, IOMMU-mapped pool): offsets into the job pool
  uint64_t a_off = 0, b_off = 0, c_off = 0, p_off = 0, o_off = 0;
  uint64_t a_span = 0, b_span = 0, c_span = 0;
};

class HlBackend;

class HlQueue : public BackendQueue {
 public:
  HlQueue(HlBackend &be, uint32_t depth) : be_(be), depth_(depth) {}
  ~HlQueue() override;
  sf_status start(Command &c) override;
  sf_status poll(std::deque<Command *> &started) override;
  void abandon() override;
  uint32_t capacity() const override { return depth_; }

 private:
  HlBackend &be_;
  uint32_t depth_;
};

class HlBackend : public Backend {
 public:
  HlBackend(std::unique_ptr<hl::Transport> t, sf_exec_target target) : t_(std::move(t)), target_(target) {}
  ~HlBackend() override { close(); }

  // ------------------------------------------------------------------ bring-up (P25 docs/02 section 3)
  sf_status open(uint32_t) override {
    uint32_t id = t_->ops()->mmio_read32(t_->ctx(), SFH_REG_ID);
    if (id != SFH_DEVICE_MAGIC) return fail(SF_ERR_NO_DEVICE, "BAR0 ID %08x is not 'SFHL': not a SilicaFlux HostLink function", id);
    uint32_t ver = t_->ops()->mmio_read32(t_->ctx(), SFH_REG_VERSION);
    if ((ver >> 16) != SFH_ABI_MAJOR)
      return fail(SF_ERR_INCOMPATIBLE_VERSION, "HostLink ABI %u.%u is not supported (this library: %u.x)", ver >> 16,
                  ver & 0xFFFF, SFH_ABI_MAJOR);
    if (sfh_open(&d_, t_->ops(), t_->ctx()) != SFH_OK) return fail(SF_ERR_NO_DEVICE, "sfh_open failed");
    if (t_->ops()->dma_alloc(t_->ctx(), kJobPool, &job_pool_) != 0) return fail(SF_ERR_OUT_OF_MEMORY, "host DMA pool");
    if (t_->ops()->dma_alloc(t_->ctx(), kSyncPool, &sync_pool_) != 0) return fail(SF_ERR_OUT_OF_MEMORY, "host DMA pool");
    return init_device();
  }

  sf_status init_device() {
    ring_.clear();
    if (sfh_reset(&d_, 100000) != SFH_OK) return lost("function reset did not complete");
    if (sfh_queues_alloc(&d_, kSqLog2, kCqLog2) != SFH_OK) return fail(SF_ERR_DEVICE, "queue setup refused");
    // least privilege: windows 0/1 = rings (driver), 2 = job staging, 3 = transfer staging
    uint32_t rw = SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_READ_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK;
    if (d_.num_windows < 4 || sfh_set_window(&d_, 2, job_pool_.iova, job_pool_.size, rw) != SFH_OK ||
        sfh_set_window(&d_, 3, sync_pool_.iova, sync_pool_.size, rw) != SFH_OK)
      return fail(SF_ERR_DEVICE, "DMA window setup refused");
    sfh_irq_setup(&d_, 0);   // completion by CQ phase polling (interrupts are only a wake-up hint)
    if (sfh_enable(&d_, 0) != SFH_OK)
      return fail(SF_ERR_DEVICE, "queue enable refused (ERR_STATUS %08x)", sfh_rd(&d_, SFH_REG_ERR_STATUS));
    lost_ = false;
    return SF_OK;
  }

  void close() override {
    if (!t_) return;
    if (d_.ops && !lost_) {
      sfh_disable(&d_, 100000);
      sfh_queues_free(&d_);
    }
    if (job_pool_.va) t_->ops()->dma_free(t_->ctx(), &job_pool_);
    if (sync_pool_.va) t_->ops()->dma_free(t_->ctx(), &sync_pool_);
    t_.reset();
  }

  void fill_info(sf_device_info &i) override {
    i.caps = SF_CAP_HW_COUNTERS | (t_->simulator() ? SF_CAP_FAULT_INJECTION : 0u);
    if (d_.caps & SFH_CAPS_TENSOR_GEMM_MASK) i.caps |= SF_CAP_GEMM_I8_I32;
    i.device_abi_version = d_.version;
    i.hardware_revision = d_.hw_rev;
    snprintf(i.hardware_id, sizeof i.hardware_id, "SilicaFlux P25 HostLink + SilicaFlux-V tile (%s)",
             t_->simulator() ? "RTL sim" : "PCIe");
    i.max_queue_depth = 16;
    i.max_queues = 1;              // one hardware submission queue
    i.vector_lanes = 0;
    i.max_vector_elements = 0;
    i.gemm_max_m = 65535;
    i.gemm_max_n = 65535;
    i.gemm_max_k = 131071;         // int32 accumulation bound (as the TENSORCORE contract)
    i.tensor_array_rows = 4;
    i.tensor_array_cols = 4;
    i.nominal_clock_mhz = t_->clock_mhz();
    i.default_timeout_ms = t_->simulator() ? 100 : 10000;
  }
  std::vector<MemRegion> memory_regions() override { return {{d_.devmem_base[0], d_.devmem_size[0]}}; }

  // ------------------------------------------------------------------ ring manager (all entries, in order)
  struct Slot {
    uint32_t txn;
    std::function<void(const sfh_cqe &)> done;
  };

  sf_status lost(const char *what) {
    lost_ = true;
    return fail(SF_ERR_DEVICE_LOST, "HostLink: %s (STATUS %08x ERR_STATUS %08x)", what,
                sfh_rd(&d_, SFH_REG_STATUS), sfh_rd(&d_, SFH_REG_ERR_STATUS));
  }

  bool push(sfh_sqe e, std::function<void(const sfh_cqe &)> done) {
    e.txn_id = d_.next_txn++;
    if (sfh_push(&d_, &e) != SFH_OK) {
      d_.next_txn--;
      return false;
    }
    ring_.push_back({e.txn_id, std::move(done)});
    dirty_ = true;
    return true;
  }

  // ring the doorbell for pushed entries and dispatch every completion that arrived
  sf_status pump() {
    if (lost_) return SF_ERR_DEVICE_LOST;
    if (dirty_) {
      sfh_ring(&d_);
      dirty_ = false;
    }
    sfh_cqe c;
    while (sfh_poll_cqe(&d_, &c) == 1) {
      if (ring_.empty() || ring_.front().txn != c.txn_id) return lost("completion out of order");
      auto done = std::move(ring_.front().done);
      ring_.pop_front();
      done(c);
    }
    if (!ring_.empty() && (sfh_rd(&d_, SFH_REG_STATUS) & SFH_STATUS_FATAL_MASK)) return lost("device FATAL");
    return SF_OK;
  }

  // blocking helper for host transfers (other owners' completions are dispatched meanwhile)
  sf_status run_sync(const sfh_sqe &e) {
    bool done = false;
    uint32_t st = 0;
    uint64_t t0 = t_->time_us();
    while (!push(e, [&](const sfh_cqe &c) {
      done = true;
      st = SFH_CQE_STATUS(c.dw3);
    })) {
      if (sf_status s = step()) return s;
      if (t_->time_us() - t0 > 100000) return lost("submission queue never drained");
    }
    while (!done) {
      if (sf_status s = step()) return s;
      if (t_->time_us() - t0 > (t_->simulator() ? 100000u : 10000000u)) return lost("DMA did not complete");
    }
    if (st != SFH_STATUS_SUCCESS)
      return fail(map_status(st), "HostLink DMA failed: %s", sfh_status_str(st));
    return SF_OK;
  }

  sf_status step() {
    if (sf_status s = pump()) return s;
    t_->advance();
    progress_jobs();
    return pump();
  }

  // ------------------------------------------------------------------ host transfers (H2D / D2H DMA)
  sf_status transfer(uint64_t addr, void *host, uint64_t n, bool to_device) {
    if (lost_) return fail(SF_ERR_DEVICE_LOST, "device lost");
    uint8_t *pool = static_cast<uint8_t *>(sync_pool_.va);
    for (uint64_t off = 0; off < n;) {
      uint64_t a = addr + off, len = std::min<uint64_t>(n - off, kSyncPool - 16);
      uint64_t s0 = rd8(a), s1 = ru8(a + len), span = s1 - s0;   // DMA needs 8-byte multiples
      sfh_sqe e;
      if (to_device) {
        if (s0 != a || s1 != a + len) {                            // read-modify-write of the edges
          sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, s0, sync_pool_.iova, (uint32_t)span, 0);
          if (sf_status s = run_sync(e)) return s;
        }
        memcpy(pool + (a - s0), static_cast<uint8_t *>(host) + off, len);
        sfh_wmb();
        sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, sync_pool_.iova, s0, (uint32_t)span, 0);
        if (sf_status s = run_sync(e)) return s;
      } else {
        sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, s0, sync_pool_.iova, (uint32_t)span, 0);
        if (sf_status s = run_sync(e)) return s;
        sfh_rmb();
        memcpy(static_cast<uint8_t *>(host) + off, pool + (a - s0), len);
      }
      off += len;
    }
    return SF_OK;
  }
  sf_status write(uint64_t a, const void *s, uint64_t n) override { return transfer(a, const_cast<void *>(s), n, true); }
  sf_status read(uint64_t a, void *d, uint64_t n) override { return transfer(a, d, n, false); }

  // ------------------------------------------------------------------ commands
  sf_status create_queue(uint32_t depth, std::unique_ptr<BackendQueue> *q) override {
    *q = std::make_unique<HlQueue>(*this, depth);
    return SF_OK;
  }

  sf_status check(const Command &c) override {
    switch (c.op) {
      case SF_OP_GEMM:
        if (!(d_.caps & SFH_CAPS_TENSOR_GEMM_MASK)) return fail(SF_ERR_UNSUPPORTED, "no TENSOR_GEMM capability");
        if (c.gemm.out_i8)
          return fail(SF_ERR_UNSUPPORTED, "the SilicaFlux-V tensor engine has no requantised INT8 output");
        if (c.gemm.k > 131071) return fail(SF_ERR_UNSUPPORTED, "K > 131071 could overflow the INT32 accumulators");
        return SF_OK;
      case SF_OP_RAW:
        return fail(SF_ERR_UNSUPPORTED, "raw engine descriptors are not reachable through HostLink ABI 1.0");
      case SF_OP_COPY:
        return fail(SF_ERR_UNSUPPORTED, "HostLink ABI 1.0 has no device-to-device copy");
      default:
        return fail(SF_ERR_UNSUPPORTED, "HostLink ABI 1.0 has no vector opcode (0x03 reserved)");
    }
  }

  // GEMM job: read operands -> per batch: re-layout, H2D blocks, TENSOR_GEMMs, D2H C blocks -> write C
  sf_status build_gemm(Command &c, std::shared_ptr<Job> &out) {
    auto j = std::make_shared<Job>();
    j->cmd = &c;
    const GemmArgs g = c.gemm;
    const uint32_t MB = (g.m + 3) / 4, NB = (g.n + 3) / 4;
    const uint64_t fa = (uint64_t)(g.m - 1) * g.lda + g.k, fb = (uint64_t)(g.k - 1) * g.ldb + g.n;
    const uint64_t fc = (uint64_t)(g.m - 1) * g.ldc + 4ull * g.n;
    const uint32_t nchunks = (g.k + kKChunk - 1) / kKChunk;
    const uint32_t kp = (g.k + 1) & ~1u;                         // K padded so 4*kp is a multiple of 8
    const uint32_t blk = 8 * kp;                                 // A block + B block bytes (single chunk)
    const uint32_t tspm = d_.devmem_size[1];
    if (blk + 64 > tspm || 8 * kKChunk + 64 > tspm) return fail(SF_ERR_UNSUPPORTED, "tensor scratchpad too small");
    const uint32_t group = nchunks == 1 ? std::max<uint32_t>(1, std::min<uint32_t>(MB * NB, tspm / (blk + 64))) : 1;
    const uint32_t nblocks = MB * NB, nbatches = (nblocks + group - 1) / group;
    // staging layout in the job pool
    j->a_span = ru8(g.a + fa) - rd8(g.a);
    j->b_span = ru8(g.b + fb) - rd8(g.b);
    j->c_span = ru8(g.c + fc) - rd8(g.c);
    j->a_off = 0;
    j->b_off = ru8(j->a_off + j->a_span);
    j->c_off = ru8(j->b_off + j->b_span);
    j->o_off = ru8(j->c_off + j->c_span);
    j->p_off = ru8(j->o_off + 64ull * nblocks);
    uint64_t pbytes = nchunks == 1 ? (uint64_t)group * blk : (uint64_t)nchunks * 8 * kKChunk;
    if (j->p_off + pbytes > kJobPool) return fail(SF_ERR_UNSUPPORTED, "GEMM staging exceeds the host DMA pool");
    uint8_t *pool = static_cast<uint8_t *>(job_pool_.va);
    const uint64_t iova = job_pool_.iova, ts = d_.devmem_base[1];
    bool dense_c = (g.ldc == 4 * g.n) && rd8(g.c) == g.c && ru8(g.c + fc) == g.c + fc;

    // phase 0: operands (and C, when gaps between C rows must be preserved) to host staging
    j->phases.push_back([=](Job &jb, std::vector<sfh_sqe> &q) {
      sfh_sqe e;
      sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, rd8(g.a), iova + jb.a_off, (uint32_t)jb.a_span, 0);
      q.push_back(e);
      sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, rd8(g.b), iova + jb.b_off, (uint32_t)jb.b_span, 0);
      q.push_back(e);
      if (!dense_c) {
        sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, rd8(g.c), iova + jb.c_off, (uint32_t)jb.c_span, 0);
        q.push_back(e);
      }
      return SF_OK;
    });
    // phases 1..: one batch of output blocks each
    for (uint32_t bt = 0; bt < nbatches; bt++) {
      j->phases.push_back([=](Job &jb, std::vector<sfh_sqe> &q) {
        sfh_rmb();
        const int8_t *A = reinterpret_cast<const int8_t *>(pool + jb.a_off + (g.a - rd8(g.a)));
        const int8_t *B = reinterpret_cast<const int8_t *>(pool + jb.b_off + (g.b - rd8(g.b)));
        uint8_t *P = pool + jb.p_off;
        auto pack = [&](uint32_t bi, uint32_t bj, uint32_t k0, uint32_t kn, uint8_t *dstA, uint8_t *dstB) {
          for (uint32_t k = 0; k < kn; k++)
            for (uint32_t r = 0; r < 4; r++) {
              uint32_t row = 4 * bi + r, col = 4 * bj + r;
              dstA[4 * k + r] = row < g.m ? (uint8_t)A[(uint64_t)row * g.lda + k0 + k] : 0;   // A column-major
              dstB[4 * k + r] = col < g.n ? (uint8_t)B[(uint64_t)(k0 + k) * g.ldb + col] : 0;  // B row-major
            }
        };
        sfh_sqe e;
        if (nchunks == 1) {
          uint32_t first = bt * group, cnt = std::min(group, nblocks - first);
          uint32_t c_area = (cnt * blk + 15) & ~15u;
          memset(P, 0, (size_t)cnt * blk);
          for (uint32_t x = 0; x < cnt; x++) {
            uint32_t bi = (first + x) / NB, bj = (first + x) % NB;
            pack(bi, bj, 0, g.k, P + (size_t)x * blk, P + (size_t)x * blk + 4 * kp);
          }
          sfh_wmb();
          sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, iova + jb.p_off, ts, cnt * blk, 0);
          q.push_back(e);
          for (uint32_t x = 0; x < cnt; x++) {
            sfh_sqe_gemm(&e, x * blk, x * blk + 4 * kp, c_area + 64 * x, g.k, 0, 0);
            q.push_back(e);
          }
          sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, ts + c_area, iova + jb.o_off + 64ull * first, 64 * cnt, 0);
          q.push_back(e);
        } else {   // K > 1024: one block per batch, K chunks accumulated in the engine (ACC)
          uint32_t bi = bt / NB, bj = bt % NB;
          for (uint32_t ch = 0; ch < nchunks; ch++) {
            uint32_t k0 = ch * kKChunk, kn = std::min(kKChunk, g.k - k0);
            uint8_t *dst = P + (size_t)ch * 8 * kKChunk;
            memset(dst, 0, 8 * kKChunk);
            pack(bi, bj, k0, kn, dst, dst + 4 * kKChunk);
            sfh_wmb();
            sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, iova + jb.p_off + (uint64_t)ch * 8 * kKChunk, ts, 8 * kKChunk, 0);
            q.push_back(e);
            sfh_sqe_gemm(&e, 0, 4 * kKChunk, 8 * kKChunk, kn, ch ? 1u : 0u, 0);   // te_flags bit 0: ACC
            q.push_back(e);
          }
          sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, ts + 8 * kKChunk, iova + jb.o_off + 64ull * bt, 64, 0);
          q.push_back(e);
        }
        return SF_OK;
      });
    }
    // last phase: blocks -> C image -> device
    j->phases.push_back([=](Job &jb, std::vector<sfh_sqe> &q) {
      sfh_rmb();
      uint8_t *Cimg = pool + jb.c_off + (g.c - rd8(g.c));
      for (uint32_t b = 0; b < nblocks; b++) {
        uint32_t bi = b / NB, bj = b % NB;
        const uint8_t *blkc = pool + jb.o_off + 64ull * b;
        for (uint32_t r = 0; r < 4; r++)
          for (uint32_t cc = 0; cc < 4; cc++) {
            uint32_t row = 4 * bi + r, col = 4 * bj + cc;
            if (row < g.m && col < g.n) memcpy(Cimg + (uint64_t)row * g.ldc + 4ull * col, blkc + 16 * r + 4 * cc, 4);
          }
      }
      sfh_wmb();
      sfh_sqe e;
      sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, iova + jb.c_off, rd8(g.c), (uint32_t)jb.c_span, 0);
      q.push_back(e);
      return SF_OK;
    });
    j->finish = [=](Job &jb) {
      sf_cmd_result &r = jb.cmd->result;
      r.engine_cycles = jb.engine_cycles;
      r.device_commands = jb.entries;
      r.flags |= SF_RESULT_HOST_ASSISTED | SF_RESULT_CHUNKED;
      if (jb.status == SF_OK) {
        r.elements = (uint64_t)g.m * g.n;
        r.macs = (uint64_t)g.m * g.n * g.k;
      }
    };
    out = j;
    return SF_OK;
  }

  // drive the active job: push its entries as ring space allows, advance phases
  void progress_jobs() {
    while (!jobs_.empty()) {
      Job &j = *jobs_.front();
      if (!j.started) {
        j.started = true;
        j.cmd->result.exec_target = target_;
      }
      // a phase ends when every pushed entry completed and nothing remains to push (or it failed)
      if (j.completed == j.pushed && (j.pushed == j.sqes.size() || j.failed)) {
        if (j.failed || j.phase == j.phases.size()) {
          if (j.finish) j.finish(j);
          j.cmd->result.status = j.status;
          j.cmd->result.device_status = j.dev_status;
          j.cmd->result.device_error = j.dev_error;
          j.cmd->done = true;
          jobs_.pop_front();
          continue;
        }
        j.sqes.clear();
        j.pushed = j.completed = 0;
        sf_status s = j.phases[j.phase++](j, j.sqes);
        if (s != SF_OK) {
          j.failed = true;
          j.status = s;
          continue;
        }
      }
      while (j.pushed < j.sqes.size() && !j.failed) {
        Job *jp = &j;
        uint32_t op = j.sqes[j.pushed].opcode;
        if (!push(j.sqes[j.pushed], [this, jp, op](const sfh_cqe &c) {
              uint32_t st = SFH_CQE_STATUS(c.dw3);
              jp->completed++;
              jp->entries++;
              if (op == SFH_OP_TENSOR_GEMM && st == SFH_STATUS_SUCCESS) jp->engine_cycles += c.result;
              if (st != SFH_STATUS_SUCCESS && !jp->failed) {
                jp->failed = true;
                jp->status = map_status(st);
                jp->dev_status = st;
                jp->dev_error = c.result;
              }
            }))
          break;
        j.pushed++;
      }
      return;   // one active job at a time (the engine executes in order anyway)
    }
  }

  void enqueue_job(std::shared_ptr<Job> j) { jobs_.push_back(std::move(j)); }
  void drop_jobs() { jobs_.clear(); }

  void advance() override {
    if (lost_) return;
    t_->advance();
    progress_jobs();
    pump();
    progress_jobs();
  }
  uint64_t device_time_us() override { return t_->time_us(); }
  bool is_simulator() const override { return t_->simulator(); }
  sf_exec_target exec_target() const override { return target_; }

  // ------------------------------------------------------------------ management
  sf_status reset(sf_reset_level level) override {
    jobs_.clear();
    ring_.clear();
    dirty_ = false;
    if (level == SF_RESET_FULL) {
      sf_status s = t_->hot_reset();
      if (s != SF_OK && s != SF_ERR_UNSUPPORTED) return s;
    }
    sfh_queues_free(&d_);
    return init_device();   // CTRL.RESET: finishes the bus transaction in flight, resets the tile
  }

  sf_status status(sf_device_status &st) override {
    uint32_t s = sfh_rd(&d_, SFH_REG_STATUS), e = sfh_rd(&d_, SFH_REG_ERR_STATUS);
    st.state = (s & SFH_STATUS_FATAL_MASK) ? SF_STATE_LOST : SF_STATE_READY;
    st.ras_status = e;   // HostLink has no RAS block: ERR_STATUS is the closest error status
    snprintf(st.detail, sizeof st.detail, "HostLink ABI %u.%u HW_REV %08x: STATUS %08x ERR_STATUS %08x (no RAS block on this device)",
             d_.version >> 16, d_.version & 0xFFFF, d_.hw_rev, s, e);
    return SF_OK;
  }

  sf_status read_counters(std::vector<sf_counter> &out) override {
    static const char *names[SFH_NUM_PERF] = {"cmds_completed", "cmds_failed", "bytes_h2d", "bytes_d2h", "busy_cycles",
                                              "host_wait_cycles", "cq_full_cycles", "irq_msgs", "engine_cycles", "doorbells"};
    static const uint32_t units[SFH_NUM_PERF] = {SF_UNIT_EVENTS, SF_UNIT_EVENTS, SF_UNIT_BYTES, SF_UNIT_BYTES, SF_UNIT_CYCLES,
                                                 SF_UNIT_CYCLES, SF_UNIT_CYCLES, SF_UNIT_EVENTS, SF_UNIT_CYCLES, SF_UNIT_EVENTS};
    sfh_perf_snapshot(&d_);
    for (unsigned i = 0; i < SFH_NUM_PERF; i++) {
      sf_counter c{};
      snprintf(c.name, sizeof c.name, "hostlink.%s", names[i]);
      c.value = sfh_perf_read(&d_, i);
      c.unit = units[i];
      c.source = SF_SRC_HARDWARE;
      out.push_back(c);
    }
    t_->counters(out);
    return SF_OK;
  }
  sf_status clear_counters() override {
    sfh_wr(&d_, SFH_REG_PERF_CTRL, SFH_PERF_CTRL_CLEAR_MASK);
    return SF_OK;
  }
  sf_status perf_summary(sf_perf_summary &s) override {
    sfh_perf_snapshot(&d_);
    s.device_dma_bytes = sfh_perf_read(&d_, SFH_PERF_BYTES_H2D) + sfh_perf_read(&d_, SFH_PERF_BYTES_D2H);
    s.dma_stall_cycles = sfh_perf_read(&d_, SFH_PERF_HOST_WAIT_CYCLES);
    s.queue_full_cycles = sfh_perf_read(&d_, SFH_PERF_CQ_FULL_CYCLES);
    return SF_OK;   // no free-running cycle, MAC or vector counter exists on this device: left unset
  }
  sf_status inject(sf_inject_kind kind, uint64_t, uint64_t) override {
    if (kind == SF_INJECT_HOST_DMA_ERROR) {   // the whole staging pool: the next host-side DMA fails
      if (sf_status s = t_->inject_host_error(job_pool_.iova, job_pool_.size)) return s;
      return t_->inject_host_error(sync_pool_.iova, sync_pool_.size);
    }
    if (kind == SF_INJECT_CLEAR) return t_->clear_host_errors();
    return fail(SF_ERR_UNSUPPORTED, "HostLink simulation injects host-side (PCIe/IOMMU) DMA errors only");
  }

  std::deque<std::shared_ptr<Job>> jobs_;

 private:
  std::unique_ptr<hl::Transport> t_;
  sf_exec_target target_;
  sfh_dev d_{};
  sfh_dma_buf job_pool_{}, sync_pool_{};
  std::deque<Slot> ring_;
  bool dirty_ = false, lost_ = false;
  friend class HlQueue;
};

HlQueue::~HlQueue() {}

sf_status HlQueue::start(Command &c) {
  if (be_.lost_) return fail(SF_ERR_DEVICE_LOST, "device lost");
  std::shared_ptr<Job> j;
  if (sf_status s = be_.build_gemm(c, j)) return s;
  c.backend_state = j;
  be_.enqueue_job(j);
  be_.progress_jobs();
  return be_.pump() == SF_ERR_DEVICE_LOST ? SF_ERR_DEVICE_LOST : SF_OK;
}

sf_status HlQueue::poll(std::deque<Command *> &) {
  sf_status s = be_.pump();
  be_.progress_jobs();
  return s == SF_ERR_DEVICE_LOST ? SF_ERR_DEVICE_LOST : SF_OK;
}

void HlQueue::abandon() { be_.drop_jobs(); }

}  // namespace

#ifdef SF_HAVE_RTL_HOSTLINK
std::unique_ptr<Backend> make_hostlink_sim_backend(const DeviceEntry &) {
  return std::make_unique<HlBackend>(hl::make_sim_transport(), SF_EXEC_RTL_SIMULATION);
}
#endif

#ifdef SF_HAVE_VFIO
// Discovery only lists functions whose IDs were configured; opening one verifies the BAR0 ID.
std::unique_ptr<Backend> make_hostlink_vfio_backend(const DeviceEntry &e) {
  auto t = hl::make_vfio_transport(e.arg);
  if (!t) return nullptr;
  return std::make_unique<HlBackend>(std::move(t), SF_EXEC_HARDWARE);
}
#endif

}  // namespace sf
