// SilicaFlux.OS -- HostLink transports.
//
// The HostLink protocol layer (hl_backend.cpp + the vendored P25 C driver
// sfh_driver.c) is identical for every transport; only the transport differs:
//   * hl_sim_transport.cpp : Verilated P25 sfh_device_top behind the P25
//                            transaction-level PCIe endpoint / root complex /
//                            IOMMU / host-memory model (SfhSim).  Runs.
//   * hl_vfio_transport.cpp: Linux VFIO user-space access to a physical PCIe
//                            function (P25 sfh_backend_vfio.c).  Compiles; it has
//                            never executed because no SilicaFlux PCIe hardware
//                            exists (P25 docs/08_FPGA_BRINGUP.md).
#pragma once
#include <memory>
#include <string>
#include <vector>

#include "../../core/internal.h"
#include "sfh_driver.h"

namespace sf::hl {

class Transport {
 public:
  virtual ~Transport() = default;
  virtual const sfh_backend_ops *ops() = 0;
  virtual void *ctx() = 0;
  virtual bool simulator() const = 0;
  virtual const char *name() const = 0;
  virtual uint32_t clock_mhz() const = 0;            // nominal (simulator) clock for time conversion
  virtual void advance() = 0;                        // let the device progress (simulator: clock cycles)
  virtual uint64_t time_us() = 0;
  virtual sf_status hot_reset() = 0;                 // endpoint hot reset / FLR (resets counters too)
  virtual sf_status inject_host_error(uint64_t iova, uint64_t size) { return fail(SF_ERR_UNSUPPORTED, "not a simulator"); }
  virtual sf_status clear_host_errors() { return fail(SF_ERR_UNSUPPORTED, "not a simulator"); }
  virtual void counters(std::vector<sf_counter> &out) {}
};

std::unique_ptr<Transport> make_sim_transport();
std::unique_ptr<Transport> make_vfio_transport(const std::string &bdf);   // nullptr + fail() detail on error

}  // namespace sf::hl
