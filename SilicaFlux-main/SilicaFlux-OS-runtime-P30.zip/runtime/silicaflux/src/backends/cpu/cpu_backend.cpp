// SilicaFlux.OS -- CPU reference backend.
//
// Device kind SF_DEVICE_CPU_REFERENCE: it never claims to be SilicaFlux
// hardware.  It implements exactly the operation set and numeric contracts of
// the SilicaFlux engines (src/ref/), so it serves for correctness, differential
// testing and API development.  Commands execute in the calling thread during
// sf_queue_poll / sf_queue_wait, one per step, in queue order (deterministic,
// no hidden threads).  "Device memory" is a lazily committed host mapping;
// device addresses are offsets from kBase, never host pointers.
#include <sys/mman.h>

#include <algorithm>
#include <chrono>
#include <cstring>

#include "../../core/internal.h"

namespace sf {
namespace {

constexpr uint64_t kBase = 0x100000000ull;
constexpr uint64_t kSize = 1ull << 30;   // 1 GiB address space, committed on first touch
constexpr unsigned kLanes = 4;           // reduction width of the reference SilicaFlux tile configuration

class CpuMem : public MemAccess {
 public:
  explicit CpuMem(uint8_t *p) : p_(p) {}
  sf_status rd(uint64_t a, void *d, uint64_t n) override {
    if (a < kBase || a + n > kBase + kSize) return fail(SF_ERR_OUT_OF_RANGE, "address %#llx outside device memory", (unsigned long long)a);
    memcpy(d, p_ + (a - kBase), n);
    return SF_OK;
  }
  sf_status wr(uint64_t a, const void *s, uint64_t n) override {
    if (a < kBase || a + n > kBase + kSize) return fail(SF_ERR_OUT_OF_RANGE, "address %#llx outside device memory", (unsigned long long)a);
    memcpy(p_ + (a - kBase), s, n);
    return SF_OK;
  }
  uint8_t *p_;
};

struct CpuStats {
  uint64_t cmds = 0, elements = 0, macs = 0, busy_ns = 0;
};

class CpuBackend;

// Commands are executed by CpuBackend::advance(), i.e. only when the host lets the
// "device" progress (sf_queue_poll / sf_queue_wait / sf_buffer_sync), one per step.
class CpuQueue : public BackendQueue {
 public:
  CpuQueue(CpuBackend &be, CpuMem &m, CpuStats &st, uint32_t depth) : be_(be), mem_(m), st_(st), depth_(depth) {}
  ~CpuQueue() override;
  sf_status start(Command &c) override {
    started_.push_back(&c);
    return SF_OK;
  }
  sf_status poll(std::deque<Command *> &) override { return SF_OK; }   // completion is marked by execute_one
  void abandon() override { started_.clear(); }
  uint32_t capacity() const override { return depth_; }
  bool execute_one() {
    while (!started_.empty() && started_.front()->done) started_.pop_front();
    if (started_.empty()) return false;
    Command &c = *started_.front();
    started_.pop_front();
    uint64_t t0 = host_ns();
    sf_status s = c.op == SF_OP_RAW ? fail(SF_ERR_UNSUPPORTED, "raw device descriptors need a SilicaFlux device")
                                    : cpu_execute(c, mem_, kLanes, c.result);
    c.result.exec_target = SF_EXEC_CPU_REFERENCE;
    c.result.status = s;
    c.done = true;
    st_.cmds++;
    st_.elements += c.result.elements;
    st_.macs += c.result.macs;
    st_.busy_ns += host_ns() - t0;
    return true;
  }

 private:
  CpuBackend &be_;
  CpuMem &mem_;
  CpuStats &st_;
  uint32_t depth_;
  std::deque<Command *> started_;
};

class CpuBackend : public Backend {
 public:
  ~CpuBackend() override { close(); }
  sf_status open(uint32_t) override {
    void *p = mmap(nullptr, kSize, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED) return fail(SF_ERR_OUT_OF_MEMORY, "cannot reserve %llu bytes of host memory", (unsigned long long)kSize);
    base_ = static_cast<uint8_t *>(p);
    mem_ = std::make_unique<CpuMem>(base_);
    return SF_OK;
  }
  void close() override {
    if (base_) munmap(base_, kSize);
    base_ = nullptr;
  }
  void fill_info(sf_device_info &i) override {
    i.caps = SF_CAP_VECTOR_F32 | SF_CAP_VECTOR_I32 | SF_CAP_DOT_F32 | SF_CAP_GEMM_I8_I32 | SF_CAP_GEMM_I8_Q8 | SF_CAP_COPY;
    i.device_abi_version = 0;
    snprintf(i.hardware_id, sizeof i.hardware_id, "host CPU reference (not SilicaFlux hardware)");
    i.max_queue_depth = 1024;
    i.max_queues = 16;
    i.vector_lanes = kLanes;
    i.max_vector_elements = kSize / 16;
    i.gemm_max_m = 65535;
    i.gemm_max_n = 65535;
    i.gemm_max_k = 131071;
    i.default_timeout_ms = 60000;
  }
  std::vector<MemRegion> memory_regions() override { return {{kBase, kSize}}; }
  sf_status write(uint64_t a, const void *s, uint64_t n) override { return mem_->wr(a, s, n); }
  sf_status read(uint64_t a, void *d, uint64_t n) override { return mem_->rd(a, d, n); }
  sf_status zero(uint64_t a, uint64_t n) override {
    if (a < kBase || a + n > kBase + kSize) return fail(SF_ERR_OUT_OF_RANGE, "zero outside memory");
    memset(base_ + (a - kBase), 0, n);
    return SF_OK;
  }
  sf_status create_queue(uint32_t depth, std::unique_ptr<BackendQueue> *q) override {
    auto cq = std::make_unique<CpuQueue>(*this, *mem_, st_, depth);
    queues_.push_back(cq.get());
    *q = std::move(cq);
    return SF_OK;
  }
  void forget(CpuQueue *q) { queues_.erase(std::remove(queues_.begin(), queues_.end(), q), queues_.end()); }
  sf_status check(const Command &c) override {
    if (c.op == SF_OP_GEMM && (c.gemm.m > 65535 || c.gemm.n > 65535 || c.gemm.k > 131071))
      return fail(SF_ERR_UNSUPPORTED, "GEMM dimensions exceed the SilicaFlux contract (M,N <= 65535, K <= 131071)");
    if (c.op == SF_OP_RAW) return fail(SF_ERR_UNSUPPORTED, "raw device descriptors need a SilicaFlux device");
    return SF_OK;
  }
  void advance() override {   // one command, round-robin over the queues
    for (size_t k = 0; k < queues_.size(); k++) {
      CpuQueue *q = queues_[(rr_ + k) % queues_.size()];
      if (q->execute_one()) {
        rr_ = (rr_ + k + 1) % queues_.size();
        return;
      }
    }
  }
  uint64_t device_time_us() override { return host_ns() / 1000; }
  bool is_simulator() const override { return false; }
  sf_exec_target exec_target() const override { return SF_EXEC_CPU_REFERENCE; }
  sf_status reset(sf_reset_level) override { return SF_OK; }
  sf_status status(sf_device_status &s) override {
    s.state = SF_STATE_READY;
    snprintf(s.detail, sizeof s.detail, "CPU reference backend: no RAS hardware");
    return SF_OK;
  }
  sf_status read_counters(std::vector<sf_counter> &out) override {
    auto add = [&](const char *n, uint64_t v, uint32_t unit) {
      sf_counter c{};
      snprintf(c.name, sizeof c.name, "%s", n);
      c.value = v;
      c.unit = unit;
      c.source = SF_SRC_RUNTIME;
      out.push_back(c);
    };
    add("cpu.commands", st_.cmds, SF_UNIT_EVENTS);
    add("cpu.elements", st_.elements, SF_UNIT_OPS);
    add("cpu.macs", st_.macs, SF_UNIT_MACS);
    add("cpu.busy_ns", st_.busy_ns, SF_UNIT_NANOSECONDS);
    return SF_OK;
  }
  sf_status clear_counters() override {
    st_ = CpuStats{};
    return SF_OK;
  }
  sf_status perf_summary(sf_perf_summary &s) override {
    s.vector_elements = st_.elements;
    s.tensor_macs = st_.macs;
    return SF_OK;
  }

 private:
  uint8_t *base_ = nullptr;
  std::unique_ptr<CpuMem> mem_;
  CpuStats st_;
  std::vector<CpuQueue *> queues_;
  size_t rr_ = 0;
};

CpuQueue::~CpuQueue() { be_.forget(this); }

}  // namespace

std::unique_ptr<Backend> make_cpu_backend(const DeviceEntry &) { return std::make_unique<CpuBackend>(); }

}  // namespace sf
