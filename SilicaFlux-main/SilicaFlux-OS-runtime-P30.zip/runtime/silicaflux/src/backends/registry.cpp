// SilicaFlux.OS -- device discovery.
//
// Lists, in order: the CPU reference backend (always), each RTL simulator that
// was built into this library (identified as a simulator, never as hardware),
// and every PCIe function that matches a configured SilicaFlux HostLink ID.
// HostLink PCI vendor/device IDs are NOT assigned yet (P25 docs/02 section 1),
// so physical discovery only considers IDs given in SILICAFLUX_PCI_IDS
// ("vvvv:dddd[,...]") or a function named by SILICAFLUX_PCI_BDF; a match is
// confirmed by the BAR0 ID register ('SFHL') when it is opened.
#include <dirent.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>

#include "../core/internal.h"

namespace sf {

std::unique_ptr<Backend> make_cpu_backend(const DeviceEntry &);
#ifdef SF_HAVE_RTL_CC
std::unique_ptr<Backend> make_cc_backend(const DeviceEntry &);
std::string cc_firmware_path();
#endif
#ifdef SF_HAVE_RTL_HOSTLINK
std::unique_ptr<Backend> make_hostlink_sim_backend(const DeviceEntry &);
#endif
#ifdef SF_HAVE_VFIO
std::unique_ptr<Backend> make_hostlink_vfio_backend(const DeviceEntry &);
#endif

std::string build_backends() {
  std::string s = "cpu";
#ifdef SF_HAVE_RTL_CC
  s += ", rtl-cc";
#endif
#ifdef SF_HAVE_RTL_HOSTLINK
  s += ", rtl-hostlink";
#endif
#ifdef SF_HAVE_VFIO
  s += ", pcie-vfio";
#endif
  return s;
}

namespace {
[[maybe_unused]] std::string read_line(const std::string &path) {
  std::ifstream f(path);
  std::string s;
  std::getline(f, s);
  return s;
}

#ifdef SF_HAVE_VFIO
void scan_pci(std::vector<DeviceEntry> &out) {
  std::vector<std::pair<unsigned, unsigned>> ids;
  if (const char *e = getenv("SILICAFLUX_PCI_IDS")) {
    std::stringstream ss(e);
    std::string tok;
    while (std::getline(ss, tok, ',')) {
      unsigned v = 0, d = 0;
      if (sscanf(tok.c_str(), "%x:%x", &v, &d) == 2) ids.push_back({v, d});
    }
  }
  const char *want_bdf = getenv("SILICAFLUX_PCI_BDF");
  if (ids.empty() && !want_bdf) return;   // no ID assigned: nothing can be recognised
  DIR *dir = opendir("/sys/bus/pci/devices");
  if (!dir) return;
  while (dirent *de = readdir(dir)) {
    if (de->d_name[0] == '.') continue;
    std::string bdf = de->d_name, base = "/sys/bus/pci/devices/" + bdf;
    unsigned v = (unsigned)strtoul(read_line(base + "/vendor").c_str(), nullptr, 16);
    unsigned d = (unsigned)strtoul(read_line(base + "/device").c_str(), nullptr, 16);
    bool match = want_bdf && bdf == want_bdf;
    for (auto &p : ids)
      if (p.first == v && p.second == d) match = true;
    if (!match) continue;
    char link[256] = "";
    ssize_t n = readlink((base + "/driver").c_str(), link, sizeof link - 1);
    std::string drv = n > 0 ? std::string(link, (size_t)n) : "";
    drv = drv.substr(drv.find_last_of('/') + 1);
    DeviceEntry e;
    e.name = "pcie:" + bdf;
    e.kind = SF_DEVICE_HARDWARE;
    e.arg = bdf;
    e.make = make_hostlink_vfio_backend;
    char desc[160];
    if (drv == "vfio-pci") {
      snprintf(desc, sizeof desc, "SilicaFlux HostLink PCIe function %04x:%04x via VFIO (unverified until opened)", v, d);
      e.available = true;
    } else {
      snprintf(desc, sizeof desc, "PCIe %04x:%04x bound to '%s': bind it to vfio-pci to use it", v, d,
               drv.empty() ? "no driver" : drv.c_str());
      e.available = false;
    }
    e.description = desc;
    out.push_back(std::move(e));
  }
  closedir(dir);
}
#endif
}  // namespace

std::vector<DeviceEntry> discover_devices() {
  std::vector<DeviceEntry> v;
  {
    DeviceEntry e;
    e.name = "cpu";
    e.description = "CPU reference implementation of the SilicaFlux kernels (host CPU, not SilicaFlux hardware)";
    e.kind = SF_DEVICE_CPU_REFERENCE;
    e.static_caps = SF_CAP_VECTOR_F32 | SF_CAP_VECTOR_I32 | SF_CAP_DOT_F32 | SF_CAP_GEMM_I8_I32 | SF_CAP_GEMM_I8_Q8 |
                    SF_CAP_COPY;
    e.make = make_cpu_backend;
    v.push_back(std::move(e));
  }
#ifdef SF_HAVE_RTL_CC
  {
    DeviceEntry e;
    e.name = "rtl-cc";
    e.kind = SF_DEVICE_RTL_SIMULATOR;
    e.simulator = true;
    e.make = make_cc_backend;
    std::string fw = cc_firmware_path();
    if (access(fw.c_str(), R_OK) == 0) {
      e.description = "RTL simulation (Verilator) of SilicaFlux-HPC P21 ControlCore + M08 FP32 vector tile + "
                      "TC08 INT8 tensor unit";
    } else {
      e.available = false;
      e.description = "ControlCore firmware image not found: " + fw + " (set SILICAFLUX_CC_FIRMWARE)";
    }
    v.push_back(std::move(e));
  }
#endif
#ifdef SF_HAVE_RTL_HOSTLINK
  {
    DeviceEntry e;
    e.name = "rtl-hostlink";
    e.kind = SF_DEVICE_RTL_SIMULATOR;
    e.simulator = true;
    e.make = make_hostlink_sim_backend;
    e.description = "RTL simulation (Verilator) of SilicaFlux P25 HostLink PCIe front end + SilicaFlux-V tile, "
                    "with a transaction-level PCIe/IOMMU host model";
    v.push_back(std::move(e));
  }
#endif
#ifdef SF_HAVE_VFIO
  scan_pci(v);
#endif
  return v;
}

}  // namespace sf
