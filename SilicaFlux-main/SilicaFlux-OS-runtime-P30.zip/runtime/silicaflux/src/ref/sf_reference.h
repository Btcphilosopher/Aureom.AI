// SilicaFlux.OS -- reference implementations of every supported kernel.
//
// These define the exact results the SilicaFlux engines must produce:
//   vector  : HPC Module 08 tile KERNEL semantics (one rounding per element op,
//             fflags OR-ed over the command);
//   dot     : HPC Module 03 REDUCTION.md section 1 (per-beat pairwise tree over
//             `lanes` elements, then strictly sequential FP32 accumulation,
//             absent leaves skipped, never replaced by zero);
//   GEMM    : TENSORCORE 08 ABI v2 (exact int32; int8 = clamp(R_rm(acc*M/2^S)+zp)
//             with ReLU floor zp, SAT before ReLU).
// Used by the CPU reference backend, by CPU fallback, and by the tests.
#pragma once
#include <cstddef>
#include <cstdint>

namespace sf::ref {

enum class VecOp { kAdd, kMul, kFma };

// d[i] = op(a[i], b[i], c[i]) on FP32 bit patterns.  If a_scalar != nullptr,
// operand a is the broadcast value *a_scalar (axpy).  Returns OR of flags.
uint32_t vec_f32(VecOp op, uint32_t rm, size_t n, const uint32_t *a, const uint32_t *a_scalar, const uint32_t *b,
                 const uint32_t *c, uint32_t *d);
// d[i] = a[i] op b[i], INT32 wrapping (op = kAdd or kMul)
void vec_i32(VecOp op, size_t n, const int32_t *a, const int32_t *b, int32_t *d);
// dot product with the hardware's defined order; `init` = initial accumulator bits
uint32_t dot_f32(size_t n, const uint32_t *a, const uint32_t *b, uint32_t rm, unsigned lanes, uint32_t init,
                 uint32_t *flags);

// C[m][n] (int32) = sum_k A[m][k] * B[k][n]; strides in BYTES
void gemm_i8_i32(uint32_t M, uint32_t N, uint32_t K, const int8_t *A, size_t lda, const int8_t *B, size_t ldb,
                 int32_t *C, size_t ldc);
// R_rm(x * mult / 2^shift) exactly (TENSORCORE 05 contract)
int64_t rescale(int64_t x, int32_t mult, unsigned shift, uint32_t rm);
// one requantised element; *sat set if the pre-clamp value left [-128, 127]
int8_t requant(int32_t acc, int32_t mult, unsigned shift, int32_t zp, bool relu, uint32_t rm, bool *sat);
// int8-output GEMM; returns true if any element saturated
bool gemm_i8_q8(uint32_t M, uint32_t N, uint32_t K, const int8_t *A, size_t lda, const int8_t *B, size_t ldb,
                int8_t *C, size_t ldc, int32_t mult, unsigned shift, int32_t zp, bool relu, uint32_t rm);

}  // namespace sf::ref
