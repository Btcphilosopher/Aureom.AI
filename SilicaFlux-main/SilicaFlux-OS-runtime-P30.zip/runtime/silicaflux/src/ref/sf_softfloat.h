// SilicaFlux.OS -- independent FP32 reference arithmetic (integer-only soft-float).
//
// Semantics are those the SilicaFlux vector lanes document (HPC Module 01/02/03):
//   * IEEE 754 binary32, all five rounding modes (RNE, RTZ, RDN, RUP, RMM);
//   * full subnormal support (no flush-to-zero), tininess detected AFTER rounding;
//   * any NaN result is the canonical quiet NaN 0x7FC00000 (RISC-V);
//   * flags {NV, DZ, OF, UF, NX} as bits 4..0 (RISC-V fflags order);
//   * fma: one rounding; inf*0 raises NV even when the addend is a quiet NaN.
// It uses no host floating point, so it cannot inherit the host FPU's NaN or
// tininess conventions.  Cross-checked against the host FPU in tests/.
#pragma once
#include <cstdint>

namespace sf::ref {

enum : uint32_t { kRNE = 0, kRTZ = 1, kRDN = 2, kRUP = 3, kRMM = 4 };
enum : uint32_t { kNX = 1u << 0, kUF = 1u << 1, kOF = 1u << 2, kDZ = 1u << 3, kNV = 1u << 4 };
constexpr uint32_t kCanonicalNaN = 0x7FC00000u;

uint32_t f32_add(uint32_t a, uint32_t b, uint32_t rm, uint32_t *flags);
uint32_t f32_sub(uint32_t a, uint32_t b, uint32_t rm, uint32_t *flags);
uint32_t f32_mul(uint32_t a, uint32_t b, uint32_t rm, uint32_t *flags);
uint32_t f32_fma(uint32_t a, uint32_t b, uint32_t c, uint32_t rm, uint32_t *flags);   // a*b + c

bool f32_is_nan(uint32_t a);

}  // namespace sf::ref
