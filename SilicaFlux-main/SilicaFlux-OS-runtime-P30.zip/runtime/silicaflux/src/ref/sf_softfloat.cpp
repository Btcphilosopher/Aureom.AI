// SilicaFlux.OS -- independent FP32 reference arithmetic.  See sf_softfloat.h.
// Every finite operand is unpacked to an exact integer significand and a
// power-of-two exponent; sums are formed exactly in 128-bit integers (operands
// that fall entirely below the alignment window contribute a sticky bit only),
// and one function rounds and packs the exact result.
#include "sf_softfloat.h"

namespace sf::ref {
namespace {

using u128 = unsigned __int128;

enum Cls { kZero, kFinite, kInf, kNaN };
struct Unp {
  uint32_t sign;
  Cls cls;
  uint32_t sig;   // value = sig * 2^exp (finite)
  int32_t exp;
};

Unp unpack(uint32_t a) {
  Unp u;
  u.sign = a >> 31;
  uint32_t e = (a >> 23) & 0xFFu, f = a & 0x7FFFFFu;
  u.sig = 0;
  u.exp = 0;
  if (e == 0xFFu) {
    u.cls = f ? kNaN : kInf;
  } else if (e == 0) {
    u.cls = f ? kFinite : kZero;
    u.sig = f;
    u.exp = -149;
  } else {
    u.cls = kFinite;
    u.sig = f | 0x800000u;
    u.exp = (int32_t)e - 150;
  }
  return u;
}

bool is_snan(uint32_t a) { return ((a >> 23) & 0xFFu) == 0xFFu && (a & 0x7FFFFFu) && !(a & 0x400000u); }

int msb128(u128 x) {
  uint64_t hi = (uint64_t)(x >> 64), lo = (uint64_t)x;
  if (hi) return 64 + 63 - __builtin_clzll(hi);
  return 63 - __builtin_clzll(lo);
}

// Round sig*2^lsb to a multiple of 2^target (the kept integer is returned).
u128 round_to(uint32_t sign, u128 sig, int32_t lsb, int32_t target, uint32_t rm, bool *inexact) {
  int32_t s = target - lsb;
  if (s <= 0) {  // exact: only small left shifts can occur (target >= msb - 23)
    *inexact = false;
    return sig << (-s);
  }
  u128 kept, rem;
  int cmp;  // rem compared with half an ulp
  if (s >= 128) {
    kept = 0;
    rem = sig;
    if (s == 128) {
      u128 half = (u128)1 << 127;
      cmp = rem > half ? 1 : (rem == half ? 0 : -1);
    } else {
      cmp = -1;
    }
  } else {
    kept = sig >> s;
    rem = sig & (((u128)1 << s) - 1);
    u128 half = (u128)1 << (s - 1);
    cmp = rem > half ? 1 : (rem == half ? 0 : -1);
  }
  *inexact = rem != 0;
  bool inc = false;
  switch (rm) {
    case kRNE: inc = cmp > 0 || (cmp == 0 && (kept & 1)); break;
    case kRTZ: inc = false; break;
    case kRDN: inc = *inexact && sign; break;
    case kRUP: inc = *inexact && !sign; break;
    case kRMM: inc = cmp >= 0 && *inexact; break;
    default: inc = cmp > 0 || (cmp == 0 && (kept & 1)); break;
  }
  return kept + (inc ? 1 : 0);
}

uint32_t overflow_result(uint32_t sign, uint32_t rm) {
  const uint32_t inf = 0x7F800000u, max = 0x7F7FFFFFu;
  uint32_t mag;
  switch (rm) {
    case kRTZ: mag = max; break;
    case kRDN: mag = sign ? inf : max; break;
    case kRUP: mag = sign ? max : inf; break;
    default: mag = inf; break;  // RNE, RMM
  }
  return (sign << 31) | mag;
}

// value = (-1)^sign * sig * 2^lsb, sig != 0
uint32_t round_pack(uint32_t sign, int32_t lsb, u128 sig, uint32_t rm, uint32_t *fl) {
  int p = msb128(sig);
  int32_t E = lsb + p;  // exponent of the leading one
  bool inexact = false;
  if (E >= -126) {
    u128 kept = round_to(sign, sig, lsb, E - 23, rm, &inexact);
    if (kept == ((u128)1 << 24)) {  // carry out of the significand
      kept >>= 1;
      E++;
    }
    if (E > 127) {
      *fl |= kOF | kNX;
      return overflow_result(sign, rm);
    }
    if (inexact) *fl |= kNX;
    return (sign << 31) | ((uint32_t)(E + 127) << 23) | ((uint32_t)kept & 0x7FFFFFu);
  }
  // below the normal range: tininess is decided on the result rounded with an
  // unbounded exponent (RISC-V / SoftFloat "tininess after rounding")
  bool tiny = true;
  if (E == -127) {
    bool ix;
    u128 ku = round_to(sign, sig, lsb, E - 23, rm, &ix);
    if (ku == ((u128)1 << 24)) tiny = false;
  }
  u128 kept = round_to(sign, sig, lsb, -149, rm, &inexact);
  if (inexact) {
    *fl |= kNX;
    if (tiny) *fl |= kUF;
  }
  return (sign << 31) | (uint32_t)kept;  // kept == 2^23 encodes the minimum normal
}

u128 align(u128 sig, int32_t sh) {
  if (sh >= 0) return sig << sh;
  int32_t r = -sh;
  if (r >= 128) return sig != 0 ? 1 : 0;
  u128 lost = sig & (((u128)1 << r) - 1);
  return (sig >> r) | (lost != 0 ? 1 : 0);
}

// exact (sticky-correct) signed sum of two nonzero finite values
void exact_sum(uint32_t sx, u128 x, int32_t ex, uint32_t sy, u128 y, int32_t ey, uint32_t *sign, u128 *sum,
               int32_t *lsb) {
  int32_t mx = ex + msb128(x), my = ey + msb128(y);
  int32_t top = mx > my ? mx : my;
  int32_t L = top - 125;
  u128 X = align(x, ex - L), Y = align(y, ey - L);
  *lsb = L;
  if (sx == sy) {
    *sum = X + Y;
    *sign = sx;
  } else if (X >= Y) {
    *sum = X - Y;
    *sign = sx;
  } else {
    *sum = Y - X;
    *sign = sy;
  }
}

uint32_t zero_sum_sign(uint32_t sa, uint32_t sb, uint32_t rm) {
  if (sa == sb) return sa;
  return rm == kRDN ? 1u : 0u;
}

}  // namespace

bool f32_is_nan(uint32_t a) { return ((a >> 23) & 0xFFu) == 0xFFu && (a & 0x7FFFFFu); }

uint32_t f32_add(uint32_t a, uint32_t b, uint32_t rm, uint32_t *flags) {
  uint32_t fl = 0, r;
  Unp A = unpack(a), B = unpack(b);
  if (A.cls == kNaN || B.cls == kNaN) {
    if (is_snan(a) || is_snan(b)) fl |= kNV;
    r = kCanonicalNaN;
  } else if (A.cls == kInf && B.cls == kInf) {
    if (A.sign != B.sign) {
      fl |= kNV;
      r = kCanonicalNaN;
    } else {
      r = a;
    }
  } else if (A.cls == kInf) {
    r = a;
  } else if (B.cls == kInf) {
    r = b;
  } else if (A.cls == kZero && B.cls == kZero) {
    r = zero_sum_sign(A.sign, B.sign, rm) << 31;
  } else if (A.cls == kZero) {
    r = b;
  } else if (B.cls == kZero) {
    r = a;
  } else {
    uint32_t s;
    u128 S;
    int32_t L;
    exact_sum(A.sign, A.sig, A.exp, B.sign, B.sig, B.exp, &s, &S, &L);
    r = S == 0 ? ((rm == kRDN ? 1u : 0u) << 31) : round_pack(s, L, S, rm, &fl);
  }
  if (flags) *flags |= fl;
  return r;
}

uint32_t f32_sub(uint32_t a, uint32_t b, uint32_t rm, uint32_t *flags) {
  return f32_add(a, b ^ 0x80000000u, rm, flags);
}

uint32_t f32_mul(uint32_t a, uint32_t b, uint32_t rm, uint32_t *flags) {
  uint32_t fl = 0, r;
  Unp A = unpack(a), B = unpack(b);
  uint32_t s = A.sign ^ B.sign;
  if (A.cls == kNaN || B.cls == kNaN) {
    if (is_snan(a) || is_snan(b)) fl |= kNV;
    r = kCanonicalNaN;
  } else if ((A.cls == kInf && B.cls == kZero) || (A.cls == kZero && B.cls == kInf)) {
    fl |= kNV;
    r = kCanonicalNaN;
  } else if (A.cls == kInf || B.cls == kInf) {
    r = (s << 31) | 0x7F800000u;
  } else if (A.cls == kZero || B.cls == kZero) {
    r = s << 31;
  } else {
    r = round_pack(s, A.exp + B.exp, (u128)A.sig * B.sig, rm, &fl);
  }
  if (flags) *flags |= fl;
  return r;
}

uint32_t f32_fma(uint32_t a, uint32_t b, uint32_t c, uint32_t rm, uint32_t *flags) {
  uint32_t fl = 0, r;
  Unp A = unpack(a), B = unpack(b), C = unpack(c);
  uint32_t ps = A.sign ^ B.sign;
  bool inf_times_zero = (A.cls == kInf && B.cls == kZero) || (A.cls == kZero && B.cls == kInf);
  if (A.cls == kNaN || B.cls == kNaN || C.cls == kNaN) {
    if (is_snan(a) || is_snan(b) || is_snan(c) || inf_times_zero) fl |= kNV;
    r = kCanonicalNaN;
  } else if (inf_times_zero) {
    fl |= kNV;
    r = kCanonicalNaN;
  } else if (A.cls == kInf || B.cls == kInf) {
    if (C.cls == kInf && C.sign != ps) {
      fl |= kNV;
      r = kCanonicalNaN;
    } else {
      r = (ps << 31) | 0x7F800000u;
    }
  } else if (C.cls == kInf) {
    r = c;
  } else if (A.cls == kZero || B.cls == kZero) {  // exact zero product
    r = C.cls == kZero ? (zero_sum_sign(ps, C.sign, rm) << 31) : c;
  } else {
    u128 P = (u128)A.sig * B.sig;
    int32_t pe = A.exp + B.exp;
    if (C.cls == kZero) {
      r = round_pack(ps, pe, P, rm, &fl);
    } else {
      uint32_t s;
      u128 S;
      int32_t L;
      exact_sum(ps, P, pe, C.sign, C.sig, C.exp, &s, &S, &L);
      r = S == 0 ? ((rm == kRDN ? 1u : 0u) << 31) : round_pack(s, L, S, rm, &fl);
    }
  }
  if (flags) *flags |= fl;
  return r;
}

}  // namespace sf::ref
