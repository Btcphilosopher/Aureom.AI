// SilicaFlux.OS -- reference kernels.  See sf_reference.h for the contracts.
#include "sf_reference.h"

#include <vector>

#include "sf_softfloat.h"

namespace sf::ref {

uint32_t vec_f32(VecOp op, uint32_t rm, size_t n, const uint32_t *a, const uint32_t *a_scalar, const uint32_t *b,
                 const uint32_t *c, uint32_t *d) {
  uint32_t fl = 0;
  for (size_t i = 0; i < n; i++) {
    uint32_t x = a_scalar ? *a_scalar : a[i];
    switch (op) {
      case VecOp::kAdd: d[i] = f32_add(x, b[i], rm, &fl); break;
      case VecOp::kMul: d[i] = f32_mul(x, b[i], rm, &fl); break;
      case VecOp::kFma: d[i] = f32_fma(x, b[i], c[i], rm, &fl); break;
    }
  }
  return fl;
}

void vec_i32(VecOp op, size_t n, const int32_t *a, const int32_t *b, int32_t *d) {
  for (size_t i = 0; i < n; i++) {
    uint32_t x = (uint32_t)a[i], y = (uint32_t)b[i];
    d[i] = (int32_t)(op == VecOp::kMul ? x * y : x + y);  // two's complement wrap, low 32 bits
  }
}

uint32_t dot_f32(size_t n, const uint32_t *a, const uint32_t *b, uint32_t rm, unsigned lanes, uint32_t init,
                 uint32_t *flags) {
  uint32_t fl = 0, acc = init;
  if (lanes == 0) lanes = 1;
  std::vector<uint32_t> val(lanes);
  std::vector<bool> present(lanes);
  for (size_t g = 0; g * lanes < n; g++) {
    for (unsigned l = 0; l < lanes; l++) {
      size_t e = g * lanes + l;
      present[l] = e < n;
      if (present[l]) val[l] = f32_mul(a[e], b[e], rm, &fl);   // element result, rounded (unfused)
    }
    for (unsigned width = lanes; width > 1; width /= 2) {      // pairwise tree over lane index
      for (unsigned i = 0; i < width / 2; i++) {
        unsigned L = 2 * i, R = 2 * i + 1;
        if (present[L] && present[R]) {
          val[i] = f32_add(val[L], val[R], rm, &fl);
          present[i] = true;
        } else if (present[L]) {
          val[i] = val[L];
          present[i] = true;
        } else if (present[R]) {
          val[i] = val[R];
          present[i] = true;
        } else {
          present[i] = false;
        }
      }
    }
    if (present[0]) acc = f32_add(acc, val[0], rm, &fl);       // strictly in beat order
  }
  if (flags) *flags |= fl;
  return acc;
}

void gemm_i8_i32(uint32_t M, uint32_t N, uint32_t K, const int8_t *A, size_t lda, const int8_t *B, size_t ldb,
                 int32_t *C, size_t ldc) {
  for (uint32_t i = 0; i < M; i++)
    for (uint32_t j = 0; j < N; j++) {
      int64_t s = 0;
      for (uint32_t k = 0; k < K; k++) s += (int64_t)A[i * lda + k] * (int64_t)B[k * ldb + j];
      *(int32_t *)((uint8_t *)C + i * ldc + 4 * (size_t)j) = (int32_t)s;   // exact for K <= 131071
    }
}

int64_t rescale(int64_t x, int32_t mult, unsigned shift, uint32_t rm) {
  __int128 p = (__int128)x * mult;
  __int128 one = (__int128)1 << shift;
  // floor division by 2^shift
  __int128 q = p >= 0 ? p / one : -((-p + one - 1) / one);
  __int128 r = p - q * one;                                     // 0 <= r < 2^shift
  __int128 twice = 2 * r;
  switch (rm) {
    case kRTZ: if (p < 0 && r != 0) q += 1; break;
    case kRDN: break;
    case kRUP: if (r != 0) q += 1; break;
    case kRMM: if (twice > one || (twice == one && p > 0)) q += 1; break;
    case kRNE:
    default:
      if (twice > one || (twice == one && (q & 1))) q += 1;
      break;
  }
  return (int64_t)q;
}

int8_t requant(int32_t acc, int32_t mult, unsigned shift, int32_t zp, bool relu, uint32_t rm, bool *sat) {
  int64_t y = rescale(acc, mult, shift, rm) + zp;
  bool s = y < -128 || y > 127;
  if (sat && s) *sat = true;
  int64_t q = y < -128 ? -128 : (y > 127 ? 127 : y);
  if (relu && q < zp) q = zp;
  return (int8_t)q;
}

bool gemm_i8_q8(uint32_t M, uint32_t N, uint32_t K, const int8_t *A, size_t lda, const int8_t *B, size_t ldb,
                int8_t *C, size_t ldc, int32_t mult, unsigned shift, int32_t zp, bool relu, uint32_t rm) {
  bool sat = false;
  for (uint32_t i = 0; i < M; i++)
    for (uint32_t j = 0; j < N; j++) {
      int64_t s = 0;
      for (uint32_t k = 0; k < K; k++) s += (int64_t)A[i * lda + k] * (int64_t)B[k * ldb + j];
      C[i * ldc + j] = requant((int32_t)s, mult, shift, zp, relu, rm, &sat);
    }
  return sat;
}

}  // namespace sf::ref
