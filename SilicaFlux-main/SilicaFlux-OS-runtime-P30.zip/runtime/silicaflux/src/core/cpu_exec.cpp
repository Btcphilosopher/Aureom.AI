// SilicaFlux.OS -- CPU execution of lowered commands with the reference kernels.
// Operands are read from / written to device memory through MemAccess, so the
// same code serves the CPU reference backend (host memory) and CPU fallback on
// a real or simulated device (blocking backend transfers).
#include <algorithm>
#include <vector>

#include "../ref/sf_reference.h"
#include "internal.h"

namespace sf {

namespace {
constexpr uint64_t kChunk = 1u << 16;   // elements per pass (bounded host memory)

sf_status rd(MemAccess &m, uint64_t a, std::vector<uint32_t> &v, uint64_t n) {
  v.resize(n);
  return m.rd(a, v.data(), 4 * n);
}
}  // namespace

sf_status cpu_execute(const Command &c, MemAccess &mem, unsigned lanes, sf_cmd_result &r) {
  r.device_commands = 0;
  switch (c.op) {
    case SF_OP_VECTOR_ADD:
    case SF_OP_VECTOR_MUL:
    case SF_OP_VECTOR_FMA:
    case SF_OP_VECTOR_AXPY: {
      const VecArgs &v = c.vec;
      std::vector<uint32_t> A, B, C, D;
      uint32_t fl = 0;
      for (uint64_t off = 0; off < v.n; off += kChunk) {
        uint64_t n = std::min<uint64_t>(kChunk, v.n - off);
        sf_status s;
        if (!v.axpy && (s = rd(mem, v.a + 4 * off, A, n))) return s;
        if ((s = rd(mem, v.b + 4 * off, B, n))) return s;
        if ((c.op == SF_OP_VECTOR_FMA || v.axpy) && (s = rd(mem, v.c + 4 * off, C, n))) return s;
        D.resize(n);
        if (v.dtype == SF_DTYPE_I32) {
          ref::vec_i32(c.op == SF_OP_VECTOR_MUL ? ref::VecOp::kMul : ref::VecOp::kAdd, n,
                       reinterpret_cast<const int32_t *>(A.data()), reinterpret_cast<const int32_t *>(B.data()),
                       reinterpret_cast<int32_t *>(D.data()));
        } else {
          ref::VecOp op = c.op == SF_OP_VECTOR_ADD ? ref::VecOp::kAdd
                          : c.op == SF_OP_VECTOR_MUL ? ref::VecOp::kMul : ref::VecOp::kFma;
          fl |= ref::vec_f32(op, v.rm, n, A.data(), v.axpy ? &v.alpha_bits : nullptr, B.data(), C.data(), D.data());
        }
        if ((s = mem.wr(v.d + 4 * off, D.data(), 4 * n))) return s;
      }
      r.elements = v.n;
      if (v.dtype == SF_DTYPE_F32) {
        r.fp_flags = fl;
        r.flags |= SF_RESULT_FP_FLAGS;
      }
      return SF_OK;
    }
    case SF_OP_VECTOR_DOT: {
      const VecArgs &v = c.vec;
      // the defined order is per beat of `lanes` elements with sequential accumulation across
      // beats, so chunking at beat boundaries and carrying the accumulator is exact
      uint64_t chunk = kChunk - kChunk % lanes;
      std::vector<uint32_t> A, B;
      uint32_t acc = 0, fl = 0;
      for (uint64_t off = 0; off < v.n; off += chunk) {
        uint64_t n = std::min<uint64_t>(chunk, v.n - off);
        sf_status s;
        if ((s = rd(mem, v.a + 4 * off, A, n)) || (s = rd(mem, v.b + 4 * off, B, n))) return s;
        acc = ref::dot_f32(n, A.data(), B.data(), v.rm, lanes, acc, &fl);
      }
      if (sf_status s = mem.wr(v.d, &acc, 4)) return s;
      r.scalar_bits = acc;
      r.fp_flags = fl;
      r.flags |= SF_RESULT_FP_FLAGS;
      r.elements = v.n;
      return SF_OK;
    }
    case SF_OP_GEMM: {
      const GemmArgs &g = c.gemm;
      uint64_t fa = (uint64_t)(g.m - 1) * g.lda + g.k, fb = (uint64_t)(g.k - 1) * g.ldb + g.n;
      uint32_t es = g.out_i8 ? 1 : 4;
      uint64_t fc = (uint64_t)(g.m - 1) * g.ldc + (uint64_t)g.n * es;
      std::vector<int8_t> A(fa), B(fb);
      std::vector<uint8_t> C(fc);
      sf_status s;
      if ((s = mem.rd(g.a, A.data(), fa)) || (s = mem.rd(g.b, B.data(), fb))) return s;
      if ((s = mem.rd(g.c, C.data(), fc))) return s;   // bytes between rows are preserved
      if (g.out_i8) {
        bool sat = ref::gemm_i8_q8(g.m, g.n, g.k, A.data(), g.lda, B.data(), g.ldb, reinterpret_cast<int8_t *>(C.data()),
                                   g.ldc, g.q_mult, g.q_shift, g.q_zp, g.relu, g.rm);
        if (sat) r.flags |= SF_RESULT_SATURATED;
      } else {
        ref::gemm_i8_i32(g.m, g.n, g.k, A.data(), g.lda, B.data(), g.ldb, reinterpret_cast<int32_t *>(C.data()), g.ldc);
      }
      if ((s = mem.wr(g.c, C.data(), fc))) return s;
      r.elements = (uint64_t)g.m * g.n;
      r.macs = (uint64_t)g.m * g.n * g.k;
      return SF_OK;
    }
    case SF_OP_COPY: {
      std::vector<uint8_t> buf;
      for (uint64_t off = 0; off < c.copy.size; off += 4 * kChunk) {
        uint64_t n = std::min<uint64_t>(4 * kChunk, c.copy.size - off);
        buf.resize(n);
        sf_status s;
        if ((s = mem.rd(c.copy.src + off, buf.data(), n)) || (s = mem.wr(c.copy.dst + off, buf.data(), n))) return s;
      }
      r.elements = c.copy.size / 4;
      return SF_OK;
    }
    default:
      return fail(SF_ERR_UNSUPPORTED, "operation %d cannot run on the CPU reference", (int)c.op);
  }
}

}  // namespace sf
