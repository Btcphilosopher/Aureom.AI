// SilicaFlux.OS -- runtime internals: commands, backend contract, objects.
//
// Layering (docs/02_ARCHITECTURE.md):
//   C API (c_api.cpp) -> compute API / kernel lowering (kernels.cpp)
//   -> command & memory manager (runtime.cpp: devices, buffers, queues, allocator)
//   -> backend (Backend / BackendQueue below) -> transport (simulator harness, VFIO, CPU)
#pragma once
#include <atomic>
#include <chrono>
#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "silicaflux/silicaflux.h"

namespace sf {

// ------------------------------------------------------------------ errors
// Records a thread-local detail message and returns `s` (for `return fail(...)`).
sf_status fail(sf_status s, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void clear_detail();
uint64_t host_ns();   // CLOCK_MONOTONIC

// ------------------------------------------------------------------ device memory allocator
struct MemRegion {
  uint64_t base, size;
};
class Allocator {
 public:
  void init(const std::vector<MemRegion> &regions, uint64_t align);
  bool alloc(uint64_t size, uint64_t *addr);   // first fit, aligned
  void free(uint64_t addr);
  uint64_t total() const { return total_; }
  uint64_t used() const { return used_; }
  uint64_t align() const { return align_; }

 private:
  std::map<uint64_t, uint64_t> free_;   // base -> size (coalesced)
  std::map<uint64_t, uint64_t> live_;   // base -> size
  uint64_t align_ = 64, total_ = 0, used_ = 0;
};

// ------------------------------------------------------------------ commands
enum class Exec { kBackend, kHostFallback, kMarker };

struct VecArgs {
  uint32_t dtype = SF_DTYPE_F32, rm = 0;
  uint64_t n = 0, a = 0, b = 0, c = 0, d = 0;   // device addresses
  bool axpy = false;
  uint32_t alpha_bits = 0;
};
struct GemmArgs {
  uint32_t m = 0, n = 0, k = 0, lda = 0, ldb = 0, ldc = 0;   // strides in bytes, normalised
  bool out_i8 = false, relu = false;
  int32_t q_mult = 0, q_zp = 0;
  uint32_t q_shift = 0, rm = 0;
  uint64_t a = 0, b = 0, c = 0;
};
struct CopyArgs {
  uint64_t src = 0, dst = 0, size = 0;
};
struct RawArgs {
  uint32_t engine = 0;
  std::vector<uint32_t> words;
};

struct BufferObj;
struct Command {
  sf_cmd_t id = 0;
  sf_op op = SF_OP_NOP;
  Exec exec = Exec::kBackend;
  VecArgs vec;
  GemmArgs gemm;
  CopyArgs copy;
  RawArgs raw;
  // buffers kept alive (and owned by the device) until retirement
  std::vector<std::shared_ptr<BufferObj>> reads, writes;
  // state
  bool started = false, done = false;
  sf_cmd_result result{};
  // backend scratch
  uint64_t sim_submit_cycle = 0;
  uint32_t backend_tag = 0;
  std::shared_ptr<void> backend_state;
};

// ------------------------------------------------------------------ backend contract
class BackendQueue {
 public:
  virtual ~BackendQueue() = default;
  // Start a command (it is the next in queue order).  Must not block on completion.
  // Returns SF_ERR_QUEUE_FULL if the backend cannot accept it now (it will be retried).
  virtual sf_status start(Command &c) = 0;
  // Mark completed commands (c.done = true, c.result filled).  `started` lists the
  // started-but-not-done commands in order.  Must not block longer than a slice.
  virtual sf_status poll(std::deque<Command *> &started) = 0;
  // Device was reset: drop all device-side state without talking to the device.
  virtual void abandon() = 0;
  virtual uint32_t capacity() const = 0;
};

class Backend {
 public:
  virtual ~Backend() = default;
  virtual sf_status open(uint32_t flags) = 0;     // boot / probe / handshake
  virtual void close() = 0;
  virtual void fill_info(sf_device_info &info) = 0;
  virtual std::vector<MemRegion> memory_regions() = 0;
  virtual uint32_t min_alignment() const { return 64; }
  // blocking transfers (bytes counted by the runtime)
  virtual sf_status write(uint64_t addr, const void *src, uint64_t n) = 0;
  virtual sf_status read(uint64_t addr, void *dst, uint64_t n) = 0;
  virtual sf_status zero(uint64_t addr, uint64_t n);
  // queues
  virtual sf_status create_queue(uint32_t depth, std::unique_ptr<BackendQueue> *q) = 0;
  // Validate a lowered command against device limits (SF_ERR_UNSUPPORTED etc.).
  // Returns SF_ERR_UNSUPPORTED for ops the device lacks: the runtime may then fall back.
  virtual sf_status check(const Command &c) = 0;
  // Advance device time by one bounded slice (simulators: clock cycles).
  virtual void advance() = 0;
  // Device time in microseconds (wall clock for real devices, simulated for simulators).
  virtual uint64_t device_time_us() = 0;
  virtual bool is_simulator() const = 0;
  virtual sf_exec_target exec_target() const = 0;
  // management
  virtual sf_status reset(sf_reset_level level) = 0;
  virtual sf_status status(sf_device_status &st) = 0;
  virtual sf_status read_counters(std::vector<sf_counter> &out) = 0;
  virtual sf_status clear_counters() = 0;
  virtual sf_status perf_summary(sf_perf_summary &s) = 0;
  virtual sf_status selftest(uint32_t mask, sf_selftest_result &r);
  virtual std::string take_console() { return {}; }
  virtual sf_status inject(sf_inject_kind kind, uint64_t addr, uint64_t size);
};

// factories / discovery (backends/registry.cpp)
struct DeviceEntry {
  std::string name, description;
  sf_device_kind kind;
  bool simulator = false, available = true;
  uint32_t static_caps = 0;
  std::unique_ptr<Backend> (*make)(const DeviceEntry &) = nullptr;
  std::string arg;   // e.g. PCI BDF
};
std::vector<DeviceEntry> discover_devices();
std::string build_backends();

// ------------------------------------------------------------------ objects
struct DeviceObj;

struct BufferObj {
  std::weak_ptr<DeviceObj> dev;
  std::shared_ptr<BufferObj> parent;    // views keep the root allocation alive
  uint64_t addr = 0, size = 0;
  uint32_t flags = 0;
  bool is_view = false;
  // ownership tracking lives on the root allocation
  std::atomic<uint32_t> pending_reads{0}, pending_writes{0};
  BufferObj *root() { return parent ? parent->root() : this; }
  ~BufferObj();
};

struct QueueObj {
  std::weak_ptr<DeviceObj> dev;
  uint32_t depth = 0;
  sf_cmd_t next_id = 1;
  std::deque<std::unique_ptr<Command>> cmds;     // submitted, not retired (order)
  std::unique_ptr<BackendQueue> bq;
  std::map<sf_cmd_t, sf_cmd_result> results;     // retired results (bounded)
  sf_cmd_t last_retired = 0;
  bool destroyed = false;
};

struct TraceRec {
  uint64_t queue;
  sf_cmd_t id;
  sf_cmd_result r;
};

struct DeviceObj {
  std::recursive_mutex mu;
  DeviceEntry entry;
  std::unique_ptr<Backend> be;
  uint32_t open_flags = 0;
  sf_device_info info{};
  Allocator alloc;
  bool lost = false, closed = false;
  sf_status last_error = SF_OK;
  std::vector<uint64_t> queues;    // queue handles
  std::vector<uint64_t> buffers;   // buffer handles
  // runtime-side statistics (host clock domain)
  uint64_t bytes_h2d = 0, bytes_d2h = 0, transfer_ns = 0;
  uint32_t completed = 0, failed = 0, resets = 0;
  // tracing
  bool tracing = false;
  std::string trace_path;
  uint64_t trace_t0_ns = 0;
  std::vector<TraceRec> trace;
};

// global interrupt flag (sf_interrupt)
extern std::atomic<bool> g_interrupt;

// helpers used by kernels.cpp
sf_status submit_command(uint64_t qh, std::unique_ptr<Command> cmd, sf_cmd_t *out);
struct BufRef {
  std::shared_ptr<BufferObj> b;
  std::shared_ptr<DeviceObj> d;
};
sf_status get_buffer(sf_buffer_t h, BufRef *out);
sf_status get_queue_device(sf_queue_t q, std::shared_ptr<DeviceObj> *dev);

// CPU execution of a lowered command against a byte-addressable view of device memory
// (used by the CPU backend and by CPU fallback).
struct MemAccess {
  virtual ~MemAccess() = default;
  virtual sf_status rd(uint64_t addr, void *dst, uint64_t n) = 0;
  virtual sf_status wr(uint64_t addr, const void *src, uint64_t n) = 0;
};
sf_status cpu_execute(const Command &c, MemAccess &mem, unsigned lanes, sf_cmd_result &r);

// profiling (profile.cpp)
sf_status write_trace(DeviceObj &d);

}  // namespace sf
