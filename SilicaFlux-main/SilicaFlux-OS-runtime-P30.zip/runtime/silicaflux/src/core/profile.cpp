// SilicaFlux.OS -- performance counters and machine-readable traces.
//
// Clock domains are never mixed: host timestamps are CLOCK_MONOTONIC
// nanoseconds; device values are device clock cycles exactly as the engines /
// firmware report them.  Each trace field names its domain (docs/06_PROFILING.md).
#include <cstdio>
#include <cstring>

#include "internal.h"

namespace sf {
std::shared_ptr<DeviceObj> lookup_device(sf_device_t h);
void pump_device(DeviceObj &d);

namespace {
const char *unit_name(uint32_t u) {
  switch (u) {
    case SF_UNIT_CYCLES: return "device_cycles";
    case SF_UNIT_EVENTS: return "events";
    case SF_UNIT_BYTES: return "bytes";
    case SF_UNIT_OPS: return "ops";
    case SF_UNIT_MACS: return "macs";
    case SF_UNIT_NANOSECONDS: return "host_ns";
  }
  return "?";
}
const char *source_name(uint32_t s) {
  switch (s) {
    case SF_SRC_HARDWARE: return "hardware_counter";
    case SF_SRC_FIRMWARE: return "firmware";
    case SF_SRC_SIMULATOR: return "simulator";
    case SF_SRC_RUNTIME: return "runtime";
  }
  return "?";
}
const char *target_name(uint32_t t) {
  switch (t) {
    case SF_EXEC_HARDWARE: return "hardware";
    case SF_EXEC_RTL_SIMULATION: return "rtl_simulation";
    case SF_EXEC_CPU_REFERENCE: return "cpu_reference";
    case SF_EXEC_CPU_FALLBACK: return "cpu_fallback";
  }
  return "none";
}
const char *op_str(uint32_t op) {
  static const char *n[] = {"?", "vector_add", "vector_mul", "vector_fma", "vector_axpy", "vector_dot",
                            "tensor_gemm", "buffer_copy", "marker", "raw"};
  return op < sizeof n / sizeof n[0] ? n[op] : "?";
}

void runtime_counters(DeviceObj &d, std::vector<sf_counter> &out) {
  auto add = [&](const char *n, uint64_t v, uint32_t unit) {
    sf_counter c{};
    snprintf(c.name, sizeof c.name, "%s", n);
    c.value = v;
    c.unit = unit;
    c.source = SF_SRC_RUNTIME;
    out.push_back(c);
  };
  add("host.bytes_h2d", d.bytes_h2d, SF_UNIT_BYTES);
  add("host.bytes_d2h", d.bytes_d2h, SF_UNIT_BYTES);
  add("host.transfer_ns", d.transfer_ns, SF_UNIT_NANOSECONDS);
  add("host.commands_completed", d.completed, SF_UNIT_EVENTS);
  add("host.commands_failed", d.failed, SF_UNIT_EVENTS);
}
}  // namespace

sf_status write_trace(DeviceObj &d) {
  FILE *f = fopen(d.trace_path.c_str(), "w");
  if (!f) return fail(SF_ERR_INVALID_ARGUMENT, "cannot write %s", d.trace_path.c_str());
  fprintf(f, "{\n  \"schema\": \"silicaflux-trace/1\",\n");
  fprintf(f, "  \"device\": {\"name\": \"%s\", \"kind\": %u, \"is_simulator\": %u, \"hardware_id\": \"%s\", "
             "\"nominal_clock_mhz\": %u, \"firmware_version\": %u, \"device_abi_version\": %u},\n",
          d.info.name, d.info.kind, d.info.is_simulator, d.info.hardware_id, d.info.nominal_clock_mhz,
          d.info.firmware_version, d.info.device_abi_version);
  fprintf(f, "  \"clock_domains\": {\n"
             "    \"host_ns\": \"host CLOCK_MONOTONIC nanoseconds relative to trace start\",\n"
             "    \"device_cycles\": \"device clock cycles as reported by engine records / firmware; never converted\"\n"
             "  },\n  \"commands\": [\n");
  for (size_t i = 0; i < d.trace.size(); i++) {
    const TraceRec &t = d.trace[i];
    const sf_cmd_result &r = t.r;
    auto rel = [&](uint64_t ns) -> long long { return ns ? (long long)(ns - d.trace_t0_ns) : -1; };
    fprintf(f,
            "    {\"queue\": \"%#llx\", \"id\": %llu, \"op\": \"%s\", \"status\": \"%s\", \"exec_target\": \"%s\", "
            "\"host_submit_ns\": %lld, \"host_complete_ns\": %lld, \"engine_cycles\": %llu, "
            "\"device_start_cycle\": %llu, \"device_end_cycle\": %llu, \"device_queue_cycles\": %llu, "
            "\"device_status\": %u, \"device_error\": %u, \"fp_flags\": %u, \"result_flags\": %u, \"elements\": %llu, "
            "\"macs\": %llu, \"device_commands\": %u}%s\n",
            (unsigned long long)t.queue, (unsigned long long)t.id, op_str(r.op), sf_status_string(r.status),
            target_name(r.exec_target), rel(r.host_submit_ns), rel(r.host_complete_ns),
            (unsigned long long)r.engine_cycles, (unsigned long long)r.device_start_cycle,
            (unsigned long long)r.device_end_cycle, (unsigned long long)r.device_queue_cycles, r.device_status,
            r.device_error, r.fp_flags, r.flags, (unsigned long long)r.elements, (unsigned long long)r.macs,
            r.device_commands, i + 1 < d.trace.size() ? "," : "");
  }
  fprintf(f, "  ],\n  \"counters_at_stop\": [\n");
  std::vector<sf_counter> cs;
  if (!d.lost) d.be->read_counters(cs);
  runtime_counters(d, cs);
  for (size_t i = 0; i < cs.size(); i++)
    fprintf(f, "    {\"name\": \"%s\", \"value\": %llu, \"unit\": \"%s\", \"source\": \"%s\"}%s\n", cs[i].name,
            (unsigned long long)cs[i].value, unit_name(cs[i].unit), source_name(cs[i].source),
            i + 1 < cs.size() ? "," : "");
  fprintf(f, "  ]\n}\n");
  fclose(f);
  d.trace.clear();
  return SF_OK;
}

}  // namespace sf

using namespace sf;

extern "C" {

sf_status sfi_device_read_counters(sf_device_t dh, sf_counter *counters, uint32_t capacity, uint32_t *count) {
  auto d = lookup_device(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  pump_device(*d);
  std::vector<sf_counter> cs;
  if (sf_status s = d->be->read_counters(cs)) return s;
  runtime_counters(*d, cs);
  if (count) *count = (uint32_t)cs.size();
  if (counters)
    for (uint32_t i = 0; i < capacity && i < cs.size(); i++) counters[i] = cs[i];
  return SF_OK;
}

sf_status sfi_device_clear_counters(sf_device_t dh) {
  auto d = lookup_device(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  d->bytes_h2d = d->bytes_d2h = d->transfer_ns = 0;
  return d->be->clear_counters();
}

sf_status sfi_device_perf_summary(sf_device_t dh, sf_perf_summary *out) {
  if (!out) return fail(SF_ERR_INVALID_ARGUMENT, "summary is NULL");
  auto d = lookup_device(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  pump_device(*d);
  sf_perf_summary s;
  memset(&s, 0xFF, sizeof s);
  s.struct_size = sizeof s;
  s.reserved = 0;
  if (sf_status rc = d->be->perf_summary(s)) return rc;
  s.host_bytes_h2d = d->bytes_h2d;
  s.host_bytes_d2h = d->bytes_d2h;
  s.host_transfer_ns = d->transfer_ns;
  uint32_t n = out->struct_size && out->struct_size < sizeof s ? out->struct_size : sizeof s;
  memcpy(out, &s, n);
  out->struct_size = n;
  return SF_OK;
}

sf_status sfi_trace_start(sf_device_t dh, const char *json_path) {
  if (!json_path || !*json_path) return fail(SF_ERR_INVALID_ARGUMENT, "json_path is empty");
  auto d = lookup_device(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  FILE *f = fopen(json_path, "w");
  if (!f) return fail(SF_ERR_INVALID_ARGUMENT, "cannot open %s for writing", json_path);
  fclose(f);
  d->trace_path = json_path;
  d->trace.clear();
  d->trace_t0_ns = host_ns();
  d->tracing = true;
  return SF_OK;
}

sf_status sfi_trace_stop(sf_device_t dh) {
  auto d = lookup_device(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (!d->tracing) return fail(SF_ERR_INVALID_ARGUMENT, "tracing is not active");
  pump_device(*d);
  d->tracing = false;
  return write_trace(*d);
}

}  // extern "C"
