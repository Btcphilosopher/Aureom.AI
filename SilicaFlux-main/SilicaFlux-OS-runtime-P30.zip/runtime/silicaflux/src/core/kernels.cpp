// SilicaFlux.OS -- compute API: argument validation and lowering to commands.
//
// Every call is validated here (handles, device ownership, access flags,
// sizes, precisions) before any backend sees it.  The backend then checks the
// device's own limits (Backend::check).  An operation the device lacks is
// rejected with SF_ERR_UNSUPPORTED -- unless the device was opened with
// SF_OPEN_ALLOW_CPU_FALLBACK, in which case the runtime runs it on the CPU
// reference, in queue order, and marks the result SF_EXEC_CPU_FALLBACK.
#include <cstring>

#include "internal.h"

namespace sf {
std::shared_ptr<DeviceObj> lookup_device(sf_device_t h);
}

using namespace sf;

namespace {

uint32_t caps_needed(const Command &c) {
  switch (c.op) {
    case SF_OP_VECTOR_ADD:
    case SF_OP_VECTOR_MUL: return c.vec.dtype == SF_DTYPE_I32 ? SF_CAP_VECTOR_I32 : SF_CAP_VECTOR_F32;
    case SF_OP_VECTOR_FMA:
    case SF_OP_VECTOR_AXPY: return SF_CAP_VECTOR_F32;
    case SF_OP_VECTOR_DOT: return SF_CAP_DOT_F32;
    case SF_OP_GEMM: return c.gemm.out_i8 ? SF_CAP_GEMM_I8_Q8 : SF_CAP_GEMM_I8_I32;
    case SF_OP_COPY: return SF_CAP_COPY;
    default: return 0;
  }
}

const char *op_name(sf_op op) {
  switch (op) {
    case SF_OP_VECTOR_ADD: return "vector_add";
    case SF_OP_VECTOR_MUL: return "vector_mul";
    case SF_OP_VECTOR_FMA: return "vector_fma";
    case SF_OP_VECTOR_AXPY: return "vector_axpy";
    case SF_OP_VECTOR_DOT: return "vector_dot";
    case SF_OP_GEMM: return "tensor_gemm";
    case SF_OP_COPY: return "buffer_copy";
    case SF_OP_NOP: return "marker";
    case SF_OP_RAW: return "raw";
  }
  return "?";
}

struct Lowering {
  sf_queue_t q;
  std::shared_ptr<DeviceObj> dev;
  std::unique_ptr<Command> cmd = std::make_unique<Command>();
};

sf_status begin(sf_queue_t q, sf_op op, Lowering &L) {
  L.q = q;
  if (sf_status s = get_queue_device(q, &L.dev)) return s;
  L.cmd->op = op;
  return SF_OK;
}

// operand: valid handle, same device, access flag, enough bytes
sf_status operand(Lowering &L, sf_buffer_t h, uint64_t bytes, bool write, const char *what, uint64_t *addr) {
  BufRef br;
  if (sf_status s = get_buffer(h, &br)) return fail(s, "%s: %s", what, sf_last_error_detail());
  if (br.d != L.dev) return fail(SF_ERR_INVALID_BUFFER, "%s belongs to another device", what);
  uint32_t need = write ? SF_MEM_DEVICE_WRITE : SF_MEM_DEVICE_READ;
  if (!(br.b->flags & need))
    return fail(SF_ERR_PERMISSION, "%s lacks %s", what, write ? "SF_MEM_DEVICE_WRITE" : "SF_MEM_DEVICE_READ");
  if (bytes > br.b->size)
    return fail(SF_ERR_OUT_OF_RANGE, "%s holds %llu bytes, the operation needs %llu", what,
                (unsigned long long)br.b->size, (unsigned long long)bytes);
  (write ? L.cmd->writes : L.cmd->reads).push_back(br.b);
  *addr = br.b->addr;
  return SF_OK;
}

sf_status finish(Lowering &L, sf_cmd_t *out) {
  Command &c = *L.cmd;
  {
    std::lock_guard<std::recursive_mutex> g(L.dev->mu);
    uint32_t need = caps_needed(c);
    sf_status s = SF_OK;
    if (need && !(L.dev->info.caps & need))
      s = fail(SF_ERR_UNSUPPORTED, "%s: %s does not support this operation/precision", op_name(c.op),
               L.dev->info.name);
    else if (c.op != SF_OP_NOP)
      s = L.dev->be->check(c);
    if (s == SF_ERR_UNSUPPORTED && c.op != SF_OP_RAW && (L.dev->open_flags & SF_OPEN_ALLOW_CPU_FALLBACK)) {
      c.exec = Exec::kHostFallback;    // explicit, opt-in, and reported as SF_EXEC_CPU_FALLBACK
      s = SF_OK;
    }
    if (s != SF_OK) return s;
  }
  return submit_command(L.q, std::move(L.cmd), out);
}

uint32_t rounding(const sf_vector_opts *o) {
  if (!o) return SF_ROUND_NEAREST_EVEN;
  sf_vector_opts v{};
  uint32_t n = o->struct_size && o->struct_size < sizeof v ? o->struct_size : sizeof v;
  memcpy(&v, o, n);
  return v.rounding;
}

sf_status vector_common(sf_queue_t q, sf_op op, sf_buffer_t a, sf_buffer_t b, sf_buffer_t c, sf_buffer_t d,
                        uint64_t n, sf_dtype dt, const sf_vector_opts *opts, bool axpy, float alpha,
                        sf_cmd_t *out) {
  if (out) *out = 0;
  if (n == 0) return fail(SF_ERR_INVALID_ARGUMENT, "n is 0");
  if (dt != SF_DTYPE_F32 && dt != SF_DTYPE_I32)
    return fail(SF_ERR_UNSUPPORTED, "vector operations support F32 and I32 only (dtype %d)", (int)dt);
  if (dt == SF_DTYPE_I32 && (op == SF_OP_VECTOR_FMA || op == SF_OP_VECTOR_AXPY))
    return fail(SF_ERR_UNSUPPORTED, "fma/axpy are FP32 operations");
  uint32_t rm = rounding(opts);
  if (rm > SF_ROUND_NEAREST_MAX) return fail(SF_ERR_INVALID_ARGUMENT, "rounding mode %u", rm);
  if (n > (UINT64_MAX / 4)) return fail(SF_ERR_INVALID_ARGUMENT, "n too large");
  Lowering L;
  if (sf_status s = begin(q, op, L)) return s;
  VecArgs &v = L.cmd->vec;
  v.dtype = dt;
  v.rm = rm;
  v.n = n;
  v.axpy = axpy;
  memcpy(&v.alpha_bits, &alpha, 4);
  uint64_t bytes = 4 * n;
  if (!axpy)
    if (sf_status s = operand(L, a, bytes, false, "a", &v.a)) return s;
  if (sf_status s = operand(L, b, bytes, false, axpy ? "x" : "b", &v.b)) return s;
  if (op == SF_OP_VECTOR_FMA || axpy)
    if (sf_status s = operand(L, c, bytes, false, axpy ? "y" : "c", &v.c)) return s;
  if (sf_status s = operand(L, d, bytes, true, "d", &v.d)) return s;
  // elementwise semantics: d may equal a source exactly (in place) but must not partially overlap one
  auto partial = [&](uint64_t src) {
    return src != v.d && src < v.d + bytes && v.d < src + bytes;
  };
  if ((!axpy && partial(v.a)) || partial(v.b) || ((op == SF_OP_VECTOR_FMA || axpy) && partial(v.c)))
    return fail(SF_ERR_INVALID_ARGUMENT, "destination partially overlaps a source operand (order-dependent result)");
  return finish(L, out);
}

}  // namespace

extern "C" {

sf_status sfi_vector_add(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t d, uint64_t n, sf_dtype dt,
                               const sf_vector_opts *o, sf_cmd_t *cmd) {
  return vector_common(q, SF_OP_VECTOR_ADD, a, b, 0, d, n, dt, o, false, 0.f, cmd);
}
sf_status sfi_vector_mul(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t d, uint64_t n, sf_dtype dt,
                               const sf_vector_opts *o, sf_cmd_t *cmd) {
  return vector_common(q, SF_OP_VECTOR_MUL, a, b, 0, d, n, dt, o, false, 0.f, cmd);
}
sf_status sfi_vector_fma(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t c, sf_buffer_t d, uint64_t n,
                               const sf_vector_opts *o, sf_cmd_t *cmd) {
  return vector_common(q, SF_OP_VECTOR_FMA, a, b, c, d, n, SF_DTYPE_F32, o, false, 0.f, cmd);
}
// axpy: d = fma(alpha, x, y): x travels as operand b, y as operand c, alpha is the broadcast operand a
sf_status sfi_vector_axpy(sf_queue_t q, float alpha, sf_buffer_t x, sf_buffer_t y, sf_buffer_t d, uint64_t n,
                                const sf_vector_opts *o, sf_cmd_t *cmd) {
  return vector_common(q, SF_OP_VECTOR_AXPY, 0, x, y, d, n, SF_DTYPE_F32, o, true, alpha, cmd);
}

sf_status sfi_vector_dot(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t out, uint64_t n,
                               const sf_vector_opts *o, sf_cmd_t *cmd) {
  if (cmd) *cmd = 0;
  if (n == 0) return fail(SF_ERR_INVALID_ARGUMENT, "n is 0");
  uint32_t rm = rounding(o);
  if (rm > SF_ROUND_NEAREST_MAX) return fail(SF_ERR_INVALID_ARGUMENT, "rounding mode %u", rm);
  Lowering L;
  if (sf_status s = begin(q, SF_OP_VECTOR_DOT, L)) return s;
  VecArgs &v = L.cmd->vec;
  v.dtype = SF_DTYPE_F32;
  v.rm = rm;
  v.n = n;
  if (sf_status s = operand(L, a, 4 * n, false, "a", &v.a)) return s;
  if (sf_status s = operand(L, b, 4 * n, false, "b", &v.b)) return s;
  if (sf_status s = operand(L, out, 4, true, "out", &v.d)) return s;
  return finish(L, cmd);
}

sf_status sfi_tensor_gemm(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t c, const sf_gemm_desc *desc,
                                sf_cmd_t *cmd) {
  if (cmd) *cmd = 0;
  if (!desc) return fail(SF_ERR_INVALID_ARGUMENT, "desc is NULL");
  sf_gemm_desc g{};
  uint32_t n = desc->struct_size && desc->struct_size < sizeof g ? desc->struct_size : sizeof g;
  memcpy(&g, desc, n);
  if (g.m == 0 || g.n == 0 || g.k == 0) return fail(SF_ERR_INVALID_ARGUMENT, "m, n and k must be >= 1");
  if (g.a_type != SF_DTYPE_I8 || g.b_type != SF_DTYPE_I8)
    return fail(SF_ERR_UNSUPPORTED, "GEMM operands must be SF_DTYPE_I8 (got %u, %u): no conversion is performed",
                g.a_type, g.b_type);
  if (g.c_type != SF_DTYPE_I32 && g.c_type != SF_DTYPE_I8)
    return fail(SF_ERR_UNSUPPORTED, "GEMM output must be SF_DTYPE_I32 or SF_DTYPE_I8 (got %u)", g.c_type);
  bool i8 = g.c_type == SF_DTYPE_I8;
  uint32_t es = i8 ? 1 : 4;
  uint64_t lda = g.lda ? g.lda : g.k, ldb = g.ldb ? g.ldb : g.n, ldc = g.ldc ? g.ldc : (uint64_t)g.n * es;
  if (lda < g.k || ldb < g.n || ldc < (uint64_t)g.n * es)
    return fail(SF_ERR_INVALID_ARGUMENT, "strides must satisfy lda >= k, ldb >= n, ldc >= n * element size");
  if (!i8 && (ldc % 4)) return fail(SF_ERR_INVALID_ARGUMENT, "INT32 output needs a 4-byte multiple ldc");
  if (lda > UINT32_MAX || ldb > UINT32_MAX || ldc > UINT32_MAX) return fail(SF_ERR_INVALID_ARGUMENT, "stride too large");
  if (i8) {
    if (g.q_shift > 63) return fail(SF_ERR_INVALID_ARGUMENT, "q_shift %u > 63", g.q_shift);
    if (g.q_zero_point < -128 || g.q_zero_point > 127) return fail(SF_ERR_INVALID_ARGUMENT, "q_zero_point out of int8");
    if (g.rounding > SF_ROUND_NEAREST_MAX) return fail(SF_ERR_INVALID_ARGUMENT, "rounding mode %u", g.rounding);
  } else if (g.relu) {
    return fail(SF_ERR_INVALID_ARGUMENT, "relu applies to requantised INT8 output only");
  }
  Lowering L;
  if (sf_status s = begin(q, SF_OP_GEMM, L)) return s;
  GemmArgs &x = L.cmd->gemm;
  x.m = g.m;
  x.n = g.n;
  x.k = g.k;
  x.lda = (uint32_t)lda;
  x.ldb = (uint32_t)ldb;
  x.ldc = (uint32_t)ldc;
  x.out_i8 = i8;
  x.relu = i8 && g.relu;
  x.q_mult = i8 ? g.q_mult : 0;
  x.q_shift = i8 ? g.q_shift : 0;
  x.q_zp = i8 ? g.q_zero_point : 0;
  x.rm = i8 ? g.rounding : 0;
  uint64_t fa = (uint64_t)(g.m - 1) * lda + g.k, fb = (uint64_t)(g.k - 1) * ldb + g.n,
           fc = (uint64_t)(g.m - 1) * ldc + (uint64_t)g.n * es;
  if (sf_status s = operand(L, a, fa, false, "A", &x.a)) return s;
  if (sf_status s = operand(L, b, fb, false, "B", &x.b)) return s;
  if (sf_status s = operand(L, c, fc, true, "C", &x.c)) return s;
  // the result would depend on execution order if C overlapped an operand (TENSORCORE ALIAS rule)
  auto ov = [](uint64_t p, uint64_t pn, uint64_t r, uint64_t rn) { return p < r + rn && r < p + pn; };
  if (ov(x.c, fc, x.a, fa) || ov(x.c, fc, x.b, fb))
    return fail(SF_ERR_INVALID_ARGUMENT, "C overlaps A or B");
  return finish(L, cmd);
}

sf_status sfi_buffer_copy(sf_queue_t q, sf_buffer_t src, sf_buffer_t dst, uint64_t size, sf_cmd_t *cmd) {
  if (cmd) *cmd = 0;
  if (size == 0 || size % 4) return fail(SF_ERR_INVALID_ARGUMENT, "copy size must be a non-zero multiple of 4");
  Lowering L;
  if (sf_status s = begin(q, SF_OP_COPY, L)) return s;
  if (sf_status s = operand(L, src, size, false, "src", &L.cmd->copy.src)) return s;
  if (sf_status s = operand(L, dst, size, true, "dst", &L.cmd->copy.dst)) return s;
  L.cmd->copy.size = size;
  if (L.cmd->copy.src < L.cmd->copy.dst + size && L.cmd->copy.dst < L.cmd->copy.src + size)
    return fail(SF_ERR_INVALID_ARGUMENT, "source and destination overlap");
  return finish(L, cmd);
}

sf_status sfi_queue_marker(sf_queue_t q, sf_cmd_t *cmd) {
  if (cmd) *cmd = 0;
  Lowering L;
  if (sf_status s = begin(q, SF_OP_NOP, L)) return s;
  L.cmd->exec = Exec::kMarker;
  return submit_command(q, std::move(L.cmd), cmd);
}

sf_status sfi_debug_submit_raw(sf_queue_t q, uint32_t engine, const uint32_t *words, uint32_t nwords,
                                     sf_cmd_t *cmd) {
  if (cmd) *cmd = 0;
  if (!words || nwords == 0 || nwords > 64) return fail(SF_ERR_INVALID_ARGUMENT, "1..64 descriptor words required");
  if (engine != SF_ENGINE_VECTOR && engine != SF_ENGINE_TENSOR) return fail(SF_ERR_INVALID_ARGUMENT, "unknown engine");
  Lowering L;
  if (sf_status s = begin(q, SF_OP_RAW, L)) return s;
  L.cmd->raw.engine = engine;
  L.cmd->raw.words.assign(words, words + nwords);
  return finish(L, cmd);
}

}  // extern "C"
