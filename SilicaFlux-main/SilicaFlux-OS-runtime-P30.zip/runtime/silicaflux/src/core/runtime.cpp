// SilicaFlux.OS -- command and memory manager: handles, devices, buffers, queues.
#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <thread>

#include "internal.h"

namespace sf {

// ================================================================== errors / time
static thread_local char t_detail[512] = "";

sf_status fail(sf_status s, const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(t_detail, sizeof t_detail, fmt, ap);
  va_end(ap);
  return s;
}
void clear_detail() { t_detail[0] = 0; }

uint64_t host_ns() {
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

std::atomic<bool> g_interrupt{false};

// ================================================================== allocator
void Allocator::init(const std::vector<MemRegion> &regions, uint64_t align) {
  free_.clear();
  live_.clear();
  align_ = align;
  total_ = used_ = 0;
  for (const auto &r : regions) {
    uint64_t b = (r.base + align - 1) / align * align;
    if (b >= r.base + r.size) continue;
    uint64_t s = (r.base + r.size - b) / align * align;
    if (!s) continue;
    free_[b] = s;
    total_ += s;
  }
}

bool Allocator::alloc(uint64_t size, uint64_t *addr) {
  uint64_t need = (std::max<uint64_t>(size, 1) + align_ - 1) / align_ * align_;
  for (auto it = free_.begin(); it != free_.end(); ++it) {
    if (it->second < need) continue;
    uint64_t base = it->first, rest = it->second - need;
    free_.erase(it);
    if (rest) free_[base + need] = rest;
    live_[base] = need;
    used_ += need;
    *addr = base;
    return true;
  }
  return false;
}

void Allocator::free(uint64_t addr) {
  auto it = live_.find(addr);
  if (it == live_.end()) return;
  uint64_t base = addr, size = it->second;
  live_.erase(it);
  used_ -= size;
  auto nx = free_.lower_bound(base);
  if (nx != free_.end() && base + size == nx->first) {   // merge with the next free range
    size += nx->second;
    nx = free_.erase(nx);
  }
  if (nx != free_.begin()) {                               // merge with the previous one
    auto pv = std::prev(nx);
    if (pv->first + pv->second == base) {
      pv->second += size;
      return;
    }
  }
  free_[base] = size;
}

// ================================================================== handle tables
namespace {

enum : uint64_t { kTagDev = 1, kTagBuf = 2, kTagQueue = 3 };

template <typename T>
struct Table {
  struct Slot {
    uint32_t gen = 1;
    std::shared_ptr<T> p;
  };
  std::vector<Slot> slots;
  std::vector<uint32_t> free_list;
  uint64_t tag;
  explicit Table(uint64_t t) : tag(t) {}
  uint64_t add(std::shared_ptr<T> p) {
    uint32_t i;
    if (!free_list.empty()) {
      i = free_list.back();
      free_list.pop_back();
    } else {
      i = (uint32_t)slots.size();
      slots.push_back({});
    }
    slots[i].p = std::move(p);
    return (tag << 56) | ((uint64_t)(slots[i].gen & 0xFFFFFFu) << 32) | (uint64_t)(i + 1);
  }
  std::shared_ptr<T> get(uint64_t h) const {
    if ((h >> 56) != tag) return nullptr;
    uint32_t i = (uint32_t)(h & 0xFFFFFFFFu);
    uint32_t g = (uint32_t)((h >> 32) & 0xFFFFFFu);
    if (i == 0 || i > slots.size()) return nullptr;
    const Slot &s = slots[i - 1];
    if (!s.p || (s.gen & 0xFFFFFFu) != g) return nullptr;
    return s.p;
  }
  std::shared_ptr<T> remove(uint64_t h) {
    auto p = get(h);
    if (!p) return nullptr;
    Slot &s = slots[(h & 0xFFFFFFFFu) - 1];
    s.p.reset();
    s.gen++;
    free_list.push_back((uint32_t)((h & 0xFFFFFFFFu) - 1));
    return p;
  }
};

struct Registry {
  std::mutex mu;
  Table<DeviceObj> devs{kTagDev};
  Table<BufferObj> bufs{kTagBuf};
  Table<QueueObj> queues{kTagQueue};
  bool discovered = false;
  std::vector<DeviceEntry> entries;
  std::vector<bool> open_flags;
};

Registry &reg() {
  static Registry *r = new Registry();   // intentionally leaked: usable from atexit handlers
  return *r;
}

void ensure_discovered(Registry &r) {
  if (r.discovered) return;
  r.entries = discover_devices();
  r.open_flags.assign(r.entries.size(), false);
  r.discovered = true;
}

std::shared_ptr<DeviceObj> get_dev(sf_device_t h) {
  auto &r = reg();
  std::lock_guard<std::mutex> g(r.mu);
  return r.devs.get(h);
}

std::shared_ptr<QueueObj> get_q(sf_queue_t h) {
  auto &r = reg();
  std::lock_guard<std::mutex> g(r.mu);
  return r.queues.get(h);
}

template <typename T>
void copy_out(T *dst, const T &src) {
  uint32_t n = dst->struct_size;
  if (n == 0 || n > sizeof(T)) n = sizeof(T);
  memcpy((void *)dst, (const void *)&src, n);
  dst->struct_size = n;
}

void set_str(char *dst, size_t cap, const std::string &s) {
  snprintf(dst, cap, "%s", s.c_str());
}

}  // namespace

sf_status get_buffer(sf_buffer_t h, BufRef *out) {
  auto &r = reg();
  std::shared_ptr<BufferObj> b;
  {
    std::lock_guard<std::mutex> g(r.mu);
    b = r.bufs.get(h);
  }
  if (!b) return fail(SF_ERR_INVALID_BUFFER, "buffer handle %#llx is not valid (released or never created)",
                      (unsigned long long)h);
  auto d = b->dev.lock();
  if (!d || d->closed) return fail(SF_ERR_INVALID_BUFFER, "the buffer's device is closed");
  out->b = b;
  out->d = d;
  return SF_OK;
}

sf_status get_queue_device(sf_queue_t qh, std::shared_ptr<DeviceObj> *dev) {
  auto q = get_q(qh);
  if (!q || q->destroyed) return fail(SF_ERR_INVALID_QUEUE, "queue handle %#llx is not valid", (unsigned long long)qh);
  auto d = q->dev.lock();
  if (!d || d->closed) return fail(SF_ERR_INVALID_QUEUE, "the queue's device is closed");
  *dev = d;
  return SF_OK;
}

BufferObj::~BufferObj() {
  if (is_view) return;
  auto d = dev.lock();
  if (!d) return;
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (!d->closed) d->alloc.free(addr);
}

// ================================================================== backend defaults
sf_status Backend::zero(uint64_t addr, uint64_t n) {
  std::vector<uint8_t> z((size_t)std::min<uint64_t>(n, 65536), 0);
  for (uint64_t off = 0; off < n;) {
    uint64_t c = std::min<uint64_t>(z.size(), n - off);
    sf_status s = write(addr + off, z.data(), c);
    if (s) return s;
    off += c;
  }
  return SF_OK;
}
sf_status Backend::selftest(uint32_t, sf_selftest_result &) {
  return fail(SF_ERR_UNSUPPORTED, "this device has no device-resident self-test");
}
sf_status Backend::inject(sf_inject_kind, uint64_t, uint64_t) {
  return fail(SF_ERR_UNSUPPORTED, "fault injection is only available on simulators");
}

// ================================================================== queue engine
namespace {

void complete_with(Command &c, sf_status s, const char *why) {
  c.done = true;
  c.result.status = s;
  if (c.result.exec_target == 0) c.result.exec_target = SF_EXEC_NONE;
  (void)why;
}

class FallbackMem : public MemAccess {
 public:
  explicit FallbackMem(Backend &b) : be(b) {}
  sf_status rd(uint64_t a, void *d, uint64_t n) override { return be.read(a, d, n); }
  sf_status wr(uint64_t a, const void *s, uint64_t n) override { return be.write(a, s, n); }
  Backend &be;
};

void retire(DeviceObj &d, uint64_t qh, QueueObj &q) {
  std::unique_ptr<Command> c = std::move(q.cmds.front());
  q.cmds.pop_front();
  if (!c->result.host_complete_ns) c->result.host_complete_ns = host_ns();
  c->result.struct_size = sizeof(sf_cmd_result);
  for (auto &b : c->reads) b->root()->pending_reads--;
  for (auto &b : c->writes) b->root()->pending_writes--;
  c->reads.clear();
  c->writes.clear();
  if (c->result.status == SF_OK) d.completed++;
  else d.failed++;
  q.results[c->id] = c->result;
  q.last_retired = c->id;
  while (q.results.size() > 4096) q.results.erase(q.results.begin());
  if (d.tracing) d.trace.push_back({qh, c->id, c->result});
}

void mark_lost(DeviceObj &d, QueueObj &q) {
  for (auto &c : q.cmds)
    if (!c->done) complete_with(*c, SF_ERR_DEVICE_LOST, "device lost");
}

// One non-blocking step of a queue: start what can start, collect completions, retire in order.
void pump(DeviceObj &d, uint64_t qh, QueueObj &q) {
  if (d.lost) mark_lost(d, q);
  bool barrier = false;   // a host-executed command that has not run yet blocks later starts
  for (size_t i = 0; i < q.cmds.size() && !d.lost; i++) {
    Command &c = *q.cmds[i];
    if (c.started) {
      if (c.exec != Exec::kBackend && !c.done) barrier = true;
      continue;
    }
    if (c.exec == Exec::kBackend) {
      if (barrier) break;
      sf_status s = q.bq->start(c);
      if (s == SF_ERR_QUEUE_FULL) break;
      if (s == SF_ERR_DEVICE_LOST) {
        d.lost = true;
        mark_lost(d, q);
        break;
      }
      c.started = true;
      if (s != SF_OK) complete_with(c, s, "rejected at start");
    } else {
      // host-executed: only after every older command has completed
      bool older_done = true;
      for (size_t j = 0; j < i; j++)
        if (!q.cmds[j]->done) older_done = false;
      if (!older_done) {
        barrier = true;
        break;
      }
      c.started = true;
      c.result.host_submit_ns = c.result.host_submit_ns ? c.result.host_submit_ns : host_ns();
      if (c.exec == Exec::kMarker) {
        c.result.exec_target = SF_EXEC_NONE;
        complete_with(c, SF_OK, "marker");
      } else {
        FallbackMem mem(*d.be);
        sf_status s = cpu_execute(c, mem, d.info.vector_lanes ? d.info.vector_lanes : 4, c.result);
        c.result.exec_target = SF_EXEC_CPU_FALLBACK;
        complete_with(c, s, "fallback");
      }
    }
  }
  if (!d.lost) {
    std::deque<Command *> started;
    for (auto &c : q.cmds)
      if (c->started && !c->done && c->exec == Exec::kBackend) started.push_back(c.get());
    if (!started.empty()) {
      sf_status s = q.bq->poll(started);
      if (s == SF_ERR_DEVICE_LOST) {
        d.lost = true;
        d.last_error = s;
        mark_lost(d, q);
      }
    }
  }
  while (!q.cmds.empty() && q.cmds.front()->done) retire(d, qh, q);
}

void pump_all(DeviceObj &d) {
  for (uint64_t qh : d.queues) {
    auto q = get_q(qh);
    if (q && !q->destroyed) pump(d, qh, *q);
  }
}

uint64_t default_timeout_ms(DeviceObj &d) {
  return d.info.default_timeout_ms ? d.info.default_timeout_ms : 10000;
}

uint64_t sim_wall_guard_ns() {
  const char *e = getenv("SILICAFLUX_SIM_WALL_TIMEOUT_S");
  uint64_t s = e ? strtoull(e, nullptr, 10) : 900;
  if (!s) s = 900;
  return s * 1000000000ull;
}

// Generic bounded wait: `done()` evaluated after every pump.
template <typename F>
sf_status wait_until(DeviceObj &d, uint64_t timeout_ms, F done) {
  if (timeout_ms == SF_TIMEOUT_DEFAULT) timeout_ms = default_timeout_ms(d);
  const uint64_t t_dev0 = d.be->device_time_us();
  const uint64_t deadline_us = t_dev0 + timeout_ms * 1000ull;
  const uint64_t wall_deadline = host_ns() + (d.be->is_simulator() ? sim_wall_guard_ns() : timeout_ms * 1000000ull + 1000000000ull);
  for (;;) {
    pump_all(d);
    if (done()) return SF_OK;
    if (d.lost) return fail(SF_ERR_DEVICE_LOST, "device lost: %s", sf_status_string(d.last_error));
    if (g_interrupt.load()) return fail(SF_ERR_INTERRUPTED, "wait interrupted by sf_interrupt()");
    if (d.be->device_time_us() > deadline_us)
      return fail(SF_ERR_TIMEOUT, "no completion within %llu ms of %s time", (unsigned long long)timeout_ms,
                  d.be->is_simulator() ? "simulated device" : "device");
    if (host_ns() > wall_deadline)
      return fail(SF_ERR_TIMEOUT, "wall-clock guard expired (simulated time advanced %llu us)",
                  (unsigned long long)(d.be->device_time_us() - t_dev0));
    d.be->advance();
  }
}

}  // namespace

sf_status submit_command(uint64_t qh, std::unique_ptr<Command> cmd, sf_cmd_t *out) {
  auto q = get_q(qh);
  if (!q || q->destroyed) return fail(SF_ERR_INVALID_QUEUE, "queue handle %#llx is not valid", (unsigned long long)qh);
  auto d = q->dev.lock();
  if (!d || d->closed) return fail(SF_ERR_INVALID_QUEUE, "the queue's device is closed");
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost: reset it with SF_RESET_FULL");
  pump(*d, qh, *q);   // retire what has completed: frees slots
  if (q->cmds.size() >= q->depth)
    return fail(SF_ERR_QUEUE_FULL, "queue depth %u reached: %zu commands outstanding (nothing was submitted)",
                q->depth, q->cmds.size());
  // ownership: the device owns the buffers from now until retirement
  for (auto &b : cmd->reads) b->root()->pending_reads++;
  for (auto &b : cmd->writes) b->root()->pending_writes++;
  cmd->id = q->next_id++;
  cmd->result.struct_size = sizeof(sf_cmd_result);
  cmd->result.op = cmd->op;
  cmd->result.host_submit_ns = host_ns();
  if (out) *out = cmd->id;
  q->cmds.push_back(std::move(cmd));
  pump(*d, qh, *q);
  return SF_OK;
}

}  // namespace sf

// ==================================================================== C API
using namespace sf;

extern "C" {

SF_API uint32_t sf_get_api_version(void) { return SF_API_VERSION; }

SF_API const char *sf_get_build_info(void) {
  static std::string s = "silicaflux 1.0.0 (C ABI 1.0; backends: " + build_backends() + ")";
  return s.c_str();
}

SF_API const char *sf_status_string(sf_status s) {
  switch (s) {
    case SF_OK: return "SF_OK";
    case SF_PENDING: return "SF_PENDING";
    case SF_ERR_INVALID_ARGUMENT: return "SF_ERR_INVALID_ARGUMENT";
    case SF_ERR_NO_DEVICE: return "SF_ERR_NO_DEVICE";
    case SF_ERR_UNSUPPORTED: return "SF_ERR_UNSUPPORTED";
    case SF_ERR_INCOMPATIBLE_VERSION: return "SF_ERR_INCOMPATIBLE_VERSION";
    case SF_ERR_OUT_OF_MEMORY: return "SF_ERR_OUT_OF_MEMORY";
    case SF_ERR_INVALID_DEVICE: return "SF_ERR_INVALID_DEVICE";
    case SF_ERR_INVALID_BUFFER: return "SF_ERR_INVALID_BUFFER";
    case SF_ERR_INVALID_QUEUE: return "SF_ERR_INVALID_QUEUE";
    case SF_ERR_INVALID_COMMAND: return "SF_ERR_INVALID_COMMAND";
    case SF_ERR_OUT_OF_RANGE: return "SF_ERR_OUT_OF_RANGE";
    case SF_ERR_PERMISSION: return "SF_ERR_PERMISSION";
    case SF_ERR_BUSY: return "SF_ERR_BUSY";
    case SF_ERR_QUEUE_FULL: return "SF_ERR_QUEUE_FULL";
    case SF_ERR_TIMEOUT: return "SF_ERR_TIMEOUT";
    case SF_ERR_DMA: return "SF_ERR_DMA";
    case SF_ERR_DEVICE: return "SF_ERR_DEVICE";
    case SF_ERR_ABORTED: return "SF_ERR_ABORTED";
    case SF_ERR_DEVICE_LOST: return "SF_ERR_DEVICE_LOST";
    case SF_ERR_INTERRUPTED: return "SF_ERR_INTERRUPTED";
    case SF_ERR_INTERNAL: return "SF_ERR_INTERNAL";
    default: return "SF_ERR_<unknown>";
  }
}

SF_API const char *sf_last_error_detail(void) { return t_detail; }

SF_API void sf_interrupt(void) { g_interrupt.store(true); }
SF_API void sf_clear_interrupt(void) { g_interrupt.store(false); }

// ------------------------------------------------------------------ discovery
sf_status sfi_get_device_count(uint32_t *count) {
  if (!count) return fail(SF_ERR_INVALID_ARGUMENT, "count is NULL");
  auto &r = reg();
  std::lock_guard<std::mutex> g(r.mu);
  ensure_discovered(r);
  *count = (uint32_t)r.entries.size();
  return SF_OK;
}

static void static_info(const DeviceEntry &e, uint32_t index, sf_device_info &i) {
  memset(&i, 0, sizeof i);
  i.struct_size = sizeof i;
  i.index = index;
  set_str(i.name, sizeof i.name, e.name);
  set_str(i.description, sizeof i.description, e.description);
  i.kind = e.kind;
  i.is_simulator = e.simulator ? 1 : 0;
  i.available = e.available ? 1 : 0;
  i.caps = e.static_caps;
}

sf_status sfi_get_device_info(uint32_t index, sf_device_info *info) {
  if (!info) return fail(SF_ERR_INVALID_ARGUMENT, "info is NULL");
  auto &r = reg();
  std::lock_guard<std::mutex> g(r.mu);
  ensure_discovered(r);
  if (index >= r.entries.size()) return fail(SF_ERR_NO_DEVICE, "device index %u out of range", index);
  sf_device_info i;
  static_info(r.entries[index], index, i);
  copy_out(info, i);
  return SF_OK;
}

// ------------------------------------------------------------------ device
sf_status sfi_device_open(uint32_t index, uint32_t flags, sf_device_t *dev) {
  if (!dev) return fail(SF_ERR_INVALID_ARGUMENT, "dev is NULL");
  *dev = SF_NULL_HANDLE;
  auto &r = reg();
  DeviceEntry e;
  {
    std::lock_guard<std::mutex> g(r.mu);
    ensure_discovered(r);
    if (index >= r.entries.size()) return fail(SF_ERR_NO_DEVICE, "device index %u out of range", index);
    if (!r.entries[index].available)
      return fail(SF_ERR_NO_DEVICE, "%s is not available: %s", r.entries[index].name.c_str(),
                  r.entries[index].description.c_str());
    if (r.open_flags[index]) return fail(SF_ERR_BUSY, "%s is already open (exclusive access)", r.entries[index].name.c_str());
    r.open_flags[index] = true;
    const DeviceEntry &src = r.entries[index];
    e.name = src.name;
    e.description = src.description;
    e.kind = src.kind;
    e.simulator = src.simulator;
    e.available = src.available;
    e.static_caps = src.static_caps;
    e.make = src.make;
    e.arg = src.arg;
  }
  auto release_slot = [&]() {
    std::lock_guard<std::mutex> g(r.mu);
    r.open_flags[index] = false;
  };
  auto d = std::make_shared<DeviceObj>();
  d->entry.name = e.name;
  d->entry.description = e.description;
  d->entry.kind = e.kind;
  d->entry.simulator = e.simulator;
  d->entry.arg = e.arg;
  clear_detail();
  d->be = e.make(e);
  if (!d->be) {
    release_slot();
    std::string why = *sf_last_error_detail() ? sf_last_error_detail() : "backend unavailable";
    return fail(SF_ERR_NO_DEVICE, "%s: %s", e.name.c_str(), why.c_str());
  }
  clear_detail();
  sf_status s = d->be->open(flags);
  if (s != SF_OK) {
    release_slot();
    return s;   // detail set by the backend
  }
  d->open_flags = flags;
  static_info(e, index, d->info);
  d->be->fill_info(d->info);
  d->info.struct_size = sizeof d->info;
  d->info.min_alignment = d->be->min_alignment();
  d->alloc.init(d->be->memory_regions(), d->info.min_alignment);
  d->info.device_memory_bytes = d->alloc.total();
  std::lock_guard<std::mutex> g(r.mu);
  *dev = r.devs.add(d);
  return SF_OK;
}

sf_status sfi_device_open_by_name(const char *name, uint32_t flags, sf_device_t *dev) {
  if (!name || !dev) return fail(SF_ERR_INVALID_ARGUMENT, "name/dev is NULL");
  uint32_t n = 0;
  sf_get_device_count(&n);
  for (uint32_t i = 0; i < n; i++) {
    sf_device_info info{};
    info.struct_size = sizeof info;
    sf_get_device_info(i, &info);
    if (!strcmp(info.name, name)) return sf_device_open(i, flags, dev);
  }
  return fail(SF_ERR_NO_DEVICE, "no device named '%s' (see `silicaflux info`)", name);
}

sf_status sfi_device_close(sf_device_t dh) {
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::vector<uint64_t> qs, bs;
  {
    std::lock_guard<std::recursive_mutex> g(d->mu);
    qs = d->queues;
    bs = d->buffers;
  }
  if (g_interrupt.load() && !d->lost) {
    std::lock_guard<std::recursive_mutex> g(d->mu);
    d->be->reset(SF_RESET_ENGINES);   // abort outstanding work instead of waiting for it
  }
  for (uint64_t q : qs) sf_queue_destroy(q);
  for (uint64_t b : bs) sf_buffer_release(b);
  {
    std::lock_guard<std::recursive_mutex> g(d->mu);
    if (d->tracing) {
      sf::write_trace(*d);
      d->tracing = false;
    }
    d->be->close();
    d->closed = true;
  }
  auto &r = reg();
  std::lock_guard<std::mutex> g(r.mu);
  r.devs.remove(dh);
  for (size_t i = 0; i < r.entries.size(); i++)
    if (r.entries[i].name == d->entry.name) r.open_flags[i] = false;
  return SF_OK;
}

sf_status sfi_device_get_info(sf_device_t dh, sf_device_info *info) {
  if (!info) return fail(SF_ERR_INVALID_ARGUMENT, "info is NULL");
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  copy_out(info, d->info);
  return SF_OK;
}

sf_status sfi_device_reset(sf_device_t dh, sf_reset_level level) {
  if (level != SF_RESET_ENGINES && level != SF_RESET_FULL) return fail(SF_ERR_INVALID_ARGUMENT, "bad reset level");
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  sf_status s = d->be->reset(level);
  // every outstanding command is aborted; queues are re-created on the device
  for (uint64_t qh : d->queues) {
    auto q = get_q(qh);
    if (!q) continue;
    for (auto &c : q->cmds)
      if (!c->done) {
        c->done = true;
        c->started = true;
        c->result.status = SF_ERR_ABORTED;
        c->result.exec_target = SF_EXEC_NONE;
      }
    while (!q->cmds.empty()) retire(*d, qh, *q);
    q->bq->abandon();
    q->bq.reset();
    if (s == SF_OK) {
      sf_status cs = d->be->create_queue(q->depth, &q->bq);
      if (cs != SF_OK) s = cs;
    }
  }
  if (s == SF_OK) {
    d->lost = false;
    d->resets++;
  } else {
    d->lost = true;
    d->last_error = s;
  }
  return s;
}

sf_status sfi_device_get_status(sf_device_t dh, sf_device_status *st) {
  if (!st) return fail(SF_ERR_INVALID_ARGUMENT, "status is NULL");
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  sf_device_status s{};
  s.struct_size = sizeof s;
  s.state = SF_STATE_READY;
  sf_status rc = SF_OK;
  if (!d->lost) rc = d->be->status(s);
  if (d->lost) s.state = SF_STATE_LOST;
  s.last_error = d->lost ? d->last_error : s.last_error;
  s.commands_completed = d->completed;
  s.commands_failed = d->failed;
  s.resets = d->resets;
  copy_out(st, s);
  return rc;
}

sf_status sfi_device_selftest(sf_device_t dh, uint32_t mask, sf_selftest_result *res) {
  if (!res) return fail(SF_ERR_INVALID_ARGUMENT, "result is NULL");
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  // the device-resident suite exercises every engine: run it only when idle
  sf_status ws = wait_until(*d, SF_TIMEOUT_DEFAULT, [&]() {
    for (uint64_t qh : d->queues) {
      auto q = get_q(qh);
      if (q && !q->cmds.empty()) return false;
    }
    return true;
  });
  if (ws) return ws;
  sf_selftest_result r{};
  r.struct_size = sizeof r;
  sf_status s = d->be->selftest(mask, r);
  copy_out(res, r);
  return s;
}

sf_status sfi_device_read_console(sf_device_t dh, char *buf, size_t cap, size_t *len) {
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  std::string s = d->be->take_console();
  size_t n = buf && cap ? std::min(cap - 1, s.size()) : 0;
  if (n) memcpy(buf, s.data(), n);
  if (buf && cap) buf[n] = 0;
  if (len) *len = s.size();
  return SF_OK;
}

// ------------------------------------------------------------------ buffers
sf_status sfi_buffer_create(sf_device_t dh, uint64_t size, uint32_t flags, sf_buffer_t *out) {
  if (!out) return fail(SF_ERR_INVALID_ARGUMENT, "buf is NULL");
  *out = SF_NULL_HANDLE;
  if (size == 0) return fail(SF_ERR_INVALID_ARGUMENT, "size is 0");
  if (flags & ~(uint32_t)SF_MEM_READ_WRITE) return fail(SF_ERR_INVALID_ARGUMENT, "unknown buffer flags %#x", flags);
  if (!(flags & (SF_MEM_DEVICE_READ | SF_MEM_DEVICE_WRITE)))
    return fail(SF_ERR_INVALID_ARGUMENT, "a buffer needs SF_MEM_DEVICE_READ and/or SF_MEM_DEVICE_WRITE");
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  uint64_t addr = 0;
  if (!d->alloc.alloc(size, &addr))
    return fail(SF_ERR_OUT_OF_MEMORY, "no contiguous %llu-byte range free (%llu of %llu bytes in use)",
                (unsigned long long)size, (unsigned long long)d->alloc.used(), (unsigned long long)d->alloc.total());
  sf_status s = d->be->zero(addr, (size + 3) & ~3ull);
  if (s != SF_OK) {
    d->alloc.free(addr);
    return s;
  }
  auto b = std::make_shared<BufferObj>();
  b->dev = d;
  b->addr = addr;
  b->size = size;
  b->flags = flags;
  auto &r = reg();
  std::lock_guard<std::mutex> rg(r.mu);
  *out = r.bufs.add(b);
  d->buffers.push_back(*out);
  return SF_OK;
}

sf_status sfi_buffer_create_view(sf_buffer_t parent, uint64_t offset, uint64_t size, uint32_t flags,
                                       sf_buffer_t *view) {
  if (!view) return fail(SF_ERR_INVALID_ARGUMENT, "view is NULL");
  *view = SF_NULL_HANDLE;
  BufRef p;
  if (sf_status s = get_buffer(parent, &p)) return s;
  if (offset % 4) return fail(SF_ERR_INVALID_ARGUMENT, "view offset %llu is not a multiple of 4", (unsigned long long)offset);
  if (size == 0 || offset > p.b->size || size > p.b->size - offset)
    return fail(SF_ERR_OUT_OF_RANGE, "view [%llu, +%llu) outside the %llu-byte parent", (unsigned long long)offset,
                (unsigned long long)size, (unsigned long long)p.b->size);
  if (flags & ~p.b->flags)
    return fail(SF_ERR_PERMISSION, "view flags %#x exceed the parent's %#x", flags, p.b->flags);
  std::lock_guard<std::recursive_mutex> g(p.d->mu);
  auto v = std::make_shared<BufferObj>();
  v->dev = p.d;
  v->parent = p.b;
  v->addr = p.b->addr + offset;
  v->size = size;
  v->flags = flags;
  v->is_view = true;
  auto &r = reg();
  std::lock_guard<std::mutex> rg(r.mu);
  *view = r.bufs.add(v);
  p.d->buffers.push_back(*view);
  return SF_OK;
}

sf_status sfi_buffer_release(sf_buffer_t h) {
  auto &r = reg();
  std::shared_ptr<BufferObj> b;
  {
    std::lock_guard<std::mutex> g(r.mu);
    b = r.bufs.remove(h);
  }
  if (!b) return fail(SF_ERR_INVALID_BUFFER, "buffer handle %#llx is not valid (double release?)", (unsigned long long)h);
  if (auto d = b->dev.lock()) {
    std::lock_guard<std::recursive_mutex> g(d->mu);
    auto &v = d->buffers;
    v.erase(std::remove(v.begin(), v.end(), h), v.end());
  }
  return SF_OK;   // memory is freed when the last pending command retires
}

static sf_status host_access_check(BufRef &br, uint64_t off, uint64_t size, bool write) {
  if (size == 0) return fail(SF_ERR_INVALID_ARGUMENT, "size is 0");
  if (off > br.b->size || size > br.b->size - off)
    return fail(SF_ERR_OUT_OF_RANGE, "[%llu, +%llu) outside the %llu-byte buffer", (unsigned long long)off,
                (unsigned long long)size, (unsigned long long)br.b->size);
  if (write && !(br.b->flags & SF_MEM_HOST_WRITE)) return fail(SF_ERR_PERMISSION, "buffer has no SF_MEM_HOST_WRITE");
  if (!write && !(br.b->flags & SF_MEM_HOST_READ)) return fail(SF_ERR_PERMISSION, "buffer has no SF_MEM_HOST_READ");
  BufferObj *root = br.b->root();
  if (br.d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  if (root->pending_writes.load() || (write && root->pending_reads.load()))
    return fail(SF_ERR_BUSY, "the buffer is owned by %u pending command(s): call sf_buffer_sync first",
                root->pending_writes.load() + (write ? root->pending_reads.load() : 0u));
  return SF_OK;
}

sf_status sfi_buffer_write(sf_buffer_t h, uint64_t off, const void *src, uint64_t size) {
  if (!src) return fail(SF_ERR_INVALID_ARGUMENT, "src is NULL");
  BufRef br;
  if (sf_status s = get_buffer(h, &br)) return s;
  std::lock_guard<std::recursive_mutex> g(br.d->mu);
  pump_all(*br.d);
  if (sf_status s = host_access_check(br, off, size, true)) return s;
  uint64_t t0 = host_ns();
  sf_status s = br.d->be->write(br.b->addr + off, src, size);
  br.d->transfer_ns += host_ns() - t0;
  if (s == SF_OK) br.d->bytes_h2d += size;
  return s;
}

sf_status sfi_buffer_read(sf_buffer_t h, uint64_t off, void *dst, uint64_t size) {
  if (!dst) return fail(SF_ERR_INVALID_ARGUMENT, "dst is NULL");
  BufRef br;
  if (sf_status s = get_buffer(h, &br)) return s;
  std::lock_guard<std::recursive_mutex> g(br.d->mu);
  pump_all(*br.d);
  if (sf_status s = host_access_check(br, off, size, false)) return s;
  uint64_t t0 = host_ns();
  sf_status s = br.d->be->read(br.b->addr + off, dst, size);
  br.d->transfer_ns += host_ns() - t0;
  if (s == SF_OK) br.d->bytes_d2h += size;
  return s;
}

sf_status sfi_buffer_sync(sf_buffer_t h, uint64_t timeout_ms) {
  BufRef br;
  if (sf_status s = get_buffer(h, &br)) return s;
  std::lock_guard<std::recursive_mutex> g(br.d->mu);
  BufferObj *root = br.b->root();
  return wait_until(*br.d, timeout_ms,
                    [&]() { return root->pending_reads.load() == 0 && root->pending_writes.load() == 0; });
}

sf_status sfi_buffer_get_info(sf_buffer_t h, sf_buffer_info *info) {
  if (!info) return fail(SF_ERR_INVALID_ARGUMENT, "info is NULL");
  BufRef br;
  if (sf_status s = get_buffer(h, &br)) return s;
  std::lock_guard<std::recursive_mutex> g(br.d->mu);
  pump_all(*br.d);
  sf_buffer_info i{};
  i.struct_size = sizeof i;
  i.flags = br.b->flags;
  i.size = br.b->size;
  i.device_address = br.b->addr;
  i.pending_commands = br.b->root()->pending_reads.load() + br.b->root()->pending_writes.load();
  i.is_view = br.b->is_view;
  copy_out(info, i);
  return SF_OK;
}

// ------------------------------------------------------------------ queues
sf_status sfi_queue_create(sf_device_t dh, uint32_t depth, sf_queue_t *out) {
  if (!out) return fail(SF_ERR_INVALID_ARGUMENT, "queue is NULL");
  *out = SF_NULL_HANDLE;
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  if (depth == 0 || depth > d->info.max_queue_depth)
    return fail(SF_ERR_INVALID_ARGUMENT, "depth %u outside 1..%u", depth, d->info.max_queue_depth);
  if (d->queues.size() >= d->info.max_queues)
    return fail(SF_ERR_BUSY, "the device supports %u queues", d->info.max_queues);
  auto q = std::make_shared<QueueObj>();
  q->dev = d;
  q->depth = depth;
  if (sf_status s = d->be->create_queue(depth, &q->bq)) return s;
  auto &r = reg();
  std::lock_guard<std::mutex> rg(r.mu);
  *out = r.queues.add(q);
  d->queues.push_back(*out);
  return SF_OK;
}

sf_status sfi_queue_destroy(sf_queue_t qh) {
  auto q = get_q(qh);
  if (!q || q->destroyed) return fail(SF_ERR_INVALID_QUEUE, "queue handle %#llx is not valid", (unsigned long long)qh);
  auto d = q->dev.lock();
  sf_status rc = SF_OK;
  if (d) {
    std::lock_guard<std::recursive_mutex> g(d->mu);
    if (!d->lost && !g_interrupt.load())
      rc = wait_until(*d, SF_TIMEOUT_DEFAULT, [&]() { return q->cmds.empty(); });
    for (auto &c : q->cmds)
      if (!c->done) {
        c->done = true;
        c->result.status = SF_ERR_ABORTED;
      }
    if (!q->cmds.empty() && rc != SF_OK && !d->lost) d->be->reset(SF_RESET_ENGINES);
    while (!q->cmds.empty()) retire(*d, qh, *q);
    if (q->bq) {
      if (d->lost) q->bq->abandon();
      q->bq.reset();
    }
    auto &v = d->queues;
    v.erase(std::remove(v.begin(), v.end(), qh), v.end());
  }
  q->destroyed = true;
  auto &r = reg();
  std::lock_guard<std::mutex> g(r.mu);
  r.queues.remove(qh);
  return rc == SF_ERR_TIMEOUT ? fail(SF_ERR_TIMEOUT, "queue destroyed after a timeout: outstanding commands aborted")
                              : SF_OK;
}

sf_status sfi_queue_pending(sf_queue_t qh, uint32_t *count) {
  if (!count) return fail(SF_ERR_INVALID_ARGUMENT, "count is NULL");
  std::shared_ptr<DeviceObj> d;
  if (sf_status s = get_queue_device(qh, &d)) return s;
  auto q = get_q(qh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  pump(*d, qh, *q);
  *count = (uint32_t)q->cmds.size();
  return SF_OK;
}

sf_status sfi_queue_poll(sf_queue_t qh, sf_cmd_t cmd, sf_cmd_result *res) {
  std::shared_ptr<DeviceObj> d;
  if (sf_status s = get_queue_device(qh, &d)) return s;
  auto q = get_q(qh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  if (cmd == 0 || cmd >= q->next_id) return fail(SF_ERR_INVALID_COMMAND, "command id %llu was never submitted", (unsigned long long)cmd);
  for (int pass = 0; pass < 2; pass++) {
    pump(*d, qh, *q);
    if (cmd <= q->last_retired) {
      auto it = q->results.find(cmd);
      if (it == q->results.end())
        return fail(SF_ERR_INVALID_COMMAND, "result of command %llu is no longer retained", (unsigned long long)cmd);
      if (res) copy_out(res, it->second);
      return it->second.status == SF_OK ? SF_OK : fail(it->second.status, "command %llu completed with %s",
                                                      (unsigned long long)cmd, sf_status_string(it->second.status));
    }
    if (pass == 0 && !d->lost) d->be->advance();   // a simulator only progresses when the host lets it
  }
  if (d->lost) return fail(SF_ERR_DEVICE_LOST, "device lost");
  return SF_PENDING;
}

sf_status sfi_queue_wait(sf_queue_t qh, sf_cmd_t cmd, uint64_t timeout_ms, sf_cmd_result *res) {
  std::shared_ptr<DeviceObj> d;
  if (sf_status s = get_queue_device(qh, &d)) return s;
  auto q = get_q(qh);
  std::lock_guard<std::recursive_mutex> g(d->mu);
  sf_cmd_t target = cmd == SF_CMD_ALL ? q->next_id - 1 : cmd;
  if (cmd != SF_CMD_ALL && (cmd == 0 || cmd >= q->next_id))
    return fail(SF_ERR_INVALID_COMMAND, "command id %llu was never submitted", (unsigned long long)cmd);
  if (target == 0) return SF_OK;   // nothing submitted
  sf_status s = wait_until(*d, timeout_ms, [&]() { return q->last_retired >= target; });
  if (s != SF_OK) return s;
  auto it = q->results.find(target);
  if (it == q->results.end())
    return fail(SF_ERR_INVALID_COMMAND, "result of command %llu is no longer retained", (unsigned long long)target);
  if (res) copy_out(res, it->second);
  return it->second.status == SF_OK ? SF_OK : fail(it->second.status, "command %llu completed with %s",
                                                  (unsigned long long)target, sf_status_string(it->second.status));
}

// ------------------------------------------------------------------ diagnostics
sf_status sfi_debug_inject(sf_device_t dh, sf_inject_kind kind, sf_buffer_t buf, uint64_t offset,
                                 uint64_t size) {
  auto d = get_dev(dh);
  if (!d) return fail(SF_ERR_INVALID_DEVICE, "device handle %#llx is not valid", (unsigned long long)dh);
  uint64_t addr = 0;
  if (kind == SF_INJECT_MEM_READ_ERROR || kind == SF_INJECT_MEM_WRITE_ERROR || kind == SF_INJECT_HOST_DMA_ERROR) {
    BufRef br;
    if (sf_status s = get_buffer(buf, &br)) return s;
    if (offset > br.b->size || size == 0 || size > br.b->size - offset)
      return fail(SF_ERR_OUT_OF_RANGE, "injection range outside the buffer");
    addr = br.b->addr + offset;
  }
  std::lock_guard<std::recursive_mutex> g(d->mu);
  return d->be->inject(kind, addr, size);
}

}  // extern "C"

// shared with c_api of the profiling module
namespace sf {
std::shared_ptr<DeviceObj> lookup_device(sf_device_t h) { return get_dev(h); }
void pump_device(DeviceObj &d) { pump_all(d); }
}  // namespace sf
