# SilicaFlux.OS — system runtime and HPC software enablement (Project 30)

**Aureom.AI / SilicaFlux-HPC** · directory `runtime/silicaflux/`

A host software stack that controls SilicaFlux devices, submits vector and tensor workloads, moves data, reads results
and diagnoses failures — built on the **real** command ABIs and the **unmodified** RTL of the SilicaFlux projects.

```
APPLICATION                examples/, tools/silicaflux (CLI), your program
SILICAFLUX COMPUTE API     sf_vector_add/mul/fma/axpy/dot, sf_tensor_gemm, sf_buffer_copy      (C ABI 1.0)
KERNEL RUNTIME             devices, in-order queues, results, timeouts, interruption, tracing
COMMAND & MEMORY MANAGER   device-memory allocator, buffer ownership, command lowering
HOST TRANSPORT BACKEND     cpu  |  rtl-cc (SFRQ rings + mailbox)  |  HostLink (P25 driver: SQ/CQ + DMA)
HARDWARE / RTL SIMULATION  CPU reference | Verilated P21 ControlCore system | Verilated P25 HostLink device | VFIO
```

> **Status — read this first.** Everything executes either on the **CPU reference backend** or on **Verilator RTL
> simulations of the SilicaFlux RTL**; every result says which (`sf_cmd_result.exec_target`). **No SilicaFlux hardware
> exists**: the PCIe/VFIO backend compiles and is tested for the absent-device case only. Simulated cycle counts are
> RTL cycles against modelled memories, not silicon performance. Firmware integrity is CRC32 only (no
> authentication). Details: [docs/12](docs/12_LIMITATIONS_AND_FINDINGS.md).

## What runs

| Device | What it is | Operations | Status |
|---|---|---|---|
| `cpu` | CPU reference implementation (independent, bit-exact contracts) | vector F32/I32, dot, GEMM INT32 & requantised INT8, copy | runs |
| `rtl-cc` | Verilated **P21 ControlCore** (RV32IM + runtime firmware 2.0) + **HPC M08** FP32 vector tile + **TENSORCORE 08** INT8 tensor unit | all of the above on the RTL engines; 64 hardware counters; RAS; device timestamps; firmware self-test | runs |
| `rtl-hostlink` | Verilated **P25 HostLink** PCIe front end + SilicaFlux-V tile, behind a PCIe/IOMMU host model | INT8→INT32 GEMM on the RTL tensor engine (host-assisted operand layout), DMA, 10 hardware counters | runs |
| `pcie:<BDF>` | physical HostLink function via Linux VFIO | same as `rtl-hostlink` | compiles; **no hardware** |

## Results (all reproducible from this directory; logs in `reports/`)

| Check | Result |
|---|---|
| Independent FP32 reference vs host FPU (4 rounding modes) and vs binary128 (RMM) | 1 200 000 + 200 000 operations, **0 mismatches** |
| C API on the CPU backend (handles, ownership, permissions, queues, interruption, all kernels) | **378 / 378 checks** |
| RTL ControlCore — kernels: FP32 add/mul/fma/axpy in 5 rounding modes incl. inf/NaN/subnormals (values **and** IEEE flags), INT32, chained dot products, INT32 & requantised INT8 GEMMs, exact counters, differential vs CPU | **bit-exact**, 321 / 321 checks |
| RTL ControlCore — faults, recovery, compatibility, lost device | invalid commands, DMA failures, host & device timeouts, reset during execution, RAS warning/fatal, interruption, full reset, stock/ABI-2/corrupted firmware refused, unresponsive device → full reset: **all pass** |
| P21 firmware self-test under the runtime firmware, on the RTL | **231 / 231 checks** |
| RTL HostLink — DMA (unaligned edges), GEMM (incl. K = 1500 with engine accumulation), PCIe/IOMMU fault, queue full, timeout, resets, counters, marked CPU fallback | **103 / 103 checks** |
| End-to-end 10-step GEMM flow on **every available backend** | cpu, rtl-cc, rtl-hostlink: **PASS**; physical hardware: none discovered |
| Examples (vector ops, matmul, heat-equation stencil, quantised MLP, mixed CPU/accelerator) | pass on cpu and rtl-cc; matmul / mixed on rtl-hostlink; MLP correctly refused there (no requantisation) |
| Firmware images | rebuilt byte-identical to `firmware/prebuilt/` |
| Whole suite from a clean checkout | configure + build 41 s; **27 / 27 ctest tests, 1 035 checks, 0 failures** (49.5 s, `-j 4`) |

Full report: **[reports/E2E_EXECUTION_REPORT.md](reports/E2E_EXECUTION_REPORT.md)**.

## Quick start

```bash
sudo apt-get install -y cmake ninja-build python3 verilator gcc-riscv64-unknown-elf
```

```bash
cmake -S runtime/silicaflux -B build -G Ninja && cmake --build build
```

```bash
ctest --test-dir build -j 4 --output-on-failure
```

```bash
./build/silicaflux info
```

```bash
./build/silicaflux run gemm --device rtl-cc --m 16 --n 16 --k 64
```

```bash
./build/silicaflux counters --device rtl-cc --workload gemm:16x16x64
```

```bash
./build/example_stencil rtl-cc
```

Without Verilator the build still produces the library, CLI, examples and CPU tests (`-DSF_ENABLE_RTL_CC=OFF
-DSF_ENABLE_RTL_HOSTLINK=OFF`); without a RISC-V compiler the prebuilt firmware images are used.

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit, readiness of each dependency | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| 2 | Layered architecture, simulation backend first | [docs/01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md), `src/` |
| 3 | Modern C++ runtime, C ABI | C++17 `src/`, C99 [`include/silicaflux/silicaflux.h`](include/silicaflux/silicaflux.h), [docs/03](docs/03_C_ABI.md) |
| 4 | Device management; simulator identifies itself | `sf_get_device_*`, `sf_device_open/close/reset/get_status/selftest`; `kind`, `is_simulator`, `exec_target` |
| 5 | Memory API: ownership, alignment, failure, lifetime, sync, permissions, DMA mapping | `sf_buffer_*`, [docs/02 §3](docs/02_API_GUIDE.md) |
| 6 | Queues on the real ABI, no ring overwrite, ordering | `sf_queue_*`, SFRQ rings [docs/07](docs/07_FIRMWARE_RQ_ABI.md), HostLink SQ/CQ |
| 7 | Compute API on real commands, reject unsupported | `sf_vector_*`, `sf_tensor_gemm`, [docs/04](docs/04_KERNELS.md) |
| 8 | CPU reference backend, marked | `src/backends/cpu`, `src/ref`, `SF_EXEC_CPU_REFERENCE` / `SF_EXEC_CPU_FALLBACK` |
| 9 | RTL simulator backend (submit, transfer, advance, completion, outputs, counters) | `src/backends/rtl_cc`, `src/backends/hostlink` + `hl_sim_transport.cpp` |
| 10 | Physical backend, legitimate host access, DMA isolation | `hl_vfio_transport.cpp` (VFIO, IOMMU), [docs/09](docs/09_HARDWARE_BACKEND.md) |
| 11 | ControlCore firmware: commands, DMA, dispatch, errors, counters, status/reset, ABI versions | `firmware/` ([docs/07](docs/07_FIRMWARE_RQ_ABI.md)) |
| 12 | Kernel library (add, mul, FMA, dot, INT8 GEMM, INT32 output, quantised GEMM); no compiler claim | [docs/04](docs/04_KERNELS.md) |
| 13 | Compiler integration path | [docs/10](docs/10_COMPILER_ROADMAP.md) |
| 14 | Profiling: cycles, vector ops, MACs, bytes, stalls, SRAM contention, queue delays, RAS; traces; separate clocks | `sf_device_read_counters`, `sf_device_perf_summary`, `sf_trace_*`, [docs/06](docs/06_PROFILING.md) |
| 15 | Scientific examples with independent references | `examples/` (vector ops, matmul, stencil, INT8 MLP, mixed CPU/accelerator) |
| 16 | CLI: info, selftest, run, benchmark, counters, errors | `tools/silicaflux_cli.cpp` |
| 17 | Fault and recovery behaviour, never hang | [docs/11](docs/11_FAULTS_AND_RECOVERY.md), `tests/` |
| 18 | End-to-end test on every backend | `tests/e2e_gemm.cpp`, [reports/E2E_EXECUTION_REPORT.md](reports/E2E_EXECUTION_REPORT.md) |
| 19 | CMake, versioned headers, unit/integration tests, CI, docs, examples, benchmark script, compatibility matrix | `CMakeLists.txt`, `tests/`, `ci/github-actions.yml`, `docs/`, `tools/run_benchmarks.sh`, [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md), [docs/08](docs/08_BUILD_AND_RELEASE.md) |

## Layout

```
include/silicaflux/silicaflux.h   public C ABI 1.0
src/core/        runtime (devices, buffers, queues), compute API, CPU execution, profiling
src/ref/         independent integer-only FP32 + kernel references
src/backends/    cpu/  rtl_cc/ (harness + backend)  hostlink/ (backend, sim + VFIO transports)  registry.cpp
firmware/        SFRQ ABI header, runtime firmware (main_rt.c, rq.c), prebuilt images + SHA256SUMS
third_party/     P21 ControlCore and P25 HostLink, vendored unmodified (SHA256SUMS, PROVENANCE.md)
tools/           silicaflux CLI, benchmark runner + report, trace converter
tests/           unit, RTL, fault, end-to-end         examples/   five reproducible examples
docs/            00 audit … 12 limitations, COMPATIBILITY  reports/  results of the final run
ci/              GitHub Actions workflow
```
