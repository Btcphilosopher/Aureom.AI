# Third-party (SilicaFlux repository) sources — provenance

Copied **unmodified** from the archives in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` of
`btcphilosopher/Aureom.AI` (snapshot 2026-11-10). Build outputs, reports and FPGA artefacts of those projects were not
copied. `SHA256SUMS` lists every vendored file; verify with `sha256sum -c SHA256SUMS` from this directory.

| Directory | Archive | Archive SHA-256 | Contents copied |
|---|---|---|---|
| `controlcore/` | `silicaflux-controlcore.zip` (Project 21) | `39b5b8e374a4a6d5c2dbd4be9048e907400e0a323625e3d21e462b17faecf530` | `README.md`, `rtl/`, `integration/`, `firmware/` (sources; no `build/`), `third_party/` (its own vendored RTL and drivers: SilicaFlux-V, MCU-I, SRAM library, DataFabric, HPC M04/M05/M08, TENSORCORE 02–08), `config/`, `scripts/`, `docs/`, `tb/` |
| `hostlink/` | `silicaflux-hostlink-project25.zip` (Project 25) | `bfb5bab2671630fb58f90df96d6a97f041b0dc3652bc6a676d06764f6db81b96` | `README.md`, `rtl/`, `sw/`, `generated/`, `abi/`, `docs/`, `third_party/`, `tb/cosim/` |

Licensing and authorship are those of the originating projects (Aureom.AI / SilicaFlux-HPC).
