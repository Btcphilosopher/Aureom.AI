// SilicaFlux HostLink -- transaction-level host / endpoint model (see sfh_sim.h)
#include "sfh_sim.h"

#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "Vsfh_device_top.h"
#include "sfh_driver.h"
#include "verilated.h"
#include "verilated_vcd_c.h"

double sc_time_stamp() { return 0; }

static std::string fmt(const char *f, ...) {
  char b[512];
  va_list ap;
  va_start(ap, f);
  vsnprintf(b, sizeof b, f, ap);
  va_end(ap);
  return b;
}

SfhSim::SfhSim(const SimCfg &c) : cfg(c), rng(c.seed) {
  ctx_ = std::make_unique<VerilatedContext>();
  ctx_->randReset(0);
  if (cfg.trace) ctx_->traceEverOn(true);
  top = new Vsfh_device_top{ctx_.get()};
  if (cfg.trace) {
    vcd_ = new VerilatedVcdC;
    top->trace(vcd_, 99);
    vcd_->open(cfg.trace_file.c_str());
  }
  top->clk = 0;
  top->ep_rst_n = 0;
  drive_inputs();
  top->eval();
  in_reset_ = true;
  tick(8);
  top->ep_rst_n = 1;
  in_reset_ = false;
  tick(8);
}

SfhSim::~SfhSim() {
  if (vcd_) { vcd_->close(); delete vcd_; }
  top->final();
  delete top;
  for (auto &a : allocs_) free(a.first);
}

// ============================================================================ time
void SfhSim::tick(unsigned n) {
  for (unsigned i = 0; i < n; i++) {
    sample_and_update();
    top->clk = 1;
    top->eval();
    if (vcd_) vcd_->dump(cycle_ * 2 + 1);
    cycle_++;
    apply_posted();
    drive_inputs();
    top->clk = 0;
    top->eval();
    if (vcd_) vcd_->dump(cycle_ * 2);
  }
}

// ============================================================================ IOMMU / host memory
SfhSim::Buf SfhSim::dma_alloc(size_t bytes) {
  size_t sz = (bytes + 4095) & ~(size_t)4095;
  uint8_t *p = (uint8_t *)aligned_alloc(4096, sz);
  memset(p, 0, sz);
  allocs_[p] = sz;
  Buf b{p, next_iova_, sz};
  for (size_t o = 0; o < sz; o += 4096) iommu_[(next_iova_ + o) >> 12] = p + o;
  next_iova_ += sz + 4096;          // unmapped guard page between allocations
  return b;
}

void SfhSim::dma_free(const Buf &b) {
  for (size_t o = 0; o < b.size; o += 4096) iommu_.erase((b.iova + o) >> 12);
  allocs_.erase(b.va);
  free(b.va);
}

void SfhSim::iommu_unmap_page(uint64_t iova) { iommu_.erase(iova >> 12); }

uint8_t *SfhSim::xlate(uint64_t iova) {
  auto it = iommu_.find(iova >> 12);
  return it == iommu_.end() ? nullptr : it->second + (iova & 4095);
}

uint8_t SfhSim::host_check(uint64_t addr, unsigned bytes, bool write) {
  for (uint64_t a = addr & ~4095ull; a < addr + bytes; a += 4096) {
    if (!xlate(a)) {
      faults.push_back({addr, write, cycle_});
      return 3;   // DECERR: IOMMU fault -> unsupported request at the root complex
    }
  }
  for (auto &e : err_ranges_) {
    if (e.write == write && e.count != 0 && addr < e.hi && addr + bytes > e.lo) {
      if (e.count > 0) e.count--;
      return e.resp;
    }
  }
  return 0;
}

void SfhSim::inject_error(uint64_t lo, uint64_t hi, bool write, int count, uint8_t resp) {
  err_ranges_.push_back({lo, hi, write, count, resp});
}

// ============================================================================ posted writes
void SfhSim::apply_posted() {
  auto apply = [&](const Posted &p) {
    if (p.msi) {
      irq_pending |= 1u << p.vector;
      irq_msgs++;
      irq_log.push_back({cycle_, p.vector});
      return;
    }
    for (size_t i = 0; i < p.data.size(); i++) {
      uint8_t *d = xlate(p.addr + i);
      if (d) *d = p.data[i];
    }
  };
  if (!cfg.relaxed_ordering) {
    while (!posted_.empty() && posted_.front().vis <= cycle_) {
      apply(posted_.front());
      posted_.pop_front();
    }
  } else {
    for (size_t i = 0; i < posted_.size();) {
      // an MSI (no relaxed-ordering attribute) never passes older posted writes
      if (posted_[i].vis <= cycle_ && (!posted_[i].msi || i == 0)) {
        apply(posted_[i]);
        posted_.erase(posted_.begin() + (long)i);
      } else {
        i++;
      }
    }
  }
}

void SfhSim::flush_posted() {
  for (auto &p : posted_) p.vis = 0;
  bool r = cfg.relaxed_ordering;
  cfg.relaxed_ordering = false;
  apply_posted();
  cfg.relaxed_ordering = r;
}

// ============================================================================ per-cycle model
void SfhSim::sample_and_update() {
  Vsfh_device_top *t = top;
  if (in_reset_) return;

  // ------------------------------------------------------------ BAR master BFM
  if (bar_.active) {
    if (t->s_bar_awvalid && t->s_bar_awready) bar_.aw_done = true;
    if (t->s_bar_wvalid && t->s_bar_wready) bar_.w_sent++;
    if (t->s_bar_bvalid && t->s_bar_bready) {
      bar_.done = true;
      bar_.bresp = t->s_bar_bresp;
      bar_.id_ok = (t->s_bar_bid == bar_.id);
    }
    if (t->s_bar_arvalid && t->s_bar_arready) bar_.ar_done = true;
    if (t->s_bar_rvalid && t->s_bar_rready) {
      bar_.rdata.push_back(t->s_bar_rdata);
      bar_.rresp.push_back(t->s_bar_rresp);
      if (t->s_bar_rid != bar_.id) bar_.id_ok = false;
      bool last_expected = bar_.rdata.size() == (size_t)bar_.len + 1;
      if ((bool)t->s_bar_rlast != last_expected) bar_.rlast_ok = false;
      if (last_expected || t->s_bar_rlast) bar_.done = true;
    }
  }

  // ------------------------------------------------------------ host AXI: stability checks
  if (p_arv_ && !p_arh_ && (!t->m_host_arvalid || t->m_host_araddr != p_araddr_ || t->m_host_arlen != p_arlen_))
    violations.push_back(fmt("AR changed/dropped before handshake @%llu", (unsigned long long)cycle_));
  if (p_awv_ && !p_awh_ && (!t->m_host_awvalid || t->m_host_awaddr != p_awaddr_ || t->m_host_awlen != p_awlen_))
    violations.push_back(fmt("AW changed/dropped before handshake @%llu", (unsigned long long)cycle_));
  if (p_wv_ && !p_wh_ && (!t->m_host_wvalid || t->m_host_wdata != p_wdata_))
    violations.push_back(fmt("W changed/dropped before handshake @%llu", (unsigned long long)cycle_));

  bool ar_hs = t->m_host_arvalid && ar_ready_;
  bool aw_hs = t->m_host_awvalid && aw_ready_;
  bool w_hs = t->m_host_wvalid && w_ready_;
  bool r_hs = r_valid_ && t->m_host_rready;
  bool b_hs = b_valid_ && t->m_host_bready;
  p_arv_ = t->m_host_arvalid; p_arh_ = ar_hs; p_araddr_ = t->m_host_araddr; p_arlen_ = t->m_host_arlen;
  p_awv_ = t->m_host_awvalid; p_awh_ = aw_hs; p_awaddr_ = t->m_host_awaddr; p_awlen_ = t->m_host_awlen;
  p_wv_ = t->m_host_wvalid; p_wh_ = w_hs; p_wdata_ = t->m_host_wdata;

  auto check_burst = [&](const char *ch, uint64_t a, unsigned len, unsigned size, unsigned burst, unsigned id) {
    unsigned beats = len + 1;
    if (size != 3) violations.push_back(fmt("%s size %u != 3", ch, size));
    if (burst != 1) violations.push_back(fmt("%s burst %u != INCR", ch, burst));
    if (id != 0) violations.push_back(fmt("%s id %u", ch, id));
    if (a & 7) violations.push_back(fmt("%s unaligned %llx", ch, (unsigned long long)a));
    if (beats > 16) violations.push_back(fmt("%s burst too long (%u)", ch, beats));
    if ((a & 4095) + beats * 8ull > 4096)
      violations.push_back(fmt("%s burst crosses 4 KiB: addr %llx beats %u", ch, (unsigned long long)a, beats));
  };

  // ------------------------------------------------------------ host AXI: read
  if (ar_hs) {
    check_burst("AR", t->m_host_araddr, t->m_host_arlen, t->m_host_arsize, t->m_host_arburst, t->m_host_arid);
    flush_posted();   // PCIe: a read request never passes earlier posted writes
    RdJob j{t->m_host_araddr, (unsigned)t->m_host_arlen + 1u, 0, cycle_ + (uint64_t)cfg.rd_latency, 0};
    j.resp = host_check(j.addr, j.beats * 8, false);
    rd_q_.push_back(j);
    host_bursts++;
  }
  if (r_hs) {
    RdJob &j = rd_q_.front();
    j.sent++;
    host_rd_beats++;
    r_valid_ = false;
    if (j.sent == j.beats) rd_q_.pop_front();
  }
  // ------------------------------------------------------------ host AXI: write
  if (aw_hs) {
    check_burst("AW", t->m_host_awaddr, t->m_host_awlen, t->m_host_awsize, t->m_host_awburst, t->m_host_awid);
    wr_q_.push_back(WrJob{t->m_host_awaddr, (unsigned)t->m_host_awlen + 1u, 0, {}, true, 0, false});
    host_bursts++;
  }
  if (w_hs) {
    if (wr_q_.empty()) {
      violations.push_back("W beat without AW");
    } else {
      WrJob &j = wr_q_.front();
      if (t->m_host_wstrb != 0xFF) violations.push_back(fmt("WSTRB %02x", t->m_host_wstrb));
      j.data.push_back(t->m_host_wdata);
      j.got++;
      host_wr_beats++;
      bool last = (j.got == j.beats);
      if ((bool)t->m_host_wlast != last) violations.push_back(fmt("WLAST wrong at beat %u/%u", j.got, j.beats));
      if (last) {
        j.b_at = cycle_ + (uint64_t)cfg.wr_latency;
        b_q_.push_back(j);
        wr_q_.pop_front();
      }
    }
  }
  if (b_hs) {
    b_valid_ = false;
    b_q_.pop_front();
  }

  // ------------------------------------------------------------ interrupts
  if (t->irq_valid && irq_ready_) {
    unsigned d = (unsigned)cfg.msi_delay;
    posted_.push_back(Posted{post_seq_++, 0, cycle_ + d, {}, true, (unsigned)t->irq_vector});
  }

  // ------------------------------------------------------------ external fabric master (M1)
  if (ext_.active && !ext_.issued && t->x_req_valid && t->x_req_ready) ext_.issued = true;
  else if (ext_.active && ext_.issued && t->x_rsp_valid && t->x_rsp_ready) {
    ext_.done = true;
    ext_.rdata = t->x_rsp_rdata;
    ext_.err = t->x_rsp_error;
  }
}

void SfhSim::drive_bar() {
  Vsfh_device_top *t = top;
  bool bw = bar_.active && bar_.write, br = bar_.active && !bar_.write;
  t->s_bar_awvalid = bw && !bar_.aw_done;
  t->s_bar_awid = bar_.id;
  t->s_bar_awaddr = bar_.off;
  t->s_bar_awlen = bar_.len;
  t->s_bar_awsize = bar_.size;
  t->s_bar_awburst = 1;
  t->s_bar_wvalid = bw && bar_.w_sent < (unsigned)bar_.len + 1;
  t->s_bar_wdata = bar_.w_sent < bar_.wdata.size() ? bar_.wdata[bar_.w_sent] : 0;
  t->s_bar_wstrb = bar_.strb;
  t->s_bar_wlast = bar_.w_sent == bar_.len;
  t->s_bar_bready = 1;
  t->s_bar_arvalid = br && !bar_.ar_done;
  t->s_bar_arid = bar_.id;
  t->s_bar_araddr = bar_.off;
  t->s_bar_arlen = bar_.len;
  t->s_bar_arsize = bar_.size;
  t->s_bar_arburst = 1;
  t->s_bar_rready = 1;
}

void SfhSim::drive_inputs() {
  Vsfh_device_top *t = top;
  drive_bar();

  // ------------------------------------------------------------ host AXI slave
  ar_ready_ = !stall_host && chance(cfg.ar_ready_pct);
  aw_ready_ = !stall_host && chance(cfg.aw_ready_pct);
  w_ready_ = !wr_q_.empty() && chance(cfg.w_ready_pct);
  if (!r_valid_ && !rd_q_.empty()) {
    RdJob &j = rd_q_.front();
    if (cycle_ >= j.ready_at && !stall_host && chance(cfg.r_valid_pct)) {
      uint64_t a = j.addr + 8ull * j.sent;
      uint64_t v = 0;
      if (j.resp == 0) {
        for (int b = 0; b < 8; b++) {
          uint8_t *p = xlate(a + b);
          v |= (uint64_t)(p ? *p : 0) << (8 * b);
        }
      }
      r_valid_ = true;
      r_data_ = v;
      r_resp_ = j.resp;
      r_last_ = (j.sent + 1 == j.beats);
    }
  }
  if (!b_valid_ && !b_q_.empty()) {
    WrJob &j = b_q_.front();
    if (cycle_ >= j.b_at && !stall_host && chance(cfg.b_valid_pct)) {
      b_valid_ = true;
      b_resp_ = host_check(j.addr, j.beats * 8, true);
      if (b_resp_ == 0) {
        Posted p{post_seq_++, j.addr, 0, {}, false, 0};
        for (auto w : j.data)
          for (int b = 0; b < 8; b++) p.data.push_back((uint8_t)(w >> (8 * b)));
        int span = cfg.post_delay_max - cfg.post_delay_min;
        p.vis = cycle_ + (uint64_t)cfg.post_delay_min + (span > 0 ? rng() % (uint64_t)(span + 1) : 0);
        posted_.push_back(p);
      }
    }
  }
  t->m_host_arready = ar_ready_;
  t->m_host_awready = aw_ready_;
  t->m_host_wready = w_ready_;
  t->m_host_rvalid = r_valid_;
  t->m_host_rdata = r_data_;
  t->m_host_rresp = r_resp_;
  t->m_host_rlast = r_last_;
  t->m_host_rid = 0;
  t->m_host_bvalid = b_valid_;
  t->m_host_bresp = b_resp_;
  t->m_host_bid = 0;

  // ------------------------------------------------------------ interrupts
  irq_ready_ = irq_ready_override >= 0 ? (irq_ready_override != 0) : chance(cfg.irq_ready_pct);
  t->irq_ready = irq_ready_;

  // ------------------------------------------------------------ external master
  ext_run();
  t->x_req_valid = ext_.active && !ext_.issued;
  t->x_req_write = ext_.write;
  t->x_req_addr = ext_.addr;
  t->x_req_wdata = ext_.wdata;
  t->x_req_wstrb = 0xF;
  t->x_rsp_ready = ext_.active && ext_.issued;
}

// random background traffic of the second DataFabric master, self-checking
void SfhSim::ext_run() {
  if (ext_.active && ext_.done) {
    if (!ext_.backdoor) {
      ext_ops++;
      if (ext_.err) {
        ext_errors++;
        violations.push_back(fmt("ext master error at %08x", ext_.addr));
      } else if (ext_.write) {
        ext_shadow_[ext_.addr] = ext_.wdata;
      } else {
        auto it = ext_shadow_.find(ext_.addr);
        if (it != ext_shadow_.end() && it->second != ext_.rdata)
          violations.push_back(fmt("ext master read mismatch at %08x: %08x != %08x", ext_.addr, ext_.rdata,
                                   it->second));
      }
      ext_.active = false;
    }
  }
  if (!ext_.active && cfg.ext_traffic_pct > 0 && cfg.ext_size >= 4 && !in_reset_ && chance(cfg.ext_traffic_pct)) {
    ext_ = ExtOp{};
    ext_.active = true;
    ext_.write = rng() & 1;
    ext_.addr = cfg.ext_base + (uint32_t)((rng() % (cfg.ext_size / 4)) * 4);
    ext_.wdata = (uint32_t)rng();
  }
}

// Backdoor access through DataFabric master M1 (independent of HostLink).
// Background traffic is suspended so that a request already presented to the
// fabric is never replaced before it is accepted (SFB2 rule R2).
uint32_t SfhSim::fabric_op(bool write, uint32_t addr, uint32_t v, bool *err) {
  int pct = cfg.ext_traffic_pct;
  cfg.ext_traffic_pct = 0;
  while (ext_.active) tick();
  ext_ = ExtOp{};
  ext_.active = true; ext_.backdoor = true; ext_.write = write; ext_.addr = addr; ext_.wdata = v;
  for (int i = 0; i < 100000 && !ext_.done; i++) tick();
  if (!ext_.done) violations.push_back(fmt("fabric backdoor access %08x hung", addr));
  if (err) *err = ext_.err;
  uint32_t r = ext_.rdata;
  ext_.active = false;
  cfg.ext_traffic_pct = pct;
  return r;
}
uint32_t SfhSim::fabric_read32(uint32_t addr, bool *err) { return fabric_op(false, addr, 0, err); }
void SfhSim::fabric_write32(uint32_t addr, uint32_t v, bool *err) { fabric_op(true, addr, v, err); }

// ============================================================================ BAR accesses
void SfhSim::bar_run() {
  for (int i = 0; i < 200000 && !bar_.done; i++) tick();
  if (!bar_.done) violations.push_back(fmt("BAR access to %03x hung", bar_.off));
  BarOp keep = bar_;
  bar_ = BarOp{};
  bar_.rdata = keep.rdata;
  bar_.rresp = keep.rresp;
  bar_.bresp = keep.bresp;
  bar_.id_ok = keep.id_ok;
  bar_.rlast_ok = keep.rlast_ok;
  drive_bar();
  top->eval();
}

uint32_t SfhSim::bar_read(uint32_t off) {
  bool lok, iok;
  std::vector<uint32_t> d;
  auto r = bar_read_raw(off, 0, 2, &d, (uint8_t)(rng() & 15), &lok, &iok);
  if (!iok || !lok) violations.push_back(fmt("BAR read %03x: bad RID/RLAST", off));
  if (r.empty() || r[0] != 0) {
    bar_slverr_reads++;
    return 0xFFFFFFFFu;     // completer abort / UR -> all-ones to the CPU
  }
  return d[0];
}

void SfhSim::bar_write(uint32_t off, uint32_t v, uint8_t strb) {
  bool iok;
  uint8_t r = bar_write_raw(off, 0, 2, {v}, strb, (uint8_t)(rng() & 15), &iok);
  if (!iok) violations.push_back(fmt("BAR write %03x: bad BID", off));
  if (r != 0) bar_slverr_writes++;   // invisible to a real CPU (posted write)
}

std::vector<uint8_t> SfhSim::bar_read_raw(uint32_t off, uint8_t len, uint8_t size, std::vector<uint32_t> *data,
                                          uint8_t id, bool *rlast_ok, bool *id_ok) {
  bar_ = BarOp{};
  bar_.active = true; bar_.write = false; bar_.off = off; bar_.len = len; bar_.size = size; bar_.id = id;
  drive_bar();
  top->eval();
  bar_run();
  if (data) *data = bar_.rdata;
  if (rlast_ok) *rlast_ok = bar_.rlast_ok;
  if (id_ok) *id_ok = bar_.id_ok;
  return bar_.rresp;
}

uint8_t SfhSim::bar_write_raw(uint32_t off, uint8_t len, uint8_t size, const std::vector<uint32_t> &data,
                              uint8_t strb, uint8_t id, bool *id_ok) {
  bar_ = BarOp{};
  bar_.active = true; bar_.write = true; bar_.off = off; bar_.len = len; bar_.size = size; bar_.id = id;
  bar_.strb = strb; bar_.wdata = data;
  drive_bar();
  top->eval();
  bar_run();
  if (id_ok) *id_ok = bar_.id_ok;
  return bar_.bresp;
}

// ============================================================================ interrupts
int SfhSim::wait_irq(uint32_t mask, uint64_t timeout_us, uint32_t *fired) {
  uint64_t limit = cycle_ + (uint64_t)(timeout_us * kMHz) + 1;
  while (!(irq_pending & mask)) {
    if (cycle_ >= limit) return -1;
    tick();
  }
  *fired = irq_pending & mask;
  irq_pending &= ~mask;
  return 0;
}

bool SfhSim::irq_level() { return top->irq_level; }

// ============================================================================ endpoint reset
void SfhSim::ep_reset(unsigned cycles) {
  top->ep_rst_n = 0;
  in_reset_ = true;
  // the endpoint aborts its in-flight AXI transactions; nothing more reaches the host
  rd_q_.clear(); wr_q_.clear(); b_q_.clear();
  r_valid_ = b_valid_ = false;
  bar_ = BarOp{};
  ext_ = ExtOp{};
  p_arv_ = p_awv_ = p_wv_ = false;
  tick(cycles);
  top->ep_rst_n = 1;
  in_reset_ = false;
  tick(8);
}

// ============================================================================ C backend ops
static uint32_t be_rd(void *c, uint32_t off) { return ((SfhSim *)c)->bar_read(off); }
static void be_wr(void *c, uint32_t off, uint32_t v) { ((SfhSim *)c)->bar_write(off, v); }
static int be_alloc(void *c, size_t n, sfh_dma_buf *o) {
  SfhSim::Buf b = ((SfhSim *)c)->dma_alloc(n);
  o->va = b.va; o->iova = b.iova; o->size = b.size; o->priv = nullptr;
  return 0;
}
static void be_free(void *c, sfh_dma_buf *b) {
  ((SfhSim *)c)->dma_free(SfhSim::Buf{(uint8_t *)b->va, b->iova, b->size});
  b->va = nullptr;
}
static int be_wait(void *c, uint32_t m, uint64_t t, uint32_t *f) { return ((SfhSim *)c)->wait_irq(m, t, f); }
static void be_relax(void *c) { ((SfhSim *)c)->tick(4); }
static uint64_t be_now(void *c) { return ((SfhSim *)c)->now_us(); }

static const sfh_backend_ops kOps = {be_rd, be_wr, be_alloc, be_free, be_wait, be_relax, be_now};
const sfh_backend_ops *sfh_sim_backend_ops() { return &kOps; }
