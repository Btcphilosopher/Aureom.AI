// SilicaFlux HostLink -- transaction-level host / endpoint model around the
// Verilated sfh_device_top.  It stands in for "PCIe endpoint IP + root complex
// + IOMMU + host memory + CPU MMIO" at the AXI boundary of sfh_ep_axi_shell.
// See docs/06_SIM_BACKEND.md.
#pragma once
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <random>
#include <string>
#include <vector>

class Vsfh_device_top;
class VerilatedVcdC;
class VerilatedContext;

struct SimCfg {
  uint64_t seed = 1;
  // host-side AXI behaviour (percent of cycles the model is ready/valid)
  int ar_ready_pct = 100, aw_ready_pct = 100, w_ready_pct = 100, r_valid_pct = 100, b_valid_pct = 100;
  int rd_latency = 24;          // cycles from AR accept to first R beat (PCIe read round trip)
  int wr_latency = 6;           // cycles from WLAST to B
  int irq_ready_pct = 100;      // endpoint accepting interrupt messages
  // posted-write visibility: delay in cycles before a write is visible to the CPU
  int post_delay_min = 0, post_delay_max = 0;
  bool relaxed_ordering = false;   // writes may become visible out of order
  int msi_delay = 2;
  // second DataFabric master (contention agent)
  int ext_traffic_pct = 0;
  uint32_t ext_base = 0, ext_size = 0;
  bool trace = false;
  std::string trace_file = "sfh_trace.vcd";
};

struct HostFault { uint64_t iova; bool write; uint64_t cycle; };

class SfhSim {
 public:
  explicit SfhSim(const SimCfg &cfg);
  ~SfhSim();

  // ---------------------------------------------------------------- time
  void tick(unsigned n = 1);
  uint64_t cycle() const { return cycle_; }
  static constexpr double kMHz = 250.0;   // assumed core clock for us conversions
  uint64_t now_us() const { return (uint64_t)(cycle_ / kMHz); }

  // ---------------------------------------------------------------- BAR (CPU MMIO through the endpoint)
  uint32_t bar_read(uint32_t off);                 // SLVERR -> 0xFFFFFFFF (completer abort)
  void bar_write(uint32_t off, uint32_t v, uint8_t strb = 0xF);
  // raw AXI4 BAR access for protocol tests; returns resp of each beat
  std::vector<uint8_t> bar_read_raw(uint32_t off, uint8_t len, uint8_t size, std::vector<uint32_t> *data,
                                    uint8_t id, bool *rlast_ok, bool *id_ok);
  uint8_t bar_write_raw(uint32_t off, uint8_t len, uint8_t size, const std::vector<uint32_t> &data,
                        uint8_t strb, uint8_t id, bool *id_ok);
  unsigned bar_slverr_reads = 0, bar_slverr_writes = 0;

  // ---------------------------------------------------------------- host memory behind an IOMMU
  struct Buf { uint8_t *va; uint64_t iova; size_t size; };
  Buf dma_alloc(size_t bytes);
  void dma_free(const Buf &b);
  void iommu_unmap_page(uint64_t iova);            // fault injection
  std::vector<HostFault> faults;

  // ---------------------------------------------------------------- interrupts
  uint32_t irq_pending = 0;                        // vectors delivered, not yet consumed
  uint64_t irq_msgs = 0;
  std::vector<std::pair<uint64_t, unsigned>> irq_log;  // (cycle, vector)
  int wait_irq(uint32_t mask, uint64_t timeout_us, uint32_t *fired);
  bool irq_level();

  // ---------------------------------------------------------------- failure injection
  struct ErrRange { uint64_t lo, hi; bool write; int count; uint8_t resp; };
  void inject_error(uint64_t lo, uint64_t hi, bool write, int count = -1, uint8_t resp = 2);
  void clear_errors() { err_ranges_.clear(); }
  bool stall_host = false;       // stop accepting AR/AW (host-bus hang)
  int irq_ready_override = -1;   // -1: use cfg, 0: never ready, 1: always ready

  // ---------------------------------------------------------------- endpoint reset (hot reset / FLR)
  void ep_reset(unsigned cycles = 8);

  // ---------------------------------------------------------------- DataFabric backdoor via master M1
  uint32_t fabric_read32(uint32_t addr, bool *err = nullptr);
  void fabric_write32(uint32_t addr, uint32_t v, bool *err = nullptr);
  uint64_t ext_ops = 0, ext_errors = 0;

  // ---------------------------------------------------------------- checkers
  std::vector<std::string> violations;            // AXI / protocol violations seen
  uint64_t host_rd_beats = 0, host_wr_beats = 0, host_bursts = 0;
  uint64_t posted_pending() const { return posted_.size(); }
  void flush_posted();                             // make all posted writes visible

  SimCfg cfg;
  std::mt19937_64 rng;
  Vsfh_device_top *top = nullptr;

 private:
  bool chance(int pct) { return pct >= 100 || (int)(rng() % 100) < pct; }
  uint8_t *xlate(uint64_t iova);                    // IOMMU: nullptr if unmapped
  uint8_t host_check(uint64_t addr, unsigned bytes, bool write);
  void eval_half(bool clk);
  void drive_inputs();
  void drive_bar();
  uint32_t fabric_op(bool write, uint32_t addr, uint32_t v, bool *err);
  void sample_and_update();
  void apply_posted();

  std::unique_ptr<VerilatedContext> ctx_;
  VerilatedVcdC *vcd_ = nullptr;
  uint64_t cycle_ = 0;

  // IOMMU: page -> host page pointer
  std::map<uint64_t, uint8_t *> iommu_;
  std::map<uint8_t *, size_t> allocs_;
  uint64_t next_iova_ = 0x0000000100000000ull;
  std::vector<ErrRange> err_ranges_;

  // ---- BAR master BFM state
  struct BarOp {
    bool active = false, write = false;
    uint32_t off = 0; uint8_t len = 0, size = 2, strb = 0xF, id = 0;
    std::vector<uint32_t> wdata;
    bool aw_done = false; unsigned w_sent = 0;
    bool done = false; uint8_t bresp = 0; bool id_ok = true;
    std::vector<uint32_t> rdata; std::vector<uint8_t> rresp; bool rlast_ok = true;
    bool ar_done = false;
  } bar_;
  void bar_run();

  // ---- host AXI slave state
  struct RdJob { uint64_t addr; unsigned beats, sent; uint64_t ready_at; uint8_t resp; };
  struct WrJob { uint64_t addr; unsigned beats, got; std::vector<uint64_t> data; bool wlast_ok;
                 uint64_t b_at; bool b_ready_set; };
  std::deque<RdJob> rd_q_;
  std::deque<WrJob> wr_q_;            // AW accepted; front receives W beats
  std::deque<WrJob> b_q_;             // W complete, waiting for B
  bool r_valid_ = false, b_valid_ = false;
  uint64_t r_data_ = 0; uint8_t r_resp_ = 0; bool r_last_ = false;
  uint8_t b_resp_ = 0;
  bool ar_ready_ = false, aw_ready_ = false, w_ready_ = false, irq_ready_ = false;
  // previous-cycle values for stability checks
  bool p_arv_ = false, p_awv_ = false, p_wv_ = false, p_arh_ = false, p_awh_ = false, p_wh_ = false;
  uint64_t p_araddr_ = 0, p_awaddr_ = 0, p_wdata_ = 0; uint32_t p_arlen_ = 0, p_awlen_ = 0;

  // ---- posted write queue (host-side visibility)
  struct Posted { uint64_t seq, addr, vis; std::vector<uint8_t> data; bool msi; unsigned vector; };
  std::deque<Posted> posted_;
  uint64_t post_seq_ = 0;

  // ---- external fabric master
  struct ExtOp { bool active = false, write = false, issued = false, done = false, err = false;
                 uint32_t addr = 0, wdata = 0, rdata = 0; bool backdoor = false; };
  ExtOp ext_;
  std::map<uint32_t, uint32_t> ext_shadow_;
  void ext_run();

  bool in_reset_ = false;
};

// Backend ops for the C driver (sw/include/sfh_driver.h)
struct sfh_backend_ops;
const sfh_backend_ops *sfh_sim_backend_ops();
