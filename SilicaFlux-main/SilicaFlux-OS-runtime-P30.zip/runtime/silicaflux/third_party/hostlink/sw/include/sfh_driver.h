/*
 * SilicaFlux HostLink -- user-space driver library (backend independent).
 *
 * The same code drives the simulated device (sw/backends/sfh_backend_sim.cpp,
 * Verilated RTL + transaction-level host model) and real hardware through
 * Linux VFIO (sw/backends/sfh_backend_vfio.c).  Only the backend ops differ.
 *
 * Threading: one submitter thread per sfh_dev (no internal locking).
 * Ordering : see docs/02_DRIVER_ABI.md "Memory ordering"; the barriers used
 *            here are sfh_wmb()/sfh_rmb() below.
 */
#ifndef SFH_DRIVER_H
#define SFH_DRIVER_H

#include <stddef.h>
#include <stdint.h>
#include "silicaflux_hostlink_abi.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------------------------------------------------------- barriers */
/* Order normal-memory stores (SQE) before a later MMIO store (doorbell). */
static inline void sfh_wmb(void) {
#if defined(__x86_64__) || defined(__i386__)
  __asm__ __volatile__("sfence" ::: "memory");
#elif defined(__aarch64__)
  __asm__ __volatile__("dmb oshst" ::: "memory");
#else
  __atomic_thread_fence(__ATOMIC_SEQ_CST);
#endif
}
/* Order the read of the CQE phase dword before reads of the other fields and
 * of DMA'd data. */
static inline void sfh_rmb(void) {
#if defined(__x86_64__) || defined(__i386__)
  __asm__ __volatile__("lfence" ::: "memory");
#elif defined(__aarch64__)
  __asm__ __volatile__("dmb oshld" ::: "memory");
#else
  __atomic_thread_fence(__ATOMIC_SEQ_CST);
#endif
}

/* ---------------------------------------------------------------- backend */
struct sfh_dma_buf {
  void    *va;      /* CPU address */
  uint64_t iova;    /* device-visible address (IOMMU-mapped) */
  size_t   size;
  void    *priv;    /* backend private */
};

struct sfh_backend_ops {
  uint32_t (*mmio_read32)(void *ctx, uint32_t off);
  void     (*mmio_write32)(void *ctx, uint32_t off, uint32_t val);
  /* Allocate DMA-able, IOMMU-mapped, zeroed memory (alignment >= 4096). */
  int      (*dma_alloc)(void *ctx, size_t bytes, struct sfh_dma_buf *out);
  void     (*dma_free)(void *ctx, struct sfh_dma_buf *buf);
  /* Block until an interrupt message arrives on a vector in `mask`
   * (bit v = vector v).  Returns 0 and the fired vectors, or -1 on timeout. */
  int      (*wait_irq)(void *ctx, uint32_t mask, uint64_t timeout_us, uint32_t *fired);
  /* Called inside polling loops (sim: advances the clock). */
  void     (*relax)(void *ctx);
  uint64_t (*now_us)(void *ctx);
};

/* ---------------------------------------------------------------- device */
#ifndef SFH_IRQ_SLICE_US
#define SFH_IRQ_SLICE_US 200u     /* max sleep before re-polling the CQ */
#endif
struct sfh_dev {
  const struct sfh_backend_ops *ops;
  void      *ctx;
  uint32_t   version, hw_rev, caps, limits;
  uint32_t   devmem_base[2], devmem_size[2];
  unsigned   num_windows, num_vectors, max_dma_log2;
  struct sfh_dma_buf sq, cq;
  unsigned   sq_n, cq_n;           /* entries */
  unsigned   sq_tail;              /* driver copy of the doorbell value */
  unsigned   sq_head;              /* last device head seen in a CQE */
  unsigned   cq_head;              /* next CQE to consume */
  unsigned   cq_phase;             /* expected phase of the next CQE */
  unsigned   inflight;             /* submitted, not yet completed */
  uint32_t   next_txn;
  int        use_irq;              /* wait for CQ interrupts instead of polling */
  uint64_t   irq_waits, polls;     /* statistics */
};

enum {
  SFH_OK = 0,
  SFH_ERR_NODEV = -1,     /* ID/version mismatch */
  SFH_ERR_BUSY = -2,      /* SQ full */
  SFH_ERR_TIMEOUT = -3,
  SFH_ERR_CONFIG = -4,    /* device refused the configuration */
  SFH_ERR_NOMEM = -5,
  SFH_ERR_INVAL = -6,
  SFH_ERR_FATAL = -7,     /* device reports STATUS.FATAL */
};

static inline uint32_t sfh_rd(struct sfh_dev *d, uint32_t off) { return d->ops->mmio_read32(d->ctx, off); }
static inline void sfh_wr(struct sfh_dev *d, uint32_t off, uint32_t v) { d->ops->mmio_write32(d->ctx, off, v); }

int  sfh_open(struct sfh_dev *d, const struct sfh_backend_ops *ops, void *ctx);
int  sfh_reset(struct sfh_dev *d, uint64_t timeout_us);
int  sfh_set_window(struct sfh_dev *d, unsigned idx, uint64_t base, uint64_t size, uint32_t ctrl);
int  sfh_queues_alloc(struct sfh_dev *d, unsigned sq_log2, unsigned cq_log2);
void sfh_queues_free(struct sfh_dev *d);
int  sfh_enable(struct sfh_dev *d, uint32_t ctrl_extra);   /* ctrl_extra: FLUSH_ALL / STOP_ON_ERROR */
int  sfh_disable(struct sfh_dev *d, uint64_t timeout_us);  /* waits for STATUS.IDLE */
void sfh_irq_setup(struct sfh_dev *d, int use_irq);        /* INT_ENABLE + vectors */

/* Queue an entry without ringing the doorbell (batching); SFH_ERR_BUSY if full. */
int  sfh_push(struct sfh_dev *d, const struct sfh_sqe *e);
void sfh_ring(struct sfh_dev *d);                          /* sfh_wmb(); SQ_TAIL <- tail */
int  sfh_submit(struct sfh_dev *d, const struct sfh_sqe *e);
/* 1 = a completion was consumed into *out, 0 = none available. */
int  sfh_poll_cqe(struct sfh_dev *d, struct sfh_cqe *out);
int  sfh_wait_cqe(struct sfh_dev *d, struct sfh_cqe *out, uint64_t timeout_us);
/* submit + wait for that entry's completion (in-order queue) */
int  sfh_run(struct sfh_dev *d, struct sfh_sqe *e, struct sfh_cqe *out, uint64_t timeout_us);

/* Entry builders (zero all reserved fields). */
void sfh_sqe_nop(struct sfh_sqe *e, uint32_t flags);
void sfh_sqe_dma(struct sfh_sqe *e, uint32_t dir, uint64_t src, uint64_t dst, uint32_t len, uint32_t flags);
void sfh_sqe_gemm(struct sfh_sqe *e, uint32_t a_off, uint32_t b_off, uint32_t c_off, uint32_t k,
                  uint32_t te_flags, uint32_t flags);

/* Blocking helpers built on the queue (return CQE status or a negative SFH_ERR_*). */
int  sfh_dma_h2d(struct sfh_dev *d, uint64_t host_iova, uint32_t dev_addr, uint32_t len, uint64_t timeout_us);
int  sfh_dma_d2h(struct sfh_dev *d, uint32_t dev_addr, uint64_t host_iova, uint32_t len, uint64_t timeout_us);

void     sfh_perf_snapshot(struct sfh_dev *d);
uint64_t sfh_perf_read(struct sfh_dev *d, unsigned idx);    /* after sfh_perf_snapshot */

#ifdef __cplusplus
}
#endif
#endif /* SFH_DRIVER_H */
