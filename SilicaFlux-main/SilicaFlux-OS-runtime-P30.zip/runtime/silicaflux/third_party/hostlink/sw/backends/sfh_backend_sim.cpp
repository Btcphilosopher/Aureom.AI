// SilicaFlux HostLink -- simulation backend entry point for the examples.
// Runs the backend-independent demo against the Verilated RTL through the
// transaction-level host model (tb/cosim/sfh_sim.cpp provides the ops).
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "sfh_driver.h"
#include "sfh_sim.h"

extern "C" int sfh_gemm_demo(const sfh_backend_ops *ops, void *ctx, FILE *log);

int main(int argc, char **argv) {
  SimCfg cfg;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--trace")) cfg.trace = true;
    if (!strcmp(argv[i], "--backpressure")) {
      cfg.ar_ready_pct = cfg.aw_ready_pct = cfg.w_ready_pct = cfg.r_valid_pct = cfg.b_valid_pct = 50;
      cfg.rd_latency = 100;
    }
  }
  SfhSim sim(cfg);
  printf("backend  : simulation (Verilated sfh_device_top + host model, rd latency %d cycles)\n", cfg.rd_latency);
  int rc = sfh_gemm_demo(sfh_sim_backend_ops(), &sim, stdout);
  printf("sim      : %llu cycles, %llu host bursts, %llu MSI messages, %zu protocol violations\n",
         (unsigned long long)sim.cycle(), (unsigned long long)sim.host_bursts, (unsigned long long)sim.irq_msgs,
         sim.violations.size());
  return rc || !sim.violations.empty();
}
