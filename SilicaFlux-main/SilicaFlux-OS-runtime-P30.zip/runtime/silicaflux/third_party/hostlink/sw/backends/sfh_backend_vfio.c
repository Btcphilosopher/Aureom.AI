/*
 * SilicaFlux HostLink -- Linux VFIO hardware backend (user space).
 *
 * STATUS: compiles against the Linux UAPI <linux/vfio.h>; NOT EXECUTED.
 * No SilicaFlux PCIe device exists in the build environment (see
 * docs/08_FPGA_BRINGUP.md).  It must be brought up on real hardware before
 * any claim is made about it.
 *
 * What it does (type-1 IOMMU container model):
 *   - binds the device's IOMMU group to a VFIO container (the device must be
 *     bound to vfio-pci by the administrator first);
 *   - mmaps BAR0 (uncached MMIO) for the register file;
 *   - enables PCI bus mastering in the command register;
 *   - allocates DMA buffers with mmap() and maps them into the device's IOVA
 *     space with VFIO_IOMMU_MAP_DMA: the device can reach ONLY these pages
 *     (IOMMU), in addition to the HostLink windows that the driver programs
 *     to the same IOVAs (defence in depth);
 *   - routes MSI-X (or MSI) vectors to eventfds with VFIO_DEVICE_SET_IRQS.
 * The IOMMU is the security boundary; the device windows only restrict the
 * device further.  Never run HostLink DMA with the IOMMU disabled or in
 * passthrough mode (docs/04_DMA_AND_ISOLATION.md).
 */
#include "sfh_backend_vfio.h"

#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <linux/vfio.h>
#include <poll.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/eventfd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

#define PCI_COMMAND 0x04
#define PCI_COMMAND_MEMORY 0x2
#define PCI_COMMAND_MASTER 0x4

static int fail(const char *what) {
  fprintf(stderr, "sfh_vfio: %s: %s\n", what, strerror(errno));
  return -1;
}

int sfh_vfio_open(struct sfh_vfio *v, const char *bdf) {
  memset(v, 0, sizeof(*v));
  v->container = v->group = v->device = -1;
  for (int i = 0; i < SFH_VFIO_MAX_VEC; i++) v->efd[i] = -1;
  v->next_iova = 0x100000000ull;                     /* above 4 GiB: exercises 64-bit addressing */

  char path[256], link[256];
  snprintf(path, sizeof path, "/sys/bus/pci/devices/%s/iommu_group", bdf);
  ssize_t n = readlink(path, link, sizeof link - 1);
  if (n < 0) return fail("iommu_group (IOMMU disabled or wrong BDF?)");
  link[n] = 0;
  int group_id = atoi(basename(link));

  v->container = open("/dev/vfio/vfio", O_RDWR);
  if (v->container < 0) return fail("open /dev/vfio/vfio");
  if (ioctl(v->container, VFIO_GET_API_VERSION) != VFIO_API_VERSION) return fail("VFIO API version");
  if (!ioctl(v->container, VFIO_CHECK_EXTENSION, VFIO_TYPE1_IOMMU)) return fail("no type-1 IOMMU");

  snprintf(path, sizeof path, "/dev/vfio/%d", group_id);
  v->group = open(path, O_RDWR);
  if (v->group < 0) return fail("open group (is the device bound to vfio-pci?)");
  struct vfio_group_status gs = {.argsz = sizeof gs};
  if (ioctl(v->group, VFIO_GROUP_GET_STATUS, &gs) || !(gs.flags & VFIO_GROUP_FLAGS_VIABLE))
    return fail("group not viable (bind every device of the group to vfio-pci)");
  if (ioctl(v->group, VFIO_GROUP_SET_CONTAINER, &v->container)) return fail("GROUP_SET_CONTAINER");
  if (ioctl(v->container, VFIO_SET_IOMMU, VFIO_TYPE1_IOMMU)) return fail("SET_IOMMU");

  v->device = ioctl(v->group, VFIO_GROUP_GET_DEVICE_FD, bdf);
  if (v->device < 0) return fail("GET_DEVICE_FD");

  /* BAR0 */
  struct vfio_region_info bar = {.argsz = sizeof bar, .index = VFIO_PCI_BAR0_REGION_INDEX};
  if (ioctl(v->device, VFIO_DEVICE_GET_REGION_INFO, &bar)) return fail("BAR0 info");
  if (!(bar.flags & VFIO_REGION_INFO_FLAG_MMAP) || bar.size < SFH_BAR0_BYTES) {
    errno = EINVAL;
    return fail("BAR0 not mappable or too small");
  }
  v->bar0 = mmap(NULL, bar.size, PROT_READ | PROT_WRITE, MAP_SHARED, v->device, (off_t)bar.offset);
  if (v->bar0 == MAP_FAILED) { v->bar0 = NULL; return fail("mmap BAR0"); }
  v->bar0_size = bar.size;

  /* bus mastering (vfio-pci enables memory decode, not DMA) */
  struct vfio_region_info cfg = {.argsz = sizeof cfg, .index = VFIO_PCI_CONFIG_REGION_INDEX};
  if (ioctl(v->device, VFIO_DEVICE_GET_REGION_INFO, &cfg)) return fail("config info");
  uint16_t cmd = 0;
  if (pread(v->device, &cmd, 2, (off_t)(cfg.offset + PCI_COMMAND)) != 2) return fail("read COMMAND");
  cmd |= PCI_COMMAND_MEMORY | PCI_COMMAND_MASTER;
  if (pwrite(v->device, &cmd, 2, (off_t)(cfg.offset + PCI_COMMAND)) != 2) return fail("write COMMAND");

  /* interrupts: MSI-X preferred, MSI fallback */
  int idx = VFIO_PCI_MSIX_IRQ_INDEX;
  struct vfio_irq_info ii = {.argsz = sizeof ii, .index = (uint32_t)idx};
  if (ioctl(v->device, VFIO_DEVICE_GET_IRQ_INFO, &ii) || ii.count == 0) {
    idx = VFIO_PCI_MSI_IRQ_INDEX;
    ii.index = (uint32_t)idx;
    if (ioctl(v->device, VFIO_DEVICE_GET_IRQ_INFO, &ii)) ii.count = 0;
  }
  v->nvec = ii.count < SFH_VFIO_MAX_VEC ? (int)ii.count : SFH_VFIO_MAX_VEC;
  if (v->nvec > 0) {
    size_t sz = sizeof(struct vfio_irq_set) + sizeof(int32_t) * (size_t)v->nvec;
    struct vfio_irq_set *set = calloc(1, sz);
    if (!set) return fail("calloc");
    set->argsz = (uint32_t)sz;
    set->flags = VFIO_IRQ_SET_DATA_EVENTFD | VFIO_IRQ_SET_ACTION_TRIGGER;
    set->index = (uint32_t)idx;
    set->start = 0;
    set->count = (uint32_t)v->nvec;
    for (int i = 0; i < v->nvec; i++) {
      v->efd[i] = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
      ((int32_t *)set->data)[i] = v->efd[i];
    }
    int rc = ioctl(v->device, VFIO_DEVICE_SET_IRQS, set);
    free(set);
    if (rc) return fail("SET_IRQS");
  }
  return 0;
}

void sfh_vfio_close(struct sfh_vfio *v) {
  for (int i = 0; i < SFH_VFIO_MAX_VEC; i++)
    if (v->efd[i] >= 0) close(v->efd[i]);
  if (v->bar0) munmap(v->bar0, v->bar0_size);
  if (v->device >= 0) close(v->device);
  if (v->group >= 0) close(v->group);
  if (v->container >= 0) close(v->container);
  memset(v, 0, sizeof(*v));
}

/* ---------------------------------------------------------------- ops */
static uint32_t vf_rd(void *c, uint32_t off) {
  struct sfh_vfio *v = c;
  return *(volatile uint32_t *)((uint8_t *)v->bar0 + off);
}

static void vf_wr(void *c, uint32_t off, uint32_t val) {
  struct sfh_vfio *v = c;
  *(volatile uint32_t *)((uint8_t *)v->bar0 + off) = val;
}

static int vf_alloc(void *c, size_t bytes, struct sfh_dma_buf *o) {
  struct sfh_vfio *v = c;
  size_t sz = (bytes + 4095u) & ~(size_t)4095u;
  void *p = mmap(NULL, sz, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_POPULATE, -1, 0);
  if (p == MAP_FAILED) return -1;
  memset(p, 0, sz);
  struct vfio_iommu_type1_dma_map m = {.argsz = sizeof m,
                                       .flags = VFIO_DMA_MAP_FLAG_READ | VFIO_DMA_MAP_FLAG_WRITE,
                                       .vaddr = (uint64_t)(uintptr_t)p,
                                       .iova = v->next_iova,
                                       .size = sz};
  if (ioctl(v->container, VFIO_IOMMU_MAP_DMA, &m)) {
    munmap(p, sz);
    return fail("MAP_DMA");
  }
  o->va = p;
  o->iova = v->next_iova;
  o->size = sz;
  o->priv = NULL;
  v->next_iova += sz + 4096u;                        /* unmapped guard page */
  return 0;
}

static void vf_free(void *c, struct sfh_dma_buf *b) {
  struct sfh_vfio *v = c;
  struct vfio_iommu_type1_dma_unmap u = {.argsz = sizeof u, .iova = b->iova, .size = b->size};
  /* the device must be quiescent (queues disabled / reset) before buffers are unmapped */
  if (ioctl(v->container, VFIO_IOMMU_UNMAP_DMA, &u)) fail("UNMAP_DMA");
  munmap(b->va, b->size);
  b->va = NULL;
}

static int vf_wait(void *c, uint32_t mask, uint64_t timeout_us, uint32_t *fired) {
  struct sfh_vfio *v = c;
  struct pollfd pf[SFH_VFIO_MAX_VEC];
  int map[SFH_VFIO_MAX_VEC], n = 0;
  for (int i = 0; i < v->nvec; i++)
    if ((mask >> i) & 1u) { pf[n].fd = v->efd[i]; pf[n].events = POLLIN; map[n++] = i; }
  if (n == 0) return -1;
  int to = (int)((timeout_us + 999u) / 1000u);
  if (poll(pf, (nfds_t)n, to) <= 0) return -1;
  *fired = 0;
  for (int i = 0; i < n; i++) {
    uint64_t cnt;
    if ((pf[i].revents & POLLIN) && read(pf[i].fd, &cnt, sizeof cnt) == (ssize_t)sizeof cnt) *fired |= 1u << map[i];
  }
  return *fired ? 0 : -1;
}

static void vf_relax(void *c) {
  (void)c;
#if defined(__x86_64__) || defined(__i386__)
  __builtin_ia32_pause();
#else
  sched_yield();
#endif
}

static uint64_t vf_now(void *c) {
  (void)c;
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (uint64_t)ts.tv_sec * 1000000u + (uint64_t)ts.tv_nsec / 1000u;
}

static const struct sfh_backend_ops kVfioOps = {vf_rd, vf_wr, vf_alloc, vf_free, vf_wait, vf_relax, vf_now};
const struct sfh_backend_ops *sfh_vfio_backend_ops(void) { return &kVfioOps; }
