/* SilicaFlux HostLink -- Linux VFIO backend (compiles; not executed: no hardware). */
#ifndef SFH_BACKEND_VFIO_H
#define SFH_BACKEND_VFIO_H
#include <stddef.h>
#include <stdint.h>
#include "sfh_driver.h"

#define SFH_VFIO_MAX_VEC 8

struct sfh_vfio {
  int container, group, device;
  void *bar0;
  size_t bar0_size;
  int efd[SFH_VFIO_MAX_VEC];
  int nvec;
  uint64_t next_iova;
};

/* bdf: "0000:01:00.0"; device must be bound to vfio-pci, IOMMU enabled. */
int sfh_vfio_open(struct sfh_vfio *v, const char *bdf);
void sfh_vfio_close(struct sfh_vfio *v);
const struct sfh_backend_ops *sfh_vfio_backend_ops(void);

#endif
