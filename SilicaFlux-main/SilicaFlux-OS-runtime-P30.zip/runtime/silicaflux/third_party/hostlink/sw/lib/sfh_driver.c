/*
 * SilicaFlux HostLink -- user-space driver library implementation.
 * Backend independent: every device access goes through d->ops.
 */
#include "sfh_driver.h"

#include <string.h>

#define RD(o) sfh_rd(d, (o))
#define WR(o, v) sfh_wr(d, (o), (v))

static uint64_t elapsed(struct sfh_dev *d, uint64_t t0) { return d->ops->now_us(d->ctx) - t0; }

int sfh_open(struct sfh_dev *d, const struct sfh_backend_ops *ops, void *ctx) {
  memset(d, 0, sizeof(*d));
  d->ops = ops;
  d->ctx = ctx;
  if (RD(SFH_REG_ID) != SFH_DEVICE_MAGIC) return SFH_ERR_NODEV;
  d->version = RD(SFH_REG_VERSION);
  if ((d->version >> 16) != SFH_ABI_MAJOR) return SFH_ERR_NODEV;   /* incompatible ABI */
  d->hw_rev = RD(SFH_REG_HW_REV);
  d->caps = RD(SFH_REG_CAPS);
  d->limits = RD(SFH_REG_LIMITS);
  d->devmem_base[0] = RD(SFH_REG_DEVMEM0_BASE);
  d->devmem_size[0] = RD(SFH_REG_DEVMEM0_SIZE);
  d->devmem_base[1] = RD(SFH_REG_DEVMEM1_BASE);
  d->devmem_size[1] = RD(SFH_REG_DEVMEM1_SIZE);
  d->num_windows = (d->limits & SFH_LIMITS_NUM_WINDOWS_MASK) >> SFH_LIMITS_NUM_WINDOWS_SHIFT;
  d->num_vectors = (d->limits & SFH_LIMITS_NUM_VECTORS_MASK) >> SFH_LIMITS_NUM_VECTORS_SHIFT;
  d->max_dma_log2 = (d->limits & SFH_LIMITS_MAX_DMA_LOG2_MASK) >> SFH_LIMITS_MAX_DMA_LOG2_SHIFT;
  d->next_txn = 1;
  return SFH_OK;
}

int sfh_reset(struct sfh_dev *d, uint64_t timeout_us) {
  WR(SFH_REG_CTRL, SFH_CTRL_RESET_MASK);
  uint64_t t0 = d->ops->now_us(d->ctx);
  for (;;) {
    uint32_t s = RD(SFH_REG_STATUS);
    if (!(s & SFH_STATUS_RESETTING_MASK) && (s & SFH_STATUS_IDLE_MASK)) break;
    if (elapsed(d, t0) > timeout_us) return SFH_ERR_TIMEOUT;
    d->ops->relax(d->ctx);
  }
  d->sq_tail = d->sq_head = d->cq_head = 0;
  d->cq_phase = 1;
  d->inflight = 0;
  return SFH_OK;
}

int sfh_set_window(struct sfh_dev *d, unsigned idx, uint64_t base, uint64_t size, uint32_t ctrl) {
  if (idx >= d->num_windows) return SFH_ERR_INVAL;
  if ((base | size) & (SFH_WINDOW_ALIGN - 1)) return SFH_ERR_INVAL;
  WR(SFH_REG_WIN_CTRL(idx), 0);                      /* disable before changing */
  WR(SFH_REG_WIN_BASE_LO(idx), (uint32_t)base);
  WR(SFH_REG_WIN_BASE_HI(idx), (uint32_t)(base >> 32));
  WR(SFH_REG_WIN_SIZE_LO(idx), (uint32_t)size);
  WR(SFH_REG_WIN_SIZE_HI(idx), (uint32_t)(size >> 32));
  WR(SFH_REG_WIN_CTRL(idx), ctrl);
  if (RD(SFH_REG_WIN_CTRL(idx)) != ctrl || RD(SFH_REG_WIN_BASE_LO(idx)) != (uint32_t)base)
    return SFH_ERR_CONFIG;                           /* locked: queues enabled or engine busy */
  return SFH_OK;
}

static size_t round4k(size_t n) { return (n + 4095u) & ~(size_t)4095u; }

int sfh_queues_alloc(struct sfh_dev *d, unsigned sq_log2, unsigned cq_log2) {
  unsigned sqmax = (d->limits & SFH_LIMITS_SQ_LOG2_MAX_MASK) >> SFH_LIMITS_SQ_LOG2_MAX_SHIFT;
  unsigned cqmax = (d->limits & SFH_LIMITS_CQ_LOG2_MAX_MASK) >> SFH_LIMITS_CQ_LOG2_MAX_SHIFT;
  if (sq_log2 < 1 || sq_log2 > sqmax || cq_log2 < 1 || cq_log2 > cqmax) return SFH_ERR_INVAL;
  if (d->ops->dma_alloc(d->ctx, round4k((size_t)SFH_SQE_BYTES << sq_log2), &d->sq)) return SFH_ERR_NOMEM;
  if (d->ops->dma_alloc(d->ctx, round4k((size_t)SFH_CQE_BYTES << cq_log2), &d->cq)) {
    d->ops->dma_free(d->ctx, &d->sq);
    return SFH_ERR_NOMEM;
  }
  d->sq_n = 1u << sq_log2;
  d->cq_n = 1u << cq_log2;
  WR(SFH_REG_SQ_BASE_LO, (uint32_t)d->sq.iova);
  WR(SFH_REG_SQ_BASE_HI, (uint32_t)(d->sq.iova >> 32));
  WR(SFH_REG_SQ_SIZE, sq_log2);
  WR(SFH_REG_CQ_BASE_LO, (uint32_t)d->cq.iova);
  WR(SFH_REG_CQ_BASE_HI, (uint32_t)(d->cq.iova >> 32));
  WR(SFH_REG_CQ_SIZE, cq_log2);
  /* least privilege: window 0 = SQ (device may only read), window 1 = CQ (only write) */
  int rc = sfh_set_window(d, 0, d->sq.iova, d->sq.size, SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_READ_MASK);
  if (rc == SFH_OK)
    rc = sfh_set_window(d, 1, d->cq.iova, d->cq.size, SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK);
  return rc;
}

void sfh_queues_free(struct sfh_dev *d) {
  if (d->sq.va) d->ops->dma_free(d->ctx, &d->sq);
  if (d->cq.va) d->ops->dma_free(d->ctx, &d->cq);
  memset(&d->sq, 0, sizeof(d->sq));
  memset(&d->cq, 0, sizeof(d->cq));
}

int sfh_enable(struct sfh_dev *d, uint32_t ctrl_extra) {
  memset(d->cq.va, 0, d->cq.size);                   /* phase 0 everywhere: nothing valid */
  sfh_wmb();
  WR(SFH_REG_CTRL, SFH_CTRL_ENABLE_MASK | ctrl_extra);
  if (!(RD(SFH_REG_STATUS) & SFH_STATUS_ENABLED_MASK)) return SFH_ERR_CONFIG;
  d->sq_tail = d->sq_head = d->cq_head = 0;
  d->cq_phase = 1;
  d->inflight = 0;
  return SFH_OK;
}

int sfh_disable(struct sfh_dev *d, uint64_t timeout_us) {
  uint32_t c = RD(SFH_REG_CTRL);
  WR(SFH_REG_CTRL, c & ~SFH_CTRL_ENABLE_MASK);
  uint64_t t0 = d->ops->now_us(d->ctx);
  while (!(RD(SFH_REG_STATUS) & SFH_STATUS_IDLE_MASK)) {
    if (elapsed(d, t0) > timeout_us) return SFH_ERR_TIMEOUT;
    d->ops->relax(d->ctx);
  }
  return SFH_OK;
}

void sfh_irq_setup(struct sfh_dev *d, int use_irq) {
  d->use_irq = use_irq;
  unsigned errv = d->num_vectors > 1 ? 1u : 0u;      /* single-vector MSI: everything on vector 0 */
  WR(SFH_REG_INT_VECTOR, (errv << SFH_INT_VECTOR_ERR_VEC_SHIFT) | 0u);
  WR(SFH_REG_INT_STATUS, SFH_INT_STATUS_CQ_MASK | SFH_INT_STATUS_ERROR_MASK);
  WR(SFH_REG_INT_ENABLE, use_irq ? (SFH_INT_ENABLE_CQ_MASK | SFH_INT_ENABLE_ERROR_MASK) : 0u);
}

static unsigned sq_free(struct sfh_dev *d) {
  unsigned used = (d->sq_tail - d->sq_head) & (d->sq_n - 1u);
  return d->sq_n - 1u - used;
}

int sfh_push(struct sfh_dev *d, const struct sfh_sqe *e) {
  if (sq_free(d) == 0) return SFH_ERR_BUSY;
  volatile uint32_t *dst = (volatile uint32_t *)((uint8_t *)d->sq.va + (size_t)d->sq_tail * SFH_SQE_BYTES);
  const uint32_t *src = (const uint32_t *)e;
  for (unsigned i = 0; i < SFH_SQE_BYTES / 4; i++) dst[i] = src[i];
  d->sq_tail = (d->sq_tail + 1u) & (d->sq_n - 1u);
  d->inflight++;
  return SFH_OK;
}

void sfh_ring(struct sfh_dev *d) {
  sfh_wmb();                                          /* SQE stores before the doorbell */
  WR(SFH_REG_SQ_TAIL, d->sq_tail);
}

int sfh_submit(struct sfh_dev *d, const struct sfh_sqe *e) {
  int rc = sfh_push(d, e);
  if (rc == SFH_OK) sfh_ring(d);
  return rc;
}

int sfh_poll_cqe(struct sfh_dev *d, struct sfh_cqe *out) {
  volatile struct sfh_cqe *c =
      (volatile struct sfh_cqe *)((uint8_t *)d->cq.va + (size_t)d->cq_head * SFH_CQE_BYTES);
  uint32_t dw3 = c->dw3;                              /* phase dword first */
  d->polls++;
  if (SFH_CQE_PHASE(dw3) != d->cq_phase) return 0;
  sfh_rmb();                                          /* then the rest of the entry and data */
  out->txn_id = c->txn_id;
  out->result = c->result;
  out->dw2 = c->dw2;
  out->dw3 = dw3;
  d->sq_head = SFH_CQE_SQ_HEAD(out);
  d->cq_head = (d->cq_head + 1u) & (d->cq_n - 1u);
  if (d->cq_head == 0) d->cq_phase ^= 1u;
  if (d->inflight) d->inflight--;
  WR(SFH_REG_CQ_HEAD, d->cq_head);                    /* release the slot */
  return 1;
}

int sfh_wait_cqe(struct sfh_dev *d, struct sfh_cqe *out, uint64_t timeout_us) {
  uint64_t t0 = d->ops->now_us(d->ctx);
  for (;;) {
    if (sfh_poll_cqe(d, out)) return SFH_OK;
    uint64_t el = elapsed(d, t0);
    if (el > timeout_us) {
      if (RD(SFH_REG_STATUS) & SFH_STATUS_FATAL_MASK) return SFH_ERR_FATAL;
      return SFH_ERR_TIMEOUT;
    }
    if (d->use_irq) {
      /* sleep in bounded slices: a completion whose entry did not request an
       * interrupt (or a lost message) costs at most one slice, never a hang */
      uint32_t fired = 0;
      uint64_t slice = timeout_us - el < SFH_IRQ_SLICE_US ? timeout_us - el : SFH_IRQ_SLICE_US;
      d->irq_waits++;
      if (d->ops->wait_irq(d->ctx, 0x1u, slice, &fired) == 0)
        WR(SFH_REG_INT_STATUS, SFH_INT_STATUS_CQ_MASK);  /* ack, then drain (no lost wakeup) */
    } else {
      d->ops->relax(d->ctx);
    }
  }
}

int sfh_run(struct sfh_dev *d, struct sfh_sqe *e, struct sfh_cqe *out, uint64_t timeout_us) {
  e->txn_id = d->next_txn++;
  if (d->use_irq) e->flags |= SFH_SQE_FLAG_IRQ;      /* we are going to sleep on it */
  int rc = sfh_submit(d, e);
  if (rc) return rc;
  rc = sfh_wait_cqe(d, out, timeout_us);
  if (rc) return rc;
  return out->txn_id == e->txn_id ? SFH_OK : SFH_ERR_INVAL;
}

void sfh_sqe_nop(struct sfh_sqe *e, uint32_t flags) {
  memset(e, 0, sizeof(*e));
  e->opcode = SFH_OP_NOP;
  e->flags = (uint8_t)flags;
}

void sfh_sqe_dma(struct sfh_sqe *e, uint32_t dir, uint64_t src, uint64_t dst, uint32_t len, uint32_t flags) {
  memset(e, 0, sizeof(*e));
  e->opcode = SFH_OP_DMA;
  e->flags = (uint8_t)flags;
  e->dir = (uint8_t)dir;
  e->u.dma.src = src;
  e->u.dma.dst = dst;
  e->u.dma.length = len;
}

void sfh_sqe_gemm(struct sfh_sqe *e, uint32_t a_off, uint32_t b_off, uint32_t c_off, uint32_t k,
                  uint32_t te_flags, uint32_t flags) {
  memset(e, 0, sizeof(*e));
  e->opcode = SFH_OP_TENSOR_GEMM;
  e->flags = (uint8_t)flags;
  e->u.gemm.a_off = a_off;
  e->u.gemm.b_off = b_off;
  e->u.gemm.c_off = c_off;
  e->u.gemm.k = k;
  e->u.gemm.te_flags = te_flags;
}

static int run_status(struct sfh_dev *d, struct sfh_sqe *e, uint64_t timeout_us) {
  struct sfh_cqe c;
  int rc = sfh_run(d, e, &c, timeout_us);
  return rc ? rc : (int)SFH_CQE_STATUS(c.dw3);
}

int sfh_dma_h2d(struct sfh_dev *d, uint64_t host_iova, uint32_t dev_addr, uint32_t len, uint64_t timeout_us) {
  struct sfh_sqe e;
  sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, host_iova, dev_addr, len, 0);
  return run_status(d, &e, timeout_us);
}

int sfh_dma_d2h(struct sfh_dev *d, uint32_t dev_addr, uint64_t host_iova, uint32_t len, uint64_t timeout_us) {
  struct sfh_sqe e;
  sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, dev_addr, host_iova, len, 0);
  return run_status(d, &e, timeout_us);
}

void sfh_perf_snapshot(struct sfh_dev *d) { WR(SFH_REG_PERF_CTRL, SFH_PERF_CTRL_SNAPSHOT_MASK); }

uint64_t sfh_perf_read(struct sfh_dev *d, unsigned idx) {
  return (uint64_t)RD(SFH_REG_PERF_LO(idx)) | ((uint64_t)RD(SFH_REG_PERF_HI(idx)) << 32);
}
