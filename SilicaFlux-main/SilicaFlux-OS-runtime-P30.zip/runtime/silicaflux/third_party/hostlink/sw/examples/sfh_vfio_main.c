/*
 * SilicaFlux HostLink -- hardware entry point for the demo (Linux VFIO).
 * NOT EXECUTED in this project (no SilicaFlux PCIe device available).
 *
 *   # bind the endpoint to vfio-pci (IOMMU must be enabled: intel_iommu=on / amd_iommu=on)
 *   echo 0000:01:00.0 > /sys/bus/pci/devices/0000:01:00.0/driver/unbind
 *   echo <vendor> <device> > /sys/bus/pci/drivers/vfio-pci/new_id
 *   ./sfh_gemm_demo_vfio 0000:01:00.0
 */
#include <stdio.h>

#include "../backends/sfh_backend_vfio.h"

int sfh_gemm_demo(const struct sfh_backend_ops *ops, void *ctx, FILE *log);

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "usage: %s <PCI BDF, e.g. 0000:01:00.0>\n", argv[0]);
    return 2;
  }
  struct sfh_vfio v;
  if (sfh_vfio_open(&v, argv[1])) return 1;
  printf("backend  : VFIO %s, BAR0 %zu bytes, %d interrupt vectors\n", argv[1], v.bar0_size, v.nvec);
  int rc = sfh_gemm_demo(sfh_vfio_backend_ops(), &v, stdout);
  sfh_vfio_close(&v);
  return rc;
}
