/*
 * SilicaFlux HostLink -- end-to-end demo, backend independent.
 *   probe -> reset -> queues/windows/interrupts -> H2D A,B -> TENSOR_GEMM ->
 *   D2H C -> compare with a CPU reference -> DMA bandwidth -> counters
 * Linked with the simulation backend (sw/backends/sfh_backend_sim.cpp) or the
 * VFIO backend (sw/examples/sfh_vfio_main.c).  Same binary logic either way.
 */
#include <stdio.h>
#include <string.h>

#include "sfh_driver.h"

#define CHECK(c, ...)                         \
  do {                                        \
    if (!(c)) {                               \
      fprintf(log, "FAIL: " __VA_ARGS__);     \
      fprintf(log, "\n");                     \
      return 1;                               \
    }                                         \
  } while (0)

static uint32_t lcg(uint32_t *s) { return *s = *s * 1664525u + 1013904223u; }

int sfh_gemm_demo(const struct sfh_backend_ops *ops, void *ctx, FILE *log) {
  struct sfh_dev d;
  int rc = sfh_open(&d, ops, ctx);
  CHECK(rc == SFH_OK, "probe: no SilicaFlux HostLink device (rc %d)", rc);
  fprintf(log, "device   : ID 'SFHL' ABI %u.%u HW_REV %08x CAPS %08x LIMITS %08x\n", d.version >> 16,
          d.version & 0xFFFF, d.hw_rev, d.caps, d.limits);
  fprintf(log, "devmem   : SRAM %08x+%u  TSPM %08x+%u  windows %u vectors %u max DMA 2^%u\n", d.devmem_base[0],
          d.devmem_size[0], d.devmem_base[1], d.devmem_size[1], d.num_windows, d.num_vectors, d.max_dma_log2);
  CHECK(d.caps & SFH_CAPS_TENSOR_GEMM_MASK, "no TENSOR_GEMM capability");
  CHECK(sfh_reset(&d, 100000) == SFH_OK, "reset");
  CHECK(sfh_queues_alloc(&d, 6, 6) == SFH_OK, "queues");
  struct sfh_dma_buf pool;
  CHECK(ops->dma_alloc(ctx, 192 * 1024, &pool) == 0, "dma_alloc");
  CHECK(sfh_set_window(&d, 2, pool.iova, pool.size,
                       SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_READ_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK) == SFH_OK,
        "window");
  sfh_irq_setup(&d, d.num_vectors > 0);
  CHECK(sfh_enable(&d, 0) == SFH_OK, "enable (ERR_STATUS %08x)", sfh_rd(&d, SFH_REG_ERR_STATUS));
  sfh_wr(&d, SFH_REG_PERF_CTRL, SFH_PERF_CTRL_CLEAR_MASK);

  /* ---------------------------------------------------------------- GEMM C = A(4xK) * B(Kx4), int8 */
  const unsigned K = 64;
  uint8_t *A = pool.va, *B = (uint8_t *)pool.va + 4096, *C = (uint8_t *)pool.va + 8192;
  uint32_t seed = 0x5F1u;
  for (unsigned i = 0; i < 4 * K; i++) { A[i] = (uint8_t)lcg(&seed); B[i] = (uint8_t)lcg(&seed); }
  memset(C, 0, 64);
  const uint32_t TS = d.devmem_base[1];
  CHECK(sfh_dma_h2d(&d, pool.iova, TS + 0x0000, 4 * K, 100000) == 0, "H2D A");
  CHECK(sfh_dma_h2d(&d, pool.iova + 4096, TS + 0x1000, 4 * K, 100000) == 0, "H2D B");
  struct sfh_sqe e;
  struct sfh_cqe c;
  sfh_sqe_gemm(&e, 0x0000, 0x1000, 0x2000, K, 0, 0);
  CHECK(sfh_run(&d, &e, &c, 100000) == SFH_OK, "GEMM submit");
  CHECK(SFH_CQE_STATUS(c.dw3) == SFH_STATUS_SUCCESS, "GEMM status %s", sfh_status_str(SFH_CQE_STATUS(c.dw3)));
  uint32_t te_cycles = c.result;
  CHECK(sfh_dma_d2h(&d, TS + 0x2000, pool.iova + 8192, 64, 100000) == 0, "D2H C");
  int bad = 0;
  fprintf(log, "C = A*B  (K = %u, int8 x int8 -> int32), tensor engine %u cycles:\n", K, te_cycles);
  for (int i = 0; i < 4; i++) {
    fprintf(log, "  [");
    for (int j = 0; j < 4; j++) {
      int32_t ref = 0, got;
      for (unsigned k = 0; k < K; k++) ref += (int8_t)A[4 * k + i] * (int8_t)B[4 * k + j];
      memcpy(&got, C + 16 * i + 4 * j, 4);
      bad += got != ref;
      fprintf(log, " %7d%s", got, got == ref ? "" : "(!)");
    }
    fprintf(log, " ]\n");
  }
  CHECK(bad == 0, "%d result elements differ from the CPU reference", bad);

  /* ---------------------------------------------------------------- DMA round trip, whole SRAM */
  uint8_t *src = (uint8_t *)pool.va + 16384, *dst = (uint8_t *)pool.va + 16384 + 65536;
  for (unsigned i = 0; i < 65536; i++) src[i] = (uint8_t)lcg(&seed);
  sfh_perf_snapshot(&d);
  uint64_t b0 = sfh_perf_read(&d, SFH_PERF_BUSY_CYCLES);
  CHECK(sfh_dma_h2d(&d, pool.iova + 16384, d.devmem_base[0], 65536, 1000000) == 0, "H2D 64 KiB");
  sfh_perf_snapshot(&d);
  uint64_t b1 = sfh_perf_read(&d, SFH_PERF_BUSY_CYCLES);
  CHECK(sfh_dma_d2h(&d, d.devmem_base[0], pool.iova + 16384 + 65536, 65536, 1000000) == 0, "D2H 64 KiB");
  sfh_perf_snapshot(&d);
  uint64_t b2 = sfh_perf_read(&d, SFH_PERF_BUSY_CYCLES);
  CHECK(memcmp(src, dst, 65536) == 0, "64 KiB round trip mismatch");
  fprintf(log, "DMA      : H2D 64 KiB in %llu busy cycles (%.2f B/cycle), D2H 64 KiB in %llu (%.2f B/cycle)\n",
          (unsigned long long)(b1 - b0), 65536.0 / (double)(b1 - b0), (unsigned long long)(b2 - b1),
          65536.0 / (double)(b2 - b1));

  static const char *names[SFH_NUM_PERF] = {"CMDS_COMPLETED", "CMDS_FAILED", "BYTES_H2D", "BYTES_D2H", "BUSY_CYCLES",
                                            "HOST_WAIT_CYCLES", "CQ_FULL_CYCLES", "IRQ_MSGS", "ENGINE_CYCLES", "DOORBELLS"};
  fprintf(log, "counters :");
  for (unsigned i = 0; i < SFH_NUM_PERF; i++)
    fprintf(log, " %s=%llu", names[i], (unsigned long long)sfh_perf_read(&d, i));
  fprintf(log, "\ndriver   : interrupt waits %llu, CQ polls %llu\n", (unsigned long long)d.irq_waits,
          (unsigned long long)d.polls);
  CHECK(sfh_disable(&d, 100000) == SFH_OK, "disable");
  CHECK(sfh_rd(&d, SFH_REG_ERR_STATUS) == 0, "ERR_STATUS %08x", sfh_rd(&d, SFH_REG_ERR_STATUS));
  sfh_queues_free(&d);
  ops->dma_free(ctx, &pool);
  fprintf(log, "PASS: data transfer + TensorCore compute + data transfer, bit exact\n");
  return 0;
}
