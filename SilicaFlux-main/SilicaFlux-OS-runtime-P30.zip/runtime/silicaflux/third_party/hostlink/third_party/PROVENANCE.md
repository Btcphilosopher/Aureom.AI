# Third-party (SilicaFlux in-repository) sources — vendored UNMODIFIED

Origin archive in `btcphilosopher/Aureom.AI`:

| Vendored tree | Archive | SHA-256 of the archive |
|---|---|---|
| `silicaflux-datafabric/` (subset) | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip` (byte-identical copy also at `SilicaFlux-main/silicaflux-datafabric.zip`) | `9f1f37357c8e25e00c214227894bca37c45e18ae9d7a993f87039a7679b665fb` |

The DataFabric archive itself vendors SilicaFlux-V release 1 and the SilicaFlux SRAM Wrapper Library unmodified
(its own `third_party/PROVENANCE.md` and `SHA256SUMS`); the files here are copied from it without change:

* `rtl/interconnect/` — `sfb_crossbar` and sub-blocks, `sfb_v1_slave_adapter`
* `rtl/mem/sfb_sram_slave.sv`
* `tb/common/sfb_protocol_checker.sv`, `docs/datafabric/PROTOCOL.md` (reference)
* `third_party/silicaflux-v/rtl/{pkg,common,mem,accel}` — `sfv_pkg`, `sfv_common` (`sfv_rst_sync`), `sfv_clkgate`,
  `sfv_sram_sp`, `sfv_tile`, `sfv_tensor_engine`, `sfv_vec_engine`; `docs/ACCELERATORS.md`, `docs/RTL_CODING_RULES.md`
* `third_party/silicaflux-sramlib/rtl/mem/**` — SRAM Wrapper Library RTL

Every file is byte-identical to the archive member; verify with

```bash
cd third_party/silicaflux-datafabric && sha256sum -c ../SHA256SUMS.datafabric
```

(`make lint` runs this check.)
