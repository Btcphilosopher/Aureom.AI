# 09 — CXL research note

**Nothing in this project implements or claims CXL.** HostLink is ordinary PCIe-style DMA behind a (future)
PCIe endpoint. This note records how SilicaFlux could move to CXL and which separate milestones that would take.

## 1. What CXL is (for this discussion)

Compute Express Link runs over the PCIe physical layer (CXL 1.1/2.0 at PCIe 5.0 rates; CXL 3.x at PCIe 6.x rates
with flit mode) and multiplexes three protocols:

| Protocol | Function | Relevance |
|---|---|---|
| **CXL.io** | PCIe-equivalent: enumeration, configuration, MMIO BARs, DMA, interrupts. Mandatory for every CXL device. | HostLink's ABI maps onto it unchanged — but CXL.io is *not coherent* in any new sense; it is the PCIe semantics HostLink already assumes. |
| **CXL.cache** | lets a device cache host memory coherently (device requests to the host's home agent; host snoops the device cache). | an accelerator could read operands directly from host memory with coherent caching instead of explicit DMA + flushes |
| **CXL.mem** | lets the host access device-attached memory as ordinary (cacheable) memory through HDM decoders. | the host could write operands straight into SilicaFlux memory with CPU stores |

Device types: **Type 1** (CXL.io + CXL.cache; accelerator without host-managed device memory), **Type 2**
(CXL.io + CXL.cache + CXL.mem; accelerator with device memory), **Type 3** (CXL.io + CXL.mem; memory expander).
A SilicaFlux accelerator with on-board memory would be a Type 2 device.

## 2. What HostLink's DMA is — and is not

* Device writes reach host memory through the root complex; on most servers DMA to host memory is snooped
  ("I/O-coherent") so CPUs read fresh data — but the **device holds no coherent cached copy** of host memory and the
  host cannot cache **device** memory coherently.
* Visibility is managed by protocol: completion entries, phase tags, barriers and the optional flush read.
  The flush read is an **ordering** mechanism (a read does not pass posted writes), not coherence.
* Therefore HostLink must never be described as cache-coherent or as CXL.

## 3. Possible directions

| Direction | What changes in SilicaFlux | What is required |
|---|---|---|
| A. CXL.io only | nothing above the endpoint: same BAR ABI, same queues | a CXL-capable endpoint used in CXL.io mode (or plain PCIe); no functional gain |
| B. Type 2, CXL.mem first | device SRAM/HBM exposed as HDM; host writes A/B with stores, reads C with loads; queues still for commands | device memory controller behind a CXL.mem target, HDM decoders, bias handling (host-/device-bias in CXL 1.1/2.0; back-invalidate snoop for device-coherent HDM in CXL 3.x); host OS/driver support for device memory (e.g. as a special-purpose memory region) |
| C. Type 2 with CXL.cache | TensorCore / DMA fetch operands from host virtual buffers coherently; fewer copies and no flushes | device coherency agent and a coherent device cache, snoop handling, address translation for host addresses (ATS/IOMMU interaction), deadlock-free integration with the DataFabric |

## 4. IP and platform availability

* No CXL IP, CXL-capable FPGA or CXL host is available to this project; none of the repository's boards has the
  required SERDES.
* Some current FPGA families advertise CXL hard IP (for example Intel Agilex 7 devices with R-Tile list CXL
  Type 1/2/3 support); availability, supported CXL revision and device types must be checked against the vendor's
  current documentation before planning. CXL hosts are server CPU platforms with CXL root ports.

## 5. Separate milestones (none started)

1. **CXL.io bring-up** on a certified endpoint: enumeration as a CXL device, DVSECs, reuse of the HostLink ABI.
2. **CXL.mem / HDM**: device memory visible to the host, bias/coherence model chosen and verified.
3. **CXL.cache**: coherent device access to host memory; protocol verification with the vendor's verification IP.
4. **Compliance and interoperability**: CXL compliance tests and interoperability testing with real host
   platforms. Until these pass, no CXL compliance, coherence or interoperability may be claimed.
