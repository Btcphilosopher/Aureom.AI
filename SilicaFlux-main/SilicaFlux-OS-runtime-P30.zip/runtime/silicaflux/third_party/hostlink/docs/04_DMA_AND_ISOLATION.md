# 04 — DMA descriptor engine and host isolation

## 1. DMA engine

| Property | Implementation (`rtl/sfh_engine.sv`, `rtl/sfh_host_port.sv`) |
|---|---|
| Descriptor | SQE with `opcode = DMA`: source, destination, length, direction (`dir`), transaction ID, completion flags (`IRQ`, `FLUSH`) — [02_DRIVER_ABI.md](02_DRIVER_ABI.md) §4 |
| Directions | H2D (host IOVA → device SRAM/TSPM), D2H (device → host IOVA). No host→host or device→device copy. |
| Granularity | 8 bytes (src, dst, length); length 1 B…1 MiB in 8-byte units |
| Host side | AXI4 master, 64-bit, INCR bursts of ≤ 16 beats (128 B), AxID 0, WSTRB all-ones; a chunk never crosses a host 4 KiB boundary; one burst outstanding |
| Device side | SFB2 master on `sfb_crossbar`, 32-bit word transactions, one outstanding; each write acknowledged before the next (R7) |
| Chunking | `chunk = min(remaining, 128 B, bytes to the next host 4 KiB boundary)`; H2D: host burst read → device word writes; D2H: device word reads → host burst write (B awaited) |
| Completion | after the last device write acknowledge (H2D) / last host B response (D2H); `CQE.result` = bytes completed |
| Errors | host SLVERR/DECERR → `HOST_BUS_ERROR`; fabric `rsp_error` → `DEV_BUS_ERROR`; `result` = contiguous prefix completed; `ERR_ADDR` = failing address; next command runs normally |
| Scatter-gather | **not implemented** (`CAPS.SCATTER_GATHER = 0`); a scattered buffer is submitted as one DMA entry per contiguous IOVA range (the queue gives in-order execution). |

## 2. Validation before any access

`rtl/sfh_cmd_validate.sv` is purely combinational on the fetched SQE and the window registers. A command executes
only if every check passes; the 31 invalid-descriptor cases of `t_invalid_descriptors` verify that a rejected
command performs **no** host or device access (IOMMU fault log empty, host and device canaries unchanged).

| Check | Arithmetic |
|---|---|
| length 1 … 2^MAX_DMA_LOG2, multiple of 8; src/dst 8-aligned | 32-bit |
| host range `[a, a+len)` inside a window: `VALID`, permission (`DEV_READ` for H2D, `DEV_WRITE` for D2H), `a ≥ base`, `a+len ≤ base+size`, `a+len ≤ 2^64` | **65-bit** sums: no wrap-around can alias a low address (`t_window_overflow`: window ending at 2^64 + 4 KiB, range wrapping past 2^64 → denied) |
| device range inside DEVMEM0 or DEVMEM1, upper 32 bits zero | **33-bit** sums (`dev 32-bit wrap` case) |
| SQ ring inside a `DEV_READ` window, CQ ring inside a `DEV_WRITE` window, rings not overlapping, sizes in range | checked at `CTRL.ENABLE`; refused with `ERR_STATUS.RING_CONFIG` |

Consequences of the least-privilege windows set by the reference driver: the device cannot overwrite its own
command ring (D2H into the SQ → `HOST_ADDR_DENIED`), cannot read the CQ, and cannot touch anything else.

## 3. Register permissions

* RO registers ignore writes (logged). RWL registers (rings, windows) are writable only while the queues are
  disabled and the engine idle — a window can never change under a command that was validated against it.
* `CTRL.ENABLE` 0→1 requires an idle engine; doorbells are range- and direction-checked (02 §6).
* Sub-word writes, bursts and misaligned offsets are rejected by the BAR bridge / endpoint shell.

## 4. Reset and in-flight transfers

| Event | In-flight host transaction | In-flight command | After |
|---|---|---|---|
| `CTRL.ENABLE` 1→0 | completes | completes, CQE posted | idle, no new fetch |
| `CTRL.RESET` | completes (AXI/SFB2 cannot be cancelled), response data discarded | abandoned, no CQE | all registers reset, tile reset, no further host access (`t_reset_during_activity`: 6 random reset points during a 64 KiB H2D/D2H + GEMM mix; host traffic counters frozen after reset) |
| host stops answering | watchdog → FATAL + `HOST_TIMEOUT`; `CTRL.RESET` waits | abandoned | late answer → reset completes; no answer → endpoint FLR / hot reset required (`t_host_timeout`) |
| endpoint reset (FLR, hot reset, link down) | dropped by the endpoint | abandoned | everything reset incl. counters (`t_endpoint_reset`) |

Driver rule: before unmapping DMA buffers or the rings, disable the queues and wait for `STATUS.IDLE` (or reset
the device) so that no transaction can target an unmapped IOVA.

## 5. Reliance on the host IOMMU

HostLink's windows are **defence in depth, not the security boundary**:

* They are a few coarse ranges programmed by the driver; a compromised or buggy driver can program any window.
* A malicious device (or a modified bitstream) ignores them entirely.

The isolation the system relies on is the **host IOMMU** (Intel VT-d / AMD-Vi / Arm SMMU) with the device in its
own IOMMU group, mapped only through the DMA API (kernel) or VFIO type-1 (user space; `sw/backends/
sfh_backend_vfio.c` maps every buffer with `VFIO_IOMMU_MAP_DMA` at IOVAs above 4 GiB, with unmapped guard pages).
Requirements for deployment:

1. IOMMU enabled in DMA-translation mode (not `iommu=pt` passthrough, not disabled) for this function.
2. ACS on the path to the device, so that peer-to-peer requests cannot bypass the IOMMU.
3. Bus mastering enabled only after the IOMMU domain is attached (the VFIO backend sets `BME` after attaching the
   group to the container).
4. ATS / PASID / PRI are not used by HostLink and should stay disabled in the endpoint configuration.

The simulator models this split: its IOMMU answers DECERR for unmapped pages even inside a valid window
(`t_data_bus_errors`, `t_window_overflow`), and records each fault.
