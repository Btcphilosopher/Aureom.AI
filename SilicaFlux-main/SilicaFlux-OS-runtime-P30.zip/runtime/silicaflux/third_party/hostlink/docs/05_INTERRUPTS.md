# 05 — Interrupts

## 1. Sources and registers

| Source | Bit | Set when | Default vector |
|---|---|---|---|
| CQ | `INT_STATUS[0]` | a CQE is posted for an SQE with the `IRQ` flag, or with non-SUCCESS status; `INT_TEST[0]` | 0 |
| ERROR | `INT_STATUS[1]` | a device-level error bit is set in `ERR_STATUS` (REG_ACCESS, DOORBELL, RING_CONFIG, HOST_BUS, HOST_TIMEOUT, ENGINE_TIMEOUT); `INT_TEST[1]` | 1 |

* `INT_STATUS` is sticky, write-1-to-clear. An event in the same cycle as a clear wins (no lost interrupt).
* `INT_ENABLE` masks per source. A masked source still latches its status. Enabling a source whose status is
  already set sends a message immediately.
* `INT_VECTOR` maps each source to a message vector `< NUM_VECTORS` (reference: 2). With single-vector MSI, map
  both to vector 0.
* `irq_level = |(INT_STATUS & INT_ENABLE)` for INTx-style integration.

## 2. Message interface (towards the endpoint)

`irq_valid`, `irq_vector[3:0]`, `irq_ready`: a message request is presented and held stable until the endpoint
accepts it (valid/ready). Every enabled event arms its source; while a message is waiting, further events coalesce
into at most one follow-up message. Sources mapped to the same vector share one message. A message already
presented is never withdrawn, even if the host masks or clears the source meanwhile (the driver tolerates a
spurious interrupt). The endpoint IP turns the request into an MSI or MSI-X memory write (vector table, masking
and pending bits of MSI-X live in the endpoint IP's capability, not in HostLink).

Ordering: the CQ event is generated only after the CQE write has been acknowledged (and after the flush read when
enabled), so inside HostLink a message can never precede the completion it announces. The simulator delivers
messages through the same posted-write queue as data (an MSI never passes earlier posted writes) and the test
checks that the CQE is visible whenever a message arrives, with 60-cycle write-visibility latency.

## 3. Driver usage

* **Polling fallback** (no interrupts at all): `INT_ENABLE = 0`; poll the next CQE's phase dword in host memory
  (no MMIO needed) — `sfh_irq_setup(d, 0)`.
* **Interrupt mode**: `sfh_irq_setup(d, 1)`; `sfh_run()` sets the `IRQ` flag on what it waits for; the wait loop is
  poll → sleep on vector 0 (bounded slice, 200 µs) → on wake `INT_STATUS = CQ` (W1C) → poll again. Clearing before
  draining means an event arriving during the drain re-arms a message, so no wake-up is lost; the bounded slice
  makes even a lost message cost latency, never a hang.
* ERROR vector: read `ERR_STATUS` / `STATUS.FATAL`, act per 02 §8, clear with W1C.

## 4. Verification (`tests/test_hostlink.cpp`)

| Case | Test |
|---|---|
| no IRQ flag → no message; IRQ flag → vector 0; CQE visible on arrival | `interrupts` (a, b) |
| masked: status latches, no message, no level; unmask → immediate message | `interrupts` (c) |
| error completion without flag interrupts | `interrupts` (d) |
| device error → ERROR on vector 1; single-vector mode on vector 0 | `interrupts` (e, f) |
| endpoint not accepting messages: request held stable, events coalesce to 1–2 messages | `interrupts` (g) |
| `INT_TEST`, `IRQ_MSGS` counter equals delivered messages | `interrupts` (h) |
| interrupt-driven driver path, 30 commands, few polls | `irq_driven_completion` |
| ERROR interrupt on fatal / timeout / engine timeout | `fatal_queue_errors`, `host_timeout`, `engine_timeout` |
| mutants: "unmask does not re-arm", "interrupt on every completion" | killed (`reports/mutants.md`) |

MSI / MSI-X on real hardware (capability configuration, vector table masking, eventfd delivery through VFIO) is
**not verified** — blocked with the rest of the hardware bring-up.
