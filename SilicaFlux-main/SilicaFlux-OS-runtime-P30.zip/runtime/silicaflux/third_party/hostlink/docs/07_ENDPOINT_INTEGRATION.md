# 07 — Endpoint integration

**Status: the endpoint boundary is defined, implemented and verified in simulation against a model of an
AXI-bridge endpoint. No vendor PCIe endpoint IP has been instantiated, built or run** (none is available —
[00_AUDIT.md](00_AUDIT.md)). Physical PCIe must be added only through a verified vendor endpoint core; this
project contains no PCIe protocol logic and makes no PCIe-compliance claim.

## 1. The boundary

`sfh_device_top` (or `silicaflux_host_pcie` + `sfh_ep_axi_shell` in a larger SoC) expects an endpoint that provides
the three services every AXI-bridge style PCIe endpoint provides:

| Role | HostLink port | Protocol | Endpoint-side service |
|---|---|---|---|
| BAR0 target (CPU MMIO) | `s_bar_*` | AXI4 slave, 32-bit data, AxID 4 bit; single-beat 32-bit accesses forwarded, everything else answered SLVERR by the shell | memory requests hitting BAR0 forwarded as AXI master transactions ("PCIe → AXI" / BAR master bridge) |
| Device-initiated host memory access | `m_host_*` | AXI4 master, 64-bit address, 64-bit data, INCR ≤ 16 beats, never across 4 KiB, AxID 0 | AXI slave bridge turning AXI reads/writes into memory read / posted write TLPs ("AXI → PCIe" / slave bridge) |
| Interrupt request | `irq_valid`, `irq_vector[3:0]`, `irq_ready` (+ `irq_level`) | valid/ready, payload stable until accepted | MSI / MSI-X (or legacy INTx from `irq_level`) generation |
| Clock / reset | `clk`, `ep_rst_n` | endpoint user clock, user reset (active low) | user clock and reset; asserted on hot reset, FLR and link down |

## 2. Requirements on the endpoint configuration

| # | Requirement | Why |
|---|---|---|
| E1 | BAR0: 32-bit or 64-bit memory BAR, non-prefetchable, ≥ 4 KiB, mapped to AXI offset 0 of `s_bar_*` (HostLink decodes `AxADDR[11:0]`) | register file |
| E2 | Slave bridge with **identity address translation** (AXI address = PCIe address = IOVA), 64-bit addressing enabled | SQEs carry IOVAs |
| E3 | Writes on the slave bridge emitted **in AXI order**, one traffic class, **Relaxed Ordering cleared** — or else run with `CTRL.FLUSH_ALL` | completion-after-data guarantee ([02_DRIVER_ABI.md](02_DRIVER_ABI.md) §7) |
| E4 | An interrupt requested after a bridge write's B response must not overtake that write — or else `CTRL.FLUSH_ALL` | interrupt after CQE |
| E5 | Completion timeouts / UR / CA on the slave bridge returned as AXI SLVERR/DECERR (never a hang) | HostLink reports `HOST_BUS_ERROR`; its own watchdog is only the second line |
| E6 | Max payload / max read request ≥ 128 B (PCIe minimum is 128 B) | HostLink bursts are ≤ 128 B, so no endpoint splitting is needed |
| E7 | Hot reset, FLR and link-down drive `ep_rst_n` low | function reset semantics |
| E8 | Data-width conversion (endpoint datapath 64/128/256/512 bit) and clock-domain crossing with standard AXI infrastructure IP if the endpoint clock differs from the SilicaFlux clock | HostLink is one 64-bit clock domain |
| E9 | MSI-X capability with ≥ 2 vectors (MSI with 1 vector is supported by mapping both sources to vector 0); ATS/PASID/PRI disabled | interrupts; isolation through the IOMMU only |
| E10 | Vendor/device ID, class code (e.g. processing accelerator `0x12`), subsystem IDs assigned by the project owner | enumeration (not assigned yet) |

## 3. Mapping to vendor endpoint families (to be verified on the real IP)

The table names IP *roles*; exact port names, widths and handshakes differ between IP versions and **must be
taken from the instantiation template generated for the chosen device and tool version**. None of this has been
elaborated against real IP.

| Endpoint family (examples) | BAR target | Host access | Interrupt | Notes |
|---|---|---|---|---|
| AMD/Xilinx DMA/Bridge Subsystem for PCIe in **AXI Bridge** mode, AXI Bridge for PCIe (Gen3), QDMA bridge mode | AXI4 BAR master port (width-convert to 32 bit) | AXI4 slave bridge port; set AXI→PCIe translation to identity | user interrupt / MSI-X request interface; a small req/ack adapter may be needed | do not use the IP's own DMA engine for HostLink queues (two DMA engines with different ABIs) |
| Intel/Altera Multi-Channel DMA for PCIe in a bridge configuration with bursting Avalon-MM master/slave | Avalon-MM master → AXI4 (bridge IP) | Avalon-MM slave ← AXI4 (bridge IP) | MSI/MSI-X user interface | Avalon↔AXI bridging adds latency; ordering requirement E3 still applies |
| Lattice PCIe endpoint soft/hard IP (CertusPro-NX, ECP5-5G class devices) | per IP user interface | per IP user interface | per IP | requires a device with SERDES; the repository's ECP5 `LFE5U` (ULX3S) has none |

## 4. What the shell does and does not do

`rtl/ep/sfh_ep_axi_shell.sv`:
* converts BAR AXI4 to AXI4-Lite; rejects bursts (`AxLEN ≠ 0`) and non-32-bit sizes with SLVERR (consuming all W
  beats, returning `LEN+1` R beats with RLAST on the last), echoes AxID; verified by `reg_access_rules`
  (4-beat burst read, 2-beat burst write, narrow write, 32 ID round trips) and by the `shell_burst` mutant;
* synchronises the endpoint reset (`sfv_rst_sync`, async assert / sync release).

It does **not**: decode BARs, handle configuration space, generate TLPs, implement MSI-X tables, cross clock
domains, convert data widths, or enforce PCIe ordering. Those are endpoint-IP and AXI-infrastructure functions.

## 5. What remains unverified until hardware exists

Enumeration, BAR sizing, link training (speed/width), real TLP ordering of the chosen bridge (E3/E4), real
completion-timeout behaviour (E5), MSI-X delivery through the OS, IOMMU interaction, VFIO backend, timing closure
at the endpoint user clock. See [08_FPGA_BRINGUP.md](08_FPGA_BRINGUP.md).

## 6. Further SilicaFlux integration (after the endpoint)

* **ControlCore**: expose its SFB2 host-access port (`hs_*`) through a second BAR or a HostLink "mailbox" opcode
  and route `host_irq_o` to a third interrupt source, so the host can boot and talk to the firmware through the
  same function.
* **HPC Module 06 command queue**: forward a new opcode's payload to `hpc_command_queue`'s ready/valid descriptor
  port and complete on its completion record — the host-memory queues stay the external ABI.
* **Vector engine**: opcode `0x03 VECTOR` is reserved; the VE register page is already wired to the tile.
