# 01 — Architecture

## 1. Control path and data path

```
 Host CPU (driver: sw/lib/sfh_driver.c, backend: VFIO | simulation)
   │  MMIO: BAR0 32-bit registers, doorbells            ▲ MSI/MSI-X message (vector)
   │  host memory: SQ ring, CQ ring, data buffers (IOMMU-mapped IOVAs)
 ══╪════════════════════════════════════ PCIe link ══════╪══════════════════════════════
   ▼                                                     │
 PCIe endpoint IP  (vendor, verified — NOT part of this project; simulated by tb/cosim/sfh_sim.cpp)
   │ BAR0 → AXI4 master      ▲ AXI4 slave bridge (device → host memory)   ▲ interrupt request
 ──┼─────────────────────────┼────────────────────────────────────────────┼──────────── generic AXI boundary
   ▼                         │                                            │
 sfh_ep_axi_shell            │  (AXI4→AXI4-Lite BAR converter, burst rejection, reset sync)
   ▼ AXI4-Lite               │ AXI4 64-bit                                 │ irq_valid/vector/ready
 ┌─ silicaflux_host_pcie ────┼────────────────────────────────────────────┼──────────────┐
 │  sfh_bar_regs ── cfg/doorbells ──► sfh_engine ───────────────────────────────────────  │
 │   (register file, error log,        │ sfh_host_port (AXI4 bursts, ≤ 4 KiB, watchdog) │
 │    sfh_irq, sfh_perf, ring/doorbell │ sfh_cmd_validate (opcode/fields/windows/ranges)│
 │    validation, sfh_win_check)       │ sfh_te_ctl (TE register sequencer, watchdog)   │
 └─────────────────────────────────────┼──────────────────────────────┼─────────────────┘
                                       ▼ SFB2 master (M0)             ▼ TE register page
 SilicaFlux DataFabric: sfb_crossbar 2×2 (round robin) ◄── M1: ControlCore / other masters
     ▼ S0 0x1000_0000                  ▼ S1 0x2000_0000
 sfb_sram_slave (device SRAM 64 KiB)   sfb_v1_slave_adapter → sfv_tile (TSPM 16 KiB, VE, TE)
```

**Control**: host writes SQEs to the SQ ring in its memory, then the `SQ_TAIL` doorbell (BAR0). HostLink fetches
each 64-byte SQE with one AXI read burst, validates it, executes it, writes a 16-byte CQE into the CQ ring and
optionally sends an interrupt message.

**Bulk data**: `DMA` commands move data between host IOVAs (AXI4, 64-bit, ≤ 16-beat bursts, never across a 4 KiB
boundary) and device memory (SFB2 word accesses to the device SRAM or the tile scratchpad).

**Compute**: `TENSOR_GEMM` programs the SilicaFlux-V tensor engine through its register page, starts it and waits
for its DONE/ERR status; operands and results live in the tile scratchpad (TSPM), which the host fills and drains
with `DMA`.

The PCIe protocol core is kept separate: `silicaflux_host_pcie` contains no PCIe logic and only speaks
AXI4-Lite / AXI4 / valid-ready interrupt requests, so the same RTL is driven by the simulated host today and by a
vendor endpoint later.

## 2. Modules

| Module | File | Function |
|---|---|---|
| `silicaflux_host_pcie` | `rtl/silicaflux_host_pcie.sv` | **primary RTL**: HostLink core (regs + engine), parameter legality checks |
| `sfh_bar_regs` | `rtl/sfh_bar_regs.sv` | BAR0 AXI4-Lite target, register file, access permissions, doorbell + ring validation, error log |
| `sfh_irq` | `rtl/sfh_irq.sv` | INT_STATUS/ENABLE/VECTOR, message generation and coalescing, level output |
| `sfh_perf` | `rtl/sfh_perf.sv` | 10 × 64-bit counters with atomic snapshot |
| `sfh_engine` | `rtl/sfh_engine.sv` | queue engine FSM: fetch, decode, DMA, GEMM, flush, CQE post, reset drain, fatal handling |
| `sfh_host_port` | `rtl/sfh_host_port.sv` | AXI4 master to host memory, 16 × 64-bit burst buffer, watchdog |
| `sfh_cmd_validate` | `rtl/sfh_cmd_validate.sv` | combinational SQE checks (status codes in priority order) |
| `sfh_win_check` | `rtl/sfh_win_check.sv` | 65-bit overflow-safe window check (rings and DMA) |
| `sfh_te_ctl` | `rtl/sfh_te_ctl.sv` | tensor-engine command sequencer + watchdog + tile reset request |
| `sfh_ep_axi_shell` | `rtl/ep/sfh_ep_axi_shell.sv` | endpoint integration wrapper (BAR AXI4→AXI4-Lite, reset sync) |
| `sfh_device_top` | `rtl/soc/sfh_device_top.sv` | device: shell + HostLink + DataFabric + SRAM + compute tile |
| `sfh_abi_pkg` | `generated/sfh_abi_pkg.sv` | generated from `abi/sfh_abi.py` (single source of truth) |

## 3. Engine state machine

```
          ┌──────────── reset_req (only where no bus transaction is outstanding) ─────────────┐
          ▼                                                                                   │
 RESET ─► IDLE ──(enabled & !halted & HEAD≠TAIL)──► FETCH ──► DECODE ──invalid──────────┐     │
  ▲        ▲                                   (8-beat read)  │                         │     │
  │        │                         NOP ─────────────────────┤                         │     │
  │        │                         DMA ─► DMA_NEXT ◄──────┐ │                         │     │
  │        │                                 │ H2D: HOST_RD ─► DEV_NEXT ⇄ DEV_REQ/DEV_RSP   │
  │        │                                 │ D2H: DEV_NEXT ⇄ DEV_REQ/DEV_RSP ─► HOST_WR    │
  │        │                         GEMM ─► TE (sfh_te_ctl: write regs, START, poll)    │     │
  │        │                                                                          ▼     │
  │        └────── CQ_POST (2-beat write, wait B) ◄── CQ_FILL ◄── [FLUSH] ◄── CQ_WAIT (CQ full: stall)
  │                     │ error on queue memory / host timeout
  └──── (reset_req) ─── FATAL
```

* One command in flight, strictly in order; one AXI burst and one SFB2 beat in flight at a time.
* A data-transfer error ends the command (error CQE). An error or timeout on SQ fetch / CQ write / flush read, or
  any host-bus timeout, is **fatal** (no further commands; recovery = `CTRL.RESET`).
* `CTRL.RESET` is acted on only between bus transactions (AXI and SFB2 have no cancel); the in-flight transaction
  always completes, the command never does.

## 4. Clocking and reset

Single clock domain (`clk`). In an FPGA build this is either the endpoint IP's user clock (simplest; all of
HostLink and the device run in it) or a separate core clock with AXI clock-domain-crossing IP on the three
endpoint-side interfaces (the shell boundary is the only place that needs it). Resets: endpoint user reset →
`sfv_rst_sync` → `rst_n` (async assert, sync release). The compute tile has its own synchronised reset that
HostLink asserts during `CTRL.RESET` and after an engine timeout; `tile_rst_req` comes from a flop (glitch-free).

## 5. Resource estimate (Yosys 0.33, no place-and-route; `reports/synth.log`)

| Target | Result |
|---|---|
| generic `synth` of `silicaflux_host_pcie` | 31.5 k cells, 4 562 flip-flops, no latches, `check -assert` clean |
| `synth_xilinx -family xc7` | ≈ 6.0 k LUT, 4.6 k FF, 609 CARRY4 (mapping estimate only) |
| `sfh_ep_axi_shell` | 255 cells, 90 flip-flops |

The largest flop consumers are the 64-bit performance counters with snapshots (1 280 FF), the 128-byte burst
buffer (1 024 FF; maps to LUT-RAM/BRAM in a real flow) and the 512-bit SQE register.

## 6. Performance (RTL, reference configuration, `reports/gemm_demo_sim.log`)

| Measurement (host read latency 24 cycles) | Result |
|---|---|
| H2D 64 KiB → device SRAM | 71 216 cycles = **0.92 B/cycle** |
| D2H 64 KiB ← device SRAM | 62 512 cycles = **1.05 B/cycle** |
| TENSOR_GEMM K = 64 | 135 engine cycles (= 3 + 2K + 4, deterministic) |
| same DMAs with 50 % AXI back-pressure, 100-cycle read latency | 0.55 / 0.91 B/cycle |

Throughput is limited by design choices made for verifiability: one SFB2 word in flight (≈ 3 cycles per 32-bit
word on the device side) and no overlap between the host burst and the device beats of a chunk. The path to
≥ 8 B/cycle is listed in [INTEGRATION_REPORT.md](../INTEGRATION_REPORT.md) §6 (64-bit DataFabric port, pipelined
SFB2 requests, double-buffered chunks, several outstanding AXI bursts).
