# 00 — Repository and platform audit

Audit of `btcphilosopher/Aureom.AI` (branch snapshot of 2026-11-10) and of the build machine, done before any
HostLink RTL was written. Every SilicaFlux project in the repository is stored as a zip archive; the relevant ones
were extracted and read.

## 1. Findings

| Item | Finding | Consequence for HostLink |
|---|---|---|
| **Target FPGA board** | Boards referenced by SilicaFlux projects: **ULX3S** (Lattice ECP5 `LFE5U-85F`, ControlCore / MCU-I / HPC M08 / TensorCore 08), **Arty A7-100T** (SRAM library, SilicaFlux v1 `synth/vivado`), **DE10-Nano** (Cyclone V SE, SilicaFlux v1 `synth/quartus`). ControlCore `docs/08_FPGA.md`: *"No board was available. Nothing in this project has run on FPGA hardware."* | No PCIe-capable board is referenced anywhere. |
| **PCIe-capable FPGA resources** | ECP5 `LFE5U` parts have no SERDES; the Arty A7-100T board has no PCIe edge connector; the Cyclone V **SE** in the DE10-Nano has no transceivers. None of the three boards can be a PCIe endpoint. | Physical PCIe is **blocked** (section 3). |
| **Licensed / vendor PCIe endpoint IP** | None in the repository (searched every extracted archive for PCIe, XDMA, QDMA, MSI-X, BAR). HPC Module 08 `docs/06_host_software.md`: *"No PCIe (or any other off-chip host link) is implemented or claimed."* No Vivado / Quartus / Radiant installation on the build machine (so no IP catalog either). | No verified endpoint core is available → HostLink is built against a **generic AXI endpoint boundary** and a **simulated host transport**; no custom PCIe protocol logic is written. |
| **PCIe hardware on the build machine** | `/sys/bus/pci/devices`: Intel host bridge `8086:0d57` and virtio devices (`1af4:*`) only; no Xilinx (`10ee`) / Altera (`1172`) function; no `/dev/xdma*`, `/dev/vfio/*` device. | No hardware bring-up possible here. |
| **DataFabric interconnect** | `silicaflux-datafabric.zip` (Project 03, two byte-identical copies, SHA-256 `9f1f3735…`): **SFB2** protocol (valid/ready request + response with back-pressure, rule set R1–R12), `sfb_crossbar` (formally verified arbiter/crossbar), `sfb_sram_slave`, `sfb_v1_slave_adapter`, protocol checker. | HostLink is an **SFB2 master** on an unmodified `sfb_crossbar`; the repo's `sfb_protocol_checker` conventions are followed. |
| **DMA engine** | DataFabric `silicaflux_dma` (on-chip src→dst copy, CPU-programmed, single channel, no host memory). HPC M05 `hpc_dma_adapter` (scratchpad ↔ vector array). Neither can reach host memory. | A host-memory DMA descriptor engine is new work (`sfh_engine`); DataFabric's error-code style and "write acknowledged before completion" rule (R7) are reused. |
| **ControlCore registers** | `silicaflux-controlcore.zip`: RV32 control processor, register pages SYSCTRL/MAILBOX/RAS/PMU/SECMON, an **SFB2 host access port** (`hs_*`) and `host_irq_o`/`host_ready_o` pins — a host interface *contract* with no transport behind it. | HostLink can later front the ControlCore host port (docs/07 §6); kept out of this milestone to keep the BAR ABI independent of firmware. |
| **Command queues** | HPC M06 `hpc_command_queue` (on-device ready/valid FIFO of 256-bit descriptors, in-order scheduler, MMIO adapter). It is not a host-memory queue. | HostLink queues are host-memory rings (NVMe-style). M06 can sit *behind* HostLink later (forward an opcode to its stream port). |
| **Vector/Tensor engines** | SilicaFlux-V `sfv_tile` = `sfv_vec_engine` (4-lane int32 SIMD) + `sfv_tensor_engine` (4×4 INT8 MAC, deterministic CYCLES = 3 + 2K + 4) + 16 KiB TSPM, register-page interface, legality checks built in. | `TENSOR_GEMM` drives the unmodified TE through its register page. The VE page is wired but no opcode is defined in ABI 1.0 (reserved 0x03). |
| **RTL coding rules** | `silicaflux-v/docs/RTL_CODING_RULES.md`: one SV subset for Verilator 5.020 / Icarus 12 / Yosys 0.33; flat ports, no interfaces/structs/package imports; `always_ff`/`always_comb`; async-assert/sync-release resets through `sfv_rst_sync`; sim-only code under `ifndef SYNTHESIS`. | Followed by all HostLink RTL (lint report: 0 warnings). |
| **Host OS / build environment** | Ubuntu 24.04.5, Linux 6.18 x86-64, gcc 13.3, Python 3.13, `linux/vfio.h` UAPI headers present. Installed for this project: **Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33** (the exact versions the repository's flows use). | Simulation, lint and synthesis run here; VFIO backend compiles but cannot run. |

## 2. Reuse matrix

| Reused unmodified (`third_party/`, SHA-256 verified by `make lint`) | Role in HostLink |
|---|---|
| `sfb_crossbar`, `sfb_addr_decoder`, `sfb_arbiter`, `sfb_req_mux`, `sfb_rsp_router`, `sfb_error_slave` | device DataFabric (2 masters × 2 slaves) |
| `sfb_sram_slave` + SilicaFlux SRAM Wrapper Library (`sram_sp` …) | 64 KiB device SRAM |
| `sfb_v1_slave_adapter` | TSPM port of the compute tile on SFB2 |
| `sfv_tile`, `sfv_tensor_engine`, `sfv_vec_engine`, `sfv_sram_sp`, `sfv_pkg`, `sfv_common` (`sfv_rst_sync`), `sfv_clkgate` | compute tile, reset synchronisers |
| `sfb_protocol_checker`, `PROTOCOL.md`, `RTL_CODING_RULES.md`, `ACCELERATORS.md` | reference documents |

## 3. Decision

Following the brief ("If no suitable PCIe endpoint is available, construct a functional simulated host-transport
interface and clearly mark physical PCIe integration blocked"):

* **Built**: the complete SilicaFlux side (BAR register bridge, host-memory queues, DMA descriptor engine, compute
  dispatch, interrupts, isolation), an endpoint integration wrapper with **generic AXI ports**, a
  transaction-level simulated host, a backend-independent C driver, and a VFIO hardware backend (compile-only).
* **Not built**: any PCIe protocol logic (TLPs, configuration space, link layer, MSI-X tables). Those belong to a
  verified vendor endpoint core.
* **Blocked**: physical PCIe integration, FPGA build, enumeration, BAR/DMA/MSI on hardware
  ([08_FPGA_BRINGUP.md](08_FPGA_BRINGUP.md) lists exactly what is needed to unblock it).
