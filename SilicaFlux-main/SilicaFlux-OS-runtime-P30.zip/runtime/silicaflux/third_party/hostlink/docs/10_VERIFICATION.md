# 10 — Verification

Everything below is reproducible with `make reports` (`scripts/run_all.sh`); every number in the documentation
comes from a file in `reports/`.

## 1. Layers

| Layer | What | Where |
|---|---|---|
| ABI consistency | SV package, C header, register table, register map generated from `abi/sfh_abi.py`; `--check` fails on stale outputs; C `_Static_assert`s pin every SQE/CQE field offset to the Python definition; the suite checks every register's reset value against the generated table | `make abi-check`, `t_reg_reset_values` |
| Co-simulation (main) | the real C driver drives the Verilated `sfh_device_top` through the transaction-level host model, with AXI/BAR/SFB2 protocol checkers and RTL self-checks active | `tests/test_hostlink.cpp`, `reports/cosim_results.md` |
| Independent SV testbenches | hand-written SV host (no C++ model) for the DoD flow; cycle-exact unit test of the interrupt block; both on Icarus 12 and Verilator 5 | `tb/sv/`, `reports/sv_tests.log` |
| Mutation testing | 26 realistic RTL bugs injected one at a time; each must make the suite (or the unit test) fail | `scripts/mutants.py`, `reports/mutants.md` |
| Lint / elaboration | Verilator `-Wall` (0 warnings in new RTL, 6 configurations), illegal parameter rejection, Icarus elaboration, vendored-file SHA-256 | `reports/lint.log` |
| Synthesis | Yosys 0.33 generic + xc7 mapping: no latches, `check -assert` | `reports/synth.log` |
| Hardware | **not done (blocked)** — procedure in [08_FPGA_BRINGUP.md](08_FPGA_BRINGUP.md) | — |

## 2. Brief §11 coverage

| Required | Tests |
|---|---|
| Register access | `reg_reset_values` (all 74 registers vs. ABI; all 950 unmapped offsets → all-ones + logged), `reg_access_rules` (writable masks, RO/RWL/sub-word/misaligned/burst/narrow rejection, ID echo, no read side effects), `ring_config_validation` (10 refusal cases) |
| Command submission | `nop_basic` (every CQE field), `irq_driven_completion`, all DMA/GEMM tests |
| Queue wraparound | `queue_wraparound` (6 SQ/CQ size pairs incl. 2-entry rings, random batching, phase tags), `random_regression` (random sizes 2–32) |
| DMA data integrity | `dma_integrity` (40 random transfers, both regions, independent check through a second fabric master), `dma_full_regions` (64 KiB / 16 KiB, host buffers straddling 4 KiB pages), `random_regression` (reference model of device memory) |
| Invalid descriptors | `invalid_descriptors` (31 cases: every status code, nothing accessed, nothing modified), `window_overflow` (2^64 wrap), `gemm_engine_error` |
| Host back-pressure | `host_backpressure` (10–70 % ready/valid on all five AXI channels, latency up to 240 cycles), `cq_full_backpressure` (device stalls on a full CQ), `interrupts` (g) (endpoint refuses messages) |
| Device reset | `reset_during_activity` (6 random reset points during DMA + GEMM traffic), `reset_in_flush` (reset while the flush read is outstanding: no completion written), `fatal_queue_errors`, `host_timeout`, `endpoint_reset`, `disable_drain` |
| Interrupts | `interrupts` (8 sub-cases), `irq_driven_completion`, `tb_sfh_irq` (cycle-exact races) — see [05_INTERRUPTS.md](05_INTERRUPTS.md) |
| Timeouts | `engine_timeout` (engine watchdog + recovery), `host_timeout` (host-bus watchdog, drain, endpoint reset) |
| Error recovery | `data_bus_errors` (SLVERR on read/write, IOMMU fault; device continues), `fatal_queue_errors` (SQ/CQ/flush errors → FATAL → reset → works), `stop_on_error`, `doorbell_validation` |
| Memory ordering | `memory_ordering` (strict vs. relaxed posted-write visibility, with and without FLUSH) |
| DataFabric integration | `fabric_contention` (second master hammering the SRAM during HostLink DMA) |
| Definition of done | `gemm_end_to_end` (K = 1…1024, signed/unsigned, accumulation across commands; engine cycles = 3 + 2K + 4), `sfh_gemm_demo_sim`, `tb_sfh_smoke` |

## 3. Bugs found by the verification (all fixed)

| Found by | Bug | Fix |
|---|---|---|
| `stop_on_error`, `doorbell_validation` | the `halt_set` pulse reached the register file one cycle late; the engine could fetch one more SQE after a failing command with `STOP_ON_ERROR` | engine blocks fetching while `halt_set` is high |
| `window_overflow` | a host range ending exactly at 2^64 was rejected (over-strict) | accept `end ≤ 2^64`, reject `end > 2^64` |
| lint parameter sweep | `MAXB = 4` elaborated into a broken design (an SQE fetch needs 8 beats) | elaboration-time parameter legality checks (10 illegal sets rejected) |
| self-review | after an engine timeout the TE controller reported done before the tile's reset synchroniser released | `REL_CYC` release wait in `sfh_te_ctl` |
| self-review, then `reset_in_flush` (written first, failed: 2 host write beats after the reset request) | a `CTRL.RESET` arriving during the flush read still let the CQE be written | `E_CQ_FILL` checks `reset_req` before issuing the CQE write |
| suite run time (130 s for one test) | driver slept for the full timeout when waiting in interrupt mode on a command without the IRQ flag | driver sets the flag itself; sleeps in bounded slices |

## 4. What is not verified

* Anything on hardware (enumeration, link, real TLP ordering, MSI-X through an OS, VFIO backend, IOMMU).
* Formal proofs (the DataFabric crossbar is formally verified upstream; HostLink has no formal proofs yet — the
  natural next targets are the doorbell arithmetic, `sfh_win_check` and the engine's "no new transaction during
  reset" property).
* Gate-level simulation and timing (no PDK / vendor flow).
* Icarus does not enforce the elaboration-time parameter checks (it ignores `$error` in generate blocks); Verilator
  and Yosys do.
* Functional coverage is argued by the test-to-requirement map above and by mutation testing, not measured with a
  coverage tool.
