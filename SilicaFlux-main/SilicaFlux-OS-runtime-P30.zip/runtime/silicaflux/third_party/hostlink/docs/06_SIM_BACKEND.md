# 06 — PCIe simulation backend (transaction-level host model)

`tb/cosim/sfh_sim.{h,cpp}` wraps the Verilated `sfh_device_top` and plays every role on the far side of the
endpoint's AXI ports: **endpoint IP + root complex + IOMMU + host memory + CPU MMIO**. It is a transaction-level
model of the *effects* of PCIe that matter to HostLink (posted vs. non-posted ordering, completion errors,
latency, back-pressure, interrupt messages, resets) — not a PCIe protocol model; no TLPs, DLLPs or link training
are simulated, and nothing here verifies PCIe compliance.

## 1. What is modelled

| Feature | Model |
|---|---|
| BAR reads/writes | AXI4 master on the shell's BAR port (random AxID). Read SLVERR → CPU sees `0xFFFFFFFF` (completer abort). Raw API for bursts / narrow sizes / chosen IDs. |
| Host memory | real C++ allocations; the driver's "VA" is a pointer the test can read directly |
| IOMMU | page table IOVA → host page; IOVAs from `0x1_0000_0000` with an unmapped guard page after every allocation; unmapped access → DECERR + fault log; pages can be unmapped on the fly |
| Read path | AR accepted with probability `ar_ready_pct`; first R beat after `rd_latency` cycles; R beats valid with `r_valid_pct`; held stable until RREADY |
| Write path | AW / W ready with `aw/w_ready_pct`; B after `wr_latency` with `b_valid_pct`; on OKAY the data enters the **posted-write queue** |
| Posted-write visibility | each write becomes CPU-visible after a delay in `[post_delay_min, post_delay_max]`; **strict** mode: in order (PCIe, RO = 0); **relaxed** mode: any order (RO = 1). A device read request first makes every earlier posted write visible (a read never passes posted writes). |
| Interrupts | `irq_ready` with `irq_ready_pct` or forced 0/1; an accepted request becomes an MSI entry in the posted queue (never passes older writes) and is delivered to `irq_pending` (per vector) |
| Command submission / completion polling | through the real C driver (`sw/lib/sfh_driver.c`) via `sfh_sim_backend_ops()`; `relax()` advances 4 cycles; `now_us()` = cycles / 250 (250 MHz core clock assumed) |
| Failure injection | SLVERR/DECERR on address ranges for reads or writes (count-limited), host stall (no AR/AW accepted, no responses), IOMMU unmap, endpoint not accepting interrupts, endpoint reset (`ep_reset`), relaxed ordering |
| Second DataFabric master | self-checking random read/write traffic on a device range (contention) + blocking backdoor reads/writes (independent check of device memory) |
| Protocol checkers | AR/AW/W payload stable until handshake; AxSIZE = 3, INCR, AxID = 0, ≤ 16 beats, no 4 KiB crossing, 8-byte aligned; WSTRB = FF; WLAST position; W without AW; BAR RID/BID echo and RLAST position; RTL `$error` self-checks abort the run |
| Tracing | `--trace` writes a VCD of the whole device |

## 2. Same ABI on simulated and hardware backends

```
                 tests/test_hostlink.cpp        sw/examples/sfh_gemm_demo.c
                              \                   /
                         sw/lib/sfh_driver.c  (backend independent)
                          /                         \
   sfh_sim_backend_ops (tb/cosim)          sfh_vfio_backend_ops (sw/backends)
   Verilated RTL + host model              /dev/vfio, BAR0 mmap, IOMMU map, eventfd MSI-X
   RUNS (this project)                     COMPILES; NOT RUN (no hardware)
```

`struct sfh_backend_ops` = `mmio_read32`, `mmio_write32`, `dma_alloc`, `dma_free`, `wait_irq`, `relax`, `now_us`.
The demo binary for both backends is built from the identical `sfh_gemm_demo.c` object.

## 3. Running

```bash
make test                      # suite (SEEDS=2 by default) + demo, logs in reports/
build/test_hostlink --list     # 29 tests and what each covers
build/test_hostlink --filter interrupts --trace   # one test with a VCD
build/sfh_gemm_demo_sim --backpressure            # demo under 50 % AXI back-pressure
```
