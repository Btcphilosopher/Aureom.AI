# 02 — Driver-facing ABI specification (version 1.0)

Normative contract between a host driver and SilicaFlux HostLink. Single source of truth:
[`abi/sfh_abi.py`](../abi/sfh_abi.py); the RTL package, the C header
[`generated/silicaflux_hostlink_abi.h`](../generated/silicaflux_hostlink_abi.h) and the register map
([03_REGISTER_MAP.md](03_REGISTER_MAP.md)) are generated from it (`make abi-check` fails if any is stale). The
reference driver is [`sw/lib/sfh_driver.c`](../sw/lib/sfh_driver.c). All values little-endian.

## 1. Versioning and discovery

* `ID` (BAR0 `0x000`) reads `0x5346484C` ("SFHL"). A driver must refuse a function whose `ID` differs.
* `VERSION[31:16]` = ABI major, `[15:0]` = minor. A driver supports exactly one major; a higher minor only adds
  registers, capability bits, opcodes or status codes in reserved space. **Reserved fields must be written as 0**
  (the device rejects non-zero reserved SQE fields with `INVALID_FIELD`, so they stay usable for future minors).
* `CAPS` lists implemented features; `LIMITS`, `DEVMEM0/1_BASE/SIZE` describe the instance. A driver must read
  them instead of assuming the reference configuration.
* PCI vendor/device IDs, class code and BAR sizes are configured in the endpoint IP and are **not assigned yet**
  (see [07_ENDPOINT_INTEGRATION.md](07_ENDPOINT_INTEGRATION.md)); drivers bind by ID and confirm with the `ID`
  register.

## 2. BAR0 access rules

BAR0 is 4 KiB of 32-bit registers (non-prefetchable memory BAR). Only aligned 32-bit reads and writes are legal.
Sub-word writes, misaligned offsets, bursts, writes to read-only or currently locked registers and accesses to
unlisted offsets are **rejected**: no state change, `ERR_STATUS.REG_ACCESS` (or `.DOORBELL`) set,
`ERR_REG_OFFSET` records the offset, an `ERROR` interrupt event is raised. A rejected **read** returns all-ones
to the CPU (completer abort). No register has a read side effect. Full map: [03_REGISTER_MAP.md](03_REGISTER_MAP.md).

## 3. Initialisation sequence

```
1  ID == 'SFHL' and VERSION.MAJOR == 1, read CAPS, LIMITS, DEVMEM*
2  CTRL = RESET; poll STATUS until RESETTING = 0 and IDLE = 1
3  allocate SQ (64 B x 2^s) and CQ (16 B x 2^c) in DMA-able memory, 64-byte aligned, IOMMU-mapped;
   zero the CQ (phase 0 everywhere)
4  SQ_BASE_LO/HI, SQ_SIZE = s; CQ_BASE_LO/HI, CQ_SIZE = c                     (RWL registers)
5  WINn_BASE/SIZE/CTRL for every host range the device may touch (4 KiB granular):
     reference driver: WIN0 = SQ ring, DEV_READ only;  WIN1 = CQ ring, DEV_WRITE only;
                       WIN2/3 = data buffers with the permissions they need
6  INT_VECTOR, INT_STATUS = 3 (clear), INT_ENABLE (0 for pure polling)
7  CTRL = ENABLE [| FLUSH_ALL] [| STOP_ON_ERROR]; read STATUS.ENABLED: 0 => ERR_STATUS.RING_CONFIG
   (size out of range, ring not inside a window with the right permission, or SQ/CQ overlap)
8  driver state: sq_tail = 0, cq_head = 0, expected phase = 1
```
Enabling resets `SQ_HEAD`, `SQ_TAIL`, `CQ_TAIL`, `CQ_HEAD` to 0 and `CQ_PHASE` to 1. `CTRL.ENABLE` 0→1 is refused
while the engine is not idle. RWL registers (ring and window registers) can only be written while
`STATUS.ENABLED = 0`, `IDLE = 1`, `RESETTING = 0`.

## 4. Submission queue entry (SQE, 64 bytes)

| Dword | Bits | NOP | DMA | TENSOR_GEMM |
|---|---|---|---|---|
| 0 | [7:0] | opcode `0x00` | opcode `0x01` | opcode `0x02` |
| 0 | [15:8] | flags | flags | flags |
| 0 | [23:16] | 0 | `dir`: 1 = H2D, 2 = D2H | 0 |
| 0 | [31:24] | 0 | 0 | 0 |
| 1 | | `txn_id` | `txn_id` | `txn_id` |
| 2–3 | | 0 | `src` (64-bit) | dw2 `a_off`, dw3 `b_off` |
| 4–5 | | 0 | `dst` (64-bit) | dw4 `c_off`, dw5 `k` (1..1024) |
| 6 | | 0 | `length` (bytes) | `a_stride` (0 = 4) |
| 7 | | 0 | 0 | `b_stride` (0 = 4) |
| 8 | | 0 | 0 | `c_stride` (0 = 16) |
| 9 | | 0 | 0 | `te_flags`: [0] ACC, [1] A_UNSIGNED, [2] B_UNSIGNED |
| 10–15 | | 0 | 0 | 0 |

**Flags** (`dw0[15:8]`): bit 0 `IRQ` — raise `INT_STATUS.CQ` (and a message) when this entry completes; bit 1
`FLUSH` — flush-read before posting this completion (§7.3). Other bits reserved (must be 0).

**DMA**: H2D copies `length` bytes from host IOVA `src` to device address `dst`; D2H from device address `src` to
host IOVA `dst`. `src`, `dst`, `length` multiples of 8; `1 ≤ length ≤ 2^LIMITS.MAX_DMA_LOG2` (1 MiB). The device
range must lie inside one `DEVMEM` region (upper 32 bits 0); the host range inside one enabled window with
`DEV_READ` (H2D) or `DEV_WRITE` (D2H). Scatter-gather is **not implemented** (`CAPS.SCATTER_GATHER = 0`): a
scattered buffer is submitted as several DMA entries.

**TENSOR_GEMM**: `C[4×4] (+)= A[4×K] · B[K×4]`, int8/uint8 → int32 on the SilicaFlux-V tensor engine. Offsets are
**TSPM byte offsets** (0 .. `DEVMEM1_SIZE`-1), not fabric addresses: A column-major (word `k` at
`a_off + k·a_stride` holds `A[0..3][k]`), B row-major (word `k` holds `B[k][0..3]`), C written back as 4 rows of
4 int32 at `c_off + i·c_stride` (16-byte aligned). `ACC` accumulates onto the engine accumulators of the previous
GEMM (K-splitting); a reset of the tile clears them. Operand legality is checked by the engine itself.

## 5. Completion queue entry (CQE, 16 bytes)

| Dword | Bits | Field |
|---|---|---|
| 0 | | `txn_id` of the SQE |
| 1 | | `result`: DMA = bytes completed (contiguous prefix, also on error); GEMM = engine cycles (SUCCESS) or engine error code (`ENGINE_ERROR`: 1 ALIGN, 2 RANGE, 3 BADOP, 4 BUSY); otherwise 0 |
| 2 | [15:0] | `sq_head`: device SQ head after consuming this entry (frees SQ slots) |
| 2 | [23:16] | opcode of the SQE |
| 3 | [15:0] | `status` (table below) |
| 3 | [16] | `phase` — written last; toggles each time the CQ wraps; first pass = 1 |

| Status | Code | Meaning |
|---|---|---|
| SUCCESS | 0x00 | completed |
| INVALID_OPCODE | 0x01 | opcode not implemented (0x03 VECTOR is reserved) |
| INVALID_FIELD | 0x02 | reserved field/bit ≠ 0, unknown flag, bad `dir`, device address ≥ 4 GiB |
| INVALID_LENGTH | 0x03 | DMA length 0 or > 2^MAX_DMA_LOG2 |
| MISALIGNED | 0x04 | DMA src/dst/length not multiples of 8 |
| HOST_ADDR_DENIED | 0x05 | host range not inside a permitted window, or it wraps past 2^64 |
| DEV_ADDR_INVALID | 0x06 | device range not inside one DEVMEM region, or wraps past 2^32 |
| HOST_BUS_ERROR | 0x07 | host bus answered SLVERR/DECERR on a data transfer (IOMMU fault, UR, CA) |
| DEV_BUS_ERROR | 0x08 | DataFabric `rsp_error` on a device access |
| ENGINE_ERROR | 0x09 | tensor engine refused the parameters (`result` = engine code) |
| ENGINE_TIMEOUT | 0x0A | tensor engine exceeded `TIMEOUT` cycles; the tile was reset |

Validation order is the table order (first failing check reports). Statuses 0x01–0x06 are produced **before any
memory access**: a rejected command reads and writes nothing. Every SQE produces exactly one CQE, in submission
order, except when the device becomes FATAL or is reset (§8).

## 6. Queue protocol

* **Indices**: `N = 2^SIZE` entries; indices are `0 .. N-1`. SQ: host owns `TAIL`, device owns `HEAD`. CQ: device
  owns `TAIL`, host owns `HEAD`.
* **Empty / full**: SQ empty when `HEAD == TAIL`, full when `(TAIL + 1) mod N == HEAD` (one slot unused). The host
  learns `HEAD` from `CQE.sq_head` (or the `SQ_HEAD` register). CQ full for the device when
  `(CQ_TAIL + 1) mod N == CQ_HEAD`: the engine then **stalls** (no CQE is ever overwritten); `STATUS.CQ_FULL`
  and the `CQ_FULL_CYCLES` counter show the back-pressure.
* **Ownership**: CQ ownership is carried by the **phase tag** (generation bit). An entry belongs to the host when
  its phase equals the expected phase; the expected phase starts at 1 and flips when the host's `cq_head` wraps.
  No SQ ownership bit is needed: an SQE belongs to the device from the doorbell until `sq_head` passes it.
* **Doorbells** (BAR0 writes): `SQ_TAIL = new tail` after writing the entries; `CQ_HEAD = new head` after
  consuming entries. Batching is allowed (several SQEs, one doorbell). Doorbells are validated:
  * `SQ_TAIL`: accepted only while enabled, value `< N`, bits [31:12] = 0, and the number of pending entries must
    not decrease: `(new − HEAD) mod N ≥ (old − HEAD) mod N`;
  * `CQ_HEAD`: accepted only while enabled, value `< N`, and not past the device tail:
    `(new − old) mod N ≤ (CQ_TAIL − old) mod N`.
  A rejected doorbell changes nothing and sets `ERR_STATUS.DOORBELL`.
* **Queue reset**: `CTRL.ENABLE` 1→0 stops fetching after the command in flight has posted its CQE (wait for
  `STATUS.IDLE`); re-enabling resets all indices (entries not yet fetched are dropped). `CTRL.RESET` resets the
  whole function (§8).
* **Ordering**: strictly in order, one command executing at a time.

## 7. Memory ordering

### 7.1 Host → device (submission)

1. Write the SQE(s) to the ring with ordinary stores (the ring is DMA-coherent memory: normal cacheable memory on
   x86 and on cache-coherent PCIe platforms; `dma_alloc_coherent`-type memory where DMA is not coherent).
2. **Write barrier** ordering those stores before the MMIO doorbell: `sfh_wmb()` = `sfence` (x86) /
   `dmb oshst` (arm64) — the equivalent of Linux `wmb()`/`dma_wmb()` before `writel()`.
3. Write `SQ_TAIL`. The device reads the SQE only after it has received the doorbell, so it sees the complete
   entry. The host must not modify an SQE until `CQE.sq_head` has passed it.

### 7.2 Device → host (completion)

HostLink guarantees, inside the device:

* an H2D command completes only after **every** device write was acknowledged by the DataFabric (SFB2 rule R7:
  the write has been performed);
* a D2H command completes only after the B response of **every** host write burst; then the CQE is written as one
  16-byte, 16-byte-aligned burst whose last dword carries the phase tag, and only after its B response is the
  interrupt event raised;
* all host writes use AXI ID 0 (one ordered stream) and are issued strictly one after another.

The completion is visible to the host before or with the data **only under the selected protocol assumption**:
PCIe posted writes from one requester, in one traffic class, **without the Relaxed Ordering attribute**, are not
reordered. Therefore:

* the endpoint integration must map HostLink's AXI writes to posted write TLPs **in AXI order**, with Relaxed
  Ordering **cleared** (or not set for the AXI bridge path), in a single traffic class;
* if that cannot be guaranteed (RO enabled by the IP or by the platform for performance), set
  **`CTRL.FLUSH_ALL`** or the **`FLUSH` SQE flag**: before writing the CQE the device performs a 1-beat read of the
  just-consumed SQ slot. PCIe ordering forbids a read request from passing earlier posted writes, so when its
  completion returns, every earlier data write has reached the root complex; the CQE is written afterwards.

The simulator models both cases: with relaxed ordering and no flush the test suite observes stale data in 13–17
of 30 completions; with `FLUSH` / `FLUSH_ALL`, never (`t_memory_ordering`, `reports/cosim.log`).

### 7.3 Host consumption

Read CQE dword 3 first; if `phase` ≠ expected, the entry is not yet valid. Otherwise **read barrier**
(`sfh_rmb()` = `lfence` / `dmb oshld`), then read dwords 0–2 and the DMA'd data. Release the slot with the
`CQ_HEAD` doorbell. The phase-first protocol assumes that the CQE (one TLP of 16 bytes inside one cache line)
becomes visible to the CPU as a unit — the same assumption NVMe relies on; the PCIe specification itself does not
guarantee atomic visibility of a TLP's payload, root complexes in practice provide it per cache line.

### 7.4 Interrupts

A message is requested only after the CQE write (and optional flush) completed. The endpoint delivers the message
as a posted memory write; it must not overtake the CQE write (same requirement as §7.2; `FLUSH_ALL` closes it if the
IP cannot guarantee it). Interrupts are a wake-up hint: the CQ phase tags are the only source of truth.

## 8. Errors, fatal state and reset

| Situation | Device behaviour | Driver action |
|---|---|---|
| invalid SQE (status 0x01–0x06) | error CQE, nothing touched; `ERR_STATUS.CMD_ERROR`, `ERR_CMD` = status + SQ index; `INT_STATUS.CQ` | report per command; continue |
| host/device bus error on data | error CQE with bytes done; `ERR_ADDR` | report; continue |
| engine error / timeout | error CQE; timeout also sets `ERR_STATUS.ENGINE_TIMEOUT`, resets the tile | continue (ACC state lost) |
| bus error on SQ fetch, CQ write or flush; any host-bus timeout | **FATAL**: `STATUS.FATAL`, `ERR_STATUS.HOST_BUS`/`HOST_TIMEOUT`, `ERR_ADDR`, ERROR interrupt; no further fetches; the command in flight never completes | `CTRL.RESET`, re-initialise, resubmit what was not completed |
| `STOP_ON_ERROR` set and a command fails | queue halts after posting that CQE (`STATUS.HALTED`) | inspect, then write `CTRL` with `ENABLE=1` to resume |
| `CTRL.RESET` | finishes the bus transaction in flight (≤ one 128-byte burst and one fabric word), then every register except the PERF counters returns to its reset value and the compute tile is reset; nothing reaches host memory afterwards | poll `STATUS` (`RESETTING=0`, `IDLE=1`) with a timeout |
| host never answers an outstanding transaction | `CTRL.RESET` waits (`RESETTING` stays 1): AXI cannot cancel | function-level / hot reset through the endpoint (resets everything including counters) |

`TIMEOUT` (core cycles, default 2^20) bounds every host-bus transaction and every engine command; 0 disables the
watchdog (debug only).

## 9. Buffer ownership and DMA mapping rules

* Every host address in an SQE, and the SQ/CQ bases, are **IOVAs** from the OS DMA API / VFIO, never CPU physical
  addresses chosen by the device.
* A buffer is owned by the device from the doorbell that submits a command using it until that command's CQE has
  been consumed. The driver must not unmap, free or reuse it in between (an IOMMU fault would be reported as
  `HOST_BUS_ERROR`, but data could already have been read).
* Windows are coarse, programmed only while the queues are disabled; per-buffer protection is the IOMMU's job
  ([04_DMA_AND_ISOLATION.md](04_DMA_AND_ISOLATION.md)).

## 10. Minimal driver loop (C, any backend)

```c
struct sfh_dev d;  struct sfh_sqe e;  struct sfh_cqe c;
sfh_open(&d, ops, ctx);                  /* ID, VERSION, CAPS, LIMITS          */
sfh_reset(&d, 100000);
sfh_queues_alloc(&d, 6, 6);              /* rings + windows 0/1 (least privilege) */
sfh_set_window(&d, 2, buf.iova, buf.size, VALID | DEV_READ | DEV_WRITE);
sfh_irq_setup(&d, 1);                    /* CQ -> vector 0, ERROR -> vector 1  */
sfh_enable(&d, 0);
sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, buf.iova, d.devmem_base[1], 256, 0);
sfh_run(&d, &e, &c, 100000);             /* push, wmb, doorbell, wait CQE      */
if (SFH_CQE_STATUS(c.dw3) != SFH_STATUS_SUCCESS) ...
```
