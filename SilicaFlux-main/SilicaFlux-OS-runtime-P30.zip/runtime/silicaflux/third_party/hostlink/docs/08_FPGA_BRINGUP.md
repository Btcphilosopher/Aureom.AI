# 08 — FPGA bring-up

## Status: **BLOCKED**

| Bring-up step (brief §9) | Status | Blocker |
|---|---|---|
| Integrate real endpoint IP | blocked | no PCIe-capable board, no vendor IP/tools in this environment ([00_AUDIT.md](00_AUDIT.md)) |
| Apply vendor constraints | blocked | depends on board (PCIe lane pins, reference clock, PERST#) |
| Build the design | blocked | vendor synthesis + place & route; only Yosys mapping estimates exist (`reports/synth.log`) |
| Confirm device enumeration | blocked | no hardware |
| Verify BAR access | blocked (simulated: PASS) | |
| Run loopback DMA | blocked (simulated: PASS) | |
| Test interrupts | blocked (simulated: PASS) | |
| Run a small TensorCore workload | blocked (simulated: PASS, `sfh_gemm_demo`) | |
| Capture logs and negotiated link properties | **no logs exist** — none are claimed | |

No hardware log, link speed, link width or enumeration result exists for this project. The commands and the
acceptance criteria below are the procedure to produce them.

## 1. What is needed

1. A board whose FPGA has PCIe hard IP and SERDES routed to a PCIe edge connector (any current AMD, Intel or
   Lattice PCIe development card); its vendor tool and the endpoint IP licence.
2. A Linux host with an IOMMU enabled (`intel_iommu=on` / `amd_iommu=on`), VFIO (`vfio-pci`), and a free slot.
3. Assigned PCI vendor/device IDs (or the vendor's evaluation IDs for lab use).

## 2. Integration steps

1. Generate the endpoint IP in AXI-bridge configuration satisfying E1–E10 of
   [07_ENDPOINT_INTEGRATION.md](07_ENDPOINT_INTEGRATION.md) (BAR0 4 KiB+, identity slave-bridge translation, RO off,
   MSI-X ≥ 2 vectors, 64-bit addressing).
2. Write a board top: endpoint IP + AXI width/clock converters + `sfh_device_top` (define `SFV_NO_CLOCK_GATE`,
   use the FPGA SRAM backend of the SilicaFlux SRAM library for the 64 KiB SRAM and the TSPM).
3. Apply the board's vendor constraints (PCIe lanes, refclk, PERST#), constrain the user clock, close timing.
4. Run the same RTL simulation regression before building (`make lint test sv-smoke`).

## 3. Bring-up procedure and acceptance criteria (logs to capture)

| Step | Command | Pass criterion |
|---|---|---|
| enumeration | `lspci -nn -d <vid>:<did>` and `lspci -vv -s <bdf>` | device listed; BAR0 size ≥ 4 KiB; MSI-X capability present |
| link | `lspci -vv -s <bdf> \| grep -E 'LnkCap\|LnkSta'` | negotiated speed/width as configured (record both LnkCap and LnkSta) |
| IOMMU group | `readlink /sys/bus/pci/devices/<bdf>/iommu_group` | group contains only this function (else ACS issue) |
| bind | `vfio-pci` bind (see `sw/examples/sfh_vfio_main.c`) | `/dev/vfio/<group>` exists |
| BAR access | `sfh_gemm_demo_vfio <bdf>` first lines | `ID 'SFHL' ABI 1.0`, CAPS/LIMITS as built |
| loopback DMA | demo "DMA" line | 64 KiB H2D + D2H round trip bit exact; record B/cycle |
| interrupts | demo "IRQ_MSGS", `cat /proc/interrupts` (vfio-msix lines) | message count equals completions requested; no lost wake-up |
| TensorCore | demo GEMM block | `PASS ... bit exact`, engine cycles = 3 + 2K + 4 |
| ordering | rerun with `CTRL.FLUSH_ALL` off and on, large D2H stress | no stale data in either; if stale data appears without flush, the IP violates E3 → ship with FLUSH_ALL |
| error paths | demo variants: window miss, unmapped IOVA | `HOST_ADDR_DENIED`; `HOST_BUS_ERROR` + IOMMU fault in `dmesg` |
| reset | VFIO `VFIO_DEVICE_RESET` (FLR) during traffic | device returns to reset values; no DMA after reset |

All of the above must be recorded verbatim in `reports/hw_bringup.md` before hardware functionality is claimed.
