// =============================================================================
// SilicaFlux HostLink :: sfh_engine -- submission/completion queue engine
//
// Strictly in-order, one command in flight:
//   FETCH    read the 64-byte SQE at SQ_BASE + HEAD*64 (one 8-beat burst)
//   DECODE   sfh_cmd_validate; a rejected command touches no memory
//   EXECUTE  NOP | DMA (chunked: <= MAXB beats, never across a host 4 KiB
//            boundary; H2D = host burst read -> SFB2 word writes, each write
//            acknowledged before the next; D2H = SFB2 word reads -> host
//            burst write, B response awaited) | TENSOR_GEMM (sfh_te_ctl)
//   CQ_WAIT  host back-pressure: wait while the CQ is full
//   FLUSH    optional 1-beat read of the consumed SQE slot: PCIe ordering
//            forbids a read request from passing earlier posted writes, so
//            its completion proves all earlier data writes reached the root
//            complex (needed only when relaxed ordering may reorder writes)
//   CQ_POST  write the 16-byte CQE (one 2-beat burst, 16-byte aligned, phase
//            tag in the last dword) and wait for its B response; only then
//            advance CQ_TAIL and raise the CQ interrupt event
// Completion is therefore never reported before the command's device writes
// were acknowledged by the DataFabric (SFB2 rule R7) and its host writes were
// accepted by the endpoint, ordered ahead of the CQE (docs/02_DRIVER_ABI.md
// section "Memory ordering").
//
// Errors: data-transfer errors fail the command (status in its CQE).  A host-
// bus error or timeout on queue memory (SQ fetch, CQ write, flush) or any
// host-bus timeout is FATAL: no further commands, STATUS.FATAL, ERROR
// interrupt; recovery = CTRL.RESET.
// Reset (CTRL.RESET): the engine finishes the bus transaction in flight (AXI
// and SFB2 have no cancel), never the command; then pulses `srst` (register
// file, interrupt block, TE controller) and holds the compute tile in reset.
// =============================================================================
`default_nettype none

module sfh_engine #(
  parameter int          NW           = 4,
  parameter int          MAXB         = 16,
  parameter int          MAX_DMA_LOG2 = 20,
  parameter logic [31:0] DM0_BASE     = 32'h1000_0000,
  parameter logic [31:0] DM0_SIZE     = 32'h0001_0000,
  parameter logic [31:0] DM1_BASE     = 32'h2000_0000,
  parameter logic [31:0] DM1_SIZE     = 32'h0000_4000,
  parameter int          RST_CYC      = 4,
  localparam int         BIW          = $clog2(MAXB),
  localparam int         NPC          = 10
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ------------------------------------------------------------ configuration (sfh_bar_regs)
  input  wire logic              enabled,
  input  wire logic              flush_all,
  input  wire logic              stop_on_err,
  input  wire logic [31:0]       timeout,
  input  wire logic [63:0]       sq_base,
  input  wire logic [3:0]        sq_log2,
  input  wire logic [63:0]       cq_base,
  input  wire logic [3:0]        cq_log2,
  input  wire logic [NW*64-1:0]  win_base,
  input  wire logic [NW*64-1:0]  win_size,
  input  wire logic [NW*3-1:0]   win_ctrl,
  input  wire logic [11:0]       sq_tail,
  input  wire logic [11:0]       cq_head,
  input  wire logic              q_init,
  input  wire logic              reset_req,
  input  wire logic              halted,
  // ------------------------------------------------------------ status / events (sfh_bar_regs)
  output logic                   srst,
  output logic                   idle,
  output logic                   fatal,
  output logic                   cq_full,
  output logic [3:0]             state,
  output logic [11:0]            sq_head,
  output logic [11:0]            cq_tail,
  output logic                   cq_phase,
  output logic                   halt_set,
  output logic                   ev_cq,
  output logic                   ev_host_bus,
  output logic                   ev_host_tmo,
  output logic                   ev_cmd_err,
  output logic                   ev_eng_tmo,
  output logic [63:0]            err_addr,
  output logic [15:0]            err_cmd_status,
  output logic [15:0]            err_cmd_sqidx,
  output logic [NPC*16-1:0]      perf_inc,
  // ------------------------------------------------------------ AXI4 master to host memory
  output logic                   m_awvalid,
  input  wire logic              m_awready,
  output logic [63:0]            m_awaddr,
  output logic [7:0]             m_awlen,
  output logic [2:0]             m_awsize,
  output logic [1:0]             m_awburst,
  output logic [3:0]             m_awid,
  output logic                   m_wvalid,
  input  wire logic              m_wready,
  output logic [63:0]            m_wdata,
  output logic [7:0]             m_wstrb,
  output logic                   m_wlast,
  input  wire logic              m_bvalid,
  output logic                   m_bready,
  input  wire logic [1:0]        m_bresp,
  input  wire logic [3:0]        m_bid,
  output logic                   m_arvalid,
  input  wire logic              m_arready,
  output logic [63:0]            m_araddr,
  output logic [7:0]             m_arlen,
  output logic [2:0]             m_arsize,
  output logic [1:0]             m_arburst,
  output logic [3:0]             m_arid,
  input  wire logic              m_rvalid,
  output logic                   m_rready,
  input  wire logic [63:0]       m_rdata,
  input  wire logic [1:0]        m_rresp,
  input  wire logic              m_rlast,
  input  wire logic [3:0]        m_rid,
  // ------------------------------------------------------------ SFB2 master (DataFabric)
  output logic                   f_req_valid,
  input  wire logic              f_req_ready,
  output logic                   f_req_write,
  output logic [31:0]            f_req_addr,
  output logic [31:0]            f_req_wdata,
  output logic [3:0]             f_req_wstrb,
  input  wire logic              f_rsp_valid,
  output logic                   f_rsp_ready,
  input  wire logic [31:0]       f_rsp_rdata,
  input  wire logic              f_rsp_error,
  // ------------------------------------------------------------ tensor engine register page
  output logic                   te_sel,
  output logic                   te_rb_we,
  output logic [11:0]            te_rb_addr,
  output logic [31:0]            te_rb_wdata,
  input  wire logic [31:0]       te_rdata,
  output logic                   tile_rst_req
);
  typedef enum logic [3:0] {
    E_IDLE = 4'd0, E_FETCH = 4'd1, E_DECODE = 4'd2, E_DMA_NEXT = 4'd3, E_HOST_RD = 4'd4,
    E_DEV_NEXT = 4'd5, E_DEV_REQ = 4'd6, E_DEV_RSP = 4'd7, E_HOST_WR = 4'd8, E_TE = 4'd9,
    E_CQ_WAIT = 4'd10, E_FLUSH = 4'd11, E_CQ_FILL = 4'd12, E_CQ_POST = 4'd13, E_FATAL = 4'd14,
    E_RESET = 4'd15
  } est_e;
  est_e st;

  // ---------------------------------------------------------------- state
  logic [11:0]  sq_head_q, cq_tail_q, cur_idx_q;
  logic         phase_q, fatal_q, tmo_seen_q, fill_q;
  logic [511:0] sqe_q;
  logic [15:0]  cpl_st_q;
  logic [31:0]  cpl_res_q;
  logic [63:0]  cpl_addr_q;
  logic [63:0]  host_ptr_q;
  logic [31:0]  dev_ptr_q, remain_q, done_q;
  logic [7:0]   chunk_q;
  logic [5:0]   words_q, widx_q;
  logic         h2d_q;
  logic [3:0]   rcnt_q;
  logic [63:0]  hp_addr_q;

  wire [11:0] sq_mask = 12'((32'd1 << sq_log2) - 32'd1);
  wire [11:0] cq_mask = 12'((32'd1 << cq_log2) - 32'd1);
  wire        cq_is_full = (((cq_tail_q + 12'd1) & cq_mask) == cq_head);

  // ---------------------------------------------------------------- validation
  logic [15:0] v_status;
  logic        v_nop, v_dma, v_gemm, v_h2d;
  logic [63:0] v_host;
  logic [31:0] v_dev, v_len, v_txn;
  logic [7:0]  v_op, v_flags;
  sfh_cmd_validate #(
    .NW(NW), .MAX_DMA_LOG2(MAX_DMA_LOG2),
    .DM0_BASE(DM0_BASE), .DM0_SIZE(DM0_SIZE), .DM1_BASE(DM1_BASE), .DM1_SIZE(DM1_SIZE)
  ) u_val (
    .sqe(sqe_q), .win_base, .win_size, .win_ctrl,
    .status(v_status), .is_nop(v_nop), .is_dma(v_dma), .is_gemm(v_gemm), .h2d(v_h2d),
    .host_addr(v_host), .dev_addr(v_dev), .length(v_len), .opcode(v_op), .flags(v_flags), .txn_id(v_txn)
  );
  wire unused_v = v_nop ^ v_gemm ^ (^v_flags);

  // ---------------------------------------------------------------- tensor-engine controller
  logic        te_start, te_done, te_running, te_rst;
  logic [15:0] te_st;
  logic [31:0] te_res;
  sfh_te_ctl #(.RST_CYC(RST_CYC)) u_te (
    .clk, .rst_n, .srst,
    .start(te_start),
    .p_a(sqe_q[sfh_abi_pkg::SQE_A_OFF_DW*32 +: 32]), .p_b(sqe_q[sfh_abi_pkg::SQE_B_OFF_DW*32 +: 32]),
    .p_c(sqe_q[sfh_abi_pkg::SQE_C_OFF_DW*32 +: 32]), .p_k(sqe_q[sfh_abi_pkg::SQE_K_DW*32 +: 32]),
    .p_as(sqe_q[sfh_abi_pkg::SQE_A_STRIDE_DW*32 +: 32]), .p_bs(sqe_q[sfh_abi_pkg::SQE_B_STRIDE_DW*32 +: 32]),
    .p_cs(sqe_q[sfh_abi_pkg::SQE_C_STRIDE_DW*32 +: 32]),
    .p_flags(sqe_q[sfh_abi_pkg::SQE_TE_FLAGS_DW*32 +: 3]),
    .timeout, .done(te_done), .st_out(te_st), .result(te_res), .running(te_running),
    .tile_rst_req(te_rst),
    .te_sel, .rb_we(te_rb_we), .rb_addr(te_rb_addr), .rb_wdata(te_rb_wdata), .te_rdata
  );

  // ---------------------------------------------------------------- host port
  logic             hp_valid, hp_ready, hp_write, hp_done, hp_err, hp_idle, hp_tmo;
  logic [63:0]      hp_addr;
  logic [BIW:0]     hp_beats;
  logic             bw_en;
  logic [BIW-1:0]   bw_idx;
  logic [1:0]       bw_hmask;
  logic [63:0]      bw_data;
  logic [MAXB*64-1:0] buf_flat;
  sfh_host_port #(.MAXB(MAXB)) u_hp (
    .clk, .rst_n,
    .req_valid(hp_valid), .req_ready(hp_ready), .req_write(hp_write), .req_addr(hp_addr),
    .req_beats(hp_beats), .done(hp_done), .done_err(hp_err), .idle(hp_idle),
    .timeout, .tmo(hp_tmo),
    .bw_en, .bw_idx, .bw_hmask, .bw_data, .buf_flat,
    .m_awvalid, .m_awready, .m_awaddr, .m_awlen, .m_awsize, .m_awburst, .m_awid,
    .m_wvalid, .m_wready, .m_wdata, .m_wstrb, .m_wlast,
    .m_bvalid, .m_bready, .m_bresp, .m_bid,
    .m_arvalid, .m_arready, .m_araddr, .m_arlen, .m_arsize, .m_arburst, .m_arid,
    .m_rvalid, .m_rready, .m_rdata, .m_rresp, .m_rlast, .m_rid
  );
  wire unused_hp = hp_ready;

  // ---------------------------------------------------------------- chunking
  wire [12:0] to4k     = 13'd4096 - {1'b0, host_ptr_q[11:0]};
  wire [31:0] maxc     = 32'(MAXB * 8);
  wire [31:0] c1       = (remain_q < maxc) ? remain_q : maxc;
  wire [31:0] chunk_n  = (c1 < {19'd0, to4k}) ? c1 : {19'd0, to4k};
  wire [63:0] sq_slot  = sq_base + {46'd0, cur_idx_q, 6'd0};
  wire [63:0] fetch_a  = sq_base + {46'd0, sq_head_q, 6'd0};
  wire [63:0] cq_slot  = cq_base + {48'd0, cq_tail_q, 4'd0};
  wire [31:0] word_a   = dev_ptr_q + {24'd0, widx_q, 2'b00};
  wire        sqe_irq   = sqe_q[sfh_abi_pkg::SQE_FLAGS_LSB + sfh_abi_pkg::SQE_FLAG_IRQ_BIT];
  wire        sqe_flush = sqe_q[sfh_abi_pkg::SQE_FLAGS_LSB + sfh_abi_pkg::SQE_FLAG_FLUSH_BIT];
  // halt_set is a registered pulse that reaches the register file one cycle
  // later: block fetching in that cycle too (found by t_stop_on_error)
  wire        can_fetch = enabled && !halted && !halt_set && !fatal_q && !reset_req && (sq_head_q != sq_tail);
  wire        cpl_fail  = (cpl_st_q != sfh_abi_pkg::ST_SUCCESS);
  wire [31:0] cqe_dw2   = {8'd0, v_op, 4'd0, sq_head_q};
  wire [31:0] cqe_dw3   = {15'd0, phase_q, cpl_st_q};

  // ---------------------------------------------------------------- combinational outputs
  always_comb begin
    hp_valid = 1'b0; hp_write = 1'b0; hp_addr = 64'd0; hp_beats = '0;
    bw_en = 1'b0; bw_idx = '0; bw_hmask = 2'b00; bw_data = 64'd0;
    te_start = 1'b0;
    case (st)
      E_IDLE: if (can_fetch) begin
        hp_valid = 1'b1; hp_addr = fetch_a; hp_beats = (BIW+1)'(8);
      end
      E_DECODE: te_start = !reset_req && (v_status == sfh_abi_pkg::ST_SUCCESS) && v_gemm;
      E_DMA_NEXT: if (!reset_req && remain_q != 32'd0 && h2d_q) begin
        hp_valid = 1'b1; hp_addr = host_ptr_q; hp_beats = (BIW+1)'(chunk_n >> 3);
      end
      E_DEV_NEXT: if (!reset_req && widx_q == words_q && !h2d_q) begin
        hp_valid = 1'b1; hp_write = 1'b1; hp_addr = host_ptr_q; hp_beats = (BIW+1)'(chunk_q >> 3);
      end
      E_DEV_RSP: if (f_rsp_valid && !h2d_q) begin
        bw_en = 1'b1; bw_idx = widx_q[BIW:1]; bw_hmask = widx_q[0] ? 2'b10 : 2'b01;
        bw_data = {f_rsp_rdata, f_rsp_rdata};
      end
      E_CQ_WAIT: if (!reset_req && !cq_is_full && (flush_all || sqe_flush)) begin
        hp_valid = 1'b1; hp_addr = sq_slot; hp_beats = (BIW+1)'(1);
      end
      E_CQ_FILL: begin
        bw_en = 1'b1; bw_hmask = 2'b11;
        if (!fill_q) begin bw_idx = '0; bw_data = {cpl_res_q, v_txn}; end
        else begin
          bw_idx = (BIW)'(1); bw_data = {cqe_dw3, cqe_dw2};
          // a reset requested during FLUSH must not let the command complete
          hp_valid = !reset_req; hp_write = 1'b1; hp_addr = cq_slot; hp_beats = (BIW+1)'(2);
        end
      end
      default: ;
    endcase
  end

  assign f_req_valid = (st == E_DEV_REQ);
  assign f_req_write = h2d_q;
  assign f_req_addr  = word_a;
  assign f_req_wdata = buf_flat[widx_q*32 +: 32];
  assign f_req_wstrb = 4'hF;
  assign f_rsp_ready = (st == E_DEV_RSP);

  // ---------------------------------------------------------------- FSM
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= E_IDLE;
      sq_head_q <= 12'd0; cq_tail_q <= 12'd0; cur_idx_q <= 12'd0; phase_q <= 1'b1;
      fatal_q <= 1'b0; tmo_seen_q <= 1'b0; fill_q <= 1'b0;
      sqe_q <= '0; cpl_st_q <= 16'd0; cpl_res_q <= 32'd0; cpl_addr_q <= 64'd0;
      host_ptr_q <= 64'd0; dev_ptr_q <= 32'd0; remain_q <= 32'd0; done_q <= 32'd0;
      chunk_q <= 8'd0; words_q <= 6'd0; widx_q <= 6'd0; h2d_q <= 1'b0; rcnt_q <= 4'd0;
      hp_addr_q <= 64'd0;
      srst <= 1'b0; halt_set <= 1'b0; ev_cq <= 1'b0; ev_host_bus <= 1'b0; ev_host_tmo <= 1'b0;
      ev_cmd_err <= 1'b0; ev_eng_tmo <= 1'b0; err_addr <= 64'd0; err_cmd_status <= 16'd0;
      err_cmd_sqidx <= 16'd0;
    end else begin
      srst <= 1'b0; halt_set <= 1'b0; ev_cq <= 1'b0; ev_host_bus <= 1'b0; ev_host_tmo <= 1'b0;
      ev_cmd_err <= 1'b0; ev_eng_tmo <= 1'b0;

      if (hp_valid) hp_addr_q <= hp_addr;
      if (hp_tmo) begin                                 // host bus not answering: fatal
        fatal_q <= 1'b1; tmo_seen_q <= 1'b1;
        ev_host_tmo <= 1'b1; err_addr <= hp_addr_q;
      end
      if (q_init) begin sq_head_q <= 12'd0; cq_tail_q <= 12'd0; phase_q <= 1'b1; end

      case (st)
        // ------------------------------------------------------------ dispatch
        E_IDLE: begin
          if (reset_req)           begin st <= E_RESET; rcnt_q <= 4'd0; end
          else if (fatal_q)        st <= E_FATAL;
          else if (can_fetch)      begin st <= E_FETCH; cur_idx_q <= sq_head_q; end
        end
        E_FETCH: if (hp_done) begin
          if (tmo_seen_q || hp_err) begin
            if (hp_err) begin ev_host_bus <= 1'b1; err_addr <= hp_addr_q; end
            fatal_q <= 1'b1; st <= E_FATAL;
          end else begin
            sqe_q     <= buf_flat[511:0];
            sq_head_q <= (sq_head_q + 12'd1) & sq_mask;
            st        <= E_DECODE;
          end
        end
        E_DECODE: begin
          cpl_res_q <= 32'd0;
          if (reset_req) begin
            st <= E_RESET; rcnt_q <= 4'd0;
          end else if (v_status != sfh_abi_pkg::ST_SUCCESS) begin
            cpl_st_q <= v_status; cpl_addr_q <= v_dma ? v_host : 64'd0; st <= E_CQ_WAIT;
          end else if (v_dma) begin
            host_ptr_q <= v_host; dev_ptr_q <= v_dev; remain_q <= v_len; done_q <= 32'd0;
            h2d_q <= v_h2d; st <= E_DMA_NEXT;
          end else if (v_gemm) begin
            st <= E_TE;
          end else begin                                // NOP
            cpl_st_q <= sfh_abi_pkg::ST_SUCCESS; st <= E_CQ_WAIT;
          end
        end
        // ------------------------------------------------------------ DMA
        E_DMA_NEXT: begin
          if (reset_req) begin
            st <= E_RESET; rcnt_q <= 4'd0;
          end else if (remain_q == 32'd0) begin
            cpl_st_q <= sfh_abi_pkg::ST_SUCCESS; cpl_res_q <= done_q; st <= E_CQ_WAIT;
          end else begin
            chunk_q <= chunk_n[7:0];
            words_q <= chunk_n[7:2];
            widx_q  <= 6'd0;
            st      <= h2d_q ? E_HOST_RD : E_DEV_NEXT;
          end
        end
        E_HOST_RD: if (hp_done) begin
          if (tmo_seen_q) st <= E_FATAL;
          else if (hp_err) begin
            cpl_st_q <= sfh_abi_pkg::ST_HOST_BUS_ERROR; cpl_res_q <= done_q;
            cpl_addr_q <= host_ptr_q; st <= E_CQ_WAIT;
          end else st <= E_DEV_NEXT;
        end
        E_DEV_NEXT: begin
          if (widx_q == words_q) begin
            if (h2d_q) begin
              host_ptr_q <= host_ptr_q + {56'd0, chunk_q};
              dev_ptr_q  <= dev_ptr_q + {24'd0, chunk_q};
              remain_q   <= remain_q - {24'd0, chunk_q};
              done_q     <= done_q + {24'd0, chunk_q};
              st         <= E_DMA_NEXT;
            end else if (reset_req) begin
              st <= E_RESET; rcnt_q <= 4'd0;
            end else begin
              st <= E_HOST_WR;
            end
          end else if (reset_req) begin
            st <= E_RESET; rcnt_q <= 4'd0;
          end else begin
            st <= E_DEV_REQ;
          end
        end
        E_DEV_REQ: if (f_req_ready) st <= E_DEV_RSP;
        E_DEV_RSP: if (f_rsp_valid) begin
          if (f_rsp_error) begin
            cpl_st_q <= sfh_abi_pkg::ST_DEV_BUS_ERROR; cpl_res_q <= done_q;
            cpl_addr_q <= {32'd0, word_a}; st <= E_CQ_WAIT;
          end else begin
            widx_q <= widx_q + 6'd1; st <= E_DEV_NEXT;
          end
        end
        E_HOST_WR: if (hp_done) begin
          if (tmo_seen_q) st <= E_FATAL;
          else if (hp_err) begin
            cpl_st_q <= sfh_abi_pkg::ST_HOST_BUS_ERROR; cpl_res_q <= done_q;
            cpl_addr_q <= host_ptr_q; st <= E_CQ_WAIT;
          end else begin
            host_ptr_q <= host_ptr_q + {56'd0, chunk_q};
            dev_ptr_q  <= dev_ptr_q + {24'd0, chunk_q};
            remain_q   <= remain_q - {24'd0, chunk_q};
            done_q     <= done_q + {24'd0, chunk_q};
            st         <= E_DMA_NEXT;
          end
        end
        // ------------------------------------------------------------ compute
        E_TE: begin
          if (reset_req) begin
            st <= E_RESET; rcnt_q <= 4'd0;
          end else if (te_done) begin
            cpl_st_q <= te_st; cpl_res_q <= te_res; cpl_addr_q <= 64'd0;
            if (te_st == sfh_abi_pkg::ST_ENGINE_TIMEOUT) ev_eng_tmo <= 1'b1;
            st <= E_CQ_WAIT;
          end
        end
        // ------------------------------------------------------------ completion
        E_CQ_WAIT: begin
          fill_q <= 1'b0;
          if (reset_req) begin
            st <= E_RESET; rcnt_q <= 4'd0;
          end else if (!cq_is_full) begin
            st <= (flush_all || sqe_flush) ? E_FLUSH : E_CQ_FILL;
          end
        end
        E_FLUSH: if (hp_done) begin
          if (tmo_seen_q || hp_err) begin
            if (hp_err) begin ev_host_bus <= 1'b1; err_addr <= hp_addr_q; end
            fatal_q <= 1'b1; st <= E_FATAL;
          end else st <= E_CQ_FILL;
        end
        E_CQ_FILL: begin
          fill_q <= 1'b1;
          if (fill_q) begin
            if (reset_req) begin st <= E_RESET; rcnt_q <= 4'd0; end   // found by t_reset_in_flush
            else           st <= E_CQ_POST;
          end
        end
        E_CQ_POST: if (hp_done) begin
          if (tmo_seen_q || hp_err) begin
            if (hp_err) begin ev_host_bus <= 1'b1; err_addr <= hp_addr_q; end
            fatal_q <= 1'b1; st <= E_FATAL;
          end else begin
            cq_tail_q <= (cq_tail_q + 12'd1) & cq_mask;
            if (((cq_tail_q + 12'd1) & cq_mask) == 12'd0) phase_q <= !phase_q;
            ev_cq <= sqe_irq || cpl_fail;
            if (cpl_fail) begin
              ev_cmd_err <= 1'b1; err_addr <= cpl_addr_q;
              err_cmd_status <= cpl_st_q; err_cmd_sqidx <= {4'd0, cur_idx_q};
              if (stop_on_err) halt_set <= 1'b1;
            end
            st <= E_IDLE;
          end
        end
        // ------------------------------------------------------------ fatal / reset
        E_FATAL: if (reset_req && hp_idle) begin st <= E_RESET; rcnt_q <= 4'd0; end
        default: begin                                  // E_RESET (port idle by construction)
          rcnt_q <= rcnt_q + 4'd1;
          if (32'(rcnt_q) == RST_CYC) begin
            srst <= 1'b1;
            st <= E_IDLE;
            sq_head_q <= 12'd0; cq_tail_q <= 12'd0; phase_q <= 1'b1;
            fatal_q <= 1'b0; tmo_seen_q <= 1'b0;
          end
        end
      endcase
    end
  end

  // ---------------------------------------------------------------- status / perf
  assign idle     = ((st == E_IDLE) || (st == E_FATAL)) && hp_idle;
  assign fatal    = fatal_q;
  assign cq_full  = (st == E_CQ_WAIT) && cq_is_full;
  assign state    = st;
  assign sq_head  = sq_head_q;
  assign cq_tail  = cq_tail_q;
  assign cq_phase = phase_q;
  // tile_rst_req feeds an asynchronous reset (through sfv_rst_sync in the
  // device top): drive it from a flop, never from decoded state bits (glitches)
  logic tile_rst_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) tile_rst_q <= 1'b0;
    else        tile_rst_q <= te_rst || (st == E_RESET);
  end
  assign tile_rst_req = tile_rst_q;

  wire post_ok   = (st == E_CQ_POST) && hp_done && !hp_err && !tmo_seen_q;
  wire h2d_chunk = (st == E_DEV_NEXT) && (widx_q == words_q) && h2d_q;
  wire d2h_chunk = (st == E_HOST_WR) && hp_done && !hp_err && !tmo_seen_q;
  always_comb begin
    perf_inc = '0;
    perf_inc[0*16 +: 16] = {15'd0, post_ok};
    perf_inc[1*16 +: 16] = {15'd0, post_ok && cpl_fail};
    perf_inc[2*16 +: 16] = h2d_chunk ? {8'd0, chunk_q} : 16'd0;
    perf_inc[3*16 +: 16] = d2h_chunk ? {8'd0, chunk_q} : 16'd0;
    perf_inc[4*16 +: 16] = {15'd0, (st != E_IDLE) && (st != E_FATAL)};
    perf_inc[5*16 +: 16] = {15'd0, !hp_idle};
    perf_inc[6*16 +: 16] = {15'd0, cq_full};
    perf_inc[8*16 +: 16] = {15'd0, te_running};
  end
endmodule

`default_nettype wire
