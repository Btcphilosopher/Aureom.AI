// =============================================================================
// SilicaFlux HostLink :: sfh_te_ctl -- TENSOR_GEMM sequencer for sfv_tensor_engine
//
// Drives the SilicaFlux-V tensor-engine register page (rb_* bus of sfv_tile,
// single-cycle writes, combinational reads; register map in
// third_party/.../sfv_tensor_engine.sv) for one HostLink command:
//   STATUS <- W1C(DONE|ERR); CFG <- {B_UNS, A_UNS, WB=1, ACC};
//   A/B/C_ADDR, K, A/B/C_STRIDE; CTRL <- START (IRQ_EN = 0)
// then polls STATUS every cycle:
//   ERR            -> ENGINE_ERROR, result = engine ERRCODE (param refused)
//   DONE && !BUSY  -> read CYCLES -> SUCCESS, result = engine cycles
//   watchdog       -> ENGINE_TIMEOUT, tile reset requested for RST_CYC cycles, then
//                     REL_CYC more cycles for the tile's reset synchroniser to release
//                     before `done` (so the next command never meets a tile in reset)
// Write-back (CFG.WB) is always on: results reach the TSPM, from where a
// D2H DMA returns them to the host.
// abort: stop immediately (engine soft reset); the tile is reset by the
// engine's reset sequence.
// =============================================================================
`default_nettype none

module sfh_te_ctl #(
  parameter int RST_CYC = 4,
  parameter int REL_CYC = 4          // >= tile reset synchroniser stages + 1 (flop)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        srst,
  input  wire logic        start,
  input  wire logic [31:0] p_a, p_b, p_c, p_k, p_as, p_bs, p_cs,
  input  wire logic [2:0]  p_flags,           // {B_UNSIGNED, A_UNSIGNED, ACC}
  input  wire logic [31:0] timeout,
  output logic             done,
  output logic [15:0]      st_out,
  output logic [31:0]      result,
  output logic             running,           // engine cycles (perf)
  output logic             tile_rst_req,
  // tensor-engine register page
  output logic             te_sel,
  output logic             rb_we,
  output logic [11:0]      rb_addr,
  output logic [31:0]      rb_wdata,
  input  wire logic [31:0] te_rdata
);
  typedef enum logic [2:0] {T_IDLE, T_WR, T_POLL, T_CYC, T_RST} tst_e;
  tst_e        st;
  logic [3:0]  idx;
  logic [31:0] wd_q;
  logic [3:0]  rc_q;
  logic [31:0] a_q, b_q, c_q, k_q, as_q, bs_q, cs_q;
  logic [2:0]  f_q;

  // write sequence table
  always_comb begin
    rb_addr  = 12'h004;
    rb_wdata = 32'd0;
    case (idx)
      4'd0:    begin rb_addr = 12'h004; rb_wdata = 32'h0000_0006; end             // W1C DONE|ERR
      4'd1:    begin rb_addr = 12'h008; rb_wdata = {28'd0, f_q[2], f_q[1], 1'b1, f_q[0]}; end
      4'd2:    begin rb_addr = 12'h00C; rb_wdata = a_q;  end
      4'd3:    begin rb_addr = 12'h010; rb_wdata = b_q;  end
      4'd4:    begin rb_addr = 12'h014; rb_wdata = c_q;  end
      4'd5:    begin rb_addr = 12'h018; rb_wdata = k_q;  end
      4'd6:    begin rb_addr = 12'h01C; rb_wdata = as_q; end
      4'd7:    begin rb_addr = 12'h020; rb_wdata = bs_q; end
      4'd8:    begin rb_addr = 12'h024; rb_wdata = cs_q; end
      default: begin rb_addr = 12'h000; rb_wdata = 32'h0000_0001; end             // START
    endcase
    if (st == T_POLL) begin rb_addr = 12'h004; rb_wdata = 32'd0; end
    if (st == T_CYC)  begin rb_addr = 12'h028; rb_wdata = 32'd0; end
  end
  assign te_sel = (st == T_WR) || (st == T_POLL) || (st == T_CYC);
  assign rb_we  = (st == T_WR);

  wire te_busy = te_rdata[0];
  wire te_done = te_rdata[1];
  wire te_err  = te_rdata[2];

  assign running      = (st == T_POLL);
  assign tile_rst_req = (st == T_RST) && (32'(rc_q) < RST_CYC);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= T_IDLE; idx <= 4'd0; wd_q <= 32'd0; rc_q <= 4'd0;
      done <= 1'b0; st_out <= 16'd0; result <= 32'd0;
      a_q <= '0; b_q <= '0; c_q <= '0; k_q <= '0; as_q <= '0; bs_q <= '0; cs_q <= '0; f_q <= '0;
    end else if (srst) begin
      st <= T_IDLE; idx <= 4'd0; done <= 1'b0;
    end else begin
      done <= 1'b0;
      case (st)
        T_IDLE: if (start) begin
          a_q <= p_a; b_q <= p_b; c_q <= p_c; k_q <= p_k;
          as_q <= p_as; bs_q <= p_bs; cs_q <= p_cs; f_q <= p_flags;
          idx <= 4'd0; st <= T_WR;
        end
        T_WR: begin
          idx <= idx + 4'd1;
          if (idx == 4'd9) begin st <= T_POLL; wd_q <= 32'd0; end
        end
        T_POLL: begin
          wd_q <= wd_q + 32'd1;
          if (te_err) begin
            st <= T_IDLE; done <= 1'b1;
            st_out <= sfh_abi_pkg::ST_ENGINE_ERROR; result <= {28'd0, te_rdata[7:4]};
          end else if (te_done && !te_busy) begin
            st <= T_CYC;
          end else if (timeout != 32'd0 && wd_q + 32'd1 >= timeout) begin
            st <= T_RST; rc_q <= 4'd0;
            st_out <= sfh_abi_pkg::ST_ENGINE_TIMEOUT; result <= 32'd0;
          end
        end
        T_CYC: begin
          st <= T_IDLE; done <= 1'b1;
          st_out <= sfh_abi_pkg::ST_SUCCESS; result <= te_rdata;
        end
        default: begin                         // T_RST: hold the tile in reset, then let it leave reset
          rc_q <= rc_q + 4'd1;
          if (32'(rc_q) == RST_CYC + REL_CYC - 1) begin st <= T_IDLE; done <= 1'b1; end
        end
      endcase
    end
  end
endmodule

`default_nettype wire
