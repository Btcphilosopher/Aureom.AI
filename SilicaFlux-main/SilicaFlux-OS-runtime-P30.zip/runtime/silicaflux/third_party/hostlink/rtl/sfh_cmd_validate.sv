// =============================================================================
// SilicaFlux HostLink :: sfh_cmd_validate -- submission-entry decode + checks
//
// Pure combinational.  A command is executed only if `status` is SUCCESS;
// nothing is read from or written to any memory for a rejected command.
// Checks, in priority order (the first failing check gives the status):
//   1. opcode implemented                                     INVALID_OPCODE
//   2. unknown SQE flags, RSVD0, reserved dwords of the
//      opcode, DIR (DMA: H2D/D2H; others: 0), unknown
//      GEMM flags, device-side address bits [63:32]           INVALID_FIELD
//   3. DMA length 1 .. 2^MAX_DMA_LOG2                         INVALID_LENGTH
//   4. DMA src/dst/length multiples of 8                      MISALIGNED
//   5. host range inside a VALID window with DEV_READ (H2D)
//      or DEV_WRITE (D2H), 65-bit overflow-safe               HOST_ADDR_DENIED
//   6. device range inside DEVMEM0 or DEVMEM1, 33-bit safe    DEV_ADDR_INVALID
// TENSOR_GEMM operands are validated by the tensor engine itself (single
// source of truth for its legality rules); a refusal completes with
// ENGINE_ERROR and the engine's error code.
// =============================================================================
`default_nettype none

module sfh_cmd_validate #(
  parameter int          NW           = 4,
  parameter int          MAX_DMA_LOG2 = 20,
  parameter logic [31:0] DM0_BASE     = 32'h1000_0000,
  parameter logic [31:0] DM0_SIZE     = 32'h0001_0000,
  parameter logic [31:0] DM1_BASE     = 32'h2000_0000,
  parameter logic [31:0] DM1_SIZE     = 32'h0000_4000
) (
  input  wire logic [511:0]     sqe,
  input  wire logic [NW*64-1:0] win_base,
  input  wire logic [NW*64-1:0] win_size,
  input  wire logic [NW*3-1:0]  win_ctrl,
  output logic [15:0]           status,
  output logic                  is_nop,
  output logic                  is_dma,
  output logic                  is_gemm,
  output logic                  h2d,
  output logic [63:0]           host_addr,
  output logic [31:0]           dev_addr,
  output logic [31:0]           length,
  output logic [7:0]            opcode,
  output logic [7:0]            flags,
  output logic [31:0]           txn_id
);
  function automatic logic [31:0] dw(input logic [511:0] e, input int i);
    dw = e[i*32 +: 32];
  endfunction

  assign opcode = sqe[sfh_abi_pkg::SQE_OPCODE_LSB +: 8];
  assign flags  = sqe[sfh_abi_pkg::SQE_FLAGS_LSB +: 8];
  wire [7:0] dir   = sqe[sfh_abi_pkg::SQE_DIR_LSB +: 8];
  wire [7:0] rsvd0 = sqe[sfh_abi_pkg::SQE_RSVD0_LSB +: 8];
  assign txn_id = dw(sqe, sfh_abi_pkg::SQE_TXN_ID_DW);

  wire [63:0] src = {dw(sqe, sfh_abi_pkg::SQE_SRC_HI_DW), dw(sqe, sfh_abi_pkg::SQE_SRC_LO_DW)};
  wire [63:0] dst = {dw(sqe, sfh_abi_pkg::SQE_DST_HI_DW), dw(sqe, sfh_abi_pkg::SQE_DST_LO_DW)};
  assign length = dw(sqe, sfh_abi_pkg::SQE_LENGTH_DW);

  assign is_nop  = (opcode == sfh_abi_pkg::OP_NOP);
  assign is_dma  = (opcode == sfh_abi_pkg::OP_DMA);
  assign is_gemm = (opcode == sfh_abi_pkg::OP_TENSOR_GEMM);
  assign h2d     = (dir == sfh_abi_pkg::DMA_DIR_H2D);
  wire   d2h     = (dir == sfh_abi_pkg::DMA_DIR_D2H);

  assign host_addr = h2d ? src : dst;
  wire [63:0] dev64 = h2d ? dst : src;
  assign dev_addr  = dev64[31:0];

  // reserved dwords
  logic rsv_dma_nz, rsv_gemm_nz, rsv_nop_nz;
  always_comb begin
    rsv_dma_nz = 1'b0; rsv_gemm_nz = 1'b0; rsv_nop_nz = 1'b0;
    for (int i = sfh_abi_pkg::SQE_DMA_RSVD_FIRST_DW; i < 16; i++)  if (dw(sqe, i) != 32'd0) rsv_dma_nz  = 1'b1;
    for (int i = sfh_abi_pkg::SQE_GEMM_RSVD_FIRST_DW; i < 16; i++) if (dw(sqe, i) != 32'd0) rsv_gemm_nz = 1'b1;
    for (int i = sfh_abi_pkg::SQE_NOP_RSVD_FIRST_DW; i < 16; i++)  if (dw(sqe, i) != 32'd0) rsv_nop_nz  = 1'b1;
  end
  wire [31:0] te_flags = dw(sqe, sfh_abi_pkg::SQE_TE_FLAGS_DW);

  // host window
  logic host_ok;
  sfh_win_check #(.NW(NW)) u_win (
    .addr(host_addr), .len(length), .need_rd(h2d), .need_wr(!h2d),
    .win_base, .win_size, .win_ctrl, .ok(host_ok)
  );
  // device regions (33-bit arithmetic: no wrap-around)
  wire [32:0] dev_end = {1'b0, dev_addr} + {1'b0, length};
  wire in_r0 = ({1'b0, dev_addr} >= {1'b0, DM0_BASE}) && (dev_end <= {1'b0, DM0_BASE} + {1'b0, DM0_SIZE});
  wire in_r1 = ({1'b0, dev_addr} >= {1'b0, DM1_BASE}) && (dev_end <= {1'b0, DM1_BASE} + {1'b0, DM1_SIZE});

  always_comb begin
    status = sfh_abi_pkg::ST_SUCCESS;
    if (!is_nop && !is_dma && !is_gemm)
      status = sfh_abi_pkg::ST_INVALID_OPCODE;
    else if ((flags & ~sfh_abi_pkg::SQE_FLAGS_VALID) != 8'd0 || rsvd0 != 8'd0)
      status = sfh_abi_pkg::ST_INVALID_FIELD;
    else if (is_nop && (dir != 8'd0 || rsv_nop_nz))
      status = sfh_abi_pkg::ST_INVALID_FIELD;
    else if (is_gemm && (dir != 8'd0 || rsv_gemm_nz || (te_flags & ~sfh_abi_pkg::GEMM_FLAGS_VALID) != 32'd0))
      status = sfh_abi_pkg::ST_INVALID_FIELD;
    else if (is_dma && ((!h2d && !d2h) || rsv_dma_nz || dev64[63:32] != 32'd0))
      status = sfh_abi_pkg::ST_INVALID_FIELD;
    else if (is_dma && (length == 32'd0 || length > (32'd1 << MAX_DMA_LOG2)))
      status = sfh_abi_pkg::ST_INVALID_LENGTH;
    else if (is_dma && (src[2:0] != 3'd0 || dst[2:0] != 3'd0 || length[2:0] != 3'd0))
      status = sfh_abi_pkg::ST_MISALIGNED;
    else if (is_dma && !host_ok)
      status = sfh_abi_pkg::ST_HOST_ADDR_DENIED;
    else if (is_dma && !in_r0 && !in_r1)
      status = sfh_abi_pkg::ST_DEV_ADDR_INVALID;
  end
endmodule

`default_nettype wire
