// =============================================================================
// SilicaFlux HostLink :: sfh_bar_regs -- BAR0 register bridge (AXI4-Lite slave)
//
// Implements the BAR0 register map of abi/sfh_abi.py (ABI 1.0) exactly; every
// offset/reset value/writable mask comes from generated/sfh_abi_pkg.sv.
//
// AXI4-Lite: 32-bit data, 12-bit offset, one write and one read in flight.
//   Write: AW and W are captured independently (any order), the register
//   update happens in one cycle when both are present, then B is returned.
//   Read : AR accepted when no R is pending; R returned the next cycle.
// Rejected accesses (never any state change except the error log):
//   * misaligned offset or WSTRB != 4'hF (BAR0 is 32-bit only)
//   * unmapped offset, write to RO, write to RWL while locked
//     (locked = ENABLED || !engine idle || RESETTING), any write during reset
//   * INT_VECTOR with a vector >= NV, CTRL.ENABLE 0->1 while the engine is
//     not idle
//   -> SLVERR, ERR_STATUS.REG_ACCESS, ERR_REG_OFFSET.
//   Invalid doorbells -> SLVERR, ERR_STATUS.DOORBELL, ERR_REG_OFFSET.
//   (PCIe writes are posted: the SLVERR on a write is only visible to tools;
//   drivers must use ERR_STATUS.  A read SLVERR becomes a completer abort and
//   the CPU reads all-ones.)
// No register has a read side effect.
// =============================================================================
`default_nettype none

module sfh_bar_regs #(
  parameter int          NW           = 4,
  parameter int          NV           = 2,
  parameter int          SQ_LOG2_MAX  = 12,
  parameter int          CQ_LOG2_MAX  = 12,
  parameter int          MAX_DMA_LOG2 = 20,
  parameter int          MAXB         = 16,
  parameter logic [31:0] DM0_BASE     = 32'h1000_0000,
  parameter logic [31:0] DM0_SIZE     = 32'h0001_0000,
  parameter logic [31:0] DM1_BASE     = 32'h2000_0000,
  parameter logic [31:0] DM1_SIZE     = 32'h0000_4000,
  parameter logic [31:0] CAPS         = 32'h0000_00FF,
  localparam int         NPC          = 10
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ------------------------------------------------------------ AXI4-Lite slave (BAR0)
  input  wire logic             s_awvalid,
  output logic                  s_awready,
  input  wire logic [11:0]      s_awaddr,
  input  wire logic             s_wvalid,
  output logic                  s_wready,
  input  wire logic [31:0]      s_wdata,
  input  wire logic [3:0]       s_wstrb,
  output logic                  s_bvalid,
  input  wire logic             s_bready,
  output logic [1:0]            s_bresp,
  input  wire logic             s_arvalid,
  output logic                  s_arready,
  input  wire logic [11:0]      s_araddr,
  output logic                  s_rvalid,
  input  wire logic             s_rready,
  output logic [31:0]           s_rdata,
  output logic [1:0]            s_rresp,
  // ------------------------------------------------------------ configuration to the engine
  output logic                  o_enabled,
  output logic                  o_flush_all,
  output logic                  o_stop_on_err,
  output logic [31:0]           o_timeout,
  output logic [63:0]           o_sq_base,
  output logic [3:0]            o_sq_log2,
  output logic [63:0]           o_cq_base,
  output logic [3:0]            o_cq_log2,
  output logic [NW*64-1:0]      o_win_base,
  output logic [NW*64-1:0]      o_win_size,
  output logic [NW*3-1:0]       o_win_ctrl,
  output logic [11:0]           o_sq_tail,
  output logic [11:0]           o_cq_head,
  output logic                  o_q_init,        // pulse: queues just enabled
  output logic                  o_reset_req,     // level until i_srst
  output logic                  o_halted,
  // ------------------------------------------------------------ status/events from the engine
  input  wire logic             i_srst,          // pulse: perform soft reset now
  input  wire logic             i_eng_idle,
  input  wire logic             i_eng_fatal,
  input  wire logic             i_eng_cq_full,
  input  wire logic [3:0]       i_eng_state,
  input  wire logic [11:0]      i_sq_head,
  input  wire logic [11:0]      i_cq_tail,
  input  wire logic             i_cq_phase,
  input  wire logic             i_halt_set,
  input  wire logic             i_ev_cq,
  input  wire logic             i_ev_host_bus,
  input  wire logic             i_ev_host_tmo,
  input  wire logic             i_ev_cmd_err,
  input  wire logic             i_ev_eng_tmo,
  input  wire logic [63:0]      i_err_addr,      // with host_bus/host_tmo/cmd_err
  input  wire logic [15:0]      i_err_cmd_status,
  input  wire logic [15:0]      i_err_cmd_sqidx,
  input  wire logic [NPC*16-1:0] i_perf_inc,     // engine-owned counters
  // ------------------------------------------------------------ interrupts
  output logic                  irq_valid,
  output logic [3:0]            irq_vector,
  input  wire logic             irq_ready,
  output logic                  irq_level
);
  // ---------------------------------------------------------------- register state
  logic        enabled_q, flush_q, stop_q, reset_req_q, halted_q;
  logic [31:0] scratch_q, timeout_q;
  logic [63:0] sq_base_q, cq_base_q;
  logic [3:0]  sq_log2_q, cq_log2_q;
  logic [11:0] sq_tail_q, cq_head_q;
  logic [NW*64-1:0] win_base_q, win_size_q;
  logic [NW*3-1:0]  win_ctrl_q;
  logic [6:0]  err_q;
  logic [11:0] err_off_q;
  logic [63:0] err_addr_q;
  logic [31:0] err_cmd_q;

  // ---------------------------------------------------------------- AXI-Lite write capture
  logic        aw_have, w_have;
  logic [11:0] aw_off;
  logic [31:0] w_data;
  logic [3:0]  w_strb;
  assign s_awready = !aw_have;
  assign s_wready  = !w_have;
  wire do_wr = aw_have && w_have && !s_bvalid;

  // ---------------------------------------------------------------- ring validation (CTRL.ENABLE 0->1)
  wire [31:0] sq_bytes = 32'd64 << sq_log2_q;
  wire [31:0] cq_bytes = 32'd16 << cq_log2_q;
  logic sq_win_ok, cq_win_ok;
  sfh_win_check #(.NW(NW)) u_sqwin (
    .addr(sq_base_q), .len(sq_bytes), .need_rd(1'b1), .need_wr(1'b0),
    .win_base(win_base_q), .win_size(win_size_q), .win_ctrl(win_ctrl_q), .ok(sq_win_ok));
  sfh_win_check #(.NW(NW)) u_cqwin (
    .addr(cq_base_q), .len(cq_bytes), .need_rd(1'b0), .need_wr(1'b1),
    .win_base(win_base_q), .win_size(win_size_q), .win_ctrl(win_ctrl_q), .ok(cq_win_ok));
  wire [64:0] sq_end = {1'b0, sq_base_q} + {33'd0, sq_bytes};
  wire [64:0] cq_end = {1'b0, cq_base_q} + {33'd0, cq_bytes};
  wire rings_overlap = ({1'b0, sq_base_q} < cq_end) && ({1'b0, cq_base_q} < sq_end);
  wire ring_ok = (sq_log2_q >= 4'd1) && (32'(sq_log2_q) <= SQ_LOG2_MAX) &&
                 (cq_log2_q >= 4'd1) && (32'(cq_log2_q) <= CQ_LOG2_MAX) &&
                 sq_win_ok && cq_win_ok && !rings_overlap;

  // ---------------------------------------------------------------- doorbell validation
  wire [11:0] sq_mask = 12'((32'd1 << sq_log2_q) - 32'd1);
  wire [11:0] cq_mask = 12'((32'd1 << cq_log2_q) - 32'd1);
  wire [11:0] db_v    = w_data[11:0];
  wire        db_hi0  = (w_data[31:12] == 20'd0);
  wire db_sq_ok = enabled_q && db_hi0 && ((db_v & ~sq_mask) == 12'd0) &&
                  (((db_v - i_sq_head) & sq_mask) >= ((sq_tail_q - i_sq_head) & sq_mask));
  wire db_cq_ok = enabled_q && db_hi0 && ((db_v & ~cq_mask) == 12'd0) &&
                  (((db_v - cq_head_q) & cq_mask) <= ((i_cq_tail - cq_head_q) & cq_mask));

  // ---------------------------------------------------------------- write decode
  wire locked = enabled_q || !i_eng_idle || reset_req_q;
  logic wr_rej, wr_db_rej;
  logic wr_win_hit;
  always_comb begin
    wr_rej = 1'b0; wr_db_rej = 1'b0; wr_win_hit = 1'b0;
    for (int i = 0; i < NW; i++) begin
      for (int r = 0; r < 5; r++) begin
        if (aw_off == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + r * 4)) wr_win_hit = 1'b1;
      end
    end
    if (aw_off[1:0] != 2'b00 || w_strb != 4'hF || reset_req_q) begin
      wr_rej = 1'b1;
    end else if (wr_win_hit) begin
      wr_rej = locked;
    end else begin
      case (aw_off)
        sfh_abi_pkg::REG_CTRL:
          wr_rej = !w_data[1] && w_data[0] && !enabled_q && !i_eng_idle;
        sfh_abi_pkg::REG_SCRATCH, sfh_abi_pkg::REG_TIMEOUT,
        sfh_abi_pkg::REG_INT_STATUS, sfh_abi_pkg::REG_INT_ENABLE, sfh_abi_pkg::REG_INT_TEST,
        sfh_abi_pkg::REG_ERR_STATUS, sfh_abi_pkg::REG_PERF_CTRL:
          wr_rej = 1'b0;
        sfh_abi_pkg::REG_INT_VECTOR:
          wr_rej = (32'(w_data[3:0]) >= NV) || (32'(w_data[11:8]) >= NV);
        sfh_abi_pkg::REG_SQ_BASE_LO, sfh_abi_pkg::REG_SQ_BASE_HI, sfh_abi_pkg::REG_SQ_SIZE,
        sfh_abi_pkg::REG_CQ_BASE_LO, sfh_abi_pkg::REG_CQ_BASE_HI, sfh_abi_pkg::REG_CQ_SIZE:
          wr_rej = locked;
        sfh_abi_pkg::REG_SQ_TAIL: wr_db_rej = !db_sq_ok;
        sfh_abi_pkg::REG_CQ_HEAD: wr_db_rej = !db_cq_ok;
        default: wr_rej = 1'b1;                       // RO or unmapped
      endcase
    end
  end
  wire wr_ok   = do_wr && !wr_rej && !wr_db_rej;
  wire wr_at   = wr_ok;
  function automatic logic hit(input logic [11:0] off, input logic [11:0] reg_off);
    hit = (off == reg_off);
  endfunction

  wire ctrl_wr      = wr_at && hit(aw_off, sfh_abi_pkg::REG_CTRL);
  wire ctrl_en_try  = ctrl_wr && !w_data[1] && w_data[0] && !enabled_q;
  wire q_init       = ctrl_en_try && ring_ok;
  wire ring_rej     = ctrl_en_try && !ring_ok;

  // ---------------------------------------------------------------- read decode
  logic [31:0] rd_val;
  logic        rd_hit;
  logic [NPC*64-1:0] perf_snap;
  logic [1:0]  int_status, int_enable;
  logic [3:0]  vec_cq, vec_err;
  wire  [31:0] status_w = {20'd0, i_eng_state, 2'b00, i_eng_cq_full, halted_q, i_eng_fatal,
                           reset_req_q, i_eng_idle, enabled_q};
  wire  [31:0] limits_w = {8'(MAXB), 8'(MAX_DMA_LOG2), 4'(NV), 4'(NW), 4'(CQ_LOG2_MAX), 4'(SQ_LOG2_MAX)};

  always_comb begin
    rd_val = 32'd0;
    rd_hit = 1'b1;
    case (s_araddr)
      sfh_abi_pkg::REG_ID:            rd_val = sfh_abi_pkg::DEVICE_MAGIC;
      sfh_abi_pkg::REG_VERSION:       rd_val = {sfh_abi_pkg::ABI_MAJOR, sfh_abi_pkg::ABI_MINOR};
      sfh_abi_pkg::REG_HW_REV:        rd_val = sfh_abi_pkg::HW_REV;
      sfh_abi_pkg::REG_CAPS:          rd_val = CAPS;
      sfh_abi_pkg::REG_LIMITS:        rd_val = limits_w;
      sfh_abi_pkg::REG_DEVMEM0_BASE:  rd_val = DM0_BASE;
      sfh_abi_pkg::REG_DEVMEM0_SIZE:  rd_val = DM0_SIZE;
      sfh_abi_pkg::REG_DEVMEM1_BASE:  rd_val = DM1_BASE;
      sfh_abi_pkg::REG_DEVMEM1_SIZE:  rd_val = DM1_SIZE;
      sfh_abi_pkg::REG_CTRL:          rd_val = {28'd0, stop_q, flush_q, 1'b0, enabled_q};
      sfh_abi_pkg::REG_STATUS:        rd_val = status_w;
      sfh_abi_pkg::REG_SCRATCH:       rd_val = scratch_q;
      sfh_abi_pkg::REG_TIMEOUT:       rd_val = timeout_q;
      sfh_abi_pkg::REG_SQ_BASE_LO:    rd_val = sq_base_q[31:0];
      sfh_abi_pkg::REG_SQ_BASE_HI:    rd_val = sq_base_q[63:32];
      sfh_abi_pkg::REG_SQ_SIZE:       rd_val = {28'd0, sq_log2_q};
      sfh_abi_pkg::REG_SQ_HEAD:       rd_val = {20'd0, i_sq_head};
      sfh_abi_pkg::REG_SQ_TAIL:       rd_val = {20'd0, sq_tail_q};
      sfh_abi_pkg::REG_CQ_BASE_LO:    rd_val = cq_base_q[31:0];
      sfh_abi_pkg::REG_CQ_BASE_HI:    rd_val = cq_base_q[63:32];
      sfh_abi_pkg::REG_CQ_SIZE:       rd_val = {28'd0, cq_log2_q};
      sfh_abi_pkg::REG_CQ_TAIL:       rd_val = {20'd0, i_cq_tail};
      sfh_abi_pkg::REG_CQ_HEAD:       rd_val = {20'd0, cq_head_q};
      sfh_abi_pkg::REG_CQ_PHASE:      rd_val = {31'd0, i_cq_phase};
      sfh_abi_pkg::REG_INT_STATUS:    rd_val = {30'd0, int_status};
      sfh_abi_pkg::REG_INT_ENABLE:    rd_val = {30'd0, int_enable};
      sfh_abi_pkg::REG_INT_VECTOR:    rd_val = {20'd0, vec_err, 4'd0, vec_cq};
      sfh_abi_pkg::REG_INT_TEST:      rd_val = 32'd0;
      sfh_abi_pkg::REG_ERR_STATUS:    rd_val = {25'd0, err_q};
      sfh_abi_pkg::REG_ERR_REG_OFFSET: rd_val = {20'd0, err_off_q};
      sfh_abi_pkg::REG_ERR_ADDR_LO:   rd_val = err_addr_q[31:0];
      sfh_abi_pkg::REG_ERR_ADDR_HI:   rd_val = err_addr_q[63:32];
      sfh_abi_pkg::REG_ERR_CMD:       rd_val = err_cmd_q;
      sfh_abi_pkg::REG_PERF_CTRL:     rd_val = 32'd0;
      default: begin
        rd_hit = 1'b0;
        for (int i = 0; i < NW; i++) begin
          if (s_araddr == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 0))  begin rd_hit = 1'b1; rd_val = win_base_q[i*64 +: 32]; end
          if (s_araddr == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 4))  begin rd_hit = 1'b1; rd_val = win_base_q[i*64+32 +: 32]; end
          if (s_araddr == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 8))  begin rd_hit = 1'b1; rd_val = win_size_q[i*64 +: 32]; end
          if (s_araddr == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 12)) begin rd_hit = 1'b1; rd_val = win_size_q[i*64+32 +: 32]; end
          if (s_araddr == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 16)) begin rd_hit = 1'b1; rd_val = {29'd0, win_ctrl_q[i*3 +: 3]}; end
        end
        for (int i = 0; i < NPC; i++) begin
          if (s_araddr == 12'(sfh_abi_pkg::PERF_BASE + i * 8))     begin rd_hit = 1'b1; rd_val = perf_snap[i*64 +: 32]; end
          if (s_araddr == 12'(sfh_abi_pkg::PERF_BASE + i * 8 + 4)) begin rd_hit = 1'b1; rd_val = perf_snap[i*64+32 +: 32]; end
        end
      end
    endcase
    if (s_araddr[1:0] != 2'b00) begin rd_hit = 1'b0; rd_val = 32'd0; end
  end
  wire do_rd  = s_arvalid && s_arready;
  wire rd_rej = do_rd && !rd_hit;

  // ---------------------------------------------------------------- error log
  wire       ev_reg_rej = (do_wr && wr_rej) || rd_rej;
  wire       ev_db_rej  = do_wr && wr_db_rej;
  wire [6:0] err_new    = {i_ev_eng_tmo, i_ev_cmd_err, i_ev_host_tmo, i_ev_host_bus,
                           ring_rej, ev_db_rej, ev_reg_rej};
  wire       ev_err_irq = |{err_new[6], err_new[4:0]};          // CMD_ERROR reports via the CQ
  wire       err_w1c    = wr_at && hit(aw_off, sfh_abi_pkg::REG_ERR_STATUS);

  // ---------------------------------------------------------------- interrupt block
  wire int_test = wr_at && hit(aw_off, sfh_abi_pkg::REG_INT_TEST);
  wire irq_sent;
  sfh_irq #(.NV(NV)) u_irq (
    .clk, .rst_n, .srst(i_srst),
    .ev({ev_err_irq || (int_test && w_data[1]), i_ev_cq || (int_test && w_data[0])}),
    .w1c_we(wr_at && hit(aw_off, sfh_abi_pkg::REG_INT_STATUS)), .w1c_mask(w_data[1:0]),
    .en_we(wr_at && hit(aw_off, sfh_abi_pkg::REG_INT_ENABLE)), .en_val(w_data[1:0]),
    .vec_we(wr_at && hit(aw_off, sfh_abi_pkg::REG_INT_VECTOR)),
    .vec_cq_val(w_data[3:0]), .vec_err_val(w_data[11:8]),
    .status(int_status), .enable(int_enable), .vec_cq, .vec_err,
    .msg_valid(irq_valid), .msg_vector(irq_vector), .msg_ready(irq_ready),
    .irq_level, .ev_msg_sent(irq_sent)
  );

  // ---------------------------------------------------------------- performance counters
  logic [NPC*16-1:0] perf_inc;
  always_comb begin
    perf_inc = i_perf_inc;
    perf_inc[7*16 +: 16] = {15'd0, irq_sent};
    perf_inc[9*16 +: 16] = {15'd0, wr_ok && (hit(aw_off, sfh_abi_pkg::REG_SQ_TAIL) ||
                                             hit(aw_off, sfh_abi_pkg::REG_CQ_HEAD))};
  end
  wire perf_w = wr_at && hit(aw_off, sfh_abi_pkg::REG_PERF_CTRL);
  sfh_perf #(.NC(NPC)) u_perf (
    .clk, .rst_n, .inc(perf_inc), .snap(perf_w && w_data[0]), .clr(perf_w && w_data[1]),
    .snapshot(perf_snap)
  );

  // ---------------------------------------------------------------- AXI handshakes
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      aw_have <= 1'b0; w_have <= 1'b0; aw_off <= 12'd0; w_data <= 32'd0; w_strb <= 4'd0;
      s_bvalid <= 1'b0; s_bresp <= 2'b00;
      s_rvalid <= 1'b0; s_rdata <= 32'd0; s_rresp <= 2'b00;
    end else begin
      if (s_awvalid && s_awready) begin aw_have <= 1'b1; aw_off <= s_awaddr; end
      if (s_wvalid && s_wready)   begin w_have <= 1'b1; w_data <= s_wdata; w_strb <= s_wstrb; end
      if (do_wr) begin
        aw_have <= 1'b0; w_have <= 1'b0;
        s_bvalid <= 1'b1;
        s_bresp  <= (wr_rej || wr_db_rej) ? 2'b10 : 2'b00;
      end else if (s_bvalid && s_bready) begin
        s_bvalid <= 1'b0;
      end
      if (do_rd) begin
        s_rvalid <= 1'b1;
        s_rdata  <= rd_hit ? rd_val : 32'd0;
        s_rresp  <= rd_hit ? 2'b00 : 2'b10;
      end else if (s_rvalid && s_rready) begin
        s_rvalid <= 1'b0;
      end
    end
  end
  assign s_arready = !s_rvalid;

  // ---------------------------------------------------------------- register updates
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      enabled_q <= 1'b0; flush_q <= 1'b0; stop_q <= 1'b0; reset_req_q <= 1'b0; halted_q <= 1'b0;
      scratch_q <= 32'd0; timeout_q <= sfh_abi_pkg::RST_TIMEOUT;
      sq_base_q <= 64'd0; cq_base_q <= 64'd0; sq_log2_q <= 4'd0; cq_log2_q <= 4'd0;
      sq_tail_q <= 12'd0; cq_head_q <= 12'd0;
      win_base_q <= '0; win_size_q <= '0; win_ctrl_q <= '0;
      err_q <= 7'd0; err_off_q <= 12'd0; err_addr_q <= 64'd0; err_cmd_q <= 32'd0;
    end else if (i_srst) begin
      enabled_q <= 1'b0; flush_q <= 1'b0; stop_q <= 1'b0; reset_req_q <= 1'b0; halted_q <= 1'b0;
      scratch_q <= 32'd0; timeout_q <= sfh_abi_pkg::RST_TIMEOUT;
      sq_base_q <= 64'd0; cq_base_q <= 64'd0; sq_log2_q <= 4'd0; cq_log2_q <= 4'd0;
      sq_tail_q <= 12'd0; cq_head_q <= 12'd0;
      win_base_q <= '0; win_size_q <= '0; win_ctrl_q <= '0;
      err_q <= 7'd0; err_off_q <= 12'd0; err_addr_q <= 64'd0; err_cmd_q <= 32'd0;
    end else begin
      // ---- CTRL
      if (ctrl_wr) begin
        if (w_data[1]) begin
          reset_req_q <= 1'b1;
        end else begin
          flush_q <= w_data[2];
          stop_q  <= w_data[3];
          if (!w_data[0])       enabled_q <= 1'b0;
          else if (q_init)      enabled_q <= 1'b1;
          if (w_data[0])        halted_q  <= 1'b0;
        end
      end
      if (i_halt_set) halted_q <= 1'b1;               // a halt event wins over a racing resume
      if (q_init) begin sq_tail_q <= 12'd0; cq_head_q <= 12'd0; end
      // ---- plain RW / RWL registers
      if (wr_at) begin
        case (aw_off)
          sfh_abi_pkg::REG_SCRATCH:    scratch_q <= w_data & sfh_abi_pkg::WMASK_SCRATCH;
          sfh_abi_pkg::REG_TIMEOUT:    timeout_q <= w_data & sfh_abi_pkg::WMASK_TIMEOUT;
          sfh_abi_pkg::REG_SQ_BASE_LO: sq_base_q[31:0]  <= w_data & sfh_abi_pkg::WMASK_SQ_BASE_LO;
          sfh_abi_pkg::REG_SQ_BASE_HI: sq_base_q[63:32] <= w_data & sfh_abi_pkg::WMASK_SQ_BASE_HI;
          sfh_abi_pkg::REG_SQ_SIZE:    sq_log2_q <= w_data[3:0];
          sfh_abi_pkg::REG_CQ_BASE_LO: cq_base_q[31:0]  <= w_data & sfh_abi_pkg::WMASK_CQ_BASE_LO;
          sfh_abi_pkg::REG_CQ_BASE_HI: cq_base_q[63:32] <= w_data & sfh_abi_pkg::WMASK_CQ_BASE_HI;
          sfh_abi_pkg::REG_CQ_SIZE:    cq_log2_q <= w_data[3:0];
          sfh_abi_pkg::REG_SQ_TAIL:    sq_tail_q <= db_v;
          sfh_abi_pkg::REG_CQ_HEAD:    cq_head_q <= db_v;
          default: ;
        endcase
        for (int i = 0; i < NW; i++) begin
          if (aw_off == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 0))
            win_base_q[i*64 +: 32] <= w_data & sfh_abi_pkg::WMASK_WIN0_BASE_LO;
          if (aw_off == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 4))
            win_base_q[i*64+32 +: 32] <= w_data;
          if (aw_off == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 8))
            win_size_q[i*64 +: 32] <= w_data & sfh_abi_pkg::WMASK_WIN0_SIZE_LO;
          if (aw_off == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 12))
            win_size_q[i*64+32 +: 32] <= w_data;
          if (aw_off == 12'(sfh_abi_pkg::WIN_BASE + i * sfh_abi_pkg::WIN_STRIDE + 16))
            win_ctrl_q[i*3 +: 3] <= w_data[2:0];
        end
      end
      // ---- error log (new events win over a racing W1C)
      err_q <= (err_q & ~(err_w1c ? w_data[6:0] : 7'd0)) | err_new;
      if (ev_reg_rej || ev_db_rej) err_off_q <= (do_wr && (wr_rej || wr_db_rej)) ? aw_off : s_araddr;
      if (i_ev_host_bus || i_ev_host_tmo || i_ev_cmd_err) err_addr_q <= i_err_addr;
      if (i_ev_cmd_err) err_cmd_q <= {i_err_cmd_sqidx, i_err_cmd_status};
    end
  end

  // ---------------------------------------------------------------- outputs
  assign o_enabled     = enabled_q;
  assign o_flush_all   = flush_q;
  assign o_stop_on_err = stop_q;
  assign o_timeout     = timeout_q;
  assign o_sq_base     = sq_base_q;
  assign o_sq_log2     = sq_log2_q;
  assign o_cq_base     = cq_base_q;
  assign o_cq_log2     = cq_log2_q;
  assign o_win_base    = win_base_q;
  assign o_win_size    = win_size_q;
  assign o_win_ctrl    = win_ctrl_q;
  assign o_sq_tail     = sq_tail_q;
  assign o_cq_head     = cq_head_q;
  assign o_q_init      = q_init;
  assign o_reset_req   = reset_req_q;
  assign o_halted      = halted_q;
endmodule

`default_nettype wire
