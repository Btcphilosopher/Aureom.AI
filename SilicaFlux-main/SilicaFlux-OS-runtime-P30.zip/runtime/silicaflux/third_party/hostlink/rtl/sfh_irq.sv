// =============================================================================
// SilicaFlux HostLink :: sfh_irq -- interrupt status / mask / message generator
//
// Two sources: 0 = CQ (completion posted with IRQ flag or error status),
//              1 = ERROR (device-level error recorded in ERR_STATUS).
// INT_STATUS  sticky, W1C.  An event in the same cycle as a W1C wins (an
//             interrupt is never lost to a racing clear).
// INT_ENABLE  per-source mask.  Status still latches while masked; enabling a
//             source whose status is set arms a message immediately.
// Messages    every enabled event arms its source; armed sources are
//             coalesced while a message is pending.  A source is disarmed if
//             its status is cleared or it is masked before its message is
//             loaded.  The presented message (msg_valid/msg_vector) is held
//             stable until msg_ready (valid/ready rule): a message already
//             presented to the endpoint is never withdrawn.  Sources mapped to
//             the same vector are delivered by one message.
// Level       irq_level = |(INT_STATUS & INT_ENABLE) for INTx-style hosts and
//             polling.
// Ordering: the queue engine raises ev[0] only after the completion entry
// write has been acknowledged by the host bus (and after the optional flush
// read), so a message can never overtake the completion it announces inside
// HostLink (see docs/05_INTERRUPTS.md for the endpoint-side requirement).
// =============================================================================
`default_nettype none

module sfh_irq #(
  parameter int NV = 2              // message vectors implemented
) (
  input  wire logic       clk,
  input  wire logic       rst_n,
  input  wire logic       srst,              // synchronous soft reset
  input  wire logic [1:0] ev,                // event pulses {ERROR, CQ}
  input  wire logic       w1c_we,
  input  wire logic [1:0] w1c_mask,
  input  wire logic       en_we,
  input  wire logic [1:0] en_val,
  input  wire logic       vec_we,
  input  wire logic [3:0] vec_cq_val,
  input  wire logic [3:0] vec_err_val,
  output logic [1:0]      status,
  output logic [1:0]      enable,
  output logic [3:0]      vec_cq,
  output logic [3:0]      vec_err,
  output logic            msg_valid,
  output logic [3:0]      msg_vector,
  input  wire logic       msg_ready,
  output logic            irq_level,
  output logic            ev_msg_sent
);
  logic [1:0] pend_q;

  wire [1:0] clr      = w1c_we ? w1c_mask : 2'b00;
  wire [1:0] status_n = (status & ~clr) | ev;
  wire [1:0] enable_n = en_we ? en_val : enable;
  wire [1:0] arm      = (ev & enable_n) | (en_we ? (en_val & ~enable & status_n) : 2'b00);
  wire       hs       = msg_valid && msg_ready;
  // sources still eligible after this cycle's clears/masks (before loading)
  wire [1:0] pend_eff = (pend_q | arm) & status_n & enable_n;
  wire       can_load = !msg_valid || hs;
  wire       ld       = can_load && (pend_eff != 2'b00);
  wire [3:0] ld_vec   = pend_eff[0] ? vec_cq : vec_err;
  wire [1:0] covered  = {pend_eff[1] && (vec_err == ld_vec), pend_eff[0] && (vec_cq == ld_vec)};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      status <= 2'b00; enable <= 2'b00; vec_cq <= 4'd0; vec_err <= 4'd1;
      pend_q <= 2'b00; msg_valid <= 1'b0; msg_vector <= 4'd0;
    end else if (srst) begin
      status <= 2'b00; enable <= 2'b00; vec_cq <= 4'd0; vec_err <= 4'd1;
      pend_q <= 2'b00;
      // a presented message must stay until accepted (valid/ready rule)
      if (hs) msg_valid <= 1'b0;
    end else begin
      status <= status_n;
      enable <= enable_n;
      if (vec_we) begin vec_cq <= vec_cq_val; vec_err <= vec_err_val; end
      if (hs) msg_valid <= 1'b0;
      if (ld) begin
        msg_valid  <= 1'b1;
        msg_vector <= ld_vec;
        pend_q     <= pend_eff & ~covered;
      end else begin
        pend_q     <= pend_eff;
      end
    end
  end

  assign irq_level   = |(status & enable);
  assign ev_msg_sent = hs;

  // NV is checked by the register block (INT_VECTOR writes >= NV rejected)
  wire unused_nv = (NV > 0);
endmodule

`default_nettype wire
