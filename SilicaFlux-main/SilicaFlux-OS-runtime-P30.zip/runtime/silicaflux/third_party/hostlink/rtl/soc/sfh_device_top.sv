// =============================================================================
// SilicaFlux HostLink :: sfh_device_top -- accelerator device behind the endpoint
//
//   endpoint IP ports ──► sfh_ep_axi_shell ──► silicaflux_host_pcie
//                                                │ SFB2 (M0)        │ TE register page
//   external SFB2 master (M1, e.g. ControlCore) ─┤                  │
//                                       sfb_crossbar (2x2, round robin)
//                                         │ S0                │ S1
//                                 sfb_sram_slave        sfb_v1_slave_adapter
//                                 device SRAM 64 KiB    sfv_tile TSPM 16 KiB
//                                 @ 0x1000_0000         @ 0x2000_0000 (+ VE, TE)
//
// Reused UNMODIFIED from the repository (third_party/, SHA-256 in
// third_party/SHA256SUMS.datafabric): sfb_crossbar and its sub-blocks,
// sfb_sram_slave (+ SilicaFlux SRAM Wrapper Library), sfb_v1_slave_adapter,
// sfv_tile / sfv_tensor_engine / sfv_vec_engine, sfv_rst_sync.
// The compute tile is held in reset (synchronised release) while HostLink
// requests it (soft reset, engine timeout).  Build with SFV_NO_CLOCK_GATE
// (FPGA and simulation configuration of sfv_clkgate).
// =============================================================================
`default_nettype none

module sfh_device_top #(
  parameter int          NW           = 4,
  parameter int          NV           = 2,
  parameter int          MAXB         = 16,
  parameter logic [31:0] DM0_BASE     = 32'h1000_0000,
  parameter logic [31:0] DM0_SIZE     = 32'h0001_0000,     // power of two
  parameter logic [31:0] DM1_BASE     = 32'h2000_0000,
  parameter logic [31:0] DM1_SIZE     = 32'h0000_4000,     // = TSPM bytes
  localparam int         IDW          = 4
) (
  input  wire logic           clk,
  input  wire logic           ep_rst_n,
  // ------------------------------------------------------------ endpoint BAR master (AXI4, 32-bit)
  input  wire logic           s_bar_awvalid,
  output logic                s_bar_awready,
  input  wire logic [IDW-1:0] s_bar_awid,
  input  wire logic [31:0]    s_bar_awaddr,
  input  wire logic [7:0]     s_bar_awlen,
  input  wire logic [2:0]     s_bar_awsize,
  input  wire logic [1:0]     s_bar_awburst,
  input  wire logic           s_bar_wvalid,
  output logic                s_bar_wready,
  input  wire logic [31:0]    s_bar_wdata,
  input  wire logic [3:0]     s_bar_wstrb,
  input  wire logic           s_bar_wlast,
  output logic                s_bar_bvalid,
  input  wire logic           s_bar_bready,
  output logic [IDW-1:0]      s_bar_bid,
  output logic [1:0]          s_bar_bresp,
  input  wire logic           s_bar_arvalid,
  output logic                s_bar_arready,
  input  wire logic [IDW-1:0] s_bar_arid,
  input  wire logic [31:0]    s_bar_araddr,
  input  wire logic [7:0]     s_bar_arlen,
  input  wire logic [2:0]     s_bar_arsize,
  input  wire logic [1:0]     s_bar_arburst,
  output logic                s_bar_rvalid,
  input  wire logic           s_bar_rready,
  output logic [IDW-1:0]      s_bar_rid,
  output logic [31:0]         s_bar_rdata,
  output logic [1:0]          s_bar_rresp,
  output logic                s_bar_rlast,
  // ------------------------------------------------------------ host memory (to endpoint slave bridge, AXI4 64-bit)
  output logic                m_host_awvalid,
  input  wire logic           m_host_awready,
  output logic [63:0]         m_host_awaddr,
  output logic [7:0]          m_host_awlen,
  output logic [2:0]          m_host_awsize,
  output logic [1:0]          m_host_awburst,
  output logic [3:0]          m_host_awid,
  output logic                m_host_wvalid,
  input  wire logic           m_host_wready,
  output logic [63:0]         m_host_wdata,
  output logic [7:0]          m_host_wstrb,
  output logic                m_host_wlast,
  input  wire logic           m_host_bvalid,
  output logic                m_host_bready,
  input  wire logic [1:0]     m_host_bresp,
  input  wire logic [3:0]     m_host_bid,
  output logic                m_host_arvalid,
  input  wire logic           m_host_arready,
  output logic [63:0]         m_host_araddr,
  output logic [7:0]          m_host_arlen,
  output logic [2:0]          m_host_arsize,
  output logic [1:0]          m_host_arburst,
  output logic [3:0]          m_host_arid,
  input  wire logic           m_host_rvalid,
  output logic                m_host_rready,
  input  wire logic [63:0]    m_host_rdata,
  input  wire logic [1:0]     m_host_rresp,
  input  wire logic           m_host_rlast,
  input  wire logic [3:0]     m_host_rid,
  // ------------------------------------------------------------ interrupts (to endpoint MSI/MSI-X request)
  output logic                irq_valid,
  output logic [3:0]          irq_vector,
  input  wire logic           irq_ready,
  output logic                irq_level,
  // ------------------------------------------------------------ second DataFabric master (ControlCore / test agent)
  input  wire logic           x_req_valid,
  output logic                x_req_ready,
  input  wire logic           x_req_write,
  input  wire logic [31:0]    x_req_addr,
  input  wire logic [31:0]    x_req_wdata,
  input  wire logic [3:0]     x_req_wstrb,
  output logic                x_rsp_valid,
  input  wire logic           x_rsp_ready,
  output logic [31:0]         x_rsp_rdata,
  output logic                x_rsp_error
);
  localparam int TSPM_WORDS = DM1_SIZE / 4;
  localparam int TBW        = $clog2(TSPM_WORDS / 4);

  // ---------------------------------------------------------------- endpoint shell
  logic        rst_n;
  logic        l_awvalid, l_awready, l_wvalid, l_wready, l_bvalid, l_bready;
  logic        l_arvalid, l_arready, l_rvalid, l_rready;
  logic [11:0] l_awaddr, l_araddr;
  logic [31:0] l_wdata, l_rdata;
  logic [3:0]  l_wstrb;
  logic [1:0]  l_bresp, l_rresp;

  sfh_ep_axi_shell #(.IDW(IDW)) u_shell (
    .clk, .ep_rst_n, .core_rst_n(rst_n),
    .s_awvalid(s_bar_awvalid), .s_awready(s_bar_awready), .s_awid(s_bar_awid), .s_awaddr(s_bar_awaddr),
    .s_awlen(s_bar_awlen), .s_awsize(s_bar_awsize), .s_awburst(s_bar_awburst),
    .s_wvalid(s_bar_wvalid), .s_wready(s_bar_wready), .s_wdata(s_bar_wdata), .s_wstrb(s_bar_wstrb),
    .s_wlast(s_bar_wlast), .s_bvalid(s_bar_bvalid), .s_bready(s_bar_bready), .s_bid(s_bar_bid),
    .s_bresp(s_bar_bresp), .s_arvalid(s_bar_arvalid), .s_arready(s_bar_arready), .s_arid(s_bar_arid),
    .s_araddr(s_bar_araddr), .s_arlen(s_bar_arlen), .s_arsize(s_bar_arsize), .s_arburst(s_bar_arburst),
    .s_rvalid(s_bar_rvalid), .s_rready(s_bar_rready), .s_rid(s_bar_rid), .s_rdata(s_bar_rdata),
    .s_rresp(s_bar_rresp), .s_rlast(s_bar_rlast),
    .l_awvalid, .l_awready, .l_awaddr, .l_wvalid, .l_wready, .l_wdata, .l_wstrb,
    .l_bvalid, .l_bready, .l_bresp, .l_arvalid, .l_arready, .l_araddr,
    .l_rvalid, .l_rready, .l_rdata, .l_rresp
  );

  // ---------------------------------------------------------------- HostLink core
  logic        hl_req_valid, hl_req_ready, hl_req_write, hl_rsp_valid, hl_rsp_ready, hl_rsp_error;
  logic [31:0] hl_req_addr, hl_req_wdata, hl_rsp_rdata;
  logic [3:0]  hl_req_wstrb;
  logic        te_sel, te_rb_we, tile_rst_req;
  logic [11:0] te_rb_addr;
  logic [31:0] te_rb_wdata, te_rdata;

  silicaflux_host_pcie #(
    .NW(NW), .NV(NV), .MAXB(MAXB),
    .DM0_BASE(DM0_BASE), .DM0_SIZE(DM0_SIZE), .DM1_BASE(DM1_BASE), .DM1_SIZE(DM1_SIZE)
  ) u_hostlink (
    .clk, .rst_n,
    .s_bar_awvalid(l_awvalid), .s_bar_awready(l_awready), .s_bar_awaddr(l_awaddr),
    .s_bar_wvalid(l_wvalid), .s_bar_wready(l_wready), .s_bar_wdata(l_wdata), .s_bar_wstrb(l_wstrb),
    .s_bar_bvalid(l_bvalid), .s_bar_bready(l_bready), .s_bar_bresp(l_bresp),
    .s_bar_arvalid(l_arvalid), .s_bar_arready(l_arready), .s_bar_araddr(l_araddr),
    .s_bar_rvalid(l_rvalid), .s_bar_rready(l_rready), .s_bar_rdata(l_rdata), .s_bar_rresp(l_rresp),
    .m_host_awvalid, .m_host_awready, .m_host_awaddr, .m_host_awlen, .m_host_awsize, .m_host_awburst,
    .m_host_awid, .m_host_wvalid, .m_host_wready, .m_host_wdata, .m_host_wstrb, .m_host_wlast,
    .m_host_bvalid, .m_host_bready, .m_host_bresp, .m_host_bid,
    .m_host_arvalid, .m_host_arready, .m_host_araddr, .m_host_arlen, .m_host_arsize, .m_host_arburst,
    .m_host_arid, .m_host_rvalid, .m_host_rready, .m_host_rdata, .m_host_rresp, .m_host_rlast,
    .m_host_rid,
    .irq_valid, .irq_vector, .irq_ready, .irq_level,
    .df_req_valid(hl_req_valid), .df_req_ready(hl_req_ready), .df_req_write(hl_req_write),
    .df_req_addr(hl_req_addr), .df_req_wdata(hl_req_wdata), .df_req_wstrb(hl_req_wstrb),
    .df_rsp_valid(hl_rsp_valid), .df_rsp_ready(hl_rsp_ready), .df_rsp_rdata(hl_rsp_rdata),
    .df_rsp_error(hl_rsp_error),
    .te_sel, .te_rb_we, .te_rb_addr, .te_rb_wdata, .te_rdata, .tile_rst_req
  );

  // ---------------------------------------------------------------- DataFabric crossbar
  localparam logic [63:0] SLV_BASE = {DM1_BASE, DM0_BASE};
  localparam logic [63:0] SLV_MASK = {~(DM1_SIZE - 32'd1), ~(DM0_SIZE - 32'd1)};
  logic [1:0]  s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [63:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [7:0]  s_req_wstrb;
  logic [1:0]  m_rsp_valid, m_rsp_error, m_req_ready;
  logic [63:0] m_rsp_rdata;
  logic        err_evt_unused, err_write_unused;
  logic [31:0] err_addr_unused;
  logic [0:0]  err_master_unused;
  logic [1:0]  ev_a_unused, ev_s_unused, ev_l_unused, ev_r_unused;

  sfb_crossbar #(
    .NM(2), .NS(2), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE(SLV_BASE), .SLV_MASK(SLV_MASK), .MST_SLV_EN(4'b1111)
  ) u_xbar (
    .clk, .rst_n,
    .m_req_valid({x_req_valid, hl_req_valid}), .m_req_ready(m_req_ready),
    .m_req_write({x_req_write, hl_req_write}), .m_req_addr({x_req_addr, hl_req_addr}),
    .m_req_wdata({x_req_wdata, hl_req_wdata}), .m_req_wstrb({x_req_wstrb, hl_req_wstrb}),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready({x_rsp_ready, hl_rsp_ready}),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(err_evt_unused), .err_addr(err_addr_unused), .err_master(err_master_unused),
    .err_write(err_write_unused),
    .ev_req_accept(ev_a_unused), .ev_req_stall(ev_s_unused), .ev_arb_loss(ev_l_unused),
    .ev_rsp_stall(ev_r_unused)
  );
  assign hl_req_ready = m_req_ready[0];
  assign x_req_ready  = m_req_ready[1];
  assign hl_rsp_valid = m_rsp_valid[0];
  assign x_rsp_valid  = m_rsp_valid[1];
  assign hl_rsp_rdata = m_rsp_rdata[31:0];
  assign x_rsp_rdata  = m_rsp_rdata[63:32];
  assign hl_rsp_error = m_rsp_error[0];
  assign x_rsp_error  = m_rsp_error[1];

  // ---------------------------------------------------------------- S0: device SRAM
  logic [31:0] tst_rdata_unused;
  sfb_sram_slave #(.DW(32), .DEPTH(DM0_SIZE / 4), .READ_LATENCY(1)) u_sram (
    .clk, .rst_n,
    .req_valid(s_req_valid[0]), .req_ready(s_req_ready[0]), .req_write(s_req_write[0]),
    .req_addr(s_req_addr[31:0]), .req_wdata(s_req_wdata[31:0]), .req_wstrb(s_req_wstrb[3:0]),
    .rsp_valid(s_rsp_valid[0]), .rsp_ready(s_rsp_ready[0]), .rsp_rdata(s_rsp_rdata[31:0]),
    .rsp_error(s_rsp_error[0]),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata(32'd0),
    .tst_rdata(tst_rdata_unused)
  );

  // ---------------------------------------------------------------- S1: compute tile (TSPM + engines)
  logic        tile_rst_n;
  sfv_rst_sync #(.STAGES(2)) u_tile_rst (
    .clk, .rst_ni(rst_n && !tile_rst_req), .test_mode(1'b0), .test_rst_ni(1'b1), .rst_no(tile_rst_n)
  );
  logic        v1_req, v1_gnt, v1_we, v1_rvalid, v1_err;
  logic [31:0] v1_addr, v1_wdata, v1_rdata;
  logic [3:0]  v1_be;
  sfb_v1_slave_adapter u_tspm_adp (
    .clk, .rst_n,
    .req_valid(s_req_valid[1]), .req_ready(s_req_ready[1]), .req_write(s_req_write[1]),
    .req_addr(s_req_addr[63:32]), .req_wdata(s_req_wdata[63:32]), .req_wstrb(s_req_wstrb[7:4]),
    .rsp_valid(s_rsp_valid[1]), .rsp_ready(s_rsp_ready[1]), .rsp_rdata(s_rsp_rdata[63:32]),
    .rsp_error(s_rsp_error[1]),
    .v1_req, .v1_gnt, .v1_addr, .v1_we, .v1_be, .v1_wdata, .v1_rvalid, .v1_rdata, .v1_err
  );

  logic [31:0]          ve_rdata_unused;
  logic                 ve_err_unused, te_err_unused, irq_ve_unused, irq_te_unused;
  logic [4*32-1:0]      bist_rdata_unused;
  sfv_tile #(.LANES(4), .MUL_W(32), .TSPM_WORDS(TSPM_WORDS)) u_tile (
    .clk, .rst_n(tile_rst_n), .test_mode(1'b0), .cg_off(1'b1),
    .req(v1_req), .gnt(v1_gnt), .addr(v1_addr), .we(v1_we), .be(v1_be), .wdata(v1_wdata),
    .rvalid(v1_rvalid), .rdata(v1_rdata), .err(v1_err),
    .ve_sel(1'b0), .te_sel, .rb_we(te_rb_we), .rb_addr(te_rb_addr), .rb_wdata(te_rb_wdata),
    .ve_rdata(ve_rdata_unused), .ve_err(ve_err_unused), .te_rdata, .te_err(te_err_unused),
    .irq_ve(irq_ve_unused), .irq_te(irq_te_unused),
    .bist_en(1'b0), .bist_ce(1'b0), .bist_we(1'b0), .bist_addr({TBW{1'b0}}), .bist_wdata(32'd0),
    .bist_rdata(bist_rdata_unused)
  );
endmodule

`default_nettype wire
