// =============================================================================
// SilicaFlux HostLink :: sfh_win_check -- host DMA address-window check
//
// ok = 1 iff the byte range [addr, addr + len) lies completely inside at least
// one window that is VALID and grants every requested permission
// (need_rd -> DEV_READ, need_wr -> DEV_WRITE).
//
// Overflow-safe: every sum is computed in 65 bits, so an addr + len or a
// base + size that wraps past 2^64 can never alias to a low address; a range
// whose exclusive end is beyond 2^64 is always rejected (ending exactly at
// 2^64 is legal: found by t_window_overflow).  len = 0 is rejected (callers
// never ask for empty ranges; an empty range is not "inside" anything here).
// Pure combinational.  Used for SQ/CQ ring checks (sfh_bar_regs) and for
// every DMA command (sfh_cmd_validate).
// =============================================================================
`default_nettype none

module sfh_win_check #(
  parameter int NW = 4
) (
  input  wire logic [63:0]      addr,
  input  wire logic [31:0]      len,
  input  wire logic             need_rd,
  input  wire logic             need_wr,
  input  wire logic [NW*64-1:0] win_base,
  input  wire logic [NW*64-1:0] win_size,
  input  wire logic [NW*3-1:0]  win_ctrl,     // per window {DEV_WRITE, DEV_READ, VALID}
  output logic                  ok
);
  wire [64:0] r_end = {1'b0, addr} + {33'd0, len};

  always_comb begin
    ok = 1'b0;
    for (int i = 0; i < NW; i++) begin
      if (win_ctrl[i*3 + 0] &&
          (!need_rd || win_ctrl[i*3 + 1]) &&
          (!need_wr || win_ctrl[i*3 + 2]) &&
          (len != 32'd0) && (r_end <= 65'h1_0000_0000_0000_0000) &&
          ({1'b0, addr} >= {1'b0, win_base[i*64 +: 64]}) &&
          (r_end <= ({1'b0, win_base[i*64 +: 64]} + {1'b0, win_size[i*64 +: 64]})))
        ok = 1'b1;
    end
  end
endmodule

`default_nettype wire
