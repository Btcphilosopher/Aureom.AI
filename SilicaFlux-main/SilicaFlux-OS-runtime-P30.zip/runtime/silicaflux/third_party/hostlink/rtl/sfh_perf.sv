// =============================================================================
// SilicaFlux HostLink :: sfh_perf -- 64-bit event counters with atomic snapshot
//
// NC live counters, each incremented by inc[i*16 +: 16] per cycle.
// snap: copy every live counter (including this cycle's increment) into the
//       software-visible snapshot registers in one cycle -> all PERF_* values
//       read afterwards are mutually consistent and LO/HI cannot tear.
// clr : zero live counters and snapshots (clr wins over snap and inc).
// Counters are NOT affected by the HostLink soft reset (CTRL.RESET) so that
// a reset can be diagnosed; only the endpoint reset (rst_n) clears them.
// =============================================================================
`default_nettype none

module sfh_perf #(
  parameter int NC = 10
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [NC*16-1:0] inc,
  input  wire logic             snap,
  input  wire logic             clr,
  output logic [NC*64-1:0]      snapshot
);
  logic [NC*64-1:0] live_q;

  for (genvar i = 0; i < NC; i++) begin : g_c
    wire [63:0] nxt = live_q[i*64 +: 64] + {48'd0, inc[i*16 +: 16]};
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        live_q[i*64 +: 64]   <= 64'd0;
        snapshot[i*64 +: 64] <= 64'd0;
      end else if (clr) begin
        live_q[i*64 +: 64]   <= 64'd0;
        snapshot[i*64 +: 64] <= 64'd0;
      end else begin
        live_q[i*64 +: 64] <= nxt;
        if (snap) snapshot[i*64 +: 64] <= nxt;
      end
    end
  end
endmodule

`default_nettype wire
