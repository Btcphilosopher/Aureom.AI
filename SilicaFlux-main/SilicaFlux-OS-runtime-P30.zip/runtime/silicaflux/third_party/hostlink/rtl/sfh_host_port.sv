// =============================================================================
// SilicaFlux HostLink :: sfh_host_port -- AXI4 master towards host memory
//
// Connects to the slave (user->PCIe) bridge port of the endpoint IP; every
// transaction becomes PCIe memory read/write requests to host IOVAs.
// One transaction at a time (one burst): AR -> R* or AW -> W* -> B.
//   * INCR bursts of 1..MAXB beats, 64-bit beats (AxSIZE = 3), AxID = 0;
//   * the caller guarantees that a burst never crosses a 4 KiB boundary
//     (AXI rule, and PCIe requests must not cross 4 KiB); checked in
//     simulation;
//   * WSTRB is always all-ones (HostLink only moves whole 8-byte beats);
//   * AW is accepted before the first W beat is sent (no W-before-AW);
//   * a burst is never abandoned: once AR/AW is issued, all R beats / all W
//     beats + B are completed even after a timeout or a reset request (AXI
//     has no cancel).  `idle` tells the engine when the port is quiescent.
// Data buffer: MAXB x 64 bit, written by R beats (reads) or by the engine
// (bw_*, 32-bit halves), read by W beats (writes) or by the engine (buf_flat).
// Watchdog: `tmo` pulses once when the current transaction has been
// outstanding for `timeout` cycles (0 disables); the transaction keeps
// draining.  `done` pulses when the transaction finished; `done_err` = any
// R/B response other than OKAY, or an RLAST mismatch.
// =============================================================================
`default_nettype none

module sfh_host_port #(
  parameter int MAXB = 16,
  localparam int BIW = $clog2(MAXB)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ------------------------------------------------------------ engine side
  input  wire logic              req_valid,
  output logic                   req_ready,      // == idle
  input  wire logic              req_write,
  input  wire logic [63:0]       req_addr,
  input  wire logic [BIW:0]      req_beats,      // 1..MAXB
  output logic                   done,
  output logic                   done_err,
  output logic                   idle,
  input  wire logic [31:0]       timeout,
  output logic                   tmo,
  input  wire logic              bw_en,
  input  wire logic [BIW-1:0]    bw_idx,
  input  wire logic [1:0]        bw_hmask,       // 32-bit halves to write
  input  wire logic [63:0]       bw_data,
  output logic [MAXB*64-1:0]     buf_flat,
  // ------------------------------------------------------------ AXI4 master
  output logic                   m_awvalid,
  input  wire logic              m_awready,
  output logic [63:0]            m_awaddr,
  output logic [7:0]             m_awlen,
  output logic [2:0]             m_awsize,
  output logic [1:0]             m_awburst,
  output logic [3:0]             m_awid,
  output logic                   m_wvalid,
  input  wire logic              m_wready,
  output logic [63:0]            m_wdata,
  output logic [7:0]             m_wstrb,
  output logic                   m_wlast,
  input  wire logic              m_bvalid,
  output logic                   m_bready,
  input  wire logic [1:0]        m_bresp,
  input  wire logic [3:0]        m_bid,
  output logic                   m_arvalid,
  input  wire logic              m_arready,
  output logic [63:0]            m_araddr,
  output logic [7:0]             m_arlen,
  output logic [2:0]             m_arsize,
  output logic [1:0]             m_arburst,
  output logic [3:0]             m_arid,
  input  wire logic              m_rvalid,
  output logic                   m_rready,
  input  wire logic [63:0]       m_rdata,
  input  wire logic [1:0]        m_rresp,
  input  wire logic              m_rlast,
  input  wire logic [3:0]        m_rid
);
  typedef enum logic [2:0] {P_IDLE, P_AR, P_R, P_AW, P_W, P_B} pst_e;
  pst_e st;

  logic [63:0]   addr_q;
  logic [BIW:0]  beats_q;          // total beats
  logic [BIW:0]  cnt_q;            // beats transferred
  logic          err_q, tmo_done_q;
  logic [31:0]   wd_q;
  logic [63:0]   buf_q [MAXB];

  assign idle      = (st == P_IDLE);
  assign req_ready = idle;
  wire   go        = req_valid && idle;

  // ---------------------------------------------------------------- AXI outputs
  assign m_awvalid = (st == P_AW);
  assign m_awaddr  = addr_q;
  assign m_awlen   = 8'(beats_q) - 8'd1;
  assign m_awsize  = 3'd3;
  assign m_awburst = 2'b01;
  assign m_awid    = 4'd0;
  assign m_wvalid  = (st == P_W);
  assign m_wdata   = buf_q[cnt_q[BIW-1:0]];
  assign m_wstrb   = 8'hFF;
  assign m_wlast   = (cnt_q == beats_q - 1'b1);
  assign m_bready  = (st == P_B);
  assign m_arvalid = (st == P_AR);
  assign m_araddr  = addr_q;
  assign m_arlen   = 8'(beats_q) - 8'd1;
  assign m_arsize  = 3'd3;
  assign m_arburst = 2'b01;
  assign m_arid    = 4'd0;
  assign m_rready  = (st == P_R);

  wire r_hs   = m_rvalid && m_rready;
  wire r_last = (cnt_q == beats_q - 1'b1);

  // ---------------------------------------------------------------- FSM
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= P_IDLE; addr_q <= 64'd0; beats_q <= '0; cnt_q <= '0; err_q <= 1'b0;
      done <= 1'b0; done_err <= 1'b0; tmo <= 1'b0; tmo_done_q <= 1'b0; wd_q <= 32'd0;
    end else begin
      done <= 1'b0; done_err <= 1'b0; tmo <= 1'b0;
      if (st != P_IDLE) begin
        wd_q <= wd_q + 32'd1;
        if (timeout != 32'd0 && wd_q + 32'd1 >= timeout && !tmo_done_q) begin
          tmo <= 1'b1; tmo_done_q <= 1'b1;
        end
      end
      case (st)
        P_IDLE: if (go) begin
          addr_q <= req_addr; beats_q <= req_beats; cnt_q <= '0; err_q <= 1'b0;
          wd_q <= 32'd0; tmo_done_q <= 1'b0;
          st <= req_write ? P_AW : P_AR;
        end
        P_AR: if (m_arready) st <= P_R;
        P_R: if (r_hs) begin
          if (m_rresp != 2'b00 || m_rlast != r_last || m_rid != 4'd0) err_q <= 1'b1;
          cnt_q <= cnt_q + 1'b1;
          if (r_last) begin
            st <= P_IDLE; done <= 1'b1;
            done_err <= err_q || m_rresp != 2'b00 || !m_rlast || m_rid != 4'd0;
          end
        end
        P_AW: if (m_awready) st <= P_W;
        P_W: if (m_wready) begin
          cnt_q <= cnt_q + 1'b1;
          if (m_wlast) st <= P_B;
        end
        default: if (m_bvalid) begin           // P_B
          st <= P_IDLE; done <= 1'b1;
          done_err <= (m_bresp != 2'b00) || (m_bid != 4'd0);
        end
      endcase
    end
  end

  // ---------------------------------------------------------------- buffer (datapath, not reset)
  always_ff @(posedge clk) begin
    if (st == P_R && r_hs) begin
      buf_q[cnt_q[BIW-1:0]] <= m_rdata;
    end else if (bw_en) begin
      if (bw_hmask[0]) buf_q[bw_idx][31:0]  <= bw_data[31:0];
      if (bw_hmask[1]) buf_q[bw_idx][63:32] <= bw_data[63:32];
    end
  end
  for (genvar i = 0; i < MAXB; i++) begin : g_flat
    assign buf_flat[i*64 +: 64] = buf_q[i];
  end

`ifndef SYNTHESIS
  // simulation-only protocol self-checks (never feed logic)
  always @(posedge clk) begin
    if (go) begin
      if (req_beats == '0 || req_beats > (BIW+1)'(MAXB))
        $error("sfh_host_port: illegal beat count %0d", req_beats);
      if ({52'd0, req_addr[11:0]} + 64'(req_beats) * 64'd8 > 64'd4096)
        $error("sfh_host_port: burst crosses 4 KiB (addr %h beats %0d)", req_addr, req_beats);
      if (req_addr[2:0] != 3'd0)
        $error("sfh_host_port: unaligned address %h", req_addr);
    end
  end
`endif
endmodule

`default_nettype wire
