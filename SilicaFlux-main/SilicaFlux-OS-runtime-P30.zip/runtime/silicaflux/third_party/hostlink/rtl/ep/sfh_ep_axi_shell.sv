// =============================================================================
// SilicaFlux HostLink :: sfh_ep_axi_shell -- endpoint integration wrapper
//
// The boundary between a vendor PCIe endpoint IP and silicaflux_host_pcie.
// It contains NO PCIe protocol logic; it adapts the generic AXI ports that
// AXI-bridge style endpoints expose:
//   1. BAR target: the endpoint forwards BAR0 memory requests as AXI4 (or
//      AXI4-Lite) transactions.  This shell converts them to the HostLink
//      AXI4-Lite target: single-beat 32-bit accesses (AxLEN = 0, AxSIZE = 2)
//      are forwarded; any burst or narrow/wide access is answered locally with
//      SLVERR (all W beats consumed, LEN+1 R beats returned), so a misbehaving
//      driver can never confuse the register file.  IDs are echoed.  One
//      write and one read in flight.  BAR offset = AxADDR[11:0] (BAR0 is
//      4 KiB; the endpoint's BAR-to-AXI translation decides the upper bits).
//      An AXI4-Lite BAR master connects by tying AxLEN = 0, AxSIZE = 2,
//      AxBURST = 1, AxID = 0, WLAST = 1.
//   2. Reset: the endpoint's user reset (active low) is synchronised with
//      sfv_rst_sync (async assert, sync release) -> core_rst_n.  A PCIe hot
//      reset, link-down or FLR handled by the endpoint IP must assert it.
// The host-memory AXI4 master and the interrupt request pass straight
// through the device top (no adaptation needed for an AXI slave bridge with
// identity address translation).  See docs/07_ENDPOINT_INTEGRATION.md for the
// per-vendor mapping and what remains to be verified on real IP.
// =============================================================================
`default_nettype none

module sfh_ep_axi_shell #(
  parameter int IDW = 4
) (
  input  wire logic           clk,
  input  wire logic           ep_rst_n,          // endpoint user reset, active low
  output logic                core_rst_n,
  // ------------------------------------------------------------ from endpoint BAR master (AXI4)
  input  wire logic           s_awvalid,
  output logic                s_awready,
  input  wire logic [IDW-1:0] s_awid,
  input  wire logic [31:0]    s_awaddr,
  input  wire logic [7:0]     s_awlen,
  input  wire logic [2:0]     s_awsize,
  input  wire logic [1:0]     s_awburst,
  input  wire logic           s_wvalid,
  output logic                s_wready,
  input  wire logic [31:0]    s_wdata,
  input  wire logic [3:0]     s_wstrb,
  input  wire logic           s_wlast,
  output logic                s_bvalid,
  input  wire logic           s_bready,
  output logic [IDW-1:0]      s_bid,
  output logic [1:0]          s_bresp,
  input  wire logic           s_arvalid,
  output logic                s_arready,
  input  wire logic [IDW-1:0] s_arid,
  input  wire logic [31:0]    s_araddr,
  input  wire logic [7:0]     s_arlen,
  input  wire logic [2:0]     s_arsize,
  input  wire logic [1:0]     s_arburst,
  output logic                s_rvalid,
  input  wire logic           s_rready,
  output logic [IDW-1:0]      s_rid,
  output logic [31:0]         s_rdata,
  output logic [1:0]          s_rresp,
  output logic                s_rlast,
  // ------------------------------------------------------------ to HostLink BAR target (AXI4-Lite)
  output logic                l_awvalid,
  input  wire logic           l_awready,
  output logic [11:0]         l_awaddr,
  output logic                l_wvalid,
  input  wire logic           l_wready,
  output logic [31:0]         l_wdata,
  output logic [3:0]          l_wstrb,
  input  wire logic           l_bvalid,
  output logic                l_bready,
  input  wire logic [1:0]     l_bresp,
  output logic                l_arvalid,
  input  wire logic           l_arready,
  output logic [11:0]         l_araddr,
  input  wire logic           l_rvalid,
  output logic                l_rready,
  input  wire logic [31:0]    l_rdata,
  input  wire logic [1:0]     l_rresp
);
  // ---------------------------------------------------------------- reset
  sfv_rst_sync #(.STAGES(2)) u_rst (
    .clk, .rst_ni(ep_rst_n), .test_mode(1'b0), .test_rst_ni(1'b1), .rst_no(core_rst_n)
  );
  wire rst_n = core_rst_n;

  // ---------------------------------------------------------------- write path
  typedef enum logic [2:0] {W_IDLE, W_FWD, W_B, W_DRAIN, W_RESP} wst_e;
  wst_e          ws;
  logic [IDW-1:0] wid_q;
  logic [11:0]   waddr_q;
  logic          aw_done_q, w_done_q;
  logic [1:0]    wresp_q;

  wire w_ok = (s_awlen == 8'd0) && (s_awsize == 3'd2);
  assign s_awready = (ws == W_IDLE);
  assign l_awvalid = (ws == W_FWD) && !aw_done_q;
  assign l_awaddr  = waddr_q;
  assign l_wvalid  = (ws == W_FWD) && !w_done_q && s_wvalid;
  assign l_wdata   = s_wdata;
  assign l_wstrb   = s_wstrb;
  assign s_wready  = ((ws == W_FWD) && !w_done_q && l_wready) || (ws == W_DRAIN);
  assign l_bready  = (ws == W_B);
  assign s_bvalid  = (ws == W_RESP);
  assign s_bid     = wid_q;
  assign s_bresp   = wresp_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ws <= W_IDLE; wid_q <= '0; waddr_q <= 12'd0; aw_done_q <= 1'b0; w_done_q <= 1'b0; wresp_q <= 2'b00;
    end else begin
      case (ws)
        W_IDLE: if (s_awvalid) begin
          wid_q <= s_awid; waddr_q <= s_awaddr[11:0]; aw_done_q <= 1'b0; w_done_q <= 1'b0;
          ws <= w_ok ? W_FWD : W_DRAIN;
        end
        W_FWD: begin
          if (l_awvalid && l_awready) aw_done_q <= 1'b1;
          if (l_wvalid && l_wready)   w_done_q  <= 1'b1;
          if ((aw_done_q || (l_awvalid && l_awready)) && (w_done_q || (l_wvalid && l_wready))) ws <= W_B;
        end
        W_B: if (l_bvalid) begin wresp_q <= l_bresp; ws <= W_RESP; end
        W_DRAIN: if (s_wvalid && s_wlast) begin wresp_q <= 2'b10; ws <= W_RESP; end
        default: if (s_bready) ws <= W_IDLE;          // W_RESP
      endcase
    end
  end

  // ---------------------------------------------------------------- read path
  typedef enum logic [2:0] {R_IDLE, R_FWD, R_WAIT, R_RESP, R_ERR} rst_e;
  rst_e          rs;
  logic [IDW-1:0] rid_q;
  logic [11:0]   raddr_q;
  logic [7:0]    rcnt_q;
  logic [31:0]   rdata_q;
  logic [1:0]    rresp_q;

  wire r_ok = (s_arlen == 8'd0) && (s_arsize == 3'd2);
  assign s_arready = (rs == R_IDLE);
  assign l_arvalid = (rs == R_FWD);
  assign l_araddr  = raddr_q;
  assign l_rready  = (rs == R_WAIT);
  assign s_rvalid  = (rs == R_RESP) || (rs == R_ERR);
  assign s_rid     = rid_q;
  assign s_rdata   = (rs == R_RESP) ? rdata_q : 32'd0;
  assign s_rresp   = (rs == R_RESP) ? rresp_q : 2'b10;
  assign s_rlast   = (rs == R_RESP) || (rcnt_q == 8'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rs <= R_IDLE; rid_q <= '0; raddr_q <= 12'd0; rcnt_q <= 8'd0; rdata_q <= 32'd0; rresp_q <= 2'b00;
    end else begin
      case (rs)
        R_IDLE: if (s_arvalid) begin
          rid_q <= s_arid; raddr_q <= s_araddr[11:0]; rcnt_q <= s_arlen;
          rs <= r_ok ? R_FWD : R_ERR;
        end
        R_FWD:  if (l_arready) rs <= R_WAIT;
        R_WAIT: if (l_rvalid) begin rdata_q <= l_rdata; rresp_q <= l_rresp; rs <= R_RESP; end
        R_RESP: if (s_rready) rs <= R_IDLE;
        default: if (s_rready) begin                  // R_ERR
          if (rcnt_q == 8'd0) rs <= R_IDLE;
          else rcnt_q <= rcnt_q - 8'd1;
        end
      endcase
    end
  end

  wire unused_ok = ^{s_awburst, s_arburst, s_awaddr[31:12], s_araddr[31:12], s_wlast};
endmodule

`default_nettype wire
