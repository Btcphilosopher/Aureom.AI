// =============================================================================
// SilicaFlux HostLink :: silicaflux_host_pcie -- host-facing accelerator subsystem
//
// Project 25 primary RTL.  The SilicaFlux side of a PCIe accelerator: BAR
// register bridge, host-memory submission/completion queues, DMA descriptor
// engine, compute dispatch and interrupt generation.
//
//      Host software
//         | (PCIe: TLPs, BARs, MSI/MSI-X -- handled by the ENDPOINT IP only)
//      PCIe endpoint IP (vendor, verified)  ...  sfh_ep_axi_shell (adapters)
//         |  AXI4-Lite BAR0 target        |  AXI4 host-memory master   | irq msg
//      ===|===============================|============================|=====
//      silicaflux_host_pcie  (this module: no PCIe protocol logic at all)
//         sfh_bar_regs  --cfg/doorbells-->  sfh_engine  (SQ/CQ, DMA, GEMM)
//                                              |  SFB2 master   | TE register page
//      ========================================|================|============
//      SilicaFlux DataFabric (sfb_crossbar) -> device SRAM, tile scratchpad;
//      sfv_tile (vector + tensor engines)
//
// This module deliberately contains NO PCIe protocol logic: it speaks AXI4-Lite
// (BAR target), AXI4 (host memory, 64-bit) and a valid/ready interrupt-message
// request.  Link training, TLP formation, configuration space, BAR
// decoding, MSI/MSI-X capability and tables, completion timeouts and
// ordering inside the PCIe fabric belong to the endpoint IP.  Nothing here
// claims PCIe compliance.
//
// Clock/reset: one clock domain (the endpoint's user clock, or a SilicaFlux
// core clock with AXI clock converters at the endpoint boundary -- see
// docs/07_ENDPOINT_INTEGRATION.md).  rst_n: asynchronous assert, synchronous
// release (sfv_rst_sync in the shell).  Reference configuration parameters
// are defined in abi/sfh_abi.py.
// =============================================================================
`default_nettype none

module silicaflux_host_pcie #(
  parameter int          NW           = 4,       // DMA windows
  parameter int          NV           = 2,       // interrupt vectors
  parameter int          SQ_LOG2_MAX  = 12,
  parameter int          CQ_LOG2_MAX  = 12,
  parameter int          MAX_DMA_LOG2 = 20,
  parameter int          MAXB         = 16,      // host burst beats (64-bit)
  parameter logic [31:0] DM0_BASE     = 32'h1000_0000,
  parameter logic [31:0] DM0_SIZE     = 32'h0001_0000,
  parameter logic [31:0] DM1_BASE     = 32'h2000_0000,
  parameter logic [31:0] DM1_SIZE     = 32'h0000_4000
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ------------------------------------------------------------ BAR0 target (AXI4-Lite)
  input  wire logic             s_bar_awvalid,
  output logic                  s_bar_awready,
  input  wire logic [11:0]      s_bar_awaddr,
  input  wire logic             s_bar_wvalid,
  output logic                  s_bar_wready,
  input  wire logic [31:0]      s_bar_wdata,
  input  wire logic [3:0]       s_bar_wstrb,
  output logic                  s_bar_bvalid,
  input  wire logic             s_bar_bready,
  output logic [1:0]            s_bar_bresp,
  input  wire logic             s_bar_arvalid,
  output logic                  s_bar_arready,
  input  wire logic [11:0]      s_bar_araddr,
  output logic                  s_bar_rvalid,
  input  wire logic             s_bar_rready,
  output logic [31:0]           s_bar_rdata,
  output logic [1:0]            s_bar_rresp,
  // ------------------------------------------------------------ host memory (AXI4 master, 64-bit)
  output logic                  m_host_awvalid,
  input  wire logic             m_host_awready,
  output logic [63:0]           m_host_awaddr,
  output logic [7:0]            m_host_awlen,
  output logic [2:0]            m_host_awsize,
  output logic [1:0]            m_host_awburst,
  output logic [3:0]            m_host_awid,
  output logic                  m_host_wvalid,
  input  wire logic             m_host_wready,
  output logic [63:0]           m_host_wdata,
  output logic [7:0]            m_host_wstrb,
  output logic                  m_host_wlast,
  input  wire logic             m_host_bvalid,
  output logic                  m_host_bready,
  input  wire logic [1:0]       m_host_bresp,
  input  wire logic [3:0]       m_host_bid,
  output logic                  m_host_arvalid,
  input  wire logic             m_host_arready,
  output logic [63:0]           m_host_araddr,
  output logic [7:0]            m_host_arlen,
  output logic [2:0]            m_host_arsize,
  output logic [1:0]            m_host_arburst,
  output logic [3:0]            m_host_arid,
  input  wire logic             m_host_rvalid,
  output logic                  m_host_rready,
  input  wire logic [63:0]      m_host_rdata,
  input  wire logic [1:0]       m_host_rresp,
  input  wire logic             m_host_rlast,
  input  wire logic [3:0]       m_host_rid,
  // ------------------------------------------------------------ interrupt message request
  output logic                  irq_valid,
  output logic [3:0]            irq_vector,
  input  wire logic             irq_ready,
  output logic                  irq_level,
  // ------------------------------------------------------------ DataFabric (SFB2 master, 32-bit)
  output logic                  df_req_valid,
  input  wire logic             df_req_ready,
  output logic                  df_req_write,
  output logic [31:0]           df_req_addr,
  output logic [31:0]           df_req_wdata,
  output logic [3:0]            df_req_wstrb,
  input  wire logic             df_rsp_valid,
  output logic                  df_rsp_ready,
  input  wire logic [31:0]      df_rsp_rdata,
  input  wire logic             df_rsp_error,
  // ------------------------------------------------------------ tensor engine register page (sfv_tile rb_*)
  output logic                  te_sel,
  output logic                  te_rb_we,
  output logic [11:0]           te_rb_addr,
  output logic [31:0]           te_rb_wdata,
  input  wire logic [31:0]      te_rdata,
  output logic                  tile_rst_req
);
  localparam int NPC = 10;

  // ---------------------------------------------------------------- parameter legality (elaboration)
  // MAXB: an SQE fetch is one 8-beat burst; chunk/word counters are sized for <= 128 B.
  if (MAXB != 8 && MAXB != 16) begin : g_bad_maxb
    $error("silicaflux_host_pcie: MAXB must be 8 or 16");
  end
  // NW: window registers occupy 0x200..0x2FF (stride 0x20) below the PERF block.
  if (NW < 1 || NW > 8) begin : g_bad_nw
    $error("silicaflux_host_pcie: NW must be 1..8");
  end
  if (NV < 1 || NV > 16) begin : g_bad_nv
    $error("silicaflux_host_pcie: NV must be 1..16 (4-bit vector fields)");
  end
  // queue indices are 12-bit (SQ_HEAD/SQ_TAIL/CQ_* registers and CQE.SQ_HEAD)
  if (SQ_LOG2_MAX < 1 || SQ_LOG2_MAX > 12 || CQ_LOG2_MAX < 1 || CQ_LOG2_MAX > 12) begin : g_bad_q
    $error("silicaflux_host_pcie: SQ_LOG2_MAX/CQ_LOG2_MAX must be 1..12");
  end
  if (MAX_DMA_LOG2 < 3 || MAX_DMA_LOG2 > 30) begin : g_bad_len
    $error("silicaflux_host_pcie: MAX_DMA_LOG2 must be 3..30");
  end

  // ---------------------------------------------------------------- regs <-> engine
  logic             enabled, flush_all, stop_on_err, q_init, reset_req, halted;
  logic [31:0]      timeout;
  logic [63:0]      sq_base, cq_base;
  logic [3:0]       sq_log2, cq_log2;
  logic [NW*64-1:0] win_base, win_size;
  logic [NW*3-1:0]  win_ctrl;
  logic [11:0]      sq_tail, cq_head, sq_head, cq_tail;
  logic             srst, eng_idle, eng_fatal, eng_cq_full, cq_phase, halt_set;
  logic [3:0]       eng_state;
  logic             ev_cq, ev_host_bus, ev_host_tmo, ev_cmd_err, ev_eng_tmo;
  logic [63:0]      err_addr;
  logic [15:0]      err_cmd_status, err_cmd_sqidx;
  logic [NPC*16-1:0] perf_inc;

  sfh_bar_regs #(
    .NW(NW), .NV(NV), .SQ_LOG2_MAX(SQ_LOG2_MAX), .CQ_LOG2_MAX(CQ_LOG2_MAX),
    .MAX_DMA_LOG2(MAX_DMA_LOG2), .MAXB(MAXB),
    .DM0_BASE(DM0_BASE), .DM0_SIZE(DM0_SIZE), .DM1_BASE(DM1_BASE), .DM1_SIZE(DM1_SIZE),
    .CAPS(sfh_abi_pkg::RST_CAPS)
  ) u_regs (
    .clk, .rst_n,
    .s_awvalid(s_bar_awvalid), .s_awready(s_bar_awready), .s_awaddr(s_bar_awaddr),
    .s_wvalid(s_bar_wvalid), .s_wready(s_bar_wready), .s_wdata(s_bar_wdata), .s_wstrb(s_bar_wstrb),
    .s_bvalid(s_bar_bvalid), .s_bready(s_bar_bready), .s_bresp(s_bar_bresp),
    .s_arvalid(s_bar_arvalid), .s_arready(s_bar_arready), .s_araddr(s_bar_araddr),
    .s_rvalid(s_bar_rvalid), .s_rready(s_bar_rready), .s_rdata(s_bar_rdata), .s_rresp(s_bar_rresp),
    .o_enabled(enabled), .o_flush_all(flush_all), .o_stop_on_err(stop_on_err), .o_timeout(timeout),
    .o_sq_base(sq_base), .o_sq_log2(sq_log2), .o_cq_base(cq_base), .o_cq_log2(cq_log2),
    .o_win_base(win_base), .o_win_size(win_size), .o_win_ctrl(win_ctrl),
    .o_sq_tail(sq_tail), .o_cq_head(cq_head), .o_q_init(q_init), .o_reset_req(reset_req),
    .o_halted(halted),
    .i_srst(srst), .i_eng_idle(eng_idle), .i_eng_fatal(eng_fatal), .i_eng_cq_full(eng_cq_full),
    .i_eng_state(eng_state), .i_sq_head(sq_head), .i_cq_tail(cq_tail), .i_cq_phase(cq_phase),
    .i_halt_set(halt_set), .i_ev_cq(ev_cq), .i_ev_host_bus(ev_host_bus), .i_ev_host_tmo(ev_host_tmo),
    .i_ev_cmd_err(ev_cmd_err), .i_ev_eng_tmo(ev_eng_tmo), .i_err_addr(err_addr),
    .i_err_cmd_status(err_cmd_status), .i_err_cmd_sqidx(err_cmd_sqidx), .i_perf_inc(perf_inc),
    .irq_valid, .irq_vector, .irq_ready, .irq_level
  );

  sfh_engine #(
    .NW(NW), .MAXB(MAXB), .MAX_DMA_LOG2(MAX_DMA_LOG2),
    .DM0_BASE(DM0_BASE), .DM0_SIZE(DM0_SIZE), .DM1_BASE(DM1_BASE), .DM1_SIZE(DM1_SIZE)
  ) u_eng (
    .clk, .rst_n,
    .enabled, .flush_all, .stop_on_err, .timeout, .sq_base, .sq_log2, .cq_base, .cq_log2,
    .win_base, .win_size, .win_ctrl, .sq_tail, .cq_head, .q_init, .reset_req, .halted,
    .srst, .idle(eng_idle), .fatal(eng_fatal), .cq_full(eng_cq_full), .state(eng_state),
    .sq_head, .cq_tail, .cq_phase, .halt_set,
    .ev_cq, .ev_host_bus, .ev_host_tmo, .ev_cmd_err, .ev_eng_tmo,
    .err_addr, .err_cmd_status, .err_cmd_sqidx, .perf_inc,
    .m_awvalid(m_host_awvalid), .m_awready(m_host_awready), .m_awaddr(m_host_awaddr),
    .m_awlen(m_host_awlen), .m_awsize(m_host_awsize), .m_awburst(m_host_awburst), .m_awid(m_host_awid),
    .m_wvalid(m_host_wvalid), .m_wready(m_host_wready), .m_wdata(m_host_wdata),
    .m_wstrb(m_host_wstrb), .m_wlast(m_host_wlast),
    .m_bvalid(m_host_bvalid), .m_bready(m_host_bready), .m_bresp(m_host_bresp), .m_bid(m_host_bid),
    .m_arvalid(m_host_arvalid), .m_arready(m_host_arready), .m_araddr(m_host_araddr),
    .m_arlen(m_host_arlen), .m_arsize(m_host_arsize), .m_arburst(m_host_arburst), .m_arid(m_host_arid),
    .m_rvalid(m_host_rvalid), .m_rready(m_host_rready), .m_rdata(m_host_rdata),
    .m_rresp(m_host_rresp), .m_rlast(m_host_rlast), .m_rid(m_host_rid),
    .f_req_valid(df_req_valid), .f_req_ready(df_req_ready), .f_req_write(df_req_write),
    .f_req_addr(df_req_addr), .f_req_wdata(df_req_wdata), .f_req_wstrb(df_req_wstrb),
    .f_rsp_valid(df_rsp_valid), .f_rsp_ready(df_rsp_ready), .f_rsp_rdata(df_rsp_rdata),
    .f_rsp_error(df_rsp_error),
    .te_sel, .te_rb_we, .te_rb_addr, .te_rb_wdata, .te_rdata, .tile_rst_req
  );
endmodule

`default_nettype wire
