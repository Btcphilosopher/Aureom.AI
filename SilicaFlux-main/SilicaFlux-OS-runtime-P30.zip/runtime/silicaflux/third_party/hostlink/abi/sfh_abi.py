"""SilicaFlux HostLink -- driver-facing ABI, single source of truth.

Everything a host driver and the RTL must agree on is defined here once:
BAR0 register map (offsets, access types, reset values, writable masks,
fields, side effects), submission/completion entry layouts, opcodes, flags,
status codes and limits of the reference configuration.

`abi/gen_abi.py` turns this file into
  generated/sfh_abi_pkg.sv            SystemVerilog package used by the RTL
  generated/silicaflux_hostlink_abi.h C header used by the driver/tests
  generated/sfh_regtable.h            C register table (conformance test)
  docs/03_REGISTER_MAP.md             human-readable register map
Edit this file, never the generated outputs (`make abi` regenerates them and
`make abi-check` fails if they are stale).

ABI version 1.0.  Little-endian everywhere.  All BAR0 accesses are aligned
32-bit reads/writes; any other access is rejected (see docs/02_DRIVER_ABI.md).
"""

ABI_MAJOR = 1
ABI_MINOR = 0
DEVICE_MAGIC = 0x5346484C          # 'SFHL'
HW_REV = 0x00010000                # [31:16] RTL revision 1, [15:8] variant 0 (generic)
BAR0_BYTES = 4096

# ----------------------------------------------------------------------------
# Reference configuration (parameters of silicaflux_host_pcie / sfh_device_top).
# The driver must read LIMITS / DEVMEM* at run time instead of assuming these.
# ----------------------------------------------------------------------------
CFG = dict(
    SQ_LOG2_MAX=12,        # up to 4096 submission entries
    CQ_LOG2_MAX=12,        # up to 4096 completion entries
    NUM_WINDOWS=4,         # host DMA address windows
    NUM_VECTORS=2,         # interrupt message vectors
    MAX_DMA_LOG2=20,       # max bytes per DMA command = 1 MiB
    MAX_BURST_BEATS=16,    # host AXI burst length (64-bit beats) = 128 B
    DEVMEM0_BASE=0x10000000, DEVMEM0_SIZE=0x00010000,   # device SRAM 64 KiB
    DEVMEM1_BASE=0x20000000, DEVMEM1_SIZE=0x00004000,   # tile scratchpad (TSPM) 16 KiB
    TIMEOUT_RESET=0x00100000,
)

SQE_BYTES = 64
CQE_BYTES = 16
HOST_BEAT_BYTES = 8                 # host AXI data width 64 bit
DMA_ALIGN = 8                       # src/dst/length granularity (bytes)
RING_ALIGN = 64                     # SQ/CQ base alignment (bytes)
WINDOW_ALIGN = 4096                 # DMA window base/size granularity

# ----------------------------------------------------------------------------
# Opcodes, flags, directions, status codes
# ----------------------------------------------------------------------------
OPCODES = [
    ("NOP",         0x00, "No operation; completes with SUCCESS. Used for queue tests and as a fence marker."),
    ("DMA",         0x01, "Copy `length` bytes between host memory and device memory; direction in `dir`."),
    ("TENSOR_GEMM", 0x02, "4x4 INT8 GEMM on the SilicaFlux-V tensor engine, operands/result in the tile scratchpad."),
    # 0x03 VECTOR is reserved for the vector engine (not implemented in ABI 1.0).
]

SQE_FLAGS = [
    ("IRQ",   0, "Raise INT_STATUS.CQ (and an interrupt message if enabled) when this entry completes."),
    ("FLUSH", 1, "Before posting this completion, issue a host read to flush earlier posted writes (relaxed-ordering hosts)."),
]

DMA_DIRS = [
    ("H2D", 1, "host memory (src, IOVA) -> device memory (dst, device address)"),
    ("D2H", 2, "device memory (src, device address) -> host memory (dst, IOVA)"),
]

GEMM_FLAGS = [
    ("ACC",        0, "Accumulate onto the engine accumulators instead of starting from zero."),
    ("A_UNSIGNED", 1, "A elements are uint8 (default int8)."),
    ("B_UNSIGNED", 2, "B elements are uint8 (default int8)."),
]

STATUS = [
    ("SUCCESS",          0x00, "Command completed."),
    ("INVALID_OPCODE",   0x01, "Opcode not implemented."),
    ("INVALID_FIELD",    0x02, "Reserved field/bit non-zero, unknown flag, bad direction or device address above 4 GiB."),
    ("INVALID_LENGTH",   0x03, "DMA length 0 or above 2^MAX_DMA_LOG2."),
    ("MISALIGNED",       0x04, "DMA src, dst or length not a multiple of 8 bytes."),
    ("HOST_ADDR_DENIED", 0x05, "Host range not inside an enabled window with the needed permission, or 64-bit overflow."),
    ("DEV_ADDR_INVALID", 0x06, "Device range not inside one device memory region, or 32-bit overflow."),
    ("HOST_BUS_ERROR",   0x07, "Host bus returned SLVERR/DECERR on a data transfer (e.g. IOMMU fault, UR/CA)."),
    ("DEV_BUS_ERROR",    0x08, "DataFabric returned rsp_error on a device access."),
    ("ENGINE_ERROR",     0x09, "Compute engine rejected the parameters; CQE.result = engine error code."),
    ("ENGINE_TIMEOUT",   0x0A, "Compute engine exceeded TIMEOUT cycles; engine was reset."),
]

# ----------------------------------------------------------------------------
# Submission entry (64 B) and completion entry (16 B): (name, dword, lsb, width, doc)
# ----------------------------------------------------------------------------
SQE_COMMON = [
    ("OPCODE", 0, 0, 8,  "opcode"),
    ("FLAGS",  0, 8, 8,  "completion flags (SQE_FLAG_*)"),
    ("DIR",    0, 16, 8, "DMA direction (DMA_DIR_*); 0 for other opcodes"),
    ("RSVD0",  0, 24, 8, "reserved, 0"),
    ("TXN_ID", 1, 0, 32, "transaction ID, echoed in the completion"),
]
SQE_DMA = [
    ("SRC_LO", 2, 0, 32, "source address [31:0]"),
    ("SRC_HI", 3, 0, 32, "source address [63:32] (0 for a device source)"),
    ("DST_LO", 4, 0, 32, "destination address [31:0]"),
    ("DST_HI", 5, 0, 32, "destination address [63:32] (0 for a device destination)"),
    ("LENGTH", 6, 0, 32, "bytes, multiple of 8, 1 .. 2^MAX_DMA_LOG2"),
]   # dwords 7..15 reserved (0)
SQE_GEMM = [
    ("A_OFF",    2, 0, 32, "A byte offset in the TSPM (column-major 4xK, word k = A[0..3][k])"),
    ("B_OFF",    3, 0, 32, "B byte offset in the TSPM (row-major Kx4, word k = B[k][0..3])"),
    ("C_OFF",    4, 0, 32, "C byte offset in the TSPM (4 rows of 4 int32, 16-byte aligned)"),
    ("K",        5, 0, 32, "inner dimension 1..1024"),
    ("A_STRIDE", 6, 0, 32, "bytes between A words (0 = 4)"),
    ("B_STRIDE", 7, 0, 32, "bytes between B words (0 = 4)"),
    ("C_STRIDE", 8, 0, 32, "bytes between C rows (0 = 16)"),
    ("TE_FLAGS", 9, 0, 32, "GEMM_FLAG_*"),
]   # dwords 10..15 reserved (0)
SQE_DMA_RSVD_DW = list(range(7, 16))
SQE_GEMM_RSVD_DW = list(range(10, 16))
SQE_NOP_RSVD_DW = list(range(2, 16))

CQE = [
    ("TXN_ID",  0, 0, 32, "transaction ID from the submission entry"),
    ("RESULT",  1, 0, 32, "DMA: bytes completed (contiguous prefix); GEMM: engine cycles or engine error code"),
    ("SQ_HEAD", 2, 0, 16, "device SQ head after consuming this entry"),
    ("OPCODE",  2, 16, 8, "opcode of the completed entry"),
    ("RSVD2",   2, 24, 8, "reserved"),
    ("STATUS",  3, 0, 16, "STATUS_*"),
    ("PHASE",   3, 16, 1, "phase tag: toggles every time the CQ wraps; starts at 1"),
]

# ----------------------------------------------------------------------------
# BAR0 registers
#   access: RO   read-only (writes rejected, ERR_STATUS.REG_ACCESS)
#           RW   read/write (bits outside `wmask` read as 0 / ignored)
#           RWL  read/write only while the queues are disabled and the engine
#                is idle (STATUS.ENABLED=0, IDLE=1, RESETTING=0); else rejected
#           W1C  write 1 to clear
#           W1S  write 1 to trigger/set; reads return 0 (except INT_TEST: 0)
#           DB   doorbell: validated write (rejected writes set ERR_STATUS.DOORBELL)
# ----------------------------------------------------------------------------
class Reg:
    def __init__(self, name, off, acc, reset, wmask, doc, fields=(), side=""):
        self.name, self.off, self.acc, self.reset, self.wmask = name, off, acc, reset, wmask
        self.doc, self.fields, self.side = doc, list(fields), side


def F(name, lsb, width, doc):
    return (name, lsb, width, doc)


C = CFG
CAPS_FIELDS = [F("NOP", 0, 1, "NOP opcode"), F("DMA_H2D", 1, 1, "host-to-device DMA"),
               F("DMA_D2H", 2, 1, "device-to-host DMA"), F("TENSOR_GEMM", 3, 1, "TENSOR_GEMM opcode"),
               F("IRQ_MSG", 4, 1, "message-signalled interrupts through the endpoint (MSI/MSI-X)"),
               F("IRQ_LEVEL", 5, 1, "level interrupt output (INTx emulation)"),
               F("FLUSH_READ", 6, 1, "flush-read before completion (SQE FLUSH, CTRL.FLUSH_ALL)"),
               F("STOP_ON_ERROR", 7, 1, "CTRL.STOP_ON_ERROR"),
               F("SCATTER_GATHER", 8, 1, "scatter-gather DMA (0: not implemented)"),
               F("VECTOR", 9, 1, "vector-engine opcode (0: not implemented)")]
CAPS_RESET = 0xFF

LIMITS_RESET = (C["SQ_LOG2_MAX"] | (C["CQ_LOG2_MAX"] << 4) | (C["NUM_WINDOWS"] << 8) |
                (C["NUM_VECTORS"] << 12) | (C["MAX_DMA_LOG2"] << 16) | (C["MAX_BURST_BEATS"] << 24))

REGS = [
    Reg("ID", 0x000, "RO", DEVICE_MAGIC, 0, "Device identification, ASCII 'SFHL'."),
    Reg("VERSION", 0x004, "RO", (ABI_MAJOR << 16) | ABI_MINOR, 0, "ABI version implemented by the hardware.",
        [F("MINOR", 0, 16, "ABI minor (additive changes)"), F("MAJOR", 16, 16, "ABI major (incompatible changes)")]),
    Reg("HW_REV", 0x008, "RO", HW_REV, 0, "Hardware revision.",
        [F("VARIANT", 8, 8, "0 = generic RTL"), F("REV", 16, 16, "RTL revision")]),
    Reg("CAPS", 0x00C, "RO", CAPS_RESET, 0, "Capability bits.", CAPS_FIELDS),
    Reg("LIMITS", 0x010, "RO", LIMITS_RESET, 0, "Implementation limits.",
        [F("SQ_LOG2_MAX", 0, 4, "max log2(SQ entries)"), F("CQ_LOG2_MAX", 4, 4, "max log2(CQ entries)"),
         F("NUM_WINDOWS", 8, 4, "number of DMA windows"), F("NUM_VECTORS", 12, 4, "interrupt vectors"),
         F("MAX_DMA_LOG2", 16, 8, "log2(max DMA length in bytes)"),
         F("MAX_BURST_BEATS", 24, 8, "host burst length in 8-byte beats")]),
    Reg("DEVMEM0_BASE", 0x014, "RO", C["DEVMEM0_BASE"], 0, "Device memory region 0 (device SRAM) base, device address."),
    Reg("DEVMEM0_SIZE", 0x018, "RO", C["DEVMEM0_SIZE"], 0, "Device memory region 0 size in bytes."),
    Reg("DEVMEM1_BASE", 0x01C, "RO", C["DEVMEM1_BASE"], 0, "Device memory region 1 (tile scratchpad, TSPM) base."),
    Reg("DEVMEM1_SIZE", 0x020, "RO", C["DEVMEM1_SIZE"], 0, "Device memory region 1 size in bytes."),

    Reg("CTRL", 0x040, "RW", 0, 0xF, "Device control.",
        [F("ENABLE", 0, 1, "1 = process the submission queue"),
         F("RESET", 1, 1, "W1S: soft reset of the whole HostLink function (reads 0)"),
         F("FLUSH_ALL", 2, 1, "flush-read before every completion"),
         F("STOP_ON_ERROR", 3, 1, "halt queue processing after a failed command")],
        side="ENABLE 0->1: validates SQ/CQ configuration against the windows; on success resets SQ_HEAD, "
             "SQ_TAIL, CQ_TAIL, CQ_HEAD to 0 and CQ_PHASE to 1 and starts processing; on failure ENABLE stays 0 "
             "and ERR_STATUS.RING_CONFIG is set.  ENABLE 1->0: the command in flight completes (its CQE is "
             "posted), then the engine idles (poll STATUS.IDLE).  Any write with ENABLE=1 clears STATUS.HALTED.  "
             "RESET=1: the engine finishes the bus transaction in flight (never the command), then every "
             "register except PERF counters returns to its reset value and the compute tile is reset; "
             "STATUS.RESETTING=1 meanwhile."),
    Reg("STATUS", 0x044, "RO", 0x2, 0, "Device status.",
        [F("ENABLED", 0, 1, "queues enabled"), F("IDLE", 1, 1, "no command or bus transaction in flight"),
         F("RESETTING", 2, 1, "soft reset in progress"),
         F("FATAL", 3, 1, "fatal error (host-bus error/timeout on queue memory); needs CTRL.RESET"),
         F("HALTED", 4, 1, "stopped after an error (STOP_ON_ERROR)"),
         F("CQ_FULL", 5, 1, "engine waiting for CQ space (host back-pressure)"),
         F("STATE", 8, 4, "engine state (debug)")]),
    Reg("SCRATCH", 0x048, "RW", 0, 0xFFFFFFFF, "Scratch register for BAR access tests; no side effect."),
    Reg("TIMEOUT", 0x04C, "RW", C["TIMEOUT_RESET"], 0xFFFFFFFF,
        "Watchdog in core clock cycles for every host-bus transaction and every engine command; 0 disables."),

    Reg("SQ_BASE_LO", 0x080, "RWL", 0, 0xFFFFFFC0, "SQ base IOVA [31:0] (64-byte aligned; bits [5:0] read 0)."),
    Reg("SQ_BASE_HI", 0x084, "RWL", 0, 0xFFFFFFFF, "SQ base IOVA [63:32]."),
    Reg("SQ_SIZE", 0x088, "RWL", 0, 0xF, "SQ size.", [F("LOG2", 0, 4, "log2(entries), 1..SQ_LOG2_MAX")]),
    Reg("SQ_HEAD", 0x08C, "RO", 0, 0, "Device SQ head: index of the next entry the device will fetch."),
    Reg("SQ_TAIL", 0x090, "DB", 0, 0xFFF, "SQ tail doorbell: index one past the last valid entry.",
        side="Accepted only while ENABLED, if TAIL < entries and the number of pending entries does not "
             "decrease ((new-HEAD) mod N >= (old-HEAD) mod N); otherwise ignored and ERR_STATUS.DOORBELL is set."),
    Reg("CQ_BASE_LO", 0x0A0, "RWL", 0, 0xFFFFFFC0, "CQ base IOVA [31:0] (64-byte aligned; bits [5:0] read 0)."),
    Reg("CQ_BASE_HI", 0x0A4, "RWL", 0, 0xFFFFFFFF, "CQ base IOVA [63:32]."),
    Reg("CQ_SIZE", 0x0A8, "RWL", 0, 0xF, "CQ size.", [F("LOG2", 0, 4, "log2(entries), 1..CQ_LOG2_MAX")]),
    Reg("CQ_TAIL", 0x0AC, "RO", 0, 0, "Device CQ tail: index the next completion will be written to."),
    Reg("CQ_HEAD", 0x0B0, "DB", 0, 0xFFF, "CQ head doorbell: index of the next entry the host will consume.",
        side="Accepted only while ENABLED, if HEAD < entries and it does not pass the device tail "
             "((new-old) mod N <= (CQ_TAIL-old) mod N); otherwise ignored and ERR_STATUS.DOORBELL is set."),
    Reg("CQ_PHASE", 0x0B4, "RO", 1, 0, "Phase tag the device writes into the next completion.",
        [F("PHASE", 0, 1, "current phase")]),

    Reg("INT_STATUS", 0x0C0, "W1C", 0, 0x3, "Interrupt status (write 1 to clear).",
        [F("CQ", 0, 1, "a completion with SQE IRQ flag or non-SUCCESS status was posted"),
         F("ERROR", 1, 1, "a device-level error bit was set in ERR_STATUS")]),
    Reg("INT_ENABLE", 0x0C4, "RW", 0, 0x3, "Interrupt enable (mask) per source.",
        [F("CQ", 0, 1, "enable CQ interrupts"), F("ERROR", 1, 1, "enable ERROR interrupts")],
        side="Enabling a source whose INT_STATUS bit is already set sends a message immediately."),
    Reg("INT_VECTOR", 0x0C8, "RW", 0x100, 0xF0F, "Message vector per source.",
        [F("CQ_VEC", 0, 4, "vector for CQ"), F("ERR_VEC", 8, 4, "vector for ERROR")],
        side="A vector >= NUM_VECTORS is rejected (ERR_STATUS.REG_ACCESS)."),
    Reg("INT_TEST", 0x0CC, "W1S", 0, 0x3, "Software-triggered interrupt events (driver self-test).",
        [F("CQ", 0, 1, "set INT_STATUS.CQ as an event"), F("ERROR", 1, 1, "set INT_STATUS.ERROR as an event")]),

    Reg("ERR_STATUS", 0x100, "W1C", 0, 0x7F, "Sticky device error bits (write 1 to clear).",
        [F("REG_ACCESS", 0, 1, "rejected BAR access (RO/locked/unmapped/sub-word/bad value)"),
         F("DOORBELL", 1, 1, "rejected doorbell value"),
         F("RING_CONFIG", 2, 1, "ENABLE refused: invalid SQ/CQ size, alignment or window"),
         F("HOST_BUS", 3, 1, "host-bus error on SQ fetch, CQ write or flush read (fatal)"),
         F("HOST_TIMEOUT", 4, 1, "host-bus transaction exceeded TIMEOUT (fatal)"),
         F("CMD_ERROR", 5, 1, "a command completed with non-SUCCESS status"),
         F("ENGINE_TIMEOUT", 6, 1, "compute engine exceeded TIMEOUT")]),
    Reg("ERR_REG_OFFSET", 0x104, "RO", 0, 0, "BAR0 offset of the last rejected register/doorbell access."),
    Reg("ERR_ADDR_LO", 0x108, "RO", 0, 0, "Address of the last failing host/device access [31:0]."),
    Reg("ERR_ADDR_HI", 0x10C, "RO", 0, 0, "Address of the last failing host/device access [63:32]."),
    Reg("ERR_CMD", 0x110, "RO", 0, 0, "Last failed command.",
        [F("STATUS", 0, 16, "completion status"), F("SQ_INDEX", 16, 16, "SQ index of the command")]),

    Reg("PERF_CTRL", 0x300, "W1S", 0, 0x3, "Performance counter control.",
        [F("SNAPSHOT", 0, 1, "copy all live counters to the PERF_* registers atomically"),
         F("CLEAR", 1, 1, "zero all live counters and snapshots")]),
]

WIN_BASE, WIN_STRIDE = 0x200, 0x20
for i in range(C["NUM_WINDOWS"]):
    b = WIN_BASE + i * WIN_STRIDE
    REGS += [
        Reg(f"WIN{i}_BASE_LO", b + 0x00, "RWL", 0, 0xFFFFF000, f"DMA window {i} base IOVA [31:0] (4 KiB granular)."),
        Reg(f"WIN{i}_BASE_HI", b + 0x04, "RWL", 0, 0xFFFFFFFF, f"DMA window {i} base IOVA [63:32]."),
        Reg(f"WIN{i}_SIZE_LO", b + 0x08, "RWL", 0, 0xFFFFF000, f"DMA window {i} size [31:0] (4 KiB granular)."),
        Reg(f"WIN{i}_SIZE_HI", b + 0x0C, "RWL", 0, 0xFFFFFFFF, f"DMA window {i} size [63:32]."),
        Reg(f"WIN{i}_CTRL", b + 0x10, "RWL", 0, 0x7, f"DMA window {i} control.",
            [F("VALID", 0, 1, "window enabled"), F("DEV_READ", 1, 1, "device may read (H2D source, SQ fetch, flush)"),
             F("DEV_WRITE", 2, 1, "device may write (D2H destination, CQ post)")]),
    ]

PERF_COUNTERS = [
    ("CMDS_COMPLETED", "completions posted (any status)"),
    ("CMDS_FAILED", "completions posted with non-SUCCESS status"),
    ("BYTES_H2D", "bytes written to device memory by H2D DMA"),
    ("BYTES_D2H", "bytes written to host memory by D2H DMA"),
    ("BUSY_CYCLES", "cycles with a command in flight"),
    ("HOST_WAIT_CYCLES", "cycles with a host-bus transaction outstanding"),
    ("CQ_FULL_CYCLES", "cycles stalled on a full CQ"),
    ("IRQ_MSGS", "interrupt messages accepted by the endpoint"),
    ("ENGINE_CYCLES", "cycles the compute engine was running a HostLink command"),
    ("DOORBELLS", "accepted doorbell writes"),
]
PERF_BASE = 0x310
for i, (n, d) in enumerate(PERF_COUNTERS):
    REGS += [Reg(f"PERF_{n}_LO", PERF_BASE + 8 * i, "RO", 0, 0, f"Snapshot of {d} [31:0]."),
             Reg(f"PERF_{n}_HI", PERF_BASE + 8 * i + 4, "RO", 0, 0, f"Snapshot of {d} [63:32].")]

REGS.sort(key=lambda r: r.off)


def check():
    offs = [r.off for r in REGS]
    assert len(offs) == len(set(offs)), "duplicate register offset"
    for r in REGS:
        assert r.off % 4 == 0 and r.off < BAR0_BYTES, r.name
        assert r.acc in ("RO", "RW", "RWL", "W1C", "W1S", "DB"), r.name
        if r.acc == "RO":
            assert r.wmask == 0, r.name
        for (fn, lsb, w, _) in r.fields:
            assert 0 <= lsb and lsb + w <= 32, (r.name, fn)
    for tbl in (SQE_COMMON + SQE_DMA, SQE_COMMON + SQE_GEMM, CQE):
        seen = set()
        for (_, dw, lsb, w, _) in tbl:
            for b in range(dw * 32 + lsb, dw * 32 + lsb + w):
                assert b not in seen
                seen.add(b)
    assert max(dw for (_, dw, _, _, _) in SQE_COMMON + SQE_DMA + SQE_GEMM) < SQE_BYTES // 4
    assert max(dw for (_, dw, _, _, _) in CQE) < CQE_BYTES // 4


check()
