/* =============================================================================
 * SilicaFlux ControlCore firmware -- platform layer
 *   trap handler (exceptions, MEI dispatch by INTC claim, MTI tick, MSI),
 *   interrupt priorities / masking, timer tick, watchdog supervision,
 *   system DMA driver, RAS reporting.
 *
 * Interrupt model (docs/INTERRUPTS.md): level-sensitive sources; the handler of
 * source s clears the cause AT THE SOURCE (that is the acknowledgement), then
 * the dispatcher claims again until INTC.CLAIM = 0, so simultaneous requests
 * are served in priority order inside one trap.  No nesting (MIE = 0 in traps).
 * ===========================================================================*/
#include "fw.h"

expect_t g_expect;
volatile uint32_t g_irq_log[32], g_irq_log_n, g_irq_count[16];
volatile uint32_t g_ticks, g_msi_count;
volatile uint32_t g_wdt_ewi, g_wdt_hang;
volatile uint32_t g_dma_done, g_dma_status;
volatile uint32_t g_ras_warn_bits, g_ras_fatal_bits, g_ras_warn_irqs, g_ras_fatal_irqs;
volatile uint32_t g_cmd[8], g_cmd_pending, g_cmd_seq;

static void (*isr_table[16])(void);
#define RAS_WARN_ALL  0x7Fu
#define RAS_FATAL_ALL 0x0Fu

uint32_t cycles(void) { return csr_read(mcycle); }

uint64_t mtime(void) {
  uint32_t hi, lo;
  do {
    hi = MTIMER(CC_MTIMER_MTIME_HI);
    lo = MTIMER(CC_MTIMER_MTIME_LO);
  } while (hi != MTIMER(CC_MTIMER_MTIME_HI));
  return ((uint64_t)hi << 32) | lo;
}

static void timer_arm(uint32_t delta) {
  uint64_t t = mtime() + delta;
  MTIMER(CC_MTIMER_MTIMECMP_HI) = 0xFFFFFFFFu;          /* no spurious match while updating */
  MTIMER(CC_MTIMER_MTIMECMP_LO) = (uint32_t)t;
  MTIMER(CC_MTIMER_MTIMECMP_HI) = (uint32_t)(t >> 32);
}

void wdt_service(void) {
  WDT(CC_WDT_SERVICE) = CC_WDT_KEY1;
  WDT(CC_WDT_SERVICE) = CC_WDT_KEY2;
}

/* ---------------------------------------------------------------- expected-trap probes */
void expect_arm(uint32_t mode) {
  g_expect.cause = 0;
  g_expect.mode = mode;
  g_expect.armed = 1;
  __asm__ volatile("" ::: "memory");
}
uint32_t expect_result(void) {
  __asm__ volatile("" ::: "memory");
  g_expect.armed = 0;
  return g_expect.cause;
}
uint32_t probe_rd(uint32_t addr, uint32_t *val) {
  uint32_t v = 0xDEADBEEFu;
  expect_arm(EXP_SKIP);
  __asm__ volatile("lw %0, 0(%1)" : "+r"(v) : "r"(addr) : "memory");
  uint32_t c = expect_result();
  if (val) *val = v;
  return c;
}
uint32_t probe_wr(uint32_t addr, uint32_t val) {
  expect_arm(EXP_SKIP);
  __asm__ volatile("sw %0, 0(%1)" ::"r"(val), "r"(addr) : "memory");
  return expect_result();
}
uint32_t probe_wr8(uint32_t addr, uint8_t val) {
  expect_arm(EXP_SKIP);
  __asm__ volatile("sb %0, 0(%1)" ::"r"(val), "r"(addr) : "memory");
  return expect_result();
}

/* ---------------------------------------------------------------- interrupt service routines */
static void isr_fatal(void) {
  uint32_t st = (RAS(CC_RAS_STATUS) >> 8) & 0xFFu;
  g_ras_fatal_bits |= st;
  g_ras_fatal_irqs++;
  /* level sources stay set while the condition persists: mask them until the
   * owner (accelerator reset, SoC) clears the condition */
  uint32_t lvl = st & ((1u << (CC_RAS_SRC_TSU_HALTED - 8)) | (1u << (CC_RAS_SRC_EXT_FATAL - 8)));
  if (st & (1u << (CC_RAS_SRC_TSU_HALTED - 8))) g_acc.tsu_halted = 1;
  /* policy: an uncorrectable parity error in IMEM means the running image is
   * damaged -> soft reset; the warm boot re-checks the CRC and, if it fails,
   * falls back to a cold boot that waits for the host (docs/04_INTERRUPTS.md).
   * Data-memory parity errors are reported and left to the faulting code. */
  if ((st & (1u << (CC_RAS_SRC_MEM_PARITY - 8))) && (RAS(CC_RAS_LAST_SRC) & 0x1Fu) == CC_RAS_SRC_MEM_PARITY) {
    uint32_t a = RAS(CC_RAS_LAST_ADDR);
    if (a >= CC_IMEM_BASE && a < CC_IMEM_BASE + CC_IMEM_SIZE) {
      SYSCTRL(CC_SYSCTRL_SCRATCH1) = a;                 /* evidence for the next boot */
      cprintf("[FATAL] IMEM parity error at %08x -> soft reset\n", a);
      SYSCTRL(CC_SYSCTRL_SOFT_RESET) = CC_SOFT_RESET_KEY;
    }
  }
  if (lvl) RAS(CC_RAS_FATAL_EN) = RAS(CC_RAS_FATAL_EN) & ~lvl;
  RAS(CC_RAS_STATUS) = st << 8;
  (void)RAS(CC_RAS_STATUS);
}

static void isr_ras_warn(void) {
  uint32_t st = RAS(CC_RAS_STATUS) & 0xFFu;
  g_ras_warn_bits |= st;
  g_ras_warn_irqs++;
  uint32_t lvl = st & (1u << CC_RAS_SRC_EXT_WARN);
  if (lvl) RAS(CC_RAS_WARN_EN) = RAS(CC_RAS_WARN_EN) & ~lvl;
  RAS(CC_RAS_STATUS) = st;
  (void)RAS(CC_RAS_STATUS);
}

static void isr_wdt(void) {
  g_wdt_ewi++;
  if (g_wdt_hang) {
    /* watchdog-reset test: stop the early warning and let the counter expire */
    WDT(CC_WDT_CTRL) = CC_WDT_CTRL_EN;
    WDT(CC_WDT_STATUS) = CC_WDT_STATUS_EWI;
    SYSCTRL(CC_SYSCTRL_SCRATCH2) = g_wdt_ewi;           /* POR-domain evidence that survives the reset */
    cprintf("[wdt] early warning, not serviced -> expecting reset\n");
    return;
  }
  WDT(CC_WDT_EWI_THRESH) = WDT_EWI_RUN;
  wdt_service();
  WDT(CC_WDT_STATUS) = CC_WDT_STATUS_EWI;
}

static void isr_dma(void) {
  g_dma_status = DMA(CC_DMA_STATUS);
  DMA(CC_DMA_INT_STATUS) = CC_DMA_INT_DONE | CC_DMA_INT_ERROR;
  (void)DMA(CC_DMA_INT_STATUS);                         /* read back: the level has dropped before the next claim */
  g_dma_done++;
}

static void isr_host(void) {
  for (int i = 0; i < 8; i++) g_cmd[i] = MBOX_H2F(i);
  MBOX(CC_MBOX_H2F_ACK) = 0u;
  (void)MBOX(CC_MBOX_DB_STATUS);
  g_cmd_pending++;
}

extern void isr_vector(void);   /* accel.c */
extern void isr_tensor(void);

static void dispatch_ext(void) {
  uint32_t id, guard = 0;
  while ((id = INTC(CC_INTC_CLAIM)) != 0u) {
    uint32_t s = id - 1u;
    if (g_irq_log_n < 32u) g_irq_log[g_irq_log_n] = s;
    g_irq_log_n++;
    g_irq_count[s]++;
    if (isr_table[s]) isr_table[s]();
    if (++guard > 64u || !isr_table[s]) {
      /* a source that cannot be cleared is masked rather than allowed to storm */
      INTC(CC_INTC_ENABLE) = INTC(CC_INTC_ENABLE) & ~(1u << s);
      ras_report(0, 0xE0000000u | s);
      guard = 0;
    }
  }
}

/* ---------------------------------------------------------------- trap handler */
static void fatal_trap(uint32_t cause, uint32_t epc, uint32_t tval) {
  cprintf("\n[FATAL] unexpected trap mcause=%08x mepc=%08x mtval=%08x\n", cause, epc, tval);
  RAS(CC_RAS_SW_REPORT) = 0x80000000u | 0x7E000000u | (cause & 0xFFu);
  boot_stage(CC_BOOT_STAGE_FATAL);
  SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0xC0000000u | 0xDEADu;
  for (;;) wfi();
}

void trap_handler(trap_frame_t *f) {
  uint32_t cause = csr_read(mcause);
  if (cause & MCAUSE_INT) {
    switch (cause & 0x1Fu) {
      case 11: dispatch_ext(); break;
      case 7:
        g_ticks++;
        if (!g_wdt_hang) wdt_service();
        timer_arm(TICK_CYCLES);
        break;
      case 3:
        g_msi_count++;
        MTIMER(CC_MTIMER_MSIP) = 0u;
        break;
      default: break;
    }
    return;
  }
  uint32_t tval = csr_read(mtval);
  if (g_expect.armed) {
    g_expect.cause = cause;
    g_expect.epc = f->mepc;
    g_expect.tval = tval;
    g_expect.count++;
    g_expect.armed = 0;
    f->mepc = (g_expect.mode == EXP_RESUME_RA) ? f->x[1] : f->mepc + 4u;
    return;
  }
  fatal_trap(cause, f->mepc, tval);
}

/* ---------------------------------------------------------------- RAS */
void ras_report(int fatal, uint32_t code) {
  RAS(CC_RAS_SW_REPORT) = (fatal ? 0x80000000u : 0u) | (code & 0x7FFFFFFFu);
}

/* ---------------------------------------------------------------- system DMA */
int dma_start(uint32_t src, uint32_t dst, uint32_t len) {
  if (DMA(CC_DMA_STATUS) & CC_DMA_STATUS_BUSY) return -2;
  g_dma_done = 0;
  DMA(CC_DMA_SRC_ADDR) = src;
  DMA(CC_DMA_DST_ADDR) = dst;
  DMA(CC_DMA_LENGTH) = len;
  DMA(CC_DMA_MODE) = 0u;
  DMA(CC_DMA_INT_STATUS) = CC_DMA_INT_DONE | CC_DMA_INT_ERROR;
  DMA(CC_DMA_INT_ENABLE) = CC_DMA_INT_DONE | CC_DMA_INT_ERROR;
  DMA(CC_DMA_CONTROL) = CC_DMA_CONTROL_START;
  return 0;
}
int dma_wait(uint32_t tmo) {
  if (WAIT_UNTIL(g_dma_done != 0u, tmo)) return -1;
  if (g_dma_status & CC_DMA_STATUS_ERROR) return (int)(DMA(CC_DMA_ERROR_CODE) & 0xFu);
  return 0;
}
int dma_copy(uint32_t src, uint32_t dst, uint32_t len) {
  int r = dma_start(src, dst, len);
  return r ? r : dma_wait(TMO_DEFAULT);
}

/* ---------------------------------------------------------------- init */
void platform_init(void) {
  /* interrupt sources: handlers, recommended priorities, threshold 0 */
  isr_table[CC_IRQ_FATAL] = isr_fatal;
  isr_table[CC_IRQ_WDT] = isr_wdt;
  isr_table[CC_IRQ_RAS_WARN] = isr_ras_warn;
  isr_table[CC_IRQ_DMA] = isr_dma;
  isr_table[CC_IRQ_TENSOR] = isr_tensor;
  isr_table[CC_IRQ_VECTOR] = isr_vector;
  isr_table[CC_IRQ_HOST] = isr_host;
  INTC(CC_INTC_ENABLE) = 0u;
  INTC(CC_INTC_SWPEND) = 0u;
  INTC(CC_INTC_PRIO0) = (CC_IRQ_FATAL_PRIO << (4 * CC_IRQ_FATAL)) | (CC_IRQ_WDT_PRIO << (4 * CC_IRQ_WDT)) |
                        (CC_IRQ_RAS_WARN_PRIO << (4 * CC_IRQ_RAS_WARN)) | (CC_IRQ_DMA_PRIO << (4 * CC_IRQ_DMA)) |
                        (CC_IRQ_TENSOR_PRIO << (4 * CC_IRQ_TENSOR)) | (CC_IRQ_VECTOR_PRIO << (4 * CC_IRQ_VECTOR)) |
                        (CC_IRQ_HOST_PRIO << (4 * CC_IRQ_HOST));
  INTC(CC_INTC_PRIO1) = 0u;
  INTC(CC_INTC_THRESHOLD) = 0u;
  /* RAS: every source reported */
  RAS(CC_RAS_STATUS) = 0xFFFFu;
  RAS(CC_RAS_WARN_EN) = RAS_WARN_ALL;
  RAS(CC_RAS_FATAL_EN) = RAS_FATAL_ALL;
  RAS(CC_RAS_CTRL) = 0x1u | 0x4u;               /* FATAL_TO_HOST, clear FIRST */
  /* timer tick + watchdog supervision */
  MTIMER(CC_MTIMER_PRESCALE) = 0u;
  timer_arm(TICK_CYCLES);
  WDT(CC_WDT_PRESCALE) = WDT_PRESCALE_RUN;
  WDT(CC_WDT_LOAD) = WDT_LOAD_RUN;
  WDT(CC_WDT_EWI_THRESH) = WDT_EWI_RUN;
  WDT(CC_WDT_CTRL) = CC_WDT_CTRL_EN | CC_WDT_CTRL_EWI_EN;
  wdt_service();
  INTC(CC_INTC_ENABLE) = (1u << CC_IRQ_FATAL) | (1u << CC_IRQ_WDT) | (1u << CC_IRQ_RAS_WARN) | (1u << CC_IRQ_DMA) |
                         (1u << CC_IRQ_TENSOR) | (1u << CC_IRQ_VECTOR) | (1u << CC_IRQ_HOST);
  csr_write(mie, MIE_MEIE | MIE_MTIE | MIE_MSIE);
  irq_enable();
}
