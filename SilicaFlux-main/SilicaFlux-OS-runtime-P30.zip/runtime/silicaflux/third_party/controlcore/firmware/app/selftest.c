/* =============================================================================
 * SilicaFlux ControlCore firmware -- self-test suite (runs on the RTL)
 *
 * Every check is self-contained: firmware computes its own reference (INT32
 * GEMM with RV32IM, FP32 with libgcc soft-float on exactly representable
 * values) and compares with what the hardware produced.  Results are printed on
 * the host-visible console and returned to the host (RUN_SELFTEST).
 *
 * Device-memory layout used here (DEVMEM = 0x2000_0000, 1 MiB):
 *   +0x10000 DMA test   +0x20000 vector operands   +0x30000 tensor operands
 *   +0x40000 concurrency set   (the host uses +0x80000 and up)
 * ===========================================================================*/
#include "fw.h"

tally_t g_tally;
static uint32_t t_checks, t_fails, t_id;

#define DEV(off)   (CC_DEVMEM_BASE + (off))
#define SPM(off)   (CC_TILE_SPM_BASE + (off))
#define DW(a)      REG32(a)

void check(int ok, uint32_t id, uint32_t got, uint32_t exp) {
  t_checks++;
  g_tally.checks++;
  if (!ok) {
    t_fails++;
    g_tally.fails++;
    cprintf("  FAIL %04x got=%08x exp=%08x\n", id, got, exp);
  }
}
static void t_begin(uint32_t id, const char *name) {
  t_id = id;
  t_checks = t_fails = 0;
  cprintf("[T%u %s]\n", id, name);
}
static void t_end(void) { cprintf("  -> checks=%u fails=%u\n", t_checks, t_fails); }
#define C(n) ((t_id << 8) | (n))

static uint32_t lcg_state = 12345u;
static uint32_t lcg(void) { lcg_state = lcg_state * 1664525u + 1013904223u; return lcg_state; }
static uint32_t fbits(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }

static void dev_wr_bytes(uint32_t dst, const void *src, uint32_t n) {   /* word stores to EXT */
  const uint8_t *s = (const uint8_t *)src;
  for (uint32_t i = 0; i < n; i += 4) {
    uint32_t w = 0;
    for (uint32_t b = 0; b < 4 && i + b < n; b++) w |= (uint32_t)s[i + b] << (8 * b);
    DW(dst + i) = w;
  }
}

/* ============================================================== T1 identity */
static void t_identity(void) {
  t_begin(1, "identity / ISA / map version");
  uint32_t misa = csr_read(misa);
  CHECK_EQ(C(1), misa >> 30, 1u);                         /* MXL = 32 */
  CHECK_TRUE(C(2), misa & (1u << 8));                     /* I */
  CHECK_TRUE(C(3), misa & (1u << 12));                    /* M */
  CHECK_EQ(C(4), csr_read(mhartid), 0u);
  CHECK_EQ(C(5), csr_read(mimpid), 0x00210001u);
  CHECK_EQ(C(6), SYSCTRL(CC_SYSCTRL_ID), CC_SYSCTRL_ID_RST);
  CHECK_EQ(C(7), SYSCTRL(CC_SYSCTRL_HW_VERSION), CC_SYSCTRL_HW_VERSION_RST);
  CHECK_EQ(C(8), SYSCTRL(CC_SYSCTRL_MAP_VERSION), CC_MAP_VERSION);
  CHECK_EQ(C(9), SYSCTRL(CC_SYSCTRL_IMEM_BYTES), CC_IMEM_SIZE);
  CHECK_EQ(C(10), SYSCTRL(CC_SYSCTRL_DMEM_BYTES), CC_DMEM_SIZE);
  CHECK_EQ(C(11), SYSCTRL(CC_SYSCTRL_ROM_BYTES), CC_BOOTROM_SIZE);
  CHECK_EQ(C(12), SYSCTRL(CC_SYSCTRL_FEATURES) & 0x7Fu, 0x7Fu);
  CHECK_EQ(C(13), SEC(CC_SEC_CAPS) & 0xFu, 0u);          /* no auth / secure boot / RoT / debug: honest */
  CHECK_EQ(C(14), (SEC(CC_SEC_STATUS) >> 2) & 3u, 0u);   /* AUTH_STATE = not implemented */
  CHECK_EQ(C(15), SEC(CC_SEC_BOOT_MEASURE), ((const volatile cc_image_hdr_t *)CC_IMEM_BASE)->crc32);
  CHECK_EQ(C(16), DMA(CC_DMA_ID), CC_DMA_ID_VALUE);
  CHECK_EQ(C(17), PMU(CC_PMU_INFO), 0x11u);
  t_end();
}

/* ============================================================== T2 MMIO */
static void t_mmio(void) {
  t_begin(2, "MMIO read/write and refused accesses");
  static const uint32_t pat[4] = {0xA5A5A5A5u, 0x5A5A5A5Au, 0xFFFFFFFFu, 0x00000000u};
  for (int i = 0; i < 4; i++) {
    SYSCTRL(CC_SYSCTRL_SCRATCH3) = pat[i];
    CHECK_EQ(C(1 + i), SYSCTRL(CC_SYSCTRL_SCRATCH3), pat[i]);
  }
  for (int b = 0; b < 32; b++) {                          /* walking one in a mailbox register */
    MBOX_F2H(7) = 1u << b;
    if (MBOX_F2H(7) != (1u << b)) CHECK_EQ(C(5), MBOX_F2H(7), 1u << b);
  }
  CHECK_TRUE(C(6), 1);
  INTC(CC_INTC_PRIO1) = 0xFFFFFFFFu;                      /* writable bits only */
  CHECK_EQ(C(7), INTC(CC_INTC_PRIO1), 0x77777777u);
  INTC(CC_INTC_PRIO1) = 0u;
  uint32_t w0 = RAS(CC_RAS_WARN_COUNT);
  /* write to a read-only register -> store access fault, mtval = address */
  CHECK_EQ(C(8), probe_wr(CC_SYSCTRL_BASE + CC_SYSCTRL_ID, 0x1234u), 7u);
  CHECK_EQ(C(9), g_expect.tval, CC_SYSCTRL_BASE + CC_SYSCTRL_ID);
  CHECK_EQ(C(10), SYSCTRL(CC_SYSCTRL_ID), CC_SYSCTRL_ID_RST);
  /* sub-word write to a register page -> refused by the bridge */
  CHECK_EQ(C(11), probe_wr8(CC_SYSCTRL_BASE + CC_SYSCTRL_SCRATCH3, 0x55u), 7u);
  /* unmapped offset inside a page, and an absent page */
  uint32_t v;
  CHECK_EQ(C(12), probe_rd(CC_SYSCTRL_BASE + 0xFFCu, &v), 5u);
  CHECK_EQ(C(13), probe_rd(CC_PERIPH_BASE + 20u * CC_PAGE_SIZE, &v), 5u);
  /* soft reset with a wrong key is refused (and does NOT reset) */
  CHECK_EQ(C(14), probe_wr(CC_SYSCTRL_BASE + CC_SYSCTRL_SOFT_RESET, 0x12345678u), 7u);
  /* RAS saw the refused accesses */
  CHECK_TRUE(C(15), RAS(CC_RAS_WARN_COUNT) >= w0 + 5u);
  CHECK_TRUE(C(16), g_ras_warn_bits & (1u << CC_RAS_SRC_PERIPH_ERR));
  t_end();
}

/* ============================================================== T3 exceptions / invalid address */
static void t_except(void) {
  t_begin(3, "exceptions and invalid addresses");
  uint32_t v, d0 = RAS(CC_RAS_WARN_COUNT);
  RAS(CC_RAS_CTRL) = 0x1u | 0x4u;                         /* clear FIRST */
  CHECK_EQ(C(1), probe_rd(0x50000000u, &v), 5u);          /* unmapped: load access fault */
  CHECK_EQ(C(2), g_expect.tval, 0x50000000u);
  CHECK_EQ(C(3), RAS(CC_RAS_FIRST_SRC), 0x80000000u | CC_RAS_SRC_BUS_DECODE);
  CHECK_EQ(C(4), RAS(CC_RAS_FIRST_ADDR), 0x50000000u);
  CHECK_EQ(C(5), probe_wr(0x08000000u, 1u), 7u);          /* unmapped store */
  CHECK_EQ(C(6), probe_wr(CC_BOOTROM_BASE + 0x40u, 1u), 7u);   /* ROM is read-only */
  CHECK_EQ(C(7), probe_rd(CC_DMEM_BASE + 2u, &v), 4u);   /* misaligned load */
  CHECK_EQ(C(8), probe_rd(0x28000000u, &v), 5u);          /* EXT window, nothing behind it in the fabric */
  /* instruction fetch from DMEM: execute-never -> instruction access fault */
  expect_arm(EXP_RESUME_RA);
  ((void (*)(void))(uintptr_t)(CC_DMEM_BASE + 0x100u))();
  CHECK_EQ(C(9), expect_result(), 1u);
  CHECK_EQ(C(10), g_expect.epc, CC_DMEM_BASE + 0x100u);
  expect_arm(EXP_SKIP);
  __asm__ volatile(".word 0x00000000");                   /* illegal instruction */
  CHECK_EQ(C(11), expect_result(), 2u);
  expect_arm(EXP_SKIP);
  __asm__ volatile("ecall");
  CHECK_EQ(C(12), expect_result(), 11u);
  expect_arm(EXP_SKIP);
  __asm__ volatile("ebreak");
  CHECK_EQ(C(13), expect_result(), 3u);
  CHECK_TRUE(C(14), RAS(CC_RAS_WARN_COUNT) >= d0 + 2u);       /* the two data-side decode errors */
  CHECK_TRUE(C(15), PERF_CNT(CC_PERF_EV_BUS_ERR) >= 3u);
  t_end();
}

/* ============================================================== T4 timer */
static void t_timer(void) {
  t_begin(4, "machine timer, software interrupt, counters");
  uint64_t m0 = mtime();
  uint32_t c0 = cycles(), i0 = csr_read(minstret);
  for (volatile int i = 0; i < 100; i++) {}
  uint64_t m1 = mtime();
  CHECK_TRUE(C(1), m1 > m0);
  CHECK_TRUE(C(2), cycles() - c0 >= 100u);
  CHECK_TRUE(C(3), csr_read(minstret) - i0 >= 100u);
  /* periodic MTI tick while the CPU sleeps in WFI */
  uint32_t t0 = g_ticks, s0 = PMU(CC_PMU_SLEEP_CYC);
  CHECK_EQ(C(4), WAIT_UNTIL(g_ticks >= t0 + 3u, 10u * TICK_CYCLES), 0);
  CHECK_TRUE(C(5), PMU(CC_PMU_SLEEP_CYC) > s0 + TICK_CYCLES);
  /* prescaler: mtime advances 4x slower */
  MTIMER(CC_MTIMER_PRESCALE) = 3u;
  m0 = mtime(); c0 = cycles();
  while (cycles() - c0 < 4000u) {}
  m1 = mtime();
  MTIMER(CC_MTIMER_PRESCALE) = 0u;
  CHECK_TRUE(C(6), (m1 - m0) >= 950u && (m1 - m0) <= 1100u);
  /* MSI */
  uint32_t s1 = g_msi_count;
  MTIMER(CC_MTIMER_MSIP) = 1u;
  CHECK_EQ(C(7), WAIT_UNTIL(g_msi_count != s1, 1000u), 0);
  CHECK_EQ(C(8), MTIMER(CC_MTIMER_MSIP), 0u);
  t_end();
}

/* ============================================================== T5 interrupt controller */
static void t_intc(void) {
  t_begin(5, "INTC masking, priority, threshold, simultaneous sources");
  uint32_t en = INTC(CC_INTC_ENABLE), prio = INTC(CC_INTC_PRIO0);
  uint32_t m = irq_save();
  /* --- software-pended sources (MIE off: observe the controller directly) */
  INTC(CC_INTC_SWPEND) = 0x80u;                           /* source 7 is not enabled: masked */
  CHECK_EQ(C(1), INTC(CC_INTC_PENDING) & 0x80u, 0x80u);
  CHECK_EQ(C(2), INTC(CC_INTC_ACTIVE) & 0x80u, 0u);
  CHECK_EQ(C(3), INTC(CC_INTC_CLAIM), 0u);
  INTC(CC_INTC_ENABLE) = en | 0x80u;
  INTC(CC_INTC_PRIO0) = prio | 0x10000000u;              /* src7 priority 1 */
  CHECK_EQ(C(4), INTC(CC_INTC_CLAIM), 8u);
  INTC(CC_INTC_PRIO0) = 0u;                              /* priority 0 = never */
  CHECK_EQ(C(5), INTC(CC_INTC_CLAIM), 0u);
  INTC(CC_INTC_PRIO0) = 0x31000000u;                      /* src7 prio 3, src6 prio 1 */
  INTC(CC_INTC_SWPEND) = 0xC0u;
  CHECK_EQ(C(6), INTC(CC_INTC_CLAIM), 8u);                /* higher priority wins */
  INTC(CC_INTC_PRIO0) = 0x11000000u;
  CHECK_EQ(C(7), INTC(CC_INTC_CLAIM), 7u);                /* tie: lower index wins */
  INTC(CC_INTC_THRESHOLD) = 1u;
  CHECK_EQ(C(8), INTC(CC_INTC_CLAIM), 0u);                /* priority must exceed threshold */
  INTC(CC_INTC_THRESHOLD) = 0u;
  INTC(CC_INTC_SWPEND) = 0u;
  INTC(CC_INTC_ENABLE) = en;
  INTC(CC_INTC_PRIO0) = prio;
  /* --- seven REAL sources pending at the same time, then MIE on */
  g_irq_log_n = 0;
  RAS(CC_RAS_INJECT) = (1u << CC_RAS_SRC_SW_FATAL) | (1u << CC_RAS_SRC_SW_WARN);   /* FATAL, RAS_WARN */
  WDT(CC_WDT_EWI_THRESH) = 0xFFFFFFFFu;                                         /* WDT early warning */
  static uint32_t dsrc[16];
  for (int i = 0; i < 16; i++) dsrc[i] = (uint32_t)i;
  dma_start((uint32_t)(uintptr_t)dsrc, DEV(0x10000), 64u);                       /* DMA */
  uint32_t nd[TSU_DESC_WORDS];
  tsu_build_nop(nd, 0x51, 1);
  if (g_acc.tsu_present) tsu_submit_irq(nd);                                     /* TENSOR */
  hpc_cmd_t vn = hpc_cmd_nop(0x52, 0);
  if (g_acc.vec_present) vec_submit(&vn);                                        /* VECTOR */
  MBOX_H2F(0) = CC_MBOX_CMD_NONE;
  MBOX(CC_MBOX_H2F_RING) = 0x7E57u;                                              /* HOST */
  uint32_t want = 0x7Fu, t0 = cycles();
  if (!g_acc.tsu_present) want &= ~(1u << CC_IRQ_TENSOR);
  if (!g_acc.vec_present) want &= ~(1u << CC_IRQ_VECTOR);
  while ((INTC(CC_INTC_ACTIVE) & want) != want && cycles() - t0 < 20000u) {}
  CHECK_EQ(C(9), INTC(CC_INTC_ACTIVE) & want, want);
  uint32_t cmdp = g_cmd_pending;
  irq_restore(m);                                         /* all taken in ONE trap, by priority */
  WAIT_UNTIL(g_irq_log_n >= 7u - (uint32_t)(!g_acc.tsu_present) - (uint32_t)(!g_acc.vec_present), 50000u);
  static const uint32_t order[7] = {CC_IRQ_FATAL, CC_IRQ_WDT, CC_IRQ_RAS_WARN, CC_IRQ_DMA, CC_IRQ_TENSOR,
                                    CC_IRQ_VECTOR, CC_IRQ_HOST};
  uint32_t k = 0;
  for (int i = 0; i < 7; i++) {
    if (!(want & (1u << order[i]))) continue;
    CHECK_EQ(C(10 + i), g_irq_log[k], order[i]);
    k++;
  }
  CHECK_EQ(C(17), g_irq_log_n, k);
  CHECK_EQ(C(18), INTC(CC_INTC_PENDING) & 0x7Fu, 0u);    /* every source acknowledged at the source */
  /* consume the test records / doorbell */
  tsu_record_t r;
  hpc_cpl_t c;
  if (g_acc.tsu_present) CHECK_EQ(C(19), tsu_wait_irq(&r, 1000u) == 0 && r.tid == 0x51 && r.status == TSU_ST_OK, 1);
  if (g_acc.vec_present) CHECK_EQ(C(20), vec_wait(&c, 1000u) == 0 && c.tag == 0x52 && c.status == HPC_ST_OK, 1);
  if (g_cmd_pending != cmdp && g_cmd[0] == CC_MBOX_CMD_NONE) g_cmd_pending = cmdp;
  CHECK_TRUE(C(21), g_ras_fatal_bits & (1u << (CC_RAS_SRC_SW_FATAL - 8)));
  t_end();
}

/* ============================================================== T6 DMA */
static uint32_t dma_buf[256], dma_back[256];
static void t_dma(void) {
  t_begin(6, "system DMA: DMEM <-> device memory, completion IRQ, errors");
  for (int i = 0; i < 256; i++) { dma_buf[i] = lcg(); dma_back[i] = 0; }
  uint32_t n0 = g_irq_count[CC_IRQ_DMA];
  CHECK_EQ(C(1), dma_copy((uint32_t)(uintptr_t)dma_buf, DEV(0x10000), 1024u), 0);
  int bad = 0;
  for (int i = 0; i < 256; i++) bad += DW(DEV(0x10000) + 4u * i) != dma_buf[i];
  CHECK_EQ(C(2), bad, 0);
  CHECK_EQ(C(3), dma_copy(DEV(0x10000), (uint32_t)(uintptr_t)dma_back, 1024u), 0);
  CHECK_EQ(C(4), memcmp(dma_back, dma_buf, 1024u), 0);
  CHECK_EQ(C(5), DMA(CC_DMA_BYTES_DONE), 1024u);
  CHECK_EQ(C(6), g_irq_count[CC_IRQ_DMA] - n0, 2u);
  /* device -> device */
  CHECK_EQ(C(7), dma_copy(DEV(0x10000), DEV(0x10400), 1024u), 0);
  CHECK_EQ(C(8), DW(DEV(0x10400) + 4u * 255u), dma_buf[255]);
  /* error: read from an unmapped address -> DataFabric READ_BUS (8), RAS DMA_ERR */
  uint32_t w0 = g_ras_warn_bits;
  (void)w0;
  CHECK_EQ(C(9), dma_copy(0x50000000u, DEV(0x10800), 64u), 8);
  CHECK_TRUE(C(10), g_ras_warn_bits & (1u << CC_RAS_SRC_DMA_ERR));
  /* error: device memory answers with an error (poisoned window) */
  CHECK_EQ(C(11), dma_copy(CC_TB_POISON_BASE, DEV(0x10800), 64u), 8);
  /* validation: misaligned source is rejected before any bus access */
  CHECK_TRUE(C(12), dma_copy(DEV(0x10002), DEV(0x10800), 64u) > 0);
  /* recovery: the next transfer works */
  CHECK_EQ(C(13), dma_copy((uint32_t)(uintptr_t)dma_buf, DEV(0x10800), 64u), 0);
  CHECK_EQ(C(14), DW(DEV(0x10800)), dma_buf[0]);
  t_end();
}

/* ============================================================== T7 vector */
#define VL 32u
static float va[VL], vb[VL], vc[VL];
static void t_vector(void) {
  t_begin(7, "vector tile commands (KERNEL, DMA+VEC, reduction)");
  if (!g_acc.vec_present) { CHECK_TRUE(C(0), 0); t_end(); return; }
  for (uint32_t i = 0; i < VL; i++) {                     /* exactly representable: fused == unfused */
    va[i] = (float)(i + 1u) * 0.5f;
    vb[i] = (float)((int)(i % 7u) - 3) + 0.25f;
    vc[i] = 1.5f;
  }
  dev_wr_bytes(DEV(0x20000), va, VL * 4u);
  dev_wr_bytes(DEV(0x21000), vb, VL * 4u);
  dev_wr_bytes(DEV(0x22000), vc, VL * 4u);
  static const struct { unsigned op; const char *n; } ops[3] = {
      {HPC_OP_FADD, "FADD"}, {HPC_OP_FMUL, "FMUL"}, {HPC_OP_FMADD, "FMADD"}};
  hpc_cpl_t cpl;
  for (int k = 0; k < 3; k++) {
    hpc_cmd_t c = hpc_cmd_kernel(ops[k].op, HPC_RNE, VL, DEV(0x20000), DEV(0x21000), DEV(0x22000), DEV(0x23000),
                                 SPM(0), 0u, (uint8_t)(0x10 + k), 0u);
    uint32_t n0 = g_irq_count[CC_IRQ_VECTOR];
    CHECK_EQ(C(1 + 4 * k), vec_run(&c, &cpl), 0);
    CHECK_EQ(C(2 + 4 * k), cpl.status, HPC_ST_OK);
    CHECK_EQ(C(3 + 4 * k), cpl.count, VL);
    CHECK_TRUE(C(4 + 4 * k), g_irq_count[CC_IRQ_VECTOR] > n0);
    int bad = 0;
    for (uint32_t i = 0; i < VL; i++) {
      float ref = (k == 0) ? va[i] + vb[i] : (k == 1) ? va[i] * vb[i] : va[i] * vb[i] + vc[i];
      if (DW(DEV(0x23000) + 4u * i) != fbits(ref)) bad++;
    }
    CHECK_EQ(C(13 + k), bad, 0);
    cprintf("  KERNEL %s vl=%u: status=%u cycles=%u\n", ops[k].n, VL, cpl.status, cpl.cycles);
  }
  /* explicit pipeline: tile DMA host->SPM (x2), VEC on the scratchpad, tile DMA SPM->host; submitted
   * back to back, ordered by the tile's own hazard checks */
  hpc_cmd_t q[4] = {
      hpc_cmd_dma(DEV(0x20000), SPM(0x8000), VL * 4u, 0x21, 0u),
      hpc_cmd_dma(DEV(0x21000), SPM(0x9000), VL * 4u, 0x22, 0u),
      hpc_cmd_vec(HPC_OP_FSUB, HPC_RNE, VL, SPM(0x8000), SPM(0x9000), 0u, SPM(0xA000), 0u, 0x23, 0u),
      hpc_cmd_dma(SPM(0xA000), DEV(0x24000), VL * 4u, 0x24, 0u)};
  for (int i = 0; i < 4; i++) CHECK_EQ(C(20 + i), vec_submit(&q[i]), 0);
  for (int i = 0; i < 4; i++) {
    CHECK_EQ(C(24 + i), vec_wait(&cpl, TMO_DEFAULT), 0);
    CHECK_EQ(C(28 + i), cpl.tag | (cpl.status << 8), (uint32_t)(0x21 + i));
  }
  int bad = 0;
  for (uint32_t i = 0; i < VL; i++) bad += DW(DEV(0x24000) + 4u * i) != fbits(va[i] - vb[i]);
  CHECK_EQ(C(32), bad, 0);
  /* sum reduction of A + B: result in the completion record */
  float sum = 0.0f;
  for (uint32_t i = 0; i < VL; i++) sum += va[i] + vb[i];
  hpc_cmd_t r = hpc_cmd_vec(HPC_OP_FADD, HPC_RNE, VL, SPM(0x8000), SPM(0x9000), 0u, SPM(0xB000), 0u, 0x25, HPC_RED);
  CHECK_EQ(C(33), vec_run(&r, &cpl), 0);
  CHECK_EQ(C(34), cpl.status, HPC_ST_OK);
  CHECK_EQ(C(35), cpl.result, fbits(sum));
  t_end();
}

/* ============================================================== T8 tensor */
static int8_t ta[32 * 64], tb[64 * 32];
static int32_t tref[32 * 32];
static void gemm_ref(const int8_t *a, const int8_t *b, int32_t *c, uint32_t m, uint32_t n, uint32_t k) {
  for (uint32_t i = 0; i < m; i++)
    for (uint32_t j = 0; j < n; j++) {
      int32_t s = 0;
      for (uint32_t x = 0; x < k; x++) s += (int32_t)a[i * k + x] * (int32_t)b[x * n + j];
      c[i * n + j] = s;
    }
}
static void gemm_fill(uint32_t m, uint32_t n, uint32_t k, uint32_t a_dev, uint32_t b_dev) {
  for (uint32_t i = 0; i < m * k; i++) ta[i] = (int8_t)(lcg() >> 24);
  for (uint32_t i = 0; i < k * n; i++) tb[i] = (int8_t)(lcg() >> 24);
  dev_wr_bytes(a_dev, ta, m * k);
  dev_wr_bytes(b_dev, tb, k * n);
  gemm_ref(ta, tb, tref, m, n, k);
}
static int gemm_cmp_i32(uint32_t c_dev, uint32_t m, uint32_t n) {
  int bad = 0;
  for (uint32_t i = 0; i < m * n; i++) bad += (int32_t)DW(c_dev + 4u * i) != tref[i];
  return bad;
}
static int32_t rne_shift(int64_t x, unsigned s) {            /* round to nearest even of x / 2^s */
  if (s == 0) return (int32_t)x;
  int64_t q = x >> s, r = x - (q << s), half = (int64_t)1 << (s - 1);
  if (r > half || (r == half && (q & 1))) q++;
  return (int32_t)q;
}
static void t_tensor(void) {
  t_begin(8, "tensor unit GEMM descriptors (INT8 -> INT32 / INT8)");
  if (!g_acc.tsu_present) { CHECK_TRUE(C(0), 0); t_end(); return; }
  static const uint32_t dims[3][3] = {{8, 8, 16}, {17, 13, 29}, {4, 4, 4}};
  tsu_record_t rec;
  uint32_t d[TSU_DESC_WORDS];
  for (int t = 0; t < 3; t++) {
    uint32_t m = dims[t][0], n = dims[t][1], k = dims[t][2];
    gemm_fill(m, n, k, DEV(0x30000), DEV(0x34000));
    tsu_opts_t o;
    memset(&o, 0, sizeof o);
    o.irq = 1;
    tsu_build_gemm(d, (uint8_t)(0x30 + t), DEV(0x30000), DEV(0x34000), DEV(0x38000), m, n, k, &o);
    CHECK_EQ(C(1 + 5 * t), tsu_check(&g_acc.tsu, d), 0);
    uint32_t n0 = g_irq_count[CC_IRQ_TENSOR];
    CHECK_EQ(C(2 + 5 * t), tsu_run(d, &rec), 0);
    CHECK_EQ(C(3 + 5 * t), rec.status | (rec.err << 8), TSU_ST_OK);
    CHECK_EQ(C(4 + 5 * t), rec.count, m * n * 4u);
    CHECK_EQ(C(5 + 5 * t), gemm_cmp_i32(DEV(0x38000), m, n), 0);
    CHECK_TRUE(C(16 + t), g_irq_count[CC_IRQ_TENSOR] > n0);
    cprintf("  GEMM %ux%ux%u INT32: status=%u tiles=%u cycles=%u\n", m, n, k, rec.status, rec.tiles, rec.cycles);
  }
  /* requantised INT8 output with ReLU: q = max(clamp(R_rne(acc * 2^20 / 2^23) + zp), zp) */
  {
    uint32_t m = 8, n = 8, k = 32;
    int8_t zp = -3;
    gemm_fill(m, n, k, DEV(0x30000), DEV(0x34000));
    tsu_opts_t o;
    memset(&o, 0, sizeof o);
    o.irq = 1; o.out_int8 = 1; o.rm = TSU_RM_RNE; o.relu = 1; o.qmult = 1 << 20; o.qshift = 23; o.qzp = zp;
    tsu_build_gemm(d, 0x38, DEV(0x30000), DEV(0x34000), DEV(0x3C000), m, n, k, &o);
    CHECK_EQ(C(20), tsu_run(d, &rec), 0);
    CHECK_EQ(C(21), rec.status | (rec.err << 8), TSU_ST_OK);
    int bad = 0;
    for (uint32_t i = 0; i < m * n; i++) {
      int32_t q = rne_shift((int64_t)tref[i] * (1 << 20), 23) + zp;
      if (q > 127) q = 127;
      if (q < -128) q = -128;
      if (q < zp) q = zp;
      int8_t got = (int8_t)(DW(DEV(0x3C000) + (i & ~3u)) >> (8 * (i & 3u)));
      bad += got != (int8_t)q;
    }
    CHECK_EQ(C(22), bad, 0);
  }
  t_end();
}

/* ============================================================== T9 concurrency */
static void t_concur(void) {
  t_begin(9, "concurrent tensor GEMM + vector KERNEL + system DMA");
  if (!g_acc.tsu_present || !g_acc.vec_present) { CHECK_TRUE(C(0), 0); t_end(); return; }
  uint32_t m = 16, n = 16, k = 64, d[TSU_DESC_WORDS];
  gemm_fill(m, n, k, DEV(0x40000), DEV(0x44000));
  tsu_opts_t o;
  memset(&o, 0, sizeof o);
  o.irq = 1;
  tsu_build_gemm(d, 0x40, DEV(0x40000), DEV(0x44000), DEV(0x48000), m, n, k, &o);
  hpc_cmd_t kc = hpc_cmd_kernel(HPC_OP_FMADD, HPC_RNE, VL, DEV(0x20000), DEV(0x21000), DEV(0x22000), DEV(0x4C000),
                                SPM(0x1000), 0u, 0x41, 0u);
  for (int i = 0; i < 256; i++) dma_buf[i] = ~(uint32_t)i;
  uint32_t ov0 = PERF_CNT(CC_PERF_EV_ACC_OVERLAP), l0 = g_irq_log_n;
  CHECK_EQ(C(1), tsu_submit_irq(d), 0);
  CHECK_EQ(C(2), vec_submit(&kc), 0);
  CHECK_EQ(C(3), dma_start((uint32_t)(uintptr_t)dma_buf, DEV(0x4E000), 1024u), 0);
  tsu_record_t rec;
  hpc_cpl_t cpl;
  CHECK_EQ(C(4), dma_wait(TMO_DEFAULT), 0);
  CHECK_EQ(C(5), vec_wait(&cpl, TMO_DEFAULT), 0);
  CHECK_EQ(C(6), tsu_wait_irq(&rec, 20000000u), 0);
  CHECK_EQ(C(7), cpl.status, HPC_ST_OK);
  CHECK_EQ(C(8), rec.status, TSU_ST_OK);
  CHECK_EQ(C(9), gemm_cmp_i32(DEV(0x48000), m, n), 0);
  int bad = 0;
  for (uint32_t i = 0; i < VL; i++) bad += DW(DEV(0x4C000) + 4u * i) != fbits(va[i] * vb[i] + vc[i]);
  CHECK_EQ(C(10), bad, 0);
  CHECK_EQ(C(11), DW(DEV(0x4E000) + 4u * 255u), ~255u);
  CHECK_TRUE(C(12), PERF_CNT(CC_PERF_EV_ACC_OVERLAP) > ov0);
  CHECK_TRUE(C(13), g_irq_log_n - l0 >= 3u);
  cprintf("  overlap cycles=%u  irqs=%u\n", PERF_CNT(CC_PERF_EV_ACC_OVERLAP) - ov0, g_irq_log_n - l0);
  t_end();
}

/* ============================================================== T10 error handling and recovery */
static void t_errors(void) {
  t_begin(10, "accelerator error handling and recovery");
  hpc_cpl_t cpl;
  tsu_record_t rec;
  uint32_t d[TSU_DESC_WORDS];
  if (g_acc.vec_present) {
    /* reserved command type -> BAD_TYPE record, tile halts (HALT_ON_ERROR), firmware resumes */
    hpc_cmd_t bad = hpc_cmd_nop(0x60, 0u);
    bad.w[0] = (bad.w[0] & ~0xFu) | 0x7u;
    CHECK_EQ(C(1), vec_run(&bad, &cpl), 0);
    CHECK_EQ(C(2), cpl.status, HPC_ST_BAD_TYPE);
    ras_report(0, 0xA0000000u | cpl.status);
    CHECK_TRUE(C(3), hpc_status(CC_VECTOR_BASE) & 2u);     /* HALTED */
    hpc_resume(CC_VECTOR_BASE);
    hpc_cmd_t nop = hpc_cmd_nop(0x61, 0u);
    CHECK_EQ(C(4), vec_run(&nop, &cpl), 0);
    CHECK_EQ(C(5), cpl.status | (cpl.tag << 8), HPC_ST_OK | (0x61u << 8));
    /* tile DMA from the poisoned window -> DMA_ERR (READ_BUS), resume, retry from good memory */
    hpc_cmd_t dm = hpc_cmd_dma(CC_TB_POISON_BASE, SPM(0xC000), 64u, 0x62, 0u);
    CHECK_EQ(C(6), vec_run(&dm, &cpl), 0);
    CHECK_EQ(C(7), cpl.status | (cpl.detail << 8), HPC_ST_DMA_ERR | (8u << 8));
    hpc_resume(CC_VECTOR_BASE);
    dm = hpc_cmd_dma(DEV(0x20000), SPM(0xC000), 64u, 0x63, 0u);
    CHECK_EQ(C(8), vec_run(&dm, &cpl), 0);
    CHECK_EQ(C(9), cpl.status, HPC_ST_OK);
  }
  if (g_acc.tsu_present) {
    /* invalid descriptor (M = 0) -> ERROR DIM_ZERO, never executed; later commands SKIPPED until ERR_CLEAR */
    tsu_opts_t o;
    memset(&o, 0, sizeof o);
    o.irq = 1;
    tsu_build_gemm(d, 0x70, DEV(0x30000), DEV(0x34000), DEV(0x38000), 0, 4, 4, &o);
    CHECK_EQ(C(10), tsu_check(&g_acc.tsu, d), TSU_E_DIM_ZERO);
    CHECK_EQ(C(11), tsu_run(d, &rec), 0);
    CHECK_EQ(C(12), rec.status | (rec.err << 8), TSU_ST_ERROR | (TSU_E_DIM_ZERO << 8));
    tsu_build_gemm(d, 0x71, DEV(0x30000), DEV(0x34000), DEV(0x38000), 4, 4, 4, &o);
    CHECK_EQ(C(13), tsu_run(d, &rec), 0);
    CHECK_EQ(C(14), rec.status, TSU_ST_SKIPPED);
    tsu_clear_error();
    gemm_fill(4, 4, 4, DEV(0x30000), DEV(0x34000));
    tsu_build_gemm(d, 0x72, DEV(0x30000), DEV(0x34000), DEV(0x38000), 4, 4, 4, &o);
    CHECK_EQ(C(15), tsu_run(d, &rec), 0);
    CHECK_EQ(C(16), rec.status, TSU_ST_OK);
    CHECK_EQ(C(17), gemm_cmp_i32(DEV(0x38000), 4, 4), 0);
    /* operand in poisoned memory -> DMA_READ error with the failing address, then recovery */
    tsu_build_gemm(d, 0x73, CC_TB_POISON_BASE, DEV(0x34000), DEV(0x38000), 4, 4, 4, &o);
    CHECK_EQ(C(18), tsu_run(d, &rec), 0);
    CHECK_EQ(C(19), rec.status | (rec.err << 8), TSU_ST_ERROR | (TSU_E_DMA_READ << 8));
    CHECK_EQ(C(20), rec.err_addr & ~0xFFFu, CC_TB_POISON_BASE);
    ras_report(0, 0xB0000000u | rec.err);
    tsu_clear_error();
    tsu_build_gemm(d, 0x74, DEV(0x30000), DEV(0x34000), DEV(0x38000), 4, 4, 4, &o);
    CHECK_EQ(C(21), tsu_run(d, &rec), 0);
    CHECK_EQ(C(22), rec.status, TSU_ST_OK);
  }
  /* full accelerator-domain reset through the PMU and rediscovery */
  uint32_t sub_before = g_acc.tsu_present ? TSU_RD32(TSU_R_SUBMITTED) : 0u;
  int mask = acc_reset();
  CHECK_EQ(C(23), mask, (g_acc.vec_present ? 1 : 0) | (g_acc.tsu_present ? 2 : 0));
  CHECK_TRUE(C(24), mask == 3);
  if (g_acc.tsu_present) {
    CHECK_TRUE(C(25), sub_before > 0u);
    CHECK_EQ(C(26), TSU_RD32(TSU_R_SUBMITTED), 0u);       /* the unit really was reset */
    gemm_fill(8, 8, 8, DEV(0x30000), DEV(0x34000));
    tsu_opts_t o;
    memset(&o, 0, sizeof o);
    o.irq = 1;
    tsu_build_gemm(d, 0x75, DEV(0x30000), DEV(0x34000), DEV(0x38000), 8, 8, 8, &o);
    CHECK_EQ(C(27), tsu_run(d, &rec), 0);
    CHECK_EQ(C(28), rec.status, TSU_ST_OK);
    CHECK_EQ(C(29), gemm_cmp_i32(DEV(0x38000), 8, 8), 0);
  }
  t_end();
}

/* ============================================================== T11 RAS */
static void t_ras(void) {
  t_begin(11, "RAS warning / fatal reporting, parity error injection");
  uint32_t wi = g_ras_warn_irqs, fi = g_ras_fatal_irqs, fc = RAS(CC_RAS_FATAL_COUNT);
  RAS(CC_RAS_INJECT) = 1u << CC_RAS_SRC_SW_WARN;
  CHECK_EQ(C(1), WAIT_UNTIL(g_ras_warn_irqs != wi, 1000u), 0);
  RAS(CC_RAS_INJECT) = 1u << CC_RAS_SRC_EXT_FATAL;
  CHECK_EQ(C(2), WAIT_UNTIL(g_ras_fatal_irqs != fi, 1000u), 0);
  CHECK_EQ(C(3), RAS(CC_RAS_FATAL_COUNT), fc + 1u);
  RAS(CC_RAS_FATAL_EN) = 0x0Fu;                           /* re-arm (the ISR masks level sources) */
  /* firmware-reported fatal with a code */
  fi = g_ras_fatal_irqs;
  ras_report(1, 0x1234u);
  CHECK_EQ(C(4), WAIT_UNTIL(g_ras_fatal_irqs != fi, 1000u), 0);
  CHECK_EQ(C(5), RAS(CC_RAS_SW_CODE), 0x1234u);
  /* parity: corrupt one DMEM word on write, the read is answered with a bus error,
   * reported as fatal MEM_PARITY; scrubbing the word (rewrite) recovers */
  static volatile uint32_t victim = 0x600DF00Du;
  uint32_t addr = (uint32_t)(uintptr_t)&victim, v;
  fi = g_ras_fatal_irqs;
  RAS(CC_RAS_CTRL) = 0x1u | 0x4u;
  __asm__ volatile(
      "li   t0, 1\n"
      "sw   t0, 0(%0)\n"            /* RAS.PAR_INJECT = 1 */
      "sw   %2, 0(%1)\n"            /* next write -> inverted parity */
      :: "r"(CC_RAS_BASE + CC_RAS_PAR_INJECT), "r"(addr), "r"(0xBADC0DEu) : "t0", "memory");
  CHECK_EQ(C(6), RAS(CC_RAS_PAR_INJECT), 0u);             /* one-shot */
  CHECK_EQ(C(7), probe_rd(addr, &v), 5u);                 /* load access fault */
  CHECK_EQ(C(8), WAIT_UNTIL(g_ras_fatal_irqs != fi, 1000u), 0);
  CHECK_TRUE(C(9), g_ras_fatal_bits & (1u << (CC_RAS_SRC_MEM_PARITY - 8)));
  CHECK_EQ(C(10), RAS(CC_RAS_FIRST_SRC), 0x80000000u | CC_RAS_SRC_MEM_PARITY);
  CHECK_EQ(C(11), RAS(CC_RAS_FIRST_ADDR), addr);
  victim = 0x600DF00Du;                                   /* scrub */
  CHECK_EQ(C(12), probe_rd(addr, &v), 0u);
  CHECK_EQ(C(13), v, 0x600DF00Du);
  t_end();
}

/* ============================================================== T12 performance counters */
static void t_perf(void) {
  t_begin(12, "performance counters (ControlCore, vector tile, tensor unit)");
  uint32_t lo0 = PERF(CC_PERF_CYCLE_LO);
  CHECK_TRUE(C(1), PERF(CC_PERF_CYCLE_LO) != lo0);
  CHECK_EQ(C(2), PERF(CC_PERF_INFO), 20u);
  PERF(CC_PERF_CTRL) = 1u;                                /* freeze */
  lo0 = PERF(CC_PERF_CYCLE_LO);
  uint32_t e0 = PERF_CNT(CC_PERF_EV_EXT_REQ);
  (void)DW(DEV(0));
  CHECK_EQ(C(3), PERF(CC_PERF_CYCLE_LO), lo0);
  CHECK_EQ(C(4), PERF_CNT(CC_PERF_EV_EXT_REQ), e0);
  PERF(CC_PERF_CTRL) = 0u;
  CHECK_TRUE(C(5), PERF_CNT(CC_PERF_EV_TSU_BUSY) > 0u);
  CHECK_TRUE(C(6), PERF_CNT(CC_PERF_EV_VEC_BUSY) > 0u);
  CHECK_TRUE(C(7), PERF_CNT(CC_PERF_EV_DMA_BUSY) > 0u);
  CHECK_TRUE(C(8), PERF_CNT(CC_PERF_EV_SRC_TENSOR) > 0u);
  if (g_acc.tsu_present && g_acc.vec_present) {
    /* exact accelerator counters for a known workload */
    tsu_clear_counters();
    hpc_perf_clear(CC_VECTOR_BASE);
    uint32_t d[TSU_DESC_WORDS];
    tsu_record_t rec;
    hpc_cpl_t cpl;
    tsu_opts_t o;
    memset(&o, 0, sizeof o);
    o.irq = 1;
    gemm_fill(12, 8, 40, DEV(0x30000), DEV(0x34000));
    tsu_build_gemm(d, 0x80, DEV(0x30000), DEV(0x34000), DEV(0x38000), 12, 8, 40, &o);
    CHECK_EQ(C(9), tsu_run(d, &rec), 0);
    CHECK_EQ(C(10), tsu_counter(TSU_PC_GEMM_OK), 1u);
    CHECK_EQ(C(11), tsu_counter(TSU_PC_MACS), 12u * 8u * 40u);
    CHECK_EQ(C(12), tsu_counter(TSU_PC_CMD_DONE), 1u);
    hpc_cmd_t kc = hpc_cmd_kernel(HPC_OP_FADD, HPC_RNE, VL, DEV(0x20000), DEV(0x21000), 0u, DEV(0x23000), SPM(0),
                                  0u, 0x81, 0u);
    CHECK_EQ(C(13), vec_run(&kc, &cpl), 0);
    CHECK_EQ(C(14), hpc_perf_read(CC_VECTOR_BASE, HPC_PC_KERNEL_CMDS), 1u);
    CHECK_EQ(C(15), hpc_perf_read(CC_VECTOR_BASE, HPC_PC_VEC_ELEMS), VL);
    CHECK_EQ(C(16), hpc_perf_read(CC_VECTOR_BASE, HPC_PC_VEC_FLOPS), VL);
  }
  uint32_t n = perf_dump(DEV(0x50000));
  CHECK_EQ(C(17), n, 4u + 20u + 2u + 24u + 2u + 20u);
  CHECK_EQ(C(18), DW(DEV(0x50000)), 0x43435046u);
  t_end();
}

/* ============================================================== T13 watchdog (no reset) */
static void t_wdt(void) {
  t_begin(13, "watchdog service, count, early-warning interrupt");
  CHECK_EQ(C(1), WDT(CC_WDT_CTRL) & 0x5u, CC_WDT_CTRL_EN | CC_WDT_CTRL_EWI_EN);
  uint32_t c0 = WDT(CC_WDT_COUNT);
  uint32_t t0 = cycles();
  while (cycles() - t0 < 2000u) {}
  uint32_t c1 = WDT(CC_WDT_COUNT);
  CHECK_TRUE(C(2), c1 < c0);
  wdt_service();
  CHECK_TRUE(C(3), WDT(CC_WDT_COUNT) >= c1);
  CHECK_EQ(C(4), probe_wr(CC_WDT_BASE + CC_WDT_COUNT, 0u), 7u);   /* read-only */
  uint32_t e0 = g_wdt_ewi;
  WDT(CC_WDT_EWI_THRESH) = 0xFFFFFFFFu;                   /* force the early warning now */
  CHECK_EQ(C(5), WAIT_UNTIL(g_wdt_ewi != e0, 1000u), 0);
  CHECK_EQ(C(6), WDT(CC_WDT_EWI_THRESH), WDT_EWI_RUN);   /* handler restored and serviced */
  CHECK_EQ(C(7), WDT(CC_WDT_STATUS) & CC_WDT_STATUS_EWI, 0u);
  t_end();
}

/* ============================================================== T14 power management */
static void t_pmu(void) {
  t_begin(14, "PMU: accelerator isolation and clock gating");
  uint32_t v;
  PMU(CC_PMU_ACC_CTRL) = 0x1u | 0x4u;                     /* isolate */
  CHECK_TRUE(C(1), PMU(CC_PMU_ACC_STATUS) & 0x4u);
  CHECK_EQ(C(2), probe_rd(TSU_BASE + TSU_R_ID, &v), 5u);  /* register page refused */
  CHECK_EQ(C(3), probe_rd(DEV(0), &v), 5u);               /* data port refused */
  CHECK_TRUE(C(4), g_ras_warn_bits & (1u << CC_RAS_SRC_ISO_ACCESS));
  PMU(CC_PMU_ACC_CTRL) = 0x1u;
  CHECK_EQ(C(5), probe_rd(TSU_BASE + TSU_R_ID, &v), 0u);
  CHECK_EQ(C(6), v, TSU_ID_VALUE);
  /* clock gating: the tensor unit's free-running CYCLES counter stops while gated */
  uint32_t g0 = PMU(CC_PMU_GATED_CYC), k0 = tsu_counter(TSU_PC_CYCLES);
  PMU(CC_PMU_ACC_CTRL) = 0x0u;                            /* CLK_EN = 0 */
  uint32_t t0 = cycles();
  while (cycles() - t0 < 3000u) {}
  CHECK_EQ(C(7), PMU(CC_PMU_ACC_STATUS) & 0x1u, 0u);      /* clock off */
  PMU(CC_PMU_ACC_CTRL) = 0x1u;
  while (PMU(CC_PMU_ACC_STATUS) & 0x4u) {}
  uint32_t k1 = tsu_counter(TSU_PC_CYCLES), g1 = PMU(CC_PMU_GATED_CYC);
  CHECK_TRUE(C(8), g1 - g0 >= 2500u);
  CHECK_TRUE(C(9), (k1 - k0) < (cycles() - t0) - 2500u);  /* the unit saw >= 2500 fewer cycles */
  cprintf("  gated %u cycles; tensor unit counted %u of %u\n", g1 - g0, k1 - k0, cycles() - t0);
  t_end();
}

/* ============================================================== T15 watchdog reset (destructive) */
static void t_wdt_reset(void) {
  t_begin(15, "watchdog timeout -> system reset");
  SYSCTRL(CC_SYSCTRL_SCRATCH0) = SCRATCH_WDT_MARK;
  SYSCTRL(CC_SYSCTRL_SCRATCH2) = 0u;
  WDT(CC_WDT_PRESCALE) = 15u;
  WDT(CC_WDT_LOAD) = 2000u;
  WDT(CC_WDT_EWI_THRESH) = 500u;
  wdt_service();
  g_wdt_hang = 1;
  cprintf("  watchdog armed (32k cycles), service stopped\n");
  WAIT_UNTIL(0, 2000000u);
  CHECK_TRUE(C(1), 0);                                    /* still running: the reset did not happen */
  g_wdt_hang = 0;
  t_end();
}

uint32_t selftest_run(uint32_t mask) {
  tally_t start = g_tally;
  boot_stage(CC_BOOT_STAGE_SELF_TEST);
  cprintf("== self-test mask %08x ==\n", mask);
  if (mask & ST_IDENTITY) t_identity();
  if (mask & ST_MMIO) t_mmio();
  if (mask & ST_EXCEPT) t_except();
  if (mask & ST_TIMER) t_timer();
  if (mask & ST_INTC) t_intc();
  if (mask & ST_DMA) t_dma();
  if (mask & ST_VECTOR) t_vector();
  if (mask & ST_TENSOR) t_tensor();
  if (mask & ST_CONCUR) t_concur();
  if (mask & ST_ERRORS) t_errors();
  if (mask & ST_RAS) t_ras();
  if (mask & ST_PERF) t_perf();
  if (mask & ST_WDT) t_wdt();
  if (mask & ST_PMU) t_pmu();
  if (mask & ST_WDT_RESET) t_wdt_reset();
  uint32_t f = g_tally.fails - start.fails;
  cprintf("== self-test done: checks=%u fails=%u %s ==\n", g_tally.checks - start.checks, f, f ? "FAIL" : "PASS");
  return f;
}
