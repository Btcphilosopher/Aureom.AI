#!/usr/bin/env python3
"""SilicaFlux ControlCore -- system regression runner.

Runs every scenario of tb/tb_cc_system.sv (ControlCore + real vector tile + real
tensor unit, firmware on the RTL CPU) in parallel, parses each log and writes
reports/regression.md and reports/regression.json.  Exit status 0 only if every
run printed "TB RESULT PASS".
"""
import argparse
import concurrent.futures as cf
import datetime
import json
import os
import re
import subprocess
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

MATRIX = [  # (scenario, back-pressure %, seed, description)
    ("boot_host", 0, 1, "host loads firmware; full self-test suite; host GEMM/vector/DMA commands; RAS; telemetry"),
    ("boot_host", 40, 7, "same, 40 % random back-pressure on device memory"),
    ("boot_ext", 0, 1, "ROM DMA-copies the image from device memory; self-test subset; host GEMM"),
    ("boot_ext", 25, 3, "same, 25 % back-pressure"),
    ("bad_image", 0, 1, "corrupted image rejected (CRC), corrected image accepted, host reset -> cold boot"),
    ("wdt_reset", 0, 1, "watchdog early warning, timeout reset, warm boot without the host, recovery"),
]


def run(sim, fw, scen, bp, seed, timeout):
    log = os.path.join(ROOT, "reports", "sim", f"{scen}_bp{bp}_s{seed}.log")
    t0 = time.time()
    with open(log, "w") as f:
        p = subprocess.run([sim, f"+scenario={scen}", f"+fw={fw}", f"+bp={bp}", f"+seed={seed}",
                            f"+timeout={timeout}"], stdout=f, stderr=subprocess.STDOUT, cwd=ROOT)
    wall = time.time() - t0
    txt = open(log).read()
    m = re.search(r"TB RESULT (PASS|FAIL) scenario=(\S+) cycles=(\d+)", txt)
    sd = re.search(r"SHUTDOWN: firmware checks=(\d+) fails=(\d+)", txt)
    return {
        "scenario": scen, "bp": bp, "seed": seed, "rc": p.returncode,
        "result": m.group(1) if m else "FAIL", "cycles": int(m.group(3)) if m else None,
        "fw_checks": int(sd.group(1)) if sd else None, "fw_fails": int(sd.group(2)) if sd else None,
        "tb_checks_ok": txt.count("TB check ok"), "tb_checks_fail": txt.count("TB CHECK FAIL"),
        "wall_s": round(wall, 1), "log": os.path.relpath(log, ROOT),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", required=True)
    ap.add_argument("--fw", required=True)
    ap.add_argument("--scenarios", nargs="*")
    ap.add_argument("--jobs", type=int, default=os.cpu_count())
    ap.add_argument("--timeout", type=int, default=40_000_000)
    a = ap.parse_args()
    os.makedirs(os.path.join(ROOT, "reports", "sim"), exist_ok=True)
    mat = [m for m in MATRIX if not a.scenarios or m[0] in a.scenarios]
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda m: run(os.path.abspath(a.sim), a.fw, m[0], m[1], m[2], a.timeout), mat))
    ver = subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip()
    gcc = subprocess.run(["riscv64-unknown-elf-gcc", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    fwinfo = json.load(open(os.path.join(ROOT, "firmware", "build", "fw", "controlcore_fw.json")))
    npass = sum(r["result"] == "PASS" for r in res)
    md = ["# System regression (ControlCore + vector tile + tensor unit, firmware on the RTL CPU)", "",
          f"Generated {datetime.datetime.now(datetime.timezone.utc):%Y-%m-%d %H:%M} UTC by `scripts/regress.py`. Simulator: {ver}. "
          f"Firmware: {gcc}; image {fwinfo['size']} B, CRC32 {fwinfo['crc32']}.", "",
          f"**{npass} / {len(res)} runs PASS.**", "",
          "| Scenario | Back-pressure | Seed | Result | RTL cycles | Firmware checks (fails) | Testbench checks ok / fail | Wall time | Log |",
          "|---|---|---|---|---|---|---|---|---|"]
    for r, m in zip(res, mat):
        fwc = f"{r['fw_checks']} ({r['fw_fails']})" if r["fw_checks"] is not None else "-"
        md.append(f"| {r['scenario']} | {r['bp']} % | {r['seed']} | **{r['result']}** | {r['cycles']} | {fwc} | "
                  f"{r['tb_checks_ok']} / {r['tb_checks_fail']} | {r['wall_s']} s | `{r['log']}` |")
    md += ["", "Scenario descriptions:", ""]
    for m in mat:
        md.append(f"* **{m[0]}** (bp {m[1]} %): {m[3]}")
    md.append("")
    with open(os.path.join(ROOT, "reports", "regression.md"), "w") as f:
        f.write("\n".join(md))
    with open(os.path.join(ROOT, "reports", "regression.json"), "w") as f:
        json.dump(res, f, indent=1)
    for r in res:
        print(f"{r['result']}  {r['scenario']:<10} bp={r['bp']:<3} cycles={r['cycles']} fw={r['fw_checks']}/{r['fw_fails']} "
              f"tb_ok={r['tb_checks_ok']} tb_fail={r['tb_checks_fail']} {r['wall_s']}s")
    print(f"regress: {npass}/{len(res)} PASS")
    raise SystemExit(0 if npass == len(res) else 1)


if __name__ == "__main__":
    main()
