#!/usr/bin/env python3
"""Collect the final results of every gate into reports/SUMMARY.md."""
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "reports")


def rd(p):
    p = os.path.join(R, p)
    return open(p, errors="replace").read() if os.path.exists(p) else ""


def first(pat, txt, default="n/a"):
    m = re.search(pat, txt)
    return m.group(1) if m else default


def main():
    rows = []
    reg = json.loads(rd("regression.json") or "[]")
    npass = sum(r["result"] == "PASS" for r in reg)
    rows.append(("System regression (ControlCore + vector tile + tensor unit)", f"{npass} / {len(reg)} PASS",
                 "regression.md"))
    fw = [r for r in reg if r["fw_checks"]]
    rows.append(("Firmware checks executed on the RTL (all runs)", f"{sum(r['fw_checks'] for r in fw)} checks, "
                 f"{sum(r['fw_fails'] for r in fw)} fails", "sim/*.log"))
    rows.append(("Testbench (host-side) checks", f"{sum(r['tb_checks_ok'] for r in reg)} ok, "
                 f"{sum(r['tb_checks_fail'] for r in reg)} fail", "regression.md"))
    rows.append(("cocotb unit tests", first(r"\*\*(\d+ / \d+) PASS\*\*", rd("unit.md")) + " PASS", "unit.md"))
    isa = rd("isa/riscv_tests_m1.txt")
    rows.append(("riscv-tests on the CPU (RV32M = 1)", first(r"TOTAL (pass=\d+ fail=\d+)", isa), "isa/riscv_tests_m1.txt"))
    lint = rd("lint.md")
    rows.append(("Lint / elaboration gates", f"{lint.count('**PASS**')} / {lint.count('**PASS**') + lint.count('**FAIL**')} PASS",
                 "lint.md"))
    rows.append(("Address-map validator", first(r"\*\*(\d+ / \d+) PASS\*\*", rd("memmap_tests.md")) + " PASS",
                 "memmap_tests.md"))
    rows.append(("Vendored files identical to the repository archives", first(r"check_vendor: (\d+ files, \d+ problems)",
                                                                              rd("vendor_run.log")), "vendor_run.log"))
    fpga = rd("fpga.md")
    rows.append(("FPGA post-route Fmax estimate (ULX3S 85F, ControlCore harness)",
                 first(r"estimate: ([\d.]+ MHz -- \w+ at the [\d.]+ MHz constraint)", fpga), "fpga.md"))
    rows.append(("FPGA utilisation (TRELLIS_COMB / FF / DP16KD)",
                 " / ".join(first(rf"\| {n} \| (\d+) \| \d+ \|", fpga) for n in ("TRELLIS_COMB", "TRELLIS_FF", "DP16KD")),
                 "fpga.md"))
    rows.append(("FPGA harness RTL simulation", first(r"TB_FPGA RESULT (\w+)", rd("sim/fpga_harness.log")),
                 "sim/fpga_harness.log"))
    md = ["# Results summary (final run on the frozen sources)", "",
          "Every number is copied from the tool output named in the last column (`reports/`).", "",
          "| Gate | Result | Source |", "|---|---|---|"] + [f"| {a} | **{b}** | `{c}` |" for a, b, c in rows]
    md += ["", "Not performed: FPGA board run, gate-level simulation, formal proof of the new RTL, RISC-V "
           "architectural compliance tests, firmware authentication (not implemented). See docs/09_LIMITATIONS.md.", ""]
    open(os.path.join(R, "SUMMARY.md"), "w").write("\n".join(md))
    print("\n".join(md))


if __name__ == "__main__":
    main()
