#!/usr/bin/env python3
"""SilicaFlux ControlCore -- address-map generator and validator.

    gen_memmap.py [--check]

Reads config/cc_memmap.yaml (the single source of truth), validates it and
writes the SystemVerilog package, the C header, the Python constants module and
docs/MEMORY_MAP.md.  With --check nothing is written: the script fails if any
generated file is missing or stale (used by `make check`).

Validation (every failure is fatal):
  * region base aligned to its size, size a power of two, no region overlap
  * EXT sub-regions aligned and inside EXT, no overlap between them
  * PERIPH window = 32 pages of page_size; page numbers unique and in range
  * register offsets 4-byte aligned, < page_size, unique within a block
  * IRQ ids unique and < 16; enumeration values unique within an enum
  * access-matrix names exist; every region slave index unique
  * reused blocks: offsets equal the vendored MCU-I package
    (third_party/silicaflux-mcu-i/rtl/generated/mcu_memmap_pkg.sv)
"""
import argparse
import os
import re
import sys

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = os.path.join(ROOT, "config", "cc_memmap.yaml")
OUT_SV = os.path.join(ROOT, "rtl", "generated", "cc_memmap_pkg.sv")
OUT_SVH = os.path.join(ROOT, "rtl", "generated", "cc_memmap_defs.svh")
OUT_H = os.path.join(ROOT, "firmware", "include", "generated", "cc_memmap.h")
OUT_PY = os.path.join(ROOT, "scripts", "generated", "cc_memmap.py")
OUT_MD = os.path.join(ROOT, "docs", "MEMORY_MAP.md")
OUT_LD = os.path.join(ROOT, "firmware", "include", "generated", "cc_memory.ld")
MCU_PKG = os.path.join(ROOT, "third_party", "silicaflux-mcu-i", "rtl", "generated", "mcu_memmap_pkg.sv")

errors = []


def err(msg):
    errors.append(msg)


def pow2(x):
    return x > 0 and (x & (x - 1)) == 0


def overlap(a, b):
    return a["base"] < b["base"] + b["size"] and b["base"] < a["base"] + a["size"]


def block_prefix(block):
    return {"cc_sysctrl": "SYSCTRL", "cc_mailbox": "MBOX", "cc_perf": "PERF", "cc_pmu": "PMU",
            "cc_ras": "RAS", "cc_secmon": "SEC", "mcu_intc": "INTC", "mcu_wdt": "WDT",
            "mcu_dma": "DMA", "sfv_timer": "MTIMER"}[block]


def validate(m):
    regs = m["regions"]
    for r in regs:
        if not pow2(r["size"]):
            err(f"region {r['name']}: size 0x{r['size']:x} is not a power of two")
        if r["base"] % r["size"]:
            err(f"region {r['name']}: base 0x{r['base']:08x} not aligned to size 0x{r['size']:x}")
        if r["base"] + r["size"] > 1 << 32:
            err(f"region {r['name']}: exceeds the 32-bit space")
    for i, a in enumerate(regs):
        for b in regs[i + 1:]:
            if overlap(a, b):
                err(f"regions {a['name']} and {b['name']} overlap")
    slaves = [r["slave"] for r in regs]
    if sorted(slaves) != list(range(len(slaves))):
        err(f"region slave indices must be 0..{len(slaves)-1} exactly once: {slaves}")
    ext = next(r for r in regs if r["name"] == "EXT")
    subs = m["ext_subregions"]
    for s in subs:
        if not pow2(s["size"]) or s["base"] % s["size"]:
            err(f"ext sub-region {s['name']}: base/size not aligned")
        if s["base"] < ext["base"] or s["base"] + s["size"] > ext["base"] + ext["size"]:
            err(f"ext sub-region {s['name']} not inside EXT")
    for i, a in enumerate(subs):
        for b in subs[i + 1:]:
            if overlap(a, b):
                err(f"ext sub-regions {a['name']} and {b['name']} overlap")
    per = next(r for r in regs if r["name"] == "PERIPH")
    ps = m["page_size"]
    if per["size"] != 32 * ps:
        err("PERIPH must be exactly 32 pages (sfv_periph_bridge decodes addr[16:12])")
    seen = set()
    for p in m["pages"]:
        if p["page"] in seen:
            err(f"page {p['page']} defined twice")
        seen.add(p["page"])
        if not 0 <= p["page"] < 32:
            err(f"page {p['name']}: number out of range")
        if p.get("forwarded") and not 8 <= p["page"] <= 15:
            err(f"page {p['name']}: only pages 8..15 can be forwarded to the accelerator port")
    names = {r["name"] for r in regs}
    mnames = {mm["name"] for mm in m["masters"]}
    for mname, lst in m["access"].items():
        if mname not in mnames:
            err(f"access: unknown master {mname}")
        for rn in lst:
            if rn not in names:
                err(f"access: {mname} -> unknown region {rn}")
    for bname, blk in m["blocks"].items():
        offs = set()
        for r in blk["regs"]:
            o = r["ofs"]
            if o % 4 or o >= ps:
                err(f"{bname}.{r['name']}: offset 0x{o:x} misaligned or outside the page")
            if o in offs:
                err(f"{bname}.{r['name']}: duplicate offset 0x{o:x}")
            offs.add(o)
    ids = [q["id"] for q in m["irqs"]]
    if len(set(ids)) != len(ids) or max(ids) >= 16:
        err("irq ids must be unique and < 16")
    for en, vals in m["enums"].items():
        if len(set(vals.values())) != len(vals):
            err(f"enum {en}: duplicate values")
    # reused blocks vs vendored MCU-I package
    pkg = open(MCU_PKG).read()
    pv = {k: int(v.replace("_", ""), 16) for k, v in
          re.findall(r"localparam\s+logic\s+\[\d+:0\]\s+(\w+)\s*=\s*\d+'h([0-9A-Fa-f_]+);", pkg)}
    for bname, blk in m["blocks"].items():
        pre = blk.get("reused_pkg_prefix")
        if not pre:
            continue
        for r in blk["regs"]:
            key = pre + r["name"]
            if key not in pv:
                err(f"{bname}.{r['name']}: {key} not found in mcu_memmap_pkg")
            elif pv[key] != r["ofs"]:
                err(f"{bname}.{r['name']}: 0x{r['ofs']:x} != mcu_memmap_pkg {key} 0x{pv[key]:x}")
    for k in ("WDT_KEY1", "WDT_KEY2", "DMA_ID_VALUE"):
        if k not in pv:
            err(f"mcu_memmap_pkg: {k} missing")
    return pv


def gen(m, pv):
    ver = (m["map_version"]["major"] << 16) | m["map_version"]["minor"]
    regs = m["regions"]
    items = []   # (name, value, width, comment)
    items.append(("CC_MAP_VERSION", ver, 32, f"address map v{m['map_version']['major']}.{m['map_version']['minor']}"))
    for r in regs:
        items.append((f"CC_{r['name']}_BASE", r["base"], 32, r["desc"]))
        items.append((f"CC_{r['name']}_SIZE", r["size"], 32, ""))
    for s in m["ext_subregions"]:
        items.append((f"CC_{s['name']}_BASE", s["base"], 32, s["desc"]))
        items.append((f"CC_{s['name']}_SIZE", s["size"], 32, ""))
    per = next(r for r in regs if r["name"] == "PERIPH")
    items.append(("CC_PAGE_SIZE", m["page_size"], 32, ""))
    for p in m["pages"]:
        items.append((f"CC_PG_{p['name']}", p["page"], 32, p["desc"]))
        items.append((f"CC_{p['name']}_BASE", per["base"] + p["page"] * m["page_size"], 32, ""))
    for mm in m["masters"]:
        items.append((f"CC_M_{mm['name']}", mm["id"], 32, mm["desc"]))
    for r in regs:
        items.append((f"CC_S_{r['name']}", r["slave"], 32, ""))
    for q in m["irqs"]:
        items.append((f"CC_IRQ_{q['name']}", q["id"], 32, q["desc"]))
        items.append((f"CC_IRQ_{q['name']}_PRIO", q["prio"], 32, "recommended priority"))
    for bname, blk in m["blocks"].items():
        pre = block_prefix(bname)
        for r in blk["regs"]:
            items.append((f"CC_{pre}_{r['name']}", r["ofs"], 12, r.get("desc", "")))
            if "reset" in r:
                items.append((f"CC_{pre}_{r['name']}_RST", r["reset"], 32, ""))
    for ename, vals in m["enums"].items():
        for k, v in vals.items():
            items.append((f"CC_{ename}_{k}", v, 32, ""))
    for k, v in m["constants"].items():
        items.append((f"CC_{k}", v, 32, ""))
    items.append(("CC_WDT_KEY1", pv["WDT_KEY1"], 32, "from mcu_memmap_pkg"))
    items.append(("CC_WDT_KEY2", pv["WDT_KEY2"], 32, "from mcu_memmap_pkg"))
    items.append(("CC_DMA_ID_VALUE", pv["DMA_ID_VALUE"], 32, "from mcu_memmap_pkg"))

    # crossbar parameters derived from the regions
    nm, ns = len(m["masters"]), len(regs)
    base = mask = 0
    for r in regs:
        base |= r["base"] << (32 * r["slave"])
        mask |= ((~(r["size"] - 1)) & 0xFFFFFFFF) << (32 * r["slave"])
    en = 0
    slave_of = {r["name"]: r["slave"] for r in regs}
    for mm in m["masters"]:
        for rn in m["access"][mm["name"]]:
            en |= 1 << (mm["id"] * ns + slave_of[rn])
    page_en = 0
    for p in m["pages"]:
        page_en |= 1 << p["page"]
    fwd = 0
    for p in m["pages"]:
        if p.get("forwarded"):
            fwd |= 1 << p["page"]

    hdr = ("GENERATED by scripts/gen_memmap.py from config/cc_memmap.yaml -- DO NOT EDIT\n"
           f"SilicaFlux ControlCore address map v{m['map_version']['major']}.{m['map_version']['minor']}")

    # ---- SystemVerilog
    sv = [f"// {l}" for l in hdr.splitlines()]
    sv += ["`default_nettype none", "package cc_memmap_pkg;"]
    for n, v, w, c in items:
        cm = f"  // {c}" if c else ""
        sv.append(f"  localparam logic [{w-1}:0] {n} = {w}'h{v:0{(w+3)//4}x};{cm}")
    sv.append(f"  localparam int CC_XBAR_NM = {nm};")
    sv.append(f"  localparam int CC_XBAR_NS = {ns};")
    sv.append(f"  localparam logic [{ns*32-1}:0] CC_XBAR_BASE = {ns*32}'h{base:0{ns*8}x};")
    sv.append(f"  localparam logic [{ns*32-1}:0] CC_XBAR_MASK = {ns*32}'h{mask:0{ns*8}x};")
    sv.append(f"  localparam logic [{nm*ns-1}:0] CC_XBAR_EN = {nm*ns}'h{en:0{(nm*ns+3)//4}x};")
    sv.append(f"  localparam logic [31:0] CC_PAGE_EN = 32'h{page_en:08x};")
    sv.append(f"  localparam logic [31:0] CC_PAGE_FWD = 32'h{fwd:08x};")
    sv += ["endpackage", "`default_nettype wire", ""]
    # the same constants as module-local localparams, for tools without package
    # wildcard imports (Yosys 0.33): `include "cc_memmap_defs.svh" inside a module
    svh = [f"// {l}" for l in hdr.splitlines()] + ["// Module-scope copy of cc_memmap_pkg (include INSIDE a module body; no guard)."]
    svh += [l for l in sv if l.startswith("  localparam")]
    svh.append("")

    # ---- C
    h = ["/*"] + [f" * {l}" for l in hdr.splitlines()] + [" */", "#ifndef CC_MEMMAP_H", "#define CC_MEMMAP_H", "",
         "#ifdef __ASSEMBLER__", "#define CC_U(x) x", "#else", "#define CC_U(x) x##u", "#endif", ""]
    for n, v, w, c in items:
        cm = f"  /* {c} */" if c and len(c) < 100 else ""
        h.append(f"#define {n:<34} CC_U(0x{v:08X}){cm}")
    h += ["", f"#define CC_PAGE_EN                         CC_U(0x{page_en:08X})",
          f"#define CC_PAGE_FWD                        CC_U(0x{fwd:08X})",
          "#define CC_REG(base, off) (*(volatile unsigned int *)((base) + (off)))",
          "", "#endif /* CC_MEMMAP_H */", ""]

    # ---- Python
    py = [f"# {l}" for l in hdr.splitlines()]
    for n, v, w, c in items:
        py.append(f"{n} = 0x{v:08X}")
    py += [f"CC_PAGE_EN = 0x{page_en:08X}", f"CC_PAGE_FWD = 0x{fwd:08X}", ""]

    # ---- Markdown
    md = [f"# ControlCore address map v{m['map_version']['major']}.{m['map_version']['minor']}", "",
          "> GENERATED by `scripts/gen_memmap.py` from `config/cc_memmap.yaml` (the single source of truth). "
          "Do not edit; edit the YAML and run `make memmap`. The same run produces "
          "`rtl/generated/cc_memmap_pkg.sv`, `firmware/include/generated/cc_memmap.h` and "
          "`scripts/generated/cc_memmap.py`, and fails on misalignment, overlaps or a mismatch with the reused "
          "MCU-I register package.", "",
          "Byte addresses, little-endian, 32-bit registers (word accesses only on the register pages).", "",
          "## Regions (ControlCore crossbar)", "", "| Region | Base | Last | Size | Description |", "|---|---|---|---|---|"]
    for r in sorted(regs, key=lambda r: r["base"]):
        md.append(f"| {r['name']} | `0x{r['base']:08X}` | `0x{r['base']+r['size']-1:08X}` | {fmt_size(r['size'])} | {r['desc']} |")
    md += ["", "Everything else is unmapped: an access returns a bus error (load/store/instruction access fault) "
           "and is logged by RAS (`BUS_DECODE`).", "",
           "### Inside EXT (reference accelerator system)", "", "| Sub-region | Base | Size | Description |", "|---|---|---|---|"]
    for s in m["ext_subregions"]:
        md.append(f"| {s['name']} | `0x{s['base']:08X}` | {fmt_size(s['size'])} | {s['desc']} |")
    md += ["", "## Access matrix", "", "| Master | " + " | ".join(r["name"] for r in sorted(regs, key=lambda r: r["slave"])) + " |",
           "|---|" + "---|" * len(regs)]
    for mm in m["masters"]:
        row = [("yes" if r["name"] in m["access"][mm["name"]] else "-") for r in sorted(regs, key=lambda r: r["slave"])]
        md.append(f"| {mm['name']} ({mm['desc']}) | " + " | ".join(row) + " |")
    md += ["", "## Register pages (PERIPH, 4 KiB each)", "", "| Page | Base | Name | Block | Description |", "|---|---|---|---|---|"]
    for p in m["pages"]:
        fw = " (forwarded to the accelerator register port)" if p.get("forwarded") else ""
        ru = " (reused, unmodified)" if p.get("reused") else ""
        md.append(f"| {p['page']} | `0x{per['base']+p['page']*m['page_size']:08X}` | {p['name']} | `{p['block']}`{ru} | {p['desc']}{fw} |")
    md += ["", "Pages not listed (18..31) answer every access with a bus error.", "",
           "## Interrupts (INTC sources -> CPU MEI)", "", "| Id | Name | Recommended priority | Source |", "|---|---|---|---|"]
    for q in m["irqs"]:
        md.append(f"| {q['id']} | {q['name']} | {q['prio']} | {q['desc']} |")
    md += ["", "CPU-level interrupts: " + "; ".join(f"{c['name']} (mcause {c['mcause']}): {c['desc']}" for c in m["cpu_irqs"]), ""]
    for bname, blk in m["blocks"].items():
        md += [f"## Block `{bname}` (prefix `CC_{block_prefix(bname)}_`)", "", "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
        for r in blk["regs"]:
            rs = f"`0x{r['reset']:08X}`" if "reset" in r else ""
            md.append(f"| `0x{r['ofs']:03X}` | {r['name']} | {r['access']} | {rs} | {r.get('desc', '')} |")
        md.append("")
    md += ["## Enumerations", ""]
    for ename, vals in m["enums"].items():
        md.append(f"* **{ename}**: " + ", ".join(f"{k} = 0x{v:X}" for k, v in vals.items()))
    md += ["", "## Constants", ""]
    for k, v in m["constants"].items():
        md.append(f"* `CC_{k}` = `0x{v:X}`")
    md += ["", "## Crossbar parameters (derived)", "",
           f"* `CC_XBAR_BASE` = `{ns*32}'h{base:0{ns*8}x}`", f"* `CC_XBAR_MASK` = `{ns*32}'h{mask:0{ns*8}x}`",
           f"* `CC_XBAR_EN` (bit m*NS+s) = `{nm*ns}'h{en:x}`", f"* `CC_PAGE_EN` = `32'h{page_en:08x}`, "
           f"`CC_PAGE_FWD` = `32'h{fwd:08x}`", ""]
    ld = [f"/* {l} */" for l in hdr.splitlines()] + ["MEMORY", "{"]
    for r in regs:
        if r["kind"] in ("rom", "sram"):
            attr = {"BOOTROM": "rx", "IMEM": "rwx", "DMEM": "rw"}[r["name"]]
            ld.append(f"  {r['name']} ({attr}) : ORIGIN = 0x{r['base']:08X}, LENGTH = 0x{r['size']:X}")
    ld += ["}", f"CC_IMAGE_HDR_BYTES = 0x{m['constants']['IMAGE_HDR_BYTES']:X};", ""]
    return {OUT_SV: "\n".join(sv), OUT_SVH: "\n".join(svh), OUT_H: "\n".join(h), OUT_PY: "\n".join(py), OUT_MD: "\n".join(md),
            OUT_LD: "\n".join(ld)}


def fmt_size(s):
    for u, n in (("MiB", 1 << 20), ("KiB", 1 << 10)):
        if s >= n and s % n == 0:
            return f"{s // n} {u}"
    return f"{s} B"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    m = yaml.safe_load(open(CFG))
    pv = validate(m)
    if errors:
        for e in errors:
            print("gen_memmap: ERROR:", e)
        sys.exit(1)
    outs = gen(m, pv)
    stale = []
    for path, text in outs.items():
        if a.check:
            if not os.path.exists(path) or open(path).read() != text:
                stale.append(os.path.relpath(path, ROOT))
        else:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                f.write(text)
    if stale:
        print("gen_memmap: STALE:", ", ".join(stale))
        sys.exit(1)
    print(f"gen_memmap: map v{m['map_version']['major']}.{m['map_version']['minor']} OK: "
          f"{len(m['regions'])} regions, {len(m['pages'])} pages, "
          f"{sum(len(b['regs']) for b in m['blocks'].values())} registers, {len(m['irqs'])} IRQs"
          + (" (generated files up to date)" if a.check else " -> generated"))


if __name__ == "__main__":
    main()
