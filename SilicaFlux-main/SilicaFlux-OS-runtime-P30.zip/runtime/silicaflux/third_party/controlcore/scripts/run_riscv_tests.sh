#!/usr/bin/env bash
# =============================================================================
# SilicaFlux ControlCore :: riscv-tests ISA suites on the ControlCore CPU
#
# usage: scripts/run_riscv_tests.sh <RV32M: 0|1|2> [RISCV_TESTS_DIR]
#
# Re-runs, in this environment, the evidence MCU-I recorded for the CPU the
# ControlCore instantiates: third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv
# (vendored unmodified) on the vendored MCU-I harness tb/cpu/tb_cpu.sv, with
# the riscv-software-src/riscv-tests self-checking suites (rv32ui, rv32um,
# rv32mi) under 3 bus profiles (grant %: max response latency) x 2 seeds.
# The ControlCore uses RV32M = 1 (iterative multiply/divide).
# Derived from MCU-I scripts/run_riscv_tests.sh (paths, report location).
#
# These are NOT the RISC-V International architectural tests (riscv-arch-test);
# passing them is not a claim of RISC-V compliance or certification.
# Excluded (documented): rv32ui/ma_data (misaligned access traps by design),
# rv32mi/pmpaddr (no PMP), rv32mi/breakpoint (no trigger module).
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
M="${1:-1}"
RT="${2:-${RISCV_TESTS:-$ROOT/deps/riscv-tests}}"
OUT="$ROOT/build/riscv-tests/m$M"; mkdir -p "$OUT"
REPORT="$ROOT/reports/isa/riscv_tests_m$M.txt"; mkdir -p "$(dirname "$REPORT")"
PREFIX="${RISCV_PREFIX:-riscv64-unknown-elf-}"
PROFILES="${PROFILES:-100:1 70:2 40:4}"
SEEDS="${SEEDS:-1 2}"

if [ ! -d "$RT/isa" ]; then
  echo "fetching riscv-tests into $RT"
  git clone -q https://github.com/riscv-software-src/riscv-tests "$RT" && git -C "$RT" submodule update --init -q env \
    || { echo "ERROR: cannot fetch riscv-tests"; exit 2; }
fi
if [ "$M" = 0 ]; then MARCH=rv32i_zicsr_zifencei; SUITES="rv32ui rv32mi";
else MARCH=rv32im_zicsr_zifencei; SUITES="rv32ui rv32um rv32mi"; fi
CFLAGS="-march=$MARCH -mabi=ilp32 -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles"

SIMDIR="$OUT/obj_dir"
verilator --binary --timing -Wno-fatal -Wno-WIDTH -O2 --top-module tb_cpu -GRV32M=$M \
  -Mdir "$SIMDIR" -o vtb_cpu "$ROOT/third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv" \
  "$ROOT/third_party/silicaflux-mcu-i/tb/cpu/tb_cpu.sv" > "$OUT/verilator_build.log" 2>&1 \
  || { tail -30 "$OUT/verilator_build.log"; exit 1; }
SIM="$SIMDIR/vtb_cpu"
SKIP=" rv32ui/ma_data rv32mi/pmpaddr rv32mi/breakpoint "

pass=0; fail=0; : > "$REPORT"
{
  echo "# riscv-tests on mcu_cpu RV32M=$M (the ControlCore CPU)  ($(date -u +%F' '%T) UTC)"
  echo "# riscv-tests commit: $(git -C "$RT" rev-parse HEAD 2>/dev/null)"
  echo "# toolchain: $(${PREFIX}gcc --version | head -1) ; -march=$MARCH -mabi=ilp32"
  echo "# simulator: $(verilator --version)"
  echo "# profiles (grant%:maxlatency): $PROFILES ; seeds: $SEEDS"
} >> "$REPORT"
for suite in $SUITES; do
  for src in "$RT"/isa/$suite/*.S; do
    t="$suite/$(basename "$src" .S)"
    case "$SKIP" in *" $t "*) echo "SKIP $t" >> "$REPORT"; continue;; esac
    elf="$OUT/${t//\//-}.elf"
    if ! ${PREFIX}gcc $CFLAGS -I"$RT/env/p" -I"$RT/isa/macros/scalar" -T"$RT/env/p/link.ld" \
         "$src" -o "$elf" > "$elf.log" 2>&1; then
      echo "BUILD-FAIL $t" | tee -a "$REPORT"; fail=$((fail+1)); continue
    fi
    ${PREFIX}objcopy -O binary "$elf" "$elf.bin"
    python3 "$ROOT/third_party/silicaflux-v/scripts/bin2hex.py" "$elf.bin" "$elf.hex" > /dev/null
    tohost=$(${PREFIX}nm "$elf" | awk '$3=="tohost"{print $1}')
    ok=1
    for prof in $PROFILES; do for seed in $SEEDS; do
      g=${prof%%:*}; l=${prof##*:}
      r=$("$SIM" +hex="$elf.hex" +tohost="$tohost" +gnt=$g +lat=$l +seed=$seed 2>&1 | grep "TB_CPU RESULT")
      case "$r" in *PASS*) ;; *) ok=0; echo "FAIL $t gnt=$g lat=$l seed=$seed : $r" >> "$REPORT";; esac
    done; done
    if [ $ok = 1 ]; then echo "PASS $t" >> "$REPORT"; pass=$((pass+1)); else echo "FAIL $t"; fail=$((fail+1)); fi
  done
done
echo "TOTAL pass=$pass fail=$fail" | tee -a "$REPORT"
[ $fail = 0 ]
