// =============================================================================
// SilicaFlux-HPC :: silicaflux_cc_hpc_system -- ControlCore + real accelerators
//
//   host ── hs_* ──► silicaflux_control_core ── acc_rb_* (pages 8, 9) ──► sfx_hpc_tensor_system (TENSORCORE 08,
//                         │  RV32IM firmware        ext_* (SFB2 master) ──► m0 host data port      unmodified)
//                         │                         acc_clk_o / acc_rst_no ─► clk / rst_n            ├─ silicaflux_hpc_tile
//                         ◄── tile_irq / tsu_irq / busy / tsu_halted ─────────────────────────────── ├─ silicaflux_tensor_unit
//                                                                                                   └─ sfb_crossbar ─► devmem (dm_*)
// Device address space (identical for the ControlCore and both accelerators):
//   CC_DEVMEM_BASE   0x2000_0000  shared device SRAM (DEVMEM_BYTES)     -> dm_* port (testbench / SoC memory)
//   CC_TILE_SPM_BASE 0x3000_0000  vector tile scratchpad (64 KiB)       -> tile host window
// The tensor unit's legal memory window is exactly the shared SRAM (MEM_LO/MEM_HI), as in TC08.
// Single clock: the accelerator subsystem runs on acc_clk_o, the ICG-gated copy
// of clk (cc_pmu); dm_* is synchronous to clk and idle while the gate is off.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module silicaflux_cc_hpc_system
#(
  parameter int RV32M        = 1,
  parameter int SRAM_PARITY  = 1,
  parameter int SRAM_BACKEND = `SRAM_BACKEND_GENERIC,
  parameter int DEVMEM_BYTES = 32'h0010_0000,
  parameter int TSU_QUANT    = 1,
  parameter int TSU_DBUF     = 1
) (
  input  wire logic        clk,
  input  wire logic        rst_ni,
  input  wire logic        test_mode,
  input  wire logic [1:0]  boot_mode_i,
  input  wire logic        host_rst_req_i,
  // host access port
  input  wire logic        hs_req_valid,
  output logic             hs_req_ready,
  input  wire logic        hs_req_write,
  input  wire logic [31:0] hs_req_addr,
  input  wire logic [31:0] hs_req_wdata,
  input  wire logic [3:0]  hs_req_wstrb,
  output logic             hs_rsp_valid,
  input  wire logic        hs_rsp_ready,
  output logic [31:0]      hs_rsp_rdata,
  output logic             hs_rsp_error,
  output logic             host_irq_o,
  output logic             host_ready_o,
  output logic             cmdproc_ready_o,
  output logic             ras_fatal_o,
  // shared device memory (SFB2 slave port of the accelerator fabric)
  output logic             dm_req_valid,
  input  wire logic        dm_req_ready,
  output logic             dm_req_write,
  output logic [31:0]      dm_req_addr,
  output logic [31:0]      dm_req_wdata,
  output logic [3:0]       dm_req_wstrb,
  input  wire logic        dm_rsp_valid,
  output logic             dm_rsp_ready,
  input  wire logic [31:0] dm_rsp_rdata,
  input  wire logic        dm_rsp_error,
  // SoC RAS inputs
  input  wire logic        ext_warn_i,
  input  wire logic        ext_fatal_i,
  // diagnostics
  output logic             diag_valid_o,
  output logic [7:0]       diag_char_o,
  output logic             test_done_o,
  output logic             test_fail_o,
  output logic [15:0]      test_code_o,
  output logic             cpu_sleep_o,
  output logic             acc_clk_o,
  output logic             tile_busy_o,
  output logic             tsu_busy_o
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  logic        acc_rb_sel, acc_rb_we, acc_rb_err, acc_rst_n;
  logic [15:0] acc_rb_addr;
  logic [31:0] acc_rb_wdata, acc_rb_rdata;
  logic        x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [31:0] x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [3:0]  x_req_wstrb;
  logic        tile_irq, tsu_irq, tile_busy, tsu_busy, tsu_halted;

  silicaflux_control_core #(.RV32M(RV32M), .SRAM_PARITY(SRAM_PARITY), .SRAM_BACKEND(SRAM_BACKEND)) u_cc (
    .clk, .rst_ni, .test_mode, .boot_mode_i, .host_rst_req_i,
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o, .host_ready_o, .cmdproc_ready_o, .ras_fatal_o,
    .acc_rb_sel, .acc_rb_we, .acc_rb_addr, .acc_rb_wdata, .acc_rb_rdata, .acc_rb_err,
    .ext_req_valid(x_req_valid), .ext_req_ready(x_req_ready), .ext_req_write(x_req_write), .ext_req_addr(x_req_addr),
    .ext_req_wdata(x_req_wdata), .ext_req_wstrb(x_req_wstrb), .ext_rsp_valid(x_rsp_valid), .ext_rsp_ready(x_rsp_ready),
    .ext_rsp_rdata(x_rsp_rdata), .ext_rsp_error(x_rsp_error),
    .acc_clk_o, .acc_rst_no(acc_rst_n),
    .acc_vec_irq_i(tile_irq), .acc_tsu_irq_i(tsu_irq), .acc_vec_busy_i(tile_busy), .acc_tsu_busy_i(tsu_busy),
    .acc_tsu_halted_i(tsu_halted),
    .ext_warn_i, .ext_fatal_i,
    .diag_valid_o, .diag_char_o, .test_done_o, .test_fail_o, .test_code_o, .cpu_sleep_o
  );

  /* verilator lint_off UNUSEDSIGNAL */
  logic [2:0] mon_stall_u, mon_acc_u, mon_loss_u;
  /* verilator lint_on UNUSEDSIGNAL */
  sfx_hpc_tensor_system #(
    .SRAM_BASE(CC_DEVMEM_BASE), .SRAM_BYTES(DEVMEM_BYTES), .SPM_BASE(CC_TILE_SPM_BASE), .SPM_BYTES(CC_TILE_SPM_SIZE),
    .TSU_QUANT(TSU_QUANT), .TSU_DBUF(TSU_DBUF)
  ) u_acc (
    .clk(acc_clk_o), .rst_n(acc_rst_n),
    .rb_sel(acc_rb_sel), .rb_we(acc_rb_we), .rb_addr(acc_rb_addr), .rb_wdata(acc_rb_wdata),
    .rb_rdata(acc_rb_rdata), .rb_err(acc_rb_err),
    .h_req_valid(x_req_valid), .h_req_ready(x_req_ready), .h_req_write(x_req_write), .h_req_addr(x_req_addr),
    .h_req_wdata(x_req_wdata), .h_req_wstrb(x_req_wstrb), .h_rsp_valid(x_rsp_valid), .h_rsp_ready(x_rsp_ready),
    .h_rsp_rdata(x_rsp_rdata), .h_rsp_error(x_rsp_error),
    .s_req_valid(dm_req_valid), .s_req_ready(dm_req_ready), .s_req_write(dm_req_write), .s_req_addr(dm_req_addr),
    .s_req_wdata(dm_req_wdata), .s_req_wstrb(dm_req_wstrb), .s_rsp_valid(dm_rsp_valid), .s_rsp_ready(dm_rsp_ready),
    .s_rsp_rdata(dm_rsp_rdata), .s_rsp_error(dm_rsp_error),
    .tile_irq, .tsu_irq, .tile_busy, .tsu_busy, .tsu_halted,
    .mon_req_stall(mon_stall_u), .mon_req_accept(mon_acc_u), .mon_arb_loss(mon_loss_u)
  );
  assign tile_busy_o = tile_busy;
  assign tsu_busy_o  = tsu_busy;
endmodule

`default_nettype wire
