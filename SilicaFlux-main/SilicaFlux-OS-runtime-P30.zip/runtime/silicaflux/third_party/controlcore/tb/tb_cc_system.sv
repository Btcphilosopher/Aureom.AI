// =============================================================================
// SilicaFlux ControlCore :: tb_cc_system -- firmware-level system testbench
//
// DUT: integration/silicaflux_cc_hpc_system (ControlCore + the real vector tile
// and tensor unit).  The testbench plays two roles only:
//   * the HOST: an SFB2 master on the host access port (loads the firmware
//     image, uses the mailbox, reads status) and the host reset pin;
//   * the shared DEVICE MEMORY: an SFB2 slave model (1 MiB at CC_DEVMEM_BASE)
//     with optional random back-pressure and a 4 KiB "poison" window that
//     answers with errors (CC_TB_POISON_BASE), for error-path tests.
// Everything else -- boot, accelerator programming, interrupts, checking -- is
// done by the real boot ROM and firmware running on the RTL CPU.
//
// Plusargs: +scenario=boot_host|boot_ext|bad_image|wdt_reset  +fw=<image.hex>
//           +timeout=<cycles> +bp=<0..90 % back-pressure on device memory> +seed=<n>
// Result:   "TB RESULT PASS|FAIL scenario=... cycles=..." (exit status 0 / 1)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_cc_system;
  import cc_memmap_pkg::*;

  // ------------------------------------------------------------------ clock / reset
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  string   scenario, fw_path;
  longint  timeout;
  int      bp_pct, seed, tb_fails = 0;
  logic [31:0] stmask;
  logic [1:0] boot_mode = 2'b00;
  logic    host_rst = 1'b0, ext_warn = 1'b0, ext_fatal = 1'b0;

  // ------------------------------------------------------------------ DUT
  logic        hs_req_valid = 1'b0, hs_req_ready, hs_req_write = 1'b0, hs_rsp_valid, hs_rsp_error;
  logic [31:0] hs_req_addr = '0, hs_req_wdata = '0, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb = 4'hF;
  logic        host_irq, host_ready, cmdproc_ready, ras_fatal;
  logic        dm_req_valid, dm_req_ready, dm_req_write, dm_rsp_valid, dm_rsp_ready, dm_rsp_error;
  logic [31:0] dm_req_addr, dm_req_wdata, dm_rsp_rdata;
  logic [3:0]  dm_req_wstrb;
  logic        diag_valid, test_done, test_fail, cpu_sleep, acc_clk, tile_busy, tsu_busy;
  logic [7:0]  diag_char;
  logic [15:0] test_code;

  silicaflux_cc_hpc_system u_sys (
    .clk, .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(boot_mode), .host_rst_req_i(host_rst),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready(1'b1), .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(host_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready), .ras_fatal_o(ras_fatal),
    .dm_req_valid, .dm_req_ready, .dm_req_write, .dm_req_addr, .dm_req_wdata, .dm_req_wstrb,
    .dm_rsp_valid, .dm_rsp_ready, .dm_rsp_rdata, .dm_rsp_error,
    .ext_warn_i(ext_warn), .ext_fatal_i(ext_fatal),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep), .acc_clk_o(acc_clk), .tile_busy_o(tile_busy),
    .tsu_busy_o(tsu_busy)
  );

  // ------------------------------------------------------------------ device memory model (SFB2 slave)
  localparam int DM_WORDS = int'(CC_DEVMEM_SIZE) / 4;
  logic [31:0] dmem [DM_WORDS];
  logic        dm_rv = 1'b0, dm_re = 1'b0, dm_stall = 1'b0;
  logic [31:0] dm_rd = '0;
  int unsigned dm_reads = 0, dm_writes = 0;
  assign dm_req_ready = !dm_rv && !dm_stall;
  assign dm_rsp_valid = dm_rv;
  assign dm_rsp_rdata = dm_rd;
  assign dm_rsp_error = dm_re;
  function automatic bit dm_bad(input logic [31:0] a);
    return (a < CC_DEVMEM_BASE) || (a >= CC_DEVMEM_BASE + CC_DEVMEM_SIZE) ||
           (a >= CC_TB_POISON_BASE && a < CC_TB_POISON_BASE + CC_TB_POISON_SIZE);
  endfunction
  always @(posedge clk) begin
    dm_stall <= (bp_pct > 0) && (($urandom % 100) < bp_pct);
    if (dm_rv && dm_rsp_ready) dm_rv <= 1'b0;
    if (dm_req_valid && dm_req_ready) begin
      automatic int w = int'((dm_req_addr - CC_DEVMEM_BASE) >> 2);
      dm_rv <= 1'b1;
      dm_re <= dm_bad(dm_req_addr);
      dm_rd <= '0;
      if (!dm_bad(dm_req_addr)) begin
        if (dm_req_write) begin
          for (int b = 0; b < 4; b++) if (dm_req_wstrb[b]) dmem[w][8*b +: 8] <= dm_req_wdata[8*b +: 8];
          dm_writes++;
        end else begin
          dm_rd <= dmem[w];
          dm_reads++;
        end
      end
    end
  end
  function automatic void dm_poke(input logic [31:0] a, input logic [31:0] v);
    dmem[int'((a - CC_DEVMEM_BASE) >> 2)] = v;
  endfunction
  function automatic logic [31:0] dm_peek(input logic [31:0] a);
    return dmem[int'((a - CC_DEVMEM_BASE) >> 2)];
  endfunction

  // ------------------------------------------------------------------ optional host-port trace (+hostdbg)
  bit hostdbg;
  initial hostdbg = $test$plusargs("hostdbg");
  always @(posedge clk) if (hostdbg) begin
    if (hs_req_valid) $display("[%0d] HOSTDBG req v=1 rdy=%0d we=%0d a=%08h", cyc, hs_req_ready, hs_req_write, hs_req_addr);
    if (hs_rsp_valid) $display("[%0d] HOSTDBG rsp d=%08h err=%0d", cyc, hs_rsp_rdata, hs_rsp_error);
  end

  // ------------------------------------------------------------------ optional CPU trap trace (+cpudbg)
  bit cpudbg;
  initial cpudbg = $test$plusargs("cpudbg");
  always @(posedge clk) if (cpudbg && u_sys.u_cc.u_cpu.rt_valid && u_sys.u_cc.u_cpu.rt_trap)
    $display("[%0d] CPUDBG trap pc=%08h insn=%08h cause=%08h", cyc, u_sys.u_cc.u_cpu.rt_pc,
             u_sys.u_cc.u_cpu.rt_insn, u_sys.u_cc.u_cpu.rt_cause);

  // ------------------------------------------------------------------ optional accelerator doorbell trace (+accdbg)
  bit accdbg;
  initial accdbg = $test$plusargs("accdbg");
  always @(posedge clk) if (accdbg && u_sys.acc_rb_sel && u_sys.acc_rb_we &&
                           (u_sys.acc_rb_addr == 16'h80A0 || u_sys.acc_rb_addr == 16'h8058 ||
                            u_sys.acc_rb_addr == 16'h9070 || u_sys.acc_rb_addr == 16'h9098 || u_sys.acc_rb_addr == 16'h8020))
    $display("[%0d] ACCDBG write %04h = %08h err=%0d acc_clk_en=%0d", cyc, u_sys.acc_rb_addr, u_sys.acc_rb_wdata,
             u_sys.acc_rb_err, u_sys.u_cc.acc_clk_en);

  bit ras_fatal_seen = 1'b0;
  always @(posedge clk) if (ras_fatal) ras_fatal_seen <= 1'b1;

  // ------------------------------------------------------------------ console capture
  string line = "";
  byte   con_log[$];
  always @(posedge clk) if (diag_valid) begin
    con_log.push_back(diag_char);
    if (diag_char == 8'h0A) begin
      $display("[%0d] FW| %s", cyc, line);
      line = "";
    end else begin
      line = {line, string'(diag_char)};
    end
  end

  // ------------------------------------------------------------------ host BFM
  task automatic host_access(input bit wr, input logic [31:0] a, input logic [31:0] wd,
                             output logic [31:0] rd, output bit err);
    // drive and sample mid-cycle (negedge + settle): the handshake happens at the
    // next posedge when valid && ready are seen here
    @(negedge clk);
    hs_req_valid = 1'b1; hs_req_write = wr; hs_req_addr = a; hs_req_wdata = wd; hs_req_wstrb = 4'hF;
    #1;
    while (!hs_req_ready) begin @(negedge clk); #1; end
    @(posedge clk);
    #1;
    hs_req_valid = 1'b0;
    while (!hs_rsp_valid) begin @(negedge clk); #1; end
    rd = hs_rsp_rdata; err = hs_rsp_error;
    @(posedge clk);
  endtask
  task automatic hwr(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; bit e;
    host_access(1'b1, a, d, r, e);
    if (e) begin $display("TB ERROR host write %08h refused", a); tb_fails++; end
  endtask
  task automatic hrd(input logic [31:0] a, output logic [31:0] d);
    bit e;
    host_access(1'b0, a, 32'd0, d, e);
    if (e) begin $display("TB ERROR host read %08h refused", a); tb_fails++; end
  endtask
  task automatic tb_check(input string what, input logic [31:0] got, input logic [31:0] exp);
    if (got !== exp) begin
      $display("TB CHECK FAIL %s: got %08h exp %08h", what, got, exp);
      tb_fails++;
    end else $display("TB check ok   %s = %08h", what, got);
  endtask

  // wait for a SYSCTRL.BOOT_STAGE value (host polling, as a real host would)
  task automatic wait_stage(input logic [31:0] st, input longint tmo);
    logic [31:0] v; longint t0 = cyc;
    forever begin
      hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v);
      if (v == st) break;
      if (cyc - t0 > tmo) begin $display("TB ERROR timeout waiting for boot stage %0h (at %0h)", st, v); tb_fails++; break; end
      repeat (200) @(posedge clk);
    end
  endtask

  // load the firmware image into IMEM through the host port
  logic [31:0] img [$];
  task automatic load_image_file();
    int fd; logic [31:0] w;
    img.delete();
    fd = $fopen(fw_path, "r");
    if (fd == 0) $fatal(1, "cannot open %s", fw_path);
    while ($fscanf(fd, "%h\n", w) == 1) img.push_back(w);
    $fclose(fd);
    $display("TB host: firmware image %s, %0d words", fw_path, img.size());
  endtask
  task automatic host_load(input int corrupt_word);
    longint t0 = cyc;
    for (int i = 0; i < img.size(); i++)
      hwr(CC_IMEM_BASE + 32'(4 * i), (i == corrupt_word) ? ~img[i] : img[i]);
    $display("TB host: image written to IMEM in %0d cycles%s", cyc - t0, corrupt_word >= 0 ? " (CORRUPTED)" : "");
  endtask

  // mailbox: send a command, wait for the firmware's answer (F2H doorbell)
  logic [31:0] rsp [8];
  task automatic mbox_cmd(input logic [31:0] cmd, input logic [31:0] a1, input logic [31:0] a2,
                          input logic [31:0] a3, input longint tmo);
    longint t0 = cyc;
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, a1);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 8, a2);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 12, a3);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd);
    mbox_wait(tmo);
    $display("TB host: cmd %02h -> status %0d (%0d cycles)", cmd, rsp[0] & 32'hFF, cyc - t0);
  endtask
  task automatic mbox_wait(input longint tmo);
    longint t0 = cyc;
    while (!host_irq) begin
      @(posedge clk);
      if (cyc - t0 > tmo) begin $display("TB ERROR timeout waiting for the firmware"); tb_fails++; return; end
    end
    for (int i = 0; i < 8; i++) hrd(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 32'(4 * i), rsp[i]);
    hwr(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
  endtask

  // ------------------------------------------------------------------ reference helpers
  function automatic logic [31:0] f32_int(input int v);       // exact float bits of a small integer
    int s, e, m, a;
    if (v == 0) return 32'h0;
    s = v < 0; a = s ? -v : v; e = 0;
    while ((a >> e) > 1) e++;
    m = (a << (23 - e)) & 32'h7FFFFF;
    return {s[0], 8'(127 + e), m[22:0]};
  endfunction

  // host-built GEMM (TENSORCORE 08 ABI v2 descriptor in device memory)
  task automatic host_gemm(input int m, input int n, input int k, input logic [7:0] tid, input bit bad_version);
    logic [31:0] A = CC_DEVMEM_BASE + 32'h8_0000, B = CC_DEVMEM_BASE + 32'h8_4000;
    logic [31:0] C = CC_DEVMEM_BASE + 32'h8_8000, D = CC_DEVMEM_BASE + 32'h8_F000;
    byte a[], b[]; int bad = 0;
    a = new[m * k]; b = new[k * n];
    foreach (a[i]) a[i] = byte'($urandom);
    foreach (b[i]) b[i] = byte'($urandom);
    for (int i = 0; i < m * k; i += 4) dm_poke(A + i, {a[i+3 < m*k ? i+3 : i], a[i+2 < m*k ? i+2 : i], a[i+1 < m*k ? i+1 : i], a[i]});
    for (int i = 0; i < k * n; i += 4) dm_poke(B + i, {b[i+3 < k*n ? i+3 : i], b[i+2 < k*n ? i+2 : i], b[i+1 < k*n ? i+1 : i], b[i]});
    dm_poke(D + 0,  {tid, 8'h01, 4'h0, bad_version ? 4'h1 : 4'h2, 8'h40});   // GEMM, VERSION 2, FLAGS.IRQ
    dm_poke(D + 4,  A);  dm_poke(D + 8, B);  dm_poke(D + 12, C);
    dm_poke(D + 16, {16'(n), 16'(m)});  dm_poke(D + 20, 32'(k));
    dm_poke(D + 24, 32'(k));  dm_poke(D + 28, 32'(n));  dm_poke(D + 32, 32'(4 * n));
    dm_poke(D + 36, 0); dm_poke(D + 40, 0); dm_poke(D + 44, 0);
    for (int i = 0; i < m * n; i++) dm_poke(C + 4 * i, 32'hDEAD_BEEF);
    mbox_cmd(CC_MBOX_CMD_GEMM, D, 0, 0, 5_000_000);
    if (bad_version) begin
      tb_check("GEMM bad version: status ACC_ERROR", rsp[0] & 32'hFF, CC_MBOX_STS_ACC_ERROR);
      tb_check("GEMM bad version: record ERR_CODE VERSION", (rsp[1] >> 16) & 32'hFF, 32'h01);
      tb_check("GEMM bad version: C untouched", dm_peek(C), 32'hDEAD_BEEF);
      return;
    end
    tb_check($sformatf("GEMM %0dx%0dx%0d status", m, n, k), rsp[0] & 32'hFF, CC_MBOX_STS_OK);
    tb_check("GEMM record TID", rsp[1] & 32'hFF, 32'(tid));
    tb_check("GEMM record COUNT (bytes acknowledged)", rsp[2], 32'(4 * m * n));
    for (int i = 0; i < m; i++)
      for (int j = 0; j < n; j++) begin
        int s = 0;
        for (int x = 0; x < k; x++) s += int'(a[i * k + x]) * int'(b[x * n + j]);
        if (dm_peek(C + 4 * (i * n + j)) !== 32'(s)) bad++;
      end
    tb_check("GEMM C mismatches vs testbench reference", 32'(bad), 0);
  endtask

  // host-built vector KERNEL (HPC Module 08 tile descriptor in device memory)
  task automatic host_vector(input int vl);
    logic [31:0] A = CC_DEVMEM_BASE + 32'h9_0000, B = CC_DEVMEM_BASE + 32'h9_1000;
    logic [31:0] Dd = CC_DEVMEM_BASE + 32'h9_2000, D = CC_DEVMEM_BASE + 32'h9_3000;
    int bad = 0;
    for (int i = 0; i < vl; i++) begin
      dm_poke(A + 4 * i, f32_int(i - 7)); dm_poke(B + 4 * i, f32_int(3 * i)); dm_poke(Dd + 4 * i, 32'hFFFF_FFFF);
    end
    dm_poke(D + 0, {8'h00, 8'h77, 1'b0, 3'd0, 3'd0, 5'h01, 4'h3});   // KERNEL, FADD, RNE, TAG 0x77
    dm_poke(D + 4, 32'(vl)); dm_poke(D + 8, 0); dm_poke(D + 12, A); dm_poke(D + 16, B); dm_poke(D + 20, 0);
    dm_poke(D + 24, Dd); dm_poke(D + 28, CC_TILE_SPM_BASE + 32'h4000);
    mbox_cmd(CC_MBOX_CMD_VECTOR_KERNEL, D, 0, 0, 5_000_000);
    tb_check("VECTOR KERNEL status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
    tb_check("VECTOR KERNEL record tag", rsp[1] & 32'hFF, 32'h77);
    tb_check("VECTOR KERNEL record count", rsp[3], 32'(vl));
    for (int i = 0; i < vl; i++) if (dm_peek(Dd + 4 * i) !== f32_int(4 * i - 7)) bad++;
    tb_check("VECTOR D mismatches vs testbench reference", 32'(bad), 0);
  endtask

  // ------------------------------------------------------------------ scenario helpers
  task automatic boot_from_host(input int corrupt_word);
    wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 2_000_000);
    host_load(corrupt_word);
    mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 0, 0, 0, 3_000_000);
  endtask
  task automatic wait_host_ready(input longint tmo);
    longint t0 = cyc;
    while (!host_ready) begin
      @(posedge clk);
      if (cyc - t0 > tmo) begin $display("TB ERROR timeout waiting for HOST_READY"); tb_fails++; return; end
    end
    mbox_wait(1000);                                        // unsolicited ready notification + capabilities
    $display("TB host: HOST READY at cycle %0d: accelerators=%0h tile_cfg=%08h tsu_info=%08h reset_cause=%0h fw=%08h crc=%08h",
             cyc, rsp[1], rsp[2], rsp[3], rsp[4], rsp[5], rsp[6]);
  endtask
  task automatic finish_run();
    mbox_cmd(CC_MBOX_CMD_SHUTDOWN, 32'(tb_fails), 0, 0, 100000);
    repeat (20) @(posedge clk);
    tb_check("TEST_CTRL done", 32'(test_done), 1);
    tb_check("TEST_CTRL fail", 32'(test_fail), 0);
    $display("TB RESULT %s scenario=%s cycles=%0d devmem_reads=%0d devmem_writes=%0d",
             (tb_fails == 0 && test_done && !test_fail) ? "PASS" : "FAIL", scenario, cyc, dm_reads, dm_writes);
    if (tb_fails == 0 && test_done && !test_fail) $finish(0);
    else $fatal(1, "scenario %s failed (tb_fails=%0d)", scenario, tb_fails);
  endtask

  // ------------------------------------------------------------------ watchdog on the whole run
  initial begin
    if (!$value$plusargs("timeout=%d", timeout)) timeout = 40_000_000;
    wait (cyc > timeout);
    $display("TB RESULT FAIL scenario=%s TIMEOUT at cycle %0d (boot stage via probe %0h)", scenario, cyc,
             u_sys.u_cc.u_sysctrl.stage_q);
    $fatal(1, "timeout");
  end

  // ------------------------------------------------------------------ main
  initial begin
    logic [31:0] v; bit e;
    if (!$value$plusargs("scenario=%s", scenario)) scenario = "boot_host";
    if (!$value$plusargs("fw=%s", fw_path)) fw_path = "firmware/build/fw/controlcore_fw.hex";
    if (!$value$plusargs("bp=%d", bp_pct)) bp_pct = 0;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    void'($urandom(seed));
    for (int i = 0; i < DM_WORDS; i++) dmem[i] = 32'h0;
    load_image_file();
    $display("TB scenario %s, device-memory back-pressure %0d%%", scenario, bp_pct);
    if (scenario == "boot_ext") begin
      boot_mode = 2'b01;
      foreach (img[i]) dmem[int'((CC_EXT_IMAGE_DEFAULT - CC_DEVMEM_BASE) >> 2) + i] = img[i];   // host placed it
    end
    repeat (5) @(posedge clk);
    rst_n = 1'b1;

    case (scenario)
      // -------------------------------------------------------------- full bring-up and orchestration
      "boot_host": begin
        boot_from_host(-1);
        tb_check("ROM accepted the image", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
        wait_host_ready(5_000_000);
        tb_check("both accelerators discovered", rsp[1], 3);
        tb_check("cmdproc_ready pin", 32'(cmdproc_ready), 1);
        hrd(CC_SECURITY_BASE + CC_SEC_STATUS, v);
        tb_check("SECURITY: host lock set, AUTH_STATE = not implemented", v & 32'h10F, 32'h003);
        // host write lock: IMEM is no longer host-writable
        host_access(1'b1, CC_IMEM_BASE + 32'h100, 32'h0, v, e);
        tb_check("host write to IMEM refused after lock", 32'(e), 1);
        hrd(CC_SECURITY_BASE + CC_SEC_STATUS, v);
        tb_check("SECURITY: HOST_VIOLATION recorded", (v >> 8) & 1, 1);
        mbox_cmd(CC_MBOX_CMD_PING, 32'h1234_5678, 0, 0, 100000);
        tb_check("PING echo", rsp[1], 32'h1234_5678);
        // firmware self-test suite on the RTL
        if (!$value$plusargs("stmask=%h", stmask)) stmask = 0;
        mbox_cmd(CC_MBOX_CMD_RUN_SELFTEST, stmask, 0, 0, 30_000_000);
        if (stmask != 0) finish_run();
        tb_check("RUN_SELFTEST status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
        tb_check("RUN_SELFTEST firmware fails", rsp[2], 0);
        $display("TB host: firmware self-test executed %0d checks", rsp[1]);
        // host-submitted accelerator work through the command processor
        host_gemm(9, 11, 40, 8'h91, 1'b0);
        host_gemm(4, 4, 4, 8'h92, 1'b1);                    // invalid descriptor: rejected, nothing written
        host_gemm(16, 8, 24, 8'h93, 1'b0);                  // recovered
        host_vector(48);
        for (int i = 0; i < 64; i++) dm_poke(CC_DEVMEM_BASE + 32'hA_0000 + 4 * i, 32'hC0DE_0000 + i);
        mbox_cmd(CC_MBOX_CMD_DMA_COPY, CC_DEVMEM_BASE + 32'hA_0000, CC_DEVMEM_BASE + 32'hA_1000, 256, 1_000_000);
        tb_check("DMA_COPY status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
        tb_check("DMA_COPY last word", dm_peek(CC_DEVMEM_BASE + 32'hA_10FC), 32'hC0DE_003F);
        mbox_cmd(CC_MBOX_CMD_DMA_COPY, CC_TB_POISON_BASE, CC_DEVMEM_BASE + 32'hA_1000, 64, 1_000_000);
        tb_check("DMA_COPY from poisoned memory -> error", rsp[0] & 32'hFF, CC_MBOX_STS_ACC_ERROR);
        tb_check("DMA_COPY error code READ_BUS", rsp[1], 8);
        // SoC warning input -> RAS
        ext_warn = 1'b1; repeat (50) @(posedge clk); ext_warn = 1'b0; repeat (50) @(posedge clk);
        mbox_cmd(CC_MBOX_CMD_RAS_DUMP, 0, 0, 0, 100000);
        tb_check("RAS saw the SoC warning (EXT_WARN)", (rsp[6] >> CC_RAS_SRC_EXT_WARN) & 1, 1);
        tb_check("RAS saw the parity test (MEM_PARITY)", (rsp[7] >> (CC_RAS_SRC_MEM_PARITY - 8)) & 1, 1);
        tb_check("ras_fatal pin was raised while fatal events were pending", 32'(ras_fatal_seen), 1);
        tb_check("ras_fatal pin released after the firmware handled them", 32'(ras_fatal), 0);
        // telemetry
        mbox_cmd(CC_MBOX_CMD_PERF_DUMP, CC_DEVMEM_BASE + 32'hB_0000, 0, 0, 100000);
        tb_check("PERF_DUMP words", rsp[1], 72);
        tb_check("PERF_DUMP tag", dm_peek(CC_DEVMEM_BASE + 32'hB_0000), 32'h4343_5046);
        $display("TB host: telemetry: cc_cycles=%0d vec_busy=%0d tsu_busy=%0d tile_kernels=%0d tsu_gemm_ok=%0d tsu_macs=%0d",
                 dm_peek(CC_DEVMEM_BASE + 32'hB_0004), dm_peek(CC_DEVMEM_BASE + 32'hB_0014),
                 dm_peek(CC_DEVMEM_BASE + 32'hB_0018), dm_peek(CC_DEVMEM_BASE + 32'hB_0000 + 4 * (26 + 23)),
                 dm_peek(CC_DEVMEM_BASE + 32'hB_0000 + 4 * (52 + 5)), dm_peek(CC_DEVMEM_BASE + 32'hB_0000 + 4 * (52 + 8)));
        tb_check("tensor GEMM_OK counter > 0", 32'(dm_peek(CC_DEVMEM_BASE + 32'hB_0000 + 4 * (52 + 5)) > 0), 1);
        // host-visible console FIFO: the first characters equal the stream the testbench captured
        hrd(CC_MAILBOX_BASE + CC_MBOX_DIAG_STATUS, v);
        $display("TB host: console FIFO level %0d overflow %0d", v & 32'h1FF, (v >> 16) & 1);
        for (int i = 0; i < 16; i++) begin
          hrd(CC_MAILBOX_BASE + CC_MBOX_DIAG_RX, v);
          if (v[8] !== 1'b1 || v[7:0] !== con_log[i]) begin
            tb_check($sformatf("console FIFO char %0d", i), v, {23'd0, 1'b1, con_log[i]}); break;
          end
          hwr(CC_MAILBOX_BASE + CC_MBOX_DIAG_POP, 0);
        end
        finish_run();
      end
      // -------------------------------------------------------------- boot from device memory via DMA
      "boot_ext": begin
        wait_host_ready(5_000_000);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_MODE, v);
        tb_check("BOOT_MODE straps = EXT", v, CC_BOOT_MODE_EXT);
        mbox_cmd(CC_MBOX_CMD_RUN_SELFTEST, 32'h1C1, 0, 0, 20_000_000);   // identity, timer, vector, tensor
        tb_check("RUN_SELFTEST firmware fails", rsp[2], 0);
        host_gemm(8, 8, 8, 8'hE1, 1'b0);
        finish_run();
      end
      // -------------------------------------------------------------- corrupted image, recovery, host reset
      "bad_image": begin
        boot_from_host(200);
        tb_check("ROM rejected the corrupted image", rsp[0] & 32'hFF, CC_MBOX_STS_BAD_CMD);
        tb_check("ROM reason = CRC", rsp[1], CC_BOOT_ERR_CRC);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STATUS, v);
        tb_check("BOOT_STATUS = CRC", v, CC_BOOT_ERR_CRC);
        boot_from_host(-1);                                  // reload a good image, no reset needed
        tb_check("ROM accepted the corrected image", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
        wait_host_ready(5_000_000);
        // host-requested reset: cold boot, image must be loaded again
        host_rst = 1'b1; repeat (10) @(posedge clk); host_rst = 1'b0;
        repeat (50) @(posedge clk);
        tb_check("host_ready dropped by the host reset", 32'(host_ready), 0);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_RESET_CAUSE, v);
        tb_check("RESET_CAUSE = HOST (POR cleared by firmware)", v, CC_RESET_CAUSE_HOST);
        boot_from_host(-1);
        wait_host_ready(5_000_000);
        tb_check("firmware saw reset cause HOST", rsp[4], CC_RESET_CAUSE_HOST);
        mbox_cmd(CC_MBOX_CMD_PING, 32'hA5A5_0001, 0, 0, 100000);
        tb_check("PING after host reset", rsp[1], 32'hA5A5_0001);
        finish_run();
      end
      // -------------------------------------------------------------- watchdog timeout -> reset -> warm boot
      "wdt_reset": begin
        boot_from_host(-1);
        wait_host_ready(5_000_000);
        hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, 32'h8000_0000);
        hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, CC_MBOX_CMD_RUN_SELFTEST);
        hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, CC_MBOX_CMD_RUN_SELFTEST);
        wait (!host_ready);
        $display("TB host: HOST_READY dropped at cycle %0d (watchdog reset)", cyc);
        wait_host_ready(5_000_000);                          // warm boot: no image reload by the host
        tb_check("firmware saw reset cause WDT", rsp[4], CC_RESET_CAUSE_WDT);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_SCRATCH0, v);
        tb_check("SCRATCH0 = watchdog test passed", v, 32'h5744_5450);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_SCRATCH2, v);
        tb_check("early-warning interrupt seen before the reset", 32'(v >= 1), 1);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_RESET_COUNT, v);
        tb_check("RESET_COUNT", v, 1);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STATUS, v);
        mbox_cmd(CC_MBOX_CMD_RUN_SELFTEST, 32'h081, 0, 0, 10_000_000);   // identity + tensor after the reset
        tb_check("RUN_SELFTEST after watchdog reset", rsp[2], 0);
        finish_run();
      end
      default: $fatal(1, "unknown scenario %s", scenario);
    endcase
  end
endmodule

`default_nettype wire
