/* SilicaFlux.OS example 4 -- AI inference primitive: a quantised 2-layer MLP.
 *
 *   example_int8_inference [cpu|rtl-cc] [--allow-cpu-fallback]
 *
 *   H  = ReLU(requant(X . W1))   int8 x int8 -> int32 -> int8 (multiplier/shift/zero-point)
 *   Z  = H . W2                  int8 x int8 -> int32 logits
 *   class = argmax(Z)
 * Both layers run on the tensor engine; H stays in device memory between them.
 * Reference: integer arithmetic written here, with the requantisation contract
 * clamp(round_half_even(acc * M / 2^S) + zp, -128, 127), ReLU floor = zp.
 * A device without requantised output (e.g. rtl-hostlink) reports UNSUPPORTED
 * (exit 3) unless --allow-cpu-fallback is given, in which case layer 1 is
 * computed on the CPU and labelled as such.
 */
#include "common.h"

enum { BATCH = 8, IN = 64, HID = 32, OUT = 10 };
static const int32_t QM = 1 << 22;   /* requantisation multiplier */
static const uint32_t QS = 31;       /* shift: scale = 2^22 / 2^31 = 1/512 */
static const int32_t QZ = 0;

static int8_t requant_ref(int32_t acc) {
  __int128 p = (__int128)acc * QM, one = (__int128)1 << QS;
  __int128 q = p >= 0 ? p / one : -((-p + one - 1) / one);   /* floor */
  __int128 rem = p - q * one;
  if (2 * rem > one || (2 * rem == one && (q & 1))) q += 1;   /* ties to even */
  long long y = (long long)q + QZ;
  if (y < -128) y = -128;
  if (y > 127) y = 127;
  if (y < QZ) y = QZ;                                         /* ReLU at the zero-point */
  return (int8_t)y;
}

int main(int argc, char **argv) {
  sf_device_info info;
  sf_device_t dev = open_from_args(argc, argv, &info);
  static int8_t X[BATCH * IN], W1[IN * HID], W2[HID * OUT], H[BATCH * HID], Href[BATCH * HID];
  static int32_t Z[BATCH * OUT], Zref[BATCH * OUT];
  uint32_t seed = 31337;
  for (int i = 0; i < BATCH * IN; i++) X[i] = (int8_t)(lcg(&seed) >> 24);
  for (int i = 0; i < IN * HID; i++) W1[i] = (int8_t)(lcg(&seed) >> 25);
  for (int i = 0; i < HID * OUT; i++) W2[i] = (int8_t)(lcg(&seed) >> 25);

  sf_buffer_t bx = new_buffer(dev, sizeof X, X), bw1 = new_buffer(dev, sizeof W1, W1), bw2 = new_buffer(dev, sizeof W2, W2);
  sf_buffer_t bh = new_buffer(dev, sizeof H, NULL), bz = new_buffer(dev, sizeof Z, NULL);
  sf_queue_t q;
  CHECK(sf_queue_create(dev, 4, &q));
  sf_gemm_desc l1 = {sizeof l1};
  l1.m = BATCH; l1.n = HID; l1.k = IN;
  l1.a_type = l1.b_type = SF_DTYPE_I8;
  l1.c_type = SF_DTYPE_I8;
  l1.q_mult = QM; l1.q_shift = QS; l1.q_zero_point = QZ; l1.relu = 1; l1.rounding = SF_ROUND_NEAREST_EVEN;
  sf_gemm_desc l2 = {sizeof l2};
  l2.m = BATCH; l2.n = OUT; l2.k = HID;
  l2.a_type = l2.b_type = SF_DTYPE_I8;
  l2.c_type = SF_DTYPE_I32;
  sf_cmd_t c1, c2;
  CHECK(sf_tensor_gemm(q, bx, bw1, bh, &l1, &c1));   /* layer 2 reads H: in-order queue = dependency */
  CHECK(sf_tensor_gemm(q, bh, bw2, bz, &l2, &c2));
  sf_cmd_result r1 = {sizeof r1}, r2 = {sizeof r2};
  CHECK(sf_queue_wait(q, c2, SF_TIMEOUT_DEFAULT, &r2));
  CHECK(sf_queue_poll(q, c1, &r1));
  CHECK(sf_buffer_read(bh, 0, H, sizeof H));
  CHECK(sf_buffer_read(bz, 0, Z, sizeof Z));

  for (int b = 0; b < BATCH; b++) {
    for (int j = 0; j < HID; j++) {
      int32_t acc = 0;
      for (int k = 0; k < IN; k++) acc += X[b * IN + k] * W1[k * HID + j];
      Href[b * HID + j] = requant_ref(acc);
    }
    for (int j = 0; j < OUT; j++) {
      int32_t acc = 0;
      for (int k = 0; k < HID; k++) acc += Href[b * HID + k] * W2[k * OUT + j];
      Zref[b * OUT + j] = acc;
    }
  }
  int bad = memcmp(H, Href, sizeof H) != 0 || memcmp(Z, Zref, sizeof Z) != 0;
  printf("  layer 1: %dx%dx%d int8->int8 requant+ReLU on %s (%llu engine cycles%s)\n", BATCH, HID, IN,
         exec_name(r1.exec_target), (unsigned long long)r1.engine_cycles,
         (r1.flags & SF_RESULT_SATURATED) ? ", saturated" : "");
  printf("  layer 2: %dx%dx%d int8->int32 on %s (%llu engine cycles)\n", BATCH, OUT, HID, exec_name(r2.exec_target),
         (unsigned long long)r2.engine_cycles);
  printf("  predicted classes:");
  for (int b = 0; b < BATCH; b++) {
    int best = 0;
    for (int j = 1; j < OUT; j++)
      if (Z[b * OUT + j] > Z[b * OUT + best]) best = j;
    printf(" %d", best);
  }
  printf("\n%s: hidden activations and logits %s the integer reference\n", bad ? "FAILED" : "PASSED",
         bad ? "DIFFER from" : "match");
  sf_device_close(dev);
  return bad;
}
