/* SilicaFlux.OS example 5 -- mixed CPU / accelerator workload.
 *
 *   example_mixed_workload [cpu|rtl-cc|rtl-hostlink]
 *
 * A pipeline over several batches of a float "feature x weight" product:
 *   host  : quantise float features to int8 (symmetric, per tensor)
 *   device: int8 GEMM -> int32                              (batch b+1 is in flight ...)
 *   host  : dequantise + softmax + argmax of batch b        (... while the host works on b)
 * The host never touches a buffer the device still owns: each batch has its own
 * output buffer, and results are read only after that batch's command retired.
 * Reference: the same pipeline in float on the host; the quantised pipeline must
 * pick the same class for every row.
 */
#include <math.h>

#include "common.h"

enum { BATCHES = 4, ROWS = 8, FEAT = 48, CLS = 12 };

int main(int argc, char **argv) {
  sf_device_info info;
  sf_device_t dev = open_from_args(argc, argv, &info);
  static float Xf[BATCHES][ROWS * FEAT], Wf[FEAT * CLS];
  static int8_t Xq[BATCHES][ROWS * FEAT], Wq[FEAT * CLS];
  uint32_t seed = 99;
  for (int b = 0; b < BATCHES; b++)
    for (int i = 0; i < ROWS * FEAT; i++) Xf[b][i] = (float)((int32_t)lcg(&seed) >> 16) / 32768.0f;
  for (int i = 0; i < FEAT * CLS; i++) Wf[i] = (float)((int32_t)lcg(&seed) >> 16) / 32768.0f;
  /* host: quantise the weights once */
  float wmax = 0;
  for (int i = 0; i < FEAT * CLS; i++) wmax = fmaxf(wmax, fabsf(Wf[i]));
  float ws = wmax / 127.0f;
  for (int i = 0; i < FEAT * CLS; i++) Wq[i] = (int8_t)lrintf(Wf[i] / ws);
  sf_buffer_t bw = new_buffer(dev, sizeof Wq, Wq), bx[BATCHES], bc[BATCHES];
  float xs[BATCHES];
  sf_queue_t q;
  CHECK(sf_queue_create(dev, 4, &q));
  sf_gemm_desc g = {sizeof g};
  g.m = ROWS; g.n = CLS; g.k = FEAT;
  g.a_type = g.b_type = SF_DTYPE_I8;
  g.c_type = SF_DTYPE_I32;
  sf_cmd_t ids[BATCHES];
  int agree = 0, total = 0;
  double host_ms = 0;
  for (int b = 0; b <= BATCHES; b++) {
    if (b < BATCHES) {   /* host quantises batch b and submits it (asynchronous) */
      float xmax = 0;
      for (int i = 0; i < ROWS * FEAT; i++) xmax = fmaxf(xmax, fabsf(Xf[b][i]));
      xs[b] = xmax / 127.0f;
      for (int i = 0; i < ROWS * FEAT; i++) Xq[b][i] = (int8_t)lrintf(Xf[b][i] / xs[b]);
      bx[b] = new_buffer(dev, sizeof Xq[b], Xq[b]);
      bc[b] = new_buffer(dev, 4 * ROWS * CLS, NULL);
      CHECK(sf_tensor_gemm(q, bx[b], bw, bc[b], &g, &ids[b]));
    }
    if (b > 0) {         /* meanwhile: host finishes batch b-1 */
      int p = b - 1;
      sf_cmd_result r = {sizeof r};
      CHECK(sf_queue_wait(q, ids[p], SF_TIMEOUT_DEFAULT, &r));
      int32_t C[ROWS * CLS];
      CHECK(sf_buffer_read(bc[p], 0, C, sizeof C));
      for (int i = 0; i < ROWS; i++) {
        float logits[CLS], ref[CLS], mx = -1e30f, sum = 0;
        for (int j = 0; j < CLS; j++) {
          logits[j] = (float)C[i * CLS + j] * xs[p] * ws;           /* dequantise */
          mx = fmaxf(mx, logits[j]);
          ref[j] = 0;
          for (int k = 0; k < FEAT; k++) ref[j] += Xf[p][i * FEAT + k] * Wf[k * CLS + j];
        }
        int best = 0, rbest = 0;
        for (int j = 0; j < CLS; j++) {
          sum += expf(logits[j] - mx);                              /* softmax on the host */
          if (logits[j] > logits[best]) best = j;
          if (ref[j] > ref[rbest]) rbest = j;
        }
        agree += best == rbest;
        total++;
        if (i == 0) printf("  batch %d row 0: class %d (p=%.3f), float reference class %d\n", p, best,
                           expf(logits[best] - mx) / sum, rbest);
      }
      host_ms += (r.host_complete_ns - r.host_submit_ns) / 1e6;
      if (p == 0) printf("  GEMMs run on %s; host quantisation/dequantisation/softmax on the CPU\n",
                         exec_name(r.exec_target));
    }
  }
  printf("%s: %d of %d rows agree with the float reference\n", agree >= total - 1 ? "PASSED" : "FAILED", agree, total);
  sf_device_close(dev);
  return agree >= total - 1 ? 0 : 1;   /* int8 quantisation may flip a near-tie */
}
