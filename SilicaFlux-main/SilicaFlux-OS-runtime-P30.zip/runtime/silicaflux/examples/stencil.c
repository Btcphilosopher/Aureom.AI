/* SilicaFlux.OS example 3 -- scientific stencil: 1-D heat equation.
 *
 *   example_stencil [cpu|rtl-cc] [--allow-cpu-fallback]
 *
 * Explicit finite differences for u_t = u_xx on [0,1], u(0)=u(1)=0,
 * u(x,0) = sin(pi x):   u_i' = u_i + r (u_{i-1} - 2 u_i + u_{i+1}),  r = dt/h^2.
 * Each step is three device vector commands on buffer VIEWS (no host round trip):
 *   t1 = u[i-1] + u[i+1]            sf_vector_add
 *   t2 = -2 * u[i] + t1             sf_vector_axpy
 *   u' = r * t2 + u[i]              sf_vector_axpy
 * Checks: (1) bit-exact against the same sequence in host IEEE float arithmetic;
 * (2) scientific sanity: the discrete solution must decay like the exact discrete
 * eigenmode, u = (1 - 4 r sin^2(pi h / 2))^steps sin(pi x).
 */
#include <math.h>

#include "common.h"

static uint32_t bits(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }

int main(int argc, char **argv) {
  sf_device_info info;
  sf_device_t dev = open_from_args(argc, argv, &info);
  const size_t n = 130;                        /* grid points including the two boundaries */
  const size_t m = n - 2;                      /* interior points */
  const int steps = 25;
  const float r = 0.25f;
  const double h = 1.0 / (double)(n - 1), pi = 3.14159265358979323846;
  float *u0 = calloc(n, 4), *ref = calloc(n, 4), *tmp = calloc(n, 4), *got = calloc(n, 4);
  for (size_t i = 1; i + 1 < n; i++) u0[i] = (float)sin(pi * (double)i * h);
  memcpy(ref, u0, 4 * n);

  sf_buffer_t U[2] = {new_buffer(dev, 4 * n, u0), new_buffer(dev, 4 * n, u0)};
  sf_buffer_t left[2], mid[2], right[2];
  for (int k = 0; k < 2; k++) {                /* views share the parent's memory */
    CHECK(sf_buffer_create_view(U[k], 0, 4 * m, SF_MEM_READ_WRITE, &left[k]));
    CHECK(sf_buffer_create_view(U[k], 4, 4 * m, SF_MEM_READ_WRITE, &mid[k]));
    CHECK(sf_buffer_create_view(U[k], 8, 4 * m, SF_MEM_READ_WRITE, &right[k]));
  }
  sf_buffer_t t1 = new_buffer(dev, 4 * m, NULL), t2 = new_buffer(dev, 4 * m, NULL);
  sf_queue_t q;
  CHECK(sf_queue_create(dev, 8, &q));
  sf_cmd_result res = {sizeof res};
  uint64_t engine = 0;
  int cur = 0;
  for (int s = 0; s < steps; s++) {
    int nxt = 1 - cur;
    CHECK(sf_vector_add(q, left[cur], right[cur], t1, m, SF_DTYPE_F32, NULL, NULL));
    CHECK(sf_vector_axpy(q, -2.0f, mid[cur], t1, t2, m, NULL, NULL));
    CHECK(sf_vector_axpy(q, r, t2, mid[cur], mid[nxt], m, NULL, NULL));
    CHECK(sf_queue_wait(q, SF_CMD_ALL, SF_TIMEOUT_DEFAULT, &res));   /* commands are in order; wait per step */
    engine += res.engine_cycles;
    /* host reference: identical operation sequence, IEEE float */
    for (size_t i = 1; i + 1 < n; i++) {
      volatile float a = ref[i - 1] + ref[i + 1];
      volatile float b = fmaf(-2.0f, ref[i], a);
      tmp[i] = fmaf(r, b, ref[i]);
    }
    memcpy(ref + 1, tmp + 1, 4 * m);
    cur = nxt;
  }
  CHECK(sf_buffer_read(U[cur], 0, got, 4 * n));
  size_t bad = 0;
  double maxdev = 0, decay = pow(1.0 - 4.0 * r * pow(sin(pi * h / 2.0), 2.0), steps);
  for (size_t i = 0; i < n; i++) {
    bad += bits(got[i]) != bits(ref[i]);
    double exact = decay * sin(pi * (double)i * h);
    if (fabs(got[i] - exact) > maxdev) maxdev = fabs(got[i] - exact);
  }
  printf("  %d steps x 3 vector commands on %zu interior points, executed on %s\n", steps, m,
         exec_name(res.exec_target));
  printf("  last step: %llu engine cycles for its last command; %llu engine cycles in total (sampled per step)\n",
         (unsigned long long)res.engine_cycles, (unsigned long long)engine);
  printf("  u(0.5) = %.7f  (discrete-eigenmode solution %.7f), max |u - exact discrete solution| = %.2e\n",
         got[(n - 1) / 2], decay * sin(pi * 0.5), maxdev);
  printf("  device vs host IEEE reference: %zu of %zu values differ\n", bad, n);
  int ok = bad == 0 && maxdev < 1e-5;
  printf("%s\n", ok ? "PASSED" : "FAILED");
  sf_device_close(dev);
  free(u0); free(ref); free(tmp); free(got);
  return ok ? 0 : 1;
}
