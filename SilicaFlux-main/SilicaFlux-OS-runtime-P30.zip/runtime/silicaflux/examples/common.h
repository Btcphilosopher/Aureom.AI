/* SilicaFlux.OS examples -- shared helpers (public C API only). */
#ifndef SF_EXAMPLES_COMMON_H
#define SF_EXAMPLES_COMMON_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "silicaflux/silicaflux.h"

#define CHECK(call)                                                                               \
  do {                                                                                            \
    sf_status _s = (call);                                                                        \
    if (_s != SF_OK) {                                                                            \
      fprintf(stderr, "%s:%d: %s -> %s: %s\n", __FILE__, __LINE__, #call, sf_status_string(_s),   \
              sf_last_error_detail());                                                            \
      exit(_s == SF_ERR_UNSUPPORTED ? 3 : 1);                                                     \
    }                                                                                             \
  } while (0)

static const char *exec_name(uint32_t t) {
  switch (t) {
    case SF_EXEC_HARDWARE: return "hardware";
    case SF_EXEC_RTL_SIMULATION: return "RTL simulation";
    case SF_EXEC_CPU_REFERENCE: return "CPU reference backend";
    case SF_EXEC_CPU_FALLBACK: return "CPU fallback";
    default: return "not executed";
  }
}

/* usage: prog [device-name] [--allow-cpu-fallback] */
static sf_device_t open_from_args(int argc, char **argv, sf_device_info *info) {
  const char *name = "cpu";
  uint32_t flags = 0;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--allow-cpu-fallback")) flags |= SF_OPEN_ALLOW_CPU_FALLBACK;
    else name = argv[i];
  }
  sf_device_t d;
  CHECK(sf_device_open_by_name(name, flags, &d));
  info->struct_size = sizeof *info;
  CHECK(sf_device_get_info(d, info));
  printf("device: %s -- %s%s\n", info->name, info->hardware_id, info->is_simulator ? " [SIMULATOR]" : "");
  return d;
}

static sf_buffer_t new_buffer(sf_device_t d, uint64_t bytes, const void *init) {
  sf_buffer_t b;
  CHECK(sf_buffer_create(d, bytes, SF_MEM_READ_WRITE, &b));
  if (init) CHECK(sf_buffer_write(b, 0, init, bytes));
  return b;
}

static inline uint32_t lcg(uint32_t *s) { return *s = *s * 1664525u + 1013904223u; }
#endif
