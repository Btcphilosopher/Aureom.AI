/* SilicaFlux.OS example 2 -- matrix multiplication on the tensor engine.
 *
 *   example_matmul [cpu|rtl-cc|rtl-hostlink] [M N K]
 *
 * C(int32) = A(int8) x B(int8), row-major, checked against a naive triple loop.
 * Reports where it executed, the engine's cycle count and MACs per engine cycle.
 */
#include "common.h"

int main(int argc, char **argv) {
  sf_device_info info;
  int nd = argc > 4 ? 2 : argc;   /* device name only */
  sf_device_t dev = open_from_args(nd, argv, &info);
  uint32_t M = argc > 4 ? (uint32_t)atoi(argv[2]) : 24, N = argc > 4 ? (uint32_t)atoi(argv[3]) : 20,
           K = argc > 4 ? (uint32_t)atoi(argv[4]) : 96;
  int8_t *A = malloc((size_t)M * K), *B = malloc((size_t)K * N);
  int32_t *C = malloc(4ull * M * N);
  uint32_t seed = 7;
  for (size_t i = 0; i < (size_t)M * K; i++) A[i] = (int8_t)lcg(&seed);
  for (size_t i = 0; i < (size_t)K * N; i++) B[i] = (int8_t)lcg(&seed);
  sf_buffer_t a = new_buffer(dev, (uint64_t)M * K, A), b = new_buffer(dev, (uint64_t)K * N, B);
  sf_buffer_t c = new_buffer(dev, 4ull * M * N, NULL);
  sf_queue_t q;
  CHECK(sf_queue_create(dev, 4, &q));
  sf_gemm_desc g = {sizeof g};
  g.m = M; g.n = N; g.k = K;
  g.a_type = g.b_type = SF_DTYPE_I8;
  g.c_type = SF_DTYPE_I32;
  sf_cmd_t id;
  CHECK(sf_tensor_gemm(q, a, b, c, &g, &id));
  sf_cmd_result r = {sizeof r};
  CHECK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r));
  CHECK(sf_buffer_read(c, 0, C, 4ull * M * N));
  size_t bad = 0;
  for (uint32_t i = 0; i < M; i++)
    for (uint32_t j = 0; j < N; j++) {
      int32_t s = 0;
      for (uint32_t k = 0; k < K; k++) s += (int32_t)A[i * K + k] * (int32_t)B[k * N + j];
      bad += s != C[i * N + j];
    }
  printf("  C[%ux%u] = A[%ux%u] x B[%ux%u] (int8 -> int32) on %s%s\n", M, N, M, K, K, N, exec_name(r.exec_target),
         (r.flags & SF_RESULT_HOST_ASSISTED) ? " (host-assisted operand layout)" : "");
  printf("  %llu MACs in %llu engine cycles = %.2f MACs/cycle; %u device commands\n", (unsigned long long)r.macs,
         (unsigned long long)r.engine_cycles, r.engine_cycles ? (double)r.macs / (double)r.engine_cycles : 0.0,
         r.device_commands);
  printf("  C[0][0..3] = %d %d %d %d\n", C[0], C[1], C[2], C[3]);
  printf("%s: %zu of %u elements differ from the naive reference\n", bad ? "FAILED" : "PASSED", bad, M * N);
  sf_device_close(dev);
  free(A); free(B); free(C);
  return bad ? 1 : 0;
}
