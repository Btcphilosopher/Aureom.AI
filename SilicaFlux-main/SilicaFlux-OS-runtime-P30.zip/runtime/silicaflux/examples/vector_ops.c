/* SilicaFlux.OS example 1 -- vector numerical operations.
 *
 *   example_vector_ops [cpu|rtl-cc|...] [--allow-cpu-fallback]
 *
 * axpy, add, mul, fma and a dot product on the device, each checked against an
 * independent reference computed here with the host's IEEE float arithmetic
 * (round-to-nearest-even, fmaf for the fused operations).  The dot product is
 * checked bit-for-bit against the device's DEFINED summation order (per beat of
 * `vector_lanes` elements a pairwise tree, then sequential accumulation), and
 * its accuracy is reported against a double-precision sum.
 */
#include <math.h>

#include "common.h"

static uint32_t bits(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }

/* the device's reduction order (HPC Module 03 REDUCTION.md section 1), independent C implementation */
static float defined_order_dot(const float *a, const float *b, size_t n, unsigned lanes) {
  float acc = 0.0f, v[64];
  int present[64];
  for (size_t g = 0; g * lanes < n; g++) {
    for (unsigned l = 0; l < lanes; l++) {
      size_t e = g * lanes + l;
      present[l] = e < n;
      if (present[l]) v[l] = a[e] * b[e];
    }
    for (unsigned w = lanes; w > 1; w /= 2)
      for (unsigned i = 0; i < w / 2; i++) {
        int L = present[2 * i], R = present[2 * i + 1];
        v[i] = L && R ? v[2 * i] + v[2 * i + 1] : (L ? v[2 * i] : v[2 * i + 1]);
        present[i] = L || R;
      }
    if (present[0]) acc = acc + v[0];
  }
  return acc;
}

int main(int argc, char **argv) {
  sf_device_info info;
  sf_device_t dev = open_from_args(argc, argv, &info);
  const size_t n = 2000;
  float *x = malloc(4 * n), *y = malloc(4 * n), *z = malloc(4 * n), *out = malloc(4 * n);
  uint32_t seed = 2026;
  for (size_t i = 0; i < n; i++) {
    x[i] = (float)((int32_t)lcg(&seed) >> 8) / 65536.0f;
    y[i] = (float)((int32_t)lcg(&seed) >> 8) / 65536.0f;
    z[i] = (float)((int32_t)lcg(&seed) >> 8) / 65536.0f;
  }
  sf_buffer_t bx = new_buffer(dev, 4 * n, x), by = new_buffer(dev, 4 * n, y), bz = new_buffer(dev, 4 * n, z);
  sf_buffer_t bd = new_buffer(dev, 4 * n, NULL), bs = new_buffer(dev, 4, NULL);
  sf_queue_t q;
  CHECK(sf_queue_create(dev, 8, &q));
  const float alpha = 2.5f;
  int failures = 0;
  for (int op = 0; op < 4; op++) {
    static const char *names[] = {"axpy  d = 2.5*x + y", "add   d = x + y", "mul   d = x * y", "fma   d = x*y + z"};
    sf_cmd_t id;
    if (op == 0) CHECK(sf_vector_axpy(q, alpha, bx, by, bd, n, NULL, &id));
    if (op == 1) CHECK(sf_vector_add(q, bx, by, bd, n, SF_DTYPE_F32, NULL, &id));
    if (op == 2) CHECK(sf_vector_mul(q, bx, by, bd, n, SF_DTYPE_F32, NULL, &id));
    if (op == 3) CHECK(sf_vector_fma(q, bx, by, bz, bd, n, NULL, &id));
    sf_cmd_result r = {sizeof r};
    CHECK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r));
    CHECK(sf_buffer_read(bd, 0, out, 4 * n));
    size_t bad = 0;
    for (size_t i = 0; i < n; i++) {
      volatile float ref = op == 0 ? fmaf(alpha, x[i], y[i]) : op == 1 ? x[i] + y[i] : op == 2 ? x[i] * y[i]
                                                                                     : fmaf(x[i], y[i], z[i]);
      bad += bits(ref) != bits(out[i]);
    }
    printf("  %-22s %zu elements on %-15s %8llu engine cycles, %u device cmds: %s\n", names[op], n,
           exec_name(r.exec_target), (unsigned long long)r.engine_cycles, r.device_commands,
           bad ? "MISMATCH" : "bit-exact vs host IEEE reference");
    failures += bad != 0;
  }
  sf_cmd_t id;
  CHECK(sf_vector_dot(q, bx, by, bs, n, NULL, &id));
  sf_cmd_result r = {sizeof r};
  CHECK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r));
  float dot;
  CHECK(sf_buffer_read(bs, 0, &dot, 4));
  double exact = 0;
  for (size_t i = 0; i < n; i++) exact += (double)x[i] * (double)y[i];
  unsigned lanes = info.vector_lanes ? info.vector_lanes : 4;
  float ord = defined_order_dot(x, y, n, lanes);
  printf("  dot   s = sum x*y        %g on %s; defined %u-lane order: %s; |rel. error| vs double = %.2e\n", dot,
         exec_name(r.exec_target), lanes, bits(ord) == bits(dot) ? "bit-exact" : "MISMATCH",
         fabs((dot - exact) / exact));
  failures += bits(ord) != bits(dot);
  sf_queue_destroy(q);
  sf_device_close(dev);
  free(x); free(y); free(z); free(out);
  printf("%s\n", failures ? "FAILED" : "PASSED");
  return failures ? 1 : 0;
}
