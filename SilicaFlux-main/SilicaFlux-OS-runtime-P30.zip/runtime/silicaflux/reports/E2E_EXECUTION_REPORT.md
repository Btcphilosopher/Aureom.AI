# SilicaFlux.OS — end-to-end execution report

Final run on the frozen sources of this archive, 2026-11-10, on the build machine described below. Every number here
is copied from the logs in `reports/logs/` and the JSON files next to this report; nothing was run on SilicaFlux
hardware (none exists). "RTL simulation" means Verilator 5.020 models of the unmodified SilicaFlux RTL.

## 1. Environment

| Item | Value |
|---|---|
| Host | Intel Xeon @ 2.10 GHz, 4 cores, Ubuntu 24.04, Linux 6.18 |
| Toolchain | GCC 13.3, CMake 3.28, Ninja, Python 3.13, Verilator 5.020, riscv64-unknown-elf-gcc 13.2 |
| Library | `silicaflux 1.0.0 (C ABI 1.0; backends: cpu, rtl-cc, rtl-hostlink, pcie-vfio)` |
| Firmware | `controlcore_rt` 2.0, SFRQ ABI 1.0, SHA-256 `47b8d260…ff7e57d` (rebuilt byte-identical to `firmware/prebuilt/`) |
| Devices discovered | `cpu` (CPU reference), `rtl-cc` (RTL simulator), `rtl-hostlink` (RTL simulator); **no physical SilicaFlux PCIe function** |

## 2. Build from scratch

`cmake -S runtime/silicaflux -B build -G Ninja` (0.6 s) and `cmake --build build` (**40 s**, 4 cores: both Verilated
models, three firmware images, library, CLI, examples, tests) — `logs/configure.log`, `logs/clean_build.log`. Zero
compiler warnings in project code (`-Wall -Wextra`); the firmware builds with `-Wall -Wextra` warning-free.
`libsilicaflux.so.1` exports exactly 43 `sf_*` symbols (version `SILICAFLUX_1.0`).

## 3. Test suite — 27 / 27 passed (`logs/ctest_full_run.log`, 49.5 s wall with `-j 4`)

| ctest | Checks | Time | Content |
|---|---:|---:|---|
| `reference_arithmetic` | 37 | 0.6 s | soft-float vs host FPU: **1 200 000 ops, 0 mismatches**; RMM vs binary128: **200 000 ops, 0 mismatches**; dot order; requantisation; GEMM |
| `api_cpu` | 378 | 0.1 s | C API on the CPU backend (handles, ownership, permissions, views, queue full, ordering, interruption, kernels, trace, counters) |
| `hardware_absent` | 10 | 0.0 s | a real virtio PCI function is listed as unavailable and refused; nothing reported as SilicaFlux hardware |
| `firmware_reproducible` | 3 images | 0.0 s | rebuilt images byte-identical to `firmware/prebuilt/SHA256SUMS` |
| `api_guard_current` | — | 0.0 s | generated exception firewall matches the header |
| `rtl_cc_kernels` | 321 | 17.4 s | see §4 |
| `rtl_cc_faults` | 58 | 12.5 s | invalid tile/tensor descriptors rejected by the engines; DMA read errors (tile, system DMA, tensor) reported and recovered; host timeout without hang; firmware timeout → quiesced accelerator reset |
| `rtl_cc_recovery` | 91 | 19.5 s | reset during a running GEMM (both commands `ABORTED`, queue reusable); RAS warning & fatal events; interruption from another thread; full reset |
| `rtl_cc_compat` | 4 | 20.2 s | stock P21 firmware, SFRQ ABI 2.0 firmware, CRC-corrupted image → `SF_ERR_INCOMPATIBLE_VERSION`; missing image → `SF_ERR_NO_DEVICE` |
| `rtl_cc_selftest` | 14 | 24.8 s | P21 firmware self-test under the runtime firmware: **231 checks, 0 failures** (2 026 463 device cycles) |
| `rtl_cc_lost` | 19 | 48.2 s | device memory stops answering → completion never arrives (`TIMEOUT`) → watchdog reset detected → `SF_ERR_DEVICE_LOST` → `SF_RESET_FULL` → GEMM correct |
| `rtl_hostlink` | 103 | 0.4 s | see §5 |
| `e2e_all_backends` | 30 steps | 7.2 s | §6 |
| 14 × `example_*` | — | 0–10 s | §7 |

Total: **1 035 checks** in the test binaries plus 14 example programs and the 3-device end-to-end flow; 0 failures.

## 4. RTL ControlCore system — kernels (`rtl_cc_kernels`, from `logs/ctest_all_test_output.log`)

| Workload | Result |
|---|---|
| FP32 add / mul / fma / axpy, 517 elements incl. inf, NaN, signalling NaN, subnormals, 5 rounding modes (20 commands) | **0 value mismatches, 0 IEEE-flag mismatches** vs the independent reference; 143 550 tile cycles |
| INT32 add / mul, 9 001 elements (3 KERNEL chunks each) | bit-exact |
| Dot product n = 7 / 4 096 / 10 007 (3 chained KERNELs), RNE / RDN / RMM | bit-exact with the defined 4-lane order, flags equal |
| GEMM INT32 1×1×1, 17×13×29, 9×11×40 (lda padded), 32×24×200 | 0 byte mismatches; 92 / 3 818 / 2 259 / 46 094 tensor cycles |
| GEMM requantised INT8 9×11×40, all 5 rounding modes (+ReLU) | 0 byte mismatches, saturation flag equal to the reference |
| Exact hardware counters after `PERF_CLEAR` | `tensor.macs = 3 840` for a 12×8×40 GEMM, `tile.vec_elems = 640`, `tile.kernel_cmds = 1` |
| Differential (same workload on `cpu` and `rtl-cc`) | GEMM, FMA (RUP) and dot outputs byte-identical |
| Queue depth 2: third submission | `SF_ERR_QUEUE_FULL`, nothing submitted; completion in order; the 2nd GEMM waited 78 532 device cycles (firmware-measured) |

## 5. RTL HostLink device (`rtl_hostlink`)

| Workload | Result |
|---|---|
| DMA round trip 5 000 B, unaligned 13-byte patch at offset 3 (read-modify-write), tail read | bit-exact |
| GEMM 4×4×64 / 17×13×29 / 9×11×40 strided C / 8×8×1500 (K-split with engine ACC) / 24×20×128 | 0 byte mismatches; 6 / 26 / 15 / 23 / 37 HostLink commands; 135 / 1 300 / 783 / 12 056 / 7 890 tensor-engine cycles; flagged host-assisted layout |
| Vector, copy, requantised GEMM, raw descriptors | `SF_ERR_UNSUPPORTED` (honest capability set) |
| Host-side PCIe/IOMMU fault on the staging pools | transfer and GEMM → `SF_ERR_DMA` (CQE status 7 HOST_BUS_ERROR); cleared → correct |
| 16 queued 64×64×256 GEMMs | 17th `SF_ERR_QUEUE_FULL`; 1 ms wait → `SF_ERR_TIMEOUT`; engine reset → all `ABORTED`; full (hot) reset → correct |
| Explicit CPU fallback (`SF_OPEN_ALLOW_CPU_FALLBACK`) | vector add correct and reported `SF_EXEC_CPU_FALLBACK`; GEMM in the same queue still `SF_EXEC_RTL_SIMULATION` |

## 6. End-to-end flow on every backend (`e2e_report.json`, `logs/e2e_run.log`)

GEMM 32×24×80 INT8 → INT32, seed 20261110, ten steps (initialise · allocate · transfer · submit · wait · retrieve ·
compare · counters · free · shut down):

| Device | Executed on | Steps | Mismatches | Device evidence | Wait (host ms) |
|---|---|---|---:|---|---:|
| `cpu` | CPU reference | 10 / 10 OK | 0 / 768 | 9 runtime counters | 0.05 |
| `rtl-cc` | RTL simulation | 10 / 10 OK | 0 / 768 | 18 933 tensor cycles, 1 command; 80 counters (65 hardware); `tensor.macs = 61 440 = 32·24·80` | 237 |
| `rtl-hostlink` | RTL simulation (host-assisted layout) | 10 / 10 OK | 0 / 768 | 8 016 tensor-engine cycles, 57 HostLink commands; 22 counters (10 hardware) | 38 |
| physical PCIe | — | not run | — | no SilicaFlux function exists | — |

Host times measure the simulator, not the device.

## 7. Examples (each verified against its own independent reference)

| Example | cpu | rtl-cc | rtl-hostlink |
|---|---|---|---|
| `vector_ops` (axpy, add, mul, fma, dot) | PASS | PASS — bit-exact vs host IEEE; dot bit-exact with the defined order, rel. error 9.9e-8 vs double | unsupported |
| `matmul` 24×20×96 | PASS | PASS — 13 802 tensor cycles (3.34 MAC/cycle) | PASS — 5 970 engine cycles, 37 commands |
| `stencil` (heat equation, 25 steps × 3 commands on views) | PASS | PASS — bit-exact vs host IEEE; max deviation from the exact discrete solution 1.28e-7 | unsupported |
| `int8_inference` (2-layer quantised MLP) | PASS | PASS — both layers on TC08, H device-resident | correctly refused (exit 3); with fallback: layer 1 on CPU, marked |
| `mixed_workload` (host quantise/softmax + device GEMM, pipelined) | PASS | PASS — 32/32 rows agree with float reference | PASS |

## 8. Benchmarks (`benchmarks/SUMMARY.md`, fixed seeds; deterministic — identical in repeated runs)

| Device | Workload | Engine cycles | Work per engine cycle |
|---|---|---:|---:|
| rtl-cc | vector FADD 4 096 | 52 256 | 0.078 elements |
| rtl-cc | dot 4 096 | 35 888 | 0.114 elements |
| rtl-cc | GEMM 64×64×256 | 288 675 | 3.63 MACs (16-MAC array; memory-port bound, TC08 docs/09) |
| rtl-hostlink | GEMM 64×64×256 | 132 864 (+ DMA) | 7.89 MACs (engine only, 333 HostLink commands) |

## 9. CLI session (`logs/cli_session.txt`)

`silicaflux info` (three devices, simulators labelled "SIMULATOR – not silicon"), `run gemm` on rtl-cc with a trace
(`trace_gemm_rtl_cc.json`, converted to `trace_gemm_rtl_cc.chrome.json`), `run gemm-q8 --rounding 4`, `run gemm` on
rtl-hostlink (all "PASS, bit-exact" against the CPU reference device), `run vector-add` on rtl-hostlink (exit 3,
unsupported), `selftest` on rtl-cc (firmware suite 231/231 + 8 kernel checks), `errors --inject warning`,
`counters` on rtl-hostlink.

## 10. Definition of done

*A user can build the software, submit a vector or tensor workload through the documented API, retrieve correct
results and inspect genuine execution status:* **met on the CPU reference and on the two RTL simulation backends**
(build §2, workloads §4–§7, execution target, device cycles, hardware counters and RAS status in every result).
Not met on physical hardware, which does not exist; the hardware backend compiles and handles the absent device
(docs/09).
