/*
 * SilicaFlux.OS -- SilicaFlux Compute API, C ABI version 1.0
 * Aureom.AI / SilicaFlux-HPC, Project 30.
 *
 * This header is the ONLY stable interface of libsilicaflux.  It is plain C99,
 * has no dependencies beyond <stddef.h>/<stdint.h>, and is usable from C, C++
 * and any FFI.  The ABI rules are in docs/03_C_ABI.md; in short:
 *
 *   - Every handle is an opaque 64-bit value (index + generation).  A released
 *     or never-valid handle is detected and rejected (SF_ERR_INVALID_*); it is
 *     never dereferenced.
 *   - Every struct that crosses the ABI starts with `uint32_t struct_size`.  The
 *     caller sets it to sizeof(struct); the library fills / reads only the fields
 *     that exist in both its own and the caller's version.
 *   - A minor version only appends functions, enum values and struct fields.
 *     A major version change is incompatible: check sf_get_api_version().
 *   - Functions return sf_status (0 = success, > 0 = "not yet", < 0 = error).
 *     No function aborts the process, throws, or waits without a bound.
 *
 * Execution honesty: every completed command reports WHERE it executed
 * (sf_exec_target): physical hardware, an RTL simulation of the SilicaFlux
 * RTL, the CPU reference backend, or an explicitly requested CPU fallback.
 * A backend never reports a computation it did not perform.
 */
#ifndef SILICAFLUX_H
#define SILICAFLUX_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
#  define SF_API __declspec(dllimport)
#elif defined(__GNUC__)
#  define SF_API __attribute__((visibility("default")))
#else
#  define SF_API
#endif

/* ===================================================================== versions */
#define SF_API_VERSION_MAJOR 1
#define SF_API_VERSION_MINOR 0
#define SF_API_VERSION ((SF_API_VERSION_MAJOR << 16) | SF_API_VERSION_MINOR)

/* Returns (major << 16) | minor of the loaded library.  A program built against
 * major M must refuse a library whose major differs. */
SF_API uint32_t sf_get_api_version(void);
/* Library build string, e.g. "silicaflux 1.0.0 (cpu, rtl-cc, rtl-hostlink, pcie-vfio)". */
SF_API const char *sf_get_build_info(void);

/* ===================================================================== status */
typedef int32_t sf_status;
enum {
  SF_OK                       = 0,
  SF_PENDING                  = 1,    /* poll: command not complete yet (not an error) */
  SF_ERR_INVALID_ARGUMENT     = -1,
  SF_ERR_NO_DEVICE            = -2,   /* device absent / not discoverable / backend not built */
  SF_ERR_UNSUPPORTED          = -3,   /* operation, precision or dimension not supported by this device */
  SF_ERR_INCOMPATIBLE_VERSION = -4,   /* firmware / hardware ABI revision not supported by this library */
  SF_ERR_OUT_OF_MEMORY        = -5,   /* device memory (or host staging memory) exhausted */
  SF_ERR_INVALID_DEVICE       = -6,   /* bad / closed device handle */
  SF_ERR_INVALID_BUFFER       = -7,   /* bad / released buffer handle, or buffer of another device */
  SF_ERR_INVALID_QUEUE        = -8,   /* bad / destroyed queue handle */
  SF_ERR_INVALID_COMMAND      = -9,   /* unknown command id, or command rejected by device validation */
  SF_ERR_OUT_OF_RANGE         = -10,  /* offset / size outside a buffer */
  SF_ERR_PERMISSION           = -11,  /* access not allowed by the buffer's access flags */
  SF_ERR_BUSY                 = -12,  /* resource owned by the device (pending commands) / device already open */
  SF_ERR_QUEUE_FULL           = -13,  /* submission would overwrite an unconsumed ring slot: nothing submitted */
  SF_ERR_TIMEOUT              = -14,  /* bounded wait expired (host side) or device command timeout */
  SF_ERR_DMA                  = -15,  /* a data transfer failed (bus / IOMMU / memory error) */
  SF_ERR_DEVICE               = -16,  /* the engine reported an execution error (see device_status/device_error) */
  SF_ERR_ABORTED              = -17,  /* command discarded by a reset or queue teardown */
  SF_ERR_DEVICE_LOST          = -18,  /* device unresponsive or fatal: sf_device_reset(SF_RESET_FULL) required */
  SF_ERR_INTERRUPTED          = -19,  /* wait interrupted by sf_interrupt() (command is still pending) */
  SF_ERR_INTERNAL             = -20   /* library bug / inconsistent state (please report) */
};
/* Static English description of a status code (never NULL). */
SF_API const char *sf_status_string(sf_status s);
/* Thread-local detail message for the last error returned on this thread (never NULL). */
SF_API const char *sf_last_error_detail(void);

/* ===================================================================== handles */
typedef uint64_t sf_device_t;
typedef uint64_t sf_buffer_t;
typedef uint64_t sf_queue_t;
typedef uint64_t sf_cmd_t;          /* per-queue command id, > 0 */
#define SF_NULL_HANDLE 0u
#define SF_CMD_ALL     0u           /* sf_queue_wait: every command submitted so far */

/* ===================================================================== time */
/* Timeouts are in milliseconds of DEVICE time: wall-clock time for hardware and
 * the CPU reference, simulated time (cycles / nominal clock) for RTL
 * simulators.  Simulators also enforce a wall-clock guard (docs/05).  There is
 * no infinite wait. */
#define SF_TIMEOUT_DEFAULT UINT64_MAX     /* the device's default (sf_device_info.default_timeout_ms) */

/* ===================================================================== enums */
typedef enum sf_device_kind {
  SF_DEVICE_CPU_REFERENCE = 1,      /* host CPU reference implementation of the SilicaFlux kernels */
  SF_DEVICE_RTL_SIMULATOR = 2,      /* Verilated SilicaFlux RTL: cycle-accurate model, NOT silicon */
  SF_DEVICE_HARDWARE      = 3       /* physical device (PCIe) */
} sf_device_kind;

typedef enum sf_exec_target {
  SF_EXEC_NONE            = 0,      /* not executed (rejected / aborted) */
  SF_EXEC_HARDWARE        = 1,
  SF_EXEC_RTL_SIMULATION  = 2,
  SF_EXEC_CPU_REFERENCE   = 3,      /* the device IS the CPU reference backend */
  SF_EXEC_CPU_FALLBACK    = 4       /* device lacked the op; CPU computed it because SF_OPEN_ALLOW_CPU_FALLBACK */
} sf_exec_target;

typedef enum sf_dtype {
  SF_DTYPE_F32 = 1,
  SF_DTYPE_I32 = 2,
  SF_DTYPE_I8  = 3
} sf_dtype;

typedef enum sf_rounding {          /* IEEE 754 / RISC-V frm encoding */
  SF_ROUND_NEAREST_EVEN = 0,
  SF_ROUND_TOWARD_ZERO  = 1,
  SF_ROUND_DOWN         = 2,
  SF_ROUND_UP           = 3,
  SF_ROUND_NEAREST_MAX  = 4         /* round to nearest, ties away from zero */
} sf_rounding;

/* capability bits (sf_device_info.caps) */
#define SF_CAP_VECTOR_F32     (1u << 0)   /* add / mul / fma / axpy, FP32, all 5 rounding modes */
#define SF_CAP_VECTOR_I32     (1u << 1)   /* add / mul, INT32 (wrapping) */
#define SF_CAP_DOT_F32        (1u << 2)   /* dot product (defined reduction order) */
#define SF_CAP_GEMM_I8_I32    (1u << 3)   /* C(int32) = A(int8) * B(int8) */
#define SF_CAP_GEMM_I8_Q8     (1u << 4)   /* requantised int8 output (+ optional ReLU) */
#define SF_CAP_COPY           (1u << 5)   /* device-to-device buffer copy */
#define SF_CAP_HW_COUNTERS    (1u << 6)   /* hardware performance counters */
#define SF_CAP_RAS            (1u << 7)   /* RAS error reporting */
#define SF_CAP_DEVICE_TIMESTAMPS (1u << 8)/* per-command device cycle stamps */
#define SF_CAP_FAULT_INJECTION (1u << 9)  /* sf_debug_inject (simulators only) */
#define SF_CAP_FIRMWARE_SELFTEST (1u << 10)

/* open flags */
#define SF_OPEN_ALLOW_CPU_FALLBACK (1u << 0)  /* run ops the device lacks on the CPU, marked SF_EXEC_CPU_FALLBACK */
#define SF_OPEN_TRACE_CONSOLE      (1u << 1)  /* print the device firmware console (diagnostics) to stderr */

/* ===================================================================== discovery */
#define SF_NAME_MAX 64
#define SF_DESC_MAX 160

typedef struct sf_device_info {
  uint32_t struct_size;
  uint32_t index;
  char     name[SF_NAME_MAX];           /* "cpu", "rtl-cc", "rtl-hostlink", "pcie:0000:01:00.0" */
  char     description[SF_DESC_MAX];
  uint32_t kind;                        /* sf_device_kind */
  uint32_t is_simulator;                /* 1 for RTL simulators (never claims to be hardware) */
  uint32_t available;                   /* 0: listed but cannot be opened (reason in description) */
  uint32_t caps;                        /* SF_CAP_*: valid after open (0 before, except CPU) */
  /* versions -- valid after open */
  uint32_t device_abi_version;          /* (major<<16)|minor of the host<->device ABI */
  uint32_t firmware_version;            /* 0 if the device has no firmware */
  uint32_t hardware_revision;           /* device-reported revision / configuration word, 0 if none */
  char     hardware_id[SF_NAME_MAX];    /* e.g. "SilicaFlux-HPC P21 ControlCore + M08 tile + TC08" */
  /* limits -- valid after open */
  uint64_t device_memory_bytes;         /* allocatable by sf_buffer_create */
  uint32_t min_alignment;               /* every buffer is aligned to at least this */
  uint32_t max_queue_depth;
  uint32_t max_queues;
  uint32_t vector_lanes;                /* reduction tree width (defines dot-product order) */
  uint64_t max_vector_elements;         /* per sf_vector_* call */
  uint32_t gemm_max_m, gemm_max_n, gemm_max_k;
  uint32_t tensor_array_rows, tensor_array_cols;
  uint32_t nominal_clock_mhz;           /* simulators: clock used to convert cycles <-> ms (assumed, NOT measured) */
  uint64_t default_timeout_ms;
} sf_device_info;

SF_API sf_status sf_get_device_count(uint32_t *count);
/* Static information; full capabilities/limits are filled by sf_device_get_info after open. */
SF_API sf_status sf_get_device_info(uint32_t index, sf_device_info *info);

/* ===================================================================== device */
SF_API sf_status sf_device_open(uint32_t index, uint32_t flags, sf_device_t *dev);
SF_API sf_status sf_device_open_by_name(const char *name, uint32_t flags, sf_device_t *dev);
/* Waits (bounded) for outstanding commands, destroys queues, releases buffers, shuts the device down. */
SF_API sf_status sf_device_close(sf_device_t dev);
SF_API sf_status sf_device_get_info(sf_device_t dev, sf_device_info *info);

typedef enum sf_reset_level {
  SF_RESET_ENGINES = 1,   /* abort every queue, reset the compute engines; device memory and firmware kept */
  SF_RESET_FULL    = 2    /* cold reset: firmware reloaded, device memory content undefined */
} sf_reset_level;
/* Every command outstanding at the reset completes with SF_ERR_ABORTED.  Queues and buffers stay valid. */
SF_API sf_status sf_device_reset(sf_device_t dev, sf_reset_level level);

typedef enum sf_device_state {
  SF_STATE_READY = 1, SF_STATE_DEGRADED = 2, SF_STATE_ERROR = 3, SF_STATE_LOST = 4
} sf_device_state;

typedef struct sf_device_status {
  uint32_t struct_size;
  uint32_t state;                 /* sf_device_state */
  sf_status last_error;           /* last device-level error (SF_OK if none) */
  uint32_t ras_status;            /* raw RAS status register (0 if no RAS) */
  uint32_t ras_warnings;          /* corrected / warning events since reset */
  uint32_t ras_fatals;            /* fatal events since reset */
  uint32_t ras_first_source;      /* source id of the first error (device specific) */
  uint32_t ras_first_address;
  uint32_t ras_warning_sources;   /* bitmask of warning sources seen */
  uint32_t ras_fatal_sources;     /* bitmask of fatal sources seen */
  uint32_t commands_failed;       /* commands completed with an error since open */
  uint32_t commands_completed;
  uint32_t resets;                /* sf_device_reset calls that completed */
  char     detail[SF_DESC_MAX];   /* human-readable summary */
} sf_device_status;
SF_API sf_status sf_device_get_status(sf_device_t dev, sf_device_status *status);

/* Device-resident self-test (firmware test suite) where the device has one. */
typedef struct sf_selftest_result {
  uint32_t struct_size;
  uint32_t checks;
  uint32_t failures;
  uint64_t device_cycles;
  char     detail[SF_DESC_MAX];
} sf_selftest_result;
SF_API sf_status sf_device_selftest(sf_device_t dev, uint32_t mask, sf_selftest_result *result);

/* Diagnostic console text produced by device firmware since the last call (may be empty). */
SF_API sf_status sf_device_read_console(sf_device_t dev, char *buf, size_t cap, size_t *len);

/* ===================================================================== memory */
/* Device access permissions (what COMMANDS may do with the buffer) */
#define SF_MEM_DEVICE_READ   (1u << 0)
#define SF_MEM_DEVICE_WRITE  (1u << 1)
/* Host access permissions (what sf_buffer_write / sf_buffer_read may do) */
#define SF_MEM_HOST_WRITE    (1u << 2)
#define SF_MEM_HOST_READ     (1u << 3)
#define SF_MEM_READ_WRITE    (SF_MEM_DEVICE_READ | SF_MEM_DEVICE_WRITE | SF_MEM_HOST_WRITE | SF_MEM_HOST_READ)
#define SF_MEM_INPUT         (SF_MEM_DEVICE_READ | SF_MEM_HOST_WRITE | SF_MEM_HOST_READ)
#define SF_MEM_OUTPUT        (SF_MEM_DEVICE_WRITE | SF_MEM_HOST_READ | SF_MEM_DEVICE_READ)

/* Allocates device memory (aligned to sf_device_info.min_alignment, content zeroed).
 * Fails with SF_ERR_OUT_OF_MEMORY when no contiguous range is free. */
SF_API sf_status sf_buffer_create(sf_device_t dev, uint64_t size, uint32_t flags, sf_buffer_t *buf);
/* A view of [offset, offset+size) of `parent` sharing its memory (keeps the parent alive).
 * offset must be a multiple of 4.  Access flags must be a subset of the parent's. */
SF_API sf_status sf_buffer_create_view(sf_buffer_t parent, uint64_t offset, uint64_t size, uint32_t flags,
                                       sf_buffer_t *view);
/* Drops the handle.  Device memory is freed only after every command that uses it has completed. */
SF_API sf_status sf_buffer_release(sf_buffer_t buf);
/* Blocking host->device copy.  SF_ERR_BUSY if a pending command still owns the buffer. */
SF_API sf_status sf_buffer_write(sf_buffer_t buf, uint64_t offset, const void *src, uint64_t size);
/* Blocking device->host copy.  SF_ERR_BUSY if a pending command still owns the buffer. */
SF_API sf_status sf_buffer_read(sf_buffer_t buf, uint64_t offset, void *dst, uint64_t size);
/* Waits (bounded) until no pending command owns the buffer: ownership returns to the host. */
SF_API sf_status sf_buffer_sync(sf_buffer_t buf, uint64_t timeout_ms);

typedef struct sf_buffer_info {
  uint32_t struct_size;
  uint32_t flags;
  uint64_t size;
  uint64_t device_address;        /* informational: device bus address (never a host pointer) */
  uint32_t pending_commands;      /* > 0: owned by the device */
  uint32_t is_view;
} sf_buffer_info;
SF_API sf_status sf_buffer_get_info(sf_buffer_t buf, sf_buffer_info *info);

/* ===================================================================== queues */
/* In-order queue: commands complete in submission order.  `depth` = maximum
 * number of submitted-but-not-retired commands (bounded by max_queue_depth); a
 * submission beyond it returns SF_ERR_QUEUE_FULL without side effects. */
SF_API sf_status sf_queue_create(sf_device_t dev, uint32_t depth, sf_queue_t *queue);
/* Waits (bounded by the default timeout) for outstanding commands; aborts what remains. */
SF_API sf_status sf_queue_destroy(sf_queue_t queue);

typedef struct sf_cmd_result {
  uint32_t  struct_size;
  sf_status status;               /* SF_OK or the command's error */
  uint32_t  exec_target;          /* sf_exec_target */
  uint32_t  op;                   /* sf_op */
  uint32_t  flags;                /* SF_RESULT_* */
  uint32_t  device_status;        /* raw engine / firmware status code (device specific, 0 = OK) */
  uint32_t  device_error;         /* raw engine error code / detail */
  uint32_t  fp_flags;             /* IEEE flags OR-ed over the command: bit 4 NV, 3 DZ, 2 OF, 1 UF, 0 NX */
  uint64_t  engine_cycles;        /* cycles reported by the engine's completion record (device clock) */
  uint64_t  device_queue_cycles;  /* device time between the command becoming visible and its start */
  uint64_t  device_start_cycle;   /* device timestamps (device clock, 0 if unavailable) */
  uint64_t  device_end_cycle;
  uint64_t  host_submit_ns;       /* host monotonic clock (CLOCK_MONOTONIC) -- never mixed with cycles */
  uint64_t  host_complete_ns;
  uint64_t  elements;             /* vector elements / GEMM output elements computed */
  uint64_t  macs;                 /* multiply-accumulates performed by the device */
  uint32_t  device_commands;      /* hardware commands issued for this API call */
  uint32_t  scalar_bits;          /* dot product: FP32 result bits (also stored in the output buffer) */
} sf_cmd_result;

#define SF_RESULT_HOST_ASSISTED (1u << 0)  /* host re-laid-out operands (device consumes a fixed layout) */
#define SF_RESULT_SATURATED     (1u << 1)  /* int8 output: at least one value saturated */
#define SF_RESULT_FP_FLAGS      (1u << 2)  /* fp_flags is valid */
#define SF_RESULT_CHUNKED       (1u << 3)  /* split into several device commands (device_commands > 1) */

/* Non-blocking: SF_OK (result filled, command retired), SF_PENDING, or an error. */
SF_API sf_status sf_queue_poll(sf_queue_t queue, sf_cmd_t cmd, sf_cmd_result *result);
/* Bounded wait.  cmd = SF_CMD_ALL waits for everything submitted so far (result: the last command).
 * Returns the command's own status (e.g. SF_ERR_DEVICE) when it completed with an error, or
 * SF_ERR_TIMEOUT / SF_ERR_INTERRUPTED when the wait ended first (the command stays pending). */
SF_API sf_status sf_queue_wait(sf_queue_t queue, sf_cmd_t cmd, uint64_t timeout_ms, sf_cmd_result *result);
/* Number of submitted-but-not-retired commands. */
SF_API sf_status sf_queue_pending(sf_queue_t queue, uint32_t *count);

/* Interrupts every wait in progress (and the next one) in this process: they
 * return SF_ERR_INTERRUPTED.  Async-signal-safe (only sets an atomic flag). */
SF_API void sf_interrupt(void);
SF_API void sf_clear_interrupt(void);

/* ===================================================================== compute */
typedef enum sf_op {
  SF_OP_VECTOR_ADD = 1, SF_OP_VECTOR_MUL = 2, SF_OP_VECTOR_FMA = 3, SF_OP_VECTOR_AXPY = 4,
  SF_OP_VECTOR_DOT = 5, SF_OP_GEMM = 6, SF_OP_COPY = 7, SF_OP_NOP = 8, SF_OP_RAW = 9
} sf_op;

typedef struct sf_vector_opts {
  uint32_t struct_size;
  uint32_t rounding;              /* sf_rounding, F32 only (default RNE) */
} sf_vector_opts;

/* d[i] = a[i] + b[i]              (F32 or I32; n elements) */
SF_API sf_status sf_vector_add(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t d, uint64_t n,
                               sf_dtype dtype, const sf_vector_opts *opts, sf_cmd_t *cmd);
/* d[i] = a[i] * b[i]              (F32 or I32) */
SF_API sf_status sf_vector_mul(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t d, uint64_t n,
                               sf_dtype dtype, const sf_vector_opts *opts, sf_cmd_t *cmd);
/* d[i] = fma(a[i], b[i], c[i])    (F32, single rounding) */
SF_API sf_status sf_vector_fma(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t c, sf_buffer_t d,
                               uint64_t n, const sf_vector_opts *opts, sf_cmd_t *cmd);
/* d[i] = fma(alpha, x[i], y[i])   (F32) */
SF_API sf_status sf_vector_axpy(sf_queue_t q, float alpha, sf_buffer_t x, sf_buffer_t y, sf_buffer_t d,
                                uint64_t n, const sf_vector_opts *opts, sf_cmd_t *cmd);
/* out[0] = sum_i round(a[i]*b[i]), F32, in the device's DEFINED order (docs/04 §dot):
 * per beat of `vector_lanes` elements a pairwise tree, then sequential accumulation.
 * The value is also returned in sf_cmd_result.scalar_bits. */
SF_API sf_status sf_vector_dot(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t out, uint64_t n,
                               const sf_vector_opts *opts, sf_cmd_t *cmd);

typedef struct sf_gemm_desc {
  uint32_t struct_size;
  uint32_t m, n, k;               /* C[m x n] = A[m x k] * B[k x n], row-major */
  uint32_t a_type, b_type;        /* SF_DTYPE_I8 only */
  uint32_t c_type;                /* SF_DTYPE_I32 (exact) or SF_DTYPE_I8 (requantised) */
  uint32_t lda, ldb, ldc;         /* row strides in BYTES; 0 = dense */
  /* SF_DTYPE_I8 output: c = clamp(round_rm(acc * q_mult / 2^q_shift) + q_zero_point, -128, 127),
   * then max(c, q_zero_point) if relu */
  int32_t  q_mult;
  uint32_t q_shift;               /* 0..63 */
  int32_t  q_zero_point;          /* -128..127 */
  uint32_t relu;
  uint32_t rounding;              /* sf_rounding for requantisation */
} sf_gemm_desc;
SF_API sf_status sf_tensor_gemm(sf_queue_t q, sf_buffer_t a, sf_buffer_t b, sf_buffer_t c,
                                const sf_gemm_desc *desc, sf_cmd_t *cmd);

/* dst[0..size) = src[0..size)   (device-to-device; sizes multiple of 4) */
SF_API sf_status sf_buffer_copy(sf_queue_t q, sf_buffer_t src, sf_buffer_t dst, uint64_t size, sf_cmd_t *cmd);
/* Completes when every older command in the queue has completed. */
SF_API sf_status sf_queue_marker(sf_queue_t q, sf_cmd_t *cmd);

/* ===================================================================== profiling */
typedef enum sf_counter_source {
  SF_SRC_HARDWARE  = 1,   /* a hardware performance counter (RTL counter in simulation) */
  SF_SRC_FIRMWARE  = 2,   /* counted by device firmware */
  SF_SRC_SIMULATOR = 3,   /* provided by the simulation harness (not visible on hardware) */
  SF_SRC_RUNTIME   = 4    /* counted by this library on the host */
} sf_counter_source;

typedef enum sf_counter_unit {
  SF_UNIT_CYCLES = 1,     /* device clock cycles */
  SF_UNIT_EVENTS = 2,
  SF_UNIT_BYTES  = 3,
  SF_UNIT_OPS    = 4,     /* elements / flops */
  SF_UNIT_MACS   = 5,
  SF_UNIT_NANOSECONDS = 6 /* host clock */
} sf_counter_unit;

typedef struct sf_counter {
  char     name[48];      /* stable dotted name, e.g. "tensor.macs", "cc.cycles", "host.bytes_h2d" */
  uint64_t value;
  uint32_t unit;          /* sf_counter_unit */
  uint32_t source;        /* sf_counter_source */
} sf_counter;

/* Reads every counter the device exposes.  *count receives the number available;
 * at most `capacity` are written. */
SF_API sf_status sf_device_read_counters(sf_device_t dev, sf_counter *counters, uint32_t capacity,
                                         uint32_t *count);
SF_API sf_status sf_device_clear_counters(sf_device_t dev);

/* Standardised summary (fields not supported by the device are UINT64_MAX). */
typedef struct sf_perf_summary {
  uint32_t struct_size;
  uint32_t reserved;
  uint64_t device_cycles;         /* device clock since counter clear */
  uint64_t vector_elements;
  uint64_t vector_flops;
  uint64_t tensor_macs;
  uint64_t device_dma_bytes;      /* bytes moved by on-device DMA engines */
  uint64_t dma_stall_cycles;      /* memory-port request presented but not accepted */
  uint64_t sram_conflict_cycles;  /* scratchpad bank conflicts */
  uint64_t queue_full_cycles;     /* engine command queue full */
  uint64_t ras_events;
  uint64_t host_bytes_h2d;        /* library-counted (host clock domain) */
  uint64_t host_bytes_d2h;
  uint64_t host_transfer_ns;
} sf_perf_summary;
SF_API sf_status sf_device_perf_summary(sf_device_t dev, sf_perf_summary *summary);

/* Machine-readable trace: every command retired while tracing is recorded with
 * host timestamps (ns) and device cycles in SEPARATE fields.  Written as JSON
 * (schema "silicaflux-trace/1", docs/06) when tracing stops. */
SF_API sf_status sf_trace_start(sf_device_t dev, const char *json_path);
SF_API sf_status sf_trace_stop(sf_device_t dev);

/* ===================================================================== diagnostics / fault injection */
typedef enum sf_inject_kind {
  SF_INJECT_MEM_READ_ERROR  = 1,  /* reads of [address, +size) of `buf` answer with a bus error */
  SF_INJECT_MEM_WRITE_ERROR = 2,
  SF_INJECT_RAS_WARNING     = 3,  /* pulse the SoC RAS warning input */
  SF_INJECT_RAS_FATAL       = 4,  /* pulse the SoC RAS fatal input */
  SF_INJECT_HOST_DMA_ERROR  = 5,  /* host side of the transport answers DMA with an error (PCIe/IOMMU fault) */
  SF_INJECT_CLEAR           = 6,  /* remove every injected memory/DMA/hang fault */
  SF_INJECT_DEVICE_HANG     = 7   /* device memory stops accepting requests: the device becomes unresponsive */
} sf_inject_kind;
/* Simulators only (SF_CAP_FAULT_INJECTION); hardware returns SF_ERR_UNSUPPORTED. */
SF_API sf_status sf_debug_inject(sf_device_t dev, sf_inject_kind kind, sf_buffer_t buf, uint64_t offset,
                                 uint64_t size);
/* Submits a raw device descriptor (device-specific words) for validation tests.
 * Simulators and hardware only; the device validates it like any command. */
SF_API sf_status sf_debug_submit_raw(sf_queue_t q, uint32_t engine, const uint32_t *words, uint32_t nwords,
                                     sf_cmd_t *cmd);
#define SF_ENGINE_VECTOR 1u
#define SF_ENGINE_TENSOR 2u

#ifdef __cplusplus
}
#endif
#endif /* SILICAFLUX_H */
