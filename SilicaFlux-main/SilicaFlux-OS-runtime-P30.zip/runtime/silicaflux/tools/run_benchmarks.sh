#!/usr/bin/env bash
# SilicaFlux.OS -- reproducible benchmark run.
#
#   tools/run_benchmarks.sh [BUILD_DIR] [OUT_DIR] [--quick]
#
# Runs `silicaflux benchmark` (fixed seeds, fixed sizes) on every device that can be
# opened, writes OUT_DIR/<device>.json + .txt, the device list, the environment
# (tool versions, CPU, firmware image checksum) and OUT_DIR/SUMMARY.md.
# Device-side numbers are device clock cycles; host times measure this host (and,
# for RTL simulators, the simulator's speed -- never the device's speed).
set -euo pipefail
BUILD=${1:-build}
OUT=${2:-bench/results}
QUICK=${3:-}
HERE=$(cd "$(dirname "$0")/.." && pwd)
mkdir -p "$OUT"
"$BUILD/silicaflux" info --json > "$OUT/devices.json"
{
  echo "date_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "library: $("$BUILD/silicaflux" info | head -1)"
  echo "verilator: $(verilator --version 2>/dev/null || echo n/a)"
  echo "cxx: $(c++ --version | head -1)"
  echo "cpu: $(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2- | sed 's/^ //' || echo n/a)"
  echo "firmware_sha256: $(sha256sum "$BUILD/firmware/controlcore_rt.hex" 2>/dev/null | cut -d' ' -f1 || echo n/a)"
} > "$OUT/environment.txt"
for dev in $(python3 -c "import json; print(' '.join(d['name'] for d in json.load(open('$OUT/devices.json')) if d['opened']))"); do
  echo "== benchmark on $dev"
  "$BUILD/silicaflux" benchmark --device "$dev" --json "$OUT/$dev.json" $QUICK | tee "$OUT/$dev.txt"
done
python3 "$HERE/tools/bench_report.py" "$OUT" > "$OUT/SUMMARY.md"
echo "summary: $OUT/SUMMARY.md"
