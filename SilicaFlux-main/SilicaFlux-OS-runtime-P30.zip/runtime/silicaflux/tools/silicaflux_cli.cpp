// SilicaFlux.OS -- `silicaflux` diagnostics command-line tool.
//
//   silicaflux info      [--device NAME] [--json]
//   silicaflux selftest  [--device NAME] [--firmware-mask HEX]
//   silicaflux run OP    [--device NAME] [--n N] [--m M --k K] [--rounding R] [--seed S] [--trace FILE]
//                        OP: vector-add vector-mul vector-fma axpy dot gemm gemm-q8 copy
//   silicaflux benchmark [--device NAME] [--json FILE] [--quick]
//   silicaflux counters  [--device NAME] [--workload gemm:MxNxK|vector:N] [--clear]
//   silicaflux errors    [--device NAME] [--inject warning|fatal]
//
// Every command is backed by real functionality of the selected device; results
// are verified against the CPU reference device through the same public API.
// Ctrl-C interrupts a wait (sf_interrupt) and the device is closed cleanly.
// Exit status: 0 success, 1 failure / mismatch, 2 usage error, 3 not supported by the device.
#include <csignal>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <random>
#include <string>
#include <vector>

#include "silicaflux/silicaflux.h"

namespace {

std::map<std::string, std::string> g_opt;
std::vector<std::string> g_pos;

std::string opt(const std::string &k, const std::string &def = "") {
  auto it = g_opt.find(k);
  return it == g_opt.end() ? def : it->second;
}
long long opti(const std::string &k, long long def) {
  auto it = g_opt.find(k);
  return it == g_opt.end() ? def : strtoll(it->second.c_str(), nullptr, 0);
}
bool flag(const std::string &k) { return g_opt.count(k) != 0; }

const char *kind_str(uint32_t k) {
  return k == SF_DEVICE_CPU_REFERENCE ? "cpu-reference" : k == SF_DEVICE_RTL_SIMULATOR ? "rtl-simulator" : "hardware";
}
const char *target_str(uint32_t t) {
  switch (t) {
    case SF_EXEC_HARDWARE: return "hardware";
    case SF_EXEC_RTL_SIMULATION: return "RTL simulation";
    case SF_EXEC_CPU_REFERENCE: return "CPU reference";
    case SF_EXEC_CPU_FALLBACK: return "CPU FALLBACK";
  }
  return "not executed";
}

int die(sf_status s, const char *what) {
  fprintf(stderr, "silicaflux: %s: %s (%s)\n", what, sf_status_string(s), sf_last_error_detail());
  return s == SF_ERR_UNSUPPORTED ? 3 : 1;
}

void on_sigint(int) { sf_interrupt(); }

struct Opened {
  sf_device_t d = 0;
  sf_device_info info{};
  ~Opened() {
    if (d) sf_device_close(d);
  }
};

sf_status open_device(Opened &o, uint32_t flags = 0) {
  std::string name = opt("device", "cpu");
  sf_status s = sf_device_open_by_name(name.c_str(), flags, &o.d);
  if (s) return s;
  o.info.struct_size = sizeof o.info;
  return sf_device_get_info(o.d, &o.info);
}

std::string caps_str(uint32_t c) {
  static const char *n[] = {"vector-f32", "vector-i32", "dot-f32", "gemm-i8-i32", "gemm-i8-q8", "copy", "hw-counters",
                            "ras", "device-timestamps", "fault-injection", "firmware-selftest"};
  std::string s;
  for (int i = 0; i < 11; i++)
    if (c & (1u << i)) s += (s.empty() ? "" : " ") + std::string(n[i]);
  return s.empty() ? "-" : s;
}

// ------------------------------------------------------------------ info
int cmd_info() {
  bool json = flag("json");
  if (!json) printf("%s, C API %u.%u\n", sf_get_build_info(), sf_get_api_version() >> 16, sf_get_api_version() & 0xFFFF);
  uint32_t n = 0;
  sf_get_device_count(&n);
  if (json) printf("[\n");
  for (uint32_t i = 0; i < n; i++) {
    sf_device_info s{};
    s.struct_size = sizeof s;
    sf_get_device_info(i, &s);
    if (g_opt.count("device") && opt("device") != s.name) continue;
    sf_device_info full = s;
    sf_device_t d = 0;
    sf_status os = s.available ? sf_device_open(i, 0, &d) : SF_ERR_NO_DEVICE;
    if (os == SF_OK) {
      sf_device_get_info(d, &full);
      sf_device_close(d);
    }
    if (json) {
      printf("  {\"index\": %u, \"name\": \"%s\", \"kind\": \"%s\", \"is_simulator\": %u, \"available\": %u, "
             "\"opened\": %s, \"caps\": \"%s\", \"device_abi\": \"%u.%u\", \"firmware\": \"%u.%u\", "
             "\"hardware_id\": \"%s\", \"memory_bytes\": %llu}%s\n",
             i, s.name, kind_str(s.kind), s.is_simulator, s.available, os == SF_OK ? "true" : "false",
             caps_str(full.caps).c_str(), full.device_abi_version >> 16, full.device_abi_version & 0xFFFF,
             full.firmware_version >> 16, full.firmware_version & 0xFFFF, full.hardware_id,
             (unsigned long long)full.device_memory_bytes, i + 1 < n && !g_opt.count("device") ? "," : "");
      continue;
    }
    printf("\n[%u] %s  (%s%s)\n    %s\n", i, s.name, kind_str(s.kind), s.is_simulator ? ", SIMULATOR - not silicon" : "",
           s.description);
    if (os != SF_OK) {
      printf("    status        : not opened: %s\n", s.available ? sf_last_error_detail() : "unavailable");
      continue;
    }
    printf("    hardware id   : %s\n", full.hardware_id);
    printf("    versions      : device ABI %u.%u, firmware %u.%u, hw revision %08x\n", full.device_abi_version >> 16,
           full.device_abi_version & 0xFFFF, full.firmware_version >> 16, full.firmware_version & 0xFFFF,
           full.hardware_revision);
    printf("    capabilities  : %s\n", caps_str(full.caps).c_str());
    printf("    memory        : %llu bytes allocatable, alignment %u\n", (unsigned long long)full.device_memory_bytes,
           full.min_alignment);
    printf("    queues        : up to %u, depth <= %u\n", full.max_queues, full.max_queue_depth);
    if (full.vector_lanes) printf("    vector        : %u lanes (reduction order), <= %llu elements per call\n",
                                  full.vector_lanes, (unsigned long long)full.max_vector_elements);
    if ((full.caps & SF_CAP_GEMM_I8_I32) && full.tensor_array_rows)
      printf("    tensor        : %ux%u array, M,N <= %u, K <= %u\n", full.tensor_array_rows, full.tensor_array_cols,
             full.gemm_max_m, full.gemm_max_k);
    else if (full.caps & SF_CAP_GEMM_I8_I32)
      printf("    tensor        : reference implementation, M,N <= %u, K <= %u\n", full.gemm_max_m, full.gemm_max_k);
    if (full.nominal_clock_mhz)
      printf("    clock         : %u MHz NOMINAL (simulation time base; not a measured frequency)\n",
             full.nominal_clock_mhz);
  }
  if (json) printf("]\n");
  return 0;
}

// ------------------------------------------------------------------ workloads (device vs CPU reference device)
struct Outcome {
  sf_status status = SF_OK;
  sf_cmd_result r{};
  std::vector<uint8_t> out;
  uint64_t host_ns = 0;
};

struct Workload {
  std::string op;
  uint64_t n = 1024;
  uint32_t m = 16, k = 64, rounding = 0;
  uint64_t seed = 1;
};

Outcome run_on(sf_device_t d, const Workload &w, bool tracing) {
  Outcome o;
  o.r.struct_size = sizeof o.r;
  std::mt19937_64 g(w.seed);
  sf_queue_t q;
  if ((o.status = sf_queue_create(d, 4, &q))) return o;
  std::vector<sf_buffer_t> bufs;
  auto mk = [&](uint64_t bytes, const void *init) {
    sf_buffer_t b = 0;
    sf_status s = sf_buffer_create(d, bytes, SF_MEM_READ_WRITE, &b);
    if (s == SF_OK && init) s = sf_buffer_write(b, 0, init, bytes);
    if (s != SF_OK && o.status == SF_OK) o.status = s;   // e.g. SF_ERR_OUT_OF_MEMORY: reported, not hidden
    bufs.push_back(b);
    return b;
  };
  sf_cmd_t id = 0;
  sf_vector_opts vo{sizeof vo, w.rounding};
  sf_buffer_t out = 0;
  uint64_t out_bytes = 0;
  if (w.op == "gemm" || w.op == "gemm-q8") {
    uint32_t M = w.m, N = (uint32_t)w.n, K = w.k;
    bool q8 = w.op == "gemm-q8";
    std::vector<int8_t> A((size_t)M * K), B((size_t)K * N);
    for (auto &v : A) v = (int8_t)g();
    for (auto &v : B) v = (int8_t)g();
    sf_buffer_t a = mk(A.size(), A.data()), b = mk(B.size(), B.data());
    out_bytes = (uint64_t)M * N * (q8 ? 1 : 4);
    out = mk(out_bytes, nullptr);
    sf_gemm_desc gd{};
    gd.struct_size = sizeof gd;
    gd.m = M; gd.n = N; gd.k = K;
    gd.a_type = gd.b_type = SF_DTYPE_I8;
    gd.c_type = q8 ? SF_DTYPE_I8 : SF_DTYPE_I32;
    if (q8) {
      gd.q_mult = 1 << 20; gd.q_shift = 24; gd.q_zero_point = 0; gd.relu = 1; gd.rounding = w.rounding;
    }
    if (o.status == SF_OK) o.status = sf_tensor_gemm(q, a, b, out, &gd, &id);
  } else {
    uint64_t n = w.n;
    std::vector<float> X(n), Y(n), Z(n);
    std::uniform_real_distribution<float> u(-10.f, 10.f);
    for (uint64_t i = 0; i < n; i++) { X[i] = u(g); Y[i] = u(g); Z[i] = u(g); }
    if (w.op == "copy") {
      sf_buffer_t a = mk(4 * n, X.data());
      out_bytes = 4 * n;
      out = mk(out_bytes, nullptr);
      if (o.status == SF_OK) o.status = sf_buffer_copy(q, a, out, 4 * n, &id);
    } else {
      sf_buffer_t x = mk(4 * n, X.data()), y = mk(4 * n, Y.data()), z = mk(4 * n, Z.data());
      out_bytes = w.op == "dot" ? 4 : 4 * n;
      out = mk(out_bytes, nullptr);
      if (o.status != SF_OK) {
      } else if (w.op == "vector-add") o.status = sf_vector_add(q, x, y, out, n, SF_DTYPE_F32, &vo, &id);
      else if (w.op == "vector-mul") o.status = sf_vector_mul(q, x, y, out, n, SF_DTYPE_F32, &vo, &id);
      else if (w.op == "vector-fma") o.status = sf_vector_fma(q, x, y, z, out, n, &vo, &id);
      else if (w.op == "axpy") o.status = sf_vector_axpy(q, 0.75f, x, y, out, n, &vo, &id);
      else if (w.op == "dot") o.status = sf_vector_dot(q, x, y, out, n, &vo, &id);
      else o.status = SF_ERR_INVALID_ARGUMENT;
    }
  }
  (void)tracing;
  if (o.status == SF_OK) {
    o.status = sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &o.r);
    if (o.status == SF_OK) {
      o.out.resize(out_bytes);
      sf_buffer_read(out, 0, o.out.data(), out_bytes);
    }
  }
  o.host_ns = o.r.host_complete_ns - o.r.host_submit_ns;
  for (auto b : bufs)
    if (b) sf_buffer_release(b);
  sf_queue_destroy(q);
  return o;
}

Workload workload_from_opts(const std::string &op) {
  Workload w;
  w.op = op;
  w.n = (uint64_t)opti("n", op.rfind("gemm", 0) == 0 ? 16 : 1024);
  w.m = (uint32_t)opti("m", 16);
  w.k = (uint32_t)opti("k", 64);
  w.rounding = (uint32_t)opti("rounding", 0);
  w.seed = (uint64_t)opti("seed", 1);
  return w;
}

void print_result(const char *dev, const Workload &w, const Outcome &o) {
  printf("%s: %s", dev, w.op.c_str());
  if (w.op.rfind("gemm", 0) == 0) printf(" %ux%llux%u", w.m, (unsigned long long)w.n, w.k);
  else printf(" n=%llu", (unsigned long long)w.n);
  printf(" -> %s\n", sf_status_string(o.status));
  if (o.status != SF_OK) return;
  printf("    executed on      : %s%s\n", target_str(o.r.exec_target),
         (o.r.flags & SF_RESULT_HOST_ASSISTED) ? " (host-assisted operand layout)" : "");
  printf("    device commands  : %u\n", o.r.device_commands);
  if (o.r.engine_cycles) printf("    engine cycles    : %llu (device clock)\n", (unsigned long long)o.r.engine_cycles);
  if (o.r.device_end_cycle)
    printf("    device timeline  : start %llu end %llu, queued %llu cycles (device clock)\n",
           (unsigned long long)o.r.device_start_cycle, (unsigned long long)o.r.device_end_cycle,
           (unsigned long long)o.r.device_queue_cycles);
  printf("    host latency     : %.3f ms (host clock, includes simulation time for simulators)\n", o.host_ns / 1e6);
  if (o.r.macs) printf("    MACs             : %llu\n", (unsigned long long)o.r.macs);
  if (o.r.flags & SF_RESULT_FP_FLAGS) printf("    IEEE flags       : %#x (NV DZ OF UF NX)\n", o.r.fp_flags);
}

// ------------------------------------------------------------------ run
int cmd_run() {
  if (g_pos.size() < 2) {
    fprintf(stderr, "usage: silicaflux run OP [--device NAME] ...\n");
    return 2;
  }
  Workload w = workload_from_opts(g_pos[1]);
  Opened dev;
  if (sf_status s = open_device(dev, flag("allow-cpu-fallback") ? SF_OPEN_ALLOW_CPU_FALLBACK : 0))
    return die(s, "open");
  if (g_opt.count("trace")) sf_trace_start(dev.d, opt("trace").c_str());
  Outcome o = run_on(dev.d, w, true);
  if (g_opt.count("trace")) sf_trace_stop(dev.d);
  print_result(dev.info.name, w, o);
  if (o.status != SF_OK) return die(o.status, "run");
  if (std::string(dev.info.name) == "cpu") return 0;
  Opened ref;
  g_opt["device"] = "cpu";
  if (sf_status s = open_device(ref)) return die(s, "open cpu reference");
  Outcome r = run_on(ref.d, w, false);
  size_t bad = 0;
  for (size_t i = 0; i < o.out.size() && i < r.out.size(); i++) bad += o.out[i] != r.out[i];
  printf("    verification     : %s (%zu of %zu bytes differ from the CPU reference)\n",
         bad == 0 && o.out.size() == r.out.size() ? "PASS, bit-exact" : "FAIL", bad, o.out.size());
  return bad ? 1 : 0;
}

// ------------------------------------------------------------------ selftest
int cmd_selftest() {
  Opened dev;
  if (sf_status s = open_device(dev)) return die(s, "open");
  printf("self-test of %s (%s)\n", dev.info.name, dev.info.hardware_id);
  int fails = 0, ran = 0;
  if (dev.info.caps & SF_CAP_FIRMWARE_SELFTEST) {
    sf_selftest_result r{};
    r.struct_size = sizeof r;
    sf_status s = sf_device_selftest(dev.d, (uint32_t)strtoul(opt("firmware-mask", "0").c_str(), nullptr, 16), &r);
    printf("  device firmware suite : %s, %u checks, %u failures, %llu device cycles\n", sf_status_string(s), r.checks,
           r.failures, (unsigned long long)r.device_cycles);
    fails += (s != SF_OK) || r.failures;
  }
  Opened ref;
  std::string name = dev.info.name;
  g_opt["device"] = "cpu";
  if (sf_status s = open_device(ref)) return die(s, "open cpu reference");
  const char *ops[] = {"vector-add", "vector-mul", "vector-fma", "axpy", "dot", "gemm", "gemm-q8", "copy"};
  for (const char *op : ops) {
    Workload w;
    w.op = op;
    w.n = std::string(op).rfind("gemm", 0) == 0 ? 12 : 777;
    w.m = 9;
    w.k = 40;
    w.rounding = 0;
    w.seed = 42;
    Outcome o = run_on(dev.d, w, false);
    if (o.status == SF_ERR_UNSUPPORTED) {
      printf("  %-12s : not supported by this device (skipped)\n", op);
      continue;
    }
    Outcome r = run_on(ref.d, w, false);
    bool ok = o.status == SF_OK && r.status == SF_OK && o.out == r.out;
    printf("  %-12s : %s  [%s, %llu engine cycles]\n", op, ok ? "PASS" : "FAIL", target_str(o.r.exec_target),
           (unsigned long long)o.r.engine_cycles);
    ran++;
    fails += !ok;
  }
  sf_device_status st{};
  st.struct_size = sizeof st;
  if (sf_device_get_status(dev.d, &st) == SF_OK) printf("  device status : %s\n", st.detail);
  printf("self-test %s: %d kernel checks, %d failures\n", fails ? "FAILED" : "PASSED", ran, fails);
  return fails ? 1 : 0;
}

// ------------------------------------------------------------------ counters / errors
const char *unit_str(uint32_t u) {
  static const char *n[] = {"?", "cycles", "events", "bytes", "ops", "macs", "host-ns"};
  return u < 7 ? n[u] : "?";
}
const char *src_str(uint32_t s) {
  static const char *n[] = {"?", "hardware", "firmware", "simulator", "runtime"};
  return s < 5 ? n[s] : "?";
}

int cmd_counters() {
  Opened dev;
  if (sf_status s = open_device(dev)) return die(s, "open");
  if (flag("clear")) sf_device_clear_counters(dev.d);
  std::string wl = opt("workload");
  if (!wl.empty()) {
    Workload w;
    unsigned M = 16, N = 16, K = 64;
    unsigned long long n = 1024;
    if (sscanf(wl.c_str(), "gemm:%ux%ux%u", &M, &N, &K) == 3) {
      w.op = "gemm";
      w.m = M;
      w.n = N;
      w.k = K;
    } else if (sscanf(wl.c_str(), "vector:%llu", &n) == 1) {
      w.op = "vector-fma";
      w.n = n;
    } else {
      fprintf(stderr, "--workload gemm:MxNxK | vector:N\n");
      return 2;
    }
    sf_device_clear_counters(dev.d);
    Outcome o = run_on(dev.d, w, false);
    printf("workload %s -> %s on %s\n", wl.c_str(), sf_status_string(o.status), target_str(o.r.exec_target));
  }
  std::vector<sf_counter> cs(512);
  uint32_t n = 0;
  if (sf_status s = sf_device_read_counters(dev.d, cs.data(), (uint32_t)cs.size(), &n)) return die(s, "counters");
  printf("%-34s %20s  %-8s %s\n", "counter", "value", "unit", "source");
  for (uint32_t i = 0; i < n && i < cs.size(); i++)
    printf("%-34s %20llu  %-8s %s\n", cs[i].name, (unsigned long long)cs[i].value, unit_str(cs[i].unit),
           src_str(cs[i].source));
  return 0;
}

int cmd_errors() {
  Opened dev;
  if (sf_status s = open_device(dev)) return die(s, "open");
  std::string inj = opt("inject");
  if (!inj.empty()) {
    sf_inject_kind k = inj == "warning" ? SF_INJECT_RAS_WARNING : inj == "fatal" ? SF_INJECT_RAS_FATAL : (sf_inject_kind)0;
    if (!k) {
      fprintf(stderr, "--inject warning|fatal\n");
      return 2;
    }
    if (sf_status s = sf_debug_inject(dev.d, k, 0, 0, 0)) return die(s, "inject");
    printf("injected a RAS %s event (simulator)\n", inj.c_str());
  }
  sf_device_status st{};
  st.struct_size = sizeof st;
  if (sf_status s = sf_device_get_status(dev.d, &st)) return die(s, "status");
  static const char *states[] = {"?", "READY", "DEGRADED", "ERROR", "LOST"};
  printf("device %s: state %s\n", dev.info.name, states[st.state < 5 ? st.state : 0]);
  if (dev.info.caps & SF_CAP_RAS) {
    printf("  RAS status        : %#x\n  warnings          : %u (sources %#x)\n  fatal events      : %u (sources %#x)\n"
           "  first error       : source %#x (bit 31 = valid) address %#x\n",
           st.ras_status, st.ras_warnings, st.ras_warning_sources, st.ras_fatals, st.ras_fatal_sources,
           st.ras_first_source, st.ras_first_address);
  } else {
    printf("  this device has no RAS block\n");
  }
  printf("  commands          : %u completed, %u failed since open; %u resets\n", st.commands_completed,
         st.commands_failed, st.resets);
  printf("  detail            : %s\n", st.detail);
  return st.state == SF_STATE_READY || st.state == SF_STATE_DEGRADED ? 0 : 1;
}

// ------------------------------------------------------------------ benchmark
int cmd_benchmark() {
  Opened dev;
  if (sf_status s = open_device(dev)) return die(s, "open");
  bool quick = flag("quick");
  std::vector<Workload> ws;
  for (uint64_t n : quick ? std::vector<uint64_t>{256, 4096} : std::vector<uint64_t>{256, 1024, 4096, 16384}) {
    for (const char *op : {"vector-add", "vector-fma", "dot"}) {
      Workload w;
      w.op = op;
      w.n = n;
      w.seed = 7;
      ws.push_back(w);
    }
  }
  struct G { uint32_t m, n, k; };
  for (G g : quick ? std::vector<G>{{16, 16, 64}, {32, 32, 128}}
                   : std::vector<G>{{16, 16, 64}, {32, 32, 128}, {64, 64, 256}, {32, 32, 1024}}) {
    Workload w;
    w.op = "gemm";
    w.m = g.m;
    w.n = g.n;
    w.k = g.k;
    w.seed = 7;
    ws.push_back(w);
  }
  FILE *js = g_opt.count("json") ? fopen(opt("json").c_str(), "w") : nullptr;
  if (js)
    fprintf(js, "{\n  \"schema\": \"silicaflux-bench/1\",\n  \"library\": \"%s\",\n  \"device\": {\"name\": \"%s\", "
                "\"hardware_id\": \"%s\", \"kind\": \"%s\", \"firmware\": %u, \"device_abi\": %u, "
                "\"nominal_clock_mhz\": %u},\n  \"results\": [\n",
            sf_get_build_info(), dev.info.name, dev.info.hardware_id, kind_str(dev.info.kind), dev.info.firmware_version,
            dev.info.device_abi_version, dev.info.nominal_clock_mhz);
  printf("%-11s %-14s %-9s %12s %12s %12s %10s\n", "op", "size", "status", "eng.cycles", "dev.cycles", "work/cycle",
         "host ms");
  bool first = true;
  for (auto &w : ws) {
    Outcome o = run_on(dev.d, w, false);
    char size[32];
    if (w.op == "gemm") snprintf(size, sizeof size, "%ux%llux%u", w.m, (unsigned long long)w.n, w.k);
    else snprintf(size, sizeof size, "%llu", (unsigned long long)w.n);
    uint64_t work = w.op == "gemm" ? (uint64_t)w.m * w.n * w.k : w.n;
    uint64_t dev_cycles = o.r.device_end_cycle > o.r.device_start_cycle ? o.r.device_end_cycle - o.r.device_start_cycle : 0;
    double per = o.r.engine_cycles ? (double)work / (double)o.r.engine_cycles : 0;
    printf("%-11s %-14s %-9s %12llu %12llu %12.3f %10.3f\n", w.op.c_str(), size,
           o.status == SF_OK ? "ok" : sf_status_string(o.status), (unsigned long long)o.r.engine_cycles,
           (unsigned long long)dev_cycles, per, o.host_ns / 1e6);
    if (js) {
      fprintf(js, "%s    {\"op\": \"%s\", \"size\": \"%s\", \"status\": \"%s\", \"exec_target\": \"%s\", "
                  "\"work_items\": %llu, \"engine_cycles\": %llu, \"device_span_cycles\": %llu, "
                  "\"device_commands\": %u, \"host_assisted\": %s, \"host_latency_ns\": %llu}",
              first ? "" : ",\n", w.op.c_str(), size, sf_status_string(o.status), target_str(o.r.exec_target),
              (unsigned long long)work, (unsigned long long)o.r.engine_cycles, (unsigned long long)dev_cycles,
              o.r.device_commands, (o.r.flags & SF_RESULT_HOST_ASSISTED) ? "true" : "false",
              (unsigned long long)o.host_ns);
      first = false;
    }
  }
  if (js) {
    fprintf(js, "\n  ],\n  \"notes\": \"engine_cycles/device_span_cycles are device clock cycles; host_latency_ns is "
                "host time (for simulators it measures simulation speed, not device speed)\"\n}\n");
    fclose(js);
  }
  printf("work/cycle = elements (vector) or MACs (gemm) per engine cycle; host ms is wall time on this host.\n");
  return 0;
}

void usage() {
  printf("usage: silicaflux <info|selftest|run|benchmark|counters|errors> [options]\n"
         "  --device NAME   cpu | rtl-cc | rtl-hostlink | pcie:BDF   (default cpu; see `silicaflux info`)\n"
         "  run OP          vector-add vector-mul vector-fma axpy dot gemm gemm-q8 copy\n"
         "                  --n N  (vector length, or GEMM N)  --m M --k K  --rounding 0..4  --seed S\n"
         "                  --trace FILE.json  --allow-cpu-fallback\n"
         "  benchmark       --json FILE  --quick\n"
         "  counters        --workload gemm:MxNxK|vector:N  --clear\n"
         "  errors          --inject warning|fatal   (simulators only)\n"
         "  selftest        --firmware-mask HEX\n");
}

}  // namespace

int main(int argc, char **argv) {
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    if (a.rfind("--", 0) == 0) {
      std::string k = a.substr(2);
      if (i + 1 < argc && std::string(argv[i + 1]).rfind("--", 0) != 0 && k != "json" && k != "clear" &&
          k != "quick" && k != "allow-cpu-fallback")
        g_opt[k] = argv[++i];
      else if (k == "json" && i + 1 < argc && std::string(argv[i + 1]).rfind("--", 0) != 0)
        g_opt[k] = argv[++i];
      else
        g_opt[k] = "1";
    } else {
      g_pos.push_back(a);
    }
  }
  if (g_pos.empty()) {
    usage();
    return 2;
  }
  signal(SIGINT, on_sigint);
  const std::string &c = g_pos[0];
  if (c == "info") return cmd_info();
  if (c == "selftest") return cmd_selftest();
  if (c == "run") return cmd_run();
  if (c == "benchmark") return cmd_benchmark();
  if (c == "counters") return cmd_counters();
  if (c == "errors") return cmd_errors();
  usage();
  return 2;
}
