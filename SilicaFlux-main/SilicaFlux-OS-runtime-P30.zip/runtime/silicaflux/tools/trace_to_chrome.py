#!/usr/bin/env python3
"""SilicaFlux.OS -- convert a silicaflux-trace/1 file to Chrome trace-event JSON (chrome://tracing, Perfetto).

Only the HOST timeline (host_submit_ns .. host_complete_ns) becomes trace time: device cycles are
attached as event arguments and are never converted into time, so the two clock domains are not
conflated.  Usage: trace_to_chrome.py TRACE.json [OUT.json]
"""
import json
import sys

src = json.load(open(sys.argv[1]))
assert src.get("schema") == "silicaflux-trace/1", "not a silicaflux trace"
events = [{"ph": "M", "name": "process_name", "pid": 1, "args": {"name": f"host timeline: {src['device']['name']}"}}]
for c in src["commands"]:
    if c["host_submit_ns"] < 0 or c["host_complete_ns"] < 0:
        continue
    events.append({
        "ph": "X", "pid": 1, "tid": c["queue"], "name": c["op"],
        "ts": c["host_submit_ns"] / 1000.0, "dur": max(0.001, (c["host_complete_ns"] - c["host_submit_ns"]) / 1000.0),
        "args": {k: c[k] for k in ("status", "exec_target", "engine_cycles", "device_start_cycle", "device_end_cycle",
                                   "device_queue_cycles", "elements", "macs", "device_commands")},
    })
out = sys.argv[2] if len(sys.argv) > 2 else sys.argv[1].replace(".json", ".chrome.json")
json.dump({"traceEvents": events, "displayTimeUnit": "ns",
           "otherData": {"note": "ts/dur are host time (us); device cycles are in args only"}}, open(out, "w"), indent=1)
print(out)
