// SilicaFlux.OS -- C API tests on the CPU reference backend (fast, no RTL).
// Covers handle validation, buffer lifetime / ownership / permissions, queue
// semantics (depth, ordering, poll, wait, interruption), every kernel against the
// independent reference, precision/dimension rejection, tracing and counters.
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <random>
#include <string>
#include <thread>
#include <vector>

#include "sf_reference.h"
#include "sf_softfloat.h"
#include "sf_test.h"
#include "silicaflux/silicaflux.h"

using namespace sf::ref;

static sf_device_t open_cpu() {
  sf_device_t d = 0;
  if (sf_device_open_by_name("cpu", 0, &d) != SF_OK) {
    fprintf(stderr, "cannot open cpu: %s\n", sf_last_error_detail());
    exit(2);
  }
  return d;
}

static sf_buffer_t mkbuf(sf_device_t d, uint64_t size, uint32_t flags = SF_MEM_READ_WRITE) {
  sf_buffer_t b = 0;
  if (sf_buffer_create(d, size, flags, &b) != SF_OK) {
    fprintf(stderr, "buffer: %s\n", sf_last_error_detail());
    exit(2);
  }
  return b;
}

SF_TEST(version_and_discovery) {
  EXPECT_EQ(sf_get_api_version() >> 16, (uint32_t)SF_API_VERSION_MAJOR);
  EXPECT_TRUE(strstr(sf_get_build_info(), "cpu") != nullptr);
  uint32_t n = 0;
  ASSERT_OK(sf_get_device_count(&n));
  EXPECT_TRUE(n >= 1);
  sf_device_info i{};
  i.struct_size = sizeof i;
  ASSERT_OK(sf_get_device_info(0, &i));
  EXPECT_TRUE(!strcmp(i.name, "cpu"));
  EXPECT_EQ(i.kind, (uint32_t)SF_DEVICE_CPU_REFERENCE);
  EXPECT_EQ(i.is_simulator, 0u);
  EXPECT_STATUS(sf_get_device_info(n + 5, &i), SF_ERR_NO_DEVICE);
  sf_device_t d;
  EXPECT_STATUS(sf_device_open_by_name("no-such-device", 0, &d), SF_ERR_NO_DEVICE);
  // a small caller struct (older ABI minor) is filled only up to its size
  struct { uint32_t struct_size; uint32_t index; char name[SF_NAME_MAX]; } small{};
  small.struct_size = sizeof small;
  ASSERT_OK(sf_get_device_info(0, reinterpret_cast<sf_device_info *>(&small)));
  EXPECT_TRUE(!strcmp(small.name, "cpu"));
  EXPECT_EQ(small.struct_size, (uint32_t)sizeof small);
}

SF_TEST(device_open_close_exclusive) {
  sf_device_t d = open_cpu(), d2 = 0;
  EXPECT_STATUS(sf_device_open_by_name("cpu", 0, &d2), SF_ERR_BUSY);
  sf_device_info i{};
  i.struct_size = sizeof i;
  ASSERT_OK(sf_device_get_info(d, &i));
  EXPECT_TRUE((i.caps & SF_CAP_GEMM_I8_I32) != 0);
  EXPECT_EQ(i.vector_lanes, 4u);
  EXPECT_EQ(i.min_alignment, 64u);
  ASSERT_OK(sf_device_close(d));
  EXPECT_STATUS(sf_device_close(d), SF_ERR_INVALID_DEVICE);
  EXPECT_STATUS(sf_device_get_info(d, &i), SF_ERR_INVALID_DEVICE);
  EXPECT_STATUS(sf_device_get_info(0x1234, &i), SF_ERR_INVALID_DEVICE);
}

SF_TEST(buffers_lifetime_permissions_views) {
  sf_device_t d = open_cpu();
  sf_buffer_t b = mkbuf(d, 1000);
  std::vector<uint8_t> z(1000, 0xAA), w(1000);
  ASSERT_OK(sf_buffer_read(b, 0, w.data(), 1000));
  EXPECT_TRUE(std::all_of(w.begin(), w.end(), [](uint8_t v) { return v == 0; }));   // zeroed
  for (int i = 0; i < 1000; i++) z[i] = (uint8_t)(i * 7);
  ASSERT_OK(sf_buffer_write(b, 0, z.data(), 1000));
  ASSERT_OK(sf_buffer_read(b, 0, w.data(), 1000));
  EXPECT_TRUE(z == w);
  EXPECT_STATUS(sf_buffer_write(b, 999, z.data(), 2), SF_ERR_OUT_OF_RANGE);
  EXPECT_STATUS(sf_buffer_read(b, 0, nullptr, 2), SF_ERR_INVALID_ARGUMENT);
  sf_buffer_info bi{};
  bi.struct_size = sizeof bi;
  ASSERT_OK(sf_buffer_get_info(b, &bi));
  EXPECT_EQ(bi.size, 1000u);
  EXPECT_EQ(bi.device_address % 64, 0u);
  // views
  sf_buffer_t v;
  EXPECT_STATUS(sf_buffer_create_view(b, 2, 8, SF_MEM_READ_WRITE, &v), SF_ERR_INVALID_ARGUMENT);
  EXPECT_STATUS(sf_buffer_create_view(b, 996, 8, SF_MEM_READ_WRITE, &v), SF_ERR_OUT_OF_RANGE);
  ASSERT_OK(sf_buffer_create_view(b, 100, 16, SF_MEM_INPUT, &v));
  uint8_t t[16];
  ASSERT_OK(sf_buffer_read(v, 0, t, 16));
  EXPECT_TRUE(!memcmp(t, z.data() + 100, 16));
  // the parent handle can go; the view keeps the memory alive
  ASSERT_OK(sf_buffer_release(b));
  EXPECT_STATUS(sf_buffer_release(b), SF_ERR_INVALID_BUFFER);
  EXPECT_STATUS(sf_buffer_read(b, 0, t, 4), SF_ERR_INVALID_BUFFER);
  ASSERT_OK(sf_buffer_read(v, 0, t, 16));
  EXPECT_TRUE(!memcmp(t, z.data() + 100, 16));
  // permissions
  sf_buffer_t wo = mkbuf(d, 64, SF_MEM_DEVICE_READ | SF_MEM_HOST_WRITE);
  EXPECT_STATUS(sf_buffer_read(wo, 0, t, 4), SF_ERR_PERMISSION);
  sf_buffer_t ro = mkbuf(d, 64, SF_MEM_OUTPUT);
  EXPECT_STATUS(sf_buffer_write(ro, 0, t, 4), SF_ERR_PERMISSION);
  EXPECT_STATUS(sf_buffer_create(d, 64, 0x100, &b), SF_ERR_INVALID_ARGUMENT);
  EXPECT_STATUS(sf_buffer_create(d, 0, SF_MEM_READ_WRITE, &b), SF_ERR_INVALID_ARGUMENT);
  // allocation failure is reported, not fatal
  EXPECT_STATUS(sf_buffer_create(d, 4ull << 30, SF_MEM_READ_WRITE, &b), SF_ERR_OUT_OF_MEMORY);
  // a buffer from another device is rejected by the compute API
  ASSERT_OK(sf_device_close(d));
  EXPECT_STATUS(sf_buffer_read(v, 0, t, 4), SF_ERR_INVALID_BUFFER);   // closing a device releases its buffers
}

static std::vector<uint32_t> rnd_f32(std::mt19937 &g, size_t n) {
  std::vector<uint32_t> v(n);
  std::uniform_real_distribution<float> u(-100.f, 100.f);
  for (auto &x : v) {
    float f = u(g);
    memcpy(&x, &f, 4);
  }
  return v;
}

SF_TEST(vector_kernels_match_reference_all_rounding_modes) {
  sf_device_t d = open_cpu();
  sf_queue_t q;
  ASSERT_OK(sf_queue_create(d, 16, &q));
  std::mt19937 g(5);
  const size_t n = 1003;
  auto A = rnd_f32(g, n), B = rnd_f32(g, n), C = rnd_f32(g, n);
  A[3] = 0x7F800000u;   // inf
  B[3] = 0;             // inf * 0 -> NV
  sf_buffer_t a = mkbuf(d, 4 * n), b = mkbuf(d, 4 * n), c = mkbuf(d, 4 * n), o = mkbuf(d, 4 * n), s = mkbuf(d, 4);
  ASSERT_OK(sf_buffer_write(a, 0, A.data(), 4 * n));
  ASSERT_OK(sf_buffer_write(b, 0, B.data(), 4 * n));
  ASSERT_OK(sf_buffer_write(c, 0, C.data(), 4 * n));
  std::vector<uint32_t> got(n), want(n);
  for (uint32_t rm = 0; rm <= 4; rm++) {
    sf_vector_opts opts{sizeof opts, rm};
    for (int op = 0; op < 4; op++) {
      sf_cmd_t id;
      sf_cmd_result r{};
      r.struct_size = sizeof r;
      uint32_t fl = 0;
      float alpha = 1.75f;
      uint32_t ab;
      memcpy(&ab, &alpha, 4);
      if (op == 0) { ASSERT_OK(sf_vector_add(q, a, b, o, n, SF_DTYPE_F32, &opts, &id)); fl = vec_f32(VecOp::kAdd, rm, n, A.data(), nullptr, B.data(), nullptr, want.data()); }
      if (op == 1) { ASSERT_OK(sf_vector_mul(q, a, b, o, n, SF_DTYPE_F32, &opts, &id)); fl = vec_f32(VecOp::kMul, rm, n, A.data(), nullptr, B.data(), nullptr, want.data()); }
      if (op == 2) { ASSERT_OK(sf_vector_fma(q, a, b, c, o, n, &opts, &id)); fl = vec_f32(VecOp::kFma, rm, n, A.data(), nullptr, B.data(), C.data(), want.data()); }
      if (op == 3) { ASSERT_OK(sf_vector_axpy(q, alpha, b, c, o, n, &opts, &id)); fl = vec_f32(VecOp::kFma, rm, n, nullptr, &ab, B.data(), C.data(), want.data()); }
      ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r));
      ASSERT_OK(sf_buffer_read(o, 0, got.data(), 4 * n));
      EXPECT_TRUE(got == want);
      EXPECT_EQ(r.fp_flags, fl);
      EXPECT_EQ(r.exec_target, (uint32_t)SF_EXEC_CPU_REFERENCE);
      EXPECT_EQ(r.elements, (uint64_t)n);
    }
    sf_cmd_t id;
    sf_cmd_result r{};
    r.struct_size = sizeof r;
    ASSERT_OK(sf_vector_dot(q, c, c, s, n, &opts, &id));
    ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r));
    uint32_t dot_ref = dot_f32(n, C.data(), C.data(), rm, 4, 0, nullptr), dot_got;
    ASSERT_OK(sf_buffer_read(s, 0, &dot_got, 4));
    EXPECT_EQ(dot_got, dot_ref);
    EXPECT_EQ(r.scalar_bits, dot_ref);
  }
  // INT32
  std::vector<int32_t> X(n), Y(n), Z(n), W(n);
  for (size_t i = 0; i < n; i++) { X[i] = (int32_t)g(); Y[i] = (int32_t)g(); }
  ASSERT_OK(sf_buffer_write(a, 0, X.data(), 4 * n));
  ASSERT_OK(sf_buffer_write(b, 0, Y.data(), 4 * n));
  sf_cmd_t id;
  ASSERT_OK(sf_vector_mul(q, a, b, o, n, SF_DTYPE_I32, nullptr, &id));
  ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, nullptr));
  ASSERT_OK(sf_buffer_read(o, 0, Z.data(), 4 * n));
  vec_i32(VecOp::kMul, n, X.data(), Y.data(), W.data());
  EXPECT_TRUE(Z == W);
  // rejected precisions / arguments
  EXPECT_STATUS(sf_vector_add(q, a, b, o, n, SF_DTYPE_I8, nullptr, &id), SF_ERR_UNSUPPORTED);
  EXPECT_STATUS(sf_vector_fma(q, a, b, c, o, 0, nullptr, &id), SF_ERR_INVALID_ARGUMENT);
  EXPECT_STATUS(sf_vector_add(q, a, b, o, n + 1, SF_DTYPE_F32, nullptr, &id), SF_ERR_OUT_OF_RANGE);
  sf_vector_opts bad{sizeof bad, 7};
  EXPECT_STATUS(sf_vector_add(q, a, b, o, n, SF_DTYPE_F32, &bad, &id), SF_ERR_INVALID_ARGUMENT);
  sf_buffer_t ro_in = mkbuf(d, 4 * n, SF_MEM_INPUT);
  EXPECT_STATUS(sf_vector_add(q, a, b, ro_in, n, SF_DTYPE_F32, nullptr, &id), SF_ERR_PERMISSION);
  // partial overlap of destination and source is order-dependent: rejected; exact in-place is allowed
  sf_buffer_t sh;
  ASSERT_OK(sf_buffer_create_view(a, 4, 4 * (n - 1), SF_MEM_READ_WRITE, &sh));
  EXPECT_STATUS(sf_vector_add(q, a, b, sh, n - 1, SF_DTYPE_F32, nullptr, &id), SF_ERR_INVALID_ARGUMENT);
  ASSERT_OK(sf_vector_add(q, a, b, a, n, SF_DTYPE_I32, nullptr, &id));
  ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, nullptr));
  ASSERT_OK(sf_device_close(d));
}

SF_TEST(gemm_int32_and_requantised_int8) {
  sf_device_t d = open_cpu();
  sf_queue_t q;
  ASSERT_OK(sf_queue_create(d, 4, &q));
  std::mt19937 g(9);
  const uint32_t M = 13, N = 7, K = 37;
  std::vector<int8_t> A(M * K), B(K * N);
  for (auto &x : A) x = (int8_t)g();
  for (auto &x : B) x = (int8_t)g();
  sf_buffer_t a = mkbuf(d, A.size()), b = mkbuf(d, B.size()), c = mkbuf(d, 4 * M * N), c8 = mkbuf(d, M * N);
  ASSERT_OK(sf_buffer_write(a, 0, A.data(), A.size()));
  ASSERT_OK(sf_buffer_write(b, 0, B.data(), B.size()));
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t id;
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  ASSERT_OK(sf_tensor_gemm(q, a, b, c, &gd, &id));
  ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r));
  std::vector<int32_t> C(M * N), R(M * N);
  ASSERT_OK(sf_buffer_read(c, 0, C.data(), 4 * M * N));
  gemm_i8_i32(M, N, K, A.data(), K, B.data(), N, R.data(), 4 * N);
  EXPECT_TRUE(C == R);
  EXPECT_EQ(r.macs, (uint64_t)M * N * K);
  // requantised INT8 + ReLU
  gd.c_type = SF_DTYPE_I8;
  gd.q_mult = 1 << 20; gd.q_shift = 26; gd.q_zero_point = -3; gd.relu = 1; gd.rounding = SF_ROUND_NEAREST_EVEN;
  ASSERT_OK(sf_tensor_gemm(q, a, b, c8, &gd, &id));
  ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r));
  std::vector<int8_t> C8(M * N), R8(M * N);
  ASSERT_OK(sf_buffer_read(c8, 0, C8.data(), M * N));
  bool sat = gemm_i8_q8(M, N, K, A.data(), K, B.data(), N, R8.data(), N, 1 << 20, 26, -3, true, 0);
  EXPECT_TRUE(C8 == R8);
  EXPECT_EQ((r.flags & SF_RESULT_SATURATED) != 0, sat);
  // rejected precisions, dimensions, layouts
  sf_gemm_desc bad = gd;
  bad.a_type = SF_DTYPE_F32;
  EXPECT_STATUS(sf_tensor_gemm(q, a, b, c8, &bad, &id), SF_ERR_UNSUPPORTED);
  bad = gd;
  bad.c_type = SF_DTYPE_F32;
  EXPECT_STATUS(sf_tensor_gemm(q, a, b, c8, &bad, &id), SF_ERR_UNSUPPORTED);
  bad = gd;
  bad.k = 0;
  EXPECT_STATUS(sf_tensor_gemm(q, a, b, c8, &bad, &id), SF_ERR_INVALID_ARGUMENT);
  bad = gd;
  bad.lda = K - 1;
  EXPECT_STATUS(sf_tensor_gemm(q, a, b, c8, &bad, &id), SF_ERR_INVALID_ARGUMENT);
  bad = gd;
  bad.m = 70000;
  EXPECT_STATUS(sf_tensor_gemm(q, a, b, c8, &bad, &id), SF_ERR_OUT_OF_RANGE);   // footprint exceeds buffer A
  bad = gd;
  bad.q_shift = 64;
  EXPECT_STATUS(sf_tensor_gemm(q, a, b, c8, &bad, &id), SF_ERR_INVALID_ARGUMENT);
  EXPECT_STATUS(sf_tensor_gemm(q, a, b, a, &gd, &id), SF_ERR_INVALID_ARGUMENT);   // C aliases A
  ASSERT_OK(sf_device_close(d));
}

SF_TEST(queue_depth_ordering_ownership_interrupt) {
  sf_device_t d = open_cpu();
  sf_queue_t q;
  EXPECT_STATUS(sf_queue_create(d, 0, &q), SF_ERR_INVALID_ARGUMENT);
  ASSERT_OK(sf_queue_create(d, 3, &q));
  const size_t n = 64;
  sf_buffer_t a = mkbuf(d, 4 * n), o = mkbuf(d, 4 * n), o2 = mkbuf(d, 4 * n);
  std::vector<int32_t> X(n, 3);
  ASSERT_OK(sf_buffer_write(a, 0, X.data(), 4 * n));
  sf_cmd_t ids[4] = {};
  // CPU commands run only when the host polls/waits, so the queue fills deterministically
  ASSERT_OK(sf_vector_add(q, a, a, o, n, SF_DTYPE_I32, nullptr, &ids[0]));
  // the device owns `o` now: host access is refused, reads of a pure input are allowed
  int32_t tmp[4];
  EXPECT_STATUS(sf_buffer_write(o, 0, tmp, 16), SF_ERR_BUSY);
  EXPECT_STATUS(sf_buffer_read(o, 0, tmp, 16), SF_ERR_BUSY);
  EXPECT_STATUS(sf_buffer_write(a, 0, tmp, 16), SF_ERR_BUSY);
  ASSERT_OK(sf_buffer_read(a, 0, tmp, 16));
  ASSERT_OK(sf_vector_add(q, o, a, o2, n, SF_DTYPE_I32, nullptr, &ids[1]));
  ASSERT_OK(sf_queue_marker(q, &ids[2]));
  uint32_t pend = 0;
  ASSERT_OK(sf_queue_pending(q, &pend));
  EXPECT_EQ(pend, 3u);
  EXPECT_STATUS(sf_vector_add(q, a, a, o, n, SF_DTYPE_I32, nullptr, &ids[3]), SF_ERR_QUEUE_FULL);
  EXPECT_EQ(ids[3], 0u);   // nothing was submitted
  EXPECT_TRUE(ids[0] < ids[1] && ids[1] < ids[2]);
  // interruption: the wait returns, the command stays pending
  sf_interrupt();
  EXPECT_STATUS(sf_queue_wait(q, SF_CMD_ALL, SF_TIMEOUT_DEFAULT, nullptr), SF_ERR_INTERRUPTED);
  sf_clear_interrupt();
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  ASSERT_OK(sf_queue_wait(q, ids[1], SF_TIMEOUT_DEFAULT, &r));
  EXPECT_TRUE(r.host_complete_ns >= r.host_submit_ns);
  ASSERT_OK(sf_queue_poll(q, ids[0], &r));                    // older results remain retrievable
  EXPECT_EQ(sf_queue_poll(q, ids[2], &r), SF_OK);
  EXPECT_STATUS(sf_queue_poll(q, 999, &r), SF_ERR_INVALID_COMMAND);
  std::vector<int32_t> Y(n);
  ASSERT_OK(sf_buffer_read(o2, 0, Y.data(), 4 * n));
  EXPECT_EQ(Y[17], 9);                                        // (3+3)+3: in-order execution
  ASSERT_OK(sf_buffer_sync(o2, SF_TIMEOUT_DEFAULT));
  // a buffer released while a command still uses it stays valid for that command
  sf_cmd_t id;
  ASSERT_OK(sf_vector_add(q, a, a, o2, n, SF_DTYPE_I32, nullptr, &id));
  ASSERT_OK(sf_buffer_release(a));
  ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, nullptr));
  ASSERT_OK(sf_buffer_read(o2, 0, Y.data(), 4 * n));
  EXPECT_EQ(Y[5], 6);
  // interruption from another thread while a wait is in progress
  ASSERT_OK(sf_queue_destroy(q));
  EXPECT_STATUS(sf_queue_wait(q, SF_CMD_ALL, 1, nullptr), SF_ERR_INVALID_QUEUE);
  EXPECT_STATUS(sf_queue_marker(q, &id), SF_ERR_INVALID_QUEUE);
  ASSERT_OK(sf_device_close(d));
}

SF_TEST(copy_raw_trace_counters) {
  sf_device_t d = open_cpu();
  sf_queue_t q;
  ASSERT_OK(sf_queue_create(d, 8, &q));
  sf_buffer_t a = mkbuf(d, 256), b = mkbuf(d, 256);
  std::vector<uint8_t> X(256);
  for (int i = 0; i < 256; i++) X[i] = (uint8_t)i;
  ASSERT_OK(sf_buffer_write(a, 0, X.data(), 256));
  const char *path = "sf_test_trace.json";
  ASSERT_OK(sf_trace_start(d, path));
  sf_cmd_t id;
  EXPECT_STATUS(sf_buffer_copy(q, a, b, 6, &id), SF_ERR_INVALID_ARGUMENT);
  ASSERT_OK(sf_buffer_copy(q, a, b, 256, &id));
  ASSERT_OK(sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, nullptr));
  std::vector<uint8_t> Y(256);
  ASSERT_OK(sf_buffer_read(b, 0, Y.data(), 256));
  EXPECT_TRUE(X == Y);
  uint32_t words[8] = {0};
  EXPECT_STATUS(sf_debug_submit_raw(q, SF_ENGINE_VECTOR, words, 8, &id), SF_ERR_UNSUPPORTED);
  EXPECT_STATUS(sf_debug_inject(d, SF_INJECT_RAS_WARNING, 0, 0, 0), SF_ERR_UNSUPPORTED);
  sf_selftest_result st{};
  st.struct_size = sizeof st;
  EXPECT_STATUS(sf_device_selftest(d, 0, &st), SF_ERR_UNSUPPORTED);
  ASSERT_OK(sf_trace_stop(d));
  std::ifstream f(path);
  std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  EXPECT_TRUE(s.find("\"schema\": \"silicaflux-trace/1\"") != std::string::npos);
  EXPECT_TRUE(s.find("\"op\": \"buffer_copy\"") != std::string::npos);
  EXPECT_TRUE(s.find("\"exec_target\": \"cpu_reference\"") != std::string::npos);
  sf_counter cs[64];
  uint32_t n = 0;
  ASSERT_OK(sf_device_read_counters(d, cs, 64, &n));
  bool found = false;
  for (uint32_t i = 0; i < n && i < 64; i++)
    if (!strcmp(cs[i].name, "host.bytes_h2d") && cs[i].value == 256 && cs[i].source == SF_SRC_RUNTIME) found = true;
  EXPECT_TRUE(found);
  sf_perf_summary ps{};
  ps.struct_size = sizeof ps;
  ASSERT_OK(sf_device_perf_summary(d, &ps));
  EXPECT_EQ(ps.device_cycles, UINT64_MAX);   // the CPU reference has no device clock: not invented
  EXPECT_EQ(ps.host_bytes_d2h, 256u);
  sf_device_status ds{};
  ds.struct_size = sizeof ds;
  ASSERT_OK(sf_device_get_status(d, &ds));
  EXPECT_EQ(ds.state, (uint32_t)SF_STATE_READY);
  ASSERT_OK(sf_device_reset(d, SF_RESET_ENGINES));
  ASSERT_OK(sf_device_close(d));
  remove(path);
}

SF_TEST(threaded_interrupt_unblocks_wait) {
  // a wait on a long CPU queue is interrupted from another thread
  sf_device_t d = open_cpu();
  sf_queue_t q;
  ASSERT_OK(sf_queue_create(d, 64, &q));
  const uint32_t M = 96, N = 96, K = 512;
  sf_buffer_t a = mkbuf(d, M * K), b = mkbuf(d, K * N), c = mkbuf(d, 4 * M * N);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  for (int i = 0; i < 60; i++) ASSERT_OK(sf_tensor_gemm(q, a, b, c, &gd, nullptr));
  std::thread t([] {
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    sf_interrupt();
  });
  sf_status s = sf_queue_wait(q, SF_CMD_ALL, SF_TIMEOUT_DEFAULT, nullptr);
  t.join();
  EXPECT_STATUS(s, SF_ERR_INTERRUPTED);
  sf_clear_interrupt();
  uint32_t pend = 0;
  ASSERT_OK(sf_queue_pending(q, &pend));
  EXPECT_TRUE(pend > 0);
  ASSERT_OK(sf_queue_wait(q, SF_CMD_ALL, SF_TIMEOUT_DEFAULT, nullptr));
  ASSERT_OK(sf_device_close(d));
}

SF_TEST_MAIN()
