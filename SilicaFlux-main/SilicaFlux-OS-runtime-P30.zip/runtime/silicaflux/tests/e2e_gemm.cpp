// SilicaFlux.OS -- end-to-end verification (brief section 18), on EVERY available backend:
//   1 initialise device   2 allocate input matrices   3 transfer data   4 submit TensorCore GEMM
//   5 wait for completion 6 retrieve output           7 compare with CPU reference
//   8 read hardware counters                          9 free resources  10 shut down cleanly
// The same logical workload (seeded) runs on each device.  Devices that are listed
// but cannot be opened (e.g. absent hardware) are reported, not skipped silently.
// Output: human-readable log + JSON report (--report FILE).  Exit 0 iff every
// available device passed all ten steps.
#include <cstdio>
#include <cstring>
#include <ctime>
#include <random>
#include <string>
#include <vector>

#include "silicaflux/silicaflux.h"

namespace {

struct Step {
  const char *name;
  sf_status status;
  double host_ms;
  std::string note;
};

uint64_t now_ns() {
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

std::string jesc(const std::string &s) {
  std::string o;
  for (char c : s) {
    if (c == '"' || c == '\\') o += '\\';
    o += c;
  }
  return o;
}

const char *target(uint32_t t) {
  switch (t) {
    case SF_EXEC_HARDWARE: return "hardware";
    case SF_EXEC_RTL_SIMULATION: return "rtl_simulation";
    case SF_EXEC_CPU_REFERENCE: return "cpu_reference";
    case SF_EXEC_CPU_FALLBACK: return "cpu_fallback";
  }
  return "none";
}

}  // namespace

int main(int argc, char **argv) {
  std::string report;
  uint32_t M = 32, N = 24, K = 80;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--report") && i + 1 < argc) report = argv[++i];
    if (!strcmp(argv[i], "--size") && i + 1 < argc) sscanf(argv[++i], "%ux%ux%u", &M, &N, &K);
  }
  // the logical workload and its independent reference (naive loops)
  std::mt19937 g(20261110);
  std::vector<int8_t> A((size_t)M * K), B((size_t)K * N);
  for (auto &v : A) v = (int8_t)g();
  for (auto &v : B) v = (int8_t)g();
  std::vector<int32_t> R((size_t)M * N);
  for (uint32_t i = 0; i < M; i++)
    for (uint32_t j = 0; j < N; j++) {
      int32_t s = 0;
      for (uint32_t k = 0; k < K; k++) s += A[(size_t)i * K + k] * B[(size_t)k * N + j];
      R[(size_t)i * N + j] = s;
    }

  uint32_t ndev = 0;
  sf_get_device_count(&ndev);
  printf("SilicaFlux.OS end-to-end GEMM %ux%ux%u (int8 x int8 -> int32) on %u listed device(s); %s\n", M, N, K, ndev,
         sf_get_build_info());
  std::string json = "{\n  \"schema\": \"silicaflux-e2e/1\",\n  \"library\": \"" + jesc(sf_get_build_info()) +
                     "\",\n  \"workload\": {\"op\": \"tensor_gemm\", \"m\": " + std::to_string(M) +
                     ", \"n\": " + std::to_string(N) + ", \"k\": " + std::to_string(K) +
                     ", \"seed\": 20261110},\n  \"devices\": [\n";
  int failures = 0, passed = 0, hardware_listed = 0;
  for (uint32_t di = 0; di < ndev; di++) {
    sf_device_info si{};
    si.struct_size = sizeof si;
    sf_get_device_info(di, &si);
    if (si.kind == SF_DEVICE_HARDWARE) hardware_listed++;
    printf("\n== [%u] %s (%s)\n", di, si.name, si.is_simulator ? "RTL SIMULATOR" : si.kind == SF_DEVICE_HARDWARE ? "hardware" : "CPU reference");
    std::vector<Step> steps;
    sf_device_t d = 0;
    sf_queue_t q = 0;
    sf_buffer_t a = 0, b = 0, c = 0;
    sf_cmd_t id = 0;
    sf_cmd_result r{};
    r.struct_size = sizeof r;
    std::vector<int32_t> C((size_t)M * N, 0x7EADBEEF);
    sf_device_info info{};
    info.struct_size = sizeof info;
    uint64_t hw_counters = 0, hw_macs = UINT64_MAX;
    bool ok = true;
    auto run = [&](const char *name, auto fn) {
      if (!ok) {
        steps.push_back({name, SF_ERR_ABORTED, 0, "not run (earlier step failed)"});
        return;
      }
      uint64_t t0 = now_ns();
      std::string note;
      sf_status s = fn(note);
      double ms = (now_ns() - t0) / 1e6;
      if (s != SF_OK && note.empty()) note = sf_last_error_detail();
      steps.push_back({name, s, ms, note});
      printf("   %-26s %-28s %10.2f ms  %s\n", name, sf_status_string(s), ms, note.c_str());
      if (s != SF_OK) ok = false;
    };
    run("1 initialise device", [&](std::string &n) {
      sf_status s = sf_device_open(di, 0, &d);
      if (s == SF_OK) {
        sf_device_get_info(d, &info);
        n = std::string(info.hardware_id) + ", fw " + std::to_string(info.firmware_version >> 16) + "." +
            std::to_string(info.firmware_version & 0xFFFF) + ", device ABI " +
            std::to_string(info.device_abi_version >> 16) + "." + std::to_string(info.device_abi_version & 0xFFFF);
      }
      return s;
    });
    if (!ok && !si.available) {
      printf("   -> device listed but not available: %s\n", si.description);
      json += std::string(di ? ",\n" : "") + "    {\"name\": \"" + jesc(si.name) + "\", \"kind\": " + std::to_string(si.kind) +
              ", \"available\": false, \"reason\": \"" + jesc(si.description) + "\"}";
      continue;
    }
    run("2 allocate input matrices", [&](std::string &) {
      sf_status s = sf_buffer_create(d, A.size(), SF_MEM_INPUT, &a);
      if (!s) s = sf_buffer_create(d, B.size(), SF_MEM_INPUT, &b);
      if (!s) s = sf_buffer_create(d, 4 * C.size(), SF_MEM_OUTPUT, &c);
      if (!s) s = sf_queue_create(d, 4, &q);
      return s;
    });
    run("3 transfer data", [&](std::string &n) {
      sf_status s = sf_buffer_write(a, 0, A.data(), A.size());
      if (!s) s = sf_buffer_write(b, 0, B.data(), B.size());
      n = std::to_string(A.size() + B.size()) + " bytes host->device";
      return s;
    });
    run("4 submit TensorCore GEMM", [&](std::string &) {
      sf_gemm_desc gd{};
      gd.struct_size = sizeof gd;
      gd.m = M; gd.n = N; gd.k = K;
      gd.a_type = gd.b_type = SF_DTYPE_I8;
      gd.c_type = SF_DTYPE_I32;
      return sf_tensor_gemm(q, a, b, c, &gd, &id);
    });
    run("5 wait for completion", [&](std::string &n) {
      sf_status s = sf_queue_wait(q, id, SF_TIMEOUT_DEFAULT, &r);
      char buf[160];
      snprintf(buf, sizeof buf, "executed on %s, %llu engine cycles, %u device commands%s", target(r.exec_target),
               (unsigned long long)r.engine_cycles, r.device_commands,
               (r.flags & SF_RESULT_HOST_ASSISTED) ? ", host-assisted layout" : "");
      n = buf;
      return s;
    });
    run("6 retrieve output", [&](std::string &) { return sf_buffer_read(c, 0, C.data(), 4 * C.size()); });
    size_t bad = 0;
    run("7 compare with CPU reference", [&](std::string &n) {
      for (size_t i = 0; i < C.size(); i++) bad += C[i] != R[i];
      n = std::to_string(bad) + " of " + std::to_string(C.size()) + " elements differ";
      return bad ? SF_ERR_DEVICE : SF_OK;
    });
    run("8 read hardware counters", [&](std::string &n) {
      std::vector<sf_counter> cs(256);
      uint32_t cnt = 0;
      sf_status s = sf_device_read_counters(d, cs.data(), (uint32_t)cs.size(), &cnt);
      for (uint32_t i = 0; i < cnt && i < cs.size(); i++) {
        if (cs[i].source == SF_SRC_HARDWARE) hw_counters++;
        if (!strcmp(cs[i].name, "tensor.macs")) hw_macs = cs[i].value;
      }
      n = std::to_string(cnt) + " counters, " + std::to_string(hw_counters) + " from hardware counters";
      if (hw_macs != UINT64_MAX) n += ", tensor.macs = " + std::to_string(hw_macs);
      return s;
    });
    run("9 free resources", [&](std::string &) {
      sf_status s = sf_buffer_release(a);
      if (!s) s = sf_buffer_release(b);
      if (!s) s = sf_buffer_release(c);
      if (!s) s = sf_queue_destroy(q);
      return s;
    });
    run("10 shut down cleanly", [&](std::string &) { return sf_device_close(d); });
    bool pass = ok;
    passed += pass;
    failures += !pass;
    printf("   -> %s\n", pass ? "PASS" : "FAIL");
    json += std::string(di ? ",\n" : "") + "    {\"name\": \"" + jesc(si.name) + "\", \"kind\": " + std::to_string(si.kind) +
            ", \"is_simulator\": " + std::to_string(si.is_simulator) + ", \"available\": true, \"hardware_id\": \"" +
            jesc(info.hardware_id) + "\", \"exec_target\": \"" + target(r.exec_target) +
            "\", \"engine_cycles\": " + std::to_string(r.engine_cycles) + ", \"device_commands\": " +
            std::to_string(r.device_commands) + ", \"host_assisted\": " +
            ((r.flags & SF_RESULT_HOST_ASSISTED) ? "true" : "false") + ", \"mismatches\": " + std::to_string(bad) +
            ", \"hardware_counters\": " + std::to_string(hw_counters) + ", \"pass\": " + (pass ? "true" : "false") +
            ", \"steps\": [";
    for (size_t i = 0; i < steps.size(); i++) {
      char buf[96];
      snprintf(buf, sizeof buf, "%.3f", steps[i].host_ms);
      json += std::string(i ? ", " : "") + "{\"step\": \"" + steps[i].name + "\", \"status\": \"" +
              sf_status_string(steps[i].status) + "\", \"host_ms\": " + buf + ", \"note\": \"" + jesc(steps[i].note) + "\"}";
    }
    json += "]}";
  }
  if (!hardware_listed) printf("\n== physical hardware: no SilicaFlux PCIe function discovered (none exists; see docs/09)\n");
  json += "\n  ],\n  \"physical_hardware_discovered\": " + std::to_string(hardware_listed) +
          ",\n  \"passed\": " + std::to_string(passed) + ",\n  \"failed\": " + std::to_string(failures) + "\n}\n";
  if (!report.empty()) {
    FILE *f = fopen(report.c_str(), "w");
    if (f) {
      fputs(json.c_str(), f);
      fclose(f);
      printf("report: %s\n", report.c_str());
    }
  }
  printf("\nend-to-end: %d device(s) passed, %d failed\n", passed, failures);
  return failures ? 1 : 0;
}
