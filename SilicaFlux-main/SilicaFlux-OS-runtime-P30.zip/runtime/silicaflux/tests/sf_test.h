// SilicaFlux.OS -- minimal self-contained test harness (no external framework).
#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <string>
#include <vector>

namespace sftest {
struct Case { const char *name; std::function<void()> fn; };
inline std::vector<Case> &cases() { static std::vector<Case> c; return c; }
inline int &failures() { static int f = 0; return f; }
inline int &checks() { static int c = 0; return c; }
struct Reg { Reg(const char *n, std::function<void()> f) { cases().push_back({n, std::move(f)}); } };

inline int run_all(int argc, char **argv) {
  const char *filter = nullptr;
  for (int i = 1; i < argc; i++)
    if (!strcmp(argv[i], "--filter") && i + 1 < argc) filter = argv[++i];
  int failed_cases = 0, ran = 0;
  for (auto &c : cases()) {
    if (filter && !strstr(c.name, filter)) continue;
    int f0 = failures();
    printf("[ RUN      ] %s\n", c.name);
    fflush(stdout);
    c.fn();
    ran++;
    bool ok = failures() == f0;
    if (!ok) failed_cases++;
    printf("[ %s ] %s\n", ok ? "      OK" : " FAILED ", c.name);
    fflush(stdout);
  }
  printf("[==========] %d test cases, %d checks, %d failed cases, %d failed checks\n", ran, checks(), failed_cases,
         failures());
  return failures() ? 1 : 0;
}
}  // namespace sftest

#define SF_TEST(name)                                         \
  static void name();                                         \
  static sftest::Reg reg_##name(#name, name);                 \
  static void name()

#define EXPECT_TRUE(c)                                                                     \
  do {                                                                                     \
    sftest::checks()++;                                                                    \
    if (!(c)) {                                                                            \
      sftest::failures()++;                                                                \
      fprintf(stderr, "  %s:%d: EXPECT_TRUE(%s) failed\n", __FILE__, __LINE__, #c);       \
    }                                                                                      \
  } while (0)

#define EXPECT_EQ(a, b)                                                                              \
  do {                                                                                               \
    sftest::checks()++;                                                                              \
    auto _va = (a);                                                                                  \
    auto _vb = (b);                                                                                  \
    if (!(_va == _vb)) {                                                                             \
      sftest::failures()++;                                                                          \
      fprintf(stderr, "  %s:%d: EXPECT_EQ(%s, %s) failed: %lld vs %lld (0x%llx vs 0x%llx)\n", __FILE__, \
              __LINE__, #a, #b, (long long)_va, (long long)_vb, (unsigned long long)_va,               \
              (unsigned long long)_vb);                                                              \
    }                                                                                                \
  } while (0)

#define ASSERT_OK(expr)                                                                         \
  do {                                                                                          \
    sftest::checks()++;                                                                         \
    int _rc = (int)(expr);                                                                      \
    if (_rc != 0) {                                                                             \
      sftest::failures()++;                                                                     \
      fprintf(stderr, "  %s:%d: %s returned %d (%s) %s\n", __FILE__, __LINE__, #expr, _rc,      \
              sf_status_string(_rc), sf_last_error_detail());                                   \
      return;                                                                                   \
    }                                                                                           \
  } while (0)

#define EXPECT_STATUS(expr, want)                                                                   \
  do {                                                                                              \
    sftest::checks()++;                                                                             \
    int _rc = (int)(expr);                                                                          \
    if (_rc != (int)(want)) {                                                                       \
      sftest::failures()++;                                                                         \
      fprintf(stderr, "  %s:%d: %s returned %d (%s), expected %d (%s) %s\n", __FILE__, __LINE__, #expr, \
              _rc, sf_status_string(_rc), (int)(want), sf_status_string(want), sf_last_error_detail());  \
    }                                                                                               \
  } while (0)

#define SF_TEST_MAIN() \
  int main(int argc, char **argv) { return sftest::run_all(argc, argv); }
