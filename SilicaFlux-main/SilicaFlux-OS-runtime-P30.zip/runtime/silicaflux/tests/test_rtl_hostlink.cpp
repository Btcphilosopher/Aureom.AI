// SilicaFlux.OS -- tests on the RTL simulation of the P25 HostLink PCIe device.
// The runtime drives the unmodified P25 C driver; every byte moves through the
// RTL DMA engine (H2D/D2H over the simulated PCIe/IOMMU host model) and every
// multiply-accumulate runs on the RTL tensor engine.
#include <cstdio>
#include <cstring>
#include <random>
#include <vector>

#include "sf_reference.h"
#include "sf_test.h"
#include "silicaflux/silicaflux.h"

using namespace sf::ref;

namespace {
sf_device_t g_d = 0;
sf_queue_t g_q = 0;

sf_device_t dev(uint32_t flags = 0) {
  if (!g_d) {
    if (sf_device_open_by_name("rtl-hostlink", flags, &g_d) != SF_OK) {
      fprintf(stderr, "cannot open rtl-hostlink: %s\n", sf_last_error_detail());
      exit(2);
    }
    sf_queue_create(g_d, 16, &g_q);
  }
  return g_d;
}
void reopen(uint32_t flags) {
  if (g_d) sf_device_close(g_d);
  g_d = 0;
  dev(flags);
}
sf_buffer_t mkbuf(uint64_t size) {
  sf_buffer_t b = 0;
  if (sf_buffer_create(dev(), size, SF_MEM_READ_WRITE, &b) != SF_OK) {
    fprintf(stderr, "buffer: %s\n", sf_last_error_detail());
    exit(2);
  }
  return b;
}

sf_status gemm(uint32_t M, uint32_t N, uint32_t K, uint32_t ldc_pad, size_t *bad, sf_cmd_result *res) {
  std::mt19937 g(M * 7 + N * 131 + K);
  uint32_t ldc = 4 * N + ldc_pad;
  std::vector<int8_t> A((size_t)M * K), B((size_t)K * N);
  for (auto &v : A) v = (int8_t)g();
  for (auto &v : B) v = (int8_t)g();
  size_t cb = (size_t)(M - 1) * ldc + 4 * N;
  std::vector<uint8_t> C(cb, 0xA5), R(cb, 0xA5);
  sf_buffer_t a = mkbuf(A.size()), b = mkbuf(B.size()), c = mkbuf(cb);
  sf_buffer_write(a, 0, A.data(), A.size());
  sf_buffer_write(b, 0, B.data(), B.size());
  sf_buffer_write(c, 0, C.data(), cb);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K; gd.ldc = ldc;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t id;
  sf_status s = sf_tensor_gemm(g_q, a, b, c, &gd, &id);
  if (s == SF_OK) s = sf_queue_wait(g_q, id, SF_TIMEOUT_DEFAULT, res);
  if (s == SF_OK) {
    sf_buffer_read(c, 0, C.data(), cb);
    gemm_i8_i32(M, N, K, A.data(), K, B.data(), N, reinterpret_cast<int32_t *>(R.data()), ldc);
    *bad = 0;
    for (size_t i = 0; i < cb; i++) *bad += C[i] != R[i];
  }
  for (auto h : {a, b, c}) sf_buffer_release(h);
  return s;
}
}  // namespace

SF_TEST(hostlink_identity_and_capabilities) {
  dev();
  sf_device_info i{};
  i.struct_size = sizeof i;
  ASSERT_OK(sf_device_get_info(g_d, &i));
  printf("  %s: %s, ABI %u.%u, HW_REV %08x, %llu bytes device memory\n", i.name, i.hardware_id,
         i.device_abi_version >> 16, i.device_abi_version & 0xFFFF, i.hardware_revision,
         (unsigned long long)i.device_memory_bytes);
  EXPECT_EQ(i.kind, (uint32_t)SF_DEVICE_RTL_SIMULATOR);
  EXPECT_EQ(i.is_simulator, 1u);
  EXPECT_EQ(i.device_abi_version >> 16, 1u);
  EXPECT_TRUE(i.caps & SF_CAP_GEMM_I8_I32);
  EXPECT_EQ(i.caps & (SF_CAP_VECTOR_F32 | SF_CAP_GEMM_I8_Q8 | SF_CAP_COPY), 0u);   // honest capability set
  EXPECT_EQ(i.device_memory_bytes, 65536u);
}

SF_TEST(hostlink_dma_transfers_including_unaligned_edges) {
  dev();
  sf_buffer_t b = mkbuf(5000);
  std::vector<uint8_t> X(5000), Y(5000);
  for (size_t i = 0; i < X.size(); i++) X[i] = (uint8_t)(i * 31 + 7);
  ASSERT_OK(sf_buffer_write(b, 0, X.data(), X.size()));
  ASSERT_OK(sf_buffer_read(b, 0, Y.data(), Y.size()));
  EXPECT_TRUE(X == Y);
  uint8_t patch[13] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
  ASSERT_OK(sf_buffer_write(b, 3, patch, 13));   // not 8-byte aligned at either end: read-modify-write
  memcpy(X.data() + 3, patch, 13);
  ASSERT_OK(sf_buffer_read(b, 0, Y.data(), Y.size()));
  EXPECT_TRUE(X == Y);
  uint8_t mid[5];
  ASSERT_OK(sf_buffer_read(b, 4997 - 5, mid, 5));
  EXPECT_TRUE(!memcmp(mid, X.data() + 4992, 5));
  sf_buffer_release(b);
}

SF_TEST(hostlink_gemm_on_rtl_tensor_engine) {
  dev();
  struct { uint32_t m, n, k, pad; } cases[] = {{4, 4, 64, 0}, {17, 13, 29, 0}, {9, 11, 40, 12}, {8, 8, 1500, 0}, {24, 20, 128, 0}};
  for (auto &c : cases) {
    size_t bad = 99;
    sf_cmd_result r{};
    r.struct_size = sizeof r;
    ASSERT_OK(gemm(c.m, c.n, c.k, c.pad, &bad, &r));
    printf("  GEMM %ux%ux%u%s: %zu byte mismatches; %u HostLink commands, %llu tensor-engine cycles, exec=%u flags=%#x\n",
           c.m, c.n, c.k, c.pad ? " (strided C)" : "", bad, r.device_commands, (unsigned long long)r.engine_cycles,
           r.exec_target, r.flags);
    EXPECT_EQ(bad, (size_t)0);
    EXPECT_EQ(r.exec_target, (uint32_t)SF_EXEC_RTL_SIMULATION);
    EXPECT_TRUE(r.flags & SF_RESULT_HOST_ASSISTED);
    EXPECT_EQ(r.macs, (uint64_t)c.m * c.n * c.k);
    EXPECT_TRUE(r.engine_cycles > 0);
  }
}

SF_TEST(hostlink_unsupported_operations_rejected) {
  dev();
  sf_buffer_t a = mkbuf(256), o = mkbuf(256);
  sf_cmd_t id;
  EXPECT_STATUS(sf_vector_add(g_q, a, a, o, 64, SF_DTYPE_F32, nullptr, &id), SF_ERR_UNSUPPORTED);
  EXPECT_STATUS(sf_buffer_copy(g_q, a, o, 256, &id), SF_ERR_UNSUPPORTED);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = gd.n = 4; gd.k = 16;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I8;
  EXPECT_STATUS(sf_tensor_gemm(g_q, a, a, o, &gd, &id), SF_ERR_UNSUPPORTED);
  uint32_t w[8] = {};
  EXPECT_STATUS(sf_debug_submit_raw(g_q, SF_ENGINE_TENSOR, w, 8, &id), SF_ERR_UNSUPPORTED);
  sf_buffer_release(a);
  sf_buffer_release(o);
}

SF_TEST(hostlink_host_dma_fault_and_recovery) {
  dev();
  sf_buffer_t b = mkbuf(256), a = mkbuf(8 * 32), bb = mkbuf(32 * 8), c = mkbuf(4 * 64);
  uint8_t x[256] = {1};
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = 8; gd.n = 8; gd.k = 32;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  ASSERT_OK(sf_debug_inject(g_d, SF_INJECT_HOST_DMA_ERROR, b, 0, 256));   // IOMMU/bus error on the host side
  EXPECT_STATUS(sf_buffer_write(b, 0, x, 256), SF_ERR_DMA);
  sf_cmd_t id;
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  ASSERT_OK(sf_tensor_gemm(g_q, a, bb, c, &gd, &id));
  EXPECT_STATUS(sf_queue_wait(g_q, id, SF_TIMEOUT_DEFAULT, &r), SF_ERR_DMA);
  EXPECT_EQ(r.device_status, 7u);   // HOST_BUS_ERROR in the completion entry
  ASSERT_OK(sf_debug_inject(g_d, SF_INJECT_CLEAR, 0, 0, 0));
  ASSERT_OK(sf_buffer_write(b, 0, x, 256));
  size_t bad = 1;
  ASSERT_OK(gemm(8, 8, 32, 0, &bad, &r));
  EXPECT_EQ(bad, (size_t)0);
  sf_device_status st{};
  st.struct_size = sizeof st;
  ASSERT_OK(sf_device_get_status(g_d, &st));
  printf("  %s\n", st.detail);
  EXPECT_EQ(st.state, (uint32_t)SF_STATE_READY);
  for (auto h : {b, a, bb, c}) sf_buffer_release(h);
}

SF_TEST(hostlink_queue_full_timeout_reset) {
  dev();
  const uint32_t M = 64, N = 64, K = 256;
  sf_buffer_t a = mkbuf(M * K), b = mkbuf(K * N), c = mkbuf(4 * M * N);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t ids[17] = {};
  for (int i = 0; i < 16; i++) ASSERT_OK(sf_tensor_gemm(g_q, a, b, c, &gd, &ids[i]));
  EXPECT_STATUS(sf_tensor_gemm(g_q, a, b, c, &gd, &ids[16]), SF_ERR_QUEUE_FULL);
  EXPECT_STATUS(sf_queue_wait(g_q, ids[0], 1, nullptr), SF_ERR_TIMEOUT);   // 1 ms simulated
  ASSERT_OK(sf_device_reset(g_d, SF_RESET_ENGINES));
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  EXPECT_STATUS(sf_queue_poll(g_q, ids[0], &r), SF_ERR_ABORTED);
  EXPECT_STATUS(sf_queue_poll(g_q, ids[15], &r), SF_ERR_ABORTED);
  size_t bad = 9;
  ASSERT_OK(gemm(16, 12, 48, 0, &bad, &r));
  EXPECT_EQ(bad, (size_t)0);
  ASSERT_OK(sf_device_reset(g_d, SF_RESET_FULL));
  ASSERT_OK(gemm(5, 6, 7, 0, &bad, &r));
  EXPECT_EQ(bad, (size_t)0);
  for (auto h : {a, b, c}) sf_buffer_release(h);
}

SF_TEST(hostlink_counters) {
  dev();
  ASSERT_OK(sf_device_clear_counters(g_d));
  size_t bad;
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  ASSERT_OK(gemm(12, 8, 40, 0, &bad, &r));
  sf_counter cs[64];
  uint32_t n = 0;
  ASSERT_OK(sf_device_read_counters(g_d, cs, 64, &n));
  uint64_t eng = 0, h2d = 0, done = 0;
  for (uint32_t i = 0; i < n && i < 64; i++) {
    if (!strcmp(cs[i].name, "hostlink.engine_cycles")) eng = cs[i].value;
    if (!strcmp(cs[i].name, "hostlink.bytes_h2d")) h2d = cs[i].value;
    if (!strcmp(cs[i].name, "hostlink.cmds_completed")) done = cs[i].value;
  }
  printf("  hardware counters: cmds_completed=%llu bytes_h2d=%llu engine_cycles=%llu (record sum %llu)\n",
         (unsigned long long)done, (unsigned long long)h2d, (unsigned long long)eng, (unsigned long long)r.engine_cycles);
  EXPECT_TRUE(h2d > 0);
  EXPECT_TRUE(eng >= r.engine_cycles);
  sf_perf_summary ps{};
  ps.struct_size = sizeof ps;
  ASSERT_OK(sf_device_perf_summary(g_d, &ps));
  EXPECT_EQ(ps.tensor_macs, UINT64_MAX);   // no MAC counter in this hardware: not invented
}

SF_TEST(hostlink_explicit_cpu_fallback_is_marked) {
  reopen(SF_OPEN_ALLOW_CPU_FALLBACK);
  const size_t n = 100;
  std::vector<uint32_t> X(n), Y(n), Z(n), W(n);
  for (size_t i = 0; i < n; i++) {
    float f = (float)i * 0.5f, g = 3.0f - (float)i;
    memcpy(&X[i], &f, 4);
    memcpy(&Y[i], &g, 4);
  }
  sf_buffer_t x = mkbuf(4 * n), y = mkbuf(4 * n), z = mkbuf(4 * n);
  ASSERT_OK(sf_buffer_write(x, 0, X.data(), 4 * n));
  ASSERT_OK(sf_buffer_write(y, 0, Y.data(), 4 * n));
  sf_cmd_t id;
  ASSERT_OK(sf_vector_add(g_q, x, y, z, n, SF_DTYPE_F32, nullptr, &id));
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  ASSERT_OK(sf_queue_wait(g_q, id, SF_TIMEOUT_DEFAULT, &r));
  EXPECT_EQ(r.exec_target, (uint32_t)SF_EXEC_CPU_FALLBACK);   // never reported as device execution
  ASSERT_OK(sf_buffer_read(z, 0, Z.data(), 4 * n));
  vec_f32(VecOp::kAdd, 0, n, X.data(), nullptr, Y.data(), nullptr, W.data());
  EXPECT_TRUE(Z == W);
  // the GEMM still runs on the device in the same queue, in order
  size_t bad = 1;
  ASSERT_OK(gemm(6, 5, 20, 0, &bad, &r));
  EXPECT_EQ(r.exec_target, (uint32_t)SF_EXEC_RTL_SIMULATION);
  EXPECT_EQ(bad, (size_t)0);
}

int main(int argc, char **argv) {
  int rc = sftest::run_all(argc, argv);
  if (g_d) sf_device_close(g_d);
  return rc;
}
