// SilicaFlux.OS -- tests on the RTL simulation of the P21 ControlCore system.
//
// Every result here is computed by the Verilated RTL (vector tile, tensor unit,
// system DMA) under the runtime firmware, and compared bit-for-bit with the
// independent reference (src/ref) and with the CPU reference backend.
// Groups (ctest runs each in its own process, each boots the device once):
//   kernels_   all kernels, all rounding modes, chunking, counters, traces, queue semantics
//   faults_    invalid commands, DMA failures, host and device timeouts, invalid handles
//   recovery_  reset during execution, full reset, RAS events, host interruption
//   compat_    firmware revision handling (stock P21 firmware, SFRQ ABI 2.0, corrupted image)
//   selftest_  the P21 firmware self-test suite running on the RTL under the runtime firmware
//   lost_      unresponsive device -> SF_ERR_DEVICE_LOST -> full reset
#include <unistd.h>

#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <random>
#include <string>
#include <thread>
#include <vector>

#include "sf_reference.h"
#include "sf_softfloat.h"
#include "sf_test.h"
#include "silicaflux/silicaflux.h"

using namespace sf::ref;

#ifndef SF_FW_DIR
#define SF_FW_DIR "firmware"
#endif

namespace {

struct Dev {
  sf_device_t d = 0;
  sf_queue_t q = 0;
  sf_device_info info{};
};

Dev g_dev;
Dev &dev() {
  Dev &D = g_dev;
  if (!D.d) {
    auto t0 = std::chrono::steady_clock::now();
    if (sf_device_open_by_name("rtl-cc", 0, &D.d) != SF_OK) {
      fprintf(stderr, "cannot open rtl-cc: %s\n", sf_last_error_detail());
      exit(2);
    }
    D.info.struct_size = sizeof D.info;
    sf_device_get_info(D.d, &D.info);
    sf_queue_create(D.d, 16, &D.q);
    printf("  [rtl-cc booted in %.1f s: fw %08x, SFRQ ABI %08x, %s]\n",
           std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(), D.info.firmware_version,
           D.info.device_abi_version, D.info.hardware_id);
  }
  return D;
}

sf_buffer_t mkbuf(uint64_t size, uint32_t flags = SF_MEM_READ_WRITE) {
  sf_buffer_t b = 0;
  if (sf_buffer_create(dev().d, size, flags, &b) != SF_OK) {
    fprintf(stderr, "buffer: %s\n", sf_last_error_detail());
    exit(2);
  }
  return b;
}

std::vector<uint32_t> fp_operands(std::mt19937 &g, size_t n, bool specials) {
  std::vector<uint32_t> v(n);
  std::uniform_real_distribution<float> u(-1000.f, 1000.f);
  static const uint32_t sp[] = {0x7F800000u, 0xFF800000u, 0x7FC00000u, 0x7F800001u, 0x00000001u, 0x80000000u,
                                0x007FFFFFu, 0x7F7FFFFFu, 0x00800000u, 0x3F800000u};
  for (size_t i = 0; i < n; i++) {
    float f = u(g);
    memcpy(&v[i], &f, 4);
    if (specials && g() % 16 == 0) v[i] = sp[g() % 10];
    if (specials && g() % 16 == 1) v[i] = (uint32_t)g() & 0x807FFFFFu;   // subnormals
  }
  return v;
}

sf_cmd_result wait_ok(sf_cmd_t id, sf_status *st = nullptr) {
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  sf_status s = sf_queue_wait(dev().q, id, SF_TIMEOUT_DEFAULT, &r);
  if (st) *st = s;
  return r;
}

}  // namespace

// ================================================================== kernels
SF_TEST(kernels_identity) {
  Dev &D = dev();
  EXPECT_EQ(D.info.kind, (uint32_t)SF_DEVICE_RTL_SIMULATOR);
  EXPECT_EQ(D.info.is_simulator, 1u);
  EXPECT_EQ(D.info.device_abi_version >> 16, 1u);
  EXPECT_EQ(D.info.firmware_version, 0x00020000u);
  EXPECT_EQ(D.info.vector_lanes, 4u);
  EXPECT_EQ(D.info.tensor_array_rows, 4u);
  EXPECT_EQ(D.info.gemm_max_k, 131071u);
  EXPECT_EQ(D.info.max_vector_elements, 63ull * 4096);   // advertised limit == enforced limit
  EXPECT_TRUE((D.info.caps & (SF_CAP_VECTOR_F32 | SF_CAP_GEMM_I8_I32 | SF_CAP_GEMM_I8_Q8 | SF_CAP_HW_COUNTERS)) ==
              (SF_CAP_VECTOR_F32 | SF_CAP_GEMM_I8_I32 | SF_CAP_GEMM_I8_Q8 | SF_CAP_HW_COUNTERS));
  sf_device_status st{};
  st.struct_size = sizeof st;
  ASSERT_OK(sf_device_get_status(D.d, &st));
  EXPECT_EQ(st.state, (uint32_t)SF_STATE_READY);
  printf("  status: %s\n", st.detail);
}

SF_TEST(kernels_vector_fp32_all_rounding_modes_bit_exact) {
  Dev &D = dev();
  std::mt19937 g(2026);
  const size_t n = 517;   // not a multiple of the lane count
  auto A = fp_operands(g, n, true), B = fp_operands(g, n, true), C = fp_operands(g, n, true);
  sf_buffer_t a = mkbuf(4 * n), b = mkbuf(4 * n), c = mkbuf(4 * n), o = mkbuf(4 * n);
  ASSERT_OK(sf_buffer_write(a, 0, A.data(), 4 * n));
  ASSERT_OK(sf_buffer_write(b, 0, B.data(), 4 * n));
  ASSERT_OK(sf_buffer_write(c, 0, C.data(), 4 * n));
  std::vector<uint32_t> got(n), want(n);
  float alpha = -0.3125f;
  uint32_t ab;
  memcpy(&ab, &alpha, 4);
  int mism = 0, flag_mism = 0, runs = 0;
  uint64_t cycles = 0;
  for (uint32_t rm = 0; rm <= 4; rm++) {
    sf_vector_opts o_{sizeof o_, rm};
    for (int op = 0; op < 4; op++) {
      sf_cmd_t id;
      uint32_t fl = 0;
      if (op == 0) { ASSERT_OK(sf_vector_add(D.q, a, b, o, n, SF_DTYPE_F32, &o_, &id)); fl = vec_f32(VecOp::kAdd, rm, n, A.data(), nullptr, B.data(), nullptr, want.data()); }
      if (op == 1) { ASSERT_OK(sf_vector_mul(D.q, a, b, o, n, SF_DTYPE_F32, &o_, &id)); fl = vec_f32(VecOp::kMul, rm, n, A.data(), nullptr, B.data(), nullptr, want.data()); }
      if (op == 2) { ASSERT_OK(sf_vector_fma(D.q, a, b, c, o, n, &o_, &id)); fl = vec_f32(VecOp::kFma, rm, n, A.data(), nullptr, B.data(), C.data(), want.data()); }
      if (op == 3) { ASSERT_OK(sf_vector_axpy(D.q, alpha, b, c, o, n, &o_, &id)); fl = vec_f32(VecOp::kFma, rm, n, nullptr, &ab, B.data(), C.data(), want.data()); }
      sf_status s;
      sf_cmd_result r = wait_ok(id, &s);
      ASSERT_OK(s);
      ASSERT_OK(sf_buffer_read(o, 0, got.data(), 4 * n));
      for (size_t i = 0; i < n; i++)
        if (got[i] != want[i]) {
          if (mism < 5) fprintf(stderr, "  rm%u op%d [%zu] a=%08x b=%08x c=%08x: rtl %08x ref %08x\n", rm, op, i, A[i], B[i], C[i], got[i], want[i]);
          mism++;
        }
      if (r.fp_flags != fl) flag_mism++;
      EXPECT_EQ(r.exec_target, (uint32_t)SF_EXEC_RTL_SIMULATION);
      EXPECT_EQ(r.elements, (uint64_t)n);
      cycles += r.engine_cycles;
      runs++;
    }
  }
  printf("  %d vector commands x %zu elements (incl. inf/NaN/subnormals), 5 rounding modes: %d value and %d flag "
         "mismatches; %llu tile cycles\n", runs, n, mism, flag_mism, (unsigned long long)cycles);
  EXPECT_EQ(mism, 0);
  EXPECT_EQ(flag_mism, 0);
  for (auto h : {a, b, c, o}) sf_buffer_release(h);
}

SF_TEST(kernels_vector_int32_and_chunking) {
  Dev &D = dev();
  std::mt19937 g(7);
  const size_t n = 9001;   // > 4096: three tile KERNEL commands
  std::vector<int32_t> X(n), Y(n), Z(n), W(n);
  for (size_t i = 0; i < n; i++) { X[i] = (int32_t)g(); Y[i] = (int32_t)g(); }
  sf_buffer_t x = mkbuf(4 * n), y = mkbuf(4 * n), z = mkbuf(4 * n);
  ASSERT_OK(sf_buffer_write(x, 0, X.data(), 4 * n));
  ASSERT_OK(sf_buffer_write(y, 0, Y.data(), 4 * n));
  for (int op = 0; op < 2; op++) {
    sf_cmd_t id;
    if (op == 0) ASSERT_OK(sf_vector_add(D.q, x, y, z, n, SF_DTYPE_I32, nullptr, &id));
    else ASSERT_OK(sf_vector_mul(D.q, x, y, z, n, SF_DTYPE_I32, nullptr, &id));
    sf_status s;
    sf_cmd_result r = wait_ok(id, &s);
    ASSERT_OK(s);
    EXPECT_EQ(r.device_commands, 3u);
    EXPECT_TRUE((r.flags & SF_RESULT_CHUNKED) != 0);
    ASSERT_OK(sf_buffer_read(z, 0, Z.data(), 4 * n));
    vec_i32(op ? VecOp::kMul : VecOp::kAdd, n, X.data(), Y.data(), W.data());
    EXPECT_TRUE(Z == W);
  }
  for (auto h : {x, y, z}) sf_buffer_release(h);
}

SF_TEST(kernels_dot_product_defined_order_with_chaining) {
  Dev &D = dev();
  std::mt19937 g(11);
  for (size_t n : {7ul, 4096ul, 10007ul}) {
    auto A = fp_operands(g, n, false), B = fp_operands(g, n, false);
    sf_buffer_t a = mkbuf(4 * n), b = mkbuf(4 * n), out = mkbuf(4);
    ASSERT_OK(sf_buffer_write(a, 0, A.data(), 4 * n));
    ASSERT_OK(sf_buffer_write(b, 0, B.data(), 4 * n));
    for (uint32_t rm : {0u, 2u, 4u}) {
      sf_vector_opts o{sizeof o, rm};
      sf_cmd_t id;
      ASSERT_OK(sf_vector_dot(D.q, a, b, out, n, &o, &id));
      sf_status s;
      sf_cmd_result r = wait_ok(id, &s);
      ASSERT_OK(s);
      uint32_t fl = 0, want = dot_f32(n, A.data(), B.data(), rm, D.info.vector_lanes, 0, &fl), got = 0;
      ASSERT_OK(sf_buffer_read(out, 0, &got, 4));
      EXPECT_EQ(got, want);
      EXPECT_EQ(r.scalar_bits, want);
      EXPECT_EQ(r.fp_flags, fl);
      if (n == 10007 && rm == 0) {
        float f;
        memcpy(&f, &got, 4);
        printf("  dot n=%zu (%u chained tile commands) = %.6g, bit-exact with the defined order\n", n, r.device_commands, f);
      }
    }
    for (auto h : {a, b, out}) sf_buffer_release(h);
  }
}

static void gemm_case(uint32_t M, uint32_t N, uint32_t K, uint32_t lda_pad, bool q8, uint32_t rm, bool relu) {
  Dev &D = dev();
  std::mt19937 g(M * 131 + N * 7 + K);
  uint32_t lda = K + lda_pad, ldb = N, es = q8 ? 1 : 4, ldc = N * es + (q8 ? 3 : 0);
  std::vector<int8_t> A((size_t)M * lda), B((size_t)K * ldb);
  for (auto &v : A) v = (int8_t)g();
  for (auto &v : B) v = (int8_t)g();
  size_t cbytes = (size_t)(M - 1) * ldc + (size_t)N * es;
  std::vector<uint8_t> C(cbytes, 0x5A), R(cbytes, 0x5A);
  sf_buffer_t a = mkbuf(A.size()), b = mkbuf(B.size()), c = mkbuf(cbytes);
  ASSERT_OK(sf_buffer_write(a, 0, A.data(), A.size()));
  ASSERT_OK(sf_buffer_write(b, 0, B.data(), B.size()));
  ASSERT_OK(sf_buffer_write(c, 0, C.data(), cbytes));
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K; gd.lda = lda; gd.ldb = ldb; gd.ldc = ldc;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = q8 ? SF_DTYPE_I8 : SF_DTYPE_I32;
  gd.q_mult = 0x5A82799A; gd.q_shift = 41; gd.q_zero_point = -3; gd.relu = relu; gd.rounding = rm;
  sf_cmd_t id;
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, c, &gd, &id));
  sf_status s;
  sf_cmd_result r = wait_ok(id, &s);
  ASSERT_OK(s);
  ASSERT_OK(sf_buffer_read(c, 0, C.data(), cbytes));
  bool sat = false;
  if (q8) sat = gemm_i8_q8(M, N, K, A.data(), lda, B.data(), ldb, (int8_t *)R.data(), ldc, gd.q_mult, gd.q_shift, -3, relu, rm);
  else gemm_i8_i32(M, N, K, A.data(), lda, B.data(), ldb, (int32_t *)R.data(), ldc);
  size_t bad = 0;
  for (size_t i = 0; i < cbytes; i++) bad += C[i] != R[i];
  printf("  GEMM %ux%ux%u %s%s rm%u: %zu byte mismatches, %llu tensor cycles, %llu MACs, queue delay %llu cycles\n",
         M, N, K, q8 ? "INT8-requant" : "INT32", relu ? "+ReLU" : "", rm, bad, (unsigned long long)r.engine_cycles,
         (unsigned long long)r.macs, (unsigned long long)r.device_queue_cycles);
  EXPECT_EQ(bad, (size_t)0);
  EXPECT_EQ(r.macs, (uint64_t)M * N * K);
  if (q8) EXPECT_EQ((r.flags & SF_RESULT_SATURATED) != 0, sat);
  EXPECT_TRUE(r.device_end_cycle > r.device_start_cycle);
  for (auto h : {a, b, c}) sf_buffer_release(h);
}

SF_TEST(kernels_gemm_int32_shapes_and_strides) {
  gemm_case(1, 1, 1, 0, false, 0, false);
  gemm_case(17, 13, 29, 0, false, 0, false);
  gemm_case(9, 11, 40, 5, false, 0, false);
  gemm_case(32, 24, 200, 3, false, 0, false);
}

SF_TEST(kernels_gemm_requantised_int8_all_rounding_modes) {
  for (uint32_t rm = 0; rm <= 4; rm++) gemm_case(9, 11, 40, 0, true, rm, rm == 0);
}

SF_TEST(kernels_copy_counters_trace) {
  Dev &D = dev();
  ASSERT_OK(sf_device_clear_counters(D.d));
  std::vector<uint32_t> X(1024);
  for (size_t i = 0; i < X.size(); i++) X[i] = 0xC0DE0000u + (uint32_t)i;
  sf_buffer_t a = mkbuf(4096), b = mkbuf(4096), x = mkbuf(4 * 640), out = mkbuf(4 * 640);
  ASSERT_OK(sf_buffer_write(a, 0, X.data(), 4096));
  const char *path = "rtl_cc_trace.json";
  ASSERT_OK(sf_trace_start(D.d, path));
  sf_cmd_t id;
  ASSERT_OK(sf_buffer_copy(D.q, a, b, 4096, &id));
  wait_ok(id);
  std::vector<uint32_t> Y(1024);
  ASSERT_OK(sf_buffer_read(b, 0, Y.data(), 4096));
  EXPECT_TRUE(X == Y);
  ASSERT_OK(sf_vector_add(D.q, x, x, out, 640, SF_DTYPE_F32, nullptr, &id));
  wait_ok(id);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = 12; gd.n = 8; gd.k = 40;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_buffer_t ga = mkbuf(480), gb = mkbuf(320), gc = mkbuf(384);
  ASSERT_OK(sf_tensor_gemm(D.q, ga, gb, gc, &gd, &id));
  wait_ok(id);
  ASSERT_OK(sf_trace_stop(D.d));
  // exact hardware counters for exactly this work
  sf_counter cs[128];
  uint32_t n = 0;
  ASSERT_OK(sf_device_read_counters(D.d, cs, 128, &n));
  auto get = [&](const char *name) -> uint64_t {
    for (uint32_t i = 0; i < n && i < 128; i++)
      if (!strcmp(cs[i].name, name)) return cs[i].value;
    return ~0ull;
  };
  EXPECT_EQ(get("tile.vec_elems"), 640u);
  EXPECT_EQ(get("tile.kernel_cmds"), 1u);
  EXPECT_EQ(get("tensor.gemm_ok"), 1u);
  EXPECT_EQ(get("tensor.macs"), 12u * 8 * 40);
  EXPECT_EQ(get("fw.system_dma_bytes") >= 4096, true);
  EXPECT_TRUE(get("cc.cycles") > 0 && get("cc.cycles") != ~0ull);
  sf_perf_summary ps{};
  ps.struct_size = sizeof ps;
  ASSERT_OK(sf_device_perf_summary(D.d, &ps));
  EXPECT_EQ(ps.tensor_macs, 3840u);
  EXPECT_EQ(ps.vector_elements, 640u);
  printf("  counters: cc.cycles=%llu tile.vec_elems=%llu tensor.macs=%llu dma_bytes=%llu stalls=%llu "
         "spm_conflicts=%llu\n", (unsigned long long)ps.device_cycles, (unsigned long long)ps.vector_elements,
         (unsigned long long)ps.tensor_macs, (unsigned long long)ps.device_dma_bytes,
         (unsigned long long)ps.dma_stall_cycles, (unsigned long long)ps.sram_conflict_cycles);
  std::ifstream f(path);
  std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  EXPECT_TRUE(s.find("\"exec_target\": \"rtl_simulation\"") != std::string::npos);
  EXPECT_TRUE(s.find("\"name\": \"tensor.macs\", \"value\": 3840, \"unit\": \"macs\", \"source\": \"hardware_counter\"") !=
              std::string::npos);
  remove(path);
  for (auto h : {a, b, x, out, ga, gb, gc}) sf_buffer_release(h);
}

SF_TEST(kernels_differential_vs_cpu_backend) {
  // the same logical workload on the CPU reference device and on the RTL
  sf_device_t cpu;
  ASSERT_OK(sf_device_open_by_name("cpu", 0, &cpu));
  sf_queue_t cq;
  ASSERT_OK(sf_queue_create(cpu, 8, &cq));
  Dev &D = dev();
  std::mt19937 g(99);
  const uint32_t M = 20, N = 12, K = 64;
  const size_t n = 300;
  std::vector<int8_t> A(M * K), B(K * N);
  for (auto &v : A) v = (int8_t)g();
  for (auto &v : B) v = (int8_t)g();
  auto X = fp_operands(g, n, true), Y = fp_operands(g, n, true);
  std::vector<uint8_t> outs[2][3];
  sf_device_t devs[2] = {cpu, D.d};
  sf_queue_t qs[2] = {cq, D.q};
  for (int k = 0; k < 2; k++) {
    sf_buffer_t a, b, c, x, y, o, s;
    sf_buffer_create(devs[k], A.size(), SF_MEM_READ_WRITE, &a);
    sf_buffer_create(devs[k], B.size(), SF_MEM_READ_WRITE, &b);
    sf_buffer_create(devs[k], 4 * M * N, SF_MEM_READ_WRITE, &c);
    sf_buffer_create(devs[k], 4 * n, SF_MEM_READ_WRITE, &x);
    sf_buffer_create(devs[k], 4 * n, SF_MEM_READ_WRITE, &y);
    sf_buffer_create(devs[k], 4 * n, SF_MEM_READ_WRITE, &o);
    sf_buffer_create(devs[k], 4, SF_MEM_READ_WRITE, &s);
    sf_buffer_write(a, 0, A.data(), A.size());
    sf_buffer_write(b, 0, B.data(), B.size());
    sf_buffer_write(x, 0, X.data(), 4 * n);
    sf_buffer_write(y, 0, Y.data(), 4 * n);
    sf_gemm_desc gd{};
    gd.struct_size = sizeof gd;
    gd.m = M; gd.n = N; gd.k = K;
    gd.a_type = gd.b_type = SF_DTYPE_I8;
    gd.c_type = SF_DTYPE_I32;
    sf_vector_opts o_{sizeof o_, SF_ROUND_UP};
    ASSERT_OK(sf_tensor_gemm(qs[k], a, b, c, &gd, nullptr));
    ASSERT_OK(sf_vector_fma(qs[k], x, y, x, o, n, &o_, nullptr));
    ASSERT_OK(sf_vector_dot(qs[k], x, y, s, n, &o_, nullptr));
    ASSERT_OK(sf_queue_wait(qs[k], SF_CMD_ALL, SF_TIMEOUT_DEFAULT, nullptr));
    outs[k][0].resize(4 * M * N);
    outs[k][1].resize(4 * n);
    outs[k][2].resize(4);
    sf_buffer_read(c, 0, outs[k][0].data(), 4 * M * N);
    sf_buffer_read(o, 0, outs[k][1].data(), 4 * n);
    sf_buffer_read(s, 0, outs[k][2].data(), 4);
    for (auto h : {a, b, c, x, y, o, s}) sf_buffer_release(h);
  }
  EXPECT_TRUE(outs[0][0] == outs[1][0]);
  EXPECT_TRUE(outs[0][1] == outs[1][1]);
  EXPECT_TRUE(outs[0][2] == outs[1][2]);
  ASSERT_OK(sf_device_close(cpu));
}

SF_TEST(kernels_queue_full_order_and_poll) {
  Dev &D = dev();
  sf_queue_t q2;
  ASSERT_OK(sf_queue_create(D.d, 2, &q2));
  const uint32_t M = 32, N = 32, K = 256;
  sf_buffer_t a = mkbuf(M * K), b = mkbuf(K * N), c1 = mkbuf(4 * M * N), c2 = mkbuf(4 * M * N);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t i1, i2, i3 = 0;
  ASSERT_OK(sf_tensor_gemm(q2, a, b, c1, &gd, &i1));
  ASSERT_OK(sf_tensor_gemm(q2, a, b, c2, &gd, &i2));
  EXPECT_STATUS(sf_tensor_gemm(q2, a, b, c1, &gd, &i3), SF_ERR_QUEUE_FULL);
  EXPECT_EQ(i3, 0u);
  sf_cmd_result r1{}, r2{};
  r1.struct_size = r2.struct_size = sizeof r1;
  EXPECT_STATUS(sf_queue_poll(q2, i1, &r1), SF_PENDING);
  int polls = 0;
  while (sf_queue_poll(q2, i2, &r2) == SF_PENDING) polls++;
  ASSERT_OK(sf_queue_poll(q2, i1, &r1));
  EXPECT_TRUE(r1.device_end_cycle <= r2.device_start_cycle);   // in-order, one at a time
  EXPECT_TRUE(r2.device_queue_cycles >= r1.engine_cycles / 2);  // the second waited behind the first
  printf("  2 queued GEMMs: %d polls; #1 cycles %llu, #2 waited %llu device cycles before starting\n", polls,
         (unsigned long long)r1.engine_cycles, (unsigned long long)r2.device_queue_cycles);
  ASSERT_OK(sf_queue_destroy(q2));
  for (auto h : {a, b, c1, c2}) sf_buffer_release(h);
}

// ================================================================== faults
SF_TEST(faults_invalid_commands_rejected_by_the_engines) {
  Dev &D = dev();
  sf_buffer_t d = mkbuf(64);
  sf_buffer_info bi{};
  bi.struct_size = sizeof bi;
  sf_buffer_get_info(d, &bi);
  // tile descriptor with a reserved command TYPE (5): BAD_TYPE, nothing executed
  uint32_t vec[8] = {0x5u | (0x77u << 16), 4, 0, (uint32_t)bi.device_address, (uint32_t)bi.device_address, 0,
                     (uint32_t)bi.device_address, 0x30000000u};
  sf_cmd_t id;
  ASSERT_OK(sf_debug_submit_raw(D.q, SF_ENGINE_VECTOR, vec, 8, &id));
  sf_status s;
  sf_cmd_result r = wait_ok(id, &s);
  EXPECT_STATUS(s, SF_ERR_INVALID_COMMAND);
  EXPECT_EQ((r.device_status >> 8) & 0xF, 1u);   // tile STATUS BAD_TYPE
  // tensor descriptor with VERSION 1: rejected with ERR_CODE VERSION (0x01)
  uint32_t gem[12] = {0x40u | (1u << 8) | (1u << 16) | (0x92u << 24), (uint32_t)bi.device_address,
                      (uint32_t)bi.device_address, (uint32_t)bi.device_address + 32, 1 | (1 << 16), 1, 1, 1, 4, 0, 0, 0};
  ASSERT_OK(sf_debug_submit_raw(D.q, SF_ENGINE_TENSOR, gem, 12, &id));
  r = wait_ok(id, &s);
  EXPECT_STATUS(s, SF_ERR_INVALID_COMMAND);
  EXPECT_EQ(r.device_error & 0xFF, 0x01u);
  // tensor descriptor whose C leaves the unit's memory window: RANGE (0x0E)
  gem[0] = 0x40u | (2u << 8) | (1u << 16);
  gem[3] = 0x30000000u;
  ASSERT_OK(sf_debug_submit_raw(D.q, SF_ENGINE_TENSOR, gem, 12, &id));
  r = wait_ok(id, &s);
  EXPECT_STATUS(s, SF_ERR_INVALID_COMMAND);
  EXPECT_EQ(r.device_error & 0xFF, 0x0Eu);
  // the engines recovered: the next commands execute
  gemm_case(4, 4, 4, 0, false, 0, false);
  sf_buffer_release(d);
}

SF_TEST(faults_dma_failure_reported_and_recovered) {
  Dev &D = dev();
  const size_t n = 256;
  sf_buffer_t a = mkbuf(4 * n), b = mkbuf(4 * n), o = mkbuf(4 * n);
  ASSERT_OK(sf_debug_inject(D.d, SF_INJECT_MEM_READ_ERROR, a, 128, 64));   // inside every operand footprint below
  sf_cmd_t id;
  sf_status s;
  ASSERT_OK(sf_vector_add(D.q, a, b, o, n, SF_DTYPE_F32, nullptr, &id));
  sf_cmd_result r = wait_ok(id, &s);
  EXPECT_STATUS(s, SF_ERR_DMA);
  EXPECT_EQ((r.device_status >> 8) & 0xF, 8u);    // tile DMA_ERR
  EXPECT_EQ((r.device_error >> 8) & 0xF, 8u);     // DETAIL = READ_BUS
  ASSERT_OK(sf_buffer_copy(D.q, a, o, 4 * n, &id));
  r = wait_ok(id, &s);
  EXPECT_STATUS(s, SF_ERR_DMA);
  EXPECT_EQ(r.device_error, 8u);                  // system DMA READ_BUS
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = 8; gd.n = 8; gd.k = 64;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, o, &gd, &id));
  r = wait_ok(id, &s);
  EXPECT_STATUS(s, SF_ERR_DMA);
  EXPECT_EQ(r.device_error & 0xFF, 0x18u);        // DMA_READ
  ASSERT_OK(sf_debug_inject(D.d, SF_INJECT_CLEAR, 0, 0, 0));
  ASSERT_OK(sf_vector_add(D.q, a, b, o, n, SF_DTYPE_F32, nullptr, &id));
  wait_ok(id, &s);
  ASSERT_OK(s);
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, o, &gd, &id));
  wait_ok(id, &s);
  ASSERT_OK(s);
  for (auto h : {a, b, o}) sf_buffer_release(h);
}

SF_TEST(faults_host_timeout_never_hangs) {
  Dev &D = dev();
  const uint32_t M = 64, N = 64, K = 512;
  sf_buffer_t a = mkbuf(M * K), b = mkbuf(K * N), c = mkbuf(4 * M * N);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t id;
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, c, &gd, &id));
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  EXPECT_STATUS(sf_queue_wait(D.q, id, 1, &r), SF_ERR_TIMEOUT);   // 1 ms simulated = 100 000 cycles
  uint32_t pend = 0;
  ASSERT_OK(sf_queue_pending(D.q, &pend));
  EXPECT_EQ(pend, 1u);                                             // still pending, not lost
  ASSERT_OK(sf_queue_wait(D.q, id, SF_TIMEOUT_DEFAULT, &r));
  printf("  64x64x512 GEMM: host wait of 1 ms timed out; completed later after %llu tensor cycles\n",
         (unsigned long long)r.engine_cycles);
  for (auto h : {a, b, c}) sf_buffer_release(h);
}

SF_TEST(faults_device_command_timeout_resets_engine) {
  Dev &D = dev();
  setenv("SILICAFLUX_CC_CMD_TIMEOUT_CYCLES", "3000", 1);
  const uint32_t M = 32, N = 32, K = 256;
  sf_buffer_t a = mkbuf(M * K), b = mkbuf(K * N), c = mkbuf(4 * M * N);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t id;
  sf_status s;
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, c, &gd, &id));
  sf_cmd_result r = wait_ok(id, &s);
  EXPECT_STATUS(s, SF_ERR_TIMEOUT);
  EXPECT_EQ(r.device_status & 0xFF, 4u);   // SFRQ_ST_TIMEOUT: firmware gave up and reset the accelerators
  unsetenv("SILICAFLUX_CC_CMD_TIMEOUT_CYCLES");
  gemm_case(8, 8, 16, 0, false, 0, false);  // the reset engine works again
  sf_device_status st{};
  st.struct_size = sizeof st;
  ASSERT_OK(sf_device_get_status(D.d, &st));
  printf("  status after device timeout: %s\n", st.detail);
  for (auto h : {a, b, c}) sf_buffer_release(h);
}

SF_TEST(faults_invalid_handles_and_arguments) {
  Dev &D = dev();
  sf_buffer_t a = mkbuf(64), b = mkbuf(64);
  ASSERT_OK(sf_buffer_release(b));
  sf_cmd_t id;
  EXPECT_STATUS(sf_vector_add(D.q, a, b, a, 16, SF_DTYPE_F32, nullptr, &id), SF_ERR_INVALID_BUFFER);
  EXPECT_STATUS(sf_vector_add(D.q, a, 0xDEADBEEFull, a, 16, SF_DTYPE_F32, nullptr, &id), SF_ERR_INVALID_BUFFER);
  EXPECT_STATUS(sf_vector_add(0x42, a, a, a, 16, SF_DTYPE_F32, nullptr, &id), SF_ERR_INVALID_QUEUE);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = gd.n = gd.k = 4;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_F32;
  EXPECT_STATUS(sf_tensor_gemm(D.q, a, a, a, &gd, &id), SF_ERR_UNSUPPORTED);
  EXPECT_STATUS(sf_debug_inject(D.d, SF_INJECT_HOST_DMA_ERROR, a, 0, 4), SF_ERR_UNSUPPORTED);
  sf_buffer_release(a);
}

// ================================================================== recovery
SF_TEST(recovery_reset_during_execution) {
  Dev &D = dev();
  const uint32_t M = 64, N = 64, K = 512;
  sf_buffer_t a = mkbuf(M * K), b = mkbuf(K * N), c = mkbuf(4 * M * N);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t i1, i2;
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, c, &gd, &i1));
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, c, &gd, &i2));
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  for (int i = 0; i < 40; i++) EXPECT_STATUS(sf_queue_poll(D.q, i1, &r), SF_PENDING);   // the GEMM is running
  ASSERT_OK(sf_device_reset(D.d, SF_RESET_ENGINES));
  EXPECT_STATUS(sf_queue_poll(D.q, i1, &r), SF_ERR_ABORTED);
  EXPECT_STATUS(sf_queue_poll(D.q, i2, &r), SF_ERR_ABORTED);
  uint32_t pend = 9;
  ASSERT_OK(sf_queue_pending(D.q, &pend));
  EXPECT_EQ(pend, 0u);
  // the queue and the buffers stay usable after the reset
  gemm_case(17, 13, 29, 0, false, 0, false);
  for (auto h : {a, b, c}) sf_buffer_release(h);
}

SF_TEST(recovery_ras_warning_and_fatal_events) {
  Dev &D = dev();
  sf_device_status st{};
  st.struct_size = sizeof st;
  ASSERT_OK(sf_device_get_status(D.d, &st));
  uint32_t w0 = st.ras_warnings, f0 = st.ras_fatals;
  ASSERT_OK(sf_debug_inject(D.d, SF_INJECT_RAS_WARNING, 0, 0, 0));
  ASSERT_OK(sf_device_get_status(D.d, &st));
  EXPECT_TRUE(st.ras_warnings > w0);
  EXPECT_TRUE((st.ras_warning_sources >> 5) & 1);   // RAS source EXT_WARN
  ASSERT_OK(sf_debug_inject(D.d, SF_INJECT_RAS_FATAL, 0, 0, 0));
  ASSERT_OK(sf_device_get_status(D.d, &st));
  EXPECT_TRUE(st.ras_fatals > f0);
  EXPECT_TRUE((st.ras_fatal_sources >> 2) & 1);     // RAS source EXT_FATAL (fatal bit 2)
  printf("  RAS after injection: %s\n", st.detail);
  gemm_case(4, 8, 16, 0, false, 0, false);         // the device keeps working after a handled event
}

SF_TEST(recovery_host_interruption) {
  Dev &D = dev();
  const uint32_t M = 64, N = 64, K = 512;
  sf_buffer_t a = mkbuf(M * K), b = mkbuf(K * N), c = mkbuf(4 * M * N);
  sf_gemm_desc gd{};
  gd.struct_size = sizeof gd;
  gd.m = M; gd.n = N; gd.k = K;
  gd.a_type = gd.b_type = SF_DTYPE_I8;
  gd.c_type = SF_DTYPE_I32;
  sf_cmd_t id;
  ASSERT_OK(sf_tensor_gemm(D.q, a, b, c, &gd, &id));
  std::thread t([] {
    std::this_thread::sleep_for(std::chrono::milliseconds(300));
    sf_interrupt();   // what a SIGINT handler does
  });
  sf_status s = sf_queue_wait(D.q, id, SF_TIMEOUT_DEFAULT, nullptr);
  t.join();
  EXPECT_STATUS(s, SF_ERR_INTERRUPTED);
  sf_clear_interrupt();
  sf_cmd_result r = wait_ok(id, &s);
  ASSERT_OK(s);
  EXPECT_EQ(r.macs, (uint64_t)M * N * K);
  for (auto h : {a, b, c}) sf_buffer_release(h);
}

SF_TEST(recovery_full_reset_reboots_firmware) {
  Dev &D = dev();
  ASSERT_OK(sf_device_reset(D.d, SF_RESET_FULL));
  sf_device_status st{};
  st.struct_size = sizeof st;
  ASSERT_OK(sf_device_get_status(D.d, &st));
  EXPECT_EQ(st.state, (uint32_t)SF_STATE_READY);
  EXPECT_TRUE(st.resets >= 1);
  gemm_case(17, 13, 29, 0, false, 0, false);
}

SF_TEST(lost_unresponsive_device_then_full_reset) {
  Dev &D = dev();
  sf_buffer_t a = mkbuf(1024), o = mkbuf(1024);
  ASSERT_OK(sf_debug_inject(D.d, SF_INJECT_DEVICE_HANG, 0, 0, 0));
  sf_cmd_t id;
  ASSERT_OK(sf_vector_add(D.q, a, a, o, 256, SF_DTYPE_F32, nullptr, &id));
  sf_cmd_result r{};
  r.struct_size = sizeof r;
  EXPECT_STATUS(sf_queue_wait(D.q, id, 5, &r), SF_ERR_TIMEOUT);          // the completion never comes
  sf_device_status st{};
  st.struct_size = sizeof st;
  sf_status s = sf_device_get_status(D.d, &st);                         // the firmware cannot answer
  printf("  status while hung -> %s: %s\n", sf_status_string(s), sf_last_error_detail());
  EXPECT_TRUE(s == SF_ERR_DEVICE_LOST);
  EXPECT_STATUS(sf_queue_wait(D.q, id, SF_TIMEOUT_DEFAULT, &r), SF_ERR_DEVICE_LOST);
  EXPECT_STATUS(sf_vector_add(D.q, a, a, o, 256, SF_DTYPE_F32, nullptr, &id), SF_ERR_DEVICE_LOST);
  ASSERT_OK(sf_debug_inject(D.d, SF_INJECT_CLEAR, 0, 0, 0));
  ASSERT_OK(sf_device_reset(D.d, SF_RESET_FULL));                       // cold boot recovers
  ASSERT_OK(sf_device_get_status(D.d, &st));
  EXPECT_EQ(st.state, (uint32_t)SF_STATE_READY);
  gemm_case(9, 11, 40, 0, false, 0, false);
  sf_buffer_release(a);
  sf_buffer_release(o);
}

// ================================================================== compat
static sf_status open_with_firmware(const std::string &path) {
  setenv("SILICAFLUX_CC_FIRMWARE", path.c_str(), 1);
  sf_device_t d = 0;
  sf_status s = sf_device_open_by_name("rtl-cc", 0, &d);
  printf("  firmware %s -> %s: %s\n", path.substr(path.find_last_of('/') + 1).c_str(), sf_status_string(s),
         s ? sf_last_error_detail() : "ok");
  if (s == SF_OK) sf_device_close(d);
  unsetenv("SILICAFLUX_CC_FIRMWARE");
  return s;
}

SF_TEST(compat_stock_p21_firmware_refused) {
  EXPECT_STATUS(open_with_firmware(SF_FW_DIR "/controlcore_p21_stock.hex"), SF_ERR_INCOMPATIBLE_VERSION);
}
SF_TEST(compat_future_abi_major_refused) {
  EXPECT_STATUS(open_with_firmware(SF_FW_DIR "/controlcore_rt_abi2.hex"), SF_ERR_INCOMPATIBLE_VERSION);
}
SF_TEST(compat_corrupted_image_rejected_by_boot_rom) {
  std::ifstream in(SF_FW_DIR "/controlcore_rt.hex");
  std::vector<std::string> lines;
  std::string l;
  while (std::getline(in, l)) lines.push_back(l);
  char buf[16];
  snprintf(buf, sizeof buf, "%08x", (unsigned)strtoul(lines[200].c_str(), nullptr, 16) ^ 0x00010000u);
  lines[200] = buf;
  std::string p = "corrupted_fw.hex";
  std::ofstream out(p);
  for (auto &x : lines) out << x << "\n";
  out.close();
  EXPECT_STATUS(open_with_firmware(p), SF_ERR_INCOMPATIBLE_VERSION);
  remove(p.c_str());
}
SF_TEST(compat_missing_image) {
  EXPECT_STATUS(open_with_firmware("/nonexistent/fw.hex"), SF_ERR_NO_DEVICE);
}

// ================================================================== selftest
SF_TEST(selftest_p21_firmware_suite_on_rtl) {
  Dev &D = dev();
  sf_selftest_result r{};
  r.struct_size = sizeof r;
  ASSERT_OK(sf_device_selftest(D.d, 0, &r));
  printf("  P21 firmware self-test under runtime firmware: %u checks, %u failures, %llu device cycles\n", r.checks,
         r.failures, (unsigned long long)r.device_cycles);
  EXPECT_TRUE(r.checks >= 200);
  EXPECT_EQ(r.failures, 0u);
  // the runtime queue still works after the suite reset and re-discovered the accelerators
  gemm_case(9, 11, 40, 0, true, 0, true);
  sf_selftest_result bad{};
  bad.struct_size = sizeof bad;
  EXPECT_STATUS(sf_device_selftest(D.d, 0x80000000u, &bad), SF_ERR_INVALID_ARGUMENT);
}

int main(int argc, char **argv) {
  int rc = sftest::run_all(argc, argv);
  if (g_dev.d) sf_device_close(g_dev.d);
  return rc;
}
