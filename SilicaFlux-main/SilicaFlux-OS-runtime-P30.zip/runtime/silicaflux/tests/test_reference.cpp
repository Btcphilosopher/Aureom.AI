// SilicaFlux.OS -- unit tests of the independent reference arithmetic.
//
// Oracle 1: the host x86 SSE/FMA3 unit under fesetround/fetestexcept (RNE, RTZ,
//           RDN, RUP).  x86 detects tininess after rounding, like RISC-V, so the
//           flags must match too; NaN results are compared as "both NaN" only
//           (x86 returns a different default NaN than RISC-V's canonical one).
// Oracle 2: RMM (no host mode) -- exact results formed in binary64/binary128 and
//           rounded to binary32 by a separate, straightforward routine.
// Plus: the documented requantisation contract and dot-product order examples.
#include <cfenv>
#include <cmath>
#include <cstring>
#include <random>

#if defined(__x86_64__)
#include <immintrin.h>
#endif

#include "../src/ref/sf_reference.h"
#include "../src/ref/sf_softfloat.h"
#include "sf_test.h"


using namespace sf::ref;

static uint32_t bits(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }
static float flt(uint32_t u) { float f; memcpy(&f, &u, 4); return f; }

static const int kHostModes[4] = {FE_TONEAREST, FE_TOWARDZERO, FE_DOWNWARD, FE_UPWARD};

static uint32_t host_flags() {
  uint32_t f = 0;
  if (fetestexcept(FE_INVALID)) f |= kNV;
  if (fetestexcept(FE_DIVBYZERO)) f |= kDZ;
  if (fetestexcept(FE_OVERFLOW)) f |= kOF;
  if (fetestexcept(FE_UNDERFLOW)) f |= kUF;
  if (fetestexcept(FE_INEXACT)) f |= kNX;
  return f;
}

__attribute__((target("fma"))) static float host_fma(float a, float b, float c) {
  return _mm_cvtss_f32(_mm_fmadd_ss(_mm_set_ss(a), _mm_set_ss(b), _mm_set_ss(c)));
}

// random operands biased toward special values, subnormals and close exponents
static uint32_t rnd_operand(std::mt19937_64 &g) {
  static const uint32_t specials[] = {0x00000000u, 0x80000000u, 0x7F800000u, 0xFF800000u, 0x7FC00000u,
                                      0x7F800001u, 0xFFA00000u, 0x00000001u, 0x807FFFFFu, 0x00800000u,
                                      0x7F7FFFFFu, 0xFF7FFFFFu, 0x3F800000u, 0xBF800000u, 0x33800000u};
  uint32_t r = (uint32_t)g();
  switch (g() % 8) {
    case 0: return specials[g() % (sizeof specials / sizeof specials[0])];
    case 1: return (r & 0x807FFFFFu);                                   // subnormal
    case 2: return (r & 0x80FFFFFFu) | (0x3Fu << 24);                   // near 1
    case 3: return (r & 0x807FFFFFu) | ((uint32_t)(1 + g() % 4) << 23); // tiny normals
    case 4: return (r & 0x807FFFFFu) | ((uint32_t)(250 + g() % 4) << 23);  // huge
    default: return r;
  }
}

static bool same(uint32_t a, uint32_t b) { return a == b || (f32_is_nan(a) && f32_is_nan(b)); }

SF_TEST(softfloat_vs_host_fpu_add_mul_fma) {
#if !defined(__x86_64__)
  printf("  (skipped: needs an x86-64 host FPU oracle)\n");
  return;
#else
  if (!__builtin_cpu_supports("fma")) { printf("  (fma oracle skipped: no FMA3)\n"); }
  std::mt19937_64 g(12345);
  int mismatches = 0, nan_canon_bad = 0;
  const int N = 400000;
  for (int i = 0; i < N; i++) {
    uint32_t a = rnd_operand(g), b = rnd_operand(g), c = rnd_operand(g);
    unsigned m = (unsigned)(g() % 4);
    for (int op = 0; op < 3; op++) {
      if (op == 2 && !__builtin_cpu_supports("fma")) continue;
      volatile float fa = flt(a), fb = flt(b), fc = flt(c);
      fesetround(kHostModes[m]);
      feclearexcept(FE_ALL_EXCEPT);
      float hr = op == 0 ? fa + fb : (op == 1 ? fa * fb : host_fma(fa, fb, fc));
      uint32_t hf = host_flags();
      fesetround(FE_TONEAREST);
      uint32_t sf = 0;
      uint32_t sr = op == 0 ? f32_add(a, b, m, &sf) : (op == 1 ? f32_mul(a, b, m, &sf) : f32_fma(a, b, c, m, &sf));
      // Known, documented x86 vs RISC-V divergences (not reference errors):
      //  * NaN encoding (x86 default NaN 0xFFC00000 / payload propagation) -> compared as "both NaN";
      //  * fma(inf, 0, qNaN): RISC-V (and SoftFloat-RISCV, the hardware FMA's oracle) raises NV,
      //    x86 FMA3 does not.  The RISC-V behaviour is checked in softfloat_directed_cases.
      bool inf0 = ((a & 0x7FFFFFFFu) == 0x7F800000u && (b & 0x7FFFFFFFu) == 0) ||
                  ((b & 0x7FFFFFFFu) == 0x7F800000u && (a & 0x7FFFFFFFu) == 0);
      if (op == 2 && inf0 && f32_is_nan(c) && (c & 0x400000u)) hf |= kNV;
      if (!same(sr, bits(hr)) || sf != hf) {
        if (mismatches < 10)
          fprintf(stderr, "  op%d rm%u a=%08x b=%08x c=%08x: ref %08x/%02x host %08x/%02x\n", op, m, a, b, c, sr, sf,
                  bits(hr), hf);
        mismatches++;
      }
      if (f32_is_nan(sr) && sr != kCanonicalNaN) nan_canon_bad++;
    }
  }
  printf("  %d random operations x 4 rounding modes: %d mismatches\n", 3 * N, mismatches);
  EXPECT_EQ(mismatches, 0);
  EXPECT_EQ(nan_canon_bad, 0);
#endif
}

// ---------------------------------------------------------------- RMM oracle
// Round an exact binary128 value to binary32, ties away from zero (independent path).
static uint32_t q_to_f32_rmm(__float128 x, uint32_t *flags) {
  uint32_t sign = x < 0 ? 1u : 0u;
  if (x < 0) x = -x;
  if (x == 0) return sign << 31;
  int e = 0;
  // scale so that 2^23 <= m < 2^24 (or clamp at the subnormal exponent)
  __float128 m = x;
  while (m >= (__float128)16777216.0) { m /= 2; e++; }
  while (m < (__float128)8388608.0) { m *= 2; e--; }
  // value = m * 2^e, m in [2^23, 2^24)
  if (e < -149) {  // subnormal: re-scale to exponent -149
    while (e < -149) { m /= 2; e++; }
  }
  __float128 fl = m;
  long long ip = (long long)fl;           // truncation
  __float128 frac = m - (__float128)ip;
  if (frac != 0) *flags |= kNX;
  if (frac >= (__float128)0.5) ip += 1;   // ties away from zero (magnitude)
  if (ip == 16777216) { ip >>= 1; e++; }
  if (e + 23 > 127) { *flags |= kOF | kNX; return (sign << 31) | 0x7F800000u; }
  if (e == -149 && ip < 8388608) {        // subnormal (or rounded up to min normal)
    return (sign << 31) | (uint32_t)ip;
  }
  uint32_t biased = (uint32_t)(e + 23 + 127);
  return (sign << 31) | (biased << 23) | ((uint32_t)ip & 0x7FFFFFu);
}

SF_TEST(softfloat_rmm_vs_binary128) {
  std::mt19937_64 g(777);
  int mismatches = 0, n = 0;
  for (int i = 0; i < 200000; i++) {
    // finite operands with limited exponent spread so that binary128 holds the exact result
    auto pick = [&]() {
      uint32_t r = (uint32_t)g();
      uint32_t e = (uint32_t)(g() % 2 ? 1 + g() % 60 : 100 + g() % 50);
      return (r & 0x807FFFFFu) | (e << 23);
    };
    uint32_t a = pick(), b = pick(), c = pick();
    int op = (int)(g() % 3);
    __float128 qa = flt(a), qb = flt(b), qc = flt(c);
    __float128 exact = op == 0 ? qa + qb : (op == 1 ? qa * qb : qa * qb + qc);
    if (exact == 0) continue;
    uint32_t of = 0, sfl = 0;
    uint32_t want = q_to_f32_rmm(exact, &of);
    uint32_t got = op == 0 ? f32_add(a, b, kRMM, &sfl) : (op == 1 ? f32_mul(a, b, kRMM, &sfl) : f32_fma(a, b, c, kRMM, &sfl));
    n++;
    if (want != got) {
      if (mismatches < 10) fprintf(stderr, "  RMM op%d %08x %08x %08x: ref %08x oracle %08x\n", op, a, b, c, got, want);
      mismatches++;
    }
  }
  printf("  %d RMM operations: %d mismatches\n", n, mismatches);
  EXPECT_EQ(mismatches, 0);
}

SF_TEST(softfloat_directed_cases) {
  uint32_t f = 0;
  // ties: 1 + 2^-24 is exactly halfway between 1 and 1+2^-23
  EXPECT_EQ(f32_add(0x3F800000u, 0x33800000u, kRNE, &f), 0x3F800000u);
  EXPECT_EQ(f32_add(0x3F800000u, 0x33800000u, kRMM, &f), 0x3F800001u);
  EXPECT_EQ(f32_add(0x3F800000u, 0x33800000u, kRUP, &f), 0x3F800001u);
  EXPECT_EQ(f32_add(0x3F800000u, 0x33800000u, kRTZ, &f), 0x3F800000u);
  // x + (-x) = +0, except RDN -> -0
  EXPECT_EQ(f32_add(0x3F800000u, 0xBF800000u, kRNE, &f), 0x00000000u);
  EXPECT_EQ(f32_add(0x3F800000u, 0xBF800000u, kRDN, &f), 0x80000000u);
  // inf - inf: NV, canonical NaN
  f = 0;
  EXPECT_EQ(f32_add(0x7F800000u, 0xFF800000u, kRNE, &f), kCanonicalNaN);
  EXPECT_EQ(f, kNV);
  // inf * 0 + qNaN raises NV (RISC-V)
  f = 0;
  EXPECT_EQ(f32_fma(0x7F800000u, 0x00000000u, 0x7FC00000u, kRNE, &f), kCanonicalNaN);
  EXPECT_EQ(f, kNV);
  // overflow under directed rounding
  f = 0;
  EXPECT_EQ(f32_mul(0x7F7FFFFFu, 0x40000000u, kRTZ, &f), 0x7F7FFFFFu);
  EXPECT_EQ(f, kOF | kNX);
  // tininess after rounding: largest subnormal * (1 + eps) rounding up to the min normal is not tiny
  f = 0;
  uint32_t r = f32_mul(0x007FFFFFu, 0x3F800001u, kRUP, &f);
  EXPECT_EQ(r, 0x00800000u);
  EXPECT_EQ(f & kUF, 0u);
}

SF_TEST(dot_product_order_definition) {
  // x = {2^24, 1, 1, -2^24}, b = 1
  uint32_t a[5] = {0x4B800000u, 0x3F800000u, 0x3F800000u, 0xCB800000u, 0x40000000u};
  uint32_t b[5] = {0x3F800000u, 0x3F800000u, 0x3F800000u, 0x3F800000u, 0x3F800000u};
  uint32_t fl = 0;
  // N = 1, sequential: 0+2^24 = 2^24; +1 -> 2^24 (tie, even); +1 -> 2^24; -2^24 -> 0; +2 -> 2
  EXPECT_EQ(dot_f32(5, a, b, kRNE, 1, 0, &fl), bits(2.0f));
  // N = 4: beat0 = (2^24+1 -> 2^24) + (1-2^24 = -16777215) = 1; acc = 1; beat1 = 2 -> 3
  fl = 0;
  EXPECT_EQ(dot_f32(5, a, b, kRNE, 4, 0, &fl), bits(3.0f));
  // empty -> init unchanged, no flags
  fl = 0;
  EXPECT_EQ(dot_f32(0, a, b, kRNE, 4, 0x80000000u, &fl), 0x80000000u);
  EXPECT_EQ(fl, 0u);
}

SF_TEST(requant_contract) {
  bool sat = false;
  // R_rne(100 * 2^20 / 2^23) = 12.5 -> 12 (tie to even); + zp 3 = 15
  EXPECT_EQ((int)requant(100, 1 << 20, 23, 3, false, kRNE, &sat), 15);
  EXPECT_EQ((int)requant(100, 1 << 20, 23, 3, false, kRMM, &sat), 16);
  EXPECT_EQ((int)requant(-100, 1 << 20, 23, 0, false, kRMM, &sat), -13);
  EXPECT_EQ((int)requant(-100, 1 << 20, 23, 0, false, kRTZ, &sat), -12);
  EXPECT_EQ((int)requant(-100, 1 << 20, 23, 0, false, kRDN, &sat), -13);
  EXPECT_EQ((int)requant(-100, 1 << 20, 23, 0, false, kRUP, &sat), -12);
  EXPECT_TRUE(!sat);
  // saturation and ReLU floor at zp
  EXPECT_EQ((int)requant(100000, 1 << 20, 20, 0, false, kRNE, &sat), 127);
  EXPECT_TRUE(sat);
  sat = false;
  EXPECT_EQ((int)requant(-50, 1, 0, -3, true, kRNE, &sat), -3);
  EXPECT_TRUE(!sat);
}

SF_TEST(gemm_reference_small) {
  int8_t A[2 * 3] = {1, -2, 3, 4, 5, -6};
  int8_t B[3 * 2] = {7, 8, -9, 10, 11, 12};
  int32_t C[4];
  gemm_i8_i32(2, 2, 3, A, 3, B, 2, C, 8);
  EXPECT_EQ(C[0], 1 * 7 + -2 * -9 + 3 * 11);
  EXPECT_EQ(C[1], 1 * 8 + -2 * 10 + 3 * 12);
  EXPECT_EQ(C[2], 4 * 7 + 5 * -9 + -6 * 11);
  EXPECT_EQ(C[3], 4 * 8 + 5 * 10 + -6 * 12);
  int8_t extreme_a[2] = {-128, -128}, extreme_b[2] = {-128, -128};
  int32_t c1;
  gemm_i8_i32(1, 1, 2, extreme_a, 2, extreme_b, 1, &c1, 4);
  EXPECT_EQ(c1, 2 * 16384);
}

SF_TEST_MAIN()
