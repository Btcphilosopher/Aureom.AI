// SilicaFlux.OS -- physical-device discovery when no SilicaFlux hardware exists.
//
// HostLink PCI IDs are not assigned, so discovery only considers functions named by
// SILICAFLUX_PCI_IDS / SILICAFLUX_PCI_BDF.  This test points discovery at a real
// PCI function of the build machine that is NOT a SilicaFlux device and checks that
// the library reports it truthfully (listed, unavailable, open refused) and never
// pretends a simulator or another device is SilicaFlux hardware.
#include <dirent.h>
#include <unistd.h>

#include <cstdio>
#include <cstring>
#include <string>

#include "sf_test.h"
#include "silicaflux/silicaflux.h"

static std::string first_pci_function() {
  DIR *d = opendir("/sys/bus/pci/devices");
  if (!d) return "";
  std::string r;
  while (dirent *e = readdir(d))
    if (e->d_name[0] != '.') {
      r = e->d_name;
      break;
    }
  closedir(d);
  return r;
}

SF_TEST(no_hardware_is_ever_reported_as_present) {
  std::string bdf = first_pci_function();
  if (!bdf.empty()) setenv("SILICAFLUX_PCI_BDF", bdf.c_str(), 1);   // before the first discovery
  uint32_t n = 0;
  ASSERT_OK(sf_get_device_count(&n));
  int hardware = 0;
  for (uint32_t i = 0; i < n; i++) {
    sf_device_info info{};
    info.struct_size = sizeof info;
    ASSERT_OK(sf_get_device_info(i, &info));
    printf("  [%u] %-22s kind=%u simulator=%u available=%u  %s\n", i, info.name, info.kind, info.is_simulator,
           info.available, info.description);
    if (info.kind == SF_DEVICE_HARDWARE) {
      hardware++;
      sf_device_t dev = 0;
      sf_status s = sf_device_open(i, 0, &dev);
      printf("      open -> %s: %s\n", sf_status_string(s), sf_last_error_detail());
      // the function is not a SilicaFlux HostLink device: it must not open as one
      EXPECT_TRUE(s == SF_ERR_NO_DEVICE || s == SF_ERR_INCOMPATIBLE_VERSION);
    }
    if (info.kind == SF_DEVICE_RTL_SIMULATOR) EXPECT_EQ(info.is_simulator, 1u);
  }
  if (bdf.empty()) printf("  (no PCI functions visible: nothing to probe)\n");
  else EXPECT_EQ(hardware, 1);
  sf_device_t dev = 0;
  EXPECT_STATUS(sf_device_open_by_name("pcie:0000:ff:1f.7", 0, &dev), SF_ERR_NO_DEVICE);
}

SF_TEST_MAIN()
