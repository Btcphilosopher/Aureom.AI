#!/usr/bin/env python3
"""Cut a cycle window out of a (large) DataFabric trace, streaming.

  trace_window.py IN.csv OUT.csv --from C0 --to C1
  trace_window.py IN.csv OUT.csv --last-transfer MASTER --accepts N [--margin M]
      window = the last N consecutive ACCEPTs of MASTER (e.g. the DMA's last
      16 KiB copy = 8192 accepts) +/- M cycles; a response in flight at the
      window start is kept consistent by starting at an ACCEPT boundary.
Full SoC firmware traces are hundreds of MB; the delivered reports keep windows.
"""
import argparse
import csv
import sys
from collections import deque


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("inp")
    ap.add_argument("out")
    ap.add_argument("--from", dest="c0", type=int)
    ap.add_argument("--to", dest="c1", type=int)
    ap.add_argument("--last-transfer", type=int, help="master index")
    ap.add_argument("--accepts", type=int, default=8192)
    ap.add_argument("--margin", type=int, default=64)
    a = ap.parse_args(argv)
    c0, c1 = a.c0, a.c1
    if a.last_transfer is not None:
        last = deque(maxlen=a.accepts)
        lastresp = 0
        with open(a.inp) as f:
            for r in csv.DictReader(f):
                if int(r["master"]) == a.last_transfer:
                    if r["event"] == "ACCEPT":
                        last.append(int(r["cycle"]))
                    elif r["event"] == "RESPONSE":
                        lastresp = int(r["cycle"])
        if len(last) < a.accepts:
            print("trace_window: not enough accepts", file=sys.stderr)
            return 2
        c0, c1 = max(0, last[0] - a.margin), lastresp + a.margin
    n = 0
    with open(a.inp) as f, open(a.out, "w", newline="") as g:
        rd = csv.DictReader(f)
        w = csv.DictWriter(g, fieldnames=rd.fieldnames)
        w.writeheader()
        open_ids = {}
        for r in rd:
            c = int(r["cycle"])
            if c < c0:
                continue
            if c > c1:
                break
            m = r["master"]
            # drop responses whose ACCEPT lies before the window (keeps the window self-consistent)
            if r["event"] == "ACCEPT":
                open_ids[m] = r["id"]
            elif r["event"] == "RESPONSE" and open_ids.get(m) != r["id"]:
                continue
            w.writerow(r)
            n += 1
    print(f"trace_window: cycles {c0}..{c1}, {n} events -> {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
