#!/usr/bin/env python3
"""Bandwidth / latency / contention analysis of MEASURED DataFabric traces.

Per master: transactions, bytes (read/write), bytes per cycle over the trace
span, arbitration delay (ISSUE -> ACCEPT), response latency (ACCEPT ->
RESPONSE), conflict cycles, error responses.  Per slave: accepted
transactions and utilisation (accepts / span; a single-cycle SRAM can accept
one per cycle).  Optional window: --from/--to cycles (e.g. one DMA transfer).

  bandwidth_analysis.py TRACE.csv [--names DBG,CPUD,CPUI,DMA] [--json OUT]
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from collections import defaultdict

import trace_export as te


def analyse(rows: list[dict], names=None, t0=None, t1=None) -> dict:
    rows = [r for r in rows if (t0 is None or r["cycle"] >= t0) and (t1 is None or r["cycle"] <= t1)]
    if not rows:
        return {"span_cycles": 0, "masters": {}, "slaves": {}}
    span = rows[-1]["cycle"] - rows[0]["cycle"] + 1
    m = defaultdict(lambda: {"accepts": 0, "reads": 0, "writes": 0, "bytes_read": 0, "bytes_written": 0,
                             "arb_delay": [], "latency": [], "conflict_cycles": 0, "errors": 0})
    s = defaultdict(lambda: {"accepts": 0})
    for r in rows:
        x = m[r["master"]]
        if r["event"] == "ACCEPT":
            x["accepts"] += 1
            x["arb_delay"].append(r["stall_cycles"])
            if r["op"] == "W":
                x["writes"] += 1
                x["bytes_written"] += r["size"]
            else:
                x["reads"] += 1
                x["bytes_read"] += r["size"]
            s[r["slave"]]["accepts"] += 1
        elif r["event"] == "RESPONSE":
            x["latency"].append(r["stall_cycles"])
            x["errors"] += r["error"]
        elif r["event"] == "CONFLICT":
            x["conflict_cycles"] += 1
    out = {"span_cycles": span, "masters": {}, "slaves": {}}
    for k, x in sorted(m.items()):
        name = names[k] if names and k < len(names) else str(k)
        ad, lt = x.pop("arb_delay"), x.pop("latency")
        x["bytes_per_cycle"] = round((x["bytes_read"] + x["bytes_written"]) / span, 4)
        x["avg_arb_delay"] = round(statistics.mean(ad), 3) if ad else None
        x["max_arb_delay"] = max(ad) if ad else None
        x["avg_latency"] = round(statistics.mean(lt), 3) if lt else None
        x["max_latency"] = max(lt) if lt else None
        out["masters"][name] = x
    for k, x in sorted(s.items()):
        x["utilisation"] = round(x["accepts"] / span, 4)
        out["slaves"][str(k)] = x
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("trace")
    ap.add_argument("--names")
    ap.add_argument("--from", dest="t0", type=int)
    ap.add_argument("--to", dest="t1", type=int)
    ap.add_argument("--max-outstanding", type=int, default=1)
    ap.add_argument("--json")
    a = ap.parse_args(argv)
    rows = te.load(a.trace, a.max_outstanding)
    res = analyse(rows, a.names.split(",") if a.names else None, a.t0, a.t1)
    if a.json:
        json.dump(res, open(a.json, "w"), indent=1)
    print(json.dumps(res, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
