"""pytest: memory-map generator validation and generation."""
import copy
import os
import sys

import pytest
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "python", "datafabric"))
import memmap_gen as mg  # noqa: E402

MAP = os.path.join(ROOT, "memmap", "silicaflux_v_datafabric.yaml")


@pytest.fixture
def base():
    return yaml.safe_load(open(MAP))


def bad(m, msg):
    with pytest.raises(mg.MemoryMapError, match=msg):
        mg.validate(m)


def test_reference_map_is_valid(base):
    m = mg.validate(base)
    assert [r["name"] for r in m["regions"]][0] == "BOOT_ROM"
    page = {p["name"]: p["base"] for p in m["pages"]}
    assert page["DMA"] == 0x40006000 and page["DFPERF"] == 0x40007000 and page["TE"] == 0x40011000


def test_overlap_rejected(base):
    base["regions"][2]["base"] = 0x10000000          # SRAM_BANK1 onto BANK0
    bad(base, "overlap")


def test_invalid_size_rejected(base):
    base["regions"][1]["size"] = 0
    bad(base, "invalid size")


def test_non_power_of_two_rejected(base):
    base["regions"][1]["size"] = 0x6000
    bad(base, "power of two")


def test_unaligned_base_rejected(base):
    base["regions"][5]["base"] = 0x20002000             # TSPM (16 KiB) at a 8 KiB boundary
    bad(base, "not aligned")


def test_address_overflow_rejected(base):
    base["regions"].append({"name": "TOP", "base": 0xFFFF0000, "size": 0x20000, "access": "rw", "slave": "TOP"})
    bad(base, "overflow")


def test_duplicate_name_rejected(base):
    base["regions"].append(copy.deepcopy(base["regions"][1]))
    base["regions"][-1]["base"] = 0x50000000
    bad(base, "duplicate")


def test_page_name_collides_with_region(base):
    base["pages"].append({"name": "TSPM", "index": 9, "parent": "PERIPH"})
    bad(base, "duplicate address name")


def test_unsupported_access_rejected(base):
    base["regions"][0]["access"] = "wx"
    bad(base, "unsupported access")


def test_page_outside_parent_rejected(base):
    base["pages"].append({"name": "FAR", "index": 40, "parent": "PERIPH"})
    bad(base, "outside parent")


def test_duplicate_page_index_rejected(base):
    base["pages"].append({"name": "DUP", "index": 6, "parent": "PERIPH"})
    bad(base, "used twice")


def test_register_overlap_rejected(base):
    base["register_blocks"]["dma"]["registers"][3]["offset"] = 0x08
    bad(base, "overlap")


def test_register_unaligned_rejected(base):
    base["register_blocks"]["dma"]["registers"][3]["offset"] = 0x0A
    bad(base, "unaligned")


def test_field_overlap_rejected(base):
    base["register_blocks"]["dma"]["registers"][1]["fields"][1]["bits"] = "0"
    bad(base, "overlaps another field")


def test_field_too_wide_rejected(base):
    base["register_blocks"]["dma"]["registers"][1]["fields"][4]["bits"] = "33:8"
    bad(base, "exceeds 32-bit")


def test_unknown_register_access_rejected(base):
    base["register_blocks"]["dma"]["registers"][2]["access"] = "rwx"
    bad(base, "unsupported access")


def test_deny_unknown_region_rejected(base):
    base["masters"][2]["deny"] = ["NOWHERE"]
    bad(base, "unknown region")


def test_generated_sv_matches_map(base):
    m = mg.validate(base)
    pkg = mg.gen_sv_pkg(m, "x.yaml")
    assert "localparam int NUM_SLAVES  = 7;" in pkg
    assert "localparam int M_DMA   = 3;" in pkg
    # DMA (m=3) and CPUI (m=2) denied PERIPH (s=6)
    en = int(pkg.split("MST_SLV_EN = 28'h")[1].split(";")[0], 16)
    assert not (en >> (3 * 7 + 6)) & 1 and not (en >> (2 * 7 + 6)) & 1 and (en >> (1 * 7 + 6)) & 1


def test_crosscheck_detects_conflict(base, tmp_path):
    pkg = tmp_path / "sfv_pkg.sv"
    pkg.write_text("localparam logic [31:0] ROM_BASE = 32'h0000_0000;\nlocalparam logic [31:0] SRAM_BASE = 32'h1000_0000;\n"
                   "localparam logic [31:0] TSPM_BASE = 32'h2000_0000;\nlocalparam logic [31:0] PERIPH_BASE = 32'h4000_0000;\n"
                   "localparam logic [31:0] PERIPH_MASK = 32'hFFFE_0000;\nlocalparam logic [31:0] ROM_MASK = 32'hFFFF_F000;\n"
                   "localparam logic [31:0] TSPM_MASK = 32'hFFFF_C000;\nlocalparam int PG_DMA = 6;\n")
    m = mg.validate(base)
    with pytest.raises(mg.MemoryMapError, match="reuses page index"):
        mg.crosscheck_sfv_pkg(m, str(pkg))


def test_committed_outputs_up_to_date():
    assert mg.main([MAP, "--root", ROOT, "--check"]) == 0
