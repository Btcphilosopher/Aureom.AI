#!/usr/bin/env python3
"""SilicaFlux DataFabric memory-map generator.

Single source of truth: memmap/silicaflux_v_datafabric.yaml.  Validates the
map and generates SystemVerilog, C, Python and Markdown views:

  generated/sfb_memmap_pkg.sv          package: slave/master indices, BASE/MASK
                                       vectors for sfb_crossbar, access matrix,
                                       page indices, IRQ numbers
  rtl/dma/dma_defs.svh                 DMA register map (`define header)
  rtl/interconnect/sfb_perf_defs.svh   perf-counter register map
  generated/sfv_df_map.h               C header for firmware
  generated/datafabric_map.py          Python definitions
  docs/datafabric/MEMORY_MAP.md        human-readable map

Rejected (MemoryMapError): overlapping regions or pages, invalid ranges
(size <= 0, non-power-of-two size, base not aligned to size -- required by the
mask decoder), address overflow beyond address_width, duplicate names or
indices, unsupported access permissions, pages outside their parent window,
registers that overlap / are unaligned / exceed the page, fields that overlap
or exceed 32 bits, unknown register/field access types, deny lists naming
unknown regions.

  memmap_gen.py MAP.yaml --root DIR            write all outputs under DIR
  memmap_gen.py MAP.yaml --root DIR --check    exit 1 if any output is stale
  memmap_gen.py MAP.yaml --sfv-pkg sfv_pkg.sv  cross-check against SilicaFlux-V
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from typing import Any

import yaml

REG_ACCESS = {"ro", "rw", "wo", "w1c", "w1s"}


class MemoryMapError(ValueError):
    pass


def _int(v: Any, what: str) -> int:
    if isinstance(v, bool) or not isinstance(v, int):
        raise MemoryMapError(f"{what}: expected an integer, got {v!r}")
    return v


def _bits(spec: str, what: str) -> tuple[int, int]:
    m = re.fullmatch(r"\s*(\d+)\s*(?::\s*(\d+)\s*)?", str(spec))
    if not m:
        raise MemoryMapError(f"{what}: bad bit range {spec!r}")
    hi = int(m.group(1))
    lo = int(m.group(2)) if m.group(2) is not None else hi
    if lo > hi:
        raise MemoryMapError(f"{what}: bit range {spec!r} has msb < lsb")
    if hi > 31:
        raise MemoryMapError(f"{what}: bit range {spec!r} exceeds 32-bit register")
    return hi, lo


def load(path: str) -> dict:
    with open(path) as f:
        return validate(yaml.safe_load(f))


def validate(m: dict) -> dict:
    if not isinstance(m, dict):
        raise MemoryMapError("map must be a mapping")
    meta = m.get("meta", {})
    aw = _int(meta.get("address_width", 32), "meta.address_width")
    if aw <= 0 or aw > 64:
        raise MemoryMapError(f"meta.address_width {aw} out of range")
    top = 1 << aw
    page = _int(meta.get("page_size", 0x1000), "meta.page_size")
    acc_types = set(m.get("access_types", ["r", "rw", "rx", "rwx"]))
    # namespaces: regions and pages share the address namespace (both become
    # <NAME>_BASE constants); masters and interrupts have their own prefixes
    spaces: dict[str, set[str]] = {}

    def uniq(n: str, what: str, space: str = "address") -> None:
        if not isinstance(n, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", n):
            raise MemoryMapError(f"{what}: invalid name {n!r}")
        ns_ = spaces.setdefault(space, set())
        if n.upper() in ns_:
            raise MemoryMapError(f"duplicate {space} name {n!r}")
        ns_.add(n.upper())

    regions = m.get("regions") or []
    if not regions:
        raise MemoryMapError("no regions defined")
    slaves = set()
    for r in regions:
        uniq(r.get("name"), "region")
        b = _int(r.get("base"), f"region {r['name']}.base")
        s = _int(r.get("size"), f"region {r['name']}.size")
        if s <= 0:
            raise MemoryMapError(f"region {r['name']}: invalid size {s}")
        if b < 0 or b + s > top:
            raise MemoryMapError(f"region {r['name']}: address overflow (0x{b:x} + 0x{s:x} > 2^{aw})")
        if s & (s - 1):
            raise MemoryMapError(f"region {r['name']}: size 0x{s:x} is not a power of two (mask decode)")
        if b % s:
            raise MemoryMapError(f"region {r['name']}: base 0x{b:x} not aligned to its size 0x{s:x}")
        if r.get("access") not in acc_types:
            raise MemoryMapError(f"region {r['name']}: unsupported access {r.get('access')!r} "
                                 f"(allowed {sorted(acc_types)})")
        sl = r.get("slave", r["name"])
        if sl in slaves:
            raise MemoryMapError(f"region {r['name']}: slave port {sl!r} used twice")
        slaves.add(sl)
    srt = sorted(regions, key=lambda r: r["base"])
    for a, c in zip(srt, srt[1:]):
        if a["base"] + a["size"] > c["base"]:
            raise MemoryMapError(f"regions {a['name']} and {c['name']} overlap")

    byname = {r["name"]: r for r in regions}
    used_idx: dict[str, set] = {}
    for p in m.get("pages") or []:
        uniq(p.get("name"), "page")
        par = byname.get(p.get("parent"))
        if par is None:
            raise MemoryMapError(f"page {p['name']}: unknown parent {p.get('parent')!r}")
        i = _int(p.get("index"), f"page {p['name']}.index")
        if i < 0 or (i + 1) * page > par["size"]:
            raise MemoryMapError(f"page {p['name']}: index {i} outside parent window {par['name']}")
        if i in used_idx.setdefault(par["name"], set()):
            raise MemoryMapError(f"page {p['name']}: index {i} used twice in {par['name']}")
        used_idx[par["name"]].add(i)
        p["base"] = par["base"] + i * page
        p["size"] = page
        if p.get("block") and p["block"] not in (m.get("register_blocks") or {}):
            raise MemoryMapError(f"page {p['name']}: unknown register block {p['block']!r}")

    midx = set()
    for ms in m.get("masters") or []:
        uniq(ms.get("name"), "master", "master")
        i = _int(ms.get("index"), f"master {ms['name']}.index")
        if i in midx:
            raise MemoryMapError(f"master {ms['name']}: index {i} used twice")
        midx.add(i)
        for d in ms.get("deny", []) or []:
            if d not in byname:
                raise MemoryMapError(f"master {ms['name']}: deny names unknown region {d!r}")
    if midx and sorted(midx) != list(range(len(midx))):
        raise MemoryMapError("master indices must be 0..N-1")

    iidx = set()
    for q in m.get("interrupts") or []:
        uniq(q.get("name", "?"), "interrupt", "interrupt")
        i = _int(q.get("index"), f"interrupt {q['name']}.index")
        if i in iidx or i < 0 or i > 31:
            raise MemoryMapError(f"interrupt {q['name']}: bad or duplicate index {i}")
        iidx.add(i)

    for bn, blk in (m.get("register_blocks") or {}).items():
        regs = list(blk.get("registers") or [])
        pm = blk.get("per_master")
        offs: dict[int, str] = {}
        rnames = set()
        for r in regs:
            n = r.get("name")
            if n in rnames:
                raise MemoryMapError(f"block {bn}: duplicate register {n!r}")
            rnames.add(n)
            o = _int(r.get("offset"), f"{bn}.{n}.offset")
            if o % 4 or o < 0 or o + 4 > page:
                raise MemoryMapError(f"block {bn}: register {n} offset 0x{o:x} unaligned or outside the page")
            if o in offs:
                raise MemoryMapError(f"block {bn}: registers {offs[o]} and {n} overlap at 0x{o:x}")
            offs[o] = n
            if r.get("access") not in REG_ACCESS:
                raise MemoryMapError(f"block {bn}: register {n} has unsupported access {r.get('access')!r}")
            used = 0
            fnames = set()
            for fd in r.get("fields") or []:
                hi, lo = _bits(fd.get("bits"), f"{bn}.{n}.{fd.get('name')}")
                if fd.get("name") in fnames:
                    raise MemoryMapError(f"block {bn}: register {n} duplicate field {fd.get('name')!r}")
                fnames.add(fd.get("name"))
                mask = ((1 << (hi - lo + 1)) - 1) << lo
                if used & mask:
                    raise MemoryMapError(f"block {bn}: register {n} field {fd['name']} overlaps another field")
                used |= mask
                if fd.get("access") not in REG_ACCESS:
                    raise MemoryMapError(f"block {bn}: field {n}.{fd['name']} unsupported access {fd.get('access')!r}")
                fd["msb"], fd["lsb"] = hi, lo
        if pm:
            nm = len(m.get("masters") or [])
            base, stride = _int(pm["base"], f"{bn}.per_master.base"), _int(pm["stride"], f"{bn}.per_master.stride")
            for r in pm["registers"]:
                if _int(r["offset"], "per_master offset") >= stride:
                    raise MemoryMapError(f"block {bn}: per-master register {r['name']} exceeds the stride")
            for k in range(nm):
                for r in pm["registers"]:
                    o = base + k * stride + r["offset"]
                    if o in offs:
                        raise MemoryMapError(f"block {bn}: per-master register {r['name']}[{k}] overlaps {offs[o]}")
                    if o + 4 > page:
                        raise MemoryMapError(f"block {bn}: per-master registers exceed the page")
                    offs[o] = f"{r['name']}[{k}]"
    return m


# =========================================================================== generators
HDR_SV = "// GENERATED by python/datafabric/memmap_gen.py from {src} -- do not edit.\n"
HDR_C = "/* GENERATED by python/datafabric/memmap_gen.py from {src} -- do not edit. */\n"


def _w(v: int) -> str:
    return f"32'h{v >> 16:04X}_{v & 0xFFFF:04X}"


def gen_sv_pkg(m: dict, src: str) -> str:
    regs = m["regions"]
    ms = sorted(m.get("masters") or [], key=lambda x: x["index"])
    ns, nm = len(regs), len(ms)
    L = [HDR_SV.format(src=src), "`default_nettype none\n\n/* verilator lint_off UNUSEDPARAM */  // a map package: not every constant is used by every design\npackage sfb_memmap_pkg;\n"]
    L.append(f"  localparam int NUM_SLAVES  = {ns};\n  localparam int NUM_MASTERS = {nm};\n")
    for i, r in enumerate(regs):
        n = r["name"]
        L.append(f"  localparam int          S_{r.get('slave', n):10s} = {i};")
        L.append(f"  localparam logic [31:0] {n}_BASE = {_w(r['base'])};")
        L.append(f"  localparam logic [31:0] {n}_SIZE = {_w(r['size'])};")
        L.append(f"  localparam logic [31:0] {n}_MASK = {_w((~(r['size'] - 1)) & 0xFFFFFFFF)};")
    L.append("")
    for x in ms:
        L.append(f"  localparam int M_{x['name']:5s} = {x['index']};")
    base = " ".join(f"{_w(r['base'])}," for r in reversed(regs)).rstrip(",")
    mask = " ".join(f"{_w((~(r['size'] - 1)) & 0xFFFFFFFF)}," for r in reversed(regs)).rstrip(",")
    L.append(f"\n  // sfb_crossbar parameters (slave s at bits [s*32 +: 32])")
    L.append(f"  localparam logic [NUM_SLAVES*32-1:0] SLV_BASE = {{{base}}};")
    L.append(f"  localparam logic [NUM_SLAVES*32-1:0] SLV_MASK = {{{mask}}};")
    en = 0
    for x in ms:
        for s, r in enumerate(regs):
            if r["name"] not in (x.get("deny") or []):
                en |= 1 << (x["index"] * ns + s)
    L.append(f"  // access matrix: bit m*NUM_SLAVES+s")
    L.append(f"  localparam logic [NUM_MASTERS*NUM_SLAVES-1:0] MST_SLV_EN = {nm * ns}'h{en:X};\n")
    pe = 0
    for p in m.get("pages") or []:
        L.append(f"  localparam int PG_{p['name']:8s} = {p['index']};   // {p['base']:#010x}")
        pe |= 1 << p["index"]
    L.append(f"  localparam logic [31:0] PAGE_EN = 32'h{pe:08X};\n")
    for q in m.get("interrupts") or []:
        L.append(f"  localparam int IRQ_{q['name']:7s} = {q['index']};")
    L.append(f"  localparam int NUM_IRQ = {max((q['index'] for q in m.get('interrupts') or []), default=-1) + 1};")
    L.append("endpackage\n/* verilator lint_on UNUSEDPARAM */\n\n`default_nettype wire\n")
    return "\n".join(L)


def gen_svh(m: dict, block: str, src: str) -> str:
    blk = m["register_blocks"][block]
    P = blk["prefix"]
    g = f"{P}_DEFS_SVH"
    L = [HDR_SV.format(src=src) + f"// Register block '{block}'.  A `define header (not a package): Yosys 0.33\n"
         "// cannot resolve package references in module parameter lists.\n", f"`ifndef {g}", f"`define {g}\n"]
    for r in blk["registers"]:
        L.append(f"`define {P}_REG_{r['name']:14s} 12'h{r['offset']:03X}")
    for r in blk["registers"]:
        for fd in r.get("fields") or []:
            if fd["msb"] == fd["lsb"]:
                L.append(f"`define {P}_{r['name']}_{fd['name']:10s} {fd['lsb']}")
            else:
                L.append(f"`define {P}_{r['name']}_{fd['name']}_LSB {fd['lsb']}")
                L.append(f"`define {P}_{r['name']}_{fd['name']}_MSB {fd['msb']}")
    if "id_value" in blk:
        v = blk["id_value"]
        L.append(f"`define {P}_ID_VALUE {_w(v)}")
    pm = blk.get("per_master")
    if pm:
        L.append(f"`define {P}_PM_BASE   12'h{pm['base']:03X}")
        L.append(f"`define {P}_PM_STRIDE 12'h{pm['stride']:03X}")
        for r in pm["registers"]:
            L.append(f"`define {P}_PM_{r['name']:10s} 5'h{r['offset']:02X}")
    for en, vals in (blk.get("enums") or {}).items():
        w = max(1, max(v["value"] for v in vals).bit_length())
        tag = {"error": "ERR", "state": "ST"}.get(en, en.upper())
        for v in vals:
            L.append(f"`define {P}_{tag}_{v['name']:14s} {w}'d{v['value']}")
    L.append("\n`endif\n")
    return "\n".join(L)


def gen_c(m: dict, src: str) -> str:
    L = [HDR_C.format(src=src), "#ifndef SFV_DF_MAP_H", "#define SFV_DF_MAP_H", "#include <stdint.h>\n",
         "/* ---- regions (base, size) ---- */"]
    for r in m["regions"]:
        L.append(f"#define SFV_DF_{r['name']}_BASE 0x{r['base']:08X}u")
        L.append(f"#define SFV_DF_{r['name']}_SIZE 0x{r['size']:08X}u")
    L.append("\n/* ---- peripheral pages ---- */")
    for p in m.get("pages") or []:
        L.append(f"#define SFV_DF_{p['name']}_BASE 0x{p['base']:08X}u")
    L.append("\n/* ---- bus masters ---- */")
    for x in m.get("masters") or []:
        L.append(f"#define SFV_DF_MASTER_{x['name']} {x['index']}u")
    L.append("\n/* ---- interrupt sources (INTC) ---- */")
    for q in m.get("interrupts") or []:
        L.append(f"#define SFV_DF_IRQ_{q['name']} {q['index']}u")
    for bn, blk in (m.get("register_blocks") or {}).items():
        P = blk["prefix"]
        L.append(f"\n/* ---- register block '{bn}' (offsets from its page base) ---- */")
        for r in blk["registers"]:
            L.append(f"#define {P}_{r['name']}_OFF 0x{r['offset']:03X}u   /* {r['access']} */")
            for fd in r.get("fields") or []:
                n = fd["msb"] - fd["lsb"] + 1
                L.append(f"#define {P}_{r['name']}_{fd['name']}_SHIFT {fd['lsb']}u")
                L.append(f"#define {P}_{r['name']}_{fd['name']}_MASK  (0x{(1 << n) - 1:X}u << {fd['lsb']}u)")
        if "id_value" in blk:
            L.append(f"#define {P}_ID_VALUE 0x{blk['id_value']:08X}u")
        pm = blk.get("per_master")
        if pm:
            for r in pm["registers"]:
                L.append(f"#define {P}_{r['name']}_OFF(m) (0x{pm['base']:03X}u + 0x{pm['stride']:X}u * (m) + 0x{r['offset']:02X}u)")
        for en, vals in (blk.get("enums") or {}).items():
            tag = {"error": "ERR", "state": "ST"}.get(en, en.upper())
            for v in vals:
                L.append(f"#define {P}_{tag}_{v['name']} {v['value']}u")
    L.append("\n#endif /* SFV_DF_MAP_H */\n")
    return "\n".join(L)


def gen_py(m: dict, src: str) -> str:
    out = {
        "REGIONS": {r["name"]: (r["base"], r["size"], r["access"], r.get("slave", r["name"])) for r in m["regions"]},
        "PAGES": {p["name"]: p["base"] for p in m.get("pages") or []},
        "MASTERS": {x["name"]: x["index"] for x in m.get("masters") or []},
        "MASTER_DENY": {x["name"]: list(x.get("deny") or []) for x in m.get("masters") or []},
        "IRQ": {q["name"]: q["index"] for q in m.get("interrupts") or []},
        "REGS": {bn: {r["name"]: r["offset"] for r in blk["registers"]}
                 for bn, blk in (m.get("register_blocks") or {}).items()},
        "ENUMS": {bn: {en: {v["name"]: v["value"] for v in vals} for en, vals in (blk.get("enums") or {}).items()}
                  for bn, blk in (m.get("register_blocks") or {}).items()},
    }
    s = f'"""GENERATED by python/datafabric/memmap_gen.py from {src} -- do not edit."""\n'
    for k, v in out.items():
        s += f"{k} = {v!r}\n"
    s += ("\n\ndef decode(addr: int):\n    \"\"\"Region name for a byte address, or None (unmapped).\"\"\"\n"
          "    for n, (b, sz, _a, _s) in REGIONS.items():\n        if b <= addr < b + sz:\n            return n\n"
          "    return None\n")
    return s


def gen_md(m: dict, src: str) -> str:
    L = [f"# SilicaFlux-V + DataFabric memory map\n", f"Generated from `{src}` by `python/datafabric/memmap_gen.py` "
         "-- edit the YAML, not this file.  Little-endian, 32-bit byte addresses.  Unlisted addresses are "
         "**unmapped and return a bus error** (never aliased to SRAM).\n",
         "## Regions (crossbar slave ports)\n", "| # | Region | Base | Size | End | Access | Slave | New | Note |",
         "|---|---|---|---|---|---|---|---|---|"]
    for i, r in enumerate(m["regions"]):
        L.append(f"| {i} | {r['name']} | `0x{r['base']:08X}` | {r['size'] // 1024} KiB | `0x{r['base'] + r['size'] - 1:08X}` "
                 f"| {r['access']} | {r.get('slave', r['name'])} | {'yes' if r.get('new') else ''} | {r.get('note', '')} |")
    L += ["\n## Peripheral pages (4 KiB each, inside PERIPH)\n", "| Page | Index | Base | New | Register block |",
          "|---|---|---|---|---|"]
    for p in m.get("pages") or []:
        L.append(f"| {p['name']} | {p['index']} | `0x{p['base']:08X}` | {'yes' if p.get('new') else ''} | {p.get('block', '')} |")
    L += ["\n## Bus masters and access matrix\n", "| Master | Index | Denied regions (decode error) | Note |",
          "|---|---|---|---|"]
    for x in m.get("masters") or []:
        L.append(f"| {x['name']} | {x['index']} | {', '.join(x.get('deny') or []) or '-'} | {x.get('note', '')} |")
    L += ["\n## Interrupt sources (INTC)\n", "| Source | Index | New |", "|---|---|---|"]
    for q in m.get("interrupts") or []:
        L.append(f"| {q['name']} | {q['index']} | {'yes' if q.get('new') else ''} |")
    for bn, blk in (m.get("register_blocks") or {}).items():
        page = next((p for p in m.get("pages") or [] if p.get("block") == bn), None)
        L.append(f"\n## Register block `{bn}`" + (f" (page {page['name']}, `0x{page['base']:08X}`)" if page else ""))
        L += ["", "| Offset | Register | Access | Reset | Fields / description |", "|---|---|---|---|---|"]
        for r in blk["registers"]:
            fs = "; ".join(f"[{fd['msb']}:{fd['lsb']}] {fd['name']} ({fd['access']}): {fd.get('desc', '')}"
                           if fd["msb"] != fd["lsb"] else f"[{fd['lsb']}] {fd['name']} ({fd['access']}): {fd.get('desc', '')}"
                           for fd in r.get("fields") or [])
            L.append(f"| 0x{r['offset']:03X} | {r['name']} | {r['access']} | 0x{r.get('reset', 0):X} | {fs or r.get('desc', '')} |")
        pm = blk.get("per_master")
        if pm:
            for r in pm["registers"]:
                L.append(f"| 0x{pm['base']:03X} + 0x{pm['stride']:X}*m + 0x{r['offset']:02X} | {r['name']}[m] | ro | 0x0 | {r.get('desc', '')} |")
        for en, vals in (blk.get("enums") or {}).items():
            L.append(f"\n`{bn}.{en}` values: " + ", ".join(f"{v['value']} = {v['name']}" for v in vals))
    return "\n".join(L) + "\n"


def outputs(m: dict, src: str) -> dict[str, str]:
    return {
        "generated/sfb_memmap_pkg.sv": gen_sv_pkg(m, src),
        "rtl/dma/dma_defs.svh": gen_svh(m, "dma", src),
        "rtl/interconnect/sfb_perf_defs.svh": gen_svh(m, "dfperf", src),
        "generated/sfv_df_map.h": gen_c(m, src),
        "generated/datafabric_map.py": gen_py(m, src),
        "docs/datafabric/MEMORY_MAP.md": gen_md(m, src),
    }


# =========================================================================== SilicaFlux-V cross-check
def crosscheck_sfv_pkg(m: dict, pkg_path: str) -> list[str]:
    """Compare against silicaflux-v rtl/pkg/sfv_pkg.sv.  Returns findings; raises on conflicts."""
    txt = open(pkg_path).read()
    vals = {}
    for n, v in re.findall(r"localparam\s+logic\s*\[31:0\]\s+(\w+)\s*=\s*32'h([0-9A-Fa-f_]+)", txt):
        vals[n] = int(v.replace("_", ""), 16)
    ints = {n: int(v) for n, v in re.findall(r"localparam\s+int\s+(\w+)\s*=\s*(\d+)", txt)}
    reg = {r["name"]: r for r in m["regions"]}
    conflicts, notes = [], []

    def eq(what, a, b):
        (notes if a == b else conflicts).append(f"{what}: yaml 0x{a:08X} vs sfv_pkg 0x{b:08X}")
    eq("ROM base", reg["BOOT_ROM"]["base"], vals["ROM_BASE"])
    eq("SRAM base", reg["SRAM_BANK0"]["base"], vals["SRAM_BASE"])
    eq("TSPM base", reg["TSPM"]["base"], vals["TSPM_BASE"])
    eq("PERIPH base", reg["PERIPH"]["base"], vals["PERIPH_BASE"])
    eq("PERIPH mask", (~(reg["PERIPH"]["size"] - 1)) & 0xFFFFFFFF, vals["PERIPH_MASK"])
    for n, key in (("BOOT_ROM", "ROM_MASK"), ("TSPM", "TSPM_MASK")):
        mk = (~(reg[n]["size"] - 1)) & 0xFFFFFFFF
        if mk != vals[key]:
            notes.append(f"INFO {key}=0x{vals[key]:08X} in sfv_pkg is NOT the decode window used by sfv_soc "
                         f"(sfv_soc decodes {n} with ~({n}_BYTES-1) = 0x{mk:08X}); the yaml follows sfv_soc")
    for p in m.get("pages") or []:
        k = f"PG_{p['name']}"
        if k in ints:
            (notes if ints[k] == p["index"] else conflicts).append(f"page {p['name']}: yaml {p['index']} vs sfv_pkg {ints[k]}")
        elif not p.get("new"):
            conflicts.append(f"page {p['name']} not in sfv_pkg and not marked new")
    for x in m.get("masters") or []:
        k = f"M_{x['name']}"
        if k in ints:
            (notes if ints[k] == x["index"] else conflicts).append(f"master {x['name']}: yaml {x['index']} vs {ints[k]}")
        elif not x.get("new"):
            conflicts.append(f"master {x['name']} not in sfv_pkg and not marked new")
    for q in m.get("interrupts") or []:
        k = f"IRQ_{q['name']}"
        if k in ints:
            (notes if ints[k] == q["index"] else conflicts).append(f"irq {q['name']}: yaml {q['index']} vs {ints[k]}")
        elif not q.get("new"):
            conflicts.append(f"irq {q['name']} not in sfv_pkg and not marked new")
    used_pages = {ints[k] for k in ints if k.startswith("PG_")}
    for p in m.get("pages") or []:
        if p.get("new") and p["index"] in used_pages:
            conflicts.append(f"new page {p['name']} reuses page index {p['index']} already used by SilicaFlux-V")
    if conflicts:
        raise MemoryMapError("conflicts with SilicaFlux-V sfv_pkg:\n  " + "\n  ".join(conflicts))
    return notes


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("yaml")
    ap.add_argument("--root", default=".")
    ap.add_argument("--check", action="store_true", help="fail if generated files are stale")
    ap.add_argument("--sfv-pkg", help="silicaflux-v rtl/pkg/sfv_pkg.sv to cross-check")
    a = ap.parse_args(argv)
    try:
        m = load(a.yaml)
        if a.sfv_pkg:
            for n in crosscheck_sfv_pkg(m, a.sfv_pkg):
                print("crosscheck:", n)
    except MemoryMapError as e:
        print(f"memmap_gen: ERROR: {e}", file=sys.stderr)
        return 2
    src = os.path.relpath(a.yaml, a.root) if os.path.isabs(a.yaml) else a.yaml
    stale = []
    for rel, text in outputs(m, src).items():
        p = os.path.join(a.root, rel)
        old = open(p).read() if os.path.exists(p) else None
        if a.check:
            if old != text:
                stale.append(rel)
        elif old != text:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w").write(text)
            print("wrote", rel)
    if a.check:
        if stale:
            print("memmap_gen: stale generated files:", ", ".join(stale), file=sys.stderr)
            return 1
        print("memmap_gen: all generated files up to date")
    return 0


if __name__ == "__main__":
    sys.exit(main())
