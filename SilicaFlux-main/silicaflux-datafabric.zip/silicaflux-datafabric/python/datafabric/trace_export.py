#!/usr/bin/env python3
"""DataFabric transaction traces -> MemoryLab canonical traces.

Input: CSV written by tb/common/sfb_trace_monitor.sv
  cycle,event,master,id,addr,op,size,bank,slave,error,stall_cycles
  (event in ISSUE / ACCEPT / CONFLICT / RESPONSE; bank = slave index; -1 unmapped)
Output (MemoryLab python/memorylab/trace_import.py canonical columns, plus
DataFabric extras kept as additional columns):
  cycle,event,master,id,addr,op,size,bank[,slave,error,stall_cycles]
as CSV or JSON ({"transactions": [...]}).

Validation performed on every load (TraceError on failure):
  * known events, non-negative cycles, monotonically non-decreasing cycles;
  * per master: every ACCEPT has a later RESPONSE (unless the trace was cut
    at the end), responses in acceptance order, at most `max_outstanding`
    accepted-but-unanswered transactions (1 for SFB2 rev 2.0 crossbar ports).

  trace_export.py IN.csv --out OUT.csv|OUT.json [--names DBG,CPUD,CPUI,DMA]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict

EVENTS = {"ISSUE", "ACCEPT", "CONFLICT", "RESPONSE"}
COLS = ["cycle", "event", "master", "id", "addr", "op", "size", "bank", "slave", "error", "stall_cycles"]


class TraceError(ValueError):
    pass


def load(path: str, max_outstanding: int = 1, allow_truncated: bool = True) -> list[dict]:
    rows = []
    with open(path) as f:
        rd = csv.DictReader(f)
        missing = set(COLS) - set(rd.fieldnames or [])
        if missing:
            raise TraceError(f"{path}: missing columns {sorted(missing)}")
        for r in rd:
            row = {k: (r[k] if k == "event" or k == "op" else int(r[k])) for k in COLS}
            if row["event"] not in EVENTS:
                raise TraceError(f"{path}: unknown event {row['event']!r}")
            rows.append(row)
    validate(rows, max_outstanding, allow_truncated)
    return rows


def validate(rows: list[dict], max_outstanding: int = 1, allow_truncated: bool = True) -> dict:
    last = -1
    pend: dict[int, list[int]] = defaultdict(list)
    stats = {"accepts": 0, "responses": 0, "max_outstanding_seen": 0}
    for r in rows:
        if r["cycle"] < 0 or r["cycle"] < last:
            raise TraceError(f"non-monotonic cycle at {r}")
        last = r["cycle"]
        m = r["master"]
        if r["event"] == "ACCEPT":
            pend[m].append(r["id"])
            stats["accepts"] += 1
            # an ACCEPT logged in the same cycle as the previous RESPONSE is the
            # SFB2 back-to-back case; the monitor writes the RESPONSE line first
            if len(pend[m]) > max_outstanding:
                raise TraceError(f"master {m}: more than {max_outstanding} outstanding at cycle {r['cycle']}")
            stats["max_outstanding_seen"] = max(stats["max_outstanding_seen"], len(pend[m]))
        elif r["event"] == "RESPONSE":
            if not pend[m]:
                raise TraceError(f"master {m}: response without acceptance at cycle {r['cycle']}")
            exp = pend[m].pop(0)
            if r["id"] != exp:
                raise TraceError(f"master {m}: response id {r['id']} out of order (expected {exp})")
            stats["responses"] += 1
    open_ = sum(len(v) for v in pend.values())
    if open_ and not allow_truncated:
        raise TraceError(f"{open_} transactions without response")
    stats["open_at_end"] = open_
    return stats


def to_memorylab(rows: list[dict], names: list[str] | None = None) -> list[dict]:
    out = []
    for r in rows:
        o = {"cycle": r["cycle"], "event": r["event"], "master": names[r["master"]] if names else r["master"],
             "id": r["id"], "addr": r["addr"], "op": r["op"], "size": r["size"], "bank": r["bank"],
             "slave": r["slave"], "error": r["error"], "stall_cycles": r["stall_cycles"]}
        out.append(o)
    return out


def write(rows: list[dict], path: str) -> None:
    if path.endswith(".json"):
        json.dump({"format": "memorylab-canonical+datafabric", "transactions": rows}, open(path, "w"))
    else:
        with open(path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else COLS)
            w.writeheader()
            w.writerows(rows)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("trace")
    ap.add_argument("--out", required=True)
    ap.add_argument("--names", help="comma-separated master names, index order")
    ap.add_argument("--max-outstanding", type=int, default=1)
    a = ap.parse_args(argv)
    try:
        rows = load(a.trace, a.max_outstanding)
    except TraceError as e:
        print("trace_export: INVALID:", e, file=sys.stderr)
        return 2
    write(to_memorylab(rows, a.names.split(",") if a.names else None), a.out)
    print(f"trace_export: {len(rows)} events -> {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
