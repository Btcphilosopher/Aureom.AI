#!/usr/bin/env python3
"""DataFabric <-> SilicaFlux MemoryLab (Project 02) adapter.

1. MEASURED: imports real Verilator transaction traces (DataFabric CSV ->
   MemoryLab canonical) and runs MemoryLab's OWN analyser
   (memorylab.trace_import.trace_metrics) on them -- span, accepted
   transactions, words/cycle, latency statistics, ordering problems -- next to
   DataFabric's bandwidth_analysis (per-master bandwidth, arbitration delay,
   contention).
2. PREDICTED: runs MemoryLab's event-driven DMA/interconnect/SRAM model
   (memorylab.calibration.dma_copy_cycles, the model MemoryLab calibrated
   against memoryflow's sf_dma) for a 4 KiB SRAM->SRAM copy with parameters
   mapped from each DataFabric DMA configuration, and compares with the
   MEASURED RTL cycles from reports/datafabric/benchmark.json.
Measured and predicted numbers are kept in separate, labelled columns; the
model's structural assumptions that differ from the RTL are listed.

MemoryLab is located with --memorylab DIR (its python/ directory) or the
MEMORYLAB_PY environment variable.  Without it, step 1 still runs the
DataFabric analysis and step 2 is reported as "not run".

  memorylab_adapter.py --traces reports/datafabric/traces --out reports/datafabric
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bandwidth_analysis as ba  # noqa: E402
import trace_export as te  # noqa: E402

# DataFabric DMA configuration -> MemoryLab Dma model parameters.
# beat = DW/8; SilicaFlux-V SRAM: 1-cycle read latency; crossbar adds 0 cycles.
# rd/wr_outstanding: simple engine = 1 (and NO read/write overlap: see notes);
# buffered = MAX_OUT (2), burst = BURST beats.
MODEL_MAP = {
    "simple_d32": dict(burst_beats=1, rd_outstanding=1, wr_outstanding=1, beat=4),
    "simple_d64": dict(burst_beats=1, rd_outstanding=1, wr_outstanding=1, beat=8),
    "simple_d128": dict(burst_beats=1, rd_outstanding=1, wr_outstanding=1, beat=16),
    "buf_f8_b8": dict(burst_beats=8, rd_outstanding=2, wr_outstanding=2, beat=4),
    "buf_f16_b16": dict(burst_beats=16, rd_outstanding=2, wr_outstanding=2, beat=4),
    "buf_f8_dual": dict(burst_beats=8, rd_outstanding=2, wr_outstanding=2, beat=4),
    "buf_f8_b8_d64": dict(burst_beats=8, rd_outstanding=2, wr_outstanding=2, beat=8),
}
NOTES = [
    "MemoryLab's Dma model always decouples reads and writes through a data FIFO and lets them overlap; "
    "the DataFabric simple engine is strictly read-then-write per beat (one data register), so the model "
    "is optimistic for it by construction.",
    "MemoryLab's interconnect gives reads and writes independent progress; the single-port buffered engine "
    "shares one SFB2 port and alternates READ/WRITE phases, so only the dual-port configuration matches the "
    "model's structure.",
    "Measured cycles include the start-register write and ~2-cycle STATUS polling; the model reports "
    "submit-to-last-write-ack (setup = 4 cycles as in MemoryLab's DMA_DEFAULTS).",
    "The model's 'spm2spm' copies inside one 4-bank SRAM, so it is compared with the measured same-slave "
    "copy (one crossbar slave port serves both reads and writes); the two-slave copy is listed separately.",
]


def load_memorylab(path: str | None):
    p = path or os.environ.get("MEMORYLAB_PY")
    if not p:
        return None, "MemoryLab not located (use --memorylab or MEMORYLAB_PY)"
    sys.path.insert(0, p)
    try:
        import memorylab.calibration as cal  # noqa: F401
        import memorylab.trace_import as ti  # noqa: F401
        tail = os.path.join(*os.path.normpath(p).split(os.sep)[-2:])  # no build-machine path in reports
        return (ti, cal), f"MemoryLab imported from MEMORYLAB_PY=.../{tail}"
    except Exception as e:  # pragma: no cover
        return None, f"MemoryLab import failed: {e}"


def analyse_traces(trace_dir: str, ml) -> list[dict]:
    out = []
    names = ["DBG", "CPUD", "CPUI", "DMA"]
    for path in sorted(glob.glob(os.path.join(trace_dir, "*.csv"))):
        if path.endswith(".memorylab.csv"):
            continue
        rows = te.load(path, max_outstanding=1)
        stats = te.validate(rows, 1)
        canon = te.to_memorylab(rows)
        cpath = path[:-4] + ".memorylab.csv"
        te.write(canon, cpath)
        is_soc = "tb_dma" not in os.path.basename(path)
        bw = ba.analyse(rows, names if is_soc else None)
        rec = dict(trace=os.path.relpath(path), canonical=os.path.relpath(cpath), events=len(rows),
                   validation=stats, datafabric=bw)
        if ml:
            ti = ml[0]
            df = ti.read_trace(cpath)
            m = ti.trace_metrics(df)
            rec["memorylab_trace_metrics"] = {k: (round(v, 4) if isinstance(v, float) else v) for k, v in m.items()}
        out.append(rec)
    return out


def predictions(bench_json: str, ml) -> list[dict]:
    meas = {}
    if os.path.exists(bench_json):
        for r in json.load(open(bench_json))["results"]:
            if r.get("ok") and r.get("scenario") == "ideal":
                meas[r["config"]] = r
    rows = []
    for cfg, mp in MODEL_MAP.items():
        # MemoryLab's spm2spm copies inside ONE 4-bank SRAM -> compare with the
        # measured same-slave copy; the two-slave (xbank) number is listed for reference
        row = dict(config=cfg, measured_rtl_cycles=meas.get(cfg, {}).get("samebank_cycles"),
                   measured_rtl_bytes_per_cycle=meas.get(cfg, {}).get("samebank_bpc"),
                   measured_rtl_xbank_cycles=meas.get(cfg, {}).get("xbank_cycles"))
        if ml:
            cal = ml[1]
            pred = cal.dma_copy_cycles("spm2spm", mp["burst_beats"], overhead=0, setup=4, ext_latency=20,
                                       spm_latency=1, rd_outstanding=mp["rd_outstanding"],
                                       wr_outstanding=mp["wr_outstanding"], nbytes=4096, beat=mp["beat"])
            row["memorylab_predicted_cycles"] = pred
            row["memorylab_predicted_bytes_per_cycle"] = round(4096 / pred, 4)
            if row["measured_rtl_cycles"]:
                row["measured_over_predicted"] = round(row["measured_rtl_cycles"] / pred, 3)
        row["model_params"] = mp
        rows.append(row)
    return rows


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--traces", default="reports/datafabric/traces")
    ap.add_argument("--bench", default="reports/datafabric/benchmark.json")
    ap.add_argument("--memorylab")
    ap.add_argument("--out", default="reports/datafabric")
    a = ap.parse_args(argv)
    ml, msg = load_memorylab(a.memorylab)
    print(msg)
    tr = analyse_traces(a.traces, ml)
    pr = predictions(a.bench, ml)
    res = dict(memorylab=msg, traces=tr, dma_copy_4k=pr, model_vs_rtl_notes=NOTES)
    os.makedirs(a.out, exist_ok=True)
    json.dump(res, open(os.path.join(a.out, "memorylab_comparison.json"), "w"), indent=1)
    with open(os.path.join(a.out, "memorylab_comparison.md"), "w") as f:
        f.write(f"# DataFabric x MemoryLab\n\n{msg}.\n\n## 1. Measured RTL traces analysed by MemoryLab's own "
                "`trace_import.trace_metrics` (and DataFabric bandwidth_analysis)\n\n"
                "| trace | events | MemoryLab: span / accepted / words per cycle / avg / p95 / max latency / problems | "
                "DMA (or master 0) B/cycle, avg arb delay, conflicts |\n|---|---|---|---|\n")
        for r in tr:
            mlm = r.get("memorylab_trace_metrics", {})
            dm = r["datafabric"]["masters"].get("DMA") or r["datafabric"]["masters"].get("0") or {}
            f.write(f"| `{os.path.basename(r['trace'])}` | {r['events']} | "
                    f"{mlm.get('span_cycles')} / {mlm.get('accepted')} / {mlm.get('words_per_cycle')} / "
                    f"{mlm.get('avg_latency_cycles')} / {mlm.get('p95_latency_cycles')} / {mlm.get('max_latency_cycles')} / "
                    f"{mlm.get('problems')} | {dm.get('bytes_per_cycle')}, {dm.get('avg_arb_delay')}, "
                    f"{dm.get('conflict_cycles')} |\n")
        f.write("\n## 2. 4 KiB SRAM->SRAM DMA copy: MEASURED RTL vs MemoryLab event-model PREDICTION\n\n"
                "| config | measured RTL cycles (same slave) | measured B/cycle | MemoryLab predicted cycles | predicted B/cycle | "
                "measured / predicted | measured RTL cycles (two slaves) |\n|---|---|---|---|---|---|---|\n")
        for r in pr:
            f.write(f"| {r['config']} | {r['measured_rtl_cycles']} | {r['measured_rtl_bytes_per_cycle']} | "
                    f"{r.get('memorylab_predicted_cycles', 'not run')} | {r.get('memorylab_predicted_bytes_per_cycle', '')} | "
                    f"{r.get('measured_over_predicted', '')} | {r.get('measured_rtl_xbank_cycles')} |\n")
        f.write("\nWhy the model and the RTL differ (structural assumptions, not tuning):\n\n" +
                "".join(f"- {n}\n" for n in NOTES))
    print(f"memorylab_adapter: {len(tr)} traces, {len(pr)} model comparisons -> {a.out}/memorylab_comparison.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
