# Formal results

Yosys 0.33 (git sha1 2584903a060); BMC with yosys-smtbmc + Z3 version 5.3.3 - 64 bit or ABC bmc3 (bit-level, on the AIGER model); unbounded proofs with ABC PDR (yosys-abc).  `expect FAIL` rows are non-vacuity checks: the same harness on deliberately broken RTL must produce a counterexample.  A PDR result of UNKNOWN means the engine hit its time budget: the property then holds only to the BMC depth.

| job | top | params | BMC | unbounded | expect | verdict | note |
|---|---|---|---|---|---|---|---|
| arbiter_rr_n3 | fv_sfb_arbiter | {'N': 3, 'MODE': 1} | PASS depth 24 | PROVED (unbounded, ABC PDR) | PASS | OK |  |
| arbiter_rr_n5 | fv_sfb_arbiter | {'N': 5, 'MODE': 1} | PASS depth 12 | PROVED (unbounded, ABC PDR) | PASS | OK |  |
| arbiter_fixed_n4 | fv_sfb_arbiter | {'N': 4, 'MODE': 0} | PASS depth 20 | PROVED (unbounded, ABC PDR) | PASS | OK |  |
| skid_buffer | fv_sfb_skid | {} | PASS depth 30 | PROVED (unbounded, ABC PDR) | PASS | OK |  |
| crossbar_3x2 | fv_sfb_xbar | {} | PASS depth 10 | PROVED (unbounded, ABC PDR) | PASS | OK |  |
| dma_simple_engine | fv_dma_engine | {'ENGINE': 0, 'LEN_BITS': 6} | PASS depth 23 (abc bmc3) | UNKNOWN (PDR budget 1200 s reached in frame 76) | PASS | OK, **bounded only** |  |
| dma_burst_engine | fv_dma_engine | {'ENGINE': 1, 'LEN_BITS': 5} | PASS depth 22 (abc bmc3) | UNKNOWN (PDR budget 1200 s reached in frame 18) | PASS | OK, **bounded only** |  |
| mut_xbar_misroute | fv_sfb_xbar | {} | FAIL (counterexample) | - | FAIL | OK | response routed to owner+1 |
| mut_xbar_no_lock | fv_sfb_xbar | {} | FAIL (counterexample) | - | FAIL | OK | grant lock removed (slave-side R2) |
| mut_arb_rr_stuck | fv_sfb_arbiter | {'N': 3, 'MODE': 1} | FAIL (counterexample) | - | FAIL | OK | RR pointer never advances (fairness A4) |
| mut_skid_drop | fv_sfb_skid | {} | FAIL (counterexample) | - | FAIL | OK | parked beat not stored |
| mut_dma_tail_strobe | fv_dma_engine | {'ENGINE': 0, 'LEN_BITS': 6} | FAIL (counterexample) | - | FAIL | OK | tail strobe ignored (write beyond len) |
