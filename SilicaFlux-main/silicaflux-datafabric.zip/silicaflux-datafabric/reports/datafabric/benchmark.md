# DataFabric RTL benchmark (MEASURED, Verilator)

4 KiB copy, cycles from START to BUSY=0 (includes ~2-cycle register polling).  ideal = no back-pressure, 1-cycle slaves, no other traffic; contention = NC competing masters at 70 % request rate on the same SRAM slaves.

| config | scenario | xbank cycles | xbank B/cycle | same-bank cycles | same-bank B/cycle | competing accepts | TB |
|---|---|---|---|---|---|---|---|
| buf8_nc1_fp | contention | 2563 | 1.598127 | 2563 | 1.598127 | 1422 | PASS |
| buf8_nc1_fp | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf8_nc1_rr | contention | 3432 | 1.193473 | 3470 | 1.180403 | 4291 | PASS |
| buf8_nc1_rr | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf8_nc2_fp | contention | 2563 | 1.598127 | 2563 | 1.598127 | 2058 | PASS |
| buf8_nc2_fp | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf8_nc2_rr | contention | 4617 | 0.887156 | 4607 | 0.889082 | 7754 | PASS |
| buf8_nc2_rr | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf8_nc3_fp | contention | 2563 | 1.598127 | 2563 | 1.598127 | 2501 | PASS |
| buf8_nc3_fp | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf8_nc3_rr | contention | 5783 | 0.708283 | 5899 | 0.694355 | 10782 | PASS |
| buf8_nc3_rr | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf8_nc4_fp | contention | 2563 | 1.598127 | 2563 | 1.598127 | 2840 | PASS |
| buf8_nc4_fp | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf8_nc4_rr | contention | 7006 | 0.584642 | 7464 | 0.548767 | 13838 | PASS |
| buf8_nc4_rr | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf_f16_b16 | contention | 4410 | 0.928798 | 4509 | 0.908405 | 7520 | PASS |
| buf_f16_b16 | ideal | 2307 | 1.775466 | 2307 | 1.775466 | 0 | PASS |
| buf_f2_b2 | contention | 5453 | 0.751146 | 5538 | 0.739617 | 9324 | PASS |
| buf_f2_b2 | ideal | 4099 | 0.999268 | 4099 | 0.999268 | 0 | PASS |
| buf_f4_b4 | contention | 4898 | 0.83626 | 4925 | 0.831675 | 8249 | PASS |
| buf_f4_b4 | ideal | 3075 | 1.332033 | 3075 | 1.332033 | 0 | PASS |
| buf_f8_b1 | contention | 6620 | 0.618731 | 6543 | 0.626013 | 11329 | PASS |
| buf_f8_b1 | ideal | 6147 | 0.666341 | 6147 | 0.666341 | 0 | PASS |
| buf_f8_b4 | contention | 4898 | 0.83626 | 4925 | 0.831675 | 8249 | PASS |
| buf_f8_b4 | ideal | 3075 | 1.332033 | 3075 | 1.332033 | 0 | PASS |
| buf_f8_b8 | contention | 4617 | 0.887156 | 4607 | 0.889082 | 7754 | PASS |
| buf_f8_b8 | ideal | 2563 | 1.598127 | 2563 | 1.598127 | 0 | PASS |
| buf_f8_b8_d64 | contention | 2263 | 1.809987 | 2247 | 1.822875 | 3853 | PASS |
| buf_f8_b8_d64 | ideal | 1283 | 3.192518 | 1283 | 3.192518 | 0 | PASS |
| buf_f8_dual | contention | 2077 | 1.972075 | 3543 | 1.156082 | 4228 | PASS |
| buf_f8_dual | ideal | 1031 | 3.972842 | 2053 | 1.995129 | 0 | PASS |
| simple_d128 | contention | 1123 | 3.647373 | 1304 | 3.141104 | 2074 | PASS |
| simple_d128 | ideal | 1028 | 3.984436 | 1028 | 3.984436 | 0 | PASS |
| simple_d32 | contention | 4534 | 0.903397 | 5235 | 0.782426 | 8242 | PASS |
| simple_d32 | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_d64 | contention | 2265 | 1.808389 | 2603 | 1.573569 | 4135 | PASS |
| simple_d64 | ideal | 2052 | 1.996101 | 2052 | 1.996101 | 0 | PASS |
| simple_nc1_fp | contention | 4100 | 0.999024 | 4100 | 0.999024 | 4742 | PASS |
| simple_nc1_fp | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_nc1_rr | contention | 4277 | 0.957681 | 4459 | 0.918592 | 5380 | PASS |
| simple_nc1_rr | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_nc2_fp | contention | 4100 | 0.999024 | 4100 | 0.999024 | 6466 | PASS |
| simple_nc2_fp | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_nc2_rr | contention | 4534 | 0.903397 | 5235 | 0.782426 | 8242 | PASS |
| simple_nc2_rr | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_nc3_fp | contention | 4100 | 0.999024 | 4100 | 0.999024 | 6906 | PASS |
| simple_nc3_fp | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_nc3_rr | contention | 4671 | 0.8769 | 6429 | 0.637113 | 10170 | PASS |
| simple_nc3_rr | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_nc4_fp | contention | 4100 | 0.999024 | 4100 | 0.999024 | 7057 | PASS |
| simple_nc4_fp | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |
| simple_nc4_rr | contention | 5027 | 0.8148 | 7729 | 0.529952 | 12132 | PASS |
| simple_nc4_rr | ideal | 4100 | 0.999024 | 4100 | 0.999024 | 0 | PASS |

## Arbitration fairness (tb_sfb_xbar, 4 masters x 7 slaves, 20k cycles)

| topology | arbitration | traffic | accepted per master | max wait per master | min share | TB |
|---|---|---|---|---|---|---|
| crossbar | fixed | random | [7846, 7415, 6702, 6899] | [9, 13, 17, 24] | 0.2322 | PASS slave_accepts=24903 protocol_violat |
| crossbar | fixed | sustained contention | [10000, 1, 1, 1] | [1, 962, 964, 966] | 0.0001 | PASS slave_accepts=10003 protocol_violat |
| crossbar | round robin | random | [7058, 7078, 7168, 7739] | [13, 13, 12, 11] | 0.243 | PASS slave_accepts=24871 protocol_violat |
| crossbar | round robin | sustained contention | [2501, 2501, 2501, 2500] | [7, 7, 7, 7] | 0.2499 | PASS slave_accepts=10003 protocol_violat |
| shared bus | fixed | random | [8138, 1385, 76, 1] | [10, 104, 2130, 4] | 0.0001 | FAIL errors=1 protocol_violations=0 |
| shared bus | fixed | sustained contention | [10000, 1, 1, 1] | [1, 962, 964, 966] | 0.0001 | PASS slave_accepts=10003 protocol_violat |
| shared bus | round robin | random | [2401, 2400, 2401, 2400] | [19, 19, 16, 17] | 0.2499 | PASS slave_accepts=8635 protocol_violati |
| shared bus | round robin | sustained contention | [2501, 2501, 2501, 2500] | [7, 7, 7, 7] | 0.2499 | PASS slave_accepts=10003 protocol_violat |
