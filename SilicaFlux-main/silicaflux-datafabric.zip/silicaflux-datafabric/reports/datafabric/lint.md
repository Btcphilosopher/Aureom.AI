# Lint

**25/25 PASS** (Verilator 5.020 -Wall: zero warnings required in DataFabric files; third-party SilicaFlux-V warnings counted separately; Yosys 0.33 elaboration, `check -assert`, no latches)

| tool | top | params | result | DataFabric warnings | third-party warnings | detail |
|---|---|---|---|---|---|---|
| verilator -Wall | sfb_crossbar |  | PASS | 0 | 0 |  |
| verilator -Wall | sfb_crossbar | -GNM=5 -GNS=3 -GDW=128 -GARB_MODE=0 | PASS | 0 | 0 |  |
| verilator -Wall | sfb_shared_bus | -GNM=3 -GNS=4 | PASS | 0 | 0 |  |
| verilator -Wall | sfb_reg_slice |  | PASS | 0 | 0 |  |
| verilator -Wall | sfb_v1_slave_adapter |  | PASS | 0 | 0 |  |
| verilator -Wall | sfb_perf_counters |  | PASS | 0 | 0 |  |
| verilator -Wall | silicaflux_dma |  | PASS | 0 | 0 |  |
| verilator -Wall | silicaflux_dma | -GENGINE=1 | PASS | 0 | 0 |  |
| verilator -Wall | silicaflux_dma | -GENGINE=1 -GDUAL_PORT=1 | PASS | 0 | 0 |  |
| verilator -Wall | silicaflux_dma | -GDW=128 -GPERF=0 | PASS | 0 | 0 |  |
| verilator -Wall | silicaflux_dma | -GENGINE=1 -GDW=64 -GFIFO_DEPTH=16 -GBURST=16 | PASS | 0 | 0 |  |
| verilator -Wall | sfb_sram_slave | -GREAD_LATENCY=2 | PASS | 0 | 2 |  |
| verilator -Wall | sfb_sram_1r1w_slave |  | PASS | 0 | 2 |  |
| verilator -Wall | sfv_soc_df |  | PASS | 0 | 48 |  |
| verilator -Wall | sfv_soc_df | -GDMA_ENGINE=1 -GPERF=0 -GSRAM_IMPL=1 | PASS | 0 | 47 |  |
| yosys 0.33 elab+check+latch rule | sfb_crossbar |  | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | sfb_shared_bus |  | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | sfb_reg_slice |  | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | sfb_v1_slave_adapter |  | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | sfb_perf_counters |  | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | silicaflux_dma |  | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | silicaflux_dma | chparam -set ENGINE 1 silicaflux_dma; | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | silicaflux_dma | chparam -set ENGINE 1 -set DUAL_PORT 1 silicaflux_dma; | PASS |  |  |  |
| yosys 0.33 elab+check+latch rule | sfv_soc_df |  | PASS |  |  | 1 latch(es), all in sfv_clkgate (ICG model) |
| memmap_gen --check --sfv-pkg | memory map |  | PASS |  |  | crosscheck: INFO ROM_MASK=0xFFFFC000 in sfv_pkg is NOT the decode window used by sfv_soc (sfv_soc decodes BOOT_ROM with ~(BOOT_ROM_BYTES-1) = 0xFFFFF000); the yaml follows sfv_soc; crosscheck: INFO TS |
