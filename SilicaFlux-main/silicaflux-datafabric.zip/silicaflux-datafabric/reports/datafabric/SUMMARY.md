# SilicaFlux DataFabric -- verification and PPA summary

Generated 2026-11-06 02:40 UTC by `scripts/datafabric/report.py` from the JSON reports in this directory.

Source: btcphilosopher/Aureom.AI branch claude/awesome-albattani-y4t7ih @ 05183f2 (SilicaFlux-main archives; nothing committed).

## Tools

| tool | version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| z3 | Z3 version 5.3.3 - 64 bit |
| clang | Ubuntu clang version 18.1.3 (1ubuntu1) |
| python | Python 3.13.18 |
| cocotb | 2.1.0 |
| sby | not installed |
| openroad | not installed |

## Source hashes (sha256 over file paths + contents)

| tree | sha256 |
|---|---|
| rtl | `9ff28812edc6d5eae1eaa99d58af494c785c32c668d81a9483661ecf8b3b420e` |
| tb | `a378f114a80c83a599f3cf1a1eccbd64b507cdb6f91ad6fe4b260e22d365542d` |
| firmware | `c2572d05a2e091b5ffe3bc6d929f54e43cfa303c70efd5c39882c2d639c191b9` |
| memmap | `c2ecd6dac3d41d3571d06b127f8c6aecbe520e78ba7c22cc032907030210982a` |
| third_party | `30c7f549be123d587e6bcf8aa738d77b1d2aaa8ad00fde072a6ec3172509bbab` |

## Results

| check | report | result |
|---|---|---|
| RTL lint (Verilator -Wall, Yosys elab/latch, map freshness) | [lint.json](lint.md) | 25/25 PASS |
| Unit regression (tb_dma, slices, sramlib, cocotb, pytest) | [unit_regression.json](unit_regression.md) | 56/56 PASS |
| Crossbar parameter regression (tb_sfb_xbar) | [xbar_regression.json](xbar_regression.md) | 115/115 PASS |
| Mutation campaign (testbench strength) | [xbar_mutants.json](xbar_mutants.md) | 12/12 mutants killed |
| SoC firmware regression (sfv_soc_df) | [soc_regression.json](soc_regression.md) | 18/18 PASS |
| Formal (BMC + ABC PDR + non-vacuity mutants) | [formal.json](formal.md) | 12/12 jobs as expected: 5 unbounded proofs, 2 bounded only (PDR undecided), 5 mutants caught |
| Gate-level simulation | [gls.json](gls.md) | 5/5 PASS |
| Synthesis (Yosys generic CMOS, no PDK) | [synth.json](synth.md) | 34/34 configurations, 0 latches |
| RTL performance sweep | [benchmark.json](benchmark.md) | 54/54 runs PASS |
| MemoryLab integration | [memorylab_comparison.json](memorylab_comparison.md) | 5 RTL traces analysed; MemoryLab imported from MEMORYLAB_PY=.../silicaflux-memorylab/python |

Not run / not available here: SymbiYosys (proofs were run with yosys-smtbmc and ABC PDR directly), OpenROAD/OpenSTA and any PDK Liberty (no placement, timing, routing-congestion or power numbers are claimed), FPGA bitstream (no nextpnr), riscv-tests (the CPU is unchanged from release 1).
