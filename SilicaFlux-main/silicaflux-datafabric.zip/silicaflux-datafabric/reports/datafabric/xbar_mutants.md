# Crossbar mutation campaign

**12/12 mutants killed** (tb_sfb_xbar NM=3 NS=3 ARB=RR, or tb_sfb_reg_slice for skid/slice mutants; seed 1, 20k cycles)

| id | injected bug | killed | first symptom |
|---|---|---|---|
| M1 | response routed to the wrong master | yes | `no result` |
| M2 | slave accepts a 2nd transaction before responding | yes | `[85000] %Error: sfb_protocol_checker.sv:124: Assertion failed in TOP.tb_sfb_xbar.g_chk_s[0].u_chk_s: [slave] R6: more than 1 transactions outstanding` |
| M3 | no grant lock: slave-side payload changes under back-pressure | yes | `[725000] %Error: sfb_protocol_checker.sv:90: Assertion failed in TOP.tb_sfb_xbar.g_chk_s[0].u_chk_s: [slave] R2: request payload changed before acceptance` |
| M4 | write strobes taken from master 0 | yes | `TB_SFB ERROR m2 request 100100d4 not forwarded intact to slave 1 cyc=2` |
| M5 | decode error reported as OKAY | yes | `TB_SFB ERROR m2 rsp data=00000000 err=0 expected data=00000000 err=1 cyc=11` |
| M6 | access matrix ignored | yes | `TB_SFB ERROR m2 watchdog (starvation/deadlock) cyc=20000` |
| M7 | round-robin pointer never advances (starvation) | yes | `TB_SFB ERROR m1 RR fairness bound exceeded (16 cycles)` |
| M8 | owner not recorded at acceptance | yes | `TB_SFB ERROR m1 watchdog (starvation/deadlock) cyc=20000` |
| M9 | master may have two transactions outstanding | yes | `[145000] %Error: sfb_protocol_checker.sv:124: Assertion failed in TOP.tb_sfb_xbar.g_chk_m[2].u_chk: [master] R6: more than 1 transactions outstanding` |
| M10 | response back-pressure ignored (response lost) | yes | `[165000] %Error: sfb_protocol_checker.sv:97: Assertion failed in TOP.tb_sfb_xbar.g_chk_m[1].u_chk: [master] R4: rsp_valid dropped before acceptance` |
| M11 | misaligned address not rejected | yes | `TB_SFB ERROR conservation: 2 slave accepts vs 1 mapped master accepts cyc=54` |
| M12 | skid buffer loses the parked beat | yes | `TB_SLICE ERROR rsp 00000000/0 expected 1d1d1d1d/0 cyc=20` |
