# Synthesis results (technology independent)

Yosys 0.33 (git sha1 2584903a060); `abc -g cmos2` (NAND/NOR/NOT); transistors from `stat -tech cmos`; NAND2-eq = transistors/4; depth = `ltp -noff` gate levels (logic-depth proxy, **not** timing); memories kept as macros (bits).  No PDK/Liberty was available: no node-specific area, timing or power is claimed.

| config | description | cells | flops | NAND2-eq | transistors | logic depth | pre-map MUX | latches | mem bits |
|---|---|---|---|---|---|---|---|---|---|
| dma_buf_f16_b16 | buffered DMA, FIFO 16, burst 16 | 10940 | 1218 | 9040 | 36158 | 81 | 1716 | 0 | 0 |
| dma_buf_f2_b2 | buffered DMA, FIFO 2, burst 2 | 9100 | 764 | 7664 | 30658 | 81 | 1253 | 0 | 0 |
| dma_buf_f4_b4 | buffered DMA, FIFO 4, burst 4 | 9374 | 830 | 7838 | 31350 | 81 | 1322 | 0 | 0 |
| dma_buf_f8_b8 | buffered DMA, FIFO 8, burst 8 | 9945 | 960 | 8243 | 32972 | 81 | 1455 | 0 | 0 |
| dma_buf_f8_b8_d64 | buffered DMA, FIFO 8, 64-bit | 10985 | 1219 | 8960 | 35840 | 81 | 1737 | 0 | 0 |
| dma_buf_f8_dual | buffered DMA, FIFO 8, dual port | 9602 | 962 | 7926 | 31702 | 81 | 1208 | 0 | 0 |
| dma_simple_d128 | simple DMA, 128-bit | 4471 | 545 | 3684 | 14738 | 81 | 1363 | 0 | 0 |
| dma_simple_d32 | simple DMA, 32-bit (SilicaFlux-V default) | 4308 | 437 | 3638 | 14552 | 81 | 1303 | 0 | 0 |
| dma_simple_d32_noperf | simple DMA, 32-bit, no perf counters | 3500 | 341 | 2972 | 11890 | 81 | 1175 | 0 | 0 |
| dma_simple_d64 | simple DMA, 64-bit | 4341 | 473 | 3610 | 14442 | 81 | 1323 | 0 | 0 |
| sfv_xbar_3x7_baseline | SilicaFlux-V release-1 sfv_xbar 3x7, fixed priority (reference) | 5012 | 27 | 4646 | 18582 | 19 | 2448 | 0 | 0 |
| shared_m3_s7_d32_rr | shared bus 3x7, 32-bit, round robin | 2262 | 45 | 2050 | 8200 | 52 | 781 | 0 | 0 |
| shared_m4_s7_d32_rr | shared bus 4x7, 32-bit, round robin | 2397 | 48 | 2217 | 8868 | 51 | 827 | 0 | 0 |
| xbar_m1_s7_d32_fp | crossbar 1x7, 32-bit, fixed priority (= direct bus: one master) | 1475 | 30 | 1340 | 5360 | 21 | 606 | 0 | 0 |
| xbar_m2_s4_d32_rr | crossbar 2x4, 32-bit, round robin | 1785 | 28 | 1713 | 6852 | 22 | 692 | 0 | 0 |
| xbar_m2_s7_d32_rr | crossbar 2x7, 32-bit, round robin | 3110 | 46 | 2987 | 11948 | 24 | 1203 | 0 | 0 |
| xbar_m3_s4_d32_rr | crossbar 3x4, 32-bit, round robin | 3362 | 42 | 3114 | 12456 | 33 | 1070 | 0 | 0 |
| xbar_m3_s7_d32_fp | crossbar 3x7, 32-bit, fixed priority | 5288 | 55 | 4954 | 19816 | 28 | 1787 | 0 | 0 |
| xbar_m3_s7_d32_rr | crossbar 3x7, 32-bit, round robin | 6021 | 69 | 5632 | 22526 | 35 | 1871 | 0 | 0 |
| xbar_m4_s4_d32_rr | crossbar 4x4, 32-bit, round robin | 4362 | 48 | 4189 | 16756 | 32 | 1396 | 0 | 0 |
| xbar_m4_s7_d128_rr | crossbar 4x7, 128-bit, round robin | 20063 | 78 | 19765 | 79060 | 34 | 7536 | 0 | 0 |
| xbar_m4_s7_d32_fp | crossbar 4x7, 32-bit, fixed priority | 6748 | 64 | 6520 | 26078 | 28 | 2364 | 0 | 0 |
| xbar_m4_s7_d32_rr | crossbar 4x7, 32-bit, round robin | 7602 | 78 | 7340 | 29360 | 34 | 2448 | 0 | 0 |
| xbar_m4_s7_d64_rr | crossbar 4x7, 64-bit, round robin | 11837 | 78 | 11526 | 46104 | 35 | 4144 | 0 | 0 |
| xbar_m5_s4_d32_rr | crossbar 5x4, 32-bit, round robin | 5940 | 62 | 5560 | 22240 | 43 | 1829 | 0 | 0 |
| xbar_m5_s7_d32_rr | crossbar 5x7, 32-bit, round robin | 10565 | 101 | 9928 | 39714 | 46 | 3210 | 0 | 0 |
| xbarreg_m3_s7_d32_rr | registered crossbar 3x7 (sfb_reg_slice on every slave port) | 9750 | 1525 | 7812 | 31248 | 35 | 2627 | 0 | 0 |
| xbarreg_m4_s7_d32_rr | registered crossbar 4x7 (sfb_reg_slice on every slave port) | 10926 | 1534 | 9136 | 36546 | 34 | 3204 | 0 | 0 |
| perf_counters_m4 | DFPERF counters, 4 masters (optional) | 9742 | 1873 | 7020 | 28082 | 67 | 2907 | 0 | 0 |
| reg_slice_d32 | register slice, req+rsp, 32-bit | 534 | 208 | 322 | 1288 | 4 | 108 | 0 | 0 |
| v1_slave_adapter | legacy-slave adapter (x7 in sfv_soc_df) | 143 | 34 | 107 | 428 | 3 | 34 | 0 | 0 |
| soc_sfv_baseline | SilicaFlux-V release-1 core SoC (sfv_xbar) | 97345 | 2776 | 90924 | 363696 | 87 | 12624 | 0 | 1179648 |
| soc_sfv_df_default | SilicaFlux-V + DataFabric (simple DMA, RR, PERF=1) | 132975 | 5130 | 121673 | 486692 | 94 | 19571 | 0 | 1179648 |
| soc_sfv_df_noperf | SilicaFlux-V + DataFabric (simple DMA, RR, PERF=0) | 122307 | 3429 | 113642 | 454570 | 95 | 16919 | 0 | 1179648 |
