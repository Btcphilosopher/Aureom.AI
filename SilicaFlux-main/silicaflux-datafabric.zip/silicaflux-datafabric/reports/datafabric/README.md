# reports/datafabric — tool output of this release

Every file is written by a script in `scripts/datafabric/`, `formal/datafabric/` or
`python/datafabric/`; the JSON files contain the exact commands, parameters, seeds
and exit codes. `SUMMARY.md` collates them with tool versions and source hashes.

| File | Produced by | Content |
|---|---|---|
| `SUMMARY.md` | `make datafabric-report` | pass counts, tool versions, source-tree hashes |
| `lint.{md,json}` | `make datafabric-lint` | Verilator -Wall, Yosys elaboration/latch rule, memory-map freshness + SilicaFlux-V cross-check |
| `unit_regression.{md,json}` | `make datafabric-unit` | tb_dma matrix, register slice, SRAM-library slaves, cocotb (v1 compat + Python reference model), pytest |
| `xbar_regression.{md,json}` | `make datafabric-xbar` | crossbar / shared-bus parameter matrix incl. resets, contention, withdrawal, long run |
| `xbar_mutants.{md,json}` | `make datafabric-mutants` | mutation campaign (testbench strength) |
| `soc_regression.{md,json}`, `soc_logs/` | `make datafabric-soc` | SilicaFlux-V + DataFabric firmware scenarios, UART transcripts |
| `formal.{md,json}` | `make datafabric-formal` | BMC / PDR results and non-vacuity checks |
| `gls.{md,json}` | `make datafabric-gls` | gate-level simulation of synthesized netlists |
| `synth.{md,json}` | `make datafabric-synth` | Yosys generic-gate area / flops / logic depth per configuration |
| `benchmark.{md,json}` | `make datafabric-benchmark` | measured RTL DMA throughput sweep + arbitration fairness |
| `memorylab_comparison.{md,json}` | `python/datafabric/memorylab_adapter.py` | MemoryLab analysis of measured traces; model vs RTL |
| `traces/` | testbenches (`+trace=`) | transaction traces (CSV) + MemoryLab canonical copies; SoC traces are windows of the DMA-demo phase D8 |
