# Unit regression

**56/56 PASS**

| suite | config | args | result |
|---|---|---|---|
| tb_dma | dma_e0_p0_d32_a1_l13 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d32_a1_l13 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d32_a1_l13 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d64_a1_l13 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d64_a1_l13 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d64_a1_l13 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d128_a0_l12 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d128_a0_l12 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d128_a0_l12 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d32_a1_l13 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d32_a1_l13 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d32_a1_l13 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p1_d32_a1_l13 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p1_d32_a1_l13 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p1_d32_a1_l13 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d64_a0_l24 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d64_a0_l24 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d64_a0_l24 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d32_a0_l36 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d32_a0_l36 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e0_p0_d32_a0_l36 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d32_a1_l11 | +seed=1 +bp=20 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d32_a1_l11 | +seed=2 +bp=0 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_dma | dma_e1_p0_d32_a1_l11 | +seed=3 +bp=40 +ntrans=80 | PASS: TB_DMA RESULT PASS protocol_violations=0 |
| tb_sfb_reg_slice | slice_q1_s1_d32 | +seed=1 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=32 transfers=16791 checked=16791 throughput=1.000000 |
| tb_sfb_reg_slice | slice_q1_s1_d32 | +seed=2 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=32 transfers=16820 checked=16820 throughput=0.999900 |
| tb_sfb_reg_slice | slice_q1_s1_d32 | +seed=3 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=32 transfers=16825 checked=16825 throughput=1.000000 |
| tb_sfb_reg_slice | slice_q1_s0_d32 | +seed=1 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=0 DW=32 transfers=16774 checked=16774 throughput=0.999900 |
| tb_sfb_reg_slice | slice_q1_s0_d32 | +seed=2 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=0 DW=32 transfers=16769 checked=16769 throughput=0.999900 |
| tb_sfb_reg_slice | slice_q1_s0_d32 | +seed=3 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=0 DW=32 transfers=16743 checked=16743 throughput=0.999900 |
| tb_sfb_reg_slice | slice_q0_s1_d32 | +seed=1 | PASS: TB_SLICE RESULT PASS REQ_SLICE=0 RSP_SLICE=1 DW=32 transfers=16680 checked=16680 throughput=0.999800 |
| tb_sfb_reg_slice | slice_q0_s1_d32 | +seed=2 | PASS: TB_SLICE RESULT PASS REQ_SLICE=0 RSP_SLICE=1 DW=32 transfers=16674 checked=16674 throughput=1.000000 |
| tb_sfb_reg_slice | slice_q0_s1_d32 | +seed=3 | PASS: TB_SLICE RESULT PASS REQ_SLICE=0 RSP_SLICE=1 DW=32 transfers=16629 checked=16629 throughput=1.000000 |
| tb_sfb_reg_slice | slice_q1_s1_d64 | +seed=1 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=64 transfers=16743 checked=16743 throughput=0.999900 |
| tb_sfb_reg_slice | slice_q1_s1_d64 | +seed=2 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=64 transfers=16805 checked=16805 throughput=0.999900 |
| tb_sfb_reg_slice | slice_q1_s1_d64 | +seed=3 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=64 transfers=16837 checked=16837 throughput=0.999900 |
| tb_sfb_reg_slice | slice_q1_s1_d128 | +seed=1 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=128 transfers=16822 checked=16822 throughput=1.000000 |
| tb_sfb_reg_slice | slice_q1_s1_d128 | +seed=2 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=128 transfers=16817 checked=16817 throughput=1.000000 |
| tb_sfb_reg_slice | slice_q1_s1_d128 | +seed=3 | PASS: TB_SLICE RESULT PASS REQ_SLICE=1 RSP_SLICE=1 DW=128 transfers=16757 checked=16757 throughput=0.999900 |
| tb_sfb_xbar | xsram_s1_l1_d32 | +seed=1 +cycles=20000 | PASS: TB_SFB RESULT PASS slave_accepts=23740 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s1_l1_d32 | +seed=2 +cycles=20000 +resets=2 | PASS: TB_SFB RESULT PASS slave_accepts=23807 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=2 withdrawn=0 |
| tb_sfb_xbar | xsram_s1_l2_d32 | +seed=1 +cycles=20000 | PASS: TB_SFB RESULT PASS slave_accepts=15401 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s1_l2_d32 | +seed=2 +cycles=20000 +resets=2 | PASS: TB_SFB RESULT PASS slave_accepts=15624 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s1_l3_d32 | +seed=1 +cycles=20000 | PASS: TB_SFB RESULT PASS slave_accepts=11360 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s1_l3_d32 | +seed=2 +cycles=20000 +resets=2 | PASS: TB_SFB RESULT PASS slave_accepts=11350 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s2_l1_d32 | +seed=1 +cycles=20000 | PASS: TB_SFB RESULT PASS slave_accepts=23740 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s2_l1_d32 | +seed=2 +cycles=20000 +resets=2 | PASS: TB_SFB RESULT PASS slave_accepts=23807 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=2 withdrawn=0 |
| tb_sfb_xbar | xsram_s2_l2_d64 | +seed=1 +cycles=20000 | PASS: TB_SFB RESULT PASS slave_accepts=16534 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s2_l2_d64 | +seed=2 +cycles=20000 +resets=2 | PASS: TB_SFB RESULT PASS slave_accepts=16595 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=1 withdrawn=0 |
| tb_sfb_xbar | xsram_s2_l3_d32 | +seed=1 +cycles=20000 | PASS: TB_SFB RESULT PASS slave_accepts=12546 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| tb_sfb_xbar | xsram_s2_l3_d32 | +seed=2 +cycles=20000 +resets=2 | PASS: TB_SFB RESULT PASS slave_accepts=12531 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=1 withdrawn=0 |
| cocotb | v1compat_fixed_priority |  | PASS: TESTS=1 PASS=1 FAIL=0 SKIP=0              64480.00           2.02      31956.22 |
| cocotb | v1compat_round_robin | COMPAT_RR=1 | PASS: TESTS=1 PASS=1 FAIL=0 SKIP=0              64910.00           2.30      28187.10 |
| cocotb | dma_python_refmodel_simple | ENGINE=0 | PASS: TESTS=3 PASS=3 FAIL=0 SKIP=0                          173500.00           2.42      71566.89 |
| cocotb | dma_python_refmodel_buffered | ENGINE=1 | PASS: TESTS=3 PASS=3 FAIL=0 SKIP=0                          117630.00           1.95      60414.43 |
| pytest | memmap_gen |  | PASS: 20 passed in 0.48s |
