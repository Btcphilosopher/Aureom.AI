# SoC synthesis with module boundaries kept (attribution)

Baseline sfv_soc: **107990** NAND2-eq; sfv_soc_df (PERF=1): **125516** NAND2-eq; difference **17526** (16.2 %).  Logic only (SRAM/ROM arrays are macros); generic gates; ICG replaced by its FPGA model (SFV_NO_CLOCK_GATE).

| module | instances | NAND2-eq each | NAND2-eq total |
|---|---|---|---|
| sfb_crossbar | 1 | 618 | 618 |
| sfb_rsp_router | 1 | 2770 | 2770 |
| sfb_req_mux | 7 | 517 | 3619 |
| sfb_arbiter | 7 | 101 | 707 |
| sfb_addr_decoder | 4 | 80 | 320 |
| sfb_error_slave | 4 | 3 | 12 |
| sfb_v1_slave_adapter | 7 | 107 | 749 |
| silicaflux_dma | 1 | 0 | 0 |
| dma_control_regs | 1 | 1106 | 1106 |
| dma_irq | 1 | 10 | 10 |
| dma_transfer_engine | 1 | 1290 | 1290 |
| dma_validate | 1 | 1220 | 1220 |
| sfb_perf_counters | 1 | 7006 | 7006 |
| *removed:* sfv_xbar | 1 | 1817 | -1817 |
| sfv_periph_bridge (baseline -> DataFabric) | 1 | 1408 -> 972 | -436 |
| sfv_intc (baseline -> DataFabric) | 1 | 92 -> 102 | 10 |

Sum of the DataFabric modules listed: 19427 NAND2-eq (of which sfb_perf_counters 7006).
