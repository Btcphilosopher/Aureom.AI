# DataFabric x MemoryLab

MemoryLab imported from MEMORYLAB_PY=.../silicaflux-memorylab/python.

## 1. Measured RTL traces analysed by MemoryLab's own `trace_import.trace_metrics` (and DataFabric bandwidth_analysis)

| trace | events | MemoryLab: span / accepted / words per cycle / avg / p95 / max latency / problems | DMA (or master 0) B/cycle, avg arb delay, conflicts |
|---|---|---|---|
| `buffered__dma_demo_buffered_engine__D8_window.csv` | 57714 | 10877 / 19068 / 1.7531 / 1.0 / 1.0 / 1.0 / [] | 3.0126, 0.062, 510 |
| `default__dma_demo_sram_boot__D8_window.csv` | 82271 | 18552 / 26744 / 1.4416 / 1.0 / 1.0 / 1.0 / [] | 1.7663, 0.249, 2040 |
| `tb_dma__buf_f8_b8__contention.csv` | 50015 | 9269 / 13653 / 1.473 / 1.0 / 1.0 / 1.0 / [] | 1.7676, 1.0, 4098 |
| `tb_dma__buf_f8_b8_d64__contention.csv` | 24641 | 4555 / 6796 / 1.492 / 1.0 / 1.0 / 1.0 / [] | 3.5969, 0.949, 1944 |
| `tb_dma__simple_d32__contention.csv` | 49605 | 9814 / 14237 / 1.4507 / 1.0 / 1.0 / 1.0 / [] | 1.6695, 0.383, 1569 |

## 2. 4 KiB SRAM->SRAM DMA copy: MEASURED RTL vs MemoryLab event-model PREDICTION

| config | measured RTL cycles (same slave) | measured B/cycle | MemoryLab predicted cycles | predicted B/cycle | measured / predicted | measured RTL cycles (two slaves) |
|---|---|---|---|---|---|---|
| simple_d32 | 4100 | 0.999024 | 3077 | 1.3312 | 1.332 | 4100 |
| simple_d64 | 2052 | 1.996101 | 1541 | 2.658 | 1.332 | 2052 |
| simple_d128 | 1028 | 3.984436 | 773 | 5.2988 | 1.33 | 1028 |
| buf_f8_b8 | 2563 | 1.598127 | 1550 | 2.6426 | 1.654 | 2563 |
| buf_f16_b16 | 2307 | 1.775466 | 1558 | 2.629 | 1.481 | 2307 |
| buf_f8_dual | 2053 | 1.995129 | 1550 | 2.6426 | 1.325 | 1031 |
| buf_f8_b8_d64 | 1283 | 3.192518 | 782 | 5.2379 | 1.641 | 1283 |

Why the model and the RTL differ (structural assumptions, not tuning):

- MemoryLab's Dma model always decouples reads and writes through a data FIFO and lets them overlap; the DataFabric simple engine is strictly read-then-write per beat (one data register), so the model is optimistic for it by construction.
- MemoryLab's interconnect gives reads and writes independent progress; the single-port buffered engine shares one SFB2 port and alternates READ/WRITE phases, so only the dual-port configuration matches the model's structure.
- Measured cycles include the start-register write and ~2-cycle STATUS polling; the model reports submit-to-last-write-ack (setup = 4 cycles as in MemoryLab's DMA_DEFAULTS).
- The model's 'spm2spm' copies inside one 4-bank SRAM, so it is compared with the measured same-slave copy (one crossbar slave port serves both reads and writes); the two-slave copy is listed separately.
