# Gate-level simulation (Yosys generic netlist + simcells.v, Verilator)

**5/5 PASS**

| DUT | args | result |
|---|---|---|
| xbar_3x3_rr | +seed=1 +cycles=20000 | TB_SFB RESULT PASS slave_accepts=13556 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| xbar_3x3_rr | +seed=2 +cycles=20000 +resets=3 | TB_SFB RESULT PASS slave_accepts=13532 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=1 withdrawn=0 |
| xbar_3x3_rr | +seed=3 +cycles=20000 +mode=1 | TB_SFB RESULT PASS slave_accepts=6669 protocol_violations=0 starvation_events=0 cancelled_writes_resolved=0 withdrawn=0 |
| dma_simple | +seed=1 +ntrans=30 | TB_DMA RESULT PASS protocol_violations=0 |
| dma_buffered | +seed=1 +ntrans=30 | TB_DMA RESULT PASS protocol_violations=0 |
