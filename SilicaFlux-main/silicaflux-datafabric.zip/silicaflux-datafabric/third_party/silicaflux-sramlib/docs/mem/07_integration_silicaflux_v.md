# 07 — Integration with SilicaFlux / SilicaFlux-V

## 1. Placement and build

Unpack the zip at `SilicaFlux-main/silicaflux-sramlib/` (next to `silicaflux-memoryflow`, `silicaflux-testcore`).
Compile lists:

```
+incdir+rtl/mem +incdir+rtl/mem/backends/asic
rtl/mem/backends/generic/*.sv rtl/mem/backends/fpga/*.sv
rtl/mem/backends/asic/sram_asic_array.sv rtl/mem/backends/asic/sram_leaf_*.sv
rtl/mem/sram_*.sv
# plus, for lint/synthesis with BACKEND=ASIC: rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv
# plus, for ASIC simulation: the vendor models (scripts/mem/fetch_open_macros.sh)
```

Yosys: read with `read_verilog -defer -sv -DSYNTHESIS …` then `hierarchy -top <top> -chparam …` (some modules
deliberately `$fatal` with their default parameters).  Verilator: macro stubs must be on the file list even for
GENERIC (it resolves module names in unused generate branches).

## 2. Done here: SilicaFlux 2.5 `memory_controller.sf`

`integration/silicaflux25/memory_controller_sramlib.sf` (+ `memory_controller.sf.patch`, a unified diff against
`SilicaFlux-main/memory_controller.sf`) replaces the inline per-bank arrays (`mem_q`, `par_mem_q` and their read
pipelines) by `sram_backend_1rw` instances — data 128 b × `BANK_DEPTH` with 16 byte lanes, parity 16 b with 16
one-bit lanes — and adds three parameters with backward-compatible defaults:

| Parameter | Default | Meaning |
|---|---|---|
| `SRAM_BACKEND` | 0 (GENERIC) | 0 GENERIC, 1 FPGA, 2 ASIC |
| `SRAM_MACRO` | 0 | data-array macro (ASIC) |
| `SRAM_PARITY_MACRO` | 0 | parity-array macro (ASIC with `PARITY_EN`) |

Nothing else in the controller changes: arbitration, credits, the `INIT_ON_RESET` sweep (already port-based, so
macro-compatible), flush/kill and the parity exception path.  The raw-backend contract (data valid exactly
`SRAM_LATENCY` after the read, not held) matches how the controller consumes `bank_rdata` — confirmed by running
with output poisoning.

**Result** (`make mem-integration`, `reports/mem/integration.md`): MemoryFlow's existing characterisation
testbench `tb_sf25_memctrl.sv` passes on the unmodified controller, on the GENERIC-backed variant and on the
FPGA-backed variant with the **same 150,843 checks and all 36 functional / throughput metrics identical**.  The only
testbench edit is the hierarchical path its parity-corruption phase uses to flip a stored bit.

ASIC mapping of this controller (example): data banks 128 b × 512 → `SRAM_MACRO = SRAM_MACRO_IHP_1P_512X64`
(2 columns per bank); parity 16 b × 512 → `SRAM_MACRO_IHP_1P_512X16`.  Use `sram_analysis.py plan` to evaluate
any choice.  On SKY130 the 16 one-bit parity lanes are not representable with byte masks — the elaboration check
rejects it; store parity in a bit-mask macro or widen the data word with ECC (next actions).

## 3. To do for other blocks

| Block | Recommendation |
|---|---|
| Gen-1 `fetch_unit` IMEM (1024 × 32, write port + sync read) | replace by `sram_1r1w` (or `sram_backend_1r1w`), `READ_LATENCY 1`; the loader writes through `wr_*` |
| Gen-1 tile `memory_controller` (multi-port flop array) | cannot map to a macro as written; re-implement on `sram_sp`/`sram_bank_controller` (4-word vector access → 4 interleaved banks or a 128-bit word) |
| Gen-2.5 `compute_tile.sf` SPM windows (16 KiB scalar + 64 KiB vector) | `compute_tile.sf` does not elaborate in the repository (interface drift); when repaired, point its scratchpad at the patched `memory_controller` |
| SilicaFlux-V (documented: 16 KiB I + 16 KiB D L1, 256 KiB L2/scratch, or 64-128 KiB unified) | presets in `rtl/mem/sram_presets.svh`; a DMA-managed scratchpad maps directly onto `sram_bank_controller` (CPU, vector, tensor, DMA as masters); caches can use `sram_sp` for data and tag arrays |
| MBIST | connect each memory's test port with `sram_mbist_adapter` to TestCore `tc_mbist` (registry: width, depth-1, latency = `READ_LATENCY` + adapter pipes, type 0 for 1RW / 1 for 1R1W) |

## 4. Example subsystem

`rtl/mem/examples/sfv_memory_subsystem_example.sv` wires the presets together the way a SilicaFlux-V memory
subsystem would: a control SRAM and a CPU SRAM (`sram_sp`, no-backpressure mode), a 32 KiB byte-addressed
scratchpad (`sram_bank_controller`, 4 masters — CPU, vector, tensor, DMA — × 4 banks × 128 b) and one
`sram_mbist_march` testing all six memories through `sram_mbist_adapter`s and the bank controller's `tst_sel`.  A
single `BACKEND` and one macro per memory class (`MACRO_CTRL`, `MACRO_CPU`, `MACRO_SPM`) retarget it.  Evidence:
`-Wall` lint clean (GENERIC and IHP) and Yosys synthesis with IHP SG13G2 macros keeps exactly 1 + 2 + 8 macro
instances of the three selected types and no flip-flop memory (`reports/mem/synth.md`).  It is a structural
template: its building blocks are verified individually; the example top itself has no dedicated testbench.

## 5. Software-visible behaviour

The patched controller is cycle- and data-identical to the original for every testbench transaction.  The library
itself adds no software-visible state.  Systems built on `sram_bank_controller` see word- or byte-addressed memory
with error responses for misaligned/out-of-range accesses and no coherence (scratchpad semantics).
