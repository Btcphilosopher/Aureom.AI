# Third-party (SilicaFlux in-repo) sources -- vendored UNMODIFIED

Origin archives in btcphilosopher/Aureom.AI (branch snapshot of this work):
- silicaflux-v/       <- SilicaFlux-main/silicaflux-v-release1.zip (sha256 424816e9eaedee999a711617ceb2f517d55684301f7dc260c24f73af9c045b16)
- silicaflux-sramlib/ <- SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip (sha256 13b1cee1f913d7b5821f338ce0d12a038e02a1062538c66e4917cae2599beb16)

Only a subset of each archive is copied (RTL, firmware, the testbench/tests reused here, key docs).
Every file is byte-identical to the archive member; verify with `sha256sum -c SHA256SUMS`.
