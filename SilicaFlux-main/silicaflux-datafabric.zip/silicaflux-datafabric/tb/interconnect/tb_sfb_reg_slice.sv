// =============================================================================
// SilicaFlux DataFabric :: tb_sfb_reg_slice -- register slice / skid buffer test
//
// A streaming master with up to MAXO transactions in flight drives
// sfb_reg_slice (REQ_SLICE/RSP_SLICE) into a pipelined memory slave (response
// queue depth 8, random req_ready, random latency).  The master applies random
// rsp_ready back-pressure.  Both skid-buffer entries are therefore exercised
// on both channels.  Checks: protocol on both sides (MAX_OUT = 16), every
// response in order with the predicted data (shadow memory updated in
// acceptance order), no loss / duplication (counts), final memory equality,
// and full throughput (>= 0.95 transfers/cycle in the +bp=0 phase).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sfb_reg_slice #(
  parameter int DW        = 32,
  parameter int REQ_SLICE = 1,
  parameter int RSP_SLICE = 1
);
  localparam int AW = 32, SB = DW / 8, WORDS = 32, MAXO = 12, QD = 8;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic          u_req_valid, u_req_ready, u_req_write, u_rsp_valid, u_rsp_ready, u_rsp_error;
  logic [AW-1:0] u_req_addr;
  logic [DW-1:0] u_req_wdata, u_rsp_rdata;
  logic [SB-1:0] u_req_wstrb;
  logic          d_req_valid, d_req_ready, d_req_write, d_rsp_valid, d_rsp_ready, d_rsp_error;
  logic [AW-1:0] d_req_addr;
  logic [DW-1:0] d_req_wdata, d_rsp_rdata;
  logic [SB-1:0] d_req_wstrb;

  sfb_reg_slice #(.AW(AW), .DW(DW), .REQ_SLICE(REQ_SLICE), .RSP_SLICE(RSP_SLICE)) dut (
    .clk, .rst_n,
    .s_req_valid(u_req_valid), .s_req_ready(u_req_ready), .s_req_write(u_req_write),
    .s_req_addr(u_req_addr), .s_req_wdata(u_req_wdata), .s_req_wstrb(u_req_wstrb),
    .s_rsp_valid(u_rsp_valid), .s_rsp_ready(u_rsp_ready), .s_rsp_rdata(u_rsp_rdata),
    .s_rsp_error(u_rsp_error),
    .m_req_valid(d_req_valid), .m_req_ready(d_req_ready), .m_req_write(d_req_write),
    .m_req_addr(d_req_addr), .m_req_wdata(d_req_wdata), .m_req_wstrb(d_req_wstrb),
    .m_rsp_valid(d_rsp_valid), .m_rsp_ready(d_rsp_ready), .m_rsp_rdata(d_rsp_rdata),
    .m_rsp_error(d_rsp_error)
  );

  logic [31:0] vu, vd, nqu, npu, nou, nqd, npd, nod;
  sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(16), .NAME("upstream")) u_cu (
    .clk, .rst_n, .req_valid(u_req_valid), .req_ready(u_req_ready), .req_write(u_req_write),
    .req_addr(u_req_addr), .req_wdata(u_req_wdata), .req_wstrb(u_req_wstrb),
    .rsp_valid(u_rsp_valid), .rsp_ready(u_rsp_ready), .rsp_rdata(u_rsp_rdata), .rsp_error(u_rsp_error),
    .violations(vu), .n_req(nqu), .n_rsp(npu), .outstanding(nou));
  sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(16), .NAME("downstream")) u_cd (
    .clk, .rst_n, .req_valid(d_req_valid), .req_ready(d_req_ready), .req_write(d_req_write),
    .req_addr(d_req_addr), .req_wdata(d_req_wdata), .req_wstrb(d_req_wstrb),
    .rsp_valid(d_rsp_valid), .rsp_ready(d_rsp_ready), .rsp_rdata(d_rsp_rdata), .rsp_error(d_rsp_error),
    .violations(vd), .n_req(nqd), .n_rsp(npd), .outstanding(nod));

  function automatic int unsigned xsn(input int unsigned r);
    int unsigned t;
    t = r ^ (r << 13); t = t ^ (t >> 17); t = t ^ (t << 5);
    xsn = t;
  endfunction
  function automatic logic [DW-1:0] merge(input logic [DW-1:0] o, input logic [DW-1:0] n,
                                          input logic [SB-1:0] st);
    for (int b = 0; b < SB; b++) merge[b*8 +: 8] = st[b] ? n[b*8 +: 8] : o[b*8 +: 8];
  endfunction

  int unsigned seed, ncyc, bp, cyc, errors, n_ok;
  logic [DW-1:0] shadow [0:WORDS-1];
  logic [DW-1:0] mem    [0:WORDS-1];

  // ---------------------------------------------------------------- master
  logic [DW-1:0] ex_d [0:MAXO-1];
  logic          ex_e [0:MAXO-1];
  int unsigned   ex_rd, ex_wr, ex_n, mrng;
  always_ff @(posedge clk or negedge rst_n) begin
    int unsigned n, w;
    if (!rst_n) begin
      u_req_valid <= 1'b0; u_rsp_ready <= 1'b0; ex_rd <= 0; ex_wr <= 0; ex_n <= 0;
      u_req_write <= 1'b0; u_req_addr <= '0; u_req_wdata <= '0; u_req_wstrb <= '0;
    end else begin
      n = ex_n;
      mrng = xsn(mrng);
      u_rsp_ready <= (mrng % 100) >= bp;
      if (u_rsp_valid && u_rsp_ready) begin
        if (u_rsp_error !== ex_e[ex_rd] || (!ex_e[ex_rd] && u_rsp_rdata !== ex_d[ex_rd])) begin
          errors <= errors + 1;
          $display("TB_SLICE ERROR rsp %h/%0d expected %h/%0d cyc=%0d", u_rsp_rdata, u_rsp_error,
                   ex_d[ex_rd], ex_e[ex_rd], cyc);
        end else n_ok <= n_ok + 1;
        ex_rd <= (ex_rd + 1) % MAXO;
        n = n - 1;
      end
      if (u_req_valid && u_req_ready) begin
        w = int'(u_req_addr[$clog2(WORDS*SB)-1:$clog2(SB)]);
        ex_e[ex_wr] <= (w == WORDS - 1);
        if (u_req_write) begin
          ex_d[ex_wr] <= '0;
          if (w != WORDS - 1) shadow[w] <= merge(shadow[w], u_req_wdata, u_req_wstrb);
        end else ex_d[ex_wr] <= (w == WORDS - 1) ? '0 : shadow[w];
        ex_wr <= (ex_wr + 1) % MAXO;
        n = n + 1;
      end
      ex_n <= n;
      // next request (held stable until accepted)
      if (!u_req_valid || u_req_ready) begin
        mrng = xsn(mrng);
        if (n < MAXO - 1 && (bp == 0 || (mrng % 100) >= 10) && cyc < ncyc) begin
          u_req_valid <= 1'b1;
          mrng = xsn(mrng); u_req_write <= mrng[0];
          mrng = xsn(mrng); u_req_addr  <= AW'((mrng % WORDS) * SB);
          for (int k = 0; k < DW / 32; k++) begin mrng = xsn(mrng); u_req_wdata[k*32 +: 32] <= mrng; end
          mrng = xsn(mrng); u_req_wstrb <= (mrng % 2) ? '1 : SB'(mrng >> 8);
        end else u_req_valid <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------------- pipelined slave
  logic [DW-1:0] q_d [0:QD-1];
  logic          q_e [0:QD-1];
  int unsigned   q_due [0:QD-1];
  int unsigned   q_n, q_rd, q_wr, srng, scyc;
  logic          s_rdy;
  assign d_req_ready = s_rdy && (q_n < QD);
  assign d_rsp_valid = (q_n != 0) && (scyc >= q_due[q_rd]);
  assign d_rsp_rdata = d_rsp_valid ? q_d[q_rd] : '0;
  assign d_rsp_error = d_rsp_valid && q_e[q_rd];
  always_ff @(posedge clk or negedge rst_n) begin
    int unsigned n, w, due;
    if (!rst_n) begin
      q_n <= 0; q_rd <= 0; q_wr <= 0; s_rdy <= 1'b0; scyc <= 0;
    end else begin
      scyc <= scyc + 1;
      srng = xsn(srng);
      s_rdy <= (bp == 0) ? 1'b1 : ((srng % 4) != 0);
      n = q_n;
      if (d_rsp_valid && d_rsp_ready) begin q_rd <= (q_rd + 1) % QD; n = n - 1; end
      if (d_req_valid && d_req_ready) begin
        w = int'(d_req_addr[$clog2(WORDS*SB)-1:$clog2(SB)]);
        srng = xsn(srng);
        due = scyc + ((bp == 0) ? 1 : (1 + srng % 3));
        if (q_n != 0 && q_due[(q_wr + QD - 1) % QD] > due) due = q_due[(q_wr + QD - 1) % QD];
        q_due[q_wr] <= due;
        q_e[q_wr]   <= (w == WORDS - 1);
        q_d[q_wr]   <= (d_req_write || w == WORDS - 1) ? '0 : mem[w];
        if (d_req_write && w != WORDS - 1) mem[w] <= merge(mem[w], d_req_wdata, d_req_wstrb);
        q_wr <= (q_wr + 1) % QD;
        n = n + 1;
      end
      q_n <= n;
    end
  end

  // ---------------------------------------------------------------- main
  initial begin
    int unsigned acc0, c0;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("cycles=%d", ncyc)) ncyc = 20000;
    errors = 0; n_ok = 0;
    mrng = seed * 32'h9E37_79B9 + 1; srng = seed * 32'h85EB_CA6B + 7;
    for (int w = 0; w < WORDS; w++) begin shadow[w] = DW'(w * 32'h0101_0101); mem[w] = shadow[w]; end
    repeat (3) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    // phase 1: random back-pressure on both sides
    bp = 30;
    for (cyc = 0; cyc < ncyc / 2; cyc++) @(posedge clk);
    // phase 2: no back-pressure -> throughput measurement
    bp = 0;
    acc0 = nqd; c0 = cyc;
    for (; cyc < ncyc; cyc++) @(posedge clk);
    begin
      real thr;
      thr = real'(nqd - acc0) / real'(cyc - c0);
      repeat (40) @(posedge clk);
      for (int w = 0; w < WORDS; w++)
        if (mem[w] !== shadow[w]) begin errors++; $display("TB_SLICE ERROR final mem w%0d", w); end
      if (nqu != nqd || npu != npd || nqu != npu) begin
        errors++; $display("TB_SLICE ERROR counts up %0d/%0d down %0d/%0d", nqu, npu, nqd, npd);
      end
      if (thr < 0.95) begin errors++; $display("TB_SLICE ERROR throughput %f < 0.95", thr); end
      if (errors == 0 && vu == 0 && vd == 0)
        $display("TB_SLICE RESULT PASS REQ_SLICE=%0d RSP_SLICE=%0d DW=%0d transfers=%0d checked=%0d throughput=%f",
                 REQ_SLICE, RSP_SLICE, DW, nqd, n_ok, thr);
      else begin
        $display("TB_SLICE RESULT FAIL errors=%0d violations=%0d/%0d", errors, vu, vd);
        $fatal(1, "tb_sfb_reg_slice failed");
      end
    end
    $finish;
  end
endmodule

`default_nettype wire
