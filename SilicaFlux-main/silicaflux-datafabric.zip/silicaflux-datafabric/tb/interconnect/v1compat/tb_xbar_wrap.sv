// [DataFabric v1-compat copy of silicaflux-v tb/unit/tb_xbar_wrap.sv: only the
//  crossbar instance is replaced; slave models and checks are unchanged]
// Crossbar unit-test wrapper: 3 masters (cocotb) x 3 memory slaves with
// randomised grant and response latency, plus protocol assertions.
// Map: S0 0x0000_0xxx  S1 0x1000_0xxx  S2 0x2000_0xxx (4 KiB each);
// master 2 may not access S2 (MST_SLV_EN) -> decode error.
`timescale 1ns/1ps
module tb_xbar_wrap (
  input  logic clk, rst_n,
  input  logic m0_req, m1_req, m2_req,
  output logic m0_gnt, m1_gnt, m2_gnt,
  input  logic [31:0] m0_addr, m1_addr, m2_addr,
  input  logic m0_we, m1_we, m2_we,
  input  logic [3:0] m0_be, m1_be, m2_be,
  input  logic [31:0] m0_wdata, m1_wdata, m2_wdata,
  output logic m0_rvalid, m1_rvalid, m2_rvalid,
  output logic [31:0] m0_rdata, m1_rdata, m2_rdata,
  output logic m0_err, m1_err, m2_err,
  output logic err_evt,
  output logic [31:0] err_addr,
  output logic [1:0] err_master,
  output logic protocol_error,
  input  logic [31:0] seed
);
  localparam int NM = 3, NS = 3;
  logic [NM-1:0] mreq, mgnt, mwe, mrv, merr;
  logic [NM*32-1:0] maddr, mwd, mrd;
  logic [NM*4-1:0] mbe;
  assign mreq = {m2_req, m1_req, m0_req};
  assign maddr = {m2_addr, m1_addr, m0_addr};
  assign mwe = {m2_we, m1_we, m0_we};
  assign mbe = {m2_be, m1_be, m0_be};
  assign mwd = {m2_wdata, m1_wdata, m0_wdata};
  assign {m2_gnt, m1_gnt, m0_gnt} = mgnt;
  assign {m2_rvalid, m1_rvalid, m0_rvalid} = mrv;
  assign {m2_err, m1_err, m0_err} = merr;
  assign {m2_rdata, m1_rdata, m0_rdata} = mrd;

  logic [NS-1:0] sreq, sgnt, swe, srv, serr;
  logic [NS*32-1:0] saddr, swd, srd;
  logic [NS*4-1:0] sbe;

  // ---- DataFabric: sfb_crossbar (SFB2) + sfb_v1_slave_adapter per legacy slave.
  // Legacy masters always accept responses -> rsp_ready tied high.  Fixed
  // priority (ARB_MODE=0) and CHECK_ALIGN=0 reproduce sfv_xbar exactly;
  // +define+COMPAT_RR selects round robin.
`ifdef COMPAT_RR
  localparam int ARB = 1;
`else
  localparam int ARB = 0;
`endif
  logic [NS-1:0]    a_req_valid, a_req_ready, a_req_write, a_rsp_valid, a_rsp_ready, a_rsp_error;
  logic [NS*32-1:0] a_req_addr, a_req_wdata, a_rsp_rdata;
  logic [NS*4-1:0]  a_req_wstrb;
  logic [NM-1:0]    ev0, ev1, ev2, ev3;
  sfb_crossbar #(.NM(NM), .NS(NS), .AW(32), .DW(32), .ARB_MODE(ARB), .CHECK_ALIGN(0),
    .SLV_BASE({32'h2000_0000, 32'h1000_0000, 32'h0000_0000}),
    .SLV_MASK({32'hFFFF_F000, 32'hFFFF_F000, 32'hFFFF_F000}),
    .MST_SLV_EN(9'b011_111_111)) u_dut (
    .clk, .rst_n,
    .m_req_valid(mreq), .m_req_ready(mgnt), .m_req_write(mwe), .m_req_addr(maddr),
    .m_req_wdata(mwd), .m_req_wstrb(mbe),
    .m_rsp_valid(mrv), .m_rsp_ready({NM{1'b1}}), .m_rsp_rdata(mrd), .m_rsp_error(merr),
    .s_req_valid(a_req_valid), .s_req_ready(a_req_ready), .s_req_write(a_req_write),
    .s_req_addr(a_req_addr), .s_req_wdata(a_req_wdata), .s_req_wstrb(a_req_wstrb),
    .s_rsp_valid(a_rsp_valid), .s_rsp_ready(a_rsp_ready), .s_rsp_rdata(a_rsp_rdata),
    .s_rsp_error(a_rsp_error),
    .err_evt, .err_addr, .err_master, .err_write(),
    .ev_req_accept(ev0), .ev_req_stall(ev1), .ev_arb_loss(ev2), .ev_rsp_stall(ev3));
  genvar ga;
  for (ga = 0; ga < NS; ga++) begin : g_adapt
    sfb_v1_slave_adapter u_ad (
      .clk, .rst_n,
      .req_valid(a_req_valid[ga]), .req_ready(a_req_ready[ga]), .req_write(a_req_write[ga]),
      .req_addr(a_req_addr[ga*32 +: 32]), .req_wdata(a_req_wdata[ga*32 +: 32]),
      .req_wstrb(a_req_wstrb[ga*4 +: 4]),
      .rsp_valid(a_rsp_valid[ga]), .rsp_ready(a_rsp_ready[ga]), .rsp_rdata(a_rsp_rdata[ga*32 +: 32]),
      .rsp_error(a_rsp_error[ga]),
      .v1_req(sreq[ga]), .v1_gnt(sgnt[ga]), .v1_addr(saddr[ga*32 +: 32]), .v1_we(swe[ga]),
      .v1_be(sbe[ga*4 +: 4]), .v1_wdata(swd[ga*32 +: 32]),
      .v1_rvalid(srv[ga]), .v1_rdata(srd[ga*32 +: 32]), .v1_err(serr[ga]));
  end

  // slave models: 1 KiW memory, random gnt (75%), latency 1..3; S1 returns an
  // error for word address 0x3FF (slave error path)
  logic [31:0] mem [0:NS-1][0:1023];
  int unsigned rng;
  logic [NS-1:0] pend;
  int cnt [0:NS-1];
  logic [31:0] pa [0:NS-1], pwd [0:NS-1];
  logic [3:0] pbe [0:NS-1];
  logic pwe [0:NS-1];
  initial rng = 1;
  function automatic int unsigned nxt();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    nxt = rng;
  endfunction
  logic [NS-1:0] gnt_r;
  always_ff @(posedge clk) begin
    if (!rst_n) rng <= (seed == 0) ? 1 : seed;
    for (int s = 0; s < NS; s++) gnt_r[s] <= (nxt() % 4) != 0;
  end
  assign sgnt = gnt_r;
  always_ff @(posedge clk) begin
    srv <= '0;
    if (!rst_n) begin
      pend <= '0;
    end else begin
      for (int s = 0; s < NS; s++) begin
        if (pend[s]) begin
          if (cnt[s] <= 1) begin
            srv[s] <= 1'b1;
            pend[s] <= 1'b0;
            srd[s*32 +: 32] <= (pwe[s] || (s == 1 && pa[s][11:2] == 10'h3FF)) ? 32'd0 : mem[s][pa[s][11:2]];
            serr[s] <= (s == 1) && (pa[s][11:2] == 10'h3FF);
            if (pwe[s]) for (int b = 0; b < 4; b++)
              if (pbe[s][b]) mem[s][pa[s][11:2]][b*8 +: 8] <= pwd[s][b*8 +: 8];
          end else cnt[s] <= cnt[s] - 1;
        end
        if (sreq[s] && sgnt[s]) begin
          pend[s] <= 1'b1; pa[s] <= saddr[s*32 +: 32]; pwe[s] <= swe[s];
          pbe[s] <= sbe[s*4 +: 4]; pwd[s] <= swd[s*32 +: 32]; cnt[s] <= nxt() % 3;
        end
      end
    end
  end

  // protocol assertions: a slave never gets a new request while it still owes
  // a response (unless the response is delivered in that cycle)
  always_ff @(posedge clk) begin
    if (!rst_n) protocol_error <= 1'b0;
    else for (int s = 0; s < NS; s++)
      if (sreq[s] && sgnt[s] && pend[s] && !(cnt[s] <= 1)) protocol_error <= 1'b1;
  end
endmodule
