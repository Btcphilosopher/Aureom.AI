// =============================================================================
// SilicaFlux DataFabric :: tb_sfb_xbar -- self-checking randomized testbench
//
// DUT: sfb_crossbar (NM x NS, DW, ARB) with optional register slices on the
// slave ports.  Environment (all seeded from +seed, xorshift32, tool-
// independent):
//   * NM random master BFMs: reads/writes with random strobes to SHARED words
//     (inter-master races are intended), unmapped / misaligned / access-
//     matrix-denied / slave-error addresses, random idle gaps, random
//     rsp_ready back-pressure, and "pipelined" requests presented while the
//     previous response is still pending (same-cycle accept+response path);
//   * NS slave models: random req_ready, latency LMIN..LMAX, response held
//     under back-pressure, error on the last word of each window;
//   * sfb_protocol_checker on every master and slave port.
// Independent scoreboards:
//   (1) request conservation: every master acceptance that the TB reference
//       decoder maps to slave s is matched, in the same cycle, by an identical
//       acceptance on slave port s, and #slave accepts == #mapped master
//       accepts (no loss, duplication or misrouting);
//   (2) response check: a shadow memory updated in acceptance order predicts
//       every read value and every error flag; each master compares its
//       in-order response against its own expectation;
//   (3) liveness: no master waits more than WATCHDOG cycles for acceptance or
//       a response; in MODE=contention with ARB=1 the wait of every master is
//       bounded by NM*(LMAX+2) cycles (round-robin fairness, measured).
// Optional asynchronous resets in the middle of traffic (+resets=K).
// Modes (+mode=): 0 random, 1 sustained contention (every master hammers
// slave 0, no gaps, slaves always ready, no response stall), 2 single active
// requester (only master 0 issues).
// Result line: "TB_SFB RESULT PASS|FAIL ..." ; exit code via $fatal on FAIL.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sfb_xbar #(
  parameter int NM        = 3,
  parameter int NS        = 3,
  parameter int DW        = 32,
  parameter int ARB       = 1,
  parameter int SLICE     = 0,      // 1: sfb_reg_slice (req+rsp) on every slave port
  parameter int LMIN      = 1,
  parameter int LMAX      = 3,
  parameter int WORDS     = 64,     // words per slave window (power of two)
  parameter int SLAVES    = 0,      // 0 TB models, 1 sramlib sram_sp, 2 sramlib sram_sp / sram_1r1w alternating
  parameter int SRAM_LAT  = 1,      // sramlib READ_LATENCY
  parameter int TOPO      = 0,      // 0 sfb_crossbar, 1 sfb_shared_bus
  parameter int WITHDRAW  = 0       // 1: masters withdraw / replace un-accepted requests (R2 violated
                                    //    on purpose: fabric tolerance, cf. silicaflux-v ISS-017)
);
  localparam int AW = 32;
  localparam int SB = DW / 8;
  localparam int OFF = $clog2(SB);
  localparam int WIN = WORDS * SB;                 // window bytes
  localparam int MW = (NM > 1) ? $clog2(NM) : 1;
  localparam logic [AW-1:0] BASE0 = 32'h1000_0000;
  localparam logic [AW-1:0] STRIDE = 32'h0001_0000;

  function automatic logic [NS*AW-1:0] f_base();
    for (int s = 0; s < NS; s++) f_base[s*AW +: AW] = BASE0 + AW'(s) * STRIDE;
  endfunction
  function automatic logic [NS*AW-1:0] f_mask();
    for (int s = 0; s < NS; s++) f_mask[s*AW +: AW] = ~AW'(WIN - 1);
  endfunction
  // last master may not access last slave (when both exist)
  function automatic logic [NM*NS-1:0] f_en();
    f_en = '1;
    if (NM > 1 && NS > 1) f_en[(NM-1)*NS + (NS-1)] = 1'b0;
  endfunction
  localparam logic [NM*NS-1:0] EN = (TOPO == 1) ? '1 : f_en();   // shared bus: no access matrix

  // ---------------------------------------------------------------- clock/reset
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT wires
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*AW-1:0] m_req_addr;
  logic [NM*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0] m_req_wstrb;
  logic [NS-1:0]    x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [NS*AW-1:0] x_req_addr;
  logic [NS*DW-1:0] x_req_wdata, x_rsp_rdata;
  logic [NS*SB-1:0] x_req_wstrb;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*AW-1:0] s_req_addr;
  logic [NS*DW-1:0] s_req_wdata, s_rsp_rdata;
  logic [NS*SB-1:0] s_req_wstrb;
  logic             err_evt, err_write;
  logic [AW-1:0]    err_addr;
  logic [MW-1:0]    err_master;
  logic [NM-1:0]    ev_req_accept, ev_req_stall, ev_arb_loss, ev_rsp_stall;

`ifndef GLS   // the shared bus instantiates parameterised crossbars: RTL only
  if (TOPO == 1) begin : g_shared
    sfb_shared_bus #(
      .NM(NM), .NS(NS), .AW(AW), .DW(DW), .ARB_MODE(ARB), .CHECK_ALIGN(1),
      .SLV_BASE(f_base()), .SLV_MASK(f_mask())
    ) dut (
      .clk, .rst_n,
      .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
      .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
      .s_req_valid(x_req_valid), .s_req_ready(x_req_ready), .s_req_write(x_req_write),
      .s_req_addr(x_req_addr), .s_req_wdata(x_req_wdata), .s_req_wstrb(x_req_wstrb),
      .s_rsp_valid(x_rsp_valid), .s_rsp_ready(x_rsp_ready), .s_rsp_rdata(x_rsp_rdata),
      .s_rsp_error(x_rsp_error),
      .err_evt, .err_addr, .err_master, .err_write,
      .ev_req_accept, .ev_req_stall, .ev_arb_loss, .ev_rsp_stall
    );
  end else
`endif
  begin : g_xbar
`ifdef GLS   // gate-level simulation: synthesized netlist with these parameters baked in
    sfb_crossbar dut (
`else
    sfb_crossbar #(
      .NM(NM), .NS(NS), .AW(AW), .DW(DW), .ARB_MODE(ARB), .CHECK_ALIGN(1),
      .SLV_BASE(f_base()), .SLV_MASK(f_mask()), .MST_SLV_EN(EN)
    ) dut (
`endif
      .clk, .rst_n,
      .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
      .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
      .s_req_valid(x_req_valid), .s_req_ready(x_req_ready), .s_req_write(x_req_write),
      .s_req_addr(x_req_addr), .s_req_wdata(x_req_wdata), .s_req_wstrb(x_req_wstrb),
      .s_rsp_valid(x_rsp_valid), .s_rsp_ready(x_rsp_ready), .s_rsp_rdata(x_rsp_rdata),
      .s_rsp_error(x_rsp_error),
      .err_evt, .err_addr, .err_master, .err_write,
      .ev_req_accept, .ev_req_stall, .ev_arb_loss, .ev_rsp_stall
    );
  end

  // optional register slices between crossbar slave ports and slave models
  genvar gs, gm;
  for (gs = 0; gs < NS; gs++) begin : g_slice
    sfb_reg_slice #(.AW(AW), .DW(DW), .REQ_SLICE(SLICE), .RSP_SLICE(SLICE)) u_sl (
      .clk, .rst_n,
      .s_req_valid(x_req_valid[gs]), .s_req_ready(x_req_ready[gs]), .s_req_write(x_req_write[gs]),
      .s_req_addr(x_req_addr[gs*AW +: AW]), .s_req_wdata(x_req_wdata[gs*DW +: DW]),
      .s_req_wstrb(x_req_wstrb[gs*SB +: SB]),
      .s_rsp_valid(x_rsp_valid[gs]), .s_rsp_ready(x_rsp_ready[gs]),
      .s_rsp_rdata(x_rsp_rdata[gs*DW +: DW]), .s_rsp_error(x_rsp_error[gs]),
      .m_req_valid(s_req_valid[gs]), .m_req_ready(s_req_ready[gs]), .m_req_write(s_req_write[gs]),
      .m_req_addr(s_req_addr[gs*AW +: AW]), .m_req_wdata(s_req_wdata[gs*DW +: DW]),
      .m_req_wstrb(s_req_wstrb[gs*SB +: SB]),
      .m_rsp_valid(s_rsp_valid[gs]), .m_rsp_ready(s_rsp_ready[gs]),
      .m_rsp_rdata(s_rsp_rdata[gs*DW +: DW]), .m_rsp_error(s_rsp_error[gs])
    );
  end

  // ---------------------------------------------------------------- protocol checkers
  logic [31:0] viol_m [0:NM-1];
  logic [31:0] viol_s [0:NS-1];
  logic [31:0] viol_x [0:NS-1];
  for (gm = 0; gm < NM; gm++) begin : g_chk_m
    logic [31:0] nq, np, no;
    sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(1), .ALLOW_REQ_CHANGE(WITHDRAW), .NAME("master")) u_chk (
      .clk, .rst_n,
      .req_valid(m_req_valid[gm]), .req_ready(m_req_ready[gm]), .req_write(m_req_write[gm]),
      .req_addr(m_req_addr[gm*AW +: AW]), .req_wdata(m_req_wdata[gm*DW +: DW]),
      .req_wstrb(m_req_wstrb[gm*SB +: SB]),
      .rsp_valid(m_rsp_valid[gm]), .rsp_ready(m_rsp_ready[gm]),
      .rsp_rdata(m_rsp_rdata[gm*DW +: DW]), .rsp_error(m_rsp_error[gm]),
      .violations(viol_m[gm]), .n_req(nq), .n_rsp(np), .outstanding(no)
    );
  end
  for (gs = 0; gs < NS; gs++) begin : g_chk_s
    logic [31:0] nq, np, no, nq2, np2, no2;
    // crossbar slave port: exactly one outstanding
    sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(1), .ALLOW_REQ_CHANGE(WITHDRAW), .NAME("xbar-slave")) u_chk_x (
      .clk, .rst_n,
      .req_valid(x_req_valid[gs]), .req_ready(x_req_ready[gs]), .req_write(x_req_write[gs]),
      .req_addr(x_req_addr[gs*AW +: AW]), .req_wdata(x_req_wdata[gs*DW +: DW]),
      .req_wstrb(x_req_wstrb[gs*SB +: SB]),
      .rsp_valid(x_rsp_valid[gs]), .rsp_ready(x_rsp_ready[gs]),
      .rsp_rdata(x_rsp_rdata[gs*DW +: DW]), .rsp_error(x_rsp_error[gs]),
      .violations(viol_x[gs]), .n_req(nq), .n_rsp(np), .outstanding(no)
    );
    // slave-model port (behind the optional slice)
    sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(1), .ALLOW_REQ_CHANGE(WITHDRAW), .NAME("slave")) u_chk_s (
      .clk, .rst_n,
      .req_valid(s_req_valid[gs]), .req_ready(s_req_ready[gs]), .req_write(s_req_write[gs]),
      .req_addr(s_req_addr[gs*AW +: AW]), .req_wdata(s_req_wdata[gs*DW +: DW]),
      .req_wstrb(s_req_wstrb[gs*SB +: SB]),
      .rsp_valid(s_rsp_valid[gs]), .rsp_ready(s_rsp_ready[gs]),
      .rsp_rdata(s_rsp_rdata[gs*DW +: DW]), .rsp_error(s_rsp_error[gs]),
      .violations(viol_s[gs]), .n_req(nq2), .n_rsp(np2), .outstanding(no2)
    );
  end

  // ---------------------------------------------------------------- run control
  int unsigned seed, ncyc, mode, nresets, cyc, errors, rsp_bp, gap_pct;
  function automatic int unsigned xsn(input int unsigned r);   // xorshift32 next state
    int unsigned t;
    t = r ^ (r << 13); t = t ^ (t >> 17); t = t ^ (t << 5);
    xsn = t;
  endfunction

  // reference memory (shadow) and slave memories, identical initial pattern
  logic [DW-1:0] shadow [0:NS-1][0:WORDS-1];
  logic [DW-1:0] smem   [0:NS-1][0:WORDS-1];
  function automatic logic [DW-1:0] init_word(input int s, input int w);
    for (int k = 0; k < DW / 32; k++) init_word[k*32 +: 32] = 32'hA5A5_0000 ^ (s << 20) ^ (w << 4) ^ k;
  endfunction
  function automatic logic [DW-1:0] merge(input logic [DW-1:0] o, input logic [DW-1:0] n,
                                          input logic [SB-1:0] st);
    for (int b = 0; b < SB; b++) merge[b*8 +: 8] = st[b] ? n[b*8 +: 8] : o[b*8 +: 8];
  endfunction

  function automatic logic [DW-1:0] mask_bits(input logic [SB-1:0] m);
    for (int b = 0; b < SB; b++) mask_bits[b*8 +: 8] = {8{m[b]}};
  endfunction

  // TB reference decoder
  function automatic int ref_dec(input int m, input logic [AW-1:0] a);   // -1 = decode error
    ref_dec = -1;
    for (int s = 0; s < NS; s++)
      if ((a & ~AW'(WIN - 1)) == BASE0 + AW'(s) * STRIDE && EN[m*NS + s] && a[OFF-1:0] == '0)
        ref_dec = s;
  endfunction
  function automatic logic is_serr(input logic [AW-1:0] a);              // slave error word (TB models only)
    is_serr = (SLAVES == 0) && (a[$clog2(WIN)-1:OFF] == '1);
  endfunction
  // bytes whose content is known to the scoreboard (sramlib arrays power up undefined)
  logic [SB-1:0] known [0:NS-1][0:WORDS-1];
  logic [SB-1:0] exp_mask [0:NM-1];

  // ---------------------------------------------------------------- master BFMs
  logic [NM-1:0]    exp_pend;            // expectation pending (one outstanding)
  logic [DW-1:0]    exp_data [0:NM-1];
  logic             exp_err  [0:NM-1];
  int unsigned      wait_req [0:NM-1], wait_rsp [0:NM-1], max_wait [0:NM-1];
  int unsigned      n_acc [0:NM-1], n_rd [0:NM-1], n_wr [0:NM-1], n_derr [0:NM-1], n_serr [0:NM-1];
  int unsigned      n_pipe [0:NM-1];
  int unsigned      n_slv_acc, n_map_acc, n_starved, n_cancel, n_withdrawn = 0;
  int               exp_t  [0:NM-1];     // target slave of the outstanding request (-1: decode error)
  int               exp_wd [0:NM-1];
  logic             exp_w  [0:NM-1];
  logic             stop_issue = 1'b0;   // drain phase at the end of the run


  for (gm = 0; gm < NM; gm++) begin : g_mst
    logic          v_q, w_q;
    logic [AW-1:0] a_q;
    logic [DW-1:0] d_q;
    logic [SB-1:0] st_q;
    logic          rr_q;
    assign m_req_valid[gm]           = v_q;
    assign m_req_write[gm]           = w_q;
    assign m_req_addr[gm*AW +: AW]   = a_q;
    assign m_req_wdata[gm*DW +: DW]  = d_q;
    assign m_req_wstrb[gm*SB +: SB]  = st_q;
    assign m_rsp_ready[gm]           = rr_q;

    int unsigned   rng;
    logic          seeded = 1'b0;
    always_ff @(posedge clk or negedge rst_n) begin
      logic          nw;
      logic [AW-1:0] na;
      logic [DW-1:0] nd;
      logic [SB-1:0] nst;
      logic          issue, accepted, responded;
      int unsigned   r, sl, wd;
      if (!rst_n) begin
        if (!seeded) begin rng = seed * 32'h9E37_79B9 + 32'(gm) * 7919 + 1; seeded <= 1'b1; end
        v_q  <= 1'b0;
        rr_q <= 1'b0;
        w_q  <= 1'b0;
        a_q  <= '0;
        d_q  <= '0;
        st_q <= '0;
      end else begin
        accepted  = v_q && m_req_ready[gm];
        responded = m_rsp_valid[gm] && m_rsp_ready[gm];
        // response back-pressure
        rng = xsn(rng);
        rr_q <= (mode == 1) ? 1'b1 : ((rng % 100) >= rsp_bp);
        // issue policy: mode 2 -> only master 0; new request when the slot is
        // free; sometimes present it while the response is still pending
        issue = 1'b0;
        if (!(mode == 2 && gm != 0) && !stop_issue) begin
          if (!v_q || accepted) begin
            if (mode == 1) issue = 1'b1;
            else begin
              rng = xsn(rng);
              if ((rng % 100) >= gap_pct) begin
                // pipelined issue allowed while one response is pending
                rng = xsn(rng);
                issue = !exp_pend[gm] || accepted || (rng % 2 == 0);
              end
            end
          end
        end
        // ---- withdrawal (WITHDRAW = 1): drop an un-accepted request 5 % of the time
        if (WITHDRAW != 0 && v_q && !accepted && !issue) begin
          rng = xsn(rng);
          if (rng % 100 < 5) begin
            v_q <= 1'b0;
            n_withdrawn <= n_withdrawn + 1;
          end
        end
        if (issue) begin
          // ---- request generation
          rng = xsn(rng); r  = rng % 100;
          rng = xsn(rng); sl = (mode == 1) ? 0 : (rng % NS);
          rng = xsn(rng); wd = rng % ((mode == 1) ? 8 : WORDS);
          rng = xsn(rng); nw = rng[3];
          for (int k = 0; k < DW / 32; k++) begin rng = xsn(rng); nd[k*32 +: 32] = rng; end
          nst = '1;
          rng = xsn(rng);
          if (rng % 3 == 0) begin rng = xsn(rng); nst = SB'(rng); end
          na = BASE0 + AW'(sl) * STRIDE + AW'(wd * SB);
          if (mode == 0) begin
            rng = xsn(rng);
            if (r < 4)       na = 32'h3000_0000 + AW'((rng % 16) * SB);          // unmapped
            else if (r < 7)  na = BASE0 + AW'(WIN) + AW'((rng % 4) * SB);        // hole after slave 0
            else if (r < 10 && SB > 1) na = na | AW'(1 + rng % (SB - 1));        // misaligned
            else if (r < 14 && NM > 1 && NS > 1)
              na = BASE0 + AW'(NS - 1) * STRIDE + AW'((rng % WORDS) * SB);       // maybe denied
            else if (r < 17) na = BASE0 + AW'(sl) * STRIDE + AW'(WIN - SB);      // slave error word
          end
          v_q <= 1'b1; w_q <= nw; a_q <= na; d_q <= nd; st_q <= nst;
        end else if (accepted) begin
          v_q <= 1'b0;
        end
      end
    end
  end

  // ---------------------------------------------------------------- slave models
  // Pipelined slaves: accept a new request whenever their response queue
  // (depth QD) has room -- also while earlier responses are pending -- like
  // sramlib sram_sp with RSP_FIFO_DEPTH > 1.  The crossbar, not the slave,
  // must therefore enforce one outstanding transaction per slave port.
  // Responses are in order; entry k becomes visible >= LMIN..LMAX cycles
  // after its acceptance.  Write data is applied at acceptance; read data is
  // sampled at acceptance.  Error on the last word of the window.
  localparam int QD = 4;
  for (gs = 0; gs < NS; gs++) begin : g_slv
   if (SLAVES == 0) begin : g_model
    logic [DW-1:0] q_d   [0:QD-1];
    logic          q_e   [0:QD-1];
    int unsigned   q_due [0:QD-1];
    int unsigned   q_n, q_rd, q_wr;
    logic          rdy_q;
    int unsigned   rng;
    logic          seeded = 1'b0;
    int unsigned   scyc;
    assign s_req_ready[gs]          = rdy_q && (q_n < QD);
    assign s_rsp_valid[gs]          = (q_n != 0) && (scyc >= q_due[q_rd]);
    assign s_rsp_rdata[gs*DW +: DW] = s_rsp_valid[gs] ? q_d[q_rd] : '0;
    assign s_rsp_error[gs]          = s_rsp_valid[gs] && q_e[q_rd];
    always_ff @(posedge clk or negedge rst_n) begin
      logic [AW-1:0] a;
      int unsigned   w, lat, due, n;
      if (!rst_n) begin
        if (!seeded) begin rng = seed * 32'h85EB_CA6B + 32'(gs) * 104729 + 3; seeded <= 1'b1; end
        q_n <= 0; q_rd <= 0; q_wr <= 0; rdy_q <= 1'b0; scyc <= 0;
        for (int k = 0; k < QD; k++) q_due[k] <= 0;
      end else begin
        scyc <= scyc + 1;
        rng = xsn(rng);
        rdy_q <= (mode == 1) ? 1'b1 : ((rng % 4) != 0);
        n = q_n;
        if (s_rsp_valid[gs] && s_rsp_ready[gs]) begin
          q_rd <= (q_rd + 1) % QD;
          n = n - 1;
        end
        if (s_req_valid[gs] && s_req_ready[gs]) begin
          a = s_req_addr[gs*AW +: AW];
          w = int'(a[$clog2(WIN)-1:OFF]);
          rng = xsn(rng);
          lat = (mode == 1) ? LMAX : (LMIN + rng % (LMAX - LMIN + 1));
          // response visible `lat` cycles after this acceptance cycle, in order
          due = scyc + lat;
          if (q_n != 0 && q_due[(q_wr + QD - 1) % QD] > due) due = q_due[(q_wr + QD - 1) % QD];
          q_due[q_wr] <= due;
          q_e[q_wr]   <= is_serr(a);
          q_d[q_wr]   <= (s_req_write[gs] || is_serr(a)) ? '0 : smem[gs][w];
          if (s_req_write[gs] && !is_serr(a))
            smem[gs][w] <= merge(smem[gs][w], s_req_wdata[gs*DW +: DW], s_req_wstrb[gs*SB +: SB]);
          q_wr <= (q_wr + 1) % QD;
          n = n + 1;
        end
        q_n <= n;
      end
    end
   end else if (SLAVES == 2 && (gs % 2) == 1) begin : g_1r1w
    sfb_sram_1r1w_slave #(.DW(DW), .DEPTH(WORDS), .READ_LATENCY(SRAM_LAT)) u_sram (
      .clk, .rst_n,
      .req_valid(s_req_valid[gs]), .req_ready(s_req_ready[gs]), .req_write(s_req_write[gs]),
      .req_addr(s_req_addr[gs*AW +: AW]), .req_wdata(s_req_wdata[gs*DW +: DW]),
      .req_wstrb(s_req_wstrb[gs*SB +: SB]),
      .rsp_valid(s_rsp_valid[gs]), .rsp_ready(s_rsp_ready[gs]), .rsp_rdata(s_rsp_rdata[gs*DW +: DW]),
      .rsp_error(s_rsp_error[gs]));
   end else begin : g_sp
    logic [DW-1:0] tst_rd;
    sfb_sram_slave #(.DW(DW), .DEPTH(WORDS), .READ_LATENCY(SRAM_LAT)) u_sram (
      .clk, .rst_n,
      .req_valid(s_req_valid[gs]), .req_ready(s_req_ready[gs]), .req_write(s_req_write[gs]),
      .req_addr(s_req_addr[gs*AW +: AW]), .req_wdata(s_req_wdata[gs*DW +: DW]),
      .req_wstrb(s_req_wstrb[gs*SB +: SB]),
      .rsp_valid(s_rsp_valid[gs]), .rsp_ready(s_rsp_ready[gs]), .rsp_rdata(s_rsp_rdata[gs*DW +: DW]),
      .rsp_error(s_rsp_error[gs]),
      .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rd));
   end
  end

  // ---------------------------------------------------------------- scoreboards
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      // reset cancellation (PROTOCOL.md R11): an accepted write whose response
      // was not delivered may or may not have been performed -> resolve the
      // shadow to the slave's actual content for exactly those words
      for (int m = 0; m < NM; m++)
        if (exp_pend[m] && exp_w[m] && exp_t[m] >= 0 && !exp_err[m]) begin
          if (SLAVES == 0) shadow[exp_t[m]][exp_wd[m]] <= smem[exp_t[m]][exp_wd[m]];
          else known[exp_t[m]][exp_wd[m]] <= '0;
          n_cancel <= n_cancel + 1;
        end
      exp_pend <= '0;
      for (int m = 0; m < NM; m++) begin wait_req[m] <= 0; wait_rsp[m] <= 0; end
    end else begin
      int n_s_acc, n_m_acc;
      n_s_acc = 0; n_m_acc = 0;
      for (int s = 0; s < NS; s++) if (x_req_valid[s] && x_req_ready[s]) n_s_acc++;
      for (int m = 0; m < NM; m++) begin
        logic [AW-1:0] a;
        logic          w;
        int            t;
        a = m_req_addr[m*AW +: AW];
        w = m_req_write[m];
        // ---- response check (responses of the previous transaction come first)
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          if (!exp_pend[m]) begin
            errors <= errors + 1; $display("TB_SFB ERROR m%0d unexpected response", m);
          end else if (m_rsp_error[m] !== exp_err[m] ||
                       (!exp_err[m] && ((m_rsp_rdata[m*DW +: DW] ^ exp_data[m]) & mask_bits(exp_mask[m])) != '0)) begin
            errors <= errors + 1;
            $display("TB_SFB ERROR m%0d rsp data=%h err=%0d expected data=%h err=%0d cyc=%0d",
                     m, m_rsp_rdata[m*DW +: DW], m_rsp_error[m], exp_data[m], exp_err[m], cyc);
          end
        end
        // ---- request acceptance: reference decode, conservation, shadow update
        if (m_req_valid[m] && m_req_ready[m]) begin
          t = ref_dec(m, a);
          exp_t[m] <= t;
          exp_w[m] <= w;
          exp_wd[m] <= int'(a[$clog2(WIN)-1:OFF]);
          n_acc[m] <= n_acc[m] + 1;
          if (m_rsp_valid[m] && m_rsp_ready[m]) n_pipe[m] <= n_pipe[m] + 1;
          if (t < 0) begin
            n_derr[m] <= n_derr[m] + 1;
            exp_err[m] <= 1'b1; exp_data[m] <= '0; exp_mask[m] <= '1;
            if (!err_evt) begin errors <= errors + 1; $display("TB_SFB ERROR m%0d decode error not captured", m); end
          end else begin
            int wd;
            n_m_acc++;
            wd = int'(a[$clog2(WIN)-1:OFF]);
            if (!(x_req_valid[t] && x_req_ready[t] && x_req_addr[t*AW +: AW] == a &&
                  x_req_write[t] == w && x_req_wstrb[t*SB +: SB] == m_req_wstrb[m*SB +: SB] &&
                  (!w || x_req_wdata[t*DW +: DW] == m_req_wdata[m*DW +: DW]))) begin
              errors <= errors + 1;
              $display("TB_SFB ERROR m%0d request %h not forwarded intact to slave %0d cyc=%0d", m, a, t, cyc);
            end
            exp_err[m] <= is_serr(a);
            if (is_serr(a)) n_serr[m] <= n_serr[m] + 1;
            if (w) begin
              n_wr[m] <= n_wr[m] + 1;
              exp_data[m] <= '0;
              exp_mask[m] <= '1;
              if (!is_serr(a)) begin
                shadow[t][wd] <= merge(shadow[t][wd], m_req_wdata[m*DW +: DW], m_req_wstrb[m*SB +: SB]);
                known[t][wd]  <= known[t][wd] | m_req_wstrb[m*SB +: SB];
              end
            end else begin
              n_rd[m] <= n_rd[m] + 1;
              exp_data[m] <= is_serr(a) ? '0 : shadow[t][wd];
              exp_mask[m] <= is_serr(a) ? '1 : known[t][wd];
            end
          end
          exp_pend[m] <= 1'b1;
        end else if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          exp_pend[m] <= 1'b0;
        end
        // ---- liveness / fairness
        if (m_req_valid[m] && !m_req_ready[m]) wait_req[m] <= wait_req[m] + 1;
        else begin
          if (wait_req[m] > max_wait[m]) max_wait[m] <= wait_req[m];
          wait_req[m] <= 0;
        end
        if (exp_pend[m] && !(m_rsp_valid[m] && m_rsp_ready[m])) wait_rsp[m] <= wait_rsp[m] + 1;
        else wait_rsp[m] <= 0;
        if (mode == 1 && ARB == 0 && wait_req[m] > 1000) begin
          // documented fixed-priority behaviour: lower-priority masters starve
          // under sustained contention -> recorded, not an error
          n_starved <= n_starved + 1;
          wait_req[m] <= 0;
        end else if (wait_req[m] > 20000 || wait_rsp[m] > 20000) begin
          errors <= errors + 1; $display("TB_SFB ERROR m%0d watchdog (starvation/deadlock) cyc=%0d", m, cyc);
          wait_req[m] <= 0; wait_rsp[m] <= 0;
        end
        if (mode == 1 && ARB == 1 && wait_req[m] > NM * (LMAX + 2)) begin
          errors <= errors + 1;
          $display("TB_SFB ERROR m%0d RR fairness bound exceeded (%0d cycles)", m, wait_req[m]);
          wait_req[m] <= 0;
        end
      end
      if (n_s_acc != n_m_acc) begin
        errors <= errors + 1;
        $display("TB_SFB ERROR conservation: %0d slave accepts vs %0d mapped master accepts cyc=%0d",
                 n_s_acc, n_m_acc, cyc);
      end
      n_slv_acc <= n_slv_acc + n_s_acc;
      n_map_acc <= n_map_acc + n_m_acc;
    end
  end

  // ---------------------------------------------------------------- debug print (+dbg=N cycles)
  int unsigned dbg_n;
  always @(posedge clk) begin
    if (dbg_n != 0) begin
      dbg_n <= dbg_n - 1;
      $display("DBG cyc=%0d rst=%b mv=%b mr=%b mrv=%b mrr=%b sv=%b sr=%b srv=%b srr=%b pend=%b",
               cyc, rst_n, m_req_valid, m_req_ready, m_rsp_valid, m_rsp_ready, s_req_valid, s_req_ready,
               s_rsp_valid, s_rsp_ready, exp_pend);
    end
  end

  // ---------------------------------------------------------------- main
  initial begin
    if (!$value$plusargs("dbg=%d", dbg_n)) dbg_n = 0;
    if (!$value$plusargs("seed=%d", seed))     seed = 1;
    if (!$value$plusargs("cycles=%d", ncyc))   ncyc = 20000;
    if (!$value$plusargs("mode=%d", mode))     mode = 0;
    if (!$value$plusargs("resets=%d", nresets)) nresets = 0;
    if (!$value$plusargs("rsp_bp=%d", rsp_bp)) rsp_bp = 25;
    if (!$value$plusargs("gap=%d", gap_pct))   gap_pct = 20;
    errors = 0; n_slv_acc = 0; n_map_acc = 0; n_starved = 0; n_cancel = 0;
    for (int m = 0; m < NM; m++) begin
      max_wait[m] = 0; n_acc[m] = 0; n_rd[m] = 0; n_wr[m] = 0; n_derr[m] = 0; n_serr[m] = 0; n_pipe[m] = 0;
    end
    for (int s = 0; s < NS; s++)
      for (int w = 0; w < WORDS; w++) begin
        shadow[s][w] = init_word(s, w);
        smem[s][w]   = init_word(s, w);
        known[s][w]  = (SLAVES == 0) ? '1 : '0;
      end
    $display("TB_SFB config NM=%0d NS=%0d DW=%0d ARB=%0d SLICE=%0d LAT=%0d..%0d SLAVES=%0d SRAM_LAT=%0d TOPO=%0d mode=%0d seed=%0d cycles=%0d resets=%0d",
             NM, NS, DW, ARB, SLICE, LMIN, LMAX, SLAVES, SRAM_LAT, TOPO, mode, seed, ncyc, nresets);
    rst_n = 1'b0;
    repeat (3) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    for (cyc = 0; cyc < ncyc; cyc++) begin
      @(posedge clk);
      if (nresets != 0 && cyc > 100 && (cyc % (ncyc / (nresets + 1))) == 0 && cyc < ncyc - 200) begin
        // asynchronous reset in the middle of traffic
        #2 rst_n = 1'b0;
        @(negedge clk);
        if (|m_rsp_valid || |x_req_valid) begin
          errors++; $display("TB_SFB ERROR activity while in reset");
        end
        @(negedge clk) rst_n = 1'b1;
        if (|m_rsp_valid) begin errors++; $display("TB_SFB ERROR response right after reset"); end
      end
    end
    // drain: stop issuing, wait for every outstanding response
    stop_issue = 1'b1;
    begin
      int unsigned d;
      d = 0;
      while ((|exp_pend || |m_req_valid) && d < 100000) begin @(posedge clk); d++; end
      if (d >= 100000) begin errors++; $display("TB_SFB ERROR drain timeout"); end
    end
    repeat (LMAX + 8) @(posedge clk);
    begin
      int unsigned v;
      v = 0;
      for (int m = 0; m < NM; m++) v += viol_m[m];
      for (int s = 0; s < NS; s++) v += viol_s[s] + viol_x[s];
      for (int m = 0; m < NM; m++)
        $display("TB_SFB master %0d: accepted=%0d reads=%0d writes=%0d decode_err=%0d slave_err=%0d pipelined=%0d max_wait=%0d",
                 m, n_acc[m], n_rd[m], n_wr[m], n_derr[m], n_serr[m], n_pipe[m], max_wait[m]);
      // final memory consistency: slave memories == shadow (TB models only;
      // sramlib contents are checked by every read during the run)
      if (SLAVES == 0) for (int s = 0; s < NS; s++)
        for (int w = 0; w < WORDS; w++)
          if (smem[s][w] !== shadow[s][w]) begin
            errors++; $display("TB_SFB ERROR final memory s%0d w%0d %h != %h", s, w, smem[s][w], shadow[s][w]);
          end
      if (n_slv_acc == 0) begin errors++; $display("TB_SFB ERROR no traffic"); end
      // (the continuous-wait starvation detector does not apply when masters
      //  withdraw requests: their wait counters restart on every withdrawal)
      if (mode == 1 && ARB == 0 && NM > 1 && n_starved == 0 && WITHDRAW == 0) begin
        errors++; $display("TB_SFB ERROR fixed priority: expected starvation not observed");
      end
      if (errors == 0 && v == 0)
        $display("TB_SFB RESULT PASS slave_accepts=%0d protocol_violations=0 starvation_events=%0d cancelled_writes_resolved=%0d withdrawn=%0d",
                 n_slv_acc, n_starved, n_cancel, n_withdrawn);
      else begin
        $display("TB_SFB RESULT FAIL errors=%0d protocol_violations=%0d", errors, v);
        $fatal(1, "tb_sfb_xbar failed");
      end
    end
    $finish;
  end
endmodule

`default_nettype wire
