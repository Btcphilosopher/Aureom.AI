"""cocotb: silicaflux_dma against an independent Python reference model (Icarus).

The DUT's SFB2 master port is served by a Python memory slave with random
req_ready back-pressure, random latency 1..4, in-order responses held under
the DMA's rsp_ready, unmapped regions (decode error) and a programmable poison
word (slave error).  The register bus is driven like sfv_periph_bridge.
Every transfer is predicted by `ref_transfer` (validation rules, beat-by-beat
copy, error semantics) and the resulting memory, ERROR_CODE, ERROR_ADDR,
BYTES_DONE and STATUS are compared.  ENGINE (0 simple / 1 buffered) comes from
the Makefile.  Seeds are logged (cocotb RANDOM_SEED / SEED env).
"""
import os
import random

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ReadOnly, RisingEdge

# register offsets / codes (generated/datafabric_map.py would provide these;
# kept literal here so the test is self-contained and cross-checks the map)
CONTROL, STATUS, SRC, DST, LEN, BYTES, IE, IS, ECODE, EADDR, INFO, ID = (
    0x00, 0x04, 0x08, 0x0C, 0x10, 0x14, 0x18, 0x1C, 0x20, 0x24, 0x28, 0x2C)
E_ZERO, E_LEN, E_SALIGN, E_DALIGN, E_SOVF, E_DOVF, E_OVL, E_RD, E_WR, E_ABT = range(1, 11)
REGIONS = [(0x1000_0000, 0x1_0000), (0x2000_0000, 0x1000)]
MAX_LEN = 1 << 16


def mapped(a):
    return any(b <= a < b + s for b, s in REGIONS)


def ref_transfer(mem, src, dst, n, poison):
    """Reference semantics (docs/datafabric/DMA.md). Returns (code, bytes_done, err_addr)."""
    if n == 0:
        return E_ZERO, 0, 0
    if n > MAX_LEN:
        return E_LEN, 0, 0
    if src % 4:
        return E_SALIGN, 0, 0
    if dst % 4:
        return E_DALIGN, 0, 0
    if src + n > 1 << 32:
        return E_SOVF, 0, 0
    if dst + n > 1 << 32:
        return E_DOVF, 0, 0
    if src < dst + n and dst < src + n:
        return E_OVL, 0, 0
    done = 0
    for off in range(0, n, 4):
        sa, da = src + off, dst + off
        if not mapped(sa) or sa == poison:
            return E_RD, done, sa
        if not mapped(da) or da == poison:
            return E_WR, done, da
        k = min(4, n - off)
        for b in range(k):
            mem[da + b] = mem.get(sa + b, 0)
        done += k
    return 0, done, 0


class MemSlave:
    def __init__(self, dut, rng, bp=25):
        self.dut, self.rng, self.bp = dut, rng, bp
        self.mem = {}
        self.poison = -1
        self.q = []          # [due_cycle, data, err]
        self.cyc = 0
        dut.m_req_ready.value = 0
        dut.m_rsp_valid.value = 0
        dut.m_rsp_rdata.value = 0
        dut.m_rsp_error.value = 0

    def word(self, a):
        return sum(self.mem.get(a + b, 0) << (8 * b) for b in range(4))

    async def run(self):
        dut = self.dut
        ready = 0
        while True:
            await ReadOnly()
            acc = int(dut.m_req_valid.value) and ready
            if acc:
                a, w = int(dut.m_req_addr.value), int(dut.m_req_write.value)
                # write data / strobes are don't-care on reads (un-reset datapath may be X)
                d = int(dut.m_req_wdata.value) if w else 0
                st = int(dut.m_req_wstrb.value) if w else 0
            hs = len(self.q) and self.q[0][0] <= self.cyc and int(dut.m_rsp_ready.value)
            await RisingEdge(dut.clk)
            self.cyc += 1
            if hs:
                self.q.pop(0)
            if acc:
                err = (not mapped(a)) or a == self.poison
                data = 0
                if not err and w:
                    for b in range(4):
                        if (st >> b) & 1:
                            self.mem[a + b] = (d >> (8 * b)) & 0xFF
                elif not err:
                    data = self.word(a)
                due = max(self.cyc + self.rng.randint(0, 3), self.q[-1][0] if self.q else 0)
                self.q.append([due, data, int(err)])
            ready = int(self.rng.randrange(100) >= self.bp and len(self.q) < 4)
            dut.m_req_ready.value = ready
            if self.q and self.q[0][0] <= self.cyc:
                dut.m_rsp_valid.value, dut.m_rsp_rdata.value, dut.m_rsp_error.value = 1, self.q[0][1], self.q[0][2]
            else:
                dut.m_rsp_valid.value, dut.m_rsp_rdata.value, dut.m_rsp_error.value = 0, 0, 0


class RegBus:
    def __init__(self, dut):
        self.dut = dut
        dut.rb_sel.value = 0
        dut.rb_we.value = 0
        dut.rb_addr.value = 0
        dut.rb_wdata.value = 0

    async def write(self, a, v):
        d = self.dut
        d.rb_sel.value, d.rb_we.value, d.rb_addr.value, d.rb_wdata.value = 1, 1, a, v & 0xFFFFFFFF
        await ReadOnly()
        e = int(d.rb_err.value)
        await RisingEdge(d.clk)
        d.rb_sel.value, d.rb_we.value = 0, 0
        return e

    async def read(self, a):
        d = self.dut
        d.rb_sel.value, d.rb_we.value, d.rb_addr.value = 1, 0, a
        await ReadOnly()
        v, e = int(d.rb_rdata.value), int(d.rb_err.value)
        await RisingEdge(d.clk)
        d.rb_sel.value = 0
        return v, e


async def setup(dut, seed):
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    rng = random.Random(seed)
    slave = MemSlave(dut, rng)
    for base, size in REGIONS:
        for a in range(base, base + size):
            slave.mem[a] = rng.getrandbits(8)
    rb = RegBus(dut)
    dut.rst_n.value = 0
    for _ in range(4):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    cocotb.start_soon(slave.run())
    await RisingEdge(dut.clk)
    return rng, slave, rb


async def transfer(dut, rb, slave, src, dst, n, tag):
    ref = dict(slave.mem)
    code, done, eaddr = ref_transfer(ref, src, dst, n, slave.poison)
    assert await rb.write(SRC, src) == 0 and await rb.write(DST, dst) == 0 and await rb.write(LEN, n) == 0
    await rb.write(IS, 3)
    assert await rb.write(CONTROL, 1) == 0, f"{tag}: START refused"
    for _ in range(200000):
        st, _ = await rb.read(STATUS)
        if not st & 1:
            break
    else:
        raise AssertionError(f"{tag}: never finished")
    hw_code, _ = await rb.read(ECODE)
    hw_bytes, _ = await rb.read(BYTES)
    hw_eaddr, _ = await rb.read(EADDR)
    assert hw_code == code, f"{tag}: ERROR_CODE {hw_code} != reference {code}"
    assert ((st >> 1) & 1) == (code == 0) and ((st >> 2) & 1) == (code != 0), f"{tag}: STATUS {st:#x}"
    if int(os.environ.get("ENGINE", "0")) == 0 or code != E_WR:
        assert hw_bytes == done, f"{tag}: BYTES_DONE {hw_bytes} != reference {done}"
        if code in (E_RD, E_WR):
            assert hw_eaddr == eaddr, f"{tag}: ERROR_ADDR {hw_eaddr:#x} != {eaddr:#x}"
        bad = [a for a in set(ref) | set(slave.mem) if ref.get(a) != slave.mem.get(a)]
        assert not bad, f"{tag}: {len(bad)} bytes differ from the reference model (first {hex(min(bad))})"
    return code


@cocotb.test()
async def random_valid_transfers(dut):
    seed = int(os.environ.get("SEED", "11"))
    rng, slave, rb = await setup(dut, seed)
    dut._log.info("seed=%d engine=%s", seed, os.environ.get("ENGINE", "0"))
    v, _ = await rb.read(ID)
    assert v == 0x5346_4446
    for i in range(int(os.environ.get("N_DMA", "40"))):
        n = rng.randint(1, 300)
        s_reg, d_reg = rng.sample([0, 1], 2) if rng.random() < 0.7 else (0, 0)
        src = REGIONS[s_reg][0] + 4 * rng.randrange(0, 64)
        dst = REGIONS[d_reg][0] + (0x800 if d_reg == s_reg else 0) + 4 * rng.randrange(0, 64)
        assert await transfer(dut, rb, slave, src, dst, n, f"t{i}") == 0


@cocotb.test()
async def validation_and_bus_errors(dut):
    rng, slave, rb = await setup(dut, int(os.environ.get("SEED", "11")) + 1)
    cases = [
        (0x1000_0000, 0x2000_0000, 0, "zero"), (0x1000_0000, 0x2000_0000, MAX_LEN + 1, "too long"),
        (0x1000_0002, 0x2000_0000, 8, "src align"), (0x1000_0000, 0x2000_0001, 8, "dst align"),
        (0xFFFF_FFF0, 0x2000_0000, 0x20, "src overflow"), (0x1000_0000, 0xFFFF_FFF8, 0x10, "dst overflow"),
        (0x1000_0000, 0x1000_0004, 16, "overlap"), (0x3000_0000, 0x2000_0000, 16, "unmapped src"),
        (0x1000_0000, 0x3000_0000, 16, "unmapped dst"), (0x2000_0F80, 0x1000_4000, 0x100, "src runs off"),
    ]
    for s, d, n, tag in cases:
        await transfer(dut, rb, slave, s, d, n, tag)
    slave.poison = 0x1000_0040
    await transfer(dut, rb, slave, 0x1000_0000, 0x2000_0000, 0x80, "poison read")
    slave.poison = 0x2000_0100
    await transfer(dut, rb, slave, 0x1000_0000, 0x2000_00F0, 0x40, "poison write")
    slave.poison = -1
    assert await transfer(dut, rb, slave, 0x1000_0000, 0x2000_0000, 0x40, "after errors") == 0


@cocotb.test()
async def busy_protection_and_irq(dut):
    rng, slave, rb = await setup(dut, int(os.environ.get("SEED", "11")) + 2)
    await rb.write(IE, 1)
    await rb.write(SRC, 0x1000_0000)
    await rb.write(DST, 0x2000_0000)
    await rb.write(LEN, 2048)
    assert await rb.write(CONTROL, 1) == 0
    assert await rb.write(SRC, 0x1000_1000) == 1, "SRC write while busy not refused"
    assert await rb.write(LEN, 4) == 1, "LEN write while busy not refused"
    assert await rb.write(CONTROL, 1) == 1, "START while busy not refused"
    v, _ = await rb.read(SRC)
    assert v == 0x1000_0000
    while True:
        st, _ = await rb.read(STATUS)
        if not st & 1:
            break
    assert st & 2 and int(dut.irq.value) == 1, "completion interrupt missing"
    await rb.write(IS, 1)
    await RisingEdge(dut.clk)
    await ReadOnly()
    assert int(dut.irq.value) == 0, "interrupt not cleared by W1C"
