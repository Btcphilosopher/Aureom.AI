// =============================================================================
// SilicaFlux DataFabric :: tb_dma -- self-checking DMA testbench (Verilator)
//
// DUT: silicaflux_dma (simple or buffered engine) on an sfb_crossbar together
// with NC competing random masters ("CPU", "vector", "tensor" traffic models).
// Slaves: MEM0 0x1000_0000 16 KiB, MEM1 0x1001_0000 16 KiB (SRAM banks),
// MEM2 0x2000_0000 4 KiB (tile-scratchpad-like); everything else unmapped.
// Slave models are pipelined (accept while responses pend), with random
// req_ready back-pressure (+bp=%), latency LMIN..LMAX and a programmable
// "poison" word that answers with rsp_error (write not performed).
// Competing masters only touch the top 4 KiB of MEM0/MEM1 (their scratch);
// the DMA uses the rest.  The TB drives the DMA register bus like the CPU
// behind sfv_periph_bridge.
//
// Independent checks:
//   * expected-memory model (bytes): competing writes applied at acceptance,
//     DMA effect applied at completion (copy of `bytes_done` bytes); the full
//     slave memory is compared after every transfer;
//   * write monitor on the DMA port(s): every DMA write lies in
//     [dst, dst+len) word range with strobes only on bytes < len, no write
//     after a read error, no DMA request while idle / in reset (no spurious
//     writes), every write's data equals the source bytes;
//   * STATUS / ERROR_CODE / ERROR_ADDR / BYTES_DONE / INT_STATUS / irq;
//   * sfb_protocol_checker on every master and slave port.
// Tests (+test=all|directed|errors|busy|irq|abort|reset|random) and
// +seed, +ntrans, +bp, +nc_active.  Result: "TB_DMA RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "dma_defs.svh"

module tb_dma #(
  parameter int DW         = 32,
  parameter int ENGINE     = 0,
  parameter int FIFO_DEPTH = 8,
  parameter int BURST      = 8,
  parameter int DUAL_PORT  = 0,
  parameter int MAX_OUT    = 2,
  parameter int NC         = 2,      // competing masters
  parameter int ARB        = 1,
  parameter int LMIN       = 1,
  parameter int LMAX       = 3
);
  localparam int SB  = DW / 8;
  localparam int OFF = $clog2(SB);
  localparam int NP  = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1;
  localparam int NM  = NP + NC;
  localparam int NS  = 3;
  localparam int MEMB = 16384 * 2 + 4096;             // bytes of all slaves
  localparam logic [NS*32-1:0] BASE = {32'h2000_0000, 32'h1001_0000, 32'h1000_0000};
  localparam logic [NS*32-1:0] MASK = {32'hFFFF_F000, 32'hFFFF_C000, 32'hFFFF_C000};

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- fabric wires
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr;
  logic [NM*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0] m_req_wstrb;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*32-1:0] s_req_addr;
  logic [NS*DW-1:0] s_req_wdata, s_rsp_rdata;
  logic [NS*SB-1:0] s_req_wstrb;
  logic [NM-1:0]    ev_acc, ev_stall, ev_loss, ev_rstall;
  logic             err_evt, err_write;
  logic [31:0]      err_addr;
  logic [$clog2(NM)-1:0] err_master;

  sfb_crossbar #(.NM(NM), .NS(NS), .AW(32), .DW(DW), .ARB_MODE(ARB), .CHECK_ALIGN(1),
                 .SLV_BASE(BASE), .SLV_MASK(MASK)) u_xbar (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt, .err_addr, .err_master, .err_write,
    .ev_req_accept(ev_acc), .ev_req_stall(ev_stall), .ev_arb_loss(ev_loss), .ev_rsp_stall(ev_rstall));

  // ---------------------------------------------------------------- DUT
  logic        rb_sel = 1'b0, rb_we = 1'b0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic        rb_err, irq, dma_busy, dma_done_ev;
  logic [31:0] dma_bytes;
  logic [7:0]  dma_fifo, fifo_max = 8'd0;
  always @(posedge clk) if (dma_fifo > fifo_max) fifo_max <= dma_fifo;
`ifdef GLS   // gate-level simulation: synthesized netlist with these parameters baked in
  silicaflux_dma dut (
`else
  silicaflux_dma #(.DW(DW), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .BURST(BURST),
                   .DUAL_PORT(DUAL_PORT), .MAX_OUT(MAX_OUT), .MAX_LEN_LOG2(16)) dut (
`endif
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq,
    .m_req_valid(m_req_valid[NP-1:0]), .m_req_ready(m_req_ready[NP-1:0]),
    .m_req_write(m_req_write[NP-1:0]), .m_req_addr(m_req_addr[NP*32-1:0]),
    .m_req_wdata(m_req_wdata[NP*DW-1:0]), .m_req_wstrb(m_req_wstrb[NP*SB-1:0]),
    .m_rsp_valid(m_rsp_valid[NP-1:0]), .m_rsp_ready(m_rsp_ready[NP-1:0]),
    .m_rsp_rdata(m_rsp_rdata[NP*DW-1:0]), .m_rsp_error(m_rsp_error[NP-1:0]),
    .busy(dma_busy), .ev_done(dma_done_ev), .bytes_done(dma_bytes), .fifo_level(dma_fifo));

  // ---------------------------------------------------------------- protocol checkers + trace
  logic [31:0] viol [0:NM+NS-1];
  genvar g;
  for (g = 0; g < NM; g++) begin : g_cm
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT((g < NP && ENGINE != 0) ? MAX_OUT : 1),
                           .NAME("master")) u_c (
      .clk, .rst_n, .req_valid(m_req_valid[g]), .req_ready(m_req_ready[g]), .req_write(m_req_write[g]),
      .req_addr(m_req_addr[g*32 +: 32]), .req_wdata(m_req_wdata[g*DW +: DW]), .req_wstrb(m_req_wstrb[g*SB +: SB]),
      .rsp_valid(m_rsp_valid[g]), .rsp_ready(m_rsp_ready[g]), .rsp_rdata(m_rsp_rdata[g*DW +: DW]),
      .rsp_error(m_rsp_error[g]), .violations(viol[g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  for (g = 0; g < NS; g++) begin : g_cs
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(1), .NAME("slave")) u_c (
      .clk, .rst_n, .req_valid(s_req_valid[g]), .req_ready(s_req_ready[g]), .req_write(s_req_write[g]),
      .req_addr(s_req_addr[g*32 +: 32]), .req_wdata(s_req_wdata[g*DW +: DW]), .req_wstrb(s_req_wstrb[g*SB +: SB]),
      .rsp_valid(s_rsp_valid[g]), .rsp_ready(s_rsp_ready[g]), .rsp_rdata(s_rsp_rdata[g*DW +: DW]),
      .rsp_error(s_rsp_error[g]), .violations(viol[NM+g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  logic [63:0] tcyc;
  sfb_trace_monitor #(.NM(NM), .NS(NS), .DW(DW), .SLV_BASE(BASE), .SLV_MASK(MASK)) u_trace (
    .clk, .rst_n, .req_valid(m_req_valid), .req_ready(m_req_ready), .req_write(m_req_write),
    .req_addr(m_req_addr), .req_wstrb(m_req_wstrb), .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready),
    .rsp_error(m_rsp_error), .arb_loss(ev_loss), .cycle(tcyc));

  // ---------------------------------------------------------------- shared state
  function automatic int unsigned xsn(input int unsigned r);
    int unsigned t;
    t = r ^ (r << 13); t = t ^ (t >> 17); t = t ^ (t << 5);
    xsn = t;
  endfunction
  // global byte offset of an address (-1: unmapped)
  function automatic int goff(input logic [31:0] a);
    goff = -1;
    if ((a & 32'hFFFF_C000) == 32'h1000_0000) goff = int'(a[13:0]);
    else if ((a & 32'hFFFF_C000) == 32'h1001_0000) goff = 16384 + int'(a[13:0]);
    else if ((a & 32'hFFFF_F000) == 32'h2000_0000) goff = 32768 + int'(a[11:0]);
  endfunction

  logic [7:0]  mem [0:MEMB-1];            // slave storage (all slaves)
  logic [7:0]  exp [0:MEMB-1];            // expected memory
  int          poison;                    // global byte offset of a poisoned word (-1 none)
  int unsigned seed, bp, cyc, errors, nc_active;
  logic        in_xfer;                   // a DMA transfer is in progress (TB view)
  logic [31:0] x_src, x_dst, x_len;       // current transfer
  logic        x_rd_err_seen;
  int unsigned n_dma_wr, n_dma_rd, n_comp_acc;
  always @(posedge clk) cyc <= cyc + 1;

  // ---------------------------------------------------------------- slave models
  localparam int QD = 4;
  for (g = 0; g < NS; g++) begin : g_slv
    logic [DW-1:0] q_d   [0:QD-1];
    logic          q_e   [0:QD-1];
    int unsigned   q_due [0:QD-1];
    int unsigned   q_n, q_rd, q_wr, rng, scyc;
    logic          rdy_q;
    assign s_req_ready[g]         = rdy_q && (q_n < QD);
    assign s_rsp_valid[g]         = (q_n != 0) && (scyc >= q_due[q_rd]);
    assign s_rsp_rdata[g*DW +: DW] = s_rsp_valid[g] ? q_d[q_rd] : '0;
    assign s_rsp_error[g]         = s_rsp_valid[g] && q_e[q_rd];
    always_ff @(posedge clk or negedge rst_n) begin
      int unsigned n, due, lat;
      int o;
      logic [DW-1:0] d;
      logic pe;
      if (!rst_n) begin
        q_n <= 0; q_rd <= 0; q_wr <= 0; rdy_q <= 1'b0; scyc <= 0;
        rng = seed * 32'h85EB_CA6B + 32'(g) * 104729 + 3;
      end else begin
        scyc <= scyc + 1;
        rng = xsn(rng);
        rdy_q <= (rng % 100) >= bp;
        n = q_n;
        if (s_rsp_valid[g] && s_rsp_ready[g]) begin q_rd <= (q_rd + 1) % QD; n = n - 1; end
        if (s_req_valid[g] && s_req_ready[g]) begin
          o  = goff({s_req_addr[g*32 + OFF +: 32 - OFF], {OFF{1'b0}}});
          pe = (poison >= 0) && (o == poison);
          for (int b = 0; b < SB; b++) d[b*8 +: 8] = mem[o + b];
          if (s_req_write[g] && !pe)
            for (int b = 0; b < SB; b++) if (s_req_wstrb[g*SB + b]) mem[o + b] <= s_req_wdata[g*DW + b*8 +: 8];
          rng = xsn(rng);
          lat = LMIN + rng % (LMAX - LMIN + 1);
          due = scyc + lat;
          if (q_n != 0 && q_due[(q_wr + QD - 1) % QD] > due) due = q_due[(q_wr + QD - 1) % QD];
          q_due[q_wr] <= due;
          q_e[q_wr]   <= pe;
          q_d[q_wr]   <= (s_req_write[g] || pe) ? '0 : d;
          q_wr <= (q_wr + 1) % QD;
          n = n + 1;
        end
        q_n <= n;
      end
    end
  end

  // ---------------------------------------------------------------- competing masters
  for (g = NP; g < NM; g++) begin : g_comp
    logic v_q, w_q, rr_q;
    logic [31:0] a_q;
    logic [DW-1:0] d_q;
    logic [SB-1:0] st_q;
    int unsigned rng;
    logic out_q;
    assign m_req_valid[g] = v_q;
    assign m_req_write[g] = w_q;
    assign m_req_addr[g*32 +: 32] = a_q;
    assign m_req_wdata[g*DW +: DW] = d_q;
    assign m_req_wstrb[g*SB +: SB] = st_q;
    assign m_rsp_ready[g] = rr_q;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        v_q <= 1'b0; w_q <= 1'b0; a_q <= '0; d_q <= '0; st_q <= '0; rr_q <= 1'b0; out_q <= 1'b0;
        rng = seed * 32'h9E37_79B9 + 32'(g) * 7919 + 11;
      end else begin
        rng = xsn(rng); rr_q <= (rng % 100) >= bp;
        if (m_req_valid[g] && m_req_ready[g]) out_q <= 1'b1;
        else if (m_rsp_valid[g] && m_rsp_ready[g]) out_q <= 1'b0;
        if (!v_q || m_req_ready[g]) begin
          rng = xsn(rng);
          if (int'(g - NP) < int'(nc_active) && (rng % 100) < 70) begin
            v_q <= 1'b1;
            rng = xsn(rng); w_q <= rng[0];
            // scratch: top 4 KiB of MEM0 or MEM1
            rng = xsn(rng);
            a_q <= (rng[1] ? 32'h1001_3000 : 32'h1000_3000) + 32'(((rng >> 4) % (4096 / SB)) * SB);
            for (int k = 0; k < DW / 32; k++) begin rng = xsn(rng); d_q[k*32 +: 32] <= rng; end
            rng = xsn(rng); st_q <= (rng % 2) ? '1 : SB'(rng >> 4);
          end else v_q <= 1'b0;
        end
      end
    end
  end
  // expected memory: competing writes at acceptance (no other writer of those bytes)
  always @(posedge clk) if (rst_n)
    for (int m = NP; m < NM; m++)
      if (m_req_valid[m] && m_req_ready[m]) begin
        n_comp_acc <= n_comp_acc + 1;
        if (m_req_write[m]) begin
          int o;
          o = goff(m_req_addr[m*32 +: 32]);
          if (!(poison >= 0 && o == poison))
            for (int b = 0; b < SB; b++) if (m_req_wstrb[m*SB + b]) exp[o + b] = m_req_wdata[m*DW + b*8 +: 8];
        end
      end

  // ---------------------------------------------------------------- DMA write monitor
  always @(posedge clk) if (rst_n) begin
    for (int p = 0; p < NP; p++)
      if (m_req_valid[p]) begin
        logic [31:0] a;
        a = m_req_addr[p*32 +: 32];
        if (!in_xfer) begin
          errors++; $display("TB_DMA ERROR DMA request while no transfer is active a=%h cyc=%0d", a, cyc);
        end else if (m_req_ready[p]) begin
          if (m_req_write[p]) begin
            n_dma_wr++;
            if (x_rd_err_seen && ENGINE == 0) begin
              errors++; $display("TB_DMA ERROR write issued after a read error");
            end
            for (int b = 0; b < SB; b++)
              if (m_req_wstrb[p*SB + b]) begin
                logic [32:0] ba;
                ba = {1'b0, a} + 33'(b);
                if (ba < {1'b0, x_dst} || ba >= {1'b0, x_dst} + {1'b0, x_len}) begin
                  errors++; $display("TB_DMA ERROR write outside destination: byte %h dst=%h len=%0d", ba, x_dst, x_len);
                end else begin
                  int so;
                  so = goff(x_src + 32'(ba[31:0] - x_dst));
                  if (so >= 0 && m_req_wdata[p*DW + b*8 +: 8] !== exp[so]) begin
                    errors++; $display("TB_DMA ERROR write data byte %h = %h, source byte is %h", ba,
                                       m_req_wdata[p*DW + b*8 +: 8], exp[so]);
                  end
                end
              end
          end else n_dma_rd++;
        end
      end
    for (int p = 0; p < NP; p++)
      if (m_rsp_valid[p] && m_rsp_ready[p] && m_rsp_error[p] && !m_req_write[p]) x_rd_err_seen = 1'b1;
  end

  // ---------------------------------------------------------------- register bus tasks
  task automatic rb_write(input logic [11:0] a, input logic [31:0] d, output logic e);
    @(negedge clk); rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d;
    #1 e = rb_err;                       // response is valid during the strobe cycle
    @(posedge clk); #1 rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  task automatic rb_read(input logic [11:0] a, output logic [31:0] d, output logic e);
    @(negedge clk); rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a;
    #1 d = rb_rdata; e = rb_err;
    @(posedge clk); #1 rb_sel = 1'b0;
  endtask
  task automatic chk(input logic c, input string msg);
    if (!c) begin errors++; $display("TB_DMA ERROR %s (cyc=%0d)", msg, cyc); end
  endtask

  // full memory comparison
  task automatic compare_mem(input string tag);
    int bad;
    bad = 0;
    for (int i = 0; i < MEMB; i++)
      if (mem[i] !== exp[i]) begin
        if (bad < 4) $display("TB_DMA ERROR [%s] mem byte %0d = %h expected %h", tag, i, mem[i], exp[i]);
        bad++;
      end
    if (bad != 0) begin errors++; $display("TB_DMA ERROR [%s] %0d bytes differ", tag, bad); end
  endtask

  // run one transfer, wait for completion, check status and memory
  //   exp_code: expected ERROR_CODE (0 = success); exp_bytes: -1 = len
  task automatic run(input logic [31:0] src, input logic [31:0] dst, input logic [31:0] len,
                     input logic [3:0] exp_code, input int exp_bytes, input string tag,
                     output int unsigned cycles);
    logic e;
    logic [31:0] st, code, bytes, ea, is;
    int unsigned t0, guard;
    x_src = src; x_dst = dst; x_len = len; x_rd_err_seen = 1'b0;
    rb_write(`DMA_REG_SRC_ADDR, src, e);   chk(!e, {tag, ": SRC write refused"});
    rb_write(`DMA_REG_DST_ADDR, dst, e);   chk(!e, {tag, ": DST write refused"});
    rb_write(`DMA_REG_LENGTH, len, e);     chk(!e, {tag, ": LEN write refused"});
    rb_write(`DMA_REG_INT_STATUS, 32'h3, e);
    in_xfer = 1'b1;
    t0 = cyc;
    rb_write(`DMA_REG_CONTROL, 32'h1, e);  chk(!e, {tag, ": START refused"});
    guard = 0;
    do begin rb_read(`DMA_REG_STATUS, st, e); guard++; end while (st[`DMA_STATUS_BUSY] && guard < 200000);
    cycles = cyc - t0;
    in_xfer = 1'b0;
    chk(guard < 200000, {tag, ": transfer never finished"});
    rb_read(`DMA_REG_ERROR_CODE, code, e);
    rb_read(`DMA_REG_BYTES_DONE, bytes, e);
    rb_read(`DMA_REG_ERROR_ADDR, ea, e);
    rb_read(`DMA_REG_INT_STATUS, is, e);
    if (exp_code == `DMA_ERR_NONE) begin
      chk(st[`DMA_STATUS_DONE] && !st[`DMA_STATUS_ERROR], {tag, ": STATUS not DONE"});
      chk(is == 32'h1, {tag, ": INT_STATUS not DONE"});
      chk(bytes == len, {tag, $sformatf(": BYTES_DONE %0d != %0d", bytes, len)});
    end else begin
      chk(!st[`DMA_STATUS_DONE] && st[`DMA_STATUS_ERROR], {tag, ": STATUS not ERROR"});
      chk(is == 32'h2, {tag, ": INT_STATUS not ERROR"});
      chk(code[3:0] == exp_code, {tag, $sformatf(": ERROR_CODE %0d != %0d", code, exp_code)});
      if (exp_bytes >= 0) chk(bytes == 32'(exp_bytes), {tag, $sformatf(": BYTES_DONE %0d != %0d", bytes, exp_bytes)});
    end
    // apply the DMA effect to the expected memory: the first bytes_done bytes
    for (int i = 0; i < int'(bytes); i++) exp[goff(dst + 32'(i))] = exp[goff(src + 32'(i))];
    // buffered engine: up to MAX_OUT-1 words after a write error may have been
    // written -> take the actual content for that window (documented)
    if (exp_code == `DMA_ERR_WRITE_BUS && ENGINE != 0)
      for (int i = int'(bytes); i < int'(bytes) + MAX_OUT * SB && i < int'(len); i++)
        exp[goff(dst + 32'(i))] = mem[goff(dst + 32'(i))];
    repeat (4) @(posedge clk);
    compare_mem(tag);
  endtask

  // ---------------------------------------------------------------- tests
  int unsigned c;
  logic e;
  logic [31:0] r;
  string test;
  int unsigned ntrans, total_bytes, total_cycles;

  task automatic t_directed();
    // one word, multiword, every length 1..3*SB+1 with all alignments of tail
    run(32'h1000_0000, 32'h1001_0000, 32'(SB), 0, -1, "one-word", c);
    run(32'h1000_0100, 32'h1001_0400, 32'd256, 0, -1, "multi-word", c);
    for (int l = 1; l <= 3 * SB + 1; l++)
      run(32'h1000_0800 + 32'(l * 64), 32'h1001_0800 + 32'(l * 64), 32'(l), 0, -1, $sformatf("len%0d", l), c);
    run(32'h1000_1000, 32'h2000_0000, 32'd1024, 0, -1, "sram->tspm", c);
    run(32'h2000_0000, 32'h1000_2000, 32'd1024, 0, -1, "tspm->sram", c);
    run(32'h1000_1000, 32'h1000_2400, 32'd700, 0, -1, "same-bank", c);
    // large copy: throughput
    run(32'h1000_0000, 32'h1001_0000, 32'd4096, 0, -1, "4KiB", c);
    $display("TB_DMA PERF copy4k cycles=%0d bytes_per_cycle=%f", c, 4096.0 / real'(c));
    // queue saturation coverage: the buffered engine's FIFO must have filled to
    // its credit limit (single port: one burst; dual port: up to FIFO_DEPTH)
    if (ENGINE != 0) begin
      $display("TB_DMA FIFO max occupancy=%0d (depth %0d, burst %0d)", fifo_max, FIFO_DEPTH, BURST);
      chk(fifo_max <= 8'(FIFO_DEPTH), "FIFO occupancy above its depth");
      chk(fifo_max >= 8'((DUAL_PORT != 0) ? 2 : ((BURST < FIFO_DEPTH) ? BURST : FIFO_DEPTH)),
          "FIFO never reached its expected fill level (queue saturation not exercised)");
    end
  endtask

  task automatic t_errors();
    run(32'h1000_0000, 32'h1001_0000, 32'd0, `DMA_ERR_ZERO_LENGTH, 0, "zero-len", c);
    run(32'h1000_0000, 32'h1001_0000, 32'h0001_0001, `DMA_ERR_LENGTH, 0, "too-long", c);
    if (SB > 1) begin
      run(32'h1000_0001, 32'h1001_0000, 32'd16, `DMA_ERR_SRC_ALIGN, 0, "src-align", c);
      run(32'h1000_0000, 32'h1001_0002, 32'd16, `DMA_ERR_DST_ALIGN, 0, "dst-align", c);
    end
    run(32'hFFFF_FF00, 32'h1001_0000, 32'h0000_0200, `DMA_ERR_SRC_OVERFLOW, 0, "src-overflow", c);
    run(32'h1000_0000, 32'hFFFF_FFF0, 32'h0000_0020, `DMA_ERR_DST_OVERFLOW, 0, "dst-overflow", c);
    run(32'h1000_0000, 32'h1000_0010, 32'd64, `DMA_ERR_OVERLAP, 0, "overlap-fwd", c);
    run(32'h1000_0040, 32'h1000_0000, 32'd128, `DMA_ERR_OVERLAP, 0, "overlap-bwd", c);
    run(32'h1000_0040, 32'h1000_0040, 32'd8, `DMA_ERR_OVERLAP, 0, "overlap-same", c);
    // invalid source / destination (unmapped -> decode error)
    run(32'h3000_0000, 32'h1001_0000, 32'd64, `DMA_ERR_READ_BUS, 0, "bad-src", c);
    rb_read(`DMA_REG_ERROR_ADDR, r, e); chk(r == 32'h3000_0000, "ERROR_ADDR of bad source");
    run(32'h1000_0000, 32'h3000_0000, 32'd64, `DMA_ERR_WRITE_BUS, 0, "bad-dst", c);
    rb_read(`DMA_REG_ERROR_ADDR, r, e); chk(r == 32'h3000_0000, "ERROR_ADDR of bad destination");
    // source runs off the end of MEM2 into unmapped space: prefix is copied
    run(32'h2000_0F00, 32'h1000_1800, 32'd512, `DMA_ERR_READ_BUS, 256, "src-runs-off", c);
    // slave error in the middle of the source (read) and destination (write)
    poison = goff(32'h1000_0420);
    run(32'h1000_0400, 32'h1001_0400, 32'd128, `DMA_ERR_READ_BUS, 32, "read-slave-error", c);
    rb_read(`DMA_REG_ERROR_ADDR, r, e); chk(r == 32'h1000_0420, "ERROR_ADDR of slave read error");
    poison = goff(32'h1001_0640);
    run(32'h1000_0600, 32'h1001_0600, 32'd256, `DMA_ERR_WRITE_BUS, 64, "write-slave-error", c);
    rb_read(`DMA_REG_ERROR_ADDR, r, e); chk(r == 32'h1001_0640, "ERROR_ADDR of slave write error");
    poison = -1;
    // a good transfer after the errors
    run(32'h1000_0400, 32'h1001_0400, 32'd200, 0, -1, "after-errors", c);
  endtask

  task automatic t_busy();
    logic [31:0] st;
    // start a long transfer, try to modify it while busy
    x_src = 32'h1000_0000; x_dst = 32'h1001_0000; x_len = 32'd2048; x_rd_err_seen = 1'b0;
    rb_write(`DMA_REG_SRC_ADDR, x_src, e); rb_write(`DMA_REG_DST_ADDR, x_dst, e);
    rb_write(`DMA_REG_LENGTH, x_len, e);
    in_xfer = 1'b1;
    rb_write(`DMA_REG_CONTROL, 32'h1, e); chk(!e, "busy: start");
    rb_write(`DMA_REG_SRC_ADDR, 32'h1000_2000, e); chk(e, "busy: SRC write not refused");
    rb_write(`DMA_REG_DST_ADDR, 32'h1000_2000, e); chk(e, "busy: DST write not refused");
    rb_write(`DMA_REG_LENGTH, 32'd4, e);           chk(e, "busy: LEN write not refused");
    rb_write(`DMA_REG_CONTROL, 32'h3, e);          chk(e, "busy: START|ABORT not refused");
    rb_write(`DMA_REG_STATUS, 32'h0, e);           chk(e, "RO STATUS write not refused");
    rb_write(12'h0FC, 32'h0, e);                   chk(e, "unmapped offset not refused");
    rb_read(`DMA_REG_SRC_ADDR, r, e); chk(r == x_src && !e, "busy: SRC changed");
    rb_read(`DMA_REG_LENGTH, r, e);   chk(r == x_len && !e, "busy: LEN changed");
    do rb_read(`DMA_REG_STATUS, st, e); while (st[0]);
    in_xfer = 1'b0;
    chk(st[`DMA_STATUS_DONE], "busy: transfer did not complete");
    rb_read(`DMA_REG_BYTES_DONE, r, e); chk(r == x_len, "busy: bytes");
    for (int i = 0; i < 2048; i++) exp[goff(x_dst + 32'(i))] = exp[goff(x_src + 32'(i))];
    repeat (4) @(posedge clk);
    compare_mem("busy-protection");
    rb_read(`DMA_REG_ID, r, e); chk(r == `DMA_ID_VALUE, "ID register");
    rb_read(`DMA_REG_INFO, r, e); chk(r[7:0] == 8'(SB) && r[8] == 1'(ENGINE), "INFO register");
  endtask

  task automatic t_irq();
    logic [31:0] st;
    // completion interrupt enabled, error interrupt masked
    rb_write(`DMA_REG_INT_ENABLE, 32'h1, e);
    run(32'h1000_0000, 32'h1001_0000, 32'd64, 0, -1, "irq-done", c);
    chk(irq, "completion irq not asserted");
    rb_write(`DMA_REG_INT_STATUS, 32'h1, e);       // W1C
    @(posedge clk); #1 chk(!irq, "irq not cleared by W1C");
    run(32'h1000_0000, 32'h1001_0000, 32'd0, `DMA_ERR_ZERO_LENGTH, 0, "irq-err-masked", c);
    chk(!irq, "masked error irq asserted");
    rb_write(`DMA_REG_INT_ENABLE, 32'h2, e);
    @(posedge clk); #1 chk(irq, "error irq not asserted after enabling");
    rb_write(`DMA_REG_INT_STATUS, 32'h2, e);
    @(posedge clk); #1 chk(!irq, "error irq not cleared");
    rb_write(`DMA_REG_INT_ENABLE, 32'h0, e);
  endtask

  task automatic t_abort();
    logic [31:0] st, bytes, code;
    x_src = 32'h1000_0000; x_dst = 32'h1001_0000; x_len = 32'd4096; x_rd_err_seen = 1'b0;
    rb_write(`DMA_REG_SRC_ADDR, x_src, e); rb_write(`DMA_REG_DST_ADDR, x_dst, e);
    rb_write(`DMA_REG_LENGTH, x_len, e);
    in_xfer = 1'b1;
    rb_write(`DMA_REG_CONTROL, 32'h1, e);
    repeat (300) @(posedge clk);
    rb_write(`DMA_REG_CONTROL, 32'h2, e); chk(!e, "abort refused");
    do rb_read(`DMA_REG_STATUS, st, e); while (st[0]);
    in_xfer = 1'b0;
    rb_read(`DMA_REG_ERROR_CODE, code, e);
    rb_read(`DMA_REG_BYTES_DONE, bytes, e);
    chk(st[`DMA_STATUS_ERROR] && st[`DMA_STATUS_ABORTED] && code == `DMA_ERR_ABORTED, "abort status");
    chk(bytes > 0 && bytes < x_len && bytes % SB == 0, $sformatf("abort bytes_done=%0d", bytes));
    for (int i = 0; i < int'(bytes); i++) exp[goff(x_dst + 32'(i))] = exp[goff(x_src + 32'(i))];
    repeat (4) @(posedge clk);
    compare_mem("abort");
    rb_write(`DMA_REG_CONTROL, 32'h2, e); chk(!e, "abort while idle must be harmless");
    run(32'h1000_0000, 32'h1001_0000, 32'd96, 0, -1, "after-abort", c);
  endtask

  task automatic t_reset();
    logic [31:0] st;
    x_src = 32'h1000_0000; x_dst = 32'h1001_0000; x_len = 32'd2048; x_rd_err_seen = 1'b0;
    rb_write(`DMA_REG_SRC_ADDR, x_src, e); rb_write(`DMA_REG_DST_ADDR, x_dst, e);
    rb_write(`DMA_REG_LENGTH, x_len, e); rb_write(`DMA_REG_INT_ENABLE, 32'h3, e);
    in_xfer = 1'b1;
    rb_write(`DMA_REG_CONTROL, 32'h1, e);
    repeat (157) @(posedge clk);
    #3 rst_n = 1'b0;                          // asynchronous reset in the middle of the copy
    in_xfer = 1'b0;                           // from here on any DMA request is spurious
    repeat (3) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    // the destination prefix written before reset is unknown to the model:
    // adopt the actual content of the destination range (reset cancellation)
    for (int i = 0; i < 2048; i++) exp[goff(x_dst + 32'(i))] = mem[goff(x_dst + 32'(i))];
    repeat (50) @(posedge clk);
    chk(!dma_busy && !irq, "DMA not idle / irq after reset");
    rb_read(`DMA_REG_STATUS, st, e);   chk(st == 32'h0, "STATUS not reset");
    rb_read(`DMA_REG_SRC_ADDR, st, e); chk(st == 32'h0, "SRC not reset");
    rb_read(`DMA_REG_BYTES_DONE, st, e); chk(st == 32'h0, "BYTES_DONE not reset");
    compare_mem("reset");
    run(32'h1000_0000, 32'h1001_0000, 32'd2048, 0, -1, "after-reset", c);
  endtask

  task automatic t_random(input int n);
    int unsigned rng;
    rng = seed * 32'h2545_F491 + 99;
    total_bytes = 0; total_cycles = 0;
    for (int i = 0; i < n; i++) begin
      logic [31:0] s, d, l;
      int sr, dr;
      rng = xsn(rng); l = 32'(1 + rng % 700);
      rng = xsn(rng); sr = rng % 3;
      rng = xsn(rng); dr = rng % 3;
      // regions: MEM0/MEM1 lower 12 KiB, MEM2 4 KiB; avoid overlap by halves
      rng = xsn(rng);
      s = (sr == 0 ? 32'h1000_0000 : sr == 1 ? 32'h1001_0000 : 32'h2000_0000) + 32'(((rng >> 3) % 64) * SB);
      rng = xsn(rng);
      d = (dr == 0 ? 32'h1000_1800 : dr == 1 ? 32'h1001_1800 : 32'h2000_0800) + 32'(((rng >> 3) % 64) * SB);
      if (dr == 2) l = (l > 1500) ? 32'd1500 : l;
      if (sr == 2 && l > 2000) l = 2000;
      run(s, d, l, 0, -1, $sformatf("rnd%0d", i), c);
      total_bytes += l; total_cycles += c;
    end
    $display("TB_DMA PERF random transfers=%0d bytes=%0d cycles=%0d bytes_per_cycle=%f", n, total_bytes,
             total_cycles, real'(total_bytes) / real'(total_cycles));
  endtask

  initial begin
    int unsigned v;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("bp=%d", bp)) bp = 20;
    if (!$value$plusargs("ntrans=%d", ntrans)) ntrans = 60;
    if (!$value$plusargs("nc_active=%d", nc_active)) nc_active = NC;
    if (!$value$plusargs("test=%s", test)) test = "all";
    errors = 0; poison = -1; in_xfer = 1'b0; cyc = 0; n_dma_wr = 0; n_dma_rd = 0; n_comp_acc = 0;
    begin
      int unsigned rng;
      rng = seed * 32'h1B87_3593 + 5;
      for (int i = 0; i < MEMB; i++) begin rng = xsn(rng); mem[i] = rng[7:0]; exp[i] = rng[7:0]; end
    end
    $display("TB_DMA config DW=%0d ENGINE=%0d FIFO=%0d BURST=%0d DUAL=%0d MAX_OUT=%0d NC=%0d ARB=%0d LAT=%0d..%0d bp=%0d seed=%0d test=%s",
             DW, ENGINE, FIFO_DEPTH, BURST, DUAL_PORT, MAX_OUT, NC, ARB, LMIN, LMAX, bp, seed, test);
    repeat (3) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    repeat (2) @(posedge clk);
    if (test == "all" || test == "directed") t_directed();
    if (test == "all" || test == "errors")   t_errors();
    if (test == "all" || test == "busy")     t_busy();
    if (test == "all" || test == "irq")      t_irq();
    if (test == "all" || test == "abort")    t_abort();
    if (test == "all" || test == "reset")    t_reset();
    if (test == "all" || test == "random")   t_random(ntrans);
    if (test == "perf") begin
      run(32'h1000_0000, 32'h1001_0000, 32'd4096, 0, -1, "perf-4KiB-bank-to-bank", c);
      $display("TB_DMA PERF copy4k_xbank cycles=%0d bytes_per_cycle=%f", c, 4096.0 / real'(c));
      run(32'h1000_0000, 32'h1000_1800, 32'd4096, 0, -1, "perf-4KiB-same-bank", c);
      $display("TB_DMA PERF copy4k_samebank cycles=%0d bytes_per_cycle=%f", c, 4096.0 / real'(c));
    end
    repeat (20) @(posedge clk);
    v = 0;
    for (int i = 0; i < NM + NS; i++) v += viol[i];
    $display("TB_DMA stats dma_reads=%0d dma_writes=%0d competing_accepts=%0d", n_dma_rd, n_dma_wr, n_comp_acc);
    if (errors == 0 && v == 0) $display("TB_DMA RESULT PASS protocol_violations=0");
    else begin
      $display("TB_DMA RESULT FAIL errors=%0d protocol_violations=%0d", errors, v);
      $fatal(1, "tb_dma failed");
    end
    $finish;
  end
endmodule

`default_nettype wire
