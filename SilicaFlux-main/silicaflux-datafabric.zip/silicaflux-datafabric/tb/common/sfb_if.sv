// =============================================================================
// SilicaFlux DataFabric :: sfb_if -- SFB2 interface bundle (verification use)
//
// Convenience bundle with master / slave / monitor modports for testbenches and
// bind-style checkers.  Synthesizable DataFabric RTL uses flat ports instead
// (SilicaFlux-V coding rule 1: the Yosys 0.33 flow does not accept interfaces),
// exactly as the SRAM Wrapper Library does with its sram_if.
// =============================================================================
`default_nettype none

interface sfb_if #(
  parameter int AW = 32,
  parameter int DW = 32
) (
  input wire logic clk,
  input wire logic rst_n
);
  localparam int SB = DW / 8;
  logic          req_valid, req_ready, req_write;
  logic [AW-1:0] req_addr;
  logic [DW-1:0] req_wdata;
  logic [SB-1:0] req_wstrb;
  logic          rsp_valid, rsp_ready, rsp_error;
  logic [DW-1:0] rsp_rdata;

  modport master  (input clk, rst_n, req_ready, rsp_valid, rsp_rdata, rsp_error,
                   output req_valid, req_write, req_addr, req_wdata, req_wstrb, rsp_ready);
  modport slave   (input clk, rst_n, req_valid, req_write, req_addr, req_wdata, req_wstrb, rsp_ready,
                   output req_ready, rsp_valid, rsp_rdata, rsp_error);
  modport monitor (input clk, rst_n, req_valid, req_ready, req_write, req_addr, req_wdata, req_wstrb,
                   rsp_valid, rsp_ready, rsp_rdata, rsp_error);
endinterface

`default_nettype wire
