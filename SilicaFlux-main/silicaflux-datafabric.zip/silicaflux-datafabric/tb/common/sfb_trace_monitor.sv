// =============================================================================
// SilicaFlux DataFabric :: sfb_trace_monitor -- transaction trace writer (sim only)
//
// Watches NM master ports of an SFB2 fabric and writes one CSV line per event
// in the MemoryLab canonical trace format (silicaflux-memorylab
// python/memorylab/trace_import.py) extended with DataFabric columns:
//   cycle,event,master,id,addr,op,size,bank,slave,error,stall_cycles
// event: ISSUE (first cycle a request is valid), ACCEPT (request handshake),
//        CONFLICT (cycle in which the request lost arbitration), RESPONSE
//        (response handshake).  id = per-master sequence number; op = R/W;
//        size = bytes enabled by wstrb (reads: full width); slave = index from
//        SLV_BASE/SLV_MASK (-1 unmapped); stall_cycles on ACCEPT = cycles from
//        ISSUE to ACCEPT, on RESPONSE = cycles from ACCEPT to RESPONSE.
// Enabled by +trace=<file>; writes nothing otherwise.
// =============================================================================
`default_nettype none

module sfb_trace_monitor #(
  parameter int              NM       = 2,
  parameter int              NS       = 2,
  parameter int              DW       = 32,
  parameter logic [NS*32-1:0] SLV_BASE = '0,
  parameter logic [NS*32-1:0] SLV_MASK = '0,
  localparam int             SB       = DW / 8
) (
  input wire logic             clk,
  input wire logic             rst_n,
  input wire logic [NM-1:0]    req_valid,
  input wire logic [NM-1:0]    req_ready,
  input wire logic [NM-1:0]    req_write,
  input wire logic [NM*32-1:0] req_addr,
  input wire logic [NM*SB-1:0] req_wstrb,
  input wire logic [NM-1:0]    rsp_valid,
  input wire logic [NM-1:0]    rsp_ready,
  input wire logic [NM-1:0]    rsp_error,
  input wire logic [NM-1:0]    arb_loss,
  output logic [63:0]          cycle
);
`ifndef SYNTHESIS
  int          fd;
  string       fname;
  logic [NM-1:0] pend;
  longint      t_issue [0:NM-1];
  longint      t_acc   [0:NM-1];
  int          seq     [0:NM-1];
  logic [31:0] o_addr  [0:NM-1];
  logic        o_w     [0:NM-1];
  int          o_sz    [0:NM-1];
  int          o_sl    [0:NM-1];

  function automatic int slave_of(input logic [31:0] a);
    slave_of = -1;
    for (int s = NS - 1; s >= 0; s--) if ((a & SLV_MASK[s*32 +: 32]) == SLV_BASE[s*32 +: 32]) slave_of = s;
  endfunction
  function automatic int popc(input logic [SB-1:0] v);
    popc = 0;
    for (int b = 0; b < SB; b++) popc += int'(v[b]);
  endfunction

  initial begin
    fd = 0;
    if ($value$plusargs("trace=%s", fname)) begin
      fd = $fopen(fname, "w");
      $fwrite(fd, "cycle,event,master,id,addr,op,size,bank,slave,error,stall_cycles\n");
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cycle <= 0;
      pend  <= '0;
      for (int m = 0; m < NM; m++) seq[m] <= 0;
    end else begin
      cycle <= cycle + 1;
      for (int m = 0; m < NM; m++) begin
        logic [31:0] a;
        int sz, sl;
        a  = req_addr[m*32 +: 32];
        sz = req_write[m] ? popc(req_wstrb[m*SB +: SB]) : SB;
        sl = slave_of(a);
        if (rsp_valid[m] && rsp_ready[m] && fd != 0)
          $fwrite(fd, "%0d,RESPONSE,%0d,%0d,%0d,%s,%0d,%0d,%0d,%0d,%0d\n", cycle, m, seq[m] - 1, o_addr[m],
                  o_w[m] ? "W" : "R", o_sz[m], o_sl[m], o_sl[m], rsp_error[m], cycle - t_acc[m]);
        if (req_valid[m] && !pend[m]) begin
          t_issue[m] = cycle;
          if (fd != 0) $fwrite(fd, "%0d,ISSUE,%0d,%0d,%0d,%s,%0d,%0d,%0d,0,0\n", cycle, m, seq[m], a,
                               req_write[m] ? "W" : "R", sz, sl, sl);
        end
        if (req_valid[m] && arb_loss[m] && fd != 0)
          $fwrite(fd, "%0d,CONFLICT,%0d,%0d,%0d,%s,%0d,%0d,%0d,0,0\n", cycle, m, seq[m], a,
                  req_write[m] ? "W" : "R", sz, sl, sl);
        if (req_valid[m] && req_ready[m]) begin
          if (fd != 0) $fwrite(fd, "%0d,ACCEPT,%0d,%0d,%0d,%s,%0d,%0d,%0d,0,%0d\n", cycle, m, seq[m], a,
                               req_write[m] ? "W" : "R", sz, sl, sl, cycle - (pend[m] ? t_issue[m] : cycle));
          t_acc[m] <= cycle; o_addr[m] <= a; o_w[m] <= req_write[m]; o_sz[m] <= sz; o_sl[m] <= sl;
          seq[m] <= seq[m] + 1;
          pend[m] <= 1'b0;
        end else if (req_valid[m]) pend[m] <= 1'b1;
        else pend[m] <= 1'b0;
      end
    end
  end
  final if (fd != 0) $fclose(fd);
`else
  assign cycle = '0;
`endif
endmodule

`default_nettype wire
