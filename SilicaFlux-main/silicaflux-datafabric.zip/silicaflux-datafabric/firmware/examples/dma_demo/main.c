/* =============================================================================
 * SilicaFlux DataFabric -- DMA demonstration / acceptance firmware
 * Runs on SilicaFlux-V + DataFabric (rtl/soc/sfv_soc_df.sv), loaded into SRAM
 * bank 0 (boot mode 3, or SPI / JTAG boot).  Every result is checked against
 * the CPU's own computation (C golden models from silicaflux-v sfv_accel.c).
 *
 *   D1 identity             D5 interrupt-driven completion / error
 *   D2 SRAM->SRAM copies    D6 CPU->SRAM->DMA->TSPM->tensor->TSPM->DMA->SRAM->CPU
 *   D3 errors + validation  D7 same flow through the vector engine
 *   D4 busy protection,     D8 DMA vs CPU contention, CPU memcpy vs DMA cycles,
 *      abort                   DataFabric performance counters
 *                           D9 DMA competing with the tensor engine for the TSPM
 * Output: UART log, TEST_STATUS (PASS/FAIL + number of failures).
 * ===========================================================================*/
#include "sfv_accel.h"
#include "sfv_lib.h"
#include "silicaflux_dma.h"

/* buffers at fixed addresses in SRAM banks 1 and 2 (code/data in bank 0,
 * stack at the top of bank 3) so that bank traffic is predictable */
#define BUF_A   0x10008000u     /* bank 1, 16 KiB */
#define BUF_B   0x10010000u     /* bank 2, 16 KiB */
#define BUF_C   0x1000C000u     /* bank 1 upper 16 KiB */
#define BUF_D   0x10014000u     /* bank 2 upper 16 KiB */
#define W32(a)  ((volatile uint32_t *)(uintptr_t)(a))
#define B8(a)   ((volatile uint8_t *)(uintptr_t)(a))

#define PERF(off) REG32(SFV_DF_DFPERF_BASE + (off))

static uint32_t fails, checks, seed = 0xDA7AF1B5u;

static void check(int ok, uint32_t id, uint32_t got, uint32_t exp) {
  checks++;
  if (!ok) {
    fails++;
    if (fails <= 20) {
      uart_puts("  FAIL id=");
      uart_puthex(id);
      uart_puts(" got=");
      uart_puthex(got);
      uart_puts(" exp=");
      uart_puthex(exp);
      uart_puts("\n");
    }
  }
}
#define CHECK_EQ(id, got, exp)       \
  do {                               \
    uint32_t _g = (uint32_t)(got), _e = (uint32_t)(exp); \
    check(_g == _e, (id), _g, _e);   \
  } while (0)

static void section(const char *name) {
  uart_puts("[");
  uart_puts(name);
  uart_puts("] checks=");
  uart_putdec(checks);
  uart_puts(" fails=");
  uart_putdec(fails);
  uart_puts("\n");
}

/* ---------------------------------------------------------------- traps */
volatile uint32_t n_exc, last_cause, n_ext;

__attribute__((interrupt("machine"))) void trap_entry(void) {
  uint32_t cause = csr_read(mcause);
  if (cause & 0x80000000u) {
    if ((cause & 0x1Fu) == 11u) {
      uint32_t c = INTC_CLAIM;
      if (c == SFV_DF_IRQ_DMA + 1u) dma_isr();
      else INTC_ENABLE = 0;
      n_ext++;
    }
    return;
  }
  n_exc++;                                   /* expected bus errors: skip the access */
  last_cause = cause;
  csr_write(mepc, csr_read(mepc) + 4u);
}

static void fill(uint32_t a, uint32_t nwords) {
  for (uint32_t i = 0; i < nwords; i++) W32(a)[i] = rand32(&seed);
}
static uint32_t cmp_bytes(uint32_t a, uint32_t b, uint32_t n) {
  uint32_t bad = 0;
  for (uint32_t i = 0; i < n; i++) bad += (B8(a)[i] != B8(b)[i]);
  return bad;
}

/* ---------------------------------------------------------------- D1 */
static void d1_identity(void) {
  section("D1 identity");
  CHECK_EQ(0x101, dma_init(), 0);
  uint32_t info = dma_info();
  CHECK_EQ(0x102, (info & DMA_INFO_DW_BYTES_MASK) >> DMA_INFO_DW_BYTES_SHIFT, 4);
  CHECK_EQ(0x103, (info & DMA_INFO_VERSION_MASK) >> DMA_INFO_VERSION_SHIFT, 1);
  CHECK_EQ(0x104, dma_get_status(), 0);
  CHECK_EQ(0x105, PERF(DFP_INFO_OFF) & 0xFFu, 4);          /* 4 crossbar masters counted */
  uart_puts("  DMA INFO=");
  uart_puthex(info);
  uart_puts("\n");
}

/* ---------------------------------------------------------------- D2 */
static void d2_copies(void) {
  section("D2 SRAM->SRAM copies");
  fill(BUF_A, 1024);
  for (uint32_t i = 0; i < 1024; i++) W32(BUF_B)[i] = 0;
  CHECK_EQ(0x201, dma_copy(BUF_B, BUF_A, 4096), 0);
  CHECK_EQ(0x202, cmp_bytes(BUF_A, BUF_B, 4096), 0);
  /* byte-accurate lengths: bytes after the end must be untouched */
  for (uint32_t len = 1; len <= 9; len++) {
    uint32_t d = BUF_D + 64u * len;
    for (uint32_t i = 0; i < 4; i++) W32(d)[i] = 0xA5A5A5A5u;
    CHECK_EQ(0x210 + len, dma_copy(d, BUF_A + 4u * len, len), 0);
    CHECK_EQ(0x220 + len, cmp_bytes(d, BUF_A + 4u * len, len), 0);
    CHECK_EQ(0x230 + len, B8(d)[len], 0xA5);
  }
  /* source crossing the bank 1 / bank 2 boundary */
  CHECK_EQ(0x240, dma_copy(BUF_C, BUF_B - 512u, 1024), 0);
  CHECK_EQ(0x241, cmp_bytes(BUF_C, BUF_B - 512u, 1024), 0);
  /* boot ROM as a source */
  CHECK_EQ(0x242, dma_copy(BUF_D, SFV_DF_BOOT_ROM_BASE, 256), 0);
  CHECK_EQ(0x243, cmp_bytes(BUF_D, SFV_DF_BOOT_ROM_BASE, 256), 0);
}

/* ---------------------------------------------------------------- D3 */
static void hw_expect(uint32_t id, uint32_t src, uint32_t dst, uint32_t len, int code, uint32_t eaddr) {
  dma_xfer_t x = {src, dst, len};
  dma_status_t st;
  CHECK_EQ(id, dma_configure_raw(&x), 0);
  CHECK_EQ(id + 1, dma_start(), 0);
  CHECK_EQ(id + 2, dma_wait(1000000u, &st), code);
  CHECK_EQ(id + 3, (st.status & DMA_STATUS_ERROR_MASK) != 0, code != 0);
  if (eaddr) CHECK_EQ(id + 4, st.error_addr, eaddr);
}
static void d3_errors(void) {
  section("D3 errors and validation");
  uint32_t gpio_out = GPIO_OUT;
  hw_expect(0x300, BUF_A, BUF_B, 0, DMA_ERR_ZERO_LENGTH, 0);
  hw_expect(0x310, BUF_A + 1u, BUF_B, 16, DMA_ERR_SRC_ALIGN, 0);
  hw_expect(0x320, BUF_A, BUF_B + 2u, 16, DMA_ERR_DST_ALIGN, 0);
  hw_expect(0x330, BUF_A, BUF_A + 8u, 64, DMA_ERR_OVERLAP, 0);
  hw_expect(0x340, 0xFFFFFF00u, BUF_B, 512, DMA_ERR_SRC_OVERFLOW, 0);
  hw_expect(0x350, 0x30000000u, BUF_B, 64, DMA_ERR_READ_BUS, 0x30000000u);          /* unmapped */
  hw_expect(0x360, BUF_A, SFV_DF_GPIO_BASE + 4u, 4, DMA_ERR_WRITE_BUS, SFV_DF_GPIO_BASE + 4u); /* denied */
  hw_expect(0x370, BUF_A, SFV_DF_BOOT_ROM_BASE, 16, DMA_ERR_WRITE_BUS, SFV_DF_BOOT_ROM_BASE);  /* ROM */
  CHECK_EQ(0x380, GPIO_OUT, gpio_out);                       /* the denied write had no effect */
  /* the same descriptors are caught by the driver before touching the hardware */
  dma_xfer_t z = {BUF_A, BUF_B, 0}, ov = {BUF_A, BUF_A + 8u, 64}, pe = {BUF_A, SFV_DF_GPIO_BASE, 4};
  dma_xfer_t un = {0x30000000u, BUF_B, 64};
  CHECK_EQ(0x390, dma_check(&z), DMA_DRV_EINVAL);
  CHECK_EQ(0x391, dma_check(&ov), DMA_DRV_EINVAL);
  CHECK_EQ(0x392, dma_check(&pe), DMA_DRV_ERANGE);
  CHECK_EQ(0x393, dma_check(&un), DMA_DRV_ERANGE);
  /* the engine is healthy afterwards */
  CHECK_EQ(0x394, dma_copy(BUF_B, BUF_A, 128), 0);
  CHECK_EQ(0x395, cmp_bytes(BUF_B, BUF_A, 128), 0);
}

/* ---------------------------------------------------------------- D4 */
static void d4_busy_abort(void) {
  section("D4 busy protection and abort");
  dma_xfer_t x = {BUF_A, BUF_B, 16384};
  dma_status_t st;
  CHECK_EQ(0x401, dma_configure(&x), 0);
  CHECK_EQ(0x402, dma_start(), 0);
  uint32_t e0 = n_exc;
  DMA_REG(DMA_SRC_ADDR_OFF) = BUF_C;                         /* refused: bus error -> trap */
  DMA_REG(DMA_LENGTH_OFF) = 4;                               /* refused */
  DMA_REG(DMA_CONTROL_OFF) = DMA_CONTROL_START_MASK;          /* refused */
  CHECK_EQ(0x403, n_exc - e0, 3);
  CHECK_EQ(0x404, last_cause, 7);                            /* store access fault */
  CHECK_EQ(0x405, DMA_REG(DMA_SRC_ADDR_OFF), BUF_A);
  CHECK_EQ(0x406, DMA_REG(DMA_LENGTH_OFF), 16384);
  CHECK_EQ(0x407, dma_start(), DMA_DRV_EBUSY);
  for (volatile int i = 0; i < 40; i++) {
  }
  dma_abort();
  CHECK_EQ(0x408, dma_wait(1000000u, &st), DMA_ERR_ABORTED);
  CHECK_EQ(0x409, (st.status & DMA_STATUS_ABORTED_MASK) != 0, 1);
  CHECK_EQ(0x40A, st.bytes_done > 0 && st.bytes_done < 16384 && (st.bytes_done & 3u) == 0, 1);
  CHECK_EQ(0x40B, cmp_bytes(BUF_A, BUF_B, st.bytes_done), 0);   /* written prefix is correct */
  uart_puts("  aborted after bytes=");
  uart_putdec(st.bytes_done);
  uart_puts("\n");
  dma_abort();                                               /* idle: no effect */
  CHECK_EQ(0x40C, dma_copy(BUF_B, BUF_A, 16384), 0);          /* full copy after abort */
  CHECK_EQ(0x40D, cmp_bytes(BUF_A, BUF_B, 16384), 0);
}

/* ---------------------------------------------------------------- D5 */
static void d5_interrupts(void) {
  section("D5 interrupts");
  INTC_ENABLE = 1u << SFV_DF_IRQ_DMA;
  csr_set(mie, MIE_MEIE);
  csr_set(mstatus, MSTATUS_MIE);
  dma_enable_interrupt(DMA_IRQ_DONE | DMA_IRQ_ERROR);
  uint32_t ev0 = dma_isr_events;
  dma_xfer_t x = {BUF_A, BUF_C, 2048};
  CHECK_EQ(0x501, dma_configure(&x), 0);
  CHECK_EQ(0x502, dma_start(), 0);
  while (dma_isr_events == ev0) __asm__ volatile("wfi");
  CHECK_EQ(0x503, dma_isr_last, DMA_IRQ_DONE);
  CHECK_EQ(0x504, cmp_bytes(BUF_A, BUF_C, 2048), 0);
  dma_xfer_t bad = {0x30000000u, BUF_C, 64};
  CHECK_EQ(0x505, dma_configure_raw(&bad), 0);
  CHECK_EQ(0x506, dma_start(), 0);
  while (dma_isr_events == ev0 + 1u) __asm__ volatile("wfi");
  CHECK_EQ(0x507, dma_isr_last, DMA_IRQ_ERROR);
  CHECK_EQ(0x508, dma_pending_interrupt(), 0);               /* acknowledged by the ISR */
  csr_clear(mstatus, MSTATUS_MIE);
  dma_enable_interrupt(0);
  INTC_ENABLE = 0;
}

/* ---------------------------------------------------------------- D6 */
static void d6_tensor(void) {
  section("D6 tensor end-to-end via DMA");
  static const uint32_t ks[] = {4, 16, 64, 256};
  for (uint32_t t = 0; t < 4; t++) {
    uint32_t k = ks[t];
    uint32_t cfgs[2] = {TE_CFG_WB, TE_CFG_WB | TE_CFG_AUNS | TE_CFG_BUNS};
    for (uint32_t m = 0; m < 2; m++) {
      /* CPU initialises the operands in SRAM (A columns, B rows: packed int8) */
      fill(BUF_A, k);                          /* a_cols[k] */
      fill(BUF_A + 0x1000u, k);                /* b_rows[k] */
      /* DMA: SRAM -> tile scratchpad */
      CHECK_EQ(0x600 + 16 * t + 4 * m, dma_copy(SFV_DF_TSPM_BASE + 0x0000u, BUF_A, 4u * k), 0);
      CHECK_EQ(0x601 + 16 * t + 4 * m, dma_copy(SFV_DF_TSPM_BASE + 0x1000u, BUF_A + 0x1000u, 4u * k), 0);
      /* tensor engine (operands only touched after the DMA completed) */
      uint32_t s = te_run(cfgs[m], 0x0000u, 0x1000u, 0x2000u, k, 0, 0, 0);
      CHECK_EQ(0x602 + 16 * t + 4 * m, s & (ACC_DONE | ACC_ERR), ACC_DONE);
      /* DMA: result back to SRAM */
      CHECK_EQ(0x603 + 16 * t + 4 * m, dma_copy(BUF_B, SFV_DF_TSPM_BASE + 0x2000u, 64), 0);
      /* CPU reference */
      int32_t ref[16];
      for (int i = 0; i < 16; i++) ref[i] = 0;
      te_ref((const uint32_t *)(uintptr_t)BUF_A, (const uint32_t *)(uintptr_t)(BUF_A + 0x1000u), k,
             m != 0, m != 0, ref);
      uint32_t bad = 0;
      for (int i = 0; i < 16; i++) bad += (W32(BUF_B)[i] != (uint32_t)ref[i]);
      CHECK_EQ(0x6F0 + t * 2 + m, bad, 0);
    }
  }
  uart_puts("  TE CYCLES(K=256)=");
  uart_putdec(TE_CYCLES);
  uart_puts("\n");
}

/* ---------------------------------------------------------------- D7 */
static void d7_vector(void) {
  section("D7 vector end-to-end via DMA");
  const uint32_t n = 128;
  fill(BUF_A, n);
  fill(BUF_A + 0x1000u, n);
  CHECK_EQ(0x701, dma_copy(SFV_DF_TSPM_BASE + 0x0400u, BUF_A, 4u * n), 0);
  CHECK_EQ(0x702, dma_copy(SFV_DF_TSPM_BASE + 0x0800u, BUF_A + 0x1000u, 4u * n), 0);
  uint32_t ops[3] = {VOP_ADD, VOP_XOR, VOP_MUL};
  for (uint32_t o = 0; o < 3; o++) {
    uint32_t s = ve_run(ops[o], 0, 0x0400u, 0x0800u, 0x0C00u, n, 0);
    CHECK_EQ(0x710 + o, s & (ACC_DONE | ACC_ERR), ACC_DONE);
    CHECK_EQ(0x720 + o, dma_copy(BUF_B, SFV_DF_TSPM_BASE + 0x0C00u, 4u * n), 0);
    uint32_t bad = 0;
    for (uint32_t i = 0; i < n; i++)
      bad += (W32(BUF_B)[i] != ve_ref_elem(ops[o], W32(BUF_A)[i], W32(BUF_A + 0x1000u)[i], 32));
    CHECK_EQ(0x730 + o, bad, 0);
  }
  /* dot product with the result written back to the scratchpad, fetched by DMA */
  uint32_t s = ve_run(VOP_DOT, VE_CMD_WRES, 0x0400u, 0x0800u, 0x0FF0u, n, 0);
  CHECK_EQ(0x740, s & (ACC_DONE | ACC_ERR), ACC_DONE);
  CHECK_EQ(0x741, dma_copy(BUF_B, SFV_DF_TSPM_BASE + 0x0FF0u, 4), 0);
  uint32_t ref = 0;
  for (uint32_t i = 0; i < n; i++) ref += ve_ref_elem(VOP_DOT, W32(BUF_A)[i], W32(BUF_A + 0x1000u)[i], 32);
  CHECK_EQ(0x742, W32(BUF_B)[0], ref);
}

/* ---------------------------------------------------------------- D9 */
/* DMA and tensor engine compete for the tile scratchpad banks.  The engine
 * holding the TSPM lock has priority on every bank (sfv_tile), so its latency
 * must stay exactly 3 + 2K + 4 cycles; the DMA absorbs the conflicts. */
static void d9_dma_vs_tensor(void) {
  section("D9 DMA competing with the tensor engine");
  const uint32_t k = 256;
  fill(BUF_A, k);
  fill(BUF_A + 0x1000u, k);
  fill(BUF_C, 1024);
  CHECK_EQ(0x901, dma_copy(SFV_DF_TSPM_BASE + 0x0000u, BUF_A, 4u * k), 0);
  CHECK_EQ(0x902, dma_copy(SFV_DF_TSPM_BASE + 0x1000u, BUF_A + 0x1000u, 4u * k), 0);
  /* reference: DMA 4 KiB SRAM -> TSPM with the engine idle */
  uint32_t c0 = csr_read(mcycle);
  CHECK_EQ(0x903, dma_copy(SFV_DF_TSPM_BASE + 0x3000u, BUF_C, 4096), 0);
  uint32_t c_idle = csr_read(mcycle) - c0;
  /* start the tensor engine without waiting, then the same DMA copy */
  TE_STATUS = ACC_DONE | ACC_ERR;
  TE_CFG = TE_CFG_WB;
  TE_A_ADDR = 0x0000u;
  TE_B_ADDR = 0x1000u;
  TE_C_ADDR = 0x2000u;
  TE_K = k;
  TE_A_STRIDE = 0;
  TE_B_STRIDE = 0;
  TE_C_STRIDE = 0;
  c0 = csr_read(mcycle);
  TE_CTRL = ACC_START;
  CHECK_EQ(0x904, dma_copy(SFV_DF_TSPM_BASE + 0x3000u, BUF_C, 4096), 0);
  uint32_t c_busy = csr_read(mcycle) - c0;
  uint32_t s;
  do {
    s = TE_STATUS;
  } while (!(s & (ACC_DONE | ACC_ERR)));
  CHECK_EQ(0x905, s & (ACC_DONE | ACC_ERR), ACC_DONE);
  CHECK_EQ(0x906, TE_CYCLES, 3u + 2u * k + 4u);            /* engine latency unaffected */
  CHECK_EQ(0x907, cmp_bytes(SFV_DF_TSPM_BASE + 0x3000u, BUF_C, 4096), 0);
  CHECK_EQ(0x908, dma_copy(BUF_B, SFV_DF_TSPM_BASE + 0x2000u, 64), 0);
  int32_t ref[16];
  for (int i = 0; i < 16; i++) ref[i] = 0;
  te_ref((const uint32_t *)(uintptr_t)BUF_A, (const uint32_t *)(uintptr_t)(BUF_A + 0x1000u), k, 0, 0, ref);
  uint32_t bad = 0;
  for (int i = 0; i < 16; i++) bad += (W32(BUF_B)[i] != (uint32_t)ref[i]);
  CHECK_EQ(0x909, bad, 0);
  CHECK_EQ(0x90A, c_busy >= c_idle, 1);                     /* the DMA, not the engine, waits */
  uart_puts("  4KiB SRAM->TSPM DMA cycles: engine idle=");
  uart_putdec(c_idle);
  uart_puts(" concurrent with TE(K=256)=");
  uart_putdec(c_busy);
  uart_puts(" TE_CYCLES=");
  uart_putdec(TE_CYCLES);
  uart_puts("\n");
}

/* ---------------------------------------------------------------- D8 */
static void print_perf(void) {
  static const char *mn[4] = {"DBG ", "CPUD", "CPUI", "DMA "};
  PERF(DFP_CTRL_OFF) = DFP_CTRL_ENABLE_MASK | DFP_CTRL_SNAPSHOT_MASK;     /* atomic snapshot */
  uart_puts("  DFPERF cycles=");
  uart_putdec(PERF(DFP_CYCLES_LO_OFF));
  uart_puts(" dma_bytes=");
  uart_putdec(PERF(DFP_DMA_BYTES_OFF));
  uart_puts(" dma_busy=");
  uart_putdec(PERF(DFP_DMA_BUSY_OFF));
  uart_puts(" dma_idle=");
  uart_putdec(PERF(DFP_DMA_IDLE_OFF));
  uart_puts("\n");
  for (uint32_t m = 0; m < 4; m++) {
    uart_puts("  DFPERF ");
    uart_puts(mn[m]);
    uart_puts(" reads=");
    uart_putdec(PERF(DFP_READS_OFF(m)));
    uart_puts(" writes=");
    uart_putdec(PERF(DFP_WRITES_OFF(m)));
    uart_puts(" req_stall=");
    uart_putdec(PERF(DFP_REQ_STALL_OFF(m)));
    uart_puts(" arb_loss=");
    uart_putdec(PERF(DFP_ARB_LOSS_OFF(m)));
    uart_puts(" errors=");
    uart_putdec(PERF(DFP_ERRORS_OFF(m)));
    uart_puts("\n");
  }
}

static void d8_contention(void) {
  section("D8 contention and performance");
  /* CPU memcpy vs DMA, 4 KiB bank 1 -> bank 2 */
  fill(BUF_A, 1024);
  uint32_t c0 = csr_read(mcycle);
  for (uint32_t i = 0; i < 1024; i++) W32(BUF_B)[i] = W32(BUF_A)[i];
  uint32_t c_cpu = csr_read(mcycle) - c0;
  CHECK_EQ(0x801, cmp_bytes(BUF_A, BUF_B, 4096), 0);
  c0 = csr_read(mcycle);
  CHECK_EQ(0x802, dma_copy(BUF_D, BUF_A, 4096), 0);
  uint32_t c_dma = csr_read(mcycle) - c0;
  CHECK_EQ(0x803, cmp_bytes(BUF_A, BUF_D, 4096), 0);
  uart_puts("  4KiB copy cycles: cpu_word_loop=");
  uart_putdec(c_cpu);
  uart_puts(" dma(incl. setup+poll)=");
  uart_putdec(c_dma);
  uart_puts("\n");
  /* DMA copies 16 KiB bank 1 -> bank 2 while the CPU checksums bank 1/2 data */
  PERF(DFP_CTRL_OFF) = DFP_CTRL_ENABLE_MASK | DFP_CTRL_CLEAR_MASK;
  fill(BUF_A, 4096);
  uint32_t ref = 0, sum = 0;
  for (uint32_t i = 0; i < 2048; i++) ref += W32(BUF_C)[i] ^ i;
  dma_xfer_t x = {BUF_A, BUF_B, 16384};
  CHECK_EQ(0x804, dma_configure(&x), 0);
  CHECK_EQ(0x805, dma_start(), 0);
  for (uint32_t i = 0; i < 2048; i++) sum += W32(BUF_C)[i] ^ i;   /* concurrent CPU traffic */
  dma_status_t st;
  CHECK_EQ(0x806, dma_wait(10000000u, &st), 0);
  CHECK_EQ(0x807, sum, ref);
  CHECK_EQ(0x808, cmp_bytes(BUF_A, BUF_B, 16384), 0);
  CHECK_EQ(0x809, DMA_REG(DMA_TRANSFERS_OFF) > 10, 1);
  print_perf();
  CHECK_EQ(0x80A, PERF(DFP_DMA_BYTES_OFF), 16384);
  CHECK_EQ(0x80B, PERF(DFP_READS_OFF(3)), 4096);              /* DMA: one read per word */
  CHECK_EQ(0x80C, PERF(DFP_WRITES_OFF(3)), 4096);
  CHECK_EQ(0x80D, PERF(DFP_ARB_LOSS_OFF(3)) + PERF(DFP_ARB_LOSS_OFF(1)) > 0, 1);  /* real contention */
  uart_puts("  DMA ACTIVE_CYCLES=");
  uart_putdec(DMA_REG(DMA_ACTIVE_CYCLES_OFF));
  uart_puts(" STALL_CYCLES=");
  uart_putdec(DMA_REG(DMA_STALL_CYCLES_OFF));
  uart_puts("\n");
}

int main(void) {
  uart_puts("\nSFV-DF DMA demo (SilicaFlux DataFabric)\n");
  d1_identity();
  d2_copies();
  d3_errors();
  d4_busy_abort();
  d5_interrupts();
  d6_tensor();
  d7_vector();
  d9_dma_vs_tensor();
  d8_contention();
  section("done");
  uart_puts("SFV-DF RESULT ");
  uart_puts(fails ? "FAIL" : "PASS");
  uart_puts(" checks=");
  uart_putdec(checks);
  uart_puts(" fails=");
  uart_putdec(fails);
  uart_puts("\n");
  uart_flush();
  test_status(fails ? TEST_FAIL : TEST_PASS, fails);
  return 0;
}
