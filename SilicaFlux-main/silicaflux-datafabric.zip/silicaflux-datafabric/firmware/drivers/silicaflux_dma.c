/* SilicaFlux DataFabric -- DMA driver.  See silicaflux_dma.h. */
#include "silicaflux_dma.h"

volatile uint32_t dma_isr_events, dma_isr_last;

uint32_t dma_info(void) { return DMA_REG(DMA_INFO_OFF); }

int dma_init(void) {
  if (DMA_REG(DMA_ID_OFF) != DMA_ID_VALUE) return DMA_DRV_ENODEV;
  if (DMA_REG(DMA_STATUS_OFF) & DMA_STATUS_BUSY_MASK) return DMA_DRV_EBUSY;
  DMA_REG(DMA_INT_ENABLE_OFF) = 0;
  DMA_REG(DMA_INT_STATUS_OFF) = DMA_IRQ_DONE | DMA_IRQ_ERROR;
  dma_isr_events = 0;
  dma_isr_last = 0;
  return 0;
}

/* Memory the DMA may access: SRAM (all banks, contiguous), the tile
 * scratchpad, and the boot ROM as a source.  The peripheral window is denied
 * by the bus access matrix (MMIO side effects have not been reviewed). */
static int in_region(uint32_t a, uint32_t len, uint32_t base, uint32_t size) {
  return a >= base && len <= size && a - base <= size - len;
}
static int reachable(uint32_t a, uint32_t len, int is_dst) {
  const uint32_t sram_base = SFV_DF_SRAM_BANK0_BASE;
  const uint32_t sram_size = SFV_DF_SRAM_BANK0_SIZE + SFV_DF_SRAM_BANK1_SIZE +
                             SFV_DF_SRAM_BANK2_SIZE + SFV_DF_SRAM_BANK3_SIZE;
  if (in_region(a, len, sram_base, sram_size)) return 1;
  if (in_region(a, len, SFV_DF_TSPM_BASE, SFV_DF_TSPM_SIZE)) return 1;
  if (!is_dst && in_region(a, len, SFV_DF_BOOT_ROM_BASE, SFV_DF_BOOT_ROM_SIZE)) return 1;
  return 0;
}

int dma_check(const dma_xfer_t *x) {
  uint32_t info = dma_info();
  uint32_t dwb = (info & DMA_INFO_DW_BYTES_MASK) >> DMA_INFO_DW_BYTES_SHIFT;
  uint32_t maxl = (info & DMA_INFO_MAX_LEN_LOG2_MASK) >> DMA_INFO_MAX_LEN_LOG2_SHIFT;
  if (x->len == 0 || (maxl < 32 && x->len > (1u << maxl))) return DMA_DRV_EINVAL;
  if (dwb == 0 || ((x->src | x->dst) & (dwb - 1u))) return DMA_DRV_EINVAL;
  uint64_t s_end = (uint64_t)x->src + x->len, d_end = (uint64_t)x->dst + x->len;  /* exclusive ends */
  if (s_end > 0x100000000ull || d_end > 0x100000000ull) return DMA_DRV_EINVAL;      /* wraps 2^32 */
  if ((uint64_t)x->src < d_end && (uint64_t)x->dst < s_end) return DMA_DRV_EINVAL;  /* overlap */
  if (!reachable(x->src, x->len, 0) || !reachable(x->dst, x->len, 1)) return DMA_DRV_ERANGE;
  return 0;
}

int dma_configure_raw(const dma_xfer_t *x) {
  if (DMA_REG(DMA_STATUS_OFF) & DMA_STATUS_BUSY_MASK) return DMA_DRV_EBUSY;
  DMA_REG(DMA_SRC_ADDR_OFF) = x->src;
  DMA_REG(DMA_DST_ADDR_OFF) = x->dst;
  DMA_REG(DMA_LENGTH_OFF) = x->len;
  return 0;
}

int dma_configure(const dma_xfer_t *x) {
  int r = dma_check(x);
  return r ? r : dma_configure_raw(x);
}

int dma_start(void) {
  if (DMA_REG(DMA_STATUS_OFF) & DMA_STATUS_BUSY_MASK) return DMA_DRV_EBUSY;
  DMA_REG(DMA_CONTROL_OFF) = DMA_CONTROL_START_MASK;
  return 0;
}

uint32_t dma_get_status(void) { return DMA_REG(DMA_STATUS_OFF); }

int dma_poll(dma_status_t *st) {
  uint32_t s = DMA_REG(DMA_STATUS_OFF);
  if (s & DMA_STATUS_BUSY_MASK) return DMA_POLL_BUSY;
  if (st) {
    st->status = s;
    st->error = DMA_REG(DMA_ERROR_CODE_OFF);
    st->error_addr = DMA_REG(DMA_ERROR_ADDR_OFF);
    st->bytes_done = DMA_REG(DMA_BYTES_DONE_OFF);
  }
  return (s & DMA_STATUS_ERROR_MASK) ? (int)DMA_REG(DMA_ERROR_CODE_OFF) : 0;
}

int dma_wait(uint32_t max_polls, dma_status_t *st) {
  for (uint32_t i = 0; i < max_polls; i++) {
    int r = dma_poll(st);
    if (r != DMA_POLL_BUSY) return r;
  }
  return DMA_DRV_ETIMEDOUT;
}

void dma_abort(void) { DMA_REG(DMA_CONTROL_OFF) = DMA_CONTROL_ABORT_MASK; }

void dma_enable_interrupt(uint32_t mask) { DMA_REG(DMA_INT_ENABLE_OFF) = mask; }
void dma_clear_interrupt(uint32_t mask) { DMA_REG(DMA_INT_STATUS_OFF) = mask; }
uint32_t dma_pending_interrupt(void) { return DMA_REG(DMA_INT_STATUS_OFF); }

int dma_copy(uint32_t dst, uint32_t src, uint32_t len) {
  dma_xfer_t x = {src, dst, len};
  int r = dma_configure(&x);
  if (r) return r;
  r = dma_start();
  if (r) return r;
  return dma_wait(0x7FFFFFFFu, 0);
}

void dma_isr(void) {
  uint32_t p = DMA_REG(DMA_INT_STATUS_OFF);
  dma_isr_last = p;
  dma_isr_events++;
  DMA_REG(DMA_INT_STATUS_OFF) = p;          /* acknowledge (W1C) */
}
