/* =============================================================================
 * SilicaFlux DataFabric -- single-channel DMA driver (bare metal, no libc)
 *
 * Hardware: rtl/dma/silicaflux_dma.sv, register page DMA (0x4000_6000),
 * INTC source SFV_DF_IRQ_DMA.  Register/field/enum constants come from
 * generated/sfv_df_map.h (memmap/silicaflux_v_datafabric.yaml).
 *
 * Only functions backed by real hardware are provided.  In particular
 * dma_abort() is real: the engine stops at the next beat boundary after the
 * outstanding bus transaction completes; BYTES_DONE then tells how much of the
 * destination has been written.
 *
 * Return convention: 0 = success, > 0 = hardware ERROR_CODE (DMA_ERR_*),
 * < 0 = driver error (DMA_DRV_E*, detected before touching the hardware).
 * ===========================================================================*/
#ifndef SILICAFLUX_DMA_H
#define SILICAFLUX_DMA_H
#include <stdint.h>
#include "sfv_df_map.h"

#define DMA_REG(off) (*(volatile uint32_t *)(uintptr_t)(SFV_DF_DMA_BASE + (off)))

/* driver errors (negative) */
#define DMA_DRV_EBUSY     (-1)   /* a transfer is in progress                  */
#define DMA_DRV_EINVAL    (-2)   /* zero length, misalignment, overflow, overlap */
#define DMA_DRV_ERANGE    (-3)   /* address range not DMA-reachable memory      */
#define DMA_DRV_ETIMEDOUT (-4)   /* dma_wait() poll budget exhausted            */
#define DMA_DRV_ENODEV    (-5)   /* ID register mismatch                        */

/* dma_poll() result while the transfer is still running.  Deliberately
 * outside 0..15 (the 4-bit ERROR_CODE range): an earlier value of 1 collided
 * with DMA_ERR_ZERO_LENGTH and made dma_wait() spin on a finished transfer
 * (found by the SoC firmware regression, D3). */
#define DMA_POLL_BUSY 0x100

#define DMA_IRQ_DONE  DMA_INT_STATUS_DONE_MASK
#define DMA_IRQ_ERROR DMA_INT_STATUS_ERROR_MASK

typedef struct {
  uint32_t src;        /* byte address, aligned to the data width (INFO.DW_BYTES) */
  uint32_t dst;        /* byte address, aligned                                    */
  uint32_t len;        /* bytes, 1 .. 2^INFO.MAX_LEN_LOG2                          */
} dma_xfer_t;

typedef struct {
  uint32_t status;     /* STATUS register                                  */
  uint32_t error;      /* ERROR_CODE (0 when the transfer completed)       */
  uint32_t error_addr; /* ERROR_ADDR                                       */
  uint32_t bytes_done; /* BYTES_DONE                                       */
} dma_status_t;

int      dma_init(void);                              /* check ID, idle, clear + mask interrupts */
uint32_t dma_info(void);                              /* INFO register                          */
int      dma_check(const dma_xfer_t *x);              /* software validation only               */
int      dma_configure(const dma_xfer_t *x);          /* validate + program SRC/DST/LENGTH      */
int      dma_configure_raw(const dma_xfer_t *x);      /* program without software validation    */
int      dma_start(void);                             /* 0, or DMA_DRV_EBUSY (hardware refused) */
int      dma_poll(dma_status_t *st);                  /* DMA_POLL_BUSY, 0, or ERROR_CODE        */
int      dma_wait(uint32_t max_polls, dma_status_t *st);
void     dma_abort(void);
uint32_t dma_get_status(void);                        /* raw STATUS                             */
void     dma_enable_interrupt(uint32_t mask);         /* DMA_IRQ_DONE | DMA_IRQ_ERROR           */
void     dma_clear_interrupt(uint32_t mask);          /* write-one-to-clear INT_STATUS          */
uint32_t dma_pending_interrupt(void);                 /* INT_STATUS                             */
int      dma_copy(uint32_t dst, uint32_t src, uint32_t len);  /* configure + start + wait       */

/* Example interrupt service routine: call from the machine external-interrupt
 * handler when INTC_CLAIM == SFV_DF_IRQ_DMA + 1.  Records the outcome in
 * dma_isr_events / dma_isr_last and acknowledges the DMA interrupt. */
extern volatile uint32_t dma_isr_events, dma_isr_last;
void dma_isr(void);

#endif
