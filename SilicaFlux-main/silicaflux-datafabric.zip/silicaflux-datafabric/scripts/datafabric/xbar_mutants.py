#!/usr/bin/env python3
"""Mutation campaign for the SFB2 crossbar testbench: each mutant injects one
realistic RTL bug into a copy of rtl/interconnect; tb_sfb_xbar must FAIL
(mutant 'killed').  Writes reports/datafabric/xbar_mutants.{json,md}."""
import concurrent.futures as cf, json, os, re, shutil, subprocess, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
FILES = ["sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
         "sfb_error_slave.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv", "sfb_crossbar.sv"]
# (id, file, original, replacement, description, run-args)
MUTANTS = [
    ("M1", "sfb_rsp_router.sv", "if (busy[s] && owner_oh[s*NM + m]) begin", "if (busy[s] && owner_oh[s*NM + ((m + 1) % NM)]) begin",
     "response routed to the wrong master", "+mode=0"),
    ("M2", "sfb_crossbar.sv", "wire [NS-1:0] s_free = ~busy_q | s_rsp_hs;", "wire [NS-1:0] s_free = '1;",
     "slave accepts a 2nd transaction before responding", "+mode=0"),
    ("M3", "sfb_arbiter.sv", "lock_q     <= grant_valid && stall && !accept;", "lock_q     <= 1'b0;",
     "no grant lock: slave-side payload changes under back-pressure", "+mode=0"),
    ("M4", "sfb_req_mux.sv", "s_wstrb = s_wstrb | ({SB{grant[m]}} & m_wstrb[m*SB +: SB]);", "s_wstrb = s_wstrb | ({SB{grant[m]}} & m_wstrb[0 +: SB]);",
     "write strobes taken from master 0", "+mode=0"),
    ("M5", "sfb_error_slave.sv", "assign rsp_error = pend_q;", "assign rsp_error = 1'b0;",
     "decode error reported as OKAY", "+mode=0"),
    ("M6", "sfb_addr_decoder.sv", "SLV_BASE[s*AW +: AW]) && EN[s]) begin", "SLV_BASE[s*AW +: AW])) begin",
     "access matrix ignored", "+mode=0"),
    ("M7", "sfb_arbiter.sv", "prio_q <= (grant_idx == IW'(N - 1)) ? '0 : grant_idx + IW'(1);", "prio_q <= prio_q;",
     "round-robin pointer never advances (starvation)", "+mode=1"),
    ("M8", "sfb_crossbar.sv", "owner_q[s*NM +: NM]   <= grant[s*NM +: NM];", "owner_q[s*NM +: NM]   <= owner_q[s*NM +: NM];",
     "owner not recorded at acceptance", "+mode=0"),
    ("M9", "sfb_crossbar.sv", "wire [NM-1:0] m_free = ~out_q | m_rsp_hs;", "wire [NM-1:0] m_free = '1;",
     "master may have two transactions outstanding", "+mode=0"),
    ("M10", "sfb_rsp_router.sv", "s_rsp_ready[s] = m_rsp_ready[m];", "s_rsp_ready[s] = 1'b1;",
     "response back-pressure ignored (response lost)", "+mode=0"),
    ("M11", "sfb_addr_decoder.sv", "if (misaligned) hit = 1'b0;", "",
     "misaligned address not rejected", "+mode=0"),
    ("M12", "sfb_skid_buffer.sv", "if (!(m_ready || !m_valid) && s_valid && s_ready) skid_data <= s_data;", "",
     "skid buffer loses the parked beat", "+mode=0"),
]

def one(m):
    mid, fn, old, new, desc, args = m
    d = os.path.join(ROOT, "build", "mutants", mid)
    shutil.rmtree(d, ignore_errors=True); os.makedirs(os.path.join(d, "rtl"))
    for f in FILES:
        src = open(os.path.join(ROOT, "rtl", "interconnect", f)).read()
        if f == fn:
            assert old in src, (mid, old)
            src = src.replace(old, new)
        open(os.path.join(d, "rtl", f), "w").write(src)
    # skid-buffer mutants are judged by the streaming slice testbench (the
    # crossbar keeps one transaction per port, so it never fills a skid)
    if fn in ("sfb_skid_buffer.sv", "sfb_reg_slice.sv"):
        top, tbf, gen = "tb_sfb_reg_slice", "tb/interconnect/tb_sfb_reg_slice.sv", []
    else:
        top, tbf, gen = "tb_sfb_xbar", "tb/interconnect/tb_sfb_xbar.sv", ["-GNM=3", "-GNS=3", "-GARB=1"]
    cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "2", "-Wno-fatal",
           "-Wno-lint", "-Wno-style", "--top-module", top, "-Mdir", os.path.join(d, "obj"), "-o", "vtb"] + gen + \
          [os.path.join(d, "rtl", f) for f in FILES] + \
          [os.path.join(ROOT, "tb/common/sfb_protocol_checker.sv"), os.path.join(ROOT, tbf)]
    b = subprocess.run(cmd, capture_output=True, text=True)
    if b.returncode != 0:
        return dict(id=mid, desc=desc, killed=True, how="build/elaboration failure", detail=b.stderr[-500:])
    r = subprocess.run([os.path.join(d, "obj", "vtb"), "+seed=1", "+cycles=20000"] + args.split(),
                       capture_output=True, text=True, timeout=600)
    errs = [l for l in r.stdout.splitlines() if "ERROR" in l or "R2:" in l or "R4:" in l or "R5:" in l or "R6:" in l]
    res = next((l for l in r.stdout.splitlines() if "RESULT" in l), "no result")
    killed = "RESULT PASS" not in res
    return dict(id=mid, desc=desc, killed=killed, how=(errs[0][:160] if errs else res), result=res)

def main():
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        res = list(ex.map(one, MUTANTS))
    k = sum(r["killed"] for r in res)
    os.makedirs(os.path.join(ROOT, "reports", "datafabric"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "datafabric", "xbar_mutants.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "datafabric", "xbar_mutants.md"), "w") as f:
        f.write(f"# Crossbar mutation campaign\n\n**{k}/{len(res)} mutants killed** (tb_sfb_xbar NM=3 NS=3 ARB=RR, or tb_sfb_reg_slice for skid/slice mutants; seed 1, 20k cycles)\n\n"
                "| id | injected bug | killed | first symptom |\n|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['id']} | {r['desc']} | {'yes' if r['killed'] else '**NO**'} | `{r['how']}` |\n")
    print(f"mutants killed: {k}/{len(res)}")
    for r in res: print(r["id"], "killed" if r["killed"] else "SURVIVED", r["desc"], "|", r["how"][:120])
    return 0 if k == len(res) else 1

if __name__ == "__main__":
    sys.exit(main())
