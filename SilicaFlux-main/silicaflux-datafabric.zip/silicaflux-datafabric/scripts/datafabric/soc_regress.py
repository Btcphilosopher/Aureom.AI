#!/usr/bin/env python3
"""SoC-level regression of SilicaFlux-V + DataFabric (Verilator, firmware level).

Builds tb_soc_df in several configurations and runs:
  * the six UNMODIFIED SilicaFlux-V release-1 scenarios (scripts/soc_regress.sh
    of silicaflux-v) with the unmodified acceptance firmware -- regression of
    the original SoC behaviour on the new fabric;
  * the DataFabric DMA demo (firmware/examples/dma_demo) through SRAM, SPI
    flash and JTAG boot;
  * configuration variants: buffered DMA engine, SilicaFlux SRAM Wrapper
    Library banks (incl. MBIST POST on them), fixed-priority arbitration,
    performance counters removed.
Writes reports/datafabric/soc_regression.{md,json}, UART logs to
reports/datafabric/soc_logs/ and the DMA-demo transaction trace to
reports/datafabric/traces/.  Exit 1 on any failure."""
import concurrent.futures as cf
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
B = os.path.join(ROOT, "build")
FW = os.path.join(B, "fw")
REP = os.path.join(ROOT, "reports", "datafabric")
LOGS = os.path.join(REP, "soc_logs")


def files():
    sfv = [os.path.join("third_party/silicaflux-v", l.strip())
           for l in open(os.path.join(ROOT, "third_party/silicaflux-v/rtl/files.f")) if l.strip()]
    sl = "third_party/silicaflux-sramlib/rtl/mem"
    sram = ([f"-I{sl}", f"-I{sl}/backends/asic"] +
            sorted(f"{sl}/backends/generic/{f}" for f in os.listdir(f"{ROOT}/{sl}/backends/generic")) +
            sorted(f"{sl}/backends/fpga/{f}" for f in os.listdir(f"{ROOT}/{sl}/backends/fpga")) +
            [f"{sl}/backends/asic/sram_asic_array.sv"] +
            sorted(f"{sl}/backends/asic/{f}" for f in os.listdir(f"{ROOT}/{sl}/backends/asic") if f.startswith("sram_leaf_")) +
            [f"{sl}/backends/asic/stubs/sram_macro_blackboxes.sv"] +
            sorted(f"{sl}/{f}" for f in os.listdir(f"{ROOT}/{sl}") if f.startswith("sram_") and f.endswith(".sv") and f != "sram_if.sv"))
    df = ["generated/sfb_memmap_pkg.sv"] + [f"rtl/interconnect/{f}" for f in (
        "sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
        "sfb_skid_buffer.sv", "sfb_reg_slice.sv", "sfb_v1_slave_adapter.sv", "sfb_crossbar.sv",
        "sfb_perf_counters.sv")] + [f"rtl/dma/{f}" for f in (
        "dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv", "dma_irq.sv",
        "dma_control_regs.sv", "silicaflux_dma.sv")] + ["rtl/mem/sfb_sram_slave.sv", "rtl/mem/sfb_sram_1r1w_slave.sv",
                                                         "rtl/soc/sfv_soc_df.sv"]
    return sram + sfv + df + ["build/fw/sfv_bootrom_image.sv", "tb/common/sfb_trace_monitor.sv", "tb/soc/tb_soc_df.sv"]


# name -> (-G parameters, extra defines)
VARIANTS = {
    "default":   ([], []),                                     # simple DMA, RR, perf on, sfv SRAM banks
    "buffered":  (["-GDMA_ENGINE=1"], []),
    "sramlib":   (["-GSRAM_IMPL=1"], ["+define+DF_SRAMLIB"]),
    "fixedprio": (["-GARB_MODE=0"], []),
    "noperf":    (["-GPERF=0"], []),
}

APP = "build/fw/sfv_app"
DEMO = "build/fw/dma_demo"
SCENARIOS = [
    # variant, name, args
    ("default", "sfv_spi_flash_boot_app", ["+boot=0", f"+flash={APP}_flash.hex"]),
    ("default", "sfv_jtag_load_boot_app", ["+boot=1", "+jtag=1", f"+sram={APP}_sram.hex"]),
    ("default", "sfv_rom_post_selftest", ["+boot=2"]),
    ("default", "sfv_sram_direct_boot_app", ["+boot=3", f"+sram={APP}_sram.hex"]),
    ("default", "sfv_mbist_fault_detect", ["+boot=2", "+fault_bank=2", "+fault_addr=4660", "+fault_bit=13",
                                           "+fault_val=1", "+expect_fail=1"]),
    ("default", "sfv_mbist_fault_bank0", ["+boot=2", "+fault_bank=0", "+fault_addr=8191", "+fault_bit=0",
                                          "+fault_val=0", "+expect_fail=1"]),
    ("default", "dma_demo_sram_boot", ["+boot=3", f"+sram={DEMO}_sram.hex", "+trace=@TRACE@"]),
    ("default", "dma_demo_spi_flash_boot", ["+boot=0", f"+flash={DEMO}_flash.hex"]),
    # the release-1 testbench loads 2400 words over JTAG; the demo image is larger
    ("default", "dma_demo_jtag_boot", ["+boot=1", "+jtag=1", f"+sram={DEMO}_sram.hex", "+jtag_words=4096"]),
    ("buffered", "dma_demo_buffered_engine", ["+boot=3", f"+sram={DEMO}_sram.hex", "+trace=@TRACE@"]),
    ("buffered", "sfv_sram_direct_boot_app", ["+boot=3", f"+sram={APP}_sram.hex"]),
    ("sramlib", "dma_demo_sramlib_banks", ["+boot=3", f"+sram={DEMO}_sram.hex"]),
    ("sramlib", "sfv_rom_post_selftest", ["+boot=2"]),
    ("sramlib", "sfv_sram_direct_boot_app", ["+boot=3", f"+sram={APP}_sram.hex"]),
    ("fixedprio", "dma_demo_fixed_priority", ["+boot=3", f"+sram={DEMO}_sram.hex"]),
    ("fixedprio", "sfv_sram_direct_boot_app", ["+boot=3", f"+sram={APP}_sram.hex"]),
    ("noperf", "sfv_sram_direct_boot_app", ["+boot=3", f"+sram={APP}_sram.hex"]),
    ("noperf", "sfv_rom_post_selftest", ["+boot=2"]),
]


def build(variant):
    gen, defs = VARIANTS[variant]
    obj = os.path.join(B, "soc_df", variant)
    os.makedirs(obj, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "2", "-Wno-fatal",
           "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Irtl/dma", "-Irtl/interconnect",
           "--top-module", "tb_soc_df", "-Mdir", obj, "-o", "vtb"] + gen + defs + files()
    t0 = time.time()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    open(os.path.join(B, "soc_df", f"{variant}.build.log"), "w").write(r.stdout + r.stderr)
    return variant, r.returncode, round(time.time() - t0, 1), " ".join(cmd)


def run(variant, name, args):
    os.makedirs(LOGS, exist_ok=True)
    os.makedirs(os.path.join(REP, "traces"), exist_ok=True)
    tag = f"{variant}__{name}"
    args = [a.replace("@TRACE@", os.path.join("reports/datafabric/traces", f"{tag}.csv")) for a in args]
    cmd = [os.path.join(B, "soc_df", variant, "vtb")] + args + [f"+log=reports/datafabric/soc_logs/{tag}.uart.log"]
    t0 = time.time()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=3600)
    open(os.path.join(LOGS, f"{tag}.sim.log"), "w").write(r.stdout[-20000:])
    line = next((l for l in r.stdout.splitlines() if "TB_SOC RESULT" in l), "NO RESULT")
    # full SoC traces are ~400 MB: keep only the window of the last DMA transfer (demo phase D8)
    tr = os.path.join(REP, "traces", f"{tag}.csv")
    if os.path.exists(tr):
        subprocess.run([sys.executable, "python/datafabric/trace_window.py", tr, tr[:-4] + "__D8_window.csv",
                        "--last-transfer", "3", "--accepts", "8192"], cwd=ROOT, capture_output=True)
        os.remove(tr)
    uart = open(os.path.join(LOGS, f"{tag}.uart.log")).read() if os.path.exists(os.path.join(LOGS, f"{tag}.uart.log")) else ""
    app = [l for l in uart.splitlines() if "RESULT" in l or "PHASE1" in l]
    return dict(variant=variant, scenario=name, ok="RESULT PASS" in line, result=line, firmware=app,
                cmd=" ".join(os.path.relpath(c, ROOT) if c.startswith(ROOT) else c for c in cmd),
                secs=round(time.time() - t0, 1))


def main():
    sel = set(sys.argv[1:])
    variants = sorted({v for v, _, _ in SCENARIOS if not sel or v in sel})
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        builds = list(ex.map(build, variants))
    ok_builds = {v for v, rc, _, _ in builds if rc == 0}
    res = []
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(run, v, n, a) for v, n, a in SCENARIOS if v in ok_builds and (not sel or v in sel)]
        res = [f.result() for f in futs]
    for v, rc, secs, cmd in builds:
        if rc != 0:
            res.append(dict(variant=v, scenario="BUILD", ok=False, result="BUILD FAILED (see build/soc_df)", cmd=cmd))
    n = sum(r["ok"] for r in res)
    ver = subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip()
    os.makedirs(REP, exist_ok=True)
    json.dump(dict(tool=ver, builds=[dict(variant=v, rc=rc, secs=s, cmd=c) for v, rc, s, c in builds],
                   passed=n, total=len(res), runs=res), open(os.path.join(REP, "soc_regression.json"), "w"), indent=1)
    with open(os.path.join(REP, "soc_regression.md"), "w") as f:
        f.write(f"# SoC regression: SilicaFlux-V + DataFabric (tb_soc_df)\n\n{ver}.  **{n}/{len(res)} PASS**\n\n"
                "Variants: " + "; ".join(f"`{v}` = {' '.join(VARIANTS[v][0] + VARIANTS[v][1]) or 'defaults'}"
                                         for v in variants) + "\n\n"
                "| variant | scenario | result | firmware summary |\n|---|---|---|---|\n")
        for r in sorted(res, key=lambda r: (r["variant"], r["scenario"])):
            f.write(f"| {r['variant']} | {r['scenario']} | {'PASS' if r['ok'] else '**FAIL**'}: "
                    f"{r['result'].replace('TB_SOC RESULT ', '')} | {'<br>'.join(r.get('firmware', []))} |\n")
    print(f"soc regression: {n}/{len(res)} PASS")
    for r in res:
        print(("PASS " if r["ok"] else "FAIL ") + r["variant"] + " " + r["scenario"] + " | " + r["result"])
    return 0 if n == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
