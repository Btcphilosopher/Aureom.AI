#!/usr/bin/env python3
"""DataFabric lint: Verilator -Wall (zero warnings in DataFabric files), Yosys 0.33
elaboration + `check -assert` + no inferred latches, generated-file freshness and
the SilicaFlux-V memory-map cross-check.  Writes reports/datafabric/lint.{json,md}."""
import json
import os
import re
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "datafabric"))
from unit_regress import sramlib  # noqa: E402

IC = [f"rtl/interconnect/{f}" for f in ("sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
                                         "sfb_error_slave.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv",
                                         "sfb_v1_slave_adapter.sv", "sfb_crossbar.sv", "sfb_shared_bus.sv",
                                         "sfb_perf_counters.sv")]
DMA = [f"rtl/dma/{f}" for f in ("dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv",
                                "dma_irq.sv", "dma_control_regs.sv", "silicaflux_dma.sv")]
MEM = ["rtl/mem/sfb_sram_slave.sv", "rtl/mem/sfb_sram_1r1w_slave.sv"]
SFV = [os.path.join("third_party/silicaflux-v", l.strip())
       for l in open(os.path.join(ROOT, "third_party/silicaflux-v/rtl/files.f")) if l.strip()]
SOC = SFV + ["build/fw/sfv_bootrom_image.sv", "generated/sfb_memmap_pkg.sv"] + IC + DMA + MEM + ["rtl/soc/sfv_soc_df.sv"]

# (top, files, -G params)
TOPS = [
    ("sfb_crossbar", IC, []), ("sfb_crossbar", IC, ["-GNM=5", "-GNS=3", "-GDW=128", "-GARB_MODE=0"]),
    ("sfb_shared_bus", IC, ["-GNM=3", "-GNS=4"]), ("sfb_reg_slice", IC, []), ("sfb_v1_slave_adapter", IC, []),
    ("sfb_perf_counters", IC, []),
    ("silicaflux_dma", DMA, []), ("silicaflux_dma", DMA, ["-GENGINE=1"]),
    ("silicaflux_dma", DMA, ["-GENGINE=1", "-GDUAL_PORT=1"]), ("silicaflux_dma", DMA, ["-GDW=128", "-GPERF=0"]),
    ("silicaflux_dma", DMA, ["-GENGINE=1", "-GDW=64", "-GFIFO_DEPTH=16", "-GBURST=16"]),
    ("sfb_sram_slave", sramlib() + MEM, ["-GREAD_LATENCY=2"]), ("sfb_sram_1r1w_slave", sramlib() + MEM, []),
    ("sfv_soc_df", sramlib() + SOC, []), ("sfv_soc_df", sramlib() + SOC, ["-GDMA_ENGINE=1", "-GPERF=0", "-GSRAM_IMPL=1"]),
]
YOSYS = [("sfb_crossbar", IC, ""), ("sfb_shared_bus", IC, ""), ("sfb_reg_slice", IC, ""),
         ("sfb_v1_slave_adapter", IC, ""), ("sfb_perf_counters", IC, ""),
         ("silicaflux_dma", DMA, ""), ("silicaflux_dma", DMA, "chparam -set ENGINE 1 silicaflux_dma;"),
         ("silicaflux_dma", DMA, "chparam -set ENGINE 1 -set DUAL_PORT 1 silicaflux_dma;"),
         ("sfv_soc_df", [f for f in SOC if f not in MEM], "")]   # SRAM_IMPL=0: library branch not elaborated


def main():
    res = []
    for top, files, gen in TOPS:
        cmd = ["verilator", "--lint-only", "-Wall", "-Irtl/dma", "-Irtl/interconnect", "--top-module", top] + gen + files
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        msgs = [l for l in r.stderr.splitlines() if re.match(r"%(Warning|Error)", l)]
        own = [l for l in msgs if re.search(r"\b(rtl|generated)/", l) and "third_party" not in l]
        res.append(dict(tool="verilator -Wall", top=top, params=" ".join(gen), ok=not own and r.returncode in (0, 1) and
                        not any(l.startswith("%Error:") and "third_party" not in l and "Exiting due to" not in l for l in msgs),
                        datafabric_warnings=len(own), third_party_warnings=len(msgs) - len(own), detail=own[:5]))
    for top, files, ch in YOSYS:
        # latches: none allowed, except inside SilicaFlux-V's clock-gate model sfv_clkgate
        # (release-1 coding rule 2: "the Yosys latch list must contain only sfv_clkgate")
        lst = os.path.join(ROOT, "build", f"latches_{top}.txt")
        os.makedirs(os.path.dirname(lst), exist_ok=True)
        script = (f"read_verilog -sv -DSYNTHESIS -Irtl/dma -Irtl/interconnect {' '.join(files)}; {ch} "
                  f"hierarchy -check -top {top}; proc; opt_clean; check -assert; "
                  f"tee -q -o {lst} select -list t:$dlatch t:$adlatch t:$dlatchsr t:$_DLATCH*")
        r = subprocess.run(["yosys", "-q", "-p", script], cwd=ROOT, capture_output=True, text=True)
        lat = [l.strip() for l in open(lst).read().splitlines() if l.strip()] if os.path.exists(lst) else []
        bad = [l for l in lat if not l.startswith("sfv_clkgate/")]
        res.append(dict(tool="yosys 0.33 elab+check+latch rule", top=top, params=ch, ok=r.returncode == 0 and not bad,
                        detail=[l for l in (r.stderr + r.stdout).splitlines() if "ERROR" in l][:3] + bad[:3] +
                               ([f"{len(lat)} latch(es), all in sfv_clkgate (ICG model)"] if lat and not bad else [])))
    r = subprocess.run([sys.executable, "python/datafabric/memmap_gen.py", "memmap/silicaflux_v_datafabric.yaml",
                        "--root", ".", "--check", "--sfv-pkg", "third_party/silicaflux-v/rtl/pkg/sfv_pkg.sv"],
                       cwd=ROOT, capture_output=True, text=True)
    res.append(dict(tool="memmap_gen --check --sfv-pkg", top="memory map", params="", ok=r.returncode == 0,
                    detail=[l for l in r.stdout.splitlines() if "INFO" in l] + r.stderr.splitlines()[-2:]))
    n = sum(x["ok"] for x in res)
    rep = os.path.join(ROOT, "reports", "datafabric")
    os.makedirs(rep, exist_ok=True)
    json.dump(dict(passed=n, total=len(res), checks=res), open(os.path.join(rep, "lint.json"), "w"), indent=1)
    with open(os.path.join(rep, "lint.md"), "w") as f:
        f.write(f"# Lint\n\n**{n}/{len(res)} PASS** (Verilator 5.020 -Wall: zero warnings required in DataFabric "
                "files; third-party SilicaFlux-V warnings counted separately; Yosys 0.33 elaboration, `check -assert`, "
                "no latches)\n\n| tool | top | params | result | DataFabric warnings | third-party warnings | detail |\n"
                "|---|---|---|---|---|---|---|\n")
        for x in res:
            f.write(f"| {x['tool']} | {x['top']} | {x['params']} | {'PASS' if x['ok'] else '**FAIL**'} | "
                    f"{x.get('datafabric_warnings', '')} | {x.get('third_party_warnings', '')} | "
                    f"{'; '.join(x.get('detail', []))[:200]} |\n")
    print(f"lint: {n}/{len(res)} PASS")
    for x in res:
        if not x["ok"]:
            print("FAIL", x)
    return 0 if n == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
