#!/usr/bin/env python3
"""Crossbar parameter regression: builds tb_sfb_xbar per configuration with
Verilator (-G overrides), runs several seeds/modes, writes
reports/datafabric/xbar_regression.{json,md}.  Exit 1 on any failure."""
import concurrent.futures as cf, json, os, subprocess, sys, time
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
IC = ["rtl/interconnect/" + f for f in (
    "sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
    "sfb_error_slave.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv", "sfb_crossbar.sv", "sfb_shared_bus.sv")]
TB = ["tb/common/sfb_protocol_checker.sv", "tb/interconnect/tb_sfb_xbar.sv"]
# (NM, NS, DW, ARB, SLICE, LMIN, LMAX[, TOPO[, WITHDRAW]])  TOPO 1 = sfb_shared_bus
CONFIGS = [
    (1, 1, 32, 1, 0, 1, 1), (2, 1, 32, 1, 0, 1, 2), (2, 2, 32, 0, 0, 1, 3), (2, 2, 32, 1, 0, 1, 3),
    (3, 3, 32, 0, 0, 1, 3), (3, 3, 32, 1, 1, 1, 3), (4, 7, 32, 1, 0, 1, 4), (5, 3, 32, 1, 0, 1, 3),
    (5, 4, 32, 0, 1, 2, 5), (3, 2, 64, 1, 0, 1, 3), (4, 4, 64, 0, 0, 1, 2), (3, 3, 128, 1, 0, 1, 3),
    (5, 2, 128, 1, 1, 1, 4), (4, 3, 32, 1, 0, 3, 8),
    (3, 3, 32, 1, 0, 1, 3, 1), (4, 7, 32, 1, 0, 1, 2, 1), (5, 4, 64, 1, 1, 1, 3, 1),
    (3, 3, 32, 1, 0, 1, 3, 0, 1), (4, 7, 32, 0, 0, 1, 2, 0, 1),            # request withdrawal tolerance
]
SEEDS = [int(s) for s in os.environ.get("XBAR_SEEDS", "1,2,3").split(",")]
CYCLES = int(os.environ.get("XBAR_CYCLES", "20000"))

def build(cfg):
    nm, ns, dw, arb, sl, lmin, lmax = cfg[:7]
    topo = cfg[7] if len(cfg) > 7 else 0
    wd = cfg[8] if len(cfg) > 8 else 0
    tag = f"nm{nm}_ns{ns}_dw{dw}_arb{arb}_sl{sl}_l{lmin}{lmax}" + ("_shared" if topo else "") + ("_withdraw" if wd else "")
    obj = os.path.join(ROOT, "build", "xbar_regress", tag)
    os.makedirs(obj, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "2",
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", "tb_sfb_xbar", "-Mdir", obj, "-o", "vtb",
           f"-GNM={nm}", f"-GNS={ns}", f"-GDW={dw}", f"-GARB={arb}", f"-GSLICE={sl}",
           f"-GLMIN={lmin}", f"-GLMAX={lmax}", f"-GTOPO={topo}", f"-GWITHDRAW={wd}"] + IC + TB
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return tag, obj, cmd, r.returncode, r.stderr[-2000:]

def run(tag, obj, seed, mode, resets, cycles=None):
    args = [os.path.join(obj, "vtb"), f"+seed={seed}", f"+cycles={cycles or CYCLES}", f"+mode={mode}", f"+resets={resets}"]
    t0 = time.time()
    r = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
    line = next((l for l in r.stdout.splitlines() if "TB_SFB RESULT" in l), "NO RESULT LINE")
    ok = r.returncode == 0 and "RESULT PASS" in line
    masters = [l for l in r.stdout.splitlines() if l.startswith("TB_SFB master")]
    return dict(config=tag, seed=seed, mode=mode, resets=resets, ok=ok, result=line,
                masters=masters, cmd=" ".join(args), exit=r.returncode, secs=round(time.time() - t0, 2),
                tail="" if ok else r.stdout[-3000:])

def main():
    os.makedirs(os.path.join(ROOT, "reports", "datafabric"), exist_ok=True)
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        builds = list(ex.map(build, CONFIGS))
    results, jobs = [], []
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        for tag, obj, cmd, rc, err in builds:
            if rc != 0:
                results.append(dict(config=tag, ok=False, result="BUILD FAIL", cmd=" ".join(cmd), tail=err))
                continue
            for seed in SEEDS:
                jobs.append(ex.submit(run, tag, obj, seed, 0, 0))
            jobs.append(ex.submit(run, tag, obj, SEEDS[0], 0, 3))      # resets during traffic
            jobs.append(ex.submit(run, tag, obj, SEEDS[0], 1, 0))      # sustained contention
            jobs.append(ex.submit(run, tag, obj, SEEDS[0], 2, 0))      # single active requester
            if tag == "nm4_ns7_dw32_arb1_sl0_l14":
                jobs.append(ex.submit(run, tag, obj, 99, 0, 5, 200000))   # long-running traffic
        results += [j.result() for j in jobs]
    npass = sum(r["ok"] for r in results)
    ver = subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip()
    rep = dict(tool=ver, cycles=CYCLES, seeds=SEEDS, passed=npass, total=len(results), runs=results)
    with open(os.path.join(ROOT, "reports", "datafabric", "xbar_regression.json"), "w") as f:
        json.dump(rep, f, indent=1)
    with open(os.path.join(ROOT, "reports", "datafabric", "xbar_regression.md"), "w") as f:
        f.write(f"# Crossbar regression (tb_sfb_xbar)\n\n{ver}; {CYCLES} cycles per run; "
                f"**{npass}/{len(results)} PASS**\n\n| config | seed | mode | resets | result |\n|---|---|---|---|---|\n")
        for r in sorted(results, key=lambda r: (r["config"], r.get("mode", 0), r.get("seed", 0))):
            f.write(f"| {r['config']} | {r.get('seed','')} | {r.get('mode','')} | {r.get('resets','')} | "
                    f"{'PASS' if r['ok'] else 'FAIL'}: {r['result'].replace('TB_SFB RESULT ','')} |\n")
    print(f"xbar regression: {npass}/{len(results)} PASS")
    for r in results:
        if not r["ok"]:
            print("FAIL", r["config"], r.get("seed"), r.get("mode"), r["result"]); print(r.get("tail", "")[-1500:])
    return 0 if npass == len(results) else 1

if __name__ == "__main__":
    sys.exit(main())
