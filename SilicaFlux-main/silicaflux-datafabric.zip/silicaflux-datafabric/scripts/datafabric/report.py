#!/usr/bin/env python3
"""Collate reports/datafabric/*.json into reports/datafabric/SUMMARY.md with tool
versions, source hashes and pass/fail counts.  Only numbers present in the JSON
reports (i.e. produced by tools that actually ran) are summarised; a missing
report is listed as NOT RUN."""
import datetime
import hashlib
import json
import os
import subprocess

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
REP = os.path.join(ROOT, "reports", "datafabric")


def tree_hash(dirs):
    h = hashlib.sha256()
    for d in dirs:
        for base, _, files in sorted(os.walk(os.path.join(ROOT, d))):
            for f in sorted(files):
                p = os.path.join(base, f)
                h.update(os.path.relpath(p, ROOT).encode())
                h.update(open(p, "rb").read())
    return h.hexdigest()


def ver(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
        return (r.stdout or r.stderr).strip().splitlines()[0]
    except Exception:
        return "not installed"


def load(name):
    p = os.path.join(REP, name)
    return json.load(open(p)) if os.path.exists(p) else None


def relativize():
    """Make the stored command lines repository-relative: the reports are shipped, the
    build machine's absolute paths are not meaningful (and not wanted) in them."""
    pre = ROOT + os.sep
    for f in sorted(os.listdir(REP)):
        if not f.endswith((".json", ".md")):
            continue
        p = os.path.join(REP, f)
        s = open(p).read()
        if pre in s:
            open(p, "w").write(s.replace(pre, ""))


def main():
    relativize()
    tools = {"verilator": ver(["verilator", "--version"]), "iverilog": ver(["iverilog", "-V"]),
             "yosys": ver(["yosys", "-V"]), "z3": ver(["z3", "--version"]), "clang": ver(["clang", "--version"]),
             "python": ver(["python3", "--version"]), "cocotb": ver(["python3", "-c", "import cocotb;print(cocotb.__version__)"]),
             "sby": ver(["sby", "--help"]), "openroad": ver(["openroad", "-version"])}
    hashes = {"rtl": tree_hash(["rtl"]), "tb": tree_hash(["tb/common", "tb/interconnect", "tb/dma", "tb/soc"]),
              "firmware": tree_hash(["firmware/drivers", "firmware/examples"]), "memmap": tree_hash(["memmap"]),
              "third_party": tree_hash(["third_party"])}
    L = ["# SilicaFlux DataFabric -- verification and PPA summary", "",
         f"Generated {datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} by "
         "`scripts/datafabric/report.py` from the JSON reports in this directory.", "",
         "Source: btcphilosopher/Aureom.AI branch claude/awesome-albattani-y4t7ih @ 05183f2 "
         "(SilicaFlux-main archives; nothing committed).", "", "## Tools", "", "| tool | version |", "|---|---|"]
    L += [f"| {k} | {v} |" for k, v in tools.items()]
    L += ["", "## Source hashes (sha256 over file paths + contents)", "", "| tree | sha256 |", "|---|---|"]
    L += [f"| {k} | `{v}` |" for k, v in hashes.items()]
    L += ["", "## Results", "", "| check | report | result |", "|---|---|---|"]

    def row(name, file, res):
        L.append(f"| {name} | [{file}]({file.replace('.json', '.md')}) | {res} |")

    d = load("lint.json")
    row("RTL lint (Verilator -Wall, Yosys elab/latch, map freshness)", "lint.json",
        f"{d['passed']}/{d['total']} PASS" if d else "NOT RUN")
    d = load("unit_regression.json")
    row("Unit regression (tb_dma, slices, sramlib, cocotb, pytest)", "unit_regression.json",
        f"{d['passed']}/{d['total']} PASS" if d else "NOT RUN")
    d = load("xbar_regression.json")
    row("Crossbar parameter regression (tb_sfb_xbar)", "xbar_regression.json",
        f"{d['passed']}/{d['total']} PASS" if d else "NOT RUN")
    d = load("xbar_mutants.json")
    row("Mutation campaign (testbench strength)", "xbar_mutants.json",
        f"{sum(m['killed'] for m in d)}/{len(d)} mutants killed" if d else "NOT RUN")
    d = load("soc_regression.json")
    row("SoC firmware regression (sfv_soc_df)", "soc_regression.json",
        f"{d['passed']}/{d['total']} PASS" if d else "NOT RUN")
    d = load("formal.json")
    if d:
        ok = sum(1 for j in d["jobs"] if j.get("ok"))
        pas = [j for j in d["jobs"] if j.get("expect") == "PASS"]
        proved = sum(1 for j in pas if str(j.get("prove", "")).startswith("PROVED"))
        mut = sum(1 for j in d["jobs"] if j.get("expect") == "FAIL" and j.get("ok"))
        row("Formal (BMC + ABC PDR + non-vacuity mutants)", "formal.json",
            f"{ok}/{len(d['jobs'])} jobs as expected: {proved} unbounded proofs, "
            f"{len(pas) - proved} bounded only (PDR undecided), {mut} mutants caught")
    else:
        row("Formal", "formal.json", "NOT RUN")
    d = load("gls.json")
    row("Gate-level simulation", "gls.json", f"{sum(r['ok'] for r in d)}/{len(d)} PASS" if d else "NOT RUN")
    d = load("synth.json")
    row("Synthesis (Yosys generic CMOS, no PDK)", "synth.json",
        f"{sum(1 for r in d['results'] if r.get('ok'))}/{len(d['results'])} configurations, "
        f"{sum(r.get('latches', 0) for r in d['results'] if r.get('ok'))} latches" if d else "NOT RUN")
    d = load("benchmark.json")
    row("RTL performance sweep", "benchmark.json",
        f"{sum(1 for r in d['results'] if r.get('ok'))}/{len(d['results'])} runs PASS" if d else "NOT RUN")
    d = load("memorylab_comparison.json")
    row("MemoryLab integration", "memorylab_comparison.json",
        f"{len(d['traces'])} RTL traces analysed; {d['memorylab']}" if d else "NOT RUN")
    L += ["", "Not run / not available here: SymbiYosys (proofs were run with yosys-smtbmc and ABC PDR "
          "directly), OpenROAD/OpenSTA and any PDK Liberty (no placement, timing, routing-congestion or power "
          "numbers are claimed), FPGA bitstream (no nextpnr), riscv-tests (the CPU is unchanged from release 1)."]
    open(os.path.join(REP, "SUMMARY.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L[-16:]))


if __name__ == "__main__":
    main()
