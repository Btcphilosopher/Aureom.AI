#!/usr/bin/env bash
# Package the DataFabric project as a zip (sources, docs, reports, trace windows).
# Excludes build products, simulator scratch directories and Python caches.
#   scripts/datafabric/package.sh OUT.zip
set -euo pipefail
cd "$(dirname "$0")/../.."
out=${1:-silicaflux-datafabric.zip}
case "$out" in /*) ;; *) out="$(dirname "$PWD")/$out" ;; esac
name=$(basename "$PWD")
cd ..
rm -f "$out"
zip -qr "$out" "$name" \
  -x "$name/build/*" "$name/*/sim_build*" "$name/*/*/sim_build*" "$name/*/*/*/sim_build*" \
     "$name/*__pycache__*" "$name/*.pyc" "$name/*/results*.xml" "$name/*/*/results*.xml" \
     "$name/*/*/*/results*.xml" "$name/tb/dma/cocotb/cocotb_e*.log" \
     "$name/tb/interconnect/v1compat/compat*.log" "$name/*.pytest_cache*"
echo "packaged $out"
