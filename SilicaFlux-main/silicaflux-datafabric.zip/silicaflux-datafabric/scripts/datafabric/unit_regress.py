#!/usr/bin/env python3
"""DataFabric unit regression (everything except the crossbar matrix, the SoC
and formal, which have their own runners):
  * tb_dma (Verilator): engines x ports x widths x arbitration x latency/back-pressure x seeds,
    all test groups (directed, errors, busy, irq, abort, reset, random)
  * tb_sfb_reg_slice (Verilator): slice configurations x seeds
  * tb_sfb_xbar with SilicaFlux SRAM Wrapper Library slaves (Verilator)
  * cocotb (Icarus): unmodified silicaflux-v crossbar test on sfb_crossbar (fixed / RR),
    DMA vs Python reference model (simple / buffered)
  * pytest: memory-map generator
Writes reports/datafabric/unit_regression.{json,md}; exit 1 on any failure."""
import concurrent.futures as cf
import json
import os
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
B = os.path.join(ROOT, "build", "unit")
IC = [f"rtl/interconnect/{f}" for f in ("sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
                                         "sfb_error_slave.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv", "sfb_crossbar.sv",
                                         "sfb_shared_bus.sv")]
DMA = [f"rtl/dma/{f}" for f in ("dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv",
                                "dma_irq.sv", "dma_control_regs.sv", "silicaflux_dma.sv")]
SL = "third_party/silicaflux-sramlib/rtl/mem"


def sramlib():
    g = lambda d: sorted(f"{SL}/{d}/{f}" for f in os.listdir(os.path.join(ROOT, SL, d)) if f.endswith(".sv"))
    return ([f"-I{SL}", f"-I{SL}/backends/asic"] + g("backends/generic") + g("backends/fpga") +
            [f"{SL}/backends/asic/sram_asic_array.sv"] +
            sorted(f"{SL}/backends/asic/{f}" for f in os.listdir(os.path.join(ROOT, SL, "backends/asic")) if f.startswith("sram_leaf_")) +
            [f"{SL}/backends/asic/stubs/sram_macro_blackboxes.sv"] +
            sorted(f"{SL}/{f}" for f in os.listdir(os.path.join(ROOT, SL)) if f.startswith("sram_") and f.endswith(".sv") and f != "sram_if.sv"))


VL = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "2", "-Wno-fatal", "-Wno-lint",
      "-Wno-style", "-Irtl/dma"]

# (tag, top, -G params, files, [run arg lists])
BUILDS = []
for eng, dual, dw, arb, lmin, lmax in [(0, 0, 32, 1, 1, 3), (0, 0, 64, 1, 1, 3), (0, 0, 128, 0, 1, 2),
                                       (1, 0, 32, 1, 1, 3), (1, 1, 32, 1, 1, 3), (1, 0, 64, 0, 2, 4),
                                       (0, 0, 32, 0, 3, 6), (1, 0, 32, 1, 1, 1)]:
    tag = f"dma_e{eng}_p{dual}_d{dw}_a{arb}_l{lmin}{lmax}"
    runs = [["+seed=1", "+bp=20"], ["+seed=2", "+bp=0"], ["+seed=3", "+bp=40", "+ntrans=80"]]
    BUILDS.append((tag, "tb_dma", [f"-GENGINE={eng}", f"-GDUAL_PORT={dual}", f"-GDW={dw}", f"-GARB={arb}",
                                    f"-GLMIN={lmin}", f"-GLMAX={lmax}", "-GFIFO_DEPTH=8", "-GBURST=4"],
                   IC + DMA + ["tb/common/sfb_protocol_checker.sv", "tb/common/sfb_trace_monitor.sv", "tb/dma/tb_dma.sv"],
                   runs))
for rq, rs, dw in [(1, 1, 32), (1, 0, 32), (0, 1, 32), (1, 1, 64), (1, 1, 128)]:
    BUILDS.append((f"slice_q{rq}_s{rs}_d{dw}", "tb_sfb_reg_slice", [f"-GREQ_SLICE={rq}", f"-GRSP_SLICE={rs}", f"-GDW={dw}"],
                   ["rtl/interconnect/sfb_skid_buffer.sv", "rtl/interconnect/sfb_reg_slice.sv",
                    "tb/common/sfb_protocol_checker.sv", "tb/interconnect/tb_sfb_reg_slice.sv"],
                   [["+seed=1"], ["+seed=2"], ["+seed=3"]]))
for slv, lat, dw in [(1, 1, 32), (1, 2, 32), (1, 3, 32), (2, 1, 32), (2, 2, 64), (2, 3, 32)]:
    BUILDS.append((f"xsram_s{slv}_l{lat}_d{dw}", "tb_sfb_xbar", [f"-GSLAVES={slv}", f"-GSRAM_LAT={lat}", f"-GDW={dw}"],
                   sramlib() + IC + ["rtl/mem/sfb_sram_slave.sv", "rtl/mem/sfb_sram_1r1w_slave.sv",
                                     "tb/common/sfb_protocol_checker.sv", "tb/interconnect/tb_sfb_xbar.sv"],
                   [["+seed=1", "+cycles=20000"], ["+seed=2", "+cycles=20000", "+resets=2"]]))


def build_and_run(b):
    tag, top, gen, files, runs = b
    obj = os.path.join(B, tag)
    os.makedirs(obj, exist_ok=True)
    cmd = VL + ["--top-module", top, "-Mdir", obj, "-o", "vtb"] + gen + files
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    if r.returncode:
        return [dict(suite=top, config=tag, args="BUILD", ok=False, result=r.stderr[-400:])]
    out = []
    for a in runs:
        t0 = time.time()
        p = subprocess.run([os.path.join(obj, "vtb")] + a, cwd=ROOT, capture_output=True, text=True, timeout=3600)
        line = next((l for l in p.stdout.splitlines() if "RESULT" in l), "NO RESULT")
        out.append(dict(suite=top, config=tag, args=" ".join(a), ok=p.returncode == 0 and "RESULT PASS" in line,
                        result=line, secs=round(time.time() - t0, 1)))
    return out


def cocotb_runs():
    out = []
    for d, var, tag in [("tb/interconnect/v1compat", {}, "v1compat_fixed_priority"),
                        ("tb/interconnect/v1compat", {"COMPAT_RR": "1"}, "v1compat_round_robin"),
                        ("tb/dma/cocotb", {"ENGINE": "0"}, "dma_python_refmodel_simple"),
                        ("tb/dma/cocotb", {"ENGINE": "1"}, "dma_python_refmodel_buffered")]:
        env = dict(os.environ, **var)
        args = ["make"] + [f"{k}={v}" for k, v in var.items()]
        p = subprocess.run(args, cwd=os.path.join(ROOT, d), capture_output=True, text=True, env=env, timeout=3600)
        line = next((l.strip(" *") for l in p.stdout.splitlines() if "TESTS=" in l), "NO RESULT")
        out.append(dict(suite="cocotb", config=tag, args=" ".join(args[1:]), ok=p.returncode == 0 and "FAIL=0" in line,
                        result=line))
    p = subprocess.run([sys.executable, "-m", "pytest", "-q", "python/datafabric/tests"], cwd=ROOT,
                       capture_output=True, text=True)
    out.append(dict(suite="pytest", config="memmap_gen", args="", ok=p.returncode == 0,
                    result=p.stdout.strip().splitlines()[-1] if p.stdout.strip() else p.stderr[-300:]))
    return out


def main():
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        res = [r for rr in ex.map(build_and_run, BUILDS) for r in rr]
    res += cocotb_runs()
    n = sum(r["ok"] for r in res)
    rep = os.path.join(ROOT, "reports", "datafabric")
    os.makedirs(rep, exist_ok=True)
    json.dump(dict(passed=n, total=len(res), runs=res), open(os.path.join(rep, "unit_regression.json"), "w"), indent=1)
    with open(os.path.join(rep, "unit_regression.md"), "w") as f:
        f.write(f"# Unit regression\n\n**{n}/{len(res)} PASS**\n\n| suite | config | args | result |\n|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['suite']} | {r['config']} | {r['args']} | {'PASS' if r['ok'] else '**FAIL**'}: {r['result'][:150]} |\n")
    print(f"unit regression: {n}/{len(res)} PASS")
    for r in res:
        if not r["ok"]:
            print("FAIL", r)
    return 0 if n == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
