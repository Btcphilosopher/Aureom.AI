#!/usr/bin/env python3
"""DataFabric synthesis / PPA experiments (Yosys 0.33, technology independent).

No foundry or open-PDK Liberty file is available in this environment, so every
configuration is synthesised to a generic 2-input CMOS gate set
(`abc -g cmos2`: NAND/NOR/NOT + flops) and reported as:
  cells, flip-flops, multiplexer cells before tech mapping ($_MUX_), an
  estimated transistor count (`stat -tech cmos`), NAND2-equivalent area
  (transistors / 4) and the longest combinational path in gate levels
  (`ltp -noff`, a logic-depth proxy -- NOT a timing number).
Memories (SoC SRAM / ROM arrays) are kept as unmapped $mem cells and reported
separately as bits.  Latches are counted and must be zero.
Writes reports/datafabric/synth.{json,md} and the mapped netlists of the
default configurations to reports/datafabric/netlists/.
"""
import concurrent.futures as cf
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
OUT = os.path.join(ROOT, "build", "synth")
REP = os.path.join(ROOT, "reports", "datafabric")
IC = [f"rtl/interconnect/{f}" for f in (
    "sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
    "sfb_skid_buffer.sv", "sfb_reg_slice.sv", "sfb_v1_slave_adapter.sv", "sfb_crossbar.sv", "sfb_shared_bus.sv",
    "sfb_perf_counters.sv")]
DMA = [f"rtl/dma/{f}" for f in ("dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv",
                                "dma_irq.sv", "dma_control_regs.sv", "silicaflux_dma.sv")]
SFV = "third_party/silicaflux-v/rtl"
WRAP = "build/synth/wrappers.sv"


def base_mask(ns, win=0x10000):
    b = "{" + ", ".join(f"32'h{0x10000000 + s * win:08X}" for s in reversed(range(ns))) + "}"
    m = "{" + ", ".join(f"32'h{(~(win - 1)) & 0xFFFFFFFF:08X}" for _ in range(ns)) + "}"
    return b, m


def wrappers():
    """Fabric wrappers with a fixed address map (Yosys chparam cannot pass wide vectors conveniently)."""
    out = ["`default_nettype none"]
    for nm in (1, 2, 3, 4, 5):
        for ns in (4, 7):
            for dw in (32, 64, 128):
                b, m = base_mask(ns)
                for kind in ("xbar", "shared", "xbarreg"):
                    if kind != "xbar" and (nm == 1 or ns != 7):
                        continue
                    for arb in (0, 1):
                        name = f"w_{kind}_m{nm}_s{ns}_d{dw}_a{arb}"
                        sb = dw // 8
                        mod = "sfb_shared_bus" if kind == "shared" else "sfb_crossbar"
                        # sized all-ones: Yosys 0.33 reads an unsized '1 override as 1'b1
                        en = "" if kind == "shared" else f", .MST_SLV_EN({nm * ns}'h{(1 << (nm * ns)) - 1:X})"
                        ports = (f"  input wire logic clk, rst_n,\n"
                                 f"  input wire logic [{nm}-1:0] mv, mw, mrr, output logic [{nm}-1:0] mr, mrv, mre,\n"
                                 f"  input wire logic [{nm}*32-1:0] ma, input wire logic [{nm}*{dw}-1:0] md,\n"
                                 f"  input wire logic [{nm}*{sb}-1:0] mst, output logic [{nm}*{dw}-1:0] mrd,\n"
                                 f"  output logic [{ns}-1:0] sv, sw, srr, input wire logic [{ns}-1:0] sr, srv, sre,\n"
                                 f"  output logic [{ns}*32-1:0] sa, output logic [{ns}*{dw}-1:0] sd,\n"
                                 f"  output logic [{ns}*{sb}-1:0] sst, input wire logic [{ns}*{dw}-1:0] srd,\n"
                                 f"  output logic ee, ewr, output logic [31:0] ea, output logic [{max(1, (nm - 1).bit_length())}-1:0] em,\n"
                                 f"  output logic [{nm}-1:0] e0, e1, e2, e3")
                        if kind == "xbarreg":
                            body = (f"  logic [{ns}-1:0] xv, xw, xrr, xr, xrv, xre; logic [{ns}*32-1:0] xa;\n"
                                    f"  logic [{ns}*{dw}-1:0] xd, xrd; logic [{ns}*{sb}-1:0] xst;\n"
                                    f"  {mod} #(.NM({nm}), .NS({ns}), .DW({dw}), .ARB_MODE({arb}), .SLV_BASE({b}), .SLV_MASK({m}){en}) u (\n"
                                    f"    .clk, .rst_n, .m_req_valid(mv), .m_req_ready(mr), .m_req_write(mw), .m_req_addr(ma),\n"
                                    f"    .m_req_wdata(md), .m_req_wstrb(mst), .m_rsp_valid(mrv), .m_rsp_ready(mrr), .m_rsp_rdata(mrd),\n"
                                    f"    .m_rsp_error(mre), .s_req_valid(xv), .s_req_ready(xr), .s_req_write(xw), .s_req_addr(xa),\n"
                                    f"    .s_req_wdata(xd), .s_req_wstrb(xst), .s_rsp_valid(xrv), .s_rsp_ready(xrr), .s_rsp_rdata(xrd),\n"
                                    f"    .s_rsp_error(xre), .err_evt(ee), .err_addr(ea), .err_master(em), .err_write(ewr),\n"
                                    f"    .ev_req_accept(e0), .ev_req_stall(e1), .ev_arb_loss(e2), .ev_rsp_stall(e3));\n"
                                    f"  genvar g;\n  for (g = 0; g < {ns}; g++) begin : gs\n"
                                    f"    sfb_reg_slice #(.DW({dw})) r (.clk, .rst_n, .s_req_valid(xv[g]), .s_req_ready(xr[g]),\n"
                                    f"      .s_req_write(xw[g]), .s_req_addr(xa[g*32 +: 32]), .s_req_wdata(xd[g*{dw} +: {dw}]),\n"
                                    f"      .s_req_wstrb(xst[g*{sb} +: {sb}]), .s_rsp_valid(xrv[g]), .s_rsp_ready(xrr[g]),\n"
                                    f"      .s_rsp_rdata(xrd[g*{dw} +: {dw}]), .s_rsp_error(xre[g]), .m_req_valid(sv[g]), .m_req_ready(sr[g]),\n"
                                    f"      .m_req_write(sw[g]), .m_req_addr(sa[g*32 +: 32]), .m_req_wdata(sd[g*{dw} +: {dw}]),\n"
                                    f"      .m_req_wstrb(sst[g*{sb} +: {sb}]), .m_rsp_valid(srv[g]), .m_rsp_ready(srr[g]),\n"
                                    f"      .m_rsp_rdata(srd[g*{dw} +: {dw}]), .m_rsp_error(sre[g]));\n  end\n")
                        else:
                            body = (f"  {mod} #(.NM({nm}), .NS({ns}), .DW({dw}), .ARB_MODE({arb}), .SLV_BASE({b}), .SLV_MASK({m}){en}) u (\n"
                                    f"    .clk, .rst_n, .m_req_valid(mv), .m_req_ready(mr), .m_req_write(mw), .m_req_addr(ma),\n"
                                    f"    .m_req_wdata(md), .m_req_wstrb(mst), .m_rsp_valid(mrv), .m_rsp_ready(mrr), .m_rsp_rdata(mrd),\n"
                                    f"    .m_rsp_error(mre), .s_req_valid(sv), .s_req_ready(sr), .s_req_write(sw), .s_req_addr(sa),\n"
                                    f"    .s_req_wdata(sd), .s_req_wstrb(sst), .s_rsp_valid(srv), .s_rsp_ready(srr), .s_rsp_rdata(srd),\n"
                                    f"    .s_rsp_error(sre), .err_evt(ee), .err_addr(ea), .err_master(em), .err_write(ewr),\n"
                                    f"    .ev_req_accept(e0), .ev_req_stall(e1), .ev_arb_loss(e2), .ev_rsp_stall(e3));\n")
                        out.append(f"module {name} (\n{ports}\n);\n{body}endmodule")
    b, m = base_mask(7)
    out.append("module w_sfv_xbar_m3_s7 (\n  input wire logic clk, rst_n,\n"
               "  input wire logic [2:0] mv, mw, output logic [2:0] mr, mrv, mre,\n"
               "  input wire logic [95:0] ma, md, input wire logic [11:0] mst, output logic [95:0] mrd,\n"
               "  output logic [6:0] sv, sw, input wire logic [6:0] sr, srv, sre,\n"
               "  output logic [223:0] sa, sd, output logic [27:0] sst, input wire logic [223:0] srd,\n"
               "  output logic ee, ewr, output logic [31:0] ea, output logic [1:0] em\n);\n"
               f"  sfv_xbar #(.NM(3), .NS(7), .SLV_BASE({b}), .SLV_MASK({m}), .MST_SLV_EN(21'h1FFFFF)) u (\n"
               "    .clk, .rst_n, .m_req(mv), .m_gnt(mr), .m_addr(ma), .m_we(mw), .m_be(mst), .m_wdata(md),\n"
               "    .m_rvalid(mrv), .m_rdata(mrd), .m_err(mre), .s_req(sv), .s_gnt(sr), .s_addr(sa), .s_we(sw),\n"
               "    .s_be(sst), .s_wdata(sd), .s_rvalid(srv), .s_rdata(srd), .s_err(sre),\n"
               "    .err_evt(ee), .err_addr(ea), .err_master(em), .err_we(ewr));\nendmodule")
    out.append("`default_nettype wire\n")
    os.makedirs(os.path.dirname(os.path.join(ROOT, WRAP)), exist_ok=True)
    open(os.path.join(ROOT, WRAP), "w").write("\n".join(out))


# (name, group, top, files, chparams, description)
def configs():
    c = []
    for nm, ns, dw, arb in [(1, 7, 32, 0), (2, 7, 32, 1), (3, 7, 32, 0), (3, 7, 32, 1), (4, 7, 32, 0), (4, 7, 32, 1),
                            (5, 7, 32, 1), (4, 4, 32, 1), (4, 7, 64, 1), (4, 7, 128, 1), (2, 4, 32, 1), (3, 4, 32, 1),
                            (5, 4, 32, 1)]:
        c.append((f"xbar_m{nm}_s{ns}_d{dw}_{'rr' if arb else 'fp'}", "fabric", f"w_xbar_m{nm}_s{ns}_d{dw}_a{arb}",
                  [WRAP] + IC, {}, f"crossbar {nm}x{ns}, {dw}-bit, {'round robin' if arb else 'fixed priority'}"
                  + (" (= direct bus: one master)" if nm == 1 else "")))
    for nm in (3, 4):
        c.append((f"shared_m{nm}_s7_d32_rr", "fabric", f"w_shared_m{nm}_s7_d32_a1", [WRAP] + IC, {},
                  f"shared bus {nm}x7, 32-bit, round robin"))
        c.append((f"xbarreg_m{nm}_s7_d32_rr", "fabric", f"w_xbarreg_m{nm}_s7_d32_a1", [WRAP] + IC, {},
                  f"registered crossbar {nm}x7 (sfb_reg_slice on every slave port)"))
    c.append(("sfv_xbar_3x7_baseline", "fabric", "w_sfv_xbar_m3_s7", [WRAP, f"{SFV}/bus/sfv_xbar.sv"] + IC,
              {}, "SilicaFlux-V release-1 sfv_xbar 3x7, fixed priority (reference)"))
    for name, p, d in [
        ("dma_simple_d32", {"ENGINE": 0, "DW": 32}, "simple DMA, 32-bit (SilicaFlux-V default)"),
        ("dma_simple_d32_noperf", {"ENGINE": 0, "DW": 32, "PERF": 0}, "simple DMA, 32-bit, no perf counters"),
        ("dma_simple_d64", {"ENGINE": 0, "DW": 64}, "simple DMA, 64-bit"),
        ("dma_simple_d128", {"ENGINE": 0, "DW": 128}, "simple DMA, 128-bit"),
        ("dma_buf_f2_b2", {"ENGINE": 1, "FIFO_DEPTH": 2, "BURST": 2}, "buffered DMA, FIFO 2, burst 2"),
        ("dma_buf_f4_b4", {"ENGINE": 1, "FIFO_DEPTH": 4, "BURST": 4}, "buffered DMA, FIFO 4, burst 4"),
        ("dma_buf_f8_b8", {"ENGINE": 1, "FIFO_DEPTH": 8, "BURST": 8}, "buffered DMA, FIFO 8, burst 8"),
        ("dma_buf_f16_b16", {"ENGINE": 1, "FIFO_DEPTH": 16, "BURST": 16}, "buffered DMA, FIFO 16, burst 16"),
        ("dma_buf_f8_dual", {"ENGINE": 1, "FIFO_DEPTH": 8, "BURST": 8, "DUAL_PORT": 1}, "buffered DMA, FIFO 8, dual port"),
        ("dma_buf_f8_b8_d64", {"ENGINE": 1, "FIFO_DEPTH": 8, "BURST": 8, "DW": 64}, "buffered DMA, FIFO 8, 64-bit"),
    ]:
        c.append((name, "dma", "silicaflux_dma", DMA, p, d))
    c.append(("perf_counters_m4", "misc", "sfb_perf_counters", ["rtl/interconnect/sfb_perf_counters.sv"],
              {"NM": 4}, "DFPERF counters, 4 masters (optional)"))
    c.append(("v1_slave_adapter", "misc", "sfb_v1_slave_adapter", ["rtl/interconnect/sfb_v1_slave_adapter.sv"], {},
              "legacy-slave adapter (x7 in sfv_soc_df)"))
    c.append(("reg_slice_d32", "misc", "sfb_reg_slice", ["rtl/interconnect/sfb_skid_buffer.sv", "rtl/interconnect/sfb_reg_slice.sv"],
              {}, "register slice, req+rsp, 32-bit"))
    return c


SOC = [("soc_sfv_baseline", "soc", "sfv_soc", "SilicaFlux-V release-1 core SoC (sfv_xbar)"),
       ("soc_sfv_df_default", "soc", "sfv_soc_df", "SilicaFlux-V + DataFabric (simple DMA, RR, PERF=1)"),
       ("soc_sfv_df_noperf", "soc", "sfv_soc_df", "SilicaFlux-V + DataFabric (simple DMA, RR, PERF=0)")]


def soc_files():
    sfv = [os.path.join("third_party/silicaflux-v", l.strip())
           for l in open(os.path.join(ROOT, "third_party/silicaflux-v/rtl/files.f")) if l.strip()]
    return (sfv + ["build/fw/sfv_bootrom_image.sv", "generated/sfb_memmap_pkg.sv"] + IC + DMA +
            ["rtl/soc/sfv_soc_df.sv"])


def parse(log):
    def num(pat, default=0):
        m = re.findall(pat, log)
        return int(m[-1]) if m else default
    cells = num(r"Number of cells:\s+(\d+)")
    ff = sum(int(n) for n in re.findall(r"\$_(?:S?DFFE?|DFF|ALDFF|DFFSR|SDFFC?E?)_\w*\s+(\d+)", log.split("=== design hierarchy ===")[-1] if "=== design hierarchy ===" in log else log))
    tr = num(r"Estimated number of transistors:\s+(\d+)")
    latch = sum(int(n) for n in re.findall(r"\$_DLATCH\w*\s+(\d+)", log))
    membits = num(r"Number of memory bits:\s+(\d+)")
    depth = num(r"Longest topological path in \S+ \(length=(\d+)\)")
    mux = num(r"PREMAP_MUX\s+(\d+)")
    return dict(cells=cells, flops=ff, transistors=tr, nand2_eq=round(tr / 4), latches=latch, mem_bits=membits,
                logic_depth=depth, mux_premap=mux)


def run(cfg, flat_soc=False):
    name, group, top, files, ch, desc = cfg
    d = os.path.join(OUT, name)
    os.makedirs(d, exist_ok=True)
    chs = "".join(f"chparam -set {k} {v} {top}; " for k, v in ch.items())
    inc = "-Irtl/dma -Irtl/interconnect"
    script = (f"read_verilog -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE {inc} {' '.join(files)}; {chs}"
              f"hierarchy -check -top {top}; proc; flatten; opt; "
              # pre-mapping mux count (word-level $mux / $pmux bits after fine techmap)
              # SoC: SRAM/ROM arrays stay macros ($mem); blocks: small FIFOs/arrays become flops
              f"wreduce; alumacc; opt; {'memory -nomap' if group == 'soc' else 'memory'}; opt_clean; "
              f"techmap; opt -fast; tee -o {d}/premap.txt stat; "
              f"abc -g cmos2; opt_clean; "
              f"tee -o {d}/stat.txt stat -tech cmos; "
              f"tee -o {d}/ltp.txt ltp -noff; "
              f"write_verilog -noattr {d}/netlist.v")
    t0 = time.time()
    r = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys.log"), "-p", script], cwd=ROOT,
                       capture_output=True, text=True, timeout=7200)
    if r.returncode != 0:
        return dict(name=name, group=group, desc=desc, ok=False, error=(r.stderr or r.stdout)[-800:])
    stat = open(os.path.join(d, "stat.txt")).read()
    pre = open(os.path.join(d, "premap.txt")).read()
    ltp = open(os.path.join(d, "ltp.txt")).read()
    res = parse(stat + "\n" + ltp)
    res["mux_premap"] = sum(int(n) for n in re.findall(r"\$_MUX_\s+(\d+)", pre))
    res["flops"] = sum(int(n) for n in re.findall(r"\$_\w*DFF\w*\s+(\d+)", stat))
    if group == "soc":
        # Yosys 0.33 `stat` does not count $mem_v2 bits: report the configured macro bits instead
        # (4 SRAM banks x 8192 x 32 + TSPM 4 x 1024 x 32; the boot ROM image is synthesised to logic)
        res["mem_bits"] = 4 * 8192 * 32 + 4 * 1024 * 32
    res.update(name=name, group=group, desc=desc, top=top, params=ch, ok=True, secs=round(time.time() - t0, 1))
    return res


def hier_soc():
    """SoC synthesis WITHOUT flattening: per-module NAND2-eq of baseline vs DataFabric,
    so the DataFabric increment can be attributed module by module."""
    out = {}
    for top in ("sfv_soc", "sfv_soc_df"):
        d = os.path.join(OUT, "hier_" + top); os.makedirs(d, exist_ok=True)
        script = (f"read_verilog -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE -Irtl/dma -Irtl/interconnect {' '.join(soc_files())}; "
                  f"hierarchy -check -top {top}; proc; opt; wreduce; alumacc; opt; memory -nomap; opt_clean; "
                  f"techmap; opt -fast; abc -g cmos2; opt_clean; tee -o {d}/stat.txt stat -tech cmos")
        r = subprocess.run(["yosys", "-q", "-p", script], cwd=ROOT, capture_output=True, text=True, timeout=7200)
        if r.returncode:
            return None
        txt = open(os.path.join(d, "stat.txt")).read()
        mods = {}
        for m in re.finditer(r"=== (\S+) ===(.*?)(?==== |\Z)", txt, re.S):
            t = re.search(r"Estimated number of transistors:\s+(\d+)", m.group(2))
            mods[re.sub(r"^\$paramod(\$[0-9a-f]+)?\\", "", m.group(1)).split("\\")[0]] = int(t.group(1)) // 4 if t else 0
        cnt = {}
        hier = txt.split("=== design hierarchy ===")[-1]
        for name, n in re.findall(r"^\s+(\S+)\s+(\d+)$", hier, re.M):
            k = re.sub(r"^\$paramod(\$[0-9a-f]+)?\\", "", name).split("\\")[0]
            cnt[k] = cnt.get(k, 0) + int(n)
        tot = re.findall(r"Estimated number of transistors:\s+(\d+)", hier)
        out[top] = dict(total_nand2_eq=int(tot[-1]) // 4 if tot else None, per_module_nand2_eq=mods, instances=cnt)
    return out


def write_hier(h):
    if not h:
        return
    json.dump(h, open(os.path.join(REP, "synth_soc_hier.json"), "w"), indent=1)
    a, b = h["sfv_soc"], h["sfv_soc_df"]
    df_mods = ["sfb_crossbar", "sfb_rsp_router", "sfb_req_mux", "sfb_arbiter", "sfb_addr_decoder", "sfb_error_slave",
               "sfb_v1_slave_adapter", "silicaflux_dma", "dma_control_regs", "dma_irq", "dma_transfer_engine",
               "dma_validate", "sfb_perf_counters"]
    with open(os.path.join(REP, "synth_soc_hier.md"), "w") as f:
        f.write("# SoC synthesis with module boundaries kept (attribution)\n\n"
                f"Baseline sfv_soc: **{a['total_nand2_eq']}** NAND2-eq; sfv_soc_df (PERF=1): **{b['total_nand2_eq']}** "
                f"NAND2-eq; difference **{b['total_nand2_eq'] - a['total_nand2_eq']}** "
                f"({100 * (b['total_nand2_eq'] - a['total_nand2_eq']) / a['total_nand2_eq']:.1f} %).  Logic only "
                "(SRAM/ROM arrays are macros); generic gates; ICG replaced by its FPGA model (SFV_NO_CLOCK_GATE).\n\n"
                "| module | instances | NAND2-eq each | NAND2-eq total |\n|---|---|---|---|\n")
        tot = 0
        for m in df_mods:
            n, e = b["instances"].get(m, 0), b["per_module_nand2_eq"].get(m, 0)
            tot += n * e
            f.write(f"| {m} | {n} | {e} | {n * e} |\n")
        x = a["per_module_nand2_eq"].get("sfv_xbar", 0)
        f.write(f"| *removed:* sfv_xbar | 1 | {x} | -{x} |\n")
        for m in ("sfv_periph_bridge", "sfv_intc"):
            f.write(f"| {m} (baseline -> DataFabric) | 1 | {a['per_module_nand2_eq'].get(m, 0)} -> "
                    f"{b['per_module_nand2_eq'].get(m, 0)} | {b['per_module_nand2_eq'].get(m, 0) - a['per_module_nand2_eq'].get(m, 0)} |\n")
        f.write(f"\nSum of the DataFabric modules listed: {tot} NAND2-eq (of which sfb_perf_counters "
                f"{b['per_module_nand2_eq'].get('sfb_perf_counters', 0)}).\n")


def main():
    wrappers()
    jobs = configs()
    sel = sys.argv[1:]
    with_soc = not sel or "soc" in sel
    jobs = [j for j in jobs if not sel or j[1] in sel or j[0] in sel]
    soc_jobs = []
    if with_soc:
        for name, group, top, desc in SOC:
            ch = {"PERF": 0} if name.endswith("noperf") else {}
            soc_jobs.append((name, group, top, soc_files(), ch, desc))
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        res = list(ex.map(run, jobs + soc_jobs))
    ver = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    os.makedirs(REP, exist_ok=True)
    prev = {}
    pj = os.path.join(REP, "synth.json")
    if sel and os.path.exists(pj):
        prev = {r["name"]: r for r in json.load(open(pj)).get("results", [])}
    for r in res:
        prev[r["name"]] = r
    allres = list(prev.values())
    json.dump(dict(tool=ver, method=__doc__, results=allres), open(pj, "w"), indent=1)
    with open(os.path.join(REP, "synth.md"), "w") as f:
        f.write(f"# Synthesis results (technology independent)\n\n{ver}; `abc -g cmos2` (NAND/NOR/NOT); "
                "transistors from `stat -tech cmos`; NAND2-eq = transistors/4; depth = `ltp -noff` gate levels "
                "(logic-depth proxy, **not** timing); memories kept as macros (bits).  No PDK/Liberty was available: "
                "no node-specific area, timing or power is claimed.\n\n"
                "| config | description | cells | flops | NAND2-eq | transistors | logic depth | pre-map MUX | latches | mem bits |\n"
                "|---|---|---|---|---|---|---|---|---|---|\n")
        for r in sorted(allres, key=lambda r: (r["group"], r["name"])):
            if not r.get("ok"):
                f.write(f"| {r['name']} | {r['desc']} | FAILED | | | | | | | |\n")
                continue
            f.write(f"| {r['name']} | {r['desc']} | {r['cells']} | {r['flops']} | {r['nand2_eq']} | {r['transistors']} | "
                    f"{r['logic_depth']} | {r['mux_premap']} | {r['latches']} | {r['mem_bits']} |\n")
    if with_soc:
        write_hier(hier_soc())
    bad = [r for r in res if not r.get("ok") or r.get("latches")]
    for r in res:
        print(f"{r['name']:28s} " + (f"cells={r['cells']:7d} ff={r['flops']:6d} nand2eq={r['nand2_eq']:7d} depth={r['logic_depth']:3d} "
                                     f"latch={r['latches']}" if r.get("ok") else "FAILED " + r.get("error", "")[-300:]))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
