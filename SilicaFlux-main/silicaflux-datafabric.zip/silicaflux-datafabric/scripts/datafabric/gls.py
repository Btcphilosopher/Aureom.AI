#!/usr/bin/env python3
"""Gate-level simulation (GLS): synthesize a DUT with Yosys (same generic CMOS
flow as synth.py, parameters baked in), then run the SAME self-checking
testbench on the mapped netlist (+define+GLS, Yosys simcells.v gate models).
Catches simulation/synthesis mismatches (e.g. the Yosys 0.33 unsized-'1
parameter issue found in this project).  Writes reports/datafabric/gls.{json,md}."""
import json, os, subprocess, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
B = os.path.join(ROOT, "build", "gls")
SIMCELLS = os.environ.get("YOSYS_SIMCELLS", "/usr/share/yosys/simcells.v")
IC = [f"rtl/interconnect/{f}" for f in ("sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
                                         "sfb_error_slave.sv", "sfb_crossbar.sv")]
DMA = [f"rtl/dma/{f}" for f in ("dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv",
                                "dma_irq.sv", "dma_control_regs.sv", "silicaflux_dma.sv")]
_SL = "third_party/silicaflux-sramlib/rtl/mem"
SRAMLIB = ([f"-I{_SL}", f"-I{_SL}/backends/asic"] +
           sorted(f"{_SL}/backends/generic/{f}" for f in os.listdir(os.path.join(ROOT, _SL, "backends/generic"))) +
           sorted(f"{_SL}/backends/fpga/{f}" for f in os.listdir(os.path.join(ROOT, _SL, "backends/fpga"))) +
           [f"{_SL}/backends/asic/sram_asic_array.sv"] +
           sorted(f"{_SL}/backends/asic/{f}" for f in os.listdir(os.path.join(ROOT, _SL, "backends/asic")) if f.startswith("sram_leaf_")) +
           [f"{_SL}/backends/asic/stubs/sram_macro_blackboxes.sv"] +
           sorted(f"{_SL}/{f}" for f in os.listdir(os.path.join(ROOT, _SL)) if f.startswith("sram_") and f.endswith(".sv") and f != "sram_if.sv"))
# tb_sfb_xbar defaults: NM=3 NS=3 DW=32 ARB=1 WORDS=64 -> window 256 B at 0x1000_0000 + s*0x1_0000,
# master 2 denied slave 2 (EN bit 8)
JOBS = [
    ("xbar_3x3_rr", "sfb_crossbar", IC,
     {"NM": "3", "NS": "3", "DW": "32", "ARB_MODE": "1", "CHECK_ALIGN": "1",
      "SLV_BASE": "96'h10020000_10010000_10000000", "SLV_MASK": "96'hFFFFFF00_FFFFFF00_FFFFFF00",
      "MST_SLV_EN": "9'h0FF"},
     "tb_sfb_xbar", SRAMLIB + ["rtl/interconnect/sfb_skid_buffer.sv", "rtl/interconnect/sfb_reg_slice.sv",
                     "rtl/mem/sfb_sram_slave.sv", "rtl/mem/sfb_sram_1r1w_slave.sv",
                     "tb/common/sfb_protocol_checker.sv", "tb/interconnect/tb_sfb_xbar.sv"], [],
     [["+seed=1", "+cycles=20000"], ["+seed=2", "+cycles=20000", "+resets=3"], ["+seed=3", "+cycles=20000", "+mode=1"]]),
    ("dma_simple", "silicaflux_dma", DMA, {"DW": "32", "ENGINE": "0", "MAX_LEN_LOG2": "16"},
     "tb_dma", ["tb/common/sfb_protocol_checker.sv", "tb/common/sfb_trace_monitor.sv", "tb/dma/tb_dma.sv"] + IC,
     ["-GENGINE=0"], [["+seed=1", "+ntrans=30"]]),
    ("dma_buffered", "silicaflux_dma", DMA,
     {"DW": "32", "ENGINE": "1", "FIFO_DEPTH": "8", "BURST": "8", "MAX_OUT": "2", "MAX_LEN_LOG2": "16"},
     "tb_dma", ["tb/common/sfb_protocol_checker.sv", "tb/common/sfb_trace_monitor.sv", "tb/dma/tb_dma.sv"] + IC,
     ["-GENGINE=1"], [["+seed=1", "+ntrans=30"]]),
]


def main():
    os.makedirs(B, exist_ok=True)
    res = []
    for name, top, rtl, params, tbtop, tbfiles, tbgen, runs in JOBS:
        d = os.path.join(B, name); os.makedirs(d, exist_ok=True)
        net = os.path.join(d, f"{top}_netlist.v")
        ch = " ".join(f"-set {k} {v}" for k, v in params.items())
        script = (f"read_verilog -sv -DSYNTHESIS -Irtl/dma {' '.join(rtl)}; chparam {ch} {top}; "
                  f"hierarchy -check -top {top}; proc; flatten; opt; wreduce; alumacc; opt; memory; opt; "
                  f"techmap; opt -fast; abc -g cmos2; opt_clean; rename -top {top}; "
                  f"write_verilog -noattr {net}")
        y = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys.log"), "-p", script], cwd=ROOT,
                           capture_output=True, text=True)
        if y.returncode:
            res.append(dict(job=name, ok=False, stage="synth", detail=y.stderr[-600:])); continue
        obj = os.path.join(d, "obj")
        cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "4", "-Wno-fatal",
               "-Wno-lint", "-Wno-style", "-Irtl/dma", "+define+GLS", "--top-module", tbtop, "-Mdir", obj,
               "-o", "vtb"] + tbgen + [SIMCELLS, net] + tbfiles
        v = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        if v.returncode:
            res.append(dict(job=name, ok=False, stage="build", detail=v.stderr[-800:])); continue
        for a in runs:
            r = subprocess.run([os.path.join(obj, "vtb")] + a, cwd=ROOT, capture_output=True, text=True, timeout=3600)
            line = next((l for l in r.stdout.splitlines() if "RESULT" in l), "NO RESULT")
            res.append(dict(job=name, args=" ".join(a), ok=("RESULT PASS" in line and r.returncode == 0), result=line,
                            netlist=os.path.relpath(net, ROOT)))
            print(name, " ".join(a), "->", line)
    os.makedirs(os.path.join(ROOT, "reports", "datafabric"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "datafabric", "gls.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "datafabric", "gls.md"), "w") as f:
        n = sum(r["ok"] for r in res)
        f.write(f"# Gate-level simulation (Yosys generic netlist + simcells.v, Verilator)\n\n**{n}/{len(res)} PASS**\n\n"
                "| DUT | args | result |\n|---|---|---|\n")
        for r in res:
            f.write(f"| {r['job']} | {r.get('args', r.get('stage', ''))} | {r.get('result', r.get('detail', '')[:200])} |\n")
    for r in res:
        if not r["ok"]:
            print("FAIL", r)
    return 0 if all(r["ok"] for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
