#!/usr/bin/env python3
"""DataFabric performance sweep -- MEASURED in RTL simulation (Verilator, tb_dma +test=perf).

For every configuration the testbench copies 4 KiB (a) between two SRAM slaves
("xbank") and (b) inside one SRAM slave ("samebank") and reports the cycles
from the START register write until software sees BUSY = 0 (includes the
register-bus polling granularity of ~2 cycles).
  ideal      : no back-pressure, fixed 1-cycle slave latency, no other traffic
  contention : NC competing random masters active (70 % request rate, scratch
               regions in the same SRAM slaves), no back-pressure
Also measures a fairness study (fixed priority vs round robin) on a shared bus
and on the crossbar with tb_sfb_xbar.
Writes reports/datafabric/benchmark.{json,md}.  Nothing here is estimated: all
numbers come from the simulation logs referenced by command line.
"""
import concurrent.futures as cf
import json
import os
import re
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
B = os.path.join(ROOT, "build", "bench")
REP = os.path.join(ROOT, "reports", "datafabric")
IC = [f"rtl/interconnect/{f}" for f in ("sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
                                         "sfb_error_slave.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv",
                                         "sfb_crossbar.sv", "sfb_shared_bus.sv")]
DMA = [f"rtl/dma/{f}" for f in ("dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv",
                                "dma_irq.sv", "dma_control_regs.sv", "silicaflux_dma.sv")]
TB = ["tb/common/sfb_protocol_checker.sv", "tb/common/sfb_trace_monitor.sv", "tb/dma/tb_dma.sv"]

# name: dict of tb_dma parameters
DMA_CFGS = {
    "simple_d32": dict(ENGINE=0, DW=32),
    "simple_d64": dict(ENGINE=0, DW=64),
    "simple_d128": dict(ENGINE=0, DW=128),
    "buf_f2_b2": dict(ENGINE=1, FIFO_DEPTH=2, BURST=2),
    "buf_f4_b4": dict(ENGINE=1, FIFO_DEPTH=4, BURST=4),
    "buf_f8_b1": dict(ENGINE=1, FIFO_DEPTH=8, BURST=1),
    "buf_f8_b4": dict(ENGINE=1, FIFO_DEPTH=8, BURST=4),
    "buf_f8_b8": dict(ENGINE=1, FIFO_DEPTH=8, BURST=8),
    "buf_f16_b16": dict(ENGINE=1, FIFO_DEPTH=16, BURST=16),
    "buf_f8_dual": dict(ENGINE=1, FIFO_DEPTH=8, BURST=8, DUAL_PORT=1),
    "buf_f8_b8_d64": dict(ENGINE=1, FIFO_DEPTH=8, BURST=8, DW=64),
}
# master-count / arbitration sweep: simple engine with NC competing masters
for nc in (1, 2, 3, 4):
    for arb in (0, 1):
        DMA_CFGS[f"simple_nc{nc}_{'rr' if arb else 'fp'}"] = dict(ENGINE=0, NC=nc, ARB=arb)
        DMA_CFGS[f"buf8_nc{nc}_{'rr' if arb else 'fp'}"] = dict(ENGINE=1, FIFO_DEPTH=8, BURST=8, NC=nc, ARB=arb)


def build(name, params):
    obj = os.path.join(B, name)
    os.makedirs(obj, exist_ok=True)
    p = dict(NC=2, ARB=1, LMIN=1, LMAX=1)
    p.update(params)
    cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "2", "-Wno-fatal", "-Wno-lint",
           "-Wno-style", "-Irtl/dma", "--top-module", "tb_dma", "-Mdir", obj, "-o", "vtb"] + \
          [f"-G{k}={v}" for k, v in p.items()] + IC + DMA + TB
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return name, p, r.returncode, r.stderr[-800:]


def perf(name, p, scenario):
    nc = p["NC"]
    args = ["+test=perf", "+bp=0", "+seed=1", f"+nc_active={nc if scenario == 'contention' else 0}"]
    if scenario == "contention" and name.startswith(("simple_d32", "buf_f8_b8")):
        args.append(f"+trace=reports/datafabric/traces/tb_dma__{name}__contention.csv")
    cmd = [os.path.join(B, name, "vtb")] + args
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=1800)
    out = r.stdout
    def grab(tag):
        m = re.search(rf"PERF {tag} cycles=(\d+) bytes_per_cycle=([\d.]+)", out)
        return (int(m.group(1)), float(m.group(2))) if m else (None, None)
    xb, sb = grab("copy4k_xbank"), grab("copy4k_samebank")
    comp = re.search(r"competing_accepts=(\d+)", out)
    ok = "RESULT PASS" in out
    return dict(config=name, params=p, scenario=scenario, ok=ok, xbank_cycles=xb[0], xbank_bpc=xb[1],
                samebank_cycles=sb[0], samebank_bpc=sb[1], competing_accepts=int(comp.group(1)) if comp else None,
                cmd=" ".join(os.path.relpath(c, ROOT) if c.startswith(ROOT) else c for c in cmd))


def fairness():
    """tb_sfb_xbar sustained contention (mode 1) and random traffic: max wait per master."""
    rows = []
    for topo in (0, 1):
        for arb in (0, 1):
            tag = f"fair_t{topo}_a{arb}"
            obj = os.path.join(B, tag)
            os.makedirs(obj, exist_ok=True)
            cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "2", "-Wno-fatal",
                   "-Wno-lint", "-Wno-style", "--top-module", "tb_sfb_xbar", "-Mdir", obj, "-o", "vtb",
                   "-GNM=4", "-GNS=7", f"-GARB={arb}", f"-GTOPO={topo}", "-GLMIN=1", "-GLMAX=2"] + IC + \
                  ["tb/common/sfb_protocol_checker.sv", "tb/interconnect/tb_sfb_xbar.sv"]
            if subprocess.run(cmd, cwd=ROOT, capture_output=True).returncode:
                continue
            for mode in (0, 1):
                r = subprocess.run([os.path.join(obj, "vtb"), "+seed=1", "+cycles=20000", f"+mode={mode}"],
                                   cwd=ROOT, capture_output=True, text=True)
                acc = [int(x) for x in re.findall(r"master \d+: accepted=(\d+)", r.stdout)]
                mw = [int(x) for x in re.findall(r"max_wait=(\d+)", r.stdout)]
                rows.append(dict(topology="shared bus" if topo else "crossbar", arb="round robin" if arb else "fixed",
                                 traffic="sustained contention" if mode else "random", accepted=acc, max_wait=mw,
                                 min_share=round(min(acc) / max(1, sum(acc)), 4) if acc else None,
                                 result=next((l for l in r.stdout.splitlines() if "RESULT" in l), "")))
    return rows


def main():
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        builds = list(ex.map(lambda kv: build(*kv), DMA_CFGS.items()))
    res = []
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        futs = []
        for name, p, rc, err in builds:
            if rc:
                res.append(dict(config=name, ok=False, error=err)); continue
            futs.append(ex.submit(perf, name, p, "ideal"))
            futs.append(ex.submit(perf, name, p, "contention"))
        res += [f.result() for f in futs]
    fair = fairness()
    os.makedirs(REP, exist_ok=True)
    json.dump(dict(results=res, fairness=fair), open(os.path.join(REP, "benchmark.json"), "w"), indent=1)
    with open(os.path.join(REP, "benchmark.md"), "w") as f:
        f.write("# DataFabric RTL benchmark (MEASURED, Verilator)\n\n4 KiB copy, cycles from START to BUSY=0 "
                "(includes ~2-cycle register polling).  ideal = no back-pressure, 1-cycle slaves, no other traffic; "
                "contention = NC competing masters at 70 % request rate on the same SRAM slaves.\n\n"
                "| config | scenario | xbank cycles | xbank B/cycle | same-bank cycles | same-bank B/cycle | competing accepts | TB |\n"
                "|---|---|---|---|---|---|---|---|\n")
        for r in sorted(res, key=lambda r: (r["config"], r.get("scenario", ""))):
            if not r.get("ok") and "error" in r:
                f.write(f"| {r['config']} | BUILD FAIL | | | | | | |\n"); continue
            f.write(f"| {r['config']} | {r['scenario']} | {r['xbank_cycles']} | {r['xbank_bpc']} | {r['samebank_cycles']} | "
                    f"{r['samebank_bpc']} | {r['competing_accepts']} | {'PASS' if r['ok'] else 'FAIL'} |\n")
        f.write("\n## Arbitration fairness (tb_sfb_xbar, 4 masters x 7 slaves, 20k cycles)\n\n"
                "| topology | arbitration | traffic | accepted per master | max wait per master | min share | TB |\n"
                "|---|---|---|---|---|---|---|\n")
        for r in fair:
            f.write(f"| {r['topology']} | {r['arb']} | {r['traffic']} | {r['accepted']} | {r['max_wait']} | "
                    f"{r['min_share']} | {r['result'].replace('TB_SFB RESULT ', '')[:40]} |\n")
    bad = [r for r in res if not r.get("ok")]
    print(f"benchmark: {len(res) - len(bad)}/{len(res)} runs PASS; fairness rows {len(fair)}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
