// Formal harness: DMA engines (ENGINE = 0 dma_transfer_engine, ENGINE = 1
// dma_burst_engine single-port) against an arbitrary SFB2 slave.
// Environment: cfg_* arbitrary but held while busy (dma_control_regs refuses
// writes while busy), start/abort arbitrary; the slave answers only
// outstanding transactions, never in the acceptance cycle, in order, with
// arbitrary latency, readiness, data and error flags.
// Properties:
//   D1 no request while idle (no spurious / post-reset access)
//   D2 outstanding transactions <= 1 (ENGINE 0) / <= MAX_OUT (ENGINE 1)
//   D3 request payload stable while valid && !ready (SFB2 R2)
//   D4 every write lies inside [dst, dst+len): word address in range and no
//      strobe on a byte at or beyond dst+len
//   D5 completion implies every beat was written and acknowledged OK, with
//      nothing outstanding; bytes_done == len
//   D6 (ENGINE 0) no write after a read error in the same transfer
//   D7 writes never overtake good reads: writes issued <= good reads received
//   D8 no duplicate write: each write address is the next word after the
//      previous write of the transfer (strictly increasing, no repeats)
//   D9 bytes_done <= len, and bytes_done counts acknowledged writes only
// Small widths keep the state space tractable: the engine is generic in
// the address; len is constrained to < 2**LEN_BITS bytes.
module fv_dma_engine #(
  parameter int ENGINE   = 0,
  parameter int LEN_BITS = 6
) (
  input logic        clk,
  input logic        start, abort,
  input logic [31:0] cfg_src, cfg_dst, cfg_len,
  input logic        req_ready, rsp_valid, rsp_error,
  input logic [31:0] rsp_rdata
);
  localparam int DW = 32, SB = 4, MAXO = (ENGINE == 0) ? 1 : 2;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic        busy, done, fail, ev_stall, rsp_ready, req_valid, req_write;
  logic [7:0]  fifo_level;
  logic [3:0]  err_code;
  logic [31:0] err_addr, bytes_done, req_addr, req_wdata;
  logic [3:0]  req_wstrb;
  logic [2:0]  state;

  if (ENGINE == 0) begin : g_e0
    dma_transfer_engine #(.DW(DW), .MAX_LEN_LOG2(16)) dut (
      .clk, .rst_n, .start, .abort, .cfg_src, .cfg_dst, .cfg_len,
      .busy, .done, .fail, .err_code, .err_addr, .bytes_done, .state, .ev_stall,
      .req_valid, .req_ready, .req_write, .req_addr, .req_wdata, .req_wstrb,
      .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_error);
  end else begin : g_e1
    dma_burst_engine #(.DW(DW), .MAX_LEN_LOG2(16), .FIFO_DEPTH(4), .BURST(4), .DUAL_PORT(0),
                       .MAX_OUT(MAXO)) dut (
      .clk, .rst_n, .start, .abort, .cfg_src, .cfg_dst, .cfg_len,
      .busy, .done, .fail, .err_code, .err_addr, .bytes_done, .state, .ev_stall, .fifo_level,
      .req_valid, .req_ready, .req_write, .req_addr, .req_wdata, .req_wstrb,
      .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_error);
  end

`ifdef FORMAL
  logic        past, busy_q, pv, pw;
  logic [31:0] pa, pd;
  logic [3:0]  ps;
  logic [31:0] h_src, h_dst, h_len, h_rd_ok, h_wr_iss, h_wr_ok, h_last_wa;
  logic [2:0]  outst;
  logic        h_rd_err, h_any_w;
  logic [MAXO:0] typ;                      // type FIFO of outstanding requests (1 = write)
  wire acc  = req_valid && req_ready;
  wire rhs  = rsp_valid && rsp_ready;
  wire rtyp = typ[0];
  initial begin
    past = 1'b0; busy_q = 1'b0; pv = 1'b0; outst = 3'd0; typ = '0;
    h_rd_ok = '0; h_wr_iss = '0; h_wr_ok = '0; h_rd_err = 1'b0; h_any_w = 1'b0;
  end

  // environment
  always_comb if (rst_n) begin
    assume (cfg_len < (32'd1 << LEN_BITS));
    if (outst == 3'd0) assume (!rsp_valid);               // only outstanding transactions answered
    if (busy_q) assume (cfg_src == h_src && cfg_dst == h_dst && cfg_len == h_len);
  end

  always_ff @(posedge clk) begin
    past <= rst_n; busy_q <= busy;
    pv <= req_valid && !req_ready; pw <= req_write; pa <= req_addr; pd <= req_wdata; ps <= req_wstrb;
    if (!rst_n) begin
      outst <= 3'd0; typ <= '0;
    end else begin
      outst <= outst + 3'(acc) - 3'(rhs);
      if (acc && rhs)  typ <= (typ >> 1) | ((MAXO+1)'(req_write) << (outst - 3'd1));
      else if (acc)    typ <= typ | ((MAXO+1)'(req_write) << outst);
      else if (rhs)    typ <= typ >> 1;
    end
    if (!busy && start) begin
      h_src <= cfg_src; h_dst <= cfg_dst; h_len <= cfg_len;
      h_rd_ok <= '0; h_wr_iss <= '0; h_wr_ok <= '0; h_rd_err <= 1'b0; h_any_w <= 1'b0;
    end else begin
      if (rhs && !rtyp && !rsp_error) h_rd_ok <= h_rd_ok + 32'd1;
      if (rhs && !rtyp && rsp_error)  h_rd_err <= 1'b1;
      if (rhs && rtyp && !rsp_error)  h_wr_ok <= h_wr_ok + 32'd1;
      if (acc && req_write) begin h_wr_iss <= h_wr_iss + 32'd1; h_last_wa <= req_addr; h_any_w <= 1'b1; end
    end
  end

  always_comb if (rst_n) begin
    if (!busy) assert (!req_valid);                                         // D1
    assert (outst <= 3'(MAXO));                                             // D2
    if (ENGINE == 0) assert (!(acc && outst != 3'd0 && !rhs));
    if (req_valid && req_write) begin                                       // D4
      assert (req_addr >= h_dst && {1'b0, req_addr} < {1'b0, h_dst} + {1'b0, h_len});
      for (int b = 0; b < SB; b++)
        if (req_wstrb[b]) assert ({1'b0, req_addr} + 33'(b) < {1'b0, h_dst} + {1'b0, h_len});
      assert (req_addr[1:0] == 2'b00);
    end
    if (done) begin                                                         // D5
      assert (outst == 3'd0);
      assert (h_wr_ok == ((h_len + 32'd3) >> 2));
      assert (bytes_done == h_len);
    end
    if (ENGINE == 0 && h_rd_err) assert (!(req_valid && req_write));        // D6
    assert (h_wr_iss <= h_rd_ok);                                           // D7
    if (acc && req_write && h_any_w) assert (req_addr == h_last_wa + 32'd4);  // D8
    if (acc && req_write && !h_any_w) assert (req_addr == h_dst);
    if (busy_q) assert (bytes_done <= h_len);                               // D9
    if (busy_q && ENGINE == 0) assert (bytes_done <= (h_wr_ok << 2));
  end
  always_comb if (rst_n && past && pv)                                       // D3
    assert (req_valid && req_write == pw && req_addr == pa && req_wstrb == ps && (!pw || req_wdata == pd));
`endif
endmodule
