# DataFabric formal jobs beyond the interconnect: DMA engines and non-vacuity
# (mutant) checks.  exec()'d by run_formal.py, which defines JOBS, ic(), XBAR, HERE, DMA.
_DMAF = [os.path.join(DMA, f) for f in ("dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv",
                                        "dma_burst_engine.sv")]
_INC = ["-I" + DMA]
JOBS += [
    ("dma_simple_engine", "fv_dma_engine", _DMAF + [os.path.join(HERE, "fv_dma_engine.sv")],
     {"ENGINE": 0, "LEN_BITS": 6}, 40, True, {"pdr_timeout": 1200, "bmc_timeout": 900, "bmc_engine": "abc_bmc3"}),
    ("dma_burst_engine", "fv_dma_engine", _DMAF + [os.path.join(HERE, "fv_dma_engine.sv")],
     {"ENGINE": 1, "LEN_BITS": 5}, 40, True, {"pdr_timeout": 1200, "bmc_timeout": 900, "bmc_engine": "abc_bmc3"}),
    # ---- non-vacuity: each must produce a counterexample
    ("mut_xbar_misroute", "fv_sfb_xbar", XBAR + [os.path.join(HERE, "fv_sfb_xbar.sv")], {}, 6, False,
     {"expect": "FAIL", "note": "response routed to owner+1",
      "mutate": ("sfb_rsp_router.sv", "if (busy[s] && owner_oh[s*NM + m]) begin",
                 "if (busy[s] && owner_oh[s*NM + ((m + 1) % NM)]) begin")}),
    ("mut_xbar_no_lock", "fv_sfb_xbar", XBAR + [os.path.join(HERE, "fv_sfb_xbar.sv")], {}, 6, False,
     {"expect": "FAIL", "note": "grant lock removed (slave-side R2)",
      "mutate": ("sfb_arbiter.sv", "lock_q     <= grant_valid && stall && !accept;", "lock_q     <= 1'b0;")}),
    ("mut_arb_rr_stuck", "fv_sfb_arbiter", ic("sfb_arbiter.sv") + [os.path.join(HERE, "fv_sfb_arbiter.sv")],
     {"N": 3, "MODE": 1}, 12, False,
     {"expect": "FAIL", "note": "RR pointer never advances (fairness A4)",
      "mutate": ("sfb_arbiter.sv", "prio_q <= (grant_idx == IW'(N - 1)) ? '0 : grant_idx + IW'(1);", "prio_q <= prio_q;")}),
    ("mut_skid_drop", "fv_sfb_skid", ic("sfb_skid_buffer.sv") + [os.path.join(HERE, "fv_sfb_skid.sv")], {}, 10, False,
     {"expect": "FAIL", "note": "parked beat not stored",
      "mutate": ("sfb_skid_buffer.sv", "if (!(m_ready || !m_valid) && s_valid && s_ready) skid_data <= s_data;", "")}),
    ("mut_dma_tail_strobe", "fv_dma_engine", _DMAF + [os.path.join(HERE, "fv_dma_engine.sv")],
     {"ENGINE": 0, "LEN_BITS": 6}, 30, False,
     {"expect": "FAIL", "note": "tail strobe ignored (write beyond len)", "bmc_engine": "abc_bmc3",
      "mutate": ("dma_transfer_engine.sv", "req_wstrb <= tail_strb;", "req_wstrb <= '1;")}),
]
