// Formal harness: sfb_skid_buffer (the storage element of sfb_reg_slice).
// The producer sends a sequence-numbered stream (data = number of beats
// accepted so far); the consumer applies arbitrary back-pressure.
//   S1 no loss / duplication / re-ordering: every output beat carries the
//      next expected sequence number
//   S2 output stable while valid && !ready
//   S3 occupancy (accepted - delivered) never exceeds 2
//   S4 the producer is never blocked when the buffer is empty
module fv_sfb_skid (
  input logic clk,
  input logic s_valid,
  input logic m_ready
);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic       s_ready, m_valid;
  logic [7:0] m_data, in_cnt, out_cnt;
  sfb_skid_buffer #(.WIDTH(8)) dut (.clk, .rst_n, .s_valid, .s_ready, .s_data(in_cnt),
                                    .m_valid, .m_ready, .m_data);
`ifdef FORMAL
  logic       pv, past;
  logic [7:0] pd;
  initial begin in_cnt = 8'd0; out_cnt = 8'd0; pv = 1'b0; past = 1'b0; end
  always_ff @(posedge clk) begin
    past <= rst_n;
    if (!rst_n) begin in_cnt <= 8'd0; out_cnt <= 8'd0; end
    else begin
      if (s_valid && s_ready) in_cnt <= in_cnt + 8'd1;
      if (m_valid && m_ready) out_cnt <= out_cnt + 8'd1;
    end
    pv <= m_valid && !m_ready; pd <= m_data;
  end
  always_comb if (rst_n) begin
    if (m_valid) assert (m_data == out_cnt);                         // S1
    assert (8'(in_cnt - out_cnt) <= 8'd2);                           // S3
    assert ((in_cnt == out_cnt) || m_valid);                         // nothing hidden
    if (in_cnt == out_cnt) assert (s_ready);                          // S4
  end
  always_comb if (rst_n && past && pv) assert (m_valid && m_data == pd);   // S2
`endif
endmodule
