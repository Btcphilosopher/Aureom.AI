# ASIC configuration points (130 / 65 / 28 nm) -- templates only

No foundry PDK or standard-cell Liberty is available in this environment, and no
node-specific area/timing/power is claimed anywhere in this project.  The PPA
results in `reports/datafabric/synth.md` are technology-independent (generic CMOS
gates, transistor estimate, gate-level logic depth).

When a licensed PDK is available, DataFabric drops into the existing SilicaFlux-V
ASIC flow (`third_party/silicaflux-v` release: `asic/scripts/run_asic.sh`,
`asic/configs/*.cfg`, `asic/constraints/sfv_soc.sdc`) with the top replaced by
`sfv_soc_df` and the file list extended by `scripts/datafabric/lint.py`'s SOC list.
The templates below record the DataFabric-specific settings for each node.

| Node | Template | Status |
|---|---|---|
| 130 nm | `datafabric_130nm.cfg.template` | needs a licensed (or open sky130/IHP SG13G2) PDK |
| 65 nm | `datafabric_65nm.cfg.template` | needs a licensed foundry PDK + SRAM compiler |
| 28 nm | `datafabric_28nm.cfg.template` | needs a licensed foundry PDK + SRAM compiler; DFT/MBIST signoff |
