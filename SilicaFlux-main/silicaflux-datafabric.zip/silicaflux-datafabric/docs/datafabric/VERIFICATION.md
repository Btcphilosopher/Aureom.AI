# Verification

All results quoted here are produced by the commands in the Makefile and stored in
`reports/datafabric/` (JSON with command lines, seeds and exit codes; Markdown
summaries). [SUMMARY.md](../../reports/datafabric/SUMMARY.md) lists the final pass
counts and tool versions; a test is only claimed if it ran and passed there.

## 1. Environment

| Layer | Tooling | Where |
|---|---|---|
| Self-checking SV testbenches | Verilator 5.020 (`--binary --timing`) | `tb/interconnect/tb_sfb_xbar.sv`, `tb_sfb_reg_slice.sv`, `tb/dma/tb_dma.sv`, `tb/soc/tb_soc_df.sv` |
| cocotb + Python reference model | cocotb 2.1, Icarus 12 | `tb/dma/cocotb/test_dma_cocotb.py`; silicaflux-v `test_xbar.py` (unmodified) in `tb/interconnect/v1compat/` |
| Protocol assertions | `tb/common/sfb_protocol_checker.sv` on every master/slave port | R2, R4, R5, R6, R8, X checks |
| Formal | Yosys 0.33 → SMT2 (yosys-smtbmc + z3) and AIGER (ABC `bmc3`, `pdr`) | `formal/datafabric/` |
| Gate-level simulation | Yosys generic netlist + `simcells.v` in the same testbenches | `scripts/datafabric/gls.py` |
| Testbench strength | mutation campaign (12 injected RTL bugs) | `scripts/datafabric/xbar_mutants.py` |
| Firmware on the real CPU | SilicaFlux-V RV32I core in `sfv_soc_df` | `firmware/examples/dma_demo` |
| Generator tests | pytest | `python/datafabric/tests` |

Independent scoreboards: the crossbar testbench checks **request conservation**
(every mapped master acceptance coincides with an identical slave acceptance and
vice versa), **response prediction** from a shadow memory updated in acceptance
order, and **final memory equality**; the DMA testbench keeps a byte-exact
expected memory and a **write monitor** that checks every DMA write against the
destination range and the source data. Seeds are passed as `+seed=` and recorded
in every JSON report; the xorshift generators are tool-independent.

## 2. Bus verification items

| # | Requirement | Covered by |
|---|---|---|
| 1 | single-master read | `tb_sfb_xbar +mode=2` (single active requester), NM=1 config |
| 2 | single-master write | same |
| 3 | multiple masters | NM = 2…5 configs |
| 4 | multiple slaves | NS = 1…7 configs |
| 5 | simultaneous requests | random mode + sustained contention (`+mode=1`) |
| 6 | round-robin arbitration | ARB=1 configs; fairness bound check in mode 1; PDR proof A4 |
| 7 | fixed priority | ARB=0 configs; expected starvation asserted in mode 1 |
| 8 | read/write back-pressure | random `req_ready` slaves + random master `rsp_ready` (`+rsp_bp`) |
| 9 | slow SRAM response | slave latency 1…8; SRAM library READ_LATENCY 1…3 |
| 10 | illegal address | unmapped, hole, misaligned, access-matrix denied → error + `err_evt` |
| 11 | response ordering | per-master in-order expectation; MemoryLab `trace_metrics` order check |
| 12 | reset during a transaction | `+resets=K` (cancelled writes resolved per R11) |
| 13 | byte write strobes | random sparse strobes, byte-merge shadow |
| 14 | continuous contention | mode 1 + 200k-cycle long run |
| 15 | non-power-of-two master count | NM = 3, 5 |
| 16 | register-slice behaviour | `tb_sfb_reg_slice` (multi-outstanding stream, 1.0 transfer/cycle) + SLICE=1 crossbar configs + PDR proof of the skid buffer |
| 17 | error propagation | slave-error words, decode errors, `rsp_rdata = 0` (R8) |
| — | request cancellation before acceptance | `-GWITHDRAW=1` configs: masters withdraw/replace un-accepted requests; no loss/duplication |
| — | backward compatibility | silicaflux-v `test_xbar.py` unmodified (fixed + RR); release-1 SoC scenarios cycle-identical |
| — | SRAM Wrapper Library slaves | `tb_sfb_xbar -GSLAVES=1/2 -GSRAM_LAT=1..3` |

## 3. DMA verification items

| # | Requirement | Covered by |
|---|---|---|
| 1 | one-word copy | `tb_dma` directed `one-word`; firmware D2 |
| 2 | multiword copy | directed `multi-word`, 4 KiB, random 1…700 B |
| 3 | byte-length boundaries | every length 1…3·DW/8+1 with guard bytes (tb + firmware D2) |
| 4 | address alignment | SRC_ALIGN / DST_ALIGN (tb, cocotb, firmware D3) |
| 5 | invalid source | unmapped source → READ_BUS, ERROR_ADDR; source running off a region → prefix copied |
| 6 | invalid destination | unmapped → WRITE_BUS; peripheral page denied by the access matrix; ROM |
| 7 | address overflow | SRC_OVERFLOW / DST_OVERFLOW |
| 8 | overlapping ranges | forward, backward, identical |
| 9 | transfer reset | async reset mid-copy: idle, registers reset, no spurious request after reset |
| 10 | bus read error | poisoned source word mid-transfer: prefix semantics, ERROR_ADDR |
| 11 | bus write error | poisoned destination word |
| 12 | interrupt completion | `t_irq`, firmware D5 (`wfi`) |
| 13 | interrupt acknowledgement | W1C, masking, error IRQ |
| 14 | busy-state register protection | SRC/DST/LEN/START refused while busy, values unchanged; firmware D4 (store faults) |
| 15 | queue saturation | buffered engine: FIFO occupancy must reach its credit limit (asserted); credit FIFO never overflows (RTL assertion + bounded formal D2) |
| 16 | random back-pressure | `+bp=0/20/40`, latency ranges |
| 17 | randomized valid lengths | `t_random`, cocotb random transfers vs Python model |
| 18 | DMA competing with CPU | competing masters in tb; firmware D8 (CPU checksum concurrent, perf counters) |
| 19 | DMA competing with vector/tensor | tb competing masters model accelerator traffic; firmware D9 (DMA vs tensor engine on TSPM banks, TE latency unchanged) |
| 20 | sustained multi-transfer | 60–80 back-to-back random transfers per run; firmware ~60 transfers |

## 4. Assertions / proofs

| Property | Simulation | Formal |
|---|---|---|
| exclusive arbitration grants | protocol + conservation checks | A1 (PDR, unbounded), crossbar P2 |
| transaction conservation | conservation scoreboard | crossbar P3 (PDR) |
| stable payloads during stalls | R2/R4 checkers on every port | crossbar P7, skid S2 (unbounded), DMA D3 (bounded) |
| correct read-response ownership | response prediction | crossbar P4/P4b (PDR) |
| no false write acknowledgement | write responses only after the slave model wrote; R7 in adapters | — (by construction; GLS) |
| no accepted DMA transfer disappearing | every START ends in DONE or ERROR (tb waits with timeout) | — (liveness not proven: no watchdog by design) |
| no duplicate write operations | write monitor + byte-exact memory | DMA D8 (consecutive addresses; bounded) |
| DMA completion implies all writes completed | BYTES_DONE == LEN at DONE | DMA D5 (bounded) |
| no write outside the destination range | write monitor (address + strobes) | DMA D4 (bounded) |
| no request while idle / after reset | write monitor | DMA D1 (bounded) |
| round-robin bounded waiting | mode-1 fairness bound | A4 (PDR) |

**Non-vacuity:** the same harnesses on mutated RTL must fail — response misroute,
missing grant lock, frozen RR pointer, dropped skid entry, ignored tail strobe
(`formal.md`, `expect FAIL` rows).

## 5. Known verification gaps

* **DMA properties D1–D9 are proven only to a bounded depth.** The final run gives
  no counterexample in 23 cycles from reset (simple engine, length < 64 B) and
  22 cycles (buffered engine, length < 32 B) with ABC `bmc3` at a 900 s budget.
  ABC PDR did not converge within 1,200 s (frame 76 / frame 18) for either engine.
  23 cycles cover the start, validation and the first ~4–5 beats of a transfer,
  including short-length tail strobes and error paths, but not a full-length
  transfer. Long transfers are covered by simulation only (`tb_dma`, cocotb,
  firmware). The interconnect proofs (arbiter, skid buffer, crossbar) are
  unbounded (PDR PROVED).
* No liveness proofs (a never-responding slave keeps the DMA busy by design).
* SoC tests are firmware-directed; no constrained-random system-level test with
  JTAG + CPU + DMA together (DF-04 in ISSUES.md).
* Gate-level simulation uses Yosys generic cells (no foundry library, no timing).
