# Firmware: DMA driver and demonstration

Toolchain: clang/lld (RV32I_Zicsr, ilp32), identical flags to SilicaFlux-V release 1.
`make datafabric-fw` builds into `build/fw/`:

| Output | Source | Notes |
|---|---|---|
| `sfv_bootrom_image.sv` | `third_party/silicaflux-v/firmware/bootrom` (unmodified) | byte-identical image to release 1 (sha256 prefix `13b0b165bdf76bd2`) |
| `sfv_app_{sram,flash}.hex` | release-1 acceptance app (unmodified) | regression of the original SoC on the new fabric |
| `dma_demo_{sram,flash}.hex` | `firmware/examples/dma_demo/main.c` + driver | 167 checks, loadable through SRAM backdoor, SPI flash or JTAG boot |

Register/field/enum names come from `generated/sfv_df_map.h` (generated from the
memory-map YAML), so the driver cannot drift from the RTL register map.

## Driver API (`firmware/drivers/silicaflux_dma.h`)

| Function | Behaviour |
|---|---|
| `dma_init()` | checks `ID == 'SFDF'`, not busy, masks + clears interrupts |
| `dma_info()` | `INFO` (data width, engine, FIFO, max length, version) |
| `dma_check(x)` | software validation: zero/too-long length, alignment, 2^32 wrap, overlap (`DMA_DRV_EINVAL`), DMA-reachable regions only — SRAM, TSPM, ROM as source (`DMA_DRV_ERANGE`) |
| `dma_configure(x)` / `dma_configure_raw(x)` | validate (or not) and program SRC/DST/LENGTH; `DMA_DRV_EBUSY` while busy |
| `dma_start()` | START; `DMA_DRV_EBUSY` if busy |
| `dma_poll(st)` | `DMA_POLL_BUSY` (0x100), 0 = done, > 0 = hardware `ERROR_CODE` |
| `dma_wait(n, st)` | poll up to n times; `DMA_DRV_ETIMEDOUT` |
| `dma_abort()` | real hardware abort (next beat boundary) |
| `dma_get_status()`, `dma_enable_interrupt()`, `dma_clear_interrupt()`, `dma_pending_interrupt()` | register access |
| `dma_copy(dst, src, len)` | configure + start + wait |
| `dma_isr()` | example ISR: records and acknowledges `INT_STATUS` |

Return convention: 0 success, > 0 hardware `ERROR_CODE` (`DMA_ERR_*`), < 0 driver error.
`DMA_POLL_BUSY` is deliberately outside the 4-bit error-code range: an earlier value
of 1 equalled `DMA_ERR_ZERO_LENGTH` and made `dma_wait()` spin on a finished
transfer — found by the SoC firmware regression.

## Interrupt service example

```c
__attribute__((interrupt("machine"))) void trap_entry(void) {
  uint32_t cause = csr_read(mcause);
  if ((cause & 0x80000000u) && (cause & 0x1Fu) == 11u) {      /* machine external */
    uint32_t c = INTC_CLAIM;                                   /* 1 + source */
    if (c == SFV_DF_IRQ_DMA + 1u) dma_isr();
    return;
  }
  /* exceptions ... */
}
/* enable: INTC_ENABLE = 1u << SFV_DF_IRQ_DMA; csr_set(mie, MIE_MEIE);
 *         csr_set(mstatus, MSTATUS_MIE); dma_enable_interrupt(DMA_IRQ_DONE | DMA_IRQ_ERROR); */
```

## Usage example

```c
#include "silicaflux_dma.h"
dma_init();
int r = dma_copy(0x20000000u /* TSPM */, 0x10008000u /* SRAM */, 1024);
if (r > 0)  { /* hardware error: DMA_ERR_* ; see ERROR_ADDR / BYTES_DONE via dma_poll() */ }
if (r < 0)  { /* rejected by the driver before touching the hardware */ }
```

## Demonstration program (`firmware/examples/dma_demo`)

D1 identity · D2 SRAM→SRAM copies (4 KiB, every length 1..9 with guard bytes, bank
crossing, ROM source) · D3 every validation error, unmapped source/destination, DMA
write into a peripheral page denied by the access matrix (GPIO unchanged), ROM as
destination · D4 busy protection (three refused writes → store access faults),
abort with prefix check, full copy after abort · D5 completion and error interrupts
with `wfi` · D6 **CPU → SRAM → DMA → TSPM → tensor engine → TSPM → DMA → SRAM → CPU
verification** for K = 4…256, signed/unsigned · D7 the same through the vector
engine (ADD/XOR/MUL/DOT) · D8 CPU loop vs DMA copy cycles, DMA copy concurrent with a
CPU checksum on the same bank, DataFabric performance counters. Result over UART and
`SYSCTRL.TEST_STATUS` (the testbench's PASS criterion).
