# DataFabric documentation

| Document | Content |
|---|---|
| [AUDIT.md](AUDIT.md) | Phase 1 repository audit: `.sf` verdict, module table (10 columns), reuse decisions, pre-existing defects found |
| [PROTOCOL.md](PROTOCOL.md) | SFB2 specification: signals, rules R1–R12, combinational-path rules, arbitration, errors, reset, route to IDs, tool-portability rules |
| [ARCHITECTURE.md](ARCHITECTURE.md) | topology, components, clock/reset/CDC, vector/tensor and SRAM-library integration, counters and traces |
| [DMA.md](DMA.md) | DMA behaviour: programming sequence, validation, busy protection, FSM, errors, abort, interrupts, buffered engine |
| [MEMORY_MAP.md](MEMORY_MAP.md) | generated memory and register map (do not edit; edit `memmap/*.yaml`) |
| [FIRMWARE.md](FIRMWARE.md) | driver API, ISR example, demonstration program |
| [VERIFICATION.md](VERIFICATION.md) | test environment, requirement → test mapping, assertions/proofs, gaps |
| [PPA.md](PPA.md) | synthesis method, topology/width/master-count/DMA sweeps, SoC area, recommendation |
| [ISSUES.md](ISSUES.md) | prioritised open issues/blockers and defects resolved during this work |
