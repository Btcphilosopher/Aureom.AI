# SilicaFlux CloudRuntime (Project 70) — `runtime/cloud/`

Host software for the **SilicaFlux CloudDPU**: discover a device, allocate protected buffers, submit operations, get
verified completions and telemetry — against the **real P61 CloudDPU RTL in Verilator** and a **CPU reference model**;
plus a Kubernetes device plugin, container integration, a Prometheus exporter, a benchmark suite and security/reliability
test suites.

> ### Status — read this first
> * **Simulation only.** `rtl-sim` = the *unmodified* P61 RTL under Verilator 5.020 (cycle-accurate; *no clock frequency*).
>   `cpu-ref` = a software model of the same contract, differentially tested against the RTL.
> * **No hardware support is claimed.** The `hw` backend cannot be opened (read-only probe, always "unavailable"). No FPGA/ASIC
>   result exists; FPGA bring-up is **BLOCKED** (`fpga/BRINGUP_STATUS.md`). The brief requires separate hardware validation.
> * **PacketCore in the RTL is a test adapter** (PASS/XOR32/BSWAP32 + CRC-32 + checksum, no packet parsing). GEMM, AES-GCM and
>   storage are **blocked in the RTL**; they exist only as **software extensions** in `cpu-ref`. On `rtl-sim` they fail with
>   `SF_ERR_UNSUPPORTED` — never emulated.
> * **Not production-ready.** In-process isolation is an API boundary; the socket-served mediator + VFIO path is designed,
>   not built. See `docs/10_LIMITATIONS.md`.

## Definition of done (brief §20) — all met in simulation

| # | A user can… | How (verified on `rtl-sim` and `cpu-ref`) |
|---|---|---|
| 1 | build the runtime | `make` (clean-room measured on 4 cores: 27 s for the 3 RTL geometries + 91 s for the Rust workspace, crate registry already cached; a first build also downloads crates) |
| 2 | discover a simulated or actual device | `sfctl discover` / `sf_cloud_discover` — every entry states why it is/isn't available |
| 3 | allocate a protected buffer | `sf_cloud_alloc(… SF_MEM_DEV_READ / DEV_WRITE)` — window-placed, generation-tagged, scrubbed |
| 4 | submit a supported operation | `sf_cloud_submit(PKT_PROCESS / COPY / DMA_*)` |
| 5 | receive a correct completion | `committed`, CRC-32 in/out, RFC 1071 checksum — checked against independent references |
| 6 | read the result | `sf_cloud_read` |
| 7 | collect performance counters | `sf_cloud_counters`, `/metrics` (real DPU counters) |
| 8 | release resources cleanly | `sf_cloud_close` — hardware scrub of SRAM partitions, host windows zeroed, keys wiped |

`sfctl slice --backend rtl-sim:mt` runs all eight steps and prints the evidence; exit 0 iff everything verified.
Kubernetes: the plugin represents device **health** (pushed over `ListAndWatch`) and **allocation** (validated `Allocate`,
ledger) — checked against a mock kubelet and against Kubernetes' official generated stubs (`docs/05`).

## Layout

```
rtl/vendor/clouddpu-p61/   P61 RTL, UNMODIFIED, byte-identical to the archive (SHA-256 manifest)
rtl/sim/                   Verilator harness (C++), C API (sf_rtl_api.h), Makefile, raw C smoke test
crates/sf-cloud/           runtime: backends (cpu-ref, rtl-sim, hw probe), mediator, C ABI, telemetry, container helpers
                           tests/ (52+ integration tests)  examples/ (A–F)
crates/sf-cli/             sfctl           crates/sf-exporter/   Prometheus exporter + dashboard
crates/sf-device-plugin/   kubelet device plugin (v1beta1)       crates/sf-bench/      benchmark suite
include/sf_cloud.h         the stable C ABI          python/   ctypes binding, tests, examples, report tools
deploy/                    k8s manifests, Dockerfile  third_party/k8s/   upstream device-plugin proto (+provenance)
tests/k8s-interop/         Go fake kubelet on the official k8s stubs     fpga/   prerequisite checker + status (BLOCKED)
benchmarks/results/        JSON reports (reproducibility metadata)       scripts/  CI, examples, manifest check, packaging
docs/                      00 readiness · 01 architecture · 02 API · 03 Linux access · 04 isolation · 05 Kubernetes ·
                           06 observability · 07 benchmarks · 08 FPGA · 09 testing · 10 limitations · BUILD_AND_DEPLOY
```

## Quick start

```bash
make                                              # RTL libs + release build
target/release/sfctl slice --backend rtl-sim:mt   # the vertical slice
make test                                         # everything (RTL required)
scripts/run_examples.sh                           # examples A–F on every backend
make bench                                        # benchmark reports → benchmarks/results/
```

## Headline results (details and caveats in `docs/07`)

* Differential: 600 random + malformed commands identical on `cpu-ref` and the RTL (completions, host memory, counters, telemetry).
* A copy + FCS runs at ≈0.45 B/device-cycle — about **8× slower than one CPU core at an assumed 100 MHz**: *no acceleration
  advantage is demonstrated*; the P61 baseline is a functional design (one outstanding request per port, one shared PacketCore).
* Two tenants contend to **1.98×** (fully serialised) — fair (Jain 1.00) but not isolated in time.

## Provenance

Vendored RTL: `btcphilosopher/Aureom.AI` archives (`rtl/vendor/clouddpu-p61`, hashes in `clouddpu-p61.SHA256SUMS`). K8s proto:
upstream verbatim (`third_party/k8s/PROVENANCE.md`). The repository has **no licence file**: manifests say `UNLICENSED`; an owner
must choose one before any distribution. Nothing in this package was committed or pushed.
