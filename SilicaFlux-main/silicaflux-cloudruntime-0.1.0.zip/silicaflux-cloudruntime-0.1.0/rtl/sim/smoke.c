/* Raw smoke test of the RTL simulation transport, driving the Project 61 CloudDPU RTL directly through
 * sfrtl_*.  Independent of the Rust runtime: this checks the harness and the DPU's documented ABI
 * (docs/DPU_MEMORY_MAP.md, silicaflux_cloud_pkg.sv) using values taken from those documents. */
#include "sf_rtl_api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define G(o)    (0x40008000u + (o))
#define T(t, o) (0x40009000u + 0x100u * (t) + (o))
static sfrtl_t *h;
static int fails;
#define CHECK(c, ...) do { if (!(c)) { printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); fails++; } } while (0)

static uint32_t rd(uint32_t a) { uint32_t v = 0; int r = sfrtl_mgmt(h, 0, a, 0, &v, 100000); CHECK(r == 0, "read %08x -> %d", a, r); return v; }
static void wr(uint32_t a, uint32_t v) { int r = sfrtl_mgmt(h, 1, a, v, NULL, 100000); CHECK(r == 0, "write %08x -> %d", a, r); }

static uint32_t crc32(const uint8_t *d, size_t n) {
    uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) { c ^= d[i]; for (int k = 0; k < 8; k++) c = (c & 1) ? (c >> 1) ^ 0xEDB88320u : c >> 1; }
    return ~c;
}

int main(void) {
    char err[256] = "";
    sfrtl_options o; memset(&o, 0, sizeof o); o.struct_size = sizeof o; o.host_lat_max = 3; o.seed = 7; o.access_log = 1;
    h = sfrtl_open(&o, err, sizeof err);
    if (!h) { printf("open failed: %s\n", err); return 2; }
    sfrtl_build_info bi; sfrtl_build_info_get(h, &bi);
    printf("model: %s cfg=%s verilator=%s tenants=%u queues=%u+%u\n", bi.design, bi.config_name, bi.verilator, bi.num_tenants, bi.num_net_queues, bi.num_compute_queues);

    /* discovery through the DPU's own registers */
    CHECK(rd(G(0x000)) == 0x53464450u, "ID is not 'SFDP'");
    CHECK(rd(G(0x004)) == 0x00010000u, "ABI version");
    uint32_t c0 = rd(G(0x008));
    CHECK((c0 & 0xFF) == bi.num_tenants, "CONFIG0 tenants");
    uint32_t blk = rd(G(0x018));
    printf("BLOCK_STATUS=%08x (PACKETCORE=%u CLOUDDMA=%u VIRTUALIO=%u INFER=%u CRYPTO=%u STORAGE=%u TLM=%u CC=%u)\n", blk,
           blk & 3, (blk >> 2) & 3, (blk >> 4) & 3, (blk >> 6) & 3, (blk >> 8) & 3, (blk >> 10) & 3, (blk >> 12) & 3, (blk >> 14) & 3);
    CHECK((blk & 3) == 2, "PacketCore must report TEST_ADAPTER");
    CHECK(((blk >> 6) & 3) == 1 && ((blk >> 8) & 3) == 1 && ((blk >> 10) & 3) == 1, "INFER/CRYPTO/STORAGE must report BLOCKED");

    /* bring up tenant 0: SRAM partition [0, 32K), window0 R (input), window1 RW (output) */
    const uint64_t IN = 0x40000000ull, OUT = 0x40010000ull;
    wr(T(0, 0x00C), 0); wr(T(0, 0x010), 32768);
    wr(T(0, 0x020), (uint32_t)IN);  wr(T(0, 0x024), 0); wr(T(0, 0x028), 0x10000); wr(T(0, 0x02C), 0x1 | 0x2);
    wr(T(0, 0x030), (uint32_t)OUT); wr(T(0, 0x034), 0); wr(T(0, 0x038), 0x10000); wr(T(0, 0x03C), 0x1 | 0x2 | 0x4);
    wr(T(0, 0x004), 1); /* COMMIT */
    uint32_t cfg = 0; for (int i = 0; i < 1000 && !(cfg = rd(T(0, 0x008)) & 0xFF); i++) {}
    CHECK(cfg == 1, "COMMIT result %u (want CFG_OK=1)", cfg);
    uint32_t st = 0; for (int i = 0; i < 4000; i++) { st = rd(T(0, 0)); if ((st & 7) == 0 && (st & 0x100)) break; sfrtl_run(h, 16); }
    CHECK((st & 0x100) && (st & 7) == 0, "tenant configured+scrubbed (state=%08x)", st);
    wr(T(0, 0x004), 2); /* ENABLE */
    CHECK((rd(T(0, 0)) & 7) == 1, "tenant ACTIVE");
    wr(G(0x020), 1);    /* CTRL.EN */

    /* host data */
    uint8_t in[64], exp[64];
    for (int i = 0; i < 64; i++) { in[i] = (uint8_t)(i * 7 + 3); exp[i] = in[i] ^ 0xA5; }
    CHECK(sfrtl_hostmem_write(h, IN, in, 64) == 0, "hostmem write");

    uint32_t cmd[12], cpl[8];
    memset(cmd, 0, sizeof cmd);
    cmd[0] = 0x00; cmd[1] = 0x100;                    /* NOP */
    CHECK(sfrtl_submit(h, 0, cmd, 10000) == 0, "submit NOP");
    CHECK(sfrtl_run_until_cpl(h, 0, 100000) == 1, "NOP completion");
    CHECK(sfrtl_cpl_pop(h, 0, cpl) == 1, "pop"); CHECK(((cpl[0] >> 8) & 0xFF) == 0 && ((cpl[0] >> 16) & 0xFF) == 0, "NOP status/err %08x", cpl[0]);

    memset(cmd, 0, sizeof cmd);                        /* PKT_PROCESS XOR32 */
    cmd[0] = 0x01; cmd[1] = 0x101; cmd[2] = (uint32_t)IN; cmd[4] = (uint32_t)OUT; cmd[6] = 64; cmd[7] = 0; cmd[8] = 0x01; cmd[9] = 0xA5A5A5A5u;
    CHECK(sfrtl_submit(h, 0, cmd, 10000) == 0, "submit PKT_PROCESS");
    CHECK(sfrtl_run_until_cpl(h, 0, 200000) == 1, "PKT completion");
    CHECK(sfrtl_cpl_pop(h, 0, cpl) == 1, "pop");
    printf("PKT cpl: status=%u err=0x%02x tenant=%u queue=%u tag=%x bytes=%u committed=%u crc_in=%08x crc_out=%08x csum=%04x\n",
           (cpl[0] >> 8) & 0xFF, (cpl[0] >> 16) & 0xFF, (cpl[0] >> 24) & 0xF, cpl[0] >> 28, cpl[1], cpl[3], (cpl[2] >> 16) & 1, cpl[4], cpl[5], cpl[6] & 0xFFFF);
    CHECK(((cpl[0] >> 8) & 0xFF) == 0 && ((cpl[0] >> 16) & 0xFF) == 0, "status/err");
    CHECK(cpl[3] == 64, "bytes"); CHECK(((cpl[2] >> 16) & 1) == 1, "COMMITTED flag");
    CHECK(cpl[4] == crc32(in, 64), "crc_in %08x vs %08x", cpl[4], crc32(in, 64));
    CHECK(cpl[5] == crc32(exp, 64), "crc_out %08x vs %08x", cpl[5], crc32(exp, 64));
    uint8_t out[64]; sfrtl_hostmem_read(h, OUT, out, 64);
    CHECK(memcmp(out, exp, 64) == 0, "output bytes differ from XOR reference");

    /* negative: destination in the READ-ONLY window must be refused, and move no byte */
    memset(cmd, 0, sizeof cmd);
    cmd[0] = 0x01; cmd[1] = 0x102; cmd[2] = (uint32_t)IN; cmd[4] = (uint32_t)(IN + 0x100); cmd[6] = 64; cmd[7] = 0;
    sfrtl_host_stats s0, s1; sfrtl_host_stats_get(h, &s0);
    CHECK(sfrtl_submit(h, 0, cmd, 10000) == 0, "submit violating cmd");
    CHECK(sfrtl_run_until_cpl(h, 0, 200000) == 1, "violation completion");
    sfrtl_cpl_pop(h, 0, cpl);
    CHECK(((cpl[0] >> 16) & 0xFF) == 0x12, "want ERR_PERM_WRITE(0x12), got 0x%02x", (cpl[0] >> 16) & 0xFF);
    sfrtl_host_stats_get(h, &s1);
    CHECK(s1.writes == s0.writes, "violating command wrote host memory!");

    /* counters + telemetry */
    uint32_t acc = rd(0x4000C010u), ret = rd(0x4000C018u);
    printf("PERF: accepted=%u retired=%u  telemetry events=", acc, ret);
    int ev = 0; uint32_t t3[3]; while (sfrtl_tlm_pop(h, t3)) ev++;
    printf("%d  cycles=%llu\n", ev, (unsigned long long)sfrtl_cycles(h));
    CHECK(acc >= 3 && ret >= 3 && ev >= 3, "counters/telemetry");

    sfrtl_close(h);
    printf(fails ? "SMOKE FAIL (%d)\n" : "SMOKE PASS\n", fails);
    return fails ? 1 : 0;
}
