/*
 * SilicaFlux CloudRuntime -- RTL simulation transport, C API (version 1)
 *
 * This header is the ONLY interface between the Rust runtime and the Verilator model of the
 * SilicaFlux CloudDPU (Project 61 RTL, vendored unmodified).  It is a *simulation* transport:
 *
 *   - "host memory" is a byte array owned by the harness, served to the DPU through the DPU's
 *     SFB2 host-memory port with randomised latency / back-pressure;
 *   - the management port (ControlCore host access port) and the per-queue submission / completion
 *     ports are driven cycle by cycle;
 *   - simulated time advances ONLY inside calls that take a cycle budget (sfrtl_run, sfrtl_mgmt,
 *     sfrtl_submit, sfrtl_run_until_cpl).  Every blocking call has an explicit budget and returns an
 *     explicit failure instead of waiting forever.
 *
 * Nothing here talks to hardware.  A physical transport would implement the same device-level
 * contract (see crates/sf-cloud/src/backend/mod.rs), not this API.
 *
 * Thread safety: a handle must be used from one thread at a time.
 */
#ifndef SF_RTL_API_H
#define SF_RTL_API_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SFRTL_API_VERSION 1u

typedef struct sfrtl sfrtl_t;

/* Return codes */
#define SFRTL_OK            0
#define SFRTL_BUS_ERROR     1   /* management port answered with an error response          */
#define SFRTL_TIMEOUT      (-1) /* cycle budget exhausted                                   */
#define SFRTL_RANGE        (-2) /* host-memory access outside the simulated DRAM            */
#define SFRTL_BAD_ARG      (-3)

typedef struct {
    uint32_t struct_size;      /* sizeof(sfrtl_options), for forward compatibility           */
    uint32_t host_mem_bytes;   /* simulated host DRAM size; 0 = default (4 MiB)              */
    uint32_t host_lat_max;     /* extra host-memory response latency, cycles (random 0..N)   */
    uint32_t host_bp_pct;      /* host-memory request back-pressure percentage 0..90         */
    uint64_t seed;             /* seeds the harness PRNG and the Verilator X-initial values  */
    uint32_t access_log;       /* non-zero: record every host-memory access                  */
    uint32_t reserved;
} sfrtl_options;

/* Compile-time facts about this model (the runtime must still DISCOVER the geometry through the
 * DPU's own ID/CONFIG registers; this is only used to cross-check it). */
typedef struct {
    uint32_t api_version;
    uint32_t num_tenants, num_net_queues, num_compute_queues, num_dma_channels;
    uint32_t data_width, address_width, num_windows, sram_bytes;
    uint64_t host_mem_base;
    uint64_t host_mem_bytes;
    char     design[32];       /* "silicaflux_cloud_dpu"                                     */
    char     config_name[16];  /* e.g. "mt"                                                  */
    char     verilator[24];    /* Verilator version string                                   */
} sfrtl_build_info;

typedef struct {
    uint64_t reads, writes;          /* host-memory beats served                              */
    uint64_t bytes_rd, bytes_wr;
    uint64_t wild;                   /* requests outside the simulated DRAM (answered: error) */
    uint64_t injected_errors;        /* error responses produced by injected error ranges     */
    uint32_t outstanding;            /* requests queued inside the host-memory model          */
    uint32_t reserved;
} sfrtl_host_stats;

typedef struct {
    uint32_t busy, halted_unused, host_ready, cmdproc_ready;
    uint32_t irq_event, irq_fault, ras_fatal, test_fail;
} sfrtl_signals;

typedef struct {
    uint64_t cycle;
    uint64_t addr;
    uint32_t write;                  /* 1 = write beat, 0 = read beat                         */
    uint32_t bytes;                  /* bytes actually transferred in the beat (strobes)      */
} sfrtl_access;

uint32_t sfrtl_abi_version(void);

/* Create the model, apply reset, wait until the management port is ready.  NULL on failure
 * (message in err). */
sfrtl_t *sfrtl_open(const sfrtl_options *opt, char *err, size_t errlen);
void     sfrtl_close(sfrtl_t *h);
void     sfrtl_build_info_get(const sfrtl_t *h, sfrtl_build_info *out);

/* Hard reset (rst_ni low for several cycles, then wait for management-port readiness).  All
 * device state is lost; host memory contents are preserved (it is host DRAM, not device state);
 * pending completions and telemetry held by the harness are discarded. */
int      sfrtl_hard_reset(sfrtl_t *h, uint32_t max_cycles);

/* Management register access through the ControlCore host port.  PRIVILEGED: it reaches the
 * tenant configuration and every DPU register.  The runtime keeps it behind the mediator. */
int      sfrtl_mgmt(sfrtl_t *h, int write, uint32_t addr, uint32_t wdata, uint32_t *rdata,
                    uint32_t max_cycles);

/* Hand one 12-word submission descriptor to queue q.  Returns SFRTL_OK when the DPU accepted it,
 * SFRTL_TIMEOUT if the queue stayed full for max_cycles. */
int      sfrtl_submit(sfrtl_t *h, uint32_t queue, const uint32_t cmd[12], uint32_t max_cycles);

/* Pop one 8-word completion record of queue q.  1 = popped, 0 = none waiting. */
int      sfrtl_cpl_pop(sfrtl_t *h, uint32_t queue, uint32_t out[8]);
uint32_t sfrtl_cpl_pending(const sfrtl_t *h, uint32_t queue);

/* Advance simulated time.  Returns the number of cycles run. */
uint64_t sfrtl_run(sfrtl_t *h, uint64_t cycles);
/* Run until a completion is waiting on `queue` (or on any queue if queue == 0xFFFFFFFF), for at
 * most max_cycles.  1 = completion available, 0 = budget exhausted. */
int      sfrtl_run_until_cpl(sfrtl_t *h, uint32_t queue, uint64_t max_cycles);
uint64_t sfrtl_cycles(const sfrtl_t *h);

/* Simulated host DRAM (the host CPU's own view of its memory; not a DPU data path). */
int      sfrtl_hostmem_write(sfrtl_t *h, uint64_t iova, const void *src, size_t len);
int      sfrtl_hostmem_read(const sfrtl_t *h, uint64_t iova, void *dst, size_t len);

/* CloudTelemetry event port.  Each event is the DPU's 80-bit record as three little-endian
 * words {bits 31:0, bits 63:32, bits 79:64}.  1 = popped, 0 = none. */
int      sfrtl_tlm_pop(sfrtl_t *h, uint32_t out[3]);
uint64_t sfrtl_tlm_overflow(const sfrtl_t *h); /* events the harness had to drop (ring full) */

/* Environment / fault injection (simulation only). */
void     sfrtl_host_params(sfrtl_t *h, uint32_t lat_max, uint32_t bp_pct);
void     sfrtl_host_inject_error(sfrtl_t *h, uint64_t lo, uint64_t hi); /* [lo, hi) answers error */
void     sfrtl_host_clear_errors(sfrtl_t *h);
void     sfrtl_host_hold(sfrtl_t *h, uint64_t cycles); /* withhold responses for N more cycles   */
void     sfrtl_host_stats_get(const sfrtl_t *h, sfrtl_host_stats *out);
void     sfrtl_signals_get(const sfrtl_t *h, sfrtl_signals *out);
void     sfrtl_cpl_ready_set(sfrtl_t *h, uint32_t queue, int ready); /* model a stalled consumer */

/* Simulation back door: read device-local SRAM without using any DPU data path (the upstream testbench does the
 * same with a hierarchical reference).  Used to verify scrubbing independently of the hardware doing it. */
int      sfrtl_sram_peek(const sfrtl_t *h, uint32_t offset, void *dst, size_t len);

/* Exact value of the DPU's free-running cycle counter (the value stamped into completion records), read through a
 * simulation back door.  uint64 cycles; advances once per clock edge, like sfrtl_cycles(). */
uint64_t sfrtl_dpu_time(const sfrtl_t *h);

/* Independent access monitor: pops recorded host-memory accesses (only if access_log was set).
 * 1 = popped, 0 = none. */
int      sfrtl_access_pop(sfrtl_t *h, sfrtl_access *out);
uint64_t sfrtl_access_overflow(const sfrtl_t *h);

#ifdef __cplusplus
}
#endif
#endif /* SF_RTL_API_H */
