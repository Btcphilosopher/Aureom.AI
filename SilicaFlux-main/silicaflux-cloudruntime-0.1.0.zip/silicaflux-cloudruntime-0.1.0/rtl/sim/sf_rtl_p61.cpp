// SilicaFlux CloudRuntime -- Verilator harness around the vendored Project 61 CloudDPU RTL.
//
// Plays the SIMULATED HOST for the DPU (same roles as the upstream SystemVerilog testbench, which this
// harness does not reuse): management host (ControlCore host access port), virtual-function queue
// submit/complete ports, SFB2 host-memory slave and a CloudTelemetry consumer.  Contains NO checking of
// DPU behaviour -- correctness checking lives in the runtime tests, against an independent reference.
//
// Cycle discipline (equivalent to the upstream bench's `always @(posedge clk)` + non-blocking assigns):
//   1. inputs are applied and the model is evaluated with clk=0;
//   2. the pre-edge outputs are sampled -> this is what "happens at the edge";
//   3. clk=1, eval (the edge);
//   4. harness state advances from the pre-edge samples and drives the NEXT cycle's inputs;
//   5. clk=0, eval (combinational settle with the new inputs).
#include "sf_rtl_api.h"

#include "Vsilicaflux_cloud_dpu.h"
#include "Vsilicaflux_cloud_dpu___024root.h"
#include "verilated.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <vector>

#ifndef SFRTL_NT
#define SFRTL_NT 2
#endif
#ifndef SFRTL_NNQ
#define SFRTL_NNQ 2
#endif
#ifndef SFRTL_NCQ
#define SFRTL_NCQ 1
#endif
#ifndef SFRTL_NS
#define SFRTL_NS 2
#endif
#ifndef SFRTL_NW
#define SFRTL_NW 2
#endif
#ifndef SFRTL_SRAM
#define SFRTL_SRAM 65536
#endif
#ifndef SFRTL_NB
#define SFRTL_NB 2
#endif
#ifndef SFRTL_CONFIG_NAME
#define SFRTL_CONFIG_NAME "mt"
#endif

// This harness is written for the 32-bit data / 32-bit address DPU geometry (the geometry the upstream
// project regressed most heavily).  Wider geometries need VlWide handling for hm_*_wdata/rdata.
#define SFRTL_DW 32
#define SFRTL_AW 32
#define SFRTL_NQH (SFRTL_NNQ + SFRTL_NCQ)

static const uint64_t HM_BASE = 0x40000000ull;
static const size_t   CPL_WORDS = 8;
static const size_t   CMD_WORDS = 12;
static const size_t   CPL_RING_MAX = 256;
static const size_t   TLM_RING_MAX = 1u << 16;
static const size_t   ACC_RING_MAX = 1u << 20;

namespace {

struct HmReq {
    bool     write;
    uint64_t addr;
    uint32_t wdata;
    uint32_t wstrb;
    uint64_t due;
};

struct Edge {            // what happened at one rising edge (pre-edge handshakes)
    bool hs_req = false; // management request accepted
    bool hs_rsp = false; // management response delivered
    bool hs_err = false;
    uint32_t hs_rdata = 0;
    bool sub = false;    // submission accepted
};

}  // namespace

struct sfrtl {
    VerilatedContext *ctx = nullptr;
    Vsilicaflux_cloud_dpu *top = nullptr;
    uint64_t cyc = 0;
    uint64_t rng = 1;

    // host DRAM and the SFB2 slave model
    std::vector<uint8_t> hm;
    std::deque<HmReq>    hm_q;
    std::vector<std::pair<uint64_t, uint64_t>> hm_err_ranges;
    uint64_t hm_hold_until = 0;
    uint32_t lat_max = 2, bp_pct = 0;
    sfrtl_host_stats st{};
    bool access_log = false;
    std::deque<sfrtl_access> acc;
    uint64_t acc_overflow = 0;

    // completions / telemetry, as the host consumer sees them
    std::deque<std::vector<uint32_t>> cpl[SFRTL_NQH];
    bool     cpl_stall[SFRTL_NQH] = {};
    std::deque<std::vector<uint32_t>> tlm;
    uint64_t tlm_overflow = 0;

    uint32_t rnd() {  // xorshift64*
        rng ^= rng >> 12; rng ^= rng << 25; rng ^= rng >> 27;
        return (uint32_t)((rng * 0x2545F4914F6CDD1Dull) >> 32);
    }

    // Verilator 5 keeps a THREAD-LOCAL pointer to the "current" VerilatedContext (used e.g. when scopes are
    // destroyed).  With several devices in one process, or a handle used from different threads, that pointer
    // must be re-bound to this handle's context before the model is touched -- otherwise it can dangle into a
    // context that was already freed (observed: std::system_error from scopeErase on close).
    void bind() { Verilated::threadContextp(ctx); }
    void eval() { bind(); top->eval(); }

    // -------- one clock cycle ------------------------------------------------------------------
    Edge tick() {
        bind();
        Edge e;
        // ---- pre-edge samples
        const bool hs_req   = top->hs_req_valid && top->hs_req_ready;
        const bool hs_rsp   = top->hs_rsp_valid;           // hs_rsp_ready is tied high
        const uint32_t hs_rd = top->hs_rsp_rdata;
        const bool hs_er    = top->hs_rsp_error;
        const bool sub      = top->vio_sub_valid && top->vio_sub_ready;

        const bool hm_hs_req = top->hm_req_valid && top->hm_req_ready;
        HmReq nr{};
        if (hm_hs_req) {
            nr.write = top->hm_req_write; nr.addr = top->hm_req_addr;
            nr.wdata = top->hm_req_wdata; nr.wstrb = top->hm_req_wstrb;
        }
        const bool hm_rsp_hs = top->hm_rsp_valid && top->hm_rsp_ready;
        const bool hm_rsp_rdy = top->hm_rsp_ready;
        const bool hm_rsp_val = top->hm_rsp_valid;

        std::vector<uint32_t> got_cpl[SFRTL_NQH];
        bool got_cpl_v[SFRTL_NQH] = {};
        const uint32_t cv = top->vio_cpl_valid;
        for (int q = 0; q < SFRTL_NQH; q++) {
            if (((cv >> q) & 1u) && ((top->vio_cpl_ready >> q) & 1u)) {
                got_cpl_v[q] = true;
                got_cpl[q].resize(CPL_WORDS);
                for (size_t w = 0; w < CPL_WORDS; w++) got_cpl[q][w] = top->vio_cpl_data.data()[q * CPL_WORDS + w];
            }
        }
        const bool tlm_hs = top->tlm_valid && top->tlm_ready;
        std::vector<uint32_t> tlm_rec;
        if (tlm_hs) { tlm_rec.assign(top->tlm_data.data(), top->tlm_data.data() + 3); tlm_rec[2] &= 0xFFFFu; }

        // ---- the edge
        top->clk = 1; eval();
        cyc++;

        // ---- management port
        e.hs_req = hs_req; e.hs_rsp = hs_rsp; e.hs_err = hs_er; e.hs_rdata = hs_rd; e.sub = sub;

        // ---- completion consumer
        for (int q = 0; q < SFRTL_NQH; q++) {
            if (got_cpl_v[q]) cpl[q].push_back(std::move(got_cpl[q]));
            top->vio_cpl_ready = (top->vio_cpl_ready & ~(1u << q)) |
                                 ((!cpl_stall[q] && cpl[q].size() < CPL_RING_MAX) ? (1u << q) : 0u);
        }
        // ---- telemetry consumer (always ready; bounded ring)
        if (tlm_hs) {
            if (tlm.size() < TLM_RING_MAX) tlm.push_back(std::move(tlm_rec)); else tlm_overflow++;
        }
        top->tlm_ready = 1;

        // ---- host memory model (SFB2 slave)
        if (hm_hs_req) {
            nr.due = cyc + 1 + (lat_max ? (rnd() % (lat_max + 1)) : 0);
            hm_q.push_back(nr);
        }
        if (hm_rsp_hs) top->hm_rsp_valid = 0;
        if ((!hm_rsp_val || hm_rsp_rdy) && !hm_q.empty() && hm_q.front().due <= cyc && cyc >= hm_hold_until) {
            HmReq r = hm_q.front(); hm_q.pop_front();
            top->hm_rsp_valid = 1; top->hm_rsp_error = 0; top->hm_rsp_rdata = 0;
            bool inj = false;
            for (auto &rg : hm_err_ranges) if (r.addr >= rg.first && r.addr < rg.second) inj = true;
            const bool in_range = r.addr >= HM_BASE && (r.addr + 4) <= HM_BASE + hm.size();
            uint32_t nbytes = 0;
            for (int b = 0; b < 4; b++) nbytes += r.write ? ((r.wstrb >> b) & 1u) : 1u;
            if (!in_range) { top->hm_rsp_error = 1; st.wild++; }
            else if (inj)  { top->hm_rsp_error = 1; st.injected_errors++; }
            else {
                const size_t o = (size_t)(r.addr - HM_BASE);
                if (r.write) {                      // the write is performed AT acknowledge time
                    for (int b = 0; b < 4; b++) if ((r.wstrb >> b) & 1u) hm[o + b] = (uint8_t)(r.wdata >> (8 * b));
                    st.writes++; st.bytes_wr += nbytes;
                } else {
                    uint32_t v = 0;
                    for (int b = 0; b < 4; b++) v |= (uint32_t)hm[o + b] << (8 * b);
                    top->hm_rsp_rdata = v;
                    st.reads++; st.bytes_rd += 4;
                }
            }
            if (access_log) {
                if (acc.size() < ACC_RING_MAX) acc.push_back({cyc, r.addr, r.write ? 1u : 0u, nbytes});
                else acc_overflow++;
            }
        }
        top->hm_req_ready = (hm_q.size() < 4) && (bp_pct == 0 || (rnd() % 100) >= bp_pct);

        top->clk = 0; eval();
        return e;
    }

    void idle_inputs() {
        top->hs_req_valid = 0; top->hs_req_write = 0; top->hs_req_addr = 0; top->hs_req_wdata = 0; top->hs_req_wstrb = 0xF;
        top->vio_sub_valid = 0; top->vio_sub_q = 0;
        for (size_t w = 0; w < CMD_WORDS; w++) top->vio_sub_cmd.data()[w] = 0;
        top->vio_cpl_ready = 0;
        top->hm_req_ready = 0; top->hm_rsp_valid = 0; top->hm_rsp_error = 0; top->hm_rsp_rdata = 0;
        top->tlm_ready = 1;
        top->hs_rsp_ready = 1;
    }

    void clear_host_side() {
        hm_q.clear();
        for (auto &q : cpl) q.clear();
        tlm.clear();
        top->hm_rsp_valid = 0;
    }

    int reset(uint32_t max_cycles) {
        idle_inputs();
        top->rst_ni = 0; top->clk = 0; eval();
        for (int i = 0; i < 6; i++) tick();
        clear_host_side();
        top->rst_ni = 1; eval();
        for (int i = 0; i < 40; i++) tick();
        // The host port stalls until the system domain is up.  host_ready_o / cmdproc_ready_o are boot-stage
        // pins raised by the ControlCore FIRMWARE, which this transport does not load (the CPU idles in its
        // boot ROM, exactly as in the upstream smoke scenario) -- so readiness is "the DPU answers its ID".
        return probe_id(max_cycles);
    }

    // Read DPU_G_ID through the management port; OK only if it answers "SFDP" (0x53464450).
    int probe_id(uint32_t max_cycles) {
        top->hs_req_valid = 1; top->hs_req_write = 0; top->hs_req_addr = 0x40008000u; top->hs_req_wstrb = 0xF;
        eval();
        bool accepted = false;
        for (uint32_t i = 0; i < max_cycles; i++) {
            Edge e = tick();
            if (!accepted && e.hs_req) { accepted = true; top->hs_req_valid = 0; eval(); continue; }
            if (accepted && e.hs_rsp) return (!e.hs_err && e.hs_rdata == 0x53464450u) ? SFRTL_OK : SFRTL_BUS_ERROR;
        }
        top->hs_req_valid = 0; eval();
        return SFRTL_TIMEOUT;
    }
};

// ---- SRAM back door (simulation only; mirrors the upstream testbench's hierarchical peek) --------------------
#define SFRTL_BANK(i) h->top->rootp->silicaflux_cloud_dpu__DOT__u_fab__DOT__g_bank__BRA__##i##__KET____DOT__u_bank__DOT__u_sram__DOT__u_array__DOT__g_generic__DOT__u_mem__DOT__mem
static uint32_t sram_word(const sfrtl *hc, uint32_t byte_addr) {
    sfrtl *h = const_cast<sfrtl *>(hc);
    const uint32_t bank_bytes = SFRTL_SRAM / SFRTL_NB;
    const uint32_t bank = byte_addr / bank_bytes, w = (byte_addr % bank_bytes) / 4;
    switch (bank) {
        case 0: return SFRTL_BANK(0)[w];
#if SFRTL_NB > 1
        case 1: return SFRTL_BANK(1)[w];
#endif
#if SFRTL_NB > 2
        case 2: return SFRTL_BANK(2)[w];
        case 3: return SFRTL_BANK(3)[w];
#endif
        default: return 0;
    }
}

// =============================================================================================
extern "C" {

// Exact value of the DPU's own free-running cycle counter (the one stamped into completion records).  Both it and
// the harness cycle counter advance once per clock edge, so their difference is a constant that lets the runtime
// turn completion timestamps into exact latencies without any bus-access uncertainty.
uint64_t sfrtl_dpu_time(const sfrtl_t *h) {
    return h ? (uint64_t)h->top->rootp->silicaflux_cloud_dpu__DOT__u_regs__DOT__time_q : 0;
}

int sfrtl_sram_peek(const sfrtl_t *h, uint32_t offset, void *dst, size_t len) {
    if (!h || (!dst && len)) return SFRTL_BAD_ARG;
    if ((uint64_t)offset + len > SFRTL_SRAM) return SFRTL_RANGE;
    uint8_t *o = static_cast<uint8_t *>(dst);
    for (size_t i = 0; i < len; i++) {
        const uint32_t a = offset + (uint32_t)i;
        o[i] = (uint8_t)(sram_word(h, a & ~3u) >> (8 * (a & 3u)));
    }
    return SFRTL_OK;
}


uint32_t sfrtl_abi_version(void) { return SFRTL_API_VERSION; }

static void set_err(char *err, size_t n, const char *m) {
    if (err && n) { std::snprintf(err, n, "%s", m); }
}

sfrtl_t *sfrtl_open(const sfrtl_options *opt, char *err, size_t errlen) {
    if (opt && opt->struct_size && opt->struct_size < sizeof(sfrtl_options)) {
        set_err(err, errlen, "sfrtl_options struct too small"); return nullptr;
    }
    sfrtl_t *h = new sfrtl();
    h->ctx = new VerilatedContext();
    const uint64_t seed = (opt && opt->seed) ? opt->seed : 1;
    h->ctx->randReset(2);
    h->ctx->randSeed((int)(seed & 0x7fffffff));
    h->rng = seed * 0x9E3779B97F4A7C15ull | 1ull;
    h->bind();
    h->top = new Vsilicaflux_cloud_dpu(h->ctx);
    const uint32_t mem = (opt && opt->host_mem_bytes) ? opt->host_mem_bytes : (4u << 20);
    h->hm.assign(mem, 0);
    if (opt) { h->lat_max = opt->host_lat_max; h->bp_pct = opt->host_bp_pct > 90 ? 90 : opt->host_bp_pct; h->access_log = opt->access_log != 0; }
    h->top->test_mode = 0; h->top->boot_mode_i = 0; h->top->host_rst_req_i = 0;
    h->top->ext_warn_i = 0; h->top->ext_fatal_i = 0;
    if (h->reset(200000) != SFRTL_OK) {
        set_err(err, errlen, "DPU management port did not become ready after reset");
        sfrtl_close(h); return nullptr;
    }
    return h;
}

void sfrtl_close(sfrtl_t *h) {
    if (!h) return;
    h->bind();
    if (h->top) { h->top->final(); delete h->top; }
    delete h->ctx;
    delete h;
}

void sfrtl_build_info_get(const sfrtl_t *h, sfrtl_build_info *o) {
    std::memset(o, 0, sizeof(*o));
    o->api_version = SFRTL_API_VERSION;
    o->num_tenants = SFRTL_NT; o->num_net_queues = SFRTL_NNQ; o->num_compute_queues = SFRTL_NCQ;
    o->num_dma_channels = SFRTL_NS; o->data_width = SFRTL_DW; o->address_width = SFRTL_AW;
    o->num_windows = SFRTL_NW; o->sram_bytes = SFRTL_SRAM;
    o->host_mem_base = HM_BASE; o->host_mem_bytes = h ? h->hm.size() : 0;
    std::snprintf(o->design, sizeof o->design, "silicaflux_cloud_dpu");
    std::snprintf(o->config_name, sizeof o->config_name, "%s", SFRTL_CONFIG_NAME);
    std::snprintf(o->verilator, sizeof o->verilator, "%s", Verilated::productVersion());
}

int sfrtl_hard_reset(sfrtl_t *h, uint32_t max_cycles) {
    if (!h) return SFRTL_BAD_ARG;
    h->hm_hold_until = 0;
    return h->reset(max_cycles);
}

int sfrtl_mgmt(sfrtl_t *h, int write, uint32_t addr, uint32_t wdata, uint32_t *rdata, uint32_t max_cycles) {
    if (!h) return SFRTL_BAD_ARG;
    h->top->hs_req_valid = 1; h->top->hs_req_write = write ? 1 : 0;
    h->top->hs_req_addr = addr; h->top->hs_req_wdata = wdata; h->top->hs_req_wstrb = 0xF;
    h->eval();
    bool accepted = false;
    for (uint32_t i = 0; i < max_cycles; i++) {
        Edge e = h->tick();
        if (!accepted && e.hs_req) {
            accepted = true;
            h->top->hs_req_valid = 0; h->eval();
            // The response is never in the acceptance cycle; it may arrive in any later cycle.
            continue;
        }
        if (accepted && e.hs_rsp) {
            if (rdata) *rdata = e.hs_rdata;
            return e.hs_err ? SFRTL_BUS_ERROR : SFRTL_OK;
        }
    }
    h->top->hs_req_valid = 0; h->eval();
    return SFRTL_TIMEOUT;
}

int sfrtl_submit(sfrtl_t *h, uint32_t queue, const uint32_t cmd[12], uint32_t max_cycles) {
    if (!h || !cmd || queue > 15) return SFRTL_BAD_ARG;
    h->top->vio_sub_valid = 1; h->top->vio_sub_q = queue;
    for (size_t w = 0; w < CMD_WORDS; w++) h->top->vio_sub_cmd.data()[w] = cmd[w];
    h->eval();
    for (uint32_t i = 0; i < max_cycles; i++) {
        Edge e = h->tick();
        if (e.sub) { h->top->vio_sub_valid = 0; h->eval(); return SFRTL_OK; }
    }
    h->top->vio_sub_valid = 0; h->eval();
    return SFRTL_TIMEOUT;
}

int sfrtl_cpl_pop(sfrtl_t *h, uint32_t queue, uint32_t out[8]) {
    if (!h || queue >= SFRTL_NQH || !out) return 0;
    auto &d = h->cpl[queue];
    if (d.empty()) return 0;
    for (size_t w = 0; w < CPL_WORDS; w++) out[w] = d.front()[w];
    d.pop_front();
    return 1;
}

uint32_t sfrtl_cpl_pending(const sfrtl_t *h, uint32_t queue) {
    if (!h || queue >= SFRTL_NQH) return 0;
    return (uint32_t)h->cpl[queue].size();
}

uint64_t sfrtl_run(sfrtl_t *h, uint64_t cycles) {
    if (!h) return 0;
    for (uint64_t i = 0; i < cycles; i++) h->tick();
    return cycles;
}

int sfrtl_run_until_cpl(sfrtl_t *h, uint32_t queue, uint64_t max_cycles) {
    if (!h) return 0;
    for (uint64_t i = 0; i < max_cycles; i++) {
        if (queue == 0xFFFFFFFFu) { for (int q = 0; q < SFRTL_NQH; q++) if (!h->cpl[q].empty()) return 1; }
        else if (queue < SFRTL_NQH && !h->cpl[queue].empty()) return 1;
        h->tick();
    }
    return 0;
}

uint64_t sfrtl_cycles(const sfrtl_t *h) { return h ? h->cyc : 0; }

int sfrtl_hostmem_write(sfrtl_t *h, uint64_t iova, const void *src, size_t len) {
    if (!h || (!src && len)) return SFRTL_BAD_ARG;
    if (iova < HM_BASE || iova - HM_BASE + len > h->hm.size()) return SFRTL_RANGE;
    if (len) std::memcpy(&h->hm[iova - HM_BASE], src, len);
    return SFRTL_OK;
}

int sfrtl_hostmem_read(const sfrtl_t *h, uint64_t iova, void *dst, size_t len) {
    if (!h || (!dst && len)) return SFRTL_BAD_ARG;
    if (iova < HM_BASE || iova - HM_BASE + len > h->hm.size()) return SFRTL_RANGE;
    if (len) std::memcpy(dst, &h->hm[iova - HM_BASE], len);
    return SFRTL_OK;
}

int sfrtl_tlm_pop(sfrtl_t *h, uint32_t out[3]) {
    if (!h || h->tlm.empty()) return 0;
    for (int w = 0; w < 3; w++) out[w] = h->tlm.front()[w];
    h->tlm.pop_front();
    return 1;
}
uint64_t sfrtl_tlm_overflow(const sfrtl_t *h) { return h ? h->tlm_overflow : 0; }

void sfrtl_host_params(sfrtl_t *h, uint32_t lat_max, uint32_t bp_pct) {
    if (!h) return;
    h->lat_max = lat_max;
    h->bp_pct = bp_pct > 90 ? 90 : bp_pct;
}
void sfrtl_host_inject_error(sfrtl_t *h, uint64_t lo, uint64_t hi) { if (h) h->hm_err_ranges.emplace_back(lo, hi); }
void sfrtl_host_clear_errors(sfrtl_t *h) { if (h) h->hm_err_ranges.clear(); }
void sfrtl_host_hold(sfrtl_t *h, uint64_t cycles) { if (h) h->hm_hold_until = h->cyc + cycles; }

void sfrtl_host_stats_get(const sfrtl_t *h, sfrtl_host_stats *o) {
    if (!h || !o) return;
    *o = h->st; o->outstanding = (uint32_t)h->hm_q.size();
}

void sfrtl_signals_get(const sfrtl_t *h, sfrtl_signals *o) {
    if (!h || !o) return;
    o->busy = h->top->dpu_busy_o; o->halted_unused = 0; o->host_ready = h->top->host_ready_o;
    o->cmdproc_ready = h->top->cmdproc_ready_o; o->irq_event = h->top->dpu_irq_event_o;
    o->irq_fault = h->top->dpu_irq_fault_o; o->ras_fatal = h->top->ras_fatal_o; o->test_fail = h->top->test_fail_o;
}

void sfrtl_cpl_ready_set(sfrtl_t *h, uint32_t queue, int ready) {
    if (!h || queue >= SFRTL_NQH) return;
    h->cpl_stall[queue] = !ready;
}

int sfrtl_access_pop(sfrtl_t *h, sfrtl_access *o) {
    if (!h || h->acc.empty()) return 0;
    *o = h->acc.front(); h->acc.pop_front(); return 1;
}
uint64_t sfrtl_access_overflow(const sfrtl_t *h) { return h ? h->acc_overflow : 0; }

}  // extern "C"
