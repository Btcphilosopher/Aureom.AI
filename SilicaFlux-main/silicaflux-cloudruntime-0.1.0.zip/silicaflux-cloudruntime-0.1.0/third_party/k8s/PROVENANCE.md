# Provenance of `deviceplugin_v1beta1_api.proto`

* Upstream: `kubernetes/kubelet`, `pkg/apis/deviceplugin/v1beta1/api.proto` (kubelet device-plugin API **v1beta1**, the
  stable version used by every supported Kubernetes release; `pluginapi.Version = "v1beta1"`).
* Fetched verbatim from `https://raw.githubusercontent.com/kubernetes/kubelet/master/pkg/apis/deviceplugin/v1beta1/api.proto`
  on 2026-11-14.  SHA-256: `b780bfeac99c93c231dc165ce417f4da88481eececa0c65eeb90f5f2e9b5b65b` (212 lines).
* Not modified.  Licence: Apache-2.0 (Kubernetes authors).
* The plugin implements: `Registration.Register` (client), `DevicePlugin.{GetDevicePluginOptions, ListAndWatch,
  GetPreferredAllocation, Allocate, PreStartContainer}` (server).
