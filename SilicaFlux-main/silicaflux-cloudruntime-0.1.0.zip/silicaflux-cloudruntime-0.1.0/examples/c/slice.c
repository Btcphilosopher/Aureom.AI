/* C example: the vertical slice through the stable C ABI only (include/sf_cloud.h).
 *   cc -std=c11 -Iinclude examples/c/slice.c -Ltarget/release -lsf_cloud -Wl,-rpath,$PWD/target/release -o slice
 *   ./slice [backend-spec]          default "auto";  e.g.  ./slice rtl-sim:mt
 * Exit: 0 = verified, 1 = failure, 3 = backend lacks the capability (never emulated). */
#include "sf_cloud.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void die(const char *what, sf_status s) {
    fprintf(stderr, "%s failed: %s (%s)\n", what, sf_cloud_status_str(s), sf_cloud_last_error());
    exit(1);
}
#define TRY(x) do { sf_status _s = (x); if (_s != SF_OK) die(#x, _s); } while (0)

int main(int argc, char **argv) {
    sf_cloud_open_params p = {sizeof p, SF_CLOUD_ABI_MAJOR, argc > 1 ? argv[1] : "auto", SF_OPEN_STANDALONE, 0, 0};
    sf_cloud_device *dev = NULL;
    TRY(sf_cloud_open(&p, &dev));
    sf_cloud_info_t info = {.struct_size = sizeof info};
    TRY(sf_cloud_info(dev, &info));
    printf("backend %s | %s\n  measured_on_hardware=%u caps=0x%x\n", info.backend, info.timing_model, info.measured_on_hardware, info.caps);
    if (!(info.caps & SF_CAP_PKT_PROCESS)) { puts("UNSUPPORTED: pkt_process"); sf_cloud_close(dev); return 3; }

    enum { N = 1500 };
    unsigned char in[N], out[N];
    for (int i = 0; i < N; i++) in[i] = (unsigned char)(i * 31 + 7);
    sf_buf_t src, dst;
    TRY(sf_cloud_alloc(dev, N, SF_MEM_DEV_READ, &src));      /* the device may only READ this buffer  */
    TRY(sf_cloud_alloc(dev, N, SF_MEM_DEV_WRITE, &dst));     /* ... and only WRITE this one           */
    TRY(sf_cloud_write(dev, src, 0, in, N));
    sf_cloud_op_t op = {.struct_size = sizeof op, .kind = SF_OP_COPY, .src = src, .dst = dst, .len = N};
    sf_ticket_t t;
    TRY(sf_cloud_submit(dev, &op, &t));
    sf_cloud_completion_t c = {.struct_size = sizeof c};
    TRY(sf_cloud_wait(dev, t, 20000, &c));                   /* bounded: SF_ERR_TIMEOUT, never a hang */
    TRY(sf_cloud_read(dev, dst, 0, out, N));
    int ok = c.status == SF_OK && c.committed && c.has_crc && c.crc_in == c.crc_out && memcmp(in, out, N) == 0;
    printf("copy %s: committed=%u crc32=%08x latency=%llu device cycles\n", ok ? "VERIFIED" : "FAILED", c.committed, c.crc_in, (unsigned long long)c.latency_cycles);
    sf_cloud_counters_t cn = {.struct_size = sizeof cn};
    TRY(sf_cloud_counters(dev, &cn));
    printf("counters: tenant bytes_ok=%llu | device retired=%llu dma_rd=%llu dma_wr=%llu\n", (unsigned long long)cn.t_bytes_ok, (unsigned long long)cn.d_cmds_retired, (unsigned long long)cn.d_dma_bytes_rd, (unsigned long long)cn.d_dma_bytes_wr);
    TRY(sf_cloud_free(dev, src));
    TRY(sf_cloud_free(dev, dst));
    TRY(sf_cloud_close(dev));
    return ok ? 0 : 1;
}
