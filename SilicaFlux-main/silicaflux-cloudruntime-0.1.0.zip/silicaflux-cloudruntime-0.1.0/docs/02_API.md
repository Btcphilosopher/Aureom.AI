# 02 — Device API (C ABI 1.0, Rust, Python)

Header: `include/sf_cloud.h` — the contract. The C names follow the suggestion in the brief with the repository's `sf_`
prefix plus a `cloud` namespace, so nothing collides with the P30 HPC runtime (`sf_vector_*`, `sf_tensor_gemm`).

## Stability rules

* Names, enum values, struct field order and sizes never change within ABI major **1**. New fields are only appended.
* Every struct passed in begins with `uint32_t struct_size` (set it to `sizeof` *your* copy). The library reads/writes
  at most `min(your size, its size)` bytes — old callers work with new libraries and vice versa. `sf_cloud_op_t` is
  the exception: ABI 1.0 requires the full struct (rejected with `SF_ERR_INVALID_ARG` otherwise).
* `sf_cloud_open_params.abi_major` must equal `SF_CLOUD_ABI_MAJOR`, else `SF_ERR_ABI_MISMATCH`.
* The device's *register* ABI is checked at open (`ID == "SFDP"`, major version 1) → `SF_ERR_ABI_MISMATCH` otherwise.
  (This is the firmware-compatibility check; no firmware is loaded in this runtime — see `docs/10`.)
* No panic crosses the boundary (`SF_ERR_INTERNAL` + message). Layout drift between header, library and the Python
  binding is detected by `sf_cloud_abi_sizes()` in tests.

## Functions

| Function | Purpose | Notes |
|---|---|---|
| `sf_cloud_discover` | list devices | every entry has a `reason`; `hw` entries are never available |
| `sf_cloud_open` / `sf_cloud_close` | open / release | `SF_OPEN_STANDALONE`: private device, every tenant provisioned, handle is tenant **and** admin (development mode — *not* an isolation boundary). `SF_OPEN_MEDIATOR`: privileged handle without a tenant. Close releases everything (buffers scrubbed, SRAM partitions scrubbed by the hardware, keys wiped) |
| `sf_cloud_info` | what is behind the handle | backend, **timing model**, `measured_on_hardware`, capability bits, geometry read from the DPU, `BLOCK_STATUS`, health, thermal |
| `sf_cloud_alloc` / `free` | protected buffers | `SF_MEM_DEV_READ` (device may read; placed in the read-only window), `SF_MEM_DEV_WRITE`, `SF_MEM_DEVICE` (SRAM partition, not CPU accessible). `free` → `SF_ERR_BUSY` while an in-flight command references it |
| `sf_cloud_write` / `read` | host ↔ buffer synchronisation | refused (`SF_ERR_BUSY`) while the device owns the buffer |
| `sf_cloud_key_load` / `unload` | tenant-owned AES keys | 16/32 bytes; wiped on unload/close |
| `sf_cloud_submit` | start an operation | returns a ticket. Validation first: nothing invalid reaches the device |
| `sf_cloud_poll` | non-blocking | `SF_ERR_NOT_READY` while running; a finished ticket is consumed (a second poll → `SF_ERR_STALE_HANDLE`) |
| `sf_cloud_wait` | bounded blocking | `SF_ERR_TIMEOUT` ⇒ the operation *may still be running*, the ticket stays valid |
| `sf_cloud_counters` | tenant counters (always) + whole-device counters (admin handles: `device_valid = 1`) | |
| `sf_cloud_telemetry` | consume this tenant's events (admin: all) | |
| `sf_cloud_metrics` | Prometheus text of the whole device (admin) | |
| `sf_cloud_reset` | `SF_RESET_DATAPLANE` / `SF_RESET_HARD` (admin) | tenant handles get `SF_ERR_PERMISSION` |
| `sf_cloud_provision_tenant` / `deprovision` / `open_session` / `set_thermal` | mediator operations (admin) | `open_session` needs the 16-byte credential from provisioning |
| `sf_cloud_status_str`, `sf_cloud_last_error` | diagnostics | `last_error` is thread-local and carries the human-readable detail |

## Workloads

Every call validates its parameters **before** anything is submitted and returns an explicit status. A workload the
backend cannot execute fails with `SF_ERR_UNSUPPORTED` — **never** silently emulated or approximated.

| Workload | `SF_OP_*` | `rtl-sim` | `cpu-ref` | Limits / notes |
|---|---|---|---|---|
| Packet processing | `PKT_PROCESS` | ✔ (**test adapter**: `PASS`, `XOR32` (not encryption), `BSWAP32` + CRC-32 + RFC 1071) | ✔ (same semantics) | no packet parsing: the real PacketCore (P62) is not integrated. `BSWAP32` needs length % 4 = 0 |
| Memory movement | `COPY` | ✔ (`PKT_PROCESS`/`PASS`; completion carries `crc_in`/`crc_out`, `committed`) | ✔ | any length ≥ 1; chunked at 2048 B |
| DMA transfers | `DMA_H2D`, `DMA_D2H` | ✔ | ✔ | host buffer ↔ device-local buffer |
| Tensor GEMM | `GEMM_I8` | ✘ `UNSUPPORTED` (engine blocked) | ✔ software | INT8×INT8→INT32, m,n,k ≤ 64; `src`=A, `aux`=B, `dst`=C (LE int32) |
| AES-GCM | `AES_GCM` | ✘ `UNSUPPORTED` (no CryptoCore exists) | ✔ software | AES-128/256, 12-byte IV, AAD ≤ 1024 B, payload ≤ `max_xfer` (single chunk); tag in `aux`; **no plaintext is released on authentication failure** (`SF_ERR_CRYPTO_AUTH`) |
| Storage read/write | `STORAGE_READ`/`WRITE` | ✘ `UNSUPPORTED` (no StorageFabric) | ✔ software | 512-byte blocks, private namespace per tenant, 8192 blocks; out-of-range LBA → `SF_ERR_INVALID_ARG`, never wraps |
| Telemetry collection | `sf_cloud_telemetry`, `sf_cloud_metrics`, `sf_cloud_counters` | ✔ real DPU counters/events | ✔ model of them | cycle-type counters on `cpu-ref` are logical |

The capability bits in `sf_cloud_info.caps` are derived from the device (`BLOCK_STATUS == REAL`) or, for the model,
declared by it; see `docs/00`.

## Status codes (all 22)

`SF_OK 0`, `INVALID_ARG -1`, `UNSUPPORTED -2`, `NO_DEVICE -3`, `PERMISSION -4`, `NO_MEMORY -5`, `BUSY -6`,
`STALE_HANDLE -7`, `TIMEOUT -8`, `QUEUE_FULL -9`, `DEVICE_FAULT -10`, `TENANT_STATE -11`, `ISOLATION -12`,
`ALIGNMENT -13`, `RANGE -14`, `NOT_READY -15`, `CRYPTO_AUTH -16`, `ABI_MISMATCH -17`, `RESET -18`, `INTERNAL -19`,
`BAD_DESCRIPTOR -20`, `QUOTA -21`. (`tests/c_abi.rs` checks the header against the Rust table.)
Raw DPU error codes are in `Completion.dev_err` (`proto::err`); the mapping to status codes is in `mediator.rs::map_dev_err`.

## Example (C)

```c
sf_cloud_open_params p = {sizeof p, SF_CLOUD_ABI_MAJOR, "auto", SF_OPEN_STANDALONE, 0, 0};
sf_cloud_device *dev;           sf_cloud_open(&p, &dev);
sf_cloud_info_t info = {.struct_size = sizeof info};   sf_cloud_info(dev, &info);   /* READ THIS: backend, timing, caps */
sf_buf_t src, dst;
sf_cloud_alloc(dev, 1500, SF_MEM_DEV_READ,  &src);
sf_cloud_alloc(dev, 1500, SF_MEM_DEV_WRITE, &dst);
sf_cloud_write(dev, src, 0, data, 1500);
sf_cloud_op_t op = {.struct_size = sizeof op, .kind = SF_OP_COPY, .src = src, .dst = dst, .len = 1500};
sf_ticket_t t;                  sf_cloud_submit(dev, &op, &t);
sf_cloud_completion_t c = {.struct_size = sizeof c};
sf_cloud_wait(dev, t, 20000, &c);                        /* SF_ERR_TIMEOUT instead of hanging */
/* c.committed, c.crc_in == c.crc_out, c.latency_cycles */
sf_cloud_read(dev, dst, 0, out, 1500);
sf_cloud_free(dev, src);  sf_cloud_free(dev, dst);  sf_cloud_close(dev);
```
Complete program: `examples/c/slice.c` (built and run by `ctest`).

## Rust

`sf_cloud::mediator::{Mediator, Session, Op, TenantConfig, …}`; `Mediator::open(backend::open_backend(&BackendSpec::parse("rtl-sim:mt")?)?, …)`,
`provision_tenant`, `open_session`, then `session.alloc/submit/wait/read`. Examples: `crates/sf-cloud/examples/*.rs`.

## Python

`python/silicaflux` — `ctypes` over the C ABI (no compile step):

```python
import silicaflux as sf
with sf.Device.open("rtl-sim:mt") as dev:
    print(dev.info()["timing_model"], dev.info()["caps"])
    c = dev.wait(dev.submit(sf.OP_COPY, src=src, dst=dst, length=n))
```
Errors raise `SilicaFluxError` (`.name`, `.detail`). `python/bench_compare.py` prints benchmark reports side by side with
their measurement sources. Tests: `python3 -m unittest discover -s python/tests`.

## Backend specs

`auto` (RTL if its library is found, else `cpu-ref`) · `cpu-ref[:cfg=min|mt|mt4][,tenants=N,sram=BYTES,…]` ·
`rtl-sim[:cfg=mt|min|mt4][,seed=N,lat=N,bp=PCT,mem=BYTES,log=1,lib=PATH]` · `hw` (always fails with the reason).
`SF_RTL_LIB` overrides the RTL library path; `SILICAFLUX_VISIBLE_DEVICES` restricts visible devices (containers).
