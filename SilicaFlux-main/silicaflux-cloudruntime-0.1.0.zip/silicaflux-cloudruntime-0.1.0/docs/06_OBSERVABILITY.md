# 06 — Observability

`sf-exporter` (and `sf_cloud_metrics()` / `sfctl metrics`) turn a device **snapshot** into Prometheus text and JSON.
Every value comes from the device's own registers/counters or from the runtime's bookkeeping; **nothing is estimated**.

```bash
target/release/sf-exporter --backend rtl-sim:mt --listen 127.0.0.1:9477 [--synthetic-load]
curl localhost:9477/metrics        # Prometheus text            curl localhost:9477/healthz   # 200 healthy|degraded, 503 faulted|unavailable
curl localhost:9477/api/snapshot   # JSON                       open http://localhost:9477/   # dashboard
```

`--synthetic-load` runs a small self-generated workload for demos and is **announced** (`silicaflux_exporter_synthetic_load 1`);
it is never on by default. The exporter owns its own device instance (simulated backends are in-process).

## What is exported (brief §12)

| Required | Metric(s) | Source |
|---|---|---|
| Device state | `silicaflux_device_health{state}` (one-hot), `…_health_reason`, `silicaflux_device_info{backend,kind,timing,measured_on_hardware,dpu_abi}`, `silicaflux_block_status{block,status}`, `silicaflux_fault_status{fault}` | `G_STATUS`, `G_FAULT_STATUS`, `BLOCK_STATUS` |
| Throughput | `silicaflux_dma_bytes_total{direction}`, `silicaflux_dpu_commands_total{stage}`, `silicaflux_runtime_bytes_ok_total`, derived gauges `…_throughput_bytes_per_second{source="wall_clock"}` (**simulation speed on rtl-sim**) and `…_bytes_per_device_cycle` (timing-model backends only) | DPU perf counters; scrape-to-scrape deltas |
| Memory utilisation | `silicaflux_sram_bytes{state}`, `silicaflux_host_window_bytes{state}`, `silicaflux_tenant_resources{kind=buffers|host_bytes|device_bytes|keys|inflight}` | mediator allocators |
| Queue occupancy | `silicaflux_queue_occupancy{queue,tenant,class,kind=submission|completion}`, `silicaflux_queue_commands_total` | `Q_STATUS`, `Q_*` registers |
| Completion latency | `silicaflux_completion_latency_cycles` (histogram) + `…_seconds_sum` | DPU cycle counter in the completion record (exact) / wall clock |
| Thermal state | `silicaflux_thermal_state{state}`, `silicaflux_temperature_celsius{source="external"}` | **no on-chip sensor path exists** (PowerClock P27 not integrated): `unavailable` until `set_thermal()` is fed by an external source |
| Error status | `silicaflux_device_errors_total{code,name}`, `silicaflux_runtime_operations_total{status}`, `silicaflux_dpu_events_total{kind}`, `silicaflux_integrity_anomalies_total{kind}` | completions, counters |
| Per-domain usage | `silicaflux_tenant_state`, `silicaflux_tenant_operations_total`, `silicaflux_tenant_device_total{kind=commands|bytes|violations|errors}` | per-tenant DPU counter block + runtime |

## Honesty rules

* `silicaflux_device_info` carries `timing=` and `measured_on_hardware=` — a dashboard can never mistake simulation
  numbers for hardware numbers; the HTML dashboard shows a banner saying so.
* Cycle-type counters (`active`, `stall_*`, `memory_conflicts`) are exported **only** for backends with a timing model
  (on `cpu-ref` they would be logical, so they are omitted).
* The CloudTelemetry **event port** is consumed by the mediator (ring of 8192 events, tenant-filtered on read); the DPU's
  export FIFO is 16 deep and **drops and counts** when not consumed (`silicaflux_telemetry_events_total{state="dropped"}`).
