# 07 — Benchmarks

`sf-bench run --backend SPEC [--quick] [--assume-clock-mhz F] [--out report.json]` — reports in
`benchmarks/results/`; tables below are **generated** from them by `scripts/gen_bench_md.py` (no hand transcription).
`python3 python/bench_compare.py` prints them side by side with their measurement sources.

## Read this first: what the numbers are, and are not

| Kind | Where | Meaning |
|---|---|---|
| **hardware measurements** | `hardware_measurements` | **EMPTY.** No physical device exists. Nothing in this document is a hardware result. |
| **device cycles** (`rtl-sim`) | `device_cycles*`, `bytes_per_device_cycle` | Cycles of the cycle-accurate RTL simulation. Real RTL behaviour against a *modelled* host memory (random 0–2 cycle latency, single outstanding request). **There is no clock frequency**: no clock has been closed in timing on any implementation of this design. |
| **wall clock** | `wall_*` | Host CPU time of the whole software stack. For `rtl-sim` this is **simulation speed** (Verilator on one core), *not* device speed. For `cpu-ref` it is the speed of a software model. |
| **CPU-only reference** | `cpu_only_reference` | The same work done directly in software on the same host CPU, no runtime, no device model. The honest "what would a plain CPU do" baseline. |
| **assumed-clock projection** | `assumed_clock_projection` | `bytes/cycle × an ASSUMED MHz`, supplied on the command line, labelled as an assumption. Included only so a reader can see the order of magnitude. **Not a result.** |

Rules the suite enforces: every benchmark verifies its output (byte-for-byte or CRC against an independent software
computation) *before* its numbers count and a wrong result fails the run (exit 1); unsupported workloads are reported
`unsupported` with the reason; power is `not_measurable` with the reason (no power telemetry exists, a simulation has
no power model, no hardware has run) — **no energy figure is reported or estimated**.

## Results

Report metadata (rtl-sim): git `2ff91f94917f` (dirty=true), runtime 0.1.0, RTL P61-RTL-1.0 (0x00010000), rustc 1.97.0 (2d8144b78 2026-07-07), Verilator 5.020 2024-01-01, CPU `Intel(R) Xeon(R) Processor @ 2.10GHz`; `all_verified = True`; `hardware_measurements = []`.

### Network packet throughput — FCS/checksum offload through the DPU (`PKT_PROCESS`/PASS, pipeline depth 12)

| frame B | device cycles / frame | **bytes / device cycle** | CPU-only reference (memcpy+CRC32+csum, host wall) |
|---:|---:|---:|---:|
| 64 | 148.2 | 0.432 | 365 MB/s |
| 256 | 577.9 | 0.443 | 336 MB/s |
| 1024 | 2,294.3 | 0.446 | 362 MB/s |
| 1500 | 3,358.9 | 0.447 | 355 MB/s |

### DMA bandwidth — host→device then device→host, sequential operations

| transfer B | device cycles (active) | **bytes / device cycle** (both directions counted) | CPU-only (two memcpy, host wall) |
|---:|---:|---:|---:|
| 256 | 77,516 | 0.661 | 33,997 MB/s |
| 2048 | 614,950 | 0.666 | 71,772 MB/s |
| 8192 | 1,333,363 | 1.229 | 107,549 MB/s |

### Memory-copy latency — one operation in flight (device cycles, exact DPU timestamps)

| bytes | p50 | p99 | max | CPU-only p50 (host wall) |
|---:|---:|---:|---:|---:|
| 64 | 281 | 291 | 292 | 0.19 µs |
| 256 | 1,097 | 1,122 | 1,125 | 0.58 µs |
| 1024 | 4,361 | 4,405 | 4,410 | 2.38 µs |
| 2048 | 8,707 | 8,776 | 8,798 | 5.01 µs |

### Multi-tenant contention — 2 tenants × 64 copies of 2 KiB, all submitted before any wait (`rtl-sim`)

| metric | value |
|---|---:|
| solo_device_cycles | 295,360 |
| two_tenants_device_cycles | 584,704 |
| slowdown vs ideal parallel (1.0 = second tenant free, 2.0 = fully serialised) | **1.98** |
| per-tenant bytes/cycle | 0.227, 0.224 |
| Jain fairness index (throughput) | 1.000 |

### Resource-allocation overhead (`rtl-sim`)

| metric | value |
|---|---:|
| alloc+free of a 64 B buffer, p50 / p99 (host wall) | 132 ns / 153 ns |
| NOP: completion record created after (device cycles, p50) | 1 |
| NOP wall round trip p50 (software stack + simulation) | 240 µs |
| tenant provisioning incl. hardware SRAM scrub | 16,476 device cycles (31.9 ms wall) |

### Software-extension workloads (`cpu-ref` only; the RTL blocks these engines)

| workload | through the runtime (host wall) | CPU-only direct call (host wall) | runtime overhead |
|---|---:|---:|---:|
| tensor throughput | 1.01 GMAC/s | 2.22 GMAC/s | 2.2× |
| crypto throughput | 490.74 MB/s | 1,067.35 MB/s | 2.2× |
| storage iops | 378,872.41 IOPS | 1,630,104.33 IOPS | 4.3× |

### Statuses

| benchmark | rtl-sim | cpu-ref |
|---|---|---|
| network_packet_throughput | ok | ok |
| dma_bandwidth | ok | ok |
| memory_copy_latency | ok | ok |
| tensor_throughput | unsupported | ok |
| crypto_throughput | unsupported | ok |
| storage_iops | unsupported | ok |
| multi_tenant_contention | ok | not_measurable |
| resource_allocation_overhead | ok | ok |
| power_efficiency | not_measurable | not_measurable |

### Assumed-clock projection @ 100 MHz — ILLUSTRATIVE ONLY

| benchmark | case | bytes/cycle | MB/s **at the assumed clock** |
|---|---|---:|---:|
| network_packet_throughput | 64B frames | 0.432 | 43.2 |
| network_packet_throughput | 256B frames | 0.443 | 44.3 |
| network_packet_throughput | 1024B frames | 0.446 | 44.6 |
| network_packet_throughput | 1500B frames | 0.447 | 44.7 |
| dma_bandwidth | 256B H2D+D2H | 0.661 | 66.1 |
| dma_bandwidth | 2048B H2D+D2H | 0.666 | 66.6 |
| dma_bandwidth | 8192B H2D+D2H | 1.229 | 122.9 |
| multi_tenant_contention | 2 tenants aggregate | 0.448 | 44.8 |


## Interpretation (what these results do and do not show)

1. **The P61 baseline is a functional design, not a fast one, and these numbers say so.** A copy + CRC-32 + checksum moves
   ≈0.45 payload bytes per device cycle. At an *assumed* 100 MHz that would be ≈45 MB/s — **about 8× slower than one
   host CPU core** doing the same work (≈355 MB/s measured above). P61's own documentation expects this ("one outstanding
   transaction per SFB2 port … far below a real DPU's") and claims no throughput. **No acceleration advantage is
   demonstrated.** The upstream projects point at the remedies (P64's burst CloudDMA reports ≈8 B/cycle; P62's PacketCore
   streams 1 beat/cycle), none integrated yet.
2. **Pipelining roughly doubles single-operation throughput** (0.447 B/cycle pipelined vs 2048 B / 8707 cycles = 0.235
   B/cycle for one copy in flight). Inferred (not separately instrumented): host DMA overlapping the PacketCore stage.
3. **Tenants do not overlap inside the device.** Two tenants each running 64 copies finish in 1.98× the time one needs
   (ideal parallel = 1.0, fully serial = 2.0): the single PacketCore adapter and the single host-memory port serialise
   them. Fairness between them is perfect (Jain 1.000, round-robin). This is the quantified form of the side-channel /
   contention non-claim in `docs/04`. Pure DMA operations appear to overlap: an 8 KiB DMA (4 chunks, 2 DMA channels) reaches
   1.23 B/cycle vs 0.67 for 2 KiB — consistent with chunks running in parallel on the two channels (inferred from the
   numbers, not separately instrumented).
4. **Small-operation latency is real RTL latency**: a 64 B copy completes in ≈281 cycles, 2 KiB in ≈8.7k. The NOP
   figure is the cycle at which the DPU *creates* the completion record (1 cycle after accepting the descriptor,
   verified against the harness directly); the record becomes host-visible ≈2 cycles later. For data-moving
   operations the difference is negligible.
5. **Software extensions** (GEMM, AES-GCM, storage) are *software* in the CPU model; their only meaningful comparison
   is runtime overhead versus calling the same code directly (2–4×: buffer/ticket/window bookkeeping). They say nothing
   about any accelerator because none exists for these workloads.
6. **Wall-clock MB/s of `rtl-sim` (≈0.1–0.5 MB/s) are meaningless as device performance.**

## Methodology notes (and two measurement bugs found while building this)

* Completion latency uses the **DPU's own cycle counter** in the completion record, calibrated to the harness clock
  through a simulation back door (exact). The first implementation measured at the 128-cycle pump step of the wait loop:
  every percentile collapsed to one value and short operations were inflated. Sequential-operation throughput is now
  computed from the sum of exact per-operation latencies, not from the wall of cycles including pump rounding
  (both are in the report).
* Batch throughput (pipelined) uses the cycle-counter delta over the batch (error < one pump step per batch).
* Workloads are deterministic xorshift64 byte streams; no external data. Frame sizes 64/256/1024/1500 B; pipeline depth 12;
  chunk 2048 B; geometry `mt` (2 tenants, 2 DMA channels, 64 KiB SRAM, 32-bit data path).

## Reproducibility (brief §18)

Every report records: **git revision** (+ dirty flag; or the package manifest hash when built from the release zip),
**firmware version** (`none loaded` — the ControlCore idles in boot ROM), **runtime version**, C ABI, **RTL version**
(`P61-RTL-1.0`), DPU ABI, **toolchain** (rustc, gcc, Verilator, OS, CPU model), **device backend** + timing model +
`measured_on_hardware`, **hardware configuration** (geometry, block status), **dataset**, **parameters**,
**correctness result**, **clock information**, and **measurement source** per metric. To reproduce:

```bash
make rtl-all build
target/release/sf-bench run --backend rtl-sim:mt --out a.json --assume-clock-mhz 100
target/release/sf-bench run --backend cpu-ref:mt --out b.json
python3 scripts/gen_bench_md.py          # regenerate the tables
```
Cycle counts are deterministic for a fixed seed (`rtl-sim:mt,seed=N`); wall-clock figures vary with the host.
