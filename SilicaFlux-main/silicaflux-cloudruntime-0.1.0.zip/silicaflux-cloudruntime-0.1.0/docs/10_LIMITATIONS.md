# 10 — Limitations and non-claims

**This is a simulation-first runtime. It is not production-ready and nothing here has been run on hardware.** The
brief requires separate FPGA or ASIC validation before any hardware release; that has not happened.

| Area | Limitation |
|---|---|
| Hardware | No hardware backend. `hw` is a read-only probe. No FPGA/ASIC result, no measured clock, power, area, thermal or link data. |
| Fidelity | `rtl-sim` is the *vendored P61 RTL* in Verilator with a *modelled* host (single-outstanding SFB2, random 0–2 cycle latency). `cpu-ref` is a model validated against it on `mt` geometry, 600 commands + the test suites; it has no timing. |
| PacketCore | The P61 block is a **test adapter** (PASS / XOR32 / BSWAP32 + CRC-32 + checksum). It parses nothing. The real PacketCore (P62) is not integrated. XOR32 is **not** encryption. |
| Engines | GEMM, AES-GCM, storage: **absent in RTL** (blocked); they exist only as software extensions in `cpu-ref`. VirtualIO (P63), CloudDMA-P64, MemoryPool (P65), InferenceScheduler (P66), TensorCore, StorageCore, NVMe, SecureStore: not integrated. |
| Crypto | Software AES-GCM (RustCrypto) validated against published vectors; **not** a validated cryptographic module; keys live in process memory; no key hierarchy/HSM. |
| Firmware | None loaded; ControlCore idles in boot ROM; the host drives the register pages. The ControlCore firmware path (mailbox command set, secure boot) is unused/unauthenticated (CRC-32 only upstream). "Firmware compatibility check" = DPU register ABI + ID check. |
| Isolation | In-process mediator is an API boundary, not a security boundary. The socket-served mediator (`sf-mediatord`) and VFIO transport are **designed, not built** (`docs/03`). No IOMMU/PASID/SR-IOV. Side channels, DoS beyond round-robin, shared-fate on job timeout: not defended (and measured: 1.98× serialisation). |
| Throughput | The DPU baseline moves ≈0.45 B/cycle (copy + FCS) and is slower than one CPU core at any plausible clock (`docs/07`). One outstanding request per port, single PacketCore. |
| Limits | `max_xfer` 4096 B per descriptor (the runtime chunks at 2048); GEMM dims ≤ 64; AES-GCM payload ≤ `max_xfer` (single chunk); 12-byte IVs; AAD ≤ 1024; storage 8192 blocks/tenant; 2 hardware windows per tenant; 32-bit data/address geometry in the harness. |
| Chunked failure | A failed multi-chunk operation leaves its destination unspecified (completion says failed / not committed). |
| Reset | Hard reset discards device-local buffer contents (partitions are re-scrubbed); outstanding operations fail as `SF_ERR_RESET`. |
| Telemetry | No thermal sensor path (PowerClock P27 not integrated): thermal is `unavailable` unless an external source feeds it. The DPU event FIFO (16) drops and counts when unconsumed. |
| Kubernetes | Not run against a kubelet/cluster; wire protocol verified against official stubs only. Allocation accounting is a request count (the kubelet does not report releases). Dockerfile and manifests not applied/built. |
| Python / C | Binding is `ctypes` (no wheels, no async). |
| Licensing | The repository has **no licence file**; manifests say `UNLICENSED`. Vendored P61 carries `third_party/PROVENANCE.md` (same statement); RustCrypto/tonic/etc. keep their own licences (see `Cargo.lock`). |
| CI | `ci/github-workflow.yml` is provided but was **not run on GitHub**; `make ci` was run locally. |

## What would have to be true to call this production-ready (none holds today)

1. A real transport (VFIO + mediator daemon) and an IOMMU-backed deployment, reviewed and tested on hardware.
2. Hardware validation of every isolation property in `tests/security.rs` / `tests/reliability.rs`.
3. A real PacketCore/crypto/storage path, or removal of the extensions from any hardware-facing surface.
4. A closed-timing FPGA/ASIC build with measured throughput that beats the CPU baseline for a stated workload.
5. Authenticated firmware/bitstream, a licence, a security review, and soak/fuzz campaigns on the real device.
