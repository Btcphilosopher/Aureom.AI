# 03 — Linux device access path (design; NOT implemented for hardware)

> **Status.** No physical SilicaFlux CloudDPU, PCIe endpoint, FPGA image, vendor/device ID or kernel driver exists. The
> only transports that exist are the two simulations. `backend/hw.rs` is a **read-only probe** that reports "unavailable"
> and why; it never opens, maps or writes anything. This document is the design a hardware transport must follow and the
> checklist that must be satisfied *before* any tenant is allowed near real hardware.

## Threat model

Tenants are mutually distrusting cloud workloads in containers/VMs on a shared host. The host kernel and the mediator
are trusted; tenant code is not. A tenant must not be able to: read or write another tenant's memory (host DRAM or device
SRAM), program DMA engines with arbitrary addresses, touch configuration registers, observe another tenant's
completions or keys, wedge the device for others, or recover data left by a previous tenant.

## Options considered

| Path | Verdict |
|---|---|
| Raw `/dev/mem`, `mmap` of a BAR in the tenant, user-space MMIO by tenants | **Rejected.** Gives raw MMIO (arbitrary DMA programming) and, without an IOMMU, raw host memory. |
| UIO (`uio_pci_generic`) | **Rejected.** No IOMMU awareness: a device with bus-master enabled can DMA anywhere. |
| Out-of-tree kernel driver doing everything (queues, buffers, ioctls) | Viable but heavy; every policy change is a kernel change; needs the DPU's tenant model mapped onto kernel objects. A candidate for a later *verified* production driver. |
| **VFIO (`vfio-pci`, type-1 IOMMU) behind a privileged mediator** | **Chosen.** The kernel enforces DMA isolation (IOMMU group, `VFIO_IOMMU_MAP_DMA`); user-space policy lives in one small trusted process. Reuses the design already written for HostLink (P25 `sfh_backend_vfio.c`, compile-only). |
| DPDK / SPDK-style user-space driver framework | Possible *inside* the mediator (they also build on VFIO); adds a large dependency for no isolation benefit. |

## Chosen design

```
  tenant container/VM                    privileged node agent  (sf-mediatord — NOT IMPLEMENTED)         kernel / device
 ┌────────────────────────┐   unix socket   ┌─────────────────────────────────────────────┐        ┌───────────────────┐
 │ libsf_cloud (client)    │ ─────────────▶ │ Mediator (this repo's mediator.rs)           │  VFIO  │ vfio-pci + IOMMU  │
 │ alloc/submit/wait only  │  SO_PEERCRED    │ tenants · buffers · quotas · keys · routing │ ─────▶ │ BAR0 (registers)  │
 │ no device node, no MMIO │  + allocation   │ IOVA allocator = RangeAlloc                 │        │ DMA via IOMMU     │
 └────────────────────────┘  token (from     │ owns the ONLY mapping of the BARs           │        │ MSI-X → eventfd   │
                              Allocate)      └─────────────────────────────────────────────┘        └───────────────────┘
```

1. **Only the mediator opens the device.** It binds the function to `vfio-pci`, opens the group, attaches an IOMMU
   domain **before** enabling bus mastering, maps BAR0 itself. Tenants never see `/dev/vfio/*`, a BAR, or a physical address.
2. **Tenant buffers are IOVAs, not CPU addresses.** Host buffers live in memory the mediator allocated and mapped with
   `VFIO_IOMMU_MAP_DMA` at IOVAs from its allocator (the runtime's `RangeAlloc` already hands out the tenant windows);
   unmapped guard gaps surround each window (P25 uses IOVAs above 4 GiB with guard pages). The DPU's own per-beat
   window check is a **second** line behind the IOMMU, not a replacement for it (P61 states plainly that it has no IOMMU).
3. **Tenant → mediator** over a Unix socket. Identity = `SO_PEERCRED` (uid/gid/pid) **and** an allocation token minted by
   the device plugin's `Allocate` and delivered to the container as an env var. The mediator maps identity → tenant and
   enforces the same checks as the in-process mediator (handles with epoch+generation, ownership, quotas, hazards).
4. **No raw register access.** The only register surface exposed over the socket is the workload API; tenant
   provisioning, reset and counters are admin operations on a separate, root-only socket.
5. **Interrupts** — MSI-X → `eventfd` consumed by the mediator, which wakes the waiting session. Polling fallback exists
   in the simulation transport (`advance` + `pop_completion`).
6. **Reset / crash** — FLR (or the DPU's `rst_ni`) on mediator start (`reset_on_open`); a mediator crash leaves tenants
   with dead sockets and the device is reset by the next mediator instance. IOMMU domains are torn down by the kernel
   when the VFIO fd closes, so a crash cannot leave DMA mappings alive.
7. **Sharing is not enabled until validated.** The kubelet-visible unit stays a *whole device* (`docs/05`); the DPU's
   hardware tenants (partitions) are used by the mediator internally and are **not** advertised.

## What exists today vs. what is missing

| Piece | State |
|---|---|
| Mediator logic (tenants, buffers, quotas, keys, completion routing, reset, crash recovery) | **Implemented and tested** in-process (`mediator.rs`, 20 security/reliability tests, on the RTL). |
| Simulation transports | `rtl-sim`, `cpu-ref`. |
| Hardware probe | read-only (`SF_PCI_IDS` + sysfs); always "unavailable". |
| `sf-mediatord` (socket server, `SO_PEERCRED`, tokens) | **Not implemented.** Until it exists, a container using the library runs its **own in-process device** (simulation); there is no cross-process isolation to claim. |
| VFIO backend (`VFIO_IOMMU_MAP_DMA`, BAR mmap, eventfd) | **Not implemented here.** P25 contains a compile-only reference. |
| PCIe endpoint + vendor/device IDs + kernel config (`intel_iommu=on`, `vfio-pci`) | Do not exist / not assigned. |

## Preconditions before enabling any real tenant (all must hold)

1. IOMMU enabled; the device is alone in its IOMMU group (or the group is wholly assigned to the mediator).
2. Bus mastering enabled **after** the IOMMU domain is attached; BAR mapping only in the mediator process.
3. Hardware isolation validated on the real device: per-beat guards, scrub, quarantine, reset-under-load (the simulated
   suites in `tests/security.rs` + `tests/reliability.rs` are the *specification* to re-run against hardware).
4. Function-level reset verified to quiesce DMA before IOMMU mappings are torn down.
5. A documented firmware/bitstream version policy (`docs/02`: register ABI check) and an authenticated update path
   (the ControlCore currently has CRC-32 integrity only).
