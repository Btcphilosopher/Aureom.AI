# Build, test and deploy

## Prerequisites

| Tool | Version used / needed | For |
|---|---|---|
| Rust (cargo) | 1.97 used; ≥ 1.80 needed | runtime, CLI, exporter, plugin, benchmarks |
| Verilator + g++ + make | **5.020** (Ubuntu 24.04 package — the version the RTL projects were verified with) | `rtl-sim` backend (optional: without it the runtime builds and `rtl-sim` reports "unavailable") |
| Python 3 (+ `pyyaml`) | 3.13 | Python tests, manifest check, report tools |
| gcc | 13 | C ABI test, C example |
| CMake ≥ 3.16 | 3.28 | optional C front end |
| Go ≥ 1.22 + network | 1.24 | optional: Kubernetes interop check only |
| Yosys 0.33, Icarus 12 | installed here | not needed by the runtime (only for upstream RTL flows) |

`protoc` is **not** required (`protoc-bin-vendored`). crates.io access is needed once (`Cargo.lock` is provided; use `--locked`).

## Build

```bash
cd runtime/cloud
make                         # RTL simulation libraries (mt, min, mt4: ~10 s each) + cargo build --release
#   or step by step:
make -C rtl/sim CFG=mt       # -> build/rtl/mt/libsfrtl_p61.so
cargo build --release --workspace --lib --bins --examples
#   CMake front end for C/C++ consumers:
cmake -S . -B build/cmake && cmake --build build/cmake && ctest --test-dir build/cmake --output-on-failure
```
Outputs: `target/release/{sfctl,sf-exporter,sf-device-plugin,sf-bench}`, `libsf_cloud.{so,a}`, `include/sf_cloud.h`.

## Run

```bash
target/release/sfctl discover
target/release/sfctl slice --backend rtl-sim:mt        # the end-to-end vertical slice, narrated (exit 0 iff verified)
target/release/sfctl slice --backend cpu-ref
python3 python/examples/slice.py rtl-sim:mt
scripts/run_examples.sh                                # all six examples on every backend, expected outcomes checked
target/release/sf-exporter --backend rtl-sim:mt --listen 127.0.0.1:9477 --synthetic-load
```
The RTL library is found via `SF_RTL_LIB`, else `build/rtl/<cfg>/libsfrtl_p61.so` relative to the executable or the
working directory (walking up).

## Test

```bash
make test        # cargo test --workspace (RTL required) + Python + manifest checks      (incremental ≈ 1 min)
make ci          # + RTL smoke, examples, benchmark smoke, sfctl slice   (clean tree incl. test compile: 193 s on 4 cores)
scripts/ci.sh    # make ci + Go interop when Go is available
```
`SF_REQUIRE_RTL=0` lets the suite run on a machine without Verilator (RTL cases are skipped with a note).

## Container image (not built here)

`deploy/docker/Dockerfile` builds a runtime image (non-root, simulated backends). **No container daemon was available when this
package was produced; the Dockerfile has not been built.** See `docs/05_KUBERNETES.md` for the manifests.

## Release package

`scripts/package.sh` (= `make zip`) writes `silicaflux-cloudruntime-<version>.zip` containing the sources, vendored RTL,
docs, deployment files and benchmark reports — **not** `target/` or `build/` — plus `MANIFEST.sha256` (every file's
SHA-256). It performs **no git operation**. Benchmark reports built from the package record the manifest hash in place of a
git revision.

## Firmware compatibility

At `open` the runtime reads `ID` (must be `SFDP`) and the DPU register ABI version (major must equal 1, else
`SF_ERR_ABI_MISMATCH`); no firmware is loaded. If a future bitstream/firmware changes the register ABI major, the runtime
refuses it instead of mis-driving it. `tests/abi_crosscheck.rs` fails the build if the runtime and the vendored RTL
packages disagree on any constant.
