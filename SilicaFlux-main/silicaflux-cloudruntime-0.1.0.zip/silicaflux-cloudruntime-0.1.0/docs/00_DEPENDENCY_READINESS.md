# 00 — Dependency readiness report

Audit of the SilicaFlux repository for everything the CloudRuntime depends on (brief §1).  Read it before relying on
any claim elsewhere in this package.

## How the evidence was gathered — and how far to trust it

| Evidence kind | Meaning |
|---|---|
| **Re-run here** | I executed it in this environment (Verilator 5.020, Yosys 0.33, Icarus 12, gcc 13, rustc 1.97, Go 1.24). |
| **Reported upstream** | A number taken from the project's own README/reports. The report files were read; **the upstream regressions were not re-run** (they take 15–45 min each). |
| **Absent** | Searched for (file names, `grep` over every extracted archive) and not found. |

As in the earlier SilicaFlux projects, the RTL lives inside zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`.  The archives for CloudDPU (P61), PacketCore (P62), VirtualIO (P63),
CloudDMA (P64), MemoryPool (P65), InferenceScheduler (P66), ControlCore (P21), StorageCore (P51), NVMe HostCore (P57),
SecureStore (P59), HostLink (P25) and the OS runtime (P30) were extracted read-only into a scratch directory and their
READMEs, audit/limitation documents and (for P61) RTL sources were read.  **Nothing from them was modified.**

> Note: the P61 audit (`docs/00_AUDIT.md` inside that archive) states that PacketCore, VirtualIO, CloudDMA and
> InferenceScheduler "do not exist".  That was true when P61 was written; **P62–P66 were added to the repository
> afterwards** (same upload batch), so those statements are now stale.  They exist as *separate, standalone* designs
> and are **not integrated** into the P61 CloudDPU.

## Readiness per dependency

Levels: **R4** integrated and used by this runtime · **R3** real RTL, verified standalone, *not integrated* ·
**R2** behavioural stand-in / model · **R1** interface only · **R0** does not exist.

| Brief item | Where | Level | What exists (evidence) | Used by CloudRuntime |
|---|---|---|---|---|
| **CloudDPU** | P61 `silicaflux-clouddpu-p61.zip` | **R4** (with caveats) | Synthesizable DPU: command queues, command processor, CloudDMA slots, per-beat tenant guards, tenant contexts + scrub, counters, telemetry event port, register map. *Re-run here:* vendored RTL builds in Verilator 5.020 in ~10 s per geometry, boots, and passes the vertical slice, a 600-command differential run vs the CPU model, security and reliability suites. *Reported upstream:* 55/55 regression runs, 20/20 mutants killed, Verilator `-Wall` clean. **Caveat:** PacketCore inside it is a **test adapter**; INFER/CRYPTO/STORAGE are `BLOCKED`. | Yes — `rtl-sim` backend |
| **PacketCore** | P62 `…packetcore-p62.zip` | **R3** | Real parser (Ethernet/VLAN/IPv4/IPv6/TCP/UDP/VXLAN, RSS hash), match/action, queues, scheduler, tenant isolation, statistics. *Reported:* verified vs an independent model; synthesised; place-and-route on a **reduced** ECP5-85F config reaches only 20.6–27.8 MHz (target 50 MHz missed); full default config does not fit. No MAC. AXI-S streaming interface — **not** the DPU's SFB2 job interface. | **No.** Integration = write an adapter replacing `sfd_packetcore_tadapter` (next step 1). |
| **VirtualIO** | P63 `…virtualio-p63.zip` | **R3** | virtio-blk engine (split ring, mmio v2), permission-gated DMA, Rust reference model, C host library `libsfvirtio` with a simulation transport. *Reported:* 23/23 directed, 1,400 random scenarios, 16/16 mutants, formal harness for the permission gate; ECP5-85F 45.9k LUT4, ≈20 MHz, **not timing-closed**; never run against a production guest driver. Defines its own StorageCore interface (none existed). | **No.** P61's `vio_sub/vio_cpl` ports are plain queue ports with a testbench-style host; the runtime drives them directly. |
| **CloudDMA** | P61 `sfd_clouddma` (inside the DPU) **and** P64 `silicaflux_cloud_dma` (standalone) | **R4** (P61 one) / **R3** (P64) | Two implementations. P61's is single-beat, one outstanding request. P64's is a scatter-gather descriptor engine with AXI4 bursts, permission checker and IOMMU interface: *reported* 45/45 + 12/12 regression runs, 29/29 mutants, 7.96 B/cycle on large copies vs an 8 B/cycle ceiling; synthesis generic only. | P61's: yes. P64's: **no** (replacing P61's single-beat slot with it is the biggest available throughput gain). |
| **MemoryPool** | P65 `…memorypool-p65.zip` | **R3** | Region table, allocator, tiering (SRAM/DRAM), migration, scrubber, counters. *Reported:* 3 configs × 3 seeds PASS, 23/24 mutants (the survivor argued equivalent), DRAM tier is a **behavioural model**, **no CXL**, no coherence. | **No.** The runtime's allocator (`alloc.rs`) is software. |
| **InferenceScheduler** | P66 `…p66-inferencescheduler.zip` | **R2/R3** | INT8 GEMM scheduler (RR/WRR/DRR/priority/deadline, per-tenant rate limits), isolation layers. *Reported:* 19 directed tests; mutation campaign: 24 mutants defined, **13 executed and all 13 killed, 11 not run before packaging** — and all against **behavioural TensorCore/memory models**; its own status: "**Integration BLOCKED**: no TensorCore, CloudDMA, MemoryPool or ControlCore source was present" (stale: they exist now, still unintegrated). | **No.** GEMM is therefore `blocked` on the RTL backend. |
| **TensorCore** | P-TC01–TC10 archives | **R3** | INT8 array, unit 111/111, 642 GEMMs, C-driver co-sim (*reported*). One command at a time; SFB2 master. | No (needs P66-style multi-tenant integration first). |
| **CloudCrypto / CryptoCore** | — | **R0** | No GCM-class core anywhere. SecureStore (P59) has AES-XTS/CMAC/KDF/CRC for **storage**, not verified under Yosys 0.33 (needs Verilator ≥ 5.040 per its README), not a validated crypto module. | AES-GCM exists only as a **software** extension in the `cpu-ref` backend (RustCrypto, verified against published test vectors). |
| **StorageFabric** | — | **R0** | Not present. StorageCore P51 (NAND/FTL SoC, ~18k LUT4, no GC, not NVMe/ONFI compliant) and NVMe HostCore P57 are separate. | Block storage exists only as a **software** extension in `cpu-ref`. |
| **CloudTelemetry** | — | **R1** | The DPU's `tlm_*` event port and counters are real RTL; **no consumer existed**. | **This package is the first consumer**: `telemetry.rs`, `sf-exporter`. |
| **ControlCore** | P21 `silicaflux-controlcore.zip` | **R4** (reused inside P61) | RV32IM_Zicsr CPU, boot ROM, SFB2 bus, mailbox, RAS. *Reported:* 231/231 firmware self-test, 107/107 host checks. Firmware integrity = CRC-32 only (no authentication). | Yes, as the DPU's management plane, **without firmware**: the CPU idles in boot ROM and the host drives the register pages directly (the `host_ready_o` / `cmdproc_ready_o` pins are raised by firmware and therefore never assert — found and handled during bring-up). |
| **PCIe interfaces** | P25 HostLink | **R3** | BAR/queue ABI, DMA, MSI, isolation behind a generic AXI endpoint boundary; simulated PCIe host; C driver with a **VFIO backend that compiles and has never run**. **No PCIe protocol logic**, no endpoint IP, no board. | No (design reference for `docs/03`). |
| **Existing host runtime** | P30 `SilicaFlux-OS-runtime-P30.zip` (`runtime/silicaflux`) | **R4 for its target** | C ABI 1.0 runtime for the **HPC vector/tensor tile** with `cpu`, `rtl-cc`, `rtl-hostlink`, `pcie:<BDF>` (compile-only) backends, CMake, `exec_target` labelling. Different device, different ABI (`sf_vector_*`, `sf_tensor_gemm`). | Conventions followed (honest backend labelling, versioned C ABI, simulation first, CMake front end); **no code shared**. |
| **FPGAFlow** | — | **R0** | No project, file or directory with that name in any archive. The practice is per-project open-tool flows on the ULX3S (Yosys `synth_ecp5` + nextpnr-ecp5 + ecppack); **no bitstream anywhere has run on a board**. | No. `fpga/check_prerequisites.sh` reports the blockers. |
| **Hardware** | — | **R0** | No FPGA board, no ASIC, no hardware result of any kind anywhere in the repository. | — |

## What this means for the runtime (decisions taken)

1. **Simulation first, and only P61's RTL is simulated.**  It is the one design that already exposes a complete,
   documented host-facing ABI (queues, windows, register map).  Verilator 5.020 is the version every upstream project
   used.
2. **The CPU reference backend is a model of the P61 *contract*** — validated command-for-command against the RTL
   (`tests/differential.rs`) — and additionally hosts the **software extensions** (GEMM, AES-GCM, storage) for
   workloads the RTL blocks.  Each is labelled as software in every API and report.
3. **Unsupported means unsupported.**  The RTL backend reports `gemm_i8`, `aes_gcm`, `storage` as *not available*
   (derived from the DPU's own `BLOCK_STATUS` register, not assumed); submitting them returns `SF_ERR_UNSUPPORTED`
   naming the operation and backend.  Examples C/D/E exit 3 on `rtl-sim`.
4. **No hardware path is claimed.**  `HardwareSource`/`hw` backends exist only as read-only probes that report
   "unavailable" with the reason.

## Recommended integration order (not done here)

1. **P62 PacketCore → DPU**: replace `sfd_packetcore_tadapter` behind `sfd_pkt_hub` (adapter AXI-S ↔ SFB2 job protocol);
   re-run P61's guard-unit bench with the real engine; add parser-level malformed-packet tests.
2. **P64 CloudDMA → DPU slot** to lift the single-beat limit (the benchmark shows ≈0.45 B/cycle).
3. **P66 + TensorCore** behind the compute queue with per-tenant window enforcement on the tensor DMA, then enable
   `ENABLE_TENSOR`.
4. A **GCM-class CryptoCore** (does not exist), then StorageFabric.
5. A **PCIe endpoint + IOMMU** and the mediator daemon (`docs/03`); only then FPGA bring-up (`docs/08`).

## Gaps found in the repository that this package does not close

* No licence file anywhere in the repository (`third_party/PROVENANCE.md` in the vendored P61 tree says the same). This
  package's manifests declare `license = "UNLICENSED"`: **an owner must choose a licence before any distribution.**
* No firmware authentication / secure boot for the ControlCore (CRC-32 only).
* No timing-closed implementation of any cloud block (P62 20–28 MHz reduced; P63 ≈20 MHz; P61 generic synthesis only).
