# 08 — FPGA integration

## Status: **BLOCKED — nothing in this document has been performed**

`fpga/check_prerequisites.sh` inspects the host and writes `fpga/BRINGUP_STATUS.md`. In this environment it reports
(verbatim facts): no `nextpnr-ecp5` / `ecppack` / `openFPGALoader` / `vivado` / `quartus`; no FPGA PCIe device; no
USB-JTAG/serial device; **no IOMMU groups, no `/dev/vfio/vfio`**; and — independent of this host — **missing from the
repository**: a PCIe endpoint IP / vendor shell (HostLink P25 "contains no PCIe protocol logic"), verified pin and clock
constraints for the CloudDPU, an Ethernet MAC/PHY, and **any previously closed timing** on a cloud block (P61 generic
Yosys only; P62 reduced configuration 20.6–27.8 MHz on ECP5-85F with the full configuration not fitting; P63 ≈20 MHz).

| Brief step (§14) | Status | Blocker |
|---|---|---|
| Build CloudDPU for a board | **not done** | no board/tools; P61 has only generic Yosys cell counts (≈38.5k generic cells for the minimum DPU — *not* an area claim) |
| Apply verified clock and pin constraints | **not done** | no constraints exist for the CloudDPU; the repository's constraints target other designs/boards |
| Integrate PCIe/Ethernet IP | **not done** | none exists in the repository |
| Program the board | **not done** | no board |
| Confirm device communication | **not done** (simulated: PASS) | |
| Run transfer tests | **not done** (simulated: PASS, `tests/vertical_slice.rs`) | |
| Run compute tests | **not done** (simulated: PASS for DMA + PacketCore adapter; GEMM/crypto/storage have no hardware) | |
| Capture telemetry | **not done** (simulated: exporter on `rtl-sim`) | |

**There is no hardware log, no enumeration result, no link speed, no timing report and no utilisation figure for this
design. None is claimed anywhere in this package.** The `hw` backend cannot be opened, and every report carries
`hardware_measurements: []`.

## What a bring-up must achieve (acceptance criteria)

Each criterion needs *evidence files* recorded under `fpga/results/<date>-<board>/`; a criterion without its evidence
file is **not met**.

| # | Step | Command (once the transport exists) | Pass criterion | Evidence |
|---|---|---|---|---|
| 1 | Build | vendor flow / `yosys + nextpnr` script | timing met at the chosen clock **with the report attached**; utilisation report | `build.log`, `timing.rpt`, `utilisation.rpt`, bitstream SHA-256 |
| 2 | Program + enumerate | `lspci -nn -vv -s <BDF>` | device present; negotiated link speed/width recorded | `lspci.txt` |
| 3 | Identity | `sfctl info --backend hw:<BDF>` | `ID = SFDP`, register ABI major 1; `measured_on_hardware = true` only now | `info.txt` |
| 4 | Transfer | vertical slice with real DMA through the IOMMU | byte-exact, `committed`, per-beat guards active | `slice.txt` |
| 5 | Compute | PKT_PROCESS/COPY sweep (sizes of `examples/b`) | identical to the cpu-ref/rtl-sim results (use `tests/differential.rs` as the oracle) | `differential.txt` |
| 6 | Isolation | re-run `tests/security.rs` + `tests/reliability.rs` against the device | all pass; scrub verified by an independent mechanism | `security.txt`, `reliability.txt` |
| 7 | Telemetry | `sf-exporter --backend hw:<BDF>` for ≥ 10 min under load | counters monotonic, no `integrity_anomalies`, thermal source named | `metrics.txt` |
| 8 | Benchmarks | `sf-bench run --backend hw:<BDF>` | `hardware_measurements` populated **with a measured clock** and the evidence above; simulation numbers stay in their own section | `bench.json` |

## Order of work that unblocks it

1. Integrate P62 (PacketCore) and a burst CloudDMA (P64) so the design is worth running (`docs/00`).
2. Pick a board; produce **verified** pin/clock constraints and close timing — the upstream results suggest this will
   force a reduced configuration first.
3. A PCIe endpoint (or UART/Ethernet bring-up path) + IOMMU + the `sf-mediatord` + VFIO transport (`docs/03`).
4. Only then the table above.

Release of anything as "hardware supported" requires separate FPGA **or** ASIC validation, as the brief states.
