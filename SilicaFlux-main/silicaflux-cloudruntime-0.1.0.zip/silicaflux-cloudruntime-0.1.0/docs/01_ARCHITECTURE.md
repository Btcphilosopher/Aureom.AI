# 01 — Runtime architecture

```
 Cloud application ── C ABI (include/sf_cloud.h) · Rust API (Session) · Python (ctypes)
        │  sf_cloud_open / alloc / submit / wait / poll / counters / reset
        ▼
 SilicaFlux API layer ─ ffi.rs: struct_size-prefixed structs, panic containment, thread-local last-error
        ▼
 Runtime scheduler ──── mediator.rs  (PRIVILEGED; one per device)
        │   tenants · buffers · tickets/chunks · staging slots · keys · quotas · completion routing · reset · health
        ▼
 Device transport ───── Backend trait (backend/mod.rs): management registers · queues · host memory · telemetry
        │        ┌──────────────┬────────────────────────────┬──────────────────────────────┐
        ▼        ▼              ▼                            ▼                              ▼
   cpu-ref (software model)   rtl-sim (Verilator, C++ harness   hw (NOT IMPLEMENTED:
   + software extensions      around vendored P61 RTL)           read-only probe, always "unavailable")
        │                          │
        ▼                          ▼
 SilicaFlux CloudDPU ── queue → command processor → job slot → CloudDMA (host↔SRAM) → PacketCore adapter → CloudDMA
        ▼
 Hardware engine ────── (rtl-sim: DMA + PacketCore TEST ADAPTER; GEMM / crypto / storage engines are BLOCKED in the RTL)
        ▼
 Completion ─────────── per-queue completion FIFO → ticket → `Completion` (status, committed, CRC-32, checksum, latency)
```

Every arrow above is exercised by `tests/vertical_slice.rs` on both backends.

## The device contract (`Backend`)

The contract is **the DPU as software sees it**, deliberately the same on every backend:

| Part | Semantics |
|---|---|
| management plane | 32-bit register read/write at the DPU's register pages (`0x4000_8000…`). Privileged: tenant provisioning, reset, counters. An unmapped/read-only access is a **bus error**, never ignored. The local SRAM is *not* reachable from here (only the ControlCore's own CPU/DMA can address it) — found and corrected in the model during testing. |
| data plane | `submit(queue, 12-word descriptor)` → `QueueFull` if not accepted; `pop_completion(queue)` → 8-word record. A submission to a non-existent queue or the firmware-only management queue (15) is accepted by the shared bus and **discarded** (observed on the RTL, mirrored in the model, covered by a test). |
| host memory | the memory the DPU DMAs from/to (IOVA range). In simulation it is a byte array behind an SFB2 slave with random latency/back-pressure. |
| telemetry | 80-bit event records (`retire`, `violation`, `tenant_state`, `dp_reset`). |
| time | `cycles()`. `rtl-sim`: real RTL cycles. `cpu-ref`: a **logical** counter (no timing model). |
| `SimControl` (sim only) | host-error injection, response hold, stalled completion consumer, independent host-access log, SRAM back door, exact DPU-time read. |

`BackendInfo` carries `timing` (`none` / `rtl-simulation` / `hardware`) and `measured_on_hardware`; both are surfaced
in `sf_cloud_info()`, the CLI, the benchmark report and every metric — a number can always be traced to its source.

## Backends

* **`rtl-sim`** — `rtl/sim/sf_rtl_p61.cpp` (≈480 lines) is a Verilator harness around the *unmodified* P61 RTL
  (`rtl/vendor/clouddpu-p61`, SHA-256 manifest, byte-identical to the archive). It plays the simulated host
  (management port, queue ports, SFB2 host-memory slave, telemetry consumer) and contains **no checking of DPU
  behaviour**. Built per geometry (`make -C rtl/sim CFG=mt|min|mt4`, ≈10 s) into `libsfrtl_p61.so`, loaded at run time
  with `dlopen` — the runtime builds and works without Verilator, the backend is simply "unavailable". The C API is
  `rtl/sim/sf_rtl_api.h`. Geometry is **discovered from the DPU's own registers**, not assumed.
  *Harness bug found and fixed:* Verilator 5 keeps a thread-local "current context"; with two devices of the same
  library in one process it dangled and closing an instance deadlocked/aborted. The harness re-binds the context on
  every entry (`tests/rtl_instances.rs` reproduces the hang against an unfixed build).
* **`cpu-ref`** — a software model of the same contract (`backend/cpuref.rs`): register map, tenant state machine
  (commit checks, scrub, quarantine, drain), queue/completion credits, the RTL's validation order and error codes,
  per-beat host windows, counters, telemetry, job watchdog/zombie/DP-reset semantics. **Differentially tested against
  the RTL** (`tests/differential.rs`: 600 random commands, completions field-for-field, full host-memory image,
  counters, tenant states, telemetry sequence). It additionally runs the **software extensions** (INT8 GEMM,
  AES-GCM, block storage) which the RTL cannot.
* **`hw`** — not implemented. `backend/hw.rs` is a read-only sysfs probe that reports `available: false` with the
  reason. See `docs/03_LINUX_DEVICE_ACCESS.md` for the intended path.

## The mediator (privileged layer)

One `Mediator` owns one backend. Tenants hold a `Session` — a capability that can only name objects of their own tenant.

* **Provisioning**: SRAM partition (256 B pages) + two host windows (R for device-read-only buffers, RW for
  device-writable ones) + quotas → shadow registers → `COMMIT` → poll result → wait for the **hardware scrub** → `ENABLE`.
  Overlap is refused by the device (`CFG_OVERLAP_*`), and the mediator's own allocators avoid it.
* **Buffers**: handles = `epoch(16) | generation(16) | tenant(8) | index(24)`. States `HostOwned → DeviceOwned →
  HostOwned`, or `Quarantined` after a device timeout. The **pin is released only by the device's completion
  record** for that exact command, so a freed buffer can never be the target of a late DMA. Memory is zeroed on free and
  at provisioning. Device-local buffers live in the tenant's SRAM partition above the staging area and are not CPU
  accessible.
* **Operations**: validated in software (alignment, ranges, permissions, hazards: one writer excludes everyone),
  **chunked** to `chunk_bytes` (2048) with per-chunk staging slots, submitted round-robin over the tenant's queues,
  completions routed by `(queue, tag)`. CRC-32 and the RFC 1071 checksum of a multi-chunk operation are combined with
  `crc32_combine` / ones-complement addition (unit-tested against direct computation).
* **Completion semantics**: a ticket is delivered **exactly once**; `Completion.committed` is true only if every output
  byte was acknowledged by its destination; a failed multi-chunk operation leaves the destination *unspecified*
  (documented and tested) while a failed single-chunk operation leaves it untouched.
* **Bounded waiting**: every wait has a wall-clock budget **and** a device-cycle budget → `SF_ERR_TIMEOUT`
  ("may still be running"). Nothing blocks forever.
* **Reset**: *data-plane* (aborts running jobs with `RESET_ABORT`, clears a halted plane, queues and tenants survive) and
  *hard* (all device state lost: every outstanding command is failed locally as `Reset`, tenants are re-provisioned
  from the mediator's records, device-local buffer contents are lost). *Crash*: `Mediator::crash()` + `open(reset_on_open)`.
* **Health**: `Healthy` / `Degraded` (quarantined tenant, sticky host/descriptor fault, thermal warning) /
  `Faulted` (halted data plane, sticky timeout/internal/SRAM fault, thermal critical) / `Unavailable`.

## Vertical slice, step by step (what actually happens on `rtl-sim`)

`sfctl slice --backend rtl-sim:mt`

1. **Discovery** — `discover()` lists devices with an availability *reason*; `open` reads `ID` (`SFDP`), ABI version
   (major must be 1), `CONFIG0/1`, `BLOCK_STATUS`, queue bindings.
2. **Secure allocation** — tenant provisioned and scrubbed by the hardware; `alloc(DEV_READ)` / `alloc(DEV_WRITE)`
   place the buffers in the R / RW window.
3. **DMA** — the descriptor `PKT_PROCESS` goes to the tenant's queue; CloudDMA reads host → SRAM beat by beat, each beat
   passing the per-beat host and SRAM guards.
4. **Accelerator operation** — the PacketCore *test adapter* transforms the staged bytes and computes CRC-32 ×2 and the
   RFC 1071 checksum.
5. **Completion** — CloudDMA writes SRAM → host; the completion record is built only after the last write is
   acknowledged (`COMMITTED` flag); the mediator unpins the buffers and delivers the ticket.
6. **Telemetry** — counters (`CMDS_*`, `DMA_BYTES_*`), per-tenant counters, `retire` event, exporter text.

## Threading

A `Mediator` and its `Session`s are `Send + Sync`; calls serialise on one lock. Waits release the lock between 128-cycle
pump steps. The C handle may be shared across threads; it must not be used after `sf_cloud_close`.
