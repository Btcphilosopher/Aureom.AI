# 09 — Testing and verification

## Inventory (all run by `make test`; counts from the last full run in this environment)

| Suite | Tests | Backends | What it establishes |
|---|---:|---|---|
| `sf-cloud` unit | 13 | — | CRC-32 (check value `CBF43926`), `crc32_combine`, RFC 1071 (RFC example), descriptor/completion/telemetry codecs, range allocator, CDI/visibility |
| `abi_crosscheck` | 4 | — | **every Rust ABI constant equals the vendored RTL package** (parses `silicaflux_cloud_pkg.sv` and the memmap): opcodes, error codes, states, register offsets, descriptor/completion bit positions |
| `vertical_slice` | 4 | cpu-ref + rtl-sim | the end-to-end slice, DMA round trip, discovery, unsupported-on-RTL |
| `differential` | 1 (600 commands) | cpu-ref vs rtl-sim | **model ≡ RTL**: every completion field, full host-memory image, 9 event counters, per-tenant counters, tenant states, telemetry sequence — on valid commands, over a dozen classes of malformed descriptor, 78 isolation violations with quarantine/recovery |
| `security` | 10 | both | lengths/ranges, handle scoping & forgery, use-after-free & generation reuse, in-flight protection, quotas/exhaustion, storm, hardware guards (raw queue), forged tenant, 300 fuzzed descriptors, management/invalid queues |
| `reliability` | 10 | both | device unavailable, **command timeout + orphaned host response**, bounded waits, stalled completion consumer, memory failure & partial transfer, hard reset mid-flight, **driver crash + recovery (SRAM/host scrub verified through a back door)**, deprovision under load, thermal policy, register-map bounds |
| `extensions` | 6 | cpu-ref | GEMM vs reference; AES-GCM **NIST/McGrew–Viega test cases 4 & 16** (re-derived with OpenSSL); tamper detection releases no plaintext; key ownership; storage namespaces; extension commands obey the same window guards |
| `rtl_instances` | 2 | rtl-sim | several devices of one library in a process, any drop order, cross-thread use (regression for the Verilator thread-local-context bug; hangs, and fails by watchdog, against an unfixed harness) |
| `c_abi` + `abi_test.c` | 2 | both | the whole slice **through the C ABI only**, struct sizes header↔library, negative paths, privilege separation; compiled with `-Wall -Wextra -Werror` |
| ctest (CMake) | 4 | both | C ABI test + C example |
| Python | 6 | both | binding layout, errors, slice (CRC vs `zlib`), GEMM by hand, GCM test case 4 |
| `plugin_e2e` | 8 | — | device plugin vs a mock kubelet (see `docs/05`) |
| Go interop | 1 script | — | plugin vs Kubernetes' official stubs |
| examples | 12 combos | both | A,B,F pass on both; C,D,E pass on cpu-ref and **must exit 3 (UNSUPPORTED) on rtl-sim** |
| manifests | 1 | — | security properties of `deploy/k8s` (checker verified against 4 mutations) |
| `rtl/sim/smoke.c` | 3 geometries | rtl-sim | raw harness smoke without Rust (ID, BLOCK_STATUS, tenant bring-up, NOP, PKT_PROCESS, violation refused with zero host writes) |

`SF_REQUIRE_RTL=1` (the default in `make`) turns a missing RTL library into a **failure**; without it the RTL cases
print a note and are skipped — CI must not skip silently.

## Defects found by this verification (and what each was)

| Found by | Defect | Where | Fix |
|---|---|---|---|
| bring-up | `host_ready_o`/`cmdproc_ready_o` never assert without ControlCore firmware | my harness (wrong readiness condition) | readiness = the DPU answers `ID == SFDP` |
| differential/security | model accepted SRAM access through the management port (the RTL answers a bus error) | `cpu-ref` model | removed; SRAM back door added for scrub checks |
| security | submission to a non-existent / management queue was refused by the model (the RTL accepts and discards) | `cpu-ref` model | matched to the RTL, covered by a test |
| extensions | **panic** (integer overflow) in the storage range check on `lba = u64::MAX` | `cpu-ref` model | checked 64-bit arithmetic; a malformed command must never crash the device |
| multi-instance test | process abort / deadlock closing one of two RTL instances (dangling thread-local Verilator context) | my harness | re-bind the context on every entry; regression test with watchdog |
| plugin | registered with the kubelet **before** checking that its own socket existed, advertising a non-existent endpoint after a kubelet restart | device plugin supervisor | check/rebuild the socket first; test asserts exactly one registration |
| benchmarks | latency percentiles identical and short-op throughput inflated (measured at the 128-cycle pump step) | measurement | exact DPU timestamps (+ back-door calibration) |
| benchmarks | NOP "1 cycle" looked impossible | my reading | verified at harness level: completion record is created 1 cycle after acceptance; metric renamed and defined |
| reliability | "failed read produces no output" asserted for a multi-chunk copy | my test | semantics documented: multi-chunk failure leaves the destination unspecified; single-chunk untouched |
| several | wrong expectations in my own tests (SRAM-range is a violation, odd addresses fail ALIGN before the window check, reused buffer still holds earlier plaintext, …) | my tests | corrected; **none was a DPU/RTL defect** |

**No defect in the vendored P61 RTL was found**; every discrepancy between model and RTL was resolved in favour of the RTL.

## What is *not* covered

* The upstream regressions/mutation campaigns were **not re-run** (only P61's RTL was compiled and exercised through
  this runtime). Coverage of the RTL beyond the exercised paths is the upstream project's, not this package's.
* No formal proof, no code-coverage measurement, no mutation testing of *this* runtime's code.
* Only the `mt` geometry carries the full differential/security/reliability load; `min` and `mt4` pass the raw smoke
  test and are built by CI but are not regressed (`mt4` is not even part of the upstream regression).
* Concurrency: multi-thread use is exercised by the examples, `rtl_instances` and the plugin tests, not by a dedicated
  stress/loom campaign.
* Hardware: nothing.
