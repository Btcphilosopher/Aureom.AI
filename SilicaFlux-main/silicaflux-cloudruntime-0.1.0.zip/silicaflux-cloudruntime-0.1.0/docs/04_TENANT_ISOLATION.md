# 04 — Tenant isolation

> *A tenant ID alone does not provide isolation.* (P61 brief; the same principle applies here.)

Isolation in this package is the **product of two independent layers**, tested separately:

* the **device** (hardware guards in the P61 RTL, or the model of them): enforced even if all software above is
  buggy or hostile;
* the **mediator** (software): enforced for every call that goes through the API.

The security tests inject descriptors straight into a tenant's queue through the privileged raw interface to prove the
first layer stands on its own (`tests/security.rs::hardware_*`, `fuzzed_descriptors_*`), and call the public API to
prove the second (`handles_*`, `use_after_free_*`, `in_flight_*`, `resource_exhaustion_*`).

## The seven objects of the brief

| Object | Hardware enforcement (P61) | Mediator enforcement | Evidence |
|---|---|---|---|
| **Device ownership** | Only the management plane reaches tenant configuration; a *live* tenant's windows/partition cannot be edited (`COMMIT` refused unless DISABLED) | One `Mediator` owns the backend; sessions are capabilities; admin calls are unreachable from `Session`; credential required to open a session | `c_abi_test` privilege checks; `reliability::raw_register_access_*` |
| **DMA permissions** | Per-tenant host windows `{base,size,R,W}`; checked per command **and on every beat**; a transfer must lie in **one** window; SRAM partitions per tenant, 256 B granular, non-overlapping | A buffer's device permission (`DEV_READ`/`DEV_WRITE`) decides *which window* it lives in, so the hardware window enforces it too; operand ranges and permissions validated before submit | `hardware_refuses_cross_tenant_and_read_only_dma` (cross-tenant read/write, RO-window write, window overrun, address wrap), independent access-log monitor |
| **Queue permissions** | Each queue is hard-wired to one tenant; the descriptor's `tenant` is only a *claim* (`ERR_TENANT_MISMATCH`, a violation); host submit bus cannot reach the firmware-only management queue | The mediator never lets a tenant choose a queue or tenant | `hardware_refuses_forged_tenant_*`, `management_and_invalid_queues_are_not_tenant_reachable` |
| **Key ownership** | — (no crypto hardware exists) | Keys are tenant-owned slots with epoch+generation handles; foreign handle ≡ stale handle; wiped on unload/close/crash | `keys_are_owned_by_their_tenant`; AES-GCM auth-failure releases no plaintext |
| **Buffer lifetime** | Partitions scrubbed on assignment, teardown, recovery | Pin until the *device's* completion; generation on every slot reuse; zero on free; quarantine after a device timeout until reset; `epoch` makes handles from a crashed runtime unusable | `use_after_free_*`, `in_flight_*`, `command_timeout_*`, `driver_crash_*` |
| **Completion visibility** | One completion FIFO per queue; a record carries the queue's tenant | Completions routed by `(queue, tag)`; a foreign-tenant record is an integrity violation (`anomalies_tenant_mismatch`), a record with no ticket is counted and dropped; each ticket is delivered once and only to its tenant | `handles_are_tenant_scoped…` (foreign/consumed tickets), `submission_storm_loses_nothing` |
| **Error reporting** | Violations quarantine *that* tenant only; sticky fault bits, last-fault capture, telemetry `violation` event | Distinct status per cause; **foreign handles are indistinguishable from freed ones** (no oracle for another tenant's objects) but are **audited** (`cross_tenant_attempts`, exported as `silicaflux_integrity_anomalies_total`) | metrics, `reliability`, example F (400 hostile attempts audited) |

## Tenant state machine (hardware)

`DISABLED → (COMMIT) SCRUBBING → DISABLED(configured) → (ENABLE) ACTIVE`; `ACTIVE → (violation) QUARANTINED`;
`ACTIVE|QUARANTINED → (DISABLE/RECOVER) DRAINING → SCRUBBING → DISABLED`. The mediator's `recover_tenant`,
`deprovision_tenant` and `reset_hard` drive it; the test suites verify the SRAM partition is **zero** afterwards by a
simulator back door independent of the DPU's data path.

## Privileged mediation

`Mediator` is the privileged object; `Session` is the unprivileged capability. In-process this is an **API boundary,
not a security boundary**: code in the same address space can do anything. The real boundary is the process split of
`docs/03` (a socket-served mediator + VFIO), which is **not implemented**. Consequently:

* `SF_OPEN_STANDALONE` gives one handle both capabilities **by design** — it is a development / single-application mode.
* Multi-tenant sharing must not be exposed to untrusted tenants until the daemon, an IOMMU and hardware validation exist.

## Explicit non-claims

* **Side channels.** SRAM banks, the fabric, the host-memory port and the **single PacketCore adapter are shared**.
  Measured (`docs/07`): two tenants running the same copy workload take **1.98×** the solo time — the shared resources
  serialise them. Latency is observable across tenants.
* **Denial of service** beyond round-robin arbitration and per-queue completion credits. A *job timeout halts the data
  plane for every tenant* until a data-plane reset (a stuck host memory cannot be told apart from a stuck slot):
  shared-fate by design, tested (`command_timeout_*`).
* **Host IOMMU/PASID/SR-IOV** do not exist; the DPU's per-beat window check is its only host-address protection.
* **Keys** are process memory (wiped with volatile writes, not hardware-protected); no key hierarchy, no HSM, no
  validated cryptographic module. AES-GCM is a software extension.
* **Firmware** (ControlCore) integrity is CRC-32; not authenticated. No firmware is loaded in this runtime.
* Nothing here has been validated on hardware.
