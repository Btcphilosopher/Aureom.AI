# 05 — Kubernetes integration

Implements the **kubelet device-plugin API v1beta1** (the stable version; `pluginapi.Version = "v1beta1"`). The proto is
the **verbatim upstream file** (`third_party/k8s/deviceplugin_v1beta1_api.proto`, SHA-256 recorded in `PROVENANCE.md`),
compiled with tonic; `protoc` comes from the `protoc-bin-vendored` crate, so no system protobuf is needed.

## Resource names — and why there are two

| Resource | Meaning | Advertised today |
|---|---|---|
| `aureom.ai/silicaflux-dpu` | a **physical** CloudDPU | **never** — no hardware transport exists; `--mode hardware` registers and advertises **0 devices** and logs why |
| `aureom.ai/silicaflux-dpu-sim` | a **simulated** device (cpu-ref / rtl-sim) | only with `--mode simulated --sim-devices …` and the node label `aureom.ai/silicaflux=simulated` |

A simulator can therefore never satisfy a request for hardware, and a real DPU resource name can't appear by accident.
Device IDs: `cpu-ref-0`, `rtl-sim-0`, … (one per **whole device**).

## Behaviour

| Requirement | Implementation | Test |
|---|---|---|
| Registration | `Registration.Register {version v1beta1, endpoint, resource_name, options}`; the plugin socket is checked/rebuilt **before** registering (the kubelet dials the endpoint right after `Register`) | `registers_with_resource_endpoint_and_options` |
| Discovery | `DeviceSource` trait: `SimulatedSource` (opens each backend + mediator), `HardwareSource` (always empty) | `partitions_are_never_advertised_and_hardware_is_never_faked` |
| `ListAndWatch` | full list on connect and on **every** change; health polled every `--health-interval-secs` | `list_and_watch_streams_health_changes_and_removals` |
| `Allocate` | unknown device → `InvalidArgument`; unhealthy → `FailedPrecondition` (with the reason); empty request → `InvalidArgument`; a mixed request fails as a whole and records nothing. Response: env `SILICAFLUX_VISIBLE_DEVICES`, `SILICAFLUX_BACKEND`, annotations, optional CDI names. **No `devices` (device nodes), no `mounts`** | `allocate_validates_devices_and_never_hands_out_device_nodes` |
| `GetPreferredAllocation` | `must_include` first, then least-allocated, ties by id | `preferred_allocation_spreads_and_honours_must_include` |
| Health changes | `Healthy`/`Unhealthy` from `Mediator::health()`: `Healthy`/`Degraded` ⇒ Healthy, `Faulted`/`Unavailable` ⇒ Unhealthy. Operator override: `--override-dir DIR` (a file named after the device marks it unhealthy) | same + Go interop |
| Restart / re-registration | kubelet restart wipes the socket directory → rebuild the server **then** register once; kubelet-socket-only change → re-register; kubelet absent at start → wait; kubelet refusing → retry | `kubelet_restart_triggers_reregistration_and_server_rebuild`, `plugin_waits_for_a_kubelet_that_starts_later`, `registration_rejected_by_the_kubelet_is_retried_not_fatal` |
| Resource accounting | ledger of every successful `Allocate` + per-device counters + metrics | `allocate_*` |
| Partitions | **never advertised** (each device is whole; no flag exists to change that) | `partitions_are_never_advertised…` |

### Accounting is a request count, not live occupancy

The kubelet does **not** tell a device plugin when a container ends. `silicaflux_plugin_device_allocations_total` is
therefore an upper-bound request count. The kubelet is the source of truth (`kubectl describe node`, the PodResources
API); reconciling against PodResources is future work.

## Independent protocol check (not just self-consistency)

`scripts/k8s_interop.sh` builds a **fake kubelet in Go on Kubernetes' own generated stubs** (`k8s.io/kubelet v0.31.0`),
runs the Rust plugin binary against it and checks registration fields, `ListAndWatch` (initial list **and** a live
health push), `Allocate` (codes + payload), `GetPreferredAllocation`, `PreStartContainer`, and that the CDI spec
parses. Result recorded in this environment: **`INTEROP: PASS (official k8s.io/kubelet stubs)`**. The Rust-only mock
kubelet tests (8) could agree with each other and still disagree with a real kubelet; this check removes that risk for
the wire protocol. It is **not** a test against a running kubelet/cluster — none was available.

## Container integration

* **Device visibility**: the library honours `SILICAFLUX_VISIBLE_DEVICES` (`all` / empty / `void` / `none` / a list): in a
  container only the allocated device(s) can be opened or discovered; opening any other is refused.
* **CDI**: `--cdi` returns qualified names (`aureom.ai/silicaflux-dpu-sim=<id>`) and maintains a CDI spec
  (cdiVersion 0.6.0) in `--cdi-dir` (atomic write on every inventory change); `sfctl cdi --devices a,b` generates one
  offline. CDI edits contain **environment only** — no device nodes, no mounts.
* **Resource permissions**: manifests (`deploy/k8s/`) run unprivileged, `readOnlyRootFilesystem`, all capabilities dropped,
  `RuntimeDefault` seccomp, `automountServiceAccountToken: false`, no host namespaces; the only `hostPath`s are the
  plugin's kubelet socket directory and the CDI directory. `scripts/check_manifests.py` enforces this (verified to fail
  on four deliberate regressions).
* **Config generation / logging / health**: structured `key=value` logs on stderr (`event=registered`, `health_change`,
  `allocated`, …); `/healthz` and `/metrics` on `--metrics-listen`.
* **No mediator socket is mounted**, because no mediator daemon exists (`docs/03`). A pod today runs the runtime
  library **in-process** against the simulated backend named in its environment.

## Deploy (simulated)

```bash
kubectl label node <node> aureom.ai/silicaflux=simulated
docker build -f runtime/cloud/deploy/docker/Dockerfile -t ghcr.io/aureom-ai/silicaflux-cloud-runtime:0.1.0 runtime/cloud   # untested: no container daemon here
kubectl apply -f runtime/cloud/deploy/k8s/device-plugin-daemonset.yaml
kubectl apply -f runtime/cloud/deploy/k8s/workload-pod.yaml      # requests aureom.ai/silicaflux-dpu-sim: 1
kubectl get node <node> -o jsonpath='{.status.allocatable}'      # shows aureom.ai/silicaflux-dpu-sim
```

## Not done / not claimed

Run against a real kubelet or cluster; the Dockerfile and manifests were **not applied** (no cluster, no container daemon);
PodResources reconciliation; topology hints; NUMA; hardware mode; partition sharing; admission policy for the node label.
