//! sf-exporter: Prometheus exporter + lightweight dashboard for a SilicaFlux CloudDPU.
//!
//!   sf-exporter [--backend SPEC] [--listen ADDR] [--synthetic-load]
//!
//!   GET /metrics        Prometheus text exposition
//!   GET /healthz        200 if the device is healthy or degraded, 503 if faulted/unavailable (JSON body)
//!   GET /api/snapshot   JSON for the dashboard
//!   GET /               dashboard
//!
//! The exporter owns its own mediator and device instance (simulated backends are in-process; a physical
//! transport does not exist yet).  `--synthetic-load` runs a small self-generated workload so a demo shows moving
//! numbers; it is announced in the metrics (`silicaflux_exporter_synthetic_load 1`) and is never on by default.
use sf_cloud::backend::{self, BackendSpec};
use sf_cloud::mediator::{alloc_flags as f, Health, Mediator, MediatorOptions, Op, TenantConfig};
use sf_cloud::telemetry::{self, Rates};
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

const DASHBOARD: &str = include_str!("dashboard.html");

struct State {
    m: Mediator,
    synthetic: bool,
    last: Mutex<Option<(Instant, u64, u64, u64)>>, // (when, bytes_ok, ops_ok, cycles)
    started: Instant,
}

fn arg(args: &[String], name: &str) -> Option<String> {
    args.iter().position(|a| a == name).and_then(|i| args.get(i + 1)).cloned()
}

fn respond(s: &mut TcpStream, code: u16, ctype: &str, body: &str) {
    let reason = match code {
        200 => "OK",
        404 => "Not Found",
        405 => "Method Not Allowed",
        503 => "Service Unavailable",
        _ => "Error",
    };
    let _ = write!(
        s,
        "HTTP/1.1 {code} {reason}\r\nContent-Type: {ctype}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n\r\n",
        body.len()
    );
    let _ = s.write_all(body.as_bytes());
}

fn metrics(st: &State) -> Result<String, String> {
    let snap = st.m.snapshot().map_err(|e| e.to_string())?;
    let c = &snap.counters;
    let now = Instant::now();
    let rates = {
        let mut last = st.last.lock().unwrap();
        let r = last.map(|(t, b, o, cy)| {
            let dt = now.duration_since(t).as_secs_f64().max(1e-6);
            let db = c.stats.bytes_ok.saturating_sub(b) as f64;
            let dc = c.cycles.saturating_sub(cy) as f64;
            Rates {
                bytes_per_second_wall: db / dt,
                ops_per_second_wall: c.stats.ok.saturating_sub(o) as f64 / dt,
                bytes_per_device_cycle: if snap.info.backend.timing != backend::TimingModel::None && dc > 0.0 { Some(db / dc) } else { None },
            }
        });
        *last = Some((now, c.stats.bytes_ok, c.stats.ok, c.cycles));
        r
    };
    let mut text = telemetry::render_prometheus(&snap, rates);
    text.push_str("# HELP silicaflux_exporter_synthetic_load 1 if this exporter generates its own demo workload.\n# TYPE silicaflux_exporter_synthetic_load gauge\n");
    text.push_str(&format!("silicaflux_exporter_synthetic_load {}\n", st.synthetic as u8));
    text.push_str("# HELP silicaflux_exporter_uptime_seconds Exporter uptime.\n# TYPE silicaflux_exporter_uptime_seconds gauge\n");
    text.push_str(&format!("silicaflux_exporter_uptime_seconds {:.0}\n", st.started.elapsed().as_secs_f64()));
    Ok(text)
}

fn handle(mut s: TcpStream, st: &State) {
    let _ = s.set_read_timeout(Some(Duration::from_secs(5)));
    let mut buf = [0u8; 4096];
    let mut n = 0;
    while n < buf.len() {
        match s.read(&mut buf[n..]) {
            Ok(0) => break,
            Ok(k) => {
                n += k;
                if buf[..n].windows(4).any(|w| w == b"\r\n\r\n") {
                    break;
                }
            }
            Err(_) => return,
        }
    }
    let req = String::from_utf8_lossy(&buf[..n]).into_owned();
    let line = req.lines().next().unwrap_or("");
    let mut parts = line.split_whitespace();
    let (method, path) = (parts.next().unwrap_or(""), parts.next().unwrap_or(""));
    if method != "GET" {
        return respond(&mut s, 405, "text/plain", "only GET\n");
    }
    let path = path.split('?').next().unwrap_or("");
    match path {
        "/metrics" => match metrics(st) {
            Ok(t) => respond(&mut s, 200, "text/plain; version=0.0.4; charset=utf-8", &t),
            Err(e) => respond(&mut s, 503, "text/plain", &format!("# snapshot failed: {e}\n")),
        },
        "/healthz" => {
            let h = st.m.health();
            let ok = matches!(h, Health::Healthy | Health::Degraded(_));
            let body =
                format!("{{\"state\":\"{}\",\"reasons\":[{}]}}\n", h.name(), h.reasons().iter().map(|r| format!("\"{}\"", r.replace('"', "'"))).collect::<Vec<_>>().join(","));
            respond(&mut s, if ok { 200 } else { 503 }, "application/json", &body)
        }
        "/api/snapshot" => match st.m.snapshot() {
            Ok(snap) => respond(&mut s, 200, "application/json", &telemetry::snapshot_json(&snap)),
            Err(e) => respond(&mut s, 503, "application/json", &format!("{{\"error\":\"{}\"}}", e.to_string().replace('"', "'"))),
        },
        "/" | "/index.html" => respond(&mut s, 200, "text/html; charset=utf-8", DASHBOARD),
        _ => respond(&mut s, 404, "text/plain", "not found\n"),
    }
}

fn synthetic_load(m: Mediator) {
    std::thread::spawn(move || {
        let Ok(cred) = m.provision_tenant(0, TenantConfig::default()) else { return };
        let Ok(s) = m.open_session(0, &cred) else { return };
        let (Ok(a), Ok(b)) = (s.alloc(2048, f::DEV_READ), s.alloc(2048, f::DEV_WRITE)) else { return };
        let _ = s.write(a, 0, &[0x5Au8; 2048]);
        loop {
            if let Ok(t) = s.submit(&Op::Copy { src: a, src_off: 0, dst: b, dst_off: 0, len: 2048 }) {
                let _ = s.wait(t, Duration::from_secs(5));
            }
            std::thread::sleep(Duration::from_millis(100));
        }
    });
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        eprintln!("usage: sf-exporter [--backend SPEC] [--listen ADDR] [--synthetic-load]\n  SPEC: auto | cpu-ref | rtl-sim[:cfg=mt] ; default listen 127.0.0.1:9477");
        return;
    }
    let spec = arg(&args, "--backend").unwrap_or_else(|| "auto".into());
    let listen = arg(&args, "--listen").unwrap_or_else(|| "127.0.0.1:9477".into());
    let synthetic = args.iter().any(|a| a == "--synthetic-load");
    let be = match BackendSpec::parse(&spec).and_then(|s| backend::open_backend(&s)) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("sf-exporter: cannot open backend '{spec}': {e}");
            std::process::exit(2);
        }
    };
    let m = match Mediator::open(be, MediatorOptions::default()) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("sf-exporter: cannot open device: {e}");
            std::process::exit(2);
        }
    };
    let info = m.info();
    eprintln!(
        "sf-exporter: device '{}' ({}) timing='{}' measured_on_hardware={}",
        info.backend.name,
        info.backend.description,
        info.backend.timing.as_str(),
        info.backend.measured_on_hardware
    );
    if synthetic {
        eprintln!("sf-exporter: --synthetic-load: generating a small demo workload (announced in the metrics)");
        synthetic_load(m.clone());
    }
    let listener = match TcpListener::bind(&listen) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("sf-exporter: cannot listen on {listen}: {e}");
            std::process::exit(2);
        }
    };
    eprintln!("sf-exporter: listening on http://{}", listener.local_addr().unwrap());
    let st = Arc::new(State { m, synthetic, last: Mutex::new(None), started: Instant::now() });
    for conn in listener.incoming().flatten() {
        let st = st.clone();
        std::thread::spawn(move || handle(conn, &st));
    }
}
