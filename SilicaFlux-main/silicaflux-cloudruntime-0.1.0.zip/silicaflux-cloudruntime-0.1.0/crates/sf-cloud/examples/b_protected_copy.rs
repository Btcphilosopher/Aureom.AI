//! Example B -- protected memory-copy accelerator.
//!
//! Copies buffers of many sizes through the device and proves, per copy, that every destination byte was
//! committed (`committed` flag) and that the device-computed CRC of source and destination agree.  Then it
//! shows the protections: stale handles, foreign handles, overruns, permission misuse, in-flight reuse, and
//! -- through the privileged raw queue, i.e. a tenant driver that bypasses the runtime -- the DEVICE's own guard
//! refusing a write into a read-only window without moving a byte.
mod common;
use common::*;
use sf_cloud::mediator::{alloc_flags as f, Op};
use sf_cloud::proto::{self, err, op, reg, Cmd};
use sf_cloud::status::Status;
use std::time::Duration;

fn main() {
    let (m, ss, info) = open(2);
    require(&info, "dma/copy", info.backend.caps.pkt_process);
    let a = &ss[0];
    let w = Duration::from_secs(60);
    let mut rng = Rng(0xB0B);
    println!("\n-- copy sweep (odd sizes and multi-chunk transfers included)");
    for n in [1usize, 3, 4, 63, 64, 1000, 2048, 2049, 4096, 10_000, 65_000] {
        let data = rng.bytes(n);
        let (src, dst) = (a.alloc(n as u64, f::DEV_READ).unwrap(), a.alloc(n as u64, f::DEV_WRITE).unwrap());
        a.write(src, 0, &data).unwrap();
        let t = a.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: n as u64 }).unwrap();
        let c = a.wait(t, w).unwrap();
        let mut out = vec![0u8; n];
        a.read(dst, 0, &mut out).unwrap();
        check(c.status == Status::Ok && c.committed && out == data && c.crc_in == c.crc_out && c.crc_in == Some(proto::crc32(&data)), &format!("copy of {n} bytes: {c:?}"));
        println!("  {n:>6} bytes  chunks={:<2} committed={}  crc={:08x}  OK", c.chunks, c.committed, c.crc_in.unwrap());
        a.free(src).unwrap();
        a.free(dst).unwrap();
    }

    println!("\n-- protections (each must be refused)");
    let (src, dst) = (a.alloc(256, f::DEV_READ).unwrap(), a.alloc(256, f::DEV_WRITE).unwrap());
    let freed = a.alloc(64, 0).unwrap();
    a.free(freed).unwrap();
    let expect = |what: &str, got: Status, want: Status| {
        println!("  {what:<58} -> {}", got.name());
        check(got == want, &format!("{what}: expected {}, got {}", want.name(), got.name()));
    };
    expect("use after free", a.write(freed, 0, b"x").unwrap_err().status, Status::StaleHandle);
    expect("double free", a.free(freed).unwrap_err().status, Status::StaleHandle);
    expect("copy longer than the buffer", a.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: 257 }).unwrap_err().status, Status::Range);
    expect("destination is a DEV_READ-only buffer", a.submit(&Op::Copy { src: dst, src_off: 0, dst: src, dst_off: 0, len: 8 }).unwrap_err().status, Status::Permission);
    if let Some(b) = ss.get(1) {
        expect("other tenant uses my handle as a destination", b.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: 8 }).unwrap_err().status, Status::StaleHandle);
        expect("other tenant frees my buffer", b.free(dst).unwrap_err().status, Status::StaleHandle);
    }
    let t = a.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: 256 }).unwrap();
    expect("free the destination while the device is writing it", a.free(dst).unwrap_err().status, Status::Busy);
    expect("CPU write into a buffer the device is reading", a.write(src, 0, b"x").unwrap_err().status, Status::Busy);
    a.wait(t, w).unwrap();

    println!("\n-- hardware guard evidence (tenant driver bypassing the runtime, privileged raw queue)");
    let (in0, _out0) = m.tenant_windows(0).unwrap();
    let q0 = m.queue_of_tenant(0).unwrap();
    let writes_before = m.with_sim(|s| s.host_stats().writes).unwrap_or(0);
    let evil = Cmd { opcode: op::DMA_D2H, tenant: 0, tag: 0xE711, dst: in0.0 + 64, len: 64, ..Default::default() }; // dst in the READ-ONLY window
    m.raw_submit(q0, &evil).unwrap();
    let mut cpl = None;
    for _ in 0..5000 {
        m.raw_pump(64);
        if let Some(c) = m.raw_pop_completion(q0) {
            cpl = Some(c);
            break;
        }
    }
    let c = cpl.unwrap_or_else(|| fail("no completion for the hostile descriptor"));
    let writes_after = m.with_sim(|s| s.host_stats().writes).unwrap_or(0);
    println!("  device answered: status={} err=0x{:02x} ({}) ; host writes during the attempt: {}", c.status, c.err, proto::err::name(c.err), writes_after - writes_before);
    check(c.err == err::PERM_WRITE && writes_after == writes_before, "the device guard must refuse the write and move no byte");
    println!(
        "  tenant 0 is now {} (isolation violation -> quarantine); violation counter = {}",
        proto::tstate::name(m.mgmt_read(reg::tenant(0, reg::T_STATE)).unwrap() & 7),
        m.mgmt_read(reg::tenant(0, reg::T_VIOL_COUNT)).unwrap()
    );
    m.recover_tenant(0).unwrap();
    println!("  recovered (drain -> scrub -> re-enable)");
    a.free(src).unwrap();
    a.free(dst).unwrap();
    m.shutdown().unwrap();
    verdict(&info, "protected memory-copy accelerator");
}
