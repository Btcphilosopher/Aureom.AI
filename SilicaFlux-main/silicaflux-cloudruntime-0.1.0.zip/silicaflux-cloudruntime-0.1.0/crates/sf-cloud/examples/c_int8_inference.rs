//! Example C -- INT8 inference service (two-layer perceptron on the INT8 GEMM engine).
//!
//! REQUIRES a backend that implements GEMM.  The vendored RTL blocks its tensor engine (InferenceScheduler P66 and
//! TensorCore are not integrated into the CloudDPU), so on `rtl-sim` this example reports UNSUPPORTED and exits 3 --
//! it never fakes a result.  On `cpu-ref` the GEMM runs in software through the same runtime/mediator path.
mod common;
use common::*;
use sf_cloud::mediator::{alloc_flags as f, Op};
use sf_cloud::status::Status;
use std::time::{Duration, Instant};

fn gemm_ref(a: &[i8], b: &[i8], m: usize, n: usize, k: usize) -> Vec<i32> {
    let mut c = vec![0i32; m * n];
    for i in 0..m {
        for j in 0..n {
            c[i * n + j] = (0..k).map(|x| a[i * k + x] as i32 * b[x * n + j] as i32).sum();
        }
    }
    c
}
fn requant(v: &[i32], shift: u32) -> Vec<i8> {
    v.iter().map(|&x| ((x.max(0)) >> shift).min(127) as i8).collect() // ReLU + shift + saturate
}

fn main() {
    let (m, ss, info) = open(1);
    require(&info, "gemm_i8", info.backend.caps.gemm_i8);
    let s = &ss[0];
    let (batch, d_in, d_hid, d_out) = (8usize, 32usize, 16usize, 8usize);
    let mut rng = Rng(0xC0FFEE);
    let rnd8 = |rng: &mut Rng, n: usize| -> Vec<i8> { (0..n).map(|_| (rng.below(61) as i64 - 30) as i8).collect() };
    let (w1, w2) = (rnd8(&mut rng, d_in * d_hid), rnd8(&mut rng, d_hid * d_out));
    let as_u8 = |v: &[i8]| v.iter().map(|&x| x as u8).collect::<Vec<u8>>();
    // device-side weights live in read-only buffers
    let (hw1, hw2) = (s.alloc(w1.len() as u64, f::DEV_READ).unwrap(), s.alloc(w2.len() as u64, f::DEV_READ).unwrap());
    s.write(hw1, 0, &as_u8(&w1)).unwrap();
    s.write(hw2, 0, &as_u8(&w2)).unwrap();
    let (hx, hh, hy) = (
        s.alloc((batch * d_in) as u64, f::DEV_READ | f::DEV_WRITE).unwrap(),
        s.alloc((batch * d_hid * 4) as u64, f::DEV_WRITE).unwrap(),
        s.alloc((batch * d_out * 4) as u64, f::DEV_WRITE).unwrap(),
    );
    let hh8 = s.alloc((batch * d_hid) as u64, f::DEV_READ).unwrap();
    let w = Duration::from_secs(30);
    let (mut ok, n_req) = (0usize, 50usize);
    let t0 = Instant::now();
    for _ in 0..n_req {
        let x = rnd8(&mut rng, batch * d_in);
        // layer 1
        s.write(hx, 0, &as_u8(&x)).unwrap();
        let t = s.submit(&Op::GemmI8 { a: hx, a_off: 0, b: hw1, b_off: 0, c: hh, c_off: 0, m: batch as u32, n: d_hid as u32, k: d_in as u32 }).unwrap();
        let c = s.wait(t, w).unwrap();
        check(c.status == Status::Ok && c.committed, "layer 1");
        let mut raw = vec![0u8; batch * d_hid * 4];
        s.read(hh, 0, &mut raw).unwrap();
        let h32: Vec<i32> = raw.chunks(4).map(|b| i32::from_le_bytes(b.try_into().unwrap())).collect();
        let h8 = requant(&h32, 7); // activation + requantisation in software between engine calls
        s.write(hh8, 0, &as_u8(&h8)).unwrap();
        // layer 2
        let t = s.submit(&Op::GemmI8 { a: hh8, a_off: 0, b: hw2, b_off: 0, c: hy, c_off: 0, m: batch as u32, n: d_out as u32, k: d_hid as u32 }).unwrap();
        check(s.wait(t, w).unwrap().status == Status::Ok, "layer 2");
        let mut raw = vec![0u8; batch * d_out * 4];
        s.read(hy, 0, &mut raw).unwrap();
        let got: Vec<i32> = raw.chunks(4).map(|b| i32::from_le_bytes(b.try_into().unwrap())).collect();
        // independent software reference of the whole network
        let r1 = requant(&gemm_ref(&x, &w1, batch, d_hid, d_in), 7);
        let r2 = gemm_ref(&r1, &w2, batch, d_out, d_hid);
        check(got == r2, "logits differ from the software reference");
        ok += 1;
    }
    let el = t0.elapsed().as_secs_f64();
    println!("\n{ok}/{n_req} inference requests (batch {batch}, {d_in}->{d_hid}->{d_out}) bit-exact against the software reference");
    println!("wall clock of the software stack: {:.0} requests/s ({} -- not a hardware figure)", n_req as f64 / el, info.backend.name);
    m.shutdown().unwrap();
    verdict(&info, "INT8 inference service");
}
