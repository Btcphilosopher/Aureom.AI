//! Example A -- cloud packet-processing service.
//!
//! A batch of Ethernet-style frames goes through the device's PacketCore **test adapter**: each frame is copied
//! through device SRAM and the device reports the IEEE 802.3 CRC-32 (the Ethernet FCS algorithm) and the RFC 1071
//! Internet checksum of the frame.  A second pass byte-swaps each 32-bit word (a byte-order conversion service).
//! The adapter does NOT parse packets -- the real PacketCore (Project 62) is not integrated -- so this is a
//! frame-checksum offload service, not a packet classifier.  Every device result is checked against an
//! independent software computation.
mod common;
use common::*;
use sf_cloud::mediator::{alloc_flags as f, BufHandle, Op, Ticket};
use sf_cloud::proto;
use std::collections::VecDeque;
use std::time::{Duration, Instant};

const SIZES: [usize; 6] = [64, 128, 256, 512, 1024, 1500];

fn main() {
    let frames: usize = arg("--frames").and_then(|v| v.parse().ok()).unwrap_or(200);
    let (m, ss, info) = open(1);
    require(&info, "pkt_process", info.backend.caps.pkt_process);
    let s = &ss[0];
    println!("PacketCore block status: {}", info.blocks.iter().find(|b| b.0 == "packetcore").map(|b| b.1).unwrap_or("?"));

    // pre-build the traffic: 14-byte Ethernet header + IPv4-looking payload, deterministic
    let mut rng = Rng(0xA11CE);
    let traffic: Vec<Vec<u8>> = (0..frames)
        .map(|i| {
            let n = SIZES[i % SIZES.len()];
            let mut fr = rng.bytes(n);
            fr[12] = 0x08; // ethertype 0x0800
            fr[13] = 0x00;
            fr
        })
        .collect();

    // a ring of pre-allocated slots so many frames are in flight (pipelining)
    const DEPTH: usize = 12;
    let slots: Vec<(BufHandle, BufHandle)> = (0..DEPTH).map(|_| (s.alloc(1536, f::DEV_READ).unwrap(), s.alloc(1536, f::DEV_WRITE).unwrap())).collect();
    let mut inflight: VecDeque<(usize, usize, Ticket)> = VecDeque::new();
    let (mut bytes, mut verified, mut cycles_sum) = (0u64, 0usize, 0u64);
    let t0 = Instant::now();
    let finish = |idx: usize, slot: usize, t: Ticket, bytes: &mut u64, verified: &mut usize, cyc: &mut u64| {
        let c = s.wait(t, Duration::from_secs(60)).unwrap_or_else(|e| fail(&format!("frame {idx}: {e}")));
        let fr = &traffic[idx];
        check(c.status == sf_cloud::status::Status::Ok && c.committed, &format!("frame {idx}: {c:?}"));
        // the device-computed FCS equals the independent software CRC-32, the output equals the input
        check(c.crc_in == Some(proto::crc32(fr)) && c.crc_out == Some(proto::crc32(fr)) && c.csum == Some(proto::csum1071(fr)), &format!("frame {idx}: FCS/checksum mismatch"));
        let mut out = vec![0u8; fr.len()];
        s.read(slots[slot].1, 0, &mut out).unwrap();
        check(&out == fr, &format!("frame {idx}: copied bytes differ"));
        *bytes += fr.len() as u64;
        *verified += 1;
        *cyc += c.latency_cycles;
    };
    for (i, fr) in traffic.iter().enumerate() {
        if inflight.len() == DEPTH {
            let (idx, slot, t) = inflight.pop_front().unwrap();
            finish(idx, slot, t, &mut bytes, &mut verified, &mut cycles_sum);
        }
        let slot = i % DEPTH;
        s.write(slots[slot].0, 0, fr).unwrap();
        let t = s.submit(&Op::Copy { src: slots[slot].0, src_off: 0, dst: slots[slot].1, dst_off: 0, len: fr.len() as u64 }).unwrap_or_else(|e| fail(&e.to_string()));
        inflight.push_back((i, slot, t));
    }
    while let Some((idx, slot, t)) = inflight.pop_front() {
        finish(idx, slot, t, &mut bytes, &mut verified, &mut cycles_sum);
    }
    let el = t0.elapsed().as_secs_f64();
    println!("\nFCS/checksum offload: {verified}/{frames} frames verified, {bytes} bytes");
    println!("  wall clock (software stack, {}): {:.0} frames/s, {:.2} MB/s", info.backend.name, frames as f64 / el, bytes as f64 / el / 1e6);
    println!("  mean submit->completion latency: {:.0} device cycles ({})", cycles_sum as f64 / frames as f64, info.backend.timing.as_str());

    // byte-order conversion service on 4-byte-aligned frames
    let fr = &traffic[SIZES.len() - 1]; // 1500 bytes
    s.write(slots[0].0, 0, fr).unwrap();
    let t = s.submit(&Op::PktProcess { src: slots[0].0, src_off: 0, dst: slots[0].1, dst_off: 0, len: 1500, proc_op: proto::proc_op::BSWAP32, param: 0 }).unwrap();
    let c = s.wait(t, Duration::from_secs(60)).unwrap();
    let mut out = vec![0u8; 1500];
    s.read(slots[0].1, 0, &mut out).unwrap();
    check(c.status == sf_cloud::status::Status::Ok && out == proto::apply_proc(proto::proc_op::BSWAP32, 0, fr).unwrap(), "BSWAP32 conversion");
    println!("byte-order conversion (BSWAP32) of a 1500-byte frame: verified");
    // malformed requests fail explicitly
    let e = s.submit(&Op::PktProcess { src: slots[0].0, src_off: 0, dst: slots[0].1, dst_off: 0, len: 1499, proc_op: proto::proc_op::BSWAP32, param: 0 }).unwrap_err();
    println!("malformed request (BSWAP32 on 1499 bytes) -> {}", e.status.name());
    check(e.status == sf_cloud::status::Status::InvalidArg, "malformed request must be refused");
    for (a, b) in slots {
        s.free(a).unwrap();
        s.free(b).unwrap();
    }
    m.shutdown().unwrap();
    verdict(&info, "packet-processing service (frame FCS/checksum offload + byte-order conversion)");
}
