//! Example E -- cloud block-storage service.
//!
//! REQUIRES a backend that implements storage.  StorageFabric does not exist in the repository (StorageCore P51 /
//! NVMe HostCore P57 are separate, not integrated into the CloudDPU), so `rtl-sim` reports UNSUPPORTED (exit 3).  On
//! `cpu-ref` a RAM-backed block device with a PRIVATE namespace per tenant runs in software.
mod common;
use common::*;
use sf_cloud::mediator::{alloc_flags as f, Op};
use sf_cloud::proto;
use sf_cloud::status::Status;
use std::collections::HashMap;
use std::time::{Duration, Instant};

fn main() {
    let (m, ss, info) = open(2);
    require(&info, "storage", info.backend.caps.storage);
    let (a, w) = (&ss[0], Duration::from_secs(30));
    let mut rng = Rng(0xE5E5);
    let (hw, hr) = (a.alloc(512 * 8, f::DEV_READ).unwrap(), a.alloc(512 * 8, f::DEV_WRITE).unwrap());
    let mut shadow: HashMap<u64, Vec<u8>> = HashMap::new(); // what the volume must contain
    let (mut writes, mut reads, t0) = (0u32, 0u32, Instant::now());
    for _ in 0..1500 {
        let lba = rng.below(1000);
        let blocks = 1 + rng.below(4) as u32;
        if rng.below(100) < 40 {
            let data = rng.bytes(512 * blocks as usize);
            a.write(hw, 0, &data).unwrap();
            let t = a.submit(&Op::StorageWrite { src: hw, src_off: 0, lba, blocks }).unwrap();
            check(a.wait(t, w).unwrap().status == Status::Ok, "write");
            for b in 0..blocks as u64 {
                shadow.insert(lba + b, data[(b * 512) as usize..(b * 512 + 512) as usize].to_vec());
            }
            writes += 1;
        } else {
            let t = a.submit(&Op::StorageRead { dst: hr, dst_off: 0, lba, blocks }).unwrap();
            let c = a.wait(t, w).unwrap();
            check(c.status == Status::Ok && c.committed, "read");
            let mut out = vec![0u8; 512 * blocks as usize];
            a.read(hr, 0, &mut out).unwrap();
            for b in 0..blocks as u64 {
                let want = shadow.get(&(lba + b)).cloned().unwrap_or_else(|| vec![0u8; 512]);
                check(out[(b * 512) as usize..(b * 512 + 512) as usize] == want[..], &format!("read-your-writes violated at LBA {}", lba + b));
            }
            reads += 1;
        }
    }
    let el = t0.elapsed().as_secs_f64();
    println!("{writes} writes + {reads} reads, every read matched the shadow volume ({} blocks written)", shadow.len());
    println!("wall clock of the software stack: {:.0} IOPS ({} -- not a storage-hardware figure)", (writes + reads) as f64 / el, info.backend.name);
    // per-tenant namespaces
    if let Some(b) = ss.get(1) {
        let hb = b.alloc(512, f::DEV_WRITE).unwrap();
        let some_lba = *shadow.keys().next().unwrap();
        let t = b.submit(&Op::StorageRead { dst: hb, dst_off: 0, lba: some_lba, blocks: 1 }).unwrap();
        b.wait(t, w).unwrap();
        let mut o = vec![0xFFu8; 512];
        b.read(hb, 0, &mut o).unwrap();
        check(o.iter().all(|&x| x == 0), "tenant 1 must see an empty namespace");
        println!("tenant 1 reading LBA {some_lba} (written by tenant 0): all zeros -- namespaces are private");
    }
    // out-of-range LBAs are refused, none wraps
    for lba in [8192u64, u64::MAX] {
        let t = a.submit(&Op::StorageRead { dst: hr, dst_off: 0, lba, blocks: 1 }).unwrap();
        let c = a.wait(t, w).unwrap();
        println!("read LBA {lba:#x}: {}", c.status.name());
        check(c.status == Status::InvalidArg, "out-of-range LBA must be refused");
    }
    let _ = proto::op::STORAGE;
    m.shutdown().unwrap();
    verdict(&info, "cloud block-storage service");
}
