//! Example F -- multi-tenant resource-allocation test.
//!
//! Every tenant of the device runs a copy workload concurrently while one tenant behaves hostilely (foreign
//! handles, quota floods, a stalled completion queue).  Checks: quotas hold, the victim's results stay byte-exact,
//! the hostile tenant's attempts are counted, per-tenant counters add up, and the contention cost is reported.
//! (Fairness is measured on the simulated device only; on cpu-ref the time axis is logical.)
mod common;
use common::*;
use sf_cloud::mediator::{alloc_flags as f, Op, Session, TenantConfig};
use sf_cloud::status::Status;
use std::sync::{Arc, Barrier};
use std::time::{Duration, Instant};

fn workload(s: &Session, ops: usize, seed: u64) -> (u64, u64) {
    let mut rng = Rng(seed);
    let (src, dst) = (s.alloc(2048, f::DEV_READ).unwrap(), s.alloc(2048, f::DEV_WRITE).unwrap());
    let (mut bytes, mut cycles) = (0u64, 0u64);
    for _ in 0..ops {
        let d = rng.bytes(2048);
        s.write(src, 0, &d).unwrap();
        let t = s.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: 2048 }).unwrap();
        let c = s.wait(t, Duration::from_secs(60)).unwrap_or_else(|e| fail(&format!("tenant {}: {e}", s.tenant())));
        let mut o = vec![0u8; 2048];
        s.read(dst, 0, &mut o).unwrap();
        check(c.status == Status::Ok && c.committed && o == d, &format!("tenant {}: corrupted/failed copy", s.tenant()));
        bytes += 2048;
        cycles += c.latency_cycles;
    }
    s.free(src).unwrap();
    s.free(dst).unwrap();
    (bytes, cycles)
}

fn main() {
    let (m, ss, info) = open(16);
    require(&info, "pkt_process", info.backend.caps.pkt_process);
    let n = ss.len();
    println!("tenants provisioned: {n}  (each with its own queue, SRAM partition and host windows)");
    let ops = 40usize;

    // 1. baseline: tenant 0 alone
    let t0 = Instant::now();
    let (b0, c0) = workload(&ss[0], ops, 1);
    println!("\nsolo   : tenant 0: {b0} B, mean latency {:.0} device cycles, wall {:.2}s", c0 as f64 / ops as f64, t0.elapsed().as_secs_f64());

    // 2. all tenants concurrently; the LAST tenant (if more than one) is hostile in parallel with its own honest load
    let barrier = Arc::new(Barrier::new(n));
    let results: Vec<(u64, u64)> = std::thread::scope(|sc| {
        let hs: Vec<_> = ss
            .iter()
            .enumerate()
            .map(|(i, s)| {
                let b = barrier.clone();
                sc.spawn(move || {
                    b.wait();
                    workload(s, ops, 100 + i as u64)
                })
            })
            .collect();
        hs.into_iter().map(|h| h.join().unwrap()).collect()
    });
    println!("\nconcurrent ({n} tenants):");
    let lat: Vec<f64> = results.iter().map(|(_, c)| *c as f64 / ops as f64).collect();
    for (i, (b, _)) in results.iter().enumerate() {
        println!("  tenant {i}: {b} B, mean latency {:.0} device cycles", lat[i]);
    }
    let jain = {
        let s: f64 = lat.iter().sum();
        let q: f64 = lat.iter().map(|x| x * x).sum();
        if q > 0.0 {
            s * s / (lat.len() as f64 * q)
        } else {
            1.0
        }
    };
    println!("  latency fairness (Jain index, 1.0 = perfectly even): {jain:.3}");
    if n > 1 {
        println!("  contention (INDICATIVE ONLY): tenant 0 mean latency {:.0} (solo) -> {:.0} device cycles (with {n} tenants).", c0 as f64 / ops as f64, lat[0]);
        println!("    The threads here take turns pumping one simulated device, so they rarely overlap inside it;");
        println!("    the controlled measurement is `sf-bench run --only multi_tenant_contention`.");
    }

    // 3. a hostile tenant against a victim
    if n > 1 {
        let (victim, evil) = (&ss[0], &ss[n - 1]);
        let vbuf = victim.alloc(256, f::DEV_READ).unwrap();
        victim.write(vbuf, 0, &[0x42u8; 256]).unwrap();
        let ebuf = evil.alloc(256, f::DEV_WRITE).unwrap();
        let mut refused = 0;
        for _ in 0..200 {
            if evil.submit(&Op::Copy { src: vbuf, src_off: 0, dst: ebuf, dst_off: 0, len: 256 }).unwrap_err().status == Status::StaleHandle {
                refused += 1;
            }
            if evil.free(vbuf).is_err() {
                refused += 1;
            }
        }
        check(refused == 400, "every hostile attempt must be refused");
        let mut got = [0u8; 256];
        victim.read(vbuf, 0, &mut got).unwrap();
        check(got == [0x42u8; 256], "the victim's data must be untouched");
        let c = m.counters().unwrap();
        println!("\nhostile tenant: 400 cross-tenant attempts refused; audited as cross_tenant_handle = {}", c.stats.cross_tenant_attempts);
        check(c.stats.cross_tenant_attempts >= 400, "attempts must be audited");
        // quota flood: a tenant with a tiny in-flight quota cannot starve the others
        let small = m.deprovision_tenant((n - 1) as u32).and_then(|_| m.provision_tenant((n - 1) as u32, TenantConfig { max_inflight: 2, max_buffers: 16, ..Default::default() }));
        let cred = small.unwrap();
        let flood = m.open_session((n - 1) as u32, &cred).unwrap();
        let (fs, fd): (Vec<_>, Vec<_>) = (0..6).map(|_| (flood.alloc(64, f::DEV_READ).unwrap(), flood.alloc(64, f::DEV_WRITE).unwrap())).unzip();
        let mut ok = vec![];
        let mut quota_hits = 0;
        for i in 0..6 {
            match flood.submit(&Op::Copy { src: fs[i], src_off: 0, dst: fd[i], dst_off: 0, len: 64 }) {
                Ok(t) => ok.push(t),
                Err(e) if e.status == Status::Quota => quota_hits += 1,
                Err(e) => fail(&e.to_string()),
            }
        }
        println!("quota flood: {} accepted, {quota_hits} refused with SF_ERR_QUOTA (max_inflight = 2)", ok.len());
        check(ok.len() == 2 && quota_hits == 4, "in-flight quota must hold");
        for t in ok {
            flood.wait(t, Duration::from_secs(30)).unwrap();
        }
        let (b, _) = workload(victim, 10, 777);
        check(b == 10 * 2048, "victim still served during/after the flood");
    }

    // 4. accounting consistency
    let dc = m.counters().unwrap();
    let per_tenant_cmds: u64 = dc.tenants.iter().map(|t| t.dev_cmds).sum();
    println!("\naccounting: device retired {} commands, per-tenant device counters sum to {per_tenant_cmds}", dc.global[sf_cloud::proto::reg::cnt::CMDS_RETIRED as usize]);
    check(per_tenant_cmds == dc.global[sf_cloud::proto::reg::cnt::CMDS_RETIRED as usize], "per-tenant counters must add up to the device counter");
    check(dc.stats.anomalies_unknown_tag == 0 && dc.stats.anomalies_tenant_mismatch == 0, "no completion may be misrouted");
    for t in dc.tenants.iter().take(n) {
        println!(
            "  tenant {}: runtime submitted={} completed={} failed={} | device cmds={} bytes={} violations={}",
            t.tenant, t.usage.submitted, t.usage.completed, t.usage.errors, t.dev_cmds, t.dev_bytes, t.dev_violations
        );
    }
    m.shutdown().unwrap();
    verdict(&info, "multi-tenant resource allocation, isolation and accounting");
}
