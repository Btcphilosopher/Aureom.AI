//! Shared helpers for the example applications.
//!
//! Exit codes of every example:  0 = completed and verified   1 = a check failed   2 = setup error
//!                               3 = UNSUPPORTED on this backend (the backend cannot run this workload; nothing is emulated)
#![allow(dead_code)]
use sf_cloud::backend::{self, BackendSpec};
use sf_cloud::mediator::{DeviceInfo, Mediator, MediatorOptions, Session, TenantConfig};
use std::process::exit;

pub const EXIT_FAIL: i32 = 1;
pub const EXIT_SETUP: i32 = 2;
pub const EXIT_UNSUPPORTED: i32 = 3;

pub fn arg(name: &str) -> Option<String> {
    let a: Vec<String> = std::env::args().collect();
    a.iter().position(|x| x == name).and_then(|i| a.get(i + 1)).cloned()
}

pub fn open(tenants: u32) -> (Mediator, Vec<Session>, DeviceInfo) {
    let spec = arg("--backend").unwrap_or_else(|| "auto".into());
    let be = match BackendSpec::parse(&spec).and_then(|s| backend::open_backend(&s)) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("setup error: cannot open backend '{spec}': {e}");
            exit(EXIT_SETUP);
        }
    };
    let m = Mediator::open(be, MediatorOptions::default()).unwrap_or_else(|e| {
        eprintln!("setup error: {e}");
        exit(EXIT_SETUP)
    });
    let info = m.info();
    println!("backend: {} -- {}", info.backend.name, info.backend.description);
    println!("timing : {}   measured_on_hardware={}", info.backend.timing.as_str(), info.backend.measured_on_hardware);
    let n = tenants.min(info.geometry.tenants);
    let mut sessions = vec![];
    for t in 0..n {
        let cred = m.provision_tenant(t, TenantConfig { name: format!("tenant{t}"), ..Default::default() }).unwrap_or_else(|e| {
            eprintln!("setup error: provisioning tenant {t}: {e}");
            exit(EXIT_SETUP)
        });
        sessions.push(m.open_session(t, &cred).unwrap());
    }
    (m, sessions, info)
}

/// Print UNSUPPORTED and exit 3 if the backend lacks a capability.
pub fn require(info: &DeviceInfo, what: &str, have: bool) {
    if !have {
        println!("\nUNSUPPORTED: workload '{what}' cannot run on backend '{}': the device/backend does not implement it", info.backend.name);
        println!("(blocks: {})", info.blocks.iter().map(|(n, s)| format!("{n}={s}")).collect::<Vec<_>>().join(", "));
        println!("Nothing was emulated and nothing ran.  Use a backend that advertises '{what}' (see `sfctl info`).");
        exit(EXIT_UNSUPPORTED);
    }
}

pub fn fail(msg: &str) -> ! {
    println!("\nFAIL: {msg}");
    exit(EXIT_FAIL)
}

pub fn check(cond: bool, msg: &str) {
    if !cond {
        fail(msg);
    }
}

pub struct Rng(pub u64);
impl Rng {
    pub fn next(&mut self) -> u64 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0
    }
    pub fn below(&mut self, n: u64) -> u64 {
        self.next() % n.max(1)
    }
    pub fn bytes(&mut self, n: usize) -> Vec<u8> {
        (0..n).map(|_| (self.next() >> 24) as u8).collect()
    }
}

pub fn verdict(info: &DeviceInfo, what: &str) {
    println!(
        "\nRESULT: PASS  {what}  [backend={} measured_on_hardware={} -- simulation/model result, NOT a hardware result]",
        info.backend.name, info.backend.measured_on_hardware
    );
}
