//! Example D -- encrypted data-processing service (AES-GCM).
//!
//! REQUIRES a backend that implements AES-GCM.  The vendored RTL has no CryptoCore (its CRYPTO opcode completes with
//! ERR_BLOCKED), so `rtl-sim` reports UNSUPPORTED and exits 3.  On `cpu-ref` the cipher runs in software (RustCrypto
//! `aes-gcm`), validated against the published GCM test vectors in `tests/extensions.rs`.  Keys live in process
//! memory: there is no HSM and no key hierarchy -- this is a functional service, not a hardened key-management one.
mod common;
use common::*;
use sf_cloud::mediator::{alloc_flags as f, Op};
use sf_cloud::status::Status;
use std::time::Duration;

fn main() {
    let (m, ss, info) = open(2);
    require(&info, "aes_gcm", info.backend.caps.aes_gcm);
    let a = &ss[0];
    let w = Duration::from_secs(30);
    let mut rng = Rng(0xD0D0);
    let key = rng.bytes(32);
    let k = a.load_key(&key).unwrap();
    let records: Vec<Vec<u8>> = (0..64)
        .map(|_| {
            let n = 16 + rng.below(1400) as usize;
            rng.bytes(n)
        })
        .collect();
    let aad = b"record-store-v1";
    let (hp, hc, ht, hd) = (a.alloc(2048, f::DEV_READ).unwrap(), a.alloc(2048, f::DEV_WRITE).unwrap(), a.alloc(16, f::DEV_WRITE).unwrap(), a.alloc(2048, f::DEV_WRITE).unwrap());
    let htr = a.alloc(16, f::DEV_READ).unwrap();
    let hcr = a.alloc(2048, f::DEV_READ).unwrap();
    let mut store: Vec<(Vec<u8>, Vec<u8>, [u8; 12])> = vec![]; // (ciphertext, tag, iv): what an untrusted store would hold
    for (i, rec) in records.iter().enumerate() {
        let mut iv = [0u8; 12];
        iv[4..].copy_from_slice(&(i as u64).to_be_bytes()); // unique per record under this key
        a.write(hp, 0, rec).unwrap();
        let t =
            a.submit(&Op::AesGcm { key: k, encrypt: true, iv, aad: aad.to_vec(), src: hp, src_off: 0, dst: hc, dst_off: 0, tag: ht, tag_off: 0, len: rec.len() as u32 }).unwrap();
        check(a.wait(t, w).unwrap().status == Status::Ok, "encrypt");
        let (mut ct, mut tag) = (vec![0u8; rec.len()], vec![0u8; 16]);
        a.read(hc, 0, &mut ct).unwrap();
        a.read(ht, 0, &mut tag).unwrap();
        check(&ct != rec, "ciphertext must differ from the plaintext");
        store.push((ct, tag, iv));
    }
    println!("encrypted {} records (unique IVs, AAD bound)", store.len());
    let decrypt = |ct: &[u8], tag: &[u8], iv: [u8; 12], aad: &[u8]| {
        a.write(hd, 0, &[0u8; 2048]).unwrap(); // known-clean destination: anything non-zero afterwards was written by the device
        a.write(hcr, 0, ct).unwrap();
        a.write(htr, 0, tag).unwrap();
        let t =
            a.submit(&Op::AesGcm { key: k, encrypt: false, iv, aad: aad.to_vec(), src: hcr, src_off: 0, dst: hd, dst_off: 0, tag: htr, tag_off: 0, len: ct.len() as u32 }).unwrap();
        let c = a.wait(t, w).unwrap();
        let mut out = vec![0xAAu8; ct.len()];
        a.read(hd, 0, &mut out).unwrap();
        (c, out)
    };
    for (i, (ct, tag, iv)) in store.iter().enumerate() {
        let (c, pt) = decrypt(ct, tag, *iv, aad);
        check(c.status == Status::Ok && pt == records[i], &format!("record {i} round trip"));
    }
    println!("decrypted and verified all {} records", store.len());
    // the untrusted store is tampered with: every manipulation must be detected and release NO plaintext
    let mut detected = 0;
    for i in [0usize, 7, 31, 63] {
        let (ct, tag, iv) = &store[i];
        let mut bad_ct = ct.clone();
        bad_ct[ct.len() / 2] ^= 0x01;
        let mut bad_tag = tag.clone();
        bad_tag[0] ^= 0x01;
        let mut other_iv = *iv;
        other_iv[11] ^= 1;
        for (label, c_, t_, iv_, aad_) in [
            ("bit flip in ciphertext", &bad_ct, tag, *iv, &aad[..]),
            ("bit flip in tag", ct, &bad_tag, *iv, &aad[..]),
            ("wrong IV", ct, tag, other_iv, &aad[..]),
            ("wrong AAD", ct, tag, *iv, b"record-store-v2".as_slice()),
        ] {
            let (c, out) = decrypt(c_, t_, iv_, aad_);
            check(
                c.status == Status::CryptoAuth && !c.committed && out.iter().all(|&b| b == 0),
                &format!("record {i}: {label} must be rejected with no plaintext released (got {:?})", c.status),
            );
            detected += 1;
        }
    }
    println!("{detected}/{detected} tampering attempts detected; no plaintext was released");
    // tenant isolation of keys
    if let Some(b) = ss.get(1) {
        let (bp, bc, bt) = (b.alloc(64, f::DEV_READ).unwrap(), b.alloc(64, f::DEV_WRITE).unwrap(), b.alloc(16, f::DEV_WRITE).unwrap());
        let e = b.submit(&Op::AesGcm { key: k, encrypt: true, iv: [0; 12], aad: vec![], src: bp, src_off: 0, dst: bc, dst_off: 0, tag: bt, tag_off: 0, len: 64 }).unwrap_err();
        println!("tenant 1 using tenant 0's key handle -> {}", e.status.name());
        check(e.status == Status::StaleHandle, "foreign key handle must be refused");
    }
    a.unload_key(k).unwrap();
    let rep = m.shutdown().unwrap();
    println!("shutdown: {} key(s) still loaded were wiped", rep.keys_wiped);
    verdict(&info, "encrypted data-processing service (AES-256-GCM)");
}
