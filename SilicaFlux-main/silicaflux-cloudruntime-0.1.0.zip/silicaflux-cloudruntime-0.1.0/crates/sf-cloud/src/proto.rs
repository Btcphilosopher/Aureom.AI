//! Wire-level ABI of the SilicaFlux CloudDPU (Project 61), as seen by software.
//!
//! Every constant here is a transcription of `rtl/vendor/clouddpu-p61/rtl/pkg/silicaflux_cloud_pkg.sv` and
//! `silicaflux_cloud_memmap_pkg.sv`.  `tests/abi_crosscheck.rs` parses those SystemVerilog files and fails if
//! any value drifts, so this file cannot silently disagree with the RTL it drives.

// ------------------------------------------------------------------------------------------ identification
pub const DPU_ID_MAGIC: u32 = 0x5346_4450; // "SFDP"
pub const DPU_ABI_MAJOR: u32 = 1;
pub const DPU_ABI_MINOR: u32 = 0;

pub const CMD_WORDS: usize = 12;
pub const CPL_WORDS: usize = 8;

// ------------------------------------------------------------------------------------------ opcodes
pub mod op {
    pub const NOP: u8 = 0x00;
    pub const PKT_PROCESS: u8 = 0x01;
    pub const DMA_H2D: u8 = 0x02;
    pub const DMA_D2H: u8 = 0x03;
    pub const INFER: u8 = 0x10;
    pub const CRYPTO: u8 = 0x11;
    pub const STORAGE: u8 = 0x12;

    pub fn is_net(o: u8) -> bool {
        o == PKT_PROCESS || o == DMA_H2D || o == DMA_D2H
    }
    pub fn is_eng(o: u8) -> bool {
        o == INFER || o == CRYPTO || o == STORAGE
    }
    pub fn reads_host(o: u8) -> bool {
        o == PKT_PROCESS || o == DMA_H2D
    }
    pub fn writes_host(o: u8) -> bool {
        o == PKT_PROCESS || o == DMA_D2H
    }
}

/// PacketCore TEST ADAPTER operations (none of these is cryptography; see docs).
pub mod proc_op {
    pub const PASS: u8 = 0x00;
    pub const XOR32: u8 = 0x01;
    pub const BSWAP32: u8 = 0x02;
}

pub mod status {
    pub const OK: u8 = 0;
    pub const ERROR: u8 = 1;
    pub const ABORTED: u8 = 2;
}

pub mod err {
    pub const NONE: u8 = 0x00;
    pub const BAD_OPCODE: u8 = 0x01;
    pub const BAD_DESC: u8 = 0x02;
    pub const BAD_LENGTH: u8 = 0x03;
    pub const ALIGN: u8 = 0x04;
    pub const TENANT_STATE: u8 = 0x05;
    pub const QUARANTINED: u8 = 0x06;
    pub const BLOCKED: u8 = 0x07;
    pub const BAD_TENANT: u8 = 0x08;
    pub const PROC_OP: u8 = 0x09;
    pub const TENANT_MISMATCH: u8 = 0x10;
    pub const PERM_READ: u8 = 0x11;
    pub const PERM_WRITE: u8 = 0x12;
    pub const SRAM_RANGE: u8 = 0x13;
    pub const PERM_BEAT: u8 = 0x14;
    pub const HOST_MEM: u8 = 0x20;
    pub const SRAM_RESP: u8 = 0x21;
    pub const TIMEOUT: u8 = 0x22;
    pub const RESET_ABORT: u8 = 0x23;
    pub const INTERNAL: u8 = 0x24;

    pub fn is_violation(e: u8) -> bool {
        (0x10..=0x14).contains(&e)
    }
    pub fn name(e: u8) -> &'static str {
        match e {
            NONE => "NONE",
            BAD_OPCODE => "BAD_OPCODE",
            BAD_DESC => "BAD_DESC",
            BAD_LENGTH => "BAD_LENGTH",
            ALIGN => "ALIGN",
            TENANT_STATE => "TENANT_STATE",
            QUARANTINED => "QUARANTINED",
            BLOCKED => "BLOCKED",
            BAD_TENANT => "BAD_TENANT",
            PROC_OP => "PROC_OP",
            TENANT_MISMATCH => "TENANT_MISMATCH",
            PERM_READ => "PERM_READ",
            PERM_WRITE => "PERM_WRITE",
            SRAM_RANGE => "SRAM_RANGE",
            PERM_BEAT => "PERM_BEAT",
            HOST_MEM => "HOST_MEM",
            SRAM_RESP => "SRAM_RESP",
            TIMEOUT => "TIMEOUT",
            RESET_ABORT => "RESET_ABORT",
            INTERNAL => "INTERNAL",
            _ => "UNKNOWN",
        }
    }
}

pub mod tstate {
    pub const DISABLED: u32 = 0;
    pub const ACTIVE: u32 = 1;
    pub const DRAINING: u32 = 2;
    pub const SCRUBBING: u32 = 3;
    pub const QUARANTINED: u32 = 4;
    pub fn name(s: u32) -> &'static str {
        match s {
            DISABLED => "disabled",
            ACTIVE => "active",
            DRAINING => "draining",
            SCRUBBING => "scrubbing",
            QUARANTINED => "quarantined",
            _ => "unknown",
        }
    }
}

pub mod tcmd {
    pub const COMMIT: u32 = 1;
    pub const ENABLE: u32 = 2;
    pub const DISABLE: u32 = 3;
    pub const RECOVER: u32 = 4;
    pub const RELEASE: u32 = 5;
}

pub mod cfg {
    pub const NONE: u32 = 0x00;
    pub const OK: u32 = 0x01;
    pub const BUSY: u32 = 0x10;
    pub const BAD_PART: u32 = 0x11;
    pub const BAD_WINDOW: u32 = 0x12;
    pub const OVERLAP_SRAM: u32 = 0x13;
    pub const OVERLAP_HOST: u32 = 0x14;
    pub const NO_TENANT: u32 = 0x15;
    pub const SCRUB_FAIL: u32 = 0x16;
}

pub mod flt {
    pub const PERM_VIOL: u32 = 0;
    pub const HOST_ERR: u32 = 1;
    pub const DESC_ERR: u32 = 2;
    pub const TIMEOUT: u32 = 3;
    pub const SRAM_ERR: u32 = 4;
    pub const INTERNAL: u32 = 5;
    pub const RESET_DONE: u32 = 6;
    pub const TLM_DROP: u32 = 7;
    pub const NAMES: [&str; 8] = ["perm_viol", "host_err", "desc_err", "timeout", "sram_err", "internal", "reset_done", "tlm_drop"];
}

/// Block status codes (BLOCK_STATUS, 2 bits per block).
pub mod blk {
    pub const ABSENT: u32 = 0;
    pub const BLOCKED: u32 = 1;
    pub const TEST_ADAPTER: u32 = 2;
    pub const REAL: u32 = 3;
    pub fn name(s: u32) -> &'static str {
        match s & 3 {
            ABSENT => "absent",
            BLOCKED => "blocked",
            TEST_ADAPTER => "test-adapter",
            _ => "real",
        }
    }
}

pub mod tlm {
    pub const CMD_RETIRE: u8 = 0x01;
    pub const VIOLATION: u8 = 0x02;
    pub const TENANT_STATE: u8 = 0x03;
    pub const FAULT: u8 = 0x04;
    pub const DP_RESET: u8 = 0x05;
    pub fn name(e: u8) -> &'static str {
        match e {
            CMD_RETIRE => "cmd_retire",
            VIOLATION => "violation",
            TENANT_STATE => "tenant_state",
            FAULT => "fault",
            DP_RESET => "dp_reset",
            _ => "unknown",
        }
    }
}

pub const MGMT_QUEUE_ID: u32 = 15;
pub const SRAM_PAGE_BYTES: u32 = 256;

// ------------------------------------------------------------------------------------------ register map
#[allow(clippy::identity_op)] // `PAGE + 0x000` is deliberate: every register is written as page + offset, offsets line up
pub mod reg {
    pub const PERIPH_BASE: u32 = 0x4000_0000;
    pub const GLOBAL: u32 = 0x4000_8000;
    pub const TENANT: u32 = 0x4000_9000;
    pub const QUEUE: u32 = 0x4000_A000;
    pub const MGMT_CQ: u32 = 0x4000_B000;
    pub const PERF: u32 = 0x4000_C000;
    pub const TELEMETRY: u32 = 0x4000_D000;
    pub const ENGINES: u32 = 0x4000_E000;
    pub const DEBUG: u32 = 0x4000_F000;

    // GLOBAL
    pub const G_ID: u32 = GLOBAL;
    pub const G_VERSION: u32 = GLOBAL + 0x004;
    pub const G_CONFIG0: u32 = GLOBAL + 0x008;
    pub const G_CONFIG1: u32 = GLOBAL + 0x00C;
    pub const G_SRAM_BYTES: u32 = GLOBAL + 0x010;
    pub const G_MAX_XFER: u32 = GLOBAL + 0x014;
    pub const G_BLOCK_STATUS: u32 = GLOBAL + 0x018;
    pub const G_FEATURES: u32 = GLOBAL + 0x01C;
    pub const G_CTRL: u32 = GLOBAL + 0x020;
    pub const G_STATUS: u32 = GLOBAL + 0x024;
    pub const G_FAULT_STATUS: u32 = GLOBAL + 0x030;
    pub const G_FAULT_ENABLE: u32 = GLOBAL + 0x034;
    pub const G_FAULT_TENANT: u32 = GLOBAL + 0x040;
    pub const G_FAULT_ERR: u32 = GLOBAL + 0x044;
    pub const G_FAULT_ADDR_LO: u32 = GLOBAL + 0x048;
    pub const G_FAULT_ADDR_HI: u32 = GLOBAL + 0x04C;
    pub const G_JOB_TIMEOUT: u32 = GLOBAL + 0x050;
    pub const G_TIME_LO: u32 = GLOBAL + 0x054;
    pub const G_TIME_HI: u32 = GLOBAL + 0x058;
    pub const G_SCRATCH: u32 = GLOBAL + 0x060;
    pub const G_DP_RESETS: u32 = GLOBAL + 0x064;

    pub const CTRL_EN: u32 = 1 << 0;
    pub const CTRL_DP_RESET: u32 = 1 << 1;
    pub const STATUS_BUSY: u32 = 1 << 0;
    pub const STATUS_HALTED: u32 = 1 << 1;
    pub const STATUS_RESETTING: u32 = 1 << 2;
    pub const STATUS_SCRUB: u32 = 1 << 3;

    // TENANT (array of 16, stride 0x100)
    pub const T_STRIDE: u32 = 0x100;
    pub const T_STATE: u32 = 0x000;
    pub const T_CMD: u32 = 0x004;
    pub const T_CFG_STATUS: u32 = 0x008;
    pub const T_SRAM_BASE: u32 = 0x00C;
    pub const T_SRAM_SIZE: u32 = 0x010;
    pub const T_POLICY: u32 = 0x014;
    pub const T_VIOL_COUNT: u32 = 0x018;
    pub const T_WIN0: u32 = 0x020;
    pub const T_WIN_STRIDE: u32 = 0x010;
    pub fn tenant(t: u32, off: u32) -> u32 {
        TENANT + T_STRIDE * t + off
    }
    pub fn win(t: u32, w: u32, field: u32) -> u32 {
        tenant(t, T_WIN0 + T_WIN_STRIDE * w + field)
    }
    pub const WIN_BASE_LO: u32 = 0;
    pub const WIN_BASE_HI: u32 = 4;
    pub const WIN_SIZE: u32 = 8;
    pub const WIN_CTRL: u32 = 12;
    pub const WIN_VALID: u32 = 1;
    pub const WIN_R: u32 = 2;
    pub const WIN_W: u32 = 4;

    // QUEUE (array of 16, stride 0x20)
    pub const Q_STRIDE: u32 = 0x20;
    pub const Q_BIND: u32 = 0x000;
    pub const Q_STATUS: u32 = 0x004;
    pub const Q_SUBMITTED: u32 = 0x008;
    pub const Q_COMPLETED: u32 = 0x00C;
    pub const Q_REJECTED: u32 = 0x010;
    pub fn queue(q: u32, off: u32) -> u32 {
        QUEUE + Q_STRIDE * q + off
    }

    // PERF
    pub const P_CTRL: u32 = PERF;
    pub const P_INFO: u32 = PERF + 0x004;
    pub const P_CNT0: u32 = PERF + 0x010;
    pub fn perf_global(k: u32) -> u32 {
        P_CNT0 + 8 * k
    }
    pub fn perf_tenant(t: u32, off: u32) -> u32 {
        PERF + 0x400 + 0x20 * t + off
    }
    pub const PERF_FREEZE: u32 = 1;
    pub const PERF_CLEAR: u32 = 2;
    /// global counter indices
    pub mod cnt {
        pub const CMDS_ACCEPTED: u32 = 0;
        pub const CMDS_RETIRED: u32 = 1;
        pub const CMDS_ERROR: u32 = 2;
        pub const DMA_BYTES_RD: u32 = 3;
        pub const DMA_BYTES_WR: u32 = 4;
        pub const ACTIVE_CYCLES: u32 = 5;
        pub const STALL_DISPATCH: u32 = 6;
        pub const STALL_FABRIC: u32 = 7;
        pub const STALL_HOST: u32 = 8;
        pub const STALL_ANY: u32 = 9;
        pub const MEM_CONFLICTS: u32 = 10;
        pub const ERR_EVENTS: u32 = 11;
        pub const VIOLATIONS: u32 = 12;
        pub const HOST_ERRORS: u32 = 13;
        pub const TIMEOUTS: u32 = 14;
        pub const CYCLES: u32 = 15;
        pub const N: usize = 16;
        pub const NAMES: [&str; 16] = [
            "cmds_accepted",
            "cmds_retired",
            "cmds_error",
            "dma_bytes_rd",
            "dma_bytes_wr",
            "active_cycles",
            "stall_dispatch",
            "stall_fabric",
            "stall_host",
            "stall_any",
            "mem_conflicts",
            "err_events",
            "violations",
            "host_errors",
            "timeouts",
            "cycles",
        ];
    }

    // TELEMETRY
    pub const L_CTRL: u32 = TELEMETRY;
    pub const L_LEVEL: u32 = TELEMETRY + 0x004;
    pub const L_DROPPED: u32 = TELEMETRY + 0x008;
    pub const L_EMITTED: u32 = TELEMETRY + 0x00C;

    // ENGINES
    pub const E_INFER: u32 = ENGINES;
    pub const E_CRYPTO: u32 = ENGINES + 0x004;
    pub const E_STORAGE: u32 = ENGINES + 0x008;
    pub const E_BLOCKED_REJECTS: u32 = ENGINES + 0x010;
    pub const E_PKT_JOBS: u32 = ENGINES + 0x014;
}

// ------------------------------------------------------------------------------------------ descriptors
/// Submission descriptor (host view), 12 little-endian words.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Cmd {
    pub opcode: u8,
    pub flags: u8,
    pub tenant: u8,
    pub tag: u32,
    pub src: u64,
    pub dst: u64,
    pub len: u32,
    pub sram_off: u32,
    pub proc_op: u8,
    pub param: u32,
    /// Reserved words that MUST be zero; exposed only so negative tests can violate the rule.
    pub rsvd_w0: u16,
    pub rsvd_w8: u32,
    pub rsvd_w10_11: u64,
}

impl Cmd {
    pub fn encode(&self) -> [u32; CMD_WORDS] {
        let mut w = [0u32; CMD_WORDS];
        w[0] = self.opcode as u32 | (self.flags as u32) << 8 | ((self.tenant as u32) & 0xF) << 16 | ((self.rsvd_w0 as u32) & 0xFFF) << 20;
        w[1] = self.tag;
        w[2] = self.src as u32;
        w[3] = (self.src >> 32) as u32;
        w[4] = self.dst as u32;
        w[5] = (self.dst >> 32) as u32;
        w[6] = self.len;
        w[7] = self.sram_off;
        w[8] = self.proc_op as u32 | (self.rsvd_w8 & 0x00FF_FFFF) << 8;
        w[9] = self.param;
        w[10] = self.rsvd_w10_11 as u32;
        w[11] = (self.rsvd_w10_11 >> 32) as u32;
        w
    }
    pub fn decode(w: &[u32; CMD_WORDS]) -> Cmd {
        Cmd {
            opcode: w[0] as u8,
            flags: (w[0] >> 8) as u8,
            tenant: ((w[0] >> 16) & 0xF) as u8,
            rsvd_w0: ((w[0] >> 20) & 0xFFF) as u16,
            tag: w[1],
            src: w[2] as u64 | (w[3] as u64) << 32,
            dst: w[4] as u64 | (w[5] as u64) << 32,
            len: w[6],
            sram_off: w[7],
            proc_op: w[8] as u8,
            rsvd_w8: w[8] >> 8,
            param: w[9],
            rsvd_w10_11: w[10] as u64 | (w[11] as u64) << 32,
        }
    }
}

/// Completion record (host view), 8 little-endian words.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Cpl {
    pub opcode: u8,
    pub status: u8,
    pub err: u8,
    pub tenant: u8,
    pub queue: u8,
    pub tag: u32,
    pub txn: u16,
    pub flags: u16,
    pub bytes: u32,
    pub crc_in: u32,
    pub crc_out: u32,
    pub csum: u16,
    pub ts: u32,
}

pub const CPL_FLAG_COMMITTED: u16 = 1;

impl Cpl {
    pub fn decode(w: &[u32; CPL_WORDS]) -> Cpl {
        Cpl {
            opcode: w[0] as u8,
            status: (w[0] >> 8) as u8,
            err: (w[0] >> 16) as u8,
            tenant: ((w[0] >> 24) & 0xF) as u8,
            queue: (w[0] >> 28) as u8,
            tag: w[1],
            txn: w[2] as u16,
            flags: (w[2] >> 16) as u16,
            bytes: w[3],
            crc_in: w[4],
            crc_out: w[5],
            csum: w[6] as u16,
            ts: w[7],
        }
    }
    pub fn encode(&self) -> [u32; CPL_WORDS] {
        [
            self.opcode as u32 | (self.status as u32) << 8 | (self.err as u32) << 16 | ((self.tenant as u32) & 0xF) << 24 | (self.queue as u32) << 28,
            self.tag,
            self.txn as u32 | (self.flags as u32) << 16,
            self.bytes,
            self.crc_in,
            self.crc_out,
            self.csum as u32,
            self.ts,
        ]
    }
    pub fn committed(&self) -> bool {
        self.flags & CPL_FLAG_COMMITTED != 0
    }
}

/// One CloudTelemetry record: `{ts[31:0], arg[31:0], event[7:0], queue[3:0], tenant[3:0]}` (80 bit).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct TlmEvent {
    pub ts: u32,
    pub arg: u32,
    pub event: u8,
    pub queue: u8,
    pub tenant: u8,
}

impl TlmEvent {
    /// `w` = {bits 31:0, bits 63:32, bits 79:64}.
    pub fn decode(w: [u32; 3]) -> TlmEvent {
        TlmEvent {
            tenant: (w[0] & 0xF) as u8,
            queue: ((w[0] >> 4) & 0xF) as u8,
            event: ((w[0] >> 8) & 0xFF) as u8,
            arg: ((w[1] & 0xFFFF) << 16) | (w[0] >> 16),
            ts: ((w[2] & 0xFFFF) << 16) | (w[1] >> 16),
        }
    }
}

// ------------------------------------------------------------------------------------------ reference functions
const fn crc_table() -> [u32; 256] {
    let mut t = [0u32; 256];
    let mut i = 0;
    while i < 256 {
        let mut c = i as u32;
        let mut k = 0;
        while k < 8 {
            c = if c & 1 != 0 { (c >> 1) ^ 0xEDB8_8320 } else { c >> 1 };
            k += 1;
        }
        t[i] = c;
        i += 1;
    }
    t
}
static CRC_T: [u32; 256] = crc_table();

/// CRC-32 (IEEE 802.3), the value the DPU reports in `crc_in` / `crc_out`.
pub fn crc32(data: &[u8]) -> u32 {
    let mut c = 0xFFFF_FFFFu32;
    for &b in data {
        c = CRC_T[((c ^ b as u32) & 0xFF) as usize] ^ (c >> 8);
    }
    !c
}

fn gf2_times(mat: &[u32; 32], mut v: u32) -> u32 {
    let mut sum = 0;
    let mut i = 0;
    while v != 0 {
        if v & 1 != 0 {
            sum ^= mat[i];
        }
        v >>= 1;
        i += 1;
    }
    sum
}
fn gf2_square(sq: &mut [u32; 32], mat: &[u32; 32]) {
    for n in 0..32 {
        sq[n] = gf2_times(mat, mat[n]);
    }
}

/// CRC of the concatenation A||B from crc(A), crc(B) and len(B) (zlib `crc32_combine`).
pub fn crc32_combine(mut crc1: u32, crc2: u32, mut len2: u64) -> u32 {
    if len2 == 0 {
        return crc1;
    }
    let mut even = [0u32; 32];
    let mut odd = [0u32; 32];
    odd[0] = 0xEDB8_8320;
    let mut row = 1u32;
    for n in 1..32 {
        odd[n] = row;
        row <<= 1;
    }
    gf2_square(&mut even, &odd);
    gf2_square(&mut odd, &even);
    loop {
        gf2_square(&mut even, &odd);
        if len2 & 1 != 0 {
            crc1 = gf2_times(&even, crc1);
        }
        len2 >>= 1;
        if len2 == 0 {
            break;
        }
        gf2_square(&mut odd, &even);
        if len2 & 1 != 0 {
            crc1 = gf2_times(&odd, crc1);
        }
        len2 >>= 1;
        if len2 == 0 {
            break;
        }
    }
    crc1 ^ crc2
}

/// RFC 1071 internet checksum (network byte order, odd tail zero padded), as reported in `csum`.
pub fn csum1071(data: &[u8]) -> u16 {
    !fold(sum1071(data))
}
/// Unfolded ones-complement partial sum of a chunk (chunk offset must be even to combine).
pub fn sum1071(data: &[u8]) -> u32 {
    let mut s: u64 = 0;
    let mut i = 0;
    while i < data.len() {
        let hi = data[i] as u64;
        let lo = if i + 1 < data.len() { data[i + 1] as u64 } else { 0 };
        s += hi << 8 | lo;
        i += 2;
    }
    while s >> 32 != 0 {
        s = (s & 0xFFFF_FFFF) + (s >> 32);
    }
    s as u32
}
pub fn fold(mut s: u32) -> u16 {
    while s >> 16 != 0 {
        s = (s & 0xFFFF) + (s >> 16);
    }
    s as u16
}
/// Combine two partial RFC 1071 checksums (as returned by `csum1071`) of consecutive chunks; the first
/// chunk must have even length.
pub fn csum_combine(a: u16, b: u16) -> u16 {
    let s = (!a) as u32 + (!b) as u32;
    !fold(s)
}

/// Apply a PacketCore test-adapter operation.  `None` if the op/length combination is illegal.
pub fn apply_proc(op: u8, param: u32, input: &[u8]) -> Option<Vec<u8>> {
    match op {
        proc_op::PASS => Some(input.to_vec()),
        proc_op::XOR32 => {
            let k = param.to_le_bytes();
            Some(input.iter().enumerate().map(|(i, b)| b ^ k[i % 4]).collect())
        }
        proc_op::BSWAP32 => {
            if input.len() % 4 != 0 {
                return None;
            }
            let mut o = Vec::with_capacity(input.len());
            for c in input.chunks(4) {
                o.extend_from_slice(&[c[3], c[2], c[1], c[0]]);
            }
            Some(o)
        }
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn crc_check_value() {
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926);
    }
    #[test]
    fn crc_combine_matches_direct() {
        let data: Vec<u8> = (0..10_000u32).map(|i| (i * 31 + 7) as u8).collect();
        for split in [1usize, 3, 4096, 4097, 9999] {
            let (a, b) = data.split_at(split);
            assert_eq!(crc32_combine(crc32(a), crc32(b), b.len() as u64), crc32(&data), "split {split}");
        }
    }
    #[test]
    fn rfc1071_example() {
        // RFC 1071 section 3: the sample words 0x0001 0xf203 0xf4f5 0xf6f7 sum to 0xddf2; checksum = ~0xddf2 = 0x220d
        assert_eq!(csum1071(&[0x00, 0x01, 0xf2, 0x03, 0xf4, 0xf5, 0xf6, 0xf7]), 0x220d);
    }
    #[test]
    fn csum_combine_matches_direct() {
        let d: Vec<u8> = (0..4096u32 + 100).map(|i| (i * 13 + 5) as u8).collect();
        let (a, b) = d.split_at(4096);
        assert_eq!(csum_combine(csum1071(a), csum1071(b)), csum1071(&d));
    }
    #[test]
    fn cmd_roundtrip() {
        let c = Cmd {
            opcode: 1,
            flags: 1,
            tenant: 3,
            tag: 0xDEAD_BEEF,
            src: 0x1_0000_0040,
            dst: 0x2_0000_0080,
            len: 4096,
            sram_off: 256,
            proc_op: 2,
            param: 0xA5A5_5A5A,
            ..Default::default()
        };
        assert_eq!(Cmd::decode(&c.encode()), c);
    }
    #[test]
    fn cpl_roundtrip() {
        let c = Cpl { opcode: 1, status: 1, err: 0x12, tenant: 2, queue: 5, tag: 9, txn: 77, flags: 1, bytes: 64, crc_in: 1, crc_out: 2, csum: 3, ts: 4 };
        assert_eq!(Cpl::decode(&c.encode()), c);
    }
    #[test]
    fn tlm_decode_layout() {
        // record {ts=0x11223344, arg=0x55667788, event=0x02, queue=0x3, tenant=0x1}
        let w0 = (0x7788u32 << 16) | (0x02 << 8) | (0x3 << 4) | 0x1;
        let w1 = (0x3344u32 << 16) | 0x5566;
        let w2 = 0x1122;
        assert_eq!(TlmEvent::decode([w0, w1, w2]), TlmEvent { ts: 0x1122_3344, arg: 0x5566_7788, event: 2, queue: 3, tenant: 1 });
    }
    #[test]
    fn proc_ops() {
        assert_eq!(apply_proc(proc_op::XOR32, 0x0403_0201, &[0, 0, 0, 0, 0xFF]).unwrap(), vec![1, 2, 3, 4, 0xFE]);
        assert_eq!(apply_proc(proc_op::BSWAP32, 0, &[1, 2, 3, 4]).unwrap(), vec![4, 3, 2, 1]);
        assert!(apply_proc(proc_op::BSWAP32, 0, &[1, 2, 3]).is_none());
        assert!(apply_proc(0x7F, 0, &[1]).is_none());
    }
}
