//! Container integration helpers shared by the device plugin and the CLI.
//!
//! * **Device visibility**: `SILICAFLUX_VISIBLE_DEVICES` (set by the device plugin's `Allocate`) restricts which
//!   devices `discover()` / `open("auto")` expose inside a container.  Unset = no restriction (host process).
//! * **CDI**: generation of Container Device Interface specs, so runtimes that support CDI (containerd >= 1.7,
//!   CRI-O) can inject exactly the allocated device's environment/mounts by name.
//! * **Resource names**: simulated devices are advertised under a *different* resource name than hardware so a
//!   simulator can never be scheduled where hardware was requested.
//!
//! No raw device node, register window or host-memory mapping is ever produced here: containers get an
//! environment and (for a future hardware transport) a mediator socket, never MMIO.

use std::fmt::Write;

/// Resource name for physical devices (none are advertised today: no hardware transport exists).
pub const RESOURCE_HW: &str = "aureom.ai/silicaflux-dpu";
/// Resource name for simulated devices (cpu-ref / rtl-sim), advertised only on explicit request.
pub const RESOURCE_SIM: &str = "aureom.ai/silicaflux-dpu-sim";
pub const ENV_VISIBLE: &str = "SILICAFLUX_VISIBLE_DEVICES";
pub const ENV_BACKEND: &str = "SILICAFLUX_BACKEND";

/// Kubernetes device IDs are opaque strings; keep them shell/DNS friendly: `rtl-sim:mt` -> `rtl-sim-mt`.
pub fn k8s_device_id(descriptor_id: &str) -> String {
    descriptor_id.chars().map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '.' { c } else { '-' }).collect()
}

/// Parse `SILICAFLUX_VISIBLE_DEVICES`: `None` = unrestricted; `Some(vec![])` = no device visible.
pub fn visible_devices(env_value: Option<&str>) -> Option<Vec<String>> {
    let v = env_value?.trim();
    if v.is_empty() || v.eq_ignore_ascii_case("void") || v.eq_ignore_ascii_case("none") {
        return Some(vec![]);
    }
    if v.eq_ignore_ascii_case("all") {
        return None;
    }
    Some(v.split(',').map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect())
}

/// Is `descriptor_id` (e.g. `rtl-sim:mt`) visible under the current environment?
pub fn is_visible(descriptor_id: &str) -> bool {
    match visible_devices(std::env::var(ENV_VISIBLE).ok().as_deref()) {
        None => true,
        Some(list) => list.iter().any(|x| x == descriptor_id || *x == k8s_device_id(descriptor_id)),
    }
}

#[derive(Clone, Debug, Default)]
pub struct CdiDevice {
    pub name: String,
    pub env: Vec<(String, String)>,
    /// Absolute container paths of device nodes (never raw register windows).
    pub device_nodes: Vec<String>,
    pub mounts: Vec<CdiMount>,
}

#[derive(Clone, Debug)]
pub struct CdiMount {
    pub host_path: String,
    pub container_path: String,
    /// e.g. ["ro", "nosuid", "nodev", "bind"]
    pub options: Vec<String>,
}

fn j(s: &str) -> String {
    let mut o = String::with_capacity(s.len() + 2);
    o.push('"');
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            c if (c as u32) < 0x20 => {
                let _ = write!(o, "\\u{:04x}", c as u32);
            }
            c => o.push(c),
        }
    }
    o.push('"');
    o
}

/// CDI specification (cdiVersion 0.6.0) for `kind` (e.g. `aureom.ai/silicaflux-dpu`).
pub fn cdi_spec(kind: &str, devices: &[CdiDevice]) -> String {
    let mut o = String::new();
    let _ = writeln!(o, "{{\n  \"cdiVersion\": \"0.6.0\",\n  \"kind\": {},\n  \"devices\": [", j(kind));
    for (i, d) in devices.iter().enumerate() {
        let _ = write!(o, "    {{\n      \"name\": {},\n      \"containerEdits\": {{\n", j(&d.name));
        let env: Vec<String> = d.env.iter().map(|(k, v)| j(&format!("{k}={v}"))).collect();
        let _ = write!(o, "        \"env\": [{}]", env.join(", "));
        if !d.device_nodes.is_empty() {
            let n: Vec<String> = d.device_nodes.iter().map(|p| format!("{{\"path\": {}}}", j(p))).collect();
            let _ = write!(o, ",\n        \"deviceNodes\": [{}]", n.join(", "));
        }
        if !d.mounts.is_empty() {
            let m: Vec<String> = d
                .mounts
                .iter()
                .map(|m| {
                    format!(
                        "{{\"hostPath\": {}, \"containerPath\": {}, \"options\": [{}]}}",
                        j(&m.host_path),
                        j(&m.container_path),
                        m.options.iter().map(|x| j(x)).collect::<Vec<_>>().join(", ")
                    )
                })
                .collect();
            let _ = write!(o, ",\n        \"mounts\": [{}]", m.join(", "));
        }
        let _ = write!(o, "\n      }}\n    }}{}\n", if i + 1 < devices.len() { "," } else { "" });
    }
    o.push_str("  ]\n}\n");
    o
}

/// The CDI device name a runtime resolves: `<kind>=<name>`.
pub fn cdi_qualified_name(kind: &str, name: &str) -> String {
    format!("{kind}={name}")
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ids_and_visibility() {
        assert_eq!(k8s_device_id("rtl-sim:mt"), "rtl-sim-mt");
        assert_eq!(visible_devices(None), None);
        assert_eq!(visible_devices(Some("all")), None);
        assert_eq!(visible_devices(Some("")), Some(vec![]));
        assert_eq!(visible_devices(Some("void")), Some(vec![]));
        assert_eq!(visible_devices(Some("a, b")), Some(vec!["a".into(), "b".into()]));
    }
    #[test]
    fn cdi_is_wellformed() {
        let d = CdiDevice {
            name: "cpu-ref-0".into(),
            env: vec![(ENV_VISIBLE.into(), "cpu-ref-0".into())],
            device_nodes: vec![],
            mounts: vec![CdiMount {
                host_path: "/run/silicaflux".into(),
                container_path: "/run/silicaflux".into(),
                options: vec!["ro".into(), "nosuid".into(), "nodev".into(), "bind".into()],
            }],
        };
        let s = cdi_spec(RESOURCE_SIM, &[d]);
        assert!(s.contains("\"cdiVersion\": \"0.6.0\"") && s.contains("\"kind\": \"aureom.ai/silicaflux-dpu-sim\""));
        assert!(s.contains("SILICAFLUX_VISIBLE_DEVICES=cpu-ref-0") && s.contains("\"options\": [\"ro\", \"nosuid\", \"nodev\", \"bind\"]"));
        assert_eq!(s.matches('{').count(), s.matches('}').count());
    }
}
