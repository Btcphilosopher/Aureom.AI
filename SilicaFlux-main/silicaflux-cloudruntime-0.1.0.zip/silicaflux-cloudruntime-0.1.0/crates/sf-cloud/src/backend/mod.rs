//! Device-level backend contract.
//!
//! A [`Backend`] is "the DPU as software sees it": the privileged management register window, one
//! submission/completion queue pair per host queue, the host memory the DPU DMAs from/to, and the telemetry
//! event port.  Three implementations exist or are planned:
//!
//! * `cpu-ref`  ([`cpuref`])  -- a pure-software functional model of the same contract (no RTL).  It is the
//!   reference the RTL is differentially tested against, and the CPU-only comparison path for benchmarks.
//! * `rtl-sim` ([`rtl`])      -- the Verilator model of the vendored Project 61 CloudDPU RTL.
//! * `hw`      ([`hw`])       -- physical hardware.  **Not implemented**: only a read-only probe exists, and it
//!   reports "unavailable".  No hardware support is claimed anywhere in this crate.
//!
//! Everything above this trait (mediator, buffers, tenants, workload API, telemetry) is shared code that runs
//! unchanged on every backend.

pub mod cpuref;
pub mod hw;
pub mod rtl;

use crate::status::Status;
use std::fmt;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BackendKind {
    CpuRef,
    RtlSim,
    Hardware,
}

impl BackendKind {
    pub fn as_str(self) -> &'static str {
        match self {
            BackendKind::CpuRef => "cpu-ref",
            BackendKind::RtlSim => "rtl-sim",
            BackendKind::Hardware => "hw",
        }
    }
}

/// What the time axis of this backend means.  Used to keep simulation estimates apart from measurements.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TimingModel {
    /// No timing model: `cycles()` is a logical counter only.
    None,
    /// Cycle-accurate simulation of the RTL (cycles are real RTL clock cycles, but the clock frequency of any
    /// silicon/FPGA implementation is NOT known).
    RtlSimulation,
    /// A physical device with a measured clock.
    Hardware,
}

impl TimingModel {
    pub fn as_str(self) -> &'static str {
        match self {
            TimingModel::None => "none (logical counter)",
            TimingModel::RtlSimulation => "rtl-simulation (cycle-accurate RTL, no clock-frequency claim)",
            TimingModel::Hardware => "hardware (measured)",
        }
    }
}

/// Which workload classes the backend can execute.  Derived from facts, not hopes: for the RTL backend this is
/// read from the DPU's BLOCK_STATUS register and the opcode set of the vendored RTL.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Caps {
    pub nop: bool,
    pub dma: bool,
    pub pkt_process: bool,
    pub gemm_i8: bool,
    pub aes_gcm: bool,
    pub storage: bool,
    pub telemetry: bool,
}

#[derive(Clone, Debug)]
pub struct BackendInfo {
    pub kind: BackendKind,
    pub name: String,
    pub description: String,
    pub timing: TimingModel,
    pub caps: Caps,
    /// Simulated/real host memory the DPU can reach, as an IOVA range.
    pub iova_base: u64,
    pub iova_size: u64,
    /// True only if results come from a physical device.
    pub measured_on_hardware: bool,
    pub details: Vec<(String, String)>,
}

#[derive(Clone, Debug)]
pub enum DevError {
    Unavailable(String),
    Timeout(String),
    /// The management port answered with an error response (invalid register / forbidden write).
    BusError(u32),
    QueueFull,
    BadArg(String),
    Unsupported(String),
    Failed(String),
}

impl fmt::Display for DevError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DevError::Unavailable(s) => write!(f, "device unavailable: {s}"),
            DevError::Timeout(s) => write!(f, "device timeout: {s}"),
            DevError::BusError(a) => write!(f, "management bus error at 0x{a:08x}"),
            DevError::QueueFull => write!(f, "device queue full"),
            DevError::BadArg(s) => write!(f, "bad argument: {s}"),
            DevError::Unsupported(s) => write!(f, "unsupported: {s}"),
            DevError::Failed(s) => write!(f, "device failure: {s}"),
        }
    }
}

impl DevError {
    pub fn status(&self) -> Status {
        match self {
            DevError::Unavailable(_) => Status::NoDevice,
            DevError::Timeout(_) => Status::Timeout,
            DevError::BusError(_) => Status::DeviceFault,
            DevError::QueueFull => Status::QueueFull,
            DevError::BadArg(_) => Status::InvalidArg,
            DevError::Unsupported(_) => Status::Unsupported,
            DevError::Failed(_) => Status::DeviceFault,
        }
    }
}

/// Extension commands: workloads the vendored RTL does not implement (its engine opcodes complete with
/// `ERR_BLOCKED`).  Only the `cpu-ref` backend executes them, in software, and says so in `BackendInfo`.
#[derive(Clone, Debug)]
pub enum ExtCmd {
    /// INT8 x INT8 -> INT32 GEMM.  A at `a` (m*k bytes), B at `b` (k*n bytes), C written to `c` (m*n*4 bytes LE).
    GemmI8 {
        tag: u32,
        a: u64,
        b: u64,
        c: u64,
        m: u32,
        n: u32,
        k: u32,
    },
    /// AES-GCM.  `encrypt`: plaintext at `src` -> ciphertext at `dst` then 16-byte tag at `tag_addr`.
    /// decrypt: ciphertext at `src`, tag read from `tag_addr`; plaintext written to `dst` only if the tag verifies.
    AesGcm {
        tag: u32,
        encrypt: bool,
        key: Vec<u8>,
        iv: [u8; 12],
        aad: Vec<u8>,
        src: u64,
        dst: u64,
        tag_addr: u64,
        len: u32,
    },
    /// Block storage (512-byte blocks) in the tenant's private namespace.
    StorageWrite {
        tag: u32,
        src: u64,
        lba: u64,
        blocks: u32,
    },
    StorageRead {
        tag: u32,
        lba: u64,
        dst: u64,
        blocks: u32,
    },
}

impl ExtCmd {
    pub fn tag(&self) -> u32 {
        match self {
            ExtCmd::GemmI8 { tag, .. } | ExtCmd::AesGcm { tag, .. } | ExtCmd::StorageWrite { tag, .. } | ExtCmd::StorageRead { tag, .. } => *tag,
        }
    }
}

/// Error codes of the extension commands (outside the RTL's 0x00..0x24 range).
pub mod ext_err {
    pub const AUTH_FAIL: u8 = 0x30;
    pub const BAD_PARAM: u8 = 0x31;
    pub const NO_SPACE: u8 = 0x32;
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct HostStats {
    pub reads: u64,
    pub writes: u64,
    pub bytes_rd: u64,
    pub bytes_wr: u64,
    pub wild: u64,
    pub injected_errors: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Access {
    pub cycle: u64,
    pub addr: u64,
    pub write: bool,
    pub bytes: u32,
}

/// Fault/environment injection.  Available on simulated backends only.
pub trait SimControl {
    /// Host-memory accesses in `[lo, hi)` answer with an error response ("memory failure").
    fn inject_host_error(&mut self, lo: u64, hi: u64);
    fn clear_host_errors(&mut self);
    /// Withhold host-memory responses for the next `cycles` cycles ("stuck host / link").
    fn hold_host(&mut self, cycles: u64);
    fn set_host_params(&mut self, lat_max: u32, bp_pct: u32);
    /// Model a completion consumer that stops reading queue `q`.
    fn set_completion_consumer(&mut self, queue: u32, ready: bool);
    fn host_stats(&self) -> HostStats;
    /// Drain the independent host-memory access log (empty if logging is off).
    fn drain_access_log(&mut self) -> Vec<Access>;
    fn enable_access_log(&mut self, on: bool);
    /// Back door: read device-local SRAM without using any device data path (verification of scrubbing).
    fn sram_peek(&mut self, offset: u32, out: &mut [u8]) -> Result<(), DevError>;
}

pub trait Backend: Send {
    fn info(&self) -> BackendInfo;

    // ---- privileged management plane (ControlCore host port / register pages) -------------------------------
    fn mgmt_read(&mut self, addr: u32) -> Result<u32, DevError>;
    fn mgmt_write(&mut self, addr: u32, val: u32) -> Result<(), DevError>;

    // ---- data plane ----------------------------------------------------------------------------------------
    /// Hand a descriptor to queue `queue`.  `Err(QueueFull)` if the device did not accept it.
    fn submit(&mut self, queue: u32, cmd: &[u32; 12]) -> Result<(), DevError>;
    fn submit_ext(&mut self, _queue: u32, _ext: &ExtCmd) -> Result<(), DevError> {
        Err(DevError::Unsupported("extension commands are not implemented by this backend".into()))
    }
    fn pop_completion(&mut self, queue: u32) -> Option<[u32; 8]>;
    /// Let the device run for up to `cycles` device cycles.  Returns the cycles actually advanced.
    fn advance(&mut self, cycles: u64) -> u64;
    fn cycles(&self) -> u64;
    fn pop_telemetry(&mut self) -> Option<[u32; 3]>;

    // ---- host memory (the host CPU's view of the memory the DPU DMAs) ----------------------------------------
    fn host_write(&mut self, iova: u64, data: &[u8]) -> Result<(), DevError>;
    fn host_read(&mut self, iova: u64, out: &mut [u8]) -> Result<(), DevError>;

    /// Hard device reset (all device state lost; host memory preserved).
    fn reset(&mut self) -> Result<(), DevError>;

    /// Exact value of the device's own cycle counter right now (the counter stamped into completion records),
    /// if the backend can read it without bus latency (simulation back door).  Used to calibrate latency
    /// measurements; `None` makes the mediator fall back to a register read (a few cycles of uncertainty).
    fn dpu_time_exact(&mut self) -> Option<u64> {
        None
    }

    fn sim(&mut self) -> Option<&mut dyn SimControl> {
        None
    }
}

// =================================================================================================== discovery
#[derive(Clone, Debug)]
pub struct DeviceDescriptor {
    /// Stable identifier, e.g. `cpu-ref:0`, `rtl-sim:mt`.
    pub id: String,
    pub kind: BackendKind,
    pub description: String,
    pub available: bool,
    /// Why the device is (un)available -- always filled in.
    pub reason: String,
}

/// Where the RTL simulation library is searched.
pub fn rtl_library_candidates(cfg: &str) -> Vec<std::path::PathBuf> {
    let mut v = Vec::new();
    if let Ok(p) = std::env::var("SF_RTL_LIB") {
        v.push(p.into());
    }
    let name = "libsfrtl_p61.so";
    if let Ok(exe) = std::env::current_exe() {
        let mut d = exe.parent().map(|p| p.to_path_buf());
        for _ in 0..5 {
            if let Some(dir) = d.clone() {
                v.push(dir.join("rtl").join(cfg).join(name));
                v.push(dir.join("build/rtl").join(cfg).join(name));
                v.push(dir.join(name));
                d = dir.parent().map(|p| p.to_path_buf());
            }
        }
    }
    if let Ok(cwd) = std::env::current_dir() {
        let mut d = Some(cwd);
        for _ in 0..6 {
            if let Some(dir) = d {
                v.push(dir.join("build/rtl").join(cfg).join(name));
                v.push(dir.join("runtime/cloud/build/rtl").join(cfg).join(name));
                d = dir.parent().map(|p| p.to_path_buf());
            } else {
                break;
            }
        }
    }
    v.push(format!("/usr/lib/silicaflux/rtl/{cfg}/{name}").into());
    v
}

pub fn find_rtl_library(cfg: &str) -> Option<std::path::PathBuf> {
    rtl_library_candidates(cfg).into_iter().find(|p| p.is_file())
}

/// Enumerate every device this host can offer, with an explicit reason for each unavailable one.
pub fn discover() -> Vec<DeviceDescriptor> {
    discover_all().into_iter().filter(|d| crate::container::is_visible(&d.id)).collect()
}

/// Every device, ignoring `SILICAFLUX_VISIBLE_DEVICES` (host-side tooling).
pub fn discover_all() -> Vec<DeviceDescriptor> {
    let mut v = vec![DeviceDescriptor {
        id: "cpu-ref:0".into(),
        kind: BackendKind::CpuRef,
        description: "CPU reference model of the SilicaFlux CloudDPU (software; not hardware)".into(),
        available: true,
        reason: "always available".into(),
    }];
    for cfg in ["mt", "min", "mt4"] {
        let lib = find_rtl_library(cfg);
        v.push(DeviceDescriptor {
            id: format!("rtl-sim:{cfg}"),
            kind: BackendKind::RtlSim,
            description: format!("Verilator simulation of the Project 61 CloudDPU RTL, geometry '{cfg}'"),
            available: lib.is_some(),
            reason: match lib {
                Some(p) => format!("library {}", p.display()),
                None => format!("libsfrtl_p61.so for '{cfg}' not found (build: make -C rtl/sim CFG={cfg}; or set SF_RTL_LIB)"),
            },
        });
    }
    v.extend(hw::probe());
    v
}

/// Parsed backend specification, e.g. `cpu-ref`, `rtl-sim:mt`, `rtl-sim:mt,lib=/path/lib.so,seed=3`.
#[derive(Clone, Debug, Default)]
pub struct BackendSpec {
    pub kind: Option<BackendKind>,
    pub config: String,
    pub lib: Option<String>,
    pub seed: u64,
    pub host_lat_max: u32,
    pub host_bp_pct: u32,
    pub host_mem_bytes: u32,
    pub access_log: bool,
    pub opts: Vec<(String, String)>,
}

impl BackendSpec {
    pub fn parse(s: &str) -> Result<BackendSpec, DevError> {
        let mut sp = BackendSpec { seed: 1, host_lat_max: 2, ..Default::default() };
        let (head, rest) = match s.split_once(':') {
            Some((h, r)) => (h, r),
            None => (s, ""),
        };
        sp.kind = Some(match head {
            "cpu-ref" | "cpuref" | "cpu" => BackendKind::CpuRef,
            "rtl-sim" | "rtl" => BackendKind::RtlSim,
            "hw" | "hardware" => BackendKind::Hardware,
            "auto" | "" => {
                return Ok(BackendSpec { kind: None, ..sp });
            }
            other => return Err(DevError::BadArg(format!("unknown backend '{other}' (cpu-ref | rtl-sim | hw | auto)"))),
        });
        sp.config = "mt".into();
        for item in rest.split(',').filter(|x| !x.is_empty()) {
            let (k, v) = item.split_once('=').unwrap_or(("cfg", item));
            match k {
                "cfg" | "config" => sp.config = v.to_string(),
                "lib" => sp.lib = Some(v.to_string()),
                "seed" => sp.seed = v.parse().map_err(|_| DevError::BadArg(format!("bad seed '{v}'")))?,
                "lat" => sp.host_lat_max = v.parse().map_err(|_| DevError::BadArg(format!("bad lat '{v}'")))?,
                "bp" => sp.host_bp_pct = v.parse().map_err(|_| DevError::BadArg(format!("bad bp '{v}'")))?,
                "mem" => sp.host_mem_bytes = v.parse().map_err(|_| DevError::BadArg(format!("bad mem '{v}'")))?,
                "log" => sp.access_log = v == "1" || v == "true",
                _ => sp.opts.push((k.to_string(), v.to_string())),
            }
        }
        Ok(sp)
    }
}

/// Open a backend.  `auto` prefers the RTL simulation when its library is present, otherwise the CPU model.
pub fn open_backend(spec: &BackendSpec) -> Result<Box<dyn Backend>, DevError> {
    // Visibility control: inside a container only the allocated device(s) may be opened.
    let id = match spec.kind {
        Some(BackendKind::CpuRef) => Some("cpu-ref:0".to_string()),
        Some(BackendKind::RtlSim) => Some(format!("rtl-sim:{}", spec.config)),
        Some(BackendKind::Hardware) => Some("hw:none".to_string()),
        None => None,
    };
    if let Some(id) = &id {
        if !crate::container::is_visible(id) && spec.kind != Some(BackendKind::Hardware) {
            return Err(DevError::Unavailable(format!(
                "device '{id}' is not visible: {}={:?} (set by the device plugin's Allocate)",
                crate::container::ENV_VISIBLE,
                std::env::var(crate::container::ENV_VISIBLE).unwrap_or_default()
            )));
        }
    }
    match spec.kind {
        Some(BackendKind::CpuRef) => Ok(Box::new(cpuref::CpuRefBackend::from_spec(spec)?)),
        Some(BackendKind::RtlSim) => Ok(Box::new(rtl::RtlBackend::open(spec)?)),
        Some(BackendKind::Hardware) => Err(DevError::Unavailable(hw::unavailable_reason())),
        None => {
            if find_rtl_library("mt").is_some() && crate::container::is_visible("rtl-sim:mt") {
                let mut s = spec.clone();
                s.kind = Some(BackendKind::RtlSim);
                s.config = "mt".into();
                return open_backend(&s);
            }
            if !crate::container::is_visible("cpu-ref:0") {
                return Err(DevError::Unavailable(format!(
                    "no device is visible: {}={:?}",
                    crate::container::ENV_VISIBLE,
                    std::env::var(crate::container::ENV_VISIBLE).unwrap_or_default()
                )));
            }
            let mut s = spec.clone();
            s.kind = Some(BackendKind::CpuRef);
            open_backend(&s)
        }
    }
}
