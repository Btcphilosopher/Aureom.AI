//! Physical hardware backend: **NOT IMPLEMENTED.**
//!
//! There is no PCIe endpoint IP, no FPGA bitstream, no board and no kernel driver for the SilicaFlux CloudDPU in
//! the repository (see `docs/00_DEPENDENCY_READINESS.md`).  This module therefore contains only a *read-only
//! probe*: it looks at sysfs for devices matching configured PCI IDs and for IOMMU/VFIO readiness, and always
//! reports the device as unavailable with the precise reason.  It never opens, maps or writes a device.
//!
//! The intended hardware access path is documented in `docs/03_LINUX_DEVICE_ACCESS.md` (VFIO behind a
//! privileged mediator; no raw MMIO or host memory exposed to tenants).

use super::{BackendKind, DeviceDescriptor};
use std::fs;
use std::path::Path;

pub fn unavailable_reason() -> String {
    "physical SilicaFlux CloudDPU access is not implemented: no PCIe endpoint, FPGA image or verified kernel/VFIO \
     transport exists yet (docs/03_LINUX_DEVICE_ACCESS.md); use cpu-ref or rtl-sim"
        .to_string()
}

/// PCI IDs to look for: `SF_PCI_IDS="vvvv:dddd[,vvvv:dddd...]"`.  No IDs have been assigned to this device, so
/// by default nothing is looked for.
fn configured_ids() -> Vec<(u16, u16)> {
    std::env::var("SF_PCI_IDS")
        .ok()
        .map(|s| {
            s.split(',')
                .filter_map(|p| {
                    let (v, d) = p.trim().split_once(':')?;
                    Some((u16::from_str_radix(v, 16).ok()?, u16::from_str_radix(d, 16).ok()?))
                })
                .collect()
        })
        .unwrap_or_default()
}

fn read_hex(p: &Path) -> Option<u32> {
    let s = fs::read_to_string(p).ok()?;
    u32::from_str_radix(s.trim().trim_start_matches("0x"), 16).ok()
}

/// Read-only environment facts relevant to a future VFIO transport.
pub fn vfio_readiness() -> Vec<(String, String)> {
    let mut v = Vec::new();
    v.push(("/dev/vfio/vfio".into(), if Path::new("/dev/vfio/vfio").exists() { "present" } else { "absent" }.into()));
    let groups = fs::read_dir("/sys/kernel/iommu_groups").map(|d| d.count()).unwrap_or(0);
    v.push(("iommu_groups".into(), groups.to_string()));
    v
}

pub fn probe() -> Vec<DeviceDescriptor> {
    let ids = configured_ids();
    let mut out = Vec::new();
    if ids.is_empty() {
        out.push(DeviceDescriptor {
            id: "hw:none".into(),
            kind: BackendKind::Hardware,
            description: "physical SilicaFlux CloudDPU (PCIe)".into(),
            available: false,
            reason: format!("{} (no PCI IDs configured: set SF_PCI_IDS once IDs are assigned)", unavailable_reason()),
        });
        return out;
    }
    if let Ok(dir) = fs::read_dir("/sys/bus/pci/devices") {
        for e in dir.flatten() {
            let p = e.path();
            let (Some(ven), Some(dev)) = (read_hex(&p.join("vendor")), read_hex(&p.join("device"))) else { continue };
            if ids.contains(&(ven as u16, dev as u16)) {
                out.push(DeviceDescriptor {
                    id: format!("hw:{}", e.file_name().to_string_lossy()),
                    kind: BackendKind::Hardware,
                    description: format!("PCI {:04x}:{:04x} (matched SF_PCI_IDS)", ven, dev),
                    available: false,
                    reason: unavailable_reason(),
                });
            }
        }
    }
    if out.is_empty() {
        out.push(DeviceDescriptor {
            id: "hw:none".into(),
            kind: BackendKind::Hardware,
            description: "physical SilicaFlux CloudDPU (PCIe)".into(),
            available: false,
            reason: "no PCI device matches SF_PCI_IDS".into(),
        });
    }
    out
}
