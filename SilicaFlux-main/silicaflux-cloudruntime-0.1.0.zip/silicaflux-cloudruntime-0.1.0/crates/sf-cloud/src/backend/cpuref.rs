//! `cpu-ref` backend: a software functional model of the SilicaFlux CloudDPU contract.
//!
//! It is **not hardware and not RTL**.  It implements the same management register map, queue/completion
//! semantics, validation order, error codes, tenant state machine and isolation checks as the vendored Project
//! 61 RTL -- transcribed from the RTL sources and kept honest by *differential tests* that run identical command
//! streams against this model and the Verilator simulation and compare every completion record and every host
//! memory byte (`tests/differential.rs`).
//!
//! Beyond the RTL it also executes the *extension* workloads (INT8 GEMM, AES-GCM, block storage) in software,
//! which the RTL cannot do (its engine opcodes complete with `ERR_BLOCKED`).  Those are labelled as software
//! extensions in `BackendInfo`.
//!
//! Time: the model has a *logical* clock (`cycles()`); the numbers are not a performance model.

use super::*;
use crate::proto::{self, blk, cfg, err, op, status, tcmd, tlm, tstate, Cmd};
use aes_gcm::aead::generic_array::GenericArray;
use aes_gcm::aead::AeadInPlace;
use aes_gcm::{Aes128Gcm, Aes256Gcm, KeyInit};
use std::collections::{HashMap, VecDeque};

#[derive(Clone, Debug)]
pub struct CpuRefConfig {
    pub tenants: u32,
    pub net_queues: u32,
    pub compute_queues: u32,
    pub dma_channels: u32,
    pub windows: u32,
    pub sram_bytes: u32,
    pub max_xfer: u32,
    pub queue_depth: u32,
    pub cplq_depth: u32,
    pub host_mem_bytes: u32,
    pub iova_base: u64,
    /// Capacity of each tenant's private storage namespace, in 512-byte blocks.
    pub storage_blocks: u64,
}

impl Default for CpuRefConfig {
    /// Same geometry as the RTL `mt` configuration, so the two can be compared command for command.
    fn default() -> Self {
        CpuRefConfig {
            tenants: 2,
            net_queues: 2,
            compute_queues: 1,
            dma_channels: 2,
            windows: 2,
            sram_bytes: 65536,
            max_xfer: 4096,
            queue_depth: 4,
            cplq_depth: 4,
            host_mem_bytes: 4 << 20,
            iova_base: 0x4000_0000,
            storage_blocks: 8192,
        }
    }
}

const WIN_NONE: (u64, u32, u32) = (0, 0, 0);
const RING_MAX: usize = 256;
const TLM_MAX: usize = 1 << 16;
const BEAT: u32 = 4;

#[derive(Clone)]
struct Tenant {
    state: u32,
    cfg_ok: bool,
    claimed: bool,
    cfg_status: u32,
    sh_base: u32,
    sh_size: u32,
    ef_base: u32,
    ef_size: u32,
    policy: bool,
    viol: u32,
    sh_win: Vec<(u64, u32, u32)>,
    ef_win: Vec<(u64, u32, u32)>,
    inflight: u32,
}

enum Entry {
    Hw(Cmd),
    Ext(ExtCmd),
}

struct Queue {
    bind: u32,
    compute: bool,
    sq: VecDeque<Entry>,
    hw_cq: VecDeque<[u32; 8]>,
    ring: VecDeque<[u32; 8]>,
    reserved: u32,
    submitted: u32,
    completed: u32,
    rejected: u32,
    consumer_ready: bool,
}

struct Job {
    entry: Entry,
    queue: u32,
    tenant: u32,
    start: u64,
    done_at: u64,
    zombie: bool,
    touches_host: bool,
}

#[derive(Default, Clone)]
struct TenantPerf {
    cmds: u64,
    bytes: u64,
    viol: u32,
    errors: u32,
}

struct Model {
    c: CpuRefConfig,
    clock: u64,
    sram: Vec<u8>,
    tenants: Vec<Tenant>,
    queues: Vec<Queue>,
    slots: Vec<Option<Job>>,
    rr: usize,
    ctl_en: bool,
    halted: bool,
    reset_pending: bool,
    job_timeout: u32,
    scratch: u32,
    n_resets: u32,
    irq_en: bool,
    fst: u32,
    fen: u32,
    fwn: u32,
    ffa: u32,
    f_tenant: u32,
    f_err: u32,
    f_addr: u64,
    cnt: [u64; 16],
    tperf: Vec<TenantPerf>,
    perf_frozen: bool,
    thi: u32,
    perf_hi: u32,
    tlm_en: bool,
    tlm: VecDeque<[u32; 3]>,
    tlm_dropped: u32,
    tlm_emitted: u32,
    blocked_rejects: u32,
    pkt_jobs: u32,
    txn_ctr: u16,
    storage: Vec<HashMap<u64, Box<[u8; 512]>>>,
}

pub struct CpuRefBackend {
    m: Model,
    hm: Vec<u8>,
    // simulation controls (kept outside the Model: they survive a device reset, like the RTL harness')
    err_ranges: Vec<(u64, u64)>,
    hold_until: u64,
    stats: HostStats,
    log_on: bool,
    log: VecDeque<Access>,
    info: BackendInfo,
}

fn p32(v: u64) -> u32 {
    v as u32
}

impl Model {
    fn new(c: CpuRefConfig) -> Model {
        let nqh = (c.net_queues + c.compute_queues) as usize;
        let nt = c.tenants as usize;
        let mut queues = Vec::new();
        for q in 0..nqh {
            queues.push(Queue {
                bind: (q as u32) % c.tenants,
                compute: q as u32 >= c.net_queues,
                sq: VecDeque::new(),
                hw_cq: VecDeque::new(),
                ring: VecDeque::new(),
                reserved: 0,
                submitted: 0,
                completed: 0,
                rejected: 0,
                consumer_ready: true,
            });
        }
        Model {
            sram: vec![0; c.sram_bytes as usize],
            tenants: (0..nt)
                .map(|_| Tenant {
                    state: tstate::DISABLED,
                    cfg_ok: false,
                    claimed: false,
                    cfg_status: cfg::NONE,
                    sh_base: 0,
                    sh_size: 0,
                    ef_base: 0,
                    ef_size: 0,
                    policy: true,
                    viol: 0,
                    sh_win: vec![WIN_NONE; c.windows as usize],
                    ef_win: vec![WIN_NONE; c.windows as usize],
                    inflight: 0,
                })
                .collect(),
            queues,
            slots: (0..c.dma_channels).map(|_| None).collect(),
            rr: 0,
            ctl_en: false,
            halted: false,
            reset_pending: false,
            job_timeout: 0x0004_0000,
            scratch: 0,
            n_resets: 0,
            irq_en: false,
            fst: 0,
            fen: 0,
            fwn: 0,
            ffa: 0,
            f_tenant: 0,
            f_err: 0,
            f_addr: 0,
            cnt: [0; 16],
            tperf: vec![TenantPerf::default(); nt],
            perf_frozen: false,
            thi: 0,
            perf_hi: 0,
            tlm_en: true,
            tlm: VecDeque::new(),
            tlm_dropped: 0,
            tlm_emitted: 0,
            blocked_rejects: 0,
            pkt_jobs: 0,
            txn_ctr: 0,
            storage: (0..nt).map(|_| HashMap::new()).collect(),
            clock: 0,
            c,
        }
    }

    fn nqh(&self) -> u32 {
        self.c.net_queues + self.c.compute_queues
    }

    fn count(&mut self, k: usize, n: u64) {
        if !self.perf_frozen {
            self.cnt[k] += n;
        }
    }

    fn emit(&mut self, event: u8, tenant: u32, queue: u32, arg: u32) {
        self.tlm_emitted += 1;
        if !self.tlm_en {
            return;
        }
        if self.tlm.len() >= TLM_MAX {
            self.tlm_dropped += 1;
            self.fst |= 1 << proto::flt::TLM_DROP;
            return;
        }
        let ts = p32(self.clock);
        // {ts[31:0], arg[31:0], event[7:0], queue[3:0], tenant[3:0]} as three LE words
        let w0 = (tenant & 0xF) | (queue & 0xF) << 4 | (event as u32) << 8 | (arg & 0xFFFF) << 16;
        let w1 = (arg >> 16) | (ts & 0xFFFF) << 16;
        let w2 = ts >> 16;
        self.tlm.push_back([w0, w1, w2]);
    }

    fn set_state(&mut self, t: usize, s: u32) {
        if self.tenants[t].state != s {
            self.tenants[t].state = s;
            self.emit(tlm::TENANT_STATE, t as u32, 0, s);
        }
    }

    fn zero_partition(&mut self, t: usize) {
        let (b, s) = (self.tenants[t].ef_base as usize, self.tenants[t].ef_size as usize);
        if b + s <= self.sram.len() {
            self.sram[b..b + s].iter_mut().for_each(|x| *x = 0);
        }
    }

    // ------------------------------------------------------------------------------------ registers
    fn read(&mut self, addr: u32) -> Result<u32, DevError> {
        let be = DevError::BusError(addr);
        // NOTE: the local SRAM (ControlCore EXT window 0x2000_0000) is NOT reachable through the host management
        // port on the RTL (bus error); only the ControlCore's own CPU/DMA can address it.  The model matches.
        if !(0x4000_8000..0x4001_0000).contains(&addr) || addr % 4 != 0 {
            return Err(be);
        }
        let page = (addr - 0x4000_8000) >> 12;
        let off = addr & 0xFFF;
        match page {
            0 => self.read_global(off).ok_or(be),
            1 => self.read_tenant(off).ok_or(be),
            2 => self.read_queue(off).ok_or(be),
            3 => Ok(0),
            4 => self.read_perf(off).ok_or(be),
            5 => self.read_tlm(off).ok_or(be),
            6 => match off {
                0 => Ok(blk::TEST_ADAPTER | 1 << 8),
                4 => Ok(blk::TEST_ADAPTER | 1 << 8),
                8 => Ok(blk::TEST_ADAPTER | 1 << 8),
                0x10 => Ok(self.blocked_rejects),
                0x14 => Ok(self.pkt_jobs),
                _ => Err(be),
            },
            7 => Ok(0),
            _ => Err(be),
        }
    }

    fn read_global(&mut self, off: u32) -> Option<u32> {
        let c = &self.c;
        Some(match off {
            0x000 => proto::DPU_ID_MAGIC,
            0x004 => proto::DPU_ABI_MAJOR << 16 | proto::DPU_ABI_MINOR,
            0x008 => c.tenants | c.net_queues << 8 | c.compute_queues << 16 | c.dma_channels << 24,
            0x00C => 32 | 32 << 16 | c.windows << 24,
            0x010 => c.sram_bytes,
            0x014 => c.max_xfer,
            // The model is a behavioural stand-in for every block -> TEST_ADAPTER; none is REAL.
            0x018 => {
                let t = blk::TEST_ADAPTER;
                t | t << 2 | t << 4 | t << 6 | t << 8 | t << 10 | t << 12 | t << 14
            }
            0x01C => 0b0000_0111 | 1 << 3 | ((c.tenants > 1) as u32) << 4 | 1 << 5 | ((c.queue_depth > 1) as u32) << 6,
            0x020 => self.ctl_en as u32,
            0x024 => {
                let inflight = self.slots.iter().filter(|s| s.is_some()).count() as u32;
                let queued: u32 = self.queues.iter().map(|q| q.sq.len() as u32).sum();
                let busy = inflight > 0 || queued > 0 || self.reset_pending;
                let scrub = self.tenants.iter().any(|t| t.state == tstate::SCRUBBING) as u32;
                (queued & 0xFF) << 16 | (inflight & 0xFF) << 8 | scrub << 3 | (self.reset_pending as u32) << 2 | (self.halted as u32) << 1 | busy as u32
            }
            0x028 => (self.irq_fault() as u32) << 1,
            0x02C => self.irq_en as u32,
            0x030 => self.fst,
            0x034 => self.fen,
            0x038 => self.fwn,
            0x03C => self.ffa,
            0x040 => self.f_tenant,
            0x044 => self.f_err,
            0x048 => p32(self.f_addr),
            0x04C => (self.f_addr >> 32) as u32,
            0x050 => self.job_timeout,
            0x054 => {
                self.thi = (self.clock >> 32) as u32;
                p32(self.clock)
            }
            0x058 => self.thi,
            0x060 => self.scratch,
            0x064 => self.n_resets,
            _ => return None,
        })
    }

    fn irq_fault(&self) -> bool {
        self.fst & self.fen != 0
    }

    fn write_global(&mut self, off: u32, v: u32) -> bool {
        match off {
            0x020 => {
                self.ctl_en = v & 1 != 0;
                if v & 2 != 0 {
                    self.reset_pending = true;
                    self.n_resets += 1;
                }
            }
            0x02C => self.irq_en = v & 1 != 0,
            0x030 => self.fst &= !(v & 0xFF),
            0x034 => self.fen = v & 0xFF,
            0x038 => self.fwn = v & 0xFF,
            0x03C => self.ffa = v & 0xFF,
            0x050 => self.job_timeout = v,
            0x060 => self.scratch = v,
            _ => return false,
        }
        true
    }

    fn tenant_idx(&self, off: u32) -> Option<(usize, u32)> {
        let t = (off >> 8) as usize;
        if t >= self.tenants.len() {
            None
        } else {
            Some((t, off & 0xFF))
        }
    }

    fn read_tenant(&mut self, off: u32) -> Option<u32> {
        let (t, o) = self.tenant_idx(off)?;
        let ten = &self.tenants[t];
        if (0x20..0xA0).contains(&o) {
            if o % 4 != 0 {
                return None;
            }
            let w = ((o - 0x20) >> 4) as usize;
            if w >= self.c.windows as usize {
                return None;
            }
            let (b, s, c) = ten.sh_win[w];
            return Some(match (o >> 2) & 3 {
                0 => p32(b),
                1 => (b >> 32) as u32,
                2 => s,
                _ => c,
            });
        }
        Some(match o {
            0x00 => ten.inflight << 24 | (ten.cfg_ok as u32) << 8 | ten.state,
            0x04 => 0,
            0x08 => ten.cfg_status,
            0x0C => ten.sh_base,
            0x10 => ten.sh_size,
            0x14 => ten.policy as u32,
            0x18 => ten.viol,
            0x1C => ten.inflight,
            _ => return None,
        })
    }

    fn write_tenant(&mut self, off: u32, v: u32) -> bool {
        let Some((t, o)) = self.tenant_idx(off) else { return false };
        if (0x20..0xA0).contains(&o) {
            if o % 4 != 0 {
                return false;
            }
            let w = ((o - 0x20) >> 4) as usize;
            if w >= self.c.windows as usize {
                return false;
            }
            let e = &mut self.tenants[t].sh_win[w];
            match (o >> 2) & 3 {
                0 => e.0 = (e.0 & !0xFFFF_FFFF) | v as u64,
                1 => e.0 = (e.0 & 0xFFFF_FFFF) | (v as u64) << 32,
                2 => e.1 = v,
                _ => e.2 = v & 7,
            }
            return true;
        }
        match o {
            0x04 => self.tenant_cmd(t, v),
            0x0C => self.tenants[t].sh_base = v,
            0x10 => self.tenants[t].sh_size = v,
            0x14 => self.tenants[t].policy = v & 1 != 0,
            _ => return false,
        }
        true
    }

    fn tenant_cmd(&mut self, t: usize, v: u32) {
        match v {
            tcmd::COMMIT => {
                if self.tenants[t].state != tstate::DISABLED {
                    self.tenants[t].cfg_status = cfg::BUSY;
                    return;
                }
                let r = self.validate_commit(t);
                self.tenants[t].cfg_status = r;
                if r == cfg::OK {
                    let ten = &mut self.tenants[t];
                    ten.ef_base = ten.sh_base;
                    ten.ef_size = ten.sh_size;
                    ten.ef_win = ten.sh_win.clone();
                    ten.claimed = true;
                    ten.cfg_ok = false;
                    self.set_state(t, tstate::SCRUBBING);
                }
            }
            tcmd::ENABLE => {
                if self.tenants[t].state == tstate::DISABLED && self.tenants[t].cfg_ok {
                    self.set_state(t, tstate::ACTIVE);
                }
            }
            tcmd::DISABLE | tcmd::RECOVER => {
                if self.tenants[t].state == tstate::ACTIVE || self.tenants[t].state == tstate::QUARANTINED {
                    self.set_state(t, tstate::DRAINING);
                }
            }
            tcmd::RELEASE if self.tenants[t].state == tstate::DISABLED => {
                let ten = &mut self.tenants[t];
                ten.claimed = false;
                ten.cfg_ok = false;
                ten.cfg_status = cfg::NONE;
            }
            _ => {}
        }
    }

    /// Same order of checks as `sfd_tenant_ctx`: partition, windows, then for each other claimed tenant
    /// (lowest first) SRAM overlap before host-window overlap.
    fn validate_commit(&self, t: usize) -> u32 {
        let ten = &self.tenants[t];
        let (b, s) = (ten.sh_base as u64, ten.sh_size as u64);
        if s == 0 || b % 256 != 0 || s % 256 != 0 || b + s > self.c.sram_bytes as u64 {
            return cfg::BAD_PART;
        }
        for &(wb, ws, wc) in &ten.sh_win {
            if wc & 1 != 0 && (ws == 0 || wb % 4 != 0 || ws % 4 != 0 || wb as u128 + ws as u128 > 1u128 << 32) {
                return cfg::BAD_WINDOW;
            }
        }
        for (i, o) in self.tenants.iter().enumerate() {
            if i == t || !o.claimed {
                continue;
            }
            if b < o.ef_base as u64 + o.ef_size as u64 && (o.ef_base as u64) < b + s {
                return cfg::OVERLAP_SRAM;
            }
            for &(wb, ws, wc) in &ten.sh_win {
                for &(ob, os, oc) in &o.ef_win {
                    if wc & 1 != 0 && oc & 1 != 0 && wb < ob + os as u64 && ob < wb + ws as u64 {
                        return cfg::OVERLAP_HOST;
                    }
                }
            }
        }
        cfg::OK
    }

    fn read_queue(&mut self, off: u32) -> Option<u32> {
        let q = (off >> 5) as usize;
        let o = off & 0x1F;
        if off >= 0x800 || q >= 16 {
            return Some(0);
        }
        if q >= self.queues.len() {
            return match o {
                4 => Some(0),
                0 => Some(0),
                _ => Some(0),
            };
        }
        let qu = &self.queues[q];
        Some(match o {
            0x00 => qu.bind,
            0x04 => (qu.sq.len() as u32 & 0xFF) | (qu.hw_cq.len() as u32 & 0xFF) << 8 | (qu.compute as u32) << 16 | 1 << 18,
            0x08 => qu.submitted,
            0x0C => qu.completed,
            0x10 => qu.rejected,
            _ => return None,
        })
    }

    fn write_queue(&mut self, off: u32, v: u32) -> bool {
        let q = (off >> 5) as usize;
        if off & 0x1F != 0 || q >= self.queues.len() || v >= self.c.tenants {
            return false;
        }
        let qu = &mut self.queues[q];
        if !qu.sq.is_empty() || qu.reserved != 0 {
            return false;
        }
        qu.bind = v;
        true
    }

    fn read_perf(&mut self, off: u32) -> Option<u32> {
        Some(match off {
            0x000 => self.perf_frozen as u32,
            0x004 => 16 | self.c.tenants << 8,
            0x010..=0x08F => {
                let k = ((off - 0x10) / 8) as usize;
                if k >= 16 {
                    return Some(0);
                }
                if (off - 0x10) % 8 == 0 {
                    self.perf_hi = (self.cnt[k] >> 32) as u32;
                    p32(self.cnt[k])
                } else {
                    self.perf_hi
                }
            }
            0x400..=0x7FF => {
                let t = ((off - 0x400) / 0x20) as usize;
                let o = (off - 0x400) % 0x20;
                if t >= self.tperf.len() {
                    return Some(0);
                }
                let p = &self.tperf[t];
                match o {
                    0x00 => p32(p.cmds),
                    0x04 => (p.cmds >> 32) as u32,
                    0x08 => p32(p.bytes),
                    0x0C => (p.bytes >> 32) as u32,
                    0x18 => p.viol,
                    0x1C => p.errors,
                    _ => 0,
                }
            }
            _ => return None,
        })
    }

    fn write_perf(&mut self, off: u32, v: u32) -> bool {
        if off != 0 {
            return false;
        }
        self.perf_frozen = v & 1 != 0;
        if v & 2 != 0 {
            self.cnt = [0; 16];
            self.tperf.iter_mut().for_each(|p| *p = TenantPerf::default());
        }
        true
    }

    fn read_tlm(&mut self, off: u32) -> Option<u32> {
        Some(match off {
            0x00 => self.tlm_en as u32,
            0x04 => 0,
            0x08 => self.tlm_dropped,
            0x0C => self.tlm_emitted,
            0x10 | 0x14 | 0x18 => 0,
            _ => return None,
        })
    }
}

// ============================================================================================ backend
impl CpuRefBackend {
    pub fn from_spec(spec: &BackendSpec) -> Result<CpuRefBackend, DevError> {
        let mut c = CpuRefConfig::default();
        for (k, v) in &spec.opts {
            let n: u64 = v.parse().map_err(|_| DevError::BadArg(format!("bad value for {k}: '{v}'")))?;
            match k.as_str() {
                "tenants" => c.tenants = n as u32,
                "nnq" => c.net_queues = n as u32,
                "ncq" => c.compute_queues = n as u32,
                "ns" => c.dma_channels = n as u32,
                "sram" => c.sram_bytes = n as u32,
                "maxx" => c.max_xfer = n as u32,
                "storage_blocks" => c.storage_blocks = n,
                other => return Err(DevError::BadArg(format!("unknown cpu-ref option '{other}'"))),
            }
        }
        if spec.config == "min" {
            c.tenants = 1;
            c.net_queues = 1;
            c.dma_channels = 1;
        } else if spec.config == "mt4" {
            c.tenants = 4;
            c.net_queues = 4;
        }
        if spec.host_mem_bytes != 0 {
            c.host_mem_bytes = spec.host_mem_bytes;
        }
        let mut b = CpuRefBackend::new(c)?;
        b.log_on = spec.access_log;
        Ok(b)
    }

    pub fn new(c: CpuRefConfig) -> Result<CpuRefBackend, DevError> {
        if c.tenants == 0 || c.tenants > 16 || c.net_queues == 0 || c.net_queues + c.compute_queues > 15 || c.dma_channels == 0 || c.dma_channels > 8 {
            return Err(DevError::BadArg("illegal cpu-ref geometry".into()));
        }
        if c.sram_bytes % 256 != 0 || c.windows == 0 || c.windows > 8 || c.max_xfer < BEAT {
            return Err(DevError::BadArg("illegal cpu-ref geometry (sram/windows/max_xfer)".into()));
        }
        let info = BackendInfo {
            kind: BackendKind::CpuRef,
            name: "cpu-ref".into(),
            description: "CPU reference model of the SilicaFlux CloudDPU contract (software; NOT hardware, NOT RTL)".into(),
            timing: TimingModel::None,
            caps: Caps { nop: true, dma: true, pkt_process: true, gemm_i8: true, aes_gcm: true, storage: true, telemetry: true },
            iova_base: c.iova_base,
            iova_size: c.host_mem_bytes as u64,
            measured_on_hardware: false,
            details: vec![
                ("model".into(), "functional; logical clock only".into()),
                (
                    "geometry".into(),
                    format!("tenants={} net_queues={} compute_queues={} dma_channels={} sram={}", c.tenants, c.net_queues, c.compute_queues, c.dma_channels, c.sram_bytes),
                ),
                ("extensions".into(), "INT8 GEMM, AES-GCM, block storage execute in software (the RTL blocks them)".into()),
                ("packetcore".into(), "test-adapter semantics (PASS/XOR32/BSWAP32 + CRC-32 + RFC1071)".into()),
            ],
        };
        Ok(CpuRefBackend {
            hm: vec![0; c.host_mem_bytes as usize],
            m: Model::new(c),
            err_ranges: vec![],
            hold_until: 0,
            stats: HostStats::default(),
            log_on: false,
            log: VecDeque::new(),
            info,
        })
    }

    // ---------------------------------------------------------------------------- host memory (beat level)
    fn in_range(&self, addr: u64, len: u64) -> bool {
        addr >= self.m.c.iova_base && addr + len <= self.m.c.iova_base + self.hm.len() as u64
    }
    fn err_at(&self, addr: u64) -> bool {
        self.err_ranges.iter().any(|&(lo, hi)| addr >= lo && addr < hi)
    }
    fn note(&mut self, addr: u64, write: bool, bytes: u32) {
        if self.log_on && self.log.len() < (1 << 20) {
            self.log.push_back(Access { cycle: self.m.clock, addr, write, bytes });
        }
    }

    /// Read `len` bytes beat by beat; stops at the first beat that answers with an error.
    /// Returns (data, completed bytes, failed).
    fn dev_read(&mut self, addr: u64, len: u32) -> (Vec<u8>, u32, bool) {
        let mut out = Vec::with_capacity(len as usize);
        let fast = self.err_ranges.is_empty() && !self.log_on;
        if fast && self.in_range(addr, len as u64) {
            let o = (addr - self.m.c.iova_base) as usize;
            out.extend_from_slice(&self.hm[o..o + len as usize]);
            self.stats.reads += len.div_ceil(4) as u64;
            self.stats.bytes_rd += (len.div_ceil(4) * 4) as u64;
            return (out, len, false);
        }
        let mut done = 0u32;
        while done < len {
            let a = addr + done as u64;
            let n = BEAT.min(len - done);
            if !self.in_range(a, BEAT as u64) {
                self.stats.wild += 1;
                return (out, done, true);
            }
            if self.err_at(a) {
                self.stats.injected_errors += 1;
                return (out, done, true);
            }
            let o = (a - self.m.c.iova_base) as usize;
            out.extend_from_slice(&self.hm[o..o + n as usize]);
            self.stats.reads += 1;
            self.stats.bytes_rd += 4;
            self.note(a, false, BEAT);
            done += n;
        }
        (out, done, false)
    }

    /// Write beat by beat (the last beat uses a partial byte strobe); stops at the first error beat.
    /// Returns (bytes written, failed).
    fn dev_write(&mut self, addr: u64, data: &[u8]) -> (u32, bool) {
        let len = data.len() as u32;
        let fast = self.err_ranges.is_empty() && !self.log_on;
        if fast && self.in_range(addr, len as u64) {
            let o = (addr - self.m.c.iova_base) as usize;
            self.hm[o..o + len as usize].copy_from_slice(data);
            self.stats.writes += len.div_ceil(4) as u64;
            self.stats.bytes_wr += len as u64;
            return (len, false);
        }
        let mut done = 0u32;
        while done < len {
            let a = addr + done as u64;
            let n = BEAT.min(len - done);
            if !self.in_range(a, BEAT as u64) {
                self.stats.wild += 1;
                return (done, true);
            }
            if self.err_at(a) {
                self.stats.injected_errors += 1;
                return (done, true);
            }
            let o = (a - self.m.c.iova_base) as usize;
            self.hm[o..o + n as usize].copy_from_slice(&data[done as usize..(done + n) as usize]);
            self.stats.writes += 1;
            self.stats.bytes_wr += n as u64;
            self.note(a, true, n);
            done += n;
        }
        (done, false)
    }

    // ---------------------------------------------------------------------------- window check
    fn win_ok(&self, t: usize, addr: u64, len: u32, need_r: bool, need_w: bool) -> bool {
        if len == 0 {
            return false;
        }
        let end = addr as u128 + len as u128;
        self.m.tenants[t].ef_win.iter().any(|&(b, s, c)| c & 1 != 0 && addr >= b && end <= b as u128 + s as u128 && (!need_r || c & 2 != 0) && (!need_w || c & 4 != 0))
    }

    // ---------------------------------------------------------------------------- command validation
    /// Mirrors `sfd_cmdproc` VALIDATION ORDER.  Returns (error, nop, fault address).
    fn validate(&self, q: u32, cmd: &Cmd) -> (u8, bool, u64) {
        let m = &self.m;
        let qu = &m.queues[q as usize];
        let t = qu.bind as usize;
        let d_len = cmd.len;
        if cmd.tenant as u32 != qu.bind {
            return (err::TENANT_MISMATCH, false, 0);
        }
        if cmd.rsvd_w0 != 0 || cmd.flags & 0xFE != 0 || cmd.rsvd_w8 != 0 || cmd.rsvd_w10_11 != 0 {
            return (err::BAD_DESC, false, 0);
        }
        let o = cmd.opcode;
        let known = o == op::NOP || op::is_net(o) || op::is_eng(o);
        if !known {
            return (err::BAD_OPCODE, false, 0);
        }
        if (op::is_net(o) && qu.compute) || (op::is_eng(o) && !qu.compute) {
            return (err::BAD_OPCODE, false, 0);
        }
        match m.tenants[t].state {
            tstate::QUARANTINED => return (err::QUARANTINED, false, 0),
            tstate::ACTIVE => {}
            _ => return (err::TENANT_STATE, false, 0),
        }
        if op::is_eng(o) {
            return (err::BLOCKED, false, 0);
        }
        if o == op::NOP {
            return (err::NONE, true, 0);
        }
        if d_len == 0 || d_len > m.c.max_xfer {
            return (err::BAD_LENGTH, false, 0);
        }
        let pkt = o == op::PKT_PROCESS;
        if pkt && !(cmd.proc_op == proto::proc_op::PASS || cmd.proc_op == proto::proc_op::XOR32 || cmd.proc_op == proto::proc_op::BSWAP32) {
            return (err::PROC_OP, false, 0);
        }
        if pkt && cmd.proc_op == proto::proc_op::BSWAP32 && d_len % 4 != 0 {
            return (err::PROC_OP, false, 0);
        }
        if cmd.sram_off % BEAT != 0 || (op::reads_host(o) && cmd.src % BEAT as u64 != 0) || (op::writes_host(o) && cmd.dst % BEAT as u64 != 0) {
            return (err::ALIGN, false, 0);
        }
        let psize = m.tenants[t].ef_size as u64;
        let len_al = (d_len.div_ceil(BEAT) * BEAT) as u64;
        let need = cmd.sram_off as u64 + if pkt { len_al * 2 } else { len_al };
        if cmd.sram_off as u64 > psize || need > psize {
            return (err::SRAM_RANGE, false, 0);
        }
        if op::reads_host(o) && !self.win_ok(t, cmd.src, d_len, true, false) {
            return (err::PERM_READ, false, cmd.src);
        }
        if op::writes_host(o) && !self.win_ok(t, cmd.dst, d_len, false, true) {
            return (err::PERM_WRITE, false, cmd.dst);
        }
        (err::NONE, false, 0)
    }

    /// Validation of an extension command (software extension of the contract).
    fn validate_ext(&self, q: u32, e: &ExtCmd) -> (u8, u64) {
        let m = &self.m;
        let qu = &m.queues[q as usize];
        let t = qu.bind as usize;
        match m.tenants[t].state {
            tstate::QUARANTINED => return (err::QUARANTINED, 0),
            tstate::ACTIVE => {}
            _ => return (err::TENANT_STATE, 0),
        }
        let rd = |a: u64, n: u32| self.win_ok(t, a, n, true, false);
        let wr = |a: u64, n: u32| self.win_ok(t, a, n, false, true);
        match e {
            ExtCmd::GemmI8 { a, b, c, m: mm, n, k, .. } => {
                if *mm == 0 || *n == 0 || *k == 0 || *mm > 64 || *n > 64 || *k > 64 {
                    return (ext_err::BAD_PARAM, 0);
                }
                if !rd(*a, mm * k) {
                    return (err::PERM_READ, *a);
                }
                if !rd(*b, k * n) {
                    return (err::PERM_READ, *b);
                }
                if !wr(*c, mm * n * 4) {
                    return (err::PERM_WRITE, *c);
                }
            }
            ExtCmd::AesGcm { encrypt, key, src, dst, tag_addr, len, .. } => {
                if !(key.len() == 16 || key.len() == 32) || *len == 0 || *len > m.c.max_xfer {
                    return (ext_err::BAD_PARAM, 0);
                }
                if !rd(*src, *len) {
                    return (err::PERM_READ, *src);
                }
                if !wr(*dst, *len) {
                    return (err::PERM_WRITE, *dst);
                }
                if *encrypt && !wr(*tag_addr, 16) {
                    return (err::PERM_WRITE, *tag_addr);
                }
                if !*encrypt && !rd(*tag_addr, 16) {
                    return (err::PERM_READ, *tag_addr);
                }
            }
            ExtCmd::StorageWrite { src, lba, blocks, .. } => {
                if !storage_range_ok(m, *lba, *blocks) {
                    return (ext_err::BAD_PARAM, 0);
                }
                if !rd(*src, blocks * 512) {
                    return (err::PERM_READ, *src);
                }
            }
            ExtCmd::StorageRead { lba, dst, blocks, .. } => {
                if !storage_range_ok(m, *lba, *blocks) {
                    return (ext_err::BAD_PARAM, 0);
                }
                if !wr(*dst, blocks * 512) {
                    return (err::PERM_WRITE, *dst);
                }
            }
        }
        (err::NONE, 0)
    }

    // ---------------------------------------------------------------------------- completion plumbing
    fn push_cpl(&mut self, q: u32, mut cpl: proto::Cpl, tenant: u32, fault_addr: u64) {
        cpl.tenant = tenant as u8;
        cpl.queue = q as u8;
        cpl.ts = p32(self.m.clock);
        let m = &mut self.m;
        // faults
        let e = cpl.err;
        let mut flt = 0u32;
        let mut addr_valid = false;
        if err::is_violation(e) {
            flt |= 1 << proto::flt::PERM_VIOL;
            addr_valid = true;
        }
        if e == err::HOST_MEM {
            flt |= 1 << proto::flt::HOST_ERR;
        }
        if e == err::SRAM_RESP {
            flt |= 1 << proto::flt::SRAM_ERR;
        }
        if e == err::INTERNAL {
            flt |= 1 << proto::flt::INTERNAL;
        }
        if e == err::TIMEOUT {
            flt |= 1 << proto::flt::TIMEOUT;
        }
        if matches!(e, err::BAD_DESC | err::BAD_OPCODE | err::BAD_LENGTH | err::ALIGN | err::PROC_OP | err::BAD_TENANT) && cpl.bytes == 0 {
            flt |= 1 << proto::flt::DESC_ERR;
        }
        if flt != 0 {
            m.fst |= flt;
            m.f_tenant = tenant;
            m.f_err = e as u32;
            if addr_valid {
                m.f_addr = fault_addr;
            }
        }
        // counters
        m.count(proto::reg::cnt::CMDS_RETIRED as usize, 1);
        if cpl.status != status::OK {
            m.count(proto::reg::cnt::CMDS_ERROR as usize, 1);
        }
        if e != err::NONE {
            m.count(proto::reg::cnt::ERR_EVENTS as usize, 1);
        }
        if err::is_violation(e) {
            m.count(proto::reg::cnt::VIOLATIONS as usize, 1);
        }
        if e == err::HOST_MEM {
            m.count(proto::reg::cnt::HOST_ERRORS as usize, 1);
        }
        if e == err::TIMEOUT {
            m.count(proto::reg::cnt::TIMEOUTS as usize, 1);
        }
        if e == err::BLOCKED {
            m.blocked_rejects += 1;
        }
        if let Some(p) = m.tperf.get_mut(tenant as usize) {
            p.cmds += 1;
            p.bytes += cpl.bytes as u64;
            if e != err::NONE {
                p.errors += 1;
            }
            if err::is_violation(e) {
                p.viol += 1;
            }
        }
        // telemetry
        if err::is_violation(e) {
            m.emit(tlm::VIOLATION, tenant, q, e as u32);
        } else {
            m.emit(tlm::CMD_RETIRE, tenant, q, (e as u32) << 8 | cpl.status as u32);
        }
        // tenant violation bookkeeping
        if err::is_violation(e) {
            if let Some(t) = m.tenants.get_mut(tenant as usize) {
                t.viol += 1;
                if t.policy && t.state == tstate::ACTIVE {
                    m.set_state(tenant as usize, tstate::QUARANTINED);
                }
            }
        }
        m.queues[q as usize].hw_cq.push_back(cpl.encode());
    }

    // ---------------------------------------------------------------------------- job execution
    fn job_cost(&self, e: &Entry) -> (u64, bool) {
        match e {
            Entry::Hw(c) => {
                let beats = c.len.div_ceil(4) as u64;
                match c.opcode {
                    op::PKT_PROCESS => (16 + beats * 3, true),
                    op::DMA_H2D | op::DMA_D2H => (12 + beats, true),
                    _ => (4, false),
                }
            }
            Entry::Ext(_) => (64, true),
        }
    }

    /// Execute a Hw job to completion, returning the completion record and fault address.
    fn exec_hw(&mut self, tenant: usize, c: &Cmd) -> proto::Cpl {
        let mut cpl = proto::Cpl { opcode: c.opcode, tag: c.tag, ..Default::default() };
        let t = &self.m.tenants[tenant];
        let in_abs = (t.ef_base + c.sram_off) as usize;
        let len_al = (c.len.div_ceil(4) * 4) as usize;
        let out_abs = in_abs + len_al;
        let fail = |cpl: &mut proto::Cpl, e: u8| {
            cpl.status = status::ERROR;
            cpl.err = e;
        };
        // ---- load
        if op::reads_host(c.opcode) {
            let (data, done, failed) = self.dev_read(c.src, c.len);
            self.m.count(proto::reg::cnt::DMA_BYTES_RD as usize, done as u64);
            // bytes of completed beats are staged into SRAM even if a later beat fails
            self.m.sram[in_abs..in_abs + data.len()].copy_from_slice(&data);
            if failed {
                fail(&mut cpl, err::HOST_MEM);
                return cpl;
            }
            if c.opcode == op::DMA_H2D {
                cpl.bytes = c.len;
                return cpl;
            }
        }
        // ---- PacketCore test adapter
        let input = self.m.sram[in_abs..in_abs + c.len as usize].to_vec();
        if c.opcode == op::PKT_PROCESS {
            self.m.pkt_jobs += 1;
            let out = proto::apply_proc(c.proc_op, c.param, &input).expect("validated");
            self.m.sram[out_abs..out_abs + out.len()].copy_from_slice(&out);
            cpl.crc_in = proto::crc32(&input);
            cpl.crc_out = proto::crc32(&out);
            cpl.csum = proto::csum1071(&out);
        }
        // ---- store
        let src_off = if c.opcode == op::PKT_PROCESS { out_abs } else { in_abs };
        let data = self.m.sram[src_off..src_off + c.len as usize].to_vec();
        let (written, failed) = self.dev_write(c.dst, &data);
        self.m.count(proto::reg::cnt::DMA_BYTES_WR as usize, written as u64);
        if failed {
            // bytes already acknowledged stay in host memory; the completion carries no bytes and no commit flag
            cpl = proto::Cpl { opcode: c.opcode, tag: c.tag, status: status::ERROR, err: err::HOST_MEM, ..Default::default() };
            return cpl;
        }
        cpl.bytes = c.len;
        cpl.flags |= proto::CPL_FLAG_COMMITTED;
        cpl
    }

    fn exec_ext(&mut self, tenant: usize, e: &ExtCmd) -> proto::Cpl {
        let mut cpl = proto::Cpl { tag: e.tag(), ..Default::default() };
        let bad = |cpl: &mut proto::Cpl, code: u8| {
            cpl.status = status::ERROR;
            cpl.err = code;
        };
        match e {
            ExtCmd::GemmI8 { a, b, c, m, n, k, .. } => {
                cpl.opcode = op::INFER;
                let (ad, _, f1) = self.dev_read(*a, m * k);
                let (bd, _, f2) = self.dev_read(*b, k * n);
                if f1 || f2 {
                    bad(&mut cpl, err::HOST_MEM);
                    return cpl;
                }
                let (m, n, k) = (*m as usize, *n as usize, *k as usize);
                let mut out = Vec::with_capacity(m * n * 4);
                for i in 0..m {
                    for j in 0..n {
                        let mut acc: i32 = 0;
                        for x in 0..k {
                            acc += (ad[i * k + x] as i8 as i32) * (bd[x * n + j] as i8 as i32);
                        }
                        out.extend_from_slice(&acc.to_le_bytes());
                    }
                }
                let (w, failed) = self.dev_write(*c, &out);
                let _ = w;
                if failed {
                    cpl = proto::Cpl { opcode: op::INFER, tag: e.tag(), status: status::ERROR, err: err::HOST_MEM, ..Default::default() };
                    return cpl;
                }
                cpl.bytes = out.len() as u32;
                cpl.flags |= proto::CPL_FLAG_COMMITTED;
            }
            ExtCmd::AesGcm { encrypt, key, iv, aad, src, dst, tag_addr, len, .. } => {
                cpl.opcode = op::CRYPTO;
                let (mut buf, _, f) = self.dev_read(*src, *len);
                if f {
                    bad(&mut cpl, err::HOST_MEM);
                    return cpl;
                }
                let nonce = GenericArray::from_slice(iv);
                if *encrypt {
                    let tag = if key.len() == 16 {
                        Aes128Gcm::new(GenericArray::from_slice(key)).encrypt_in_place_detached(nonce, aad, &mut buf)
                    } else {
                        Aes256Gcm::new(GenericArray::from_slice(key)).encrypt_in_place_detached(nonce, aad, &mut buf)
                    };
                    let tag = tag.expect("gcm encrypt");
                    let (_, f1) = self.dev_write(*dst, &buf);
                    let (_, f2) = self.dev_write(*tag_addr, tag.as_slice());
                    if f1 || f2 {
                        cpl = proto::Cpl { opcode: op::CRYPTO, tag: e.tag(), status: status::ERROR, err: err::HOST_MEM, ..Default::default() };
                        return cpl;
                    }
                } else {
                    let (tg, _, f) = self.dev_read(*tag_addr, 16);
                    if f {
                        bad(&mut cpl, err::HOST_MEM);
                        return cpl;
                    }
                    let tag = GenericArray::from_slice(&tg);
                    let ok = if key.len() == 16 {
                        Aes128Gcm::new(GenericArray::from_slice(key)).decrypt_in_place_detached(nonce, aad, &mut buf, tag)
                    } else {
                        Aes256Gcm::new(GenericArray::from_slice(key)).decrypt_in_place_detached(nonce, aad, &mut buf, tag)
                    };
                    if ok.is_err() {
                        // plaintext is NEVER released on authentication failure
                        bad(&mut cpl, ext_err::AUTH_FAIL);
                        return cpl;
                    }
                    let (_, f1) = self.dev_write(*dst, &buf);
                    if f1 {
                        cpl = proto::Cpl { opcode: op::CRYPTO, tag: e.tag(), status: status::ERROR, err: err::HOST_MEM, ..Default::default() };
                        return cpl;
                    }
                }
                cpl.bytes = *len;
                cpl.flags |= proto::CPL_FLAG_COMMITTED;
            }
            ExtCmd::StorageWrite { src, lba, blocks, .. } => {
                cpl.opcode = op::STORAGE;
                let (d, _, f) = self.dev_read(*src, blocks * 512);
                if f {
                    bad(&mut cpl, err::HOST_MEM);
                    return cpl;
                }
                for i in 0..*blocks as u64 {
                    let mut blkb = Box::new([0u8; 512]);
                    blkb.copy_from_slice(&d[(i * 512) as usize..(i * 512 + 512) as usize]);
                    self.m.storage[tenant].insert(lba + i, blkb);
                }
                cpl.bytes = blocks * 512;
                cpl.flags |= proto::CPL_FLAG_COMMITTED;
            }
            ExtCmd::StorageRead { lba, dst, blocks, .. } => {
                cpl.opcode = op::STORAGE;
                let mut out = Vec::with_capacity((*blocks * 512) as usize);
                for i in 0..*blocks as u64 {
                    match self.m.storage[tenant].get(&(lba + i)) {
                        Some(b) => out.extend_from_slice(&b[..]),
                        None => out.extend_from_slice(&[0u8; 512]), // unwritten blocks read as zero
                    }
                }
                let (_, failed) = self.dev_write(*dst, &out);
                if failed {
                    cpl = proto::Cpl { opcode: op::STORAGE, tag: e.tag(), status: status::ERROR, err: err::HOST_MEM, ..Default::default() };
                    return cpl;
                }
                cpl.bytes = out.len() as u32;
                cpl.flags |= proto::CPL_FLAG_COMMITTED;
            }
        }
        cpl
    }

    // ---------------------------------------------------------------------------- the scheduler step
    /// Returns true if something happened at the current clock.
    fn step(&mut self) -> bool {
        let mut progress = false;

        // ---- data-plane reset
        if self.m.reset_pending {
            self.m.reset_pending = false;
            progress = true;
            for s in 0..self.m.slots.len() {
                if let Some(job) = self.m.slots[s].take() {
                    let (q, t) = (job.queue, job.tenant);
                    self.m.tenants[t as usize].inflight = self.m.tenants[t as usize].inflight.saturating_sub(1);
                    self.m.queues[q as usize].reserved = self.m.queues[q as usize].reserved.saturating_sub(1);
                    if !job.zombie {
                        let tag = match &job.entry {
                            Entry::Hw(c) => (c.opcode, c.tag),
                            Entry::Ext(e) => (ext_opcode(e), e.tag()),
                        };
                        let cpl = proto::Cpl { opcode: tag.0, tag: tag.1, status: status::ABORTED, err: err::RESET_ABORT, ..Default::default() };
                        self.push_cpl(q, cpl, t, 0);
                    }
                }
            }
            self.m.halted = false;
            self.m.fst |= 1 << proto::flt::RESET_DONE;
            self.m.emit(tlm::DP_RESET, 0, 0, 0);
        }

        // ---- tenant housekeeping: drain -> scrub -> disabled
        for t in 0..self.m.tenants.len() {
            match self.m.tenants[t].state {
                tstate::DRAINING if self.m.tenants[t].inflight == 0 => {
                    self.m.set_state(t, tstate::SCRUBBING);
                    progress = true;
                }
                tstate::SCRUBBING => {
                    self.m.zero_partition(t);
                    self.m.tenants[t].cfg_ok = true;
                    self.m.set_state(t, tstate::DISABLED);
                    progress = true;
                }
                _ => {}
            }
        }

        // ---- finish jobs
        for s in 0..self.m.slots.len() {
            let Some(job) = &self.m.slots[s] else { continue };
            let age = self.m.clock - job.start;
            let hold_blocks = job.touches_host && self.hold_until > self.m.clock;
            let timed_out = !job.zombie && self.m.job_timeout != 0 && age >= self.m.job_timeout as u64;
            if timed_out {
                let (q, t) = (job.queue, job.tenant);
                let (opc, tag) = match &job.entry {
                    Entry::Hw(c) => (c.opcode, c.tag),
                    Entry::Ext(e) => (ext_opcode(e), e.tag()),
                };
                self.m.slots[s].as_mut().unwrap().zombie = true;
                self.m.halted = true;
                let cpl = proto::Cpl { opcode: opc, tag, status: status::ERROR, err: err::TIMEOUT, ..Default::default() };
                self.push_cpl(q, cpl, t, 0);
                progress = true;
                continue;
            }
            if job.zombie {
                // a zombie finishes (silently) once the host unblocks; its completion was already reported
                if job.done_at <= self.m.clock && !hold_blocks {
                    // the late write would land now; the model drops it (the host window still guards it)
                    // the slot stays counted until DP_RESET, like the RTL
                }
                continue;
            }
            if job.done_at <= self.m.clock && !hold_blocks {
                let job = self.m.slots[s].take().unwrap();
                let tenant = job.tenant as usize;
                let cpl = match &job.entry {
                    Entry::Hw(c) => self.exec_hw(tenant, c),
                    Entry::Ext(e) => self.exec_ext(tenant, e),
                };
                self.m.tenants[tenant].inflight -= 1;
                self.m.queues[job.queue as usize].reserved -= 1;
                self.push_cpl(job.queue, cpl, job.tenant, 0);
                progress = true;
            }
        }

        // ---- dispatch: round robin over queues that have a descriptor and a completion credit
        if self.m.ctl_en && !self.m.halted {
            let n = self.m.queues.len();
            for k in 0..n {
                let q = (self.m.rr + k) % n;
                let credit = {
                    let qu = &self.m.queues[q];
                    (qu.hw_cq.len() as u32 + qu.reserved) < self.m.c.cplq_depth
                };
                if self.m.queues[q].sq.is_empty() || !credit {
                    continue;
                }
                // decode
                let verdict = match self.m.queues[q].sq.front().unwrap() {
                    Entry::Hw(c) => {
                        let c = *c;
                        self.validate(q as u32, &c)
                    }
                    Entry::Ext(e) => {
                        let (er, fa) = self.validate_ext(q as u32, e);
                        (er, false, fa)
                    }
                };
                let tenant = self.m.queues[q].bind;
                if verdict.0 != err::NONE || verdict.1 {
                    let entry = self.m.queues[q].sq.pop_front().unwrap();
                    let (opc, tag, len) = match &entry {
                        Entry::Hw(c) => (c.opcode, c.tag, c.len),
                        Entry::Ext(e) => (ext_opcode(e), e.tag(), 0),
                    };
                    let _ = len;
                    let cpl = proto::Cpl {
                        opcode: opc,
                        tag,
                        status: if verdict.0 == err::NONE { status::OK } else { status::ERROR },
                        err: verdict.0,
                        txn: self.m.txn_ctr,
                        ..Default::default()
                    };
                    self.push_cpl(q as u32, cpl, tenant, verdict.2);
                    self.m.rr = (q + 1) % n;
                    progress = true;
                    break;
                }
                // needs a free slot
                if let Some(free) = self.m.slots.iter().position(|s| s.is_none()) {
                    let entry = self.m.queues[q].sq.pop_front().unwrap();
                    let (dur, touches) = self.job_cost(&entry);
                    self.m.txn_ctr = self.m.txn_ctr.wrapping_add(1);
                    self.m.tenants[tenant as usize].inflight += 1;
                    self.m.queues[q].reserved += 1;
                    self.m.slots[free] = Some(Job { entry, queue: q as u32, tenant, start: self.m.clock, done_at: self.m.clock + dur, zombie: false, touches_host: touches });
                    self.m.rr = (q + 1) % n;
                    progress = true;
                    break;
                }
            }
        }

        // ---- completion consumers: hardware CQ -> host ring
        for qu in self.m.queues.iter_mut() {
            while qu.consumer_ready && qu.ring.len() < RING_MAX && !qu.hw_cq.is_empty() {
                let r = qu.hw_cq.pop_front().unwrap();
                qu.completed += 1;
                if (r[0] >> 8) & 0xFF != 0 {
                    qu.rejected += 1;
                }
                qu.ring.push_back(r);
                progress = true;
            }
        }
        progress
    }

    fn next_event(&self) -> Option<u64> {
        let mut t: Option<u64> = None;
        let mut upd = |x: u64| {
            if x > self.m.clock {
                t = Some(t.map_or(x, |y| y.min(x)));
            }
        };
        for j in self.m.slots.iter().flatten() {
            if !j.zombie {
                upd(j.done_at);
                if self.m.job_timeout != 0 {
                    upd(j.start + self.m.job_timeout as u64);
                }
                if j.touches_host {
                    upd(self.hold_until);
                }
            }
        }
        t
    }
}

/// Attacker-controlled LBA/length: all arithmetic in u64 with checked addition (a wrapped range must be refused,
/// never accepted, and must never panic the device model).
fn storage_range_ok(m: &Model, lba: u64, blocks: u32) -> bool {
    let bytes = blocks as u64 * 512;
    blocks != 0 && bytes <= m.c.max_xfer as u64 * 16 && lba.checked_add(blocks as u64).is_some_and(|end| end <= m.c.storage_blocks)
}

fn ext_opcode(e: &ExtCmd) -> u8 {
    match e {
        ExtCmd::GemmI8 { .. } => op::INFER,
        ExtCmd::AesGcm { .. } => op::CRYPTO,
        _ => op::STORAGE,
    }
}

impl Backend for CpuRefBackend {
    fn info(&self) -> BackendInfo {
        self.info.clone()
    }

    fn mgmt_read(&mut self, addr: u32) -> Result<u32, DevError> {
        self.m.read(addr)
    }

    fn mgmt_write(&mut self, addr: u32, val: u32) -> Result<(), DevError> {
        let be = DevError::BusError(addr);
        if !(0x4000_8000..0x4001_0000).contains(&addr) || addr % 4 != 0 {
            return Err(be);
        }
        let page = (addr - 0x4000_8000) >> 12;
        let off = addr & 0xFFF;
        let ok = match page {
            0 => self.m.write_global(off, val),
            1 => self.m.write_tenant(off, val),
            2 => self.m.write_queue(off, val),
            4 => self.m.write_perf(off, val),
            5 if off == 0 => {
                self.m.tlm_en = val & 1 != 0;
                true
            }
            _ => false,
        };
        if ok {
            Ok(())
        } else {
            Err(be)
        }
    }

    fn submit(&mut self, queue: u32, cmd: &[u32; 12]) -> Result<(), DevError> {
        if queue > 15 {
            return Err(DevError::BadArg(format!("queue id {queue} does not fit the 4-bit queue select")));
        }
        if queue >= self.m.nqh() {
            // Observed on the RTL: the shared submission bus accepts a descriptor selecting a queue that does not
            // exist (or the firmware-only management queue 15) and DISCARDS it -- no completion, no data movement.
            return Ok(());
        }
        let q = &mut self.m.queues[queue as usize];
        if q.sq.len() as u32 >= self.m.c.queue_depth {
            return Err(DevError::QueueFull);
        }
        q.sq.push_back(Entry::Hw(Cmd::decode(cmd)));
        q.submitted += 1;
        self.m.count(proto::reg::cnt::CMDS_ACCEPTED as usize, 1);
        Ok(())
    }

    fn submit_ext(&mut self, queue: u32, ext: &ExtCmd) -> Result<(), DevError> {
        if queue >= self.m.nqh() {
            return Err(DevError::BadArg(format!("queue {queue} does not exist")));
        }
        let q = &mut self.m.queues[queue as usize];
        if q.sq.len() as u32 >= self.m.c.queue_depth {
            return Err(DevError::QueueFull);
        }
        q.sq.push_back(Entry::Ext(ext.clone()));
        q.submitted += 1;
        self.m.count(proto::reg::cnt::CMDS_ACCEPTED as usize, 1);
        Ok(())
    }

    fn pop_completion(&mut self, queue: u32) -> Option<[u32; 8]> {
        self.m.queues.get_mut(queue as usize)?.ring.pop_front()
    }

    fn advance(&mut self, cycles: u64) -> u64 {
        let end = self.m.clock + cycles;
        let mut guard = 0u32;
        loop {
            let progressed = self.step();
            guard += 1;
            if progressed && guard < 1_000_000 {
                continue;
            }
            // nothing more to do at this instant: jump to the next event (or the end of the budget)
            match self.next_event() {
                Some(t) if t <= end => self.m.clock = t,
                _ => break,
            }
            guard = 0;
        }
        self.m.clock = end;
        // one more pass so that work becoming eligible exactly at `end` is visible
        self.step();
        cycles
    }

    fn cycles(&self) -> u64 {
        self.m.clock
    }

    fn dpu_time_exact(&mut self) -> Option<u64> {
        Some(self.m.clock) // the model's TIME register IS its logical clock
    }

    fn pop_telemetry(&mut self) -> Option<[u32; 3]> {
        self.m.tlm.pop_front()
    }

    fn host_write(&mut self, iova: u64, data: &[u8]) -> Result<(), DevError> {
        if !self.in_range(iova, data.len() as u64) {
            return Err(DevError::BadArg(format!("host memory write outside simulated DRAM: 0x{iova:x}+{}", data.len())));
        }
        let o = (iova - self.m.c.iova_base) as usize;
        self.hm[o..o + data.len()].copy_from_slice(data);
        Ok(())
    }

    fn host_read(&mut self, iova: u64, out: &mut [u8]) -> Result<(), DevError> {
        if !self.in_range(iova, out.len() as u64) {
            return Err(DevError::BadArg(format!("host memory read outside simulated DRAM: 0x{iova:x}+{}", out.len())));
        }
        let o = (iova - self.m.c.iova_base) as usize;
        out.copy_from_slice(&self.hm[o..o + out.len()]);
        Ok(())
    }

    fn reset(&mut self) -> Result<(), DevError> {
        let cfgc = self.m.c.clone();
        let clock = self.m.clock;
        // SRAM contents are never cleared by a reset (only the tenant scrubber clears memory), like the RTL
        let sram = std::mem::take(&mut self.m.sram);
        let storage = std::mem::take(&mut self.m.storage);
        self.m = Model::new(cfgc);
        self.m.sram = sram;
        self.m.storage = storage;
        self.m.clock = clock;
        self.hold_until = 0;
        Ok(())
    }

    fn sim(&mut self) -> Option<&mut dyn SimControl> {
        Some(self)
    }
}

impl SimControl for CpuRefBackend {
    fn inject_host_error(&mut self, lo: u64, hi: u64) {
        self.err_ranges.push((lo, hi));
    }
    fn clear_host_errors(&mut self) {
        self.err_ranges.clear();
    }
    fn hold_host(&mut self, cycles: u64) {
        self.hold_until = self.m.clock + cycles;
    }
    fn set_host_params(&mut self, _lat_max: u32, _bp_pct: u32) {}
    fn set_completion_consumer(&mut self, queue: u32, ready: bool) {
        if let Some(q) = self.m.queues.get_mut(queue as usize) {
            q.consumer_ready = ready;
        }
    }
    fn host_stats(&self) -> HostStats {
        self.stats
    }
    fn drain_access_log(&mut self) -> Vec<Access> {
        self.log.drain(..).collect()
    }
    fn enable_access_log(&mut self, on: bool) {
        self.log_on = on;
    }
    fn sram_peek(&mut self, offset: u32, out: &mut [u8]) -> Result<(), DevError> {
        let o = offset as usize;
        if o + out.len() > self.m.sram.len() {
            return Err(DevError::BadArg("SRAM peek outside the device SRAM".into()));
        }
        out.copy_from_slice(&self.m.sram[o..o + out.len()]);
        Ok(())
    }
}
