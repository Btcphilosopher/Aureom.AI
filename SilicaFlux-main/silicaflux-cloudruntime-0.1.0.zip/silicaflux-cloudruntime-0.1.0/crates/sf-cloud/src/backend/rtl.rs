//! `rtl-sim` backend: drives the Verilator model of the vendored Project 61 CloudDPU through the C API in
//! `rtl/sim/sf_rtl_api.h`.  The shared library is loaded at run time, so the runtime builds and works without
//! Verilator; the backend is simply "unavailable" when the library has not been built.

use super::*;
use libloading::Library;
use std::ffi::{c_char, c_int, c_void, CStr};

#[repr(C)]
struct SfrtlOptions {
    struct_size: u32,
    host_mem_bytes: u32,
    host_lat_max: u32,
    host_bp_pct: u32,
    seed: u64,
    access_log: u32,
    reserved: u32,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct SfrtlBuildInfo {
    api_version: u32,
    num_tenants: u32,
    num_net_queues: u32,
    num_compute_queues: u32,
    num_dma_channels: u32,
    data_width: u32,
    address_width: u32,
    num_windows: u32,
    sram_bytes: u32,
    _pad: u32,
    host_mem_base: u64,
    host_mem_bytes: u64,
    design: [c_char; 32],
    config_name: [c_char; 16],
    verilator: [c_char; 24],
}

#[repr(C)]
#[derive(Default, Clone, Copy)]
struct SfrtlHostStats {
    reads: u64,
    writes: u64,
    bytes_rd: u64,
    bytes_wr: u64,
    wild: u64,
    injected_errors: u64,
    outstanding: u32,
    reserved: u32,
}

#[repr(C)]
#[derive(Default, Clone, Copy)]
struct SfrtlAccess {
    cycle: u64,
    addr: u64,
    write: u32,
    bytes: u32,
}

type FnAbi = unsafe extern "C" fn() -> u32;
type FnOpen = unsafe extern "C" fn(*const SfrtlOptions, *mut c_char, usize) -> *mut c_void;
type FnClose = unsafe extern "C" fn(*mut c_void);
type FnBuild = unsafe extern "C" fn(*const c_void, *mut SfrtlBuildInfo);
type FnReset = unsafe extern "C" fn(*mut c_void, u32) -> c_int;
type FnMgmt = unsafe extern "C" fn(*mut c_void, c_int, u32, u32, *mut u32, u32) -> c_int;
type FnSubmit = unsafe extern "C" fn(*mut c_void, u32, *const u32, u32) -> c_int;
type FnCplPop = unsafe extern "C" fn(*mut c_void, u32, *mut u32) -> c_int;
type FnRun = unsafe extern "C" fn(*mut c_void, u64) -> u64;
type FnCycles = unsafe extern "C" fn(*const c_void) -> u64;
type FnMemW = unsafe extern "C" fn(*mut c_void, u64, *const c_void, usize) -> c_int;
type FnMemR = unsafe extern "C" fn(*const c_void, u64, *mut c_void, usize) -> c_int;
type FnTlm = unsafe extern "C" fn(*mut c_void, *mut u32) -> c_int;
type FnHostParams = unsafe extern "C" fn(*mut c_void, u32, u32);
type FnInject = unsafe extern "C" fn(*mut c_void, u64, u64);
type FnVoid = unsafe extern "C" fn(*mut c_void);
type FnHold = unsafe extern "C" fn(*mut c_void, u64);
type FnStats = unsafe extern "C" fn(*const c_void, *mut SfrtlHostStats);
type FnReady = unsafe extern "C" fn(*mut c_void, u32, c_int);
type FnAccPop = unsafe extern "C" fn(*mut c_void, *mut SfrtlAccess) -> c_int;
type FnPeek = unsafe extern "C" fn(*const c_void, u32, *mut c_void, usize) -> c_int;
type FnDpuTime = unsafe extern "C" fn(*const c_void) -> u64;

struct Fns {
    close: FnClose,
    build: FnBuild,
    reset: FnReset,
    mgmt: FnMgmt,
    submit: FnSubmit,
    cpl_pop: FnCplPop,
    run: FnRun,
    cycles: FnCycles,
    mem_w: FnMemW,
    mem_r: FnMemR,
    tlm_pop: FnTlm,
    host_params: FnHostParams,
    inject: FnInject,
    clear_err: FnVoid,
    hold: FnHold,
    stats: FnStats,
    cpl_ready: FnReady,
    acc_pop: FnAccPop,
    sram_peek: FnPeek,
    dpu_time: FnDpuTime,
}

pub struct RtlBackend {
    _lib: Library,
    f: Fns,
    h: *mut c_void,
    info: BackendInfo,
    log_on: bool,
    lib_path: String,
}

// The handle is only ever used from one thread at a time (the mediator holds the backend behind a mutex).
unsafe impl Send for RtlBackend {}

const MGMT_BUDGET: u32 = 400_000;
const SUBMIT_BUDGET: u32 = 4_000;

fn cstr(a: &[c_char]) -> String {
    unsafe { CStr::from_ptr(a.as_ptr()) }.to_string_lossy().into_owned()
}

impl RtlBackend {
    pub fn open(spec: &BackendSpec) -> Result<RtlBackend, DevError> {
        let path = match &spec.lib {
            Some(p) => std::path::PathBuf::from(p),
            None => find_rtl_library(&spec.config).ok_or_else(|| {
                DevError::Unavailable(format!(
                    "RTL simulation library for geometry '{}' not found; build it with `make -C rtl/sim CFG={}` or set SF_RTL_LIB",
                    spec.config, spec.config
                ))
            })?,
        };
        let lib = unsafe { Library::new(&path) }.map_err(|e| DevError::Unavailable(format!("cannot load {}: {e}", path.display())))?;
        macro_rules! sym {
            ($name:literal, $ty:ty) => {{
                let s: libloading::Symbol<$ty> =
                    unsafe { lib.get($name) }.map_err(|e| DevError::Unavailable(format!("{}: missing symbol {}: {e}", path.display(), String::from_utf8_lossy($name))))?;
                *s
            }};
        }
        let abi: FnAbi = sym!(b"sfrtl_abi_version", FnAbi);
        let v = unsafe { abi() };
        if v != 1 {
            return Err(DevError::Unavailable(format!("RTL library ABI version {v}, runtime expects 1")));
        }
        let open: FnOpen = sym!(b"sfrtl_open", FnOpen);
        let f = Fns {
            close: sym!(b"sfrtl_close", FnClose),
            build: sym!(b"sfrtl_build_info_get", FnBuild),
            reset: sym!(b"sfrtl_hard_reset", FnReset),
            mgmt: sym!(b"sfrtl_mgmt", FnMgmt),
            submit: sym!(b"sfrtl_submit", FnSubmit),
            cpl_pop: sym!(b"sfrtl_cpl_pop", FnCplPop),
            run: sym!(b"sfrtl_run", FnRun),
            cycles: sym!(b"sfrtl_cycles", FnCycles),
            mem_w: sym!(b"sfrtl_hostmem_write", FnMemW),
            mem_r: sym!(b"sfrtl_hostmem_read", FnMemR),
            tlm_pop: sym!(b"sfrtl_tlm_pop", FnTlm),
            host_params: sym!(b"sfrtl_host_params", FnHostParams),
            inject: sym!(b"sfrtl_host_inject_error", FnInject),
            clear_err: sym!(b"sfrtl_host_clear_errors", FnVoid),
            hold: sym!(b"sfrtl_host_hold", FnHold),
            stats: sym!(b"sfrtl_host_stats_get", FnStats),
            cpl_ready: sym!(b"sfrtl_cpl_ready_set", FnReady),
            acc_pop: sym!(b"sfrtl_access_pop", FnAccPop),
            sram_peek: sym!(b"sfrtl_sram_peek", FnPeek),
            dpu_time: sym!(b"sfrtl_dpu_time", FnDpuTime),
        };
        let opt = SfrtlOptions {
            struct_size: std::mem::size_of::<SfrtlOptions>() as u32,
            host_mem_bytes: spec.host_mem_bytes,
            host_lat_max: spec.host_lat_max,
            host_bp_pct: spec.host_bp_pct,
            seed: spec.seed,
            access_log: spec.access_log as u32,
            reserved: 0,
        };
        let mut err = [0 as c_char; 256];
        let h = unsafe { open(&opt, err.as_mut_ptr(), err.len()) };
        if h.is_null() {
            return Err(DevError::Unavailable(format!("sfrtl_open failed: {}", cstr(&err))));
        }
        let mut bi: SfrtlBuildInfo = unsafe { std::mem::zeroed() };
        unsafe { (f.build)(h, &mut bi) };
        let mut be = RtlBackend {
            _lib: lib,
            f,
            h,
            info: BackendInfo {
                kind: BackendKind::RtlSim,
                name: "rtl-sim".into(),
                description: String::new(),
                timing: TimingModel::RtlSimulation,
                caps: Caps::default(),
                iova_base: bi.host_mem_base,
                iova_size: bi.host_mem_bytes,
                measured_on_hardware: false,
                details: vec![],
            },
            log_on: spec.access_log,
            lib_path: path.display().to_string(),
        };
        // Capabilities come from the DPU itself (BLOCK_STATUS), not from assumptions.
        let blk = be.mgmt_read(crate::proto::reg::G_BLOCK_STATUS)?;
        let id = be.mgmt_read(crate::proto::reg::G_ID)?;
        if id != crate::proto::DPU_ID_MAGIC {
            return Err(DevError::Failed(format!("DPU ID register reads 0x{id:08x}, expected 0x{:08x}", crate::proto::DPU_ID_MAGIC)));
        }
        use crate::proto::blk;
        let st = |shift: u32| (blk >> shift) & 3;
        be.info.caps = Caps {
            nop: true,
            dma: st(2) == blk::REAL,
            pkt_process: st(0) == blk::TEST_ADAPTER || st(0) == blk::REAL,
            gemm_i8: st(6) == blk::REAL,
            aes_gcm: st(8) == blk::REAL,
            storage: st(10) == blk::REAL,
            telemetry: st(12) == blk::REAL,
        };
        be.info.description = format!(
            "Verilator {} cycle-accurate simulation of {} (Project 61 RTL, vendored unmodified), geometry '{}'",
            cstr(&bi.verilator),
            cstr(&bi.design),
            cstr(&bi.config_name)
        );
        be.info.details = vec![
            ("library".into(), be.lib_path.clone()),
            ("verilator".into(), cstr(&bi.verilator)),
            ("geometry".into(), cstr(&bi.config_name)),
            ("build_tenants".into(), bi.num_tenants.to_string()),
            ("build_net_queues".into(), bi.num_net_queues.to_string()),
            ("build_compute_queues".into(), bi.num_compute_queues.to_string()),
            ("build_dma_channels".into(), bi.num_dma_channels.to_string()),
            ("block_status".into(), format!("0x{blk:04x}")),
            ("packetcore".into(), blk::name(st(0)).into()),
            ("host_data_path".into(), "SFB2 32-bit, simulated host DRAM with randomised latency".into()),
            ("control_firmware".into(), "not loaded (ControlCore idles in boot ROM; host drives the register pages)".into()),
        ];
        Ok(be)
    }
}

impl Drop for RtlBackend {
    fn drop(&mut self) {
        if !self.h.is_null() {
            unsafe { (self.f.close)(self.h) };
            self.h = std::ptr::null_mut();
        }
    }
}

impl Backend for RtlBackend {
    fn info(&self) -> BackendInfo {
        self.info.clone()
    }

    fn mgmt_read(&mut self, addr: u32) -> Result<u32, DevError> {
        let mut v = 0u32;
        match unsafe { (self.f.mgmt)(self.h, 0, addr, 0, &mut v, MGMT_BUDGET) } {
            0 => Ok(v),
            1 => Err(DevError::BusError(addr)),
            _ => Err(DevError::Timeout(format!("management read 0x{addr:08x}"))),
        }
    }

    fn mgmt_write(&mut self, addr: u32, val: u32) -> Result<(), DevError> {
        match unsafe { (self.f.mgmt)(self.h, 1, addr, val, std::ptr::null_mut(), MGMT_BUDGET) } {
            0 => Ok(()),
            1 => Err(DevError::BusError(addr)),
            _ => Err(DevError::Timeout(format!("management write 0x{addr:08x}"))),
        }
    }

    fn submit(&mut self, queue: u32, cmd: &[u32; 12]) -> Result<(), DevError> {
        match unsafe { (self.f.submit)(self.h, queue, cmd.as_ptr(), SUBMIT_BUDGET) } {
            0 => Ok(()),
            -1 => Err(DevError::QueueFull),
            _ => Err(DevError::BadArg(format!("queue {queue}"))),
        }
    }

    fn pop_completion(&mut self, queue: u32) -> Option<[u32; 8]> {
        let mut w = [0u32; 8];
        if unsafe { (self.f.cpl_pop)(self.h, queue, w.as_mut_ptr()) } == 1 {
            Some(w)
        } else {
            None
        }
    }

    fn advance(&mut self, cycles: u64) -> u64 {
        unsafe { (self.f.run)(self.h, cycles) }
    }

    fn cycles(&self) -> u64 {
        unsafe { (self.f.cycles)(self.h) }
    }

    fn pop_telemetry(&mut self) -> Option<[u32; 3]> {
        let mut w = [0u32; 3];
        if unsafe { (self.f.tlm_pop)(self.h, w.as_mut_ptr()) } == 1 {
            Some(w)
        } else {
            None
        }
    }

    fn host_write(&mut self, iova: u64, data: &[u8]) -> Result<(), DevError> {
        match unsafe { (self.f.mem_w)(self.h, iova, data.as_ptr() as *const c_void, data.len()) } {
            0 => Ok(()),
            _ => Err(DevError::BadArg(format!("host memory write outside simulated DRAM: 0x{iova:x}+{}", data.len()))),
        }
    }

    fn host_read(&mut self, iova: u64, out: &mut [u8]) -> Result<(), DevError> {
        match unsafe { (self.f.mem_r)(self.h, iova, out.as_mut_ptr() as *mut c_void, out.len()) } {
            0 => Ok(()),
            _ => Err(DevError::BadArg(format!("host memory read outside simulated DRAM: 0x{iova:x}+{}", out.len()))),
        }
    }

    fn reset(&mut self) -> Result<(), DevError> {
        match unsafe { (self.f.reset)(self.h, 400_000) } {
            0 => Ok(()),
            _ => Err(DevError::Timeout("device did not come back after reset".into())),
        }
    }

    fn dpu_time_exact(&mut self) -> Option<u64> {
        Some(unsafe { (self.f.dpu_time)(self.h) })
    }

    fn sim(&mut self) -> Option<&mut dyn SimControl> {
        Some(self)
    }
}

impl SimControl for RtlBackend {
    fn inject_host_error(&mut self, lo: u64, hi: u64) {
        unsafe { (self.f.inject)(self.h, lo, hi) }
    }
    fn clear_host_errors(&mut self) {
        unsafe { (self.f.clear_err)(self.h) }
    }
    fn hold_host(&mut self, cycles: u64) {
        unsafe { (self.f.hold)(self.h, cycles) }
    }
    fn set_host_params(&mut self, lat_max: u32, bp_pct: u32) {
        unsafe { (self.f.host_params)(self.h, lat_max, bp_pct) }
    }
    fn set_completion_consumer(&mut self, queue: u32, ready: bool) {
        unsafe { (self.f.cpl_ready)(self.h, queue, ready as c_int) }
    }
    fn host_stats(&self) -> HostStats {
        let mut s = SfrtlHostStats::default();
        unsafe { (self.f.stats)(self.h, &mut s) };
        HostStats { reads: s.reads, writes: s.writes, bytes_rd: s.bytes_rd, bytes_wr: s.bytes_wr, wild: s.wild, injected_errors: s.injected_errors }
    }
    fn drain_access_log(&mut self) -> Vec<Access> {
        let mut v = Vec::new();
        let mut a = SfrtlAccess::default();
        while unsafe { (self.f.acc_pop)(self.h, &mut a) } == 1 {
            v.push(Access { cycle: a.cycle, addr: a.addr, write: a.write != 0, bytes: a.bytes });
        }
        v
    }
    fn enable_access_log(&mut self, on: bool) {
        // The log is enabled at open time (options.access_log); this only records the caller's intent.
        self.log_on = on;
    }
    fn sram_peek(&mut self, offset: u32, out: &mut [u8]) -> Result<(), DevError> {
        match unsafe { (self.f.sram_peek)(self.h, offset, out.as_mut_ptr() as *mut c_void, out.len()) } {
            0 => Ok(()),
            _ => Err(DevError::BadArg(format!("SRAM peek outside the device SRAM: +{offset}..+{}", offset as usize + out.len()))),
        }
    }
}
