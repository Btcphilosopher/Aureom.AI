//! SilicaFlux CloudRuntime -- host runtime for the SilicaFlux CloudDPU.
//!
//! Layering (see docs/01_ARCHITECTURE.md):
//!
//! ```text
//! cloud application -> C ABI (ffi) / Rust API (Session)
//!                   -> Mediator  (tenants, buffers, tickets, keys, reset, health)   [privileged]
//!                   -> Backend   (cpu-ref | rtl-sim | hw)                           [device contract]
//!                   -> SilicaFlux CloudDPU -> engine -> completion
//! ```
pub mod alloc;
pub mod backend;
pub mod container;
pub mod ffi;
pub mod mediator;
pub mod proto;
pub mod status;
pub mod telemetry;

/// Runtime (crate) version.
pub const RUNTIME_VERSION: &str = env!("CARGO_PKG_VERSION");
/// RTL the `rtl-sim` backend simulates: Project 61 CloudDPU, `silicaflux_cloud_pkg::DPU_RTL_VER`.
pub const DPU_RTL_VERSION: &str = "P61-RTL-1.0 (0x00010000)";
/// Version of the stable C ABI (`include/sf_cloud.h`).  Breaking changes bump the major.
pub const ABI_MAJOR: u32 = 1;
pub const ABI_MINOR: u32 = 0;
