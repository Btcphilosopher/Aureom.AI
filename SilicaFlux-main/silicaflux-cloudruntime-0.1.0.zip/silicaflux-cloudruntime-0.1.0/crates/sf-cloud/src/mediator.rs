//! The privileged mediation layer.
//!
//! One [`Mediator`] owns one device backend and is the *only* component that touches the management plane,
//! provisions tenants, programs DMA windows, and builds queue descriptors.  Tenants get a [`Session`]: a
//! capability that can only operate on objects of its own tenant.
//!
//! Invariants enforced here (each is covered by `tests/security.rs` and `tests/reliability.rs`):
//!
//! * **Buffer lifetime** -- handles carry a generation; a freed or foreign handle is `StaleHandle`.  A buffer is
//!   pinned while any command that references it is in flight, and the pin is released **only by the device's
//!   completion record for that exact command** (never by a user-side timeout or cancel), so freed memory can
//!   never be the target of a late DMA.  Memory is scrubbed before it can be reused.
//! * **Device access permissions** -- a buffer is placed in the tenant's read-only or read/write host window
//!   according to its `DEV_READ` / `DEV_WRITE` usage, so the hardware window check enforces the permission too.
//! * **Tenant isolation** -- the tenant of a command is the tenant of the *queue* (hardware binding), tickets,
//!   keys and completions are tenant-owned, and foreign handles are indistinguishable from freed ones.
//! * **Completion visibility** -- a completion is delivered only to the ticket that owns its (queue, tag); a
//!   completion whose tenant field disagrees with the ticket's tenant is an integrity violation, not a result.
//! * **Bounded waiting** -- every wait has a wall-clock and a device-cycle budget and returns `Timeout`.

use crate::alloc::RangeAlloc;
use crate::backend::{Backend, BackendInfo, Caps, DevError, ExtCmd, SimControl};
use crate::proto::{self, blk, cfg as pcfg, err as perr, op as pop, reg, tcmd, tstate, Cmd, Cpl, TlmEvent};
use crate::status::{err, SfError, SfResult, Status};
use std::collections::{BTreeMap, HashMap, VecDeque};
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::{Duration, Instant};

pub const BUF_ALIGN: u64 = 64;
const IOVA_PAGE: u64 = 4096;
const PUMP_CYCLES: u64 = 128;
const MAX_FINISHED_UNREAPED: usize = 1024;
const EVENT_RING: usize = 8192;
pub const LAT_BUCKETS: [u64; 7] = [256, 1024, 4096, 16384, 65536, 262144, u64::MAX];

// ------------------------------------------------------------------------------------------------ flags
pub mod alloc_flags {
    /// Host memory the device can DMA from/to (default).
    pub const HOST: u32 = 0;
    /// Device-local memory (the tenant's SRAM partition); not CPU-accessible.
    pub const DEVICE: u32 = 1;
    /// The device may read the buffer (input).
    pub const DEV_READ: u32 = 2;
    /// The device may write the buffer (output).
    pub const DEV_WRITE: u32 = 4;
}

// ------------------------------------------------------------------------------------------------ handles
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct BufHandle(pub u64);
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Ticket(pub u64);
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct KeyHandle(pub u64);

/// Handle layout: `epoch(16) | generation(16) | tenant(8) | index(24)`.  The epoch is unique per mediator
/// instance, so a handle held across a runtime restart can never alias an object of the new instance; the
/// generation changes every time a slot is reused, so a handle to a freed object can never alias a new one.
fn pack_handle(epoch: u16, gen: u16, tenant: u32, idx: u32) -> u64 {
    (epoch as u64) << 48 | (gen as u64) << 32 | (tenant as u64 & 0xFF) << 24 | idx as u64 & 0xFF_FFFF
}
fn unpack_handle(h: u64) -> (u16, u16, u32, u32) {
    ((h >> 48) as u16, (h >> 32) as u16, ((h >> 24) & 0xFF) as u32, (h & 0xFF_FFFF) as u32)
}

static EPOCH_COUNTER: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);
fn next_epoch() -> u16 {
    use std::sync::atomic::Ordering;
    // random start per process (so restarts of the whole process differ), then strictly increasing
    let _ = EPOCH_COUNTER.compare_exchange(0, 1 + (u32::from_le_bytes(random_bytes::<4>()) & 0x7FFF), Ordering::SeqCst, Ordering::SeqCst);
    (EPOCH_COUNTER.fetch_add(1, Ordering::SeqCst) & 0xFFFF) as u16
}

// ------------------------------------------------------------------------------------------------ operations
#[derive(Clone, Debug)]
pub enum Op {
    /// Queue round trip, no data.
    Nop,
    /// host `src` -> device staging -> PacketCore -> device staging -> host `dst`.
    PktProcess {
        src: BufHandle,
        src_off: u64,
        dst: BufHandle,
        dst_off: u64,
        len: u64,
        proc_op: u8,
        param: u32,
    },
    /// Protected memory copy: PktProcess with PASS; the completion carries CRC-32 of source and destination.
    Copy {
        src: BufHandle,
        src_off: u64,
        dst: BufHandle,
        dst_off: u64,
        len: u64,
    },
    /// host -> device-local buffer.
    DmaH2d {
        src: BufHandle,
        src_off: u64,
        dst: BufHandle,
        dst_off: u64,
        len: u64,
    },
    /// device-local buffer -> host.
    DmaD2h {
        src: BufHandle,
        src_off: u64,
        dst: BufHandle,
        dst_off: u64,
        len: u64,
    },
    GemmI8 {
        a: BufHandle,
        a_off: u64,
        b: BufHandle,
        b_off: u64,
        c: BufHandle,
        c_off: u64,
        m: u32,
        n: u32,
        k: u32,
    },
    AesGcm {
        key: KeyHandle,
        encrypt: bool,
        iv: [u8; 12],
        aad: Vec<u8>,
        src: BufHandle,
        src_off: u64,
        dst: BufHandle,
        dst_off: u64,
        tag: BufHandle,
        tag_off: u64,
        len: u32,
    },
    StorageWrite {
        src: BufHandle,
        src_off: u64,
        lba: u64,
        blocks: u32,
    },
    StorageRead {
        dst: BufHandle,
        dst_off: u64,
        lba: u64,
        blocks: u32,
    },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum OpKind {
    Nop,
    PktProcess,
    Copy,
    DmaH2d,
    DmaD2h,
    GemmI8,
    AesGcm,
    StorageWrite,
    StorageRead,
}

impl OpKind {
    pub const ALL: [OpKind; 9] =
        [OpKind::Nop, OpKind::PktProcess, OpKind::Copy, OpKind::DmaH2d, OpKind::DmaD2h, OpKind::GemmI8, OpKind::AesGcm, OpKind::StorageWrite, OpKind::StorageRead];
    pub fn name(self) -> &'static str {
        match self {
            OpKind::Nop => "nop",
            OpKind::PktProcess => "pkt_process",
            OpKind::Copy => "copy",
            OpKind::DmaH2d => "dma_h2d",
            OpKind::DmaD2h => "dma_d2h",
            OpKind::GemmI8 => "gemm_i8",
            OpKind::AesGcm => "aes_gcm",
            OpKind::StorageWrite => "storage_write",
            OpKind::StorageRead => "storage_read",
        }
    }
}

impl Op {
    pub fn kind(&self) -> OpKind {
        match self {
            Op::Nop => OpKind::Nop,
            Op::PktProcess { .. } => OpKind::PktProcess,
            Op::Copy { .. } => OpKind::Copy,
            Op::DmaH2d { .. } => OpKind::DmaH2d,
            Op::DmaD2h { .. } => OpKind::DmaD2h,
            Op::GemmI8 { .. } => OpKind::GemmI8,
            Op::AesGcm { .. } => OpKind::AesGcm,
            Op::StorageWrite { .. } => OpKind::StorageWrite,
            Op::StorageRead { .. } => OpKind::StorageRead,
        }
    }
}

#[derive(Clone, Debug)]
pub struct Completion {
    pub kind: OpKind,
    pub status: Status,
    /// Raw DPU error code of the first failing command (0 = none); see `proto::err`.
    pub dev_err: u8,
    pub bytes: u64,
    /// CRC-32 (IEEE) of the input / output stream, as computed by the device (PKT_PROCESS / Copy only).
    pub crc_in: Option<u32>,
    pub crc_out: Option<u32>,
    pub csum: Option<u16>,
    /// Every output byte was acknowledged by its destination before this completion was produced.
    pub committed: bool,
    pub chunks: u32,
    /// Device cycles from submission to the completion, from the DPU's own cycle counter (not quantised).  Includes
    /// time queued behind other work.  cpu-ref: logical cycles.
    pub latency_cycles: u64,
    pub latency_ns: u64,
}

// ------------------------------------------------------------------------------------------------ tenants
#[derive(Clone, Debug)]
pub struct TenantConfig {
    pub name: String,
    pub host_in_bytes: u64,
    pub host_out_bytes: u64,
    /// 0 = an equal share of the device SRAM.
    pub sram_bytes: u32,
    pub max_buffers: u32,
    pub max_inflight: u32,
    pub max_keys: u32,
    pub chunk_bytes: u32,
    pub staging_slots: u32,
    pub quarantine_on_violation: bool,
}

impl Default for TenantConfig {
    fn default() -> Self {
        TenantConfig {
            name: "tenant".into(),
            host_in_bytes: 256 << 10,
            host_out_bytes: 256 << 10,
            sram_bytes: 0,
            max_buffers: 256,
            max_inflight: 64,
            max_keys: 16,
            chunk_bytes: 2048,
            staging_slots: 4,
            quarantine_on_violation: true,
        }
    }
}

/// Secret that authenticates a [`Session`] to its tenant.  In a deployment with the mediator daemon this is
/// replaced by the transport identity (SO_PEERCRED / allocation token); see docs/04_TENANT_ISOLATION.md.
#[derive(Clone, PartialEq, Eq)]
pub struct TenantCredential(pub [u8; 16]);

impl std::fmt::Debug for TenantCredential {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "TenantCredential(**redacted**)")
    }
}

fn random_bytes<const N: usize>() -> [u8; N] {
    use std::io::Read;
    let mut b = [0u8; N];
    if let Ok(mut f) = std::fs::File::open("/dev/urandom") {
        if f.read_exact(&mut b).is_ok() {
            return b;
        }
    }
    // fallback (non-Linux): time/pid mix -- adequate only for development use
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let mut x = t as u64 ^ (std::process::id() as u64) << 32 | 1;
    for v in b.iter_mut() {
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        *v = x as u8;
    }
    b
}

fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    a.len() == b.len() && a.iter().zip(b).fold(0u8, |d, (x, y)| d | (x ^ y)) == 0
}

#[derive(Clone, Debug, Default)]
pub struct TenantUsage {
    pub buffers: u32,
    pub host_bytes: u64,
    pub device_bytes: u64,
    pub keys: u32,
    pub inflight: u32,
    pub submitted: u64,
    pub completed: u64,
    pub errors: u64,
    pub bytes_ok: u64,
    pub cross_tenant_attempts: u64,
}

struct TenantRec {
    live: bool,
    cfg: TenantConfig,
    secret: [u8; 16],
    in_win: (u64, u64),
    out_win: (u64, u64),
    sram: (u32, u32),
    in_alloc: RangeAlloc,
    out_alloc: RangeAlloc,
    dev_alloc: RangeAlloc,
    staging_free: Vec<u32>,
    staging_zombie: Vec<u32>,
    net_queues: Vec<u32>,
    rr: usize,
    usage: TenantUsage,
    finished_unreaped: usize,
}

// ------------------------------------------------------------------------------------------------ buffers
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BufState {
    Free,
    /// Owned by the host: CPU may read/write; no command references it.
    HostOwned,
    /// A device operation referencing the buffer is in flight (CPU access is restricted).
    DeviceOwned,
    /// A device command timed out and may still write: unusable until a data-plane reset.
    Quarantined,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum BufKind {
    Host,
    Device,
}

struct BufSlot {
    gen: u16,
    state: BufState,
    tenant: u32,
    kind: BufKind,
    dev_read: bool,
    dev_write: bool,
    /// host: absolute IOVA; device: partition-relative offset
    addr: u64,
    size: u64,
    alloc_len: u64,
    readers: u32,
    writers: u32,
}

struct KeySlot {
    gen: u16,
    tenant: u32,
    key: Vec<u8>,
    live: bool,
}

fn wipe(v: &mut Vec<u8>) {
    for b in v.iter_mut() {
        // volatile so the optimiser cannot elide the wipe
        unsafe { std::ptr::write_volatile(b, 0) };
    }
    v.clear();
}

// ------------------------------------------------------------------------------------------------ tickets
struct Chunk {
    cmd: Option<Cmd>,
    ext: Option<ExtCmd>,
    staging: Option<u32>,
    len: u32,
    submitted: bool,
    done: Option<ChunkRes>,
}

#[derive(Clone, Copy, Debug, Default)]
struct ChunkRes {
    err: u8,
    /// DPU cycle counter (low 32 bits) when the completion was produced; None for results synthesised locally.
    ts: Option<u32>,
    bytes: u32,
    crc_in: u32,
    crc_out: u32,
    csum: u16,
    committed: bool,
}

struct Pin {
    buf: usize,
    writer: bool,
}

struct TicketRec {
    tenant: u32,
    kind: OpKind,
    chunks: Vec<Chunk>,
    next_unsubmitted: usize,
    inflight: u32,
    cancelled: bool,
    quarantine: bool,
    pins: Vec<Pin>,
    submit_cycle: u64,
    submit_at: Instant,
    result: Option<Completion>,
}

// ------------------------------------------------------------------------------------------------ stats
#[derive(Clone, Debug)]
pub struct RtStats {
    pub submitted: u64,
    pub ok: u64,
    pub failed: u64,
    pub by_status: [u64; 22],
    pub by_kind_ok: [u64; 9],
    pub bytes_ok: u64,
    pub lat_buckets: [u64; 7],
    pub lat_sum_cycles: u64,
    pub lat_sum_ns: u64,
    pub lat_count: u64,
    pub anomalies_unknown_tag: u64,
    pub anomalies_tenant_mismatch: u64,
    pub cross_tenant_attempts: u64,
    pub resets_soft: u64,
    pub resets_hard: u64,
    pub dev_err_counts: [u64; 64],
    pub telemetry_dropped_events: u64,
}

impl Default for RtStats {
    fn default() -> Self {
        RtStats {
            submitted: 0,
            ok: 0,
            failed: 0,
            by_status: [0; 22],
            by_kind_ok: [0; 9],
            bytes_ok: 0,
            lat_buckets: [0; 7],
            lat_sum_cycles: 0,
            lat_sum_ns: 0,
            lat_count: 0,
            anomalies_unknown_tag: 0,
            anomalies_tenant_mismatch: 0,
            cross_tenant_attempts: 0,
            resets_soft: 0,
            resets_hard: 0,
            dev_err_counts: [0; 64],
            telemetry_dropped_events: 0,
        }
    }
}

/// Thermal state.  The CloudDPU has NO thermal sensor path (PowerClock, Project 27, is not integrated), so the
/// state is `Unavailable` until an external source (node agent, BMC) feeds a reading with
/// [`Mediator::set_thermal`].  Nothing in this crate measures or models temperature.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum ThermalState {
    Unavailable,
    Normal(f32),
    /// Above the warning threshold: the device is reported `Degraded`.
    Warning(f32),
    /// Above the critical threshold: the device is reported `Faulted` and new submissions are refused.
    Critical(f32),
}

impl ThermalState {
    pub fn name(&self) -> &'static str {
        match self {
            ThermalState::Unavailable => "unavailable",
            ThermalState::Normal(_) => "normal",
            ThermalState::Warning(_) => "warning",
            ThermalState::Critical(_) => "critical",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Health {
    Healthy,
    Degraded(Vec<String>),
    Faulted(Vec<String>),
    Unavailable(String),
}

impl Health {
    pub fn name(&self) -> &'static str {
        match self {
            Health::Healthy => "healthy",
            Health::Degraded(_) => "degraded",
            Health::Faulted(_) => "faulted",
            Health::Unavailable(_) => "unavailable",
        }
    }
    pub fn reasons(&self) -> Vec<String> {
        match self {
            Health::Healthy => vec![],
            Health::Degraded(r) | Health::Faulted(r) => r.clone(),
            Health::Unavailable(s) => vec![s.clone()],
        }
    }
}

#[derive(Clone, Debug)]
pub struct Geometry {
    pub tenants: u32,
    pub net_queues: u32,
    pub compute_queues: u32,
    pub dma_channels: u32,
    pub data_width: u32,
    pub address_width: u32,
    pub windows: u32,
    pub sram_bytes: u32,
    pub max_xfer: u32,
    pub block_status: u32,
    pub features: u32,
    pub abi_major: u32,
    pub abi_minor: u32,
}

#[derive(Clone, Debug)]
pub struct DeviceInfo {
    pub backend: BackendInfo,
    pub geometry: Geometry,
    pub runtime_version: &'static str,
    pub abi_version: (u32, u32),
    pub tenant: Option<u32>,
    pub blocks: Vec<(&'static str, &'static str)>,
}

#[derive(Clone, Debug)]
pub struct TelemetryEvent {
    pub ts: u32,
    pub event: u8,
    pub tenant: u8,
    pub queue: u8,
    pub arg: u32,
}

#[derive(Clone, Debug, Default)]
pub struct TenantCounters {
    pub tenant: u32,
    pub usage: TenantUsage,
    /// From the device's per-tenant counter block.
    pub dev_cmds: u64,
    pub dev_bytes: u64,
    pub dev_violations: u32,
    pub dev_errors: u32,
    pub state: u32,
}

#[derive(Clone, Debug)]
pub struct DeviceCounters {
    pub global: [u64; 16],
    pub tenants: Vec<TenantCounters>,
    pub stats: RtStats,
    pub cycles: u64,
}

#[derive(Clone, Debug)]
pub struct QueueSnapshot {
    pub queue: u32,
    pub bound_tenant: u32,
    pub queued: u32,
    pub completions_waiting: u32,
    pub compute_class: bool,
    pub submitted: u32,
    pub completed: u32,
    pub rejected: u32,
}

#[derive(Clone, Debug)]
pub struct Snapshot {
    pub info: DeviceInfo,
    pub health: Health,
    pub cycles: u64,
    pub counters: DeviceCounters,
    pub queues: Vec<QueueSnapshot>,
    pub fault_status: u32,
    pub status_reg: u32,
    pub sram_used: u64,
    pub sram_capacity: u64,
    pub host_used: u64,
    pub host_capacity: u64,
    pub tlm_dropped: u32,
    pub tlm_emitted: u32,
    pub tenant_states: Vec<(u32, u32, bool)>, // (tenant, hw state, provisioned)
    pub thermal: ThermalState,
}

// ------------------------------------------------------------------------------------------------ core
pub struct Core {
    be: Box<dyn Backend>,
    info: BackendInfo,
    geo: Geometry,
    tenants: Vec<TenantRec>,
    bufs: Vec<BufSlot>,
    keys: Vec<KeySlot>,
    tickets: BTreeMap<u64, TicketRec>,
    tags: HashMap<u64, (u64, usize)>,
    next_ticket: u64,
    next_tag: u32,
    epoch: u16,
    iova_alloc: RangeAlloc,
    sram_alloc: RangeAlloc,
    stats: RtStats,
    events: VecDeque<TelemetryEvent>,
    queue_bind: Vec<u32>,
    enabled: bool,
    cycle_budget: u64,
    thermal: ThermalState,
    /// backend cycle counter minus the DPU's own time counter (calibrated at open / after a hard reset), so a
    /// completion's DPU timestamp can be compared with the cycle at which the command was submitted.
    time_offset: i64,
}

fn dev<T>(r: Result<T, DevError>) -> SfResult<T> {
    r.map_err(|e| SfError::new(e.status(), e.to_string()))
}

fn map_dev_err(e: u8) -> Status {
    match e {
        perr::NONE => Status::Ok,
        perr::PERM_READ | perr::PERM_WRITE | perr::SRAM_RANGE | perr::PERM_BEAT | perr::TENANT_MISMATCH => Status::Isolation,
        perr::QUARANTINED | perr::TENANT_STATE | perr::BAD_TENANT => Status::TenantState,
        perr::BLOCKED => Status::Unsupported,
        perr::BAD_OPCODE | perr::BAD_DESC => Status::BadDescriptor,
        perr::BAD_LENGTH | perr::PROC_OP => Status::InvalidArg,
        perr::ALIGN => Status::Alignment,
        perr::HOST_MEM | perr::SRAM_RESP | perr::INTERNAL => Status::DeviceFault,
        perr::TIMEOUT => Status::Timeout,
        perr::RESET_ABORT => Status::Reset,
        crate::backend::ext_err::AUTH_FAIL => Status::CryptoAuth,
        crate::backend::ext_err::BAD_PARAM => Status::InvalidArg,
        crate::backend::ext_err::NO_SPACE => Status::NoMemory,
        _ => Status::DeviceFault,
    }
}

fn status_index(s: Status) -> usize {
    (-(s.as_i32())) as usize
}

impl Core {
    // -------------------------------------------------------------------------------------- low level
    fn rd(&mut self, a: u32) -> SfResult<u32> {
        dev(self.be.mgmt_read(a))
    }
    fn wr(&mut self, a: u32, v: u32) -> SfResult<()> {
        dev(self.be.mgmt_write(a, v))
    }
    fn rd64(&mut self, a: u32) -> SfResult<u64> {
        let lo = self.rd(a)? as u64;
        let hi = self.rd(a + 4)? as u64;
        Ok(hi << 32 | lo)
    }

    /// Advance the device and process everything it produced.
    fn pump(&mut self, cycles: u64) {
        self.be.advance(cycles);
        self.collect();
    }

    fn collect(&mut self) {
        for q in 0..(self.geo.net_queues + self.geo.compute_queues) {
            while let Some(w) = self.be.pop_completion(q) {
                self.on_completion(q, Cpl::decode(&w));
            }
        }
        while let Some(w) = self.be.pop_telemetry() {
            let e = TlmEvent::decode(w);
            if self.events.len() >= EVENT_RING {
                self.events.pop_front();
                self.stats.telemetry_dropped_events += 1;
            }
            self.events.push_back(TelemetryEvent { ts: e.ts, event: e.event, tenant: e.tenant, queue: e.queue, arg: e.arg });
        }
        self.submit_pending();
    }

    fn wait_for<F: FnMut(&mut Core) -> SfResult<bool>>(&mut self, what: &str, budget: u64, mut cond: F) -> SfResult<()> {
        let mut spent = 0u64;
        loop {
            if cond(self)? {
                return Ok(());
            }
            if spent >= budget {
                return err(Status::Timeout, format!("timed out waiting for {what} ({budget} device cycles)"));
            }
            self.pump(PUMP_CYCLES);
            spent += PUMP_CYCLES;
        }
    }

    // -------------------------------------------------------------------------------------- open
    fn open(mut be: Box<dyn Backend>) -> SfResult<Core> {
        let info = be.info();
        let id = dev(be.mgmt_read(reg::G_ID))?;
        if id != proto::DPU_ID_MAGIC {
            return err(Status::NoDevice, format!("DPU ID register reads 0x{id:08x}, expected 0x{:08x}", proto::DPU_ID_MAGIC));
        }
        let ver = dev(be.mgmt_read(reg::G_VERSION))?;
        let (maj, min) = (ver >> 16, ver & 0xFFFF);
        if maj != proto::DPU_ABI_MAJOR {
            return err(Status::AbiMismatch, format!("device ABI {maj}.{min}, runtime supports {}.x", proto::DPU_ABI_MAJOR));
        }
        let c0 = dev(be.mgmt_read(reg::G_CONFIG0))?;
        let c1 = dev(be.mgmt_read(reg::G_CONFIG1))?;
        let geo = Geometry {
            tenants: c0 & 0xFF,
            net_queues: (c0 >> 8) & 0xFF,
            compute_queues: (c0 >> 16) & 0xFF,
            dma_channels: c0 >> 24,
            data_width: c1 & 0xFFFF,
            address_width: (c1 >> 16) & 0xFF,
            windows: c1 >> 24,
            sram_bytes: dev(be.mgmt_read(reg::G_SRAM_BYTES))?,
            max_xfer: dev(be.mgmt_read(reg::G_MAX_XFER))?,
            block_status: dev(be.mgmt_read(reg::G_BLOCK_STATUS))?,
            features: dev(be.mgmt_read(reg::G_FEATURES))?,
            abi_major: maj,
            abi_minor: min,
        };
        if geo.windows < 2 {
            return err(Status::Unsupported, "the runtime needs at least 2 host windows per tenant");
        }
        let nq = geo.net_queues + geo.compute_queues;
        let mut queue_bind = Vec::new();
        for q in 0..nq {
            queue_bind.push(dev(be.mgmt_read(reg::queue(q, reg::Q_BIND)))?);
        }
        let tenants = (0..geo.tenants)
            .map(|_| TenantRec {
                live: false,
                cfg: TenantConfig::default(),
                secret: [0; 16],
                in_win: (0, 0),
                out_win: (0, 0),
                sram: (0, 0),
                in_alloc: RangeAlloc::new(0, 0),
                out_alloc: RangeAlloc::new(0, 0),
                dev_alloc: RangeAlloc::new(0, 0),
                staging_free: vec![],
                staging_zombie: vec![],
                net_queues: vec![],
                rr: 0,
                usage: TenantUsage::default(),
                finished_unreaped: 0,
            })
            .collect();
        let mut core = Core {
            iova_alloc: RangeAlloc::new(info.iova_base, info.iova_size),
            sram_alloc: RangeAlloc::new(0, geo.sram_bytes as u64),
            be,
            info,
            geo,
            tenants,
            bufs: vec![],
            keys: vec![],
            tickets: BTreeMap::new(),
            tags: HashMap::new(),
            next_ticket: 1,
            next_tag: 1,
            epoch: next_epoch(),
            stats: RtStats::default(),
            events: VecDeque::new(),
            queue_bind,
            enabled: false,
            cycle_budget: 20_000_000,
            thermal: ThermalState::Unavailable,
            time_offset: 0,
        };
        core.wr(reg::L_CTRL, 1)?; // telemetry events on
        core.calibrate_time();
        Ok(core)
    }

    /// Align the DPU's time counter with the backend cycle counter.  With a simulation back door the offset is
    /// exact; otherwise a TIME_LO register read is used, whose bus latency bounds the error (a few cycles).  Either
    /// way it is a constant offset, not a drift.
    fn calibrate_time(&mut self) {
        if let Some(t) = self.be.dpu_time_exact() {
            // exact: both counters advance once per clock edge, so the offset is a constant (no bus latency involved)
            self.time_offset = self.be.cycles() as i64 - t as i64;
            return;
        }
        let c0 = self.be.cycles();
        if let Ok(t) = self.rd(reg::G_TIME_LO) {
            let c1 = self.be.cycles();
            self.time_offset = ((c0 + c1) / 2) as i64 - t as i64;
        }
    }

    // -------------------------------------------------------------------------------------- tenants
    fn provision(&mut self, id: u32, cfg: TenantConfig) -> SfResult<TenantCredential> {
        if id >= self.geo.tenants {
            return err(Status::InvalidArg, format!("tenant {id} does not exist (device has {})", self.geo.tenants));
        }
        if self.tenants[id as usize].live {
            return err(Status::Busy, format!("tenant {id} is already provisioned"));
        }
        let nets: Vec<u32> = (0..self.geo.net_queues).filter(|&q| self.queue_bind[q as usize] == id).collect();
        if nets.is_empty() {
            return err(Status::Unsupported, format!("no network queue is bound to tenant {id} on this device"));
        }
        let sram = if cfg.sram_bytes == 0 { (self.geo.sram_bytes / self.geo.tenants) / 256 * 256 } else { cfg.sram_bytes };
        let slot = (2 * cfg.chunk_bytes as u64).div_ceil(256) * 256;
        let mut slots = cfg.staging_slots.max(1);
        while slots > 1 && slot * slots as u64 > sram as u64 / 2 {
            slots -= 1;
        }
        let staging_total = slot * slots as u64;
        if cfg.chunk_bytes == 0 || cfg.chunk_bytes % 4 != 0 || cfg.chunk_bytes > self.geo.max_xfer || staging_total >= sram as u64 {
            return err(Status::InvalidArg, "chunk_bytes must be a multiple of 4, <= max_xfer, and the SRAM partition must leave room beyond the staging area");
        }
        let sbase = self.sram_alloc.alloc(sram as u64, 256).ok_or_else(|| SfError::new(Status::NoMemory, "device SRAM exhausted"))?;
        let ib = match self.iova_alloc.alloc(cfg.host_in_bytes.max(IOVA_PAGE), IOVA_PAGE) {
            Some(v) => v,
            None => {
                self.sram_alloc.free(sbase, sram as u64, 256);
                return err(Status::NoMemory, "host IOVA space exhausted");
            }
        };
        let ob = match self.iova_alloc.alloc(cfg.host_out_bytes.max(IOVA_PAGE), IOVA_PAGE) {
            Some(v) => v,
            None => {
                self.sram_alloc.free(sbase, sram as u64, 256);
                self.iova_alloc.free(ib, cfg.host_in_bytes.max(IOVA_PAGE), IOVA_PAGE);
                return err(Status::NoMemory, "host IOVA space exhausted");
            }
        };
        let isz = cfg.host_in_bytes.max(IOVA_PAGE).div_ceil(IOVA_PAGE) * IOVA_PAGE;
        let osz = cfg.host_out_bytes.max(IOVA_PAGE).div_ceil(IOVA_PAGE) * IOVA_PAGE;
        let undo = |c: &mut Core| {
            c.sram_alloc.free(sbase, sram as u64, 256);
            c.iova_alloc.free(ib, isz, IOVA_PAGE);
            c.iova_alloc.free(ob, osz, IOVA_PAGE);
        };
        // scrub the host windows: a new tenant never sees a previous owner's bytes
        if let Err(e) = self.zero_host(ib, isz).and_then(|_| self.zero_host(ob, osz)) {
            undo(self);
            return Err(e);
        }
        // program the shadow configuration, then COMMIT
        let t = id;
        let prog = (|| -> SfResult<()> {
            self.wr(reg::tenant(t, reg::T_SRAM_BASE), sbase as u32)?;
            self.wr(reg::tenant(t, reg::T_SRAM_SIZE), sram)?;
            self.wr(reg::tenant(t, reg::T_POLICY), cfg.quarantine_on_violation as u32)?;
            for (w, (base, size, perm)) in [(0u32, (ib, isz, reg::WIN_VALID | reg::WIN_R)), (1, (ob, osz, reg::WIN_VALID | reg::WIN_R | reg::WIN_W))] {
                self.wr(reg::win(t, w, reg::WIN_BASE_LO), base as u32)?;
                self.wr(reg::win(t, w, reg::WIN_BASE_HI), (base >> 32) as u32)?;
                self.wr(reg::win(t, w, reg::WIN_SIZE), size as u32)?;
                self.wr(reg::win(t, w, reg::WIN_CTRL), perm)?;
            }
            // any further windows stay invalid
            for w in 2..self.geo.windows {
                self.wr(reg::win(t, w, reg::WIN_CTRL), 0)?;
            }
            self.wr(reg::tenant(t, reg::T_CMD), tcmd::COMMIT)?;
            Ok(())
        })();
        if let Err(e) = prog {
            undo(self);
            return Err(e);
        }
        let budget = self.cycle_budget;
        let r = self.wait_for("tenant COMMIT result", budget, |c| Ok(c.rd(reg::tenant(t, reg::T_CFG_STATUS))? != pcfg::NONE));
        if let Err(e) = r {
            undo(self);
            return Err(e);
        }
        let cs = self.rd(reg::tenant(t, reg::T_CFG_STATUS))?;
        if cs != pcfg::OK {
            undo(self);
            let (st, why) = match cs {
                pcfg::BAD_PART => (Status::InvalidArg, "SRAM partition rejected (empty, unaligned or outside SRAM)"),
                pcfg::BAD_WINDOW => (Status::InvalidArg, "host window rejected"),
                pcfg::OVERLAP_SRAM => (Status::Isolation, "SRAM partition overlaps another tenant"),
                pcfg::OVERLAP_HOST => (Status::Isolation, "host window overlaps another tenant"),
                pcfg::BUSY => (Status::Busy, "tenant not disabled"),
                _ => (Status::DeviceFault, "tenant commit failed"),
            };
            return err(st, format!("tenant {t} COMMIT refused by the device (CFG_STATUS=0x{cs:02x}): {why}"));
        }
        let r = self.wait_for("partition scrub", budget, |c| {
            let s = c.rd(reg::tenant(t, reg::T_STATE))?;
            Ok(s & 7 == tstate::DISABLED && s & 0x100 != 0)
        });
        if let Err(e) = r {
            undo(self);
            return Err(e);
        }
        self.wr(reg::tenant(t, reg::T_CMD), tcmd::ENABLE)?;
        let s = self.rd(reg::tenant(t, reg::T_STATE))?;
        if s & 7 != tstate::ACTIVE {
            undo(self);
            return err(Status::TenantState, format!("tenant {t} did not become ACTIVE (state {})", tstate::name(s & 7)));
        }
        if !self.enabled {
            self.wr(reg::G_CTRL, reg::CTRL_EN)?;
            self.enabled = true;
        }
        let secret: [u8; 16] = random_bytes();
        let staging_free: Vec<u32> = (0..slots).rev().map(|i| (i as u64 * slot) as u32).collect();
        let dev_len = sram as u64 - staging_total;
        let rec = &mut self.tenants[id as usize];
        *rec = TenantRec {
            live: true,
            cfg,
            secret,
            in_win: (ib, isz),
            out_win: (ob, osz),
            sram: (sbase as u32, sram),
            in_alloc: RangeAlloc::new(ib, isz),
            out_alloc: RangeAlloc::new(ob, osz),
            dev_alloc: RangeAlloc::new(staging_total, dev_len),
            staging_free,
            staging_zombie: vec![],
            net_queues: nets,
            rr: 0,
            usage: TenantUsage::default(),
            finished_unreaped: 0,
        };
        Ok(TenantCredential(secret))
    }

    fn zero_host(&mut self, base: u64, len: u64) -> SfResult<()> {
        let z = vec![0u8; 4096];
        let mut o = 0;
        while o < len {
            let n = (len - o).min(4096) as usize;
            dev(self.be.host_write(base + o, &z[..n]))?;
            o += n as u64;
        }
        Ok(())
    }

    fn tenant_live(&self, t: u32) -> SfResult<()> {
        match self.tenants.get(t as usize) {
            Some(r) if r.live => Ok(()),
            _ => err(Status::NoDevice, format!("tenant {t} is not provisioned")),
        }
    }

    fn deprovision(&mut self, id: u32) -> SfResult<()> {
        self.tenant_live(id)?;
        // 1. cancel what has not been submitted; wait for what is in flight (the device owns those buffers)
        let ids: Vec<u64> = self.tickets.iter().filter(|(_, t)| t.tenant == id).map(|(k, _)| *k).collect();
        for k in &ids {
            if let Some(t) = self.tickets.get_mut(k) {
                t.cancelled = true;
            }
        }
        self.collect();
        let budget = self.cycle_budget;
        self.wait_for("in-flight commands of the tenant", budget, |c| Ok(c.tickets.values().all(|t| t.tenant != id || t.inflight == 0)))?;
        // 2. drop tickets, keys, buffers
        for k in ids {
            self.tickets.remove(&k);
        }
        for ks in self.keys.iter_mut() {
            if ks.live && ks.tenant == id {
                wipe(&mut ks.key);
                ks.live = false;
                ks.gen = ks.gen.saturating_add(1);
            }
        }
        for i in 0..self.bufs.len() {
            if self.bufs[i].state != BufState::Free && self.bufs[i].tenant == id {
                self.release_buf(i)?;
            }
        }
        // 3. disable -> drain -> scrub (hardware zeroes the partition) -> release the configuration
        self.wr(reg::tenant(id, reg::T_CMD), tcmd::DISABLE)?;
        self.wait_for("tenant scrub", budget, |c| {
            let s = c.rd(reg::tenant(id, reg::T_STATE))?;
            Ok(s & 7 == tstate::DISABLED)
        })?;
        self.wr(reg::tenant(id, reg::T_CMD), tcmd::RELEASE)?;
        let (ib, isz) = self.tenants[id as usize].in_win;
        let (ob, osz) = self.tenants[id as usize].out_win;
        let (sb, ss) = self.tenants[id as usize].sram;
        self.zero_host(ib, isz)?;
        self.zero_host(ob, osz)?;
        self.iova_alloc.free(ib, isz, IOVA_PAGE);
        self.iova_alloc.free(ob, osz, IOVA_PAGE);
        self.sram_alloc.free(sb as u64, ss as u64, 256);
        self.tenants[id as usize].live = false;
        self.tenants[id as usize].usage = TenantUsage::default();
        Ok(())
    }

    // -------------------------------------------------------------------------------------- buffers
    fn buf_lookup(&mut self, tenant: u32, h: u64) -> SfResult<usize> {
        let (epoch, gen, t, idx) = unpack_handle(h);
        let idx = idx as usize;
        let ok = epoch == self.epoch && idx < self.bufs.len() && self.bufs[idx].gen == gen && self.bufs[idx].state != BufState::Free;
        if !ok {
            return err(Status::StaleHandle, "buffer handle is stale or invalid");
        }
        if self.bufs[idx].tenant != tenant || t != tenant {
            // indistinguishable from a freed handle; counted for audit
            self.stats.cross_tenant_attempts += 1;
            if let Some(r) = self.tenants.get_mut(tenant as usize) {
                r.usage.cross_tenant_attempts += 1;
            }
            return err(Status::StaleHandle, "buffer handle is stale or invalid");
        }
        Ok(idx)
    }

    fn alloc_buf(&mut self, tenant: u32, size: u64, flags: u32) -> SfResult<BufHandle> {
        self.tenant_live(tenant)?;
        if size == 0 || size > (1 << 30) {
            return err(Status::InvalidArg, "buffer size must be 1 byte .. 1 GiB");
        }
        let device = flags & alloc_flags::DEVICE != 0;
        let mut r = flags & alloc_flags::DEV_READ != 0;
        let mut w = flags & alloc_flags::DEV_WRITE != 0;
        if flags & !(alloc_flags::DEVICE | alloc_flags::DEV_READ | alloc_flags::DEV_WRITE) != 0 {
            return err(Status::InvalidArg, "unknown allocation flags");
        }
        if !r && !w {
            r = true;
            w = true;
        }
        let max = self.tenants[tenant as usize].cfg.max_buffers;
        if self.tenants[tenant as usize].usage.buffers >= max {
            return err(Status::Quota, format!("tenant buffer quota ({max}) exhausted"));
        }
        let rec = &mut self.tenants[tenant as usize];
        let alloc_len = size.div_ceil(BUF_ALIGN) * BUF_ALIGN;
        let (addr, kind) = if device {
            (rec.dev_alloc.alloc(size, BUF_ALIGN), BufKind::Device)
        } else if w {
            (rec.out_alloc.alloc(size, BUF_ALIGN), BufKind::Host)
        } else {
            (rec.in_alloc.alloc(size, BUF_ALIGN), BufKind::Host)
        };
        let Some(addr) = addr else {
            return err(Status::NoMemory, "tenant memory exhausted for this buffer class");
        };
        rec.usage.buffers += 1;
        match kind {
            BufKind::Host => rec.usage.host_bytes += alloc_len,
            BufKind::Device => rec.usage.device_bytes += alloc_len,
        }
        let slot = BufSlot { gen: 1, state: BufState::HostOwned, tenant, kind, dev_read: r, dev_write: w, addr, size, alloc_len, readers: 0, writers: 0 };
        let idx = match self.bufs.iter().position(|b| b.state == BufState::Free && b.gen != u16::MAX) {
            Some(i) => {
                let gen = self.bufs[i].gen;
                self.bufs[i] = BufSlot { gen, ..slot };
                i
            }
            None => {
                self.bufs.push(slot);
                self.bufs.len() - 1
            }
        };
        Ok(BufHandle(pack_handle(self.epoch, self.bufs[idx].gen, tenant, idx as u32)))
    }

    /// Scrub and return the buffer's memory; invalidates every outstanding handle.
    fn release_buf(&mut self, idx: usize) -> SfResult<()> {
        let (tenant, kind, addr, size, alloc_len, dr, dw) = {
            let b = &self.bufs[idx];
            (b.tenant, b.kind, b.addr, b.size, b.alloc_len, b.dev_read, b.dev_write)
        };
        if kind == BufKind::Host {
            self.zero_host(addr, alloc_len)?;
        }
        let rec = &mut self.tenants[tenant as usize];
        match kind {
            BufKind::Host => {
                if dw {
                    rec.out_alloc.free(addr, size, BUF_ALIGN);
                } else {
                    let _ = dr;
                    rec.in_alloc.free(addr, size, BUF_ALIGN);
                }
                rec.usage.host_bytes -= alloc_len;
            }
            BufKind::Device => {
                rec.dev_alloc.free(addr, size, BUF_ALIGN);
                rec.usage.device_bytes -= alloc_len;
            }
        }
        rec.usage.buffers -= 1;
        let b = &mut self.bufs[idx];
        b.state = BufState::Free;
        b.gen = b.gen.saturating_add(1); // u16::MAX = retired: the slot is never handed out again
        b.readers = 0;
        b.writers = 0;
        Ok(())
    }

    fn free_buf(&mut self, tenant: u32, h: BufHandle) -> SfResult<()> {
        let idx = self.buf_lookup(tenant, h.0)?;
        let b = &self.bufs[idx];
        if b.readers > 0 || b.writers > 0 || b.state == BufState::DeviceOwned {
            return err(Status::Busy, "buffer is referenced by an in-flight device operation");
        }
        if b.state == BufState::Quarantined {
            return err(Status::Busy, "buffer is quarantined after a device timeout; reset the device first");
        }
        self.release_buf(idx)
    }

    fn buf_write(&mut self, tenant: u32, h: BufHandle, off: u64, data: &[u8]) -> SfResult<()> {
        let idx = self.buf_lookup(tenant, h.0)?;
        let b = &self.bufs[idx];
        if b.kind != BufKind::Host {
            return err(Status::Permission, "device-local memory is not CPU accessible");
        }
        if b.state == BufState::Quarantined || b.readers > 0 || b.writers > 0 {
            return err(Status::Busy, "buffer is owned by the device");
        }
        if off.checked_add(data.len() as u64).map_or(true, |e| e > b.size) {
            return err(Status::Range, "write outside the buffer");
        }
        let a = b.addr + off;
        dev(self.be.host_write(a, data))
    }

    fn buf_read(&mut self, tenant: u32, h: BufHandle, off: u64, out: &mut [u8]) -> SfResult<()> {
        let idx = self.buf_lookup(tenant, h.0)?;
        let b = &self.bufs[idx];
        if b.kind != BufKind::Host {
            return err(Status::Permission, "device-local memory is not CPU accessible");
        }
        if b.state == BufState::Quarantined || b.writers > 0 {
            return err(Status::Busy, "buffer is being written by the device");
        }
        if off.checked_add(out.len() as u64).map_or(true, |e| e > b.size) {
            return err(Status::Range, "read outside the buffer");
        }
        let a = b.addr + off;
        dev(self.be.host_read(a, out))
    }

    // -------------------------------------------------------------------------------------- keys
    fn key_lookup(&mut self, tenant: u32, h: u64) -> SfResult<usize> {
        let (epoch, gen, t, idx) = unpack_handle(h);
        let idx = idx as usize;
        if epoch != self.epoch || idx >= self.keys.len() || !self.keys[idx].live || self.keys[idx].gen != gen {
            return err(Status::StaleHandle, "key handle is stale or invalid");
        }
        if self.keys[idx].tenant != tenant || t != tenant {
            self.stats.cross_tenant_attempts += 1;
            if let Some(r) = self.tenants.get_mut(tenant as usize) {
                r.usage.cross_tenant_attempts += 1;
            }
            return err(Status::StaleHandle, "key handle is stale or invalid");
        }
        Ok(idx)
    }

    fn load_key(&mut self, tenant: u32, key: &[u8]) -> SfResult<KeyHandle> {
        self.tenant_live(tenant)?;
        if !(key.len() == 16 || key.len() == 32) {
            return err(Status::InvalidArg, "AES key must be 16 or 32 bytes");
        }
        let max = self.tenants[tenant as usize].cfg.max_keys;
        if self.tenants[tenant as usize].usage.keys >= max {
            return err(Status::Quota, format!("tenant key quota ({max}) exhausted"));
        }
        self.tenants[tenant as usize].usage.keys += 1;
        let slot = KeySlot { gen: 1, tenant, key: key.to_vec(), live: true };
        let idx = match self.keys.iter().position(|k| !k.live && k.gen != u16::MAX) {
            Some(i) => {
                let gen = self.keys[i].gen;
                self.keys[i] = KeySlot { gen, ..slot };
                i
            }
            None => {
                self.keys.push(slot);
                self.keys.len() - 1
            }
        };
        Ok(KeyHandle(pack_handle(self.epoch, self.keys[idx].gen, tenant, idx as u32)))
    }

    fn unload_key(&mut self, tenant: u32, h: KeyHandle) -> SfResult<()> {
        let idx = self.key_lookup(tenant, h.0)?;
        wipe(&mut self.keys[idx].key);
        self.keys[idx].live = false;
        self.keys[idx].gen = self.keys[idx].gen.saturating_add(1);
        self.tenants[tenant as usize].usage.keys -= 1;
        Ok(())
    }

    // -------------------------------------------------------------------------------------- submit
    fn caps_for(&self, k: OpKind) -> bool {
        let c: Caps = self.info.caps;
        match k {
            OpKind::Nop => c.nop,
            OpKind::PktProcess | OpKind::Copy => c.pkt_process,
            OpKind::DmaH2d | OpKind::DmaD2h => c.dma,
            OpKind::GemmI8 => c.gemm_i8,
            OpKind::AesGcm => c.aes_gcm,
            OpKind::StorageWrite | OpKind::StorageRead => c.storage,
        }
    }

    fn res(&mut self, tenant: u32, h: BufHandle, off: u64, len: u64, need_r: bool, need_w: bool, want_kind: BufKind) -> SfResult<usize> {
        let idx = self.buf_lookup(tenant, h.0)?;
        let b = &self.bufs[idx];
        if b.state == BufState::Quarantined {
            return err(Status::Busy, "buffer is quarantined");
        }
        if b.kind != want_kind {
            return err(
                Status::InvalidArg,
                match want_kind {
                    BufKind::Host => "operand must be a host buffer",
                    BufKind::Device => "operand must be a device-local buffer",
                },
            );
        }
        if need_r && !b.dev_read {
            return err(Status::Permission, "buffer was not allocated with DEV_READ");
        }
        if need_w && !b.dev_write {
            return err(Status::Permission, "buffer was not allocated with DEV_WRITE");
        }
        if len == 0 {
            return err(Status::InvalidArg, "operand length must be non-zero");
        }
        if off.checked_add(len).map_or(true, |e| e > b.size) {
            return err(Status::Range, "operand range outside the buffer");
        }
        Ok(idx)
    }

    fn pin(&mut self, pins: &mut Vec<Pin>, idx: usize, writer: bool) -> SfResult<()> {
        let b = &mut self.bufs[idx];
        // hazard rules: one writer excludes everyone; readers may share
        if writer && (b.readers > 0 || b.writers > 0) || !writer && b.writers > 0 {
            return err(Status::Busy, "buffer is already in use by an in-flight operation (read/write hazard)");
        }
        if writer {
            b.writers += 1;
        } else {
            b.readers += 1;
        }
        b.state = BufState::DeviceOwned;
        pins.push(Pin { buf: idx, writer });
        Ok(())
    }

    fn unpin(&mut self, pins: &[Pin], quarantine: bool) {
        for p in pins {
            let b = &mut self.bufs[p.buf];
            if p.writer {
                b.writers = b.writers.saturating_sub(1);
            } else {
                b.readers = b.readers.saturating_sub(1);
            }
            if quarantine && p.writer {
                b.state = BufState::Quarantined;
            } else if b.readers == 0 && b.writers == 0 && b.state != BufState::Quarantined {
                b.state = BufState::HostOwned;
            }
        }
    }

    fn submit_op(&mut self, tenant: u32, op: &Op) -> SfResult<Ticket> {
        self.tenant_live(tenant)?;
        if let ThermalState::Critical(t) = self.thermal {
            return err(Status::DeviceFault, format!("device is in a critical thermal state ({t:.1} C reported by the external sensor); new work is refused"));
        }
        let kind = op.kind();
        if !self.caps_for(kind) {
            return err(Status::Unsupported, format!("operation '{}' is not implemented by backend '{}' (see `sfctl info` for the capability list)", kind.name(), self.info.name));
        }
        {
            let rec = &self.tenants[tenant as usize];
            if rec.usage.inflight >= rec.cfg.max_inflight {
                return err(Status::Quota, format!("tenant in-flight quota ({}) exhausted", rec.cfg.max_inflight));
            }
            if rec.finished_unreaped >= MAX_FINISHED_UNREAPED {
                return err(Status::Quota, "too many completed tickets have not been collected (poll/wait them)");
            }
        }
        let rec_chunk = self.tenants[tenant as usize].cfg.chunk_bytes as u64;
        let mut pins: Vec<Pin> = Vec::new();
        let mut chunks: Vec<Chunk> = Vec::new();
        let r: SfResult<()> = (|| {
            match op {
                Op::Nop => {
                    chunks.push(Chunk {
                        cmd: Some(Cmd { opcode: pop::NOP, tenant: tenant as u8, ..Default::default() }),
                        ext: None,
                        staging: None,
                        len: 0,
                        submitted: false,
                        done: None,
                    });
                }
                Op::PktProcess { src, src_off, dst, dst_off, len, proc_op, param } => {
                    self.build_pkt(tenant, &mut pins, &mut chunks, *src, *src_off, *dst, *dst_off, *len, *proc_op, *param, rec_chunk)?
                }
                Op::Copy { src, src_off, dst, dst_off, len } => {
                    self.build_pkt(tenant, &mut pins, &mut chunks, *src, *src_off, *dst, *dst_off, *len, proto::proc_op::PASS, 0, rec_chunk)?
                }
                Op::DmaH2d { src, src_off, dst, dst_off, len } => {
                    let si = self.res(tenant, *src, *src_off, *len, true, false, BufKind::Host)?;
                    let di = self.res(tenant, *dst, *dst_off, *len, false, false, BufKind::Device)?;
                    check_align(*src_off, *dst_off)?;
                    self.pin(&mut pins, si, false)?;
                    self.pin(&mut pins, di, true)?;
                    let (sa, da) = (self.bufs[si].addr + src_off, self.bufs[di].addr + dst_off);
                    let mut o = 0u64;
                    while o < *len {
                        let n = (*len - o).min(rec_chunk);
                        chunks.push(Chunk {
                            cmd: Some(Cmd { opcode: pop::DMA_H2D, tenant: tenant as u8, src: sa + o, len: n as u32, sram_off: (da + o) as u32, ..Default::default() }),
                            ext: None,
                            staging: None,
                            len: n as u32,
                            submitted: false,
                            done: None,
                        });
                        o += n;
                    }
                }
                Op::DmaD2h { src, src_off, dst, dst_off, len } => {
                    let si = self.res(tenant, *src, *src_off, *len, false, false, BufKind::Device)?;
                    let di = self.res(tenant, *dst, *dst_off, *len, false, true, BufKind::Host)?;
                    check_align(*src_off, *dst_off)?;
                    self.pin(&mut pins, si, false)?;
                    self.pin(&mut pins, di, true)?;
                    let (sa, da) = (self.bufs[si].addr + src_off, self.bufs[di].addr + dst_off);
                    let mut o = 0u64;
                    while o < *len {
                        let n = (*len - o).min(rec_chunk);
                        chunks.push(Chunk {
                            cmd: Some(Cmd { opcode: pop::DMA_D2H, tenant: tenant as u8, dst: da + o, len: n as u32, sram_off: (sa + o) as u32, ..Default::default() }),
                            ext: None,
                            staging: None,
                            len: n as u32,
                            submitted: false,
                            done: None,
                        });
                        o += n;
                    }
                }
                Op::GemmI8 { a, a_off, b, b_off, c, c_off, m, n, k } => {
                    if *m == 0 || *n == 0 || *k == 0 || *m > 64 || *n > 64 || *k > 64 {
                        return err(Status::InvalidArg, "GEMM dimensions must be 1..=64");
                    }
                    let ai = self.res(tenant, *a, *a_off, (*m * *k) as u64, true, false, BufKind::Host)?;
                    let bi = self.res(tenant, *b, *b_off, (*k * *n) as u64, true, false, BufKind::Host)?;
                    let ci = self.res(tenant, *c, *c_off, (*m * *n * 4) as u64, false, true, BufKind::Host)?;
                    self.pin(&mut pins, ai, false)?;
                    if bi != ai {
                        self.pin(&mut pins, bi, false)?;
                    }
                    self.pin(&mut pins, ci, true)?;
                    let ext = ExtCmd::GemmI8 { tag: 0, a: self.bufs[ai].addr + a_off, b: self.bufs[bi].addr + b_off, c: self.bufs[ci].addr + c_off, m: *m, n: *n, k: *k };
                    chunks.push(Chunk { cmd: None, ext: Some(ext), staging: None, len: 0, submitted: false, done: None });
                }
                Op::AesGcm { key, encrypt, iv, aad, src, src_off, dst, dst_off, tag, tag_off, len } => {
                    let ki = self.key_lookup(tenant, key.0)?;
                    let keyb = self.keys[ki].key.clone();
                    if *len == 0 || *len > self.geo.max_xfer {
                        return err(Status::InvalidArg, format!("AES-GCM length must be 1..={} (single-chunk operation)", self.geo.max_xfer));
                    }
                    if aad.len() > 1024 {
                        return err(Status::InvalidArg, "AAD longer than 1024 bytes");
                    }
                    let si = self.res(tenant, *src, *src_off, *len as u64, true, false, BufKind::Host)?;
                    let di = self.res(tenant, *dst, *dst_off, *len as u64, false, true, BufKind::Host)?;
                    let ti = self.res(tenant, *tag, *tag_off, 16, !*encrypt, *encrypt, BufKind::Host)?;
                    if si == di || ti == di {
                        return err(Status::InvalidArg, "AES-GCM destination must not alias its source or tag buffer");
                    }
                    self.pin(&mut pins, si, false)?;
                    self.pin(&mut pins, di, true)?;
                    if ti != si {
                        self.pin(&mut pins, ti, *encrypt)?;
                    }
                    let ext = ExtCmd::AesGcm {
                        tag: 0,
                        encrypt: *encrypt,
                        key: keyb,
                        iv: *iv,
                        aad: aad.clone(),
                        src: self.bufs[si].addr + src_off,
                        dst: self.bufs[di].addr + dst_off,
                        tag_addr: self.bufs[ti].addr + tag_off,
                        len: *len,
                    };
                    chunks.push(Chunk { cmd: None, ext: Some(ext), staging: None, len: *len, submitted: false, done: None });
                }
                Op::StorageWrite { src, src_off, lba, blocks } => {
                    let n = *blocks as u64 * 512;
                    let si = self.res(tenant, *src, *src_off, n, true, false, BufKind::Host)?;
                    self.pin(&mut pins, si, false)?;
                    let ext = ExtCmd::StorageWrite { tag: 0, src: self.bufs[si].addr + src_off, lba: *lba, blocks: *blocks };
                    chunks.push(Chunk { cmd: None, ext: Some(ext), staging: None, len: n as u32, submitted: false, done: None });
                }
                Op::StorageRead { dst, dst_off, lba, blocks } => {
                    let n = *blocks as u64 * 512;
                    let di = self.res(tenant, *dst, *dst_off, n, false, true, BufKind::Host)?;
                    self.pin(&mut pins, di, true)?;
                    let ext = ExtCmd::StorageRead { tag: 0, lba: *lba, dst: self.bufs[di].addr + dst_off, blocks: *blocks };
                    chunks.push(Chunk { cmd: None, ext: Some(ext), staging: None, len: n as u32, submitted: false, done: None });
                }
            }
            Ok(())
        })();
        if let Err(e) = r {
            self.unpin(&pins, false);
            return Err(e);
        }
        let id = (tenant as u64) << 56 | (self.epoch as u64) << 40 | self.next_ticket;
        self.next_ticket += 1;
        let rec = &mut self.tenants[tenant as usize];
        rec.usage.inflight += 1;
        rec.usage.submitted += 1;
        self.stats.submitted += 1;
        self.tickets.insert(
            id,
            TicketRec {
                tenant,
                kind,
                chunks,
                next_unsubmitted: 0,
                inflight: 0,
                cancelled: false,
                quarantine: false,
                pins,
                submit_cycle: self.be.cycles(),
                submit_at: Instant::now(),
                result: None,
            },
        );
        self.submit_pending();
        Ok(Ticket(id))
    }

    #[allow(clippy::too_many_arguments)]
    fn build_pkt(
        &mut self,
        tenant: u32,
        pins: &mut Vec<Pin>,
        chunks: &mut Vec<Chunk>,
        src: BufHandle,
        src_off: u64,
        dst: BufHandle,
        dst_off: u64,
        len: u64,
        proc_op: u8,
        param: u32,
        chunk: u64,
    ) -> SfResult<()> {
        let si = self.res(tenant, src, src_off, len, true, false, BufKind::Host)?;
        let di = self.res(tenant, dst, dst_off, len, false, true, BufKind::Host)?;
        check_align(src_off, dst_off)?;
        if !(proc_op == proto::proc_op::PASS || proc_op == proto::proc_op::XOR32 || proc_op == proto::proc_op::BSWAP32) {
            return err(Status::InvalidArg, format!("unknown PacketCore operation 0x{proc_op:02x}"));
        }
        if proc_op == proto::proc_op::BSWAP32 && len % 4 != 0 {
            return err(Status::InvalidArg, "BSWAP32 requires a length that is a multiple of 4");
        }
        if si == di {
            return err(Status::InvalidArg, "source and destination must be different buffers");
        }
        self.pin(pins, si, false)?;
        self.pin(pins, di, true)?;
        let (sa, da) = (self.bufs[si].addr + src_off, self.bufs[di].addr + dst_off);
        let mut o = 0u64;
        while o < len {
            let n = (len - o).min(chunk);
            chunks.push(Chunk {
                cmd: Some(Cmd { opcode: pop::PKT_PROCESS, tenant: tenant as u8, src: sa + o, dst: da + o, len: n as u32, proc_op, param, ..Default::default() }),
                ext: None,
                staging: None,
                len: n as u32,
                submitted: false,
                done: None,
            });
            o += n;
        }
        Ok(())
    }

    /// Hand as many unsubmitted chunks to the device as queue space and staging slots allow.
    fn submit_pending(&mut self) {
        let ids: Vec<u64> = self.tickets.iter().filter(|(_, t)| t.result.is_none() && !t.cancelled && t.next_unsubmitted < t.chunks.len()).map(|(k, _)| *k).collect();
        for id in ids {
            loop {
                let (tenant, ci, needs_staging) = {
                    let t = &self.tickets[&id];
                    if t.next_unsubmitted >= t.chunks.len() || t.cancelled {
                        break;
                    }
                    let c = &t.chunks[t.next_unsubmitted];
                    (t.tenant, t.next_unsubmitted, c.cmd.is_some_and(|c| c.opcode == pop::PKT_PROCESS))
                };
                let rec = &mut self.tenants[tenant as usize];
                let staging = if needs_staging {
                    match rec.staging_free.pop() {
                        Some(s) => Some(s),
                        None => break, // wait for a slot
                    }
                } else {
                    None
                };
                let q = rec.net_queues[rec.rr % rec.net_queues.len()];
                rec.rr += 1;
                // tag
                let mut tag = self.next_tag;
                loop {
                    if tag != 0 && !self.tags.contains_key(&((q as u64) << 32 | tag as u64)) {
                        break;
                    }
                    tag = tag.wrapping_add(1);
                }
                self.next_tag = tag.wrapping_add(1);
                let t = self.tickets.get_mut(&id).unwrap();
                let ch = &mut t.chunks[ci];
                let res = if let Some(mut cmd) = ch.cmd {
                    cmd.tag = tag;
                    if let Some(s) = staging {
                        cmd.sram_off = s;
                    }
                    ch.cmd = Some(cmd);
                    self.be.submit(q, &cmd.encode())
                } else {
                    let mut e = ch.ext.clone().unwrap();
                    match &mut e {
                        ExtCmd::GemmI8 { tag: t, .. } | ExtCmd::AesGcm { tag: t, .. } | ExtCmd::StorageWrite { tag: t, .. } | ExtCmd::StorageRead { tag: t, .. } => *t = tag,
                    }
                    ch.ext = Some(e.clone());
                    self.be.submit_ext(q, &e)
                };
                match res {
                    Ok(()) => {
                        ch.staging = staging;
                        ch.submitted = true;
                        t.next_unsubmitted += 1;
                        t.inflight += 1;
                        self.tags.insert((q as u64) << 32 | tag as u64, (id, ci));
                    }
                    Err(DevError::QueueFull) => {
                        if let Some(s) = staging {
                            self.tenants[tenant as usize].staging_free.push(s);
                        }
                        break;
                    }
                    Err(e) => {
                        // a submission that the device refuses outright fails the whole ticket
                        if let Some(s) = staging {
                            self.tenants[tenant as usize].staging_free.push(s);
                        }
                        let t = self.tickets.get_mut(&id).unwrap();
                        t.chunks[ci].done = Some(ChunkRes { err: perr::INTERNAL, ..Default::default() });
                        t.next_unsubmitted += 1;
                        t.cancelled = true;
                        let _ = e;
                        break;
                    }
                }
            }
            self.maybe_finish(id);
        }
    }

    // -------------------------------------------------------------------------------------- completions
    fn on_completion(&mut self, q: u32, c: Cpl) {
        let key = (q as u64) << 32 | c.tag as u64;
        let Some((tid, ci)) = self.tags.remove(&key) else {
            self.stats.anomalies_unknown_tag += 1;
            return;
        };
        let Some(t) = self.tickets.get_mut(&tid) else {
            self.stats.anomalies_unknown_tag += 1;
            return;
        };
        let mismatch = c.tenant as u32 != t.tenant;
        let tenant = t.tenant;
        let ch = &mut t.chunks[ci];
        let mut res = ChunkRes { err: c.err, ts: Some(c.ts), bytes: c.bytes, crc_in: c.crc_in, crc_out: c.crc_out, csum: c.csum, committed: c.committed() };
        if mismatch {
            // a completion of another tenant's record arrived on this ticket's queue/tag: an integrity violation
            self.stats.anomalies_tenant_mismatch += 1;
            res = ChunkRes { err: perr::TENANT_MISMATCH, ts: Some(c.ts), ..Default::default() };
        }
        ch.done = Some(res);
        t.inflight -= 1;
        if c.err == perr::TIMEOUT {
            t.quarantine = true;
        }
        let zombie = c.err == perr::TIMEOUT;
        if let Some(s) = ch.staging.take() {
            let rec = &mut self.tenants[tenant as usize];
            if zombie {
                rec.staging_zombie.push(s);
            } else {
                rec.staging_free.push(s);
            }
        }
        if res.err != 0 {
            // stop submitting the rest of an already-failed ticket
            let t = self.tickets.get_mut(&tid).unwrap();
            t.cancelled = true;
        }
        self.maybe_finish(tid);
    }

    fn maybe_finish(&mut self, id: u64) {
        let Some(t) = self.tickets.get_mut(&id) else { return };
        if t.result.is_some() || t.inflight > 0 {
            return;
        }
        // finished when everything submitted has completed and nothing more will be submitted
        let all_submitted = t.next_unsubmitted >= t.chunks.len();
        if !(all_submitted || t.cancelled) {
            return;
        }
        let tenant = t.tenant;
        let kind = t.kind;
        let mut status = Status::Ok;
        let mut dev_err = 0u8;
        let (mut bytes, mut committed) = (0u64, true);
        let (mut crc_in, mut crc_out, mut csum): (Option<u32>, Option<u32>, Option<u16>) = (None, None, None);
        let mut any_err = false;
        for ch in &t.chunks {
            match ch.done {
                Some(r) => {
                    if r.err != 0 && !any_err {
                        any_err = true;
                        dev_err = r.err;
                        status = map_dev_err(r.err);
                    }
                    bytes += r.bytes as u64;
                    committed &= r.committed || ch.cmd.is_some_and(|c| c.opcode == pop::NOP);
                    if matches!(kind, OpKind::PktProcess | OpKind::Copy) && r.err == 0 {
                        crc_in = Some(match crc_in {
                            Some(a) => proto::crc32_combine(a, r.crc_in, ch.len as u64),
                            None => r.crc_in,
                        });
                        crc_out = Some(match crc_out {
                            Some(a) => proto::crc32_combine(a, r.crc_out, ch.len as u64),
                            None => r.crc_out,
                        });
                        csum = Some(match csum {
                            Some(a) => proto::csum_combine(a, r.csum),
                            None => r.csum,
                        });
                    }
                }
                None => {
                    // never submitted (cancelled after an earlier failure)
                    committed = false;
                }
            }
        }
        if !any_err && t.chunks.iter().any(|c| c.done.is_none()) {
            // cancelled for a reason other than a chunk error (deprovision)
            status = Status::Reset;
        }
        if status != Status::Ok {
            committed = false;
        }
        // Latency from the DPU's own timestamps: exact, not quantised to the pump step.  (Falls back to the
        // observation time only if no chunk produced a device timestamp, e.g. everything was failed locally.)
        let submit_dev = (t.submit_cycle as i64 - self.time_offset) as u32;
        let dev_lat = t.chunks.iter().filter_map(|ch| ch.done.and_then(|r| r.ts)).map(|ts| ts.wrapping_sub(submit_dev)).filter(|d| *d < (1 << 30)).max();
        let latency_cycles = dev_lat.map(|d| d as u64).unwrap_or_else(|| self.be.cycles().saturating_sub(t.submit_cycle));
        let latency_ns = t.submit_at.elapsed().as_nanos() as u64;
        let n_chunks = t.chunks.len() as u32;
        let pins = std::mem::take(&mut t.pins);
        let quarantine = t.quarantine;
        t.result = Some(Completion { kind, status, dev_err, bytes, crc_in, crc_out, csum, committed, chunks: n_chunks, latency_cycles, latency_ns });
        // The device has returned every command of this ticket: only now are the buffers released.
        self.unpin(&pins, quarantine);
        let rec = &mut self.tenants[tenant as usize];
        rec.usage.inflight -= 1;
        rec.usage.completed += 1;
        rec.finished_unreaped += 1;
        if status == Status::Ok {
            rec.usage.bytes_ok += bytes;
            self.stats.ok += 1;
            self.stats.bytes_ok += bytes;
            let ki = OpKind::ALL.iter().position(|k| *k == kind).unwrap();
            self.stats.by_kind_ok[ki] += 1;
        } else {
            rec.usage.errors += 1;
            self.stats.failed += 1;
        }
        self.stats.by_status[status_index(status)] += 1;
        if dev_err != 0 {
            self.stats.dev_err_counts[(dev_err as usize).min(63)] += 1;
        }
        let bi = LAT_BUCKETS.iter().position(|&b| latency_cycles < b).unwrap_or(6);
        self.stats.lat_buckets[bi] += 1;
        self.stats.lat_sum_cycles += latency_cycles;
        self.stats.lat_sum_ns += latency_ns;
        self.stats.lat_count += 1;
    }

    fn take_ticket(&mut self, tenant: u32, t: Ticket) -> SfResult<Option<Completion>> {
        let owned = (t.0 >> 56) as u32 == tenant && ((t.0 >> 40) & 0xFFFF) as u16 == self.epoch;
        let Some(rec) = self.tickets.get(&t.0).filter(|_| owned) else {
            if !owned {
                self.stats.cross_tenant_attempts += 1;
                if let Some(r) = self.tenants.get_mut(tenant as usize) {
                    r.usage.cross_tenant_attempts += 1;
                }
            }
            return err(Status::StaleHandle, "ticket is unknown, already collected, or belongs to another tenant");
        };
        if rec.result.is_none() {
            return Ok(None);
        }
        let rec = self.tickets.remove(&t.0).unwrap();
        self.tenants[tenant as usize].finished_unreaped -= 1;
        Ok(rec.result)
    }

    // -------------------------------------------------------------------------------------- reset / recovery
    /// Data-plane reset: the DPU aborts running jobs (`ERR_RESET_ABORT`), clears zombies and resumes; tenant
    /// configuration and queued descriptors survive.
    fn reset_dataplane(&mut self) -> SfResult<()> {
        self.wr(reg::G_CTRL, reg::CTRL_EN | reg::CTRL_DP_RESET)?;
        self.wr(reg::G_CTRL, reg::CTRL_EN)?;
        let budget = self.cycle_budget;
        self.wait_for("data-plane reset", budget, |c| Ok(c.rd(reg::G_STATUS)? & (reg::STATUS_RESETTING | reg::STATUS_HALTED) == 0))?;
        self.collect();
        self.stats.resets_soft += 1;
        // zombies are gone: release quarantined buffers and staging slots
        for b in self.bufs.iter_mut() {
            if b.state == BufState::Quarantined {
                b.writers = 0;
                b.readers = 0;
                b.state = BufState::HostOwned;
            }
        }
        for r in self.tenants.iter_mut() {
            let z: Vec<u32> = r.staging_zombie.drain(..).collect();
            r.staging_free.extend(z);
        }
        Ok(())
    }

    /// Hard reset: every device-side state is lost, so every outstanding command is failed locally with
    /// `Reset`, and the tenants are re-provisioned from the mediator's configuration records.
    fn reset_hard(&mut self) -> SfResult<()> {
        dev(self.be.reset())?;
        self.stats.resets_hard += 1;
        self.tags.clear();
        let ids: Vec<u64> = self.tickets.iter().filter(|(_, t)| t.result.is_none()).map(|(k, _)| *k).collect();
        for id in ids {
            let t = self.tickets.get_mut(&id).unwrap();
            for ch in t.chunks.iter_mut() {
                if ch.submitted && ch.done.is_none() {
                    ch.done = Some(ChunkRes { err: perr::RESET_ABORT, ..Default::default() });
                }
            }
            t.inflight = 0;
            t.cancelled = true;
            t.quarantine = false;
            self.maybe_finish(id);
        }
        for b in self.bufs.iter_mut() {
            if b.state == BufState::Quarantined {
                b.writers = 0;
                b.readers = 0;
                b.state = BufState::HostOwned;
            }
        }
        // restore device state
        self.enabled = false;
        let live: Vec<u32> = (0..self.geo.tenants).filter(|&t| self.tenants[t as usize].live).collect();
        for t in live {
            let r = &self.tenants[t as usize];
            let (ib, isz, ob, osz, sb, ss, pol) = (r.in_win.0, r.in_win.1, r.out_win.0, r.out_win.1, r.sram.0, r.sram.1, r.cfg.quarantine_on_violation);
            self.wr(reg::tenant(t, reg::T_SRAM_BASE), sb)?;
            self.wr(reg::tenant(t, reg::T_SRAM_SIZE), ss)?;
            self.wr(reg::tenant(t, reg::T_POLICY), pol as u32)?;
            for (w, (base, size, perm)) in [(0u32, (ib, isz, reg::WIN_VALID | reg::WIN_R)), (1, (ob, osz, reg::WIN_VALID | reg::WIN_R | reg::WIN_W))] {
                self.wr(reg::win(t, w, reg::WIN_BASE_LO), base as u32)?;
                self.wr(reg::win(t, w, reg::WIN_BASE_HI), (base >> 32) as u32)?;
                self.wr(reg::win(t, w, reg::WIN_SIZE), size as u32)?;
                self.wr(reg::win(t, w, reg::WIN_CTRL), perm)?;
            }
            self.wr(reg::tenant(t, reg::T_CMD), tcmd::COMMIT)?;
            let budget = self.cycle_budget;
            self.wait_for("tenant re-commit", budget, |c| Ok(c.rd(reg::tenant(t, reg::T_CFG_STATUS))? != pcfg::NONE))?;
            self.wait_for("partition scrub", budget, |c| {
                let s = c.rd(reg::tenant(t, reg::T_STATE))?;
                Ok(s & 7 == tstate::DISABLED && s & 0x100 != 0)
            })?;
            self.wr(reg::tenant(t, reg::T_CMD), tcmd::ENABLE)?;
            // device-local buffers lost their contents (the partition was scrubbed)
        }
        if self.tenants.iter().any(|t| t.live) {
            self.wr(reg::G_CTRL, reg::CTRL_EN)?;
            self.enabled = true;
        }
        self.wr(reg::L_CTRL, 1)?;
        self.calibrate_time();
        Ok(())
    }

    fn recover_tenant(&mut self, id: u32) -> SfResult<()> {
        self.tenant_live(id)?;
        self.wr(reg::tenant(id, reg::T_CMD), tcmd::RECOVER)?;
        let budget = self.cycle_budget;
        self.wait_for("tenant recovery (drain + scrub)", budget, |c| {
            let s = c.rd(reg::tenant(id, reg::T_STATE))?;
            Ok(s & 7 == tstate::DISABLED && s & 0x100 != 0)
        })?;
        self.wr(reg::tenant(id, reg::T_CMD), tcmd::ENABLE)?;
        let s = self.rd(reg::tenant(id, reg::T_STATE))?;
        if s & 7 != tstate::ACTIVE {
            return err(Status::TenantState, "tenant did not return to ACTIVE");
        }
        Ok(())
    }

    // -------------------------------------------------------------------------------------- observability
    fn health(&mut self) -> Health {
        let status = match self.rd(reg::G_STATUS) {
            Ok(s) => s,
            Err(e) => return Health::Unavailable(e.to_string()),
        };
        let fst = self.rd(reg::G_FAULT_STATUS).unwrap_or(0);
        let mut faulted = vec![];
        let mut degraded = vec![];
        if status & reg::STATUS_HALTED != 0 {
            faulted.push("data plane halted after a job watchdog timeout (data-plane reset required)".to_string());
        }
        for (bit, name) in proto::flt::NAMES.iter().enumerate() {
            if fst & (1 << bit) != 0 {
                match bit as u32 {
                    proto::flt::TIMEOUT | proto::flt::INTERNAL | proto::flt::SRAM_ERR => faulted.push(format!("sticky fault: {name}")),
                    proto::flt::RESET_DONE => {}
                    _ => degraded.push(format!("sticky fault: {name}")),
                }
            }
        }
        match self.thermal {
            ThermalState::Warning(t) => degraded.push(format!("thermal warning ({t:.1} C, external sensor)")),
            ThermalState::Critical(t) => faulted.push(format!("thermal critical ({t:.1} C, external sensor)")),
            _ => {}
        }
        for t in 0..self.geo.tenants {
            if self.tenants[t as usize].live {
                if let Ok(s) = self.rd(reg::tenant(t, reg::T_STATE)) {
                    if s & 7 == tstate::QUARANTINED {
                        degraded.push(format!("tenant {t} is quarantined"));
                    }
                }
            }
        }
        if !faulted.is_empty() {
            faulted.extend(degraded);
            Health::Faulted(faulted)
        } else if !degraded.is_empty() {
            Health::Degraded(degraded)
        } else {
            Health::Healthy
        }
    }

    fn device_info(&self, tenant: Option<u32>) -> DeviceInfo {
        let b = self.geo.block_status;
        let names = ["packetcore", "clouddma", "virtualio", "inference", "crypto", "storage", "telemetry", "controlcore"];
        DeviceInfo {
            backend: self.info.clone(),
            geometry: self.geo.clone(),
            runtime_version: crate::RUNTIME_VERSION,
            abi_version: (crate::ABI_MAJOR, crate::ABI_MINOR),
            tenant,
            blocks: names.iter().enumerate().map(|(i, n)| (*n, blk::name(b >> (2 * i)))).collect(),
        }
    }

    fn counters(&mut self) -> SfResult<DeviceCounters> {
        let mut global = [0u64; 16];
        for (k, g) in global.iter_mut().enumerate() {
            *g = self.rd64(reg::perf_global(k as u32))?;
        }
        let mut tenants = Vec::new();
        for t in 0..self.geo.tenants {
            tenants.push(self.tenant_counters(t)?);
        }
        Ok(DeviceCounters { global, tenants, stats: self.stats.clone(), cycles: self.be.cycles() })
    }

    fn tenant_counters(&mut self, t: u32) -> SfResult<TenantCounters> {
        let cmds = self.rd64(reg::perf_tenant(t, 0))?;
        let bytes = self.rd64(reg::perf_tenant(t, 8))?;
        let viol = self.rd(reg::perf_tenant(t, 0x18))?;
        let errs = self.rd(reg::perf_tenant(t, 0x1C))?;
        let state = self.rd(reg::tenant(t, reg::T_STATE))? & 7;
        Ok(TenantCounters { tenant: t, usage: self.tenants[t as usize].usage.clone(), dev_cmds: cmds, dev_bytes: bytes, dev_violations: viol, dev_errors: errs, state })
    }

    fn snapshot(&mut self) -> SfResult<Snapshot> {
        let health = self.health();
        let counters = self.counters()?;
        let mut queues = Vec::new();
        for q in 0..(self.geo.net_queues + self.geo.compute_queues) {
            let s = self.rd(reg::queue(q, reg::Q_STATUS))?;
            queues.push(QueueSnapshot {
                queue: q,
                bound_tenant: self.rd(reg::queue(q, reg::Q_BIND))?,
                queued: s & 0xFF,
                completions_waiting: (s >> 8) & 0xFF,
                compute_class: s & (1 << 16) != 0,
                submitted: self.rd(reg::queue(q, reg::Q_SUBMITTED))?,
                completed: self.rd(reg::queue(q, reg::Q_COMPLETED))?,
                rejected: self.rd(reg::queue(q, reg::Q_REJECTED))?,
            });
        }
        let mut tstates = Vec::new();
        for t in 0..self.geo.tenants {
            let s = self.rd(reg::tenant(t, reg::T_STATE))? & 7;
            tstates.push((t, s, self.tenants[t as usize].live));
        }
        let sram_used: u64 = self.tenants.iter().filter(|t| t.live).map(|t| t.sram.1 as u64).sum();
        let host_used: u64 = self.tenants.iter().filter(|t| t.live).map(|t| t.in_win.1 + t.out_win.1).sum();
        Ok(Snapshot {
            info: self.device_info(None),
            health,
            cycles: self.be.cycles(),
            counters,
            queues,
            fault_status: self.rd(reg::G_FAULT_STATUS)?,
            status_reg: self.rd(reg::G_STATUS)?,
            sram_used,
            sram_capacity: self.geo.sram_bytes as u64,
            host_used,
            host_capacity: self.info.iova_size,
            tlm_dropped: self.rd(reg::L_DROPPED)?,
            tlm_emitted: self.rd(reg::L_EMITTED)?,
            tenant_states: tstates,
            thermal: self.thermal,
        })
    }
}

fn check_align(a: u64, b: u64) -> SfResult<()> {
    if a % 4 != 0 || b % 4 != 0 {
        return err(Status::Alignment, "buffer offsets must be multiples of 4 bytes");
    }
    Ok(())
}

// ================================================================================================ public API
/// Privileged owner of a device.  Hold it only in the trusted component (daemon / node agent); hand tenants a
/// [`Session`].
#[derive(Clone)]
pub struct Mediator {
    core: Arc<Mutex<Core>>,
}

#[derive(Clone, Debug)]
pub struct MediatorOptions {
    /// Device cycles any internal wait may spend before failing with `Timeout`.
    pub cycle_budget: u64,
    /// Hard-reset the device before taking ownership.  Use this when attaching to a device that a previous
    /// (crashed) host runtime may have left configured: nothing about its state is trusted.
    pub reset_on_open: bool,
}

impl Default for MediatorOptions {
    fn default() -> Self {
        MediatorOptions { cycle_budget: 20_000_000, reset_on_open: false }
    }
}

#[derive(Clone, Debug, Default)]
pub struct ShutdownReport {
    pub buffers_released: u32,
    pub tickets_dropped: u32,
    pub keys_wiped: u32,
    pub tenants_released: u32,
}

impl Mediator {
    pub fn open(mut backend: Box<dyn Backend>, opts: MediatorOptions) -> SfResult<Mediator> {
        if opts.reset_on_open {
            dev(backend.reset())?;
        }
        let mut core = Core::open(backend)?;
        core.cycle_budget = opts.cycle_budget;
        Ok(Mediator { core: Arc::new(Mutex::new(core)) })
    }

    fn lock(&self) -> MutexGuard<'_, Core> {
        // A panic while holding the lock leaves invariants unknown; fail loudly instead of continuing.
        self.core.lock().expect("mediator lock poisoned: an earlier operation panicked")
    }

    pub fn info(&self) -> DeviceInfo {
        self.lock().device_info(None)
    }

    pub fn provision_tenant(&self, id: u32, cfg: TenantConfig) -> SfResult<TenantCredential> {
        self.lock().provision(id, cfg)
    }

    pub fn deprovision_tenant(&self, id: u32) -> SfResult<()> {
        self.lock().deprovision(id)
    }

    pub fn open_session(&self, tenant: u32, cred: &TenantCredential) -> SfResult<Session> {
        let c = self.lock();
        c.tenant_live(tenant)?;
        if !ct_eq(&c.tenants[tenant as usize].secret, &cred.0) {
            return err(Status::Permission, "tenant credential rejected");
        }
        drop(c);
        Ok(Session { core: self.core.clone(), tenant })
    }

    pub fn tenant_ids(&self) -> Vec<u32> {
        let c = self.lock();
        (0..c.geo.tenants).filter(|&t| c.tenants[t as usize].live).collect()
    }

    pub fn health(&self) -> Health {
        self.lock().health()
    }

    /// Current device cycle counter (no register access, so reading it does not advance the simulation).
    pub fn device_cycles(&self) -> u64 {
        self.lock().be.cycles()
    }

    pub fn snapshot(&self) -> SfResult<Snapshot> {
        self.lock().snapshot()
    }

    pub fn counters(&self) -> SfResult<DeviceCounters> {
        self.lock().counters()
    }

    /// Run the device for `cycles` and process its output (used by exporters / idle loops).
    pub fn pump(&self, cycles: u64) {
        self.lock().pump(cycles)
    }

    pub fn reset_dataplane(&self) -> SfResult<()> {
        self.lock().reset_dataplane()
    }

    pub fn reset_hard(&self) -> SfResult<()> {
        self.lock().reset_hard()
    }

    pub fn recover_tenant(&self, id: u32) -> SfResult<()> {
        self.lock().recover_tenant(id)
    }

    /// Clear the device's sticky fault bits (W1C) after the cause has been dealt with.
    pub fn clear_faults(&self) -> SfResult<()> {
        self.lock().wr(reg::G_FAULT_STATUS, 0xFF)
    }

    /// Feed an external temperature reading (see [`ThermalState`]).
    pub fn set_thermal(&self, t: ThermalState) {
        self.lock().thermal = t;
    }

    pub fn thermal(&self) -> ThermalState {
        self.lock().thermal
    }

    pub fn set_job_timeout(&self, cycles: u32) -> SfResult<()> {
        self.lock().wr(reg::G_JOB_TIMEOUT, cycles)
    }

    pub fn drain_telemetry(&self) -> Vec<TelemetryEvent> {
        let mut c = self.lock();
        c.collect();
        c.events.drain(..).collect()
    }

    /// Privileged raw management access (the management plane).  Never reachable from a [`Session`].
    pub fn mgmt_read(&self, addr: u32) -> SfResult<u32> {
        self.lock().rd(addr)
    }
    pub fn mgmt_write(&self, addr: u32, v: u32) -> SfResult<()> {
        self.lock().wr(addr, v)
    }

    /// Privileged raw queue access, bypassing every mediator check.  This models a compromised or buggy
    /// tenant driver that can write descriptors straight into its own queue (what SR-IOV virtual functions
    /// would allow) and is used by the security tests to prove that the *hardware* guards stand on their own.
    pub fn raw_submit(&self, queue: u32, cmd: &Cmd) -> SfResult<()> {
        dev(self.lock().be.submit(queue, &cmd.encode()))
    }
    /// Same as [`raw_submit`](Self::raw_submit) for extension commands (cpu-ref only).
    pub fn raw_submit_ext(&self, queue: u32, ext: &ExtCmd) -> SfResult<()> {
        dev(self.lock().be.submit_ext(queue, ext))
    }
    pub fn raw_pop_completion(&self, queue: u32) -> Option<Cpl> {
        let mut c = self.lock();
        c.be.advance(0);
        c.be.pop_completion(queue).map(|w| Cpl::decode(&w))
    }
    pub fn raw_pump(&self, cycles: u64) {
        self.lock().be.advance(cycles);
    }
    pub fn queue_of_tenant(&self, tenant: u32) -> Option<u32> {
        let c = self.lock();
        c.tenants.get(tenant as usize).and_then(|t| t.net_queues.first().copied())
    }
    /// Host window (base, size) of a tenant: (input R, output RW).
    pub fn tenant_windows(&self, tenant: u32) -> Option<((u64, u64), (u64, u64))> {
        let c = self.lock();
        c.tenants.get(tenant as usize).filter(|t| t.live).map(|t| (t.in_win, t.out_win))
    }
    pub fn tenant_partition(&self, tenant: u32) -> Option<(u32, u32)> {
        let c = self.lock();
        c.tenants.get(tenant as usize).filter(|t| t.live).map(|t| t.sram)
    }
    pub fn host_write_raw(&self, iova: u64, data: &[u8]) -> SfResult<()> {
        dev(self.lock().be.host_write(iova, data))
    }
    pub fn host_read_raw(&self, iova: u64, out: &mut [u8]) -> SfResult<()> {
        dev(self.lock().be.host_read(iova, out))
    }

    /// Fault / environment injection (simulated backends only).
    pub fn with_sim<R>(&self, f: impl FnOnce(&mut dyn SimControl) -> R) -> SfResult<R> {
        let mut c = self.lock();
        match c.be.sim() {
            Some(s) => Ok(f(s)),
            None => err(Status::Unsupported, "this backend has no simulation controls"),
        }
    }

    /// Give the device back WITHOUT any orderly teardown: all host-side software state (tenants, buffers, keys,
    /// tickets) is discarded and the device keeps whatever state it has.  This is what a crashed host runtime
    /// leaves behind; recovery is `Mediator::open(.., reset_on_open: true)`.  Fails with `Busy` while sessions
    /// or other clones of this mediator still exist.
    pub fn crash(self) -> SfResult<Box<dyn Backend>> {
        match Arc::try_unwrap(self.core) {
            Ok(m) => {
                let mut core = m.into_inner().expect("mediator lock poisoned");
                for k in core.keys.iter_mut() {
                    wipe(&mut k.key);
                }
                Ok(core.be)
            }
            Err(_) => err(Status::Busy, "sessions or clones of the mediator are still alive"),
        }
    }

    /// Release everything and report what was still allocated.
    pub fn shutdown(&self) -> SfResult<ShutdownReport> {
        let mut c = self.lock();
        let mut rep = ShutdownReport::default();
        rep.tickets_dropped = c.tickets.len() as u32;
        rep.buffers_released = c.bufs.iter().filter(|b| b.state != BufState::Free).count() as u32;
        rep.keys_wiped = c.keys.iter().filter(|k| k.live).count() as u32;
        for t in 0..c.geo.tenants {
            if c.tenants[t as usize].live {
                c.deprovision(t)?;
                rep.tenants_released += 1;
            }
        }
        Ok(rep)
    }
}

/// A tenant's capability on the device.
#[derive(Clone)]
pub struct Session {
    core: Arc<Mutex<Core>>,
    tenant: u32,
}

impl Session {
    fn lock(&self) -> MutexGuard<'_, Core> {
        self.core.lock().expect("mediator lock poisoned: an earlier operation panicked")
    }
    pub fn tenant(&self) -> u32 {
        self.tenant
    }
    pub fn info(&self) -> DeviceInfo {
        self.lock().device_info(Some(self.tenant))
    }
    pub fn alloc(&self, size: u64, flags: u32) -> SfResult<BufHandle> {
        self.lock().alloc_buf(self.tenant, size, flags)
    }
    pub fn free(&self, h: BufHandle) -> SfResult<()> {
        self.lock().free_buf(self.tenant, h)
    }
    pub fn write(&self, h: BufHandle, off: u64, data: &[u8]) -> SfResult<()> {
        self.lock().buf_write(self.tenant, h, off, data)
    }
    pub fn read(&self, h: BufHandle, off: u64, out: &mut [u8]) -> SfResult<()> {
        self.lock().buf_read(self.tenant, h, off, out)
    }
    pub fn buf_size(&self, h: BufHandle) -> SfResult<u64> {
        let mut c = self.lock();
        let i = c.buf_lookup(self.tenant, h.0)?;
        Ok(c.bufs[i].size)
    }
    pub fn buf_state(&self, h: BufHandle) -> SfResult<BufState> {
        let mut c = self.lock();
        let i = c.buf_lookup(self.tenant, h.0)?;
        Ok(c.bufs[i].state)
    }
    pub fn load_key(&self, key: &[u8]) -> SfResult<KeyHandle> {
        self.lock().load_key(self.tenant, key)
    }
    pub fn unload_key(&self, h: KeyHandle) -> SfResult<()> {
        self.lock().unload_key(self.tenant, h)
    }
    pub fn submit(&self, op: &Op) -> SfResult<Ticket> {
        self.lock().submit_op(self.tenant, op)
    }
    /// Non-blocking: advances the device a little, returns `Err(NotReady)` while the operation is running.
    pub fn poll(&self, t: Ticket) -> SfResult<Completion> {
        let mut c = self.lock();
        c.pump(PUMP_CYCLES);
        match c.take_ticket(self.tenant, t)? {
            Some(r) => Ok(r),
            None => err(Status::NotReady, "operation has not completed"),
        }
    }
    /// Blocking wait with a wall-clock timeout and a device-cycle budget; never waits forever.
    pub fn wait(&self, t: Ticket, timeout: Duration) -> SfResult<Completion> {
        let start = Instant::now();
        let mut spent = 0u64;
        loop {
            {
                let mut c = self.lock();
                c.pump(PUMP_CYCLES);
                spent += PUMP_CYCLES;
                if let Some(r) = c.take_ticket(self.tenant, t)? {
                    return Ok(r);
                }
                if spent >= c.cycle_budget {
                    return err(Status::Timeout, format!("operation did not complete within {spent} device cycles; it may still be running"));
                }
            }
            if start.elapsed() >= timeout {
                return err(Status::Timeout, format!("operation did not complete within {:?}; it may still be running", timeout));
            }
        }
    }
    pub fn counters(&self) -> SfResult<TenantCounters> {
        self.lock().tenant_counters(self.tenant)
    }
    /// Take (consume) up to `max` telemetry events of this tenant.
    pub fn telemetry_drain(&self, max: usize) -> Vec<TelemetryEvent> {
        let mut c = self.lock();
        c.collect();
        let t = self.tenant as u8;
        let mut out = Vec::new();
        let mut keep = VecDeque::with_capacity(c.events.len());
        for e in c.events.drain(..) {
            if e.tenant == t && out.len() < max {
                out.push(e);
            } else {
                keep.push_back(e);
            }
        }
        c.events = keep;
        out
    }

    /// Telemetry events of this tenant only (not consumed).
    pub fn telemetry(&self) -> Vec<TelemetryEvent> {
        let mut c = self.lock();
        c.collect();
        let t = self.tenant as u8;
        c.events.iter().filter(|e| e.tenant == t).cloned().collect()
    }
}
