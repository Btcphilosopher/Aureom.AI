//! C ABI (`include/sf_cloud.h`, version 1.0).
//!
//! Rules enforced here for every entry point:
//!   * no panic ever crosses the boundary (`guard!` catches it and returns `SF_ERR_INTERNAL`);
//!   * every pointer argument is checked for NULL; every struct is size-prefixed and copied with the smaller of
//!     the caller's and the library's size, so old callers and new libraries (and vice versa) interoperate;
//!   * failures carry a human-readable detail retrievable with `sf_cloud_last_error()` (thread-local).
#![allow(non_camel_case_types, clippy::missing_safety_doc)]

use crate::backend::{self, BackendSpec, TimingModel};
use crate::mediator::{alloc_flags, BufHandle, Health, KeyHandle, Mediator, MediatorOptions, Op, Session, Snapshot, TenantConfig, TenantCredential, ThermalState, Ticket};
use crate::status::{SfError, SfResult, Status};
use std::cell::RefCell;
use std::ffi::{c_char, c_void, CStr, CString};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::time::Duration;

pub type sf_status = i32;
pub type sf_buf_t = u64;
pub type sf_ticket_t = u64;
pub type sf_key_t = u64;

thread_local! {
    static LAST_ERR: RefCell<CString> = RefCell::new(CString::new("").unwrap());
}

fn set_last(msg: &str) {
    let clean: String = msg.chars().filter(|c| *c != '\0').collect();
    LAST_ERR.with(|e| *e.borrow_mut() = CString::new(clean).unwrap_or_default());
}

fn fail(e: SfError) -> sf_status {
    set_last(&e.to_string());
    e.status.as_i32()
}

fn fail_with(status: Status, msg: &str) -> sf_status {
    set_last(&format!("{}: {msg}", status.name()));
    status.as_i32()
}

macro_rules! guard {
    ($body:expr) => {{
        match catch_unwind(AssertUnwindSafe(|| -> sf_status { $body })) {
            Ok(v) => v,
            Err(p) => {
                let msg = p.downcast_ref::<&str>().map(|s| s.to_string()).or_else(|| p.downcast_ref::<String>().cloned()).unwrap_or_else(|| "panic".into());
                fail_with(Status::Internal, &format!("internal panic contained at the C boundary: {msg}"))
            }
        }
    }};
}

fn ok_or<T>(r: SfResult<T>, f: impl FnOnce(T)) -> sf_status {
    match r {
        Ok(v) => {
            f(v);
            0
        }
        Err(e) => fail(e),
    }
}

// ------------------------------------------------------------------------------------------------ structs
#[repr(C)]
pub struct sf_cloud_open_params {
    pub struct_size: u32,
    pub abi_major: u32,
    pub backend: *const c_char,
    pub flags: u32,
    pub tenant: u32,
    pub default_timeout_ms: u64,
}

#[repr(C)]
pub struct sf_cloud_info_t {
    pub struct_size: u32,
    pub abi_major: u32,
    pub abi_minor: u32,
    pub dpu_abi_major: u32,
    pub dpu_abi_minor: u32,
    pub runtime_version: [c_char; 16],
    pub backend: [c_char; 16],
    pub backend_description: [c_char; 192],
    pub timing_model: [c_char; 112],
    pub measured_on_hardware: u32,
    pub caps: u32,
    pub tenants: u32,
    pub net_queues: u32,
    pub compute_queues: u32,
    pub dma_channels: u32,
    pub data_width: u32,
    pub address_width: u32,
    pub windows: u32,
    pub sram_bytes: u32,
    pub max_xfer: u32,
    pub block_status: u32,
    pub tenant: u32,
    pub admin: u32,
    pub health: u32,
    pub thermal: u32,
    pub health_detail: [c_char; 192],
}

#[repr(C)]
pub struct sf_cloud_tenant_config {
    pub struct_size: u32,
    pub sram_bytes: u32,
    pub host_in_bytes: u64,
    pub host_out_bytes: u64,
    pub max_buffers: u32,
    pub max_inflight: u32,
    pub max_keys: u32,
    pub chunk_bytes: u32,
    pub staging_slots: u32,
    pub quarantine_on_violation: u32,
}

#[repr(C)]
pub struct sf_cloud_op_t {
    pub struct_size: u32,
    pub kind: u32,
    pub src: u64,
    pub dst: u64,
    pub aux: u64,
    pub src_off: u64,
    pub dst_off: u64,
    pub aux_off: u64,
    pub len: u64,
    pub proc_op: u32,
    pub proc_param: u32,
    pub m: u32,
    pub n: u32,
    pub k: u32,
    pub key: u64,
    pub encrypt: u32,
    pub aad_len: u32,
    pub aad: *const u8,
    pub iv: [u8; 12],
    pub blocks: u32,
    pub lba: u64,
}

#[repr(C)]
pub struct sf_cloud_completion_t {
    pub struct_size: u32,
    pub kind: u32,
    pub status: i32,
    pub dev_err: u32,
    pub bytes: u64,
    pub crc_in: u32,
    pub crc_out: u32,
    pub has_crc: u32,
    pub csum: u32,
    pub committed: u32,
    pub chunks: u32,
    pub latency_cycles: u64,
    pub latency_ns: u64,
}

#[repr(C)]
pub struct sf_cloud_counters_t {
    pub struct_size: u32,
    pub tenant: u32,
    pub t_submitted: u64,
    pub t_completed: u64,
    pub t_errors: u64,
    pub t_bytes_ok: u64,
    pub t_cross_tenant_attempts: u64,
    pub t_buffers: u32,
    pub t_keys: u32,
    pub t_inflight: u32,
    pub t_state: u32,
    pub t_host_bytes: u64,
    pub t_device_bytes: u64,
    pub t_dev_cmds: u64,
    pub t_dev_bytes: u64,
    pub t_dev_violations: u32,
    pub t_dev_errors: u32,
    pub device_valid: u32,
    pub reserved: u32,
    pub cycles: u64,
    pub d_cmds_accepted: u64,
    pub d_cmds_retired: u64,
    pub d_cmds_error: u64,
    pub d_dma_bytes_rd: u64,
    pub d_dma_bytes_wr: u64,
    pub d_active_cycles: u64,
    pub d_stall_any: u64,
    pub d_violations: u64,
    pub d_host_errors: u64,
    pub d_timeouts: u64,
    pub d_submitted: u64,
    pub d_ok: u64,
    pub d_failed: u64,
    pub d_resets_soft: u64,
    pub d_resets_hard: u64,
}

#[repr(C)]
pub struct sf_cloud_event_t {
    pub ts: u32,
    pub arg: u32,
    pub event: u8,
    pub tenant: u8,
    pub queue: u8,
    pub reserved: u8,
}

#[repr(C)]
pub struct sf_cloud_device_desc {
    pub id: [c_char; 32],
    pub kind: [c_char; 16],
    pub available: u32,
    pub reserved: u32,
    pub description: [c_char; 160],
    pub reason: [c_char; 192],
}

/// Opaque device handle.
pub struct sf_cloud_device {
    magic: u32,
    mediator: Option<Mediator>,
    session: Option<Session>,
    owns_mediator: bool,
    timeout: Duration,
}

const MAGIC: u32 = 0x5346_4344; // "SFCD"
const CLOSED: u32 = 0xDEAD_C10D;

// ------------------------------------------------------------------------------------------------ helpers
fn put_str<const N: usize>(dst: &mut [c_char; N], s: &str) {
    let b = s.as_bytes();
    let n = b.len().min(N - 1);
    for i in 0..n {
        dst[i] = b[i] as c_char;
    }
    dst[n] = 0;
    for d in dst.iter_mut().skip(n + 1) {
        *d = 0;
    }
}

/// Copy a caller struct (`struct_size` bytes at `p`) into a zeroed library struct, clipped to the smaller size.
unsafe fn read_struct<T>(p: *const T, caller_size: u32) -> T {
    let mut v: T = std::mem::zeroed();
    let n = (caller_size as usize).min(std::mem::size_of::<T>());
    std::ptr::copy_nonoverlapping(p as *const u8, &mut v as *mut T as *mut u8, n);
    v
}

/// Write `v` into the caller's struct, never beyond the size the caller declared.
unsafe fn write_struct<T>(v: &T, p: *mut T, caller_size: u32) {
    let n = (caller_size as usize).min(std::mem::size_of::<T>());
    std::ptr::copy_nonoverlapping(v as *const T as *const u8, p as *mut u8, n);
}

unsafe fn dev_ref<'a>(d: *mut sf_cloud_device) -> Result<&'a sf_cloud_device, sf_status> {
    if d.is_null() {
        return Err(fail_with(Status::InvalidArg, "NULL device handle"));
    }
    let r = &*d;
    if r.magic != MAGIC {
        return Err(fail_with(Status::StaleHandle, "device handle is closed or invalid"));
    }
    Ok(r)
}

fn session(d: &sf_cloud_device) -> Result<&Session, sf_status> {
    d.session.as_ref().ok_or_else(|| fail_with(Status::Permission, "this handle has no tenant session (mediator handle): use sf_cloud_open_session()"))
}
fn mediator(d: &sf_cloud_device) -> Result<&Mediator, sf_status> {
    d.mediator.as_ref().ok_or_else(|| fail_with(Status::Permission, "this call needs a privileged (mediator) handle"))
}

fn health_code(h: &Health) -> u32 {
    match h {
        Health::Healthy => 0,
        Health::Degraded(_) => 1,
        Health::Faulted(_) => 2,
        Health::Unavailable(_) => 3,
    }
}
fn thermal_code(t: &ThermalState) -> u32 {
    match t {
        ThermalState::Unavailable => 0,
        ThermalState::Normal(_) => 1,
        ThermalState::Warning(_) => 2,
        ThermalState::Critical(_) => 3,
    }
}

// ------------------------------------------------------------------------------------------------ library
#[no_mangle]
pub unsafe extern "C" fn sf_cloud_version(major: *mut u32, minor: *mut u32, runtime_version: *mut *const c_char) {
    static VER: &[u8] = concat!(env!("CARGO_PKG_VERSION"), "\0").as_bytes();
    if !major.is_null() {
        *major = crate::ABI_MAJOR;
    }
    if !minor.is_null() {
        *minor = crate::ABI_MINOR;
    }
    if !runtime_version.is_null() {
        *runtime_version = VER.as_ptr() as *const c_char;
    }
}

// NUL-terminated names; must equal Status::name() (checked by tests/c_abi.rs).
fn name_cstr(s: Status) -> &'static [u8] {
    macro_rules! t { ($($v:ident => $n:literal),* $(,)?) => { match s { $(Status::$v => concat!($n, "\0").as_bytes(),)* } } }
    t!(Ok => "SF_OK", InvalidArg => "SF_ERR_INVALID_ARG", Unsupported => "SF_ERR_UNSUPPORTED", NoDevice => "SF_ERR_NO_DEVICE",
       Permission => "SF_ERR_PERMISSION", NoMemory => "SF_ERR_NO_MEMORY", Busy => "SF_ERR_BUSY", StaleHandle => "SF_ERR_STALE_HANDLE",
       Timeout => "SF_ERR_TIMEOUT", QueueFull => "SF_ERR_QUEUE_FULL", DeviceFault => "SF_ERR_DEVICE_FAULT", TenantState => "SF_ERR_TENANT_STATE",
       Isolation => "SF_ERR_ISOLATION", Alignment => "SF_ERR_ALIGNMENT", Range => "SF_ERR_RANGE", NotReady => "SF_ERR_NOT_READY",
       CryptoAuth => "SF_ERR_CRYPTO_AUTH", AbiMismatch => "SF_ERR_ABI_MISMATCH", Reset => "SF_ERR_RESET", Internal => "SF_ERR_INTERNAL",
       BadDescriptor => "SF_ERR_BAD_DESCRIPTOR", Quota => "SF_ERR_QUOTA")
}
#[no_mangle]
pub extern "C" fn sf_cloud_status_str(s: sf_status) -> *const c_char {
    match Status::from_i32(s) {
        Some(st) => name_cstr(st).as_ptr() as *const c_char,
        None => b"SF_ERR_UNKNOWN\0".as_ptr() as *const c_char,
    }
}

#[no_mangle]
pub extern "C" fn sf_cloud_last_error() -> *const c_char {
    LAST_ERR.with(|e| e.borrow().as_ptr())
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_discover(out: *mut sf_cloud_device_desc, max: usize, count: *mut usize) -> sf_status {
    guard!({
        let devs = backend::discover();
        if !count.is_null() {
            *count = devs.len();
        }
        if !out.is_null() {
            for (i, d) in devs.iter().take(max).enumerate() {
                let mut e: sf_cloud_device_desc = std::mem::zeroed();
                put_str(&mut e.id, &d.id);
                put_str(&mut e.kind, d.kind.as_str());
                e.available = d.available as u32;
                put_str(&mut e.description, &d.description);
                put_str(&mut e.reason, &d.reason);
                *out.add(i) = e;
            }
        }
        0
    })
}

// ------------------------------------------------------------------------------------------------ open / close
#[no_mangle]
pub unsafe extern "C" fn sf_cloud_open(params: *const sf_cloud_open_params, out: *mut *mut sf_cloud_device) -> sf_status {
    guard!({
        if params.is_null() || out.is_null() {
            return fail_with(Status::InvalidArg, "NULL params or out");
        }
        *out = std::ptr::null_mut();
        let first = *(params as *const u32);
        let p: sf_cloud_open_params = read_struct(params, first);
        if (first as usize) < 24 {
            return fail_with(Status::InvalidArg, "sf_cloud_open_params.struct_size too small");
        }
        if p.abi_major != crate::ABI_MAJOR {
            return fail_with(Status::AbiMismatch, &format!("caller built against ABI {}, library is {}", p.abi_major, crate::ABI_MAJOR));
        }
        let spec_s = if p.backend.is_null() { "auto".to_string() } else { CStr::from_ptr(p.backend).to_string_lossy().into_owned() };
        let spec = match BackendSpec::parse(&spec_s) {
            Ok(s) => s,
            Err(e) => return fail_with(Status::InvalidArg, &e.to_string()),
        };
        let be = match backend::open_backend(&spec) {
            Ok(b) => b,
            Err(e) => return fail_with(e.status(), &e.to_string()),
        };
        let med = match Mediator::open(be, MediatorOptions::default()) {
            Ok(m) => m,
            Err(e) => return fail(e),
        };
        let timeout = Duration::from_millis(if p.default_timeout_ms == 0 { 10_000 } else { p.default_timeout_ms });
        let mut sess = None;
        if p.flags & 0x1 != 0 {
            // STANDALONE: private device, every tenant provisioned, this handle is tenant + admin
            let n = med.info().geometry.tenants;
            let mut creds = Vec::new();
            for t in 0..n {
                match med.provision_tenant(t, TenantConfig { name: format!("tenant{t}"), ..Default::default() }) {
                    Ok(c) => creds.push(c),
                    Err(e) => {
                        let _ = med.shutdown();
                        return fail(e);
                    }
                }
            }
            if p.tenant >= n {
                let _ = med.shutdown();
                return fail_with(Status::InvalidArg, &format!("tenant {} does not exist (device has {n})", p.tenant));
            }
            sess = match med.open_session(p.tenant, &creds[p.tenant as usize]) {
                Ok(s) => Some(s),
                Err(e) => {
                    let _ = med.shutdown();
                    return fail(e);
                }
            };
        } else if p.flags & 0x2 == 0 {
            return fail_with(Status::InvalidArg, "flags must include SF_OPEN_STANDALONE or SF_OPEN_MEDIATOR");
        }
        *out = Box::into_raw(Box::new(sf_cloud_device { magic: MAGIC, mediator: Some(med), session: sess, owns_mediator: true, timeout }));
        0
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_close(dev: *mut sf_cloud_device) -> sf_status {
    guard!({
        if dev.is_null() {
            return 0;
        }
        if (*dev).magic != MAGIC {
            return fail_with(Status::StaleHandle, "device handle is closed or invalid");
        }
        let mut b = Box::from_raw(dev);
        b.magic = CLOSED;
        let mut rc = 0;
        if b.owns_mediator {
            if let Some(m) = b.mediator.take() {
                b.session = None;
                match m.shutdown() {
                    Ok(_) => {}
                    Err(e) => rc = fail(e),
                }
            }
        }
        // leak the (now closed) box on purpose?  No: free it; the magic check protects against most double closes
        drop(b);
        rc
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_info(dev: *mut sf_cloud_device, out: *mut sf_cloud_info_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        if out.is_null() {
            return fail_with(Status::InvalidArg, "NULL out");
        }
        let cs = *(out as *const u32);
        let (di, tenant, health, thermal) = match (&d.session, &d.mediator) {
            (Some(s), Some(m)) => (s.info(), s.tenant(), m.health(), m.thermal()),
            (Some(s), None) => (s.info(), s.tenant(), Health::Healthy, ThermalState::Unavailable),
            (None, Some(m)) => (m.info(), u32::MAX, m.health(), m.thermal()),
            _ => return fail_with(Status::Internal, "handle without mediator or session"),
        };
        let mut r: sf_cloud_info_t = std::mem::zeroed();
        r.struct_size = std::mem::size_of::<sf_cloud_info_t>() as u32;
        r.abi_major = crate::ABI_MAJOR;
        r.abi_minor = crate::ABI_MINOR;
        r.dpu_abi_major = di.geometry.abi_major;
        r.dpu_abi_minor = di.geometry.abi_minor;
        put_str(&mut r.runtime_version, di.runtime_version);
        put_str(&mut r.backend, &di.backend.name);
        put_str(&mut r.backend_description, &di.backend.description);
        put_str(&mut r.timing_model, di.backend.timing.as_str());
        r.measured_on_hardware = (di.backend.measured_on_hardware && di.backend.timing == TimingModel::Hardware) as u32;
        let c = di.backend.caps;
        r.caps = (c.nop as u32)
            | (c.dma as u32) << 1
            | (c.pkt_process as u32) << 2
            | (c.gemm_i8 as u32) << 3
            | (c.aes_gcm as u32) << 4
            | (c.storage as u32) << 5
            | (c.telemetry as u32) << 6;
        let g = &di.geometry;
        r.tenants = g.tenants;
        r.net_queues = g.net_queues;
        r.compute_queues = g.compute_queues;
        r.dma_channels = g.dma_channels;
        r.data_width = g.data_width;
        r.address_width = g.address_width;
        r.windows = g.windows;
        r.sram_bytes = g.sram_bytes;
        r.max_xfer = g.max_xfer;
        r.block_status = g.block_status;
        r.tenant = tenant;
        r.admin = d.mediator.is_some() as u32;
        r.health = health_code(&health);
        r.thermal = thermal_code(&thermal);
        put_str(&mut r.health_detail, &health.reasons().join("; "));
        write_struct(&r, out, cs);
        0
    })
}

// ------------------------------------------------------------------------------------------------ privileged
fn tenant_cfg(p: *const sf_cloud_tenant_config) -> TenantConfig {
    let mut c = TenantConfig::default();
    if !p.is_null() {
        let cs = unsafe { *(p as *const u32) };
        let v: sf_cloud_tenant_config = unsafe { read_struct(p, cs) };
        // zero fields keep their defaults, so an old caller with a shorter struct still gets sane values
        if v.sram_bytes != 0 {
            c.sram_bytes = v.sram_bytes;
        }
        if v.host_in_bytes != 0 {
            c.host_in_bytes = v.host_in_bytes;
        }
        if v.host_out_bytes != 0 {
            c.host_out_bytes = v.host_out_bytes;
        }
        if v.max_buffers != 0 {
            c.max_buffers = v.max_buffers;
        }
        if v.max_inflight != 0 {
            c.max_inflight = v.max_inflight;
        }
        if v.max_keys != 0 {
            c.max_keys = v.max_keys;
        }
        if v.chunk_bytes != 0 {
            c.chunk_bytes = v.chunk_bytes;
        }
        if v.staging_slots != 0 {
            c.staging_slots = v.staging_slots;
        }
        c.quarantine_on_violation = if cs as usize >= std::mem::size_of::<sf_cloud_tenant_config>() { v.quarantine_on_violation != 0 } else { true };
    }
    c
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_provision_tenant(admin: *mut sf_cloud_device, tenant: u32, cfg: *const sf_cloud_tenant_config, credential_out: *mut u8) -> sf_status {
    guard!({
        let d = match dev_ref(admin) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let m = match mediator(d) {
            Ok(m) => m,
            Err(e) => return e,
        };
        if credential_out.is_null() {
            return fail_with(Status::InvalidArg, "NULL credential_out");
        }
        ok_or(m.provision_tenant(tenant, tenant_cfg(cfg)), |c| std::ptr::copy_nonoverlapping(c.0.as_ptr(), credential_out, 16))
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_deprovision_tenant(admin: *mut sf_cloud_device, tenant: u32) -> sf_status {
    guard!({
        let d = match dev_ref(admin) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let m = match mediator(d) {
            Ok(m) => m,
            Err(e) => return e,
        };
        ok_or(m.deprovision_tenant(tenant), |_| ())
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_open_session(admin: *mut sf_cloud_device, tenant: u32, credential: *const u8, out: *mut *mut sf_cloud_device) -> sf_status {
    guard!({
        let d = match dev_ref(admin) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let m = match mediator(d) {
            Ok(m) => m,
            Err(e) => return e,
        };
        if credential.is_null() || out.is_null() {
            return fail_with(Status::InvalidArg, "NULL credential or out");
        }
        let mut c = [0u8; 16];
        std::ptr::copy_nonoverlapping(credential, c.as_mut_ptr(), 16);
        ok_or(m.open_session(tenant, &TenantCredential(c)), |s| {
            *out = Box::into_raw(Box::new(sf_cloud_device { magic: MAGIC, mediator: None, session: Some(s), owns_mediator: false, timeout: d.timeout }));
        })
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_reset(admin: *mut sf_cloud_device, flags: u32) -> sf_status {
    guard!({
        let d = match dev_ref(admin) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let m = match mediator(d) {
            Ok(m) => m,
            Err(e) => return e,
        };
        if flags & !0x3 != 0 || flags == 0 {
            return fail_with(Status::InvalidArg, "flags must be SF_RESET_DATAPLANE and/or SF_RESET_HARD");
        }
        let r = if flags & 0x2 != 0 { m.reset_hard() } else { m.reset_dataplane().and_then(|_| m.clear_faults()) };
        ok_or(r, |_| ())
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_set_thermal(admin: *mut sf_cloud_device, state: u32, celsius: f32) -> sf_status {
    guard!({
        let d = match dev_ref(admin) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let m = match mediator(d) {
            Ok(m) => m,
            Err(e) => return e,
        };
        m.set_thermal(match state {
            0 => ThermalState::Unavailable,
            1 => ThermalState::Normal(celsius),
            2 => ThermalState::Warning(celsius),
            3 => ThermalState::Critical(celsius),
            _ => return fail_with(Status::InvalidArg, "thermal state must be 0..3"),
        });
        0
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_metrics(admin: *mut sf_cloud_device, buf: *mut c_char, len: usize, needed: *mut usize) -> sf_status {
    guard!({
        let d = match dev_ref(admin) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let m = match mediator(d) {
            Ok(m) => m,
            Err(e) => return e,
        };
        let snap: Snapshot = match m.snapshot() {
            Ok(s) => s,
            Err(e) => return fail(e),
        };
        let text = crate::telemetry::render_prometheus(&snap, None);
        if !needed.is_null() {
            *needed = text.len() + 1;
        }
        if !buf.is_null() && len > 0 {
            let n = text.len().min(len - 1);
            std::ptr::copy_nonoverlapping(text.as_ptr(), buf as *mut u8, n);
            *buf.add(n) = 0;
            if n < text.len() {
                return fail_with(Status::Range, "buffer too small; *needed has the required size");
            }
        }
        0
    })
}

// ------------------------------------------------------------------------------------------------ tenant
#[no_mangle]
pub unsafe extern "C" fn sf_cloud_alloc(dev: *mut sf_cloud_device, size: u64, flags: u32, out: *mut sf_buf_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        if out.is_null() {
            return fail_with(Status::InvalidArg, "NULL out");
        }
        // the C flag values equal alloc_flags (HOST=0, DEVICE=1, DEV_READ=2, DEV_WRITE=4)
        let _ = (alloc_flags::HOST, alloc_flags::DEVICE, alloc_flags::DEV_READ, alloc_flags::DEV_WRITE);
        ok_or(s.alloc(size, flags), |h| *out = h.0)
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_free(dev: *mut sf_cloud_device, buf: sf_buf_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        ok_or(s.free(BufHandle(buf)), |_| ())
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_write(dev: *mut sf_cloud_device, buf: sf_buf_t, offset: u64, src: *const c_void, len: usize) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        if src.is_null() && len > 0 {
            return fail_with(Status::InvalidArg, "NULL src");
        }
        let data: &[u8] = if len == 0 { &[] } else { std::slice::from_raw_parts(src as *const u8, len) };
        ok_or(s.write(BufHandle(buf), offset, data), |_| ())
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_read(dev: *mut sf_cloud_device, buf: sf_buf_t, offset: u64, dst: *mut c_void, len: usize) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        if dst.is_null() && len > 0 {
            return fail_with(Status::InvalidArg, "NULL dst");
        }
        let out: &mut [u8] = if len == 0 { &mut [] } else { std::slice::from_raw_parts_mut(dst as *mut u8, len) };
        ok_or(s.read(BufHandle(buf), offset, out), |_| ())
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_key_load(dev: *mut sf_cloud_device, key: *const u8, len: usize, out: *mut sf_key_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        if key.is_null() || out.is_null() {
            return fail_with(Status::InvalidArg, "NULL key or out");
        }
        ok_or(s.load_key(std::slice::from_raw_parts(key, len)), |h| *out = h.0)
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_key_unload(dev: *mut sf_cloud_device, key: sf_key_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        ok_or(s.unload_key(KeyHandle(key)), |_| ())
    })
}

unsafe fn convert_op(o: &sf_cloud_op_t) -> SfResult<Op> {
    let (src, dst, aux, key) = (BufHandle(o.src), BufHandle(o.dst), BufHandle(o.aux), KeyHandle(o.key));
    Ok(match o.kind {
        0 => Op::Nop,
        1 => Op::PktProcess { src, src_off: o.src_off, dst, dst_off: o.dst_off, len: o.len, proc_op: o.proc_op as u8, param: o.proc_param },
        2 => Op::Copy { src, src_off: o.src_off, dst, dst_off: o.dst_off, len: o.len },
        3 => Op::DmaH2d { src, src_off: o.src_off, dst, dst_off: o.dst_off, len: o.len },
        4 => Op::DmaD2h { src, src_off: o.src_off, dst, dst_off: o.dst_off, len: o.len },
        5 => Op::GemmI8 { a: src, a_off: o.src_off, b: aux, b_off: o.aux_off, c: dst, c_off: o.dst_off, m: o.m, n: o.n, k: o.k },
        6 => {
            if o.aad_len > 0 && o.aad.is_null() {
                return Err(SfError::new(Status::InvalidArg, "aad_len > 0 but aad is NULL"));
            }
            if o.len > u32::MAX as u64 {
                return Err(SfError::new(Status::InvalidArg, "AES-GCM length too large"));
            }
            let aad = if o.aad_len == 0 { vec![] } else { std::slice::from_raw_parts(o.aad, o.aad_len as usize).to_vec() };
            Op::AesGcm { key, encrypt: o.encrypt != 0, iv: o.iv, aad, src, src_off: o.src_off, dst, dst_off: o.dst_off, tag: aux, tag_off: o.aux_off, len: o.len as u32 }
        }
        7 => Op::StorageWrite { src, src_off: o.src_off, lba: o.lba, blocks: o.blocks },
        8 => Op::StorageRead { dst, dst_off: o.dst_off, lba: o.lba, blocks: o.blocks },
        k => return Err(SfError::new(Status::InvalidArg, format!("unknown operation kind {k}"))),
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_submit(dev: *mut sf_cloud_device, op: *const sf_cloud_op_t, out: *mut sf_ticket_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        if op.is_null() || out.is_null() {
            return fail_with(Status::InvalidArg, "NULL op or out");
        }
        let cs = *(op as *const u32);
        if (cs as usize) < std::mem::size_of::<sf_cloud_op_t>() {
            return fail_with(Status::InvalidArg, &format!("sf_cloud_op_t.struct_size {cs} < {} (ABI 1.0 needs the full struct)", std::mem::size_of::<sf_cloud_op_t>()));
        }
        let o: sf_cloud_op_t = read_struct(op, cs);
        let o = match convert_op(&o) {
            Ok(o) => o,
            Err(e) => return fail(e),
        };
        ok_or(s.submit(&o), |t| *out = t.0)
    })
}

fn fill_completion(c: &crate::mediator::Completion, out: *mut sf_cloud_completion_t, cs: u32) {
    let mut r: sf_cloud_completion_t = unsafe { std::mem::zeroed() };
    r.struct_size = std::mem::size_of::<sf_cloud_completion_t>() as u32;
    r.kind = match c.kind {
        crate::mediator::OpKind::Nop => 0,
        crate::mediator::OpKind::PktProcess => 1,
        crate::mediator::OpKind::Copy => 2,
        crate::mediator::OpKind::DmaH2d => 3,
        crate::mediator::OpKind::DmaD2h => 4,
        crate::mediator::OpKind::GemmI8 => 5,
        crate::mediator::OpKind::AesGcm => 6,
        crate::mediator::OpKind::StorageWrite => 7,
        crate::mediator::OpKind::StorageRead => 8,
    };
    r.status = c.status.as_i32();
    r.dev_err = c.dev_err as u32;
    r.bytes = c.bytes;
    if let (Some(a), Some(b), Some(s)) = (c.crc_in, c.crc_out, c.csum) {
        r.has_crc = 1;
        r.crc_in = a;
        r.crc_out = b;
        r.csum = s as u32;
    }
    r.committed = c.committed as u32;
    r.chunks = c.chunks;
    r.latency_cycles = c.latency_cycles;
    r.latency_ns = c.latency_ns;
    unsafe { write_struct(&r, out, cs) };
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_poll(dev: *mut sf_cloud_device, t: sf_ticket_t, out: *mut sf_cloud_completion_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        if out.is_null() {
            return fail_with(Status::InvalidArg, "NULL out");
        }
        let cs = *(out as *const u32);
        match s.poll(Ticket(t)) {
            Ok(c) => {
                fill_completion(&c, out, cs);
                0
            }
            Err(e) => fail(e),
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_wait(dev: *mut sf_cloud_device, t: sf_ticket_t, timeout_ms: u64, out: *mut sf_cloud_completion_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        let s = match session(d) {
            Ok(s) => s,
            Err(e) => return e,
        };
        if out.is_null() {
            return fail_with(Status::InvalidArg, "NULL out");
        }
        let cs = *(out as *const u32);
        let to = if timeout_ms == 0 { d.timeout } else { Duration::from_millis(timeout_ms) };
        match s.wait(Ticket(t), to) {
            Ok(c) => {
                fill_completion(&c, out, cs);
                0
            }
            Err(e) => fail(e),
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_counters(dev: *mut sf_cloud_device, out: *mut sf_cloud_counters_t) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        if out.is_null() {
            return fail_with(Status::InvalidArg, "NULL out");
        }
        let cs = *(out as *const u32);
        let mut r: sf_cloud_counters_t = std::mem::zeroed();
        r.struct_size = std::mem::size_of::<sf_cloud_counters_t>() as u32;
        if let Some(s) = &d.session {
            let tc = match s.counters() {
                Ok(t) => t,
                Err(e) => return fail(e),
            };
            r.tenant = tc.tenant;
            let u = &tc.usage;
            r.t_submitted = u.submitted;
            r.t_completed = u.completed;
            r.t_errors = u.errors;
            r.t_bytes_ok = u.bytes_ok;
            r.t_cross_tenant_attempts = u.cross_tenant_attempts;
            r.t_buffers = u.buffers;
            r.t_keys = u.keys;
            r.t_inflight = u.inflight;
            r.t_state = tc.state;
            r.t_host_bytes = u.host_bytes;
            r.t_device_bytes = u.device_bytes;
            r.t_dev_cmds = tc.dev_cmds;
            r.t_dev_bytes = tc.dev_bytes;
            r.t_dev_violations = tc.dev_violations;
            r.t_dev_errors = tc.dev_errors;
        } else {
            r.tenant = u32::MAX;
        }
        if let Some(m) = &d.mediator {
            let dc = match m.counters() {
                Ok(c) => c,
                Err(e) => return fail(e),
            };
            use crate::proto::reg::cnt;
            let g = &dc.global;
            r.device_valid = 1;
            r.cycles = dc.cycles;
            r.d_cmds_accepted = g[cnt::CMDS_ACCEPTED as usize];
            r.d_cmds_retired = g[cnt::CMDS_RETIRED as usize];
            r.d_cmds_error = g[cnt::CMDS_ERROR as usize];
            r.d_dma_bytes_rd = g[cnt::DMA_BYTES_RD as usize];
            r.d_dma_bytes_wr = g[cnt::DMA_BYTES_WR as usize];
            r.d_active_cycles = g[cnt::ACTIVE_CYCLES as usize];
            r.d_stall_any = g[cnt::STALL_ANY as usize];
            r.d_violations = g[cnt::VIOLATIONS as usize];
            r.d_host_errors = g[cnt::HOST_ERRORS as usize];
            r.d_timeouts = g[cnt::TIMEOUTS as usize];
            r.d_submitted = dc.stats.submitted;
            r.d_ok = dc.stats.ok;
            r.d_failed = dc.stats.failed;
            r.d_resets_soft = dc.stats.resets_soft;
            r.d_resets_hard = dc.stats.resets_hard;
        }
        write_struct(&r, out, cs);
        0
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_telemetry(dev: *mut sf_cloud_device, out: *mut sf_cloud_event_t, max: usize, n: *mut usize) -> sf_status {
    guard!({
        let d = match dev_ref(dev) {
            Ok(d) => d,
            Err(e) => return e,
        };
        if out.is_null() && max > 0 {
            return fail_with(Status::InvalidArg, "NULL out");
        }
        let evs = match (&d.session, &d.mediator) {
            (Some(s), Some(_)) | (Some(s), None) => s.telemetry_drain(max),
            (None, Some(m)) => {
                let mut v = m.drain_telemetry();
                v.truncate(max);
                v
            }
            _ => vec![],
        };
        for (i, e) in evs.iter().enumerate() {
            *out.add(i) = sf_cloud_event_t { ts: e.ts, arg: e.arg, event: e.event, tenant: e.tenant, queue: e.queue, reserved: 0 };
        }
        if !n.is_null() {
            *n = evs.len();
        }
        0
    })
}

#[no_mangle]
pub unsafe extern "C" fn sf_cloud_abi_sizes(out: *mut u32, count: *mut usize) -> sf_status {
    guard!({
        let v = [
            std::mem::size_of::<sf_cloud_open_params>(),
            std::mem::size_of::<sf_cloud_info_t>(),
            std::mem::size_of::<sf_cloud_tenant_config>(),
            std::mem::size_of::<sf_cloud_op_t>(),
            std::mem::size_of::<sf_cloud_completion_t>(),
            std::mem::size_of::<sf_cloud_counters_t>(),
            std::mem::size_of::<sf_cloud_event_t>(),
            std::mem::size_of::<sf_cloud_device_desc>(),
        ];
        if !out.is_null() {
            for (i, s) in v.iter().enumerate() {
                *out.add(i) = *s as u32;
            }
        }
        if !count.is_null() {
            *count = v.len();
        }
        0
    })
}
