//! Telemetry export: device [`Snapshot`] -> Prometheus text exposition and JSON.
//!
//! Every number comes from the device's own counters (register reads) or from the runtime's bookkeeping; nothing
//! is estimated.  Where a quantity does not exist for a backend it is **omitted or labelled**, never faked:
//!   * thermal: `unavailable` until an external reading is fed (the CloudDPU has no sensor path);
//!   * cycle-based rates: only for backends with a timing model;
//!   * every sample carries the backend's identity (`backend`, `timing`, `measured_on_hardware`) in
//!     `silicaflux_device_info`, so a dashboard can never mistake simulation numbers for hardware numbers.

use crate::backend::TimingModel;
use crate::mediator::{Health, OpKind, Snapshot, ThermalState, LAT_BUCKETS};
use crate::proto::{self, blk, reg::cnt, tstate};
use std::fmt::Write;

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")
}

/// Optional derived rates computed by the caller from two snapshots (the library keeps no history).
#[derive(Clone, Copy, Debug, Default)]
pub struct Rates {
    pub bytes_per_second_wall: f64,
    pub bytes_per_device_cycle: Option<f64>,
    pub ops_per_second_wall: f64,
}

struct Out(String);
impl Out {
    fn help(&mut self, name: &str, kind: &str, help: &str) {
        let _ = writeln!(self.0, "# HELP {name} {help}\n# TYPE {name} {kind}");
    }
    fn sample(&mut self, name: &str, labels: &str, v: impl std::fmt::Display) {
        if labels.is_empty() {
            let _ = writeln!(self.0, "{name} {v}");
        } else {
            let _ = writeln!(self.0, "{name}{{{labels}}} {v}");
        }
    }
}

pub fn render_prometheus(s: &Snapshot, rates: Option<Rates>) -> String {
    let mut o = Out(String::with_capacity(8192));
    let b = &s.info.backend;
    o.help("silicaflux_device_info", "gauge", "Identity of the device behind these metrics (1). measured_on_hardware=\"false\" means every number is simulation or model output.");
    o.sample(
        "silicaflux_device_info",
        &format!(
            "backend=\"{}\",kind=\"{}\",timing=\"{}\",measured_on_hardware=\"{}\",runtime_version=\"{}\",dpu_abi=\"{}.{}\"",
            esc(&b.name),
            b.kind.as_str(),
            esc(b.timing.as_str()),
            b.measured_on_hardware,
            s.info.runtime_version,
            s.info.geometry.abi_major,
            s.info.geometry.abi_minor
        ),
        1,
    );
    o.help("silicaflux_device_health", "gauge", "One-hot device health: healthy | degraded | faulted | unavailable.");
    for st in ["healthy", "degraded", "faulted", "unavailable"] {
        o.sample("silicaflux_device_health", &format!("state=\"{st}\""), (s.health.name() == st) as u8);
    }
    if !matches!(s.health, Health::Healthy) {
        o.help("silicaflux_device_health_reason", "gauge", "Reasons for a non-healthy state (1 per reason).");
        for r in s.health.reasons() {
            o.sample("silicaflux_device_health_reason", &format!("reason=\"{}\"", esc(&r)), 1);
        }
    }
    o.help("silicaflux_device_cycles", "counter", "Device cycle counter (rtl-sim: real RTL cycles; cpu-ref: logical counter, not time).");
    o.sample("silicaflux_device_cycles", "", s.cycles);

    o.help("silicaflux_block_status", "gauge", "Honest status of each DPU block: absent | blocked | test-adapter | real.");
    let names = ["packetcore", "clouddma", "virtualio", "inference", "crypto", "storage", "telemetry", "controlcore"];
    for (i, n) in names.iter().enumerate() {
        o.sample("silicaflux_block_status", &format!("block=\"{n}\",status=\"{}\"", blk::name(s.info.geometry.block_status >> (2 * i))), 1);
    }

    // ---- device counters
    let g = &s.counters.global;
    o.help("silicaflux_dpu_commands_total", "counter", "DPU command counters (accepted into a queue / retired with a completion / retired with an error).");
    o.sample("silicaflux_dpu_commands_total", "stage=\"accepted\"", g[cnt::CMDS_ACCEPTED as usize]);
    o.sample("silicaflux_dpu_commands_total", "stage=\"retired\"", g[cnt::CMDS_RETIRED as usize]);
    o.sample("silicaflux_dpu_commands_total", "stage=\"error\"", g[cnt::CMDS_ERROR as usize]);
    o.help("silicaflux_dma_bytes_total", "counter", "Bytes moved by completed DMA beats.");
    o.sample("silicaflux_dma_bytes_total", "direction=\"host_to_device\"", g[cnt::DMA_BYTES_RD as usize]);
    o.sample("silicaflux_dma_bytes_total", "direction=\"device_to_host\"", g[cnt::DMA_BYTES_WR as usize]);
    if b.timing == TimingModel::RtlSimulation || b.timing == TimingModel::Hardware {
        o.help("silicaflux_dpu_cycles_total", "counter", "DPU cycle counters (only for backends with a timing model).");
        for (k, n) in [
            (cnt::ACTIVE_CYCLES, "active"),
            (cnt::STALL_DISPATCH, "stall_dispatch"),
            (cnt::STALL_FABRIC, "stall_fabric"),
            (cnt::STALL_HOST, "stall_host"),
            (cnt::STALL_ANY, "stall_any"),
            (cnt::MEM_CONFLICTS, "memory_conflicts"),
            (cnt::CYCLES, "total"),
        ] {
            o.sample("silicaflux_dpu_cycles_total", &format!("kind=\"{n}\""), g[k as usize]);
        }
    }
    o.help("silicaflux_dpu_events_total", "counter", "DPU error-class events.");
    for (k, n) in [(cnt::ERR_EVENTS, "error"), (cnt::VIOLATIONS, "isolation_violation"), (cnt::HOST_ERRORS, "host_memory_error"), (cnt::TIMEOUTS, "job_timeout")] {
        o.sample("silicaflux_dpu_events_total", &format!("kind=\"{n}\""), g[k as usize]);
    }
    o.help("silicaflux_fault_status", "gauge", "Sticky fault bits of the DPU (1 = set).");
    for (bit, n) in proto::flt::NAMES.iter().enumerate() {
        o.sample("silicaflux_fault_status", &format!("fault=\"{n}\""), (s.fault_status >> bit) & 1);
    }
    o.help("silicaflux_telemetry_events_total", "counter", "CloudTelemetry events generated / dropped by the DPU's export FIFO.");
    o.sample("silicaflux_telemetry_events_total", "state=\"emitted\"", s.tlm_emitted);
    o.sample("silicaflux_telemetry_events_total", "state=\"dropped\"", s.tlm_dropped);

    // ---- throughput
    if let Some(r) = rates {
        o.help(
            "silicaflux_throughput_bytes_per_second",
            "gauge",
            "Verified bytes per WALL-CLOCK second between the last two scrapes (software stack speed; for rtl-sim this is simulation speed, not device speed).",
        );
        o.sample("silicaflux_throughput_bytes_per_second", "source=\"wall_clock\"", format!("{:.1}", r.bytes_per_second_wall));
        o.help("silicaflux_operations_per_second", "gauge", "Completed operations per wall-clock second between the last two scrapes.");
        o.sample("silicaflux_operations_per_second", "source=\"wall_clock\"", format!("{:.2}", r.ops_per_second_wall));
        if let Some(c) = r.bytes_per_device_cycle {
            o.help(
                "silicaflux_throughput_bytes_per_device_cycle",
                "gauge",
                "Verified bytes per DEVICE cycle between the last two scrapes (timing-model backends only; no clock frequency is implied).",
            );
            o.sample("silicaflux_throughput_bytes_per_device_cycle", "", format!("{c:.6}"));
        }
    }

    // ---- memory
    o.help("silicaflux_sram_bytes", "gauge", "Device-local SRAM: capacity and bytes assigned to tenant partitions.");
    o.sample("silicaflux_sram_bytes", "state=\"capacity\"", s.sram_capacity);
    o.sample("silicaflux_sram_bytes", "state=\"assigned\"", s.sram_used);
    o.help("silicaflux_host_window_bytes", "gauge", "Host (IOVA) memory: size of the DMA-reachable range and bytes granted to tenant windows.");
    o.sample("silicaflux_host_window_bytes", "state=\"capacity\"", s.host_capacity);
    o.sample("silicaflux_host_window_bytes", "state=\"granted\"", s.host_used);

    // ---- queues
    o.help("silicaflux_queue_occupancy", "gauge", "Descriptors waiting in a submission queue / completions waiting in its completion queue.");
    for q in &s.queues {
        let lab = |k: &str| format!("queue=\"{}\",tenant=\"{}\",class=\"{}\",kind=\"{k}\"", q.queue, q.bound_tenant, if q.compute_class { "compute" } else { "network" });
        o.sample("silicaflux_queue_occupancy", &lab("submission"), q.queued);
        o.sample("silicaflux_queue_occupancy", &lab("completion"), q.completions_waiting);
    }
    o.help("silicaflux_queue_commands_total", "counter", "Per-queue descriptors submitted / completions delivered / completions with an error.");
    for q in &s.queues {
        let lab = |k: &str| format!("queue=\"{}\",kind=\"{k}\"", q.queue);
        o.sample("silicaflux_queue_commands_total", &lab("submitted"), q.submitted);
        o.sample("silicaflux_queue_commands_total", &lab("completed"), q.completed);
        o.sample("silicaflux_queue_commands_total", &lab("rejected"), q.rejected);
    }

    // ---- completion latency
    let st = &s.counters.stats;
    o.help("silicaflux_completion_latency_cycles", "histogram", "Operation latency from submission to completion-record creation in device cycles (the record is host-visible ~2 cycles later), from the DPU's own cycle counter (includes queueing behind other work; exact on rtl-sim via a simulation back door; cpu-ref: logical cycles).");
    let mut cum = 0u64;
    for (i, ub) in LAT_BUCKETS.iter().enumerate() {
        cum += st.lat_buckets[i];
        let le = if *ub == u64::MAX { "+Inf".to_string() } else { ub.to_string() };
        o.sample("silicaflux_completion_latency_cycles_bucket", &format!("le=\"{le}\""), cum);
    }
    o.sample("silicaflux_completion_latency_cycles_sum", "", st.lat_sum_cycles);
    o.sample("silicaflux_completion_latency_cycles_count", "", st.lat_count);
    o.help("silicaflux_completion_latency_seconds_sum", "counter", "Wall-clock seconds spent between submission and observed completion, summed over operations.");
    o.sample("silicaflux_completion_latency_seconds_sum", "", format!("{:.9}", st.lat_sum_ns as f64 / 1e9));

    // ---- runtime ops / errors
    o.help("silicaflux_runtime_operations_total", "counter", "Operations by final status.");
    o.sample("silicaflux_runtime_operations_total", "status=\"SF_OK\"", st.ok);
    for (i, n) in st.by_status.iter().enumerate().skip(1) {
        if *n > 0 {
            if let Some(sv) = crate::status::Status::from_i32(-(i as i32)) {
                o.sample("silicaflux_runtime_operations_total", &format!("status=\"{}\"", sv.name()), n);
            }
        }
    }
    o.help("silicaflux_runtime_operations_ok_total", "counter", "Successful operations by kind.");
    for (i, k) in OpKind::ALL.iter().enumerate() {
        o.sample("silicaflux_runtime_operations_ok_total", &format!("op=\"{}\"", k.name()), st.by_kind_ok[i]);
    }
    o.help("silicaflux_runtime_bytes_ok_total", "counter", "Bytes of successfully completed operations.");
    o.sample("silicaflux_runtime_bytes_ok_total", "", st.bytes_ok);
    o.help("silicaflux_device_errors_total", "counter", "Operations that failed, by raw DPU error code.");
    for (code, n) in st.dev_err_counts.iter().enumerate() {
        if *n > 0 {
            o.sample("silicaflux_device_errors_total", &format!("code=\"0x{code:02x}\",name=\"{}\"", proto::err::name(code as u8)), n);
        }
    }
    o.help(
        "silicaflux_integrity_anomalies_total",
        "counter",
        "Completions that matched no ticket / carried a foreign tenant / handles used across tenants. Anything non-zero deserves attention.",
    );
    o.sample("silicaflux_integrity_anomalies_total", "kind=\"unknown_tag\"", st.anomalies_unknown_tag);
    o.sample("silicaflux_integrity_anomalies_total", "kind=\"tenant_mismatch\"", st.anomalies_tenant_mismatch);
    o.sample("silicaflux_integrity_anomalies_total", "kind=\"cross_tenant_handle\"", st.cross_tenant_attempts);
    o.help("silicaflux_device_resets_total", "counter", "Resets performed by the mediator.");
    o.sample("silicaflux_device_resets_total", "kind=\"data_plane\"", st.resets_soft);
    o.sample("silicaflux_device_resets_total", "kind=\"hard\"", st.resets_hard);

    // ---- thermal
    o.help(
        "silicaflux_thermal_state",
        "gauge",
        "One-hot thermal state. 'unavailable': the CloudDPU has no thermal sensor path (PowerClock not integrated); a value appears only if an external source feeds one.",
    );
    for n in ["unavailable", "normal", "warning", "critical"] {
        o.sample("silicaflux_thermal_state", &format!("state=\"{n}\""), (s.thermal.name() == n) as u8);
    }
    if let ThermalState::Normal(t) | ThermalState::Warning(t) | ThermalState::Critical(t) = s.thermal {
        o.help("silicaflux_temperature_celsius", "gauge", "Temperature fed by an EXTERNAL sensor (not measured by the runtime or the DPU).");
        o.sample("silicaflux_temperature_celsius", "source=\"external\"", format!("{t:.2}"));
    }

    // ---- per-tenant (per-domain) usage
    o.help("silicaflux_tenant_state", "gauge", "One-hot hardware tenant state.");
    for (t, hw, live) in &s.tenant_states {
        if !live {
            continue;
        }
        for n in ["disabled", "active", "draining", "scrubbing", "quarantined"] {
            o.sample("silicaflux_tenant_state", &format!("tenant=\"{t}\",state=\"{n}\""), (tstate::name(*hw) == n) as u8);
        }
    }
    o.help("silicaflux_tenant_resources", "gauge", "Per-tenant resource usage (buffers, host bytes, device bytes, keys, in-flight operations).");
    o.help("silicaflux_tenant_operations_total", "counter", "Per-tenant operations: submitted / completed / failed; bytes of successful operations.");
    o.help("silicaflux_tenant_device_total", "counter", "Per-tenant counters read from the DPU: commands retired, bytes, isolation violations, errors.");
    for t in &s.counters.tenants {
        if !s.tenant_states.iter().any(|(id, _, live)| *id == t.tenant && *live) {
            continue;
        }
        let l = |k: &str| format!("tenant=\"{}\",kind=\"{k}\"", t.tenant);
        let u = &t.usage;
        o.sample("silicaflux_tenant_resources", &l("buffers"), u.buffers);
        o.sample("silicaflux_tenant_resources", &l("host_bytes"), u.host_bytes);
        o.sample("silicaflux_tenant_resources", &l("device_bytes"), u.device_bytes);
        o.sample("silicaflux_tenant_resources", &l("keys"), u.keys);
        o.sample("silicaflux_tenant_resources", &l("inflight"), u.inflight);
        o.sample("silicaflux_tenant_operations_total", &l("submitted"), u.submitted);
        o.sample("silicaflux_tenant_operations_total", &l("completed"), u.completed);
        o.sample("silicaflux_tenant_operations_total", &l("failed"), u.errors);
        o.sample("silicaflux_tenant_operations_total", &l("bytes_ok"), u.bytes_ok);
        o.sample("silicaflux_tenant_device_total", &l("commands"), t.dev_cmds);
        o.sample("silicaflux_tenant_device_total", &l("bytes"), t.dev_bytes);
        o.sample("silicaflux_tenant_device_total", &l("violations"), t.dev_violations);
        o.sample("silicaflux_tenant_device_total", &l("errors"), t.dev_errors);
    }
    o.0
}

fn jesc(s: &str) -> String {
    let mut o = String::with_capacity(s.len() + 2);
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            c if (c as u32) < 0x20 => {
                let _ = write!(o, "\\u{:04x}", c as u32);
            }
            c => o.push(c),
        }
    }
    o
}

/// Compact JSON of the snapshot for dashboards.
pub fn snapshot_json(s: &Snapshot) -> String {
    let b = &s.info.backend;
    let g = &s.counters.global;
    let st = &s.counters.stats;
    let mut o = String::new();
    let _ = write!(
        o,
        "{{\"backend\":{{\"name\":\"{}\",\"kind\":\"{}\",\"description\":\"{}\",\"timing\":\"{}\",\"measured_on_hardware\":{}}},",
        jesc(&b.name),
        b.kind.as_str(),
        jesc(&b.description),
        jesc(b.timing.as_str()),
        b.measured_on_hardware
    );
    let _ = write!(
        o,
        "\"health\":{{\"state\":\"{}\",\"reasons\":[{}]}},",
        s.health.name(),
        s.health.reasons().iter().map(|r| format!("\"{}\"", jesc(r))).collect::<Vec<_>>().join(",")
    );
    let _ = write!(o, "\"thermal\":\"{}\",\"cycles\":{},", s.thermal.name(), s.cycles);
    let _ = write!(
        o,
        "\"caps\":{{\"pkt_process\":{},\"dma\":{},\"gemm_i8\":{},\"aes_gcm\":{},\"storage\":{}}},",
        b.caps.pkt_process, b.caps.dma, b.caps.gemm_i8, b.caps.aes_gcm, b.caps.storage
    );
    let _ = write!(
        o,
        "\"counters\":{{\"cmds_accepted\":{},\"cmds_retired\":{},\"cmds_error\":{},\"dma_bytes_rd\":{},\"dma_bytes_wr\":{},\"violations\":{},\"host_errors\":{},\"timeouts\":{}}},",
        g[cnt::CMDS_ACCEPTED as usize],
        g[cnt::CMDS_RETIRED as usize],
        g[cnt::CMDS_ERROR as usize],
        g[cnt::DMA_BYTES_RD as usize],
        g[cnt::DMA_BYTES_WR as usize],
        g[cnt::VIOLATIONS as usize],
        g[cnt::HOST_ERRORS as usize],
        g[cnt::TIMEOUTS as usize]
    );
    let _ =
        write!(o, "\"memory\":{{\"sram_capacity\":{},\"sram_assigned\":{},\"host_capacity\":{},\"host_granted\":{}}},", s.sram_capacity, s.sram_used, s.host_capacity, s.host_used);
    let _ = write!(
        o,
        "\"runtime\":{{\"submitted\":{},\"ok\":{},\"failed\":{},\"bytes_ok\":{},\"latency_cycles_avg\":{:.1},\"latency_count\":{},\"anomalies\":{}}},",
        st.submitted,
        st.ok,
        st.failed,
        st.bytes_ok,
        if st.lat_count > 0 { st.lat_sum_cycles as f64 / st.lat_count as f64 } else { 0.0 },
        st.lat_count,
        st.anomalies_unknown_tag + st.anomalies_tenant_mismatch + st.cross_tenant_attempts
    );
    let _ = write!(
        o,
        "\"queues\":[{}],",
        s.queues
            .iter()
            .map(|q| format!(
                "{{\"queue\":{},\"tenant\":{},\"class\":\"{}\",\"queued\":{},\"completions_waiting\":{}}}",
                q.queue,
                q.bound_tenant,
                if q.compute_class { "compute" } else { "network" },
                q.queued,
                q.completions_waiting
            ))
            .collect::<Vec<_>>()
            .join(",")
    );
    let _ = write!(
        o,
        "\"tenants\":[{}]}}",
        s.counters
            .tenants
            .iter()
            .filter(|t| s.tenant_states.iter().any(|(id, _, live)| *id == t.tenant && *live))
            .map(|t| format!(
                "{{\"tenant\":{},\"state\":\"{}\",\"buffers\":{},\"host_bytes\":{},\"device_bytes\":{},\"keys\":{},\"inflight\":{},\"submitted\":{},\"failed\":{},\"violations\":{}}}",
                t.tenant,
                tstate::name(t.state),
                t.usage.buffers,
                t.usage.host_bytes,
                t.usage.device_bytes,
                t.usage.keys,
                t.usage.inflight,
                t.usage.submitted,
                t.usage.errors,
                t.dev_violations
            ))
            .collect::<Vec<_>>()
            .join(",")
    );
    o
}
