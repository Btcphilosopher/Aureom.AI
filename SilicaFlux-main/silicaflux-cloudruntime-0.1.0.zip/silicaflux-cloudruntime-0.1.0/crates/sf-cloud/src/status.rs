//! Explicit status codes for the whole runtime.  The numeric values are part of the C ABI
//! (`include/sf_cloud.h`) and never change within an ABI major version.

use std::fmt;

#[repr(i32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Status {
    Ok = 0,
    InvalidArg = -1,
    /// The selected backend (or the hardware generation) does not implement the operation.
    Unsupported = -2,
    NoDevice = -3,
    /// The caller lacks the privilege for this call (e.g. a tenant handle calling an admin function).
    Permission = -4,
    NoMemory = -5,
    /// The object is in use (buffer referenced by an in-flight operation, queue busy, ...).
    Busy = -6,
    /// The handle refers to an object that was freed or belongs to an earlier generation.
    StaleHandle = -7,
    /// The wait budget (wall clock or device cycles) ran out.  The operation may still be running.
    Timeout = -8,
    QueueFull = -9,
    /// The device reported a fault while executing this operation (memory error, engine fault, ...).
    DeviceFault = -10,
    TenantState = -11,
    /// An isolation check (hardware guard or mediator) refused the operation.
    Isolation = -12,
    Alignment = -13,
    Range = -14,
    /// poll(): the operation has not completed yet.
    NotReady = -15,
    CryptoAuth = -16,
    AbiMismatch = -17,
    /// The operation was cancelled by a device reset.
    Reset = -18,
    Internal = -19,
    /// The descriptor was malformed or used a reserved field.
    BadDescriptor = -20,
    /// A tenant quota (buffers, bytes, in-flight operations, keys) was exhausted.
    Quota = -21,
}

impl Status {
    pub fn as_i32(self) -> i32 {
        self as i32
    }
    pub fn from_i32(v: i32) -> Option<Status> {
        use Status::*;
        Some(match v {
            0 => Ok,
            -1 => InvalidArg,
            -2 => Unsupported,
            -3 => NoDevice,
            -4 => Permission,
            -5 => NoMemory,
            -6 => Busy,
            -7 => StaleHandle,
            -8 => Timeout,
            -9 => QueueFull,
            -10 => DeviceFault,
            -11 => TenantState,
            -12 => Isolation,
            -13 => Alignment,
            -14 => Range,
            -15 => NotReady,
            -16 => CryptoAuth,
            -17 => AbiMismatch,
            -18 => Reset,
            -19 => Internal,
            -20 => BadDescriptor,
            -21 => Quota,
            _ => return None,
        })
    }
    pub fn name(self) -> &'static str {
        use Status::*;
        match self {
            Ok => "SF_OK",
            InvalidArg => "SF_ERR_INVALID_ARG",
            Unsupported => "SF_ERR_UNSUPPORTED",
            NoDevice => "SF_ERR_NO_DEVICE",
            Permission => "SF_ERR_PERMISSION",
            NoMemory => "SF_ERR_NO_MEMORY",
            Busy => "SF_ERR_BUSY",
            StaleHandle => "SF_ERR_STALE_HANDLE",
            Timeout => "SF_ERR_TIMEOUT",
            QueueFull => "SF_ERR_QUEUE_FULL",
            DeviceFault => "SF_ERR_DEVICE_FAULT",
            TenantState => "SF_ERR_TENANT_STATE",
            Isolation => "SF_ERR_ISOLATION",
            Alignment => "SF_ERR_ALIGNMENT",
            Range => "SF_ERR_RANGE",
            NotReady => "SF_ERR_NOT_READY",
            CryptoAuth => "SF_ERR_CRYPTO_AUTH",
            AbiMismatch => "SF_ERR_ABI_MISMATCH",
            Reset => "SF_ERR_RESET",
            Internal => "SF_ERR_INTERNAL",
            BadDescriptor => "SF_ERR_BAD_DESCRIPTOR",
            Quota => "SF_ERR_QUOTA",
        }
    }
    pub fn describe(self) -> &'static str {
        use Status::*;
        match self {
            Ok => "success",
            InvalidArg => "an argument was invalid",
            Unsupported => "operation not implemented by this backend/device",
            NoDevice => "no matching device",
            Permission => "caller lacks the required privilege",
            NoMemory => "out of memory in the requested domain",
            Busy => "object busy (referenced by an in-flight operation)",
            StaleHandle => "handle was freed or belongs to an earlier generation",
            Timeout => "timed out; the operation may still be running",
            QueueFull => "device queue full",
            DeviceFault => "device reported a fault while executing the operation",
            TenantState => "tenant is not in a state that accepts work",
            Isolation => "an isolation check refused the operation",
            Alignment => "address or length not aligned as required",
            Range => "offset/length outside the object",
            NotReady => "operation has not completed",
            CryptoAuth => "authentication tag mismatch",
            AbiMismatch => "caller and library ABI versions differ",
            Reset => "operation cancelled by a device reset",
            Internal => "internal error",
            BadDescriptor => "malformed descriptor",
            Quota => "tenant quota exhausted",
        }
    }
}

impl fmt::Display for Status {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} ({})", self.name(), self.describe())
    }
}

/// Error type of the Rust API: a status code plus a human-readable detail.
#[derive(Clone, Debug)]
pub struct SfError {
    pub status: Status,
    pub detail: String,
}

impl SfError {
    pub fn new(status: Status, detail: impl Into<String>) -> Self {
        SfError { status, detail: detail.into() }
    }
}

impl fmt::Display for SfError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.status.name(), self.detail)
    }
}

impl std::error::Error for SfError {}

pub type SfResult<T> = Result<T, SfError>;

pub fn err<T>(status: Status, detail: impl Into<String>) -> SfResult<T> {
    Err(SfError::new(status, detail))
}
