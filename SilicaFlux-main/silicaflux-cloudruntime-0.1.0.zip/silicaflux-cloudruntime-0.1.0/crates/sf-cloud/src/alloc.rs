//! First-fit range allocator with coalescing.  Used for host IOVA windows, device-local SRAM partitions and
//! per-tenant buffer placement.  It only hands out ranges; it never touches memory.

#[derive(Clone, Debug)]
pub struct RangeAlloc {
    base: u64,
    size: u64,
    /// sorted, non-overlapping, non-adjacent free ranges (start, len)
    free: Vec<(u64, u64)>,
}

fn align_up(v: u64, a: u64) -> u64 {
    v.div_ceil(a) * a
}

impl RangeAlloc {
    pub fn new(base: u64, size: u64) -> RangeAlloc {
        RangeAlloc { base, size, free: if size > 0 { vec![(base, size)] } else { vec![] } }
    }
    pub fn capacity(&self) -> u64 {
        self.size
    }
    pub fn used(&self) -> u64 {
        self.size - self.free.iter().map(|f| f.1).sum::<u64>()
    }
    pub fn largest_free(&self) -> u64 {
        self.free.iter().map(|f| f.1).max().unwrap_or(0)
    }
    /// Allocate `len` bytes aligned to `align` (power of two).  `len` is rounded up to `align`.
    pub fn alloc(&mut self, len: u64, align: u64) -> Option<u64> {
        if len == 0 || !align.is_power_of_two() {
            return None;
        }
        let len = align_up(len, align);
        for i in 0..self.free.len() {
            let (s, l) = self.free[i];
            let a = align_up(s, align);
            if a >= s && a + len <= s + l {
                let mut repl = Vec::new();
                if a > s {
                    repl.push((s, a - s));
                }
                if a + len < s + l {
                    repl.push((a + len, s + l - (a + len)));
                }
                self.free.splice(i..=i, repl);
                return Some(a);
            }
        }
        None
    }
    /// Return a range.  Panics on double free / foreign range: those are runtime bugs, never tenant input.
    pub fn free(&mut self, start: u64, len: u64, align: u64) {
        let len = align_up(len, align);
        assert!(start >= self.base && start + len <= self.base + self.size, "free outside the allocator range");
        let pos = self.free.partition_point(|f| f.0 < start);
        if pos > 0 {
            let p = self.free[pos - 1];
            assert!(p.0 + p.1 <= start, "double free (overlaps previous free range)");
        }
        if pos < self.free.len() {
            assert!(start + len <= self.free[pos].0, "double free (overlaps next free range)");
        }
        self.free.insert(pos, (start, len));
        // coalesce
        if pos + 1 < self.free.len() && self.free[pos].0 + self.free[pos].1 == self.free[pos + 1].0 {
            self.free[pos].1 += self.free[pos + 1].1;
            self.free.remove(pos + 1);
        }
        if pos > 0 && self.free[pos - 1].0 + self.free[pos - 1].1 == self.free[pos].0 {
            self.free[pos - 1].1 += self.free[pos].1;
            self.free.remove(pos);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn alloc_free_coalesce() {
        let mut a = RangeAlloc::new(0x1000, 0x1000);
        let x = a.alloc(100, 64).unwrap();
        let y = a.alloc(100, 64).unwrap();
        assert_eq!((x, y), (0x1000, 0x1080));
        assert_eq!(a.used(), 0x100);
        a.free(x, 100, 64);
        a.free(y, 100, 64);
        assert_eq!(a.used(), 0);
        assert_eq!(a.largest_free(), 0x1000);
    }
    #[test]
    fn exhaustion_and_fragmentation() {
        let mut a = RangeAlloc::new(0, 256);
        let v: Vec<u64> = (0..4).map(|_| a.alloc(64, 64).unwrap()).collect();
        assert!(a.alloc(1, 64).is_none());
        a.free(v[1], 64, 64);
        a.free(v[3], 64, 64);
        assert!(a.alloc(128, 64).is_none()); // fragmented
        a.free(v[2], 64, 64);
        assert_eq!(a.alloc(192, 64), Some(64));
    }
    #[test]
    #[should_panic]
    fn double_free_panics() {
        let mut a = RangeAlloc::new(0, 256);
        let x = a.alloc(64, 64).unwrap();
        a.free(x, 64, 64);
        a.free(x, 64, 64);
    }
}
