//! Differential test: the CPU reference model against the Verilator RTL simulation.
//!
//! The same randomised command stream -- valid commands, every class of malformed descriptor, permission
//! violations, host-memory errors -- is applied to both devices through the privileged raw queue interface
//! (bypassing the mediator, so device-level semantics are compared, not mediator-level ones).  Every completion
//! record field, the complete host-memory image, the performance counters, the tenant states and the telemetry
//! event sequence must match.  Any difference is a bug in the model or in the RTL, never "close enough".
mod common;
use common::*;
use sf_cloud::mediator::{Mediator, MediatorOptions, TenantConfig};
use sf_cloud::proto::{err, op, proc_op, reg, Cmd, Cpl};

const SRAM_WORDS: u32 = 4;

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u64 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0
    }
    fn below(&mut self, n: u64) -> u64 {
        self.next() % n.max(1)
    }
}

struct Env {
    m: Mediator,
    win_in: Vec<(u64, u64)>,
    win_out: Vec<(u64, u64)>,
    part: Vec<(u32, u32)>,
    q: Vec<u32>,
}

fn setup(be: Box<dyn sf_cloud::backend::Backend>) -> Env {
    let m = Mediator::open(be, MediatorOptions { cycle_budget: 4_000_000, ..Default::default() }).unwrap();
    for t in 0..2 {
        m.provision_tenant(t, TenantConfig::default()).unwrap();
    }
    let mut e = Env { m, win_in: vec![], win_out: vec![], part: vec![], q: vec![] };
    for t in 0..2 {
        let (i, o) = e.m.tenant_windows(t).unwrap();
        e.win_in.push(i);
        e.win_out.push(o);
        e.part.push(e.m.tenant_partition(t).unwrap());
        e.q.push(e.m.queue_of_tenant(t).unwrap());
        // identical, deterministic content in both windows
        e.m.host_write_raw(i.0, &data(100 + t as u64, i.1 as usize)).unwrap();
        e.m.host_write_raw(o.0, &data(200 + t as u64, o.1 as usize)).unwrap();
    }
    e
}

/// Submit one raw command and collect its completion (bounded).
fn run(e: &Env, q: u32, cmd: &Cmd) -> Cpl {
    for _ in 0..100 {
        if e.m.raw_submit(q, cmd).is_ok() {
            break;
        }
        e.m.raw_pump(64);
    }
    for _ in 0..20_000 {
        e.m.raw_pump(64);
        if let Some(c) = e.m.raw_pop_completion(q) {
            assert_eq!(c.tag, cmd.tag, "completion tag mismatch");
            return c;
        }
    }
    panic!("no completion for tag {:#x}", cmd.tag);
}

fn gen_cmd(r: &mut Rng, e: &Env, t: usize, tag: u32) -> Cmd {
    let (ib, isz) = e.win_in[t];
    let (ob, osz) = e.win_out[t];
    let psize = e.part[t].1 as u64;
    let other = 1 - t;
    let len = [1u32, 3, 4, 7, 64, 100, 1000, 2048, 4096][r.below(9) as usize];
    let aligned = |r: &mut Rng, base: u64, size: u64, len: u32| -> u64 {
        let max = size.saturating_sub(len as u64 + 4) / 4;
        base + 4 * r.below(max.max(1))
    };
    let mut c = Cmd {
        opcode: op::PKT_PROCESS,
        tenant: t as u8,
        tag,
        len,
        proc_op: [proc_op::PASS, proc_op::XOR32, proc_op::BSWAP32][r.below(3) as usize],
        param: r.next() as u32,
        ..Default::default()
    };
    if c.proc_op == proc_op::BSWAP32 {
        c.len = len.div_ceil(4) * 4;
    }
    c.src = aligned(r, ib, isz, c.len);
    c.dst = aligned(r, ob, osz, c.len);
    c.sram_off = (4 * r.below((psize.saturating_sub(2 * (c.len as u64 + 4))) / 4 + 1)) as u32;
    match r.below(28) {
        0..=9 => {} // valid PKT_PROCESS
        10 | 11 => {
            c.opcode = op::DMA_H2D;
            c.proc_op = 0;
            c.param = 0;
            c.dst = 0;
        } // valid H2D
        12 | 13 => {
            c.opcode = op::DMA_D2H;
            c.proc_op = 0;
            c.param = 0;
            c.src = 0;
        } // valid D2H
        14 => {
            c = Cmd { opcode: op::NOP, tenant: t as u8, tag, ..Default::default() };
        }
        15 => c.len = 0,        // BAD_LENGTH
        16 => c.len = 4096 + 4, // BAD_LENGTH (> MAX_XFER)
        17 => c.src += 1,       // ALIGN
        18 => c.sram_off += 2,  // ALIGN
        19 => c.proc_op = 0x7F, // PROC_OP
        20 => {
            c.proc_op = proc_op::BSWAP32;
            c.len = 5;
        } // PROC_OP (len % 4)
        21 => c.opcode = 0x66,  // BAD_OPCODE
        22 => c.rsvd_w8 = 1,    // BAD_DESC
        23 => c.tenant = other as u8, // TENANT_MISMATCH (violation)
        24 => c.sram_off = psize as u32 - 8, // SRAM_RANGE (violation)
        25 => c.src = e.win_in[other].0, // PERM_READ: other tenant's window
        26 => c.dst = ib + 64,  // PERM_WRITE: read-only window
        _ => {
            c.opcode = op::INFER;
        } // engine opcode on a network queue
    }
    c
}

fn compare(name_a: &str, a: &Cpl, name_b: &str, b: &Cpl, ctx: &str) {
    // `txn` (DPU transaction id) and `ts` (cycle counter) are implementation details; everything else must agree.
    let strip = |c: &Cpl| Cpl { txn: 0, ts: 0, ..*c };
    assert_eq!(strip(a), strip(b), "{ctx}\n  {name_a}: {a:?}\n  {name_b}: {b:?}");
}

#[test]
fn model_equals_rtl_on_random_streams() {
    let Some(rtl) = rtl_only("mt", "seed=3,lat=3") else { return };
    let cpu = backends("mt").into_iter().next().unwrap().1;
    let (a, b) = (setup(cpu), setup(rtl));
    let mut r = Rng(0x1234_5678_9ABC_DEF1);
    let mut tag = 0x100u32;
    let (mut n_ok, mut n_err, mut n_viol) = (0, 0, 0);
    for step in 0..600 {
        let t = (r.below(2)) as usize;
        let c = gen_cmd(&mut r, &a, t, tag);
        tag += 1;
        let ca = run(&a, a.q[t], &c);
        let cb = run(&b, b.q[t], &c);
        compare("cpu-ref", &ca, "rtl-sim", &cb, &format!("step {step} tenant {t} cmd {c:?}"));
        if ca.err == 0 {
            n_ok += 1
        } else {
            n_err += 1
        }
        if err::is_violation(ca.err) {
            n_viol += 1;
            // the violation quarantines the tenant on both; the next command must be refused identically
            let probe = Cmd { opcode: op::NOP, tenant: t as u8, tag, ..Default::default() };
            tag += 1;
            let pa = run(&a, a.q[t], &probe);
            let pb = run(&b, b.q[t], &probe);
            compare("cpu-ref", &pa, "rtl-sim", &pb, &format!("step {step}: probe after violation"));
            assert_eq!(pa.err, err::QUARANTINED);
            a.m.recover_tenant(t as u32).unwrap();
            b.m.recover_tenant(t as u32).unwrap();
            // recovery scrubbed the partition; the host windows are untouched
        }
    }
    assert!(n_ok > 150 && n_err > 80 && n_viol > 10, "stream must exercise all paths: ok={n_ok} err={n_err} viol={n_viol}");

    // complete host-memory image of both tenants' windows must be byte-identical
    for t in 0..2 {
        for (win_a, win_b) in [(a.win_in[t], b.win_in[t]), (a.win_out[t], b.win_out[t])] {
            assert_eq!(win_a, win_b, "window layout differs");
            let (mut ma, mut mb) = (vec![0u8; win_a.1 as usize], vec![0u8; win_b.1 as usize]);
            a.m.host_read_raw(win_a.0, &mut ma).unwrap();
            b.m.host_read_raw(win_b.0, &mut mb).unwrap();
            let first = ma.iter().zip(&mb).position(|(x, y)| x != y);
            assert!(first.is_none(), "tenant {t} host memory differs at offset {:?}", first);
        }
    }

    // counters that count *events* (not cycles) must match exactly
    let (ca, cb) = (a.m.counters().unwrap(), b.m.counters().unwrap());
    for k in [
        reg::cnt::CMDS_ACCEPTED,
        reg::cnt::CMDS_RETIRED,
        reg::cnt::CMDS_ERROR,
        reg::cnt::DMA_BYTES_RD,
        reg::cnt::DMA_BYTES_WR,
        reg::cnt::ERR_EVENTS,
        reg::cnt::VIOLATIONS,
        reg::cnt::HOST_ERRORS,
        reg::cnt::TIMEOUTS,
    ] {
        assert_eq!(ca.global[k as usize], cb.global[k as usize], "global counter {}", reg::cnt::NAMES[k as usize]);
    }
    for t in 0..2 {
        let (x, y) = (&ca.tenants[t], &cb.tenants[t]);
        assert_eq!((x.dev_cmds, x.dev_bytes, x.dev_violations, x.dev_errors, x.state), (y.dev_cmds, y.dev_bytes, y.dev_violations, y.dev_errors, y.state), "tenant {t} counters");
    }

    // telemetry: same events, same order (timestamps excluded)
    let strip = |v: Vec<sf_cloud::mediator::TelemetryEvent>| -> Vec<(u8, u8, u8, u32)> { v.into_iter().map(|e| (e.event, e.tenant, e.queue, e.arg)).collect() };
    let (ea, eb) = (strip(a.m.drain_telemetry()), strip(b.m.drain_telemetry()));
    assert_eq!(ea.len(), eb.len(), "telemetry event count");
    assert_eq!(ea, eb, "telemetry event sequence");
    println!("differential: {n_ok} ok + {n_err} refused ({n_viol} violations) identical on cpu-ref and rtl-sim");
    let _ = SRAM_WORDS;
}
