//! Regression test: several RTL devices in one process, any destruction order, and use from different threads.
//! (Verilator 5 keeps a thread-local "current context" pointer; the harness must re-bind it on every call.
//! Before the fix, closing an instance after a later one had been created and freed aborted the process.)
mod common;
use common::*;
use sf_cloud::mediator::{alloc_flags as f, Mediator, MediatorOptions, Op, TenantConfig};
use sf_cloud::status::Status;
use std::time::Duration;

fn quick_slice(m: &Mediator) {
    let cred = m.provision_tenant(0, TenantConfig::default()).unwrap();
    let s = m.open_session(0, &cred).unwrap();
    let a = s.alloc(256, f::DEV_READ).unwrap();
    let b = s.alloc(256, f::DEV_WRITE).unwrap();
    s.write(a, 0, &data(9, 256)).unwrap();
    let t = s.submit(&Op::Copy { src: a, src_off: 0, dst: b, dst_off: 0, len: 256 }).unwrap();
    assert_eq!(s.wait(t, Duration::from_secs(20)).unwrap().status, Status::Ok);
    let mut out = vec![0u8; 256];
    s.read(b, 0, &mut out).unwrap();
    assert_eq!(out, data(9, 256));
}

#[test]
fn two_instances_either_drop_order() {
    with_timeout(60, "two RTL instances of the same library (thread-local Verilator context)", two_instances_body);
}

fn two_instances_body() {
    for first_dropped_is_oldest in [true, false] {
        // two instances of the SAME library (separate libraries have separate thread-local state and would hide the bug)
        let (Some(x), Some(y)) = (rtl_only("mt", "seed=1"), rtl_only("mt", "seed=2")) else { return };
        let mx = Mediator::open(x, MediatorOptions::default()).unwrap();
        let my = Mediator::open(y, MediatorOptions::default()).unwrap();
        quick_slice(&mx);
        quick_slice(&my);
        if first_dropped_is_oldest {
            drop(mx);
            drop(my);
        } else {
            drop(my);
            drop(mx);
        }
    }
}

#[test]
fn created_on_one_thread_used_and_dropped_on_another() {
    with_timeout(60, "cross-thread RTL instance", cross_thread_body);
}

fn cross_thread_body() {
    let Some(be) = rtl_only("mt", "") else { return };
    let m = Mediator::open(be, MediatorOptions::default()).unwrap();
    // another device of the same library is created and destroyed on this thread in the meantime
    if let Some(other) = rtl_only("mt", "") {
        drop(Mediator::open(other, MediatorOptions::default()).unwrap());
    }
    let h = std::thread::spawn(move || {
        quick_slice(&m);
        drop(m);
    });
    h.join().unwrap();
}
