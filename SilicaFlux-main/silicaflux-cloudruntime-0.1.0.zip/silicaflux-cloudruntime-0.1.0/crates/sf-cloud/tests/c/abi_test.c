/* Full vertical slice through the C ABI only.  Usage: abi_test <backend-spec> [expect-rtl]
 *   - checks the struct sizes the library reports against sizeof() of THIS compilation unit's header,
 *   - discovery -> open -> alloc -> write -> submit -> wait -> read -> verify -> counters -> telemetry -> free -> close,
 *   - negative paths: invalid args, stale handles, unsupported ops, foreign handles, bounded waits.
 * Exit status 0 = all checks passed. */
#include "sf_cloud.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fprintf(stderr, "FAIL %s:%d: ", __FILE__, __LINE__); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); fails++; } } while (0)
#define OK(call) do { sf_status _s = (call); if (_s != SF_OK) { fprintf(stderr, "FAIL %s:%d: %s -> %s (%s)\n", __FILE__, __LINE__, #call, sf_cloud_status_str(_s), sf_cloud_last_error()); fails++; } } while (0)
#define EXPECT(call, want) do { sf_status _s = (call); if (_s != (want)) { fprintf(stderr, "FAIL %s:%d: %s -> %s, wanted %s (%s)\n", __FILE__, __LINE__, #call, sf_cloud_status_str(_s), sf_cloud_status_str(want), sf_cloud_last_error()); fails++; } } while (0)

static uint32_t crc32(const uint8_t *d, size_t n) {
    uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) { c ^= d[i]; for (int k = 0; k < 8; k++) c = (c & 1) ? (c >> 1) ^ 0xEDB88320u : c >> 1; }
    return ~c;
}
static uint16_t csum1071(const uint8_t *d, size_t n) {
    uint32_t s = 0;
    for (size_t i = 0; i < n; i += 2) s += ((uint32_t)d[i] << 8) | (i + 1 < n ? d[i + 1] : 0);
    while (s >> 16) s = (s & 0xFFFF) + (s >> 16);
    return (uint16_t)~s;
}

int main(int argc, char **argv) {
    const char *spec = argc > 1 ? argv[1] : "cpu-ref";
    /* ---- ABI layout: header (this compile) vs library */
    uint32_t sz[16]; size_t nsz = 0;
    OK(sf_cloud_abi_sizes(sz, &nsz));
    CHECK(nsz == 8, "abi_sizes count %zu", nsz);
    CHECK(sz[0] == sizeof(sf_cloud_open_params), "open_params %u vs %zu", sz[0], sizeof(sf_cloud_open_params));
    CHECK(sz[1] == sizeof(sf_cloud_info_t), "info %u vs %zu", sz[1], sizeof(sf_cloud_info_t));
    CHECK(sz[2] == sizeof(sf_cloud_tenant_config), "tenant_config %u vs %zu", sz[2], sizeof(sf_cloud_tenant_config));
    CHECK(sz[3] == sizeof(sf_cloud_op_t), "op %u vs %zu", sz[3], sizeof(sf_cloud_op_t));
    CHECK(sz[4] == sizeof(sf_cloud_completion_t), "completion %u vs %zu", sz[4], sizeof(sf_cloud_completion_t));
    CHECK(sz[5] == sizeof(sf_cloud_counters_t), "counters %u vs %zu", sz[5], sizeof(sf_cloud_counters_t));
    CHECK(sz[6] == sizeof(sf_cloud_event_t), "event %u vs %zu", sz[6], sizeof(sf_cloud_event_t));
    CHECK(sz[7] == sizeof(sf_cloud_device_desc), "device_desc %u vs %zu", sz[7], sizeof(sf_cloud_device_desc));
    uint32_t maj = 0, min = 0; const char *rv = NULL;
    sf_cloud_version(&maj, &min, &rv);
    CHECK(maj == SF_CLOUD_ABI_MAJOR && min == SF_CLOUD_ABI_MINOR && rv && *rv, "version");
    CHECK(strcmp(sf_cloud_status_str(SF_ERR_TIMEOUT), "SF_ERR_TIMEOUT") == 0, "status_str");
    CHECK(strcmp(sf_cloud_status_str(SF_OK), "SF_OK") == 0, "status_str ok");

    /* ---- 1. discovery */
    sf_cloud_device_desc devs[16]; size_t nd = 0;
    OK(sf_cloud_discover(devs, 16, &nd));
    CHECK(nd >= 2, "expected cpu-ref and hw entries, got %zu", nd);
    int have_cpu = 0;
    for (size_t i = 0; i < nd && i < 16; i++) {
        CHECK(devs[i].reason[0] != 0, "device %s has no reason", devs[i].id);
        if (strcmp(devs[i].id, "cpu-ref:0") == 0 && devs[i].available) have_cpu = 1;
        if (strcmp(devs[i].kind, "hw") == 0) CHECK(!devs[i].available, "hardware must never be reported available");
    }
    CHECK(have_cpu, "cpu-ref:0 missing");

    /* ---- invalid opens */
    sf_cloud_device *dev = NULL;
    sf_cloud_open_params p; memset(&p, 0, sizeof p);
    p.struct_size = sizeof p; p.abi_major = SF_CLOUD_ABI_MAJOR; p.backend = spec; p.flags = SF_OPEN_STANDALONE;
    sf_cloud_open_params bad = p; bad.abi_major = 99;
    EXPECT(sf_cloud_open(&bad, &dev), SF_ERR_ABI_MISMATCH);
    bad = p; bad.backend = "hw";
    EXPECT(sf_cloud_open(&bad, &dev), SF_ERR_NO_DEVICE);
    CHECK(strstr(sf_cloud_last_error(), "not implemented") != NULL, "hw failure must say why: %s", sf_cloud_last_error());
    bad = p; bad.flags = 0;
    EXPECT(sf_cloud_open(&bad, &dev), SF_ERR_INVALID_ARG);
    EXPECT(sf_cloud_open(NULL, &dev), SF_ERR_INVALID_ARG);
    CHECK(dev == NULL, "out must stay NULL on failure");

    /* ---- 2. open + info */
    OK(sf_cloud_open(&p, &dev));
    if (!dev) return 2;
    sf_cloud_info_t info; memset(&info, 0, sizeof info); info.struct_size = sizeof info;
    OK(sf_cloud_info(dev, &info));
    printf("backend=%s  timing=%s\n  %s\n  tenants=%u queues=%u+%u  caps=0x%x  block_status=0x%04x  admin=%u health=%u thermal=%u\n",
           info.backend, info.timing_model, info.backend_description, info.tenants, info.net_queues, info.compute_queues, info.caps, info.block_status, info.admin, info.health, info.thermal);
    CHECK(info.measured_on_hardware == 0, "must not claim hardware");
    CHECK(info.dpu_abi_major == 1, "device ABI");
    CHECK(info.caps & SF_CAP_PKT_PROCESS, "pkt_process cap");
    CHECK(info.admin == 1 && info.tenant == 0, "standalone handle is admin of tenant 0");
    /* an old caller with a smaller struct must still work and not be overrun */
    {
        struct { uint32_t struct_size; uint32_t abi_major, abi_minor; uint8_t guard[64]; } small;
        memset(&small, 0xAB, sizeof small); small.struct_size = 12;
        OK(sf_cloud_info(dev, (sf_cloud_info_t *)&small));
        CHECK(small.abi_major == SF_CLOUD_ABI_MAJOR && small.guard[0] == 0xAB, "short struct: library wrote beyond struct_size");
    }

    /* ---- 3. protected buffers, 4. DMA + accelerator op, 5. completion, 6. read */
    enum { N = 1000 };
    uint8_t in[N], out[N], exp[N];
    for (int i = 0; i < N; i++) { in[i] = (uint8_t)(i * 7 + 3); exp[i] = in[i] ^ 0x5A; }
    sf_buf_t src = 0, dst = 0;
    OK(sf_cloud_alloc(dev, N, SF_MEM_DEV_READ, &src));
    OK(sf_cloud_alloc(dev, N, SF_MEM_DEV_WRITE, &dst));
    OK(sf_cloud_write(dev, src, 0, in, N));
    sf_cloud_op_t op; memset(&op, 0, sizeof op);
    op.struct_size = sizeof op; op.kind = SF_OP_PKT_PROCESS; op.src = src; op.dst = dst; op.len = N;
    op.proc_op = SF_PROC_XOR32; op.proc_param = 0x5A5A5A5Au;
    sf_ticket_t t = 0;
    OK(sf_cloud_submit(dev, &op, &t));
    /* the buffers are pinned while the operation runs */
    EXPECT(sf_cloud_free(dev, dst), SF_ERR_BUSY);
    sf_cloud_completion_t c; memset(&c, 0, sizeof c); c.struct_size = sizeof c;
    OK(sf_cloud_wait(dev, t, 20000, &c));
    CHECK(c.status == SF_OK && c.committed == 1 && c.bytes == N, "completion status=%d committed=%u bytes=%llu", c.status, c.committed, (unsigned long long)c.bytes);
    CHECK(c.has_crc && c.crc_in == crc32(in, N) && c.crc_out == crc32(exp, N) && c.csum == csum1071(exp, N), "crc/csum from the device differ from the C reference");
    OK(sf_cloud_read(dev, dst, 0, out, N));
    CHECK(memcmp(out, exp, N) == 0, "output bytes differ from the XOR reference");
    EXPECT(sf_cloud_poll(dev, t, &c), SF_ERR_STALE_HANDLE); /* completion is delivered exactly once */

    /* ---- protected memory copy (the ticket completes with crc_in == crc_out) */
    sf_buf_t cdst = 0; OK(sf_cloud_alloc(dev, N, SF_MEM_DEV_WRITE, &cdst));
    memset(&op, 0, sizeof op); op.struct_size = sizeof op; op.kind = SF_OP_COPY; op.src = src; op.dst = cdst; op.len = N;
    OK(sf_cloud_submit(dev, &op, &t));
    /* poll until done (bounded) */
    sf_status ps = SF_ERR_NOT_READY;
    for (int i = 0; i < 100000 && ps == SF_ERR_NOT_READY; i++) ps = sf_cloud_poll(dev, t, &c);
    CHECK(ps == SF_OK && c.status == SF_OK && c.crc_in == c.crc_out, "copy via poll: %s", sf_cloud_status_str(ps));
    OK(sf_cloud_read(dev, cdst, 0, out, N));
    CHECK(memcmp(out, in, N) == 0, "copy bytes");

    /* ---- negative paths: each must fail with the documented status */
    sf_buf_t tmpb = 0;
    EXPECT(sf_cloud_alloc(dev, 0, 0, &tmpb), SF_ERR_INVALID_ARG);
    EXPECT(sf_cloud_alloc(dev, 64, 0x80, &tmpb), SF_ERR_INVALID_ARG);
    EXPECT(sf_cloud_free(dev, 0xDEADBEEFull), SF_ERR_STALE_HANDLE);
    EXPECT(sf_cloud_free(dev, cdst + 1), SF_ERR_STALE_HANDLE);
    OK(sf_cloud_free(dev, cdst));
    EXPECT(sf_cloud_free(dev, cdst), SF_ERR_STALE_HANDLE); /* double free */
    EXPECT(sf_cloud_read(dev, dst, N - 4, out, 8), SF_ERR_RANGE);
    memset(&op, 0, sizeof op); op.struct_size = sizeof op; op.kind = SF_OP_COPY; op.src = src; op.dst = dst; op.len = 0;
    EXPECT(sf_cloud_submit(dev, &op, &t), SF_ERR_INVALID_ARG);
    op.len = N + 1;
    EXPECT(sf_cloud_submit(dev, &op, &t), SF_ERR_RANGE);
    op.len = N; op.kind = 77;
    EXPECT(sf_cloud_submit(dev, &op, &t), SF_ERR_INVALID_ARG);
    op.struct_size = 16;
    EXPECT(sf_cloud_submit(dev, &op, &t), SF_ERR_INVALID_ARG);
    EXPECT(sf_cloud_submit(NULL, &op, &t), SF_ERR_INVALID_ARG);
    /* workloads the backend cannot run fail clearly, they are not emulated */
    memset(&op, 0, sizeof op); op.struct_size = sizeof op; op.kind = SF_OP_GEMM_I8; op.src = src; op.aux = src; op.dst = dst; op.m = op.n = op.k = 4;
    sf_status gs = sf_cloud_submit(dev, &op, &t);
    unsigned extra_ops = 0; unsigned long long extra_bytes = 0;
    if (info.caps & SF_CAP_GEMM_I8) {
        /* a capable backend (cpu-ref) runs it: 4x4x4 INT8 -> 64 bytes of INT32 */
        CHECK(gs == SF_OK, "gemm on a capable backend: %s (%s)", sf_cloud_status_str(gs), sf_cloud_last_error());
        if (gs == SF_OK) { OK(sf_cloud_wait(dev, t, 5000, &c)); CHECK(c.status == SF_OK && c.bytes == 64, "gemm completion"); extra_ops = 1; extra_bytes = 64; }
    }
    else { EXPECT(gs, SF_ERR_UNSUPPORTED); CHECK(strstr(sf_cloud_last_error(), "gemm_i8") != NULL, "unsupported message names the op: %s", sf_cloud_last_error()); }
    /* privilege separation */
    uint8_t cred[16]; sf_cloud_device *sess = NULL;
    EXPECT(sf_cloud_provision_tenant(dev, 0, NULL, cred), SF_ERR_BUSY); /* tenant 0 is already provisioned */
    if (info.tenants > 1) {
        sf_cloud_device *med = NULL; sf_cloud_open_params mp = p; mp.flags = SF_OPEN_MEDIATOR;
        OK(sf_cloud_open(&mp, &med));
        sf_buf_t tmp;
        EXPECT(sf_cloud_alloc(med, 64, 0, &tmp), SF_ERR_PERMISSION);   /* mediator handle has no tenant session */
        OK(sf_cloud_provision_tenant(med, 0, NULL, cred));
        uint8_t wrong[16]; memset(wrong, 0, 16);
        EXPECT(sf_cloud_open_session(med, 0, wrong, &sess), SF_ERR_PERMISSION);
        OK(sf_cloud_open_session(med, 0, cred, &sess));
        EXPECT(sf_cloud_reset(sess, SF_RESET_DATAPLANE), SF_ERR_PERMISSION); /* tenant handle is not privileged */
        EXPECT(sf_cloud_provision_tenant(sess, 1, NULL, cred), SF_ERR_PERMISSION);
        sf_buf_t sb = 0;
        OK(sf_cloud_alloc(sess, 128, 0, &sb));
        OK(sf_cloud_free(sess, sb));
        OK(sf_cloud_close(sess));
        OK(sf_cloud_close(med));
    }

    /* ---- 7. counters + telemetry */
    sf_cloud_counters_t cn; memset(&cn, 0, sizeof cn); cn.struct_size = sizeof cn;
    OK(sf_cloud_counters(dev, &cn));
    printf("  counters: tenant submitted=%llu completed=%llu bytes_ok=%llu dev_cmds=%llu | device accepted=%llu retired=%llu dma_rd=%llu dma_wr=%llu cycles=%llu\n",
           (unsigned long long)cn.t_submitted, (unsigned long long)cn.t_completed, (unsigned long long)cn.t_bytes_ok, (unsigned long long)cn.t_dev_cmds,
           (unsigned long long)cn.d_cmds_accepted, (unsigned long long)cn.d_cmds_retired, (unsigned long long)cn.d_dma_bytes_rd, (unsigned long long)cn.d_dma_bytes_wr, (unsigned long long)cn.cycles);
    CHECK(cn.t_submitted == 2 + extra_ops && cn.t_completed == 2 + extra_ops && cn.t_bytes_ok == 2 * N + extra_bytes, "tenant counters: submitted=%llu completed=%llu bytes_ok=%llu", (unsigned long long)cn.t_submitted, (unsigned long long)cn.t_completed, (unsigned long long)cn.t_bytes_ok);
    CHECK(cn.device_valid == 1 && cn.d_cmds_retired >= 2 && cn.d_dma_bytes_rd >= 2 * N && cn.d_dma_bytes_wr >= 2 * N, "device counters");
    sf_cloud_event_t ev[64]; size_t nev = 0;
    OK(sf_cloud_telemetry(dev, ev, 64, &nev));
    CHECK(nev >= 2, "telemetry events: %zu", nev);
    int retire = 0; for (size_t i = 0; i < nev; i++) if (ev[i].event == 1) retire++;
    CHECK(retire >= 2, "retire events %d", retire);
    char *metrics = malloc(1 << 16); size_t need = 0;
    OK(sf_cloud_metrics(dev, metrics, 1 << 16, &need));
    CHECK(strstr(metrics, "silicaflux_device_info") && strstr(metrics, "measured_on_hardware=\"false\""), "metrics must declare the data source");
    CHECK(strstr(metrics, "silicaflux_thermal_state{state=\"unavailable\"} 1"), "thermal must be reported unavailable");
    char tiny[16]; EXPECT(sf_cloud_metrics(dev, tiny, sizeof tiny, &need), SF_ERR_RANGE);
    free(metrics);

    /* ---- 8. clean release */
    OK(sf_cloud_free(dev, src));
    OK(sf_cloud_free(dev, dst));
    OK(sf_cloud_close(dev));
    /* (a handle must not be used after sf_cloud_close(): not tested, it is undefined behaviour in C) */
    printf(fails ? "C ABI: FAIL (%d)\n" : "C ABI: PASS\n", fails);
    return fails ? 1 : 0;
}
