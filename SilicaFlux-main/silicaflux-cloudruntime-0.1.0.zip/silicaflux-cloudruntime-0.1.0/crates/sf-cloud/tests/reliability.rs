//! Reliability tests: every failure must be reported explicitly and boundedly -- never a hang, never silent loss.
mod common;
use common::*;
use sf_cloud::backend::{self, Backend, BackendInfo, BackendKind, BackendSpec, Caps, DevError, TimingModel};
use sf_cloud::mediator::{alloc_flags as f, BufState, Health, Mediator, MediatorOptions, Op, Session, TenantConfig, ThermalState};
use sf_cloud::proto::{self, err, reg};
use sf_cloud::status::Status;
use std::time::{Duration, Instant};

const W: Duration = Duration::from_secs(30);

fn specs() -> Vec<String> {
    let mut v = vec!["cpu-ref:mt".to_string()];
    if rtl_only("mt", "").is_some() {
        v.push("rtl-sim:mt,seed=21".to_string());
    }
    v
}

fn open(spec: &str, n_tenants: u32) -> (Mediator, Vec<Session>) {
    let be = backend::open_backend(&BackendSpec::parse(spec).unwrap()).unwrap();
    let m = Mediator::open(be, MediatorOptions { cycle_budget: 3_000_000, ..Default::default() }).unwrap();
    let mut v = vec![];
    for t in 0..n_tenants {
        let cred = m.provision_tenant(t, TenantConfig::default()).unwrap();
        v.push(m.open_session(t, &cred).unwrap());
    }
    (m, v)
}

fn copy_op(src: sf_cloud::mediator::BufHandle, dst: sf_cloud::mediator::BufHandle, len: u64) -> Op {
    Op::Copy { src, src_off: 0, dst, dst_off: 0, len }
}

// ------------------------------------------------------------------------------------------ unavailable
struct DeadBackend;
impl Backend for DeadBackend {
    fn info(&self) -> BackendInfo {
        BackendInfo {
            kind: BackendKind::Hardware,
            name: "dead".into(),
            description: "always failing".into(),
            timing: TimingModel::None,
            caps: Caps::default(),
            iova_base: 0,
            iova_size: 0,
            measured_on_hardware: false,
            details: vec![],
        }
    }
    fn mgmt_read(&mut self, _: u32) -> Result<u32, DevError> {
        Err(DevError::Timeout("no response from device".into()))
    }
    fn mgmt_write(&mut self, _: u32, _: u32) -> Result<(), DevError> {
        Err(DevError::Timeout("no response from device".into()))
    }
    fn submit(&mut self, _: u32, _: &[u32; 12]) -> Result<(), DevError> {
        Err(DevError::Unavailable("dead".into()))
    }
    fn pop_completion(&mut self, _: u32) -> Option<[u32; 8]> {
        None
    }
    fn advance(&mut self, c: u64) -> u64 {
        c
    }
    fn cycles(&self) -> u64 {
        0
    }
    fn pop_telemetry(&mut self) -> Option<[u32; 3]> {
        None
    }
    fn host_write(&mut self, _: u64, _: &[u8]) -> Result<(), DevError> {
        Err(DevError::Unavailable("dead".into()))
    }
    fn host_read(&mut self, _: u64, _: &mut [u8]) -> Result<(), DevError> {
        Err(DevError::Unavailable("dead".into()))
    }
    fn reset(&mut self) -> Result<(), DevError> {
        Err(DevError::Unavailable("dead".into()))
    }
}

#[test]
fn device_unavailable_is_reported_explicitly() {
    let t0 = Instant::now();
    // physical hardware: no transport exists -> explicit, never a pretend success
    let e = backend::open_backend(&BackendSpec::parse("hw").unwrap()).err().expect("hw must not open");
    assert!(e.to_string().contains("not implemented"), "{e}");
    // missing RTL library
    let e = backend::open_backend(&BackendSpec::parse("rtl-sim:mt,lib=/nonexistent/libsfrtl.so").unwrap()).err().expect("must fail");
    assert!(matches!(e, DevError::Unavailable(_)), "{e}");
    // a device that stops answering: the mediator must give up with an error, not wait forever
    let r = Mediator::open(Box::new(DeadBackend), MediatorOptions::default());
    let e = r.err().expect("dead device must fail to open");
    assert_eq!(e.status, Status::Timeout, "{e}");
    assert!(t0.elapsed() < Duration::from_secs(5), "failure must be prompt");
    // a device that disappears after open
    for spec in specs() {
        let (m, _) = open(&spec, 1);
        assert!(!matches!(m.health(), Health::Unavailable(_)));
    }
}

// ------------------------------------------------------------------------------------------ timeout / halt / orphan
#[test]
fn command_timeout_halts_quarantines_and_recovers_with_data_intact() {
    with_timeout(120, "command timeout scenario", || {
        for spec in specs() {
            let (m, ss) = open(&spec, 2);
            let (a, b) = (&ss[0], &ss[1]);
            m.set_job_timeout(3000).unwrap();
            let (src, dst) = (a.alloc(1024, f::DEV_READ).unwrap(), a.alloc(1024, f::DEV_WRITE).unwrap());
            a.write(src, 0, &data(40, 1024)).unwrap();
            // the host stops answering for a long while (stuck link / hung host memory)
            m.with_sim(|s| s.hold_host(40_000)).unwrap();
            let t = a.submit(&copy_op(src, dst, 1024)).unwrap();
            let c = a.wait(t, W).unwrap();
            assert_eq!(c.status, Status::Timeout, "{spec}: {c:?}");
            assert_eq!(c.dev_err, err::TIMEOUT);
            assert!(!c.committed, "{spec}: a timed-out copy must never claim commit");
            // the device may still write the destination: it is quarantined, not freed
            assert_eq!(a.buf_state(dst).unwrap(), BufState::Quarantined, "{spec}");
            assert_eq!(a.free(dst).unwrap_err().status, Status::Busy, "{spec}");
            assert_eq!(a.write(dst, 0, b"x").unwrap_err().status, Status::Busy, "{spec}");
            // shared-fate: the data plane is halted for EVERY tenant until a data-plane reset
            match m.health() {
                Health::Faulted(r) => assert!(r.iter().any(|x| x.contains("halted") || x.contains("timeout")), "{r:?}"),
                h => panic!("{spec}: expected Faulted, got {h:?}"),
            }
            let (bs, bd) = (b.alloc(256, f::DEV_READ).unwrap(), b.alloc(256, f::DEV_WRITE).unwrap());
            b.write(bs, 0, &data(41, 256)).unwrap();
            let tb = b.submit(&copy_op(bs, bd, 256)).unwrap();
            let t0 = Instant::now();
            assert_eq!(b.wait(tb, Duration::from_millis(150)).unwrap_err().status, Status::Timeout, "{spec}: neighbour must see a bounded timeout, not a hang");
            assert!(t0.elapsed() < Duration::from_secs(10));
            // recovery: data-plane reset WHILE the stalled host response is still outstanding (orphan logic)
            m.reset_dataplane().unwrap();
            m.clear_faults().unwrap();
            assert_eq!(a.buf_state(dst).unwrap(), BufState::HostOwned, "{spec}: quarantine released by the reset");
            // the neighbour's queued copy runs after the reset and must be byte-exact (a stale host response
            // must not corrupt the first transfer after the reset)
            let cb = b.wait(tb, W).unwrap();
            assert_eq!(cb.status, Status::Ok, "{spec}: {cb:?}");
            let mut out = vec![0u8; 256];
            b.read(bd, 0, &mut out).unwrap();
            assert_eq!(out, data(41, 256), "{spec}: first transfer after the reset");
            // and tenant A is back in business
            m.set_job_timeout(0x40000).unwrap();
            let t2 = a.submit(&copy_op(src, dst, 1024)).unwrap();
            assert_eq!(a.wait(t2, W).unwrap().status, Status::Ok, "{spec}");
            let mut out = vec![0u8; 1024];
            a.read(dst, 0, &mut out).unwrap();
            assert_eq!(out, data(40, 1024), "{spec}");
            assert_eq!(m.health(), Health::Healthy, "{spec}: {:?}", m.health());
            assert_eq!(m.counters().unwrap().stats.resets_soft, 1);
            m.shutdown().unwrap();
        }
    });
}

#[test]
fn waits_are_bounded_even_when_the_device_never_answers() {
    with_timeout(120, "bounded wait", || {
        for spec in specs() {
            let (m, ss) = open(&spec, 1);
            let a = &ss[0];
            m.set_job_timeout(0).unwrap(); // watchdog disabled: only the caller's budget can end the wait
            let (s, d) = (a.alloc(64, f::DEV_READ).unwrap(), a.alloc(64, f::DEV_WRITE).unwrap());
            m.with_sim(|x| x.hold_host(u64::MAX / 4)).unwrap();
            let t = a.submit(&copy_op(s, d, 64)).unwrap();
            let t0 = Instant::now();
            let e = a.wait(t, Duration::from_millis(200)).unwrap_err();
            assert_eq!(e.status, Status::Timeout, "{spec}: {e}");
            assert!(e.detail.contains("may still be running"), "{e}");
            assert!(t0.elapsed() < Duration::from_secs(10), "{spec}: wait overran its budget");
            assert_eq!(a.poll(t).unwrap_err().status, Status::NotReady);
            // still pinned -> cannot be freed
            assert_eq!(a.free(d).unwrap_err().status, Status::Busy);
            // a hard reset ends it: the ticket completes as Reset and the buffer is released
            m.reset_hard().unwrap();
            let c = a.wait(t, W).unwrap();
            assert_eq!(c.status, Status::Reset, "{spec}: {c:?}");
            a.free(d).unwrap();
            m.shutdown().unwrap();
        }
    });
}

// ------------------------------------------------------------------------------------------ saturation
#[test]
fn stalled_completion_consumer_backpressures_only_its_own_queue() {
    with_timeout(120, "queue saturation", || {
        for spec in specs() {
            let (m, ss) = open(&spec, 2);
            let (a, b) = (&ss[0], &ss[1]);
            let q0 = m.queue_of_tenant(0).unwrap();
            let (sa, sb) = (a.alloc(256, f::DEV_READ).unwrap(), b.alloc(256, f::DEV_READ).unwrap());
            a.write(sa, 0, &data(50, 256)).unwrap();
            b.write(sb, 0, &data(51, 256)).unwrap();
            let das: Vec<_> = (0..14).map(|_| a.alloc(256, f::DEV_WRITE).unwrap()).collect();
            m.with_sim(|s| s.set_completion_consumer(q0, false)).unwrap();
            let tas: Vec<_> = das.iter().map(|d| a.submit(&copy_op(sa, *d, 256)).unwrap()).collect();
            // tenant B (other queue) is completely unaffected while A's completions are not being read
            for _ in 0..5 {
                let d = b.alloc(256, f::DEV_WRITE).unwrap();
                let t = b.submit(&copy_op(sb, d, 256)).unwrap();
                assert_eq!(b.wait(t, W).unwrap().status, Status::Ok, "{spec}: neighbour affected by a stalled queue");
            }
            // A's last operation cannot complete: bounded timeout, not a hang
            let t0 = Instant::now();
            assert_eq!(a.wait(*tas.last().unwrap(), Duration::from_millis(150)).unwrap_err().status, Status::Timeout, "{spec}");
            assert!(t0.elapsed() < Duration::from_secs(10));
            // consumer resumes: nothing was lost
            m.with_sim(|s| s.set_completion_consumer(q0, true)).unwrap();
            for t in tas {
                assert_eq!(a.wait(t, W).unwrap().status, Status::Ok, "{spec}");
            }
            for d in &das {
                let mut o = vec![0u8; 256];
                a.read(*d, 0, &mut o).unwrap();
                assert_eq!(o, data(50, 256), "{spec}");
            }
            let st = m.counters().unwrap().stats;
            assert_eq!((st.failed, st.anomalies_unknown_tag), (0, 0), "{spec}");
            m.shutdown().unwrap();
        }
    });
}

// ------------------------------------------------------------------------------------------ memory failure
#[test]
fn host_memory_failure_and_partial_transfer_semantics() {
    with_timeout(120, "memory failure", || {
        let mut results: Vec<(String, Vec<u8>)> = vec![];
        for spec in specs() {
            let (m, ss) = open(&spec, 1);
            let a = &ss[0];
            let n = 4096usize;
            let (src, dst) = (a.alloc(n as u64, f::DEV_READ).unwrap(), a.alloc(n as u64, f::DEV_WRITE).unwrap());
            a.write(src, 0, &data(60, n)).unwrap();
            let (_, out_win) = m.tenant_windows(0).map(|(i, o)| (i, o)).unwrap();
            let dst_iova = out_win.0; // first buffer in the output window
                                      // (1) the destination fails 1024 bytes into the transfer
            m.with_sim(|s| s.inject_host_error(dst_iova + 1024, dst_iova + 8192)).unwrap();
            let t = a.submit(&copy_op(src, dst, n as u64)).unwrap();
            let c = a.wait(t, W).unwrap();
            assert_eq!(c.status, Status::DeviceFault, "{spec}: {c:?}");
            assert_eq!(c.dev_err, err::HOST_MEM);
            assert!(!c.committed && c.bytes == 0, "{spec}: a failed transfer must not claim bytes or commit");
            let mut got = vec![0u8; n];
            a.read(dst, 0, &mut got).unwrap();
            assert_eq!(&got[..1024], &data(60, n)[..1024], "{spec}: the beats acknowledged before the failure stay written (partial transfer)");
            assert!(got[1024..].iter().all(|&b| b == 0), "{spec}: nothing may be written beyond the failing beat");
            results.push((spec.clone(), got));
            assert!(matches!(m.health(), Health::Degraded(_)), "{spec}: {:?}", m.health());
            // (2) the SOURCE fails.  For a single-chunk transfer (<= chunk_bytes = 2048) a failed read produces no
            // output at all.  (A multi-chunk transfer may leave the other chunks' bytes in the destination: its
            // completion says "failed, not committed", and the destination contents are then unspecified.)
            m.with_sim(|s| s.clear_host_errors()).unwrap();
            let src_iova = m.tenant_windows(0).unwrap().0 .0;
            m.with_sim(|s| s.inject_host_error(src_iova + 512, src_iova + 600)).unwrap();
            let d2 = a.alloc(2048, f::DEV_WRITE).unwrap();
            let t = a.submit(&copy_op(src, d2, 2048)).unwrap();
            let c = a.wait(t, W).unwrap();
            assert_eq!((c.status, c.dev_err, c.chunks), (Status::DeviceFault, err::HOST_MEM, 1), "{spec}");
            assert!(!c.committed && c.bytes == 0);
            let mut z = vec![0xAAu8; 2048];
            a.read(d2, 0, &mut z).unwrap();
            assert!(z.iter().all(|&b| b == 0), "{spec}: a failed single-chunk read must not produce output");
            // multi-chunk: still an explicit failure, with the destination declared unspecified
            let d3 = a.alloc(n as u64, f::DEV_WRITE).unwrap();
            let t = a.submit(&copy_op(src, d3, n as u64)).unwrap();
            let c = a.wait(t, W).unwrap();
            assert_eq!((c.status, c.committed, c.chunks), (Status::DeviceFault, false, 2), "{spec}: {c:?}");
            // (3) recovery: clear the fault, retry
            m.with_sim(|s| s.clear_host_errors()).unwrap();
            let t = a.submit(&copy_op(src, dst, n as u64)).unwrap();
            assert_eq!(a.wait(t, W).unwrap().status, Status::Ok, "{spec}");
            m.clear_faults().unwrap();
            assert_eq!(m.health(), Health::Healthy, "{spec}");
            let dc = m.counters().unwrap();
            assert!(dc.global[reg::cnt::HOST_ERRORS as usize] >= 2, "{spec}");
            m.shutdown().unwrap();
        }
        if results.len() == 2 {
            assert_eq!(results[0].1, results[1].1, "partial-transfer image differs between cpu-ref and rtl-sim");
        }
    });
}

// ------------------------------------------------------------------------------------------ reset / crash
#[test]
fn hard_reset_interrupts_inflight_work_and_the_device_recovers() {
    with_timeout(120, "hard reset", || {
        for spec in specs() {
            let (m, ss) = open(&spec, 2);
            let a = &ss[0];
            let (src, d_host) = (a.alloc(2048, f::DEV_READ).unwrap(), a.alloc(2048, f::DEV_WRITE).unwrap());
            let dev = a.alloc(2048, f::DEVICE).unwrap();
            a.write(src, 0, &data(70, 2048)).unwrap();
            let dsts: Vec<_> = (0..6).map(|_| a.alloc(2048, f::DEV_WRITE).unwrap()).collect();
            let tix: Vec<_> = dsts.iter().map(|d| a.submit(&copy_op(src, *d, 2048)).unwrap()).collect();
            m.pump(300); // some work is mid-flight
            m.reset_hard().unwrap();
            let mut reset = 0;
            for t in tix {
                let c = a.wait(t, W).unwrap();
                assert!(matches!(c.status, Status::Reset | Status::Ok), "{spec}: {c:?}");
                if c.status == Status::Reset {
                    assert!(!c.committed && c.bytes == 0);
                    reset += 1;
                }
            }
            assert!(reset >= 1, "{spec}: at least one operation must have been interrupted");
            // buffers are usable again and every handle is still valid
            for d in &dsts {
                a.free(*d).unwrap();
            }
            // the tenants were re-provisioned from the mediator's records: full workflow works again
            let t = a.submit(&Op::DmaH2d { src, src_off: 0, dst: dev, dst_off: 0, len: 2048 }).unwrap();
            assert_eq!(a.wait(t, W).unwrap().status, Status::Ok, "{spec}");
            let t = a.submit(&Op::DmaD2h { src: dev, src_off: 0, dst: d_host, dst_off: 0, len: 2048 }).unwrap();
            assert_eq!(a.wait(t, W).unwrap().status, Status::Ok, "{spec}");
            let mut out = vec![0u8; 2048];
            a.read(d_host, 0, &mut out).unwrap();
            assert_eq!(out, data(70, 2048), "{spec}");
            assert_eq!(m.counters().unwrap().stats.resets_hard, 1);
            assert_eq!(m.health(), Health::Healthy, "{spec}");
            m.shutdown().unwrap();
        }
    });
}

#[test]
fn driver_crash_leaves_no_residue_and_no_stale_handles() {
    with_timeout(120, "driver crash", || {
        for spec in specs() {
            let (m, ss) = open(&spec, 2);
            let a = &ss[0];
            let secret = vec![0xC3u8; 2048];
            let (src, dst) = (a.alloc(2048, f::DEV_READ).unwrap(), a.alloc(2048, f::DEV_WRITE).unwrap());
            let devbuf = a.alloc(2048, f::DEVICE).unwrap();
            a.write(src, 0, &secret).unwrap();
            let t = a.submit(&Op::DmaH2d { src, src_off: 0, dst: devbuf, dst_off: 0, len: 2048 }).unwrap();
            a.wait(t, W).unwrap();
            let t = a.submit(&copy_op(src, dst, 2048)).unwrap();
            a.wait(t, W).unwrap();
            let part = m.tenant_partition(0).unwrap();
            let (win_in, win_out) = m.tenant_windows(0).unwrap();
            // work is in flight when the host runtime dies
            let d2 = a.alloc(2048, f::DEV_WRITE).unwrap();
            let _inflight = a.submit(&copy_op(src, d2, 2048)).unwrap();
            let old_handle = src;
            drop(ss);
            let be = m.crash().expect("no other users");
            // recovery: attach, hard-reset, trust nothing
            let m2 = Mediator::open(be, MediatorOptions { cycle_budget: 3_000_000, reset_on_open: true }).unwrap();
            let cred = m2.provision_tenant(0, TenantConfig::default()).unwrap();
            let a2 = m2.open_session(0, &cred).unwrap();
            // (a) a handle from the dead runtime can never alias an object of the new one, even though the slot is reused
            let fresh = a2.alloc(2048, f::DEV_READ).unwrap();
            assert_ne!(old_handle, fresh);
            assert_eq!(a2.read(old_handle, 0, &mut [0u8; 8]).unwrap_err().status, Status::StaleHandle, "{spec}");
            // (b) the new tenant's host windows hold no residue
            for (b, n) in [win_in, win_out] {
                let mut mem = vec![0xFFu8; n as usize];
                m2.host_read_raw(b, &mut mem).unwrap();
                assert!(mem.iter().all(|&x| x == 0), "{spec}: host window residue after crash recovery");
            }
            // (c) the SRAM partition (device buffers + staging) was scrubbed before re-use
            let (pb, ps) = part;
            let mut sram = vec![0xFFu8; ps as usize];
            m2.with_sim(|s| s.sram_peek(pb, &mut sram)).unwrap().unwrap();
            let nonzero = sram.iter().filter(|&&b| b != 0).count();
            assert_eq!(nonzero, 0, "{spec}: {nonzero} non-zero SRAM bytes left in the partition");
            // (d) the interrupted command did not survive and delivers nothing to the new instance
            m2.pump(5_000);
            assert_eq!(m2.counters().unwrap().stats.anomalies_unknown_tag, 0, "{spec}");
            let (s2, d3) = (fresh, a2.alloc(2048, f::DEV_WRITE).unwrap());
            a2.write(s2, 0, &data(80, 2048)).unwrap();
            let t = a2.submit(&copy_op(s2, d3, 2048)).unwrap();
            assert_eq!(a2.wait(t, W).unwrap().status, Status::Ok, "{spec}");
            m2.shutdown().unwrap();
        }
    });
}

#[test]
fn deprovision_under_load_waits_and_scrubs() {
    with_timeout(120, "deprovision", || {
        for spec in specs() {
            let (m, ss) = open(&spec, 2);
            let (a, b) = (&ss[0], &ss[1]);
            let (sa, sb) = (a.alloc(1024, f::DEV_READ).unwrap(), b.alloc(1024, f::DEV_READ).unwrap());
            a.write(sa, 0, &vec![0xEEu8; 1024]).unwrap();
            b.write(sb, 0, &data(90, 1024)).unwrap();
            let das: Vec<_> = (0..5).map(|_| a.alloc(1024, f::DEV_WRITE).unwrap()).collect();
            for d in &das {
                a.submit(&copy_op(sa, *d, 1024)).unwrap();
            }
            let (wi, wo) = m.tenant_windows(0).unwrap();
            let part = m.tenant_partition(0).unwrap();
            m.deprovision_tenant(0).unwrap();
            assert_eq!(a.alloc(8, 0).unwrap_err().status, Status::NoDevice, "{spec}: deprovisioned tenant");
            for (base, n) in [wi, wo] {
                let mut mem = vec![0xFFu8; n as usize];
                m.host_read_raw(base, &mut mem).unwrap();
                assert!(mem.iter().all(|&x| x == 0), "{spec}: window not scrubbed");
            }
            let mut sram = vec![0xFFu8; part.1 as usize];
            m.with_sim(|s| s.sram_peek(part.0, &mut sram)).unwrap().unwrap();
            assert!(sram.iter().all(|&b| b == 0), "{spec}: SRAM partition not scrubbed");
            // the neighbour kept working throughout
            let d = b.alloc(1024, f::DEV_WRITE).unwrap();
            let t = b.submit(&copy_op(sb, d, 1024)).unwrap();
            assert_eq!(b.wait(t, W).unwrap().status, Status::Ok, "{spec}");
            // the freed resources can be handed to a new tenant in the same slot
            let cred = m.provision_tenant(0, TenantConfig::default()).unwrap();
            assert!(m.open_session(0, &cred).is_ok());
            m.shutdown().unwrap();
        }
    });
}

// ------------------------------------------------------------------------------------------ thermal
#[test]
fn thermal_state_is_unavailable_until_fed_and_drives_health_and_admission() {
    for spec in specs() {
        let (m, ss) = open(&spec, 1);
        let a = &ss[0];
        assert_eq!(m.snapshot().unwrap().thermal, ThermalState::Unavailable, "{spec}: no sensor exists; must say so");
        let (s, d) = (a.alloc(64, f::DEV_READ).unwrap(), a.alloc(64, f::DEV_WRITE).unwrap());
        m.set_thermal(ThermalState::Warning(88.0));
        assert!(matches!(m.health(), Health::Degraded(_)));
        let t = a.submit(&copy_op(s, d, 64)).unwrap();
        assert_eq!(a.wait(t, W).unwrap().status, Status::Ok, "a warning must not stop work");
        m.set_thermal(ThermalState::Critical(101.5));
        assert!(matches!(m.health(), Health::Faulted(_)));
        let e = a.submit(&copy_op(s, d, 64)).unwrap_err();
        assert_eq!(e.status, Status::DeviceFault, "{e}");
        assert!(e.detail.contains("thermal"));
        m.set_thermal(ThermalState::Normal(55.0));
        assert_eq!(m.health(), Health::Healthy);
        let t = a.submit(&copy_op(s, d, 64)).unwrap();
        assert_eq!(a.wait(t, W).unwrap().status, Status::Ok);
        m.shutdown().unwrap();
    }
}

#[test]
fn raw_register_access_stays_inside_the_register_map() {
    for spec in specs() {
        let (m, _) = open(&spec, 1);
        // unmapped / read-only / misaligned management accesses answer with an error, they are not ignored
        assert!(m.mgmt_read(0x4000_8FFC).is_err(), "{spec}: unmapped register read");
        assert!(m.mgmt_write(reg::G_ID, 0xFFFF_FFFF).is_err(), "{spec}: write to a read-only register");
        assert!(m.mgmt_write(reg::G_SRAM_BYTES, 0).is_err(), "{spec}: write to a read-only register");
        assert!(m.mgmt_read(0x1000_0000).is_err(), "{spec}: address outside the DPU windows");
        assert!(m.mgmt_read(reg::tenant(15, 0)).is_err(), "{spec}: tenant 15 does not exist on this device");
        assert_eq!(m.mgmt_read(reg::G_ID).unwrap(), proto::DPU_ID_MAGIC, "{spec}: device still sane");
    }
}
