//! Builds `tests/c/abi_test.c` with gcc against the shared library and runs the complete vertical slice through
//! the C ABI only, on every available backend.
mod common;
use std::path::PathBuf;
use std::process::Command;

fn root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..")
}

fn build_lib() -> PathBuf {
    // make sure the cdylib exists in the same profile as this test
    let release = !cfg!(debug_assertions) && std::env::current_exe().unwrap().to_string_lossy().contains("/release/");
    let mut c = Command::new(env!("CARGO"));
    c.args(["build", "-p", "sf-cloud", "--lib", "--quiet"]).current_dir(root());
    if release {
        c.arg("--release");
    }
    assert!(c.status().expect("cargo build").success(), "building the cdylib failed");
    root().join("target").join(if release { "release" } else { "debug" })
}

#[test]
fn c_abi_vertical_slice_on_every_backend() {
    let libdir = build_lib();
    assert!(libdir.join("libsf_cloud.so").exists(), "libsf_cloud.so missing in {}", libdir.display());
    let out = std::env::temp_dir().join(format!("sf_abi_test_{}", std::process::id()));
    let status = Command::new("gcc")
        .args(["-std=c11", "-Wall", "-Wextra", "-Werror", "-O1", "-I"])
        .arg(root().join("include"))
        .arg(root().join("crates/sf-cloud/tests/c/abi_test.c"))
        .arg("-L")
        .arg(&libdir)
        .arg("-lsf_cloud")
        .arg(format!("-Wl,-rpath,{}", libdir.display()))
        .arg("-o")
        .arg(&out)
        .status()
        .expect("gcc");
    assert!(status.success(), "the C test (and therefore include/sf_cloud.h) must compile cleanly with -Wall -Wextra -Werror");
    let mut specs = vec!["cpu-ref:mt".to_string()];
    if common::rtl_only("mt", "").is_some() {
        specs.push("rtl-sim:mt,seed=9".to_string());
    }
    for spec in specs {
        let o = Command::new(&out).arg(&spec).current_dir(root()).output().expect("run abi_test");
        let text = format!("{}{}", String::from_utf8_lossy(&o.stdout), String::from_utf8_lossy(&o.stderr));
        println!("--- {spec}\n{text}");
        assert!(o.status.success(), "C ABI test failed on {spec}:\n{text}");
        assert!(text.contains("C ABI: PASS"), "{spec}: {text}");
    }
    let _ = std::fs::remove_file(out);
}

#[test]
fn header_status_values_match_the_library() {
    // every SF_* value in the header equals the Rust Status discriminant (and the name table is complete)
    let h = std::fs::read_to_string(root().join("include/sf_cloud.h")).unwrap();
    let mut seen = 0;
    for line in h.lines() {
        let l = line.trim();
        if !(l.starts_with("SF_OK") || l.starts_with("SF_ERR_")) || !l.contains('=') {
            continue;
        }
        let name = l.split_whitespace().next().unwrap().to_string();
        let val: i32 = l.split('=').nth(1).and_then(|v| v.split([',', '/']).next()).unwrap().trim().parse().unwrap();
        let st = sf_cloud::status::Status::from_i32(val).unwrap_or_else(|| panic!("header value {val} for {name} unknown to the library"));
        assert_eq!(st.name(), name, "name of status {val}");
        seen += 1;
    }
    assert_eq!(seen, 22, "header must define all 22 status codes");
}
