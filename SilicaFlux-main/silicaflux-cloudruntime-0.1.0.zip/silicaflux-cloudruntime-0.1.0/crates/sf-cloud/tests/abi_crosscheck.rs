//! The Rust ABI constants (`proto.rs`) must equal the values in the vendored RTL packages.  This test parses
//! `silicaflux_cloud_pkg.sv` and `silicaflux_cloud_memmap_pkg.sv` and fails on any disagreement, so the runtime
//! cannot silently drift from the RTL it drives.
use sf_cloud::proto::*;
use std::collections::HashMap;
use std::path::PathBuf;

fn rtl_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../rtl/vendor/clouddpu-p61/rtl/pkg")
}

/// name -> value for every `localparam ... NAME = <literal>;`
fn parse(file: &str) -> HashMap<String, u64> {
    let text = std::fs::read_to_string(rtl_dir().join(file)).unwrap_or_else(|e| panic!("{file}: {e}"));
    let mut m = HashMap::new();
    for line in text.lines() {
        let l = line.split("//").next().unwrap().trim();
        if !l.starts_with("localparam") {
            continue;
        }
        let Some((lhs, rhs)) = l.split_once('=') else { continue };
        let name = lhs.split_whitespace().last().unwrap().to_string();
        let lit = rhs.trim().trim_end_matches(';').trim();
        if let Some(v) = literal(lit) {
            m.insert(name, v);
        }
    }
    m
}

fn literal(s: &str) -> Option<u64> {
    let s = s.replace('_', "");
    if let Some((_, rest)) = s.split_once('\'') {
        let (base, digits) = rest.split_at(1);
        let radix = match base {
            "h" | "H" => 16,
            "d" | "D" => 10,
            "b" | "B" => 2,
            _ => return None,
        };
        return u64::from_str_radix(digits, radix).ok();
    }
    s.parse().ok()
}

#[test]
fn ids_and_versions() {
    let p = parse("silicaflux_cloud_pkg.sv");
    assert_eq!(p["DPU_ID_MAGIC"] as u32, DPU_ID_MAGIC);
    assert_eq!(p["DPU_ABI_MAJOR"] as u32, DPU_ABI_MAJOR);
    assert_eq!(p["DPU_ABI_MINOR"] as u32, DPU_ABI_MINOR);
    assert_eq!(p["CMD_NW"] as usize, CMD_WORDS);
    assert_eq!(p["CPL_NW"] as usize, CPL_WORDS);
    assert_eq!(p["MGMT_QUEUE_ID"] as u32, MGMT_QUEUE_ID);
    assert_eq!(p["SRAM_PAGE_BYTES"] as u32, SRAM_PAGE_BYTES);
}

#[test]
fn opcodes_errors_states() {
    let p = parse("silicaflux_cloud_pkg.sv");
    let eq = |n: &str, v: u64| assert_eq!(p[n], v, "{n}");
    eq("OP_NOP", op::NOP as u64);
    eq("OP_PKT_PROCESS", op::PKT_PROCESS as u64);
    eq("OP_DMA_H2D", op::DMA_H2D as u64);
    eq("OP_DMA_D2H", op::DMA_D2H as u64);
    eq("OP_INFER", op::INFER as u64);
    eq("OP_CRYPTO", op::CRYPTO as u64);
    eq("OP_STORAGE", op::STORAGE as u64);
    eq("PROC_PASS", proc_op::PASS as u64);
    eq("PROC_XOR32", proc_op::XOR32 as u64);
    eq("PROC_BSWAP32", proc_op::BSWAP32 as u64);
    eq("ST_OK", status::OK as u64);
    eq("ST_ERROR", status::ERROR as u64);
    eq("ST_ABORTED", status::ABORTED as u64);
    for (n, v) in [
        ("ERR_NONE", err::NONE),
        ("ERR_BAD_OPCODE", err::BAD_OPCODE),
        ("ERR_BAD_DESC", err::BAD_DESC),
        ("ERR_BAD_LENGTH", err::BAD_LENGTH),
        ("ERR_ALIGN", err::ALIGN),
        ("ERR_TENANT_STATE", err::TENANT_STATE),
        ("ERR_QUARANTINED", err::QUARANTINED),
        ("ERR_BLOCKED", err::BLOCKED),
        ("ERR_BAD_TENANT", err::BAD_TENANT),
        ("ERR_PROC_OP", err::PROC_OP),
        ("ERR_TENANT_MISMATCH", err::TENANT_MISMATCH),
        ("ERR_PERM_READ", err::PERM_READ),
        ("ERR_PERM_WRITE", err::PERM_WRITE),
        ("ERR_SRAM_RANGE", err::SRAM_RANGE),
        ("ERR_PERM_BEAT", err::PERM_BEAT),
        ("ERR_HOST_MEM", err::HOST_MEM),
        ("ERR_SRAM_RESP", err::SRAM_RESP),
        ("ERR_TIMEOUT", err::TIMEOUT),
        ("ERR_RESET_ABORT", err::RESET_ABORT),
        ("ERR_INTERNAL", err::INTERNAL),
    ] {
        eq(n, v as u64);
    }
    for (n, v) in [
        ("TS_DISABLED", tstate::DISABLED),
        ("TS_ACTIVE", tstate::ACTIVE),
        ("TS_DRAINING", tstate::DRAINING),
        ("TS_SCRUBBING", tstate::SCRUBBING),
        ("TS_QUARANTINED", tstate::QUARANTINED),
    ] {
        eq(n, v as u64);
    }
    for (n, v) in [("TCMD_COMMIT", tcmd::COMMIT), ("TCMD_ENABLE", tcmd::ENABLE), ("TCMD_DISABLE", tcmd::DISABLE), ("TCMD_RECOVER", tcmd::RECOVER), ("TCMD_RELEASE", tcmd::RELEASE)]
    {
        eq(n, v as u64);
    }
    for (n, v) in [
        ("CFG_NONE", cfg::NONE),
        ("CFG_OK", cfg::OK),
        ("CFG_BUSY", cfg::BUSY),
        ("CFG_BAD_PART", cfg::BAD_PART),
        ("CFG_BAD_WINDOW", cfg::BAD_WINDOW),
        ("CFG_OVERLAP_SRAM", cfg::OVERLAP_SRAM),
        ("CFG_OVERLAP_HOST", cfg::OVERLAP_HOST),
        ("CFG_NO_TENANT", cfg::NO_TENANT),
        ("CFG_SCRUB_FAIL", cfg::SCRUB_FAIL),
    ] {
        eq(n, v as u64);
    }
    for (n, v) in [("BLK_ABSENT", blk::ABSENT), ("BLK_BLOCKED", blk::BLOCKED), ("BLK_TEST_ADAPTER", blk::TEST_ADAPTER), ("BLK_REAL", blk::REAL)] {
        eq(n, v as u64);
    }
    for (n, v) in [
        ("TLM_CMD_RETIRE", tlm::CMD_RETIRE),
        ("TLM_VIOLATION", tlm::VIOLATION),
        ("TLM_TENANT_STATE", tlm::TENANT_STATE),
        ("TLM_FAULT", tlm::FAULT),
        ("TLM_DP_RESET", tlm::DP_RESET),
    ] {
        eq(n, v as u64);
    }
    for (n, v) in [
        ("FLT_PERM_VIOL", flt::PERM_VIOL),
        ("FLT_HOST_ERR", flt::HOST_ERR),
        ("FLT_DESC_ERR", flt::DESC_ERR),
        ("FLT_TIMEOUT", flt::TIMEOUT),
        ("FLT_SRAM_ERR", flt::SRAM_ERR),
        ("FLT_INTERNAL", flt::INTERNAL),
        ("FLT_RESET_DONE", flt::RESET_DONE),
        ("FLT_TLM_DROP", flt::TLM_DROP),
    ] {
        eq(n, v as u64);
    }
    eq("CPL_FLAG_COMMITTED", 0); // bit index
    assert_eq!(CPL_FLAG_COMMITTED, 1 << p["CPL_FLAG_COMMITTED"]);
}

#[test]
fn descriptor_and_completion_layouts() {
    let p = parse("silicaflux_cloud_pkg.sv");
    // Each field's bit position in the flat 384/256-bit words must match the word we encode it into.
    let mut c = Cmd {
        opcode: 0x5A,
        flags: 1,
        tenant: 0xB,
        tag: 0x1111_2222,
        src: 0x3333_4444_5555_6666,
        dst: 0x7777_8888_9999_AAAA,
        len: 0xBBBB_CCCC,
        sram_off: 0xDDDD_EEEE,
        proc_op: 0x7E,
        param: 0xF0F0_0F0F,
        ..Default::default()
    };
    c.rsvd_w10_11 = 0;
    let w = c.encode();
    let bit = |lsb: u64, width: u32| -> u64 {
        let (word, off) = ((lsb / 32) as usize, (lsb % 32) as u32);
        let v = (w[word] as u64) | w.get(word + 1).map_or(0, |x| (*x as u64) << 32);
        (v >> off) & ((1u64 << width) - 1)
    };
    assert_eq!(bit(p["CMD_OPCODE_LSB"], 8), 0x5A);
    assert_eq!(bit(p["CMD_FLAGS_LSB"], 8), 1);
    assert_eq!(bit(p["CMD_TENANT_LSB"], 4), 0xB);
    assert_eq!(bit(p["CMD_TAG_LSB"], 32), 0x1111_2222);
    assert_eq!(bit(p["CMD_SRC_LSB"], 32), 0x5555_6666);
    assert_eq!(bit(p["CMD_SRC_LSB"] + 32, 32), 0x3333_4444);
    assert_eq!(bit(p["CMD_DST_LSB"], 32), 0x9999_AAAA);
    assert_eq!(bit(p["CMD_LEN_LSB"], 32), 0xBBBB_CCCC);
    assert_eq!(bit(p["CMD_SRAM_OFF_LSB"], 32), 0xDDDD_EEEE);
    assert_eq!(bit(p["CMD_PROC_OP_LSB"], 8), 0x7E);
    assert_eq!(bit(p["CMD_PARAM_LSB"], 32), 0xF0F0_0F0F);

    let cp = Cpl {
        opcode: 0x11,
        status: 2,
        err: 0x22,
        tenant: 0x3,
        queue: 0x4,
        tag: 0xA1A2_A3A4,
        txn: 0xB1B2,
        flags: 1,
        bytes: 0xC1C2_C3C4,
        crc_in: 0xD1D2_D3D4,
        crc_out: 0xE1E2_E3E4,
        csum: 0xF1F2,
        ts: 0x1234_5678,
    };
    let w = cp.encode();
    let bit = |lsb: u64, width: u32| -> u64 {
        let (word, off) = ((lsb / 32) as usize, (lsb % 32) as u32);
        (w[word] as u64 >> off) & ((1u64 << width) - 1)
    };
    assert_eq!(bit(p["CPL_OPCODE_LSB"], 8), 0x11);
    assert_eq!(bit(p["CPL_STATUS_LSB"], 8), 2);
    assert_eq!(bit(p["CPL_ERR_LSB"], 8), 0x22);
    assert_eq!(bit(p["CPL_TENANT_LSB"], 4), 0x3);
    assert_eq!(bit(p["CPL_QUEUE_LSB"], 4), 0x4);
    assert_eq!(bit(p["CPL_TAG_LSB"], 32), 0xA1A2_A3A4);
    assert_eq!(bit(p["CPL_TXN_LSB"], 16), 0xB1B2);
    assert_eq!(bit(p["CPL_FLAGS_LSB"], 16), 1);
    assert_eq!(bit(p["CPL_BYTES_LSB"], 32), 0xC1C2_C3C4);
    assert_eq!(bit(p["CPL_CRC_IN_LSB"], 32), 0xD1D2_D3D4);
    assert_eq!(bit(p["CPL_CRC_OUT_LSB"], 32), 0xE1E2_E3E4);
    assert_eq!(bit(p["CPL_CSUM_LSB"], 16), 0xF1F2);
    assert_eq!(bit(p["CPL_TS_LSB"], 32), 0x1234_5678);
}

#[test]
fn register_map() {
    let m = parse("silicaflux_cloud_memmap_pkg.sv");
    let g = m["DPU_GLOBAL_PAGE_BASE"] as u32;
    assert_eq!(g, reg::GLOBAL);
    assert_eq!(m["DPU_TENANT_PAGE_BASE"] as u32, reg::TENANT);
    for (n, v) in [
        ("DPU_G_ID", reg::G_ID),
        ("DPU_G_VERSION", reg::G_VERSION),
        ("DPU_G_CONFIG0", reg::G_CONFIG0),
        ("DPU_G_CONFIG1", reg::G_CONFIG1),
        ("DPU_G_SRAM_BYTES", reg::G_SRAM_BYTES),
        ("DPU_G_MAX_XFER", reg::G_MAX_XFER),
        ("DPU_G_BLOCK_STATUS", reg::G_BLOCK_STATUS),
        ("DPU_G_FEATURES", reg::G_FEATURES),
        ("DPU_G_CTRL", reg::G_CTRL),
        ("DPU_G_STATUS", reg::G_STATUS),
        ("DPU_G_FAULT_STATUS", reg::G_FAULT_STATUS),
        ("DPU_G_FAULT_ENABLE", reg::G_FAULT_ENABLE),
        ("DPU_G_FAULT_TENANT", reg::G_FAULT_TENANT),
        ("DPU_G_FAULT_ERR", reg::G_FAULT_ERR),
        ("DPU_G_FAULT_ADDR_LO", reg::G_FAULT_ADDR_LO),
        ("DPU_G_FAULT_ADDR_HI", reg::G_FAULT_ADDR_HI),
        ("DPU_G_JOB_TIMEOUT", reg::G_JOB_TIMEOUT),
        ("DPU_G_TIME_LO", reg::G_TIME_LO),
        ("DPU_G_TIME_HI", reg::G_TIME_HI),
        ("DPU_G_SCRATCH", reg::G_SCRATCH),
        ("DPU_G_DP_RESETS", reg::G_DP_RESETS),
    ] {
        assert_eq!(m[n] as u32 + g, v, "{n}");
    }
    assert_eq!(m["DPU_T_STRIDE"] as u32, reg::T_STRIDE);
    for (n, v) in [
        ("DPU_T_STATE", reg::T_STATE),
        ("DPU_T_CMD", reg::T_CMD),
        ("DPU_T_CFG_STATUS", reg::T_CFG_STATUS),
        ("DPU_T_SRAM_BASE", reg::T_SRAM_BASE),
        ("DPU_T_SRAM_SIZE", reg::T_SRAM_SIZE),
        ("DPU_T_POLICY", reg::T_POLICY),
        ("DPU_T_VIOL_COUNT", reg::T_VIOL_COUNT),
        ("DPU_T_WIN0", reg::T_WIN0),
    ] {
        assert_eq!(m[n] as u32, v, "{n}");
    }
}
