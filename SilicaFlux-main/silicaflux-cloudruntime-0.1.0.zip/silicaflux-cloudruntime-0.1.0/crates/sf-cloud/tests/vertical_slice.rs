//! The first end-to-end vertical slice, executed on every available backend:
//!
//!   DEVICE DISCOVERY -> SECURE BUFFER ALLOCATION -> DMA TRANSFER -> ACCELERATOR OPERATION -> COMPLETION -> TELEMETRY
//!
//! Correctness is checked against references computed here, independently of the device (crc32/csum/xor).
mod common;
use common::*;
use sf_cloud::backend::{self, BackendKind};
use sf_cloud::mediator::{alloc_flags as f, Op};
use sf_cloud::proto;
use sf_cloud::status::Status;
use std::time::Duration;

#[test]
fn discovery_lists_devices_with_reasons() {
    let devs = backend::discover();
    assert!(devs.iter().any(|d| d.id == "cpu-ref:0" && d.available));
    for d in &devs {
        assert!(!d.reason.is_empty(), "device {} has no availability reason", d.id);
    }
    // hardware must never be reported available: no hardware transport exists
    assert!(devs.iter().filter(|d| d.kind == BackendKind::Hardware).all(|d| !d.available));
}

#[test]
fn vertical_slice_pkt_process_xor32() {
    for (name, be) in backends("mt") {
        let info = be.info();
        let (m, sessions) = mediator_all(be);
        let s = &sessions[0];

        // 1. discovery: geometry comes from the DPU's own registers
        let di = s.info();
        assert_eq!(di.geometry.tenants, 2, "{name}");
        assert_eq!(di.geometry.abi_major, 1);
        assert!(!info.measured_on_hardware);

        // 2. protected buffers: input is device-read-only, output is device-writable
        let n = 1000usize; // not a multiple of the 2048-byte chunk: exercises the partial tail beat logic
        let src = s.alloc(n as u64, f::DEV_READ).unwrap();
        let dst = s.alloc(n as u64, f::DEV_WRITE).unwrap();
        let input = data(1, n);
        s.write(src, 0, &input).unwrap();

        // 3-5. DMA in -> PacketCore op -> DMA out -> completion
        let t = s.submit(&Op::PktProcess { src, src_off: 0, dst, dst_off: 0, len: n as u64, proc_op: proto::proc_op::XOR32, param: 0xA5A5_5A5A }).unwrap();
        let c = s.wait(t, Duration::from_secs(20)).unwrap();
        assert_eq!(c.status, Status::Ok, "{name}: {c:?}");
        assert!(c.committed, "{name}: success must imply commit");
        assert_eq!(c.bytes, n as u64);

        // 6. read the result and compare with an independent reference
        let mut out = vec![0u8; n];
        s.read(dst, 0, &mut out).unwrap();
        let expect = proto::apply_proc(proto::proc_op::XOR32, 0xA5A5_5A5A, &input).unwrap();
        assert_eq!(out, expect, "{name}: output bytes");
        assert_eq!(c.crc_in, Some(proto::crc32(&input)), "{name}: crc_in");
        assert_eq!(c.crc_out, Some(proto::crc32(&expect)), "{name}: crc_out");
        assert_eq!(c.csum, Some(proto::csum1071(&expect)), "{name}: rfc1071 checksum");

        // 7. counters and telemetry
        let tc = s.counters().unwrap();
        assert_eq!(tc.usage.submitted, 1);
        assert_eq!(tc.usage.bytes_ok, n as u64);
        assert!(tc.dev_cmds >= 1, "{name}: device per-tenant counter");
        let dc = m.counters().unwrap();
        assert!(dc.global[proto::reg::cnt::CMDS_RETIRED as usize] >= 1);
        assert!(dc.global[proto::reg::cnt::DMA_BYTES_RD as usize] >= n as u64, "{name}: DMA read bytes");
        assert!(dc.global[proto::reg::cnt::DMA_BYTES_WR as usize] >= n as u64, "{name}: DMA write bytes");
        let ev = s.telemetry();
        assert!(ev.iter().any(|e| e.event == proto::tlm::CMD_RETIRE), "{name}: telemetry retire event");

        // 8. clean release
        s.free(src).unwrap();
        s.free(dst).unwrap();
        let rep = m.shutdown().unwrap();
        assert_eq!(rep.tenants_released, 2);
        println!("{name}: vertical slice OK ({} chunk(s), latency {} cycles, device cycles total {})", c.chunks, c.latency_cycles, dc.cycles);
    }
}

#[test]
fn dma_roundtrip_through_device_memory() {
    for (name, be) in backends("mt") {
        let (m, sessions) = mediator_all(be);
        let s = &sessions[1]; // second tenant: exercises a non-zero SRAM partition base
        let n = 3000usize;
        let h_in = s.alloc(n as u64, f::DEV_READ).unwrap();
        let h_out = s.alloc(n as u64, f::DEV_WRITE).unwrap();
        let dbuf = s.alloc(n as u64, f::DEVICE).unwrap();
        let input = data(2, n);
        s.write(h_in, 0, &input).unwrap();
        let t1 = s.submit(&Op::DmaH2d { src: h_in, src_off: 0, dst: dbuf, dst_off: 0, len: n as u64 }).unwrap();
        let c1 = s.wait(t1, Duration::from_secs(20)).unwrap();
        assert_eq!(c1.status, Status::Ok, "{name}: {c1:?}");
        // device-local memory is not CPU-accessible
        let mut tmp = [0u8; 4];
        assert_eq!(s.read(dbuf, 0, &mut tmp).unwrap_err().status, Status::Permission);
        let t2 = s.submit(&Op::DmaD2h { src: dbuf, src_off: 0, dst: h_out, dst_off: 0, len: n as u64 }).unwrap();
        let c2 = s.wait(t2, Duration::from_secs(20)).unwrap();
        assert_eq!(c2.status, Status::Ok, "{name}: {c2:?}");
        assert!(c2.committed);
        let mut out = vec![0u8; n];
        s.read(h_out, 0, &mut out).unwrap();
        assert_eq!(out, input, "{name}: DMA round trip");
        m.shutdown().unwrap();
    }
}

#[test]
fn unsupported_workloads_fail_clearly_on_rtl() {
    // The vendored RTL blocks the engine opcodes; the runtime must say so instead of pretending.
    let Some(be) = rtl_only("mt", "") else { return };
    let caps = be.info().caps;
    assert!(!caps.gemm_i8 && !caps.aes_gcm && !caps.storage, "RTL backend must not advertise blocked engines: {caps:?}");
    let (m, sessions) = mediator_all(be);
    let s = &sessions[0];
    let a = s.alloc(64, f::DEV_READ).unwrap();
    let c = s.alloc(256, f::DEV_WRITE).unwrap();
    let r = s.submit(&Op::GemmI8 { a, a_off: 0, b: a, b_off: 0, c, c_off: 0, m: 4, n: 4, k: 4 });
    let e = r.unwrap_err();
    assert_eq!(e.status, Status::Unsupported, "{e}");
    assert!(e.detail.contains("gemm_i8") && e.detail.contains("rtl-sim"), "message must name op and backend: {e}");
    m.shutdown().unwrap();
}
