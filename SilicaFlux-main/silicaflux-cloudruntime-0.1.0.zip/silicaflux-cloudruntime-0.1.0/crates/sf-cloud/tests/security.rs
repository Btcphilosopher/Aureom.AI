//! Security tests (controlled test environment: simulated backends only).
//!
//! Two layers are tested separately, on purpose:
//!   * the MEDIATOR (software): handle validation, ownership, quotas, lifetime -- through the public Session API;
//!   * the DEVICE (hardware guards, or the model of them): descriptors are injected through the privileged raw
//!     queue interface, bypassing every mediator check, to prove the device's own guards hold when software
//!     above it is buggy or hostile (a tenant with direct queue access).
mod common;
use common::*;
use sf_cloud::backend::{self, BackendSpec};
use sf_cloud::mediator::{alloc_flags as f, Mediator, MediatorOptions, Op, TenantConfig};
use sf_cloud::proto::{self, err, op, proc_op, reg, Cmd};
use sf_cloud::status::Status;
use std::time::Duration;

const W: Duration = Duration::from_secs(20);

fn mediator_with(spec: &str, tenants: &[TenantConfig]) -> (Mediator, Vec<sf_cloud::mediator::Session>) {
    let be = backend::open_backend(&BackendSpec::parse(spec).unwrap()).unwrap();
    let m = Mediator::open(be, MediatorOptions { cycle_budget: 4_000_000, ..Default::default() }).unwrap();
    let mut v = vec![];
    for (i, c) in tenants.iter().enumerate() {
        let cred = m.provision_tenant(i as u32, c.clone()).unwrap();
        v.push(m.open_session(i as u32, &cred).unwrap());
    }
    (m, v)
}

fn all_specs() -> Vec<String> {
    let mut v = vec!["cpu-ref:mt,log=1".to_string()];
    if rtl_only("mt", "").is_some() {
        v.push("rtl-sim:mt,log=1,seed=11".to_string());
    }
    v
}

fn raw(m: &Mediator, q: u32, cmd: &Cmd) -> proto::Cpl {
    for _ in 0..200 {
        if m.raw_submit(q, cmd).is_ok() {
            break;
        }
        m.raw_pump(64);
    }
    for _ in 0..30_000 {
        m.raw_pump(64);
        if let Some(c) = m.raw_pop_completion(q) {
            assert_eq!(c.tag, cmd.tag);
            return c;
        }
    }
    panic!("no completion for raw command {cmd:?}");
}

// ------------------------------------------------------------------------------------------ mediator layer
#[test]
fn invalid_lengths_and_ranges_rejected() {
    for spec in all_specs() {
        let (m, s) = mediator_with(&spec, &[TenantConfig::default()]);
        let s = &s[0];
        let a = s.alloc(100, f::DEV_READ).unwrap();
        let b = s.alloc(100, f::DEV_WRITE).unwrap();
        let mk = |len: u64, so: u64, d_o: u64| Op::PktProcess { src: a, src_off: so, dst: b, dst_off: d_o, len, proc_op: proc_op::PASS, param: 0 };
        assert_eq!(s.submit(&mk(0, 0, 0)).unwrap_err().status, Status::InvalidArg, "{spec}: zero length");
        assert_eq!(s.submit(&mk(101, 0, 0)).unwrap_err().status, Status::Range, "{spec}: longer than the buffer");
        assert_eq!(s.submit(&mk(u64::MAX, 0, 0)).unwrap_err().status, Status::Range, "{spec}: overflow length");
        assert_eq!(s.submit(&mk(10, u64::MAX - 3, 0)).unwrap_err().status, Status::Range, "{spec}: overflowing offset");
        assert_eq!(s.submit(&mk(10, 1, 0)).unwrap_err().status, Status::Alignment, "{spec}: misaligned offset");
        assert_eq!(s.submit(&Op::PktProcess { src: a, src_off: 0, dst: b, dst_off: 0, len: 6, proc_op: proc_op::BSWAP32, param: 0 }).unwrap_err().status, Status::InvalidArg);
        assert_eq!(s.submit(&Op::PktProcess { src: a, src_off: 0, dst: b, dst_off: 0, len: 8, proc_op: 0x55, param: 0 }).unwrap_err().status, Status::InvalidArg);
        // a destination the device may not write, a source it may not read
        assert_eq!(s.submit(&Op::Copy { src: b, src_off: 0, dst: a, dst_off: 0, len: 8 }).unwrap_err().status, Status::Permission, "{spec}: DEV_READ-only buffer as destination");
        assert_eq!(s.submit(&Op::Copy { src: a, src_off: 0, dst: a, dst_off: 0, len: 8 }).unwrap_err().status, Status::Permission);
        assert_eq!(s.alloc(0, 0).unwrap_err().status, Status::InvalidArg);
        assert_eq!(s.alloc(u64::MAX, 0).unwrap_err().status, Status::InvalidArg);
        assert_eq!(s.alloc(8, 0x80).unwrap_err().status, Status::InvalidArg, "unknown flags");
        // nothing above reached the device
        assert_eq!(m.counters().unwrap().global[reg::cnt::CMDS_ACCEPTED as usize], 0, "{spec}: invalid requests must never reach the device");
        m.shutdown().unwrap();
    }
}

#[test]
fn handles_are_tenant_scoped_and_unforgeable() {
    for spec in all_specs() {
        let (m, ss) = mediator_with(&spec, &[TenantConfig::default(), TenantConfig::default()]);
        let (a, b) = (&ss[0], &ss[1]);
        let secret = b"tenant-A-secret-data............";
        let ha = a.alloc(64, 0).unwrap();
        a.write(ha, 0, secret).unwrap();
        // tenant B tries every verb on A's handle
        let mut tmp = [0u8; 32];
        assert_eq!(b.read(ha, 0, &mut tmp).unwrap_err().status, Status::StaleHandle, "{spec}");
        assert_eq!(b.write(ha, 0, b"overwrite").unwrap_err().status, Status::StaleHandle);
        assert_eq!(b.free(ha).unwrap_err().status, Status::StaleHandle);
        assert_eq!(b.buf_size(ha).unwrap_err().status, Status::StaleHandle);
        let hb = b.alloc(64, 0).unwrap(); // DEV_READ | DEV_WRITE, so only the foreign handle can be the problem
        assert_eq!(b.submit(&Op::Copy { src: ha, src_off: 0, dst: hb, dst_off: 0, len: 32 }).unwrap_err().status, Status::StaleHandle, "{spec}: foreign buffer as a DMA source");
        assert_eq!(
            b.submit(&Op::Copy { src: hb, src_off: 0, dst: ha, dst_off: 0, len: 32 }).unwrap_err().status,
            Status::StaleHandle,
            "{spec}: foreign buffer as a DMA destination"
        );
        // A's data is untouched and still readable by A
        let mut back = vec![0u8; secret.len()];
        a.read(ha, 0, &mut back).unwrap();
        assert_eq!(&back, secret);
        // forged / random handles
        for forged in [0u64, 1, u64::MAX, ha.0 ^ 1, ha.0 ^ (1 << 32), ha.0 ^ (1 << 48), ha.0 ^ (1 << 24), 0x1234_5678_9ABC_DEF0] {
            let h = sf_cloud::mediator::BufHandle(forged);
            if h != ha {
                assert_eq!(a.free(h).unwrap_err().status, Status::StaleHandle, "{spec}: forged handle {forged:#x}");
            }
        }
        assert!(m.counters().unwrap().stats.cross_tenant_attempts >= 5, "cross-tenant attempts must be audited");
        // tickets are tenant-scoped too
        let tk = a.submit(&Op::Nop).unwrap();
        assert_eq!(b.poll(tk).unwrap_err().status, Status::StaleHandle, "{spec}: foreign ticket");
        assert_eq!(a.wait(tk, W).unwrap().status, Status::Ok);
        assert_eq!(a.poll(tk).unwrap_err().status, Status::StaleHandle, "completion is delivered exactly once");
        m.shutdown().unwrap();
    }
}

#[test]
fn use_after_free_and_generation_reuse() {
    for spec in all_specs() {
        let (m, ss) = mediator_with(&spec, &[TenantConfig::default()]);
        let s = &ss[0];
        let old = s.alloc(64, 0).unwrap();
        s.write(old, 0, b"first owner secret").unwrap();
        s.free(old).unwrap();
        assert_eq!(s.free(old).unwrap_err().status, Status::StaleHandle, "{spec}: double free");
        assert_eq!(s.write(old, 0, b"x").unwrap_err().status, Status::StaleHandle, "{spec}: write after free");
        // the slot and the memory are reused, but the old handle must stay dead and the memory must be clean
        let fresh = s.alloc(64, 0).unwrap();
        assert_ne!(old, fresh);
        assert_eq!(s.read(old, 0, &mut [0u8; 4]).unwrap_err().status, Status::StaleHandle);
        let mut got = vec![0xFFu8; 64];
        s.read(fresh, 0, &mut got).unwrap();
        assert!(got.iter().all(|&b| b == 0), "{spec}: reallocated memory must be scrubbed");
        m.shutdown().unwrap();
    }
}

#[test]
fn in_flight_buffers_cannot_be_freed_or_touched() {
    for spec in all_specs() {
        let (m, ss) = mediator_with(&spec, &[TenantConfig::default()]);
        let s = &ss[0];
        let src = s.alloc(4096, f::DEV_READ).unwrap();
        let dst = s.alloc(4096, f::DEV_WRITE).unwrap();
        let dst2 = s.alloc(4096, f::DEV_WRITE).unwrap();
        s.write(src, 0, &data(3, 4096)).unwrap();
        let t = s.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: 4096 }).unwrap();
        // the operation has not been pumped yet: every one of these must be refused
        assert_eq!(s.free(src).unwrap_err().status, Status::Busy, "{spec}: free source in flight");
        assert_eq!(s.free(dst).unwrap_err().status, Status::Busy, "{spec}: free destination in flight");
        assert_eq!(s.write(dst, 0, b"cpu write").unwrap_err().status, Status::Busy, "{spec}: CPU write to a buffer the device is writing");
        assert_eq!(s.read(dst, 0, &mut [0u8; 4]).unwrap_err().status, Status::Busy, "{spec}: CPU read of a buffer the device is writing");
        assert_eq!(s.write(src, 0, b"cpu write").unwrap_err().status, Status::Busy, "{spec}: CPU write to a buffer the device is reading");
        // write-after-write hazard: a second operation targeting the same destination
        assert_eq!(s.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: 64 }).unwrap_err().status, Status::Busy, "{spec}: WAW hazard");
        // a read-only second user of the source is fine
        let t2 = s.submit(&Op::Copy { src, src_off: 0, dst: dst2, dst_off: 0, len: 64 }).unwrap();
        assert_eq!(s.wait(t, W).unwrap().status, Status::Ok);
        assert_eq!(s.wait(t2, W).unwrap().status, Status::Ok);
        s.free(src).unwrap();
        s.free(dst).unwrap();
        m.shutdown().unwrap();
    }
}

#[test]
fn resource_exhaustion_is_bounded_and_recoverable() {
    for spec in all_specs() {
        let small = TenantConfig { host_in_bytes: 8192, host_out_bytes: 8192, max_buffers: 40, max_inflight: 3, max_keys: 2, ..Default::default() };
        let (m, ss) = mediator_with(&spec, &[small]);
        let s = &ss[0];
        // buffer count quota
        let mut hs = vec![];
        let e = loop {
            match s.alloc(64, f::DEV_WRITE) {
                Ok(h) => hs.push(h),
                Err(e) => break e,
            }
            assert!(hs.len() <= 200, "allocation must fail eventually");
        };
        assert!(matches!(e.status, Status::Quota | Status::NoMemory), "{spec}: {e}");
        let peak = hs.len();
        for h in hs.drain(..) {
            s.free(h).unwrap();
        }
        for _ in 0..peak {
            hs.push(s.alloc(64, f::DEV_WRITE).unwrap()); // no leak: the same number fits again
        }
        for h in hs.drain(..) {
            s.free(h).unwrap();
        }
        // memory exhaustion (bytes) distinct from count exhaustion
        let big = s.alloc(8000, f::DEV_WRITE).unwrap();
        assert_eq!(s.alloc(1000, f::DEV_WRITE).unwrap_err().status, Status::NoMemory, "{spec}");
        s.free(big).unwrap();
        // in-flight quota
        let a = s.alloc(64, f::DEV_READ).unwrap();
        let dsts: Vec<_> = (0..4).map(|_| s.alloc(64, f::DEV_WRITE).unwrap()).collect();
        let mut tix = vec![];
        for d in &dsts[..3] {
            tix.push(s.submit(&Op::Copy { src: a, src_off: 0, dst: *d, dst_off: 0, len: 64 }).unwrap());
        }
        assert_eq!(s.submit(&Op::Copy { src: a, src_off: 0, dst: dsts[3], dst_off: 0, len: 64 }).unwrap_err().status, Status::Quota, "{spec}: in-flight quota");
        for t in tix {
            assert_eq!(s.wait(t, W).unwrap().status, Status::Ok);
        }
        // key quota
        let k1 = s.load_key(&[1u8; 16]).unwrap();
        let _k2 = s.load_key(&[2u8; 32]).unwrap();
        assert_eq!(s.load_key(&[3u8; 16]).unwrap_err().status, Status::Quota);
        assert_eq!(s.load_key(&[3u8; 15]).unwrap_err().status, Status::InvalidArg);
        s.unload_key(k1).unwrap();
        s.load_key(&[3u8; 16]).unwrap();
        m.shutdown().unwrap();
    }
}

#[test]
fn submission_storm_loses_nothing() {
    // many more operations than the device queues hold: back-pressure must be absorbed, nothing dropped
    for spec in all_specs() {
        let (m, ss) = mediator_with(&spec, &[TenantConfig { max_inflight: 512, ..Default::default() }]);
        let s = &ss[0];
        let src = s.alloc(1024, f::DEV_READ).unwrap();
        s.write(src, 0, &data(5, 1024)).unwrap();
        let dsts: Vec<_> = (0..120).map(|_| s.alloc(1024, f::DEV_WRITE).unwrap()).collect();
        let tix: Vec<_> =
            dsts.iter().map(|d| s.submit(&Op::PktProcess { src, src_off: 0, dst: *d, dst_off: 0, len: 1024, proc_op: proc_op::XOR32, param: 0x0102_0304 }).unwrap()).collect();
        let expect = proto::apply_proc(proc_op::XOR32, 0x0102_0304, &data(5, 1024)).unwrap();
        for (t, d) in tix.into_iter().zip(&dsts) {
            let c = s.wait(t, W).unwrap();
            assert_eq!(c.status, Status::Ok, "{spec}");
            let mut out = vec![0u8; 1024];
            s.read(*d, 0, &mut out).unwrap();
            assert_eq!(out, expect, "{spec}");
        }
        let st = m.counters().unwrap().stats;
        assert_eq!((st.submitted, st.ok, st.failed, st.anomalies_unknown_tag), (120, 120, 0, 0), "{spec}");
        m.shutdown().unwrap();
    }
}

// ------------------------------------------------------------------------------------------ device layer
/// Independent monitor: every host-memory access the device performed must lie inside a window that was
/// granted to some tenant (the log is produced by the simulated host memory, not by the DPU).
fn assert_accesses_within(m: &Mediator, granted: &[(u64, u64)], forbidden: &[(u64, u64)], what: &str) {
    let log = m.with_sim(|s| s.drain_access_log()).unwrap();
    for a in &log {
        let inside = granted.iter().any(|&(b, n)| a.addr >= b && a.addr < b + n);
        assert!(inside, "{what}: host access outside every granted window at {:#x} (write={})", a.addr, a.write);
        assert!(!forbidden.iter().any(|&(b, n)| a.addr >= b && a.addr < b + n), "{what}: host access into a forbidden region at {:#x}", a.addr);
    }
}

#[test]
fn hardware_refuses_cross_tenant_and_read_only_dma() {
    for spec in all_specs() {
        let (m, _ss) = mediator_with(&spec, &[TenantConfig::default(), TenantConfig::default()]);
        let (in0, out0) = m.tenant_windows(0).unwrap();
        let (in1, out1) = m.tenant_windows(1).unwrap();
        let (q0, q1) = (m.queue_of_tenant(0).unwrap(), m.queue_of_tenant(1).unwrap());
        m.host_write_raw(in1.0, &vec![0x77u8; 256]).unwrap();
        m.host_write_raw(out1.0, &vec![0x55u8; 256]).unwrap();
        m.with_sim(|s| s.drain_access_log()).unwrap();
        let before1_out = {
            let mut v = vec![0u8; 256];
            m.host_read_raw(out1.0, &mut v).unwrap();
            v
        };

        // (a) tenant 0 asks the device to read tenant 1's input window
        let c = raw(&m, q0, &Cmd { opcode: op::PKT_PROCESS, tenant: 0, tag: 1, src: in1.0, dst: out0.0, len: 64, proc_op: proc_op::PASS, ..Default::default() });
        assert_eq!((c.status, c.err), (proto::status::ERROR, err::PERM_READ), "{spec}: cross-tenant read");
        assert!(!c.committed());
        // (b) ...and to write tenant 1's output window
        m.recover_tenant(0).unwrap(); // (a) was a violation: tenant 0 is quarantined until recovered
        let c = raw(&m, q0, &Cmd { opcode: op::PKT_PROCESS, tenant: 0, tag: 2, src: in0.0, dst: out1.0, len: 64, proc_op: proc_op::PASS, ..Default::default() });
        assert_eq!(c.err, err::PERM_WRITE, "{spec}: cross-tenant write");
        m.recover_tenant(0).unwrap();
        // (c) write into its OWN read-only window
        let c = raw(&m, q0, &Cmd { opcode: op::DMA_D2H, tenant: 0, tag: 3, dst: in0.0 + 64, len: 64, ..Default::default() });
        assert_eq!(c.err, err::PERM_WRITE, "{spec}: write to a read-only window");
        m.recover_tenant(0).unwrap();
        // (d) a transfer that starts inside a window and runs past its end
        let c = raw(&m, q0, &Cmd { opcode: op::PKT_PROCESS, tenant: 0, tag: 4, src: in0.0 + in0.1 - 16, dst: out0.0, len: 64, proc_op: proc_op::PASS, ..Default::default() });
        assert_eq!(c.err, err::PERM_READ, "{spec}: window overrun");
        m.recover_tenant(0).unwrap();
        // (e) address-space wrap
        let c = raw(&m, q0, &Cmd { opcode: op::PKT_PROCESS, tenant: 0, tag: 5, src: u64::MAX - 7, dst: out0.0, len: 64, proc_op: proc_op::PASS, ..Default::default() });
        assert_eq!(c.err, err::PERM_READ, "{spec}: wrapping address");
        // after a violation the tenant is quarantined; the violation is observable everywhere
        let probe = raw(&m, q0, &Cmd { opcode: op::NOP, tenant: 0, tag: 6, ..Default::default() });
        assert_eq!(probe.err, err::QUARANTINED, "{spec}");
        assert_eq!(m.mgmt_read(reg::tenant(0, reg::T_VIOL_COUNT)).unwrap(), 5, "{spec}: violation counter");
        let fst = m.mgmt_read(reg::G_FAULT_STATUS).unwrap();
        assert!(fst & (1 << proto::flt::PERM_VIOL) != 0, "{spec}: sticky PERM_VIOL fault");
        assert_eq!(m.mgmt_read(reg::G_FAULT_ERR).unwrap(), err::PERM_READ as u32, "{spec}: last fault code");
        assert!(matches!(m.health(), sf_cloud::mediator::Health::Degraded(_)), "{spec}: health must show the quarantine: {:?}", m.health());
        let ev = m.drain_telemetry();
        assert!(ev.iter().filter(|e| e.event == proto::tlm::VIOLATION && e.tenant == 0).count() >= 5, "{spec}: violation telemetry");

        // the other tenant is unaffected and keeps working
        let c = raw(&m, q1, &Cmd { opcode: op::PKT_PROCESS, tenant: 1, tag: 7, src: in1.0, dst: out1.0, len: 64, proc_op: proc_op::PASS, ..Default::default() });
        assert_eq!((c.status, c.err), (proto::status::OK, err::NONE), "{spec}: neighbour must not be disturbed");

        // independent evidence: no device access ever touched a forbidden region, and tenant 1's output
        // window changed only where tenant 1's own command wrote
        let granted = [in0, out0, in1, out1];
        assert_accesses_within(&m, &granted, &[], &spec);
        let mut after1_out = vec![0u8; 256];
        m.host_read_raw(out1.0, &mut after1_out).unwrap();
        assert_eq!(&after1_out[64..], &before1_out[64..], "{spec}: bytes beyond tenant 1's own 64-byte write changed");
        m.recover_tenant(0).unwrap();
        let c = raw(&m, q0, &Cmd { opcode: op::NOP, tenant: 0, tag: 8, ..Default::default() });
        assert_eq!(c.err, err::NONE, "{spec}: recovered tenant works again");
        m.shutdown().unwrap();
    }
}

#[test]
fn hardware_refuses_forged_tenant_and_malformed_descriptors() {
    for spec in all_specs() {
        let (m, _ss) = mediator_with(&spec, &[TenantConfig::default(), TenantConfig::default()]);
        let (in0, out0) = m.tenant_windows(0).unwrap();
        let q0 = m.queue_of_tenant(0).unwrap();
        let good = Cmd { opcode: op::PKT_PROCESS, tenant: 0, tag: 0, src: in0.0, dst: out0.0, len: 64, proc_op: proc_op::PASS, ..Default::default() };
        let mut t = 100u32;
        let mut next = || {
            t += 1;
            t
        };
        // reserved bits, unknown opcode, bad lengths, bad ops: none is a violation, none quarantines
        for (label, mut c, want) in [
            ("reserved w0 bits", good, err::BAD_DESC),
            ("reserved w8 bits", good, err::BAD_DESC),
            ("reserved w10/11", good, err::BAD_DESC),
            ("flags reserved", good, err::BAD_DESC),
            ("unknown opcode", good, err::BAD_OPCODE),
            ("zero length", good, err::BAD_LENGTH),
            ("oversize length", good, err::BAD_LENGTH),
            ("unknown proc op", good, err::PROC_OP),
            ("misaligned src", good, err::ALIGN),
            ("engine opcode on a network queue", good, err::BAD_OPCODE),
        ] {
            c.tag = next();
            match label {
                "reserved w0 bits" => c.rsvd_w0 = 1,
                "reserved w8 bits" => c.rsvd_w8 = 0x10,
                "reserved w10/11" => c.rsvd_w10_11 = 1,
                "flags reserved" => c.flags = 0x80,
                "unknown opcode" => c.opcode = 0xEE,
                "zero length" => c.len = 0,
                "oversize length" => c.len = 1 << 20,
                "unknown proc op" => c.proc_op = 0x40,
                "misaligned src" => c.src += 2,
                _ => c.opcode = op::INFER,
            }
            let cpl = raw(&m, q0, &c);
            assert_eq!(cpl.err, want, "{spec}: {label}");
            assert_eq!(cpl.status, proto::status::ERROR);
            assert_eq!(cpl.bytes, 0, "{spec}: {label}: no byte may be reported as moved");
        }
        assert_eq!(m.mgmt_read(reg::tenant(0, reg::T_STATE)).unwrap() & 7, proto::tstate::ACTIVE, "{spec}: descriptor errors are not violations");
        // an SRAM range outside the tenant's partition IS an isolation violation (0x13): it quarantines
        let cpl = raw(&m, q0, &Cmd { tag: next(), sram_off: 1 << 20, ..good });
        assert_eq!(cpl.err, err::SRAM_RANGE, "{spec}: SRAM overrun");
        assert_eq!(m.mgmt_read(reg::tenant(0, reg::T_STATE)).unwrap() & 7, proto::tstate::QUARANTINED, "{spec}");
        m.recover_tenant(0).unwrap();
        // a forged tenant id IS a violation (the queue's hardware binding is authoritative)
        let cpl = raw(&m, q0, &Cmd { tenant: 1, tag: next(), ..good });
        assert_eq!(cpl.err, err::TENANT_MISMATCH, "{spec}");
        assert_eq!(cpl.tenant, 0, "{spec}: the completion carries the queue's tenant, never the claimed one");
        assert_eq!(m.mgmt_read(reg::tenant(0, reg::T_STATE)).unwrap() & 7, proto::tstate::QUARANTINED);
        m.shutdown().unwrap();
    }
}

#[test]
fn fuzzed_descriptors_never_escape_or_wedge() {
    for spec in all_specs() {
        let (m, _ss) = mediator_with(&spec, &[TenantConfig::default(), TenantConfig::default()]);
        let wins = [m.tenant_windows(0).unwrap(), m.tenant_windows(1).unwrap()];
        let granted: Vec<(u64, u64)> = wins.iter().flat_map(|w| [w.0, w.1]).collect();
        m.with_sim(|s| s.drain_access_log()).unwrap();
        let mut x = 0xDEAD_BEEF_CAFE_F00Du64;
        let mut rnd = move || {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            x
        };
        let mut completions = 0;
        for i in 0..300u32 {
            let t = (rnd() % 2) as usize;
            let q = m.queue_of_tenant(t as u32).unwrap();
            // half fully random words, half "plausible header, random body"
            let mut w = [0u32; 12];
            for v in w.iter_mut() {
                *v = rnd() as u32;
            }
            if rnd() % 2 == 0 {
                w[0] = [0u32, 1, 2, 3, 0x10, 0x11, 0x12][(rnd() % 7) as usize] | (t as u32) << 16;
                w[8] = (rnd() % 4) as u32;
                w[10] = 0;
                w[11] = 0;
                if rnd() % 2 == 0 {
                    w[3] = 0;
                    w[5] = 0;
                    w[2] = wins[t].0 .0 as u32 + (rnd() % 0x4000) as u32 * 4;
                    w[4] = wins[t].1 .0 as u32 + (rnd() % 0x4000) as u32 * 4;
                    w[6] = (rnd() % 5000) as u32;
                }
            }
            w[1] = i + 1;
            let cmd = Cmd::decode(&w);
            let c = raw(&m, q, &cmd);
            completions += 1;
            assert_eq!(c.tag, cmd.tag);
            assert_eq!(c.queue as u32, q, "{spec}: completion on the wrong queue");
            assert_eq!(c.tenant as usize, t, "{spec}: completion carries a foreign tenant");
            if c.err == err::NONE {
                assert_eq!(c.status, proto::status::OK);
            }
            if m.mgmt_read(reg::tenant(t as u32, reg::T_STATE)).unwrap() & 7 == proto::tstate::QUARANTINED {
                m.recover_tenant(t as u32).unwrap();
            }
        }
        assert_eq!(completions, 300);
        // the device is alive and its data plane healthy afterwards
        let q0 = m.queue_of_tenant(0).unwrap();
        let ok = raw(&m, q0, &Cmd { opcode: op::NOP, tenant: 0, tag: 0xFFFF_0001, ..Default::default() });
        assert_eq!(ok.err, err::NONE, "{spec}");
        assert_eq!(m.mgmt_read(reg::G_STATUS).unwrap() & reg::STATUS_HALTED, 0, "{spec}: halted after fuzzing");
        assert_accesses_within(&m, &granted, &[], &spec);
        m.shutdown().unwrap();
    }
}

#[test]
fn management_and_invalid_queues_are_not_tenant_reachable() {
    // Observe what the device does with a submission to the firmware-only management queue (15) and to a queue
    // that does not exist, and require that neither produces a completion on a tenant queue nor changes state.
    for spec in all_specs() {
        let (m, _ss) = mediator_with(&spec, &[TenantConfig::default(), TenantConfig::default()]);
        let (in0, out0) = m.tenant_windows(0).unwrap();
        m.with_sim(|s| s.drain_access_log()).unwrap();
        let evil = Cmd { opcode: op::PKT_PROCESS, tenant: 0, tag: 0xBAD, src: in0.0, dst: out0.0, len: 64, proc_op: proc_op::PASS, ..Default::default() };
        for q in [3u32, 14, 15] {
            let r = m.raw_submit(q, &evil);
            println!("{spec}: raw submit to queue {q}: {r:?}");
        }
        m.raw_pump(5_000);
        for q in 0..3 {
            if let Some(c) = m.raw_pop_completion(q) {
                panic!("{spec}: a submission to a foreign queue produced a completion on queue {q}: {c:?}");
            }
        }
        let mgmt_cq = m.mgmt_read(reg::MGMT_CQ).unwrap_or(0);
        println!("{spec}: management CQ status after the attempts: {mgmt_cq:#x}");
        let out = {
            let mut v = vec![0u8; 64];
            m.host_read_raw(out0.0, &mut v).unwrap();
            v
        };
        assert!(out.iter().all(|&b| b == 0), "{spec}: a foreign-queue submission moved data");
        m.shutdown().unwrap();
    }
}
