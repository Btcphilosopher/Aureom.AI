//! Shared helpers for the integration tests.
#![allow(dead_code)]
use sf_cloud::backend::{self, Backend, BackendSpec};
use sf_cloud::mediator::{Mediator, MediatorOptions, Session, TenantConfig};

/// Every backend available on this machine.  `cpu-ref` is always present; `rtl-sim` only when its library has
/// been built.  With `SF_REQUIRE_RTL=1` a missing RTL library is a hard failure (CI must not skip silently).
pub fn backends(cfg: &str) -> Vec<(String, Box<dyn Backend>)> {
    let mut v: Vec<(String, Box<dyn Backend>)> = Vec::new();
    v.push((format!("cpu-ref:{cfg}"), backend::open_backend(&BackendSpec::parse(&format!("cpu-ref:{cfg}")).unwrap()).unwrap()));
    match backend::open_backend(&BackendSpec::parse(&format!("rtl-sim:{cfg},seed=5")).unwrap()) {
        Ok(b) => v.push((format!("rtl-sim:{cfg}"), b)),
        Err(e) => {
            if std::env::var("SF_REQUIRE_RTL").is_ok_and(|v| v == "1") {
                panic!("SF_REQUIRE_RTL=1 but the RTL backend is unavailable: {e}");
            }
            eprintln!("note: rtl-sim:{cfg} not available, running cpu-ref only ({e})");
        }
    }
    v
}

pub fn rtl_only(cfg: &str, extra: &str) -> Option<Box<dyn Backend>> {
    let spec = if extra.is_empty() { format!("rtl-sim:{cfg}") } else { format!("rtl-sim:{cfg},{extra}") };
    match backend::open_backend(&BackendSpec::parse(&spec).unwrap()) {
        Ok(b) => Some(b),
        Err(e) => {
            if std::env::var("SF_REQUIRE_RTL").is_ok_and(|v| v == "1") {
                panic!("SF_REQUIRE_RTL=1 but the RTL backend is unavailable: {e}");
            }
            eprintln!("note: rtl-sim:{cfg} not available, skipping ({e})");
            None
        }
    }
}

/// Mediator with every tenant of the device provisioned with default quotas.
pub fn mediator_all(be: Box<dyn Backend>) -> (Mediator, Vec<Session>) {
    let m = Mediator::open(be, MediatorOptions { cycle_budget: 4_000_000, ..Default::default() }).expect("open mediator");
    let n = m.info().geometry.tenants;
    let mut sessions = vec![];
    for t in 0..n {
        let cred = m.provision_tenant(t, TenantConfig { name: format!("t{t}"), ..Default::default() }).expect("provision");
        sessions.push(m.open_session(t, &cred).expect("session"));
    }
    (m, sessions)
}

/// Deterministic pseudo-random bytes.
pub fn data(seed: u64, n: usize) -> Vec<u8> {
    let mut x = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
    (0..n)
        .map(|_| {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            (x >> 24) as u8
        })
        .collect()
}

/// Run `f` on a thread and fail (instead of hanging CI) if it does not finish in `secs` seconds.
pub fn with_timeout<F: FnOnce() + Send + 'static>(secs: u64, what: &str, f: F) {
    let (tx, rx) = std::sync::mpsc::channel();
    let h = std::thread::spawn(move || {
        f();
        let _ = tx.send(());
    });
    match rx.recv_timeout(std::time::Duration::from_secs(secs)) {
        Ok(()) => h.join().expect("test thread panicked"),
        Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => {
            h.join().expect("test thread panicked");
        }
        Err(_) => panic!("{what}: no result within {secs}s (deadlock?)"),
    }
}
