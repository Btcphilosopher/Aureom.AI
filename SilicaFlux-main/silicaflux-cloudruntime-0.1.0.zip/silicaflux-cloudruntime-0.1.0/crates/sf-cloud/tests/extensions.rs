//! Software-extension workloads (INT8 GEMM, AES-GCM, block storage): implemented ONLY by the cpu-ref backend.
//! The vendored RTL blocks these engines; `vertical_slice::unsupported_workloads_fail_clearly_on_rtl` proves the
//! runtime says so.  These tests give the cpu-ref implementations independent known answers.
mod common;
use common::*;
use sf_cloud::backend::{self, BackendSpec};
use sf_cloud::mediator::{alloc_flags as f, Mediator, MediatorOptions, Op, Session, TenantConfig};
use sf_cloud::status::Status;
use std::time::Duration;

const W: Duration = Duration::from_secs(20);

fn hex(s: &str) -> Vec<u8> {
    (0..s.len() / 2).map(|i| u8::from_str_radix(&s[2 * i..2 * i + 2], 16).unwrap()).collect()
}

fn cpu(tenants: u32) -> (Mediator, Vec<Session>) {
    let be = backend::open_backend(&BackendSpec::parse("cpu-ref:mt").unwrap()).unwrap();
    let m = Mediator::open(be, MediatorOptions { cycle_budget: 2_000_000, ..Default::default() }).unwrap();
    let mut v = vec![];
    for t in 0..tenants {
        let c = m.provision_tenant(t, TenantConfig::default()).unwrap();
        v.push(m.open_session(t, &c).unwrap());
    }
    (m, v)
}

#[test]
fn gemm_i8_matches_reference() {
    let (m, ss) = cpu(1);
    let s = &ss[0];
    for (mm, n, k) in [(1u32, 1u32, 1u32), (4, 4, 4), (7, 5, 9), (16, 16, 16), (64, 64, 64), (64, 1, 64), (1, 64, 3)] {
        let a: Vec<i8> = data(1 + mm as u64, (mm * k) as usize).into_iter().map(|b| b as i8).collect();
        let b: Vec<i8> = data(2 + n as u64, (k * n) as usize).into_iter().map(|b| b as i8).collect();
        let (ha, hb) = (s.alloc((mm * k) as u64, f::DEV_READ).unwrap(), s.alloc((k * n) as u64, f::DEV_READ).unwrap());
        let hc = s.alloc((mm * n * 4) as u64, f::DEV_WRITE).unwrap();
        s.write(ha, 0, &a.iter().map(|&x| x as u8).collect::<Vec<_>>()).unwrap();
        s.write(hb, 0, &b.iter().map(|&x| x as u8).collect::<Vec<_>>()).unwrap();
        let t = s.submit(&Op::GemmI8 { a: ha, a_off: 0, b: hb, b_off: 0, c: hc, c_off: 0, m: mm, n, k }).unwrap();
        let c = s.wait(t, W).unwrap();
        assert_eq!((c.status, c.bytes, c.committed), (Status::Ok, (mm * n * 4) as u64, true), "{mm}x{n}x{k}");
        let mut out = vec![0u8; (mm * n * 4) as usize];
        s.read(hc, 0, &mut out).unwrap();
        for i in 0..mm as usize {
            for j in 0..n as usize {
                let mut acc = 0i32;
                for x in 0..k as usize {
                    acc += a[i * k as usize + x] as i32 * b[x * n as usize + j] as i32;
                }
                let got = i32::from_le_bytes(out[(i * n as usize + j) * 4..][..4].try_into().unwrap());
                assert_eq!(got, acc, "C[{i}][{j}] of {mm}x{n}x{k}");
            }
        }
        for h in [ha, hb, hc] {
            s.free(h).unwrap();
        }
    }
    // extremes: -128 * -128 accumulated k times must not overflow i32 for k <= 64
    let (ha, hb, hc) = (s.alloc(64, f::DEV_READ).unwrap(), s.alloc(64, f::DEV_READ).unwrap(), s.alloc(4, f::DEV_WRITE).unwrap());
    s.write(ha, 0, &[0x80u8; 64]).unwrap();
    s.write(hb, 0, &[0x80u8; 64]).unwrap();
    let t = s.submit(&Op::GemmI8 { a: ha, a_off: 0, b: hb, b_off: 0, c: hc, c_off: 0, m: 1, n: 1, k: 64 }).unwrap();
    s.wait(t, W).unwrap();
    let mut o = [0u8; 4];
    s.read(hc, 0, &mut o).unwrap();
    assert_eq!(i32::from_le_bytes(o), 64 * 128 * 128);
    // parameter validation
    for (mm, n, k) in [(0u32, 1u32, 1u32), (65, 1, 1), (1, 65, 1), (1, 1, 65)] {
        assert_eq!(s.submit(&Op::GemmI8 { a: ha, a_off: 0, b: hb, b_off: 0, c: hc, c_off: 0, m: mm, n, k }).unwrap_err().status, Status::InvalidArg);
    }
    // operand smaller than m*k
    assert_eq!(s.submit(&Op::GemmI8 { a: ha, a_off: 0, b: hb, b_off: 0, c: hc, c_off: 0, m: 8, n: 1, k: 9 }).unwrap_err().status, Status::Range);
    m.shutdown().unwrap();
}

fn gcm_case(s: &Session, key: &[u8], iv: &[u8; 12], aad: &[u8], pt: &[u8]) -> (Vec<u8>, Vec<u8>) {
    let k = s.load_key(key).unwrap();
    let (hp, hc, ht) = (s.alloc(pt.len() as u64, f::DEV_READ).unwrap(), s.alloc(pt.len() as u64, f::DEV_WRITE).unwrap(), s.alloc(16, f::DEV_WRITE).unwrap());
    s.write(hp, 0, pt).unwrap();
    let t =
        s.submit(&Op::AesGcm { key: k, encrypt: true, iv: *iv, aad: aad.to_vec(), src: hp, src_off: 0, dst: hc, dst_off: 0, tag: ht, tag_off: 0, len: pt.len() as u32 }).unwrap();
    let c = s.wait(t, W).unwrap();
    assert_eq!((c.status, c.committed, c.bytes), (Status::Ok, true, pt.len() as u64), "{c:?}");
    let (mut ct, mut tag) = (vec![0u8; pt.len()], vec![0u8; 16]);
    s.read(hc, 0, &mut ct).unwrap();
    s.read(ht, 0, &mut tag).unwrap();
    for h in [hp, hc, ht] {
        s.free(h).unwrap();
    }
    s.unload_key(k).unwrap();
    (ct, tag)
}

#[test]
fn aes_gcm_known_answers() {
    // McGrew & Viega, "The Galois/Counter Mode of Operation", test cases 4 and 16 (re-derived independently with OpenSSL)
    let p = hex("d9313225f88406e5a55909c5aff5269a86a7a9531534f7da2e4c303d8a318a721c3c0c95956809532fcf0e2449a6b525b16aedf5aa0de657ba637b39");
    let aad = hex("feedfacedeadbeeffeedfacedeadbeefabaddad2");
    let iv: [u8; 12] = hex("cafebabefacedbaddecaf888").try_into().unwrap();
    let (m, ss) = cpu(1);
    let s = &ss[0];
    let (c, t) = gcm_case(s, &hex("feffe9928665731c6d6a8f9467308308"), &iv, &aad, &p);
    assert_eq!(c, hex("42831ec2217774244b7221b784d0d49ce3aa212f2c02a4e035c17e2329aca12e21d514b25466931c7d8f6a5aac84aa051ba30b396a0aac973d58e091"), "TC4 ciphertext");
    assert_eq!(t, hex("5bc94fbc3221a5db94fae95ae7121a47"), "TC4 tag");
    let (c, t) = gcm_case(s, &hex("feffe9928665731c6d6a8f9467308308feffe9928665731c6d6a8f9467308308"), &iv, &aad, &p);
    assert_eq!(c, hex("522dc1f099567d07f47f37a32a84427d643a8cdcbfe5c0c97598a2bd2555d1aa8cb08e48590dbb3da7b08b1056828838c5f61e6393ba7a0abcc9f662"), "TC16 ciphertext");
    assert_eq!(t, hex("76fc6ece0f4e1768cddf8853bb2d551b"), "TC16 tag");
    m.shutdown().unwrap();
}

#[test]
fn aes_gcm_roundtrip_and_authentication_failure() {
    let (m, ss) = cpu(1);
    let s = &ss[0];
    let key = [7u8; 32];
    let iv = [9u8; 12];
    let pt = data(5, 1500);
    let (ct, tag) = gcm_case(s, &key, &iv, b"hdr", &pt);
    assert_ne!(ct, pt);
    let k = s.load_key(&key).unwrap();
    let dec = |ct: &[u8], tag: &[u8], aad: &[u8], key: sf_cloud::mediator::KeyHandle| {
        let (hc, ht, hp) = (s.alloc(ct.len() as u64, f::DEV_READ).unwrap(), s.alloc(16, f::DEV_READ).unwrap(), s.alloc(ct.len() as u64, f::DEV_WRITE).unwrap());
        s.write(hc, 0, ct).unwrap();
        s.write(ht, 0, tag).unwrap();
        let t = s.submit(&Op::AesGcm { key, encrypt: false, iv, aad: aad.to_vec(), src: hc, src_off: 0, dst: hp, dst_off: 0, tag: ht, tag_off: 0, len: ct.len() as u32 }).unwrap();
        let c = s.wait(t, W).unwrap();
        let mut out = vec![0xAAu8; ct.len()];
        s.read(hp, 0, &mut out).unwrap();
        for h in [hc, ht, hp] {
            s.free(h).unwrap();
        }
        (c, out)
    };
    let (c, out) = dec(&ct, &tag, b"hdr", k);
    assert_eq!((c.status, c.committed), (Status::Ok, true));
    assert_eq!(out, pt, "decrypt round trip");
    // every kind of tampering must fail authentication AND must not release any plaintext
    let mut bad_ct = ct.clone();
    bad_ct[100] ^= 1;
    let mut bad_tag = tag.clone();
    bad_tag[15] ^= 0x80;
    for (label, c_in, t_in, aad) in [("ciphertext bit flip", &bad_ct, &tag, &b"hdr"[..]), ("tag bit flip", &ct, &bad_tag, b"hdr"), ("wrong AAD", &ct, &tag, b"hdX")] {
        let (c, out) = dec(c_in, t_in, aad, k);
        assert_eq!(c.status, Status::CryptoAuth, "{label}: {c:?}");
        assert!(!c.committed, "{label}");
        assert!(out.iter().all(|&b| b == 0), "{label}: plaintext must never be released on authentication failure");
    }
    m.shutdown().unwrap();
}

#[test]
fn keys_are_owned_by_their_tenant() {
    let (m, ss) = cpu(2);
    let (a, b) = (&ss[0], &ss[1]);
    let ka = a.load_key(&[0x42u8; 16]).unwrap();
    let (hp, hc, ht) = (b.alloc(64, f::DEV_READ).unwrap(), b.alloc(64, f::DEV_WRITE).unwrap(), b.alloc(16, f::DEV_WRITE).unwrap());
    // tenant B tries to use tenant A's key handle
    let e = b.submit(&Op::AesGcm { key: ka, encrypt: true, iv: [0; 12], aad: vec![], src: hp, src_off: 0, dst: hc, dst_off: 0, tag: ht, tag_off: 0, len: 64 }).unwrap_err();
    assert_eq!(e.status, Status::StaleHandle, "{e}");
    assert_eq!(b.unload_key(ka).unwrap_err().status, Status::StaleHandle);
    assert!(m.counters().unwrap().stats.cross_tenant_attempts >= 2);
    // the failed attempts left tenant B's buffers untouched and unpinned
    b.free(hc).unwrap();
    // A's key still works for A and is gone once unloaded
    a.unload_key(ka).unwrap();
    assert_eq!(a.unload_key(ka).unwrap_err().status, Status::StaleHandle, "double unload");
    let (ap, ac, at) = (a.alloc(64, f::DEV_READ).unwrap(), a.alloc(64, f::DEV_WRITE).unwrap(), a.alloc(16, f::DEV_WRITE).unwrap());
    assert_eq!(
        a.submit(&Op::AesGcm { key: ka, encrypt: true, iv: [0; 12], aad: vec![], src: ap, src_off: 0, dst: ac, dst_off: 0, tag: at, tag_off: 0, len: 64 }).unwrap_err().status,
        Status::StaleHandle,
        "use after unload"
    );
    // shutdown reports (and wipes) keys that were still loaded
    let _k = a.load_key(&[1u8; 16]).unwrap();
    let rep = m.shutdown().unwrap();
    assert_eq!(rep.keys_wiped, 1);
}

#[test]
fn block_storage_namespaces_are_private() {
    let (m, ss) = cpu(2);
    let (a, b) = (&ss[0], &ss[1]);
    let blocks = 4u32;
    let payload = data(77, 512 * blocks as usize);
    let src = a.alloc(payload.len() as u64, f::DEV_READ).unwrap();
    a.write(src, 0, &payload).unwrap();
    let t = a.submit(&Op::StorageWrite { src, src_off: 0, lba: 10, blocks }).unwrap();
    let c = a.wait(t, W).unwrap();
    assert_eq!((c.status, c.bytes, c.committed), (Status::Ok, payload.len() as u64, true));
    let read = |s: &Session, lba: u64, blocks: u32| -> Vec<u8> {
        let dst = s.alloc(512 * blocks as u64, f::DEV_WRITE).unwrap();
        let t = s.submit(&Op::StorageRead { dst, dst_off: 0, lba, blocks }).unwrap();
        assert_eq!(s.wait(t, W).unwrap().status, Status::Ok);
        let mut out = vec![0u8; 512 * blocks as usize];
        s.read(dst, 0, &mut out).unwrap();
        s.free(dst).unwrap();
        out
    };
    assert_eq!(read(a, 10, blocks), payload, "read back what was written");
    assert_eq!(read(a, 12, 1), payload[1024..1536], "partial range");
    assert!(read(a, 100, 2).iter().all(|&x| x == 0), "unwritten blocks read as zero");
    // tenant B sees an empty namespace: A's blocks are not reachable by any LBA
    assert!(read(b, 10, blocks).iter().all(|&x| x == 0), "tenant B must not see tenant A's blocks");
    // overwrite
    let p2 = data(78, 512);
    a.write(src, 0, &p2).unwrap();
    let t = a.submit(&Op::StorageWrite { src, src_off: 0, lba: 11, blocks: 1 }).unwrap();
    a.wait(t, W).unwrap();
    assert_eq!(read(a, 11, 1), p2);
    assert_eq!(read(a, 10, 1), payload[..512]);
    // range checks: every out-of-range LBA is refused by the device, none wraps around
    for lba in [8192u64, 8191 + 1, u64::MAX - 1, u64::MAX] {
        let dst = a.alloc(512, f::DEV_WRITE).unwrap();
        let t = a.submit(&Op::StorageRead { dst, dst_off: 0, lba, blocks: 1 }).unwrap();
        assert_eq!(a.wait(t, W).unwrap().status, Status::InvalidArg, "lba {lba:#x}");
        a.free(dst).unwrap();
    }
    let dst = a.alloc(512, f::DEV_WRITE).unwrap();
    let t = a.submit(&Op::StorageRead { dst, dst_off: 0, lba: 8191, blocks: 1 }).unwrap(); // the last valid block
    assert_eq!(a.wait(t, W).unwrap().status, Status::Ok);
    m.shutdown().unwrap();
}

#[test]
fn extension_commands_obey_the_same_window_guards_as_dma() {
    use sf_cloud::backend::ExtCmd;
    use sf_cloud::proto::{self, err, op};
    let (m, _ss) = cpu(2);
    let (in0, out0) = m.tenant_windows(0).unwrap();
    let (in1, out1) = m.tenant_windows(1).unwrap();
    let q0 = m.queue_of_tenant(0).unwrap();
    m.host_write_raw(in1.0, &vec![0x11u8; 256]).unwrap();
    m.host_write_raw(out1.0, &vec![0x22u8; 256]).unwrap();
    let run = |e: ExtCmd| -> proto::Cpl {
        m.raw_submit_ext(q0, &e).unwrap();
        for _ in 0..2000 {
            m.raw_pump(64);
            if let Some(c) = m.raw_pop_completion(q0) {
                return c;
            }
        }
        panic!("no completion");
    };
    // tenant 0's GEMM reads tenant 1's window / writes tenant 1's window / writes its own READ-ONLY window
    let c = run(ExtCmd::GemmI8 { tag: 1, a: in1.0, b: in0.0, c: out0.0, m: 2, n: 2, k: 2 });
    assert_eq!((c.opcode, c.err), (op::INFER, err::PERM_READ), "{c:?}");
    m.recover_tenant(0).unwrap();
    let c = run(ExtCmd::GemmI8 { tag: 2, a: in0.0, b: in0.0, c: out1.0, m: 2, n: 2, k: 2 });
    assert_eq!(c.err, err::PERM_WRITE, "{c:?}");
    m.recover_tenant(0).unwrap();
    let c = run(ExtCmd::GemmI8 { tag: 3, a: in0.0, b: in0.0, c: in0.0 + 64, m: 2, n: 2, k: 2 });
    assert_eq!(c.err, err::PERM_WRITE, "write into a read-only window: {c:?}");
    m.recover_tenant(0).unwrap();
    // AES-GCM / storage: same guards
    let c = run(ExtCmd::AesGcm { tag: 4, encrypt: true, key: vec![0; 16], iv: [0; 12], aad: vec![], src: in1.0, dst: out0.0, tag_addr: out0.0 + 128, len: 64 });
    assert_eq!((c.opcode, c.err), (op::CRYPTO, err::PERM_READ), "{c:?}");
    m.recover_tenant(0).unwrap();
    let c = run(ExtCmd::StorageRead { tag: 5, lba: 0, dst: out1.0, blocks: 1 });
    assert_eq!((c.opcode, c.err), (op::STORAGE, err::PERM_WRITE), "{c:?}");
    m.recover_tenant(0).unwrap();
    // none of the refused commands moved a byte of tenant 1's memory
    let mut b = vec![0u8; 256];
    m.host_read_raw(out1.0, &mut b).unwrap();
    assert!(b.iter().all(|&x| x == 0x22), "tenant 1's output window was modified");
    m.shutdown().unwrap();
}
