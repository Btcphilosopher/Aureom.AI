//! sf-bench -- reproducible benchmark suite for the SilicaFlux CloudRuntime.
//!
//!   sf-bench run [--backend SPEC] [--out report.json] [--only NAME[,NAME]] [--quick] [--assume-clock-mhz F]
//!   sf-bench list
//!
//! RULES THIS SUITE FOLLOWS (see docs/07_BENCHMARKS.md)
//!   * Every benchmark verifies its output (byte-exact / CRC) before its numbers count; a wrong result fails the run.
//!   * Three kinds of number are never mixed:
//!       - `hardware_measurements`   : physical-device results.  ALWAYS EMPTY today: no hardware transport exists.
//!       - simulation results        : `device cycles` from the cycle-accurate RTL simulation (no clock frequency!)
//!                                     and `wall clock` of the software stack (for rtl-sim this is SIMULATION SPEED).
//!       - cpu_only_reference        : the same work done directly in software, on the host CPU, no runtime involved.
//!   * A device-cycle figure can be turned into MB/s only with an ASSUMED clock (`--assume-clock-mhz`); the result is
//!     placed under `assumed_clock_projection`, labelled as an assumption.  No clock has been closed in timing.
//!   * Workloads a backend cannot run are reported `unsupported` with the reason; power is `not_measurable`.
use aes_gcm::aead::generic_array::GenericArray;
use aes_gcm::aead::AeadInPlace;
use aes_gcm::{Aes256Gcm, KeyInit};
use sf_cloud::backend::{self, BackendSpec, TimingModel};
use sf_cloud::mediator::{alloc_flags as f, BufHandle, DeviceInfo, Mediator, MediatorOptions, Op, Session, TenantConfig, Ticket};
use sf_cloud::proto;
use sf_cloud::status::Status;
use std::collections::{HashMap, VecDeque};
use std::process::ExitCode;
use std::time::{Duration, Instant};

// ------------------------------------------------------------------------------------------------ JSON
#[derive(Clone, Debug)]
enum J {
    Null,
    B(bool),
    N(f64),
    S(String),
    A(Vec<J>),
    O(Vec<(String, J)>),
}
fn s(x: impl Into<String>) -> J {
    J::S(x.into())
}
fn n(x: impl Into<f64>) -> J {
    J::N(x.into())
}
fn o(items: Vec<(&str, J)>) -> J {
    J::O(items.into_iter().map(|(k, v)| (k.to_string(), v)).collect())
}
fn render(j: &J, out: &mut String, ind: usize) {
    let pad = |o: &mut String, k: usize| o.push_str(&"  ".repeat(k));
    match j {
        J::Null => out.push_str("null"),
        J::B(b) => out.push_str(if *b { "true" } else { "false" }),
        J::N(v) => {
            if v.is_finite() {
                if v.fract() == 0.0 && v.abs() < 9e15 {
                    out.push_str(&format!("{}", *v as i64))
                } else {
                    out.push_str(&format!("{v:.6}"))
                }
            } else {
                out.push_str("null")
            }
        }
        J::S(x) => {
            out.push('"');
            for c in x.chars() {
                match c {
                    '"' => out.push_str("\\\""),
                    '\\' => out.push_str("\\\\"),
                    '\n' => out.push_str("\\n"),
                    c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
                    c => out.push(c),
                }
            }
            out.push('"');
        }
        J::A(v) => {
            if v.is_empty() {
                out.push_str("[]");
                return;
            }
            out.push_str("[\n");
            for (i, x) in v.iter().enumerate() {
                pad(out, ind + 1);
                render(x, out, ind + 1);
                out.push_str(if i + 1 < v.len() { ",\n" } else { "\n" });
            }
            pad(out, ind);
            out.push(']');
        }
        J::O(v) => {
            if v.is_empty() {
                out.push_str("{}");
                return;
            }
            out.push_str("{\n");
            for (i, (k, x)) in v.iter().enumerate() {
                pad(out, ind + 1);
                out.push_str(&format!("\"{k}\": "));
                render(x, out, ind + 1);
                out.push_str(if i + 1 < v.len() { ",\n" } else { "\n" });
            }
            pad(out, ind);
            out.push('}');
        }
    }
}

// ------------------------------------------------------------------------------------------------ helpers
struct Ctx {
    m: Mediator,
    ss: Vec<Session>,
    info: DeviceInfo,
    quick: bool,
    has_cycles: bool,
    failures: Vec<String>,
    /// (benchmark, metric, bytes_per_device_cycle) for the optional clock projection
    projections: Vec<(String, String, f64)>,
}

fn pct(v: &mut Vec<f64>, p: f64) -> f64 {
    if v.is_empty() {
        return f64::NAN;
    }
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    v[(((v.len() - 1) as f64) * p).round() as usize]
}

fn data(seed: u64, len: usize) -> Vec<u8> {
    let mut x = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
    (0..len)
        .map(|_| {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            (x >> 24) as u8
        })
        .collect()
}

const W: Duration = Duration::from_secs(120);

fn unsupported(name: &str, info: &DeviceInfo, what: &str) -> J {
    o(vec![
        ("benchmark", s(name)),
        ("status", s("unsupported")),
        (
            "reason",
            s(format!(
                "backend '{}' does not implement '{what}' (blocks: {})",
                info.backend.name,
                info.blocks.iter().map(|(a, b)| format!("{a}={b}")).collect::<Vec<_>>().join(", ")
            )),
        ),
        ("correct", J::Null),
    ])
}

fn ok_result(name: &str, metrics: Vec<(&str, J)>, cpu_ref: Option<J>, sources: Vec<(&str, &str)>) -> J {
    let mut v = vec![
        ("benchmark", s(name)),
        ("status", s("ok")),
        ("correct", J::B(true)),
        ("metrics", o(metrics)),
        ("cpu_only_reference", cpu_ref.unwrap_or(J::Null)),
        ("measurement_sources", o(sources.into_iter().map(|(k, v)| (k, s(v))).collect())),
    ];
    v.shrink_to_fit();
    o(v)
}

impl Ctx {
    fn fail(&mut self, bench: &str, msg: String) {
        self.failures.push(format!("{bench}: {msg}"));
    }
    fn cycles(&self) -> u64 {
        self.m.device_cycles()
    }
    fn project(&mut self, bench: &str, metric: &str, bpc: f64) {
        self.projections.push((bench.into(), metric.into(), bpc));
    }
}

// ------------------------------------------------------------------------------------------------ benchmarks
/// Pipelined copy of `frames` buffers of `size` bytes with `depth` in flight.  Returns (wall secs, device cycles, ok).
fn pipelined_copies(c: &mut Ctx, tenant: usize, frames: &[Vec<u8>], depth: usize, bench: &str) -> (f64, u64, u64) {
    let s_ = &c.ss[tenant];
    let max = frames.iter().map(|f| f.len()).max().unwrap() as u64;
    let slots: Vec<(BufHandle, BufHandle)> = (0..depth).map(|_| (s_.alloc(max, f::DEV_READ).unwrap(), s_.alloc(max, f::DEV_WRITE).unwrap())).collect();
    let mut inflight: VecDeque<(usize, usize, Ticket)> = VecDeque::new();
    let (cy0, t0) = (c.cycles(), Instant::now());
    let mut bytes = 0u64;
    let mut bad = None;
    let verify = |idx: usize, slot: usize, t: Ticket, bad: &mut Option<String>| {
        let cpl = s_.wait(t, W);
        match cpl {
            Ok(cp) => {
                let fr = &frames[idx];
                if cp.status != Status::Ok || !cp.committed || cp.crc_out != Some(proto::crc32(fr)) {
                    *bad = Some(format!("frame {idx}: {cp:?}"));
                }
                if idx % 17 == 0 {
                    let mut out = vec![0u8; fr.len()];
                    s_.read(slots[slot].1, 0, &mut out).unwrap();
                    if &out != fr {
                        *bad = Some(format!("frame {idx}: output bytes differ"));
                    }
                }
            }
            Err(e) => *bad = Some(format!("frame {idx}: {e}")),
        }
    };
    for (i, fr) in frames.iter().enumerate() {
        if inflight.len() == depth {
            let (idx, slot, t) = inflight.pop_front().unwrap();
            verify(idx, slot, t, &mut bad);
        }
        let slot = i % depth;
        s_.write(slots[slot].0, 0, fr).unwrap();
        let t = s_.submit(&Op::Copy { src: slots[slot].0, src_off: 0, dst: slots[slot].1, dst_off: 0, len: fr.len() as u64 }).unwrap();
        bytes += fr.len() as u64;
        inflight.push_back((i, slot, t));
    }
    while let Some((idx, slot, t)) = inflight.pop_front() {
        verify(idx, slot, t, &mut bad);
    }
    let (wall, cyc) = (t0.elapsed().as_secs_f64(), c.cycles() - cy0);
    for (a, b) in slots {
        s_.free(a).unwrap();
        s_.free(b).unwrap();
    }
    if let Some(b) = bad {
        c.fail(bench, b);
    }
    (wall, cyc, bytes)
}

fn bench_packet(c: &mut Ctx) -> J {
    let name = "network_packet_throughput";
    if !c.info.backend.caps.pkt_process {
        return unsupported(name, &c.info, "pkt_process");
    }
    let per = if c.quick { 60 } else { 300 };
    let mut rows = vec![];
    let mut cpu_rows = vec![];
    for size in [64usize, 256, 1024, 1500] {
        let frames: Vec<Vec<u8>> = (0..per).map(|i| data(size as u64 * 1000 + i as u64, size)).collect();
        let (wall, cyc, bytes) = pipelined_copies(c, 0, &frames, 12, name);
        let mut row =
            vec![("frame_bytes", n(size as f64)), ("frames", n(per as f64)), ("wall_frames_per_s", n(per as f64 / wall)), ("wall_mb_per_s", n(bytes as f64 / wall / 1e6))];
        if c.has_cycles {
            let bpc = bytes as f64 / cyc as f64;
            row.push(("device_cycles", n(cyc as f64)));
            row.push(("device_cycles_per_frame", n(cyc as f64 / per as f64)));
            row.push(("bytes_per_device_cycle", n(bpc)));
            c.project(name, &format!("{size}B frames"), bpc);
        }
        rows.push(o(row));
        // CPU-only reference: the same work (copy + CRC-32 + RFC 1071 checksum) with no device and no runtime
        let t0 = Instant::now();
        let mut sink = 0u32;
        let mut out = vec![0u8; size];
        for fr in &frames {
            out.copy_from_slice(fr);
            sink ^= proto::crc32(&out) ^ proto::csum1071(&out) as u32;
        }
        std::hint::black_box(sink);
        let w = t0.elapsed().as_secs_f64();
        cpu_rows.push(o(vec![("frame_bytes", n(size as f64)), ("wall_frames_per_s", n(per as f64 / w)), ("wall_mb_per_s", n((per * size) as f64 / w / 1e6))]));
    }
    ok_result(
        name,
        vec![("by_frame_size", J::A(rows))],
        Some(o(vec![("what", s("memcpy + CRC-32 + RFC1071 checksum per frame, same host CPU, no runtime")), ("by_frame_size", J::A(cpu_rows))])),
        vec![
            ("wall_*", "host wall clock (std::time::Instant) of the whole software stack; for rtl-sim this is SIMULATION speed"),
            ("device_cycles*", "rtl-sim: Verilator cycle counter delta over the batch (pump granularity 128 cycles); cpu-ref: not available"),
        ],
    )
}

fn bench_dma(c: &mut Ctx) -> J {
    let name = "dma_bandwidth";
    if !c.info.backend.caps.dma {
        return unsupported(name, &c.info, "dma");
    }
    let reps = if c.quick { 20 } else { 100 };
    let s_ = c.ss[0].clone();
    let mut rows = vec![];
    let mut cpu_rows = vec![];
    for size in [256u64, 2048, 8192] {
        let (h_in, h_out, dev) = (s_.alloc(size, f::DEV_READ).unwrap(), s_.alloc(size, f::DEV_WRITE).unwrap(), s_.alloc(size, f::DEVICE).unwrap());
        let d = data(size, size as usize);
        s_.write(h_in, 0, &d).unwrap();
        let (cy0, t0) = (c.cycles(), Instant::now());
        let mut active = 0u64; // sum of the exact per-operation device latencies (operations run back to back, one at a time)
        for _ in 0..reps {
            let t = s_.submit(&Op::DmaH2d { src: h_in, src_off: 0, dst: dev, dst_off: 0, len: size }).unwrap();
            let a = s_.wait(t, W).unwrap();
            let t = s_.submit(&Op::DmaD2h { src: dev, src_off: 0, dst: h_out, dst_off: 0, len: size }).unwrap();
            let b = s_.wait(t, W).unwrap();
            if a.status != Status::Ok || b.status != Status::Ok || !b.committed {
                c.fail(name, format!("{size} B: {a:?} {b:?}"));
            }
            active += a.latency_cycles + b.latency_cycles;
        }
        let (wall, cyc) = (t0.elapsed().as_secs_f64(), c.cycles() - cy0);
        let mut out = vec![0u8; size as usize];
        s_.read(h_out, 0, &mut out).unwrap();
        if out != d {
            c.fail(name, format!("{size} B: round trip differs"));
        }
        let moved = (reps as u64 * size * 2) as f64; // host->device plus device->host
        let mut row = vec![("transfer_bytes", n(size as f64)), ("round_trips", n(reps as f64)), ("wall_mb_per_s", n(moved / wall / 1e6))];
        if c.has_cycles {
            let bpc = moved / active as f64;
            row.push(("device_cycles_active", n(active as f64)));
            row.push(("device_cycles_including_pump_rounding", n(cyc as f64)));
            row.push(("bytes_per_device_cycle", n(bpc)));
            c.project(name, &format!("{size}B H2D+D2H"), bpc);
        }
        rows.push(o(row));
        let t0 = Instant::now();
        let mut sink = vec![0u8; size as usize];
        let mut sink2 = vec![0u8; size as usize];
        for _ in 0..reps {
            sink.copy_from_slice(&d);
            sink2.copy_from_slice(&sink);
        }
        std::hint::black_box((&sink, &sink2));
        cpu_rows.push(o(vec![("transfer_bytes", n(size as f64)), ("wall_mb_per_s", n(moved / t0.elapsed().as_secs_f64() / 1e6))]));
        for h in [h_in, h_out, dev] {
            s_.free(h).unwrap();
        }
    }
    ok_result(
        name,
        vec![("by_transfer_size", J::A(rows))],
        Some(o(vec![("what", s("two memcpy of the same bytes, host CPU")), ("by_transfer_size", J::A(cpu_rows))])),
        vec![
            ("wall_*", "host wall clock of the software stack"),
            ("device_cycles_active", "rtl-sim: sum of exact per-operation latencies from the DPU cycle counter (operations are sequential, so no idle time is counted)"),
            ("bytes_per_device_cycle", "bytes moved (host->device + device->host) / device_cycles_active"),
        ],
    )
}

fn bench_copy_latency(c: &mut Ctx) -> J {
    let name = "memory_copy_latency";
    if !c.info.backend.caps.pkt_process {
        return unsupported(name, &c.info, "pkt_process");
    }
    let reps = if c.quick { 40 } else { 200 };
    let s_ = c.ss[0].clone();
    let mut rows = vec![];
    let mut cpu_rows = vec![];
    for size in [64u64, 256, 1024, 2048] {
        let (src, dst) = (s_.alloc(size, f::DEV_READ).unwrap(), s_.alloc(size, f::DEV_WRITE).unwrap());
        let d = data(size, size as usize);
        s_.write(src, 0, &d).unwrap();
        let (mut cyc, mut ns) = (vec![], vec![]);
        for _ in 0..reps {
            let t = s_.submit(&Op::Copy { src, src_off: 0, dst, dst_off: 0, len: size }).unwrap();
            let cp = s_.wait(t, W).unwrap();
            if cp.status != Status::Ok || !cp.committed || cp.crc_in != cp.crc_out {
                c.fail(name, format!("{size} B: {cp:?}"));
            }
            cyc.push(cp.latency_cycles as f64);
            ns.push(cp.latency_ns as f64);
        }
        let mut out = vec![0u8; size as usize];
        s_.read(dst, 0, &mut out).unwrap();
        if out != d {
            c.fail(name, format!("{size} B: copy differs"));
        }
        let mut row =
            vec![("bytes", n(size as f64)), ("samples", n(reps as f64)), ("wall_us_p50", n(pct(&mut ns.clone(), 0.5) / 1e3)), ("wall_us_p99", n(pct(&mut ns.clone(), 0.99) / 1e3))];
        if c.has_cycles {
            row.push(("device_cycles_p50", n(pct(&mut cyc.clone(), 0.5))));
            row.push(("device_cycles_p90", n(pct(&mut cyc.clone(), 0.9))));
            row.push(("device_cycles_p99", n(pct(&mut cyc.clone(), 0.99))));
            row.push(("device_cycles_max", n(pct(&mut cyc.clone(), 1.0))));
        }
        rows.push(o(row));
        let mut lat = vec![];
        let mut sink = vec![0u8; size as usize];
        for _ in 0..reps {
            let t0 = Instant::now();
            sink.copy_from_slice(&d);
            std::hint::black_box(proto::crc32(&sink));
            lat.push(t0.elapsed().as_nanos() as f64);
        }
        cpu_rows.push(o(vec![("bytes", n(size as f64)), ("wall_us_p50", n(pct(&mut lat.clone(), 0.5) / 1e3)), ("wall_us_p99", n(pct(&mut lat, 0.99) / 1e3))]));
        s_.free(src).unwrap();
        s_.free(dst).unwrap();
    }
    ok_result(name, vec![("note", s("single operation in flight; device-cycle latency = DPU cycle counter at completion minus the cycle of submission (exact: the DPU counter is calibrated through a simulation back door)")), ("by_size", J::A(rows))], Some(o(vec![("what", s("memcpy + CRC-32 of the same bytes, host CPU")), ("by_size", J::A(cpu_rows))])), vec![("device_cycles*", "rtl-sim: DPU cycle counter in the completion record minus the submission cycle (not quantised)"), ("wall_*", "host wall clock including software stack overhead")])
}

fn bench_tensor(c: &mut Ctx) -> J {
    let name = "tensor_throughput";
    if !c.info.backend.caps.gemm_i8 {
        return unsupported(name, &c.info, "gemm_i8");
    }
    let reps = if c.quick { 30 } else { 200 };
    let s_ = c.ss[0].clone();
    let dim = 64usize;
    let (a8, b8) = (data(1, dim * dim), data(2, dim * dim));
    let (ha, hb, hc) =
        (s_.alloc((dim * dim) as u64, f::DEV_READ).unwrap(), s_.alloc((dim * dim) as u64, f::DEV_READ).unwrap(), s_.alloc((dim * dim * 4) as u64, f::DEV_WRITE).unwrap());
    s_.write(ha, 0, &a8).unwrap();
    s_.write(hb, 0, &b8).unwrap();
    let t0 = Instant::now();
    for _ in 0..reps {
        let t = s_.submit(&Op::GemmI8 { a: ha, a_off: 0, b: hb, b_off: 0, c: hc, c_off: 0, m: dim as u32, n: dim as u32, k: dim as u32 }).unwrap();
        let cp = s_.wait(t, W).unwrap();
        if cp.status != Status::Ok {
            c.fail(name, format!("{cp:?}"));
        }
    }
    let wall = t0.elapsed().as_secs_f64();
    let mut got = vec![0u8; dim * dim * 4];
    s_.read(hc, 0, &mut got).unwrap();
    let gemm = |a: &[u8], b: &[u8]| -> Vec<i32> {
        let mut o = vec![0i32; dim * dim];
        for i in 0..dim {
            for k in 0..dim {
                let av = a[i * dim + k] as i8 as i32;
                for j in 0..dim {
                    o[i * dim + j] += av * b[k * dim + j] as i8 as i32;
                }
            }
        }
        o
    };
    let want = gemm(&a8, &b8);
    if got.chunks(4).map(|b| i32::from_le_bytes(b.try_into().unwrap())).collect::<Vec<_>>() != want {
        c.fail(name, "GEMM result differs from the reference".into());
    }
    let macs = (dim * dim * dim) as f64 * reps as f64;
    let t0 = Instant::now();
    for _ in 0..reps {
        std::hint::black_box(gemm(&a8, &b8));
    }
    let w2 = t0.elapsed().as_secs_f64();
    ok_result(
        name,
        vec![("shape", s("64x64x64 INT8 -> INT32")), ("reps", n(reps as f64)), ("wall_gmac_per_s", n(macs / wall / 1e9)), ("wall_ops_per_s", n(reps as f64 / wall))],
        Some(o(vec![("what", s("direct i8 GEMM loop, same host CPU, no runtime")), ("wall_gmac_per_s", n(macs / w2 / 1e9))])),
        vec![("wall_*", "host wall clock; the GEMM executes in SOFTWARE inside the cpu-ref backend (the RTL blocks its tensor engine)")],
    )
}

fn bench_crypto(c: &mut Ctx) -> J {
    let name = "crypto_throughput";
    if !c.info.backend.caps.aes_gcm {
        return unsupported(name, &c.info, "aes_gcm");
    }
    let reps = if c.quick { 200 } else { 1500 };
    let s_ = c.ss[0].clone();
    let size = 1024usize;
    let key = [0x42u8; 32];
    let k = s_.load_key(&key).unwrap();
    let (hp, hc, ht) = (s_.alloc(size as u64, f::DEV_READ).unwrap(), s_.alloc(size as u64, f::DEV_WRITE).unwrap(), s_.alloc(16, f::DEV_WRITE).unwrap());
    let pt = data(9, size);
    s_.write(hp, 0, &pt).unwrap();
    let t0 = Instant::now();
    let mut iv = [0u8; 12];
    for i in 0..reps {
        iv[..8].copy_from_slice(&(i as u64).to_le_bytes());
        let t = s_.submit(&Op::AesGcm { key: k, encrypt: true, iv, aad: vec![], src: hp, src_off: 0, dst: hc, dst_off: 0, tag: ht, tag_off: 0, len: size as u32 }).unwrap();
        if s_.wait(t, W).unwrap().status != Status::Ok {
            c.fail(name, "encrypt failed".into());
        }
    }
    let wall = t0.elapsed().as_secs_f64();
    // correctness: the last record matches a direct computation
    let (mut ct, mut tag) = (vec![0u8; size], vec![0u8; 16]);
    s_.read(hc, 0, &mut ct).unwrap();
    s_.read(ht, 0, &mut tag).unwrap();
    let mut want = pt.clone();
    let wt = Aes256Gcm::new(GenericArray::from_slice(&key)).encrypt_in_place_detached(GenericArray::from_slice(&iv), &[], &mut want).unwrap();
    if want != ct || wt.as_slice() != &tag[..] {
        c.fail(name, "ciphertext/tag differ from a direct computation".into());
    }
    let cipher = Aes256Gcm::new(GenericArray::from_slice(&key));
    let t0 = Instant::now();
    let mut buf = pt.clone();
    for i in 0..reps {
        buf.copy_from_slice(&pt);
        iv[..8].copy_from_slice(&(i as u64).to_le_bytes());
        std::hint::black_box(cipher.encrypt_in_place_detached(GenericArray::from_slice(&iv), &[], &mut buf).unwrap());
    }
    let w2 = t0.elapsed().as_secs_f64();
    let bytes = (reps * size) as f64;
    ok_result(
        name,
        vec![("record_bytes", n(size as f64)), ("records", n(reps as f64)), ("wall_mb_per_s", n(bytes / wall / 1e6)), ("wall_records_per_s", n(reps as f64 / wall))],
        Some(o(vec![("what", s("direct aes-gcm crate call, AES-256-GCM, same host CPU")), ("wall_mb_per_s", n(bytes / w2 / 1e6))])),
        vec![("wall_*", "host wall clock; AES-GCM executes in SOFTWARE in the cpu-ref backend (the RTL has no CryptoCore)")],
    )
}

fn bench_storage(c: &mut Ctx) -> J {
    let name = "storage_iops";
    if !c.info.backend.caps.storage {
        return unsupported(name, &c.info, "storage");
    }
    let reps = if c.quick { 400 } else { 3000 };
    let s_ = c.ss[0].clone();
    let blocks = 8u32; // 4 KiB I/O
    let (hw, hr) = (s_.alloc(4096, f::DEV_READ).unwrap(), s_.alloc(4096, f::DEV_WRITE).unwrap());
    let mut x = 0x1234_5678_9ABCu64;
    let mut rnd = move || {
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        x
    };
    let mut ops: Vec<(bool, u64, Vec<u8>)> = vec![];
    for i in 0..reps {
        let write = rnd() % 100 < 30;
        let lba = rnd() % 1000;
        ops.push((write, lba, if write { data(i as u64 + 7, 4096) } else { vec![] }));
    }
    let mut shadow: HashMap<u64, Vec<u8>> = HashMap::new();
    let t0 = Instant::now();
    let mut bad = 0;
    for (write, lba, d) in &ops {
        if *write {
            s_.write(hw, 0, d).unwrap();
            let t = s_.submit(&Op::StorageWrite { src: hw, src_off: 0, lba: *lba, blocks }).unwrap();
            if s_.wait(t, W).unwrap().status != Status::Ok {
                bad += 1;
            }
            for b in 0..blocks as u64 {
                shadow.insert(lba + b, d[(b * 512) as usize..(b * 512 + 512) as usize].to_vec());
            }
        } else {
            let t = s_.submit(&Op::StorageRead { dst: hr, dst_off: 0, lba: *lba, blocks }).unwrap();
            if s_.wait(t, W).unwrap().status != Status::Ok {
                bad += 1;
            }
            let mut out = vec![0u8; 4096];
            s_.read(hr, 0, &mut out).unwrap();
            for b in 0..blocks as u64 {
                let want = shadow.get(&(lba + b)).cloned().unwrap_or_else(|| vec![0u8; 512]);
                if out[(b * 512) as usize..(b * 512 + 512) as usize] != want[..] {
                    bad += 1;
                }
            }
        }
    }
    let wall = t0.elapsed().as_secs_f64();
    if bad > 0 {
        c.fail(name, format!("{bad} mismatching operations"));
    }
    let mut base: HashMap<u64, Box<[u8; 512]>> = HashMap::new();
    let t0 = Instant::now();
    for (write, lba, d) in &ops {
        if *write {
            for b in 0..blocks as u64 {
                let mut blk = Box::new([0u8; 512]);
                blk.copy_from_slice(&d[(b * 512) as usize..(b * 512 + 512) as usize]);
                base.insert(lba + b, blk);
            }
        } else {
            let mut out = vec![0u8; 4096];
            for b in 0..blocks as u64 {
                if let Some(x) = base.get(&(lba + b)) {
                    out[(b * 512) as usize..(b * 512 + 512) as usize].copy_from_slice(&x[..]);
                }
            }
            std::hint::black_box(&out);
        }
    }
    let w2 = t0.elapsed().as_secs_f64();
    ok_result(
        name,
        vec![("io_bytes", n(4096.0)), ("mix", s("70% read / 30% write, random LBA in [0,1000)")), ("ops", n(reps as f64)), ("wall_iops", n(reps as f64 / wall))],
        Some(o(vec![("what", s("in-memory HashMap block store, same op sequence, host CPU")), ("wall_iops", n(reps as f64 / w2))])),
        vec![("wall_*", "host wall clock; the block store is a SOFTWARE model in cpu-ref (StorageFabric does not exist in the repository)")],
    )
}

fn bench_contention(c: &mut Ctx) -> J {
    let name = "multi_tenant_contention";
    if c.ss.len() < 2 || !c.info.backend.caps.pkt_process {
        return o(vec![("benchmark", s(name)), ("status", s("unsupported")), ("reason", s("needs >= 2 tenants and pkt_process")), ("correct", J::Null)]);
    }
    if !c.has_cycles {
        return o(vec![
            ("benchmark", s(name)),
            ("status", s("not_measurable")),
            ("reason", s(format!("backend '{}' has no timing model, so contention in device cycles does not exist; measured only on rtl-sim", c.info.backend.name))),
            ("correct", J::Null),
        ]);
    }
    let k = if c.quick { 24 } else { 64 };
    let size = 2048u64;
    let run = |c: &mut Ctx, tenants: &[usize]| -> (u64, Vec<f64>, Vec<u64>) {
        let ss: Vec<Session> = tenants.iter().map(|&t| c.ss[t].clone()).collect();
        let bufs: Vec<(BufHandle, Vec<BufHandle>)> = ss
            .iter()
            .map(|s_| {
                let src = s_.alloc(size, f::DEV_READ).unwrap();
                s_.write(src, 0, &data(5, size as usize)).unwrap();
                (src, (0..k).map(|_| s_.alloc(size, f::DEV_WRITE).unwrap()).collect())
            })
            .collect();
        let cy0 = c.cycles();
        let mut tix: Vec<Vec<Ticket>> = vec![vec![]; ss.len()];
        for i in 0..k {
            for (ti, s_) in ss.iter().enumerate() {
                tix[ti].push(s_.submit(&Op::Copy { src: bufs[ti].0, src_off: 0, dst: bufs[ti].1[i], dst_off: 0, len: size }).unwrap());
            }
        }
        let mut finish = vec![0u64; ss.len()];
        let mut lat = vec![0f64; ss.len()];
        for (ti, s_) in ss.iter().enumerate() {
            for t in tix[ti].drain(..) {
                let cp = s_.wait(t, W).unwrap();
                if cp.status != Status::Ok {
                    c.failures.push(format!("{name}: {cp:?}"));
                }
                lat[ti] += cp.latency_cycles as f64;
                finish[ti] = c.cycles() - cy0;
            }
            lat[ti] /= k as f64;
        }
        let total = c.cycles() - cy0;
        for (ti, s_) in ss.iter().enumerate() {
            s_.free(bufs[ti].0).unwrap();
            for b in &bufs[ti].1 {
                s_.free(*b).unwrap();
            }
        }
        (total, lat, finish)
    };
    let (solo, solo_lat, _) = run(c, &[0]);
    let (both, both_lat, finish) = run(c, &[0, 1]);
    let bytes_each = (k as u64 * size) as f64;
    let thr: Vec<f64> = finish.iter().map(|&f| bytes_each / f as f64).collect();
    let jain = {
        let sm: f64 = thr.iter().sum();
        let q: f64 = thr.iter().map(|x| x * x).sum();
        sm * sm / (thr.len() as f64 * q)
    };
    c.project(name, "2 tenants aggregate", 2.0 * bytes_each / both as f64);
    ok_result(
        name,
        vec![
            ("ops_per_tenant", n(k as f64)),
            ("op_bytes", n(size as f64)),
            ("solo_device_cycles", n(solo as f64)),
            ("two_tenants_device_cycles", n(both as f64)),
            ("slowdown_vs_ideal_parallel", n(both as f64 / solo as f64)),
            ("slowdown_vs_serial", n(both as f64 / (2.0 * solo as f64))),
            ("solo_mean_latency_cycles", n(solo_lat[0])),
            ("tenant_mean_latency_cycles", J::A(both_lat.iter().map(|x| n(*x)).collect())),
            ("tenant_bytes_per_cycle", J::A(thr.iter().map(|x| n(*x)).collect())),
            ("jain_fairness_throughput", n(jain)),
            (
                "interpretation",
                s("slowdown_vs_ideal_parallel = 1.0 means the second tenant is free; 2.0 means fully serialised (the host-memory port or fabric is the shared bottleneck)"),
            ),
        ],
        None,
        vec![("device_cycles*", "rtl-sim cycle counter; single-threaded submission of all work before any wait, so the tenants genuinely overlap inside the device")],
    )
}

fn bench_alloc(c: &mut Ctx) -> J {
    let name = "resource_allocation_overhead";
    let reps = if c.quick { 500 } else { 3000 };
    let s_ = c.ss[0].clone();
    let mut ns = vec![];
    for _ in 0..reps {
        let t0 = Instant::now();
        let b = s_.alloc(64, f::DEV_WRITE).unwrap();
        s_.free(b).unwrap();
        ns.push(t0.elapsed().as_nanos() as f64);
    }
    let mut nop = vec![];
    let mut nop_cy = vec![];
    for _ in 0..(if c.quick { 100 } else { 500 }) {
        let t0 = Instant::now();
        let t = s_.submit(&Op::Nop).unwrap();
        let cp = s_.wait(t, W).unwrap();
        if cp.status != Status::Ok {
            c.fail(name, format!("NOP: {cp:?}"));
        }
        nop.push(t0.elapsed().as_nanos() as f64);
        nop_cy.push(cp.latency_cycles as f64);
    }
    // tenant provisioning cost (includes the hardware scrub of the SRAM partition)
    let last = c.info.geometry.tenants - 1;
    let spare = c.m.deprovision_tenant(last).map(|_| ());
    let (mut prov_wall, mut prov_cy) = (f64::NAN, 0u64);
    if spare.is_ok() {
        let (cy0, t0) = (c.cycles(), Instant::now());
        let cred = c.m.provision_tenant(last, TenantConfig::default());
        prov_wall = t0.elapsed().as_secs_f64() * 1e3;
        prov_cy = c.cycles() - cy0;
        match cred {
            Ok(cr) => c.ss[last as usize] = c.m.open_session(last, &cr).unwrap(),
            Err(e) => c.fail(name, format!("re-provisioning: {e}")),
        }
    }
    let mut metrics = vec![
        ("alloc_free_pair_ns_p50", n(pct(&mut ns.clone(), 0.5))),
        ("alloc_free_pair_ns_p99", n(pct(&mut ns, 0.99))),
        ("nop_roundtrip_wall_us_p50", n(pct(&mut nop.clone(), 0.5) / 1e3)),
        ("nop_roundtrip_wall_us_p99", n(pct(&mut nop, 0.99) / 1e3)),
        ("tenant_provision_wall_ms", n(prov_wall)),
    ];
    if c.has_cycles {
        metrics.push(("nop_completion_created_device_cycles_p50", n(pct(&mut nop_cy, 0.5))));
        metrics.push(("nop_latency_definition", s("DPU timestamp of completion-record creation minus the cycle of submission. Verified at harness level: the record is created 1 cycle after the descriptor is accepted and becomes host-visible ~2 cycles later (completion FIFO), so add ~2 cycles for delivery. Negligible for data-moving operations.")));
        metrics.push(("tenant_provision_device_cycles", n(prov_cy as f64)));
    }
    ok_result(
        name,
        metrics,
        None,
        vec![
            ("*_ns/_us/_ms", "host wall clock (software overhead of the runtime/mediator; alloc/free never touches the device except to scrub host memory)"),
            ("*_device_cycles*", "rtl-sim; provisioning includes the hardware scrub of the SRAM partition"),
        ],
    )
}

fn bench_power(c: &mut Ctx) -> J {
    let _ = c;
    o(vec![
        ("benchmark", s("power_efficiency")),
        ("status", s("not_measurable")),
        ("reason", s("No power or thermal telemetry exists for the CloudDPU (PowerClock, Project 27, is not integrated), a simulation has no power model, and no hardware has been run. Energy per byte can only be measured on hardware with an external meter. No figure is reported or estimated.")),
        ("correct", J::Null),
    ])
}

// ------------------------------------------------------------------------------------------------ metadata
fn cmd(c: &str, args: &[&str]) -> String {
    std::process::Command::new(c)
        .args(args)
        .output()
        .ok()
        .filter(|o| o.status.success())
        .map(|o| String::from_utf8_lossy(&o.stdout).lines().next().unwrap_or("").trim().to_string())
        .unwrap_or_else(|| "unavailable".into())
}

fn arg(a: &[String], k: &str) -> Option<String> {
    a.iter().position(|x| x == k).and_then(|i| a.get(i + 1)).cloned()
}

fn manifest_hash() -> J {
    // MANIFEST.sha256 sits at the package root (written by scripts/package.sh); hash the manifest itself
    let mut d = std::env::current_dir().ok();
    for _ in 0..6 {
        if let Some(dir) = d.clone() {
            let p = dir.join("MANIFEST.sha256");
            if p.is_file() {
                let out = cmd("sha256sum", &[p.to_str().unwrap()]);
                return s(format!("{} ({})", out.split_whitespace().next().unwrap_or("?"), p.display()));
            }
            d = dir.parent().map(|x| x.to_path_buf());
        }
    }
    s("none (not a release package; see git revision)")
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    const NAMES: [&str; 9] = [
        "network_packet_throughput",
        "dma_bandwidth",
        "memory_copy_latency",
        "tensor_throughput",
        "crypto_throughput",
        "storage_iops",
        "multi_tenant_contention",
        "resource_allocation_overhead",
        "power_efficiency",
    ];
    match args.first().map(|x| x.as_str()) {
        Some("list") => {
            NAMES.iter().for_each(|n| println!("{n}"));
            return ExitCode::SUCCESS;
        }
        Some("run") => {}
        _ => {
            eprintln!("usage: sf-bench run [--backend SPEC] [--out FILE] [--only a,b] [--quick] [--assume-clock-mhz F] | list");
            return ExitCode::from(2);
        }
    }
    let spec = arg(&args, "--backend").unwrap_or_else(|| "auto".into());
    let quick = args.iter().any(|a| a == "--quick");
    let only: Option<Vec<String>> = arg(&args, "--only").map(|v| v.split(',').map(|x| x.to_string()).collect());
    let assume: Option<f64> = arg(&args, "--assume-clock-mhz").and_then(|v| v.parse().ok());
    let be = match BackendSpec::parse(&spec).and_then(|sp| backend::open_backend(&sp)) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("cannot open backend '{spec}': {e}");
            return ExitCode::from(2);
        }
    };
    let m = Mediator::open(be, MediatorOptions { cycle_budget: 200_000_000, ..Default::default() }).expect("open mediator");
    let info = m.info();
    let mut ss = vec![];
    for t in 0..info.geometry.tenants.min(2) {
        let cred = m.provision_tenant(t, TenantConfig { max_inflight: 256, max_buffers: 512, ..Default::default() }).expect("provision");
        ss.push(m.open_session(t, &cred).unwrap());
    }
    let has_cycles = info.backend.timing != TimingModel::None;
    let mut c = Ctx { m, ss, info: info.clone(), quick, has_cycles, failures: vec![], projections: vec![] };
    eprintln!("sf-bench: backend {} ({}), quick={quick}", info.backend.name, info.backend.timing.as_str());

    let mut results = vec![];
    for name in NAMES {
        if only.as_ref().is_some_and(|o| !o.iter().any(|x| x == name)) {
            continue;
        }
        eprint!("  {name} ... ");
        let t0 = Instant::now();
        let r = match name {
            "network_packet_throughput" => bench_packet(&mut c),
            "dma_bandwidth" => bench_dma(&mut c),
            "memory_copy_latency" => bench_copy_latency(&mut c),
            "tensor_throughput" => bench_tensor(&mut c),
            "crypto_throughput" => bench_crypto(&mut c),
            "storage_iops" => bench_storage(&mut c),
            "multi_tenant_contention" => bench_contention(&mut c),
            "resource_allocation_overhead" => bench_alloc(&mut c),
            _ => bench_power(&mut c),
        };
        eprintln!("done ({:.1}s)", t0.elapsed().as_secs_f64());
        results.push(r);
    }
    let rep = c.m.shutdown();
    if let Err(e) = rep {
        c.failures.push(format!("shutdown: {e}"));
    }

    // ---- assumed clock projection (never mixed with measurements)
    let projection = match (assume, c.has_cycles) {
        (Some(mhz), true) => o(vec![
            ("WARNING", s("ILLUSTRATIVE ONLY. The clock below is an ASSUMPTION supplied on the command line. No clock has been closed in timing on any implementation of this design (generic Yosys synthesis only; FPGA place-and-route reached 20-28 MHz on reduced configurations in the upstream projects). Do not quote these as device performance.")),
            ("assumed_clock_mhz", n(mhz)),
            ("projected_mb_per_s", J::A(c.projections.iter().map(|(b, m, bpc)| o(vec![("benchmark", s(b)), ("case", s(m)), ("bytes_per_device_cycle", n(*bpc)), ("mb_per_s_at_assumed_clock", n(bpc * mhz))])).collect())),
        ]),
        (Some(_), false) => s("not applicable: this backend has no cycle timing"),
        _ => J::Null,
    };
    let geo = &info.geometry;
    let git_dirty = env!("SF_GIT_DIRTY");
    let report = o(vec![
        ("schema", s("silicaflux-cloud-bench/1")),
        ("metadata", o(vec![
            ("generated_unix_time", n(std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0) as f64)),
            ("git", o(vec![("revision", s(env!("SF_GIT_REV"))), ("dirty", s(git_dirty)), ("note", s("recorded at BUILD time of sf-bench"))])),
            ("source_manifest_sha256", manifest_hash()),
            ("runtime_version", s(sf_cloud::RUNTIME_VERSION)),
            ("c_abi", s(format!("{}.{}", sf_cloud::ABI_MAJOR, sf_cloud::ABI_MINOR))),
            ("firmware_version", s("none loaded: the ControlCore idles in its boot ROM; the host drives the DPU register pages directly")),
            ("rtl_version", s(if info.backend.kind == backend::BackendKind::RtlSim { sf_cloud::DPU_RTL_VERSION } else { "n/a (cpu-ref is a software model of the contract)" })),
            ("dpu_abi", s(format!("{}.{}", geo.abi_major, geo.abi_minor))),
            ("toolchain", o(vec![("rustc", s(env!("SF_RUSTC"))), ("gcc", s(cmd("gcc", &["--version"]))), ("verilator", s(info.backend.details.iter().find(|(k, _)| k == "verilator").map(|(_, v)| v.clone()).unwrap_or_else(|| "n/a".into()))), ("os", s(cmd("uname", &["-srm"]))), ("cpu", s(std::fs::read_to_string("/proc/cpuinfo").ok().and_then(|t| t.lines().find(|l| l.starts_with("model name")).map(|l| l.split(':').nth(1).unwrap_or("").trim().to_string())).unwrap_or_else(|| "unknown".into())))])),
            ("device_backend", o(vec![("name", s(&info.backend.name)), ("kind", s(info.backend.kind.as_str())), ("description", s(&info.backend.description)), ("timing_model", s(info.backend.timing.as_str())), ("measured_on_hardware", J::B(info.backend.measured_on_hardware)), ("details", o(info.backend.details.iter().map(|(k, v)| (k.as_str(), s(v))).collect()))])),
            ("hardware_configuration", o(vec![("tenants", n(geo.tenants)), ("network_queues", n(geo.net_queues)), ("compute_queues", n(geo.compute_queues)), ("dma_channels", n(geo.dma_channels)), ("data_width_bits", n(geo.data_width)), ("address_width_bits", n(geo.address_width)), ("sram_bytes", n(geo.sram_bytes)), ("max_transfer_bytes", n(geo.max_xfer)), ("blocks", o(info.blocks.iter().map(|(k, v)| (*k, s(*v))).collect()))])),
            ("dataset", s("synthetic, deterministic: xorshift64 byte streams seeded per benchmark/size (seed = size*1000+index for frames; fixed seeds elsewhere); frame sizes 64/256/1024/1500 B; no external data")),
            ("parameters", o(vec![("backend_spec", s(&spec)), ("quick", J::B(quick)), ("pipeline_depth", n(12)), ("chunk_bytes", n(2048)), ("assume_clock_mhz", assume.map(n).unwrap_or(J::Null))])),
            ("clock", o(vec![("device_clock", s("none: a simulated RTL has no clock frequency; 'device cycles' are simulation cycles")), ("host_clock", s("monotonic wall clock (std::time::Instant) on the machine named under toolchain.cpu")), ("pump_granularity_cycles", n(128)), ("latency_timestamps", s("completion latencies use the DPU cycle counter in the completion record (exact); batch throughput uses the cycle-counter delta over the batch (error < one 128-cycle pump step per batch)"))])),
        ])),
        ("correctness", o(vec![("all_verified", J::B(c.failures.is_empty())), ("failures", J::A(c.failures.iter().map(s).collect())), ("note", s("every benchmark checks its output byte-for-byte or by CRC against an independent software computation before its numbers are reported"))])),
        ("hardware_measurements", J::A(vec![])),
        ("hardware_measurements_note", s("EMPTY: no physical SilicaFlux device has been run.  Everything below is simulation or software-model output.")),
        ("results", J::A(results)),
        ("assumed_clock_projection", projection),
    ]);
    let mut text = String::new();
    render(&report, &mut text, 0);
    text.push('\n');
    match arg(&args, "--out") {
        Some(p) => {
            std::fs::write(&p, &text).expect("write report");
            eprintln!("sf-bench: wrote {p}");
        }
        None => print!("{text}"),
    }
    if c.failures.is_empty() {
        ExitCode::SUCCESS
    } else {
        eprintln!("sf-bench: CORRECTNESS FAILURES:");
        c.failures.iter().for_each(|f| eprintln!("  - {f}"));
        ExitCode::from(1)
    }
}
