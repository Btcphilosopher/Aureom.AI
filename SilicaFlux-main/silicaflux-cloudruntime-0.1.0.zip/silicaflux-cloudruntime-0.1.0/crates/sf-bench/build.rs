// Records build-time provenance for benchmark reports: git revision (if this is a git checkout) and the compiler.
use std::process::Command;
fn run(cmd: &str, args: &[&str]) -> Option<String> {
    let o = Command::new(cmd).args(args).output().ok()?;
    if o.status.success() {
        Some(String::from_utf8_lossy(&o.stdout).trim().to_string())
    } else {
        None
    }
}
fn main() {
    let rev = run("git", &["rev-parse", "HEAD"]).unwrap_or_else(|| "unknown (not built from a git checkout)".into());
    let dirty = run("git", &["status", "--porcelain", "--", "."]).map(|s| !s.is_empty());
    println!("cargo:rustc-env=SF_GIT_REV={rev}");
    println!(
        "cargo:rustc-env=SF_GIT_DIRTY={}",
        match dirty {
            Some(true) => "true",
            Some(false) => "false",
            None => "unknown",
        }
    );
    println!("cargo:rustc-env=SF_RUSTC={}", run(&std::env::var("RUSTC").unwrap_or_else(|_| "rustc".into()), &["--version"]).unwrap_or_else(|| "unknown".into()));
    println!("cargo:rerun-if-changed=build.rs");
}
