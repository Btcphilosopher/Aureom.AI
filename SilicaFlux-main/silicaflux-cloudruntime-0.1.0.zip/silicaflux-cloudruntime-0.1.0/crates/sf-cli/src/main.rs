//! `sfctl` -- discover, inspect and exercise a SilicaFlux CloudDPU.
//!
//!   sfctl discover
//!   sfctl info    [--backend SPEC]
//!   sfctl slice   [--backend SPEC] [--bytes N]     the end-to-end vertical slice, narrated; exit 0 iff correct
//!   sfctl metrics [--backend SPEC]                 Prometheus text after a small self-load
//!   sfctl cdi     --devices a,b [--kind K] [--out FILE]   generate a CDI spec
//!
//! SPEC: auto | cpu-ref[:opt=v] | rtl-sim[:cfg=mt|min|mt4,seed=N,lat=N] | hw (not implemented)
use sf_cloud::backend::{self, BackendSpec};
use sf_cloud::container::{cdi_spec, k8s_device_id, CdiDevice, ENV_VISIBLE, RESOURCE_SIM};
use sf_cloud::mediator::{alloc_flags as f, Mediator, MediatorOptions, Op, TenantConfig};
use sf_cloud::proto;
use sf_cloud::status::Status;
use sf_cloud::telemetry;
use std::process::ExitCode;
use std::time::Duration;

fn arg(args: &[String], name: &str) -> Option<String> {
    args.iter().position(|a| a == name).and_then(|i| args.get(i + 1)).cloned()
}

fn open(spec: &str) -> Result<Mediator, String> {
    let be = backend::open_backend(&BackendSpec::parse(spec).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    Mediator::open(be, MediatorOptions::default()).map_err(|e| e.to_string())
}

fn cmd_discover() -> ExitCode {
    println!("{:<14} {:<8} {:<9} DESCRIPTION / REASON", "ID", "KIND", "AVAILABLE");
    for d in backend::discover_all() {
        println!("{:<14} {:<8} {:<9} {}\n{:<33}{}", d.id, d.kind.as_str(), if d.available { "yes" } else { "no" }, d.description, "", d.reason);
    }
    println!("\nNote: no physical SilicaFlux hardware transport exists; 'hw' entries are never available.");
    ExitCode::SUCCESS
}

fn cmd_info(spec: &str) -> ExitCode {
    let m = match open(spec) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("error: {e}");
            return ExitCode::from(2);
        }
    };
    let i = m.info();
    let (b, g) = (&i.backend, &i.geometry);
    println!("backend      : {} ({})", b.name, b.kind.as_str());
    println!("description  : {}", b.description);
    println!("timing       : {}", b.timing.as_str());
    println!("measured on hardware: {}", b.measured_on_hardware);
    for (k, v) in &b.details {
        println!("  {k:<14}: {v}");
    }
    println!("runtime      : {}  (C ABI {}.{})", i.runtime_version, i.abi_version.0, i.abi_version.1);
    println!("device ABI   : {}.{}   firmware: none loaded (ControlCore idles in boot ROM; host drives the register pages)", g.abi_major, g.abi_minor);
    println!(
        "geometry     : {} tenants, {} network + {} compute queues, {} DMA channel(s), {}-bit data / {}-bit address, {} windows/tenant, {} B SRAM, max transfer {} B",
        g.tenants, g.net_queues, g.compute_queues, g.dma_channels, g.data_width, g.address_width, g.windows, g.sram_bytes, g.max_xfer
    );
    println!("blocks       : {}", i.blocks.iter().map(|(n, s)| format!("{n}={s}")).collect::<Vec<_>>().join("  "));
    let c = b.caps;
    println!(
        "capabilities : nop={} dma={} pkt_process={} gemm_i8={} aes_gcm={} storage={} telemetry={}",
        c.nop, c.dma, c.pkt_process, c.gemm_i8, c.aes_gcm, c.storage, c.telemetry
    );
    println!("health       : {} {:?}", m.health().name(), m.health().reasons());
    ExitCode::SUCCESS
}

fn step(n: u32, s: &str) {
    println!("[{n}] {s}");
}

fn cmd_slice(spec: &str, bytes: usize) -> ExitCode {
    println!("== SilicaFlux vertical slice: discovery -> secure buffer -> DMA -> accelerator op -> completion -> telemetry ==");
    step(1, "device discovery");
    for d in backend::discover() {
        println!("      {:<12} {:<8} available={:<5} {}", d.id, d.kind.as_str(), d.available, d.reason);
    }
    let m = match open(spec) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("FAIL: cannot open '{spec}': {e}");
            return ExitCode::from(2);
        }
    };
    let info = m.info();
    println!("      opened: {} -- {}", info.backend.name, info.backend.description);
    println!(
        "      geometry read from the DPU registers: {} tenants, {} queues, SRAM {} B, blocks: {}",
        info.geometry.tenants,
        info.geometry.net_queues,
        info.geometry.sram_bytes,
        info.blocks.iter().map(|(n, s)| format!("{n}={s}")).collect::<Vec<_>>().join(",")
    );
    let cred = match m.provision_tenant(0, TenantConfig::default()) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("FAIL: provisioning: {e}");
            return ExitCode::from(2);
        }
    };
    let s = m.open_session(0, &cred).unwrap();
    let (iw, ow) = m.tenant_windows(0).unwrap();
    step(
        2,
        &format!("secure buffer allocation (tenant 0: SRAM partition {:?}, host windows: R {:#x}+{:#x}, RW {:#x}+{:#x})", m.tenant_partition(0).unwrap(), iw.0, iw.1, ow.0, ow.1),
    );
    let mut input = vec![0u8; bytes];
    let mut x = 0x9E37_79B9_7F4A_7C15u64;
    for b in input.iter_mut() {
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        *b = (x >> 24) as u8;
    }
    let (src, dst) = match (s.alloc(bytes as u64, f::DEV_READ), s.alloc(bytes as u64, f::DEV_WRITE)) {
        (Ok(a), Ok(b)) => (a, b),
        (Err(e), _) | (_, Err(e)) => {
            eprintln!("FAIL: alloc: {e}");
            return ExitCode::from(1);
        }
    };
    s.write(src, 0, &input).unwrap();
    println!("      src: DEV_READ buffer (device cannot write it); dst: DEV_WRITE buffer; handles carry epoch+generation");
    step(
        3,
        &format!(
            "DMA + accelerator operation: host src -> device SRAM -> PacketCore ({}) -> device SRAM -> host dst, {bytes} bytes",
            if info.backend.caps.pkt_process { "TEST ADAPTER: XOR32" } else { "n/a" }
        ),
    );
    let param = 0xA5A5_5A5Au32;
    let t = match s.submit(&Op::PktProcess { src, src_off: 0, dst, dst_off: 0, len: bytes as u64, proc_op: proto::proc_op::XOR32, param }) {
        Ok(t) => t,
        Err(e) => {
            eprintln!("FAIL: submit: {e}");
            return ExitCode::from(1);
        }
    };
    println!(
        "      ticket {:#x}; src/dst are now pinned (free() would return SF_ERR_BUSY: {})",
        t.0,
        s.free(dst).map(|_| "NOT PINNED".to_string()).unwrap_or_else(|e| e.status.name().to_string())
    );
    let c = match s.wait(t, Duration::from_secs(60)) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("FAIL: wait: {e}");
            return ExitCode::from(1);
        }
    };
    step(4, "completion");
    println!(
        "      status={} committed={} bytes={} chunks={} latency={} device cycles ({})",
        c.status.name(),
        c.committed,
        c.bytes,
        c.chunks,
        c.latency_cycles,
        info.backend.timing.as_str()
    );
    let mut out = vec![0u8; bytes];
    s.read(dst, 0, &mut out).unwrap();
    let expect = proto::apply_proc(proto::proc_op::XOR32, param, &input).unwrap();
    let mut ok = c.status == Status::Ok && c.committed && c.bytes == bytes as u64;
    ok &= out == expect;
    ok &= c.crc_in == Some(proto::crc32(&input)) && c.crc_out == Some(proto::crc32(&expect)) && c.csum == Some(proto::csum1071(&expect));
    step(5, &format!("result verified against an independent reference (bytes, CRC-32 in/out, RFC 1071 checksum): {}", if ok { "MATCH" } else { "MISMATCH" }));
    if let (Some(a), Some(b), Some(cs)) = (c.crc_in, c.crc_out, c.csum) {
        println!("      device reported crc_in={a:08x} crc_out={b:08x} csum={cs:04x}");
    }
    let tc = s.counters().unwrap();
    let dc = m.counters().unwrap();
    step(6, "performance counters");
    println!(
        "      tenant: submitted={} completed={} bytes_ok={} | device: accepted={} retired={} dma_rd={} B dma_wr={} B violations={}",
        tc.usage.submitted,
        tc.usage.completed,
        tc.usage.bytes_ok,
        dc.global[proto::reg::cnt::CMDS_ACCEPTED as usize],
        dc.global[proto::reg::cnt::CMDS_RETIRED as usize],
        dc.global[proto::reg::cnt::DMA_BYTES_RD as usize],
        dc.global[proto::reg::cnt::DMA_BYTES_WR as usize],
        dc.global[proto::reg::cnt::VIOLATIONS as usize]
    );
    let ev = s.telemetry();
    step(7, &format!("telemetry: {} event(s) for this tenant", ev.len()));
    for e in ev.iter().take(6) {
        println!("      ts={:<8} {:<13} queue={} arg={:#x}", e.ts, proto::tlm::name(e.event), e.queue, e.arg);
    }
    let snap = m.snapshot().unwrap();
    let prom = telemetry::render_prometheus(&snap, None);
    println!("      exporter text: {} metric lines (health={}, thermal={})", prom.lines().filter(|l| !l.starts_with('#')).count(), snap.health.name(), snap.thermal.name());
    s.free(src).unwrap();
    s.free(dst).unwrap();
    let rep = m.shutdown().unwrap();
    step(8, &format!("clean release: tenants released={}, SRAM partition scrubbed by the device, host windows zeroed", rep.tenants_released));
    println!();
    if ok {
        println!("RESULT: PASS  backend={} measured_on_hardware={}  (simulation / model result, NOT a hardware result)", info.backend.name, info.backend.measured_on_hardware);
        ExitCode::SUCCESS
    } else {
        println!("RESULT: FAIL");
        ExitCode::from(1)
    }
}

fn cmd_metrics(spec: &str) -> ExitCode {
    let m = match open(spec) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("error: {e}");
            return ExitCode::from(2);
        }
    };
    let cred = m.provision_tenant(0, TenantConfig::default()).unwrap();
    let s = m.open_session(0, &cred).unwrap();
    let (a, b) = (s.alloc(1024, f::DEV_READ).unwrap(), s.alloc(1024, f::DEV_WRITE).unwrap());
    s.write(a, 0, &[7u8; 1024]).unwrap();
    for _ in 0..8 {
        let t = s.submit(&Op::Copy { src: a, src_off: 0, dst: b, dst_off: 0, len: 1024 }).unwrap();
        s.wait(t, Duration::from_secs(30)).unwrap();
    }
    print!("{}", telemetry::render_prometheus(&m.snapshot().unwrap(), None));
    ExitCode::SUCCESS
}

fn cmd_cdi(args: &[String]) -> ExitCode {
    let kind = arg(args, "--kind").unwrap_or_else(|| RESOURCE_SIM.to_string());
    let Some(devs) = arg(args, "--devices") else {
        eprintln!("error: --devices a,b required");
        return ExitCode::from(2);
    };
    let devices: Vec<CdiDevice> = devs
        .split(',')
        .filter(|s| !s.is_empty())
        .map(|d| {
            let id = k8s_device_id(d);
            CdiDevice { name: id.clone(), env: vec![(ENV_VISIBLE.into(), id)], device_nodes: vec![], mounts: vec![] }
        })
        .collect();
    let spec = cdi_spec(&kind, &devices);
    match arg(args, "--out") {
        Some(p) => {
            if let Err(e) = std::fs::write(&p, &spec) {
                eprintln!("error: {p}: {e}");
                return ExitCode::from(2);
            }
            println!("wrote {p}");
        }
        None => print!("{spec}"),
    }
    ExitCode::SUCCESS
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let spec = arg(&args, "--backend").unwrap_or_else(|| "auto".into());
    match args.first().map(|s| s.as_str()) {
        Some("discover") => cmd_discover(),
        Some("info") => cmd_info(&spec),
        Some("slice") => cmd_slice(&spec, arg(&args, "--bytes").and_then(|v| v.parse().ok()).unwrap_or(1000)),
        Some("metrics") => cmd_metrics(&spec),
        Some("cdi") => cmd_cdi(&args),
        _ => {
            eprintln!(
                "usage: sfctl discover | info | slice | metrics | cdi   [--backend SPEC] [--bytes N]\n  SPEC: auto | cpu-ref | rtl-sim[:cfg=mt|min|mt4] | hw (not implemented)"
            );
            ExitCode::from(2)
        }
    }
}
