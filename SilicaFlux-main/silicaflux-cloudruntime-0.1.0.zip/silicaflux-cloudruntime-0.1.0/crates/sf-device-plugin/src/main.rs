//! sf-device-plugin: Kubernetes device plugin for SilicaFlux CloudDPU devices.
//!
//!   sf-device-plugin [--mode hardware|simulated] [--sim-devices cpu-ref,rtl-sim:mt]
//!                    [--resource-name NAME] [--socket-dir DIR] [--health-interval-secs N]
//!                    [--cdi] [--cdi-dir DIR] [--metrics-listen ADDR] [--override-dir DIR]
//!
//! `--mode hardware` (default) advertises PHYSICAL devices under `aureom.ai/silicaflux-dpu`.  No hardware
//! transport exists yet, so this advertises zero devices (and says so).  `--mode simulated` advertises the
//! cpu-ref / rtl-sim devices named by --sim-devices under the DIFFERENT resource `aureom.ai/silicaflux-dpu-sim`, so a
//! simulator can never satisfy a request for hardware.
use sf_cloud::container::{self, cdi_spec, CdiDevice, RESOURCE_HW, RESOURCE_SIM};
use sf_device_plugin::{http, log, run, DeviceInfo, DeviceSource, HardwareSource, PluginConfig, Shared, SimulatedSource};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

fn arg(args: &[String], name: &str) -> Option<String> {
    args.iter().position(|a| a == name).and_then(|i| args.get(i + 1)).cloned()
}

fn write_cdi(dir: &std::path::Path, kind: &str, devs: &[DeviceInfo]) {
    let cdi: Vec<CdiDevice> = devs
        .iter()
        .map(|d| CdiDevice {
            name: d.id.clone(),
            env: vec![(container::ENV_VISIBLE.into(), d.id.clone()), (container::ENV_BACKEND.into(), d.backend_spec.clone())],
            device_nodes: vec![],
            mounts: vec![],
        })
        .collect();
    let spec = cdi_spec(kind, &cdi);
    let file = dir.join(format!("{}.json", kind.replace('/', "-")));
    let tmp = dir.join(format!(".{}.tmp", kind.replace('/', "-")));
    let r = std::fs::create_dir_all(dir).and_then(|_| std::fs::write(&tmp, spec)).and_then(|_| std::fs::rename(&tmp, &file));
    match r {
        Ok(()) => log("info", &format!("event=cdi_spec_written path={} devices={}", file.display(), devs.len())),
        Err(e) => log("error", &format!("event=cdi_spec_failed path={} error=\"{e}\"", file.display())),
    }
}

#[tokio::main]
async fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        eprintln!("usage: sf-device-plugin [--mode hardware|simulated] [--sim-devices cpu-ref,rtl-sim:mt] [--resource-name N] [--socket-dir DIR]\n                        [--health-interval-secs N] [--cdi] [--cdi-dir DIR] [--metrics-listen ADDR] [--override-dir DIR]");
        return;
    }
    let mode = arg(&args, "--mode").unwrap_or_else(|| "hardware".into());
    let simulated = match mode.as_str() {
        "hardware" => false,
        "simulated" => true,
        m => {
            eprintln!("error: --mode must be 'hardware' or 'simulated', got '{m}'");
            std::process::exit(2);
        }
    };
    let resource = arg(&args, "--resource-name").unwrap_or_else(|| if simulated { RESOURCE_SIM } else { RESOURCE_HW }.to_string());
    let socket_dir = PathBuf::from(arg(&args, "--socket-dir").unwrap_or_else(|| "/var/lib/kubelet/device-plugins".into()));
    let mut cfg = PluginConfig::new(&resource, &socket_dir);
    cfg.health_interval = Duration::from_secs(arg(&args, "--health-interval-secs").and_then(|v| v.parse().ok()).unwrap_or(5));
    let cdi = args.iter().any(|a| a == "--cdi");
    if cdi {
        cfg.cdi_kind = Some(resource.clone());
    }
    let override_dir = arg(&args, "--override-dir").map(PathBuf::from);
    let source: Arc<dyn DeviceSource> = if simulated {
        let specs: Vec<String> = arg(&args, "--sim-devices").unwrap_or_else(|| "cpu-ref".into()).split(',').filter(|s| !s.is_empty()).map(|s| s.to_string()).collect();
        match SimulatedSource::new(&specs, override_dir) {
            Ok(s) => {
                log("warn", &format!("event=simulated_mode resource={resource} note=\"advertising SIMULATED devices; results are not hardware results\""));
                Arc::new(s)
            }
            Err(e) => {
                eprintln!("error: {e}");
                std::process::exit(2);
            }
        }
    } else {
        log("warn", "event=no_hardware_transport note=\"physical SilicaFlux devices cannot be driven yet (docs/03_LINUX_DEVICE_ACCESS.md); advertising 0 devices\"");
        Arc::new(HardwareSource)
    };
    let shared = Shared::new(cfg);
    if cdi {
        let dir = PathBuf::from(arg(&args, "--cdi-dir").unwrap_or_else(|| "/var/run/cdi".into()));
        let kind = resource.clone();
        shared.set_inventory_hook(move |d| write_cdi(&dir, &kind, d));
    }
    if let Some(addr) = arg(&args, "--metrics-listen") {
        match http::serve(&addr, shared.clone()) {
            Ok(a) => log("info", &format!("event=metrics_listening addr={a}")),
            Err(e) => {
                eprintln!("error: cannot listen on {addr}: {e}");
                std::process::exit(2);
            }
        }
    }
    let shutdown = async {
        use tokio::signal::unix::{signal, SignalKind};
        let mut term = signal(SignalKind::terminate()).expect("SIGTERM handler");
        tokio::select! { _ = tokio::signal::ctrl_c() => {}, _ = term.recv() => {} }
    };
    if let Err(e) = run(shared, source, shutdown).await {
        log("error", &format!("event=fatal error=\"{e}\""));
        std::process::exit(1);
    }
}
