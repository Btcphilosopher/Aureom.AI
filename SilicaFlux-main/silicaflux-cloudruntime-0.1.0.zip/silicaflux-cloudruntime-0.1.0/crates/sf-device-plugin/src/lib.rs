//! Kubernetes device plugin for SilicaFlux CloudDPU devices (kubelet device-plugin API v1beta1).
//!
//! What it does:
//!   * registers a vendor resource with the kubelet (`Registration.Register`);
//!   * discovers devices and probes their health periodically; health changes are pushed to the kubelet over
//!     `ListAndWatch` immediately;
//!   * `Allocate`: validates every requested device (unknown -> InvalidArgument, unhealthy -> FailedPrecondition),
//!     returns the container's environment (visibility control) and, optionally, CDI device names; records the
//!     allocation in a ledger exported as metrics;
//!   * supervises itself: if the kubelet restarts (its socket changes) or removes the plugin socket, the plugin
//!     re-creates its server and registers again.
//!
//! What it deliberately does NOT do:
//!   * advertise tenant partitions / virtual functions.  Each advertised device is a WHOLE device; sharing is
//!     inside the mediator and is not exposed to the scheduler until isolation has been validated on hardware;
//!   * hand containers device nodes, register windows or host-memory mappings (`DeviceSpec`/`Mount` stay empty);
//!   * advertise physical hardware: no hardware transport exists, so `HardwareSource` finds nothing;
//!   * claim to know when an allocation ends: the kubelet does not tell device plugins, so the ledger is an
//!     upper-bound request count, not live occupancy.  The kubelet is the source of truth for allocation.

pub mod api {
    tonic::include_proto!("v1beta1");
}
pub mod http;

use api::device_plugin_server::{DevicePlugin, DevicePluginServer};
use api::registration_client::RegistrationClient;
use api::*;
use sf_cloud::backend::{self, BackendSpec};
use sf_cloud::container::{self, k8s_device_id};
use sf_cloud::mediator::{Health, Mediator, MediatorOptions};
use std::collections::{BTreeMap, HashMap};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicI64, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tokio::sync::{mpsc, oneshot, watch};
use tokio_stream::wrappers::{ReceiverStream, UnixListenerStream};
use tonic::{Request, Response, Status};

pub const API_VERSION: &str = "v1beta1";
pub const HEALTHY: &str = "Healthy";
pub const UNHEALTHY: &str = "Unhealthy";

pub fn log(level: &str, msg: &str) {
    let t = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs_f64()).unwrap_or(0.0);
    eprintln!("ts={t:.3} level={level} component=sf-device-plugin {msg}");
}

// ------------------------------------------------------------------------------------------------ devices
#[derive(Clone, Debug, PartialEq)]
pub struct DeviceInfo {
    /// Kubernetes device ID (opaque to the kubelet).
    pub id: String,
    pub description: String,
    /// Backend spec the workload should use for this device (exported as SILICAFLUX_BACKEND).
    pub backend_spec: String,
    pub healthy: bool,
    pub reason: String,
    pub simulated: bool,
}

/// Where devices come from.  `poll` is called at start-up and every health interval; it must return promptly.
pub trait DeviceSource: Send + Sync + 'static {
    fn poll(&self) -> Vec<DeviceInfo>;
}

/// Physical devices.  None can be found today: no hardware transport exists (docs/03_LINUX_DEVICE_ACCESS.md).
pub struct HardwareSource;
impl DeviceSource for HardwareSource {
    fn poll(&self) -> Vec<DeviceInfo> {
        // `hw:*` descriptors are always reported unavailable by the runtime; advertising them would be a lie.
        Vec::new()
    }
}

struct Probe {
    spec: String,
    id: String,
    description: String,
    mediator: Option<Mediator>,
}

/// Simulated devices (cpu-ref / rtl-sim), each probed through its own mediator instance.
pub struct SimulatedSource {
    probes: Mutex<Vec<Probe>>,
    override_dir: Option<PathBuf>,
}

impl SimulatedSource {
    pub fn new(specs: &[String], override_dir: Option<PathBuf>) -> Result<SimulatedSource, String> {
        let mut per_kind: HashMap<&'static str, usize> = HashMap::new();
        let mut probes = Vec::new();
        for s in specs {
            let sp = BackendSpec::parse(s).map_err(|e| e.to_string())?;
            let kind = sp.kind.ok_or("device spec must name a backend (cpu-ref | rtl-sim)")?;
            if kind == backend::BackendKind::Hardware {
                return Err("hardware devices cannot be configured as simulated devices".into());
            }
            let n = per_kind.entry(kind.as_str()).or_insert(0);
            let id = format!("{}-{}", k8s_device_id(kind.as_str()), n);
            *n += 1;
            probes.push(Probe { spec: s.clone(), id, description: format!("simulated SilicaFlux CloudDPU ({s})"), mediator: None });
        }
        Ok(SimulatedSource { probes: Mutex::new(probes), override_dir })
    }
}

impl DeviceSource for SimulatedSource {
    fn poll(&self) -> Vec<DeviceInfo> {
        let mut out = Vec::new();
        for p in self.probes.lock().unwrap().iter_mut() {
            if p.mediator.is_none() {
                // (re)open the probe instance; failure => the device is listed as unhealthy, not silently dropped
                p.mediator = BackendSpec::parse(&p.spec).ok().and_then(|s| backend::open_backend(&s).ok()).and_then(|b| Mediator::open(b, MediatorOptions::default()).ok());
            }
            let (healthy, reason) = match &p.mediator {
                None => (false, "backend could not be opened".to_string()),
                Some(m) => match m.health() {
                    Health::Healthy => (true, String::new()),
                    Health::Degraded(r) => (true, format!("degraded: {}", r.join("; "))),
                    Health::Faulted(r) => (false, format!("faulted: {}", r.join("; "))),
                    Health::Unavailable(r) => (false, format!("unavailable: {r}")),
                },
            };
            if !healthy {
                p.mediator = None; // probe again from scratch next time
            }
            let (mut healthy, mut reason) = (healthy, reason);
            if let Some(d) = &self.override_dir {
                if d.join(&p.id).exists() {
                    healthy = false;
                    reason = format!("operator override: {}", d.join(&p.id).display());
                }
            }
            out.push(DeviceInfo { id: p.id.clone(), description: p.description.clone(), backend_spec: p.spec.clone(), healthy, reason, simulated: true });
        }
        out
    }
}

// ------------------------------------------------------------------------------------------------ config / state
#[derive(Clone, Debug)]
pub struct PluginConfig {
    pub resource_name: String,
    pub socket_dir: PathBuf,
    /// File name of the plugin's own socket inside `socket_dir` (this is the `endpoint` in the registration).
    pub plugin_socket: String,
    pub kubelet_socket: PathBuf,
    pub health_interval: Duration,
    /// CDI kind to return device names for (e.g. `aureom.ai/silicaflux-dpu-sim`); None = environment only.
    pub cdi_kind: Option<String>,
    pub registration_retry: Duration,
}

impl PluginConfig {
    pub fn new(resource_name: &str, socket_dir: &Path) -> PluginConfig {
        PluginConfig {
            resource_name: resource_name.to_string(),
            socket_dir: socket_dir.to_path_buf(),
            plugin_socket: "aureom-silicaflux.sock".into(),
            kubelet_socket: socket_dir.join("kubelet.sock"),
            health_interval: Duration::from_secs(5),
            cdi_kind: None,
            registration_retry: Duration::from_secs(1),
        }
    }
}

#[derive(Default)]
pub struct Counters {
    pub registrations: AtomicU64,
    pub registration_failures: AtomicU64,
    pub allocate_requests: AtomicU64,
    pub allocate_failures: AtomicU64,
    pub devices_allocated: AtomicU64,
    pub preferred_requests: AtomicU64,
    pub health_transitions: AtomicU64,
    pub server_restarts: AtomicU64,
    pub watchers: AtomicI64,
}

#[derive(Clone, Debug)]
pub struct AllocRecord {
    pub seq: u64,
    pub devices: Vec<String>,
    pub at_unix: u64,
}

pub struct Shared {
    pub cfg: PluginConfig,
    devices: Mutex<BTreeMap<String, DeviceInfo>>,
    version: watch::Sender<u64>,
    ledger: Mutex<Vec<AllocRecord>>,
    per_device_allocs: Mutex<HashMap<String, u64>>,
    pub counters: Counters,
    #[allow(clippy::type_complexity)]
    hook: Mutex<Option<Box<dyn Fn(&[DeviceInfo]) + Send + Sync>>>,
}

impl Shared {
    pub fn new(cfg: PluginConfig) -> Arc<Shared> {
        let (tx, _) = watch::channel(0);
        Arc::new(Shared {
            cfg,
            devices: Mutex::new(BTreeMap::new()),
            version: tx,
            ledger: Mutex::new(vec![]),
            per_device_allocs: Mutex::new(HashMap::new()),
            counters: Counters::default(),
            hook: Mutex::new(None),
        })
    }

    /// Replace the inventory; returns true (and wakes every ListAndWatch stream) if anything changed.
    pub fn update_devices(&self, list: Vec<DeviceInfo>) -> bool {
        let new: BTreeMap<String, DeviceInfo> = list.into_iter().map(|d| (d.id.clone(), d)).collect();
        let mut cur = self.devices.lock().unwrap();
        // health only matters to the kubelet; descriptions/reasons are for humans, so notify on any difference
        if *cur == new {
            return false;
        }
        for (id, d) in &new {
            if let Some(old) = cur.get(id) {
                if old.healthy != d.healthy {
                    self.counters.health_transitions.fetch_add(1, Ordering::Relaxed);
                    log(if d.healthy { "info" } else { "warn" }, &format!("event=health_change device={id} healthy={} reason=\"{}\"", d.healthy, d.reason));
                }
            } else {
                log("info", &format!("event=device_added device={id} healthy={}", d.healthy));
            }
        }
        for id in cur.keys() {
            if !new.contains_key(id) {
                log("warn", &format!("event=device_removed device={id}"));
            }
        }
        *cur = new;
        let snapshot: Vec<DeviceInfo> = cur.values().cloned().collect();
        drop(cur);
        if let Some(h) = self.hook.lock().unwrap().as_ref() {
            h(&snapshot);
        }
        self.version.send_modify(|v| *v += 1);
        true
    }

    /// Called (outside the inventory lock) after every inventory change, e.g. to refresh a CDI spec file.
    pub fn set_inventory_hook(&self, f: impl Fn(&[DeviceInfo]) + Send + Sync + 'static) {
        *self.hook.lock().unwrap() = Some(Box::new(f));
    }

    pub fn devices(&self) -> Vec<DeviceInfo> {
        self.devices.lock().unwrap().values().cloned().collect()
    }

    pub fn ledger(&self) -> Vec<AllocRecord> {
        self.ledger.lock().unwrap().clone()
    }

    pub fn per_device_allocations(&self) -> HashMap<String, u64> {
        self.per_device_allocs.lock().unwrap().clone()
    }

    fn api_devices(&self) -> Vec<Device> {
        self.devices.lock().unwrap().values().map(|d| Device { id: d.id.clone(), health: if d.healthy { HEALTHY } else { UNHEALTHY }.to_string(), topology: None }).collect()
    }

    pub fn options(&self) -> DevicePluginOptions {
        DevicePluginOptions { pre_start_required: false, get_preferred_allocation_available: true }
    }
}

// ------------------------------------------------------------------------------------------------ service
#[derive(Clone)]
pub struct Service {
    pub shared: Arc<Shared>,
}

type WatchStream = ReceiverStream<Result<ListAndWatchResponse, Status>>;

#[tonic::async_trait]
impl DevicePlugin for Service {
    async fn get_device_plugin_options(&self, _: Request<Empty>) -> Result<Response<DevicePluginOptions>, Status> {
        Ok(Response::new(self.shared.options()))
    }

    type ListAndWatchStream = WatchStream;

    async fn list_and_watch(&self, _: Request<Empty>) -> Result<Response<Self::ListAndWatchStream>, Status> {
        let (tx, rx) = mpsc::channel(8);
        let shared = self.shared.clone();
        let mut ver = shared.version.subscribe();
        shared.counters.watchers.fetch_add(1, Ordering::Relaxed);
        log("info", "event=list_and_watch_opened");
        tokio::spawn(async move {
            loop {
                // the full device list is sent on every change, as the API requires
                if tx.send(Ok(ListAndWatchResponse { devices: shared.api_devices() })).await.is_err() {
                    break; // the kubelet closed the stream
                }
                if ver.changed().await.is_err() {
                    break;
                }
            }
            shared.counters.watchers.fetch_sub(1, Ordering::Relaxed);
            log("info", "event=list_and_watch_closed");
        });
        Ok(Response::new(ReceiverStream::new(rx)))
    }

    async fn get_preferred_allocation(&self, req: Request<PreferredAllocationRequest>) -> Result<Response<PreferredAllocationResponse>, Status> {
        self.shared.counters.preferred_requests.fetch_add(1, Ordering::Relaxed);
        let allocs = self.shared.per_device_allocs.lock().unwrap().clone();
        let mut out = Vec::new();
        for c in req.into_inner().container_requests {
            let n = c.allocation_size.max(0) as usize;
            let mut chosen: Vec<String> = Vec::new();
            for id in &c.must_include_device_i_ds {
                if !chosen.contains(id) {
                    chosen.push(id.clone());
                }
            }
            // least-allocated first, then by id: spreads wear/usage across identical devices deterministically
            let mut rest: Vec<&String> = c.available_device_i_ds.iter().filter(|id| !chosen.contains(id)).collect();
            rest.sort_by_key(|id| (allocs.get(*id).copied().unwrap_or(0), (*id).clone()));
            for id in rest {
                if chosen.len() >= n {
                    break;
                }
                chosen.push(id.clone());
            }
            if chosen.len() < n {
                return Err(Status::invalid_argument(format!("cannot satisfy allocation_size {n}: only {} candidate device(s)", chosen.len())));
            }
            chosen.truncate(n.max(c.must_include_device_i_ds.len()));
            out.push(ContainerPreferredAllocationResponse { device_i_ds: chosen });
        }
        Ok(Response::new(PreferredAllocationResponse { container_responses: out }))
    }

    async fn allocate(&self, req: Request<AllocateRequest>) -> Result<Response<AllocateResponse>, Status> {
        let sh = &self.shared;
        sh.counters.allocate_requests.fetch_add(1, Ordering::Relaxed);
        let devs = sh.devices.lock().unwrap().clone();
        let mut responses = Vec::new();
        let mut all_ids = Vec::new();
        for c in req.into_inner().container_requests {
            if c.devices_ids.is_empty() {
                sh.counters.allocate_failures.fetch_add(1, Ordering::Relaxed);
                return Err(Status::invalid_argument("empty device list in a container request"));
            }
            let mut specs = Vec::new();
            for id in &c.devices_ids {
                match devs.get(id) {
                    None => {
                        sh.counters.allocate_failures.fetch_add(1, Ordering::Relaxed);
                        log("warn", &format!("event=allocate_refused device={id} reason=unknown"));
                        return Err(Status::invalid_argument(format!("unknown device '{id}'")));
                    }
                    Some(d) if !d.healthy => {
                        sh.counters.allocate_failures.fetch_add(1, Ordering::Relaxed);
                        log("warn", &format!("event=allocate_refused device={id} reason=unhealthy detail=\"{}\"", d.reason));
                        return Err(Status::failed_precondition(format!("device '{id}' is unhealthy: {}", d.reason)));
                    }
                    Some(d) => specs.push(d.backend_spec.clone()),
                }
            }
            let ids = c.devices_ids.join(",");
            let mut envs = HashMap::new();
            envs.insert(container::ENV_VISIBLE.to_string(), ids.clone());
            envs.insert(container::ENV_BACKEND.to_string(), specs.join(","));
            let mut annotations = HashMap::new();
            annotations.insert("aureom.ai/silicaflux-devices".to_string(), ids);
            if devs.values().any(|d| d.simulated) {
                annotations.insert("aureom.ai/silicaflux-simulated".to_string(), "true".to_string());
            }
            let cdi_devices = match &sh.cfg.cdi_kind {
                Some(kind) => c.devices_ids.iter().map(|id| CdiDevice { name: container::cdi_qualified_name(kind, id) }).collect(),
                None => vec![],
            };
            all_ids.extend(c.devices_ids.iter().cloned());
            // No `devices` (device nodes) and no `mounts`: containers never receive raw device access.
            responses.push(ContainerAllocateResponse { envs, mounts: vec![], devices: vec![], annotations, cdi_devices });
        }
        let seq = {
            let mut l = sh.ledger.lock().unwrap();
            let seq = l.len() as u64 + 1;
            l.push(AllocRecord { seq, devices: all_ids.clone(), at_unix: SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0) });
            seq
        };
        {
            let mut p = sh.per_device_allocs.lock().unwrap();
            for id in &all_ids {
                *p.entry(id.clone()).or_insert(0) += 1;
            }
        }
        sh.counters.devices_allocated.fetch_add(all_ids.len() as u64, Ordering::Relaxed);
        log("info", &format!("event=allocated seq={seq} devices={}", all_ids.join(",")));
        Ok(Response::new(AllocateResponse { container_responses: responses }))
    }

    async fn pre_start_container(&self, _: Request<PreStartContainerRequest>) -> Result<Response<PreStartContainerResponse>, Status> {
        Ok(Response::new(PreStartContainerResponse {}))
    }
}

// ------------------------------------------------------------------------------------------------ registration
pub async fn uds_channel(path: PathBuf) -> Result<tonic::transport::Channel, tonic::transport::Error> {
    use hyper_util::rt::TokioIo;
    tonic::transport::Endpoint::try_from("http://localhost")?
        .connect_with_connector(tower::service_fn(move |_: tonic::transport::Uri| {
            let p = path.clone();
            async move { Ok::<_, std::io::Error>(TokioIo::new(tokio::net::UnixStream::connect(p).await?)) }
        }))
        .await
}

/// Register the plugin with the kubelet.
pub async fn register(cfg: &PluginConfig, options: DevicePluginOptions) -> Result<(), String> {
    let ch = tokio::time::timeout(Duration::from_secs(5), uds_channel(cfg.kubelet_socket.clone()))
        .await
        .map_err(|_| "timed out connecting to the kubelet socket".to_string())?
        .map_err(|e| format!("cannot connect to {}: {e}", cfg.kubelet_socket.display()))?;
    let mut c = RegistrationClient::new(ch);
    tokio::time::timeout(
        Duration::from_secs(5),
        c.register(RegisterRequest { version: API_VERSION.into(), endpoint: cfg.plugin_socket.clone(), resource_name: cfg.resource_name.clone(), options: Some(options) }),
    )
    .await
    .map_err(|_| "registration timed out".to_string())?
    .map_err(|e| format!("kubelet refused the registration: {e}"))?;
    Ok(())
}

fn sock_identity(p: &Path) -> Option<(u64, i64, i64)> {
    std::fs::metadata(p).ok().map(|m| (m.ino(), m.ctime(), m.ctime_nsec()))
}

struct ServerHandle {
    stop: Option<oneshot::Sender<()>>,
    task: tokio::task::JoinHandle<()>,
}

fn start_server(shared: &Arc<Shared>) -> Result<ServerHandle, String> {
    let path = shared.cfg.socket_dir.join(&shared.cfg.plugin_socket);
    let _ = std::fs::remove_file(&path); // stale socket from a previous run
    std::fs::create_dir_all(&shared.cfg.socket_dir).map_err(|e| format!("{}: {e}", shared.cfg.socket_dir.display()))?;
    let listener = tokio::net::UnixListener::bind(&path).map_err(|e| format!("cannot bind {}: {e}", path.display()))?;
    let (tx, rx) = oneshot::channel::<()>();
    let svc = Service { shared: shared.clone() };
    let task = tokio::spawn(async move {
        let r = tonic::transport::Server::builder()
            .add_service(DevicePluginServer::new(svc))
            .serve_with_incoming_shutdown(UnixListenerStream::new(listener), async {
                let _ = rx.await;
            })
            .await;
        if let Err(e) = r {
            log("error", &format!("event=grpc_server_error error=\"{e}\""));
        }
    });
    Ok(ServerHandle { stop: Some(tx), task })
}

async fn stop_server(mut h: ServerHandle, path: &Path) {
    if let Some(tx) = h.stop.take() {
        let _ = tx.send(());
    }
    let _ = tokio::time::timeout(Duration::from_secs(3), &mut h.task).await;
    h.task.abort();
    let _ = std::fs::remove_file(path);
}

/// Run the plugin until `shutdown` resolves.  Supervises the gRPC server and the kubelet registration.
pub async fn run(shared: Arc<Shared>, source: Arc<dyn DeviceSource>, shutdown: impl std::future::Future<Output = ()>) -> Result<(), String> {
    tokio::pin!(shutdown);
    let plugin_path = shared.cfg.socket_dir.join(&shared.cfg.plugin_socket);
    // initial inventory
    {
        let s = source.clone();
        let list = tokio::task::spawn_blocking(move || s.poll()).await.map_err(|e| e.to_string())?;
        shared.update_devices(list);
    }
    log("info", &format!("event=start resource={} devices={} socket={}", shared.cfg.resource_name, shared.devices().len(), plugin_path.display()));
    'outer: loop {
        let server = start_server(&shared)?;
        let mut registered_identity: Option<(u64, i64, i64)> = None;
        let mut last_health = tokio::time::Instant::now();
        let mut retry_at = tokio::time::Instant::now();
        let mut ticker = tokio::time::interval(Duration::from_millis(200));
        loop {
            tokio::select! {
                _ = &mut shutdown => {
                    log("info", "event=shutdown");
                    stop_server(server, &plugin_path).await;
                    break 'outer;
                }
                _ = ticker.tick() => {}
            }
            // (1) The kubelet removes every socket in the directory when it restarts: our server is then
            //     unreachable even though it is still running -> rebuild it.  This is checked BEFORE registering:
            //     the kubelet dials the registered endpoint right after Register, so the socket must exist.
            if !plugin_path.exists() {
                log("warn", "event=plugin_socket_removed action=restart_server");
                shared.counters.server_restarts.fetch_add(1, Ordering::Relaxed);
                stop_server(server, &plugin_path).await;
                continue 'outer;
            }
            // (2) register, or re-register when the kubelet restarted (its socket was re-created)
            let kid = sock_identity(&shared.cfg.kubelet_socket);
            let need_register = registered_identity.is_none() || (kid.is_some() && kid != registered_identity);
            if need_register && kid.is_some() && tokio::time::Instant::now() >= retry_at {
                match register(&shared.cfg, shared.options()).await {
                    Ok(()) => {
                        shared.counters.registrations.fetch_add(1, Ordering::Relaxed);
                        registered_identity = sock_identity(&shared.cfg.kubelet_socket);
                        log("info", &format!("event=registered resource={} endpoint={} api={API_VERSION}", shared.cfg.resource_name, shared.cfg.plugin_socket));
                    }
                    Err(e) => {
                        shared.counters.registration_failures.fetch_add(1, Ordering::Relaxed);
                        log("warn", &format!("event=registration_failed error=\"{e}\" retry_in={:?}", shared.cfg.registration_retry));
                        retry_at = tokio::time::Instant::now() + shared.cfg.registration_retry;
                    }
                }
            }
            // (3) health
            if last_health.elapsed() >= shared.cfg.health_interval {
                last_health = tokio::time::Instant::now();
                let s = source.clone();
                if let Ok(list) = tokio::task::spawn_blocking(move || s.poll()).await {
                    shared.update_devices(list);
                }
            }
        }
    }
    Ok(())
}
