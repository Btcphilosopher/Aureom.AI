//! Tiny HTTP endpoint for the plugin: `/metrics` (Prometheus) and `/healthz`.  No dependencies, GET only.
use crate::Shared;
use std::io::{Read, Write};
use std::net::TcpListener;
use std::sync::atomic::Ordering;
use std::sync::Arc;

fn hdr(o: &mut String, name: &str, kind: &str, help: &str) {
    o.push_str(&format!("# HELP {name} {help}\n# TYPE {name} {kind}\n"));
}

pub fn render_metrics(sh: &Shared) -> String {
    let devs = sh.devices();
    let c = &sh.counters;
    let mut o = String::new();
    hdr(&mut o, "silicaflux_plugin_info", "gauge", "Plugin identity.");
    o.push_str(&format!("silicaflux_plugin_info{{resource=\"{}\",api=\"{}\"}} 1\n", sh.cfg.resource_name, crate::API_VERSION));
    hdr(&mut o, "silicaflux_plugin_devices", "gauge", "Advertised devices by health.");
    let h = devs.iter().filter(|d| d.healthy).count();
    o.push_str(&format!("silicaflux_plugin_devices{{health=\"healthy\"}} {h}\nsilicaflux_plugin_devices{{health=\"unhealthy\"}} {}\n", devs.len() - h));
    hdr(&mut o, "silicaflux_plugin_device_health", "gauge", "Per-device health (1 = healthy).");
    for d in &devs {
        o.push_str(&format!("silicaflux_plugin_device_health{{device=\"{}\",simulated=\"{}\"}} {}\n", d.id, d.simulated, d.healthy as u8));
    }
    hdr(
        &mut o,
        "silicaflux_plugin_device_allocations_total",
        "counter",
        "Allocate requests that included the device. The kubelet does not report releases: this is a request count, not live occupancy.",
    );
    let per = sh.per_device_allocations();
    for d in &devs {
        o.push_str(&format!("silicaflux_plugin_device_allocations_total{{device=\"{}\"}} {}\n", d.id, per.get(&d.id).copied().unwrap_or(0)));
    }
    for (n, k, hlp, v) in [
        (
            "silicaflux_plugin_registrations_total",
            "counter",
            "Successful registrations with the kubelet (re-registrations after a kubelet restart included).",
            c.registrations.load(Ordering::Relaxed) as i64,
        ),
        ("silicaflux_plugin_registration_failures_total", "counter", "Failed registration attempts.", c.registration_failures.load(Ordering::Relaxed) as i64),
        ("silicaflux_plugin_allocate_requests_total", "counter", "Allocate calls received.", c.allocate_requests.load(Ordering::Relaxed) as i64),
        (
            "silicaflux_plugin_allocate_failures_total",
            "counter",
            "Allocate calls refused (unknown or unhealthy device, empty request).",
            c.allocate_failures.load(Ordering::Relaxed) as i64,
        ),
        ("silicaflux_plugin_devices_allocated_total", "counter", "Devices handed out by successful Allocate calls.", c.devices_allocated.load(Ordering::Relaxed) as i64),
        ("silicaflux_plugin_health_transitions_total", "counter", "Device health changes observed.", c.health_transitions.load(Ordering::Relaxed) as i64),
        (
            "silicaflux_plugin_server_restarts_total",
            "counter",
            "Times the gRPC server was rebuilt after the kubelet removed the plugin socket.",
            c.server_restarts.load(Ordering::Relaxed) as i64,
        ),
        ("silicaflux_plugin_list_and_watch_streams", "gauge", "Open ListAndWatch streams.", c.watchers.load(Ordering::Relaxed)),
    ] {
        hdr(&mut o, n, k, hlp);
        o.push_str(&format!("{n} {v}\n"));
    }
    o
}

pub fn serve(listen: &str, sh: Arc<Shared>) -> std::io::Result<std::net::SocketAddr> {
    let l = TcpListener::bind(listen)?;
    let addr = l.local_addr()?;
    std::thread::spawn(move || {
        for conn in l.incoming().flatten() {
            let sh = sh.clone();
            std::thread::spawn(move || {
                let mut conn = conn;
                let _ = conn.set_read_timeout(Some(std::time::Duration::from_secs(5)));
                let mut buf = [0u8; 2048];
                let n = conn.read(&mut buf).unwrap_or(0);
                let req = String::from_utf8_lossy(&buf[..n]);
                let path = req.lines().next().and_then(|l| l.split_whitespace().nth(1)).unwrap_or("/").to_string();
                let (code, body) = match path.as_str() {
                    "/metrics" => (200, render_metrics(&sh)),
                    "/healthz" => {
                        let healthy = sh.devices().iter().filter(|d| d.healthy).count();
                        (200, format!("ok registered={} healthy_devices={healthy}\n", sh.counters.registrations.load(Ordering::Relaxed)))
                    }
                    _ => (404, "not found\n".to_string()),
                };
                let _ = write!(conn, "HTTP/1.1 {code} X\r\nContent-Type: text/plain; version=0.0.4\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len());
            });
        }
    });
    Ok(addr)
}
