//! End-to-end tests of the device plugin against a MOCK KUBELET that implements the real `Registration` service
//! (the verbatim upstream v1beta1 API) over a Unix socket, exactly where the kubelet would.
use sf_device_plugin::api::device_plugin_client::DevicePluginClient;
use sf_device_plugin::api::registration_server::{Registration, RegistrationServer};
use sf_device_plugin::api::*;
use sf_device_plugin::{http, run, uds_channel, DeviceInfo, DeviceSource, HardwareSource, PluginConfig, Shared, SimulatedSource};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::sync::oneshot;
use tonic::{Code, Request, Response, Status};

static N: AtomicU32 = AtomicU32::new(0);
fn tmpdir() -> PathBuf {
    // short path: unix socket paths are limited to ~108 bytes
    let d = std::env::temp_dir().join(format!("sfp{}_{}", std::process::id(), N.fetch_add(1, Ordering::SeqCst)));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

// ---------------------------------------------------------------------------------------------- mock kubelet
struct Mock {
    reqs: Arc<Mutex<Vec<RegisterRequest>>>,
}
#[tonic::async_trait]
impl Registration for Mock {
    async fn register(&self, r: Request<RegisterRequest>) -> Result<Response<Empty>, Status> {
        let r = r.into_inner();
        // what the real kubelet checks
        if r.version != "v1beta1" {
            return Err(Status::invalid_argument(format!("unsupported API version {}", r.version)));
        }
        if !r.resource_name.contains('/') || r.endpoint.is_empty() {
            return Err(Status::invalid_argument("invalid resource name or endpoint"));
        }
        self.reqs.lock().unwrap().push(r);
        Ok(Response::new(Empty {}))
    }
}

struct MockKubelet {
    reqs: Arc<Mutex<Vec<RegisterRequest>>>,
    stop: Option<oneshot::Sender<()>>,
    task: tokio::task::JoinHandle<()>,
}
impl MockKubelet {
    fn start(dir: &Path) -> MockKubelet {
        let sock = dir.join("kubelet.sock");
        let _ = std::fs::remove_file(&sock);
        let l = tokio::net::UnixListener::bind(&sock).unwrap();
        let reqs = Arc::new(Mutex::new(vec![]));
        let (tx, rx) = oneshot::channel();
        let svc = RegistrationServer::new(Mock { reqs: reqs.clone() });
        let task = tokio::spawn(async move {
            let _ = tonic::transport::Server::builder()
                .add_service(svc)
                .serve_with_incoming_shutdown(tokio_stream::wrappers::UnixListenerStream::new(l), async {
                    let _ = rx.await;
                })
                .await;
        });
        MockKubelet { reqs, stop: Some(tx), task }
    }
    async fn stop(mut self) {
        if let Some(t) = self.stop.take() {
            let _ = t.send(());
        }
        let _ = tokio::time::timeout(Duration::from_secs(3), &mut self.task).await;
    }
    fn count(&self) -> usize {
        self.reqs.lock().unwrap().len()
    }
}

async fn until<F: FnMut() -> bool>(what: &str, secs: u64, mut f: F) {
    let t0 = std::time::Instant::now();
    while !f() {
        assert!(t0.elapsed() < Duration::from_secs(secs), "timed out waiting for: {what}");
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
}

// ---------------------------------------------------------------------------------------------- fake devices
#[derive(Clone)]
struct Fake(Arc<Mutex<Vec<DeviceInfo>>>);
impl DeviceSource for Fake {
    fn poll(&self) -> Vec<DeviceInfo> {
        self.0.lock().unwrap().clone()
    }
}
fn dev(id: &str, healthy: bool) -> DeviceInfo {
    DeviceInfo {
        id: id.into(),
        description: format!("test device {id}"),
        backend_spec: "cpu-ref".into(),
        healthy,
        reason: if healthy { String::new() } else { "injected".into() },
        simulated: true,
    }
}

struct Running {
    shared: Arc<Shared>,
    stop: Option<oneshot::Sender<()>>,
    task: tokio::task::JoinHandle<Result<(), String>>,
    dir: PathBuf,
}
impl Running {
    fn start(dir: &Path, source: Arc<dyn DeviceSource>, tweak: impl FnOnce(&mut PluginConfig)) -> Running {
        let mut cfg = PluginConfig::new("aureom.ai/silicaflux-dpu-sim", dir);
        cfg.health_interval = Duration::from_millis(100);
        cfg.registration_retry = Duration::from_millis(100);
        tweak(&mut cfg);
        let shared = Shared::new(cfg);
        let (tx, rx) = oneshot::channel::<()>();
        let sh = shared.clone();
        let task = tokio::spawn(async move {
            run(sh, source, async {
                let _ = rx.await;
            })
            .await
        });
        Running { shared, stop: Some(tx), task, dir: dir.to_path_buf() }
    }
    async fn client(&self) -> DevicePluginClient<tonic::transport::Channel> {
        let sock = self.dir.join(&self.shared.cfg.plugin_socket);
        // like the kubelet: dial the endpoint the plugin registered
        until("plugin socket", 5, || sock.exists()).await;
        DevicePluginClient::new(uds_channel(sock).await.unwrap())
    }
    async fn stop(mut self) {
        if let Some(t) = self.stop.take() {
            let _ = t.send(());
        }
        let r = tokio::time::timeout(Duration::from_secs(5), self.task).await.expect("plugin shutdown timed out").unwrap();
        assert!(r.is_ok(), "{r:?}");
    }
}

// ---------------------------------------------------------------------------------------------- tests
#[tokio::test(flavor = "multi_thread")]
async fn registers_with_resource_endpoint_and_options() {
    let d = tmpdir();
    let k = MockKubelet::start(&d);
    let p = Running::start(&d, Arc::new(Fake(Arc::new(Mutex::new(vec![dev("a", true), dev("b", true)])))), |_| {});
    until("registration", 5, || k.count() == 1).await;
    let r = k.reqs.lock().unwrap()[0].clone();
    assert_eq!(r.version, "v1beta1");
    assert_eq!(r.resource_name, "aureom.ai/silicaflux-dpu-sim");
    assert_eq!(r.endpoint, "aureom-silicaflux.sock");
    let o = r.options.unwrap();
    assert!(!o.pre_start_required && o.get_preferred_allocation_available);
    assert!(d.join(&r.endpoint).exists(), "the endpoint named in the registration must exist");
    let mut c = p.client().await;
    let o2 = c.get_device_plugin_options(Empty {}).await.unwrap().into_inner();
    assert_eq!((o2.pre_start_required, o2.get_preferred_allocation_available), (false, true));
    p.stop().await;
    assert!(!d.join("aureom-silicaflux.sock").exists(), "socket removed on shutdown");
    k.stop().await;
}

#[tokio::test(flavor = "multi_thread")]
async fn list_and_watch_streams_health_changes_and_removals() {
    let d = tmpdir();
    let k = MockKubelet::start(&d);
    let src = Fake(Arc::new(Mutex::new(vec![dev("a", true), dev("b", true)])));
    let p = Running::start(&d, Arc::new(src.clone()), |_| {});
    until("registration", 5, || k.count() == 1).await;
    let mut c = p.client().await;
    let mut st = c.list_and_watch(Empty {}).await.unwrap().into_inner();
    let first = st.message().await.unwrap().unwrap();
    assert_eq!(first.devices.iter().map(|x| (x.id.as_str(), x.health.as_str())).collect::<Vec<_>>(), vec![("a", "Healthy"), ("b", "Healthy")]);
    // a device goes unhealthy: the kubelet must hear about it without asking
    src.0.lock().unwrap()[1] = dev("b", false);
    let upd = tokio::time::timeout(Duration::from_secs(3), st.message()).await.expect("no update after the health change").unwrap().unwrap();
    assert_eq!(upd.devices.iter().find(|x| x.id == "b").unwrap().health, "Unhealthy");
    assert_eq!(upd.devices.iter().find(|x| x.id == "a").unwrap().health, "Healthy");
    // recovery
    src.0.lock().unwrap()[1] = dev("b", true);
    let upd = tokio::time::timeout(Duration::from_secs(3), st.message()).await.unwrap().unwrap().unwrap();
    assert!(upd.devices.iter().all(|x| x.health == "Healthy"));
    // removal
    src.0.lock().unwrap().remove(0);
    let upd = tokio::time::timeout(Duration::from_secs(3), st.message()).await.unwrap().unwrap().unwrap();
    assert_eq!(upd.devices.len(), 1);
    assert_eq!(p.shared.counters.health_transitions.load(Ordering::Relaxed), 2);
    // a second watcher gets the CURRENT state immediately
    let mut c2 = p.client().await;
    let mut st2 = c2.list_and_watch(Empty {}).await.unwrap().into_inner();
    assert_eq!(st2.message().await.unwrap().unwrap().devices.len(), 1);
    assert_eq!(p.shared.counters.watchers.load(Ordering::Relaxed), 2);
    drop(st);
    drop(st2);
    until("watchers to be reaped", 3, || {
        src.0.lock().unwrap().push(dev("z", true)); // provoke a send so closed streams are noticed
        src.0.lock().unwrap().retain(|x| x.id != "z" || true);
        p.shared.counters.watchers.load(Ordering::Relaxed) == 0
    })
    .await;
    p.stop().await;
    k.stop().await;
}

#[tokio::test(flavor = "multi_thread")]
async fn allocate_validates_devices_and_never_hands_out_device_nodes() {
    let d = tmpdir();
    let k = MockKubelet::start(&d);
    let src = Fake(Arc::new(Mutex::new(vec![dev("a", true), dev("b", false)])));
    let p = Running::start(&d, Arc::new(src), |c| c.cdi_kind = Some("aureom.ai/silicaflux-dpu-sim".into()));
    until("registration", 5, || k.count() == 1).await;
    let mut c = p.client().await;
    let req = |ids: &[&str]| AllocateRequest { container_requests: vec![ContainerAllocateRequest { devices_ids: ids.iter().map(|s| s.to_string()).collect() }] };
    let ok = c.allocate(req(&["a"])).await.unwrap().into_inner();
    let r = &ok.container_responses[0];
    assert_eq!(r.envs["SILICAFLUX_VISIBLE_DEVICES"], "a");
    assert_eq!(r.envs["SILICAFLUX_BACKEND"], "cpu-ref");
    assert!(r.devices.is_empty() && r.mounts.is_empty(), "containers must not receive device nodes or host mounts");
    assert_eq!(r.annotations["aureom.ai/silicaflux-simulated"], "true");
    assert_eq!(r.cdi_devices.iter().map(|x| x.name.as_str()).collect::<Vec<_>>(), vec!["aureom.ai/silicaflux-dpu-sim=a"]);
    // refusals carry the right gRPC codes
    assert_eq!(c.allocate(req(&["nope"])).await.unwrap_err().code(), Code::InvalidArgument);
    let e = c.allocate(req(&["b"])).await.unwrap_err();
    assert_eq!(e.code(), Code::FailedPrecondition);
    assert!(e.message().contains("unhealthy") && e.message().contains("injected"), "{}", e.message());
    assert_eq!(c.allocate(AllocateRequest { container_requests: vec![ContainerAllocateRequest { devices_ids: vec![] }] }).await.unwrap_err().code(), Code::InvalidArgument);
    // a mixed request fails as a whole and records nothing
    assert!(c.allocate(req(&["a", "b"])).await.is_err());
    // accounting
    let sh = &p.shared;
    assert_eq!(sh.counters.allocate_requests.load(Ordering::Relaxed), 5);
    assert_eq!(sh.counters.allocate_failures.load(Ordering::Relaxed), 4);
    assert_eq!(sh.counters.devices_allocated.load(Ordering::Relaxed), 1);
    assert_eq!(sh.ledger().len(), 1);
    assert_eq!(sh.ledger()[0].devices, vec!["a".to_string()]);
    assert_eq!(sh.per_device_allocations()["a"], 1);
    // PreStartContainer is a no-op (pre_start_required = false)
    c.pre_start_container(PreStartContainerRequest { devices_ids: vec!["a".into()] }).await.unwrap();
    // the metrics endpoint reflects the same numbers
    let addr = http::serve("127.0.0.1:0", sh.clone()).unwrap();
    let body = tokio::task::spawn_blocking(move || {
        use std::io::{Read, Write};
        let mut s = std::net::TcpStream::connect(addr).unwrap();
        write!(s, "GET /metrics HTTP/1.1\r\nHost: x\r\n\r\n").unwrap();
        let mut b = String::new();
        s.read_to_string(&mut b).unwrap();
        b
    })
    .await
    .unwrap();
    for want in [
        "silicaflux_plugin_devices{health=\"healthy\"} 1",
        "silicaflux_plugin_devices{health=\"unhealthy\"} 1",
        "silicaflux_plugin_allocate_failures_total 4",
        "silicaflux_plugin_device_allocations_total{device=\"a\"} 1",
        "silicaflux_plugin_registrations_total 1",
    ] {
        assert!(body.contains(want), "metrics missing `{want}`:\n{body}");
    }
    p.stop().await;
    k.stop().await;
}

#[tokio::test(flavor = "multi_thread")]
async fn preferred_allocation_spreads_and_honours_must_include() {
    let d = tmpdir();
    let k = MockKubelet::start(&d);
    let src = Fake(Arc::new(Mutex::new(vec![dev("a", true), dev("b", true), dev("c", true)])));
    let p = Running::start(&d, Arc::new(src), |_| {});
    until("registration", 5, || k.count() == 1).await;
    let mut c = p.client().await;
    let pref = |avail: &[&str], must: &[&str], n: i32| PreferredAllocationRequest {
        container_requests: vec![ContainerPreferredAllocationRequest {
            available_device_i_ds: avail.iter().map(|s| s.to_string()).collect(),
            must_include_device_i_ds: must.iter().map(|s| s.to_string()).collect(),
            allocation_size: n,
        }],
    };
    let ids = |r: PreferredAllocationResponse| r.container_responses[0].device_i_ds.clone();
    assert_eq!(ids(c.get_preferred_allocation(pref(&["c", "a", "b"], &[], 1)).await.unwrap().into_inner()), vec!["a"]);
    // use "a" twice: it is no longer preferred
    for _ in 0..2 {
        c.allocate(AllocateRequest { container_requests: vec![ContainerAllocateRequest { devices_ids: vec!["a".into()] }] }).await.unwrap();
    }
    assert_eq!(ids(c.get_preferred_allocation(pref(&["a", "b", "c"], &[], 2)).await.unwrap().into_inner()), vec!["b", "c"]);
    assert_eq!(ids(c.get_preferred_allocation(pref(&["a", "b", "c"], &["a"], 2)).await.unwrap().into_inner()), vec!["a", "b"]);
    assert_eq!(c.get_preferred_allocation(pref(&["a"], &[], 2)).await.unwrap_err().code(), Code::InvalidArgument);
    p.stop().await;
    k.stop().await;
}

#[tokio::test(flavor = "multi_thread")]
async fn kubelet_restart_triggers_reregistration_and_server_rebuild() {
    let d = tmpdir();
    let k1 = MockKubelet::start(&d);
    let p = Running::start(&d, Arc::new(Fake(Arc::new(Mutex::new(vec![dev("a", true)])))), |_| {});
    until("first registration", 5, || k1.count() == 1).await;
    let sock = d.join("aureom-silicaflux.sock");
    let mut c = p.client().await;
    assert_eq!(c.list_and_watch(Empty {}).await.unwrap().into_inner().message().await.unwrap().unwrap().devices.len(), 1);

    // --- kubelet restart: it exits and, on start, wipes every socket in the directory
    k1.stop().await;
    let _ = std::fs::remove_file(d.join("kubelet.sock"));
    std::fs::remove_file(&sock).unwrap();
    let k2 = MockKubelet::start(&d);
    until("re-registration with the new kubelet", 8, || k2.count() >= 1).await;
    tokio::time::sleep(Duration::from_millis(500)).await;
    assert_eq!(k2.count(), 1, "exactly one registration, and only after the plugin socket exists again");
    assert_eq!(k2.reqs.lock().unwrap()[0].resource_name, "aureom.ai/silicaflux-dpu-sim");
    assert!(sock.exists(), "the registered endpoint must exist");
    assert!(p.shared.counters.server_restarts.load(Ordering::Relaxed) >= 1, "the gRPC server must have been rebuilt");
    // the new socket serves real traffic
    let mut c = p.client().await;
    let r = c.allocate(AllocateRequest { container_requests: vec![ContainerAllocateRequest { devices_ids: vec!["a".into()] }] }).await.unwrap();
    assert_eq!(r.into_inner().container_responses.len(), 1);

    // --- kubelet restarts but the plugin socket survives: only a re-registration is needed
    k2.stop().await;
    let _ = std::fs::remove_file(d.join("kubelet.sock"));
    let k3 = MockKubelet::start(&d);
    until("re-registration after a kubelet-socket-only change", 8, || k3.count() == 1).await;
    assert!(p.shared.counters.registrations.load(Ordering::Relaxed) >= 3);
    p.stop().await;
    k3.stop().await;
}

#[tokio::test(flavor = "multi_thread")]
async fn plugin_waits_for_a_kubelet_that_starts_later() {
    let d = tmpdir();
    let p = Running::start(&d, Arc::new(Fake(Arc::new(Mutex::new(vec![dev("a", true)])))), |_| {});
    // no kubelet yet: the plugin serves, does not crash, and does not spin on failed registrations
    tokio::time::sleep(Duration::from_millis(600)).await;
    assert_eq!(p.shared.counters.registrations.load(Ordering::Relaxed), 0);
    assert!(d.join("aureom-silicaflux.sock").exists());
    let k = MockKubelet::start(&d);
    until("registration once the kubelet appears", 8, || k.count() == 1).await;
    p.stop().await;
    k.stop().await;
}

#[tokio::test(flavor = "multi_thread")]
async fn registration_rejected_by_the_kubelet_is_retried_not_fatal() {
    // a kubelet that refuses the first attempts (e.g. still starting): the plugin keeps trying
    struct Flaky(Arc<Mutex<u32>>, Arc<Mutex<Vec<RegisterRequest>>>);
    #[tonic::async_trait]
    impl Registration for Flaky {
        async fn register(&self, r: Request<RegisterRequest>) -> Result<Response<Empty>, Status> {
            let mut n = self.0.lock().unwrap();
            *n += 1;
            if *n < 3 {
                return Err(Status::unavailable("kubelet not ready"));
            }
            self.1.lock().unwrap().push(r.into_inner());
            Ok(Response::new(Empty {}))
        }
    }
    let d = tmpdir();
    let (tries, ok) = (Arc::new(Mutex::new(0)), Arc::new(Mutex::new(vec![])));
    let l = tokio::net::UnixListener::bind(d.join("kubelet.sock")).unwrap();
    let svc = RegistrationServer::new(Flaky(tries.clone(), ok.clone()));
    tokio::spawn(async move {
        let _ = tonic::transport::Server::builder().add_service(svc).serve_with_incoming(tokio_stream::wrappers::UnixListenerStream::new(l)).await;
    });
    let p = Running::start(&d, Arc::new(Fake(Arc::new(Mutex::new(vec![dev("a", true)])))), |_| {});
    until("successful registration after refusals", 10, || ok.lock().unwrap().len() == 1).await;
    assert!(*tries.lock().unwrap() >= 3);
    assert!(p.shared.counters.registration_failures.load(Ordering::Relaxed) >= 2);
    p.stop().await;
}

#[tokio::test(flavor = "multi_thread")]
async fn partitions_are_never_advertised_and_hardware_is_never_faked() {
    // a 2-tenant simulated device is advertised as ONE whole device, not as two partitions
    let d = tmpdir();
    let override_dir = d.join("override");
    std::fs::create_dir_all(&override_dir).unwrap();
    let src = SimulatedSource::new(&["cpu-ref".to_string(), "cpu-ref".to_string()], Some(override_dir.clone())).unwrap();
    let list = src.poll();
    assert_eq!(list.iter().map(|x| x.id.as_str()).collect::<Vec<_>>(), vec!["cpu-ref-0", "cpu-ref-1"], "one entry per DEVICE (each has 2 hardware tenants)");
    assert!(list.iter().all(|x| x.healthy && x.simulated));
    // operator override marks a device unhealthy
    std::fs::write(override_dir.join("cpu-ref-1"), b"").unwrap();
    let list = src.poll();
    assert!(list[0].healthy && !list[1].healthy && list[1].reason.contains("operator override"));
    std::fs::remove_file(override_dir.join("cpu-ref-1")).unwrap();
    assert!(src.poll()[1].healthy, "recovers when the override is removed");
    // hardware devices cannot be configured as simulated; hardware mode advertises nothing
    assert!(SimulatedSource::new(&["hw".to_string()], None).is_err());
    assert!(SimulatedSource::new(&["auto".to_string()], None).is_err());
    assert!(HardwareSource.poll().is_empty());
    // the full plugin with the hardware source: registers, lists nothing, allocates nothing
    let k = MockKubelet::start(&d);
    let p = Running::start(&d, Arc::new(HardwareSource), |c| c.resource_name = "aureom.ai/silicaflux-dpu".into());
    until("registration", 5, || k.count() == 1).await;
    assert_eq!(k.reqs.lock().unwrap()[0].resource_name, "aureom.ai/silicaflux-dpu");
    let mut c = p.client().await;
    assert!(c.list_and_watch(Empty {}).await.unwrap().into_inner().message().await.unwrap().unwrap().devices.is_empty());
    assert_eq!(
        c.allocate(AllocateRequest { container_requests: vec![ContainerAllocateRequest { devices_ids: vec!["hw-0".into()] }] }).await.unwrap_err().code(),
        Code::InvalidArgument
    );
    p.stop().await;
    k.stop().await;
}
