// Compiles the UPSTREAM kubelet device-plugin API (third_party/k8s/deviceplugin_v1beta1_api.proto, fetched verbatim
// from kubernetes/kubelet, see third_party/k8s/PROVENANCE.md) into Rust client + server stubs.  protoc comes from
// the `protoc-bin-vendored` crate, so no system protobuf compiler is needed.
fn main() {
    let protoc = protoc_bin_vendored::protoc_bin_path().expect("vendored protoc");
    std::env::set_var("PROTOC", protoc);
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../third_party/k8s");
    let proto = dir.join("deviceplugin_v1beta1_api.proto");
    println!("cargo:rerun-if-changed={}", proto.display());
    tonic_prost_build::configure().build_server(true).build_client(true).compile_protos(&[proto], &[dir]).expect("compile the device-plugin proto");
}
