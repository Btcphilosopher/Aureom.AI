// Independent interoperability check: a fake kubelet written against Kubernetes' OWN generated stubs
// (k8s.io/kubelet/pkg/apis/deviceplugin/v1beta1).  It serves Registration on <dir>/kubelet.sock, waits for the Rust
// plugin to register, then dials the registered endpoint and exercises the DevicePlugin service exactly like the
// kubelet does.  Exit status 0 only if every check passes.
package main

import (
	"context"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
	pluginapi "k8s.io/kubelet/pkg/apis/deviceplugin/v1beta1"
)

type registration struct {
	got chan *pluginapi.RegisterRequest
}

func (r *registration) Register(_ context.Context, req *pluginapi.RegisterRequest) (*pluginapi.Empty, error) {
	if req.Version != pluginapi.Version {
		return nil, fmt.Errorf("unsupported API version %q (kubelet speaks %q)", req.Version, pluginapi.Version)
	}
	r.got <- req
	return &pluginapi.Empty{}, nil
}

var failures int

func check(ok bool, format string, a ...any) {
	if ok {
		fmt.Printf("  ok   %s\n", fmt.Sprintf(format, a...))
	} else {
		failures++
		fmt.Printf("  FAIL %s\n", fmt.Sprintf(format, a...))
	}
}

func main() {
	if len(os.Args) < 3 {
		fmt.Println("usage: interop <socket-dir> <expected-resource> [unhealthy-override-file]")
		os.Exit(2)
	}
	dir, wantResource := os.Args[1], os.Args[2]
	sock := filepath.Join(dir, filepath.Base(pluginapi.KubeletSocket))
	_ = os.Remove(sock)
	lis, err := net.Listen("unix", sock)
	if err != nil {
		fmt.Println("listen:", err)
		os.Exit(2)
	}
	reg := &registration{got: make(chan *pluginapi.RegisterRequest, 4)}
	srv := grpc.NewServer()
	pluginapi.RegisterRegistrationServer(srv, reg)
	go srv.Serve(lis)
	defer srv.Stop()

	fmt.Println("waiting for the plugin to register ...")
	var req *pluginapi.RegisterRequest
	select {
	case req = <-reg.got:
	case <-time.After(30 * time.Second):
		fmt.Println("FAIL: the plugin never registered")
		os.Exit(1)
	}
	check(req.Version == pluginapi.Version, "registered API version %q", req.Version)
	check(req.ResourceName == wantResource, "resource name %q", req.ResourceName)
	check(req.Options != nil && req.Options.GetPreferredAllocationAvailable && !req.Options.PreStartRequired, "options %+v", req.Options)

	conn, err := grpc.Dial("unix://"+filepath.Join(dir, req.Endpoint), grpc.WithTransportCredentials(insecure.NewCredentials()), grpc.WithBlock(), grpc.WithTimeout(10*time.Second))
	if err != nil {
		fmt.Println("FAIL: dial endpoint:", err)
		os.Exit(1)
	}
	defer conn.Close()
	c := pluginapi.NewDevicePluginClient(conn)
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	opts, err := c.GetDevicePluginOptions(ctx, &pluginapi.Empty{})
	check(err == nil && opts.GetPreferredAllocationAvailable, "GetDevicePluginOptions %+v err=%v", opts, err)

	lw, err := c.ListAndWatch(ctx, &pluginapi.Empty{})
	if err != nil {
		fmt.Println("FAIL: ListAndWatch:", err)
		os.Exit(1)
	}
	first, err := lw.Recv()
	check(err == nil && len(first.Devices) >= 1, "ListAndWatch first response: %d device(s) err=%v", len(first.GetDevices()), err)
	ids := []string{}
	for _, d := range first.Devices {
		ids = append(ids, d.ID)
		check(d.Health == pluginapi.Healthy, "device %s health %q", d.ID, d.Health)
	}
	sort.Strings(ids)
	fmt.Println("  devices:", strings.Join(ids, ","))

	// Allocate exactly like the kubelet: one container request with one device
	al, err := c.Allocate(ctx, &pluginapi.AllocateRequest{ContainerRequests: []*pluginapi.ContainerAllocateRequest{{DevicesIDs: []string{ids[0]}}}})
	check(err == nil && len(al.ContainerResponses) == 1, "Allocate(%s) err=%v", ids[0], err)
	if err == nil {
		r := al.ContainerResponses[0]
		check(r.Envs["SILICAFLUX_VISIBLE_DEVICES"] == ids[0], "env SILICAFLUX_VISIBLE_DEVICES=%q", r.Envs["SILICAFLUX_VISIBLE_DEVICES"])
		check(len(r.Devices) == 0 && len(r.Mounts) == 0, "no device nodes / mounts handed out (devices=%d mounts=%d)", len(r.Devices), len(r.Mounts))
	}
	_, err = c.Allocate(ctx, &pluginapi.AllocateRequest{ContainerRequests: []*pluginapi.ContainerAllocateRequest{{DevicesIDs: []string{"no-such-device"}}}})
	check(status.Code(err) == codes.InvalidArgument, "Allocate(unknown) -> %v", status.Code(err))

	pa, err := c.GetPreferredAllocation(ctx, &pluginapi.PreferredAllocationRequest{ContainerRequests: []*pluginapi.ContainerPreferredAllocationRequest{{AvailableDeviceIDs: ids, AllocationSize: 1}}})
	check(err == nil && len(pa.ContainerResponses) == 1 && len(pa.ContainerResponses[0].DeviceIDs) == 1, "GetPreferredAllocation -> %+v err=%v", pa, err)
	_, err = c.PreStartContainer(ctx, &pluginapi.PreStartContainerRequest{DevicesIDs: ids[:1]})
	check(err == nil, "PreStartContainer err=%v", err)

	// optional: health change driven by an override file given as arg 3
	if len(os.Args) > 3 {
		f := os.Args[3]
		if err := os.WriteFile(f, nil, 0o644); err != nil {
			fmt.Println("cannot create override file:", err)
			os.Exit(2)
		}
		got := make(chan string, 1)
		go func() {
			for {
				m, err := lw.Recv()
				if err != nil {
					got <- "stream error: " + err.Error()
					return
				}
				for _, d := range m.Devices {
					if d.Health == pluginapi.Unhealthy {
						got <- "unhealthy " + d.ID
						return
					}
				}
			}
		}()
		select {
		case m := <-got:
			check(strings.HasPrefix(m, "unhealthy"), "ListAndWatch pushed the health change: %s", m)
		case <-time.After(20 * time.Second):
			check(false, "no health update within 20s")
		}
		_, err = c.Allocate(ctx, &pluginapi.AllocateRequest{ContainerRequests: []*pluginapi.ContainerAllocateRequest{{DevicesIDs: []string{ids[0]}}}})
		check(status.Code(err) == codes.FailedPrecondition, "Allocate(unhealthy device) -> %v", status.Code(err))
	}
	if failures > 0 {
		fmt.Printf("INTEROP: FAIL (%d)\n", failures)
		os.Exit(1)
	}
	fmt.Println("INTEROP: PASS (official k8s.io/kubelet stubs)")
}
