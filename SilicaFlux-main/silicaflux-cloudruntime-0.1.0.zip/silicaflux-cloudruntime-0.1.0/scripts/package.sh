#!/usr/bin/env bash
# Release package.  Writes dist/silicaflux-cloudruntime-<version>.zip containing sources, vendored RTL, docs, deployment
# files and benchmark reports (NOT target/, build/, dist/), plus MANIFEST.sha256 and BUILDINFO.txt.
# NO git operation is performed (nothing is committed, tagged or pushed).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
VER="$(sed -n 's/^version = "\(.*\)"/\1/p' Cargo.toml | head -1)"
NAME="silicaflux-cloudruntime-${VER}"
OUT="${OUT:-$ROOT/dist}"; mkdir -p "$OUT"
STAGE="$(mktemp -d)"; trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/$NAME"
# tracked-agnostic copy: everything except build outputs
tar --exclude=./target --exclude=./build --exclude=./dist --exclude=__pycache__ --exclude='*.pyc' --exclude=./.git -cf - . | tar -xf - -C "$STAGE/$NAME"
cat > "$STAGE/$NAME/BUILDINFO.txt" <<INFO
package        : $NAME
created (UTC)  : $(date -u +%Y-%m-%dT%H:%M:%SZ)
host           : $(uname -srm)
rustc          : $(rustc --version 2>/dev/null || echo n/a)
verilator      : $(verilator --version 2>/dev/null | head -1 || echo n/a)
gcc            : $(gcc --version 2>/dev/null | head -1 || echo n/a)
source         : release package (no git metadata inside; the sha256 manifest identifies the sources)
git operations : NONE were performed by the packaging script
status         : simulation-only runtime; no hardware support claimed; see README.md and docs/10_LIMITATIONS.md
INFO
( cd "$STAGE/$NAME" && find . -type f ! -name MANIFEST.sha256 | LC_ALL=C sort | xargs sha256sum > MANIFEST.sha256 )
( cd "$STAGE" && rm -f "$OUT/$NAME.zip" && find "$NAME" -type f | LC_ALL=C sort | zip -X -q "$OUT/$NAME.zip" -@ )
echo "wrote $OUT/$NAME.zip ($(du -h "$OUT/$NAME.zip" | cut -f1), $(unzip -Z1 "$OUT/$NAME.zip" | wc -l) files)"
( cd "$STAGE/$NAME" && sha256sum -c MANIFEST.sha256 --quiet && echo "manifest verifies ($(wc -l < MANIFEST.sha256) files)" )
