#!/usr/bin/env python3
"""Render benchmarks/results/*.json as the markdown tables used in docs/07_BENCHMARKS.md (no hand transcription)."""
import json, sys, os
R = os.path.join(os.path.dirname(__file__), "..", "benchmarks", "results")
rtl = json.load(open(os.path.join(R, "rtl-sim_mt.json")))
cpu = json.load(open(os.path.join(R, "cpu-ref_mt.json")))
def res(rep, name): return next(x for x in rep["results"] if x["benchmark"] == name)
def f(v, d=2): return f"{v:,.{d}f}" if isinstance(v, float) else f"{v:,}"
out = []
m = rtl["metadata"]
out.append(f"Report metadata (rtl-sim): git `{m['git']['revision'][:12]}` (dirty={m['git']['dirty']}), runtime {m['runtime_version']}, RTL {m['rtl_version']}, "
           f"{m['toolchain']['rustc']}, Verilator {m['toolchain']['verilator']}, CPU `{m['toolchain']['cpu']}`; `all_verified = {rtl['correctness']['all_verified']}`; `hardware_measurements = {rtl['hardware_measurements']}`.\n")
# packet
p = res(rtl, "network_packet_throughput"); c = res(rtl, "network_packet_throughput")["cpu_only_reference"]["by_frame_size"]
out.append("### Network packet throughput — FCS/checksum offload through the DPU (`PKT_PROCESS`/PASS, pipeline depth 12)\n")
out.append("| frame B | device cycles / frame | **bytes / device cycle** | CPU-only reference (memcpy+CRC32+csum, host wall) |\n|---:|---:|---:|---:|")
for r, cr in zip(p["metrics"]["by_frame_size"], c):
    out.append(f"| {int(r['frame_bytes'])} | {f(r['device_cycles_per_frame'],1)} | {f(r['bytes_per_device_cycle'],3)} | {f(cr['wall_mb_per_s'],0)} MB/s |")
# dma
d = res(rtl, "dma_bandwidth"); dc = d["cpu_only_reference"]["by_transfer_size"]
out.append("\n### DMA bandwidth — host→device then device→host, sequential operations\n")
out.append("| transfer B | device cycles (active) | **bytes / device cycle** (both directions counted) | CPU-only (two memcpy, host wall) |\n|---:|---:|---:|---:|")
for r, cr in zip(d["metrics"]["by_transfer_size"], dc):
    out.append(f"| {int(r['transfer_bytes'])} | {f(r['device_cycles_active'],0)} | {f(r['bytes_per_device_cycle'],3)} | {f(cr['wall_mb_per_s'],0)} MB/s |")
# latency
l = res(rtl, "memory_copy_latency"); lc = l["cpu_only_reference"]["by_size"]
out.append("\n### Memory-copy latency — one operation in flight (device cycles, exact DPU timestamps)\n")
out.append("| bytes | p50 | p99 | max | CPU-only p50 (host wall) |\n|---:|---:|---:|---:|---:|")
for r, cr in zip(l["metrics"]["by_size"], lc):
    out.append(f"| {int(r['bytes'])} | {f(r['device_cycles_p50'],0)} | {f(r['device_cycles_p99'],0)} | {f(r['device_cycles_max'],0)} | {f(cr['wall_us_p50'],2)} µs |")
# contention
t = res(rtl, "multi_tenant_contention")["metrics"]
out.append("\n### Multi-tenant contention — 2 tenants × 64 copies of 2 KiB, all submitted before any wait (`rtl-sim`)\n")
out.append("| metric | value |\n|---|---:|")
for k in ("solo_device_cycles", "two_tenants_device_cycles"):
    out.append(f"| {k} | {f(t[k],0)} |")
out.append(f"| slowdown vs ideal parallel (1.0 = second tenant free, 2.0 = fully serialised) | **{f(t['slowdown_vs_ideal_parallel'],2)}** |")
out.append(f"| per-tenant bytes/cycle | {', '.join(f(x,3) for x in t['tenant_bytes_per_cycle'])} |")
out.append(f"| Jain fairness index (throughput) | {f(t['jain_fairness_throughput'],3)} |")
# alloc
a = res(rtl, "resource_allocation_overhead")["metrics"]
out.append("\n### Resource-allocation overhead (`rtl-sim`)\n")
out.append("| metric | value |\n|---|---:|")
out.append(f"| alloc+free of a 64 B buffer, p50 / p99 (host wall) | {f(a['alloc_free_pair_ns_p50'],0)} ns / {f(a['alloc_free_pair_ns_p99'],0)} ns |")
out.append(f"| NOP: completion record created after (device cycles, p50) | {f(a['nop_completion_created_device_cycles_p50'],0)} |")
out.append(f"| NOP wall round trip p50 (software stack + simulation) | {f(a['nop_roundtrip_wall_us_p50'],0)} µs |")
out.append(f"| tenant provisioning incl. hardware SRAM scrub | {f(a['tenant_provision_device_cycles'],0)} device cycles ({f(a['tenant_provision_wall_ms'],1)} ms wall) |")
# software extensions
out.append("\n### Software-extension workloads (`cpu-ref` only; the RTL blocks these engines)\n")
out.append("| workload | through the runtime (host wall) | CPU-only direct call (host wall) | runtime overhead |\n|---|---:|---:|---:|")
for name, key, unit in (("tensor_throughput", "wall_gmac_per_s", "GMAC/s"), ("crypto_throughput", "wall_mb_per_s", "MB/s"), ("storage_iops", "wall_iops", "IOPS")):
    x = res(cpu, name); a1 = x["metrics"][key]; b1 = x["cpu_only_reference"][key]
    out.append(f"| {name.replace('_',' ')} | {f(a1,2)} {unit} | {f(b1,2)} {unit} | {f(b1/a1,1)}× |")
out.append("\n### Statuses\n")
out.append("| benchmark | rtl-sim | cpu-ref |\n|---|---|---|")
for x in rtl["results"]:
    y = res(cpu, x["benchmark"])
    out.append(f"| {x['benchmark']} | {x['status']} | {y['status']} |")
proj = rtl["assumed_clock_projection"]
out.append(f"\n### Assumed-clock projection @ {proj['assumed_clock_mhz']:.0f} MHz — ILLUSTRATIVE ONLY\n")
out.append("| benchmark | case | bytes/cycle | MB/s **at the assumed clock** |\n|---|---|---:|---:|")
for p_ in proj["projected_mb_per_s"]:
    out.append(f"| {p_['benchmark']} | {p_['case']} | {f(p_['bytes_per_device_cycle'],3)} | {f(p_['mb_per_s_at_assumed_clock'],1)} |")
print("\n".join(out))
