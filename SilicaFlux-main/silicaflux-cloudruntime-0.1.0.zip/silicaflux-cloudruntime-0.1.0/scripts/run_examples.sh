#!/usr/bin/env bash
# Runs every example on every available backend and checks the EXPECTED outcome:
#   a b f : pass (exit 0) on cpu-ref and on rtl-sim
#   c d e : pass on cpu-ref; on rtl-sim they MUST report UNSUPPORTED (exit 3) -- the RTL blocks those engines
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
PROFILE="${PROFILE:-release}"; FLAG=""; [ "$PROFILE" = release ] && FLAG="--release"
cargo build $FLAG -p sf-cloud --examples --quiet || exit 2
BIN="target/$PROFILE/examples"
BACKENDS=("cpu-ref:mt"); [ -f build/rtl/mt/libsfrtl_p61.so ] && BACKENDS+=("rtl-sim:mt")
declare -A EXAMPLES=( [a_packet_service]=1 [b_protected_copy]=1 [c_int8_inference]=0 [d_encrypted_processing]=0 [e_block_storage]=0 [f_multi_tenant]=1 )
fail=0
printf "%-24s %-10s %-9s %s\n" example backend expected result
for ex in a_packet_service b_protected_copy c_int8_inference d_encrypted_processing e_block_storage f_multi_tenant; do
  for be in "${BACKENDS[@]}"; do
    want=0; [[ $be == rtl-sim* && ${EXAMPLES[$ex]} == 0 ]] && want=3
    out=$("$BIN/$ex" --backend "$be" 2>&1); rc=$?
    [ -n "${VERBOSE:-}" ] && echo "$out"
    if [ $rc -eq $want ]; then res="ok (exit $rc)"; else res="UNEXPECTED exit $rc"; fail=1; echo "$out" | tail -8; fi
    printf "%-24s %-10s %-9s %s\n" "$ex" "${be%%:*}" "exit $want" "$res"
  done
done
exit $fail
