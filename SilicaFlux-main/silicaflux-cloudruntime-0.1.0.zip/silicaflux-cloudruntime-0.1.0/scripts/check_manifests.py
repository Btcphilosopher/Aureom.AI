#!/usr/bin/env python3
"""Static checks of the deployment manifests: they must parse and must not weaken the security model."""
import glob, os, sys
try:
    import yaml
except ImportError:
    print("pyyaml not installed: pip install pyyaml"); sys.exit(2)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors = []

def containers(doc):
    spec = doc.get("spec", {})
    tpl = spec.get("template", {}).get("spec", spec)
    return tpl.get("containers", []) + tpl.get("initContainers", []), tpl

for f in sorted(glob.glob(os.path.join(ROOT, "deploy/k8s/*.yaml"))):
    for doc in yaml.safe_load_all(open(f)):
        if not doc:
            continue
        kind, name = doc.get("kind"), doc.get("metadata", {}).get("name")
        where = f"{os.path.basename(f)}:{kind}/{name}"
        if kind in ("Pod", "DaemonSet", "Deployment"):
            cs, pod = containers(doc)
            if pod.get("automountServiceAccountToken") is not False:
                errors.append(f"{where}: must set automountServiceAccountToken: false")
            if pod.get("hostNetwork") or pod.get("hostPID") or pod.get("hostIPC"):
                errors.append(f"{where}: host namespaces are not allowed")
            for v in pod.get("volumes", []):
                hp = v.get("hostPath", {}).get("path")
                if hp and hp not in ("/var/lib/kubelet/device-plugins", "/var/run/cdi"):
                    errors.append(f"{where}: unexpected hostPath {hp}")
                if hp and kind != "DaemonSet":
                    errors.append(f"{where}: only the device-plugin DaemonSet may use hostPath")
            for c in cs:
                sc = c.get("securityContext", {})
                cn = f"{where}/{c['name']}"
                if sc.get("privileged") is not False: errors.append(f"{cn}: privileged must be false")
                if sc.get("allowPrivilegeEscalation") is not False: errors.append(f"{cn}: allowPrivilegeEscalation must be false")
                if sc.get("readOnlyRootFilesystem") is not True: errors.append(f"{cn}: readOnlyRootFilesystem must be true")
                if "ALL" not in sc.get("capabilities", {}).get("drop", []): errors.append(f"{cn}: must drop ALL capabilities")
                if not c.get("resources", {}).get("limits"): errors.append(f"{cn}: resource limits required")
                for e in c.get("volumeMounts", []):
                    if "/dev" == e.get("mountPath") or e.get("mountPath", "").startswith("/dev/"):
                        errors.append(f"{cn}: containers must not mount device paths")
                lim = c.get("resources", {}).get("limits", {})
                for r, v in lim.items():
                    if r.startswith("aureom.ai/"):
                        if r not in ("aureom.ai/silicaflux-dpu", "aureom.ai/silicaflux-dpu-sim"):
                            errors.append(f"{cn}: unknown resource {r}")
                        if not isinstance(v, int) or v < 1:
                            errors.append(f"{cn}: extended resource {r} must be a positive integer (whole devices only)")
                args = " ".join(c.get("args", []))
                if "--advertise-partitions" in args:
                    errors.append(f"{cn}: partitions must not be advertised")
                if "--mode=simulated" in args:
                    sel = pod.get("nodeSelector", {})
                    if not sel.get("aureom.ai/silicaflux"):
                        errors.append(f"{cn}: simulated mode must be opt-in via a nodeSelector")
if errors:
    print("MANIFEST CHECK FAILED"); [print(" -", e) for e in errors]; sys.exit(1)
print("manifests ok:", ", ".join(os.path.basename(p) for p in sorted(glob.glob(os.path.join(ROOT, "deploy/k8s/*.yaml")))))
