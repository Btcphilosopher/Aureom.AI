#!/usr/bin/env bash
# What CI runs.  Exit status 0 only if every check passes.  (Go interop is optional: needs Go + network.)
set -euo pipefail
cd "$(dirname "$0")/.."
make ci
if command -v go >/dev/null 2>&1; then make interop; else echo "go not installed: skipping the k8s interop check"; fi
echo "CI OK"
