#!/usr/bin/env bash
# Independent protocol check: the Rust device plugin vs a fake kubelet built on Kubernetes' OWN generated stubs
# (k8s.io/kubelet).  Needs: Go >= 1.22 (module download from proxy.golang.org), a built sf-device-plugin.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PLUGIN="${PLUGIN:-$ROOT/target/debug/sf-device-plugin}"
[ -x "$PLUGIN" ] || { echo "build first: cargo build -p sf-device-plugin"; exit 2; }
TMP="$(mktemp -d)"; trap 'kill $PP 2>/dev/null || true; rm -rf "$TMP"' EXIT
( cd "$ROOT/tests/k8s-interop" && GOFLAGS=-mod=mod go build -o "$TMP/interop" . )
mkdir -p "$TMP/ovr"
( "$TMP/interop" "$TMP" aureom.ai/silicaflux-dpu-sim "$TMP/ovr/cpu-ref-0" > "$TMP/go.log" 2>&1; echo "exit=$?" >> "$TMP/go.log" ) &
sleep 1
"$PLUGIN" --mode simulated --sim-devices cpu-ref,cpu-ref --socket-dir "$TMP" --override-dir "$TMP/ovr" \
          --health-interval-secs 1 --cdi --cdi-dir "$TMP/cdi" > "$TMP/plugin.log" 2>&1 &
PP=$!
for _ in $(seq 1 120); do grep -q '^exit=' "$TMP/go.log" 2>/dev/null && break; sleep 0.5; done
cat "$TMP/go.log"
grep -q 'INTEROP: PASS' "$TMP/go.log" && grep -q '^exit=0' "$TMP/go.log"
python3 - "$TMP/cdi" <<'PY'
import json, glob, sys
files = glob.glob(sys.argv[1] + "/*.json")
assert files, "no CDI spec was written"
for f in files:
    j = json.load(open(f))
    assert j["cdiVersion"] == "0.6.0" and j["kind"].startswith("aureom.ai/") and j["devices"], f
    print("CDI spec ok:", j["kind"], [d["name"] for d in j["devices"]])
PY
