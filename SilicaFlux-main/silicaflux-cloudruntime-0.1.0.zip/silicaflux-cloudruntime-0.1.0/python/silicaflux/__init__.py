"""Python bindings for the SilicaFlux CloudRuntime C ABI (ctypes; no compilation step).

    import silicaflux as sf
    with sf.Device.open("cpu-ref") as dev:          # or "rtl-sim:mt", "auto"
        src = dev.alloc(1000, sf.MEM_DEV_READ);  dst = dev.alloc(1000, sf.MEM_DEV_WRITE)
        dev.write(src, data)
        c = dev.wait(dev.submit(sf.OP_PKT_PROCESS, src=src, dst=dst, length=1000,
                                proc_op=sf.PROC_XOR32, proc_param=0xA5A5A5A5))
        out = dev.read(dst, 1000)

Every call returns/raises explicitly: failures raise SilicaFluxError carrying the C status code and the library's
detail message.  Which backend is behind a Device is always visible in dev.info() -- check it before drawing
conclusions from timings (cpu-ref and rtl-sim are NOT hardware).
"""
from __future__ import annotations

import ctypes as C
import os
from dataclasses import dataclass
from typing import List, Optional

ABI_MAJOR, ABI_MINOR = 1, 0

# status codes (include/sf_cloud.h)
SF_OK = 0
STATUS_NAMES = {0: "SF_OK", -1: "SF_ERR_INVALID_ARG", -2: "SF_ERR_UNSUPPORTED", -3: "SF_ERR_NO_DEVICE", -4: "SF_ERR_PERMISSION",
                -5: "SF_ERR_NO_MEMORY", -6: "SF_ERR_BUSY", -7: "SF_ERR_STALE_HANDLE", -8: "SF_ERR_TIMEOUT", -9: "SF_ERR_QUEUE_FULL",
                -10: "SF_ERR_DEVICE_FAULT", -11: "SF_ERR_TENANT_STATE", -12: "SF_ERR_ISOLATION", -13: "SF_ERR_ALIGNMENT",
                -14: "SF_ERR_RANGE", -15: "SF_ERR_NOT_READY", -16: "SF_ERR_CRYPTO_AUTH", -17: "SF_ERR_ABI_MISMATCH",
                -18: "SF_ERR_RESET", -19: "SF_ERR_INTERNAL", -20: "SF_ERR_BAD_DESCRIPTOR", -21: "SF_ERR_QUOTA"}
OPEN_STANDALONE, OPEN_MEDIATOR = 0x1, 0x2
MEM_HOST, MEM_DEVICE, MEM_DEV_READ, MEM_DEV_WRITE = 0x0, 0x1, 0x2, 0x4
CAPS = {"nop": 1 << 0, "dma": 1 << 1, "pkt_process": 1 << 2, "gemm_i8": 1 << 3, "aes_gcm": 1 << 4, "storage": 1 << 5, "telemetry": 1 << 6}
OP_NOP, OP_PKT_PROCESS, OP_COPY, OP_DMA_H2D, OP_DMA_D2H, OP_GEMM_I8, OP_AES_GCM, OP_STORAGE_WRITE, OP_STORAGE_READ = range(9)
PROC_PASS, PROC_XOR32, PROC_BSWAP32 = 0, 1, 2
RESET_DATAPLANE, RESET_HARD = 0x1, 0x2


class SilicaFluxError(Exception):
    def __init__(self, status: int, detail: str):
        self.status = status
        self.name = STATUS_NAMES.get(status, f"SF_ERR_{status}")
        self.detail = detail
        super().__init__(f"{self.name}: {detail}")


class _OpenParams(C.Structure):
    _fields_ = [("struct_size", C.c_uint32), ("abi_major", C.c_uint32), ("backend", C.c_char_p), ("flags", C.c_uint32),
                ("tenant", C.c_uint32), ("default_timeout_ms", C.c_uint64)]


class _Info(C.Structure):
    _fields_ = [("struct_size", C.c_uint32), ("abi_major", C.c_uint32), ("abi_minor", C.c_uint32), ("dpu_abi_major", C.c_uint32),
                ("dpu_abi_minor", C.c_uint32), ("runtime_version", C.c_char * 16), ("backend", C.c_char * 16),
                ("backend_description", C.c_char * 192), ("timing_model", C.c_char * 112), ("measured_on_hardware", C.c_uint32),
                ("caps", C.c_uint32), ("tenants", C.c_uint32), ("net_queues", C.c_uint32), ("compute_queues", C.c_uint32),
                ("dma_channels", C.c_uint32), ("data_width", C.c_uint32), ("address_width", C.c_uint32), ("windows", C.c_uint32),
                ("sram_bytes", C.c_uint32), ("max_xfer", C.c_uint32), ("block_status", C.c_uint32), ("tenant", C.c_uint32),
                ("admin", C.c_uint32), ("health", C.c_uint32), ("thermal", C.c_uint32), ("health_detail", C.c_char * 192)]


class _TenantConfig(C.Structure):
    _fields_ = [("struct_size", C.c_uint32), ("sram_bytes", C.c_uint32), ("host_in_bytes", C.c_uint64), ("host_out_bytes", C.c_uint64),
                ("max_buffers", C.c_uint32), ("max_inflight", C.c_uint32), ("max_keys", C.c_uint32), ("chunk_bytes", C.c_uint32),
                ("staging_slots", C.c_uint32), ("quarantine_on_violation", C.c_uint32)]


class _Op(C.Structure):
    _fields_ = [("struct_size", C.c_uint32), ("kind", C.c_uint32), ("src", C.c_uint64), ("dst", C.c_uint64), ("aux", C.c_uint64),
                ("src_off", C.c_uint64), ("dst_off", C.c_uint64), ("aux_off", C.c_uint64), ("length", C.c_uint64),
                ("proc_op", C.c_uint32), ("proc_param", C.c_uint32), ("m", C.c_uint32), ("n", C.c_uint32), ("k", C.c_uint32),
                ("key", C.c_uint64), ("encrypt", C.c_uint32), ("aad_len", C.c_uint32), ("aad", C.c_void_p), ("iv", C.c_uint8 * 12),
                ("blocks", C.c_uint32), ("lba", C.c_uint64)]


class _Completion(C.Structure):
    _fields_ = [("struct_size", C.c_uint32), ("kind", C.c_uint32), ("status", C.c_int32), ("dev_err", C.c_uint32), ("bytes", C.c_uint64),
                ("crc_in", C.c_uint32), ("crc_out", C.c_uint32), ("has_crc", C.c_uint32), ("csum", C.c_uint32),
                ("committed", C.c_uint32), ("chunks", C.c_uint32), ("latency_cycles", C.c_uint64), ("latency_ns", C.c_uint64)]


class _Counters(C.Structure):
    _fields_ = [("struct_size", C.c_uint32), ("tenant", C.c_uint32), ("t_submitted", C.c_uint64), ("t_completed", C.c_uint64),
                ("t_errors", C.c_uint64), ("t_bytes_ok", C.c_uint64), ("t_cross_tenant_attempts", C.c_uint64),
                ("t_buffers", C.c_uint32), ("t_keys", C.c_uint32), ("t_inflight", C.c_uint32), ("t_state", C.c_uint32),
                ("t_host_bytes", C.c_uint64), ("t_device_bytes", C.c_uint64), ("t_dev_cmds", C.c_uint64), ("t_dev_bytes", C.c_uint64),
                ("t_dev_violations", C.c_uint32), ("t_dev_errors", C.c_uint32), ("device_valid", C.c_uint32), ("reserved", C.c_uint32),
                ("cycles", C.c_uint64), ("d_cmds_accepted", C.c_uint64), ("d_cmds_retired", C.c_uint64), ("d_cmds_error", C.c_uint64),
                ("d_dma_bytes_rd", C.c_uint64), ("d_dma_bytes_wr", C.c_uint64), ("d_active_cycles", C.c_uint64),
                ("d_stall_any", C.c_uint64), ("d_violations", C.c_uint64), ("d_host_errors", C.c_uint64), ("d_timeouts", C.c_uint64),
                ("d_submitted", C.c_uint64), ("d_ok", C.c_uint64), ("d_failed", C.c_uint64), ("d_resets_soft", C.c_uint64),
                ("d_resets_hard", C.c_uint64)]


class _Event(C.Structure):
    _fields_ = [("ts", C.c_uint32), ("arg", C.c_uint32), ("event", C.c_uint8), ("tenant", C.c_uint8), ("queue", C.c_uint8), ("reserved", C.c_uint8)]


class _DeviceDesc(C.Structure):
    _fields_ = [("id", C.c_char * 32), ("kind", C.c_char * 16), ("available", C.c_uint32), ("reserved", C.c_uint32),
                ("description", C.c_char * 160), ("reason", C.c_char * 192)]


def _find_lib() -> str:
    cands = [os.environ.get("SF_CLOUD_LIB", "")]
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.abspath(os.path.join(here, "..", ".."))
    for prof in ("release", "debug"):
        cands.append(os.path.join(root, "target", prof, "libsf_cloud.so"))
    cands.append("libsf_cloud.so")
    for c in cands:
        if c and (os.path.isfile(c) or c == "libsf_cloud.so"):
            return c
    raise OSError("libsf_cloud.so not found: build it (cargo build --release -p sf-cloud) or set SF_CLOUD_LIB")


_lib: Optional[C.CDLL] = None


def lib() -> C.CDLL:
    global _lib
    if _lib is None:
        L = C.CDLL(_find_lib())
        P, U32, U64 = C.POINTER, C.c_uint32, C.c_uint64
        sig = {
            "sf_cloud_version": (None, [P(U32), P(U32), P(C.c_char_p)]),
            "sf_cloud_status_str": (C.c_char_p, [C.c_int32]),
            "sf_cloud_last_error": (C.c_char_p, []),
            "sf_cloud_discover": (C.c_int32, [P(_DeviceDesc), C.c_size_t, P(C.c_size_t)]),
            "sf_cloud_open": (C.c_int32, [P(_OpenParams), P(C.c_void_p)]),
            "sf_cloud_close": (C.c_int32, [C.c_void_p]),
            "sf_cloud_info": (C.c_int32, [C.c_void_p, P(_Info)]),
            "sf_cloud_provision_tenant": (C.c_int32, [C.c_void_p, U32, P(_TenantConfig), C.c_char_p]),
            "sf_cloud_deprovision_tenant": (C.c_int32, [C.c_void_p, U32]),
            "sf_cloud_open_session": (C.c_int32, [C.c_void_p, U32, C.c_char_p, P(C.c_void_p)]),
            "sf_cloud_reset": (C.c_int32, [C.c_void_p, U32]),
            "sf_cloud_set_thermal": (C.c_int32, [C.c_void_p, U32, C.c_float]),
            "sf_cloud_metrics": (C.c_int32, [C.c_void_p, C.c_char_p, C.c_size_t, P(C.c_size_t)]),
            "sf_cloud_alloc": (C.c_int32, [C.c_void_p, U64, U32, P(U64)]),
            "sf_cloud_free": (C.c_int32, [C.c_void_p, U64]),
            "sf_cloud_write": (C.c_int32, [C.c_void_p, U64, U64, C.c_char_p, C.c_size_t]),
            "sf_cloud_read": (C.c_int32, [C.c_void_p, U64, U64, C.c_void_p, C.c_size_t]),
            "sf_cloud_key_load": (C.c_int32, [C.c_void_p, C.c_char_p, C.c_size_t, P(U64)]),
            "sf_cloud_key_unload": (C.c_int32, [C.c_void_p, U64]),
            "sf_cloud_submit": (C.c_int32, [C.c_void_p, P(_Op), P(U64)]),
            "sf_cloud_poll": (C.c_int32, [C.c_void_p, U64, P(_Completion)]),
            "sf_cloud_wait": (C.c_int32, [C.c_void_p, U64, U64, P(_Completion)]),
            "sf_cloud_counters": (C.c_int32, [C.c_void_p, P(_Counters)]),
            "sf_cloud_telemetry": (C.c_int32, [C.c_void_p, P(_Event), C.c_size_t, P(C.c_size_t)]),
            "sf_cloud_abi_sizes": (C.c_int32, [P(U32), P(C.c_size_t)]),
        }
        for name, (res, args) in sig.items():
            f = getattr(L, name)
            f.restype, f.argtypes = res, args
        _lib = L
    return _lib


def _check(st: int) -> None:
    if st != SF_OK:
        msg = lib().sf_cloud_last_error()
        raise SilicaFluxError(st, msg.decode("utf-8", "replace") if msg else "")


def abi_check() -> None:
    """Verify that the ctypes struct layouts equal the library's (catches header/binding drift)."""
    sizes = (C.c_uint32 * 16)()
    n = C.c_size_t()
    _check(lib().sf_cloud_abi_sizes(sizes, C.byref(n)))
    want = [C.sizeof(x) for x in (_OpenParams, _TenantConfig, _Op, _Completion, _Counters, _Event, _DeviceDesc)]
    got = [sizes[0], sizes[2], sizes[3], sizes[4], sizes[5], sizes[6], sizes[7]]
    if want != got or sizes[1] != C.sizeof(_Info):
        raise AssertionError(f"ctypes layout differs from the library: python {want + [C.sizeof(_Info)]} vs library {got + [sizes[1]]}")


def discover() -> List[dict]:
    arr = (_DeviceDesc * 32)()
    n = C.c_size_t()
    _check(lib().sf_cloud_discover(arr, 32, C.byref(n)))
    return [{"id": d.id.decode(), "kind": d.kind.decode(), "available": bool(d.available), "description": d.description.decode(), "reason": d.reason.decode()}
            for d in arr[:min(n.value, 32)]]


@dataclass
class Completion:
    kind: int
    status: int
    dev_err: int
    bytes: int
    crc_in: Optional[int]
    crc_out: Optional[int]
    csum: Optional[int]
    committed: bool
    chunks: int
    latency_cycles: int
    latency_ns: int

    @property
    def ok(self) -> bool:
        return self.status == SF_OK


class Device:
    """A handle on a SilicaFlux device (tenant session; admin too when opened standalone)."""

    def __init__(self, handle: C.c_void_p):
        self._h = handle

    @classmethod
    def open(cls, backend: str = "auto", tenant: int = 0, timeout_ms: int = 10000) -> "Device":
        p = _OpenParams(C.sizeof(_OpenParams), ABI_MAJOR, backend.encode(), OPEN_STANDALONE, tenant, timeout_ms)
        h = C.c_void_p()
        _check(lib().sf_cloud_open(C.byref(p), C.byref(h)))
        return cls(h)

    def close(self) -> None:
        if self._h:
            h, self._h = self._h, None
            _check(lib().sf_cloud_close(h))

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def info(self) -> dict:
        i = _Info()
        i.struct_size = C.sizeof(_Info)
        _check(lib().sf_cloud_info(self._h, C.byref(i)))
        d = {f: getattr(i, f) for f, _ in _Info._fields_ if not f.endswith(("_description", "_version", "_model", "_detail")) and f not in ("backend", "struct_size")}
        d.update(backend=i.backend.decode(), backend_description=i.backend_description.decode(), timing_model=i.timing_model.decode(),
                 runtime_version=i.runtime_version.decode(), health_detail=i.health_detail.decode(),
                 caps={k: bool(i.caps & v) for k, v in CAPS.items()}, measured_on_hardware=bool(i.measured_on_hardware))
        return d

    def alloc(self, size: int, flags: int = 0) -> int:
        h = C.c_uint64()
        _check(lib().sf_cloud_alloc(self._h, size, flags, C.byref(h)))
        return h.value

    def free(self, buf: int) -> None:
        _check(lib().sf_cloud_free(self._h, buf))

    def write(self, buf: int, data: bytes, offset: int = 0) -> None:
        _check(lib().sf_cloud_write(self._h, buf, offset, bytes(data), len(data)))

    def read(self, buf: int, n: int, offset: int = 0) -> bytes:
        out = C.create_string_buffer(n)
        _check(lib().sf_cloud_read(self._h, buf, offset, out, n))
        return out.raw[:n]

    def key_load(self, key: bytes) -> int:
        h = C.c_uint64()
        _check(lib().sf_cloud_key_load(self._h, bytes(key), len(key), C.byref(h)))
        return h.value

    def key_unload(self, key: int) -> None:
        _check(lib().sf_cloud_key_unload(self._h, key))

    def submit(self, kind: int, *, src: int = 0, dst: int = 0, aux: int = 0, src_off: int = 0, dst_off: int = 0, aux_off: int = 0,
               length: int = 0, proc_op: int = 0, proc_param: int = 0, m: int = 0, n: int = 0, k: int = 0, key: int = 0,
               encrypt: bool = True, aad: bytes = b"", iv: bytes = b"\0" * 12, blocks: int = 0, lba: int = 0) -> int:
        op = _Op()
        op.struct_size, op.kind = C.sizeof(_Op), kind
        op.src, op.dst, op.aux, op.src_off, op.dst_off, op.aux_off, op.length = src, dst, aux, src_off, dst_off, aux_off, length
        op.proc_op, op.proc_param, op.m, op.n, op.k, op.key, op.encrypt = proc_op, proc_param, m, n, k, key, int(encrypt)
        aad_buf = C.create_string_buffer(bytes(aad), max(1, len(aad)))
        op.aad_len, op.aad = len(aad), C.cast(aad_buf, C.c_void_p)
        for i, b in enumerate(iv[:12]):
            op.iv[i] = b
        op.blocks, op.lba = blocks, lba
        t = C.c_uint64()
        _check(lib().sf_cloud_submit(self._h, C.byref(op), C.byref(t)))
        return t.value

    @staticmethod
    def _completion(c: _Completion) -> Completion:
        return Completion(c.kind, c.status, c.dev_err, c.bytes, c.crc_in if c.has_crc else None, c.crc_out if c.has_crc else None,
                          c.csum if c.has_crc else None, bool(c.committed), c.chunks, c.latency_cycles, c.latency_ns)

    def poll(self, ticket: int) -> Optional[Completion]:
        """Completion if finished, None while running."""
        c = _Completion()
        c.struct_size = C.sizeof(_Completion)
        st = lib().sf_cloud_poll(self._h, ticket, C.byref(c))
        if st == -15:
            return None
        _check(st)
        return self._completion(c)

    def wait(self, ticket: int, timeout_ms: int = 10000) -> Completion:
        c = _Completion()
        c.struct_size = C.sizeof(_Completion)
        _check(lib().sf_cloud_wait(self._h, ticket, timeout_ms, C.byref(c)))
        return self._completion(c)

    def counters(self) -> dict:
        c = _Counters()
        c.struct_size = C.sizeof(_Counters)
        _check(lib().sf_cloud_counters(self._h, C.byref(c)))
        return {f: getattr(c, f) for f, _ in _Counters._fields_ if f not in ("struct_size", "reserved")}

    def telemetry(self, max_events: int = 256) -> List[dict]:
        arr = (_Event * max_events)()
        n = C.c_size_t()
        _check(lib().sf_cloud_telemetry(self._h, arr, max_events, C.byref(n)))
        return [{"ts": e.ts, "arg": e.arg, "event": e.event, "tenant": e.tenant, "queue": e.queue} for e in arr[:n.value]]

    def metrics(self) -> str:
        need = C.c_size_t()
        lib().sf_cloud_metrics(self._h, None, 0, C.byref(need))
        buf = C.create_string_buffer(need.value + 1)
        _check(lib().sf_cloud_metrics(self._h, buf, len(buf), C.byref(need)))
        return buf.value.decode()

    def reset(self, hard: bool = False) -> None:
        _check(lib().sf_cloud_reset(self._h, RESET_HARD if hard else RESET_DATAPLANE))
