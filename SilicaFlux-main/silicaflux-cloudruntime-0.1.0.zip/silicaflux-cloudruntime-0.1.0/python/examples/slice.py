#!/usr/bin/env python3
"""The vertical slice from Python.  Usage: slice.py [backend]   (default: auto)"""
import os, sys, zlib
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import silicaflux as sf

backend = sys.argv[1] if len(sys.argv) > 1 else "auto"
print("devices:", [(d["id"], d["available"]) for d in sf.discover()])
with sf.Device.open(backend) as dev:
    i = dev.info()
    print(f"opened {i['backend']} ({i['timing_model']}); measured_on_hardware={i['measured_on_hardware']}; caps={[k for k, v in i['caps'].items() if v]}")
    data = os.urandom(1500)
    src, dst = dev.alloc(len(data), sf.MEM_DEV_READ), dev.alloc(len(data), sf.MEM_DEV_WRITE)
    dev.write(src, data)
    c = dev.wait(dev.submit(sf.OP_COPY, src=src, dst=dst, length=len(data)))
    assert dev.read(dst, len(data)) == data and c.committed and c.crc_in == c.crc_out == zlib.crc32(data)
    print(f"copy OK: committed={c.committed} crc32={c.crc_in:08x} latency={c.latency_cycles} device cycles")
    print("counters:", {k: v for k, v in dev.counters().items() if k in ("t_submitted", "t_bytes_ok", "d_cmds_retired", "d_dma_bytes_rd", "d_dma_bytes_wr")})
