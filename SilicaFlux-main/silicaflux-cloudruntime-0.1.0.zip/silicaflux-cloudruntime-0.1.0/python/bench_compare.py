#!/usr/bin/env python3
"""Compare sf-bench JSON reports (experimentation helper).  Usage: bench_compare.py report1.json [report2.json ...]

Prints, per benchmark, the numbers side by side WITH their measurement source, and refuses to put simulation wall-clock
figures next to CPU-only figures as if they were comparable performance (they are not: for rtl-sim the wall clock is
simulation speed)."""
import json, sys

def main(paths):
    reps = [json.load(open(p)) for p in paths]
    for r in reps:
        b = r["metadata"]["device_backend"]
        print(f"== {b['name']}  timing: {b['timing_model']}  measured_on_hardware={b['measured_on_hardware']}  verified={r['correctness']['all_verified']}  git={r['metadata']['git']['revision'][:12]}")
        print(f"   hardware_measurements: {r['hardware_measurements'] or 'NONE (no physical device has been run)'}")
        for x in r["results"]:
            if x["status"] != "ok":
                print(f"   {x['benchmark']:<32} {x['status']}: {x.get('reason','')[:90]}")
                continue
            m = x["metrics"]
            for k, v in m.items():
                if isinstance(v, list) and v and isinstance(v[0], dict):
                    for row in v:
                        keys = [kk for kk in row if "device_cycles" in kk or "bytes_per_device" in kk or kk.endswith("wall_mb_per_s")]
                        print(f"   {x['benchmark']:<32} " + ", ".join(f"{kk}={row[kk]:.3g}" for kk in list(row)[:1] + keys[:3] if isinstance(row[kk], (int, float))))
            cpu = x.get("cpu_only_reference")
            if cpu:
                print(f"   {'':<32} cpu-only reference ({cpu.get('what','')[:60]})")
        proj = r.get("assumed_clock_projection")
        if isinstance(proj, dict):
            print(f"   !! assumed-clock projection @ {proj['assumed_clock_mhz']} MHz is an ASSUMPTION, not a result:")
            for p in proj["projected_mb_per_s"]:
                print(f"      {p['benchmark']:<28} {p['case']:<22} {p['mb_per_s_at_assumed_clock']:.1f} MB/s")
        print()

if __name__ == "__main__":
    main(sys.argv[1:] or ["benchmarks/results/rtl-sim_mt.json", "benchmarks/results/cpu-ref_mt.json"])
