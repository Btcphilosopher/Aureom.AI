"""Tests of the Python binding.  Run:  python3 -m unittest discover -s python/tests -v   (from runtime/cloud)"""
import os
import sys
import unittest
import zlib

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import silicaflux as sf  # noqa: E402


def backends():
    out = ["cpu-ref:mt"]
    if any(d["id"] == "rtl-sim:mt" and d["available"] for d in sf.discover()):
        out.append("rtl-sim:mt")
    elif os.environ.get("SF_REQUIRE_RTL") == "1":
        raise AssertionError("SF_REQUIRE_RTL=1 but rtl-sim:mt is unavailable")
    return out


def xor32(data: bytes, param: int) -> bytes:
    k = param.to_bytes(4, "little")
    return bytes(b ^ k[i % 4] for i, b in enumerate(data))


class Binding(unittest.TestCase):
    def test_abi_layout_matches_library(self):
        sf.abi_check()

    def test_discovery_never_offers_hardware(self):
        devs = sf.discover()
        self.assertTrue(any(d["id"] == "cpu-ref:0" and d["available"] for d in devs))
        for d in devs:
            self.assertTrue(d["reason"], d)
            if d["kind"] == "hw":
                self.assertFalse(d["available"])
        with self.assertRaises(sf.SilicaFluxError) as e:
            sf.Device.open("hw")
        self.assertEqual(e.exception.name, "SF_ERR_NO_DEVICE")
        self.assertIn("not implemented", e.exception.detail)

    def test_vertical_slice_on_every_backend(self):
        for be in backends():
            with sf.Device.open(be) as dev:
                info = dev.info()
                self.assertFalse(info["measured_on_hardware"], be)
                self.assertTrue(info["caps"]["pkt_process"])
                data = bytes((i * 7 + 3) & 0xFF for i in range(1000))
                src, dst = dev.alloc(1000, sf.MEM_DEV_READ), dev.alloc(1000, sf.MEM_DEV_WRITE)
                dev.write(src, data)
                c = dev.wait(dev.submit(sf.OP_PKT_PROCESS, src=src, dst=dst, length=1000, proc_op=sf.PROC_XOR32, proc_param=0xA5A5A5A5))
                self.assertTrue(c.ok and c.committed and c.bytes == 1000, (be, c))
                out = dev.read(dst, 1000)
                self.assertEqual(out, xor32(data, 0xA5A5A5A5), be)
                self.assertEqual(c.crc_in, zlib.crc32(data), be)          # independent reference: zlib's CRC-32
                self.assertEqual(c.crc_out, zlib.crc32(out), be)
                cn = dev.counters()
                self.assertEqual((cn["t_submitted"], cn["t_completed"], cn["t_bytes_ok"]), (1, 1, 1000))
                self.assertGreaterEqual(cn["d_dma_bytes_rd"], 1000)
                self.assertTrue(any(e["event"] == 1 for e in dev.telemetry()))
                m = dev.metrics()
                self.assertIn('measured_on_hardware="false"', m)
                self.assertIn('silicaflux_thermal_state{state="unavailable"} 1', m)
                dev.free(src)
                dev.free(dst)

    def test_errors_are_explicit(self):
        with sf.Device.open("cpu-ref:mt") as dev:
            b = dev.alloc(64, sf.MEM_DEV_WRITE)
            with self.assertRaises(sf.SilicaFluxError) as e:
                dev.read(b, 100)
            self.assertEqual(e.exception.name, "SF_ERR_RANGE")
            dev.free(b)
            with self.assertRaises(sf.SilicaFluxError) as e:
                dev.free(b)
            self.assertEqual(e.exception.name, "SF_ERR_STALE_HANDLE")
            with self.assertRaises(sf.SilicaFluxError) as e:
                dev.alloc(0)
            self.assertEqual(e.exception.name, "SF_ERR_INVALID_ARG")

    def test_unsupported_workload_fails_clearly_on_rtl(self):
        if "rtl-sim:mt" not in backends():
            self.skipTest("rtl-sim not built")
        with sf.Device.open("rtl-sim:mt") as dev:
            self.assertFalse(dev.info()["caps"]["gemm_i8"])
            a, c = dev.alloc(64, sf.MEM_DEV_READ), dev.alloc(256, sf.MEM_DEV_WRITE)
            with self.assertRaises(sf.SilicaFluxError) as e:
                dev.submit(sf.OP_GEMM_I8, src=a, aux=a, dst=c, m=4, n=4, k=4)
            self.assertEqual(e.exception.name, "SF_ERR_UNSUPPORTED")
            self.assertIn("gemm_i8", e.exception.detail)

    def test_gemm_and_gcm_on_cpu_ref(self):
        with sf.Device.open("cpu-ref:mt") as dev:
            # GEMM 2x3 * 3x2, int8 -> int32
            A, B = bytes([1, 2, 3, 4, 5, 6]), bytes([7, 8, 9, 10, 11, 12])
            ha, hb, hc = dev.alloc(6, sf.MEM_DEV_READ), dev.alloc(6, sf.MEM_DEV_READ), dev.alloc(16, sf.MEM_DEV_WRITE)
            dev.write(ha, A)
            dev.write(hb, B)
            c = dev.wait(dev.submit(sf.OP_GEMM_I8, src=ha, aux=hb, dst=hc, m=2, n=2, k=3))
            self.assertTrue(c.ok)
            import struct
            self.assertEqual(struct.unpack("<4i", dev.read(hc, 16)), (58, 64, 139, 154))
            # AES-GCM: NIST/McGrew-Viega test case 4 (bytes.fromhex values)
            key = bytes.fromhex("feffe9928665731c6d6a8f9467308308")
            iv = bytes.fromhex("cafebabefacedbaddecaf888")
            pt = bytes.fromhex("d9313225f88406e5a55909c5aff5269a86a7a9531534f7da2e4c303d8a318a721c3c0c95956809532fcf0e2449a6b525b16aedf5aa0de657ba637b39")
            aad = bytes.fromhex("feedfacedeadbeeffeedfacedeadbeefabaddad2")
            k = dev.key_load(key)
            p, ct, tag = dev.alloc(len(pt), sf.MEM_DEV_READ), dev.alloc(len(pt), sf.MEM_DEV_WRITE), dev.alloc(16, sf.MEM_DEV_WRITE)
            dev.write(p, pt)
            c = dev.wait(dev.submit(sf.OP_AES_GCM, key=k, encrypt=True, iv=iv, aad=aad, src=p, dst=ct, aux=tag, length=len(pt)))
            self.assertTrue(c.ok)
            self.assertEqual(dev.read(ct, len(pt)).hex(), "42831ec2217774244b7221b784d0d49ce3aa212f2c02a4e035c17e2329aca12e21d514b25466931c7d8f6a5aac84aa051ba30b396a0aac973d58e091")
            self.assertEqual(dev.read(tag, 16).hex(), "5bc94fbc3221a5db94fae95ae7121a47")
            dev.key_unload(k)


if __name__ == "__main__":
    unittest.main()
