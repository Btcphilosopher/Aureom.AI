/*
 * SilicaFlux CloudRuntime -- C ABI, version 1.0
 *
 *   discover -> open -> alloc -> submit -> wait/poll -> read -> counters -> free -> close
 *
 * STABILITY RULES (ABI major 1)
 *   - Function names, enum values, struct field order and sizes never change within a major version.
 *   - Every struct passed to the library begins with `uint32_t struct_size`; set it to sizeof() of YOUR copy.
 *     The library never reads or writes beyond the size you declare, so a newer library works with older
 *     callers and vice versa (new fields are only ever appended).
 *   - Every function returns an `sf_status`: SF_OK (0) or a negative error.  Nothing blocks without a bound:
 *     waits take a timeout and return SF_ERR_TIMEOUT.
 *   - A handle may be used from several threads (calls are serialised internally), but must not be used after
 *     sf_cloud_close().
 *
 * WHAT IS (NOT) BEHIND THE API -- read `sf_cloud_info()` first.
 *   backend "cpu-ref"  software model of the device contract (not hardware, not RTL)
 *   backend "rtl-sim"  Verilator simulation of the Project 61 CloudDPU RTL (cycle-accurate; no clock claim)
 *   backend "hw"       physical hardware: NOT IMPLEMENTED -- sf_cloud_open() fails with SF_ERR_NO_DEVICE
 *   Operations the active backend cannot execute fail with SF_ERR_UNSUPPORTED (see info.caps); they are never
 *   emulated silently.
 *
 * SECURITY MODEL (docs/04_TENANT_ISOLATION.md)
 *   A handle is either a *mediator* handle (privileged: provisions tenants, resets, device-wide counters) or a
 *   *tenant* handle (own buffers, keys, tickets only).  SF_OPEN_STANDALONE creates a private device with every
 *   tenant provisioned and gives the one handle both capabilities: it is a development / single-application
 *   mode, NOT an isolation boundary.
 */
#ifndef SF_CLOUD_H
#define SF_CLOUD_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SF_CLOUD_ABI_MAJOR 1u
#define SF_CLOUD_ABI_MINOR 0u

/* ------------------------------------------------------------------------------------------------ status */
typedef int32_t sf_status;
enum {
    SF_OK                 = 0,
    SF_ERR_INVALID_ARG    = -1,
    SF_ERR_UNSUPPORTED    = -2,   /* backend/device does not implement the operation */
    SF_ERR_NO_DEVICE      = -3,
    SF_ERR_PERMISSION     = -4,
    SF_ERR_NO_MEMORY      = -5,
    SF_ERR_BUSY           = -6,   /* object referenced by an in-flight operation */
    SF_ERR_STALE_HANDLE   = -7,   /* freed, foreign or invalid handle */
    SF_ERR_TIMEOUT        = -8,   /* operation may still be running */
    SF_ERR_QUEUE_FULL     = -9,
    SF_ERR_DEVICE_FAULT   = -10,
    SF_ERR_TENANT_STATE   = -11,
    SF_ERR_ISOLATION      = -12,
    SF_ERR_ALIGNMENT      = -13,
    SF_ERR_RANGE          = -14,
    SF_ERR_NOT_READY      = -15,  /* poll(): not completed yet */
    SF_ERR_CRYPTO_AUTH    = -16,
    SF_ERR_ABI_MISMATCH   = -17,
    SF_ERR_RESET          = -18,
    SF_ERR_INTERNAL       = -19,
    SF_ERR_BAD_DESCRIPTOR = -20,
    SF_ERR_QUOTA          = -21
};

/* ------------------------------------------------------------------------------------------------ handles */
typedef struct sf_cloud_device sf_cloud_device;   /* opaque */
typedef uint64_t sf_buf_t;                        /* buffer handle (epoch|generation|tenant|index); 0 = invalid */
typedef uint64_t sf_ticket_t;                     /* operation ticket */
typedef uint64_t sf_key_t;                        /* key handle */

/* ------------------------------------------------------------------------------------------------ flags */
/* sf_cloud_open flags */
#define SF_OPEN_STANDALONE  0x1u  /* private device, every tenant provisioned, handle = tenant + admin */
#define SF_OPEN_MEDIATOR    0x2u  /* privileged handle without a tenant session (provision tenants yourself) */

/* sf_cloud_alloc flags */
#define SF_MEM_HOST         0x0u  /* host memory the device can DMA from/to (default) */
#define SF_MEM_DEVICE       0x1u  /* device-local memory (tenant SRAM partition), not CPU accessible */
#define SF_MEM_DEV_READ     0x2u  /* the device may read the buffer (input)  */
#define SF_MEM_DEV_WRITE    0x4u  /* the device may write the buffer (output); 0|0 = both */

/* capabilities (sf_cloud_info.caps) */
#define SF_CAP_NOP          (1u << 0)
#define SF_CAP_DMA          (1u << 1)
#define SF_CAP_PKT_PROCESS  (1u << 2)
#define SF_CAP_GEMM_I8      (1u << 3)
#define SF_CAP_AES_GCM      (1u << 4)
#define SF_CAP_STORAGE      (1u << 5)
#define SF_CAP_TELEMETRY    (1u << 6)

/* sf_cloud_reset flags */
#define SF_RESET_DATAPLANE  0x1u  /* abort running jobs, clear a halted data plane; tenants/queues survive */
#define SF_RESET_HARD       0x2u  /* full device reset; every outstanding operation fails with SF_ERR_RESET */

/* operations */
enum {
    SF_OP_NOP           = 0,  /* queue round trip */
    SF_OP_PKT_PROCESS   = 1,  /* host src -> device -> PacketCore transform -> host dst; CRC-32 + RFC1071 checksum */
    SF_OP_COPY          = 2,  /* protected memory copy (PKT_PROCESS with PASS); completion carries crc_in/crc_out */
    SF_OP_DMA_H2D       = 3,  /* host src -> device-local dst */
    SF_OP_DMA_D2H       = 4,  /* device-local src -> host dst */
    SF_OP_GEMM_I8       = 5,  /* INT8 x INT8 -> INT32, m,n,k <= 64.  src=A, aux=B, dst=C (little-endian int32) */
    SF_OP_AES_GCM       = 6,  /* src -> dst, tag in aux (16 bytes); needs a key from sf_cloud_key_load */
    SF_OP_STORAGE_WRITE = 7,  /* src -> blocks at lba (512-byte blocks, tenant-private namespace) */
    SF_OP_STORAGE_READ  = 8   /* blocks at lba -> dst */
};

/* PacketCore test-adapter operations (proc_op).  NONE of them is cryptography. */
#define SF_PROC_PASS     0u
#define SF_PROC_XOR32    1u   /* out = in ^ (param repeated every 4 bytes) */
#define SF_PROC_BSWAP32  2u   /* byte-swap every 32-bit word (length multiple of 4) */

/* ------------------------------------------------------------------------------------------------ structs */
typedef struct sf_cloud_open_params {
    uint32_t struct_size;
    uint32_t abi_major;           /* set to SF_CLOUD_ABI_MAJOR */
    const char *backend;          /* "auto" (default), "cpu-ref[:opt=v,...]", "rtl-sim[:cfg=mt|min|mt4,...]", "hw" */
    uint32_t flags;               /* SF_OPEN_* */
    uint32_t tenant;              /* standalone: tenant to open (default 0) */
    uint64_t default_timeout_ms;  /* 0 = 10000 */
} sf_cloud_open_params;

typedef struct sf_cloud_info {
    uint32_t struct_size;
    uint32_t abi_major, abi_minor;            /* this library */
    uint32_t dpu_abi_major, dpu_abi_minor;    /* the device's register ABI */
    char     runtime_version[16];
    char     backend[16];                     /* "cpu-ref" | "rtl-sim" | "hw" */
    char     backend_description[192];
    char     timing_model[112];
    uint32_t measured_on_hardware;            /* 1 only for a physical device (never, today) */
    uint32_t caps;                            /* SF_CAP_* */
    uint32_t tenants, net_queues, compute_queues, dma_channels;
    uint32_t data_width, address_width, windows, sram_bytes, max_xfer;
    uint32_t block_status;                    /* raw BLOCK_STATUS: 2 bits/block, 0 absent 1 blocked 2 test-adapter 3 real */
    uint32_t tenant;                          /* tenant of this handle */
    uint32_t admin;                           /* 1 if the handle has mediator privileges */
    uint32_t health;                          /* 0 healthy 1 degraded 2 faulted 3 unavailable */
    uint32_t thermal;                         /* 0 unavailable 1 normal 2 warning 3 critical */
    char     health_detail[192];
} sf_cloud_info_t;

typedef struct sf_cloud_tenant_config {
    uint32_t struct_size;
    uint32_t sram_bytes;          /* 0 = equal share */
    uint64_t host_in_bytes;       /* device-read-only host window */
    uint64_t host_out_bytes;      /* device-writable host window */
    uint32_t max_buffers, max_inflight, max_keys;
    uint32_t chunk_bytes, staging_slots;
    uint32_t quarantine_on_violation;
} sf_cloud_tenant_config;

typedef struct sf_cloud_op {
    uint32_t struct_size;
    uint32_t kind;                /* SF_OP_* */
    sf_buf_t src, dst, aux;
    uint64_t src_off, dst_off, aux_off;
    uint64_t len;                 /* bytes (PKT_PROCESS/COPY/DMA/AES_GCM) */
    uint32_t proc_op, proc_param; /* PKT_PROCESS */
    uint32_t m, n, k;             /* GEMM_I8 */
    sf_key_t key;                 /* AES_GCM */
    uint32_t encrypt;             /* AES_GCM: 1 = encrypt (tag written to aux), 0 = decrypt (tag read from aux) */
    uint32_t aad_len;             /* AES_GCM: <= 1024 */
    const uint8_t *aad;
    uint8_t  iv[12];              /* AES_GCM */
    uint32_t blocks;              /* STORAGE_*: number of 512-byte blocks */
    uint64_t lba;                 /* STORAGE_* */
} sf_cloud_op_t;

typedef struct sf_cloud_completion {
    uint32_t struct_size;
    uint32_t kind;
    sf_status status;             /* SF_OK or the failure of the operation */
    uint32_t dev_err;             /* raw DPU error code of the first failing command, 0 = none */
    uint64_t bytes;
    uint32_t crc_in, crc_out;     /* CRC-32 (IEEE) of input/output stream, valid if has_crc */
    uint32_t has_crc;
    uint32_t csum;                /* RFC 1071 checksum of the output, valid if has_crc */
    uint32_t committed;           /* every output byte was acknowledged by its destination */
    uint32_t chunks;
    uint64_t latency_cycles;      /* device cycles (cpu-ref: logical); see info.timing_model */
    uint64_t latency_ns;          /* wall clock of the software stack, submit -> observed completion */
} sf_cloud_completion_t;

typedef struct sf_cloud_counters {
    uint32_t struct_size;
    uint32_t tenant;
    /* this tenant (always valid) */
    uint64_t t_submitted, t_completed, t_errors, t_bytes_ok, t_cross_tenant_attempts;
    uint32_t t_buffers, t_keys, t_inflight, t_state;
    uint64_t t_host_bytes, t_device_bytes;
    uint64_t t_dev_cmds, t_dev_bytes;
    uint32_t t_dev_violations, t_dev_errors;
    /* whole device (valid only for admin handles: device_valid = 1) */
    uint32_t device_valid;
    uint32_t reserved;
    uint64_t cycles;
    uint64_t d_cmds_accepted, d_cmds_retired, d_cmds_error, d_dma_bytes_rd, d_dma_bytes_wr;
    uint64_t d_active_cycles, d_stall_any, d_violations, d_host_errors, d_timeouts;
    uint64_t d_submitted, d_ok, d_failed, d_resets_soft, d_resets_hard;
} sf_cloud_counters_t;

typedef struct sf_cloud_event {
    uint32_t ts;                  /* device cycle counter (low 32 bits) */
    uint32_t arg;
    uint8_t  event;               /* 1 retire 2 violation 3 tenant_state 4 fault 5 dp_reset */
    uint8_t  tenant, queue, reserved;
} sf_cloud_event_t;

typedef struct sf_cloud_device_desc {
    char     id[32];              /* "cpu-ref:0", "rtl-sim:mt", ... */
    char     kind[16];
    uint32_t available;
    uint32_t reserved;
    char     description[160];
    char     reason[192];         /* always filled in: why it is / is not available */
} sf_cloud_device_desc;

/* ------------------------------------------------------------------------------------------------ API */
/* library */
void        sf_cloud_version(uint32_t *major, uint32_t *minor, const char **runtime_version);
const char *sf_cloud_status_str(sf_status s);        /* "SF_ERR_TIMEOUT" ... (static string) */
/* Human-readable detail of the last failure ON THIS THREAD (valid until the next call on this thread). */
const char *sf_cloud_last_error(void);

/* discovery: fills up to `max` descriptors, *count = number of devices known (may exceed max) */
sf_status sf_cloud_discover(sf_cloud_device_desc *out, size_t max, size_t *count);

sf_status sf_cloud_open(const sf_cloud_open_params *params, sf_cloud_device **out);
sf_status sf_cloud_close(sf_cloud_device *dev);      /* frees everything the handle owns; safe on NULL */
sf_status sf_cloud_info(sf_cloud_device *dev, sf_cloud_info_t *out);

/* privileged (mediator) operations */
sf_status sf_cloud_provision_tenant(sf_cloud_device *admin, uint32_t tenant, const sf_cloud_tenant_config *cfg /*NULL = defaults*/,
                                    uint8_t credential_out[16]);
sf_status sf_cloud_deprovision_tenant(sf_cloud_device *admin, uint32_t tenant);
sf_status sf_cloud_open_session(sf_cloud_device *admin, uint32_t tenant, const uint8_t credential[16], sf_cloud_device **out);
sf_status sf_cloud_reset(sf_cloud_device *admin, uint32_t flags);
sf_status sf_cloud_set_thermal(sf_cloud_device *admin, uint32_t state /*0 unavailable,1 normal,2 warning,3 critical*/, float celsius);
/* Prometheus text exposition of the whole device into buf (NUL-terminated); *needed = bytes required. */
sf_status sf_cloud_metrics(sf_cloud_device *admin, char *buf, size_t len, size_t *needed);

/* tenant operations */
sf_status sf_cloud_alloc(sf_cloud_device *dev, uint64_t size, uint32_t flags, sf_buf_t *out);
sf_status sf_cloud_free(sf_cloud_device *dev, sf_buf_t buf);
sf_status sf_cloud_write(sf_cloud_device *dev, sf_buf_t buf, uint64_t offset, const void *src, size_t len);
sf_status sf_cloud_read(sf_cloud_device *dev, sf_buf_t buf, uint64_t offset, void *dst, size_t len);
sf_status sf_cloud_key_load(sf_cloud_device *dev, const uint8_t *key, size_t len /*16 or 32*/, sf_key_t *out);
sf_status sf_cloud_key_unload(sf_cloud_device *dev, sf_key_t key);

sf_status sf_cloud_submit(sf_cloud_device *dev, const sf_cloud_op_t *op, sf_ticket_t *out);
/* SF_OK = completed (record filled; the ticket is consumed), SF_ERR_NOT_READY = still running. */
sf_status sf_cloud_poll(sf_cloud_device *dev, sf_ticket_t t, sf_cloud_completion_t *out);
/* Blocks at most timeout_ms (and a device-cycle budget).  SF_ERR_TIMEOUT leaves the ticket valid. */
sf_status sf_cloud_wait(sf_cloud_device *dev, sf_ticket_t t, uint64_t timeout_ms, sf_cloud_completion_t *out);

sf_status sf_cloud_counters(sf_cloud_device *dev, sf_cloud_counters_t *out);
/* Telemetry events of this tenant (all events for admin handles); *n = number written.  Events are consumed. */
sf_status sf_cloud_telemetry(sf_cloud_device *dev, sf_cloud_event_t *out, size_t max, size_t *n);

/* Layout self-check for tests: writes sizeof() of each public struct as seen by the library. */
sf_status sf_cloud_abi_sizes(uint32_t out[16], size_t *count);

#ifdef __cplusplus
}
#endif
#endif /* SF_CLOUD_H */
