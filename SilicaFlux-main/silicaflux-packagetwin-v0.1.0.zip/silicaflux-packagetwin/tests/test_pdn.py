"""PDN conservation laws and electrothermal coupling."""
import silicaflux_package_twin as T


def test_pdn_conservation_laws():
    r = T.v_pdn_laws()
    assert r["passed"], r


def test_flipchip_beats_wirebond_ir_drop():
    a = T.default_config_A()
    q = T.default_config_A0()
    da = T.solve_pdn(a, T.build_model(a, workload="mixed"))["worst_drop_mv"]
    dq = T.solve_pdn(q, T.build_model(q, workload="mixed"))["worst_drop_mv"]
    assert da < dq


def test_electrothermal_heat_balance():
    r = T.electrothermal(T.default_config_A("natural"), level=-1)
    assert r["converged"] and not r["thermal_runaway_detected"]
    assert r["heat_balance_check_rel"] < 1e-8


def test_runaway_is_detected_for_exaggerated_leakage():
    r = T.electrothermal(T.default_config_A("natural"), level=-1, leak_what_if={"p0_w": 0.5, "k_per_k": 0.08})
    assert r["thermal_runaway_detected"]


def test_powergrid_export_roundtrip(tmp_path):
    cfg = T.default_config_A()
    sol = T.solve_pdn(cfg, T.build_model(cfg, workload="mixed"))
    T.export_powergrid(sol, tmp_path)
    imp = T.import_powergrid(tmp_path)
    assert imp["nodes"] > 100 and imp["resistors"] > 100
    assert abs(imp["total_load_a"] - sol["load_current_a"]) / sol["load_current_a"] < 1e-9
