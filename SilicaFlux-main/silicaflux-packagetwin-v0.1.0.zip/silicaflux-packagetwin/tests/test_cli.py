"""Command-line entry points."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _run(*args, out):
    return subprocess.run([sys.executable, str(ROOT / "silicaflux_package_twin.py"), "--out", str(out), *args],
                          capture_output=True, text=True, timeout=600)


def test_materials_command(tmp_path):
    p = _run("materials", out=tmp_path)
    assert p.returncode == 0 and "silicon" in p.stdout


def test_run_command(tmp_path):
    p = _run("run", "--config", str(ROOT / "configs" / "scenario_A_fcbga_natural.json"), "--level", "-1", "--pdn", out=tmp_path)
    assert p.returncode == 0, p.stderr
    d = json.loads((tmp_path / "runs" / "A_fcbga_lidded_natural.json").read_text())
    assert d["energy_residual_rel"] < 1e-8 and "pdn" in d
