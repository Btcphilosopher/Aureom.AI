"""Block power model and physical power mapping."""
import numpy as np

import silicaflux_package_twin as T


def test_power_map_conservation_and_orientation():
    r = T.v_power_mapping()
    assert r["passed"], r


def test_breakdown_sums_and_workload_order():
    pm = T.PowerModel()
    fp = T.load_floorplan("C_sram_near_compute")
    tot = {}
    for wl in pm.workloads:
        br = pm.evaluate(fp, wl)
        s = sum(r["power_w"] for r in br["groups"]) + sum(m["power_w"] for m in br["macros"]) + br["io"]["power_w"]
        assert abs(s - br["total_power_w"]) < 1e-15
        assert abs(sum(br["by_class_w"].values()) - br["total_power_w"]) < 1e-15
        tot[wl] = br["total_power_w"]
    assert tot["idle"] < tot["mixed"] < tot["max_simultaneous"]


def test_only_icg_groups_can_be_gated():
    pm = T.PowerModel()
    fp = T.load_floorplan("A_baseline")
    br = pm.evaluate(fp, "idle")
    ce = {r["name"]: r["clock_enable"] for r in br["groups"]}
    assert ce["cpu"] == 1.0 and ce["fabric"] == 1.0
    assert ce["vector"] < 1.0 and ce["tensor"] < 1.0


def test_sources_cover_every_group_and_macro():
    cfg = T.default_config_A()
    m = T.build_model(cfg, workload="tensor")
    labels = {s.label for s in m.sources}
    fp = T.load_floorplan(cfg["die"]["floorplan"])
    assert {g["name"] for g in fp["std_cell_groups"]} <= labels
    assert {mm["name"] for mm in fp["macros"]} <= labels
    assert abs(m.total_power() - m.meta["power_breakdown"]["total_power_w"]) < 1e-15
