"""Energy conservation on random and on the real package models."""
import silicaflux_package_twin as T


def test_energy_conservation_random_models():
    r = T.v_energy_random()
    assert r["passed"], r


def test_package_A_energy_balance_and_heat_paths():
    r = T.run_thermal(T.default_config_A("natural"), level=-1)
    assert r["energy_residual_rel"] < 1e-8
    assert abs(sum(r["heat_split"].values()) - 1.0) < 1e-9
    assert r["power_map"]["conservation_rel_err"] < 1e-12
    assert r["tj_c"] > r["ambient_c"]


def test_package_B_energy_balance():
    r = T.run_thermal(T.default_config_B(), level=-1)
    assert r["energy_residual_rel"] < 1e-8
    assert len(r["dies"]) == 3
