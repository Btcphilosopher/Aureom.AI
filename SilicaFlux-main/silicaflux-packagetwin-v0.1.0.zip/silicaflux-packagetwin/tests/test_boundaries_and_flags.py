"""Boundary-condition handling and rejection of non-physical configurations."""
import json

import pytest

import silicaflux_package_twin as T


def test_boundary_handling():
    r = T.v_boundary_handling()
    assert r["passed"], r
    assert all(c["rejected"] for c in r["rejected"])


def test_material_and_config_flags():
    r = T.v_material_and_config_flags()
    assert r["passed"], r


def test_material_database_valid_and_provenanced():
    mats = T.load_materials()
    for m in mats.values():
        assert m.prov in T.PROV_CLASSES
        assert not [i for i in T.validate_material(m) if i.severity == "ERROR"], m.name


def test_default_configs_match_schema(tmp_path):
    pytest.importorskip("jsonschema")
    T.write_default_configs(tmp_path)
    for p in tmp_path.glob("*.json"):
        assert T.validate_against_schema(json.loads(p.read_text()), "scenario.schema.json") == [], p.name


def test_every_parameter_carries_provenance():
    rows = T.collect_params(T.default_config_A())
    assert rows and all(r["provenance"] in T.PROV_CLASSES for r in rows)
    assert not any(r["provenance"] == "measured" for r in rows)       # nothing is measured


def test_no_heat_sink_is_rejected():
    cfg = T.default_config_A("natural")
    model = T.build_model(cfg, workload="mixed")
    model.bcs = [T.BCRule("all", "adiabatic", "any")]
    with pytest.raises(T.TwinError):
        T.ThermalSolver(model, T.Mesh(model, T.mesh_spec_for(cfg, -1)))
