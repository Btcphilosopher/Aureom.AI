"""Bump / ball accounting, escape estimate and the S-parameter interface."""
import numpy as np

import silicaflux_package_twin as T


def test_bump_map_accounting():
    ic = T.interconnect_study(T.default_config_A())
    b = ic["bumps"]
    assert sum(b["counts"].values()) == b["sites_total"] == b["nx"] * b["ny"]
    assert b["signals_placed"] + b["signal_shortfall"] == b["signals_required"] == 73
    assert ic["balls"]["shortfall"] == 0


def test_two_signal_rings_are_short_at_200um_on_C_floorplan():
    cfg = T.default_config_A()
    T.set_path(cfg, "bumps.signal_rings", 2)
    ic = T.interconnect_study(cfg)
    assert ic["bumps"]["signal_shortfall"] > 0


def test_escape_estimate():
    e = T.escape_layers(200e-6, 110e-6, 25e-6, 25e-6, 3)
    assert e["traces_per_channel"] == 1 and e["layers_needed"] == 2


def test_touchstone_interface():
    r = T.v_touchstone()
    assert r["passed"], r
    assert r["compliance"].startswith("NOT ASSESSED")
