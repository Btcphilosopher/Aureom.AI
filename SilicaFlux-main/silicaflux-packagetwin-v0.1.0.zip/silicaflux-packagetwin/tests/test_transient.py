"""Transient heat transfer: temporal order, lumped limit, steady/transient consistency."""
import silicaflux_package_twin as T


def test_temporal_orders_and_lumped_limit():
    r = T.v_lumped_rc()
    assert r["passed"], r
    assert 0.95 < r["implicit_euler"]["order"] < 1.05
    assert 1.95 < r["crank_nicolson"]["order"] < 2.05
    assert r["implicit_euler"]["energy_residual"] < 1e-10


def test_transient_converges_to_steady_state():
    r = T.v_steady_transient()
    assert r["passed"], r
