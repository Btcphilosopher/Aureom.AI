"""Steady conduction against analytical / independent reference solutions."""
import silicaflux_package_twin as T


def test_slab_flux_exact():
    r = T.v_slab_flux()
    assert r["passed"], r


def test_composite_slab_with_contact_and_convection_exact():
    r = T.v_composite_contact()
    assert r["passed"], r


def test_volumetric_generation_second_order():
    r = T.v_volumetric_order()
    assert r["passed"] and r["metric"] > 1.8, r


def test_manufactured_3d_orthotropic_second_order():
    r = T.v_mms_3d()
    assert r["passed"], r
    assert r["order_l2"] > 1.9


def test_multilayer_spreading_matches_fourier_series_and_converges():
    r = T.v_fourier_spreading(levels=(0, 1))
    errs = [max(l["rel_err"]) for l in r["levels"]]
    assert errs[1] < errs[0] < 5e-3, errs


def test_temperature_dependent_k_matches_kirchhoff():
    r = T.v_kT()
    assert r["passed"], r
