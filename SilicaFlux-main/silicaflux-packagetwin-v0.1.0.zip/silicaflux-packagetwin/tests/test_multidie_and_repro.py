"""Multi-die research scenario and reproducibility."""
import numpy as np

import silicaflux_package_twin as T


def test_thermal_coupling_superposition_exact():
    r = T.thermal_coupling(T.default_config_B(), level=-1, tj_limit=105.0)
    assert r["field_superposition_max_err_k"] < 1e-8
    R = np.array(r["R_k_per_w"])
    assert np.all(np.diag(R) > 0) and np.all(R > 0)
    assert r["allocation"]["lp_unconstrained_total_w"] >= r["allocation"]["uniform_total_w"] - 1e-9


def test_d2d_counts_are_geometric_only():
    d = T.d2d_study(T.default_config_B())
    assert d["pairs"] and all(p["connections"] == min(p["bump_limited"], p["wiring_limited"]) for p in d["pairs"])
    assert "licensed" in d["caveat"]


def test_reproducible_results():
    cfg = T.default_config_A("natural")
    a = T.strip_private(T.run_thermal(cfg, level=-1))
    b = T.strip_private(T.run_thermal(cfg, level=-1))
    keys = ("tj_c", "theta_ja_k_w", "power_w", "heat_flow_w")
    assert T.stable_hash(T.rounded({k: a[k] for k in keys}, 9)) == T.stable_hash(T.rounded({k: b[k] for k in keys}, 9))
    assert a["config_hash"] == b["config_hash"]
