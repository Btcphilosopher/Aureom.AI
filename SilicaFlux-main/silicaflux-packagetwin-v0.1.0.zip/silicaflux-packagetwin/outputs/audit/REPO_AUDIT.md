# Repository audit (generated)

Scanned `/home/user/Aureom.AI`: 886 files, 374 zip archives (member names inspected).

| artefact | status | files | role |
|---|---|---|---|
| FloorplanLab (Project 05) | FOUND | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip (sha256 52ba66778641) | Real OpenROAD/ORFS floorplans of sfv_soc_df on IHP SG13G2: die/core outline, 12 SRAM macro placements, std-cell density grids, logical-group extents, PDN straps. USED (eda_derived). |
| ThermalLab | FOUND | SilicaFlux ThermalLab (1).zip (sha256 6a0f0945705a)<br>SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/SilicaFlux ThermalLab (1).zip (sha256 6a0f0945705a) | Earlier validated FV thermal solver; all of its geometry/power/package inputs were demonstration placeholders (5x5 mm die, 2.2 W). Not used as input; its method informed this solver. |
| PowerGrid (Project 08) | NOT FOUND | - | On-die power-grid project referenced by ThermalLab/FloorplanLab; no archive found -> PDN exchange format implemented (nodes.csv / resistors.csv). |
| PowerLink | FOUND | SilicaFlux-main/silicaflux-powerlink.zip (sha256 2563c2f42bbf) | Power/package/PCB co-design planning model (65 nm generic tech, 2.5 mm planning die). Package-family parasitics/thermal ranges reused as literature ranges; its power numbers are NOT used (different technology). |
| PowerClock (Project 27) | FOUND | SilicaFlux-main/silicaflux-powerclock.zip (sha256 30e4b497087b)<br>SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-powerclock.zip (sha256 30e4b497087b) | Power manager RTL: clock-enable, throttling, frequency-only operating points. NO DVFS / voltage control -> no DVFS assumed here. |
| ControlCore (Project 21) | FOUND | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-controlcore.zip (sha256 39b5b8e374a4) | HPC control subsystem RTL (RV32IM, 64+32 KiB SRAM); SKY130 synthesis smoke test only; no floorplan. |
| TensorCore 01-10 | FOUND | SilicaFlux-main/silicaflux-tensorcore08.zip (sha256 be676860442c)<br>SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore07.zip (sha256 e337a15a4cd3)<br>SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore01-tensor_pe.zip (sha256 1776098c7f15) | INT8 systolic tensor accelerator RTL; SKY130 synthesis smoke test (TC08: 154,882 cells, 1.597 mm2 cell area); no floorplan. |
| HPC vector modules (M02-M09) | FOUND | SilicaFlux-main/SilicaFlux2.0/silicaflux-hpc-m02-vector-lane.zip (sha256 e76a238e1431)<br>SilicaFlux-main/SilicaFlux2.0/silicaflux-hpc-fp32-fma.zip (sha256 8ca1a6d8c804)<br>SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m03-vector-array.zip (sha256 c1b6d2946c5b) | FP32 vector lane/array/tile RTL; no floorplan. |
| DataFabric | FOUND | SilicaFlux-main/silicaflux-datafabric.zip (sha256 9f1f37357c8e)<br>SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip (sha256 9f1f37357c8e)<br>SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric-noc.zip (sha256 a095106011e7) | SFB2 interconnect + DMA RTL (integrated in sfv_soc_df). |
| HostLink PCIe (Project 25) | FOUND | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hostlink-project25.zip (sha256 bfb5bab26716) | PCIe host-interface RTL behind a generic AXI endpoint boundary: the PCIe PHY/controller is vendor IP that does not exist here. |
| MemoryBridge (Project 24) | FOUND | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-extmem-bridge-p24.zip (sha256 ca58fdc3ea5a) | DDR / future-HBM bridge verified against a SIMULATED controller: no DDR/HBM PHY exists. |
| SRAM Wrapper Library (Project 01) | FOUND | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip (sha256 13b1cee1f913) | SRAM interfaces; ASIC backend maps to foundry macros. |
| YieldLab (Project 12) | FOUND | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-yieldlab.zip (sha256 14cb37f4633e) | Wafer/defect/yield simulation linked to FloorplanLab geometry. |
| SilicaFlux-V release 1 | FOUND | SilicaFlux-main/silicaflux-v-release1.zip (sha256 424816e9eaed) | RTL release of the implemented SoC. |

CAD / layout / S-parameter files associated with SilicaFlux: 2 (package drawings: 0, Touchstone: 0).

First entries:

- `silicaflux-yieldlab/third_party/thermallab/def_demo/top.def` in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-yieldlab.zip`
- `silicaflux-testcore/third_party/pdk/sky130_fd_sc_hd_merged.lef` in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-testcore-p07.zip`
