# Package technology comparison (generated)

Same die, same power model and same board for every Scenario-A/A0 row (SilicaFlux-V, `mixed` workload); Scenario-B rows use the hypothetical chiplet set. All package/cooling parameters are assumptions (see `results/assumptions_*.csv`). Values are model outputs, not measurements.

| configuration | architecture | P (W) | theta_JA (K/W) | theta_JC,top* (K/W) | theta_JB* (K/W) | board path % | P_max @105 degC (W) | static IR (mV) | PDN peak Z (ohm) | target Z (ohm) | bump sites | ball sites | cost index (assumed) | stack height (mm) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A0_wirebond_qfn_natural | wire_bond_qfn | 0.02193 | 23.42 | 16.54 | 2.809 | 96.69 | 3.973 | 5.866 | 0.7197 | 4.945 | - | - | 1.95 | 0.95 |
| A_bare_die_forced_air | flip_chip_single_die | 0.02193 | 5.412 | 3.763 | 7.64 | 19.78 | 14.79 | 0.7773 | 1.363 | 4.945 | 187 | 144 | 8.6 | 19.25 |
| A_fcbga_cold_plate | flip_chip_single_die | 0.02193 | 4.32 | 3.786 | 4.256 | 5.38 | 18.55 | 0.7773 | 1.363 | 4.945 | 187 | 144 | 32.95 | 11.05 |
| A_fcbga_forced_air | flip_chip_single_die | 0.02193 | 5.312 | 3.786 | 4.256 | 15.23 | 15.07 | 0.7773 | 1.363 | 4.945 | 187 | 144 | 9.6 | 20.1 |
| A_fcbga_natural | flip_chip_single_die | 0.02193 | 21.66 | 3.786 | 4.256 | 97.71 | 4.381 | 0.7773 | 1.363 | 4.945 | 187 | 144 | 2.95 | 2.051 |
| A_fcbga_passive_heatsink | flip_chip_single_die | 0.02193 | 14.39 | 3.786 | 4.256 | 58.47 | 7.571 | 0.7773 | 1.363 | 4.945 | 187 | 144 | 5.4 | 20.1 |
| B_organic_mcm_forced_air | multi_die_organic_mcm | 17.52 | 1.226 | 0.3782 | 0.824 | 10.8 | 65.27 | 9.061 | 0.01761 | 0.002889 | - | - | 17.8 | 22.58 |
| B_si_interposer_cold_plate | multi_die_interposer | 17.52 | 0.5888 | 0.3547 | 0.7575 | 1.726 | 135.9 | 8.901 | 0.0176 | 0.002889 | - | - | 73.85 | 11.66 |
| B_si_interposer_forced_air | multi_die_interposer | 17.52 | 1.194 | 0.3547 | 0.7575 | 10.88 | 67.02 | 8.901 | 0.0176 | 0.002889 | - | - | 50.8 | 22.71 |

\* idealised compact-model definitions.

| configuration | availability | missing manufacturing data |
|---|---|---|
| A0_wirebond_qfn_natural | standard OSAT flow; matches the prototype documents | pad ring + I/O cells, bond-pad plan, leadframe drawing |
| A_bare_die_forced_air | as A without lid; die-edge chipping / handling risk | as A + heatsink attach / clip force |
| A_fcbga_cold_plate | as A + liquid loop (overkill for SilicaFlux-V) | as A + cold-plate characterisation |
| A_fcbga_forced_air | as A + fan airflow at system level | as A + fan curve / system airflow |
| A_fcbga_natural | documented production direction; requires wafer bumping of IHP dies | bump plan + TopMetal2 pads, UBM/solder, substrate design kit, lid BOM |
| A_fcbga_passive_heatsink | as A + off-the-shelf heatsink | as A + heatsink vendor data |
| B_organic_mcm_forced_air | research only (coarser D2D wiring) | chiplet partitioning, fine-line organic substrate, D2D PHY |
| B_si_interposer_cold_plate | research only | as B + liquid cooling |
| B_si_interposer_forced_air | research only | chiplet RTL partitioning, micro-bump assembly, interposer foundry, licensed D2D/UCIe PHY, KGD test |

**Reading the table.** For SilicaFlux-V the thermal columns differ by factors of several, but every configuration keeps the die within a fraction of a kelvin of ambient at the modelled power; the discriminators are I/O count (bump/ball sites), static IR drop (area-array flip-chip vs edge-fed wire-bond), assembly availability and cost. Scenario B is where cooling and PDN impedance become limiting.

