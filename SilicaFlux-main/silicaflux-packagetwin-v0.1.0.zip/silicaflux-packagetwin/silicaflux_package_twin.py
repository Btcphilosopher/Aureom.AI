#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SilicaFlux PackageTwin - 3D semiconductor package digital twin  (Project 29)
=============================================================================
Aureom.AI / SilicaFlux-HPC.  Primary source: ``silicaflux_package_twin.py``.

An engineering simulator and design-exploration platform for the proposed
SilicaFlux package.  It models the silicon die, die metallisation (BEOL),
die-to-package interconnect, underfill, package substrate, thermal interface
materials, heat spreader (lid), heatsink / cold plate and the PCB boundary,
together with a resistive power-delivery network (PDN), interconnect
accounting and a research multi-die / interposer configuration.

What it is NOT
--------------
* Not a signoff tool.  The thermal solver is a validated finite-volume
  conduction solver; cooling is represented by correlation-based or declared
  heat-transfer coefficients (no CFD).  The PDN is a homogenised resistive
  network (no electromagnetic extraction, no signoff-grade IR/EM).
* Not a manufacturable package design.  No package drawing, substrate
  stack-up, bump plan, OSAT design kit or measurement exists in the
  repository.  Every package parameter carries a provenance class and is
  reported as such.

Provenance classes (every physical parameter carries one)
---------------------------------------------------------
measured      physical measurement on SilicaFlux hardware          (none exist)
eda_derived   read from an EDA output on the real SilicaFlux RTL (FloorplanLab /
              OpenROAD / Yosys on IHP SG13G2) - tool results, not silicon
specified     stated by a PDK / ORFS platform file, a JEDEC standard or a
              SilicaFlux design target document
published     published material property or literature range
assumed       engineering assumption for this model (replace with vendor data)
hypothetical  research-scenario value for technology SilicaFlux does not have
derived       computed here from other declared inputs

Numerical method
----------------
Steady conduction  div(k grad T) + q = 0 and transient
rho cp dT/dt = div(k grad T) + q are discretised with a cell-centred finite-
volume method on a non-uniform rectilinear 3-D mesh (7-point stencil,
harmonic face conductances, diagonal orthotropic conductivity tensor,
interface contact resistances, Robin / Dirichlet / Neumann boundaries).
Transient: theta scheme (implicit Euler default, Crank-Nicolson optional).
Verification: analytical slabs, composite slabs with contact resistance,
manufactured 3-D anisotropic solution, multilayer Fourier-series spreading
solution, lumped RC transients, energy conservation, steady/transient
consistency, mesh convergence (Richardson / GCI) and PDN conservation laws.

Usage:  python silicaflux_package_twin.py --help
"""
from __future__ import annotations

import os

# Small dense BLAS operations inside the Krylov loop are ~100x slower with OpenBLAS threading on
# small vectors; pin BLAS to one thread before numpy is imported (results are unaffected).
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import copy
import csv
import hashlib
import io
import json
import math
import platform
import re
import sys
import time
import zipfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import scipy
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from scipy.sparse.csgraph import connected_components

__version__ = "0.1.0"
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
CONFIGS = ROOT / "configs"
OUT_DEFAULT = ROOT / "outputs"

UM = 1e-6
MM = 1e-3
SIGMA_SB = 5.670374419e-8          # W m^-2 K^-4
G_ACC = 9.80665                     # m s^-2
T_ABS = 273.15

# Viewer / figure palette (midnight navy, gold, cyan, violet)
PALETTE = {
    "navy": "#0b1533", "navy2": "#111d45", "navy3": "#1a2a5e", "ink": "#e8ecf8",
    "muted": "#9aa6c8", "gold": "#d9ac3c", "gold2": "#f2d27a", "cyan": "#22c7e0",
    "cyan2": "#8eeaf6", "violet": "#8b6cf0", "violet2": "#c3b2ff", "red": "#ef5d6a",
}

PROV_CLASSES = {
    "measured": "physical measurement on SilicaFlux hardware (none exist in the repository)",
    "eda_derived": "read from EDA tool output on the real SilicaFlux RTL (FloorplanLab/OpenROAD/Yosys, IHP SG13G2) - not silicon",
    "specified": "stated by a PDK/ORFS platform file, a JEDEC standard or a SilicaFlux design-target document",
    "published": "published material property / literature range",
    "assumed": "engineering assumption made for this model - replace with vendor or measured data",
    "hypothetical": "research-scenario value for technology SilicaFlux does not have",
    "derived": "computed by PackageTwin from other declared inputs",
}


# =============================================================================
# 1. Small utilities
# =============================================================================
class TwinError(Exception):
    """Raised for invalid / non-physical configurations that must not be solved."""


@dataclass
class Issue:
    severity: str          # ERROR | WARNING | INFO
    code: str
    message: str
    where: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


def _json_default(o):
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    if dataclasses_is(o):
        return asdict(o)
    raise TypeError(f"not JSON serialisable: {type(o)}")


def dataclasses_is(o) -> bool:
    return hasattr(o, "__dataclass_fields__")


def jdump(obj, path: Path, indent: int = 1) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, sort_keys=True, default=_json_default)
        f.write("\n")


def jload(path: Path) -> Any:
    with open(path) as f:
        return json.load(f)


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def stable_hash(obj) -> str:
    return sha256_bytes(json.dumps(obj, sort_keys=True, default=_json_default).encode())


def rounded(obj, nd: int = 10):
    """Round floats recursively (for reproducibility hashes independent of LSB noise)."""
    if isinstance(obj, float):
        return float(f"{obj:.{nd}g}")
    if isinstance(obj, dict):
        return {k: rounded(v, nd) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [rounded(v, nd) for v in obj]
    if isinstance(obj, np.ndarray):
        return rounded(obj.tolist(), nd)
    if isinstance(obj, (np.floating,)):
        return rounded(float(obj), nd)
    return obj


def write_csv(path: Path, rows: List[dict], fields: Optional[List[str]] = None, precise: bool = False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    if fields is None:
        fields = []
        for r in rows:
            for k in r:
                if k not in fields:
                    fields.append(k)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: (repr(float(r.get(k))) if precise and isinstance(r.get(k), (float, np.floating)) else _fmt_csv(r.get(k))) for k in fields})


def _fmt_csv(v):
    if isinstance(v, float):
        return f"{v:.6g}"
    if isinstance(v, (np.floating,)):
        return f"{float(v):.6g}"
    if isinstance(v, (list, tuple, dict)):
        return json.dumps(v, default=_json_default)
    return v


def pv(spec, default=None):
    """Value of a parameter spec: either a plain number or {"value": x, "prov": ..., ...}."""
    if spec is None:
        return default
    if isinstance(spec, dict):
        return spec.get("value", default)
    return spec


def P(value, prov: str, source: str = "", rng: Optional[Sequence[float]] = None, unit: str = "", note: str = "") -> dict:
    """Build a provenance-tagged parameter spec."""
    if prov not in PROV_CLASSES:
        raise TwinError(f"unknown provenance class {prov!r}")
    d = {"value": value, "prov": prov}
    if source:
        d["source"] = source
    if rng is not None:
        d["range"] = list(rng)
    if unit:
        d["unit"] = unit
    if note:
        d["note"] = note
    return d


def collect_params(cfg, prefix: str = "") -> List[dict]:
    """Walk a config tree and list every provenance-tagged parameter (the assumptions ledger)."""
    rows = []
    if isinstance(cfg, dict):
        if "value" in cfg and "prov" in cfg:
            rows.append({"parameter": prefix, "value": cfg["value"], "unit": cfg.get("unit", _unit_from_key(prefix)),
                         "provenance": cfg["prov"], "range": cfg.get("range", ""), "source": cfg.get("source", ""),
                         "note": cfg.get("note", "")})
            return rows
        for k, v in cfg.items():
            rows += collect_params(v, f"{prefix}.{k}" if prefix else str(k))
    elif isinstance(cfg, list):
        for i, v in enumerate(cfg):
            rows += collect_params(v, f"{prefix}[{i}]")
    return rows


def _unit_from_key(key: str) -> str:
    tail = key.split(".")[-1]
    for suf, u in (("_um", "um"), ("_mm", "mm"), ("_w_mk", "W/(m K)"), ("_k_w", "K/W"), ("_w_m2k", "W/(m2 K)"),
                   ("_mm2k_w", "mm2 K/W"), ("_c", "degC"), ("_w", "W"), ("_v", "V"), ("_a", "A"), ("_hz", "Hz"),
                   ("_ohm", "ohm"), ("_m_s", "m/s"), ("_j", "J"), ("_f", "F"), ("_h", "H"), ("_kg", "kg")):
        if tail.endswith(suf):
            return u
    return ""


# =============================================================================
# 2. Materials
# =============================================================================
@dataclass
class Material:
    name: str
    kx: float
    ky: float
    kz: float
    rho: float
    cp: float
    prov: str = "assumed"
    source: str = ""
    note: str = ""
    k_temp_exponent: float = 0.0          # k(T) = k_ref (T/300K)^-n  (0 = constant)
    resistivity_ohm_m: Optional[float] = None
    tcr_per_k: float = 0.0
    emissivity: Optional[float] = None
    color: str = ""

    @property
    def k_iso(self) -> float:
        return (self.kx * self.ky * self.kz) ** (1.0 / 3.0)

    @property
    def anisotropic(self) -> bool:
        return not (math.isclose(self.kx, self.kz, rel_tol=1e-9) and math.isclose(self.ky, self.kz, rel_tol=1e-9))

    def summary(self) -> dict:
        return {"name": self.name, "kx": self.kx, "ky": self.ky, "kz": self.kz, "rho": self.rho, "cp": self.cp,
                "prov": self.prov, "source": self.source, "note": self.note}


def material_from_dict(name: str, d: dict) -> Material:
    if "k" in d:
        kx = ky = kz = float(d["k"])
    else:
        kx = float(d.get("kx", d.get("kxy")))
        ky = float(d.get("ky", d.get("kxy", kx)))
        kz = float(d["kz"])
    return Material(name=name, kx=kx, ky=ky, kz=kz, rho=float(d["rho"]), cp=float(d["cp"]),
                    prov=d.get("prov", "assumed"), source=d.get("source", ""), note=d.get("note", ""),
                    k_temp_exponent=float(d.get("k_temp_exponent", 0.0)),
                    resistivity_ohm_m=d.get("resistivity_ohm_m"), tcr_per_k=float(d.get("tcr_per_k", 0.0)),
                    emissivity=d.get("emissivity"), color=d.get("color", ""))


def load_materials(path: Optional[Path] = None) -> Dict[str, Material]:
    path = Path(path) if path else DATA / "materials.json"
    db = jload(path)
    mats = {n: material_from_dict(n, d) for n, d in db["materials"].items()}
    return mats


def validate_material(m: Material) -> List[Issue]:
    """Positive-parameter and plausibility checks (flags non-physical materials)."""
    out: List[Issue] = []
    for attr in ("kx", "ky", "kz", "rho", "cp"):
        v = getattr(m, attr)
        if not np.isfinite(v) or v <= 0:
            out.append(Issue("ERROR", "MAT_NONPOSITIVE", f"{m.name}.{attr} = {v} must be finite and > 0", m.name))
    if out:
        return out
    for attr in ("kx", "ky", "kz"):
        v = getattr(m, attr)
        if v < 0.01:
            out.append(Issue("WARNING", "MAT_K_LOW", f"{m.name}.{attr} = {v} W/mK is below still air", m.name))
        if v > 2500:
            out.append(Issue("ERROR", "MAT_K_NONPHYSICAL", f"{m.name}.{attr} = {v} W/mK exceeds diamond (~2200 W/mK)", m.name))
    if not (0.5 <= m.rho <= 23000):
        out.append(Issue("ERROR", "MAT_RHO_RANGE", f"{m.name}.rho = {m.rho} kg/m3 outside [0.5, 23000]", m.name))
    if not (100 <= m.cp <= 5000):
        out.append(Issue("WARNING", "MAT_CP_RANGE", f"{m.name}.cp = {m.cp} J/kgK outside [100, 5000]", m.name))
    alpha = max(m.kx, m.ky, m.kz) / (m.rho * m.cp)
    if alpha > 2e-3:
        out.append(Issue("ERROR", "MAT_DIFFUSIVITY", f"{m.name} diffusivity {alpha:.2e} m2/s is non-physical", m.name))
    if m.prov not in PROV_CLASSES:
        out.append(Issue("ERROR", "MAT_PROVENANCE", f"{m.name} has unknown provenance {m.prov!r}", m.name))
    return out


def mix_columns(name: str, f: float, col: Material, mat: Material, prov: str, source: str) -> Material:
    """Effective medium for parallel cylindrical columns (bumps, balls, TSVs) of area fraction f in a matrix.

    Through-plane: parallel (rule of mixtures, exact for straight columns).
    In-plane: 2-D Maxwell-Garnett (Rayleigh) for aligned cylinders.
    """
    if not (0.0 <= f < 1.0):
        raise TwinError(f"{name}: column area fraction {f} must be in [0,1)")
    kz = f * col.kz + (1 - f) * mat.kz
    kc, km = col.kx, mat.kx
    kxy = km * (kc + km + f * (kc - km)) / (kc + km - f * (kc - km))
    rho = f * col.rho + (1 - f) * mat.rho
    cp = (f * col.rho * col.cp + (1 - f) * mat.rho * mat.cp) / rho
    return Material(name, kxy, kxy, kz, rho, cp, prov, source,
                    note=f"columns {col.name} f={f:.4f} in {mat.name} (kz parallel, kxy Maxwell-Garnett)")


def mix_laminate(name: str, plies: List[Tuple[float, float, Material, Material]], prov: str, source: str) -> Material:
    """Laminate of plies (thickness, metal coverage c, metal, dielectric).

    Each ply: k = c k_metal + (1-c) k_diel in both directions (patterned metal spans the ply);
    laminate: in-plane thickness-weighted parallel, through-plane series.
    """
    T = sum(p[0] for p in plies)
    kxy = sum(t * (c * m.kx + (1 - c) * d.kx) for t, c, m, d in plies) / T
    kz = T / sum(t / (c * m.kz + (1 - c) * d.kz) for t, c, m, d in plies)
    rhocp = sum(t * (c * m.rho * m.cp + (1 - c) * d.rho * d.cp) for t, c, m, d in plies) / T
    rho = sum(t * (c * m.rho + (1 - c) * d.rho) for t, c, m, d in plies) / T
    return Material(name, kxy, kxy, kz, rho, rhocp / rho, prov, source,
                    note=f"laminate of {len(plies)} plies, {T / UM:.1f} um")


# =============================================================================
# 3. Geometry model
# =============================================================================
@dataclass
class Rect:
    x0: float
    y0: float
    x1: float
    y1: float

    def __post_init__(self):
        if self.x1 < self.x0 or self.y1 < self.y0:
            raise TwinError(f"degenerate rectangle {self}")

    @property
    def w(self) -> float:
        return self.x1 - self.x0

    @property
    def h(self) -> float:
        return self.y1 - self.y0

    @property
    def area(self) -> float:
        return self.w * self.h

    @property
    def cx(self) -> float:
        return 0.5 * (self.x0 + self.x1)

    @property
    def cy(self) -> float:
        return 0.5 * (self.y0 + self.y1)

    def contains(self, x, y):
        return (x >= self.x0) & (x <= self.x1) & (y >= self.y0) & (y <= self.y1)

    def inside(self, other: "Rect", tol: float = 1e-12) -> bool:
        return (self.x0 >= other.x0 - tol and self.y0 >= other.y0 - tol and
                self.x1 <= other.x1 + tol and self.y1 <= other.y1 + tol)

    def overlaps(self, other: "Rect") -> bool:
        return self.x0 < other.x1 and other.x0 < self.x1 and self.y0 < other.y1 and other.y0 < self.y1

    def expand(self, d: float) -> "Rect":
        return Rect(self.x0 - d, self.y0 - d, self.x1 + d, self.y1 + d)

    @staticmethod
    def centered(cx: float, cy: float, w: float, h: float) -> "Rect":
        return Rect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)

    def mm(self) -> List[float]:
        return [round(v / MM, 6) for v in (self.x0, self.y0, self.x1, self.y1)]


def ring(outer: Rect, width: float) -> List[Rect]:
    """Four rectangles forming a ring of the given width inside `outer`."""
    i = outer.expand(-width)
    return [Rect(outer.x0, outer.y0, outer.x1, i.y0), Rect(outer.x0, i.y1, outer.x1, outer.y1),
            Rect(outer.x0, i.y0, i.x0, i.y1), Rect(i.x1, i.y0, outer.x1, i.y1)]


@dataclass
class Layer:
    name: str
    role: str
    thickness: float
    nz: int = 1
    background: Optional[str] = None                   # material over the whole domain (None = void)
    regions: List[Tuple[Rect, str]] = field(default_factory=list)   # later entries override earlier ones
    source: bool = False                                # heat-source (device) layer
    note: str = ""
    z0: float = 0.0

    @property
    def z1(self) -> float:
        return self.z0 + self.thickness


@dataclass
class InterfaceRule:
    """Thermal contact resistance R'' (m2K/W) between vertically adjacent layers lower|upper.
    Applied only where the two touching cells have the listed materials (None = any)."""
    name: str
    lower: str
    upper: str
    R: float
    materials: Optional[Tuple[Optional[str], Optional[str]]] = None


@dataclass
class BCRule:
    """Boundary condition on exposed faces (domain boundary or faces adjacent to void cells).
    The first matching rule wins; unmatched faces are adiabatic."""
    name: str
    type: str                     # convection | dirichlet | flux | adiabatic
    surface: str = "any"          # top | bottom | side | any
    layers: Optional[List[str]] = None
    region: Optional[Rect] = None
    h: float = 0.0                # W/m2K (convection)
    T: float = 25.0               # degC (ambient / fixed temperature)
    q: float = 0.0                # W/m2 into the solid (flux)
    R: float = 0.0                # extra series contact resistance m2K/W
    note: str = ""


@dataclass
class HeatSource:
    """A rectangular uniform source (power W) or a gridded source in package coordinates."""
    label: str
    group: str
    power: float
    rect: Optional[Rect] = None
    grid_x: Optional[np.ndarray] = None      # bin edges (m)
    grid_y: Optional[np.ndarray] = None
    grid_p: Optional[np.ndarray] = None      # (ny_bins, nx_bins) W
    layer: str = "active"
    die: str = ""
    prov: str = "assumed"


@dataclass
class DiePlacement:
    name: str
    rect: Rect                        # die outline in package coordinates (m)
    face_down: bool = True            # flip-chip: layout mirrored about the die's vertical centre line
    floorplan: Optional[dict] = None  # vendored FloorplanLab data (die-local um) or synthetic block plan
    source_layer: str = "active"
    thickness: float = 300 * UM
    prov: str = "eda_derived"

    def to_pkg(self, x_um, y_um):
        """Die-face layout coordinates (um, origin = die lower-left, as in DEF) -> package coordinates (m)."""
        x = np.asarray(x_um, dtype=float) * UM
        y = np.asarray(y_um, dtype=float) * UM
        if self.face_down:
            return self.rect.x1 - x, self.rect.y0 + y
        return self.rect.x0 + x, self.rect.y0 + y

    def rect_to_pkg(self, r_um: Sequence[float]) -> Rect:
        xa, ya = self.to_pkg(r_um[0], r_um[1])
        xb, yb = self.to_pkg(r_um[2], r_um[3])
        return Rect(float(min(xa, xb)), float(min(ya, yb)), float(max(xa, xb)), float(max(ya, yb)))


@dataclass
class PackageModel:
    name: str
    scenario: str
    layers: List[Layer]
    materials: Dict[str, Material]
    interfaces: List[InterfaceRule]
    bcs: List[BCRule]
    domain: Rect
    fine_x: List[Tuple[float, float]]
    fine_y: List[Tuple[float, float]]
    dies: List[DiePlacement] = field(default_factory=list)
    sources: List[HeatSource] = field(default_factory=list)
    extra_capacity: List[Tuple[str, Rect, float]] = field(default_factory=list)   # (layer, region, J/K)
    ambient_c: float = 25.0
    meta: dict = field(default_factory=dict)
    issues: List[Issue] = field(default_factory=list)

    def __post_init__(self):
        z = 0.0
        for L in self.layers:
            L.z0 = z
            z += L.thickness

    def layer(self, name: str) -> Layer:
        for L in self.layers:
            if L.name == name:
                return L
        raise KeyError(name)

    @property
    def height(self) -> float:
        return sum(L.thickness for L in self.layers)

    def total_power(self) -> float:
        return float(sum(s.power for s in self.sources))


def validate_model(model: PackageModel) -> List[Issue]:
    """Geometry / material / boundary sanity checks.  ERRORs make the model unsolvable."""
    out: List[Issue] = []
    names = set()
    for L in model.layers:
        if L.name in names:
            out.append(Issue("ERROR", "LAYER_DUP", f"duplicate layer name {L.name}", L.name))
        names.add(L.name)
        if not (L.thickness > 0 and np.isfinite(L.thickness)):
            out.append(Issue("ERROR", "LAYER_THICKNESS", f"layer {L.name} thickness {L.thickness} must be > 0", L.name))
        if L.nz < 1:
            out.append(Issue("ERROR", "LAYER_NZ", f"layer {L.name} nz must be >= 1", L.name))
        if L.background is not None and L.background not in model.materials:
            out.append(Issue("ERROR", "MAT_UNKNOWN", f"layer {L.name} background {L.background} unknown", L.name))
        for r, m in L.regions:
            if m not in model.materials:
                out.append(Issue("ERROR", "MAT_UNKNOWN", f"layer {L.name} region material {m} unknown", L.name))
            if not r.inside(model.domain, tol=1e-9):
                out.append(Issue("ERROR", "REGION_OUTSIDE", f"layer {L.name} region {r.mm()} mm outside domain", L.name))
            if r.area <= 0:
                out.append(Issue("WARNING", "REGION_EMPTY", f"layer {L.name} has a zero-area region", L.name))
        if L.background is None and not L.regions:
            out.append(Issue("ERROR", "LAYER_EMPTY", f"layer {L.name} has no material at all (floating stack)", L.name))
    used = {L.background for L in model.layers if L.background} | {m for L in model.layers for _, m in L.regions}
    for m in sorted(used):
        if m in model.materials:
            iss = validate_material(model.materials[m])
            if model.meta.get("numerical_experiment"):
                for i in iss:
                    if i.code in ("MAT_K_NONPHYSICAL", "MAT_DIFFUSIVITY"):
                        i.severity, i.message = "WARNING", i.message + " [numerical experiment]"
            out += iss
    for ir in model.interfaces:
        if ir.R < 0 or not np.isfinite(ir.R):
            out.append(Issue("ERROR", "CONTACT_NEGATIVE", f"interface {ir.name} R''={ir.R} must be >= 0", ir.name))
        if ir.R > 1e-3:
            out.append(Issue("WARNING", "CONTACT_HIGH", f"interface {ir.name} R''={ir.R * 1e6:.0f} mm2K/W is very high", ir.name))
        ln = [L.name for L in model.layers]
        if ir.lower not in ln or ir.upper not in ln:
            out.append(Issue("ERROR", "CONTACT_LAYER", f"interface {ir.name} refers to unknown layer", ir.name))
        elif ln.index(ir.upper) != ln.index(ir.lower) + 1:
            out.append(Issue("ERROR", "CONTACT_NOT_ADJACENT", f"interface {ir.name}: {ir.lower}/{ir.upper} not adjacent", ir.name))
    n_sink = 0
    for b in model.bcs:
        if b.type not in ("convection", "dirichlet", "flux", "adiabatic"):
            out.append(Issue("ERROR", "BC_TYPE", f"BC {b.name} type {b.type} unknown", b.name))
        if b.type == "convection":
            if not (b.h > 0 and np.isfinite(b.h)):
                out.append(Issue("ERROR", "BC_H", f"BC {b.name} h={b.h} must be > 0", b.name))
            elif b.h > 1e6:
                out.append(Issue("WARNING", "BC_H_HIGH", f"BC {b.name} h={b.h:.3g} W/m2K exceeds boiling/jet impingement range", b.name))
            n_sink += 1
        if b.type == "dirichlet":
            n_sink += 1
        if b.R < 0:
            out.append(Issue("ERROR", "BC_R", f"BC {b.name} contact R must be >= 0", b.name))
    if n_sink == 0:
        out.append(Issue("ERROR", "NO_HEAT_SINK", "no convection or fixed-temperature boundary: steady problem is ill-posed"))
    for d in model.dies:
        if not d.rect.inside(model.domain):
            out.append(Issue("ERROR", "DIE_OUTSIDE", f"die {d.name} outside domain", d.name))
    for i, a in enumerate(model.dies):
        for b in model.dies[i + 1:]:
            if a.rect.overlaps(b.rect):
                out.append(Issue("ERROR", "DIE_OVERLAP", f"dies {a.name} and {b.name} overlap", a.name))
    for s in model.sources:
        if s.power < 0 or not np.isfinite(s.power):
            out.append(Issue("ERROR", "POWER_NEGATIVE", f"source {s.label} power {s.power} < 0", s.label))
    return out


# =============================================================================
# 4. Mesh
# =============================================================================
@dataclass
class MeshSpec:
    h_fine: float = 100 * UM      # lateral cell size inside fine zones (dies)
    growth: float = 0.30          # cell size grows by h_fine + growth * distance outside fine zones
    h_max: float = 6 * MM
    nz_scale: float = 1.0         # multiplies every layer's nz
    level: int = 0

    @staticmethod
    def level_spec(level: int, base_h: float = 120 * UM, ratio: float = 1.5, growth: float = 0.30,
                   h_max: float = 6 * MM) -> "MeshSpec":
        r = ratio ** level
        # systematic refinement: the whole size field h(x) = min(h_max, h_fine + growth d) is divided by r
        return MeshSpec(h_fine=base_h / r, growth=growth / r, h_max=h_max / r, nz_scale=r, level=level)


def _size_field(x: np.ndarray, zones: List[Tuple[float, float]], h_fine: float, growth: float, h_max: float) -> np.ndarray:
    if not zones:
        return np.full_like(x, h_max)
    d = np.full_like(x, np.inf)
    for a, b in zones:
        d = np.minimum(d, np.where(x < a, a - x, np.where(x > b, x - b, 0.0)))
    return np.minimum(h_max, h_fine + growth * d)


def graded_lines(breaks: Sequence[float], zones: List[Tuple[float, float]], h_fine: float, growth: float,
                 h_max: float) -> np.ndarray:
    """Mesh lines through every breakpoint; inside each interval the nodes equidistribute 1/h(x)."""
    br = np.unique(np.round(np.asarray(breaks, dtype=float), 12))
    out = [br[0]]
    for a, b in zip(br[:-1], br[1:]):
        L = b - a
        if L <= 1e-12:
            continue
        xs = np.linspace(a, b, 2001)
        inv = 1.0 / _size_field(xs, zones, h_fine, growth, h_max)
        s = np.concatenate([[0.0], np.cumsum(0.5 * (inv[1:] + inv[:-1]) * np.diff(xs))])
        n = max(1, int(math.ceil(s[-1] - 1e-9)))
        targets = np.linspace(0, s[-1], n + 1)[1:]
        nodes = np.interp(targets, s, xs)
        nodes[-1] = b
        out.extend(nodes.tolist())
    return np.array(out)


class Mesh:
    """Non-uniform rectilinear 3-D mesh; cell (k, j, i) <-> z, y, x."""

    def __init__(self, model: PackageModel, spec: MeshSpec, extra_x: Sequence[float] = (), extra_y: Sequence[float] = ()):
        self.spec = spec
        dom = model.domain
        xb = {dom.x0, dom.x1, *extra_x}
        yb = {dom.y0, dom.y1, *extra_y}
        for L in model.layers:
            for r, _ in L.regions:
                xb |= {r.x0, r.x1}
                yb |= {r.y0, r.y1}
        for _, r, _ in model.extra_capacity:
            xb |= {r.x0, r.x1}
            yb |= {r.y0, r.y1}
        for b in model.bcs:                      # flux / fixed-T patches must be resolved exactly
            if b.region is not None and b.type in ("flux", "dirichlet"):
                xb |= {b.region.x0, b.region.x1}
                yb |= {b.region.y0, b.region.y1}
        xb = [v for v in xb if dom.x0 - 1e-12 <= v <= dom.x1 + 1e-12]
        yb = [v for v in yb if dom.y0 - 1e-12 <= v <= dom.y1 + 1e-12]
        self.xe = graded_lines(sorted(xb), model.fine_x, spec.h_fine, spec.growth, spec.h_max)
        self.ye = graded_lines(sorted(yb), model.fine_y, spec.h_fine, spec.growth, spec.h_max)
        ze = [0.0]
        klayer = []
        self.layer_k: Dict[str, Tuple[int, int]] = {}
        for li, L in enumerate(model.layers):
            nz = max(1, int(round(L.nz * spec.nz_scale)))
            k0 = len(ze) - 1
            ze.extend((L.z0 + L.thickness * np.arange(1, nz + 1) / nz).tolist())
            klayer += [li] * nz
            self.layer_k[L.name] = (k0, k0 + nz)
        self.ze = np.array(ze)
        self.klayer = np.array(klayer)
        self.nx, self.ny, self.nz = len(self.xe) - 1, len(self.ye) - 1, len(self.ze) - 1
        self.dx, self.dy, self.dz = np.diff(self.xe), np.diff(self.ye), np.diff(self.ze)
        self.xc = 0.5 * (self.xe[1:] + self.xe[:-1])
        self.yc = 0.5 * (self.ye[1:] + self.ye[:-1])
        self.zc = 0.5 * (self.ze[1:] + self.ze[:-1])
        if min(self.dx.min(), self.dy.min(), self.dz.min()) <= 0:
            raise TwinError("mesh has non-positive cell size")
        self.mat_names = list(model.materials.keys())
        mid = {n: i for i, n in enumerate(self.mat_names)}
        X, Y = np.meshgrid(self.xc, self.yc)          # (ny, nx)
        self.mat = np.full((self.nz, self.ny, self.nx), -1, dtype=np.int32)
        for li, L in enumerate(model.layers):
            m2 = np.full((self.ny, self.nx), -1, dtype=np.int32)
            if L.background is not None:
                m2[:] = mid[L.background]
            for r, mname in L.regions:
                m2[r.contains(X, Y)] = mid[mname]
            k0, k1 = self.layer_k[L.name]
            self.mat[k0:k1] = m2[None]
        self.active = self.mat >= 0
        self.n_active = int(self.active.sum())
        self.layer_names = [L.name for L in model.layers]

    @property
    def shape(self) -> Tuple[int, int, int]:
        return (self.nz, self.ny, self.nx)

    def summary(self) -> dict:
        return {"nx": self.nx, "ny": self.ny, "nz": self.nz, "cells_total": int(self.nx * self.ny * self.nz),
                "cells_active": self.n_active, "dx_min_um": float(self.dx.min() / UM), "dx_max_mm": float(self.dx.max() / MM),
                "dy_min_um": float(self.dy.min() / UM), "dz_min_um": float(self.dz.min() / UM),
                "max_neighbour_ratio_x": float(np.max(np.maximum(self.dx[1:] / self.dx[:-1], self.dx[:-1] / self.dx[1:]))),
                "level": self.spec.level}


def overlap_lengths(src_edges_lo: np.ndarray, src_edges_hi: np.ndarray, mesh_edges: np.ndarray) -> np.ndarray:
    """(n_src, n_cells) overlap lengths between source intervals and mesh cells (exact, conservative)."""
    lo = np.maximum(src_edges_lo[:, None], mesh_edges[None, :-1])
    hi = np.minimum(src_edges_hi[:, None], mesh_edges[None, 1:])
    return np.clip(hi - lo, 0.0, None)


# =============================================================================
# 5. Finite-volume thermal solver
# =============================================================================
SURF_CODES = {"top": 0, "bottom": 1, "side": 2}


class ThermalSolver:
    """Cell-centred FV conduction solver on a Mesh.

    Unknowns: temperatures (degC) of active cells.  Linear system  A T = q + b_bc  where A holds
    internal face conductances (harmonic, with interface contact resistance) and boundary
    conductances.  Energy conservation is exact at the discrete level and is checked on every solve.
    """

    def __init__(self, model: PackageModel, mesh: Mesh, direct_limit: int = 15_000):
        self.model, self.mesh = model, mesh
        issues = [i for i in validate_model(model) if i.severity == "ERROR"]
        if issues:
            raise TwinError("model invalid: " + "; ".join(f"{i.code}: {i.message}" for i in issues))
        m = mesh
        self.N = m.n_active
        if self.N == 0:
            raise TwinError("no active cells")
        self.idx = np.full(m.shape, -1, dtype=np.int64)
        self.idx[m.active] = np.arange(self.N)
        mats = [model.materials[n] for n in m.mat_names]
        self._tab = {a: np.array([getattr(x, a) for x in mats]) for a in ("kx", "ky", "kz", "rho", "cp", "k_temp_exponent")}
        safe = np.where(m.active, m.mat, 0)
        self.k3_ref = {a: np.where(m.active, self._tab[a][safe], np.nan) for a in ("kx", "ky", "kz")}
        self.nexp3 = np.where(m.active, self._tab["k_temp_exponent"][safe], 0.0)
        self.nonlinear_capable = bool(np.any(self.nexp3 != 0))
        V3 = m.dz[:, None, None] * m.dy[None, :, None] * m.dx[None, None, :]
        self.V = V3[m.active]
        self.C = (self._tab["rho"][safe] * self._tab["cp"][safe] * V3)[m.active]
        self.extra_C_total = 0.0
        for lname, r, cap in model.extra_capacity:
            k0, k1 = m.layer_k[lname]
            ox = overlap_lengths(np.array([r.x0]), np.array([r.x1]), m.xe)[0]
            oy = overlap_lengths(np.array([r.y0]), np.array([r.y1]), m.ye)[0]
            w2 = np.outer(oy, ox)
            kk = k1 - 1
            w2 = np.where(m.active[kk], w2, 0.0)
            if w2.sum() <= 0:
                raise TwinError(f"extra capacity on {lname} does not overlap active cells")
            self.C[self.idx[kk][m.active[kk]]] += (cap * w2 / w2.sum())[m.active[kk]]
            self.extra_C_total += cap
        self.direct_limit = direct_limit
        self._build_contacts()
        self._build_boundary()
        self.A, self.Gb, self.bbc = self._assemble(self.k3_ref)
        self._check_connectivity()
        self._lu = None
        self.stats = {"assemble_cells": self.N}

    # ---------------------------------------------------------------- geometry helpers
    def _build_contacts(self):
        m, model = self.mesh, self.model
        self.Rc = np.zeros((m.nz - 1, m.ny, m.nx))
        self.contact_log = []
        for ir in model.interfaces:
            k_lo = m.layer_k[ir.lower][1] - 1
            mlo, mhi = m.mat[k_lo], m.mat[k_lo + 1]
            mask = (mlo >= 0) & (mhi >= 0)
            if ir.materials:
                a, b = ir.materials
                if a is not None:
                    mask &= mlo == m.mat_names.index(a)
                if b is not None:
                    mask &= mhi == m.mat_names.index(b)
            area = float((np.outer(m.dy, m.dx))[mask].sum())
            self.Rc[k_lo][mask] += ir.R
            self.contact_log.append({"interface": ir.name, "R_m2K_W": ir.R, "area_mm2": area / MM ** 2})

    def _build_boundary(self):
        m = self.mesh
        act = m.active
        parts = []
        for d in ("-x", "+x", "-y", "+y", "-z", "+z"):
            nb = np.zeros_like(act)
            if d == "-x":
                nb[:, :, 1:] = act[:, :, :-1]
            elif d == "+x":
                nb[:, :, :-1] = act[:, :, 1:]
            elif d == "-y":
                nb[:, 1:, :] = act[:, :-1, :]
            elif d == "+y":
                nb[:, :-1, :] = act[:, 1:, :]
            elif d == "-z":
                nb[1:] = act[:-1]
            else:
                nb[:-1] = act[1:]
            k, j, i = np.nonzero(act & ~nb)
            if d in ("-x", "+x"):
                area, half, axis = m.dy[j] * m.dz[k], m.dx[i] / 2, 0
                fx = m.xe[i] if d == "-x" else m.xe[i + 1]
                fy, fz, surf = m.yc[j], m.zc[k], 2
            elif d in ("-y", "+y"):
                area, half, axis = m.dx[i] * m.dz[k], m.dy[j] / 2, 1
                fy = m.ye[j] if d == "-y" else m.ye[j + 1]
                fx, fz, surf = m.xc[i], m.zc[k], 2
            else:
                area, half, axis = m.dx[i] * m.dy[j], m.dz[k] / 2, 2
                fz = m.ze[k] if d == "-z" else m.ze[k + 1]
                fx, fy, surf = m.xc[i], m.yc[j], (1 if d == "-z" else 0)
            n = len(k)
            parts.append(dict(cell=self.idx[k, j, i], k=k, j=j, i=i, area=area, half=half, axis=np.full(n, axis),
                              fx=np.asarray(fx, float), fy=np.asarray(fy, float), fz=np.asarray(fz, float),
                              surf=np.full(n, surf), layer=m.klayer[k]))
        F = {key: np.concatenate([p[key] for p in parts]) for key in parts[0]}
        rule = np.full(len(F["cell"]), -1, dtype=np.int64)
        lname = np.array(m.layer_names)
        for ri, b in enumerate(self.model.bcs):
            mask = rule == -1
            if b.surface != "any":
                mask &= F["surf"] == SURF_CODES[b.surface]
            if b.layers:
                mask &= np.isin(lname[F["layer"]], b.layers)
            if b.region is not None:
                mask &= b.region.contains(F["fx"], F["fy"])
            rule[mask] = ri
        F["rule"] = rule
        self.F = F

    def _k_face_boundary(self, k3: dict) -> np.ndarray:
        F = self.F
        kk = np.empty(len(F["cell"]))
        for ax, key in ((0, "kx"), (1, "ky"), (2, "kz")):
            s = F["axis"] == ax
            kk[s] = k3[key][F["k"][s], F["j"][s], F["i"][s]]
        return kk

    def _assemble(self, k3: dict):
        m, idx = self.mesh, self.idx
        act = m.active
        rows, cols, vals = [], [], []
        self._pairs = []
        with np.errstate(divide="ignore", invalid="ignore"):
            # x faces
            a = act[:, :, :-1] & act[:, :, 1:]
            area = m.dz[:, None, None] * m.dy[None, :, None]
            G = area / (m.dx[None, None, :-1] / (2 * k3["kx"][:, :, :-1]) + m.dx[None, None, 1:] / (2 * k3["kx"][:, :, 1:]))
            self._add_pairs(idx[:, :, :-1][a], idx[:, :, 1:][a], G[a], 0, rows, cols, vals)
            # y faces
            a = act[:, :-1, :] & act[:, 1:, :]
            area = m.dz[:, None, None] * m.dx[None, None, :]
            G = area / (m.dy[None, :-1, None] / (2 * k3["ky"][:, :-1, :]) + m.dy[None, 1:, None] / (2 * k3["ky"][:, 1:, :]))
            self._add_pairs(idx[:, :-1, :][a], idx[:, 1:, :][a], G[a], 1, rows, cols, vals)
            # z faces (with contact resistance)
            a = act[:-1] & act[1:]
            area = (m.dy[:, None] * m.dx[None, :])[None]
            G = area / (m.dz[:-1, None, None] / (2 * k3["kz"][:-1]) + m.dz[1:, None, None] / (2 * k3["kz"][1:]) + self.Rc)
            self._add_pairs(idx[:-1][a], idx[1:][a], G[a], 2, rows, cols, vals)
            kz_lower = np.broadcast_to(np.arange(m.nz - 1)[:, None, None], a.shape)[a]
            self._zpair_klow = kz_lower
        F = self.F
        kf = self._k_face_boundary(k3)
        Gb = np.zeros(len(F["cell"]))
        bbc = np.zeros(self.N)
        for ri, b in enumerate(self.model.bcs):
            s = F["rule"] == ri
            if not np.any(s):
                continue
            if b.type == "convection":
                Gb[s] = F["area"][s] / (F["half"][s] / kf[s] + b.R + 1.0 / b.h)
            elif b.type == "dirichlet":
                Gb[s] = F["area"][s] / (F["half"][s] / kf[s] + b.R)
            if b.type in ("convection", "dirichlet"):
                np.add.at(bbc, F["cell"][s], Gb[s] * b.T)
            elif b.type == "flux":
                np.add.at(bbc, F["cell"][s], b.q * F["area"][s])
        rows.append(F["cell"])
        cols.append(F["cell"])
        vals.append(Gb)
        A = sp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(self.N, self.N)).tocsr()
        A.sum_duplicates()
        return A, Gb, bbc

    def _add_pairs(self, i1, i2, g, axis, rows, cols, vals):
        if np.any(~np.isfinite(g)) or np.any(g <= 0):
            raise TwinError("non-positive / non-finite face conductance (check materials and thicknesses)")
        rows += [i1, i2, i1, i2]
        cols += [i1, i2, i2, i1]
        vals += [g, g, -g, -g]
        self._pairs.append((i1, i2, g, axis))

    def _check_connectivity(self):
        i1 = np.concatenate([p[0] for p in self._pairs]) if self._pairs else np.array([], int)
        i2 = np.concatenate([p[1] for p in self._pairs]) if self._pairs else np.array([], int)
        G = sp.coo_matrix((np.ones(len(i1)), (i1, i2)), shape=(self.N, self.N))
        ncomp, lab = connected_components(G, directed=False)
        sink = np.zeros(ncomp, bool)
        has = self.Gb > 0
        sink[np.unique(lab[self.F["cell"][has]])] = True
        if not sink.all():
            bad = np.where(~sink)[0]
            sizes = [int((lab == b).sum()) for b in bad[:5]]
            raise TwinError(f"{len(bad)} thermally floating region(s) with no heat-removal path "
                            f"(cells: {sizes}); steady state is undefined - check layers/boundary conditions")
        self.n_components = ncomp

    # ---------------------------------------------------------------- sources
    def source_vector(self, sources: Optional[List[HeatSource]] = None) -> Tuple[np.ndarray, dict]:
        m = self.mesh
        sources = self.model.sources if sources is None else sources
        q3 = np.zeros(m.shape)
        rep = {"input_w": 0.0, "mapped_w": 0.0, "spill_w": 0.0, "n_sources": len(sources)}
        for s in sources:
            if s.power == 0:
                continue
            k0, k1 = m.layer_k[s.layer]
            wz = m.dz[k0:k1] / m.dz[k0:k1].sum()
            if s.rect is not None:
                ox = overlap_lengths(np.array([s.rect.x0]), np.array([s.rect.x1]), m.xe)[0]
                oy = overlap_lengths(np.array([s.rect.y0]), np.array([s.rect.y1]), m.ye)[0]
                if s.rect.area <= 0:
                    raise TwinError(f"source {s.label} has zero area")
                W = np.outer(oy, ox) / s.rect.area * s.power
            else:
                gx, gy, gp = s.grid_x, s.grid_y, s.grid_p
                bw, bh = np.diff(gx), np.diff(gy)
                Ox = overlap_lengths(gx[:-1], gx[1:], m.xe) / bw[:, None]
                Oy = overlap_lengths(gy[:-1], gy[1:], m.ye) / bh[:, None]
                W = Oy.T @ gp @ Ox
                if not math.isclose(W.sum(), gp.sum(), rel_tol=1e-9, abs_tol=1e-15):
                    raise TwinError(f"gridded source {s.label} not inside the mesh domain")
            P3 = W[None] * wz[:, None, None]
            act = m.active[k0:k1]
            spill = float(P3[~act].sum())
            tot = float(P3.sum())
            if spill > 1e-9 * max(tot, 1e-30):
                rep["spill_w"] += spill
                P3 = np.where(act, P3, 0.0)
                if P3.sum() <= 0:
                    raise TwinError(f"source {s.label} lands entirely on void cells")
                P3 *= tot / P3.sum()
            q3[k0:k1] += P3
            rep["input_w"] += s.power
        q = q3[m.active]
        rep["mapped_w"] = float(q.sum())
        rep["conservation_rel_err"] = abs(rep["mapped_w"] - rep["input_w"]) / max(rep["input_w"], 1e-30)
        return q, rep

    # ---------------------------------------------------------------- solves
    def factorize(self):
        if self._lu is None:
            t = time.time()
            self._lu = spla.splu(self.A.tocsc(), permc_spec="MMD_AT_PLUS_A")
            self.stats["factor_s"] = time.time() - t
        return self._lu

    def _precond(self):
        if getattr(self, "_pc", None) is None:
            self._pc = TwoLevelZLine(self, self.A, -self._pairs[2][2])
        return self._pc

    def solve(self, q: np.ndarray, x0: Optional[np.ndarray] = None, tol: float = 1e-11) -> np.ndarray:
        """Steady solve.  Direct sparse LU for small meshes, else PCG with a two-level z-line preconditioner
        (falls back to direct LU if PCG fails)."""
        rhs = q + self.bbc
        if self.N <= self.direct_limit:
            return self.factorize().solve(rhs)
        x, it, ok = pcg(self.A, rhs, self._precond(), x0=x0, tol=tol)
        self.stats["pcg_iterations"] = it
        if not ok:
            self.stats["pcg_fallback"] = True
            return self.factorize().solve(rhs)
        return x

    def solve_nonlinear(self, q: np.ndarray, tol: float = 1e-7, max_iter: int = 40) -> Tuple[np.ndarray, dict]:
        """Picard iteration for k(T) = k_ref ((T+273.15)/300)^-n on materials that declare n."""
        T = self.solve(q)
        if not self.nonlinear_capable:
            return T, {"iterations": 0, "converged": True}
        A0, Gb0, b0 = self.A, self.Gb, self.bbc
        hist = []
        conv = False
        for it in range(1, max_iter + 1):
            T3 = self.T3(T)
            fac = np.where(self.nexp3 != 0, ((np.nan_to_num(T3, nan=25.0) + T_ABS) / 300.0) ** (-self.nexp3), 1.0)
            k3 = {a: self.k3_ref[a] * fac for a in ("kx", "ky", "kz")}
            self.A, self.Gb, self.bbc = self._assemble(k3)
            self._lu, self._pc = None, None
            Tn = self.solve(q, x0=T, tol=1e-12)
            dT = float(np.max(np.abs(Tn - T)))
            hist.append(dT)
            T = Tn
            if dT < tol:
                conv = True
                break
        info = {"iterations": it, "converged": conv, "history_K": hist}
        self._nl_state = (self.A, self.Gb, self.bbc)
        self.A, self.Gb, self.bbc = A0, Gb0, b0
        self._lu, self._pc = None, None
        return T, info

    def transient(self, q_segments: List[Tuple[float, np.ndarray]], t_end: float, dt: float, theta: float = 1.0,
                  T0: Optional[np.ndarray] = None, record: Optional[Dict[str, np.ndarray]] = None,
                  record_every: int = 1) -> dict:
        """Theta-scheme transient.  q_segments = [(t_start, q_vector), ...] piecewise-constant power.

        Returns time series of the max temperature over each `record` cell set plus a per-step
        discrete energy-balance residual."""
        if dt <= 0 or t_end <= 0:
            raise TwinError("dt and t_end must be > 0")
        if not (0.5 <= theta <= 1.0):
            raise TwinError("theta must be in [0.5, 1] for unconditional stability")
        A = self.A
        Mdt = sp.diags(self.C / dt)
        LHS = (Mdt + theta * A).tocsr()
        if self.N <= max(self.direct_limit, 60_000):           # factor once per dt, reuse for every step
            _lu = spla.splu(LHS.tocsc(), permc_spec="MMD_AT_PLUS_A")
            step_solve = lambda rhs, x0: _lu.solve(rhs)
        else:
            _pc = TwoLevelZLine(self, LHS, -theta * self._pairs[2][2])

            def step_solve(rhs, x0):
                x, it, ok = pcg(LHS, rhs, _pc, x0=x0, tol=1e-12)
                if not ok:
                    raise TwinError("transient PCG step failed")
                return x
        R = (Mdt - (1 - theta) * A).tocsr()
        T = np.full(self.N, self.model.ambient_c) if T0 is None else T0.copy()
        segs = sorted(q_segments, key=lambda s: s[0])

        def q_at(t):
            q = segs[0][1]
            for ts, qs in segs:
                if t >= ts - 1e-12:
                    q = qs
            return q

        nsteps = int(round(t_end / dt))
        rec = record or {"Tmax": np.arange(self.N)}
        out = {"t": [0.0], **{k: [float(T[v].max())] for k, v in rec.items()}}
        Gbsum_cell = np.zeros(self.N)
        np.add.at(Gbsum_cell, self.F["cell"], self.Gb)
        worst = 0.0
        for n in range(nsteps):
            t0, t1 = n * dt, (n + 1) * dt
            # power held constant over a step at its value in the step (left-continuous)
            qs = q_at(t0 + 0.5 * dt)
            s = qs + self.bbc
            Tn = step_solve(R @ T + s, T)
            stored = float(np.sum(self.C * (Tn - T)))
            Tth = theta * Tn + (1 - theta) * T
            netin = dt * (float(qs.sum()) + float(self.bbc.sum()) - float(np.sum(Gbsum_cell * Tth)))
            scale = dt * max(float(np.abs(qs).sum()) + float(np.abs(self.bbc).sum()), 1e-30)
            worst = max(worst, abs(stored - netin) / scale)
            T = Tn
            if (n + 1) % record_every == 0 or n == nsteps - 1:
                out["t"].append(t1)
                for k, v in rec.items():
                    out[k].append(float(T[v].max()))
        out["T_final"] = T
        out["energy_residual_max"] = worst
        return out

    # ---------------------------------------------------------------- post-processing
    def T3(self, T: np.ndarray) -> np.ndarray:
        out = np.full(self.mesh.shape, np.nan)
        out[self.mesh.active] = T
        return out

    def boundary_heat(self, T: np.ndarray, q: np.ndarray, Gb: Optional[np.ndarray] = None) -> dict:
        Gb = self.Gb if Gb is None else Gb
        F = self.F
        flows: Dict[str, float] = {}
        tot_out = 0.0
        flux_in = 0.0
        for ri, b in enumerate(self.model.bcs):
            s = F["rule"] == ri
            if not np.any(s):
                continue
            if b.type in ("convection", "dirichlet"):
                Q = float(np.sum(Gb[s] * (T[F["cell"][s]] - b.T)))
            elif b.type == "flux":
                Q = -float(np.sum(b.q * F["area"][s]))
                flux_in += -Q
            else:
                Q = 0.0
            flows[b.name] = flows.get(b.name, 0.0) + Q
            tot_out += Q
        p_in = float(q.sum()) + flux_in
        # tot_out = (heat leaving through convection/fixed-T faces) - (heat entering through flux faces)
        resid = tot_out - float(q.sum())
        return {"flows_w": flows, "total_out_w": tot_out + flux_in, "power_in_w": p_in,
                "energy_residual_w": resid, "energy_residual_rel": abs(resid) / max(p_in, 1e-30)}

    def interface_heat(self, T: np.ndarray) -> List[dict]:
        """Net upward heat flow across every layer boundary (W)."""
        m = self.mesh
        i1, i2, g, ax = self._pairs[2]
        flow = g * (T[i1] - T[i2])
        out = []
        for li in range(len(m.layer_names) - 1):
            klo = m.layer_k[m.layer_names[li]][1] - 1
            s = self._zpair_klow == klo
            out.append({"lower": m.layer_names[li], "upper": m.layer_names[li + 1], "upward_w": float(flow[s].sum())})
        return out

    def layer_cells(self, layer: str) -> np.ndarray:
        k0, k1 = self.mesh.layer_k[layer]
        sub = self.idx[k0:k1]
        return sub[sub >= 0]

    def top_face_temperature(self, T: np.ndarray, layer: str, x: float, y: float) -> float:
        """Temperature on the top face of `layer` at (x, y) (lower-side value if a contact resistance exists)."""
        m = self.mesh
        i = int(np.clip(np.searchsorted(m.xe, x) - 1, 0, m.nx - 1))
        j = int(np.clip(np.searchsorted(m.ye, y) - 1, 0, m.ny - 1))
        k = m.layer_k[layer][1] - 1
        c = self.idx[k, j, i]
        if c < 0:
            return float("nan")
        kz = self.k3_ref["kz"][k, j, i]
        area = m.dx[i] * m.dy[j]
        if k + 1 < m.nz and self.idx[k + 1, j, i] >= 0:
            c2 = self.idx[k + 1, j, i]
            g = area / (m.dz[k] / (2 * kz) + m.dz[k + 1] / (2 * self.k3_ref["kz"][k + 1, j, i]) + self.Rc[k, j, i])
            flux = g * (T[c] - T[c2]) / area
        else:
            s = np.where((self.F["cell"] == c) & (self.F["surf"] == 0))[0]
            flux = float(np.sum(self.Gb[s] * (T[c] - self._bc_T(s)))) / area if len(s) else 0.0
        return float(T[c] - flux * m.dz[k] / (2 * kz))

    def _bc_T(self, faces):
        return np.array([self.model.bcs[r].T if r >= 0 else 0.0 for r in self.F["rule"][faces]])

    def surface_mean_temperature(self, T: np.ndarray, rule_name: str) -> float:
        F = self.F
        ri = [i for i, b in enumerate(self.model.bcs) if b.name == rule_name]
        s = np.isin(F["rule"], ri)
        if not np.any(s):
            return float("nan")
        Tf = T[F["cell"][s]]
        b = self.model.bcs[ri[0]]
        kf = self._k_face_boundary(self.k3_ref)[s]
        if b.type in ("convection", "dirichlet"):
            Q = self.Gb[s] * (Tf - b.T)                       # leaving the solid
            Tf = Tf - Q * F["half"][s] / (kf * F["area"][s])
        elif b.type == "flux":
            Tf = Tf + b.q * F["half"][s] / kf                 # entering the solid
        return float(np.sum(Tf * F["area"][s]) / np.sum(F["area"][s]))


class TwoLevelZLine:
    """Symmetric multiplicative two-level preconditioner for layered package meshes.

    Smoother: z-line block Jacobi (exact tridiagonal solve along every vertical column - the stiff
    direction because layers are thin).  Coarse space: piecewise-constant aggregates per
    (column, layer), Galerkin coarse operator P^T M P solved by sparse LU.
    """

    def __init__(self, solver: "ThermalSolver", M: sp.csr_matrix, zoff: np.ndarray):
        from scipy.linalg import lapack
        self._lapack = lapack
        m = solver.mesh
        N = solver.N
        kk, jj, ii = np.nonzero(m.active)
        col = jj.astype(np.int64) * m.nx + ii
        self.order = np.lexsort((kk, col))
        inv = np.empty_like(self.order)
        inv[self.order] = np.arange(N)
        i1, i2, _, _ = solver._pairs[2]
        off = np.zeros(max(N - 1, 1))
        if len(i1):
            if not np.all(inv[i2] == inv[i1] + 1):
                raise TwinError("z-line ordering inconsistent")
            off[inv[i1]] = zoff
        d = M.diagonal()[self.order]
        self.fac = lapack.dgttrf(off[:N - 1].copy(), d.copy(), off[:N - 1].copy())
        if self.fac[-1] != 0:
            raise TwinError("z-line factorisation failed")
        # coarse aggregates: 3 x 3 columns per layer (best cost/iteration balance measured on the package meshes)
        key = ((jj.astype(np.int64) // 3) * m.nx + ii // 3) * (len(m.layer_names) + 1) + m.klayer[kk]
        _, cid = np.unique(key, return_inverse=True)
        self.P = sp.csr_matrix((np.ones(N), (np.arange(N), cid)), shape=(N, int(cid.max()) + 1))
        self.PT = self.P.T.tocsr()
        self.luc = spla.splu((self.PT @ M @ self.P).tocsc(), permc_spec="MMD_AT_PLUS_A")
        self.M = M

    def smooth(self, r: np.ndarray) -> np.ndarray:
        dl2, d2, du2, du22, ipiv, _ = self.fac
        x = self._lapack.dgttrs(dl2, d2, du2, du22, ipiv, r[self.order])[0]
        out = np.empty_like(x)
        out[self.order] = x
        return out

    def __call__(self, r: np.ndarray) -> np.ndarray:
        x = self.smooth(r)
        x = x + self.P @ self.luc.solve(self.PT @ (r - self.M @ x))
        return x + self.smooth(r - self.M @ x)


def pcg(A, b: np.ndarray, prec: Callable[[np.ndarray], np.ndarray], x0: Optional[np.ndarray] = None,
        tol: float = 1e-11, maxit: int = 5000) -> Tuple[np.ndarray, int, bool]:
    """Preconditioned conjugate gradients; returns (x, iterations, converged)."""
    x = np.zeros_like(b) if x0 is None else x0.astype(float).copy()
    r = b - A @ x
    nb = max(np.linalg.norm(b), 1e-300)
    if np.linalg.norm(r) < tol * nb:
        return x, 0, True
    z = prec(r)
    rz = float(r @ z)
    if rz <= 0:
        return x, 0, False
    p = z.copy()
    for it in range(1, maxit + 1):
        Ap = A @ p
        pAp = float(p @ Ap)
        if pAp <= 0:
            return x, it, False
        a = rz / pAp
        x += a * p
        r -= a * Ap
        if np.linalg.norm(r) < tol * nb:
            return x, it, True
        z = prec(r)
        rzn = float(r @ z)
        if rzn <= 0:
            return x, it, False
        p = z + (rzn / rz) * p
        rz = rzn
    return x, maxit, False


# =============================================================================
# 6. Analytical / independent reference solutions (verification)
# =============================================================================
def ref_slab_flux(L: float, k: float, q: float) -> float:
    """1-D slab, fixed T on one face, flux q on the other: temperature rise = q L / k."""
    return q * L / k


def ref_series_stack(layers: List[Tuple[float, float]], contacts: Sequence[float], h: Optional[float]) -> float:
    """Unit-area series resistance of a layered slab (K m2 / W)."""
    R = sum(t / k for t, k in layers) + sum(contacts)
    if h is not None:
        R += 1.0 / h
    return R


def ref_fourier_spreading(a: float, b: float, layers: List[Tuple[float, float, float]], h: float,
                          sources: List[Tuple[Rect, float]], evals: List[Rect],
                          contacts: Optional[List[float]] = None, M: int = 200, N: int = 200) -> List[float]:
    """Mean temperature rise over `evals` rectangles on the top surface of a rectangular flux channel.

    Exact Fourier-series solution (Muzychka/Culham/Yovanovich-type, derived for multilayer orthotropic
    stacks): channel a x b with adiabatic sides, uniform-flux rectangular sources on the top surface,
    convective bottom h.  layers = [(t, k_r, k_z), ...] listed TOP -> BOTTOM; contacts[i] is the contact
    resistance below layer i.  Each Fourier mode is propagated with the layer impedance recursion
    Z_top = (tanh(g t) + K Z_b) / (K (1 + K Z_b tanh(g t))), g = beta sqrt(kr/kz), K = beta sqrt(kr kz).
    """
    contacts = contacts or [0.0] * len(layers)
    m = np.arange(M + 1)
    n = np.arange(N + 1)
    lam = m * np.pi / a
    dlt = n * np.pi / b
    beta = np.sqrt(lam[:, None] ** 2 + dlt[None, :] ** 2)
    Z = np.full(beta.shape, 1.0 / h)
    for li in range(len(layers) - 1, -1, -1):
        t, kr, kz = layers[li]
        Z = Z + contacts[li]
        with np.errstate(divide="ignore", invalid="ignore"):
            g = beta * math.sqrt(kr / kz)
            K = beta * math.sqrt(kr * kz)
            th = np.tanh(g * t)
            Zn = (th + K * Z) / (K * (1 + K * Z * th))
        Zn[0, 0] = Z[0, 0] + t / kz
        Z = Zn

    def cint(lo, hi, w):
        out = np.empty_like(w)
        nz = w > 0
        out[nz] = (np.sin(w[nz] * hi) - np.sin(w[nz] * lo)) / w[nz]
        out[~nz] = hi - lo
        return out

    eps_m = np.where(m == 0, 1.0, 2.0)
    eps_n = np.where(n == 0, 1.0, 2.0)
    Q = np.zeros(beta.shape)
    for r, pw in sources:
        Q += (pw / r.area) * np.outer(cint(r.x0, r.x1, lam), cint(r.y0, r.y1, dlt))
    Q *= np.outer(eps_m, eps_n) / (a * b)
    res = []
    for e in evals:
        Xe = np.outer(cint(e.x0, e.x1, lam), cint(e.y0, e.y1, dlt)) / e.area
        res.append(float(np.sum(Q * Z * Xe)))
    return res


def ref_lumped_rc(P: float, hA: float, C: float, t) -> np.ndarray:
    """Lumped-capacitance step response (Biot << 1): dT(t) = P/hA (1 - exp(-t hA / C))."""
    t = np.asarray(t, float)
    return P / hA * (1.0 - np.exp(-t * hA / C))


def ref_kirchhoff_slab(L: float, q: float, k_ref: float, n: float, T_cold_c: float) -> float:
    """Hot-face temperature of a slab with k(T) = k_ref (T/300)^-n, flux q, cold face fixed (Kirchhoff transform)."""
    Tc = T_cold_c + T_ABS
    if abs(n - 1.0) < 1e-12:
        Th = Tc * math.exp(q * L / (k_ref * 300.0))
    else:
        val = Tc ** (1 - n) + q * L * (1 - n) / (k_ref * 300.0 ** n)
        Th = val ** (1.0 / (1 - n))
    return Th - T_ABS


# =============================================================================
# 7. Cooling models (correlations; no CFD)
# =============================================================================
def air_props(T_c: float) -> dict:
    """Dry air at 1 atm: ideal gas density, Sutherland viscosity and conductivity."""
    T = T_c + T_ABS
    rho = 101325.0 / (287.05 * T)
    mu = 1.716e-5 * (T / 273.15) ** 1.5 * (273.15 + 110.4) / (T + 110.4)
    k = 0.0241 * (T / 273.15) ** 1.5 * (273.15 + 194.0) / (T + 194.0)
    cp = 1007.0
    nu = mu / rho
    alpha = k / (rho * cp)
    return {"rho": rho, "mu": mu, "k": k, "cp": cp, "nu": nu, "alpha": alpha, "Pr": nu / alpha, "beta": 1.0 / T}


def h_radiation(eps: float, Ts_c: float, Ta_c: float) -> float:
    Ts, Ta = Ts_c + T_ABS, Ta_c + T_ABS
    return eps * SIGMA_SB * (Ts ** 2 + Ta ** 2) * (Ts + Ta)


def h_natural_horizontal(L: float, dT: float, T_amb: float, facing: str = "up") -> float:
    """Horizontal plate, L = A/P.  Upper heated: 0.54 Ra^1/4 / 0.15 Ra^1/3; lower heated: 0.52 Ra^1/5."""
    dT = max(dT, 0.1)
    ap = air_props(T_amb + dT / 2)
    Ra = G_ACC * ap["beta"] * dT * L ** 3 / (ap["nu"] * ap["alpha"])
    if facing == "up":
        Nu = 0.54 * Ra ** 0.25 if Ra < 1e7 else 0.15 * Ra ** (1 / 3)
    else:
        Nu = 0.52 * Ra ** 0.2
    return Nu * ap["k"] / L


def h_natural_vertical(L: float, dT: float, T_amb: float) -> float:
    """Churchill-Chu vertical plate (all Ra)."""
    dT = max(dT, 0.1)
    ap = air_props(T_amb + dT / 2)
    Ra = G_ACC * ap["beta"] * dT * L ** 3 / (ap["nu"] * ap["alpha"])
    Nu = (0.825 + 0.387 * Ra ** (1 / 6) / (1 + (0.492 / ap["Pr"]) ** (9 / 16)) ** (8 / 27)) ** 2
    return Nu * ap["k"] / L


def h_forced_flat_plate(L: float, V: float, T_amb: float) -> float:
    """Average h on a flat plate in parallel flow (laminar 0.664 Re^1/2 Pr^1/3; mixed above Re 5e5)."""
    ap = air_props(T_amb + 5)
    Re = V * L / ap["nu"]
    if Re < 5e5:
        Nu = 0.664 * Re ** 0.5 * ap["Pr"] ** (1 / 3)
    else:
        Nu = (0.037 * Re ** 0.8 - 871) * ap["Pr"] ** (1 / 3)
    return Nu * ap["k"] / L


def platefin_heatsink(W: float, D: float, fin_h: float, fin_t: float, n_fins: int, k_fin: float, rho_fin: float,
                      cp_fin: float, mode: str, velocity: float, T_amb: float, dT_base: float, emissivity: float = 0.0) -> dict:
    """Plate-fin heatsink -> effective h on the base footprint W x D.

    forced : Teertstra, Yovanovich & Culham (2000) composite developing-flow channel model,
             channel velocity from continuity (no bypass, no fan curve).
    natural: Bar-Cohen & Rohsenow (1984) vertical parallel plates (fins vertical, channel length D).
    Fin efficiency tanh(mHc)/(mHc) with corrected length Hc = H + t/2.  Radiation (if emissivity > 0)
    from the outer envelope only.
    """
    if n_fins < 2:
        raise TwinError("heatsink needs at least 2 fins")
    s = (W - n_fins * fin_t) / (n_fins - 1)
    if s <= 0:
        raise TwinError(f"fins do not fit: spacing {s / MM:.3f} mm <= 0")
    ap = air_props(T_amb + max(dT_base, 0.1) / 2)
    if mode == "forced":
        if velocity <= 0:
            raise TwinError("forced-air heatsink needs velocity > 0")
        Vch = velocity * W / (W - n_fins * fin_t)
        Re_s = Vch * s / ap["nu"]
        Re_star = Re_s * s / D
        Pr = ap["Pr"]
        Nu = ((Re_star * Pr / 2) ** -3 + (0.664 * Re_star ** 0.5 * Pr ** (1 / 3) * (1 + 3.65 / Re_star ** 0.5) ** 0.5) ** -3) ** (-1 / 3)
        corr = "Teertstra et al. 2000 (forced, developing laminar channel flow)"
        extra = {"channel_velocity_m_s": Vch, "Re_s_star": Re_star}
    elif mode == "natural":
        dT = max(dT_base, 0.1)
        El = G_ACC * ap["beta"] * dT * s ** 4 / (ap["nu"] * ap["alpha"] * D)
        Nu = (576 / El ** 2 + 2.873 / El ** 0.5) ** -0.5
        corr = "Bar-Cohen & Rohsenow 1984 (natural, vertical parallel plates)"
        extra = {"Elenbaas": El}
    else:
        raise TwinError(f"heatsink mode {mode}")
    h = Nu * ap["k"] / s
    m_ = math.sqrt(2 * h / (k_fin * fin_t))
    Hc = fin_h + fin_t / 2
    eta = math.tanh(m_ * Hc) / (m_ * Hc)
    A_base = (W - n_fins * fin_t) * D
    A_fin = n_fins * 2 * Hc * D
    hA = h * (A_base + eta * A_fin)
    h_rad = 0.0
    if emissivity > 0:
        h_rad = h_radiation(emissivity, T_amb + dT_base, T_amb)
        hA += h_rad * (W * D + 2 * fin_h * D + 2 * fin_h * W)
    h_eff = hA / (W * D)
    return {"h_fin_w_m2k": h, "fin_efficiency": eta, "fin_spacing_mm": s / MM, "h_eff_base_w_m2k": h_eff,
            "R_sa_k_w": 1.0 / hA, "area_fins_m2": A_fin, "fin_mass_kg": n_fins * fin_t * fin_h * D * rho_fin,
            "fin_capacity_j_k": n_fins * fin_t * fin_h * D * rho_fin * cp_fin, "correlation": corr,
            "h_rad_w_m2k": h_rad, "Nu_s": Nu, **extra}


# =============================================================================
# 8. Repository audit and FloorplanLab import (EDA-derived geometry)
# =============================================================================
FLOORPLANLAB_ZIP_REL = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip"

AUDIT_TARGETS = [
    ("FloorplanLab (Project 05)", ["silicaflux-floorplanlab.zip"],
     "Real OpenROAD/ORFS floorplans of sfv_soc_df on IHP SG13G2: die/core outline, 12 SRAM macro placements, std-cell density grids, logical-group extents, PDN straps. USED (eda_derived)."),
    ("ThermalLab", ["SilicaFlux ThermalLab*.zip"],
     "Earlier validated FV thermal solver; all of its geometry/power/package inputs were demonstration placeholders (5x5 mm die, 2.2 W). Not used as input; its method informed this solver."),
    ("PowerGrid (Project 08)", ["*powergrid*", "*power-grid*", "*power_grid*"],
     "On-die power-grid project referenced by ThermalLab/FloorplanLab; no archive found -> PDN exchange format implemented (nodes.csv / resistors.csv)."),
    ("PowerLink", ["silicaflux-powerlink.zip"],
     "Power/package/PCB co-design planning model (65 nm generic tech, 2.5 mm planning die). Package-family parasitics/thermal ranges reused as literature ranges; its power numbers are NOT used (different technology)."),
    ("PowerClock (Project 27)", ["silicaflux-powerclock.zip"],
     "Power manager RTL: clock-enable, throttling, frequency-only operating points. NO DVFS / voltage control -> no DVFS assumed here."),
    ("ControlCore (Project 21)", ["silicaflux-controlcore.zip"], "HPC control subsystem RTL (RV32IM, 64+32 KiB SRAM); SKY130 synthesis smoke test only; no floorplan."),
    ("TensorCore 01-10", ["silicaflux-tensorcore*.zip"], "INT8 systolic tensor accelerator RTL; SKY130 synthesis smoke test (TC08: 154,882 cells, 1.597 mm2 cell area); no floorplan."),
    ("HPC vector modules (M02-M09)", ["silicaflux-hpc-m0*.zip", "silicaflux-hpc-fp32-fma.zip"], "FP32 vector lane/array/tile RTL; no floorplan."),
    ("DataFabric", ["silicaflux-datafabric*.zip"], "SFB2 interconnect + DMA RTL (integrated in sfv_soc_df)."),
    ("HostLink PCIe (Project 25)", ["silicaflux-hostlink*.zip"], "PCIe host-interface RTL behind a generic AXI endpoint boundary: the PCIe PHY/controller is vendor IP that does not exist here."),
    ("MemoryBridge (Project 24)", ["silicaflux-extmem*.zip"], "DDR / future-HBM bridge verified against a SIMULATED controller: no DDR/HBM PHY exists."),
    ("SRAM Wrapper Library (Project 01)", ["silicaflux-sramlib.zip"], "SRAM interfaces; ASIC backend maps to foundry macros."),
    ("YieldLab (Project 12)", ["silicaflux-yieldlab.zip"], "Wafer/defect/yield simulation linked to FloorplanLab geometry."),
    ("SilicaFlux-V release 1", ["silicaflux-v-release1.zip"], "RTL release of the implemented SoC."),
]
CAD_EXTENSIONS = (".step", ".stp", ".iges", ".igs", ".dxf", ".brd", ".kicad_pcb", ".gbr", ".gtl", ".odb", ".sldprt",
                  ".x_t", ".ipc", ".ipc2581", ".snp", ".s2p", ".s4p", ".gds", ".oas", ".lef", ".def")


def audit_repository(repo: Path, max_hash_mb: float = 300.0) -> dict:
    """Scan a repository checkout for the artefacts PackageTwin can use; nothing is guessed."""
    import fnmatch
    repo = Path(repo)
    files = [p for p in repo.rglob("*") if p.is_file() and ".git" not in p.parts]
    found = []
    for name, pats, role in AUDIT_TARGETS:
        hits = [p for p in files if any(fnmatch.fnmatch(p.name.lower(), pt.lower()) for pt in pats)]
        found.append({"artefact": name, "role": role, "status": "FOUND" if hits else "NOT FOUND",
                      "files": [{"path": str(p.relative_to(repo)), "bytes": p.stat().st_size,
                                 "sha256": sha256_file(p) if p.stat().st_size < max_hash_mb * 1e6 else None} for p in hits[:12]]})
    cad = []
    zips = [p for p in files if p.suffix.lower() == ".zip"]
    for p in files:
        if p.suffix.lower() in CAD_EXTENSIONS:
            cad.append({"path": str(p.relative_to(repo)), "inside": None})
    for z in zips:
        try:
            with zipfile.ZipFile(z) as zf:
                for n in zf.namelist():
                    if n.lower().endswith(CAD_EXTENSIONS) and "node_modules" not in n:
                        cad.append({"path": n, "inside": str(z.relative_to(repo))})
        except (zipfile.BadZipFile, OSError):
            continue
    cad_sf = [c for c in cad if c["inside"] is None or "silica" in (c["inside"] or "").lower()]
    return {"repo": str(repo), "n_files": len(files), "n_zips": len(zips), "artefacts": found,
            "cad_or_layout_files_silicaflux": cad_sf[:200], "n_cad_or_layout_files_silicaflux": len(cad_sf),
            "package_drawings_found": [c for c in cad_sf if c["path"].lower().endswith((".step", ".stp", ".iges", ".igs", ".dxf", ".brd", ".kicad_pcb", ".gbr", ".sldprt"))],
            "s_parameter_files_found": [c for c in cad_sf if re.search(r"\.s\d+p$", c["path"].lower())]}


def _parse_openroad_power(txt: str) -> dict:
    out = {}
    for line in txt.splitlines():
        m = re.match(r"^\s*(Sequential|Combinational|Clock|Macro|Pad|Total)\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)", line)
        if m:
            out[m.group(1).lower()] = {"internal_w": float(m.group(2)), "switching_w": float(m.group(3)),
                                       "leakage_w": float(m.group(4)), "total_w": float(m.group(5))}
    return out


def import_floorplanlab(zip_path: Path, out_dir: Path, repo_root: Optional[Path] = None) -> List[str]:
    """Vendor the per-run OpenROAD exports needed by PackageTwin (subset, with SHA-256 provenance)."""
    zip_path = Path(zip_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    zsha = sha256_file(zip_path)
    rel = str(zip_path.relative_to(repo_root)) if repo_root else zip_path.name
    imported = []
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        runs = sorted({m.group(1) for n in names for m in [re.search(r"reports/runs/([^/]+)/twinlab_floorplan\.json$", n)] if m})
        for run in runs:
            base = [n for n in names if n.endswith(f"reports/runs/{run}/twinlab_floorplan.json")][0][:-len("twinlab_floorplan.json")]
            raw = zf.read(base + "twinlab_floorplan.json")
            tw = json.loads(raw)
            rj = json.loads(zf.read(base + "run.json")) if base + "run.json" in names else {}
            if rj.get("status") != "completed" or not rj.get("physically_valid", False):
                continue
            pw = _parse_openroad_power(zf.read(base + "place_power.rpt").decode()) if base + "place_power.rpt" in names else {}
            fp = {
                "schema": "packagetwin.floorplan/1",
                "run_id": run,
                "description": rj.get("spec", {}).get("description", ""),
                "provenance": {"class": "eda_derived", "source_zip": rel, "source_zip_sha256": zsha,
                               "member": base + "twinlab_floorplan.json", "member_sha256": sha256_bytes(raw),
                               "fidelity": tw["provenance"].get("fidelity"), "label": tw["provenance"].get("label"),
                               "tools": tw["provenance"].get("tools"), "platform": tw["provenance"].get("platform"),
                               "process": tw["provenance"].get("process"), "netlist_sha256": tw["provenance"].get("netlist_sha256"),
                               "design": tw["provenance"].get("design"), "top": tw["provenance"].get("top")},
                "technology": tw.get("technology", {}),
                "die_um": tw["die_um"], "core_um": tw["core_um"],
                "macros": [{"name": m["name"], "master": m["master"], "bbox_um": m["bbox_um"], "orient": m.get("orient"),
                            "group": m.get("group")} for m in tw["macros"]],
                "std_cell_groups": tw["std_cell_groups"],
                "density_grid": tw["density_grid"],
                "io_pins": [{"name": p["name"], "dir": p.get("dir"), "edge": p.get("edge"), "layer": p.get("layer"),
                             "bbox_um": p.get("bbox_um")} for p in tw["io_pins"]],
                "power_grid": {"stripes": tw["power_grid"]["stripes"], "followpin_rails": tw["power_grid"].get("followpin_rails"),
                               "connectivity": tw["power_grid"].get("connectivity")},
                "area": tw.get("area", {}),
                "timing": {k: v for k, v in tw.get("timing", {}).items() if k != "critical_paths"},
                "openroad_power_vectorless": pw,
                "run_status": rj.get("status"), "physically_valid": rj.get("physically_valid"),
            }
            jdump(fp, out_dir / f"{run}.json", indent=None)
            imported.append(run)
        syn = [n for n in names if n.endswith("reports/synthesis/synthesis_summary.json")]
        if syn:
            s = json.loads(zf.read(syn[0]))
            s.pop("macro_instances", None)
            s.pop("netlist", None)
            jdump({"schema": "packagetwin.synthesis/1", "provenance": {"class": "eda_derived", "source_zip": rel,
                   "source_zip_sha256": zsha, "member": syn[0]}, "summary": s}, out_dir / "_synthesis_summary.json")
        prof = [n for n in names if n.endswith("platforms/ihp_sg13g2/profile.yaml")]
        if prof:
            txt = zf.read(prof[0]).decode()
            (out_dir / "_ihp_sg13g2_profile.yaml").write_text(
                f"# vendored verbatim from {rel}::{prof[0]} (sha256 of zip {zsha})\n" + txt)
    return imported


def list_floorplans() -> List[str]:
    return sorted(p.stem for p in (DATA / "floorplans").glob("*.json") if not p.stem.startswith("_"))


def load_floorplan(run_id: str) -> dict:
    p = DATA / "floorplans" / f"{run_id}.json"
    if not p.exists():
        raise TwinError(f"floorplan {run_id} not vendored (run `import-floorplanlab`); available: {list_floorplans()}")
    return jload(p)


# =============================================================================
# 9. Block-level power model and physical power mapping
# =============================================================================
class PowerModel:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else DATA / "power_model.json"
        self.d = jload(self.path)

    @property
    def workloads(self) -> List[str]:
        return list(self.d["workloads"].keys())

    def cls(self, group: str) -> str:
        return self.d["group_class"].get(group, "Other")

    def evaluate(self, fp: dict, workload: str, activity_scale: Optional[float] = None,
                 overrides: Optional[dict] = None) -> dict:
        """Block power breakdown for a vendored floorplan and an assumed workload."""
        d = copy.deepcopy(self.d)
        if overrides:
            for k, v in overrides.items():
                set_path(d, k, v)
        if workload not in d["workloads"]:
            raise TwinError(f"unknown workload {workload}; known: {list(d['workloads'])}")
        wl = d["workloads"][workload]
        c = d["coefficients"]
        V, f = pv(d["technology"]["vdd_v"]), pv(d["technology"]["f_clk_hz"])
        sc = pv(c["activity_scale"]) if activity_scale is None else activity_scale
        gated = set(pv(d["clock_gated_groups"]))
        groups = fp["std_cell_groups"]
        A_tot = sum(g["area_um2"] for g in groups)
        ff_per_um2 = pv(c["n_ff_total"]) / A_tot
        Eff, csink, csw, leak = pv(c["e_ff_clock_j"]), pv(c["c_clock_tree_per_sink_f"]), pv(c["c_sw_density_f_per_um2"]), pv(c["leak_density_w_per_um2"])
        rows = []
        for g in groups:
            act = dict(wl["groups"].get("default", {}))
            act.update(wl["groups"].get(g["name"], {}))
            alpha = min(1.0, act.get("alpha", 0.0) * sc)
            ce = act.get("ce", 1.0) if g["name"] in gated else 1.0
            A = g["area_um2"]
            nff = A * ff_per_um2
            p_ff = nff * Eff * f * ce
            p_tree = nff * csink * V ** 2 * f * ce
            p_logic = alpha * ce * csw * A * V ** 2 * f
            p_leak = leak * A
            rows.append({"name": g["name"], "class": self.cls(g["name"]), "kind": "std_cells", "area_um2": A,
                         "n_ff_est": nff, "alpha": alpha, "clock_enable": ce, "p_ff_clock_w": p_ff, "p_clock_tree_w": p_tree,
                         "p_logic_w": p_logic, "p_leak_w": p_leak, "power_w": p_ff + p_tree + p_logic + p_leak,
                         "prov": "eda_derived area/placement + assumed activity"})
        macros = []
        by_group: Dict[str, int] = {}
        for m in fp["macros"]:
            by_group[m["group"]] = by_group.get(m["group"], 0) + 1
        clipped = False
        for m in fp["macros"]:
            rate = wl["sram"].get(m["group"], 0.0) * sc / by_group[m["group"]]
            if rate > 1.0:
                rate, clipped = 1.0, True
            E = pv(c["sram_e_access_j"][m["master"]])
            pl = pv(c["sram_leak_w"][m["master"]])
            macros.append({"name": m["name"], "master": m["master"], "group": m["group"], "class": self.cls(m["group"]),
                           "kind": "sram_macro", "accesses_per_cycle": rate, "p_access_w": rate * E * f, "p_leak_w": pl,
                           "power_w": rate * E * f + pl, "prov": "eda_derived placement + assumed energy/activity"})
        io = c["io"]
        n_out = sum(1 for p in fp["io_pins"] if (p.get("dir") or "").upper() in ("OUTPUT", "INOUT"))
        a_io = min(1.0, wl.get("io_alpha", 0.0) * sc)
        p_io = n_out * a_io * (pv(io["c_pad_f"]) + pv(io["c_load_f"])) * pv(io["v_io_v"]) ** 2 * f
        by_class: Dict[str, float] = {}
        for r in rows + macros:
            by_class[r["class"]] = by_class.get(r["class"], 0.0) + r["power_w"]
        by_class["IO"] = by_class.get("IO", 0.0) + p_io
        core = sum(r["power_w"] for r in rows + macros)
        return {"workload": workload, "description": wl["description"], "activity_scale": sc, "vdd_v": V, "f_clk_hz": f,
                "groups": rows, "macros": macros, "io": {"n_outputs": n_out, "alpha": a_io, "power_w": p_io, "rail": "VDDIO (hypothetical)",
                                                         "prov": "hypothetical pad ring"},
                "by_class_w": by_class, "core_power_w": core, "io_power_w": p_io, "total_power_w": core + p_io,
                "core_current_a": core / V, "sram_rate_clipped": clipped,
                "components_w": {"ff_clock": sum(r["p_ff_clock_w"] for r in rows), "clock_tree": sum(r["p_clock_tree_w"] for r in rows),
                                 "logic": sum(r["p_logic_w"] for r in rows), "leakage": sum(r["p_leak_w"] for r in rows) + sum(m["p_leak_w"] for m in macros),
                                 "sram_access": sum(m["p_access_w"] for m in macros), "io": p_io}}

    def sources_for_die(self, fp: dict, br: dict, die: DiePlacement, layer: str = "active") -> List[HeatSource]:
        """Map the breakdown onto physically plausible die regions (package coordinates).

        * std-cell groups: EDA std-cell density grid x Gaussian(centroid, sigma = f x extent), clipped to the
          group's placement extent, normalised -> conservative.  (Logical groups are annotations, not fences.)
        * SRAM macros: uniform over the EDA macro outline.
        * I/O: hypothetical pad-driver strips along the die edges that carry output pins.
        """
        c = self.d["coefficients"]
        sf = pv(c["attribution_sigma_fraction"])
        dg = fp["density_grid"]
        U = np.array(dg["utilisation"], float)             # rows = y bins
        nb = U.shape[0]
        ox, oy = dg["origin_um"]
        bw, bh = dg["bin_w_um"], dg["bin_h_um"]
        xe_l = ox + bw * np.arange(U.shape[1] + 1)
        ye_l = oy + bh * np.arange(nb + 1)
        xc_l, yc_l = 0.5 * (xe_l[1:] + xe_l[:-1]), 0.5 * (ye_l[1:] + ye_l[:-1])
        X, Y = np.meshgrid(xc_l, yc_l)
        xe_p, _ = die.to_pkg(xe_l, np.zeros_like(xe_l))
        _, ye_p = die.to_pkg(np.zeros_like(ye_l), ye_l)
        flip = xe_p[0] > xe_p[-1]
        if flip:
            xe_p = xe_p[::-1]
        srcs = []
        pw = {r["name"]: r["power_w"] for r in br["groups"]}
        for g in fp["std_cell_groups"]:
            P_g = pw.get(g["name"], 0.0)
            ex = g.get("extent_um") or g.get("bbox_um")
            cx, cy = g["centroid_um"]
            sx = max(sf * (ex[2] - ex[0]), bw)
            sy = max(sf * (ex[3] - ex[1]), bh)
            w = U * np.exp(-0.5 * (((X - cx) / sx) ** 2 + ((Y - cy) / sy) ** 2))
            w *= (X >= ex[0]) & (X <= ex[2]) & (Y >= ex[1]) & (Y <= ex[3])
            if w.sum() <= 0:
                w = ((X >= ex[0]) & (X <= ex[2]) & (Y >= ex[1]) & (Y <= ex[3])).astype(float)
            if w.sum() <= 0:
                raise TwinError(f"group {g['name']} has no placement area for power attribution")
            grid = P_g * w / w.sum()
            if flip:
                grid = grid[:, ::-1]
            srcs.append(HeatSource(label=g["name"], group=self.cls(g["name"]), power=float(grid.sum()), grid_x=xe_p,
                                   grid_y=ye_p, grid_p=grid, layer=layer, die=die.name, prov="eda_derived+assumed"))
        for m in br["macros"]:
            bb = [mm for mm in fp["macros"] if mm["name"] == m["name"]][0]["bbox_um"]
            srcs.append(HeatSource(label=m["name"], group="SRAM", power=m["power_w"], rect=die.rect_to_pkg(bb),
                                   layer=layer, die=die.name, prov="eda_derived+assumed"))
        if br["io"]["power_w"] > 0:
            wstrip = pv(c["io"]["strip_width_um"])
            W_um, H_um = fp["die_um"][2] - fp["die_um"][0], fp["die_um"][3] - fp["die_um"][1]
            edges: Dict[str, int] = {}
            for p in fp["io_pins"]:
                if (p.get("dir") or "").upper() in ("OUTPUT", "INOUT"):
                    edges[p["edge"]] = edges.get(p["edge"], 0) + 1
            n = sum(edges.values())
            strip = {"bottom": [0, 0, W_um, wstrip], "top": [0, H_um - wstrip, W_um, H_um],
                     "left": [0, 0, wstrip, H_um], "right": [W_um - wstrip, 0, W_um, H_um]}
            for e, k in edges.items():
                srcs.append(HeatSource(label=f"io_ring_{e}", group="IO", power=br["io"]["power_w"] * k / n,
                                       rect=die.rect_to_pkg(strip[e]), layer=layer, die=die.name, prov="hypothetical"))
        return srcs



def set_path(d: dict, path: str, value) -> None:
    """Set a dotted-path value; if the target is a provenance dict only its 'value' is replaced."""
    keys = path.split(".")
    cur = d
    for k in keys[:-1]:
        cur = cur[int(k)] if isinstance(cur, list) else cur.setdefault(k, {})
    last = keys[-1]
    if isinstance(cur, dict) and isinstance(cur.get(last), dict) and "value" in cur[last] and not (isinstance(value, dict) and "value" in value):
        cur[last] = dict(cur[last], value=value)
    else:
        cur[last] = value


def get_path(d: dict, path: str, default=None):
    cur = d
    for k in path.split("."):
        if isinstance(cur, list):
            cur = cur[int(k)]
        elif isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return default
    return cur


# =============================================================================
# 10. Scenario configurations (declared design inputs with provenance)
# =============================================================================
JEDEC_SRC = "JESD51-7 high effective thermal conductivity (2s2p) test board"


def _common_board() -> dict:
    return {"standard": JEDEC_SRC,
            "width_mm": P(76.2, "specified", JEDEC_SRC), "length_mm": P(114.3, "specified", JEDEC_SRC),
            "thickness_mm": P(1.6, "specified", JEDEC_SRC),
            "signal_cu_um": P(70.0, "specified", "JESD51-7: 2 oz outer copper"),
            "plane_cu_um": P(35.0, "specified", "JESD51-7: two 1 oz internal planes"),
            "signal_coverage": P(0.10, "assumed", "trace coverage of outer layers", [0.05, 0.3]),
            "plane_coverage": P(0.90, "assumed", "internal plane coverage", [0.7, 1.0]),
            "emissivity": P(0.9, "published", "solder-mask emissivity 0.85-0.95"),
            "vrm_distance_mm": P(15.0, "assumed", "VRM output to package centre", [5, 40]),
            "under_package_via_fraction": P(0.01, "assumed", "plated-through via area fraction under the package (BGA dog-bone escape / EP thermal vias)", [0.0, 0.05])}


def _cooling_block(kind: str) -> dict:
    return {"type": kind,
            "velocity_m_s": P(2.0, "assumed", "approach air velocity for forced cooling", [0.5, 5.0]),
            "heatsink": {"material": "aluminium_6063",
                         "width_mm": P(40.0, "assumed", "extruded plate-fin heatsink footprint"),
                         "depth_mm": P(40.0, "assumed"), "base_mm": P(3.0, "assumed", "base plate thickness", [1.0, 8.0]),
                         "fin_height_mm": P(15.0, "assumed"), "fin_thickness_mm": P(0.8, "assumed"),
                         "n_fins": P(14, "assumed"), "emissivity": P(0.85, "published", "black anodised Al")},
            "cold_plate": {"material": "copper", "width_mm": P(40.0, "assumed"), "depth_mm": P(40.0, "assumed"),
                           "base_mm": P(3.0, "assumed"),
                           "h_eff_w_m2k": P(1.0e4, "assumed", "effective h referred to the base footprint of a liquid cold plate", [3e3, 3e4]),
                           "coolant_inlet_c": P(25.0, "assumed"), "flow_l_min": P(0.5, "assumed", "water flow", [0.2, 2.0])},
            "lid_emissivity": P(0.10, "published", "Ni-plated Cu lid 0.05-0.15"),
            "package_emissivity": P(0.90, "published", "substrate solder mask / mould")}


def default_config_A(cooling: str = "forced_air_heatsink", floorplan: str = "C_sram_near_compute", lid: bool = True) -> dict:
    return {
        "schema": "packagetwin.scenario/1",
        "name": "A_fcbga_" + ("lidded" if lid else "bare_die") + "_" + cooling,
        "architecture": "flip_chip_single_die",
        "title": "Scenario A - conventional flip-chip BGA, single SilicaFlux-V compute die",
        "status": "ENGINEERING ASSUMPTIONS for every package parameter; die outline, macro placement and std-cell density are EDA-derived (FloorplanLab, IHP SG13G2, pre-CTS).",
        "ambient_c": P(25.0, "specified", "JESD51-2 still-air reference ambient"),
        "tj_limits_c": {"planning": P(105.0, "assumed", "planning junction limit (PowerLink tj_max)"),
                        "characterised": P(125.0, "specified", "highest characterised corner in the vendored IHP SRAM liberty set (slow_1p08V_125C); not a qualified reliability limit")},
        "workload": "mixed",
        "die": {"floorplan": floorplan,
                "thickness_um": P(300.0, "assumed", "back-ground die thickness; IHP MPW delivery thickness not specified", [150, 725]),
                "beol_thickness_um": P(11.0, "assumed", "IHP SG13G2 7-metal stack incl. passivation, order of magnitude - verify", [8, 15]),
                "beol_metal_thickness_fraction": P(0.55, "assumed", "share of BEOL height that is metal levels"),
                "beol_metal_density": P(0.35, "assumed", "mean metal coverage per level", [0.2, 0.6]),
                "beol_via_density": P(0.03, "assumed", "via area fraction in via levels", [0.01, 0.08]),
                "active_thickness_um": P(2.0, "assumed", "effective heat-source layer thickness"),
                "offset_mm": [0.0, 0.0]},
        "bumps": {"type": "C4 solder bump, area array",
                  "pitch_um": P(200.0, "assumed", "C4 area-array pitch; IHP MPW dies need third-party wafer bumping (UBM + solder) - not available in the repository", [150, 250]),
                  "diameter_um": P(100.0, "assumed"), "height_um": P(70.0, "assumed"),
                  "material": "solder_sac305",
                  "edge_keepout_um": P(120.0, "assumed", "bump centre to die edge"),
                  "signal_rings": P(3, "assumed", "outer bump rings reserved for signals + VDDIO/VSS (2 rings leave the C-floorplan die 1 signal short at 200 um)"),
                  "pg_pattern": "checkerboard",
                  "io_power_per_signals": P(6, "assumed", "one VDDIO/VSS pair per N signal bumps (SSO rule of thumb)"),
                  "underfill_fillet_mm": P(0.4, "assumed"),
                  "r_contact_ohm": P(0.008, "assumed", "UBM + pads + intermetallics per bump (PowerLink fc_bga 6-20 mOhm range)"),
                  "i_max_a": P(0.15, "published", "C4 EM-limited current at 105 degC (PowerLink package_library fc_bga, literature 0.08-0.25 A)"),
                  "l_loop_h": P(60e-12, "published", "VDD/VSS bump-pair loop inductance (PowerLink fc_bga literature range 30-120 pH)")},
        "substrate": {"body_mm": P(10.0, "assumed", "FCBGA body", [8, 20]),
                      "metal_layers": P(4, "assumed", "1-2-1 build-up", [2, 10]),
                      "core_um": P(400.0, "assumed"), "buildup_dielectric_um": P(30.0, "assumed"),
                      "cu_um": P(15.0, "assumed"), "plane_coverage": P(0.80, "assumed"),
                      "signal_coverage": P(0.30, "assumed"), "via_fraction": P(0.02, "assumed"),
                      "line_um": P(25.0, "assumed", "build-up line width"), "space_um": P(25.0, "assumed"),
                      "bump_pad_um": P(110.0, "assumed", "substrate pad under a C4 bump"),
                      "via_stack_r_ohm": P(0.004, "assumed", "microvia + PTH stack per connection")},
        "bga": {"pitch_mm": P(0.8, "assumed", "0.8 mm pitch FBGA"), "ball_diameter_mm": P(0.45, "assumed"),
                "standoff_mm": P(0.30, "assumed"), "edge_mm": P(0.6, "assumed", "body edge to outer ball centre"),
                "r_ball_ohm": P(0.003, "published", "ball + escape via (PowerLink fc_bga 2-5 mOhm)"),
                "i_max_a": P(1.2, "published", "PowerLink fc_bga pin current"),
                "l_loop_h": P(0.5e-9, "published", "ball pair + PCB via loop inductance (PowerLink)"),
                "pcb_line_um": P(100.0, "assumed", "PCB escape line"), "pcb_space_um": P(100.0, "assumed"),
                "pcb_pad_um": P(400.0, "assumed")},
        "lid": {"enabled": lid, "material": "copper", "thickness_mm": P(0.8, "assumed", "", [0.3, 2.0]),
                "inset_mm": P(0.3, "assumed", "lid edge inset from body edge"),
                "foot_width_mm": P(1.2, "assumed", "lid seal-ring foot width"), "adhesive": "lid_adhesive"},
        "tim1": {"material": "tim1_polymer", "k_w_mk": P(3.0, "assumed", "TIM1 bulk conductivity", [1.0, 15.0]),
                 "thickness_um": P(50.0, "assumed", "TIM1 bond line", [20, 150]),
                 "contact_mm2k_w": P(5.0, "assumed", "per-interface contact resistance", [1.0, 20.0])},
        "tim2": {"material": "tim2_grease", "k_w_mk": P(4.0, "assumed", "", [1.0, 8.0]),
                 "thickness_um": P(50.0, "assumed", "", [20, 150]), "contact_mm2k_w": P(5.0, "assumed", "", [1.0, 20.0])},
        "cooling": _cooling_block(cooling),
        "board": _common_board(),
        "pdn": {"rail": "VDD (core)", "vdd_v": P(1.2, "specified", "IHP SG13G2 typ corner"),
                "ir_budget_fraction": P(0.03, "assumed", "static IR budget (PowerLink VDD_CORE dc_ir 30 mV of 1.0 V)"),
                "dynamic_budget_fraction": P(0.05, "assumed"),
                "metal_resistivity_ohm_m": P(3.0e-8, "assumed", "Al-Cu interconnect film"),
                "tm1_thickness_um": P(2.0, "assumed", "TopMetal1 thickness (public SG13G2 docs ~2 um - verify)"),
                "tm2_thickness_um": P(3.0, "assumed", "TopMetal2 thickness (public SG13G2 docs ~3 um - verify)"),
                "m5_thickness_um": P(0.49, "assumed", "Metal5 thickness (verify)"),
                "m1_thickness_um": P(0.42, "assumed", "Metal1 thickness (verify)"),
                "tm1_strap_width_um": P(1.8, "eda_derived", "FloorplanLab PDN TopMetal1 straps (horizontal)"),
                "tm1_strap_pitch_um": P(30.24, "eda_derived", "FloorplanLab PDN strap2_pitch"),
                "m5_strap_width_um": P(2.2, "eda_derived", "FloorplanLab PDN Metal5 straps (vertical)"),
                "m5_strap_pitch_um": P(75.6, "eda_derived", "FloorplanLab PDN strap1_pitch"),
                "m1_rail_width_um": P(0.44, "eda_derived", "FloorplanLab followpin rail width"),
                "m1_rail_pitch_um": P(7.56, "eda_derived", "same-net followpin pitch (2 x 3.78 um rows)"),
                "bump_pad_redistribution_ohm": P(0.010, "assumed", "TopMetal2 bump pad + via stack to TopMetal1 grid per bump (no RDL design exists)"),
                "on_die_decap_f": P(2e-9, "assumed", "intrinsic + decap-cell capacitance (no filler/decap inserted yet)", [0.5e-9, 10e-9]),
                "on_die_decap_esr_ohm": P(0.05, "assumed"),
                "package_decap_f": P(0.0, "assumed", "no package decap in baseline"),
                "board_decap": {"bulk_f": P(100e-6, "assumed"), "bulk_esr_ohm": P(0.01, "assumed"), "bulk_esl_h": P(1e-9, "assumed"),
                                "mlcc_f": P(10e-6, "assumed", "4 x 2.2 uF 0402 near package"), "mlcc_esr_ohm": P(0.005, "assumed"),
                                "mlcc_esl_h": P(0.3e-9, "assumed")},
                "vrm": {"r_out_ohm": P(0.002, "assumed", "regulator output impedance (AC model only; DC output regulated at the VRM patch)"),
                        "l_out_h": P(20e-9, "assumed", "effective above loop bandwidth"),
                        "patch_r_ohm": P(1e-4, "assumed", "output-capacitor patch to plane spreading connection (static model)")},
                "board_planes_per_net": P(1, "specified", "JESD51-7: one internal plane per net"),
                "board_plane_cu_um": P(35.0, "specified", "JESD51-7 1 oz plane"),
                "die_grid_n": P(48, "assumed", "PDN die-grid nodes along the long die edge (numerical)"),
                "step_current_fraction": P(0.8, "assumed", "load step as a fraction of the workload current (idle -> workload)")},
        "mesh": {"base_h_um": 120.0, "ratio": 1.4, "growth": 0.30, "h_max_mm": 6.0},
    }


def default_config_A0() -> dict:
    """Reference: wire-bond QFN (the SilicaFlux-V prototype documents' low-pin-count option)."""
    cfg = default_config_A("natural")
    cfg.update({
        "name": "A0_wb_qfn_reference_natural",
        "architecture": "wire_bond_qfn",
        "title": "Reference A0 - wire-bond QFN with exposed pad (prototype-document option), face-up die",
        "qfn": {"body_mm": P(10.0, "assumed", "10x10 mm QFN-88 (PowerLink wb_qfn88)"), "thickness_mm": P(0.9, "assumed"),
                "paddle_mm": P(6.0, "assumed", "exposed die pad"), "leadframe_um": P(200.0, "assumed"),
                "lead_ring_mm": P(0.5, "assumed"), "lead_cu_fraction": P(0.55, "assumed", "lead coverage along the ring"),
                "solder_um": P(50.0, "assumed"), "paddle_solder_coverage": P(0.65, "assumed", "exposed-pad solder after voiding", [0.4, 0.9]),
                "die_attach_um": P(25.0, "assumed"), "die_attach_material": "die_attach_ag_epoxy",
                "wire_diameter_um": P(25.0, "published", "Au bond wire (PowerLink wb_qfn88)"),
                "wire_length_mm": P(1.6, "assumed", "PowerLink wb_qfn88 1.1-2.4 mm"),
                "pad_pitch_um": P(80.0, "assumed", "in-line bond-pad pitch"),
                "vdd_pads": P(8, "assumed", "PowerLink pin_plan VDD_CORE 8"), "vss_pads": P(8, "assumed", "PowerLink pin_plan 8 (+ exposed pad down-bonds)"),
                "r_lead_ohm": P(0.0015, "published", "PowerLink wb_qfn88 lead 1-3 mOhm"),
                "wire_i_max_a": P(0.25, "published", "PowerLink 25 um Au wire 0.15-0.35 A"),
                "wire_l_loop_h": P(1.5e-9, "assumed", "bond-wire pair loop inductance ~1 nH/mm")},
    })
    cfg["lid"]["enabled"] = False
    cfg["board"]["under_package_via_fraction"] = P(0.02, "assumed", "JESD51-5-style thermal via array under the exposed pad", [0.0, 0.05])
    return cfg


def default_config_B(interposer: bool = True, hbm: bool = False, cooling: str = "forced_air_heatsink") -> dict:
    """Research scenario B: multiple dies on a passive silicon interposer (or organic MCM)."""
    H = "hypothetical"
    cfg = default_config_A(cooling)
    cfg.update({
        "name": "B_" + ("si_interposer" if interposer else "organic_mcm") + ("_hbm" if hbm else "") + "_" + cooling,
        "architecture": "multi_die_interposer" if interposer else "multi_die_organic_mcm",
        "title": "Research scenario B - SilicaFlux-HPC chiplets on " + ("a passive silicon interposer" if interposer else "an organic MCM substrate"),
        "status": "HYPOTHETICAL research configuration. No SilicaFlux chiplet, interposer, micro-bump, UCIe or HBM capability exists; "
                  "every die size, power density and interconnect parameter is a placeholder for design-space exploration.",
        "workload": "hpc_nominal",
        "tj_limits_c": {"planning": P(105.0, "assumed", "planning junction limit"),
                        "characterised": P(125.0, "assumed", "placeholder")},
        "multi_die": {
            "interposer": interposer,
            "interposer_mm": [P(15.0, H, "interposer x"), P(11.0, H, "interposer y")],
            "interposer_um": P(100.0, H, "thinned passive Si interposer"),
            "tsv_diameter_um": P(10.0, H), "tsv_pitch_um": P(50.0, H),
            "rdl_um": P(5.0, H, "interposer RDL stack"), "rdl_layers": P(3, H),
            "rdl_line_um": P(1.0, H), "rdl_space_um": P(1.0, H),
            "ubump_pitch_um": P(40.0, H, "micro-bump pitch (requires fine-pitch assembly not available)"),
            "ubump_diameter_um": P(22.0, H), "ubump_height_um": P(20.0, H),
            "ubump_i_max_a": P(0.04, "published", "PowerLink adv_organic micro-bump 0.02-0.07 A"),
            "d2d_rows": P(12, H, "micro-bump rows along each facing die edge reserved for die-to-die"),
            "d2d_gbps_per_wire": P(4.0, H, "per-wire rate assumption - NOT derived from wire length; UCIe-class links need licensed compliant IP + channel validation"),
            "die_gap_mm": P(0.2, H), "gap_fill": "mold_compound",
            "die_thickness_um": P(200.0, H),
            "dies": [
                {"name": "SFX_COMPUTE_0", "w_mm": P(6.0, H), "h_mm": P(6.0, H), "x_mm": -3.1, "y_mm": 1.4, "kind": "compute",
                 "power_density_w_mm2": P(0.20, H, "accelerator logic power-density placeholder", [0.02, 0.5])},
                {"name": "SFX_COMPUTE_1", "w_mm": P(6.0, H), "h_mm": P(6.0, H), "x_mm": 3.1, "y_mm": 1.4, "kind": "compute",
                 "power_density_w_mm2": P(0.20, H, "", [0.02, 0.5])},
                {"name": "SFX_CTRL_IO", "w_mm": P(12.2, H), "h_mm": P(3.2, H), "x_mm": 0.0, "y_mm": -3.6, "kind": "ctrl_io",
                 "power_density_w_mm2": P(0.08, H, "", [0.02, 0.3])},
            ],
            "hbm": hbm,
            "hbm_sites": [{"name": "HBM_PLACEHOLDER_0", "w_mm": P(7.75, H), "h_mm": P(11.87, H), "x_mm": -11.5, "y_mm": 0.0,
                           "power_w": P(5.0, H, "placeholder stack power")}],
        },
    })
    cfg["substrate"]["body_mm"] = P(25.0, H, "multi-die FCBGA body")
    cfg["substrate"]["metal_layers"] = P(8, H, "4-2-4 build-up")
    cfg["substrate"]["core_um"] = P(800.0, H)
    cfg["bumps"]["pitch_um"] = P(150.0, H, "C4 under interposer/dies")
    cfg["bumps"]["diameter_um"] = P(90.0, H)
    cfg["cooling"]["heatsink"]["width_mm"] = P(60.0, "assumed")
    cfg["cooling"]["heatsink"]["depth_mm"] = P(60.0, "assumed")
    cfg["cooling"]["heatsink"]["n_fins"] = P(20, "assumed")
    cfg["cooling"]["heatsink"]["base_mm"] = P(5.0, "assumed")
    cfg["cooling"]["cold_plate"]["width_mm"] = P(60.0, "assumed")
    cfg["cooling"]["cold_plate"]["depth_mm"] = P(60.0, "assumed")
    cfg["pdn"]["vdd_v"] = P(0.9, H, "core rail for a hypothetical advanced-node chiplet")
    cfg["pdn"]["board_plane_cu_um"] = P(70.0, H, "2 oz power planes")
    cfg["pdn"]["board_planes_per_net"] = P(2, H, "two power planes per net on the system board")
    cfg["pdn"]["on_die_decap_f"] = P(600e-9, H, "aggregate on-die decap of three advanced-node chiplets", [100e-9, 2e-6])
    cfg["pdn"]["on_die_decap_esr_ohm"] = P(0.0005, H)
    cfg["pdn"]["package_decap_f"] = P(20e-6, H, "land-side / die-side package capacitors")
    cfg["pdn"]["board_decap"] = {"bulk_f": P(2e-3, H), "bulk_esr_ohm": P(0.002, H), "bulk_esl_h": P(1e-9, H),
                                 "mlcc_f": P(200e-6, H, "MLCC bank under the package"), "mlcc_esr_ohm": P(0.0005, H), "mlcc_esl_h": P(0.05e-9, H)}
    cfg["pdn"]["vrm"] = {"r_out_ohm": P(0.0005, H), "l_out_h": P(2e-9, H), "patch_r_ohm": P(5e-5, H)}
    cfg["mesh"] = {"base_h_um": 300.0, "ratio": 1.4, "growth": 0.30, "h_max_mm": 6.0}
    return cfg


# =============================================================================
# 11. Model builders: config -> PackageModel
# =============================================================================
def _m(materials: Dict[str, Material], name: str) -> Material:
    if name not in materials:
        raise TwinError(f"material {name} not in database")
    return materials[name]


def _with_k(materials: Dict[str, Material], base: str, new: str, k: float, prov: str = "assumed") -> str:
    m = copy.deepcopy(_m(materials, base))
    m.name, m.kx, m.ky, m.kz, m.prov = new, k, k, k, prov
    materials[new] = m
    return new


def derived_materials(cfg: dict, mats: Dict[str, Material]) -> Dict[str, Material]:
    """Composite / homogenised materials computed from the declared geometry (provenance 'derived')."""
    mats = dict(mats)
    b = cfg["board"]
    t_tot = pv(b["thickness_mm"]) * MM
    ts, tp = pv(b["signal_cu_um"]) * UM, pv(b["plane_cu_um"]) * UM
    td = (t_tot - 2 * ts - 2 * tp) / 3
    cu, fr4 = mats["copper"], mats["fr4_resin_glass"]
    cs, cpl = pv(b["signal_coverage"]), pv(b["plane_coverage"])
    mats["board_2s2p_eff"] = mix_laminate("board_2s2p_eff", [(ts, cs, cu, fr4), (td, 0, cu, fr4), (tp, cpl, cu, fr4), (td, 0, cu, fr4),
                                                             (tp, cpl, cu, fr4), (td, 0, cu, fr4), (ts, cs, cu, fr4)],
                                          "derived", "JESD51-7 2s2p laminate rule-of-mixtures")
    fvb = pv(b.get("under_package_via_fraction", 0.0))
    mats["board_via_eff"] = mix_columns("board_via_eff", fvb, cu, mats["board_2s2p_eff"], "derived", "PTH vias under the package")
    s = cfg["substrate"]
    nl = int(pv(s["metal_layers"]))
    tcu, tbu, tcore = pv(s["cu_um"]) * UM, pv(s["buildup_dielectric_um"]) * UM, pv(s["core_um"]) * UM
    fv = pv(s["via_fraction"])
    bu = mats["buildup_dielectric"]
    core = mats["package_core_laminate"]
    bu_v = mix_columns("bu_via", fv, cu, bu, "derived", "")
    core_v = mix_columns("core_pth", fv, cu, core, "derived", "")
    plies = []
    for i in range(nl):
        outer = i in (0, nl - 1)
        plies.append((tcu, pv(s["signal_coverage"]) if outer else pv(s["plane_coverage"]), cu, bu))
        if i < nl - 1:
            plies.append((tcore, 0.0, cu, core_v) if i == nl // 2 - 1 else (tbu, 0.0, cu, bu_v))
    mats["substrate_eff"] = mix_laminate("substrate_eff", plies, "derived", f"{nl}-metal-layer build-up laminate")
    g = cfg["bga"]
    f_ball = math.pi * (pv(g["ball_diameter_mm"]) / 2) ** 2 / pv(g["pitch_mm"]) ** 2
    mats["bga_eff"] = mix_columns("bga_eff", f_ball, mats["solder_sac305"], mats["air"], "derived", "BGA balls in air")
    bp = cfg["bumps"]
    f_b = math.pi * (pv(bp["diameter_um"]) / 2) ** 2 / pv(bp["pitch_um"]) ** 2
    mats["c4_underfill_eff"] = mix_columns("c4_underfill_eff", f_b, mats[bp["material"]], mats["underfill"], "derived", "C4 bumps in underfill")
    d = cfg["die"]
    tb = pv(d["beol_thickness_um"]) * UM
    fm = pv(d["beol_metal_thickness_fraction"])
    al, ox = mats["aluminium_alloy_film"], mats["sio2_film"]
    mats["beol_eff"] = mix_laminate("beol_eff", [(fm * tb, pv(d["beol_metal_density"]), al, ox),
                                                 ((1 - fm) * tb, pv(d["beol_via_density"]), al, ox)],
                                    "derived", "homogenised BEOL (metal levels in parallel, via levels in series)")
    for nm, spec in cfg.get("extra_materials", {}).items():
        m = copy.deepcopy(_m(mats, spec["base"]))
        m.name = nm
        f = spec.get("k_scale", 1.0)
        m.kx, m.ky, m.kz = m.kx * f, m.ky * f, m.kz * f
        if "k" in spec:
            m.kx = m.ky = m.kz = spec["k"]
        m.prov, m.note = spec.get("prov", "assumed"), spec.get("note", "")
        mats[nm] = m
    _with_k(mats, cfg["tim1"]["material"], "tim1", pv(cfg["tim1"]["k_w_mk"]))
    if "tim2" in cfg:
        _with_k(mats, cfg["tim2"]["material"], "tim2", pv(cfg["tim2"]["k_w_mk"]))
    md = cfg.get("multi_die")
    if md:
        f_t = math.pi * (pv(md["tsv_diameter_um"]) / 2) ** 2 / pv(md["tsv_pitch_um"]) ** 2
        mats["interposer_tsv_eff"] = mix_columns("interposer_tsv_eff", f_t, cu, mats["silicon"], "derived", "Cu TSVs in Si")
        mats["rdl_eff"] = mix_laminate("rdl_eff", [(0.5 * pv(md["rdl_um"]) * UM, 0.4, cu, ox), (0.5 * pv(md["rdl_um"]) * UM, 0.05, cu, ox)],
                                       "derived", "interposer RDL")
        f_u = math.pi * (pv(md["ubump_diameter_um"]) / 2) ** 2 / pv(md["ubump_pitch_um"]) ** 2
        mats["ubump_underfill_eff"] = mix_columns("ubump_underfill_eff", f_u, cu, mats["underfill"], "derived", "Cu-pillar micro-bumps in underfill")
    return mats


def cooling_coefficients(cfg: dict, mats: Dict[str, Material], dT: Dict[str, float], T_amb: float) -> dict:
    """Heat-transfer coefficients for every boundary group at the current surface temperature rises."""
    c = cfg["cooling"]
    kind = c["type"]
    V = pv(c["velocity_m_s"]) if kind in ("forced_air_heatsink", "forced_air") else 0.0
    out = {"type": kind}
    bw, bl = pv(cfg["board"]["width_mm"]) * MM, pv(cfg["board"]["length_mm"]) * MM
    eps_b = pv(cfg["board"]["emissivity"])
    Lb = bw * bl / (2 * (bw + bl))
    dtb = dT.get("board", 5.0)
    if V > 0:
        hb_top = hb_bot = h_forced_flat_plate(bl, V, T_amb)
    else:
        hb_top = h_natural_horizontal(Lb, dtb, T_amb, "up")
        hb_bot = h_natural_horizontal(Lb, dtb, T_amb, "down")
    hr_b = h_radiation(eps_b, T_amb + dtb, T_amb)
    out["board_top"] = hb_top + hr_b
    out["board_bottom"] = hb_bot + hr_b
    out["board_edge"] = h_natural_vertical(pv(cfg["board"]["thickness_mm"]) * MM * 10, dtb, T_amb) + hr_b
    body = pv(cfg["substrate"]["body_mm"]) * MM
    dtp = dT.get("package", 10.0)
    hp = h_forced_flat_plate(body, V, T_amb) if V > 0 else h_natural_horizontal(body / 4, dtp, T_amb, "up")
    out["package"] = hp + h_radiation(pv(c["package_emissivity"]), T_amb + dtp, T_amb)
    out["lid"] = hp + h_radiation(pv(c["lid_emissivity"]), T_amb + dtp, T_amb)
    if kind in ("passive_heatsink", "forced_air_heatsink"):
        hs = c["heatsink"]
        hm = _m(mats, hs["material"])
        mode = "forced" if kind == "forced_air_heatsink" else "natural"
        r = platefin_heatsink(pv(hs["width_mm"]) * MM, pv(hs["depth_mm"]) * MM, pv(hs["fin_height_mm"]) * MM,
                              pv(hs["fin_thickness_mm"]) * MM, int(pv(hs["n_fins"])), hm.kx, hm.rho, hm.cp, mode, V, T_amb,
                              dT.get("heatsink", 10.0), pv(hs["emissivity"]))
        out["heatsink_top"] = r["h_eff_base_w_m2k"]
        out["heatsink_detail"] = r
        Wh = pv(hs["width_mm"]) * MM
        out["heatsink_other"] = (h_forced_flat_plate(Wh, V, T_amb) if V > 0 else
                                 h_natural_vertical(pv(hs["base_mm"]) * MM * 5, dT.get("heatsink", 10.0), T_amb)) + \
            h_radiation(pv(hs["emissivity"]), T_amb + dT.get("heatsink", 10.0), T_amb)
        out["T_top"] = T_amb
    elif kind == "cold_plate":
        cp_ = c["cold_plate"]
        out["heatsink_top"] = pv(cp_["h_eff_w_m2k"])
        mdot = pv(cp_["flow_l_min"]) / 60e3 * 997.0
        out["coolant_rise_per_w"] = 1.0 / (mdot * 4180.0)
        out["T_top"] = pv(cp_["coolant_inlet_c"]) + 0.5 * dT.get("coolant_power_w", 0.0) * out["coolant_rise_per_w"]
        out["heatsink_other"] = h_natural_vertical(0.02, dT.get("heatsink", 5.0), T_amb)
    else:
        out["T_top"] = T_amb
    return out


def build_model(cfg: dict, materials: Optional[Dict[str, Material]] = None, pm: Optional[PowerModel] = None,
                workload: Optional[str] = None, power_scale: float = 1.0, dT: Optional[Dict[str, float]] = None,
                bc_mode: str = "operating") -> PackageModel:
    """Build the declared package stack.  bc_mode: operating | jc_top (idealised JESD51-14-style cold plate on
    the case top, all else adiabatic) | jb (idealised: fixed temperature at the ball plane, all else adiabatic)."""
    arch = cfg["architecture"]
    mats = derived_materials(cfg, materials or load_materials())
    pm = pm or PowerModel()
    if arch == "flip_chip_single_die":
        model = _build_flipchip(cfg, mats, pm, workload, power_scale, dT or {}, bc_mode)
    elif arch == "wire_bond_qfn":
        model = _build_qfn(cfg, mats, pm, workload, power_scale, dT or {}, bc_mode)
    elif arch.startswith("multi_die"):
        model = _build_multidie(cfg, mats, pm, workload, power_scale, dT or {}, bc_mode)
    else:
        raise TwinError(f"unknown architecture {arch}")
    model.meta["config_hash"] = stable_hash(cfg)
    model.meta["bc_mode"] = bc_mode
    model.meta["numerical_experiment"] = bool(cfg.get("numerical_experiment", False))
    model.issues = validate_model(model) + config_checks(cfg, model)
    return model


def config_checks(cfg: dict, model: PackageModel) -> List[Issue]:
    """Engineering plausibility flags beyond pure geometry validity."""
    out = []
    bp = cfg.get("bumps", {})
    if bp and pv(bp["diameter_um"]) >= pv(bp["pitch_um"]):
        out.append(Issue("ERROR", "BUMP_PITCH", "bump diameter >= pitch (bridging)", "bumps"))
    g = cfg.get("bga", {})
    if g and pv(g["ball_diameter_mm"]) >= pv(g["pitch_mm"]):
        out.append(Issue("ERROR", "BALL_PITCH", "ball diameter >= pitch", "bga"))
    for t in ("tim1", "tim2"):
        if t in cfg:
            if pv(cfg[t]["thickness_um"]) < 10:
                out.append(Issue("WARNING", "TIM_THIN", f"{t} bond line < 10 um is not manufacturable for polymer TIMs", t))
            if pv(cfg[t]["k_w_mk"]) > 20 and "indium" not in cfg[t]["material"]:
                out.append(Issue("WARNING", "TIM_K_HIGH", f"{t} k > 20 W/mK exceeds polymer/grease TIMs (metal TIM required)", t))
    c = cfg["cooling"]
    if c["type"] == "cold_plate" and pv(c["cold_plate"]["h_eff_w_m2k"]) > 1e5:
        out.append(Issue("WARNING", "COLDPLATE_H", "cold-plate h_eff > 1e5 W/m2K is beyond single-phase liquid cooling", "cooling"))
    if c["type"] in ("forced_air_heatsink", "forced_air") and pv(c["velocity_m_s"]) > 8:
        out.append(Issue("WARNING", "AIR_VELOCITY", "approach velocity > 8 m/s (acoustics / fan limits)", "cooling"))
    if model.meta.get("die_area_mm2", 0) > 0 and pv(cfg["substrate"]["body_mm"]) ** 2 < 2.0 * model.meta["die_area_mm2"]:
        out.append(Issue("WARNING", "BODY_SMALL", "package body < 2x die area: fan-out/escape likely infeasible", "substrate"))
    return out


def _cavity_rules(cavity_layers: List[str], lid_inner: Rect) -> List[BCRule]:
    """Enclosed air under the lid is adiabatic: every face inside the lid's inner outline on the die-level layers,
    plus only the UNDERSIDE of the lid (its top surface is an external boundary)."""
    lay = [c for c in cavity_layers if c != "lid"]
    return [BCRule("lid_cavity", "adiabatic", "any", lay, lid_inner, note="enclosed air under the lid (adiabatic)"),
            BCRule("lid_cavity", "adiabatic", "bottom", ["lid"], lid_inner, note="lid underside over the cavity (adiabatic)")]


def _bc_set_common(cfg, model_layers, h, T_amb, pkg_layers, lid_inner: Optional[Rect], cavity_layers, top_layer, top_kind):
    bcs = []
    if lid_inner is not None:
        bcs += _cavity_rules(cavity_layers, lid_inner)
    if top_kind in ("heatsink", "cold_plate"):
        bcs.append(BCRule("heatsink_top", "convection", "top", [top_layer], None, h["heatsink_top"], h["T_top"],
                          note="fin array / cold plate (effective h on base footprint)"))
        bcs.append(BCRule("heatsink_other", "convection", "any", [top_layer], None, h["heatsink_other"], T_amb))
    bcs.append(BCRule("lid_exposed", "convection", "any", ["lid", "tim2"], None, h["lid"], T_amb))
    bcs.append(BCRule("package_exposed", "convection", "any", pkg_layers, None, h["package"], T_amb))
    bcs.append(BCRule("board_top", "convection", "top", ["board"], None, h["board_top"], T_amb))
    bcs.append(BCRule("board_bottom", "convection", "bottom", ["board"], None, h["board_bottom"], T_amb))
    bcs.append(BCRule("board_edge", "convection", "side", ["board"], None, h["board_edge"], T_amb))
    return bcs


def _die_from_floorplan(cfg: dict) -> Tuple[dict, float, float]:
    fp = load_floorplan(cfg["die"]["floorplan"])
    W = (fp["die_um"][2] - fp["die_um"][0]) * UM
    H = (fp["die_um"][3] - fp["die_um"][1]) * UM
    return fp, W, H


def _build_flipchip(cfg, mats, pm, workload, power_scale, dT, bc_mode) -> PackageModel:
    T_amb = pv(cfg["ambient_c"])
    fp, W, H = _die_from_floorplan(cfg)
    off = cfg["die"].get("offset_mm", [0.0, 0.0])
    die_r = Rect.centered(off[0] * MM, off[1] * MM, W, H)
    body = pv(cfg["substrate"]["body_mm"]) * MM
    body_r = Rect.centered(0, 0, body, body)
    bw, bl = pv(cfg["board"]["width_mm"]) * MM, pv(cfg["board"]["length_mm"]) * MM
    board_r = Rect.centered(0, 0, bw, bl)
    if not die_r.expand(pv(cfg["bumps"]["underfill_fillet_mm"]) * MM).inside(body_r):
        raise TwinError("die + underfill fillet does not fit on the package body")
    cool = cfg["cooling"]["type"]
    lid_on = cfg["lid"]["enabled"]
    if bc_mode in ("jc_top", "jb"):
        cool = "none"
    h = cooling_coefficients(cfg, mats, dT, T_amb)
    lay = [Layer("board", "pcb", pv(cfg["board"]["thickness_mm"]) * MM, 3, "board_2s2p_eff", [(body_r, "board_via_eff")], note="JESD51-7 2s2p effective laminate")]
    if bc_mode == "jb":
        lay = []
    lay.append(Layer("bga", "balls", pv(cfg["bga"]["standoff_mm"]) * MM, 2, None, [(body_r, "bga_eff")], note="BGA balls (effective)"))
    lay.append(Layer("substrate", "substrate", _substrate_thickness(cfg), 3, None, [(body_r, "substrate_eff")]))
    fil = die_r.expand(pv(cfg["bumps"]["underfill_fillet_mm"]) * MM)
    lid_r = foot = lid_inner = None
    lid_mat = cfg["lid"]["material"]
    if lid_on:
        lid_r = body_r.expand(-pv(cfg["lid"]["inset_mm"]) * MM)
        lid_inner = lid_r.expand(-pv(cfg["lid"]["foot_width_mm"]) * MM)
        if not fil.inside(lid_inner):
            raise TwinError("die + fillet collides with the lid foot - enlarge the body or shrink the foot")
        foot = ring(lid_r, pv(cfg["lid"]["foot_width_mm"]) * MM)
    reg = [(fil, "underfill"), (die_r, "c4_underfill_eff")] + ([(r, cfg["lid"]["adhesive"]) for r in foot] if lid_on else [])
    lay.append(Layer("bumps", "die_interconnect", pv(cfg["bumps"]["height_um"]) * UM, 2, None, reg, note="C4 + underfill"))
    fr = [(r, lid_mat) for r in foot] if lid_on else []
    lay.append(Layer("beol", "beol", pv(cfg["die"]["beol_thickness_um"]) * UM, 1, None, [(die_r, "beol_eff")] + fr, note="die metallisation (face down)"))
    lay.append(Layer("active", "device", pv(cfg["die"]["active_thickness_um"]) * UM, 1, None, [(die_r, "silicon_device_layer")] + fr, source=True))
    lay.append(Layer("die", "silicon", pv(cfg["die"]["thickness_um"]) * UM - pv(cfg["die"]["active_thickness_um"]) * UM, 4, None, [(die_r, "silicon")] + fr))
    lay.append(Layer("tim1", "tim1", pv(cfg["tim1"]["thickness_um"]) * UM, 1, None, [(die_r, "tim1")] + fr))
    R1 = pv(cfg["tim1"]["contact_mm2k_w"]) * 1e-6
    ifs = [InterfaceRule("die/tim1", "die", "tim1", R1, ("silicon", "tim1"))]
    top_layer, top_kind = None, "none"
    if lid_on:
        lay.append(Layer("lid", "spreader", pv(cfg["lid"]["thickness_mm"]) * MM, 3, None, [(lid_r, lid_mat)]))
        ifs.append(InterfaceRule("tim1/lid", "tim1", "lid", R1, ("tim1", lid_mat)))
    hs_r = None
    if cool in ("passive_heatsink", "forced_air_heatsink", "cold_plate"):
        if cool == "cold_plate":
            cp_ = cfg["cooling"]["cold_plate"]
            hs_r = Rect.centered(0, 0, pv(cp_["width_mm"]) * MM, pv(cp_["depth_mm"]) * MM)
            hs_mat, hs_t = cp_["material"], pv(cp_["base_mm"]) * MM
            top_kind = "cold_plate"
        else:
            hs = cfg["cooling"]["heatsink"]
            hs_r = Rect.centered(0, 0, pv(hs["width_mm"]) * MM, pv(hs["depth_mm"]) * MM)
            hs_mat, hs_t = hs["material"], pv(hs["base_mm"]) * MM
            top_kind = "heatsink"
        if not hs_r.inside(board_r):
            raise TwinError("heatsink larger than the board domain")
        R2 = pv(cfg["tim2"]["contact_mm2k_w"]) * 1e-6
        if lid_on:
            lay.append(Layer("tim2", "tim2", pv(cfg["tim2"]["thickness_um"]) * UM, 1, None, [(lid_r, "tim2")]))
            ifs.append(InterfaceRule("lid/tim2", "lid", "tim2", R2, (lid_mat, "tim2")))
            ifs.append(InterfaceRule("tim2/heatsink", "tim2", "heatsink", R2, ("tim2", hs_mat)))
        else:
            ifs.append(InterfaceRule("tim1/heatsink", "tim1", "heatsink", R1, ("tim1", hs_mat)))
        lay.append(Layer("heatsink", "heatsink", hs_t, 3, None, [(hs_r, hs_mat)]))
        top_layer = "heatsink"
    pkg_layers = ["bga", "substrate", "bumps", "beol", "active", "die", "tim1"]
    cavity = ["substrate", "bumps", "beol", "active", "die", "tim1", "lid"]
    if bc_mode == "operating":
        bcs = _bc_set_common(cfg, lay, h, T_amb, pkg_layers, lid_inner, cavity, top_layer, top_kind)
    else:
        bcs = []
        if lid_inner is not None:
            bcs += _cavity_rules(cavity, lid_inner)
        if bc_mode == "jc_top":
            topname = "lid" if lid_on else "tim1"
            region = lid_r if lid_on else die_r
            if not lid_on:
                lay[-1] = Layer("tim1", "tim1", lay[-1].thickness, 1, None, [(die_r, "tim1")])
            bcs.append(BCRule("case_top_fixed", "dirichlet", "top", [topname], region, T=T_amb, note="idealised JESD51-14 cold plate"))
        else:
            bcs.append(BCRule("ball_plane_fixed", "dirichlet", "bottom", ["bga"], body_r, T=T_amb, note="idealised board clamp at the ball plane"))
    extra = []
    if top_kind == "heatsink" and "heatsink_detail" in h:
        extra.append(("heatsink", hs_r, h["heatsink_detail"]["fin_capacity_j_k"]))
    die = DiePlacement("SFV", die_r, face_down=True, floorplan=fp, thickness=pv(cfg["die"]["thickness_um"]) * UM)
    model = PackageModel(cfg["name"], "A", lay, mats, ifs, bcs, board_r if bc_mode != "jb" else body_r,
                         [(die_r.x0 - 0.2 * MM, die_r.x1 + 0.2 * MM)], [(die_r.y0 - 0.2 * MM, die_r.y1 + 0.2 * MM)],
                         [die], [], extra, T_amb)
    if bc_mode == "jb":
        model.domain = body_r
    model.meta.update({"die_rect": die_r, "body_rect": body_r, "lid_rect": lid_r, "heatsink_rect": hs_r, "cooling": h,
                       "die_area_mm2": W * H / MM ** 2, "floorplan": cfg["die"]["floorplan"], "lid": lid_on,
                       "case_layer": "lid" if lid_on else "die"})
    if workload:
        br = pm.evaluate(fp, workload)
        model.sources = pm.sources_for_die(fp, br, die)
        _scale_sources(model, power_scale, cfg.get("_class_scale"))
        model.meta["power_breakdown"] = br
    return model


def _scale_sources(model: PackageModel, power_scale: float, class_scale: Optional[Dict[str, float]] = None) -> None:
    for s in model.sources:
        f = power_scale
        if class_scale:
            f *= class_scale.get(s.group, class_scale.get("*", 1.0))
        s.power *= f
        if s.grid_p is not None:
            s.grid_p = s.grid_p * f


def _substrate_thickness(cfg) -> float:
    s = cfg["substrate"]
    nl = int(pv(s["metal_layers"]))
    return (nl * pv(s["cu_um"]) + (nl - 2) * pv(s["buildup_dielectric_um"]) + pv(s["core_um"])) * UM


def _build_qfn(cfg, mats, pm, workload, power_scale, dT, bc_mode) -> PackageModel:
    T_amb = pv(cfg["ambient_c"])
    q = cfg["qfn"]
    fp, W, H = _die_from_floorplan(cfg)
    die_r = Rect.centered(0, 0, W, H)
    body = pv(q["body_mm"]) * MM
    body_r = Rect.centered(0, 0, body, body)
    pad_r = Rect.centered(0, 0, pv(q["paddle_mm"]) * MM, pv(q["paddle_mm"]) * MM)
    if not die_r.inside(pad_r):
        raise TwinError("die larger than the exposed pad")
    bw, bl = pv(cfg["board"]["width_mm"]) * MM, pv(cfg["board"]["length_mm"]) * MM
    board_r = Rect.centered(0, 0, bw, bl)
    h = cooling_coefficients(cfg, mats, dT, T_amb)
    cu = "copper_alloy_c194"
    lr = ring(body_r, pv(q["lead_ring_mm"]) * MM)
    mats["lead_ring_eff"] = mix_columns("lead_ring_eff", pv(q["lead_cu_fraction"]), mats[cu], mats["mold_compound"], "derived", "QFN leads in mould")
    mats["ep_solder_eff"] = mix_columns("ep_solder_eff", pv(q["paddle_solder_coverage"]), mats["solder_sac305"], mats["air"], "derived", "exposed-pad solder with voids")
    mats["lead_solder_eff"] = mix_columns("lead_solder_eff", pv(q["lead_cu_fraction"]), mats["solder_sac305"], mats["air"], "derived", "lead solder joints")
    t_lf, t_da = pv(q["leadframe_um"]) * UM, pv(q["die_attach_um"]) * UM
    t_die, t_act, t_beol = pv(cfg["die"]["thickness_um"]) * UM, pv(cfg["die"]["active_thickness_um"]) * UM, pv(cfg["die"]["beol_thickness_um"]) * UM
    t_mold = pv(q["thickness_mm"]) * MM - t_lf - t_da - t_die - t_beol
    if t_mold <= 50 * UM:
        raise TwinError("QFN body too thin for die + leadframe (mould cap < 50 um)")
    lay = [Layer("board", "pcb", pv(cfg["board"]["thickness_mm"]) * MM, 3, "board_2s2p_eff", [(pad_r, "board_via_eff")]),
           Layer("solder", "solder", pv(q["solder_um"]) * UM, 1, None, [(pad_r, "ep_solder_eff")] + [(r, "lead_solder_eff") for r in lr]),
           Layer("leadframe", "leadframe", t_lf, 2, None, [(body_r, "mold_compound"), (pad_r, cu)] + [(r, "lead_ring_eff") for r in lr]),
           Layer("attach", "die_attach", t_da, 1, None, [(body_r, "mold_compound"), (die_r, q["die_attach_material"])]),
           Layer("die", "silicon", t_die - t_act, 4, None, [(body_r, "mold_compound"), (die_r, "silicon")]),
           Layer("active", "device", t_act, 1, None, [(body_r, "mold_compound"), (die_r, "silicon_device_layer")], source=True),
           Layer("beol", "beol", t_beol, 1, None, [(body_r, "mold_compound"), (die_r, "beol_eff")]),
           Layer("mold", "mould", t_mold, 3, None, [(body_r, "mold_compound")])]
    if bc_mode == "operating":
        bcs = [BCRule("package_top", "convection", "top", ["mold"], None, h["package"], T_amb),
               BCRule("package_exposed", "convection", "any", ["solder", "leadframe", "attach", "die", "active", "beol", "mold"], None, h["package"], T_amb),
               BCRule("board_top", "convection", "top", ["board"], None, h["board_top"], T_amb),
               BCRule("board_bottom", "convection", "bottom", ["board"], None, h["board_bottom"], T_amb),
               BCRule("board_edge", "convection", "side", ["board"], None, h["board_edge"], T_amb)]
    elif bc_mode == "jc_top":
        lay = lay[1:]
        bcs = [BCRule("case_top_fixed", "dirichlet", "top", ["mold"], body_r, T=T_amb)]
    else:
        lay = lay[1:]
        bcs = [BCRule("ball_plane_fixed", "dirichlet", "bottom", ["solder"], body_r, T=T_amb)]
    die = DiePlacement("SFV", die_r, face_down=False, floorplan=fp, thickness=t_die)
    dom = board_r if bc_mode == "operating" else body_r
    model = PackageModel(cfg["name"], "A0", lay, mats, [], bcs, dom,
                         [(die_r.x0 - 0.2 * MM, die_r.x1 + 0.2 * MM)], [(die_r.y0 - 0.2 * MM, die_r.y1 + 0.2 * MM)], [die], [], [], T_amb)
    model.meta.update({"die_rect": die_r, "body_rect": body_r, "lid_rect": None, "heatsink_rect": None, "cooling": h,
                       "die_area_mm2": W * H / MM ** 2, "floorplan": cfg["die"]["floorplan"], "lid": False, "case_layer": "mold"})
    if workload:
        br = pm.evaluate(fp, workload)
        model.sources = pm.sources_for_die(fp, br, die)
        _scale_sources(model, power_scale, cfg.get("_class_scale"))
        model.meta["power_breakdown"] = br
    return model


def synthetic_floorplan_B(d: dict) -> dict:
    """HYPOTHETICAL illustrative block plan for a research chiplet (fractions of the die)."""
    if d["kind"] == "compute":
        blocks = [("TensorCore array", "TensorCore", (0.10, 0.30, 0.90, 0.90), 0.50),
                  ("Vector lanes", "VectorEngine", (0.10, 0.12, 0.90, 0.30), 0.22),
                  ("SRAM banks W", "SRAM", (0.00, 0.12, 0.10, 1.00), 0.06),
                  ("SRAM banks E", "SRAM", (0.90, 0.12, 1.00, 1.00), 0.06),
                  ("SRAM row N", "SRAM", (0.10, 0.90, 0.90, 1.00), 0.05),
                  ("D2D PHY (to CTRL_IO)", "IO", (0.10, 0.00, 0.90, 0.12), 0.11)]
    else:
        blocks = [("ControlCore", "ControlCore", (0.38, 0.30, 0.62, 0.70), 0.14),
                  ("DataFabric", "DataFabric", (0.12, 0.30, 0.38, 0.70), 0.20),
                  ("DataFabric E", "DataFabric", (0.62, 0.30, 0.88, 0.70), 0.12),
                  ("D2D PHY (to compute)", "IO", (0.05, 0.70, 0.95, 1.00), 0.18),
                  ("PCIe PHY placeholder", "IO", (0.00, 0.00, 0.12, 0.70), 0.12),
                  ("DDR PHY placeholder", "IO", (0.88, 0.00, 1.00, 0.70), 0.16),
                  ("Misc / clocks", "ClockAndGlue", (0.12, 0.00, 0.88, 0.30), 0.08)]
    return {"kind": d["kind"], "prov": "hypothetical", "blocks": [{"name": n, "class": c, "frac": list(r), "power_share": s} for n, c, r, s in blocks]}


def _build_multidie(cfg, mats, pm, workload, power_scale, dT, bc_mode) -> PackageModel:
    T_amb = pv(cfg["ambient_c"])
    md = cfg["multi_die"]
    body = pv(cfg["substrate"]["body_mm"]) * MM
    body_r = Rect.centered(0, 0, body, body)
    bw, bl = pv(cfg["board"]["width_mm"]) * MM, pv(cfg["board"]["length_mm"]) * MM
    board_r = Rect.centered(0, 0, bw, bl)
    dies = []
    for d in md["dies"]:
        r = Rect.centered(d["x_mm"] * MM, d["y_mm"] * MM, pv(d["w_mm"]) * MM, pv(d["h_mm"]) * MM)
        dies.append((d, r, False))
    if md.get("hbm"):
        for d in md["hbm_sites"]:
            dies.append((d, Rect.centered(d["x_mm"] * MM, d["y_mm"] * MM, pv(d["w_mm"]) * MM, pv(d["h_mm"]) * MM), True))
    xs = [r for _, r, _ in dies]
    span = Rect(min(r.x0 for r in xs), min(r.y0 for r in xs), max(r.x1 for r in xs), max(r.y1 for r in xs))
    inter = md["interposer"]
    if inter:
        ip = md["interposer_mm"]
        ip_r = Rect.centered(0, 0, pv(ip[0]) * MM, pv(ip[1]) * MM)
        if md.get("hbm"):
            ip_r = Rect(min(ip_r.x0, span.x0 - 0.5 * MM), min(ip_r.y0, span.y0 - 0.5 * MM), max(ip_r.x1, span.x1 + 0.5 * MM), max(ip_r.y1, span.y1 + 0.5 * MM))
        if not span.inside(ip_r):
            raise TwinError("dies do not fit on the interposer")
        carrier = ip_r
    else:
        carrier = span.expand(0.5 * MM)
    if not carrier.expand(pv(cfg["bumps"]["underfill_fillet_mm"]) * MM).inside(body_r):
        raise TwinError("interposer/dies do not fit on the substrate body")
    cool = cfg["cooling"]["type"] if bc_mode == "operating" else "none"
    h = cooling_coefficients(cfg, mats, dT, T_amb)
    lid_r = body_r.expand(-pv(cfg["lid"]["inset_mm"]) * MM)
    lid_inner = lid_r.expand(-pv(cfg["lid"]["foot_width_mm"]) * MM)
    foot = ring(lid_r, pv(cfg["lid"]["foot_width_mm"]) * MM)
    lm = cfg["lid"]["material"]
    fr = [(r, lm) for r in foot]
    gapfill = md.get("gap_fill")
    lay = [] if bc_mode == "jb" else [Layer("board", "pcb", pv(cfg["board"]["thickness_mm"]) * MM, 3, "board_2s2p_eff", [(body_r, "board_via_eff")])]
    lay += [Layer("bga", "balls", pv(cfg["bga"]["standoff_mm"]) * MM, 2, None, [(body_r, "bga_eff")]),
            Layer("substrate", "substrate", _substrate_thickness(cfg), 3, None, [(body_r, "substrate_eff")])]
    fil = carrier.expand(pv(cfg["bumps"]["underfill_fillet_mm"]) * MM)
    if inter:
        lay.append(Layer("c4", "die_interconnect", pv(cfg["bumps"]["height_um"]) * UM, 2, None,
                         [(fil, "underfill"), (ip_r, "c4_underfill_eff")] + [(r, cfg["lid"]["adhesive"]) for r in foot]))
        lay.append(Layer("interposer", "interposer", pv(md["interposer_um"]) * UM, 2, None, [(ip_r, "interposer_tsv_eff")] + fr))
        lay.append(Layer("rdl", "interposer_rdl", pv(md["rdl_um"]) * UM, 1, None, [(ip_r, "rdl_eff")] + fr))
        ub = [(ip_r, "underfill")] if gapfill else []
        lay.append(Layer("ubumps", "die_interconnect", pv(md["ubump_height_um"]) * UM, 1, None,
                         ub + [(r, ("ubump_underfill_eff" if not hb else "ubump_underfill_eff")) for _, r, hb in dies] + fr))
    else:
        lay.append(Layer("c4", "die_interconnect", pv(cfg["bumps"]["height_um"]) * UM, 2, None,
                         [(fil, "underfill")] + [(r, "c4_underfill_eff") for _, r, _ in dies] + [(r, cfg["lid"]["adhesive"]) for r in foot]))
    gap = [(carrier, gapfill)] if gapfill else []
    t_die = pv(md["die_thickness_um"]) * UM
    t_act = pv(cfg["die"]["active_thickness_um"]) * UM
    t_beol = pv(cfg["die"]["beol_thickness_um"]) * UM
    lay.append(Layer("beol", "beol", t_beol, 1, None, gap + [(r, ("dram_stack_effective" if hb else "beol_eff")) for _, r, hb in dies] + fr))
    lay.append(Layer("active", "device", t_act, 1, None, gap + [(r, ("dram_stack_effective" if hb else "silicon_device_layer")) for _, r, hb in dies] + fr, source=True))
    lay.append(Layer("die", "silicon", t_die - t_act, 4, None, gap + [(r, ("dram_stack_effective" if hb else "silicon")) for _, r, hb in dies] + fr))
    lay.append(Layer("tim1", "tim1", pv(cfg["tim1"]["thickness_um"]) * UM, 1, None, [(carrier if gapfill else span, "tim1")] + fr))
    lay.append(Layer("lid", "spreader", pv(cfg["lid"]["thickness_mm"]) * MM, 3, None, [(lid_r, lm)]))
    R1 = pv(cfg["tim1"]["contact_mm2k_w"]) * 1e-6
    ifs = [InterfaceRule("die/tim1", "die", "tim1", R1, (None, "tim1")), InterfaceRule("tim1/lid", "tim1", "lid", R1, ("tim1", lm))]
    if not gapfill:
        lay[-2] = Layer("tim1", "tim1", lay[-2].thickness, 1, None, [(r, "tim1") for _, r, _ in dies] + fr)
    hs_r, top_kind, extra = None, "none", []
    if cool in ("passive_heatsink", "forced_air_heatsink", "cold_plate"):
        R2 = pv(cfg["tim2"]["contact_mm2k_w"]) * 1e-6
        if cool == "cold_plate":
            cp_ = cfg["cooling"]["cold_plate"]
            hs_r = Rect.centered(0, 0, pv(cp_["width_mm"]) * MM, pv(cp_["depth_mm"]) * MM)
            hs_mat, hs_t, top_kind = cp_["material"], pv(cp_["base_mm"]) * MM, "cold_plate"
        else:
            hs = cfg["cooling"]["heatsink"]
            hs_r = Rect.centered(0, 0, pv(hs["width_mm"]) * MM, pv(hs["depth_mm"]) * MM)
            hs_mat, hs_t, top_kind = hs["material"], pv(hs["base_mm"]) * MM, "heatsink"
        lay.append(Layer("tim2", "tim2", pv(cfg["tim2"]["thickness_um"]) * UM, 1, None, [(lid_r, "tim2")]))
        lay.append(Layer("heatsink", "heatsink", hs_t, 3, None, [(hs_r, hs_mat)]))
        ifs += [InterfaceRule("lid/tim2", "lid", "tim2", R2, (lm, "tim2")), InterfaceRule("tim2/heatsink", "tim2", "heatsink", R2, ("tim2", hs_mat))]
        if top_kind == "heatsink" and "heatsink_detail" in h:
            extra.append(("heatsink", hs_r, h["heatsink_detail"]["fin_capacity_j_k"]))
    pkg_layers = ["bga", "substrate", "c4", "interposer", "rdl", "ubumps", "beol", "active", "die", "tim1"]
    cavity = ["substrate", "c4", "interposer", "rdl", "ubumps", "beol", "active", "die", "tim1", "lid"]
    names = [L.name for L in lay]
    pkg_layers = [n for n in pkg_layers if n in names]
    cavity = [n for n in cavity if n in names]
    if bc_mode == "operating":
        bcs = _bc_set_common(cfg, lay, h, T_amb, pkg_layers, lid_inner, cavity, "heatsink" if hs_r else None, top_kind)
    elif bc_mode == "jc_top":
        bcs = _cavity_rules(cavity, lid_inner) + [BCRule("case_top_fixed", "dirichlet", "top", ["lid"], lid_r, T=T_amb)]
    else:
        bcs = _cavity_rules(cavity, lid_inner) + [BCRule("ball_plane_fixed", "dirichlet", "bottom", ["bga"], body_r, T=T_amb)]
    dps = []
    for d, r, hb in dies:
        fpb = None if hb else synthetic_floorplan_B(d)
        dps.append(DiePlacement(d["name"], r, face_down=True, floorplan=fpb, thickness=t_die, prov="hypothetical"))
    fx = [(r.x0 - 0.3 * MM, r.x1 + 0.3 * MM) for _, r, _ in dies]
    fy = [(r.y0 - 0.3 * MM, r.y1 + 0.3 * MM) for _, r, _ in dies]
    model = PackageModel(cfg["name"], "B", lay, mats, ifs, bcs, board_r if bc_mode != "jb" else body_r, fx, fy, dps, [], extra, T_amb)
    model.meta.update({"die_rect": span, "body_rect": body_r, "lid_rect": lid_r, "heatsink_rect": hs_r, "cooling": h,
                       "carrier_rect": carrier, "interposer": inter, "die_area_mm2": sum(r.area for _, r, _ in dies) / MM ** 2,
                       "case_layer": "lid", "lid": True})
    if workload:
        srcs, br = multidie_sources(cfg, dps, dies, power_scale, cfg.get("_die_scale"))
        model.sources = srcs
        model.meta["power_breakdown"] = br
    return model


def multidie_sources(cfg, dps: List[DiePlacement], dies, power_scale: float = 1.0, die_scale: Optional[Dict[str, float]] = None):
    srcs = []
    rows = []
    for dp, (d, r, hb) in zip(dps, dies):
        s = (die_scale or {}).get(dp.name, 1.0) * power_scale
        if hb:
            P_d = pv(d["power_w"]) * s
            srcs.append(HeatSource(f"{dp.name}", "HBM(placeholder)", P_d, rect=r, die=dp.name, prov="hypothetical"))
            rows.append({"die": dp.name, "block": dp.name, "class": "HBM(placeholder)", "power_w": P_d})
            continue
        P_d = pv(d["power_density_w_mm2"]) * (r.area / MM ** 2) * s
        for b in dp.floorplan["blocks"]:
            fx0, fy0, fx1, fy1 = b["frac"]
            br_ = Rect(r.x0 + fx0 * r.w, r.y0 + fy0 * r.h, r.x0 + fx1 * r.w, r.y0 + fy1 * r.h)
            p = P_d * b["power_share"]
            srcs.append(HeatSource(f"{dp.name}:{b['name']}", b["class"], p, rect=br_, die=dp.name, prov="hypothetical"))
            rows.append({"die": dp.name, "block": b["name"], "class": b["class"], "power_w": p})
    tot = sum(x["power_w"] for x in rows)
    by_class: Dict[str, float] = {}
    for x in rows:
        by_class[x["class"]] = by_class.get(x["class"], 0.0) + x["power_w"]
    by_die: Dict[str, float] = {}
    for x in rows:
        by_die[x["die"]] = by_die.get(x["die"], 0.0) + x["power_w"]
    return srcs, {"workload": "hpc_nominal (hypothetical power densities)", "rows": rows, "total_power_w": tot,
                  "core_power_w": tot, "by_class_w": by_class, "by_die_w": by_die, "prov": "hypothetical",
                  "core_current_a": tot / pv(cfg["pdn"]["vdd_v"])}


# =============================================================================
# 12. Thermal case runner and post-processing
# =============================================================================
TOP_RULES = ("heatsink_top", "heatsink_other", "lid_exposed", "package_top", "case_top_fixed")
BOARD_RULES = ("board_top", "board_bottom", "board_edge", "ball_plane_fixed")


def mesh_spec_for(cfg: dict, level: int) -> MeshSpec:
    m = cfg.get("mesh", {})
    return MeshSpec.level_spec(level, base_h=m.get("base_h_um", 120.0) * UM, ratio=m.get("ratio", 1.4),
                               growth=m.get("growth", 0.30), h_max=m.get("h_max_mm", 6.0) * MM)


def _surface_rises(solver: ThermalSolver, T: np.ndarray, model: PackageModel, Q: dict) -> Dict[str, float]:
    Ta = model.ambient_c
    out = {}
    for key, rules in (("board", ["board_top"]), ("package", ["lid_exposed", "package_top", "package_exposed"]),
                       ("heatsink", ["heatsink_top"])):
        for r in rules:
            v = solver.surface_mean_temperature(T, r)
            if np.isfinite(v):
                out[key] = max(v - (model.meta["cooling"].get("T_top", Ta) if key == "heatsink" else Ta), 0.05)
                break
    out["coolant_power_w"] = max(Q.get("heatsink_top", 0.0), 0.0)
    return out


def run_thermal(cfg: dict, workload: Optional[str] = None, level: int = 0, power_scale: float = 1.0,
                bc_mode: str = "operating", materials: Optional[Dict[str, Material]] = None, pm: Optional[PowerModel] = None,
                nonlinear: bool = False, max_h_iter: int = 6, h_tol: float = 0.01, keep: bool = False,
                fixed_dT: Optional[Dict[str, float]] = None) -> dict:
    """Solve one declared case.  Natural-convection and radiation coefficients are iterated to self-consistency
    with the solved surface temperatures (h depends on dT^1/4)."""
    workload = workload or cfg.get("workload")
    materials = materials or load_materials()
    pm = pm or PowerModel()
    dT = dict(fixed_dT) if fixed_dT else {}
    h_hist = []
    t0 = time.time()
    mesh = None
    for it in range(1, max_h_iter + 1):
        model = build_model(cfg, materials, pm, workload, power_scale, dT, bc_mode)
        errs = [i for i in model.issues if i.severity == "ERROR"]
        if errs:
            raise TwinError("non-physical configuration: " + "; ".join(f"{e.code}: {e.message}" for e in errs))
        if mesh is None:
            mesh = Mesh(model, mesh_spec_for(cfg, level))
        else:
            mesh.mat_names = list(model.materials.keys())
        solver = ThermalSolver(model, mesh)
        q, maprep = solver.source_vector()
        if nonlinear:
            T, nlinfo = solver.solve_nonlinear(q)
        else:
            T, nlinfo = solver.solve(q, x0=T if it > 1 else None), None
        bh = solver.boundary_heat(T, q)
        hc = {k: v for k, v in model.meta["cooling"].items() if isinstance(v, float)}
        h_hist.append(hc)
        if bc_mode != "operating" or fixed_dT is not None:
            break
        new_dT = _surface_rises(solver, T, model, bh["flows_w"])
        h_new = {k: v for k, v in cooling_coefficients(cfg, model.materials, new_dT, model.ambient_c).items() if isinstance(v, float)}
        change = max([abs(h_new[k] - hc[k]) / max(abs(hc[k]), 1e-9) for k in hc if k in h_new] + [0.0])
        dT = new_dT
        if change < h_tol:
            break
    res = postprocess(cfg, model, mesh, solver, T, q, maprep, bh, workload)
    res.update({"bc_mode": bc_mode, "level": level, "power_scale": power_scale, "h_iterations": len(h_hist),
                "h_converged_change": change if bc_mode == "operating" and fixed_dT is None else 0.0,
                "surface_dT_used": dT, "nonlinear": nlinfo, "wall_s": time.time() - t0})
    if keep:
        res["_solver"], res["_T"], res["_q"], res["_model"] = solver, T, q, model
    return res


def _source_layer_map(solver: ThermalSolver, T: np.ndarray, layer: str = "active") -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    m = solver.mesh
    k0, k1 = m.layer_k[layer]
    T3 = solver.T3(T)[k0:k1]
    import warnings
    with warnings.catch_warnings(), np.errstate(all="ignore"):
        warnings.simplefilter("ignore", RuntimeWarning)
        mp = np.nanmax(T3, axis=0)
    return m.xc, m.yc, mp


def postprocess(cfg, model: PackageModel, mesh: Mesh, solver: ThermalSolver, T, q, maprep, bh, workload) -> dict:
    Ta = model.ambient_c
    P = float(q.sum())
    src_cells = np.concatenate([solver.layer_cells(L.name) for L in model.layers if L.source])
    jmax = src_cells[np.argmax(T[src_cells])]
    kk, jj, ii = np.nonzero(mesh.active)
    Tj = float(T[jmax])
    res = {"case": cfg["name"], "scenario": model.scenario, "architecture": cfg["architecture"], "workload": workload,
           "power_w": P, "ambient_c": Ta, "tj_c": Tj, "tj_rise_k": Tj - Ta,
           "tj_location_mm": [float(mesh.xc[ii[jmax]] / MM), float(mesh.yc[jj[jmax]] / MM)],
           "theta_ja_k_w": (Tj - Ta) / P if P > 0 else float("nan"),
           "t_die_pw_mean_c": float(np.sum(q * T) / P) if P > 0 else float("nan"),
           "mesh": mesh.summary(), "solver": dict(solver.stats), "power_map": maprep,
           "energy_residual_rel": bh["energy_residual_rel"], "heat_flow_w": bh["flows_w"]}
    tot = sum(v for v in bh["flows_w"].values() if v > 0) or 1.0
    res["heat_split"] = {"top_path": sum(v for k, v in bh["flows_w"].items() if k in TOP_RULES) / tot,
                         "board_path": sum(v for k, v in bh["flows_w"].items() if k in BOARD_RULES) / tot,
                         "package_sides": bh["flows_w"].get("package_exposed", 0.0) / tot}
    res["interface_flows_w"] = solver.interface_heat(T)
    dies = {}
    for d in model.dies:
        c = src_cells[d.rect.contains(mesh.xc[ii[src_cells]], mesh.yc[jj[src_cells]])]
        if len(c):
            dies[d.name] = {"tj_c": float(T[c].max()), "tmean_c": float(T[c].mean()), "tmin_c": float(T[c].min()),
                            "power_w": float(sum(s.power for s in model.sources if s.die == d.name))}
    res["dies"] = dies
    dr = model.meta["die_rect"]
    case_layer = model.meta.get("case_layer", "lid")
    if case_layer in mesh.layer_k:
        res["case_top_c"] = solver.top_face_temperature(T, case_layer, dr.cx, dr.cy)
        res["psi_jt_k_w"] = (Tj - res["case_top_c"]) / P if P > 0 else float("nan")
    if "board" in mesh.layer_k:
        bx = model.meta["body_rect"].x1 + 1.0 * MM
        res["board_c"] = solver.top_face_temperature(T, "board", bx, model.meta["body_rect"].cy)
        res["psi_jb_k_w"] = (Tj - res["board_c"]) / P if P > 0 else float("nan")
    if model.meta.get("lid_rect") is not None and "lid" in mesh.layer_k:
        lr = model.meta["lid_rect"]
        xs = np.linspace(lr.x0 + 0.2 * MM, lr.x1 - 0.2 * MM, 15)
        tl = [solver.top_face_temperature(T, "lid", x, lr.cy) for x in xs]
        res["lid_top_spread_k"] = float(np.nanmax(tl) - np.nanmin(tl))
    blocks = []
    for s in model.sources:
        qs, _ = solver.source_vector([s])
        if qs.sum() <= 0:
            continue
        dens = qs / solver.V
        hot = dens > 0.1 * dens.max()
        blocks.append({"label": s.label, "class": s.group, "die": s.die, "power_w": s.power,
                       "t_mean_pw_c": float(np.sum(qs * T) / qs.sum()), "t_max_c": float(T[hot].max()),
                       "prov": s.prov})
    res["blocks"] = blocks
    classes: Dict[str, dict] = {}
    for b in blocks:
        c = classes.setdefault(b["class"], {"power_w": 0.0, "t_max_c": -1e9, "_tw": 0.0})
        c["power_w"] += b["power_w"]
        c["t_max_c"] = max(c["t_max_c"], b["t_max_c"])
        c["_tw"] += b["t_mean_pw_c"] * b["power_w"]
    for c in classes.values():
        c["t_mean_pw_c"] = c.pop("_tw") / c["power_w"] if c["power_w"] > 0 else float("nan")
    res["classes"] = classes
    h = model.meta["cooling"]
    res["cooling"] = {k: (v if not isinstance(v, dict) else {kk_: vv for kk_, vv in v.items()}) for k, v in h.items()}
    res["issues"] = [i.as_dict() for i in model.issues]
    res["config_hash"] = model.meta["config_hash"]
    if "power_breakdown" in model.meta:
        br = model.meta["power_breakdown"]
        res["power_breakdown"] = {k: br[k] for k in ("by_class_w", "total_power_w", "core_power_w") if k in br}
        res["power_breakdown"]["io_power_w"] = br.get("io_power_w", 0.0)
    x, y, mp = _source_layer_map(solver, T)
    res["_die_map"] = (x, y, mp)
    return res


def strip_private(res: dict) -> dict:
    return {k: v for k, v in res.items() if not k.startswith("_")}


def compact_thermal_model(cfg: dict, workload: Optional[str] = None, level: int = 0, materials=None, pm=None) -> dict:
    """JEDEC-style two-resistor compact model parameters from idealised boundary conditions (JESD15-3 concept):
    theta_JC(top): fixed temperature on the case top, all else adiabatic; theta_JB: fixed temperature at the ball
    plane, all else adiabatic.  Idealised numerical definitions, not JESD51-14/51-8 test results."""
    a = run_thermal(cfg, workload, level, bc_mode="jc_top", materials=materials, pm=pm)
    b = run_thermal(cfg, workload, level, bc_mode="jb", materials=materials, pm=pm)
    return {"theta_jc_top_k_w": a["theta_ja_k_w"], "theta_jb_k_w": b["theta_ja_k_w"],
            "definition": "idealised: Dirichlet on case top (jc) / ball plane (jb); all other faces adiabatic"}


def power_capacity(cfg: dict, tj_limit: float, workload: Optional[str] = None, level: int = 0, materials=None, pm=None,
                   iters: int = 6) -> dict:
    """Largest power (same spatial distribution) that keeps Tj <= tj_limit, iterating the T-dependent
    convection coefficients at that power."""
    r = run_thermal(cfg, workload, level, materials=materials, pm=pm)
    P0 = r["power_w"]
    scale = (tj_limit - r["ambient_c"]) / max(r["tj_rise_k"], 1e-12)
    for _ in range(iters):
        r = run_thermal(cfg, workload, level, power_scale=scale, materials=materials, pm=pm)
        new = scale * (tj_limit - r["ambient_c"]) / max(r["tj_rise_k"], 1e-12)
        if abs(new - scale) / scale < 2e-3:
            scale = new
            break
        scale = new
    return {"tj_limit_c": tj_limit, "p_max_w": P0 * scale, "theta_ja_at_pmax_k_w": r["theta_ja_k_w"],
            "headroom_factor": scale, "workload": r["workload"]}


# =============================================================================
# 13. Interconnect accounting: bump / ball maps, escape routing, S-parameters
# =============================================================================
def array_sites(rect: Rect, pitch: float, keepout: float) -> Tuple[np.ndarray, np.ndarray, int, int]:
    """Centred full area array of sites inside rect at the given pitch and edge keep-out."""
    nx = int(math.floor((rect.w - 2 * keepout) / pitch + 1e-9)) + 1
    ny = int(math.floor((rect.h - 2 * keepout) / pitch + 1e-9)) + 1
    if nx < 1 or ny < 1:
        raise TwinError("array does not fit")
    x0 = rect.cx - (nx - 1) * pitch / 2
    y0 = rect.cy - (ny - 1) * pitch / 2
    X, Y = np.meshgrid(x0 + pitch * np.arange(nx), y0 + pitch * np.arange(ny))
    return X, Y, nx, ny


def bump_map(die_rect: Rect, pitch: float, keepout: float, signal_rings: int, n_signals: int, io_power_per_signals: int,
             pattern: str = "checkerboard", pg_fraction: float = 1.0) -> dict:
    """Area-array bump allocation: signals + VDDIO/VSS pairs on the outer rings, core VDD/VSS inside."""
    X, Y, nx, ny = array_sites(die_rect, pitch, keepout)
    J, I = np.meshgrid(np.arange(ny), np.arange(nx), indexing="ij")
    ring_ = np.minimum.reduce([I, nx - 1 - I, J, ny - 1 - J])
    net = np.full(X.shape, "SPARE", dtype=object)
    outer = ring_ < signal_rings
    inner = ~outer
    if pattern == "checkerboard":
        core = np.where((I + J) % 2 == 0, "VDD", "VSS")
    elif pattern == "rows":
        core = np.where(J % 2 == 0, "VDD", "VSS")
    elif pattern == "quadrant":
        core = np.where((I < nx / 2) ^ (J < ny / 2), "VDD", "VSS")
    else:
        raise TwinError(f"bump pattern {pattern}")
    if pg_fraction < 1.0:
        rng = np.random.default_rng(20261110)
        drop = rng.random(X.shape) > pg_fraction
        core = np.where(drop, "SPARE", core)
    net[inner] = core[inner]
    # outer rings: walk the perimeter ring by ring, assign signals with a VDDIO/VSSIO pair every N signals
    order = np.argsort((ring_ * 1e6 + np.arctan2(Y - die_rect.cy, X - die_rect.cx)).ravel())
    s_left, cnt, k = n_signals, 0, 0
    for idx in order:
        jy, ix = divmod(idx, nx)
        if not outer[jy, ix]:
            continue
        if s_left <= 0:
            break
        if cnt == io_power_per_signals:
            net[jy, ix] = "VDDIO" if k % 2 == 0 else "VSSIO"
            k += 1
            if k % 2 == 0:
                cnt = 0
            continue
        net[jy, ix] = "SIG"
        s_left -= 1
        cnt += 1
    left = outer & (net == "SPARE")
    net[left] = core[left]                  # unused signal-ring sites become core P/G
    counts = {n: int((net == n).sum()) for n in ("VDD", "VSS", "SIG", "VDDIO", "VSSIO", "SPARE")}
    sites = [{"x_mm": float(x / MM), "y_mm": float(y / MM), "ring": int(r), "net": str(n)}
             for x, y, r, n in zip(X.ravel(), Y.ravel(), ring_.ravel(), net.ravel())]
    return {"pitch_um": pitch / UM, "nx": nx, "ny": ny, "sites_total": nx * ny, "counts": counts,
            "signals_required": n_signals, "signals_placed": counts["SIG"], "signal_shortfall": max(0, s_left),
            "outer_ring_capacity": int(outer.sum()), "sites": sites, "pattern": pattern}


def ball_map(body_rect: Rect, pitch: float, edge: float, n_signal: int, n_io_pg: int, die_rect: Rect) -> dict:
    X, Y, nx, ny = array_sites(body_rect, pitch, edge)
    J, I = np.meshgrid(np.arange(ny), np.arange(nx), indexing="ij")
    ring_ = np.minimum.reduce([I, nx - 1 - I, J, ny - 1 - J])
    net = np.full(X.shape, "SPARE", dtype=object)
    order = np.argsort((ring_ * 1e6 + np.arctan2(Y, X)).ravel())
    need_sig, need_io = n_signal, n_io_pg
    sig_rings_used = 0
    for idx in order:
        jy, ix = divmod(idx, nx)
        if need_sig > 0:
            net[jy, ix] = "SIG"
            need_sig -= 1
            sig_rings_used = max(sig_rings_used, ring_[jy, ix] + 1)
        elif need_io > 0:
            net[jy, ix] = "VDDIO" if need_io % 2 else "VSSIO"
            need_io -= 1
    core = net == "SPARE"
    pg = np.where((I + J) % 2 == 0, "VDD", "VSS")
    net[core] = pg[core]
    counts = {n: int((net == n).sum()) for n in ("VDD", "VSS", "SIG", "VDDIO", "VSSIO", "SPARE")}
    sites = [{"x_mm": float(x / MM), "y_mm": float(y / MM), "ring": int(r), "net": str(n)}
             for x, y, r, n in zip(X.ravel(), Y.ravel(), ring_.ravel(), net.ravel())]
    return {"pitch_mm": pitch / MM, "nx": nx, "ny": ny, "sites_total": nx * ny, "counts": counts,
            "signal_rings": int(sig_rings_used), "shortfall": max(0, need_sig) + max(0, need_io), "sites": sites}


def escape_layers(pitch: float, pad: float, line: float, space: float, rows: int) -> dict:
    """Escape-routing estimate: traces per channel between pads; a layer escapes (n+1) rows."""
    ch = pitch - pad
    n = int(math.floor((ch - space) / (line + space) + 1e-9))
    n = max(n, 0)
    per_layer = n + 1
    return {"traces_per_channel": n, "rows_per_layer": per_layer, "rows": rows,
            "layers_needed": int(math.ceil(rows / per_layer)) if rows > 0 else 0,
            "method": "channel count between pads, outer row escapes directly (classic escape estimate, no via-in-pad, no DRC)"}


def interconnect_study(cfg: dict, fp: Optional[dict] = None, die_rect: Optional[Rect] = None) -> dict:
    """Bump / ball / escape accounting for a flip-chip single-die configuration."""
    fp = fp or load_floorplan(cfg["die"]["floorplan"])
    W = (fp["die_um"][2] - fp["die_um"][0]) * UM
    H = (fp["die_um"][3] - fp["die_um"][1]) * UM
    die_rect = die_rect or Rect.centered(0, 0, W, H)
    b = cfg["bumps"]
    n_sig = len(fp["io_pins"])
    bm = bump_map(die_rect, pv(b["pitch_um"]) * UM, pv(b["edge_keepout_um"]) * UM, int(pv(b["signal_rings"])), n_sig,
                  int(pv(b["io_power_per_signals"])), b.get("pg_pattern", "checkerboard"))
    s = cfg["substrate"]
    body = pv(s["body_mm"]) * MM
    g = cfg["bga"]
    n_io_pg = bm["counts"]["VDDIO"] + bm["counts"]["VSSIO"]
    balls = ball_map(Rect.centered(0, 0, body, body), pv(g["pitch_mm"]) * MM, pv(g["edge_mm"]) * MM, bm["counts"]["SIG"], n_io_pg, die_rect)
    sig_rows_die = int(pv(b["signal_rings"]))
    esc_sub = escape_layers(pv(b["pitch_um"]) * UM, pv(s["bump_pad_um"]) * UM, pv(s["line_um"]) * UM, pv(s["space_um"]) * UM, sig_rows_die)
    esc_pcb = escape_layers(pv(g["pitch_mm"]) * MM, pv(g["pcb_pad_um"]) * UM, pv(g["pcb_line_um"]) * UM, pv(g["pcb_space_um"]) * UM, balls["signal_rings"])
    nl = int(pv(s["metal_layers"]))
    sig_layers_avail = max(nl - 2, 1)
    perim = 2 * (W + H)
    fanout_cap = int(perim / ((pv(s["line_um"]) + pv(s["space_um"])) * UM)) * max(esc_sub["layers_needed"], 1)
    return {"bumps": {k: v for k, v in bm.items() if k != "sites"}, "bump_sites": bm["sites"],
            "balls": {k: v for k, v in balls.items() if k != "sites"}, "ball_sites": balls["sites"],
            "substrate_escape": esc_sub, "pcb_escape": esc_pcb,
            "substrate_signal_layers_available": sig_layers_avail,
            "substrate_layers_ok": esc_sub["layers_needed"] <= sig_layers_avail,
            "die_perimeter_fanout_capacity": fanout_cap,
            "signals_required": n_sig, "signal_source": "FloorplanLab io_pins (73 logical core pins; no pad ring exists)",
            "die_rect_mm": die_rect.mm()}


# ---- S-parameter interface (measured / externally extracted data only) -------------------------
def read_touchstone(path: Path) -> dict:
    """Minimal Touchstone v1 reader (.sNp): returns freq (Hz), S (nf, n, n) complex, z0."""
    path = Path(path)
    m = re.search(r"\.s(\d+)p$", path.name.lower())
    if not m:
        raise TwinError("Touchstone file must end in .sNp")
    n = int(m.group(1))
    unit, fmt, z0 = 1e9, "MA", 50.0
    mult = {"hz": 1.0, "khz": 1e3, "mhz": 1e6, "ghz": 1e9}
    nums = []
    for line in path.read_text().splitlines():
        line = line.split("!")[0].strip()
        if not line:
            continue
        if line.startswith("#"):
            t = line[1:].lower().split()
            for i, tok in enumerate(t):
                if tok in mult:
                    unit = mult[tok]
                elif tok in ("ma", "db", "ri"):
                    fmt = tok.upper()
                elif tok == "r":
                    z0 = float(t[i + 1])
            continue
        nums += [float(v) for v in line.split()]
    per = 1 + 2 * n * n
    if len(nums) % per:
        raise TwinError("Touchstone data length inconsistent with port count")
    a = np.array(nums).reshape(-1, per)
    f = a[:, 0] * unit
    v = a[:, 1:].reshape(-1, n * n, 2)
    if fmt == "RI":
        S = v[..., 0] + 1j * v[..., 1]
    elif fmt == "MA":
        S = v[..., 0] * np.exp(1j * np.deg2rad(v[..., 1]))
    else:
        S = 10 ** (v[..., 0] / 20) * np.exp(1j * np.deg2rad(v[..., 1]))
    S = S.reshape(-1, n, n)
    if n == 2:
        S = S.transpose(0, 2, 1)      # Touchstone v1 2-port order is S11 S21 S12 S22
    return {"freq_hz": f, "S": S, "z0": z0, "ports": n, "file": str(path), "sha256": sha256_file(path)}


def write_touchstone(path: Path, f: np.ndarray, S: np.ndarray, z0: float = 50.0, comment: str = "") -> None:
    n = S.shape[1]
    lines = [f"! {c}" for c in comment.splitlines()] + [f"# HZ S RI R {z0:g}"]
    for k in range(len(f)):
        Sk = S[k].T if n == 2 else S[k]
        vals = []
        for v in Sk.ravel():
            vals += [f"{v.real:.9e}", f"{v.imag:.9e}"]
        lines.append(f"{f[k]:.9e} " + " ".join(vals))
    Path(path).write_text("\n".join(lines) + "\n")


def sparam_checks(sp_: dict) -> dict:
    """Passivity (max singular value <= 1), reciprocity (S = S^T), insertion/return loss summary.
    No standard compliance (PCIe/HBM/UCIe) is inferred: that needs the standard's compliance tooling,
    a full channel (package + board + connectors) and transmitter/receiver models."""
    S = sp_["S"]
    sv = np.array([np.linalg.svd(Sk, compute_uv=False).max() for Sk in S])
    rec = float(np.max(np.abs(S - S.transpose(0, 2, 1))))
    out = {"ports": sp_["ports"], "f_min_hz": float(sp_["freq_hz"][0]), "f_max_hz": float(sp_["freq_hz"][-1]),
           "max_singular_value": float(sv.max()), "passive": bool(sv.max() <= 1 + 1e-6),
           "reciprocity_error": rec, "reciprocal": rec < 1e-6,
           "compliance": "NOT ASSESSED - requires measured/extracted full-channel S-parameters and standard-specific compliance tools"}
    if sp_["ports"] >= 2:
        il = -20 * np.log10(np.maximum(np.abs(S[:, 1, 0]), 1e-30))
        rl = -20 * np.log10(np.maximum(np.abs(S[:, 0, 0]), 1e-30))
        out.update({"insertion_loss_db_at_fmax": float(il[-1]), "return_loss_db_min": float(rl.min())})
    return out


def synthetic_line_sparams(length_m: float, f: np.ndarray, R=50.0, L=300e-9, G=0.0, C=120e-12, z0=50.0) -> np.ndarray:
    """Exact 2-port S-parameters of a uniform RLGC line (per-metre values).  SYNTHETIC TEST FIXTURE ONLY."""
    w = 2 * np.pi * f
    Zs = R + 1j * w * L
    Yp = G + 1j * w * C
    gam = np.sqrt(Zs * Yp)
    Zc = np.sqrt(Zs / Yp)
    gl = gam * length_m
    A = np.cosh(gl); B = Zc * np.sinh(gl); Cc = np.sinh(gl) / Zc; D = A
    den = A + B / z0 + Cc * z0 + D
    S11 = (A + B / z0 - Cc * z0 - D) / den
    S21 = 2 / den
    S = np.zeros((len(f), 2, 2), complex)
    S[:, 0, 0] = S11; S[:, 1, 1] = S11; S[:, 1, 0] = S21; S[:, 0, 1] = S21
    return S


# =============================================================================
# 14. Power-delivery network (resistive, homogenised; not EM extraction)
# =============================================================================
@dataclass
class PDNStage:
    name: str
    rect: Rect
    nx: int
    ny: int
    rs_x: float           # sheet resistance for current along x (ohm/sq)
    rs_y: float
    tcr: float = 0.0      # 1/K
    note: str = ""


@dataclass
class PDNLink:
    a: str
    b: str
    xa: np.ndarray
    ya: np.ndarray
    xb: np.ndarray
    yb: np.ndarray
    R: np.ndarray        # ohm per link
    kind: str
    count: np.ndarray    # physical connections represented by each link (for per-connection current)
    i_max: float = float("inf")
    tcr: float = 0.0


class PDNNetwork:
    """One supply net (VDD or VSS) as a resistive graph of 2-D sheet stages joined by vertical links."""

    def __init__(self, net: str, stages: List[PDNStage], links: List[PDNLink], vrm_xy: Tuple[float, float],
                 vrm_patch: float, v_fixed: float, r_vrm: float):
        self.net, self.stages, self.links = net, stages, links
        self.offset = {}
        n = 0
        for st in stages:
            self.offset[st.name] = n
            n += st.nx * st.ny
        self.n = n + 1                      # + VRM node
        self.vrm = n
        self.vrm_xy, self.vrm_patch, self.v_fixed, self.r_vrm = vrm_xy, vrm_patch, v_fixed, r_vrm

    def stage(self, name) -> PDNStage:
        return [s for s in self.stages if s.name == name][0]

    def node(self, sname: str, x, y):
        st = self.stage(sname)
        i = np.clip(((np.asarray(x) - st.rect.x0) / st.rect.w * st.nx).astype(int), 0, st.nx - 1)
        j = np.clip(((np.asarray(y) - st.rect.y0) / st.rect.h * st.ny).astype(int), 0, st.ny - 1)
        return self.offset[sname] + j * st.nx + i

    def node_xy(self, sname: str):
        st = self.stage(sname)
        xs = st.rect.x0 + (np.arange(st.nx) + 0.5) * st.rect.w / st.nx
        ys = st.rect.y0 + (np.arange(st.ny) + 0.5) * st.rect.h / st.ny
        X, Y = np.meshgrid(xs, ys)
        return X.ravel(), Y.ravel()

    def branches(self, T_of: Optional[Callable[[str, np.ndarray, np.ndarray], np.ndarray]] = None):
        """All resistive branches (i, j, G, group)."""
        I, J, G, grp, CNT = [], [], [], [], []
        for st in self.stages:
            hx, hy = st.rect.w / st.nx, st.rect.h / st.ny
            X, Y = self.node_xy(st.name)
            fac = np.ones(st.nx * st.ny)
            if T_of is not None and st.tcr:
                fac = 1 + st.tcr * (T_of(st.name, X, Y) - 25.0)
            fac = fac.reshape(st.ny, st.nx)
            base = self.offset[st.name] + np.arange(st.nx * st.ny).reshape(st.ny, st.nx)
            if st.nx > 1:
                f = 0.5 * (fac[:, :-1] + fac[:, 1:])
                I.append(base[:, :-1].ravel()); J.append(base[:, 1:].ravel())
                G.append(((hy / hx) / st.rs_x / f).ravel()); grp += [st.name] * f.size; CNT.append(np.ones(f.size))
            if st.ny > 1:
                f = 0.5 * (fac[:-1, :] + fac[1:, :])
                I.append(base[:-1, :].ravel()); J.append(base[1:, :].ravel())
                G.append(((hx / hy) / st.rs_y / f).ravel()); grp += [st.name] * f.size; CNT.append(np.ones(f.size))
        for lk in self.links:
            na, nb = self.node(lk.a, lk.xa, lk.ya), self.node(lk.b, lk.xb, lk.yb)
            fac = 1.0
            if T_of is not None and lk.tcr:
                fac = 1 + lk.tcr * (T_of(lk.a, lk.xa, lk.ya) - 25.0)
            I.append(na); J.append(nb); G.append(1.0 / (lk.R * fac)); grp += [lk.kind] * len(na); CNT.append(np.asarray(lk.count, float))
        last = self.stages[-1]
        X, Y = self.node_xy(last.name)
        near = np.hypot(X - self.vrm_xy[0], Y - self.vrm_xy[1]) <= self.vrm_patch
        if not near.any():
            near[np.argmin(np.hypot(X - self.vrm_xy[0], Y - self.vrm_xy[1]))] = True
        nn = self.offset[last.name] + np.where(near)[0]
        I.append(nn); J.append(np.full(len(nn), self.vrm)); G.append(np.full(len(nn), 1.0 / (self.r_vrm * len(nn)))); grp += ["vrm_connection"] * len(nn)
        CNT.append(np.ones(len(nn)))
        return np.concatenate(I), np.concatenate(J), np.concatenate(G), np.array(grp), np.concatenate(CNT)

    def solve(self, inj: np.ndarray, T_of=None) -> dict:
        """inj: current injected INTO each node (A), length n-1 (VRM node excluded); VRM node held at v_fixed."""
        i, j, g, grp, cnt = self.branches(T_of)
        if np.any(g <= 0) or not np.all(np.isfinite(g)):
            raise TwinError("non-positive PDN conductance")
        n = self.n
        Gm = sp.coo_matrix((np.concatenate([g, g, -g, -g]), (np.concatenate([i, j, i, j]), np.concatenate([i, j, j, i]))), shape=(n, n)).tocsr()
        free = np.arange(n - 1)
        b = inj.copy() - Gm[free][:, [self.vrm]].toarray().ravel() * self.v_fixed
        Gff = Gm[free][:, free].tocsc()
        ncomp, lab = connected_components(Gm, directed=False)
        if ncomp > 1:
            raise TwinError(f"PDN {self.net}: {ncomp - 1} floating node group(s) - every stage must connect to the VRM")
        v = np.empty(n)
        v[free] = spla.spsolve(Gff, b)
        v[self.vrm] = self.v_fixed
        ib = g * (v[i] - v[j])
        kcl = Gm @ v
        kcl_res = float(np.max(np.abs(kcl[free] - inj))) if len(free) else 0.0
        i_vrm = float(kcl[self.vrm])
        loss = g * (v[i] - v[j]) ** 2
        groups = {}
        for gname in np.unique(grp):
            groups[str(gname)] = float(loss[grp == gname].sum())
        tellegen = float(np.sum((v[i] - v[j]) * ib) - np.sum(v[free] * inj) - v[self.vrm] * i_vrm)
        return {"v": v, "branch_i": ib, "branch_groups": grp, "branch_ij": (i, j), "branch_count": cnt, "branch_g": g, "i_vrm_a": i_vrm,
                "kcl_residual_a": kcl_res, "loss_w": float(loss.sum()), "loss_by_group_w": groups, "tellegen_w": tellegen}


def sheet_r(rho: float, t: float) -> float:
    return rho / t


def die_grid_sheet(cfg: dict) -> Tuple[float, float, dict]:
    """Homogenised on-die grid sheet resistance per net from the FloorplanLab strap geometry."""
    p = cfg["pdn"]
    rho = pv(p["metal_resistivity_ohm_m"])
    rs_tm1 = sheet_r(rho, pv(p["tm1_thickness_um"]) * UM)
    rs_m5 = sheet_r(rho, pv(p["m5_thickness_um"]) * UM)
    rs_m1 = sheet_r(rho, pv(p["m1_thickness_um"]) * UM)
    gx = pv(p["tm1_strap_width_um"]) / (pv(p["tm1_strap_pitch_um"]) * rs_tm1) + pv(p["m1_rail_width_um"]) / (pv(p["m1_rail_pitch_um"]) * rs_m1)
    gy = pv(p["m5_strap_width_um"]) / (pv(p["m5_strap_pitch_um"]) * rs_m5)
    return 1 / gx, 1 / gy, {"rs_tm1": rs_tm1, "rs_m5": rs_m5, "rs_m1": rs_m1,
                            "note": "TopMetal1 straps + Metal1 followpins carry x-current, Metal5 straps carry y-current; vias between levels ideal"}


def _load_currents_on_die(model: PackageModel, stage: PDNStage, V: float, die_name: Optional[str] = None,
                          extra: Optional[List[HeatSource]] = None) -> np.ndarray:
    """Map core-rail power sources (excluding the VDDIO pad ring and placeholders) onto PDN die-grid nodes (A)."""
    xe = stage.rect.x0 + np.arange(stage.nx + 1) * stage.rect.w / stage.nx
    ye = stage.rect.y0 + np.arange(stage.ny + 1) * stage.rect.h / stage.ny
    Pg = np.zeros((stage.ny, stage.nx))
    for s in list(model.sources) + list(extra or []):
        if s.label.startswith("io_ring") or s.group.startswith("HBM"):
            continue
        if die_name and s.die != die_name:
            continue
        if s.rect is not None:
            ox = overlap_lengths(np.array([s.rect.x0]), np.array([s.rect.x1]), xe)[0]
            oy = overlap_lengths(np.array([s.rect.y0]), np.array([s.rect.y1]), ye)[0]
            Pg += np.outer(oy, ox) / s.rect.area * s.power
        else:
            Ox = overlap_lengths(s.grid_x[:-1], s.grid_x[1:], xe) / np.diff(s.grid_x)[:, None]
            Oy = overlap_lengths(s.grid_y[:-1], s.grid_y[1:], ye) / np.diff(s.grid_y)[:, None]
            Pg += Oy.T @ s.grid_p @ Ox
    return (Pg / V).ravel()


def build_pdn(cfg: dict, model: PackageModel, bmap: Optional[dict] = None, die_n: Optional[int] = None) -> dict:
    """Assemble VDD and VSS networks for the declared architecture.  Returns networks + load vectors."""
    p = cfg["pdn"]
    V = pv(p["vdd_v"])
    arch = cfg["architecture"]
    rho_cu = model.materials["copper"].resistivity_ohm_m
    tcr_al = model.materials["aluminium_alloy_film"].tcr_per_k
    tcr_cu = model.materials["copper"].tcr_per_k
    vrm_d = pv(cfg["board"]["vrm_distance_mm"]) * MM
    body_r = model.meta["body_rect"]
    pcb_half = max(vrm_d + 5 * MM, body_r.w / 2 + 5 * MM)
    pcb_r = Rect.centered(0, 0, 2 * pcb_half, 2 * pcb_half)
    npcb = 40
    rs_pcb = sheet_r(rho_cu, pv(p["board_plane_cu_um"]) * UM) / pv(p.get("board_planes_per_net", 1))
    die_n = die_n or int(pv(p["die_grid_n"]))
    nets = {}
    loads = {}
    info = {"vdd_v": V, "architecture": arch}
    if arch in ("flip_chip_single_die", "wire_bond_qfn"):
        die = model.dies[0]
        rsx, rsy, dg = die_grid_sheet(cfg)
        info["die_grid"] = {"rs_x_ohm_sq": rsx, "rs_y_ohm_sq": rsy, **dg}
        nx = die_n
        ny = max(4, int(round(die_n * die.rect.h / die.rect.w)))
        die_st = PDNStage("die", die.rect, nx, ny, rsx, rsy, tcr_al, "homogenised TopMetal1/Metal5/Metal1 grid")
        pcb_st = PDNStage("pcb", pcb_r, npcb, npcb, rs_pcb, rs_pcb, tcr_cu, "board plane (1 oz)")
        if arch == "flip_chip_single_die":
            b = cfg["bumps"]
            s = cfg["substrate"]
            nl = int(pv(s["metal_layers"]))
            rs_sub = sheet_r(rho_cu, pv(s["cu_um"]) * UM) / pv(s["plane_coverage"])
            sub_st = PDNStage("substrate", body_r, 30, 30, rs_sub, rs_sub, tcr_cu, f"one {pv(s['cu_um'])} um plane per net ({nl} metal layers)")
            if bmap is None:
                bmap = interconnect_study(cfg, die_rect=die.rect)
            h_b = pv(b["height_um"]) * UM
            r_sold = model.materials[b["material"]].resistivity_ohm_m * h_b / (math.pi * (pv(b["diameter_um"]) * UM / 2) ** 2)
            r_bump = r_sold + pv(b["r_contact_ohm"]) + pv(p["bump_pad_redistribution_ohm"]) + pv(s["via_stack_r_ohm"])
            info["bump_r_ohm"] = {"solder_geometry": r_sold, "contact": pv(b["r_contact_ohm"]),
                                  "redistribution": pv(p["bump_pad_redistribution_ohm"]), "substrate_vias": pv(s["via_stack_r_ohm"]), "total": r_bump}
            g = cfg["bga"]
            r_ball = pv(g["r_ball_ohm"]) + pv(s["via_stack_r_ohm"])
            for net in ("VDD", "VSS"):
                bs = [x for x in bmap["bump_sites"] if x["net"] == net]
                bl = [x for x in bmap["ball_sites"] if x["net"] == net]
                if not bs or not bl:
                    raise TwinError(f"no {net} bumps or balls allocated")
                bx = np.array([x["x_mm"] for x in bs]) * MM
                by = np.array([x["y_mm"] for x in bs]) * MM
                lx = np.array([x["x_mm"] for x in bl]) * MM
                ly = np.array([x["y_mm"] for x in bl]) * MM
                links = [PDNLink("die", "substrate", bx, by, bx, by, np.full(len(bx), r_bump), "bumps", np.ones(len(bx)), pv(b["i_max_a"]),
                                 model.materials[b["material"]].tcr_per_k),
                         PDNLink("substrate", "pcb", lx, ly, lx, ly, np.full(len(lx), r_ball), "balls", np.ones(len(lx)), pv(g["i_max_a"]), tcr_cu)]
                nets[net] = PDNNetwork(net, [die_st, sub_st, pcb_st], links, (vrm_d, 0.0), 2.5 * MM,
                                       V if net == "VDD" else 0.0, pv(p["vrm"]["patch_r_ohm"]))
            info["bumps"] = {"VDD": bmap["bumps"]["counts"]["VDD"], "VSS": bmap["bumps"]["counts"]["VSS"]}
            info["balls"] = {"VDD": bmap["balls"]["counts"]["VDD"], "VSS": bmap["balls"]["counts"]["VSS"]}
        else:
            q = cfg["qfn"]
            r_wire = model.materials["gold_wire"].resistivity_ohm_m * pv(q["wire_length_mm"]) * MM / (math.pi * (pv(q["wire_diameter_um"]) * UM / 2) ** 2)
            body = body_r
            for net, npads in (("VDD", int(pv(q["vdd_pads"]))), ("VSS", int(pv(q["vss_pads"])))):
                # pads distributed evenly around the die periphery; leads at the body edge on the same ray
                th = (np.arange(npads) + (0.5 if net == "VSS" else 0.0)) / npads * 2 * np.pi + np.pi / 4
                ux, uy = np.cos(th), np.sin(th)
                sx = np.minimum(die.rect.w / 2 / np.maximum(np.abs(ux), 1e-9), die.rect.h / 2 / np.maximum(np.abs(uy), 1e-9)) * 0.97
                px, py = die.rect.cx + ux * sx, die.rect.cy + uy * sx
                sb = np.minimum(body.w / 2 / np.maximum(np.abs(ux), 1e-9), body.h / 2 / np.maximum(np.abs(uy), 1e-9)) * 0.97
                lx, ly = body.cx + ux * sb, body.cy + uy * sb
                links = [PDNLink("die", "pcb", px, py, lx, ly, np.full(npads, r_wire + pv(q["r_lead_ohm"])), "bond_wires",
                                 np.ones(npads), pv(q["wire_i_max_a"]), model.materials["gold_wire"].tcr_per_k)]
                nets[net] = PDNNetwork(net, [die_st, pcb_st], links, (vrm_d, 0.0), 2.5 * MM, V if net == "VDD" else 0.0,
                                       pv(p["vrm"]["patch_r_ohm"]))
            info["bond_wire_r_ohm"] = r_wire
            info["pads"] = {"VDD": int(pv(q["vdd_pads"])), "VSS": int(pv(q["vss_pads"]))}
        loads["die"] = _load_currents_on_die(model, die_st, V)
        info["stages"] = [asdict_stage(s) for s in nets["VDD"].stages]
    else:
        md = cfg["multi_die"]
        rsx, rsy, dg = die_grid_sheet(cfg)
        rs_die = 0.02
        info["die_grid"] = {"rs_x_ohm_sq": rs_die, "rs_y_ohm_sq": rs_die, "prov": "hypothetical advanced-node top-metal grid"}
        stages = [PDNStage(d.name, d.rect, 24, 24, rs_die, rs_die, tcr_cu) for d in model.dies if d.floorplan is not None]
        carrier = model.meta["carrier_rect"]
        s = cfg["substrate"]
        rs_sub = sheet_r(rho_cu, pv(s["cu_um"]) * UM) / pv(s["plane_coverage"]) / 2.0
        sub_st = PDNStage("substrate", body_r, 30, 30, rs_sub, rs_sub, tcr_cu, "two planes per net (8-layer)")
        pcb_st = PDNStage("pcb", pcb_r, npcb, npcb, rs_pcb, rs_pcb, tcr_cu)
        links_common = []
        pitch_u = pv(md["ubump_pitch_um"]) * UM
        r_ub = 0.040
        allst = list(stages)
        if md["interposer"]:
            rs_rdl = sheet_r(rho_cu, 0.5 * pv(md["rdl_um"]) * UM) / 0.5
            ip_st = PDNStage("interposer", carrier, 36, 28, rs_rdl, rs_rdl, tcr_cu, "interposer RDL power plane (hypothetical)")
            allst.append(ip_st)
            lower = "interposer"
        else:
            lower = "substrate"
        for st in stages:
            X, Y = np.meshgrid(st.rect.x0 + (np.arange(st.nx) + 0.5) * st.rect.w / st.nx, st.rect.y0 + (np.arange(st.ny) + 0.5) * st.rect.h / st.ny)
            cell = (st.rect.w / st.nx) * (st.rect.h / st.ny)
            if md["interposer"]:
                n_per = cell / pitch_u ** 2 * 0.35          # 70 % of micro-bumps are P/G, half per net
                r_each, imax, kind = r_ub, pv(md["ubump_i_max_a"]), "ubumps"
            else:
                pc = pv(cfg["bumps"]["pitch_um"]) * UM
                n_per = cell / pc ** 2 * 0.35
                r_each, imax, kind = 0.012, pv(cfg["bumps"]["i_max_a"]), "c4_bumps"
            links_common.append(PDNLink(st.name, lower, X.ravel(), Y.ravel(), X.ravel(), Y.ravel(), np.full(X.size, r_each / n_per),
                                        kind, np.full(X.size, n_per), imax, 0.0))
        if md["interposer"]:
            Xc, Yc, _, _ = array_sites(carrier, pv(cfg["bumps"]["pitch_um"]) * UM, 0.2 * MM)
            n_c4 = Xc.size
            sel = (np.arange(n_c4) % 2 == 0)
            r_c4_tsv = 0.012 + 0.010
            links_common.append(PDNLink("interposer", "substrate", Xc.ravel()[sel], Yc.ravel()[sel], Xc.ravel()[sel], Yc.ravel()[sel],
                                        np.full(sel.sum(), r_c4_tsv), "c4_tsv", np.ones(sel.sum()), pv(cfg["bumps"]["i_max_a"]), 0.0))
            info["c4_per_net"] = int(sel.sum())
        Xb, Yb, _, _ = array_sites(body_r, pv(cfg["bga"]["pitch_mm"]) * MM, pv(cfg["bga"]["edge_mm"]) * MM)
        inner = carrier.expand(1 * MM).contains(Xb, Yb).ravel()
        r_ball = pv(cfg["bga"]["r_ball_ohm"]) + pv(s["via_stack_r_ohm"])
        info["balls_per_net"] = int(inner.sum() // 2)
        for net in ("VDD", "VSS"):
            sel = inner & ((np.arange(Xb.size) % 2 == 0) if net == "VDD" else (np.arange(Xb.size) % 2 == 1))
            lk = links_common + [PDNLink("substrate", "pcb", Xb.ravel()[sel], Yb.ravel()[sel], Xb.ravel()[sel], Yb.ravel()[sel],
                                         np.full(sel.sum(), r_ball), "balls", np.ones(sel.sum()), pv(cfg["bga"]["i_max_a"]), tcr_cu)]
            nets[net] = PDNNetwork(net, allst + [sub_st, pcb_st], lk, (vrm_d + 5 * MM, 0.0), 3 * MM, V if net == "VDD" else 0.0,
                                   pv(p["vrm"]["patch_r_ohm"]))
        for st in stages:
            loads[st.name] = _load_currents_on_die(model, st, V, die_name=st.name)
        info["stages"] = [asdict_stage(s) for s in nets["VDD"].stages]
    return {"nets": nets, "loads": loads, "info": info, "bmap": bmap}


def asdict_stage(s: PDNStage) -> dict:
    return {"name": s.name, "rect_mm": s.rect.mm(), "nx": s.nx, "ny": s.ny, "rs_x_ohm_sq": s.rs_x, "rs_y_ohm_sq": s.rs_y, "note": s.note}


def solve_pdn(cfg: dict, model: PackageModel, pdn: Optional[dict] = None, T_of=None) -> dict:
    """Static IR drop: constant-current loads, VDD and VSS solved separately (exactly decoupled for
    current sinks), supply at the load = V(VDD) - V(VSS)."""
    pdn = pdn or build_pdn(cfg, model)
    V = pdn["info"]["vdd_v"]
    out = {"info": pdn["info"]}
    res = {}
    for net, nw in pdn["nets"].items():
        inj = np.zeros(nw.n - 1)
        for sname, cur in pdn["loads"].items():
            o = nw.offset[sname]
            inj[o:o + len(cur)] += (-cur if net == "VDD" else cur)
        res[net] = nw.solve(inj, T_of)
        res[net]["inj"] = inj
    vd, vs = res["VDD"]["v"], res["VSS"]["v"]
    I_load = sum(float(c.sum()) for c in pdn["loads"].values())
    eff = {}
    worst = 0.0
    for sname, cur in pdn["loads"].items():
        nw = pdn["nets"]["VDD"]
        o = nw.offset[sname]
        st = nw.stage(sname)
        ve = vd[o:o + st.nx * st.ny] - vs[o:o + st.nx * st.ny]
        drop = V - ve
        loaded = cur > 0
        eff[sname] = {"max_drop_mv": float(drop[loaded].max() * 1e3) if loaded.any() else 0.0,
                      "mean_drop_mv": float(np.average(drop[loaded], weights=cur[loaded]) * 1e3) if loaded.any() else 0.0,
                      "vdd_drop_mv": float((V - vd[o:o + st.nx * st.ny])[loaded].max() * 1e3) if loaded.any() else 0.0,
                      "vss_bounce_mv": float(vs[o:o + st.nx * st.ny][loaded].max() * 1e3) if loaded.any() else 0.0,
                      "map_mv": (drop * 1e3).reshape(st.ny, st.nx), "rect_mm": st.rect.mm(), "current_a": float(cur.sum())}
        worst = max(worst, eff[sname]["max_drop_mv"])
    P_load = 0.0
    for sname, cur in pdn["loads"].items():
        o = pdn["nets"]["VDD"].offset[sname]
        P_load += float(np.sum(cur * (vd[o:o + len(cur)] - vs[o:o + len(cur)])))
    I_vrm = res["VDD"]["i_vrm_a"]                      # current delivered by the regulator into the VDD net
    P_supply = V * I_vrm
    P_loss = res["VDD"]["loss_w"] + res["VSS"]["loss_w"]
    links = {}
    for net in ("VDD", "VSS"):
        nw = pdn["nets"][net]
        grp = res[net]["branch_groups"]
        ib = res[net]["branch_i"]
        cnt = res[net]["branch_count"]
        for kind in {lk.kind for lk in nw.links}:
            sel = grp == kind
            per = np.abs(ib[sel]) / cnt[sel]
            imax = min(lk.i_max for lk in nw.links if lk.kind == kind)
            d = links.setdefault(kind, {"max_per_connection_a": 0.0, "i_max_a": imax, "connections": 0.0, "total_a_per_net": 0.0})
            d["max_per_connection_a"] = max(d["max_per_connection_a"], float(per.max()) if per.size else 0.0)
            d["connections"] += float(cnt[sel].sum())
            d["total_a_per_net"] = max(d["total_a_per_net"], float(np.abs(ib[sel]).sum()))
    for d in links.values():
        d["em_margin"] = d["i_max_a"] / d["max_per_connection_a"] if d["max_per_connection_a"] > 0 else float("inf")
    out.update({"load_current_a": I_load, "vrm_current_a": I_vrm, "p_supply_w": P_supply, "p_load_w": P_load,
                "p_loss_w": P_loss, "loss_by_group_w": {n: res[n]["loss_by_group_w"] for n in res},
                "conservation": {"kcl_residual_a": max(res[n]["kcl_residual_a"] for n in res),
                                 "current_balance_rel": abs(I_vrm - I_load) / max(I_load, 1e-30),
                                 "power_balance_rel": abs(P_supply - P_load - P_loss) / max(P_supply, 1e-30),
                                 "tellegen_w": max(abs(res[n]["tellegen_w"]) for n in res)},
                "worst_drop_mv": worst, "dies": eff, "links": links,
                "budget_mv": pv(cfg["pdn"]["ir_budget_fraction"]) * V * 1e3,
                "within_budget": worst <= pv(cfg["pdn"]["ir_budget_fraction"]) * V * 1e3,
                "disclaimer": "homogenised resistive model with constant-current loads; vias between grid levels ideal; not EM extraction or IR signoff"})
    out["_res"] = res
    out["_pdn"] = pdn
    return out


def pdn_impedance(cfg: dict, n_pg_pairs: int, n_ball_pairs: int, r_die_eff: float, f: Optional[np.ndarray] = None,
                  link_l_bump: Optional[float] = None, link_l_ball: Optional[float] = None) -> dict:
    """Lumped PDN impedance seen by the die (VRM - board caps - package - bumps - on-die decap).
    Uses literature package inductances; NOT an extracted model."""
    p = cfg["pdn"]
    f = np.logspace(3, 9.5, 400) if f is None else f
    w = 2 * np.pi * f
    jw = 1j * w
    vr = p["vrm"]
    Zvrm = pv(vr["r_out_ohm"]) + jw * pv(vr["l_out_h"])
    bd = p["board_decap"]
    Zbulk = pv(bd["bulk_esr_ohm"]) + jw * pv(bd["bulk_esl_h"]) + 1 / (jw * pv(bd["bulk_f"]))
    Zmlcc = pv(bd["mlcc_esr_ohm"]) + jw * pv(bd["mlcc_esl_h"]) + 1 / (jw * pv(bd["mlcc_f"]))
    Zb = 1 / (1 / Zvrm + 1 / Zbulk + 1 / Zmlcc)
    Lball = (link_l_ball if link_l_ball is not None else pv(cfg["bga"]["l_loop_h"])) / max(n_ball_pairs * 0.8, 1)
    Lbump = (link_l_bump if link_l_bump is not None else pv(cfg["bumps"]["l_loop_h"])) / max(n_pg_pairs * 0.8, 1)
    Zpkg = Zb + jw * (Lball + 25e-12) + 0.0008
    if pv(p["package_decap_f"]) > 0:
        Zpd = 0.002 + jw * 30e-12 + 1 / (jw * pv(p["package_decap_f"]))
        Zpkg = 1 / (1 / Zpkg + 1 / Zpd)
    Zin = Zpkg + jw * Lbump + r_die_eff
    Zdie = pv(p["on_die_decap_esr_ohm"]) + 1 / (jw * pv(p["on_die_decap_f"]))
    Z = 1 / (1 / Zin + 1 / Zdie)
    mag = np.abs(Z)
    k = int(np.argmax(mag[f > 1e5])) + int(np.argmax(f > 1e5))
    return {"f_hz": f, "z_ohm": mag, "peak_ohm": float(mag[k]), "f_peak_hz": float(f[k]),
            "l_bump_eff_h": Lbump, "l_ball_eff_h": Lball,
            "note": "lumped series/parallel ladder with literature inductances; resonance between package inductance and on-die decap"}


# =============================================================================
# 15. Electrothermal coupling, PowerGrid exchange, multi-die analyses
# =============================================================================
LINK_LAYER = {"bumps": "bumps", "ubumps": "ubumps", "c4_tsv": "c4", "c4_bumps": "c4", "balls": "bga",
              "bond_wires": "mold", "vrm_connection": "board"}
STAGE_LAYER = {"die": "beol", "substrate": "substrate", "pcb": "board", "interposer": "rdl"}


def _layer_sampler(solver: ThermalSolver, T: np.ndarray, layer: str) -> Callable:
    m = solver.mesh
    k0, k1 = m.layer_k[layer]
    T3 = solver.T3(T)[k0:k1]
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        mp = np.nanmean(T3, axis=0)
    mp = np.where(np.isfinite(mp), mp, solver.model.ambient_c)

    def f(x, y):
        i = np.clip(np.searchsorted(m.xe, x) - 1, 0, m.nx - 1)
        j = np.clip(np.searchsorted(m.ye, y) - 1, 0, m.ny - 1)
        return mp[j, i]
    return f


def _points_to_source(label: str, layer: str, x: np.ndarray, y: np.ndarray, p: np.ndarray, rect: Rect, nb: int = 48) -> HeatSource:
    gx = np.linspace(rect.x0, rect.x1, nb + 1)
    gy = np.linspace(rect.y0, rect.y1, nb + 1)
    H, _, _ = np.histogram2d(np.clip(y, rect.y0, rect.y1), np.clip(x, rect.x0, rect.x1), bins=[gy, gx], weights=p)
    return HeatSource(label, "PDN_loss", float(H.sum()), grid_x=gx, grid_y=gy, grid_p=H, layer=layer, prov="derived")


def pdn_loss_sources(pdn_sol: dict, model: PackageModel) -> List[HeatSource]:
    """Every I^2R loss of the PDN becomes a heat source in the layer where it is dissipated (conservative)."""
    out = []
    names = [L.name for L in model.layers]
    for net in ("VDD", "VSS"):
        r = pdn_sol["_res"][net]
        nw = pdn_sol["_pdn"]["nets"][net]
        i, j = r["branch_ij"]
        loss = r["branch_g"] * (r["v"][i] - r["v"][j]) ** 2
        grp = r["branch_groups"]
        pos = {}
        for st in nw.stages:
            X, Y = nw.node_xy(st.name)
            pos[st.name] = (nw.offset[st.name], X, Y)
        xs = np.zeros(nw.n)
        ys = np.zeros(nw.n)
        for st in nw.stages:
            o, X, Y = pos[st.name]
            xs[o:o + len(X)] = X
            ys[o:o + len(Y)] = Y
        xs[nw.vrm], ys[nw.vrm] = nw.vrm_xy
        for g in np.unique(grp):
            sel = grp == g
            if loss[sel].sum() <= 0:
                continue
            if g in LINK_LAYER:
                layer = LINK_LAYER[g]
            else:
                layer = STAGE_LAYER.get(g, "beol")
            if layer not in names:
                layer = "board" if g in ("pcb", "vrm_connection") else ("beol" if "beol" in names else names[-1])
            xm = 0.5 * (xs[i[sel]] + xs[j[sel]])
            ym = 0.5 * (ys[i[sel]] + ys[j[sel]])
            if g == "vrm_connection":
                xm, ym = xs[i[sel]], ys[i[sel]]
            L = model.layer(layer)
            rects = [r_ for r_, _ in L.regions]
            if L.background is not None or not rects:
                rr = model.domain
            else:
                rr = Rect(min(r_.x0 for r_ in rects), min(r_.y0 for r_ in rects), max(r_.x1 for r_ in rects), max(r_.y1 for r_ in rects))
            st_rect = None
            for st in nw.stages:
                if st.name == g:
                    st_rect = st.rect
            out.append(_points_to_source(f"pdn_loss:{net}:{g}", layer, xm, ym, loss[sel], st_rect or rr))
    return out


def electrothermal(cfg: dict, workload: Optional[str] = None, level: int = 0, max_iter: int = 10, tol: float = 1e-5,
                   leak_what_if: Optional[dict] = None, materials=None, pm=None) -> dict:
    """Fixed-point coupling: temperature -> metal resistance (TCR) -> PDN currents/losses -> heat -> temperature.
    Loads are constant-current (power scales with the local supply).  Leakage-vs-temperature is NOT modelled
    unless an explicit what-if {"p0_w", "k_per_k"} is supplied (no calibrated device data exist)."""
    materials = materials or load_materials()
    r0 = run_thermal(cfg, workload, level, keep=True, materials=materials, pm=pm)
    fixed = r0["surface_dT_used"]
    model, solver, T = r0["_model"], r0["_solver"], r0["_T"]
    base_sources = list(model.sources)
    P_nom = sum(s.power for s in base_sources if not s.label.startswith("io_ring"))
    hist = []
    Tj_prev = r0["tj_c"]
    runaway = False
    sol = None
    for it in range(1, max_iter + 1):
        samplers = {}

        def T_of(stage, X, Y, _s=samplers, _solver=solver, _T=T):
            layer = STAGE_LAYER.get(stage, "beol")
            if stage not in STAGE_LAYER and stage != "die":
                layer = "beol"
            if layer not in _solver.mesh.layer_k:
                layer = "board" if "board" in _solver.mesh.layer_k else _solver.mesh.layer_names[0]
            if layer not in _s:
                _s[layer] = _layer_sampler(_solver, _T, layer)
            return _s[layer](X, Y)
        sol = solve_pdn(cfg, model, T_of=T_of)
        scale = sol["p_load_w"] / max(P_nom, 1e-30)
        new_sources = []
        for s in base_sources:
            s2 = copy.copy(s)
            if not s.label.startswith("io_ring"):
                s2.power = s.power * scale
                if s.grid_p is not None:
                    s2.grid_p = s.grid_p * scale
            new_sources.append(s2)
        new_sources += pdn_loss_sources(sol, model)
        P_leak = 0.0
        if leak_what_if:
            dTj = Tj_prev - model.ambient_c
            P_leak = leak_what_if["p0_w"] * math.exp(leak_what_if["k_per_k"] * dTj)
            d = model.dies[0].rect
            new_sources.append(HeatSource("leakage_what_if", "Leakage(what-if)", P_leak, rect=d, prov="hypothetical"))
        q, rep = solver.source_vector(new_sources)
        Tn = solver.solve(q, x0=T)
        src_cells = np.concatenate([solver.layer_cells(L.name) for L in model.layers if L.source])
        Tj = float(Tn[src_cells].max())
        bh = solver.boundary_heat(Tn, q)
        hist.append({"iteration": it, "tj_c": Tj, "p_load_w": sol["p_load_w"], "p_loss_w": sol["p_loss_w"], "p_leak_w": P_leak,
                     "heat_in_w": float(q.sum()), "energy_residual_rel": bh["energy_residual_rel"], "worst_drop_mv": sol["worst_drop_mv"]})
        if Tj > 400 or (len(hist) >= 3 and hist[-1]["tj_c"] - hist[-2]["tj_c"] >= 0.98 * (hist[-2]["tj_c"] - hist[-3]["tj_c"]) > 1.0):
            runaway = True
            break
        T = Tn
        if abs(Tj - Tj_prev) < tol:
            Tj_prev = Tj
            break
        Tj_prev = Tj
    io_p = sum(s.power for s in base_sources if s.label.startswith("io_ring"))
    out = {"tj_uncoupled_c": r0["tj_c"], "tj_coupled_c": Tj_prev, "delta_tj_k": Tj_prev - r0["tj_c"], "iterations": hist,
           "converged": (not runaway) and len(hist) < max_iter, "thermal_runaway_detected": runaway,
           "p_supply_w": sol["p_supply_w"], "p_load_w": sol["p_load_w"], "p_pdn_loss_w": sol["p_loss_w"],
           "heat_balance_check_rel": abs(hist[-1]["heat_in_w"] - (sol["p_supply_w"] + io_p + hist[-1]["p_leak_w"])) / max(hist[-1]["heat_in_w"], 1e-30),
           "worst_drop_mv_hot": sol["worst_drop_mv"], "leak_what_if": leak_what_if,
           "note": "constant-current loads; metal TCR applied to die grid, bumps, planes; no leakage-vs-T calibration"}
    return out


def export_powergrid(pdn_sol: dict, out_dir: Path, stage: str = "die", net: str = "VDD") -> dict:
    """Write the on-die grid in the PowerGrid/ThermalLab exchange schema (nodes.csv, resistors.csv)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    nw = pdn_sol["_pdn"]["nets"][net]
    r = pdn_sol["_res"][net]
    st = nw.stage(stage)
    o = nw.offset[stage]
    X, Y = nw.node_xy(stage)
    v = r["v"]
    cur = pdn_sol["_pdn"]["loads"].get(stage, np.zeros(len(X)))
    rows = [{"node": f"{stage}_{k}", "x_um": X[k] / UM, "y_um": Y[k] / UM, "load_current_a": float(cur[k]), "voltage_v": float(v[o + k])}
            for k in range(len(X))]
    write_csv(out_dir / "nodes.csv", rows, ["node", "x_um", "y_um", "load_current_a", "voltage_v"], precise=True)
    i, j = r["branch_ij"]
    g = r["branch_g"]
    sel = (r["branch_groups"] == stage)
    rr = [{"n1": f"{stage}_{a - o}", "n2": f"{stage}_{b - o}", "r_ohm": 1.0 / gg, "layer": "TopMetal1/Metal5/Metal1 (homogenised)",
           "dissipation_w": gg * (v[a] - v[b]) ** 2} for a, b, gg in zip(i[sel], j[sel], g[sel])]
    write_csv(out_dir / "resistors.csv", rr, ["n1", "n2", "r_ohm", "layer", "dissipation_w"], precise=True)
    return {"nodes": len(rows), "resistors": len(rr), "dir": str(out_dir)}


def import_powergrid(in_dir: Path) -> dict:
    """Read a PowerGrid export (nodes.csv / resistors.csv); validates schema and conservation of the export."""
    d = Path(in_dir)
    with open(d / "nodes.csv") as f:
        nodes = list(csv.DictReader(f))
    with open(d / "resistors.csv") as f:
        res = list(csv.DictReader(f))
    need_n = {"node", "x_um", "y_um", "load_current_a", "voltage_v"}
    need_r = {"n1", "n2", "r_ohm", "layer"}
    if not nodes or not need_n <= set(nodes[0]):
        raise TwinError(f"nodes.csv must contain {sorted(need_n)}")
    if not res or not need_r <= set(res[0]):
        raise TwinError(f"resistors.csv must contain {sorted(need_r)}")
    V = {n["node"]: float(n["voltage_v"]) for n in nodes}
    diss = sum((V[r["n1"]] - V[r["n2"]]) ** 2 / float(r["r_ohm"]) for r in res)
    if any(float(r["r_ohm"]) <= 0 for r in res):
        raise TwinError("non-positive resistance in PowerGrid export")
    return {"nodes": len(nodes), "resistors": len(res), "total_load_a": sum(float(n["load_current_a"]) for n in nodes),
            "min_voltage_v": min(V.values()), "max_voltage_v": max(V.values()), "grid_dissipation_w": diss}


def d2d_study(cfg: dict) -> dict:
    """Die-to-die connection counts from shared edge length, bump pitch/rows and RDL wiring capacity.
    Raw signalling capacity only - not a link-bandwidth or protocol-compliance claim."""
    md = cfg["multi_die"]
    rects = {d["name"]: Rect.centered(d["x_mm"] * MM, d["y_mm"] * MM, pv(d["w_mm"]) * MM, pv(d["h_mm"]) * MM) for d in md["dies"]}
    pitch = pv(md["ubump_pitch_um"]) * UM if md["interposer"] else pv(cfg["bumps"]["pitch_um"]) * UM
    rows = int(pv(md["d2d_rows"]))
    if md["interposer"]:
        ls = (pv(md["rdl_line_um"]) + pv(md["rdl_space_um"])) * UM
        nlay = int(pv(md["rdl_layers"]))
        medium = "silicon interposer RDL (hypothetical)"
    else:
        ls = (pv(cfg["substrate"]["line_um"]) + pv(cfg["substrate"]["space_um"])) * UM
        nlay = max(int(pv(cfg["substrate"]["metal_layers"])) // 2 - 1, 1)
        medium = "organic build-up substrate"
    out = []
    names = list(rects)
    for a_i, a in enumerate(names):
        for b in names[a_i + 1:]:
            A, B = rects[a], rects[b]
            gx = max(B.x0 - A.x1, A.x0 - B.x1)
            gy = max(B.y0 - A.y1, A.y0 - B.y1)
            if gx > 1.5 * MM and gy > 1.5 * MM:
                continue
            if gx <= 1.5 * MM and gx >= 0 and gy < 0:
                L = min(A.y1, B.y1) - max(A.y0, B.y0)
                gap = gx
            elif gy <= 1.5 * MM and gy >= 0 and gx < 0:
                L = min(A.x1, B.x1) - max(A.x0, B.x0)
                gap = gy
            else:
                continue
            bump_lim = int(L / pitch) * rows
            wire_lim = int(L / ls) * nlay
            n = min(bump_lim, wire_lim)
            out.append({"die_a": a, "die_b": b, "shared_edge_mm": L / MM, "gap_mm": gap / MM, "bump_limited": bump_lim,
                        "wiring_limited": wire_lim, "connections": n, "limited_by": "bumps" if bump_lim <= wire_lim else "wiring",
                        "raw_capacity_gbps_hypothetical": n * pv(md["d2d_gbps_per_wire"]),
                        "beachfront_depth_um": rows * pitch / UM})
    return {"medium": medium, "pitch_um": pitch / UM, "rows": rows, "pairs": out,
            "caveat": "UCIe / HBM are integration targets requiring licensed compliant PHY+controller IP, a qualified interposer/substrate channel and physical validation; counts here are geometric capacity only."}


def thermal_coupling(cfg: dict, level: int = 0, tj_limit: Optional[float] = None, materials=None) -> dict:
    """Thermal influence matrix R[i][j] = rise of die j's peak per W in die i (fixed convection coefficients),
    exact field superposition check, and LP power allocation under a junction limit."""
    from scipy.optimize import linprog
    materials = materials or load_materials()
    r_nom = run_thermal(cfg, level=level, keep=True, materials=materials)
    dT = r_nom["surface_dT_used"]
    Ta = r_nom["ambient_c"]
    dies = [d for d in r_nom["dies"]]
    n = len(dies)
    R = np.zeros((n, n))
    Tsum = np.zeros_like(r_nom["_T"])
    Pn = np.array([r_nom["dies"][d]["power_w"] for d in dies])
    for i, d in enumerate(dies):
        c = copy.deepcopy(cfg)
        c["_die_scale"] = {x: (1.0 if x == d else 0.0) for x in dies}
        if c["multi_die"].get("hbm"):
            for h in c["multi_die"]["hbm_sites"]:
                c["_die_scale"].setdefault(h["name"], 0.0)
        r = run_thermal(c, level=level, fixed_dT=dT, keep=True, materials=materials)
        Tsum += r["_T"] - Ta
        for j, e in enumerate(dies):
            R[i, j] = (r["dies"][e]["tj_c"] - Ta) / max(Pn[i], 1e-30)
    # the nominal run iterated h; superposition must be checked at identical (fixed) coefficients
    r_fix = run_thermal(cfg, level=level, fixed_dT=dT, keep=True, materials=materials)
    sup_err = float(np.max(np.abs((r_fix["_T"] - Ta) - Tsum)))
    pred = Ta + Pn @ R
    out = {"dies": dies, "R_k_per_w": R.tolist(), "nominal_power_w": Pn.tolist(),
           "tj_nominal_c": [r_fix["dies"][d]["tj_c"] for d in dies], "tj_matrix_bound_c": pred.tolist(),
           "field_superposition_max_err_k": sup_err,
           "self_heating_k_w": np.diag(R).tolist(),
           "note": "matrix uses each die's peak; the sum of peaks is an upper bound of the true peak (located at different points)"}
    if tj_limit is not None:
        lim = tj_limit - Ta
        res = linprog(-np.ones(n), A_ub=R.T, b_ub=np.full(n, lim), bounds=[(0, None)] * n, method="highs")
        s_uniform = lim / max((Pn @ R).max(), 1e-30)
        comp = [k for k, d in enumerate(dies) if "COMPUTE" in d]
        A_eq = []
        if len(comp) == 2:
            row = np.zeros(n); row[comp[0]] = 1; row[comp[1]] = -1
            A_eq = [row]
        res2 = linprog(-np.ones(n), A_ub=R.T, b_ub=np.full(n, lim), A_eq=np.array(A_eq) if A_eq else None,
                       b_eq=np.zeros(len(A_eq)) if A_eq else None,
                       bounds=[(0.2 * Pn[k], None) for k in range(n)], method="highs")
        out["allocation"] = {"tj_limit_c": tj_limit, "uniform_scale": s_uniform, "uniform_total_w": float(Pn.sum() * s_uniform),
                             "lp_unconstrained_w": res.x.tolist() if res.success else None,
                             "lp_unconstrained_total_w": float(res.x.sum()) if res.success else None,
                             "lp_balanced_w": res2.x.tolist() if res2.success else None,
                             "lp_balanced_total_w": float(res2.x.sum()) if res2.success else None,
                             "constraints": "sum_i R[i,j] P_i <= Tj_limit - Ta for every die j; balanced: equal compute dies, every die >= 20 % of nominal"}
    return out


# =============================================================================
# 16. Numerical verification suite
# =============================================================================
def _simple_model(layers: List[Layer], mats: Dict[str, Material], bcs: List[BCRule], dom: Rect, ifs=None, fine=None) -> PackageModel:
    return PackageModel("verification", "V", layers, mats, ifs or [], bcs, dom, fine or [], fine or [])


def _vmats() -> Dict[str, Material]:
    db = load_materials()
    return {"si": db["silicon"], "cu": db["copper"], "tim": db["tim1_polymer"], "lam": Material("lam", 30, 30, 1.0, 1900, 1000, "assumed"),
            "uf": db["underfill"], "aniso": Material("aniso", 40.0, 15.0, 2.0, 2000, 900, "assumed")}


def _result(name, passed, metric, tol, **details):
    return {"test": name, "passed": bool(passed), "metric": float(metric) if metric is not None else None, "tolerance": tol, **details}


def v_slab_flux() -> dict:
    mats = _vmats()
    L, q = 400 * UM, 2e5
    dom = Rect(0, 0, 1 * MM, 1 * MM)
    m = _simple_model([Layer("si", "x", L, 20, "si")], mats,
                      [BCRule("top", "flux", "top", q=q), BCRule("bot", "dirichlet", "bottom", T=25.0)], dom)
    s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.25 * MM, h_max=0.25 * MM)))
    T = s.solve(np.zeros(s.N))
    exact_top = 25 + ref_slab_flux(L, mats["si"].kz, q)
    Ttop = s.surface_mean_temperature(T, "top")
    zc = s.mesh.zc[np.nonzero(s.mesh.active)[0]]
    err_cells = float(np.max(np.abs(T - (25 + q * zc / mats["si"].kz))))
    err = max(abs(Ttop - exact_top), err_cells) / (exact_top - 25)
    return _result("1D slab, flux / fixed T (dT = qL/k)", err < 1e-9, err, 1e-9, T_top_c=Ttop, exact_c=exact_top)


def v_composite_contact() -> dict:
    mats = _vmats()
    dom = Rect(0, 0, 2 * MM, 2 * MM)
    lay = [Layer("cu", "x", 1 * MM, 4, "cu"), Layer("tim", "x", 50 * UM, 2, "tim"), Layer("si", "x", 300 * UM, 5, "si")]
    ifs = [InterfaceRule("cu/tim", "cu", "tim", 5e-6), InterfaceRule("tim/si", "tim", "si", 3e-6)]
    q, h = 1e5, 2500.0
    m = _simple_model(lay, mats, [BCRule("top", "flux", "top", q=q), BCRule("bot", "convection", "bottom", h=h, T=25.0)], dom, ifs)
    s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.5 * MM, h_max=0.5 * MM)))
    T = s.solve(np.zeros(s.N))
    R = ref_series_stack([(1 * MM, mats["cu"].kz), (50 * UM, mats["tim"].kz), (300 * UM, mats["si"].kz)], [5e-6, 3e-6], h)
    Ttop = s.surface_mean_temperature(T, "top")
    err = abs(Ttop - 25 - q * R) / (q * R)
    return _result("multilayer slab with contact resistances and convection (series network)", err < 1e-9, err, 1e-9,
                   T_top_c=Ttop, exact_c=25 + q * R)


def v_volumetric_order() -> dict:
    """Uniform generation in a slab with both faces fixed: parabola; observed order of the max error."""
    mats = _vmats()
    L, g = 1 * MM, 1e9
    errs, hs = [], []
    for n in (8, 16, 32):
        dom = Rect(0, 0, 0.5 * MM, 0.5 * MM)
        m = _simple_model([Layer("si", "x", L, n, "si")], mats, [BCRule("d", "dirichlet", "top", T=0.0), BCRule("d2", "dirichlet", "bottom", T=0.0)], dom)
        s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.5 * MM, h_max=0.5 * MM)))
        T = s.solve(g * s.V)
        zc = s.mesh.zc[np.nonzero(s.mesh.active)[0]]
        ex = g * zc * (L - zc) / (2 * mats["si"].kz)
        errs.append(float(np.max(np.abs(T - ex)) / ex.max()))
        hs.append(L / n)
    p = math.log(errs[1] / errs[2]) / math.log(2)
    return _result("1D volumetric generation: observed order (max-norm)", p > 1.8, p, ">1.8", errors=errs)


def v_mms_3d() -> dict:
    """Manufactured 3-D solution, orthotropic k, zero Dirichlet on all faces; observed order (L2 and max)."""
    mats = _vmats()
    k = mats["aniso"]
    Lx, Ly, Lz = 2 * MM, 1.5 * MM, 0.5 * MM
    res = []
    for n in (8, 16, 32):
        dom = Rect(0, 0, Lx, Ly)
        m = _simple_model([Layer("a", "x", Lz, n, "aniso")], {"aniso": k}, [BCRule("d", "dirichlet", "any", T=0.0)], dom)
        mesh = Mesh(m, MeshSpec(h_fine=Lx / n, h_max=Lx / n))
        mesh.xe = np.linspace(0, Lx, n + 1); mesh.ye = np.linspace(0, Ly, n + 1)
        mesh.nx = mesh.ny = n
        mesh.dx, mesh.dy = np.diff(mesh.xe), np.diff(mesh.ye)
        mesh.xc, mesh.yc = 0.5 * (mesh.xe[1:] + mesh.xe[:-1]), 0.5 * (mesh.ye[1:] + mesh.ye[:-1])
        mesh.mat = np.zeros((mesh.nz, n, n), np.int32)
        mesh.active = mesh.mat >= 0
        mesh.n_active = int(mesh.active.sum())
        s = ThermalSolver(m, mesh)
        kk, jj, ii = np.nonzero(mesh.active)
        X, Y, Z = mesh.xc[ii], mesh.yc[jj], mesh.zc[kk]
        Te = np.sin(np.pi * X / Lx) * np.sin(np.pi * Y / Ly) * np.sin(np.pi * Z / Lz)
        qd = (k.kx * (np.pi / Lx) ** 2 + k.ky * (np.pi / Ly) ** 2 + k.kz * (np.pi / Lz) ** 2) * Te
        T = s.solve(qd * s.V)
        e = T - Te
        res.append((float(np.sqrt(np.sum(e ** 2 * s.V) / np.sum(s.V))), float(np.max(np.abs(e)))))
    pl2 = math.log(res[1][0] / res[2][0]) / math.log(2)
    pmx = math.log(res[1][1] / res[2][1]) / math.log(2)
    return _result("3-D manufactured solution, orthotropic k: observed order", min(pl2, pmx) > 1.8, min(pl2, pmx), ">1.8",
                   order_l2=pl2, order_max=pmx, errors=res)


def v_fourier_spreading(levels=(0, 1, 2)) -> dict:
    """Multilayer orthotropic flux channel with two eccentric sources and contact resistance vs exact Fourier series."""
    mats = _vmats()
    a, b = 8 * MM, 6 * MM
    # top -> bottom: die (Si), TIM, laminate-like orthotropic spreader
    layers_tb = [(300 * UM, mats["si"].kx, mats["si"].kz), (60 * UM, mats["tim"].kx, mats["tim"].kz), (1.2 * MM, 30.0, 1.0)]
    contacts = [4e-6, 2e-6, 0.0]
    h = 3000.0
    srcs = [(Rect(1.0 * MM, 1.5 * MM, 3.0 * MM, 3.5 * MM), 1.5), (Rect(5.0 * MM, 3.0 * MM, 6.0 * MM, 5.0 * MM), 0.8)]
    evals = [r for r, _ in srcs]
    ref = ref_fourier_spreading(a, b, layers_tb, h, srcs, evals, contacts, M=300, N=300)
    out = []
    for lv in levels:
        r = 1.6 ** lv
        lay = [Layer("lam", "x", 1.2 * MM, int(round(4 * r)), "lam"), Layer("tim", "x", 60 * UM, int(round(2 * r)), "tim"),
               Layer("si", "x", 300 * UM, int(round(5 * r)), "si")]
        ifs = [InterfaceRule("tim/si", "tim", "si", contacts[0]), InterfaceRule("lam/tim", "lam", "tim", contacts[1])]
        bcs = [BCRule(f"src{i}", "flux", "top", region=rr, q=pw / rr.area) for i, (rr, pw) in enumerate(srcs)] + \
              [BCRule("bot", "convection", "bottom", h=h, T=0.0)]
        m = _simple_model(lay, {"lam": mats["lam"], "tim": mats["tim"], "si": mats["si"]}, bcs, Rect(0, 0, a, b), ifs)
        hh = 0.25 * MM / r
        s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=hh, h_max=hh)))
        T = s.solve(np.zeros(s.N))
        fv = [s.surface_mean_temperature(T, f"src{i}") for i in range(len(srcs))]
        out.append({"level": lv, "cells": s.N, "fv_mean_rise": fv, "rel_err": [abs(f - e) / e for f, e in zip(fv, ref)],
                    "energy_residual_rel": s.boundary_heat(T, np.zeros(s.N))["energy_residual_rel"]})
    err = max(out[-1]["rel_err"])
    e0, e1 = max(out[-2]["rel_err"]), err
    return _result("multilayer orthotropic spreading vs exact Fourier series (2 eccentric sources)", err < 2e-3 and e1 < e0, err, 2e-3,
                   reference_mean_rise_k=ref, levels=out)


def v_energy_random(seed: int = 7) -> dict:
    rng = np.random.default_rng(seed)
    mats = _vmats()
    worst = 0.0
    for trial in range(4):
        dom = Rect(0, 0, 3 * MM, 2 * MM)
        names = list(mats)
        lay = []
        for li in range(4):
            reg = [(Rect(*sorted(rng.uniform(0, 3 * MM, 2)), *sorted(rng.uniform(0, 2 * MM, 2))) if False else
                    Rect(rng.uniform(0, 1) * MM, rng.uniform(0, 0.8) * MM, rng.uniform(1.5, 3) * MM, rng.uniform(1.2, 2) * MM),
                    names[rng.integers(len(names))])]
            lay.append(Layer(f"L{li}", "x", rng.uniform(50, 500) * UM, int(rng.integers(1, 4)), names[rng.integers(len(names))], reg))
        lay[1].source = True
        ifs = [InterfaceRule("c", "L0", "L1", rng.uniform(0, 1e-5))]
        bcs = [BCRule("top", "convection", "top", h=rng.uniform(50, 5000), T=20.0), BCRule("bot", "convection", "bottom", h=rng.uniform(5, 500), T=30.0),
               BCRule("side", "convection", "side", h=rng.uniform(1, 50), T=25.0)]
        m = _simple_model(lay, mats, bcs, dom, ifs)
        s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.2 * MM, h_max=0.2 * MM)))
        q = rng.uniform(0, 1, s.N) * (np.isin(np.arange(s.N), s.layer_cells("L1")))
        q *= 2.0 / q.sum()
        T = s.solve(q)
        worst = max(worst, s.boundary_heat(T, q)["energy_residual_rel"])
    return _result("energy conservation on random multi-material models", worst < 1e-10, worst, 1e-10)


def v_lumped_rc() -> dict:
    """Temporal accuracy: a single-cell model is exactly the ODE C dT/dt = P - G T, so the theta scheme can be
    compared with the exact exponential (IE order 1, CN order 2).  A refined Cu block (Bi ~ 1e-4) is then
    compared with the lumped-capacitance solution."""
    mats = _vmats()
    L, h, Pw = 10 * MM, 10.0, 0.5
    m = _simple_model([Layer("cu", "x", L, 1, "cu", source=True)], {"cu": mats["cu"]}, [BCRule("all", "convection", "any", h=h, T=0.0)], Rect(0, 0, L, L))
    m.ambient_c = 0.0
    s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=L, h_max=L)))
    q = np.full(s.N, Pw / s.N)
    G, C = float(s.Gb.sum()), float(s.C.sum())
    tau = C / G
    t_end = 0.5 * tau
    out = {}
    for name, th in (("implicit_euler", 1.0), ("crank_nicolson", 0.5)):
        errs = []
        for nst in (10, 20, 40, 80):
            r = s.transient([(0.0, q)], t_end, t_end / nst, theta=th, T0=np.zeros(s.N), record={"mean": np.arange(s.N)})
            errs.append(abs(r["mean"][-1] - ref_lumped_rc(Pw, G, C, t_end)))
        out[name] = {"errors_k": errs, "order": math.log(errs[-2] / errs[-1]) / math.log(2), "energy_residual": r["energy_residual_max"]}
    m2 = _simple_model([Layer("cu", "x", L, 6, "cu", source=True)], {"cu": mats["cu"]}, [BCRule("all", "convection", "any", h=h, T=0.0)], Rect(0, 0, L, L))
    m2.ambient_c = 0.0
    s2 = ThermalSolver(m2, Mesh(m2, MeshSpec(h_fine=L / 6, h_max=L / 6)))
    q2 = np.full(s2.N, Pw / s2.N)
    r2 = s2.transient([(0.0, q2)], t_end, t_end / 200, theta=0.5, T0=np.zeros(s2.N), record={"mean": np.arange(s2.N)})
    hA = h * 6 * L * L
    lumped = abs(r2["mean"][-1] - ref_lumped_rc(Pw, hA, float(s2.C.sum()), t_end)) / ref_lumped_rc(Pw, hA, float(s2.C.sum()), t_end)
    ok = 0.95 < out["implicit_euler"]["order"] < 1.05 and 1.95 < out["crank_nicolson"]["order"] < 2.05 and lumped < 1e-3
    return _result("transient: temporal order (IE ~1, CN ~2) and lumped-capacitance limit", ok, out["crank_nicolson"]["order"],
                   "IE 0.95-1.05, CN 1.95-2.05, lumped rel < 1e-3", tau_s=tau, lumped_rel_err=lumped, biot=h * L / 6 / mats["cu"].kx, **out)


def v_steady_transient() -> dict:
    """Transient to t >> tau equals the steady solution; transient discrete energy balance per step."""
    mats = _vmats()
    dom = Rect(0, 0, 6 * MM, 6 * MM)
    die = Rect(2 * MM, 2 * MM, 4 * MM, 4 * MM)
    lay = [Layer("lam", "x", 0.8 * MM, 2, "lam"), Layer("si", "x", 300 * UM, 3, None, [(die, "si")], source=True),
           Layer("tim", "x", 50 * UM, 1, None, [(die, "tim")]), Layer("cu", "x", 1 * MM, 2, "cu")]
    bcs = [BCRule("top", "convection", "top", h=800.0, T=25.0), BCRule("bot", "convection", "bottom", h=20.0, T=25.0)]
    m = _simple_model(lay, mats, bcs, dom, [InterfaceRule("si/tim", "si", "tim", 5e-6)], [(die.x0, die.x1)])
    s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.25 * MM, growth=0.3, h_max=1 * MM)))
    q = np.zeros(s.N)
    c = s.layer_cells("si")
    q[c] = 1.0 / len(c)
    Ts = s.solve(q)
    tau = float(s.C.sum()) / (800.0 * dom.area)
    r = s.transient([(0.0, q)], 40 * tau, 0.5 * tau, theta=1.0)
    err = float(np.max(np.abs(r["T_final"] - Ts)))
    return _result("steady / transient consistency (t = 40 tau, implicit Euler)", err < 1e-6 and r["energy_residual_max"] < 1e-9, err, 1e-6,
                   transient_energy_residual=r["energy_residual_max"], tau_s=tau)


def v_kT() -> dict:
    mats = _vmats()
    si = mats["si"]
    L, q = 500 * UM, 2e6
    m = _simple_model([Layer("si", "x", L, 40, "si")], {"si": si}, [BCRule("top", "flux", "top", q=q), BCRule("bot", "dirichlet", "bottom", T=25.0)], Rect(0, 0, 0.5 * MM, 0.5 * MM))
    s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.5 * MM, h_max=0.5 * MM)))
    T, info = s.solve_nonlinear(np.zeros(s.N), tol=1e-10)
    A, Gb, bbc = s._nl_state
    s.A, s.Gb, s.bbc = A, Gb, bbc
    exact = ref_kirchhoff_slab(L, q, si.kx, si.k_temp_exponent, 25.0)
    zc = s.mesh.zc
    # face temperature from the hottest cell with the local k
    top = float(T.max())
    Tf = top + q * (s.mesh.dz[-1] / 2) / (si.kx * ((top + T_ABS) / 300) ** (-si.k_temp_exponent))
    err = abs(Tf - exact) / (exact - 25)
    return _result("k(T) slab (Picard) vs Kirchhoff-transform solution", err < 2e-3 and info["converged"], err, 2e-3,
                   picard_iterations=info["iterations"], exact_c=exact, fv_c=Tf)


def v_boundary_handling() -> dict:
    mats = _vmats()
    dom = Rect(0, 0, 4 * MM, 4 * MM)
    die = Rect(1 * MM, 1 * MM, 3 * MM, 3 * MM)
    lay = [Layer("lam", "x", 0.6 * MM, 2, "lam"), Layer("si", "x", 0.3 * MM, 3, None, [(die, "si")], source=True), Layer("cu", "x", 1 * MM, 2, "cu")]
    def solve_with(top):
        m = _simple_model(lay, mats, [top, BCRule("bot", "convection", "bottom", h=10.0, T=25.0)], dom, fine=[(1 * MM, 3 * MM)])
        s = ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.25 * MM, h_max=0.5 * MM)))
        q = np.zeros(s.N)
        c = s.layer_cells("si")
        q[c] = 1.0 / len(c)
        return s, s.solve(q), q
    sD, TD, _ = solve_with(BCRule("top", "dirichlet", "top", T=25.0))
    sR, TR, _ = solve_with(BCRule("top", "convection", "top", h=1e10, T=25.0))
    robin_lim = float(np.max(np.abs(TD - TR)))
    s, T, q = solve_with(BCRule("top", "convection", "top", h=500.0, T=25.0))
    T3 = s.T3(T)
    sym = float(np.nanmax(np.abs(T3 - T3[:, :, ::-1]))) if np.allclose(s.mesh.xe + s.mesh.xe[::-1], s.mesh.xe[0] + s.mesh.xe[-1]) else float("nan")
    bh = s.boundary_heat(T, q)
    side = bh["flows_w"].get("side", 0.0)
    rejected = []
    bad = [
        ("no heat sink (all adiabatic)", lambda: ThermalSolver(_simple_model(lay, mats, [BCRule("a", "adiabatic", "any")], dom), None)),
        ("negative h", lambda: _check_raises(_simple_model(lay, mats, [BCRule("t", "convection", "top", h=-5)], dom))),
        ("negative contact R", lambda: _check_raises(_simple_model(lay, mats, [BCRule("t", "convection", "top", h=5)], dom, [InterfaceRule("x", "lam", "si", -1e-6)]))),
    ]
    for name, fn in bad:
        try:
            fn()
            rejected.append((name, False))
        except (TwinError, AttributeError, TypeError):
            rejected.append((name, True))
    # floating island: die separated from everything by a void layer
    lay2 = [Layer("lam", "x", 0.6 * MM, 2, "lam"), Layer("gap", "x", 0.1 * MM, 1, None, [(Rect(0, 0, 0.5 * MM, 0.5 * MM), "lam")]),
            Layer("si", "x", 0.3 * MM, 2, None, [(die, "si")])]
    try:
        m = _simple_model(lay2, mats, [BCRule("bot", "convection", "bottom", ["lam"], h=10.0, T=25.0)], dom)
        ThermalSolver(m, Mesh(m, MeshSpec(h_fine=0.5 * MM, h_max=0.5 * MM)))
        rejected.append(("floating island", False))
    except TwinError:
        rejected.append(("floating island", True))
    ok = robin_lim < 1e-4 and (not np.isfinite(sym) or sym < 1e-9) and all(r for _, r in rejected)
    return _result("boundary-condition handling (Robin->Dirichlet limit, symmetry, rejection of ill-posed models)", ok, robin_lim, 1e-4,
                   symmetry_max_k=sym, unmatched_side_heat_w=side, rejected=[{"case": n, "rejected": r} for n, r in rejected])


def _check_raises(model: PackageModel):
    errs = [i for i in validate_model(model) if i.severity == "ERROR"]
    if errs:
        raise TwinError(errs[0].message)
    return model


def v_material_and_config_flags() -> dict:
    flagged = []
    bad_mats = [Material("neg_k", -1, 1, 1, 1000, 500), Material("zero_rho", 1, 1, 1, 0, 500), Material("super", 5000, 5000, 5000, 3000, 500),
                Material("nan", float("nan"), 1, 1, 1000, 500)]
    for m in bad_mats:
        flagged.append((m.name, any(i.severity == "ERROR" for i in validate_material(m))))
    cfg = default_config_A()
    cfg["bumps"]["diameter_um"] = P(250.0, "assumed")
    try:
        m = build_model(cfg, workload=None)
        flagged.append(("bump diameter >= pitch", any(i.code == "BUMP_PITCH" for i in m.issues)))
    except TwinError:
        flagged.append(("bump diameter >= pitch", True))
    cfg = default_config_A()
    cfg["substrate"]["body_mm"] = P(3.0, "assumed")
    try:
        build_model(cfg)
        flagged.append(("die larger than package body", False))
    except TwinError:
        flagged.append(("die larger than package body", True))
    cfg = default_config_A()
    cfg["tim1"]["k_w_mk"] = P(-2.0, "assumed")
    m = build_model(cfg)
    flagged.append(("negative TIM conductivity", any(i.severity == "ERROR" for i in m.issues)))
    db = load_materials()
    db_ok = all(not [i for i in validate_material(x) if i.severity == "ERROR"] for x in db.values())
    ok = all(f for _, f in flagged) and db_ok
    return _result("positive material parameters / non-physical configurations flagged", ok, sum(f for _, f in flagged), len(flagged),
                   cases=[{"case": n, "flagged": f} for n, f in flagged], material_db_valid=db_ok)


def v_power_mapping() -> dict:
    pm = PowerModel()
    worst = 0.0
    n = 0
    for run in list_floorplans():
        fp = load_floorplan(run)
        for wl in ("mixed", "tensor", "max_simultaneous"):
            cfg = default_config_A("natural", floorplan=run)
            model = build_model(cfg, workload=wl)
            mesh = Mesh(model, MeshSpec(h_fine=150 * UM, growth=0.4, h_max=8 * MM))
            s = ThermalSolver.__new__(ThermalSolver)
            s.mesh, s.model = mesh, model
            s.idx = np.full(mesh.shape, -1, dtype=np.int64)
            s.idx[mesh.active] = np.arange(mesh.n_active)
            q, rep = ThermalSolver.source_vector(s)
            br = model.meta["power_breakdown"]
            worst = max(worst, rep["conservation_rel_err"], abs(q.sum() - br["total_power_w"]) / br["total_power_w"])
            n += 1
    # orientation: a source at the die-local left edge must land at the package right side (face-down mirror)
    d = DiePlacement("t", Rect(-1 * MM, -1 * MM, 1 * MM, 1 * MM), face_down=True)
    x, _ = d.to_pkg(0.0, 0.0)
    orient_ok = abs(x - 1 * MM) < 1e-15
    return _result("power-map conservation (all floorplans x 3 workloads) and face-down orientation", worst < 1e-12 and orient_ok, worst, 1e-12,
                   cases=n, face_down_mirror_ok=orient_ok)


def v_pdn_laws() -> dict:
    out = {}
    # 1-D strip with uniform node sinks fed from both ends: discrete solution = parabola at the nodes
    n, Rs, W, L, I_tot, V0 = 41, 0.05, 1 * MM, 10 * MM, 0.5, 1.0
    st = PDNStage("strip", Rect(0, 0, L, W), n, 1, Rs, Rs)
    left = PDNStage("feedL", Rect(-1 * MM, 0, 0, W), 1, 1, Rs, Rs)
    nw = PDNNetwork("VDD", [st, left], [PDNLink("strip", "feedL", np.array([L / n / 2, L - L / n / 2]), np.array([W / 2] * 2),
                                               np.array([-0.5 * MM] * 2), np.array([W / 2] * 2), np.array([1e-9, 1e-9]), "end", np.ones(2))],
                    (-0.5 * MM, W / 2), 0.1 * MM, V0, 1e-12)
    inj = np.zeros(nw.n - 1)
    inj[1:n - 1] = -I_tot / (n - 2)
    r = nw.solve(inj)
    v = r["v"][:n]
    h = L / n
    Rseg = Rs * h / W
    k = np.arange(n)
    ex = v[0] - (I_tot / (n - 2)) * Rseg * k * (n - 1 - k) / 2
    out["strip_max_err_v"] = float(np.max(np.abs(v - ex)))
    # N identical parallel connections between two ideal planes -> R/N
    a = PDNStage("a", Rect(0, 0, 1 * MM, 1 * MM), 1, 1, 1e-9, 1e-9)
    b = PDNStage("b", Rect(0, 0, 1 * MM, 1 * MM), 1, 1, 1e-9, 1e-9)
    N, R = 37, 0.011
    nw2 = PDNNetwork("VDD", [a, b], [PDNLink("a", "b", np.full(N, 0.5 * MM), np.full(N, 0.5 * MM), np.full(N, 0.5 * MM), np.full(N, 0.5 * MM),
                                             np.full(N, R), "bumps", np.ones(N))], (0.5 * MM, 0.5 * MM), 1 * MM, 1.0, 1e-15)
    inj = np.zeros(nw2.n - 1)
    inj[0] = -1.0
    r2 = nw2.solve(inj)
    out["parallel_err_ohm"] = float(abs((1.0 - r2["v"][0]) - R / N))
    # reciprocity on a random resistive grid: transfer resistance R_ab = R_ba
    g = PDNStage("g", Rect(0, 0, 3 * MM, 2 * MM), 9, 7, 0.07, 0.11)
    nw3 = PDNNetwork("VDD", [g], [], (0.1 * MM, 0.1 * MM), 0.2 * MM, 0.0, 1e-3)
    ia, ib = 20, 50
    def transfer(src, obs):
        inj = np.zeros(nw3.n - 1); inj[src] = 1.0
        return nw3.solve(inj)["v"][obs]
    out["reciprocity_err_v"] = float(abs(transfer(ia, ib) - transfer(ib, ia)))
    # package-level conservation for A, A0, B
    pk = {}
    for cfg in (default_config_A(), default_config_A0(), default_config_B()):
        m = build_model(cfg, workload=cfg["workload"])
        s = solve_pdn(cfg, m)
        pk[cfg["name"]] = {**s["conservation"], "load_a": s["load_current_a"]}
    out["package_conservation"] = pk
    worst_pkg = max(max(v["current_balance_rel"], v["power_balance_rel"]) for v in pk.values())
    worst_kcl = max(v["kcl_residual_a"] / max(v["load_a"], 1e-12) for v in pk.values())
    worst_tel = max(v["tellegen_w"] for v in pk.values())
    ok = out["strip_max_err_v"] < 1e-12 and out["parallel_err_ohm"] < 1e-12 and out["reciprocity_err_v"] < 1e-12 and worst_pkg < 1e-7 and worst_kcl < 1e-8
    return _result("PDN conservation laws (KCL, current/power balance, Tellegen, reciprocity, analytical strip, parallel bumps)", ok,
                   worst_pkg, 1e-7, kcl_rel=worst_kcl, tellegen_w=worst_tel, **out)


def v_touchstone() -> dict:
    import tempfile
    f = np.linspace(1e8, 2e10, 60)
    S = synthetic_line_sparams(0.01, f, R=0.0, G=0.0, z0=50.0)
    with tempfile.TemporaryDirectory() as d:
        pth = Path(d) / "line.s2p"
        write_touchstone(pth, f, S, 50.0, "SYNTHETIC lossless line - test fixture only")
        r = read_touchstone(pth)
    rt = float(np.max(np.abs(r["S"] - S)))
    chk = sparam_checks(r)
    Sl = synthetic_line_sparams(0.01, f, R=20.0, G=1e-4)
    lossy = sparam_checks({"S": Sl, "freq_hz": f, "ports": 2})
    unitary = float(np.max(np.abs(np.einsum("kji,kjl->kil", S.conj(), S) - np.eye(2))))
    ok = rt < 1e-8 and chk["passive"] and chk["reciprocal"] and lossy["passive"] and unitary < 1e-9
    return _result("Touchstone round trip, passivity and reciprocity checks (synthetic fixture)", ok, rt, 1e-8, lossless_unitarity_err=unitary,
                   compliance=chk["compliance"])


def _gci(rows: List[dict], key: str) -> dict:
    """Celik et al. (2008) procedure: observed order with unequal ratios, Richardson value, fine-grid GCI (Fs 1.25)."""
    f3, f2, f1 = rows[0][key], rows[1][key], rows[2][key]
    r21 = (rows[2]["cells"] / rows[1]["cells"]) ** (1 / 3)
    r32 = (rows[1]["cells"] / rows[0]["cells"]) ** (1 / 3)
    e21, e32 = f1 - f2, f2 - f3
    out = {"metric": key, "values": [f3, f2, f1], "ratios": [r32, r21]}
    if abs(e21) < 1e-14 * max(abs(f1), 1e-30):
        out.update({"monotone": True, "observed_order": None, "gci_fine_rel": 0.0, "note": "converged to round-off"})
        return out
    if e21 * e32 > 0:
        s_ = 1.0 if e32 / e21 > 0 else -1.0
        p = abs(math.log(abs(e32 / e21))) / math.log(r21)
        for _ in range(100):
            q = math.log(max((r21 ** p - s_) / (r32 ** p - s_), 1e-12))
            p_new = abs(math.log(abs(e32 / e21)) + q) / math.log(r21)
            if abs(p_new - p) < 1e-10:
                break
            p = p_new
        p_eff = max(p, 0.5)
        f_ext = f1 + e21 / (r21 ** p_eff - 1)
        gci = 1.25 * abs(e21 / f1) / (r21 ** p_eff - 1)
        out.update({"monotone": True, "observed_order": p, "order_used": p_eff, "richardson": f_ext, "gci_fine_rel": gci,
                    "note": "observed order < 0.5 is outside the asymptotic range; 0.5 used (conservative)" if p < 0.5 else ""})
    else:
        out.update({"monotone": False, "observed_order": None, "gci_fine_rel": 3.0 * abs(e21 / f1),
                    "note": "oscillatory convergence: 3x the last relative change reported (Roache, Fs = 3)"})
    out["level0_vs_finest_rel"] = abs(f3 - f1) / abs(f1)
    return out


def mesh_convergence(cfg: dict, levels=(0, 1, 2), workload: Optional[str] = None, materials=None) -> dict:
    """Grid convergence on the full package model (systematic refinement of the size field and every layer's
    nz by the ratio r).  Convection coefficients are frozen at the level-0 solution so only discretisation
    changes.  Metrics: power-weighted mean die temperature rise (smooth functional) and peak Tj rise."""
    r0 = run_thermal(cfg, workload, levels[0], materials=materials)
    dT = r0["surface_dT_used"]
    rows = []
    for lv in levels:
        r = run_thermal(cfg, workload, lv, fixed_dT=dT, materials=materials)
        rows.append({"level": lv, "cells": r["mesh"]["cells_active"], "tj_rise_k": r["tj_rise_k"],
                     "mean_rise_k": r["t_die_pw_mean_c"] - r["ambient_c"], "theta_ja_k_w": r["theta_ja_k_w"],
                     "energy_residual_rel": r["energy_residual_rel"], "wall_s": r["wall_s"]})
    return {"case": cfg["name"], "levels": rows, "mean_rise": _gci(rows, "mean_rise_k"), "peak_rise": _gci(rows, "tj_rise_k")}


def run_validation(out_dir: Path, quick: bool = False) -> dict:
    tests = [v_slab_flux, v_composite_contact, v_volumetric_order, v_mms_3d, v_fourier_spreading, v_energy_random, v_lumped_rc,
             v_steady_transient, v_kT, v_boundary_handling, v_material_and_config_flags, v_power_mapping, v_pdn_laws, v_touchstone]
    res = []
    for t in tests:
        t0 = time.time()
        try:
            r = t()
        except Exception as e:                        # a crashing verification is a failed verification
            r = _result(t.__name__, False, None, None, error=f"{type(e).__name__}: {e}")
        r["wall_s"] = time.time() - t0
        res.append(r)
        print(f"  [{'PASS' if r['passed'] else 'FAIL'}] {r['test']}  metric={r['metric']}", flush=True)
    conv = []
    if not quick:
        for cfg in (default_config_A(), default_config_B()):
            t0 = time.time()
            c = mesh_convergence(cfg)
            c["wall_s"] = time.time() - t0
            conv.append(c)
            print(f"  [conv] {cfg['name']}: mean-rise order={c['mean_rise'].get('observed_order')} GCI={c['mean_rise'].get('gci_fine_rel')}; "
                  f"peak GCI={c['peak_rise'].get('gci_fine_rel')}", flush=True)
    summary = {"passed": sum(r["passed"] for r in res), "total": len(res), "all_passed": all(r["passed"] for r in res)}
    out = {"summary": summary, "tests": res, "mesh_convergence": conv, "versions": env_versions()}
    jdump(out, Path(out_dir) / "validation" / "validation.json")
    return out


def env_versions() -> dict:
    import matplotlib
    d = {"packagetwin": __version__, "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
         "matplotlib": matplotlib.__version__, "platform": platform.platform()}
    try:
        import plotly
        d["plotly"] = plotly.__version__
    except ImportError:
        d["plotly"] = None
    return d


# =============================================================================
# 17. Studies: baselines, workloads, sensitivities, sweeps, Pareto, transients
# =============================================================================
COST_INDEX = {   # ASSUMED relative cost index (dimensionless) - for ranking trade-offs only, never a quote
    "cooling": {"natural": 0.0, "passive_heatsink": 2.0, "forced_air_heatsink": 5.0, "cold_plate": 30.0},
    "fan_per_m_s": 0.6, "heatsink_base_per_mm": 0.15, "tim1_per_w_mk": 0.25, "lid": 1.0,
    "substrate_per_cm2": 1.2, "substrate_per_extra_layer": 0.4, "interposer_per_cm2": 20.0, "cu_heatsink_factor": 2.5,
    "prov": "assumed", "note": "relative engineering cost index chosen for trade-off ranking; replace with OSAT/thermal-vendor quotations",
}


def cost_index(cfg: dict) -> float:
    c = COST_INDEX
    cool = cfg["cooling"]["type"]
    x = c["cooling"][cool]
    if cool == "forced_air_heatsink":
        x += c["fan_per_m_s"] * pv(cfg["cooling"]["velocity_m_s"])
    if cool in ("passive_heatsink", "forced_air_heatsink"):
        f = c["cu_heatsink_factor"] if cfg["cooling"]["heatsink"]["material"] == "copper" else 1.0
        x += c["heatsink_base_per_mm"] * pv(cfg["cooling"]["heatsink"]["base_mm"]) * f
    x += c["tim1_per_w_mk"] * pv(cfg["tim1"]["k_w_mk"])
    if cfg["lid"]["enabled"]:
        x += c["lid"]
    body = pv(cfg["substrate"]["body_mm"]) if "qfn" not in cfg else pv(cfg["qfn"]["body_mm"])
    x += c["substrate_per_cm2"] * (body / 10) ** 2
    x += c["substrate_per_extra_layer"] * max(int(pv(cfg["substrate"]["metal_layers"])) - 4, 0)
    if cfg.get("multi_die", {}).get("interposer"):
        ip = cfg["multi_die"]["interposer_mm"]
        x += c["interposer_per_cm2"] * pv(ip[0]) * pv(ip[1]) / 100
    return float(x)


def stack_height_mm(cfg: dict) -> float:
    """Board top to top of the cooling solution (fins included)."""
    if cfg["architecture"] == "wire_bond_qfn":
        h = pv(cfg["qfn"]["thickness_mm"]) + pv(cfg["qfn"]["solder_um"]) / 1000
    else:
        h = pv(cfg["bga"]["standoff_mm"]) + _substrate_thickness(cfg) / MM + pv(cfg["bumps"]["height_um"]) / 1000
        if cfg.get("multi_die", {}).get("interposer"):
            md = cfg["multi_die"]
            h += (pv(md["interposer_um"]) + pv(md["rdl_um"]) + pv(md["ubump_height_um"])) / 1000 + pv(md["die_thickness_um"]) / 1000
        else:
            h += pv(cfg["die"]["thickness_um"]) / 1000 if "multi_die" not in cfg else pv(cfg["multi_die"]["die_thickness_um"]) / 1000
        h += pv(cfg["die"]["beol_thickness_um"]) / 1000 + pv(cfg["tim1"]["thickness_um"]) / 1000
        if cfg["lid"]["enabled"]:
            h += pv(cfg["lid"]["thickness_mm"])
    t = cfg["cooling"]["type"]
    if t in ("passive_heatsink", "forced_air_heatsink"):
        hs = cfg["cooling"]["heatsink"]
        h += pv(cfg["tim2"]["thickness_um"]) / 1000 * (1 if cfg["lid"]["enabled"] else 0) + pv(hs["base_mm"]) + pv(hs["fin_height_mm"])
    elif t == "cold_plate":
        h += pv(cfg["cold_plate"]["base_mm"]) if "cold_plate" in cfg else pv(cfg["cooling"]["cold_plate"]["base_mm"]) + 6.0
    return float(h)


def _run_point(args) -> dict:
    """Worker: (label, cfg, workload, extra) -> compact result row.  Never raises: failures are recorded."""
    label, cfg, wl, extra = args
    try:
        r = run_thermal(cfg, wl)
        row = {"label": label, "case": cfg["name"], "workload": r["workload"], "power_w": r["power_w"], "tj_c": r["tj_c"],
               "tj_rise_k": r["tj_rise_k"], "theta_ja_k_w": r["theta_ja_k_w"], "t_die_mean_c": r["t_die_pw_mean_c"],
               "psi_jt_k_w": r.get("psi_jt_k_w"), "psi_jb_k_w": r.get("psi_jb_k_w"),
               "top_path_frac": r["heat_split"]["top_path"], "board_path_frac": r["heat_split"]["board_path"],
               "energy_residual_rel": r["energy_residual_rel"], "cells": r["mesh"]["cells_active"],
               "cost_index": cost_index(cfg), "stack_height_mm": stack_height_mm(cfg),
               "hottest_class": max(r["classes"].items(), key=lambda kv: kv[1]["t_max_c"])[0] if r["classes"] else None,
               "errors": [i["code"] for i in r["issues"] if i["severity"] == "ERROR"],
               "warnings": [i["code"] for i in r["issues"] if i["severity"] == "WARNING"], "status": "ok"}
        for k, v in (extra or {}).items():
            row[k] = v
        if "dies" in r and len(r["dies"]) > 1:
            for d, v in r["dies"].items():
                row[f"tj_{d}_c"] = v["tj_c"]
        return row
    except TwinError as e:
        return {"label": label, "case": cfg.get("name"), "status": "rejected", "reason": str(e), **(extra or {})}


def parallel_map(fn, items: List, workers: int = 4) -> List:
    if workers <= 1 or len(items) <= 1:
        return [fn(x) for x in items]
    import multiprocessing as mp
    try:
        ctx = mp.get_context("fork")
    except ValueError:
        return [fn(x) for x in items]
    with ctx.Pool(min(workers, len(items))) as pool:
        return pool.map(fn, items, chunksize=1)


def variant(cfg: dict, changes: Dict[str, Any], name_suffix: str = "") -> dict:
    c = copy.deepcopy(cfg)
    for k, v in changes.items():
        if k.startswith("_") or k in ("extra_materials", "numerical_experiment"):
            c[k] = v
        else:
            set_path(c, k, v)
    if name_suffix:
        c["name"] = cfg["name"] + "__" + name_suffix
    return c


def pareto_front(rows: List[dict], objectives: List[str]) -> List[int]:
    """Indices of non-dominated rows (all objectives minimised)."""
    ok = [i for i, r in enumerate(rows) if r.get("status") == "ok"]
    front = []
    for i in ok:
        a = [rows[i][o] for o in objectives]
        dom = False
        for j in ok:
            if j == i:
                continue
            b = [rows[j][o] for o in objectives]
            if all(bb <= aa for aa, bb in zip(a, b)) and any(bb < aa for aa, bb in zip(a, b)):
                dom = True
                break
        if not dom:
            front.append(i)
    return front


def baseline_cases() -> Dict[str, dict]:
    return {"A_fcbga_forced_air": default_config_A("forced_air_heatsink"),
            "A_fcbga_passive_heatsink": default_config_A("passive_heatsink"),
            "A_fcbga_natural": default_config_A("natural"),
            "A_fcbga_cold_plate": default_config_A("cold_plate"),
            "A_bare_die_forced_air": default_config_A("forced_air_heatsink", lid=False),
            "A0_wirebond_qfn_natural": default_config_A0(),
            "B_si_interposer_forced_air": default_config_B(True),
            "B_organic_mcm_forced_air": default_config_B(False),
            "B_si_interposer_cold_plate": default_config_B(True, cooling="cold_plate")}


def _baseline_case(item):
    key, cfg = item
    r = run_thermal(cfg, keep=True)
    model, solver, T = r["_model"], r["_solver"], r["_T"]
    d = strip_private(r)
    cm = compact_thermal_model(cfg)
    d["compact"] = cm
    tl = pv(cfg["tj_limits_c"]["planning"])
    tc = pv(cfg["tj_limits_c"]["characterised"])
    if cfg["architecture"].startswith("multi_die"):
        d["p_max"] = {"planning": {"tj_limit_c": tl, "p_max_w": r["power_w"] * (tl - r["ambient_c"]) / r["tj_rise_k"], "method": "linear scaling at fixed h"}}
    else:
        d["p_max"] = {"planning": power_capacity(cfg, tl), "characterised": power_capacity(cfg, tc)}
    sol = solve_pdn(cfg, model)
    d["pdn"] = {k: v for k, v in sol.items() if not k.startswith("_") and k != "dies"}
    d["pdn"]["dies"] = {k: {kk: vv for kk, vv in v.items() if kk != "map_mv"} for k, v in sol["dies"].items()}
    if cfg["architecture"] == "flip_chip_single_die":
        ic = interconnect_study(cfg, die_rect=model.dies[0].rect)
        d["interconnect"] = {k: v for k, v in ic.items() if k not in ("bump_sites", "ball_sites")}
        n_pairs = min(ic["bumps"]["counts"]["VDD"], ic["bumps"]["counts"]["VSS"])
        n_ball = min(ic["balls"]["counts"]["VDD"], ic["balls"]["counts"]["VSS"])
    elif cfg["architecture"] == "wire_bond_qfn":
        ic = None
        n_pairs = int(pv(cfg["qfn"]["vdd_pads"]))
        n_ball = n_pairs
    else:
        ic = None
        n_pairs = int(sol["links"].get("ubumps", sol["links"].get("c4_bumps", {"connections": 1000}))["connections"] / 2)
        n_ball = int(sol["info"].get("balls_per_net", 50))
    r_die = sol["worst_drop_mv"] / 1e3 / max(sol["load_current_a"], 1e-12)
    lb = pv(cfg["qfn"]["wire_l_loop_h"]) if cfg["architecture"] == "wire_bond_qfn" else None
    zi = pdn_impedance(cfg, n_pairs, n_ball, r_die, link_l_bump=lb, link_l_ball=0.0 if lb else None)
    V = pv(cfg["pdn"]["vdd_v"])
    dI = pv(cfg["pdn"]["step_current_fraction"]) * sol["load_current_a"]
    d["pdn_ac"] = {"peak_impedance_ohm": zi["peak_ohm"], "f_peak_hz": zi["f_peak_hz"], "step_current_a": dI,
                   "target_impedance_ohm": pv(cfg["pdn"]["dynamic_budget_fraction"]) * V / max(dI, 1e-12),
                   "first_droop_estimate_mv": zi["peak_ohm"] * dI * 1e3, "l_bump_eff_h": zi["l_bump_eff_h"], "note": zi["note"]}
    x, y, mp_ = r["_die_map"]
    dr = model.meta["die_rect"].expand(0.6 * MM)
    sx = (x >= dr.x0) & (x <= dr.x1)
    sy = (y >= dr.y0) & (y <= dr.y1)
    vw = {"x_mm": (x[sx] / MM).round(4).tolist(), "y_mm": (y[sy] / MM).round(4).tolist(),
          "t_c": np.where(np.isfinite(mp_[np.ix_(sy, sx)]), mp_[np.ix_(sy, sx)], None).tolist()}
    m = solver.mesh
    jc = int(np.clip(np.searchsorted(m.ye, model.meta["die_rect"].cy) - 1, 0, m.ny - 1))
    T3 = solver.T3(T)
    sec = T3[:, jc, :]
    xs = (np.abs(m.xc) <= max(model.meta["body_rect"].w, 1e-3) * 0.8)
    vw["section"] = {"x_mm": (m.xc[xs] / MM).round(4).tolist(), "z_mm": (m.zc / MM).round(5).tolist(),
                     "t_c": np.where(np.isfinite(sec[:, xs]), sec[:, xs], None).tolist(), "y_mm": float(m.yc[jc] / MM)}
    vw["layers"] = [{"name": L.name, "role": L.role, "z0_mm": L.z0 / MM, "z1_mm": L.z1 / MM, "background": L.background,
                     "regions": [{"rect_mm": rr.mm(), "material": mm_} for rr, mm_ in L.regions], "source": L.source} for L in model.layers]
    vw["domain_mm"] = model.domain.mm()
    vw["bcs"] = [{"name": b.name, "type": b.type, "surface": b.surface, "layers": b.layers, "h": b.h, "T": b.T,
                  "region_mm": b.region.mm() if b.region else None} for b in model.bcs]
    vw["dies"] = [{"name": dp.name, "rect_mm": dp.rect.mm(), "face_down": dp.face_down, "prov": dp.prov} for dp in model.dies]
    blocks = []
    for s in model.sources:
        if s.rect is not None:
            blocks.append({"label": s.label, "class": s.group, "rect_mm": s.rect.mm(), "power_w": s.power, "prov": s.prov})
    vw["source_rects"] = blocks
    pg = None
    grids = [s for s in model.sources if s.grid_p is not None]
    if grids:
        gx, gy = grids[0].grid_x, grids[0].grid_y
        acc = sum(s.grid_p for s in grids)
        area = np.outer(np.diff(gy), np.diff(gx)) / MM ** 2
        pg = {"x_mm": (0.5 * (gx[1:] + gx[:-1]) / MM).round(4).tolist(), "y_mm": (0.5 * (gy[1:] + gy[:-1]) / MM).round(4).tolist(),
              "w_per_mm2": (acc / area).tolist()}
        fp = model.dies[0].floorplan
        vw["groups"] = [{"name": g["name"], "class": PowerModel().cls(g["name"]),
                         "centroid_mm": [float(v / MM) for v in model.dies[0].to_pkg(*g["centroid_um"])],
                         "extent_mm": model.dies[0].rect_to_pkg(g["extent_um"]).mm()} for g in fp["std_cell_groups"]]
    vw["power_grid"] = pg
    if ic is not None:
        vw["bumps"] = ic["bump_sites"]
        vw["balls"] = ic["ball_sites"]
    for sname, dd in sol["dies"].items():
        vw.setdefault("ir_maps", {})[sname] = {"rect_mm": dd["rect_mm"], "mv": np.round(dd["map_mv"], 5).tolist()}
    if "_res" in sol and ic is not None:
        nw = sol["_pdn"]["nets"]["VDD"]
        rr_ = sol["_res"]["VDD"]
        sel = rr_["branch_groups"] == "bumps"
        lk = [l_ for l_ in nw.links if l_.kind == "bumps"][0]
        vw["bump_currents_ma"] = {"x_mm": (lk.xa / MM).round(4).tolist(), "y_mm": (lk.ya / MM).round(4).tolist(),
                                  "i_ma": (np.abs(rr_["branch_i"][sel]) * 1e3).round(6).tolist()}
    d["_viewer"] = vw
    return key, d


def study_baselines(out: Path, workers: int = 4) -> dict:
    cases = baseline_cases()
    res = {}
    viewer = {}

    items = list(cases.items())
    outs = parallel_map(_baseline_case, items, workers)
    for key, d in outs:
        viewer[key] = d.pop("_viewer")
        d.pop("_die_map", None)
        res[key] = d
    jdump(res, out / "results" / "baselines.json")
    jdump(viewer, out / "viewer" / "viewer_data.json", indent=None)
    rows = []
    for k, d in res.items():
        rows.append({"case": k, "architecture": d["architecture"], "workload": d["workload"], "power_w": d["power_w"], "tj_c": d["tj_c"],
                     "theta_ja_k_w": d["theta_ja_k_w"], "psi_jt_k_w": d.get("psi_jt_k_w"), "psi_jb_k_w": d.get("psi_jb_k_w"),
                     "theta_jc_top_k_w": d["compact"]["theta_jc_top_k_w"], "theta_jb_k_w": d["compact"]["theta_jb_k_w"],
                     "top_path_frac": d["heat_split"]["top_path"], "board_path_frac": d["heat_split"]["board_path"],
                     "p_max_planning_w": d["p_max"]["planning"]["p_max_w"], "ir_drop_mv": d["pdn"]["worst_drop_mv"],
                     "ir_budget_mv": d["pdn"]["budget_mv"], "pdn_loss_w": d["pdn"]["p_loss_w"],
                     "pdn_peak_z_ohm": d["pdn_ac"]["peak_impedance_ohm"], "pdn_target_z_ohm": d["pdn_ac"]["target_impedance_ohm"],
                     "cost_index": cost_index(cases[k]), "stack_height_mm": stack_height_mm(cases[k]),
                     "energy_residual_rel": d["energy_residual_rel"], "cells": d["mesh"]["cells_active"]})
    write_csv(out / "results" / "baselines.csv", rows)
    return res


def study_workloads(out: Path, workers: int = 4) -> List[dict]:
    pm = PowerModel()
    items = []
    for key, cfg in (("A_fcbga_forced_air", default_config_A()), ("A_fcbga_natural", default_config_A("natural"))):
        for wl in pm.workloads:
            items.append((f"{key}:{wl}", cfg, wl, {"family": key}))
    rows = parallel_map(_run_point, items, workers)
    fp = load_floorplan(default_config_A()["die"]["floorplan"])
    pw = []
    for wl in pm.workloads:
        br = pm.evaluate(fp, wl)
        pw.append({"workload": wl, "description": br["description"], "total_w": br["total_power_w"], "core_w": br["core_power_w"],
                   "io_w": br["io_power_w"], "core_current_ma": br["core_current_a"] * 1e3,
                   **{f"class_{k}_mw": v * 1e3 for k, v in br["by_class_w"].items()}, **{f"comp_{k}_mw": v * 1e3 for k, v in br["components_w"].items()}})
    write_csv(out / "results" / "workload_power.csv", pw)
    write_csv(out / "results" / "workload_thermal.csv", rows)
    return rows


def study_sensitivity(out: Path, workers: int = 4) -> dict:
    """Section 7: chip-package thermal coupling sensitivities (Scenario A, forced-air baseline unless stated)."""
    base = default_config_A("forced_air_heatsink")
    nat = default_config_A("natural")
    items = []
    for k in (1, 2, 3, 5, 8, 15):
        items.append((f"tim1_k={k}", variant(base, {"tim1.k_w_mk": float(k)}, f"timk{k}"), None, {"study": "tim1_k", "x": k}))
    for rc in (1, 2, 5, 10, 20):
        items.append((f"tim1_R={rc}", variant(base, {"tim1.contact_mm2k_w": float(rc)}, f"timR{rc}"), None, {"study": "tim1_contact", "x": rc}))
    for t in (20, 35, 50, 75, 100, 150):
        items.append((f"tim1_blt={t}", variant(base, {"tim1.thickness_um": float(t)}, f"timt{t}"), None, {"study": "tim1_blt", "x": t}))
    for t in (1, 2, 3, 5, 8):
        items.append((f"hs_base={t}", variant(base, {"cooling.heatsink.base_mm": float(t)}, f"hsb{t}"), None, {"study": "heatsink_base_mm", "x": t}))
    for mat in ("aluminium_6063", "copper"):
        items.append((f"hs_mat={mat}", variant(base, {"cooling.heatsink.material": mat}, f"hsm{mat}"), None, {"study": "heatsink_material", "x": mat}))
    for t in (0.3, 0.5, 0.8, 1.2, 2.0):
        items.append((f"lid_t={t}", variant(base, {"lid.thickness_mm": t}, f"lidt{t}"), None, {"study": "lid_thickness_mm", "x": t}))
        items.append((f"lid_t={t}_nat", variant(nat, {"lid.thickness_mm": t}, f"lidt{t}"), None, {"study": "lid_thickness_mm_natural", "x": t}))
    for lm, extra in (("copper", {}), ("aluminium_6063", {}),
                      ("lid_ideal", {"extra_materials": {"lid_ideal": {"base": "copper", "k": 1.0e5, "prov": "derived", "note": "numerical experiment: ideal spreader"}},
                                     "numerical_experiment": True})):
        for bcfg, tag in ((base, ""), (nat, "_nat")):
            items.append((f"lid_mat={lm}{tag}", variant(bcfg, {"lid.material": lm, **extra}, f"lidm{lm}"), None, {"study": "lid_material" + tag, "x": lm}))
    for t in (100, 200, 300, 500, 725):
        items.append((f"die_t={t}", variant(base, {"die.thickness_um": float(t)}, f"diet{t}"), None, {"study": "die_thickness_um", "x": t}))
    for nl in (2, 4, 6, 8):
        items.append((f"sub_layers={nl}", variant(nat, {"substrate.metal_layers": nl}, f"subl{nl}"), None, {"study": "substrate_layers_natural", "x": nl}))
    fp = load_floorplan(base["die"]["floorplan"])
    br = PowerModel().evaluate(fp, "mixed")
    Pt = br["by_class_w"]["TensorCore"]
    Ptot = br["total_power_w"]
    for share in (Pt / Ptot, 0.4, 0.6, 0.8):
        a = share * Ptot / Pt
        b = (1 - share) * Ptot / (Ptot - Pt)
        for bcfg, tag in ((base, ""), (nat, "_nat")):
            items.append((f"tensor_share={share:.2f}{tag}", variant(bcfg, {"_class_scale": {"TensorCore": a, "*": b}}, f"conc{share:.2f}"), None,
                          {"study": "power_concentration" + tag, "x": round(share, 4)}))
    rows = parallel_map(_run_point, items, workers)
    write_csv(out / "results" / "sensitivity.csv", rows)
    # TIM collapse onto total TIM1 resistance R'' = t/k + 2 R_c
    tim = []
    for r in rows:
        if r.get("study") in ("tim1_k", "tim1_contact", "tim1_blt") and r["status"] == "ok":
            k = r["x"] if r["study"] == "tim1_k" else 3.0
            Rc = r["x"] if r["study"] == "tim1_contact" else 5.0
            t = r["x"] if r["study"] == "tim1_blt" else 50.0
            tim.append((t / k + 2 * Rc, r["theta_ja_k_w"]))
    xs, ys = np.array([a for a, _ in tim]), np.array([b for _, b in tim])
    A_ = np.vstack([xs, np.ones_like(xs)]).T
    coef, *_ = np.linalg.lstsq(A_, ys, rcond=None)
    pred = A_ @ coef
    r2 = 1 - np.sum((ys - pred) ** 2) / np.sum((ys - ys.mean()) ** 2)
    die_area = (fp["die_um"][2] - fp["die_um"][0]) * (fp["die_um"][3] - fp["die_um"][1]) * 1e-6
    rb = run_thermal(base)
    f_tim = [f["upward_w"] for f in rb["interface_flows_w"] if f["lower"] == "die" and f["upper"] == "tim1"][0] / rb["power_w"]
    lid = {}
    for tag in ("", "_nat"):
        th = {r["x"]: r["theta_ja_k_w"] for r in rows if r.get("study") == "lid_material" + tag and r["status"] == "ok"}
        if "lid_ideal" in th:
            lid["forced" if not tag else "natural"] = {m: th["lid_ideal"] / v for m, v in th.items()}
    summary = {"tim_collapse": {"slope_k_w_per_mm2k_w": float(coef[0]), "intercept_k_w": float(coef[1]), "r2": float(r2),
                                "die_area_mm2": die_area, "fraction_of_heat_through_tim1": f_tim,
                                "local_slope_parallel_paths_f2_over_area": f_tim ** 2 / die_area,
                                "interpretation": "TIM1 is a series resistance R''/A_die in the top path, in parallel with the board path: "
                                                  "d(theta_JA)/dR'' = f^2/A_die at the baseline (f = share of heat crossing TIM1); the fitted secant slope "
                                                  "over the swept range is lower because the board path takes over as TIM1 worsens"},
               "spreader_efficiency": lid,
               "spreader_efficiency_definition": "eta = theta_JA(ideal spreader, k = 1e5 W/mK numerical experiment) / theta_JA(actual lid)"}
    jdump(summary, out / "results" / "sensitivity_summary.json")
    return {"rows": rows, "summary": summary}


def study_sweeps(out: Path, workers: int = 4) -> dict:
    """Section 12: design sweeps.  Thermal metrics on the level-0 mesh (discretisation uncertainty from the GCI study)."""
    base = default_config_A("forced_air_heatsink")
    nat = default_config_A("natural")
    items = []
    for body in (8, 10, 12, 15, 20):
        for bcfg, tag in ((base, "forced"), (nat, "natural")):
            items.append((f"body={body}_{tag}", variant(bcfg, {"substrate.body_mm": float(body)}, f"body{body}"), None,
                          {"sweep": "package_size", "x": body, "cooling": tag}))
    for v in (0.5, 1.0, 2.0, 4.0):
        items.append((f"air={v}", variant(base, {"cooling.velocity_m_s": v}, f"air{v}"), None, {"sweep": "cooling", "x": f"forced {v} m/s"}))
    items.append(("natural", nat, None, {"sweep": "cooling", "x": "natural"}))
    items.append(("passive_hs", default_config_A("passive_heatsink"), None, {"sweep": "cooling", "x": "passive heatsink"}))
    for h in (3e3, 1e4, 3e4):
        items.append((f"coldplate={h:g}", variant(default_config_A("cold_plate"), {"cooling.cold_plate.h_eff_w_m2k": h}, f"cp{h:g}"), None,
                      {"sweep": "cooling", "x": f"cold plate h={h:g}"}))
    for amb in (25.0, 45.0):
        for bcfg, tag in ((base, "forced"), (nat, "natural")):
            items.append((f"amb={amb}_{tag}", variant(bcfg, {"ambient_c": amb}, f"amb{amb}"), None, {"sweep": "ambient", "x": amb, "cooling": tag}))
    for run in list_floorplans():
        fp = load_floorplan(run)
        area = (fp["die_um"][2] - fp["die_um"][0]) * (fp["die_um"][3] - fp["die_um"][1]) * 1e-6
        for bcfg, tag in ((base, "forced"), (nat, "natural")):
            items.append((f"fp={run}_{tag}", variant(bcfg, {"die.floorplan": run}, f"fp{run}"), None,
                          {"sweep": "placement", "x": run, "cooling": tag, "die_area_mm2": area, "description": fp["description"]}))
    for p_ in (150, 175, 200, 250):
        for bcfg, tag in ((base, "forced"), (nat, "natural")):
            items.append((f"bump_pitch={p_}_{tag}", variant(bcfg, {"bumps.pitch_um": float(p_), "bumps.diameter_um": 90.0}, f"bp{p_}"), None,
                          {"sweep": "bump_pitch_thermal", "x": p_, "cooling": tag, "bump_area_fraction": math.pi * 45.0 ** 2 / p_ ** 2}))
    rows = parallel_map(_run_point, items, workers)
    # electrical side of the bump-distribution sweep (fast)
    erows = []
    for p_ in (150, 175, 200, 250):
        for pat in ("checkerboard", "rows", "quadrant"):
            for rings in (2, 3, 4):
                c = variant(base, {"bumps.pitch_um": float(p_), "bumps.diameter_um": 90.0, "bumps.signal_rings": rings, "bumps.pg_pattern": pat})
                c["bumps"]["pg_pattern"] = pat
                try:
                    m = build_model(c, workload="mixed")
                    ic = interconnect_study(c, die_rect=m.dies[0].rect)
                    sol = solve_pdn(c, m, build_pdn(c, m, ic))
                    mx = PowerModel().evaluate(load_floorplan(c["die"]["floorplan"]), "max_simultaneous")
                    erows.append({"pitch_um": p_, "pattern": pat, "signal_rings": rings, **{f"n_{k}": v for k, v in ic["bumps"]["counts"].items()},
                                  "sites": ic["bumps"]["sites_total"], "signal_shortfall": ic["bumps"]["signal_shortfall"],
                                  "ir_drop_mv": sol["worst_drop_mv"], "max_bump_ma": sol["links"]["bumps"]["max_per_connection_a"] * 1e3,
                                  "em_margin": sol["links"]["bumps"]["em_margin"],
                                  "em_margin_at_max_simultaneous": sol["links"]["bumps"]["em_margin"] * sol["load_current_a"] / mx["core_current_a"],
                                  "substrate_escape_layers": ic["substrate_escape"]["layers_needed"], "status": "ok"})
                except TwinError as e:
                    erows.append({"pitch_um": p_, "pattern": pat, "signal_rings": rings, "status": "rejected", "reason": str(e)})
    write_csv(out / "results" / "sweeps.csv", rows)
    write_csv(out / "results" / "bump_distribution.csv", erows)
    # PDN per floorplan (IR drop varies with where current is drawn)
    prow = []
    for run in list_floorplans():
        c = variant(base, {"die.floorplan": run})
        m = build_model(c, workload="mixed")
        sol = solve_pdn(c, m)
        prow.append({"floorplan": run, "ir_drop_mv": sol["worst_drop_mv"], "mean_drop_mv": sol["dies"]["die"]["mean_drop_mv"],
                     "pdn_loss_uw": sol["p_loss_w"] * 1e6})
    write_csv(out / "results" / "placement_pdn.csv", prow)
    return {"rows": rows, "bump_rows": erows, "placement_pdn": prow}


def study_pareto(out: Path, workers: int = 4) -> dict:
    items = []
    for cool in ("natural", "passive_heatsink", "forced_air_heatsink", "cold_plate"):
        for hsb in ((2.0, 4.0, 8.0) if cool != "natural" else (None,)):
            for tk in (1.0, 3.0, 8.0):
                for body in (8.0, 10.0, 15.0):
                    ch = {"tim1.k_w_mk": tk, "substrate.body_mm": body}
                    if hsb is not None:
                        ch["cooling.heatsink.base_mm" if cool != "cold_plate" else "cooling.cold_plate.base_mm"] = hsb
                    c = variant(default_config_A(cool), ch, f"par_{cool}_{hsb}_{tk}_{body}")
                    items.append((c["name"], c, None, {"cooling": cool, "base_mm": hsb, "tim1_k": tk, "body_mm": body, "family": "A"}))
    rowsA = parallel_map(_run_point, items, workers)
    frontA = pareto_front(rowsA, ["theta_ja_k_w", "cost_index"])
    frontA3 = pareto_front(rowsA, ["theta_ja_k_w", "cost_index", "stack_height_mm"])
    for i, r in enumerate(rowsA):
        r["pareto"] = i in frontA
        r["pareto_3obj"] = i in frontA3
    itemsB = []
    for inter in (True, False):
        for cool, vel, h in (("passive_heatsink", None, None), ("forced_air_heatsink", 2.0, None), ("forced_air_heatsink", 4.0, None),
                             ("cold_plate", None, 1e4), ("cold_plate", None, 3e4)):
            for tk in (3.0, 8.0):
                ch = {"tim1.k_w_mk": tk}
                if vel:
                    ch["cooling.velocity_m_s"] = vel
                if h:
                    ch["cooling.cold_plate.h_eff_w_m2k"] = h
                c = variant(default_config_B(inter, cooling=cool), ch, f"parB_{vel}_{h}_{tk}")
                itemsB.append((c["name"], c, None, {"cooling": cool + (f" {vel} m/s" if vel else "") + (f" h={h:g}" if h else ""),
                                                    "interposer": inter, "tim1_k": tk, "family": "B"}))
    rowsB = parallel_map(_run_point, itemsB, workers)
    frontB = pareto_front(rowsB, ["tj_c", "cost_index"])
    for i, r in enumerate(rowsB):
        r["pareto"] = i in frontB
    write_csv(out / "results" / "pareto_A.csv", rowsA)
    write_csv(out / "results" / "pareto_B.csv", rowsB)
    return {"A": rowsA, "B": rowsB}


def study_transients(out: Path) -> dict:
    """Step and burst responses with staged time steps (implicit Euler)."""
    res = {}
    level = -1      # transient mesh (one level coarser than the sweep mesh; end state checked against the steady solve on it)
    for key, cfg, bursts in (("A_fcbga_forced_air", default_config_A(), False), ("B_si_interposer_forced_air", default_config_B(), True)):
        r = run_thermal(cfg, level=level, keep=True)
        s, T_ss, q, model = r["_solver"], r["_T"], r["_q"], r["_model"]
        Ta = model.ambient_c
        src = np.concatenate([s.layer_cells(L.name) for L in model.layers if L.source])
        T = np.full(s.N, Ta)
        ts, tj = [0.0], [Ta]
        t_off = 0.0
        for t_end, dt in ((5.0, 0.05), (60.0, 0.5), (600.0, 5.0), (3000.0, 25.0)):
            span = t_end - t_off
            tr = s.transient([(0.0, q)], span, dt, theta=1.0, T0=T, record={"tj": src}, record_every=1)
            ts += [t_off + t for t in tr["t"][1:]]
            tj += tr["tj"][1:]
            T = tr["T_final"]
            t_off = t_end
        final = r["tj_c"]
        rise = final - Ta
        def t_at(frac):
            for t_, v in zip(ts, tj):
                if v - Ta >= frac * rise:
                    return t_
            return None
        d = {"mesh_level": level, "cells": s.N, "tj_steady_c": final, "t63_s": t_at(0.632), "t90_s": t_at(0.9), "t95_s": t_at(0.95), "t99_s": t_at(0.99),
             "tj_at_1s_frac": float(np.interp(1.0, ts, tj) - Ta) / rise, "tj_at_10s_frac": float(np.interp(10.0, ts, tj) - Ta) / rise,
             "end_vs_steady_k": abs(tj[-1] - final), "t_s": ts, "tj_c": tj, "power_w": r["power_w"]}
        if bursts:
            # compute dies burst 3x nominal for 2 s every 10 s around the same average power
            q_hi = q.copy()
            comp = np.zeros(s.N, bool)
            for sname in ("SFX_COMPUTE_0", "SFX_COMPUTE_1"):
                for so in model.sources:
                    if so.die == sname:
                        qq, _ = s.source_vector([so])
                        comp |= qq > 0
            q_lo = np.where(comp, q * 0.5, q)
            q_hi = np.where(comp, q * 3.0, q)
            T = T_ss.copy()
            seg = []
            for k in range(6):
                seg += [(10.0 * k, q_hi), (10.0 * k + 2.0, q_lo)]
            # average compute power = (2*3 + 8*0.5)/10 = 1.0 x nominal
            tr = s.transient(seg, 60.0, 0.1, theta=1.0, T0=T, record={"tj": src})
            d["burst"] = {"period_s": 10.0, "on_s": 2.0, "on_scale": 3.0, "off_scale": 0.5, "tj_max_c": max(tr["tj"][100:]), "tj_min_c": min(tr["tj"][100:]),
                          "tj_steady_avg_power_c": final, "t_s": tr["t"], "tj_c": tr["tj"], "energy_residual": tr["energy_residual_max"],
                          "tj_cycle_mean_c": float(np.mean(tr["tj"][-100:])),
                          "max_heating_rate_k_s": float(np.max(np.diff(tr["tj"]) / np.diff(tr["t"]))),
                          "max_cooling_rate_k_s": float(-np.min(np.diff(tr["tj"]) / np.diff(tr["t"])))}
        res[key] = d
    jdump(res, out / "results" / "transients.json")
    return res


def study_multidie(out: Path) -> dict:
    cfg = default_config_B(True)
    tc = thermal_coupling(cfg, tj_limit=pv(cfg["tj_limits_c"]["planning"]))
    d2d = {"interposer": d2d_study(cfg), "organic_mcm": d2d_study(default_config_B(False))}
    et = {"A": electrothermal(default_config_A()), "B": electrothermal(cfg),
          "A_leakage_what_if": electrothermal(default_config_A("natural"), leak_what_if={"p0_w": 0.5, "k_per_k": 0.08})}
    rail = []
    m = build_model(cfg, workload="hpc_nominal")
    V = pv(cfg["pdn"]["vdd_v"])
    md = cfg["multi_die"]
    for d in model_dies_power(m):
        I = d["power_w"] / V
        r = [x for x in md["dies"] if x["name"] == d["die"]][0]
        area_mm2 = pv(r["w_mm"]) * pv(r["h_mm"])
        n_ub_pg = area_mm2 / (pv(md["ubump_pitch_um"]) / 1000) ** 2 * 0.7
        need = I / (0.5 * pv(md["ubump_i_max_a"]))
        rail.append({"die": d["die"], "power_w": d["power_w"], "current_a": I, "pg_ubumps_available": n_ub_pg,
                     "pg_ubumps_needed_50pct_em_derate": need * 2, "ok": n_ub_pg >= need * 2})
    res = {"thermal_coupling": tc, "d2d": d2d, "electrothermal": et, "rail_allocation": rail,
           "hbm": "integration target only (not modelled as available): requires licensed HBM PHY + controller, a JEDEC-compliant "
                  "interposer channel, known-good stacked DRAM supply and physical validation"}
    jdump(res, out / "results" / "multidie.json")
    return res


def model_dies_power(model: PackageModel) -> List[dict]:
    out: Dict[str, float] = {}
    for s in model.sources:
        out[s.die] = out.get(s.die, 0.0) + s.power
    return [{"die": k, "power_w": v} for k, v in out.items()]


# =============================================================================
# 18. Interactive 3-D package explorer (Plotly, single offline HTML)
# =============================================================================
ROLE_COLOR = {"pcb": "#1d3a5f", "balls": "#d9ac3c", "substrate": "#2b3f74", "die_interconnect": "#5b4b8a", "beol": "#9aa6c8",
              "device": "#c3b2ff", "silicon": "#8b6cf0", "tim1": "#22c7e0", "spreader": "#d9ac3c", "tim2": "#8eeaf6",
              "heatsink": "#22c7e0", "solder": "#9aa6c8", "leadframe": "#d9ac3c", "die_attach": "#5b4b8a", "mould": "#26304f",
              "interposer": "#6d7fb8", "interposer_rdl": "#9aa6c8"}
NET_COLOR = {"VDD": "#d9ac3c", "VSS": "#8b6cf0", "SIG": "#22c7e0", "VDDIO": "#f2d27a", "VSSIO": "#c3b2ff", "SPARE": "#3b4a7a"}
CLASS_COLOR = {"ControlCore": "#d9ac3c", "VectorEngine": "#22c7e0", "TensorCore": "#ef5d6a", "SRAM": "#8b6cf0", "DataFabric": "#8eeaf6",
               "IO": "#f2d27a", "ClockAndGlue": "#9aa6c8", "HBM(placeholder)": "#c3b2ff", "PDN_loss": "#ffffff"}
THERMAL_SCALE = [[0.0, "#0b1533"], [0.25, "#3b2f7a"], [0.5, "#8b6cf0"], [0.75, "#22c7e0"], [1.0, "#f2d27a"]]
BADGES = {"SIM": ("SIMULATED", "#22c7e0"), "EDA": ("EDA-DERIVED", "#d9ac3c"), "ILL": ("ENGINEERING ILLUSTRATION", "#8b6cf0"),
          "HYP": ("HYPOTHETICAL", "#ef5d6a"), "ASM": ("ASSUMED INPUT", "#c3b2ff")}


def _layout(title: str, **kw) -> dict:
    lay = dict(title=dict(text=title, font=dict(size=14, color=PALETTE["ink"])), paper_bgcolor=PALETTE["navy"], plot_bgcolor=PALETTE["navy2"],
               font=dict(color=PALETTE["ink"], family="Inter, Segoe UI, Helvetica, Arial, sans-serif", size=11),
               margin=dict(l=55, r=20, t=50, b=45), legend=dict(bgcolor="rgba(11,21,51,0.6)", bordercolor=PALETTE["navy3"], borderwidth=1))
    lay.update(kw)
    return lay


def _axis(title, **kw):
    d = dict(title=dict(text=title), gridcolor=PALETTE["navy3"], zerolinecolor=PALETTE["navy3"], linecolor=PALETTE["muted"])
    d.update(kw)
    return d


def _box_mesh(r: List[float], z0: float, z1: float, color: str, name: str, hover: str, opacity: float = 0.9, show=True, group=None) -> dict:
    x0, y0, x1, y1 = r
    xs = [x0, x1, x1, x0, x0, x1, x1, x0]
    ys = [y0, y0, y1, y1, y0, y0, y1, y1]
    zs = [z0, z0, z0, z0, z1, z1, z1, z1]
    i = [0, 0, 4, 4, 0, 0, 1, 1, 2, 2, 3, 3]
    j = [1, 2, 5, 6, 1, 5, 2, 6, 3, 7, 0, 4]
    k = [2, 3, 6, 7, 5, 4, 6, 5, 7, 6, 4, 7]
    return dict(type="mesh3d", x=xs, y=ys, z=zs, i=i, j=j, k=k, color=color, opacity=opacity, name=name, flatshading=True,
                hovertext=hover, hoverinfo="text", showlegend=show, legendgroup=group or name, visible=True,
                lighting=dict(ambient=0.55, diffuse=0.7, specular=0.2), lightposition=dict(x=200, y=200, z=400))


def _fig_stack3d(key: str, v: dict, base: dict) -> dict:
    """3-D layer stack: (a) assembled, true lateral geometry with uniformly exaggerated z; (b) exploded and NOT TO SCALE in z
    (every layer gets a minimum display thickness so 10-um layers are visible)."""
    dom = v["domain_mm"]
    body = base["meta_body_mm"]
    win = max(body[2] - body[0], 12.0) * 0.5 + 6.0
    if base.get("heatsink_mm"):
        win = max(win, (base["heatsink_mm"][2] - base["heatsink_mm"][0]) / 2 + 2.0)
    clip = [max(dom[0], -win), max(dom[1], -win), min(dom[2], win), min(dom[3], win)]
    lat = clip[2] - clip[0]
    H = v["layers"][-1]["z1_mm"]
    zx = 0.25 * lat / max(H, 1e-3)
    tmin = 0.035 * lat
    gap = 0.5 * tmin
    zd = []
    z = 0.0
    for L in v["layers"]:
        t = max((L["z1_mm"] - L["z0_mm"]) * zx, tmin)
        zd.append((z, z + t))
        z += t + gap
    def zmap(li, zz, mode):
        L = v["layers"][li]
        if mode == "true":
            return zz * zx
        a, b = zd[li]
        return a + (zz - L["z0_mm"]) / max(L["z1_mm"] - L["z0_mm"], 1e-12) * (b - a)
    names = [L["name"] for L in v["layers"]]
    sets = {"true": [], "exploded": []}
    for mode in ("true", "exploded"):
        seen = set()
        for li, L in enumerate(v["layers"]):
            regs = []
            if L["background"]:
                regs.append((clip, L["background"]))
            for rg in L["regions"]:
                r = rg["rect_mm"]
                rc = [max(r[0], clip[0]), max(r[1], clip[1]), min(r[2], clip[2]), min(r[3], clip[3])]
                if rc[2] > rc[0] and rc[3] > rc[1]:
                    regs.append((rc, rg["material"]))
            for rc, mat in regs:
                col = ROLE_COLOR.get(L["role"], PALETTE["muted"])
                if mat in ("underfill", "lid_adhesive"):
                    col = "#3b2f7a"
                if mat == "mold_compound":
                    col = "#26304f"
                if mat.startswith("copper") and L["role"] not in ("spreader",):
                    col = "#d9ac3c"
                hv = (f"<b>{L['name']}</b> ({L['role']})<br>material: {mat}<br>z = {L['z0_mm']:.4f} .. {L['z1_mm']:.4f} mm (true)"
                      f"<br>thickness {1000 * (L['z1_mm'] - L['z0_mm']):.1f} um<br>footprint {rc[2] - rc[0]:.2f} x {rc[3] - rc[1]:.2f} mm")
                op = {"pcb": 0.25, "heatsink": 0.22, "spreader": 0.45, "tim2": 0.45}.get(L["role"], 0.92)
                t = _box_mesh(rc, zmap(li, L["z0_mm"], mode), zmap(li, L["z1_mm"], mode), col, L["name"], hv, op, L["name"] not in seen)
                seen.add(L["name"])
                sets[mode].append(t)
        li_act = [i for i, L in enumerate(v["layers"]) if L["source"]][0]
        zt = zmap(li_act, v["layers"][li_act]["z1_mm"], mode) + 0.01 * lat
        first = True
        for sr in v.get("source_rects", []):
            if sr["class"] == "PDN_loss":
                continue
            hv = f"<b>{sr['label']}</b><br>class {sr['class']}<br>{sr['power_w'] * 1e3:.3f} mW ({sr['prov']})"
            sets[mode].append(_box_mesh(sr["rect_mm"], zt, zt + 0.004 * lat, CLASS_COLOR.get(sr["class"], PALETTE["muted"]),
                                        "blocks (power sources)", hv, 0.95, first, "blocks"))
            first = False
        for what, lname, size in (("bumps", "bumps", 2.5), ("balls", "bga", 3.5)):
            if not v.get(what) or lname not in names:
                continue
            li = names.index(lname)
            L = v["layers"][li]
            zb = zmap(li, 0.5 * (L["z0_mm"] + L["z1_mm"]), mode)
            for net in ("VDD", "VSS", "SIG", "VDDIO", "VSSIO"):
                pts = [b for b in v[what] if b["net"] == net]
                if pts:
                    sets[mode].append(dict(type="scatter3d", mode="markers", x=[q["x_mm"] for q in pts], y=[q["y_mm"] for q in pts], z=[zb] * len(pts),
                                           marker=dict(size=size, color=NET_COLOR[net]), name=f"{what[:-1]} {net}", legendgroup=f"{what}{net}",
                                           hovertext=[f"{what[:-1]} {net} (hypothetical allocation)" for _ in pts], hoverinfo="text"))
        zs_ = np.array([[np.nan if c is None else c for c in row] for row in v["t_c"]], float)
        sets[mode].append(dict(type="surface", x=v["x_mm"], y=v["y_mm"], z=np.full(zs_.shape, zt + 0.006 * lat).tolist(),
                               surfacecolor=np.where(np.isfinite(zs_), zs_, None).tolist(), colorscale=THERMAL_SCALE, showscale=True,
                               colorbar=dict(title=dict(text="T (degC)<br>SIMULATED"), len=0.45, x=1.02), opacity=0.98, name="device-layer temperature (simulated)",
                               visible="legendonly", hovertemplate="x %{x:.2f} mm<br>y %{y:.2f} mm<br>T %{surfacecolor:.4f} degC<extra>simulated</extra>"))
        top = zmap(len(names) - 1, v["layers"][-1]["z1_mm"], mode)
        for b in v["bcs"]:
            if b["type"] != "convection" or b["name"] not in ("heatsink_top", "board_bottom", "lid_exposed", "package_top"):
                continue
            if b["name"] == "board_bottom":
                zc_, w = -0.04 * lat, -1
            elif b["name"] == "lid_exposed" and "heatsink" in names:
                continue
            else:
                zc_, w = top + 0.04 * lat, 1
            sets[mode].append(dict(type="cone", x=[-0.15 * lat, 0, 0.15 * lat], y=[0, 0, 0], z=[zc_] * 3, u=[0] * 3, v=[0] * 3, w=[w] * 3,
                                   sizemode="absolute", sizeref=0.04 * lat, colorscale=[[0, PALETTE["cyan"]], [1, PALETTE["cyan"]]], showscale=False,
                                   name=f"cooling BC: {b['name']}", hovertext=f"{b['name']}: h = {b['h']:.1f} W/m2K, T = {b['T']:.1f} degC (correlation / declared, no CFD)",
                                   hoverinfo="text"))
    nt, ne = len(sets["true"]), len(sets["exploded"])
    legend = {}
    for mode in ("true", "exploded"):
        seen_names, flags = set(), []
        for t in sets[mode]:
            key_ = t.get("legendgroup") or t.get("name")
            flags.append(key_ not in seen_names)
            seen_names.add(key_)
            t["legendgroup"] = key_
        legend[mode] = flags
    for t, f in zip(sets["true"], legend["true"]):
        t["showlegend"] = f
    for t in sets["exploded"]:
        t["visible"] = False
        t["showlegend"] = False
    vis_t = [("legendonly" if t.get("type") == "surface" else True) for t in sets["true"]] + [False] * ne
    vis_e = [False] * nt + [("legendonly" if t.get("type") == "surface" else True) for t in sets["exploded"]]
    title_t = f"{key} - layer stack  [{BADGES['ILL'][0]}: declared geometry; z exaggerated x{zx:.1f}; board cropped to +/-{win:.0f} mm]"
    title_e = f"{key} - EXPLODED view, z NOT TO SCALE (min. display thickness)  [{BADGES['ILL'][0]}]"
    lay = _layout(title_t, scene=dict(xaxis=_axis("x (mm)", backgroundcolor=PALETTE["navy"]), yaxis=_axis("y (mm)", backgroundcolor=PALETTE["navy"]),
                                      zaxis=_axis("z (display)", backgroundcolor=PALETTE["navy"]), aspectmode="data",
                                      camera=dict(eye=dict(x=1.35, y=-1.55, z=0.85))),
                  height=680, updatemenus=[dict(type="buttons", direction="right", x=0.0, y=0.0, xanchor="left", yanchor="bottom", showactive=True,
                                                bgcolor=PALETTE["gold"], bordercolor=PALETTE["gold"], font=dict(color=PALETTE["navy"], size=12),
                                                buttons=[dict(label="Assembled (z exaggerated)", method="update",
                                                              args=[{"visible": vis_t, "showlegend": legend["true"] + [False] * ne}, {"title.text": title_t}]),
                                                         dict(label="Exploded (not to scale)", method="update",
                                                              args=[{"visible": vis_e, "showlegend": [False] * nt + legend["exploded"]}, {"title.text": title_e}])])],
                  legend=dict(bgcolor="rgba(11,21,51,0.7)", bordercolor=PALETTE["navy3"], borderwidth=1, font=dict(size=10)))
    return {"data": sets["true"] + sets["exploded"], "layout": lay}


def _fig_floorplan(key: str, v: dict) -> dict:
    tr = []
    hyp = key.startswith("B")
    if v.get("power_grid"):
        pg = v["power_grid"]
        z = np.array(pg["w_per_mm2"], float)
        tr.append(dict(type="heatmap", x=pg["x_mm"], y=pg["y_mm"], z=np.where(z > 0, z, None).tolist(), colorscale=THERMAL_SCALE,
                       colorbar=dict(title=dict(text="W/mm2<br>(modelled)")), name="std-cell power density",
                       hovertemplate="%{z:.3e} W/mm2<extra>EDA density x assumed activity</extra>"))
    shapes = []
    for d in v["dies"]:
        r = d["rect_mm"]
        shapes.append(dict(type="rect", x0=r[0], y0=r[1], x1=r[2], y1=r[3], line=dict(color=PALETTE["gold"], width=2)))
        tr.append(dict(type="scatter", x=[(r[0] + r[2]) / 2], y=[r[3]], mode="text", text=[d["name"] + (" (face-down, mirrored)" if d["face_down"] and not hyp else "")],
                       textposition="top center", showlegend=False, textfont=dict(color=PALETTE["gold"])))
    for s in v.get("source_rects", []):
        if s["class"] in ("PDN_loss",):
            continue
        r = s["rect_mm"]
        col = CLASS_COLOR.get(s["class"], PALETTE["muted"])
        tr.append(dict(type="scatter", x=[r[0], r[2], r[2], r[0], r[0]], y=[r[1], r[1], r[3], r[3], r[1]], mode="lines", fill="toself",
                       fillcolor=col + ("55" if hyp else "33"), line=dict(color=col, width=1), name=s["class"], legendgroup=s["class"],
                       showlegend=False, hovertext=f"{s['label']}<br>{s['class']} {s['power_w'] * 1e3:.3f} mW ({s['prov']})", hoverinfo="text"))
    for g in v.get("groups", []):
        tr.append(dict(type="scatter", x=[g["centroid_mm"][0]], y=[g["centroid_mm"][1]], mode="markers+text", text=[g["name"]],
                       textposition="bottom center", marker=dict(size=7, color=CLASS_COLOR.get(g["class"], "#fff"), line=dict(color="#fff", width=1)),
                       name=g["class"], legendgroup=g["class"], hovertext=f"group {g['name']} ({g['class']}) placement centroid (EDA-derived)",
                       hoverinfo="text"))
    seen = set()
    for t in tr:
        if t.get("legendgroup") and t.get("type") == "scatter" and t.get("mode") == "markers+text":
            t["showlegend"] = t["legendgroup"] not in seen
            seen.add(t["legendgroup"])
    badge = f"{BADGES['HYP'][0]} block plan" if hyp else f"{BADGES['EDA'][0]} placement (FloorplanLab, OpenROAD, IHP SG13G2) x {BADGES['ASM'][0]} activity"
    lay = _layout(f"{key} - die floorplan and modelled power density  [{badge}]  (package coordinates, viewed from top)",
                  xaxis=_axis("x (mm)", scaleanchor="y"), yaxis=_axis("y (mm)"), shapes=shapes, height=600,
                  legend=dict(orientation="h", y=-0.12, x=0, bgcolor="rgba(11,21,51,0.6)"))
    return {"data": tr, "layout": lay}


def _fig_thermal(key: str, v: dict) -> List[dict]:
    z = np.array([[np.nan if c is None else c for c in row] for row in v["t_c"]], float)
    f1 = {"data": [dict(type="contour", x=v["x_mm"], y=v["y_mm"], z=np.where(np.isfinite(z), z, None).tolist(), colorscale=THERMAL_SCALE,
                        contours=dict(coloring="heatmap", showlabels=True, labelfont=dict(color="#ffffff", size=9)), ncontours=18,
                        colorbar=dict(title=dict(text="T (degC)")), hovertemplate="x %{x:.2f} y %{y:.2f} mm<br>T %{z:.4f} degC<extra>simulated</extra>")],
          "layout": _layout(f"{key} - device-layer temperature  [{BADGES['SIM'][0]}: FV conduction, declared inputs]",
                            xaxis=_axis("x (mm)", scaleanchor="y"), yaxis=_axis("y (mm)"), height=520)}
    for d in v["dies"]:
        r = d["rect_mm"]
        f1["layout"].setdefault("shapes", []).append(dict(type="rect", x0=r[0], y0=r[1], x1=r[2], y1=r[3], line=dict(color=PALETTE["gold"], width=1.5, dash="dot")))
    sec = v["section"]
    zz = np.array([[np.nan if c is None else c for c in row] for row in sec["t_c"]], float)
    f2 = {"data": [dict(type="heatmap", x=sec["x_mm"], y=sec["z_mm"], z=np.where(np.isfinite(zz), zz, None).tolist(), colorscale=THERMAL_SCALE,
                        colorbar=dict(title=dict(text="T (degC)")), hovertemplate="x %{x:.2f} mm, z %{y:.4f} mm<br>T %{z:.4f} degC<extra>simulated</extra>")],
          "layout": _layout(f"{key} - vertical section at y = {sec['y_mm']:.2f} mm  [{BADGES['SIM'][0]}; cells on the non-uniform mesh, blank = void]",
                            xaxis=_axis("x (mm)"), yaxis=_axis("z (mm, mesh cell centres)"), height=460)}
    return [f1, f2]


def _fig_interconnect(key: str, v: dict) -> List[dict]:
    figs = []
    for what, title in (("bumps", "C4 bump map (die, package coordinates)"), ("balls", "BGA ball map")):
        if not v.get(what):
            continue
        tr = []
        for net in ("VDD", "VSS", "SIG", "VDDIO", "VSSIO", "SPARE"):
            pts = [b for b in v[what] if b["net"] == net]
            if pts:
                tr.append(dict(type="scatter", mode="markers", x=[p["x_mm"] for p in pts], y=[p["y_mm"] for p in pts],
                               marker=dict(size=9 if what == "bumps" else 11, color=NET_COLOR[net], line=dict(color="#0b1533", width=1)),
                               name=f"{net} ({len(pts)})", hovertext=[f"{net} ring {p['ring']}" for p in pts], hoverinfo="text"))
        shapes = [dict(type="rect", x0=d["rect_mm"][0], y0=d["rect_mm"][1], x1=d["rect_mm"][2], y1=d["rect_mm"][3], line=dict(color=PALETTE["gold"]))
                  for d in v["dies"]]
        figs.append({"data": tr, "layout": _layout(f"{key} - {title}  [{BADGES['ILL'][0]}: hypothetical allocation - no bump plan or pad ring exists]",
                                                   xaxis=_axis("x (mm)", scaleanchor="y"), yaxis=_axis("y (mm)"), shapes=shapes, height=520)})
    return figs


def _fig_pdn(key: str, v: dict) -> List[dict]:
    figs = []
    for sname, m in v.get("ir_maps", {}).items():
        r = m["rect_mm"]
        z = np.array(m["mv"])
        ny, nx = z.shape
        xs = np.linspace(r[0], r[2], nx + 1)
        ys = np.linspace(r[1], r[3], ny + 1)
        tr = [dict(type="heatmap", x=(0.5 * (xs[1:] + xs[:-1])).tolist(), y=(0.5 * (ys[1:] + ys[:-1])).tolist(), z=z.tolist(), colorscale=THERMAL_SCALE,
                   colorbar=dict(title=dict(text="VDD-VSS drop (mV)")), hovertemplate="%{z:.4f} mV<extra>simulated (resistive)</extra>")]
        if v.get("bump_currents_ma") and sname == "die":
            b = v["bump_currents_ma"]
            tr.append(dict(type="scatter", mode="markers", x=b["x_mm"], y=b["y_mm"], marker=dict(size=8, color=b["i_ma"], colorscale=[[0, PALETTE["violet"]], [1, PALETTE["gold"]]],
                           showscale=False, line=dict(color="#fff", width=0.5)), name="VDD bump current", hovertext=[f"{i:.4f} mA" for i in b["i_ma"]], hoverinfo="text"))
        figs.append({"data": tr, "layout": _layout(f"{key} - static IR drop on {sname}  [{BADGES['SIM'][0]}: homogenised resistive PDN, not EM extraction]",
                                                   xaxis=_axis("x (mm)", scaleanchor="y"), yaxis=_axis("y (mm)"), height=480)})
    return figs


def _fig_cooling(key: str, res: dict) -> dict:
    flows = res["heat_flow_w"]
    names = [k for k, v in flows.items() if abs(v) > 0]
    vals = [flows[k] / max(res["power_w"], 1e-30) * 100 for k in names]
    hs = res["cooling"]
    hv = {k: v for k, v in hs.items() if isinstance(v, float) and k not in ("T_top", "coolant_rise_per_w")}
    return {"data": [dict(type="bar", x=names, y=vals, marker=dict(color=PALETTE["cyan"]), name="share of heat (%)", hovertemplate="%{y:.2f} %<extra>simulated</extra>"),
                     dict(type="bar", x=list(hv), y=list(hv.values()), marker=dict(color=PALETTE["gold"]), name="h (W/m2K)", xaxis="x2", yaxis="y2",
                          hovertemplate="%{y:.1f} W/m2K<extra>correlation / declared</extra>")],
            "layout": _layout(f"{key} - cooling boundaries: heat leaving each boundary (left, SIMULATED) and coefficients used (right, correlation-based, no CFD)",
                              xaxis=dict(domain=[0, 0.45], **_axis("")), yaxis=_axis("% of dissipated power"),
                              xaxis2=dict(domain=[0.55, 1.0], anchor="y2", **_axis("")), yaxis2=dict(anchor="x2", type="log", **_axis("h (W/m2K)")),
                              height=430, showlegend=False)}


def _csv_rows(p: Path) -> List[dict]:
    if not p.exists():
        return []
    with open(p) as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k, v in list(r.items()):
            try:
                r[k] = float(v)
            except (TypeError, ValueError):
                pass
    return rows


def _fig_studies(out: Path) -> List[dict]:
    figs = []
    sens = _csv_rows(out / "results" / "sensitivity.csv")
    sw = _csv_rows(out / "results" / "sweeps.csv")
    tag = f"[{BADGES['SIM'][0]} on declared/assumed inputs; level-0 mesh]"
    def line(study_rows, xkey, ykey, name, color):
        study_rows = sorted(study_rows, key=lambda r: r[xkey])
        return dict(type="scatter", mode="lines+markers", x=[r[xkey] for r in study_rows], y=[r[ykey] for r in study_rows], name=name,
                    line=dict(color=color, width=2), marker=dict(size=7))
    tr = []
    for st, col in (("tim1_k", PALETTE["cyan"]), ("tim1_contact", PALETTE["gold"]), ("tim1_blt", PALETTE["violet"])):
        rows = [r for r in sens if r.get("study") == st and r.get("status") == "ok"]
        for r in rows:
            k = r["x"] if st == "tim1_k" else 3.0
            Rc = r["x"] if st == "tim1_contact" else 5.0
            t = r["x"] if st == "tim1_blt" else 50.0
            r["R_tim"] = t / k + 2 * Rc
        if rows:
            tr.append(line(rows, "R_tim", "theta_ja_k_w", st, col))
    figs.append({"data": tr, "layout": _layout(f"Scenario A (forced air) - theta_JA vs total TIM1 resistance t/k + 2R''  {tag}",
                                               xaxis=_axis("TIM1 resistance (mm2 K/W)"), yaxis=_axis("theta_JA (K/W)"), height=420)})
    for group, ttl in (((("heatsink_base_mm", PALETTE["cyan"], "heatsink base"), ("lid_thickness_mm", PALETTE["gold"], "lid thickness")), "forced air"),
                       ((("lid_thickness_mm_natural", PALETTE["violet"], "lid thickness"),), "still air")):
        tr = []
        for st, col, nm in group:
            rows = [r for r in sens if r.get("study") == st and r.get("status") == "ok"]
            if rows:
                tr.append(line(rows, "x", "theta_ja_k_w", nm, col))
        figs.append({"data": tr, "layout": _layout(f"Scenario A ({ttl}) - theta_JA vs heatsink base / lid thickness {tag}", xaxis=_axis("thickness (mm)"),
                                                   yaxis=_axis("theta_JA (K/W)"), height=380)})
    tr = []
    for cool, col in (("forced", PALETTE["cyan"]), ("natural", PALETTE["violet"])):
        rows = [r for r in sw if r.get("sweep") == "package_size" and r.get("cooling") == cool and r.get("status") == "ok"]
        if rows:
            tr.append(line(rows, "x", "theta_ja_k_w", cool, col))
    figs.append({"data": tr, "layout": _layout(f"Scenario A - theta_JA vs FCBGA body size {tag}", xaxis=_axis("body (mm)"), yaxis=_axis("theta_JA (K/W)", type="log"), height=420)})
    rows = [r for r in sw if r.get("sweep") == "placement" and r.get("status") == "ok"]
    if rows:
        tr = []
        for cool, col in (("forced", PALETTE["cyan"]), ("natural", PALETTE["violet"])):
            rr = [r for r in rows if r.get("cooling") == cool]
            tr.append(dict(type="bar", x=[r["x"] for r in rr], y=[r["theta_ja_k_w"] for r in rr], name=cool, marker=dict(color=col)))
        figs.append({"data": tr, "layout": _layout(f"Tensor/vector placement - 14 FloorplanLab placements (EDA-derived) {tag}", barmode="group",
                                                   xaxis=_axis(""), yaxis=_axis("theta_JA (K/W)", type="log"), height=420)})
    pa = _csv_rows(out / "results" / "pareto_A.csv")
    if pa:
        tr = []
        for cool, col in (("natural", PALETTE["violet"]), ("passive_heatsink", PALETTE["gold"]), ("forced_air_heatsink", PALETTE["cyan"]), ("cold_plate", PALETTE["red"])):
            rr = [r for r in pa if r.get("cooling") == cool and r.get("status") == "ok"]
            tr.append(dict(type="scatter", mode="markers", x=[r["cost_index"] for r in rr], y=[r["theta_ja_k_w"] for r in rr], name=cool,
                           marker=dict(size=[12 if str(r.get("pareto")) in ("True", "1.0") else 6 for r in rr], color=col,
                                       line=dict(color=["#ffffff" if str(r.get("pareto")) in ("True", "1.0") else col for r in rr], width=1.5)),
                           hovertext=[f"base {r.get('base_mm')} mm, TIM1 k {r.get('tim1_k')}, body {r.get('body_mm')} mm<br>height {r['stack_height_mm']:.1f} mm"
                                      for r in rr], hoverinfo="text+x+y"))
        figs.append({"data": tr, "layout": _layout(f"Scenario A Pareto trade-off: theta_JA vs ASSUMED cost index (white ring = non-dominated in theta_JA and cost) {tag}",
                                                   xaxis=_axis("relative cost index (assumed)"), yaxis=_axis("theta_JA (K/W)", type="log"), height=480)})
    pb = _csv_rows(out / "results" / "pareto_B.csv")
    if pb:
        tr = []
        for inter, col in (("True", PALETTE["cyan"]), ("False", PALETTE["gold"])):
            rr = [r for r in pb if str(r.get("interposer")) in (inter, "1.0" if inter == "True" else "0.0") and r.get("status") == "ok"]
            tr.append(dict(type="scatter", mode="markers", x=[r["cost_index"] for r in rr], y=[r["tj_c"] for r in rr],
                           name="Si interposer" if inter == "True" else "organic MCM", marker=dict(size=9, color=col),
                           hovertext=[f"{r['cooling']} TIM1 k {r['tim1_k']}" for r in rr], hoverinfo="text+x+y"))
        figs.append({"data": tr, "layout": _layout(f"Scenario B ({BADGES['HYP'][0]} power) - peak Tj vs assumed cost index {tag}",
                                                   xaxis=_axis("relative cost index (assumed)"), yaxis=_axis("Tj (degC)"), height=460)})
    tj = out / "results" / "transients.json"
    if tj.exists():
        t = jload(tj)
        tr = []
        for k, col in zip(t, (PALETTE["cyan"], PALETTE["gold"])):
            d = t[k]
            rise = np.array(d["tj_c"]) - d["tj_c"][0]
            tr.append(dict(type="scatter", mode="lines", x=d["t_s"][1:], y=(rise / max(rise[-1], 1e-30))[1:].tolist(), name=k, line=dict(color=col)))
        figs.append({"data": tr, "layout": _layout(f"Step response: normalised junction rise {tag}", xaxis=_axis("time (s)", type="log"),
                                                   yaxis=_axis("(Tj - Ta)/(Tj,ss - Ta)"), height=420)})
    return figs


def build_viewer(out: Path) -> Path:
    import plotly
    from plotly.offline import get_plotlyjs
    vd = jload(out / "viewer" / "viewer_data.json")
    bl = jload(out / "results" / "baselines.json")
    cases = {}
    for key, v in vd.items():
        res = bl[key]
        base = {"meta_body_mm": None, "heatsink_mm": None}
        bodies = [L for L in v["layers"] if L["name"] in ("substrate", "mold")]
        base["meta_body_mm"] = bodies[0]["regions"][0]["rect_mm"] if bodies and bodies[0]["regions"] else v["domain_mm"]
        hsl = [L for L in v["layers"] if L["name"] == "heatsink"]
        base["heatsink_mm"] = hsl[0]["regions"][0]["rect_mm"] if hsl else None
        figs = {"stack": [_fig_stack3d(key, v, base)], "floorplan": [_fig_floorplan(key, v)], "thermal": _fig_thermal(key, v),
                "interconnect": _fig_interconnect(key, v), "pdn": _fig_pdn(key, v), "cooling": [_fig_cooling(key, res)]}
        summ = {"Power (W)": res["power_w"], "Tj (degC)": res["tj_c"], "theta_JA (K/W)": res["theta_ja_k_w"],
                "theta_JC top, idealised (K/W)": res["compact"]["theta_jc_top_k_w"], "theta_JB idealised (K/W)": res["compact"]["theta_jb_k_w"],
                "Top path (%)": 100 * res["heat_split"]["top_path"], "Board path (%)": 100 * res["heat_split"]["board_path"],
                "P_max at planning Tj (W)": res["p_max"]["planning"]["p_max_w"], "Static IR drop (mV)": res["pdn"]["worst_drop_mv"],
                "Energy residual": res["energy_residual_rel"], "Mesh cells": res["mesh"]["cells_active"]}
        cases[key] = {"figs": figs, "summary": summ, "hyp": key.startswith("B"), "arch": res["architecture"]}
    studies = _fig_studies(out)
    val = jload(out / "validation" / "validation.json") if (out / "validation" / "validation.json").exists() else None
    payload = json.dumps({"cases": cases, "studies": studies,
                          "validation": [{"test": t["test"], "passed": t["passed"], "metric": t["metric"], "tol": str(t["tolerance"])} for t in val["tests"]] if val else [],
                          "conv": val.get("mesh_convergence", []) if val else [],
                          "version": __version__, "palette": PALETTE}, default=_json_default, allow_nan=False)
    html = VIEWER_TEMPLATE.replace("/*PLOTLYJS*/", get_plotlyjs()).replace("/*PAYLOAD*/", payload)
    p = out / "viewer" / "package_explorer.html"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(html)
    return p


VIEWER_TEMPLATE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>SilicaFlux PackageTwin Explorer</title>
<style>
:root{--navy:#0b1533;--navy2:#111d45;--navy3:#1a2a5e;--ink:#e8ecf8;--muted:#9aa6c8;--gold:#d9ac3c;--cyan:#22c7e0;--violet:#8b6cf0;--red:#ef5d6a}
*{box-sizing:border-box}body{margin:0;background:var(--navy);color:var(--ink);font:14px/1.45 Inter,"Segoe UI",Helvetica,Arial,sans-serif}
header{padding:18px 20px 10px;border-bottom:1px solid var(--navy3);background:linear-gradient(180deg,#0e1b45,#0b1533)}
h1{margin:0;font-size:20px;letter-spacing:.3px}h1 span{color:var(--gold)}
.sub{color:var(--muted);font-size:12.5px;margin-top:4px;max-width:1100px}
.badges{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.badge{font-size:11px;padding:3px 8px;border-radius:999px;border:1px solid;letter-spacing:.4px}
nav{display:flex;flex-wrap:wrap;gap:6px;padding:10px 20px;border-bottom:1px solid var(--navy3);align-items:center}
nav button{background:var(--navy2);color:var(--ink);border:1px solid var(--navy3);padding:6px 12px;border-radius:8px;cursor:pointer;font:inherit}
nav button.on{border-color:var(--cyan);color:var(--cyan)}select{background:var(--navy2);color:var(--ink);border:1px solid var(--navy3);padding:6px 8px;border-radius:8px;font:inherit;max-width:100%}
main{padding:14px 20px 40px}.plot{width:100%;min-height:420px;margin-bottom:16px;border:1px solid var(--navy3);border-radius:10px;overflow:hidden}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:8px;margin-bottom:14px}
.kpi{background:var(--navy2);border:1px solid var(--navy3);border-radius:10px;padding:8px 10px}.kpi b{display:block;font-size:17px;color:var(--gold)}.kpi span{font-size:11.5px;color:var(--muted)}
.warn{border:1px solid var(--red);color:#ffd5d9;background:rgba(239,93,106,.08);padding:8px 12px;border-radius:8px;margin-bottom:12px;font-size:12.5px}
table{border-collapse:collapse;width:100%;font-size:12.5px}td,th{border-bottom:1px solid var(--navy3);padding:6px 8px;text-align:left;vertical-align:top}
.pass{color:var(--cyan)}.fail{color:var(--red)}.note{color:var(--muted);font-size:12px}
@media (max-width:640px){header,nav,main{padding-left:16px;padding-right:16px}h1{font-size:17px}}
</style></head><body>
<header><h1>SilicaFlux <span>PackageTwin</span> - 3D package explorer</h1>
<div class="sub">Engineering digital twin of the proposed SilicaFlux package (Aureom.AI / SilicaFlux-HPC, Project 29). Every panel carries a provenance badge.
Die outline, SRAM macro placement and std-cell density are EDA-derived (FloorplanLab, OpenROAD on IHP SG13G2, pre-CTS); every package, cooling and activity value is an
assumption or hypothetical; there are no measurements. Temperatures and voltages are model outputs for those declared inputs - not signoff, not silicon data.</div>
<div class="badges" id="badges"></div></header>
<nav><select id="case" aria-label="case"></select><span id="tabs"></span></nav>
<main><div id="hyp"></div><div class="grid" id="kpis"></div><div id="plots"></div></main>
<script>/*PLOTLYJS*/</script>
<script>
const P=/*PAYLOAD*/;
const BADGES=[["SIMULATED","#22c7e0"],["EDA-DERIVED","#d9ac3c"],["ENGINEERING ILLUSTRATION","#8b6cf0"],["HYPOTHETICAL","#ef5d6a"],["ASSUMED INPUT","#c3b2ff"]];
document.getElementById('badges').innerHTML=BADGES.map(b=>`<span class="badge" style="color:${b[1]};border-color:${b[1]}">${b[0]}</span>`).join('');
const TABS=[["stack","3D layer stack"],["floorplan","Floorplan & power"],["thermal","Thermal"],["interconnect","Bumps & balls"],["pdn","Power delivery"],["cooling","Cooling boundaries"],["studies","Sweeps & Pareto"],["validation","Verification"]];
const sel=document.getElementById('case');Object.keys(P.cases).forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=k;sel.appendChild(o)});
let tab="stack";function st(k,d){try{return localStorage.getItem(k)||d}catch(e){return d}}function ss(k,v){try{localStorage.setItem(k,v)}catch(e){}}
tab=st('ptw_tab','stack');sel.value=st('ptw_case',sel.options[0].value);if(!P.cases[sel.value])sel.value=sel.options[0].value;
const tabsEl=document.getElementById('tabs');
function drawTabs(){tabsEl.innerHTML=TABS.map(t=>`<button class="${t[0]===tab?'on':''}" data-t="${t[0]}">${t[1]}</button>`).join(' ');tabsEl.querySelectorAll('button').forEach(b=>b.onclick=()=>{tab=b.dataset.t;ss('ptw_tab',tab);render()})}
const CFG={responsive:true,displaylogo:false,toImageButtonOptions:{format:'png',scale:2}};
function fmt(v){if(typeof v!=='number')return v;const a=Math.abs(v);return a===0?'0':(a>=1e4||a<1e-3?v.toExponential(3):(a>=100?v.toFixed(1):v.toPrecision(4)))}
function render(){drawTabs();const c=P.cases[sel.value];ss('ptw_case',sel.value);const plots=document.getElementById('plots');plots.innerHTML='';
document.getElementById('hyp').innerHTML=c.hyp?'<div class="warn"><b>HYPOTHETICAL research scenario.</b> No SilicaFlux chiplet, interposer, micro-bump, UCIe or HBM capability exists; die sizes, block plans and power densities are placeholders for design-space exploration.</div>':'';
const k=document.getElementById('kpis');k.innerHTML=(tab==='studies'||tab==='validation')?'':Object.entries(c.summary).map(([a,b])=>`<div class="kpi"><b>${fmt(b)}</b><span>${a}</span></div>`).join('');
let figs=[];if(tab==='studies')figs=P.studies;else if(tab==='validation'){renderValidation(plots);return}else figs=c.figs[tab]||[];
if(!figs.length){plots.innerHTML='<p class="note">Not applicable to this configuration.</p>';return}
figs.forEach((f,i)=>{const d=document.createElement('div');d.className='plot';plots.appendChild(d);Plotly.newPlot(d,f.data,f.layout,CFG)})}
function renderValidation(el){let h='<table><tr><th>Verification test</th><th>Result</th><th>Metric</th><th>Tolerance</th></tr>';
P.validation.forEach(t=>{h+=`<tr><td>${t.test}</td><td class="${t.passed?'pass':'fail'}">${t.passed?'PASS':'FAIL'}</td><td>${fmt(t.metric)}</td><td>${t.tol}</td></tr>`});h+='</table>';
P.conv.forEach(c=>{h+=`<h3 style="margin-top:18px">Mesh convergence - ${c.case}</h3><table><tr><th>level</th><th>cells</th><th>mean die rise (K)</th><th>peak rise (K)</th></tr>`;
c.levels.forEach(l=>{h+=`<tr><td>${l.level}</td><td>${l.cells}</td><td>${fmt(l.mean_rise_k)}</td><td>${fmt(l.tj_rise_k)}</td></tr>`});
h+=`</table><p class="note">observed order (mean) ${fmt(c.mean_rise.observed_order)}, fine-grid GCI ${fmt(100*c.mean_rise.gci_fine_rel)} %; peak: order ${fmt(c.peak_rise.observed_order)}, GCI ${fmt(100*c.peak_rise.gci_fine_rel)} %</p>`});
el.innerHTML=h;document.getElementById('kpis').innerHTML=''}
sel.onchange=render;render();
</script></body></html>"""


# =============================================================================
# 19. Schemas (geometry / material / power / exchange)
# =============================================================================
_PSPEC = {"oneOf": [{"type": "number"}, {"type": "object", "required": ["value", "prov"],
                                          "properties": {"value": {}, "prov": {"enum": list(PROV_CLASSES)}, "source": {"type": "string"},
                                                         "range": {"type": "array"}, "unit": {"type": "string"}, "note": {"type": "string"}}}]}

SCHEMAS = {
    "scenario.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "PackageTwin scenario (geometry + materials + boundaries + PDN)",
        "type": "object", "required": ["schema", "name", "architecture", "ambient_c", "die", "substrate", "tim1", "cooling", "board", "pdn"],
        "properties": {
            "schema": {"const": "packagetwin.scenario/1"}, "name": {"type": "string"},
            "architecture": {"enum": ["flip_chip_single_die", "wire_bond_qfn", "multi_die_interposer", "multi_die_organic_mcm"]},
            "ambient_c": {"$ref": "#/$defs/p"}, "workload": {"type": "string"},
            "die": {"type": "object", "required": ["floorplan", "thickness_um", "beol_thickness_um", "active_thickness_um"],
                    "properties": {"floorplan": {"type": "string"}, "thickness_um": {"$ref": "#/$defs/p"}, "beol_thickness_um": {"$ref": "#/$defs/p"},
                                   "active_thickness_um": {"$ref": "#/$defs/p"}}},
            "bumps": {"type": "object", "required": ["pitch_um", "diameter_um", "height_um", "material"]},
            "substrate": {"type": "object", "required": ["body_mm", "metal_layers", "core_um", "cu_um"]},
            "bga": {"type": "object", "required": ["pitch_mm", "ball_diameter_mm", "standoff_mm"]},
            "lid": {"type": "object", "required": ["enabled", "material"]},
            "tim1": {"type": "object", "required": ["material", "k_w_mk", "thickness_um", "contact_mm2k_w"]},
            "tim2": {"type": "object", "required": ["material", "k_w_mk", "thickness_um", "contact_mm2k_w"]},
            "cooling": {"type": "object", "required": ["type"], "properties": {"type": {"enum": ["natural", "passive_heatsink", "forced_air_heatsink", "cold_plate"]}}},
            "board": {"type": "object", "required": ["width_mm", "length_mm", "thickness_mm"]},
            "pdn": {"type": "object", "required": ["vdd_v"]},
            "multi_die": {"type": "object"}, "qfn": {"type": "object"}, "mesh": {"type": "object"}},
        "$defs": {"p": _PSPEC}},
    "materials.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "PackageTwin material database", "type": "object",
        "required": ["schema", "materials"],
        "properties": {"schema": {"const": "packagetwin.materials/1"}, "materials": {"type": "object", "additionalProperties": {
            "type": "object", "required": ["rho", "cp", "prov"],
            "properties": {"k": {"type": "number", "exclusiveMinimum": 0}, "kxy": {"type": "number", "exclusiveMinimum": 0},
                           "kz": {"type": "number", "exclusiveMinimum": 0}, "rho": {"type": "number", "exclusiveMinimum": 0},
                           "cp": {"type": "number", "exclusiveMinimum": 0}, "prov": {"enum": list(PROV_CLASSES)}, "source": {"type": "string"},
                           "k_temp_exponent": {"type": "number"}, "resistivity_ohm_m": {"type": "number", "exclusiveMinimum": 0},
                           "tcr_per_k": {"type": "number"}, "emissivity": {"type": "number", "minimum": 0, "maximum": 1}},
            "anyOf": [{"required": ["k"]}, {"required": ["kz"]}]}}}},
    "floorplan.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "Vendored FloorplanLab/TwinLab floorplan subset", "type": "object",
        "required": ["schema", "run_id", "provenance", "die_um", "core_um", "macros", "std_cell_groups", "density_grid", "io_pins"],
        "properties": {"schema": {"const": "packagetwin.floorplan/1"}, "die_um": {"type": "array", "minItems": 4, "maxItems": 4},
                       "macros": {"type": "array", "items": {"type": "object", "required": ["name", "master", "bbox_um", "group"]}},
                       "std_cell_groups": {"type": "array", "items": {"type": "object", "required": ["name", "area_um2", "centroid_um", "extent_um"]}},
                       "density_grid": {"type": "object", "required": ["bins", "bin_w_um", "bin_h_um", "origin_um", "utilisation"]}}},
    "power_map.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "Measured / externally estimated block power import (replaces the assumed model)",
        "type": "object", "required": ["schema", "die", "prov", "blocks"],
        "properties": {"schema": {"const": "packagetwin.power_map/1"}, "die": {"type": "string"}, "prov": {"enum": list(PROV_CLASSES)},
                       "source": {"type": "string"},
                       "blocks": {"type": "array", "items": {"type": "object", "required": ["name", "class", "rect_um", "power_w"],
                                                             "properties": {"rect_um": {"type": "array", "minItems": 4, "maxItems": 4},
                                                                            "power_w": {"type": "number", "minimum": 0}}}}}},
    "powergrid_exchange.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "PowerGrid exchange (CSV columns)", "type": "object",
        "properties": {"nodes.csv": {"const": ["node", "x_um", "y_um", "load_current_a", "voltage_v"]},
                       "resistors.csv": {"const": ["n1", "n2", "r_ohm", "layer", "dissipation_w"]}}},
    "sparameters.interface.json": {
        "title": "S-parameter interface", "description": "Touchstone v1 .sNp files of MEASURED or externally EXTRACTED channels only. PackageTwin checks passivity, reciprocity and reports insertion/return loss; it never infers PCIe/HBM/UCIe compliance.",
        "accepted": ["# HZ|KHZ|MHZ|GHZ S MA|DB|RI R <z0>"], "required_metadata": ["prov (measured|eda_derived)", "source tool / instrument", "fixture de-embedding statement"]},
}


def write_schemas(d: Path) -> None:
    for n, s in SCHEMAS.items():
        jdump(s, Path(d) / n)


def validate_against_schema(obj: dict, schema_name: str) -> List[str]:
    try:
        import jsonschema
    except ImportError:
        return ["jsonschema not installed - structural validation skipped"]
    v = jsonschema.Draft202012Validator(SCHEMAS[schema_name])
    return [f"{'/'.join(map(str, e.path))}: {e.message}" for e in v.iter_errors(obj)]


def load_power_map(path: Path) -> dict:
    """Import a measured / externally estimated block power map (power_map.schema.json)."""
    d = jload(path)
    errs = validate_against_schema(d, "power_map.schema.json")
    if errs and not errs[0].startswith("jsonschema not installed"):
        raise TwinError("power map invalid: " + "; ".join(errs[:5]))
    return d


# =============================================================================
# 20. Figures (matplotlib) and engineering report
# =============================================================================
def make_figures(out: Path) -> List[str]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list("sfx", [c for _, c in THERMAL_SCALE])
    plt.rcParams.update({"figure.facecolor": PALETTE["navy"], "axes.facecolor": PALETTE["navy2"], "axes.edgecolor": PALETTE["muted"],
                         "axes.labelcolor": PALETTE["ink"], "xtick.color": PALETTE["ink"], "ytick.color": PALETTE["ink"],
                         "text.color": PALETTE["ink"], "grid.color": PALETTE["navy3"], "font.size": 9, "savefig.dpi": 160})
    fd = out / "figures"
    fd.mkdir(parents=True, exist_ok=True)
    made = []
    vd = jload(out / "viewer" / "viewer_data.json")
    for key in ("A_fcbga_forced_air", "A_fcbga_natural", "B_si_interposer_forced_air"):
        if key not in vd:
            continue
        v = vd[key]
        z = np.array([[np.nan if c is None else c for c in r] for r in v["t_c"]], float)
        fig, ax = plt.subplots(figsize=(6.4, 4.6))
        cs = ax.contourf(v["x_mm"], v["y_mm"], z, 24, cmap=cmap)
        fig.colorbar(cs, ax=ax, label="T (degC)")
        for d in v["dies"]:
            r = d["rect_mm"]
            ax.plot([r[0], r[2], r[2], r[0], r[0]], [r[1], r[1], r[3], r[3], r[1]], color=PALETTE["gold"], lw=1)
        ax.set_aspect("equal")
        ax.set_xlabel("x (mm)"); ax.set_ylabel("y (mm)")
        ax.set_title(f"{key}: device-layer temperature [SIMULATED]", fontsize=9)
        p = fd / f"thermal_{key}.png"
        fig.tight_layout(); fig.savefig(p); plt.close(fig)
        made.append(p.name)
    v = vd.get("A_fcbga_forced_air")
    if v and v.get("power_grid"):
        pg = v["power_grid"]
        z = np.array(pg["w_per_mm2"], float)
        fig, ax = plt.subplots(figsize=(6.4, 4.6))
        im = ax.pcolormesh(pg["x_mm"], pg["y_mm"], np.where(z > 0, z, np.nan), cmap=cmap, shading="nearest")
        fig.colorbar(im, ax=ax, label="W/mm2 (std cells)")
        for s in v["source_rects"]:
            r = s["rect_mm"]
            ax.plot([r[0], r[2], r[2], r[0], r[0]], [r[1], r[1], r[3], r[3], r[1]], color=CLASS_COLOR.get(s["class"], "#fff"), lw=0.8)
        for g in v.get("groups", []):
            ax.plot(*g["centroid_mm"], "o", ms=4, color=CLASS_COLOR.get(g["class"], "#fff"))
            ax.annotate(g["name"], g["centroid_mm"], fontsize=6, color=PALETTE["ink"])
        ax.set_aspect("equal"); ax.set_xlabel("x (mm)"); ax.set_ylabel("y (mm)")
        ax.set_title("SilicaFlux-V power density, mixed workload\n[EDA-derived placement x ASSUMED activity; package coords, face-down mirror]", fontsize=8)
        p = fd / "power_density_A.png"
        fig.tight_layout(); fig.savefig(p); plt.close(fig)
        made.append(p.name)
    sens = _csv_rows(out / "results" / "sensitivity.csv")
    if sens:
        fig, ax = plt.subplots(figsize=(6.0, 4.0))
        for st, col in (("tim1_k", PALETTE["cyan"]), ("tim1_contact", PALETTE["gold"]), ("tim1_blt", PALETTE["violet"])):
            rows = []
            for r in sens:
                if r.get("study") == st and r.get("status") == "ok":
                    k = r["x"] if st == "tim1_k" else 3.0
                    Rc = r["x"] if st == "tim1_contact" else 5.0
                    t = r["x"] if st == "tim1_blt" else 50.0
                    rows.append((t / k + 2 * Rc, r["theta_ja_k_w"]))
            rows.sort()
            ax.plot([a for a, _ in rows], [b for _, b in rows], "o-", color=col, label=st)
        ax.set_xlabel("TIM1 resistance t/k + 2R'' (mm2 K/W)"); ax.set_ylabel("theta_JA (K/W)"); ax.grid(True); ax.legend()
        ax.set_title("Scenario A forced air: TIM1 sweeps collapse onto one line [SIMULATED]", fontsize=9)
        p = fd / "tim_collapse.png"
        fig.tight_layout(); fig.savefig(p); plt.close(fig)
        made.append(p.name)
    pa = _csv_rows(out / "results" / "pareto_A.csv")
    if pa:
        fig, ax = plt.subplots(figsize=(6.4, 4.4))
        for cool, col in (("natural", PALETTE["violet"]), ("passive_heatsink", PALETTE["gold"]), ("forced_air_heatsink", PALETTE["cyan"]), ("cold_plate", PALETTE["red"])):
            rr = [r for r in pa if r.get("cooling") == cool and r.get("status") == "ok"]
            ax.scatter([r["cost_index"] for r in rr], [r["theta_ja_k_w"] for r in rr], s=14, color=col, label=cool)
            fr = [r for r in rr if str(r.get("pareto")) in ("True", "1.0")]
            ax.scatter([r["cost_index"] for r in fr], [r["theta_ja_k_w"] for r in fr], s=60, facecolors="none", edgecolors="white")
        ax.set_yscale("log"); ax.set_xlabel("relative cost index (ASSUMED)"); ax.set_ylabel("theta_JA (K/W)"); ax.grid(True); ax.legend(fontsize=7)
        ax.set_title("Scenario A Pareto (white rings: non-dominated in theta_JA and assumed cost)", fontsize=9)
        p = fd / "pareto_A.png"
        fig.tight_layout(); fig.savefig(p); plt.close(fig)
        made.append(p.name)
    sw = _csv_rows(out / "results" / "sweeps.csv")
    rows = [r for r in sw if r.get("sweep") == "placement" and r.get("status") == "ok" and r.get("cooling") == "natural"]
    if rows:
        fig, ax = plt.subplots(figsize=(7.0, 3.8))
        ax.bar([r["x"] for r in rows], [r["theta_ja_k_w"] for r in rows], color=PALETTE["cyan"])
        ax.set_ylabel("theta_JA (K/W), natural convection"); ax.tick_params(axis="x", rotation=60); ax.grid(True, axis="y")
        lo = min(r["theta_ja_k_w"] for r in rows); hi = max(r["theta_ja_k_w"] for r in rows)
        ax.set_ylim(lo - 0.6 * (hi - lo) - 1e-3, hi + 0.3 * (hi - lo) + 1e-3)
        ax.set_title("Placement variants (14 EDA-derived FloorplanLab runs) [SIMULATED]", fontsize=9)
        p = fd / "placement_sweep.png"
        fig.tight_layout(); fig.savefig(p); plt.close(fig)
        made.append(p.name)
    tj = out / "results" / "transients.json"
    if tj.exists():
        t = jload(tj)
        fig, ax = plt.subplots(figsize=(6.0, 3.8))
        for k, col in zip(t, (PALETTE["cyan"], PALETTE["gold"])):
            d = t[k]
            rise = np.array(d["tj_c"]) - d["tj_c"][0]
            ax.semilogx(d["t_s"][1:], rise[1:] / rise[-1], color=col, label=k)
        ax.set_xlabel("time (s)"); ax.set_ylabel("normalised Tj rise"); ax.grid(True); ax.legend(fontsize=7)
        ax.set_title("Step response (implicit Euler, staged time steps) [SIMULATED]", fontsize=9)
        p = fd / "transient_step.png"
        fig.tight_layout(); fig.savefig(p); plt.close(fig)
        made.append(p.name)
    return made


def _f(x, nd=4):
    if x is None:
        return "-"
    if isinstance(x, str):
        return x
    if isinstance(x, bool):
        return "yes" if x else "no"
    try:
        x = float(x)
    except (TypeError, ValueError):
        return str(x)
    if not np.isfinite(x):
        return "-"
    a = abs(x)
    if a == 0:
        return "0"
    if a >= 1e4 or a < 1e-3:
        return f"{x:.{max(nd - 1, 1)}e}"
    return f"{x:.{nd}g}"


def _table(rows: List[List], head: List[str]) -> str:
    out = ["| " + " | ".join(head) + " |", "|" + "|".join(["---"] * len(head)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(_f(c) if not isinstance(c, str) else c for c in r) + " |")
    return "\n".join(out)


def missing_data_table() -> List[List[str]]:
    return [["Die thickness, backside finish, bumped-wafer availability for IHP SG13G2 MPW dies", "foundry / bumping house", "assumed 300 um; C4 bumping of IHP MPW dies is not available in the repository"],
            ["Pad ring / I/O cells, ESD, VDDIO domain, chip top (sfv_chip)", "SilicaFlux RTL + IHP sg13g2_io library", "hypothetical (FloorplanLab places core pins only)"],
            ["Bump plan, TopMetal2 pad/RDL layout, UBM stack", "physical design + bumping house DK", "hypothetical allocation generated here"],
            ["Package substrate stack-up, design rules, via structures, body size", "OSAT / substrate vendor design kit", "assumed 10 mm 1-2-1 FCBGA"],
            ["Lid, TIM1/TIM2 materials, bond lines, contact resistance", "OSAT BOM + TIM datasheets / ASTM D5470 measurement", "assumed (TIM contact resistance dominates the uncertainty)"],
            ["Heatsink / cold-plate characterisation, fan curve, system airflow", "thermal vendor data or CFD + wind tunnel", "correlations (Teertstra, Bar-Cohen & Rohsenow), no bypass"],
            ["Board stack-up, via fields, VRM placement", "system PCB design", "JESD51-7 2s2p + assumed vias/VRM distance"],
            ["SRAM macro power (IHP liberty), switching activity (SAIF/VCD)", "IHP SRAM collateral + gate-level simulation", "assumed energy/access and activity tables"],
            ["Post-CTS clock-tree power, leakage vs temperature", "CTS run + characterised liberty corners", "assumed C_sink; leakage(T) not modelled"],
            ["IHP SG13G2 BEOL thicknesses/resistivity, via resistances", "SG13G2 process specification", "assumed values (verify)"],
            ["On-die decap, package/board decap, VRM loop data", "physical design + PDN extraction", "assumed lumped values"],
            ["Extracted package/board S-parameters for any high-speed link", "EM extraction / VNA measurement", "none (interface only, compliance not assessed)"],
            ["Junction temperature limit / reliability qualification", "foundry + JEDEC qualification", "105 degC planning, 125 degC library corner"],
            ["Thermal test-die or IR/diode measurements for calibration", "laboratory", "none - model is numerically verified, not calibrated"]]


def write_report(out: Path) -> Path:
    bl = jload(out / "results" / "baselines.json")
    val = jload(out / "validation" / "validation.json")
    sens = jload(out / "results" / "sensitivity_summary.json") if (out / "results" / "sensitivity_summary.json").exists() else {}
    md = jload(out / "results" / "multidie.json") if (out / "results" / "multidie.json").exists() else {}
    tr = jload(out / "results" / "transients.json") if (out / "results" / "transients.json").exists() else {}
    audit = jload(out / "audit" / "repo_audit.json") if (out / "audit" / "repo_audit.json").exists() else None
    wl = _csv_rows(out / "results" / "workload_power.csv")
    wt = _csv_rows(out / "results" / "workload_thermal.csv")
    sw = _csv_rows(out / "results" / "sweeps.csv")
    sr = _csv_rows(out / "results" / "sensitivity.csv")
    bd = _csv_rows(out / "results" / "bump_distribution.csv")
    pa = _csv_rows(out / "results" / "pareto_A.csv")
    pb = _csv_rows(out / "results" / "pareto_B.csv")
    ppdn = _csv_rows(out / "results" / "placement_pdn.csv")
    L = []
    A = bl["A_fcbga_forced_air"]
    An = bl["A_fcbga_natural"]
    B = bl["B_si_interposer_forced_air"]
    L.append("# SilicaFlux PackageTwin - Thermal / Power Engineering Report (Project 29)\n")
    L.append(f"_Generated by `silicaflux_package_twin.py {__version__}` from the recorded results in `outputs/`. Every number below is read from a result file; none is typed in._\n")
    L.append("> **Status.** Die outline, SRAM macro placement, std-cell density, logical-group placement and on-die PDN straps are **EDA-derived** "
             "(FloorplanLab: OpenROAD/ORFS on IHP SG13G2, pre-CTS, 14 valid placements). Supply voltage and clock target are **specified** design inputs. "
             "Every package, interconnect, cooling, board and activity parameter is an **engineering assumption**; Scenario B is **hypothetical**. "
             "**Nothing is measured.** The solvers are numerically verified; the inputs are not validated against hardware. No signoff, qualification "
             "or compliance claim is made.\n")
    L.append("## 1. Key findings\n")
    v_ok = val["summary"]
    A_res = A["tj_rise_k"]
    L.append(f"1. **Solver verification: {v_ok['passed']}/{v_ok['total']} checks pass** (analytical slabs to ~1e-12, 3-D manufactured solution order "
             f"{_f(val['tests'][3].get('order_l2'))}, multilayer Fourier spreading within {_f(100 * val['tests'][4]['metric'])} %, IE/CN temporal orders "
             f"{_f(val['tests'][6]['implicit_euler']['order'])}/{_f(val['tests'][6]['crank_nicolson']['order'])}, PDN KCL/Tellegen/power balance). "
             + "".join(f"Package mesh convergence {c['case']}: fine-grid GCI {_f(100 * c['mean_rise']['gci_fine_rel'])} % (mean die rise), level-0 mesh within "
                       f"{_f(100 * c['mean_rise']['level0_vs_finest_rel'])} % of the finest. " for c in val.get("mesh_convergence", [])))
    L.append(f"2. **SilicaFlux-V as implemented is thermally light.** With the assumed `mixed` workload it dissipates {_f(A['power_w'] * 1e3)} mW "
             f"({_f(A['power_breakdown']['core_power_w'] * 1e3)} mW core + {_f(A['power_breakdown']['io_power_w'] * 1e3)} mW hypothetical pad ring). "
             f"In the lidded FCBGA with a forced-air heatsink Tj rises {_f(A_res)} K (theta_JA {_f(A['theta_ja_k_w'])} K/W); in still air "
             f"{_f(An['tj_rise_k'])} K (theta_JA {_f(An['theta_ja_k_w'])} K/W). The package choice for SilicaFlux-V is therefore driven by I/O count, "
             f"power-delivery quality, assembly availability and cost - not heat.")
    L.append(f"3. **Thermal capacity (same power shape):** P_max at the {_f(A['p_max']['planning']['tj_limit_c'])} degC planning limit is "
             f"{_f(A['p_max']['planning']['p_max_w'])} W (forced-air FCBGA) and {_f(An['p_max']['planning']['p_max_w'])} W (still-air FCBGA): "
             f"x{_f(A['p_max']['planning']['p_max_w'] / A['power_w'], 3)} and x{_f(An['p_max']['planning']['p_max_w'] / An['power_w'], 3)} headroom over the modelled workload.")
    if sens.get("tim_collapse"):
        tc = sens["tim_collapse"]
        L.append(f"4. **TIM1 is the dominant package resistance for the small die**: all TIM1 sweeps (k, contact, bond line) collapse onto "
                 f"theta_JA = {_f(tc['intercept_k_w'])} + {_f(tc['slope_k_w_per_mm2k_w'])} x (t/k + 2R'') K/W per mm2K/W (R2 = {_f(tc['r2'])}). "
                 f"{_f(100 * tc['fraction_of_heat_through_tim1'])} % of the heat crosses TIM1 in the baseline; a parallel-path model gives a local slope "
                 f"f^2/A_die = {_f(tc['local_slope_parallel_paths_f2_over_area'])}, and the secant slope is lower because the board path takes over as "
                 f"TIM1 worsens. Contact resistance is the largest single package uncertainty and must be measured.")
    L.append(f"5. **Power delivery:** static IR drop in the flip-chip baseline is {_f(A['pdn']['worst_drop_mv'])} mV against a {_f(A['pdn']['budget_mv'])} mV budget; "
             f"the wire-bond QFN reference reaches {_f(bl['A0_wirebond_qfn_natural']['pdn']['worst_drop_mv'])} mV because current enters only at the die edge. "
             f"Lumped PDN peak impedance {_f(A['pdn_ac']['peak_impedance_ohm'])} ohm at {_f(A['pdn_ac']['f_peak_hz'] / 1e6)} MHz vs target {_f(A['pdn_ac']['target_impedance_ohm'])} ohm.")
    if md:
        tcp = md["thermal_coupling"]
        L.append(f"6. **Research scenario B ({_f(B['power_w'])} W hypothetical):** Tj {_f(B['tj_c'])} degC with forced air; die-to-die thermal coupling "
                 f"{_f(tcp['R_k_per_w'][0][1])} K/W vs self-heating {_f(tcp['R_k_per_w'][0][0])} K/W (shared lid/heatsink), so chiplets cannot be budgeted independently; "
                 f"static IR drop {_f(B['pdn']['worst_drop_mv'])} mV of {_f(B['pdn']['budget_mv'])} mV budget. UCIe/HBM are integration targets only.")
    L.append("")
    L.append("## 2. Repository audit (what exists, what was used)\n")
    if audit:
        rows = [[a["artefact"], a["status"], (a["files"][0]["path"] if a["files"] else "-"), a["role"]] for a in audit["artefacts"]]
        L.append(_table(rows, ["artefact", "status", "first file", "role in PackageTwin"]))
        L.append(f"\nPackage drawings / PCB / mechanical CAD found: **{len(audit['package_drawings_found'])}**; Touchstone S-parameter files found: "
                 f"**{len(audit['s_parameter_files_found'])}**; physical measurements: **none**. Scanned {audit['n_files']} files ({audit['n_zips']} zip archives, member names listed).\n")
    L.append("Parameter classes used: measured (none), eda_derived, specified, published, assumed, hypothetical, derived - see `outputs/results/assumptions_*.csv` for every value with its source.\n")
    L.append("## 3. Package technology comparison (baselines)\n")
    rows = []
    for k, d in bl.items():
        rows.append([k, d["power_w"], d["tj_c"], d["theta_ja_k_w"], d["compact"]["theta_jc_top_k_w"], d["compact"]["theta_jb_k_w"],
                     100 * d["heat_split"]["top_path"], d["p_max"]["planning"]["p_max_w"], d["pdn"]["worst_drop_mv"], d["pdn"]["budget_mv"],
                     cost_index(baseline_cases()[k]), stack_height_mm(baseline_cases()[k])])
    L.append(_table(rows, ["configuration", "P (W)", "Tj (degC)", "theta_JA (K/W)", "theta_JC,top* (K/W)", "theta_JB* (K/W)", "top path %",
                           "P_max @105 degC (W)", "IR drop (mV)", "IR budget (mV)", "cost index (assumed)", "stack height (mm)"]))
    L.append("\n\\* idealised two-resistor definitions (fixed temperature on the case top / ball plane, all else adiabatic) - numerical, not JESD51-14/51-8 test results.\n")
    L.append("| technology | availability for SilicaFlux today | what is missing |\n|---|---|---|")
    L.append("| A0 wire-bond QFN (reference) | closest to the prototype documents (\"QFN or small BGA\"); standard OSAT flow | pad ring + I/O cells, bond-pad layout, leadframe drawing |")
    L.append("| A lidded / bare-die FCBGA | the documented production direction (\"flip-chip BGA for the full device\") | wafer bumping of IHP dies, TopMetal2 pad/RDL plan, substrate design kit |")
    L.append("| B Si interposer / organic MCM | research only | chiplet partitioning, micro-bump assembly, interposer foundry, licensed D2D (UCIe) / HBM PHY+controller, KGD test |\n")
    L.append("## 4. Numerical verification\n")
    L.append(_table([[t["test"], "PASS" if t["passed"] else "FAIL", t["metric"], str(t["tolerance"])] for t in val["tests"]], ["test", "result", "metric", "tolerance"]))
    for c in val.get("mesh_convergence", []):
        L.append(f"\n**Mesh convergence - {c['case']}** (systematic refinement of the size field and every layer's nz; convection coefficients frozen):\n")
        L.append(_table([[r["level"], r["cells"], r["mean_rise_k"], r["tj_rise_k"], r["energy_residual_rel"]] for r in c["levels"]],
                        ["level", "cells", "mean die rise (K)", "peak rise (K)", "energy residual"]))
        L.append(f"\nObserved order {_f(c['mean_rise']['observed_order'])} (mean) / {_f(c['peak_rise']['observed_order'])} (peak); Richardson mean rise "
                 f"{_f(c['mean_rise'].get('richardson'))} K; fine-grid GCI {_f(100 * c['mean_rise']['gci_fine_rel'])} % / {_f(100 * c['peak_rise']['gci_fine_rel'])} %. "
                 "Sweeps use level 0; its discretisation error is the level-0 vs finest difference quoted in section 1.\n")
    L.append("## 5. Block power model (SilicaFlux-V, IHP SG13G2, 50 MHz, 1.2 V)\n")
    L.append("Calibration anchors are EDA-derived (flip-flop clock energy and leakage density from the OpenROAD vectorless report: 8.34 mW total, SRAM macros reported as 0 W - "
             "FloorplanLab issue A7); switched capacitance, clock-tree load, SRAM access energy, I/O loads and all workload activities are assumptions. "
             "Only the vector and tensor engines can be clock-gated (2 ICGs in the netlist); no DVFS exists (PowerClock).\n")
    if wl:
        cls = sorted({k[6:-3] for r in wl for k in r if k.startswith("class_")})
        L.append(_table([[r["workload"], r["total_w"] * 1e3, r["core_current_ma"]] + [r.get(f"class_{c}_mw", 0.0) for c in cls] for r in wl],
                        ["workload", "total (mW)", "core current (mA)"] + [f"{c} (mW)" for c in cls]))
    if wt:
        L.append("\n" + _table([[r["label"], r["power_w"] * 1e3, r["tj_rise_k"] * 1e3, r["theta_ja_k_w"], r["hottest_class"]] for r in wt if r.get("status") == "ok"],
                               ["case:workload", "P (mW)", "Tj rise (mK)", "theta_JA (K/W)", "hottest block class"]))
    L.append("\n## 6. Chip-package thermal coupling (Scenario A)\n")
    L.append("![power](../figures/power_density_A.png)\n![thermal](../figures/thermal_A_fcbga_forced_air.png)\n")
    Ta_ = A["ambient_c"]
    L.append(_table([[c, v["power_w"] * 1e3, (v["t_max_c"] - Ta_) * 1e3, (v["t_mean_pw_c"] - Ta_) * 1e3] for c, v in A["classes"].items()],
                    ["block class", "P (mW)", "max rise (mK)", "power-weighted rise (mK)"]))
    L.append(f"\nHottest point ({A['tj_location_mm'][0]:.3f}, {A['tj_location_mm'][1]:.3f}) mm (package coordinates; the die is mounted face-down, so its layout is mirrored in x). Heat paths: top {_f(100 * A['heat_split']['top_path'])} %, board {_f(100 * A['heat_split']['board_path'])} % "
             f"(forced air); still air: top {_f(100 * An['heat_split']['top_path'])} %, board {_f(100 * An['heat_split']['board_path'])} %. Energy residual {_f(A['energy_residual_rel'])}.\n")
    if sens:
        se = sens.get("spreader_efficiency", {})
        L.append("**Heat-spreader efficiency** (" + sens.get("spreader_efficiency_definition", "") + "): " +
                 "; ".join(f"{k}: " + ", ".join(f"{m} {_f(e)}" for m, e in v.items()) for k, v in se.items()) + "\n")
    def srows(study):
        return [[r["x"], r["theta_ja_k_w"], r["tj_rise_k"] * 1e3] for r in sr if r.get("study") == study and r.get("status") == "ok"]
    for st, title in (("heatsink_material", "heatsink material (forced air)"), ("die_thickness_um", "die thickness (um, forced air)"),
                      ("substrate_layers_natural", "substrate metal layers (still air)"), ("lid_thickness_mm", "lid thickness (mm, forced air)"),
                      ("lid_thickness_mm_natural", "lid thickness (mm, still air)"), ("power_concentration", "TensorCore power share (forced air, same total)"),
                      ("power_concentration_nat", "TensorCore power share (still air)")):
        rr = srows(st)
        if rr:
            L.append(f"\n*{title}*\n\n" + _table(rr, ["value", "theta_JA (K/W)", "Tj rise (mK)"]))
    L.append("\n![tim](../figures/tim_collapse.png)\n")
    L.append("## 7. Design sweeps and Pareto trade-offs\n")
    for sweep, title in (("package_size", "package body size"), ("cooling", "cooling boundary conditions"), ("ambient", "ambient"), ("bump_pitch_thermal", "bump pitch (thermal effect)")):
        rr = [r for r in sw if r.get("sweep") == sweep and r.get("status") == "ok"]
        if rr:
            L.append(f"\n*{title}*\n\n" + _table([[r["x"], r.get("cooling", ""), r["theta_ja_k_w"], r["tj_rise_k"] * 1e3, r["top_path_frac"] * 100, r["cost_index"]] for r in rr],
                                                 ["value", "cooling", "theta_JA (K/W)", "Tj rise (mK)", "top path %", "cost index"]))
    rr = [r for r in sw if r.get("sweep") == "placement" and r.get("status") == "ok"]
    if rr:
        L.append("\n*Tensor/vector placement - every valid FloorplanLab placement (EDA-derived)*\n")
        pdn_by = {r["floorplan"]: r for r in ppdn}
        L.append(_table([[r["x"], r["cooling"], r["die_area_mm2"], r["theta_ja_k_w"], (r["t_die_mean_c"] - 25.0) / r["power_w"], pdn_by.get(r["x"], {}).get("ir_drop_mv")] for r in rr],
                        ["floorplan", "cooling", "die area (mm2)", "theta_JA peak (K/W)", "mean die rise / P (K/W)", "IR drop (mV)"]))
        L.append("\nPeak theta_JA varies far more across placements than the mean die rise: with a thin die and TIM1 dominating, the hotspot follows the local "
                 "power density, so placements that concentrate logic between the SRAM macros run hotter at the same total power. Placements with logic "
                 "under the outer (signal-only) bump rings show the largest IR drop.\n")
        L.append("\n![placement](../figures/placement_sweep.png)\n")
    if bd:
        L.append("\n*Bump distribution (electrical): pitch x P/G pattern x signal rings*\n\n" +
                 _table([[r["pitch_um"], r["pattern"], r["signal_rings"], r.get("sites"), r.get("n_VDD"), r.get("n_VSS"), r.get("n_SIG"), r.get("signal_shortfall"),
                          r.get("ir_drop_mv"), r.get("max_bump_ma"), r.get("em_margin_at_max_simultaneous")] for r in bd if r.get("status") == "ok"],
                        ["pitch (um)", "pattern", "signal rings", "sites", "VDD", "VSS", "SIG", "signal shortfall", "IR (mV)", "max bump (mA)", "EM margin @ screening bound"]))
    if pa:
        fr = [r for r in pa if str(r.get("pareto")) in ("True", "1.0")]
        n3 = sum(1 for r in pa if str(r.get("pareto_3obj")) in ("True", "1.0"))
        L.append(f"\n**Scenario A Pareto set** ({len(fr)} of {len(pa)} designs non-dominated in theta_JA and assumed cost; {n3} when stack height is added as a third objective):\n\n" +
                 _table([[r["cooling"], r.get("base_mm"), r["tim1_k"], r["body_mm"], r["theta_ja_k_w"], r["cost_index"], r["stack_height_mm"]] for r in sorted(fr, key=lambda r: r["cost_index"])],
                        ["cooling", "HS base (mm)", "TIM1 k", "body (mm)", "theta_JA (K/W)", "cost index", "height (mm)"]))
        L.append("\n![pareto](../figures/pareto_A.png)\n")
    if pb:
        fr = [r for r in pb if str(r.get("pareto")) in ("True", "1.0")]
        L.append(f"\n**Scenario B Pareto set** (Tj vs assumed cost, hypothetical power):\n\n" +
                 _table([[r["cooling"], r["interposer"], r["tim1_k"], r["tj_c"], r["cost_index"]] for r in sorted(fr, key=lambda r: r["cost_index"])],
                        ["cooling", "interposer", "TIM1 k", "Tj (degC)", "cost index"]))
    L.append("\n## 8. Power delivery\n")
    for k in ("A_fcbga_forced_air", "A0_wirebond_qfn_natural", "B_si_interposer_forced_air", "B_organic_mcm_forced_air"):
        d = bl[k]["pdn"]
        L.append(f"**{k}**: load {_f(d['load_current_a'])} A, worst VDD-VSS drop {_f(d['worst_drop_mv'])} mV (budget {_f(d['budget_mv'])} mV), PDN loss {_f(d['p_loss_w'])} W; "
                 "conservation: " + ", ".join(f"{a} {_f(b)}" for a, b in d["conservation"].items()) + "; per-connection current / EM margin: " +
                 ", ".join(f"{n} {_f(x['max_per_connection_a'] * 1e3)} mA / x{_f(x['em_margin'], 3)}" for n, x in d["links"].items()) + "\n")
        L.append("  loss by element (VDD net, W): " + ", ".join(f"{a} {_f(b)}" for a, b in d["loss_by_group_w"]["VDD"].items()) + "\n")
    if md:
        et = md["electrothermal"]
        L.append(f"\n**Electrothermal coupling** (metal TCR + PDN losses as heat, constant-current loads): A dTj {_f(et['A']['delta_tj_k'])} K, B dTj {_f(et['B']['delta_tj_k'])} K "
                 f"(heat-balance check {_f(et['B']['heat_balance_check_rel'])}); exaggerated leakage what-if (0.5 W, 8 %/K, NOT a calibration) -> runaway detected: "
                 f"{et['A_leakage_what_if']['thermal_runaway_detected']}.\n")
    L.append("Decoupling: lumped ladder (VRM, bulk + MLCC, package/bump inductance from PowerLink literature ranges, assumed on-die decap). This is not an extracted model.\n")
    L.append(_table([[k, d["pdn_ac"]["step_current_a"], d["pdn_ac"]["peak_impedance_ohm"], d["pdn_ac"]["f_peak_hz"] / 1e6, d["pdn_ac"]["target_impedance_ohm"],
                      d["pdn_ac"]["first_droop_estimate_mv"], "yes" if d["pdn_ac"]["peak_impedance_ohm"] <= d["pdn_ac"]["target_impedance_ohm"] else "NO"]
                     for k, d in bl.items()],
                    ["configuration", "load step (A)", "peak Z (ohm)", "f_peak (MHz)", "target Z (ohm)", "first-droop estimate (mV)", "meets target"]))
    L.append("\nScenario B misses its target impedance by a large factor with the hypothetical decoupling set: a ~19 A chiplet rail needs on-die and "
             "package decoupling sized from an extracted PDN model before any power budget is credible.\n")
    L.append("\n## 9. Interconnect accounting\n")
    if "interconnect" in A:
        ic = A["interconnect"]
        L.append(_table([["C4 bumps", ic["bumps"]["pitch_um"], ic["bumps"]["sites_total"], ic["bumps"]["counts"]["VDD"], ic["bumps"]["counts"]["VSS"],
                          ic["bumps"]["counts"]["SIG"], ic["bumps"]["counts"]["VDDIO"] + ic["bumps"]["counts"]["VSSIO"], ic["bumps"]["signal_shortfall"]],
                         ["BGA balls", ic["balls"]["pitch_mm"] * 1000, ic["balls"]["sites_total"], ic["balls"]["counts"]["VDD"], ic["balls"]["counts"]["VSS"],
                          ic["balls"]["counts"]["SIG"], ic["balls"]["counts"]["VDDIO"] + ic["balls"]["counts"]["VSSIO"], ic["balls"]["shortfall"]]],
                        ["array", "pitch (um)", "sites", "VDD", "VSS", "signal", "VDDIO/VSSIO", "shortfall"]))
        L.append(f"\nSignals required: {ic['signals_required']} ({ic['signal_source']}). Substrate escape: {ic['substrate_escape']['traces_per_channel']} trace(s)/channel, "
                 f"{ic['substrate_escape']['layers_needed']} signal layer(s) needed of {ic['substrate_signal_layers_available']} available; PCB escape {ic['pcb_escape']['layers_needed']} layer(s). "
                 f"Method: {ic['substrate_escape']['method']}.\n")
    L.append("S-parameters: no Touchstone file exists in the repository. The interface (`sparams` command) accepts measured or externally extracted `.sNp` data and checks "
             "passivity/reciprocity; **PCIe/HBM/UCIe compliance is never inferred** from geometry or wire length.\n")
    L.append("## 10. Advanced packaging research configuration (Scenario B)\n")
    if md:
        tcp = md["thermal_coupling"]
        L.append(_table([[d] + [tcp["R_k_per_w"][i][j] for j in range(len(tcp["dies"]))] for i, d in enumerate(tcp["dies"])], ["heat in \\ peak of"] + tcp["dies"]))
        L.append(f"\nField superposition error {_f(tcp['field_superposition_max_err_k'])} K. ")
        if "allocation" in tcp:
            al = tcp["allocation"]
            L.append(f"Power allocation at Tj <= {_f(al['tj_limit_c'])} degC: uniform scaling of the nominal split -> {_f(al['uniform_total_w'])} W; LP optimum "
                     f"{_f(al['lp_unconstrained_total_w'])} W ({', '.join(_f(x) for x in al['lp_unconstrained_w'])} W); balanced (equal compute dies) "
                     f"{_f(al['lp_balanced_total_w'])} W.\n")
        for k, dd in md["d2d"].items():
            L.append(f"\n*Die-to-die capacity - {k} ({dd['medium']}, pitch {_f(dd['pitch_um'])} um, {dd['rows']} rows)*\n\n" +
                     _table([[p["die_a"], p["die_b"], p["shared_edge_mm"], p["bump_limited"], p["wiring_limited"], p["connections"], p["raw_capacity_gbps_hypothetical"]] for p in dd["pairs"]],
                            ["die A", "die B", "shared edge (mm)", "bump-limited", "wiring-limited", "connections", "raw Gb/s (hypothetical rate)"]))
            L.append(f"\n{dd['caveat']}\n")
        L.append("\n" + _table([[r["die"], r["power_w"], r["current_a"], r["pg_ubumps_available"], r["pg_ubumps_needed_50pct_em_derate"], r["ok"]] for r in md["rail_allocation"]],
                               ["die", "P (W)", "I (A)", "P/G micro-bumps available", "needed (50 % EM derate)", "ok"]))
        L.append(f"\nHBM: {md['hbm']}\n")
        L.append("![B](../figures/thermal_B_si_interposer_forced_air.png)\n")
    if tr:
        L.append("## 11. Transient behaviour\n")
        L.append(_table([[k, d["power_w"], d["t63_s"], d["t90_s"], d["t95_s"], d["t99_s"], d["tj_at_1s_frac"], d["end_vs_steady_k"]] for k, d in tr.items()],
                        ["case", "P (W)", "t63 (s)", "t90 (s)", "t95 (s)", "t99 (s)", "rise reached at 1 s", "end vs steady (K)"]))
        b = tr.get("B_si_interposer_forced_air", {}).get("burst")
        if b:
            L.append(f"\nBurst (compute dies x{b['on_scale']} for {b['on_s']} s every {b['period_s']} s, same average): Tj {_f(b['tj_min_c'])} .. {_f(b['tj_max_c'])} degC vs "
                     f"{_f(b['tj_steady_avg_power_c'])} degC steady at the average; max heating {_f(b['max_heating_rate_k_s'])} K/s.\n")
        L.append("![transient](../figures/transient_step.png)\n")
    L.append("## 12. Missing manufacturing data (required before any package decision)\n")
    L.append(_table(missing_data_table(), ["item", "source", "status in this model"]))
    L.append("\n## 13. Limitations\n")
    for s_ in ("Cooling is represented by correlation-based or declared heat-transfer coefficients; no CFD, no fan curve, no flow bypass.",
               "Composite layers (BEOL, bump/underfill, balls, substrate, board) are homogenised effective media; individual bumps/vias are not meshed.",
               "The device layer is an effective 2 um source layer; sub-micron device self-heating is not resolved.",
               "Leakage power is temperature-independent (no calibrated data); k(T) of silicon is available via Picard iteration but off by default.",
               "PDN: homogenised resistive grids, ideal vias between grid levels, constant-current loads; AC model is lumped. Not IR/EM signoff.",
               "Interconnect routing estimates use channel counting; no DRC, no via-in-pad, no signal-integrity analysis.",
               "Scenario B die sizes, block plans and power densities are placeholders; HBM and UCIe are integration targets requiring licensed IP.",
               "All results are simulations of declared inputs; none is calibrated against a measurement."):
        L.append(f"- {s_}")
    L.append("\n## 14. Reproduce\n\n```bash\npip install -r requirements.txt\npython silicaflux_package_twin.py all --workers 4\npytest -q tests\n```\n")
    p = out / "report" / "PACKAGETWIN_ENGINEERING_REPORT.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(L) + "\n")
    write_tech_comparison(out)
    return p


TECH_READINESS = {
    "A0_wirebond_qfn_natural": ("standard OSAT flow; matches the prototype documents", "pad ring + I/O cells, bond-pad plan, leadframe drawing"),
    "A_fcbga_natural": ("documented production direction; requires wafer bumping of IHP dies", "bump plan + TopMetal2 pads, UBM/solder, substrate design kit, lid BOM"),
    "A_fcbga_passive_heatsink": ("as A + off-the-shelf heatsink", "as A + heatsink vendor data"),
    "A_fcbga_forced_air": ("as A + fan airflow at system level", "as A + fan curve / system airflow"),
    "A_fcbga_cold_plate": ("as A + liquid loop (overkill for SilicaFlux-V)", "as A + cold-plate characterisation"),
    "A_bare_die_forced_air": ("as A without lid; die-edge chipping / handling risk", "as A + heatsink attach / clip force"),
    "B_si_interposer_forced_air": ("research only", "chiplet RTL partitioning, micro-bump assembly, interposer foundry, licensed D2D/UCIe PHY, KGD test"),
    "B_organic_mcm_forced_air": ("research only (coarser D2D wiring)", "chiplet partitioning, fine-line organic substrate, D2D PHY"),
    "B_si_interposer_cold_plate": ("research only", "as B + liquid cooling"),
}


def write_tech_comparison(out: Path) -> Path:
    bl = jload(out / "results" / "baselines.json")
    cases = baseline_cases()
    L = ["# Package technology comparison (generated)\n",
         "Same die, same power model and same board for every Scenario-A/A0 row (SilicaFlux-V, `mixed` workload); Scenario-B rows use the "
         "hypothetical chiplet set. All package/cooling parameters are assumptions (see `results/assumptions_*.csv`). "
         "Values are model outputs, not measurements.\n"]
    rows = []
    for k, d in bl.items():
        ic = d.get("interconnect")
        rows.append([k, d["architecture"], d["power_w"], d["theta_ja_k_w"], d["compact"]["theta_jc_top_k_w"], d["compact"]["theta_jb_k_w"],
                     100 * d["heat_split"]["board_path"], d["p_max"]["planning"]["p_max_w"], d["pdn"]["worst_drop_mv"], d["pdn_ac"]["peak_impedance_ohm"],
                     d["pdn_ac"]["target_impedance_ohm"], (ic["bumps"]["sites_total"] if ic else "-"), (ic["balls"]["sites_total"] if ic else "-"),
                     cost_index(cases[k]), stack_height_mm(cases[k])])
    L.append(_table(rows, ["configuration", "architecture", "P (W)", "theta_JA (K/W)", "theta_JC,top* (K/W)", "theta_JB* (K/W)", "board path %",
                           "P_max @105 degC (W)", "static IR (mV)", "PDN peak Z (ohm)", "target Z (ohm)", "bump sites", "ball sites",
                           "cost index (assumed)", "stack height (mm)"]))
    L.append("\n\\* idealised compact-model definitions.\n")
    L.append(_table([[k, TECH_READINESS.get(k, ("-", "-"))[0], TECH_READINESS.get(k, ("-", "-"))[1]] for k in bl], ["configuration", "availability", "missing manufacturing data"]))
    L.append("\n**Reading the table.** For SilicaFlux-V the thermal columns differ by factors of several, but every configuration keeps the die within a "
             "fraction of a kelvin of ambient at the modelled power; the discriminators are I/O count (bump/ball sites), static IR drop "
             "(area-array flip-chip vs edge-fed wire-bond), assembly availability and cost. Scenario B is where cooling and PDN impedance become limiting.\n")
    p = out / "report" / "PACKAGE_TECHNOLOGY_COMPARISON.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(L) + "\n")
    return p


def write_audit_md(audit: dict, path: Path) -> None:
    L = ["# Repository audit (generated)\n", f"Scanned `{audit['repo']}`: {audit['n_files']} files, {audit['n_zips']} zip archives (member names inspected).\n",
         _table([[a["artefact"], a["status"], "<br>".join(f"{f['path']} (sha256 {str(f['sha256'])[:12]})" for f in a["files"][:3]) or "-", a["role"]] for a in audit["artefacts"]],
                ["artefact", "status", "files", "role"]),
         f"\nCAD / layout / S-parameter files associated with SilicaFlux: {audit['n_cad_or_layout_files_silicaflux']} (package drawings: {len(audit['package_drawings_found'])}, "
         f"Touchstone: {len(audit['s_parameter_files_found'])}).\n"]
    if audit["cad_or_layout_files_silicaflux"]:
        L.append("First entries:\n")
        for c in audit["cad_or_layout_files_silicaflux"][:25]:
            L.append(f"- `{c['path']}`" + (f" in `{c['inside']}`" if c["inside"] else ""))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text("\n".join(L) + "\n")


# =============================================================================
# 21. Command-line interface
# =============================================================================
def write_default_configs(d: Path) -> List[str]:
    d = Path(d)
    d.mkdir(parents=True, exist_ok=True)
    out = []
    for name, cfg in (("scenario_A_fcbga_forced_air.json", default_config_A("forced_air_heatsink")),
                      ("scenario_A_fcbga_natural.json", default_config_A("natural")),
                      ("scenario_A_fcbga_cold_plate.json", default_config_A("cold_plate")),
                      ("scenario_A_bare_die_forced_air.json", default_config_A("forced_air_heatsink", lid=False)),
                      ("scenario_A0_wirebond_qfn_reference.json", default_config_A0()),
                      ("scenario_B_si_interposer_research.json", default_config_B(True)),
                      ("scenario_B_organic_mcm_research.json", default_config_B(False)),
                      ("scenario_B_si_interposer_hbm_whatif.json", default_config_B(True, hbm=True))):
        jdump(cfg, d / name)
        out.append(name)
    return out


def export_assumptions(out: Path) -> None:
    for key, cfg in baseline_cases().items():
        rows = collect_params(cfg)
        write_csv(out / "results" / f"assumptions_{key}.csv", rows, ["parameter", "value", "unit", "provenance", "range", "source", "note"])
    pm = PowerModel()
    write_csv(out / "results" / "assumptions_power_model.csv", collect_params(pm.d), ["parameter", "value", "unit", "provenance", "range", "source", "note"])
    mats = load_materials()
    write_csv(out / "results" / "materials.csv", [m.summary() for m in mats.values()])
    counts: Dict[str, int] = {}
    for key, cfg in baseline_cases().items():
        for r in collect_params(cfg):
            counts[r["provenance"]] = counts.get(r["provenance"], 0) + 1
    jdump({"provenance_counts_over_baselines": counts, "classes": PROV_CLASSES, "cost_index": COST_INDEX}, out / "results" / "provenance_summary.json")


def write_manifest(out: Path) -> Path:
    files = sorted(p for p in out.rglob("*") if p.is_file() and p.name != "MANIFEST.json")
    man = {"generated_by": f"silicaflux_package_twin.py {__version__}", "versions": env_versions(),
           "files": {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": sha256_file(p)} for p in files}}
    jdump(man, out / "MANIFEST.json")
    return out / "MANIFEST.json"


def cmd_all(out: Path, workers: int, quick: bool, repo: Optional[Path]) -> None:
    t0 = time.time()
    out.mkdir(parents=True, exist_ok=True)
    print("[1/10] repository audit", flush=True)
    if repo and Path(repo).exists():
        a = audit_repository(Path(repo))
        jdump(a, out / "audit" / "repo_audit.json")
        write_audit_md(a, out / "audit" / "REPO_AUDIT.md")
    print("[2/10] assumptions ledger, schemas, configs", flush=True)
    export_assumptions(out)
    write_schemas(ROOT / "schemas")
    write_default_configs(CONFIGS)
    print("[3/10] numerical verification", flush=True)
    v = run_validation(out, quick=quick)
    if not v["summary"]["all_passed"]:
        print("  VERIFICATION FAILURES - results below are not trustworthy", flush=True)
    print("[4/10] baselines (thermal + compact model + PDN + interconnect)", flush=True)
    study_baselines(out, workers)
    print("[5/10] workloads", flush=True)
    study_workloads(out, workers)
    print("[6/10] sensitivity studies", flush=True)
    study_sensitivity(out, workers)
    print("[7/10] design sweeps + Pareto", flush=True)
    study_sweeps(out, workers)
    study_pareto(out, workers)
    print("[8/10] multi-die research scenario + electrothermal + transients", flush=True)
    study_multidie(out)
    study_transients(out)
    print("[9/10] figures, 3-D explorer, report", flush=True)
    make_figures(out)
    build_viewer(out)
    write_report(out)
    pg = solve_pdn(default_config_A(), build_model(default_config_A(), workload="mixed"))
    export_powergrid(pg, out / "powergrid_export" / "A_fcbga_die_VDD")
    print("[10/10] manifest", flush=True)
    write_manifest(out)
    print(f"done in {time.time() - t0:.0f} s -> {out}", flush=True)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="silicaflux_package_twin.py", description=__doc__.split("\n")[1],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, default=OUT_DEFAULT)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("all", help="audit, verification, every study, viewer, report, manifest")
    a.add_argument("--workers", type=int, default=4)
    a.add_argument("--quick", action="store_true", help="skip package-level mesh convergence")
    a.add_argument("--repo", type=Path, default=None, help="repository checkout to audit")
    a = sub.add_parser("audit", help="scan a repository for usable artefacts")
    a.add_argument("--repo", type=Path, required=True)
    a = sub.add_parser("import-floorplanlab", help="vendor FloorplanLab per-run exports into data/floorplans")
    a.add_argument("--zip", type=Path, required=True)
    a.add_argument("--repo", type=Path, default=None)
    sub.add_parser("init-configs", help="write the default scenario configs and JSON schemas")
    a = sub.add_parser("validate", help="run the numerical verification suite")
    a.add_argument("--quick", action="store_true")
    a = sub.add_parser("run", help="solve one scenario config")
    a.add_argument("--config", type=Path, required=True)
    a.add_argument("--workload", default=None)
    a.add_argument("--level", type=int, default=0)
    a.add_argument("--pdn", action="store_true")
    a.add_argument("--nonlinear", action="store_true", help="k(T) for silicon (Picard)")
    a = sub.add_parser("study", help="run one study")
    a.add_argument("name", choices=["baselines", "workloads", "sensitivity", "sweeps", "pareto", "transients", "multidie"])
    a.add_argument("--workers", type=int, default=4)
    sub.add_parser("viewer", help="build outputs/viewer/package_explorer.html from recorded results")
    sub.add_parser("report", help="write the engineering report from recorded results")
    a = sub.add_parser("sparams", help="check a measured / extracted Touchstone file")
    a.add_argument("--file", type=Path, required=True)
    a = sub.add_parser("powergrid-import", help="validate a PowerGrid export (nodes.csv/resistors.csv)")
    a.add_argument("--dir", type=Path, required=True)
    sub.add_parser("materials", help="list and validate the material database")
    args = ap.parse_args(argv)
    out = args.out
    if args.cmd == "all":
        cmd_all(out, args.workers, args.quick, args.repo)
    elif args.cmd == "audit":
        a_ = audit_repository(args.repo)
        jdump(a_, out / "audit" / "repo_audit.json")
        write_audit_md(a_, out / "audit" / "REPO_AUDIT.md")
        print(json.dumps({x["artefact"]: x["status"] for x in a_["artefacts"]}, indent=1))
    elif args.cmd == "import-floorplanlab":
        print(import_floorplanlab(args.zip, DATA / "floorplans", args.repo))
    elif args.cmd == "init-configs":
        print(write_default_configs(CONFIGS))
        write_schemas(ROOT / "schemas")
    elif args.cmd == "validate":
        r = run_validation(out, quick=args.quick)
        print(json.dumps(r["summary"]))
        return 0 if r["summary"]["all_passed"] else 1
    elif args.cmd == "run":
        cfg = jload(args.config)
        errs = validate_against_schema(cfg, "scenario.schema.json")
        if errs and not errs[0].startswith("jsonschema not installed"):
            print("config schema errors:\n  " + "\n  ".join(errs))
            return 2
        r = strip_private(run_thermal(cfg, args.workload, args.level, nonlinear=args.nonlinear))
        r.pop("_die_map", None)
        if args.pdn:
            sol = solve_pdn(cfg, build_model(cfg, workload=args.workload or cfg.get("workload")))
            r["pdn"] = {k: v for k, v in sol.items() if not k.startswith("_") and k != "dies"}
        jdump(r, out / "runs" / f"{cfg['name']}.json")
        print(json.dumps({k: r[k] for k in ("case", "power_w", "tj_c", "theta_ja_k_w", "heat_split", "energy_residual_rel")}, default=float, indent=1))
    elif args.cmd == "study":
        fn = {"baselines": study_baselines, "workloads": study_workloads, "sensitivity": study_sensitivity, "sweeps": study_sweeps,
              "pareto": study_pareto, "transients": study_transients, "multidie": study_multidie}[args.name]
        fn(out, args.workers) if args.name not in ("transients", "multidie") else fn(out)
    elif args.cmd == "viewer":
        print(build_viewer(out))
    elif args.cmd == "report":
        make_figures(out)
        print(write_report(out))
    elif args.cmd == "sparams":
        print(json.dumps(sparam_checks(read_touchstone(args.file)), indent=1, default=float))
    elif args.cmd == "powergrid-import":
        print(json.dumps(import_powergrid(args.dir), indent=1))
    elif args.cmd == "materials":
        mats = load_materials()
        for m in mats.values():
            iss = validate_material(m)
            print(f"{m.name:24s} kx={m.kx:8.3g} kz={m.kz:8.3g} rho={m.rho:8.4g} cp={m.cp:6.4g} {m.prov:12s} {'OK' if not iss else [i.code for i in iss]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
