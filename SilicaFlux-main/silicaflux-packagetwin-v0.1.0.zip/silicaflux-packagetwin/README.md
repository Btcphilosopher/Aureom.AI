# SilicaFlux PackageTwin - 3D semiconductor package digital twin (Project 29)

**Primary source:** [`silicaflux_package_twin.py`](silicaflux_package_twin.py) - Aureom.AI / SilicaFlux-HPC

An engineering simulator and design-exploration platform for the proposed SilicaFlux package: silicon die,
die metallisation (BEOL), die-to-package interconnect (C4 bumps / micro-bumps / bond wires), underfill, package
substrate, TIM1/TIM2, heat spreader (lid), heatsink or cold plate and the PCB boundary - plus a resistive
power-delivery network, interconnect accounting, a research multi-die/interposer configuration, a numerical
verification suite, an interactive 3-D explorer and a generated engineering report.

> **Status - read first.** The die outline, SRAM macro placement, std-cell placement density, logical-group
> placement and on-die PDN straps are **EDA-derived** from FloorplanLab (OpenROAD/ORFS on IHP SG13G2, pre-CTS,
> 14 valid placements, vendored with SHA-256 provenance). Supply voltage (1.2 V) and clock target (50 MHz) are
> **specified** design inputs. Every package, interconnect, cooling, board and workload-activity value is an
> **engineering assumption**; Scenario B is **hypothetical**. **Nothing is measured** - no package drawing, bump
> plan, pad ring, S-parameter file or thermal measurement exists in the repository. The solvers are numerically
> verified; the inputs are not validated against hardware. No signoff, qualification or compliance claim is made.
> The conceptual 3-D cutaway / infographic colours are never used as data.

## Results at a glance (bundled `outputs/`, v0.1.0 run)

Full numbers, tables and figures: [`outputs/report/PACKAGETWIN_ENGINEERING_REPORT.md`](outputs/report/PACKAGETWIN_ENGINEERING_REPORT.md)
and [`outputs/report/PACKAGE_TECHNOLOGY_COMPARISON.md`](outputs/report/PACKAGE_TECHNOLOGY_COMPARISON.md).

* **Verification: 14/14 checks pass**; package mesh convergence GCI 0.10 % (A) / 0.32 % (B). Every recorded solve
  (249 sweep points, 9 baselines) conserves energy to better than 3e-8 relative (worst case set by the iterative solver tolerance).
* **SilicaFlux-V is thermally light.** The assumed `mixed` workload is 21.9 mW (18.2 mW core). In the lidded FCBGA it
  gives theta_JA 5.3 K/W with a forced-air heatsink and 21.7 K/W in still air, a 0.12 K / 0.47 K junction rise. At the same
  power shape, a 105 degC planning limit allows 15 W and 4.4 W. The package choice is driven by I/O count, power delivery,
  bumping availability and cost, not heat.
* **TIM1 is the largest package resistance** over the 8 mm2 die. All TIM1 sweeps collapse onto one line in t/k + 2R''.
  Contact resistance is the top uncertainty to measure.
* **Placement matters through TIM1.** Peak theta_JA varies by about 45 % (4.8 to 7.0 K/W) across the 14 EDA placements,
  because the hotspot follows local power density.
* **Power delivery:** static IR drop is 0.78 mV with the flip-chip area array vs 5.9 mV for the edge-fed wire-bond QFN
  (36 mV budget). The bump sweep shows a 250 um pitch needs at least 3 signal rings for the 73 signals.
* **Scenario B (hypothetical, 17.5 W):** Tj 45.9 degC with forced air. Die-to-die thermal coupling is about 1.05 K/W vs
  1.72 K/W self-heating. 3x compute bursts swing Tj between 41 and 63 degC. The lumped PDN misses its target impedance,
  so decoupling must be sized from an extracted model.

## What it does

| Area | Implementation |
|---|---|
| Geometry | Parameterised layer stack (board, BGA, substrate, bumps+underfill, BEOL, device layer, die, TIM1, lid with seal-ring foot and adiabatic cavity, TIM2, heatsink/cold plate). Composite layers are derived effective media (laminate rule-of-mixtures, Maxwell-Garnett columns) with provenance `derived`. |
| Scenarios | **A** lidded / bare-die flip-chip BGA with the real SilicaFlux-V die; **A0** wire-bond QFN reference (the prototype documents' option); **B** research: 3 chiplets on a passive Si interposer or an organic MCM, optional HBM placeholder (disabled by default). |
| Thermal solver | Cell-centred finite volume on a graded rectilinear 3-D mesh: `div(k grad T) + q = 0` and `rho cp dT/dt = div(k grad T) + q` (theta scheme, implicit Euler default, Crank-Nicolson optional), orthotropic k, interface contact resistance, Robin/Dirichlet/Neumann boundaries, optional k(T) for silicon (Picard). Direct LU for small meshes; PCG with a two-level z-line/aggregation preconditioner for package meshes. |
| Cooling | Natural convection (Churchill-Chu / horizontal-plate) + linearised radiation, plate-fin heatsinks (Teertstra forced, Bar-Cohen & Rohsenow natural, fin efficiency), liquid cold plate (declared h + coolant rise); coefficients iterated to self-consistency with surface temperatures. No CFD. |
| Heat sources | Block power model on FloorplanLab data: per-group flip-flop clock energy and leakage calibrated to the OpenROAD vectorless report, assumed switched capacitance / clock-tree load / SRAM access energy / activity tables; mapped conservatively onto the mesh (std-cell density x Gaussian attribution; macros on their EDA outlines; hypothetical pad-ring strips). Face-down mirroring applied. |
| PDN | VDD and VSS resistive networks: homogenised on-die grid (TopMetal1/Metal5/Metal1 straps from FloorplanLab), bumps, substrate planes, balls, board planes, VRM patch; constant-current loads; KCL/Tellegen/power-balance checks; lumped decoupling impedance; electrothermal coupling (metal TCR + PDN losses as heat); PowerGrid exchange (`nodes.csv`/`resistors.csv`). |
| Interconnect | Bump/ball maps with signal, VDDIO/VSS and core P/G allocation, escape-routing layer estimate, Touchstone S-parameter interface (passivity/reciprocity; compliance never inferred). |
| Advanced packaging | Thermal coupling matrix with exact superposition check, LP power allocation under a Tj limit, die-to-die connection counts (bump- vs wiring-limited), per-die rail/micro-bump allocation. |
| Studies | Workloads, sensitivities (TIM, spreader efficiency, heatsink material, package thickness, power concentration), sweeps (heatsink base, TIM, body size, bump distribution, 14 EDA placements, cooling BCs, ambient), Pareto fronts, step/burst transients. |
| Outputs | CSV/JSON results, assumptions ledger, interactive 3-D explorer (offline HTML), figures, engineering report, manifest with SHA-256. |

## Quick start

```bash
pip install -r requirements.txt
```

```bash
python silicaflux_package_twin.py all --workers 4 --repo /path/to/Aureom.AI
```

```bash
pytest -q tests
```

Other commands: `validate`, `run --config configs/<scenario>.json [--pdn] [--level N] [--nonlinear]`,
`study <baselines|workloads|sensitivity|sweeps|pareto|transients|multidie>`, `viewer`, `report`,
`audit --repo`, `import-floorplanlab --zip`, `sparams --file x.s2p`, `powergrid-import --dir`, `materials`,
`init-configs`. See `python silicaflux_package_twin.py --help`.

Open `outputs/viewer/package_explorer.html` in a browser (no network needed) and read
`outputs/report/PACKAGETWIN_ENGINEERING_REPORT.md`.

## Layout

```
silicaflux_package_twin.py   the twin: geometry, materials, mesh, FV solver, cooling, power model, PDN,
                             interconnect, multi-die, verification, studies, viewer, report, CLI
data/materials.json          material database (provenance per entry)
data/power_model.json        block power model coefficients + assumed workloads
data/floorplans/*.json       vendored FloorplanLab exports (EDA-derived, SHA-256 of source zip + member)
configs/*.json               declared scenario inputs (every physical value tagged with provenance)
schemas/*.json               JSON schemas: scenario, materials, floorplan, power map, PowerGrid exchange, S-params
tests/                       pytest suite (analytical, convergence, conservation, BCs, PDN, interconnect, repro, CLI)
docs/                        audit, architecture, assumptions, validation, limitations
outputs/                     generated results (see MANIFEST.json)
```

## Provenance classes

`measured` (none exist) - `eda_derived` - `specified` - `published` - `assumed` - `hypothetical` - `derived`.
Every value used by the baseline scenarios is listed with its class and source in
`outputs/results/assumptions_*.csv`.

## Not committed

Delivered as an archive; nothing was pushed to GitHub. No existing SilicaFlux file was modified.
