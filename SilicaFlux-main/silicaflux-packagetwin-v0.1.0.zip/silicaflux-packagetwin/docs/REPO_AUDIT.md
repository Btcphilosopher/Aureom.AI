# Repository audit - inputs available to PackageTwin

Audited checkout: `btcphilosopher/Aureom.AI` (branch `claude/youthful-thompson-u2sb41`), `SilicaFlux-main/` and the
SilicaFlux zip archives. The machine-generated inventory (file hashes, CAD/S-parameter scan of every zip's member
list) is `outputs/audit/REPO_AUDIT.md` / `repo_audit.json` (`python silicaflux_package_twin.py audit --repo <path>`).
This page records what each artefact contributes and how it is classified.

## Used as input

| Artefact | What PackageTwin takes from it | Class |
|---|---|---|
| **FloorplanLab (Project 05)** `SilicaFlux2.5/silicaflux-floorplanlab.zip` | For the 14 runs that completed with `physically_valid = true` (IHP SG13G2, OpenROAD/ORFS `ab2aaf0f`, pre-CTS): die and core outlines, 12 SRAM macro outlines (8 x RM_IHPSG13_1P_2048x64, 4 x 512x64), logical-group cell area / centroid / placement extent, 64 x 64 std-cell utilisation grid, 73 logical I/O pins and their edges, PDN strap list (Metal5 2.2 um / 75.6 um pitch vertical, TopMetal1 1.8 um / 30.24 um horizontal, Metal1 followpins), synthesis summary (95,096 cells, 4,512 flip-flops, 2 ICGs), OpenROAD vectorless power report (8.34 mW; SRAM macros reported as 0 W). Vendored to `data/floorplans/*.json` with SHA-256 of the zip and of each member. | eda_derived |
| FloorplanLab platform profile (IHP SG13G2) | VDD 1.2 V (typ corner), PDN strap widths/pitches, macro P/G pin mapping (single 1.2 V domain), missing slow/fast std-cell corners. Vendored verbatim as `data/floorplans/_ihp_sg13g2_profile.yaml`. | specified / eda_derived |
| FloorplanLab `design.yaml` | 20 ns clock period (50 MHz) - a release-1 target, not a timing result. | specified |
| SilicaFlux design documents (PDF) | "Flip-chip BGA for the full device; wire-bond package only for a reduced low-I/O prototype"; "multiple VDD/VSS bumps, perimeter rings plus dense internal mesh"; prototype targets "< 10 mm2 die, < 1 W"; "QFN or a small BGA". Used to choose the scenario set only. | specified (targets) |
| **PowerLink** `silicaflux-powerlink.zip` | Package-family literature ranges: C4 bump R/L/EM current, ball R/L/current, bond-wire and lead values, micro-bump EM current, TIM and cooler ranges. Its power numbers are **not** used (65 nm generic planning model, 2.5 mm die). | published (literature ranges) |
| **PowerClock (Project 27)** | The power manager has clock gating and throttling but **no DVFS / voltage control** -> no voltage scaling is modelled. | specified |

## Inspected, not used as numerical input

| Artefact | Finding |
|---|---|
| **ThermalLab** `SilicaFlux ThermalLab (1).zip` | A validated FV thermal solver whose every input was a placeholder (5 x 5 mm demonstration die, 2.22 W, assumed package). Its validation approach informed this solver; none of its numbers are reused. Its HotSpot disagreement (~11 % on package spreading) is noted; PackageTwin verifies spreading against an exact multilayer Fourier-series solution instead. |
| **PowerGrid (Project 08)** | **Not present** in the repository (ThermalLab and FloorplanLab already recorded it as inaccessible). PackageTwin implements the same `nodes.csv` / `resistors.csv` exchange schema in both directions. |
| ControlCore (P21), TensorCore 01-10, HPC M02-M09, DataFabric, HostLink PCIe (P25), MemoryBridge (P24), RAS (P26) | RTL with simulation/synthesis smoke tests only (SKY130 / generic). No floorplan, power report or package data. HostLink keeps PCIe behind a vendor-endpoint boundary (no PHY); MemoryBridge is verified against a simulated controller (no DDR/HBM PHY). They define Scenario B's block classes, nothing numerical. |
| TwinLab | A web front-end with no importer for FloorplanLab data. |
| Conceptual 3-D cutaway / infographic PNGs | Illustrations; their colours are never used as power-density data and the cutaway is not assumed manufacturable. |

## Not found anywhere

* Package drawing, substrate stack-up, bump plan, pad ring / I/O cells, lid or heatsink drawing, PCB layout
  (no STEP/IGES/DXF/Gerber/BRD/KiCad files associated with SilicaFlux).
* Touchstone S-parameter files or any extracted channel model.
* Thermal, electrical or mechanical measurements of any kind.
* A chip-level top (`sfv_chip`) with pads; any larger SilicaFlux top with SRAM macros; MCU-I RTL.

## Consequences

1. Scenario A uses the **real** SilicaFlux-V die (default floorplan `C_sram_near_compute`, the FloorplanLab
   "best supported trade-off"); all 14 placements are swept.
2. Everything outside the die (bumps, substrate, lid, TIMs, cooler, board) is declared with provenance and listed in
   `outputs/results/assumptions_*.csv`.
3. Scenario B (chiplets, interposer, micro-bumps, D2D, HBM placeholder) is **hypothetical** throughout.
