# Architecture and numerical methods

`silicaflux_package_twin.py` is one module organised in numbered sections:

| # | Section | Purpose |
|---|---|---|
| 1 | utilities | JSON/CSV I/O, hashing, provenance-tagged parameters `P(value, prov, source, range)`, assumptions ledger |
| 2 | materials | `Material` (orthotropic k, rho, cp, k(T) exponent, resistivity, TCR), validation, effective media (`mix_columns`, `mix_laminate`) |
| 3 | geometry | `Rect`, `Layer` (background + regions), `InterfaceRule` (contact R''), `BCRule`, `HeatSource`, `DiePlacement` (face-down mirroring), `PackageModel`, `validate_model` |
| 4 | mesh | graded rectilinear mesh: every region/BC-patch edge is a mesh line; inside each interval nodes equidistribute 1/h(x) with h = min(h_max, h_fine + growth x distance to the dies); layer nz scaled by the level |
| 5 | FV solver | assembly, boundaries, connectivity check, sources, steady (direct LU / PCG), k(T) Picard, theta-scheme transient, post-processing |
| 6 | references | slab, series stack, multilayer Fourier spreading, lumped RC, Kirchhoff k(T) slab |
| 7 | cooling | air properties, natural/forced plate correlations, radiation, plate-fin heatsink |
| 8 | audit / import | repository scan, FloorplanLab vendoring with SHA-256 |
| 9 | power model | block power model, conservative spatial attribution |
| 10-11 | scenarios / builders | default configs (A, A0, B) and config -> `PackageModel` |
| 12 | runner | `run_thermal` (h iterated to self-consistency), compact model (theta_JC/theta_JB), thermal capacity |
| 13 | interconnect | bump/ball maps, escape estimate, Touchstone I/O and checks |
| 14 | PDN | `PDNStage`/`PDNLink`/`PDNNetwork`, `build_pdn`, `solve_pdn`, `pdn_impedance` |
| 15 | coupling | electrothermal loop, PowerGrid exchange, D2D, thermal coupling + LP allocation |
| 16 | verification | 14 tests + package mesh convergence (GCI) |
| 17 | studies | baselines, workloads, sensitivity, sweeps, Pareto, transients, multi-die |
| 18 | viewer | Plotly figures in one offline HTML |
| 19-21 | schemas, report, CLI | |

## Thermal discretisation

Cell-centred finite volumes on cells (k, j, i). Face conductance between neighbours a, b along axis d:

    G = A_face / ( d_a/(2 k_a,d) + d_b/(2 k_b,d) + R''_contact )

(harmonic mean of the half-cell resistances; the contact term is applied only on the z-faces of the declared layer
interface and only where the touching materials match the rule). Boundary faces (domain edge or next to a void cell)
take the first matching `BCRule`: Robin `G = A/(d/2k + R'' + 1/h)`, Dirichlet `G = A/(d/2k + R'')`, Neumann flux
`q'' A` on the right-hand side; unmatched faces are adiabatic. The matrix is a symmetric M-matrix; every connected
component must touch a Robin/Dirichlet face (otherwise the model is rejected as ill-posed).

Steady: direct sparse LU (N <= 15k) or PCG with a symmetric two-level preconditioner: z-line block Jacobi (one
tridiagonal LAPACK solve per vertical column - the stiff direction in thin layered stacks) plus a Galerkin coarse
correction on 3 x 3-column x layer aggregates; falls back to LU if PCG fails. Transient:
`(C/dt + theta A) T^{n+1} = (C/dt - (1-theta) A) T^n + q + b`, LU factorised once per time-step size for meshes up to
60k cells. A per-step discrete energy balance is evaluated. Implicit Euler (theta = 1) is the default because
Crank-Nicolson rings on abrupt power steps of the stiff die/TIM mode.

## Power mapping

Every source (rectangle or binned grid) is integrated exactly over mesh cells with interval-overlap matrices, so the
mapped power equals the input to round-off; any part that falls on a void cell is reported and renormalised onto the
active part. Flip-chip dies are mirrored about their vertical centre line (layout viewed from the package top).

## PDN

Each net is a resistive graph: 2-D sheet stages (on-die grid, interposer RDL, substrate plane, board plane) with
node-centred cells (G = (h_perp/h_par)/R_s) joined by vertical links (bumps, micro-bumps, C4+TSV, balls, bond wires);
the VRM is an ideal source on its output-capacitor patch. Loads are constant-current sinks (VDD) and sources (VSS)
mapped conservatively from the block power map; the supply at the load is V(VDD) - V(VSS). Checked: KCL residual,
current balance, power balance (supply = load + I^2R), Tellegen's theorem. Temperature enters through metal TCR; PDN
losses are re-deposited as heat in the layer where they occur.

## Cooling

Natural convection coefficients depend on dT^1/4; `run_thermal` iterates h with the solved surface temperatures until
they change < 1 %. Plate-fin heatsinks become an effective h on the base footprint (fin efficiency included) and the fin
mass is added as heat capacity to the base. Liquid cold plates use a declared h_eff and the mean coolant temperature.
