# Numerical verification

Run with `python silicaflux_package_twin.py validate` (results: `outputs/validation/validation.json`) or
`pytest -q tests`. Each check targets one property of the solver; together they cover the brief's list
(1-D slab vs analytical, mesh convergence, energy conservation, steady/transient consistency, positive material
parameters, boundary-condition handling, PDN conservation laws).

| Test | Property | Reference |
|---|---|---|
| 1-D slab, flux / fixed T | linear conduction exact on any mesh | dT = q L / k |
| multilayer slab with contacts + convection | interface contact resistance, Robin boundary | series resistance network |
| volumetric generation | second-order convergence | parabola T = g z (L - z) / 2k |
| 3-D manufactured solution, orthotropic k | 3-D anisotropic operator, Dirichlet boundaries, observed order ~2 | sin x sin y sin z |
| multilayer orthotropic spreading, 2 eccentric sources | lateral spreading, anisotropy, contact R, convection, monotone convergence | exact Fourier series (multilayer impedance recursion) |
| energy conservation, random models | discrete conservation with random materials/BCs/contacts | sum of boundary heat = sum of sources |
| transient temporal order | implicit Euler order 1, Crank-Nicolson order 2; lumped limit | exact ODE / lumped capacitance |
| steady / transient consistency | t >> tau transient equals steady solve; per-step energy balance | steady solution |
| k(T) slab | Picard iteration for temperature-dependent silicon | Kirchhoff transform |
| boundary handling | Robin -> Dirichlet limit, mirror symmetry, rejection of all-adiabatic / negative h / negative R'' / floating island | - |
| non-physical configuration flags | k <= 0, rho = 0, k > diamond, NaN, bump >= pitch, die > body, negative TIM k | - |
| power mapping | mapped = input for every floorplan x workload; face-down mirror | - |
| PDN laws | analytical strip, N parallel bumps = R/N, reciprocity, KCL, current & power balance, Tellegen on A/A0/B | - |
| Touchstone | round trip, passivity, reciprocity of a synthetic RLGC fixture | exact line ABCD |

Package-level mesh convergence (Scenario A and B): three systematically refined meshes (whole size field and every
layer's nz scaled by r ~ 1.4), convection coefficients frozen, Celik et al. (2008) observed order with unequal ratios,
Richardson extrapolation and fine-grid GCI (Fs = 1.25) on the power-weighted mean die rise and the peak rise.
Sweeps run on level 0; its difference to the finest level is reported as the sweep discretisation uncertainty.

Not covered: comparison with measurements (none exist), CFD, commercial FEA cross-check.
