# Assumptions and limitations

The complete, machine-generated list of every parameter used by every baseline scenario - value, unit, provenance
class, range and source - is in `outputs/results/assumptions_<scenario>.csv` and
`outputs/results/assumptions_power_model.csv`. The items below dominate the uncertainty.

## Dominant assumptions (Scenario A)

| Assumption | Value | Why it matters | How to replace |
|---|---|---|---|
| TIM1 contact resistance per interface | 5 mm2 K/W (1-20) | TIM1 is the largest package resistance over an 8 mm2 die | ASTM D5470 / transient interface measurement |
| TIM1 bulk k and bond line | 3 W/mK, 50 um | as above | TIM datasheet + assembly bond-line control |
| Flip-chip on IHP SG13G2 | C4 200 um pitch, wafer bumping by a third party | IHP MPW dies are not delivered bumped; no TopMetal2 pad/RDL plan exists | bumping-house design rules, pad layout |
| Substrate | 10 mm FCBGA, 4 metal layers, 15 um Cu, 400 um core | board path and routing | OSAT design kit |
| Cooling | 40 x 40 mm Al heatsink, 14 fins, 2 m/s (no bypass, no fan curve) | top-path resistance | vendor curves or CFD + wind tunnel |
| Board | JESD51-7 2s2p, 1 % via fraction under the package | board path (dominant in still air) | system PCB stack-up |
| Workload activities | tables in `data/power_model.json` | absolute power (shape mostly set by EDA placement) | SAIF/VCD from gate-level simulation |
| SRAM access energy | 20 pJ (2048x64), 12 pJ (512x64) | SRAM share of power | IHP SRAM liberty power tables |
| Clock tree | 12 fF per flip-flop sink | clock power | CTS run |
| Hypothetical pad ring | 3.3 V, 10 pF loads | I/O power on the die edge | real I/O library + board loads |

Scenario B parameters are all `hypothetical`.

## Limitations

* No CFD; convection is correlation-based. No flow bypass, no fan curve, no system airflow interaction.
* Homogenised layers (BEOL, bump/underfill, balls, substrate, board, TSV interposer); individual bumps, vias, traces and
  fins are not meshed.
* The device layer is an effective 2 um source layer; transistor-level self-heating is not resolved.
* Leakage is temperature-independent (no calibrated leakage-vs-T data); k(T) for silicon is available but off by default.
* PDN: resistive, homogenised, ideal inter-level vias, constant-current loads; AC model is a lumped ladder with literature
  inductances. Not IR/EM signoff and not an electromagnetic extraction.
* Interconnect routing capacity is an escape-channel count; no DRC, no SI. No high-speed compliance is ever inferred.
* Compact-model parameters (theta_JC, theta_JB) use idealised boundary conditions, not JESD51-14 / JESD51-8 test methods.
* Cost index is an assumed relative scale for ranking only.
* No result is calibrated against a measurement; the model is numerically verified, not experimentally validated.
