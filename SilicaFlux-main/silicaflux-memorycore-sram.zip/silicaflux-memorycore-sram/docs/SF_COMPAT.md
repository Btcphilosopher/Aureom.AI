# SF_COMPAT - Silica Flux (`.sf`) files and the legacy `memory_controller.sf`

## 1. `.sf` is treated as a repository-specific source format - and checked, not assumed

Every `.sf` RTL file in the audited repository carries the header `Language : Silica Flux-2017`. `sf_compat/sf2sv.py` makes the claim "these files are plain SystemVerilog" checkable:

```
python3 sf_compat/sf2sv.py --check <files.sf>...          # header marker, dialect-extension markers, package imports that nothing defines
python3 sf_compat/sf2sv.py <files.sf>... --out <dir>      # byte-identical .sv copies, verified with SHA-256
```

* **Result of the audit (`docs/AUDIT.md`, `reports/audit.json`):** Verilator 5.020 accepts the `.sf` bytes unchanged. `sf2sv.py --check` over all 33 `.sf` files of `SilicaFlux-main/` (22 carry the header) found **0** lines that start with a Silica-Flux-looking keyword (`fn`, `let`, `impl`, `stage`, `pipeline`, `#[...]`). That scan is a heuristic; the stronger evidence is that Verilator parses the units listed in `docs/AUDIT.md` with 0 errors. Failures are *missing definitions* (a package type that is not in the repository) or *tool limits* (Icarus 12: no concurrent assertions; Yosys 0.33: multi-dimensional packed typedefs; Verilator 5.020: `##` ranges in assertions).
* **Therefore the transformation `.sf` -> `.sv` is the identity on the bytes plus a changed extension.** `sf2sv.py` asserts byte equality (SHA-256) on every copy. If a future file does use a real dialect construct, `--check` reports it and no silent rewriting happens.
* `.sfx` files are assembly program sources, not RTL; they are reported and skipped.
* **Name collision:** two *different* packages are both called `silicaflux_pkg` (`silicaflux_pkg.sf`, 2081 lines, core architecture; `silicaflux_pkg (1).sf`, 136 lines, memory-subsystem types). `sf2sv.py` warns about it; `memory_controller.sf` needs the 136-line one.
* The new RTL in `rtl/` is plain `.sv` and has **no dependency** on either package (flat ports, `include`d defines only), so it is not affected by the collision.

## 2. The legacy `memory_controller.sf`: status

| question | answer |
|---|---|
| parses as SystemVerilog? | **yes** (Verilator, with the 136-line package; 0 errors, 1 warning) |
| elaborates in Icarus / Yosys 0.33? | **no** (Icarus: concurrent assertions; Yosys: multi-dimensional packed typedef in the package) |
| shipped testbench `tb_memory_controller.sf` runs? | **no** - it connects 49 pins that do not exist on the shipped controller (stale TB) |
| functionally correct as shipped? | **NOT VERIFIED - observed failing.** `sf_compat/tb_legacy_mc.sv` (new, independent reference model + the new controller driven by the same operations) found 1512 of 1516 operations answered with an exception where success is expected (`reports/legacy_mc.log`) |
| fixable by the index patch (`sf_compat/patch_waddr.py`)? | **no.** The patch removes the one suspicious construct (a `[31:2]` vector sliced with byte-address bit numbers) but the failure remained. The root cause was **not found**; whether it is a Verilator limitation or a source defect could not be decided with one tool |

**Consequence:** the legacy controller is kept as a reference only; the memory path that is verified in this repository is `sf_sram_controller`. No compatibility is claimed beyond what the table says.

## 3. Mapping from the legacy interface to the new controller (design intent, tested only through the model)

`tb_legacy_mc.sv` encodes the intended mapping and drives both controllers with it (same capacity, 4 banks x 64 lines x 16 B):

* legacy `paddr = | tag | row | bank | lane | byte |` with `SPM_BASE = 0x1000_0000` -> new byte address `addr = paddr - SPM_BASE` (the same line interleave: consecutive 16 B lines rotate through the banks);
* legacy 32-bit scalar word with byte strobes -> byte lanes of the 16 B line (strobes shifted to the lane);
* legacy 128-bit vector with 4-lane masks -> byte lanes `4k .. 4k+3`;
* legacy scalar / vector *domains* (`STRICT_DOMAINS`) and burst DMA have no direct counterpart in `sf_sram_controller`; they are provided one layer up by `sf_vector_scratchpad` (sub-word accesses, alignment rule, DMA).

Because the legacy controller fails its own cross-check, the "legacy vs new" comparison cannot be used to prove equivalence; the new controller's checks stand on the independent reference model in `tb/tb_sram_controller.sv`.
