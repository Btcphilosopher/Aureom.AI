# MBIST - March test, fault models and MEASURED coverage

> Coverage numbers below are measured by simulating **behavioural fault models** (`sf_sram_core`, `FAULT_INJECT=1`) of the classic memory fault *classes*.
> They say how well the March algorithm detects those models. They are **not** silicon fault coverage, **not** a defect-level or DPPM claim, and
> this design has **no repair capability** (no spare rows / columns, no fuse or soft-repair logic). Detection only.

## 1. Structure

| piece | file | origin |
|---|---|---|
| March engine: March C- (10N) and MATS+ (5N), solid and checkerboard backgrounds | `third_party/sramlib_mbist/sram_mbist_march.sv` | reused **byte-identical** from the SRAM library project |
| in-system sequencer: quiesce -> run one bank at a time -> re-initialise -> done | `rtl/sf_sram_mbist_ctl.sv` | new |
| memory-side raw test port on every bank (tests the STORED word: data **and** ECC check bits) | `rtl/sf_sram_bank.sv` (`tst_*`) | new |
| fault models (SAF, TF, address-decoder none/alias/multi-access, CFin, CFid, CFst, one-shot SEU) | `rtl/sf_sram_core.sv` | new, simulation-only |
| coverage campaign + testbench | `sim/run_mbist_cov.py`, `tb/tb_mbist_cov.sv` | new |

Sequence: `start_i` -> **QUIESCE** (the controller stops accepting requests and reports idle for two consecutive cycles) -> **RUN** (banks tested one after another, bounded test power; the
test bus owns every bank array while it runs) -> **REINIT** (MBIST is destructive: arrays hold the test background and, with ECC, raw patterns with arbitrary check bits; the init engine rewrites zero lines with valid ECC) -> **DONE**.

March C- : `{B(w0); U(r0,w1); U(r1,w0); D(r0,w1); D(r1,w0); B(r0)}`.

## 2. Measured coverage (`reports/mbist_coverage.md`, `.json`)

A fault is counted as detected when either data background (solid / checkerboard) flags it (union). Every run also performs isolation checks (`isolation_checks=` in the RESULT line):
a fault injected in one cell must not disturb any other location, so the measurement cannot pass because of a model artefact.

| algorithm / instance | fault population | cell faults (SAF0/1, TF up/down, AF) | coupling, different word | coupling, same word |
|---|---|---:|---:|---:|
| March C-, 2 banks x 4 rows x 32 b, **exhaustive** (every pair) | 540 / 122,880 / 39,680 | **100 %** (540/540) | **100 %** (122,880/122,880) | **80.65 %** (32,000/39,680) |
| MATS+ same instance | same | 100 % | 72.50 % (89,088/122,880) | 65.48 % (25,984/39,680) |
| March C-, SECDED bank, stored word 39 b (7 check bits), exhaustive | 652 / 182,520 / 59,280 | 100 % | 100 % | 80.51 % |
| March C-, 16 rows x 128 b, 4000 random coupling pairs per class | sampled | 100 % (8,688) | 100 % (37,310) | 82.30 % (2,214/2,690) |
| March C-, `READ_LATENCY = 3` (compare pipeline), 2000 pairs/class | sampled | 100 % | 100 % | 80.23 % |

**The honest limitation:** four same-word coupling classes (idempotent `CFid_up_f1`, `CFid_down_f0` and state `CFst_a0_v0`, `CFst_a1_v1`) are detected only ~51 % of the time. With only the two
data backgrounds the reused engine offers (solid, checkerboard), a pair of cells inside one word is never driven to every needed (aggressor, victim) combination. More data backgrounds would
raise it; they are **not** implemented here. MATS+ is a weaker test and is reported only for comparison.

Faults that are **not** modelled (so nothing is claimed about them): retention / data-retention faults (no pause element), read-disturb, write-recovery, bit-line / sense-amp
faults, neighbourhood pattern-sensitive faults, multi-cell faults, resistive defects, timing (at-speed) faults, soft-error behaviour of the test logic itself.

## 3. How to reproduce

```
python3 sim/run_mbist_cov.py            # builds the 5 campaigns with Verilator, writes reports/mbist_coverage.{json,md}
```

## 4. Integration notes

* The controller input `quiesce_i` and output `idle_o` exist for this sequencer; `init_start_i` / `init_busy_o` are the re-initialisation handshake.
* MBIST of a bank with ECC tests the 137-bit stored word including the 9 check/parity columns. The ECC decoder is bypassed on the test bus.
* A failing bank is **reported** (`fail_o`, per-bank `fail_mask_o`, first-fail row / March element / syndrome and a 16-bit fail count); there is no automatic disable or repair.
