# KNOWN LIMITATIONS

Read this before relying on anything in the package. Items are ordered by how much they could mislead.

## Not claimed / not done

1. **No silicon data of any kind.** No fabricated, characterised or measured SRAM exists in this repository. Every number is RTL-simulation output, a model result or an assumed parameter, and is labelled so.
2. **Not ASIC-ready.** For the SKY130 / IHP / GF180 macro families the repository holds geometry and port data only: no functional vendor model, SPICE, Liberty, LEF or GDS (`physical/asic_readiness.md`). The SKY130 backend runs against a **labelled stand-in model** (`sim_models/sky130_sram_standin.sv`), which proves structure only. FPGA block-RAM inference is not ASIC evidence.
3. **OpenROAD was not run** (not available here). The scripts in `physical/openroad/` are unexecuted templates; floorplans are generated geometry from manifest dimensions with assumed halo / channel / margin parameters. No DRC, LVS, timing, power or IR result exists.
4. **Power and energy are models with assumed parameters** (`power/params_assumed.json`). Only the parameter-free relations (access counts, 2-access ECC partial write, 4x energy per useful byte for 4 B loads) are independent of the assumptions. Leakage cannot be assessed.
5. **SPICE / TCAD research is uncalibrated** (generic hand-written device model, ngspice-42). Trends only; no absolute value may be quoted.
6. **No repair.** MBIST detects and reports; there are no spare rows / columns, no fuse or soft repair, no automatic bank disable.
7. **Formal results are bounded** (BMC to a fixed depth on small configurations, `formal/`, `docs/VERIFICATION.md`). They are not unbounded proofs and do not cover large depths / widths. The `ecc` configuration did **not** reach its requested depth (frame 14 of 20 in 1500 s, no counterexample), so less is claimed for it than for the others.
8. **No top-level integration module.** The pieces (controller, DataFabric adapter, vector / tensor scratchpads, MBIST sequencer) are verified in their own testbenches (the DataFabric adapter behind the real NoC; the scratchpads on top of the controller). A single `sf_memorycore_top` that instantiates all of them together was not written, so the combination is not synthesized or simulated as one design.

## Behavioural limits of the design

9. **No coherence, no locks, no atomic read-modify-write operations, no multi-line atomicity** (`docs/CONTRACT.md` O4/O5). Cross-master visibility is through the write response only.
10. **ECC is SECDED.** 1-bit errors are corrected, 2-bit errors detected; **3-bit errors may be silently miscorrected** (measured in `tb_ecc_system` E8: 243 of 300 triple-error words miscorrected, 57 flagged). No DEC-TED, no interleaving.
11. **ECC partial writes are expensive** (read-modify-write, bank busy `READ_LATENCY + 1` cycles) and a partial write onto an uncorrectable line is aborted.
12. **MBIST coverage is incomplete for same-word coupling faults** (about 51 % for four fault classes with the two data backgrounds available; 80.65 % overall for March C- in the exhaustive instance). Retention, read-disturb, at-speed and neighbourhood faults are not modelled. Coverage is of *fault models*, not of silicon defects.
13. **ARB = FIXED can starve** lower-priority masters (documented, demonstrated in benchmark E).
14. **The array is never reset.** After power-up the contents are undefined; ECC builds (or `INIT_ON_RESET = 1`) initialise explicitly. Non-ECC users must initialise before reading.
15. **ASIC backend:** the OpenRAM macro output is not held, so `READ_LATENCY >= 2` is required; SKY130 only; lanes must be a multiple of 8 bits.
16. **No sub-line array access.** A 4 B load costs a whole 16 B bank access (4x bank time and energy per useful byte).

## Legacy code and audit

17. **The legacy `memory_controller.sf` fails** a cross-check against an independent reference model (1512 of 1516 operations answered with an exception; root cause not found; an index patch did not help) - `docs/SF_COMPAT.md`. It is kept as a reference, not as a working controller. Its shipped testbench is stale (49 missing pins).
18. Several legacy `.sf` / `.sv` units cannot be tested with the available tools (Icarus 12: no concurrent assertions; Yosys 0.33: multi-dimensional packed typedefs; Verilator 5.020: `##` ranges, `automatic` in the cache TBs); this is a tool limit, not a verdict on the code.
19. Two different packages are named `silicaflux_pkg`; units that import it must be compiled with the right one (`docs/AUDIT.md`). Missing type definitions block several `.sf` units (`noc_interconnect`, `compute_tile`, ...).

## Tool and method caveats

20. All simulation is Verilator 5.020 (two-state). X-propagation behaviour is not exercised; `SIM_INIT = 2` fills arrays with a poison pattern instead. Verilator 5.020 bugs shaped the testbenches (queues of queues, `fork`/`join`, reserved identifiers) - see `docs/VERIFICATION.md`.
21. Mutation testing uses a hand-written mutant list (`tools/mutate.py`); a surviving or missing mutant says something about the tests, a full kill count says nothing about faults nobody thought to inject.
22. The sramlab cycle model was derived from the RTL and then compared with RTL runs; agreement shows consistency between two descriptions of the same design, not that the design is "right". Starvation points with a throttled DMA exist only in the model (no RTL run with a slower DMA).
23. Benchmarks A-J are single-seed unless a seed sweep is stated; random-pattern results carry sampling noise (seed sweep rows in `reports/bench_rtl.csv`).
24. `cycles_per_tile` printed by the tensor testbench includes start-up and the last drain; the steady-state period is lower (derived in `reports/sramlab_vs_rtl.md`).
25. The formal runs and most mutation runs were executed before the last edit of `rtl/sf_sram_controller.sv`, which changed **comments only** (header text about `m_req_ready` and `perf_conf`); the regression suites, synthesis and benchmark runs were repeated after it.
