# PHYSICAL and POWER - what exists, what is a model, what is missing

> **Not ASIC-ready.** The repository contains geometry numbers for the SRAM macros (width, height, area, pin counts) and port/behaviour descriptions, but **no** functional vendor model, SPICE netlist,
> Liberty timing/power, LEF abstract or GDS layout of any of the three macro families used (`physical/asic_readiness.md`, scan results of `physical/check_asic_collateral.py`).
> No OpenROAD run was executed (the tool is not available in this environment). No DRC, LVS, timing, power or IR-drop result exists.

## 1. Floorplans (`physical/`)

Labels: **GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT**. Macro width / height / area are manifest fields; halo, channels, die margin, macro gap and the logic reserve are
**assumptions** (labelled in every file).

* Configurations: **C1** 4 x 1024 x 128 b (64 KiB), **C2** 4 x 1024 x 137 b (SECDED stored word), **C3** 4 x 4096 x 128 b (256 KiB), each for **SKY130** OpenRAM 1RW1R, **IHP SG13G2** 1P, **GF180MCU** 1RW = 9 floorplans (`floorplan_*.json`, SVG in `physical/svg/`).
* Results table, notable findings and reproduction commands: `physical/README.md`, `physical/area_report.md`. Highlights: the 137-bit ECC word wastes provisioned bits in a uniform tiling (bit utilisation 85.6 % SKY130/IHP, 95.1 % GF180); SKY130 1RW1R macros leave one read port idle in every instance; GF180 at 256 KiB needs 512 instances and is impractical.
* An independent legality checker (`physical/check_floorplan.py`) recomputes areas and checks overlaps / margins. It checks geometry, **not** manufacturability.
* `physical/openroad/` holds OpenROAD scripts. They were **not executed**; they are templates driven by the generated geometry.
* `physical/dashboard_floorplan.json` feeds the macro-placement panel of the dashboard.
* Conceptual vs generated: block diagrams in `docs/` are conceptual; `physical/svg/*` and `floorplan_*.json` are generated from manifests.

## 2. SPICE / TCAD research (`research/spice/`)

> **RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA.** ngspice-42 with a hand-written generic device model (`models/generic_45nm_illustrative.lib`, not calibrated to any process).
> Only trends and ratios carry information; no absolute mV / uA / ps value may be quoted as a process value. Transistor netlists are **not** synthesizable RTL and are kept apart from `rtl/`.

Experiments: 6T cell, static noise margins (hold / read / write), read-disturb, write margin, latch sense amplifier, supply-voltage sensitivity, threshold-mismatch Monte Carlo. See `research/spice/README.md` for the run commands, limitations and result index.

## 3. Power and energy (`power/`, `reports/sramlab_energy.md`)

* `power/params_assumed.json` is the **only** place with assumed numbers; each carries the comment "ASSUMPTION - not from any process; replace with Liberty / characterised values".
* Energy results are **ASSUMED-PARAMETER x MODEL**: access counts come from the cycle model that reproduces the RTL benchmark rows exactly (119 / 119 rows, `reports/sramlab_vs_rtl.md`); the pJ per access come from the assumed parameters. They are never presented as measurements.
* Parameter-free / bracketed conclusions (hold for any parameter values): an ECC partial write costs 2 array accesses instead of 1 (bank busy `RL + 1` cycles); a 4 B scalar load costs exactly 4x the energy per useful byte of a 16 B line load because the RTL has no sub-line array access; double vs single buffering has identical dynamic energy per MAC; bank conflicts cost run time, not dynamic energy.
* Leakage: at most 2.5 % of the energy of saturated traffic across the swept range, but it would equal dynamic energy only at ~157x the assumed value - **nothing real can be said about leakage**.
* Thermal hand-off: `power/thermal_input_example.json` is written in the per-block-power schema documented by the ThermalLab archive (bank rectangles from `physical/floorplan_C1_sky130.json`). ThermalLab was **not executed**; this is a format-level hand-off, not a co-simulation.

## 4. What is needed for an ASIC flow (not done)

Per macro: functional model, SPICE/CDL, Liberty (per PVT corner), LEF, GDS, process/DRC deck; then a real OpenROAD (or equivalent) run with those views, timing sign-off, power-grid / IR analysis, DRC/LVS. The wrapper `sf_sram_macro_wrapper` and the floorplan generator are structured so that these views can be plugged in; **FPGA block-RAM inference or a stand-in simulation model is never evidence of ASIC readiness.**
