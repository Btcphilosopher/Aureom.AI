# BENCHMARKS (RTL-SIMULATION, reproducible)

Source: `reports/bench_rtl.json` produced by `benchmarks/run_bench.py` with Verilator 5.020 2024-01-01 rev (Debian 5.020-1); 1000 requests per master; `benchmarks/run_bench.py`. Every row is a Verilator run of `tb/tb_bench_ctrl.sv` / `tb/tb_tensor_scratchpad.sv` / `tb/tb_vector_scratchpad.sv` on the RTL; the workload is a pure function of (pattern, master, index, seed) with xorshift32, so the Python cycle model in `tools/sramlab` reproduces the identical address stream. **These are simulation results, not silicon measurements.** ANALYTICAL ceilings come from `tools/sramlab/analytic.py`.

Cycle convention: `cycles` = (cycle of the last response acceptance) - (cycle of the first presentation); `throughput_Bpc` = useful bytes / cycles; latency = presentation edge -> response acceptance edge. Base configuration: 4 masters, 4 banks, 256 rows/bank, 128-bit lines, `READ_LATENCY=1`, `NSLOT=8`, round-robin.

## A-F, base configuration: bandwidth, conflicts, latency

| # | pattern | experiment | RTL B/cycle | ANALYTICAL ceiling | RTL/ceiling | bank-conflict cycles | mean latency | max latency |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | SEQ_SCALAR4 | A scalar 4 B loads (line-aligned) | 15.97 | 16.00 | 99.8 % | 0 | 3.00 | 3 |
| 1 | SEQ_LINE | B wide 16 B vector loads | 63.68 | 64.00 | 99.5 % | 3 | 3.00 | 6 |
| 2 | OWN_BANK | D one bank per master | 63.87 | 64.00 | 99.8 % | 0 | 3.00 | 3 |
| 3 | SAME_BANK | E single-bank contention | 15.99 | 16.00 | 100.0 % | 3999 | 6.00 | 6 |
| 4 | RANDOM_LINE | F random lines (reads) | 41.29 | 41.94 | 98.5 % | 1631 | 3.53 | 6 |
| 5 | RANDOM_RW | F random read/write | 41.72 | 41.94 | 99.5 % | 1634 | 3.52 | 6 |
| 6 | SEQ_WRITE_FULL | full-line writes | 63.68 | 64.00 | 99.5 % | 3 | 3.00 | 6 |
| 7 | SEQ_WRITE_PART4 | 4 B partial writes (no ECC: byte-masked) | 15.92 | 16.00 | 99.5 % | 3 | 3.00 | 6 |
| 8 | RANDOM_PART4 | F random 4 B partial + reads | 10.43 | 10.48 | 99.5 % | 1634 | 3.52 | 6 |

Peak = 4 banks x 16 B = 64 B/cycle. A 4 B scalar load uses a whole 16 B line access, so benchmark A is limited to NB x 4 B = 16 B/cycle (25 % of the vector peak). Random traffic saturates below the peak because of head-of-line blocking (the exact analytical chain reproduces the Karol 1987 limits). *History:* the first revision of pattern 0 issued byte-strided sub-line addresses that the ALIGN_MODE=1 controller rejected for 3 of 4 requests, so its 15.92 B/cycle credited rejected requests; the model validation found this and the TB now issues line-aligned loads (`docs/KNOWN_LIMITATIONS.md`, `reports/sramlab_vs_rtl.md`).

## E - arbitration: round robin vs fixed priority (single-bank contention, pattern 3)

| arbitration | B/cycle | conflict cycles | mean latency | max latency |
|---|---:|---:|---:|---:|
| round robin | 15.99 | 3999 | 6.00 | 6 |
| fixed priority | 15.99 | 3000 | 4.50 | 3003 |

## C / I - tensor tile pipeline (single vs double buffering, bank skew)

| config | NBUF | SKEW | NB | N | tiles | RL | ECC | total cycles | cycles/tile* | overlap cycles | conflict cycles |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| nbuf2_skew1 | 2 | 1 | 4 | 8 | 8 | 1 | 0 | 629 | 78 | 321 | 62 |
| nbuf1_skew1 | 1 | 1 | 4 | 8 | 8 | 1 | 0 | 909 | 113 | 0 | 0 |
| nbuf2_skew0 | 2 | 0 | 4 | 8 | 8 | 1 | 0 | 662 | 82 | 349 | 114 |
| nbuf1_skew0 | 1 | 0 | 4 | 8 | 8 | 1 | 0 | 957 | 119 | 0 | 48 |
| nbuf2_extra16 | 2 | 1 | 4 | 8 | 8 | 1 | 0 | 1001 | 125 | 296 | 25 |
| nbuf1_extra16 | 1 | 1 | 4 | 8 | 8 | 1 | 0 | 1293 | 161 | 0 | 0 |
| nbuf2_extra48 | 2 | 1 | 4 | 8 | 8 | 1 | 0 | 1769 | 221 | 296 | 25 |
| nbuf1_extra48 | 1 | 1 | 4 | 8 | 8 | 1 | 0 | 2061 | 257 | 0 | 0 |
| nbuf2_ecc | 2 | 1 | 4 | 8 | 8 | 1 | 1 | 681 | 85 | 335 | 64 |
| nbuf2_n16 | 2 | 1 | 4 | 16 | 8 | 1 | 0 | 1047 | 130 | 578 | 97 |
| nbuf1_n16 | 1 | 1 | 4 | 16 | 8 | 1 | 0 | 1549 | 193 | 0 | 0 |

\* `cycles/tile` = total cycles / tiles, so it includes pipeline start-up and the last drain; it is not the steady-state period (derived in `reports/sramlab_vs_rtl.md`). `overlap cycles` counts cycles in which DMA and TensorCore were both active.

## G - DMA burst vs vector traffic on shared banks

| experiment | beats | cycles alone | cycles with vector traffic | DMA/vector bank conflicts |
|---|---:|---:|---:|---:|
| mixed DMA LOAD and vector traffic on shared banks | 64 | 69 | 70 | 15 |

## H - ECC overhead (ECC / no-ECC, same workload)

| READ_LATENCY | pattern | B/cycle no ECC | B/cycle ECC | ratio | mean latency |
|---|---:|---:|---:|---:|---:|
| 1 | SEQ_SCALAR4 | 15.97 | 15.95 | 0.999 | 3.00 -> 4.00 |
| 1 | SEQ_LINE | 63.68 | 63.62 | 0.999 | 3.00 -> 4.00 |
| 1 | OWN_BANK | 63.87 | 63.81 | 0.999 | 3.00 -> 4.00 |
| 1 | SAME_BANK | 15.99 | 15.99 | 1.000 | 6.00 -> 7.00 |
| 1 | RANDOM_LINE | 41.29 | 41.26 | 0.999 | 3.53 -> 4.53 |
| 1 | RANDOM_RW | 41.72 | 41.69 | 0.999 | 3.52 -> 4.52 |
| 1 | SEQ_WRITE_FULL | 63.68 | 63.62 | 0.999 | 3.00 -> 4.00 |
| 1 | SEQ_WRITE_PART4 | 15.92 | 7.98 | 0.501 | 3.00 -> 5.00 |
| 1 | RANDOM_PART4 | 10.43 | 7.22 | 0.692 | 3.52 -> 5.18 |
| 2 | SEQ_SCALAR4 | 15.95 | 15.94 | 0.999 | 4.00 -> 5.00 |
| 2 | SEQ_LINE | 63.62 | 63.56 | 0.999 | 4.00 -> 5.00 |
| 2 | OWN_BANK | 63.81 | 63.74 | 0.999 | 4.00 -> 5.00 |
| 2 | SAME_BANK | 15.99 | 15.98 | 1.000 | 7.00 -> 8.00 |
| 2 | RANDOM_LINE | 41.26 | 41.24 | 0.999 | 4.53 -> 5.53 |
| 2 | RANDOM_RW | 41.69 | 41.67 | 0.999 | 4.52 -> 5.52 |
| 2 | SEQ_WRITE_FULL | 63.62 | 63.56 | 0.999 | 4.00 -> 5.00 |
| 2 | SEQ_WRITE_PART4 | 15.90 | 5.32 | 0.335 | 4.00 -> 7.00 |
| 2 | RANDOM_PART4 | 10.42 | 5.41 | 0.519 | 4.52 -> 6.93 |

Reads and full-line writes keep one access per cycle and gain one cycle of latency; a partial write is an atomic read-modify-write that keeps its bank busy `READ_LATENCY + 1` cycles.

## J - bank count, master count, depth sweeps (patterns 1, 2, 4)

| config | NM | NB | rows/bank | SEQ_LINE B/c | OWN_BANK B/c | RANDOM_LINE B/c |
|---|---:|---:|---:|---:|---:|---:|
| nb1 | 4 | 1 | 1024 | 15.99 | 15.99 | 15.99 |
| nb2 | 4 | 2 | 512 | 31.95 | 31.97 | 27.74 |
| base | 4 | 4 | 256 | 63.68 | 63.87 | 41.29 |
| nb8 | 4 | 8 | 128 | 63.68 | 63.87 | 51.36 |
| nm2_nb4 | 2 | 4 | 256 | 31.90 | 31.94 | 27.68 |
| nm8_nb4 | 8 | 4 | 256 | 63.84 | 63.94 | 52.14 |
| nm8_nb8 | 8 | 8 | 128 | 126.86 | 127.74 | 76.33 |
| d64 | 4 | 4 | 64 | 63.68 | 63.87 | 41.29 |
| d1024 | 4 | 4 | 1024 | 63.68 | 63.87 | 41.29 |
| d4096 | 4 | 4 | 4096 | 63.68 | 63.87 | 41.29 |

Depth does not change bandwidth (rows only change capacity); bank count is the bandwidth lever; more masters than banks raise contention.

## S - offered-load sweep and Q - response-queue occupancy

**S** random lines, base config:

| offered load % | B/cycle | conflict cycles | mean latency | max latency |
|---|---:|---:|---:|---:|
| 5 | 3.10 | 73 | 3.02 | 5 |
| 10 | 6.10 | 193 | 3.05 | 5 |
| 20 | 12.23 | 333 | 3.09 | 5 |
| 30 | 17.51 | 494 | 3.13 | 6 |
| 40 | 22.17 | 677 | 3.19 | 6 |
| 50 | 28.06 | 884 | 3.25 | 6 |
| 60 | 31.78 | 1118 | 3.33 | 6 |
| 80 | 37.34 | 1419 | 3.43 | 6 |
| 100 | 41.29 | 1631 | 3.53 | 6 |
| 100 | 41.29 | 1631 | 3.53 | 6 |
| 100 | 41.29 | 1631 | 3.53 | 6 |
| 100 | 41.29 | 1631 | 3.53 | 6 |

**Q** sequential lines with a slow response consumer (`rsp_pct` = probability the master accepts a response in a cycle):

| config | NSLOT | response ready % | B/cycle | mean latency | max latency |
|---|---:|---:|---:|---:|---:|
| slot2 | 2 | 100 | 42.55 | 3.50 | 6 |
| slot2 | 2 | 50 | 25.74 | 6.18 | 17 |
| slot2 | 2 | 20 | 11.93 | 14.82 | 43 |
| slot2 | 2 | 10 | 6.33 | 29.16 | 118 |
| slot4 | 4 | 100 | 63.68 | 3.00 | 6 |
| slot4 | 4 | 50 | 31.11 | 8.75 | 24 |
| slot4 | 4 | 20 | 12.31 | 24.65 | 61 |
| slot4 | 4 | 10 | 6.41 | 48.47 | 154 |
| base | 8 | 100 | 63.68 | 3.00 | 6 |
| base | 8 | 50 | 31.30 | 16.75 | 33 |
| base | 8 | 20 | 12.31 | 45.12 | 88 |
| base | 8 | 10 | 6.41 | 87.89 | 203 |

## Reproduce

```
python3 benchmarks/run_bench.py --jobs 3        # reports/bench_rtl.json / .csv
cd tools && python3 -m sramlab validate          # model vs these rows (exact)
python3 benchmarks/make_report.py                # this file
```

