# ARCHITECTURE - SilicaFlux MemoryCore SRAM

Status labels used throughout: **RTL-SIMULATION** (Verilator run of the RTL), **MODEL** (Python / behavioural model), **ASSUMED** (a parameter chosen by
the author, no process data behind it), **MEASURED** (a number printed by a simulation run in this repository). There is **no silicon measurement** anywhere in this repository.

## 1. Block diagram

```
                       DataFabric NoC (SFB3, third_party/noc_sfb3)
                                      |  target port t_*
                         +------------v-------------+
                         |  sf_sram_datafabric      |  NP controller master ports; (src,id) pinned to one port
                         +------------+-------------+
  TensorCore  DMA        Vector/scalar |                       MBIST sequencer
  A  B  C     |  DMA     v_req ...     |                       sf_sram_mbist_ctl (+ March engine, reused)
  +---v--v--v-+-v-+   +--v-----------+ |                         | quiesce / raw test bus / re-init
  |sf_tensor_ |   |   |sf_vector_    | |                         |
  |scratchpad |   |   |scratchpad    | |                         |
  +-----+-----+   |   +------+-------+ |                         |
        |   4 ports          | 1+VEC_LINES ports                 |
        +---------+----------+---------+                         |
                  v   NM master ports (valid/ready, id, be)       |
        +---------------------------------------------------+     |
        |                sf_sram_controller                 |<----+
        |  decode (line interleave) | per-bank arbitration  |
        |  per-master reorder slots (NSLOT) -> in-order rsp |
        |  flush / quiesce / init / ECC counters / perf ctr |
        +----+-----------+-----------+-----------+----------+
             |           |           |           |   NB single-port banks, one access / bank / cycle
        +----v----+ +----v----+ +----v----+ +----v----+
        |sf_sram_ | |sf_sram_ | |sf_sram_ | |sf_sram_ |   request/response wrapper, SECDED(137,128) + RMW,
        | bank 0  | | bank 1  | | bank 2  | | bank 3  |   init engine, scrubber, raw test port
        +----+----+ +----+----+ +----+----+ +----+----+
             |           |           |           |
        sf_sram_core (BACKEND = BEHAV)  |  sf_sram_fpga_bram (FPGA)  |  sf_sram_asic_sky130 (ASIC macro tiling)
```

`sf_sram_macro_wrapper` presents one port list over the three backends. The controller instantiates `sf_sram_bank` with a `BACKEND` parameter.

## 2. Baseline configuration

| parameter | baseline | notes |
|---|---|---|
| banks `NB` | 4 | power of two; independent arrays |
| line width `DW` | 128 bit (16 B) | 16 byte lanes, byte write enables |
| depth `DEPTH` | 1024 rows / bank | 4 x 1024 x 16 B = 64 KiB; any depth works, non-power-of-two tested (`DEPTH=100`) |
| port type | single-port synchronous (1RW) | one access per bank per cycle |
| address | byte addressed, `line = a >> 4; bank = line % NB; row = line / NB` | consecutive lines rotate through the banks |
| `READ_LATENCY` | 1 (controller regression 1..3; sramlab extra RTL runs up to 5) | +1 with ECC |
| masters `NM` | 4 (regression 1..4; benchmarks / extra RTL runs up to 16) | each with `NSLOT` reorder slots |

Verified configurations are listed in `docs/VERIFICATION.md`; `sim/run_regress.py` runs the suites.

## 3. Modules (all under `rtl/`)

| module | role | key facts |
|---|---|---|
| `sf_sram_core` | storage array | no array reset; byte enables; explicit read-during-write policy (`READ_FIRST`/`WRITE_FIRST`/`NO_CHANGE`); `SIM_INIT` poison default; parameter validation (`SF_CFG_FATAL`); simulation-only fault models (SAF, TF, address-decoder, CFin/CFid/CFst, one-shot SEU) removed completely when `FAULT_INJECT=0` |
| `sf_sram_bank` | one bank + maintenance | SECDED (137,128) with atomic read-modify-write for partial writes; init engine (explicit initialisation instead of a reset); opportunistic scrubber; raw MBIST test port; CE/UE counters |
| `sf_sram_controller` | NM x NB crossbar | decode, per-bank round-robin or fixed arbitration, per-master reorder slots (in-order responses even with unequal bank latency), transaction ids, flush / quiesce, out-of-range / misalignment errors, performance counters. Contract in `docs/CONTRACT.md` |
| `sf_ecc_enc`, `sf_ecc_dec`, `sf_ecc_counters` | ECC | the leaf codec is reused byte-identical from the RAS project (`third_party/ras_secded`); counters are new. `docs/ECC.md` |
| `sf_sram_mbist_ctl` | MBIST sequencer | quiesce -> March run per bank -> re-initialise; the March engine is reused (`third_party/sramlib_mbist`). `docs/MBIST.md` |
| `sf_sram_datafabric` | SFB3 target adapter | READ / WRITE / WRITE_POSTED, lane steering for 32/64/128-bit fabric words, (src,id) pinned to one controller port, error registers |
| `sf_vector_scratchpad` | vector + scalar front end | sub-word 1/2/4/8 B with sign/zero extension, 16/32/64 B multi-line vectors on parallel ports, natural or in-line alignment rule, bank-conflict detection, independent burst-DMA address generator |
| `sf_tensor_scratchpad` + `sf_ts_port` | TensorCore operand storage | A/B/C regions x `NBUF` ping-pong buffers, bank-skewed bases, hardware-enforced ownership FSM (FREE -> FILLING -> READY -> COMPUTE -> DONE -> DRAINING) |
| `sf_sram_macro_wrapper` + `backends/` | technology backends | behavioural / FPGA block-RAM template / SKY130 OpenRAM tiling (with a **labelled stand-in model** `sim_models/sky130_sram_standin.sv`, not the vendor model) |
| `sf_sync_fifo` | small FIFO | used by the front ends |

## 4. Timing summary (RTL-SIMULATION, `docs/CONTRACT.md` section 3)

* `BANK_LAT = READ_LATENCY + (ECC ? 1 : 0)`; the response of an accepted request is visible `BANK_LAT + 1` cycles after the accepting edge.
* One access per bank per cycle; a master with `NSLOT >= BANK_LAT + 2` can sustain one request per cycle.
* An ECC partial write occupies its bank for `READ_LATENCY + 1` cycles (atomic read-modify-write).

## 5. What is a model and what is RTL

* The **RTL** is everything under `rtl/` (synthesizable; Yosys generic synthesis results in `reports/synthesis.md`; no PDK, no timing, no area).
* The **fault models** in `sf_sram_core` are behavioural classes (stuck-at, transition, coupling, decoder), not a process model.
* The **SKY130 backend** tiles OpenRAM macros by *manifest geometry and port data*; the repository holds no Liberty / LEF / GDS / SPICE view of these macros (`physical/asic_readiness.md`), so it is a **structural** check, not an ASIC-ready deliverable.
* **Power / energy** is a model with assumed parameters (`power/`), never a measurement.
