# VERIFICATION

Labels: **RTL-SIMULATION** = Verilator 5.020 two-state simulation of the RTL; **BOUNDED FORMAL** = bounded model checking, not an unbounded proof. All tables below are generated from `reports/*.json` by `tools/make_verification_md.py`; re-run the commands to reproduce. Nothing here is a silicon result.

## 1. Method

* **Byte-accurate reference memory.** Every testbench keeps an independent model of the memory contents (and of which bytes are known). Requests are applied to the model **at the edge the DUT accepts them** (the controller's serialisation point, `docs/CONTRACT.md` O3) and the model predicts the exact response of each request. Responses are checked in acceptance order per master (O2).
* **Deterministic seeds.** All randomness is xorshift32 seeded by a testbench parameter; every failing run is reproducible with the printed seed.
* **Conservation / integrity** checked continuously: accepted == answered + flushed, no response during flush, payload stable under back-pressure, round-robin waiting bound, full-capacity read-back at the end.
* **Independent references.** ECC is checked against `tools/ecc/secded_ref.py` (written from the documented code layout, no RTL code shared); the cycle model in `tools/sramlab` is derived from the RTL source and compared edge for edge; the DataFabric adapter is checked behind the *implemented* NoC with its own protocol checker.
* **Mutation testing** (`tools/mutate.py`) injects hand-written faults into a *copy* of the RTL and requires at least one testbench to fail; surviving mutants exposed weak checks, which were strengthened (see section 4).

## 2. Regression suites (RTL-SIMULATION)

### ctrl - controller tests T01-T11 and T18 over 21 configurations (latency, ECC, banks, masters, widths, backends): 21/21 cases pass, 5,421,588 self-checks

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| base_L1 | defaults | 12 | 235,954 | 0 | PASS |
| L2 | READ_LATENCY=2, NSLOT=8 | 12 | 235,791 | 0 | PASS |
| L3_slot6 | READ_LATENCY=3, NSLOT=6 | 12 | 235,597 | 0 | PASS |
| ecc_L1 | ECC_EN=1 | 12 | 235,290 | 0 | PASS |
| ecc_L2 | ECC_EN=1, READ_LATENCY=2 | 12 | 236,192 | 0 | PASS |
| fixed_prio | ARB=0 | 12 | 235,679 | 0 | PASS |
| nb2_nm4 | NB=2, NM=4, DEPTH=128 | 12 | 235,885 | 0 | PASS |
| nb8_nm4 | NB=8, NM=4, DEPTH=32 | 12 | 236,696 | 0 | PASS |
| nm8_nb4 | NM=8 | 12 | 419,311 | 0 | PASS |
| nm1_nb1 | NM=1, NB=1, DEPTH=256 | 12 | 100,435 | 0 | PASS |
| no_init_poison | INIT_ON_RESET=0, SIM_INIT=2 | 12 | 230,172 | 0 | PASS |
| align_ignore | ALIGN_MODE=0 | 12 | 237,342 | 0 | PASS |
| nslot3 | NSLOT=3 | 12 | 236,545 | 0 | PASS |
| depth100_nonpow2 | DEPTH=100 | 12 | 254,375 | 0 | PASS |
| dw64 | DW=64 | 12 | 173,063 | 0 | PASS |
| dw256_ecc | DW=256, ECC_EN=1 | 12 | 370,805 | 0 | PASS |
| seed2 | SEED=1592590338, NRAND=3000 | 12 | 356,810 | 0 | PASS |
| fpga_bram | BACKEND=1 | 12 | 235,647 | 0 | PASS |
| fpga_bram_ecc_L2 | BACKEND=1, ECC_EN=1, READ_LATENCY=2 | 12 | 236,192 | 0 | PASS |
| asic_standin_L2 | BACKEND=2, READ_LATENCY=2, DEPTH=256 | 12 | 331,901 | 0 | PASS |
| asic_standin_ecc_L3 | BACKEND=2, READ_LATENCY=3, ECC_EN=1, DEPTH=300 | 12 | 351,906 | 0 | PASS |

### dfab - DataFabric adapter behind the real NoC: 9/9 cases pass, 253,852 self-checks

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| dw128 | defaults | 0 | 28,272 | 0 | PASS |
| dw32_lanes | DW=32 | 0 | 37,320 | 0 | PASS |
| dw64_lanes_np2 | DW=64, NP=2 | 0 | 31,143 | 0 | PASS |
| dw128_np2_L2 | NP=2, READ_LATENCY=2 | 0 | 28,272 | 0 | PASS |
| ecc_dw128 | ECC_EN=1 | 0 | 11,912 | 0 | PASS |
| nm2_idw2_ecc_L3 | NM=2, IDW=2, ECC_EN=1, READ_LATENCY=3, NSLOT=6 | 0 | 9,107 | 0 | PASS |
| nm4_dw128_seed2 | NM=4, SEED=19088743, NRAND=2400 | 0 | 42,132 | 0 | PASS |
| noalign_dw128 | CHK_ALIGN=0 | 0 | 28,332 | 0 | PASS |
| noalign_dw32_np2 | CHK_ALIGN=0, DW=32, NP=2 | 0 | 37,362 | 0 | PASS |

### vsp - vector scratchpad: 7/7 cases pass, 79,035 self-checks

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| vl1_inline | defaults | 0 | 11,013 | 0 | PASS |
| vl1_natural | ALIGN_RULE=0 | 0 | 11,013 | 0 | PASS |
| vl2 | VEC_LINES=2 | 0 | 11,501 | 0 | PASS |
| vl4_nb4 | VEC_LINES=4 | 0 | 11,497 | 0 | PASS |
| vl4_nb2_conflicts | VEC_LINES=4, NB=2, DEPTH=128 | 0 | 11,497 | 0 | PASS |
| vl2_ecc_L2 | VEC_LINES=2, ECC_EN=1, READ_LATENCY=2 | 0 | 11,501 | 0 | PASS |
| vl1_L3_slot6 | READ_LATENCY=3, NSLOT=6, SEED=1911 | 0 | 11,013 | 0 | PASS |

### tsp - tensor scratchpad: 12/12 cases pass, 13,744 self-checks

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| nbuf2_skew1 | defaults | 0 | 1,077 | 0 | PASS |
| nbuf1_single | NBUF=1 | 0 | 1,077 | 0 | PASS |
| nbuf2_skew0 | SKEW=0 | 0 | 1,077 | 0 | PASS |
| nbuf1_skew0 | NBUF=1, SKEW=0 | 0 | 1,077 | 0 | PASS |
| tile6_nonpow2 | N=6 | 0 | 825 | 0 | PASS |
| ecc_L2 | ECC_EN=1, READ_LATENCY=2 | 0 | 1,077 | 0 | PASS |
| compute_extra16 | COMPUTE_EXTRA=16 | 0 | 1,077 | 0 | PASS |
| compute_extra16_nbuf1 | COMPUTE_EXTRA=16, NBUF=1 | 0 | 1,077 | 0 | PASS |
| nb2 | NB=2, DEPTH=128 | 0 | 1,077 | 0 | PASS |
| n16_L3 | N=16, READ_LATENCY=3, NSLOT=6, SEED=4951 | 0 | 2,085 | 0 | PASS |
| early_done | EARLY_DONE=1 | 0 | 1,109 | 0 | PASS |
| early_done_nbuf1_L2 | EARLY_DONE=1, NBUF=1, READ_LATENCY=2 | 0 | 1,109 | 0 | PASS |

### ecc - ECC through the whole controller path (E1-E8): 3/3 cases pass, 29,858 self-checks

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| ecc_sys_nb2_L1 | defaults | 0 | 9,991 | 0 | PASS |
| ecc_sys_nb2_L2 | READ_LATENCY=2 | 0 | 9,991 | 0 | PASS |
| ecc_sys_nb4_L3 | NB=4, READ_LATENCY=3, DEPTH=8, SEED=1592590339 | 0 | 9,876 | 0 | PASS |

Controller test list (`tb/tb_sram_controller.sv`): T01 single write/read, T02 sequential + full-capacity read-back, T03 random single master, T04 byte masking, T05 bank-interleave placement, T06 bank conflicts + fairness, T07 simultaneous masters, T08 back-pressure, T09 burst boundaries, T10 invalid addresses, T11 flush / reset / quiesce, T18 randomized multi-master. Configurations cover READ_LATENCY 1-3, ECC on/off, NB 2/4/8, fixed priority, `ALIGN_MODE=0`, DW 64 and 256, non-power-of-two depth, and the FPGA / ASIC-stand-in backends.

Other testbenches: `tb_ecc_codec` (K = 32/64/128, `docs/ECC.md`, log `reports/ecc_codec.log`), `tb_mbist_cov` (`docs/MBIST.md`), `tb_datafabric` (D1-D6, D3b), `tb_vector_scratchpad` (V1-V7), `tb_tensor_scratchpad` (N1-N6 negatives + tile pipeline), `sf_compat/tb_legacy_mc` (legacy controller - **fails as shipped**, see `docs/SF_COMPAT.md`).

## 3. Bounded formal (Yosys -> AIGER -> ABC `bmc3`)

| configuration | build | depth requested | frames proved | AIG latches | AND gates | result |
|---|---|---|---|---|---|---|
| tiny | structural | 30 | 29 | 628 | 12084 | PASSED |
| tiny_L2 | structural | 24 | 23 | 702 | 12314 | PASSED |
| fixed | structural | 24 | 23 | 626 | 12026 | PASSED |
| small | structural | 18 | 17 | 876 | 15607 | PASSED |
| nm3 | structural | 18 | 17 | 824 | 20365 | PASSED |
| tiny | data (ghost memory) | 7 | 6 | 920 | 32679 | PASSED |
| tiny_L2 | data (ghost memory) | 7 | 6 | 994 | 32928 | PASSED |
| ecc | structural | 20 | 14 | 634 | 11108 | INCOMPLETE(timeout/limit) |

*frames proved* = highest frame index reported by ABC `bmc3 -v` (frames are numbered from 0); a configuration counts as PASSED only when ABC printed `No output asserted in N frames` for the requested depth N.

**Not a full pass:** configuration `ecc` (structural) ended with status `INCOMPLETE(timeout/limit)`: no counterexample was found; ABC completed frames up to index 14 of the 20 requested before the time / resource limit, so only that depth is claimed for it.

Properties (`formal/fv_sram_controller.sv`, asserted every cycle after reset): **P1** routing + exclusivity (at most one accepted non-error master per bank per cycle, bank access iff accepted error-free request to that bank, address map re-implemented independently in the harness); **P2** an accepted error request never produces a bank access; **P3** no duplicate / lost response (per-master outstanding never negative, never above `NSLOT`); **P4** ordering + data (responses equal the head of a ghost FIFO filled at acceptance from a ghost byte-accurate memory - *data build only*); **P5** stable payload under back-pressure; **P6** flush behaviour.

**Assumptions** (each an `assume`): A1 reset low in cycle 0 then high; A2 a presented request that was not accepted is presented again unchanged; A3 `quiesce_i = 0`, no init pulses, scrubber off, MBIST port idle, fault injection off (`INIT_ON_RESET = 0` without ECC; `= 1` with ECC, because a never-written ECC line is an uncorrectable codeword by design - the first ECC run found exactly that harness gap).

**Bounds.** Instances are tiny (2-3 masters, 2 banks, 2-4 rows, 32-bit lines, 2-3 slots; the `ecc` configuration has 1 master); depths are listed above and the data build is much shallower than the structural build. A pass means: no violation exists within that many cycles for any input sequence the assumptions allow. It is **not** an unbounded proof, says nothing about large depths / widths, and does not cover data under ECC single-bit faults, MBIST or the DataFabric adapter (simulation covers those). `yosys-smtbmc` with z3 was tried first and ran out of memory on these instances; ABC's SAT-based BMC was used instead. Any configuration that did not reach its requested depth is reported as such above; none is hidden.

## 4. Mutation testing

**41 of 41 mutants killed** (latest result per mutant; result files: mutation.json, mutation_ext.json, mutation_ext2.json, mutation_ext3.json).

| id | file | mutation | TB config | verdict | first failing check |
|---|---|---|---|---|---|
| M01 | rtl/sf_sram_core.sv | byte enables ignored on write | base | KILLED | [FAIL] master 0: byte 2 read 91 != d @cycle 662 (T03 random address traffic (single master |
| M02 | rtl/sf_sram_controller.sv | bank index inverted (a bijection: only the placement test can see it) | base | KILLED | [FAIL] line 0 not at bank 0 row 0 @cycle 3137 (T05 bank interleaving (address -> bank/row  |
| M03 | rtl/sf_sram_controller.sv | out-of-range off by one line | base | KILLED | [FAIL] master 2: status 0 != 1 @cycle 7632 (T09 burst boundaries (bank wrap, row wrap, ape |
| M04 | rtl/sf_sram_controller.sv | round-robin pointer stuck at master 0 (starvation) | base | KILLED | [FAIL] master 1 waited 80 > NM-1 grants (RR bound) @cycle 3287 (T06 bank conflicts (all ma |
| M05 | rtl/sf_sram_controller.sv | transaction id lost | base | KILLED | [FAIL] master 0: response id 0 != 1 (order) @cycle 76 (T01 single write/read) |
| M06 | rtl/sf_sram_controller.sv | write response leaks read data | base | KILLED | [FAIL] master 0: write/error response rdata not zero @cycle 87 (T02 sequential addresses + |
| M07 | rtl/sf_sram_controller.sv | responses presented during flush | base | KILLED | [FAIL] response presented during flush @cycle 8034 (T11 reset, flush and quiesce) |
| M08 | rtl/sf_sram_controller.sv | alignment check removed | base | KILLED | [FAIL] master 1: status 0 != 2 @cycle 7716 (T10 invalid addresses (range, misaligned) have |
| M09 | rtl/sf_sram_controller.sv | bank responses routed to master 0 only | base | KILLED | [FAIL] drain timeout (deadlock or lost transaction) @cycle 203067 (T05 bank interleaving ( |
| M10 | rtl/sf_sram_core.sv | write completions lost | base | KILLED | [FAIL] drain timeout (deadlock or lost transaction) @cycle 200072 (T01 single write/read) |
| M11 | rtl/sf_sram_controller.sv | response slots overrun under backpressure | base | KILLED | [FAIL] master 1: response withdrawn @cycle 3755 (T08 backpressure (slow response consumers |
| M12 | rtl/sf_sram_controller.sv | quiesce ignored | base | KILLED | [FAIL] request accepted during quiesce @cycle 8585 (T11 reset, flush and quiesce) |
| M13 | rtl/sf_sram_controller.sv | write data always from master 0 | base | KILLED | [FAIL] line 1 not at bank 1 row 0 @cycle 3137 (T05 bank interleaving (address -> bank/row  |
| M14 | rtl/sf_sram_controller.sv | flush leaves stale slots (head/tail not cleared) | base | KILLED | [FAIL] drain timeout (deadlock or lost transaction) @cycle 208034 (T11 reset, flush and qu |
| M15 | rtl/sf_sram_bank.sv | ECC read-modify-write merges the wrong bytes | ecc | KILLED | [FAIL] master 0: byte 0 read c6 != a7 @cycle 667 (T03 random address traffic (single maste |
| M16 | rtl/sf_sram_bank.sv | ECC partial write never written back | ecc | KILLED | [FAIL] master 0: byte 0 read c6 != a7 @cycle 667 (T03 random address traffic (single maste |
| M17 | rtl/sf_sram_bank.sv | bank accepts a request during an RMW | ecc | KILLED | [FAIL] drain timeout (deadlock or lost transaction) @cycle 200598 (T03 random address traf |
| M18 | rtl/sf_sram_bank.sv | RMW write never acknowledged | ecc | KILLED | [FAIL] drain timeout (deadlock or lost transaction) @cycle 200598 (T03 random address traf |
| M19 | rtl/sf_sram_bank.sv | init engine writes an invalid (all-zero) codeword | ecc | KILLED | [FAIL] master 0: status 3 != 0 @cycle 8998 (T18 randomized multi-master traffic (hot lines |
| M20 | rtl/sf_sram_core.sv | read returns the previous row | base | KILLED | [FAIL] master 0: byte 0 read 0 != ef @cycle 76 (T01 single write/read) |
| M21 | rtl/sf_tensor_scratchpad.sv | DMA may write a buffer that is not FILLING (operands overwritten during compute) | tsp | KILLED | [FAIL] N1: DMA write into a READY buffer must answer SF_ST_OWNER @cycle 125 (N negative te |
| M22 | rtl/sf_tensor_scratchpad.sv | DMA may read A/B and read C outside DRAINING | tsp | KILLED | [FAIL] N4: DMA read of C while FILLING / read of A must answer SF_ST_OWNER @cycle 117 (N n |
| M23 | rtl/sf_tensor_scratchpad.sv | TensorCore A access without ownership accepted | tsp | KILLED | [FAIL] N3: TensorCore read without ownership must answer SF_ST_OWNER with rdata 0 @cycle 8 |
| M24 | rtl/sf_tensor_scratchpad.sv | fill completes before its writes are acknowledged | tsp_early | KILLED | [FAIL] fill completed while its write acknowledgements were still outstanding @cycle 256 ( |
| M25 | rtl/sf_tensor_scratchpad.sv | compute completes with accesses still outstanding | tsp_early | KILLED | [FAIL] compute completed while its accesses were still outstanding @cycle 340 (P tile pipe |
| M26 | rtl/sf_tensor_scratchpad.sv | drain grants a buffer still in COMPUTE | tsp | KILLED | no RESULT line / timeout |
| M27 | rtl/sf_vector_scratchpad.sv | sign extension lost | vsp4 | KILLED | [FAIL] vector rsp data 0000000000000000000000000000000000000000000000000000000000000000000 |
| M28 | rtl/sf_vector_scratchpad.sv | alignment / size rejection removed | vsp4 | KILLED | [FAIL] vector rsp status 0 != 2 @cycle 241 (V1 sub-word / line reads and writes, every siz |
| M29 | rtl/sf_vector_scratchpad.sv | inactive-line data leaks into a multi-line response (the bug found during bring-up) | vsp4 | KILLED | [FAIL] vector rsp data d4d800429525d7ee8f6f05c543a44c70a51811e233703fe411152979e311a9451bb |
| M30 | rtl/sf_vector_scratchpad.sv | sub-word write data not shifted to its byte lane | vsp4 | KILLED | [FAIL] vector rsp data 0000000000000000000000000000000000000000000000000000000000000000000 |
| M31 | rtl/sf_vector_scratchpad.sv | DMA ignores the programmed stride | vsp4 | KILLED | [FAIL] DMA beat 25 address 00290 != programmed 002a0 (base + k*stride) @cycle 812 (V4 DMA  |
| M32 | rtl/sf_sram_datafabric.sv | narrow-fabric lane steering wrong | dfab | KILLED | [FAIL] backdoor: line 0 byte 0 in the bank array != model @cycle 10647 (D6 randomized mult |
| M33 | rtl/sf_sram_datafabric.sv | target error reported as DECERR instead of SLVERR | dfab128 | KILLED | [FAIL] master 0 id 2: status 2 != 1 (op 1) @cycle 715 (D4 SRAM range error (offset beyond  |
| M34 | rtl/sf_sram_datafabric.sv | (src,id) pair no longer pinned to one controller port (breaks SFB3 per-pair ordering) | dfab | KILLED | [FAIL] master 1 id 5: rdata b7005538 != b99fab9c @cycle 1434 (D6 randomized multi-master t |
| M35 | rtl/sf_sram_datafabric.sv | byte enables ignored | dfab | KILLED | [FAIL] master 0 id 0: rdata ffffffff != 000000ff @cycle 544 (D1 directed read/write/byte-e |
| M36 | rtl/sf_sram_datafabric.sv | misaligned write reaches the array (adapter guard missing) | dfab_noalign | KILLED | [FAIL] master 1 id 5: rdata ffffffffffffffffffffffffffffffff != 00000000000000000000000000 |
| M39 | rtl/sf_sram_bank.sv | scrubber never writes the corrected word back | eccsys | KILLED | [FAIL] E5: scrubber corrected 176 rows, seeded 11 (E5 scrubber) |
| M40 | rtl/sf_sram_bank.sv | RMW onto an uncorrectable line does not report the error | eccsys | KILLED | [FAIL] E4: partial write onto a UE line must report SF_ST_ECC_UE (E4 RMW on uncorrectable  |
| M41 | rtl/sf_sram_bank.sv | partial write onto an uncorrectable line is NOT aborted (bad bytes blessed with fresh ECC) | eccsys | KILLED | [FAIL] E4: the aborted write must leave the line exactly as found (E4 RMW on uncorrectable |
| M42 | rtl/sf_sram_bank.sv | uncorrectable read reported as OK | eccsys | KILLED | [FAIL] E2: bits 40,93: status 0 != ECC_UE (E2 double-bit errors) |
| M43 | rtl/sf_ecc_counters.sv | correctable-error counter never counts | eccsys | KILLED | [FAIL] E1: correctable counter 0 != 959 injected (E1 every stored bit position) |

Mutants that initially survived exposed weak testbench checks (a quiesce check that was vacuous, a conflict check that needed NM >= 2, a model-mirrored data check in the DataFabric test, an early-completion mode of the tensor scratchpad that nothing exercised, a lane-steering check that was self-consistent with the bug). They were fixed in the testbenches; the numbers above are after those fixes. A full kill count only shows that these injected faults are detectable.

## 5. Logic synthesis (Yosys generic gates, no PDK)

Tool: Yosys 0.33 (git sha1 2584903a060). Counts are generic cells; SRAM arrays remain `$mem` cells. No timing, no area, no technology mapping.

| module / configuration | status | flip-flops | logic cells | $mem cells | memory bits | latches |
|---|---|---|---|---|---|---|
| sf_ecc_enc K=128 | OK | 0 | 314 | 0 | 0 | 0 |
| sf_ecc_dec K=128 | OK | 0 | 1389 | 0 | 0 | 0 |
| sf_sram_core 1024x128 | OK | 6 | 17 | 1 | 131072 | 0 |
| sf_sram_bank 1024x128 (no ECC) | OK | 29 | 726 | 1 | 131072 | 0 |
| sf_sram_bank 1024x137 SECDED + scrub | OK | 423 | 4036 | 1 | 140288 | 0 |
| sf_sram_controller NM4 NB4 4x1024x128 | OK | 5205 | 36440 | 4 | 524288 | 0 |
| sf_sram_controller NM4 NB4 SECDED | OK | 6561 | 46848 | 4 | 561152 | 0 |
| sf_sram_controller NM2 NB2 small | OK | 1431 | 7641 | 2 | 16384 | 0 |
| sf_sram_datafabric DW128 NP1 | OK | 29 | 381 | 0 | 0 | 0 |
| sf_sram_datafabric DW32 NP2 | OK | 30 | 796 | 0 | 0 | 0 |
| sf_vector_scratchpad VEC128 | OK | 326 | 7104 | 2 | 0 | 0 |
| sf_vector_scratchpad VEC512 | OK | 713 | 20059 | 2 | 0 | 0 |
| sf_tensor_scratchpad 8x1 lines, ping-pong | OK | 101 | 1229 | 4 | 0 | 0 |
| sf_sram_mbist_ctl NB4 1024x128 | OK | 235 | 1205 | 0 | 0 | 0 |

## 6. Model validation (sramlab)

The Python cycle model reproduces 119 of 119 committed benchmark rows exactly on seven statistics (cycles, accesses, bank-conflict cycles, bank-busy stalls, mean latency to 3 decimals, max latency, max outstanding). Extra instrumented RTL runs: 342 of 342 controller runs match edge for edge; tensor pipeline 20 of 20 configurations match edge for edge. Details and per-row tables: `reports/sramlab_vs_rtl.md`.

## 7. Tool pitfalls that shaped the testbenches (Verilator 5.020 / Yosys 0.33)

* `pop_front()` on an array of queues empties the queue (NM = 1 and NM + 1 cases) -> circular buffers are used instead; `fork` / `join` in a testbench crashed Verilator -> separate gated `initial` blocks; `buf` and `before` are reserved identifiers there; `int'()` inside `$display` argument lists caused an internal error.
* Yosys 0.33: no `parameter string` (the macro wrapper uses an untyped `INIT_FILE`), `chparam` renames the top (use `synth -flatten` without `-top`), packed-array typedefs in the legacy package are rejected.
* RTL portability rules followed: flat ports, no `int'()` casts, no packages in synthesizable RTL, sized literals.

## 8. What this verification does not show

No silicon behaviour, no timing closure, no power; no X-propagation (two-state simulator); formal results are bounded and small; mutation testing covers only the injected list; the ECC 3-bit behaviour is characterised, not guaranteed; the legacy `memory_controller.sf` is not verified (it fails). See `docs/KNOWN_LIMITATIONS.md`.

