# CONTRACT - ordering, atomicity, latency, flow control

The normative text is the header comment of `rtl/sf_sram_controller.sv` (O1-O8); this page repeats it with the consequences, the data-fabric mapping and
how each rule is checked. Labels: every rule below is checked by RTL-SIMULATION (the testbench scoreboards) and, for the structural parts, by bounded
formal proofs (`docs/VERIFICATION.md`); none of it is silicon data.

## 1. Address map and errors

```
byte address a (AW bits), LB = log2(DW/8) = 4 for 128-bit lines
line = a >> LB ; bank = line % NB ; row = line / NB            (NB power of two)
| row | bank | byte offset |        consecutive lines rotate through the banks
```

* Capacity = `NB * DEPTH * DW/8` bytes. A line index `>= NB*DEPTH` is **out of range**: status `SF_ST_RANGE`, no array access.
* `ALIGN_MODE = 1` (default): `a[LB-1:0] != 0` is answered `SF_ST_ALIGN`, no array access. **RANGE has precedence over ALIGN.**
  Sub-line positions are expressed with the byte enables (the adapters shift data and strobes into the right lane); a read always returns the whole line.
* `ALIGN_MODE = 0`: the low `LB` bits are ignored.
* Error requests still receive exactly one response, in order (rule O2), with `rdata = 0` and the error status.
* Status codes (`rtl/sf_sram_defs.svh`): `OK`, `RANGE`, `ALIGN`, `ECC_UE`, `OWNER` (tensor scratchpad), `BADOP`.

## 2. Ordering and atomicity (O1-O8)

| rule | statement | consequence for software / adapters |
|---|---|---|
| O1 | per-master issue order: one request per master per cycle, accepted and delivered to its bank in presented order | a master sees its own program order |
| O2 | per-master **response** order = acceptance order, including error responses and requests to banks of different latency (RMW, scrub, init stalls). Implemented with `NSLOT` reorder slots per master: allocated in acceptance order, filled out of order, released strictly from the oldest | no re-ordering logic needed in a master; at most `NSLOT` requests outstanding (the slot count **is** the backpressure) |
| O3 | per-bank serialisation: one access per bank per cycle, totally ordered by acceptance. A read accepted at cycle *t* observes exactly the writes accepted at cycles `< t` to the same line, **across all masters** | read-after-write, write-after-write and write-after-read hold per line |
| O4 | atomicity is **one request = one line access**: all byte lanes become visible together to every other master. The ECC read-modify-write of a partial write is atomic (the bank accepts nothing else while it runs). **No atomicity across requests**: no locks, no atomic read-modify-write operations, no multi-line atomicity; a burst is a sequence of independent line accesses that other masters may interleave with | to hand data over, wait for the write **response** before signalling the consumer |
| O5 | no cross-master order except through O3 for the same bank | there is no coherence |
| O6 | fairness: `ARB=RR` - a continuously requesting master is granted by a bank within `NM` grants of that bank; `ARB=FIXED` - master 0 highest, starvation possible (demonstrated, section 5) | |
| O7 | `flush_i` (pulse): requests presented in the flush cycle are not accepted; no response is presented from that cycle on; the controller waits for in-flight bank operations to retire, discards every slot, resumes. Writes already accepted **stay committed** - a flush discards responses, never memory effects | a flushed master must re-read to learn the state |
| O8 | reset clears control state only; memory contents are **not** reset. ECC builds (or `INIT_ON_RESET=1`) initialise the arrays after reset, `req_ready` stays low meanwhile | never rely on array contents after power-up without the init engine |

The response channel holds a presented response stable until accepted. `m_req_ready` depends on registered state, on the master's own request and on the other masters' requests
(the arbiter) - **never on `m_rsp_ready`**, so there is no combinational loop through the response path.

## 3. Latency

* `BANK_LAT = READ_LATENCY (+1 with ECC)`; the response is visible `BANK_LAT + 1` cycles after the accepting edge when the consumer does not back-pressure.
* Sustaining one request per cycle per master needs `NSLOT >= BANK_LAT + 2`; with fewer slots the round-trip limits throughput (benchmark `Q` / config `slot2`, `docs/BENCHMARKS.md`).
* ECC partial write: the bank is busy `READ_LATENCY + 1` cycles.

## 4. DataFabric (SFB3) mapping (`rtl/sf_sram_datafabric.sv`)

| SFB3 rule | how the controller contract satisfies it |
|---|---|
| R5 exactly one response per accepted request (posted writes included) | one controller response per request, always |
| O2 responses of one `(src,id)` pair leave in acceptance order; different pairs may be reordered | every `(src,id)` is pinned to **one** controller port (`port = (src + id) mod NP`), so the pair's order is the controller's per-port order (O2). With `NP = 1` the target is fully in order; with `NP > 1` different pairs may interleave, which SFB3 permits |
| R4 response stable under `t_rsp_ready = 0` | the selected port is **locked** until its response is accepted |
| acknowledged write (SFB2 R7) | the write response is issued after the bank accepted the write |
| errors have no side effect | misaligned / out-of-range / bad opcode are answered `ST_SLVERR`, `rdata = 0`, no array access. `ST_DECERR` is a fabric status and is never produced here |
| no coherence | none provided |

Bursts: SFB3 has no native burst; a burst is a sequence of single-beat transactions (one beat per cycle per controller port when beats map to distinct banks).
The target outstanding limit is `NP * NSLOT`.

## 5. How each rule is checked

* O1/O2/O3/O4: `tb/tb_sram_controller.sv` (byte-accurate reference memory applied at **acceptance order**, per-master in-order response check, tests T01-T11 and the randomized multi-master test T18, final full-capacity readback). Mutation testing (`tools/mutate.py`) injects ordering faults (slot release order, per-bank serialisation, ...) to show that these checks can fail; results in `docs/VERIFICATION.md`.
* O6: round-robin bound checked in the controller TB; fixed-priority starvation demonstrated by the benchmark `E` (single-bank contention: maximum latency 3003 cycles with `ARB=FIXED` against 6 with round robin, `docs/BENCHMARKS.md`) - this is the documented behaviour of `ARB=FIXED`, not a defect.
* O7: flush tests (writes committed, no response after the flush cycle, resume) and the formal properties.
* Datafabric: `tb/tb_datafabric.sv` behind the **implemented** SFB3 NoC with its own protocol checker (`third_party/noc_sfb3/tb/sfn_protocol_checker.sv`): D1-D6 including randomized multi-master traffic with FENCE, posted writes, slow consumers and a backdoor check of the bank arrays.
