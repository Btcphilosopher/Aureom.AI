#!/usr/bin/env python3
"""ABC bit-level bounded model checking of sf_sram_controller (see formal/fv_sram_controller.sv for the properties).

    python3 formal/run_abc.py --cfg tiny --depth 24 [--data] [--timeout 1800] [--mem-mb 6000]

Flow: formal/build_aig.sh (Yosys: prep, flatten, memory_map, aigmap -> AIGER; $assert = bad-state property, $assume = constraint)
then `yosys-abc: read_aiger; fold; bmc3 -F DEPTH`.  A run PASSES iff ABC reports no assertion for any frame up to DEPTH ("No output
asserted in N frames").  BOUNDED proof only: all input sequences of up to DEPTH cycles after reset; no induction.  `--data` enables the
byte-accurate ghost memory (FV_DATA), which is much more expensive.  The result is appended to reports/formal.json."""
import argparse, json, os, re, resource, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", default="tiny"); ap.add_argument("--depth", type=int, default=20); ap.add_argument("--data", action="store_true")
    ap.add_argument("--timeout", type=int, default=1800); ap.add_argument("--mem-mb", type=int, default=6000)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "formal.json"))
    a = ap.parse_args()
    suffix = "_data" if a.data else "_struct"
    env = dict(os.environ, SUFFIX=suffix, EXTRA_DEFS=("-DFV_DATA" if a.data else ""))
    t0 = time.time()
    r = subprocess.run(["bash", os.path.join(ROOT, "formal", "build_aig.sh"), a.cfg], cwd=ROOT, env=env, capture_output=True, text=True)
    aig = os.path.join(ROOT, "build", "formal", f"{a.cfg}{suffix}.aig")
    if not os.path.exists(aig) or os.path.getsize(aig) == 0:
        res = dict(cfg=a.cfg, data=a.data, status="ELAB-FAIL", detail=(r.stdout + r.stderr)[-300:])
    else:
        t1 = time.time()
        def lim(): resource.setrlimit(resource.RLIMIT_AS, (a.mem_mb << 20, a.mem_mb << 20))
        cmd = ["yosys-abc", "-c", f"read_aiger {aig}; fold; print_stats; bmc3 -F {a.depth} -v"]
        try:
            p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=a.timeout, preexec_fn=lim)
            out = p.stdout + p.stderr
        except subprocess.TimeoutExpired as e:
            out = (e.stdout.decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")) + "\n[TIMEOUT]"
        frames = [int(m) for m in re.findall(r"^\s*(\d+) \+ :", out, re.M)]
        st = re.search(r"i/o =\s*(\d+)/\s*(\d+).*lat =\s*(\d+)\s+and =\s*(\d+)", out)
        asserted = re.search(r'Output (\d+) of miter .* was asserted in frame (\d+)', out)
        passed = bool(re.search(r"No output asserted in (\d+) frames", out))
        res = dict(cfg=a.cfg, data=a.data, depth_requested=a.depth, frames_proved=(max(frames) if frames else -1),
                   status=("PASSED" if passed else "FAILED" if asserted else "INCOMPLETE(timeout/limit)"),
                   counterexample=(dict(output=int(asserted.group(1)), frame=int(asserted.group(2))) if asserted else None),
                   aig=dict(inputs=int(st.group(1)), properties=int(st.group(2)), latches=int(st.group(3)), ands=int(st.group(4))) if st else None,
                   build_secs=round(t1 - t0, 1), solve_secs=round(time.time() - t1, 1), tail=out.strip().splitlines()[-3:])
    print(json.dumps({k: v for k, v in res.items() if k != "tail"}))
    allr = []
    if os.path.exists(a.out):
        try: allr = json.load(open(a.out))
        except Exception: allr = []
    allr = [x for x in allr if not (x.get("cfg") == res["cfg"] and x.get("data") == res["data"])] + [res]
    json.dump(allr, open(a.out, "w"), indent=1)
    return 0 if res["status"] == "PASSED" else 1
if __name__ == "__main__":
    sys.exit(main())
