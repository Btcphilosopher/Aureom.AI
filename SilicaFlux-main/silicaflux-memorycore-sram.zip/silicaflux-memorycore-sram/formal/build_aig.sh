#!/bin/bash
# Usage: formal/build_aig.sh <cfg>   (cfg from run_formal.py CFGS; writes build/formal/<cfg>.aig)
# Bit-level flow: Yosys prep/flatten/memory_map/aigmap -> AIGER (asserts = bad properties, assumes = constraints) -> ABC bmc3.
set -e
cd "$(dirname "$0")/.."
cfg="$1"
SRC="rtl/sf_sram_controller.sv rtl/sf_sram_bank.sv rtl/sf_sram_macro_wrapper.sv rtl/sf_sram_core.sv rtl/backends/sf_sram_fpga_bram.sv rtl/backends/sf_sram_asic_sky130.sv rtl/sf_ecc_enc.sv rtl/sf_ecc_dec.sv rtl/sf_ecc_counters.sv third_party/ras_secded/sfras_secded_enc.sv third_party/ras_secded/sfras_secded_dec.sv formal/fv_sram_controller.sv build/formal/fv_top_${cfg}.sv"
yosys -q -p "read_verilog -sv -formal -DFORMAL ${EXTRA_DEFS:-} -Irtl -Ithird_party/ras_secded $SRC; prep -top fv_top; async2sync; dffunmap; flatten; memory_map; opt -fast -nodffe -nosdff; setundef -zero -undriven; techmap; setundef -zero; dfflegalize -cell \$_DFF_P_ 01; opt_clean; aigmap; opt_clean; write_aiger -zinit -map build/formal/${cfg}${SUFFIX:-}.map build/formal/${cfg}${SUFFIX:-}.aig" 2>&1 | grep -v Warning || true
