#!/usr/bin/env python3
"""Bounded formal verification of sf_sram_controller (Yosys 0.33 + yosys-smtbmc + z3).

    python3 formal/run_formal.py [--cfg tiny] [--depth 10] [--cover] [--mem-mb 6000] [--timeout 900]

For each configuration a wrapper module sets the parameters (Yosys 0.33 -chparam is unreliable), the design is elaborated with
`read_verilog -formal`, converted with prep/async2sync/dffunmap and checked with `yosys-smtbmc -s z3 -t DEPTH`.  The RESULT is a
BOUNDED proof: every assertion of formal/fv_sram_controller.sv holds for ALL input sequences of up to DEPTH clock cycles after reset
(assumptions in the harness header).  It is NOT an unbounded proof; no induction is claimed.  --cover runs the cover statements and
reports which were reached (non-vacuity evidence).  Memory is capped with ulimit so a runaway solver cannot take the machine down.
"""
import argparse, json, os, re, resource, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = ["rtl/sf_sram_controller.sv", "rtl/sf_sram_bank.sv", "rtl/sf_sram_macro_wrapper.sv", "rtl/sf_sram_core.sv",
       "rtl/backends/sf_sram_fpga_bram.sv", "rtl/backends/sf_sram_asic_sky130.sv", "rtl/sf_ecc_enc.sv", "rtl/sf_ecc_dec.sv",
       "rtl/sf_ecc_counters.sv", "third_party/ras_secded/sfras_secded_enc.sv", "third_party/ras_secded/sfras_secded_dec.sv",
       "formal/fv_sram_controller.sv"]
CFGS = {
    "tiny":   dict(NM=2, NB=2, DEPTH=2, DW=32, AW=6, IDW=1, NSLOT=2, L=1, ECC=0, ARB=1),
    "tiny_L2": dict(NM=2, NB=2, DEPTH=2, DW=32, AW=6, IDW=1, NSLOT=2, L=2, ECC=0, ARB=1),
    "small":  dict(NM=2, NB=2, DEPTH=4, DW=32, AW=8, IDW=2, NSLOT=3, L=1, ECC=0, ARB=1),
    "fixed":  dict(NM=2, NB=2, DEPTH=2, DW=32, AW=6, IDW=1, NSLOT=2, L=1, ECC=0, ARB=0),
    "nm3":    dict(NM=3, NB=2, DEPTH=2, DW=32, AW=6, IDW=1, NSLOT=2, L=1, ECC=0, ARB=1),
    "ecc":    dict(NM=1, NB=2, DEPTH=2, DW=32, AW=6, IDW=1, NSLOT=2, L=1, ECC=1, ARB=1),
}


def wrapper(name, p):
    return f"""`default_nettype none
module fv_top (input wire clk, input wire rst_n, input wire [{p['NM']-1}:0] req_valid, input wire [{p['NM']-1}:0] req_we,
  input wire [{p['NM']*p['AW']-1}:0] req_addr, input wire [{p['NM']*p['DW']-1}:0] req_wdata, input wire [{p['NM']*p['DW']//8-1}:0] req_be,
  input wire [{p['NM']*p['IDW']-1}:0] req_id, input wire [{p['NM']-1}:0] rsp_ready, input wire flush_i);
  fv_sram_controller #(.NM({p['NM']}), .NB({p['NB']}), .DEPTH({p['DEPTH']}), .DW({p['DW']}), .AW({p['AW']}), .IDW({p['IDW']}),
    .NSLOT({p['NSLOT']}), .L({p['L']}), .ECC({p['ECC']}), .ARB({p['ARB']})) u (.*);
endmodule
"""


def run(cfg, depth, cover, mem_mb, timeout):
    p = CFGS[cfg]
    wdir = os.path.join(ROOT, "build", "formal")
    os.makedirs(wdir, exist_ok=True)
    wrap = os.path.join(wdir, f"fv_top_{cfg}.sv")
    open(wrap, "w").write(wrapper(cfg, p))
    smt = os.path.join(wdir, f"{cfg}{'_cov' if cover else ''}.smt2")
    defs = "-DFORMAL" + (" -DCOVER" if cover else "")
    ys = (f"read_verilog -sv -formal {defs} -Irtl -Ithird_party/ras_secded {' '.join(SRC)} {wrap}; "
          f"prep -top fv_top; async2sync; dffunmap; write_smt2 -wires {smt}")
    t0 = time.time()
    r = subprocess.run(["yosys", "-q", "-p", ys], cwd=ROOT, capture_output=True, text=True)
    if r.returncode != 0:
        return dict(cfg=cfg, status="ELAB-FAIL", detail=(r.stdout + r.stderr)[-400:])
    t_elab = time.time() - t0
    cmd = ["yosys-smtbmc", "-s", "z3", "-t", str(depth)] + (["-c"] if cover else []) + [smt]

    def limit():
        resource.setrlimit(resource.RLIMIT_AS, (mem_mb * 1024 * 1024, mem_mb * 1024 * 1024))
    t1 = time.time()
    try:
        s = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout, preexec_fn=limit)
        out = s.stdout + s.stderr
        rc = s.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout.decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")) + "\n[TIMEOUT]"
        rc = 124
    steps = [int(m) for m in re.findall(r"Checking assertions in step (\d+)", out)]
    covered = re.findall(r"Reached cover statement at (.*?) in step (\d+)", out)
    failed = [l for l in out.splitlines() if "Assert failed" in l or "BMC failed" in l or "Assumptions are unsatisfiable" in l]
    done = "Status: PASSED" in out or "Status: passed" in out.lower()
    res = dict(cfg=cfg, params=p, depth_requested=depth, cover=cover, rc=rc, elab_secs=round(t_elab, 1), solve_secs=round(time.time() - t1, 1),
               max_step_checked=max(steps) if steps else None, covers_reached=len(covered), failed=failed[:5],
               status=("PASSED" if done and rc == 0 else "FAILED" if failed else "INCOMPLETE"), tail=out.strip().splitlines()[-4:])
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", nargs="*", default=["tiny"])
    ap.add_argument("--depth", type=int, default=10)
    ap.add_argument("--cover", action="store_true")
    ap.add_argument("--mem-mb", type=int, default=6000)
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "formal.json"))
    a = ap.parse_args()
    res = []
    if os.path.exists(a.out):
        try:
            res = json.load(open(a.out))
        except Exception:
            res = []
    for c in a.cfg:
        r = run(c, a.depth, a.cover, a.mem_mb, a.timeout)
        print(json.dumps({k: v for k, v in r.items() if k != "tail"}))
        res = [x for x in res if not (x.get("cfg") == c and x.get("cover") == a.cover)] + [r]
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(res, open(a.out, "w"), indent=1)
    return 0 if all(r["status"] == "PASSED" for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
