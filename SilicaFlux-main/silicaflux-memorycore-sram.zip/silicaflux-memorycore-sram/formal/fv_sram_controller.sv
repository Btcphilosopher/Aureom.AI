// =============================================================================
// SilicaFlux MemoryCore :: formal harness for sf_sram_controller (Yosys + yosys-smtbmc / z3, bounded model checking)
//
// DUT: small instance (NM masters, NB banks, DEPTH rows, DW-bit lines, NSLOT slots, READ_LATENCY L, optional ECC).
// Inputs are FREE (any sequence the assumptions allow).  Properties (all asserted every cycle after reset):
//   P1  routing + exclusivity   bank_acc_o[b] == OR over masters of (accepted & !error & bank_of(addr)==b), and at most ONE
//                               accepted non-error master per bank per cycle (the harness re-implements the address map
//                               independently of the RTL: line = addr>>LB, bank = line%NB, oor = line >= NB*DEPTH, misaligned)
//   P2  no illegal memory op    an accepted ERROR request (range / misaligned) never produces a bank access (part of P1)
//   P3  no duplicate / no loss  per master outstanding = accepted - answered: never negative (no response without a request,
//                               "no buffer underflow") and never above NSLOT ("no buffer overflow")
//   P4  ordering + data         every response equals the head of a ghost FIFO filled at acceptance time from a ghost byte-
//                               accurate memory: id, write flag, status, rdata (known bytes), in acceptance order
//   P5  stable payload          a response not accepted stays valid with unchanged payload
//   P6  flush                   while flush_busy_o: no response valid, no request ready; after the flush every master has
//                               nothing outstanding (ghost state is cleared at the flush edge, as the contract O7 defines)
// ASSUMPTIONS (documented, each one is an `assume`):
//   A1  reset: rst_n low in cycle 0, high afterwards (the harness checks behaviour after reset)
//   A2  request stability: a request that was presented and not accepted is presented again unchanged (controller contract:
//       no cancellation)
//   A3  quiesce_i = 0, init_start_i = 0, scrub off, MBIST test port idle, fault injection off.  INIT_ON_RESET = 0 without ECC (the ghost
//       memory tracks which bytes were written, so it needs no initialisation phase); INIT_ON_RESET = 1 with ECC, because a never-written
//       ECC line is an arbitrary (usually uncorrectable) codeword by design - the first harness run found exactly that
// Not proven here (covered by simulation): data content under ECC single-bit faults, MBIST, DataFabric adapter.
// =============================================================================
`default_nettype none
`include "sf_sram_defs.svh"

module fv_sram_controller #(
  parameter NM = 2, NB = 2, DEPTH = 4, DW = 32, AW = 8, IDW = 2, NSLOT = 3, L = 1, ECC = 0, ARB = 1
) (
  input  wire                 clk,
  input  wire                 rst_n,
  input  wire [NM-1:0]        req_valid,
  input  wire [NM-1:0]        req_we,
  input  wire [NM*AW-1:0]     req_addr,
  input  wire [NM*DW-1:0]     req_wdata,
  input  wire [NM*(DW/8)-1:0] req_be,
  input  wire [NM*IDW-1:0]    req_id,
  input  wire [NM-1:0]        rsp_ready,
  input  wire                 flush_i
);
  localparam BE_W = DW / 8;
  localparam LB = (DW == 32) ? 2 : (DW == 64) ? 3 : 4;
  localparam CAPL = NB * DEPTH;
  localparam BW = (NB > 1) ? $clog2(NB) : 1;
  localparam RW = $clog2(DEPTH);
  localparam R_ECC = $clog2(DW + $clog2(DW + 1) + 1);
  localparam STORE_W = (ECC != 0) ? DW + R_ECC + 1 : DW;

  wire [NM-1:0]        req_ready, rsp_valid, rsp_we, rsp_ce;
  wire [NM*DW-1:0]     rsp_rdata;
  wire [NM*IDW-1:0]    rsp_id;
  wire [NM*3-1:0]      rsp_status;
  wire                 flush_busy, idle, init_busy;
  wire [NB-1:0]        bank_acc, ev_ce, ev_ue;
  wire [NB*16-1:0]     ce_cnt, ue_cnt;
  wire [NB*32-1:0]     pa, pc, pb;
  wire [NM*32-1:0]     ps;
  wire [NB*STORE_W-1:0] tst_rdata;

  sf_sram_controller #(.NM(NM), .NB(NB), .DEPTH(DEPTH), .DW(DW), .AW(AW), .IDW(IDW), .READ_LATENCY(L), .ECC_EN(ECC), .NSLOT(NSLOT),
                       .ARB(ARB), .ALIGN_MODE(1), .INIT_ON_RESET(ECC), .SIM_INIT(0), .FAULT_INJECT(0), .CNT_W(16)) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(req_valid), .m_req_ready(req_ready), .m_req_we(req_we), .m_req_addr(req_addr), .m_req_wdata(req_wdata),
    .m_req_be(req_be), .m_req_id(req_id), .m_rsp_valid(rsp_valid), .m_rsp_ready(rsp_ready), .m_rsp_rdata(rsp_rdata),
    .m_rsp_id(rsp_id), .m_rsp_we(rsp_we), .m_rsp_status(rsp_status), .m_rsp_ce(rsp_ce),
    .flush_i(flush_i), .flush_busy_o(flush_busy), .quiesce_i(1'b0), .idle_o(idle), .init_start_i(1'b0), .init_busy_o(init_busy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue), .ce_cnt_o(ce_cnt), .ue_cnt_o(ue_cnt),
    .perf_acc_o(pa), .perf_conf_o(pc), .perf_busy_o(pb), .perf_stall_o(ps), .bank_acc_o(bank_acc),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({RW{1'b0}}), .tst_wdata_i({STORE_W{1'b0}}),
    .tst_rdata_o(tst_rdata),
    .fi_bank({BW{1'b0}}), .fi_type(4'd0), .fi_row({RW{1'b0}}), .fi_row2({RW{1'b0}}), .fi_bit({$clog2(STORE_W){1'b0}}), .fi_bit2({$clog2(STORE_W){1'b0}}),
    .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({RW{1'b0}}), .seu_mask({STORE_W{1'b0}}));

  // ---------------------------------------------------------------- A1: reset sequence
  reg f_past_valid = 1'b0;
  always @(posedge clk) f_past_valid <= 1'b1;
  always @(*) begin
    if (!f_past_valid) assume (!rst_n);
    else               assume (rst_n);
  end

  // ---------------------------------------------------------------- A2: request stability (no cancellation)
  reg [NM-1:0]        p_valid, p_ready, p_we;
  reg [NM*AW-1:0]     p_addr;
  reg [NM*DW-1:0]     p_wdata;
  reg [NM*BE_W-1:0]   p_be;
  reg [NM*IDW-1:0]    p_id;
  reg                 p_flush;
  always @(posedge clk) begin
    p_valid <= req_valid; p_ready <= req_ready; p_we <= req_we; p_addr <= req_addr; p_wdata <= req_wdata; p_be <= req_be; p_id <= req_id;
    p_flush <= flush_i;
  end
  integer ai;
  always @(*) begin
    if (f_past_valid && rst_n && !p_flush)
      for (ai = 0; ai < NM; ai = ai + 1)
        if (p_valid[ai] && !p_ready[ai]) begin
          assume (req_valid[ai]);
          assume (req_we[ai] == p_we[ai]);
          assume (req_addr[ai*AW +: AW] == p_addr[ai*AW +: AW]);
          assume (req_wdata[ai*DW +: DW] == p_wdata[ai*DW +: DW]);
          assume (req_be[ai*BE_W +: BE_W] == p_be[ai*BE_W +: BE_W]);
          assume (req_id[ai*IDW +: IDW] == p_id[ai*IDW +: IDW]);
        end
  end

  // ---------------------------------------------------------------- independent address decode
  reg [NM-1:0] err;
  reg [NM*BW-1:0] bnk;
  integer di;
  reg [AW-1:0] line_a;
  always @(*) begin
    for (di = 0; di < NM; di = di + 1) begin
      line_a = req_addr[di*AW +: AW] >> LB;
      err[di] = (line_a >= CAPL) || (req_addr[di*AW +: LB] != 0);
      bnk[di*BW +: BW] = (NB > 1) ? (line_a % NB) : 0;
    end
  end
  wire [NM-1:0] acc = req_valid & req_ready;

  // ---------------------------------------------------------------- P1 / P2: routing + exclusivity
  integer pb_i, pb_m, cnt_b;
  always @(posedge clk) if (f_past_valid && rst_n) begin
    for (pb_i = 0; pb_i < NB; pb_i = pb_i + 1) begin
      cnt_b = 0;
      for (pb_m = 0; pb_m < NM; pb_m = pb_m + 1)
        if (acc[pb_m] && !err[pb_m] && bnk[pb_m*BW +: BW] == pb_i) cnt_b = cnt_b + 1;
      assert (cnt_b <= 1);                                  // P1 exclusivity: one access per bank per cycle
      assert (bank_acc[pb_i] == (cnt_b == 1));              // P1 routing, P2 error requests never reach a bank
    end
  end

  // ---------------------------------------------------------------- ghost memory + ghost FIFOs (P3, P4)
`ifdef FV_DATA
  reg [DW-1:0]  gm  [0:CAPL-1];
  reg [BE_W-1:0] gk [0:CAPL-1];                              // known-byte mask
  integer gi;
  initial for (gi = 0; gi < CAPL; gi = gi + 1) gk[gi] = 0;
`endif
  localparam FW = IDW + 1 + 3 + DW + BE_W;                    // {id, we, status, data, known}
  reg [NM*NSLOT*FW-1:0] gf;
  reg [NM*3-1:0]        gcnt;                                 // outstanding per master (ghost)
  reg [FW-1:0] fe;
  reg [DW-1:0] edata;
  reg [BE_W-1:0] ekn;
  reg [2:0] est;
  integer gm_i, gb, ln, sl;
  reg [NM*NSLOT*FW-1:0] gf_n;
  reg [2:0] c;
  always @(posedge clk) begin
    if (!rst_n) begin
      gcnt <= 0;
    end else begin
      gf_n = gf;
      for (gm_i = 0; gm_i < NM; gm_i = gm_i + 1) begin
        c = gcnt[gm_i*3 +: 3];
        if (flush_i) begin
          c = 0;
        end else begin
          // response handshake pops the head (index 0), shifting the FIFO
          if (rsp_valid[gm_i] && rsp_ready[gm_i]) begin
            for (sl = 0; sl < NSLOT - 1; sl = sl + 1) gf_n[(gm_i*NSLOT + sl)*FW +: FW] = gf_n[(gm_i*NSLOT + sl + 1)*FW +: FW];
            c = c - 1;
          end
          // acceptance: apply to the ghost memory, push the expectation
          if (acc[gm_i]) begin
            ln = (req_addr[gm_i*AW +: AW] >> LB);
            est = 0; edata = 0; ekn = {BE_W{1'b1}};
            if (req_addr[gm_i*AW +: AW] >> LB >= CAPL) est = `SF_ST_RANGE;
            else if (req_addr[gm_i*AW +: LB] != 0) est = `SF_ST_ALIGN;
`ifdef FV_DATA
            else if (req_we[gm_i]) begin
              for (gb = 0; gb < BE_W; gb = gb + 1)
                if (req_be[gm_i*BE_W + gb]) begin gm[ln][gb*8 +: 8] <= req_wdata[gm_i*DW + gb*8 +: 8]; gk[ln][gb] <= 1'b1; end
            end else begin
              edata = gm[ln]; ekn = gk[ln];
            end
`endif
            if (rsp_valid[gm_i] && rsp_ready[gm_i])
              gf_n[(gm_i*NSLOT + (c + 1 - 1))*FW +: FW] = {req_id[gm_i*IDW +: IDW], req_we[gm_i], est, edata, ekn};
            else
              gf_n[(gm_i*NSLOT + c)*FW +: FW] = {req_id[gm_i*IDW +: IDW], req_we[gm_i], est, edata, ekn};
            c = c + 1;
          end
        end
        gcnt[gm_i*3 +: 3] <= c;
      end
      gf <= gf_n;
    end
  end

  // P3 bounds and P4/P5 checks.  Flush is checked separately (P6); ordering / data checks are skipped on the flush edge itself.
  integer pk, pb2;
  reg [FW-1:0] head;
  reg [DW-1:0] mask;
  always @(posedge clk) if (f_past_valid && rst_n) begin
    for (pk = 0; pk < NM; pk = pk + 1) begin
      assert (gcnt[pk*3 +: 3] <= NSLOT);                                             // P3 no overflow
      if (rsp_valid[pk] && rsp_ready[pk] && !flush_busy) begin
        assert (gcnt[pk*3 +: 3] != 0);                                               // P3 no response without a request (underflow)
        head = gf[(pk*NSLOT)*FW +: FW];
        assert (rsp_id[pk*IDW +: IDW] == head[FW-1 -: IDW]);                          // P4 order + transaction id
        assert (rsp_we[pk] == head[FW-IDW-1]);
        assert (rsp_status[pk*3 +: 3] == head[FW-IDW-2 -: 3]);
        if (!head[FW-IDW-1] && head[FW-IDW-2 -: 3] == `SF_ST_OK) begin
`ifdef FV_DATA
          mask = 0;
          for (pb2 = 0; pb2 < BE_W; pb2 = pb2 + 1) if (head[pb2]) mask[pb2*8 +: 8] = 8'hFF;
          assert ((rsp_rdata[pk*DW +: DW] & mask) == (head[BE_W +: DW] & mask));     // P4 byte-accurate data (known bytes)
`endif
        end else begin
          assert (rsp_rdata[pk*DW +: DW] == 0);                                      // write / error responses carry rdata 0
        end
      end
    end
  end

  // P5: stable payload while stalled
  reg [NM-1:0] r_valid, r_ready; reg [NM*DW-1:0] r_data; reg [NM*IDW-1:0] r_id; reg [NM*3-1:0] r_st; reg r_flush, r_fb;
  always @(posedge clk) begin
    r_valid <= rsp_valid; r_ready <= rsp_ready; r_data <= rsp_rdata; r_id <= rsp_id; r_st <= rsp_status; r_flush <= flush_i; r_fb <= flush_busy;
  end
  integer ps_i;
  // a flush (this cycle or earlier) may withdraw a response by contract (O7): the stability property excludes it
  always @(posedge clk) if (f_past_valid && rst_n && !r_flush && !r_fb && !flush_i && !flush_busy)
    for (ps_i = 0; ps_i < NM; ps_i = ps_i + 1)
      if (r_valid[ps_i] && !r_ready[ps_i]) begin
        assert (rsp_valid[ps_i]);
        assert (rsp_rdata[ps_i*DW +: DW] == r_data[ps_i*DW +: DW]);
        assert (rsp_id[ps_i*IDW +: IDW] == r_id[ps_i*IDW +: IDW]);
        assert (rsp_status[ps_i*3 +: 3] == r_st[ps_i*3 +: 3]);
      end

  // P6: flush behaviour
  always @(posedge clk) if (f_past_valid && rst_n) begin
    if (flush_busy) begin
      assert (rsp_valid == 0);
      assert (req_ready == 0);
    end
  end

  // ---------------------------------------------------------------- covers (non-vacuity)
`ifdef COVER
  always @(posedge clk) if (f_past_valid && rst_n) begin
    cover (|(rsp_valid & rsp_ready) && !flush_busy);
    cover (rsp_valid[0] && rsp_ready[0] && !rsp_we[0] && rsp_status[0*3 +: 3] == `SF_ST_OK);
    cover (|(acc & err));
    cover (NM > 1 && acc[0] && !err[0] && req_valid[1] && !req_ready[1] && !err[1] && bnk[0 +: BW] == bnk[BW +: BW]);   // a bank conflict is resolved
    cover (flush_busy);
    cover (gcnt[0 +: 3] == NSLOT);
  end
`endif
endmodule
