#!/bin/bash
# Sequential bounded-proof campaign (structural build deep, data build shallow). Results accumulate in reports/formal.json.
cd "$(dirname "$0")/.."
run() { python3 -I formal/run_abc.py "$@" || true; }
run --cfg tiny    --depth 30 --timeout 1500
run --cfg tiny_L2 --depth 24 --timeout 1500
run --cfg fixed   --depth 24 --timeout 1500
run --cfg small   --depth 18 --timeout 1500
run --cfg nm3     --depth 18 --timeout 1500
run --cfg ecc     --depth 16 --timeout 1500
run --cfg tiny    --depth 7  --data --timeout 1500
run --cfg tiny_L2 --depth 7  --data --timeout 1500
