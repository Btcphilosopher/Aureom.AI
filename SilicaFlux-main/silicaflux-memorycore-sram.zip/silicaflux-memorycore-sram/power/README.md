# power/ - parametric energy / power MODEL of the MemoryCore SRAM subsystem

**This is a MODEL, never a measurement.** The repository contains **no Liberty, SPICE or characterisation power data for any SRAM macro**
(`physical/asic_readiness.md`: the Liberty and SPICE views of the SKY130, IHP SG13G2 and GF180MCU macros are ABSENT). Every absolute
energy / power produced here comes from the **ASSUMED parameters** in `params_assumed.json` - each entry carries the comment
*"ASSUMPTION - not from any process; replace with Liberty/characterised values"*. They fix the order of magnitude of the illustrations and nothing else.

| trust | what |
|---|---|
| **trustworthy** | access counts (reads / writes / RMW partial writes / bank-busy cycles) - they come from `tools/sramlab`, whose cycle model reproduces the RTL simulation exactly (`reports/sramlab_vs_rtl.md`); the RTL widths (128 data bits, 137 stored bits with SECDED); the RTL cycles/tile of the tensor runs |
| **trustworthy (parameter-free)** | the ratios / brackets of section 1 of `reports/sramlab_energy.md` (ECC stored-bit ratio 137/128, scalar-vs-line 4x energy per useful byte, double-vs-single-buffer dynamic energy 1.0 and total energy bracketed by the cycles ratio, accesses per MAC) |
| **illustrative only** | every pJ, mW, pJ/byte, pJ/MAC and every share that depends on a value of `params_assumed.json` |

## Files

| file | content |
|---|---|
| `params_assumed.json` | the ONLY place with assumed numbers (+ units, meaning, the ASSUMPTION comment per entry) and the list of RTL-derived (not assumed) constants |
| `sram_energy.py` | the model + driver: `python3 power/sram_energy.py` (stdlib; imports `tools/sramlab`) |
| `sram_energy_report.py` | writes `reports/sramlab_energy.{md,json}` and the SVG plots |
| `energy_results.json`, `energy_results.csv` | full results (all patterns x {no ECC, ECC}, tensor rows, standby, scrub, init, sensitivity, thermal scenarios) |
| `thermal_input_example.json` | per-bank power in the **ThermalLab block-JSON schema** - a FORMAT-LEVEL hand-off example (see below) |

## Model (all coefficients ASSUMED, structure derived from the RTL)

* dynamic energy per bank access, width `W` columns (128, or 137 with ECC), `E_dec = e_dec_fixed + e_dec_per_addrbit * log2(DEPTH)`
  * read  = `E_dec + W (e_rd_bit + e_wl_bit)` (+ `e_ecc_dec` with ECC)
  * full-line write = `E_dec + W (e_wr_bit + e_wl_bit)` (+ `e_ecc_enc` with ECC)
  * partial write without ECC (byte-masked, one array cycle) = `E_dec + W e_wl_bit + 8k e_wr_bit + (W-8k) e_halfsel_bit`
  * partial write with ECC = **RMW** = one ECC read access + one ECC write access (the RTL re-encodes the whole stored word; the bank is busy `READ_LATENCY+1` cycles)
* idle clock/control energy per bank-cycle without access, controller energy per accepted access (reorder slot + response mux),
  ALIGN/RANGE error responses at `ctrl_err_fraction` of that
* leakage = stored bits x `leak_pw_per_bit` x (1 + `periph_leak_fraction`); energy = power x cycles / `clock_mhz`
* switching activity is NOT assumed: it is the simulated traffic (per-bank reads / writes / RMW and bank occupancy of the validated cycle model)
* energy per USEFUL byte counts only requests that reached an array (pattern 0 of the current TB is line-aligned; the first TB revision's byte-strided variant, kept as model-only pattern 9, was 75 % ALIGN-rejected, see `reports/sramlab_vs_rtl.md`)
* energy per useful tensor operation: one operation = one 32-bit MAC; per tile the TensorCore reads A[k], B[k], C[k] and writes C[k] per pass and line, the DMA fill writes 3N lines and the drain reads N lines
  (`tensor_counts`); cycles per tile are the RTL-SIMULATION values from `reports/bench_rtl.json`. SRAM subsystem only (the MAC datapath is not modelled).

## Results

`reports/sramlab_energy.md` (+ `.json`, `sramlab_energy_per_byte.svg`, `sramlab_energy_sensitivity.svg`): relative results first, then the sensitivity sweep
(one-at-a-time x0.25..x4 and a joint log-uniform sample) that shows which conclusions depend on the assumed values, then the nominal absolute illustrations.

## Thermal / power-grid hand-off - FORMAT LEVEL ONLY (nothing was co-simulated)

Inspected READ-ONLY (extracted docs/READMEs only; **no code from the archives was executed**):

* `SilicaFlux ThermalLab (1).zip` -> `silicaflux-thermallab-0.1.0.zip`: README "Plugging in real data" and `power_mapping.py` text define a **per-block power input** (block CSV/JSON: required
  `name, zone, x0_um, y0_um, x1_um, y1_um, power_w`; optional `kind, layer, provenance, source`; `provenance` from its `DataStatus` enum). `thermal_input_example.json` is written in exactly this
  schema (`{"blocks": [...]}`, `provenance = assumed_engineering_parameter`), with the four bank rectangles and the controller reserve taken from `physical/floorplan_C1_sky130.json`
  (GENERATED GEOMETRY, not a routed layout) and the per-bank average power of the model (workload: saturated random 16 B reads). The file carries a `_format_check` produced by
  `validate_thermal_example()` - this tool's own re-implementation of the documented required-field rules, **not ThermalLab**. ThermalLab was **not** executed, so this is a format-level
  hand-off, **not an executed co-simulation**.
* `silicaflux-powerfabric-p36.zip` (PowerGrid-like): its inputs are extracted-grid exports (`nodes.csv`: `node,x_um,y_um,load_current_a,voltage_v`; `resistors.csv`) - per-node currents, not per-block
  power. It models SRAM loads as accesses/cycle x access energy x f + leakage because the SRAM Liberty gives 0 W (same structure as this model). Mapping bank power to grid nodes needs the extracted grid;
  **not done**, and no PowerGrid input file is written.

## Reproduce

```
python3 power/sram_energy.py          # needs reports/bench_rtl.json; ~5 s
python3 -m unittest discover -s tools/sramlab/tests   # from the project root (includes tests of this model)
```
