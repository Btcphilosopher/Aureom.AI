#!/usr/bin/env python3
"""Parametric ENERGY / POWER MODEL of the MemoryCore SRAM subsystem.   *** A MODEL, NEVER A MEASUREMENT ***

The repository has NO Liberty / SPICE / characterisation power data for any SRAM macro.  Every absolute energy in this
module is computed from the ASSUMED parameters of power/params_assumed.json (each flagged "ASSUMPTION - not from any process;
replace with Liberty/characterised values").  What is trustworthy are
  * the ACCESS COUNTS (reads / writes / RMW partial writes / bank-idle cycles), which come from the validated cycle model of
    tools/sramlab (identical to the RTL simulation; model-vs-RTL: reports/sramlab_vs_rtl.md), and
  * the PARAMETER-FREE RATIOS and the sensitivity brackets derived from them (see `relative_results` and `sensitivity`).

Run:   python3 power/sram_energy.py            -> power/energy_results.json, power/energy_results.csv,
                                                  power/thermal_input_example.json, reports/sramlab_energy.{md,json,svg}
Labels used everywhere:  RTL-SIMULATION | MODEL | ANALYTICAL | ASSUMED-PARAMETER
"""
from __future__ import annotations

import csv
import json
import math
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))

from sramlab.model import Cfg, simulate           # noqa: E402
from sramlab import traffic as T                   # noqa: E402
from sramlab import tensor as TN                   # noqa: E402

PARAMS_PATH = os.path.join(HERE, "params_assumed.json")
DW = 128
ECC_W = 137          # SECDED(137,128): from rtl/sf_sram_bank.sv STORE_W (derived, not assumed)


def load_params(path: str = PARAMS_PATH):
    with open(path) as fh:
        raw = json.load(fh)
    return {k: v["value"] for k, v in raw["params"].items()}, raw


# ------------------------------------------------------------------------------------------------ per-access energies
def access_energies(P: dict, depth: int, ecc: int, partial_bytes: int = 4) -> dict:
    """Dynamic energy of ONE bank access in pJ (ASSUMED-PARAMETER x RTL structure).

      read            E_dec + W (e_rd + e_wl)  [+ decode]
      write (full)    E_dec + W (e_wr + e_wl)  [+ encode]
      partial write   no ECC: E_dec + W e_wl + 8k e_wr + (W - 8k) e_halfsel      (byte-masked, one array cycle)
                      ECC   : RMW = read(ECC) + write(ECC)  (the stored word is re-encoded as a whole)
    W = 128 columns (137 with ECC).  E_dec = e_dec_fixed + e_dec_per_addrbit * log2(DEPTH)."""
    W = ECC_W if ecc else DW
    dec = P["e_dec_fixed_pj"] + P["e_dec_per_addrbit_pj"] * math.log2(depth)
    fj = 1e-3
    rd = dec + W * (P["e_rd_bit_fj"] + P["e_wl_bit_fj"]) * fj
    wr = dec + W * (P["e_wr_bit_fj"] + P["e_wl_bit_fj"]) * fj
    if ecc:
        rd += P["e_ecc_dec_pj"]
        wr += P["e_ecc_enc_pj"]
        part = rd + wr                                        # RMW: a read access plus a write access
    else:
        bits = 8 * partial_bytes
        part = dec + W * P["e_wl_bit_fj"] * fj + bits * P["e_wr_bit_fj"] * fj + (W - bits) * P["e_halfsel_bit_fj"] * fj
    return {"read": rd, "write_full": wr, "write_partial": part, "decode_fixed": dec, "columns": W}


def leakage_w(P: dict, nb: int, depth: int, ecc: int) -> float:
    """Total standby leakage power in W: bits x leak/bit x (1 + periphery fraction)."""
    bits = nb * depth * (ECC_W if ecc else DW)
    return bits * P["leak_pw_per_bit"] * 1e-12 * (1.0 + P["periph_leak_fraction"])


# ------------------------------------------------------------------------------------------------ benchmark energy
def run_energy(res, P: dict, depth_for_energy: int | None = None, include_ctrl: bool = True) -> dict:
    """Energy of one benchmark run (sramlab.model.Result) from its access counts.  All pJ values: MODEL x ASSUMED-PARAMETER."""
    cfg = res.cfg
    depth = depth_for_energy or cfg.depth
    ae = access_energies(P, depth, cfg.ecc)
    nb = cfg.nb
    cycles = res.cycles
    e_dyn_b = []
    for b in range(nb):
        rd = res.per_bank_rd[b]
        wr = res.per_bank_wr[b]
        part = res.per_bank_part[b]
        e = rd * ae["read"] + (wr - part) * ae["write_full"] + part * ae["write_partial"]
        e_dyn_b.append(e)
    occ = res.per_bank_occ
    e_idle_b = [max(0, cycles - occ[b]) * P["e_idle_clk_pj_per_bank_cycle"] for b in range(nb)]
    n_acc = sum(res.per_bank_acc)
    e_ctrl = (n_acc + P["ctrl_err_fraction"] * res.err_responses) * P["e_ctrl_access_pj"] if include_ctrl else 0.0
    t_s = cycles / (P["clock_mhz"] * 1e6)
    p_leak = leakage_w(P, nb, depth, cfg.ecc)
    e_leak_pj = p_leak * t_s * 1e12
    useful = res.useful_bytes_array
    e_dyn = sum(e_dyn_b)
    e_tot = e_dyn + sum(e_idle_b) + e_ctrl + e_leak_pj
    return {
        "pattern": cfg.pattern, "pattern_name": T.PATTERN_NAMES[cfg.pattern], "ecc": cfg.ecc, "read_latency": cfg.read_latency,
        "nb": nb, "depth": depth, "cycles": cycles, "accesses": n_acc, "error_responses": res.err_responses,
        "reads": sum(res.per_bank_rd), "writes_full": sum(res.per_bank_wr) - sum(res.per_bank_part), "writes_partial": sum(res.per_bank_part),
        "useful_bytes_array": useful, "useful_bytes_tb_accounting": res.useful_bytes,
        "E_array_dynamic_pJ": e_dyn, "E_bank_idle_clk_pJ": sum(e_idle_b), "E_controller_pJ": e_ctrl, "E_leakage_pJ": e_leak_pj,
        "E_total_pJ": e_tot,
        "pJ_per_useful_byte_dynamic": e_dyn / useful if useful else float("nan"),
        "pJ_per_useful_byte_total": e_tot / useful if useful else float("nan"),
        "leakage_share": e_leak_pj / e_tot if e_tot else 0.0,
        "avg_power_mW": e_tot / (t_s * 1e12) * 1e3 if t_s else 0.0,
        "avg_power_per_bank_mW": [(e_dyn_b[b] + e_idle_b[b]) / (t_s * 1e12) * 1e3 + p_leak / nb * 1e3 for b in range(nb)],
        "leakage_power_uW": p_leak * 1e6,
        "per_access_pJ": ae,
        "bank_occupancy": [occ[b] / cycles for b in range(nb)],
    }


def standby_summary(P: dict, nb: int, depth: int, ecc: int) -> dict:
    p = leakage_w(P, nb, depth, ecc)
    return {"nb": nb, "depth": depth, "ecc": ecc, "bits": nb * depth * (ECC_W if ecc else DW), "leakage_uW": p * 1e6,
            "idle_clock_uW": nb * P["e_idle_clk_pj_per_bank_cycle"] * 1e-12 * P["clock_mhz"] * 1e6 * 1e6,
            "standby_total_uW": p * 1e6 + nb * P["e_idle_clk_pj_per_bank_cycle"] * P["clock_mhz"]}


def scrub_energy(P: dict, depth: int, ecc: int = 1) -> dict:
    ae = access_energies(P, depth, 1)
    wait = P["scrub_wait_cycles"]
    return {"E_scrub_step_clean_pJ": ae["read"], "E_scrub_step_corrected_pJ": ae["read"] + ae["write_full"],
            "max_extra_accesses_fraction_per_bank": 1.0 / (wait + 1),
            "max_scrub_power_per_bank_uW": ae["read"] / (wait + 1) * P["clock_mhz"]}


def init_energy(P: dict, nb: int, depth: int, ecc: int) -> dict:
    ae = access_energies(P, depth, ecc)
    return {"E_init_pJ": nb * depth * ae["write_full"], "init_cycles": depth, "note": "INIT_ON_RESET: every row written once per bank (parallel banks)"}


# ------------------------------------------------------------------------------------------------ tensor workload
def tensor_counts(n: int, passes: int) -> dict:
    """SRAM accesses of the tensor TB per tile (tb_tensor_scratchpad): TensorCore per pass and line k: read A[k], B[k], C[k], write C[k];
    DMA: fill writes 3N lines (A, B, C), drain reads N lines (C).  One MAC = one 32-bit multiply-accumulate (4 per 128-bit line)."""
    reads = 3 * n * passes + n
    writes = n * passes + 3 * n
    macs = 4 * n * passes
    return {"reads": reads, "writes": writes, "accesses": reads + writes, "macs": macs, "accesses_per_mac": (reads + writes) / macs}


def tensor_energy(P: dict, n: int, passes: int, cycles_per_tile: float, nb: int = 4, depth: int = 64, ecc: int = 0) -> dict:
    ct = tensor_counts(n, passes)
    ae = access_energies(P, depth, ecc)
    e_dyn = ct["reads"] * ae["read"] + ct["writes"] * ae["write_full"]
    t_s = cycles_per_tile / (P["clock_mhz"] * 1e6)
    e_leak = leakage_w(P, nb, depth, ecc) * t_s * 1e12
    busy_bank_cycles = ct["accesses"]                       # one bank cycle per (full-line) access
    e_idle = max(0.0, nb * cycles_per_tile - busy_bank_cycles) * P["e_idle_clk_pj_per_bank_cycle"]
    e_ctrl = ct["accesses"] * P["e_ctrl_access_pj"]
    e_tot = e_dyn + e_leak + e_idle + e_ctrl
    return {"E_dynamic_pJ_per_tile": e_dyn, "E_static_pJ_per_tile": e_leak + e_idle, "E_ctrl_pJ_per_tile": e_ctrl, "E_total_pJ_per_tile": e_tot,
            "pJ_per_MAC_dynamic": e_dyn / ct["macs"], "pJ_per_MAC_total": e_tot / ct["macs"], "macs_per_tile": ct["macs"],
            "accesses_per_tile": ct["accesses"], "cycles_per_tile": cycles_per_tile, "static_share": (e_leak + e_idle) / e_tot}


# ------------------------------------------------------------------------------------------------ relative (parameter-free) results
def relative_results(P: dict, tensor_rows: dict) -> dict:
    """Ratios that do not depend on the absolute scale of ANY assumed energy (parameter-free) plus ratios that depend on the
    assumed values (reported with the value at the nominal parameters; their brackets come from `sensitivity`)."""
    out = {}
    out["parameter_free"] = {
        "ecc_stored_bits_ratio": ECC_W / DW,
        "ecc_stored_bits_ratio_note": "RTL: 137 stored bits per 128-bit line (SECDED(137,128)); every bit-proportional energy and the leakage grow by this factor",
        "ecc_partial_write_array_accesses_ratio": 2.0,
        "ecc_partial_write_array_accesses_note": "RTL: a partial write with ECC = one read + one write (bank busy READ_LATENCY+1 cycles) vs one write",
        "scalar4B_vs_line16B_energy_per_useful_byte": 4.0,
        "scalar_note": "RTL has no sub-line array access: a 4 B scalar load costs a whole-line array read; 16/4 = 4 x the energy per useful byte of a full-line read (exact, independent of every energy parameter; a hypothetical column-muxed macro would lower it)",
        "double_vs_single_buffer_dynamic_energy_per_op": 1.0,
        "double_vs_single_note": "identical SRAM access counts per tile: only the run time differs",
    }
    r2, r1 = tensor_rows.get("nbuf2_skew1"), tensor_rows.get("nbuf1_skew1")
    if r1 and r2:
        out["parameter_free"]["double_vs_single_buffer_time_ratio_RTL"] = r2["cycles_per_tile"] / r1["cycles_per_tile"]
        out["parameter_free"]["double_vs_single_buffer_total_energy_per_op_bracket"] = [r2["cycles_per_tile"] / r1["cycles_per_tile"], 1.0]
        out["parameter_free"]["double_vs_single_bracket_note"] = ("total SRAM energy/op ratio lies between the RTL cycles/tile ratio (all energy static) and 1.0 (all energy "
                                                                    "dynamic) for ANY parameter values")
    ae0 = access_energies(P, 256, 0)
    ae1 = access_energies(P, 256, 1)
    out["assumed_dependent_nominal"] = {
        "ecc_read_energy_ratio": ae1["read"] / ae0["read"], "ecc_full_write_energy_ratio": ae1["write_full"] / ae0["write_full"],
        "ecc_partial_write_energy_ratio": ae1["write_partial"] / ae0["write_partial"],
        "write_to_read_energy_ratio_noecc": ae0["write_full"] / ae0["read"],
    }
    return out


def _metrics(P: dict, tensor_rows: dict) -> dict:
    """The scalar conclusions whose sensitivity is swept."""
    d = 256
    a0, a1 = access_energies(P, d, 0), access_energies(P, d, 1)
    m = {
        "ecc_read_overhead_pct": 100 * (a1["read"] / a0["read"] - 1),
        "ecc_full_write_overhead_pct": 100 * (a1["write_full"] / a0["write_full"] - 1),
        "ecc_partial_write_energy_ratio": a1["write_partial"] / a0["write_partial"],
        "write_to_read_ratio": a0["write_full"] / a0["read"],
        "scalar_vs_vector_energy_per_useful_byte_ratio": (a0["read"] / 4.0) / (a0["read"] / 16.0),
    }
    base = {k: v for k, v in tensor_rows.items()}
    if "nbuf1_skew1" in base and "nbuf2_skew1" in base:
        t1 = tensor_energy(P, 8, 3, base["nbuf1_skew1"]["cycles_per_tile"], ecc=0)
        t2 = tensor_energy(P, 8, 3, base["nbuf2_skew1"]["cycles_per_tile"], ecc=0)
        m["double_vs_single_energy_per_op_ratio"] = t2["pJ_per_MAC_total"] / t1["pJ_per_MAC_total"]
        m["tensor_static_share_single"] = t1["static_share"]
        m["tensor_pJ_per_MAC_double"] = t2["pJ_per_MAC_total"]
    if "nbuf2_ecc" in base and "nbuf2_skew1" in base:
        te = tensor_energy(P, 8, 3, base["nbuf2_ecc"]["cycles_per_tile"], ecc=1)
        t2 = tensor_energy(P, 8, 3, base["nbuf2_skew1"]["cycles_per_tile"], ecc=0)
        m["ecc_tensor_energy_per_op_ratio"] = te["pJ_per_MAC_total"] / t2["pJ_per_MAC_total"]
    # one benchmark: leakage share of a saturated random-read run (static / dynamic balance)
    res = simulate(Cfg(pattern=4, nreq=300))
    e = run_energy(res, P, depth_for_energy=1024)
    m["leakage_share_random_read_64KiB"] = e["leakage_share"]
    m["pJ_per_useful_byte_random_read"] = e["pJ_per_useful_byte_total"]
    return m


def sensitivity(P0: dict, tensor_rows: dict, n_random: int = 300, seed: int = 7) -> dict:
    """(1) one-at-a-time: each parameter x0.25, x0.5, x2, x4 (clock excluded from ranges but included for leakage energy).
       (2) random: all parameters jointly log-uniform in [1/4, 4] x nominal.   Returns min/max/median of every metric and a
       robustness flag per metric (does the sign / ordering conclusion survive?)."""
    keys = [k for k in P0 if k not in ("scrub_wait_cycles",)]
    base = _metrics(P0, tensor_rows)
    oat = {}
    for k in keys:
        lo = {}
        for f in (0.25, 0.5, 2.0, 4.0):
            P = dict(P0)
            P[k] = P0[k] * f
            mm = _metrics(P, tensor_rows)
            for mk, mv in mm.items():
                lo.setdefault(mk, []).append(mv)
        oat[k] = {mk: (min(v), max(v)) for mk, v in lo.items()}
    rng = random.Random(seed)
    samples = {mk: [] for mk in base}
    for _ in range(n_random):
        P = dict(P0)
        for k in keys:
            P[k] = P0[k] * math.exp(rng.uniform(math.log(0.25), math.log(4.0)))
        mm = _metrics(P, tensor_rows)
        for mk, mv in mm.items():
            samples[mk].append(mv)
    rand = {}
    for mk, v in samples.items():
        s = sorted(v)
        rand[mk] = {"min": s[0], "p05": s[int(0.05 * len(s))], "median": s[len(s) // 2], "p95": s[int(0.95 * len(s))], "max": s[-1]}
    # which parameter moves which metric the most (one-at-a-time spread, relative to nominal)
    tornado = {}
    for mk in base:
        rows = []
        for k in keys:
            lo, hi = oat[k][mk]
            rows.append((k, lo, hi, (hi - lo) / abs(base[mk]) if base[mk] else 0.0))
        rows.sort(key=lambda r: -r[3])
        tornado[mk] = rows[:4]
    return {"nominal": base, "one_at_a_time": oat, "random_loguniform_4x": rand, "top_sensitivities": tornado, "n_random": n_random}


# ------------------------------------------------------------------------------------------------ driver
def main(argv=None):
    P, raw = load_params()
    with open(os.path.join(ROOT, "reports", "bench_rtl.json")) as fh:
        bench = json.load(fh)
    trows = {r["config"]: r for r in bench["tensor"]}
    nreq = 1000
    out = {"label": "MODEL x ASSUMED-PARAMETER (access counts: validated cycle model; energies: params_assumed.json). NOT a measurement.",
           "params_file": "power/params_assumed.json", "params_nominal": P, "clock_mhz": P["clock_mhz"]}
    # ---- benchmark patterns: base (no ECC) and ECC, RL = 1
    pats = []
    for ecc in (0, 1):
        for pat in range(9):
            res = simulate(Cfg(pattern=pat, ecc=ecc, nreq=nreq))
            pats.append(run_energy(res, P))
    # MODEL-ONLY pattern 9: the ORIGINAL byte-strided scalar pattern of the first TB revision (3 of 4 requests ALIGN-rejected at the
    # controller; kept to show that rejected requests cost no array energy). Pattern 0 above is the line-aligned scalar workload.
    res = simulate(Cfg(pattern=9, ecc=0, nreq=nreq))
    e = run_energy(res, P)
    e["pattern_name"] = "SEQ_SCALAR4 byte-stride (ALIGN_MODE=1, model-only, 3 of 4 rejected)"
    pats.append(e)
    out["benchmarks"] = pats
    # ratios ECC / no-ECC per pattern
    ratios = []
    for pat in range(9):
        a = next(x for x in pats if x["pattern"] == pat and x["ecc"] == 0 and "ALIGN_MODE" not in x["pattern_name"])
        b = next(x for x in pats if x["pattern"] == pat and x["ecc"] == 1)
        ratios.append({"pattern": pat, "name": T.PATTERN_NAMES[pat],
                       "dynamic_energy_per_useful_byte_ratio_ecc_over_noecc": b["pJ_per_useful_byte_dynamic"] / a["pJ_per_useful_byte_dynamic"],
                       "total_energy_per_useful_byte_ratio_ecc_over_noecc": b["pJ_per_useful_byte_total"] / a["pJ_per_useful_byte_total"],
                       "cycles_ratio": b["cycles"] / a["cycles"], "array_accesses_ratio": (b["reads"] + b["writes_full"] + 2 * b["writes_partial"]) /
                       max(1, (a["reads"] + a["writes_full"] + a["writes_partial"]))})
    out["ecc_over_noecc_by_pattern"] = ratios
    # ---- tensor workload
    tens = {}
    for tag, r in trows.items():
        te = tensor_energy(P, r["n"], r["passes"], r["cycles_per_tile"], nb=r["nb"], depth=64, ecc=r["ecc"])
        te["config"] = tag
        te["rtl_cycles_per_tile"] = r["cycles_per_tile"]
        te["rtl_bank_conflict_cycles"] = r["bank_conflict_cycles"]
        tens[tag] = te
    out["tensor"] = tens
    out["tensor_counts"] = tensor_counts(8, 3)
    # ---- standby, scrub, init
    out["standby"] = [standby_summary(P, 4, d, e) for d in (256, 1024, 4096) for e in (0, 1)]
    out["scrub"] = scrub_energy(P, 1024)
    out["init"] = init_energy(P, 4, 1024, 1)
    out["relative"] = relative_results(P, trows)
    out["sensitivity"] = sensitivity(P, trows)
    # ---- per-bank power for the thermal hand-off (floorplan C1: 4 banks x 1024 rows x 128 b, 64 KiB)
    out["thermal_handoff"] = thermal_scenarios(P)
    with open(os.path.join(HERE, "energy_results.json"), "w") as fh:
        json.dump(out, fh, indent=1)
    with open(os.path.join(HERE, "energy_results.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["label", "MODEL x ASSUMED-PARAMETER (not a measurement)"])
        w.writerow(["pattern", "ecc", "cycles", "accesses", "reads", "writes_full", "writes_partial", "useful_bytes_array", "pJ_per_useful_byte_dynamic",
                    "pJ_per_useful_byte_total", "leakage_share", "avg_power_mW"])
        for x in pats:
            w.writerow([x["pattern_name"], x["ecc"], x["cycles"], x["accesses"], x["reads"], x["writes_full"], x["writes_partial"], x["useful_bytes_array"],
                        f'{x["pJ_per_useful_byte_dynamic"]:.4f}', f'{x["pJ_per_useful_byte_total"]:.4f}', f'{x["leakage_share"]:.5f}', f'{x["avg_power_mW"]:.5f}'])
    write_thermal_example(out["thermal_handoff"])
    from sram_energy_report import write_report          # noqa: E402  (same directory)
    write_report(out, P, raw)
    print("wrote power/energy_results.json, energy_results.csv, thermal_input_example.json, reports/sramlab_energy.md")
    return 0


def thermal_scenarios(P: dict) -> dict:
    """Per-bank average power (W) of the C1 floorplan (4 banks x 1024 rows x 128 b) for three workloads.  MODEL x ASSUMED-PARAMETER."""
    sc = {}
    for name, cfgkw in (("idle", None), ("seq_line_saturated", dict(pattern=1)), ("random_read_saturated", dict(pattern=4)),
                        ("random_rw_saturated", dict(pattern=5))):
        if cfgkw is None:
            nb, depth = 4, 1024
            p_leak = leakage_w(P, nb, depth, 0)
            pb = [p_leak / nb + P["e_idle_clk_pj_per_bank_cycle"] * 1e-12 * P["clock_mhz"] * 1e6 for _ in range(nb)]
            sc[name] = {"per_bank_W": pb, "controller_W": 0.0}
            continue
        res = simulate(Cfg(depth=1024, nreq=1000, **cfgkw))
        e = run_energy(res, P, depth_for_energy=1024)
        t_s = res.cycles / (P["clock_mhz"] * 1e6)
        sc[name] = {"per_bank_W": [x * 1e-3 for x in e["avg_power_per_bank_mW"]], "controller_W": e["E_controller_pJ"] * 1e-12 / t_s,
                    "cycles": res.cycles, "accesses": e["accesses"]}
    return sc


REQUIRED_BLOCK_FIELDS = ("name", "zone", "x0_um", "y0_um", "x1_um", "y1_um", "power_w")          # ThermalLab power_mapping.REQUIRED_BLOCK_COLUMNS
THERMALLAB_PROVENANCE = ("actual_implementation_data", "eda_derived_data", "laboratory_measurement", "published_material_property",
                         "assumed_engineering_parameter", "demonstration_value", "user_supplied_data")   # ThermalLab materials.DataStatus


def validate_thermal_example(doc: dict) -> list:
    """Own re-implementation of the DOCUMENTED ThermalLab block-record checks (required fields, numeric, power >= 0, valid rectangle inside the die,
    provenance enum, no overlapping 'cell' blocks).  Returns a list of problems (empty = format OK).  This is NOT ThermalLab (not executed)."""
    probs = []
    blocks = doc.get("blocks")
    if not isinstance(blocks, list) or not blocks:
        return ["no 'blocks' list"]
    W, H = doc["_die_um"]["die_width_um"], doc["_die_um"]["die_height_um"]
    names = set()
    for i, b in enumerate(blocks):
        miss = [k for k in REQUIRED_BLOCK_FIELDS if k not in b or b[k] in ("", None)]
        if miss:
            probs.append(f"block {i}: missing {miss}")
            continue
        if b["name"] in names:
            probs.append(f"duplicate name {b['name']}")
        names.add(b["name"])
        for k in ("x0_um", "y0_um", "x1_um", "y1_um", "power_w"):
            if not isinstance(b[k], (int, float)) or b[k] != b[k]:
                probs.append(f"block {b['name']}: {k} not a number")
        if b["power_w"] < 0:
            probs.append(f"block {b['name']}: negative power")
        if not (b["x1_um"] > b["x0_um"] and b["y1_um"] > b["y0_um"]):
            probs.append(f"block {b['name']}: degenerate rectangle")
        if b["x0_um"] < 0 or b["y0_um"] < 0 or b["x1_um"] > W + 1e-6 or b["y1_um"] > H + 1e-6:
            probs.append(f"block {b['name']}: outside the die")
        if b.get("provenance", "demonstration_value") not in THERMALLAB_PROVENANCE:
            probs.append(f"block {b['name']}: provenance {b.get('provenance')!r} not a ThermalLab DataStatus")
    for i, a in enumerate(blocks):
        for c in blocks[i + 1:]:
            if min(a["x1_um"], c["x1_um"]) > max(a["x0_um"], c["x0_um"]) and min(a["y1_um"], c["y1_um"]) > max(a["y0_um"], c["y0_um"]):
                probs.append(f"blocks {a['name']} and {c['name']} overlap")
    return probs


def write_thermal_example(scen: dict, path: str | None = None):
    """Format-level hand-off in the ThermalLab block-power JSON schema (silicaflux-thermallab-0.1.0: power_mapping.blocks_from_records:
    required fields name, zone, x0_um, y0_um, x1_um, y1_um, power_w; optional kind, layer, provenance, source; provenance must be one of
    ThermalLab's DataStatus values -> 'assumed_engineering_parameter').  NOT an executed co-simulation: ThermalLab was not run."""
    with open(os.path.join(ROOT, "physical", "floorplan_C1_sky130.json")) as fh:
        fp = json.load(fh)
    key = "random_read_saturated"
    blocks = []
    for br in fp["bank_regions"]:
        b = br["bank"]
        blocks.append({"name": f"SRAM_bank{b}", "zone": "SRAM", "x0_um": br["llx"], "y0_um": br["lly"], "x1_um": br["urx"], "y1_um": br["ury"],
                       "power_w": scen[key]["per_bank_W"][b], "kind": "cell", "layer": "active", "provenance": "assumed_engineering_parameter",
                       "source": "sramlab energy MODEL (power/sram_energy.py) with ASSUMED parameters (power/params_assumed.json); workload: " + key +
                                 "; bank rectangle = GENERATED GEOMETRY of physical/floorplan_C1_sky130.json (not a routed layout)"})
    lr = fp["logic_reserve"]
    blocks.append({"name": "SRAM_CTRL", "zone": "SRAM", "x0_um": lr["llx"], "y0_um": lr["lly"], "x1_um": lr["urx"], "y1_um": lr["ury"],
                   "power_w": scen[key]["controller_W"], "kind": "cell", "layer": "active", "provenance": "assumed_engineering_parameter",
                   "source": "sramlab energy MODEL, controller access energy ASSUMED; rectangle = PLACEHOLDER logic reserve of the generated floorplan"})
    doc = {"_label": "FORMAT-LEVEL HAND-OFF EXAMPLE. Power values are MODEL x ASSUMED-PARAMETER (not measured, not from any process). ThermalLab was NOT executed.",
           "_schema": "ThermalLab block JSON: {'blocks': [ {name, zone, x0_um, y0_um, x1_um, y1_um, power_w, kind, layer, provenance, source} ]}  (power_mapping.load_blocks_json)",
           "_die_um": {"die_width_um": fp["die"]["width_um"], "die_height_um": fp["die"]["height_um"],
                       "origin": "die lower-left (0,0); x right, y up - same convention as ThermalLab floorplan_adapter"},
           "_floorplan_source": "physical/floorplan_C1_sky130.json (generated geometry, C1: 4 banks x 1024 rows x 128 b, SKY130 macro tiling)",
           "_workload_scenarios_W": {k: {"per_bank_W": v["per_bank_W"], "controller_W": v["controller_W"]} for k, v in scen.items()},
           "_selected_scenario": key,
           "blocks": blocks}
    probs = validate_thermal_example(doc)
    doc["_format_check"] = {"checker": "power/sram_energy.py validate_thermal_example (own re-implementation of the documented required-field rules; ThermalLab NOT executed)",
                            "problems": probs, "ok": not probs}
    with open(path or os.path.join(HERE, "thermal_input_example.json"), "w") as fh:
        json.dump(doc, fh, indent=1)
    if probs:
        raise RuntimeError("thermal_input_example.json failed the format check: " + "; ".join(probs))


if __name__ == "__main__":
    sys.exit(main())
