"""Writes reports/sramlab_energy.{md,json,svg} from the results dict of sram_energy.py.  MODEL x ASSUMED-PARAMETER, never a measurement."""
from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))
from sramlab.svgplot import Plot      # noqa: E402

REPORTS = os.path.join(ROOT, "reports")


def tbl(headers, rows):
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def g(v, n=3):
    if isinstance(v, float):
        return f"{v:.{n}g}"
    return str(v)


def write_report(out: dict, P: dict, raw: dict):
    os.makedirs(REPORTS, exist_ok=True)
    rel = out["relative"]
    pf = rel["parameter_free"]
    sens = out["sensitivity"]
    L = []
    w = L.append
    w("# SilicaFlux MemoryCore SRAM - energy / power MODEL (ASSUMED parameters, not a measurement)")
    w("")
    w("> **READ THIS FIRST.** The repository contains **no Liberty, SPICE or characterisation power data for any SRAM macro** "
      "(physical/asic_readiness.md: Liberty and SPICE views are ABSENT for the SKY130, IHP SG13G2 and GF180MCU macros; the sibling PowerFabric report states that the IHP SRAM Liberty gives 0 W). "
      "Every absolute energy and power below is computed from the ASSUMED parameters of `power/params_assumed.json` (each entry: *ASSUMPTION - not from any process; replace with Liberty/characterised values*). "
      "They fix the order of magnitude of the illustrations and nothing else. **What can be trusted are the access counts (from the validated cycle model, identical to the RTL simulation) "
      "and the parameter-free ratios / brackets in section 1, which are derived before any assumed number is used.** Nothing here is a silicon measurement; no process is implied.")
    w("")
    w("Provenance tags: `RTL-SIMULATION` (cycle counts of the benchmark runs), `MODEL` (sramlab cycle model: access counts, bank occupancy), `ANALYTICAL` (formulas), "
      "`ASSUMED-PARAMETER` (params_assumed.json). A number that depends on an `ASSUMED-PARAMETER` is marked **(assumed)**.")
    w("")
    # ---------------------------------------------------------------- 1 relative
    w("## 1. Relative results first (parameter-free or bracketed for ANY parameter values)")
    w("")
    sd = sens["random_loguniform_4x"]
    ro = sens["one_at_a_time"]
    rows = [
        ["ECC stored bits per line", f"137 / 128 = {pf['ecc_stored_bits_ratio']:.4f}", "exact (RTL SECDED(137,128))", "every bit-proportional energy and the leakage grow by this factor (ratio of two RTL widths)"],
        ["ECC partial write: array accesses", "2 (read + write) vs 1", "exact (RTL)", "bank busy READ_LATENCY+1 cycles; RTL-SIMULATION throughput of SEQ_WRITE_PART4 with ECC is ~0.5x (reports/sramlab_vs_rtl.md 3.2)"],
        ["4 B scalar load vs 16 B line load, energy per useful byte", f"{pf['scalar4B_vs_line16B_energy_per_useful_byte']:.2f} x", "exact for this RTL (no sub-line array access)", "same array access energy, 4x fewer useful bytes; a column-muxed macro would reduce it (not modelled)"],
        ["Double vs single buffering, dynamic SRAM energy per MAC", f"{pf['double_vs_single_buffer_dynamic_energy_per_op']:.2f} x", "exact", "identical access counts per tile"],
        ["Double vs single buffering, TOTAL SRAM energy per MAC", f"between {pf['double_vs_single_buffer_total_energy_per_op_bracket'][0]:.3f} and 1.000", "bracket for any parameters", "lower end = all energy static (leakage/idle clock), upper end = all dynamic; the RTL cycles/tile ratio 78/113 sets the lower end"],
        ["SRAM line accesses per MAC (tensor TB, PASSES=3)", f"{out['tensor_counts']['accesses_per_mac']:.3f}", "exact (TB structure)", "4 line accesses (A,B,C read + C write) feed 4 MACs per pass line; DMA adds 1/PASSES"],
        ["Bank conflicts / back-pressure", "no dynamic energy", "structural", "a stalled request performs no array access; stalls only lengthen run time (static energy per byte grows with cycles)"],
    ]
    w(tbl(["quantity", "value", "status", "why"], rows))
    w("")
    w("## 2. Sensitivity: which conclusions depend on the assumed parameters")
    w("")
    w("One-at-a-time: each ASSUMED parameter x0.25, x0.5, x2, x4 (min..max over those 4 values per parameter, then the envelope over all parameters); "
      "random: all parameters jointly log-uniform in [0.25, 4] x nominal (300 samples, 5th..95th percentile). ASSUMED-PARAMETER results throughout.")
    w("")
    rows = []
    names = {
        "ecc_read_overhead_pct": "ECC read energy overhead [%]", "ecc_full_write_overhead_pct": "ECC full-line write energy overhead [%]",
        "ecc_partial_write_energy_ratio": "ECC partial write (RMW) energy / no-ECC byte-masked write", "write_to_read_ratio": "write / read energy (no ECC)",
        "scalar_vs_vector_energy_per_useful_byte_ratio": "scalar 4 B vs 16 B line, energy per useful byte",
        "double_vs_single_energy_per_op_ratio": "double / single buffer, energy per MAC", "tensor_static_share_single": "static share of tensor energy (single buffer)",
        "tensor_pJ_per_MAC_double": "tensor SRAM energy per MAC, double buffer [pJ]", "ecc_tensor_energy_per_op_ratio": "tensor energy per MAC, ECC / no-ECC",
        "leakage_share_random_read_64KiB": "leakage share of total energy, saturated random reads, 64 KiB", "pJ_per_useful_byte_random_read": "energy per useful byte, saturated random 16 B reads [pJ]",
    }
    for mk, nm in names.items():
        if mk not in sens["nominal"]:
            continue
        nom = sens["nominal"][mk]
        lo = min(v[mk][0] for v in ro.values() if mk in v)
        hi = max(v[mk][1] for v in ro.values() if mk in v)
        r5, r95 = sd[mk]["p05"], sd[mk]["p95"]
        robust = ""
        if mk == "scalar_vs_vector_energy_per_useful_byte_ratio":
            robust = "parameter-free"
        elif mk == "double_vs_single_energy_per_op_ratio":
            robust = f"always in [{pf['double_vs_single_buffer_total_energy_per_op_bracket'][0]:.2f}, 1] (bracket)"
        elif mk in ("ecc_read_overhead_pct", "ecc_full_write_overhead_pct"):
            robust = "always > 0, < 25 % over the sweep" if hi < 25 and lo > 0 else "range wide"
        elif mk == "ecc_partial_write_energy_ratio":
            robust = f"> 2 over the whole sweep (min {g(lo)})" if lo > 2.0 else "range wide"
        elif mk == "leakage_share_random_read_64KiB":
            robust = (f"dynamic dominates for every swept value (max {100*hi:.1f} %), but leakage would equal dynamic at ~{(1/nom - 1):.0f}x the assumed leak/bit - "
                      "far outside the swept x0.25..x4 range, so no real leakage conclusion can be drawn")
        else:
            robust = "assumed-dependent"
        rows.append([nm, g(nom), f"{g(lo)} .. {g(hi)}", f"{g(r5)} .. {g(r95)}", robust])
    w(tbl(["conclusion / metric", "nominal (assumed)", "one-at-a-time envelope", "random 5-95 %", "robust?"], rows))
    w("")
    w("Parameters that move each conclusion the most (one-at-a-time spread relative to nominal):")
    w("")
    rows = []
    for mk in ("ecc_partial_write_energy_ratio", "ecc_read_overhead_pct", "double_vs_single_energy_per_op_ratio", "leakage_share_random_read_64KiB", "tensor_pJ_per_MAC_double"):
        if mk in sens["top_sensitivities"]:
            top = sens["top_sensitivities"][mk]
            rows.append([names.get(mk, mk), ", ".join(f"{k} ({g(lo)}..{g(hi)})" for k, lo, hi, _ in top[:3])])
    w(tbl(["metric", "top-3 parameters (metric range over x0.25..x4)"], rows))
    w("")
    w("**Reading.** Robust for any parameter values: ordering and sign statements (ECC adds energy; a scalar load costs 4x per useful byte; double buffering never increases energy per MAC and can reduce it by at most the cycles ratio; "
      "an ECC partial write costs two array accesses and, with any swept parameters, more than twice a byte-masked non-ECC write). Parameter-dependent: the absolute pJ, the write/read ratio, the ECC percentage overheads (they follow the fixed-vs-bit-proportional split of the assumed read energy), "
      "and the static (leakage + idle clock) share: it is small for saturated traffic at the assumed values and grows with idle time, but its true size needs characterised leakage - no leakage conclusion may be drawn from this model.")
    w("")
    # ---------------------------------------------------------------- 3 absolute
    w("## 3. Absolute illustrations at the NOMINAL assumed parameters (ASSUMED-PARAMETER x MODEL; order of magnitude only)")
    w("")
    w("### 3.1 Energy per bank access (pJ, assumed)")
    w("")
    rows = []
    for depth in (256, 1024):
        import sram_energy as SE
        for ecc in (0, 1):
            ae = SE.access_energies(P, depth, ecc)
            rows.append([depth, ecc, ae["columns"], f"{ae['read']:.2f}", f"{ae['write_full']:.2f}", f"{ae['write_partial']:.2f}" + (" (RMW)" if ecc else " (4 B masked)")])
    w(tbl(["DEPTH (rows/bank)", "ECC", "columns", "read pJ", "full-line write pJ", "partial write pJ"], rows))
    w("")
    w("### 3.2 Standby / leakage power (assumed)")
    w("")
    rows = [[s["depth"], s["ecc"], s["bits"], f"{s['leakage_uW']:.2f}", f"{s['standby_total_uW']:.2f}"] for s in out["standby"]]
    w(tbl(["DEPTH", "ECC", "stored bits (4 banks)", "leakage [uW]", "leakage + idle clock [uW] at 100 MHz"], rows))
    w("")
    w(f"Scrub (RTL: one step per SCRUB_WAIT = {P['scrub_wait_cycles']} idle cycles per bank): {out['scrub']['E_scrub_step_clean_pJ']:.1f} pJ per clean step, "
      f"{out['scrub']['E_scrub_step_corrected_pJ']:.1f} pJ when a corrected line is written back, at most {100*out['scrub']['max_extra_accesses_fraction_per_bank']:.1f} % extra bank accesses "
      f"(~{out['scrub']['max_scrub_power_per_bank_uW']:.0f} uW per bank at the assumed clock). Init at reset (INIT_ON_RESET, ECC 4 banks x 1024 rows): {out['init']['E_init_pJ']/1e3:.1f} nJ once, {out['init']['init_cycles']} cycles. (all assumed)")
    w("")
    w("### 3.3 Benchmark patterns: energy per USEFUL byte (MODEL access counts from the validated model; energies assumed)")
    w("")
    rows = []
    for x in out["benchmarks"]:
        rows.append([x["pattern_name"], x["ecc"], x["cycles"], x["reads"], x["writes_full"], x["writes_partial"], x["useful_bytes_array"], f"{x['pJ_per_useful_byte_dynamic']:.3f}",
                     f"{x['pJ_per_useful_byte_total']:.3f}", f"{100*x['leakage_share']:.2f} %", f"{x['avg_power_mW']:.3f}"])
    w(tbl(["pattern", "ECC", "cycles (RTL-validated MODEL)", "array reads", "full writes", "partial writes", "useful bytes at the array", "pJ/B dynamic (assumed)", "pJ/B total (assumed)", "leakage share (assumed)", "avg power mW (assumed)"], rows))
    w("")
    w("Useful bytes count only requests that reached an array. Pattern 0 (SEQ_SCALAR4) is the line-aligned scalar workload of the current TB; the extra row `ALIGN_MODE=1 byte-stride` is the "
      "MODEL-ONLY original byte-strided pattern of the first TB revision (3 of 4 requests rejected, no array energy), kept to document that rejected requests cost no array energy.")
    w("")
    w("### 3.4 ECC overhead per pattern (ratio ECC / no-ECC)")
    w("")
    rows = [[r["name"], f"{r['dynamic_energy_per_useful_byte_ratio_ecc_over_noecc']:.3f}", f"{r['total_energy_per_useful_byte_ratio_ecc_over_noecc']:.3f}", f"{r['cycles_ratio']:.3f}", f"{r['array_accesses_ratio']:.2f}"] for r in out["ecc_over_noecc_by_pattern"]]
    w(tbl(["pattern", "dynamic pJ/B ratio (assumed)", "total pJ/B ratio (assumed)", "cycles ratio (MODEL = RTL)", "array accesses ratio (exact)"], rows))
    w("")
    w("### 3.5 Energy per useful tensor operation (one operation = one 32-bit multiply-accumulate; SRAM subsystem only - the MAC datapath is not included)")
    w("")
    tc = out["tensor_counts"]
    w(f"Per tile (tensor TB): TensorCore per pass and line k reads A[k], B[k], C[k] and writes C[k]; the DMA fill writes 3N lines and the drain reads N lines. N=8, PASSES=3: "
      f"{tc['reads']} reads + {tc['writes']} writes = {tc['accesses']} line accesses for {tc['macs']} MACs ({tc['accesses_per_mac']:.3f} accesses/MAC, exact). Cycles per tile are the RTL-SIMULATION values.")
    w("")
    rows = []
    for tag, t in out["tensor"].items():
        rows.append([tag, t["rtl_cycles_per_tile"], t["rtl_bank_conflict_cycles"], f"{t['pJ_per_MAC_dynamic']:.2f}", f"{t['pJ_per_MAC_total']:.2f}", f"{100*t['static_share']:.1f} %"])
    w(tbl(["tensor config", "RTL cycles/tile", "RTL conflict cycles", "dynamic pJ/MAC (assumed)", "total pJ/MAC (assumed)", "static share (assumed)"], rows))
    w("")
    r1, r2 = out["tensor"]["nbuf1_skew1"], out["tensor"]["nbuf2_skew1"]
    w(f"Single vs double buffering: dynamic pJ/MAC identical ({r1['pJ_per_MAC_dynamic']:.2f}); total pJ/MAC {r1['pJ_per_MAC_total']:.2f} -> {r2['pJ_per_MAC_total']:.2f} "
      f"(x{r2['pJ_per_MAC_total']/r1['pJ_per_MAC_total']:.4f}, inside the parameter-free bracket [{pf['double_vs_single_buffer_total_energy_per_op_bracket'][0]:.3f}, 1] of section 1; assumed). "
      "At the nominal assumed values the static share is tiny, so the saving is tiny - with higher assumed leakage it approaches the cycle ratio. The honest statement is the bracket, not the nominal value.")
    w("")
    # ---------------------------------------------------------------- 4 thermal
    w("## 4. Power / thermal integration in the repository (format-level hand-off only)")
    w("")
    w("Inspected READ-ONLY (docs/READMEs extracted into build/sramlab_work; no code from the archives was executed):")
    w("")
    w("* **`silicaflux-thermallab-0.1.0` (inside `SilicaFlux ThermalLab (1).zip`)** documents a per-block power input: a block CSV/JSON with required fields "
      "`name, zone, x0_um, y0_um, x1_um, y1_um, power_w` and optional `kind, layer, provenance, source` (README 'Plugging in real data'; `power_mapping.blocks_from_records`, `load_blocks_json`); "
      "`provenance` must be one of its DataStatus values (we use `assumed_engineering_parameter`). Its own docs state that it ships DEMONSTRATION inputs only.")
    w("* **`silicaflux-powerfabric-p36.zip` (PowerGrid-like)** consumes extracted-grid exports (`nodes.csv`: node,x_um,y_um,load_current_a,voltage_v; `resistors.csv`) - per-node currents on a power-grid network, "
      "not per-block power; its SRAM loads are 'accesses / cycle x access energy x f + leakage' from a PackageTwin `power_model.json` (our model has the same structure), because the IHP SRAM Liberty gives 0 W. "
      "Mapping bank power to PowerGrid nodes needs the extracted grid and was **not done**.")
    w("")
    w("`power/thermal_input_example.json` is written in the ThermalLab block-JSON schema from this model's per-bank average power (workload: saturated random 16 B reads, floorplan C1: 4 banks x 1024 rows x 128 b), "
      "with bank rectangles taken from `physical/floorplan_C1_sky130.json` (GENERATED GEOMETRY, not a routed layout). All power values are **MODEL x ASSUMED-PARAMETER**. "
      "**This is a FORMAT-LEVEL hand-off: ThermalLab was NOT executed (no co-simulation was run).** The JSON was checked only against the documented required-field list by this tool's own validator.")
    w("")
    th = out["thermal_handoff"]
    rows = [[k, [f"{x*1e3:.3f}" for x in v["per_bank_W"]], f"{v['controller_W']*1e3:.3f}"] for k, v in th.items()]
    w(tbl(["workload scenario", "per-bank average power [mW] (assumed)", "controller [mW] (assumed)"], rows))
    w("")
    w("## 5. What would make these numbers real")
    w("")
    w("Replace `params_assumed.json` by characterised values (per-bit read/write energy, decoder energy, leakage, ECC logic from synthesis power reports) and re-run `python3 power/sram_energy.py`; "
      "the access counts and all ratios of section 1 stay valid, section 2 will then show how much the remaining uncertainty matters.")
    w("")
    w("## 6. Assumed parameters used (all ASSUMPTION - not from any process; replace with Liberty/characterised values)")
    w("")
    rows = [[k, raw["params"][k]["value"], raw["params"][k]["unit"], raw["params"][k]["meaning"]] for k in raw["params"]]
    w(tbl(["parameter", "value", "unit", "meaning"], rows))
    w("")
    with open(os.path.join(REPORTS, "sramlab_energy.md"), "w") as f:
        f.write("\n".join(L))
    slim = {"label": out["label"], "params_nominal": out["params_nominal"], "relative": out["relative"], "sensitivity": {k: out["sensitivity"][k] for k in ("nominal", "random_loguniform_4x", "top_sensitivities", "n_random")},
            "benchmarks": out["benchmarks"], "ecc_over_noecc_by_pattern": out["ecc_over_noecc_by_pattern"], "tensor": out["tensor"], "tensor_counts": out["tensor_counts"],
            "standby": out["standby"], "scrub": out["scrub"], "init": out["init"], "thermal_handoff": out["thermal_handoff"]}
    with open(os.path.join(REPORTS, "sramlab_energy.json"), "w") as f:
        json.dump(slim, f, indent=1, default=str)
    # ---- plots
    p = Plot("Energy per useful byte by pattern - MODEL x ASSUMED-PARAMETER (not a measurement)", "benchmark pattern (0 SEQ_SCALAR4 ... 8 RANDOM_PART4)", "pJ per useful byte (assumed, nominal)",
             subtitle="access counts: validated cycle model; energies: params_assumed.json; pattern 0 counts only the 25 % of requests that reach an array")
    for ecc, col, mk in ((0, "#1f6feb", "circle"), (1, "#d1242f", "square")):
        pts = [x for x in out["benchmarks"] if x["ecc"] == ecc and "ALIGN_MODE" not in x["pattern_name"]]
        p.add(f"dynamic, ECC={ecc} (ASSUMED-PARAMETER x MODEL)", [x["pattern"] for x in pts], [x["pJ_per_useful_byte_dynamic"] for x in pts], "line+marker", col, mk)
    path = os.path.join(REPORTS, "sramlab_energy_per_byte.svg")
    p.save(path)
    p = Plot("Sensitivity of conclusions, x0.25 .. x4 per ASSUMED parameter: MODEL value / nominal", "metric index (see table 2)", "metric / nominal",
             subtitle="markers: minimum and maximum over all one-at-a-time parameter variations; 1.0 = nominal; wide bars = parameter-dependent conclusion")
    mks = [m for m in names if m in sens["nominal"] and sens["nominal"][m]]
    lo = [min(v[m][0] for v in ro.values()) / sens["nominal"][m] for m in mks]
    hi = [max(v[m][1] for v in ro.values()) / sens["nominal"][m] for m in mks]
    xs = list(range(len(mks)))
    p.add("ASSUMED-PARAMETER sweep minimum / nominal", xs, lo, "marker", "#1f6feb", "triangle")
    p.add("ASSUMED-PARAMETER sweep maximum / nominal", xs, hi, "marker", "#d1242f", "diamond")
    p.add("nominal = 1", xs, [1.0] * len(xs), "line", "#57606a", None, "4 3")
    p.ylog = True
    for i, m in enumerate(mks):
        p.note(f"{i}: {names[m][:58]}")
    path = os.path.join(REPORTS, "sramlab_energy_sensitivity.svg")
    p.save(path)
