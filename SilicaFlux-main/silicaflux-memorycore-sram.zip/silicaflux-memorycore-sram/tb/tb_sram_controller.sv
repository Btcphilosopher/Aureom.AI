// =============================================================================
// SilicaFlux MemoryCore :: tb_sram_controller
// Self-checking verification of the NM-master x NB-bank SRAM controller.
//
// Reference model: a byte-accurate memory (ref_mem + ref_known).  Every request ACCEPTED by the
// DUT (valid && ready at a clock edge) is applied to the model at that edge, in acceptance order
// -- the serialisation point of the controller contract (docs/CONTRACT.md O3).  The model
// predicts, per master, the exact response {id, we, status, rdata}; responses are compared in
// acceptance order (O2).  Checked continuously: payload stability under backpressure, no response
// during flush, no acceptance during flush/quiesce, round-robin waiting bound (ARB=RR),
// transaction conservation (accepted == answered + flushed), and a final full-capacity readback
// of the memory against the model.  Deterministic: xorshift32 PRNG seeded by SEED.
//
// Tests (RESULT line per run):  T01 single write/read   T02 sequential + full-capacity readback
//   T03 random single master   T04 byte masking         T05 bank interleave placement
//   T06 bank conflicts+fairness T07 simultaneous masters T08 backpressure   T09 burst boundaries
//   T10 invalid addresses      T11 flush / reset / quiesce   T18 randomized multi-master
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_sram_controller #(
  parameter int NM = 4,
  parameter int NB = 4,
  parameter int DEPTH = 64,
  parameter int DW = 128,
  parameter int AW = 20,
  parameter int IDW = 8,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NSLOT = 8,
  parameter int ARB = `SF_ARB_RR,
  parameter int ALIGN_MODE = 1,
  parameter int INIT_ON_RESET = 1,
  parameter int SIM_INIT = 2,
  parameter int BACKEND = `SF_BACKEND_BEHAV,
  parameter int SEED = 32'h1234ABCD,
  parameter int NRAND = 1500,
  parameter int VERBOSE = 0
);
  localparam int BE_W      = DW / 8;
  localparam int LB        = $clog2(BE_W);
  localparam int CAP_LINES = NB * DEPTH;
  localparam int CAP_BYTES = CAP_LINES * BE_W;
  localparam int ROW_W     = $clog2(DEPTH);
  localparam int BW        = (NB > 1) ? $clog2(NB) : 1;
  localparam int R_ECC     = $clog2(DW + $clog2(DW + 1) + 1);
  localparam int STORE_W   = (ECC_EN != 0) ? DW + R_ECC + 1 : DW;
  localparam int FBW       = $clog2(STORE_W);

  // ------------------------------------------------------------ DUT
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic [NM-1:0]      m_req_valid, m_req_ready, m_req_we;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata;
  logic [NM*BE_W-1:0] m_req_be;
  logic [NM*IDW-1:0]  m_req_id;
  logic [NM-1:0]      m_rsp_valid, m_rsp_ready, m_rsp_we, m_rsp_ce;
  logic [NM*DW-1:0]   m_rsp_rdata;
  logic [NM*IDW-1:0]  m_rsp_id;
  logic [NM*3-1:0]    m_rsp_status;
  logic               flush_i = 1'b0, flush_busy_o, quiesce_i = 1'b0, idle_o, init_busy_o;
  logic [NB-1:0]      ev_ce_o, ev_ue_o, bank_acc_o;
  logic [NB*16-1:0]   ce_cnt_o, ue_cnt_o;
  logic [NB*32-1:0]   perf_acc_o, perf_conf_o, perf_busy_o;
  logic [NM*32-1:0]   perf_stall_o;
  logic [NB*STORE_W-1:0] tst_rdata_o;

  sf_sram_controller #(
    .NM(NM), .NB(NB), .DEPTH(DEPTH), .DW(DW), .AW(AW), .IDW(IDW), .READ_LATENCY(READ_LATENCY),
    .ECC_EN(ECC_EN), .NSLOT(NSLOT), .ARB(ARB), .ALIGN_MODE(ALIGN_MODE), .INIT_ON_RESET(INIT_ON_RESET),
    .SIM_INIT(SIM_INIT), .FAULT_INJECT(0), .BACKEND(BACKEND)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id),
    .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .flush_i(flush_i), .flush_busy_o(flush_busy_o), .quiesce_i(quiesce_i), .idle_o(idle_o),
    .init_start_i(1'b0), .init_busy_o(init_busy_o), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(ev_ce_o), .ev_ue_o(ev_ue_o), .ce_cnt_o(ce_cnt_o), .ue_cnt_o(ue_cnt_o),
    .perf_acc_o(perf_acc_o), .perf_conf_o(perf_conf_o), .perf_busy_o(perf_busy_o), .perf_stall_o(perf_stall_o),
    .bank_acc_o(bank_acc_o),
    .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0),
    .tst_rdata_o(tst_rdata_o),
    .fi_bank('0), .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0),
    .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  // ------------------------------------------------------------ PRNG (xorshift32, deterministic)
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int rndn(input int n);       // 0 .. n-1
    logic [31:0] r;
    r = rnd();
    return int'(r % 32'(n));
  endfunction
  function automatic logic [DW-1:0] mkdata();
    logic [DW-1:0] d;
    for (int w = 0; w < DW / 32; w++) d[w*32 +: 32] = rnd();
    return d;
  endfunction

  // ------------------------------------------------------------ reference model + scoreboard state
  typedef struct {
    logic we; logic [AW-1:0] addr; logic [DW-1:0] wdata; logic [BE_W-1:0] be; logic [IDW-1:0] id; int delay;
  } txn_t;
  typedef struct {
    logic we; logic [IDW-1:0] id; logic [2:0] status; logic [DW-1:0] data; logic [BE_W-1:0] kmask;
  } exp_t;

  // Per-master stimulus / expectation FIFOs are plain circular buffers (head/tail indices), not SystemVerilog
  // queues: Verilator 5.020 mis-simulates pop_front() on arrays of queues in some elaborations
  // (the whole queue vanished after one pop), and a testbench must not depend on that.
  localparam int QDEPTH = 16384;                 // >= the largest per-master stimulus backlog of any test
  localparam int EDEPTH = 512;                   // >= outstanding transactions per master (NSLOT) + slack
  txn_t qa [NM][QDEPTH];
  exp_t ea [NM][EDEPTH];
  int   qh [NM], qt [NM], eh [NM], et [NM];
  function automatic int  qsize(input int i);  return qt[i] - qh[i]; endfunction
  function automatic int  esize(input int i);  return et[i] - eh[i]; endfunction
  function automatic txn_t qfront(input int i); return qa[i][qh[i] % QDEPTH]; endfunction
  function automatic txn_t qpop(input int i);
    txn_t t;
    t = qa[i][qh[i] % QDEPTH]; qh[i] = qh[i] + 1; return t;
  endfunction
  function automatic void qpush(input int i, input txn_t t);
    qa[i][qt[i] % QDEPTH] = t; qt[i] = qt[i] + 1;
    if (qt[i] - qh[i] > QDEPTH) $fatal(1, "TB stimulus queue overflow");
  endfunction
  function automatic void qclear(input int i);  qh[i] = 0; qt[i] = 0; endfunction
  function automatic exp_t epop(input int i);
    exp_t e;
    e = ea[i][eh[i] % EDEPTH]; eh[i] = eh[i] + 1; return e;
  endfunction
  function automatic void epush(input int i, input exp_t e);
    ea[i][et[i] % EDEPTH] = e; et[i] = et[i] + 1;
    if (et[i] - eh[i] > EDEPTH) $fatal(1, "TB expectation FIFO overflow");
  endfunction
  function automatic void eclear(input int i);  eh[i] = 0; et[i] = 0; endfunction
  byte unsigned ref_mem   [CAP_BYTES];
  bit           ref_known [CAP_BYTES];

  int unsigned acc_cnt [NM], rsp_cnt [NM], drop_cnt [NM];
  int          dly [NM];
  logic [IDW-1:0] nextid [NM];
  int          rsp_pct = 100;                    // % of cycles a master asserts rsp_ready
  int          n_checks = 0, n_err = 0, n_tests = 0, test_err0 = 0;
  string       cur_test = "";
  longint      cycle = 0;
  int          rr_wait [NM];
  int          rr_max_wait = 0;
  bit          flush_window = 1'b0;
  bit          fair_check = 1'b0;
  logic [NM-1:0] prev_rv, prev_rr;
  logic [NM*DW-1:0] prev_rdata; logic [NM*IDW-1:0] prev_rid; logic [NM*3-1:0] prev_rst;

  task automatic fail(input string msg);
    n_err++;
    if (n_err <= 25) $display("  [FAIL] %s @cycle %0d (%s)", msg, cycle, cur_test);
  endtask
  task automatic check(input bit cond, input string msg);
    n_checks++;
    if (!cond) fail(msg);
  endtask

  function automatic int model_status(input logic [AW-1:0] a);
    int line;
    line = int'(a >> LB);
    if (line >= CAP_LINES) return int'(`SF_ST_RANGE);
    if (ALIGN_MODE != 0 && (a & AW'(BE_W - 1)) != '0) return int'(`SF_ST_ALIGN);
    return int'(`SF_ST_OK);
  endfunction

  // ------------------------------------------------------------ monitor: acceptance -> model, response -> compare
  always @(posedge clk) begin
    cycle <= cycle + 1;
    if (rst_n) begin
      if (flush_i) begin
        for (int i = 0; i < NM; i++) begin drop_cnt[i] += esize(i); eclear(i); end
        flush_window = 1'b1;
      end
      // the window covers exactly the cycles in which the DUT reports flush_busy_o (or flush_i)
      if (flush_window && !flush_busy_o && !flush_i) flush_window = 1'b0;
      if (flush_window) begin
        check((m_rsp_valid == '0), "response presented during flush");
        check((m_req_valid & m_req_ready) == '0, "request accepted during flush");
      end
      if (quiesce_i) check((m_req_valid & m_req_ready) == '0, "request accepted during quiesce");

      for (int i = 0; i < NM; i++) begin
        // ---- acceptance
        if (m_req_valid[i] && m_req_ready[i]) begin
          logic [AW-1:0] a; logic [DW-1:0] wd; logic [BE_W-1:0] be; exp_t e; int st; int base;
          a  = m_req_addr[i*AW +: AW]; wd = m_req_wdata[i*DW +: DW]; be = m_req_be[i*BE_W +: BE_W];
          st = model_status(a);
          e.we = m_req_we[i]; e.id = m_req_id[i*IDW +: IDW]; e.status = 3'(st); e.data = '0; e.kmask = '1;
          if (st == int'(`SF_ST_OK)) begin
            base = int'(a >> LB) * BE_W;
            if (m_req_we[i]) begin
              for (int l = 0; l < BE_W; l++)
                if (be[l]) begin ref_mem[base + l] = wd[l*8 +: 8]; ref_known[base + l] = 1'b1; end
            end else begin
              for (int l = 0; l < BE_W; l++) begin
                e.data[l*8 +: 8] = ref_mem[base + l];
                e.kmask[l] = ref_known[base + l];
              end
            end
          end
          epush(i, e);
          acc_cnt[i]++;
          // round-robin waiting bound: other masters granted the same bank while this one was pending
        end
        // ---- response
        if (m_rsp_valid[i] && m_rsp_ready[i]) begin
          if (esize(i) == 0) begin
            fail($sformatf("master %0d: unexpected response (none outstanding)", i));
          end else begin
            exp_t e;
            e = epop(i);
            rsp_cnt[i]++;
            check(m_rsp_id[i*IDW +: IDW] == e.id,        $sformatf("master %0d: response id %0h != %0h (order)", i, m_rsp_id[i*IDW +: IDW], e.id));
            check(m_rsp_we[i] == e.we,                   $sformatf("master %0d: response we mismatch", i));
            check(m_rsp_status[i*3 +: 3] == e.status,    $sformatf("master %0d: status %0d != %0d", i, m_rsp_status[i*3 +: 3], e.status));
            if (!e.we && e.status == `SF_ST_OK) begin
              for (int l = 0; l < BE_W; l++)
                if (e.kmask[l]) check(m_rsp_rdata[i*DW + l*8 +: 8] == e.data[l*8 +: 8],
                                      $sformatf("master %0d: byte %0d read %0h != %0h", i, l, m_rsp_rdata[i*DW + l*8 +: 8], e.data[l*8 +: 8]));
            end else begin
              check(m_rsp_rdata[i*DW +: DW] == '0, $sformatf("master %0d: write/error response rdata not zero", i));
            end
          end
        end
        // ---- payload stability while stalled
        if (prev_rv[i] && !prev_rr[i]) begin
          check(m_rsp_valid[i], $sformatf("master %0d: response withdrawn", i));
          check(m_rsp_rdata[i*DW +: DW] == prev_rdata[i*DW +: DW] && m_rsp_id[i*IDW +: IDW] == prev_rid[i*IDW +: IDW] &&
                m_rsp_status[i*3 +: 3] == prev_rst[i*3 +: 3], $sformatf("master %0d: response payload changed while stalled", i));
        end
      end
      prev_rv <= m_rsp_valid; prev_rr <= m_rsp_ready; prev_rdata <= m_rsp_rdata; prev_rid <= m_rsp_id; prev_rst <= m_rsp_status;
    end
  end

  // round-robin fairness monitor (per bank, only requests that can compete: slots available, in range)
  always @(posedge clk) if (rst_n && fair_check && ARB == `SF_ARB_RR && !flush_i) begin
    for (int i = 0; i < NM; i++) begin
      logic [AW-1:0] ai; int bi; bit comp;
      ai = m_req_addr[i*AW +: AW];
      bi = (NB > 1) ? int'((ai >> LB) % NB) : 0;
      comp = m_req_valid[i] && (model_status(ai) == int'(`SF_ST_OK)) && dut.can_alloc[i];
      if (comp && m_req_ready[i]) begin
        if (rr_wait[i] > rr_max_wait) rr_max_wait = rr_wait[i];
        check(rr_wait[i] <= NM - 1, $sformatf("master %0d waited %0d > NM-1 grants (RR bound)", i, rr_wait[i]));
        rr_wait[i] = 0;
      end else if (comp) begin
        for (int j = 0; j < NM; j++) begin
          logic [AW-1:0] aj; int bj;
          aj = m_req_addr[j*AW +: AW];
          bj = (NB > 1) ? int'((aj >> LB) % NB) : 0;
          if (j != i && m_req_valid[j] && m_req_ready[j] && bj == bi) rr_wait[i]++;
        end
      end else rr_wait[i] = 0;
    end
  end

  // ------------------------------------------------------------ master drivers + response ready
  always @(posedge clk) begin
    if (!rst_n) begin
      m_req_valid <= '0; m_rsp_ready <= '0;
    end else begin
      for (int i = 0; i < NM; i++) begin
        logic accepted;
        accepted = m_req_valid[i] && m_req_ready[i];
        if (accepted) m_req_valid[i] <= 1'b0;
        if ((!m_req_valid[i] || accepted) && qsize(i) > 0) begin
          if (dly[i] >= qfront(i).delay) begin
            txn_t t;
            t = qpop(i);
            m_req_valid[i] <= 1'b1; m_req_we[i] <= t.we; m_req_addr[i*AW +: AW] <= t.addr;
            m_req_wdata[i*DW +: DW] <= t.wdata; m_req_be[i*BE_W +: BE_W] <= t.be; m_req_id[i*IDW +: IDW] <= t.id;
            dly[i] = 0;
          end else dly[i] = dly[i] + 1;
        end
        m_rsp_ready[i] <= (rndn(100) < rsp_pct);
      end
    end
  end

  // ------------------------------------------------------------ helpers
  task automatic enq(input int m, input bit we, input logic [AW-1:0] addr, input logic [DW-1:0] wd,
                     input logic [BE_W-1:0] be, input int delay = 0);
    txn_t t;
    t.we = we; t.addr = addr; t.wdata = wd; t.be = be; t.id = nextid[m]; t.delay = delay;
    nextid[m] = nextid[m] + 1'b1;
    qpush(m, t);
  endtask
  function automatic logic [AW-1:0] laddr(input int line);     // byte address of a line
    return AW'(line) << LB;
  endfunction

  task automatic wait_drain(input int max_cycles = 200000);
    int n;
    bit busy;
    n = 0;
    do begin
      @(posedge clk);
      n++;
      busy = (idle_o == 1'b0) || (m_req_valid != '0);
      for (int i = 0; i < NM; i++) if (qsize(i) != 0 || esize(i) != 0) busy = 1'b1;
    end while (busy && n < max_cycles);
    if (busy) fail("drain timeout (deadlock or lost transaction)");
    repeat (2) @(posedge clk);
    for (int i = 0; i < NM; i++) begin
      check(acc_cnt[i] == rsp_cnt[i] + drop_cnt[i], $sformatf("conservation: master %0d accepted %0d != answered %0d + flushed %0d", i, acc_cnt[i], rsp_cnt[i], drop_cnt[i]));
    end
  endtask

  task automatic test_begin(input string name);
    cur_test = name; test_err0 = n_err; n_tests++;
    $display("[%0t] %s", $time, name);
  endtask
  task automatic test_end();
    $display("    %s: %s (errors so far %0d)", cur_test, (n_err == test_err0) ? "PASS" : "FAIL", n_err);
  endtask

  task automatic sweep_readback(input int m);       // read every line of the capacity
    rsp_pct = 100;
    for (int ln = 0; ln < CAP_LINES; ln++) enq(m, 1'b0, laddr(ln), '0, '1);
    wait_drain();
  endtask

  task automatic do_reset(input int cycles);
    rst_n = 1'b0;
    for (int i = 0; i < NM; i++) begin qclear(i); eclear(i); dly[i] = 0; end
    repeat (cycles) @(posedge clk);
    for (int i = 0; i < NM; i++) begin acc_cnt[i] = 0; rsp_cnt[i] = 0; drop_cnt[i] = 0; end
    if (INIT_ON_RESET != 0 || ECC_EN != 0) begin
      for (int b = 0; b < CAP_BYTES; b++) begin ref_mem[b] = 8'h00; ref_known[b] = 1'b1; end
    end else begin
      for (int b = 0; b < CAP_BYTES; b++) begin ref_mem[b] = 8'h00; ref_known[b] = 1'b0; end
    end
    @(negedge clk);
    rst_n = 1'b1;
    repeat (3) @(posedge clk);
    while (init_busy_o) @(posedge clk);
    repeat (2) @(posedge clk);
  endtask

  // backdoor dump of the bank arrays (non-ECC: stored word == data)
  logic [STORE_W-1:0] dump [NB*DEPTH];
  logic dump_req = 1'b0;
  if (BACKEND == `SF_BACKEND_BEHAV) begin : g_dump_en
    for (genvar b = 0; b < NB; b++) begin : g_dump
      always @(dump_req) begin
        for (int r = 0; r < DEPTH; r++) dump[b*DEPTH + r] = dut.g_bank[b].u_bank.u_core.g_behav.u_mem.mem[r];
      end
    end
  end

  // ------------------------------------------------------------ tests
  int cyc0, cyc1;
  logic [DW-1:0] dtmp;

  task automatic t01_single();
    test_begin("T01 single write/read");
    rsp_pct = 100;
    enq(0, 1'b1, laddr(5), 128'hDEADBEEF_CAFEF00D_0123456789ABCDEF, '1);
    enq(0, 1'b0, laddr(5), '0, '1);
    wait_drain();
    test_end();
  endtask

  task automatic t02_sequential();
    test_begin("T02 sequential addresses + full-capacity readback");
    rsp_pct = 100;
    for (int ln = 0; ln < CAP_LINES; ln++) enq(0, 1'b1, laddr(ln), mkdata(), '1);
    for (int ln = 0; ln < CAP_LINES; ln++) enq(0, 1'b0, laddr(ln), '0, '1);
    wait_drain();
    test_end();
  endtask

  task automatic t03_random_single();
    test_begin("T03 random address traffic (single master)");
    rsp_pct = 100;
    for (int n = 0; n < NRAND; n++) begin
      logic [BE_W-1:0] be;
      be = (rndn(2) == 0) ? '1 : BE_W'(rnd());
      enq(0, rndn(2) == 1, laddr(rndn(CAP_LINES)), mkdata(), be, rndn(3) == 0 ? rndn(3) : 0);
    end
    wait_drain();
    test_end();
  endtask

  task automatic t04_bytemask();
    test_begin("T04 byte masking");
    rsp_pct = 100;
    for (int l = 0; l < BE_W; l++) begin                       // each lane alone
      enq(0, 1'b1, laddr(7), '0, '1);
      enq(0, 1'b1, laddr(7), {DW{1'b1}}, BE_W'(1) << l);
      enq(0, 1'b0, laddr(7), '0, '1);
    end
    enq(0, 1'b1, laddr(9), mkdata(), '1);                        // be == 0 write is a no-op
    enq(0, 1'b1, laddr(9), mkdata(), '0);
    enq(0, 1'b0, laddr(9), '0, '1);
    for (int n = 0; n < 200; n++) begin                          // random strobes, read after each
      int ln;
      ln = rndn(CAP_LINES);
      enq(0, 1'b1, laddr(ln), mkdata(), BE_W'(rnd()));
      enq(0, 1'b0, laddr(ln), '0, '1);
    end
    // alternating halves / nibbles / sparse patterns
    for (int p = 0; p < 6; p++) begin
      logic [BE_W-1:0] be;
      case (p)
        0: be = 16'h00FF; 1: be = 16'hFF00; 2: be = 16'h0F0F; 3: be = 16'hAAAA; 4: be = 16'h5555; default: be = 16'h8001;
      endcase
      enq(0, 1'b1, laddr(11), mkdata(), BE_W'(be));
      enq(0, 1'b0, laddr(11), '0, '1);
    end
    wait_drain();
    test_end();
  endtask

  task automatic t05_interleave();
    logic [DW-1:0] d [CAP_LINES];
    test_begin("T05 bank interleaving (address -> bank/row placement)");
    rsp_pct = 100;
    for (int ln = 0; ln < CAP_LINES; ln++) begin
      d[ln] = mkdata();
      enq(ln % NM, 1'b1, laddr(ln), d[ln], '1);
    end
    wait_drain();
    if (ECC_EN == 0 && BACKEND == `SF_BACKEND_BEHAV) begin
      dump_req = ~dump_req; #1;
      for (int ln = 0; ln < CAP_LINES; ln++)
        check(dump[(ln % NB) * DEPTH + (ln / NB)] == STORE_W'(d[ln]),
              $sformatf("line %0d not at bank %0d row %0d", ln, ln % NB, ln / NB));
    end else begin
      $display("    (ECC or non-behavioural backend: placement checked through readback only)");
    end
    for (int ln = 0; ln < CAP_LINES; ln++) enq(ln % NM, 1'b0, laddr(ln), '0, '1);
    wait_drain();
    test_end();
  endtask

  task automatic t06_conflicts();
    longint c0;
    int n, acc0;
    test_begin("T06 bank conflicts (all masters -> bank 0) and arbitration fairness");
    rsp_pct = 100; n = 80; fair_check = 1'b1;
    for (int i = 0; i < NM; i++) begin rr_wait[i] = 0; end
    acc0 = int'(perf_acc_o[31:0]);
    c0 = cycle;
    for (int i = 0; i < NM; i++)
      for (int k = 0; k < n; k++) enq(i, (k % 4 == 0), laddr(((k * 7 + i) % DEPTH) * NB), mkdata(), '1);
    wait_drain();
    fair_check = 1'b0;
    $display("    bank-0 accesses %0d in %0d cycles (>= %0d expected: one access per bank per cycle); conflict cycles %0d; max RR wait %0d",
             int'(perf_acc_o[31:0]) - acc0, cycle - c0, NM * n, perf_conf_o[31:0], rr_max_wait);
    check((cycle - c0) >= NM * n, "bank accepted more than one access per cycle");
    if (NM >= 2) check(perf_conf_o[31:0] > 0, "no conflict recorded although every master hits bank 0");
    check(int'(perf_acc_o[31:0]) - acc0 == NM * n, "bank-0 accepted-access count != requests");
    test_end();
  endtask

  task automatic t07_parallel();
    longint c0;
    int n;
    test_begin("T07 simultaneous masters on independent banks (1 access / bank / cycle)");
    rsp_pct = 100; n = 200;
    c0 = cycle;
    for (int i = 0; i < NM; i++)
      for (int k = 0; k < n; k++) enq(i, 1'b0, laddr(((k % DEPTH) * NB) + (i % NB)), '0, '1);
    wait_drain();
    $display("    %0d masters x %0d reads on distinct banks: %0d cycles (ideal ~%0d + latency)", NM, n, cycle - c0, n);
    if (NM <= NB) check((cycle - c0) <= n + READ_LATENCY + 12, "independent banks did not proceed in parallel");
    test_end();
  endtask

  task automatic t08_backpressure();
    test_begin("T08 backpressure (slow response consumers, request gaps)");
    for (int pass = 0; pass < 3; pass++) begin
      rsp_pct = (pass == 0) ? 20 : (pass == 1) ? 5 : 60;
      for (int i = 0; i < NM; i++)
        for (int k = 0; k < 150; k++) begin
          int ln;
          ln = rndn(CAP_LINES);
          enq(i, rndn(3) == 0, laddr(ln), mkdata(), (rndn(2) == 0) ? '1 : BE_W'(rnd()), rndn(4) == 0 ? rndn(5) : 0);
        end
      wait_drain();
    end
    rsp_pct = 100;
    test_end();
  endtask

  task automatic t09_boundaries();
    test_begin("T09 burst boundaries (bank wrap, row wrap, aperture end)");
    rsp_pct = 100;
    for (int ln = NB - 2; ln < NB + 6; ln++) enq(0, 1'b1, laddr(ln), mkdata(), '1);              // across bank wrap
    for (int ln = NB - 2; ln < NB + 6; ln++) enq(0, 1'b0, laddr(ln), '0, '1);
    for (int ln = CAP_LINES - 6; ln < CAP_LINES; ln++) enq(1 % NM, 1'b1, laddr(ln), mkdata(), '1); // last lines of the aperture
    for (int ln = CAP_LINES - 6; ln < CAP_LINES; ln++) enq(1 % NM, 1'b0, laddr(ln), '0, '1);
    for (int ln = CAP_LINES - 2; ln < CAP_LINES + 3; ln++) enq(2 % NM, ln >= CAP_LINES - 1, laddr(ln), mkdata(), '1); // run over the end
    for (int r = 0; r < DEPTH; r += (DEPTH > 8 ? DEPTH / 8 : 1))                                    // first / last row of every bank
      for (int b = 0; b < NB; b++) begin
        enq(0, 1'b1, laddr(r * NB + b), mkdata(), '1);
        enq(0, 1'b0, laddr(r * NB + b), '0, '1);
      end
    wait_drain();
    test_end();
  endtask

  task automatic t10_invalid();
    test_begin("T10 invalid addresses (range, misaligned) have no side effect");
    rsp_pct = 100;
    for (int p = 0; p < 6; p++) begin
      logic [AW-1:0] a;
      case (p)
        0: a = AW'(CAP_BYTES);                       // first byte beyond the aperture
        1: a = AW'(CAP_BYTES + BE_W);
        2: a = AW'((1 << AW) - BE_W);                // top of the address space
        3: a = AW'(CAP_BYTES + 3);                   // out of range AND misaligned: RANGE wins
        4: a = AW'(BE_W * 5 + 1);                    // misaligned inside the aperture
        default: a = AW'(BE_W * 5 + BE_W - 1);
      endcase
      enq(0, 1'b1, a, {DW{1'b1}}, '1);               // would corrupt memory if it had a side effect
      enq(0, 1'b0, a, '0, '1);
    end
    for (int k = 1; k < BE_W; k++) enq(1 % NM, 1'b1, laddr(3) + AW'(k), mkdata(), '1);   // every misaligned offset
    wait_drain();
    sweep_readback(0);                                // full readback: nothing changed
    test_end();
  endtask

  task automatic t11_flush_reset();
    int unsigned qacc0;
    test_begin("T11 reset, flush and quiesce");
    rsp_pct = 100;
    // ---- flush in the middle of heavy traffic
    for (int i = 0; i < NM; i++)
      for (int k = 0; k < 200; k++) enq(i, rndn(2) == 1, laddr(rndn(CAP_LINES)), mkdata(), '1);
    repeat (40) @(posedge clk);
    @(negedge clk); flush_i = 1'b1; @(negedge clk); flush_i = 1'b0;
    wait_drain();
    sweep_readback(1 % NM);
    // ---- quiesce blocks acceptance, release resumes
    quiesce_i = 1'b1;
    repeat (3) @(posedge clk);                                   // let anything already presented settle
    qacc0 = acc_cnt[0];
    enq(0, 1'b0, laddr(1), '0, '1);
    repeat (20) @(posedge clk);
    check(acc_cnt[0] == qacc0, "quiesce: a request was accepted while quiesce_i was high");
    check(qsize(0) != 0 || m_req_valid[0] == 1'b1, "quiesce: the request disappeared instead of waiting");
    quiesce_i = 1'b0;
    wait_drain();
    check(acc_cnt[0] == qacc0 + 1, "quiesce: request not accepted after release");
    // ---- reset in the middle of traffic
    for (int i = 0; i < NM; i++)
      for (int k = 0; k < 100; k++) enq(i, rndn(2) == 1, laddr(rndn(CAP_LINES)), mkdata(), '1);
    repeat (30) @(posedge clk);
    do_reset(4);
    // after reset the controller must work and show no stale responses
    enq(0, 1'b1, laddr(2), mkdata(), '1);
    enq(0, 1'b0, laddr(2), '0, '1);
    wait_drain();
    test_end();
  endtask

  task automatic t18_random_multi();
    test_begin("T18 randomized multi-master traffic (hot lines, strobes, backpressure, invalid addresses)");
    for (int pass = 0; pass < 3; pass++) begin
      rsp_pct = (pass == 0) ? 100 : (pass == 1) ? 50 : 12;
      for (int i = 0; i < NM; i++)
        for (int k = 0; k < NRAND / 3; k++) begin
          int ln, r;
          logic [AW-1:0] a;
          logic [BE_W-1:0] be;
          r = rndn(100);
          if (r < 55)      ln = rndn(8);                        // hot set: forces RAW/WAW across masters
          else             ln = rndn(CAP_LINES);
          a = laddr(ln);
          if (r >= 97)      a = laddr(CAP_LINES + rndn(64));    // ~3 % out of range
          else if (r >= 94) a = laddr(ln) + AW'(1 + rndn(BE_W - 1));   // ~3 % misaligned
          be = (rndn(2) == 0) ? '1 : BE_W'(rnd());
          enq(i, rndn(2) == 1, a, mkdata(), be, rndn(5) == 0 ? rndn(4) : 0);
        end
      wait_drain();
    end
    rsp_pct = 100;
    sweep_readback(0);
    test_end();
  endtask

  // ------------------------------------------------------------ main
  initial begin
    for (int i = 0; i < NM; i++) begin qclear(i); eclear(i); dly[i] = 0; nextid[i] = IDW'(i * 37); rr_wait[i] = 0;
      acc_cnt[i] = 0; rsp_cnt[i] = 0; drop_cnt[i] = 0; end
    m_req_valid = '0; m_req_we = '0; m_req_addr = '0; m_req_wdata = '0; m_req_be = '0; m_req_id = '0; m_rsp_ready = '0;
    prev_rv = '0; prev_rr = '0;
    do_reset(5);
    $display("CONFIG NM=%0d NB=%0d DEPTH=%0d DW=%0d READ_LATENCY=%0d ECC_EN=%0d NSLOT=%0d ARB=%0d ALIGN_MODE=%0d INIT_ON_RESET=%0d BACKEND=%0d SEED=%0h",
             NM, NB, DEPTH, DW, READ_LATENCY, ECC_EN, NSLOT, ARB, ALIGN_MODE, INIT_ON_RESET, BACKEND, SEED);
    if (INIT_ON_RESET == 0 && ECC_EN == 0) begin
      // memory is not reset: the model only knows bytes written so far (ref_known)
    end
    t01_single();
    t02_sequential();
    t03_random_single();
    t04_bytemask();
    t05_interleave();
    t06_conflicts();
    t07_parallel();
    t08_backpressure();
    t09_boundaries();
    t10_invalid();
    t11_flush_reset();
    t18_random_multi();
    sweep_readback(0);
    $display("RESULT tb=sram_controller NM=%0d NB=%0d READ_LATENCY=%0d ECC_EN=%0d NSLOT=%0d ARB=%0d INIT_ON_RESET=%0d BACKEND=%0d tests=%0d checks=%0d errors=%0d cycles=%0d %s",
             NM, NB, READ_LATENCY, ECC_EN, NSLOT, ARB, INIT_ON_RESET, BACKEND, n_tests, n_checks, n_err, cycle, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #(64'd400_000_000);
    $display("RESULT tb=sram_controller errors=1 WATCHDOG TIMEOUT FAIL");
    $finish;
  end
endmodule
