// =============================================================================
// SilicaFlux MemoryCore :: tb_bench_ctrl
// Deterministic traffic benchmark of sf_sram_controller.  NM masters each issue NREQ requests back to back (a request is
// presented as soon as the previous one is accepted).  The workload is a PURE FUNCTION of (PATTERN, master, index, SEED) so
// that tools/sramlab reproduces the identical address stream and can be compared cycle by cycle with this RTL run.
//
// PRNG: xorshift32 (13,17,5); per-master state  s_m = SEED ^ ((m+1) * 32'h9E3779B9); one draw per request (draw order: the
// k-th request of master m uses the k-th draw of s_m, for every pattern, whether or not the pattern uses it).
// Patterns (line = 16 B line index, REGION = CAP_LINES / NM lines, base_m = m * REGION):
//   0 SEQ_SCALAR4   read   line = base_m + ((k/4 + m) mod REGION), line-aligned address (ALIGN_MODE=1 rejects sub-line addresses: the byte
//                          offset of a scalar load inside the line is NOT part of the controller address) ... 4 useful bytes per access
//   1 SEQ_LINE      read   line = base_m + (k mod REGION)                                16 useful bytes
//   2 OWN_BANK      read   line = ((k*NB + (m mod NB)) mod CAP_LINES)                    16 B, master m only touches bank m mod NB
//   3 SAME_BANK     read   line = (((k + m*37) * NB) mod CAP_LINES)                      16 B, everybody on bank 0
//   4 RANDOM_LINE   read   line = draw mod CAP_LINES                                     16 B
//   5 RANDOM_RW     read or write by draw bit 0 (1 = write), line = (draw >> 1) mod CAP_LINES, full-line write, 16 B
//   6 SEQ_WRITE_FULL  write line = base_m + (k mod REGION), be = all ones                16 B
//   7 SEQ_WRITE_PART4 write line = base_m + (k mod REGION), be = 16'h000F                4 useful bytes (RMW with ECC)
//   8 RANDOM_PART4  read or write by draw bit 0, line = (draw >> 1) mod CAP_LINES, writes be = 16'h000F; 4 B per access
// Runtime plusargs: +PATTERN= +NREQ= +RSP_PCT= (response ready probability) +LOAD_PCT= (probability per cycle that an idle master presents
// a request: xs(cycle*2654435 ^ (m<<16) ^ 0x5A5A5A5A) % 100 < LOAD_PCT) +SEED=
// Output: BENCH ctrl ... throughput in useful bytes per cycle, bank conflict cycles, mean / max latency (cycles from the
// first cycle a request is presented to the cycle its response is accepted), max outstanding of MASTER 0 (max_out[0]); the controller's own per-master maximum is not reported here.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_bench_ctrl #(
  parameter int NM = 4,
  parameter int NB = 4,
  parameter int DEPTH = 256,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NSLOT = 8,
  parameter int ARB = `SF_ARB_RR,
  parameter int PATTERN = 1,
  parameter int NREQ = 1000,
  parameter int RSP_PCT = 100,
  parameter int SEED = 32'h00C0FFEE
);
  localparam int AW = 20, DW = 128, IDW = 8, LB = 4, BE_W = 16;
  localparam int CAP_LINES = NB * DEPTH;
  localparam int REGION = CAP_LINES / NM;
  localparam int R_ECC = $clog2(DW + $clog2(DW + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? DW + R_ECC + 1 : DW;
  localparam int BW = (NB > 1) ? $clog2(NB) : 1;
  localparam int ROW_W = $clog2(DEPTH);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  logic [NM-1:0] m_req_valid = '0, m_req_ready, m_req_we = '0, m_rsp_valid, m_rsp_ready = '0, m_rsp_we, m_rsp_ce;
  logic [NM*AW-1:0] m_req_addr = '0;
  logic [NM*DW-1:0] m_req_wdata = '0, m_rsp_rdata;
  logic [NM*BE_W-1:0] m_req_be = '0;
  logic [NM*IDW-1:0] m_req_id = '0, m_rsp_id;
  logic [NM*3-1:0] m_rsp_status;
  logic idle, init_busy;
  logic [NB*32-1:0] perf_acc, perf_conf, perf_busy;
  logic [NM*32-1:0] perf_stall;
  logic [NB*STORE_W-1:0] tst_rdata;

  sf_sram_controller #(.NM(NM), .NB(NB), .DEPTH(DEPTH), .DW(DW), .AW(AW), .IDW(IDW), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
                       .NSLOT(NSLOT), .ARB(ARB), .INIT_ON_RESET(1), .SIM_INIT(2)) dut (
    .clk(clk), .rst_n(rst_n), .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(1'b0), .idle_o(idle), .init_start_i(1'b0), .init_busy_o(init_busy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(), .ev_ue_o(), .ce_cnt_o(), .ue_cnt_o(), .perf_acc_o(perf_acc), .perf_conf_o(perf_conf),
    .perf_busy_o(perf_busy), .perf_stall_o(perf_stall), .bank_acc_o(),
    .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0), .tst_rdata_o(tst_rdata),
    .fi_bank('0), .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  // ---------------------------------------------------------------- workload generator (pure function of the arguments)
  function automatic logic [31:0] xs(input logic [31:0] x);
    logic [31:0] y;
    y = x ^ (x << 13); y = y ^ (y >> 17); y = y ^ (y << 5);
    return y;
  endfunction

  // runtime-selectable (plusargs +PATTERN= +NREQ= +RSP_PCT= +LOAD_PCT= +SEED=); the parameters give the defaults
  int pat = PATTERN, nreq = NREQ, rsp_pct = RSP_PCT, load_pct = 100, seed_v = SEED;
  logic [31:0] rs [NM];
  int issued [NM], done_n [NM], outst [NM], max_out [NM], useful_per [NM];
  longint lat_sum = 0;
  int lat_max = 0, lat_n = 0;
  longint t_first_valid [NM][16];            // presentation time of the oldest outstanding request (ring, per master)
  int th [NM], tt [NM];
  int r_rd = 0, r_wr = 0;
  longint cycle = 0, c_start = 0, c_end = 0;
  bit started = 0;
  longint useful_bytes = 0;
  int conf0, busy0;

  function automatic void gen(input int m, input int k, input logic [31:0] draw,
                              output logic we, output logic [AW-1:0] a, output logic [BE_W-1:0] be, output int useful);
    int ln, base;
    base = m * REGION;
    we = 1'b0; be = '1; useful = 16; ln = 0;
    case (pat)
      0: begin ln = base + ((k / (16 / 4) + m) % REGION); useful = 4; end   // 4 B scalar load = a line-aligned read; 4 consecutive loads share a line; masters staggered by one line (= one bank)
      1: begin ln = base + (k % REGION); end
      2: begin ln = (k * NB + (m % NB)) % CAP_LINES; end
      3: begin ln = ((k + m * 37) * NB) % CAP_LINES; end
      4: begin ln = int'(draw % 32'(CAP_LINES)); end
      5: begin we = draw[0]; ln = int'((draw >> 1) % 32'(CAP_LINES)); end
      6: begin we = 1'b1; ln = base + (k % REGION); end
      7: begin we = 1'b1; ln = base + (k % REGION); be = 16'h000F; useful = 4; end
      default: begin we = draw[0]; ln = int'((draw >> 1) % 32'(CAP_LINES)); if (we) be = 16'h000F; useful = 4; end
    endcase
    a = AW'(ln) << LB;
  endfunction

  // ---------------------------------------------------------------- drivers / monitors
  // Cycle convention (shared with tools/sramlab): `cycle` is the number of rising edges seen BEFORE the current one.  A request
  // presented in the always block at edge E (cycle == E) is visible during the cycle after E and can be accepted at edge E+1.
  // latency of a request = (cycle at the edge where its response is accepted) - (cycle at the edge where it was presented).
  // total cycles = (cycle at the edge of the last response acceptance) - (cycle at the first presentation edge).
  int gcount [NM];
  bit all_done = 0;
  bit trace = $test$plusargs("DASHTRACE");
  int trace_n = 0;
  always @(posedge clk) begin
    cycle <= cycle + 1;
    if (rst_n && started) begin
      for (int m = 0; m < NM; m++) begin
        logic accepted;
        accepted = m_req_valid[m] && m_req_ready[m];
        if (accepted) begin
          issued[m]++; outst[m]++;
          if (outst[m] > max_out[m]) max_out[m] = outst[m];
          if (m_req_we[m]) r_wr++; else r_rd++;
          if (trace && trace_n < 600) begin
            trace_n++;
            $display("DT ctrl acc cycle=%0d master=%0d bank=%0d row=%0d we=%0d", cycle, m, (NB > 1) ? int'((m_req_addr[m*AW +: AW] >> LB) % NB) : 0,
                     (NB > 1) ? int'((m_req_addr[m*AW +: AW] >> LB) / NB) : int'(m_req_addr[m*AW +: AW] >> LB), m_req_we[m]);
          end
          m_req_valid[m] <= 1'b0;
        end
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          longint l;
          done_n[m]++; outst[m]--;
          l = cycle - t_first_valid[m][th[m] % 16]; th[m]++;
          if (trace && trace_n < 600) $display("DT ctrl rsp cycle=%0d master=%0d latency=%0d", cycle, m, int'(l));
          lat_sum += l; lat_n++; if (int'(l) > lat_max) lat_max = int'(l);
        end
        if ((!m_req_valid[m] || accepted) && gcount[m] < nreq && ((load_pct >= 100) || ((xs(cycle[31:0] * 32'd2654435 ^ (32'(m) << 16) ^ 32'h5A5A5A5A) % 100) < load_pct))) begin
          logic we; logic [AW-1:0] a; logic [BE_W-1:0] be; int u;
          rs[m] = xs(rs[m]);
          gen(m, gcount[m], rs[m], we, a, be, u);
          m_req_valid[m] <= 1'b1; m_req_we[m] <= we; m_req_addr[m*AW +: AW] <= a;
          m_req_wdata[m*DW +: DW] <= {4{rs[m]}}; m_req_be[m*BE_W +: BE_W] <= be; m_req_id[m*IDW +: IDW] <= IDW'(gcount[m]);
          t_first_valid[m][tt[m] % 16] = cycle; tt[m]++;
          useful_bytes += u; gcount[m]++;
          if (c_start == 0) c_start = cycle;
        end
        m_rsp_ready[m] <= (rsp_pct >= 100) ? 1'b1 : ((xs(cycle[31:0] ^ (32'(m) << 8)) % 100) < rsp_pct);
      end
      all_done = 1'b1;
      for (int m = 0; m < NM; m++) if (done_n[m] < nreq) all_done = 1'b0;
      if (all_done && c_end == 0) c_end = cycle;
    end
  end

  initial begin
    void'($value$plusargs("PATTERN=%d", pat)); void'($value$plusargs("NREQ=%d", nreq)); void'($value$plusargs("RSP_PCT=%d", rsp_pct));
    void'($value$plusargs("LOAD_PCT=%d", load_pct)); void'($value$plusargs("SEED=%d", seed_v));
    for (int m = 0; m < NM; m++) begin
      rs[m] = seed_v ^ (32'(m + 1) * 32'h9E3779B9);
      issued[m] = 0; done_n[m] = 0; outst[m] = 0; max_out[m] = 0; th[m] = 0; tt[m] = 0; gcount[m] = 0;
    end
    repeat (6) @(posedge clk); rst_n = 1'b1;
    repeat (CAP_LINES / NB + 16) @(posedge clk);
    while (!idle || init_busy) @(posedge clk);
    repeat (4) @(posedge clk);
    conf0 = 0; busy0 = 0;
    for (int b = 0; b < NB; b++) begin conf0 += int'(perf_conf[b*32 +: 32]); busy0 += int'(perf_busy[b*32 +: 32]); end
    @(negedge clk); started = 1;
    begin
      int g;
      g = 0;
      while (!all_done && g < 2000000) begin @(posedge clk); g++; end
      if (!all_done) $display("RESULT tb=bench_ctrl errors=1 TIMEOUT FAIL");
    end
    repeat (2) @(posedge clk);
    begin
      longint cyc;
      int conf1, busy1;
      real tput, ml;
      conf1 = 0; busy1 = 0;
      for (int b = 0; b < NB; b++) begin conf1 += int'(perf_conf[b*32 +: 32]); busy1 += int'(perf_busy[b*32 +: 32]); end
      cyc = c_end - c_start;
      tput = real'(useful_bytes) / real'(cyc);
      ml = real'(lat_sum) / real'(lat_n);
      $display("BENCH ctrl pattern=%0d nm=%0d nb=%0d depth=%0d read_latency=%0d ecc=%0d nslot=%0d arb=%0d rsp_pct=%0d load_pct=%0d seed=%0d nreq=%0d cycles=%0d accesses=%0d reads=%0d writes=%0d useful_bytes=%0d throughput_Bpc=%0.4f bank_conflict_cycles=%0d bank_busy_stalls=%0d mean_latency=%0.3f max_latency=%0d max_outstanding=%0d",
               pat, NM, NB, DEPTH, READ_LATENCY, ECC_EN, NSLOT, ARB, rsp_pct, load_pct, seed_v, nreq, cyc, lat_n, r_rd, r_wr, useful_bytes, tput, conf1 - conf0, busy1 - busy0, ml, lat_max, max_out[0]);
      $display("RESULT tb=bench_ctrl pattern=%0d checks=%0d errors=0 PASS", pat, lat_n);
    end
    $finish;
  end
  initial begin #(64'd2_000_000_000); $display("RESULT tb=bench_ctrl errors=1 WATCHDOG FAIL"); $finish; end
endmodule
