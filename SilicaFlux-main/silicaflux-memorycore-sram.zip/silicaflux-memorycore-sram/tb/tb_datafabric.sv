// =============================================================================
// SilicaFlux MemoryCore :: tb_datafabric
// DataFabric integration: NM SFB3 masters -> REAL silicaflux_noc (crossbar, third_party/noc_sfb3, unmodified)
// -> sf_sram_datafabric -> sf_sram_controller -> banks.  The SFB3 protocol checker (unmodified) watches every
// master port and the SRAM target port.
//
// Scoreboard: a byte-accurate model of the SRAM.  Operations are applied to the model when the TARGET
// accepts them (t_req_valid && t_req_ready) -- the serialisation point -- and the exact response
// {opcode, status, rdata} is queued per (source, id).  Responses reaching the masters are compared with the
// head of their (source, id) queue: this checks the SFB3 ordering rule (same (src,id): acceptance order) and the
// controller contract (O1-O3) end to end.  Posted writes queue nothing (the fabric retires their completion).
//
// Phases:  D1 directed: read/write/byte strobes through every master   D2 posted write + FENCE + read of another id
//          D3 decode errors (unmapped, misaligned) -> ST_DECERR from the fabric, no side effect
//          D4 target-side range error (region larger than the SRAM) -> ST_SLVERR, no side effect
//          D5 64-beat burst (posted writes, FENCE, reads) incl. throughput   D6 random multi-master traffic
//          with hot lines, strobes, FENCEs, posted writes, slow response consumers, full-capacity readback
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_datafabric #(
  parameter int DW = 128,                 // fabric data width (32 / 64 / 128)
  parameter int NM = 3,
  parameter int IDW = 3,
  parameter int NP = 1,
  parameter int NB = 4,
  parameter int DEPTH = 256,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NSLOT = 8,
  parameter int CHK_ALIGN = 1,           // fabric alignment check; 0 lets misaligned requests reach the adapter's own guard
  parameter int NRAND = 1200,
  parameter int SEED = 32'h0D15EA5E
);
  localparam int AW = 32;
  localparam int SB = DW / 8;
  localparam int LINE_W = 128;
  localparam int LB = 4;
  localparam int WB = $clog2(DW / 8);
  localparam int SRCW = (NM > 1) ? $clog2(NM) : 1;
  localparam int QW = 3;
  localparam int CAP_LINES = NB * DEPTH;
  localparam int CAP_BYTES = CAP_LINES * 16;
  localparam int REGION_BYTES = 2 * CAP_BYTES;                  // fabric region is twice the SRAM: upper half -> SLVERR
  localparam logic [AW-1:0] BASE = 32'h1000_0000;
  localparam logic [AW-1:0] MASK = ~(AW'(REGION_BYTES) - 1'b1);
  localparam logic [AW-1:0] AMASK = AW'(REGION_BYTES) - 1'b1;
  localparam int LANEW = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1;
  localparam int IDC = 3 + SRCW + IDW + LANEW + 1;
  localparam int ROW_W = $clog2(DEPTH);
  localparam int FBW = 8;
  localparam int R_ECC = $clog2(LINE_W + $clog2(LINE_W + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? LINE_W + R_ECC + 1 : LINE_W;
  localparam int BW = (NB > 1) ? $clog2(NB) : 1;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- fabric master side
  logic [NM-1:0]      m_req_valid, m_req_ready;
  logic [NM*3-1:0]    m_req_opcode;
  logic [NM*IDW-1:0]  m_req_id;
  logic [NM*QW-1:0]   m_req_qos;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata;
  logic [NM*SB-1:0]   m_req_wstrb;
  logic [NM-1:0]      m_rsp_valid, m_rsp_ready;
  logic [NM*IDW-1:0]  m_rsp_id;
  logic [NM*3-1:0]    m_rsp_opcode;
  logic [NM*2-1:0]    m_rsp_status;
  logic [NM*DW-1:0]   m_rsp_rdata;
  // ---------------------------------------------------------------- fabric target side (one target = the SRAM)
  logic               t_req_valid, t_req_ready;
  logic [2:0]         t_req_opcode;
  logic [SRCW-1:0]    t_req_src;
  logic [IDW-1:0]     t_req_id;
  logic [QW-1:0]      t_req_qos;
  logic [AW-1:0]      t_req_addr;
  logic [DW-1:0]      t_req_wdata;
  logic [SB-1:0]      t_req_wstrb;
  logic               t_rsp_valid, t_rsp_ready;
  logic [SRCW-1:0]    t_rsp_src;
  logic [IDW-1:0]     t_rsp_id;
  logic [2:0]         t_rsp_opcode;
  logic [1:0]         t_rsp_status;
  logic [DW-1:0]      t_rsp_rdata;
  logic [31:0]        rb_rdata;
  logic               rb_err, irq_err;
  logic [NM-1:0]      obs_sw_valid, obs_sw_ready, obs_decerr, obs_posted_err, obs_orphan;
  logic               obs_bad_src;

  silicaflux_noc #(
    .TOPOLOGY(1), .NM(NM), .NT(1), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(1), .CHECK_ALIGN(CHK_ALIGN),
    .TGT_BASE(BASE), .TGT_MASK(MASK), .MAXO_MAX(4), .PERF(0)
  ) noc (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_opcode(m_req_opcode), .m_req_id(m_req_id),
    .m_req_qos(m_req_qos), .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_id(m_rsp_id), .m_rsp_opcode(m_rsp_opcode),
    .m_rsp_status(m_rsp_status), .m_rsp_rdata(m_rsp_rdata),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src),
    .t_req_id(t_req_id), .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata), .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id),
    .t_rsp_opcode(t_rsp_opcode), .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata),
    .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_rdata(rb_rdata), .rb_err(rb_err), .irq_err(irq_err),
    .obs_sw_valid(obs_sw_valid), .obs_sw_ready(obs_sw_ready), .obs_out_cnt(), .obs_decerr(obs_decerr),
    .obs_posted_err(obs_posted_err), .obs_orphan(obs_orphan), .obs_bad_src(obs_bad_src));

  // ---------------------------------------------------------------- adapter + controller
  logic [NP-1:0]            c_req_valid, c_req_ready, c_req_we, c_rsp_valid, c_rsp_ready, c_rsp_we, c_rsp_ce;
  logic [NP*AW-1:0]         c_req_addr;
  logic [NP*LINE_W-1:0]     c_req_wdata, c_rsp_rdata;
  logic [NP*(LINE_W/8)-1:0] c_req_be;
  logic [NP*IDC-1:0]        c_req_id, c_rsp_id;
  logic [NP*3-1:0]          c_rsp_status;
  logic                     err_sticky;
  logic [15:0]              err_cnt;
  logic [2:0]               err_code, err_opcode;
  logic [SRCW-1:0]          err_src;
  logic [IDW-1:0]           err_id;
  logic                     err_clr = 1'b0;
  logic                     c_idle;
  logic [NB-1:0]            c_ev_ue;
  logic [NB*STORE_W-1:0]    c_tst_rdata;

  sf_sram_datafabric #(.NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .NP(NP), .ADDR_MASK(AMASK)) adp (
    .clk(clk), .rst_n(rst_n),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src),
    .t_req_id(t_req_id), .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata), .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id),
    .t_rsp_opcode(t_rsp_opcode), .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata),
    .c_req_valid(c_req_valid), .c_req_ready(c_req_ready), .c_req_we(c_req_we), .c_req_addr(c_req_addr),
    .c_req_wdata(c_req_wdata), .c_req_be(c_req_be), .c_req_id(c_req_id),
    .c_rsp_valid(c_rsp_valid), .c_rsp_ready(c_rsp_ready), .c_rsp_rdata(c_rsp_rdata), .c_rsp_id(c_rsp_id),
    .c_rsp_we(c_rsp_we), .c_rsp_status(c_rsp_status),
    .err_clr_i(err_clr), .err_sticky_o(err_sticky), .err_cnt_o(err_cnt), .err_code_o(err_code), .err_src_o(err_src),
    .err_id_o(err_id), .err_opcode_o(err_opcode));

  sf_sram_controller #(.NM(NP), .NB(NB), .DEPTH(DEPTH), .DW(LINE_W), .AW(AW), .IDW(IDC), .READ_LATENCY(READ_LATENCY),
                       .ECC_EN(ECC_EN), .NSLOT(NSLOT), .INIT_ON_RESET(1), .SIM_INIT(2)) ctl (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(c_req_valid), .m_req_ready(c_req_ready), .m_req_we(c_req_we), .m_req_addr(c_req_addr),
    .m_req_wdata(c_req_wdata), .m_req_be(c_req_be), .m_req_id(c_req_id),
    .m_rsp_valid(c_rsp_valid), .m_rsp_ready(c_rsp_ready), .m_rsp_rdata(c_rsp_rdata), .m_rsp_id(c_rsp_id),
    .m_rsp_we(c_rsp_we), .m_rsp_status(c_rsp_status), .m_rsp_ce(c_rsp_ce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(1'b0), .idle_o(c_idle), .init_start_i(1'b0), .init_busy_o(),
    .scrub_en_i(1'b0), .ecc_clr_i(1'b0), .ev_ce_o(), .ev_ue_o(c_ev_ue), .ce_cnt_o(), .ue_cnt_o(),
    .perf_acc_o(), .perf_conf_o(), .perf_busy_o(), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0), .tst_rdata_o(c_tst_rdata),
    .fi_bank('0), .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  logic [LINE_W-1:0] dump [NB*DEPTH];
  logic dump_req = 1'b0;
  if (ECC_EN == 0) begin : g_dump_en
    for (genvar b = 0; b < NB; b++) begin : g_dump
      always @(dump_req) for (int r = 0; r < DEPTH; r++) dump[b*DEPTH + r] = ctl.g_bank[b].u_bank.u_core.g_behav.u_mem.mem[r];
    end
  end

  // ---------------------------------------------------------------- SFB3 protocol checkers (unmodified)
  int viol_m [NM];
  int viol_t;
  for (genvar gm = 0; gm < NM; gm++) begin : g_pcm
    sfn_protocol_checker #(.QW(3 + IDW + QW + AW + DW + SB), .RW(IDW + 3 + 2 + DW), .NAME($sformatf("m%0d", gm))) u_pc (
      .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid[gm]), .req_ready(m_req_ready[gm]),
      .req_payload({m_req_opcode[gm*3 +: 3], m_req_id[gm*IDW +: IDW], m_req_qos[gm*QW +: QW], m_req_addr[gm*AW +: AW],
                    m_req_wdata[gm*DW +: DW], m_req_wstrb[gm*SB +: SB]}),
      .rsp_valid(m_rsp_valid[gm]), .rsp_ready(m_rsp_ready[gm]),
      .rsp_payload({m_rsp_id[gm*IDW +: IDW], m_rsp_opcode[gm*3 +: 3], m_rsp_status[gm*2 +: 2], m_rsp_rdata[gm*DW +: DW]}),
      .violations(viol_m[gm]));
  end
  sfn_protocol_checker #(.QW(3 + SRCW + IDW + QW + AW + DW + SB), .RW(SRCW + IDW + 3 + 2 + DW), .NAME("t0_sram")) u_pct (
    .clk(clk), .rst_n(rst_n), .req_valid(t_req_valid), .req_ready(t_req_ready),
    .req_payload({t_req_opcode, t_req_src, t_req_id, t_req_qos, t_req_addr, t_req_wdata, t_req_wstrb}),
    .rsp_valid(t_rsp_valid), .rsp_ready(t_rsp_ready),
    .rsp_payload({t_rsp_src, t_rsp_id, t_rsp_opcode, t_rsp_status, t_rsp_rdata}), .violations(viol_t));

  // ---------------------------------------------------------------- PRNG, model, bookkeeping
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int rndn(input int n); logic [31:0] r; r = rnd(); return int'(r % 32'(n)); endfunction

  localparam logic [2:0] OP_READ = 3'd0, OP_WRITE = 3'd1, OP_WRITE_POSTED = 3'd2, OP_FENCE = 3'd3;
  localparam logic [1:0] ST_OKAY = 2'd0, ST_SLVERR = 2'd1, ST_DECERR = 2'd2;

  byte unsigned ref_mem [CAP_BYTES];
  typedef struct { logic [2:0] op; logic [IDW-1:0] id; logic [QW-1:0] qos; logic [AW-1:0] addr; logic [DW-1:0] wdata; logic [SB-1:0] wstrb; int delay; } stim_t;
  typedef struct { logic [2:0] op; logic [1:0] st; logic [DW-1:0] data; } exp_t;
  localparam int QD = 8192, ED = 256, NID = (1 << IDW);
  stim_t sa [NM][QD];
  int    sh [NM], stl [NM];                  // stimulus head / tail
  exp_t  ea [NM][NID][ED];
  int    eh [NM][NID], et [NM][NID];
  int    dly [NM];
  int    n_checks = 0, n_err = 0, n_resp [NM], n_issue [NM], n_posted = 0, n_slverr = 0, n_decerr = 0, n_target_acc = 0;
  int    rsp_pct = 100;
  string cur = "";
  bit    in_d2 = 1'b0;                      // phase D2 active: post-FENCE reads must return the POSTED data (independent of the model)
  logic [DW-1:0] d2v [NM];
  longint cycle = 0;

  task automatic fail(input string m); n_err++; if (n_err <= 25) $display("  [FAIL] %s @cycle %0d (%s)", m, cycle, cur); endtask
  task automatic check(input bit c, input string m); n_checks++; if (!c) fail(m); endtask

  function automatic int ssize(input int m); return stl[m] - sh[m]; endfunction
  function automatic int esize(input int m, input int id); return et[m][id] - eh[m][id]; endfunction
  task automatic spush(input int m, input stim_t s);
    sa[m][stl[m] % QD] = s; stl[m] = stl[m] + 1;
    if (stl[m] - sh[m] > QD) $fatal(1, "stimulus overflow");
  endtask
  task automatic epush(input int m, input int id, input exp_t e);
    ea[m][id][et[m][id] % ED] = e; et[m][id] = et[m][id] + 1;
    if (et[m][id] - eh[m][id] > ED) $fatal(1, "expectation overflow");
  endtask

  // ---- monitor 1: master accepts -> fabric-local decisions (decode errors, FENCE) are predicted here
  function automatic bit maps(input logic [AW-1:0] a);
    return ((a & MASK) == BASE) && (CHK_ALIGN == 0 || a[WB-1:0] == '0);
  endfunction
  always @(posedge clk) begin
    cycle <= cycle + 1;
    if (rst_n) begin
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && m_req_ready[m]) begin
          logic [2:0] op; logic [IDW-1:0] id; logic [AW-1:0] a; exp_t e;
          op = m_req_opcode[m*3 +: 3]; id = m_req_id[m*IDW +: IDW]; a = m_req_addr[m*AW +: AW];
          n_issue[m]++;
          if (op == OP_FENCE) begin
            e.op = OP_FENCE; e.st = ST_OKAY; e.data = '0; epush(m, int'(id), e);
          end else if ((op == OP_READ || op == OP_WRITE) && !maps(a)) begin
            e.op = op; e.st = ST_DECERR; e.data = '0; epush(m, int'(id), e); n_decerr++;
          end
        end
      end
    end
  end

  bit trace = $test$plusargs("DASHTRACE");
  int trace_n = 0;
  // ---- monitor 2: the SRAM target accepts a request -> apply to the model, queue the response
  always @(posedge clk) begin
    if (rst_n && t_req_valid && t_req_ready) begin
      logic [AW-1:0] off; int line, base, lane; exp_t e; logic [DW-1:0] d;
      off  = t_req_addr & AMASK;
      line = int'(off >> LB);
      lane = (DW < LINE_W) ? int'((off & AW'(15)) >> WB) : 0;
      base = line * 16 + lane * SB;
      n_target_acc++;
      if (trace && trace_n < 500 && cur[0] == "D" && cur[1] == "6") begin
        trace_n++;
        $display("DT df tgt cycle=%0d src=%0d id=%0d op=%0d line=%0d bank=%0d", cycle, t_req_src, t_req_id, t_req_opcode, line, line % NB);
      end
      e.op = t_req_opcode; e.data = '0; e.st = ST_OKAY;
      if ((off & AW'(SB - 1)) != '0) begin
        e.st = ST_SLVERR; n_slverr++;                         // misaligned beat that reached the adapter (CHK_ALIGN = 0): error, no side effect
      end else if (line >= CAP_LINES) begin
        e.st = ST_SLVERR; n_slverr++;                         // range error inside the fabric region, no side effect
      end else if (t_req_opcode == OP_WRITE || t_req_opcode == OP_WRITE_POSTED) begin
        for (int b = 0; b < SB; b++) if (t_req_wstrb[b]) ref_mem[base + b] = t_req_wdata[b*8 +: 8];
      end else begin
        for (int b = 0; b < SB; b++) d[b*8 +: 8] = ref_mem[base + b];
        e.data = d;
        if (in_d2 && (t_req_id == IDW'(2) || t_req_id == IDW'(3)))
          check(d == ((t_req_id == IDW'(2)) ? d2v[int'(t_req_src)] : ~d2v[int'(t_req_src)]),
                $sformatf("D2: read after posted write + FENCE did not see the posted data (src %0d id %0d)", t_req_src, t_req_id));
      end
      if (t_req_opcode == OP_WRITE_POSTED) n_posted++;
      else epush(int'(t_req_src), int'(t_req_id), e);
    end
  end

  // ---- monitor 3: responses at the masters
  always @(posedge clk) begin
    if (rst_n) begin
      for (int m = 0; m < NM; m++) begin
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          int id; exp_t e;
          id = int'(m_rsp_id[m*IDW +: IDW]);
          n_resp[m]++;
          if (trace && trace_n < 500 && cur[0] == "D" && cur[1] == "6") $display("DT df rsp cycle=%0d master=%0d id=%0d status=%0d", cycle, m, id, m_rsp_status[m*2 +: 2]);
          if (esize(m, id) == 0) fail($sformatf("master %0d id %0d: response with nothing outstanding", m, id));
          else begin
            e = ea[m][id][eh[m][id] % ED]; eh[m][id] = eh[m][id] + 1;
            check(m_rsp_opcode[m*3 +: 3] == e.op, $sformatf("master %0d id %0d: opcode %0d != %0d", m, id, m_rsp_opcode[m*3 +: 3], e.op));
            check(m_rsp_status[m*2 +: 2] == e.st, $sformatf("master %0d id %0d: status %0d != %0d (op %0d)", m, id, m_rsp_status[m*2 +: 2], e.st, e.op));
            check(m_rsp_rdata[m*DW +: DW] == e.data, $sformatf("master %0d id %0d: rdata %h != %h", m, id, m_rsp_rdata[m*DW +: DW], e.data));
          end
        end
      end
    end
  end

  // ---- master drivers (one outstanding per cycle; the fabric enforces the per-master outstanding limit)
  always @(posedge clk) begin
    if (!rst_n) begin m_req_valid <= '0; m_rsp_ready <= '0; end
    else begin
      for (int m = 0; m < NM; m++) begin
        logic accepted;
        accepted = m_req_valid[m] && m_req_ready[m];
        if (accepted) m_req_valid[m] <= 1'b0;
        if ((!m_req_valid[m] || accepted) && ssize(m) > 0) begin
          if (dly[m] >= sa[m][sh[m] % QD].delay) begin
            stim_t s;
            s = sa[m][sh[m] % QD]; sh[m] = sh[m] + 1;
            m_req_valid[m] <= 1'b1; m_req_opcode[m*3 +: 3] <= s.op; m_req_id[m*IDW +: IDW] <= s.id; m_req_qos[m*QW +: QW] <= s.qos;
            m_req_addr[m*AW +: AW] <= s.addr; m_req_wdata[m*DW +: DW] <= s.wdata; m_req_wstrb[m*SB +: SB] <= s.wstrb;
            dly[m] = 0;
          end else dly[m] = dly[m] + 1;
        end
        m_rsp_ready[m] <= (rndn(100) < rsp_pct);
      end
    end
  end

  // ---------------------------------------------------------------- helpers
  task automatic put(input int m, input logic [2:0] op, input int id, input logic [AW-1:0] addr, input logic [DW-1:0] wd, input logic [SB-1:0] ws, input int delay = 0);
    stim_t s;
    s.op = op; s.id = IDW'(id); s.qos = QW'(rndn(5)); s.addr = addr; s.wdata = wd; s.wstrb = ws; s.delay = delay;
    spush(m, s);
  endtask
  function automatic logic [AW-1:0] gaddr(input int byteoff); return BASE + AW'(byteoff); endfunction
  function automatic logic [DW-1:0] mkdata(); logic [DW-1:0] d; for (int w = 0; w < (DW + 31) / 32; w++) d[w*32 +: 32] = rnd(); return d; endfunction

  task automatic drain(input int maxc = 400000);
    int n; bit busy;
    n = 0;
    do begin
      @(posedge clk); n++;
      busy = (m_req_valid != '0) || !c_idle || (c_rsp_valid != '0) || t_rsp_valid;
      for (int m = 0; m < NM; m++) begin
        if (ssize(m) != 0) busy = 1'b1;
        for (int i = 0; i < NID; i++) if (esize(m, i) != 0) busy = 1'b1;
      end
    end while (busy && n < maxc);
    if (busy) fail("drain timeout (deadlock or lost response)");
    repeat (3) @(posedge clk);
  endtask
  task automatic begin_phase(input string s); cur = s; $display("[%0t] %s", $time, s); endtask
  task automatic end_phase(input int e0); $display("    %s: %s", cur, (n_err == e0) ? "PASS" : "FAIL"); endtask

  // ---------------------------------------------------------------- phases
  int e0, c0, k, burst_cyc;
  real burst_cpb;
  initial begin
    for (int m = 0; m < NM; m++) begin sh[m] = 0; stl[m] = 0; dly[m] = 0; n_resp[m] = 0; n_issue[m] = 0;
      for (int i = 0; i < NID; i++) begin eh[m][i] = 0; et[m][i] = 0; end end
    for (int i = 0; i < CAP_BYTES; i++) ref_mem[i] = 8'h00;       // INIT_ON_RESET: valid zero lines
    m_req_valid = '0; m_req_opcode = '0; m_req_id = '0; m_req_qos = '0; m_req_addr = '0; m_req_wdata = '0; m_req_wstrb = '0; m_rsp_ready = '0;
    repeat (6) @(posedge clk); rst_n = 1'b1;
    repeat (4) @(posedge clk);
    while (!c_idle) @(posedge clk);
    repeat (CAP_LINES / NB + 10) @(posedge clk);                  // banks initialise after reset
    while (!c_idle) @(posedge clk);
    $display("CONFIG DW=%0d NM=%0d IDW=%0d NP=%0d NB=%0d DEPTH=%0d READ_LATENCY=%0d ECC_EN=%0d region=%0d B (SRAM %0d B)", DW, NM, IDW, NP, NB, DEPTH, READ_LATENCY, ECC_EN, REGION_BYTES, CAP_BYTES);

    // ---- D1 directed reads / writes / byte strobes from every master
    begin_phase("D1 directed read/write/byte-enable through every master"); e0 = n_err; rsp_pct = 100;
    for (int m = 0; m < NM; m++) begin
      put(m, OP_WRITE, m, gaddr(m * 256), mkdata(), '1);
      put(m, OP_READ,  m, gaddr(m * 256), '0, '1);
      for (int b = 0; b < SB; b++) begin
        put(m, OP_WRITE, m, gaddr(m * 256 + 64), '0, '1);
        put(m, OP_WRITE, m, gaddr(m * 256 + 64), {DW{1'b1}}, SB'(1) << b);
        put(m, OP_READ,  m, gaddr(m * 256 + 64), '0, '1);
      end
    end
    drain(); end_phase(e0);

    // ---- D2 posted write, FENCE, then read with ANOTHER id sees the write
    begin_phase("D2 posted write + FENCE + read (different id) ordering"); e0 = n_err; in_d2 = 1'b1;
    for (int m = 0; m < NM; m++) begin
      logic [DW-1:0] dd;
      dd = mkdata(); d2v[m] = dd;
      put(m, OP_WRITE_POSTED, 0, gaddr(2048 + m * 64), dd, '1);
      put(m, OP_WRITE_POSTED, 0, gaddr(2048 + m * 64 + SB), ~dd, '1);
      put(m, OP_FENCE, 1, gaddr(0), '0, '0);
      put(m, OP_READ, 2, gaddr(2048 + m * 64), '0, '1);        // model-checked AND explicitly equal to dd below
      put(m, OP_READ, 3, gaddr(2048 + m * 64 + SB), '0, '1);
    end
    drain(); in_d2 = 1'b0;
    check(n_posted >= NM * 2, "posted writes did not reach the SRAM");
    end_phase(e0);

    // ---- D3 decode errors: unmapped and misaligned -> DECERR from the fabric, SRAM untouched
    begin_phase("D3 decode errors (unmapped / misaligned) -> ST_DECERR, no side effect"); e0 = n_err; c0 = n_target_acc;
    put(0, OP_WRITE, 0, BASE - AW'(SB), {DW{1'b1}}, '1);                    // just below the region
    put(0, OP_READ,  1, BASE + AW'(REGION_BYTES), '0, '1);                  // just above
    put(1, OP_WRITE, 0, 32'h2000_0000, {DW{1'b1}}, '1);                     // far away
    if (SB > 1) begin
      put(1, OP_WRITE, 1, gaddr(256 + 1), {DW{1'b1}}, '1);                  // misaligned
      put(2, OP_READ,  0, gaddr(256 + SB - 1), '0, '1);
    end
    put(2, OP_READ, 1, 32'h0000_0000, '0, '1);
    drain();
    if (CHK_ALIGN != 0) check(n_target_acc == c0, "a decode-error request reached the SRAM target");
    check(n_decerr >= ((SB > 1 && CHK_ALIGN != 0) ? 6 : 4), "fabric produced fewer DECERR responses than expected");
    end_phase(e0);

    if (CHK_ALIGN == 0 && SB > 1) begin
      begin_phase("D3b misaligned requests reach the adapter (fabric check off) -> ST_SLVERR, no side effect"); e0 = n_err;
      k = n_slverr;
      for (int n = 0; n < 24; n++) begin
        put(n % NM, (n % 3 == 0) ? OP_READ : (n % 3 == 1) ? OP_WRITE : OP_WRITE_POSTED, n % NID, gaddr(512 + rndn(CAP_BYTES / SB / 2) * SB + 1 + rndn(SB - 1)), {DW{1'b1}}, '1);
      end
      drain();
      check(n_slverr - k == 24, $sformatf("expected 24 SLVERR for misaligned requests, got %0d", n_slverr - k));
      end_phase(e0);
    end

    // ---- D4 target-side range error (offset beyond the SRAM, still inside the fabric region)
    begin_phase("D4 SRAM range error (offset beyond capacity) -> ST_SLVERR, no side effect"); e0 = n_err; k = n_slverr; err_clr = 1'b1; @(posedge clk); err_clr = 1'b0;
    put(0, OP_WRITE, 2, gaddr(CAP_BYTES), {DW{1'b1}}, '1);
    put(0, OP_READ,  2, gaddr(CAP_BYTES + 16 * 3), '0, '1);
    put(1, OP_WRITE_POSTED, 2, gaddr(REGION_BYTES - SB), {DW{1'b1}}, '1);     // posted: error only in the error registers
    put(1, OP_WRITE, 3, gaddr(CAP_BYTES - SB), mkdata(), '1);                  // last valid beat: OK
    put(1, OP_READ,  3, gaddr(CAP_BYTES - SB), '0, '1);
    drain();
    check(n_slverr - k == 3, "expected exactly 3 SLVERR (write, read, posted write) beyond the capacity");
    check(err_sticky && err_cnt >= 2 && err_code == `SF_ST_RANGE, $sformatf("adapter error registers: sticky=%b cnt=%0d code=%0d", err_sticky, err_cnt, err_code));
    end_phase(e0);

    // ---- D5 burst: 64 sequential beats (posted writes), FENCE, 64 reads; throughput
    begin_phase("D5 64-beat burst (posted writes, FENCE, reads) and throughput"); e0 = n_err;
    c0 = int'(cycle);
    for (int b = 0; b < 64; b++) put(0, OP_WRITE_POSTED, b % NID, gaddr(8192 + b * SB), mkdata(), '1);
    put(0, OP_FENCE, 0, gaddr(0), '0, '0);
    for (int b = 0; b < 64; b++) put(0, OP_READ, b % NID, gaddr(8192 + b * SB), '0, '1);
    drain();
    burst_cyc = int'(cycle) - c0 - 6;
    burst_cpb = real'(burst_cyc) / 128.0;
    $display("    128 beats + FENCE in %0d cycles (%0.2f cycles/beat) behind the crossbar", burst_cyc, burst_cpb);
    end_phase(e0);

    // ---- D6 random multi-master traffic
    begin_phase("D6 randomized multi-master traffic (hot lines, strobes, posted writes, FENCE, slow consumers)"); e0 = n_err;
    for (int pass = 0; pass < 3; pass++) begin
      rsp_pct = (pass == 0) ? 100 : (pass == 1) ? 40 : 10;
      for (int m = 0; m < NM; m++)
        for (int n = 0; n < NRAND / 3; n++) begin
          int r, off, id; logic [2:0] op; logic [SB-1:0] ws;
          r = rndn(100);
          off = (rndn(100) < 55) ? (rndn(8) * 16 + rndn(16 / SB) * SB) : (rndn(CAP_BYTES / SB) * SB);
          if (rndn(100) < 4) off = CAP_BYTES + rndn(CAP_BYTES / SB) * SB;           // beyond the SRAM: SLVERR
          op = (r < 38) ? OP_READ : (r < 68) ? OP_WRITE : (r < 92) ? OP_WRITE_POSTED : OP_FENCE;
          id = rndn(NID);
          ws = (rndn(2) == 0) ? '1 : SB'(rnd());
          put(m, op, id, gaddr(off), mkdata(), ws, rndn(6) == 0 ? rndn(4) : 0);
        end
      drain();
    end
    rsp_pct = 100;
    for (int ln = 0; ln < CAP_LINES; ln++)                                          // full-capacity readback through master 0
      for (int l = 0; l < 16 / SB; l++) put(0, OP_READ, ln % NID, gaddr(ln * 16 + l * SB), '0, '1);
    drain();
    end_phase(e0);

    // ---- backdoor: the physical placement of every byte in the banks must equal the model (read-back alone cannot see a lane/bank
    //      mix-up that is applied identically on the write and read path)
    if (ECC_EN == 0) begin
      dump_req = ~dump_req; #1;
      for (int ln = 0; ln < CAP_LINES; ln++)
        for (int b = 0; b < 16; b++)
          check(dump[(ln % NB) * DEPTH + (ln / NB)][b*8 +: 8] === ref_mem[ln * 16 + b], $sformatf("backdoor: line %0d byte %0d in the bank array != model", ln, b));
    end
    // ---- global checks
    for (int m = 0; m < NM; m++) check(viol_m[m] == 0, $sformatf("SFB3 protocol violations at master %0d: %0d", m, viol_m[m]));
    check(viol_t == 0, $sformatf("SFB3 protocol violations at the SRAM target: %0d", viol_t));
    check(obs_orphan == '0 && !obs_bad_src, "fabric reported an orphan response / bad source");
    check(rb_err == 1'b0, "register bus error");
    $display("    transactions: %0d accepted by the SRAM target (%0d posted), %0d SLVERR, %0d DECERR; master issues %0d/%0d/%0d; responses %0d/%0d/%0d",
             n_target_acc, n_posted, n_slverr, n_decerr, n_issue[0], n_issue[1], n_issue[NM-1], n_resp[0], n_resp[1], n_resp[NM-1]);
    $display("RESULT tb=datafabric DW=%0d NM=%0d NP=%0d READ_LATENCY=%0d ECC_EN=%0d checks=%0d errors=%0d protocol_violations=%0d %s", DW, NM, NP, READ_LATENCY, ECC_EN,
             n_checks, n_err, viol_t, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #(64'd600_000_000);
    $display("RESULT tb=datafabric errors=1 WATCHDOG TIMEOUT FAIL");
    $finish;
  end
endmodule
