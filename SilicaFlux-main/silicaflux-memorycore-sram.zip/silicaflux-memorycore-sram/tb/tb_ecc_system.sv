// =============================================================================
// SilicaFlux MemoryCore :: tb_ecc_system
// ECC through the whole path: sf_sram_controller (ECC_EN = 1, fault injection compiled in) -> banks -> array.
// A soft error is a bit flip in the STORED word (seu_*); a hard fault is a stuck-at cell (fi_*).  Reference: byte-accurate model.
//   E1  every one of the STORED bit positions (data + check + parity) of a line flipped, read back: corrected data, rsp_ce = 1,
//       status OK, correctable counter +1 (whole sweep: STORE_W errors per bank)
//   E2  double-bit errors (sampled pairs, incl. data/check mixes): status SF_ST_ECC_UE, uncorrectable counter +1, rdata is the
//       STORED (uncorrected) data, never presented as valid
//   E3  partial write onto a line with a 1-bit error: RMW corrects the old data, merges, re-encodes: the line is clean afterwards
//       (next read: no CE) and the response reports the corrected event
//   E4  partial write onto an UNCORRECTABLE line: ABORTED (status ECC_UE, line left as found); a FULL-line write then repairs it
//   E5  scrubber: single-bit errors seeded in many rows are found and written back corrected during idle cycles (no read needed);
//       the correctable counter counts them; a UE row is reported (uncorrectable counter) and left alone
//   E6  hard fault (stuck-at cell): every functional read still returns correct data while the cell disagrees with the written value
//   E7  randomized soak: random full/partial writes, reads, single-bit upsets (at most one outstanding error per line); every read
//       must return the model data and the correctable counter must equal the number of reads/RMWs that hit a flipped line
//   E8  statistics: a line with 3 flipped bits is either miscorrected (silent) or flagged; the TB counts both (characterisation of
//       the distance-4 code, reproducible, NOT a pass/fail criterion)
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_ecc_system #(
  parameter int NB = 2,
  parameter int DEPTH = 16,
  parameter int READ_LATENCY = 1,
  parameter int NSOAK = 3000,
  parameter int SEED = 32'h5EEDECC0
);
  localparam int AW = 16, DW = 128, IDW = 4, LB = 4, BE_W = 16;
  localparam int R_ECC = 8;
  localparam int STORE_W = DW + R_ECC + 1;          // 137
  localparam int CAP_LINES = NB * DEPTH;
  localparam int BW = (NB > 1) ? $clog2(NB) : 1;
  localparam int ROW_W = $clog2(DEPTH);
  localparam int FBW = $clog2(STORE_W);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  logic m_req_valid = 0, m_req_ready, m_req_we = 0, m_rsp_valid, m_rsp_ready = 1, m_rsp_we, m_rsp_ce;
  logic [AW-1:0] m_req_addr = 0;
  logic [DW-1:0] m_req_wdata = 0, m_rsp_rdata;
  logic [BE_W-1:0] m_req_be = '1;
  logic [IDW-1:0] m_req_id = 0, m_rsp_id;
  logic [2:0] m_rsp_status;
  logic idle, scrub_en = 0, ecc_clr = 0;
  logic [NB-1:0] ev_ce, ev_ue;
  logic [NB*16-1:0] ce_cnt, ue_cnt;
  logic [BW-1:0] fi_bank = 0;
  logic [3:0] fi_type = 0;
  logic [ROW_W-1:0] fi_row = 0, fi_row2 = 0;
  logic [FBW-1:0] fi_bit = 0, fi_bit2 = 0;
  logic fi_val = 0, fi_val2 = 0, seu_pulse = 0;
  logic [ROW_W-1:0] seu_row = 0;
  logic [STORE_W-1:0] seu_mask = 0;
  logic [NB*STORE_W-1:0] tst_rdata;

  sf_sram_controller #(.NM(1), .NB(NB), .DEPTH(DEPTH), .DW(DW), .AW(AW), .IDW(IDW), .READ_LATENCY(READ_LATENCY), .ECC_EN(1), .NSLOT(4),
                       .INIT_ON_RESET(1), .SIM_INIT(2), .FAULT_INJECT(1), .SCRUB_EN(1), .SCRUB_WAIT(4)) dut (
    .clk(clk), .rst_n(rst_n), .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(1'b0), .idle_o(idle), .init_start_i(1'b0), .init_busy_o(), .scrub_en_i(scrub_en),
    .ecc_clr_i(ecc_clr), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue), .ce_cnt_o(ce_cnt), .ue_cnt_o(ue_cnt),
    .perf_acc_o(), .perf_conf_o(), .perf_busy_o(), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0), .tst_rdata_o(tst_rdata),
    .fi_bank(fi_bank), .fi_type(fi_type), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2), .fi_val(fi_val),
    .fi_val2(fi_val2), .seu_pulse(seu_pulse), .seu_row(seu_row), .seu_mask(seu_mask));

  // ---------------------------------------------------------------- model, helpers
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int rndn(input int n); logic [31:0] r; r = rnd(); return int'(r % 32'(n)); endfunction
  function automatic logic [DW-1:0] mkdata(); logic [DW-1:0] d; for (int w = 0; w < 4; w++) d[w*32 +: 32] = rnd(); return d; endfunction

  logic [DW-1:0] model [CAP_LINES];
  int n_checks = 0, n_err = 0;
  string cur = "";
  longint cycle = 0;
  always @(posedge clk) cycle <= cycle + 1;
  task automatic fail(input string m); n_err++; if (n_err <= 25) $display("  [FAIL] %s (%s)", m, cur); endtask
  task automatic check(input bit c, input string m); n_checks++; if (!c) fail(m); endtask

  function automatic int total_ce(); int s; s = 0; for (int b = 0; b < NB; b++) s += int'(ce_cnt[b*16 +: 16]); return s; endfunction
  function automatic int total_ue(); int s; s = 0; for (int b = 0; b < NB; b++) s += int'(ue_cnt[b*16 +: 16]); return s; endfunction
  function automatic int bank_of(input int line); return line % NB; endfunction
  function automatic int row_of(input int line); return line / NB; endfunction

  bit trace = $test$plusargs("DASHTRACE");
  int trace_n = 0;
  always @(posedge clk) if (trace && rst_n && (|ev_ce || |ev_ue)) begin
    trace_n++;
    $display("DT ecc event cycle=%0d phase=%s ce=%b ue=%b", cycle, cur.substr(0, 1), ev_ce, ev_ue);
  end
  // blocking single transfer (one outstanding access)
  task automatic xfer(input bit we, input int line, input logic [DW-1:0] wd, input logic [BE_W-1:0] be,
                      output logic [DW-1:0] rd, output logic [2:0] st, output bit ce);
    int g;
    @(negedge clk);
    m_req_valid = 1; m_req_we = we; m_req_addr = AW'(line) << LB; m_req_wdata = wd; m_req_be = be; m_req_id = IDW'(line);
    g = 0;
    do begin @(posedge clk); g++; end while (!m_req_ready && g < 1000);
    @(negedge clk); m_req_valid = 0;
    g = 0;
    while (!m_rsp_valid && g < 1000) begin @(posedge clk); g++; end
    rd = m_rsp_rdata; st = m_rsp_status; ce = m_rsp_ce;
    if (g >= 1000) fail("transfer timeout");
    @(posedge clk);
  endtask
  task automatic wr(input int line, input logic [DW-1:0] d, input logic [BE_W-1:0] be);
    logic [DW-1:0] rd; logic [2:0] st; bit ce;
    xfer(1'b1, line, d, be, rd, st, ce);
    for (int b = 0; b < BE_W; b++) if (be[b]) model[line][b*8 +: 8] = d[b*8 +: 8];
    check(st == `SF_ST_OK, $sformatf("write line %0d status %0d", line, st));
  endtask
  task automatic rd_check(input int line, input bit exp_ce, input string tag);
    logic [DW-1:0] rd; logic [2:0] st; bit ce;
    xfer(1'b0, line, '0, '1, rd, st, ce);
    check(st == `SF_ST_OK, $sformatf("%s: read status %0d", tag, st));
    check(rd === model[line], $sformatf("%s: line %0d data %h != %h", tag, line, rd, model[line]));
    check(ce == exp_ce, $sformatf("%s: line %0d rsp_ce %b != expected %b", tag, line, ce, exp_ce));
  endtask
  task automatic seu(input int line, input logic [STORE_W-1:0] mask);
    @(negedge clk); while (!idle) @(negedge clk);
    fi_bank = BW'(bank_of(line)); seu_row = ROW_W'(row_of(line)); seu_mask = mask; seu_pulse = 1;
    @(negedge clk); seu_pulse = 0; seu_mask = '0;
    repeat (2) @(posedge clk);
  endtask

  // ---------------------------------------------------------------- tests
  int c0, u0;
  logic [DW-1:0] rdv; logic [2:0] stv; bit cev;
  int e1_ok, mis3, flag3;
  initial begin
    for (int i = 0; i < CAP_LINES; i++) model[i] = '0;
    repeat (6) @(posedge clk); rst_n = 1;
    repeat (CAP_LINES + 24) @(posedge clk); while (!idle) @(posedge clk);
    $display("CONFIG ECC SECDED(137,128) NB=%0d DEPTH=%0d READ_LATENCY=%0d STORE_W=%0d", NB, DEPTH, READ_LATENCY, STORE_W);

    // ---- E1: every stored bit position
    cur = "E1 every stored bit position";
    $display("[%0t] E1 single-bit upsets, all %0d stored bit positions", $time, STORE_W);
    c0 = total_ce();
    for (int ln = 0; ln < CAP_LINES; ln += 5) begin
      for (int b = 0; b < STORE_W; b++) begin
        wr(ln, mkdata(), '1);
        seu(ln, STORE_W'(1) << b);
        rd_check(ln, 1'b1, $sformatf("E1 bit %0d", b));
        e1_ok++;
      end
    end
    check(total_ce() - c0 == e1_ok, $sformatf("E1: correctable counter %0d != %0d injected", total_ce() - c0, e1_ok));
    $display("    %0d upsets corrected, counter +%0d", e1_ok, total_ce() - c0);

    // ---- E2: double-bit errors
    cur = "E2 double-bit errors";
    $display("[%0t] E2 double-bit errors detected, never presented as valid", $time);
    u0 = total_ue();
    for (int n = 0; n < 200; n++) begin
      int ln, b1, b2;
      logic [DW-1:0] orig;
      ln = rndn(CAP_LINES); b1 = rndn(STORE_W); b2 = rndn(STORE_W);
      if (b1 == b2) b2 = (b2 + 1) % STORE_W;
      wr(ln, mkdata(), '1);
      orig = model[ln];
      seu(ln, (STORE_W'(1) << b1) | (STORE_W'(1) << b2));
      xfer(1'b0, ln, '0, '1, rdv, stv, cev);
      check(stv == `SF_ST_ECC_UE, $sformatf("E2: bits %0d,%0d: status %0d != ECC_UE", b1, b2, stv));
      check(!cev, "E2: uncorrectable read must not claim a correction");
      // data bits flipped in the stored word show up in the returned (uncorrected) data; check bits do not
      begin
        logic [DW-1:0] exp;
        exp = orig; if (b1 < DW) exp[b1] = ~exp[b1]; if (b2 < DW) exp[b2] = ~exp[b2];
        check(rdv === exp, "E2: UE data must be the stored (uncorrected) data bits");
      end
      wr(ln, mkdata(), '1);                                                    // repair for later tests
    end
    check(total_ue() - u0 == 200, $sformatf("E2: uncorrectable counter %0d != 200", total_ue() - u0));

    // ---- E3: partial write onto a line with a 1-bit error
    cur = "E3 RMW on correctable line";
    $display("[%0t] E3 partial write onto a single-bit-error line", $time);
    for (int n = 0; n < 40; n++) begin
      int ln, b;
      logic [BE_W-1:0] be;
      ln = rndn(CAP_LINES); b = rndn(STORE_W);
      be = BE_W'(rnd()); if (be == 0 || be == '1) be = 16'h00F0;
      wr(ln, mkdata(), '1);
      seu(ln, STORE_W'(1) << b);
      c0 = total_ce();
      wr(ln, mkdata(), be);                                                    // RMW: old data corrected, bytes merged
      check(total_ce() - c0 == 1, "E3: RMW read of the flipped word must count one correctable event");
      rd_check(ln, 1'b0, "E3 after RMW");                                      // line is clean now
    end

    // ---- E4: partial write onto an UNCORRECTABLE line is aborted; full write repairs
    cur = "E4 RMW on uncorrectable line";
    $display("[%0t] E4 partial write onto an uncorrectable line: aborted; full-line write repairs", $time);
    for (int n = 0; n < 20; n++) begin
      int ln, b1, b2;
      logic [DW-1:0] stored_raw, merged;
      ln = rndn(CAP_LINES); b1 = rndn(STORE_W); b2 = (b1 + 1 + rndn(STORE_W - 1)) % STORE_W;
      wr(ln, mkdata(), '1);
      seu(ln, (STORE_W'(1) << b1) | (STORE_W'(1) << b2));
      xfer(1'b0, ln, '0, '1, stored_raw, stv, cev);                                // raw stored data
      u0 = total_ue();
      xfer(1'b1, ln, mkdata(), 16'h0F0F, rdv, stv, cev);
      check(stv == `SF_ST_ECC_UE, "E4: partial write onto a UE line must report SF_ST_ECC_UE");
      xfer(1'b0, ln, '0, '1, merged, stv, cev);
      check(stv == `SF_ST_ECC_UE && merged === stored_raw, "E4: the aborted write must leave the line exactly as found");
      wr(ln, mkdata(), '1);                                                    // full-line write needs no old data
      rd_check(ln, 1'b0, "E4 after repair");
    end

    // ---- E5: scrubber
    cur = "E5 scrubber";
    $display("[%0t] E5 scrubber finds and repairs seeded single-bit errors, reports a UE", $time);
    for (int ln = 0; ln < CAP_LINES; ln++) wr(ln, mkdata(), '1);
    c0 = total_ce(); u0 = total_ue();
    for (int ln = 0; ln < CAP_LINES; ln += 3) seu(ln, STORE_W'(1) << rndn(STORE_W));
    seu(1, (STORE_W'(1) << 3) | (STORE_W'(1) << 60));                          // a UE row (line 1; not in the +3 stride set)
    begin
      int nseed;
      nseed = 0; for (int ln = 0; ln < CAP_LINES; ln += 3) nseed++;
      scrub_en = 1;
      repeat (CAP_LINES * 4 * 12) @(posedge clk);                              // several full scrub rounds (one step per SCRUB_WAIT cycles per bank)
      scrub_en = 0;
      repeat (8) @(posedge clk);
      check(total_ce() - c0 == nseed, $sformatf("E5: scrubber corrected %0d rows, seeded %0d", total_ce() - c0, nseed));
      check(total_ue() - u0 >= 1, "E5: scrubber must report the uncorrectable row");
      for (int ln = 0; ln < CAP_LINES; ln += 3) if (ln != 1) rd_check(ln, 1'b0, "E5 after scrub");   // clean: no CE any more, data intact
    end
    wr(1, mkdata(), '1);                                                       // repair the UE row

    // ---- E6: hard fault (stuck-at) behind ECC
    cur = "E6 stuck-at cell behind ECC";
    $display("[%0t] E6 a stuck-at cell is corrected on every read", $time);
    begin
      int ln, b, k, hits;
      ln = 6; b = 17; hits = 0;
      fi_bank = BW'(bank_of(ln)); fi_row = ROW_W'(row_of(ln)); fi_bit = FBW'(b); fi_type = `SF_FT_SAF; fi_val = 1'b0;   // data bit 17 stuck at 0
      for (k = 0; k < 8; k++) begin
        logic [DW-1:0] d;
        d = mkdata(); d[b] = 1'b1;                                             // disagrees with the stuck value
        wr(ln, d, '1);
        rd_check(ln, 1'b1, "E6 stuck-at");
        hits++;
      end
      fi_type = `SF_FT_NONE;
      wr(ln, mkdata(), '1);
    end

    // ---- E7: randomized soak with exact CE accounting
    cur = "E7 soak";
    $display("[%0t] E7 randomized soak (%0d operations)", $time, NSOAK);
    begin
      int errw [CAP_LINES];
      int exp_ce, base;
      for (int i = 0; i < CAP_LINES; i++) errw[i] = 0;
      for (int ln = 0; ln < CAP_LINES; ln++) wr(ln, mkdata(), '1);
      base = total_ce(); exp_ce = 0;
      for (int n = 0; n < NSOAK; n++) begin
        int ln, op; logic [BE_W-1:0] be;
        ln = rndn(CAP_LINES); op = rndn(100);
        if (op < 25) begin                                                     // upset (one outstanding error per line)
          if (errw[ln] == 0) begin seu(ln, STORE_W'(1) << rndn(STORE_W)); errw[ln] = 1; end
        end else if (op < 55) begin                                            // read
          rd_check(ln, errw[ln] == 1, "E7 read");
          if (errw[ln] == 1) exp_ce++;
        end else if (op < 80) begin                                            // full write: repairs
          wr(ln, mkdata(), '1); errw[ln] = 0;
        end else begin                                                         // partial write: RMW, repairs
          be = BE_W'(rnd());
          if (be == 0) be = 16'h1;
          if (be == '1) begin wr(ln, mkdata(), '1); errw[ln] = 0; end
          else begin wr(ln, mkdata(), be); if (errw[ln] == 1) exp_ce++; errw[ln] = 0; end
        end
      end
      repeat (4) @(posedge clk);
      check(total_ce() - base == exp_ce, $sformatf("E7: correctable counter +%0d != expected %0d", total_ce() - base, exp_ce));
      $display("    soak: %0d correctable events expected and counted", exp_ce);
    end

    // ---- E8: characterisation of 3-bit errors (not pass/fail)
    cur = "E8 triple errors";
    for (int n = 0; n < 300; n++) begin
      int ln, b1, b2, b3;
      logic [DW-1:0] orig;
      ln = rndn(CAP_LINES); b1 = rndn(STORE_W); b2 = (b1 + 1 + rndn(STORE_W - 1)) % STORE_W; b3 = rndn(STORE_W);
      while (b3 == b1 || b3 == b2) b3 = (b3 + 1) % STORE_W;
      wr(ln, mkdata(), '1); orig = model[ln];
      seu(ln, (STORE_W'(1) << b1) | (STORE_W'(1) << b2) | (STORE_W'(1) << b3));
      xfer(1'b0, ln, '0, '1, rdv, stv, cev);
      if (stv == `SF_ST_ECC_UE) flag3++; else if (rdv !== orig) mis3++;
      wr(ln, mkdata(), '1);
    end
    $display("    3-bit errors: %0d flagged uncorrectable, %0d silently MISCORRECTED (data differs, no flag), %0d benign (only check bits hit)", flag3, mis3, 300 - flag3 - mis3);

    $display("RESULT tb=ecc_system NB=%0d READ_LATENCY=%0d checks=%0d errors=%0d ce_total=%0d ue_total=%0d triple_flagged=%0d triple_miscorrected=%0d %s",
             NB, READ_LATENCY, n_checks, n_err, total_ce(), total_ue(), flag3, mis3, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(64'd2_000_000_000); $display("RESULT tb=ecc_system errors=1 WATCHDOG FAIL"); $finish; end
endmodule
