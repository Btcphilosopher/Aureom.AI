// =============================================================================
// SilicaFlux MemoryCore :: tb_mbist_cov
// MEASURES the detection coverage of the MBIST (March C- / MATS+ engine + sf_sram_mbist_ctl) on the fault
// models of sf_sram_core (FAULT_INJECT = 1), through the real sf_sram_controller test port.
//
// Fault universe (per run, ONE fault injected at a time into bank FBANK, the other bank(s) healthy):
//   SAF0 / SAF1            every cell (DEPTH x STORE_W)                         exhaustive
//   TF up / TF down        every cell                                           exhaustive
//   AF no-access           every row                                            exhaustive
//   AF alias (a -> b)      every ordered row pair a != b                        exhaustive
//   AF multi (a -> a+b)    every ordered row pair                               exhaustive
//   CFin  (up / down)      every ordered cell pair (aggressor != victim)        exhaustive (CF_SAMPLE = 0) or sampled
//   CFid  (up/down x force 0/1), CFst (aggressor state 0/1 x victim force 0/1)  idem
// Coupling results are split SAME-WORD (aggressor and victim in one row) and DIFFERENT-WORD.
// Each fault is run with BOTH data backgrounds (solid, checkerboard); a fault counts as detected by an
// algorithm when either background flags it ("union").  Faults in the check-bit columns of an ECC build are
// included (STORE_W = data + check bits): MBIST tests the raw stored word.
//
// PASS criteria (what MUST hold, independent of the measured numbers): the fault-free run passes with both
// backgrounds; whenever a fault is flagged ONLY the faulty bank is flagged; March C- detects 100 % of SAF, TF
// and AF (textbook result) -- a lower number would mean a defect in the fault model or the engine.
// Everything else is reported as measured, not judged.
// Output: COVER lines (machine readable) and RESULT.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sram_defs.svh"

module tb_mbist_cov #(
  parameter int NB = 2,
  parameter int DEPTH = 4,
  parameter int DW = 32,
  parameter int ECC_EN = 0,
  parameter int READ_LATENCY = 1,
  parameter int ALGO = `SRAM_MBIST_MARCH_CM,
  parameter int CF_SAMPLE = 0,            // 0: exhaustive coupling pairs, else this many random pairs per class
  parameter int FBANK = 1,
  parameter int SEED = 32'h0BADF00D,
  parameter string LABEL = "march_c-"
);
  localparam int R_ECC   = $clog2(DW + $clog2(DW + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? DW + R_ECC + 1 : DW;
  localparam int ROW_W   = $clog2(DEPTH);
  localparam int FBW     = $clog2(STORE_W);
  localparam int BW      = (NB > 1) ? $clog2(NB) : 1;
  localparam int AW      = 12;
  localparam int BE_W    = DW / 8;
  localparam int NCLS    = 17;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT: controller (no functional traffic) + MBIST
  logic tb_init = 1'b0;
  logic mb_start = 1'b0, mb_bg = 1'b0, mb_stop = 1'b0;
  logic [NB-1:0] mb_mask;
  logic mb_busy, mb_done, mb_pass, mb_fail, mb_quiesce, mb_init, mb_tst_active, mb_tst_ce, mb_tst_we;
  logic [NB-1:0] mb_fmask, mb_tst_sel;
  logic [ROW_W-1:0] mb_faddr, mb_tst_addr;
  logic [2:0] mb_felem;
  logic [STORE_W-1:0] mb_fsyn, mb_tst_wdata;
  logic [15:0] mb_fcnt;
  logic c_idle, c_initbusy;
  logic [NB*STORE_W-1:0] tst_rdata;
  logic [BW-1:0] fi_bank = BW'(FBANK);
  logic [3:0] fi_type = 4'd0;
  logic [ROW_W-1:0] fi_row = '0, fi_row2 = '0;
  logic [FBW-1:0] fi_bit = '0, fi_bit2 = '0;
  logic fi_val = 1'b0, fi_val2 = 1'b0;

  sf_sram_controller #(.NM(1), .NB(NB), .DEPTH(DEPTH), .DW(DW), .AW(AW), .IDW(1), .READ_LATENCY(READ_LATENCY),
                       .ECC_EN(ECC_EN), .NSLOT(4), .INIT_ON_RESET(1), .SIM_INIT(2), .FAULT_INJECT(1)) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(1'b0), .m_req_ready(), .m_req_we(1'b0), .m_req_addr('0), .m_req_wdata('0), .m_req_be('0), .m_req_id('0),
    .m_rsp_valid(), .m_rsp_ready(1'b1), .m_rsp_rdata(), .m_rsp_id(), .m_rsp_we(), .m_rsp_status(), .m_rsp_ce(),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(mb_quiesce), .idle_o(c_idle),
    .init_start_i(tb_init | mb_init), .init_busy_o(c_initbusy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(), .ev_ue_o(), .ce_cnt_o(), .ue_cnt_o(),
    .perf_acc_o(), .perf_conf_o(), .perf_busy_o(), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(mb_tst_active), .tst_sel_i(mb_tst_sel), .tst_ce_i(mb_tst_ce), .tst_we_i(mb_tst_we),
    .tst_addr_i(mb_tst_addr), .tst_wdata_i(mb_tst_wdata), .tst_rdata_o(tst_rdata),
    .fi_bank(fi_bank), .fi_type(fi_type), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2),
    .fi_val(fi_val), .fi_val2(fi_val2), .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  sf_sram_mbist_ctl #(.NB(NB), .DEPTH(DEPTH), .STORE_W(STORE_W), .READ_LATENCY(READ_LATENCY), .ALGO(ALGO)) mbist (
    .clk(clk), .rst_n(rst_n), .start_i(mb_start), .bank_mask_i(mb_mask), .bg_checker_i(mb_bg), .stop_on_fail_i(mb_stop),
    .busy_o(mb_busy), .done_o(mb_done), .pass_o(mb_pass), .fail_o(mb_fail), .fail_mask_o(mb_fmask), .fail_addr_o(mb_faddr),
    .fail_elem_o(mb_felem), .fail_syndrome_o(mb_fsyn), .fail_count_o(mb_fcnt),
    .quiesce_o(mb_quiesce), .idle_i(c_idle), .init_start_o(mb_init), .init_busy_i(c_initbusy),
    .tst_active_o(mb_tst_active), .tst_sel_o(mb_tst_sel), .tst_ce_o(mb_tst_ce), .tst_we_o(mb_tst_we),
    .tst_addr_o(mb_tst_addr), .tst_wdata_o(mb_tst_wdata), .tst_rdata_i(tst_rdata));

  // ---------------------------------------------------------------- coverage bookkeeping
  string cname [NCLS] = '{"SAF0","SAF1","TF_up","TF_down","AF_noaccess","AF_alias","AF_multi",
                          "CFin_up","CFin_down","CFid_up_f0","CFid_up_f1","CFid_down_f0","CFid_down_f1",
                          "CFst_a0_v0","CFst_a0_v1","CFst_a1_v0","CFst_a1_v1"};
  int tot [NCLS][2], d_solid [NCLS][2], d_chk [NCLS][2], d_union [NCLS][2];   // [class][0 same-word / 1 different-word]
  int n_err = 0, n_checks = 0, n_iso = 0;
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction

  task automatic chk(input bit c, input string m);
    n_checks++;
    if (!c) begin n_err++; if (n_err <= 20) $display("  [FAIL] %s", m); end
  endtask

  task automatic run_mbist(input bit bg, input logic [NB-1:0] mask, output bit failed, output logic [NB-1:0] fmask);
    int t;
    mb_bg = bg; mb_mask = mask;
    @(negedge clk); mb_start = 1'b1; @(negedge clk); mb_start = 1'b0;
    repeat (2) @(posedge clk);
    t = 0;
    while (!mb_done && t < 20000) begin @(posedge clk); t++; end
    chk(t < 20000, "MBIST did not finish");
    @(posedge clk);
    failed = mb_fail; fmask = mb_fmask;
  endtask

  task automatic reinit();                    // known pre-state (all-zero valid lines) before each fault
    fi_type = 4'd0;
    @(negedge clk); tb_init = 1'b1; @(negedge clk); tb_init = 1'b0;
    repeat (3) @(posedge clk);
    while (c_initbusy) @(posedge clk);
    repeat (2) @(posedge clk);
  endtask

  // run one fault with both backgrounds; update class stats
  task automatic eval_fault(input int cls, input int scope, input logic [NB-1:0] mask);
    bit f0, f1;
    logic [NB-1:0] m0, m1;
    logic [3:0] ft;
    ft = fi_type;                              // reinit() removes the fault to give a known (all-zero) pre-state
    reinit();
    fi_type = ft;                              // ... and the fault is injected again before the March run
    fi_bank = BW'(FBANK);
    run_mbist(1'b0, mask, f0, m0);
    // the second background starts from the array content the first run left behind (MBIST ends with a re-init)
    run_mbist(1'b1, mask, f1, m1);
    tot[cls][scope]++;
    if (f0) d_solid[cls][scope]++;
    if (f1) d_chk[cls][scope]++;
    if (f0 || f1) d_union[cls][scope]++;
    // isolation: only the faulty bank may ever be flagged
    if (f0) begin n_iso++; chk(m0 == (NB'(1) << FBANK), $sformatf("%s: bank flags %b != faulty bank only", cname[cls], m0)); end
    if (f1) begin n_iso++; chk(m1 == (NB'(1) << FBANK), $sformatf("%s: bank flags %b != faulty bank only (checker)", cname[cls], m1)); end
  endtask

  function automatic int scope_of(input int r1, input int r2); return (r1 == r2) ? 0 : 1; endfunction

  initial begin
    bit f0, f1;
    logic [NB-1:0] m0, m1, all;
    int n;
    all = '1;
    mb_mask = '1;
    for (int c = 0; c < NCLS; c++) for (int s = 0; s < 2; s++) begin tot[c][s] = 0; d_solid[c][s] = 0; d_chk[c][s] = 0; d_union[c][s] = 0; end
    repeat (4) @(posedge clk);
    rst_n = 1'b1;
    repeat (4) @(posedge clk);
    while (c_initbusy || !c_idle) @(posedge clk);
    $display("CONFIG label=%s NB=%0d DEPTH=%0d DW=%0d STORE_W=%0d ECC_EN=%0d READ_LATENCY=%0d ALGO=%0d CF_SAMPLE=%0d", LABEL, NB, DEPTH, DW, STORE_W, ECC_EN, READ_LATENCY, ALGO, CF_SAMPLE);

    // ---- fault-free control: must PASS with both backgrounds, all banks
    reinit();
    run_mbist(1'b0, all, f0, m0); chk(!f0 && m0 == '0, "fault-free run (solid background) reported a failure");
    run_mbist(1'b1, all, f1, m1); chk(!f1 && m1 == '0, "fault-free run (checkerboard) reported a failure");

    // ---- SAF / TF: every cell
    for (int r = 0; r < DEPTH; r++) for (int b = 0; b < STORE_W; b++) begin
      fi_row = ROW_W'(r); fi_bit = FBW'(b);
      fi_type = `SF_FT_SAF; fi_val = 1'b0; eval_fault(0, 0, all);
      fi_type = `SF_FT_SAF; fi_val = 1'b1; eval_fault(1, 0, all);
      fi_type = `SF_FT_TF;  fi_val = 1'b1; eval_fault(2, 0, all);
      fi_type = `SF_FT_TF;  fi_val = 1'b0; eval_fault(3, 0, all);
    end
    // ---- address decoder faults
    for (int a = 0; a < DEPTH; a++) begin
      fi_row = ROW_W'(a); fi_type = `SF_FT_AF_NA; eval_fault(4, 0, all);
      for (int b = 0; b < DEPTH; b++) if (a != b) begin
        fi_row2 = ROW_W'(b);
        fi_type = `SF_FT_AF_ALI; eval_fault(5, 0, all);
        fi_type = `SF_FT_AF_MUL; eval_fault(6, 0, all);
      end
    end
    // ---- coupling faults (only the faulty bank is under test: bank mask = faulty bank)
    n = (CF_SAMPLE == 0) ? (DEPTH * STORE_W) * (DEPTH * STORE_W - 1) : CF_SAMPLE;
    for (int k = 0; k < n; k++) begin
      int a, v, r1, b1, r2, b2, sc;
      if (CF_SAMPLE == 0) begin
        a = k / (DEPTH * STORE_W - 1); v = k % (DEPTH * STORE_W - 1); if (v >= a) v = v + 1;
      end else begin
        a = int'(rnd() % 32'(DEPTH * STORE_W)); v = int'(rnd() % 32'(DEPTH * STORE_W));
        if (v == a) v = (v + 1) % (DEPTH * STORE_W);
      end
      r1 = a / STORE_W; b1 = a % STORE_W; r2 = v / STORE_W; b2 = v % STORE_W; sc = scope_of(r1, r2);
      fi_row = ROW_W'(r1); fi_bit = FBW'(b1); fi_row2 = ROW_W'(r2); fi_bit2 = FBW'(b2);
      fi_type = `SF_FT_CFIN; fi_val = 1'b1; eval_fault(7, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFIN; fi_val = 1'b0; eval_fault(8, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFID; fi_val = 1'b1; fi_val2 = 1'b0; eval_fault(9, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFID; fi_val = 1'b1; fi_val2 = 1'b1; eval_fault(10, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFID; fi_val = 1'b0; fi_val2 = 1'b0; eval_fault(11, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFID; fi_val = 1'b0; fi_val2 = 1'b1; eval_fault(12, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFST; fi_val = 1'b0; fi_val2 = 1'b0; eval_fault(13, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFST; fi_val = 1'b0; fi_val2 = 1'b1; eval_fault(14, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFST; fi_val = 1'b1; fi_val2 = 1'b0; eval_fault(15, sc, NB'(1) << FBANK);
      fi_type = `SF_FT_CFST; fi_val = 1'b1; fi_val2 = 1'b1; eval_fault(16, sc, NB'(1) << FBANK);
    end
    fi_type = 4'd0;

    // ---- report
    for (int c = 0; c < NCLS; c++)
      for (int s = 0; s < 2; s++)
        if (tot[c][s] > 0)
          $display("COVER label=%s class=%s scope=%s total=%0d solid=%0d checker=%0d union=%0d union_pct=%0.2f", LABEL, cname[c],
                   (c < 7) ? "cell" : (s == 0 ? "same_word" : "diff_word"), tot[c][s], d_solid[c][s], d_chk[c][s], d_union[c][s],
                   100.0 * d_union[c][s] / tot[c][s]);
    // textbook requirement for March C-: 100 % of SAF, TF, AF
    if (ALGO == `SRAM_MBIST_MARCH_CM)
      for (int c = 0; c < 7; c++) chk(d_union[c][0] == tot[c][0], $sformatf("March C- must detect 100%% of %s (%0d/%0d)", cname[c], d_union[c][0], tot[c][0]));
    $display("RESULT tb=mbist_cov label=%s checks=%0d errors=%0d isolation_checks=%0d %s", LABEL, n_checks, n_err, n_iso, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #(64'd4_000_000_000);
    $display("RESULT tb=mbist_cov label=%s errors=1 WATCHDOG TIMEOUT FAIL", LABEL);
    $finish;
  end
endmodule
