// =============================================================================
// SilicaFlux MemoryCore :: tb_ecc_codec
// Verifies sf_ecc_enc / sf_ecc_dec (SECDED, K data bits) against the INDEPENDENT Python reference
// (tools/ecc/secded_ref.py) and by exhaustive error sweeps:
//   1. encoder == golden codewords (tb/vectors/ecc_k<K>_enc.hex): walking ones/zeros, patterns, random
//   2. clean codeword -> class NONE, data unchanged
//   3. EVERY single-bit error of EVERY vector (N flips) -> corrected, class CE_DATA / CE_CHECK as expected,
//      corrected codeword == original
//   4. EVERY double-bit error of the first NSWEEP vectors (N*(N-1)/2 pairs) -> UE_DOUBLE, never corrected
//   5. multi-bit (weight 1..6) words with the reference decoder's verdict (class and data_out) -> exact match
//      (this includes weight-3 miscorrections and weight-4 aliasing: the RTL must behave like the reference)
//   6. all-zero stored word (dead word line / un-initialised macro) -> UNCORRECTABLE (default inversion)
// Prints RESULT tb=ecc_codec K=.. checks=.. errors=.. PASS|FAIL.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_ecc_codec #(
  parameter int K = 128,
  parameter int NENC = 400,
  parameter int NERR = 4000,
  parameter int NSWEEP = 24,
  parameter string VDIR = "tb/vectors"
);
  localparam int R = $clog2(K + $clog2(K + 1) + 1);
  localparam int N = K + R + 1;

  logic [K-1:0] data_i;
  logic [N-1:0] cw_enc, cw_in, cw_corr;
  logic [K-1:0] data_o;
  logic ce, ue;
  logic [2:0] cls;
  logic [$clog2(N)-1:0] idx;

  sf_ecc_enc #(.K(K)) u_enc (.data_i(data_i), .cw_o(cw_enc));
  sf_ecc_dec #(.K(K)) u_dec (.cw_i(cw_in), .data_o(data_o), .cw_corr_o(cw_corr), .ce_o(ce), .ue_o(ue),
                             .class_o(cls), .err_idx_o(idx));

  logic [K-1:0] vdata [NENC];
  logic [N-1:0] vcw   [NENC];
  logic [N-1:0] ebad  [NERR];
  logic [3:0]   ecls  [NERR];
  logic [K-1:0] edat  [NERR];

  int n_checks = 0, n_err = 0;
  task automatic chk(input bit c, input string m);
    n_checks++;
    if (!c) begin n_err++; if (n_err <= 20) $display("  [FAIL] %s", m); end
  endtask

  // vector files: "data cw" and "cw class data" (hex)
  task automatic load_vectors();
    int fd, r;
    string line;
    logic [K-1:0] d; logic [N-1:0] w; logic [N-1:0] bw; logic [3:0] c; logic [K-1:0] dd;
    fd = $fopen($sformatf("%s/ecc_k%0d_enc.hex", VDIR, K), "r");
    if (fd == 0) begin $display("RESULT tb=ecc_codec K=%0d errors=1 cannot open enc vectors FAIL", K); $finish; end
    for (int i = 0; i < NENC; i++) begin
      r = $fscanf(fd, "%h %h\n", d, w);
      if (r != 2) begin $display("RESULT tb=ecc_codec K=%0d errors=1 short enc vector file at %0d FAIL", K, i); $finish; end
      vdata[i] = d; vcw[i] = w;
    end
    $fclose(fd);
    fd = $fopen($sformatf("%s/ecc_k%0d_err.hex", VDIR, K), "r");
    if (fd == 0) begin $display("RESULT tb=ecc_codec K=%0d errors=1 cannot open err vectors FAIL", K); $finish; end
    for (int i = 0; i < NERR; i++) begin
      r = $fscanf(fd, "%h %h %h\n", bw, c, dd);
      if (r != 3) begin $display("RESULT tb=ecc_codec K=%0d errors=1 short err vector file at %0d FAIL", K, i); $finish; end
      ebad[i] = bw; ecls[i] = c; edat[i] = dd;
    end
    $fclose(fd);
  endtask

  initial begin
    int n_ce_data, n_ce_chk, n_ue;
    int mis3 = 0, tot3 = 0;
    load_vectors();
    $display("CONFIG K=%0d R=%0d N=%0d vectors=%0d error-vectors=%0d sweep-words=%0d", K, R, N, NENC, NERR, NSWEEP);
    n_ce_data = 0; n_ce_chk = 0; n_ue = 0;
    // ---- 1/2: encoder vs golden, clean decode
    for (int i = 0; i < NENC; i++) begin
      data_i = vdata[i]; #1;
      chk(cw_enc === vcw[i], $sformatf("encoder mismatch vector %0d: %h != golden %h", i, cw_enc, vcw[i]));
      cw_in = vcw[i]; #1;
      chk(cls == `SF_ECC_NONE && !ce && !ue && data_o === vdata[i], $sformatf("clean word %0d not classified NONE (class %0d)", i, cls));
    end
    // ---- 3: every single-bit error of every vector
    for (int i = 0; i < NENC; i++) begin
      for (int b = 0; b < N; b++) begin
        cw_in = vcw[i] ^ (N'(1) << b); #1;
        chk(ce && !ue && data_o === vdata[i] && cw_corr === vcw[i], $sformatf("single error vec %0d bit %0d not corrected", i, b));
        chk(cls == ((b < K) ? `SF_ECC_CE_DATA : `SF_ECC_CE_CHECK), $sformatf("single error vec %0d bit %0d wrong class %0d", i, b, cls));
        chk(int'(idx) == b, $sformatf("single error vec %0d bit %0d located at %0d", i, b, idx));
        if (b < K) n_ce_data++; else n_ce_chk++;
      end
    end
    // ---- 4: every double-bit error of the first NSWEEP vectors
    for (int i = 0; i < NSWEEP; i++) begin
      for (int b1 = 0; b1 < N; b1++)
        for (int b2 = b1 + 1; b2 < N; b2++) begin
          cw_in = vcw[i] ^ (N'(1) << b1) ^ (N'(1) << b2); #1;
          chk(ue && !ce && cls == `SF_ECC_UE_DOUBLE && cw_corr === cw_in, $sformatf("double error vec %0d bits %0d,%0d not detected (class %0d)", i, b1, b2, cls));
          n_ue++;
        end
    end
    // ---- 5: reference verdict on multi-bit words
    for (int i = 0; i < NERR; i++) begin
      cw_in = ebad[i]; #1;
      chk(cls == ecls[i][2:0] && data_o === edat[i], $sformatf("error vec %0d: RTL class %0d data %h != reference class %0d data %h", i, cls, data_o, ecls[i], edat[i]));
    end
    // ---- 6: dead word line / never-initialised macro
    cw_in = '0; #1;
    chk(ue && !ce, "all-zero stored word must decode as uncorrectable");
    cw_in = '1; #1;
    chk(ue && !ce, "all-ones stored word must decode as uncorrectable");
    $display("    single-bit sweeps: %0d data + %0d check bit errors corrected; double-bit sweeps: %0d detected", n_ce_data, n_ce_chk, n_ue);
    $display("RESULT tb=ecc_codec K=%0d checks=%0d errors=%0d %s", K, n_checks, n_err, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule
