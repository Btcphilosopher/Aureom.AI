// synthesis wrapper: ECC bank, 1024 rows x 128 b, latency 1
module syn_bank_ecc (
  input  wire clk, rst_n, req_valid, req_we, input wire [9:0] req_row, input wire [127:0] req_wdata, input wire [15:0] req_be, input wire [3:0] req_tag,
  output wire req_ready, rsp_valid, output wire [127:0] rsp_rdata, output wire [3:0] rsp_tag, output wire rsp_we, output wire [2:0] rsp_status, output wire rsp_ce,
  input wire init_start_i, scrub_en_i, output wire init_busy_o, idle_o
);
  wire [136:0] trd; wire [15:0] cc, uc; wire [9:0] fc, fu; wire ec, eu; wire [9:0] er; wire [1:0] ek;
  sf_sram_bank #(.DEPTH(1024), .DW(128), .READ_LATENCY(1), .ECC_EN(1), .TAG_W(4), .SCRUB_EN(1)) u (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_we(req_we), .req_row(req_row), .req_wdata(req_wdata), .req_be(req_be), .req_tag(req_tag),
    .rsp_valid(rsp_valid), .rsp_rdata(rsp_rdata), .rsp_tag(rsp_tag), .rsp_we(rsp_we), .rsp_status(rsp_status), .rsp_ce(rsp_ce),
    .init_start_i(init_start_i), .init_busy_o(init_busy_o), .scrub_en_i(scrub_en_i), .idle_o(idle_o),
    .ev_ce_o(ec), .ev_ue_o(eu), .ev_row_o(er), .ev_kind_o(ek), .cnt_clr_i(1'b0), .ce_cnt_o(cc), .ue_cnt_o(uc), .first_ce_row_o(fc), .first_ue_row_o(fu),
    .tst_active_i(1'b0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i(10'd0), .tst_wdata_i(137'd0), .tst_rdata_o(trd),
    .fi_type(4'd0), .fi_row(10'd0), .fi_row2(10'd0), .fi_bit(8'd0), .fi_bit2(8'd0), .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row(10'd0), .seu_mask(137'd0));
endmodule
