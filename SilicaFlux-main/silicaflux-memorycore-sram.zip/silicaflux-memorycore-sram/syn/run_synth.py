#!/usr/bin/env python3
"""Technology-independent logic synthesis report (Yosys 0.33 generic gates, NO standard-cell library, NO timing, NO PDK).

    python3 syn/run_synth.py [--jobs 2]   ->  reports/synthesis.json, reports/synthesis.md

Per module/configuration: Yosys `synth -flatten` up to (not including) memory mapping, `techmap`, `abc -fast`, `stat`.
SRAM ARRAYS ARE LEFT AS $mem CELLS (a real flow maps them to macros); the table reports LOGIC cells only plus the memory bits the
$mem cells hold.  Latches are counted (must be 0).  Cell counts are generic-gate counts, not area: no frequency, area in um2 or power
is claimed anywhere in this project from these numbers.
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/sf_sram_core.sv", "rtl/backends/sf_sram_fpga_bram.sv", "rtl/backends/sf_sram_asic_sky130.sv", "rtl/sf_sram_macro_wrapper.sv", "rtl/sf_ecc_enc.sv",
       "rtl/sf_ecc_dec.sv", "rtl/sf_ecc_counters.sv", "rtl/sf_sram_bank.sv", "rtl/sf_sram_controller.sv", "rtl/sf_sync_fifo.sv", "rtl/sf_sram_datafabric.sv",
       "rtl/sf_vector_scratchpad.sv", "rtl/sf_ts_port.sv", "rtl/sf_tensor_scratchpad.sv", "rtl/sf_sram_mbist_ctl.sv", "third_party/sramlib_mbist/sram_mbist_march.sv",
       "third_party/ras_secded/sfras_secded_enc.sv", "third_party/ras_secded/sfras_secded_dec.sv", "sim_models/sky130_sram_standin.sv"]
INC = "-Irtl -Ithird_party/ras_secded -Ithird_party/sramlib_mbist"
# name, top, parameter overrides, memory bits (formula for the report)
ITEMS = [
    ("sf_ecc_enc K=128", "sf_ecc_enc", dict(K=128), 0),
    ("sf_ecc_dec K=128", "sf_ecc_dec", dict(K=128), 0),
    ("sf_sram_core 1024x128", "sf_sram_core", dict(DEPTH=1024, DATA_W=128, BE_W=16, READ_LATENCY=1, TAG_W=4), 1024 * 128),
    ("sf_sram_bank 1024x128 (no ECC)", "sf_sram_bank", dict(DEPTH=1024, DW=128, ECC_EN=0, TAG_W=5), 1024 * 128),
    ("sf_sram_bank 1024x137 SECDED + scrub", "sf_sram_bank", dict(DEPTH=1024, DW=128, ECC_EN=1, TAG_W=5, SCRUB_EN=1), 1024 * 137),
    ("sf_sram_controller NM4 NB4 4x1024x128", "sf_sram_controller", dict(NM=4, NB=4, DEPTH=1024, DW=128, AW=32, IDW=8, ECC_EN=0, NSLOT=8), 4 * 1024 * 128),
    ("sf_sram_controller NM4 NB4 SECDED", "sf_sram_controller", dict(NM=4, NB=4, DEPTH=1024, DW=128, AW=32, IDW=8, ECC_EN=1, NSLOT=8), 4 * 1024 * 137),
    ("sf_sram_controller NM2 NB2 small", "sf_sram_controller", dict(NM=2, NB=2, DEPTH=64, DW=128, AW=20, IDW=4, ECC_EN=0, NSLOT=4), 2 * 64 * 128),
    ("sf_sram_datafabric DW128 NP1", "sf_sram_datafabric", dict(NM=4, AW=32, DW=128, IDW=2, NP=1), 0),
    ("sf_sram_datafabric DW32 NP2", "sf_sram_datafabric", dict(NM=4, AW=32, DW=32, IDW=2, NP=2), 0),
    ("sf_vector_scratchpad VEC128", "sf_vector_scratchpad", dict(VEC_LINES=1, NB=4, CAP_LINES=4096, AW=32), 0),
    ("sf_vector_scratchpad VEC512", "sf_vector_scratchpad", dict(VEC_LINES=4, NB=4, CAP_LINES=4096, AW=32), 0),
    ("sf_tensor_scratchpad 8x1 lines, ping-pong", "sf_tensor_scratchpad", dict(AW=32, NB=4, CAP_LINES=4096, NBUF=2, A_ROWS=8, B_ROWS=8, C_ROWS=8), 0),
    ("sf_sram_mbist_ctl NB4 1024x128", "sf_sram_mbist_ctl", dict(NB=4, DEPTH=1024, STORE_W=128), 0),
]

def run(item):
    name, top, ov, membits = item
    ch = "; ".join(f"chparam -set {k} {v} {top}" for k, v in ov.items())
    ys = (f"read_verilog -sv {INC} {' '.join(RTL)}; {ch}; hierarchy -check -top {top}; synth -flatten -run :fine; "
          f"opt -fast -full; techmap; opt -fast; abc -fast; opt_clean; check; tee -o /dev/stdout stat")
    t0 = time.time()
    r = subprocess.run(["yosys", "-q", "-p", ys], cwd=ROOT, capture_output=True, text=True, timeout=1200)
    out = r.stdout + r.stderr
    if r.returncode != 0 and "Number of cells" not in out:
        return dict(name=name, top=top, status="FAIL", detail=out[-400:])
    cells = re.search(r"Number of cells:\s+(\d+)", out) or re.search(r"(\d+)\s+cells", out)
    types = {m.group(1): int(m.group(2)) for m in re.finditer(r"^\s+(\$\w+)\s+(\d+)$", out, re.M)}
    mem_cells = sum(v for k, v in types.items() if k.startswith("$mem"))
    latches = sum(v for k, v in types.items() if "latch" in k.lower())
    ffs = sum(v for k, v in types.items() if "dff" in k.lower())
    logic = sum(v for k, v in types.items() if not k.startswith("$mem") and "dff" not in k.lower())
    warn = len(re.findall(r"Warning: .*latch", out, re.I))
    return dict(name=name, top=top, params=ov, status="OK", total_cells=int(cells.group(1)) if cells else None, flip_flops=ffs, logic_cells=logic,
                mem_cells=mem_cells, memory_bits=membits, latches=latches + warn, secs=round(time.time() - t0, 1), cell_types=types)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--jobs", type=int, default=2); a = ap.parse_args()
    with ThreadPoolExecutor(a.jobs) as ex:
        rs = list(ex.map(run, ITEMS))
    json.dump(dict(tool=subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip(), results=rs), open(os.path.join(ROOT, "reports", "synthesis.json"), "w"), indent=1)
    md = ["# Logic synthesis (Yosys generic gates; no PDK, no timing, no area)", "",
          "SRAM arrays stay `$mem` cells (macro mapping is a physical-design step). Counts are generic-gate counts, NOT standard-cell area.", "",
          "| module / configuration | status | flip-flops | other logic cells | `$mem` cells | memory bits | latches | s |", "|---|---|---:|---:|---:|---:|---:|---:|"]
    for r in rs:
        md.append(f"| {r['name']} | {r['status']} | {r.get('flip_flops', '-')} | {r.get('logic_cells', '-')} | {r.get('mem_cells', '-')} | {r.get('memory_bits', '-')} | {r.get('latches', '-')} | {r.get('secs', '-')} |")
    open(os.path.join(ROOT, "reports", "synthesis.md"), "w").write("\n".join(md) + "\n")
    for r in rs: print(r["name"], r["status"], r.get("flip_flops"), r.get("logic_cells"), r.get("mem_cells"), r.get("latches"), r.get("detail", "")[:120])
    return 0 if all(r["status"] == "OK" for r in rs) else 1
if __name__ == "__main__":
    sys.exit(main())
