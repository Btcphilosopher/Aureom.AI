#!/usr/bin/env python3
"""Build the self-contained SRAMLab dashboard (dashboard/sramlab_dashboard.html) from the reports and RTL traces of this package.

    bash dashboard/make_traces.sh          # RTL-SIMULATION traces (needs Verilator)
    python3 dashboard/build_dashboard.py   # -> dashboard/sramlab_dashboard.html  (no network access needed to view it)

Every panel carries a provenance tag:
    SIMULATED  : output of a Verilator run of the RTL in this package (reports/*.json, build/trace/*.out)
    ESTIMATED  : analytical ceilings, the sramlab cycle model, or energy numbers computed from ASSUMED parameters
    GENERATED  : geometry generated from macro-manifest dimensions (not a routed / signed-off layout)
    MEASURED   : none. No silicon measurement exists in this package; the legend says so.
"""
import datetime
import glob
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def jload(rel, default=None):
    p = os.path.join(ROOT, rel)
    if not os.path.exists(p):
        return default
    with open(p) as fh:
        return json.load(fh)


def kv(line):
    return {k: v for k, v in re.findall(r"(\w+)=(\S+)", line)}


def parse_trace(name):
    p = os.path.join(ROOT, "build", "trace", name + ".out")
    out = []
    if not os.path.exists(p):
        return out
    for l in open(p, errors="replace"):
        if l.startswith("DT "):
            parts = l.split()
            out.append((parts[1], parts[2], kv(l)))
    return out


def ints(d):
    r = {}
    for k, v in d.items():
        try:
            r[k] = int(v)
        except ValueError:
            r[k] = v
    return r


def merged_mutation():
    allm = {}
    for f in sorted(glob.glob(os.path.join(ROOT, "reports", "mutation*.json"))):
        try:
            d = json.load(open(f))
        except Exception:
            continue
        for m in d.get("mutants", []):
            allm[m["id"]] = m          # later files override earlier ones (re-runs after TB strengthening)
    ms = sorted(allm.values(), key=lambda m: int(m["id"][1:]))
    killed = sum(1 for m in ms if str(m.get("verdict")).upper() == "KILLED")
    return {"killed": killed, "total": len(ms), "survived": [m["id"] for m in ms if str(m.get("verdict")).upper() != "KILLED"]}


def main():
    D = {"generated": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")}
    # ---------------------------------------------------------------- regressions / verification
    D["regress"] = {}
    for s in ("ctrl", "dfab", "vsp", "tsp", "ecc"):
        r = jload(f"reports/regress_{s}.json")
        if r:
            D["regress"][s] = {"passed": r["passed"], "total": r["total"], "checks": r["checks"]}
    D["mutation"] = merged_mutation()
    latest = {}
    for f in (jload("reports/formal.json", []) or []):
        latest[(f["cfg"], bool(f.get("data")))] = f           # later entries replace earlier runs of the same configuration
    D["formal"] = [{"cfg": f["cfg"], "data": f.get("data"), "frames": f.get("frames_proved"), "depth": f.get("depth_requested"), "status": f["status"],
                    "latches": f.get("aig", {}).get("latches"), "ands": f.get("aig", {}).get("ands")} for f in latest.values()]
    syn = jload("reports/synthesis.json", {}) or {}
    D["synth_tool"] = syn.get("tool", "")
    D["synth"] = [{k: r.get(k) for k in ("name", "status", "flip_flops", "logic_cells", "mem_cells", "memory_bits", "latches")} for r in syn.get("results", [])]
    # ---------------------------------------------------------------- benchmarks
    b = jload("reports/bench_rtl.json", {"controller": []})
    D["bench"] = [{k: r[k] for k in ("config", "pattern", "nm", "nb", "depth", "read_latency", "ecc", "nslot", "arb", "rsp_pct", "load_pct", "cycles",
                                      "throughput_Bpc", "bank_conflict_cycles", "bank_busy_stalls", "mean_latency", "max_latency") if k in r}
                  for r in b["controller"]]
    D["tensor"] = b.get("tensor", [])
    D["vector_dma"] = b.get("vector_dma", {})
    v = jload("reports/sramlab_vs_rtl.json", {})
    D["ceilings"] = [{k: r.get(k) for k in ("config", "pattern", "pattern_name", "nm", "nb", "rtl_Bpc", "model_Bpc", "ceil_Bpc", "eff", "ceil_formula", "ceil_exact")}
                     for r in v.get("ceilings", []) if r.get("rsp_pct") == 100 and r.get("load_pct") == 100]
    D["validation"] = v.get("validation", {}).get("summary", v.get("validation", {}))
    D["sat"] = v.get("saturation", [])
    # ---------------------------------------------------------------- energy / physical / mbist
    e = jload("reports/sramlab_energy.json", {})
    D["energy"] = {"label": e.get("label", ""), "bench": e.get("benchmarks", []), "ecc": e.get("ecc_over_noecc_by_pattern", []),
                   "tensor": e.get("tensor", {}), "standby": e.get("standby", []), "relative": e.get("relative", {}).get("parameter_free", {}),
                   "params": e.get("params_nominal", {})}
    fp = jload("physical/dashboard_floorplan.json", {})
    D["floorplans"] = fp.get("floorplans", [])
    D["fp_disclaimer"] = fp.get("disclaimer", "")
    mb = jload("reports/mbist_coverage.json", [])
    D["mbist"] = [{"label": m["label"], "desc": m["desc"], "status": m["status"],
                   "coverage": [{k: c[k] for k in ("class", "scope", "total", "union", "union_pct")} for c in m["coverage"]]} for m in mb]
    # ---------------------------------------------------------------- RTL traces
    T = {}
    ctrl = parse_trace("bench_ctrl")
    T["ctrl"] = {"acc": [ints(d) for t, k, d in ctrl if k == "acc"], "rsp": [ints(d) for t, k, d in ctrl if k == "rsp"]}
    tsp = parse_trace("tensor_scratchpad")
    T["tsp"] = {"state": [ints(d) for t, k, d in tsp if k == "state"], "ports": [ints(d) for t, k, d in tsp if k == "ports"]}
    df = parse_trace("datafabric")
    T["df"] = {"tgt": [ints(d) for t, k, d in df if k == "tgt"], "rsp": [ints(d) for t, k, d in df if k == "rsp"]}
    ecc = parse_trace("ecc_system")
    ph = {}
    for t, k, d in ecc:
        p = ph.setdefault(d["phase"], {"phase": d["phase"], "events": 0, "ce": 0, "ue": 0, "first": int(d["cycle"]), "last": int(d["cycle"])})
        p["events"] += 1
        p["ce"] += int(int(d["ce"], 2) > 0)
        p["ue"] += int(int(d["ue"], 2) > 0)
        p["last"] = int(d["cycle"])
    T["ecc"] = {"phases": list(ph.values()), "totals": {}}
    ep = os.path.join(ROOT, "build", "trace", "ecc_system.out")
    if os.path.exists(ep):
        for l in open(ep, errors="replace"):
            if l.startswith("RESULT tb=ecc_system"):
                T["ecc"]["totals"] = {k: (int(v) if v.isdigit() else v) for k, v in kv(l).items()}
    D["traces"] = T
    # ---------------------------------------------------------------- write
    tpl = open(os.path.join(HERE, "dashboard_template.html")).read()
    html = tpl.replace("/*__DATA__*/null", json.dumps(D, separators=(",", ":"), default=str))
    out = os.path.join(HERE, "sramlab_dashboard.html")
    with open(out, "w") as fh:
        fh.write(html)
    print(f"wrote {out} ({len(html)//1024} KiB); traces: ctrl {len(T['ctrl']['acc'])} acc / {len(T['ctrl']['rsp'])} rsp, tsp {len(T['tsp']['state'])} state / "
          f"{len(T['tsp']['ports'])} port, df {len(T['df']['tgt'])} tgt / {len(T['df']['rsp'])} rsp, ecc phases {len(T['ecc']['phases'])}")
    if not T["ctrl"]["acc"]:
        print("WARNING: no RTL trace found - run dashboard/make_traces.sh first", file=sys.stderr)


if __name__ == "__main__":
    main()
