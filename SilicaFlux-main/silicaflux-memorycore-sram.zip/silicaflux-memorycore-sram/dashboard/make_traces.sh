#!/bin/bash
# Build the four testbenches with +DASHTRACE support and capture their event traces for the SRAMLab dashboard.
# Output: build/trace/*.out (lines starting with "DT ").  Pure RTL-SIMULATION data (Verilator).
set -u
cd "$(dirname "$0")/.."
mkdir -p build/trace
V="verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-DECLFILENAME"
build() {  # name extra-filelists
  local t="$1"; shift
  $V -f sim/files_rtl.f "$@" "tb/tb_$t.sv" --top-module "tb_$t" -Mdir "build/tr_$t" -o t.exe > "build/trace/$t.build.log" 2>&1 || { echo "BUILD FAIL $t"; return 1; }
}
build bench_ctrl & build tensor_scratchpad & build datafabric "-f" sim/files_noc.f & build ecc_system &
wait
( cd build/tr_bench_ctrl        && ./t.exe +DASHTRACE +PATTERN=4 +NREQ=40 +SEED=7 > ../trace/bench_ctrl.out 2>&1 )
( cd build/tr_tensor_scratchpad && ./t.exe +DASHTRACE > ../trace/tensor_scratchpad.out 2>&1 )
( cd build/tr_datafabric        && ./t.exe +DASHTRACE > ../trace/datafabric.out 2>&1 )
( cd build/tr_ecc_system        && ./t.exe +DASHTRACE > ../trace/ecc_system.out 2>&1 )
grep -H "^RESULT" build/trace/*.out
