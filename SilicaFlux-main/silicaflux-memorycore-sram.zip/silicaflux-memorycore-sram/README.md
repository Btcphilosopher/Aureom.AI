# SilicaFlux MemoryCore - SRAM architecture, controller and physical-integration package

Aureom.AI | SilicaFlux Semiconductor Programme. SystemVerilog RTL + Python tooling + Yosys / Verilator flows.

> **Read first.** This package contains **no silicon data**. Every number is an RTL-simulation result (Verilator), a model result, or an assumed parameter, and is labelled that way.
> It is **not ASIC-ready**: the repository has no Liberty / LEF / GDS / SPICE views of the SRAM macros and OpenROAD was not run. Formal results are **bounded**. See `docs/KNOWN_LIMITATIONS.md`.

## What was done

1. **Audit** of the existing SilicaFlux memory code (`docs/AUDIT.md`, `reports/audit.json`, `tools/audit/`): every priority file was run through Verilator, Icarus and Yosys; which files parse, elaborate, pass their own tests, synthesize, or are blocked (and by what) is tabulated. `.sf` is plain SystemVerilog text; the legacy `memory_controller.sf` **fails** a cross-check and is kept as a reference only (`docs/SF_COMPAT.md`).
2. **Four-bank baseline, verified**: `sf_sram_core` -> `sf_sram_bank` -> `sf_sram_controller` (4 banks, 128-bit lines, byte addressed, single-port synchronous, byte enables, one access per bank per cycle, per-bank arbitration, in-order responses, back-pressure, transaction ids, range / alignment errors, flush / quiesce). Contract: `docs/CONTRACT.md`.
3. **ECC** (SECDED 137,128, atomic partial-write RMW, scrubber, counters; `docs/ECC.md`) and **MBIST** (March C-, measured fault-model coverage, no repair; `docs/MBIST.md`).
4. **Integration pieces**: `sf_sram_datafabric` (SFB3 target adapter, verified behind the implemented NoC), `sf_vector_scratchpad` (sub-word / multi-line / DMA), `sf_tensor_scratchpad` (ping-pong, hardware ownership), `sf_sram_macro_wrapper` (behavioural / FPGA / SKY130 macro tiling with a labelled stand-in model).
5. **Verification**: byte-accurate scoreboards, deterministic seeds, mutation testing, bounded formal (`docs/VERIFICATION.md`).
6. **Benchmarks A-J, S, Q** with actual RTL-simulation results (`docs/BENCHMARKS.md`) and the **sramlab** performance / energy tool whose cycle model reproduces the RTL exactly (`reports/sramlab_vs_rtl.md`).
7. **Physical / power / research**: geometry-level floorplans from real macro manifests (`physical/`), assumed-parameter energy model (`power/`), uncalibrated SPICE research (`research/spice/`); see `docs/PHYSICAL_POWER.md`.
8. **SRAMLab dashboard**: `dashboard/sramlab_dashboard.html` (self-contained; open in a browser).

## Quick start

```bash
make regress            # five RTL regression suites (Verilator 5.x)
make bench sramlab      # benchmarks A-J + model validation + energy model
make dashboard docs     # RTL traces, dashboard, generated documents
make formal synth mutate    # slower campaigns
```

Individual commands are in the `Makefile`. Build products go to `build/` (safe to delete); `reports/` holds the committed results of the runs described in the documents.

## Layout

| path | content |
|---|---|
| `rtl/` | synthesizable RTL (`sf_sram_*`, `sf_ecc_*`, scratchpads, MBIST sequencer, backends); `rtl/sf_sram_defs.svh` shared constants |
| `sim_models/` | simulation-only stand-in for the SKY130 macro (**not** the vendor model) |
| `tb/` | self-checking testbenches, ECC golden vectors |
| `sim/` | file lists, regression runner, ECC / MBIST campaign runners |
| `formal/` | bounded-proof harness (Yosys -> AIGER -> ABC bmc3) |
| `syn/` | Yosys generic-gate synthesis runner |
| `benchmarks/` | RTL benchmark runner and report generator |
| `tools/sramlab/`, `power/` | cycle model, analytical ceilings, energy model (assumed parameters), plots |
| `tools/audit/`, `tools/mutate.py`, `tools/ecc/` | audit runner, mutation testing, independent ECC reference |
| `sf_compat/` | `.sf` -> `.sv` identity transform, legacy-controller cross-check testbench |
| `third_party/` | reused SilicaFlux code, byte-identical, with SHA-256 manifest and provenance |
| `physical/` | macro inventory, floorplans (generated geometry), OpenROAD script templates (**not executed**) |
| `research/spice/` | ngspice 6T / sense-amp research (**uncalibrated generic model, not silicon data**) |
| `dashboard/` | trace capture, builder, self-contained HTML dashboard |
| `docs/` | ARCHITECTURE, CONTRACT, ECC, MBIST, AUDIT, SF_COMPAT, VERIFICATION, BENCHMARKS, PHYSICAL_POWER, KNOWN_LIMITATIONS |
| `reports/` | JSON / Markdown / CSV / SVG results of every run |

## Results at a glance (all regenerated from `reports/`; none is a silicon result)

| area | result | source |
|---|---|---|
| RTL regression (Verilator 5.020) | **52/52 cases pass**, 5,798,077 self-checks: controller 21/21, DataFabric 9/9, vector scratchpad 7/7, tensor scratchpad 12/12, ECC system 3/3 | `reports/regress_*.json`, `docs/VERIFICATION.md` |
| ECC codec vs independent Python reference | K = 128 / 64 / 32: 0 errors (392,786 / 106,946 / 30,686 checks); 3-bit errors are **not** guaranteed (243 of 300 miscorrected) | `reports/ecc_codec.log`, `docs/ECC.md` |
| MBIST (March C-, measured on fault models) | 100 % cell and cross-word coupling faults, **80.65 %** same-word coupling (exhaustive 4 x 32 instance); no repair | `reports/mbist_coverage.md`, `docs/MBIST.md` |
| Mutation testing | **41 of 41** injected mutants killed (after strengthening two testbench checks) | `reports/mutation*.json` |
| Bounded formal | 7 of 8 configurations reach their requested depth with no counterexample; the `ecc` configuration reached frame 14 of 20 before the time limit | `reports/formal.json` |
| Logic synthesis (Yosys generic gates) | all 14 module configurations synthesize; no PDK / timing / area | `reports/synthesis.md` |
| Benchmarks (4 masters x 4 banks, 16 B lines) | sequential 63.68 B/cycle of 64; random lines 41.29 (ceiling 41.94); single bank 15.99 of 16; scalar 4 B loads 15.97 of 16 | `docs/BENCHMARKS.md` |
| Cycle model vs RTL | 119/119 benchmark rows, 342/342 extra runs and 20/20 tensor runs reproduced exactly | `reports/sramlab_vs_rtl.md` |

## Definition of done - status

| requirement | status |
|---|---|
| four independent banks | done; verified (`docs/VERIFICATION.md`) |
| correct scalar and vector access | done (controller byte-enable path, `sf_vector_scratchpad` V1-V7) |
| arbitration | done; round-robin bound checked, fixed-priority starvation documented |
| byte enables | done; byte-accurate scoreboard |
| DataFabric transactions reach memory and complete | done; behind the real SFB3 NoC with its protocol checker |
| correct responses / completion | done; exactly one in-order response per request |
| no loss or corruption under contention | checked by scoreboards, conservation counters, mutation testing and bounded formal |
| reproducible benchmarks | done; `benchmarks/run_bench.py`, model validated exactly against the RTL |
| **not** done | top-level `sf_memorycore_top` integration module; ASIC readiness; OpenROAD run; silicon data; unbounded formal proofs |

## Provenance and licensing notes

Reused code (`third_party/`) comes from the SilicaFlux repository archives and is byte-identical (`third_party/PROVENANCE.md`, `SHA256SUMS`). Nothing was committed to git; this package was produced as a ZIP as requested.
