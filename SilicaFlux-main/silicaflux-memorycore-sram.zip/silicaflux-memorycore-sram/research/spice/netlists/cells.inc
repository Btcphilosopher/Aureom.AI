* RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA
* netlists/cells.inc : 6T SRAM building blocks used by all experiments.
* Requires models/generic_45nm_illustrative.lib to be .include'd first.
*
* Geometry parameters are drawn widths (m); all devices share gate length l.
*   beta  = wpd / wax   (cell ratio)
*   gamma = wpu / wax   (pull-up ratio)
* dvt_* are threshold shifts in volts, defined as the INCREASE of |Vth| of that
* transistor (positive = weaker device).  They are implemented as a DC voltage
* source in series with the gate:  NMOS: -dvt ; PMOS: +dvt   (see model .lib).
*
* Diffusion area/perimeter use a fixed illustrative diffusion length ldiff.
.param ldiff=100n

* ---- half cell: inverter (in -> out) plus access transistor out<->bl --------
.subckt half in out bl wl vdd vss params: wpd=200n wpu=100n wax=100n l=45n dvt_pd=0 dvt_pu=0 dvt_ax=0
Vspd gpd in dc={-dvt_pd}
Vspu gpu in dc={dvt_pu}
Vsax gax wl dc={-dvt_ax}
Mpd out gpd vss vss nch w={wpd} l={l} ad={wpd*ldiff} as={wpd*ldiff} pd={2*(wpd+ldiff)} ps={2*(wpd+ldiff)}
Mpu out gpu vdd vdd pch w={wpu} l={l} ad={wpu*ldiff} as={wpu*ldiff} pd={2*(wpu+ldiff)} ps={2*(wpu+ldiff)}
Max bl gax out vss nch w={wax} l={l} ad={wax*ldiff} as={wax*ldiff} pd={2*(wax+ldiff)} ps={2*(wax+ldiff)}
.ends half

* ---- full 6T cell: two cross-coupled halves ---------------------------------
* half 1: input qb, output q, access to bl ; half 2: input q, output qb, access to blb
.subckt cell6t q qb bl blb wl vdd vss params: wpd=200n wpu=100n wax=100n l=45n dvt_pd1=0 dvt_pd2=0 dvt_pu1=0 dvt_pu2=0 dvt_ax1=0 dvt_ax2=0
X1 qb q  bl  wl vdd vss half params: wpd={wpd} wpu={wpu} wax={wax} l={l} dvt_pd={dvt_pd1} dvt_pu={dvt_pu1} dvt_ax={dvt_ax1}
X2 q  qb blb wl vdd vss half params: wpd={wpd} wpu={wpu} wax={wax} l={l} dvt_pd={dvt_pd2} dvt_pu={dvt_pu2} dvt_ax={dvt_ax2}
.ends cell6t
