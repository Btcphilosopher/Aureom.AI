* {{LABEL}}
* senseamp.cir.tpl : latch-type (cross-coupled) sense amplifier, bank of
* independent instances, each with its own input differential and injected
* Vth mismatch.  Rendered by scripts/exp_e_senseamp.py ; job: {{NAME}}
*
*  blt/blc : bitline inputs, connected to latch nodes so/sob through PMOS pass
*            gates (on while SAE = 0, i.e. sampling) ; cross-coupled NMOS pair
*            MN1/MN2 + PMOS pair MP1/MP2 ; NMOS footer MNE enabled by SAE.
*  csa     : illustrative lumped capacitance on each latch node (NOT extracted).
*  dvt_*   : increase of |Vth| of that device (series gate source, see cells.inc).
.include {{LIB}}
.include {{CELLS}}
.options gmin=1e-12 reltol=1e-4 abstol=1e-13 vntol=1e-7 itl4=100
.temp 27
.subckt sa_latch blt blc so sob sae vdd params: wn=300n wp=300n wt=600n wi=200n l=45n csa=2f dvt_n1=0 dvt_n2=0 dvt_p1=0 dvt_p2=0
Vgn1 gn1 sob dc={-dvt_n1}
Vgn2 gn2 so  dc={-dvt_n2}
Vgp1 gp1 sob dc={dvt_p1}
Vgp2 gp2 so  dc={dvt_p2}
MN1 so  gn1 tail 0 nch w={wn} l={l} ad={wn*ldiff} as={wn*ldiff} pd={2*(wn+ldiff)} ps={2*(wn+ldiff)}
MN2 sob gn2 tail 0 nch w={wn} l={l} ad={wn*ldiff} as={wn*ldiff} pd={2*(wn+ldiff)} ps={2*(wn+ldiff)}
MP1 so  gp1 vdd vdd pch w={wp} l={l} ad={wp*ldiff} as={wp*ldiff} pd={2*(wp+ldiff)} ps={2*(wp+ldiff)}
MP2 sob gp2 vdd vdd pch w={wp} l={l} ad={wp*ldiff} as={wp*ldiff} pd={2*(wp+ldiff)} ps={2*(wp+ldiff)}
MNE tail sae 0 0 nch w={wt} l={l} ad={wt*ldiff} as={wt*ldiff} pd={2*(wt+ldiff)} ps={2*(wt+ldiff)}
MI1 so  sae blt vdd pch w={wi} l={l} ad={wi*ldiff} as={wi*ldiff} pd={2*(wi+ldiff)} ps={2*(wi+ldiff)}
MI2 sob sae blc vdd pch w={wi} l={l} ad={wi*ldiff} as={wi*ldiff} pd={2*(wi+ldiff)} ps={2*(wi+ldiff)}
C1 so  0 {csa}
C2 sob 0 {csa}
.ends sa_latch
Vdd vdd 0 {{VDD}}
Vsae sae 0 PULSE(0 {{VDD}} {{TSAE}} {{TR}} {{TR}} 1 2)
{{INSTANCES}}
.tran {{TSTEP}} {{TSTOP}} 0 {{TMAX}}
.control
set wr_singlescale
set wr_vecnames
set numdgt=6
run
wrdata {{OUT}} {{PROBES}}
.endc
.end
