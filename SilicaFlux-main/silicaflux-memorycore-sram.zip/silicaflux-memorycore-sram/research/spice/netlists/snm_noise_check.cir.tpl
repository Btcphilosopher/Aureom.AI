* {{LABEL}}
* snm_noise_check.cir.tpl : INDEPENDENT cross-check of the butterfly-square SNM.
* Full 6T cell (no loop breaking) with a static-noise voltage Vn injected in
* series with both inverter inputs, polarity chosen to flip the stored state:
*   inverter 1 input = QB + Vn ,  inverter 2 input = Q - Vn   (Seevinck definition).
* Vn is swept in small steps from 0 with the previous DC solution as the starting
* point (state continuation); the SNM of the stored state is the Vn at which the
* stored state ceases to exist (Q jumps to the other state).  Negative Vn sweeps
* flip the opposite state.  Rendered by scripts/exp_b_snm.py ; job: {{NAME}}
.include {{LIB}}
.include {{CELLS}}
.options gmin=1e-12 reltol=1e-6 abstol=1e-14 vntol=1e-8 itl1=400
.temp 27
Vdd  vdd 0 {{VDD}}
Vbl  bl  0 {{VDD}}
Vblb blb 0 {{VDD}}
Vwl  wl  0 {{VWL}}
Vn   nn  0 0
Bn1  a1  qb V=V(nn)
Bn2  a2  q  V=-V(nn)
Mpd1 q  a1 0   0   nch w={{WPD}} l={{L}} ad={ {{WPD}} * ldiff } as={ {{WPD}} * ldiff } pd={ 2 * ({{WPD}} + ldiff) } ps={ 2 * ({{WPD}} + ldiff) }
Mpu1 q  a1 vdd vdd pch w={{WPU}} l={{L}} ad={ {{WPU}} * ldiff } as={ {{WPU}} * ldiff } pd={ 2 * ({{WPU}} + ldiff) } ps={ 2 * ({{WPU}} + ldiff) }
Max1 bl wl q   0   nch w={{WAX}} l={{L}} ad={ {{WAX}} * ldiff } as={ {{WAX}} * ldiff } pd={ 2 * ({{WAX}} + ldiff) } ps={ 2 * ({{WAX}} + ldiff) }
Mpd2 qb a2 0   0   nch w={{WPD}} l={{L}} ad={ {{WPD}} * ldiff } as={ {{WPD}} * ldiff } pd={ 2 * ({{WPD}} + ldiff) } ps={ 2 * ({{WPD}} + ldiff) }
Mpu2 qb a2 vdd vdd pch w={{WPU}} l={{L}} ad={ {{WPU}} * ldiff } as={ {{WPU}} * ldiff } pd={ 2 * ({{WPU}} + ldiff) } ps={ 2 * ({{WPU}} + ldiff) }
Max2 blb wl qb 0   nch w={{WAX}} l={{L}} ad={ {{WAX}} * ldiff } as={ {{WAX}} * ldiff } pd={ 2 * ({{WAX}} + ldiff) } ps={ 2 * ({{WAX}} + ldiff) }
.nodeset v(q)={{VQ0}} v(qb)={{VQB0}}
.dc Vn 0 {{VNEND}} {{VNSTEP}}
.control
set wr_singlescale
set wr_vecnames
set numdgt=7
run
wrdata {{OUT}} v(q) v(qb)
.endc
.end
