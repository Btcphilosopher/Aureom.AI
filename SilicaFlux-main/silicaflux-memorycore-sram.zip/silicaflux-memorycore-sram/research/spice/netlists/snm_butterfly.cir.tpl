* {{LABEL}}
* snm_butterfly.cir.tpl : butterfly curves of a 6T cell, loop broken into two
* half cells (inverter + access transistor) driven by one swept input source.
* Rendered by scripts/sramlib.py ; experiment/job name: {{NAME}}
* Half 1 -> output Q (access to BL), half 2 -> output QB (access to BLB).
* Curve A = (x=in, y=out1) ; curve B = (x=out2, y=in)  (see scripts/snm.py).
.include {{LIB}}
.include {{CELLS}}
.options gmin=1e-12 reltol=1e-5 abstol=1e-14 vntol=1e-8 itl1=400
.temp 27
Vdd vdd 0 {{VDD}}
Vbl  bl  0 {{VBL}}
Vblb blb 0 {{VBLB}}
Vwl  wl  0 {{VWL}}
Vin  in  0 0
{{HALVES}}
{{DC}}
.control
set wr_singlescale
set wr_vecnames
set numdgt=7
run
wrdata {{OUT}} {{PROBES}}
.endc
.end
