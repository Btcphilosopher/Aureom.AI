* {{LABEL}}
* cell6t_op.cir.tpl : DC operating point of a full 6T cell in HOLD (WL=0),
* bitlines at Vdd.  Initial state selected with .nodeset.  Rendered by
* scripts/exp_a_bitcell.py ; job: {{NAME}}
.include {{LIB}}
.include {{CELLS}}
.options gmin=1e-14 reltol=1e-6 abstol=1e-15 vntol=1e-9
.temp 27
Vdd  vdd 0 {{VDD}}
Vbl  bl  0 {{VDD}}
Vblb blb 0 {{VDD}}
Vwl  wl  0 0
XCELL q qb bl blb wl vdd 0 cell6t params: {{CELLPARAMS}}
.nodeset v(q)={{VQ}} v(qb)={{VQB}}
.control
set wr_singlescale
set wr_vecnames
set numdgt=8
op
let vq = v(q)
let vqb = v(qb)
let icore = -i(vdd)
let ibl = -i(vbl)
let iblb = -i(vblb)
wrdata {{OUT}} vq vqb icore ibl iblb
.endc
.end
