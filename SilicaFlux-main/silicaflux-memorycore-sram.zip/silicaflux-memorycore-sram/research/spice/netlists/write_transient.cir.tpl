* {{LABEL}}
* write_transient.cir.tpl : 6T cell storing '1' on Q is written to '0'.
* BL is driven low through a driver resistance (illustrative), BLB held at Vdd,
* lumped bitline capacitance on both lines, WL pulse of amplitude {{VWLH}}.
* Rendered by scripts/exp_d_write.py ; job: {{NAME}}
.include {{LIB}}
.include {{CELLS}}
.options gmin=1e-12 reltol=1e-4 abstol=1e-13 vntol=1e-7 itl4=100
.temp 27
Vdd vdd 0 {{VDD}}
XCELL q qb bl blb wl vdd 0 cell6t params: {{CELLPARAMS}}
Vwd  wd  0 PULSE({{VDD}} 0 {{TWR}} {{TR}} {{TR}} 1 2)
Rwd  wd  bl  {{RDRV}}
Vwdb wdb 0 {{VDD}}
Rwdb wdb blb {{RDRV}}
Cbl  bl  0 {{CBL}}
Cblb blb 0 {{CBL}}
Vwl wl 0 PULSE(0 {{VWLH}} {{TWL}} {{TR}} {{TR}} {{WLW}} 1)
.nodeset v(q)={{VDD}} v(qb)=0 v(bl)={{VDD}} v(blb)={{VDD}}
.tran {{TSTEP}} {{TSTOP}} 0 {{TMAX}}
.control
set wr_singlescale
set wr_vecnames
set numdgt=7
run
wrdata {{OUT}} v(q) v(qb) v(bl) v(blb) v(wl)
.endc
.end
