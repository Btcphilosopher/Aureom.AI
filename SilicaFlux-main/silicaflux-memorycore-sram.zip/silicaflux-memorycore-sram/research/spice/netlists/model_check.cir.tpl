* {{LABEL}}
* model_check.cir.tpl : sanity / characterisation of the GENERIC ILLUSTRATIVE model.
* NMOS and PMOS, W=1um L=45nm, Id-Vgs at |Vds| = {{VDD}} and 0.05 V, plus the
* 'series gate source == Vth shift' equivalence check used for Monte Carlo.
.include {{LIB}}
.include {{CELLS}}
.options gmin=1e-14 reltol=1e-6 abstol=1e-15 vntol=1e-9
.temp 27
{{SHIFTED_MODELS}}
Vdd vdd 0 {{VDD}}
Vg  g   0 0
Bgp gp  0 V={{VDD}}-V(g)
* NMOS, Vds = Vdd (saturation-like) and 0.05 V (linear)
Vd1 d1 0 {{VDD}}
Mn1 d1 g 0 0 nch w=1u l=45n
Vd2 d2 0 0.05
Mn2 d2 g 0 0 nch w=1u l=45n
* PMOS, |Vds| = Vdd ; source at vdd, drain through 0V probe to ground
Vp1 dp 0 0
Mp1 dp gp vdd vdd pch w=1u l=45n
* equivalence: NMOS with Vth(+dvt) as a model copy vs gate-series source of -dvt
Vd3 d3 0 {{VDD}}
Mn3 d3 g 0 0 nch_shift w=1u l=45n
Vd4 d4 0 {{VDD}}
Vs4 g4 g dc=-{{DVT}}
Mn4 d4 g4 0 0 nch w=1u l=45n
* PMOS with |Vth|(+dvt): model copy vs gate-series source of +dvt
Vp5 d5 0 0
Mp5 d5 gp vdd vdd pch_shift w=1u l=45n
Vp6 d6 0 0
Vs6 g6 gp dc={{DVT}}
Mp6 d6 g6 vdd vdd pch w=1u l=45n
.dc Vg 0 {{VDD}} 0.01
.control
set wr_singlescale
set wr_vecnames
set numdgt=8
run
let idn1 = -i(vd1)
let idn2 = -i(vd2)
let idp1 = i(vp1)
let idn3 = -i(vd3)
let idn4 = -i(vd4)
let idp5 = i(vp5)
let idp6 = i(vp6)
wrdata {{OUT}} idn1 idn2 idp1 idn3 idn4 idp5 idp6
.endc
.end
