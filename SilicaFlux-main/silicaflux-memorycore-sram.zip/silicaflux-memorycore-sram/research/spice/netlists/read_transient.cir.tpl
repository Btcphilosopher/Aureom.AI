* {{LABEL}}
* read_transient.cir.tpl : 6T cell storing '0' on Q (QB = '1'), precharged
* bitlines with lumped capacitance, WL pulse.  Rendered by scripts/exp_c_read.py
* (and exp_f_vdd.py).  job: {{NAME}}
* Bitline mode {{BLMODE}}: 'cap' = precharge PMOS + lumped Cbl, released before WL;
*                          'clamp' = ideal sources hold BL/BLB at Vdd (worst-case disturb).
.include {{LIB}}
.include {{CELLS}}
.options gmin=1e-12 reltol=1e-4 abstol=1e-13 vntol=1e-7 itl4=100
.temp 27
Vdd vdd 0 {{VDD}}
XCELL q qb blc blbc wl vdd 0 cell6t params: {{CELLPARAMS}}
* zero-volt current probes between bitline and cell port (positive = into cell)
Vrd  bl  blc  0
Vrdb blb blbc 0
{{BLBLOCK}}
Vwl wl 0 PULSE(0 {{VDD}} {{TWL}} {{TR}} {{TR}} {{WLW}} 1)
.nodeset v(q)=0 v(qb)={{VDD}} v(bl)={{VDD}} v(blb)={{VDD}}
.tran {{TSTEP}} {{TSTOP}} 0 {{TMAX}}
.control
set wr_singlescale
set wr_vecnames
set numdgt=7
run
wrdata {{OUT}} v(q) v(qb) v(bl) v(blb) v(wl) i(Vrd) i(Vrdb)
.endc
.end
