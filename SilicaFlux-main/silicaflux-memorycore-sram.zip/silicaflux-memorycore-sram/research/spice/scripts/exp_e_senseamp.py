"""
exp_e_senseamp.py - (e) latch-type sense amplifier: minimum bitline differential
that resolves correctly, and the effect of an injected input-referred offset
(Vth mismatch between the two input NMOS of the cross-coupled pair).

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Netlist template: netlists/senseamp.cir.tpl (bank of independent SA instances,
one per (offset, differential) pair, all in one transient run).
Convention: dV = V(blt) - V(blc) at the moment SAE rises; correct result means
V(so) > V(sob) for dV > 0 and the reverse for dV < 0.  Offset: dvt_n1 = +d/2,
dvt_n2 = -d/2 (d = |Vth(MN1)| - |Vth(MN2)|).  "Resolved" = |V(so)-V(sob)| >= 0.8 Vdd.
Outputs: results/exp_e_senseamp_offset.csv, results/exp_e_senseamp_tres.csv,
         results/exp_e_senseamp.svg
"""
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "exp_e_senseamp"
VDD = 1.0
TSAE = 100e-12
TR = 20e-12
TSTOP = 900e-12
DV_GRID = np.round(np.arange(-99.0, 99.01, 2.0), 3)           # mV (odd values: no dV = 0 point)
OFFSETS_N = [-60.0, -40.0, -20.0, 0.0, 20.0, 40.0, 60.0]     # mV, NMOS pair mismatch d
OFFSETS_P = [-40.0, 40.0]                                     # mV, PMOS pair mismatch (extra rows)
WINDOWS = [40e-12, 60e-12, 100e-12]                           # decision windows after SAE 50%
THRESH = 0.8 * VDD


def simulate(tag, kind, off_mV, record=False):
    inst, probes = [], []
    for k, dv in enumerate(DV_GRID):
        blt = VDD if dv >= 0 else VDD - abs(dv) * 1e-3
        blc = VDD if dv < 0 else VDD - abs(dv) * 1e-3
        d = off_mV * 1e-3
        par = (f"dvt_n1={S.fmt(d/2)} dvt_n2={S.fmt(-d/2)}" if kind == "n" else
               f"dvt_p1={S.fmt(d/2)} dvt_p2={S.fmt(-d/2)}")
        inst.append(f"Vt{k} blt{k} 0 {S.fmt(blt)}\nVc{k} blc{k} 0 {S.fmt(blc)}\n"
                    f"XSA{k} blt{k} blc{k} so{k} sob{k} sae vdd sa_latch params: {par}")
        probes += [f"v(so{k})", f"v(sob{k})"]
    text = S.render("senseamp.cir.tpl", NAME=tag, VDD=S.fmt(VDD), TSAE=S.fmt(TSAE), TR=S.fmt(TR), TSTEP="2p",
                    TSTOP=S.fmt(TSTOP), TMAX="2p", INSTANCES="\n".join(inst), PROBES=" ".join(probes),
                    OUT=str((S.WORK / f"{tag}.dat").relative_to(S.ROOT)))
    _, d = S.run_ngspice(tag, text, exp=EXP, record=record)
    t = d[:, 0]
    so, sob = d[:, 1::2], d[:, 2::2]
    return t, so - sob


def analyse(t, diff):
    """Per-dV: resolved/correct at each window, resolution time, final decision."""
    t50 = TSAE + TR / 2
    out = {}
    sgn = np.sign(DV_GRID)
    for w in WINDOWS:
        v = np.array([np.interp(t50 + w, t, diff[:, k]) for k in range(diff.shape[1])])
        out[w] = (np.abs(v) >= THRESH) & (np.sign(v) == sgn)
    tres = np.full(len(DV_GRID), np.nan)
    for k in range(diff.shape[1]):
        idx = np.nonzero(np.abs(diff[:, k]) >= THRESH)[0]
        if idx.size and t[idx[0]] >= t50:
            tres[k] = (t[idx[0]] - t50) * 1e12
        elif idx.size:
            tres[k] = np.nan
    final = np.sign(diff[-1])
    return out, tres, final


def min_dv(correct):
    """Smallest |dV| (mV) such that every grid point with |dV'| >= it is correct; nan if none."""
    absdv = np.abs(DV_GRID)
    for m in sorted(set(absdv)):
        if np.all(correct[absdv >= m]):
            return float(m)
    return float("nan")


def trip_point(final):
    """dV (mV) where the final decision flips from '-' to '+' (midpoint of the bracketing grid points)."""
    idx = np.nonzero((final[:-1] < 0) & (final[1:] > 0))[0]
    if not idx.size:
        return float("nan")
    k = idx[len(idx) // 2]
    return float(0.5 * (DV_GRID[k] + DV_GRID[k + 1]))


def run():
    cases = [("n", o) for o in OFFSETS_N] + [("p", o) for o in OFFSETS_P]

    def work(i):
        kind, o = cases[i]
        t, diff = simulate(f"e_sa{i}", kind, o, record=(i == 0))
        return t, diff, analyse(t, diff)

    res = S.run_parallel(work, range(len(cases)))
    rows, t_rows = [], []
    for (kind, o), (t, diff, (corr, tres, final)) in zip(cases, res):
        row = [kind, o, trip_point(final)] + [min_dv(corr[w]) for w in WINDOWS]
        rows.append(row)
    S.write_csv(S.RESULTS / "exp_e_senseamp_offset.csv",
                ["mismatch_pair", "injected_offset_d_mV", "trip_point_dV_mV(+-1)"] +
                [f"min_dV_correct_{int(w*1e12)}ps_mV(+-2)" for w in WINDOWS], rows)
    i0 = cases.index(("n", 0.0))
    t0, diff0, (corr0, tres0, final0) = res[i0]
    S.write_csv(S.RESULTS / "exp_e_senseamp_tres.csv",
                ["dV_mV", "t_resolve_ps(0.8Vdd,from_SAE50%)"] + [f"correct_{int(w*1e12)}ps" for w in WINDOWS] + ["final_decision"],
                [[DV_GRID[k], tres0[k], int(corr0[WINDOWS[0]][k]), int(corr0[WINDOWS[1]][k]), int(corr0[WINDOWS[2]][k]),
                  int(final0[k])] for k in range(len(DV_GRID))])
    # figure
    fig = Figure("(e) Latch sense amplifier: resolution vs input differential and Vth offset", 2, 2, 440, 300,
                 f"Vdd = {VDD} V; NMOS input pair 300 nm / 45 nm; SAE rises at {TSAE*1e12:.0f} ps; resolved = |V(so)-V(sob)| >= 0.8 Vdd")
    ax = fig.axes(0, 0, "input differential dV = V(blt) - V(blc) (mV)", "time to resolve (ps)", "Resolution time vs dV (offset = 0)", legend=None)
    m = np.isfinite(tres0)
    ax.line(DV_GRID[m], tres0[m], None, 0, marker=True)
    ax = fig.axes(0, 1, "time since SAE 50% (ps)", "V(so) - V(sob) (V)", "Latch outputs for a few dV (offset = 0)", legend="tl")
    t50 = TSAE + TR / 2
    for j, dv in enumerate((-20.0, -6.0, -2.0, 2.0, 6.0, 20.0)):
        k = int(np.argmin(np.abs(DV_GRID - dv)))
        ax.line((t0 - t50) * 1e12, diff0[:, k], f"dV = {DV_GRID[k]:+.0f} mV", j)
    ax.hline(0.8, None, 5, "3 3")
    ax.hline(-0.8, None, 5, "3 3")
    ax = fig.axes(1, 0, "injected NMOS-pair offset d (mV)", "dV (mV)", "Trip point and guaranteed-correct input vs offset", legend="tl")
    rn = [r for r in rows if r[0] == "n"]
    ax.line([r[1] for r in rn], [r[2] for r in rn], "trip point dV where decision flips", 0, marker=True)
    ax.line([r[1] for r in rn], [r[4] for r in rn], f"min |dV|, both polarities correct, {int(WINDOWS[1]*1e12)} ps window", 1, "6 3", marker=True)
    ax = fig.axes(1, 1, "decision window after SAE (ps)", "min |dV| resolving correctly (mV)", "Guaranteed-correct input vs decision window", legend="tr")
    for j, o in enumerate((0.0, 20.0, 40.0, 60.0)):
        r = next(r for r in rows if r[0] == "n" and r[1] == o)
        ax.line([w * 1e12 for w in WINDOWS], r[3:6], f"offset d = {o:g} mV", j, marker=True)
    fig.save(S.RESULTS / "exp_e_senseamp.svg")
    # derived: time for the exp_c bitline differential (Cbl=50 fF) to reach the guaranteed-correct input
    derived = []
    wf = S.RESULTS / "exp_c_waveforms.csv"
    if wf.exists():
        rd = S.read_csv(wf)
        tt = np.array([float(r["t_ns"]) for r in rd]) * 1e3          # ps
        dvbl = np.array([float(r["BLB_V"]) - float(r["BL_V"]) for r in rd]) * 1e3   # mV
        wlv = np.array([float(r["WL_V"]) for r in rd])
        t50wl = S.crossing_time(tt, wlv, 0.5, True)
        for r in rn:
            need = r[4]
            if np.isfinite(need) and np.interp(t50wl, tt, dvbl) >= need:
                derived.append([r[1], need, 0.0])      # differential already >= need when WL reaches 50%
                continue
            tc = S.crossing_time(tt, dvbl, need, True) if np.isfinite(need) and need > 0 else float("nan")
            derived.append([r[1], need, max(tc - t50wl, 0.0) if np.isfinite(tc) else float("nan")])
    md = ["| mismatch pair | injected offset d (mV) | trip point dV (mV, +-1) | " + " | ".join(f"min dV correct, {int(w*1e12)} ps window (mV, +-2)" for w in WINDOWS) + " |",
          "|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {'NMOS' if r[0]=='n' else 'PMOS'} | {r[1]:+.0f} | {r[2]:+.0f} | {r[3]:.0f} | {r[4]:.0f} | {r[5]:.0f} |".replace("nan", "not resolved"))
    md += ["", "Resolution time (offset = 0, NMOS pair): see results/exp_e_senseamp_tres.csv; "
           f"e.g. dV = 20 mV -> {tres0[int(np.argmin(np.abs(DV_GRID-20)))]:.0f} ps, dV = 6 mV -> {tres0[int(np.argmin(np.abs(DV_GRID-6)))]:.0f} ps, "
           f"dV = 2 mV -> {tres0[int(np.argmin(np.abs(DV_GRID-2)))]:.0f} ps (from SAE 50% to |V(so)-V(sob)| = 0.8 Vdd)."]
    if derived:
        md += ["", "Derived (not a separate simulation): time after WL 50% for the exp_c bitline differential (default cell, Cbl = 50 fF) to reach the guaranteed-correct dV (60 ps window) of each NMOS offset:", "",
               "| offset d (mV) | needed dV (mV) | time for BL differential to reach it (ps) |", "|---|---|---|"]
        for d_ in derived:
            md.append(f"| {d_[0]:+.0f} | {d_[1]:.0f} | {d_[2]:.0f} |".replace("nan", "-"))
    r0 = next(r for r in rows if r[0] == "n" and r[1] == 0.0)
    slope = np.polyfit([r[1] for r in rn if np.isfinite(r[2])], [r[2] for r in rn if np.isfinite(r[2])], 1)[0]
    head = dict(min_dv_zero_offset_mV_by_window_ps={str(int(w * 1e12)): v for w, v in zip(WINDOWS, r0[3:6])},
                trip_point_zero_offset_mV=r0[2], trip_slope_mV_per_mV_offset=float(slope),
                min_dv_60ps_window_by_offset_mV={f"{r[1]:+.0f}": r[4] for r in rn},
                trip_by_offset={f"{r[1]:+.0f}": r[2] for r in rn})
    S.update_summary_json("exp_e_senseamp", head)
    return dict(summary=head, md="\n".join(md))


if __name__ == "__main__":
    print(run()["md"])
