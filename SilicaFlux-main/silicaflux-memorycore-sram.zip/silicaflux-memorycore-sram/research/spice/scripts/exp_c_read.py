"""
exp_c_read.py - (c) read transient: bitline differential development, read
current and READ DISTURB (bump on the '0' storage node, cell-flip flag).

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Netlist template: netlists/read_transient.cir.tpl.
Cases: (i) default cell, bitline capacitance sweep; (ii) beta sweep with
Cbl = 50 fF ("cap" mode, precharge released before WL) and with ideal-clamped
bitlines ("clamp" mode, worst-case static-like disturb).
Outputs: results/exp_c_read_cbl.csv, results/exp_c_read_beta.csv,
         results/exp_c_waveforms.csv, results/exp_c_read.svg
"""
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "exp_c_read"
VDD = 1.0
TPRE = 100e-12        # precharge released
TWL = 200e-12         # WL starts rising (50% at TWL + TR/2)
TR = 20e-12
WLW = 1.5e-9          # WL high time
TSTOP = TWL + TR + WLW + 600e-12
DEFAULT = S.Cell()
CBLS = [10e-15, 25e-15, 50e-15, 100e-15, 200e-15]
BETAS = [0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0]
CBL_DEF = 50e-15
DV_TARGETS = (50e-3, 100e-3)


def bl_block(mode, cbl, vdd=VDD):
    if mode == "clamp":
        return "Vbl  bl  0 {v}\nVblb blb 0 {v}".format(v=S.fmt(vdd))
    return (f"Cbl  bl  0 {S.fmt(cbl)}\nCblb blb 0 {S.fmt(cbl)}\n"
            f"Mpc1 bl  pre vdd vdd pch w=1u l=45n\nMpc2 blb pre vdd vdd pch w=1u l=45n\n"
            f"Vpre pre 0 PULSE(0 {S.fmt(vdd)} {S.fmt(TPRE)} {S.fmt(TR)} {S.fmt(TR)} 1 2)")


def simulate(name, cell, mode="cap", cbl=CBL_DEF, vdd=VDD, twl=TWL, wlw=WLW, record=False, tail=600e-12):
    tstop = twl + TR + wlw + tail
    text = S.render("read_transient.cir.tpl", NAME=name, BLMODE=mode, VDD=S.fmt(vdd), CELLPARAMS=cell.params(),
                    BLBLOCK=bl_block(mode, cbl, vdd), TWL=S.fmt(twl), TR=S.fmt(TR), WLW=S.fmt(wlw),
                    TSTEP="2p", TSTOP=S.fmt(tstop), TMAX="2p", OUT=str((S.WORK / f"{name}.dat").relative_to(S.ROOT)))
    _, d = S.run_ngspice(name, text, exp=EXP, record=record)
    return d, twl


def metrics(d, twl, vdd=VDD, wlw=WLW):
    t, q, qb, bl, blb, wl, ird, irdb = (d[:, k] for k in range(8))
    t50 = twl + TR / 2
    on = (t >= twl) & (t <= twl + TR + wlw)
    dv = blb - bl
    m = dict(vq_peak=float(q[on].max()), vq_end=float(q[-1]), vqb_end=float(qb[-1]))
    # Outcome classification at the instant just before WL falls (20 ps earlier):
    #  |Q-QB| < 0.1 Vdd  -> the cell sits in a symmetric analog state (statically monostable under read):
    #                       STATE LOST; the state it relaxes to after WL falls is decided by numerical noise, so the
    #                       final Q/QB comparison is NOT meaningful for these cases.
    #  Q > QB             -> FLIPPED while WL was on.   Q < QB -> retained (unless Q > QB again at the end).
    tf = twl + TR + wlw - 20e-12
    qf, qbf = float(np.interp(tf, t, q)), float(np.interp(tf, t, qb))
    if abs(qf - qbf) < 0.1 * vdd:
        m["status"] = "STATE LOST"
    elif qf > qbf:
        m["status"] = "FLIPPED"
    elif q[-1] > qb[-1]:
        m["status"] = "FLIPPED after WL"
    else:
        m["status"] = "retained"
    m["flipped"] = int(m["status"] != "retained")
    m["q_at_wl_fall"], m["qb_at_wl_fall"] = qf, qbf
    m["i_read_peak_uA"] = float(ird[on].max() * 1e6)
    for tt in (100e-12, 200e-12, 500e-12):
        m[f"dv_{int(tt*1e12)}ps_mV"] = float(np.interp(t50 + tt, t, dv) * 1e3)
    for tgt in DV_TARGETS:
        tc = S.crossing_time(t, dv, tgt, True, t_min=t50)
        m[f"t_dv{int(tgt*1e3)}mV_ps"] = (tc - t50) * 1e12 if np.isfinite(tc) else float("nan")
    m["dv_max_mV"] = float(dv[on].max() * 1e3)
    return m


def run():
    jobs = [("cbl", i, c) for i, c in enumerate(CBLS)]
    jobs += [("beta_cap", i, b) for i, b in enumerate(BETAS)] + [("beta_clamp", i, b) for i, b in enumerate(BETAS)]

    def work(job):
        kind, i, val = job
        if kind == "cbl":
            d, tw = simulate(f"c_cbl{i}", DEFAULT, "cap", val, record=(i == 2))
        elif kind == "beta_cap":
            d, tw = simulate(f"c_bcap{i}", DEFAULT.with_(beta=val), "cap", CBL_DEF)
        else:
            d, tw = simulate(f"c_bclamp{i}", DEFAULT.with_(beta=val), "clamp", CBL_DEF)
        return d, metrics(d, tw)

    res = S.run_parallel(work, jobs)
    R = {(j[0], j[1]): r for j, r in zip(jobs, res)}
    # ---- csv: Cbl sweep
    rows = []
    for i, c in enumerate(CBLS):
        m = R[("cbl", i)][1]
        rows.append([c * 1e15, m["i_read_peak_uA"], m["dv_100ps_mV"], m["dv_200ps_mV"], m["dv_500ps_mV"],
                     m["t_dv50mV_ps"], m["t_dv100mV_ps"], m["vq_peak"], m["status"]])
    S.write_csv(S.RESULTS / "exp_c_read_cbl.csv",
                ["Cbl_fF", "I_read_peak_uA", "dV_BL_at_100ps_mV", "dV_BL_at_200ps_mV", "dV_BL_at_500ps_mV",
                 "t_to_50mV_ps", "t_to_100mV_ps", "Vq_peak_V", "outcome"], rows)
    # ---- csv: beta sweep
    brow = []
    # static read-trip level of the '0' node from the butterfly (metastable Q) for context
    import snm as _snm
    stat = {}
    for b in BETAS:
        v, a, bb = S.vtc_sweep(f"c_stat_{b}", VDD, DEFAULT.with_(beta=b), "read", EXP)
        r = _snm.butterfly_lobes(v, a, bb)
        stat[b] = (r["snm"] * 1e3, r["qm"])
    for i, b in enumerate(BETAS):
        mc, mk = R[("beta_cap", i)][1], R[("beta_clamp", i)][1]
        brow.append([b, stat[b][0], stat[b][1], mc["vq_peak"], mc["flipped"], mc["i_read_peak_uA"], mc["dv_200ps_mV"],
                     mk["vq_peak"], mk["flipped"], mk["i_read_peak_uA"], mc["status"], mk["status"], mk["q_at_wl_fall"], mk["qb_at_wl_fall"]])
    S.write_csv(S.RESULTS / "exp_c_read_beta.csv",
                ["beta", "static_read_SNM_mV", "static_metastable_Q_V", "cap50fF_Vq_peak_V", "cap50fF_not_retained",
                 "cap50fF_I_read_peak_uA", "cap50fF_dV_BL_200ps_mV", "clamp_Vq_peak_V", "clamp_not_retained",
                 "clamp_I_read_peak_uA", "cap50fF_outcome", "clamp_outcome", "clamp_Q_at_WL_fall_V", "clamp_QB_at_WL_fall_V"], brow)
    # ---- waveforms of the default case (Cbl sweep) for the figure / csv
    wf = []
    d50 = R[("cbl", CBLS.index(CBL_DEF))][0]
    for k in range(0, len(d50), 1):
        if d50[k, 0] > 0.6e-9 and k % 5:
            continue
        wf.append([d50[k, 0] * 1e9, d50[k, 1], d50[k, 2], d50[k, 3], d50[k, 4], d50[k, 5], d50[k, 6] * 1e6])
    S.write_csv(S.RESULTS / "exp_c_waveforms.csv", ["t_ns", "Q_V", "QB_V", "BL_V", "BLB_V", "WL_V", "I_BL_into_cell_uA"], wf)
    # ---- figure
    fig = Figure("(c) Read transient: bitline differential, read current, read disturb", 2, 2, 440, 300,
                 f"Vdd = {VDD} V; default cell (beta 2, gamma 1); WL 50% at t = {(TWL+TR/2)*1e9:.2f} ns; stored Q = 0")
    ax = fig.axes(0, 0, "time (ns)", "bitline differential BLB - BL (mV)", "dV_BL vs time for several Cbl (zoom)", (0.15, 0.85), (0, 400), legend="br")
    for i, c in enumerate(CBLS):
        d = R[("cbl", i)][0]
        ax.line(d[:, 0] * 1e9, (d[:, 4] - d[:, 3]) * 1e3, f"Cbl = {c*1e15:g} fF", i)
    ax.hline(100, "100 mV", 5, "3 3")
    ax = fig.axes(0, 1, "time (ns)", "voltage (V)", "Cbl = 50 fF: storage nodes and WL", legend="tr")
    ax.line(d50[:, 0] * 1e9, d50[:, 5], "WL", 3, "3 3")
    ax.line(d50[:, 0] * 1e9, d50[:, 1], "Q ('0' node)", 0)
    ax.line(d50[:, 0] * 1e9, d50[:, 2], "QB ('1' node)", 1)
    ax = fig.axes(1, 0, "time (ns)", "read current into cell (uA)", "I(BL -> cell), Cbl = 50 fF", legend="tr")
    ax.line(d50[:, 0] * 1e9, d50[:, 6] * 1e6, "I_BL", 0)
    ax = fig.axes(1, 1, "beta = W_PD / W_AX", "peak V(Q) during read (V)", "Read disturb vs beta (static saddle level for reference)", legend="tr")
    ax.line(BETAS, [r[3] for r in brow], "peak Q, Cbl = 50 fF", 0, marker=True)
    ax.line(BETAS, [r[7] for r in brow], "peak Q, BL clamped", 1, "6 3", marker=True)
    ax.line([b for b in BETAS if np.isfinite(stat[b][1]) and stat[b][0] > 0], [stat[b][1] for b in BETAS if np.isfinite(stat[b][1]) and stat[b][0] > 0],
            "static saddle Q level (SNM>0)", 4, "2 3", marker=True)
    fig.save(S.RESULTS / "exp_c_read.svg")
    # ---- markdown
    md = ["Bitline-capacitance sweep (default cell, beta = 2):", "",
          "| Cbl (fF) | peak read current (uA) | dV_BL @100 ps (mV) | @200 ps | @500 ps | time to 50 mV (ps) | time to 100 mV (ps) | peak V(Q) (V) |",
          "|---|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r[0]:g} | {r[1]:.1f} | {r[2]:.1f} | {r[3]:.1f} | {r[4]:.1f} | {r[5]:.0f} | {r[6]:.0f} | {r[7]:.3f} |")
    md += ["", "Read-disturb vs beta (gamma = 1, W_AX = 100 nm). Outcome is classified just before WL falls: 'STATE LOST' = Q and QB within 0.1 Vdd of each other (symmetric analog state, cell statically monostable under read; the state it relaxes to after WL falls is decided by numerical noise and is NOT reported as a flip direction); 'retained' = original state intact:", "",
           "| beta | static READ SNM (mV) | peak V(Q), Cbl=50 fF (V) | outcome (Cbl=50 fF) | peak V(Q), BL clamped (V) | outcome (BL clamped) | peak read current, clamped (uA) |",
           "|---|---|---|---|---|---|---|"]
    for r in brow:
        md.append(f"| {r[0]:g} | {r[1]:.1f} | {r[3]:.3f} | {r[10]} | {r[7]:.3f} | {r[11]} | {r[9]:.1f} |")
    head = dict(default_I_read_peak_uA=rows[CBLS.index(CBL_DEF)][1], default_t_to_100mV_ps_cbl50=rows[CBLS.index(CBL_DEF)][6],
                default_vq_peak_V_cbl50=rows[CBLS.index(CBL_DEF)][7],
                highest_beta_not_retained_clamped=max([r[0] for r in brow if r[8]] or [float("nan")]),
                highest_beta_not_retained_cap50=max([r[0] for r in brow if r[4]] or [float("nan")]),
                vq_peak_by_beta_clamped={f"{r[0]:g}": round(r[7], 4) for r in brow},
                outcome_by_beta_clamped={f"{r[0]:g}": r[11] for r in brow},
                outcome_by_beta_cap50={f"{r[0]:g}": r[10] for r in brow})
    S.update_summary_json("exp_c_read", head)
    return dict(summary=head, md="\n".join(md))


if __name__ == "__main__":
    print(run()["md"])
