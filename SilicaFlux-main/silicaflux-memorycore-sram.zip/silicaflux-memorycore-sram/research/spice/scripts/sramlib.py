"""
sramlib.py - shared helpers for the SRAM research simulations.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Transistor-level SPICE experiments with a hand-written generic model
(models/generic_45nm_illustrative.lib). NOT synthesizable RTL.

Contents: path constants, netlist-template rendering, the ngspice runner (one
subprocess per netlist, logged), wrdata parsing, cell-geometry helpers,
Pelgrom sampling, CSV/JSON writers.
"""
from __future__ import annotations

import csv
import json
import os
import re
import shutil
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

LABEL = "RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA"

ROOT = Path(__file__).resolve().parent.parent          # research/spice
NETLISTS = ROOT / "netlists"
WORK = ROOT / "work"                                    # scratch, safe to delete
RESULTS = ROOT / "results"
LIB_REL = "models/generic_45nm_illustrative.lib"
CELLS_REL = "netlists/cells.inc"
NGSPICE = os.environ.get("NGSPICE", "ngspice")

# Illustrative Pelgrom coefficient (mV*um) - an assumption, NOT a measured value.
AVT_MV_UM = 2.5
SEED_BASE = 20240607

_lock = threading.Lock()
COMMAND_LOG: list[dict] = []        # every ngspice invocation of this process
_raw_recorded: set[str] = set()     # experiments whose representative run is already saved
RAW_TEXT: dict[str, str] = {}       # exp -> representative netlist + ngspice log (written by run_all.py)


def ngspice_version() -> str:
    try:
        out = subprocess.run([NGSPICE, "--version"], capture_output=True, text=True, timeout=30).stdout
        m = re.search(r"ngspice-\d+", out)
        return m.group(0) if m else out.strip().splitlines()[0]
    except Exception as e:  # pragma: no cover
        return f"unavailable ({e})"


def fmt(x) -> str:
    """Compact exact-ish numeric formatting for netlists."""
    return f"{float(x):.9g}"


# ----------------------------------------------------------------------------
# geometry
# ----------------------------------------------------------------------------
@dataclass
class Cell:
    """6T cell geometry.  beta = wpd/wax, gamma = wpu/wax (all at gate length l)."""
    wax: float = 100e-9
    beta: float = 2.0
    gamma: float = 1.0
    l: float = 45e-9

    @property
    def wpd(self):
        return self.beta * self.wax

    @property
    def wpu(self):
        return self.gamma * self.wax

    def with_(self, **kw) -> "Cell":
        d = dict(wax=self.wax, beta=self.beta, gamma=self.gamma, l=self.l)
        d.update(kw)
        return Cell(**d)

    def params(self, dvt: dict | None = None, half: int | None = None) -> str:
        """subckt parameter string.  dvt keys: pd,pu,ax (half) or pd1..ax2 (cell)."""
        s = f"wpd={fmt(self.wpd)} wpu={fmt(self.wpu)} wax={fmt(self.wax)} l={fmt(self.l)}"
        if dvt:
            s += "".join(f" dvt_{k}={fmt(v)}" for k, v in dvt.items())
        return s


# ----------------------------------------------------------------------------
# templates
# ----------------------------------------------------------------------------
def render(template: str, **subs) -> str:
    text = (NETLISTS / template).read_text()
    subs = {"LABEL": LABEL, "LIB": LIB_REL, "CELLS": CELLS_REL, **subs}
    for k, v in subs.items():
        text = text.replace("{{" + k + "}}", str(v))
    left = re.findall(r"\{\{[A-Z0-9_]+\}\}", text)
    if left:
        raise ValueError(f"unfilled placeholders in {template}: {sorted(set(left))}")
    return text


# ----------------------------------------------------------------------------
# ngspice runner
# ----------------------------------------------------------------------------
class NgspiceError(RuntimeError):
    pass


def load_wrdata(path: Path):
    """Parse an ngspice wrdata file written with wr_singlescale + wr_vecnames."""
    with open(path) as f:
        header = f.readline().split()
    data = np.loadtxt(path, skiprows=1, ndmin=2)
    return header, data


def run_ngspice(name: str, netlist: str, exp: str | None = None, record: bool = False,
                timeout: float = 900.0, keep: bool = False):
    """
    Write `netlist` to work/<name>.cir, run `ngspice -b -o work/<name>.log`, and
    return (header, data) parsed from work/<name>.dat (the netlist must contain
    `wrdata {{OUT}}` with OUT = work/<name>.dat).  The exact command is appended
    to COMMAND_LOG.  If record=True and no run of `exp` was saved yet, the
    netlist + ngspice log are kept in RAW_TEXT (run_all.py writes results/ngspice_runs.txt).
    """
    WORK.mkdir(exist_ok=True)
    cir = WORK / f"{name}.cir"
    log = WORK / f"{name}.log"
    dat = WORK / f"{name}.dat"
    for p in (log, dat):
        if p.exists():
            p.unlink()
    cir.write_text(netlist)
    cmd = [NGSPICE, "-b", "-o", str(log.relative_to(ROOT)), str(cir.relative_to(ROOT))]
    t0 = time.time()
    proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    wall = time.time() - t0
    logtxt = log.read_text(errors="replace") if log.exists() else ""
    entry = dict(name=name, exp=exp, cmd="cd research/spice && " + " ".join(cmd), wall_s=round(wall, 3),
                 returncode=proc.returncode)
    with _lock:
        COMMAND_LOG.append(entry)
    # hard failures anywhere in the log (Note:/Warning: lines such as gmin-stepping notes are not failures)
    bad = re.search(r"(?im)^(?!\s*(note|warning)).*(error|fatal|singular matrix|no convergence|timestep too small|aborted|interrupted).*$", logtxt)
    if not dat.exists() or bad:
        raise NgspiceError(f"ngspice failed for {name}: rc={proc.returncode} "
                           f"{bad.group(0) if bad else 'no data file'}\n--- log tail ---\n{logtxt[-1500:]}")
    if record and exp:
        with _lock:
            first = exp not in _raw_recorded
            if first:
                _raw_recorded.add(exp)
        if first:
            lines = netlist.splitlines()
            nl = "\n".join(lines[:260]) + (f"\n* ... [{len(lines)-260} more netlist lines omitted here;"
                                           f" regenerate with the driver script]" if len(lines) > 260 else "")
            RAW_TEXT[exp] = (f"# command : {entry['cmd']}\n# wall    : {entry['wall_s']} s\n"
                             f"# ---------------- netlist (work/{name}.cir) ----------------\n{nl}\n"
                             f"# ---------------- ngspice -o log (tail) ----------------\n{logtxt[-3500:]}\n")
    res = load_wrdata(dat)
    keep = keep or os.environ.get("SRAM_KEEP_WORK") == "1"
    if not keep:
        for p in (cir, log, dat):
            try:
                p.unlink()
            except OSError:
                pass
    return res


def run_parallel(fn, jobs, workers=None):
    """Map fn over jobs with a thread pool (ngspice subprocesses release the GIL)."""
    workers = workers or int(os.environ.get("SRAM_JOBS", min(4, os.cpu_count() or 1)))
    if workers <= 1:
        return [fn(j) for j in jobs]
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, jobs))


# ----------------------------------------------------------------------------
# half-cell butterfly netlists (shared by exp b, d, f, g)
# ----------------------------------------------------------------------------
def snm_netlist(name, vdd, cell: Cell, vbl, vblb, vwl, halves, dc, probes, out):
    """Render snm_butterfly.cir.tpl.  `halves` is the text of X-instances."""
    return render("snm_butterfly.cir.tpl", NAME=name, VDD=fmt(vdd), VBL=fmt(vbl), VBLB=fmt(vblb),
                  VWL=fmt(vwl), HALVES=halves, DC=dc, PROBES=probes, OUT=str(out.relative_to(ROOT)))


def two_halves(cell: Cell, dvt1=None, dvt2=None, idx=0):
    """Half 1 (out -> Q, access BL) and half 2 (out -> QB, access BLB), sharing input `in`."""
    return (f"X1_{idx} in out1_{idx} bl  wl vdd 0 half params: {cell.params(dvt1)}\n"
            f"X2_{idx} in out2_{idx} blb wl vdd 0 half params: {cell.params(dvt2)}\n")


def vtc_sweep(name, vdd, cell, mode, exp, record=False, npts=500, dvt1=None, dvt2=None):
    """
    One butterfly (two half-cell DC sweeps).  mode: 'hold' (WL=0, BL=BLB=Vdd),
    'read' (WL=Vdd, BL=BLB=Vdd).  Returns (vin, out1, out2).
    """
    vwl = 0.0 if mode == "hold" else vdd
    step = vdd / npts
    text = snm_netlist(name, vdd, cell, vdd, vdd, vwl, two_halves(cell, dvt1, dvt2),
                       f".dc Vin 0 {fmt(vdd)} {fmt(step)}", "v(out1_0) v(out2_0)",
                       WORK / f"{name}.dat")
    hdr, d = run_ngspice(name, text, exp=exp, record=record)
    return d[:, 0], d[:, 1], d[:, 2]


# ----------------------------------------------------------------------------
# Pelgrom sampling
# ----------------------------------------------------------------------------
def sigma_vth(w, l, avt_mv_um=AVT_MV_UM):
    """sigma(Vth) [V] = A_vt / sqrt(W*L), A_vt in mV*um, W and L in m."""
    wl_um2 = (w * 1e6) * (l * 1e6)
    return avt_mv_um * 1e-3 / np.sqrt(wl_um2)


def sample_dvt(cell: Cell, n, rng, avt_mv_um=AVT_MV_UM):
    """n independent Gaussian |Vth| shifts for the 6 transistors of a cell: dict of arrays."""
    sd = {"pd": sigma_vth(cell.wpd, cell.l, avt_mv_um), "pu": sigma_vth(cell.wpu, cell.l, avt_mv_um),
          "ax": sigma_vth(cell.wax, cell.l, avt_mv_um)}
    out = {}
    for k in ("pd1", "pd2", "pu1", "pu2", "ax1", "ax2"):
        out[k] = rng.normal(0.0, sd[k[:2]], n)
    return out, sd


# ----------------------------------------------------------------------------
# output writers
# ----------------------------------------------------------------------------
def write_csv(path: Path, header, rows, comment=True):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        if comment:
            f.write(f"# {LABEL}\n")
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            w.writerow([("" if (isinstance(v, float) and np.isnan(v)) else
                         (f"{v:.6g}" if isinstance(v, (float, np.floating)) else v)) for v in r])


def read_csv(path: Path):
    with open(path) as f:
        lines = [l for l in f if not l.startswith("#")]
    rd = csv.DictReader(lines)
    return list(rd)


def update_summary_json(key, value):
    """Merge an experiment's headline numbers into results/summary.json."""
    p = RESULTS / "summary.json"
    with _lock:
        d = json.loads(p.read_text()) if p.exists() else {"label": LABEL}
        d[key] = value
        p.write_text(json.dumps(d, indent=1, sort_keys=False, default=float))


def crossing_time(t, y, level, rising=True, t_min=-np.inf):
    """First time y crosses `level` (linear interpolation) with crossing time >= t_min; nan if never."""
    t = np.asarray(t, float)
    y = np.asarray(y, float)
    if rising:
        idx = np.nonzero((y[:-1] < level) & (y[1:] >= level))[0]
    else:
        idx = np.nonzero((y[:-1] > level) & (y[1:] <= level))[0]
    for i in idx:
        tc = float(t[i] + (level - y[i]) * (t[i + 1] - t[i]) / (y[i + 1] - y[i]))
        if tc >= t_min:
            return tc
    return float("nan")
