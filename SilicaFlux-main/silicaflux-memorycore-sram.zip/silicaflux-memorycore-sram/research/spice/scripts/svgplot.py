"""
svgplot.py - tiny dependency-free SVG line/scatter/histogram plotter.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Every figure written by this module carries that label in a banner and a
footer. No matplotlib is needed (the user environment may only have
ngspice + numpy). Light/dark follow the viewer's prefers-color-scheme.
"""
from __future__ import annotations

import math
from html import escape

import numpy as np

LABEL = "RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA"
FOOT = "Generic illustrative SPICE Level-3 model, 27 C, no layout parasitics. Relative trends only; not silicon data."

# categorical slots (light / dark), fixed order
SERIES = [("#2a78d6", "#3987e5"), ("#eb6834", "#d95926"), ("#008300", "#0ca30c"),
          ("#6250d6", "#9085e9"), ("#e34948", "#e66767"), ("#1baf7a", "#199e70")]

CSS = """
svg{--bg:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--grid:#e4e3df;--axis:#8a8984;--ban:#fdecea;--banink:#8a1f17;%s}
@media (prefers-color-scheme: dark){svg{--bg:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--grid:#34332f;--axis:#8a8984;--ban:#3a1f1c;--banink:#ffb4a8;%s}}
text{font-family:Helvetica,Arial,sans-serif;fill:var(--ink)}
.t2{fill:var(--ink2)} .grid{stroke:var(--grid);stroke-width:1} .axis{stroke:var(--axis);stroke-width:1.2;fill:none}
.bg{fill:var(--bg)} .ban{fill:var(--ban)} .banink{fill:var(--banink);font-weight:700}
""" % ("".join(f"--s{i}:{c[0]};" for i, c in enumerate(SERIES)),
       "".join(f"--s{i}:{c[1]};" for i, c in enumerate(SERIES)))


def nice_ticks(lo, hi, n=6):
    if not (math.isfinite(lo) and math.isfinite(hi)):
        return [0, 1]
    if hi <= lo:
        hi = lo + 1.0
    span = hi - lo
    raw = span / max(n - 1, 1)
    mag = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m * mag:
            step = m * mag
            break
    start = math.ceil(lo / step - 1e-9) * step
    ticks, t = [], start
    while t <= hi + 1e-9 * span:
        ticks.append(round(t, 12))
        t += step
    return ticks


def fnum(v):
    if v == 0:
        return "0"
    a = abs(v)
    if a >= 1e4 or a < 1e-3:
        return f"{v:.2g}"
    s = f"{v:.4g}"
    return s


class Axes:
    def __init__(self, fig, box, xlabel, ylabel, title, xlim, ylim, legend):
        self.fig, self.box = fig, box
        self.xlabel, self.ylabel, self.title = xlabel, ylabel, title
        self.xlim, self.ylim = xlim, ylim
        self.legend = legend
        self.items = []   # ('line'|'scatter'|'hist'|'vline'|'hline'|'text', ...)

    # --- data adders -------------------------------------------------------
    def line(self, x, y, label=None, color=0, dash=None, marker=False, width=2.0):
        x, y = np.asarray(x, float), np.asarray(y, float)
        self.items.append(("line", x, y, label, color, dash, marker, width))

    def scatter(self, x, y, label=None, color=0, r=3.5):
        self.items.append(("scatter", np.asarray(x, float), np.asarray(y, float), label, color, r))

    def hist(self, vals, bins=30, label=None, color=0, rng=None):
        vals = np.asarray(vals, float)
        h, e = np.histogram(vals, bins=bins, range=rng)
        self.items.append(("hist", h, e, label, color))

    def vline(self, x, label=None, color=4, dash="5 4"):
        self.items.append(("vline", x, label, color, dash))

    def hline(self, y, label=None, color=4, dash="5 4"):
        self.items.append(("hline", y, label, color, dash))

    def text(self, x, y, s, anchor="start"):
        self.items.append(("text", x, y, s, anchor))

    # --- ranges ------------------------------------------------------------
    def _ranges(self):
        xs, ys = [], []
        for it in self.items:
            k = it[0]
            if k in ("line", "scatter"):
                m = np.isfinite(it[1]) & np.isfinite(it[2])
                xs.append(it[1][m]); ys.append(it[2][m])
            elif k == "hist":
                xs.append(np.array([it[2][0], it[2][-1]])); ys.append(np.array([0, it[1].max()]))
            elif k == "vline":
                xs.append(np.array([it[1]]))
            elif k == "hline":
                ys.append(np.array([it[1]]))
        xl, yl = self.xlim, self.ylim
        if xl is None:
            a = np.concatenate(xs) if xs else np.array([0, 1.0])
            xl = (float(a.min()), float(a.max())) if a.size else (0, 1)
            if xl[1] == xl[0]:
                xl = (xl[0] - 0.5, xl[1] + 0.5)
            padx = 0.03 * (xl[1] - xl[0])
            xl = (xl[0] - padx, xl[1] + padx)
        if yl is None:
            a = np.concatenate(ys) if ys else np.array([0, 1.0])
            lo, hi = (float(a.min()), float(a.max())) if a.size else (0, 1)
            pad = 0.06 * (hi - lo if hi > lo else 1.0)
            yl = (lo - pad if lo < 0 or lo - pad > 0 else 0.0, hi + pad)
            if lo >= 0 and lo < 0.3 * hi:
                yl = (0.0, hi + pad)
        return xl, yl

    # --- render ------------------------------------------------------------
    def render(self):
        x0, y0, w, h = self.box
        xl, yl = self._ranges()
        sx = lambda v: x0 + (v - xl[0]) / (xl[1] - xl[0]) * w
        sy = lambda v: y0 + h - (v - yl[0]) / (yl[1] - yl[0]) * h
        o = [f'<g>']
        o.append(f'<text x="{x0}" y="{y0-10}" font-size="13" font-weight="600">{escape(self.title)}</text>')
        for t in nice_ticks(*xl, n=7):
            X = sx(t)
            o.append(f'<line class="grid" x1="{X:.1f}" y1="{y0}" x2="{X:.1f}" y2="{y0+h}"/>')
            o.append(f'<text class="t2" x="{X:.1f}" y="{y0+h+15}" font-size="11" text-anchor="middle">{fnum(t)}</text>')
        for t in nice_ticks(*yl, n=6):
            Y = sy(t)
            o.append(f'<line class="grid" x1="{x0}" y1="{Y:.1f}" x2="{x0+w}" y2="{Y:.1f}"/>')
            o.append(f'<text class="t2" x="{x0-6}" y="{Y+4:.1f}" font-size="11" text-anchor="end">{fnum(t)}</text>')
        o.append(f'<rect class="axis" x="{x0}" y="{y0}" width="{w}" height="{h}"/>')
        o.append(f'<text class="t2" x="{x0+w/2}" y="{y0+h+32}" font-size="12" text-anchor="middle">{escape(self.xlabel)}</text>')
        o.append(f'<text class="t2" transform="translate({x0-44},{y0+h/2}) rotate(-90)" font-size="12" text-anchor="middle">{escape(self.ylabel)}</text>')
        o.append(f'<clipPath id="clip{self.uid}"><rect x="{x0}" y="{y0}" width="{w}" height="{h}"/></clipPath><g clip-path="url(#clip{self.uid})">')
        leg = []
        for it in self.items:
            k = it[0]
            if k == "line":
                _, x, y, label, col, dash, marker, width = it
                m = np.isfinite(x) & np.isfinite(y)
                pts = " ".join(f"{sx(a):.1f},{sy(b):.1f}" for a, b in zip(x[m], y[m]))
                d = f' stroke-dasharray="{dash}"' if dash else ""
                o.append(f'<polyline points="{pts}" fill="none" stroke="var(--s{col % 6})" stroke-width="{width}" stroke-linejoin="round"{d}/>')
                if marker:
                    for a, b in zip(x[m], y[m]):
                        o.append(f'<circle cx="{sx(a):.1f}" cy="{sy(b):.1f}" r="3.2" fill="var(--s{col % 6})" stroke="var(--bg)" stroke-width="1.2"/>')
                if label:
                    leg.append((label, col, dash, "line"))
            elif k == "scatter":
                _, x, y, label, col, r = it
                for a, b in zip(x, y):
                    if math.isfinite(a) and math.isfinite(b):
                        o.append(f'<circle cx="{sx(a):.1f}" cy="{sy(b):.1f}" r="{r}" fill="var(--s{col % 6})" stroke="var(--bg)" stroke-width="1.2"/>')
                if label:
                    leg.append((label, col, None, "dot"))
            elif k == "hist":
                _, hh, e, label, col = it
                for c, a, b in zip(hh, e[:-1], e[1:]):
                    if c > 0:
                        o.append(f'<rect x="{sx(a)+0.5:.1f}" y="{sy(c):.1f}" width="{max(sx(b)-sx(a)-1,0.5):.1f}" height="{sy(0)-sy(c):.1f}" fill="var(--s{col % 6})" opacity="0.8"/>')
                if label:
                    leg.append((label, col, None, "box"))
            elif k == "vline":
                _, x, label, col, dash = it
                o.append(f'<line x1="{sx(x):.1f}" y1="{y0}" x2="{sx(x):.1f}" y2="{y0+h}" stroke="var(--s{col % 6})" stroke-width="1.6" stroke-dasharray="{dash}"/>')
                if label:
                    leg.append((label, col, dash, "line"))
            elif k == "hline":
                _, y, label, col, dash = it
                o.append(f'<line x1="{x0}" y1="{sy(y):.1f}" x2="{x0+w}" y2="{sy(y):.1f}" stroke="var(--s{col % 6})" stroke-width="1.6" stroke-dasharray="{dash}"/>')
                if label:
                    leg.append((label, col, dash, "line"))
            elif k == "text":
                _, x, y, s, anchor = it
                o.append(f'<text x="{sx(x):.1f}" y="{sy(y):.1f}" font-size="11" text-anchor="{anchor}">{escape(s)}</text>')
        o.append("</g>")
        if self.legend and leg:
            lw = 10 + 7.0 * max(len(l[0]) for l in leg) + 34
            lh = 8 + 16 * len(leg)
            if self.legend == "tl":
                lx, ly = x0 + 8, y0 + 8
            elif self.legend == "bl":
                lx, ly = x0 + 8, y0 + h - lh - 8
            elif self.legend == "br":
                lx, ly = x0 + w - lw - 8, y0 + h - lh - 8
            else:
                lx, ly = x0 + w - lw - 8, y0 + 8
            o.append(f'<rect class="bg" x="{lx}" y="{ly}" width="{lw:.0f}" height="{lh}" rx="4" opacity="0.88" stroke="var(--grid)"/>')
            for i, (label, col, dash, kind) in enumerate(leg):
                yy = ly + 14 + 16 * i
                d = f' stroke-dasharray="{dash}"' if dash else ""
                if kind == "line":
                    o.append(f'<line x1="{lx+8}" y1="{yy-4}" x2="{lx+28}" y2="{yy-4}" stroke="var(--s{col % 6})" stroke-width="2.4"{d}/>')
                elif kind == "dot":
                    o.append(f'<circle cx="{lx+18}" cy="{yy-4}" r="4" fill="var(--s{col % 6})"/>')
                else:
                    o.append(f'<rect x="{lx+10}" y="{yy-9}" width="16" height="10" fill="var(--s{col % 6})"/>')
                o.append(f'<text x="{lx+34}" y="{yy}" font-size="11">{escape(label)}</text>')
        o.append("</g>")
        return "\n".join(o)


class Figure:
    def __init__(self, title, rows=1, cols=1, panel_w=440, panel_h=300, subtitle=""):
        self.title, self.subtitle = title, subtitle
        self.rows, self.cols, self.pw, self.ph = rows, cols, panel_w, panel_h
        self.axes_list = []

    def axes(self, r=0, c=0, xlabel="", ylabel="", title="", xlim=None, ylim=None, legend="tr"):
        left, top, gap_x, gap_y = 74, 112, 80, 78
        x0 = left + c * (self.pw + gap_x)
        y0 = top + r * (self.ph + gap_y)
        ax = Axes(self, (x0, y0, self.pw, self.ph), xlabel, ylabel, title, xlim, ylim, legend)
        ax.uid = len(self.axes_list)
        self.axes_list.append(ax)
        return ax

    def svg(self):
        left, top, gap_x, gap_y = 74, 112, 80, 78
        W = left + self.cols * (self.pw + gap_x) - gap_x + 36
        H = top + self.rows * (self.ph + gap_y) - gap_y + 96
        o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-label="{escape(self.title)}">',
             f'<style>{CSS}</style>', f'<rect class="bg" width="{W}" height="{H}"/>',
             f'<rect class="ban" x="0" y="0" width="{W}" height="30"/>',
             f'<text class="banink" x="{W/2}" y="20" font-size="13" text-anchor="middle">{escape(LABEL)}</text>',
             f'<text x="24" y="58" font-size="17" font-weight="700">{escape(self.title)}</text>']
        if self.subtitle:
            o.append(f'<text class="t2" x="24" y="78" font-size="12">{escape(self.subtitle)}</text>')
        for ax in self.axes_list:
            o.append(ax.render())
        o.append(f'<text class="t2" x="24" y="{H-30}" font-size="11">{escape(FOOT)}</text>')
        o.append(f'<text class="banink" x="24" y="{H-12}" font-size="11">{escape(LABEL)}</text>')
        o.append("</svg>")
        return "\n".join(o)

    def save(self, path):
        from pathlib import Path
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(self.svg())
