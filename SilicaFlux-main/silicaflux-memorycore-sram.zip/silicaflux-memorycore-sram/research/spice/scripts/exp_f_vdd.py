"""
exp_f_vdd.py - (f) supply-voltage sensitivity: hold / read SNM, write margin,
write time and read-disturb flip behaviour for Vdd = 1.1 ... 0.5 V (plus two
extra points, 0.4 and 0.3 V, beyond the requested range).

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Reuses netlists/snm_butterfly.cir.tpl, read_transient.cir.tpl, write_transient.cir.tpl.
Same device model at every Vdd (no body bias, no Vth adjustment, 27 C).
Read-disturb transients use a 3 ns WL pulse and clamped bitlines ("worst case").
Outputs: results/exp_f_vdd.csv, results/exp_f_vdd.svg
"""
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
import snm  # noqa: E402
import exp_c_read as C  # noqa: E402
import exp_d_write as D  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "exp_f_vdd"
VDDS = [1.1, 1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3]    # last two = extras beyond the requested list
REQUESTED = set(VDDS[:7])
BETAS = [2.0, 1.0, 0.6, 0.4]
DEFAULT = S.Cell()
WLW = 3.0e-9


def one(i):
    vdd = VDDS[i]
    out = dict(vdd=vdd)
    v, a, b = S.vtc_sweep(f"f_hold{i}", vdd, DEFAULT, "hold", EXP, record=(i == 0))
    out["hold_snm_mV"] = snm.butterfly_lobes(v, a, b, vmax=vdd)["snm"] * 1e3
    for beta in BETAS:
        v, a, b = S.vtc_sweep(f"f_read{i}_{beta}", vdd, DEFAULT.with_(beta=beta), "read", EXP)
        r = snm.butterfly_lobes(v, a, b, vmax=vdd)
        out[f"read_snm_beta{beta:g}_mV"] = r["snm"] * 1e3
        out[f"read_saddleQ_beta{beta:g}_V"] = r["qm"]
        d, tw = C.simulate(f"f_rd{i}_{beta}", DEFAULT.with_(beta=beta), "clamp", C.CBL_DEF, vdd, wlw=WLW)
        m = C.metrics(d, tw, vdd, wlw=WLW)
        out[f"disturb_vqpeak_beta{beta:g}_V"] = m["vq_peak"]
        out[f"disturb_flip_beta{beta:g}"] = m["flipped"]
        out[f"disturb_outcome_beta{beta:g}"] = m["status"]
        out[f"read_i_peak_beta{beta:g}_uA"] = m["i_read_peak_uA"]
    sm = D.static_margins(f"f_wr{i}", DEFAULT, vdd)
    out["wl_trip_V"], out["wm_wl_mV"], out["wm_bl_mV"] = sm["wl_trip"], sm["wm_wl"] * 1e3, sm["wm_bl"] * 1e3
    dw, tm = D.write_transient(f"f_wt{i}", DEFAULT, vdd=vdd, wlw=WLW)
    out["write_flipped_WL=Vdd"], out["write_t_flip_ps"] = tm["flipped"], tm["t_flip_ps"]
    return out


def run():
    res = S.run_parallel(one, range(len(VDDS)))
    keys = list(res[0].keys())
    S.write_csv(S.RESULTS / "exp_f_vdd.csv", keys, [[r[k] for k in keys] for r in res])
    vd = [r["vdd"] for r in res]
    fig = Figure("(f) Supply-voltage sensitivity of the default 6T cell", 2, 2, 440, 300,
                 "Same generic model at every Vdd; beta = 2.0 (default), 1.0, 0.6 and 0.4; gamma = 1.0; 27 C; Vdd 0.4 and 0.3 V are extras")
    ax = fig.axes(0, 0, "Vdd (V)", "SNM (mV)", "Hold and read SNM vs Vdd", legend="tl")
    ax.line(vd, [r["hold_snm_mV"] for r in res], "hold", 0, marker=True)
    for j, b in enumerate(BETAS):
        ax.line(vd, [r[f"read_snm_beta{b:g}_mV"] for r in res], f"read, beta = {b:g}", j + 1, ["6 3", "2 3", "8 3 2 3", "1 3"][j], marker=True)
    ax = fig.axes(0, 1, "Vdd (V)", "read SNM / Vdd", "Normalised read SNM", legend="bl", ylim=(0, 0.3))
    for j, b in enumerate(BETAS):
        ax.line(vd, [r[f"read_snm_beta{b:g}_mV"] * 1e-3 / r["vdd"] for r in res], f"beta = {b:g}", j + 1, ["6 3", "2 3", "8 3 2 3", "1 3"][j], marker=True)
    ax = fig.axes(1, 0, "Vdd (V)", "write margin (mV)", "Static write margins (default cell)", legend="tl")
    ax.line(vd, [r["wm_wl_mV"] for r in res], "WM_WL = Vdd - WL trip", 0, marker=True)
    ax.line(vd, [r["wm_bl_mV"] for r in res], "WM_BL = BL trip", 1, "6 3", marker=True)
    ax = fig.axes(1, 1, "Vdd (V)", "peak V(Q) / Vdd", "Read-disturb bump (BL clamped, 3 ns WL)", legend="tl")
    for j, b in enumerate(BETAS):
        ax.line(vd, [r[f"disturb_vqpeak_beta{b:g}_V"] / r["vdd"] for r in res], f"beta = {b:g}", j + 1, ["6 3", "2 3", "8 3 2 3", "1 3"][j], marker=True)
        fl = [(r["vdd"], r[f"disturb_vqpeak_beta{b:g}_V"] / r["vdd"]) for r in res if r[f"disturb_flip_beta{b:g}"]]
        if fl:
            ax.scatter([x[0] for x in fl], [x[1] for x in fl], None, 4, 6)
    if any(r[f"disturb_flip_beta{b:g}"] for r in res for b in BETAS):
        ax.text(vd[0], 0.02, "large red dot = state lost / flipped", "start")
    fig.save(S.RESULTS / "exp_f_vdd.svg")
    bl = "/".join(f"{b:g}" for b in BETAS)
    md = [f"| Vdd (V) | hold SNM (mV) | READ SNM beta=2 (mV) | read SNM/Vdd (beta=2) | READ SNM beta=1/0.6/0.4 (mV) | WM_WL (mV) | WM_BL (mV) | write flip time (ps) | peak V(Q) beta={bl} (V) | outcome beta={bl} |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in res:
        tag = "" if r["vdd"] in REQUESTED else " (extra)"
        snm_s = " / ".join(f"{r[f'read_snm_beta{b:g}_mV']:.1f}" for b in BETAS[1:])
        pk_s = " / ".join(f"{r[f'disturb_vqpeak_beta{b:g}_V']:.3f}" for b in BETAS)
        fl_s = " / ".join(r[f"disturb_outcome_beta{b:g}"] for b in BETAS)
        md.append(f"| {r['vdd']:g}{tag} | {r['hold_snm_mV']:.1f} | {r['read_snm_beta2_mV']:.1f} | {r['read_snm_beta2_mV']*1e-3/r['vdd']:.3f} | "
                  f"{snm_s} | {r['wm_wl_mV']:.0f} | {r['wm_bl_mV']:.0f} | {r['write_t_flip_ps']:.0f} | {pk_s} | {fl_s} |")
    md = [m.replace("nan", "no flip in 3 ns") for m in md]
    collapsed = {f"beta{b:g}": [r["vdd"] for r in res if r[f"read_snm_beta{b:g}_mV"] <= 0.0] for b in BETAS}
    head = dict(vdds=vd, read_snm_beta2_mV=[round(r["read_snm_beta2_mV"], 1) for r in res],
                read_snm_beta1_mV=[round(r["read_snm_beta1_mV"], 1) for r in res],
                read_snm_beta0p6_mV=[round(r["read_snm_beta0.6_mV"], 1) for r in res],
                read_snm_beta0p4_mV=[round(r["read_snm_beta0.4_mV"], 1) for r in res],
                hold_snm_mV=[round(r["hold_snm_mV"], 1) for r in res],
                wm_wl_mV=[round(r["wm_wl_mV"], 1) for r in res],
                vdds_with_zero_read_snm=collapsed,
                min_read_snm_beta2_mV=min(r["read_snm_beta2_mV"] for r in res if r["vdd"] in REQUESTED),
                disturb_not_retained_vdds={f"beta{b:g}": [r["vdd"] for r in res if r[f"disturb_flip_beta{b:g}"]] for b in BETAS})
    S.update_summary_json("exp_f_vdd", head)
    return dict(summary=head, md="\n".join(md))


if __name__ == "__main__":
    print(run()["md"])
