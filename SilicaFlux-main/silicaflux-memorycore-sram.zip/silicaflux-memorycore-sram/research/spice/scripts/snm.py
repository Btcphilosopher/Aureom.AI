"""
snm.py - static-noise-margin extraction from butterfly curves.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
(This file is pure numerics; it contains no device model. The label applies to
any number produced by feeding it simulated curves from this directory.)

Algorithm (largest axis-parallel square inscribed in a butterfly lobe)
----------------------------------------------------------------------
Two curves are given, both monotonically non-increasing:

    A :  y = f(x)     (inverter 1 transfer curve, x = QB-side input, y = Q)
    B :  x = g(y)     (inverter 2 transfer curve, mirrored: x = QB, y = Q-input)

Upper-left lobe (stored state Q=1, QB=0): R1 = { y <= f(x)  and  x >= g(y) }.
For an axis-parallel square [x0,x0+s]x[y0,y0+s] to lie in R1 it is sufficient
(because f and g are non-increasing) and necessary that

    top-right corner (x0+s, y0+s) is on/below A,   bottom-left corner (x0,y0)
    is on/right of B.

The best square therefore has its bottom-left corner on B and its top-right
corner on A, and both corners lie on one 45-degree line  y = x + c.  Calling
x_A(c) and x_B(c) the abscissae at which that line meets A and B,

    side s(c) = x_A(c) - x_B(c)        (diagonal = s*sqrt(2)),
    lobe-1 SNM = max over c of s(c) inside the lobe.

The lower-right lobe (Q=0, QB=1) is the same with the sign reversed:
lobe-2 SNM = max over c of ( x_B(c) - x_A(c) ).   This is the classical
"rotate by 45 degrees and take the largest vertical gap" method (Seevinck 1987)
written in un-rotated coordinates.

Implementation
  * Both curves are made monotone (np.minimum.accumulate) and extended outside
    the sampled range by horizontal / vertical continuation, so every line
    y = x + c meets both curves exactly once, for any c.
  * D(c) = x_A(c) - x_B(c) is evaluated on a fine c grid.  Its sign pattern
    along c is  [+] [-] [+] [-]  for a bistable cell (outer runs are the
    unbounded exterior; the two INTERIOR runs are the two lobes, bounded by the
    three curve crossings = two stable points + one metastable point).
  * lobe1 = max D over the outermost interior run with D>0 ; lobe2 = -min D over
    the outermost interior run with D<0 (the lobes adjacent to the two stable
    DATA states).  If a lobe does not exist (fewer than 3 crossings, i.e. the
    cell is monostable) it is reported as 0.0.  If the curves cross 5+ times
    (an extra analog stable state in the middle of a badly degraded cell) the
    inner lobes are ignored and `multistable` is set.
  * SNM = min(lobe1, lobe2).  Reported values are in the units of the inputs
    (volts), with resolution limited by the c grid (default 0.25 mV) and by the
    sampling density of the input curves (linear interpolation).

The module has an independent brute-force implementation (`brute_force_lobe`)
used only by the unit tests to cross-check the corner-based algorithm.
"""
from __future__ import annotations

import numpy as np

DEADBAND = 1e-7  # volts; |D| below this is treated as "zero" when finding sign runs


def _prep_A(x, y):
    """Curve A as y=f(x): x increasing, y forced non-increasing."""
    x = np.asarray(x, float)
    y = np.minimum.accumulate(np.asarray(y, float))
    order = np.argsort(x, kind="stable")
    return x[order], np.minimum.accumulate(y[order])


def _prep_B(g, y):
    """Curve B as x=g(y): y increasing, g forced non-increasing."""
    g = np.asarray(g, float)
    y = np.asarray(y, float)
    order = np.argsort(y, kind="stable")
    return np.minimum.accumulate(g[order]), y[order]


def x_on_A(c, xa, ya):
    """x where the line y = x + c meets (extended) curve A."""
    u = ya - xa  # strictly decreasing with index
    c = np.asarray(c, float)
    out = np.interp(c, u[::-1], xa[::-1])
    out = np.where(c >= u[0], ya[0] - c, out)       # left horizontal extension
    out = np.where(c <= u[-1], ya[-1] - c, out)     # right horizontal extension
    return out


def x_on_B(c, gb, yb):
    """x where the line y = x + c meets (extended) curve B."""
    u = yb - gb  # strictly increasing with index
    c = np.asarray(c, float)
    out = np.interp(c, u, gb)
    out = np.where(c <= u[0], gb[0], out)           # lower vertical extension
    out = np.where(c >= u[-1], gb[-1], out)         # upper vertical extension
    return out


def _runs(sign):
    """Run-length encode a +1/-1/0 array -> list of (sign, i0, i1) ignoring zeros."""
    idx = np.nonzero(sign != 0)[0]
    runs = []
    if idx.size == 0:
        return runs
    s0, i0, prev = sign[idx[0]], idx[0], idx[0]
    for i in idx[1:]:
        if sign[i] != s0:
            runs.append((s0, i0, prev))
            s0, i0 = sign[i], i
        prev = i
    runs.append((s0, i0, prev))
    return runs


def butterfly_lobes(vin, out_a, out_b, vmax=None, dc=2.5e-4):
    """
    Lobe sizes of a butterfly.

    vin   : common swept input voltage (monotonic increasing array)
    out_a : output of half-cell 1 for each vin.  Curve A = (x=vin, y=out_a)
    out_b : output of half-cell 2 for each vin.  Curve B = (x=out_b, y=vin)
    Returns dict(lobe1, lobe2, snm, bistable, n_runs, qm, qbm, sq1, sq2)
      lobe1 : upper-left  lobe (state Q=1/QB=0: y high, x low)   [V]
      lobe2 : lower-right lobe (state Q=0/QB=1)                   [V]
      snm   : min(lobe1, lobe2) (0.0 if either lobe is absent)
      qm,qbm: coordinates (y=Q, x=QB) of the metastable crossing (the interior
              boundary between the two lobes), nan if not bistable.
    """
    vin = np.asarray(vin, float)
    if vmax is None:
        vmax = float(vin.max())
    xa, ya = _prep_A(vin, out_a)
    gb, yb = _prep_B(out_b, vin)
    span = 2.0 * vmax
    c = np.arange(-span, span + dc, dc)
    D = x_on_A(c, xa, ya) - x_on_B(c, gb, yb)
    sgn = np.where(D > DEADBAND, 1, np.where(D < -DEADBAND, -1, 0))
    runs = _runs(sgn)
    # Data-state lobes = the OUTERMOST interior runs (adjacent to the two stable
    # data states).  For an ordinary bistable cell there are exactly two interior
    # runs (4 runs, 3 crossings).  If the curves cross 5 (or more) times the cell
    # also has an extra "analog" stable state between the data states; the
    # data-retention margin is still set by the outermost lobes, so inner runs are
    # ignored (reported via n_crossings / multistable).
    n_cross = max(len(runs) - 1, 0)
    lobe1 = lobe2 = 0.0
    c1 = c2 = None
    qm = qbm = float("nan")
    if len(runs) >= 4:
        s2, i0, i1 = runs[1]          # sign - : lower-right lobe (state Q=0)
        k = i0 + int(np.argmin(D[i0:i1 + 1]))
        lobe2, c2 = float(-D[k]), float(c[k])
        s1, i0, i1 = runs[-2]         # sign + : upper-left lobe (state Q=1)
        k = i0 + int(np.argmax(D[i0:i1 + 1]))
        lobe1, c1 = float(D[k]), float(c[k])
    bistable = lobe1 > 0.0 and lobe2 > 0.0
    if bistable:
        # saddle (metastable point) adjacent to the Q=0 data state: boundary of
        # runs[1] (-) and runs[2] (+).  Q = qm, QB = qbm there.
        i_a, i_b = runs[1][2], runs[2][1]
        c_m = 0.5 * (c[i_a] + c[i_b])
        xm = float(x_on_A(np.array([c_m]), xa, ya)[0])
        qbm, qm = xm, xm + c_m
    snm = min(lobe1, lobe2) if bistable else 0.0
    # inscribed squares (x0, y0, side) for plotting: lobe1 bottom-left corner on B, lobe2 on A
    sq1 = sq2 = None
    if bistable:
        xb = float(x_on_B(np.array([c1]), gb, yb)[0])
        sq1 = (xb, xb + c1, lobe1)
        xa0 = float(x_on_A(np.array([c2]), xa, ya)[0])
        sq2 = (xa0, xa0 + c2, lobe2)
    return dict(lobe1=lobe1, lobe2=lobe2, snm=snm, bistable=bool(bistable),
                n_runs=len(runs), n_crossings=n_cross, multistable=bool(n_cross > 3), qm=qm, qbm=qbm,
                sq1=sq1, sq2=sq2)


# --------------------------------------------------------------------------
# Independent brute-force check (tests only): does NOT use the corner shortcut.
# --------------------------------------------------------------------------
def brute_force_lobe(vin, out_a, out_b, lobe=1, grid=161, samples=13, iters=16, corner_box=None):
    """
    Largest axis-parallel square fully inside lobe 1 (y<=f(x) and x>=g(y)) or
    lobe 2 (y>=f(x) and x<=g(y)), found by exhaustive search over lower-left
    corners on a grid with bisection on the side, testing a samples x samples
    lattice of points inside every candidate square.  Accuracy ~ vmax/grid.
    """
    vin = np.asarray(vin, float)
    vmax = float(vin.max())
    xa, ya = _prep_A(vin, out_a)
    gb, yb = _prep_B(out_b, vin)

    def f(x):  # A as function of x with horizontal extension
        return np.interp(x, xa, ya)

    def g(y):  # B as function of y with vertical extension
        return np.interp(y, yb, gb)

    gx = np.linspace(0.0, vmax, grid)
    X0, Y0 = np.meshgrid(gx, gx, indexing="ij")
    if corner_box is not None:           # restrict lower-left corners: (xlo, xhi, ylo, yhi)
        xlo, xhi, ylo, yhi = corner_box
        X0 = np.where((X0 >= xlo) & (X0 <= xhi) & (Y0 >= ylo) & (Y0 <= yhi), X0, np.nan)
    X0 = X0.ravel()
    Y0 = Y0.ravel()
    keep = np.isfinite(X0)
    X0, Y0 = X0[keep], Y0[keep]
    t = np.linspace(0.0, 1.0, samples)
    TX, TY = np.meshgrid(t, t, indexing="ij")
    TX = TX.ravel()[None, :]
    TY = TY.ravel()[None, :]

    def inside(s):
        px = X0[:, None] + s[:, None] * TX
        py = Y0[:, None] + s[:, None] * TY
        if lobe == 1:
            ok = (py <= f(px) + 1e-12) & (px >= g(py) - 1e-12)
        else:
            ok = (py >= f(px) - 1e-12) & (px <= g(py) + 1e-12)
        return ok.all(axis=1)

    lo = np.zeros_like(X0)
    hi = np.full_like(X0, vmax)
    feasible0 = inside(lo + 1e-9)
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        ok = inside(mid)
        lo = np.where(ok, mid, lo)
        hi = np.where(ok, hi, mid)
    lo = np.where(feasible0, lo, 0.0)
    return float(lo.max())
