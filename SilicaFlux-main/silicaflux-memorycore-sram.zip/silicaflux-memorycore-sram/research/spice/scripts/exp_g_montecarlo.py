"""
exp_g_montecarlo.py - (g) device-mismatch Monte Carlo of READ (and hold) SNM.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Per-transistor Gaussian threshold shift, sigma(Vth) = A_vt / sqrt(W*L), with the
ILLUSTRATIVE Pelgrom coefficient A_vt = 2.5 mV*um (an assumption, NOT a measured
value of any process).  Only Vth varies (no beta/L/geometry/temperature variation).
Samples are drawn in Python (numpy default_rng, fixed seeds) and injected as
series gate sources (netlists/cells.inc); N independent cells are simulated in
one ngspice run per batch (decoupled half-cell pairs sharing one swept input).
Netlist template: netlists/snm_butterfly.cir.tpl.
Failure = SNM = 0 (monostable: at least one data state lost under read bias).
Cases: the two REQUESTED points (Vdd = 1.0 V nominal and 0.7 V, default cell beta = 2)
plus EXTRA points added to show non-zero failure counts: Vdd = 0.5 V (beta = 2) and a
weak-cell variant (beta = 1) at 1.0 V and 0.7 V.
Outputs: results/exp_g_mc_summary.csv, results/exp_g_mc_samples.csv, results/exp_g_mc.svg
"""
import math
import sys
from pathlib import Path
from statistics import NormalDist

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
import snm  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "exp_g_montecarlo"
N = 1000
BATCH = 250
# (vdd, beta, label, requested?)
CASES = [(1.0, 2.0, "nominal", True), (0.7, 2.0, "requested", True), (0.5, 2.0, "extra", False),
         (1.0, 1.0, "extra weak cell", False), (0.7, 1.0, "extra weak cell", False)]
BASE = S.Cell()
NPTS = 500
ND = NormalDist()


def cname(c):
    return f"Vdd={c[0]:g} V, beta={c[1]:g}"


def batch_snm(tag, vdd, cell, mode, dvt, i0, i1, record=False):
    halves, probes = [], []
    for k in range(i0, i1):
        d1 = {"pd": dvt["pd1"][k], "pu": dvt["pu1"][k], "ax": dvt["ax1"][k]}
        d2 = {"pd": dvt["pd2"][k], "pu": dvt["pu2"][k], "ax": dvt["ax2"][k]}
        halves.append(S.two_halves(cell, d1, d2, idx=k))
        probes += [f"v(out1_{k})", f"v(out2_{k})"]
    vwl = 0.0 if mode == "hold" else vdd
    text = S.snm_netlist(tag, vdd, cell, vdd, vdd, vwl, "".join(halves),
                         f".dc Vin 0 {S.fmt(vdd)} {S.fmt(vdd/NPTS)}", " ".join(probes), S.WORK / f"{tag}.dat")
    _, d = S.run_ngspice(tag, text, exp=EXP, record=record)
    vin = d[:, 0]
    out = []
    for j, k in enumerate(range(i0, i1)):
        r = snm.butterfly_lobes(vin, d[:, 1 + 2 * j], d[:, 2 + 2 * j], vmax=vdd)
        out.append((r["snm"], r["bistable"], r["multistable"]))
    return out


def wilson(k, n, z=1.96):
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(c - h, 0.0), c + h


def stats(x):
    x = np.asarray(x) * 1e3          # mV
    n = len(x)
    mu, sd = float(x.mean()), float(x.std(ddof=1))
    nfail = int(np.sum(x <= 0.0))
    lo, hi = wilson(nfail, n)
    z = (x - mu) / sd if sd > 0 else np.zeros_like(x)
    q = lambda p: float(np.quantile(x, p))
    return dict(n=n, mean_mV=mu, sigma_mV=sd, mu_over_sigma=mu / sd if sd > 0 else float("inf"), min_mV=float(x.min()),
                max_mV=float(x.max()), median_mV=q(0.5), n_fail_snm_le_0=nfail, fail_frac=nfail / n, fail_wilson95_lo=lo,
                fail_wilson95_hi=hi, n_below_20mV=int(np.sum(x < 20.0)), skewness=float(np.mean(z ** 3)),
                excess_kurtosis=float(np.mean(z ** 4) - 3.0),
                q001_emp_mV=q(0.001), q001_gauss_mV=mu + ND.inv_cdf(0.001) * sd, q01_emp_mV=q(0.01), q01_gauss_mV=mu + ND.inv_cdf(0.01) * sd,
                gauss_implied_pfail_illustrative=0.5 * math.erfc((mu / sd) / math.sqrt(2.0)) if sd > 0 else 0.0)


def run():
    per, sd_info, jobs = {}, {}, []
    for ci, (vdd, beta, lab, req) in enumerate(CASES):
        cell = BASE.with_(beta=beta)
        rng = np.random.default_rng(S.SEED_BASE + ci)
        dvt, sd_info[ci] = S.sample_dvt(cell, N, rng)
        per[ci] = dict(dvt=dvt, cell=cell)
        for mode in ("read", "hold"):
            for b in range(0, N, BATCH):
                jobs.append((ci, vdd, cell, mode, dvt, b, min(b + BATCH, N)))

    def work(j):
        ci, vdd, cell, mode, dvt, i0, i1 = j
        return batch_snm(f"g_{mode}_c{ci}_b{i0}", vdd, cell, mode, dvt, i0, i1, record=(ci == 0 and mode == "read" and i0 == 0))

    res = S.run_parallel(work, jobs)
    for j, r in zip(jobs, res):
        ci, vdd, cell, mode, dvt, i0, i1 = j
        per[ci].setdefault(mode, [None] * N)
        per[ci][mode][i0:i1] = r
    summary_rows = []
    for ci, (vdd, beta, lab, req) in enumerate(CASES):
        for mode in ("read", "hold"):
            arr = per[ci][mode]
            per[ci][mode + "_snm"] = np.array([a[0] for a in arr])
            st = stats(per[ci][mode + "_snm"])
            st.update(case=ci, vdd=vdd, beta=beta, mode=mode, n_multistable=int(sum(a[2] for a in arr)))
            per[ci][mode + "_stats"] = st
            summary_rows.append(st)
        # zero-mismatch reference values from the same code path
        for mode in ("read", "hold"):
            v, a, b = S.vtc_sweep(f"g_nom_{ci}_{mode}", vdd, per[ci]["cell"], mode, EXP)
            per[ci][mode + "_nominal"] = snm.butterfly_lobes(v, a, b, vmax=vdd)["snm"] * 1e3
    # consistency check of the batching trick: samples re-simulated one cell per ngspice run (read)
    chk = []
    for ci in (0, 1):
        vdd, cell = CASES[ci][0], per[ci]["cell"]
        for k in range(5):
            dv = per[ci]["dvt"]
            d1 = {"pd": dv["pd1"][k], "pu": dv["pu1"][k], "ax": dv["ax1"][k]}
            d2 = {"pd": dv["pd2"][k], "pu": dv["pu2"][k], "ax": dv["ax2"][k]}
            v, a, b = S.vtc_sweep(f"g_single_{ci}_{k}", vdd, cell, "read", EXP, dvt1=d1, dvt2=d2)
            chk.append(abs(snm.butterfly_lobes(v, a, b, vmax=vdd)["snm"] - per[ci]["read_snm"][k]) * 1e3)
    batch_check_max_diff_mV = float(max(chk))
    cols = ["vdd", "beta", "mode", "n", "mean_mV", "sigma_mV", "mu_over_sigma", "min_mV", "median_mV", "max_mV", "n_fail_snm_le_0",
            "fail_frac", "fail_wilson95_lo", "fail_wilson95_hi", "n_below_20mV", "n_multistable", "skewness", "excess_kurtosis",
            "q01_emp_mV", "q01_gauss_mV", "q001_emp_mV", "q001_gauss_mV", "gauss_implied_pfail_illustrative"]
    S.write_csv(S.RESULTS / "exp_g_mc_summary.csv", cols, [[r[c] for c in cols] for r in summary_rows])
    srows = []
    for ci, (vdd, beta, lab, req) in enumerate(CASES):
        dv = per[ci]["dvt"]
        for k in range(N):
            srows.append([vdd, beta, k] + [dv[n][k] * 1e3 for n in ("pd1", "pd2", "pu1", "pu2", "ax1", "ax2")] +
                         [per[ci]["read_snm"][k] * 1e3, per[ci]["hold_snm"][k] * 1e3])
    S.write_csv(S.RESULTS / "exp_g_mc_samples.csv",
                ["vdd", "beta", "sample", "dVth_PD1_mV", "dVth_PD2_mV", "dVth_PU1_mV", "dVth_PU2_mV", "dVth_AX1_mV", "dVth_AX2_mV",
                 "read_snm_mV", "hold_snm_mV"], srows)
    # ---- figure: histograms per case + normal probability plot
    s0, s2 = sd_info[0], sd_info[3]
    fig = Figure("(g) Monte Carlo of READ SNM under Pelgrom Vth mismatch", 2, 3, 440, 300,
                 f"N = {N} per case, fixed seeds; A_vt = {S.AVT_MV_UM} mV*um (ILLUSTRATIVE); sigma(Vth): PD {s0['pd']*1e3:.1f} mV (beta 2) / {s2['pd']*1e3:.1f} mV (beta 1), PU/AX {s0['ax']*1e3:.1f} mV; gamma = 1")
    for pi, ci in enumerate((0, 1, 2, 3, 4)):
        r, c = divmod(pi, 3)
        st = per[ci]["read_stats"]
        ax = fig.axes(r, c, "READ SNM (mV)", "count", f"{cname(CASES[ci])}: mean {st['mean_mV']:.0f}, sigma {st['sigma_mV']:.1f}, fails {st['n_fail_snm_le_0']}/{N}", legend="tl")
        x = per[ci]["read_snm"] * 1e3
        lo, hi = float(x.min()), float(x.max())
        bins = 30
        ax.hist(x, bins, "MC samples", 0, rng=(lo, hi))
        xs = np.linspace(lo, hi, 200)
        pdf = np.exp(-0.5 * ((xs - st["mean_mV"]) / st["sigma_mV"]) ** 2) / (st["sigma_mV"] * np.sqrt(2 * np.pi)) * N * (hi - lo) / bins
        ax.line(xs, pdf, "Gaussian fit (mean, sigma)", 1)
        ax.vline(per[ci]["read_nominal"], f"zero-mismatch {per[ci]['read_nominal']:.0f} mV", 4)
    ax = fig.axes(1, 2, "theoretical normal quantile (sigma units)", "standardised read SNM (sigma units)",
                  "Normal probability plot (tails vs Gaussian)", legend="tl")
    ax.line([-4, 4], [-4, 4], "ideal Gaussian", 5, "4 3", width=1.4)
    for ci in range(len(CASES)):
        x = np.sort(per[ci]["read_snm"] * 1e3)
        st = per[ci]["read_stats"]
        zq = [ND.inv_cdf((i + 0.5) / N) for i in range(N)]
        ax.line(zq, (x - st["mean_mV"]) / st["sigma_mV"], cname(CASES[ci]), ci, width=1.6)
    fig.save(S.RESULTS / "exp_g_mc.svg")
    # ---- markdown
    md = [f"N = {N} samples per row, seeds {S.SEED_BASE}+case index, A_vt = {S.AVT_MV_UM} mV*um (illustrative); "
          f"sigma(Vth) = {s0['pd']*1e3:.1f} mV (PD, 200 nm, beta 2), {s0['pu']*1e3:.1f} mV (PU/AX, 100 nm), {s2['pd']*1e3:.1f} mV (PD, 100 nm, beta 1); L = 45 nm.", "",
          "| Vdd (V) | beta | quantity | zero-mismatch (mV) | mean (mV) | sigma (mV) | mu/sigma | min (mV) | failures (SNM=0) / N | Wilson 95% interval of fail fraction | N below 20 mV | skew | excess kurt. |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for ci, (vdd, beta, lab, req) in enumerate(CASES):
        for mode in ("read", "hold"):
            st = per[ci][mode + "_stats"]
            tag = "" if req else f" ({lab})"
            md.append(f"| {vdd:g}{tag} | {beta:g} | {mode.upper()} SNM | {per[ci][mode+'_nominal']:.1f} | {st['mean_mV']:.1f} | {st['sigma_mV']:.1f} | {st['mu_over_sigma']:.2f} | {st['min_mV']:.1f} | "
                      f"{st['n_fail_snm_le_0']}/{N} | [{st['fail_wilson95_lo']:.4f}, {st['fail_wilson95_hi']:.4f}] | {st['n_below_20mV']} | {st['skewness']:+.2f} | {st['excess_kurtosis']:+.2f} |")
    md += ["", f"Consistency check of the batched-netlist trick: 10 samples re-simulated one cell per ngspice run differ from the batch result by at most {batch_check_max_diff_mV:.4f} mV.", "",
           "Illustrative Gaussian extrapolation of READ SNM (uses only mean and sigma; **NOT credible in the tails**: "
           f"with N = {N} the smallest non-zero failure fraction that can be resolved is ~1/N = {1/N:.0e}, and the empirical lower tails depart from Gaussian):", "",
           "| Vdd (V) | beta | mu/sigma | Gaussian-implied P(SNM<0) (illustrative extrapolation) | observed failures / N | empirical 1% quantile (mV) | Gaussian 1% quantile (mV) | empirical 0.1% quantile (mV) | Gaussian 0.1% quantile (mV) |",
           "|---|---|---|---|---|---|---|---|---|"]
    for ci, (vdd, beta, lab, req) in enumerate(CASES):
        st = per[ci]["read_stats"]
        md.append(f"| {vdd:g} | {beta:g} | {st['mu_over_sigma']:.2f} | {st['gauss_implied_pfail_illustrative']:.2e} | {st['n_fail_snm_le_0']}/{N} | {st['q01_emp_mV']:.1f} | {st['q01_gauss_mV']:.1f} | {st['q001_emp_mV']:.1f} | {st['q001_gauss_mV']:.1f} |")
    head = {}
    for ci, (vdd, beta, lab, req) in enumerate(CASES):
        head[f"vdd_{vdd:g}_beta_{beta:g}"] = {**{k: (round(v, 5) if isinstance(v, float) else v) for k, v in per[ci]["read_stats"].items()},
                                              "zero_mismatch_read_snm_mV": round(per[ci]["read_nominal"], 2), "requested": req, "label": lab}
    head["batch_vs_single_cell_max_abs_diff_mV"] = batch_check_max_diff_mV
    head["avt_mV_um"] = S.AVT_MV_UM
    head["sigma_vth_mV_beta2"] = {k: round(v * 1e3, 2) for k, v in sd_info[0].items()}
    head["n_samples"] = N
    S.update_summary_json("exp_g_montecarlo", head)
    return dict(summary=head, md="\n".join(md))


if __name__ == "__main__":
    print(run()["md"])
