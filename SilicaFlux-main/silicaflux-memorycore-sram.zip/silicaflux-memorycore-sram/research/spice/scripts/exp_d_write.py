"""
exp_d_write.py - (d) write operation: static write margins (WL-sweep and
BL-sweep trip points, from the lobe of the stored state vanishing in the
butterfly) and write transients (flip time) versus pull-up ratio gamma.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Netlist templates: netlists/snm_butterfly.cir.tpl (nested DC sweeps),
netlists/write_transient.cir.tpl.
Definitions (stored Q=1, write 0 through BL):
  WL-sweep trip  V_WL,trip : smallest WL voltage (BL=0, BLB=Vdd) for which the
                  butterfly lobe of the stored state (Q=1) has vanished.
  write margin   WM_WL = Vdd - V_WL,trip      (>0: writable at full WL)
  BL-sweep trip  V_BL,trip : largest BL voltage (WL=Vdd, BLB=Vdd) for which the
                  stored-state lobe has vanished.  WM_BL = V_BL,trip  (>0: writable).
Grid resolution of the sweeps: Vdd/400 (WL) and Vdd/200 (BL) with linear
interpolation of the lobe size; quote results to ~ +/- that step only.
Outputs: results/exp_d_write_gamma.csv, results/exp_d_write_wlcheck.csv, results/exp_d_write.svg
"""
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
import snm  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "exp_d_write"
VDD = 1.0
DEFAULT = S.Cell()
GAMMAS = [0.4, 0.6, 0.8, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0]
CBL = 50e-15
RDRV = 500.0
TR = 20e-12
TWR = 100e-12
TWL = 200e-12
WLW = 2.0e-9
NIN = 500


def lobe1_vs_control(name, cell, vdd, which, ncontrol, record=False):
    """Nested DC sweep: inner Vin, outer = WL (which='wl') or BL (which='bl'). Returns (control, lobe1)."""
    if which == "wl":
        vbl, vblb, vwl = 0.0, vdd, 0.0
        outer = f"Vwl 0 {S.fmt(vdd)} {S.fmt(vdd/ncontrol)}"
        probe_ctl = "v(wl)"
    else:
        vbl, vblb, vwl = 0.0, vdd, vdd
        outer = f"Vbl 0 {S.fmt(vdd)} {S.fmt(vdd/ncontrol)}"
        probe_ctl = "v(bl)"
    text = S.snm_netlist(name, vdd, cell, vbl, vblb, vwl, S.two_halves(cell),
                         f".dc Vin 0 {S.fmt(vdd)} {S.fmt(vdd/NIN)} {outer}",
                         f"v(out1_0) v(out2_0) {probe_ctl}", S.WORK / f"{name}.dat")
    _, d = S.run_ngspice(name, text, exp=EXP, record=record)
    nin = NIN + 1
    nout = d.shape[0] // nin
    ctl, l1 = [], []
    for k in range(nout):
        blk = d[k * nin:(k + 1) * nin]
        ctl.append(blk[0, 3])
        r = snm.butterfly_lobes(blk[:, 0], blk[:, 1], blk[:, 2], vmax=vdd)
        l1.append(r["lobe1"])
    return np.array(ctl), np.array(l1)


def trip_from_lobe(ctl, l1, direction):
    """
    WL-sweep (direction=+1): first control value where lobe vanishes while increasing.
    BL-sweep (direction=-1): lobe vanishes for LOW BL; trip = control value where lobe
    reappears when increasing BL (largest BL with no lobe).
    Returns nan if the lobe never vanishes (not statically writable).
    """
    eps = 1e-6
    if direction > 0:
        idx = np.nonzero(l1 <= eps)[0]
        if idx.size == 0:
            return float("nan")
        k = idx[0]
        if k == 0:
            return float(ctl[0])
        # linear interpolation between last positive point and first zero point
        a, b = l1[k - 1], l1[k]
        return float(ctl[k - 1] + (a - 0.0) / (a - b) * (ctl[k] - ctl[k - 1]))
    idx = np.nonzero(l1 > eps)[0]
    if idx.size == 0:
        return float(ctl[-1])           # lobe never exists up to Vdd: writable throughout
    k = idx[0]
    if k == 0:
        return float("nan")             # lobe exists even at BL=0: not writable
    a, b = l1[k - 1], l1[k]
    return float(ctl[k - 1] + (eps - a) / (b - a) * (ctl[k] - ctl[k - 1])) if b > a else float(ctl[k - 1])


def static_margins(tag, cell, vdd, record=False):
    cw, lw = lobe1_vs_control(f"{tag}_wl", cell, vdd, "wl", 400, record=record)
    cb, lb = lobe1_vs_control(f"{tag}_bl", cell, vdd, "bl", 200)
    wl_trip = trip_from_lobe(cw, lw, +1)
    bl_trip = trip_from_lobe(cb, lb, -1)
    return dict(wl_trip=wl_trip, wm_wl=vdd - wl_trip if np.isfinite(wl_trip) else float("nan"),
                bl_trip=bl_trip, wm_bl=bl_trip, cw=cw, lw=lw, cb=cb, lb=lb)


def write_transient(name, cell, vdd=VDD, vwlh=None, wlw=WLW, cbl=CBL, rdrv=RDRV, record=False):
    vwlh = vdd if vwlh is None else vwlh
    tstop = TWL + TR + wlw + 400e-12
    text = S.render("write_transient.cir.tpl", NAME=name, VDD=S.fmt(vdd), CELLPARAMS=cell.params(), TWR=S.fmt(TWR),
                    TR=S.fmt(TR), RDRV=S.fmt(rdrv), CBL=S.fmt(cbl), VWLH=S.fmt(vwlh), TWL=S.fmt(TWL), WLW=S.fmt(wlw),
                    TSTEP="2p", TSTOP=S.fmt(tstop), TMAX="5p", OUT=str((S.WORK / f"{name}.dat").relative_to(S.ROOT)))
    _, d = S.run_ngspice(name, text, exp=EXP, record=record)
    t, q, qb = d[:, 0], d[:, 1], d[:, 2]
    t50 = TWL + TR / 2
    tc = S.crossing_time(t, q - qb, 0.0, rising=False, t_min=t50 - 50e-12)
    ts = S.crossing_time(t, q, 0.1 * vdd, rising=False, t_min=t50)
    flipped = int(q[-1] < qb[-1])
    return d, dict(flipped=flipped, t_flip_ps=(tc - t50) * 1e12 if np.isfinite(tc) else float("nan"),
                   t_q10_ps=(ts - t50) * 1e12 if np.isfinite(ts) else float("nan"),
                   q_end=float(q[-1]), qb_end=float(qb[-1]))


def run():
    # --- gamma sweep: static margins + write transient at full WL
    def work(i):
        g = GAMMAS[i]
        cell = DEFAULT.with_(gamma=g)
        sm = static_margins(f"d_g{i}", cell, VDD, record=(i == 0))
        d, tm = write_transient(f"d_wt{i}", cell, record=(i == 0))
        return sm, d, tm

    res = S.run_parallel(work, range(len(GAMMAS)))
    rows = []
    for g, (sm, d, tm) in zip(GAMMAS, res):
        rows.append([g, DEFAULT.beta, sm["wl_trip"], sm["wm_wl"], sm["bl_trip"], sm["wm_bl"], tm["flipped"],
                     tm["t_flip_ps"], tm["t_q10_ps"], tm["q_end"], tm["qb_end"]])
    S.write_csv(S.RESULTS / "exp_d_write_gamma.csv",
                ["gamma", "beta", "WL_trip_V", "WM_WL_V", "BL_trip_V", "WM_BL_V", "transient_flipped(WL=Vdd,2ns)",
                 "t_flip_ps(Q=QB,from_WL50%)", "t_Q_below_10pct_Vdd_ps", "Q_end_V", "QB_end_V"], rows)
    idef = GAMMAS.index(1.0)
    sm0, d0, tm0 = res[idef]
    # --- static-vs-transient cross-check at the default cell: WL amplitude just below / above the static trip
    trip = sm0["wl_trip"]
    chk = []
    for k, off in enumerate((-0.030, -0.010, +0.010, +0.030, +0.060)):
        v = trip + off
        dd, tm = write_transient(f"d_chk{k}", DEFAULT, vwlh=v, wlw=5.0e-9)
        chk.append([off * 1e3, v, tm["flipped"], tm["t_flip_ps"], tm["q_end"], tm["qb_end"]])
    S.write_csv(S.RESULTS / "exp_d_write_wlcheck.csv",
                ["V_WL_minus_static_trip_mV", "V_WL_amplitude_V", "flipped_within_5ns", "t_flip_ps", "Q_end_V", "QB_end_V"], chk)
    # --- figure
    fig = Figure("(d) Write operation: write margin and flip time vs pull-up ratio gamma", 2, 2, 440, 300,
                 f"Vdd = {VDD} V; beta = 2.0; W_AX = 100 nm; write driver R = {RDRV:g} ohm, Cbl = {CBL*1e15:g} fF; stored Q = 1 -> 0")
    ax = fig.axes(0, 0, "WL voltage (V)", "lobe size of stored state Q=1 (mV)", "Stored-state lobe vs WL (BL=0), default cell", legend=None)
    ax.line(sm0["cw"], sm0["lw"] * 1e3, None, 0)
    ax.vline(sm0["wl_trip"], f"static trip {sm0['wl_trip']:.3f} V", 1)
    ax = fig.axes(0, 1, "gamma = W_PU / W_AX", "voltage (V)", "Static trips vs gamma", legend="tl")
    ax.line(GAMMAS, [r[2] for r in rows], "WL-sweep trip (BL=0)", 0, marker=True)
    ax.line(GAMMAS, [r[4] for r in rows], "BL-sweep trip (WL=Vdd)", 1, "6 3", marker=True)
    ax = fig.axes(1, 0, "time (ns)", "voltage (V)", "Write transient, default cell (gamma = 1)", legend="tr")
    ax.line(d0[:, 0] * 1e9, d0[:, 5], "WL", 3, "3 3")
    ax.line(d0[:, 0] * 1e9, d0[:, 1], "Q", 0)
    ax.line(d0[:, 0] * 1e9, d0[:, 2], "QB", 1)
    ax.line(d0[:, 0] * 1e9, d0[:, 3], "BL", 2, "2 3")
    ok = [r for r in rows if r[6]]
    ax = fig.axes(1, 1, "gamma = W_PU / W_AX", "flip time from WL 50% (ps)", "Flip time vs gamma (WL = Vdd; no marker = no flip in 2 ns)", legend=None)
    ax.line([r[0] for r in ok], [r[7] for r in ok], None, 0, marker=True)
    fig.save(S.RESULTS / "exp_d_write.svg")
    # --- markdown
    md = ["| gamma | WL-sweep trip (V) | WM_WL = Vdd - trip (mV) | BL-sweep trip = WM_BL (mV) | transient at WL=Vdd | flip time Q=QB (ps) | Q below 10% Vdd (ps) |",
          "|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r[0]:g} | {r[2]:.3f} | {r[3]*1e3:.0f} | {r[5]*1e3:.0f} | {'flipped' if r[6] else '**NO FLIP in 2 ns**'} | "
                  f"{r[7]:.0f} | {r[8]:.0f} |".replace("nan", "-"))
    md += ["", "Static-vs-transient consistency, default cell (WL pulse amplitude relative to the static WL-sweep trip, 5 ns pulse):", "",
           "| V_WL - trip (mV) | V_WL (V) | flipped within 5 ns | flip time (ps) |", "|---|---|---|---|"]
    for r in chk:
        md.append(f"| {r[0]:+.0f} | {r[1]:.3f} | {'yes' if r[2] else 'no'} | {r[3]:.0f} |".replace("nan", "-"))
    head = dict(default_WL_trip_V=sm0["wl_trip"], default_WM_WL_mV=sm0["wm_wl"] * 1e3, default_BL_trip_V=sm0["bl_trip"],
                default_flip_time_ps=tm0["t_flip_ps"],
                gamma_fail_threshold=min([r[0] for r in rows if not r[6]] or [float("nan")]),
                wm_wl_mV_by_gamma={f"{r[0]:g}": (round(r[3] * 1e3, 1) if np.isfinite(r[3]) else None) for r in rows},
                flip_time_ps_by_gamma={f"{r[0]:g}": (round(r[7], 1) if np.isfinite(r[7]) else None) for r in rows},
                wlcheck=[dict(off_mV=c[0], flipped=bool(c[2])) for c in chk])
    S.update_summary_json("exp_d_write", head)
    return dict(summary=head, md="\n".join(md))


if __name__ == "__main__":
    print(run()["md"])
