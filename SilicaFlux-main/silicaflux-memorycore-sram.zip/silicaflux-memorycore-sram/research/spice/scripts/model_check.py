"""
model_check.py - characterise the GENERIC ILLUSTRATIVE device model and verify
the "series gate source == Vth shift" equivalence used by the mismatch runs.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Outputs: results/model_check.csv, results/model_check.svg ; returns summary dict.
"""
import re
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "model_check"
DVT = 0.030  # V, used for the equivalence check only


def _shifted_models(dvt):
    """Copy the lib's nch/pch cards with |vto| increased by dvt (names nch_shift / pch_shift)."""
    txt = (S.ROOT / S.LIB_REL).read_text()
    txt = "\n".join(l for l in txt.splitlines() if not l.lstrip().startswith("*"))
    txt = re.sub(r"\n\+", " ", txt)  # join continuation lines
    out = []
    for m in re.finditer(r"\.model\s+(nch|pch)\s+(nmos|pmos)\s*\((.*?)\)\s*(?:\n|$)", txt, flags=re.S):
        name, kind, body = m.groups()
        v = float(re.search(r"vto\s*=\s*([-+0-9.eE]+)", body).group(1))
        v2 = v + dvt if v > 0 else v - dvt
        body2 = re.sub(r"vto\s*=\s*[-+0-9.eE]+", f"vto={v2:.6g}", body)
        out.append(f".model {name}_shift {kind} ({body2})")
    assert len(out) == 2, out
    return "\n".join(out)


def _vth_cc(vg, i, icc):
    """Gate voltage at which i crosses icc (log interpolation)."""
    idx = np.nonzero((i[:-1] < icc) & (i[1:] >= icc))[0]
    if not idx.size:
        return float("nan")
    k = idx[0]
    f = (np.log(icc) - np.log(i[k])) / (np.log(i[k + 1]) - np.log(i[k]))
    return float(vg[k] + f * (vg[k + 1] - vg[k]))


def run(vdd=1.0):
    text = S.render("model_check.cir.tpl", VDD=S.fmt(vdd), DVT=S.fmt(DVT), SHIFTED_MODELS=_shifted_models(DVT),
                    OUT=str((S.WORK / "model_check.dat").relative_to(S.ROOT)))
    hdr, d = S.run_ngspice("model_check", text, exp=EXP, record=True)
    vg = d[:, 0]
    idn1, idn2, idp1, idn3, idn4, idp5, idp6 = (d[:, k] for k in range(1, 8))
    # Reported per um of width (W = 1 um)
    icc = 100e-9 * (1.0e-6 / 45e-9)  # 100 nA * W/L constant-current criterion
    vth_n_sat, vth_n_lin = _vth_cc(vg, idn1, icc), _vth_cc(vg, idn2, icc)
    vth_p_sat = _vth_cc(vg, idp1, icc)
    # sub-threshold swing between 1e-8 and 1e-7 A/um on the Vds=Vdd curve
    a, b = _vth_cc(vg, idn1, 1e-8), _vth_cc(vg, idn1, 1e-7)
    ss = (b - a) * 1e3
    eq_n = float(np.max(np.abs(idn3 - idn4) / np.maximum(idn3, 1e-15)))
    eq_p = float(np.max(np.abs(idp5 - idp6) / np.maximum(idp5, 1e-15)))
    summ = dict(
        vdd=vdd,
        nmos_ion_uA_per_um=float(idn1[-1] * 1e6), nmos_ioff_nA_per_um=float(idn1[0] * 1e9),
        pmos_ion_uA_per_um=float(idp1[-1] * 1e6), pmos_ioff_nA_per_um=float(idp1[0] * 1e9),
        nmos_vth_cc_sat_V=vth_n_sat, nmos_vth_cc_lin_V=vth_n_lin, nmos_dibl_mV_per_V=(vth_n_lin - vth_n_sat) * 1e3 / (vdd - 0.05),
        pmos_vth_cc_sat_V=vth_p_sat, nmos_subthreshold_swing_mV_dec=ss,
        dvt_equiv_dvt_V=DVT, dvt_equiv_max_err_nmos=eq_n, dvt_equiv_max_err_pmos=eq_p,
        ioff_ion_ratio_n=float(idn1[-1] / idn1[0]), icc_A=icc)
    S.write_csv(S.RESULTS / "model_check.csv",
                ["vg_V", "id_nmos_vds_vdd_A", "id_nmos_vds_0p05_A", "id_pmos_vsd_vdd_A(vsg=vdd-vg)",
                 "id_nmos_vto_shift_A", "id_nmos_gate_series_A", "id_pmos_vto_shift_A", "id_pmos_gate_series_A"],
                [[vg[i]] + [d[i, k] for k in range(1, 8)] for i in range(0, len(vg), 2)])
    fig = Figure("Device model check (generic illustrative Level-3, W=1 um, L=45 nm)", 1, 2, 440, 300,
                 "Id-Vgs of the hand-written model; uncalibrated, for plausibility only")
    ax = fig.axes(0, 0, "Vgs (V)  [PMOS: Vsg]", "drain current (A/um, log10)", "Id-Vgs, |Vds| = 1.0 V", legend="tl")
    pos = lambda y: np.log10(np.maximum(y, 1e-15))
    ax.line(vg, pos(idn1), "NMOS", 0)
    ax.line(vg, pos(idp1), "PMOS", 1, "6 3")
    ax.line(vg, pos(idn2), "NMOS |Vds|=0.05", 2, "2 3")
    ax2 = fig.axes(0, 1, "Vgs (V)", "drain current (uA/um)", "Id-Vgs linear (|Vds| = 1.0 V)", legend="tl")
    ax2.line(vg, idn1 * 1e6, "NMOS", 0)
    ax2.line(vg, idp1 * 1e6, "PMOS", 1, "6 3")
    fig.save(S.RESULTS / "model_check.svg")
    S.update_summary_json("model_check", summ)
    md = ["| quantity (W=1 um, L=45 nm, 27 C) | NMOS | PMOS |", "|---|---|---|",
          f"| Ion at Vgs=Vds=1.0 V (uA/um) | {summ['nmos_ion_uA_per_um']:.0f} | {summ['pmos_ion_uA_per_um']:.0f} |",
          f"| Ioff at Vgs=0, Vds=1.0 V (nA/um) | {summ['nmos_ioff_nA_per_um']:.3g} | {summ['pmos_ioff_nA_per_um']:.3g} |",
          f"| Vth (constant current 100 nA*W/L, Vds=1.0 V) (V) | {summ['nmos_vth_cc_sat_V']:.3f} | {summ['pmos_vth_cc_sat_V']:.3f} |",
          f"| DIBL (mV/V, Vds 0.05 -> 1.0 V, NMOS) | {summ['nmos_dibl_mV_per_V']:.0f} | - |",
          f"| sub-threshold swing 10-100 nA/um (mV/dec, NMOS) | {summ['nmos_subthreshold_swing_mV_dec']:.0f} | - |",
          f"| series-gate-source vs model-vto shift, max rel. error over sweep (dVth=30 mV) | {eq_n:.2e} | {eq_p:.2e} |"]
    return dict(summary=summ, md="\n".join(md))


if __name__ == "__main__":
    r = run()
    print(r["md"])
