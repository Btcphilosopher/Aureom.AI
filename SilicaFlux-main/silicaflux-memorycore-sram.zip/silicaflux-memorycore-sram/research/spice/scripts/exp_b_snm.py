"""
exp_b_snm.py - (b) hold and read static noise margin from DC butterfly curves,
and READ SNM versus cell ratio beta.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Netlist templates: netlists/snm_butterfly.cir.tpl (+ cells.inc) and the independent
cross-check netlists/snm_noise_check.cir.tpl (full cell, static noise source injected in
series with both inverter inputs, swept until the stored state disappears).  SNM algorithm:
scripts/snm.py (largest inscribed square, unit-tested in scripts/test_snm.py).
Outputs: results/exp_b_snm_beta.csv (all beta/gamma cases), results/exp_b_butterfly_default.csv,
         results/exp_b_snm.svg
"""
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
import snm  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "exp_b_snm"
VDD = 1.0
BETAS = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75, 3.0]   # 0.25-0.75 are extras below the requested 1.0-3.0 range
GRID_BETAS = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
GRID_GAMMAS = [0.5, 1.0, 1.5]
DEFAULT = S.Cell()


def one(job):
    tag, cell, mode, rec = job
    v, a, b = S.vtc_sweep(tag, VDD, cell, mode, EXP, record=rec)
    return v, a, b, snm.butterfly_lobes(v, a, b)


def noise_snm(tag, cell, mode, sign):
    """SNM of the state (sign>0: Q=1/QB=0, sign<0: Q=0/QB=1) by noise-source injection (volts)."""
    vwl = 0.0 if mode == "hold" else VDD
    q0, qb0 = (VDD, 0.0) if sign > 0 else (0.0, VDD)
    text = S.render("snm_noise_check.cir.tpl", NAME=tag, VDD=S.fmt(VDD), VWL=S.fmt(vwl), WPD=S.fmt(cell.wpd), WPU=S.fmt(cell.wpu),
                    WAX=S.fmt(cell.wax), L=S.fmt(cell.l), VQ0=S.fmt(q0), VQB0=S.fmt(qb0), VNEND=S.fmt(sign * 0.6 * VDD),
                    VNSTEP=S.fmt(sign * 0.0005 * VDD), OUT=str((S.WORK / f"{tag}.dat").relative_to(S.ROOT)))
    _, d = S.run_ngspice(tag, text, exp=EXP, record=(tag == "b_nc_0"))
    vn, q, qb = d[:, 0], d[:, 1], d[:, 2]
    diff = (q - qb) * sign
    if diff[0] < 0.2 * VDD:          # stored state does not exist even without noise
        return 0.0
    idx = np.nonzero(diff < 0)[0]
    return float(abs(vn[idx[0] - 1])) if idx.size else float("nan")


def run():
    cases = [(DEFAULT.gamma, b) for b in BETAS] + [(g, b) for g in GRID_GAMMAS if g != DEFAULT.gamma for b in GRID_BETAS]
    jobs = []
    for i, (g, b) in enumerate(cases):
        for m in ("hold", "read"):
            jobs.append((f"b_{m}_{i}", DEFAULT.with_(beta=b, gamma=g), m, i == 0 and m == "hold"))
    res = S.run_parallel(one, jobs)
    byname = {j[0]: r for j, r in zip(jobs, res)}
    allrows = []
    for i, (g, b) in enumerate(cases):
        h, r = byname[f"b_hold_{i}"][3], byname[f"b_read_{i}"][3]
        allrows.append([b, g, h["snm"] * 1e3, r["snm"] * 1e3, r["lobe1"] * 1e3, r["lobe2"] * 1e3, r["qm"], int(r["bistable"]),
                        int(r["multistable"])])
    # independent cross-check: static-noise-source injection on the full cell (all cases, both states, hold + read)
    ncjobs = [(f"b_nc_{i}_{m}_{sg}", cases[i], m, sg) for i in range(len(cases)) for m in ("hold", "read") for sg in (1, -1)]
    ncjobs[0] = ("b_nc_0", *ncjobs[0][1:])
    ncres = S.run_parallel(lambda j: noise_snm(j[0], DEFAULT.with_(gamma=j[1][0], beta=j[1][1]), j[2], j[3]), ncjobs)
    nc = {(j[0].split("_")[2] if j[0] != "b_nc_0" else "0", j[2], j[3]): v for j, v in zip(ncjobs, ncres)}
    maxdiff = 0.0
    for i, r in enumerate(allrows):
        h_p, h_n = nc[(str(i), "hold", 1)], nc[(str(i), "hold", -1)]
        r_p, r_n = nc[(str(i), "read", 1)], nc[(str(i), "read", -1)]
        r += [min(h_p, h_n) * 1e3, min(r_p, r_n) * 1e3]
        maxdiff = max(maxdiff, abs(r[-1] - r[3]), abs(r[-2] - r[2]))
    S.write_csv(S.RESULTS / "exp_b_snm_beta.csv",
                ["beta", "gamma", "hold_snm_mV", "read_snm_mV", "read_lobe1_mV", "read_lobe2_mV",
                 "read_saddle_Q_V", "read_bistable", "read_multistable", "xcheck_hold_noise_inj_mV", "xcheck_read_noise_inj_mV"], allrows)
    rows = allrows[:len(BETAS)]                      # gamma = 1 beta sweep
    grid = [[r[1], r[0], r[3]] for r in allrows if r[0] in GRID_BETAS]   # (gamma, beta, read snm)
    grid.sort(key=lambda x: (x[0], x[1]))
    # default butterfly curves
    idef = BETAS.index(2.0)
    vh, ah, bh, rh = byname[f"b_hold_{idef}"]
    vr, ar, br, rr = byname[f"b_read_{idef}"]
    sl = slice(0, None, 5)
    S.write_csv(S.RESULTS / "exp_b_butterfly_default.csv",
                ["vin_V", "hold_out_half1_V", "hold_out_half2_V", "read_out_half1_V", "read_out_half2_V"],
                [[vh[k], ah[k], bh[k], ar[k], br[k]] for k in range(0, len(vh), 5)])
    # figure
    fig = Figure("(b) Static noise margin: hold / read butterflies and read SNM vs beta", 2, 2, 440, 300,
                 f"Vdd = {VDD} V; default cell beta = 2.0, gamma = 1.0, W_AX = 100 nm, L = 45 nm; BL = BLB = Vdd")
    for k, (name, v, a, b, r) in enumerate((("HOLD (WL = 0)", vh, ah, bh, rh), ("READ (WL = Vdd)", vr, ar, br, rr))):
        ax = fig.axes(0, k, "QB (V)", "Q (V)", f"{name} butterfly, SNM = {r['snm']*1e3:.0f} mV", (0, VDD), (0, VDD), legend=None)
        ax.line(v, a, None, 0)
        ax.line(b, v, None, 1, "6 3")
        for sq, col in ((r["sq1"], 2), (r["sq2"], 2)):
            x0, y0, s = sq
            ax.line([x0, x0 + s, x0 + s, x0, x0], [y0, y0, y0 + s, y0 + s, y0], None, col, width=1.8)
    ax = fig.axes(1, 0, "beta = W_PD / W_AX", "SNM (mV)", "SNM vs beta (gamma = 1.0)", legend="tl")
    ax.line(BETAS, [r[2] for r in rows], "hold SNM", 0, marker=True)
    ax.line(BETAS, [r[3] for r in rows], "read SNM", 1, "6 3", marker=True)
    ax = fig.axes(1, 1, "beta = W_PD / W_AX", "READ SNM (mV)", "READ SNM vs beta for three gammas", legend="tl")
    for gi, g in enumerate(GRID_GAMMAS):
        sel = [x for x in grid if x[0] == g]
        ax.line([x[1] for x in sel], [x[2] for x in sel], f"gamma = {g}", gi, ["", "6 3", "2 3"][gi] or None, marker=True)
    fig.save(S.RESULTS / "exp_b_snm.svg")
    md1 = ["| beta | hold SNM (mV) | READ SNM (mV) | read lobe 1 / lobe 2 (mV) | saddle Q level during read (V) | cross-check: READ SNM by noise injection (mV) |", "|---|---|---|---|---|---|"]
    for r in rows:
        md1.append(f"| {r[0]:g} | {r[2]:.1f} | {r[3]:.1f} | {r[4]:.1f} / {r[5]:.1f} | {r[6]:.3f} | {r[10]:.1f} |".replace("nan", "-"))
    md1 += ["", f"Independent cross-check: the same cell simulated as a full 6T cell with a static noise voltage injected in series with both inverter inputs "
            f"(swept in 0.5 mV steps until the stored state vanishes) agrees with the inscribed-square values to within {maxdiff:.2f} mV over all "
            f"{len(allrows)} beta/gamma cases (hold and read, both stored states; the noise sweep has 0.5 mV granularity)."]
    md2 = ["", "READ SNM (mV) on a beta x gamma grid:", "", "| gamma \\ beta | " + " | ".join(f"{b:g}" for b in GRID_BETAS) + " |",
           "|---|" + "---|" * len(GRID_BETAS)]
    for g in GRID_GAMMAS:
        md2.append(f"| {g:g} | " + " | ".join(f"{x[2]:.1f}" for x in grid if x[0] == g) + " |")
    head = dict(hold_snm_default_mV=rows[idef][2], read_snm_default_mV=rows[idef][3],
                read_snm_beta1_mV=rows[BETAS.index(1.0)][3], read_snm_beta3_mV=rows[-1][3],
                read_snm_by_beta_mV={f"{r[0]:g}": round(r[3], 2) for r in rows},
                read_snm_monotonic_in_beta=bool(all(np.diff([r[3] for r in rows]) > 0)),
                snm_algorithm_resolution_mV=0.25, noise_injection_crosscheck_max_abs_diff_mV=round(maxdiff, 3))
    S.update_summary_json("exp_b_snm", head)
    return dict(summary=head, md="\n".join(md1 + md2))


if __name__ == "__main__":
    print(run()["md"])
