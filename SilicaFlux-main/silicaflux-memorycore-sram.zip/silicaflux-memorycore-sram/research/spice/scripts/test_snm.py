"""
test_snm.py - unit tests for scripts/snm.py on analytic / synthetic curves.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
(no SPICE here; synthetic curves only.)  Run:  python3 scripts/test_snm.py
Writes results/snm_unit_tests.txt and exits non-zero on failure.
"""
import sys
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE))
import snm  # noqa: E402

OUT = HERE.parent / "results" / "snm_unit_tests.txt"
lines = ["RESEARCH SIMULATION \u2013 UNCALIBRATED GENERIC MODEL \u2013 NOT SILICON DATA",
         "SNM-extraction unit tests on synthetic (non-SPICE) curves", ""]
fails = 0


def check(name, got, want, tol):
    global fails
    ok = abs(got - want) <= tol
    fails += (not ok)
    lines.append(f"{'PASS' if ok else 'FAIL'}  {name}: got {got*1e3:9.3f} mV  expected {want*1e3:9.3f} mV  (tol {tol*1e3:.2f} mV)")


def ramp(x, m, w, vdd=1.0):
    """Piecewise-linear inverter: vdd for x<m-w, 0 for x>m+w, linear between."""
    return np.clip(vdd * (0.5 - (x - m) / (2 * w)), 0.0, vdd)


V = np.linspace(0.0, 1.0, 1001)

# 1. Exact analytic case: symmetric ramp VTCs (m=0.5, half-width w): SNM = Vdd/2 - w
for w in (0.02, 0.05, 0.1, 0.2, 0.3, 0.4):
    r = snm.butterfly_lobes(V, ramp(V, 0.5, w), ramp(V, 0.5, w))
    check(f"analytic symmetric ramp w={w}: SNM = 0.5-w", r["snm"], 0.5 - w, 0.5e-3)
    check(f"   lobe1 == lobe2 (w={w})", r["lobe1"], r["lobe2"], 0.5e-3)

# 2. Ideal-step limit: SNM -> Vdd/2
r = snm.butterfly_lobes(V, ramp(V, 0.5, 1e-3), ramp(V, 0.5, 1e-3))
check("step-inverter limit: SNM -> 0.5 V", r["snm"], 0.5, 2e-3)

# 3. Brute-force cross-check on asymmetric / smooth curves (independent algorithm).
#    Brute force is a grid search -> lower bound accurate to ~ grid spacing (6.25 mV).
Vc = np.linspace(0.0, 1.0, 401)
cases = {
    "asym ramps m_a=0.60 m_b=0.50 w=0.05": (ramp(Vc, 0.60, 0.05), ramp(Vc, 0.50, 0.05)),
    "asym ramps m_a=0.40 m_b=0.55 w=0.10": (ramp(Vc, 0.40, 0.10), ramp(Vc, 0.55, 0.10)),
    "tanh sym  gain~8   m=0.50": (0.5 * (1 - np.tanh(4 * (Vc - 0.5) * 2)), 0.5 * (1 - np.tanh(4 * (Vc - 0.5) * 2))),
    "tanh asym m_a=0.45 m_b=0.58": (0.5 * (1 - np.tanh(8 * (Vc - 0.45))), 0.5 * (1 - np.tanh(6 * (Vc - 0.58)))),
}
for name, (a, b) in cases.items():
    r = snm.butterfly_lobes(Vc, a, b)
    b1 = snm.brute_force_lobe(Vc, a, b, lobe=1)
    b2 = snm.brute_force_lobe(Vc, a, b, lobe=2)
    check(f"brute-force lobe1  [{name}]", r["lobe1"], b1, 8e-3)
    check(f"brute-force lobe2  [{name}]", r["lobe2"], b2, 8e-3)

# 4. Sampling-density independence (tanh asym): 1001-point vs 51-point curves
fa = lambda x: 0.5 * (1 - np.tanh(8 * (x - 0.45)))
fb = lambda x: 0.5 * (1 - np.tanh(6 * (x - 0.58)))
Vf, Vs = np.linspace(0, 1, 1001), np.linspace(0, 1, 51)
rf = snm.butterfly_lobes(Vf, fa(Vf), fb(Vf))
rs = snm.butterfly_lobes(Vs, fa(Vs), fb(Vs))
check("sampling independence: 1001-pt vs 51-pt SNM", rs["snm"], rf["snm"], 3e-3)

# 5. Swapping the two curves swaps the lobes
rsw = snm.butterfly_lobes(Vf, fb(Vf), fa(Vf))
check("swap curves: lobe1 <-> lobe2", rsw["lobe1"], rf["lobe2"], 0.5e-3)

# 6. Monostable (single crossing) -> SNM must be exactly 0
lin = 0.8 * (1 - Vf) + 0.1
r = snm.butterfly_lobes(Vf, lin, lin)
check("monostable (linear, gain -0.8): SNM = 0", r["snm"], 0.0, 1e-12)
fails += (r["bistable"])
lines.append(f"{'PASS' if not r['bistable'] else 'FAIL'}  monostable flagged bistable=False (got {r['bistable']})")

# 7. Reduced-swing curves (like a write / weak-read half cell whose output cannot reach the rail)
#    7a: B swing 0.6 V -> both lobes survive, the weak one is small: compare to brute force
#    7b: B swing 0.4 V -> single crossing, the cell is monostable: SNM must be exactly 0
a = ramp(Vc, 0.5, 0.05)
b = 0.6 * ramp(Vc, 0.5, 0.05)
r = snm.butterfly_lobes(Vc, a, b)
check("reduced swing 0.6 V: weak lobe vs brute force", r["lobe2"], snm.brute_force_lobe(Vc, a, b, lobe=2), 8e-3)
check("reduced swing 0.6 V: strong lobe vs brute force", r["lobe1"], snm.brute_force_lobe(Vc, a, b, lobe=1), 8e-3)
b = 0.4 * ramp(Vc, 0.5, 0.05)
r = snm.butterfly_lobes(Vc, a, b)
lines.append(f"INFO  reduced swing 0.4 V: lobe1={r['lobe1']*1e3:.2f} lobe2={r['lobe2']*1e3:.2f} mV bistable={r['bistable']} n_runs={r['n_runs']}")
check("reduced swing 0.4 V (monostable): SNM = 0", r["snm"], 0.0, 1e-12)
fails += r["bistable"]
lines.append(f"{'PASS' if not r['bistable'] else 'FAIL'}  reduced swing 0.4 V flagged bistable=False")
lines.append("NOTE  brute force is not compared for the monostable case: the open region it would measure is not an enclosed lobe.")

# 8. Tri-stable staircase inverter (5 crossings): data-state lobe is the OUTER lobe.
#    A: 1 for x<=0.2, ramp to 0.5 by 0.22, plateau 0.5 to 0.8, ramp to 0 by 0.82, 0 beyond.  B = mirror.
#    Inner lobe (between saddle and the middle analog state) is 0.28 V; the data-state (outer)
#    lobe is ~0.18 V (0.18 + a sub-mV ramp correction).  Brute force restricted to the outer corner.
Vs_ = np.linspace(0, 1, 2001)
stair = np.interp(Vs_, [0, 0.2, 0.22, 0.8, 0.82, 1.0], [1, 1, 0.5, 0.5, 0.0, 0.0])
r = snm.butterfly_lobes(Vs_, stair, stair)
bf = snm.brute_force_lobe(Vs_[::4], stair[::4], stair[::4], lobe=1, corner_box=(0.0, 0.1, 0.78, 1.0), grid=321)
check("staircase (tri-stable): outer lobe1 vs restricted brute force", r["lobe1"], bf, 6e-3)
check("staircase (tri-stable): outer lobe1 vs analytic ~0.1808", r["lobe1"], 0.1808, 2e-3)
fails += (not r["multistable"])
lines.append(f"{'PASS' if r['multistable'] else 'FAIL'}  staircase flagged multistable (n_crossings={r['n_crossings']})")
lines.append("NOTE  brute-force values are grid lower bounds (corner grid ~3 mV); e.g. the 0.6 V-swing case above "
             "gave 81.2 mV at grid 161 and 84.4 mV at grid 321 vs 86.4 mV from snm.py (converging from below).")

lines += ["", f"RESULT: {'ALL TESTS PASSED' if fails == 0 else str(fails) + ' FAILURE(S)'}"]
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text("\n".join(lines) + "\n")
print("\n".join(lines))
sys.exit(1 if fails else 0)
