"""
exp_a_bitcell.py - (a) the 6T bitcell: stored-state check, hold leakage and
inverter characteristics versus cell ratio beta and pull-up ratio gamma.

RESEARCH SIMULATION - UNCALIBRATED GENERIC MODEL - NOT SILICON DATA
Netlist template: netlists/cell6t_op.cir.tpl (+ netlists/cells.inc, snm_butterfly.cir.tpl).
Outputs: results/exp_a_bitcell.csv, results/exp_a_bitcell.svg
"""
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sramlib as S  # noqa: E402
from svgplot import Figure  # noqa: E402

EXP = "exp_a_bitcell"
VDD = 1.0
BETAS = [1.0, 1.5, 2.0, 2.5, 3.0]
GAMMAS = [0.5, 1.0, 1.5, 2.0]
DEFAULT = S.Cell()


def op_job(job):
    cell, state, tag, record = job
    vq, vqb = (0.0, VDD) if state == 0 else (VDD, 0.0)
    text = S.render("cell6t_op.cir.tpl", NAME=tag, VDD=S.fmt(VDD), CELLPARAMS=cell.params(), VQ=S.fmt(vq),
                    VQB=S.fmt(vqb), OUT=str((S.WORK / f"{tag}.dat").relative_to(S.ROOT)))
    _, d = S.run_ngspice(tag, text, exp=EXP, record=record)
    return d[0, 1:6]


def hold_vtc_metrics(cell, tag):
    """Inverter switching threshold (Vout=Vin) and max |gain| of the hold half-cell VTC."""
    v, a, b = S.vtc_sweep(tag, VDD, cell, "hold", EXP)
    g = np.gradient(a, v)
    k = np.nonzero((a[:-1] - v[:-1] > 0) & (a[1:] - v[1:] <= 0))[0][0]
    vm = v[k] + (a[k] - v[k]) / ((a[k] - v[k]) - (a[k + 1] - v[k + 1])) * (v[k + 1] - v[k])
    return float(vm), float(np.max(np.abs(g)))


def run():
    cases = [("beta", b, DEFAULT.with_(beta=b)) for b in BETAS] + \
            [("gamma", g, DEFAULT.with_(gamma=g)) for g in GAMMAS]
    jobs = []
    for i, (kind, val, cell) in enumerate(cases):
        for st in (0, 1):
            jobs.append((cell, st, f"a_op_{i}_{st}", i == 0 and st == 0))
    ops = S.run_parallel(op_job, jobs)
    vtcs = S.run_parallel(lambda ic: hold_vtc_metrics(ic[1][2], f"a_vtc_{ic[0]}"), list(enumerate(cases)))
    rows = []
    for i, (kind, val, cell) in enumerate(cases):
        s0, s1 = ops[2 * i], ops[2 * i + 1]
        # s = [vq, vqb, icore, ibl, iblb]; leakage in nA (supply + both bitlines)
        leak0 = (s0[2] + s0[3] + s0[4]) * 1e9
        leak1 = (s1[2] + s1[3] + s1[4]) * 1e9
        ok = (s0[0] < 0.05 * VDD and s0[1] > 0.95 * VDD and s1[0] > 0.95 * VDD and s1[1] < 0.05 * VDD)
        vm, gmax = vtcs[i]
        rows.append([kind, val, cell.beta, cell.gamma, cell.wpd * 1e9, cell.wpu * 1e9, cell.wax * 1e9,
                     s0[0], s0[1], s1[0], s1[1], leak0, leak1, int(ok), vm, gmax])
    hdr = ["sweep", "value", "beta", "gamma", "W_PD_nm", "W_PU_nm", "W_AX_nm", "state0_Q_V", "state0_QB_V",
           "state1_Q_V", "state1_QB_V", "hold_leak_state0_nA", "hold_leak_state1_nA", "both_states_stable",
           "inv_Vm_V", "inv_max_gain"]
    S.write_csv(S.RESULTS / "exp_a_bitcell.csv", hdr, rows)
    # plot: leakage and inverter threshold vs beta / gamma
    fig = Figure("(a) 6T bitcell: hold leakage and inverter threshold", 1, 2, 440, 300,
                 f"Vdd = {VDD} V, WL = 0, BL = BLB = Vdd, W_AX = 100 nm, L = 45 nm; defaults beta = 2.0, gamma = 1.0")
    rb = [r for r in rows if r[0] == "beta"]
    rg = [r for r in rows if r[0] == "gamma"]
    ax = fig.axes(0, 0, "beta = W_PD / W_AX", "cell hold leakage, state Q=0 (nA)", "Leakage vs beta (gamma = 1.0)", legend=None)
    ax.line([r[1] for r in rb], [r[11] for r in rb], None, 0, marker=True)
    ax = fig.axes(0, 1, "ratio value (beta or gamma)", "inverter switching threshold Vm (V)", "Vm of hold half-cell VTC", legend="br")
    ax.line([r[1] for r in rb], [r[14] for r in rb], "vs beta (gamma=1.0)", 0, marker=True)
    ax.line([r[1] for r in rg], [r[14] for r in rg], "vs gamma (beta=2.0)", 1, "6 3", marker=True)
    fig.save(S.RESULTS / "exp_a_bitcell.svg")
    md = ["| sweep | value | W_PD/W_PU/W_AX (nm) | Q,QB state-0 (V) | Q,QB state-1 (V) | both stable | hold leakage state-0 (nA, supply+BLs) | inverter Vm (V) | max inverter gain |",
          "|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r[0]} | {r[1]:g} | {r[4]:.0f}/{r[5]:.0f}/{r[6]:.0f} | {r[7]:.3f},{r[8]:.3f} | {r[9]:.3f},{r[10]:.3f} | "
                  f"{'yes' if r[13] else 'NO'} | {r[11]:.3f} | {r[14]:.3f} | {r[15]:.1f} |")
    allstable = all(r[13] for r in rows)
    headline = dict(all_cases_bistable=bool(allstable), default_hold_leak_nA=rows[2][11], default_inv_Vm_V=rows[2][14],
                    default_inv_gain=rows[2][15])
    S.update_summary_json("exp_a_bitcell", headline)
    return dict(summary=headline, md="\n".join(md))


if __name__ == "__main__":
    print(run()["md"])
