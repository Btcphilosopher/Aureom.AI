# SilicaFlux MemoryCore - SPICE research results summary

**RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA**

Every number below was produced by an ngspice run executed by `scripts/run_all.py` with the hand-written generic model in `models/generic_45nm_illustrative.lib` (SPICE Level 3, NOT calibrated to any process; transistor-level SPICE, NOT synthesizable RTL). Values are RELATIVE TRENDS ONLY; none is a silicon measurement and none may be quoted as one.

Tool versions: ngspice-42, Python 3.13.18, numpy 2.5.3. Temperature 27 C only; no process corners; no layout parasitics.

## Device-model sanity check (generic illustrative Level-3 model)

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

Hand-written SPICE Level-3 NMOS/PMOS card (models/generic_45nm_illustrative.lib). Vth here is the constant-current value, not the model parameter vto (0.60 V).

| quantity (W=1 um, L=45 nm, 27 C) | NMOS | PMOS |
|---|---|---|
| Ion at Vgs=Vds=1.0 V (uA/um) | 748 | 506 |
| Ioff at Vgs=0, Vds=1.0 V (nA/um) | 0.35 | 0.137 |
| Vth (constant current 100 nA*W/L, Vds=1.0 V) (V) | 0.237 | 0.262 |
| DIBL (mV/V, Vds 0.05 -> 1.0 V, NMOS) | 125 | - |
| sub-threshold swing 10-100 nA/um (mV/dec, NMOS) | 62 | - |
| series-gate-source vs model-vto shift, max rel. error over sweep (dVth=30 mV) | 0.00e+00 | 0.00e+00 |

## (a) 6T bitcell: stored states, hold leakage, inverter threshold vs beta/gamma

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

Default cell: W_AX = 100 nm, W_PD = beta*W_AX (default beta = 2), W_PU = gamma*W_AX (default gamma = 1), L = 45 nm, Vdd = 1.0 V, WL = 0, BL = BLB = Vdd. Leakage includes both bitline sources (access-transistor leakage) and is NOT calibrated (no gate/junction leakage in the model).

| sweep | value | W_PD/W_PU/W_AX (nm) | Q,QB state-0 (V) | Q,QB state-1 (V) | both stable | hold leakage state-0 (nA, supply+BLs) | inverter Vm (V) | max inverter gain |
|---|---|---|---|---|---|---|---|---|
| beta | 1 | 100/100/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.072 | 0.466 | 6.3 |
| beta | 1.5 | 150/100/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.089 | 0.441 | 6.5 |
| beta | 2 | 200/100/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.107 | 0.425 | 6.6 |
| beta | 2.5 | 250/100/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.125 | 0.414 | 6.8 |
| beta | 3 | 300/100/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.142 | 0.406 | 6.9 |
| gamma | 0.5 | 200/50/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.100 | 0.394 | 7.1 |
| gamma | 1 | 200/100/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.107 | 0.425 | 6.6 |
| gamma | 1.5 | 200/150/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.114 | 0.448 | 6.4 |
| gamma | 2 | 200/200/100 | 0.000,1.000 | 1.000,0.000 | yes | 0.121 | 0.466 | 6.3 |

## (b) Static noise margin: hold / read butterflies; READ SNM vs beta

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

READ SNM = butterfly with WL = Vdd and BL = BLB = Vdd (ideal precharge); HOLD SNM = WL = 0. SNM = side of the largest square inscribed in the smaller lobe (scripts/snm.py, unit-tested). beta = 0.25 .. 0.75 are EXTRA points below the requested 1.0 .. 3.0 range. 'Saddle Q level' = Q at the metastable crossing next to the stored '0' state (the level the '0' node must exceed to lose the state, statically).

| beta | hold SNM (mV) | READ SNM (mV) | read lobe 1 / lobe 2 (mV) | saddle Q level during read (V) | cross-check: READ SNM by noise injection (mV) |
|---|---|---|---|---|---|
| 0.25 | 352.2 | 0.0 | 0.0 / 0.0 | - | 0.0 |
| 0.5 | 365.2 | 10.0 | 10.0 / 10.0 | 0.458 | 10.0 |
| 0.75 | 363.5 | 54.1 | 54.1 / 54.1 | 0.562 | 54.0 |
| 1 | 359.0 | 91.8 | 91.8 / 91.8 | 0.542 | 91.5 |
| 1.25 | 354.0 | 124.1 | 124.1 / 124.1 | 0.526 | 124.0 |
| 1.5 | 349.2 | 152.1 | 152.1 / 152.1 | 0.513 | 152.0 |
| 1.75 | 344.7 | 176.3 | 176.3 / 176.3 | 0.501 | 176.0 |
| 2 | 340.6 | 197.4 | 197.4 / 197.4 | 0.492 | 197.0 |
| 2.25 | 337.1 | 215.6 | 215.6 / 215.6 | 0.483 | 215.5 |
| 2.5 | 334.0 | 231.1 | 231.1 / 231.1 | 0.476 | 231.0 |
| 2.75 | 331.4 | 243.8 | 243.8 / 243.8 | 0.469 | 243.5 |
| 3 | 329.1 | 253.2 | 253.2 / 253.2 | 0.463 | 253.0 |

Independent cross-check: the same cell simulated as a full 6T cell with a static noise voltage injected in series with both inverter inputs (swept in 0.5 mV steps until the stored state vanishes) agrees with the inscribed-square values to within 0.47 mV over all 24 beta/gamma cases (hold and read, both stored states; the noise sweep has 0.5 mV granularity).

READ SNM (mV) on a beta x gamma grid:

| gamma \ beta | 0.5 | 1 | 1.5 | 2 | 2.5 | 3 |
|---|---|---|---|---|---|---|
| 0.5 | 0.0 | 68.0 | 137.1 | 187.2 | 222.3 | 241.4 |
| 1 | 10.0 | 91.8 | 152.1 | 197.4 | 231.1 | 253.2 |
| 1.5 | 32.6 | 109.6 | 164.9 | 206.7 | 238.4 | 260.5 |

## (c) Read transient: bitline differential, read current, read disturb

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

Stored Q = 0. Precharge PMOS releases at 0.1 ns, WL rises at 0.2 ns (20 ps edges) and stays high 1.5 ns. Times are measured from the WL 50% crossing. dV_BL = V(BLB) - V(BL). Cbl is a LUMPED capacitor per bitline (a parameter, not extracted).

Bitline-capacitance sweep (default cell, beta = 2):

| Cbl (fF) | peak read current (uA) | dV_BL @100 ps (mV) | @200 ps | @500 ps | time to 50 mV (ps) | time to 100 mV (ps) | peak V(Q) (V) |
|---|---|---|---|---|---|---|---|
| 10 | 68.4 | 587.0 | 1022.7 | 1042.6 | 10 | 18 | 0.040 |
| 25 | 69.0 | 254.9 | 492.0 | 1011.0 | 21 | 40 | 0.040 |
| 50 | 69.2 | 131.0 | 259.1 | 606.4 | 39 | 77 | 0.040 |
| 100 | 69.2 | 66.4 | 133.0 | 322.9 | 76 | 150 | 0.040 |
| 200 | 69.3 | 33.4 | 67.4 | 166.7 | 149 | 297 | 0.040 |

Read-disturb vs beta (gamma = 1, W_AX = 100 nm). Outcome is classified just before WL falls: 'STATE LOST' = Q and QB within 0.1 Vdd of each other (symmetric analog state, cell statically monostable under read; the state it relaxes to after WL falls is decided by numerical noise and is NOT reported as a flip direction); 'retained' = original state intact:

| beta | static READ SNM (mV) | peak V(Q), Cbl=50 fF (V) | outcome (Cbl=50 fF) | peak V(Q), BL clamped (V) | outcome (BL clamped) | peak read current, clamped (uA) |
|---|---|---|---|---|---|---|
| 0.3 | 0.0 | 0.610 | STATE LOST | 0.616 | STATE LOST | 30.8 |
| 0.4 | 0.0 | 0.580 | retained | 0.601 | STATE LOST | 35.7 |
| 0.5 | 10.0 | 0.408 | retained | 0.412 | retained | 40.2 |
| 0.6 | 28.5 | 0.355 | retained | 0.359 | retained | 44.4 |
| 0.8 | 62.2 | 0.266 | retained | 0.268 | retained | 51.8 |
| 1 | 91.8 | 0.193 | retained | 0.196 | retained | 57.8 |
| 1.5 | 152.1 | 0.063 | retained | 0.063 | retained | 66.6 |
| 2 | 197.4 | 0.040 | retained | 0.040 | retained | 69.3 |
| 3 | 253.2 | 0.023 | retained | 0.023 | retained | 71.4 |

## (d) Write: static write margins and write-transient flip time vs gamma

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

Stored Q = 1 written to 0. Static: WL-sweep trip = smallest WL for which the stored-state butterfly lobe has vanished (BL = 0, BLB = Vdd); BL-sweep trip = largest BL (WL = Vdd, BLB = Vdd) for which it has vanished. Transient: BL driven low through 500 ohm, Cbl = 50 fF, WL = Vdd for 2 ns; flip time = Q = QB crossing relative to WL 50%.

| gamma | WL-sweep trip (V) | WM_WL = Vdd - trip (mV) | BL-sweep trip = WM_BL (mV) | transient at WL=Vdd | flip time Q=QB (ps) | Q below 10% Vdd (ps) |
|---|---|---|---|---|---|---|
| 0.4 | 0.497 | 502 | 530 | flipped | 13 | 17 |
| 0.6 | 0.562 | 438 | 470 | flipped | 15 | 19 |
| 0.8 | 0.625 | 375 | 415 | flipped | 17 | 22 |
| 1 | 0.682 | 318 | 355 | flipped | 19 | 24 |
| 1.25 | 0.750 | 250 | 290 | flipped | 23 | 28 |
| 1.5 | 0.815 | 185 | 220 | flipped | 28 | 33 |
| 2 | 0.925 | 75 | 95 | flipped | 55 | 62 |
| 2.5 | - | - | - | **NO FLIP in 2 ns** | - | - |
| 3 | - | - | - | **NO FLIP in 2 ns** | - | - |

Static-vs-transient consistency, default cell (WL pulse amplitude relative to the static WL-sweep trip, 5 ns pulse):

| V_WL - trip (mV) | V_WL (V) | flipped within 5 ns | flip time (ps) |
|---|---|---|---|
| -30 | 0.652 | no | - |
| -10 | 0.672 | no | - |
| +10 | 0.693 | no | - |
| +30 | 0.713 | yes | 115 |
| +60 | 0.742 | yes | 65 |

## (e) Latch sense amplifier: minimum resolvable differential and offset

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

Bank of independent latch SAs (cross-coupled pair + footer + PMOS isolation), SAE rises at 100 ps; dV = V(blt) - V(blc) held by ideal sources until isolation. Offset d = |Vth|(MN1) - |Vth|(MN2) applied as +d/2 / -d/2. 'min dV correct' = smallest |dV| such that every grid point with |dV'| >= it resolves with the correct sign to |V(so)-V(sob)| >= 0.8 Vdd within the stated window after SAE 50% (grid step 2 mV).

| mismatch pair | injected offset d (mV) | trip point dV (mV, +-1) | min dV correct, 40 ps window (mV, +-2) | min dV correct, 60 ps window (mV, +-2) | min dV correct, 100 ps window (mV, +-2) |
|---|---|---|---|---|---|
| NMOS | -60 | +60 | 89 | 65 | 61 |
| NMOS | -40 | +40 | 71 | 45 | 41 |
| NMOS | -20 | +20 | 51 | 25 | 21 |
| NMOS | +0 | +0 | 33 | 5 | 1 |
| NMOS | +20 | -20 | 51 | 25 | 21 |
| NMOS | +40 | -40 | 71 | 45 | 41 |
| NMOS | +60 | -60 | 89 | 65 | 61 |
| PMOS | -40 | -8 | 41 | 13 | 9 |
| PMOS | +40 | +8 | 41 | 13 | 9 |

Resolution time (offset = 0, NMOS pair): see results/exp_e_senseamp_tres.csv; e.g. dV = 20 mV -> 45 ps, dV = 6 mV -> 59 ps, dV = 2 mV -> 73 ps (from SAE 50% to |V(so)-V(sob)| = 0.8 Vdd).

Derived (not a separate simulation): time after WL 50% for the exp_c bitline differential (default cell, Cbl = 50 fF) to reach the guaranteed-correct dV (60 ps window) of each NMOS offset:

| offset d (mV) | needed dV (mV) | time for BL differential to reach it (ps) |
|---|---|---|
| -60 | 65 | 50 |
| -40 | 45 | 36 |
| -20 | 25 | 21 |
| +0 | 5 | 6 |
| +20 | 25 | 21 |
| +40 | 45 | 36 |
| +60 | 65 | 50 |

## (f) Supply-voltage sensitivity (1.1 ... 0.5 V, plus 0.4 / 0.3 V extras)

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

Same default cell and same model at every Vdd (no Vth/sizing adjustment, 27 C). Vdd = 0.4 and 0.3 V are EXTRA points beyond the requested list. Read-disturb transients: BL clamped to Vdd, WL high 3 ns. Outcome 'STATE LOST' as defined in (c).

| Vdd (V) | hold SNM (mV) | READ SNM beta=2 (mV) | read SNM/Vdd (beta=2) | READ SNM beta=1/0.6/0.4 (mV) | WM_WL (mV) | WM_BL (mV) | write flip time (ps) | peak V(Q) beta=2/1/0.6/0.4 (V) | outcome beta=2/1/0.6/0.4 |
|---|---|---|---|---|---|---|---|---|---|
| 1.1 | 355.5 | 205.1 | 0.186 | 87.4 / 18.0 / 0.0 | 363 | 402 | 18 | 0.043 / 0.225 / 0.419 / 0.680 | retained / retained / retained / STATE LOST |
| 1 | 340.6 | 197.4 | 0.197 | 91.8 / 28.5 / 0.0 | 318 | 355 | 19 | 0.040 / 0.196 / 0.359 / 0.601 | retained / retained / retained / STATE LOST |
| 0.9 | 325.3 | 188.5 | 0.209 | 96.8 / 40.3 / 5.3 | 275 | 311 | 20 | 0.036 / 0.168 / 0.301 / 0.392 | retained / retained / retained / retained |
| 0.8 | 310.3 | 177.1 | 0.221 | 103.1 / 54.4 / 23.0 | 234 | 268 | 22 | 0.034 / 0.141 / 0.250 / 0.316 | retained / retained / retained / retained |
| 0.7 | 285.3 | 154.9 | 0.221 | 103.3 / 66.6 / 42.3 | 194 | 224 | 24 | 0.031 / 0.114 / 0.199 / 0.249 | retained / retained / retained / retained |
| 0.6 | 239.6 | 120.0 | 0.200 | 89.7 / 70.0 / 57.9 | 154 | 177 | 28 | 0.028 / 0.089 / 0.148 / 0.183 | retained / retained / retained / retained |
| 0.5 | 195.8 | 83.8 | 0.168 | 75.6 / 71.8 / 70.8 | 109 | 128 | 38 | 0.025 / 0.065 / 0.098 / 0.118 | retained / retained / retained / retained |
| 0.4 (extra) | 152.0 | 62.1 | 0.155 | 58.2 / 54.9 / 52.0 | 73 | 108 | 129 | 0.026 / 0.042 / 0.056 / 0.071 | retained / retained / retained / retained |
| 0.3 (extra) | 108.2 | 44.1 | 0.147 | 40.3 / 37.1 / 34.3 | 61 | 84 | no flip in 3 ns | 0.024 / 0.031 / 0.039 / 0.048 | retained / retained / retained / retained |

## (g) Monte Carlo of READ/hold SNM under Pelgrom Vth mismatch

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

Gaussian per-transistor Vth shifts with sigma = A_vt/sqrt(W*L), A_vt = 2.5 mV*um (ILLUSTRATIVE assumption). Rows marked extra are additional operating points. Failure = SNM = 0 (statically monostable); the results below cannot resolve failure fractions below ~1e-3.

N = 1000 samples per row, seeds 20240607+case index, A_vt = 2.5 mV*um (illustrative); sigma(Vth) = 26.4 mV (PD, 200 nm, beta 2), 37.3 mV (PU/AX, 100 nm), 37.3 mV (PD, 100 nm, beta 1); L = 45 nm.

| Vdd (V) | beta | quantity | zero-mismatch (mV) | mean (mV) | sigma (mV) | mu/sigma | min (mV) | failures (SNM=0) / N | Wilson 95% interval of fail fraction | N below 20 mV | skew | excess kurt. |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2 | READ SNM | 197.4 | 182.6 | 13.8 | 13.25 | 120.8 | 0/1000 | [0.0000, 0.0038] | 0 | -0.53 | +0.48 |
| 1 | 2 | HOLD SNM | 340.6 | 328.2 | 14.6 | 22.54 | 284.4 | 0/1000 | [0.0000, 0.0038] | 0 | -0.34 | -0.25 |
| 0.7 | 2 | READ SNM | 154.9 | 139.1 | 15.6 | 8.93 | 77.7 | 0/1000 | [0.0000, 0.0038] | 0 | -0.51 | +0.32 |
| 0.7 | 2 | HOLD SNM | 285.3 | 267.5 | 13.1 | 20.36 | 206.6 | 0/1000 | [0.0000, 0.0038] | 0 | -0.86 | +0.85 |
| 0.5 (extra) | 2 | READ SNM | 83.8 | 68.3 | 17.3 | 3.96 | 0.0 | 1/1000 | [0.0002, 0.0056] | 8 | -0.28 | +0.21 |
| 0.5 (extra) | 2 | HOLD SNM | 195.8 | 181.0 | 13.4 | 13.48 | 124.2 | 0/1000 | [0.0000, 0.0038] | 0 | -0.71 | +0.57 |
| 1 (extra weak cell) | 1 | READ SNM | 91.8 | 72.6 | 19.5 | 3.72 | 4.3 | 0/1000 | [0.0000, 0.0038] | 9 | -0.45 | +0.12 |
| 1 (extra weak cell) | 1 | HOLD SNM | 359.0 | 342.8 | 14.5 | 23.62 | 290.6 | 0/1000 | [0.0000, 0.0038] | 0 | -0.49 | -0.01 |
| 0.7 (extra weak cell) | 1 | READ SNM | 103.3 | 83.0 | 20.2 | 4.11 | 5.5 | 0/1000 | [0.0000, 0.0038] | 3 | -0.39 | +0.27 |
| 0.7 (extra weak cell) | 1 | HOLD SNM | 290.5 | 268.1 | 14.3 | 18.70 | 210.3 | 0/1000 | [0.0000, 0.0038] | 0 | -0.78 | +0.38 |

Consistency check of the batched-netlist trick: 10 samples re-simulated one cell per ngspice run differ from the batch result by at most 0.0005 mV.

Illustrative Gaussian extrapolation of READ SNM (uses only mean and sigma; **NOT credible in the tails**: with N = 1000 the smallest non-zero failure fraction that can be resolved is ~1/N = 1e-03, and the empirical lower tails depart from Gaussian):

| Vdd (V) | beta | mu/sigma | Gaussian-implied P(SNM<0) (illustrative extrapolation) | observed failures / N | empirical 1% quantile (mV) | Gaussian 1% quantile (mV) | empirical 0.1% quantile (mV) | Gaussian 0.1% quantile (mV) |
|---|---|---|---|---|---|---|---|---|
| 1 | 2 | 13.25 | 2.33e-40 | 0/1000 | 146.2 | 150.5 | 134.1 | 140.0 |
| 0.7 | 2 | 8.93 | 2.16e-19 | 0/1000 | 98.4 | 102.9 | 79.3 | 91.0 |
| 0.5 | 2 | 3.96 | 3.79e-05 | 1/1000 | 26.2 | 28.1 | 4.5 | 15.0 |
| 1 | 1 | 3.72 | 9.81e-05 | 0/1000 | 20.8 | 27.3 | 9.5 | 12.4 |
| 0.7 | 1 | 4.11 | 1.99e-05 | 0/1000 | 30.9 | 36.0 | 9.0 | 20.6 |

## Unit tests of the SNM algorithm

_RESEARCH SIMULATION – UNCALIBRATED GENERIC MODEL – NOT SILICON DATA_

See `results/snm_unit_tests.txt` (synthetic curves, analytic + brute-force cross-checks).
