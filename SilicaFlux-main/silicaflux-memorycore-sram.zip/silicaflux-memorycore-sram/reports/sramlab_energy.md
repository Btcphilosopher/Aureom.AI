# SilicaFlux MemoryCore SRAM - energy / power MODEL (ASSUMED parameters, not a measurement)

> **READ THIS FIRST.** The repository contains **no Liberty, SPICE or characterisation power data for any SRAM macro** (physical/asic_readiness.md: Liberty and SPICE views are ABSENT for the SKY130, IHP SG13G2 and GF180MCU macros; the sibling PowerFabric report states that the IHP SRAM Liberty gives 0 W). Every absolute energy and power below is computed from the ASSUMED parameters of `power/params_assumed.json` (each entry: *ASSUMPTION - not from any process; replace with Liberty/characterised values*). They fix the order of magnitude of the illustrations and nothing else. **What can be trusted are the access counts (from the validated cycle model, identical to the RTL simulation) and the parameter-free ratios / brackets in section 1, which are derived before any assumed number is used.** Nothing here is a silicon measurement; no process is implied.

Provenance tags: `RTL-SIMULATION` (cycle counts of the benchmark runs), `MODEL` (sramlab cycle model: access counts, bank occupancy), `ANALYTICAL` (formulas), `ASSUMED-PARAMETER` (params_assumed.json). A number that depends on an `ASSUMED-PARAMETER` is marked **(assumed)**.

## 1. Relative results first (parameter-free or bracketed for ANY parameter values)

| quantity | value | status | why |
|---|---|---|---|
| ECC stored bits per line | 137 / 128 = 1.0703 | exact (RTL SECDED(137,128)) | every bit-proportional energy and the leakage grow by this factor (ratio of two RTL widths) |
| ECC partial write: array accesses | 2 (read + write) vs 1 | exact (RTL) | bank busy READ_LATENCY+1 cycles; RTL-SIMULATION throughput of SEQ_WRITE_PART4 with ECC is ~0.5x (reports/sramlab_vs_rtl.md 3.2) |
| 4 B scalar load vs 16 B line load, energy per useful byte | 4.00 x | exact for this RTL (no sub-line array access) | same array access energy, 4x fewer useful bytes; a column-muxed macro would reduce it (not modelled) |
| Double vs single buffering, dynamic SRAM energy per MAC | 1.00 x | exact | identical access counts per tile |
| Double vs single buffering, TOTAL SRAM energy per MAC | between 0.690 and 1.000 | bracket for any parameters | lower end = all energy static (leakage/idle clock), upper end = all dynamic; the RTL cycles/tile ratio 78/113 sets the lower end |
| SRAM line accesses per MAC (tensor TB, PASSES=3) | 1.333 | exact (TB structure) | 4 line accesses (A,B,C read + C write) feed 4 MACs per pass line; DMA adds 1/PASSES |
| Bank conflicts / back-pressure | no dynamic energy | structural | a stalled request performs no array access; stalls only lengthen run time (static energy per byte grows with cycles) |

## 2. Sensitivity: which conclusions depend on the assumed parameters

One-at-a-time: each ASSUMED parameter x0.25, x0.5, x2, x4 (min..max over those 4 values per parameter, then the envelope over all parameters); random: all parameters jointly log-uniform in [0.25, 4] x nominal (300 samples, 5th..95th percentile). ASSUMED-PARAMETER results throughout.

| conclusion / metric | nominal (assumed) | one-at-a-time envelope | random 5-95 % | robust? |
|---|---|---|---|---|
| ECC read energy overhead [%] | 12.5 | 7.44 .. 32.7 | 6.66 .. 31.8 | range wide |
| ECC full-line write energy overhead [%] | 9.08 | 6.83 .. 18.1 | 5.9 .. 20.5 | always > 0, < 25 % over the sweep |
| ECC partial write (RMW) energy / no-ECC byte-masked write | 3.71 | 2.39 .. 6.88 | 2.29 .. 6.35 | > 2 over the whole sweep (min 2.39) |
| write / read energy (no ECC) | 1.34 | 0.438 .. 4.45 | 0.356 .. 4.8 | assumed-dependent |
| scalar 4 B vs 16 B line, energy per useful byte | 4 | 4 .. 4 | 4 .. 4 | parameter-free |
| double / single buffer, energy per MAC | 0.976 | 0.919 .. 0.994 | 0.932 .. 0.995 | always in [0.69, 1] (bracket) |
| static share of tensor energy (single buffer) | 0.0555 | 0.0151 .. 0.189 | 0.0118 .. 0.163 | assumed-dependent |
| tensor SRAM energy per MAC, double buffer [pJ] | 24.1 | 17.7 .. 49.7 | 15 .. 55 | assumed-dependent |
| tensor energy per MAC, ECC / no-ECC | 1.11 | 1.08 .. 1.21 | 1.07 .. 1.21 | assumed-dependent |
| leakage share of total energy, saturated random reads, 64 KiB | 0.00633 | 0.00159 .. 0.0248 | 0.000719 .. 0.0405 | dynamic dominates for every swept value (max 2.5 %), but leakage would equal dynamic at ~157x the assumed leak/bit - far outside the swept x0.25..x4 range, so no real leakage conclusion can be drawn |
| energy per useful byte, saturated random 16 B reads [pJ] | 1.03 | 0.55 .. 2.95 | 0.554 .. 2.76 | assumed-dependent |

Parameters that move each conclusion the most (one-at-a-time spread relative to nominal):

| metric | top-3 parameters (metric range over x0.25..x4) |
|---|---|
| ECC partial write (RMW) energy / no-ECC byte-masked write | e_rd_bit_fj (2.92..6.88), e_halfsel_bit_fj (2.39..4.31), e_wl_bit_fj (3.15..3.96) |
| ECC read energy overhead [%] | e_ecc_dec_pj (7.44..32.7), e_rd_bit_fj (8.81..18.3), e_dec_fixed_pj (9.58..13.5) |
| double / single buffer, energy per MAC | e_idle_clk_pj_per_bank_cycle (0.919..0.994), e_rd_bit_fj (0.968..0.988), e_wr_bit_fj (0.969..0.988) |
| leakage share of total energy, saturated random reads, 64 KiB | clock_mhz (0.00159..0.0248), leak_pw_per_bit (0.00159..0.0248), e_rd_bit_fj (0.00221..0.0119) |
| tensor SRAM energy per MAC, double buffer [pJ] | e_rd_bit_fj (17.7..49.7), e_wr_bit_fj (18.3..47.1), e_wl_bit_fj (22.2..31.8) |

**Reading.** Robust for any parameter values: ordering and sign statements (ECC adds energy; a scalar load costs 4x per useful byte; double buffering never increases energy per MAC and can reduce it by at most the cycles ratio; an ECC partial write costs two array accesses and, with any swept parameters, more than twice a byte-masked non-ECC write). Parameter-dependent: the absolute pJ, the write/read ratio, the ECC percentage overheads (they follow the fixed-vs-bit-proportional split of the assumed read energy), and the static (leakage + idle clock) share: it is small for saturated traffic at the assumed values and grows with idle time, but its true size needs characterised leakage - no leakage conclusion may be drawn from this model.

## 3. Absolute illustrations at the NOMINAL assumed parameters (ASSUMED-PARAMETER x MODEL; order of magnitude only)

### 3.1 Energy per bank access (pJ, assumed)

| DEPTH (rows/bank) | ECC | columns | read pJ | full-line write pJ | partial write pJ |
|---|---|---|---|---|---|
| 256 | 0 | 128 | 14.86 | 19.98 | 10.38 (4 B masked) |
| 256 | 1 | 137 | 16.71 | 21.80 | 38.51 (RMW) |
| 1024 | 0 | 128 | 15.16 | 20.28 | 10.68 (4 B masked) |
| 1024 | 1 | 137 | 17.02 | 22.10 | 39.11 (RMW) |

### 3.2 Standby / leakage power (assumed)

| DEPTH | ECC | stored bits (4 banks) | leakage [uW] | leakage + idle clock [uW] at 100 MHz |
|---|---|---|---|---|
| 256 | 0 | 131072 | 6.82 | 166.82 |
| 256 | 1 | 140288 | 7.29 | 167.29 |
| 1024 | 0 | 524288 | 27.26 | 187.26 |
| 1024 | 1 | 561152 | 29.18 | 189.18 |
| 4096 | 0 | 2097152 | 109.05 | 269.05 |
| 4096 | 1 | 2244608 | 116.72 | 276.72 |

Scrub (RTL: one step per SCRUB_WAIT = 64 idle cycles per bank): 17.0 pJ per clean step, 39.1 pJ when a corrected line is written back, at most 1.5 % extra bank accesses (~26 uW per bank at the assumed clock). Init at reset (INIT_ON_RESET, ECC 4 banks x 1024 rows): 90.5 nJ once, 1024 cycles. (all assumed)

### 3.3 Benchmark patterns: energy per USEFUL byte (MODEL access counts from the validated model; energies assumed)

| pattern | ECC | cycles (RTL-validated MODEL) | array reads | full writes | partial writes | useful bytes at the array | pJ/B dynamic (assumed) | pJ/B total (assumed) | leakage share (assumed) | avg power mW (assumed) |
|---|---|---|---|---|---|---|---|---|---|---|
| SEQ_SCALAR4 | 0 | 1002 | 4000 | 0 | 0 | 16000 | 3.715 | 3.969 | 0.11 % | 6.338 |
| SEQ_LINE | 0 | 1005 | 4000 | 0 | 0 | 64000 | 0.929 | 0.992 | 0.11 % | 6.320 |
| OWN_BANK | 0 | 1002 | 4000 | 0 | 0 | 64000 | 0.929 | 0.992 | 0.11 % | 6.338 |
| SAME_BANK | 0 | 4002 | 4000 | 0 | 0 | 64000 | 0.929 | 1.071 | 0.40 % | 1.712 |
| RANDOM_LINE | 0 | 1550 | 4000 | 0 | 0 | 64000 | 0.929 | 1.007 | 0.16 % | 4.156 |
| RANDOM_RW | 0 | 1534 | 2011 | 1989 | 0 | 64000 | 1.088 | 1.165 | 0.14 % | 4.862 |
| SEQ_WRITE_FULL | 0 | 1005 | 0 | 4000 | 0 | 64000 | 1.249 | 1.312 | 0.08 % | 8.358 |
| SEQ_WRITE_PART4 | 0 | 1005 | 0 | 0 | 4000 | 16000 | 2.595 | 2.850 | 0.15 % | 4.537 |
| RANDOM_PART4 | 0 | 1534 | 2011 | 0 | 1989 | 16000 | 3.158 | 3.468 | 0.19 % | 3.617 |
| SEQ_SCALAR4 | 1 | 1003 | 4000 | 0 | 0 | 16000 | 4.179 | 4.434 | 0.10 % | 7.073 |
| SEQ_LINE | 1 | 1006 | 4000 | 0 | 0 | 64000 | 1.045 | 1.108 | 0.10 % | 7.052 |
| OWN_BANK | 1 | 1003 | 4000 | 0 | 0 | 64000 | 1.045 | 1.108 | 0.10 % | 7.073 |
| SAME_BANK | 1 | 4003 | 4000 | 0 | 0 | 64000 | 1.045 | 1.187 | 0.38 % | 1.897 |
| RANDOM_LINE | 1 | 1551 | 4000 | 0 | 0 | 64000 | 1.045 | 1.123 | 0.16 % | 4.633 |
| RANDOM_RW | 1 | 1535 | 2011 | 1989 | 0 | 64000 | 1.203 | 1.280 | 0.14 % | 5.338 |
| SEQ_WRITE_FULL | 1 | 1006 | 0 | 4000 | 0 | 64000 | 1.362 | 1.426 | 0.08 % | 9.072 |
| SEQ_WRITE_PART4 | 1 | 2005 | 0 | 0 | 4000 | 16000 | 9.628 | 9.887 | 0.09 % | 7.890 |
| RANDOM_PART4 | 1 | 2217 | 2011 | 0 | 1989 | 16000 | 6.888 | 7.220 | 0.14 % | 5.211 |
| SEQ_SCALAR4 byte-stride (ALIGN_MODE=1, model-only, 3 of 4 rejected) | 0 | 1005 | 1000 | 0 | 0 | 4000 | 3.715 | 4.509 | 0.38 % | 1.795 |

Useful bytes count only requests that reached an array. Pattern 0 (SEQ_SCALAR4) is the line-aligned scalar workload of the current TB; the extra row `ALIGN_MODE=1 byte-stride` is the MODEL-ONLY original byte-strided pattern of the first TB revision (3 of 4 requests rejected, no array energy), kept to document that rejected requests cost no array energy.

### 3.4 ECC overhead per pattern (ratio ECC / no-ECC)

| pattern | dynamic pJ/B ratio (assumed) | total pJ/B ratio (assumed) | cycles ratio (MODEL = RTL) | array accesses ratio (exact) |
|---|---|---|---|---|
| SEQ_SCALAR4 | 1.125 | 1.117 | 1.001 | 1.00 |
| SEQ_LINE | 1.125 | 1.117 | 1.001 | 1.00 |
| OWN_BANK | 1.125 | 1.117 | 1.001 | 1.00 |
| SAME_BANK | 1.125 | 1.109 | 1.000 | 1.00 |
| RANDOM_LINE | 1.125 | 1.115 | 1.001 | 1.00 |
| RANDOM_RW | 1.105 | 1.099 | 1.001 | 1.00 |
| SEQ_WRITE_FULL | 1.091 | 1.087 | 1.001 | 1.00 |
| SEQ_WRITE_PART4 | 3.710 | 3.469 | 1.995 | 2.00 |
| RANDOM_PART4 | 2.181 | 2.082 | 1.445 | 1.50 |

### 3.5 Energy per useful tensor operation (one operation = one 32-bit multiply-accumulate; SRAM subsystem only - the MAC datapath is not included)

Per tile (tensor TB): TensorCore per pass and line k reads A[k], B[k], C[k] and writes C[k]; the DMA fill writes 3N lines and the drain reads N lines. N=8, PASSES=3: 80 reads + 48 writes = 128 line accesses for 96 MACs (1.333 accesses/MAC, exact). Cycles per tile are the RTL-SIMULATION values.

| tensor config | RTL cycles/tile | RTL conflict cycles | dynamic pJ/MAC (assumed) | total pJ/MAC (assumed) | static share (assumed) |
|---|---|---|---|---|---|
| nbuf2_skew1 | 78 | 62 | 21.97 | 24.09 | 3.2 % |
| nbuf1_skew1 | 113 | 0 | 21.97 | 24.68 | 5.6 % |
| nbuf2_skew0 | 82 | 114 | 21.97 | 24.15 | 3.5 % |
| nbuf1_skew0 | 119 | 48 | 21.97 | 24.78 | 5.9 % |
| nbuf2_extra16 | 125 | 25 | 21.97 | 24.88 | 6.3 % |
| nbuf1_extra16 | 161 | 0 | 21.97 | 25.49 | 8.5 % |
| nbuf2_extra48 | 221 | 25 | 21.97 | 26.50 | 12.0 % |
| nbuf1_extra48 | 257 | 0 | 21.97 | 27.10 | 14.0 % |
| nbuf2_ecc | 85 | 64 | 24.43 | 26.66 | 3.4 % |
| nbuf2_n16 | 130 | 97 | 21.97 | 23.87 | 2.4 % |
| nbuf1_n16 | 193 | 0 | 21.97 | 24.40 | 4.5 % |

Single vs double buffering: dynamic pJ/MAC identical (21.97); total pJ/MAC 24.68 -> 24.09 (x0.9761, inside the parameter-free bracket [0.690, 1] of section 1; assumed). At the nominal assumed values the static share is tiny, so the saving is tiny - with higher assumed leakage it approaches the cycle ratio. The honest statement is the bracket, not the nominal value.

## 4. Power / thermal integration in the repository (format-level hand-off only)

Inspected READ-ONLY (docs/READMEs extracted into build/sramlab_work; no code from the archives was executed):

* **`silicaflux-thermallab-0.1.0` (inside `SilicaFlux ThermalLab (1).zip`)** documents a per-block power input: a block CSV/JSON with required fields `name, zone, x0_um, y0_um, x1_um, y1_um, power_w` and optional `kind, layer, provenance, source` (README 'Plugging in real data'; `power_mapping.blocks_from_records`, `load_blocks_json`); `provenance` must be one of its DataStatus values (we use `assumed_engineering_parameter`). Its own docs state that it ships DEMONSTRATION inputs only.
* **`silicaflux-powerfabric-p36.zip` (PowerGrid-like)** consumes extracted-grid exports (`nodes.csv`: node,x_um,y_um,load_current_a,voltage_v; `resistors.csv`) - per-node currents on a power-grid network, not per-block power; its SRAM loads are 'accesses / cycle x access energy x f + leakage' from a PackageTwin `power_model.json` (our model has the same structure), because the IHP SRAM Liberty gives 0 W. Mapping bank power to PowerGrid nodes needs the extracted grid and was **not done**.

`power/thermal_input_example.json` is written in the ThermalLab block-JSON schema from this model's per-bank average power (workload: saturated random 16 B reads, floorplan C1: 4 banks x 1024 rows x 128 b), with bank rectangles taken from `physical/floorplan_C1_sky130.json` (GENERATED GEOMETRY, not a routed layout). All power values are **MODEL x ASSUMED-PARAMETER**. **This is a FORMAT-LEVEL hand-off: ThermalLab was NOT executed (no co-simulation was run).** The JSON was checked only against the documented required-field list by this tool's own validator.

| workload scenario | per-bank average power [mW] (assumed) | controller [mW] (assumed) |
|---|---|---|
| idle | ['0.047', '0.047', '0.047', '0.047'] | 0.000 |
| seq_line_saturated | ['1.515', '1.515', '1.515', '1.515'] | 0.398 |
| random_read_saturated | ['1.000', '0.989', '1.009', '0.999'] | 0.258 |
| random_rw_saturated | ['1.179', '1.157', '1.160', '1.204'] | 0.261 |

## 5. What would make these numbers real

Replace `params_assumed.json` by characterised values (per-bit read/write energy, decoder energy, leakage, ECC logic from synthesis power reports) and re-run `python3 power/sram_energy.py`; the access counts and all ratios of section 1 stay valid, section 2 will then show how much the remaining uncertainty matters.

## 6. Assumed parameters used (all ASSUMPTION - not from any process; replace with Liberty/characterised values)

| parameter | value | unit | meaning |
|---|---|---|---|
| clock_mhz | 100.0 | MHz | clock frequency used to convert cycles to time (the benchmark TB clock has a 10 ns period; no silicon target implies it) |
| e_rd_bit_fj | 80.0 | fJ/bit | bitline swing + sense amplifier energy per bit sensed in a read access |
| e_wr_bit_fj | 120.0 | fJ/bit | bitline full-swing drive + cell flip energy per bit actually written (write/read per-bit ratio 1.5 is itself an assumption) |
| e_halfsel_bit_fj | 20.0 | fJ/bit | disturbed-column energy per UNWRITTEN bit of the selected row in a byte-masked (partial) write without ECC |
| e_wl_bit_fj | 15.0 | fJ/bit | wordline energy per bit of row width (all columns of the selected row, read or write) |
| e_dec_fixed_pj | 1.5 | pJ/access | row decoder, wordline driver, control and clock energy per access, independent of width |
| e_dec_per_addrbit_pj | 0.15 | pJ/(access*address bit) | decoder energy per row-address bit (capacity dependence: log2(DEPTH) bits) |
| e_idle_clk_pj_per_bank_cycle | 0.4 | pJ/(bank*cycle) | clock tree / control energy of a bank in a cycle without access |
| e_ecc_enc_pj | 0.6 | pJ/use | SECDED encoder (XOR tree) energy per use (full-line write, RMW write-back) |
| e_ecc_dec_pj | 1.0 | pJ/use | SECDED decoder + correction energy per use (read, RMW read) |
| e_ctrl_access_pj | 1.0 | pJ/access | controller arbitration, reorder-slot write and response mux energy per accepted array access |
| ctrl_err_fraction | 0.3 | - | controller energy of an ALIGN/RANGE error response (no array access) as a fraction of e_ctrl_access_pj |
| leak_pw_per_bit | 40.0 | pW/bit | array leakage per stored bit |
| periph_leak_fraction | 0.3 | - | periphery (decoder, sense amps, drivers) leakage as a fraction of array leakage |
| scrub_wait_cycles | 64 | cycles | SCRUB_WAIT of rtl/sf_sram_bank.sv (RTL default 64); listed here because it is a configuration choice, not data |
