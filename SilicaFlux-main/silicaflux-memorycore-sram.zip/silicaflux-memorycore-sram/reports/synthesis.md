# Logic synthesis (Yosys generic gates; no PDK, no timing, no area)

SRAM arrays stay `$mem` cells (macro mapping is a physical-design step). Counts are generic-gate counts, NOT standard-cell area.

| module / configuration | status | flip-flops | other logic cells | `$mem` cells | memory bits | latches | s |
|---|---|---:|---:|---:|---:|---:|---:|
| sf_ecc_enc K=128 | OK | 0 | 314 | 0 | 0 | 0 | 6.1 |
| sf_ecc_dec K=128 | OK | 0 | 1389 | 0 | 0 | 0 | 9.0 |
| sf_sram_core 1024x128 | OK | 6 | 17 | 1 | 131072 | 0 | 3.6 |
| sf_sram_bank 1024x128 (no ECC) | OK | 29 | 726 | 1 | 131072 | 0 | 4.0 |
| sf_sram_bank 1024x137 SECDED + scrub | OK | 423 | 4036 | 1 | 140288 | 0 | 14.1 |
| sf_sram_controller NM4 NB4 4x1024x128 | OK | 5205 | 36440 | 4 | 524288 | 0 | 43.8 |
| sf_sram_controller NM4 NB4 SECDED | OK | 6561 | 46848 | 4 | 561152 | 0 | 64.5 |
| sf_sram_controller NM2 NB2 small | OK | 1431 | 7641 | 2 | 16384 | 0 | 12.8 |
| sf_sram_datafabric DW128 NP1 | OK | 29 | 381 | 0 | 0 | 0 | 3.1 |
| sf_sram_datafabric DW32 NP2 | OK | 30 | 796 | 0 | 0 | 0 | 3.4 |
| sf_vector_scratchpad VEC128 | OK | 326 | 7104 | 2 | 0 | 0 | 15.7 |
| sf_vector_scratchpad VEC512 | OK | 713 | 20059 | 2 | 0 | 0 | 90.3 |
| sf_tensor_scratchpad 8x1 lines, ping-pong | OK | 101 | 1229 | 4 | 0 | 0 | 3.7 |
| sf_sram_mbist_ctl NB4 1024x128 | OK | 235 | 1205 | 0 | 0 | 0 | 7.6 |
