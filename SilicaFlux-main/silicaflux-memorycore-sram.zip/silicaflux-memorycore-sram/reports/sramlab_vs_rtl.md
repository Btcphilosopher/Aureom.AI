# SilicaFlux MemoryCore SRAM - cycle model, ceilings and energy tooling vs RTL simulation

Generated 2026-11-14 15:17:09 by `python3 -m sramlab report` (tools/sramlab). Source RTL: rtl/sf_sram_controller.sv, rtl/sf_sram_bank.sv, rtl/sf_sram_core.sv, rtl/sf_tensor_scratchpad.sv; testbenches tb/tb_bench_ctrl.sv, tb/tb_tensor_scratchpad.sv; RTL results reports/bench_rtl.json (Verilator 5.020 2024-01-01 rev (Debian 5.020-1), NREQ=1000).

**Provenance tags** - `RTL-SIMULATION`: Verilator simulation of the RTL (reports/bench_rtl.json, or an instrumented re-run in build/sramlab_work); `MODEL`: tools/sramlab cycle model (derived from the RTL source); `ANALYTICAL`: closed form / small exact Markov chain (sramlab.analytic); `ASSUMED-PARAMETER`: a number chosen by us, not data (only in the energy report). Nothing in this file is a silicon measurement.

## 0. Summary

* **Validation (MODEL vs RTL-SIMULATION).** 119 of 119 committed controller benchmark rows are reproduced EXACTLY for all seven statistics (cycles, accesses, bank_conflict_cycles, bank_busy_stalls, mean_latency to the printed 3 decimals, max_latency, max_outstanding); 0 rows differ. No tolerance, no fitted constant.
* **Extra RTL runs.** 342 of 342 additional Verilator runs of an instrumented copy of the benchmark TB (non power-of-two NM / NSLOT / DEPTH, READ_LATENCY up to 5 with ECC, NM up to 16, fixed priority, ALIGN_MODE=0 builds, random RSP_PCT / LOAD_PCT / SEED) match the model in the statistics, in EVERY clock edge (accept / pop / bank-grant masks) and in the controller's own performance counters. Tensor scratchpad: 20 of 20 instrumented configurations match edge for edge; the remaining 0 differs only in a testbench counter artefact (section 6).
* **Headline ceilings (RTL-SIMULATION vs ANALYTICAL ceiling, 4 masters x 4 banks, 16 B lines):** peak seq line 63.68 of 64.00 B/c (99.5 %); own bank 63.87 of 64.00 B/c (99.8 %); single bank 15.99 of 16.00 B/c (100.0 %); random read 41.29 of 41.94 B/c (98.5 %); random rw 41.72 of 41.94 B/c (99.5 %); ecc part write 7.98 of 8.00 B/c (99.8 %).
* **Scalar loads (benchmark A, pattern 0).** The first revision of the TB issued byte-strided sub-line addresses to an ALIGN_MODE=1 controller, so 3 of 4 requests were rejected with `SF_ST_ALIGN` and benchmark A reported 15.92 B/cycle for what was really ~4 B/cycle of array traffic (found by this validation, RTL counters: 3000 error responses of 4000). The TB now issues line-aligned scalar loads (4 consecutive loads per line); RTL-SIMULATION result 15.97 B/cycle against an ANALYTICAL bound of 16.00 B/cycle (each 4 B load costs a whole 16 B bank access).

## 1. Validation: MODEL vs RTL-SIMULATION

### 1.1 Committed benchmark rows (reports/bench_rtl.json, `controller`)

| statistic | rows reproduced exactly (MODEL = RTL-SIMULATION) |
|---|---|
| cycles | 119 / 119 |
| accesses | 119 / 119 |
| bank_conflict_cycles | 119 / 119 |
| bank_busy_stalls | 119 / 119 |
| mean_latency | 119 / 119 |
| max_latency | 119 / 119 |
| max_outstanding | 119 / 119 |

**No mismatching row.** Therefore there is no 'model bug vs undocumented RTL behaviour' to report for these rows; the RTL behaviours that the contract text does not state but that the model needed are listed in 1.4 (each was derived from the RTL source before the comparison, and confirmed by it).

### 1.2 Extra RTL-SIMULATION runs (instrumented copy of the TB, build/sramlab_work)

| config | parameters | runs | exact (stats + per-edge trace + perf counters) | edges compared |
|---|---|---|---|---|
| x_base | NM=4 NB=4 DEPTH=256 RL=1 ECC=0 NSLOT=8 ARB=RR ALIGN=1 | 9 | 9 / 9 | 13648 |
| x_ecc | NM=4 NB=4 DEPTH=256 RL=1 ECC=1 NSLOT=8 ARB=RR ALIGN=1 | 9 | 9 / 9 | 15338 |
| x_nm3_ns3 | NM=3 NB=4 DEPTH=256 RL=1 ECC=0 NSLOT=3 ARB=RR ALIGN=1 | 36 | 36 / 36 | 62807 |
| x_nm8_L4_ecc | NM=8 NB=4 DEPTH=128 RL=4 ECC=1 NSLOT=6 ARB=RR ALIGN=1 | 36 | 36 / 36 | 76170 |
| x_nb2_fx_ecc | NM=4 NB=2 DEPTH=256 RL=2 ECC=1 NSLOT=5 ARB=FIXED ALIGN=1 | 36 | 36 / 36 | 63628 |
| x_align0 | NM=4 NB=4 DEPTH=256 RL=1 ECC=0 NSLOT=8 ARB=RR ALIGN=0 | 36 | 36 / 36 | 59778 |
| x_nm6_nb8_L3 | NM=6 NB=8 DEPTH=64 RL=3 ECC=0 NSLOT=12 ARB=RR ALIGN=1 | 36 | 36 / 36 | 57511 |
| x_nm16_ecc | NM=16 NB=4 DEPTH=64 RL=1 ECC=1 NSLOT=4 ARB=RR ALIGN=1 | 36 | 36 / 36 | 98874 |
| x_nm1_nb1_ecc | NM=1 NB=1 DEPTH=128 RL=1 ECC=1 NSLOT=2 ARB=RR ALIGN=1 | 36 | 36 / 36 | 60292 |
| x_d100 | NM=4 NB=4 DEPTH=100 RL=2 ECC=0 NSLOT=7 ARB=RR ALIGN=1 | 36 | 36 / 36 | 48924 |
| x_nm4_L5_ecc_ns10 | NM=4 NB=8 DEPTH=64 RL=5 ECC=1 NSLOT=10 ARB=FIXED ALIGN=1 | 36 | 36 / 36 | 49394 |

The instrumented copy is inert: its BENCH line equals the committed JSON row in 18 of 18 runs of the committed `base` / `ecc` configurations (nreq 1000). Per run, the compared items are the seven statistics, the per-edge (accept mask, pop mask, bank-grant mask) of every edge from the first presentation to the last pop, and the controller's perf counters (per-bank accepted / conflict / busy, per-master stall and max outstanding, c_start, error responses). In particular the absolute first-presentation edge (`c_start` = DEPTH + 26, derived from the TB's reset / init / settle sequence, it matters for the LOAD_PCT hash) equals the RTL value in every run.

### 1.3 Full table: every committed row, RTL-SIMULATION values (MODEL equals RTL in every cell)

| # | exp | config | pattern | rsp%/load%/seed | cycles | accesses | conflict cyc | busy stalls | mean lat | max lat | max out | MODEL vs RTL |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | AB | base | SEQ_SCALAR4 | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 1 | AB | base | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 2 | DEF | base | OWN_BANK | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 3 | DEF | base | SAME_BANK | 100/100/12648430 | 4002 | 4000 | 3999 | 0 | 5.998 | 6 | 1 | EXACT 7/7 |
| 4 | DEF | base | RANDOM_LINE | 100/100/12648430 | 1550 | 4000 | 1631 | 0 | 3.531 | 6 | 3 | EXACT 7/7 |
| 5 | DEF | base | RANDOM_RW | 100/100/12648430 | 1534 | 4000 | 1634 | 0 | 3.517 | 6 | 3 | EXACT 7/7 |
| 6 | DEF | base | SEQ_WRITE_FULL | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 7 | DEF | base | SEQ_WRITE_PART4 | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 8 | DEF | base | RANDOM_PART4 | 100/100/12648430 | 1534 | 4000 | 1634 | 0 | 3.517 | 6 | 3 | EXACT 7/7 |
| 9 | A | base | SEQ_SCALAR4 | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 10 | B | base | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 11 | D | base | OWN_BANK | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 12 | E | base | SAME_BANK | 100/100/12648430 | 4002 | 4000 | 3999 | 0 | 5.998 | 6 | 1 | EXACT 7/7 |
| 13 | E | fixed | SAME_BANK | 100/100/12648430 | 4002 | 4000 | 3000 | 0 | 4.500 | 3003 | 3 | EXACT 7/7 |
| 14 | F | base | RANDOM_LINE | 100/100/12648430 | 1550 | 4000 | 1631 | 0 | 3.531 | 6 | 3 | EXACT 7/7 |
| 15 | F | base | RANDOM_RW | 100/100/12648430 | 1534 | 4000 | 1634 | 0 | 3.517 | 6 | 3 | EXACT 7/7 |
| 16 | F | base | RANDOM_PART4 | 100/100/12648430 | 1534 | 4000 | 1634 | 0 | 3.517 | 6 | 3 | EXACT 7/7 |
| 17 | H | ecc | SEQ_SCALAR4 | 100/100/12648430 | 1003 | 4000 | 0 | 0 | 4.000 | 4 | 4 | EXACT 7/7 |
| 18 | L | L2 | SEQ_SCALAR4 | 100/100/12648430 | 1003 | 4000 | 0 | 0 | 4.000 | 4 | 4 | EXACT 7/7 |
| 19 | H | ecc_L2 | SEQ_SCALAR4 | 100/100/12648430 | 1004 | 4000 | 0 | 0 | 5.000 | 5 | 5 | EXACT 7/7 |
| 20 | H | ecc | SEQ_LINE | 100/100/12648430 | 1006 | 4000 | 3 | 0 | 4.002 | 7 | 4 | EXACT 7/7 |
| 21 | L | L2 | SEQ_LINE | 100/100/12648430 | 1006 | 4000 | 3 | 0 | 4.002 | 7 | 4 | EXACT 7/7 |
| 22 | H | ecc_L2 | SEQ_LINE | 100/100/12648430 | 1007 | 4000 | 3 | 0 | 5.002 | 8 | 5 | EXACT 7/7 |
| 23 | H | ecc | OWN_BANK | 100/100/12648430 | 1003 | 4000 | 0 | 0 | 4.000 | 4 | 4 | EXACT 7/7 |
| 24 | L | L2 | OWN_BANK | 100/100/12648430 | 1003 | 4000 | 0 | 0 | 4.000 | 4 | 4 | EXACT 7/7 |
| 25 | H | ecc_L2 | OWN_BANK | 100/100/12648430 | 1004 | 4000 | 0 | 0 | 5.000 | 5 | 5 | EXACT 7/7 |
| 26 | H | ecc | SAME_BANK | 100/100/12648430 | 4003 | 4000 | 3999 | 0 | 6.998 | 7 | 1 | EXACT 7/7 |
| 27 | L | L2 | SAME_BANK | 100/100/12648430 | 4003 | 4000 | 3999 | 0 | 6.998 | 7 | 1 | EXACT 7/7 |
| 28 | H | ecc_L2 | SAME_BANK | 100/100/12648430 | 4004 | 4000 | 3999 | 0 | 7.998 | 8 | 2 | EXACT 7/7 |
| 29 | H | ecc | RANDOM_LINE | 100/100/12648430 | 1551 | 4000 | 1631 | 0 | 4.531 | 7 | 4 | EXACT 7/7 |
| 30 | L | L2 | RANDOM_LINE | 100/100/12648430 | 1551 | 4000 | 1631 | 0 | 4.531 | 7 | 4 | EXACT 7/7 |
| 31 | H | ecc_L2 | RANDOM_LINE | 100/100/12648430 | 1552 | 4000 | 1631 | 0 | 5.531 | 8 | 5 | EXACT 7/7 |
| 32 | H | ecc | RANDOM_RW | 100/100/12648430 | 1535 | 4000 | 1634 | 0 | 4.517 | 7 | 4 | EXACT 7/7 |
| 33 | L | L2 | RANDOM_RW | 100/100/12648430 | 1535 | 4000 | 1634 | 0 | 4.517 | 7 | 4 | EXACT 7/7 |
| 34 | H | ecc_L2 | RANDOM_RW | 100/100/12648430 | 1536 | 4000 | 1634 | 0 | 5.517 | 8 | 5 | EXACT 7/7 |
| 35 | H | ecc | SEQ_WRITE_FULL | 100/100/12648430 | 1006 | 4000 | 3 | 0 | 4.002 | 7 | 4 | EXACT 7/7 |
| 36 | L | L2 | SEQ_WRITE_FULL | 100/100/12648430 | 1006 | 4000 | 3 | 0 | 4.002 | 7 | 4 | EXACT 7/7 |
| 37 | H | ecc_L2 | SEQ_WRITE_FULL | 100/100/12648430 | 1007 | 4000 | 3 | 0 | 5.002 | 8 | 5 | EXACT 7/7 |
| 38 | H | ecc | SEQ_WRITE_PART4 | 100/100/12648430 | 2005 | 4000 | 1997 | 999 | 4.999 | 10 | 4 | EXACT 7/7 |
| 39 | L | L2 | SEQ_WRITE_PART4 | 100/100/12648430 | 1006 | 4000 | 3 | 0 | 4.002 | 7 | 4 | EXACT 7/7 |
| 40 | H | ecc_L2 | SEQ_WRITE_PART4 | 100/100/12648430 | 3005 | 4000 | 2995 | 1998 | 6.997 | 14 | 4 | EXACT 7/7 |
| 41 | H | ecc | RANDOM_PART4 | 100/100/12648430 | 2217 | 4000 | 2395 | 1407 | 5.181 | 11 | 4 | EXACT 7/7 |
| 42 | L | L2 | RANDOM_PART4 | 100/100/12648430 | 1535 | 4000 | 1634 | 0 | 4.517 | 7 | 4 | EXACT 7/7 |
| 43 | H | ecc_L2 | RANDOM_PART4 | 100/100/12648430 | 2959 | 4000 | 3316 | 2927 | 6.930 | 16 | 5 | EXACT 7/7 |
| 44 | J | nb1 | SEQ_LINE | 100/100/12648430 | 4002 | 4000 | 3999 | 0 | 5.998 | 6 | 1 | EXACT 7/7 |
| 45 | J | nb1 | OWN_BANK | 100/100/12648430 | 4002 | 4000 | 3999 | 0 | 5.998 | 6 | 1 | EXACT 7/7 |
| 46 | J | nb1 | RANDOM_LINE | 100/100/12648430 | 4002 | 4000 | 3999 | 0 | 5.998 | 6 | 1 | EXACT 7/7 |
| 47 | J | nb2 | SEQ_LINE | 100/100/12648430 | 2003 | 4000 | 1999 | 0 | 3.999 | 6 | 2 | EXACT 7/7 |
| 48 | J | nb2 | OWN_BANK | 100/100/12648430 | 2002 | 4000 | 3998 | 0 | 3.999 | 4 | 2 | EXACT 7/7 |
| 49 | J | nb2 | RANDOM_LINE | 100/100/12648430 | 2307 | 4000 | 2846 | 0 | 4.290 | 6 | 3 | EXACT 7/7 |
| 50 | J | base | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 51 | J | base | OWN_BANK | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 52 | J | base | RANDOM_LINE | 100/100/12648430 | 1550 | 4000 | 1631 | 0 | 3.531 | 6 | 3 | EXACT 7/7 |
| 53 | J | nb8 | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 54 | J | nb8 | OWN_BANK | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 55 | J | nb8 | RANDOM_LINE | 100/100/12648430 | 1246 | 4000 | 818 | 0 | 3.226 | 6 | 3 | EXACT 7/7 |
| 56 | J | nm2_nb4 | SEQ_LINE | 100/100/12648430 | 1003 | 2000 | 1 | 0 | 3.001 | 4 | 3 | EXACT 7/7 |
| 57 | J | nm2_nb4 | OWN_BANK | 100/100/12648430 | 1002 | 2000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 58 | J | nm2_nb4 | RANDOM_LINE | 100/100/12648430 | 1156 | 2000 | 306 | 0 | 3.153 | 4 | 3 | EXACT 7/7 |
| 59 | J | nm8_nb4 | SEQ_LINE | 100/100/12648430 | 2005 | 8000 | 1999 | 0 | 3.999 | 10 | 3 | EXACT 7/7 |
| 60 | J | nm8_nb4 | OWN_BANK | 100/100/12648430 | 2002 | 8000 | 7996 | 0 | 3.999 | 4 | 2 | EXACT 7/7 |
| 61 | J | nm8_nb4 | RANDOM_LINE | 100/100/12648430 | 2455 | 8000 | 5340 | 0 | 4.424 | 10 | 3 | EXACT 7/7 |
| 62 | J | nm8_nb8 | SEQ_LINE | 100/100/12648430 | 1009 | 8000 | 7 | 0 | 3.003 | 10 | 3 | EXACT 7/7 |
| 63 | J | nm8_nb8 | OWN_BANK | 100/100/12648430 | 1002 | 8000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 64 | J | nm8_nb8 | RANDOM_LINE | 100/100/12648430 | 1677 | 8000 | 3409 | 0 | 3.623 | 10 | 3 | EXACT 7/7 |
| 65 | J | d64 | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 66 | J | d64 | OWN_BANK | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 67 | J | d64 | RANDOM_LINE | 100/100/12648430 | 1550 | 4000 | 1631 | 0 | 3.531 | 6 | 3 | EXACT 7/7 |
| 68 | J | d1024 | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 69 | J | d1024 | OWN_BANK | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 70 | J | d1024 | RANDOM_LINE | 100/100/12648430 | 1550 | 4000 | 1631 | 0 | 3.531 | 6 | 3 | EXACT 7/7 |
| 71 | J | d4096 | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 72 | J | d4096 | OWN_BANK | 100/100/12648430 | 1002 | 4000 | 0 | 0 | 3.000 | 3 | 3 | EXACT 7/7 |
| 73 | J | d4096 | RANDOM_LINE | 100/100/12648430 | 1550 | 4000 | 1631 | 0 | 3.531 | 6 | 3 | EXACT 7/7 |
| 74 | S | base | RANDOM_LINE | 100/5/12648430 | 20672 | 4000 | 73 | 0 | 3.018 | 5 | 2 | EXACT 7/7 |
| 75 | S | base | SEQ_LINE | 100/5/12648430 | 20667 | 4000 | 95 | 0 | 3.024 | 5 | 2 | EXACT 7/7 |
| 76 | S | nb8 | RANDOM_LINE | 100/5/12648430 | 20711 | 4000 | 44 | 0 | 3.011 | 4 | 2 | EXACT 7/7 |
| 77 | S | base | RANDOM_LINE | 100/10/12648430 | 10485 | 4000 | 193 | 0 | 3.049 | 5 | 3 | EXACT 7/7 |
| 78 | S | base | SEQ_LINE | 100/10/12648430 | 10475 | 4000 | 182 | 0 | 3.046 | 5 | 3 | EXACT 7/7 |
| 79 | S | nb8 | RANDOM_LINE | 100/10/12648430 | 10377 | 4000 | 89 | 0 | 3.023 | 5 | 3 | EXACT 7/7 |
| 80 | S | base | RANDOM_LINE | 100/20/12648430 | 5231 | 4000 | 333 | 0 | 3.088 | 5 | 3 | EXACT 7/7 |
| 81 | S | base | SEQ_LINE | 100/20/12648430 | 5182 | 4000 | 282 | 0 | 3.072 | 5 | 3 | EXACT 7/7 |
| 82 | S | nb8 | RANDOM_LINE | 100/20/12648430 | 5107 | 4000 | 156 | 0 | 3.039 | 5 | 3 | EXACT 7/7 |
| 83 | S | base | RANDOM_LINE | 100/30/12648430 | 3656 | 4000 | 494 | 0 | 3.131 | 6 | 3 | EXACT 7/7 |
| 84 | S | base | SEQ_LINE | 100/30/12648430 | 3653 | 4000 | 418 | 0 | 3.109 | 6 | 3 | EXACT 7/7 |
| 85 | S | nb8 | RANDOM_LINE | 100/30/12648430 | 3539 | 4000 | 217 | 0 | 3.055 | 5 | 3 | EXACT 7/7 |
| 86 | S | base | RANDOM_LINE | 100/40/12648430 | 2887 | 4000 | 677 | 0 | 3.185 | 6 | 3 | EXACT 7/7 |
| 87 | S | base | SEQ_LINE | 100/40/12648430 | 2801 | 4000 | 564 | 0 | 3.147 | 6 | 3 | EXACT 7/7 |
| 88 | S | nb8 | RANDOM_LINE | 100/40/12648430 | 2728 | 4000 | 297 | 0 | 3.077 | 5 | 3 | EXACT 7/7 |
| 89 | S | base | RANDOM_LINE | 100/50/12648430 | 2281 | 4000 | 884 | 0 | 3.249 | 6 | 3 | EXACT 7/7 |
| 90 | S | base | SEQ_LINE | 100/50/12648430 | 2209 | 4000 | 648 | 0 | 3.169 | 6 | 3 | EXACT 7/7 |
| 91 | S | nb8 | RANDOM_LINE | 100/50/12648430 | 2142 | 4000 | 424 | 0 | 3.111 | 6 | 3 | EXACT 7/7 |
| 92 | S | base | RANDOM_LINE | 100/60/12648430 | 2014 | 4000 | 1118 | 0 | 3.329 | 6 | 3 | EXACT 7/7 |
| 93 | S | base | SEQ_LINE | 100/60/12648430 | 1890 | 4000 | 738 | 0 | 3.195 | 6 | 3 | EXACT 7/7 |
| 94 | S | nb8 | RANDOM_LINE | 100/60/12648430 | 1841 | 4000 | 487 | 0 | 3.129 | 6 | 3 | EXACT 7/7 |
| 95 | S | base | RANDOM_LINE | 100/80/12648430 | 1714 | 4000 | 1419 | 0 | 3.429 | 6 | 3 | EXACT 7/7 |
| 96 | S | base | SEQ_LINE | 100/80/12648430 | 1475 | 4000 | 755 | 0 | 3.192 | 5 | 3 | EXACT 7/7 |
| 97 | S | nb8 | RANDOM_LINE | 100/80/12648430 | 1454 | 4000 | 635 | 0 | 3.172 | 6 | 3 | EXACT 7/7 |
| 98 | S | base | RANDOM_LINE | 100/100/12648430 | 1550 | 4000 | 1631 | 0 | 3.531 | 6 | 3 | EXACT 7/7 |
| 99 | S | base | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 100 | S | nb8 | RANDOM_LINE | 100/100/12648430 | 1246 | 4000 | 818 | 0 | 3.226 | 6 | 3 | EXACT 7/7 |
| 101 | Q | slot2 | SEQ_LINE | 100/100/12648430 | 1504 | 4000 | 3 | 0 | 3.501 | 6 | 2 | EXACT 7/7 |
| 102 | Q | slot2 | SEQ_LINE | 50/100/12648430 | 2486 | 4000 | 623 | 0 | 6.181 | 17 | 2 | EXACT 7/7 |
| 103 | Q | slot2 | SEQ_LINE | 20/100/12648430 | 5366 | 4000 | 252 | 0 | 14.822 | 43 | 2 | EXACT 7/7 |
| 104 | Q | slot2 | SEQ_LINE | 10/100/12648430 | 10113 | 4000 | 126 | 0 | 29.160 | 118 | 2 | EXACT 7/7 |
| 105 | Q | slot4 | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 106 | Q | slot4 | SEQ_LINE | 50/100/12648430 | 2057 | 4000 | 693 | 0 | 8.746 | 24 | 4 | EXACT 7/7 |
| 107 | Q | slot4 | SEQ_LINE | 20/100/12648430 | 5198 | 4000 | 289 | 0 | 24.648 | 61 | 4 | EXACT 7/7 |
| 108 | Q | slot4 | SEQ_LINE | 10/100/12648430 | 9984 | 4000 | 142 | 0 | 48.467 | 154 | 4 | EXACT 7/7 |
| 109 | Q | base | SEQ_LINE | 100/100/12648430 | 1005 | 4000 | 3 | 0 | 3.002 | 6 | 3 | EXACT 7/7 |
| 110 | Q | base | SEQ_LINE | 50/100/12648430 | 2045 | 4000 | 662 | 0 | 16.749 | 33 | 8 | EXACT 7/7 |
| 111 | Q | base | SEQ_LINE | 20/100/12648430 | 5198 | 4000 | 290 | 0 | 45.125 | 88 | 8 | EXACT 7/7 |
| 112 | Q | base | SEQ_LINE | 10/100/12648430 | 9984 | 4000 | 143 | 0 | 87.889 | 203 | 8 | EXACT 7/7 |
| 113 | F | base | RANDOM_LINE | 100/100/1001 | 1546 | 4000 | 1669 | 0 | 3.524 | 6 | 3 | EXACT 7/7 |
| 114 | F | base | RANDOM_LINE | 100/100/1002 | 1537 | 4000 | 1621 | 0 | 3.518 | 6 | 3 | EXACT 7/7 |
| 115 | F | base | RANDOM_LINE | 100/100/1003 | 1512 | 4000 | 1583 | 0 | 3.495 | 6 | 3 | EXACT 7/7 |
| 116 | L | L3 | SEQ_LINE | 100/100/12648430 | 1007 | 4000 | 3 | 0 | 5.002 | 8 | 5 | EXACT 7/7 |
| 117 | L | L3 | RANDOM_LINE | 100/100/12648430 | 1552 | 4000 | 1631 | 0 | 5.531 | 8 | 5 | EXACT 7/7 |
| 118 | L | L3 | SEQ_WRITE_PART4 | 100/100/12648430 | 1007 | 4000 | 3 | 0 | 5.002 | 8 | 5 | EXACT 7/7 |

### 1.4 RTL behaviour the contract text does not state (needed by the model; all confirmed by the RTL comparison)

1. **Pop timing / slot recycling.** A slot freed by a pop at edge e is visible in the registered `cnt` at e+1, so the same master can accept again at e+1: round trip BANK_LAT+2 (not BANK_LAT+1) - this is the exact origin of the `NSLOT >= BANK_LAT+2` rule (rtl/sf_sram_controller.sv:354,375) and of the slot ceiling NSLOT/(BANK_LAT+2).
2. **Error requests (ALIGN / RANGE) are accepted without a bank and answered at the NEXT edge, but still released in order** behind older array accesses (sd set at allocation, rtl/sf_sram_controller.sv:409-411; head-only release line 357): the latency of an error response is therefore hidden by the in-order rule (benchmark A shows identical mean latency to B).
3. **Arbitration pointer.** `rr_ptr` of a bank moves only when that bank grants (line 247-250), to granted+1; a request that is blocked because its bank is busy (RMW) does not advance it. Masters therefore desynchronise by one bank after the first conflict: SEQ_LINE (all master regions are bank-aligned, REGION multiple of NB) is conflict-free in steady state although every master starts on the same bank (3 conflict cycles in total in benchmark B).
4. **Performance-counter semantics.** `perf_conf` counts a bank-cycle with >= 2 requesters AFTER the `can_alloc` and error filter (line 229, 426-431), also when the bank is busy; a master whose slots are full is not a requester. `perf_busy` counts bank-cycles (not masters) with >= 1 requester and a busy bank; it is identically 0 without ECC (no mechanism makes a bank busy), so `bank_busy_stalls` is purely the ECC read-modify-write signature.
5. **m_req_ready is NOT a function of 'this master's own valid/address only'** as the header claims (rtl/sf_sram_controller.sv:16-17): `gnt_any[i]` depends on every other master's valid / address through the per-bank arbiter (lines 229-241, 285). It is independent of `m_rsp_ready` as stated. (Documentation issue, no functional bug.)
6. **TB latency convention.** The TB counts from the presentation edge, so the minimum latency is BANK_LAT+2 (3 cycles for READ_LATENCY=1 without ECC); the contract's BANK_LAT+1 is counted from the accepting edge. Both agree.

## 2. Ceilings vs RTL-SIMULATION

Formulas (ANALYTICAL, `sramlab.analytic`): bank peak = NB x 16 B/c; per-master slot ceiling = min(1, NSLOT/(BANK_LAT+2)) accesses/cycle (exact for rsp_ready = 1; exact Markov chain for a Bernoulli response-ready); single bank = 16 B/c; random destinations with head-of-line blocking = stationary accesses/cycle of the occupancy Markov chain (exact for iid uniform destinations: NM=NB=2/4/8 -> 0.7500 / 0.6552 / 0.6184 per bank, the Karol et al. values; balls-in-bins NB(1-(1-1/NB)^NM) is only an upper bound); an ECC partial write occupies its bank READ_LATENCY+1 cycles. The ceiling column is always an upper bound in expectation; `~` marks rows where it is not tight by construction (pattern 0 in the TB's useful-byte accounting; random mixed read / partial-write traffic with ECC, where the product HOL x 1/(1+f RL) is given as an approximate estimate).

### 2.1 Every committed row: RTL-SIMULATION | MODEL | ANALYTICAL ceiling | efficiency = RTL / ceiling

| exp | config | pattern | rsp%/load% | RTL B/c | MODEL B/c | ANALYTICAL ceiling B/c (upper bound) | efficiency | ANALYTICAL approx. estimate B/c (where it differs) | RTL mean latency (zero-load min) | approx |
|---|---|---|---|---|---|---|---|---|---|---|
| AB | base | SEQ_SCALAR4 | 100/100 | 15.97 | 15.97 | 16.00 | 99.8 % |  | 3.00 (min 3) | ~ |
| AB | base | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| DEF | base | OWN_BANK | 100/100 | 63.87 | 63.87 | 64.00 | 99.8 % |  | 3.00 (min 3) |  |
| DEF | base | SAME_BANK | 100/100 | 15.99 | 15.99 | 16.00 | 100.0 % |  | 6.00 (min 3) |  |
| DEF | base | RANDOM_LINE | 100/100 | 41.29 | 41.29 | 41.94 | 98.5 % |  | 3.53 (min 3) |  |
| DEF | base | RANDOM_RW | 100/100 | 41.72 | 41.72 | 41.94 | 99.5 % |  | 3.52 (min 3) |  |
| DEF | base | SEQ_WRITE_FULL | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| DEF | base | SEQ_WRITE_PART4 | 100/100 | 15.92 | 15.92 | 16.00 | 99.5 % |  | 3.00 (min 3) |  |
| DEF | base | RANDOM_PART4 | 100/100 | 10.43 | 10.43 | 10.48 | 99.5 % |  | 3.52 (min 3) |  |
| A | base | SEQ_SCALAR4 | 100/100 | 15.97 | 15.97 | 16.00 | 99.8 % |  | 3.00 (min 3) | ~ |
| B | base | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| D | base | OWN_BANK | 100/100 | 63.87 | 63.87 | 64.00 | 99.8 % |  | 3.00 (min 3) |  |
| E | base | SAME_BANK | 100/100 | 15.99 | 15.99 | 16.00 | 100.0 % |  | 6.00 (min 3) |  |
| E | fixed | SAME_BANK | 100/100 | 15.99 | 15.99 | 16.00 | 100.0 % |  | 4.50 (min 3) |  |
| F | base | RANDOM_LINE | 100/100 | 41.29 | 41.29 | 41.94 | 98.5 % |  | 3.53 (min 3) |  |
| F | base | RANDOM_RW | 100/100 | 41.72 | 41.72 | 41.94 | 99.5 % |  | 3.52 (min 3) |  |
| F | base | RANDOM_PART4 | 100/100 | 10.43 | 10.43 | 10.48 | 99.5 % |  | 3.52 (min 3) |  |
| H | ecc | SEQ_SCALAR4 | 100/100 | 15.95 | 15.95 | 16.00 | 99.7 % |  | 4.00 (min 4) | ~ |
| L | L2 | SEQ_SCALAR4 | 100/100 | 15.95 | 15.95 | 16.00 | 99.7 % |  | 4.00 (min 4) | ~ |
| H | ecc_L2 | SEQ_SCALAR4 | 100/100 | 15.94 | 15.94 | 16.00 | 99.6 % |  | 5.00 (min 5) | ~ |
| H | ecc | SEQ_LINE | 100/100 | 63.62 | 63.62 | 64.00 | 99.4 % |  | 4.00 (min 4) |  |
| L | L2 | SEQ_LINE | 100/100 | 63.62 | 63.62 | 64.00 | 99.4 % |  | 4.00 (min 4) |  |
| H | ecc_L2 | SEQ_LINE | 100/100 | 63.56 | 63.56 | 64.00 | 99.3 % |  | 5.00 (min 5) |  |
| H | ecc | OWN_BANK | 100/100 | 63.81 | 63.81 | 64.00 | 99.7 % |  | 4.00 (min 4) |  |
| L | L2 | OWN_BANK | 100/100 | 63.81 | 63.81 | 64.00 | 99.7 % |  | 4.00 (min 4) |  |
| H | ecc_L2 | OWN_BANK | 100/100 | 63.74 | 63.74 | 64.00 | 99.6 % |  | 5.00 (min 5) |  |
| H | ecc | SAME_BANK | 100/100 | 15.99 | 15.99 | 16.00 | 99.9 % |  | 7.00 (min 4) |  |
| L | L2 | SAME_BANK | 100/100 | 15.99 | 15.99 | 16.00 | 99.9 % |  | 7.00 (min 4) |  |
| H | ecc_L2 | SAME_BANK | 100/100 | 15.98 | 15.98 | 16.00 | 99.9 % |  | 8.00 (min 5) |  |
| H | ecc | RANDOM_LINE | 100/100 | 41.26 | 41.26 | 41.94 | 98.4 % |  | 4.53 (min 4) |  |
| L | L2 | RANDOM_LINE | 100/100 | 41.26 | 41.26 | 41.94 | 98.4 % |  | 4.53 (min 4) |  |
| H | ecc_L2 | RANDOM_LINE | 100/100 | 41.24 | 41.24 | 41.94 | 98.3 % |  | 5.53 (min 5) |  |
| H | ecc | RANDOM_RW | 100/100 | 41.69 | 41.69 | 41.94 | 99.4 % |  | 4.52 (min 4) |  |
| L | L2 | RANDOM_RW | 100/100 | 41.69 | 41.69 | 41.94 | 99.4 % |  | 4.52 (min 4) |  |
| H | ecc_L2 | RANDOM_RW | 100/100 | 41.67 | 41.67 | 41.94 | 99.4 % |  | 5.52 (min 5) |  |
| H | ecc | SEQ_WRITE_FULL | 100/100 | 63.62 | 63.62 | 64.00 | 99.4 % |  | 4.00 (min 4) |  |
| L | L2 | SEQ_WRITE_FULL | 100/100 | 63.62 | 63.62 | 64.00 | 99.4 % |  | 4.00 (min 4) |  |
| H | ecc_L2 | SEQ_WRITE_FULL | 100/100 | 63.56 | 63.56 | 64.00 | 99.3 % |  | 5.00 (min 5) |  |
| H | ecc | SEQ_WRITE_PART4 | 100/100 | 7.98 | 7.98 | 8.00 | 99.8 % |  | 5.00 (min 4) |  |
| L | L2 | SEQ_WRITE_PART4 | 100/100 | 15.90 | 15.90 | 16.00 | 99.4 % |  | 4.00 (min 4) |  |
| H | ecc_L2 | SEQ_WRITE_PART4 | 100/100 | 5.32 | 5.32 | 5.33 | 99.8 % |  | 7.00 (min 5) |  |
| H | ecc | RANDOM_PART4 | 100/100 | 7.22 | 7.22 | 10.48 | 68.8 % | 6.99 | 5.18 (min 4) | ~ |
| L | L2 | RANDOM_PART4 | 100/100 | 10.42 | 10.42 | 10.48 | 99.4 % |  | 4.52 (min 4) |  |
| H | ecc_L2 | RANDOM_PART4 | 100/100 | 5.41 | 5.41 | 8.00 | 67.6 % | 5.24 | 6.93 (min 5) | ~ |
| J | nb1 | SEQ_LINE | 100/100 | 15.99 | 15.99 | 16.00 | 100.0 % |  | 6.00 (min 3) |  |
| J | nb1 | OWN_BANK | 100/100 | 15.99 | 15.99 | 16.00 | 100.0 % |  | 6.00 (min 3) |  |
| J | nb1 | RANDOM_LINE | 100/100 | 15.99 | 15.99 | 16.00 | 100.0 % |  | 6.00 (min 3) |  |
| J | nb2 | SEQ_LINE | 100/100 | 31.95 | 31.95 | 32.00 | 99.9 % |  | 4.00 (min 3) |  |
| J | nb2 | OWN_BANK | 100/100 | 31.97 | 31.97 | 32.00 | 99.9 % |  | 4.00 (min 3) |  |
| J | nb2 | RANDOM_LINE | 100/100 | 27.74 | 27.74 | 28.00 | 99.1 % |  | 4.29 (min 3) |  |
| J | base | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| J | base | OWN_BANK | 100/100 | 63.87 | 63.87 | 64.00 | 99.8 % |  | 3.00 (min 3) |  |
| J | base | RANDOM_LINE | 100/100 | 41.29 | 41.29 | 41.94 | 98.5 % |  | 3.53 (min 3) |  |
| J | nb8 | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| J | nb8 | OWN_BANK | 100/100 | 63.87 | 63.87 | 64.00 | 99.8 % |  | 3.00 (min 3) |  |
| J | nb8 | RANDOM_LINE | 100/100 | 51.36 | 51.36 | 52.24 | 98.3 % |  | 3.23 (min 3) |  |
| J | nm2_nb4 | SEQ_LINE | 100/100 | 31.90 | 31.90 | 32.00 | 99.7 % |  | 3.00 (min 3) |  |
| J | nm2_nb4 | OWN_BANK | 100/100 | 31.94 | 31.94 | 32.00 | 99.8 % |  | 3.00 (min 3) |  |
| J | nm2_nb4 | RANDOM_LINE | 100/100 | 27.68 | 27.68 | 28.00 | 98.9 % |  | 3.15 (min 3) |  |
| J | nm8_nb4 | SEQ_LINE | 100/100 | 63.84 | 63.84 | 64.00 | 99.8 % |  | 4.00 (min 3) |  |
| J | nm8_nb4 | OWN_BANK | 100/100 | 63.94 | 63.94 | 64.00 | 99.9 % |  | 4.00 (min 3) |  |
| J | nm8_nb4 | RANDOM_LINE | 100/100 | 52.14 | 52.14 | 52.25 | 99.8 % |  | 4.42 (min 3) |  |
| J | nm8_nb8 | SEQ_LINE | 100/100 | 126.86 | 126.86 | 128.00 | 99.1 % |  | 3.00 (min 3) |  |
| J | nm8_nb8 | OWN_BANK | 100/100 | 127.74 | 127.74 | 128.00 | 99.8 % |  | 3.00 (min 3) |  |
| J | nm8_nb8 | RANDOM_LINE | 100/100 | 76.33 | 76.33 | 79.15 | 96.4 % |  | 3.62 (min 3) |  |
| J | d64 | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| J | d64 | OWN_BANK | 100/100 | 63.87 | 63.87 | 64.00 | 99.8 % |  | 3.00 (min 3) |  |
| J | d64 | RANDOM_LINE | 100/100 | 41.29 | 41.29 | 41.94 | 98.5 % |  | 3.53 (min 3) |  |
| J | d1024 | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| J | d1024 | OWN_BANK | 100/100 | 63.87 | 63.87 | 64.00 | 99.8 % |  | 3.00 (min 3) |  |
| J | d1024 | RANDOM_LINE | 100/100 | 41.29 | 41.29 | 41.94 | 98.5 % |  | 3.53 (min 3) |  |
| J | d4096 | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| J | d4096 | OWN_BANK | 100/100 | 63.87 | 63.87 | 64.00 | 99.8 % |  | 3.00 (min 3) |  |
| J | d4096 | RANDOM_LINE | 100/100 | 41.29 | 41.29 | 41.94 | 98.5 % |  | 3.53 (min 3) |  |
| S | base | RANDOM_LINE | 100/5 | 3.10 | 3.10 | 3.20 | 96.8 % |  | 3.02 (min 3) |  |
| S | base | SEQ_LINE | 100/5 | 3.10 | 3.10 | 3.20 | 96.8 % |  | 3.02 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/5 | 3.09 | 3.09 | 3.20 | 96.6 % |  | 3.01 (min 3) |  |
| S | base | RANDOM_LINE | 100/10 | 6.10 | 6.10 | 6.40 | 95.4 % |  | 3.05 (min 3) |  |
| S | base | SEQ_LINE | 100/10 | 6.11 | 6.11 | 6.40 | 95.5 % |  | 3.05 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/10 | 6.17 | 6.17 | 6.40 | 96.4 % |  | 3.02 (min 3) |  |
| S | base | RANDOM_LINE | 100/20 | 12.23 | 12.23 | 12.80 | 95.6 % |  | 3.09 (min 3) |  |
| S | base | SEQ_LINE | 100/20 | 12.35 | 12.35 | 12.80 | 96.5 % |  | 3.07 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/20 | 12.53 | 12.53 | 12.80 | 97.9 % |  | 3.04 (min 3) |  |
| S | base | RANDOM_LINE | 100/30 | 17.51 | 17.51 | 19.20 | 91.2 % |  | 3.13 (min 3) |  |
| S | base | SEQ_LINE | 100/30 | 17.52 | 17.52 | 19.20 | 91.2 % |  | 3.11 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/30 | 18.08 | 18.08 | 19.20 | 94.2 % |  | 3.06 (min 3) |  |
| S | base | RANDOM_LINE | 100/40 | 22.17 | 22.17 | 25.60 | 86.6 % |  | 3.19 (min 3) |  |
| S | base | SEQ_LINE | 100/40 | 22.85 | 22.85 | 25.60 | 89.3 % |  | 3.15 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/40 | 23.46 | 23.46 | 25.60 | 91.6 % |  | 3.08 (min 3) |  |
| S | base | RANDOM_LINE | 100/50 | 28.06 | 28.06 | 32.00 | 87.7 % |  | 3.25 (min 3) |  |
| S | base | SEQ_LINE | 100/50 | 28.97 | 28.97 | 32.00 | 90.5 % |  | 3.17 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/50 | 29.88 | 29.88 | 32.00 | 93.4 % |  | 3.11 (min 3) |  |
| S | base | RANDOM_LINE | 100/60 | 31.78 | 31.78 | 38.40 | 82.8 % |  | 3.33 (min 3) |  |
| S | base | SEQ_LINE | 100/60 | 33.86 | 33.86 | 38.40 | 88.2 % |  | 3.19 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/60 | 34.76 | 34.76 | 38.40 | 90.5 % |  | 3.13 (min 3) |  |
| S | base | RANDOM_LINE | 100/80 | 37.34 | 37.34 | 41.94 | 89.0 % |  | 3.43 (min 3) |  |
| S | base | SEQ_LINE | 100/80 | 43.39 | 43.39 | 51.20 | 84.7 % |  | 3.19 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/80 | 44.02 | 44.02 | 51.20 | 86.0 % |  | 3.17 (min 3) |  |
| S | base | RANDOM_LINE | 100/100 | 41.29 | 41.29 | 41.94 | 98.5 % |  | 3.53 (min 3) |  |
| S | base | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| S | nb8 | RANDOM_LINE | 100/100 | 51.36 | 51.36 | 52.24 | 98.3 % |  | 3.23 (min 3) |  |
| Q | slot2 | SEQ_LINE | 100/100 | 42.55 | 42.55 | 42.67 | 99.7 % |  | 3.50 (min 3) |  |
| Q | slot2 | SEQ_LINE | 50/100 | 25.74 | 25.74 | 27.43 | 93.9 % |  | 6.18 (min 3) |  |
| Q | slot2 | SEQ_LINE | 20/100 | 11.93 | 11.93 | 12.39 | 96.3 % |  | 14.82 (min 3) |  |
| Q | slot2 | SEQ_LINE | 10/100 | 6.33 | 6.33 | 6.34 | 99.8 % |  | 29.16 (min 3) |  |
| Q | slot4 | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| Q | slot4 | SEQ_LINE | 50/100 | 31.11 | 31.11 | 32.00 | 97.2 % |  | 8.75 (min 3) |  |
| Q | slot4 | SEQ_LINE | 20/100 | 12.31 | 12.31 | 12.80 | 96.2 % |  | 24.65 (min 3) |  |
| Q | slot4 | SEQ_LINE | 10/100 | 6.41 | 6.41 | 6.40 | 100.2 % |  | 48.47 (min 3) |  |
| Q | base | SEQ_LINE | 100/100 | 63.68 | 63.68 | 64.00 | 99.5 % |  | 3.00 (min 3) |  |
| Q | base | SEQ_LINE | 50/100 | 31.30 | 31.30 | 32.00 | 97.8 % |  | 16.75 (min 3) |  |
| Q | base | SEQ_LINE | 20/100 | 12.31 | 12.31 | 12.80 | 96.2 % |  | 45.12 (min 3) |  |
| Q | base | SEQ_LINE | 10/100 | 6.41 | 6.41 | 6.40 | 100.2 % |  | 87.89 (min 3) |  |
| F | base | RANDOM_LINE | 100/100 | 41.40 | 41.40 | 41.94 | 98.7 % |  | 3.52 (min 3) |  |
| F | base | RANDOM_LINE | 100/100 | 41.64 | 41.64 | 41.94 | 99.3 % |  | 3.52 (min 3) |  |
| F | base | RANDOM_LINE | 100/100 | 42.33 | 42.33 | 41.94 | 100.9 % |  | 3.50 (min 3) |  |
| L | L3 | SEQ_LINE | 100/100 | 63.56 | 63.56 | 64.00 | 99.3 % |  | 5.00 (min 5) |  |
| L | L3 | RANDOM_LINE | 100/100 | 41.24 | 41.24 | 41.94 | 98.3 % |  | 5.53 (min 5) |  |
| L | L3 | SEQ_WRITE_PART4 | 100/100 | 15.89 | 15.89 | 16.00 | 99.3 % |  | 5.00 (min 5) |  |

Efficiency slightly above 100 % has two harmless causes: (a) deterministic patterns, at most ~0.2 %: the TB measures from the first presentation to the last response (finite-run end effect), the ceiling is a steady-state rate; (b) random patterns, up to ~1-2 %: the ceiling is an EXPECTATION and a 1000-request sample fluctuates around it (MODEL, 40 seeds: std 0.3 B/c = 0.7 %; 20000 requests/master converge to 41.84 B/c vs the exact chain 41.94 B/c). Efficiencies clearly below 100 % are explained row by row in section 3 (head-of-line blocking, lock-step conflicts, RMW occupancy, ALIGN errors).

## 3. Experiments A-J, S, Q (RTL-SIMULATION | MODEL | ANALYTICAL)

### 3.1 A/B/D/E/F - RTL-SIMULATION | MODEL | ANALYTICAL for the nine workload patterns, base configuration (NM=4, NB=4, DEPTH=256, READ_LATENCY=1, no ECC, round robin)

| # | pattern | RTL B/c | MODEL B/c | ANALYTICAL B/c | RTL/ceiling | RTL conflict cycles | ceiling basis |
|---|---|---|---|---|---|---|---|
| 0 | SEQ_SCALAR4 | 15.97 | 15.97 | 16.00 | 99.8 % | 0 | scalar 4 B loads through whole-line accesses: each access = 1 bank cycle; bound NB acc/c = 16 B/c (25% of line peak) |
| 1 | SEQ_LINE | 63.68 | 63.68 | 64.00 | 99.5 % | 3 | conflict-free steady state (masters self-skew by one bank): min(NM x slot ceiling, NB x bank rate) |
| 2 | OWN_BANK | 63.87 | 63.87 | 64.00 | 99.8 % | 0 | master m -> bank m mod NB: min(NM x slot ceiling, NB x bank rate) |
| 3 | SAME_BANK | 15.99 | 15.99 | 16.00 | 100.0 % | 3999 | all masters on one bank: 1 acc/c x bank rate (F3) |
| 4 | RANDOM_LINE | 41.29 | 41.29 | 41.94 | 98.5 % | 1631 | head-of-line Markov chain (F4), exact for iid destinations |
| 5 | RANDOM_RW | 41.72 | 41.72 | 41.94 | 99.5 % | 1634 | head-of-line Markov chain (F4), exact for iid destinations |
| 6 | SEQ_WRITE_FULL | 63.68 | 63.68 | 64.00 | 99.5 % | 3 | conflict-free steady state (masters self-skew by one bank): min(NM x slot ceiling, NB x bank rate) |
| 7 | SEQ_WRITE_PART4 | 15.92 | 15.92 | 16.00 | 99.5 % | 3 | partial writes: NB x 1/(RL+1) with ECC (F5), else conflict-free like pattern 1 |
| 8 | RANDOM_PART4 | 10.43 | 10.43 | 10.48 | 99.5 % | 1634 | head-of-line Markov chain (F4), exact for iid destinations |

*Benchmark A (pattern 0) is a line-aligned scalar workload:* every 4 B load is a whole 16 B line access (four consecutive loads of one master hit the same line, masters are staggered by one line = one bank), so the useful-byte ceiling of the 4 B patterns is 4 B x accesses/cycle (25 % of the line peak). A byte-strided variant that the ALIGN_MODE=1 controller mostly rejects exists only in the model (pattern 9).

### 3.2 H - ECC overhead (RTL-SIMULATION ratios vs MODEL vs ANALYTICAL)

| RL | pattern | RTL B/c no-ECC | RTL B/c ECC | RTL ratio | MODEL ratio | ANALYTICAL ratio | mean latency (RTL) | RTL busy stalls | MODEL busy stalls |
|---|---|---|---|---|---|---|---|---|---|
| 1 | SEQ_SCALAR4 | 15.97 | 15.95 | 0.999 | 0.999 | 1.000 | 3.00 -> 4.00 | 0 | 0 |
| 1 | SEQ_LINE | 63.68 | 63.62 | 0.999 | 0.999 | 1.000 | 3.00 -> 4.00 | 0 | 0 |
| 1 | OWN_BANK | 63.87 | 63.81 | 0.999 | 0.999 | 1.000 | 3.00 -> 4.00 | 0 | 0 |
| 1 | SAME_BANK | 15.99 | 15.99 | 1.000 | 1.000 | 1.000 | 6.00 -> 7.00 | 0 | 0 |
| 1 | RANDOM_LINE | 41.29 | 41.26 | 0.999 | 0.999 | 1.000 | 3.53 -> 4.53 | 0 | 0 |
| 1 | RANDOM_RW | 41.72 | 41.69 | 0.999 | 0.999 | 1.000 | 3.52 -> 4.52 | 0 | 0 |
| 1 | SEQ_WRITE_FULL | 63.68 | 63.62 | 0.999 | 0.999 | 1.000 | 3.00 -> 4.00 | 0 | 0 |
| 1 | SEQ_WRITE_PART4 | 15.92 | 7.98 | 0.501 | 0.501 | 0.500 | 3.00 -> 5.00 | 999 | 999 |
| 1 | RANDOM_PART4 | 10.43 | 7.22 | 0.692 | 0.692 | 1.000 | 3.52 -> 5.18 | 1407 | 1407 |
| 2 | SEQ_SCALAR4 | 15.95 | 15.94 | 0.999 | 0.999 | 1.000 | 4.00 -> 5.00 | 0 | 0 |
| 2 | SEQ_LINE | 63.62 | 63.56 | 0.999 | 0.999 | 1.000 | 4.00 -> 5.00 | 0 | 0 |
| 2 | OWN_BANK | 63.81 | 63.74 | 0.999 | 0.999 | 1.000 | 4.00 -> 5.00 | 0 | 0 |
| 2 | SAME_BANK | 15.99 | 15.98 | 1.000 | 1.000 | 1.000 | 7.00 -> 8.00 | 0 | 0 |
| 2 | RANDOM_LINE | 41.26 | 41.24 | 0.999 | 0.999 | 1.000 | 4.53 -> 5.53 | 0 | 0 |
| 2 | RANDOM_RW | 41.69 | 41.67 | 0.999 | 0.999 | 1.000 | 4.52 -> 5.52 | 0 | 0 |
| 2 | SEQ_WRITE_FULL | 63.62 | 63.56 | 0.999 | 0.999 | 1.000 | 4.00 -> 5.00 | 0 | 0 |
| 2 | SEQ_WRITE_PART4 | 15.90 | 5.32 | 0.335 | 0.335 | 0.333 | 4.00 -> 7.00 | 1998 | 1998 |
| 2 | RANDOM_PART4 | 10.42 | 5.41 | 0.519 | 0.519 | 0.763 | 4.52 -> 6.93 | 2927 | 2927 |

ECC adds exactly one cycle of latency (BANK_LAT = READ_LATENCY+1) and costs bandwidth only for partial writes: every partial write occupies its bank READ_LATENCY+1 cycles (SEQ_WRITE_PART4: ratio ~0.5 at RL=1, ~0.33 at RL=2 = 1/(RL+1), the ANALYTICAL value), RANDOM_PART4 (50 % partial writes) is limited to 1/(1+0.5 RL) of the bank rate before head-of-line effects (approximate). Read- and full-line-write patterns are unchanged except for the one-cycle latency.

### 3.3 J - capacity, bank-count and master-count sweeps

**Bank count (NM = 4)** - RTL-SIMULATION | MODEL | ANALYTICAL:

| pattern (1 SEQ_LINE, 2 OWN_BANK, 4 RANDOM_LINE) | NB | RTL B/c | MODEL B/c | ANALYTICAL B/c | RTL/ceiling |
|---|---|---|---|---|---|
| 1 | 1 | 15.99 | 15.99 | 16.00 | 100.0 % |
| 1 | 2 | 31.95 | 31.95 | 32.00 | 99.9 % |
| 1 | 4 | 63.68 | 63.68 | 64.00 | 99.5 % |
| 1 | 8 | 63.68 | 63.68 | 64.00 | 99.5 % |
| 2 | 1 | 15.99 | 15.99 | 16.00 | 100.0 % |
| 2 | 2 | 31.97 | 31.97 | 32.00 | 99.9 % |
| 2 | 4 | 63.87 | 63.87 | 64.00 | 99.8 % |
| 2 | 8 | 63.87 | 63.87 | 64.00 | 99.8 % |
| 4 | 1 | 15.99 | 15.99 | 16.00 | 100.0 % |
| 4 | 2 | 27.74 | 27.74 | 28.00 | 99.1 % |
| 4 | 4 | 41.29 | 41.29 | 41.94 | 98.5 % |
| 4 | 8 | 51.36 | 51.36 | 52.24 | 98.3 % |

**Master count** - RTL-SIMULATION | MODEL | ANALYTICAL:

| pattern | config | NM | NB | RTL B/c | MODEL B/c | ANALYTICAL B/c | RTL/ceiling |
|---|---|---|---|---|---|---|---|
| 1 | nm2_nb4 | 2 | 4 | 31.90 | 31.90 | 32.00 | 99.7 % |
| 1 | base | 4 | 4 | 63.68 | 63.68 | 64.00 | 99.5 % |
| 1 | nm8_nb4 | 8 | 4 | 63.84 | 63.84 | 64.00 | 99.8 % |
| 1 | nm8_nb8 | 8 | 8 | 126.86 | 126.86 | 128.00 | 99.1 % |
| 2 | nm2_nb4 | 2 | 4 | 31.94 | 31.94 | 32.00 | 99.8 % |
| 2 | base | 4 | 4 | 63.87 | 63.87 | 64.00 | 99.8 % |
| 2 | nm8_nb4 | 8 | 4 | 63.94 | 63.94 | 64.00 | 99.9 % |
| 2 | nm8_nb8 | 8 | 8 | 127.74 | 127.74 | 128.00 | 99.8 % |
| 4 | nm2_nb4 | 2 | 4 | 27.68 | 27.68 | 28.00 | 98.9 % |
| 4 | base | 4 | 4 | 41.29 | 41.29 | 41.94 | 98.5 % |
| 4 | nm8_nb4 | 8 | 4 | 52.14 | 52.14 | 52.25 | 99.8 % |
| 4 | nm8_nb8 | 8 | 8 | 76.33 | 76.33 | 79.15 | 96.4 % |

**Capacity (NB = 4; DEPTH 64 / 256 / 1024 / 4096 rows = 4 / 16 / 64 / 256 KiB)** - capacity does not enter any ceiling, and the RTL results are IDENTICAL for the four capacities: the workloads' bank sequences depend only on the low line-address bits (CAP_LINES = NB x DEPTH is a power of two, so `draw mod CAP_LINES` has the same low bits), not on DEPTH:

| pattern | DEPTH | KiB | RTL B/c | MODEL B/c | RTL conflict cycles |
|---|---|---|---|---|---|
| 1 | 64 | 4 | 63.68 | 63.68 | 3 |
| 1 | 256 | 16 | 63.68 | 63.68 | 3 |
| 1 | 1024 | 64 | 63.68 | 63.68 | 3 |
| 1 | 4096 | 256 | 63.68 | 63.68 | 3 |
| 2 | 64 | 4 | 63.87 | 63.87 | 0 |
| 2 | 256 | 16 | 63.87 | 63.87 | 0 |
| 2 | 1024 | 64 | 63.87 | 63.87 | 0 |
| 2 | 4096 | 256 | 63.87 | 63.87 | 0 |
| 4 | 64 | 4 | 41.29 | 41.29 | 1631 |
| 4 | 256 | 16 | 41.29 | 41.29 | 1631 |
| 4 | 1024 | 64 | 41.29 | 41.29 | 1631 |
| 4 | 4096 | 256 | 41.29 | 41.29 | 1631 |

Plots: `sramlab_throughput_vs_banks.svg`, `sramlab_throughput_vs_masters.svg`.

### 3.4 S - saturation (offered load): RTL-SIMULATION | MODEL | ANALYTICAL

| config | pattern | load % | RTL B/c | MODEL B/c | ANALYTICAL min(offered, saturation) B/c | RTL/ceiling | RTL mean latency |
|---|---|---|---|---|---|---|---|
| base | 4 | 5 | 3.10 | 3.10 | 3.20 | 96.8 % | 3.02 |
| base | 1 | 5 | 3.10 | 3.10 | 3.20 | 96.8 % | 3.02 |
| nb8 | 4 | 5 | 3.09 | 3.09 | 3.20 | 96.6 % | 3.01 |
| base | 4 | 10 | 6.10 | 6.10 | 6.40 | 95.4 % | 3.05 |
| base | 1 | 10 | 6.11 | 6.11 | 6.40 | 95.5 % | 3.05 |
| nb8 | 4 | 10 | 6.17 | 6.17 | 6.40 | 96.4 % | 3.02 |
| base | 4 | 20 | 12.23 | 12.23 | 12.80 | 95.6 % | 3.09 |
| base | 1 | 20 | 12.35 | 12.35 | 12.80 | 96.5 % | 3.07 |
| nb8 | 4 | 20 | 12.53 | 12.53 | 12.80 | 97.9 % | 3.04 |
| base | 4 | 30 | 17.51 | 17.51 | 19.20 | 91.2 % | 3.13 |
| base | 1 | 30 | 17.52 | 17.52 | 19.20 | 91.2 % | 3.11 |
| nb8 | 4 | 30 | 18.08 | 18.08 | 19.20 | 94.2 % | 3.06 |
| base | 4 | 40 | 22.17 | 22.17 | 25.60 | 86.6 % | 3.19 |
| base | 1 | 40 | 22.85 | 22.85 | 25.60 | 89.3 % | 3.15 |
| nb8 | 4 | 40 | 23.46 | 23.46 | 25.60 | 91.6 % | 3.08 |
| base | 4 | 50 | 28.06 | 28.06 | 32.00 | 87.7 % | 3.25 |
| base | 1 | 50 | 28.97 | 28.97 | 32.00 | 90.5 % | 3.17 |
| nb8 | 4 | 50 | 29.88 | 29.88 | 32.00 | 93.4 % | 3.11 |
| base | 4 | 60 | 31.78 | 31.78 | 38.40 | 82.8 % | 3.33 |
| base | 1 | 60 | 33.86 | 33.86 | 38.40 | 88.2 % | 3.19 |
| nb8 | 4 | 60 | 34.76 | 34.76 | 38.40 | 90.5 % | 3.13 |
| base | 4 | 80 | 37.34 | 37.34 | 41.94 | 89.0 % | 3.43 |
| base | 1 | 80 | 43.39 | 43.39 | 51.20 | 84.7 % | 3.19 |
| nb8 | 4 | 80 | 44.02 | 44.02 | 51.20 | 86.0 % | 3.17 |
| base | 4 | 100 | 41.29 | 41.29 | 41.94 | 98.5 % | 3.53 |
| base | 1 | 100 | 63.68 | 63.68 | 64.00 | 99.5 % | 3.00 |
| nb8 | 4 | 100 | 51.36 | 51.36 | 52.24 | 98.3 % | 3.23 |

The ANALYTICAL ceiling is the asymptote min(NM x load, saturation). Up to 20 % offered load both patterns follow it within 3-5 %. Between 30 % and 80 % SEQ_LINE falls to 85-91 % of the asymptote and RANDOM_LINE to 83-91 %: the random idle gaps of the offered-load gate desynchronise the masters, so the one-bank skew that makes SEQ_LINE conflict-free at 100 % load is lost (RTL conflict cycles for SEQ_LINE: 3 at 100 % load, 418-755 at 30-80 %) and bank queueing appears before saturation; RANDOM_LINE additionally suffers head-of-line blocking (persistent destinations). At 100 % the masters self-skew again (SEQ_LINE 99.5 %). Plot: `sramlab_throughput_vs_load.svg`.

### 3.5 Q - queue occupancy vs response back-pressure and slot count (SEQ_LINE): RTL-SIMULATION | MODEL | ANALYTICAL

| config | NSLOT | rsp ready % | RTL B/c | MODEL B/c | ANALYTICAL B/c | RTL/ceiling | RTL max outstanding (master 0) | RTL mean latency | MODEL mean slot occupancy (master 0) |
|---|---|---|---|---|---|---|---|---|---|
| slot2 | 2 | 100 | 42.55 | 42.55 | 42.67 | 99.7 % | 2 | 3.50 | 1.33 |
| slot2 | 2 | 50 | 25.74 | 25.74 | 27.43 | 93.9 % | 2 | 6.18 | 1.50 |
| slot2 | 2 | 20 | 11.93 | 11.93 | 12.39 | 96.3 % | 2 | 14.82 | 1.77 |
| slot2 | 2 | 10 | 6.33 | 6.33 | 6.34 | 99.8 % | 2 | 29.16 | 1.89 |
| slot4 | 4 | 100 | 63.68 | 63.68 | 64.00 | 99.5 % | 3 | 3.00 | 1.99 |
| slot4 | 4 | 50 | 31.11 | 31.11 | 32.00 | 97.2 % | 4 | 8.75 | 3.29 |
| slot4 | 4 | 20 | 12.31 | 12.31 | 12.80 | 96.2 % | 4 | 24.65 | 3.73 |
| slot4 | 4 | 10 | 6.41 | 6.41 | 6.40 | 100.2 % | 4 | 48.47 | 3.89 |
| base | 8 | 100 | 63.68 | 63.68 | 64.00 | 99.5 % | 3 | 3.00 | 1.99 |
| base | 8 | 50 | 31.30 | 31.30 | 32.00 | 97.8 % | 8 | 16.75 | 7.25 |
| base | 8 | 20 | 12.31 | 12.31 | 12.80 | 96.2 % | 8 | 45.12 | 7.66 |
| base | 8 | 10 | 6.41 | 6.41 | 6.40 | 100.2 % | 8 | 87.89 | 7.87 |

ANALYTICAL = 4 x the exact single-master Markov chain throughput (`slot_ceiling_markov`): NSLOT=2 gives 2/3 of the port rate (BANK_LAT+2 = 3), NSLOT >= 3 sustains 1 access/cycle; with random response-ready the chain gives the exact single-master rate, the 4-master RTL runs sit a few percent below it because response back-pressure desynchronises the masters and re-introduces bank conflicts (counted by the model and the RTL).

### 3.6 Bank-conflict analysis (base configuration; MODEL, with RTL-SIMULATION perf counters where an instrumented run exists)

| ECC | pattern | MODEL conflict cycles / bank | RTL conflict cycles / bank | MODEL busy stalls / bank | MODEL stall cycles / master | MODEL stall split slot/busy/arbitration | RTL stall cycles / master | RTL counters == MODEL |
|---|---|---|---|---|---|---|---|---|
| 0 | SEQ_SCALAR4 | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | 0/0/0 | [0, 0, 0, 0] | yes |
| 0 | SEQ_LINE | [3, 0, 0, 0] | [3, 0, 0, 0] | [0, 0, 0, 0] | [0, 1, 2, 3] | 0/0/6 | [0, 1, 2, 3] | yes |
| 0 | OWN_BANK | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | 0/0/0 | [0, 0, 0, 0] | yes |
| 0 | SAME_BANK | [3999, 0, 0, 0] | [3999, 0, 0, 0] | [0, 0, 0, 0] | [2997, 2998, 2999, 3000] | 0/0/11994 | [2997, 2998, 2999, 3000] | yes |
| 0 | RANDOM_LINE | [384, 414, 419, 414] | [384, 414, 419, 414] | [0, 0, 0, 0] | [502, 548, 547, 527] | 0/0/2124 | [502, 548, 547, 527] | yes |
| 0 | RANDOM_RW | [424, 369, 390, 451] | [424, 369, 390, 451] | [0, 0, 0, 0] | [497, 532, 516, 523] | 0/0/2068 | [497, 532, 516, 523] | yes |
| 0 | SEQ_WRITE_FULL | [3, 0, 0, 0] | [3, 0, 0, 0] | [0, 0, 0, 0] | [0, 1, 2, 3] | 0/0/6 | [0, 1, 2, 3] | yes |
| 0 | SEQ_WRITE_PART4 | [3, 0, 0, 0] | [3, 0, 0, 0] | [0, 0, 0, 0] | [0, 1, 2, 3] | 0/0/6 | [0, 1, 2, 3] | yes |
| 0 | RANDOM_PART4 | [424, 369, 390, 451] | [424, 369, 390, 451] | [0, 0, 0, 0] | [497, 532, 516, 523] | 0/0/2068 | [497, 532, 516, 523] | yes |
| 1 | SEQ_SCALAR4 | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | 0/0/0 | [0, 0, 0, 0] | yes |
| 1 | SEQ_LINE | [3, 0, 0, 0] | [3, 0, 0, 0] | [0, 0, 0, 0] | [0, 1, 2, 3] | 0/0/6 | [0, 1, 2, 3] | yes |
| 1 | OWN_BANK | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | [0, 0, 0, 0] | 0/0/0 | [0, 0, 0, 0] | yes |
| 1 | SAME_BANK | [3999, 0, 0, 0] | [3999, 0, 0, 0] | [0, 0, 0, 0] | [2997, 2998, 2999, 3000] | 0/0/11994 | [2997, 2998, 2999, 3000] | yes |
| 1 | RANDOM_LINE | [384, 414, 419, 414] | [384, 414, 419, 414] | [0, 0, 0, 0] | [502, 548, 547, 527] | 0/0/2124 | [502, 548, 547, 527] | yes |
| 1 | RANDOM_RW | [424, 369, 390, 451] | [424, 369, 390, 451] | [0, 0, 0, 0] | [497, 532, 516, 523] | 0/0/2068 | [497, 532, 516, 523] | yes |
| 1 | SEQ_WRITE_FULL | [3, 0, 0, 0] | [3, 0, 0, 0] | [0, 0, 0, 0] | [0, 1, 2, 3] | 0/0/6 | [0, 1, 2, 3] | yes |
| 1 | SEQ_WRITE_PART4 | [1997, 0, 0, 0] | [1997, 0, 0, 0] | [999, 0, 0, 0] | [996, 998, 1000, 1002] | 0/1998/1998 | [996, 998, 1000, 1002] | yes |
| 1 | RANDOM_PART4 | [596, 595, 533, 671] | [596, 595, 533, 671] | [358, 367, 320, 362] | [1167, 1214, 1198, 1146] | 0/2315/2410 | [1167, 1214, 1198, 1146] | yes |

Per-master stall cycles (`perf_stall`) are `valid && !ready` cycles; the MODEL splits them into no-free-slot, bank-busy (RMW) and lost-arbitration cycles. SAME_BANK concentrates all conflict on bank 0; OWN_BANK has none; SEQ_LINE only the start-up skew.

**Fairness (O6)**, SAME_BANK, NM=4, finite 1000 requests per master (MODEL; the perf_stall counters of the instrumented fixed-priority runs equal the MODEL):

| arbitration | grants per master | max grants of the bank given to others while waiting (MODEL) | mean latency per master (MODEL; RTL: 6.0 RR, 4.5 mean FIXED) | ANALYTICAL mean latency: RR NM+BL+1, FIXED BL+2+i | stall cycles per master (MODEL) |
|---|---|---|---|---|---|
| RR | [1000, 1000, 1000, 1000] | [3, 3, 3, 3] | ['6.0', '6.0', '6.0', '6.0'] | ['6.0', '6.0', '6.0', '6.0'] | [2997, 2998, 2999, 3000] |
| FIXED | [1000, 1000, 1000, 1000] | [0, 1000, 2000, 3000] | ['3.0', '4.0', '5.0', '6.0'] | ['3.0', '4.0', '5.0', '6.0'] | [0, 1000, 2000, 3000] |

RR keeps the waiting bound NM-1 = 3 grants (contract O6 holds in this run); FIXED priority lets master 0 finish first and starves master 3 for ~3000 grants (contract: 'starvation possible').

## 4. DMA throughput and scalar/vector-versus-DMA contention

RTL-SIMULATION (reports/bench_rtl.json `vector_dma`, tb_vector_scratchpad V6): 64-beat DMA LOAD = 69 cycles alone (0.928 beats/cycle, incl. a fixed TB start/finish overhead of 5 cycles), 70 cycles with concurrent vector traffic (+1), 15 DMA/vector same-bank pulses counted by the scratchpad over the whole mixed interval.

ANALYTICAL: the single DMA port moves at most one 16 B beat per cycle, i.e. 16 B/cycle = 1/NB of the 4-bank peak (64 B/cycle); consecutive lines rotate through the banks, so alone it is port-limited, not bank-limited.

MODEL (exact controller model, 100 Monte-Carlo trials per row; competing master issues a random-bank request with probability rho per idle cycle; the vector TB's real timing is NOT modelled):

| rho (competing issue rate) | DMA cycles alone (MODEL, no TB overhead) | mean slip [cycles] | max slip | mean conflict cycles in 64 beats | DMA lost-arbitration cycles |
|---|---|---|---|---|---|
| 0.05 | 67 | 0.76 | 4 | 0.8 | 0.76 |
| 0.10 | 67 | 1.32 | 5 | 1.5 | 1.32 |
| 0.20 | 67 | 2.69 | 7 | 3.3 | 2.69 |
| 0.30 | 67 | 3.35 | 7 | 4.8 | 3.35 |
| 0.50 | 67 | 4.76 | 10 | 8.5 | 4.76 |
| 0.70 | 67 | 5.14 | 11 | 10.8 | 5.14 |
| 1.00 | 67 | 5.06 | 13 | 14.7 | 5.06 |

Reading: round-robin arbitration gives the DMA about half of the contested cycles, so even a competing master that issues EVERY cycle slows a 64-beat burst by only ~5 cycles (~8 %), and the conflict count at rho=1 (~15) is the same order as the 15 pulses of the RTL run. The RTL slip of +1 cycle corresponds to rho ~ 0.05-0.1 in the model; this is an INFERENCE from one data point (the vector stimulus overlaps only part of the DMA window and its timing is not reproduced), not a validation. DMA bandwidth is therefore bounded by the port, and a competing master costs the DMA at most about half of the cycles in which both want the same bank.

## 5. Tensor scratchpad: pipeline model, single vs double buffering, operand starvation

### 5.1 Cycle model (tensor.py) vs RTL-SIMULATION, committed rows

`cosim` = the exact controller model (4 ports A, B, C, DMA) + a transcription of the scratchpad ownership FSM and of the three TB processes (fill / compute / drain, half-cycle negedge handshakes). `phase model` = closed-form conflict-free durations (ANALYTICAL): fill Df = 3N+BL+2, drain Dd = N+BL+2, compute Dc = PASSES x (2(N+BL+2) + COMPUTE_EXTRA), a 3-cycle handshake gap per ownership change; NBUF=1: cycles/tile = Df + Dc + Dd + 9; NBUF=2: max(Dc + 3, Df + Dd + 7) when conflict free.

| config | RTL total | MODEL total | RTL cycles/tile (total/8) | MODEL cycles/tile | MODEL steady period (tiles 1..7) | ANALYTICAL conflict-free steady period | bound | ANALYTICAL phase-model total | RTL overlap | MODEL overlap | RTL conflict cycles | MODEL conflict cycles |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| nbuf2_skew1 | 629 | 629 | 78 | 78 | 73.0 | 69 | compute | 601 | 321 | 321 | 62 | 62 |
| nbuf1_skew1 | 909 | 909 | 113 | 113 | 113.0 | 113 | serial | 909 | 0 | 0 | 0 | 0 |
| nbuf2_skew0 | 662 | 662 | 82 | 82 | 77.0 | 69 | compute | 601 | 349 | 349 | 114 | 114 |
| nbuf1_skew0 | 957 | 957 | 119 | 119 | 119.0 | 113 | serial | 909 | 0 | 0 | 48 | 48 |
| nbuf2_extra16 | 1001 | 1001 | 125 | 125 | 119.0 | 117 | compute | 985 | 296 | 296 | 25 | 25 |
| nbuf1_extra16 | 1293 | 1293 | 161 | 161 | 161.0 | 161 | serial | 1293 | 0 | 0 | 0 | 0 |
| nbuf2_extra48 | 1769 | 1769 | 221 | 221 | 215.0 | 213 | compute | 1753 | 296 | 296 | 25 | 25 |
| nbuf1_extra48 | 2061 | 2061 | 257 | 257 | 257.0 | 257 | serial | 2061 | 0 | 0 | 0 | 0 |
| nbuf2_ecc | 681 | 681 | 85 | 85 | 79.0 | 75 | compute | 651 | 335 | 335 | 64 | 64 |
| nbuf2_n16 | 1047 | 1047 | 130 | 130 | 121.0 | 117 | compute | 1017 | 578 | 578 | 97 | 97 |
| nbuf1_n16 | 1549 | 1549 | 193 | 193 | 193.0 | 193 | serial | 1549 | 0 | 0 | 0 | 0 |

**Explanation of the differences.** (i) MODEL co-simulation = RTL-SIMULATION in all 11 committed rows, and in every clock edge of the instrumented traces (5.2). (ii) NBUF=1 is exactly the closed form (113 = 27 + 66 + 11 + 9 cycles/tile for N=8, PASSES=3): nothing overlaps and there are no conflicts; `cycles_per_tile` = total/NTILES also contains the 5 trailing TB cycles. (iii) NBUF=2 is compute-bound: the conflict-free steady period is 69 cycles/tile but the exact model's steady period (tiles 1..7) is 73: the DMA fill/drain of the neighbouring tiles hits the same banks as the A/B/C streams and the 62 conflict cycles delay the compute passes (+4 cycles, 5.8 %). The remaining 5 cycles/tile of the printed 78 are pipeline start-up and tail (first fill 32 cycles exposed + last drain + 5 TB cycles, amortised over only 8 tiles): the TB's `cycles_per_tile` is not the steady-state period. (iv) SKEW=0 puts A, B and C on the same bank sequence: 114 vs 62 conflict cycles (double) and 48 vs 0 (single), +4 / +6 cycles per tile (82 vs 78, 119 vs 113) - the skew is worth ~5 %. (v) ECC adds one BANK_LAT cycle to every response: +7 cycles/tile (85 vs 78). (vi) COMPUTE_EXTRA adds ~PASSES x extra cycles per tile in both modes; with larger compute the conflict stalls shrink (25 vs 62 cycles) because DMA and compute overlap less.

### 5.2 Extra RTL-SIMULATION tensor runs (instrumented copies; MODEL compared per clock edge)

| config | set | RTL total | MODEL total | RTL conflict cyc (TB print) | MODEL conflict cyc | per-edge trace identical | edges | stats equal | RTL edges te_req && !te_owned | MODEL same |
|---|---|---|---|---|---|---|---|---|---|---|
| nbuf2_skew1 | committed | 629 | 629 | 62 | 62 | yes | 624 | yes | 38 | 38 |
| nbuf1_skew1 | committed | 909 | 909 | 0 | 0 | yes | 904 | yes | 346 | 346 |
| nbuf2_skew0 | committed | 662 | 662 | 114 | 114 | yes | 657 | yes | 38 | 38 |
| nbuf1_skew0 | committed | 957 | 957 | 48 | 48 | yes | 952 | yes | 346 | 346 |
| nbuf2_extra16 | committed | 1001 | 1001 | 25 | 25 | yes | 996 | yes | 38 | 38 |
| nbuf1_extra16 | committed | 1293 | 1293 | 0 | 0 | yes | 1288 | yes | 346 | 346 |
| nbuf2_extra48 | committed | 1769 | 1769 | 25 | 25 | yes | 1764 | yes | 38 | 38 |
| nbuf1_extra48 | committed | 2061 | 2061 | 0 | 0 | yes | 2056 | yes | 346 | 346 |
| nbuf2_ecc | committed | 681 | 681 | 64 | 64 | yes | 676 | yes | 39 | 39 |
| nbuf2_n16 | committed | 1047 | 1047 | 97 | 97 | yes | 1042 | yes | 62 | 62 |
| nbuf1_n16 | committed | 1549 | 1549 | 0 | 0 | yes | 1544 | yes | 594 | 594 |
| x_nbuf2_L2 | extra | 681 | 681 | 64 | 64 | yes | 676 | yes | 39 | 39 |
| x_nbuf1_L2_ecc | extra | 1037 | 1037 | 0 | 0 | yes | 1032 | yes | 376 | 376 |
| x_nbuf2_ns4 | extra | 629 | 629 | 62 | 62 | yes | 624 | yes | 38 | 38 |
| x_nbuf2_p1_n4 | extra | 234 | 234 | 21 | 21 | yes | 229 | yes | 85 | 85 |
| x_nbuf2_p5_x5 | extra | 1181 | 1181 | 74 | 74 | yes | 1176 | yes | 38 | 38 |
| x_nbuf1_n4_skew0 | extra | 637 | 637 | 48 | 48 | yes | 632 | yes | 222 | 222 |
| x_nbuf2_n32 | extra | 1879 | 1879 | 139 | 139 | yes | 1874 | yes | 110 | 110 |
| x_nbuf2_ecc_x16 | extra | 1051 | 1051 | 25 | 25 | yes | 1046 | yes | 39 | 39 |
| x_nbuf2_nb2 | extra | 778 | 778 | 335 | 335 | yes | 773 | yes | 38 | 38 |


### 5.3 Operand starvation (ANALYTICAL curves vs MODEL co-simulation)

Definition: the TensorCore is starved when it has requested a tile (`te_req` = 1) and no buffer is READY, beyond the minimum ownership handshake (1 cycle in steady state). ANALYTICAL steady state (`tensor.starvation`), NBUF=2: the DMA port carries fill(t+1) (3N writes) and drain(t-1) (N reads) during compute(t): t_fill = (3N-1)/beta + BL + 3, t_drain = (N-1)/beta + BL + 3, T_dma = t_fill + t_drain + 1, period = max(T_c + 3, T_dma), stall = max(0, T_dma - T_c - 3), starved fraction = stall / period. NBUF=1: every DMA cycle is exposed (stall = t_fill + t_drain + 9). beta = DMA bandwidth share: the DMA port issues at most 1 line/cycle (= 25 % of the 4-bank peak); a lower beta models a slower bus or a smaller bank-bandwidth share and is throttled in the MODEL only (DMA request issued every k = 1/beta cycles). Agreement ANALYTICAL vs MODEL over all 64 sweep points: mean |difference| of the starved fraction 0.006, maximum 0.120 (the formula ignores the bank conflicts that the MODEL includes).

| N (lines/operand tile) | DMA beat rate beta [lines/cycle] | T_dma [cycles/tile] (ANALYTICAL) | compute cycles/tile above which the prefetch is fully hidden |
|---|---|---|---|
| 8 | 1 | 39 | 36 |
| 8 | 0.5 | 69 | 66 |
| 8 | 0.25 | 129 | 126 |
| 8 | 0.125 | 249 | 246 |
| 16 | 1 | 71 | 68 |
| 16 | 0.5 | 133 | 130 |
| 16 | 0.25 | 257 | 254 |
| 16 | 0.125 | 505 | 502 |
| 32 | 1 | 135 | 132 |
| 32 | 0.5 | 261 | 258 |
| 32 | 0.25 | 513 | 510 |
| 32 | 0.125 | 1017 | 1014 |

N = 8 and N = 16 (MODEL co-simulation vs ANALYTICAL; the ANALYTICAL period ignores bank conflicts):

| N | DMA issue every k cycles | beta | compute cycles/tile | ANALYTICAL starved fraction | MODEL starved fraction | ANALYTICAL period | MODEL period (steady) |
|---|---|---|---|---|---|---|---|
| 8 | 1 | 1 | 66 | 0.000 | 0.000 | 69 | 73 |
| 8 | 1 | 1 | 114 | 0.000 | 0.000 | 117 | 119 |
| 8 | 1 | 1 | 210 | 0.000 | 0.000 | 213 | 215 |
| 8 | 1 | 1 | 354 | 0.000 | 0.000 | 357 | 359 |
| 8 | 2 | 0.5 | 66 | 0.000 | 0.000 | 69 | 82 |
| 8 | 2 | 0.5 | 114 | 0.000 | 0.000 | 117 | 126 |
| 8 | 2 | 0.5 | 210 | 0.000 | 0.000 | 213 | 220 |
| 8 | 2 | 0.5 | 354 | 0.000 | 0.000 | 357 | 364 |
| 8 | 4 | 0.25 | 66 | 0.465 | 0.442 | 129 | 132 |
| 8 | 4 | 0.25 | 114 | 0.093 | 0.061 | 129 | 132 |
| 8 | 4 | 0.25 | 210 | 0.000 | 0.000 | 213 | 216 |
| 8 | 4 | 0.25 | 354 | 0.000 | 0.000 | 357 | 360 |
| 8 | 8 | 0.125 | 66 | 0.723 | 0.711 | 249 | 256 |
| 8 | 8 | 0.125 | 114 | 0.530 | 0.527 | 249 | 256 |
| 8 | 8 | 0.125 | 210 | 0.145 | 0.155 | 249 | 256 |
| 8 | 8 | 0.125 | 354 | 0.000 | 0.000 | 357 | 360 |
| 16 | 1 | 1 | 114 | 0.000 | 0.000 | 117 | 121 |
| 16 | 1 | 1 | 258 | 0.000 | 0.000 | 261 | 263 |
| 16 | 1 | 1 | 498 | 0.000 | 0.000 | 501 | 503 |
| 16 | 2 | 0.5 | 114 | 0.120 | 0.000 | 133 | 142 |
| 16 | 2 | 0.5 | 258 | 0.000 | 0.000 | 261 | 280 |
| 16 | 2 | 0.5 | 498 | 0.000 | 0.000 | 501 | 516 |
| 16 | 4 | 0.25 | 114 | 0.545 | 0.512 | 257 | 260 |
| 16 | 4 | 0.25 | 258 | 0.000 | 0.000 | 261 | 272 |
| 16 | 4 | 0.25 | 498 | 0.000 | 0.000 | 501 | 508 |
| 16 | 8 | 0.125 | 114 | 0.768 | 0.754 | 505 | 512 |
| 16 | 8 | 0.125 | 258 | 0.483 | 0.477 | 505 | 512 |
| 16 | 8 | 0.125 | 498 | 0.008 | 0.005 | 505 | 512 |

Findings: with the benchmark's full-rate DMA (beta = 1, N = 8) the double-buffered pipeline is compute-bound as soon as the compute phase lasts >= 36 cycles per tile (PASSES=3: Dc = 66), so the TensorCore is not starved; with PASSES=1 (Dc = 22) it is DMA-bound. With Dc = 66 the DMA may slow down to beta >= 0.50 lines/cycle (half the port rate) before the TensorCore starts to wait. Single buffering exposes the whole fill + drain: 41.6 % of the tile time at N=8, PASSES=3 (ANALYTICAL; equals the RTL split 113 = 66 compute + 47 DMA / handshake). Plot: `sramlab_starvation.svg`. The RTL te_req-without-grant edges (table 5.2) are the handshake minimum plus the exposed first fill, consistent with a non-starved double-buffered pipeline.

## 6. Findings, RTL / TB / documentation issues, limitations

**Findings**

* The controller + bank behaviour is fully captured by the cycle model (tools/sramlab/model.py): 119/119 committed rows and 342/342 extra runs match exactly (statistics, per-edge masks, perf counters).
* Peak 64 B/cycle (4 banks x 16 B) is reached: SEQ_LINE 63.68 B/c = 99.5 % of the ceiling; OWN_BANK 63.87; SAME_BANK 15.99 B/c = the single-bank 16 B/c.
* Random 16 B reads reach 41.29 B/c = 98.5 % of the exact head-of-line ceiling (41.94 B/c) and only 64 % of the 64 B/c peak: persistent requests block masters; more banks than masters help (NB=8: ~3.3 acc/c vs 2.6 for NB=4), more masters than banks do not.
* The NSLOT >= BANK_LAT+2 contract rule is exact: NSLOT=2 delivers 2/3 of the full rate (42.55 vs 42.67 B/c ceiling), NSLOT >= 3 delivers the full rate; response back-pressure caps each master at the response-ready probability.
* ECC costs one latency cycle and, for partial writes only, 1/(RL+1) of the bank bandwidth (the RMW occupies the bank RL+1 cycles); reads and full-line writes are not slowed.
* Tensor pipeline: double buffering is compute-bound; the fill/drain DMA is fully hidden but the DMA/TensorCore bank conflicts stretch the steady period from 69 to 73 cycles/tile (6 %); the printed 78 cycles/tile vs 113 (single buffer) also contains the 8-tile start-up; skew = 1 saves ~5 %.
* Scalar 4 B accesses are architecturally expensive: a 4 B load costs a whole 16 B bank access (4x energy and bank time per useful byte); benchmark A originally also suffered from ALIGN errors in the TB (fixed, see below).

**RTL / TB / documentation issues found by this validation** (status in the current revision)

* FIXED - tb/tb_bench_ctrl.sv pattern 0 (SEQ_SCALAR4): generated byte-strided sub-line addresses against an ALIGN_MODE=1 controller; 3 of 4 requests were answered SF_ST_ALIGN without an array access, so benchmark A's 15.92 B/cycle credited useful bytes to rejected requests (RTL counters: 3000 error responses, 1000 array accesses). The TB now issues line-aligned reads; the old pattern is kept in the model only as pattern 9.
* FIXED (documentation) - tb/tb_bench_ctrl.sv header: `max_outstanding` is MASTER 0's maximum (max_out[0]), not a per-master maximum; the header now says so.
* FIXED - tb/tb_tensor_scratchpad.sv: bank_conflict_cycles / bank_busy_stalls added 4 slices of perf_conf / perf_busy irrespective of NB (NB=2 printed 670 instead of 335); now sums NB slices. All committed rows use NB=4 and were not affected.
* FIXED (documentation) - rtl/sf_sram_controller.sv header: m_req_ready depends on registered state AND on the other masters' requests through the arbiter (never on rsp_ready); perf_conf comment now states which requests are not counted.
* OPEN (by design) - tb/tb_tensor_scratchpad.sv `cycles_per_tile` = total_cycles / NTILES includes the pipeline start-up, the last drain and 5 trailing cycles, so it is not the steady-state period (78 printed vs 73 steady for NBUF=2, N=8). The steady-state value is derived in section 6.

**Limitations / not done**

* Only the behavioural backend is modelled (BACKEND = SF_BACKEND_BEHAV); flush, quiesce, MBIST, scrub and init timing are not modelled (not exercised by the benchmark).
* The vector-scratchpad DMA experiment is modelled only parametrically (section 4); the vector TB's stimulus timing is not reproduced.
* The starvation model with beta < 1 throttles the DMA in the MODEL only: there is no RTL run with a slower DMA.
* Energy numbers live in reports/sramlab_energy.md and are ASSUMED-PARAMETER MODEL results (the repository has no SRAM Liberty/SPICE power data).
