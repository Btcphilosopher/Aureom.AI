#!/usr/bin/env python3
"""SilicaFlux MemoryCore regression runner (Verilator 5.x, --binary --timing).

  python3 sim/run_regress.py --suite ctrl [--jobs 2] [--only NAME ...] [--out reports/regress_ctrl.json]
  python3 sim/run_regress.py --list

A SUITE is a list of CASES; a CASE is (name, testbench top, extra source files, -G overrides, extra flags).
Every case is built into build/<suite>_<name>/ and run; the RESULT line printed by the testbench is
parsed (tests/checks/errors/PASS|FAIL).  Nothing is assumed: a case passes only when the testbench printed a RESULT line
with errors=0 and PASS, the process exited 0, and no assertion / $fatal text appeared.
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES_F = os.path.join(ROOT, "sim", "files_rtl.f")
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "--assert",
          "-DSF_ASSERT", "-Wno-DECLFILENAME"]


def case(name, top, tb, over=None, extra_src=(), flags=(), run_args=()):
    return dict(name=name, top=top, tb=tb, over=over or {}, extra_src=list(extra_src), flags=list(flags),
                run_args=list(run_args))


CTRL = "tb/tb_sram_controller.sv"
SUITES = {}
SUITES["ctrl"] = [
    case("base_L1", "tb_sram_controller", CTRL, {}),
    case("L2", "tb_sram_controller", CTRL, {"READ_LATENCY": 2, "NSLOT": 8}),
    case("L3_slot6", "tb_sram_controller", CTRL, {"READ_LATENCY": 3, "NSLOT": 6}),
    case("ecc_L1", "tb_sram_controller", CTRL, {"ECC_EN": 1}),
    case("ecc_L2", "tb_sram_controller", CTRL, {"ECC_EN": 1, "READ_LATENCY": 2}),
    case("fixed_prio", "tb_sram_controller", CTRL, {"ARB": 0}),
    case("nb2_nm4", "tb_sram_controller", CTRL, {"NB": 2, "NM": 4, "DEPTH": 128}),
    case("nb8_nm4", "tb_sram_controller", CTRL, {"NB": 8, "NM": 4, "DEPTH": 32}),
    case("nm8_nb4", "tb_sram_controller", CTRL, {"NM": 8}),
    case("nm1_nb1", "tb_sram_controller", CTRL, {"NM": 1, "NB": 1, "DEPTH": 256}),
    case("no_init_poison", "tb_sram_controller", CTRL, {"INIT_ON_RESET": 0, "SIM_INIT": 2}),
    case("align_ignore", "tb_sram_controller", CTRL, {"ALIGN_MODE": 0}),
    case("nslot3", "tb_sram_controller", CTRL, {"NSLOT": 3}),
    case("depth100_nonpow2", "tb_sram_controller", CTRL, {"DEPTH": 100}),
    case("dw64", "tb_sram_controller", CTRL, {"DW": 64}),
    case("dw256_ecc", "tb_sram_controller", CTRL, {"DW": 256, "ECC_EN": 1}),
    case("seed2", "tb_sram_controller", CTRL, {"SEED": 0x5EED0002, "NRAND": 3000}),
    case("fpga_bram", "tb_sram_controller", CTRL, {"BACKEND": 1}),
    case("fpga_bram_ecc_L2", "tb_sram_controller", CTRL, {"BACKEND": 1, "ECC_EN": 1, "READ_LATENCY": 2}),
    case("asic_standin_L2", "tb_sram_controller", CTRL, {"BACKEND": 2, "READ_LATENCY": 2, "DEPTH": 256},
         extra_src=["sim_models/sky130_sram_standin.sv"]),
    case("asic_standin_ecc_L3", "tb_sram_controller", CTRL, {"BACKEND": 2, "READ_LATENCY": 3, "ECC_EN": 1, "DEPTH": 300},
         extra_src=["sim_models/sky130_sram_standin.sv"]),
]


DF = "tb/tb_datafabric.sv"
NOCF = ["-f", "sim/files_noc.f"]
SUITES["dfab"] = [
    case("dw128", "tb_datafabric", DF, {}, flags=NOCF),
    case("dw32_lanes", "tb_datafabric", DF, {"DW": 32}, flags=NOCF),
    case("dw64_lanes_np2", "tb_datafabric", DF, {"DW": 64, "NP": 2}, flags=NOCF),
    case("dw128_np2_L2", "tb_datafabric", DF, {"NP": 2, "READ_LATENCY": 2}, flags=NOCF),
    case("ecc_dw128", "tb_datafabric", DF, {"ECC_EN": 1}, flags=NOCF),
    case("nm2_idw2_ecc_L3", "tb_datafabric", DF, {"NM": 2, "IDW": 2, "ECC_EN": 1, "READ_LATENCY": 3, "NSLOT": 6}, flags=NOCF),
    case("nm4_dw128_seed2", "tb_datafabric", DF, {"NM": 4, "SEED": 0x1234567, "NRAND": 2400}, flags=NOCF),
    case("noalign_dw128", "tb_datafabric", DF, {"CHK_ALIGN": 0}, flags=NOCF),
    case("noalign_dw32_np2", "tb_datafabric", DF, {"CHK_ALIGN": 0, "DW": 32, "NP": 2}, flags=NOCF),
]


VS = "tb/tb_vector_scratchpad.sv"
SUITES["vsp"] = [
    case("vl1_inline", "tb_vector_scratchpad", VS, {}),
    case("vl1_natural", "tb_vector_scratchpad", VS, {"ALIGN_RULE": 0}),
    case("vl2", "tb_vector_scratchpad", VS, {"VEC_LINES": 2}),
    case("vl4_nb4", "tb_vector_scratchpad", VS, {"VEC_LINES": 4}),
    case("vl4_nb2_conflicts", "tb_vector_scratchpad", VS, {"VEC_LINES": 4, "NB": 2, "DEPTH": 128}),
    case("vl2_ecc_L2", "tb_vector_scratchpad", VS, {"VEC_LINES": 2, "ECC_EN": 1, "READ_LATENCY": 2}),
    case("vl1_L3_slot6", "tb_vector_scratchpad", VS, {"READ_LATENCY": 3, "NSLOT": 6, "SEED": 0x777}),
]


TS = "tb/tb_tensor_scratchpad.sv"
SUITES["tsp"] = [
    case("nbuf2_skew1", "tb_tensor_scratchpad", TS, {}),
    case("nbuf1_single", "tb_tensor_scratchpad", TS, {"NBUF": 1}),
    case("nbuf2_skew0", "tb_tensor_scratchpad", TS, {"SKEW": 0}),
    case("nbuf1_skew0", "tb_tensor_scratchpad", TS, {"NBUF": 1, "SKEW": 0}),
    case("tile6_nonpow2", "tb_tensor_scratchpad", TS, {"N": 6}),
    case("ecc_L2", "tb_tensor_scratchpad", TS, {"ECC_EN": 1, "READ_LATENCY": 2}),
    case("compute_extra16", "tb_tensor_scratchpad", TS, {"COMPUTE_EXTRA": 16}),
    case("compute_extra16_nbuf1", "tb_tensor_scratchpad", TS, {"COMPUTE_EXTRA": 16, "NBUF": 1}),
    case("nb2", "tb_tensor_scratchpad", TS, {"NB": 2, "DEPTH": 128}),
    case("n16_L3", "tb_tensor_scratchpad", TS, {"N": 16, "READ_LATENCY": 3, "NSLOT": 6, "SEED": 0x1357}),
    case("early_done", "tb_tensor_scratchpad", TS, {"EARLY_DONE": 1}),
    case("early_done_nbuf1_L2", "tb_tensor_scratchpad", TS, {"EARLY_DONE": 1, "NBUF": 1, "READ_LATENCY": 2}),
]


ECCT = "tb/tb_ecc_system.sv"
SUITES["ecc"] = [      # ECC through the whole controller path (E1-E8); fault injection compiled in by the testbench itself
    case("ecc_sys_nb2_L1", "tb_ecc_system", ECCT, {}),
    case("ecc_sys_nb2_L2", "tb_ecc_system", ECCT, {"READ_LATENCY": 2}),
    case("ecc_sys_nb4_L3", "tb_ecc_system", ECCT, {"NB": 4, "READ_LATENCY": 3, "DEPTH": 8, "SEED": 0x5EED0003}),
]


def run_cmd(cmd, cwd, timeout):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or ""), time.time() - t0
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        return 124, out + "\n[TIMEOUT]", time.time() - t0


def run_case(suite, c, build_timeout=900, run_timeout=900):
    bdir = os.path.join(ROOT, "build", f"{suite}_{c['name']}")
    shutil.rmtree(bdir, ignore_errors=True)
    gs = [f"-G{k}={v}" for k, v in c["over"].items()]
    cmd = (["verilator"] + VFLAGS + ["-f", FILES_F] + c["extra_src"] + [c["tb"], "--top-module", c["top"],
           "-Mdir", bdir, "-o", "tb.exe"] + gs + c["flags"])
    rc, out, bs = run_cmd(cmd, ROOT, build_timeout)
    res = dict(suite=suite, name=c["name"], overrides=c["over"], build_rc=rc, build_secs=round(bs, 1))
    if rc != 0 or not os.path.exists(os.path.join(bdir, "tb.exe")):
        res.update(status="BUILD-FAIL", detail=[l for l in out.splitlines() if l.startswith("%Error")][:5])
        return res
    rc, out, rs = run_cmd([os.path.join(bdir, "tb.exe")] + c["run_args"], ROOT, run_timeout)
    m = None
    for l in out.splitlines():
        if l.startswith("RESULT"):
            m = l
    kv = dict(re.findall(r"(\w+)=([^\s]+)", m)) if m else {}
    bad = [l for l in out.splitlines() if re.search(r"%Error|%Fatal|Assertion failed|\[FAIL\]|\$fatal", l)]
    ok = (m is not None and rc == 0 and kv.get("errors") == "0" and m.rstrip().endswith("PASS") and not bad)
    res.update(run_rc=rc, run_secs=round(rs, 1), result=m, checks=int(kv.get("checks", 0)), tests=int(kv.get("tests", 0)),
               errors=int(kv.get("errors", -1)) if "errors" in kv else None, status="PASS" if ok else "FAIL")
    if not ok:
        res["detail"] = (bad or out.splitlines()[-6:])[:8]
    with open(os.path.join(bdir, "run.log"), "w") as f:
        f.write(out)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", default="ctrl")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for s, cs in SUITES.items():
            print(s, [c["name"] for c in cs])
        return 0
    cases = [c for c in SUITES[a.suite] if not a.only or c["name"] in a.only]
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    with ThreadPoolExecutor(a.jobs) as ex:
        results = list(ex.map(lambda c: run_case(a.suite, c), cases))
    n_pass = sum(r["status"] == "PASS" for r in results)
    tot_checks = sum(r.get("checks", 0) for r in results)
    for r in results:
        print(f"{r['status']:10s} {r['name']:20s} checks={r.get('checks', 0):>9} build={r['build_secs']}s run={r.get('run_secs', '-')}s "
              f"{'' if r['status'] == 'PASS' else r.get('detail')}")
    print(f"SUITE {a.suite}: {n_pass}/{len(results)} cases pass, {tot_checks} checks")
    out = a.out or os.path.join(ROOT, "reports", f"regress_{a.suite}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    json.dump(dict(suite=a.suite, passed=n_pass, total=len(results), checks=tot_checks, cases=results,
                   verilator=subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip()),
              open(out, "w"), indent=1)
    return 0 if n_pass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
