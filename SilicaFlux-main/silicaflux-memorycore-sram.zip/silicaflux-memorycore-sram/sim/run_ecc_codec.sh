#!/bin/bash
# Build and run tb_ecc_codec for K = 128, 64, 32 (vectors from tools/ecc/secded_ref.py).
set -u
cd "$(dirname "$0")/.."
mkdir -p build/ecc_codec
run_one() {
  local k="$1" nenc="$2" nerr="$3"
  verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -f sim/files_rtl.f tb/tb_ecc_codec.sv \
    --top-module tb_ecc_codec -GK="$k" -GNENC="$nenc" -GNERR="$nerr" -Mdir "build/ecc_codec/k$k" -o t.exe > "build/ecc_codec/k$k.build.log" 2>&1 || {
      echo "RESULT tb=ecc_codec K=$k errors=1 BUILD FAIL"; return 1; }
  "build/ecc_codec/k$k/t.exe" | tee "build/ecc_codec/k$k.run.log" | grep -E 'CONFIG|single-bit|RESULT|FAIL'
}
run_one 128 400 4000
run_one 64 200 2000
run_one 32 100 1000
