#!/usr/bin/env python3
"""check_asic_collateral.py -- which ASIC-use views of the SRAM macros does this repository actually CONTAIN?

For each macro family used by the floorplans (SKY130 OpenRAM 1RW1R, IHP SG13G2 1P, GF180MCU 1RW) it takes the
`views` / `provenance.files` lists from the macro manifests (paths in the UPSTREAM vendor repos) and looks for
files with those names anywhere under the extracted repository (audit tree).  It also scans the whole tree for
LEF / GDS / Liberty / SPICE / CDL / DEF / technology files regardless of name.  Nothing from the tree is executed;
files are only listed (os.walk) and, for the stub check, stat-ed.

Output: asic_collateral_check.json (always) and, with --write-md, asic_readiness.md.
Exit status: 0 (report generated).  With --strict: 1 if any required view is missing (i.e. NOT ASIC-ready).

Conclusion this script supports: GEOMETRY-LEVEL PLANNING ONLY; NOT ASIC-READY.  It makes no DRC/LVS/timing/power claim.
"""
import argparse
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
_SCRATCH = os.environ.get("SILICAFLUX_SCRATCH", "scratch")   # directory that contains audit/x/<extracted project archives>
AUDIT_DEFAULT = os.environ.get("SILICAFLUX_AUDIT_ROOT", _SCRATCH + "/audit")
MANIFESTS_DEFAULT = os.environ.get("SILICAFLUX_MANIFESTS", _SCRATCH + "/audit/x/silicaflux-sramlib/silicaflux-sramlib/manifests")
DISCLAIMER = "GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT"

FAMILIES = [("sky130", "SKY130_1RW1R", "SKY130 OpenRAM 1RW1R"), ("ihp", "IHP_1P", "IHP SG13G2 1P (1RW)"), ("gf180", "GF180_1RW", "GF180MCU 1RW")]

# required view categories -> manifest keys that list them
VIEWS = [
    ("functional model", ["verilog_model"], "RTL/gate simulation, equivalence, vendor-model timing checks"),
    ("SPICE / CDL netlist", ["spice", "cdl"], "LVS and circuit-level simulation"),
    ("Liberty timing/power", ["liberty"], "static timing, hold/setup closure, power estimation (per PVT corner)"),
    ("LEF abstract", ["lef"], "placement, pin access, routing blockages, PDN connection"),
    ("GDS layout", ["gds"], "final merge, DRC/LVS, tape-out"),
    ("datasheet / spec", ["datasheet"], "physical size, timing and constraints source for the manifest numbers"),
]
# a file with one of these extensions is ASIC-flow collateral regardless of its name
COLLATERAL_EXT = {".lef": "LEF", ".tlef": "tech LEF", ".gds": "GDS", ".gds2": "GDS", ".gdsii": "GDS", ".oas": "OASIS", ".lib": "Liberty", ".libm": "Liberty",
                  ".db": "Liberty db", ".sp": "SPICE", ".spi": "SPICE", ".spice": "SPICE", ".cdl": "CDL", ".def": "DEF", ".mag": "Magic layout",
                  ".lydrc": "KLayout DRC deck", ".lylvs": "KLayout LVS deck", ".lyp": "KLayout layer props", ".ndm": "NDM"}


def load_manifests(mdir):
    out = []
    for fp in sorted(glob.glob(os.path.join(mdir, "*.json"))):
        with open(fp) as f:
            d = json.load(f)
        ph = d.get("physical") or {}
        if d.get("status") == "OPEN_SOURCE_AVAILABLE" and d.get("macro_name") and ph.get("width_um") is not None:
            d["_file"] = os.path.basename(fp)
            out.append(d)
    return out


def index_tree(root):
    by_base, by_ext, total = {}, {}, 0
    for dp, dn, fn in os.walk(root, followlinks=False):
        for n in fn:
            total += 1
            rel = os.path.relpath(os.path.join(dp, n), root)
            by_base.setdefault(n, []).append(rel)
            ext = os.path.splitext(n)[1].lower()
            if ext in COLLATERAL_EXT:
                by_ext.setdefault(ext, []).append(rel)
    return by_base, by_ext, total


def sniff_gz(root):
    """Header-sniff every .gz (first 300 decompressed bytes, treated as DATA only): could collateral hide in archives?"""
    import gzip
    import re
    counts = {"gz_files": 0, "looks_like_LEF": 0, "looks_like_GDS": 0, "looks_like_Liberty": 0, "unreadable": 0}
    for dp, dn, fn in os.walk(root, followlinks=False):
        for n in fn:
            if not n.endswith(".gz"):
                continue
            counts["gz_files"] += 1
            try:
                with gzip.open(os.path.join(dp, n), "rb") as f:
                    head = f.read(300)
            except Exception:
                counts["unreadable"] += 1
                continue
            t = head.decode("latin1")
            if head[:2] == b"\x00\x06":
                counts["looks_like_GDS"] += 1
            elif re.search(r"\blibrary\s*\(", t):
                counts["looks_like_Liberty"] += 1
            elif "UNITS" in t and re.search(r"\bMACRO\b|\bLAYER\b|\bSITE\b", t):
                counts["looks_like_LEF"] += 1
    return counts


def as_list(v):
    if v is None:
        return []
    return list(v) if isinstance(v, (list, tuple)) else [v]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--audit-root", default=AUDIT_DEFAULT)
    ap.add_argument("--manifests", default=MANIFESTS_DEFAULT)
    ap.add_argument("--out", default=HERE)
    ap.add_argument("--write-md", action="store_true")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args(argv)

    mans = load_manifests(args.manifests)
    by_base, by_ext, nfiles = index_tree(args.audit_root)
    used = set()
    for fp in sorted(glob.glob(os.path.join(args.out, "floorplan_*.json"))):
        with open(fp) as f:
            used.add(json.load(f)["macro_shape"]["macro_name"])

    result = dict(audit_root_scanned=args.audit_root, files_in_tree=nfiles, families={}, collateral_extension_hits={}, notes=[])
    for ext, lst in sorted(by_ext.items()):
        result["collateral_extension_hits"][ext] = dict(kind=COLLATERAL_EXT[ext], count=len(lst), files=sorted(lst)[:20])

    missing_total = 0
    for fkey, mfam, title in FAMILIES:
        ms = [m for m in mans if m["family"] == mfam]
        fam = dict(title=title, manifest_family=mfam, macros_in_family=len(ms), macros_used_by_floorplans=sorted(n["macro_name"] for n in ms if n["macro_name"] in used),
                   source_repo=ms[0]["provenance"]["repo"], source_commit=ms[0]["provenance"]["commit"], process=ms[0]["process"], views={})
        for vname, keys, why in VIEWS:
            listed, found = 0, 0
            example, found_examples = None, []
            used_listed, used_found = 0, 0
            for m in ms:
                paths = []
                for k in keys:
                    paths += as_list((m.get("views") or {}).get(k))
                if vname == "datasheet / spec":
                    # spec CSVs (GF180) appear only as hashed provenance files, not as `views`
                    paths += [p for p in ((m.get("provenance") or {}).get("files") or {}) if "/specs/" in p]
                    paths = sorted(set(paths))
                for p in paths:
                    listed += 1
                    hit = by_base.get(os.path.basename(p), [])
                    # a same-named file only counts if it is not a JSON/MD abstract of the macro
                    hit = [h for h in hit if not h.endswith(".json")]
                    example = example or p
                    if m["macro_name"] in used:
                        used_listed += 1
                    if hit:
                        found += 1
                        found_examples.append(hit[0])
                        if m["macro_name"] in used:
                            used_found += 1
            fam["views"][vname] = dict(why=why, manifest_keys=keys, listed_files=listed, found_in_repo=found, listed_for_used_macros=used_listed,
                                       found_for_used_macros=used_found, example_listed_path=example, found_examples=found_examples[:3])
            if listed and not found:
                missing_total += 1
        fam["technology_process_info"] = dict(
            manifest_process_string=ms[0]["process"], manifest_foundry=ms[0].get("foundry"),
            tech_lef_files_in_tree=len(by_ext.get(".tlef", [])), note="manifests carry only the process NAME; technology LEF, RC/RCX rules, DRC/LVS decks and layer maps are not in the tree")
        result["families"][fkey] = fam

    # what does exist (secondary / partial)
    canon = "silicaflux-sramlib/silicaflux-sramlib/rtl/"  # the library's own tree; other projects vendor copies of it
    all_stubs = sorted(by_base.get("sram_macro_blackboxes.sv", []))
    all_leafs = sorted(p for n in ("sram_leaf_sky130.sv", "sram_leaf_ihp1p.sv", "sram_leaf_gf180.sv") for p in by_base.get(n, []))
    stubs = [p for p in all_stubs if canon in p]
    leafs = [p for p in all_leafs if canon in p]
    abstracts = [p for n, lst in by_base.items() for p in lst if "/physical/abstracts/" in p and n.endswith(".json") and n != "tech_ihp_sg13g2.json"]
    tech_json = [p for p in by_base.get("tech_ihp_sg13g2.json", [])]
    stdcell_lib = [p for p in by_ext.get(".lib", [])]
    defs = [p for p in by_ext.get(".def", [])]
    result["partial_or_unrelated_artefacts"] = dict(
        verilog_blackbox_stubs=stubs, verilog_blackbox_stub_copies_in_tree=len(all_stubs), asic_leaf_adapters=leafs, asic_leaf_adapter_copies_in_tree=len(all_leafs), lef_derived_json_abstracts_count=len(abstracts), lef_derived_json_abstract_example=sorted(abstracts)[:1],
        ihp_tech_json=tech_json, liberty_files_in_tree=stdcell_lib, def_files_in_tree=defs[:12], def_files_count=len(defs))
    result["gz_header_sniff"] = sniff_gz(args.audit_root)
    result["required_view_categories_missing_across_families"] = missing_total
    result["verdict"] = "GEOMETRY-LEVEL PLANNING ONLY - NOT ASIC-READY"
    result["notes"] = [
        "files are matched by BASENAME anywhere under the audit root; JSON files never count as the vendor view",
        "FPGA-inferred memory (BRAM templates, yosys synth_xilinx counts) is not evidence of ASIC readiness",
        "no DRC/LVS/timing/power result exists or is claimed",
    ]
    with open(os.path.join(args.out, "asic_collateral_check.json"), "w") as f:
        json.dump(result, f, indent=1)
        f.write("\n")

    # ---------------- console summary
    print("scanned %d files under %s" % (nfiles, args.audit_root))
    for fkey, fam in result["families"].items():
        print("%s (%d macros in family, used: %s)" % (fam["title"], fam["macros_in_family"], ", ".join(fam["macros_used_by_floorplans"]) or "-"))
        for vname, v in fam["views"].items():
            print("   %-22s listed %3d  found in repo %3d  (used macros: listed %d, found %d)" % (vname, v["listed_files"], v["found_in_repo"], v["listed_for_used_macros"], v["found_for_used_macros"]))
    print("collateral-extension files anywhere in the tree: " + (", ".join("%s x%d" % (e, d["count"]) for e, d in result["collateral_extension_hits"].items()) or "none"))
    print("VERDICT: %s" % result["verdict"])

    if args.write_md:
        with open(os.path.join(args.out, "asic_readiness.md"), "w") as f:
            f.write(make_md(result, args))
        print("wrote asic_readiness.md")
    return 1 if (args.strict and missing_total) else 0


def make_md(res, args):
    L = []
    A = L.append
    A("# ASIC readiness of the SRAM macro families used by MemoryCore")
    A("")
    A("> **VERDICT: GEOMETRY-LEVEL PLANNING ONLY. NOT ASIC-READY.**")
    A("> " + DISCLAIMER)
    A("")
    A("Generated by `check_asic_collateral.py` (numbers below are scan results, not opinions). No DRC, LVS, timing, power or IR result exists in this repository for these macros, and none is claimed here.")
    A("")
    A("## How it was checked")
    A("")
    A("* The manifests' `views` lists (and `provenance.files`) name the vendor files **in the upstream repositories** (path + pinned commit). They are an index, not the files.")
    A("* `find` / `os.walk` over the whole extracted tree (`%s`, %s files): any file with ASIC-collateral extensions, and any file named like a listed view. Same-named `.json` files are never counted as the vendor view." % ("audit/", format(res["files_in_tree"], ",")))
    A("* Reproduce: `find <audit-root> -type f \\( -iname '*.lef' -o -iname '*.gds*' -o -iname '*.lib' -o -iname '*.sp' -o -iname '*.cdl' -o -iname '*.mag' -o -iname '*.oas' -o -iname '*.tlef' \\)`, or `python3 check_asic_collateral.py`.")
    A("")
    A("Collateral-extension files found anywhere in the tree: " + (", ".join("`%s` x%d" % (e, d["count"]) for e, d in res["collateral_extension_hits"].items()) or "none") + ".")
    for e, d in res["collateral_extension_hits"].items():
        A("  * `%s` (%s): %s%s" % (e, d["kind"], ", ".join("`%s`" % x for x in d["files"][:4]), " ..." if d["count"] > 4 else ""))
    A("  None of them is a view of the SKY130 / IHP / GF180 SRAM macros: the `.lib` is a SKY130 standard-cell library belonging to another project; the `.def` files are DEFs of other designs (macro placements of the sramgrid project, a regions DEF of computecluster) - placement results, not macro views.")
    g = res["gz_header_sniff"]
    A("* Archives: %d `.gz` files exist (FloorplanLab run logs, yosys logs/netlists); header-sniffed as data: %d look like LEF, %d like GDS, %d like Liberty, %d unreadable - none is macro collateral. No `.zip`/`.tar` archives exist in the tree." % (g["gz_files"], g["looks_like_LEF"], g["looks_like_GDS"], g["looks_like_Liberty"], g["unreadable"]))
    A("")
    for fkey, fam in res["families"].items():
        A("## %s" % fam["title"])
        A("")
        A("Manifest family `%s`, %d macros in the family; floorplans use: %s. Upstream: %s @ `%s`. Process string in manifest: %s." % (
            fam["manifest_family"], fam["macros_in_family"], ", ".join("`%s`" % n for n in fam["macros_used_by_floorplans"]), fam["source_repo"], fam["source_commit"], fam["process"]))
        A("")
        A("| view required for ASIC use | needed for | listed by manifests (files, whole family) | present in this repo | for the used macro(s): listed / present | verdict |")
        A("|---|---|---|---|---|---|")
        for vname, v in fam["views"].items():
            verdict = "n/a (not listed)" if not v["listed_files"] else ("PRESENT" if v["found_in_repo"] == v["listed_files"] else ("PARTIAL" if v["found_in_repo"] else "ABSENT"))
            A("| %s | %s | %d (e.g. `%s`) | %d | %d / %d | **%s** |" % (vname, v["why"], v["listed_files"], v["example_listed_path"] or "-", v["found_in_repo"], v["listed_for_used_macros"], v["found_for_used_macros"], verdict))
        t = fam["technology_process_info"]
        A("| technology / process info (tech LEF, RC rules, DRC/LVS decks, std-cell libs) | everything downstream | manifest gives only `process` = \"%s\" | tech LEF files in tree: %d | - | **ABSENT** |" % (t["manifest_process_string"], t["tech_lef_files_in_tree"]))
        A("")
    p = res["partial_or_unrelated_artefacts"]
    A("## What does exist (and what it can support)")
    A("")
    A("| artefact | where | supports | does NOT support |")
    A("|---|---|---|---|")
    A("| Manifests (`manifests/*.json`) | `silicaflux-sramlib` | geometry-level planning: macro width/height/area, port lists, supply pin names, upstream paths + sha256 + commit | any tool run: they are metadata |")
    A("| Verilog black-box stubs | %s (+ %d vendored copies in other projects) | lint / synthesis with macros kept intact (port lists only; supply pins omitted) | simulation or timing: stubs carry no behaviour (their own header says so) |" % (", ".join("`%s`" % x for x in p["verilog_blackbox_stubs"]) or "none", max(0, p["verilog_blackbox_stub_copies_in_tree"] - len(p["verilog_blackbox_stubs"]))))
    A("| ASIC leaf adapters | %s (+ %d vendored copies) | RTL-to-macro pin mapping | physical views |" % (", ".join("`%s`" % x for x in p["asic_leaf_adapters"]) or "none", max(0, p["asic_leaf_adapter_copies_in_tree"] - len(p["asic_leaf_adapters"]))))
    A("| LEF-derived JSON abstracts (%d files) | `silicaflux-sramgrid-p33/physical/abstracts/` (another project; provenance records the vendor LEF sha256) | secondary evidence of pin edges / symmetry; dimension cross-check (used here only as such) | OpenROAD/ORFS: a JSON is not a LEF; the LEF itself cannot be re-read to verify it |" % p["lef_derived_json_abstracts_count"])
    A("| IHP technology summary JSON | %s | site / layer summary for planning | a technology LEF, RC or DRC/LVS deck |" % (", ".join("`%s`" % x for x in p["ihp_tech_json"]) or "none"))
    A("| FloorplanLab platform profiles | `silicaflux-floorplanlab/platforms/*` | names of site, layers, PG-pin mapping assumptions | they point at `/opt/eda/...` paths that are not present |")
    A("")
    A("## What must be fetched or generated before ANY physical verification")
    A("")
    A("Common to every family:")
    A("")
    A("1. The vendor macro views at the pinned commits: **LEF, GDS, Liberty (all corners), SPICE/CDL, Verilog model, datasheet/spec CSVs** (the library's own `scripts/mem/fetch_open_macros.sh` fetches only Verilog models, LEF, specs and licences - GDS and Liberty are listed in the manifests but not fetched even there).")
    A("2. The open PDK / design kit for the process: technology LEF, standard-cell LEF/GDS/Liberty (typical + slow/fast corners), RC/RCX rules, layer maps, DRC and LVS decks, antenna rules, tap/endcap rules.")
    A("3. EDA tools: OpenROAD + ORFS (floorplan/PDN/placement/CTS/route), Yosys (logic synthesis of the controller), KLayout (DRC/LVS decks as shipped by the PDKs), Magic/Netgen where the PDK uses them. **None is installed in the environment that produced these files.**")
    A("4. Real controller/logic area: yosys + Liberty synthesis of the MemoryCore RTL (the logic reserve here is a placeholder).")
    A("5. A pin-aware floorplan: macro pin edges/positions from the LEFs, pin-escape and channel analysis, PDN design (macro PG pins to straps), I/O/pad ring, seal ring.")
    A("6. Sign-off: STA across corners with the macro Liberty, hold/setup closure, power and IR analysis, DRC, LVS, antenna, formal equivalence of the netlist.")
    A("")
    A("Family specific:")
    A("")
    A("* **SKY130 (OpenRAM)**: SkyWater SKY130 PDK (via open_pdks) for the std cells and decks; the three manifest macros are pre-generated macros from `efabless/sky130_sram_macros`. A different size or a true single-port macro would need OpenRAM itself plus the PDK. The manifests contain only 1RW1R macros, so every instance carries an unused read port.")
    A("* **IHP SG13G2**: the IHP-Open-PDK `sg13g2_sram` collateral (LEF/GDS/Liberty x3 corners/CDL/Verilog/datasheets) and the SG13G2 std-cell/tech kit. The macros are compiled (`RM_IHPSG13_*`); the c2/c3 column-mux variants in the names are fixed shapes.")
    A("* **GF180MCU**: the `gf180mcu_fd_ip_sram` cells (15 Liberty corners per macro, LEF, GDS, CDL, specs) plus the GF180MCU PDK. FloorplanLab's gf180mcu profile is *disabled*: its pinned ORFS has no SRAM collateral and no SilicaFlux GF180 wrapper is on its flow path.")
    A("")
    A("## Not evidence of ASIC readiness")
    A("")
    A("* **FPGA-inferred memory** (block-RAM templates, `synth_xilinx` RAMB counts, FPGA simulation) says nothing about ASIC macro integration: no macro is instantiated, no LEF/Liberty is consumed.")
    A("* Equivalence/lint results against vendor Verilog models (the SRAM library's `mem-equiv`) show functional adapter correctness only; the library states what is *not* shown: \"timing closure against the Liberty views, LEF-based placement, power-pin connection, DRC/LVS, or behaviour of any macro in silicon\".")
    A("* The generated floorplans in this directory are planning geometry from manifest dimensions; they were not read by OpenROAD (not installed) and are not DRC/LVS clean by any measure.")
    A("")
    A("## Reproduce")
    A("")
    A("```")
    A("python3 -I check_asic_collateral.py --write-md      # rescans the tree, rewrites asic_collateral_check.json and this file")
    A("```")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    sys.exit(main())
