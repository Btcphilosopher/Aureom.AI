#!/usr/bin/env python3
"""check_floorplan.py -- independent legality checker for the generated MemoryCore floorplans.

Independence: this file does NOT import scripts/gen_physical.py.  It re-reads the macro manifests
(JSON, as data) and the generated artefacts, recomputes every geometric and arithmetic fact itself,
and compares.  It checks GEOMETRY ONLY (no DRC, no pin access, no routing, no timing).

Checks per floorplan (ids used in the report):
  SCHEMA      required keys, label / disclaimer, ASSUMPTION labelling of parameters
  MANIFEST    every macro_name is a real OPEN_SOURCE_AVAILABLE manifest macro (never a commercial placeholder);
              width/height/area equal the manifest fields
  COUNT       instance names unique; count = banks x NC x NR; NC/NR recomputed from ROW_W/depth and manifest geometry
  TILING      chosen macro is the minimum-total-area uniform tiling among the family's manifests; totals recomputed
  GRID        every macro sits on the bank grid (x = region.llx + col*(w+gap), ...) and orientation = R0 (even row) / MX (odd row)
  DIE         die positive, core inside die, margins equal the parameter
  IN_DIE      every macro inside die (and inside core)
  OVERLAP     no two macros overlap (positive area)
  HALO        no macro halo overlaps another macro body; every halo inside the core
  REGIONS     bank regions pairwise disjoint, tight around their own macros, macros inside their region
  CHANNELS    each channel width >= channel parameter; channels inside core, disjoint from macros/regions/logic;
              each channel touches the banks / logic named in `between`
  LOGIC       logic reserve inside core, disjoint from macros/regions/channels, area >= requested
  PARTITION   regions + channels + logic + pad rings tile the die exactly (areas add up, no holes)
  PG          every macro has a PG row for every manifest supply pin, each mapped to a net (no UNMAPPED), VDD has a voltage
  ARTEFACTS   inventory CSV, SVG title, Tcl header, FloorplanLab RunSpec and dashboard agree with the floorplan JSON

Then NEGATIVE TESTS: deliberately corrupted copies of a floorplan (overlap, outside die, halo violation, region overlap, narrow
channel, missing PG, wrong dimension, placeholder macro, wrong orientation, logic overlap, missing instance) must each be caught.

Exit status 0 only if every floorplan passes every check and every negative test is caught.
"""
import argparse
import copy
import csv
import glob
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
_SCRATCH = os.environ.get("SILICAFLUX_SCRATCH", "scratch")   # directory that contains audit/x/<extracted project archives>
MANIFESTS_DEFAULT = os.environ.get("SILICAFLUX_MANIFESTS", _SCRATCH + "/audit/x/silicaflux-sramlib/silicaflux-sramlib/manifests")
DISCLAIMER = "GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT"
LABEL = "generated-geometry"
EPS = 1e-6
TOL_AREA = 0.02  # um2, manifest rounding


def ceil_div(a, b):
    return -(-a // b)


# ----------------------------------------------------------------------------- geometry
def R(o):
    return (o["llx"], o["lly"], o["urx"], o["ury"])


def macro_rect(m):
    return (m["x"], m["y"], m["x"] + m["w"], m["y"] + m["h"])


def inflate(r, d):
    return (r[0] - d, r[1] - d, r[2] + d, r[3] + d)


def area(r):
    return (r[2] - r[0]) * (r[3] - r[1])


def overlaps(a, b):
    return min(a[2], b[2]) - max(a[0], b[0]) > EPS and min(a[3], b[3]) - max(a[1], b[1]) > EPS


def inside(inner, outer):
    return inner[0] >= outer[0] - EPS and inner[1] >= outer[1] - EPS and inner[2] <= outer[2] + EPS and inner[3] <= outer[3] + EPS


def touches(a, b):
    """rectangles share an edge segment of positive length (or overlap): gap == 0 on one axis, overlap on the other"""
    dx = max(b[0] - a[2], a[0] - b[2])
    dy = max(b[1] - a[3], a[1] - b[3])
    if abs(dx) <= EPS and dy < -EPS:
        return True
    if abs(dy) <= EPS and dx < -EPS:
        return True
    return dx < -EPS and dy < -EPS


def overlapping_pairs(rects_a, rects_b=None, same=True):
    """indices (i, j) with positive-area overlap; x-sorted sweep.  same=True: pairs within one list (i<j)."""
    out = []
    if same:
        order = sorted(range(len(rects_a)), key=lambda i: rects_a[i][0])
        for ii, i in enumerate(order):
            ri = rects_a[i]
            for j in order[ii + 1:]:
                rj = rects_a[j]
                if rj[0] >= ri[2] - EPS:
                    break
                if overlaps(ri, rj):
                    out.append((min(i, j), max(i, j)))
    else:
        order = sorted(range(len(rects_b)), key=lambda j: rects_b[j][0])
        xs = [rects_b[j][0] for j in order]
        for i, ri in enumerate(rects_a):
            for jj, j in enumerate(order):
                rj = rects_b[j]
                if rj[0] >= ri[2] - EPS:
                    break
                if overlaps(ri, rj):
                    out.append((i, j))
    return out


# ----------------------------------------------------------------------------- manifests (re-read independently)
def load_manifests(mdir):
    out = {}
    for fp in sorted(glob.glob(os.path.join(mdir, "*.json"))):
        with open(fp) as f:
            d = json.load(f)
        out[os.path.basename(fp)] = d
    return out


def real_macros(mans):
    r = {}
    for base, d in mans.items():
        ph = d.get("physical") or {}
        if d.get("status") == "OPEN_SOURCE_AVAILABLE" and d.get("macro_name") and ph.get("width_um") is not None:
            r[d["macro_name"]] = dict(manifest=base, family=d["family"], dw=d["data_width"], words=d["words"], w=ph["width_um"], h=ph["height_um"],
                                      area=ph["area_um2"], supply=list(d.get("supply_pins") or []), topology=d.get("port_topology"))
    return r


# ----------------------------------------------------------------------------- checks
class Result:
    def __init__(self, name):
        self.name = name
        self.items = []  # (check_id, ok, detail)

    def add(self, cid, ok, detail=""):
        self.items.append((cid, bool(ok), detail))

    @property
    def failed(self):
        return [(c, d) for c, ok, d in self.items if not ok]

    @property
    def passed(self):
        return [c for c, ok, d in self.items if ok]


def check_floorplan(fp, macros_db, name=None):
    res = Result(name or fp.get("id", "?"))
    add = res.add
    # ---- SCHEMA
    req = ["schema", "label", "disclaimer", "config", "family", "macro_shape", "tiling", "parameters", "die", "core", "bank_regions", "macros",
           "channels", "logic_reserve", "pg", "areas", "halo"]
    miss = [k for k in req if k not in fp]
    add("SCHEMA.keys", not miss, "missing %s" % miss)
    if miss:
        return res
    add("SCHEMA.label", fp["label"] == LABEL and fp["disclaimer"] == DISCLAIMER, "label/disclaimer")
    par = fp["parameters"]
    lab_ok = all(("ASSUMPTION" in par[k]["status"] or "PLACEHOLDER" in par[k]["status"]) for k in ("halo_um", "channel_um", "die_margin_um", "macro_gap_um", "core_pad_um", "logic_reserve_area_um2"))
    add("SCHEMA.assumptions_labelled", lab_ok, "halo/channel/margin/gap/pad/logic must carry ASSUMPTION or PLACEHOLDER status")
    add("SCHEMA.entry_labels", all(m.get("label") == LABEL for m in fp["macros"]) and all(c.get("label") == LABEL for c in fp["channels"]) and fp["logic_reserve"].get("label") == LABEL
        and all(r.get("label") == LABEL for r in fp["bank_regions"]), "every entry carries label=generated-geometry")
    halo, chan, dm = par["halo_um"]["value"], par["channel_um"]["value"], par["die_margin_um"]["value"]
    gap, pad = par["macro_gap_um"]["value"], par["core_pad_um"]["value"]
    cfg, ms = fp["config"], fp["macros"]
    die, core = R(fp["die"]), R(fp["core"])
    mrects = [macro_rect(m) for m in ms]

    # ---- MANIFEST
    shape = fp["macro_shape"]
    mdb = macros_db.get(shape["macro_name"])
    add("MANIFEST.exists", mdb is not None, "macro %r not an OPEN_SOURCE_AVAILABLE manifest macro" % shape["macro_name"])
    bad_names = [m["inst"] for m in ms if m["macro_name"] not in macros_db]
    add("MANIFEST.no_placeholder", not bad_names and all(m["macro_name"] for m in ms), "instances with unknown/placeholder macro: %s" % bad_names[:3])
    if mdb:
        fam_ok = mdb["family"] == fp["family"]["manifest_family"]
        add("MANIFEST.family", fam_ok, "manifest family %s vs %s" % (mdb["family"], fp["family"]["manifest_family"]))
        dims_bad = []
        for m in ms:
            d = macros_db.get(m["macro_name"])
            if not d or abs(m["w"] - d["w"]) > EPS or abs(m["h"] - d["h"]) > EPS or abs(m["area_um2"] - d["area"]) > EPS:
                dims_bad.append(m["inst"])
        add("MANIFEST.dims", not dims_bad, "w/h/area differ from manifest for %s" % dims_bad[:3])
        add("MANIFEST.single_shape", len({m["macro_name"] for m in ms}) == 1 and ms[0]["macro_name"] == shape["macro_name"], "mixed macro names")
        add("MANIFEST.area_consistent", abs(mdb["w"] * mdb["h"] - mdb["area"]) <= TOL_AREA, "manifest area vs w*h")

    # ---- COUNT / TILING
    names = [m["inst"] for m in ms]
    add("COUNT.unique_names", len(set(names)) == len(names), "duplicate instance names")
    if mdb:
        nc = ceil_div(cfg["row_w"], mdb["dw"])
        nr = ceil_div(cfg["depth"], mdb["words"])
        t = fp["tiling"]
        add("COUNT.nc_nr", (t["nc"], t["nr"]) == (nc, nr), "tiling says %s x %s, recomputed %s x %s" % (t["nc"], t["nr"], nc, nr))
        add("COUNT.instances", len(ms) == cfg["banks"] * nc * nr and t["instances_total"] == len(ms), "%d macros vs %d expected" % (len(ms), cfg["banks"] * nc * nr))
        expect_names = {"u_bank%d_r%d_c%d" % (b, r, c) for b in range(cfg["banks"]) for r in range(nr) for c in range(nc)}
        add("COUNT.names_complete", set(names) == expect_names, "instance name set differs from u_bank<b>_r<r>_c<c> grid")
        prov = (nc * mdb["dw"]) * (nr * mdb["words"])
        req_bits = cfg["row_w"] * cfg["depth"]
        add("TILING.bits", t["provisioned_bits_per_bank"] == prov and t["required_bits_per_bank"] == req_bits and abs(t["bit_utilisation"] - req_bits / prov) < 1e-9, "provisioned/required/util")
        tot_area = sum(m["area_um2"] for m in ms)
        add("TILING.area_total", abs(fp["areas"]["manifest_sourced"]["macro_area_total_um2"] - tot_area) <= TOL_AREA and abs(tot_area - len(ms) * mdb["area"]) <= TOL_AREA, "area sum")
        # minimum-area uniform tiling among the family
        best = None
        for n, d in macros_db.items():
            if d["family"] != mdb["family"]:
                continue
            tot = cfg["banks"] * ceil_div(cfg["row_w"], d["dw"]) * ceil_div(cfg["depth"], d["words"])
            key = (round(tot * d["area"], 2), tot, n)
            if best is None or key < best:
                best = key
        add("TILING.min_area_choice", best is not None and best[2] == shape["macro_name"], "min-area uniform tiling is %s, floorplan uses %s" % (best and best[2], shape["macro_name"]))
        # used bits
        used = sum(m["used_bits"] for m in ms)
        add("TILING.used_bits", used == cfg["banks"] * req_bits, "sum of used_bits %d vs %d" % (used, cfg["banks"] * req_bits))

    # ---- DIE
    add("DIE.positive", die[2] > die[0] and die[3] > die[1] and core[2] > core[0] and core[3] > core[1], "non-positive die/core")
    add("DIE.core_in_die", inside(core, die), "core outside die")
    add("DIE.margin", all(abs(a - b) < 1e-4 for a, b in ((core[0] - die[0], dm), (core[1] - die[1], dm), (die[2] - core[2], dm), (die[3] - core[3], dm))), "core margin != die_margin_um")
    add("DIE.area_field", abs(fp["die"]["area_um2"] - area(die)) < 0.01, "die.area_um2")

    # ---- GRID / orientation
    regs = {r["bank"]: r for r in fp["bank_regions"]}
    grid_bad, orient_bad, tile_bad = [], [], []
    for m in ms:
        r = regs.get(m["bank"])
        if r is None:
            grid_bad.append(m["inst"])
            continue
        if m["orient"] not in ("R0", "MX") or m["orient"] != ("R0" if m["tile_row"] % 2 == 0 else "MX"):
            orient_bad.append(m["inst"])
        ex = r["llx"] + m["tile_col"] * (m["w"] + gap)
        ey = r["lly"] + m["tile_row"] * (m["h"] + gap)
        if abs(m["x"] - ex) > 1e-4 or abs(m["y"] - ey) > 1e-4:
            grid_bad.append(m["inst"])
        if m["inst"] != "u_bank%d_r%d_c%d" % (m["bank"], m["tile_row"], m["tile_col"]):
            tile_bad.append(m["inst"])
    add("GRID.positions", not grid_bad, "off-grid macros %s" % grid_bad[:3])
    add("GRID.orientation", not orient_bad, "orientation not R0/MX alternating by row: %s" % orient_bad[:3])
    add("GRID.names_match_tiles", not tile_bad, "instance name != bank/row/col fields: %s" % tile_bad[:3])

    # ---- IN_DIE
    out_die = [m["inst"] for m, r in zip(ms, mrects) if not inside(r, die)]
    out_core = [m["inst"] for m, r in zip(ms, mrects) if not inside(r, core)]
    add("IN_DIE.macros", not out_die, "macros outside die: %s" % out_die[:3])
    add("IN_DIE.macros_in_core", not out_core, "macros outside core: %s" % out_core[:3])

    # ---- OVERLAP
    ov = overlapping_pairs(mrects)
    add("OVERLAP.macros", not ov, "%d overlapping macro pairs, e.g. %s" % (len(ov), [(ms[i]["inst"], ms[j]["inst"]) for i, j in ov[:2]]))

    # ---- HALO
    halos = [inflate(r, halo) for r in mrects]
    hv = [(i, j) for i, j in overlapping_pairs(halos, mrects, same=False) if i != j]
    add("HALO.not_over_other_macros", not hv, "%d halo/macro violations, e.g. %s" % (len(hv), [(ms[i]["inst"], ms[j]["inst"]) for i, j in hv[:2]]))
    add("HALO.inside_core", all(inside(h, core) for h in halos), "a halo crosses the core edge")
    add("HALO.value_matches", abs(fp["halo"]["value_um"] - halo) < 1e-9, "halo section vs parameter")

    # ---- REGIONS
    rr = [R(r) for r in fp["bank_regions"]]
    rov = overlapping_pairs(rr)
    add("REGIONS.disjoint", not rov, "overlapping bank regions %s" % rov)
    add("REGIONS.count", len(rr) == cfg["banks"], "bank region count")
    tight_bad, member_bad = [], []
    for r in fp["bank_regions"]:
        mine = [(m, macro_rect(m)) for m in ms if m["bank"] == r["bank"]]
        if not mine:
            member_bad.append(r["bank"])
            continue
        bb = (min(x[1][0] for x in mine), min(x[1][1] for x in mine), max(x[1][2] for x in mine), max(x[1][3] for x in mine))
        if any(abs(a - b) > 1e-4 for a, b in zip(bb, R(r))):
            tight_bad.append(r["bank"])
        if not all(inside(x[1], R(r)) for x in mine) or sorted(r["macros"]) != sorted(x[0]["inst"] for x in mine):
            member_bad.append(r["bank"])
    add("REGIONS.tight", not tight_bad, "region != bbox of its macros for banks %s" % tight_bad)
    add("REGIONS.members", not member_bad, "macro outside its region / member list mismatch for banks %s" % member_bad)

    # ---- CHANNELS / LOGIC
    ch = fp["channels"]
    lg = R(fp["logic_reserve"])
    narrow = [c["id"] for c in ch if min(c["urx"] - c["llx"], c["ury"] - c["lly"]) < chan - 1e-6]
    add("CHANNELS.width>=param", bool(ch) and not narrow, "channels narrower than %g um: %s" % (chan, narrow))
    add("CHANNELS.recorded_width", all(abs(c["width_um"] - min(c["urx"] - c["llx"], c["ury"] - c["lly"])) < 1e-4 for c in ch), "recorded width_um != geometry")
    add("CHANNELS.in_core", all(inside(R(c), core) for c in ch), "channel outside core")
    crs = [R(c) for c in ch]
    bad = []
    for c, r in zip(ch, crs):
        if any(overlaps(r, mr) for mr in mrects) or any(overlaps(r, x) for x in rr) or overlaps(r, lg):
            bad.append(c["id"])
    add("CHANNELS.disjoint", not bad, "channel overlaps macro/region/logic: %s" % bad)
    add("CHANNELS.disjoint_each_other", not overlapping_pairs(crs), "channels overlap each other")
    adj_bad = []
    for c, r in zip(ch, crs):
        for b in c["between"]:
            tgt = lg if b == "logic" else next((R(x) for x in fp["bank_regions"] if x["name"] == b), None)
            if tgt is None or not touches(r, tgt):
                adj_bad.append((c["id"], b))
    add("CHANNELS.adjacent_to_named", not adj_bad, "channel does not touch %s" % adj_bad[:3])
    add("LOGIC.in_core", inside(lg, core), "logic reserve outside core")
    add("LOGIC.disjoint", not any(overlaps(lg, mr) for mr in mrects) and not any(overlaps(lg, x) for x in rr) and not any(overlaps(lg, x) for x in crs), "logic reserve overlaps macro/region/channel")
    add("LOGIC.area>=requested", area(lg) >= fp["logic_reserve"]["requested_area_um2"] - 1e-6, "logic area %g < requested %g" % (area(lg), fp["logic_reserve"]["requested_area_um2"]))

    # ---- PARTITION
    parts = rr + crs + [lg]
    inner = (min(p[0] for p in parts), min(p[1] for p in parts), max(p[2] for p in parts), max(p[3] for p in parts))
    sum_parts = sum(area(p) for p in parts)
    add("PARTITION.inner_tiled", abs(sum_parts - area(inner)) < 0.01 and not overlapping_pairs(parts), "regions+channels+logic do not tile their bbox exactly (sum %g vs bbox %g)" % (sum_parts, area(inner)))
    pad_ok = all(abs(a - b) < 1e-4 for a, b in ((inner[0] - core[0], pad), (inner[1] - core[1], pad), (core[2] - inner[2], pad), (core[3] - inner[3], pad)))
    add("PARTITION.core_pad", pad_ok, "core pad ring != core_pad_um")
    add("PARTITION.die_total", abs(area(die) - (sum_parts + (area(core) - area(inner)) + (area(die) - area(core)))) < 0.01 and abs(fp["areas"]["derived"]["die_area_um2"] - area(die)) < 0.01,
        "die area identity")

    # ---- PG
    pg_bad = []
    if mdb:
        want = sorted(mdb["supply"])
        for m in ms:
            rows = m.get("pg")
            if not rows or sorted(r[0] for r in rows) != want or any(r[1] in (None, "", "UNMAPPED") for r in rows):
                pg_bad.append(m["inst"])
                continue
            nets = {r[1]: r for r in rows}
            if "VDD" not in nets or "VSS" not in nets or nets["VDD"][2] is None or nets["VSS"][2] != 0.0:
                pg_bad.append(m["inst"])
    else:
        pg_bad = ["(no manifest)"]
    add("PG.every_macro", not pg_bad, "macros with missing/invalid PG rows: %s" % pg_bad[:3])
    return res


def lint_tcl(text):
    """Structural lint only (NO Tcl interpreter is available): comments stripped, {} [] balanced over the file,
    double quotes even per command line, every flp_place line has exactly 6 arguments.  Not a syntax guarantee."""
    problems = []
    depth_c = depth_b = 0
    for n, line in enumerate(text.split("\n"), 1):
        st = line.strip()
        if not st or st.startswith("#"):
            continue
        code = line.split(";#")[0]
        if code.count('"') % 2:
            problems.append("line %d: odd number of double quotes" % n)
        depth_c += code.count("{") - code.count("}")
        depth_b += code.count("[") - code.count("]")
        if code.startswith("flp_place "):
            if len(code.split()) != 8:  # flp_place $block $dbu name master x y orient
                problems.append("line %d: flp_place needs 7 words after the command, got %d" % (n, len(code.split()) - 1))
    if depth_c != 0:
        problems.append("unbalanced braces (%+d)" % depth_c)
    if depth_b != 0:
        problems.append("unbalanced brackets (%+d)" % depth_b)
    return problems


def check_artefacts(root, fps, macros_db):
    """cross-artefact consistency (global): inventory CSV, SVG, Tcl, FloorplanLab runs, dashboard."""
    res = Result("ARTEFACTS")
    add = res.add
    csv_path = os.path.join(root, "macro_inventory.csv")
    rows = []
    if os.path.isfile(csv_path):
        with open(csv_path, newline="") as f:
            rows = list(csv.DictReader(f))
    add("ARTEFACTS.inventory_present", bool(rows), "macro_inventory.csv missing/empty")
    byfp = {}
    for r in rows:
        byfp.setdefault(r["floorplan_id"], {})[r["instance"]] = r
    for fp in fps:
        inv = byfp.get(fp["id"], {})
        ok = len(inv) == len(fp["macros"])
        if ok:
            for m in fp["macros"]:
                r = inv.get(m["inst"])
                if (not r or r["macro_name"] != m["macro_name"] or abs(float(r["x_um"]) - m["x"]) > 1e-6 or abs(float(r["y_um"]) - m["y"]) > 1e-6
                        or abs(float(r["width_um"]) - m["w"]) > 1e-6 or r["orient"] != m["orient"] or not r["source_manifest"] or not r["physical_source"] or not r["provenance_commit"]):
                    ok = False
                    break
        add("ARTEFACTS.inventory[%s]" % fp["id"], ok, "inventory rows differ from floorplan JSON")
        svg = os.path.join(root, "svg", "floorplan_%s.svg" % fp["id"])
        txt = open(svg).read() if os.path.isfile(svg) else ""
        add("ARTEFACTS.svg_title[%s]" % fp["id"], DISCLAIMER in txt and "<title>%s" % DISCLAIMER in txt, "SVG missing the mandatory title text")
        tcl = os.path.join(root, "openroad", "floorplan_%s.tcl" % fp["id"])
        t = open(tcl).read() if os.path.isfile(tcl) else ""
        n_place = len(re.findall(r"^flp_place \$block \$dbu ", t, re.M))
        add("ARTEFACTS.tcl[%s]" % fp["id"], "UNEXECUTED" in t.split("\n", 3)[1] and n_place == len(fp["macros"]), "Tcl header must say UNEXECUTED and place %d macros (found %d)" % (len(fp["macros"]), n_place))
        add("ARTEFACTS.tcl_lint[%s]" % fp["id"], not lint_tcl(t), "Tcl structural lint (brace/bracket/quote balance, flp_place arity): %s" % lint_tcl(t)[:2])
        if n_place == len(fp["macros"]):
            coords = {mm.group(1): (float(mm.group(2)), float(mm.group(3)), mm.group(4)) for mm in re.finditer(r"^flp_place \$block \$dbu (\S+) \S+ (\S+) (\S+) (\S+)", t, re.M)}
            add("ARTEFACTS.tcl_coords[%s]" % fp["id"], all(m["inst"] in coords and abs(coords[m["inst"]][0] - m["x"]) < 1e-6 and abs(coords[m["inst"]][1] - m["y"]) < 1e-6 and coords[m["inst"]][2] == m["orient"] for m in fp["macros"]), "Tcl coordinates differ from JSON")
        yml = os.path.join(root, "floorplanlab", "runs", "MC_%s.yaml" % fp["id"])
        y = open(yml).read() if os.path.isfile(yml) else ""
        ypos = {mm.group(1): (float(mm.group(2)), float(mm.group(3)), mm.group(4)) for mm in re.finditer(r"^    (u_bank\S+): \[(\S+), (\S+), (\S+)\]", y, re.M)}
        add("ARTEFACTS.flp_runspec[%s]" % fp["id"], len(ypos) == len(fp["macros"]) and all(abs(ypos[m["inst"]][0] - m["x"]) < 1e-6 and abs(ypos[m["inst"]][1] - m["y"]) < 1e-6 for m in fp["macros"] if m["inst"] in ypos), "FloorplanLab RunSpec positions differ")
    dpath = os.path.join(root, "dashboard_floorplan.json")
    ok = False
    if os.path.isfile(dpath):
        with open(dpath) as f:
            d = json.load(f)
        ok = d.get("label") == LABEL and len(d.get("floorplans", [])) == len(fps)
        for e in d.get("floorplans", []):
            fpm = next((f for f in fps if f["id"] == e["id"]), None)
            ok = ok and fpm is not None and e.get("label") == LABEL and len(e["macros"]) == len(fpm["macros"]) and all(x.get("label") == LABEL for x in e["macros"] + e["halos"] + e["channels"] + e["bank_regions"])
    add("ARTEFACTS.dashboard", ok, "dashboard labels/counts")
    return res


# ----------------------------------------------------------------------------- negative tests
def make_negatives(base):
    """list of (name, mutated fp, check id that must fail)"""
    N = []
    ms = lambda f: f["macros"]

    f = copy.deepcopy(base)  # overlap: macro 1 dropped onto macro 0 (same bank, next column)
    ms(f)[1]["x"], ms(f)[1]["y"] = ms(f)[0]["x"], ms(f)[0]["y"]
    N.append(("two macros overlap (macro1 moved onto macro0)", f, "OVERLAP.macros"))

    f = copy.deepcopy(base)
    ms(f)[1]["x"] = ms(f)[0]["x"] + 30.0  # partial overlap
    N.append(("two macros partially overlap (30 um shift)", f, "OVERLAP.macros"))

    f = copy.deepcopy(base)
    ms(f)[0]["x"] = f["die"]["urx"] - 5.0
    N.append(("macro placed outside the die", f, "IN_DIE.macros"))

    f = copy.deepcopy(base)  # halo violation without overlap: 5 um gap between macros 0 and 1 (halo 20)
    a, b = ms(f)[0], ms(f)[1]
    b["x"] = a["x"] + a["w"] + 5.0
    N.append(("halo violation: 5 um gap < halo, bodies disjoint", f, "HALO.not_over_other_macros"))

    f = copy.deepcopy(base)  # region overlap
    f["bank_regions"][1]["llx"], f["bank_regions"][1]["lly"] = f["bank_regions"][0]["llx"] + 1.0, f["bank_regions"][0]["lly"] + 1.0
    f["bank_regions"][1]["urx"], f["bank_regions"][1]["ury"] = f["bank_regions"][0]["urx"] + 1.0, f["bank_regions"][0]["ury"] + 1.0
    N.append(("bank regions overlap", f, "REGIONS.disjoint"))

    f = copy.deepcopy(base)  # narrow channel
    c = f["channels"][0]
    if (c["urx"] - c["llx"]) <= (c["ury"] - c["lly"]):
        c["urx"] -= 10.0
    else:
        c["ury"] -= 10.0
    N.append(("routing channel narrower than the parameter", f, "CHANNELS.width>=param"))

    f = copy.deepcopy(base)
    del ms(f)[2]["pg"]
    N.append(("macro without PG entry", f, "PG.every_macro"))

    f = copy.deepcopy(base)
    ms(f)[0]["pg"] = [r for r in ms(f)[0]["pg"] if r[1] != "VSS"]
    N.append(("macro PG table missing the ground pin", f, "PG.every_macro"))

    f = copy.deepcopy(base)
    ms(f)[3]["w"] += 1.0
    N.append(("macro width differs from manifest", f, "MANIFEST.dims"))

    f = copy.deepcopy(base)
    ms(f)[0]["macro_name"] = "commercial_28nm_pending"
    N.append(("instance uses a commercial placeholder macro", f, "MANIFEST.no_placeholder"))

    f = copy.deepcopy(base)
    ms(f)[0]["orient"] = "R90"
    N.append(("illegal orientation R90", f, "GRID.orientation"))

    f = copy.deepcopy(base)
    lgr = f["logic_reserve"]
    m0 = ms(f)[0]
    lgr["llx"], lgr["lly"], lgr["urx"], lgr["ury"] = m0["x"] + 10, m0["y"] + 10, m0["x"] + 110, m0["y"] + 110
    N.append(("logic reserve overlaps a macro", f, "LOGIC.disjoint"))

    f = copy.deepcopy(base)
    del ms(f)[-1]
    N.append(("instance missing (count != banks x NC x NR)", f, "COUNT.instances"))

    f = copy.deepcopy(base)
    ms(f)[0]["macro_name"] = "sky130_sram_1kbyte_1rw1r_32x256_8"  # a REAL manifest macro, but not the tile's shape
    N.append(("macro name swapped for another real macro (dims/shape mismatch)", f, "MANIFEST.dims"))
    return N


# ----------------------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description="independent floorplan legality checker")
    ap.add_argument("--root", default=HERE, help="directory with floorplan_*.json (default: this file's directory)")
    ap.add_argument("--manifests", default=MANIFESTS_DEFAULT)
    ap.add_argument("--no-negative", action="store_true")
    ap.add_argument("--report", default=None, help="write the JSON report here (default <root>/logs/check_floorplan_report.json)")
    args = ap.parse_args(argv)
    root = os.path.abspath(args.root)
    if not os.path.isdir(args.manifests):
        print("FATAL: manifests directory not found: %s" % args.manifests)
        return 2
    macros_db = real_macros(load_manifests(args.manifests))
    files = sorted(glob.glob(os.path.join(root, "floorplan_*.json")))
    if not files:
        print("FATAL: no floorplan_*.json in %s" % root)
        return 2
    fps = []
    for fpth in files:
        with open(fpth) as f:
            fps.append(json.load(f))
    report = dict(floorplans=[], negative=[], artefacts=None)
    n_pass_fp = n_checks_pass = n_checks_fail = 0
    print("check_floorplan: %d floorplans, %d real macros in manifests (placeholders excluded)" % (len(fps), len(macros_db)))
    for fp in fps:
        r = check_floorplan(fp, macros_db)
        ok = not r.failed
        n_pass_fp += ok
        n_checks_pass += len(r.passed)
        n_checks_fail += len(r.failed)
        print("  %-10s %-4s  %3d checks passed, %d failed  (%d macros)" % (fp["id"], "PASS" if ok else "FAIL", len(r.passed), len(r.failed), len(fp["macros"])))
        for cid, d in r.failed:
            print("      FAIL %s: %s" % (cid, d))
        report["floorplans"].append(dict(id=fp["id"], ok=ok, passed=len(r.passed), failed=[dict(check=c, detail=d) for c, d in r.failed]))
    ra = check_artefacts(root, fps, macros_db)
    n_checks_pass += len(ra.passed)
    n_checks_fail += len(ra.failed)
    print("  %-10s %-4s  %3d checks passed, %d failed" % ("ARTEFACTS", "PASS" if not ra.failed else "FAIL", len(ra.passed), len(ra.failed)))
    for cid, d in ra.failed:
        print("      FAIL %s: %s" % (cid, d))
    report["artefacts"] = dict(passed=len(ra.passed), failed=[dict(check=c, detail=d) for c, d in ra.failed])
    print("floorplans: %d/%d PASS ; individual checks: %d passed, %d failed" % (n_pass_fp, len(fps), n_checks_pass, n_checks_fail))

    neg_caught = neg_total = 0
    if not args.no_negative:
        base = next((f for f in fps if f["id"] == "C1_sky130"), fps[0])
        # the unmodified base must itself pass, otherwise negative tests prove nothing
        base_res = check_floorplan(base, macros_db)
        print("negative tests (base floorplan %s, unmodified: %s):" % (base["id"], "PASS" if not base_res.failed else "FAIL"))
        for name, mut, must_fail in make_negatives(base):
            r = check_floorplan(mut, macros_db, name)
            failed_ids = [c for c, d in r.failed]
            caught = must_fail in failed_ids
            neg_total += 1
            neg_caught += caught
            print("  [%s] %-62s expected %-30s failed checks: %s" % ("CAUGHT" if caught else "MISSED", name, must_fail, ", ".join(failed_ids) or "none"))
            report["negative"].append(dict(test=name, expected_check=must_fail, caught=caught, failed_checks=failed_ids))
        print("negative tests: %d/%d caught" % (neg_caught, neg_total))
    all_ok = n_pass_fp == len(fps) and not ra.failed and neg_caught == neg_total
    report["summary"] = dict(floorplans=len(fps), floorplans_pass=n_pass_fp, checks_passed=n_checks_pass, checks_failed=n_checks_fail,
                             negative_total=neg_total, negative_caught=neg_caught, overall="PASS" if all_ok else "FAIL")
    rp = args.report or os.path.join(root, "logs", "check_floorplan_report.json")
    os.makedirs(os.path.dirname(rp), exist_ok=True)
    with open(rp, "w") as f:
        json.dump(report, f, indent=1)
        f.write("\n")
    print("OVERALL: %s" % ("PASS" if all_ok else "FAIL"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
