# SilicaFlux MemoryCore - SRAM physical planning (geometry level)

> **GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT**

## Scope

Macro inventory, floorplan geometry, placement scripts and area accounting for the MemoryCore SRAM subsystem (4 independent single-port banks, line-interleaved, physically independent), driven **only** by the real open-PDK macro manifests of the SRAM library (`silicaflux-sramlib/manifests/*.json`). Every macro width/height/area is a manifest field (`physical.*`); halo, channels, die margin, macro gap and the controller/logic reserve are **assumptions** and are labelled as such everywhere. This is geometry-level planning. It is **not** an ASIC-ready deliverable (see `asic_readiness.md`).

Configurations: **C1** 4 x 1024 x 128 b (64 KiB), **C2** 4 x 1024 x 137 b (SECDED stored word), **C3** 4 x 4096 x 128 b (256 KiB). Families: **SKY130** OpenRAM 1RW1R (`sky130`), **IHP SG13G2** 1P (`ihp`), **GF180MCU** 1RW (`gf180`) -> 9 floorplans. The three `commercial_*_pending.json` manifests carry no data and are never used.

## How to run

```
python3 -I scripts/gen_physical.py && python3 -I check_floorplan.py     # generate everything, then the independent legality checker
python3 -I check_asic_collateral.py --write-md                           # re-scan the audit tree for LEF/GDS/Liberty/SPICE; rewrites asic_readiness.md
python3 -I scripts/floorplanlab_integration.py                           # OPTIONAL: runs a reviewed COPY of FloorplanLab's own validators (executes input code; see floorplanlab/INTEGRATION.md)
```

(`-I` is optional for our own scripts; they read the manifests as JSON data only.) Paths default to the extracted audit tree; override with `--manifests DIR` / `SILICAFLUX_MANIFESTS`.

## Results

| floorplan | macro | NC x NR / bank | instances | macro area mm2 (a) | die W x H um (b) | die mm2 (b) | macro-only / die (b) | bit util (b) | flags |
|---|---|---|---|---|---|---|---|---|---|
| C1_sky130 | `sky130_sram_2kbyte_1rw1r_32x512_8` | 4 x 2 | 32 | 9.1052 | 3,023.2 x 3,652.3 | 11.042 | 82.5 % | 100.00 % | READ_PORT_WASTED |
| C1_ihp | `RM_IHPSG13_1P_1024x64_c2_bm_bist` | 2 x 1 | 8 | 2.1116 | 1,919.5 x 1,585.8 | 3.044 | 69.4 % | 100.00 % | TEST_PINS_TIED |
| C1_gf180 | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 16 x 2 | 128 | 26.8032 | 7,431.1 x 4,199.0 | 31.203 | 85.9 % | 100.00 % | MANY_INSTANCES, SMALL_MACROS_ONLY |
| C2_sky130 | `sky130_sram_2kbyte_1rw1r_32x512_8` | 5 x 2 | 40 | 11.3815 | 3,726.3 x 3,652.3 | 13.610 | 83.6 % | 85.62 % | READ_PORT_WASTED, UNUSED_BITS |
| C2_ihp | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | 5 x 1 | 20 | 2.8037 | 2,493.8 x 1,585.8 | 3.955 | 70.9 % | 85.62 % | TEST_PINS_TIED, UNUSED_BITS |
| C2_gf180 | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 18 x 2 | 144 | 30.1536 | 8,334.8 x 4,199.0 | 34.998 | 86.2 % | 95.14 % | UNUSED_BITS, MANY_INSTANCES, SMALL_MACROS_ONLY |
| C3_sky130 | `sky130_sram_2kbyte_1rw1r_32x512_8` | 4 x 8 | 128 | 36.4209 | 5,744.8 x 7,189.1 | 41.300 | 88.2 % | 100.00 % | READ_PORT_WASTED, MANY_INSTANCES |
| C3_ihp | `RM_IHPSG13_1P_2048x64_c2_bm_bist` | 2 x 2 | 16 | 7.8661 | 3,337.9 x 2,824.5 | 9.428 | 83.4 % | 100.00 % | TEST_PINS_TIED |
| C3_gf180 | `gf180mcu_fd_ip_sram__sram512x8m8wm1` | 16 x 8 | 512 | 107.2129 | 14,579.5 x 8,255.4 | 120.359 | 89.1 % | 100.00 % | MANY_INSTANCES, LOGIC_RESERVE_SLIVER, SMALL_MACROS_ONLY, PIN_FACING_TIGHT |

Source of every number: `floorplan_<cfg>_<family>.json` -> `areas`, recomputed independently by `check_floorplan.py`; arithmetic shown in `area_report.md` section 2. (a) = manifest field, (b) = derived.

Notable findings: (1) for C2 (137-bit stored word) the uniform tilings waste provisioned bits in the 9 ECC columns (bit utilisation: SKY130 85.6 %, IHP 85.6 %, GF180 95.1 %); a two-macro tiling would save area but needs the RTL to split the stored word (computed in `area_report.md`, not floorplanned). (2) SKY130 1RW1R macros leave a read port idle in every instance (32 / 40 / 128 instances for C1 / C2 / C3). (3) C3 (256 KiB) macro-only area: IHP 16 instances / 7.87 mm2, SKY130 128 / 36.42 mm2, GF180 512 / 107.21 mm2 - tileable by arithmetic, but GF180 (8-bit-wide macros, 512 words max) is impractical at this capacity.

## How the geometry is built

* Coordinates: um, die lower-left = (0,0), x right, y up; a macro (x, y) is the lower-left of its placed bounding box.
* Bank = NC x NR grid of one macro shape (`tile_col` across = data-bit slice, `tile_row` up = depth slice), neighbours `macro_gap` apart (= halo). Orientation R0 on even rows, MX on odd rows. Bank placement region = bounding box of its macros.
* Four identical banks; the layout (2x2 with a central controller band, 4 in a row, or 4 in a column; chosen per floorplan by die aspect ratio closest to 1) is separated by routing channels (bank-bank and bank-logic), all `channel` wide; the controller/logic reserve is one rectangle of the placeholder area adjoining the bank block; core pad = halo; die margin around the core.
* Partition identity (checked): die = macros + intra-bank gaps + channels + logic reserve + core pad ring + die margin ring. Halos are a keepout overlay inside gaps/channels/pad.

## Verification as run

`check_floorplan.py` (independent checker) result recorded in `logs/check_floorplan_report.json`: **9/9 floorplans PASS**, 488 individual checks passed / 0 failed (incl. cross-artefact checks of CSV, SVG, Tcl, FloorplanLab RunSpecs, dashboard), **14/14 negative tests caught** (overlap, partial overlap, outside die, halo violation, region overlap, narrow channel, missing PG, wrong dimension, placeholder macro, illegal orientation, logic overlap, missing instance...). Overall: PASS.

Console output: `logs/check_floorplan.log`. `logs/determinism.txt` records that two consecutive generator runs produce byte-identical outputs. `logs/find_collateral.txt` is the raw `find` output behind `asic_readiness.md`. The checker validates the Tcl only structurally (no Tcl interpreter available).

## File map

| path | content |
|---|---|
| `scripts/gen_physical.py` | the generator (stdlib only, deterministic) |
| `macro_inventory.csv`, `macro_inventory.json` | one row per macro instance (name, macro, family/process, w/h/area, bank, tile row/col, orientation, x/y, source manifest, `physical.source` + sha256, provenance repo/commit) |
| `floorplan_<cfg>_<family>.json` (9) | die/core, bank regions, macro placements, halos, channels, logic reserve, PG table per macro, tiling arithmetic, areas, parameters with ASSUMPTION labels |
| `area_report.md`, `area_report.json` | area accounting, tiling candidates, flags, channel-width derivation note, manifest validation |
| `check_floorplan.py` | independent legality checker + negative tests (re-reads manifests; does not import the generator) |
| `openroad/floorplan_<cfg>_<family>.tcl` (9) | OpenROAD/OpenDB Tcl that reproduces the placement - **UNEXECUTED** |
| `svg/floorplan_<cfg>_<family>.svg` (9) | to-scale drawings (titled `GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT`) |
| `dashboard_floorplan.json` | compact JSON for a web dashboard (every entry labelled `generated-geometry`) |
| `asic_readiness.md`, `check_asic_collateral.py`, `asic_collateral_check.json` | per-view ASIC collateral requirement vs what the repo contains; scan results |
| `floorplanlab/` | FloorplanLab-schema RunSpecs (`runs/`), design stub, integration log (`INTEGRATION.md`, `integration_result.json`) |
| `logs/` | checker output, determinism check, find output, manifest cross-checks |

## FloorplanLab integration

FloorplanLab's full flow (`make floorplan-*`, ORFS, OpenROAD, Yosys) could **not** run here: ORFS_FLOW, OPENROAD_EXE, YOSYS_EXE, KLAYOUT_EXE, IHP_SRAM are absent (tools.env points to `/opt/eda/...`), MemoryCore is not a FloorplanLab design (its `design.yaml` is declared `status: not_available`, RTL not vendored), and `Run.check()` shells out to git/archives.

What did run (`floorplanlab_integration.py`, on a deleted-afterwards copy; original tree hash unchanged: True): FloorplanLab's own pure-Python validators on our geometry.


* RunSpec schema (`load_run`, pydantic): **9/9** generated `floorplanlab/runs/MC_*.yaml` valid.
* GATE-5 geometry rules (`mode_a` + `check_geometry`): **1/9** error-free; the other errors (error:NO_STD_REGION, error:OVER_UTILISED) come from FloorplanLab's utilisation bookkeeping: it subtracts every macro's halo ring separately, double-counting halo shared by neighbouring macros, so for our dense packing it finds no/too little standard-cell region for the placeholder logic area. It is a sizing-rule disagreement, not a macro overlap or out-of-die finding.
* GATE-6 macro rules (`check_macro_placement`: overlap, spacing >= halo, orientation, inside core, pin-escape strips): **0/9** error-free overall; **9/9** have no overlap / spacing / orientation / outside-core error. The remaining findings (error:PIN_ACCESS_BLOCKED, error:PIN_ACCESS_EDGE) are FloorplanLab's pin-escape rule, evaluated with an *assumed* pin edge: outer rows' pin edges face the core boundary (pad 20 um < required max(channel, halo) = 40 um) and, for 8-row stacks, pin-facing rows are one halo apart.
* Platform profiles `check_platform`: commercial_130 template (10 errors), commercial_28 template (10 errors), commercial_65 template (10 errors), gf180mcu disabled (5 errors), ihp_sg13g2 enabled (19 errors), sky130hd enabled (9 errors) - every enabled platform fails offline on missing ORFS/LEF/Liberty files.
Details and per-run finding codes: `floorplanlab/INTEGRATION.md`, `floorplanlab/integration_result.json`.


## Assumptions (all parameters, never measured)

1. Halo 20 um, channel width 40 um, die margin 40 um: borrowed from FloorplanLab's `floorplan_base.yaml` exploration values; not derived from any PDK rule or routing analysis.
2. Macro-to-macro gap = halo (20 um) and core pad = halo: the smallest values that satisfy the checker's 'halo must not overlap another macro body' and keep halos inside the core.
3. Controller/logic reserve = 250,000 um2 **placeholder** (same for every floorplan). No synthesis figure is used; hook: `--logic-area-json FILE` with `{"area_um2": N, "source": "..."}`.
4. Orientation: tile row even -> R0, odd -> MX, so vertically adjacent macros mirror about their shared edge. Pin geometry is unknown from the manifests; this is not a pin-aware plan.
5. Macro tiling is uniform (as the library's `sram_asic_array`); banks use the same shape; bank placement order and layout (2x2 / row / column) are generator choices.
6. PG: manifest `supply_pins` -> nets by name pattern (`vccd*`/`VDD` -> VDD, `vssd*`/`VSS` -> VSS, `VDDARRAY` kept as its own net). Voltages are corner labels read from manifest fields, not verified supply ratings.
7. FloorplanLab site names (`unithd`, `CoreSite`, `GF018hv5v_green_sc9`) and the IHP routing pitches in the channel note come from FloorplanLab's docs/profiles, not from any LEF in the repo.

## KNOWN LIMITATIONS

* **No pin geometry in the manifests**, and no LEF/GDS/Liberty/SPICE files in the repository (checked with `find`; `asic_readiness.md`). A LEF-derived JSON abstract of the macros exists in the `silicaflux-sramgrid-p33` project (pin edges, symmetry); it is used only as labelled secondary evidence and as a dimension cross-check, never to produce a number here.
* **OpenROAD was not run** (not installed): the Tcl files are unexecuted. No Tcl interpreter exists here either, so they were only structurally linted (brace/bracket/quote balance, argument counts) by `check_floorplan.py`. The `cut_rows` halo option names were not confirmed against a live `help` output.
* Halo, channel width, die margin, macro gap and the logic reserve are assumptions; die areas are therefore *planning figures*, not estimates of a taped-out area.
* **No timing, power, IR-drop, DRC, LVS, congestion or routability results** of any kind. No PDN/ring/strap area is included.
* The 4-bank 2x2 / row / column arrangement and the idea that all pins reach a central controller band are not validated by any pin-escape analysis; FloorplanLab's own pin-escape rule can flag the stacked-row spacing (see `floorplanlab/INTEGRATION.md`).
* FloorplanLab's full flow could not run here (no OpenROAD/ORFS/Yosys/PDK collateral; MemoryCore is not a FloorplanLab design) - only its pure-Python validators were exercised on a copy.
* FPGA-inferred memory (BRAM) results elsewhere in the repo say nothing about ASIC readiness.
