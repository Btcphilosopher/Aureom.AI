# FloorplanLab integration - what was done and what could not be

> **GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT**

## Files in FloorplanLab's schema

* `floorplanlab/runs/MC_<cfg>_<family>.yaml` (9): FloorplanLab `RunSpec` (`python/floorplanlab/config.py`): `floorplan.mode: A` with `die_area` / `core_area`, `macros.placement: manual` with explicit `positions: {instance: [x, y, orient]}`, `halo_um`, `channel_um`, `platform` = `sky130hd` / `ihp_sg13g2` / `gf180mcu`.
* `floorplanlab/configs/silicaflux_memorycore/design.yaml`: design stub following the repo convention of `configs/mcu_i/design.yaml` (`status: not_available`): FloorplanLab vendors only SilicaFlux-V + DataFabric RTL, so MemoryCore cannot be a FloorplanLab design without vendoring RTL and writing an SDC template, `expected_macros` per platform and `macro_groups`.

## What was executed (offline, on a copy)

The extracted FloorplanLab tree was copied to a fresh directory, its `config`, `geometry`, `validate`, `lef`, `liberty` and `orfs` modules were imported (reviewed beforehand: no subprocess/network/eval/exec in config, geometry, validate, lef, liberty; `orfs` contains subprocess helpers that were NOT called - only `orfs.tools()` was) and the following FloorplanLab functions were called. The original tree hash before/after: `49de62730049aba6` -> `49de62730049aba6` (**unmodified: True**); the copy was deleted (True).

### Tool availability (`orfs.tools()`; what `make floorplan-tools` tests)

| tool / collateral | path in tools.env | exists |
|---|---|---|
| ORFS_FLOW | `/opt/eda/orfs/flow` | **no** |
| OPENROAD_EXE | `/opt/eda/env/bin/openroad` | **no** |
| YOSYS_EXE | `/opt/eda/env/bin/yosys` | **no** |
| KLAYOUT_EXE | `/usr/bin/klayout` | **no** |
| IHP_SRAM | `/opt/eda/collateral/ihp-sg13g2-sram-d0e5b3c` | **no** |

### Platform profiles (`load_platform` + `check_platform`)

| platform | status | errors | main codes |
|---|---|---|---|
| commercial_130 | template | 10 | error:MISSING_COLLATERAL x4, error:PLATFORM_NOT_ENABLED x1, error:UNFILLED_TEMPLATE x5 |
| commercial_28 | template | 10 | error:MISSING_COLLATERAL x4, error:PLATFORM_NOT_ENABLED x1, error:UNFILLED_TEMPLATE x5 |
| commercial_65 | template | 10 | error:MISSING_COLLATERAL x4, error:PLATFORM_NOT_ENABLED x1, error:UNFILLED_TEMPLATE x5 |
| gf180mcu | disabled | 5 | error:FILE_NOT_FOUND x2, error:MISSING_COLLATERAL x2, error:PLATFORM_NOT_ENABLED x1 |
| ihp_sg13g2 | enabled | 19 | error:FILE_NOT_FOUND x19, warning:CORNER_UNAVAILABLE x2, warning:MACRO_NO_GDS x4 |
| sky130hd | enabled | 9 | error:FILE_NOT_FOUND x9, warning:CORNER_UNAVAILABLE x2, warning:MACRO_NO_GDS x1 |

### Design (`load_design('silicaflux_memorycore')`)

`ConfigError`: design 'silicaflux_memorycore' is not available: MemoryCore RTL is not vendored into FloorplanLab; geometry-only RunSpecs provided

### Our 9 RunSpecs: schema and geometry gates

`pin_side_r0` (needed by FloorplanLab's pin-escape rule) is an ASSUMPTION taken from the dominant edge of the secondary LEF-derived abstract (`bottom` for all three families); it is not verified against any LEF.

| run | RunSpec schema | GATE 5 errors | GATE 6 errors | GATE 6 errors excl. pin-escape | GATE 6 finding codes |
|---|---|---|---|---|---|
| MC_C1_gf180 | PASS | 1 | 32 | 0 | error:PIN_ACCESS_EDGE x32 |
| MC_C1_ihp | PASS | 0 | 2 | 0 | error:PIN_ACCESS_EDGE x2 |
| MC_C1_sky130 | PASS | 1 | 8 | 0 | error:PIN_ACCESS_EDGE x8 |
| MC_C2_gf180 | PASS | 1 | 36 | 0 | error:PIN_ACCESS_EDGE x36 |
| MC_C2_ihp | PASS | 1 | 5 | 0 | error:PIN_ACCESS_EDGE x5 |
| MC_C2_sky130 | PASS | 1 | 10 | 0 | error:PIN_ACCESS_EDGE x10 |
| MC_C3_gf180 | PASS | 1 | 448 | 0 | error:PIN_ACCESS_BLOCKED x384, error:PIN_ACCESS_EDGE x64 |
| MC_C3_ihp | PASS | 1 | 8 | 0 | error:PIN_ACCESS_EDGE x8 |
| MC_C3_sky130 | PASS | 1 | 112 | 0 | error:PIN_ACCESS_BLOCKED x96, error:PIN_ACCESS_EDGE x16 |

Reading the table:

* `MACRO_OVERLAP`, `MACRO_SPACING`, `MACRO_OUTSIDE_CORE`, `ILLEGAL_ORIENT`, `MACRO_OFF_GRID` would indicate real macro-geometry problems: **none occurs**.
* `PIN_ACCESS_EDGE` / `PIN_ACCESS_BLOCKED` come from FloorplanLab's pin-escape rule: the strip max(channel, halo) = 40 um in front of every pin edge must lie inside the core and be free of other macro bodies. With the assumed pin edge (R0 bottom), the first row of a bank (R0) has its pins facing the core pad (20 um < 40 um) and the top MX row likewise (`PIN_ACCESS_EDGE`); in 8-row stacks the pin-facing row boundaries are only one halo (20 um) apart (`PIN_ACCESS_BLOCKED`, C3 sky130 and C3 gf180). This is a genuine limitation of the generated packing: it is **not pin-aware** (pin geometry is unknown from the manifests; the orientation scheme is an assumption).
* `NO_STD_REGION` / `OVER_UTILISED` (GATE 5) come from FloorplanLab's bookkeeping `std region = core - macros - sum(per-macro halo rings)`, which double-counts halo shared by neighbouring macros. In our packing every halo lies inside the gaps/channels/core pad (our exact union accounting in `area_report.md` shows the halo keepout adds no die area), so the rule concludes there is no room for the placeholder logic area although nothing overlaps. Per-run numbers (um2):

| run | core | macro area | sum of halo rings (FloorplanLab) | std region left (FloorplanLab) | implied util of the logic placeholder |
|---|---|---|---|---|---|
| MC_C1_gf180 | 30,279,269 | 26,803,235 | 4,898,509 | -1,422,475 | n/a (region <= 0) |
| MC_C1_ihp | 2,770,023 | 2,111,569 | 371,501 | 286,953 | 0.87 |
| MC_C1_sky130 | 10,513,981 | 9,105,231 | 1,458,739 | -49,990 | n/a (region <= 0) |
| MC_C2_gf180 | 34,001,728 | 30,153,640 | 5,510,822 | -1,662,734 | n/a (region <= 0) |
| MC_C2_ihp | 3,634,736 | 2,803,654 | 634,480 | 196,602 | 1.27 |
| MC_C2_sky130 | 13,025,679 | 11,381,539 | 1,823,424 | -179,284 | n/a (region <= 0) |
| MC_C3_gf180 | 118,538,941 | 107,212,942 | 19,594,035 | -8,268,036 | n/a (region <= 0) |
| MC_C3_ihp | 8,941,329 | 7,866,138 | 928,755 | 146,436 | 1.71 |
| MC_C3_sky130 | 40,271,573 | 36,420,925 | 5,834,957 | -1,984,308 | n/a (region <= 0) |


## What could NOT be run, and exactly why

* **make floorplan-check / floorplan-run / ... (full ORFS flow)** - Makefile target floorplan-tools requires OPENROAD_EXE; tools.env points to /opt/eda/... which does not exist here (see tools[]); ORFS, Yosys-ORFS and the IHP SRAM collateral (LEF/Liberty) are also absent
* **floorplanlab.pipeline.Run.check() (GATE 1/4 + run prechecks for a design)** - needs a design.yaml with RTL (ours is declared not_available) and shells out to `git` and tools/import_sources.py --check (needs the SilicaFlux archives) - also not run because this task forbids using git
* **V.check_macro_channels_pdn / check_macro_pin_coverage (PDN rules)** - need parsed tech/macro LEFs (layer directions, PG stripe rectangles); none in the repo
* **FloorplanLab pytest suite (tests/)** - pytest is not installed in this environment; several tests also require the EDA tools
* **check_platform LEF/Liberty fact checks** - platform LEF/Liberty paths do not exist offline (FILE_NOT_FOUND); gf180mcu is `disabled`, commercial_* are templates

## Net effect

FloorplanLab integration is **partial**: we emit configs in its schema that its own loader validates and whose geometry its own placement/geometry checks evaluate; we cannot obtain any result from its flow (no placement, PDN, STA, routing) because the toolchain, PDK collateral and MemoryCore RTL are absent. No FloorplanLab result is claimed for MemoryCore beyond the validator outputs above.
