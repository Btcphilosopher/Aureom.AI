#!/usr/bin/env python3
"""gen_physical.py -- SilicaFlux MemoryCore physical-design geometry generator.

Reads the open-PDK SRAM macro manifests (JSON data only; nothing from the input
tree is executed) and deterministically produces, for 3 memory configurations x
3 macro families:

  macro_inventory.csv/.json, floorplan_<cfg>_<family>.json, area_report.md/.json,
  openroad/floorplan_<cfg>_<family>.tcl (UNEXECUTED), svg/floorplan_<cfg>_<family>.svg,
  dashboard_floorplan.json, floorplanlab/ (configs in FloorplanLab's schema),
  logs/crosscheck_manifest_vs_sramgrid_abstracts.json, README.md

Every macro dimension / area comes from a manifest field (physical.width_um,
physical.height_um, physical.area_um2).  Halo, channel, die margin, macro gap and
the controller/logic reserve are ASSUMPTION parameters and are labelled as such
in every output.  This is GEOMETRY-LEVEL PLANNING ONLY: no pin geometry, no
routing, no timing, no power, no DRC/LVS.

Usage:  python3 -I scripts/gen_physical.py [--manifests DIR] [--out DIR]
            [--halo-um 20] [--channel-um 40] [--die-margin-um 40]
            [--macro-gap-um HALO] [--core-pad-um HALO]
            [--logic-area-um2 250000 | --logic-area-json FILE] [--layout auto|grid2x2|row4|col4]
Standard library only; no randomness; no timestamps (re-running reproduces the
same bytes).
"""
import argparse
import csv
import glob
import json
import math
import os
import re
import sys

DISCLAIMER = "GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT"
LABEL = "generated-geometry"
SCHEMA = "silicaflux-memorycore-physical/floorplan/1"
GENERATOR = "scripts/gen_physical.py"

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DEFAULT = os.path.dirname(HERE)
_SCRATCH = os.environ.get("SILICAFLUX_SCRATCH", "scratch")   # directory that contains audit/x/<extracted project archives>
MANIFESTS_DEFAULT = os.environ.get(
    "SILICAFLUX_MANIFESTS",
    _SCRATCH + "/audit/x/silicaflux-sramlib/silicaflux-sramlib/manifests")
ABSTRACTS_DEFAULT = os.environ.get(
    "SILICAFLUX_SRAMGRID_ABSTRACTS",
    _SCRATCH + "/audit/x/silicaflux-sramgrid-p33/silicaflux-sramgrid/physical/abstracts")

# ----------------------------------------------------------------------------
# Memory configurations (architecture given by the RTL project)
# ----------------------------------------------------------------------------
CONFIGS = {
    "C1": dict(banks=4, depth=1024, row_w=128, ecc=False,
               desc="4 banks x 1024 rows x 128 b (64 KiB), no ECC"),
    "C2": dict(banks=4, depth=1024, row_w=137, ecc=True,
               desc="4 banks x 1024 rows x 137 b (SECDED (137,128) stored word)"),
    "C3": dict(banks=4, depth=4096, row_w=128, ecc=False,
               desc="4 banks x 4096 rows x 128 b (256 KiB), no ECC"),
}

# Macro families with real manifests.  `platform`/`site` come from FloorplanLab's
# platforms/*/profile.yaml (place_site) -- repo data, but NOT verified against any
# tech LEF (none in the repo).
FAMILIES = {
    "sky130": dict(manifest_family="SKY130_1RW1R", title="SKY130 OpenRAM 1RW1R",
                   flp_platform="sky130hd", site="unithd", flp_status="enabled (ORFS sky130hd)"),
    "ihp": dict(manifest_family="IHP_1P", title="IHP SG13G2 1P (1RW)",
                flp_platform="ihp_sg13g2", site="CoreSite", flp_status="enabled (ORFS ihp-sg13g2)"),
    "gf180": dict(manifest_family="GF180_1RW", title="GF180MCU 1RW",
                  flp_platform="gf180mcu", site="GF018hv5v_green_sc9",
                  flp_status="DISABLED in FloorplanLab (no SRAM collateral in its ORFS pin)"),
}

BANK_NAMES = ["bank0", "bank1", "bank2", "bank3"]
LAYOUT_ORDER = ["grid2x2", "row4", "col4"]
GRID = 0.01  # all manifest dimensions are multiples of 0.01 um


# ----------------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------------
def r4(v):
    return round(v, 4) + 0.0


def ceil_div(a, b):
    return -(-a // b)


def ceil_grid(v, g=GRID):
    return r4(math.ceil(v / g - 1e-9) * g)


def rect_area(r):
    return (r[2] - r[0]) * (r[3] - r[1])


def rect_overlap_area(a, b):
    dx = min(a[2], b[2]) - max(a[0], b[0])
    dy = min(a[3], b[3]) - max(a[1], b[1])
    return dx * dy if dx > 1e-9 and dy > 1e-9 else 0.0


def union_area(rects):
    """Exact union area of axis-aligned rectangles (integer nm arithmetic)."""
    if not rects:
        return 0.0
    ir = [(round(a * 1000), round(b * 1000), round(c * 1000), round(d * 1000)) for a, b, c, d in rects]
    xs = sorted({x for r in ir for x in (r[0], r[2])})
    ir.sort()
    total = 0
    for i in range(len(xs) - 1):
        x0, x1 = xs[i], xs[i + 1]
        ivs = sorted((r[1], r[3]) for r in ir if r[0] <= x0 and r[2] >= x1)
        cur_lo = cur_hi = None
        ylen = 0
        for lo, hi in ivs:
            if cur_hi is None or lo > cur_hi:
                if cur_hi is not None:
                    ylen += cur_hi - cur_lo
                cur_lo, cur_hi = lo, hi
            elif hi > cur_hi:
                cur_hi = hi
        if cur_hi is not None:
            ylen += cur_hi - cur_lo
        total += (x1 - x0) * ylen
    return total / 1e6


def fmt(v, nd=2):
    return f"{v:,.{nd}f}"


def num(v):
    """Exact-enough decimal text for coordinates (never %g: it truncates to 6 significant digits)."""
    t = ("%.4f" % v).rstrip("0").rstrip(".")
    return "0" if t in ("", "-0") else t


COMPACT_ITEM_KEYS = {"macros", "channels", "candidates", "pins", "records", "instances", "halos", "bank_regions", "summary", "macros_in_use", "failed"}


def _clean(o):
    """round floats to 9 decimals (kills 0.30000000000000004-style noise); recurse into containers"""
    if isinstance(o, float):
        return round(o, 9) + 0.0
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    return o


def dumps_pretty(obj, level=0, key=None):
    """Readable JSON: containers are indented one space per level, but every item of a list under a
    COMPACT_ITEM_KEYS key is written on ONE line (keeps the files small and diff-friendly)."""
    if not isinstance(obj, (dict, list)) or not obj:
        return json.dumps(_clean(obj), separators=(",", ":"))
    pad, end = " " * (level + 1), " " * level
    if isinstance(obj, dict):
        items = [pad + json.dumps(k) + ": " + dumps_pretty(v, level + 1, k) for k, v in obj.items()]
        return "{\n" + ",\n".join(items) + "\n" + end + "}"
    if key in COMPACT_ITEM_KEYS:
        items = [pad + json.dumps(_clean(v), separators=(",", ":")) for v in obj]
    else:
        items = [pad + dumps_pretty(v, level + 1, None) for v in obj]
    return "[\n" + ",\n".join(items) + "\n" + end + "]"


def write_json(path, obj, indent=1):
    with open(path, "w") as f:
        f.write(dumps_pretty(obj))
        f.write("\n")


def halo_rect(m, halo):
    return [r4(m["x"] - halo), r4(m["y"] - halo), r4(m["x"] + m["w"] + halo), r4(m["y"] + m["h"] + halo)]


# ----------------------------------------------------------------------------
# manifests
# ----------------------------------------------------------------------------
NAME_PATTERNS = {
    # family -> (regex, group order) ; used to cross-check name-encoded geometry vs manifest fields
    "SKY130_1RW1R": (re.compile(r"^sky130_sram_(\d+)kbyte_1rw1r_(\d+)x(\d+)_8$"), "kb,width,words"),
    "IHP_1P": (re.compile(r"^RM_IHPSG13_1P_(\d+)x(\d+)_c\d_bm_bist$"), "words,width"),
    "IHP_2P": (re.compile(r"^RM_IHPSG13_2P_(\d+)x(\d+)_c\d_bm_bist$"), "words,width"),
    "GF180_1RW": (re.compile(r"^gf180mcu_fd_ip_sram__sram(\d+)x8m8wm1$"), "words"),
}


def derive_voltage(raw):
    """Supply voltage from manifest fields only.  Returns dict (never invents a number)."""
    t = raw.get("timing")
    if isinstance(t, dict) and isinstance(t.get("corner"), str):
        mt = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*V\b", t["corner"])
        if mt:
            return dict(vdd_v=float(mt.group(1)), basis="manifest timing.corner = %r (corner label of the extracted timing numbers)" % t["corner"],
                        status="DERIVED_FROM_MANIFEST_CORNER_LABEL")
    libs = (raw.get("views") or {}).get("liberty") or []
    cands = []
    for p in libs:
        b = os.path.basename(p)
        if re.search(r"(^|_)(tt|typ)(_|\.|$)", b.lower()):
            mt = re.search(r"(\d)[pv](\d{1,2})V?(?=_|\.|$)", b)
            if mt:
                cands.append((float(mt.group(1) + "." + mt.group(2)), b))
    vs = sorted({v for v, _ in cands})
    if len(vs) == 1:
        return dict(vdd_v=vs[0], basis="manifest views.liberty typical-corner file name %r (corner label, not a datasheet supply rating)" % cands[0][1],
                    status="DERIVED_FROM_LIBERTY_FILE_NAME")
    return dict(vdd_v=None, basis="no voltage stated in manifest", status="NOT_IN_MANIFEST", candidates=vs)


def map_supply_pin(pin):
    """Map a manifest supply pin name to a net by NAME PATTERN (assumption: LEF not in repo)."""
    p = pin.lower()
    if "vddio" in p:
        return "VDDIO", "name-pattern"
    if p.startswith("vddarray"):
        return "VDDARRAY", "name-pattern (separate array supply; see note)"
    if p.startswith("vdd") or p.startswith("vcc"):
        return "VDD", "name-pattern"
    if p.startswith("vss") or p.startswith("gnd"):
        return "VSS", "name-pattern"
    return "UNMAPPED", "no rule"


def load_manifests(mdir):
    macros, excluded, validation = [], [], []
    files = sorted(glob.glob(os.path.join(mdir, "*.json")))
    if not files:
        sys.exit("no manifests found in %s" % mdir)
    for fp in files:
        with open(fp) as f:
            raw = json.load(f)
        base = os.path.basename(fp)
        phys = raw.get("physical") or {}
        if (raw.get("status") != "OPEN_SOURCE_AVAILABLE" or not raw.get("macro_name")
                or phys.get("width_um") is None or phys.get("height_um") is None or phys.get("area_um2") is None):
            excluded.append(dict(manifest=base, status=raw.get("status"), family=raw.get("family"),
                                 reason="placeholder / no data (status=%s, macro_name=%s): never used" % (raw.get("status"), raw.get("macro_name"))))
            continue
        name = raw["macro_name"]
        w, h, a = float(phys["width_um"]), float(phys["height_um"]), float(phys["area_um2"])
        issues = []
        # (1) area vs width*height
        if abs(w * h - a) > 0.01:
            issues.append("area_um2 %.4f != width*height %.4f" % (a, w * h))
        # (2) name-encoded geometry vs data_width/words
        pat = NAME_PATTERNS.get(raw.get("family"))
        if pat:
            mt = pat[0].match(name)
            if not mt:
                issues.append("macro_name does not match family naming pattern")
            else:
                g = list(map(int, mt.groups()))
                kind = pat[1]
                if kind == "kb,width,words":
                    kb, wd, wo = g
                    if wd != raw["data_width"] or wo != raw["words"] or kb * 8192 != wd * wo:
                        issues.append("name-encoded %dkB %dx%d != manifest data_width=%s words=%s" % (kb, wd, wo, raw["data_width"], raw["words"]))
                elif kind == "words,width":
                    wo, wd = g
                    if wd != raw["data_width"] or wo != raw["words"]:
                        issues.append("name-encoded words=%d width=%d != manifest words=%s data_width=%s" % (wo, wd, raw["words"], raw["data_width"]))
                else:
                    wo = g[0]
                    if wo != raw["words"] or raw["data_width"] != 8:
                        issues.append("name-encoded words=%d x8 != manifest words=%s data_width=%s" % (wo, raw["words"], raw["data_width"]))
        # (3) supply pins & provenance present
        if not raw.get("supply_pins"):
            issues.append("no supply_pins")
        prov = raw.get("provenance") or {}
        if not prov.get("repo") or not prov.get("commit"):
            issues.append("provenance repo/commit missing")
        src = phys.get("source")
        src_sha = (prov.get("files") or {}).get(src)
        lef_path = (raw.get("views") or {}).get("lef")
        lef_sha = (prov.get("files") or {}).get(lef_path) if isinstance(lef_path, str) else None
        v = derive_voltage(raw)
        m = dict(name=name, family=raw["family"], process=raw.get("process"), foundry=raw.get("foundry"),
                 data_width=int(raw["data_width"]), words=int(raw["words"]), topology=raw.get("port_topology"),
                 w=w, h=h, area=a, manifest=base, physical_source=src, physical_source_sha256=src_sha, lef_sha256=lef_sha,
                 prov_repo=prov.get("repo"), prov_commit=prov.get("commit"), supply_pins=list(raw.get("supply_pins") or []),
                 supply=v, views=raw.get("views") or {}, write_mask=raw.get("write_mask") or {},
                 port_list=raw.get("port_list") or [], pin_map=raw.get("pin_map") or {}, id=raw.get("id"),
                 supply_pin_condition=raw.get("supply_pin_condition"), tie_offs=raw.get("tie_offs") or {},
                 sleep_retention=raw.get("sleep_retention"), constraints=raw.get("constraints") or [])
        macros.append(m)
        validation.append(dict(macro=name, manifest=base, family=raw["family"], ok=not issues, issues=issues,
                               width_um=w, height_um=h, area_um2=a, width_x_height=r4(w * h)))
    return macros, excluded, validation


def load_abstracts(adir):
    out = {}
    if not os.path.isdir(adir):
        return out
    for fp in sorted(glob.glob(os.path.join(adir, "*.json"))):
        try:
            with open(fp) as f:
                d = json.load(f)
        except Exception:
            continue
        if isinstance(d, dict) and d.get("macro") and "width_um" in d:
            out[d["macro"]] = d
    return out


# ----------------------------------------------------------------------------
# tiling
# ----------------------------------------------------------------------------
def tile_uniform(cfg, m):
    dw, wd = m["data_width"], m["words"]
    nc = ceil_div(cfg["row_w"], dw)
    nr = ceil_div(cfg["depth"], wd)
    per_bank = nc * nr
    total = per_bank * cfg["banks"]
    prov = (nc * dw) * (nr * wd)
    req = cfg["row_w"] * cfg["depth"]
    return dict(macro_name=m["name"], data_width=dw, words=wd, nc=nc, nr=nr, per_bank=per_bank, total=total,
                macro_area_um2=m["area"], area_per_bank_um2=r4(per_bank * m["area"]),
                area_total_um2=r4(total * m["area"]), provisioned_bits_per_bank=prov, required_bits_per_bank=req,
                unused_bits_per_bank=prov - req, unused_data_bits_per_row=nc * dw - cfg["row_w"],
                unused_rows=nr * wd - cfg["depth"], bit_utilisation=req / prov,
                area_per_provisioned_bit_um2=m["area"] / (dw * wd))


def rank_candidates(cfg, macros):
    cands = [tile_uniform(cfg, m) for m in macros]
    cands.sort(key=lambda c: (round(c["area_total_um2"], 2), c["total"], c["macro_name"]))
    return cands


def hetero_alternative(cfg, macros, uniform_best):
    """Informational: best 2-group column composition (bulk macro A x nA + remainder macro B).
    NOT floorplanned: sramlib's sram_asic_array tiles with ONE macro (docs/mem/02 s.4)."""
    best = None
    for A in macros:
        nrA = ceil_div(cfg["depth"], A["words"])
        maxA = ceil_div(cfg["row_w"], A["data_width"])
        for nA in range(1, maxA):
            rem = cfg["row_w"] - nA * A["data_width"]
            if rem <= 0:
                continue
            for B in macros:
                if B is A:
                    continue
                nB = ceil_div(rem, B["data_width"])
                nrB = ceil_div(cfg["depth"], B["words"])
                bank_area = nA * nrA * A["area"] + nB * nrB * B["area"]
                inst = nA * nrA + nB * nrB
                key = (round(bank_area, 2), inst, A["name"], B["name"])
                if best is None or key < best[0]:
                    best = (key, A, nA, nrA, B, nB, nrB, bank_area, inst)
    if best is None:
        return None
    _, A, nA, nrA, B, nB, nrB, bank_area, inst = best
    total_area = cfg["banks"] * bank_area
    saving = uniform_best["area_total_um2"] - total_area
    if saving <= 0.005:
        return None
    return dict(macro_a=A["name"], cols_a=nA, rows_a=nrA, macro_b=B["name"], cols_b=nB, rows_b=nrB,
                instances_per_bank=inst, instances_total=cfg["banks"] * inst,
                area_total_um2=r4(total_area), saving_um2=r4(saving),
                saving_pct=100.0 * saving / uniform_best["area_total_um2"],
                bits_covered_per_row=nA * A["data_width"] + nB * B["data_width"],
                note="needs the RTL to split the stored word into two macro arrays; sramlib sram_asic_array tiles with a single macro; NOT floorplanned")


# ----------------------------------------------------------------------------
# layouts
# ----------------------------------------------------------------------------
def _ch(cid, kind, rect, between):
    rect = tuple(r4(v) for v in rect)
    return dict(id=cid, kind=kind, rect=rect, between=between)


def plan_layout(kind, bw, bh, c, pad, logic_area):
    """Core-relative geometry (origin = core lower-left). Returns dict."""
    if kind == "grid2x2":
        inner_w = 2 * bw + c
        lh = ceil_grid(logic_area / inner_w)
        y_bot = pad
        y_logic0 = pad + bh + c
        y_logic1 = y_logic0 + lh
        y_top = y_logic1 + c
        banks = [(pad, y_bot), (pad + bw + c, y_bot), (pad, y_top), (pad + bw + c, y_top)]
        channels = [
            _ch("ch_bank0_bank1", "bank_bank", (pad + bw, y_bot, pad + bw + c, y_bot + bh), ["bank0", "bank1"]),
            _ch("ch_bank2_bank3", "bank_bank", (pad + bw, y_top, pad + bw + c, y_top + bh), ["bank2", "bank3"]),
            _ch("ch_banks01_logic", "bank_logic", (pad, y_bot + bh, pad + inner_w, y_logic0), ["bank0", "bank1", "logic"]),
            _ch("ch_logic_banks23", "bank_logic", (pad, y_logic1, pad + inner_w, y_top), ["logic", "bank2", "bank3"]),
        ]
        logic = (pad, y_logic0, pad + inner_w, y_logic1)
        core_w, core_h = inner_w + 2 * pad, y_top + bh + pad
        desc = "2x2 banks (bank0 bottom-left, bank1 bottom-right, bank2 top-left, bank3 top-right); full-width controller band between the two bank rows"
    elif kind == "row4":
        inner_w = 4 * bw + 3 * c
        lh = ceil_grid(logic_area / inner_w)
        logic = (pad, pad, pad + inner_w, pad + lh)
        y_b = pad + lh + c
        banks = [(pad + k * (bw + c), y_b) for k in range(4)]
        channels = [_ch("ch_banks_logic", "bank_logic", (pad, pad + lh, pad + inner_w, y_b), ["bank0", "bank1", "bank2", "bank3", "logic"])]
        for k in range(3):
            x0 = pad + k * (bw + c) + bw
            channels.append(_ch("ch_bank%d_bank%d" % (k, k + 1), "bank_bank", (x0, y_b, x0 + c, y_b + bh), ["bank%d" % k, "bank%d" % (k + 1)]))
        core_w, core_h = inner_w + 2 * pad, y_b + bh + pad
        desc = "4 banks in a row (bank0..bank3 left to right); full-width controller band below the banks"
    elif kind == "col4":
        inner_h = 4 * bh + 3 * c
        lw = ceil_grid(logic_area / inner_h)
        banks = [(pad, pad + k * (bh + c)) for k in range(4)]
        channels = [_ch("ch_banks_logic", "bank_logic", (pad + bw, pad, pad + bw + c, pad + inner_h), ["bank0", "bank1", "bank2", "bank3", "logic"])]
        for k in range(3):
            y0 = pad + k * (bh + c) + bh
            channels.append(_ch("ch_bank%d_bank%d" % (k, k + 1), "bank_bank", (pad, y0, pad + bw, y0 + c), ["bank%d" % k, "bank%d" % (k + 1)]))
        logic = (pad + bw + c, pad, pad + bw + c + lw, pad + inner_h)
        core_w, core_h = bw + c + lw + 2 * pad, inner_h + 2 * pad
        desc = "4 banks in a column (bank0 at the bottom); full-height controller band on the right"
    else:
        raise ValueError(kind)
    return dict(kind=kind, desc=desc, banks=[(r4(x), r4(y)) for x, y in banks], channels=channels,
                logic=tuple(r4(v) for v in logic), core_w=r4(core_w), core_h=r4(core_h))


def choose_layout(requested, bw, bh, c, pad, dm, logic_area):
    cands = {}
    for k in LAYOUT_ORDER:
        L = plan_layout(k, bw, bh, c, pad, logic_area)
        dw, dh = L["core_w"] + 2 * dm, L["core_h"] + 2 * dm
        cands[k] = (abs(math.log(dw / dh)), dw, dh, L)
    if requested != "auto":
        k = requested
    else:
        k = min(LAYOUT_ORDER, key=lambda kk: (round(cands[kk][0], 9), LAYOUT_ORDER.index(kk)))
    info = {kk: dict(die_w_um=r4(v[1]), die_h_um=r4(v[2]), aspect_w_over_h=round(v[1] / v[2], 3), die_area_um2=r4(v[1] * v[2]))
            for kk, v in cands.items()}
    return cands[k][3], info, k


# ----------------------------------------------------------------------------
# floorplan construction
# ----------------------------------------------------------------------------
def build_floorplan(ckey, cfg, fkey, fam, macro, cands, hetero, P, abstracts):
    til = cands[0]
    assert til["macro_name"] == macro["name"]
    nc, nr = til["nc"], til["nr"]
    halo, chan, dm = P["halo_um"], P["channel_um"], P["die_margin_um"]
    gap, pad = P["macro_gap_um"], P["core_pad_um"]
    mw, mh = macro["w"], macro["h"]
    bw = r4(nc * mw + (nc - 1) * gap)
    bh = r4(nr * mh + (nr - 1) * gap)
    L, layout_info, lkind = choose_layout(P["layout"], bw, bh, chan, pad, dm, P["logic_area_um2"])
    core_w, core_h = L["core_w"], L["core_h"]
    die = (0.0, 0.0, r4(core_w + 2 * dm), r4(core_h + 2 * dm))
    core = (r4(dm), r4(dm), r4(dm + core_w), r4(dm + core_h))
    sh = lambda rect: tuple(r4(v + dm) for v in rect)  # core-relative -> die coordinates (shift both axes by the die margin)

    channels = []
    for ch in L["channels"]:
        rr = sh(ch["rect"])
        w_, h_ = rr[2] - rr[0], rr[3] - rr[1]
        channels.append(dict(id=ch["id"], kind=ch["kind"], llx=rr[0], lly=rr[1], urx=rr[2], ury=rr[3],
                             width_um=r4(min(w_, h_)), length_um=r4(max(w_, h_)), area_um2=r4(w_ * h_),
                             between=ch["between"], width_status="ASSUMPTION", label=LABEL))
    lg = sh(L["logic"])
    sup = macro["supply"]
    # PG table (family level) ------------------------------------------------
    pg_pins = []
    for pin in macro["supply_pins"]:
        net, basis = map_supply_pin(pin)
        if net == "VDD":
            volt = sup["vdd_v"]
        elif net == "VSS":
            volt = 0.0
        else:
            volt = None
        pg_pins.append(dict(pin=pin, net=net, net_basis=basis, voltage_v=volt))
    pg_nets = {}
    for p in pg_pins:
        pg_nets.setdefault(p["net"], []).append(p["pin"])

    bank_regions, macros_out = [], []
    n_unused_total = 0
    for b in range(cfg["banks"]):
        ox, oy = L["banks"][b]
        ox, oy = r4(ox + dm), r4(oy + dm)
        reg = dict(bank=b, name=BANK_NAMES[b], llx=ox, lly=oy, urx=r4(ox + bw), ury=r4(oy + bh), width_um=bw, height_um=bh,
                   nc=nc, nr=nr, label=LABEL, macros=[])
        for r in range(nr):
            for c in range(nc):
                x = r4(ox + c * (mw + gap))
                y = r4(oy + r * (mh + gap))
                inst = "u_bank%d_r%d_c%d" % (b, r, c)
                lo, hi = c * macro["data_width"], min((c + 1) * macro["data_width"], cfg["row_w"]) - 1
                used_cols = max(0, hi - lo + 1)
                rlo, rhi = r * macro["words"], min((r + 1) * macro["words"], cfg["depth"]) - 1
                used_rows = max(0, rhi - rlo + 1)
                used_bits = used_cols * used_rows
                total_bits = macro["data_width"] * macro["words"]
                macros_out.append(dict(
                    inst=inst, macro_name=macro["name"], bank=b, tile_row=r, tile_col=c,
                    orient="R0" if r % 2 == 0 else "MX",
                    x=x, y=y, w=mw, h=mh, area_um2=macro["area"],
                    data_bit_lo=lo, data_bit_hi=hi if used_cols else None, row_lo=rlo, row_hi=rhi if used_rows else None,
                    used_bits=used_bits, unused_bits=total_bits - used_bits,
                    pg=[[p["pin"], p["net"], p["voltage_v"]] for p in pg_pins],
                    label=LABEL))
                reg["macros"].append(inst)
                n_unused_total += total_bits - used_bits
        bank_regions.append(reg)

    # ------------------------------------------------------------------ areas
    macro_area = sum(m["area_um2"] for m in macros_out)
    macro_area_wh = sum(m["w"] * m["h"] for m in macros_out)
    region_area = sum(rect_area((r["llx"], r["lly"], r["urx"], r["ury"])) for r in bank_regions)
    chan_area = sum(c["area_um2"] for c in channels)
    logic_area_actual = rect_area(lg)
    die_area = rect_area(die)
    core_area = rect_area(core)
    inner_x0 = min(min(r["llx"] for r in bank_regions), lg[0], min(c["llx"] for c in channels))
    inner_y0 = min(min(r["lly"] for r in bank_regions), lg[1], min(c["lly"] for c in channels))
    inner_x1 = max(max(r["urx"] for r in bank_regions), lg[2], max(c["urx"] for c in channels))
    inner_y1 = max(max(r["ury"] for r in bank_regions), lg[3], max(c["ury"] for c in channels))
    inner_area = (inner_x1 - inner_x0) * (inner_y1 - inner_y0)
    pad_ring = core_area - inner_area
    margin_ring = die_area - core_area
    gaps_area = region_area - macro_area
    halo_ring_sum = sum((m["w"] + 2 * halo) * (m["h"] + 2 * halo) - m["w"] * m["h"] for m in macros_out)
    halo_union = union_area([tuple(halo_rect(m, halo)) for m in macros_out]) - union_area([(m["x"], m["y"], m["x"] + m["w"], m["y"] + m["h"]) for m in macros_out])
    partition = macro_area_wh + (region_area - macro_area_wh) + chan_area + logic_area_actual + pad_ring + margin_ring
    required_bits = cfg["banks"] * cfg["row_w"] * cfg["depth"]
    prov_bits = cfg["banks"] * til["provisioned_bits_per_bank"]
    areas = dict(
        manifest_sourced=dict(
            note="(a) taken from manifest fields physical.area_um2 / width_um / height_um (summed over instances)",
            macro_name=macro["name"], macro_area_each_um2=macro["area"], macro_width_um=mw, macro_height_um=mh,
            instances=len(macros_out), macro_area_total_um2=r4(macro_area), macro_area_total_mm2=macro_area / 1e6,
            macro_area_total_from_width_x_height_um2=r4(macro_area_wh)),
        derived=dict(
            note="(b) arithmetic on (a) and on assumption parameters (c)",
            bank_region_area_total_um2=r4(region_area), intra_bank_gap_area_um2=r4(region_area - macro_area_wh),
            channel_area_total_um2=r4(chan_area), logic_reserve_area_um2=r4(logic_area_actual),
            core_pad_ring_area_um2=r4(pad_ring), die_margin_ring_area_um2=r4(margin_ring),
            core_area_um2=r4(core_area), die_area_um2=r4(die_area), die_area_mm2=die_area / 1e6,
            partition_sum_um2=r4(partition), partition_residual_um2=r4(die_area - partition),
            halo_ring_area_sum_per_macro_um2=r4(halo_ring_sum), halo_keepout_union_outside_macros_um2=r4(halo_union),
            halo_is_additive_to_die=False,
            halo_note="halo keepout lies inside the intra-bank gaps, channels and core pad ring (gap=halo, channel>=halo, pad=halo), so it adds no die area here",
            macro_only_utilisation_of_die=macro_area / die_area, macro_only_utilisation_of_core=macro_area / core_area,
            macro_plus_gaps_utilisation_of_die=region_area / die_area,
            required_bits=required_bits, provisioned_bits=prov_bits, bit_utilisation=required_bits / prov_bits,
            macro_um2_per_required_bit=macro_area / required_bits, die_um2_per_required_bit=die_area / required_bits),
        assumptions=dict(
            note="(c) ASSUMPTION parameters - not manifest data, not measured",
            halo_um=halo, channel_um=chan, die_margin_um=dm, macro_gap_um=gap, core_pad_um=pad,
            logic_reserve_requested_um2=P["logic_area_um2"], logic_reserve_source=P["logic_area_source"], layout=lkind))

    # ------------------------------------------------------------------ flags
    flags = []
    if macro["topology"] == "1RW1R":
        port1 = [p for p in macro["port_list"] if p["name"].endswith("1")]
        n_unused_pins = sum(p["width"] for p in port1)
        flags.append(dict(
            code="READ_PORT_WASTED",
            text=("1RW1R macro used as 1RW: read-only port 1 (%s; %d signal bits per instance) is unused and tied off "
                  "(manifest pin_map.unused: %r). The silicon for that port is paid for in every one of the %d instances; "
                  "its share of the macro area is NOT quantifiable from manifest data."
                  % (", ".join("%s[%d]" % (p["name"], p["width"]) for p in port1), n_unused_pins,
                     macro["pin_map"].get("unused"), len(macros_out))),
            unused_signal_bits_per_instance=n_unused_pins, instances=len(macros_out)))
    if macro["family"].startswith("IHP"):
        tests = [p["name"] for p in macro["port_list"] if "BIST" in p["name"]]
        flags.append(dict(code="TEST_PINS_TIED", text="IHP macro carries a BIST mux port (%s); manifest tie_offs/pin_map tie them off (A_BIST_EN=0, other A_BIST_*=0, A_DLY=1) unless MBIST is wired through them." % ", ".join(tests)))
    if til["bit_utilisation"] < 0.999:
        flags.append(dict(code="UNUSED_BITS", text="%d unused data columns per row x %d rows/bank provisioned but not stored (%.2f%% bit utilisation)" % (til["unused_data_bits_per_row"], til["nr"] * macro["words"], 100 * til["bit_utilisation"])))
    if til["unused_rows"]:
        flags.append(dict(code="UNUSED_ROWS", text="%d unused rows per bank" % til["unused_rows"]))
    if len(macros_out) >= 128:
        flags.append(dict(code="MANY_INSTANCES", text="%d macro instances (%d per bank); a %d-bit row spans %d macros and the macro-only area is %.1f mm2 for %d KiB of user data: tileable by arithmetic, but a very large instance count / area for this capacity" % (len(macros_out), til["per_bank"], cfg["row_w"], nc, macro_area / 1e6, cfg["banks"] * cfg["depth"] * 128 // 8 // 1024)))
    lg_min = min(lg[2] - lg[0], lg[3] - lg[1])
    if lg_min < chan:
        flags.append(dict(code="LOGIC_RESERVE_SLIVER", text="the placeholder logic reserve is only %.1f um thick (thinner than the %g um channel) because it spans the full width of the bank block; it is a placeholder shape/area, not a plausible controller floorplan" % (lg_min, chan)))
    if macro["family"].startswith("GF180"):
        flags.append(dict(code="SMALL_MACROS_ONLY", text="largest GF180MCU macro in the manifests is 512 x 8 (512 B); docs/mem/08 states GF180 suits small control memories only"))

    # secondary pin-edge evidence from the sramgrid LEF-derived abstract (NOT used for any number)
    ab = abstracts.get(macro["name"])
    sec = None
    if ab:
        sec = dict(source="silicaflux-sramgrid-p33/physical/abstracts/%s.json" % macro["name"],
                   status="SECONDARY_DERIVED_NOT_VERIFIED (vendor LEF itself is not in the repo)",
                   data_status=ab.get("data_status"), signal_pin_edges_r0=ab.get("signal_pin_edges"),
                   symmetry=ab.get("symmetry"), abstract_size_um=[ab.get("width_um"), ab.get("height_um")],
                   power_pin_names_lef=sorted((ab.get("power_pins") or {}).keys()),
                   lef_sha256=(ab.get("provenance") or {}).get("sha256"))

    if sec:  # LEF-side PG pin names according to the secondary evidence (e.g. IHP: 'VDD!')
        for p_ in pg_pins:
            nm = next((n for n in sec["power_pin_names_lef"] if n == p_["pin"] or n.rstrip("!") == p_["pin"]), None)
            if nm:
                p_["lef_pin_name_secondary"] = nm
    # what the alternating R0/MX scheme would mean IF the secondary pin-edge evidence were right
    consequence = None
    if sec and isinstance(sec.get("signal_pin_edges_r0"), dict) and len(sec["signal_pin_edges_r0"]) == 1:
        edge = next(iter(sec["signal_pin_edges_r0"]))
        if edge in ("bottom", "top"):
            consequence = ("If the secondary evidence is right (all signal pins on the R0 %s edge): row-boundaries after an EVEN tile row are back-to-back, "
                           "boundaries after an ODD tile row are pin-to-pin facing; pins of the first/last row face the bank outline. "
                           "Pin-facing boundaries are separated only by the macro gap (%s um)." % (edge, num(gap)))
            if nr >= 3:
                flags.append(dict(code="PIN_FACING_TIGHT", text="with %d tile rows, %d boundaries are pin-to-pin (per secondary pin-edge evidence) but only %s um apart; FloorplanLab's pin-escape rule wants max(channel, halo) = %s um free in front of each pin edge"
                                  % (nr, nr // 2, num(gap), num(max(chan, halo)))))
    elif sec:
        consequence = "secondary evidence shows signal pins on several macro edges (%s): no single pin edge exists, so an R0/MX row alternation cannot make pin sides face; no conclusion drawn." % json.dumps(sec.get("signal_pin_edges_r0"))
    fp = dict(
        schema=SCHEMA, label=LABEL, disclaimer=DISCLAIMER, generator=GENERATOR,
        id="%s_%s" % (ckey, fkey), units="um",
        coordinate_system="origin = die lower-left; x right, y up; macro (x,y) = lower-left corner of the placed bbox (after orientation)",
        config=dict(key=ckey, **{k: v for k, v in cfg.items()}, required_bits_total=required_bits,
                    capacity_kib_user_data=cfg["banks"] * cfg["depth"] * 128 / 8 / 1024),
        family=dict(key=fkey, title=fam["title"], manifest_family=fam["manifest_family"], process=macro["process"],
                    foundry=macro["foundry"], port_topology_in_manifest=macro["topology"], port_use="1RW",
                    floorplanlab_platform=fam["flp_platform"], floorplanlab_status=fam["flp_status"], site_name_from_floorplanlab=fam["site"]),
        macro_shape=dict(macro_name=macro["name"], manifest_id=macro["id"], data_width=macro["data_width"], words=macro["words"],
                         width_um=mw, height_um=mh, area_um2=macro["area"], source_manifest=macro["manifest"],
                         physical_source=macro["physical_source"], physical_source_sha256=macro["physical_source_sha256"],
                         provenance_repo=macro["prov_repo"], provenance_commit=macro["prov_commit"],
                         write_mask=macro["write_mask"], supply_pin_condition=macro["supply_pin_condition"],
                         secondary_pin_evidence=sec),
        tiling=dict(
            rule="uniform tiling, as sramlib sram_asic_array: NC=ceil(ROW_W/data_width), NR=ceil(BANK_DEPTH/words); min total macro area wins (tie: fewer instances, then name)",
            nc=nc, nr=nr, instances_per_bank=til["per_bank"], instances_total=til["total"],
            provisioned_bits_per_bank=til["provisioned_bits_per_bank"], required_bits_per_bank=til["required_bits_per_bank"],
            unused_data_bits_per_row=til["unused_data_bits_per_row"], unused_rows_per_bank=til["unused_rows"],
            bit_utilisation=til["bit_utilisation"], arithmetic=arithmetic_lines(cfg, macro, til, gap, bw, bh),
            candidates=[{k: v for k, v in c.items()} for c in cands], heterogeneous_alternative_not_floorplanned=hetero),
        parameters=dict(
            halo_um=dict(value=halo, status="ASSUMPTION", basis="FloorplanLab configs/silicaflux_v/floorplan_base.yaml macros.halo_um (its own exploration value); not derived from any macro or PDK rule"),
            channel_um=dict(value=chan, status="ASSUMPTION", basis="FloorplanLab floorplan_base.yaml macros.channel_um (exploration value)", derivation_note=CHANNEL_NOTE),
            die_margin_um=dict(value=dm, status="ASSUMPTION", basis="FloorplanLab floorplan_base.yaml floorplan.core_margin_um (PDN ring + pin keep-out; no pad ring)"),
            macro_gap_um=dict(value=gap, status="ASSUMPTION (derived default = halo)", basis="smallest spacing satisfying 'halo must not overlap another macro body' (checker rule)"),
            core_pad_um=dict(value=pad, status="ASSUMPTION (derived default = halo)", basis="keeps every macro halo inside the core"),
            logic_reserve_area_um2=dict(value=P["logic_area_um2"], status="PLACEHOLDER ASSUMPTION", basis=P["logic_area_source"],
                                        note="NOT a synthesis result and NOT derived from a gate count; hook: --logic-area-json / --logic-area-um2"),
            layout=dict(value=lkind, status="DERIVED choice among %s by die aspect ratio closest to 1" % LAYOUT_ORDER, options=layout_info, description=L["desc"])),
        orientation_policy=dict(
            rule="tile_row even -> R0, odd -> MX (alternating by row; macros keep their bbox size)",
            status="ASSUMPTION",
            text=("Alternating R0/MX mirrors vertically adjacent macros about their shared horizontal edge, so the two macros present the same kind of edge "
                  "(pin edge or back edge) to each other. Which edge carries the pins is NOT known from the manifests and the vendor LEF is not in the repo; "
                  "this orientation scheme is therefore an assumption, not a pin-aware plan."),
            secondary_pin_evidence=sec, consequence_if_secondary_evidence_holds=consequence),
        die=dict(llx=die[0], lly=die[1], urx=die[2], ury=die[3], width_um=r4(die[2]), height_um=r4(die[3]), area_um2=r4(die_area), area_mm2=die_area / 1e6, label=LABEL),
        core=dict(llx=core[0], lly=core[1], urx=core[2], ury=core[3], width_um=r4(core_w), height_um=r4(core_h), area_um2=r4(core_area), label=LABEL),
        bank_regions=bank_regions,
        macros=macros_out,
        halo=dict(value_um=halo, status="ASSUMPTION", rule="macro bbox inflated by halo_um on all sides = std-cell keepout; must not overlap any other macro body (halo-on-halo overlap is allowed)",
                  ring_area_sum_um2=r4(halo_ring_sum), keepout_union_outside_macros_um2=r4(halo_union)),
        channels=channels,
        logic_reserve=dict(llx=lg[0], lly=lg[1], urx=lg[2], ury=lg[3], width_um=r4(lg[2] - lg[0]), height_um=r4(lg[3] - lg[1]),
                           area_um2=r4(logic_area_actual), requested_area_um2=P["logic_area_um2"], status="PLACEHOLDER ASSUMPTION",
                           source=P["logic_area_source"], label=LABEL,
                           hook="area can be supplied via --logic-area-json {\"area_um2\":N,\"source\":\"...\"} (e.g. produced from a yosys stat report of the RTL project); none is used here"),
        pg=dict(
            policy="supply pin names are copied from manifest supply_pins; pin->net mapping is by NAME PATTERN (assumption: no LEF); voltage derived from manifest corner label only",
            per_macro_row_format=["macro_supply_pin", "net", "voltage_v"],
            per_macro_location="macros[].pg (one row per manifest supply pin, identical for every instance of the macro)",
            supply_voltage=sup, pins=pg_pins, nets=pg_nets,
            notes=pg_notes(macro, sup, pg_pins, sec)),
        flags=flags,
        areas=areas,
    )
    return fp


CHANNEL_NOTE = ("Channel width would be derived as W = N_sig * pitch / L_layers (N_sig = signals crossing the channel, pitch = routing track pitch of the layers used, "
                "L_layers = number of same-direction signal layers), times a congestion margin. Track pitch comes from the technology LEF (not in this repo); "
                "signal counts come from the bank interface (see area_report.md, 'channel width derivation'). The default here is NOT derived.")


def pg_notes(macro, sup, pg_pins, sec=None):
    notes = []
    diff = [(p["pin"], p["lef_pin_name_secondary"]) for p in pg_pins if p.get("lef_pin_name_secondary") not in (None, p["pin"])]
    if diff:
        notes.append("manifest supply_pins list Verilog pin names, but the secondary LEF-derived evidence names the LEF PG pins differently: %s (manifest -> LEF). "
                     "The Tcl add_global_connection patterns use the LEF-side names; verify against the real LEF." % ", ".join("%s -> %s" % d for d in diff))
    if any(p["net"] == "VDDARRAY" for p in pg_pins):
        notes.append("VDDARRAY is a separate array-supply pin in the manifest; kept as its own net here. FloorplanLab's ihp_sg13g2 profile instead ties VDDARRAY!->VDD "
                     "(single 1.2 V domain assumption recorded there). Whether tying is allowed is a vendor datasheet question; not answerable from the manifest.")
    if macro.get("supply_pin_condition"):
        notes.append("manifest supply_pin_condition: %s" % macro["supply_pin_condition"])
    if sup["vdd_v"] is None:
        notes.append("no supply voltage stated in the manifest")
    else:
        notes.append("VDD = %.2f V is a corner label taken from the manifest (%s); it is not a verified supply rating or operating range" % (sup["vdd_v"], sup["status"]))
    if macro["family"].startswith("GF180"):
        notes.append("GF180MCU Liberty files in the manifest cover 1.8 / 3.3 / 5.0 V typical corners; 3.3 V is the corner of the timing numbers the manifest extracted")
    return notes


def arithmetic_lines(cfg, macro, til, gap, bw, bh):
    L = []
    L.append("NC = ceil(ROW_W / data_width) = ceil(%d / %d) = %d" % (cfg["row_w"], macro["data_width"], til["nc"]))
    L.append("NR = ceil(BANK_DEPTH / words) = ceil(%d / %d) = %d" % (cfg["depth"], macro["words"], til["nr"]))
    L.append("instances per bank = NC x NR = %d x %d = %d ; total = %d banks x %d = %d" % (til["nc"], til["nr"], til["per_bank"], cfg["banks"], til["per_bank"], til["total"]))
    L.append("macro area = %d x %s um2 (manifest physical.area_um2 of %s) = %s um2 = %.4f mm2" % (til["total"], fmt(macro["area"], 2), macro["name"], fmt(til["area_total_um2"], 2), til["area_total_um2"] / 1e6))
    L.append("bits provisioned per bank = (NC x data_width) x (NR x words) = (%d x %d) x (%d x %d) = %s ; required = ROW_W x BANK_DEPTH = %d x %d = %s"
             % (til["nc"], macro["data_width"], til["nr"], macro["words"], fmt(til["provisioned_bits_per_bank"], 0), cfg["row_w"], cfg["depth"], fmt(til["required_bits_per_bank"], 0)))
    L.append("unused per bank = %s bits (%d unused data bits per row x %d provisioned rows; %d unused rows) ; bit utilisation = %s / %s = %.2f %%"
             % (fmt(til["unused_bits_per_bank"], 0), til["unused_data_bits_per_row"], til["nr"] * macro["words"], til["unused_rows"],
                fmt(til["required_bits_per_bank"], 0), fmt(til["provisioned_bits_per_bank"], 0), 100 * til["bit_utilisation"]))
    L.append("bank grid width = NC x w + (NC-1) x gap = %d x %s + %d x %s = %s um ; height = NR x h + (NR-1) x gap = %d x %s + %d x %s = %s um (gap = ASSUMPTION)"
             % (til["nc"], macro["w"], til["nc"] - 1, gap, fmt(bw, 2), til["nr"], macro["h"], til["nr"] - 1, gap, fmt(bh, 2)))
    return L


# ----------------------------------------------------------------------------
# SVG
# ----------------------------------------------------------------------------
def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def make_svg(fp):
    die, core = fp["die"], fp["core"]
    Wpx, Hmax = 1500.0, 900.0
    left, top_hdr, bottom_ftr = 40.0, 120.0, 150.0
    s = min((Wpx - 2 * left) / die["width_um"], Hmax / die["height_um"])
    pw, ph = die["width_um"] * s, die["height_um"] * s
    total_w, total_h = Wpx, top_hdr + ph + bottom_ftr
    X = lambda x: left + x * s
    Y = lambda y, h=0.0: top_hdr + (die["height_um"] - y - h) * s
    o = []
    A = o.append
    A('<?xml version="1.0" encoding="UTF-8"?>')
    A('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" font-family="Helvetica, Arial, sans-serif">'
      % (total_w, total_h, total_w, total_h))
    A('<title>%s - %s</title>' % (esc(DISCLAIMER), esc(fp["id"])))
    A('<desc>To-scale geometry plot generated from manifest dimensions (%s). Not a conceptual diagram. Halo, channel, margin and logic reserve are assumptions.</desc>' % esc(fp["macro_shape"]["macro_name"]))
    A('<style>.t{fill:#111}.w{fill:#b00020;font-weight:bold}.m0{fill:#9ecae1;stroke:#08519c;stroke-width:0.5}.m1{fill:#c7e9c0;stroke:#006d2c;stroke-width:0.5}'
      '.h{fill:none;stroke:#e6550d;stroke-width:0.4;stroke-dasharray:3 2;opacity:.8}.c{fill:#fdd0a2;stroke:#a63603;stroke-width:0.6;fill-opacity:.75}'
      '.l{fill:#d9d9d9;stroke:#525252;stroke-width:1;stroke-dasharray:6 3}.r{fill:none;stroke:#6a3d9a;stroke-width:1.4;stroke-dasharray:8 4}'
      '.d{fill:#fff;stroke:#000;stroke-width:1.5}.k{fill:none;stroke:#555;stroke-width:0.8;stroke-dasharray:2 2}</style>')
    A('<rect x="0" y="0" width="%d" height="%d" fill="#ffffff"/>' % (total_w, total_h))
    # header
    A('<text class="w" x="%g" y="30" font-size="20">%s</text>' % (left, esc(DISCLAIMER)))
    til = fp["tiling"]
    A('<text class="t" x="%g" y="54" font-size="14">%s | %s | %s</text>'
      % (left, esc(fp["id"]), esc(fp["config"]["desc"]), esc(fp["family"]["title"])))
    A('<text class="t" x="%g" y="74" font-size="12">per bank %d x %d (NC x NR) of %s (%s x %s um) = %d instances/bank, %d total; bit utilisation %.2f %%</text>'
      % (left, til["nc"], til["nr"], esc(fp["macro_shape"]["macro_name"]), fmt(fp["macro_shape"]["width_um"], 2), fmt(fp["macro_shape"]["height_um"], 2),
         til["instances_per_bank"], til["instances_total"], 100 * til["bit_utilisation"]))
    A('<text class="t" x="%g" y="92" font-size="12">die %s x %s um = %.3f mm2 | macro-only area %.3f mm2 (%.1f %% of die) | layout %s</text>'
      % (left, fmt(die["width_um"], 2), fmt(die["height_um"], 2), die["area_mm2"], fp["areas"]["manifest_sourced"]["macro_area_total_mm2"],
         100 * fp["areas"]["derived"]["macro_only_utilisation_of_die"], esc(fp["parameters"]["layout"]["value"])))
    A('<text class="t" x="%g" y="110" font-size="12">ASSUMPTIONS: halo %g um, channel %g um, die margin %g um, macro gap %g um, logic reserve %s um2 (placeholder) | orientation R0/MX alternating by tile row (assumed; pin geometry unknown)</text>'
      % (left, fp["parameters"]["halo_um"]["value"], fp["parameters"]["channel_um"]["value"], fp["parameters"]["die_margin_um"]["value"],
         fp["parameters"]["macro_gap_um"]["value"], fmt(fp["parameters"]["logic_reserve_area_um2"]["value"], 0)))
    # die & core
    A('<rect class="d" x="%.2f" y="%.2f" width="%.2f" height="%.2f"/>' % (X(0), Y(0, die["height_um"]), pw, ph))
    A('<rect class="k" x="%.2f" y="%.2f" width="%.2f" height="%.2f"/>' % (X(core["llx"]), Y(core["lly"], core["height_um"]), core["width_um"] * s, core["height_um"] * s))
    # channels
    for c in fp["channels"]:
        A('<rect class="c" x="%.2f" y="%.2f" width="%.2f" height="%.2f"><title>%s %s width %s um</title></rect>'
          % (X(c["llx"]), Y(c["lly"], c["ury"] - c["lly"]), (c["urx"] - c["llx"]) * s, (c["ury"] - c["lly"]) * s, esc(c["id"]), esc(c["kind"]), c["width_um"]))
    # logic
    lg = fp["logic_reserve"]
    A('<rect class="l" x="%.2f" y="%.2f" width="%.2f" height="%.2f"><title>logic reserve (PLACEHOLDER area %s um2)</title></rect>'
      % (X(lg["llx"]), Y(lg["lly"], lg["height_um"]), lg["width_um"] * s, lg["height_um"] * s, fmt(lg["area_um2"], 0)))
    lw_px, lh_px = lg["width_um"] * s, lg["height_um"] * s
    lab = "CONTROLLER / LOGIC RESERVE (placeholder %s um2, %.0f x %.0f um)" % (fmt(lg["area_um2"], 0), lg["width_um"], lg["height_um"])
    cx, cy = X(lg["llx"]) + lw_px / 2, Y(lg["lly"], lg["height_um"]) + lh_px / 2
    if lw_px >= lh_px:
        A('<text class="t" x="%.1f" y="%.1f" font-size="11" text-anchor="middle" dominant-baseline="middle">%s</text>' % (cx, cy, esc(lab)))
    else:
        A('<text class="t" x="%.1f" y="%.1f" font-size="11" text-anchor="middle" dominant-baseline="middle" transform="rotate(-90 %.1f %.1f)">%s</text>' % (cx, cy, cx, cy, esc(lab)))
    # halos then macros
    A('<g id="halos">')
    for m in fp["macros"]:
        hx0, hy0, hx1, hy1 = halo_rect(m, fp["halo"]["value_um"])
        A('<rect class="h" x="%.2f" y="%.2f" width="%.2f" height="%.2f"/>' % (X(hx0), Y(hy0, hy1 - hy0), (hx1 - hx0) * s, (hy1 - hy0) * s))
    A('</g>')
    A('<g id="macros">')
    small = len(fp["macros"]) <= 40
    for m in fp["macros"]:
        cls = "m0" if m["orient"] == "R0" else "m1"
        A('<rect class="%s" x="%.2f" y="%.2f" width="%.2f" height="%.2f"><title>%s %s (%s) @ (%s, %s)</title></rect>'
          % (cls, X(m["x"]), Y(m["y"], m["h"]), m["w"] * s, m["h"] * s, esc(m["inst"]), esc(m["macro_name"]), m["orient"], m["x"], m["y"]))
        if small and m["w"] * s > 60:
            A('<text class="t" x="%.1f" y="%.1f" font-size="9" text-anchor="middle" dominant-baseline="middle">%s %s</text>'
              % (X(m["x"]) + m["w"] * s / 2, Y(m["y"], m["h"]) + m["h"] * s / 2, esc(m["inst"][2:]), m["orient"]))
    A('</g>')
    # bank regions + labels
    for r in fp["bank_regions"]:
        A('<rect class="r" x="%.2f" y="%.2f" width="%.2f" height="%.2f"/>' % (X(r["llx"]), Y(r["lly"], r["height_um"]), r["width_um"] * s, r["height_um"] * s))
        A('<text x="%.1f" y="%.1f" font-size="%d" font-weight="bold" fill="#6a3d9a" fill-opacity="0.85" text-anchor="middle">BANK %d (%dx%d)</text>'
          % (X(r["llx"]) + r["width_um"] * s / 2, Y(r["lly"], r["height_um"]) - 4, 13, r["bank"], r["nc"], r["nr"]))
    # scale bar
    for L in (100, 200, 500, 1000, 2000, 5000, 10000):
        if 80 <= L * s <= 320:
            break
    yb = top_hdr + ph + 28
    A('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="#000" stroke-width="2"/>' % (left, yb, left + L * s, yb))
    A('<text class="t" x="%g" y="%g" font-size="12">%s um (scale; %.4f px/um)</text>' % (left + L * s + 8, yb + 4, fmt(L, 0), s))
    # legend
    lx, ly = left, yb + 24
    items = [("m0", "macro, orient R0"), ("m1", "macro, orient MX"), ("h", "halo keepout (ASSUMPTION)"), ("c", "routing channel (ASSUMPTION width)"),
             ("l", "logic reserve (PLACEHOLDER)"), ("r", "bank placement region")]
    for cls, text in items:
        A('<rect class="%s" x="%g" y="%g" width="22" height="12"/>' % (cls, lx, ly))
        A('<text class="t" x="%g" y="%g" font-size="11">%s</text>' % (lx + 28, ly + 10, esc(text)))
        lx += 28 + 7 * len(text) + 24
    A('<text class="t" x="%g" y="%g" font-size="11">To-scale geometry plot generated from the JSON next to it (%s); macro internals and pins are not drawn. This is NOT a conceptual block diagram, NOT a routed or signed-off layout; no DRC/LVS/timing/power.</text>'
      % (left, ly + 36, esc(fp["id"])))
    A('<text class="t" x="%g" y="%g" font-size="11">%s</text>' % (left, ly + 52, esc(DISCLAIMER)))
    A('</svg>')
    return "\n".join(o) + "\n"


# ----------------------------------------------------------------------------
# OpenROAD Tcl (UNEXECUTED)
# ----------------------------------------------------------------------------
def lefnote(p):
    n = p.get("lef_pin_name_secondary")
    return "" if n in (None, p["pin"]) else " (LEF-side name %s per secondary evidence; verify)" % n


def make_tcl(fp, fam):
    d, c = fp["die"], fp["core"]
    gp = fp["parameters"]
    L = []
    A = L.append
    A("# " + "=" * 77)
    A("# !!! UNEXECUTED SCRIPT !!!  OpenROAD is NOT installed in the environment that generated")
    A("# this file; it has NEVER been run, parsed by OpenROAD or checked against a tech/macro LEF.")
    A("# Treat it as a transcription of %s.json, not as a verified flow step." % ("floorplan_" + fp["id"]))
    A("# " + DISCLAIMER)
    A("# Generated by %s (deterministic). Config %s: %s" % (GENERATOR, fp["config"]["key"], fp["config"]["desc"]))
    A("# Family %s ; macro %s (%s x %s um, manifest %s)" % (fp["family"]["title"], fp["macro_shape"]["macro_name"], fp["macro_shape"]["width_um"], fp["macro_shape"]["height_um"], fp["macro_shape"]["source_manifest"]))
    A("# ASSUMPTIONS baked in: halo %g um, channel %g um (channels are free space, not commands), die margin %g um, macro gap %g um," % (gp["halo_um"]["value"], gp["channel_um"]["value"], gp["die_margin_um"]["value"], gp["macro_gap_um"]["value"]))
    A("#   logic reserve %s um2 PLACEHOLDER (documented only; not enforced by any command below)," % fmt(gp["logic_reserve_area_um2"]["value"], 0))
    A("#   orientation R0/MX alternating by tile row (pin geometry unknown: vendor LEF not in the repo).")
    A("# Commands used: initialize_floorplan, cut_rows, add_global_connection, global_connect (OpenROAD) and the OpenDB Tcl API")
    A("#   (ord::get_db_block, findInst, setOrient, setLocation, setPlacementStatus) -- the same OpenDB pattern FloorplanLab's")
    A("#   scripts/orfs_hooks/macro_placement_lib.tcl uses. `place_macro` is deliberately NOT used: FloorplanLab's docs/ORFS_INTEGRATION.md")
    A("#   records it as unavailable in its pinned OpenROAD build.")
    A("# Option names of cut_rows (-halo_width_x/-halo_width_y) follow the OpenROAD ifp documentation; confirm with `help cut_rows`.")
    A("# Before sourcing: read_lef (tech LEF, std-cell LEF, macro LEF), read_liberty, read_verilog <netlist>, link_design <top>.")
    A("#   Macro LEF/Liberty/GDS are listed in the manifest `views` (upstream paths) but are NOT in this repository.")
    A("# " + "=" * 77)
    A("")
    A('puts "WARNING: %s was generated but never executed by its author (no OpenROAD available there)"   ;# runtime reminder' % ("floorplan_" + fp["id"] + ".tcl"))
    A('set FLP_ID   "%s"                          ;# floorplan identifier used in messages' % fp["id"])
    A('set FLP_SITE "%s"                          ;# placement site name from FloorplanLab platforms/%s/profile.yaml (place_site); verify against the tech LEF' % (fam["site"], fam["flp_platform"]))
    A("set FLP_HALO %g                              ;# ASSUMPTION macro halo in um" % gp["halo_um"]["value"])
    A("set FLP_DIE  {%s %s %s %s}                   ;# die bbox llx lly urx ury (um)" % tuple(num(v) for v in (d["llx"], d["lly"], d["urx"], d["ury"])))
    A("set FLP_CORE {%s %s %s %s}                   ;# core bbox llx lly urx ury (um)" % tuple(num(v) for v in (c["llx"], c["lly"], c["urx"], c["ury"])))
    A("")
    A("set block [ord::get_db_block]                ;# current OpenDB block (needs a linked design)")
    A('if {$block eq "NULL" || $block eq ""} { error "no design loaded: read_lef/read_liberty/read_verilog/link_design first" }   ;# fail early')
    A("set dbu [$block getDefUnits]                 ;# database units per micron (same call FloorplanLab uses)")
    A("")
    A("initialize_floorplan -die_area $FLP_DIE -core_area $FLP_CORE -site $FLP_SITE   ;# create die, core and site rows")
    A("")
    A("proc flp_place {block dbu name master x y orient} {                          ;# place one macro and lock it")
    A("  set inst [$block findInst $name]                                           ;# look the instance up by name")
    A('  if {$inst eq "NULL"} { error "macro instance $name not found (map floorplan names to netlist names first)" }   ;# fail loudly')
    A("  set m [[$inst getMaster] getName]                                          ;# its master (LEF macro) name")
    A('  if {$m ne $master} { error "$name is $m, floorplan expects $master" }      ;# master must match the manifest macro')
    A("  $inst setOrient $orient                                                    ;# R0 or MX")
    A("  $inst setLocation [expr {round($x * $dbu)}] [expr {round($y * $dbu)}]      ;# lower-left of the placed bbox, in DBU")
    A("  $inst setPlacementStatus FIRM                                              ;# fixed; later steps must not move it")
    A("}   ;# end of proc flp_place")
    A("")
    for m in fp["macros"]:
        A("flp_place $block $dbu %s %s %s %s %s    ;# bank%d row%d col%d" % (m["inst"], m["macro_name"], num(m["x"]), num(m["y"]), m["orient"], m["bank"], m["tile_row"], m["tile_col"]))
    A("")
    A("cut_rows -halo_width_x $FLP_HALO -halo_width_y $FLP_HALO    ;# keep std-cell rows out of the macro halos (ASSUMPTION halo)")
    A("")
    A("# Power/ground connectivity from the manifest supply_pins (pin -> net by NAME PATTERN, an assumption; voltage notes in the JSON):")
    for p in fp["pg"]["pins"]:
        if p["net"] in ("VDD", "VDDIO", "VDDARRAY"):
            A("add_global_connection -net %s -pin_pattern {^%s$} -power     ;# macro pin %s%s -> net %s" % (p["net"], p.get("lef_pin_name_secondary", p["pin"]), p["pin"], lefnote(p), p["net"]))
        elif p["net"] == "VSS":
            A("add_global_connection -net %s -pin_pattern {^%s$} -ground    ;# macro pin %s%s -> net %s" % (p["net"], p.get("lef_pin_name_secondary", p["pin"]), p["pin"], lefnote(p), p["net"]))
    A("global_connect                                              ;# apply the global connections")
    A("")
    lg = fp["logic_reserve"]
    A("# Documented only (no command): controller/logic reserve rectangle %s %s %s %s (um), area %s um2 PLACEHOLDER; routing channels:" % (num(lg["llx"]), num(lg["lly"]), num(lg["urx"]), num(lg["ury"]), fmt(lg["area_um2"], 0)))
    for ch in fp["channels"]:
        A("#   channel %-18s %-10s %s %s %s %s  (width %s um, ASSUMPTION)" % (ch["id"], ch["kind"], num(ch["llx"]), num(ch["lly"]), num(ch["urx"]), num(ch["ury"]), num(ch["width_um"])))
    A('puts "floorplan %s applied (%d macros); NOT validated by DRC, LVS, timing or power"   ;# end marker' % (fp["id"], len(fp["macros"])))
    return "\n".join(L) + "\n"


# ----------------------------------------------------------------------------
# FloorplanLab (its own schema)
# ----------------------------------------------------------------------------
def make_flp_run(fp, fam):
    d, c = fp["die"], fp["core"]
    gp = fp["parameters"]
    L = []
    L.append("# FloorplanLab RunSpec (python/floorplanlab/config.py: RunSpec / FloorplanSpec MODE A / MacroSpec manual positions).")
    L.append("# " + DISCLAIMER)
    L.append("# Generated by %s from floorplan_%s.json. Geometry only: halo/channel are ASSUMPTIONS; the design `silicaflux_memorycore`" % (GENERATOR, fp["id"]))
    L.append("# is NOT available in FloorplanLab (no memory RTL vendored there), so the full ORFS flow cannot run on this file.")
    L.append("id: MC_%s" % fp["id"])
    L.append('description: "SilicaFlux MemoryCore %s on %s: %s (generated geometry, not a flow result)"' % (fp["config"]["key"], fam["title"], fp["config"]["desc"]))
    L.append("design: silicaflux_memorycore")
    L.append("platform: %s" % fam["flp_platform"])
    L.append("seed: 1")
    L.append("floorplan:")
    L.append("  mode: A")
    L.append("  die_area: [%s, %s, %s, %s]" % tuple(num(v) for v in (d["llx"], d["lly"], d["urx"], d["ury"])))
    L.append("  core_area: [%s, %s, %s, %s]" % tuple(num(v) for v in (c["llx"], c["lly"], c["urx"], c["ury"])))
    L.append("macros:")
    L.append("  mode: physical")
    L.append("  placement: manual")
    L.append("  halo_um: %g" % gp["halo_um"]["value"])
    L.append("  channel_um: %g" % gp["channel_um"]["value"])
    L.append("  positions:")
    for m in fp["macros"]:
        L.append("    %s: [%s, %s, %s]" % (m["inst"], num(m["x"]), num(m["y"]), m["orient"]))
    L.append("tags: [memorycore, generated-geometry]")
    return "\n".join(L) + "\n"


FLP_DESIGN_YAML = """# SilicaFlux MemoryCore -- NOT AVAILABLE as a FloorplanLab design.
# Follows the convention of FloorplanLab configs/mcu_i/design.yaml: a design without a vendored
# RTL implementation is declared `status: not_available` and refused (never substituted).
# FloorplanLab vendors only SilicaFlux-V + DataFabric RTL (third_party/); the MemoryCore RTL is not there,
# there is no SDC template and no per-platform expected macro inventory.
# The RunSpec files in ../../runs/ carry the generated macro geometry in FloorplanLab's own schema so its
# geometry checks (GATE 5/6 functions) can be exercised offline; the ORFS flow cannot run on them.
# To enable: vendor the RTL, fill a design.yaml like configs/silicaflux_v/design.yaml (file list, top,
# SDC, expected_macros per platform, macro_groups regexes, io_plan), and add the macro LEF/Liberty to the
# platform profile (the ihp_sg13g2 profile only lists RM_IHPSG13_1P_{256,512,1024,2048}x64; the sky130hd
# profile only lists sky130_sram_1rw1r_128x256_8; gf180mcu is disabled).
name: silicaflux_memorycore
status: not_available
reason: "MemoryCore RTL is not vendored into FloorplanLab; geometry-only RunSpecs provided"
"""


# ----------------------------------------------------------------------------
# reports
# ----------------------------------------------------------------------------
def channel_signal_counts(cfg, macro, til):
    """Upper-bound functional signal count of one bank interface (architecture + manifest mask pins)."""
    addr = max(1, (cfg["depth"] - 1).bit_length())
    wm = (macro["write_mask"] or {}).get("mask_bits")
    mask_total = (wm or 0) * til["nc"]
    n = 2 * cfg["row_w"] + addr + 2 + mask_total
    return dict(din=cfg["row_w"], dout=cfg["row_w"], addr=addr, ce_we=2, mask_pins_all_columns=mask_total, total=n,
                note="din + dout + addr + ce + we + (mask_bits x NC mask pins, counted as routed; could be tied off locally). Clock excluded.")


# pitches quoted from FloorplanLab docs/TECHNOLOGY_PROFILES.md (IHP only); the tech LEF itself is not in this repo
IHP_PITCHES = dict(vertical_layers={"Metal3": 0.48, "Metal5": 0.48}, horizontal_layers={"Metal2": 0.42, "Metal4": 0.42})


def build_area_report(fps, excl, validation, cross, P):
    rows = []
    for fp in fps:
        a = fp["areas"]
        rows.append(dict(id=fp["id"], config=fp["config"]["key"], family=fp["family"]["key"], macro=fp["macro_shape"]["macro_name"],
                         nc=fp["tiling"]["nc"], nr=fp["tiling"]["nr"], per_bank=fp["tiling"]["instances_per_bank"], total=fp["tiling"]["instances_total"],
                         macro_area_mm2=a["manifest_sourced"]["macro_area_total_mm2"], die_w_um=fp["die"]["width_um"], die_h_um=fp["die"]["height_um"],
                         die_mm2=a["derived"]["die_area_mm2"], macro_util_die=a["derived"]["macro_only_utilisation_of_die"],
                         bit_util=fp["tiling"]["bit_utilisation"], layout=fp["parameters"]["layout"]["value"],
                         flags=[f["code"] for f in fp["flags"]]))
    return dict(label=LABEL, disclaimer=DISCLAIMER, schema="silicaflux-memorycore-physical/area-report/1",
                legend=dict(a="numbers taken from manifest fields", b="derived arithmetic", c="assumption parameters (not data, not measured)"),
                parameters=P, summary=rows, floorplans={fp["id"]: fp["areas"] for fp in fps},
                excluded_manifests=excl,
                manifest_validation=dict(checked=len(validation), failed=[v for v in validation if not v["ok"]]),
                crosscheck_vs_sramgrid_abstracts=cross["summary"] if cross else None)


def md_area_report(fps, rep, cfg_cands, P, cross, excl):
    L = []
    A = L.append
    A("# Area accounting - SilicaFlux MemoryCore SRAM physical planning")
    A("")
    A("> **" + DISCLAIMER + "**")
    A("> Geometry-level planning only: no routing, pin geometry, timing, power, IR, DRC or LVS. Generated by `scripts/gen_physical.py`; machine-readable twin: `area_report.json`.")
    A("")
    A("Legend used in every table below: **(a)** number taken from a manifest field, **(b)** derived arithmetic on (a) and (c), **(c)** ASSUMPTION parameter (not data, not measured).")
    A("")
    A("## 0. Assumption parameters (c) - identical for every floorplan")
    A("")
    A("| parameter | value | status | basis |")
    A("|---|---|---|---|")
    A("| halo | %g um | ASSUMPTION | FloorplanLab `floorplan_base.yaml macros.halo_um` (its exploration value); no PDK rule in repo |" % P["halo_um"])
    A("| routing channel width (bank-bank and bank-logic) | %g um | ASSUMPTION | FloorplanLab `macros.channel_um`; NOT derived - see section 5 |" % P["channel_um"])
    A("| die margin (core edge to die edge) | %g um | ASSUMPTION | FloorplanLab `core_margin_um` (PDN ring + pin keep-out, no pad ring) |" % P["die_margin_um"])
    A("| macro-to-macro gap inside a bank | %g um | ASSUMPTION (default = halo) | smallest spacing that satisfies 'halo must not overlap another macro body' |" % P["macro_gap_um"])
    A("| core pad (core edge to bank/logic block) | %g um | ASSUMPTION (default = halo) | keeps every macro halo inside the core |" % P["core_pad_um"])
    A("| controller / logic reserve | %s um2 | **PLACEHOLDER** | %s. Not a synthesis result; no gate count used |" % (fmt(P["logic_area_um2"], 0), P["logic_area_source"]))
    A("| layout | auto | DERIVED choice | among 2x2-with-central-band / row / column by die aspect ratio closest to 1 |")
    A("")
    A("## 1. Summary (all floorplans)")
    A("")
    A("| floorplan | macro (manifest) | NC x NR /bank | instances (bank / total) | (a) macro area mm2 | (b) die mm2 | (b) macro-only / die | (b) bit util | layout (c) | flags |")
    A("|---|---|---|---|---|---|---|---|---|---|")
    for r in rep["summary"]:
        A("| %s | `%s` | %d x %d | %d / %d | %.4f | %.3f | %.1f %% | %.2f %% | %s | %s |" % (
            r["id"], r["macro"], r["nc"], r["nr"], r["per_bank"], r["total"], r["macro_area_mm2"], r["die_mm2"], 100 * r["macro_util_die"], 100 * r["bit_util"], r["layout"], ", ".join(r["flags"]) or "-"))
    A("")
    A("Cross-check against `docs/mem/08_capacity_area_performance.md` of the SRAM library (numbers recomputed from manifests here):")
    A("")
    chk = []
    by = {fp["id"]: fp for fp in fps}

    def tot(fid):
        return by[fid]["areas"]["manifest_sourced"]["macro_area_total_mm2"]
    for fid, doc_txt, doc_val in (("C3_ihp", "IHP 512 KiB = 32 instances / 15.7 mm2 (128-bit words, 2048x64)", 15.7),
                                  ("C3_sky130", "SKY130 512 KiB = 256 instances / 72.8 mm2", 72.8),
                                  ("C3_gf180", "GF180 512 KiB = 1,024 instances / 214 mm2", 214.0)):
        A("* doc: %s -> %s (256 KiB) here: %d instances, %.3f mm2; doubled to 512 KiB = %d instances, %.2f mm2 vs doc %.1f mm2 (difference %.2f mm2, doc rounds)."
          % (doc_txt, fid, by[fid]["tiling"]["instances_total"], tot(fid), 2 * by[fid]["tiling"]["instances_total"], 2 * tot(fid), doc_val, 2 * tot(fid) - doc_val))
    A("")
    A("## 2. Tiling choice and arithmetic (a/b)")
    A("")
    A("Macros are tiled **uniformly** (one macro shape per bank) because that is what the SRAM library's `sram_asic_array` does (`NC = ceil(W / macro width)`, `NR = ceil(D / macro words)`, docs/mem/02 section 4). "
      "Shape selection = minimum total macro area (tie: fewer instances). Only 1RW use is considered: IHP 2P (true 2RW) macros are excluded by rule; the SKY130 1RW1R macros are the only SKY130 macros that exist, so their unused read port is **flagged**, not avoided.")
    A("")
    for fp in fps:
        t = fp["tiling"]
        A("### %s - %s on %s" % (fp["id"], fp["config"]["desc"], fp["family"]["title"]))
        A("")
        A("Selected: `%s` (manifest `%s`, area source `%s`)." % (fp["macro_shape"]["macro_name"], fp["macro_shape"]["source_manifest"], fp["macro_shape"]["physical_source"]))
        A("")
        A("```")
        for ln in t["arithmetic"]:
            A(ln)
        A("```")
        A("")
        A("Candidates ranked by total macro area (top 4 of %d eligible 1RW macros of the family):" % len(t["candidates"]))
        A("")
        A("| rank | macro | NC x NR | instances | macro area mm2 | bit util |")
        A("|---|---|---|---|---|---|")
        for i, c in enumerate(t["candidates"][:4]):
            A("| %d | `%s` | %d x %d | %d | %.4f | %.2f %% |" % (i + 1, c["macro_name"], c["nc"], c["nr"], c["total"], c["area_total_um2"] / 1e6, 100 * c["bit_utilisation"]))
        A("")
        h = t["heterogeneous_alternative_not_floorplanned"]
        if h:
            A("*Alternative not floorplanned:* %d x `%s` columns (%d rows) + %d x `%s` columns (%d rows) = %d instances, %.4f mm2, saving %.4f mm2 (%.1f %%) vs the selected uniform tiling. %s." % (
                h["cols_a"], h["macro_a"], h["rows_a"], h["cols_b"], h["macro_b"], h["rows_b"], h["instances_total"], h["area_total_um2"] / 1e6, h["saving_um2"] / 1e6, h["saving_pct"], h["note"]))
            A("")
        for fl in fp["flags"]:
            A("* **FLAG %s**: %s" % (fl["code"], fl["text"]))
        A("")
    A("## 3. Area accounting per floorplan")
    A("")
    A("Partition identity (b): die = macros + intra-bank gaps + channels + logic reserve + core pad ring + die margin ring. The halo is a keepout *overlay* that lies inside gaps/channels/pad, so it is listed but **not additive**.")
    A("")
    A("| floorplan | (a) macro area | (b) intra-bank gaps | (b) channels | (c)->(b) logic reserve | (b) core pad ring | (b) die margin ring | (b) die area | residual | (b) halo ring sum / union outside macros |")
    A("|---|---|---|---|---|---|---|---|---|---|")
    for fp in fps:
        a, d = fp["areas"]["manifest_sourced"], fp["areas"]["derived"]
        A("| %s | %s | %s | %s | %s | %s | %s | %s | %.4f | %s / %s |" % (
            fp["id"], fmt(a["macro_area_total_um2"], 0), fmt(d["intra_bank_gap_area_um2"], 0), fmt(d["channel_area_total_um2"], 0), fmt(d["logic_reserve_area_um2"], 0),
            fmt(d["core_pad_ring_area_um2"], 0), fmt(d["die_margin_ring_area_um2"], 0), fmt(d["die_area_um2"], 0), d["partition_residual_um2"],
            fmt(d["halo_ring_area_sum_per_macro_um2"], 0), fmt(d["halo_keepout_union_outside_macros_um2"], 0)))
    A("")
    A("All areas in um2. `macro area` is the sum of the manifest `physical.area_um2` over instances (the sum of width x height differs only by manifest rounding, see `area_report.json`).")
    A("")
    A("| floorplan | die W x H um | die mm2 | core mm2 | macro-only / die | macro-only / core | bank regions / die | um2 per stored bit: macro-only | um2 per stored bit: die |")
    A("|---|---|---|---|---|---|---|---|---|")
    for fp in fps:
        d = fp["areas"]["derived"]
        A("| %s | %s x %s | %.3f | %.3f | %.1f %% | %.1f %% | %.1f %% | %.3f | %.3f |" % (
            fp["id"], fmt(fp["die"]["width_um"], 2), fmt(fp["die"]["height_um"], 2), d["die_area_um2"] / 1e6, d["core_area_um2"] / 1e6,
            100 * d["macro_only_utilisation_of_die"], 100 * d["macro_only_utilisation_of_core"], 100 * d["macro_plus_gaps_utilisation_of_die"],
            d["macro_um2_per_required_bit"], d["die_um2_per_required_bit"]))
    A("")
    A("## 4. Port topology")
    A("")
    A("* **SKY130 OpenRAM** macros in the manifests are all `1RW1R`; this architecture needs one RW port per bank, so port 1 (`clk1`, `csb1`, `addr1`, `dout1`) is unused in every instance. Instance counts: " + ", ".join("%s: %d" % (fp["id"], fp["tiling"]["instances_total"]) for fp in fps if fp["family"]["key"] == "sky130") + ". The area cost of the idle port cannot be separated from manifest data.")
    A("* **IHP SG13G2 1P** and **GF180MCU 1RW** are true single-port macros: no wasted port. IHP 1P carries a BIST mux port that is tied off unless MBIST uses it (manifest `tie_offs`, `pin_map.tied`).")
    A("")
    A("## 5. Channel width derivation (illustrative; the 40 um default is NOT derived)")
    A("")
    A("`W_channel = N_sig x pitch / L_layers x margin`. N_sig below = din + dout + addr + ce + we + all mask pins (upper bound; mask pins may be tied off locally). Pitches are only available for IHP, and only second-hand: FloorplanLab `docs/TECHNOLOGY_PROFILES.md` lists Metal3/Metal5 V 0.48 um (2 vertical signal layers for a vertical channel); the tech LEF is not in this repo. No pitch exists in the repo for SKY130 / GF180 -> not computed.")
    A("")
    A("| floorplan | N_sig per bank (b) | IHP only: N x 0.48 um / 2 layers at 100 %% track use (b, illustrative) | vs default %g um |" % P["channel_um"])
    A("|---|---|---|---|")
    for fp in fps:
        ns = fp["channel_signals"]
        if fp["family"]["key"] == "ihp":
            w = ns["total"] * 0.48 / 2
            A("| %s | %d | %.1f um | %s |" % (fp["id"], ns["total"], w, "default is smaller: needs real pin-escape analysis" if w > P["channel_um"] else "default is larger"))
        else:
            A("| %s | %d | not computable (no pitch in repo) | - |" % (fp["id"], ns["total"]))
    A("")
    A("Only a fraction of a bank's signals crosses any single channel, so this is not a width estimate - it shows the default is a placeholder that real routing data must replace.")
    A("")
    A("## 6. Manifest validation and cross-checks")
    A("")
    A("* Manifests read: %d usable + %d excluded placeholders (%s)." % (rep["manifest_validation"]["checked"], len(excl), ", ".join(e["manifest"] for e in excl)))
    A("* Per-manifest checks (area = width x height within 0.01 um2; name-encoded words/width equal `data_width`/`words`; supply pins and provenance present): **%d failed**." % len(rep["manifest_validation"]["failed"]))
    if rep["manifest_validation"]["failed"]:
        for v in rep["manifest_validation"]["failed"]:
            A("  * %s: %s" % (v["macro"], "; ".join(v["issues"])))
    if cross:
        s = cross["summary"]
        A("* Cross-check of manifest width/height vs the LEF-derived abstracts in `silicaflux-sramgrid-p33/physical/abstracts/` (a different project in this repo; secondary evidence): %d macros compared, %d dimension mismatches (> 0.005 um); the LEF sha256 recorded in each abstract equals the LEF sha256 recorded in the manifest provenance for %d of %d (the LEF files themselves are absent, so the abstract content cannot be re-verified). Details: `logs/crosscheck_manifest_vs_sramgrid_abstracts.json`." % (s["compared"], s["mismatches"], s["lef_sha256_equal"], s["compared"]))
    A("")
    A("## 7. What this report does not contain")
    A("")
    A("No wirelength, congestion, timing, power, IR drop, DRC or LVS; no std-cell area from synthesis (logic reserve is a placeholder); no pin positions; no PDN. Macro area excludes power rings/straps, redundancy and routing - it is a lower bound on silicon, as `docs/mem/08` also states.")
    return "\n".join(L) + "\n"


def md_readme(fps, rep, P, flp_summary, verif=None):
    L = []
    A = L.append
    A("# SilicaFlux MemoryCore - SRAM physical planning (geometry level)")
    A("")
    A("> **" + DISCLAIMER + "**")
    A("")
    A("## Scope")
    A("")
    A("Macro inventory, floorplan geometry, placement scripts and area accounting for the MemoryCore SRAM subsystem (4 independent single-port banks, line-interleaved, physically independent), driven **only** by the real open-PDK macro manifests of the SRAM library (`silicaflux-sramlib/manifests/*.json`). "
      "Every macro width/height/area is a manifest field (`physical.*`); halo, channels, die margin, macro gap and the controller/logic reserve are **assumptions** and are labelled as such everywhere. "
      "This is geometry-level planning. It is **not** an ASIC-ready deliverable (see `asic_readiness.md`).")
    A("")
    A("Configurations: **C1** 4 x 1024 x 128 b (64 KiB), **C2** 4 x 1024 x 137 b (SECDED stored word), **C3** 4 x 4096 x 128 b (256 KiB). Families: **SKY130** OpenRAM 1RW1R (`sky130`), **IHP SG13G2** 1P (`ihp`), **GF180MCU** 1RW (`gf180`) -> 9 floorplans. The three `commercial_*_pending.json` manifests carry no data and are never used.")
    A("")
    A("## How to run")
    A("")
    A("```")
    A("python3 -I scripts/gen_physical.py && python3 -I check_floorplan.py     # generate everything, then the independent legality checker")
    A("python3 -I check_asic_collateral.py --write-md                           # re-scan the audit tree for LEF/GDS/Liberty/SPICE; rewrites asic_readiness.md")
    A("python3 -I scripts/floorplanlab_integration.py                           # OPTIONAL: runs a reviewed COPY of FloorplanLab's own validators (executes input code; see floorplanlab/INTEGRATION.md)")
    A("```")
    A("")
    A("(`-I` is optional for our own scripts; they read the manifests as JSON data only.) Paths default to the extracted audit tree; override with `--manifests DIR` / `SILICAFLUX_MANIFESTS`.")
    A("")
    A("## Results")
    A("")
    A("| floorplan | macro | NC x NR / bank | instances | macro area mm2 (a) | die W x H um (b) | die mm2 (b) | macro-only / die (b) | bit util (b) | flags |")
    A("|---|---|---|---|---|---|---|---|---|---|")
    for r in rep["summary"]:
        A("| %s | `%s` | %d x %d | %d | %.4f | %s x %s | %.3f | %.1f %% | %.2f %% | %s |" % (r["id"], r["macro"], r["nc"], r["nr"], r["total"], r["macro_area_mm2"], fmt(r["die_w_um"], 1), fmt(r["die_h_um"], 1), r["die_mm2"], 100 * r["macro_util_die"], 100 * r["bit_util"], ", ".join(r["flags"]) or "-"))
    A("")
    A("Source of every number: `floorplan_<cfg>_<family>.json` -> `areas`, recomputed independently by `check_floorplan.py`; arithmetic shown in `area_report.md` section 2. (a) = manifest field, (b) = derived.")
    A("")
    by = {r["id"]: r for r in rep["summary"]}
    A("Notable findings: (1) for C2 (137-bit stored word) the uniform tilings waste provisioned bits in the 9 ECC columns (bit utilisation: SKY130 %.1f %%, IHP %.1f %%, GF180 %.1f %%); a two-macro tiling would save area but needs the RTL to split the stored word (computed in `area_report.md`, not floorplanned). "
      "(2) SKY130 1RW1R macros leave a read port idle in every instance (%d / %d / %d instances for C1 / C2 / C3). "
      "(3) C3 (256 KiB) macro-only area: IHP %d instances / %.2f mm2, SKY130 %d / %.2f mm2, GF180 %d / %.2f mm2 - tileable by arithmetic, but GF180 (8-bit-wide macros, 512 words max) is impractical at this capacity."
      % (100 * by["C2_sky130"]["bit_util"], 100 * by["C2_ihp"]["bit_util"], 100 * by["C2_gf180"]["bit_util"],
         by["C1_sky130"]["total"], by["C2_sky130"]["total"], by["C3_sky130"]["total"],
         by["C3_ihp"]["total"], by["C3_ihp"]["macro_area_mm2"], by["C3_sky130"]["total"], by["C3_sky130"]["macro_area_mm2"], by["C3_gf180"]["total"], by["C3_gf180"]["macro_area_mm2"]))
    A("")
    A("## How the geometry is built")
    A("")
    A("* Coordinates: um, die lower-left = (0,0), x right, y up; a macro (x, y) is the lower-left of its placed bounding box.")
    A("* Bank = NC x NR grid of one macro shape (`tile_col` across = data-bit slice, `tile_row` up = depth slice), neighbours `macro_gap` apart (= halo). Orientation R0 on even rows, MX on odd rows. Bank placement region = bounding box of its macros.")
    A("* Four identical banks; the layout (2x2 with a central controller band, 4 in a row, or 4 in a column; chosen per floorplan by die aspect ratio closest to 1) is separated by routing channels (bank-bank and bank-logic), all `channel` wide; the controller/logic reserve is one rectangle of the placeholder area adjoining the bank block; core pad = halo; die margin around the core.")
    A("* Partition identity (checked): die = macros + intra-bank gaps + channels + logic reserve + core pad ring + die margin ring. Halos are a keepout overlay inside gaps/channels/pad.")
    A("")
    if verif:
        A("## Verification as run")
        A("")
        for ln in verif:
            A(ln)
        A("")
    A("## File map")
    A("")
    A("| path | content |")
    A("|---|---|")
    A("| `scripts/gen_physical.py` | the generator (stdlib only, deterministic) |")
    A("| `macro_inventory.csv`, `macro_inventory.json` | one row per macro instance (name, macro, family/process, w/h/area, bank, tile row/col, orientation, x/y, source manifest, `physical.source` + sha256, provenance repo/commit) |")
    A("| `floorplan_<cfg>_<family>.json` (9) | die/core, bank regions, macro placements, halos, channels, logic reserve, PG table per macro, tiling arithmetic, areas, parameters with ASSUMPTION labels |")
    A("| `area_report.md`, `area_report.json` | area accounting, tiling candidates, flags, channel-width derivation note, manifest validation |")
    A("| `check_floorplan.py` | independent legality checker + negative tests (re-reads manifests; does not import the generator) |")
    A("| `openroad/floorplan_<cfg>_<family>.tcl` (9) | OpenROAD/OpenDB Tcl that reproduces the placement - **UNEXECUTED** |")
    A("| `svg/floorplan_<cfg>_<family>.svg` (9) | to-scale drawings (titled `%s`) |" % DISCLAIMER)
    A("| `dashboard_floorplan.json` | compact JSON for a web dashboard (every entry labelled `generated-geometry`) |")
    A("| `asic_readiness.md`, `check_asic_collateral.py`, `asic_collateral_check.json` | per-view ASIC collateral requirement vs what the repo contains; scan results |")
    A("| `floorplanlab/` | FloorplanLab-schema RunSpecs (`runs/`), design stub, integration log (`INTEGRATION.md`, `integration_result.json`) |")
    A("| `logs/` | checker output, determinism check, find output, manifest cross-checks |")
    A("")
    A("## FloorplanLab integration")
    A("")
    if flp_summary:
        for i, ln in enumerate(flp_summary):
            if ln.startswith("* ") and i > 0 and not flp_summary[i - 1].startswith("* "):
                A("")
            A(ln)
            if not ln.startswith("* "):
                A("")
    else:
        A("Not run in this generation pass (`floorplanlab/integration_result.json` absent). Run `scripts/floorplanlab_integration.py`, then re-run the generator.")
    A("")
    A("## Assumptions (all parameters, never measured)")
    A("")
    A("1. Halo %g um, channel width %g um, die margin %g um: borrowed from FloorplanLab's `floorplan_base.yaml` exploration values; not derived from any PDK rule or routing analysis." % (P["halo_um"], P["channel_um"], P["die_margin_um"]))
    A("2. Macro-to-macro gap = halo (%g um) and core pad = halo: the smallest values that satisfy the checker's 'halo must not overlap another macro body' and keep halos inside the core." % P["macro_gap_um"])
    A("3. Controller/logic reserve = %s um2 **placeholder** (same for every floorplan). No synthesis figure is used; hook: `--logic-area-json FILE` with `{\"area_um2\": N, \"source\": \"...\"}`." % fmt(P["logic_area_um2"], 0))
    A("4. Orientation: tile row even -> R0, odd -> MX, so vertically adjacent macros mirror about their shared edge. Pin geometry is unknown from the manifests; this is not a pin-aware plan.")
    A("5. Macro tiling is uniform (as the library's `sram_asic_array`); banks use the same shape; bank placement order and layout (2x2 / row / column) are generator choices.")
    A("6. PG: manifest `supply_pins` -> nets by name pattern (`vccd*`/`VDD` -> VDD, `vssd*`/`VSS` -> VSS, `VDDARRAY` kept as its own net). Voltages are corner labels read from manifest fields, not verified supply ratings.")
    A("7. FloorplanLab site names (`unithd`, `CoreSite`, `GF018hv5v_green_sc9`) and the IHP routing pitches in the channel note come from FloorplanLab's docs/profiles, not from any LEF in the repo.")
    A("")
    A("## KNOWN LIMITATIONS")
    A("")
    A("* **No pin geometry in the manifests**, and no LEF/GDS/Liberty/SPICE files in the repository (checked with `find`; `asic_readiness.md`). A LEF-derived JSON abstract of the macros exists in the `silicaflux-sramgrid-p33` project (pin edges, symmetry); it is used only as labelled secondary evidence and as a dimension cross-check, never to produce a number here.")
    A("* **OpenROAD was not run** (not installed): the Tcl files are unexecuted. No Tcl interpreter exists here either, so they were only structurally linted (brace/bracket/quote balance, argument counts) by `check_floorplan.py`. The `cut_rows` halo option names were not confirmed against a live `help` output.")
    A("* Halo, channel width, die margin, macro gap and the logic reserve are assumptions; die areas are therefore *planning figures*, not estimates of a taped-out area.")
    A("* **No timing, power, IR-drop, DRC, LVS, congestion or routability results** of any kind. No PDN/ring/strap area is included.")
    A("* The 4-bank 2x2 / row / column arrangement and the idea that all pins reach a central controller band are not validated by any pin-escape analysis; FloorplanLab's own pin-escape rule can flag the stacked-row spacing (see `floorplanlab/INTEGRATION.md`).")
    A("* FloorplanLab's full flow could not run here (no OpenROAD/ORFS/Yosys/PDK collateral; MemoryCore is not a FloorplanLab design) - only its pure-Python validators were exercised on a copy.")
    A("* FPGA-inferred memory (BRAM) results elsewhere in the repo say nothing about ASIC readiness.")
    return "\n".join(L) + "\n"


# ----------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--manifests", default=MANIFESTS_DEFAULT)
    ap.add_argument("--abstracts", default=ABSTRACTS_DEFAULT, help="optional LEF-derived abstracts (secondary evidence only)")
    ap.add_argument("--out", default=OUT_DEFAULT)
    ap.add_argument("--halo-um", type=float, default=20.0)
    ap.add_argument("--channel-um", type=float, default=40.0)
    ap.add_argument("--die-margin-um", type=float, default=40.0)
    ap.add_argument("--macro-gap-um", type=float, default=None)
    ap.add_argument("--core-pad-um", type=float, default=None)
    ap.add_argument("--logic-area-um2", type=float, default=250000.0)
    ap.add_argument("--logic-area-json", default=None, help='{"area_um2": N, "source": "..."} e.g. produced from a yosys stat report')
    ap.add_argument("--layout", default="auto", choices=["auto"] + LAYOUT_ORDER)
    args = ap.parse_args(argv)

    out = os.path.abspath(args.out)
    for sub in ("openroad", "svg", "logs", "floorplanlab/runs", "floorplanlab/configs/silicaflux_memorycore"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)

    logic_area, logic_src = args.logic_area_um2, "PLACEHOLDER default 250000 um2 (0.25 mm2): arbitrary, same for all floorplans; replace via --logic-area-um2 / --logic-area-json"
    if args.logic_area_json:
        with open(args.logic_area_json) as f:
            j = json.load(f)
        logic_area, logic_src = float(j["area_um2"]), "supplied via --logic-area-json: %s" % j.get("source", "(no source stated)")
    elif args.logic_area_um2 != 250000.0:
        logic_src = "user-supplied --logic-area-um2 (no provenance stated)"
    gap = args.macro_gap_um if args.macro_gap_um is not None else args.halo_um
    pad = args.core_pad_um if args.core_pad_um is not None else args.halo_um
    P = dict(halo_um=args.halo_um, channel_um=args.channel_um, die_margin_um=args.die_margin_um, macro_gap_um=gap, core_pad_um=pad,
             logic_area_um2=logic_area, logic_area_source=logic_src, layout=args.layout)

    macros, excluded, validation = load_manifests(args.manifests)
    abstracts = load_abstracts(args.abstracts)
    byfam = {}
    for m in macros:
        byfam.setdefault(m["family"], []).append(m)

    # -------- cross-check manifests vs sramgrid abstracts (secondary evidence) --------
    cross = None
    if abstracts:
        comp, mism = [], []
        for m in macros:
            ab = abstracts.get(m["name"])
            if not ab:
                continue
            dw, dh = abs(ab["width_um"] - m["w"]), abs(ab["height_um"] - m["h"])
            rec = dict(macro=m["name"], manifest_wh=[m["w"], m["h"]], abstract_wh=[ab["width_um"], ab["height_um"]],
                       dw=round(dw, 6), dh=round(dh, 6), abstract_lef_sha256=(ab.get("provenance") or {}).get("sha256"),
                       manifest_physical_source_sha256=m["physical_source_sha256"], manifest_lef_sha256=m["lef_sha256"],
                       lef_sha_equal=(m["lef_sha256"] is not None and m["lef_sha256"] == (ab.get("provenance") or {}).get("sha256")),
                       signal_pin_edges=ab.get("signal_pin_edges"))
            comp.append(rec)
            if dw > 0.005 or dh > 0.005:
                mism.append(rec)
        cross = dict(label="secondary-evidence", source=args.abstracts, summary=dict(compared=len(comp), mismatches=len(mism), lef_sha256_equal=sum(1 for r in comp if r["lef_sha_equal"]), manifests_without_abstract=sorted(m["name"] for m in macros if m["name"] not in abstracts)),
                     records=comp)
        write_json(os.path.join(out, "logs", "crosscheck_manifest_vs_sramgrid_abstracts.json"), cross)

    fps, all_cands = [], {}
    for ckey, cfg in CONFIGS.items():
        for fkey, fam in FAMILIES.items():
            ms = byfam.get(fam["manifest_family"], [])
            if not ms:
                sys.exit("no manifests for family %s" % fam["manifest_family"])
            cands = rank_candidates(cfg, ms)
            macro = next(m for m in ms if m["name"] == cands[0]["macro_name"])
            het = hetero_alternative(cfg, ms, cands[0])
            fp = build_floorplan(ckey, cfg, fkey, fam, macro, cands, het, P, abstracts)
            fp["channel_signals"] = channel_signal_counts(cfg, macro, cands[0])
            fps.append(fp)
            all_cands[fp["id"]] = cands

    # -------- write floorplans, tcl, svg, flp runs --------
    for fp in fps:
        fam = FAMILIES[fp["family"]["key"]]
        write_json(os.path.join(out, "floorplan_%s.json" % fp["id"]), fp)
        with open(os.path.join(out, "openroad", "floorplan_%s.tcl" % fp["id"]), "w") as f:
            f.write(make_tcl(fp, fam))
        with open(os.path.join(out, "svg", "floorplan_%s.svg" % fp["id"]), "w") as f:
            f.write(make_svg(fp))
        with open(os.path.join(out, "floorplanlab", "runs", "MC_%s.yaml" % fp["id"]), "w") as f:
            f.write(make_flp_run(fp, fam))
    with open(os.path.join(out, "floorplanlab", "configs", "silicaflux_memorycore", "design.yaml"), "w") as f:
        f.write(FLP_DESIGN_YAML)

    # -------- inventory --------
    cols = ["floorplan_id", "instance", "macro_name", "family", "process", "width_um", "height_um", "area_um2", "bank", "tile_row", "tile_col",
            "orient", "x_um", "y_um", "data_bit_lo", "data_bit_hi", "row_lo", "row_hi", "used_bits", "unused_bits", "port_topology_manifest",
            "source_manifest", "physical_source", "physical_source_sha256", "provenance_repo", "provenance_commit", "label"]
    rows = []
    mbyname = {m["name"]: m for m in macros}
    for fp in fps:
        m0 = mbyname[fp["macro_shape"]["macro_name"]]
        for m in fp["macros"]:
            rows.append(dict(floorplan_id=fp["id"], instance=m["inst"], macro_name=m["macro_name"], family=fp["family"]["manifest_family"], process=m0["process"],
                             width_um=m["w"], height_um=m["h"], area_um2=m["area_um2"], bank=m["bank"], tile_row=m["tile_row"], tile_col=m["tile_col"],
                             orient=m["orient"], x_um=m["x"], y_um=m["y"], data_bit_lo=m["data_bit_lo"], data_bit_hi=m["data_bit_hi"], row_lo=m["row_lo"], row_hi=m["row_hi"],
                             used_bits=m["used_bits"], unused_bits=m["unused_bits"], port_topology_manifest=m0["topology"], source_manifest=m0["manifest"],
                             physical_source=m0["physical_source"], physical_source_sha256=m0["physical_source_sha256"], provenance_repo=m0["prov_repo"],
                             provenance_commit=m0["prov_commit"], label=LABEL))
    with open(os.path.join(out, "macro_inventory.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    inst_json = [dict(floorplan_id=r["floorplan_id"], instance=r["instance"], macro_name=r["macro_name"], family=r["family"], width_um=r["width_um"],
                      height_um=r["height_um"], area_um2=r["area_um2"], bank=r["bank"], tile_row=r["tile_row"], tile_col=r["tile_col"], orient=r["orient"],
                      x_um=r["x_um"], y_um=r["y_um"], used_bits=r["used_bits"], unused_bits=r["unused_bits"], source_manifest=r["source_manifest"],
                      physical_source=r["physical_source"], label=LABEL) for r in rows]
    write_json(os.path.join(out, "macro_inventory.json"), dict(
        schema="silicaflux-memorycore-physical/macro-inventory/1", label=LABEL, disclaimer=DISCLAIMER, generator=GENERATOR,
        note="per-instance provenance fields not repeated here (repo, commit, physical_source_sha256, process, topology, bit/row ranges) are in macros_in_use[macro_name] and in macro_inventory.csv",
        instance_count=len(rows), floorplans=[fp["id"] for fp in fps],
        excluded_manifests=excluded,
        macros_in_use=[dict(macro_name=n, **{k: mbyname[n][k] for k in ("family", "process", "data_width", "words", "w", "h", "area", "topology", "manifest", "physical_source", "physical_source_sha256", "prov_repo", "prov_commit", "supply_pins")})
                       for n in sorted({fp["macro_shape"]["macro_name"] for fp in fps})],
        instances=inst_json))

    # -------- area report --------
    rep = build_area_report(fps, excluded, validation, cross, P)
    write_json(os.path.join(out, "area_report.json"), rep)
    with open(os.path.join(out, "area_report.md"), "w") as f:
        f.write(md_area_report(fps, rep, all_cands, P, cross, excluded))

    # -------- dashboard --------
    dash = dict(label=LABEL, disclaimer=DISCLAIMER, schema="silicaflux-memorycore-physical/dashboard/1", units="um", generator=GENERATOR, floorplans=[])
    for fp in fps:
        dash["floorplans"].append(dict(
            id=fp["id"], config=fp["config"]["key"], config_desc=fp["config"]["desc"], family=fp["family"]["key"], family_title=fp["family"]["title"], label=LABEL,
            macro=fp["macro_shape"]["macro_name"], tiling=dict(nc=fp["tiling"]["nc"], nr=fp["tiling"]["nr"], instances=fp["tiling"]["instances_total"], bit_utilisation=round(fp["tiling"]["bit_utilisation"], 6), label=LABEL),
            die=dict(w=fp["die"]["width_um"], h=fp["die"]["height_um"], area_mm2=round(fp["die"]["area_mm2"], 6), label=LABEL),
            core=dict(x=fp["core"]["llx"], y=fp["core"]["lly"], w=fp["core"]["width_um"], h=fp["core"]["height_um"], label=LABEL),
            bank_regions=[dict(bank=r["bank"], x=r["llx"], y=r["lly"], w=r["width_um"], h=r["height_um"], label=LABEL) for r in fp["bank_regions"]],
            macros=[dict(n=m["inst"], x=m["x"], y=m["y"], w=m["w"], h=m["h"], orient=m["orient"], bank=m["bank"], label=LABEL) for m in fp["macros"]],
            halos=[dict(of=m["inst"], x=halo_rect(m, fp["halo"]["value_um"])[0], y=halo_rect(m, fp["halo"]["value_um"])[1], w=r4(m["w"] + 2 * fp["halo"]["value_um"]), h=r4(m["h"] + 2 * fp["halo"]["value_um"]), label=LABEL) for m in fp["macros"]],
            halo_params=dict(halo_um=fp["halo"]["value_um"], status="ASSUMPTION", label=LABEL),
            channels=[dict(id=c["id"], kind=c["kind"], x=c["llx"], y=c["lly"], w=r4(c["urx"] - c["llx"]), h=r4(c["ury"] - c["lly"]), width_um=c["width_um"], status="ASSUMPTION", label=LABEL) for c in fp["channels"]],
            logic_reserve=dict(x=fp["logic_reserve"]["llx"], y=fp["logic_reserve"]["lly"], w=fp["logic_reserve"]["width_um"], h=fp["logic_reserve"]["height_um"], area_um2=fp["logic_reserve"]["area_um2"], status="PLACEHOLDER ASSUMPTION", label=LABEL),
            areas=dict(label=LABEL,
                       macro_area_um2=dict(value=fp["areas"]["manifest_sourced"]["macro_area_total_um2"], kind="manifest"),
                       halo_ring_area_um2=dict(value=fp["areas"]["derived"]["halo_ring_area_sum_per_macro_um2"], kind="derived+assumption"),
                       channel_area_um2=dict(value=fp["areas"]["derived"]["channel_area_total_um2"], kind="derived+assumption"),
                       logic_reserve_area_um2=dict(value=fp["areas"]["derived"]["logic_reserve_area_um2"], kind="assumption"),
                       die_area_um2=dict(value=fp["areas"]["derived"]["die_area_um2"], kind="derived"),
                       macro_only_utilisation_of_die=dict(value=round(fp["areas"]["derived"]["macro_only_utilisation_of_die"], 6), kind="derived")),
            flags=[dict(code=x["code"], text=x["text"], label=LABEL) for x in fp["flags"]]))
    write_json(os.path.join(out, "dashboard_floorplan.json"), dash)

    # -------- README (optionally with FloorplanLab integration summary) --------
    flp_summary = None
    jp = os.path.join(out, "floorplanlab", "integration_result.json")
    if os.path.isfile(jp):
        try:
            with open(jp) as f:
                flp_summary = json.load(f).get("readme_summary")
        except Exception:
            flp_summary = None
    verif = None
    cp = os.path.join(out, "logs", "check_floorplan_report.json")
    if os.path.isfile(cp):
        try:
            with open(cp) as f:
                cs = json.load(f)["summary"]
            verif = ["`check_floorplan.py` (independent checker) result recorded in `logs/check_floorplan_report.json`: **%d/%d floorplans PASS**, %d individual checks passed / %d failed (incl. cross-artefact checks of CSV, SVG, Tcl, FloorplanLab RunSpecs, dashboard), **%d/%d negative tests caught** (overlap, partial overlap, outside die, halo violation, region overlap, narrow channel, missing PG, wrong dimension, placeholder macro, illegal orientation, logic overlap, missing instance...). Overall: %s." % (cs["floorplans_pass"], cs["floorplans"], cs["checks_passed"], cs["checks_failed"], cs["negative_caught"], cs["negative_total"], cs["overall"]),
                     "", "Console output: `logs/check_floorplan.log`. `logs/determinism.txt` records that two consecutive generator runs produce byte-identical outputs. `logs/find_collateral.txt` is the raw `find` output behind `asic_readiness.md`. The checker validates the Tcl only structurally (no Tcl interpreter available)."]
        except Exception:
            verif = None
    with open(os.path.join(out, "README.md"), "w") as f:
        f.write(md_readme(fps, rep, P, flp_summary, verif))

    print("generated %d floorplans, %d macro instances in %s" % (len(fps), len(rows), out))
    for r in rep["summary"]:
        print("  %-10s %-34s %2dx%-2d inst %3d  macro %.4f mm2  die %.3f mm2  util %.1f%%  bitutil %.1f%%  layout %s" % (
            r["id"], r["macro"], r["nc"], r["nr"], r["total"], r["macro_area_mm2"], r["die_mm2"], 100 * r["macro_util_die"], 100 * r["bit_util"], r["layout"]))
    bad = [v for v in validation if not v["ok"]]
    print("manifest validation: %d checked, %d failed; excluded placeholders: %d" % (len(validation), len(bad), len(excluded)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
