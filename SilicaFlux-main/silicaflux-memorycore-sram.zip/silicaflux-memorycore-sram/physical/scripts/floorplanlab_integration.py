#!/usr/bin/env python3
"""floorplanlab_integration.py -- exercise FloorplanLab's OWN validators on the generated MemoryCore geometry.

WHAT THIS DOES (and why it is the one place that executes code from the input tree):
  * copies the extracted FloorplanLab tree to a fresh directory inside the output directory (the original is hashed
    before and after and must be byte-identical afterwards; the copy is deleted at the end),
  * adds our design stub (`status: not_available`) and the generated RunSpec files to the COPY,
  * imports the PURE-PYTHON parts of the copied `floorplanlab` package (config / geometry / validate / lef / liberty)
    -- modules that were read before use and contain no subprocess, network or eval/exec calls -- and calls:
        load_platform + check_platform   (platform profiles; needs ORFS files -> expected to fail offline)
        load_design                      (our design is declared not_available -> expected ConfigError)
        load_run                         (pydantic RunSpec schema validation of our 9 YAML files)
        mode_a + check_geometry          (GATE 5 geometry rules)
        check_macro_placement            (GATE 6 rules: overlap, spacing >= halo, orientation, inside core, pin-escape strips)
  * does NOT run `make floorplan-*`, `Run.check()` (it shells out to git / import_sources.py and needs OpenROAD),
    ORFS, Yosys or the pytest suite.  It states why in the result.

Run with `python3 -I`.  Output: floorplanlab/integration_result.json, floorplanlab/INTEGRATION.md.
"""
import argparse
import hashlib
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DEFAULT = os.path.dirname(HERE)
_SCRATCH = os.environ.get("SILICAFLUX_SCRATCH", "scratch")   # directory that contains audit/x/<extracted project archives>
FLP_DEFAULT = os.environ.get("SILICAFLUX_FLOORPLANLAB", _SCRATCH + "/audit/x/silicaflux-floorplanlab/silicaflux-floorplanlab")
DISCLAIMER = "GENERATED GEOMETRY FROM MANIFEST DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT"


def tree_digest(root):
    h = hashlib.sha256()
    n = 0
    for dp, dn, fn in os.walk(root, followlinks=False):
        dn.sort()
        for name in sorted(fn):
            p = os.path.join(dp, name)
            if os.path.islink(p):
                continue
            rel = os.path.relpath(p, root)
            h.update(rel.encode() + b"\0")
            with open(p, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
            n += 1
    return h.hexdigest(), n


def tally(findings):
    d = {}
    for f in findings:
        k = "%s:%s" % (f.severity, f.code)
        d[k] = d.get(k, 0) + 1
    return dict(sorted(d.items()))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--floorplanlab", default=FLP_DEFAULT)
    ap.add_argument("--out", default=OUT_DEFAULT)
    args = ap.parse_args(argv)
    out = os.path.abspath(args.out)
    src = os.path.abspath(args.floorplanlab)
    if not os.path.isdir(src):
        print("FloorplanLab tree not found: %s" % src)
        return 2
    tmp = os.path.join(out, "_flp_copy_tmp")
    result = dict(label="generated-geometry", disclaimer=DISCLAIMER, floorplanlab_source=os.path.relpath(src, _SCRATCH) if src.startswith(_SCRATCH) else src)
    before, nfiles = tree_digest(src)
    result["original_tree"] = dict(files=nfiles, sha256_before=before)
    if os.path.exists(tmp):
        shutil.rmtree(tmp)
    try:
        shutil.copytree(src, tmp, symlinks=False, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        # add our design stub + RunSpecs to the COPY
        os.makedirs(os.path.join(tmp, "configs", "silicaflux_memorycore", "runs"), exist_ok=True)
        shutil.copy2(os.path.join(out, "floorplanlab", "configs", "silicaflux_memorycore", "design.yaml"), os.path.join(tmp, "configs", "silicaflux_memorycore", "design.yaml"))
        for yp in sorted(os.listdir(os.path.join(out, "floorplanlab", "runs"))):
            shutil.copy2(os.path.join(out, "floorplanlab", "runs", yp), os.path.join(tmp, "configs", "silicaflux_memorycore", "runs", yp))

        sys.dont_write_bytecode = True
        sys.path.insert(0, os.path.join(tmp, "python"))
        from floorplanlab import config as C  # noqa: E402  (copy)
        from floorplanlab import geometry as G  # noqa: E402
        from floorplanlab import validate as V  # noqa: E402
        from floorplanlab import orfs as ORFS  # noqa: E402
        result["floorplanlab_version"] = getattr(sys.modules["floorplanlab"], "__version__", None)
        result["project_root_seen_by_package"] = os.path.relpath(str(C.PROJECT), out)

        # ---- 1. tool / collateral availability (what `make floorplan-tools` and Run.check() need)
        t = ORFS.tools()
        result["tools"] = {k: dict(path=v, exists=os.path.exists(v)) for k, v in t.items()}

        # ---- 2. platform profiles
        plats = {}
        for pdir in sorted(os.listdir(os.path.join(tmp, "platforms"))):
            if not os.path.isfile(os.path.join(tmp, "platforms", pdir, "profile.yaml")):
                continue
            pf = C.load_platform(pdir)
            fs, lef = V.check_platform(pf)
            plats[pdir] = dict(status=pf.status, errors=len(V.errors(fs)), by_code=tally(fs), lef_loaded=lef is not None,
                               first_errors=[f.message for f in V.errors(fs)[:2]])
        result["platform_check"] = plats

        # ---- 3. design
        try:
            C.load_design("silicaflux_memorycore")
            result["design_load"] = dict(ok=True)
        except Exception as e:  # ConfigError expected
            result["design_load"] = dict(ok=False, expected=True, error_type=type(e).__name__, message=str(e))

        # ---- 4. RunSpec schema + 5. geometry gates
        runs = {}
        for yp in sorted(os.listdir(os.path.join(tmp, "configs", "silicaflux_memorycore", "runs"))):
            rid = yp[:-5]
            rec = dict(file="floorplanlab/runs/" + yp)
            try:
                spec = C.load_run(os.path.join(tmp, "configs", "silicaflux_memorycore", "runs", yp))
                rec["runspec_schema"] = "PASS"
            except Exception as e:
                rec["runspec_schema"] = "FAIL"
                rec["runspec_error"] = str(e)[:400]
                runs[rid] = rec
                continue
            fid = rid[3:]  # MC_<id>
            with open(os.path.join(out, "floorplan_%s.json" % fid)) as f:
                fp = json.load(f)
            edges = (fp["macro_shape"].get("secondary_pin_evidence") or {}).get("signal_pin_edges_r0") or {}
            dom = max(edges, key=edges.get) if edges else "bottom"
            rec["halo_um"], rec["channel_um"] = spec.macros.halo_um, spec.macros.channel_um
            rec["pin_side_r0_assumed"] = dom
            rec["pin_side_r0_basis"] = "dominant edge of the sramgrid LEF-derived abstract (secondary evidence)" if edges else "default 'bottom' (no evidence)"
            ms = fp["macros"]
            macros = [G.MacroInst(m["inst"], m["macro_name"], m["w"], m["h"], "main_sram", (m["bank"], m["tile_row"] * 1000 + m["tile_col"]), dom) for m in ms]
            halo, chan = spec.macros.halo_um, spec.macros.channel_um
            placements = [G.Placement(i, next(m.master for m in macros if m.name == i), float(v[0]), float(v[1]), v[2],
                                      *(lambda mm: (mm.width, mm.height))(next(m for m in macros if m.name == i))) for i, v in spec.macros.positions.items()]
            geom = G.mode_a(spec.floorplan, fp["logic_reserve"]["area_um2"], macros, halo)
            pf = C.load_platform(spec.platform)
            gf = V.check_geometry(geom, pf, None)
            mf = V.check_macro_placement(placements, geom.core, macros, halo, chan, pf.macro_allowed_orients, None, None)
            rec["placements_loaded"] = len(placements)
            rec["gate5_geometry"] = dict(errors=len(V.errors(gf)), by_code=tally(gf),
                                         breakdown={k: geom.breakdown.get(k) for k in ("macro_area_um2", "macro_halo_area_um2", "core_area_um2", "std_cell_region_available_um2", "implied_std_cell_util")})
            rec["gate6_macro_placement"] = dict(errors=len(V.errors(mf)), by_code=tally(mf),
                                                examples=[f.message for f in V.errors(mf)[:2]])
            rec["gate6_without_pin_escape"] = len([f for f in V.errors(mf) if not f.code.startswith("PIN_ACCESS")])
            runs[rid] = rec
        result["runs"] = runs

        # ---- not run
        result["not_run"] = [
            dict(item="make floorplan-check / floorplan-run / ... (full ORFS flow)", reason="Makefile target floorplan-tools requires OPENROAD_EXE; tools.env points to /opt/eda/... which does not exist here (see tools[]); ORFS, Yosys-ORFS and the IHP SRAM collateral (LEF/Liberty) are also absent"),
            dict(item="floorplanlab.pipeline.Run.check() (GATE 1/4 + run prechecks for a design)", reason="needs a design.yaml with RTL (ours is declared not_available) and shells out to `git` and tools/import_sources.py --check (needs the SilicaFlux archives) - also not run because this task forbids using git"),
            dict(item="V.check_macro_channels_pdn / check_macro_pin_coverage (PDN rules)", reason="need parsed tech/macro LEFs (layer directions, PG stripe rectangles); none in the repo"),
            dict(item="FloorplanLab pytest suite (tests/)", reason="pytest is not installed in this environment; several tests also require the EDA tools"),
            dict(item="check_platform LEF/Liberty fact checks", reason="platform LEF/Liberty paths do not exist offline (FILE_NOT_FOUND); gf180mcu is `disabled`, commercial_* are templates"),
        ]
    finally:
        sys.path = [p for p in sys.path if not p.startswith(tmp)]
        if os.path.exists(tmp):
            shutil.rmtree(tmp)
    after, _ = tree_digest(src)
    result["original_tree"]["sha256_after"] = after
    result["original_tree"]["unmodified"] = (after == before)
    result["copy_deleted"] = not os.path.exists(tmp)

    # ---------------- summary text
    runs = result["runs"]
    n_schema = sum(1 for r in runs.values() if r.get("runspec_schema") == "PASS")
    g5 = sum(1 for r in runs.values() if r.get("gate5_geometry", {}).get("errors") == 0)
    g6 = sum(1 for r in runs.values() if r.get("gate6_macro_placement", {}).get("errors") == 0)
    g6np = sum(1 for r in runs.values() if r.get("gate6_without_pin_escape") == 0)
    h0 = next(iter(runs.values())).get("halo_um", 0.0)
    c0 = next(iter(runs.values())).get("channel_um", 0.0)
    g5codes = sorted({c for r in runs.values() for c in r.get("gate5_geometry", {}).get("by_code", {}) if c.startswith("error:")})
    g6codes = sorted({c for r in runs.values() for c in r.get("gate6_macro_placement", {}).get("by_code", {}) if c.startswith("error:")})
    tools_missing = [k for k, v in result["tools"].items() if not v["exists"]]
    summary = [
        "FloorplanLab's full flow (`make floorplan-*`, ORFS, OpenROAD, Yosys) could **not** run here: %s are absent (tools.env points to `/opt/eda/...`), MemoryCore is not a FloorplanLab design (its `design.yaml` is declared `status: not_available`, RTL not vendored), and `Run.check()` shells out to git/archives." % ", ".join(tools_missing),
        "What did run (`floorplanlab_integration.py`, on a deleted-afterwards copy; original tree hash unchanged: %s): FloorplanLab's own pure-Python validators on our geometry." % result["original_tree"]["unmodified"],
        "* RunSpec schema (`load_run`, pydantic): **%d/%d** generated `floorplanlab/runs/MC_*.yaml` valid." % (n_schema, len(runs)),
        "* GATE-5 geometry rules (`mode_a` + `check_geometry`): **%d/%d** error-free; the other errors (%s) come from FloorplanLab's utilisation bookkeeping: it subtracts every macro's halo ring separately, double-counting halo shared by neighbouring macros, so for our dense packing it finds no/too little standard-cell region for the placeholder logic area. It is a sizing-rule disagreement, not a macro overlap or out-of-die finding." % (g5, len(runs), ", ".join(g5codes) or "none"),
        "* GATE-6 macro rules (`check_macro_placement`: overlap, spacing >= halo, orientation, inside core, pin-escape strips): **%d/%d** error-free overall; **%d/%d** have no overlap / spacing / orientation / outside-core error. The remaining findings (%s) are FloorplanLab's pin-escape rule, evaluated with an *assumed* pin edge: outer rows' pin edges face the core boundary (pad %g um < required max(channel, halo) = %g um) and, for 8-row stacks, pin-facing rows are one halo apart." % (g6, len(runs), g6np, len(runs), ", ".join(g6codes) or "none", h0, max(h0, c0)),
        "* Platform profiles `check_platform`: " + ", ".join("%s %s (%d errors)" % (k, v["status"], v["errors"]) for k, v in result["platform_check"].items()) + " - every enabled platform fails offline on missing ORFS/LEF/Liberty files.",
        "Details and per-run finding codes: `floorplanlab/INTEGRATION.md`, `floorplanlab/integration_result.json`.",
    ]
    result["readme_summary"] = summary
    with open(os.path.join(out, "floorplanlab", "integration_result.json"), "w") as f:
        json.dump(result, f, indent=1)
        f.write("\n")
    with open(os.path.join(out, "floorplanlab", "INTEGRATION.md"), "w") as f:
        f.write(make_md(result))
    print("\n".join(summary))
    return 0


def make_md(r):
    L = []
    A = L.append
    A("# FloorplanLab integration - what was done and what could not be")
    A("")
    A("> **" + DISCLAIMER + "**")
    A("")
    A("## Files in FloorplanLab's schema")
    A("")
    A("* `floorplanlab/runs/MC_<cfg>_<family>.yaml` (9): FloorplanLab `RunSpec` (`python/floorplanlab/config.py`): `floorplan.mode: A` with `die_area` / `core_area`, `macros.placement: manual` with explicit `positions: {instance: [x, y, orient]}`, `halo_um`, `channel_um`, `platform` = `sky130hd` / `ihp_sg13g2` / `gf180mcu`.")
    A("* `floorplanlab/configs/silicaflux_memorycore/design.yaml`: design stub following the repo convention of `configs/mcu_i/design.yaml` (`status: not_available`): FloorplanLab vendors only SilicaFlux-V + DataFabric RTL, so MemoryCore cannot be a FloorplanLab design without vendoring RTL and writing an SDC template, `expected_macros` per platform and `macro_groups`.")
    A("")
    A("## What was executed (offline, on a copy)")
    A("")
    A("The extracted FloorplanLab tree was copied to a fresh directory, its `config`, `geometry`, `validate`, `lef`, `liberty` and `orfs` modules were imported (reviewed beforehand: no subprocess/network/eval/exec in config, geometry, validate, lef, liberty; `orfs` contains subprocess helpers that were NOT called - only `orfs.tools()` was) and the following FloorplanLab functions were called. The original tree hash before/after: `%s` -> `%s` (**unmodified: %s**); the copy was deleted (%s)." % (
        r["original_tree"]["sha256_before"][:16], r["original_tree"]["sha256_after"][:16], r["original_tree"]["unmodified"], r["copy_deleted"]))
    A("")
    A("### Tool availability (`orfs.tools()`; what `make floorplan-tools` tests)")
    A("")
    A("| tool / collateral | path in tools.env | exists |")
    A("|---|---|---|")
    for k, v in r["tools"].items():
        A("| %s | `%s` | %s |" % (k, v["path"], "yes" if v["exists"] else "**no**"))
    A("")
    A("### Platform profiles (`load_platform` + `check_platform`)")
    A("")
    A("| platform | status | errors | main codes |")
    A("|---|---|---|---|")
    for k, v in r["platform_check"].items():
        A("| %s | %s | %d | %s |" % (k, v["status"], v["errors"], ", ".join("%s x%d" % (c, n) for c, n in list(v["by_code"].items())[:4]) or "-"))
    A("")
    A("### Design (`load_design('silicaflux_memorycore')`)")
    A("")
    A("`%s`: %s" % (r["design_load"].get("error_type"), r["design_load"].get("message")))
    A("")
    A("### Our 9 RunSpecs: schema and geometry gates")
    A("")
    A("`pin_side_r0` (needed by FloorplanLab's pin-escape rule) is an ASSUMPTION taken from the dominant edge of the secondary LEF-derived abstract (`bottom` for all three families); it is not verified against any LEF.")
    A("")
    A("| run | RunSpec schema | GATE 5 errors | GATE 6 errors | GATE 6 errors excl. pin-escape | GATE 6 finding codes |")
    A("|---|---|---|---|---|---|")
    for k, v in r["runs"].items():
        if v.get("runspec_schema") != "PASS":
            A("| %s | FAIL: %s | - | - | - | - |" % (k, v.get("runspec_error")))
            continue
        A("| %s | PASS | %d | %d | %d | %s |" % (k, v["gate5_geometry"]["errors"], v["gate6_macro_placement"]["errors"], v["gate6_without_pin_escape"], ", ".join("%s x%d" % (c, n) for c, n in v["gate6_macro_placement"]["by_code"].items()) or "-"))
    A("")
    A("Reading the table:")
    A("")
    A("* `MACRO_OVERLAP`, `MACRO_SPACING`, `MACRO_OUTSIDE_CORE`, `ILLEGAL_ORIENT`, `MACRO_OFF_GRID` would indicate real macro-geometry problems: **none occurs**.")
    A("* `PIN_ACCESS_EDGE` / `PIN_ACCESS_BLOCKED` come from FloorplanLab's pin-escape rule: the strip max(channel, halo) = 40 um in front of every pin edge must lie inside the core and be free of other macro bodies. With the assumed pin edge (R0 bottom), the first row of a bank (R0) has its pins facing the core pad (20 um < 40 um) and the top MX row likewise (`PIN_ACCESS_EDGE`); in 8-row stacks the pin-facing row boundaries are only one halo (20 um) apart (`PIN_ACCESS_BLOCKED`, C3 sky130 and C3 gf180). This is a genuine limitation of the generated packing: it is **not pin-aware** (pin geometry is unknown from the manifests; the orientation scheme is an assumption).")
    A("* `NO_STD_REGION` / `OVER_UTILISED` (GATE 5) come from FloorplanLab's bookkeeping `std region = core - macros - sum(per-macro halo rings)`, which double-counts halo shared by neighbouring macros. In our packing every halo lies inside the gaps/channels/core pad (our exact union accounting in `area_report.md` shows the halo keepout adds no die area), so the rule concludes there is no room for the placeholder logic area although nothing overlaps. Per-run numbers (um2):")
    A("")
    A("| run | core | macro area | sum of halo rings (FloorplanLab) | std region left (FloorplanLab) | implied util of the logic placeholder |")
    A("|---|---|---|---|---|---|")
    for k, v in r["runs"].items():
        b = v.get("gate5_geometry", {}).get("breakdown")
        if b:
            A("| %s | %s | %s | %s | %s | %s |" % (k, format(b["core_area_um2"], ",.0f"), format(b["macro_area_um2"], ",.0f"), format(b["macro_halo_area_um2"], ",.0f"), format(b["std_cell_region_available_um2"], ",.0f"), "n/a (region <= 0)" if b["implied_std_cell_util"] is None else "%.2f" % b["implied_std_cell_util"]))
    A("")
    A("")
    A("## What could NOT be run, and exactly why")
    A("")
    for n in r["not_run"]:
        A("* **%s** - %s" % (n["item"], n["reason"]))
    A("")
    A("## Net effect")
    A("")
    A("FloorplanLab integration is **partial**: we emit configs in its schema that its own loader validates and whose geometry its own placement/geometry checks evaluate; we cannot obtain any result from its flow (no placement, PDN, STA, routing) because the toolchain, PDK collateral and MemoryCore RTL are absent. No FloorplanLab result is claimed for MemoryCore beyond the validator outputs above.")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    sys.exit(main())
