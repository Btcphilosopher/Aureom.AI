# third_party — existing SilicaFlux code reused BYTE-IDENTICAL (never edited here)

Source repository: `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (nested project archives). Each file below
is copied unmodified from the archive named; `SHA256SUMS` lists the digest of every file so drift is detectable
(`cd third_party && sha256sum -c SHA256SUMS`).

| Directory | Files | Upstream archive (inside SilicaFlux-main/) | Why reused instead of rewritten |
|---|---|---|---|
| `ras_secded/` | `sfras_secded_enc.sv`, `sfras_secded_dec.sv`, `sfras_ecc_funcs.svh`, `sfras_defs.svh` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-ras-project26.zip` (Project 26 RAS) | Verified extended-Hamming SECDED leaf codec (parametric K; K=128 -> (137,128)) with a built-in none/CE/UE classifier. Re-verified here with an independent Python model and exhaustive single/double-error sweeps (`tb/tb_ecc_codec.sv`). |
| `sramlib_mbist/` | `sram_mbist_march.sv`, `sram_defs.svh` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` (Project 01) | March C- / MATS+ controller on the TestCore collar bus. This project adds the fault models, the memory-side test port and the measured coverage; it does not replace the March engine. |
| `noc_sfb3/` | `rtl/sfn_*.sv`, `rtl/silicaflux_noc.sv`, `rtl/sfb_arbiter.sv`, `rtl/sfb_addr_decoder.sv`, `tb/sfn_protocol_checker.sv`, `tb/sfn_tb_common.svh` | `silicaflux-datafabric-noc.zip` (Project 22) incl. its vendored DataFabric files | The implemented DataFabric NoC (SFB3 transaction interface). Used only to prove that `sf_sram_datafabric` works behind the real fabric, with the real protocol checker. |

Nothing in this directory is part of the new RTL claim; the new RTL lives in `rtl/`.
