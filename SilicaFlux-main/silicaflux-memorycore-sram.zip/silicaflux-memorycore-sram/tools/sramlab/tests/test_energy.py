import json
import os
import unittest

import _paths
import sram_energy as SE
from sramlab.model import Cfg, simulate


class TestParams(unittest.TestCase):
    def test_every_assumed_parameter_is_labelled(self):
        with open(SE.PARAMS_PATH) as fh:
            raw = json.load(fh)
        self.assertIn("NOT a measurement", raw["_label"])
        for k, v in raw["params"].items():
            self.assertIn("ASSUMPTION - not from any process", v["comment"], k)
            self.assertIn("replace with Liberty/characterised values", v["comment"], k)
            self.assertIn("unit", v)

    def test_rtl_derived_constants(self):
        with open(SE.PARAMS_PATH) as fh:
            raw = json.load(fh)
        self.assertEqual(raw["_derived_from_RTL_not_assumed"]["ecc_stored_bits_per_line"], SE.ECC_W)
        self.assertEqual(SE.ECC_W, 137)


class TestAccessEnergy(unittest.TestCase):
    def setUp(self):
        self.P, _ = SE.load_params()

    def test_ecc_costs_more(self):
        a0, a1 = SE.access_energies(self.P, 256, 0), SE.access_energies(self.P, 256, 1)
        self.assertGreater(a1["read"], a0["read"])
        self.assertGreater(a1["write_full"], a0["write_full"])
        self.assertAlmostEqual(a1["write_partial"], a1["read"] + a1["write_full"])         # RMW = read + write
        self.assertGreater(a1["write_partial"], 1.7 * a0["write_partial"])

    def test_bit_proportional_scaling_is_137_over_128(self):
        P = dict(self.P)
        for k in ("e_dec_fixed_pj", "e_dec_per_addrbit_pj", "e_ecc_enc_pj", "e_ecc_dec_pj"):
            P[k] = 0.0
        a0, a1 = SE.access_energies(P, 256, 0), SE.access_energies(P, 256, 1)
        self.assertAlmostEqual(a1["read"] / a0["read"], 137 / 128, places=9)
        self.assertAlmostEqual(a1["write_full"] / a0["write_full"], 137 / 128, places=9)

    def test_leakage_scales_with_bits(self):
        l0, l1 = SE.leakage_w(self.P, 4, 1024, 0), SE.leakage_w(self.P, 4, 1024, 1)
        self.assertAlmostEqual(l1 / l0, 137 / 128, places=9)
        self.assertAlmostEqual(SE.leakage_w(self.P, 4, 2048, 0) / l0, 2.0, places=9)

    def test_scalar_vs_line_ratio_is_parameter_free(self):
        for scale in (0.1, 1.0, 10.0):
            P = {k: (v * scale if isinstance(v, float) else v) for k, v in self.P.items()}
            e = SE.access_energies(P, 256, 0)["read"]
            self.assertAlmostEqual((e / 4.0) / (e / 16.0), 4.0)


class TestRunEnergy(unittest.TestCase):
    def setUp(self):
        self.P, _ = SE.load_params()

    def test_components_sum_and_counts(self):
        res = simulate(Cfg(pattern=8, ecc=1, nreq=300))
        e = SE.run_energy(res, self.P)
        self.assertAlmostEqual(e["E_total_pJ"], e["E_array_dynamic_pJ"] + e["E_bank_idle_clk_pJ"] + e["E_controller_pJ"] + e["E_leakage_pJ"], places=6)
        self.assertEqual(e["reads"] + e["writes_full"] + e["writes_partial"], e["accesses"])
        self.assertEqual(e["accesses"], 1200)

    def test_vector_vs_scalar_energy_per_useful_byte(self):
        vec = SE.run_energy(simulate(Cfg(pattern=1, nreq=300)), self.P)
        sca = SE.run_energy(simulate(Cfg(pattern=0, nreq=300)), self.P)
        self.assertAlmostEqual(sca["pJ_per_useful_byte_dynamic"] / vec["pJ_per_useful_byte_dynamic"], 4.0, places=6)

    def test_align_errors_cost_no_array_energy(self):
        r = SE.run_energy(simulate(Cfg(pattern=9, nreq=200)), self.P)       # model-only byte-stride scalar pattern
        self.assertEqual(r["accesses"], 200)
        self.assertEqual(r["useful_bytes_array"], 800)

    def test_conflicts_cost_time_not_dynamic_energy(self):
        a = SE.run_energy(simulate(Cfg(pattern=1, nreq=300)), self.P)           # conflict free
        b = SE.run_energy(simulate(Cfg(pattern=3, nreq=300)), self.P)           # single bank: 4x slower, same accesses
        self.assertAlmostEqual(a["E_array_dynamic_pJ"], b["E_array_dynamic_pJ"])
        self.assertGreater(b["E_leakage_pJ"], 3.5 * a["E_leakage_pJ"])

    def test_energy_monotonic_in_assumed_parameters(self):
        res = simulate(Cfg(pattern=5, nreq=300))
        base = SE.run_energy(res, self.P)["E_total_pJ"]
        for k in ("e_rd_bit_fj", "e_wr_bit_fj", "e_dec_fixed_pj", "leak_pw_per_bit", "e_ctrl_access_pj"):
            P = dict(self.P)
            P[k] = P[k] * 2
            self.assertGreater(SE.run_energy(res, P)["E_total_pJ"], base, k)


class TestTensorEnergy(unittest.TestCase):
    def setUp(self):
        self.P, _ = SE.load_params()

    def test_counts(self):
        c = SE.tensor_counts(8, 3)
        self.assertEqual((c["reads"], c["writes"], c["macs"]), (3 * 8 * 3 + 8, 8 * 3 + 3 * 8, 4 * 8 * 3))
        self.assertAlmostEqual(c["accesses_per_mac"], 128 / 96)

    def test_double_buffer_bracket_for_any_parameters(self):
        # parameter-free bracket: cycles ratio <= energy ratio <= 1 whatever the assumed values
        import random
        rng = random.Random(1)
        for _ in range(200):
            P = {k: (v * (4 ** rng.uniform(-1, 1)) if isinstance(v, float) else v) for k, v in self.P.items()}
            s = SE.tensor_energy(P, 8, 3, 113)["pJ_per_MAC_total"]
            d = SE.tensor_energy(P, 8, 3, 78)["pJ_per_MAC_total"]
            self.assertLessEqual(d / s, 1.0 + 1e-12)
            self.assertGreaterEqual(d / s, 78 / 113 - 1e-9)

    def test_dynamic_energy_independent_of_cycles(self):
        a = SE.tensor_energy(self.P, 8, 3, 113)
        b = SE.tensor_energy(self.P, 8, 3, 78)
        self.assertAlmostEqual(a["pJ_per_MAC_dynamic"], b["pJ_per_MAC_dynamic"])


class TestThermalHandoff(unittest.TestCase):
    def test_example_matches_documented_schema(self):
        path = os.path.join(_paths.ROOT, "power", "thermal_input_example.json")
        if not os.path.exists(path):
            self.skipTest("run python3 power/sram_energy.py first")
        with open(path) as fh:
            doc = json.load(fh)
        self.assertEqual(SE.validate_thermal_example(doc), [])
        self.assertIn("NOT executed", doc["_label"])
        for b in doc["blocks"]:
            self.assertEqual(b["provenance"], "assumed_engineering_parameter")
            for k in SE.REQUIRED_BLOCK_FIELDS:
                self.assertIn(k, b)

    def test_validator_catches_problems(self):
        doc = {"_die_um": {"die_width_um": 100, "die_height_um": 100},
               "blocks": [{"name": "a", "zone": "z", "x0_um": 0, "y0_um": 0, "x1_um": 60, "y1_um": 60, "power_w": 1e-3, "provenance": "assumed_engineering_parameter"},
                          {"name": "b", "zone": "z", "x0_um": 50, "y0_um": 50, "x1_um": 120, "y1_um": 90, "power_w": -1.0, "provenance": "made_up"}]}
        probs = SE.validate_thermal_example(doc)
        self.assertTrue(any("overlap" in p for p in probs))
        self.assertTrue(any("outside the die" in p for p in probs))
        self.assertTrue(any("negative" in p for p in probs))
        self.assertTrue(any("provenance" in p for p in probs))


if __name__ == "__main__":
    unittest.main()
