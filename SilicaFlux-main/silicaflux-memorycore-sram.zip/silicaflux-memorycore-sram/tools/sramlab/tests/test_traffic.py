import unittest

import _paths  # noqa: F401
from sramlab import traffic as T


class TestPrng(unittest.TestCase):
    def test_xorshift32_known_values(self):
        # xorshift32 with (13, 17, 5), x0 = 1: well known sequence 270369, 67634689, 2647435461, ...
        x = 1
        seq = []
        for _ in range(3):
            x = T.xs(x)
            seq.append(x)
        self.assertEqual(seq, [270369, 67634689, 2647435461])

    def test_xs_is_32_bit_and_nonzero_cycle(self):
        x = 0xC0FFEE
        for _ in range(1000):
            x = T.xs(x)
            self.assertTrue(0 < x < 2 ** 32)
        self.assertEqual(T.xs(0), 0)          # the all-zero state is the (known) fixed point

    def test_master_seed(self):
        # s_m = SEED ^ ((m+1) * 32'h9E3779B9), 32-bit wrap
        self.assertEqual(T.master_seed(0x00C0FFEE, 0), 0x00C0FFEE ^ 0x9E3779B9)
        self.assertEqual(T.master_seed(0x00C0FFEE, 1), 0x00C0FFEE ^ ((2 * 0x9E3779B9) & 0xFFFFFFFF))
        self.assertEqual(T.master_seed(1000 + 1, 3), (1001) ^ ((4 * 0x9E3779B9) & 0xFFFFFFFF))

    def test_draw_order_one_draw_per_request(self):
        s = T.MasterStream(1, 0, 4, 4, 256, 5)       # pattern 1 does not use the draw, but consumes it
        st = T.master_seed(5, 0)
        for _ in range(3):
            s.next()
            st = T.xs(st)
        self.assertEqual(s.state, st)

    def test_load_gate_and_rsp_ready(self):
        self.assertTrue(T.load_gate(7, 0, 100))
        self.assertTrue(T.rsp_ready_draw(7, 1, 100))
        # explicit evaluation of the TB expression for one point
        c, m = 12345, 2
        arg = ((c * 2654435) & 0xFFFFFFFF) ^ (m << 16) ^ 0x5A5A5A5A
        self.assertEqual(T.load_gate(c, m, 37), (T.xs(arg) % 100) < 37)
        self.assertEqual(T.rsp_ready_draw(c, m, 37), (T.xs(c ^ (m << 8)) % 100) < 37)
        # the cycle counter is truncated to 32 bit
        self.assertEqual(T.load_gate((1 << 32) + 5, 1, 50), T.load_gate(5, 1, 50))
        # long-run frequency is the requested probability
        n = sum(T.load_gate(c, 0, 30) for c in range(20000))
        self.assertAlmostEqual(n / 20000, 0.30, delta=0.02)


class TestPatterns(unittest.TestCase):
    NB, DEPTH, NM = 4, 256, 4

    def stream(self, pat, m=0, n=64, seed=0x00C0FFEE):
        return T.stream(pat, m, self.NM, self.NB, self.DEPTH, seed, n)

    def bank_row(self, r):
        st, b, row = T.decode(r.addr, self.NB, self.DEPTH)
        return st, b, row

    def test_seq_line_regions_and_rotation(self):
        region = self.NB * self.DEPTH // self.NM
        for m in range(self.NM):
            reqs = self.stream(1, m)
            for k, r in enumerate(reqs):
                self.assertFalse(r.we)
                self.assertEqual(r.addr >> 4, m * region + (k % region))
                self.assertEqual(r.useful, 16)
        # consecutive lines rotate through the banks
        banks = [self.bank_row(r)[1] for r in self.stream(1, 1, 8)]
        self.assertEqual(banks, [0, 1, 2, 3, 0, 1, 2, 3])

    def test_own_bank(self):
        for m in range(self.NM):
            self.assertEqual({self.bank_row(r)[1] for r in self.stream(2, m, 200)}, {m % self.NB})

    def test_same_bank(self):
        for m in range(self.NM):
            self.assertEqual({self.bank_row(r)[1] for r in self.stream(3, m, 200)}, {0})

    def test_scalar_pattern_is_line_aligned(self):
        reqs = self.stream(0, 0, 400)
        self.assertEqual([r.useful for r in reqs[:3]], [4, 4, 4])
        self.assertEqual([r.addr for r in reqs[:8]], [0, 0, 0, 0, 16, 16, 16, 16])      # 4 consecutive loads share one line
        self.assertTrue(all(T.decode(r.addr, 4, 256, 1)[0] == 0 for r in reqs))         # nothing is rejected with ALIGN_MODE = 1

    def test_byte_stride_pattern_9_is_mostly_misaligned(self):
        reqs = self.stream(9, 0, 400)
        self.assertEqual(reqs[1].addr - reqs[0].addr, 4)
        status = [self.bank_row(r)[0] for r in reqs]
        self.assertEqual(status.count(2), 300)             # SF_ST_ALIGN for k % 4 != 0 (ALIGN_MODE = 1)
        self.assertEqual(status.count(0), 100)
        self.assertTrue(all(T.decode(r.addr, 4, 256, 0)[0] == 0 for r in reqs))         # ALIGN_MODE = 0: everything reaches an array

    def test_random_patterns_use_the_draw(self):
        seed = 0x00C0FFEE
        st = T.master_seed(seed, 2)
        cap = self.NB * self.DEPTH
        s = T.MasterStream(4, 2, self.NM, self.NB, self.DEPTH, seed)
        s5 = T.MasterStream(5, 2, self.NM, self.NB, self.DEPTH, seed)
        s8 = T.MasterStream(8, 2, self.NM, self.NB, self.DEPTH, seed)
        for _ in range(50):
            st = T.xs(st)
            r4, r5, r8 = s.next(), s5.next(), s8.next()
            self.assertEqual(r4.addr >> 4, st % cap)
            self.assertFalse(r4.we)
            self.assertEqual(r5.we, bool(st & 1))
            self.assertEqual(r5.addr >> 4, (st >> 1) % cap)
            self.assertEqual(r5.be, 0xFFFF)
            self.assertEqual(r8.we, bool(st & 1))
            self.assertEqual(r8.be, 0x000F if r8.we else 0xFFFF)
            self.assertEqual(r8.useful, 4)

    def test_write_patterns(self):
        for r in self.stream(6, 1, 10):
            self.assertTrue(r.we)
            self.assertEqual(r.be, 0xFFFF)
            self.assertFalse(T.is_partial(r))
        for r in self.stream(7, 1, 10):
            self.assertTrue(r.we)
            self.assertEqual(r.be, 0x000F)
            self.assertTrue(T.is_partial(r))
            self.assertEqual(r.useful, 4)

    def test_addresses_in_range(self):
        for pat in range(9):
            for m in range(self.NM):
                for r in self.stream(pat, m, 300):
                    self.assertLess(r.addr >> 4, self.NB * self.DEPTH)


if __name__ == "__main__":
    unittest.main()
