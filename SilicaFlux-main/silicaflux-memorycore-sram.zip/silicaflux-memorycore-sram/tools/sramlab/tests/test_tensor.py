import json
import os
import unittest

import _paths
from sramlab import tensor as TN


class TestPhaseModel(unittest.TestCase):
    def test_phase_formulas(self):
        c = TN.TCfg()                                   # N=8, PASSES=3, BL=1
        ph = TN.phase_times(c)
        self.assertEqual((ph["Df"], ph["Dd"], ph["Dpass"], ph["Dc"]), (27, 11, 22, 66))
        self.assertEqual(ph["single_buffer_cycles_per_tile"], 27 + 66 + 11 + 9)      # 113 (equals the RTL value)
        self.assertEqual(TN.phase_times(TN.TCfg(ecc=1))["Df"], 28)                   # one more cycle of bank latency

    def test_single_buffer_is_serial_sum(self):
        for kw in ({}, dict(n=16), dict(compute_extra=16), dict(compute_extra=48), dict(read_latency=2, ecc=1)):
            c = TN.TCfg(nbuf=1, **kw)
            self.assertEqual(TN.steady_period(c)["cycles_per_tile"], TN.phase_times(c)["single_buffer_cycles_per_tile"])
            pp = TN.phase_pipeline(c)
            self.assertAlmostEqual(pp["total_cycles"], c.ntiles * pp["phases"]["single_buffer_cycles_per_tile"] + 5, delta=1)

    def test_double_buffer_never_slower_than_single_conflict_free(self):
        for kw in ({}, dict(n=16), dict(compute_extra=48), dict(passes=1)):
            s = TN.steady_period(TN.TCfg(nbuf=1, **kw))["cycles_per_tile"]
            d = TN.steady_period(TN.TCfg(nbuf=2, **kw))["cycles_per_tile"]
            self.assertLessEqual(d, s)

    def test_bound_classification(self):
        self.assertEqual(TN.steady_period(TN.TCfg(nbuf=2))["bound"], "compute")
        self.assertEqual(TN.steady_period(TN.TCfg(nbuf=2, passes=1))["bound"], "DMA")


class TestStarvation(unittest.TestCase):
    def test_monotonic_in_dma_rate_and_compute(self):
        a = TN.starvation(8, 66, 1.0)["starved_fraction"]
        b = TN.starvation(8, 66, 0.25)["starved_fraction"]
        c = TN.starvation(8, 200, 0.25)["starved_fraction"]
        self.assertEqual(a, 0.0)                         # full-rate DMA is hidden behind 66 compute cycles
        self.assertGreater(b, a)
        self.assertLess(c, b)                            # more compute per tile hides a slower DMA

    def test_single_buffer_exposes_dma(self):
        s = TN.starvation(8, 66, 1.0, nbuf=1)
        self.assertAlmostEqual(s["stall_per_tile"], 27 + 11 + 9)
        self.assertAlmostEqual(s["period"], 113)
        self.assertGreater(s["starved_fraction"], 0.2)

    def test_min_beta_helper(self):
        b = TN.min_beta_for_hidden_prefetch(8, 66)
        self.assertAlmostEqual(b, 0.5)
        self.assertEqual(TN.starvation(8, 66, b)["stall_per_tile"], 0.0)
        self.assertGreater(TN.starvation(8, 66, b * 0.9)["stall_per_tile"], 0.0)

    def test_threshold_formula(self):
        # prefetch fully hidden iff T_c + gap >= T_dma  (N=8, beta=1/2: T_dma = 4*8*2 + 2*(1+2+3)... check the crossover numerically)
        for beta in (1.0, 0.5, 0.25):
            t = TN.starvation(8, 1, beta)
            t_dma = t["t_dma"]
            self.assertEqual(TN.starvation(8, t_dma - TN.GAP, beta)["stall_per_tile"], 0.0)
            self.assertGreater(TN.starvation(8, t_dma - TN.GAP - 5, beta)["stall_per_tile"], 0.0)


@unittest.skipUnless(os.path.exists(_paths.BENCH_JSON), "reports/bench_rtl.json missing: tensor co-simulation regression skipped")
class TestCosimVsRtl(unittest.TestCase):
    def test_committed_tensor_rows_exact(self):
        with open(_paths.BENCH_JSON) as fh:
            bench = json.load(fh)
        self.assertGreaterEqual(len(bench["tensor"]), 11)
        for r in bench["tensor"]:
            cs = TN.cosim(TN.TCfg.from_row(r))
            self.assertEqual((cs["total_cycles"], cs["cycles_per_tile"], cs["overlap_cycles"], cs["bank_conflict_cycles"], cs["bank_busy_stalls"]),
                             (r["total_cycles"], r["cycles_per_tile"], r["overlap_cycles"], r["bank_conflict_cycles"], r["bank_busy_stalls"]), r["config"])

    def test_phase_model_exact_for_single_buffer_without_conflicts(self):
        with open(_paths.BENCH_JSON) as fh:
            bench = json.load(fh)
        for r in bench["tensor"]:
            if r["nbuf"] == 1 and r["bank_conflict_cycles"] == 0:
                cfg = TN.TCfg.from_row(r)
                self.assertEqual(TN.phase_pipeline(cfg)["total_cycles"], r["total_cycles"], r["config"])

    def test_double_buffer_rtl_not_below_conflict_free_bound(self):
        with open(_paths.BENCH_JSON) as fh:
            bench = json.load(fh)
        for r in bench["tensor"]:
            if r["nbuf"] == 2:
                self.assertGreaterEqual(r["total_cycles"], TN.phase_pipeline(TN.TCfg.from_row(r))["total_cycles"])


if __name__ == "__main__":
    unittest.main()
