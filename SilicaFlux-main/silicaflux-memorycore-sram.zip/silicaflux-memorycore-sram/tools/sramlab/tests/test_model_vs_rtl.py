import json
import os
import shutil
import unittest

import _paths
from sramlab import validate as V
from sramlab.model import Cfg, simulate

STATS = V.STATS


@unittest.skipUnless(os.path.exists(_paths.BENCH_JSON), f"reports/bench_rtl.json missing ({_paths.BENCH_JSON}): run benchmarks/run_bench.py to enable the model-vs-RTL regression")
class TestAgainstCommittedRtlRows(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(_paths.BENCH_JSON) as fh:
            cls.bench = json.load(fh)

    def test_every_controller_row_exact(self):
        rows = self.bench["controller"]
        self.assertGreater(len(rows), 100)
        bad = []
        for r in rows:
            res = simulate(Cfg.from_row(r))
            c = V.compare_row(r, res)
            if not c["match"]:
                bad.append((r["experiment"], r["config"], r["pattern"], c["diff"]))
        self.assertEqual(bad, [], f"{len(bad)} rows differ from the RTL simulation: {bad[:5]}")

    def test_seven_statistics_checked(self):
        self.assertEqual(STATS, ["cycles", "accesses", "bank_conflict_cycles", "bank_busy_stalls", "mean_latency", "max_latency", "max_outstanding"])

    def test_reads_writes_useful_bytes(self):
        for r in self.bench["controller"][:60]:
            m = simulate(Cfg.from_row(r))
            self.assertEqual((r["reads"], r["writes"], r["useful_bytes"]), (m.reads, m.writes, m.useful_bytes))


@unittest.skipUnless(os.path.exists(_paths.EXTRA_JSON), "reports/sramlab_rtl_extra.json missing: run `python3 -m sramlab rtl-extra` (needs Verilator) to enable")
class TestAgainstStoredExtraCampaign(unittest.TestCase):
    def test_extra_runs_exact_incl_per_edge_trace(self):
        with open(_paths.EXTRA_JSON) as fh:
            d = json.load(fh)
        rows = d["controller"]["rows"]
        self.assertGreater(len(rows), 300)
        bad = [(r["config"], r["pattern"]) for r in rows if not (r["match"] and r["trace_identical"] and r["perf_counters_match"])]
        self.assertEqual(bad, [])
        # re-run the model for a sample and compare with the stored RTL numbers (guards against a model change after the campaign)
        for r in rows[::37]:
            cfg = Cfg(nm=r["nm"], nb=r["nb"], depth=r["depth"], read_latency=r["read_latency"], ecc=r["ecc"], nslot=r["nslot"], arb=r["arb"], pattern=r["pattern"],
                      nreq=r["nreq"], rsp_pct=r["rsp_pct"], load_pct=r["load_pct"], seed=r["seed"], align_mode=r["align_mode"])
            self.assertEqual(V.compare_row(r["rtl"], simulate(cfg))["match"], True, (r["config"], r["pattern"]))

    def test_tensor_extra_traces(self):
        with open(_paths.EXTRA_JSON) as fh:
            d = json.load(fh)
        for r in d["tensor"]["rows"]:
            self.assertTrue(r["trace_identical"], r["config"])
            if r["cfg"].get("NB", 4) == 4:
                self.assertTrue(r["stats_match"], r["config"])


@unittest.skipUnless(os.environ.get("SRAMLAB_RTL") == "1" and shutil.which("verilator"),
                     "set SRAMLAB_RTL=1 (and have Verilator) to build and run an extra RTL simulation (~1 min) and compare it with the model edge by edge")
class TestLiveRtlRun(unittest.TestCase):
    def test_nm3_ns3_ecc_random_rw(self):
        from sramlab import rtlrun
        over = dict(NM=3, NB=4, DEPTH=64, READ_LATENCY=2, ECC_EN=1, NSLOT=3, ARB=1)
        exe = rtlrun.build("test_live", over)
        out = rtlrun.run(exe, 8, 200, {"RSP_PCT": 60, "LOAD_PCT": 70, "SEED": 4242}, trace=True)
        cfg = Cfg(nm=3, nb=4, depth=64, read_latency=2, ecc=1, nslot=3, arb=1, pattern=8, nreq=200, rsp_pct=60, load_pct=70, seed=4242)
        res = simulate(cfg, trace=True)
        self.assertTrue(V.compare_row(out["bench"], res)["match"])
        self.assertTrue(V.compare_trace(out["trace"], res)["identical"])


class TestModelStructure(unittest.TestCase):
    """Properties derived from the RTL source / contract, independent of the JSON."""

    def test_zero_load_latency_is_bank_lat_plus_two(self):
        for rl in (1, 2, 3):
            for ecc in (0, 1):
                m = simulate(Cfg(pattern=2, read_latency=rl, ecc=ecc, nreq=20, nm=1, nb=1))
                self.assertEqual(m.max_latency, rl + ecc + 2)

    def test_nslot_limit_and_rate(self):
        # NSLOT credits: rate = NSLOT/(BANK_LAT+2) accesses per cycle per master (RL=2 -> BL=2: round trip 4)
        m = simulate(Cfg(nm=1, nb=4, pattern=1, read_latency=2, nslot=2, nreq=2000))
        self.assertAlmostEqual(2000 / m.cycles, 2 / 4, delta=0.01)
        self.assertEqual(m.max_outstanding, 2)
        m = simulate(Cfg(nm=1, nb=4, pattern=1, read_latency=2, nslot=4, nreq=2000))
        self.assertAlmostEqual(2000 / m.cycles, 1.0, delta=0.01)

    def test_single_bank_serialises(self):
        m = simulate(Cfg(pattern=3, nreq=500))
        self.assertAlmostEqual(m.throughput_Bpc, 16.0, delta=0.1)           # one access per cycle on one bank
        self.assertGreater(m.bank_conflict_cycles, 0.9 * m.cycles)

    def test_ecc_rmw_occupancy(self):
        base = simulate(Cfg(pattern=7, ecc=0, nreq=500))
        ecc1 = simulate(Cfg(pattern=7, ecc=1, read_latency=1, nreq=500))
        ecc2 = simulate(Cfg(pattern=7, ecc=1, read_latency=2, nreq=500, nslot=8))
        self.assertAlmostEqual(base.cycles / ecc1.cycles, 1 / 2, delta=0.02)            # RL+1 = 2 bank cycles per partial write
        self.assertAlmostEqual(base.cycles / ecc2.cycles, 1 / 3, delta=0.02)            # RL+1 = 3
        self.assertGreater(ecc1.bank_busy_stalls, 0)
        self.assertEqual(base.bank_busy_stalls, 0)

    def test_rr_fairness_bound_and_fixed_starvation(self):
        rr = simulate(Cfg(pattern=3, arb=1, nreq=300))
        self.assertTrue(all(w <= 3 for w in rr.per_master_max_wait))          # NM - 1 = 3 grants (contract O6)
        fx = simulate(Cfg(pattern=3, arb=0, nreq=300))
        self.assertGreater(fx.per_master_max_wait[3], 100)                    # master 3 starves while masters 0-2 stream

    def test_align_errors_do_not_touch_banks(self):
        m = simulate(Cfg(pattern=9, nreq=200))                       # model-only byte-stride pattern
        self.assertEqual(m.err_responses, 600)
        self.assertEqual(sum(m.per_bank_acc), 200)

    def test_in_order_slot_release_and_max_outstanding(self):
        m = simulate(Cfg(pattern=4, nreq=300, nslot=3))
        self.assertTrue(all(o <= 3 for o in m.per_master_max_out))


if __name__ == "__main__":
    unittest.main()
