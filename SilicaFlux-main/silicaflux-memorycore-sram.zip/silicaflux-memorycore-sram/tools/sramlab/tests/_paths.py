"""Common path setup for the sramlab tests (importable as `_paths`; unittest discover puts this directory on sys.path)."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(os.path.dirname(HERE))
ROOT = os.path.dirname(TOOLS)
for p in (TOOLS, os.path.join(ROOT, "power")):
    if p not in sys.path:
        sys.path.insert(0, p)
BENCH_JSON = os.path.join(ROOT, "reports", "bench_rtl.json")
EXTRA_JSON = os.path.join(ROOT, "reports", "sramlab_rtl_extra.json")
