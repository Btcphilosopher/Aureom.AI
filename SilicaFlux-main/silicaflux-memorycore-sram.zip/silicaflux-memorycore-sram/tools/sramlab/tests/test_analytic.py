import json
import os
import unittest

import _paths
from sramlab import analytic as A
from sramlab.model import Cfg, simulate


class TestAnalytic(unittest.TestCase):
    def test_peak(self):
        self.assertEqual(A.bank_peak_Bpc(4), 64)
        self.assertEqual(A.bank_peak_Bpc(8), 128)
        self.assertEqual(A.single_bank_ceiling_Bpc(), 16)

    def test_slot_ceiling_formula(self):
        self.assertAlmostEqual(A.slot_ceiling(2, 1), 2 / 3)
        self.assertEqual(A.slot_ceiling(8, 1), 1.0)
        self.assertEqual(A.min_nslot_for_full_rate(1), 3)
        self.assertEqual(A.min_nslot_for_full_rate(2), 4)          # contract: NSLOT >= BANK_LAT + 2

    def test_markov_matches_closed_form_for_ready_one(self):
        for ns in (2, 3, 4, 8):
            for bl in (1, 2, 3):
                self.assertAlmostEqual(A.slot_ceiling_markov(ns, bl, 1.0), A.slot_ceiling(ns, bl), places=6)

    def test_markov_bounded_by_p(self):
        for p in (0.1, 0.5, 0.8):
            for ns in (2, 4, 8):
                v = A.slot_ceiling_markov(ns, 1, p)
                self.assertLessEqual(v, p + 1e-9)
                self.assertGreater(v, 0)

    def test_hol_matches_karol(self):
        # Karol, Hluchyj, Morgan 1987: saturation throughput per output of an N x N FIFO input-queued switch
        for n, v in ((2, 0.75), (3, 0.6825), (4, 0.6553), (8, 0.6184)):
            self.assertAlmostEqual(A.hol_saturation(n, n) / n, v, delta=6e-4)

    def test_hol_below_balls_in_bins_and_bank_count(self):
        for nm, nb in ((4, 4), (4, 8), (8, 4), (2, 4), (8, 8)):
            self.assertLess(A.hol_saturation(nm, nb), A.balls_in_bins(nm, nb) + 1e-9)
            self.assertLessEqual(A.hol_saturation(nm, nb), min(nm, nb) + 1e-9)
        self.assertAlmostEqual(A.hol_saturation(1, 4), 1.0, places=9)
        self.assertAlmostEqual(A.hol_saturation(4, 1), 1.0, places=9)

    def test_ecc_penalty(self):
        p = A.ecc_rmw_penalty(1)
        self.assertEqual(p["occupancy_cycles"], 2)
        self.assertAlmostEqual(p["throughput_factor"], 0.5)
        self.assertAlmostEqual(A.ecc_rmw_penalty(2)["throughput_factor"], 1 / 3)
        self.assertAlmostEqual(A.ecc_rmw_penalty(2, 0.5)["throughput_factor"], 1 / 2)

    def test_zero_load_latency(self):
        self.assertEqual(A.zero_load_latency(1, 0), 3)
        self.assertEqual(A.zero_load_latency(1, 1), 4)
        self.assertEqual(A.zero_load_latency(1, 0, tb_convention=False), 2)

    def test_pattern_ceilings_ordering(self):
        c = lambda p, **k: A.pattern_ceiling(p, 4, 4, 8, 1, 0, **k)["useful_Bpc"]
        self.assertEqual(c(1), 64.0)
        self.assertEqual(c(2), 64.0)
        self.assertEqual(c(3), 16.0)
        self.assertLess(c(4), c(1))
        self.assertLess(c(4), A.balls_in_bins(4, 4) * 16 + 1e-9)
        self.assertEqual(A.pattern_ceiling(7, 4, 4, 8, 1, 1)["useful_Bpc"], 8.0)      # NB/(RL+1) = 2 acc/c x 4 B
        # offered load caps the ceiling
        self.assertAlmostEqual(A.pattern_ceiling(1, 4, 4, 8, 1, 0, load_pct=10)["useful_Bpc"], 4 * 0.1 * 16)

    def test_same_bank_latency_formula_matches_model(self):
        for arb in (1, 0):
            for rl, ecc in ((1, 0), (2, 0), (1, 1), (3, 1)):
                m = simulate(Cfg(pattern=3, arb=arb, read_latency=rl, ecc=ecc, nreq=400))
                lat = [s / m.per_master_done[i] for i, s in enumerate(m.per_master_lat_sum)]
                for a, b in zip(lat, A.same_bank_latency(4, rl, ecc, arb)):
                    self.assertAlmostEqual(a, b, delta=0.05, msg=(arb, rl, ecc))

    def test_scalar_ceiling(self):
        self.assertEqual(A.scalar_useful_ceiling_Bpc(4), 16)


@unittest.skipUnless(os.path.exists(_paths.BENCH_JSON), "reports/bench_rtl.json missing")
class TestCeilingsVsRtl(unittest.TestCase):
    def test_no_rtl_row_exceeds_its_ceiling(self):
        with open(_paths.BENCH_JSON) as fh:
            bench = json.load(fh)
        for r in bench["controller"]:
            cfg = Cfg.from_row(r)
            c = A.pattern_ceiling(cfg.pattern, cfg.nm, cfg.nb, cfg.nslot, cfg.read_latency, cfg.ecc, cfg.rsp_pct, cfg.load_pct, cfg.align_mode)
            # deterministic patterns: finite-run end effects allow <= 0.5 % overshoot; random patterns: the ceiling is an EXPECTATION and a
            # 1000-request sample fluctuates around it (std ~0.7 %), allow 3 %
            tol = 1.03 if cfg.pattern in (4, 5, 8) else 1.005
            self.assertLessEqual(r["throughput_Bpc"], c["useful_Bpc"] * tol + 0.05, (r["experiment"], r["config"], r["pattern"], r["rsp_pct"], r["load_pct"]))

    def test_long_run_random_matches_hol_chain(self):
        # Monte-Carlo of the cycle model (5000 requests / master, 3 seeds) converges to the exact head-of-line chain within 1 %
        vals = [simulate(Cfg(pattern=4, seed=s, nreq=5000)).throughput_Bpc for s in (11, 12, 13)]
        mean = sum(vals) / len(vals)
        self.assertAlmostEqual(mean / (16 * A.hol_saturation(4, 4)), 1.0, delta=0.01)

    def test_model_never_beats_markov_slot_ceiling(self):
        m = simulate(Cfg(nm=1, nb=4, pattern=1, nslot=2, rsp_pct=50, nreq=4000))
        self.assertLessEqual(4000 / m.cycles, A.slot_ceiling_markov(2, 1, 0.5) * 1.01)


if __name__ == "__main__":
    unittest.main()
