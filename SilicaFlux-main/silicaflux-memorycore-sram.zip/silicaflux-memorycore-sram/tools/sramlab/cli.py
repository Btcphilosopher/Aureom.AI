"""Command line interface:  python3 -m sramlab <cmd>   (run from the tools/ directory)

  validate     model vs the committed RTL benchmark rows (reports/bench_rtl.json); exit 1 on any mismatch
  model        run the cycle model for one configuration
  ceilings     analytical ceilings for one configuration
  tensor       tensor co-simulation vs the committed tensor rows
  starvation   operand-starvation table
  rtl-extra    build + run extra instrumented RTL simulations (controller + tensor), compare per edge, write reports/sramlab_rtl_extra.json
  report       write reports/sramlab_vs_rtl.{md,json,csv} and the SVG plots
  energy       run power/sram_energy.py (energy model, results, reports/sramlab_energy.md)
  all          rtl-extra (unless --no-rtl) + report + energy
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

from . import analytic as A
from . import traffic as T
from . import validate as V
from .model import Cfg, simulate

ROOT = V.ROOT


def _load_bench(path=None):
    b = V.load_bench(path or V.BENCH_JSON)
    if b is None:
        print(f"reports/bench_rtl.json not found at {path or V.BENCH_JSON}: run benchmarks/run_bench.py first", file=sys.stderr)
        sys.exit(2)
    return b


def cmd_validate(a):
    b = _load_bench(a.bench)
    vrows = V.validate_rows(b["controller"])
    s = V.summarize(vrows)
    print(f"MODEL vs RTL-SIMULATION: {s['exact_match_all_stats']}/{s['rows']} rows exact; per statistic: {s['rows_matching_per_stat']}")
    for r in vrows:
        if not r["match"]:
            print("MISMATCH", r["experiment"], r["config"], r["pattern"], r["diff"])
    return 0 if s["mismatch_rows"] == 0 else 1


def cmd_model(a):
    cfg = Cfg(nm=a.nm, nb=a.nb, depth=a.depth, read_latency=a.rl, ecc=a.ecc, nslot=a.nslot, arb=a.arb, pattern=a.pattern, nreq=a.nreq,
              rsp_pct=a.rsp, load_pct=a.load, seed=a.seed, align_mode=a.align)
    r = simulate(cfg)
    print(json.dumps({"pattern": T.PATTERN_NAMES[a.pattern], **r.row(), "per_bank_conf": r.per_bank_conf, "per_master_stall": r.per_master_stall}, indent=1))
    return 0


def cmd_ceilings(a):
    c = A.pattern_ceiling(a.pattern, a.nm, a.nb, a.nslot, a.rl, a.ecc, a.rsp, a.load, a.align)
    print(json.dumps({"pattern": T.PATTERN_NAMES[a.pattern], "bank_peak_Bpc": A.bank_peak_Bpc(a.nb), "per_master_acc_per_cycle": A.per_master_ceiling(a.nslot, a.rl + a.ecc, a.rsp),
                      "hol_acc_per_cycle": A.hol_saturation(a.nm, a.nb), **c}, indent=1))
    return 0


def cmd_tensor(a):
    from . import tensor as TN
    b = _load_bench(a.bench)
    bad = 0
    for r in b["tensor"]:
        cfg = TN.TCfg.from_row(r)
        cs = TN.cosim(cfg)
        ok = (cs["total_cycles"], cs["overlap_cycles"], cs["bank_conflict_cycles"], cs["bank_busy_stalls"]) == \
             (r["total_cycles"], r["overlap_cycles"], r["bank_conflict_cycles"], r["bank_busy_stalls"])
        bad += not ok
        sp = TN.steady_period(cfg)
        print(f"{r['config']:16s} RTL {r['total_cycles']:5d}/{r['cycles_per_tile']:4d} conf {r['bank_conflict_cycles']:4d} | MODEL {cs['total_cycles']:5d}/{cs['cycles_per_tile']:4d} "
              f"conf {cs['bank_conflict_cycles']:4d} | conflict-free steady {sp['cycles_per_tile']} ({sp['bound']}) | {'EXACT' if ok else 'DIFF'}")
    return 1 if bad else 0


def cmd_starvation(a):
    from . import report as R
    s = R.starvation_section()
    for p in s["points"]:
        if p["n"] == a.n:
            print(f"N={p['n']} beta=1/{p['dma_every']} compute={p['compute_cycles']:4d} analytic {p['analytic_frac']:.3f} model {p['model_frac']:.3f}")
    return 0


def cmd_rtl_extra(a):
    b = _load_bench()
    out = {"label": "RTL-SIMULATION (instrumented copies of the TBs in build/sramlab_work) compared with MODEL"}
    print("controller campaign ...")
    out["controller"] = V.extra_campaign(nreq=a.nreq, jobs=a.jobs, committed=b)
    print("tensor campaign ...")
    out["tensor"] = V.tensor_campaign(jobs=a.jobs, committed=b)
    path = os.path.join(ROOT, "reports", "sramlab_rtl_extra.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=1, default=str)
    c = out["controller"]
    print(f"controller: {c['exact_stats_trace_and_perf_counters']}/{c['runs']} exact; tensor: "
          f"{sum(1 for r in out['tensor']['rows'] if r['trace_identical'])}/{len(out['tensor']['rows'])} trace-identical; wrote {path}")
    return 0


def cmd_report(a):
    from . import report as R
    b = _load_bench(a.bench)
    extra = None
    if os.path.exists(R.EXTRA_JSON):
        with open(R.EXTRA_JSON) as fh:
            extra = json.load(fh)
    else:
        print("note: reports/sramlab_rtl_extra.json missing -> extra-RTL sections will say NOT RUN (run `rtl-extra`)")
    R.write_all(b, extra)
    return 0


def cmd_energy(a):
    return subprocess.call([sys.executable, os.path.join(ROOT, "power", "sram_energy.py")])


def cmd_all(a):
    if not a.no_rtl:
        cmd_rtl_extra(a)
    cmd_report(a)
    return cmd_energy(a)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="sramlab", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def cfgargs(p):
        p.add_argument("--nm", type=int, default=4); p.add_argument("--nb", type=int, default=4); p.add_argument("--depth", type=int, default=256)
        p.add_argument("--rl", type=int, default=1); p.add_argument("--ecc", type=int, default=0); p.add_argument("--nslot", type=int, default=8)
        p.add_argument("--arb", type=int, default=1); p.add_argument("--pattern", type=int, default=1); p.add_argument("--nreq", type=int, default=1000)
        p.add_argument("--rsp", type=int, default=100); p.add_argument("--load", type=int, default=100); p.add_argument("--seed", type=int, default=0x00C0FFEE)
        p.add_argument("--align", type=int, default=1)

    p = sub.add_parser("validate"); p.add_argument("--bench"); p.set_defaults(fn=cmd_validate)
    p = sub.add_parser("model"); cfgargs(p); p.set_defaults(fn=cmd_model)
    p = sub.add_parser("ceilings"); cfgargs(p); p.set_defaults(fn=cmd_ceilings)
    p = sub.add_parser("tensor"); p.add_argument("--bench"); p.set_defaults(fn=cmd_tensor)
    p = sub.add_parser("starvation"); p.add_argument("--n", type=int, default=8); p.set_defaults(fn=cmd_starvation)
    p = sub.add_parser("rtl-extra"); p.add_argument("--nreq", type=int, default=400); p.add_argument("--jobs", type=int, default=3); p.set_defaults(fn=cmd_rtl_extra)
    p = sub.add_parser("report"); p.add_argument("--bench"); p.set_defaults(fn=cmd_report)
    p = sub.add_parser("energy"); p.set_defaults(fn=cmd_energy)
    p = sub.add_parser("all"); p.add_argument("--no-rtl", action="store_true"); p.add_argument("--nreq", type=int, default=400); p.add_argument("--jobs", type=int, default=3)
    p.add_argument("--bench"); p.set_defaults(fn=cmd_all)
    a = ap.parse_args(argv)
    return a.fn(a)
