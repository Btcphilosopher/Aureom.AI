"""Cycle model of the tensor scratchpad pipeline (tb/tb_tensor_scratchpad.sv + rtl/sf_tensor_scratchpad.sv) and the
operand-starvation model.  MODEL, not measurement.

Layer 1  `cosim`  : cycle-level co-simulation.  The memory side is the exact controller/bank model of model.Ctrl (4 ports:
                    A, B, C, DMA).  The scratchpad ownership FSM (rtl/sf_tensor_scratchpad.sv) is transcribed.  The TB side
                    (three concurrent processes fill / compute / drain, the per-port stimulus queues and response counters,
                    the half-cycle negedge handshakes) is transcribed from tb_tensor_scratchpad.sv as small generators.
Layer 2  `phase_model` / `pipeline_period` : closed-form per-tile fill / compute / drain times and the steady-state
                    cycles-per-tile recurrence for single (NBUF=1) and double (NBUF=2) buffering.
Layer 3  `starvation`   : fraction of TensorCore compute-side time lost waiting for operands, as a function of DMA bandwidth
                    share, tile size and compute time per tile.

Scheduling convention of the TB (resolved ONCE, from the instrumented RTL traces, not per row): at every posedge the DUT flops
evaluate first (they see the TB variables as they were after the previous time step), then the TB processes run (in source order
fill, compute, drain; they see DUT outputs BEFORE the edge's non-blocking updates and the response counters BEFORE this edge's
responses), then the driver/collector block of the TB (it sees queue pushes made by the processes in the same edge); negedge steps
run between edges.  See README/report for the evidence (sramlab_vs_rtl.md, section tensor).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from .model import Ctrl

FREE, FILLING, READY, COMPUTE, DONE, DRAINING = range(6)


@dataclass(frozen=True)
class TCfg:
    nbuf: int = 2
    nb: int = 4
    depth: int = 64
    n: int = 8                 # lines per tile (A, B, C each)
    skew: int = 1
    read_latency: int = 1
    ecc: int = 0
    nslot: int = 8
    ntiles: int = 8
    passes: int = 3
    compute_extra: int = 0

    @classmethod
    def from_row(cls, r: dict) -> "TCfg":
        return cls(nbuf=r["nbuf"], nb=r["nb"], n=r["n"], skew=r["skew"], read_latency=r["read_latency"], ecc=r["ecc"],
                   ntiles=r["tiles"], passes=r["passes"], compute_extra=r["compute_extra"])

    @property
    def bank_lat(self):
        return self.read_latency + (1 if self.ecc else 0)

    def layout(self):
        al = lambda x: ((x + self.nb - 1) // self.nb) * self.nb
        strd = al(self.n)
        a_off = 0
        b_off = al(a_off + self.nbuf * strd) + ((1 % self.nb) if self.skew else 0)
        c_off = al(b_off + self.nbuf * strd) + ((2 % self.nb) if self.skew else 0)
        return {"A": (a_off, strd), "B": (b_off, strd), "C": (c_off, strd), "foot": c_off + self.nbuf * strd}


class _W:
    """Mutable world of the co-simulation."""


def cosim(cfg: TCfg, trace: bool = False, rr_init=None, ptr_init: int | None = None, max_edges: int = 200_000,
          end_offset: int = 5, dma_issue_every: int = 1) -> dict:
    NB, NBUF, N = cfg.nb, cfg.nbuf, cfg.n
    lay = cfg.layout()
    ctl = Ctrl(4, NB, cfg.nslot, cfg.read_latency, cfg.ecc, 1)
    if rr_init is not None:
        ctl.rr = list(rr_init)
    ptr0 = (1 % NBUF) if ptr_init is None else ptr_init        # ring pointers after the TB's negative tests (one tile through buffer 0)
    w = _W()
    # ---- DUT scratchpad registers
    w.bst = [FREE] * NBUF
    w.fill_ptr = w.comp_ptr = w.drain_ptr = ptr0
    w.fill_v = w.te_v = w.drain_v = 0
    w.fill_b = w.te_b = w.drain_b = 0
    w.fill_pend = w.te_pend = w.drain_pend = 0
    w.dwr = w.drd = 0
    # ---- TB variables
    w.fill_req = w.fill_done = w.te_req = w.te_done = w.drain_req = w.drain_done = 0
    w.q = [deque(), deque(), deque(), deque()]          # per-port stimulus queues (entries: (line, we))
    w.valid = [None, None, None, None]                  # driver registers: None or (line, we)
    w.cnt = [0, 0, 0, 0]                                # a_n, b_n, c_n, d_n
    w.dma_lock = 0
    w.done = [0, 0, 0]
    w.done_time = None
    w.events = []                                       # (edge, tag)
    w.te_wait_cycles = 0
    w.ovl = 0
    w.edge = 0
    w.comp_idx = 0                                      # compute tile currently being waited for / computed
    w.te_wait_by_tile = [0] * cfg.ntiles
    w.comp_start_edge = [None] * cfg.ntiles
    tr = [] if trace else None

    def line_te(port, row):
        off, strd = lay["ABC"[port]]
        return off + w.te_b * strd + row

    def line_dma(region, buf, ln):
        off, strd = lay["ABC"[region]]
        return off + buf * strd + ln

    # ---------------- TB processes (generators yielding "P" = next posedge, "N" = next negedge) ----------------
    def dma_batch(items, cnt):
        while w.dma_lock:
            yield "P"
        w.dma_lock = 1
        w.cnt[3] = 0
        for it in items:
            w.q[3].append(it)
        while w.cnt[3] < cnt:
            yield "P"
        w.dma_lock = 0

    def p_fill():
        for t in range(cfg.ntiles):
            w.fill_req = 1
            while not w.fill_v:
                yield "P"
            w.fill_req = 0
            buf = w.fill_b
            items = []
            for k in range(N):
                for reg in (0, 1, 2):
                    items.append((line_dma(reg, buf, k), True))
            w.events.append(("fill_start", t))
            yield from dma_batch(items, 3 * N)
            w.events.append(("fill_batch_done", t))
            yield "N"
            w.fill_done = 1
            yield "N"
            w.fill_done = 0
            while w.fill_v:
                yield "P"
        w.done[0] = 1

    def te_wait(na, nb_, nc):
        while w.cnt[0] < na or w.cnt[1] < nb_ or w.cnt[2] < nc:
            yield "P"

    def p_comp():
        for t in range(cfg.ntiles):
            w.te_req = 1
            t_req = None
            while not w.te_v:
                yield "P"
            w.te_req = 0
            w.comp_start_edge[t] = w.edge
            w.events.append(("comp_start", t))
            for p in range(cfg.passes):
                w.cnt[0] = w.cnt[1] = w.cnt[2] = 0
                for k in range(N):
                    w.q[0].append((("te", 0, k), False))
                    w.q[1].append((("te", 1, k), False))
                    w.q[2].append((("te", 2, k), False))
                yield from te_wait(N, N, N)
                for _ in range(cfg.compute_extra):
                    yield "P"
                for k in range(N):
                    w.q[2].append((("te", 2, k), True))
                yield from te_wait(N, N, 2 * N)
            w.events.append(("comp_batch_done", t))
            yield "N"
            w.te_done = 1
            yield "N"
            w.te_done = 0
            while w.te_v:
                yield "P"
            w.comp_idx = t + 1
        w.done[1] = 1

    def p_drain():
        for t in range(cfg.ntiles):
            w.drain_req = 1
            while not w.drain_v:
                yield "P"
            w.drain_req = 0
            buf = w.drain_b
            w.events.append(("drain_start", t))
            yield from dma_batch([(line_dma(2, buf, k), False) for k in range(N)], N)
            w.events.append(("drain_batch_done", t))
            yield "N"
            w.drain_done = 1
            yield "N"
            w.drain_done = 0
            while w.drain_v:
                yield "P"
        w.done[2] = 1

    procs = [p_fill(), p_comp(), p_drain()]
    # Event-queue model of the three TB processes: a process that waits for a posedge (negedge) is appended to the posedge
    # (negedge) queue at the moment it goes to sleep; at an edge the queue is resumed in FIFO order.  Posedge waiters that went to
    # sleep in the posedge phase of the previous edge therefore run before those that went to sleep in its negedge phase.
    pq = [0, 1, 2]            # initial blocks wait for run_pipe and are released in source order (fill, compute, drain)
    nq: list[int] = []
    done_flag = [False, False, False]

    def resume(i):
        try:
            k = next(procs[i])
        except StopIteration:
            done_flag[i] = True
            return
        (pq if k == "P" else nq).append(i)

    def run_phase(kind):
        nonlocal pq, nq
        if kind == "P":
            order, pq = pq, []
        else:
            order, nq = nq, []
        for i in order:
            resume(i)

    # ---------------- edge loop ----------------
    e = 0
    while True:
        if e > max_edges:
            raise RuntimeError("tensor cosim: no completion")
        w.edge = e
        # ===== DUT flops (pre-edge view) =====
        reqs = [None] * 4
        for m in range(4):
            if w.valid[m] is not None:
                line, we = w.valid[m]
                if m < 3:
                    ln = line_te(m, line[2]) if isinstance(line, tuple) else line
                else:
                    ln = line
                reqs[m] = (0, ln % NB, we, False, we)
        out_pre = [len(ctl.q[m]) for m in range(3)]
        acc_b0 = list(ctl.acc_b)
        accepted, popped = ctl.step(e, reqs, [True] * 4, None)
        ba_mask = sum((1 << b) for b in range(NB) if ctl.acc_b[b] != acc_b0[b])
        d_acc = accepted[3]
        d_we = bool(w.valid[3] and w.valid[3][1])
        d_wr_acc = d_acc and d_we
        d_rd_acc = d_acc and not d_we
        te_idle = all(o == 0 for o in out_pre)
        fill_fin = w.fill_v and (w.fill_done or w.fill_pend) and w.dwr == 0 and not d_wr_acc
        te_fin = w.te_v and (w.te_done or w.te_pend) and te_idle and not (accepted[0] or accepted[1] or accepted[2])
        drain_fin = w.drain_v and (w.drain_done or w.drain_pend) and w.drd == 0 and not d_rd_acc
        n_bst = list(w.bst)
        nx = {k: getattr(w, k) for k in ("fill_ptr", "comp_ptr", "drain_ptr", "fill_v", "te_v", "drain_v", "fill_b", "te_b", "drain_b",
                                         "fill_pend", "te_pend", "drain_pend")}
        if w.fill_req and not w.fill_v and w.bst[w.fill_ptr] == FREE:
            n_bst[w.fill_ptr] = FILLING
            nx["fill_v"], nx["fill_b"] = 1, w.fill_ptr
        if w.te_req and not w.te_v and w.bst[w.comp_ptr] == READY:
            n_bst[w.comp_ptr] = COMPUTE
            nx["te_v"], nx["te_b"] = 1, w.comp_ptr
        if w.drain_req and not w.drain_v and w.bst[w.drain_ptr] == DONE:
            n_bst[w.drain_ptr] = DRAINING
            nx["drain_v"], nx["drain_b"] = 1, w.drain_ptr
        if w.fill_v and w.fill_done and not fill_fin:
            nx["fill_pend"] = 1
        if w.te_v and w.te_done and not te_fin:
            nx["te_pend"] = 1
        if w.drain_v and w.drain_done and not drain_fin:
            nx["drain_pend"] = 1
        if fill_fin:
            n_bst[w.fill_b] = READY
            nx["fill_v"], nx["fill_pend"] = 0, 0
            nx["fill_ptr"] = 0 if w.fill_ptr == NBUF - 1 else w.fill_ptr + 1
        if te_fin:
            n_bst[w.te_b] = DONE
            nx["te_v"], nx["te_pend"] = 0, 0
            nx["comp_ptr"] = 0 if w.comp_ptr == NBUF - 1 else w.comp_ptr + 1
        if drain_fin:
            n_bst[w.drain_b] = FREE
            nx["drain_v"], nx["drain_pend"] = 0, 0
            nx["drain_ptr"] = 0 if w.drain_ptr == NBUF - 1 else w.drain_ptr + 1
        d_pop = popped[3]
        # response of the DMA port carries the request's we flag as payload (True/False)
        d_wr_fin = d_pop is not None and d_pop is True
        d_rd_fin = d_pop is not None and d_pop is False
        n_dwr = w.dwr + (1 if d_wr_acc else 0) - (1 if d_wr_fin else 0)
        n_drd = w.drd + (1 if d_rd_acc else 0) - (1 if d_rd_fin else 0)
        # monitors (pre-edge buf_state)
        if NBUF > 1 and COMPUTE in w.bst and (FILLING in w.bst or DRAINING in w.bst):
            w.ovl += 1
        # ===== TB processes (posedge phase): see PRE-edge DUT regs (w.* not yet committed) =====
        run_phase("P")
        # ===== TB driver / collector =====
        for m in range(4):
            was_valid = w.valid[m] is not None
            if accepted[m]:
                w.valid[m] = None
            if (not was_valid or accepted[m]) and w.q[m] and (m != 3 or dma_issue_every <= 1 or e % dma_issue_every == 0):
                w.valid[m] = w.q[m].popleft()
            if popped[m] is not None:
                w.cnt[m] += 1
        if w.te_req and not w.te_v and e >= 1:           # edge 0 is not part of the RTL trace (run_pipe is set during it)
            w.te_wait_cycles += 1
            if w.comp_idx < cfg.ntiles:
                w.te_wait_by_tile[w.comp_idx] += 1                       # TensorCore ready but no READY tile (operand starvation + handshake)
        if tr is not None:
            ctl9_pre = (w.fill_req | (w.fill_v << 1) | (w.fill_done << 2) | (w.te_req << 3) | (w.te_v << 4) | (w.te_done << 5) |
                        (w.drain_req << 6) | (w.drain_v << 7) | (w.drain_done << 8))
            bs_pre = sum(w.bst[i] << (3 * i) for i in range(NBUF))
        # ===== commit non-blocking updates =====
        w.bst = n_bst
        for k, v in nx.items():
            setattr(w, k, v)
        w.dwr, w.drd = n_dwr, n_drd
        if tr is not None:
            am = sum(1 << m for m in range(4) if accepted[m])
            pm = sum(1 << m for m in range(4) if popped[m] is not None)
            tr.append((e, am, pm, ba_mask, ctl9_pre, am, pm, bs_pre))
        # ===== negedge phase (time e + 0.5) =====
        run_phase("N")
        if all(w.done) and w.done_time is None:
            w.done_time = e
            break
        e += 1
    e_end = w.done_time + end_offset
    return {"cycles": e_end, "total_cycles": e_end, "cycles_per_tile": e_end // cfg.ntiles, "overlap_cycles": w.ovl,
            "bank_conflict_cycles": sum(ctl.conf), "bank_busy_stalls": sum(ctl.busy), "events": w.events, "ctl": ctl, "trace": tr,
            "done_edge": w.done_time, "te_wait_cycles": w.te_wait_cycles, "te_wait_by_tile": list(w.te_wait_by_tile), "comp_start_edge": list(w.comp_start_edge), "dma_accepts": ctl.acc_b and sum(ctl.grants_m[3]),
            "te_accepts": [sum(ctl.grants_m[m]) for m in range(3)], "dma_stall": ctl.stall[3], "per_port_stall": list(ctl.stall),
            "per_bank_conf": list(ctl.conf)}


# =====================================================================================================================
# Layer 2: phase model (closed forms) and the conflict-free pipeline recurrence
# =====================================================================================================================
GAP = 3     # edges between the end of one ownership phase and the first request of the next owner (derived below)


def phase_times(cfg: TCfg) -> dict:
    """Conflict-free durations in clock edges, measured from the edge where the process pushes its requests to the edge where it
    observes the last response (derivation in the module docstring / report):
      fill  : 3N requests on the single DMA port, one per cycle, last response BL+1 after the last acceptance, seen one edge later
              Df = 3N + BL + 2
      drain : Dd = N + BL + 2
      compute (one pass): N reads on A, B, C in parallel (BL+2 latency) then N C-writes: 2 (N + BL + 2) + COMPUTE_EXTRA ;  Dc = passes x that
      GAP = 3: request -> flop grant (1 edge) -> visible -> process pushes (1 edge) ; done pulse -> fin -> buffer state visible -> next grant.
    """
    n, bl = cfg.n, cfg.bank_lat
    df = 3 * n + bl + 2
    dd = n + bl + 2
    dpass = 2 * (n + bl + 2) + cfg.compute_extra
    return {"Df": df, "Dd": dd, "Dpass": dpass, "Dc": cfg.passes * dpass, "gap": GAP,
            "single_buffer_cycles_per_tile": df + cfg.passes * dpass + dd + 3 * GAP}


def phase_pipeline(cfg: TCfg) -> dict:
    """Conflict-free pipeline recurrence on the ownership protocol (atomic phases, DMA port shared by fill and drain).
    Returns total cycles (TB convention: last-done edge + 5), cycles per tile and the TensorCore operand-wait cycles
    (te_req high, no READY tile).  Exact for NBUF = 1 when the memory is conflict free; for NBUF = 2 it is the conflict-free
    LOWER bound of the RTL (bank conflicts between the DMA and the TensorCore ports add to the compute time)."""
    ph = phase_times(cfg)
    Df, Dc, Dd = ph["Df"], ph["Dc"], ph["Dd"]
    T, NBUF = cfg.ntiles, cfg.nbuf
    fill_det, comp_det, drain_det = [None] * T, [None] * T, [None] * T
    lock_free, lock_by = 0, None       # edge from which the DMA lock is free, and who released it ('f' or 'd')
    t_f = t_d = 0                      # next tile for fill / drain
    t_c = 0
    te_wait = 0
    comp_req_t = 1                     # edge from which te_req is high (set at edge 0, seen by the DUT at 1)
    # tile loop in dependency order (fill(t), comp(t), drain(t) interleave on the DMA port)
    fill_ready = [None] * T            # earliest flop-grant edge of fill(t)
    pending = []
    # iterate: process DMA batches in the order they can start
    done_f = done_d = 0
    while done_f < T or done_d < T:
        # candidate fill(t_f)
        cands = []
        if t_f < T:
            g_prev = 1 if t_f == 0 else fill_det[t_f - 1] + 2
            g_free = 0 if t_f < NBUF else (drain_det[t_f - NBUF] + 2 if drain_det[t_f - NBUF] is not None else None)
            if g_free is not None:
                G = max(g_prev, g_free)
                ready = G + 1
                start = max(ready, lock_free + (1 if lock_by == "d" else 0))
                cands.append((start, 0, "f"))
        if t_d < T and comp_det[t_d] is not None:
            g_prev = 1 if t_d == 0 else drain_det[t_d - 1] + 2
            G = max(g_prev, comp_det[t_d] + 2)
            ready = G + 1
            start = max(ready, lock_free + (0 if lock_by == "f" else 0))
            cands.append((start, 1, "d"))
        # compute can be advanced whenever its fill is done
        progressed = False
        if t_c < T and fill_det[t_c] is not None:
            g_prev = 1 if t_c == 0 else comp_det[t_c - 1] + 2
            G = max(g_prev, fill_det[t_c] + 2)
            push = G + 1
            te_wait += max(0, G - g_prev)               # edges te_req high without a READY buffer (beyond the minimum)
            comp_det[t_c] = push + Dc
            t_c += 1
            progressed = True
        if not cands:
            if not progressed:
                raise RuntimeError("phase_pipeline deadlock")
            continue
        cands.sort()
        start, _, who = cands[0]
        if who == "f":
            fill_det[t_f] = start + Df
            lock_free, lock_by = fill_det[t_f], "f"
            t_f += 1
            done_f += 1
        else:
            drain_det[t_d] = start + Dd
            lock_free, lock_by = drain_det[t_d], "d"
            t_d += 1
            done_d += 1
    last = max(drain_det[-1], fill_det[-1], comp_det[-1]) + 1      # the last done pulse (negedge handshake) ends one edge later
    total = last + 5
    return {"total_cycles": total, "cycles_per_tile": total // T, "phases": ph, "fill_det": fill_det, "comp_det": comp_det,
            "drain_det": drain_det, "te_wait_extra": te_wait}


def steady_period(cfg: TCfg) -> dict:
    """Steady-state cycles per tile (conflict-free): NBUF = 1: sum of all phases + 3 GAP ; NBUF = 2: the slower of the TensorCore
    ring (Dc + GAP) and the DMA port (Df + Dd + 2 GAP + lock hand-off), i.e. compute bound or DMA bound."""
    ph = phase_times(cfg)
    if cfg.nbuf == 1:
        per = ph["single_buffer_cycles_per_tile"]
        bound = "serial"
    else:
        te = ph["Dc"] + GAP
        dma = ph["Df"] + ph["Dd"] + 2 * GAP
        per = max(te, dma)
        bound = "compute" if te >= dma else "DMA"
    return {"cycles_per_tile": per, "bound": bound, **ph}


# =====================================================================================================================
# Layer 3: operand starvation
# =====================================================================================================================
def starvation(n_lines: int, compute_cycles: float, dma_lines_per_cycle: float, nbuf: int = 2, bank_lat: int = 1,
               gap: int = GAP) -> dict:
    """TensorCore operand starvation, ANALYTICAL (steady state, no bank conflicts).

    n_lines              lines per operand tile (A, B, C each); one tile needs 3N fill writes + N drain reads on the single DMA port
    compute_cycles       TensorCore busy time per tile (the compute phase, PASSES x pass time)
    dma_lines_per_cycle  sustained DMA beat rate beta (<= 1 for the single DMA port; = DMA bandwidth share x bank bandwidth if the banks are the limit)
    DMA batch time (last request issued (3N-1)/beta after the first, + BANK_LAT + 3 until the process sees the last response):
        t_fill = (3N-1)/beta + BL + 3 ,  t_drain = (N-1)/beta + BL + 3        (beta = 1: 3N+BL+2 and N+BL+2, the conflict-free phase times)
    NBUF = 2 (prefetch of tile t+1 and drain of tile t-1 run during compute of tile t, sharing the DMA port, +1 cycle lock hand-off):
        t_dma = t_fill + t_drain + 1 ;  period = max(T_c + gap, t_dma) ;  stall = max(0, t_dma - T_c - gap)
    NBUF = 1 (nothing overlaps): stall = t_fill + t_drain + 3 gap ; period = T_c + stall
    starved fraction = stall / period  (share of wall time the TensorCore waits for operands beyond the minimum ownership handshake)
    """
    beta = max(dma_lines_per_cycle, 1e-9)
    t_fill = (3 * n_lines - 1) / beta + bank_lat + 3
    t_drain = (n_lines - 1) / beta + bank_lat + 3
    if nbuf == 1:
        stall = t_fill + t_drain + 3 * gap
        period = compute_cycles + stall
    else:
        t_dma = t_fill + t_drain + 1
        period = max(compute_cycles + gap, t_dma)
        stall = max(0.0, t_dma - compute_cycles - gap)
    return {"t_fill": t_fill, "t_drain": t_drain, "t_dma": t_fill + t_drain + 1, "period": period, "stall_per_tile": stall,
            "starved_fraction": stall / period if period else 0.0,
            "stall_per_compute_cycle": stall / compute_cycles if compute_cycles else float("inf")}


def min_beta_for_hidden_prefetch(n_lines: int, compute_cycles: float, bank_lat: int = 1, gap: int = GAP) -> float:
    """Smallest DMA beat rate for which the NBUF = 2 prefetch is fully hidden:  (4N-2)/beta + 2 (BL+3) + 1 <= T_c + gap."""
    room = compute_cycles + gap - 2 * (bank_lat + 3) - 1
    return (4 * n_lines - 2) / room if room > 0 else float("inf")
