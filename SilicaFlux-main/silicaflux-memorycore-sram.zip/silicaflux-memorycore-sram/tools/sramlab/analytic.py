"""ANALYTICAL bandwidth ceilings and expectations (closed forms and small exact Markov chains).

All numbers returned here are ANALYTICAL (not RTL, not the cycle model).  Every function states its formula and
where it is exact or approximate.  Units: accesses/cycle (acc/c) or useful bytes/cycle (B/c); one access = one
DW/8 = 16 B line access of one bank.

Notation  NM masters, NB banks, NSLOT reorder slots / master, RL = READ_LATENCY, ECC in {0,1},
          BL = RL + ECC (BANK_LAT), TB-visible zero-load latency = BL + 2 (see model.py).

Formulas
  F1  bank peak           NB x 16 B/c                (one access per bank per cycle, line = DW/8 bytes)
  F2  master slot ceiling min(1, NSLOT/(BL+2)) acc/c (a slot is busy from acceptance edge e to the pop edge e+BL+1 and the
                           registered `cnt` frees it for acceptance at e+BL+2: round trip BL+2)           [exact, rsp_ready = 1]
  F2b with a Bernoulli(p) response-ready: exact stationary solution of a small Markov chain (`slot_ceiling_markov`)
  F3  single-bank ceiling 1 acc/c = 16 B/c
  F4  random uniform destinations, NM masters that keep their HEAD request until accepted (head-of-line blocking):
        stationary accesses/cycle of the occupancy chain (`hol_saturation`), exact for saturated masters, unlimited
        slots, iid uniform destinations.  Does not depend on the tie-break policy (RR / fixed / random) because losers
        are indistinguishable by destination.  For NM = NB = 2,4,8 it gives 0.75, 0.6553, 0.6184 per bank (Karol et al. 1987).
        The no-HOL bound (balls into bins) NB (1 - (1-1/NB)^NM) is an UPPER bound.
  F5  ECC partial write: occupies its bank RL+1 cycles (bank not ready for RL cycles after the accepting edge)
        => stream of partial writes: bank ceiling 1/(RL+1) acc/c per bank.  Mixed streams: NB / (1 + f_part * RL) is an
        upper bound of the bank service rate (APPROXIMATE for random traffic because of HOL coupling).
  F6  offered load L (TB LOAD_PCT): a master presents a request with probability L per idle cycle => offered rate L
        acc/c/master until saturation: ceiling(L) = min(NM L, saturation ceiling)  [asymptote; queueing smooths the knee]
"""
from __future__ import annotations

import itertools
import math
from functools import lru_cache

import numpy as np

LINE_BYTES = 16


# ------------------------------------------------------------------------------------------------ basic ceilings
def bank_peak_Bpc(nb: int, line_bytes: int = LINE_BYTES) -> float:
    """F1: NB x 16 B/cycle."""
    return nb * line_bytes


def slot_ceiling(nslot: int, bank_lat: int) -> float:
    """F2 (accesses/cycle/master): min(1, NSLOT/(BL+2))."""
    return min(1.0, nslot / (bank_lat + 2))


def min_nslot_for_full_rate(bank_lat: int) -> int:
    """NSLOT needed for one access per cycle per master (contract: BL + 2)."""
    return bank_lat + 2


@lru_cache(maxsize=None)
def slot_ceiling_markov(nslot: int, bank_lat: int, p_ready: float = 1.0) -> float:
    """F2b: exact accepted accesses/cycle of ONE saturated, conflict-free master with Bernoulli(p_ready) rsp_ready.

    State (pre-edge) = (r, bits): r entries already poppable (they are the oldest), bits[i] = an entry accepted i+1 edges ago that is
    not yet poppable (an entry accepted at edge a is poppable from edge a+BL+1).  Per edge: accept if r+popcount(bits) < NSLOT,
    pop with prob p when r >= 1.  Throughput = P(accept) = pop rate.  Exact for the single-master, conflict-free case; the
    4-master benchmark on SEQ_LINE is conflict free in steady state (masters self-skew by one bank), so it is a tight reference there.
    """
    BL = bank_lat
    mask = (1 << BL) - 1
    states = [(r, b) for r in range(nslot + 1) for b in range(1 << BL) if r + bin(b).count("1") <= nslot]
    idx = {s: i for i, s in enumerate(states)}
    n = len(states)
    P = np.zeros((n, n))
    acc = np.zeros(n)
    for (r, b), i in idx.items():
        cnt = r + bin(b).count("1")
        a = 1 if cnt < nslot else 0
        acc[i] = a
        oldest = (b >> (BL - 1)) & 1
        for pop, pp in (((1, p_ready), (0, 1 - p_ready)) if r >= 1 else ((0, 1.0),)):
            if pp == 0:
                continue
            r2 = r - pop + oldest
            b2 = ((b << 1) & mask) | a
            P[i, idx[(r2, b2)]] += pp
    # stationary distribution
    A = np.vstack([(P.T - np.eye(n)), np.ones(n)])
    rhs = np.zeros(n + 1)
    rhs[-1] = 1.0
    pi, *_ = np.linalg.lstsq(A, rhs, rcond=None)
    return float(pi @ acc)


def per_master_ceiling(nslot: int, bank_lat: int, rsp_pct: int = 100) -> float:
    """Per master accesses/cycle ceiling: F2 for rsp_ready = 1, F2b (exact Markov) otherwise; never above rsp_pct/100."""
    p = rsp_pct / 100.0
    if rsp_pct >= 100:
        return slot_ceiling(nslot, bank_lat)
    return min(p, slot_ceiling_markov(nslot, bank_lat, p))


# ------------------------------------------------------------------------------------------------ head-of-line chain
def _partitions(n: int, k: int):
    """non-increasing tuples of length k with sum n."""
    def rec(rem, parts_left, maxv):
        if parts_left == 0:
            if rem == 0:
                yield ()
            return
        for v in range(min(rem, maxv), -1, -1):
            for rest in rec(rem - v, parts_left - 1, v):
                yield (v,) + rest
    return list(rec(n, k, n))


def _compositions(total: int, k: int):
    if k == 1:
        yield (total,)
        return
    for v in range(total + 1):
        for rest in _compositions(total - v, k - 1):
            yield (v,) + rest


@lru_cache(maxsize=None)
def hol_saturation(nm: int, nb: int) -> float:
    """F4: stationary accesses/cycle of NM saturated masters with iid uniform destinations over NB banks, head-of-line blocking.
    Chain over the multiset of head destinations (partitions of NM into NB parts); a bank serves one head per cycle and
    the served master draws a new uniform destination."""
    states = _partitions(nm, nb)
    idx = {s: i for i, s in enumerate(states)}
    n = len(states)
    P = np.zeros((n, n))
    served = np.zeros(n)
    fact = [math.factorial(i) for i in range(nm + 2)]
    for s, i in idx.items():
        after = [max(c - 1, 0) for c in s]
        k = sum(1 for c in s if c > 0)
        served[i] = k
        if k == 0:
            P[i, i] = 1.0
            continue
        for comp in _compositions(k, nb):
            prob = fact[k]
            for m in comp:
                prob /= fact[m]
            prob *= (1.0 / nb) ** k
            new = tuple(sorted((a + m for a, m in zip(after, comp)), reverse=True))
            P[i, idx[new]] += prob
    A = np.vstack([(P.T - np.eye(n)), np.ones(n)])
    rhs = np.zeros(n + 1)
    rhs[-1] = 1.0
    pi, *_ = np.linalg.lstsq(A, rhs, rcond=None)
    return float(pi @ served)


def balls_in_bins(nm: int, nb: int) -> float:
    """Upper bound without HOL persistence: expected number of distinct banks hit by NM independent uniform requests."""
    return nb * (1.0 - (1.0 - 1.0 / nb) ** nm)


# ------------------------------------------------------------------------------------------------ pattern ceilings
def pattern_ceiling(pattern: int, nm: int, nb: int, nslot: int, read_latency: int, ecc: int,
                    rsp_pct: int = 100, load_pct: int = 100, align_mode: int = 1) -> dict:
    """ANALYTICAL ceiling of the benchmark patterns, in accesses/cycle and TB-useful bytes/cycle.

    Returns {acc_per_cycle, useful_Bpc, formula, exact} ; `exact` False when the formula is an approximation / bound."""
    bl = read_latency + (1 if ecc else 0)
    pm = per_master_ceiling(nslot, bl, rsp_pct)           # per-master port/slot ceiling
    port = nm * pm
    f_part = {7: 1.0, 8: 0.5}.get(pattern, 0.0) if ecc else 0.0
    useful = {0: 4, 1: 16, 2: 16, 3: 16, 4: 16, 5: 16, 6: 16, 7: 4, 8: 4, 9: 4}[pattern]
    formula = ""
    exact = True
    estimate = None
    if pattern == 9 and align_mode:
        # model-only byte-stride pattern: 3 of 4 requests are SF_ST_ALIGN errors (no bank access): limited by the master port / slot loop only.
        # An error is answered one edge after acceptance: round trip 2 edges -> NSLOT/2, but in-order release behind
        # real accesses makes the effective bound the port rate.
        acc = nm * min(1.0, rsp_pct / 100.0)
        formula = "ALIGN errors bypass the banks: NM x min(1, rsp_pct) acc/c (TB 'useful' accounting; only 1/4 of requests touch an array)"
        exact = False
    elif pattern in (1, 6):
        acc = min(port, nb * _rmw_rate(ecc, read_latency, f_part))
        formula = "conflict-free steady state (masters self-skew by one bank): min(NM x slot ceiling, NB x bank rate)"
    elif pattern == 2:
        acc = min(port, nb * _rmw_rate(ecc, read_latency, f_part), nb)
        formula = "master m -> bank m mod NB: min(NM x slot ceiling, NB x bank rate)"
    elif pattern == 3:
        acc = min(port, 1.0 * _rmw_rate(ecc, read_latency, f_part))
        formula = "all masters on one bank: 1 acc/c x bank rate (F3)"
    elif pattern == 7:
        acc = min(port, nb * _rmw_rate(ecc, read_latency, f_part))
        formula = "partial writes: NB x 1/(RL+1) with ECC (F5), else conflict-free like pattern 1"
    elif pattern in (0, 9):                                    # scalar loads as intended (line-aligned, or ALIGN_MODE = 0)
        acc = min(port, float(nb))
        formula = "scalar 4 B loads through whole-line accesses: each access = 1 bank cycle; bound NB acc/c = 16 B/c (25% of line peak)"
        exact = False
    else:                                                      # 4, 5, 8 : random destinations
        hol = hol_saturation(nm, nb)
        if f_part:
            # upper bound = the smaller of the two independent limits (HOL chain, bank service rate); the product HOL x 1/(1+f RL) is only
            # an ESTIMATE (it is not a bound: RMW busy time partly hides the head-of-line loss)
            acc = min(port, hol, nb * _rmw_rate(ecc, read_latency, f_part))
            estimate = min(port, hol * _rmw_rate(ecc, read_latency, f_part))
            formula = "upper bound = min(HOL chain F4, NB/(1+f RL) F5); the product HOL/(1+f RL) is an approximate estimate"
            exact = False
        else:
            acc = min(port, hol)
            formula = "head-of-line Markov chain (F4), exact for iid destinations"
    off = nm * load_pct / 100.0
    acc_sat = acc
    if load_pct < 100:
        acc = min(acc, off)
        formula += f"; offered load NM x L = {off:.2f} acc/c (F6)"
    est_acc = estimate if estimate is not None else acc
    if load_pct < 100:
        est_acc = min(est_acc, off)
    return {"acc_per_cycle": acc, "acc_saturated": acc_sat, "useful_Bpc": acc * useful, "estimate_useful_Bpc": est_acc * useful, "formula": formula, "exact": exact}


def _rmw_rate(ecc: int, rl: int, f_part: float) -> float:
    """Bank service rate factor (accesses/cycle/bank) under a fraction f_part of RMW partial writes: 1/(1 + f RL) (F5)."""
    return 1.0 / (1.0 + f_part * rl) if ecc else 1.0


def ecc_rmw_penalty(read_latency: int, f_partial: float = 1.0) -> dict:
    """F5: bank occupancy of a partial write = RL+1 cycles; extra bank cycles per partial write = RL; the throughput factor of a
    stream with partial-write fraction f is 1/(1 + f RL)."""
    return {"occupancy_cycles": read_latency + 1, "extra_cycles_per_partial": read_latency,
            "throughput_factor": 1.0 / (1.0 + f_partial * read_latency)}


def zero_load_latency(read_latency: int, ecc: int, tb_convention: bool = True) -> int:
    """Presentation edge -> response handshake edge with no queueing: BL + 2 (TB convention);  BL + 1 counted from the accepting edge
    (this is the contract text `m_rsp_valid appears BANK_LAT + 1 cycles after the accepting edge`)."""
    bl = read_latency + (1 if ecc else 0)
    return bl + 2 if tb_convention else bl + 1


def little_latency(mean_in_system: float, throughput_per_master: float) -> float:
    """Little's law  W = L / lambda  (per master; L counts the presented-but-not-accepted request as in the TB latency definition)."""
    return mean_in_system / throughput_per_master if throughput_per_master > 0 else float("inf")


def same_bank_latency(nm: int, read_latency: int, ecc: int, arb: int = 1) -> list:
    """ANALYTICAL mean latency per master when all NM saturated masters hit ONE bank (TB convention, presentation edge -> response pop).
    Round robin: a master waits for the NM-1 other grants, is accepted, then BL+1 more edges: NM + BL + 1 for every master (exact, = 6 for NM=4, BL=1).
    Fixed priority (master 0 highest): master i waits for the i higher-priority masters: BL + 2 + i."""
    bl = read_latency + (1 if ecc else 0)
    if arb == 1:
        return [float(nm + bl + 1)] * nm
    return [float(bl + 2 + i) for i in range(nm)]


def single_bank_ceiling_Bpc() -> float:
    return float(LINE_BYTES)


def scalar_useful_ceiling_Bpc(nb: int, scalar_bytes: int = 4) -> float:
    """useful-byte ceiling of 4 B scalar accesses when each costs one whole-line bank access: NB x 4 B/c = 25% of the line peak."""
    return nb * scalar_bytes
