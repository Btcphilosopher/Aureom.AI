"""DMA throughput and scalar/vector-versus-DMA contention (MODEL, first order).

The RTL data point is the `vector_dma` row of reports/bench_rtl.json (tb_vector_scratchpad V6): a 64-beat DMA LOAD takes 69 cycles alone
and 70 cycles while the vector port issues 120 random sub-line / line requests, with 15 bank-conflict pulses counted over the whole mixed
interval.  The vector TB timing is not modelled here, so the model is used only as a parametric estimate:

  * DMA alone: one beat per cycle (single port, consecutive lines rotate through the banks) -> 16 B/cycle = 1/NB of the bank peak;
    cycles = beats + OVH where OVH is the TB's start / completion overhead (69 - 64 = 5 in the RTL row; a measured constant, not derived).
  * with a competing master that presents a random-bank request with probability rho per idle cycle: Monte-Carlo of the exact
    controller model (model.Ctrl) -> DMA slip (extra cycles) and conflict cycles versus rho.

The RTL slip (+1 cycle) is compared with the model curve; the matching rho is an INFERENCE from a single data point, not a validation.
"""
from __future__ import annotations

import random
from collections import deque

from .model import Ctrl
from . import traffic as T


def dma_alone_cycles(beats: int, overhead: int = 5) -> int:
    return beats + overhead


def dma_vs_vector(beats: int = 64, nb: int = 4, nslot: int = 8, read_latency: int = 1, ecc: int = 0, rho: float = 0.5,
                  vec_depth_lines: int = 128, trials: int = 100, seed: int = 11) -> dict:
    """MODEL: mean DMA completion time (edges from first presentation to last response pop) and conflict cycles.
    Masters: 0 = vector (random line, read or write, probability rho per idle cycle), 1 = DMA (consecutive lines, back to back)."""
    rng = random.Random(seed)
    base = None
    slips, confs, lost = [], [], []
    for tr in range(trials + 1):
        r = 0.0 if tr == 0 else rho
        ctl = Ctrl(2, nb, nslot, read_latency, ecc, 1)
        dma_next, dma_cur, dma_done = 0, None, 0
        vec_cur = None
        pend_pop = [0, 0]
        t_first = None
        e = 0
        dma_lost = 0
        while dma_done < beats:
            reqs = [None, None]
            if vec_cur is not None:
                reqs[0] = (0, vec_cur, rng.random() < 0.5, False, None)
            if dma_cur is not None:
                reqs[1] = (0, dma_cur % nb, False, False, None)
            acc, pop = ctl.step(e, reqs, [True, True])
            if dma_cur is not None and not acc[1]:
                dma_lost += 1
            if acc[0]:
                vec_cur = None
            if acc[1]:
                dma_cur = None
            if pop[1] is not None:
                dma_done += 1
            # drivers (same protocol as the TB: present next request in the accepting edge)
            if vec_cur is None and r > 0 and rng.random() < r:
                vec_cur = rng.randrange(vec_depth_lines)
                vec_cur %= nb
            if dma_cur is None and dma_next < beats:
                dma_cur = dma_next
                dma_next += 1
                if t_first is None:
                    t_first = e
            e += 1
        cyc = e - (t_first or 0)
        if tr == 0:
            base = cyc
        else:
            slips.append(cyc - base)
            confs.append(ctl.conf[0] + ctl.conf[1] + ctl.conf[2] + ctl.conf[3] if nb >= 4 else sum(ctl.conf))
            lost.append(dma_lost)
    n = len(slips)
    return {"rho": rho, "beats": beats, "alone_cycles_model": base, "mean_slip": sum(slips) / n, "max_slip": max(slips),
            "mean_conflict_cycles": sum(confs) / n, "mean_dma_lost_arbitration_cycles": sum(lost) / n}


def sweep(rhos=(0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0), **kw) -> list:
    return [dma_vs_vector(rho=r, **kw) for r in rhos]
