"""Model-vs-RTL validation: committed benchmark rows (reports/bench_rtl.json) and extra Verilator runs.

The comparison is EXACT (integers) and to the TB print precision for the mean latency (3 decimals).
Nothing is fitted: every number of the model comes from model.simulate(Cfg.from_row(row)).
"""
from __future__ import annotations

import json
import os
import random

from .model import Cfg, Result, simulate
from . import rtlrun

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
BENCH_JSON = os.path.join(ROOT, "reports", "bench_rtl.json")

STATS = ["cycles", "accesses", "bank_conflict_cycles", "bank_busy_stalls", "mean_latency", "max_latency", "max_outstanding"]
# additional statistics printed by the TB that are NOT in the validation list (checked as a bonus)
BONUS = ["reads", "writes", "useful_bytes"]


def load_bench(path: str = BENCH_JSON) -> dict | None:
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


def _eq(k: str, a, b) -> bool:
    if k == "mean_latency":
        return abs(float(a) - float(b)) < 6e-4          # TB prints %0.3f
    return a == b


def compare_row(rtl: dict, res: Result) -> dict:
    mrow = res.row()
    out = {"match": True, "diff": {}}
    for k in STATS + BONUS:
        if k not in rtl:
            continue
        if not _eq(k, rtl[k], mrow[k]):
            out["match"] = False
            out["diff"][k] = {"rtl": rtl[k], "model": mrow[k]}
    return out


def validate_rows(rows: list[dict]) -> list[dict]:
    """One dict per row: config key, rtl stats, model stats, per-stat equality."""
    out = []
    for r in rows:
        cfg = Cfg.from_row(r)
        res = simulate(cfg)
        c = compare_row(r, res)
        out.append({"experiment": r.get("experiment"), "desc": r.get("desc"), "config": r.get("config"),
                    "pattern": r["pattern"], "pattern_name": r.get("pattern_name"),
                    "nm": r["nm"], "nb": r["nb"], "depth": r["depth"], "read_latency": r["read_latency"], "ecc": r["ecc"],
                    "nslot": r["nslot"], "arb": r["arb"], "rsp_pct": r["rsp_pct"], "load_pct": r["load_pct"], "seed": r["seed"],
                    "rtl": {k: r[k] for k in STATS + BONUS if k in r}, "model": {k: res.row()[k] for k in STATS + BONUS},
                    "match": c["match"], "diff": c["diff"]})
    return out


def summarize(vrows: list[dict]) -> dict:
    n = len(vrows)
    exact = sum(1 for v in vrows if v["match"])
    per_stat = {}
    for k in STATS:
        per_stat[k] = sum(1 for v in vrows if k not in v["diff"])
    return {"rows": n, "exact_match_all_stats": exact, "mismatch_rows": n - exact, "rows_matching_per_stat": per_stat}


# ----------------------------------------------------------------------------------------------- trace comparison
def model_masks(res: Result):
    am, pm, ba = {}, {}, {}
    for (e, kind, a, b) in res.trace:
        if kind == "acc":
            am[e] = am.get(e, 0) | (1 << a)
        elif kind == "pop":
            pm[e] = pm.get(e, 0) | (1 << a)
        elif kind == "gnt":
            ba[e] = ba.get(e, 0) | (1 << b)
    return am, pm, ba


def compare_trace(rtl_trace: list, res: Result) -> dict:
    am, pm, ba = model_masks(res)
    first_bad = None
    n = 0
    for (e, ra, rp, rb) in rtl_trace:
        if e > res.c_end:
            break
        n += 1
        if (ra, rp, rb) != (am.get(e, 0), pm.get(e, 0), ba.get(e, 0)):
            first_bad = (e, (ra, rp, rb), (am.get(e, 0), pm.get(e, 0), ba.get(e, 0)))
            break
    return {"edges_compared": n, "identical": first_bad is None and n > 0, "first_difference": first_bad}


# ----------------------------------------------------------------------------------------------- extra RTL campaign
# Configurations that are NOT in run_bench.py CFG: non power-of-two NM / NSLOT / DEPTH, larger READ_LATENCY with ECC, NM = 16,
# NM = NB = 1, fixed priority + ECC, ALIGN_MODE = 0.  Each is built once; workloads are plusargs.
EXTRA_CFG = {
    "x_base":         dict(),                                   # == run_bench CFG "base" (instrumented copy): also checked against the committed rows
    "x_ecc":          dict(ECC_EN=1),                           # == run_bench CFG "ecc"
    "x_nm3_ns3":      dict(NM=3, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=3, ARB=1),
    "x_nm8_L4_ecc":   dict(NM=8, NB=4, DEPTH=128, READ_LATENCY=4, ECC_EN=1, NSLOT=6, ARB=1),
    "x_nb2_fx_ecc":   dict(NM=4, NB=2, DEPTH=256, READ_LATENCY=2, ECC_EN=1, NSLOT=5, ARB=0),
    "x_align0":       dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1, ALIGN_MODE=0),
    "x_nm6_nb8_L3":   dict(NM=6, NB=8, DEPTH=64, READ_LATENCY=3, ECC_EN=0, NSLOT=12, ARB=1),
    "x_nm16_ecc":     dict(NM=16, NB=4, DEPTH=64, READ_LATENCY=1, ECC_EN=1, NSLOT=4, ARB=1),
    "x_nm1_nb1_ecc":  dict(NM=1, NB=1, DEPTH=128, READ_LATENCY=1, ECC_EN=1, NSLOT=2, ARB=1),
    "x_d100":         dict(NM=4, NB=4, DEPTH=100, READ_LATENCY=2, ECC_EN=0, NSLOT=7, ARB=1),
    "x_nm4_L5_ecc_ns10": dict(NM=4, NB=8, DEPTH=64, READ_LATENCY=5, ECC_EN=1, NSLOT=10, ARB=0),
}


def cfg_of(over: dict) -> dict:
    d = dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1, ALIGN_MODE=1)
    d.update(over)
    return d


def extra_campaign(nreq: int = 400, combos_per_pattern: int = 4, jobs: int = 3, log=print, only: list | None = None,
                   committed: dict | None = None) -> dict:
    """Build the EXTRA_CFG variants, run all 9 patterns x a few (rsp, load, seed) combinations, compare with the model
    statistics AND per-edge (accept / pop / bank-grant masks).  x_base / x_ecc are the committed configurations run with the committed
    workload (nreq 1000, default seed): their BENCH line must equal the committed JSON row (proves the instrumentation is inert)."""
    names = [n for n in EXTRA_CFG if (only is None or n in only)]
    exes = rtlrun.build_many({n: EXTRA_CFG[n] for n in names}, jobs=jobs)
    rng = random.Random(20240614)
    committed_rows = {}
    if committed:
        for r in committed["controller"]:
            if r["config"] in ("base", "ecc") and r["rsp_pct"] == 100 and r["load_pct"] == 100 and r["seed"] == 0x00C0FFEE and r["experiment"] in ("AB", "DEF", "H"):
                committed_rows.setdefault(("x_" + r["config"], r["pattern"]), r)
    rows = []
    for n in names:
        c = cfg_of(EXTRA_CFG[n])
        for pat in range(9):
            if n in ("x_base", "x_ecc"):
                runs = [(100, 100, 0x00C0FFEE, 1000)]
            else:
                runs = [(100, 100, 0x00C0FFEE, nreq)]
                for _ in range(combos_per_pattern - 1):
                    runs.append((rng.choice([10, 25, 50, 75, 90, 100]), rng.choice([20, 40, 70, 100]), rng.randrange(1, 1 << 30), nreq))
            for (rsp, load, seed, nr) in runs:
                extra = {"RSP_PCT": rsp, "LOAD_PCT": load, "SEED": seed}
                out = rtlrun.run(exes[n], pat, nr, extra, trace=True)
                if "bench" not in out:
                    rows.append({"config": n, "pattern": pat, "error": "no BENCH line", "pass": False})
                    continue
                b = out["bench"]
                cfg = Cfg(nm=c["NM"], nb=c["NB"], depth=c["DEPTH"], read_latency=c["READ_LATENCY"], ecc=c["ECC_EN"], nslot=c["NSLOT"],
                          arb=c["ARB"], pattern=pat, nreq=nr, rsp_pct=rsp, load_pct=load, seed=seed, align_mode=c["ALIGN_MODE"])
                res = simulate(cfg, trace=True)
                cmp_ = compare_row(b, res)
                tc = compare_trace(out["trace"], res)
                bx = out.get("benchx", {})
                row = {"config": n, "pattern": pat, "nm": cfg.nm, "nb": cfg.nb, "depth": cfg.depth, "read_latency": cfg.read_latency,
                       "ecc": cfg.ecc, "nslot": cfg.nslot, "arb": cfg.arb, "align_mode": cfg.align_mode, "rsp_pct": rsp,
                       "load_pct": load, "seed": seed, "nreq": nr, "rtl_pass": out["pass"],
                       "rtl": {k: b[k] for k in STATS + BONUS}, "model": {k: res.row()[k] for k in STATS + BONUS},
                       "match": cmp_["match"], "diff": cmp_["diff"], "trace_identical": tc["identical"],
                       "trace_edges": tc["edges_compared"], "trace_first_difference": tc["first_difference"],
                       "rtl_err_rsp": bx.get("err_rsp"), "model_err_rsp": res.err_responses,
                       "rtl_perf_acc": [bx.get(f"acc{i}") for i in range(cfg.nb)], "model_perf_acc": res.per_bank_acc,
                       "rtl_perf_conf": [bx.get(f"conf{i}") for i in range(cfg.nb)], "model_perf_conf": res.per_bank_conf,
                       "rtl_perf_busy": [bx.get(f"busy{i}") for i in range(cfg.nb)], "model_perf_busy": res.per_bank_busy,
                       "rtl_perf_stall": [bx.get(f"stall{i}") for i in range(cfg.nm)], "model_perf_stall": res.per_master_stall,
                       "rtl_max_out": [bx.get(f"maxout{i}") for i in range(cfg.nm)], "model_max_out": res.per_master_max_out,
                       "rtl_c_start": bx.get("c_start"), "model_c_start": res.c_start}
                row["perf_counters_match"] = (row["rtl_err_rsp"] == row["model_err_rsp"] and row["rtl_perf_acc"] == row["model_perf_acc"] and
                                              row["rtl_perf_conf"] == row["model_perf_conf"] and row["rtl_perf_busy"] == row["model_perf_busy"] and
                                              row["rtl_perf_stall"] == row["model_perf_stall"] and row["rtl_max_out"] == row["model_max_out"] and
                                              row["rtl_c_start"] == row["model_c_start"])
                cr = committed_rows.get((n, pat))
                if cr is not None:
                    row["equals_committed_json_row"] = all(_eq(k, cr[k], b[k]) for k in STATS + BONUS)
                rows.append(row)
        log(f"  {n}: {sum(1 for r in rows if r['config'] == n)} runs, mismatches "
            f"{sum(1 for r in rows if r['config'] == n and not (r.get('match') and r.get('trace_identical') and r.get('perf_counters_match')))}")
    tot = len(rows)
    ok = sum(1 for r in rows if r.get("match") and r.get("trace_identical") and r.get("perf_counters_match"))
    return {"label": "RTL-SIMULATION (instrumented copy of tb_bench_ctrl, build/sramlab_work) vs MODEL",
            "runs": tot, "exact_stats_trace_and_perf_counters": ok, "rows": rows,
            "configs": {n: cfg_of(EXTRA_CFG[n]) for n in names}}


# ----------------------------------------------------------------------------------------------- tensor campaign
TENSOR_CASES = {"nbuf2_skew1": {}, "nbuf1_skew1": {"NBUF": 1}, "nbuf2_skew0": {"SKEW": 0}, "nbuf1_skew0": {"NBUF": 1, "SKEW": 0},
                "nbuf2_extra16": {"COMPUTE_EXTRA": 16}, "nbuf1_extra16": {"NBUF": 1, "COMPUTE_EXTRA": 16},
                "nbuf2_extra48": {"COMPUTE_EXTRA": 48}, "nbuf1_extra48": {"NBUF": 1, "COMPUTE_EXTRA": 48},
                "nbuf2_ecc": {"ECC_EN": 1}, "nbuf2_n16": {"N": 16}, "nbuf1_n16": {"NBUF": 1, "N": 16},
                # extra (not in run_bench): validate the co-simulation beyond the 11 committed rows
                "x_nbuf2_L2": {"READ_LATENCY": 2}, "x_nbuf1_L2_ecc": {"NBUF": 1, "READ_LATENCY": 2, "ECC_EN": 1},
                "x_nbuf2_ns4": {"NSLOT": 4}, "x_nbuf2_p1_n4": {"PASSES": 1, "N": 4}, "x_nbuf2_p5_x5": {"PASSES": 5, "COMPUTE_EXTRA": 5},
                "x_nbuf1_n4_skew0": {"NBUF": 1, "N": 4, "SKEW": 0}, "x_nbuf2_n32": {"N": 32, "DEPTH": 128},
                "x_nbuf2_ecc_x16": {"ECC_EN": 1, "COMPUTE_EXTRA": 16}, "x_nbuf2_nb2": {"NB": 2, "DEPTH": 128}}


def tcfg_of(over: dict):
    from .tensor import TCfg
    return TCfg(nbuf=over.get("NBUF", 2), nb=over.get("NB", 4), depth=over.get("DEPTH", 64), n=over.get("N", 8), skew=over.get("SKEW", 1),
                read_latency=over.get("READ_LATENCY", 1), ecc=over.get("ECC_EN", 0), nslot=over.get("NSLOT", 8), ntiles=over.get("NTILES", 8),
                passes=over.get("PASSES", 3), compute_extra=over.get("COMPUTE_EXTRA", 0))


def tensor_campaign(jobs: int = 3, log=print, only: list | None = None, committed: dict | None = None) -> dict:
    """Instrumented RTL runs of tb_tensor_scratchpad (per-edge trace) vs tensor.cosim.  Compared: BENCH statistics and the per-edge
    vectors (controller accept / pop / bank masks, ownership-handshake bits, buffer states)."""
    from concurrent.futures import ThreadPoolExecutor
    from .tensor import cosim

    names = [n for n in TENSOR_CASES if (only is None or n in only)]

    def go(n):
        exe = rtlrun.build_tensor(n, TENSOR_CASES[n])
        return n, rtlrun.run_tensor(exe)

    with ThreadPoolExecutor(jobs) as ex:
        runs = dict(ex.map(go, names))
    com = {}
    if committed:
        for r in committed["tensor"]:
            com[r["config"]] = r
    rows = []
    for n in names:
        r = runs[n]
        b = r["bench"]
        cfg = tcfg_of(TENSOR_CASES[n])
        res = cosim(cfg, trace=True)
        rt = r["trace"]
        c0 = rt[0][0] - 1
        mine = {t[0]: t for t in res["trace"]}
        ident, ne, first = True, 0, None
        for row in rt:
            e = row[0] - c0
            m = mine.get(e)
            if m is None:
                break
            if tuple(row[1:]) != tuple(m[1:]):
                ident, first = False, (e, row[1:], m[1:])
                break
            ne += 1
        # starvation observed in the RTL trace: edges with te_req = 1 and te_owned = 0 (ctl bit3 and not bit4)
        rtl_wait = sum(1 for row in rt if (row[4] >> 3) & 1 and not (row[4] >> 4) & 1)
        cmp_ = {k: (b[k], res[k]) for k in ("total_cycles", "overlap_cycles", "bank_conflict_cycles", "bank_busy_stalls")}
        row = {"config": n, "committed": n in com, "cfg": TENSOR_CASES[n], "rtl_pass": r["pass"], "rtl": {k: b[k] for k in ("total_cycles", "cycles_per_tile", "overlap_cycles", "bank_conflict_cycles", "bank_busy_stalls")},
               "model": {"total_cycles": res["total_cycles"], "cycles_per_tile": res["cycles_per_tile"], "overlap_cycles": res["overlap_cycles"],
                         "bank_conflict_cycles": res["bank_conflict_cycles"], "bank_busy_stalls": res["bank_busy_stalls"]},
               "stats_match": all(a == m_ for a, m_ in cmp_.values()), "trace_identical": ident, "trace_edges": ne, "trace_first_difference": first,
               "rtl_init_rr": {k: v for k, v in r["init"].items() if k.startswith("rr")}, "rtl_te_wait_edges": rtl_wait,
               "model_te_wait_edges": res["te_wait_cycles"]}
        if n in com:
            c = com[n]
            row["equals_committed_json_row"] = all(b[k] == c[k] for k in ("total_cycles", "cycles_per_tile", "overlap_cycles", "bank_conflict_cycles", "bank_busy_stalls"))
        if "conf_raw" in r:
            row["conf_raw"] = r["conf_raw"]
        rows.append(row)
        log(f"  tensor {n}: stats {'OK' if row['stats_match'] else 'DIFF'}, trace {'IDENTICAL' if ident else 'DIFF'} ({ne} edges)")
    return {"label": "RTL-SIMULATION (instrumented copy of tb_tensor_scratchpad, build/sramlab_work) vs MODEL (tensor.cosim)", "rows": rows}
