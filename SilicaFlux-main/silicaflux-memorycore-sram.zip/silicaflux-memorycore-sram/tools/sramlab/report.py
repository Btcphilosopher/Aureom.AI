"""Report generation: reports/sramlab_vs_rtl.{md,json,csv} and the SVG plots.  Every table / plot title carries its provenance tags."""
from __future__ import annotations

import csv
import json
import os
import time

from . import analytic as A
from . import dma as DMA
from . import experiments as X
from . import tensor as TN
from . import traffic as T
from . import validate as V
from .model import Cfg, simulate
from .svgplot import Plot

ROOT = V.ROOT
REPORTS = os.path.join(ROOT, "reports")
EXTRA_JSON = os.path.join(REPORTS, "sramlab_rtl_extra.json")
LEGEND = ("**Provenance tags** - `RTL-SIMULATION`: Verilator simulation of the RTL (reports/bench_rtl.json, or an instrumented re-run in build/sramlab_work); "
          "`MODEL`: tools/sramlab cycle model (derived from the RTL source); `ANALYTICAL`: closed form / small exact Markov chain (sramlab.analytic); "
          "`ASSUMED-PARAMETER`: a number chosen by us, not data (only in the energy report). Nothing in this file is a silicon measurement.")


def md_table(headers, rows) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def f(v, n=2):
    if v is None:
        return "-"
    if isinstance(v, float):
        return f"{v:.{n}f}"
    return str(v)


def pct(v, n=1):
    return "-" if v is None else f"{100*v:.{n}f} %"


# ------------------------------------------------------------------------------------------------ data collection
def collect(bench: dict, extra: dict | None) -> dict:
    d: dict = {"generated": time.strftime("%Y-%m-%d %H:%M:%S"), "bench_generated_by": bench.get("generated_by"), "verilator": bench.get("verilator"),
               "nreq": bench.get("nreq")}
    vrows = V.validate_rows(bench["controller"])
    d["validation"] = {"summary": V.summarize(vrows), "rows": vrows}
    d["extra_rtl"] = None
    if extra:
        c = extra["controller"]
        d["extra_rtl"] = {"controller_runs": c["runs"], "controller_exact": c["exact_stats_trace_and_perf_counters"], "configs": c["configs"],
                          "tensor_runs": len(extra["tensor"]["rows"]),
                          "tensor_stats_exact": sum(1 for r in extra["tensor"]["rows"] if r["stats_match"]),
                          "tensor_trace_identical": sum(1 for r in extra["tensor"]["rows"] if r["trace_identical"]),
                          "controller_rows": c["rows"], "tensor_rows": extra["tensor"]["rows"]}
    d["ceilings"] = X.ceilings_rows(bench)
    d["headline"] = X.headline(d["ceilings"])
    d["ecc"] = X.ecc_table(bench)
    d["sweep_nb"] = X.sweep_nb(bench)
    d["sweep_nm"] = X.sweep_nm(bench)
    d["sweep_depth"] = X.sweep_depth(bench)
    d["saturation"] = X.saturation(bench)
    d["queue"] = X.queue_table(bench)
    d["conflicts"] = X.conflict_analysis(extra["controller"] if extra else None)
    d["fairness"] = X.fairness()
    d["dma"] = dma_section(bench)
    d["tensor"] = tensor_section(bench, extra)
    d["starvation"] = starvation_section()
    return d


def dma_section(bench: dict) -> dict:
    g = (bench.get("vector_dma") or [None])[0]
    sweep = DMA.sweep(trials=100)
    return {"rtl_row": g, "model_sweep": sweep,
            "rtl_alone_beats_per_cycle": g["beats"] / g["cycles_alone"] if g else None,
            "rtl_asymptotic_note": "single DMA port: <= 1 beat (16 B) per cycle = 1/NB of the 4-bank peak",
            "rtl_slip_cycles": (g["cycles_with_vector"] - g["cycles_alone"]) if g else None}


def tensor_section(bench: dict, extra: dict | None) -> dict:
    rows = []
    for r in bench["tensor"]:
        cfg = TN.TCfg.from_row(r)
        cs = TN.cosim(cfg)
        pp = TN.phase_pipeline(cfg)
        sp = TN.steady_period(cfg)
        cst = cs["comp_start_edge"]
        steady = (cst[-1] - cst[1]) / (cfg.ntiles - 2) if cfg.ntiles > 2 else None
        rows.append({"config": r["config"], "nbuf": cfg.nbuf, "skew": cfg.skew, "n": cfg.n, "ecc": cfg.ecc, "compute_extra": cfg.compute_extra, "model_steady_period": steady,
                     "model_first_fill_edges": cst[0], "model_te_wait_by_tile": cs["te_wait_by_tile"],
                     "rtl_total": r["total_cycles"], "rtl_cpt": r["cycles_per_tile"], "rtl_overlap": r["overlap_cycles"], "rtl_conf": r["bank_conflict_cycles"],
                     "model_total": cs["total_cycles"], "model_cpt": cs["cycles_per_tile"], "model_overlap": cs["overlap_cycles"], "model_conf": cs["bank_conflict_cycles"],
                     "phase_total": pp["total_cycles"], "phase_cpt": pp["cycles_per_tile"], "steady_cpt": sp["cycles_per_tile"], "bound": sp["bound"],
                     "Df": sp["Df"], "Dc": sp["Dc"], "Dd": sp["Dd"],
                     "conflict_free_gap_total": r["total_cycles"] - pp["total_cycles"]})
    return {"rows": rows}


def starvation_section() -> dict:
    """Operand starvation vs compute time per tile and DMA bandwidth share: ANALYTICAL curves and MODEL (co-simulation) points.
    The DMA rate is throttled in the MODEL only (one DMA request every k cycles); it has no RTL counterpart.
    MODEL measurement: 12 tiles, steady state = tiles 2..11; starved cycles per tile = (edges with te_req && !te_owned) - 1 (the minimum
    handshake wait measured in the unthrottled compute-bound run); fraction = starved / measured period."""
    pts = []
    NT = 12
    for n in (8, 16):
        ref = TN.cosim(TN.TCfg(nbuf=2, n=n, compute_extra=64, ntiles=NT))
        hs_min = sum(ref["te_wait_by_tile"][2:]) / (NT - 2)
        for k in (1, 2, 4, 8):
            for extra in (0, 8, 16, 32, 48, 64, 96, 128):
                cfg = TN.TCfg(nbuf=2, n=n, compute_extra=extra, ntiles=NT)
                cs = TN.cosim(cfg, dma_issue_every=k)
                ph = TN.phase_times(cfg)
                st = cs["comp_start_edge"]
                period = (st[-1] - st[2]) / (NT - 3)
                wait = sum(cs["te_wait_by_tile"][2:]) / (NT - 2)
                starved = max(0.0, wait - hs_min)
                sv = TN.starvation(n, ph["Dc"], 1.0 / k, nbuf=2, bank_lat=cfg.bank_lat)
                pts.append({"n": n, "dma_every": k, "beta": 1.0 / k, "compute_extra": extra, "compute_cycles": ph["Dc"], "model_period": period,
                            "model_starved_per_tile": starved, "model_frac": starved / period if period else 0.0,
                            "analytic_period": sv["period"], "analytic_stall_per_tile": sv["stall_per_tile"], "analytic_frac": sv["starved_fraction"],
                            "analytic_t_dma": sv["t_dma"]})
    single = []
    for n in (8, 16):
        for extra in (0, 48):
            cfg = TN.TCfg(nbuf=1, n=n, compute_extra=extra)
            ph = TN.phase_times(cfg)
            sv = TN.starvation(n, ph["Dc"], 1.0, nbuf=1, bank_lat=cfg.bank_lat)
            single.append({"n": n, "compute_extra": extra, "analytic_frac_single": sv["starved_fraction"], "analytic_stall_single": sv["stall_per_tile"],
                           "compute_cycles": ph["Dc"]})
    cross = []
    for n in (8, 16, 32):
        for beta in (1.0, 0.5, 0.25, 0.125):
            t = TN.starvation(n, 1, beta)
            cross.append({"n": n, "beta": beta, "t_dma": t["t_dma"], "min_compute_cycles_for_no_starvation": t["t_dma"] - TN.GAP})
    both = [abs(p["model_frac"] - p["analytic_frac"]) for p in pts]
    return {"points": pts, "single_buffer": single, "crossover": cross, "max_abs_frac_difference_model_vs_analytic": max(both),
            "mean_abs_frac_difference_model_vs_analytic": sum(both) / len(both)}


# ------------------------------------------------------------------------------------------------ plots
def make_plots(d: dict, outdir: str) -> list[str]:
    files = []
    # 1) throughput vs offered load (S)
    p = Plot("Throughput vs offered load - S sweep: RTL-SIMULATION (solid) vs MODEL (dashed) vs ANALYTICAL ceiling (dotted)",
             "offered load per idle master [% of cycles]", "useful throughput [B/cycle]", subtitle="NM=4 masters, 16 B lines, NSLOT=8, READ_LATENCY=1; MODEL overlaps RTL exactly (see sramlab_vs_rtl.md)")
    names = {("base", 4): "base NB=4 RANDOM_LINE", ("base", 1): "base NB=4 SEQ_LINE", ("nb8", 4): "NB=8 RANDOM_LINE"}
    col = {("base", 4): "#1f6feb", ("base", 1): "#1a7f37", ("nb8", 4): "#d1242f"}
    for key, nm in names.items():
        pts = sorted([r for r in d["saturation"] if (r["config"], r["pattern"]) == key], key=lambda r: r["load_pct"])
        xs = [r["load_pct"] for r in pts]
        p.add(f"RTL-SIMULATION {nm}", xs, [r["rtl_Bpc"] for r in pts], "line+marker", col[key], "circle")
        p.add(f"MODEL {nm}", xs, [r["model_Bpc"] for r in pts], "line+marker", col[key], "cross", "6 4")
        p.add(f"ANALYTICAL ceiling {nm}", xs, [r["ceil_Bpc"] for r in pts], "line", col[key], None, "2 3")
    path = os.path.join(outdir, "sramlab_throughput_vs_load.svg")
    p.save(path)
    files.append(path)
    # 2) throughput vs banks (J)
    p = Plot("Throughput vs number of banks - J sweep: RTL-SIMULATION vs MODEL vs ANALYTICAL ceiling",
             "number of banks NB (NM = 4 masters)", "useful throughput [B/cycle]", subtitle="4 masters x 1000 requests, 16 B lines; peak = NB x 16 B/cycle (ANALYTICAL)")
    pn = {1: "SEQ_LINE", 2: "OWN_BANK", 4: "RANDOM_LINE"}
    pc = {1: "#1f6feb", 2: "#1a7f37", 4: "#d1242f"}
    for pat, nm in pn.items():
        pts = [r for r in d["sweep_nb"] if r["pattern"] == pat]
        xs = [r["nb"] for r in pts]
        p.add(f"RTL-SIMULATION {nm}", xs, [r["rtl_Bpc"] for r in pts], "line+marker", pc[pat], "circle")
        p.add(f"MODEL {nm}", xs, [r["model_Bpc"] for r in pts], "line+marker", pc[pat], "cross", "6 4")
        p.add(f"ANALYTICAL ceiling {nm}", xs, [r["ceil_Bpc"] for r in pts], "line", pc[pat], None, "2 3")
    xs = sorted({r["nb"] for r in d["sweep_nb"]})
    p.add("ANALYTICAL bank peak NB x 16 B/c", xs, [16 * x for x in xs], "line", "#57606a", None, "1 4")
    p.xlim = (0.8, 9)
    path = os.path.join(outdir, "sramlab_throughput_vs_banks.svg")
    p.save(path)
    files.append(path)
    # 3) masters sweep
    p = Plot("Throughput vs number of masters - J sweep: RTL-SIMULATION vs MODEL vs ANALYTICAL ceiling", "number of masters NM (NB = 4)", "useful throughput [B/cycle]",
             subtitle="configs nm2_nb4, base (4x4), nm8_nb4; RANDOM_LINE/SEQ_LINE/OWN_BANK")
    for pat, nm in pn.items():
        pts = [r for r in d["sweep_nm"] if r["pattern"] == pat and r["nb"] == 4]
        xs = [r["nm"] for r in pts]
        p.add(f"RTL-SIMULATION {nm}", xs, [r["rtl_Bpc"] for r in pts], "line+marker", pc[pat], "circle")
        p.add(f"MODEL {nm}", xs, [r["model_Bpc"] for r in pts], "line+marker", pc[pat], "cross", "6 4")
        p.add(f"ANALYTICAL ceiling {nm}", xs, [r["ceil_Bpc"] for r in pts], "line", pc[pat], None, "2 3")
    path = os.path.join(outdir, "sramlab_throughput_vs_masters.svg")
    p.save(path)
    files.append(path)
    # 4) RTL vs MODEL scatter (every benchmark row, 4 statistics)
    p = Plot("RTL-SIMULATION vs MODEL, every committed benchmark row (119): all points on y = x", "RTL-SIMULATION value", "MODEL value", xlog=True, ylog=True,
             subtitle="cycles, accesses, mean latency, max latency, bank-conflict cycles (>0), throughput [B/cycle]; exact agreement, no fit")
    vr = d["validation"]["rows"]
    series = [("cycles", lambda r: (r["rtl"]["cycles"], r["model"]["cycles"]), "#1f6feb", "circle"),
              ("mean latency", lambda r: (r["rtl"]["mean_latency"], r["model"]["mean_latency"]), "#1a7f37", "square"),
              ("bank-conflict cycles", lambda r: (r["rtl"]["bank_conflict_cycles"], r["model"]["bank_conflict_cycles"]), "#d1242f", "diamond"),
              ("max latency", lambda r: (r["rtl"]["max_latency"], r["model"]["max_latency"]), "#9a6700", "triangle")]
    allv = []
    for nm, fn, c, mk in series:
        pts = [fn(r) for r in vr]
        pts = [(a, b) for a, b in pts if a > 0 and b > 0]
        allv += [a for a, _ in pts]
        p.add(f"{nm} (RTL vs MODEL)", [a for a, _ in pts], [b for _, b in pts], "scatter", c, mk)
    lo, hi = min(allv) / 1.5, max(allv) * 1.5
    p.add("y = x", [lo, hi], [lo, hi], "line", "#57606a", None, "4 3")
    p.xlim = p.ylim = (lo, hi)
    path = os.path.join(outdir, "sramlab_rtl_vs_model_scatter.svg")
    p.save(path)
    files.append(path)
    # 5) starvation
    p = Plot("TensorCore operand starvation vs compute time per tile: ANALYTICAL curves (lines) vs MODEL co-simulation (markers)", "compute cycles per tile (TensorCore busy time)",
             "starved fraction of the TensorCore's time", subtitle="NBUF=2, N=8 lines/tile; DMA beat rate beta = 1/k lines per cycle is throttled in the MODEL only (no RTL counterpart)")
    colk = {1: "#1f6feb", 2: "#1a7f37", 4: "#9a6700", 8: "#d1242f"}
    pts_all = d["starvation"]["points"]
    for k in (1, 2, 4, 8):
        pts = sorted([x for x in pts_all if x["n"] == 8 and x["dma_every"] == k], key=lambda x: x["compute_cycles"])
        xs = [x["compute_cycles"] for x in pts]
        p.add(f"ANALYTICAL beta=1/{k}", xs, [x["analytic_frac"] for x in pts], "line", colk[k], None)
        p.add(f"MODEL co-sim beta=1/{k}", xs, [x["model_frac"] for x in pts], "marker", colk[k], "circle")
    path = os.path.join(outdir, "sramlab_starvation.svg")
    p.save(path)
    files.append(path)
    # 6) tensor cycles per tile
    p = Plot("Tensor pipeline cycles/tile: RTL-SIMULATION = MODEL co-sim vs ANALYTICAL conflict-free phase model", "tensor TB configuration (index)", "cycles per tile",
             subtitle="committed 11 tensor rows in run order; markers: RTL-SIMULATION (circle), MODEL (cross), ANALYTICAL conflict-free steady period (triangle)")
    rows = d["tensor"]["rows"]
    xs = list(range(len(rows)))
    p.add("RTL-SIMULATION cycles/tile", xs, [r["rtl_cpt"] for r in rows], "marker", "#1f6feb", "circle")
    p.add("MODEL co-sim cycles/tile", xs, [r["model_cpt"] for r in rows], "marker", "#d1242f", "cross")
    p.add("ANALYTICAL conflict-free steady period", xs, [r["steady_cpt"] for r in rows], "marker", "#1a7f37", "triangle")
    for i, r in enumerate(rows):
        p.note(f"{i}: {r['config']}") if i < 12 else None
    path = os.path.join(outdir, "sramlab_tensor_cycles.svg")
    p.save(path)
    files.append(path)
    return files


# ------------------------------------------------------------------------------------------------ markdown
def render_md(d: dict) -> str:
    L = []
    w = L.append
    v = d["validation"]["summary"]
    ex = d["extra_rtl"]
    w("# SilicaFlux MemoryCore SRAM - cycle model, ceilings and energy tooling vs RTL simulation")
    w("")
    w(f"Generated {d['generated']} by `python3 -m sramlab report` (tools/sramlab). Source RTL: rtl/sf_sram_controller.sv, rtl/sf_sram_bank.sv, rtl/sf_sram_core.sv, "
      f"rtl/sf_tensor_scratchpad.sv; testbenches tb/tb_bench_ctrl.sv, tb/tb_tensor_scratchpad.sv; RTL results reports/bench_rtl.json ({d['verilator']}, NREQ={d['nreq']}).")
    w("")
    w(LEGEND)
    w("")
    # ---------------------------------------------------------------- summary
    w("## 0. Summary")
    w("")
    h = d["headline"]
    w(f"* **Validation (MODEL vs RTL-SIMULATION).** {v['exact_match_all_stats']} of {v['rows']} committed controller benchmark rows are reproduced EXACTLY for all seven "
      f"statistics (cycles, accesses, bank_conflict_cycles, bank_busy_stalls, mean_latency to the printed 3 decimals, max_latency, max_outstanding); "
      f"{v['mismatch_rows']} rows differ. No tolerance, no fitted constant.")
    if ex:
        w(f"* **Extra RTL runs.** {ex['controller_exact']} of {ex['controller_runs']} additional Verilator runs of an instrumented copy of the benchmark TB "
          f"(non power-of-two NM / NSLOT / DEPTH, READ_LATENCY up to 5 with ECC, NM up to 16, fixed priority, ALIGN_MODE=0 builds, random RSP_PCT / LOAD_PCT / SEED) "
          f"match the model in the statistics, in EVERY clock edge (accept / pop / bank-grant masks) and in the controller's own performance counters. "
          f"Tensor scratchpad: {ex['tensor_trace_identical']} of {ex['tensor_runs']} instrumented configurations match edge for edge; the remaining "
          f"{ex['tensor_runs'] - ex['tensor_stats_exact']} differs only in a testbench counter artefact (section 6).")
    w("* **Headline ceilings (RTL-SIMULATION vs ANALYTICAL ceiling, 4 masters x 4 banks, 16 B lines):** "
      + "; ".join(f"{k.replace('_', ' ')} {x['rtl_Bpc']:.2f} of {x['ceil_Bpc']:.2f} B/c ({pct(x['eff'])})" for k, x in h.items() if k != "scalar_as_run") + ".")
    sc = h.get("scalar_as_run")
    if sc:
        w(f"* **Scalar loads (benchmark A, pattern 0).** The first revision of the TB issued byte-strided sub-line addresses to an ALIGN_MODE=1 controller, so 3 of 4 requests were "
          f"rejected with `SF_ST_ALIGN` and benchmark A reported 15.92 B/cycle for what was really ~4 B/cycle of array traffic (found by this validation, RTL counters: 3000 error responses of 4000). "
          f"The TB now issues line-aligned scalar loads (4 consecutive loads per line); RTL-SIMULATION result {sc['rtl_Bpc']:.2f} B/cycle against an ANALYTICAL bound of {sc['ceil_Bpc']:.2f} B/cycle "
          f"(each 4 B load costs a whole 16 B bank access).")
    w("")
    # ---------------------------------------------------------------- validation
    w("## 1. Validation: MODEL vs RTL-SIMULATION")
    w("")
    w("### 1.1 Committed benchmark rows (reports/bench_rtl.json, `controller`)")
    w("")
    w(md_table(["statistic", "rows reproduced exactly (MODEL = RTL-SIMULATION)"], [[k, f"{n} / {v['rows']}"] for k, n in v["rows_matching_per_stat"].items()]))
    w("")
    mism = [r for r in d["validation"]["rows"] if not r["match"]]
    if not mism:
        w("**No mismatching row.** Therefore there is no 'model bug vs undocumented RTL behaviour' to report for these rows; the RTL behaviours that the contract text does not "
          "state but that the model needed are listed in 1.4 (each was derived from the RTL source before the comparison, and confirmed by it).")
    else:
        w("**Mismatching rows (cause analysis required):**")
        for r in mism:
            w(f"* {r['experiment']} {r['config']} pattern {r['pattern']}: {r['diff']}")
    w("")
    w("### 1.2 Extra RTL-SIMULATION runs (instrumented copy of the TB, build/sramlab_work)")
    w("")
    if ex:
        rows = []
        for n, c in ex["configs"].items():
            rr = [r for r in ex["controller_rows"] if r["config"] == n]
            ok = sum(1 for r in rr if r.get("match") and r.get("trace_identical") and r.get("perf_counters_match"))
            tot_edges = sum(r.get("trace_edges", 0) for r in rr)
            rows.append([n, f"NM={c['NM']} NB={c['NB']} DEPTH={c['DEPTH']} RL={c['READ_LATENCY']} ECC={c['ECC_EN']} NSLOT={c['NSLOT']} ARB={'RR' if c['ARB'] else 'FIXED'} ALIGN={c['ALIGN_MODE']}",
                         len(rr), f"{ok} / {len(rr)}", tot_edges])
        w(md_table(["config", "parameters", "runs", "exact (stats + per-edge trace + perf counters)", "edges compared"], rows))
        w("")
        eq = [r for r in ex["controller_rows"] if "equals_committed_json_row" in r]
        w(f"The instrumented copy is inert: its BENCH line equals the committed JSON row in {sum(1 for r in eq if r['equals_committed_json_row'])} of {len(eq)} runs of the committed `base` / `ecc` "
          f"configurations (nreq 1000). Per run, the compared items are the seven statistics, the per-edge (accept mask, pop mask, bank-grant mask) of every edge from the first "
          f"presentation to the last pop, and the controller's perf counters (per-bank accepted / conflict / busy, per-master stall and max outstanding, c_start, error responses). "
          f"In particular the absolute first-presentation edge (`c_start` = DEPTH + 26, derived from the TB's reset / init / settle sequence, it matters for the LOAD_PCT hash) equals the RTL value in every run.")
    else:
        w("NOT RUN in this report (run `python3 -m sramlab rtl-extra` first).")
    w("")
    w("### 1.3 Full table: every committed row, RTL-SIMULATION values (MODEL equals RTL in every cell)")
    w("")
    rows = []
    for i, r in enumerate(d["validation"]["rows"]):
        rt = r["rtl"]
        rows.append([i, r["experiment"], r["config"], r["pattern_name"], f"{r['rsp_pct']}/{r['load_pct']}/{r['seed']}", rt["cycles"], rt["accesses"], rt["bank_conflict_cycles"],
                     rt["bank_busy_stalls"], f"{rt['mean_latency']:.3f}", rt["max_latency"], rt["max_outstanding"], "EXACT 7/7" if r["match"] else "DIFF " + str(r["diff"])])
    w(md_table(["#", "exp", "config", "pattern", "rsp%/load%/seed", "cycles", "accesses", "conflict cyc", "busy stalls", "mean lat", "max lat", "max out", "MODEL vs RTL"], rows))
    w("")
    w("### 1.4 RTL behaviour the contract text does not state (needed by the model; all confirmed by the RTL comparison)")
    w("")
    w("1. **Pop timing / slot recycling.** A slot freed by a pop at edge e is visible in the registered `cnt` at e+1, so the same master can accept again at e+1: round trip BANK_LAT+2 "
      "(not BANK_LAT+1) - this is the exact origin of the `NSLOT >= BANK_LAT+2` rule (rtl/sf_sram_controller.sv:354,375) and of the slot ceiling NSLOT/(BANK_LAT+2).")
    w("2. **Error requests (ALIGN / RANGE) are accepted without a bank and answered at the NEXT edge, but still released in order** behind older array accesses "
      "(sd set at allocation, rtl/sf_sram_controller.sv:409-411; head-only release line 357): the latency of an error response is therefore hidden by the in-order rule (benchmark A shows identical mean latency to B).")
    w("3. **Arbitration pointer.** `rr_ptr` of a bank moves only when that bank grants (line 247-250), to granted+1; a request that is blocked because its bank is busy (RMW) does not advance it. "
      "Masters therefore desynchronise by one bank after the first conflict: SEQ_LINE (all master regions are bank-aligned, REGION multiple of NB) is conflict-free in steady state "
      "although every master starts on the same bank (3 conflict cycles in total in benchmark B).")
    w("4. **Performance-counter semantics.** `perf_conf` counts a bank-cycle with >= 2 requesters AFTER the `can_alloc` and error filter (line 229, 426-431), also when the bank is busy; "
      "a master whose slots are full is not a requester. `perf_busy` counts bank-cycles (not masters) with >= 1 requester and a busy bank; it is identically 0 without ECC "
      "(no mechanism makes a bank busy), so `bank_busy_stalls` is purely the ECC read-modify-write signature.")
    w("5. **m_req_ready is NOT a function of 'this master's own valid/address only'** as the header claims (rtl/sf_sram_controller.sv:16-17): `gnt_any[i]` depends on every other master's valid / address "
      "through the per-bank arbiter (lines 229-241, 285). It is independent of `m_rsp_ready` as stated. (Documentation issue, no functional bug.)")
    w("6. **TB latency convention.** The TB counts from the presentation edge, so the minimum latency is BANK_LAT+2 (3 cycles for READ_LATENCY=1 without ECC); the contract's BANK_LAT+1 is counted from the accepting edge. Both agree.")
    w("")
    # ---------------------------------------------------------------- ceilings
    w("## 2. Ceilings vs RTL-SIMULATION")
    w("")
    w("Formulas (ANALYTICAL, `sramlab.analytic`): bank peak = NB x 16 B/c; per-master slot ceiling = min(1, NSLOT/(BANK_LAT+2)) accesses/cycle (exact for rsp_ready = 1; exact Markov chain "
      "for a Bernoulli response-ready); single bank = 16 B/c; random destinations with head-of-line blocking = stationary accesses/cycle of the occupancy Markov chain "
      f"(exact for iid uniform destinations: NM=NB=2/4/8 -> {A.hol_saturation(2,2)/2:.4f} / {A.hol_saturation(4,4)/4:.4f} / {A.hol_saturation(8,8)/8:.4f} per bank, the Karol et al. values; "
      "balls-in-bins NB(1-(1-1/NB)^NM) is only an upper bound); an ECC partial write occupies its bank READ_LATENCY+1 cycles. The ceiling column is always an upper bound in expectation; `~` marks rows where it is not tight by construction (pattern 0 in the TB's useful-byte accounting; random mixed read / partial-write traffic with ECC, where the product HOL x 1/(1+f RL) is given as an approximate estimate).")
    w("")
    w("### 2.1 Every committed row: RTL-SIMULATION | MODEL | ANALYTICAL ceiling | efficiency = RTL / ceiling")
    w("")
    rows = []
    for r in d["ceilings"]:
        est = "" if abs(r["ceil_estimate_Bpc"] - r["ceil_Bpc"]) < 1e-9 else f"{r['ceil_estimate_Bpc']:.2f}"
        rows.append([r["experiment"], r["config"], r["pattern_name"], f"{r['rsp_pct']}/{r['load_pct']}", f"{r['rtl_Bpc']:.2f}", f"{r['model_Bpc']:.2f}", f"{r['ceil_Bpc']:.2f}",
                     pct(r["eff"]), est, f"{r['rtl_mean_latency']:.2f} (min {r['zero_load_latency']})", "" if r["ceil_exact"] else "~"])
    w(md_table(["exp", "config", "pattern", "rsp%/load%", "RTL B/c", "MODEL B/c", "ANALYTICAL ceiling B/c (upper bound)", "efficiency", "ANALYTICAL approx. estimate B/c (where it differs)", "RTL mean latency (zero-load min)", "approx"], rows))
    w("")
    w("Efficiency slightly above 100 % has two harmless causes: (a) deterministic patterns, at most ~0.2 %: the TB measures from the first presentation to the last response (finite-run end effect), the ceiling is a steady-state rate; "
      "(b) random patterns, up to ~1-2 %: the ceiling is an EXPECTATION and a 1000-request sample fluctuates around it (MODEL, 40 seeds: std 0.3 B/c = 0.7 %; 20000 requests/master converge to 41.84 B/c vs the exact chain 41.94 B/c). "
      "Efficiencies clearly below 100 % are explained row by row in section 3 (head-of-line blocking, lock-step conflicts, RMW occupancy, ALIGN errors).")
    w("")
    # ---------------------------------------------------------------- experiments
    w("## 3. Experiments A-J, S, Q (RTL-SIMULATION | MODEL | ANALYTICAL)")
    w("")
    w("### 3.1 A/B/D/E/F - RTL-SIMULATION | MODEL | ANALYTICAL for the nine workload patterns, base configuration (NM=4, NB=4, DEPTH=256, READ_LATENCY=1, no ECC, round robin)")
    w("")
    rows = []
    for r in d["ceilings"]:
        if r["experiment"] in ("AB", "DEF") and r["config"] == "base":
            rows.append([r["pattern"], r["pattern_name"], f"{r['rtl_Bpc']:.2f}", f"{r['model_Bpc']:.2f}", f"{r['ceil_Bpc']:.2f}", pct(r["eff"]), r["rtl_conflicts"], r["ceil_formula"]])
    w(md_table(["#", "pattern", "RTL B/c", "MODEL B/c", "ANALYTICAL B/c", "RTL/ceiling", "RTL conflict cycles", "ceiling basis"], rows))
    w("")
    w("*Benchmark A (pattern 0) is a line-aligned scalar workload:* every 4 B load is a whole 16 B line access (four consecutive loads of one master hit the same line, masters are staggered by one line = "
      "one bank), so the useful-byte ceiling of the 4 B patterns is 4 B x accesses/cycle (25 % of the line peak). A byte-strided variant that the ALIGN_MODE=1 controller mostly rejects exists only in "
      "the model (pattern 9).")
    w("")
    w("### 3.2 H - ECC overhead (RTL-SIMULATION ratios vs MODEL vs ANALYTICAL)")
    w("")
    rows = [[r["read_latency"], r["pattern_name"], f"{r['rtl_Bpc_noecc']:.2f}", f"{r['rtl_Bpc_ecc']:.2f}", f"{r['rtl_ratio']:.3f}", f"{r['model_ratio']:.3f}",
             f"{r['ceil_ratio']:.3f}" if r["ceil_ratio"] else "-", f"{r['rtl_lat_noecc']:.2f} -> {r['rtl_lat_ecc']:.2f}", f"{r['rtl_busy_ecc']}", f"{r['model_busy_ecc']}"] for r in d["ecc"]]
    w(md_table(["RL", "pattern", "RTL B/c no-ECC", "RTL B/c ECC", "RTL ratio", "MODEL ratio", "ANALYTICAL ratio", "mean latency (RTL)", "RTL busy stalls", "MODEL busy stalls"], rows))
    w("")
    w("ECC adds exactly one cycle of latency (BANK_LAT = READ_LATENCY+1) and costs bandwidth only for partial writes: every partial write occupies its bank READ_LATENCY+1 cycles "
      "(SEQ_WRITE_PART4: ratio ~0.5 at RL=1, ~0.33 at RL=2 = 1/(RL+1), the ANALYTICAL value), RANDOM_PART4 (50 % partial writes) is limited to 1/(1+0.5 RL) of the bank rate before head-of-line effects (approximate). "
      "Read- and full-line-write patterns are unchanged except for the one-cycle latency.")
    w("")
    w("### 3.3 J - capacity, bank-count and master-count sweeps")
    w("")
    rows = [[r["pattern"], r["nb"], f"{r['rtl_Bpc']:.2f}", f"{r['model_Bpc']:.2f}", f"{r['ceil_Bpc']:.2f}", pct(r["rtl_Bpc"] / r["ceil_Bpc"])] for r in d["sweep_nb"]]
    w("**Bank count (NM = 4)** - RTL-SIMULATION | MODEL | ANALYTICAL:")
    w("")
    w(md_table(["pattern (1 SEQ_LINE, 2 OWN_BANK, 4 RANDOM_LINE)", "NB", "RTL B/c", "MODEL B/c", "ANALYTICAL B/c", "RTL/ceiling"], rows))
    w("")
    rows = [[r["pattern"], r["config"], r["nm"], r["nb"], f"{r['rtl_Bpc']:.2f}", f"{r['model_Bpc']:.2f}", f"{r['ceil_Bpc']:.2f}", pct(r["rtl_Bpc"] / r["ceil_Bpc"])] for r in d["sweep_nm"]]
    w("**Master count** - RTL-SIMULATION | MODEL | ANALYTICAL:")
    w("")
    w(md_table(["pattern", "config", "NM", "NB", "RTL B/c", "MODEL B/c", "ANALYTICAL B/c", "RTL/ceiling"], rows))
    w("")
    rows = [[r["pattern"], r["depth"], f"{r['capacity_KiB']:g}", f"{r['rtl_Bpc']:.2f}", f"{r['model_Bpc']:.2f}", r["rtl_conf"]] for r in d["sweep_depth"]]
    w("**Capacity (NB = 4; DEPTH 64 / 256 / 1024 / 4096 rows = 4 / 16 / 64 / 256 KiB)** - capacity does not enter any ceiling, and the RTL results are IDENTICAL for the four capacities: the workloads' bank sequences depend only on the low line-address bits (CAP_LINES = NB x DEPTH is a power of two, so `draw mod CAP_LINES` has the same low bits), not on DEPTH:")
    w("")
    w(md_table(["pattern", "DEPTH", "KiB", "RTL B/c", "MODEL B/c", "RTL conflict cycles"], rows))
    w("")
    w("Plots: `sramlab_throughput_vs_banks.svg`, `sramlab_throughput_vs_masters.svg`.")
    w("")
    w("### 3.4 S - saturation (offered load): RTL-SIMULATION | MODEL | ANALYTICAL")
    w("")
    rows = []
    for r in d["saturation"]:
        rows.append([r["config"], r["pattern"], r["load_pct"], f"{r['rtl_Bpc']:.2f}", f"{r['model_Bpc']:.2f}", f"{r['ceil_Bpc']:.2f}", pct(r["rtl_Bpc"] / r["ceil_Bpc"]), f"{r['rtl_mean_latency']:.2f}"])
    w(md_table(["config", "pattern", "load %", "RTL B/c", "MODEL B/c", "ANALYTICAL min(offered, saturation) B/c", "RTL/ceiling", "RTL mean latency"], rows))
    w("")
    w("The ANALYTICAL ceiling is the asymptote min(NM x load, saturation). Up to 20 % offered load both patterns follow it within 3-5 %. Between 30 % and 80 % SEQ_LINE falls to 85-91 % of the asymptote "
      "and RANDOM_LINE to 83-91 %: the random idle gaps of the offered-load gate desynchronise the masters, so the one-bank skew that makes SEQ_LINE conflict-free at 100 % load is lost "
      "(RTL conflict cycles for SEQ_LINE: 3 at 100 % load, 418-755 at 30-80 %) and bank queueing appears before saturation; RANDOM_LINE additionally suffers head-of-line blocking (persistent destinations). "
      "At 100 % the masters self-skew again (SEQ_LINE 99.5 %). Plot: `sramlab_throughput_vs_load.svg`.")
    w("")
    w("### 3.5 Q - queue occupancy vs response back-pressure and slot count (SEQ_LINE): RTL-SIMULATION | MODEL | ANALYTICAL")
    w("")
    rows = [[r["config"], r["nslot"], r["rsp_pct"], f"{r['rtl_Bpc']:.2f}", f"{r['model_Bpc']:.2f}", f"{r['ceil_Bpc']:.2f}", pct(r["rtl_Bpc"] / r["ceil_Bpc"]), r["rtl_max_outstanding"],
             f"{r['rtl_mean_latency']:.2f}", f"{r['model_mean_slot_occupancy_m0']:.2f}"] for r in d["queue"]]
    w(md_table(["config", "NSLOT", "rsp ready %", "RTL B/c", "MODEL B/c", "ANALYTICAL B/c", "RTL/ceiling", "RTL max outstanding (master 0)", "RTL mean latency", "MODEL mean slot occupancy (master 0)"], rows))
    w("")
    w("ANALYTICAL = 4 x the exact single-master Markov chain throughput (`slot_ceiling_markov`): NSLOT=2 gives 2/3 of the port rate (BANK_LAT+2 = 3), NSLOT >= 3 sustains 1 access/cycle; "
      "with random response-ready the chain gives the exact single-master rate, the 4-master RTL runs sit a few percent below it because response back-pressure desynchronises the masters "
      "and re-introduces bank conflicts (counted by the model and the RTL).")
    w("")
    w("### 3.6 Bank-conflict analysis (base configuration; MODEL, with RTL-SIMULATION perf counters where an instrumented run exists)")
    w("")
    rows = []
    for r in d["conflicts"]:
        rtl_c = r.get("rtl_conf_per_bank")
        rows.append([r["ecc"], r["pattern_name"], r["model_conf_per_bank"], rtl_c if rtl_c else "-", r["model_busy_per_bank"], r["model_stall_per_master"],
                     f"{sum(r['model_stall_slot'])}/{sum(r['model_stall_bank_busy'])}/{sum(r['model_stall_arb'])}", r["rtl_stall_per_master"] if "rtl_stall_per_master" in r else "-",
                     "yes" if r.get("counters_equal") else "-"])
    w(md_table(["ECC", "pattern", "MODEL conflict cycles / bank", "RTL conflict cycles / bank", "MODEL busy stalls / bank", "MODEL stall cycles / master",
                "MODEL stall split slot/busy/arbitration", "RTL stall cycles / master", "RTL counters == MODEL"], rows))
    w("")
    w("Per-master stall cycles (`perf_stall`) are `valid && !ready` cycles; the MODEL splits them into no-free-slot, bank-busy (RMW) and lost-arbitration cycles. "
      "SAME_BANK concentrates all conflict on bank 0; OWN_BANK has none; SEQ_LINE only the start-up skew.")
    w("")
    w("**Fairness (O6)**, SAME_BANK, NM=4, finite 1000 requests per master (MODEL; the perf_stall counters of the instrumented fixed-priority runs equal the MODEL):")
    w("")
    rows = [[r["arb"], r["per_master_grants"], r["per_master_max_wait_grants"], [f"{x:.1f}" for x in r["per_master_mean_latency"]], [f"{x:.1f}" for x in r["analytic_mean_latency"]],
             r["per_master_stall_cycles"]] for r in d["fairness"]]
    w(md_table(["arbitration", "grants per master", "max grants of the bank given to others while waiting (MODEL)", "mean latency per master (MODEL; RTL: 6.0 RR, 4.5 mean FIXED)",
                "ANALYTICAL mean latency: RR NM+BL+1, FIXED BL+2+i", "stall cycles per master (MODEL)"], rows))
    w("")
    w("RR keeps the waiting bound NM-1 = 3 grants (contract O6 holds in this run); FIXED priority lets master 0 finish first and starves master 3 for ~3000 grants (contract: 'starvation possible').")
    w("")
    # ---------------------------------------------------------------- DMA
    w("## 4. DMA throughput and scalar/vector-versus-DMA contention")
    w("")
    dm = d["dma"]
    g = dm["rtl_row"]
    if g:
        w(f"RTL-SIMULATION (reports/bench_rtl.json `vector_dma`, tb_vector_scratchpad V6): {g['beats']}-beat DMA LOAD = {g['cycles_alone']} cycles alone "
          f"({dm['rtl_alone_beats_per_cycle']:.3f} beats/cycle, incl. a fixed TB start/finish overhead of {g['cycles_alone'] - g['beats']} cycles), "
          f"{g['cycles_with_vector']} cycles with concurrent vector traffic (+{dm['rtl_slip_cycles']}), {g['conflicts']} DMA/vector same-bank pulses counted by the scratchpad over the whole mixed interval.")
        w("")
        w("ANALYTICAL: the single DMA port moves at most one 16 B beat per cycle, i.e. 16 B/cycle = 1/NB of the 4-bank peak (64 B/cycle); consecutive lines rotate through the banks, so alone it is port-limited, not bank-limited.")
        w("")
        rows = [[f"{r['rho']:.2f}", f"{r['alone_cycles_model']}", f"{r['mean_slip']:.2f}", r["max_slip"], f"{r['mean_conflict_cycles']:.1f}", f"{r['mean_dma_lost_arbitration_cycles']:.2f}"] for r in dm["model_sweep"]]
        w("MODEL (exact controller model, 100 Monte-Carlo trials per row; competing master issues a random-bank request with probability rho per idle cycle; the vector TB's real timing is NOT modelled):")
        w("")
        w(md_table(["rho (competing issue rate)", "DMA cycles alone (MODEL, no TB overhead)", "mean slip [cycles]", "max slip", "mean conflict cycles in 64 beats", "DMA lost-arbitration cycles"], rows))
        w("")
        w("Reading: round-robin arbitration gives the DMA about half of the contested cycles, so even a competing master that issues EVERY cycle slows a 64-beat burst by only ~5 cycles (~8 %), and "
          "the conflict count at rho=1 (~15) is the same order as the 15 pulses of the RTL run. The RTL slip of +1 cycle corresponds to rho ~ 0.05-0.1 in the model; this is an INFERENCE from one data point "
          "(the vector stimulus overlaps only part of the DMA window and its timing is not reproduced), not a validation. DMA bandwidth is therefore bounded by the port, "
          "and a competing master costs the DMA at most about half of the cycles in which both want the same bank.")
    w("")
    # ---------------------------------------------------------------- tensor
    w("## 5. Tensor scratchpad: pipeline model, single vs double buffering, operand starvation")
    w("")
    w("### 5.1 Cycle model (tensor.py) vs RTL-SIMULATION, committed rows")
    w("")
    w("`cosim` = the exact controller model (4 ports A, B, C, DMA) + a transcription of the scratchpad ownership FSM and of the three TB processes (fill / compute / drain, half-cycle negedge handshakes). "
      "`phase model` = closed-form conflict-free durations (ANALYTICAL): fill Df = 3N+BL+2, drain Dd = N+BL+2, compute Dc = PASSES x (2(N+BL+2) + COMPUTE_EXTRA), a 3-cycle handshake gap per ownership change; "
      "NBUF=1: cycles/tile = Df + Dc + Dd + 9; NBUF=2: max(Dc + 3, Df + Dd + 7) when conflict free.")
    w("")
    rows = []
    for r in d["tensor"]["rows"]:
        rows.append([r["config"], r["rtl_total"], r["model_total"], r["rtl_cpt"], r["model_cpt"], f"{r['model_steady_period']:.1f}", r["steady_cpt"], r["bound"], r["phase_total"],
                     r["rtl_overlap"], r["model_overlap"], r["rtl_conf"], r["model_conf"]])
    w(md_table(["config", "RTL total", "MODEL total", "RTL cycles/tile (total/8)", "MODEL cycles/tile", "MODEL steady period (tiles 1..7)", "ANALYTICAL conflict-free steady period", "bound",
                "ANALYTICAL phase-model total", "RTL overlap", "MODEL overlap", "RTL conflict cycles", "MODEL conflict cycles"], rows))
    w("")
    r0 = next(r for r in d["tensor"]["rows"] if r["config"] == "nbuf2_skew1")
    r1 = next(r for r in d["tensor"]["rows"] if r["config"] == "nbuf1_skew1")
    r2 = next(r for r in d["tensor"]["rows"] if r["config"] == "nbuf2_skew0")
    r3 = next(r for r in d["tensor"]["rows"] if r["config"] == "nbuf1_skew0")
    r4 = next(r for r in d["tensor"]["rows"] if r["config"] == "nbuf2_ecc")
    w(f"**Explanation of the differences.** (i) MODEL co-simulation = RTL-SIMULATION in all 11 committed rows, and in every clock edge of the instrumented traces (5.2). "
      f"(ii) NBUF=1 is exactly the closed form ({r1['rtl_cpt']} = 27 + 66 + 11 + 9 cycles/tile for N=8, PASSES=3): nothing overlaps and there are no conflicts; `cycles_per_tile` = total/NTILES also contains the 5 trailing TB cycles. "
      f"(iii) NBUF=2 is compute-bound: the conflict-free steady period is {r0['steady_cpt']} cycles/tile but the exact model's steady period (tiles 1..7) is {r0['model_steady_period']:.0f}: the DMA fill/drain of the neighbouring tiles hits the "
      f"same banks as the A/B/C streams and the {r0['rtl_conf']} conflict cycles delay the compute passes (+{r0['model_steady_period'] - r0['steady_cpt']:.0f} cycles, {100*(r0['model_steady_period']/r0['steady_cpt'] - 1):.1f} %). "
      f"The remaining {r0['rtl_cpt'] - r0['model_steady_period']:.0f} cycles/tile of the printed {r0['rtl_cpt']} are pipeline start-up and tail (first fill {r0['model_first_fill_edges']} cycles exposed + last drain + 5 TB cycles, amortised over only 8 tiles): "
      f"the TB's `cycles_per_tile` is not the steady-state period. "
      f"(iv) SKEW=0 puts A, B and C on the same bank sequence: {r2['rtl_conf']} vs {r0['rtl_conf']} conflict cycles (double) and {r3['rtl_conf']} vs {r1['rtl_conf']} (single), +{r2['rtl_cpt'] - r0['rtl_cpt']} / +{r3['rtl_cpt'] - r1['rtl_cpt']} cycles per tile "
      f"({r2['rtl_cpt']} vs {r0['rtl_cpt']}, {r3['rtl_cpt']} vs {r1['rtl_cpt']}) - the skew is worth ~5 %. (v) ECC adds one BANK_LAT cycle to every response: +{r4['rtl_cpt'] - r0['rtl_cpt']} cycles/tile ({r4['rtl_cpt']} vs {r0['rtl_cpt']}). "
      "(vi) COMPUTE_EXTRA adds ~PASSES x extra cycles per tile in both modes; with larger compute the conflict stalls shrink (25 vs 62 cycles) because DMA and compute overlap less.")
    w("")
    w("### 5.2 Extra RTL-SIMULATION tensor runs (instrumented copies; MODEL compared per clock edge)")
    w("")
    if ex:
        rows = []
        for r in ex["tensor_rows"]:
            rows.append([r["config"], "committed" if r["committed"] else "extra", r["rtl"]["total_cycles"], r["model"]["total_cycles"], r["rtl"]["bank_conflict_cycles"], r["model"]["bank_conflict_cycles"],
                         "yes" if r["trace_identical"] else "NO", r["trace_edges"], "yes" if r["stats_match"] else "NO (see note)", r["rtl_te_wait_edges"], r["model_te_wait_edges"]])
        w(md_table(["config", "set", "RTL total", "MODEL total", "RTL conflict cyc (TB print)", "MODEL conflict cyc", "per-edge trace identical", "edges", "stats equal", "RTL edges te_req && !te_owned", "MODEL same"], rows))
        w("")
        nb2 = [r for r in ex["tensor_rows"] if r["rtl"]["bank_conflict_cycles"] != r["model"]["bank_conflict_cycles"]]
        for r in nb2:
            w(f"*Note {r['config']}:* the per-edge trace is identical, yet the TB prints {r['rtl']['bank_conflict_cycles']} conflict cycles vs MODEL {r['model']['bank_conflict_cycles']}. "
              f"Root cause (TB, not RTL, not model): tb/tb_tensor_scratchpad.sv:375-376 and 384-385 add four 32-bit slices of `perf_conf` / `perf_busy` regardless of NB; with NB = 2 the signal is 64 bits wide, "
              f"the two out-of-range slices alias the real ones in Verilator, so every bank is counted twice (raw counter dump of this run: `perf_conf` = 0x{r.get('conf_raw', '?')}: bank0 = 0x170 cumulative, bank1 = 0; "
              f"the pipeline-window delta of bank0 is {r['model']['bank_conflict_cycles']} = MODEL, printed 2 x {r['model']['bank_conflict_cycles']} = {r['rtl']['bank_conflict_cycles']}). The committed tensor rows all use NB = 4 and are unaffected.")
        w("")
    w("### 5.3 Operand starvation (ANALYTICAL curves vs MODEL co-simulation)")
    w("")
    sv = d["starvation"]
    w("Definition: the TensorCore is starved when it has requested a tile (`te_req` = 1) and no buffer is READY, beyond the minimum ownership handshake (1 cycle in steady state). "
      "ANALYTICAL steady state (`tensor.starvation`), NBUF=2: the DMA port carries fill(t+1) (3N writes) and drain(t-1) (N reads) during compute(t): "
      "t_fill = (3N-1)/beta + BL + 3, t_drain = (N-1)/beta + BL + 3, T_dma = t_fill + t_drain + 1, period = max(T_c + 3, T_dma), stall = max(0, T_dma - T_c - 3), starved fraction = stall / period. "
      "NBUF=1: every DMA cycle is exposed (stall = t_fill + t_drain + 9). beta = DMA bandwidth share: the DMA port issues at most 1 line/cycle (= 25 % of the 4-bank peak); a lower beta "
      "models a slower bus or a smaller bank-bandwidth share and is throttled in the MODEL only (DMA request issued every k = 1/beta cycles). "
      f"Agreement ANALYTICAL vs MODEL over all {len(sv['points'])} sweep points: mean |difference| of the starved fraction {sv['mean_abs_frac_difference_model_vs_analytic']:.3f}, maximum {sv['max_abs_frac_difference_model_vs_analytic']:.3f} "
      "(the formula ignores the bank conflicts that the MODEL includes).")
    w("")
    rows = [[c["n"], f"{c['beta']:g}", f"{c['t_dma']:.0f}", f"{c['min_compute_cycles_for_no_starvation']:.0f}"] for c in sv["crossover"]]
    w(md_table(["N (lines/operand tile)", "DMA beat rate beta [lines/cycle]", "T_dma [cycles/tile] (ANALYTICAL)", "compute cycles/tile above which the prefetch is fully hidden"], rows))
    w("")
    rows = []
    for p_ in sv["points"]:
        if (p_["n"] == 8 and p_["compute_extra"] in (0, 16, 48, 96)) or (p_["n"] == 16 and p_["compute_extra"] in (0, 48, 128)):
            if p_["dma_every"] in (1, 2, 4, 8):
                rows.append([p_["n"], p_["dma_every"], f"{p_['beta']:.3g}", p_["compute_cycles"], f"{p_['analytic_frac']:.3f}", f"{p_['model_frac']:.3f}", f"{p_['analytic_period']:.0f}", f"{p_['model_period']:.0f}"])
    w("N = 8 and N = 16 (MODEL co-simulation vs ANALYTICAL; the ANALYTICAL period ignores bank conflicts):")
    w("")
    w(md_table(["N", "DMA issue every k cycles", "beta", "compute cycles/tile", "ANALYTICAL starved fraction", "MODEL starved fraction", "ANALYTICAL period", "MODEL period (steady)"], rows))
    w("")
    n8 = TN.TCfg()
    ph8 = TN.phase_times(n8)
    t_hidden = TN.starvation(8, 1, 1.0)["t_dma"] - TN.GAP
    beta_min = TN.min_beta_for_hidden_prefetch(8, ph8["Dc"], n8.bank_lat)
    ss = TN.starvation(8, ph8["Dc"], 1.0, nbuf=1)
    w(f"Findings: with the benchmark's full-rate DMA (beta = 1, N = 8) the double-buffered pipeline is compute-bound as soon as the compute phase lasts >= {t_hidden:.0f} cycles per tile "
      f"(PASSES=3: Dc = {ph8['Dc']}), so the TensorCore is not starved; with PASSES=1 (Dc = {TN.phase_times(TN.TCfg(passes=1))['Dc']}) it is DMA-bound. "
      f"With Dc = {ph8['Dc']} the DMA may slow down to beta >= {beta_min:.2f} lines/cycle (half the port rate) before the TensorCore starts to wait. "
      f"Single buffering exposes the whole fill + drain: {pct(ss['starved_fraction'])} of the tile time at N=8, PASSES=3 (ANALYTICAL; equals the RTL split 113 = 66 compute + 47 DMA / handshake). "
      "Plot: `sramlab_starvation.svg`. The RTL te_req-without-grant edges (table 5.2) are the handshake minimum plus the exposed first fill, consistent with a non-starved double-buffered pipeline.")
    w("")
    # ---------------------------------------------------------------- findings
    w("## 6. Findings, RTL / TB / documentation issues, limitations")
    w("")
    w("**Findings**")
    w("")
    hl = d["headline"]
    fs = [
        f"The controller + bank behaviour is fully captured by the cycle model (tools/sramlab/model.py): {v['exact_match_all_stats']}/{v['rows']} committed rows and {ex['controller_exact'] if ex else '-'}/{ex['controller_runs'] if ex else '-'} extra runs match exactly (statistics, per-edge masks, perf counters).",
        f"Peak 64 B/cycle (4 banks x 16 B) is reached: SEQ_LINE {hl['peak_seq_line']['rtl_Bpc']:.2f} B/c = {pct(hl['peak_seq_line']['eff'])} of the ceiling; OWN_BANK {hl['own_bank']['rtl_Bpc']:.2f}; SAME_BANK {hl['single_bank']['rtl_Bpc']:.2f} B/c = the single-bank 16 B/c.",
        f"Random 16 B reads reach {hl['random_read']['rtl_Bpc']:.2f} B/c = {pct(hl['random_read']['eff'])} of the exact head-of-line ceiling ({hl['random_read']['ceil_Bpc']:.2f} B/c) and only 64 % of the 64 B/c peak: "
        "persistent requests block masters; more banks than masters help (NB=8: ~3.3 acc/c vs 2.6 for NB=4), more masters than banks do not.",
        "The NSLOT >= BANK_LAT+2 contract rule is exact: NSLOT=2 delivers 2/3 of the full rate (42.55 vs 42.67 B/c ceiling), NSLOT >= 3 delivers the full rate; "
        "response back-pressure caps each master at the response-ready probability.",
        "ECC costs one latency cycle and, for partial writes only, 1/(RL+1) of the bank bandwidth (the RMW occupies the bank RL+1 cycles); reads and full-line writes are not slowed.",
        (lambda r0, r1: f"Tensor pipeline: double buffering is compute-bound; the fill/drain DMA is fully hidden but the DMA/TensorCore bank conflicts stretch the steady period from {r0['steady_cpt']} to {r0['model_steady_period']:.0f} cycles/tile "
                        f"({100*(r0['model_steady_period']/r0['steady_cpt'] - 1):.0f} %); the printed {r0['rtl_cpt']} cycles/tile vs {r1['rtl_cpt']} (single buffer) also contains the 8-tile start-up; skew = 1 saves ~5 %.")(
            next(r for r in d["tensor"]["rows"] if r["config"] == "nbuf2_skew1"), next(r for r in d["tensor"]["rows"] if r["config"] == "nbuf1_skew1")),
        "Scalar 4 B accesses are architecturally expensive: a 4 B load costs a whole 16 B bank access (4x energy and bank time per useful byte); benchmark A originally also suffered from ALIGN errors in the TB (fixed, see below).",
    ]
    for x in fs:
        w(f"* {x}")
    w("")
    w("**RTL / TB / documentation issues found by this validation** (status in the current revision)")
    w("")
    iss = [
        "FIXED - tb/tb_bench_ctrl.sv pattern 0 (SEQ_SCALAR4): generated byte-strided sub-line addresses against an ALIGN_MODE=1 controller; 3 of 4 requests were answered SF_ST_ALIGN without an array access, "
        "so benchmark A's 15.92 B/cycle credited useful bytes to rejected requests (RTL counters: 3000 error responses, 1000 array accesses). The TB now issues line-aligned reads; the old pattern is kept in the model only as pattern 9.",
        "FIXED (documentation) - tb/tb_bench_ctrl.sv header: `max_outstanding` is MASTER 0's maximum (max_out[0]), not a per-master maximum; the header now says so.",
        "FIXED - tb/tb_tensor_scratchpad.sv: bank_conflict_cycles / bank_busy_stalls added 4 slices of perf_conf / perf_busy irrespective of NB (NB=2 printed 670 instead of 335); now sums NB slices. All committed rows use NB=4 and were not affected.",
        "FIXED (documentation) - rtl/sf_sram_controller.sv header: m_req_ready depends on registered state AND on the other masters' requests through the arbiter (never on rsp_ready); perf_conf comment now states which requests are not counted.",
        "OPEN (by design) - tb/tb_tensor_scratchpad.sv `cycles_per_tile` = total_cycles / NTILES includes the pipeline start-up, the last drain and 5 trailing cycles, so it is not the steady-state period (78 printed vs 73 steady for NBUF=2, N=8). The steady-state value is derived in section 6.",
    ]
    for x in iss:
        w(f"* {x}")
    w("")
    w("**Limitations / not done**")
    w("")
    w("* Only the behavioural backend is modelled (BACKEND = SF_BACKEND_BEHAV); flush, quiesce, MBIST, scrub and init timing are not modelled (not exercised by the benchmark).")
    w("* The vector-scratchpad DMA experiment is modelled only parametrically (section 4); the vector TB's stimulus timing is not reproduced.")
    w("* The starvation model with beta < 1 throttles the DMA in the MODEL only: there is no RTL run with a slower DMA.")
    w("* Energy numbers live in reports/sramlab_energy.md and are ASSUMED-PARAMETER MODEL results (the repository has no SRAM Liberty/SPICE power data).")
    w("")
    return "\n".join(L)


def write_all(bench: dict, extra: dict | None, log=print) -> dict:
    d = collect(bench, extra)
    os.makedirs(REPORTS, exist_ok=True)
    files = make_plots(d, REPORTS)
    md = render_md(d)
    with open(os.path.join(REPORTS, "sramlab_vs_rtl.md"), "w") as fh:
        fh.write(md)
    slim = {k: v for k, v in d.items() if k != "extra_rtl"}
    if d["extra_rtl"]:
        e = dict(d["extra_rtl"])
        e["controller_rows"] = [{k: v for k, v in r.items() if k not in ("trace_first_difference",)} for r in e["controller_rows"]]
        slim["extra_rtl"] = e
    with open(os.path.join(REPORTS, "sramlab_vs_rtl.json"), "w") as fh:
        json.dump({"label": "tools/sramlab: MODEL / ANALYTICAL results next to RTL-SIMULATION results (reports/bench_rtl.json). Not silicon measurements.", **slim}, fh, indent=1, default=str)
    with open(os.path.join(REPORTS, "sramlab_vs_rtl.csv"), "w", newline="") as fh:
        wr = csv.writer(fh)
        wr.writerow(["experiment", "config", "pattern", "rsp_pct", "load_pct", "RTL_SIMULATION_Bpc", "MODEL_Bpc", "ANALYTICAL_ceiling_Bpc", "efficiency_RTL_over_ceiling", "RTL_mean_latency", "RTL_cycles", "MODEL_equals_RTL_7_of_7"])
        vm = {i: r["match"] for i, r in enumerate(d["validation"]["rows"])}
        for i, r in enumerate(d["ceilings"]):
            wr.writerow([r["experiment"], r["config"], r["pattern_name"], r["rsp_pct"], r["load_pct"], r["rtl_Bpc"], r["model_Bpc"], round(r["ceil_Bpc"], 4),
                         round(r["eff"], 4) if r["eff"] is not None else "", r["rtl_mean_latency"], r["rtl_cycles"], vm[i]])
    log(f"wrote {REPORTS}/sramlab_vs_rtl.md/.json/.csv and {len(files)} SVG plots")
    return d
