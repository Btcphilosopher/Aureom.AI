"""Tiny dependency-free SVG line / scatter plotter (matplotlib is not available in this environment).

Every plot carries a title that states the provenance of the plotted numbers (RTL-SIMULATION / MODEL / ANALYTICAL /
ASSUMED-PARAMETER); series names carry the same tags.  Colours are fixed hex values with a white card background so the
SVG renders identically in light and dark viewers.
"""
from __future__ import annotations

import math
import textwrap
from xml.sax.saxutils import escape

PALETTE = ["#1f6feb", "#d1242f", "#1a7f37", "#9a6700", "#8250df", "#0b7285", "#bf3989", "#57606a"]
MARKERS = ["circle", "square", "diamond", "triangle", "cross", "plus"]


def _nice_ticks(lo: float, hi: float, n: int = 6):
    if hi <= lo:
        hi = lo + 1.0
    span = hi - lo
    step = 10 ** math.floor(math.log10(span / n))
    for m in (1, 2, 2.5, 5, 10):
        if span / (step * m) <= n:
            step *= m
            break
    t0 = math.floor(lo / step) * step
    out = []
    v = t0
    while v <= hi + 1e-9 * step:
        if v >= lo - 1e-9 * step:
            out.append(round(v, 10))
        v += step
    return out


def _log_ticks(lo: float, hi: float):
    a, b = math.floor(math.log10(lo)), math.ceil(math.log10(hi))
    return [10.0 ** k for k in range(a, b + 1)]


def _marker(kind: str, x: float, y: float, c: str, s: float = 4.0) -> str:
    if kind == "square":
        return f'<rect x="{x-s:.1f}" y="{y-s:.1f}" width="{2*s:.1f}" height="{2*s:.1f}" fill="{c}" fill-opacity="0.85"/>'
    if kind == "diamond":
        return f'<polygon points="{x:.1f},{y-s-1:.1f} {x+s+1:.1f},{y:.1f} {x:.1f},{y+s+1:.1f} {x-s-1:.1f},{y:.1f}" fill="{c}" fill-opacity="0.85"/>'
    if kind == "triangle":
        return f'<polygon points="{x:.1f},{y-s-1:.1f} {x+s+1:.1f},{y+s:.1f} {x-s-1:.1f},{y+s:.1f}" fill="{c}" fill-opacity="0.85"/>'
    if kind == "cross":
        return f'<path d="M{x-s:.1f},{y-s:.1f} L{x+s:.1f},{y+s:.1f} M{x-s:.1f},{y+s:.1f} L{x+s:.1f},{y-s:.1f}" stroke="{c}" stroke-width="2" fill="none"/>'
    if kind == "plus":
        return f'<path d="M{x-s:.1f},{y:.1f} L{x+s:.1f},{y:.1f} M{x:.1f},{y-s:.1f} L{x:.1f},{y+s:.1f}" stroke="{c}" stroke-width="2" fill="none"/>'
    return f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{s:.1f}" fill="{c}" fill-opacity="0.85"/>'


class Plot:
    def __init__(self, title: str, xlabel: str, ylabel: str, width: int = 880, height: int = 520,
                 xlog: bool = False, ylog: bool = False, subtitle: str = ""):
        self.title, self.xlabel, self.ylabel, self.subtitle = title, xlabel, ylabel, subtitle
        self.w, self.h = width, height
        self.xlog, self.ylog = xlog, ylog
        self.series = []
        self.xlim = self.ylim = None
        self.notes: list[str] = []

    def add(self, name: str, xs, ys, kind: str = "line+marker", color: str | None = None, marker: str | None = None, dash: str | None = None):
        i = len(self.series)
        self.series.append(dict(name=name, xs=list(xs), ys=list(ys), kind=kind, color=color or PALETTE[i % len(PALETTE)],
                                marker=marker or MARKERS[i % len(MARKERS)], dash=dash))

    def note(self, text: str):
        self.notes.append(text)

    def _range(self, vals, log, lim):
        vals = [v for v in vals if v is not None and (v > 0 or not log)]
        lo, hi = (min(vals), max(vals)) if vals else (0, 1)
        if lim:
            lo, hi = lim
        elif not log:
            pad = 0.05 * (hi - lo if hi > lo else 1)
            lo = 0 if lo >= 0 and lo < 0.35 * hi else lo - pad
            hi = hi + pad
        else:
            lo, hi = lo / 1.3, hi * 1.3
        return lo, hi

    def svg(self) -> str:
        tl = textwrap.wrap(self.title, 96) or [""]
        sl = textwrap.wrap(self.subtitle, 130) if self.subtitle else []
        nrow = max(1, math.ceil(len(self.series) / 2))
        nnote = math.ceil(len(self.notes) / 2)
        ml, mr, mt, mb = 72, 24, 22 + 18 * len(tl) + 14 * len(sl) + 14, 64 + 18 * nrow + 13 * nnote + (8 if nnote else 0)
        W, H = self.w, self.h + 18 * nrow + 13 * nnote
        pw, ph = W - ml - mr, H - mt - mb
        allx = [x for s in self.series for x in s["xs"]]
        ally = [y for s in self.series for y in s["ys"]]
        x0, x1 = self._range(allx, self.xlog, self.xlim)
        y0, y1 = self._range(ally, self.ylog, self.ylim)

        def sx(v):
            if self.xlog:
                return ml + (math.log10(v) - math.log10(x0)) / (math.log10(x1) - math.log10(x0)) * pw
            return ml + (v - x0) / (x1 - x0) * pw

        def sy(v):
            if self.ylog:
                return mt + ph - (math.log10(v) - math.log10(y0)) / (math.log10(y1) - math.log10(y0)) * ph
            return mt + ph - (v - y0) / (y1 - y0) * ph

        o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" font-family="Helvetica,Arial,sans-serif">',
             f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
             ]
        for i, t in enumerate(tl):
            o.append(f'<text x="{ml}" y="{22 + 18 * i}" font-size="15" font-weight="bold" fill="#1f2328">{escape(t)}</text>')
        for i, t in enumerate(sl):
            o.append(f'<text x="{ml}" y="{22 + 18 * len(tl) + 14 * i}" font-size="11" fill="#57606a">{escape(t)}</text>')
        xt = _log_ticks(x0, x1) if self.xlog else _nice_ticks(x0, x1)
        yt = _log_ticks(y0, y1) if self.ylog else _nice_ticks(y0, y1)
        for t in yt:
            if y0 <= t <= y1:
                y = sy(t)
                o.append(f'<line x1="{ml}" y1="{y:.1f}" x2="{ml+pw}" y2="{y:.1f}" stroke="#d0d7de" stroke-width="1"/>')
                o.append(f'<text x="{ml-8}" y="{y+4:.1f}" font-size="11" text-anchor="end" fill="#57606a">{t:g}</text>')
        for t in xt:
            if x0 <= t <= x1:
                x = sx(t)
                o.append(f'<line x1="{x:.1f}" y1="{mt}" x2="{x:.1f}" y2="{mt+ph}" stroke="#eaeef2" stroke-width="1"/>')
                o.append(f'<text x="{x:.1f}" y="{mt+ph+16}" font-size="11" text-anchor="middle" fill="#57606a">{t:g}</text>')
        o.append(f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" fill="none" stroke="#8c959f"/>')
        o.append(f'<text x="{ml+pw/2}" y="{mt+ph+36}" font-size="12" text-anchor="middle" fill="#1f2328">{escape(self.xlabel)}</text>')
        o.append(f'<text x="16" y="{mt+ph/2}" font-size="12" text-anchor="middle" fill="#1f2328" transform="rotate(-90 16 {mt+ph/2})">{escape(self.ylabel)}</text>')
        for s in self.series:
            pts = [(sx(x), sy(y)) for x, y in zip(s["xs"], s["ys"]) if y is not None and (not self.ylog or y > 0) and (not self.xlog or x > 0)]
            if "line" in s["kind"] and len(pts) > 1:
                dash = f' stroke-dasharray="{s["dash"]}"' if s["dash"] else ""
                o.append('<polyline fill="none" stroke="%s" stroke-width="1.8"%s points="%s"/>' % (s["color"], dash, " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)))
            if "marker" in s["kind"] or s["kind"] == "scatter":
                for x, y in pts:
                    o.append(_marker(s["marker"], x, y, s["color"]))
        # legend
        ly = mt + ph + 52
        for i, s in enumerate(self.series):
            col, row = i % 2, i // 2
            lx = ml + col * (pw / 2)
            yy = ly + row * 18
            if "line" in s["kind"]:
                dash = f' stroke-dasharray="{s["dash"]}"' if s["dash"] else ""
                o.append(f'<line x1="{lx}" y1="{yy-4}" x2="{lx+22}" y2="{yy-4}" stroke="{s["color"]}" stroke-width="1.8"{dash}/>')
            if "marker" in s["kind"] or s["kind"] == "scatter":
                o.append(_marker(s["marker"], lx + 11, yy - 4, s["color"], 3.5))
            o.append(f'<text x="{lx+28}" y="{yy}" font-size="11" fill="#1f2328">{escape(s["name"])}</text>')
        for j, n in enumerate(self.notes):
            col, row = j % 2, j // 2
            o.append(f'<text x="{ml + col * (pw / 2)}" y="{ly + 18 * nrow + 4 + 13 * row}" font-size="10" fill="#57606a">{escape(n)}</text>')
        o.append("</svg>")
        return "\n".join(o)

    def save(self, path: str):
        with open(path, "w") as f:
            f.write(self.svg())
