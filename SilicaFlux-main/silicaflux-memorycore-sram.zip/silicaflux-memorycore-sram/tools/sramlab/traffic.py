"""Workload generator that reproduces tb/tb_bench_ctrl.sv EXACTLY.

Everything here is a transcription of the TB (function `gen`, `xs`, the per-master seed, the
LOAD_PCT / RSP_PCT decision functions).  It is a PURE FUNCTION of (pattern, master, index, seed);
nothing is fitted.  Where the TB header comment and the TB code disagree the CODE is followed and
the disagreement is listed in NOTES (see `tests/test_traffic.py` for the checks).

Conventions (copied from the TB header)
  line  = 16 B line index, bank = line % NB, row = line // NB
  REGION = CAP_LINES // NM (integer), base_m = m * REGION
  the k-th request of master m uses the k-th xorshift32 draw of that master (the draw is consumed
  by EVERY pattern, used or not) -- the draw handed to gen() is the NEW state (post xs()).
  `cycle` in the TB is a 64-bit edge counter; the LOAD_PCT / RSP_PCT hash functions use cycle[31:0].
"""
from __future__ import annotations

from dataclasses import dataclass

M32 = 0xFFFFFFFF
LB = 4                     # log2(16 B line)
AW = 20                    # TB address width
BE_FULL = 0xFFFF
BE_PART4 = 0x000F

PATTERN_NAMES = {0: "SEQ_SCALAR4", 1: "SEQ_LINE", 2: "OWN_BANK", 3: "SAME_BANK", 4: "RANDOM_LINE",
                 5: "RANDOM_RW", 6: "SEQ_WRITE_FULL", 7: "SEQ_WRITE_PART4", 8: "RANDOM_PART4",
                 9: "MODEL_ONLY_SCALAR_BYTE_STRIDE"}

NOTES = [
    "Pattern 0 (SEQ_SCALAR4) was changed in this revision: the earlier TB issued byte-strided sub-line addresses that the default "
    "ALIGN_MODE=1 controller answered with SF_ST_ALIGN for 3 of 4 requests (benchmark A then measured rejected requests). It now issues "
    "line-aligned reads, 4 consecutive loads per line, 4 useful bytes each, masters staggered by one line (= one bank): line = base_m + ((k/4 + m) mod REGION).",
    "Pattern 9 exists only in this model: the ORIGINAL byte-strided pattern (exercises the ALIGN error path of the model; the TB has no "
    "such pattern).",
]


def xs(x: int) -> int:
    """xorshift32 (13, 17, 5), exactly the TB function `xs`."""
    x &= M32
    y = x ^ ((x << 13) & M32)
    y ^= y >> 17
    y ^= (y << 5) & M32
    return y & M32


def master_seed(seed: int, m: int) -> int:
    """rs[m] = seed_v ^ (32'(m+1) * 32'h9E3779B9)."""
    return (seed ^ (((m + 1) * 0x9E3779B9) & M32)) & M32


def load_gate(cycle: int, m: int, load_pct: int) -> bool:
    """`(load_pct >= 100) || ((xs(cycle[31:0]*32'd2654435 ^ (32'(m)<<16) ^ 32'h5A5A5A5A) % 100) < load_pct)`.
    The product wraps at 32 bits (all operands are 32 bit in the TB expression)."""
    if load_pct >= 100:
        return True
    arg = (((cycle & M32) * 2654435) & M32) ^ ((m << 16) & M32) ^ 0x5A5A5A5A
    return (xs(arg) % 100) < load_pct


def rsp_ready_draw(cycle: int, m: int, rsp_pct: int) -> bool:
    """`(rsp_pct >= 100) ? 1 : (xs(cycle[31:0] ^ (32'(m) << 8)) % 100) < rsp_pct`."""
    if rsp_pct >= 100:
        return True
    return (xs((cycle & M32) ^ ((m << 8) & M32)) % 100) < rsp_pct


@dataclass(frozen=True)
class Req:
    we: bool
    addr: int      # byte address (20 bit)
    be: int        # 16-bit byte enables (1s for reads: the TB leaves be = '1)
    useful: int    # useful bytes credited by the TB to this request


def gen(pat: int, m: int, k: int, draw: int, nb: int, depth: int, nm: int) -> Req:
    """Transcription of the TB function `gen`."""
    cap = nb * depth
    region = cap // nm
    base = m * region
    we = False
    be = BE_FULL
    useful = 16
    a = None
    if pat == 0:               # line-aligned 4 B scalar loads (4 consecutive loads share a line); the TB was changed to this
        ln = base + ((k // 4 + m) % region)
        useful = 4
    elif pat == 9:             # MODEL-ONLY (no TB counterpart): the ORIGINAL byte-strided scalar pattern, sub-line addresses
        a = ((base * 16) + ((4 * k) % (region * 16))) & ((1 << AW) - 1)
        useful = 4
        ln = a >> LB
    elif pat == 1:
        ln = base + (k % region)
    elif pat == 2:
        ln = (k * nb + (m % nb)) % cap
    elif pat == 3:
        ln = ((k + m * 37) * nb) % cap
    elif pat == 4:
        ln = draw % cap
    elif pat == 5:
        we = bool(draw & 1)
        ln = (draw >> 1) % cap
    elif pat == 6:
        we = True
        ln = base + (k % region)
    elif pat == 7:
        we = True
        ln = base + (k % region)
        be = BE_PART4
        useful = 4
    else:                      # the TB `default` branch = pattern 8
        we = bool(draw & 1)
        ln = (draw >> 1) % cap
        if we:
            be = BE_PART4
        useful = 4
    if pat != 9:
        a = (ln << LB) & ((1 << AW) - 1)
    return Req(we, a, be, useful)


class MasterStream:
    """Request stream of one master: call next() to get the k-th request (consumes one PRNG draw)."""

    def __init__(self, pat: int, m: int, nm: int, nb: int, depth: int, seed: int):
        self.pat, self.m, self.nm, self.nb, self.depth = pat, m, nm, nb, depth
        self.state = master_seed(seed, m)
        self.k = 0

    def next(self) -> Req:
        self.state = xs(self.state)
        r = gen(self.pat, self.m, self.k, self.state, self.nb, self.depth, self.nm)
        self.k += 1
        return r


def stream(pat: int, m: int, nm: int, nb: int, depth: int, seed: int, n: int) -> list[Req]:
    s = MasterStream(pat, m, nm, nb, depth, seed)
    return [s.next() for _ in range(n)]


def decode(addr: int, nb: int, depth: int, align_mode: int = 1):
    """Controller address decode: returns (err_status, bank, row).  err_status: 0 ok, 1 RANGE, 2 ALIGN."""
    line = addr >> LB
    if line >= nb * depth:
        return 1, 0, 0
    if align_mode and (addr & ((1 << LB) - 1)):
        return 2, 0, 0
    return 0, line % nb, line // nb


def is_partial(req: Req) -> bool:
    return req.we and req.be != 0 and req.be != BE_FULL
