"""Re-run the RTL benchmark under Verilator for EXTRA data points (RTL-SIMULATION, labelled as such).

The original TB (tb/tb_bench_ctrl.sv) is read-only.  `make_instrumented_tb` writes a mechanically patched COPY
into build/sramlab_work/ that
  * adds a parameter ALIGN_MODE (default 1 = identical to the original) passed to the controller,
  * adds a per-edge trace   `TR <edge> <accept mask> <pop mask> <bank-accept mask>`  (+TRACE=1),
  * adds a `BENCHX` line with the controller's own performance counters (per-bank acc/conf/busy, per-master stall),
    the number of non-OK responses and c_start / c_end.
The workload, the cycle convention and the BENCH line are untouched, so a BENCH line from the copy is directly
comparable with the original (the test-suite checks that).
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))                       # project root P
WORK = os.path.join(ROOT, "build", "sramlab_work")
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME"]

_REPL = [
    ("  parameter int SEED = 32'h00C0FFEE\n);",
     "  parameter int SEED = 32'h00C0FFEE,\n  parameter int ALIGN_MODE = 1\n);"),
    ("  logic [NB*STORE_W-1:0] tst_rdata;\n",
     "  logic [NB*STORE_W-1:0] tst_rdata;\n  logic [NB-1:0] bank_acc;\n"),
    (".NSLOT(NSLOT), .ARB(ARB), .INIT_ON_RESET(1), .SIM_INIT(2)) dut (",
     ".NSLOT(NSLOT), .ARB(ARB), .ALIGN_MODE(ALIGN_MODE), .INIT_ON_RESET(1), .SIM_INIT(2)) dut ("),
    (".bank_acc_o()", ".bank_acc_o(bank_acc)"),
    ("  // ---------------------------------------------------------------- drivers / monitors\n",
     """  // ---- sramlab instrumentation (NOT in the original TB) ------------------------------------------------------
  int x_err = 0, x_trace = 0;
  initial void'($value$plusargs("TRACE=%d", x_trace));
  always @(posedge clk) if (rst_n && started) begin
    logic [NM-1:0] am, pm;
    am = m_req_valid & m_req_ready; pm = m_rsp_valid & m_rsp_ready;
    for (int m = 0; m < NM; m++) if (pm[m] && m_rsp_status[m*3 +: 3] != 3'd0) x_err++;
    if (x_trace != 0) $display("TR %0d %0h %0h %0h", cycle, am, pm, bank_acc);
  end
  // ---------------------------------------------------------------- drivers / monitors
"""),
    ('      $display("RESULT tb=bench_ctrl pattern=%0d checks=%0d errors=0 PASS", pat, lat_n);',
     """      $write("BENCHX c_start=%0d c_end=%0d err_rsp=%0d align_mode=%0d", c_start, c_end, x_err, ALIGN_MODE);
      for (int b = 0; b < NB; b++) $write(" acc%0d=%0d conf%0d=%0d busy%0d=%0d", b, perf_acc[b*32 +: 32], b, perf_conf[b*32 +: 32], b, perf_busy[b*32 +: 32]);
      for (int m = 0; m < NM; m++) $write(" stall%0d=%0d maxout%0d=%0d", m, perf_stall[m*32 +: 32], m, max_out[m]);
      $write("\\n");
      $display("RESULT tb=bench_ctrl pattern=%0d checks=%0d errors=0 PASS", pat, lat_n);"""),
]


def make_instrumented_tb(dst: str | None = None) -> str:
    src = os.path.join(ROOT, "tb", "tb_bench_ctrl.sv")
    dst = dst or os.path.join(WORK, "tb_bench_ctrl_x.sv")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    txt = open(src).read()
    for old, new in _REPL:
        if txt.count(old) != 1:
            raise RuntimeError(f"instrumentation anchor not found exactly once (TB changed?): {old[:60]!r}")
        txt = txt.replace(old, new)
    open(dst, "w").write(txt)
    return dst


def _sh(cmd, cwd=ROOT, timeout=3600):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr


def build(tag: str, over: dict, tb: str | None = None) -> str:
    """Verilator build of the (instrumented) bench TB; returns the executable path."""
    tb = tb or make_instrumented_tb(os.path.join(WORK, f"tb_bench_ctrl_x_{tag}.sv"))        # one file per build: parallel builds must not rewrite a shared file
    bdir = os.path.join(WORK, "bench_" + tag)
    shutil.rmtree(bdir, ignore_errors=True)
    cmd = ["verilator"] + VFLAGS + ["-f", "sim/files_rtl.f", tb, "--top-module", "tb_bench_ctrl", "-Mdir", bdir, "-o", "t.exe"] + \
          [f"-G{k}={v}" for k, v in over.items()]
    rc, out = _sh(cmd)
    if rc != 0:
        raise RuntimeError(f"verilator build {tag} failed:\n{out[-800:]}")
    return os.path.join(bdir, "t.exe")


def _num(v):
    if re.fullmatch(r"-?\d+\.\d+", v):
        return float(v)
    if re.fullmatch(r"-?\d+", v):
        return int(v)
    return v


def run(exe: str, pattern: int, nreq: int = 1000, extra: dict | None = None, trace: bool = False) -> dict:
    args = [exe, f"+PATTERN={pattern}", f"+NREQ={nreq}"] + [f"+{k}={v}" for k, v in (extra or {}).items()]
    if trace:
        args.append("+TRACE=1")
    rc, out = _sh(args, timeout=900)
    res: dict = {"rc": rc, "pass": any(l.startswith("RESULT") and l.rstrip().endswith("PASS") for l in out.splitlines()), "trace": []}
    for l in out.splitlines():
        if l.startswith("BENCH ctrl "):
            res["bench"] = {k: _num(v) for k, v in re.findall(r"(\w+)=([-\w.]+)", l)}
        elif l.startswith("BENCHX "):
            res["benchx"] = {k: _num(v) for k, v in re.findall(r"(\w+)=([-\w.]+)", l)}
        elif l.startswith("TR "):
            _, e, am, pm, ba = l.split()
            res["trace"].append((int(e), int(am, 16), int(pm, 16), int(ba, 16)))
    return res


def build_many(items: dict[str, dict], jobs: int = 3) -> dict[str, str]:
    """items: tag -> parameter overrides.  Builds in parallel."""
    with ThreadPoolExecutor(jobs) as ex:
        futs = {t: ex.submit(build, t, o) for t, o in items.items()}
        return {t: f.result() for t, f in futs.items()}


# ------------------------------------------------------------------------------------------------ tensor scratchpad TB
_TREPL = [
    ("  logic [NB*STORE_W-1:0] tst_rdata;\n", "  logic [NB*STORE_W-1:0] tst_rdata;\n  logic [NB-1:0] bank_acc;\n"),
    (".perf_stall_o(), .bank_acc_o(),", ".perf_stall_o(), .bank_acc_o(bank_acc),"),
    ("  // ---------------------------------------------------------------- main\n",
     """  // ---- sramlab instrumentation (NOT in the original TB) ------------------------------------------------------
  int x_trace = 0, x_init = 0;
  initial void'($value$plusargs("TRACE=%d", x_trace));
  always @(posedge clk) if (rst_n && run_pipe) begin
    if (!x_init) begin
      x_init = 1;
      $display("TTINIT cycle=%0d rr0=%0d rr1=%0d rr2=%0d rr3=%0d", cycle, ctl.g_arb[0].rr_ptr, ctl.g_arb[1].rr_ptr, ctl.g_arb[2].rr_ptr, ctl.g_arb[3].rr_ptr);
    end
    if (x_trace != 0)
      $display("TT %0d %0h %0h %0h %0h %0h %0h %0h", cycle, m_req_valid & m_req_ready, m_rsp_valid & m_rsp_ready, bank_acc,
               {drain_done, drain_grant, drain_req, te_done, te_owned, te_req, fill_done, fill_grant, fill_req},
               {d_req_valid & d_req_ready, c_req_valid & c_req_ready, b_req_valid & b_req_ready, a_req_valid & a_req_ready},
               {d_rsp_valid & d_rsp_ready, c_rsp_valid & c_rsp_ready, b_rsp_valid & b_rsp_ready, a_rsp_valid & a_rsp_ready}, buf_state);
  end
  // ---------------------------------------------------------------- main
"""),
    ('    $display("RESULT tb=tensor_scratchpad NBUF=%0d SKEW=%0d READ_LATENCY=%0d ECC_EN=%0d tiles=%0d checks=%0d errors=%0d owner_violations_counted=%0d %s",',
     '    $display("TTCONF nb=%0d perf_conf_raw=%0h", NB, perf_conf);\n    $display("RESULT tb=tensor_scratchpad NBUF=%0d SKEW=%0d READ_LATENCY=%0d ECC_EN=%0d tiles=%0d checks=%0d errors=%0d owner_violations_counted=%0d %s",'),
]


def make_instrumented_tensor_tb(dst: str | None = None, nb: int = 4) -> str:
    """nb = number of banks of the build (the TTINIT line prints the round-robin pointers of the first min(nb, 4) banks)."""
    src = os.path.join(ROOT, "tb", "tb_tensor_scratchpad.sv")
    dst = dst or os.path.join(WORK, f"tb_tensor_scratchpad_x{nb}.sv")
    txt = open(src).read()
    nbp = max(1, min(nb, 4))
    fmt = " ".join(f"rr{i}=%0d" for i in range(nbp))
    args = ", ".join(f"ctl.g_arb[{i}].rr_ptr" for i in range(nbp))
    for old, new in _TREPL:
        if txt.count(old) != 1:
            raise RuntimeError(f"tensor TB instrumentation anchor not found exactly once: {old[:60]!r}")
        new = new.replace('"TTINIT cycle=%0d rr0=%0d rr1=%0d rr2=%0d rr3=%0d", cycle, ctl.g_arb[0].rr_ptr, ctl.g_arb[1].rr_ptr, ctl.g_arb[2].rr_ptr, ctl.g_arb[3].rr_ptr',
                          f'"TTINIT cycle=%0d {fmt}", cycle, {args}')
        txt = txt.replace(old, new)
    open(dst, "w").write(txt)
    return dst


def build_tensor(tag: str, over: dict) -> str:
    tb = make_instrumented_tensor_tb(os.path.join(WORK, f"tb_tensor_scratchpad_x_{tag}.sv"), nb=int(over.get("NB", 4)))
    bdir = os.path.join(WORK, "tsp_" + tag)
    shutil.rmtree(bdir, ignore_errors=True)
    cmd = ["verilator"] + VFLAGS + ["-f", "sim/files_rtl.f", tb, "--top-module", "tb_tensor_scratchpad", "-Mdir", bdir, "-o", "t.exe"] + \
          [f"-G{k}={v}" for k, v in over.items()]
    rc, out = _sh(cmd)
    if rc != 0:
        raise RuntimeError(f"verilator tensor build {tag} failed:\n{out[-800:]}")
    return os.path.join(bdir, "t.exe")


def run_tensor(exe: str, trace: bool = True) -> dict:
    args = [exe] + (["+TRACE=1"] if trace else [])
    rc, out = _sh(args, timeout=900)
    res = {"rc": rc, "pass": any(l.startswith("RESULT") and l.rstrip().endswith("PASS") for l in out.splitlines()), "trace": [], "init": {}}
    for l in out.splitlines():
        if l.startswith("BENCH tensor "):
            res["bench"] = {k: _num(v) for k, v in re.findall(r"(\w+)=([-\w.]+)", l)}
        elif l.startswith("TTCONF "):
            res["conf_raw"] = l.split("perf_conf_raw=")[1].strip()
        elif l.startswith("TTINIT "):
            res["init"] = {k: _num(v) for k, v in re.findall(r"(\w+)=([-\w.]+)", l)}
        elif l.startswith("TT "):
            p = l.split()
            res["trace"].append(tuple([int(p[1])] + [int(x, 16) for x in p[2:]]))
    return res
