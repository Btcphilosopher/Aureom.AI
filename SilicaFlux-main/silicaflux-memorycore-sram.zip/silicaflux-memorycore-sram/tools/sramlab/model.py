"""Cycle-accurate model of sf_sram_controller + sf_sram_bank (behavioural backend) driven by the
benchmark TB tb/tb_bench_ctrl.sv.

MODEL, not measurement.  It is derived from the RTL SOURCE (rtl/sf_sram_controller.sv,
rtl/sf_sram_bank.sv, rtl/sf_sram_core.sv, tb/tb_bench_ctrl.sv), not from the benchmark results.

Time base.  "edge e" is the e-th rising clock edge; a model step evaluates the combinational logic from the
PRE-edge registered state (exactly what the flops see at edge e) and then computes the post-edge state.
The TB's `cycle` register equals e (it is the number of edges seen before the current one).

What is modelled (and where it comes from)
  * address decode (controller g_dec): bank = line % NB, row = line / NB, ALIGN error (ALIGN_MODE = 1, the TB
    default) -> accepted when a slot is free, no array access, response ready the NEXT edge.
  * per-master reorder slots (g_m): at most NSLOT outstanding, allocation in acceptance order, release strictly
    from the oldest, can_alloc = (cnt != NSLOT) is a REGISTERED count (a pop at edge e frees the slot for
    acceptance at edge e+1).  A bank access accepted at edge e writes its slot at edge e+BANK_LAT, the response
    is visible (m_rsp_valid) from edge e+BANK_LAT+1 on and may be popped at the first such edge where the TB's
    registered rsp_ready is 1.
  * per-bank arbitration (g_arb): requesters = valid & can_alloc & !err & bank==b; grant only if the bank is
    ready; RR: first requester at or after rr_ptr, rr_ptr <= granted+1 (mod NM) ONLY when a grant happens;
    FIXED: lowest index.  Exactly one access per bank per edge; a master is requesting exactly one bank.
  * bank (sf_sram_bank): BANK_LAT = READ_LATENCY + ECC_EN.  ECC partial write (0 < be < all ones) = RMW: the
    bank is not ready at the READ_LATENCY edges following the accepting edge (occupancy READ_LATENCY + 1),
    the response is at BANK_LAT like every other access.  be == 0 writes do not occur in the benchmark.
  * perf counters: conflict = >=2 requesters (after the can_alloc / err filter) in a cycle, whether or not the
    bank is ready; busy = >=1 requester while the bank is not ready.
  * TB conventions: a request is presented at the edge where the previous one is accepted (back to back) or, with
    LOAD_PCT < 100, when the hash gate opens; it can be accepted at the next edge.  latency = edge of the response
    handshake - edge of presentation.  cycles = c_end - c_start.  max_outstanding is master 0 only.

TB start edge.  The first edge with `started` is E0 = DEPTH + 26 (6 reset edges, DEPTH + 16 init wait edges,
4 settle edges, then the negedge that sets `started`).  It only matters for LOAD_PCT < 100 because the gate is a
hash of the absolute edge number.  Verified against RTL runs (tests/test_model_vs_rtl.py, reports).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field, replace

from . import traffic as T


@dataclass(frozen=True)
class Cfg:
    nm: int = 4
    nb: int = 4
    depth: int = 256
    read_latency: int = 1
    ecc: int = 0
    nslot: int = 8
    arb: int = 1                 # 1 = round robin, 0 = fixed priority
    pattern: int = 1
    nreq: int = 1000
    rsp_pct: int = 100
    load_pct: int = 100
    seed: int = 0x00C0FFEE
    align_mode: int = 1          # controller parameter (TB leaves the default 1)

    @property
    def bank_lat(self) -> int:
        return self.read_latency + (1 if self.ecc else 0)

    @property
    def cap_lines(self) -> int:
        return self.nb * self.depth

    @property
    def start_edge(self) -> int:
        return self.depth + 26

    @classmethod
    def from_row(cls, r: dict) -> "Cfg":
        """Build from a bench_rtl.json controller row (keys as printed by the TB)."""
        return cls(nm=int(r["nm"]), nb=int(r["nb"]), depth=int(r["depth"]), read_latency=int(r["read_latency"]),
                   ecc=int(r["ecc"]), nslot=int(r["nslot"]), arb=int(r["arb"]), pattern=int(r["pattern"]),
                   nreq=int(r["nreq"]), rsp_pct=int(r["rsp_pct"]), load_pct=int(r["load_pct"]), seed=int(r["seed"]))

    def with_(self, **kw) -> "Cfg":
        return replace(self, **kw)


@dataclass
class Result:
    cfg: Cfg
    cycles: int = 0
    accesses: int = 0
    reads: int = 0
    writes: int = 0
    useful_bytes: int = 0
    bank_conflict_cycles: int = 0
    bank_busy_stalls: int = 0
    mean_latency: float = 0.0
    max_latency: int = 0
    max_outstanding: int = 0           # master 0 (as printed by the TB)
    c_start: int = 0
    c_end: int = 0
    # --- extra statistics (not printed by the TB; MODEL-only unless an instrumented RTL run is available)
    per_bank_acc: list = field(default_factory=list)       # accepted bank accesses per bank (perf_acc)
    per_bank_conf: list = field(default_factory=list)      # conflict cycles per bank (perf_conf)
    per_bank_busy: list = field(default_factory=list)      # busy stalls per bank (perf_busy)
    per_bank_rd: list = field(default_factory=list)
    per_bank_wr: list = field(default_factory=list)
    per_bank_rmw: list = field(default_factory=list)       # partial writes executed as RMW (ECC only)
    per_bank_part: list = field(default_factory=list)      # partial writes accepted (RMW with ECC, byte-masked write without)
    per_bank_occ: list = field(default_factory=list)       # cycles the bank array/FSM was occupied by an access
    per_master_stall: list = field(default_factory=list)   # perf_stall: valid && !ready cycles
    per_master_stall_slot: list = field(default_factory=list)   # ... of which: no free slot
    per_master_stall_bank: list = field(default_factory=list)   # ... of which: bank busy (RMW)
    per_master_stall_arb: list = field(default_factory=list)    # ... of which: lost arbitration
    per_master_max_out: list = field(default_factory=list)
    per_master_lat_sum: list = field(default_factory=list)
    per_master_done: list = field(default_factory=list)
    err_responses: int = 0
    useful_bytes_array: int = 0         # useful bytes of the requests that really accessed an array (excludes ALIGN/RANGE errors)
    latency_hist: dict = field(default_factory=dict)
    occupancy_hist: list = field(default_factory=list)     # mean slot occupancy per master (pre-edge)
    per_master_grants: list = field(default_factory=list)  # grants[m][b]
    per_master_max_wait: list = field(default_factory=list)  # max grants of the requested bank given to others while waiting (O6)
    trace: list | None = None

    @property
    def throughput_Bpc(self) -> float:
        return self.useful_bytes / self.cycles if self.cycles else 0.0

    def row(self) -> dict:
        return dict(cycles=self.cycles, accesses=self.accesses, reads=self.reads, writes=self.writes,
                    useful_bytes=self.useful_bytes, throughput_Bpc=round(self.throughput_Bpc, 4),
                    bank_conflict_cycles=self.bank_conflict_cycles, bank_busy_stalls=self.bank_busy_stalls,
                    mean_latency=round(self.mean_latency, 3), max_latency=self.max_latency,
                    max_outstanding=self.max_outstanding)


class Ctrl:
    """sf_sram_controller + NB sf_sram_bank, evaluated one clock edge at a time.

    step(e, reqs, rsp_rdy) takes the PRE-edge inputs (what the flops see at edge e) and returns
    (accepted, popped).  reqs[m] is None (nothing presented) or a tuple (err, bank, we, partial, payload):
    err != 0 -> decode error (ALIGN/RANGE) answered without a bank access; partial = ECC partial write.
    A popped entry returns its payload (an arbitrary object the caller attached to the request).
    """

    def __init__(self, nm, nb, nslot, read_latency, ecc, arb):
        self.NM, self.NB, self.NS, self.RL, self.ecc, self.arb_rr = nm, nb, nslot, read_latency, bool(ecc), arb == 1
        self.BL = read_latency + (1 if ecc else 0)
        self.q = [deque() for _ in range(nm)]        # reorder slots: (first edge the entry may pop, payload)
        self.rr = [0] * nb
        self.busy_until = [-1] * nb                  # bank not ready at edges <= busy_until
        z = lambda n: [0] * n
        self.conf, self.busy, self.acc_b = z(nb), z(nb), z(nb)
        self.rd_b, self.wr_b, self.rmw_b, self.occ_b = z(nb), z(nb), z(nb), z(nb)
        self.part_b = z(nb)                          # partial writes accepted (any mode); with ECC they are RMW
        self.stall, self.st_slot, self.st_bank, self.st_arb = z(nm), z(nm), z(nm), z(nm)
        self.grants_m = [z(nb) for _ in range(nm)]   # grants[m][b]
        self.waited = [0] * nm                       # grants of the requested bank given to others while m waited (O6)
        self.max_wait = [0] * nm
        self.occ_sum = z(nm)
        self.n_steps = 0
        self.err_n = 0
        self.bank_acc_trace = None                   # optional list of (edge, bank) for the energy model

    def step(self, e, reqs, rsp_rdy, trace=None):
        NM, NB, NS = self.NM, self.NB, self.NS
        q = self.q
        can = [len(q[m]) < NS for m in range(NM)]
        rq = [[] for _ in range(NB)]
        for m in range(NM):
            r = reqs[m]
            if r is not None and can[m] and r[0] == 0:
                rq[r[1]].append(m)
        granted = [False] * NM
        for b in range(NB):
            r = rq[b]
            if not r:
                continue
            if len(r) >= 2:
                self.conf[b] += 1
            if e <= self.busy_until[b]:
                self.busy[b] += 1
                for m in r:
                    self.st_bank[m] += 1
                continue
            if self.arb_rr:
                p = self.rr[b]
                win = None
                for k in range(NM):
                    i = (p + k) % NM
                    if i in r:
                        win = i
                        break
                self.rr[b] = 0 if win == NM - 1 else win + 1
            else:
                win = r[0]
            granted[win] = True
            for m in r:
                if m != win:
                    self.st_arb[m] += 1
                    self.waited[m] += 1
                    if self.waited[m] > self.max_wait[m]:
                        self.max_wait[m] = self.waited[m]
            self.waited[win] = 0
            self.grants_m[win][b] += 1
            _, _, we, partial, _ = reqs[win]
            self.acc_b[b] += 1
            self.occ_b[b] += 1
            if we:
                self.wr_b[b] += 1
                if partial:
                    self.part_b[b] += 1
                if self.ecc and partial:
                    self.rmw_b[b] += 1
                    self.busy_until[b] = e + self.RL
                    self.occ_b[b] += self.RL
            else:
                self.rd_b[b] += 1
            if trace is not None:
                trace.append((e, "gnt", win, b))
        accepted = [False] * NM
        for m in range(NM):
            r = reqs[m]
            if r is not None:
                if can[m] and (r[0] != 0 or granted[m]):
                    accepted[m] = True
                else:
                    self.stall[m] += 1
                    if not can[m]:
                        self.st_slot[m] += 1
        popped = [None] * NM
        for m in range(NM):
            if q[m] and q[m][0][0] <= e and rsp_rdy[m]:
                popped[m] = q[m].popleft()[1]
                if popped[m] is None:
                    popped[m] = True
            self.occ_sum[m] += len(q[m]) + (1 if popped[m] is not None else 0)   # pre-edge occupancy
        for m in range(NM):
            if accepted[m]:
                r = reqs[m]
                if r[0] != 0:
                    self.err_n += 1
                    q[m].append((e + 1, r[4]))             # slot written at the accepting edge
                else:
                    q[m].append((e + self.BL + 1, r[4]))   # slot written at e+BL, popable from e+BL+1
                if trace is not None:
                    trace.append((e, "acc", m, r[1]))
        self.n_steps += 1
        return accepted, popped


def simulate(cfg: Cfg, trace: bool = False, max_edges: int = 5_000_000) -> Result:
    """tb_bench_ctrl: NM masters x NREQ back-to-back requests (see module docstring)."""
    NM, NB = cfg.nm, cfg.nb
    streams = [T.MasterStream(cfg.pattern, m, NM, NB, cfg.depth, cfg.seed) for m in range(NM)]
    ctl = Ctrl(NM, NB, cfg.nslot, cfg.read_latency, cfg.ecc, cfg.arb)
    # ---------------- testbench state (tb_bench_ctrl)
    cur = [None] * NM                       # presented request: (err, bank, we, partial, None) or None
    useful_of = [None] * NM
    gcount = [0] * NM
    done_n = [0] * NM
    outst = [0] * NM
    max_out = [0] * NM
    pres = [deque() for _ in range(NM)]
    rsp_rdy = [False] * NM                  # TB register m_rsp_ready (reset value 0)
    lat_sum = lat_max = lat_n = 0
    m_lat_sum = [0] * NM
    r_rd = r_wr = 0
    useful = 0
    useful_arr = 0
    c_start = None
    lat_hist: dict[int, int] = {}
    tr = [] if trace else None
    nreq, load_pct, rsp_pct = cfg.nreq, cfg.load_pct, cfg.rsp_pct
    gate, rdraw = T.load_gate, T.rsp_ready_draw

    e = cfg.start_edge
    e_stop = e + max_edges
    while True:
        accepted, popped = ctl.step(e, cur, rsp_rdy, tr)
        for m in range(NM):
            acc = accepted[m]
            v_pre = cur[m] is not None
            if acc:
                req = useful_of[m]
                outst[m] += 1
                if outst[m] > max_out[m]:
                    max_out[m] = outst[m]
                if req.we:
                    r_wr += 1
                else:
                    r_rd += 1
                if cur[m][0] == 0:
                    useful_arr += req.useful
                cur[m] = None
            if popped[m] is not None:
                done_n[m] += 1
                outst[m] -= 1
                l = e - pres[m].popleft()
                lat_sum += l
                m_lat_sum[m] += l
                lat_n += 1
                if l > lat_max:
                    lat_max = l
                lat_hist[l] = lat_hist.get(l, 0) + 1
                if tr is not None:
                    tr.append((e, "pop", m, l))
            if ((not v_pre) or acc) and gcount[m] < nreq and gate(e, m, load_pct):
                req = streams[m].next()
                st, bank, row = T.decode(req.addr, NB, cfg.depth, cfg.align_mode)
                cur[m] = (st, bank, req.we, T.is_partial(req), None)
                useful_of[m] = req
                pres[m].append(e)
                useful += req.useful
                gcount[m] += 1
                if c_start is None:
                    c_start = e
                if tr is not None:
                    tr.append((e, "pres", m, bank))
            rsp_rdy[m] = rdraw(e, m, rsp_pct)
        if all(d >= nreq for d in done_n):
            c_end = e
            break
        e += 1
        if e > e_stop:
            raise RuntimeError("model: no completion (deadlock?)")

    return Result(cfg=cfg, cycles=c_end - c_start, accesses=lat_n, reads=r_rd, writes=r_wr, useful_bytes=useful,
                  bank_conflict_cycles=sum(ctl.conf), bank_busy_stalls=sum(ctl.busy),
                  mean_latency=lat_sum / lat_n, max_latency=lat_max, max_outstanding=max_out[0],
                  c_start=c_start, c_end=c_end, per_bank_acc=ctl.acc_b, per_bank_conf=ctl.conf, per_bank_busy=ctl.busy,
                  per_bank_rd=ctl.rd_b, per_bank_wr=ctl.wr_b, per_bank_rmw=ctl.rmw_b, per_bank_part=ctl.part_b, per_bank_occ=ctl.occ_b,
                  per_master_stall=ctl.stall, per_master_stall_slot=ctl.st_slot, per_master_stall_bank=ctl.st_bank,
                  per_master_stall_arb=ctl.st_arb, per_master_max_out=max_out, per_master_lat_sum=m_lat_sum,
                  per_master_done=done_n, err_responses=ctl.err_n, latency_hist=lat_hist,
                  occupancy_hist=[s / max(1, ctl.n_steps) for s in ctl.occ_sum], trace=tr,
                  per_master_grants=ctl.grants_m, per_master_max_wait=ctl.max_wait, useful_bytes_array=useful_arr)
