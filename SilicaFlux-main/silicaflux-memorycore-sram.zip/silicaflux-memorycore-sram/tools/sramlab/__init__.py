"""sramlab - performance / energy research tool for the SilicaFlux MemoryCore SRAM subsystem.

MODEL / ANALYTICAL results only (plus parsers of RTL-simulation results); see reports/sramlab_vs_rtl.md.
Run `python3 -m sramlab --help` from the tools/ directory.
"""
__version__ = "1.0"
