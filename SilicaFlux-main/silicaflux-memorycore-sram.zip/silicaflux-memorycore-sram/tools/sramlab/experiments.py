"""Benchmark experiments A-J, S, Q as MODEL results next to the RTL results and the ANALYTICAL ceilings.

Every function returns plain dicts / lists (JSON-serialisable).  Provenance tags of every column:
  rtl_*       RTL-SIMULATION  (reports/bench_rtl.json or an instrumented re-run)
  model_*     MODEL           (sramlab.model, validated against the RTL rows)
  ceil_*      ANALYTICAL      (sramlab.analytic)
  eff         RTL / ANALYTICAL ceiling
"""
from __future__ import annotations

from . import analytic as A
from . import traffic as T
from .model import Cfg, simulate

EXP_TITLES = {
    "A": "A sequential scalar 4 B loads", "B": "B wide vector (16 B) loads", "AB": "A/B base config, patterns 0-1",
    "D": "D full-bank parallel accesses", "E": "E single-bank contention", "F": "F random access", "DEF": "D/E/F base config, patterns 2-8",
    "H": "H ECC overhead", "L": "L read-latency 2/3", "J": "J capacity / bank / master sweeps", "S": "S saturation (offered load)",
    "Q": "Q queue occupancy vs response backpressure and slots",
}


def ceilings_rows(bench: dict) -> list[dict]:
    rows = []
    for r in bench["controller"]:
        cfg = Cfg.from_row(r)
        m = simulate(cfg)
        c = A.pattern_ceiling(cfg.pattern, cfg.nm, cfg.nb, cfg.nslot, cfg.read_latency, cfg.ecc, cfg.rsp_pct, cfg.load_pct, cfg.align_mode)
        ceil = c["useful_Bpc"]
        zl = A.zero_load_latency(cfg.read_latency, cfg.ecc)
        rows.append({
            "experiment": r["experiment"], "desc": r["desc"], "config": r["config"], "pattern": cfg.pattern, "pattern_name": T.PATTERN_NAMES[cfg.pattern],
            "nm": cfg.nm, "nb": cfg.nb, "depth": cfg.depth, "read_latency": cfg.read_latency, "ecc": cfg.ecc, "nslot": cfg.nslot, "arb": cfg.arb,
            "rsp_pct": cfg.rsp_pct, "load_pct": cfg.load_pct, "seed": cfg.seed,
            "rtl_Bpc": r["throughput_Bpc"], "model_Bpc": round(m.throughput_Bpc, 4), "ceil_Bpc": ceil, "ceil_estimate_Bpc": c["estimate_useful_Bpc"], "ceil_acc_per_cycle": c["acc_per_cycle"],
            "ceil_exact": c["exact"], "ceil_formula": c["formula"], "eff": r["throughput_Bpc"] / ceil if ceil else None,
            "rtl_mean_latency": r["mean_latency"], "zero_load_latency": zl, "rtl_max_latency": r["max_latency"],
            "rtl_max_outstanding": r["max_outstanding"], "rtl_conflicts": r["bank_conflict_cycles"], "rtl_busy": r["bank_busy_stalls"],
            "rtl_cycles": r["cycles"], "rtl_accesses": r["accesses"],
            "peak_Bpc": A.bank_peak_Bpc(cfg.nb),
            "useful_array_Bpc_model": m.useful_bytes_array / m.cycles,
        })
    return rows


def headline(rows: list[dict]) -> dict:
    def pick(**kw):
        for r in rows:
            if all(r[k] == v for k, v in kw.items()):
                return r
        return None
    base = dict(config="base", rsp_pct=100, load_pct=100, experiment="AB")
    out = {}
    for name, kw in (("peak_seq_line", dict(config="base", pattern=1, rsp_pct=100, load_pct=100, experiment="AB")),
                     ("own_bank", dict(config="base", pattern=2, rsp_pct=100, load_pct=100, experiment="DEF")),
                     ("single_bank", dict(config="base", pattern=3, rsp_pct=100, load_pct=100, experiment="DEF")),
                     ("random_read", dict(config="base", pattern=4, rsp_pct=100, load_pct=100, experiment="DEF")),
                     ("random_rw", dict(config="base", pattern=5, rsp_pct=100, load_pct=100, experiment="DEF")),
                     ("ecc_part_write", dict(config="ecc", pattern=7, rsp_pct=100, load_pct=100, experiment="H")),
                     ("scalar_as_run", dict(config="base", pattern=0, rsp_pct=100, load_pct=100, experiment="AB"))):
        r = pick(**kw)
        if r:
            out[name] = {"rtl_Bpc": r["rtl_Bpc"], "ceil_Bpc": r["ceil_Bpc"], "eff": r["eff"], "model_Bpc": r["model_Bpc"], "peak_Bpc": r["peak_Bpc"]}
    return out


def ecc_table(bench: dict) -> list[dict]:
    """H: ECC vs no-ECC for every pattern at READ_LATENCY 1 and 2: RTL throughput ratio, MODEL ratio, ANALYTICAL ratio, latency delta."""
    rows = []
    idx = {}
    for r in bench["controller"]:
        if r["rsp_pct"] == 100 and r["load_pct"] == 100 and r["seed"] == 0x00C0FFEE and r["nm"] == 4 and r["nb"] == 4 and r["depth"] == 256 and r["nslot"] == 8 and r["arb"] == 1:
            idx[(r["config"], r["pattern"])] = r
    for rl, (cb, ce) in ((1, ("base", "ecc")), (2, ("L2", "ecc_L2"))):
        for pat in range(9):
            a, b = idx.get((cb, pat)), idx.get((ce, pat))
            if not a or not b:
                continue
            ma = simulate(Cfg.from_row(a))
            mb = simulate(Cfg.from_row(b))
            ca = A.pattern_ceiling(pat, 4, 4, 8, rl, 0)["useful_Bpc"]
            cb_ = A.pattern_ceiling(pat, 4, 4, 8, rl, 1)["useful_Bpc"]
            rows.append({"read_latency": rl, "pattern": pat, "pattern_name": T.PATTERN_NAMES[pat],
                         "rtl_Bpc_noecc": a["throughput_Bpc"], "rtl_Bpc_ecc": b["throughput_Bpc"],
                         "rtl_ratio": b["throughput_Bpc"] / a["throughput_Bpc"], "model_ratio": mb.throughput_Bpc / ma.throughput_Bpc,
                         "ceil_ratio": cb_ / ca if ca else None, "rtl_lat_noecc": a["mean_latency"], "rtl_lat_ecc": b["mean_latency"],
                         "rtl_busy_ecc": b["bank_busy_stalls"], "model_busy_ecc": mb.bank_busy_stalls,
                         "rtl_conf_noecc": a["bank_conflict_cycles"], "rtl_conf_ecc": b["bank_conflict_cycles"]})
    return rows


def sweep_nb(bench: dict) -> list[dict]:
    """J: NB sweep at NM = 4 for patterns 1, 2, 4 (RTL, MODEL, ANALYTICAL)."""
    out = []
    for r in bench["controller"]:
        if r["experiment"] == "J" and r["config"] in ("nb1", "nb2", "base", "nb8") and r["nm"] == 4:
            cfg = Cfg.from_row(r)
            c = A.pattern_ceiling(cfg.pattern, cfg.nm, cfg.nb, cfg.nslot, cfg.read_latency, cfg.ecc)
            out.append({"nb": cfg.nb, "pattern": cfg.pattern, "rtl_Bpc": r["throughput_Bpc"], "model_Bpc": simulate(cfg).throughput_Bpc,
                        "ceil_Bpc": c["useful_Bpc"], "peak_Bpc": 16 * cfg.nb})
    return sorted(out, key=lambda x: (x["pattern"], x["nb"]))


def sweep_nm(bench: dict) -> list[dict]:
    out = []
    for r in bench["controller"]:
        if r["experiment"] == "J" and r["config"] in ("nm2_nb4", "base", "nm8_nb4", "nm8_nb8"):
            cfg = Cfg.from_row(r)
            c = A.pattern_ceiling(cfg.pattern, cfg.nm, cfg.nb, cfg.nslot, cfg.read_latency, cfg.ecc)
            out.append({"config": r["config"], "nm": cfg.nm, "nb": cfg.nb, "pattern": cfg.pattern, "rtl_Bpc": r["throughput_Bpc"],
                        "model_Bpc": simulate(cfg).throughput_Bpc, "ceil_Bpc": c["useful_Bpc"], "peak_Bpc": 16 * cfg.nb})
    return sorted(out, key=lambda x: (x["pattern"], x["nb"], x["nm"]))


def sweep_depth(bench: dict) -> list[dict]:
    out = []
    for r in bench["controller"]:
        if r["experiment"] == "J" and r["config"] in ("d64", "base", "d1024", "d4096"):
            cfg = Cfg.from_row(r)
            out.append({"depth": cfg.depth, "capacity_KiB": cfg.nb * cfg.depth * 16 / 1024, "pattern": cfg.pattern, "rtl_Bpc": r["throughput_Bpc"],
                        "model_Bpc": simulate(cfg).throughput_Bpc, "rtl_conf": r["bank_conflict_cycles"]})
    return sorted(out, key=lambda x: (x["pattern"], x["depth"]))


def saturation(bench: dict) -> list[dict]:
    out = []
    for r in bench["controller"]:
        if r["experiment"] == "S":
            cfg = Cfg.from_row(r)
            c = A.pattern_ceiling(cfg.pattern, cfg.nm, cfg.nb, cfg.nslot, cfg.read_latency, cfg.ecc, cfg.rsp_pct, cfg.load_pct)
            out.append({"config": r["config"], "pattern": cfg.pattern, "load_pct": cfg.load_pct, "rtl_Bpc": r["throughput_Bpc"],
                        "model_Bpc": simulate(cfg).throughput_Bpc, "ceil_Bpc": c["useful_Bpc"], "rtl_mean_latency": r["mean_latency"],
                        "rtl_conf": r["bank_conflict_cycles"]})
    return out


def queue_table(bench: dict) -> list[dict]:
    out = []
    for r in bench["controller"]:
        if r["experiment"] == "Q":
            cfg = Cfg.from_row(r)
            m = simulate(cfg)
            bl = cfg.bank_lat
            pm = A.per_master_ceiling(cfg.nslot, bl, cfg.rsp_pct)
            out.append({"config": r["config"], "nslot": cfg.nslot, "rsp_pct": cfg.rsp_pct, "rtl_Bpc": r["throughput_Bpc"], "model_Bpc": m.throughput_Bpc,
                        "ceil_Bpc": cfg.nm * pm * 16, "markov_per_master_acc": pm, "rtl_max_outstanding": r["max_outstanding"],
                        "rtl_mean_latency": r["mean_latency"], "model_mean_slot_occupancy_m0": m.occupancy_hist[0],
                        "model_max_outstanding_per_master": m.per_master_max_out, "model_stall_slot_cycles": sum(m.per_master_stall_slot),
                        "rtl_conf": r["bank_conflict_cycles"]})
    return out


def conflict_analysis(extra: dict | None) -> list[dict]:
    """Bank-conflict analysis of the base configuration (patterns 1..8): per-bank conflict cycles, per-master stall cycles split into
    {no free slot, bank busy (RMW), lost arbitration} (MODEL); RTL perf-counter values come from the instrumented x_base run when present."""
    rtl = {}
    if extra:
        for r in extra["rows"]:
            if r["config"] in ("x_base", "x_ecc") and r.get("nreq") == 1000 and r["rsp_pct"] == 100 and r["load_pct"] == 100:
                rtl[(r["config"], r["pattern"])] = r
    out = []
    for ecc, key in ((0, "x_base"), (1, "x_ecc")):
        for pat in range(9):
            m = simulate(Cfg(pattern=pat, ecc=ecc))
            row = {"ecc": ecc, "pattern": pat, "pattern_name": T.PATTERN_NAMES[pat],
                   "model_conf_per_bank": m.per_bank_conf, "model_busy_per_bank": m.per_bank_busy, "model_stall_per_master": m.per_master_stall,
                   "model_stall_slot": m.per_master_stall_slot, "model_stall_bank_busy": m.per_master_stall_bank, "model_stall_arb": m.per_master_stall_arb,
                   "model_acc_per_bank": m.per_bank_acc, "model_bank_utilisation": [o / m.cycles for o in m.per_bank_occ],
                   "model_max_wait_grants": m.per_master_max_wait, "model_mean_latency_per_master": [s / m.per_master_done[i] for i, s in enumerate(m.per_master_lat_sum)]}
            rr = rtl.get((key, pat))
            if rr:
                row["rtl_conf_per_bank"] = rr["rtl_perf_conf"]
                row["rtl_busy_per_bank"] = rr["rtl_perf_busy"]
                row["rtl_stall_per_master"] = rr["rtl_perf_stall"]
                row["rtl_acc_per_bank"] = rr["rtl_perf_acc"]
                row["counters_equal"] = rr["perf_counters_match"]
            out.append(row)
    return out


def fairness() -> list[dict]:
    """O6 (contract): RR waiting bound NM-1 grants; FIXED priority: starvation possible.  MODEL on SAME_BANK, NM = 4."""
    out = []
    for arb, name in ((1, "RR"), (0, "FIXED")):
        m = simulate(Cfg(pattern=3, arb=arb))
        out.append({"arb": name, "analytic_mean_latency": A.same_bank_latency(4, 1, 0, arb), "per_master_grants": [sum(g) for g in m.per_master_grants], "per_master_max_wait_grants": m.per_master_max_wait,
                    "per_master_mean_latency": [s / m.per_master_done[i] for i, s in enumerate(m.per_master_lat_sum)],
                    "per_master_stall_cycles": m.per_master_stall, "rr_bound_nm_minus_1": 3})
    # saturation: infinite-stream fairness check with unlimited requests is not possible in the TB (finite NREQ); report finite-run result
    return out
