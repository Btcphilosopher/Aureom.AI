#!/usr/bin/env python3
"""Render docs/VERIFICATION.md from reports/*.json (every table cell is copied from a result file).

    python3 tools/make_verification_md.py
"""
import glob
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def J(rel, default=None):
    p = os.path.join(ROOT, rel)
    return json.load(open(p)) if os.path.exists(p) else default


def tbl(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join("---" for _ in head) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def merged_mutants():
    allm = {}
    src = {}
    for f in sorted(glob.glob(os.path.join(ROOT, "reports", "mutation*.json"))):
        d = json.load(open(f))
        for m in d.get("mutants", []):
            allm[m["id"]] = m
            src[m["id"]] = os.path.basename(f)
    return sorted(allm.values(), key=lambda m: int(m["id"][1:])), src


def main():
    w = []
    a = w.append
    a("# VERIFICATION")
    a("")
    a("Labels: **RTL-SIMULATION** = Verilator 5.020 two-state simulation of the RTL; **BOUNDED FORMAL** = bounded model checking, not an unbounded proof. "
      "All tables below are generated from `reports/*.json` by `tools/make_verification_md.py`; re-run the commands to reproduce. Nothing here is a silicon result.")
    a("")
    a("## 1. Method")
    a("")
    a("* **Byte-accurate reference memory.** Every testbench keeps an independent model of the memory contents (and of which bytes are known). Requests are applied to the model **at the edge the DUT accepts them** "
      "(the controller's serialisation point, `docs/CONTRACT.md` O3) and the model predicts the exact response of each request. Responses are checked in acceptance order per master (O2).")
    a("* **Deterministic seeds.** All randomness is xorshift32 seeded by a testbench parameter; every failing run is reproducible with the printed seed.")
    a("* **Conservation / integrity** checked continuously: accepted == answered + flushed, no response during flush, payload stable under back-pressure, round-robin waiting bound, full-capacity read-back at the end.")
    a("* **Independent references.** ECC is checked against `tools/ecc/secded_ref.py` (written from the documented code layout, no RTL code shared); the cycle model in `tools/sramlab` is derived from the RTL source and compared edge for edge; the DataFabric adapter is checked behind the *implemented* NoC with its own protocol checker.")
    a("* **Mutation testing** (`tools/mutate.py`) injects hand-written faults into a *copy* of the RTL and requires at least one testbench to fail; surviving mutants exposed weak checks, which were strengthened (see section 4).")
    a("")
    a("## 2. Regression suites (RTL-SIMULATION)")
    a("")
    for s, title in (("ctrl", "controller tests T01-T11 and T18 over 21 configurations (latency, ECC, banks, masters, widths, backends)"), ("dfab", "DataFabric adapter behind the real NoC"), ("vsp", "vector scratchpad"), ("tsp", "tensor scratchpad"), ("ecc", "ECC through the whole controller path (E1-E8)")):
        r = J(f"reports/regress_{s}.json")
        if not r:
            continue
        a(f"### {s} - {title}: {r['passed']}/{r['total']} cases pass, {r['checks']:,} self-checks")
        a("")
        a(tbl(["case", "overrides", "tests", "checks", "errors", "status"], [[c["name"], ", ".join(f"{k}={v}" for k, v in c["overrides"].items()) or "defaults", c.get("tests", ""), f"{c.get('checks', 0):,}", c.get("errors", ""), c["status"]] for c in r["cases"]]))
        a("")
    a("Controller test list (`tb/tb_sram_controller.sv`): T01 single write/read, T02 sequential + full-capacity read-back, T03 random single master, T04 byte masking, T05 bank-interleave placement, "
      "T06 bank conflicts + fairness, T07 simultaneous masters, T08 back-pressure, T09 burst boundaries, T10 invalid addresses, T11 flush / reset / quiesce, T18 randomized multi-master. "
      "Configurations cover READ_LATENCY 1-3, ECC on/off, NB 2/4/8, fixed priority, `ALIGN_MODE=0`, DW 64 and 256, non-power-of-two depth, and the FPGA / ASIC-stand-in backends.")
    a("")
    a("Other testbenches: `tb_ecc_codec` (K = 32/64/128, `docs/ECC.md`, log `reports/ecc_codec.log`), `tb_mbist_cov` (`docs/MBIST.md`), `tb_datafabric` (D1-D6, D3b), `tb_vector_scratchpad` (V1-V7), `tb_tensor_scratchpad` (N1-N6 negatives + tile pipeline), `sf_compat/tb_legacy_mc` (legacy controller - **fails as shipped**, see `docs/SF_COMPAT.md`).")
    a("")
    a("## 3. Bounded formal (Yosys -> AIGER -> ABC `bmc3`)")
    a("")
    f = J("reports/formal.json", [])
    # keep the latest entry per (cfg, data)
    last = {}
    for x in f:
        last[(x["cfg"], bool(x.get("data")))] = x
    a(tbl(["configuration", "build", "depth requested", "frames proved", "AIG latches", "AND gates", "result"],
          [[k[0], "data (ghost memory)" if k[1] else "structural", x.get("depth_requested"), x.get("frames_proved"), x.get("aig", {}).get("latches", "-"), x.get("aig", {}).get("ands", "-"), x["status"]] for k, x in last.items()]))
    a("")
    a("*frames proved* = highest frame index reported by ABC `bmc3 -v` (frames are numbered from 0); a configuration counts as PASSED only when ABC printed `No output asserted in N frames` for the requested depth N.")
    a("")
    for (cfg, data), x in last.items():
        if x["status"] != "PASSED":
            cx = "a counterexample was found" if x.get("counterexample") else "no counterexample was found"
            a(f"**Not a full pass:** configuration `{cfg}` ({'data' if data else 'structural'}) ended with status `{x['status']}`: {cx}; ABC completed frames up to index {x.get('frames_proved')} of the {x.get('depth_requested')} requested before the time / resource limit, so only that depth is claimed for it.")
            a("")
    a("Properties (`formal/fv_sram_controller.sv`, asserted every cycle after reset): **P1** routing + exclusivity (at most one accepted non-error master per bank per cycle, bank access iff accepted error-free request to that bank, "
      "address map re-implemented independently in the harness); **P2** an accepted error request never produces a bank access; **P3** no duplicate / lost response (per-master outstanding never negative, never above `NSLOT`); "
      "**P4** ordering + data (responses equal the head of a ghost FIFO filled at acceptance from a ghost byte-accurate memory - *data build only*); **P5** stable payload under back-pressure; **P6** flush behaviour.")
    a("")
    a("**Assumptions** (each an `assume`): A1 reset low in cycle 0 then high; A2 a presented request that was not accepted is presented again unchanged; A3 `quiesce_i = 0`, no init pulses, scrubber off, MBIST port idle, fault injection off "
      "(`INIT_ON_RESET = 0` without ECC; `= 1` with ECC, because a never-written ECC line is an uncorrectable codeword by design - the first ECC run found exactly that harness gap).")
    a("")
    a("**Bounds.** Instances are tiny (2-3 masters, 2 banks, 2-4 rows, 32-bit lines, 2-3 slots; the `ecc` configuration has 1 master); depths are listed above and the data build is much shallower than the structural build. "
      "A pass means: no violation exists within that many cycles for any input sequence the assumptions allow. It is **not** an unbounded proof, says nothing about large depths / widths, and does not cover data under ECC single-bit faults, MBIST or the DataFabric adapter (simulation covers those). "
      "`yosys-smtbmc` with z3 was tried first and ran out of memory on these instances; ABC's SAT-based BMC was used instead. Any configuration that did not reach its requested depth is reported as such above; none is hidden.")
    a("")
    a("## 4. Mutation testing")
    a("")
    ms, src = merged_mutants()
    killed = sum(1 for m in ms if m.get("verdict") == "KILLED")
    a(f"**{killed} of {len(ms)} mutants killed** (latest result per mutant; result files: " + ", ".join(sorted(set(src.values()))) + ").")
    a("")
    a(tbl(["id", "file", "mutation", "TB config", "verdict", "first failing check"], [[m["id"], m["file"], m["why"], m["cfg"], m["verdict"], str(m.get("detail", ""))[:90].replace("|", "/")] for m in ms]))
    a("")
    a("Mutants that initially survived exposed weak testbench checks (a quiesce check that was vacuous, a conflict check that needed NM >= 2, a model-mirrored data check in the DataFabric test, an early-completion mode of the tensor scratchpad that nothing exercised, "
      "a lane-steering check that was self-consistent with the bug). They were fixed in the testbenches; the numbers above are after those fixes. A full kill count only shows that these injected faults are detectable.")
    a("")
    a("## 5. Logic synthesis (Yosys generic gates, no PDK)")
    a("")
    s = J("reports/synthesis.json", {})
    a(f"Tool: {s.get('tool', '')}. Counts are generic cells; SRAM arrays remain `$mem` cells. No timing, no area, no technology mapping.")
    a("")
    a(tbl(["module / configuration", "status", "flip-flops", "logic cells", "$mem cells", "memory bits", "latches"], [[r["name"], r["status"], r.get("flip_flops", ""), r.get("logic_cells", ""), r.get("mem_cells", ""), r.get("memory_bits", ""), r.get("latches", "")] for r in s.get("results", [])]))
    a("")
    a("## 6. Model validation (sramlab)")
    a("")
    v = J("reports/sramlab_vs_rtl.json", {})
    sm = (v.get("validation") or {}).get("summary", {})
    ex = v.get("extra_rtl") or {}
    a(f"The Python cycle model reproduces {sm.get('exact_match_all_stats', '-')} of {sm.get('rows', '-')} committed benchmark rows exactly on seven statistics (cycles, accesses, bank-conflict cycles, bank-busy stalls, mean latency to 3 decimals, max latency, max outstanding). "
      f"Extra instrumented RTL runs: {ex.get('controller_exact', '-')} of {ex.get('controller_runs', '-')} controller runs match edge for edge; tensor pipeline {ex.get('tensor_trace_identical', '-')} of {ex.get('tensor_runs', '-')} configurations match edge for edge. "
      "Details and per-row tables: `reports/sramlab_vs_rtl.md`.")
    a("")
    a("## 7. Tool pitfalls that shaped the testbenches (Verilator 5.020 / Yosys 0.33)")
    a("")
    a("* `pop_front()` on an array of queues empties the queue (NM = 1 and NM + 1 cases) -> circular buffers are used instead; `fork` / `join` in a testbench crashed Verilator -> separate gated `initial` blocks; `buf` and `before` are reserved identifiers there; `int'()` inside `$display` argument lists caused an internal error.")
    a("* Yosys 0.33: no `parameter string` (the macro wrapper uses an untyped `INIT_FILE`), `chparam` renames the top (use `synth -flatten` without `-top`), packed-array typedefs in the legacy package are rejected.")
    a("* RTL portability rules followed: flat ports, no `int'()` casts, no packages in synthesizable RTL, sized literals.")
    a("")
    a("## 8. What this verification does not show")
    a("")
    a("No silicon behaviour, no timing closure, no power; no X-propagation (two-state simulator); formal results are bounded and small; mutation testing covers only the injected list; the ECC 3-bit behaviour is characterised, not guaranteed; the legacy `memory_controller.sf` is not verified (it fails). See `docs/KNOWN_LIMITATIONS.md`.")
    a("")
    open(os.path.join(ROOT, "docs", "VERIFICATION.md"), "w").write("\n".join(w) + "\n")
    print("wrote docs/VERIFICATION.md")


if __name__ == "__main__":
    main()
