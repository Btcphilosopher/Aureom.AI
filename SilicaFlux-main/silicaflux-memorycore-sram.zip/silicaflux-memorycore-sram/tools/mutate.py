#!/usr/bin/env python3
"""Mutation testing of the MemoryCore RTL: plant one deliberate bug at a time, rebuild a testbench, and require it to FAIL.

    python3 tools/mutate.py [--jobs 2] [--only M01 M07] [--out reports/mutation.json]

A mutant is KILLED when the testbench reports errors (RESULT ... FAIL), a build error, or does not finish (watchdog / timeout);
SURVIVED means the testbench passed with the bug present, i.e. a verification hole.  Every mutant replaces ONE exact string
that must occur exactly once in the named file (so a refactor that moves code makes the tool fail loudly instead of silently
testing nothing).  Mutants are built in a temporary copy of the tree; the real sources are never touched.
"""
import argparse, json, os, re, shutil, subprocess, sys, tempfile, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "--assert", "-DSF_ASSERT",
          "-Wno-DECLFILENAME"]

# (id, file, old, new, testbench config key, rationale)
NOC = ["-f", "sim/files_noc.f"]
# key -> (testbench, top, -G overrides, extra verilator flags)
CFG = {
    "base": ("tb/tb_sram_controller.sv", "tb_sram_controller", {}, []),
    "ecc": ("tb/tb_sram_controller.sv", "tb_sram_controller", {"ECC_EN": 1}, []),
    "eccsys": ("tb/tb_ecc_system.sv", "tb_ecc_system", {"NSOAK": 1500}, []),
    "tsp": ("tb/tb_tensor_scratchpad.sv", "tb_tensor_scratchpad", {}, []),
    "tsp_early": ("tb/tb_tensor_scratchpad.sv", "tb_tensor_scratchpad", {"EARLY_DONE": 1}, []),
    "vsp4": ("tb/tb_vector_scratchpad.sv", "tb_vector_scratchpad", {"VEC_LINES": 4, "NRAND": 900}, []),
    "dfab": ("tb/tb_datafabric.sv", "tb_datafabric", {"DW": 32, "NP": 2, "NRAND": 600}, NOC),
    "dfab128": ("tb/tb_datafabric.sv", "tb_datafabric", {"NRAND": 600}, NOC),
    "dfab_noalign": ("tb/tb_datafabric.sv", "tb_datafabric", {"NRAND": 600, "CHK_ALIGN": 0}, NOC),
}
M = [
    ("M01", "rtl/sf_sram_core.sv", "if (be[l]) mem[addr][l*LANE_W +: LANE_W] <= wdata[l*LANE_W +: LANE_W];",
     "mem[addr][l*LANE_W +: LANE_W] <= wdata[l*LANE_W +: LANE_W];", "base", "byte enables ignored on write"),
    ("M02", "rtl/sf_sram_controller.sv", "assign bank_v[i*BW +: BW] = line[BW-1:0];", "assign bank_v[i*BW +: BW] = ~line[BW-1:0];",
     "base", "bank index inverted (a bijection: only the placement test can see it)"),
    ("M03", "rtl/sf_sram_controller.sv", "({1'b0, line} >= CAPW'(CAP_LINES))", "({1'b0, line} > CAPW'(CAP_LINES))",
     "base", "out-of-range off by one line"),
    ("M04", "rtl/sf_sram_controller.sv", "if (gnt[i]) rr_ptr <= (i == NM - 1) ? '0 : MW'(i + 1);", "if (gnt[i]) rr_ptr <= '0;",
     "base", "round-robin pointer stuck at master 0 (starvation)"),
    ("M05", "rtl/sf_sram_controller.sv", "sv[s] <= 1'b1; sid[s*IDW +: IDW] <= m_req_id[i*IDW +: IDW];",
     "sv[s] <= 1'b1; sid[s*IDW +: IDW] <= '0;", "base", "transaction id lost"),
    ("M06", "rtl/sf_sram_controller.sv", "hdata = b_rsp_we[b] ? '0 : b_rsp_rdata[b*DW +: DW];", "hdata = b_rsp_rdata[b*DW +: DW];",
     "base", "write response leaks read data"),
    ("M07", "rtl/sf_sram_controller.sv", "assign m_rsp_valid[i] = head_done & ~flushing & ~flush_i;", "assign m_rsp_valid[i] = head_done;",
     "base", "responses presented during flush"),
    ("M08", "rtl/sf_sram_controller.sv", "wire mis = (ALIGN_MODE != 0) && (a[LB-1:0] != '0);", "wire mis = 1'b0;",
     "base", "alignment check removed"),
    ("M09", "rtl/sf_sram_controller.sv", "b_rsp_tag[b*TAG_W + SW +: MW] == MW'(i) &&", "b_rsp_tag[b*TAG_W + SW +: MW] == MW'(0) &&",
     "base", "bank responses routed to master 0 only"),
    ("M10", "rtl/sf_sram_core.sv", "vpipe[0] <= en;\n      wpipe[0] <= we;", "vpipe[0] <= en & ~we;\n      wpipe[0] <= we;",
     "base", "write completions lost"),
    ("M11", "rtl/sf_sram_controller.sv", "assign can_alloc[i] = (cnt != (SW+1)'(NSLOT)) & ~blocked;",
     "assign can_alloc[i] = (cnt != (SW+1)'(NSLOT + 1)) & ~blocked;", "base", "response slots overrun under backpressure"),
    ("M12", "rtl/sf_sram_controller.sv", "wire                blocked = flushing | flush_i | quiesce_i;", "wire                blocked = flushing | flush_i;",
     "base", "quiesce ignored"),
    ("M13", "rtl/sf_sram_controller.sv", "wd  = wd  | m_req_wdata[i*DW +: DW];", "wd  = wd  | m_req_wdata[0 +: DW];",
     "base", "write data always from master 0"),
    ("M14", "rtl/sf_sram_controller.sv", "end else if (clear_all) begin\n        head <= '0; tail <= '0; cnt <= '0;\n      end else begin",
     "end else begin", "base", "flush leaves stale slots (head/tail not cleared)"),
    ("M15", "rtl/sf_sram_bank.sv", "assign mrg_data = (dec_data & ~be_mask) | (rmw_wdata & be_mask);",
     "assign mrg_data = (dec_data & be_mask) | (rmw_wdata & ~be_mask);", "ecc", "ECC read-modify-write merges the wrong bytes"),
    ("M16", "rtl/sf_sram_bank.sv", "S_RMW: if (rmw_data_back && !dec_ue) begin", "S_RMW: if (1'b0 && rmw_data_back && !dec_ue) begin",
     "ecc", "ECC partial write never written back"),
    ("M17", "rtl/sf_sram_bank.sv", "assign req_ready = idle_st & ~init_pend & ~tst_active_i;", "assign req_ready = ~init_pend & ~tst_active_i;",
     "ecc", "bank accepts a request during an RMW"),
    ("M18", "rtl/sf_sram_bank.sv", "d_valid = 1'b1; d_tag = rmw_tag; d_we = 1'b1;", "d_valid = 1'b0; d_tag = rmw_tag; d_we = 1'b1;",
     "ecc", "RMW write never acknowledged"),
    ("M19", "rtl/sf_sram_bank.sv", "c_wdata = (ECC_EN != 0) ? enc_zero_cw : '0;", "c_wdata = (ECC_EN != 0) ? '0 : '0;",
     "ecc", "init engine writes an invalid (all-zero) codeword"),
    ("M21", "rtl/sf_tensor_scratchpad.sv", "      if (bst[d_req_buf] != S_FILLING) d_rej = 2'd1;", "      if (1'b0) d_rej = 2'd1;",
     "tsp", "DMA may write a buffer that is not FILLING (operands overwritten during compute)"),
    ("M22", "rtl/sf_tensor_scratchpad.sv", "if (d_req_region != 2'd2 || bst[d_req_buf] != S_DRAINING) d_rej = 2'd1;", "if (1'b0) d_rej = 2'd1;",
     "tsp", "DMA may read A/B and read C outside DRAINING"),
    ("M23", "rtl/sf_tensor_scratchpad.sv", "    if (!te_v) a_rej = 2'd1;", "    if (1'b0) a_rej = 2'd1;", "tsp", "TensorCore A access without ownership accepted"),
    ("M24", "rtl/sf_tensor_scratchpad.sv", "wire fill_fin  = fill_v & (fill_done_i | fill_fin_pend) & dma_wr_idle & ~d_wr_acc;",
     "wire fill_fin  = fill_v & (fill_done_i | fill_fin_pend);", "tsp_early", "fill completes before its writes are acknowledged"),
    ("M25", "rtl/sf_tensor_scratchpad.sv", "wire te_fin    = te_v & (te_done_i | te_fin_pend) & te_idle &",
     "wire te_fin    = te_v & (te_done_i | te_fin_pend) &", "tsp_early", "compute completes with accesses still outstanding"),
    ("M26", "rtl/sf_tensor_scratchpad.sv", "if (drain_req_i && !drain_v && bst[drain_ptr] == S_DONE) begin", "if (drain_req_i && !drain_v && bst[drain_ptr] == S_COMPUTE) begin",
     "tsp", "drain grants a buffer still in COMPUTE"),
    ("M27", "rtl/sf_vector_scratchpad.sv", "{8{sub_val[imnb*8 - 1]}}", "{8{1'b0}}", "vsp4", "sign extension lost"),
    ("M28", "rtl/sf_vector_scratchpad.sv", "wire reject     = ~align_ok;", "wire reject     = 1'b0;", "vsp4", "alignment / size rejection removed"),
    ("M29", "rtl/sf_vector_scratchpad.sv", "if (m_active[p]) assembled[p*LINE_W +: LINE_W] = c_rsp_rdata[p*LINE_W +: LINE_W];",
     "assembled[p*LINE_W +: LINE_W] = c_rsp_rdata[p*LINE_W +: LINE_W];", "vsp4", "inactive-line data leaks into a multi-line response (the bug found during bring-up)"),
    ("M30", "rtl/sf_vector_scratchpad.sv", "sub_wd[b*8 +: 8] = rq_wd[(b - ioff)*8 +: 8];", "sub_wd[b*8 +: 8] = rq_wd[b*8 +: 8];", "vsp4", "sub-word write data not shifted to its byte lane"),
    ("M31", "rtl/sf_vector_scratchpad.sv", "if (d_acc) begin dissued <= dissued + 1'b1; daddr <= daddr + dstride; end", "if (d_acc) begin dissued <= dissued + 1'b1; daddr <= daddr + 32'd16; end",
     "vsp4", "DMA ignores the programmed stride"),
    ("M32", "rtl/sf_sram_datafabric.sv", "lane = LANEW'(off[LB-1:WB]);", "lane = LANEW'(off[LB-1:WB]) ^ LANEW'(1);", "dfab", "narrow-fabric lane steering wrong"),
    ("M33", "rtl/sf_sram_datafabric.sv", "assign t_rsp_status = r_err ? 2'd1 : 2'd0;", "assign t_rsp_status = r_err ? 2'd2 : 2'd0;", "dfab128", "target error reported as DECERR instead of SLVERR"),
    ("M34", "rtl/sf_sram_datafabric.sv", "wire [NPW-1:0] hsum = NPW'(t_req_src) + NPW'(t_req_id);", "wire [NPW-1:0] hsum = NPW'(t_req_src) + NPW'(t_req_addr[4]);",
     "dfab", "(src,id) pair no longer pinned to one controller port (breaks SFB3 per-pair ordering)"),
    ("M35", "rtl/sf_sram_datafabric.sv", "assign c_req_be    = {NP{do_wr ? bline : {(LINE_W/8){1'b0}}}};", "assign c_req_be    = {NP{{(LINE_W/8){1'b1}}}};", "dfab", "byte enables ignored"),
    ("M36", "rtl/sf_sram_datafabric.sv", "wire do_wr    = is_wr & ~misal;", "wire do_wr    = is_wr;", "dfab_noalign", "misaligned write reaches the array (adapter guard missing)"),
    ("M39", "rtl/sf_sram_bank.sv", "S_SCRUB: if (scr_data_back && dec_ce && !dec_ue) begin", "S_SCRUB: if (1'b0 && scr_data_back && dec_ce && !dec_ue) begin",
     "eccsys", "scrubber never writes the corrected word back"),
    ("M40", "rtl/sf_sram_bank.sv", "d_status = dec_ue ? `SF_ST_ECC_UE : `SF_ST_OK;\n        e_ce = dec_ce; e_ue = dec_ue; e_row = rmw_row;", "d_status = `SF_ST_OK;\n        e_ce = dec_ce; e_ue = dec_ue; e_row = rmw_row;",
     "eccsys", "RMW onto an uncorrectable line does not report the error"),
    ("M41", "rtl/sf_sram_bank.sv", "S_RMW: if (rmw_data_back && !dec_ue) begin", "S_RMW: if (rmw_data_back) begin",
     "eccsys", "partial write onto an uncorrectable line is NOT aborted (bad bytes blessed with fresh ECC)"),
    ("M42", "rtl/sf_sram_bank.sv", "d_data = dec_data; d_ce = dec_ce; d_status = dec_ue ? `SF_ST_ECC_UE : `SF_ST_OK;", "d_data = dec_data; d_ce = dec_ce; d_status = `SF_ST_OK;",
     "eccsys", "uncorrectable read reported as OK"),
    ("M43", "rtl/sf_ecc_counters.sv", "if (ce_cnt_o != {CNT_W{1'b1}}) ce_cnt_o <= ce_cnt_o + 1'b1;", "if (ce_cnt_o != {CNT_W{1'b1}}) ce_cnt_o <= ce_cnt_o;",
     "eccsys", "correctable-error counter never counts"),
    ("M20", "rtl/sf_sram_core.sv", "rd0 <= mem[addr];\n        end else if (RDW == `SF_RDW_READ_FIRST) begin", "rd0 <= mem[(addr == '0) ? addr : addr - 1'b1];\n        end else if (RDW == `SF_RDW_READ_FIRST) begin",
     "base", "read returns the previous row"),
]


def sh(cmd, cwd, timeout):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or ""), time.time() - t0
    except subprocess.TimeoutExpired:
        return 124, "[TIMEOUT]", time.time() - t0


def run_mutant(m):
    mid, f, old, new, cfg, why = m
    tb, top, over, xflags = CFG[cfg]
    work = tempfile.mkdtemp(prefix=f"mut_{mid}_")
    try:
        for d in ("rtl", "tb", "sim", "third_party", "sim_models"):
            shutil.copytree(os.path.join(ROOT, d), os.path.join(work, d))
        src = open(os.path.join(work, f)).read()
        if src.count(old) != 1:
            return dict(id=mid, file=f, why=why, verdict="BAD-MUTANT", detail=f"pattern occurs {src.count(old)} times")
        open(os.path.join(work, f), "w").write(src.replace(old, new))
        gs = [f"-G{k}={v}" for k, v in over.items()]
        cmd = ["verilator"] + VFLAGS + ["-f", "sim/files_rtl.f"] + xflags + [tb, "--top-module", top, "-Mdir", "b", "-o", "t.exe"] + gs
        rc, out, bs = sh(cmd, work, 900)
        if rc != 0 or not os.path.exists(os.path.join(work, "b", "t.exe")):
            return dict(id=mid, file=f, why=why, verdict="KILLED", detail="build error: " + "; ".join(
                [l for l in out.splitlines() if l.startswith("%Error")][:2]), cfg=cfg)
        rc, out, rs = sh([os.path.join(work, "b", "t.exe")], work, 120)
        res = [l for l in out.splitlines() if l.startswith("RESULT")]
        fails = [l.strip() for l in out.splitlines() if "[FAIL]" in l]
        ok = bool(res) and res[-1].rstrip().endswith("PASS") and rc == 0
        return dict(id=mid, file=f, why=why, cfg=cfg, verdict="SURVIVED" if ok else "KILLED",
                    detail=(fails[0][:150] if fails else (res[-1][-80:] if res else "no RESULT line / timeout")),
                    checks=int(re.search(r"checks=(\d+)", res[-1]).group(1)) if res and "checks=" in res[-1] else None)
    finally:
        shutil.rmtree(work, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "mutation.json"))
    a = ap.parse_args()
    ms = [m for m in M if not a.only or m[0] in a.only]
    with ThreadPoolExecutor(a.jobs) as ex:
        rs = list(ex.map(run_mutant, ms))
    for r in rs:
        print(f"{r['verdict']:10s} {r['id']} {r['why'][:58]:58s} {r.get('detail', '')[:90]}")
    k = sum(r["verdict"] == "KILLED" for r in rs)
    print(f"MUTATION: {k}/{len(rs)} killed; survived: {[r['id'] for r in rs if r['verdict'] == 'SURVIVED']}; bad: {[r['id'] for r in rs if r['verdict'] == 'BAD-MUTANT']}")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(dict(killed=k, total=len(rs), mutants=rs), open(a.out, "w"), indent=1)
    return 0 if k == len(rs) else 1


if __name__ == "__main__":
    sys.exit(main())
