// DIALECT PROBE ONLY: smallest package that satisfies noc_interconnect.sf's documented
// noc_packet_t contract (dst_id, src_id, valid, qos + 1 payload field). Not a reconstruction.
package silicaflux_pkg;
  typedef struct packed { logic [1:0] dst_id; logic [1:0] src_id; logic valid; logic [1:0] qos; logic [31:0] payload; } noc_packet_t;
endpackage
