#!/usr/bin/env python3
"""SilicaFlux MemoryCore - repository audit runner.

Runs real tools (Verilator, Icarus Verilog, Yosys) over every memory-related source
named in the brief and classifies each one.  Nothing here is assumed: every row of the
audit table is produced by a command whose exit status and first error line are kept.

    python3 tools/audit/audit.py --repo <SilicaFlux-main dir> --work <empty scratch dir> \
                                 --out reports/audit.json

Classification (per unit):
  parse        Verilator --lint-only reports no %Error                (SystemVerilog syntax accepted)
  elaborate    same run, top module given, no unresolved references   (Verilator elaborates while linting)
  iverilog     iverilog -g2012 elaboration of the same file set
  yosys_elab   yosys read_verilog -sv; hierarchy -check; proc; check
  yosys_synth  yosys synth; stat (only attempted when yosys_elab passes)
  test         Verilator --binary --timing build + run of the unit's own testbench, when one exists
  blocked_by   'missing-dependency' | 'tool-limitation' | 'source-defect' | '' (first failing stage decides)

A file's *.sf extension is never trusted: the audit feeds the .sf bytes to the tools as they
are (Verilator) and as byte-identical .sv copies (Icarus, Yosys), and reports both.
"""
import argparse, hashlib, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

MISSING_RE = re.compile(r"(Package/class .* not found|Can't resolve module reference|Cannot find file|"
                        r"Unknown .*package|not found|Import package not found|Unsupported: .*package|"
                        r"Reference to .*before declaration|Can't find definition of)", re.I)


def sh(cmd, cwd=None, timeout=120):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        out = (p.stdout or "") + (p.stderr or "")
        return p.returncode, out, round(time.time() - t0, 1)
    except subprocess.TimeoutExpired as e:
        out = ((e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or ""))
        return 124, out + "\n[TIMEOUT]", round(time.time() - t0, 1)


def first_lines(out, pat, n=2):
    ls = [l.strip() for l in out.splitlines() if re.search(pat, l)]
    return [re.sub(r"/[^ ]*/", "", l)[:200] for l in ls[:n]]


def as_sv(files, tmp):
    """Byte-identical copies with a .sv extension (for tools that key on the extension)."""
    os.makedirs(tmp, exist_ok=True)
    out = []
    for i, f in enumerate(files):
        d = os.path.join(tmp, f"{i:02d}_" + re.sub(r"[^A-Za-z0-9_.]", "_", os.path.basename(f)))
        if not d.endswith((".sv", ".v")):
            d += ".sv"
        shutil.copyfile(f, d)
        out.append(d)
    return out


def classify_unit(name, files, top, work, tb_files=None, tb_top=None, timeout=150):
    r = {"unit": name, "files": [os.path.basename(f) for f in files], "top": top}
    missing = [f for f in files if not os.path.exists(f)]
    if missing:
        r["error"] = f"missing input files {missing}"
        return r
    q = " ".join(f'"{f}"' for f in files)
    sv = as_sv(files, os.path.join(work, "sv_" + re.sub(r"\W", "_", name)))
    qs = " ".join(f'"{f}"' for f in sv)
    top_opt = f"--top-module {top}" if top else ""
    wdir = os.path.join(work, "run_" + re.sub(r"\W", "_", name))
    os.makedirs(wdir, exist_ok=True)

    rc, out, s = sh(f"verilator --lint-only -Wall -Wno-fatal -sv {q} {top_opt}", cwd=wdir, timeout=timeout)
    errs = [l for l in out.splitlines() if l.startswith("%Error")]
    warns = [l for l in out.splitlines() if l.startswith("%Warning")]
    kinds = {}
    for l in warns:
        m = re.match(r"%Warning-([A-Z0-9]+)", l)
        kinds[m.group(1) if m else "?"] = kinds.get(m.group(1) if m else "?", 0) + 1
    r["verilator"] = {"errors": len(errs), "warnings": len(warns), "warning_kinds": kinds,
                      "first_errors": first_lines(out, r"^%Error", 3), "secs": s}
    r["parse"] = len(errs) == 0
    miss = any(MISSING_RE.search(l) for l in errs)
    # a syntax error in a header that uses a package type is the Verilator symptom of an unresolved package
    pkg_symptom = any("syntax error, unexpected IDENTIFIER" in l for l in errs)
    # constructs Verilator 5.020 documents as unsupported (SVA ## ranges, delayed array assignment in loops):
    # legal SystemVerilog that this tool cannot take, so NOT a source defect
    unsupported = errs and all(re.match(r"%Error(-UNSUPPORTED|-BLKLOOPINIT)", l) or l.startswith("%Error: Exiting") for l in errs)
    r["verilator_dep_hint"] = ("missing-dependency" if (miss or pkg_symptom) else
                               "tool-limitation(verilator-5.020-unsupported-construct)" if unsupported else
                               "source-defect" if errs else "")

    rc, out, s = sh(f"iverilog -g2012 -o /dev/null {('-s ' + top) if top else ''} {qs}", cwd=wdir, timeout=timeout)
    r["iverilog"] = {"ok": rc == 0 if top else None, "first_errors": first_lines(out, r"error|sorry|syntax", 3), "secs": s}

    ycmd = (f'read_verilog -sv {qs}; hierarchy -check {("-top " + top) if top else "-auto-top"}; proc; check -assert')
    rc, out, s = sh(f"yosys -q -p '{ycmd}'", cwd=wdir, timeout=timeout)
    r["yosys_elab"] = {"ok": rc == 0, "first_errors": first_lines(out, r"ERROR|Warning:.*(latch|drive)", 3), "secs": s}
    if rc == 0 and top:
        rc2, out2, s2 = sh(f"yosys -p 'read_verilog -sv {qs}; hierarchy -check -top {top}; synth -top {top} -flatten; "
                           f"stat' 2>&1 | tail -45", cwd=wdir, timeout=300)
        cells = re.findall(r"^\s*([0-9]+)\s+cells", out2, re.M)
        lat = len(re.findall(r"\$_DLATCH|\$dlatch", out2))
        r["yosys_synth"] = {"ok": ("Number of cells" in out2 or bool(cells)), "cells": cells[-1] if cells else None,
                            "latches": lat, "secs": s2}
    else:
        r["yosys_synth"] = {"ok": False, "skipped": "elaboration failed" if rc else "no top"}

    if tb_files:
        tq = " ".join(f'"{f}"' for f in files + tb_files)
        bd = os.path.join(wdir, "tb_build")
        rc, out, s = sh(f"verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -sv --assert {tq} "
                        f"--top-module {tb_top} -Mdir {bd} -o tb.exe", cwd=wdir, timeout=300)
        t = {"build_ok": rc == 0, "build_secs": s, "build_errors": first_lines(out, r"^%Error", 3),
             "pins_not_found": len(re.findall(r"^%Error-PINNOTFOUND", out, re.M))}
        if rc == 0:
            rc, out, s = sh(f"{bd}/tb.exe", cwd=wdir, timeout=timeout)
            verdict = [l.strip()[:120] for l in out.splitlines()
                       if re.search(r"ALL TESTS PASSED|TESTS? FAILED|FAILURES?\s*[:=]\s*[0-9]+|\bFAIL\b.*[0-9]|RESULT", l)]
            t.update({"run_rc": rc, "run_secs": s, "verdict_lines": verdict[:4],
                      "tail": [l[:160] for l in out.strip().splitlines()[-3:]]})
        r["test"] = t
    # first failing stage decides blocked_by
    if not r["parse"]:
        r["blocked_by"] = r["verilator_dep_hint"]
    elif not r["yosys_elab"]["ok"]:
        r["blocked_by"] = "tool-limitation(yosys-0.33-frontend)"
    elif not r["iverilog"]["ok"]:
        r["blocked_by"] = "tool-limitation(iverilog-12)"
    else:
        r["blocked_by"] = ""
    return r


def md5(p):
    h = hashlib.md5()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="SilicaFlux-main directory")
    ap.add_argument("--work", required=True, help="empty scratch directory")
    ap.add_argument("--mcr", help="extracted memory_cache_repo/memory_cache_repo directory")
    ap.add_argument("--out", default="reports/audit.json")
    ap.add_argument("--jobs", type=int, default=2)
    a = ap.parse_args()
    repo, work = os.path.abspath(a.repo), os.path.abspath(a.work)
    os.makedirs(work, exist_ok=True)
    S25 = os.path.join(repo, "SilicaFlux2.0", "SilicaFlux2.5")
    P136 = os.path.join(repo, "silicaflux_pkg (1).sf")
    PBIG = os.path.join(repo, "silicaflux_pkg.sf")
    PFE = os.path.join(repo, "sf_frontend_pkg.sf")
    units = []

    def U(name, files, top, tb=None, tbtop=None):
        units.append((name, files, top, tb, tbtop))

    # ---- .sf files named in the brief --------------------------------------------
    U("memory_controller.sf [+pkg(1)]", [P136, os.path.join(repo, "memory_controller.sf")], "memory_controller")
    U("memory_controller.sf [+pkg 2081-line]", [PBIG, os.path.join(repo, "memory_controller.sf")], "memory_controller")
    U("tb_memory_controller.sf (self-checking TB + DUT)", [P136, os.path.join(repo, "memory_controller.sf")],
      "memory_controller", [os.path.join(S25, "tb_memory_controller.sf")], "tb_memory_controller")
    U("noc_interconnect.sf [+pkg 2081-line]", [PBIG, os.path.join(S25, "noc_interconnect.sf")], "noc_interconnect")
    U("noc_interconnect.sf [+pkg(1)]", [P136, os.path.join(S25, "noc_interconnect.sf")], "noc_interconnect")
    U("noc_interconnect.sf [+1-struct PROBE STUB, not a reconstruction]",
      [os.path.join(os.path.dirname(os.path.abspath(__file__)), "noc_probe_stub_pkg.sv"), os.path.join(S25, "noc_interconnect.sf")],
      "noc_interconnect")
    U("compute_tile.sf [+pkg 2081-line]", [PBIG, os.path.join(S25, "compute_tile.sf")], "compute_tile")
    U("compute_tile.sf [+pkg(1)]", [P136, os.path.join(S25, "compute_tile.sf")], "compute_tile")
    U("sram-decoder.sf", [os.path.join(S25, "sram-decoder.sf")], "sf_sram_bank_decode")
    for m, pk in (("register_bank.sf", PBIG), ("forwarding_unit.sf", PBIG), ("vector_engine.sf", PBIG),
                  ("tensor_unit.sf", PBIG), ("alu.sf", PBIG), ("tile_interface.sf", PBIG),
                  ("scheduler.sf", PBIG), ("silicaflux_top.sf", PBIG)):
        base = os.path.join(repo, m) if os.path.exists(os.path.join(repo, m)) else os.path.join(S25, m)
        top = {"register_bank.sf": "register_bank", "forwarding_unit.sf": "forwarding_unit",
               "vector_engine.sf": "vector_engine", "tensor_unit.sf": "tensor_unit", "alu.sf": "sf_alu",
               "tile_interface.sf": "tile_interface", "scheduler.sf": "scheduler",
               "silicaflux_top.sf": "silicaflux_top"}[m]
        U(f"{m} [+pkg 2081-line]", [pk, base], top)
    # ---- memory_cache_repo -------------------------------------------------------
    if a.mcr:
        R = os.path.abspath(a.mcr)
        pk = os.path.join(R, "rtl", "mem_pkg.sv")
        for m, tb in (("sp_ram", "tb_sp_ram"), ("dp_ram", "tb_dp_ram"), ("sync_fifo", "tb_sync_fifo"),
                      ("async_fifo", "tb_async_fifo"), ("direct_mapped_cache", "tb_direct_mapped_cache"),
                      ("set_assoc_cache", "tb_set_assoc_cache"), ("memory_controller", "tb_memory_controller")):
            U(f"memory_cache_repo/{m}.sv", [pk, os.path.join(R, "rtl", m + ".sv")], m,
              [os.path.join(R, "tb", tb + ".sv")], tb)
        U("memory_cache_repo/mem_pkg.sv (package alone)", [pk], None)

    def run(u):
        n, f, t, tb, tt = u
        return classify_unit(n, f, t, work, tb, tt)

    with ThreadPoolExecutor(a.jobs) as ex:
        results = list(ex.map(run, units))

    # ---- duplicate detection across the working tree ---------------------------------
    dup = {}
    for root, _, fs in os.walk(repo):
        for f in fs:
            if f.endswith((".sf", ".sfx", ".sv", ".zip")):
                p = os.path.join(root, f)
                dup.setdefault(md5(p), []).append(os.path.relpath(p, repo))
    dups = [v for v in dup.values() if len(v) > 1]
    # same-name different-content files (the dangerous kind)
    byname = {}
    for v in dup.values():
        for p in v:
            byname.setdefault(os.path.basename(p), set()).add(tuple(sorted(v))[0])
    same_name_diff = {n: sorted(h) for n, h in byname.items() if len(h) > 1 and n.endswith((".sf", ".sv"))}
    pkg_defs = {}
    for root, _, fs in os.walk(repo):
        for f in fs:
            if f.endswith(".sf"):
                p = os.path.join(root, f)
                txt = open(p, errors="replace").read()
                for m in re.finditer(r"^\s*package\s+([A-Za-z_0-9]+)", txt, re.M):
                    pkg_defs.setdefault(m.group(1), []).append(
                        {"file": os.path.relpath(p, repo), "lines": txt.count("\n"), "md5": md5(p)})
    doc = {"tool_versions": {"verilator": sh("verilator --version")[1].strip(),
                             "iverilog": sh("iverilog -V 2>&1 | head -1")[1].strip(),
                             "yosys": sh("yosys -V")[1].strip()},
           "units": results, "duplicate_groups": dups, "same_name_different_content": same_name_diff,
           "package_definitions": pkg_defs}
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(doc, open(a.out, "w"), indent=1)
    print(f"wrote {a.out}: {len(results)} units")
    for r in results:
        t = r.get("test", {})
        print(f"{r['unit'][:56]:56s} parse={'Y' if r.get('parse') else 'N'} iv={'Y' if r.get('iverilog',{}).get('ok') else 'N'} "
              f"ys={'Y' if r.get('yosys_elab',{}).get('ok') else 'N'} synth={'Y' if r.get('yosys_synth',{}).get('ok') else 'N'} "
              f"tb={('build' + ('+run rc=' + str(t.get('run_rc')) + ' ' + ('/'.join(t.get('verdict_lines', []))[:30]) if t.get('build_ok') else ':FAIL(pins missing=' + str(t.get('pins_not_found')) + ')')) if t else '-'} "
              f"blocked={r.get('blocked_by','')}")


if __name__ == "__main__":
    main()
