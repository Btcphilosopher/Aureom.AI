#!/usr/bin/env python3
"""Compatibility patch #2 for memory_controller.sf: zero-based word-address vector (tool-robustness fix).

PROBLEM (reproduced, reports/legacy_mc.log): the shipped controller declares
      typedef logic [SF_PADDR_W-1:WORD_OFF_W] waddr_t;            // indices 31:2
and mc_decode() slices it with BYTE-address bit numbers (addr[SF_PADDR_W-1:SPM_ADDR_W] = [31:12], [SPM_ADDR_W-1:LINE_OFF_W], ...).
Under Verilator 5.020 the slice is evaluated on a 0-based vector: in_range is always 0 and line always 0, so EVERY scalar / vector / burst
access is answered SF_MEM_EXC_RANGE (1512 of 1516 operations of sf_compat/tb_legacy_mc.sv).  The construct is legal IEEE 1800 as far as
we can tell, so whether this is a Verilator limitation or a source defect could not be decided with one tool; either way the shipped file
does not work in the toolchain available in this repository.

FIX (this script, applied to a COPY, never to the original): make the vector zero-based and subtract WORD_OFF_W from the three slices:
      typedef logic [SF_PADDR_W-WORD_OFF_W-1:0] waddr_t;
      in_range = addr[SF_PADDR_W-WORD_OFF_W-1 : SPM_ADDR_W-WORD_OFF_W]      line = addr[SPM_ADDR_W-WORD_OFF_W-1 : LINE_OFF_W-WORD_OFF_W]
      lane = addr[LINE_OFF_W-WORD_OFF_W-1 : 0]
Behaviour is identical for a 0-based interpretation of the original; nothing else is touched.  Each pattern must occur exactly once.

    python3 sf_compat/patch_waddr.py <in memory_controller.sf> <out .sv>
"""
import sys
EDITS = [
    ("typedef logic [SF_PADDR_W-1:WORD_OFF_W]       waddr_t;", "typedef logic [SF_PADDR_W-WORD_OFF_W-1:0]       waddr_t;"),
    ("dec.in_range = (addr[SF_PADDR_W-1:SPM_ADDR_W] == APT_TAG);", "dec.in_range = (addr[SF_PADDR_W-WORD_OFF_W-1:SPM_ADDR_W-WORD_OFF_W] == APT_TAG);"),
    ("dec.line     = addr[SPM_ADDR_W-1:LINE_OFF_W];", "dec.line     = addr[SPM_ADDR_W-WORD_OFF_W-1:LINE_OFF_W-WORD_OFF_W];"),
    ("dec.lane     = addr[LINE_OFF_W-1:WORD_OFF_W];", "dec.lane     = addr[LINE_OFF_W-WORD_OFF_W-1:0];"),
]
def main():
    src, dst = sys.argv[1], sys.argv[2]
    t = open(src).read()
    for old, new in EDITS:
        assert t.count(old) == 1, f"pattern not found exactly once: {old!r} ({t.count(old)})"
        t = t.replace(old, new)
    open(dst, "w").write(t)
    print(f"patched {len(EDITS)} lines -> {dst}")
if __name__ == "__main__":
    main()
