// =============================================================================
// SilicaFlux MemoryCore :: sf_compat/tb_legacy_mc
// Compatibility test of the EXISTING SilicaFlux 2.5 memory_controller.sf (taken byte-identical from the repository, compiled through
// sf_compat/sf2sv.py which is an identity copy) against
//   (1) an independent byte-accurate reference model, and
//   (2) the NEW sf_sram_controller driven through the same operations (same capacity: 4 banks x 64 lines x 16 B = 4 KiB),
// for the semantics the two controllers share: 32-bit scalar loads/stores with byte strobes (scalar domain), 128-bit vector
// loads/stores with 4-lane masks (vector domain), burst DMA, and the exception codes.  The shipped tb_memory_controller.sf could NOT be
// used: 53 of its 54 DUT pins do not exist on the shipped DUT (docs/AUDIT.md), so this is the first test that exercises the legacy
// controller as shipped.
// Legacy address map (SPM_BASE = 32'h1000_0000):  paddr = | tag | row | bank | lane | byte |   lines [0,SCALAR_LINES) scalar domain,
// [SCALAR_LINES, TOTAL) vector domain (STRICT_DOMAINS = 1).  Mapping to the new controller: addr_new = paddr - SPM_BASE (same line
// interleave), scalar word -> byte lanes of the 16 B line, vector lane k -> bytes 4k..4k+3.
// Prints RESULT tb=legacy_mc ... PASS|FAIL with the number of mismatching operations.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_legacy_mc;
  import silicaflux_pkg::*;
  localparam int NB = 4, BANK_DEPTH = 64, SCALAR_LINES = 128;
  localparam int TOTAL = NB * BANK_DEPTH;
  localparam logic [31:0] BASE = 32'h1000_0000;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- legacy DUT
  logic s_v = 0, s_rdy, s_rv, s_rr = 1, v_v = 0, v_rdy, v_rv, v_rr = 1;
  sf_scalar_mem_req_t s_req; sf_scalar_mem_rsp_t s_rsp;
  sf_vector_mem_req_t v_req; sf_vector_mem_rsp_t v_rsp;
  logic b_rv = 0, b_rrdy, b_wv = 0, b_wrdy, b_dv, b_dr = 1, b_dd, b_ddr = 1;
  sf_burst_desc_t b_req; sf_burst_wbeat_t b_w; sf_burst_rbeat_t b_r; sf_burst_done_t b_done;
  logic [NB-1:0] coh_v; sf_paddr_t [NB-1:0] coh_a;
  logic init_done, busy, conflict;

  memory_controller #(.SPM_BASE(BASE), .NUM_BANKS(NB), .BANK_DEPTH(BANK_DEPTH), .SCALAR_LINES(SCALAR_LINES), .SRAM_LATENCY(1),
                      .BURST_MAX_BEATS(16), .BURST_PAGE_BYTES(1024), .INIT_ON_RESET(1'b1)) legacy (
    .clk_i(clk), .rst_ni(rst_n), .flush_i(1'b0), .burst_kill_i(1'b0),
    .scalar_req_valid_i(s_v), .scalar_req_ready_o(s_rdy), .scalar_req_i(s_req), .scalar_rsp_valid_o(s_rv), .scalar_rsp_ready_i(s_rr), .scalar_rsp_o(s_rsp),
    .vector_req_valid_i(v_v), .vector_req_ready_o(v_rdy), .vector_req_i(v_req), .vector_rsp_valid_o(v_rv), .vector_rsp_ready_i(v_rr), .vector_rsp_o(v_rsp),
    .burst_req_valid_i(b_rv), .burst_req_ready_o(b_rrdy), .burst_req_i(b_req), .burst_wdata_valid_i(b_wv), .burst_wdata_ready_o(b_wrdy), .burst_wdata_i(b_w),
    .burst_rdata_valid_o(b_dv), .burst_rdata_ready_i(b_dr), .burst_rdata_o(b_r), .burst_done_valid_o(b_dd), .burst_done_ready_i(b_ddr), .burst_done_o(b_done),
    .coh_wr_valid_o(coh_v), .coh_wr_addr_o(coh_a), .init_done_o(init_done), .busy_o(busy), .bank_conflict_o(conflict));

  // ---------------------------------------------------------------- new controller on the same capacity
  logic n_v = 0, n_rdy, n_we = 0, n_rv, n_rr = 1, n_rwe, n_rce, n_idle;
  logic [15:0] n_addr = 0; logic [127:0] n_wd = 0, n_rd; logic [15:0] n_be = 0; logic [7:0] n_id = 0, n_rid; logic [2:0] n_st;
  logic [4*512-1:0] n_tst;
  sf_sram_controller #(.NM(1), .NB(NB), .DEPTH(BANK_DEPTH), .DW(128), .AW(16), .IDW(8), .NSLOT(4), .INIT_ON_RESET(1)) fresh (
    .clk(clk), .rst_n(rst_n), .m_req_valid(n_v), .m_req_ready(n_rdy), .m_req_we(n_we), .m_req_addr(n_addr), .m_req_wdata(n_wd), .m_req_be(n_be), .m_req_id(n_id),
    .m_rsp_valid(n_rv), .m_rsp_ready(n_rr), .m_rsp_rdata(n_rd), .m_rsp_id(n_rid), .m_rsp_we(n_rwe), .m_rsp_status(n_st), .m_rsp_ce(n_rce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(1'b0), .idle_o(n_idle), .init_start_i(1'b0), .init_busy_o(), .scrub_en_i(1'b0), .ecc_clr_i(1'b0),
    .ev_ce_o(), .ev_ue_o(), .ce_cnt_o(), .ue_cnt_o(), .perf_acc_o(), .perf_conf_o(), .perf_busy_o(), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0), .tst_rdata_o(n_tst),
    .fi_bank('0), .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  // ---------------------------------------------------------------- model and helpers
  byte unsigned ref_mem [TOTAL*16];
  bit ref_known [TOTAL*16];
  logic [31:0] rng = 32'h1E6AC700;
  function automatic logic [31:0] rnd(); rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5); return rng; endfunction
  function automatic int rndn(input int n); logic [31:0] r; r = rnd(); return int'(r % 32'(n)); endfunction
  int n_ops = 0, n_ref_mis = 0, n_xc_mis = 0, n_exc_mis = 0, n_checks = 0;
  string first_mis = "";
  task automatic note(input string kind, input string m);
    if (kind == "ref") n_ref_mis++; else if (kind == "xc") n_xc_mis++; else n_exc_mis++;
    if (first_mis == "") first_mis = m;
    if (n_ref_mis + n_xc_mis + n_exc_mis <= 12) $display("  [MISMATCH %s] %s", kind, m);
  endtask

  // run the same operation on the NEW controller and return its response
  task automatic fresh_xfer(input bit we, input logic [31:0] paddr, input logic [127:0] wd, input logic [15:0] be, output logic [127:0] rd, output logic [2:0] st);
    int g;
    @(negedge clk); n_v = 1; n_we = we; n_addr = 16'(paddr - BASE); n_wd = wd; n_be = be;
    g = 0; do begin @(posedge clk); g++; end while (!n_rdy && g < 100);
    @(negedge clk); n_v = 0;
    g = 0; while (!n_rv && g < 100) begin @(posedge clk); g++; end
    rd = n_rd; st = n_st; @(posedge clk);
  endtask

  // legacy scalar transfer
  task automatic leg_scalar(input bit we, input logic [31:0] a, input logic [31:0] wd, input logic [3:0] strb, output logic [31:0] rd, output sf_mem_exc_e exc);
    int g;
    @(negedge clk);
    s_v = 1; s_req.op = we ? SF_MEM_STORE : SF_MEM_LOAD; s_req.addr = a; s_req.wdata = wd; s_req.wstrb = strb; s_req.tag = 8'(n_ops); s_req.hint = SF_MEM_HINT_NORMAL;
    g = 0; do begin @(posedge clk); g++; end while (!s_rdy && g < 200);
    @(negedge clk); s_v = 0;
    g = 0; while (!s_rv && g < 200) begin @(posedge clk); g++; end
    if (g >= 200) begin note("ref", "legacy scalar response timeout"); rd = '0; exc = SF_MEM_EXC_NONE; end
    else begin rd = s_rsp.rdata; exc = s_rsp.exc; end
    @(posedge clk);
  endtask
  task automatic leg_vector(input bit we, input logic [31:0] a, input logic [127:0] wd, input logic [3:0] lm, output logic [127:0] rd, output sf_mem_exc_e exc);
    int g;
    @(negedge clk);
    v_v = 1; v_req.op = we ? SF_MEM_STORE : SF_MEM_LOAD; v_req.addr = a; v_req.wdata = wd; v_req.lane_mask = lm; v_req.tag = 8'(n_ops); v_req.hint = SF_MEM_HINT_NORMAL;
    g = 0; do begin @(posedge clk); g++; end while (!v_rdy && g < 200);
    @(negedge clk); v_v = 0;
    g = 0; while (!v_rv && g < 200) begin @(posedge clk); g++; end
    if (g >= 200) begin note("ref", "legacy vector response timeout"); rd = '0; exc = SF_MEM_EXC_NONE; end
    else begin rd = v_rsp.rdata; exc = v_rsp.exc; end
    @(posedge clk);
  endtask

  function automatic int exp_exc_scalar(input logic [31:0] a);
    int line;
    if ((a >> 4) < (BASE >> 4) || (a - BASE) >= TOTAL * 16) return int'(SF_MEM_EXC_RANGE);
    if (a[1:0] != 0) return int'(SF_MEM_EXC_MISALIGN);
    line = int'((a - BASE) >> 4);
    if (line >= SCALAR_LINES) return int'(SF_MEM_EXC_DOMAIN);
    return int'(SF_MEM_EXC_NONE);
  endfunction
  function automatic int exp_exc_vector(input logic [31:0] a);
    int line;
    if (a < BASE || (a - BASE) >= TOTAL * 16) return int'(SF_MEM_EXC_RANGE);
    if (a[3:0] != 0) return int'(SF_MEM_EXC_MISALIGN);
    line = int'((a - BASE) >> 4);
    if (line < SCALAR_LINES) return int'(SF_MEM_EXC_DOMAIN);
    return int'(SF_MEM_EXC_NONE);
  endfunction

  // one scalar operation: legacy vs model vs new controller
  task automatic do_scalar(input bit we, input logic [31:0] a, input logic [31:0] wd, input logic [3:0] strb);
    logic [31:0] rd; sf_mem_exc_e exc; int ex; logic [127:0] frd; logic [2:0] fst; int base, lane;
    ex = exp_exc_scalar(a);
    leg_scalar(we, a, wd, strb, rd, exc);
    n_ops++;
    if (int'(exc) != ex) note("exc", $sformatf("scalar %s addr %h: legacy exc %0d, expected %0d", we ? "ST" : "LD", a, exc, ex));
    if (ex == 0) begin
      base = int'((a - BASE) >> 4) * 16; lane = int'((a >> 2) & 3);
      if (we) begin
        for (int b = 0; b < 4; b++) if (strb[b]) begin ref_mem[base + lane*4 + b] = wd[b*8 +: 8]; ref_known[base + lane*4 + b] = 1; end
        fresh_xfer(1'b1, a, 128'(wd) << (lane * 32), 16'(strb) << (lane * 4), frd, fst);
      end else begin
        logic [31:0] e; bit kn;
        kn = 1; for (int b = 0; b < 4; b++) begin e[b*8 +: 8] = ref_mem[base + lane*4 + b]; kn &= ref_known[base + lane*4 + b]; end
        fresh_xfer(1'b0, a, '0, '1, frd, fst);
        n_checks++;
        if (kn && rd !== e) note("ref", $sformatf("scalar LD %h: legacy %h != model %h", a, rd, e));
        if (kn && frd[lane*32 +: 32] !== e) note("xc", $sformatf("scalar LD %h: NEW controller %h != model %h", a, frd[lane*32 +: 32], e));
        if (kn && frd[lane*32 +: 32] !== rd) note("xc", $sformatf("scalar LD %h: legacy %h != new %h", a, rd, frd[lane*32 +: 32]));
      end
    end
  endtask
  task automatic do_vector(input bit we, input logic [31:0] a, input logic [127:0] wd, input logic [3:0] lm);
    logic [127:0] rd; sf_mem_exc_e exc; int ex; logic [127:0] frd; logic [2:0] fst; int base; logic [15:0] be;
    ex = exp_exc_vector(a);
    leg_vector(we, a, wd, lm, rd, exc);
    n_ops++;
    if (int'(exc) != ex) note("exc", $sformatf("vector %s addr %h: legacy exc %0d, expected %0d", we ? "ST" : "LD", a, exc, ex));
    if (ex == 0) begin
      base = int'((a - BASE) >> 4) * 16;
      for (int l = 0; l < 4; l++) be[l*4 +: 4] = {4{lm[l]}};
      if (we) begin
        for (int b = 0; b < 16; b++) if (be[b]) begin ref_mem[base + b] = wd[b*8 +: 8]; ref_known[base + b] = 1; end
        fresh_xfer(1'b1, a, wd, be, frd, fst);
      end else begin
        logic [127:0] e; logic [15:0] kn;
        for (int b = 0; b < 16; b++) begin e[b*8 +: 8] = ref_mem[base + b]; kn[b] = ref_known[base + b]; end
        fresh_xfer(1'b0, a, '0, '1, frd, fst);
        n_checks++;
        for (int b = 0; b < 16; b++) if (kn[b]) begin
          // a legacy lane-masked LOAD returns only the selected lanes (others 0): compare the selected lanes only
          if (lm[b/4]) begin
            if (rd[b*8 +: 8] !== e[b*8 +: 8]) note("ref", $sformatf("vector LD %h byte %0d: legacy %h != model %h", a, b, rd[b*8 +: 8], e[b*8 +: 8]));
            if (frd[b*8 +: 8] !== e[b*8 +: 8]) note("xc", $sformatf("vector LD %h byte %0d: NEW %h != model %h", a, b, frd[b*8 +: 8], e[b*8 +: 8]));
          end
        end
      end
    end
  endtask

  // burst (legacy only; checked against the model and read back through the new controller)
  task automatic leg_burst_store(input logic [31:0] base, input int beats, input logic [127:0] d [16]);
    int g;
    @(negedge clk); b_rv = 1; b_req.op = SF_MEM_STORE; b_req.base = base; b_req.len_m1 = 8'(beats - 1); b_req.tag = 8'h5A; b_req.hint = SF_MEM_HINT_NORMAL;
    g = 0; do begin @(posedge clk); g++; end while (!b_rrdy && g < 200);
    @(negedge clk); b_rv = 0;
    for (int k = 0; k < beats; k++) begin
      b_wv = 1; b_w.data = d[k]; b_w.strb = '1;
      g = 0; do begin @(posedge clk); g++; end while (!b_wrdy && g < 200);
      @(negedge clk);
    end
    b_wv = 0;
    g = 0; while (!b_dd && g < 400) begin @(posedge clk); g++; end
    if (b_dd && b_done.exc != SF_MEM_EXC_NONE) note("exc", $sformatf("burst store exc %0d", b_done.exc));
    if (b_dd && b_done.beats != beats) note("ref", $sformatf("burst store beats %0d != %0d", b_done.beats, beats));
    @(posedge clk);
  endtask
  task automatic leg_burst_load(input logic [31:0] base, input int beats, output logic [127:0] d [16], output sf_mem_exc_e exc);
    int g, k;
    @(negedge clk); b_rv = 1; b_req.op = SF_MEM_LOAD; b_req.base = base; b_req.len_m1 = 8'(beats - 1); b_req.tag = 8'hA5; b_req.hint = SF_MEM_HINT_NORMAL;
    g = 0; do begin @(posedge clk); g++; end while (!b_rrdy && g < 200);
    @(negedge clk); b_rv = 0;
    k = 0; g = 0; exc = SF_MEM_EXC_NONE;
    while (k < beats && g < 600) begin
      @(posedge clk); g++;
      if (b_dv && b_dr) begin d[k] = b_r.data; if (b_r.exc != SF_MEM_EXC_NONE) exc = b_r.exc; k++; end
    end
    if (k < beats) note("ref", $sformatf("burst load delivered %0d of %0d beats", k, beats));
    g = 0; while (!b_dd && g < 200) begin @(posedge clk); g++; end
    @(posedge clk);
  endtask

  initial begin
    logic [127:0] bd [16]; logic [127:0] br [16]; sf_mem_exc_e bexc; logic [127:0] frd; logic [2:0] fst;
    for (int i = 0; i < TOTAL*16; i++) begin ref_mem[i] = 0; ref_known[i] = 1; end         // INIT_ON_RESET: lines are zero
    repeat (6) @(posedge clk); rst_n = 1;
    repeat (TOTAL + 40) @(posedge clk);
    $display("CONFIG legacy memory_controller.sf  NUM_BANKS=%0d BANK_DEPTH=%0d SCALAR_LINES=%0d  vs  new sf_sram_controller (same capacity)", NB, BANK_DEPTH, SCALAR_LINES);
    // ---- directed
    do_scalar(1'b1, BASE + 32'h10, 32'hCAFEBABE, 4'hF);
    do_scalar(1'b0, BASE + 32'h10, 0, 4'hF);
    do_scalar(1'b1, BASE + 32'h14, 32'h11223344, 4'b0101);                // byte strobes
    do_scalar(1'b0, BASE + 32'h14, 0, 4'hF);
    do_vector(1'b1, BASE + 32'(SCALAR_LINES * 16), 128'h0123456789ABCDEF_FEDCBA9876543210, 4'hF);
    do_vector(1'b0, BASE + 32'(SCALAR_LINES * 16), 0, 4'hF);
    do_vector(1'b1, BASE + 32'(SCALAR_LINES * 16 + 16), {4{32'hA5A5A5A5}}, 4'b0110);   // lane mask
    do_vector(1'b0, BASE + 32'(SCALAR_LINES * 16 + 16), 0, 4'hF);
    // ---- exceptions
    do_scalar(1'b0, BASE + 32'h13, 0, 4'hF);                              // misaligned
    do_scalar(1'b0, BASE + 32'(SCALAR_LINES * 16), 0, 4'hF);              // scalar port into the vector domain
    do_scalar(1'b0, BASE + 32'(TOTAL * 16), 0, 4'hF);                     // out of range
    do_scalar(1'b0, 32'h0000_0100, 0, 4'hF);                              // outside the aperture
    do_vector(1'b0, BASE + 32'h20, 0, 4'hF);                              // vector port into the scalar domain
    do_vector(1'b0, BASE + 32'(SCALAR_LINES * 16 + 4), 0, 4'hF);          // misaligned
    // ---- random
    for (int n = 0; n < 1500; n++) begin
      int r;
      r = rndn(100);
      if (r < 40) do_scalar(rndn(2) == 0, BASE + 32'(rndn(SCALAR_LINES * 4) * 4), rnd(), (rndn(2) == 0) ? 4'hF : 4'(rnd()));
      else if (r < 80) do_vector(rndn(2) == 0, BASE + 32'((SCALAR_LINES + rndn(TOTAL - SCALAR_LINES)) * 16), {rnd(), rnd(), rnd(), rnd()}, (rndn(2) == 0) ? 4'hF : 4'(rnd()));
      else if (r < 90) do_scalar(rndn(2) == 0, BASE + 32'(rndn(TOTAL * 4 + 8) * 4) + 32'(rndn(4) == 0 ? 1 : 0), rnd(), 4'hF);     // sometimes misaligned / out of range
      else do_vector(rndn(2) == 0, BASE + 32'(rndn(TOTAL + 4) * 16 + (rndn(4) == 0 ? 4 : 0)), {rnd(), rnd(), rnd(), rnd()}, 4'hF);
    end
    // ---- burst: store 8 beats into the vector domain, load back, compare with the model and with the new controller
    for (int k = 0; k < 8; k++) bd[k] = {rnd(), rnd(), rnd(), rnd()};
    leg_burst_store(BASE + 32'((SCALAR_LINES + 8) * 16), 8, bd);
    for (int k = 0; k < 8; k++) for (int b = 0; b < 16; b++) begin ref_mem[(SCALAR_LINES + 8 + k) * 16 + b] = bd[k][b*8 +: 8]; ref_known[(SCALAR_LINES + 8 + k) * 16 + b] = 1; end
    leg_burst_load(BASE + 32'((SCALAR_LINES + 8) * 16), 8, br, bexc);
    n_ops += 2;
    for (int k = 0; k < 8; k++) begin
      n_checks++;
      if (br[k] !== bd[k]) note("ref", $sformatf("burst beat %0d: legacy read-back %h != %h", k, br[k], bd[k]));
      fresh_xfer(1'b1, BASE + 32'((SCALAR_LINES + 8 + k) * 16), bd[k], '1, frd, fst);
      fresh_xfer(1'b0, BASE + 32'((SCALAR_LINES + 8 + k) * 16), '0, '1, frd, fst);
      if (frd !== br[k]) note("xc", $sformatf("burst beat %0d: new controller %h != legacy %h", k, frd, br[k]));
    end
    $display("legacy controller: %0d operations, %0d data checks; mismatches vs model %0d, vs new controller %0d, exception-code mismatches %0d", n_ops, n_checks, n_ref_mis, n_xc_mis, n_exc_mis);
    if (first_mis != "") $display("first mismatch: %s", first_mis);
    $display("RESULT tb=legacy_mc ops=%0d checks=%0d ref_mismatches=%0d crosscheck_mismatches=%0d exception_mismatches=%0d errors=%0d %s", n_ops, n_checks, n_ref_mis, n_xc_mis, n_exc_mis,
             n_ref_mis + n_xc_mis + n_exc_mis, (n_ref_mis + n_xc_mis + n_exc_mis == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(64'd400_000_000); $display("RESULT tb=legacy_mc errors=1 WATCHDOG FAIL"); $finish; end
endmodule
