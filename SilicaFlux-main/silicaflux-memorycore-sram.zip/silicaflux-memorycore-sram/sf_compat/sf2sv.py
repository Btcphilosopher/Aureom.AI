#!/usr/bin/env python3
"""Silica Flux (.sf) -> SystemVerilog (.sv) compatibility transformation for the SilicaFlux repository.

FINDING (reports/audit.json, docs/AUDIT.md): every .sf RTL file in this repository that carries the header
"Language : Silica Flux-2017" is plain IEEE 1800-2017 SystemVerilog text: Verilator 5.020 accepts the .sf bytes unchanged
(extension is irrelevant to it), and the files that fail do so for MISSING DEFINITIONS (a package that is not in the repository) or
for tool limits (Icarus: concurrent assertions; Yosys 0.33: packed-array typedefs), never for a Silica-Flux-only construct.
So the compatibility transformation is the IDENTITY on the bytes plus a changed extension, and this tool exists to make that claim
checkable instead of assumed:

  python3 sf_compat/sf2sv.py <in.sf>... --out <dir>     copy each file to <dir>/<name>.sv byte-identical, verify with sha256
  python3 sf_compat/sf2sv.py --check <in.sf>...          report header / dialect markers, package dependencies, non-SV markers

Checks performed on every input (no file is ever rewritten):
  * header marker  "Language : Silica Flux-2017" present (or reported as absent)
  * non-SystemVerilog markers: lines starting with Silica-Flux-looking keywords (fn, let, impl, stage, pipeline, #[...]), which would
    mean a real dialect extension (none found in the repository)
  * package imports that are not defined in the given file set (the real reason files fail to elaborate)
  * .sfx files are reported as assembly program sources (not RTL) and skipped
The `silicaflux_pkg` NAME COLLISION is reported: the repository holds two different packages with this name
(core-architecture 2081 lines vs memory-subsystem types 136 lines); memory_controller.sf needs the latter.
"""
import argparse, hashlib, os, re, shutil, sys

NON_SV = re.compile(r"^\s*(fn|let|impl|stage|pipeline|use\s+silica|#\[)\b")


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def analyse(paths):
    defined, rows = {}, []
    for p in paths:
        txt = open(p, errors="replace").read()
        for m in re.finditer(r"^\s*package\s+([A-Za-z_0-9]+)", txt, re.M):
            defined.setdefault(m.group(1), []).append((p, txt.count("\n")))
    for p in paths:
        if p.endswith(".sfx"):
            rows.append(dict(file=p, kind="assembly program (.sfx), not RTL"))
            continue
        txt = open(p, errors="replace").read()
        imps = sorted(set(re.findall(r"import\s+([A-Za-z_0-9]+)::", txt)))
        rows.append(dict(file=p, header=bool(re.search(r"Language\s*:\s*Silica Flux-2017", txt)),
                         non_sv_markers=[l.strip() for l in txt.splitlines() if NON_SV.match(l)][:3],
                         imports=imps, unresolved=[i for i in imps if i not in defined],
                         defines=sorted(set(re.findall(r"^\s*(?:module|package|interface)\s+([A-Za-z_0-9]+)", txt, re.M)))))
    dup = {k: v for k, v in defined.items() if len(v) > 1}
    return rows, dup


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--out")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    rows, dup = analyse(a.files)
    for r in rows:
        print(r)
    for k, v in dup.items():
        print(f"WARNING: package '{k}' is defined {len(v)} times: " + ", ".join(f"{os.path.basename(p)} ({n} lines)" for p, n in v))
    if a.check or not a.out:
        return 0
    os.makedirs(a.out, exist_ok=True)
    for p in a.files:
        if p.endswith(".sfx"):
            continue
        d = os.path.join(a.out, re.sub(r"[^A-Za-z0-9_.]", "_", os.path.splitext(os.path.basename(p))[0]) + ".sv")
        shutil.copyfile(p, d)
        assert sha(p) == sha(d), "identity transformation must preserve every byte"
        print(f"{p} -> {d}  (sha256 {sha(d)[:16]}.. identical)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
