#!/usr/bin/env python3
"""Reproducible RTL-simulation benchmarks A-J of the MemoryCore SRAM subsystem.

    python3 benchmarks/run_bench.py [--jobs 3] [--quick]
        -> reports/bench_rtl.json, reports/bench_rtl.csv, reports/bench_rtl.md

Every number comes from a Verilator simulation of the RTL in this tree (tb/tb_bench_ctrl.sv for the controller experiments,
tb/tb_tensor_scratchpad.sv for C and I, tb/tb_vector_scratchpad.sv for G).  Nothing here is a silicon measurement and nothing is a model:
analytical ceilings and the cycle-accurate Python model are in tools/sramlab and are COMPARED with these results
(reports/sramlab_vs_rtl.*).  Workloads are deterministic (fixed seeds, pure functions of pattern/master/index).

  A sequential scalar loads (4 B)          B wide vector loads (16 B lines)       C tensor operand prefetch (DMA fill rate, tensor TB)
  D full-bank parallel accesses            E single-bank contention               F random access (+ mixed read/write)
  G mixed DMA and compute (vector TB)      H ECC overhead (ECC on vs off, partial writes)
  I double- vs single-buffer tensor execution                                      J SRAM capacity / bank count / master count sweeps
  S saturation sweep (offered load)        Q queue occupancy vs response backpressure and slot count
"""
import argparse, csv, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME"]
PAT = {0: "SEQ_SCALAR4", 1: "SEQ_LINE", 2: "OWN_BANK", 3: "SAME_BANK", 4: "RANDOM_LINE", 5: "RANDOM_RW", 6: "SEQ_WRITE_FULL",
       7: "SEQ_WRITE_PART4", 8: "RANDOM_PART4"}


def sh(cmd, cwd=ROOT, timeout=1800):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr


def build(tag, tb, top, over):
    bdir = os.path.join(ROOT, "build", "bench_" + tag)
    shutil.rmtree(bdir, ignore_errors=True)
    cmd = ["verilator"] + VFLAGS + ["-f", "sim/files_rtl.f", tb, "--top-module", top, "-Mdir", bdir, "-o", "t.exe"] + \
          [f"-G{k}={v}" for k, v in over.items()]
    rc, out = sh(cmd)
    if rc != 0:
        raise RuntimeError(f"build {tag} failed: {out[-500:]}")
    return os.path.join(bdir, "t.exe")


def parse_bench(out, kind="ctrl"):
    rows = []
    for l in out.splitlines():
        if l.startswith(f"BENCH {kind} "):
            kv = dict(re.findall(r"(\w+)=([-\w.]+)", l))
            rows.append({k: (float(v) if re.fullmatch(r"-?\d+\.\d+", v) else int(v) if re.fullmatch(r"-?\d+", v) else v) for k, v in kv.items()})
    return rows


# configurations of the controller benchmark (each needs one Verilator build; workloads are runtime plusargs)
CFG = {
    "base":      dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "ecc":       dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=1, NSLOT=8, ARB=1),
    "L2":        dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=2, ECC_EN=0, NSLOT=8, ARB=1),
    "ecc_L2":    dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=2, ECC_EN=1, NSLOT=8, ARB=1),
    "L3":        dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=3, ECC_EN=0, NSLOT=8, ARB=1),
    "fixed":     dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=0),
    "nb1":       dict(NM=4, NB=1, DEPTH=1024, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "nb2":       dict(NM=4, NB=2, DEPTH=512, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "nb8":       dict(NM=4, NB=8, DEPTH=128, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "nm8_nb4":   dict(NM=8, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "nm8_nb8":   dict(NM=8, NB=8, DEPTH=128, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "nm2_nb4":   dict(NM=2, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "d64":       dict(NM=4, NB=4, DEPTH=64, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "d1024":     dict(NM=4, NB=4, DEPTH=1024, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "d4096":     dict(NM=4, NB=4, DEPTH=4096, READ_LATENCY=1, ECC_EN=0, NSLOT=8, ARB=1),
    "slot2":     dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=2, ARB=1),
    "slot4":     dict(NM=4, NB=4, DEPTH=256, READ_LATENCY=1, ECC_EN=0, NSLOT=4, ARB=1),
}

# (experiment letter, description, config, pattern, extra plusargs)
EXP = []
for p in range(9):
    EXP.append(("AB" if p < 2 else "DEF", f"base config, pattern {p} {PAT[p]}", "base", p, {}))
EXP += [("A", "sequential scalar 4 B loads", "base", 0, {}), ("B", "wide vector (16 B) loads", "base", 1, {}),
        ("D", "full-bank parallel accesses (master m -> bank m)", "base", 2, {}), ("E", "single-bank contention", "base", 3, {}),
        ("E", "single-bank contention, fixed priority", "fixed", 3, {}), ("F", "random access, reads", "base", 4, {}),
        ("F", "random access, mixed read/write", "base", 5, {}), ("F", "random 4 B partial writes + reads", "base", 8, {})]
for p in range(9):
    for c in ("ecc", "L2", "ecc_L2"):
        EXP.append(("H" if "ecc" in c else "L", f"{c} vs base, pattern {p}", c, p, {}))
for c in ("nb1", "nb2", "base", "nb8", "nm2_nb4", "nm8_nb4", "nm8_nb8", "d64", "d1024", "d4096"):
    for p in (1, 2, 4):
        EXP.append(("J", f"sweep {c}", c, p, {}))
for load in (5, 10, 20, 30, 40, 50, 60, 80, 100):
    for c, p in (("base", 4), ("base", 1), ("nb8", 4)):
        EXP.append(("S", f"offered load {load} %", c, p, {"LOAD_PCT": load}))
for c in ("slot2", "slot4", "base"):
    for rp in (100, 50, 20, 10):
        EXP.append(("Q", f"queue occupancy: response ready {rp} %", c, 1, {"RSP_PCT": rp}))
for sd in (1, 2, 3):
    EXP.append(("F", f"random access, seed {sd}", "base", 4, {"SEED": 1000 + sd}))
for c in ("L3",):
    for p in (1, 4, 7):
        EXP.append(("L", "latency 3", c, p, {}))


def run_cfg(item):
    name, over = item
    try:
        exe = build("ctrl_" + name, "tb/tb_bench_ctrl.sv", "tb_bench_ctrl", over)
    except Exception as e:
        return name, None, str(e)
    return name, exe, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--quick", action="store_true", help="reduced request count")
    a = ap.parse_args()
    nreq = 300 if a.quick else 1000
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    t0 = time.time()
    with ThreadPoolExecutor(a.jobs) as ex:
        built = {n: e for n, e, err in ex.map(run_cfg, CFG.items()) if e}
    missing = [n for n in CFG if n not in built]
    if missing:
        print("build failures:", missing)
    rows, seen = [], set()
    for letter, desc, cfg, pat, extra in EXP:
        if cfg not in built:
            continue
        key = (cfg, pat, tuple(sorted(extra.items())))
        args = [f"+PATTERN={pat}", f"+NREQ={nreq}"] + [f"+{k}={v}" for k, v in extra.items()]
        rc, out = sh([built[cfg]] + args)
        rs = parse_bench(out)
        ok = any(l.startswith("RESULT") and l.rstrip().endswith("PASS") for l in out.splitlines())
        for r in rs:
            r.update(experiment=letter, desc=desc, config=cfg, pattern_name=PAT[pat], status="PASS" if ok and rc == 0 else "FAIL")
            if (key not in seen) or True:
                rows.append(r)
        seen.add(key)
    # tensor scratchpad (C, I): tb_tensor_scratchpad BENCH lines
    tcases = [("nbuf2_skew1", {}), ("nbuf1_skew1", {"NBUF": 1}), ("nbuf2_skew0", {"SKEW": 0}), ("nbuf1_skew0", {"NBUF": 1, "SKEW": 0}),
              ("nbuf2_extra16", {"COMPUTE_EXTRA": 16}), ("nbuf1_extra16", {"NBUF": 1, "COMPUTE_EXTRA": 16}),
              ("nbuf2_extra48", {"COMPUTE_EXTRA": 48}), ("nbuf1_extra48", {"NBUF": 1, "COMPUTE_EXTRA": 48}),
              ("nbuf2_ecc", {"ECC_EN": 1}), ("nbuf2_n16", {"N": 16}), ("nbuf1_n16", {"NBUF": 1, "N": 16})]
    trows = []

    def run_t(tc):
        tag, over = tc
        exe = build("tsp_" + tag, "tb/tb_tensor_scratchpad.sv", "tb_tensor_scratchpad", over)
        rc, out = sh([exe])
        return tag, parse_bench(out, "tensor"), out
    with ThreadPoolExecutor(a.jobs) as ex:
        for tag, rs, out in ex.map(run_t, tcases):
            for r in rs:
                r.update(experiment="C/I", desc="tensor tile pipeline " + tag, config=tag)
                trows.append(r)
    # vector scratchpad: DMA with and without concurrent vector traffic (G)
    exe = build("vsp", "tb/tb_vector_scratchpad.sv", "tb_vector_scratchpad", {})
    rc, out = sh([exe])
    g = re.search(r"DMA LOAD of (\d+) beats: (\d+) cycles alone, (\d+) cycles with concurrent vector traffic; bank conflicts seen by the scratchpad: (\d+)", out)
    grows = []
    if g:
        grows.append(dict(experiment="G", desc="mixed DMA LOAD and vector traffic on shared banks", beats=int(g.group(1)), cycles_alone=int(g.group(2)),
                          cycles_with_vector=int(g.group(3)), conflicts=int(g.group(4))))
    res = dict(generated_by="benchmarks/run_bench.py", seconds=round(time.time() - t0, 1), nreq=nreq, controller=rows, tensor=trows, vector_dma=grows,
               verilator=sh(["verilator", "--version"])[1].strip(),
               note="RTL SIMULATION results (Verilator); not silicon measurements.")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "bench_rtl.json"), "w"), indent=1)
    cols = ["experiment", "desc", "config", "pattern", "pattern_name", "nm", "nb", "depth", "read_latency", "ecc", "nslot", "arb", "rsp_pct", "load_pct", "seed",
            "nreq", "cycles", "accesses", "reads", "writes", "useful_bytes", "throughput_Bpc", "bank_conflict_cycles", "bank_busy_stalls", "mean_latency",
            "max_latency", "max_outstanding", "status"]
    with open(os.path.join(ROOT, "reports", "bench_rtl.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    bad = [r for r in rows if r.get("status") != "PASS"]
    print(f"{len(rows)} controller runs ({len(bad)} failed), {len(trows)} tensor runs, {len(grows)} vector/DMA runs in {res['seconds']} s")
    return 1 if bad or missing else 0


if __name__ == "__main__":
    sys.exit(main())
