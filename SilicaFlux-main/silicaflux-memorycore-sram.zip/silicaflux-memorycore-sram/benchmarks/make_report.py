#!/usr/bin/env python3
"""Render docs/BENCHMARKS.md from reports/bench_rtl.json (RTL-SIMULATION) and reports/sramlab_vs_rtl.json (ANALYTICAL ceilings, MODEL).

    python3 benchmarks/run_bench.py        # run all RTL benchmarks (Verilator), ~3 min with 3 jobs
    python3 benchmarks/make_report.py      # -> docs/BENCHMARKS.md
Every number in the document is copied from those JSON files; nothing is typed by hand except the prose.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PAT = ["SEQ_SCALAR4", "SEQ_LINE", "OWN_BANK", "SAME_BANK", "RANDOM_LINE", "RANDOM_RW", "SEQ_WRITE_FULL", "SEQ_WRITE_PART4", "RANDOM_PART4"]


def tbl(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join("---" if i == 0 else "---:" for i in range(len(head))) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def main():
    b = json.load(open(os.path.join(ROOT, "reports", "bench_rtl.json")))
    v = json.load(open(os.path.join(ROOT, "reports", "sramlab_vs_rtl.json")))
    rows = b["controller"]

    def pick(cfg, pat, **kw):
        for r in rows:
            if r["config"] == cfg and r["pattern"] == pat and all(r.get(k) == x for k, x in kw.items()):
                return r
        return None

    std = dict(rsp_pct=100, load_pct=100, seed=0x00C0FFEE)
    ceilmap = {(c["config"], c["pattern"]): c for c in v.get("ceilings", []) if c.get("rsp_pct") == 100 and c.get("load_pct") == 100 and c.get("seed") == 0x00C0FFEE}
    w = []
    w.append("# BENCHMARKS (RTL-SIMULATION, reproducible)")
    w.append("")
    w.append(f"Source: `reports/bench_rtl.json` produced by `benchmarks/run_bench.py` with {b['verilator']}; {b['nreq']} requests per master; `{b['generated_by']}`. "
             "Every row is a Verilator run of `tb/tb_bench_ctrl.sv` / `tb/tb_tensor_scratchpad.sv` / `tb/tb_vector_scratchpad.sv` on the RTL; the workload is a pure function of "
             "(pattern, master, index, seed) with xorshift32, so the Python cycle model in `tools/sramlab` reproduces the identical address stream. **These are simulation results, not silicon measurements.** "
             "ANALYTICAL ceilings come from `tools/sramlab/analytic.py`.")
    w.append("")
    w.append("Cycle convention: `cycles` = (cycle of the last response acceptance) - (cycle of the first presentation); `throughput_Bpc` = useful bytes / cycles; "
             "latency = presentation edge -> response acceptance edge. Base configuration: 4 masters, 4 banks, 256 rows/bank, 128-bit lines, `READ_LATENCY=1`, `NSLOT=8`, round-robin.")
    w.append("")
    w.append("## A-F, base configuration: bandwidth, conflicts, latency")
    w.append("")
    head = ["#", "pattern", "experiment", "RTL B/cycle", "ANALYTICAL ceiling", "RTL/ceiling", "bank-conflict cycles", "mean latency", "max latency"]
    desc = {0: "A scalar 4 B loads (line-aligned)", 1: "B wide 16 B vector loads", 2: "D one bank per master", 3: "E single-bank contention", 4: "F random lines (reads)",
            5: "F random read/write", 6: "full-line writes", 7: "4 B partial writes (no ECC: byte-masked)", 8: "F random 4 B partial + reads"}
    t = []
    for p in range(9):
        r = pick("base", p, **std)
        c = ceilmap.get(("base", p))
        if not r:
            continue
        cb = c["ceil_Bpc"] if c else None
        t.append([p, PAT[p], desc[p], f"{r['throughput_Bpc']:.2f}", f"{cb:.2f}" if cb else "-", f"{100 * r['throughput_Bpc'] / cb:.1f} %" if cb else "-",
                  r["bank_conflict_cycles"], f"{r['mean_latency']:.2f}", r["max_latency"]])
    w.append(tbl(head, t))
    w.append("")
    w.append("Peak = 4 banks x 16 B = 64 B/cycle. A 4 B scalar load uses a whole 16 B line access, so benchmark A is limited to NB x 4 B = 16 B/cycle (25 % of the vector peak). "
             "Random traffic saturates below the peak because of head-of-line blocking (the exact analytical chain reproduces the Karol 1987 limits). "
             "*History:* the first revision of pattern 0 issued byte-strided sub-line addresses that the ALIGN_MODE=1 controller rejected for 3 of 4 requests, so its 15.92 B/cycle credited rejected requests; "
             "the model validation found this and the TB now issues line-aligned loads (`docs/KNOWN_LIMITATIONS.md`, `reports/sramlab_vs_rtl.md`).")
    w.append("")
    w.append("## E - arbitration: round robin vs fixed priority (single-bank contention, pattern 3)")
    w.append("")
    t = []
    for cfg in ("base", "fixed"):
        r = pick(cfg, 3, **std)
        if r:
            t.append([("round robin" if cfg == "base" else "fixed priority"), f"{r['throughput_Bpc']:.2f}", r["bank_conflict_cycles"], f"{r['mean_latency']:.2f}", r["max_latency"]])
    w.append(tbl(["arbitration", "B/cycle", "conflict cycles", "mean latency", "max latency"], t))
    w.append("")
    w.append("## C / I - tensor tile pipeline (single vs double buffering, bank skew)")
    w.append("")
    t = [[x["config"], x["nbuf"], x["skew"], x["nb"], x["n"], x["tiles"], x["read_latency"], x["ecc"], x["total_cycles"], x["cycles_per_tile"], x["overlap_cycles"], x["bank_conflict_cycles"]] for x in b["tensor"]]
    w.append(tbl(["config", "NBUF", "SKEW", "NB", "N", "tiles", "RL", "ECC", "total cycles", "cycles/tile*", "overlap cycles", "conflict cycles"], t))
    w.append("")
    w.append("\\* `cycles/tile` = total cycles / tiles, so it includes pipeline start-up and the last drain; it is not the steady-state period (derived in `reports/sramlab_vs_rtl.md`). "
             "`overlap cycles` counts cycles in which DMA and TensorCore were both active.")
    w.append("")
    w.append("## G - DMA burst vs vector traffic on shared banks")
    w.append("")
    t = [[x["desc"], x["beats"], x["cycles_alone"], x["cycles_with_vector"], x["conflicts"]] for x in b.get("vector_dma", [])]
    w.append(tbl(["experiment", "beats", "cycles alone", "cycles with vector traffic", "DMA/vector bank conflicts"], t))
    w.append("")
    w.append("## H - ECC overhead (ECC / no-ECC, same workload)")
    w.append("")
    t = []
    for rl, (c0, c1) in ((1, ("base", "ecc")), (2, ("L2", "ecc_L2"))):
        for p in range(9):
            a, e = pick(c0, p, **std), pick(c1, p, **std)
            if a and e:
                t.append([rl, PAT[p], f"{a['throughput_Bpc']:.2f}", f"{e['throughput_Bpc']:.2f}", f"{e['throughput_Bpc'] / a['throughput_Bpc']:.3f}", f"{a['mean_latency']:.2f} -> {e['mean_latency']:.2f}"])
    w.append(tbl(["READ_LATENCY", "pattern", "B/cycle no ECC", "B/cycle ECC", "ratio", "mean latency"], t))
    w.append("")
    w.append("Reads and full-line writes keep one access per cycle and gain one cycle of latency; a partial write is an atomic read-modify-write that keeps its bank busy `READ_LATENCY + 1` cycles.")
    w.append("")
    w.append("## J - bank count, master count, depth sweeps (patterns 1, 2, 4)")
    w.append("")
    t = []
    for c in ("nb1", "nb2", "base", "nb8", "nm2_nb4", "nm8_nb4", "nm8_nb8", "d64", "d1024", "d4096"):
        cells = [c]
        r0 = pick(c, 1, **std)
        if not r0:
            continue
        cells += [r0["nm"], r0["nb"], r0["depth"]]
        for p in (1, 2, 4):
            r = pick(c, p, **std)
            cells.append(f"{r['throughput_Bpc']:.2f}" if r else "-")
        t.append(cells)
    w.append(tbl(["config", "NM", "NB", "rows/bank", "SEQ_LINE B/c", "OWN_BANK B/c", "RANDOM_LINE B/c"], t))
    w.append("")
    w.append("Depth does not change bandwidth (rows only change capacity); bank count is the bandwidth lever; more masters than banks raise contention.")
    w.append("")
    w.append("## S - offered-load sweep and Q - response-queue occupancy")
    w.append("")
    t = []
    for r in sorted([r for r in rows if r["config"] == "base" and r["pattern"] == 4 and r["rsp_pct"] == 100 and r["seed"] == 0x00C0FFEE], key=lambda r: r["load_pct"]):
        t.append([r["load_pct"], f"{r['throughput_Bpc']:.2f}", r["bank_conflict_cycles"], f"{r['mean_latency']:.2f}", r["max_latency"]])
    w.append("**S** random lines, base config:")
    w.append("")
    w.append(tbl(["offered load %", "B/cycle", "conflict cycles", "mean latency", "max latency"], t))
    w.append("")
    t = []
    for cfg in ("slot2", "slot4", "base"):
        for rp in (100, 50, 20, 10):
            r = pick(cfg, 1, rsp_pct=rp, load_pct=100, seed=0x00C0FFEE)
            if r:
                t.append([cfg, r["nslot"], rp, f"{r['throughput_Bpc']:.2f}", f"{r['mean_latency']:.2f}", r["max_latency"]])
    w.append("**Q** sequential lines with a slow response consumer (`rsp_pct` = probability the master accepts a response in a cycle):")
    w.append("")
    w.append(tbl(["config", "NSLOT", "response ready %", "B/cycle", "mean latency", "max latency"], t))
    w.append("")
    w.append("## Reproduce")
    w.append("")
    w.append("```\npython3 benchmarks/run_bench.py --jobs 3        # reports/bench_rtl.json / .csv\ncd tools && python3 -m sramlab validate          # model vs these rows (exact)\npython3 benchmarks/make_report.py                # this file\n```")
    w.append("")
    open(os.path.join(ROOT, "docs", "BENCHMARKS.md"), "w").write("\n".join(w) + "\n")
    print("wrote docs/BENCHMARKS.md")


if __name__ == "__main__":
    main()
