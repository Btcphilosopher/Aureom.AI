// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_datafabric
// SFB3 TARGET-port adapter: connects the SRAM controller to the implemented DataFabric NoC
// (silicaflux-datafabric-noc, docs/PROTOCOL.md "SFB3").  The fabric's target port t_* is on one side,
// NP master ports of sf_sram_controller on the other.
//
// ---------------------------------------------------------------- mapping
//   OP_READ          -> controller read of the line containing the address; response carries data.
//   OP_WRITE         -> controller write (byte enables = wstrb); the response is issued after the
//                       write has been performed in the bank (acknowledged write, SFB2 R7).
//   OP_WRITE_POSTED  -> identical write; its response is the posted COMPLETION that the fabric
//                       retires (SFB3 R5: exactly one response per accepted request, posted included).
//   other opcodes    -> never expected at a target; defensively answered ST_SLVERR with no side
//                       effect (issued to the controller as a read so that exactly one response exists).
//   DW (fabric word) 32 / 64 / 128: for DW < 128 the word is steered to its lane of the 128-bit line:
//   lane = addr[LB-1:log2(DW/8)]; wdata/wstrb are placed at that lane and the response data is the
//   same lane of the line.  Reads return a full DW word (SFB3 R10).  An address that is not DW
//   aligned is answered ST_SLVERR with no side effect (the fabric normally filters it earlier).
//   Status:  controller SF_ST_OK -> ST_OKAY(0); SF_ST_RANGE / ALIGN / ECC_UE / OWNER / BADOP -> ST_SLVERR(1).
//   ST_DECERR(2) is a FABRIC status (unmapped address) and is never produced here.  rdata = 0 for
//   writes and for every error (SFB3 "errors never have a side effect").
//
// ---------------------------------------------------------------- ordering contract match
//   SFB3 O2/R5: responses of one (src,id) pair leave in acceptance order; different pairs may be
//   answered in any order.  Controller O2: responses of one master port return in acceptance order.
//   => every (src,id) pair is mapped to ONE controller port (port = (src + id) mod NP), so the pair's
//   order is the controller's per-port order; responses of different pairs may interleave between
//   ports (NP > 1), which SFB3 permits.  With NP = 1 the target is fully in order.
//   Requests of one master to this target arrive in issue order (fabric guarantee) and reach their
//   bank in that order (controller O1); a read after a write of the same (src,id) therefore sees the
//   write (controller O3).  Across masters there is no ordering, exactly as in SFB3 (no coherence).
//
// ---------------------------------------------------------------- flow control
//   t_req_ready = the selected controller port can accept (a free reorder slot, bank grant).  The
//   outstanding limit of this target is NP * controller NSLOT (SFB3 O4).  The response channel is
//   held stable under t_rsp_ready = 0 (SFB3 R4): the selected port is LOCKED until its response is
//   accepted.  No combinational path from t_rsp_ready to t_req_ready.
//
// ---------------------------------------------------------------- bursts
//   SFB3 has no native burst: a burst is a sequence of single-beat transactions.  This adapter
//   sustains one beat per cycle per controller port when the beats map to distinct banks (consecutive
//   lines rotate through the banks).  Beat order, IDs and error status are per beat.
//
// ---------------------------------------------------------------- error reporting
//   err_sticky_o / err_cnt_o / first-error {code, src, id, opcode} captured at the response handshake;
//   err_clr_i clears.  The status also travels in-band to the master (ST_SLVERR).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_datafabric #(
  parameter int NM  = 4,                       // fabric masters (source-id width)
  parameter int AW  = 32,
  parameter int DW  = 128,                     // fabric data width: 32, 64 or 128
  parameter int IDW = 2,
  parameter int NP  = 1,                       // controller master ports used (power of two)
  parameter int LINE_W = 128,
  parameter int CNT_W  = 16,
  // address bits that belong to the SRAM aperture (offset); the fabric passes the ABSOLUTE address, the aperture
  // base bits are masked off here.  The fabric region may be LARGER than the SRAM capacity: offsets beyond the
  // capacity are answered ST_SLVERR by the controller (range error), never aliased.
  parameter logic [AW-1:0] ADDR_MASK = {AW{1'b1}},
  // ---- derived
  parameter int SRCW  = (NM > 1) ? $clog2(NM) : 1,
  parameter int SB    = DW / 8,
  parameter int LB    = $clog2(LINE_W / 8),
  parameter int WB    = $clog2(DW / 8),
  parameter int LANEW = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1,
  parameter int NPW   = (NP > 1) ? $clog2(NP) : 1,
  parameter int IDC   = 3 + SRCW + IDW + LANEW + 1      // controller id: {bad, opcode, src, id, lane}
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---------------------------------------------------------------- SFB3 target port (from the fabric)
  input  wire logic                 t_req_valid,
  output logic                      t_req_ready,
  input  wire logic [2:0]           t_req_opcode,
  input  wire logic [SRCW-1:0]      t_req_src,
  input  wire logic [IDW-1:0]       t_req_id,
  input  wire logic [2:0]           t_req_qos,
  input  wire logic [AW-1:0]        t_req_addr,
  input  wire logic [DW-1:0]        t_req_wdata,
  input  wire logic [SB-1:0]        t_req_wstrb,
  output logic                      t_rsp_valid,
  input  wire logic                 t_rsp_ready,
  output logic [SRCW-1:0]           t_rsp_src,
  output logic [IDW-1:0]            t_rsp_id,
  output logic [2:0]                t_rsp_opcode,
  output logic [1:0]                t_rsp_status,
  output logic [DW-1:0]             t_rsp_rdata,
  // ---------------------------------------------------------------- controller master ports (NP)
  output logic [NP-1:0]             c_req_valid,
  input  wire logic [NP-1:0]        c_req_ready,
  output logic [NP-1:0]             c_req_we,
  output logic [NP*AW-1:0]          c_req_addr,
  output logic [NP*LINE_W-1:0]      c_req_wdata,
  output logic [NP*(LINE_W/8)-1:0]  c_req_be,
  output logic [NP*IDC-1:0]         c_req_id,
  input  wire logic [NP-1:0]        c_rsp_valid,
  output logic [NP-1:0]             c_rsp_ready,
  input  wire logic [NP*LINE_W-1:0] c_rsp_rdata,
  input  wire logic [NP*IDC-1:0]    c_rsp_id,
  input  wire logic [NP-1:0]        c_rsp_we,
  input  wire logic [NP*3-1:0]      c_rsp_status,
  // ---------------------------------------------------------------- error reporting
  input  wire logic                 err_clr_i,
  output logic                      err_sticky_o,
  output logic [CNT_W-1:0]          err_cnt_o,
  output logic [2:0]                err_code_o,
  output logic [SRCW-1:0]           err_src_o,
  output logic [IDW-1:0]            err_id_o,
  output logic [2:0]                err_opcode_o
);
  // opcodes (sfn_pkg): READ 0, WRITE 1, WRITE_POSTED 2, FENCE 3
  localparam logic [2:0] OP_READ = 3'd0, OP_WRITE = 3'd1, OP_WRITE_POSTED = 3'd2;

  if (DW != 32 && DW != 64 && DW != 128) begin : g_err_dw
    `SF_CFG_FATAL("sf_sram_datafabric: fabric DW must be 32, 64 or 128")
  end
  if (LINE_W != 128 || DW > LINE_W) begin : g_err_line
    `SF_CFG_FATAL("sf_sram_datafabric: LINE_W must be 128 and DW <= LINE_W")
  end
  if (NP < 1 || (NP & (NP - 1)) != 0) begin : g_err_np
    `SF_CFG_FATAL("sf_sram_datafabric: NP must be a power of two")
  end

  // ------------------------------------------------------------ request decode
  wire is_rd    = (t_req_opcode == OP_READ);
  wire is_wr    = (t_req_opcode == OP_WRITE) || (t_req_opcode == OP_WRITE_POSTED);
  wire bad_op   = ~(is_rd | is_wr);
  wire [AW-1:0] off = t_req_addr & ADDR_MASK;
  wire misal    = (WB > 0) ? (off[WB-1:0] != '0) : 1'b0;
  wire bad      = bad_op | misal;
  wire do_wr    = is_wr & ~misal;                          // a misaligned write must have no side effect
  logic [LANEW-1:0]    lane;
  logic [LINE_W-1:0]   wline;
  logic [LINE_W/8-1:0] bline;
  if (DW == LINE_W) begin : g_wide
    assign lane  = '0;
    assign wline = LINE_W'(t_req_wdata);
    assign bline = (LINE_W/8)'(t_req_wstrb);
  end else begin : g_narrow
    assign lane = LANEW'(off[LB-1:WB]);
    always_comb begin
      wline = '0;
      bline = '0;
      for (int l = 0; l < LINE_W / DW; l++)
        if (lane == LANEW'(l)) begin
          wline[l*DW +: DW] = t_req_wdata;
          bline[l*SB +: SB] = t_req_wstrb;
        end
    end
  end
  wire [AW-1:0] line_addr = {off[AW-1:LB], {LB{1'b0}}};
  wire [IDC-1:0] cid = {bad, t_req_opcode, t_req_src, t_req_id, lane};

  // (src,id) -> controller port: same pair, same port, so per-pair order == controller per-port order
  wire [NPW-1:0] hsum = NPW'(t_req_src) + NPW'(t_req_id);
  wire [NPW-1:0] psel = (NP > 1) ? hsum : '0;

  always_comb begin
    for (int p = 0; p < NP; p++) begin
      c_req_valid[p] = t_req_valid & (psel == NPW'(p));
    end
  end
  assign c_req_we    = {NP{do_wr}};
  assign c_req_addr  = {NP{line_addr}};
  assign c_req_wdata = {NP{wline}};
  assign c_req_be    = {NP{do_wr ? bline : {(LINE_W/8){1'b0}}}};
  assign c_req_id    = {NP{cid}};
  assign t_req_ready = c_req_ready[psel];
  wire unused_q = &{1'b0, t_req_qos};

  // ------------------------------------------------------------ response arbitration (round robin, locked while stalled)
  logic [NPW-1:0] rr_ptr, sel_q, sel;
  logic           lock_q;
  logic           pick_v;
  logic [NPW-1:0] pick;
  always_comb begin
    /* verilator lint_off UNUSEDSIGNAL */
    integer pi, kk;
    /* verilator lint_on UNUSEDSIGNAL */
    pick = '0; pick_v = 1'b0; pi = 0; kk = 0;
    for (kk = 0; kk < NP; kk = kk + 1) begin
      pi = ({{(32-NPW){1'b0}}, rr_ptr} + kk) % NP;
      if (!pick_v && c_rsp_valid[pi]) begin pick = NPW'(pi); pick_v = 1'b1; end
    end
  end
  assign sel = lock_q ? sel_q : pick;
  wire   have = lock_q | pick_v;
  assign t_rsp_valid = have & c_rsp_valid[sel];

  wire [IDC-1:0]     rid   = c_rsp_id[sel*IDC +: IDC];
  wire [LINE_W-1:0]  rline = c_rsp_rdata[sel*LINE_W +: LINE_W];
  wire [2:0]         rst   = c_rsp_status[sel*3 +: 3];
  wire               r_bad = rid[IDC-1];
  wire [2:0]         r_op  = rid[IDC-2 -: 3];
  wire [LANEW-1:0]   r_ln  = rid[LANEW-1:0];
  wire               r_err = r_bad | (rst != `SF_ST_OK);
  logic [DW-1:0]     rword;
  always_comb begin
    rword = '0;
    if (DW == LINE_W) rword = DW'(rline);
    else for (int l = 0; l < LINE_W / DW; l++) if (r_ln == LANEW'(l)) rword = rline[l*DW +: DW];
  end
  assign t_rsp_src    = rid[IDC-5 -: SRCW] ;
  assign t_rsp_id     = rid[LANEW +: IDW];
  assign t_rsp_opcode = r_op;
  assign t_rsp_status = r_err ? 2'd1 : 2'd0;                 // ST_SLVERR / ST_OKAY
  assign t_rsp_rdata  = (r_err || c_rsp_we[sel] || r_op != OP_READ) ? '0 : rword;
  always_comb begin
    for (int p = 0; p < NP; p++) c_rsp_ready[p] = t_rsp_ready & have & (sel == NPW'(p));
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin lock_q <= 1'b0; sel_q <= '0; rr_ptr <= '0; end
    else begin
      if (t_rsp_valid && !t_rsp_ready) begin lock_q <= 1'b1; sel_q <= sel; end
      else if (t_rsp_valid && t_rsp_ready) begin
        lock_q <= 1'b0;
        rr_ptr <= (sel == NPW'(NP - 1)) ? '0 : sel + 1'b1;
      end
    end
  end

  // ------------------------------------------------------------ error reporting
  wire resp_fire = t_rsp_valid & t_rsp_ready;
  wire [2:0] ecode = r_bad ? `SF_ST_BADOP : rst;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_sticky_o <= 1'b0; err_cnt_o <= '0; err_code_o <= '0; err_src_o <= '0; err_id_o <= '0; err_opcode_o <= '0;
    end else if (err_clr_i) begin
      err_sticky_o <= 1'b0; err_cnt_o <= '0;
    end else if (resp_fire && r_err) begin
      if (err_cnt_o != {CNT_W{1'b1}}) err_cnt_o <= err_cnt_o + 1'b1;
      if (!err_sticky_o) begin
        err_sticky_o <= 1'b1; err_code_o <= ecode; err_src_o <= t_rsp_src; err_id_o <= t_rsp_id; err_opcode_o <= r_op;
      end
    end
  end
endmodule

`default_nettype wire
