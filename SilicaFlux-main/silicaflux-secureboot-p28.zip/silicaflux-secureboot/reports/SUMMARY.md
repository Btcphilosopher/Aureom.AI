# Project 28 -- results summary

Every line is copied from the report next to it (`make summary`). Simulation only: no FPGA board, no silicon. Not a security certification (docs/12_SECURITY_REVIEW.md).

| Gate | Result | Report |
|---|---|---|
| Software reference (step 1): Ed25519 djb/RFC 8032 vectors on the ROM verifier, Monocypher and OpenSSL | 9214 / 9214 PASS | [ref.md](ref.md) |
| Software reference: Wycheproof Ed25519 (ROM verifier vs expected) | 181 / 181 PASS | [ref.md](ref.md) |
| Software reference: security corpus, spec == Python reference == native ROM policy | 53 / 53 PASS | [ref.md](ref.md) |
| Software reference: differential fuzzing of the manifest policy (Python == C) | 20000 / 20000 PASS | [ref.md](ref.md) |
| Unit tests of the new RTL (SHA-256 vs NIST CAVP incl. Monte, KAT fault, DMA guard 200 k random, secure-boot block) | 5 / 5 runs PASS | [unit_sb.md](unit_sb.md) |
| cocotb unit tests of the reused P21 blocks | 17 / 17 PASS | [unit.md](unit.md) |
| **Security regression on the RTL** (15 scenarios: all brief §10 cases) | 15 / 15 scenarios PASS, 318 / 318 checks PASS | [security_regression.md](security_regression.md) |
| Authentication time, 34 KB image (IMAGE_READY -> hand-off) | 6,418,557 cycles | [security_regression.md](security_regression.md) |
| Functional regression with the real accelerators (signed firmware) | 6 / 6 PASS; 740 firmware checks, 0 fails | [regression.md](regression.md) |
| Lint (Verilator -Wall new RTL = 0 warnings; Icarus elaboration; firmware -Wall -Wextra) | 4 / 4 PASS | [lint.md](lint.md) |
| riscv-tests on mcu_cpu RV32M = 2 (3 bus profiles x 2 seeds) | pass=63 fail=0 | [isa/riscv_tests_m2.txt](isa/riscv_tests_m2.txt) |
| Yosys estimate: silicaflux_secure_boot (incl. SHA-256) | 12566 LUT4 | [synth.md](synth.md) |
| Vendored sources unmodified (SHA256SUMS) | check_vendor: 204 files, 0 problems | [../third_party/PROVENANCE.md](../third_party/PROVENANCE.md) |
