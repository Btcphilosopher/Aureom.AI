# Synthesis estimate of the Project 28 blocks

Yosys 0.33 (git sha1 2584903a060), `synth_ecp5` per block (generic Lattice ECP5 mapping, as the P21 FPGA flow). **Estimate only**: no constraints, no place-and-route, no timing. Logs: `build/synth/*.log`.

| Block | Contents | Synthesis | LUT4 | FF | CCU2C (carry) | RAM primitives | MULT18 |
|---|---|---|---|---|---|---|---|
| `sha256_core` | secworks SHA-256 compression core (vendored) | ok | 4735 | 1034 | 198 | 0 | 0 |
| `sb_sha256_wrapper` | verified SHA-256 wrapper: padding + KAT + core | ok | 5965 | 1859 | 219 | 0 | 0 |
| `silicaflux_secure_boot` | secure-boot block incl. SHA-256 wrapper, hash reader, registers | ok | 12566 | 2781 | 486 | 0 | 0 |
| `sb_dma_guard` | DMA guard, 4 windows | ok | 2157 | 532 | 773 | 0 | 0 |
| `sb_access_policy` | host / fetch / IMEM / debug policy (combinational) | ok | 129 | 0 | 64 | 0 | 0 |
| `sb_otp_model` | fuse MODEL (registers, not OTP) | ok | 274 | 133 | 0 | 0 | 0 |

Not included: the 32 KiB boot ROM (generated combinational image; an FPGA flow should infer block RAM, an ASIC flow uses a ROM macro), the four added `cc_sfb_gate` instances (P21 block, small) and the single-cycle 33x33 multiplier of `mcu_cpu` RV32M = 2 (MCU-I, DSP blocks on ECP5).
