# System regression (ControlCore v2 + vector tile + tensor unit, signed firmware on the RTL CPU)

Generated 2026-11-10 18:44 UTC by `scripts/regress.py`. Simulator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1). Firmware: riscv64-unknown-elf-gcc (13.2.0-11ubuntu1+12) 13.2.0; signed image 34472 B, key slot 0x00000001, security version 0x00000001, SHA-256 eea2dd7407c2644f... (Project 28 secure boot).

**6 / 6 runs PASS.**

| Scenario | Back-pressure | Seed | Result | RTL cycles | Firmware checks (fails) | Testbench checks ok / fail | Wall time | Log |
|---|---|---|---|---|---|---|---|---|
| boot_host | 0 % | 1 | **PASS** | 8030478 | 269 (0) | 37 / 0 | 97.2 s | `reports/sim/boot_host_bp0_s1.log` |
| boot_host | 40 % | 7 | **PASS** | 8037512 | 269 (0) | 37 / 0 | 97.8 s | `reports/sim/boot_host_bp40_s7.log` |
| boot_ext | 0 % | 1 | **PASS** | 7702729 | 82 (0) | 8 / 0 | 94.1 s | `reports/sim/boot_ext_bp0_s1.log` |
| boot_ext | 25 % | 3 | **PASS** | 7707674 | 82 (0) | 8 / 0 | 93.2 s | `reports/sim/boot_ext_bp25_s3.log` |
| bad_image | 0 % | 1 | **PASS** | 20186696 | 0 (0) | 10 / 0 | 246.9 s | `reports/sim/bad_image_bp0_s1.log` |
| wdt_reset | 0 % | 1 | **PASS** | 13957773 | 38 (0) | 7 / 0 | 171.2 s | `reports/sim/wdt_reset_bp0_s1.log` |

Scenario descriptions:

* **boot_host** (bp 0 %): host loads the signed firmware (authenticated); full self-test suite incl. T16 secure boot; host GEMM/vector/DMA commands; RAS; telemetry
* **boot_host** (bp 40 %): same, 40 % random back-pressure on device memory
* **boot_ext** (bp 0 %): ROM DMA-copies the signed image from device memory, authenticates it; self-test subset; host GEMM
* **boot_ext** (bp 25 %): same, 25 % back-pressure
* **bad_image** (bp 0 %): modified payload rejected (DIGEST), correct image accepted, host reset -> cold boot + re-authentication
* **wdt_reset** (bp 0 %): watchdog early warning, timeout reset, warm boot (re-authenticated) without the host
