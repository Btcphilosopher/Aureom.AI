# Address-map validator: negative tests

`scripts/test_memmap.py` mutates `config/cc_memmap.yaml` and checks that `scripts/gen_memmap.py` rejects every illegal map.

**18 / 18 PASS**

| Case | Validator message | Result |
|---|---|---|
| unmodified map passes | - | PASS |
| region overlap (DMEM moved onto IMEM) | regions IMEM and DMEM overlap | PASS (rejected) |
| region base not aligned to its size | region IMEM: base 0x00012000 not aligned to size 0x10000 | PASS (rejected) |
| region size not a power of two | region DMEM: size 0x6000 is not a power of two | PASS (rejected) |
| region beyond 4 GiB | region EXT: exceeds the 32-bit space | PASS (rejected) |
| duplicate crossbar slave index | region slave indices must be 0..4 exactly once: [0, 1, 2, 0, 3] | PASS (rejected) |
| EXT sub-region outside EXT | ext sub-region DEVMEM not inside EXT | PASS (rejected) |
| PERIPH not 32 pages | PERIPH must be exactly 32 pages (sfv_periph_bridge decodes addr[16:12]) | PASS (rejected) |
| page defined twice | page 0 defined twice | PASS (rejected) |
| forwarded page outside 8..15 | page SYSCTRL: only pages 8..15 can be forwarded to the accelerator port | PASS (rejected) |
| register offset misaligned | cc_ras.WARN_EN: offset 0x6 misaligned or outside the page | PASS (rejected) |
| register offset outside the page | cc_ras.WARN_EN: offset 0x1000 misaligned or outside the page | PASS (rejected) |
| duplicate register offset | cc_ras.FATAL_EN: duplicate offset 0x4 | PASS (rejected) |
| duplicate IRQ id | irq ids must be unique and < 16 | PASS (rejected) |
| IRQ id >= 16 | irq ids must be unique and < 16 | PASS (rejected) |
| access matrix names an unknown region | access: DMA -> unknown region NOWHERE | PASS (rejected) |
| reused block offset differs from MCU-I package | mcu_wdt.CTRL: 0x20 != mcu_memmap_pkg WDT_CTRL 0x0 | PASS (rejected) |
| duplicate enumeration value | enum BOOT_STAGE: duplicate values | PASS (rejected) |
