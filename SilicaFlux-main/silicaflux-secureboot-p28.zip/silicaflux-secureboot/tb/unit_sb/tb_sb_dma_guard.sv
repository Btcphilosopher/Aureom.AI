// =============================================================================
// Unit test: sb_dma_guard -- descriptor validation and per-beat firewall vs an
// independent reference model (64-bit arithmetic, written separately from the
// RTL's 33-bit logic).
//
//   * directed: zero length, fixed sides, byte mode, wrap at 2^32, window edges,
//     protected regions (BOOTROM, PERIPH, IMEM write outside LOAD), lock,
//     write-while-busy refusal;
//   * random: N descriptors (default 200 000) with random windows, biased towards
//     the 2^32 boundary, window edges and protected regions; the guard's START
//     decision, its DENY_REASON and the per-beat decision must equal the model.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sb_dma_guard;
  import cc_memmap_pkg::*;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic        rb_sel = 0, rb_we = 0, dma_sel = 0, dma_busy = 0, load_open = 0, beat_write = 0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, beat_addr = '0;
  logic [31:0] rb_rdata, viol_addr;
  logic        rb_err, dma_sel_o, dma_err_o, beat_ok, viol_evt;
  sb_dma_guard #(.NW(4)) dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .dma_rb_sel_i(dma_sel), .dma_rb_sel_o(dma_sel_o), .dma_rb_err_i(1'b0), .dma_rb_err_o(dma_err_o),
    .dma_busy, .imem_load_open(load_open),
    .beat_addr, .beat_write, .beat_ok, .beat_refused(1'b0), .viol_evt, .viol_addr
  );

  int fails = 0, checks = 0;
  int hist [8];                   // outcome distribution of the random descriptors (coverage)
  int beat_hist [2];
  task automatic chk(input string what, input logic [31:0] got, input logic [31:0] exp);
    checks++;
    if (got !== exp) begin fails++; if (fails < 30) $display("FAIL %s got=%08h exp=%08h", what, got, exp); end
  endtask

  // ---- register access helpers (one rb cycle)
  task automatic grd_wr(input logic [11:0] a, input logic [31:0] d, output bit err);
    @(negedge clk); rb_sel = 1; rb_we = 1; rb_addr = a; rb_wdata = d; #1 err = rb_err;
    @(negedge clk); rb_sel = 0; rb_we = 0;
  endtask
  task automatic dma_wr(input logic [11:0] a, input logic [31:0] d, output bit sel_through, output bit err);
    @(negedge clk); dma_sel = 1; rb_we = 1; rb_addr = a; rb_wdata = d; #1 sel_through = dma_sel_o; err = dma_err_o;
    @(negedge clk); dma_sel = 0; rb_we = 0;
  endtask

  // ---- reference model
  logic [31:0] mb [4], ml [4]; logic [2:0] ma [4];
  function automatic bit m_overlap(longint lo, longint hi, longint base, longint size);
    return lo < base + size && base < hi;
  endfunction
  function automatic bit m_prot(longint lo, longint hi, bit wr);
    return m_overlap(lo, hi, CC_BOOTROM_BASE, CC_BOOTROM_SIZE) || m_overlap(lo, hi, CC_PERIPH_BASE, CC_PERIPH_SIZE) ||
           (wr && !load_open && m_overlap(lo, hi, CC_IMEM_BASE, CC_IMEM_SIZE));
  endfunction
  function automatic bit m_win(longint lo, longint hi, bit wr);
    for (int i = 0; i < 4; i++)
      if (ma[i][0] && (wr ? ma[i][2] : ma[i][1]) && lo >= longint'(mb[i]) && hi - 1 <= longint'(ml[i])) return 1;
    return 0;
  endfunction
  function automatic logic [3:0] m_reason(logic [31:0] src, logic [31:0] dst, logic [31:0] len, bit sfix, bit dfix);
    longint slo = longint'(src) & ~longint'(3), dlo = longint'(dst) & ~longint'(3);
    longint shi = sfix ? slo + 4 : ((longint'(src) + longint'(len) + 3) & ~longint'(3));
    longint dhi = dfix ? dlo + 4 : ((longint'(dst) + longint'(len) + 3) & ~longint'(3));
    if (len == 0) return 4'(CC_DG_REASON_NONE);
    if (shi > 64'h1_0000_0000) return 4'(CC_DG_REASON_SRC_OVF);
    if (dhi > 64'h1_0000_0000) return 4'(CC_DG_REASON_DST_OVF);
    if (m_prot(slo, shi, 0) || m_prot(dlo, dhi, 1)) return 4'(CC_DG_REASON_PROTECTED);
    if (!m_win(slo, shi, 0)) return 4'(CC_DG_REASON_SRC_WINDOW);
    if (!m_win(dlo, dhi, 1)) return 4'(CC_DG_REASON_DST_WINDOW);
    return 4'(CC_DG_REASON_NONE);
  endfunction

  task automatic set_window(input int i, input logic [31:0] b, input logic [31:0] l, input logic [2:0] at);
    bit e;
    grd_wr(CC_DG_WIN0_BASE + 12'(16 * i), b, e); grd_wr(CC_DG_WIN0_LAST + 12'(16 * i), l, e);
    grd_wr(CC_DG_WIN0_ATTR + 12'(16 * i), {29'd0, at}, e);
    mb[i] = b; ml[i] = l; ma[i] = at;
  endtask

  // program a descriptor, attempt START, compare with the model
  task automatic try(input string what, input logic [31:0] src, input logic [31:0] dst, input logic [31:0] len,
                     input bit sfix, input bit dfix);
    bit thr, e; logic [3:0] exp;
    dma_wr(CC_DMA_SRC_ADDR, src, thr, e); dma_wr(CC_DMA_DST_ADDR, dst, thr, e); dma_wr(CC_DMA_LENGTH, len, thr, e);
    dma_wr(CC_DMA_MODE, {30'd0, dfix, sfix}, thr, e);
    dma_wr(CC_DMA_CONTROL, 32'h1, thr, e);
    exp = m_reason(src, dst, len, sfix, dfix);
    chk({what, " START passes"}, 32'(thr), 32'(exp == 0));
    chk({what, " START error"}, 32'(e), 32'(exp != 0));
    if (exp != 0) begin
      bit e2;
      @(negedge clk); rb_sel = 1; rb_we = 0; rb_addr = CC_DG_DENY_REASON; #1;
      chk({what, " DENY_REASON"}, rb_rdata, 32'(exp));
      @(negedge clk); rb_sel = 0;
      e2 = 0;
    end
  endtask

  initial begin
    int n; bit e, thr;
    if (!$value$plusargs("n=%d", n)) n = 200000;
    repeat (3) @(posedge clk); rst_n = 1;
    // ---- reset: default deny
    try("reset: everything denied", CC_DEVMEM_BASE, CC_DEVMEM_BASE + 32'h1000, 64, 0, 0);
    // ---- directed
    set_window(0, CC_DEVMEM_BASE, CC_DEVMEM_BASE + 32'hEFFFF, 3'b111);
    set_window(1, CC_IMAGE_STORE_BASE, CC_IMAGE_STORE_BASE + 32'hFFFF, 3'b011);
    set_window(2, CC_DMEM_BASE + 32'h1000, CC_DMEM_BASE + 32'h13FF, 3'b111);
    set_window(3, 32'hFFFF_F000, 32'hFFFF_FFFF, 3'b111);
    try("legal devmem copy", CC_DEVMEM_BASE, CC_DEVMEM_BASE + 32'h1000, 1024, 0, 0);
    try("zero length (DMA rejects it itself)", 32'h0, 32'h0, 0, 0, 0);
    try("dst runs into the read-only store", CC_DEVMEM_BASE, CC_IMAGE_STORE_BASE - 32'h100, 32'h200, 0, 0);
    try("store readable", CC_IMAGE_STORE_BASE, CC_DEVMEM_BASE, 32'h100, 0, 0);
    try("src wraps 2^32", 32'hFFFF_FF00, CC_DEVMEM_BASE, 32'h200, 0, 0);
    try("dst wraps 2^32", CC_DEVMEM_BASE, 32'hFFFF_FFF0, 32'h20, 0, 0);
    try("window ending at 2^32, exact fit", 32'hFFFF_F000, CC_DEVMEM_BASE, 32'h1000, 0, 0);
    try("huge length wraps", CC_DEVMEM_BASE, CC_DEVMEM_BASE + 32'h100, 32'hFFFF_FFFC, 0, 0);
    try("into IMEM outside LOAD", CC_DEVMEM_BASE, CC_IMEM_BASE + 32'h100, 64, 0, 0);
    try("from BOOTROM", CC_BOOTROM_BASE, CC_DEVMEM_BASE, 64, 0, 0);
    try("to PERIPH (fixed side)", CC_DEVMEM_BASE, CC_SECURITY_BASE, 64, 0, 1);
    try("DMEM buffer exact", CC_DMEM_BASE + 32'h1000, CC_DEVMEM_BASE, 32'h400, 0, 0);
    try("DMEM buffer +4 too long", CC_DMEM_BASE + 32'h1000, CC_DEVMEM_BASE, 32'h404, 0, 0);
    try("byte mode, unaligned end", CC_DEVMEM_BASE + 32'h3, CC_DEVMEM_BASE + 32'h1001, 5, 0, 0);
    load_open = 1;
    try("into IMEM in LOAD (window needed)", CC_DEVMEM_BASE, CC_IMEM_BASE + 32'h100, 64, 0, 0);
    set_window(3, CC_IMEM_BASE, CC_IMEM_BASE + 32'hFFFF, 3'b101);
    try("into IMEM in LOAD with a window", CC_DEVMEM_BASE, CC_IMEM_BASE + 32'h100, 64, 0, 0);
    load_open = 0;
    try("same after the seal", CC_DEVMEM_BASE, CC_IMEM_BASE + 32'h100, 64, 0, 0);
    // window registers: refused while the DMA is busy, then after LOCK
    dma_busy = 1; grd_wr(CC_DG_WIN0_BASE, 32'h0, e); chk("window write while DMA busy refused", 32'(e), 1); dma_busy = 0;
    // ---- random
    for (int k = 0; k < n; k++) begin
      logic [31:0] src, dst, len; bit sf, df;
      if (k % 2000 == 0) for (int i = 0; i < 4; i++) begin
        logic [31:0] b = $urandom, l;
        case ($urandom % 4)
          0: b = CC_DEVMEM_BASE + ($urandom % 32'h10_0000);
          1: b = 32'hFFFF_0000 + ($urandom % 32'h1_0000);
          2: b = CC_DMEM_BASE + ($urandom % 32'h8000);
          default: ;
        endcase
        l = b + ($urandom % 32'h2_0000);
        if (l < b) l = 32'hFFFF_FFFF;
        set_window(i, b, l, 3'($urandom));
        load_open = $urandom % 2;
      end
      src = $urandom; dst = $urandom;
      case ($urandom % 6)
        0: src = mb[$urandom % 4] + ($urandom % 64) * 4;
        1: src = 32'hFFFF_FFFF - ($urandom % 512);
        2: src = CC_IMEM_BASE + ($urandom % 32'h1_0000);
        default: ;
      endcase
      case ($urandom % 6)
        0: dst = mb[$urandom % 4] + ($urandom % 64) * 4;
        1: dst = 32'hFFFF_FFFF - ($urandom % 512);
        2: dst = ml[$urandom % 4] - ($urandom % 64);
        3: dst = CC_IMEM_BASE + ($urandom % 32'h1_0000);
        default: ;
      endcase
      len = ($urandom % 4 == 0) ? $urandom : ($urandom % 4096);
      sf = ($urandom % 8 == 0); df = ($urandom % 8 == 0);
      try("random", src, dst, len, sf, df);
      hist[m_reason(src, dst, len, sf, df)]++;
      // per-beat firewall on a random word
      beat_addr = ($urandom % 2) ? src + ($urandom % 256) : $urandom; beat_write = $urandom % 2; #1;
      begin
        longint a = longint'(beat_addr) & ~longint'(3);
        chk("random beat", 32'(beat_ok), 32'(!m_prot(a, a + 4, beat_write) && m_win(a, a + 4, beat_write)));
        beat_hist[beat_ok]++;
      end
    end
    $display("random START outcomes: allowed %0d, SRC_WINDOW %0d, DST_WINDOW %0d, SRC_OVF %0d, DST_OVF %0d, PROTECTED %0d",
             hist[0], hist[1], hist[2], hist[3], hist[4], hist[5]);
    $display("random beats: refused %0d, allowed %0d", beat_hist[0], beat_hist[1]);
    for (int r = 0; r < 6; r++) chk($sformatf("coverage: outcome %0d occurred", r), 32'(hist[r] > 100), 1);
    chk("coverage: beats allowed and refused", 32'(beat_hist[0] > 100 && beat_hist[1] > 100), 1);
    // ---- lock
    grd_wr(CC_DG_CTRL, 32'h1, e);
    grd_wr(CC_DG_WIN0_ATTR, 32'h7, e); chk("window write after LOCK refused", 32'(e), 1);
    grd_wr(CC_DG_CTRL, 32'h0, e);
    @(negedge clk); rb_sel = 1; rb_we = 0; rb_addr = CC_DG_STATUS; #1 chk("LOCK is set-only", rb_rdata[0], 1);
    @(negedge clk); rb_sel = 0;
    $display("TB RESULT %s checks=%0d fails=%0d (random descriptors: %0d)", fails == 0 ? "PASS" : "FAIL", checks, fails, n);
    if (fails != 0) $fatal(1, "failed");
    $finish(0);
  end
endmodule

`default_nettype wire
