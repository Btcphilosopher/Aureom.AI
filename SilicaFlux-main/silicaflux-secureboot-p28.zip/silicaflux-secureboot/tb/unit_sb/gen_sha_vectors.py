#!/usr/bin/env python3
"""Convert NIST CAVP SHA-256 .rsp files (vectors/nist_cavp_sha256) into the plain
format read by tb_sb_sha256.sv.  Expected digests are copied from the NIST
files, not recomputed.
  msg file : one line per message: <nbytes> <hex message or '-'> <hex MD>
  monte    : line 1 = seed, then the 100 NIST checkpoints MD[0..99]"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
V = os.path.join(ROOT, "vectors", "nist_cavp_sha256")
out = sys.argv[1]
os.makedirs(out, exist_ok=True)
n = 0
with open(os.path.join(out, "sha256_msgs.txt"), "w") as f:
    for fn in ("SHA256ShortMsg.rsp", "SHA256LongMsg.rsp"):
        ln = msg = None
        for line in open(os.path.join(V, fn)):
            line = line.strip()
            if line.startswith("Len ="):
                ln = int(line.split("=")[1])
            elif line.startswith("Msg ="):
                msg = line.split("=")[1].strip()[: 2 * (ln // 8)]
            elif line.startswith("MD =") and ln is not None:
                f.write(f"{ln // 8} {msg if msg else '-'} {line.split('=')[1].strip()}\n")
                n += 1
                ln = msg = None
seed, cps = None, []
for line in open(os.path.join(V, "SHA256Monte.rsp")):
    line = line.strip()
    if line.startswith("Seed ="):
        seed = line.split("=")[1].strip()
    elif line.startswith("MD ="):
        cps.append(line.split("=")[1].strip())
with open(os.path.join(out, "sha256_monte.txt"), "w") as f:
    f.write(seed + "\n" + "\n".join(cps) + "\n")
print(f"gen_sha_vectors: {n} messages, Monte seed + {len(cps)} checkpoints -> {out}")
