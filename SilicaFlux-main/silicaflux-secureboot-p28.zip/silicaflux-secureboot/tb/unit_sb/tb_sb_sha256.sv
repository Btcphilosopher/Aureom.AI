// =============================================================================
// Unit test: sb_sha256_wrapper (verified SHA-256 core wrapper) vs NIST CAVP
//
//   +msgs=<sha256_msgs.txt>   all SHA256ShortMsg + SHA256LongMsg messages
//   +monte=<sha256_monte.txt> full SHA256Monte (100 checkpoints x 1000 hashes)
//   +katfault                 force a datapath fault during the power-on KAT:
//                             kat_ok must be 0 and the client port held off
//   +bp=<0..90>               random gaps between input words (stall robustness)
// Expected digests come from the NIST files (tb/unit_sb/gen_sha_vectors.py).
// Result line: "TB RESULT PASS|FAIL ..." and exit status.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sb_sha256;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  logic        start = 1'b0, in_valid = 1'b0, finish = 1'b0;
  logic [31:0] in_data = '0;
  logic [2:0]  in_nbytes = 3'd4;
  logic        in_ready, busy, done, kat_done, kat_ok;
  logic [255:0] digest;
  sb_sha256_wrapper dut (.clk, .rst_n, .start, .in_valid, .in_ready, .in_data, .in_nbytes, .finish, .busy, .done,
                         .digest, .kat_done, .kat_ok);

  int fails = 0, checks = 0, bp = 0;
  longint hash_cycles = 0, hashes = 0;

  // hash one message given as a byte queue; returns the digest
  task automatic sha(input byte unsigned m[$], output logic [255:0] md);
    int nb = m.size();
    longint t0 = cyc;
    @(negedge clk); start = 1'b1; @(negedge clk); start = 1'b0;
    for (int i = 0; i < nb; i += 4) begin
      logic [31:0] w;
      int k;
      w = '0;
      k = (nb - i >= 4) ? 4 : nb - i;
      for (int b = 0; b < k; b++) w[31 - 8 * b -: 8] = m[i + b];
      while (bp > 0 && ($urandom % 100) < bp) @(negedge clk);
      in_data = w; in_nbytes = 3'(k); in_valid = 1'b1;
      do @(posedge clk); while (!in_ready);
      @(negedge clk); in_valid = 1'b0;
    end
    finish = 1'b1; @(negedge clk); finish = 1'b0;
    while (!done) @(posedge clk);
    md = digest;
    hash_cycles += cyc - t0; hashes++;
  endtask

  function automatic logic [255:0] hex256(input string s);
    logic [255:0] v = '0;
    for (int i = 0; i < 64; i++) v = {v[251:0], 4'(s.substr(i, i).atohex())};
    return v;
  endfunction

  task automatic run_msgs(input string path);
    int fd = $fopen(path, "r"), nbytes, n = 0;
    string hm, hd;
    if (fd == 0) $fatal(1, "cannot open %s", path);
    while ($fscanf(fd, "%d %s %s\n", nbytes, hm, hd) == 3) begin
      byte unsigned m[$];
      logic [255:0] md;
      m.delete();                     // block-local queues are not re-created per iteration in Verilator
      for (int i = 0; i < nbytes; i++) m.push_back(8'(hm.substr(2 * i, 2 * i + 1).atohex()));
      sha(m, md);
      checks++; n++;
      if (md !== hex256(hd)) begin
        fails++;
        $display("FAIL CAVP len=%0d bytes: got %h exp %s", nbytes, md, hd);
      end
    end
    $fclose(fd);
    $display("CAVP Short+Long: %0d messages, %0d fails", n, fails);
  endtask

  task automatic run_monte(input string path);
    int fd = $fopen(path, "r"), f0 = fails;
    string s;
    logic [255:0] seed, md[3], cp;
    if (fd == 0) $fatal(1, "cannot open %s", path);
    void'($fscanf(fd, "%s\n", s)); seed = hex256(s);
    for (int j = 0; j < 100; j++) begin
      md[0] = seed; md[1] = seed; md[2] = seed;
      for (int i = 3; i < 1003; i++) begin
        byte unsigned m[$];
        logic [255:0] r;
        m.delete();
        for (int k = 0; k < 3; k++) for (int b = 0; b < 32; b++) m.push_back(md[k][255 - 8 * b -: 8]);
        sha(m, r);
        md[0] = md[1]; md[1] = md[2]; md[2] = r;
      end
      seed = md[2];
      void'($fscanf(fd, "%s\n", s)); cp = hex256(s);
      checks++;
      if (seed !== cp) begin fails++; $display("FAIL Monte checkpoint %0d: got %h exp %h", j, seed, cp); end
    end
    $fclose(fd);
    $display("CAVP Monte: 100 checkpoints (100 000 hashes), %0d fails", fails - f0);
  endtask

  initial begin
    string msgs, monte;
    if (!$value$plusargs("bp=%d", bp)) bp = 0;
    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    if ($test$plusargs("katfault")) begin
      // stuck-at fault on one bit of the compression core's message schedule input
      force dut.u_eng.c_block[0] = 1'b1;
      wait (kat_done);
      release dut.u_eng.c_block[0];
      checks += 3;
      if (kat_ok !== 1'b0) begin fails++; $display("FAIL: KAT passed despite the injected fault"); end
      repeat (5) @(posedge clk);
      start = 1'b1; in_valid = 1'b1; @(posedge clk);
      if (in_ready !== 1'b0) begin fails++; $display("FAIL: client accepted after a failed KAT"); end
      start = 1'b0; in_valid = 1'b0;
      repeat (300) @(posedge clk);
      if (done !== 1'b0 || busy !== 1'b0) begin fails++; $display("FAIL: engine ran after a failed KAT"); end
      $display("KAT fault injection: kat_done=%0d kat_ok=%0d (expected 1 0), client held off", kat_done, kat_ok);
    end else begin
      wait (kat_done);
      checks++;
      $display("power-on KAT done at cycle %0d: kat_ok=%0d", cyc, kat_ok);
      if (kat_ok !== 1'b1) begin fails++; $display("FAIL: KAT"); end
      if ($value$plusargs("msgs=%s", msgs)) run_msgs(msgs);
      if ($value$plusargs("monte=%s", monte)) run_monte(monte);
      if (hashes != 0) $display("throughput: %0d hashes, %0.1f cycles/hash average", hashes, real'(hash_cycles) / hashes);
    end
    $display("TB RESULT %s checks=%0d fails=%0d cycles=%0d", (fails != 0) ? "FAIL" : "PASS", checks, fails, cyc);
    if (fails != 0) $fatal(1, "failed");
    $finish(0);
  end
endmodule

`default_nettype wire
