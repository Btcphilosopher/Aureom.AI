// =============================================================================
// Unit test: silicaflux_secure_boot + sb_otp_model, driven register by register
// (no CPU, no ROM): the hardware rules on their own.
//
//   +img=<signed image .hex>  loaded into the IMEM model behind the hash reader
// Covers: KAT -> LOAD, register privilege per phase, SEAL quiescence (DMA busy),
// hash-parameter refusal, measured digest == manifest digest (hashlib),
// every hand-off refusal incl. KEY_LC in PROD (not reachable through the ROM),
// PASS outputs, fuse-model rules, hash bus error, illegal-state injection while
// running (fault model: state register upset -> LOCKDOWN, execution closes),
// failure counter and automatic RECOVERY.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sb_core;
  import cc_memmap_pkg::*;
  logic clk = 1'b0, por_n = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic        rb_sel = 0, rb_we = 0, dma_busy = 0, strap = 0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic        rb_err;
  logic [31:0] f_lc = CC_SB_LC_CODE_PROD, f_rev = 0, f_svn = 0, f_cfg = 0;
  logic [31:0] otp_lc, otp_rev, otp_svn, otp_cfg, prog_bits;
  logic [1:0]  prog_sel;
  logic [3:0]  fails;
  logic        loaded, prog_en, finc, fclr;
  logic        h_req_valid, h_rsp_valid = 0, h_rsp_ready, h_rsp_error = 0, mem_err = 0;
  logic [31:0] h_req_addr, h_rsp_rdata = '0;
  logic        load_open, exec_open, rom_fetch_open, debug_en, test_en, lockdown;
  logic [31:0] exec_base, exec_end;

  sb_otp_model u_otp (.clk, .por_rst_n(por_n), .fuse_lc_i(f_lc), .fuse_revoke_i(f_rev), .fuse_svn_i(f_svn),
    .fuse_cfg_i(f_cfg), .loaded, .lc(otp_lc), .revoke(otp_rev), .svn(otp_svn), .cfg(otp_cfg),
    .prog_en, .prog_sel, .prog_bits, .fail_inc(finc), .fail_clr(fclr), .fails);
  silicaflux_secure_boot dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .otp_lc, .otp_revoke(otp_rev), .otp_svn, .otp_cfg, .boot_fails(fails), .otp_prog_en(prog_en),
    .otp_prog_sel(prog_sel), .otp_prog_bits(prog_bits), .fail_inc(finc), .fail_clr(fclr), .recovery_strap(strap),
    .h_req_valid, .h_req_ready(1'b1), .h_req_addr, .h_rsp_valid, .h_rsp_ready, .h_rsp_rdata, .h_rsp_error,
    .imem_idle(1'b1), .dma_busy, .fetch_acc(1'b0), .fetch_addr(32'd0), .viol_evt(5'd0), .viol_addr(160'd0),
    .dbg_used(1'b0),
    .load_open, .exec_open, .rom_fetch_open, .exec_base, .exec_end, .debug_en, .test_mode_en(test_en), .lockdown
  );

  // IMEM model (64 KiB) answering the hash reader one cycle after the request
  logic [31:0] imem [16384];
  logic [31:0] q [$];
  always @(posedge clk) begin
    h_rsp_valid <= 1'b0;
    if (h_req_valid && !h_rsp_valid) begin
      h_rsp_valid <= 1'b1;
      h_rsp_rdata <= imem[(h_req_addr - CC_IMEM_BASE) >> 2];
      h_rsp_error <= mem_err;
    end
  end

  int fails_n = 0, checks = 0;
  task automatic chk(input string what, input logic [31:0] got, input logic [31:0] exp);
    checks++;
    if (got !== exp) begin fails_n++; $display("FAIL %s got=%08h exp=%08h", what, got, exp); end
    else $display("ok   %s", what);
  endtask
  task automatic wr(input logic [11:0] a, input logic [31:0] d, output bit err);
    @(negedge clk); rb_sel = 1; rb_we = 1; rb_addr = a; rb_wdata = d; #1 err = rb_err;
    @(negedge clk); rb_sel = 0; rb_we = 0;
  endtask
  task automatic rd(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk); rb_sel = 1; rb_we = 0; rb_addr = a; #1 d = rb_rdata;
    @(negedge clk); rb_sel = 0;
  endtask
  task automatic cmd(input logic [7:0] c, output bit err);
    wr(CC_SEC_CMD, CC_SB_CMD_KEY | 32'(c), err);
  endtask
  function automatic logic [3:0] state();
    return dut.st_enum;
  endfunction
  task automatic reset_sys();
    rst_n = 0; repeat (3) @(posedge clk); rst_n = 1;
    wait (dut.kat_done); repeat (3) @(posedge clk);
  endtask
  task automatic seal_hash(input logic [31:0] base, input logic [31:0] len);
    bit e;
    cmd(CC_SB_CMD_SEAL, e); repeat (3) @(posedge clk);
    wr(CC_SEC_HASH_BASE, base, e); wr(CC_SEC_HASH_LEN, len, e);
    cmd(CC_SB_CMD_HASH, e);
    while (state() == 4'(CC_SB_STATE_HASHING)) @(posedge clk);
  endtask
  // EXPECT from the manifest, tokens, entry, slot, svn, then HANDOFF; returns the refusal reason
  logic [31:0] len, ent, dg [8];
  task automatic handoff(input logic [1:0] slot, input logic [31:0] svn, input bit good_expect, output logic [7:0] href);
    bit e; logic [31:0] st;
    for (int i = 0; i < 8; i++) wr(CC_SEC_EXPECT0 + 12'(4 * i), good_expect ? dg[i] : ~dg[i], e);
    wr(CC_SEC_SIG_TOKEN, CC_SB_TOKEN_A, e); wr(CC_SEC_SIG_TOKEN, CC_SB_TOKEN_B, e);
    wr(CC_SEC_ENTRY, ent, e); wr(CC_SEC_KEY_SLOT, 32'(slot), e); wr(CC_SEC_IMAGE_SVN, svn, e);
    cmd(CC_SB_CMD_HANDOFF, e);
    rd(CC_SEC_STATUS, st); href = st[31:24];
  endtask

  initial begin
    string path; bit e; logic [31:0] v; logic [7:0] href;
    if (!$value$plusargs("img=%s", path)) path = "firmware/build/fw/controlcore_fw.hex";
    begin int fd = $fopen(path, "r"); logic [31:0] w; while ($fscanf(fd, "%h\n", w) == 1) q.push_back(w); $fclose(fd); end
    foreach (imem[i]) imem[i] = (i < q.size()) ? q[i] : 32'h0;
    len = q[13]; ent = q[14];
    for (int i = 0; i < 8; i++) dg[i] = {q[16 + i][7:0], q[16 + i][15:8], q[16 + i][23:16], q[16 + i][31:24]};
    repeat (2) @(posedge clk); por_n = 1; @(posedge clk); @(posedge clk);
    reset_sys();
    chk("KAT ok -> LOAD (PROD)", {28'd0, state()}, CC_SB_STATE_LOAD);
    chk("PROD: debug and test mode closed", {30'd0, debug_en, test_en}, 0);
    chk("LOAD: IMEM writable, not executable", {30'd0, load_open, exec_open}, 2'b10);
    // ---- privilege in the ROM phase
    wr(CC_SEC_SVN_COMMIT, 1, e);   chk("firmware-phase SVN_COMMIT refused before hand-off", 32'(e), 1);
    wr(CC_SEC_EXPECT0, 0, e);      chk("EXPECT refused outside HASHED", 32'(e), 1);
    cmd(CC_SB_CMD_HASH, e);        chk("HASH refused in LOAD (not sealed)", 32'(e), 1);
    wr(CC_SEC_CMD, 32'h0000_0001, e); chk("CMD without the key tag refused", 32'(e), 1);
    wr(CC_SEC_TARGET_ID, 0, e);    chk("read-only register write refused", 32'(e), 1);
    rd(CC_SEC_VIOL_STATUS, v);     chk("refused privileged writes logged (SB_REG)", v[5], 1);
    // ---- seal waits for the DMA
    dma_busy = 1; cmd(CC_SB_CMD_SEAL, e); repeat (10) @(posedge clk);
    chk("SEALING while the DMA is busy", {28'd0, state()}, CC_SB_STATE_SEALING);
    chk("SEALING: IMEM already closed for writes", 32'(load_open), 0);
    dma_busy = 0; repeat (3) @(posedge clk);
    chk("SEALED once the DMA is idle", {28'd0, state()}, CC_SB_STATE_SEALED);
    // ---- bad hash parameters
    wr(CC_SEC_HASH_BASE, CC_IMEM_BASE + 2, e); wr(CC_SEC_HASH_LEN, 64, e); cmd(CC_SB_CMD_HASH, e);
    rd(CC_SEC_STATUS, v);
    chk("unaligned hash base -> FAIL (RANGE)", {v[31:24], v[3:0]}, {8'(CC_SB_HREF_RANGE), 4'(CC_SB_STATE_FAIL)});
    cmd(CC_SB_CMD_RELOAD, e);
    seal_hash(CC_IMEM_BASE + 32'hFF00, 32'h200);
    rd(CC_SEC_STATUS, v);
    chk("range past the end of IMEM -> FAIL (RANGE)", {v[31:24], v[3:0]}, {8'(CC_SB_HREF_RANGE), 4'(CC_SB_STATE_FAIL)});
    cmd(CC_SB_CMD_RELOAD, e);
    // ---- measurement
    seal_hash(CC_IMEM_BASE + 32'h100, len);
    chk("HASHED", {28'd0, state()}, CC_SB_STATE_HASHED);
    for (int i = 0; i < 8; i++) begin rd(CC_SEC_DIGEST0 + 12'(4 * i), v); chk($sformatf("DIGEST%0d == manifest", i), v, dg[i]); end
    // ---- KEY_LC: development slot in PROD (the ROM refuses it first; this is the hardware re-check)
    handoff(2'd0, 1, 1, href);
    chk("hand-off with the DEV key slot in PROD refused (KEY_LC)", 32'(href), CC_SB_HREF_KEY_LC);
    rd(CC_SEC_BOOT_FAILS, v); chk("failures counted (2 x RANGE + KEY_LC)", v, 3);
    cmd(CC_SB_CMD_RELOAD, e);
    seal_hash(CC_IMEM_BASE + 32'h100, len);
    handoff(2'd1, 1, 1, href);
    chk("correct hand-off -> PASS", {28'd0, state()}, CC_SB_STATE_PASS);
    chk("execute window = measured range", {exec_base, exec_end} == {CC_IMEM_BASE + 32'h100, CC_IMEM_BASE + 32'h100 + len}, 1);
    chk("execution open", 32'(exec_open), 1);
    rd(CC_SEC_BOOT_FAILS, v); chk("success clears the failure counter", v, 0);
    // ---- after hand-off
    wr(CC_SEC_HASH_BASE, 0, e); chk("ROM-phase register locked after PASS", 32'(e), 1);
    cmd(CC_SB_CMD_RELOAD, e);   chk("no command after PASS", 32'(e), 1);
    wr(CC_SEC_SVN_COMMIT, 2, e); rd(CC_SEC_OTP_STATUS, v);
    chk("SVN commit above the image's SVN refused", v[7:0], {4'(CC_SB_OTPERR_RANGE), 4'h3});
    wr(CC_SEC_SVN_COMMIT, 1, e); rd(CC_SEC_MIN_SVN, v); chk("SVN commit 1 -> MIN_SVN 1", v, 1);
    wr(CC_SEC_REVOKE_SET, 32'h2, e); rd(CC_SEC_OTP_STATUS, v);
    chk("revoking the active slot refused", v[7:0], {4'(CC_SB_OTPERR_ACTIVE_SLOT), 4'h3});
    wr(CC_SEC_LC_ADVANCE, CC_SB_LC_CODE_DEV, e); rd(CC_SEC_OTP_STATUS, v);
    chk("lifecycle cannot go back", v[7:0], {4'(CC_SB_OTPERR_TRANSITION), 4'h3});
    // ---- fault model: upset of the state register while running -> LOCKDOWN, execution closes
    force dut.st_q = 8'h55; @(posedge clk); release dut.st_q; repeat (3) @(posedge clk);
    chk("illegal state code -> LOCKDOWN", {28'd0, state()}, CC_SB_STATE_LOCKDOWN);
    chk("LOCKDOWN closes execution", 32'(exec_open), 0);
    chk("lockdown output", 32'(lockdown), 1);
    // single-bit upsets of PASS never reach another legal state
    begin
      int legal = 0;
      for (int b = 0; b < 8; b++) begin
        logic [7:0] c = 8'hD4 ^ (8'h1 << b);
        if (c == 8'h17 || c == 8'h2B || c == 8'h4D || c == 8'h8E || c == 8'h71 || c == 8'hB2 || c == 8'hE8) legal++;
      end
      chk("no single-bit flip of PASS is another legal state", 32'(legal), 0);
    end
    // ---- hash bus error, new boot
    reset_sys();
    chk("sys reset leaves LOCKDOWN (state is not sticky across reset)", {28'd0, state()}, CC_SB_STATE_LOAD);
    mem_err = 1; seal_hash(CC_IMEM_BASE + 32'h100, 64); mem_err = 0;
    rd(CC_SEC_STATUS, v);
    chk("bus error while measuring -> FAIL (HASH_ERR)", {v[31:24], v[3:0]}, {8'(CC_SB_HREF_HASH_ERR), 4'(CC_SB_STATE_FAIL)});
    cmd(CC_SB_CMD_RELOAD, e); cmd(CC_SB_CMD_FAIL, e); cmd(CC_SB_CMD_RELOAD, e); cmd(CC_SB_CMD_FAIL, e);
    rd(CC_SEC_BOOT_FAILS, v); chk("BOOT_FAILS = 3", v, 3);
    reset_sys();
    rd(CC_SEC_LIFECYCLE, v); chk("3 failures + reset -> RECOVERY", v[3:0], CC_SB_LC_RECOVERY);
    chk("RECOVERY keeps debug closed", 32'(debug_en), 0);
    // ---- the fuse model forgets at power-on (it is a model)
    por_n = 0; @(posedge clk); por_n = 1; repeat (2) @(posedge clk); reset_sys();
    rd(CC_SEC_MIN_SVN, v); chk("power-on reset: MIN_SVN back to the sensed fuse value (MODEL)", v, 0);
    $display("TB RESULT %s checks=%0d fails=%0d", fails_n == 0 ? "PASS" : "FAIL", checks, fails_n);
    if (fails_n != 0) $fatal(1, "failed");
    $finish(0);
  end
endmodule

`default_nettype wire
