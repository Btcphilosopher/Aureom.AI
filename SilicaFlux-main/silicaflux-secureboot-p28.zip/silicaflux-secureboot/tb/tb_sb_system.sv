// =============================================================================
// SilicaFlux secure boot (Project 28) :: tb_sb_system -- security regression
//
// DUT: silicaflux_control_core (ControlCore v2) WITHOUT the accelerators (their
// register port answers bus errors; the firmware reports DEGRADED) so that the
// many boots of the security suite simulate quickly.  The functional
// regression with both accelerators is tb/tb_cc_system.sv.
// The testbench plays: the HOST (SFB2 master on the host port, host reset pin),
// the DEVICE MEMORY (1 MiB SFB2 slave on the external port), a JTAG probe
// (bit-banged TAP), the fuse-sense inputs and the recovery strap.  Everything
// else -- verification, policy, isolation -- is the real boot ROM, firmware and
// RTL.
//
// Plusargs: +scenario=<name> +fw=<signed image .hex> [+lc=DEV|PROV|PROD] [+vectors=<tb_index.txt>]
//           [+img2=<hex>] [+img3=<hex>] [+timeout=<cycles>]
// Result:   "TB RESULT PASS|FAIL scenario=... cycles=..." and the exit status.
// Every check prints "TB CHECK <PASS|FAIL> <what> got=.. exp=.." (scripts/sb_regress.py
// counts them).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sb_system;
  import cc_memmap_pkg::*;
  // firmware self-test groups that do not need the accelerators: identity, MMIO, exceptions, timer,
  // interrupts, DMA, RAS, watchdog, secure boot (fw.h ST_*)
  localparam logic [31:0] ST_NOACC = 32'h0000_543F;

  // ------------------------------------------------------------------ clock / reset / pins
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  string   scenario, fw_path;
  int      rt0 = 0;                // runtime 0 (set from $urandom): loop bounds that are not constant-folded/unrolled
  longint  timeout;
  int      tb_fails = 0, tb_checks = 0;
  logic [1:0]  boot_mode = 2'b00;
  logic        host_rst = 1'b0, recovery = 1'b0;
  logic [31:0] fuse_lc = CC_SB_LC_CODE_PROD, fuse_revoke = '0, fuse_svn = '0, fuse_cfg = '0;
  logic        tck = 1'b0, trst_n = 1'b0, tms = 1'b1, tdi = 1'b0, tdo, tdo_oe;

  // ------------------------------------------------------------------ DUT
  logic        hs_req_valid = 1'b0, hs_req_ready, hs_req_write = 1'b0, hs_rsp_valid, hs_rsp_error;
  logic [31:0] hs_req_addr = '0, hs_req_wdata = '0, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb = 4'hF;
  logic        host_irq, host_ready, cmdproc_ready, ras_fatal;
  logic        x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [31:0] x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [3:0]  x_req_wstrb;
  logic        acc_rb_sel, acc_rb_we, acc_clk, acc_rst_n;
  logic [15:0] acc_rb_addr;
  logic [31:0] acc_rb_wdata;
  logic        diag_valid, test_done, test_fail, cpu_sleep, sb_exec_open, sb_lockdown;
  logic [7:0]  diag_char;
  logic [15:0] test_code;

  silicaflux_control_core u_cc (
    .clk, .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(boot_mode), .host_rst_req_i(host_rst),
    .recovery_req_i(recovery), .fuse_lc_i(fuse_lc), .fuse_revoke_i(fuse_revoke), .fuse_svn_i(fuse_svn),
    .fuse_cfg_i(fuse_cfg),
    .jtag_tck(tck), .jtag_trst_n(trst_n), .jtag_tms(tms), .jtag_tdi(tdi), .jtag_tdo(tdo), .jtag_tdo_oe(tdo_oe),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready(1'b1), .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(host_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready), .ras_fatal_o(ras_fatal),
    .acc_rb_sel, .acc_rb_we, .acc_rb_addr, .acc_rb_wdata, .acc_rb_rdata(32'd0), .acc_rb_err(1'b1),
    .ext_req_valid(x_req_valid), .ext_req_ready(x_req_ready), .ext_req_write(x_req_write), .ext_req_addr(x_req_addr),
    .ext_req_wdata(x_req_wdata), .ext_req_wstrb(x_req_wstrb), .ext_rsp_valid(x_rsp_valid), .ext_rsp_ready(x_rsp_ready),
    .ext_rsp_rdata(x_rsp_rdata), .ext_rsp_error(x_rsp_error),
    .acc_clk_o(acc_clk), .acc_rst_no(acc_rst_n),
    .acc_vec_irq_i(1'b0), .acc_tsu_irq_i(1'b0), .acc_vec_busy_i(1'b0), .acc_tsu_busy_i(1'b0), .acc_tsu_halted_i(1'b0),
    .ext_warn_i(1'b0), .ext_fatal_i(1'b0),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep), .sb_exec_open_o(sb_exec_open), .sb_lockdown_o(sb_lockdown)
  );

  // ------------------------------------------------------------------ device memory (1 MiB at CC_DEVMEM_BASE)
  localparam int DM_WORDS = int'(CC_DEVMEM_SIZE) / 4;
  logic [31:0] dmem [DM_WORDS];
  logic        dm_rv = 1'b0, dm_re = 1'b0;
  logic [31:0] dm_rd = '0;
  int unsigned dm_reads = 0, dm_writes = 0;
  assign x_req_ready = !dm_rv;
  assign x_rsp_valid = dm_rv;
  assign x_rsp_rdata = dm_rd;
  assign x_rsp_error = dm_re;
  function automatic bit dm_bad(input logic [31:0] a);
    return (a < CC_DEVMEM_BASE) || (a >= CC_DEVMEM_BASE + CC_DEVMEM_SIZE) ||
           (a >= CC_TB_POISON_BASE && a < CC_TB_POISON_BASE + CC_TB_POISON_SIZE);
  endfunction
  always @(posedge clk) begin
    if (dm_rv && x_rsp_ready) dm_rv <= 1'b0;
    if (x_req_valid && x_req_ready) begin
      automatic int w = int'((x_req_addr - CC_DEVMEM_BASE) >> 2);
      dm_rv <= 1'b1; dm_re <= dm_bad(x_req_addr); dm_rd <= '0;
      if (!dm_bad(x_req_addr)) begin
        if (x_req_write) begin
          for (int b = 0; b < 4; b++) if (x_req_wstrb[b]) dmem[w][8*b +: 8] <= x_req_wdata[8*b +: 8];
          dm_writes++;
        end else begin
          dm_rd <= dmem[w]; dm_reads++;
        end
      end
    end
  end

  // ------------------------------------------------------------------ console capture
  string line = "";
  always @(posedge clk) if (diag_valid) begin
    if (diag_char == 8'h0A) begin $display("[%0d] FW| %s", cyc, line); line = ""; end
    else line = {line, string'(diag_char)};
  end

  // ------------------------------------------------------------------ monitors
  // secure-boot state transitions (+sbdbg)
  bit sbdbg;
  initial sbdbg = $test$plusargs("sbdbg");
  logic [7:0] sbst_q = '0;
  always @(posedge clk) begin
    sbst_q <= u_cc.u_sb.st_q;
    if (sbdbg && u_cc.u_sb.st_q != sbst_q)
      $display("[%0d] SBDBG state %02h -> %02h (enum %0d) rs=%0d imem_idle=%0d dma_busy=%0d", cyc, sbst_q,
               u_cc.u_sb.st_q, u_cc.u_sb.st_enum, u_cc.u_sb.rs, u_cc.imem_idle, u_cc.dma_busy);
  end
  int exec_open_rises = 0;
  logic exec_q = 1'b0;
  always @(posedge clk) begin
    exec_q <= sb_exec_open;
    if (sb_exec_open && !exec_q) exec_open_rises++;
  end
  // every instruction fetch the crossbar accepts from IMEM must lie in the open execute window
  int illegal_fetches = 0;
  always @(posedge clk) begin
    if (u_cc.m_req_valid[CC_M_CPU_I] && u_cc.m_req_ready[CC_M_CPU_I]) begin
      automatic logic [31:0] a = u_cc.m_req_addr[CC_M_CPU_I*32 +: 32];
      if (a >= CC_IMEM_BASE && a < CC_IMEM_BASE + CC_IMEM_SIZE &&
          !(sb_exec_open && a >= u_cc.sb_exec_base && a < u_cc.sb_exec_end)) begin
        illegal_fetches++;
        $display("[%0d] TB ERROR: IMEM fetch %08h reached the crossbar outside the authenticated window", cyc, a);
      end
    end
  end

  // ------------------------------------------------------------------ host BFM
  task automatic host_access(input bit wr, input logic [31:0] a, input logic [31:0] wd, output logic [31:0] rd,
                             output bit err);
    @(negedge clk);
    hs_req_valid = 1'b1; hs_req_write = wr; hs_req_addr = a; hs_req_wdata = wd; hs_req_wstrb = 4'hF;
    do @(posedge clk); while (!hs_req_ready);
    @(negedge clk); hs_req_valid = 1'b0;
    while (!hs_rsp_valid) @(posedge clk);
    rd = hs_rsp_rdata; err = hs_rsp_error;
    @(posedge clk);
  endtask
  int host_errors = 0;
  task automatic hwr(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; bit e;
    host_access(1'b1, a, d, r, e);
    if (e) begin host_errors++; if (sbdbg) $display("[%0d] SBDBG host write %08h refused", cyc, a); end
  endtask
  task automatic hrd(input logic [31:0] a, output logic [31:0] d);
    bit e;
    host_access(1'b0, a, 32'd0, d, e);
    if (e) begin host_errors++; if (sbdbg) $display("[%0d] SBDBG host read %08h refused", cyc, a); end
  endtask
  task automatic check(input string what, input logic [31:0] got, input logic [31:0] exp);
    tb_checks++;
    if (got !== exp) begin
      tb_fails++;
      $display("[%0d] TB CHECK FAIL %s got=%08h exp=%08h", cyc, what, got, exp);
    end else $display("[%0d] TB CHECK PASS %s got=%08h", cyc, what, got);
  endtask
  // host access that MUST be refused by the host filter (error response, nothing reaches the target)
  task automatic expect_host_refused(input string what, input bit wr, input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; bit e;
    host_access(wr, a, d, r, e);
    check({"host filter refuses ", what}, 32'(e), 1);
  endtask

  task automatic wait_stage(input logic [31:0] st, input longint tmo);
    logic [31:0] v; longint t0 = cyc;
    do begin hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v); repeat (50) @(posedge clk); end
    while (v[7:0] != st[7:0] && cyc - t0 < tmo);
    if (v[7:0] != st[7:0]) begin $display("TB ERROR: timeout waiting for boot stage %0h (now %0h)", st, v); tb_fails++; end
  endtask
  task automatic wait_sb_state(input logic [3:0] st, input longint tmo);
    logic [31:0] v; longint t0 = cyc;
    do begin hrd(CC_SECURITY_BASE + CC_SEC_STATUS, v); repeat (20) @(posedge clk); end
    while (v[3:0] != st && cyc - t0 < tmo);
    if (v[3:0] != st) begin $display("TB ERROR: timeout waiting for SB state %0h (now %0h)", st, v[3:0]); tb_fails++; end
  endtask

  // images
  logic [31:0] img [$];
  task automatic load_hex(input string path, ref logic [31:0] q[$]);
    int fd; logic [31:0] w;
    q.delete();
    fd = $fopen(path, "r");
    if (fd == 0) $fatal(1, "cannot open %s", path);
    while ($fscanf(fd, "%h\n", w) == 1) q.push_back(w);
    $fclose(fd);
  endtask
  // write an image into IMEM through the host port; returns the number of refused words
  task automatic host_load(ref logic [31:0] q[$], output int refused);
    logic [31:0] r; bit e;
    longint t0 = cyc;
    refused = 0;
    for (int i = 0; i < q.size(); i++) begin
      host_access(1'b1, CC_IMEM_BASE + 32'(4 * i), q[i], r, e);
      if (e) refused++;
    end
    $display("[%0d] TB host: %0d words written to IMEM in %0d cycles, %0d refused", cyc, q.size(), cyc - t0, refused);
  endtask

  // mailbox
  logic [31:0] rsp [8];
  task automatic mbox_wait(input longint tmo, output bit ok);
    longint t0 = cyc;
    ok = 1'b1;
    while (!host_irq) begin
      @(posedge clk);
      if (cyc - t0 > tmo) begin ok = 1'b0; return; end
    end
    for (int i = 0; i < 8 + rt0; i++) hrd(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 32'(4 * i), rsp[i]);
    hwr(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
  endtask
  task automatic mbox_cmd(input logic [31:0] cmd, input logic [31:0] a1, input logic [31:0] a2, input logic [31:0] a3,
                          input longint tmo);
    bit ok;
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, a1);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 8, a2);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 12, a3);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd);
    if (sbdbg) $display("[%0d] SBDBG mailbox cmd %02h sent, host errors so far %0d", cyc, cmd, host_errors);
    mbox_wait(tmo, ok);
    if (!ok) begin $display("TB ERROR: no answer to mailbox command %02h", cmd); tb_fails++; rsp[0] = 32'hFFFF_FFFF; end
  endtask
  // load + IMAGE_READY; returns the ROM's answer: status (rsp[0][7:0]) and code (rsp[1])
  longint auth_cycles;
  task automatic boot_image(ref logic [31:0] q[$], output logic [7:0] sts, output logic [31:0] code);
    int refused;
    longint t0;
    wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 4_000_000);
    host_load(q, refused);
    t0 = cyc;
    mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 0, 0, 0, 30_000_000);
    auth_cycles = cyc - t0;
    sts = rsp[0][7:0]; code = rsp[1];
    $display("[%0d] TB host: IMAGE_READY -> status %0d code %02h after %0d cycles", cyc, sts, code, auth_cycles);
  endtask
  task automatic wait_host_ready(input longint tmo);
    longint t0 = cyc; bit ok;
    while (!host_ready) begin
      @(posedge clk);
      if (cyc - t0 > tmo) begin $display("TB ERROR timeout waiting for HOST_READY"); tb_fails++; return; end
    end
    mbox_wait(1000, ok);
    $display("[%0d] TB host: HOST READY: accelerators=%0h reset_cause=%0h fw=%08h measurement=%08h", cyc, rsp[1],
             rsp[4], rsp[5], rsp[6]);
  endtask
  task automatic power_on(input logic [31:0] lc, input logic [31:0] rev, input logic [31:0] svn,
                          input logic [31:0] cfg, input bit rec);
    rst_n = 1'b0; fuse_lc = lc; fuse_revoke = rev; fuse_svn = svn; fuse_cfg = cfg; recovery = rec;
    repeat (8) @(posedge clk);
    rst_n = 1'b1;
    repeat (8) @(posedge clk);
  endtask
  task automatic host_reset();
    host_rst = 1'b1; repeat (10) @(posedge clk); host_rst = 1'b0; repeat (60) @(posedge clk);
  endtask
  task automatic shutdown_fw();
    mbox_cmd(CC_MBOX_CMD_SHUTDOWN, 32'(tb_fails), 0, 0, 200000);
    repeat (20) @(posedge clk);
  endtask

  // ------------------------------------------------------------------ JTAG BFM (TCK = 1/4 of clk)
  task automatic jtick(input bit m, input bit d, output bit o);
    tms = m; tdi = d; #18; o = tdo; tck = 1'b1; #20; tck = 1'b0; #2;
  endtask
  task automatic jtag_reset();
    bit o;
    trst_n = 1'b0; #50; trst_n = 1'b1;
    for (int i = 0; i < 6 + rt0; i++) jtick(1, 0, o);
    jtick(0, 0, o);                                   // Run-Test/Idle
  endtask
  task automatic jtag_ir(input logic [4:0] ir);
    bit o;
    jtick(1, 0, o); jtick(1, 0, o); jtick(0, 0, o); jtick(0, 0, o);       // Select-DR, Select-IR, Capture-IR, Shift-IR
    for (int i = 0; i < 5 + rt0; i++) jtick(i == 4, ir[i], o);                  // last bit -> Exit1-IR
    jtick(1, 0, o); jtick(0, 0, o);                                       // Update-IR, RTI
  endtask
  task automatic jtag_dr(input int n, input logic [65:0] din, output logic [65:0] dout);
    bit o;
    dout = '0;
    jtick(1, 0, o); jtick(0, 0, o); jtick(0, 0, o);                       // Select-DR, Capture-DR, Shift-DR
    for (int i = 0; i < n; i++) begin jtick(i == n - 1, din[i], o); dout[i] = o; end
    jtick(1, 0, o); jtick(0, 0, o);                                       // Update-DR, RTI
  endtask
  // system-bus access through JTAG SBA (IR 0x10); returns {err, rdata}
  task automatic jtag_sba(input bit wr, input logic [31:0] a, input logic [31:0] d, output logic [31:0] rd,
                          output bit err);
    logic [65:0] o;
    jtag_ir(5'h10);
    jtag_dr(66, {wr ? 2'd2 : 2'd1, d, a}, o);
    repeat (40) @(posedge clk);
    do jtag_dr(66, {2'd0, 32'd0, 32'd0}, o); while (o[65]);               // poll until not busy
    rd = o[63:32]; err = o[64];
  endtask
  task automatic jtag_idcode(output logic [31:0] id);
    logic [65:0] o;
    jtag_ir(5'h01);
    jtag_dr(32, 66'd0, o);
    id = o[31:0];
  endtask
  task automatic jtag_dbgctrl(input logic [7:0] v);
    logic [65:0] o;
    jtag_ir(5'h11);
    jtag_dr(8, {58'd0, v}, o);
  endtask

  // ------------------------------------------------------------------ helpers for the checks
  task automatic host_isolation_checks();
    logic [31:0] v;
    expect_host_refused("IMEM write after hand-off", 1, CC_IMEM_BASE + 32'h200, 32'h0);
    expect_host_refused("DMEM write (firmware data / stack)", 1, CC_DMEM_BASE + 32'h7F00, 32'h0);
    expect_host_refused("DMEM read", 0, CC_DMEM_BASE, 32'h0);
    expect_host_refused("BOOTROM read", 0, CC_BOOTROM_BASE, 32'h0);
    expect_host_refused("SECURITY write (CMD)", 1, CC_SECURITY_BASE + CC_SEC_CMD, CC_SB_CMD_KEY | CC_SB_CMD_RELOAD);
    expect_host_refused("SECURITY write (fuse model SVN)", 1, CC_SECURITY_BASE + CC_SEC_SVN_COMMIT, 32'd5);
    expect_host_refused("DMA register write (SRC)", 1, CC_DMA_BASE + CC_DMA_SRC_ADDR, CC_IMEM_BASE);
    expect_host_refused("DMA_GUARD window write", 1, CC_DMA_GUARD_BASE + CC_DG_WIN0_BASE, 32'h0);
    expect_host_refused("SYSCTRL SOFT_RESET", 1, CC_SYSCTRL_BASE + CC_SYSCTRL_SOFT_RESET, CC_SOFT_RESET_KEY);
    expect_host_refused("INTC read (CLAIM side effect)", 0, CC_INTC_BASE + CC_INTC_CLAIM, 32'h0);
    expect_host_refused("RAS INJECT", 1, CC_RAS_BASE + CC_RAS_INJECT, 32'hFFFF);
    expect_host_refused("accelerator page", 0, CC_VECTOR_BASE, 32'h0);
    expect_host_refused("mailbox console injection (DIAG_TX)", 1, CC_MAILBOX_BASE + CC_MBOX_DIAG_TX, 32'h41);
    hrd(CC_SECURITY_BASE + CC_SEC_VIOL_STATUS, v);
    check("SECURITY.VIOL_STATUS.HOST recorded", v & 1, 1);
  endtask


  // ------------------------------------------------------------------ scenario helpers
  string FW_DIR = "firmware/build/fw";
  task automatic boot_expect(input string what, ref logic [31:0] q[$], input logic [7:0] exp_sts,
                             input logic [31:0] exp_code);
    logic [7:0] sts; logic [31:0] code;
    boot_image(q, sts, code);
    check({what, ": ROM status"}, sts, exp_sts);
    if (exp_sts != CC_MBOX_STS_OK) check({what, ": BOOT_ERR code"}, code, exp_code);
    else wait_host_ready(5_000_000);
  endtask
  task automatic load_named(input string name, ref logic [31:0] q[$]);
    load_hex({FW_DIR, "/", name, ".hex"}, q);
  endtask
  // send IMAGE_READY without waiting for the answer
  task automatic ring_image_ready();
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, CC_MBOX_CMD_IMAGE_READY);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, CC_MBOX_CMD_IMAGE_READY);
  endtask
  task automatic sb_status(output logic [31:0] v);
    hrd(CC_SECURITY_BASE + CC_SEC_STATUS, v);
  endtask
  task automatic jtag_sb_cmd(input logic [7:0] c, output bit err);
    logic [31:0] r;
    jtag_sba(1, CC_SECURITY_BASE + CC_SEC_CMD, CC_SB_CMD_KEY | 32'(c), r, err);
  endtask
  task automatic jtag_wr(input logic [31:0] a, input logic [31:0] d, output bit err);
    logic [31:0] r;
    jtag_sba(1, a, d, r, err);
  endtask
  // manifest fields of an image in a word queue
  function automatic logic [31:0] mf(ref logic [31:0] q[$], input int ofs);
    return q[ofs / 4];
  endfunction
  function automatic logic [31:0] bswap(input logic [31:0] w);
    return {w[7:0], w[15:8], w[23:16], w[31:24]};
  endfunction

  // ------------------------------------------------------------------ timeout
  initial begin
    if (!$value$plusargs("timeout=%d", timeout)) timeout = 400_000_000;
    wait (cyc > timeout);
    $display("TB RESULT FAIL scenario=%s TIMEOUT at cycle %0d", scenario, cyc);
    $fatal(1, "timeout");
  end

  task automatic finish();
    check("no IMEM fetch outside the authenticated window", 32'(illegal_fetches), 0);
    $display("TB RESULT %s scenario=%s cycles=%0d checks=%0d fails=%0d", (tb_fails == 0) ? "PASS" : "FAIL", scenario,
             cyc, tb_checks, tb_fails);
    if (tb_fails == 0) $finish(0);
    else $fatal(1, "scenario %s failed", scenario);
  endtask

  // ------------------------------------------------------------------ scenarios (one task each)
  task automatic sc_boot_ok();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        boot_image(img, sts, code);
        check("ROM accepted the signed image", sts, CC_MBOX_STS_OK);
        $display("TB METRIC auth_cycles=%0d", auth_cycles);
        wait_host_ready(5_000_000);
        hrd(CC_SECURITY_BASE + CC_SEC_STATUS, v);
        check("SB state PASS", v[3:0], CC_SB_STATE_PASS);
        check("EXEC_OPEN", v[13], 1);
        check("ROM fetch closed after hand-off", v[14], 0);
        check("execute window opened exactly once", 32'(exec_open_rises), 1);
        host_isolation_checks();
        mbox_cmd(CC_MBOX_CMD_PING, 32'h1234_5678, 0, 0, 100000);
        check("PING echo", rsp[1], 32'h1234_5678);
        mbox_cmd(CC_MBOX_CMD_RUN_SELFTEST, ST_NOACC, 0, 0, 40_000_000);
        check("firmware self-test (no accelerators) fails", rsp[2], 0);
        $display("TB host: firmware self-test executed %0d checks", rsp[1]);
        // confused deputy: the host asks the firmware to DMA into the firmware itself
        mbox_cmd(CC_MBOX_CMD_DMA_COPY, CC_DEVMEM_BASE, CC_IMEM_BASE + 32'h200, 64, 1_000_000);
        check("DMA_COPY into IMEM refused by the DMA guard (DENIED)", rsp[0][7:0], CC_MBOX_STS_DENIED);
        mbox_cmd(CC_MBOX_CMD_DMA_COPY, CC_DEVMEM_BASE, CC_DMEM_BASE + 32'h7F00, 64, 1_000_000);
        check("DMA_COPY onto the firmware stack refused", rsp[0][7:0], CC_MBOX_STS_DENIED);
        mbox_cmd(CC_MBOX_CMD_DMA_COPY, CC_DEVMEM_BASE, CC_DEVMEM_BASE + 32'h1000, 64, 1_000_000);
        check("legal DMA_COPY still works", rsp[0][7:0], CC_MBOX_STS_OK);
        shutdown_fw();
        check("firmware verdict", 32'(test_done && !test_fail), 1);
        finish();
  endtask

  task automatic sc_vectors();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        string idx, name, hexp; int fd, n = 0, rec; logic [31:0] exp, lc, rev, svn, cfg;
        logic [159:0] cur_k, new_k; logic [31:0] q [$], fcode; int refused;
        if (!$value$plusargs("vectors=%s", idx)) idx = "build/vectors/tb_index.txt";
        fd = $fopen(idx, "r");
        if (fd == 0) $fatal(1, "cannot open %s", idx);
        cur_k = {CC_SB_LC_CODE_PROD, 128'd0};
        while ($fscanf(fd, "%s %h %h %h %h %h %d %s\n", name, exp, lc, rev, svn, cfg, rec, hexp) == 8) begin
          new_k = {lc, rev, svn, cfg, 32'(rec)};
          if (cur_k != new_k) begin
            power_on(lc, rev, svn, cfg, rec[0]);
            cur_k = new_k;
          end
          load_hex(hexp, q);
          wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 4_000_000);
          host_load(q, refused);
          mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 0, 0, 0, 30_000_000);
          sts = rsp[0][7:0];
          n++;
          $display("TB VECTOR %s expect %02h -> status %0d code %02h (%0d words, %0d refused by the host filter)",
                   name, exp, sts, rsp[1], q.size(), refused);
          if (exp == 0) begin
            check({"vector ", name, " accepted"}, sts, CC_MBOX_STS_OK);
            wait_host_ready(5_000_000);
            mbox_cmd(CC_MBOX_CMD_PING, 32'hC0FFEE00 + 32'(n), 0, 0, 100000);
            check({"vector ", name, " firmware runs"}, rsp[1], 32'hC0FFEE00 + 32'(n));
            host_reset();
          end else begin
            check({"vector ", name, " rejected"}, sts, CC_MBOX_STS_BAD_CMD);
            check({"vector ", name, " reason"}, rsp[1], exp);
            hrd(CC_SECURITY_BASE + CC_SEC_FAIL_CODE, fcode);
            check({"vector ", name, " SECURITY.FAIL_CODE"}, fcode, exp);
            if (name == "oversized_file") check("oversized file: host writes beyond IMEM refused", 32'(refused > 0), 1);
          end
        end
        $fclose(fd);
        $display("TB host: %0d vectors replayed on the RTL", n);
        finish();
  endtask

  task automatic sc_ext_boot();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        boot_mode = 2'b01;
        foreach (img[i]) dmem[int'((CC_EXT_IMAGE_DEFAULT - CC_DEVMEM_BASE) >> 2) + i] = img[i];
        power_on(CC_SB_LC_CODE_PROD, 0, 0, 0, 0);
        wait_host_ready(30_000_000);
        check("EXT boot: firmware authenticated without the host", 32'(sb_exec_open), 1);
        check("EXT boot: DMA read exactly the image", dm_reads, img.size());
        mbox_cmd(CC_MBOX_CMD_PING, 32'h0E0E_0E0E, 0, 0, 100000);
        check("PING", rsp[1], 32'h0E0E_0E0E);
        finish();
  endtask

  task automatic sc_ext_reject();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        logic [31:0] q [$]; bit ok;
        boot_mode = 2'b01;
        load_hex("build/vectors/oversized_length.hex", q);
        foreach (q[i]) dmem[int'((CC_EXT_IMAGE_DEFAULT - CC_DEVMEM_BASE) >> 2) + i] = q[i];
        power_on(CC_SB_LC_CODE_PROD, 0, 0, 0, 0);
        mbox_wait(10_000_000, ok);
        check("EXT oversized: ROM reports a failure", rsp[0][7:0], CC_MBOX_STS_BAD_CMD);
        check("EXT oversized: reason LENGTH", rsp[1], CC_BOOT_ERR_LENGTH);
        check("EXT oversized: only the manifest was read before the length check (64 words)", dm_reads, 64);
        boot_expect("EXT oversized -> host fallback", img, CC_MBOX_STS_OK, 0);
        // second cold boot: payload modified in the image store
        load_hex("build/vectors/modified_payload_byte.hex", q);
        foreach (q[i]) dmem[int'((CC_EXT_IMAGE_DEFAULT - CC_DEVMEM_BASE) >> 2) + i] = q[i];
        dm_reads = 0;
        power_on(CC_SB_LC_CODE_PROD, 0, 0, 0, 0);
        mbox_wait(30_000_000, ok);
        check("EXT tampered: ROM reports a failure", rsp[0][7:0], CC_MBOX_STS_BAD_CMD);
        check("EXT tampered: reason DIGEST", rsp[1], CC_BOOT_ERR_DIGEST);
        check("EXT tampered: execute window never opened", 32'(exec_open_rises), 1);   // only the host boot above
        boot_expect("EXT tampered -> host fallback", img, CC_MBOX_STS_OK, 0);
        finish();
  endtask

  task automatic sc_toctou();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        int refused = 0, tried = 0; logic [31:0] w0;
        wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 4_000_000);
        host_load(img, refused);
        ring_image_ready();
        do sb_status(v); while (v[3:0] != CC_SB_STATE_HASHING && v[3:0] != CC_SB_STATE_HASHED);
        for (int i = 0; i < 8 + rt0; i++) begin
          host_access(1'b1, CC_IMEM_BASE + 32'h400 + 32'(4 * i), 32'hDEAD_0000 + 32'(i), v, e);
          tried++; refused += e;
        end
        do sb_status(v); while (v[3:0] != CC_SB_STATE_HASHED);
        for (int i = 0; i < 8 + rt0; i++) begin              // during the Ed25519 verification
          host_access(1'b1, CC_IMEM_BASE + 32'h100 + 32'(4 * i), 32'hBAD0_0000 + 32'(i), v, e);
          tried++; refused += e;
        end
        check("TOCTOU: every host write to the sealed IMEM refused", 32'(refused), 32'(tried));
        mbox_wait(30_000_000, e);
        check("TOCTOU: the original image is authenticated", rsp[0][7:0], CC_MBOX_STS_OK);
        wait_host_ready(5_000_000);
        hrd(CC_IMEM_BASE + 32'h100, w0);
        check("TOCTOU: IMEM holds the signed code", w0, img[64]);
        finish();
  endtask

  task automatic sc_reset_auth();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        // (a) host reset while hashing, (b) host reset during the signature check, (c) power-on reset during it
        for (int k = 0; k < 3 + rt0; k++) begin
          int refused;
          wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 4_000_000);
          host_load(img, refused);
          ring_image_ready();
          if (k == 0) do sb_status(v); while (v[3:0] != CC_SB_STATE_HASHING);
          else begin do sb_status(v); while (v[3:0] != CC_SB_STATE_HASHED); repeat (1_500_000) @(posedge clk); end
          $display("[%0d] TB host: %s during %s", cyc, k == 2 ? "POWER-ON RESET" : "host reset",
                   k == 0 ? "hashing" : "signature verification");
          if (k == 2) power_on(CC_SB_LC_CODE_PROD, 0, 0, 0, 0); else host_reset();
          check("reset during authentication: execute window never opened", 32'(exec_open_rises), 0);
          wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 4_000_000);
          sb_status(v);
          check("after the reset: secure boot back in LOAD", v[3:0], CC_SB_STATE_LOAD);
          check("after the reset: no digest / tokens carried over", v[12:10], 0);
          hrd(CC_IMEM_BASE + 32'h100, v);
          check("after the reset: IMEM scrubbed (no half-verified image survives)", v, 0);
          hrd(CC_SECURITY_BASE + CC_SEC_BOOT_FAILS, v);
          check("a reset is not counted as an authentication failure", v, 0);
        end
        boot_expect("boot after the interrupted attempts", img, CC_MBOX_STS_OK, 0);
        check("execute window opened exactly once", 32'(exec_open_rises), 1);
        finish();
  endtask

  task automatic sc_rollback();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        logic [31:0] q0 [$];
        load_named("controlcore_fw_svn0", q0);
        boot_expect("svn 1 image on a fresh part", img, CC_MBOX_STS_OK, 0);
        mbox_cmd(CC_MBOX_CMD_SB_SVN_COMMIT, 2, 0, 0, 100000);
        check("SVN commit above the running image's SVN refused", rsp[0][7:0], CC_MBOX_STS_DENIED);
        check("  reason RANGE", rsp[6][7:4], CC_SB_OTPERR_RANGE);
        mbox_cmd(CC_MBOX_CMD_SB_SVN_COMMIT, 1, 0, 0, 100000);
        check("SVN commit 1 accepted", rsp[0][7:0], CC_MBOX_STS_OK);
        check("MIN_SVN = 1", rsp[4], 1);
        host_reset();
        boot_expect("svn 0 image after the commit", q0, CC_MBOX_STS_BAD_CMD, CC_BOOT_ERR_ROLLBACK);
        boot_expect("svn 1 image still boots", img, CC_MBOX_STS_OK, 0);
        // the documented limit: the fuse MODEL is POR-domain state, a power cycle forgets it
        power_on(CC_SB_LC_CODE_PROD, 0, 0, 0, 0);
        boot_expect("LIMITATION: after a power cycle the MODEL forgot the commit (svn 0 boots)", q0, CC_MBOX_STS_OK, 0);
        power_on(CC_SB_LC_CODE_PROD, 0, 32'h1, 0, 0);       // fuses that really hold SVN 1
        boot_expect("with SVN 1 sensed at power-up, svn 0 is refused", q0, CC_MBOX_STS_BAD_CMD, CC_BOOT_ERR_ROLLBACK);
        finish();
  endtask

  task automatic sc_revoke();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        logic [31:0] q2 [$];
        load_named("controlcore_fw_slot2", q2);
        boot_expect("image signed with rotated key slot 2", q2, CC_MBOX_STS_OK, 0);
        mbox_cmd(CC_MBOX_CMD_SB_REVOKE, 32'h4, 0, 0, 100000);
        check("revoking the running image's own slot refused", rsp[0][7:0], CC_MBOX_STS_DENIED);
        check("  reason ACTIVE_SLOT", rsp[6][7:4], CC_SB_OTPERR_ACTIVE_SLOT);
        mbox_cmd(CC_MBOX_CMD_SB_REVOKE, 32'h2, 0, 0, 100000);
        check("revoking old slot 1 accepted", rsp[0][7:0], CC_MBOX_STS_OK);
        check("REVOKED = slot 1", rsp[5], 32'h2);
        host_reset();
        boot_expect("slot 1 image after revocation", img, CC_MBOX_STS_BAD_CMD, CC_BOOT_ERR_KEY_REVOKED);
        boot_expect("slot 2 image still boots", q2, CC_MBOX_STS_OK, 0);
        finish();
  endtask

  task automatic sc_lifecycle();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        logic [31:0] qd [$];
        load_named("controlcore_fw_dev", qd);
        power_on(CC_SB_LC_CODE_DEV, 0, 0, 0, 0);
        boot_expect("DEV part: development-key image", qd, CC_MBOX_STS_OK, 0);
        hrd(CC_SECURITY_BASE + CC_SEC_LIFECYCLE, v);
        check("DEV: lifecycle DEV, debug enabled", v[9:0] & 10'h20F, 10'h200 | CC_SB_LC_DEV);
        mbox_cmd(CC_MBOX_CMD_SB_REVOKE, 32'hE, 0, 0, 100000);
        check("revoking every production slot refused", rsp[0][7:0], CC_MBOX_STS_DENIED);
        check("  reason LAST_SLOT", rsp[6][7:4], CC_SB_OTPERR_LAST_SLOT);
        mbox_cmd(CC_MBOX_CMD_SB_LC_ADVANCE, CC_SB_LC_CODE_PROD, 0, 0, 100000);
        check("DEV -> PROD (skipping PROV) refused", rsp[0][7:0], CC_MBOX_STS_DENIED);
        mbox_cmd(CC_MBOX_CMD_SB_LC_ADVANCE, CC_SB_LC_CODE_PROV, 0, 0, 100000);
        check("DEV -> PROV accepted", rsp[0][7:0], CC_MBOX_STS_OK);
        check("  takes effect at the next reset (still DEV)", rsp[2][3:0], CC_SB_LC_DEV);
        host_reset();
        hrd(CC_SECURITY_BASE + CC_SEC_LIFECYCLE, v);
        check("after reset: lifecycle PROV, debug closed", v[9:0] & 10'h20F, CC_SB_LC_PROV);
        boot_expect("PROV: development key refused", qd, CC_MBOX_STS_BAD_CMD, CC_BOOT_ERR_KEY_LIFECYCLE);
        boot_expect("PROV: production-key image", img, CC_MBOX_STS_OK, 0);
        mbox_cmd(CC_MBOX_CMD_SB_LC_ADVANCE, CC_SB_LC_CODE_DEV, 0, 0, 100000);
        check("PROV -> DEV refused (one way)", rsp[0][7:0], CC_MBOX_STS_DENIED);
        mbox_cmd(CC_MBOX_CMD_SB_LC_ADVANCE, CC_SB_LC_CODE_PROD, 0, 0, 100000);
        check("PROV -> PROD accepted", rsp[0][7:0], CC_MBOX_STS_OK);
        host_reset();
        hrd(CC_SECURITY_BASE + CC_SEC_LIFECYCLE, v);
        check("after reset: lifecycle PROD", v[3:0], CC_SB_LC_PROD);
        hrd(CC_SECURITY_BASE + CC_SEC_OTP_LC, v);
        check("fuse model LC word = PROD code", v, CC_SB_LC_CODE_PROD);
        finish();
  endtask

  task automatic sc_recovery();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        logic [31:0] qb [$];
        boot_mode = 2'b01;                                 // EXT requested, valid image in the store...
        foreach (img[i]) dmem[int'((CC_EXT_IMAGE_DEFAULT - CC_DEVMEM_BASE) >> 2) + i] = img[i];
        power_on(CC_SB_LC_CODE_PROD, 0, 0, 0, 1'b1);        // ...but the recovery strap is set
        wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 4_000_000);
        hrd(CC_SECURITY_BASE + CC_SEC_LIFECYCLE, v);
        check("strap: lifecycle RECOVERY, debug still closed", {v[13], v[12], v[9], v[8], v[3:0]},
              {1'b1, 1'b1, 1'b0, 1'b1, 4'(CC_SB_LC_RECOVERY)});
        check("RECOVERY: EXT boot skipped (no device-memory read)", dm_reads, 0);
        boot_expect("RECOVERY: signed image from the host", img, CC_MBOX_STS_OK, 0);
        // automatic entry: three failed authentications, then a reset
        boot_mode = 2'b00;
        load_hex("build/vectors/bad_magic.hex", qb);
        power_on(CC_SB_LC_CODE_PROD, 0, 0, 0, 1'b0);
        for (int i = 0; i < 3 + rt0; i++) boot_expect("failed attempt", qb, CC_MBOX_STS_BAD_CMD, CC_BOOT_ERR_M_MAGIC);
        hrd(CC_SECURITY_BASE + CC_SEC_BOOT_FAILS, v);
        check("BOOT_FAILS = 3", v, 3);
        host_reset();
        hrd(CC_SECURITY_BASE + CC_SEC_LIFECYCLE, v);
        check("after 3 failures + reset: RECOVERY", v[3:0], CC_SB_LC_RECOVERY);
        boot_expect("RECOVERY: signed image boots", img, CC_MBOX_STS_OK, 0);
        hrd(CC_SECURITY_BASE + CC_SEC_BOOT_FAILS, v);
        check("successful hand-off clears BOOT_FAILS", v, 0);
        host_reset();
        hrd(CC_SECURITY_BASE + CC_SEC_LIFECYCLE, v);
        check("next reset: back to PROD", v[3:0], CC_SB_LC_PROD);
        finish();
  endtask

  task automatic sc_kat_fault();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        bit ok;
        rst_n = 1'b0;
        force u_cc.u_sb.u_sha.u_eng.c_block[0] = 1'b1;     // stuck-at fault in the SHA-256 datapath
        repeat (8) @(posedge clk); rst_n = 1'b1;
        wait (u_cc.u_sb.kat_done);
        release u_cc.u_sb.u_sha.u_eng.c_block[0];
        mbox_wait(4_000_000, ok);
        check("KAT fault: ROM reports", rsp[0][7:0], CC_MBOX_STS_BAD_CMD);
        check("KAT fault: reason CRYPTO_KAT", rsp[1], CC_BOOT_ERR_CRYPTO_KAT);
        sb_status(v);
        check("KAT fault: secure boot LOCKDOWN", v[3:0], CC_SB_STATE_LOCKDOWN);
        check("KAT fault: lockdown pin", 32'(sb_lockdown), 1);
        expect_host_refused("IMEM write in LOCKDOWN (no LOAD state)", 1, CC_IMEM_BASE + 32'h100, 32'h0);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v);
        check("boot stage FATAL", v, CC_BOOT_STAGE_FATAL);
        repeat (200000) @(posedge clk);
        check("KAT fault: execute window never opened", 32'(exec_open_rises), 0);
        finish();
  endtask

  task automatic sc_lc_invalid();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        bit ok;
        power_on(32'h5AA5_0000, 0, 0, 0, 0);
        mbox_wait(4_000_000, ok);
        check("invalid LC: reason LIFECYCLE", rsp[1], CC_BOOT_ERR_LIFECYCLE);
        hrd(CC_SECURITY_BASE + CC_SEC_LIFECYCLE, v);
        check("invalid LC: LC_INVALID, debug closed", {v[14], v[9]}, 2'b10);
        check("invalid LC: execute window never opened", 32'(exec_open_rises), 0);
        finish();
  endtask

  task automatic sc_debug_prod();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        logic [31:0] id, rd, rc0; bit err;
        jtag_idcode(id);
        check("JTAG IDCODE readable", id, {4'h1, sfv_pkg::JTAG_PART, sfv_pkg::JTAG_MFR, 1'b1});
        jtag_sba(0, CC_SYSCTRL_BASE + CC_SYSCTRL_ID, 0, rd, err);
        check("PROD: JTAG system-bus read refused", {31'd0, err}, 1);
        check("PROD: no data returned", rd, 0);
        wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 4_000_000);
        jtag_wr(CC_IMEM_BASE + 32'h100, 32'h1234_5678, err);
        check("PROD: JTAG write to IMEM refused (LOAD state)", {31'd0, err}, 1);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_RESET_COUNT, rc0);
        jtag_dbgctrl(8'b0000_0111);                        // CPU_HOLD + SYS_RESET + BOOT_OVR
        repeat (2000) @(posedge clk);
        hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_RESET_COUNT, v);
        check("PROD: JTAG system reset request ignored", v, rc0);
        boot_expect("PROD: boot with CPU_HOLD requested (ignored)", img, CC_MBOX_STS_OK, 0);
        jtag_dbgctrl(8'h00);
        sb_status(v);
        check("PROD: DEBUG_USED = 0 (nothing reached the bus)", v[16], 0);
        hrd(CC_SECURITY_BASE + CC_SEC_VIOL_STATUS, v);
        check("PROD: debug violations logged", v[4], 1);
        finish();
  endtask

  task automatic sc_debug_dev();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        logic [31:0] rd, len, ent, d [8]; bit err; int refused;
        power_on(CC_SB_LC_CODE_DEV, 32'h0000_0002, 32'h3, 32'h1, 0);   // slot 1 revoked, MIN_SVN 2, rollback enforced
        jtag_sba(0, CC_SYSCTRL_BASE + CC_SYSCTRL_ID, 0, rd, err);
        check("DEV: JTAG system-bus read works", rd, CC_SYSCTRL_ID_RST);
        check("DEV: no error", {31'd0, err}, 0);
        jtag_dbgctrl(8'h01);                                         // hold the CPU: the debugger drives the SBC
        repeat (200) @(posedge clk);
        host_load(img, refused);
        check("DEV: host loads the image in LOAD", refused, 0);
        len = mf(img, 'h34); ent = mf(img, 'h38);
        for (int i = 0; i < 8 + rt0; i++) d[i] = bswap(mf(img, 'h40 + 4 * i));
        for (int t = 0; t < 7 + rt0; t++) begin
          jtag_sb_cmd(CC_SB_CMD_SEAL, err);
          jtag_wr(CC_IMEM_BASE + 32'h100, 32'hBAD, err);
          if (t == 0) check("DEV: even the debugger cannot write the sealed IMEM", {31'd0, err}, 1);
          jtag_wr(CC_SECURITY_BASE + CC_SEC_HASH_BASE, CC_IMEM_BASE + 32'h100, err);
          jtag_wr(CC_SECURITY_BASE + CC_SEC_HASH_LEN, len, err);
          jtag_sb_cmd(CC_SB_CMD_HASH, err);
          repeat (80000) @(posedge clk);
          if (t == 0) for (int i = 0; i < 8 + rt0; i++) begin
            jtag_sba(0, CC_SECURITY_BASE + CC_SEC_DIGEST0 + 32'(4 * i), 0, rd, err);
            check($sformatf("hardware SHA-256 word %0d == manifest digest (hashlib)", i), rd, d[i]);
          end
          for (int i = 0; i < 8 + rt0; i++)
            jtag_wr(CC_SECURITY_BASE + CC_SEC_EXPECT0 + 32'(4 * i), (t == 0) ? 32'h0 : d[i], err);
          if (t != 1) begin
            jtag_wr(CC_SECURITY_BASE + CC_SEC_SIG_TOKEN, (t == 2) ? CC_SB_TOKEN_B : CC_SB_TOKEN_A, err);
            jtag_wr(CC_SECURITY_BASE + CC_SEC_SIG_TOKEN, (t == 2) ? CC_SB_TOKEN_A : CC_SB_TOKEN_B, err);
          end
          jtag_wr(CC_SECURITY_BASE + CC_SEC_ENTRY, (t == 3) ? CC_IMEM_BASE : ent, err);
          jtag_wr(CC_SECURITY_BASE + CC_SEC_KEY_SLOT, (t == 4) ? 1 : 2, err);
          jtag_wr(CC_SECURITY_BASE + CC_SEC_IMAGE_SVN, (t == 5) ? 1 : 2, err);
          jtag_sb_cmd(CC_SB_CMD_HANDOFF, err);
          jtag_sba(0, CC_SECURITY_BASE + CC_SEC_STATUS, 0, rd, err);
          case (t)
            0: check("hand-off refused: EXPECT != measured digest", {rd[31:24], rd[3:0]}, {8'(CC_SB_HREF_DIGEST), 4'(CC_SB_STATE_FAIL)});
            1: check("hand-off refused: no signature tokens", {rd[31:24], rd[3:0]}, {8'(CC_SB_HREF_TOKENS), 4'(CC_SB_STATE_FAIL)});
            2: check("hand-off refused: tokens in the wrong order", {rd[31:24], rd[3:0]}, {8'(CC_SB_HREF_TOKENS), 4'(CC_SB_STATE_FAIL)});
            3: check("hand-off refused: entry outside the measured range", {rd[31:24], rd[3:0]}, {8'(CC_SB_HREF_ENTRY), 4'(CC_SB_STATE_FAIL)});
            4: check("hand-off refused: revoked key slot (fuse model)", {rd[31:24], rd[3:0]}, {8'(CC_SB_HREF_KEY_REVOKED), 4'(CC_SB_STATE_FAIL)});
            5: check("hand-off refused: SVN below MIN_SVN (fuse model)", {rd[31:24], rd[3:0]}, {8'(CC_SB_HREF_ROLLBACK), 4'(CC_SB_STATE_FAIL)});
            default: check("DEV: the debugger CAN open execution without the ROM's signature check (DEV is not secure)",
                           {rd[13], rd[3:0]}, {1'b1, 4'(CC_SB_STATE_PASS)});
          endcase
          if (t < 6) jtag_sb_cmd(CC_SB_CMD_RELOAD, err);
        end
        sb_status(v);
        check("DEV: DEBUG_USED recorded", v[16], 1);
        check("execute window opened once (by the debugger, DEV)", 32'(exec_open_rises), 1);
        finish();
  endtask

  task automatic sc_warm_boot();
    logic [7:0] sts; logic [31:0] code, v; bit e;
        bit ok;
        boot_expect("cold boot", img, CC_MBOX_STS_OK, 0);
        for (int k = 0; k < 2 + rt0; k++) begin
          hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, 32'h8000_0000);    // ST_WDT_RESET: let the watchdog fire
          hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, CC_MBOX_CMD_RUN_SELFTEST);
          hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, CC_MBOX_CMD_RUN_SELFTEST);
          wait (!host_ready);
          $display("[%0d] TB host: watchdog reset (%0d)", cyc, k);
          if (k == 0) begin
            wait_host_ready(30_000_000);
            check("warm boot: firmware saw reset cause WDT", rsp[4], CC_RESET_CAUSE_WDT);
            hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STATUS, v);
            check("warm boot: re-authenticated (BOOT_STATUS warm flag)", v[8], 1);
          end else begin
            repeat (2000) @(posedge clk);
            host_access(1'b1, CC_IMEM_BASE + 32'h800, 32'hE71_C0DE, v, e);    // before the ROM seals
            check("warm boot: host write to the retained image accepted in LOAD", {31'd0, e}, 0);
            mbox_wait(30_000_000, ok);
            check("warm boot with a modified retained image: rejected", rsp[0][7:0], CC_MBOX_STS_BAD_CMD);
            check("  reason DIGEST", rsp[1], CC_BOOT_ERR_DIGEST);
            boot_expect("cold boot after the rejected warm boot", img, CC_MBOX_STS_OK, 0);
          end
        end
        check("execute window opened 3 times (cold, warm, cold)", 32'(exec_open_rises), 3);
        finish();
  endtask

  // ------------------------------------------------------------------ main
  initial begin
    string lcs;
    rt0 = $urandom_range(0, 0);
    if (!$value$plusargs("scenario=%s", scenario)) scenario = "boot_ok";
    if (!$value$plusargs("fw=%s", fw_path)) fw_path = "firmware/build/fw/controlcore_fw.hex";
    if ($value$plusargs("lc=%s", lcs)) fuse_lc = (lcs == "DEV") ? CC_SB_LC_CODE_DEV :
                                                 (lcs == "PROV") ? CC_SB_LC_CODE_PROV : CC_SB_LC_CODE_PROD;
    for (int i = 0; i < DM_WORDS; i++) dmem[i] = 32'h0;
    load_hex(fw_path, img);
    $display("TB scenario %s, image %s (%0d words), fuse LC %08h", scenario, fw_path, img.size(), fuse_lc);
    jtag_reset();
    power_on(fuse_lc, 32'h0, 32'h0, 32'h0, 1'b0);

    case (scenario)
      "boot_ok": sc_boot_ok();
      "vectors": sc_vectors();
      "ext_boot": sc_ext_boot();
      "ext_reject": sc_ext_reject();
      "toctou": sc_toctou();
      "reset_auth": sc_reset_auth();
      "rollback": sc_rollback();
      "revoke": sc_revoke();
      "lifecycle": sc_lifecycle();
      "recovery": sc_recovery();
      "kat_fault": sc_kat_fault();
      "lc_invalid": sc_lc_invalid();
      "debug_prod": sc_debug_prod();
      "debug_dev": sc_debug_dev();
      "warm_boot": sc_warm_boot();
      default: $fatal(1, "unknown scenario %s", scenario);
    endcase
  end
endmodule

`default_nettype wire
