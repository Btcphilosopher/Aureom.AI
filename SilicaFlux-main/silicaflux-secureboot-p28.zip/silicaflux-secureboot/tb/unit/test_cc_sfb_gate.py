"""cc_sfb_gate unit tests: transparent pass-through under random back-pressure, local
refusal (never reaches the slave), no withdrawal of a presented request, idle."""
import random

import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, Timer

from ccutil import cycles, start


class Slave:
    """SFB2 slave on the m_* side: random ready, random latency, memory."""
    def __init__(self, dut, seed):
        self.dut, self.mem, self.rng, self.seen = dut, {}, random.Random(seed), []
        self.withdrawn = False

    async def run(self):
        """Sample handshakes mid-cycle (they complete at the next rising edge),
        apply their effects right after that edge."""
        d = self.dut
        d.m_req_ready.value = 0
        d.m_rsp_valid.value = 0
        pend, presented = None, False
        while True:
            await FallingEdge(d.clk)
            await Timer(1, units="ns")
            v, r = int(d.m_req_valid.value), int(d.m_req_ready.value)
            rv, rr = int(d.m_rsp_valid.value), int(d.m_rsp_ready.value)
            if presented and not v:
                self.withdrawn = True
            presented = bool(v and not r)
            if v and r:
                a, w, wd = int(d.m_req_addr.value), int(d.m_req_write.value), int(d.m_req_wdata.value)
            await RisingEdge(d.clk)
            if rv and rr:
                d.m_rsp_valid.value = 0
                rv = 0
            if v and r:
                self.seen.append((a, w))
                if w:
                    self.mem[a] = wd
                pend = [self.rng.randint(1, 3), 0 if w else self.mem.get(a, 0)]
            if pend is not None and not rv:
                pend[0] -= 1
                if pend[0] <= 0:
                    d.m_rsp_valid.value = 1
                    d.m_rsp_rdata.value = pend[1]
                    d.m_rsp_error.value = 0
                    pend = None
            d.m_req_ready.value = 1 if (pend is None and not (v and r) and self.rng.random() < 0.6) else 0


async def access(dut, write, addr, data=0):
    await FallingEdge(dut.clk)
    dut.s_req_valid.value = 1
    dut.s_req_write.value = write
    dut.s_req_addr.value = addr
    dut.s_req_wdata.value = data
    dut.s_req_wstrb.value = 0xF
    await Timer(1, units="ns")
    while not int(dut.s_req_ready.value):
        await FallingEdge(dut.clk)
        await Timer(1, units="ns")
    await RisingEdge(dut.clk)
    await Timer(1, units="ns")
    dut.s_req_valid.value = 0
    while not int(dut.s_rsp_valid.value):
        await FallingEdge(dut.clk)
        await Timer(1, units="ns")
    r = (int(dut.s_rsp_rdata.value), int(dut.s_rsp_error.value))
    await RisingEdge(dut.clk)
    return r


def init(dut):
    for s in ("s_req_valid", "s_req_write", "s_req_addr", "s_req_wdata", "s_req_wstrb", "refuse", "m_rsp_rdata",
              "m_rsp_error"):
        getattr(dut, s).value = 0
    dut.s_rsp_ready.value = 1


@cocotb.test(timeout_time=2, timeout_unit="ms")
async def pass_through_random(dut):
    init(dut)
    await start(dut)
    sl = Slave(dut, 1)
    cocotb.start_soon(sl.run())
    rng = random.Random(5)
    ref = {}
    for i in range(300):
        a = rng.randrange(0, 64) * 4
        if rng.random() < 0.5:
            v = rng.getrandbits(32)
            assert await access(dut, 1, a, v) == (0, 0)
            ref[a] = v
        else:
            d, e = await access(dut, 0, a)
            assert e == 0 and d == ref.get(a, 0), (hex(a), hex(d))
    assert not sl.withdrawn
    await cycles(dut, 5)
    assert int(dut.idle.value) == 1


@cocotb.test(timeout_time=2, timeout_unit="ms")
async def refusal(dut):
    init(dut)
    await start(dut)
    sl = Slave(dut, 2)
    cocotb.start_soon(sl.run())
    dut.refuse.value = 1
    n0 = len(sl.seen)
    for i in range(20):
        d, e = await access(dut, i & 1, 0x100 + 4 * i, 0x55)
        assert e == 1 and d == 0
    assert len(sl.seen) == n0, "a refused request reached the slave"
    dut.refuse.value = 0
    assert (await access(dut, 1, 0x40, 7))[1] == 0
    assert await access(dut, 0, 0x40) == (7, 0)


@cocotb.test(timeout_time=2, timeout_unit="ms")
async def no_withdrawal_when_refuse_rises(dut):
    init(dut)
    await start(dut)
    sl = Slave(dut, 3)
    cocotb.start_soon(sl.run())
    rng = random.Random(9)

    async def toggler():
        while True:
            await FallingEdge(dut.clk)
            dut.refuse.value = 1 if rng.random() < 0.3 else 0
    t = cocotb.start_soon(toggler())
    for i in range(200):
        await access(dut, i & 1, (i % 16) * 4, i)
    t.kill()
    assert not sl.withdrawn, "a presented request was withdrawn"
