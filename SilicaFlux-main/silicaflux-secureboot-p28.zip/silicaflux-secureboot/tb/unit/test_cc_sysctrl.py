"""cc_sysctrl unit tests: identity, read-only refusal, reset generator (soft / WDT / host),
reset-cause and scratch retention in the POR domain, status pins."""
import cocotb
from cocotb.triggers import FallingEdge, RisingEdge

from ccutil import M, cycles, rd, start, wr


def idle(dut):
    for s in ("rb_sel", "rb_we", "rb_addr", "rb_wdata", "boot_mode", "wdt_req", "host_rst_req"):
        getattr(dut, s).value = 0


async def reset_follower(dut, log):
    """Emulates the top level: sys_reset_req holds the SYS domain in reset."""
    n = 0
    while True:
        await RisingEdge(dut.clk)
        if int(dut.sys_reset_req.value):
            dut.rst_n.value = 0
            n += 1
        elif n:
            log.append(n)
            n = 0
            dut.rst_n.value = 1


async def boot(dut):
    idle(dut)
    dut.por_rst_n.value = 0
    await start(dut, rst=("por_rst_n", "rst_n"))


@cocotb.test()
async def identity_and_refusals(dut):
    await boot(dut)
    assert await rd(dut, M.CC_SYSCTRL_ID) == M.CC_SYSCTRL_ID_RST
    assert await rd(dut, M.CC_SYSCTRL_MAP_VERSION) == M.CC_MAP_VERSION
    assert await rd(dut, M.CC_SYSCTRL_RESET_CAUSE) == M.CC_RESET_CAUSE_POR
    await wr(dut, M.CC_SYSCTRL_ID, 0, expect_err=1)
    await wr(dut, M.CC_SYSCTRL_SOFT_RESET, 0x12345678, expect_err=1)   # wrong key refused, no reset
    assert int(dut.sys_reset_req.value) == 0
    await wr(dut, 0xFFC, 0, expect_err=1)


@cocotb.test()
async def status_pins_and_boot_mode(dut):
    await boot(dut)
    dut.boot_mode.value = 1
    assert await rd(dut, M.CC_SYSCTRL_BOOT_MODE) == 1
    await wr(dut, M.CC_SYSCTRL_HOST_STATUS, 3)
    assert int(dut.host_ready.value) == 1 and int(dut.cmdproc_ready.value) == 1
    await wr(dut, M.CC_SYSCTRL_TEST_CTRL, 0xC000BEEF)
    assert int(dut.test_done.value) == 1 and int(dut.test_fail.value) == 1 and int(dut.test_code.value) == 0xBEEF


@cocotb.test()
async def reset_generator(dut):
    await boot(dut)
    log = []
    cocotb.start_soon(reset_follower(dut, log))
    await wr(dut, M.CC_SYSCTRL_SCRATCH0, 0xCAFE0001)
    await wr(dut, M.CC_SYSCTRL_BOOT_STAGE, 0x42)
    await wr(dut, M.CC_SYSCTRL_RESET_CAUSE, 0xF)                   # W1C POR
    await wr(dut, M.CC_SYSCTRL_SOFT_RESET, M.CC_SOFT_RESET_KEY)
    await cycles(dut, 40)
    assert log == [M.CC_RESET_STRETCH], log                        # stretched pulse
    assert await rd(dut, M.CC_SYSCTRL_RESET_CAUSE) == M.CC_RESET_CAUSE_SOFT
    assert await rd(dut, M.CC_SYSCTRL_SCRATCH0) == 0xCAFE0001       # POR domain kept
    assert await rd(dut, M.CC_SYSCTRL_BOOT_STAGE) == 0              # SYS domain cleared
    assert await rd(dut, M.CC_SYSCTRL_RESET_COUNT) == 1
    # watchdog request (level, cleared by the reset it causes)
    await wr(dut, M.CC_SYSCTRL_RESET_CAUSE, 0xF)
    await FallingEdge(dut.clk)
    dut.wdt_req.value = 1
    await RisingEdge(dut.clk)
    await FallingEdge(dut.clk)
    dut.wdt_req.value = 0
    await cycles(dut, 40)
    assert await rd(dut, M.CC_SYSCTRL_RESET_CAUSE) == M.CC_RESET_CAUSE_WDT
    # host request: edge-triggered, a long level causes ONE reset
    await wr(dut, M.CC_SYSCTRL_RESET_CAUSE, 0xF)
    await FallingEdge(dut.clk)
    dut.host_rst_req.value = 1
    await cycles(dut, 100)
    dut.host_rst_req.value = 0
    await cycles(dut, 5)
    assert await rd(dut, M.CC_SYSCTRL_RESET_CAUSE) == M.CC_RESET_CAUSE_HOST
    assert await rd(dut, M.CC_SYSCTRL_RESET_COUNT) == 3
    assert len(log) == 3
