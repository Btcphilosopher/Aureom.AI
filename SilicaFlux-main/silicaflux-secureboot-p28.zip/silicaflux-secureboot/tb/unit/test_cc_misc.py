"""Unit tests of cc_pmu, cc_perf and cc_secmon (selected by the TOPLEVEL)."""
import os

import cocotb
from cocotb.triggers import FallingEdge, RisingEdge

from ccutil import M, cycles, rd, start, wr

TOP = os.environ.get("TOPLEVEL", "")


def zero(dut, names):
    for s in names:
        getattr(dut, s).value = 0


# ------------------------------------------------------------------ cc_pmu
@cocotb.test(skip=TOP != "cc_pmu")
async def pmu_clock_gating_waits_for_idle(dut):
    zero(dut, ("rb_sel", "rb_we", "rb_addr", "rb_wdata", "cpu_sleep", "vec_busy", "tsu_busy", "tsu_halted",
               "fatal_iso", "acc_in_reset"))
    dut.ext_idle.value = 1
    await start(dut)
    assert int(dut.acc_clk_en.value) == 1 and int(dut.acc_iso.value) == 0
    await FallingEdge(dut.clk)
    dut.tsu_busy.value = 1
    await wr(dut, M.CC_PMU_ACC_CTRL, 0)                           # request clock off while busy
    await cycles(dut, 5)
    assert int(dut.acc_clk_en.value) == 1                          # keeps running
    assert int(dut.acc_iso.value) == 1                             # but no new access is allowed
    st = await rd(dut, M.CC_PMU_ACC_STATUS)
    assert st & 0x80, hex(st)                                      # CLK_OFF_PENDING
    dut.tsu_busy.value = 0
    await cycles(dut, 3)
    assert int(dut.acc_clk_en.value) == 0
    g0 = await rd(dut, M.CC_PMU_GATED_CYC)
    await cycles(dut, 20)
    assert await rd(dut, M.CC_PMU_GATED_CYC) >= g0 + 20
    await wr(dut, M.CC_PMU_ACC_CTRL, 1)
    await cycles(dut, 2)
    assert int(dut.acc_clk_en.value) == 1 and int(dut.acc_iso.value) == 0


@cocotb.test(skip=TOP != "cc_pmu")
async def pmu_reset_waits_for_ext_idle(dut):
    zero(dut, ("rb_sel", "rb_we", "rb_addr", "rb_wdata", "cpu_sleep", "vec_busy", "tsu_busy", "tsu_halted",
               "fatal_iso", "acc_in_reset"))
    dut.ext_idle.value = 0                                         # a transaction is outstanding
    await start(dut)
    await wr(dut, M.CC_PMU_ACC_CTRL, 0x3)
    await cycles(dut, 5)
    assert int(dut.acc_rst_req.value) == 0 and int(dut.acc_iso.value) == 1
    dut.ext_idle.value = 1
    await cycles(dut, 2)
    assert int(dut.acc_rst_req.value) == 1
    await wr(dut, M.CC_PMU_ACC_CTRL, 0x1)
    await cycles(dut, 1)
    assert int(dut.acc_rst_req.value) == 0
    await FallingEdge(dut.clk)
    dut.fatal_iso.value = 1
    await cycles(dut, 1)
    assert int(dut.acc_iso.value) == 1                             # RAS fatal isolation
    await wr(dut, M.CC_PMU_INFO, 0, expect_err=1)


# ------------------------------------------------------------------ cc_perf
@cocotb.test(skip=TOP != "cc_perf")
async def perf_counting_freeze_clear_edge(dut):
    zero(dut, ("rb_sel", "rb_we", "rb_addr", "rb_wdata", "ev"))
    await start(dut)
    assert await rd(dut, M.CC_PERF_INFO) == 20
    await FallingEdge(dut.clk)
    dut.ev.value = (1 << 0) | (1 << 8)                             # 0: level count, 8: edge count (IRQ_EXT)
    await cycles(dut, 10)
    await FallingEdge(dut.clk)
    dut.ev.value = 0
    c0 = await rd(dut, M.CC_PERF_CNT0 + 0)
    c8 = await rd(dut, M.CC_PERF_CNT0 + 4 * 8)
    assert c0 == 10 and c8 == 1, (c0, c8)
    await wr(dut, M.CC_PERF_CTRL, 1)                               # freeze
    lo = await rd(dut, M.CC_PERF_CYCLE_LO)
    dut.ev.value = 1
    await cycles(dut, 5)
    assert await rd(dut, M.CC_PERF_CYCLE_LO) == lo
    assert await rd(dut, M.CC_PERF_CNT0) == 10
    await wr(dut, M.CC_PERF_CTRL, 2)                               # clear (unfreezes: FREEZE = 0)
    dut.ev.value = 0
    assert await rd(dut, M.CC_PERF_CNT0) == 0
    await wr(dut, M.CC_PERF_CNT0, 0, expect_err=1)
    await wr(dut, M.CC_PERF_CNT0 + 4 * 20, 0, expect_err=1)        # beyond NEV: unmapped


# ------------------------------------------------------------------ cc_secmon
@cocotb.test(skip=TOP != "cc_secmon")
async def secmon_honest_status_lock_measure(dut):
    zero(dut, ("rb_sel", "rb_we", "rb_addr", "rb_wdata", "viol_evt", "viol_addr"))
    await start(dut)
    caps = await rd(dut, M.CC_SEC_CAPS)
    assert caps & 0xF == 0, "authentication / secure boot / RoT / debug must read as absent"
    assert caps & 0x70 == 0x70
    assert await rd(dut, M.CC_SEC_AUTH_HOOK) == 0
    await wr(dut, M.CC_SEC_CTRL, 1)
    await wr(dut, M.CC_SEC_CTRL, 0)                                # set-only
    assert int(dut.host_lock.value) == 1
    await wr(dut, M.CC_SEC_BOOT_MEASURE, 0x12345678)
    await wr(dut, M.CC_SEC_BOOT_MEASURE, 0x0, expect_err=1)        # write-once
    assert await rd(dut, M.CC_SEC_BOOT_MEASURE) == 0x12345678
    st = await rd(dut, M.CC_SEC_STATUS)
    assert st == 0x3, hex(st)                                      # LOCK, MEASURED, AUTH_STATE 0
    await FallingEdge(dut.clk)
    dut.viol_evt.value = 1
    dut.viol_addr.value = 0x00010040
    await RisingEdge(dut.clk)
    await FallingEdge(dut.clk)
    dut.viol_evt.value = 0
    assert (await rd(dut, M.CC_SEC_STATUS)) >> 8 & 1
    assert await rd(dut, M.CC_SEC_VIOL_ADDR) == 0x00010040
    assert await rd(dut, M.CC_SEC_VIOL_COUNT) == 1
    await wr(dut, M.CC_SEC_CLEAR, 1)
    assert not (await rd(dut, M.CC_SEC_STATUS)) >> 8 & 1
