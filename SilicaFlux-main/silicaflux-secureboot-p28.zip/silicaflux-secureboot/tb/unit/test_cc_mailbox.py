"""cc_mailbox unit tests: message registers, doorbells, interrupts, console FIFO."""
import cocotb

from ccutil import M, rd, start, wr


def idle(dut):
    dut.rb_sel.value = 0
    dut.rb_we.value = 0
    dut.rb_addr.value = 0
    dut.rb_wdata.value = 0


@cocotb.test()
async def messages_and_doorbells(dut):
    idle(dut)
    await start(dut)
    for i in range(8):
        await wr(dut, M.CC_MBOX_H2F_MSG0 + 4 * i, 0x1000 + i)
        await wr(dut, M.CC_MBOX_F2H_MSG0 + 4 * i, 0x2000 + i)
    for i in range(8):
        assert await rd(dut, M.CC_MBOX_H2F_MSG0 + 4 * i) == 0x1000 + i
        assert await rd(dut, M.CC_MBOX_F2H_MSG0 + 4 * i) == 0x2000 + i
    assert int(dut.irq_h2f.value) == 0 and int(dut.host_irq.value) == 0
    await wr(dut, M.CC_MBOX_H2F_RING, 0x11)
    assert int(dut.irq_h2f.value) == 1
    assert await rd(dut, M.CC_MBOX_H2F_CODE) == 0x11
    await wr(dut, M.CC_MBOX_F2H_RING, 0x22)
    assert int(dut.host_irq.value) == 1
    assert await rd(dut, M.CC_MBOX_DB_STATUS) == 3
    await wr(dut, M.CC_MBOX_H2F_ACK, 0)
    await wr(dut, M.CC_MBOX_F2H_ACK, 0)
    assert await rd(dut, M.CC_MBOX_DB_STATUS) == 0
    assert await rd(dut, M.CC_MBOX_RING_COUNT) == 0x00010001
    await wr(dut, M.CC_MBOX_DB_STATUS, 1, expect_err=1)
    await wr(dut, 0x400, 1, expect_err=1)


@cocotb.test()
async def console_fifo(dut):
    idle(dut)
    await start(dut)
    assert await rd(dut, M.CC_MBOX_DIAG_RX) == 0                   # empty: VALID = 0
    for i in range(260):                                           # 4 more than the FIFO holds
        await wr(dut, M.CC_MBOX_DIAG_TX, i & 0xFF)
    st = await rd(dut, M.CC_MBOX_DIAG_STATUS)
    assert st & 0x1FF == 256 and (st >> 16) & 1 == 1, hex(st)
    for i in range(4):
        v = await rd(dut, M.CC_MBOX_DIAG_RX)
        assert v == 0x100 | i, hex(v)                             # oldest kept, newest dropped
        assert await rd(dut, M.CC_MBOX_DIAG_RX) == v               # reads have no side effect
        await wr(dut, M.CC_MBOX_DIAG_POP, 0)
    await wr(dut, M.CC_MBOX_DIAG_STATUS, 1 << 16)                  # clear OVF
    assert await rd(dut, M.CC_MBOX_DIAG_STATUS) == 252
