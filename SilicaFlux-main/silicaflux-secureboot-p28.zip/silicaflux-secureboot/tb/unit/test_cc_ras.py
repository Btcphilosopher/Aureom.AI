"""cc_ras unit tests: sources, severity, W1C, level sources, counters, first/last, injection, parity controls."""
import cocotb
from cocotb.triggers import FallingEdge, RisingEdge

from ccutil import M, cycles, rd, start, wr


def idle(dut):
    for s in ("rb_sel", "rb_we", "ev_bus_decode", "ev_periph_err", "ev_dma_err", "ev_host_viol", "ev_iso_access",
              "ev_parity", "lv_ext_warn", "lv_ext_fatal", "lv_tsu_halted", "mem_write"):
        getattr(dut, s).value = 0
    for s in ("rb_addr", "rb_wdata", "ev_bus_decode_addr", "ev_periph_err_addr", "ev_host_viol_addr", "ev_parity_addr"):
        getattr(dut, s).value = 0


async def pulse(dut, sig, addr_sig=None, addr=0):
    await FallingEdge(dut.clk)
    getattr(dut, sig).value = 1
    if addr_sig:
        getattr(dut, addr_sig).value = addr
    await RisingEdge(dut.clk)
    await FallingEdge(dut.clk)
    getattr(dut, sig).value = 0


@cocotb.test()
async def reset_state(dut):
    idle(dut)
    await start(dut)
    assert await rd(dut, M.CC_RAS_STATUS) == 0
    assert await rd(dut, M.CC_RAS_CTRL) == 1            # FATAL_TO_HOST by default
    assert int(dut.irq_warn.value) == 0 and int(dut.irq_fatal.value) == 0
    await wr(dut, M.CC_RAS_WARN_COUNT, 1, expect_err=1)  # read-only
    await wr(dut, 0x200, 1, expect_err=1)                # unmapped


@cocotb.test()
async def pulse_sources_and_first_last(dut):
    idle(dut)
    await start(dut)
    await wr(dut, M.CC_RAS_WARN_EN, 0xFF)
    await wr(dut, M.CC_RAS_FATAL_EN, 0x0F)
    await pulse(dut, "ev_bus_decode", "ev_bus_decode_addr", 0x50000000)
    await cycles(dut, 1)
    assert int(dut.irq_warn.value) == 1
    assert await rd(dut, M.CC_RAS_STATUS) == 1 << M.CC_RAS_SRC_BUS_DECODE
    assert await rd(dut, M.CC_RAS_FIRST_SRC) == 0x80000000 | M.CC_RAS_SRC_BUS_DECODE
    assert await rd(dut, M.CC_RAS_FIRST_ADDR) == 0x50000000
    await pulse(dut, "ev_parity", "ev_parity_addr", 0x00020040)
    await cycles(dut, 1)
    assert int(dut.irq_fatal.value) == 1 and int(dut.fatal_pin.value) == 1
    assert await rd(dut, M.CC_RAS_LAST_SRC) == 0x80000000 | M.CC_RAS_SRC_MEM_PARITY
    assert await rd(dut, M.CC_RAS_LAST_ADDR) == 0x00020040
    assert await rd(dut, M.CC_RAS_FIRST_ADDR) == 0x50000000      # first is kept
    assert await rd(dut, M.CC_RAS_WARN_COUNT) == 1
    assert await rd(dut, M.CC_RAS_FATAL_COUNT) == 1
    await wr(dut, M.CC_RAS_STATUS, 0xFFFF)                        # W1C
    assert await rd(dut, M.CC_RAS_STATUS) == 0
    assert int(dut.irq_warn.value) == 0 and int(dut.irq_fatal.value) == 0 and int(dut.fatal_pin.value) == 0
    await wr(dut, M.CC_RAS_CTRL, 0x1 | 0x4 | 0x8)                 # clear FIRST and counters
    assert await rd(dut, M.CC_RAS_FIRST_SRC) == 0
    assert await rd(dut, M.CC_RAS_WARN_COUNT) == 0


@cocotb.test()
async def masking(dut):
    idle(dut)
    await start(dut)
    await pulse(dut, "ev_dma_err")
    await cycles(dut, 1)
    assert await rd(dut, M.CC_RAS_STATUS) == 1 << M.CC_RAS_SRC_DMA_ERR
    assert int(dut.irq_warn.value) == 0                           # not enabled
    await wr(dut, M.CC_RAS_WARN_EN, 1 << M.CC_RAS_SRC_DMA_ERR)
    assert int(dut.irq_warn.value) == 1


@cocotb.test()
async def level_sources(dut):
    idle(dut)
    await start(dut)
    await FallingEdge(dut.clk)
    dut.lv_tsu_halted.value = 1
    await cycles(dut, 5)
    bit = 1 << M.CC_RAS_SRC_TSU_HALTED
    await wr(dut, M.CC_RAS_STATUS, bit)                            # W1C while still active
    assert await rd(dut, M.CC_RAS_STATUS) & bit                    # re-set by the level
    assert await rd(dut, M.CC_RAS_FATAL_COUNT) == 1                # counted once (rising edge)
    assert await rd(dut, M.CC_RAS_RAW) == 4
    dut.lv_tsu_halted.value = 0
    await cycles(dut, 2)
    await wr(dut, M.CC_RAS_STATUS, bit)
    assert await rd(dut, M.CC_RAS_STATUS) == 0


@cocotb.test()
async def inject_and_sw_report(dut):
    idle(dut)
    await start(dut)
    await wr(dut, M.CC_RAS_INJECT, 0xFFFF)                         # only defined sources are raised
    assert await rd(dut, M.CC_RAS_STATUS) == 0x0F7F
    assert await rd(dut, M.CC_RAS_WARN_COUNT) == 7
    assert await rd(dut, M.CC_RAS_FATAL_COUNT) == 4
    await wr(dut, M.CC_RAS_STATUS, 0xFFFF)
    await wr(dut, M.CC_RAS_SW_REPORT, 0x80000000 | 0x1234)
    assert await rd(dut, M.CC_RAS_STATUS) == 1 << M.CC_RAS_SRC_SW_FATAL
    assert await rd(dut, M.CC_RAS_SW_CODE) == 0x1234
    await wr(dut, M.CC_RAS_SW_REPORT, 0x55)
    assert await rd(dut, M.CC_RAS_STATUS) & (1 << M.CC_RAS_SRC_SW_WARN)


@cocotb.test()
async def fatal_isolate_and_parity_controls(dut):
    idle(dut)
    await start(dut)
    await wr(dut, M.CC_RAS_CTRL, 0x2)                              # FATAL_ISOLATE, no pin
    await wr(dut, M.CC_RAS_INJECT, 1 << M.CC_RAS_SRC_EXT_FATAL)
    assert int(dut.fatal_iso.value) == 1 and int(dut.fatal_pin.value) == 0
    await wr(dut, M.CC_RAS_PAR_INJECT, 1)
    assert int(dut.par_inject.value) == 1
    await FallingEdge(dut.clk)
    dut.mem_write.value = 1                                        # first IMEM/DMEM write consumes it
    await RisingEdge(dut.clk)
    await FallingEdge(dut.clk)
    dut.mem_write.value = 0
    assert int(dut.par_inject.value) == 0
    await wr(dut, M.CC_RAS_PAR_CHK_EN, 1)
    assert int(dut.par_chk_en.value) == 1
