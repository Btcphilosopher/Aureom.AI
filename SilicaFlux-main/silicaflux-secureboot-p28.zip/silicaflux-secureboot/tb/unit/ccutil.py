"""Shared helpers for the ControlCore cocotb unit tests."""
import os
import sys

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, RisingEdge, Timer

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "generated"))
import cc_memmap as M  # noqa: E402,F401


async def start(dut, rst=("rst_n",), cycles=3):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    for r in rst:
        getattr(dut, r).value = 0
    for _ in range(cycles):
        await RisingEdge(dut.clk)
    for r in rst:
        getattr(dut, r).value = 1
    await RisingEdge(dut.clk)


async def rb(dut, addr, wdata=None):
    """One SilicaFlux-V register-bus access: strobe for one cycle, sample the
    combinational rdata/err mid-cycle, side effect at the rising edge."""
    await FallingEdge(dut.clk)
    dut.rb_sel.value = 1
    dut.rb_we.value = 0 if wdata is None else 1
    dut.rb_addr.value = addr
    dut.rb_wdata.value = 0 if wdata is None else wdata
    await Timer(1, units="ns")
    rd, err = int(dut.rb_rdata.value), int(dut.rb_err.value)
    await RisingEdge(dut.clk)
    dut.rb_sel.value = 0
    dut.rb_we.value = 0
    await Timer(1, units="ns")          # let the edge's register updates settle before the caller samples
    return rd, err


async def rd(dut, addr):
    v, e = await rb(dut, addr)
    assert e == 0, f"read 0x{addr:03x} refused"
    return v


async def wr(dut, addr, v, expect_err=0):
    _, e = await rb(dut, addr, v)
    assert e == expect_err, f"write 0x{addr:03x}=0x{v:08x}: err {e}, expected {expect_err}"


async def cycles(dut, n):
    for _ in range(n):
        await RisingEdge(dut.clk)
    await Timer(1, units="ns")          # sample after the last edge's updates
