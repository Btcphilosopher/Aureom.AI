#!/usr/bin/env python3
"""Collect the FPGA tool outputs (fpga/build/) into reports/fpga.md."""
import os
import re
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, "fpga", "build")


def read(name):
    p = os.path.join(B, name)
    return open(p, errors="replace").read() if os.path.exists(p) else ""


def cells(txt, names=("LUT4", "TRELLIS_FF", "CCU2C", "PFUMX", "L6MUX21", "TRELLIS_DPR16X4", "DP16KD", "MULT18X18D")):
    tot = txt.split("=== design hierarchy ===")[-1] if "design hierarchy" in txt else txt
    out = {}
    for n in names:
        m = re.findall(rf"\b{n}\s+(\d+)", tot)
        out[n] = int(m[-1]) if m else 0
    return out


def main():
    ys, pnr, hier, sysst = read("yosys_stat.txt"), read("nextpnr.log"), read("yosys_stat_hier.txt"), read("yosys_stat_system.txt")
    md = ["# FPGA implementation (ControlCore harness, ULX3S LFE5U-85F-CABGA381)", "",
          "Tool outputs in `fpga/build/` (regenerate: `make fpga`). **No hardware run**: the bitstream has never been "
          "loaded on a board. Timing is nextpnr's post-route estimate for one seed.", ""]
    ver = [subprocess.run(c, shell=True, capture_output=True, text=True).stdout.strip().splitlines()[0]
           for c in ("yosys -V", "nextpnr-ecp5 --version 2>&1")]
    md += [f"Tools: {ver[0]}; {ver[1]}.", ""]
    c = cells(ys)
    md += ["## Synthesis (Yosys `synth_ecp5`, flattened, harness included)", "", "| Cell | Count |", "|---|---|"]
    md += [f"| {k} | {v} |" for k, v in c.items()]
    util = re.findall(r"^Info:\s+(TRELLIS_COMB|TRELLIS_FF|DP16KD|MULT18X18D|TRELLIS_RAMW|TRELLIS_IO|DCCA):\s+(\d+)/\s*(\d+)\s+(\d+)%",
                      pnr, re.M)
    fmax = re.findall(r"Max frequency for clock '[^']+': ([\d.]+) MHz \((PASS|FAIL) at ([\d.]+) MHz\)", pnr)
    md += ["", "## Place and route (nextpnr-ecp5 0.6, `--85k --package CABGA381 --freq 25 --seed 1`)", "",
           "| Resource | Used | Available | % |", "|---|---|---|---|"]
    md += [f"| {a} | {b} | {cc} | {d} % |" for a, b, cc, d in util]
    if fmax:
        f, res, tgt = fmax[-1]
        md += ["", f"**Post-route maximum frequency estimate: {f} MHz -- {res} at the {tgt} MHz constraint** "
               f"(placement-stage estimate {fmax[0][0]} MHz).", ""]
        md += ["Critical register-to-register path (post-route report in `fpga/build/nextpnr.log`): IMEM block-RAM "
               "read data -> byte-parity check (`mcu_sram_bank`) -> crossbar response routing -> CPU fetch / "
               "interrupt-entry decision -> crossbar request decode. Logic depth is low; most of the delay is routing.", ""]
    bit = read("cc_fpga.bit.sha256").split()
    if bit:
        md += [f"Bitstream `fpga/build/cc_fpga.bit` SHA-256 `{bit[0]}`.", ""]
    rows = []
    for blk in re.split(r"\n=== ", hier)[1:]:
        name = blk.split(" ===")[0]
        m = re.search(r"\\([A-Za-z0-9_]+)$", name) or re.search(r"([A-Za-z0-9_]+)", name)
        short = m.group(1) if m else name
        lut = re.search(r"LUT4\s+(\d+)", blk)
        ff = re.search(r"TRELLIS_FF\s+(\d+)", blk)
        br = re.search(r"DP16KD\s+(\d+)", blk)
        if name.startswith("design hierarchy") or not (lut or ff):
            continue
        rows.append((short, int(lut.group(1)) if lut else 0, int(ff.group(1)) if ff else 0, int(br.group(1)) if br else 0))
    if rows:
        agg = {}
        for n, l, f, b in rows:
            n = re.sub(r"^\$paramod.*\\", "", n)
            a = agg.setdefault(n, [0, 0, 0])
            a[0] += l; a[1] += f; a[2] += b
        md += ["## Per-module breakdown (Yosys `-noflatten`; totals exceed the flattened run: no cross-boundary "
               "optimisation)", "", "| Module (one instance) | LUT4 | FF | DP16KD |", "|---|---|---|---|"]
        for n, (l, f, b) in sorted(agg.items(), key=lambda x: -x[1][0])[:22]:
            md.append(f"| `{n}` | {l} | {f} | {b} |")
        md += ["", "Area notes: `mcu_cpu` (RV32IM, iterative M unit, no DSP) is the largest block. `cc_perf` "
               "(20 x 32-bit saturating counters + 64-bit cycle counter with freeze/clear and a 22-way read mux) is the "
               "largest NEW block; reducing the event count or dropping saturation would shrink it. The boot ROM is "
               "synthesised as logic (`sfv_bootrom_image`, 522 words). Block RAM: IMEM 64 KiB and DMEM 32 KiB with "
               "byte parity (36-bit words) = 48 DP16KD; the harness device memory adds 32.", ""]
    if sysst:
        s = cells(sysst)
        md += ["## Full system resource estimate (ControlCore + vector tile + tensor unit, Yosys only, no P&R)", "",
               "| Cell | Count |", "|---|---|"] + [f"| {k} | {v} |" for k, v in s.items()]
        comb = s["LUT4"] + 2 * s["CCU2C"]
        md += ["", f"Logic-cell estimate: LUT4 + 2 x CCU2C = **{comb}** TRELLIS_COMB-equivalent cells "
               f"(+ {s['TRELLIS_DPR16X4']} distributed-RAM cells) against **83 640** on the LFE5U-85F: the complete "
               "system (ControlCore + FP32 vector tile + INT8 tensor unit with quantisation and double buffering) "
               "**does not fit the largest ECP5** and was therefore not placed and routed. The ControlCore itself "
               "is about 15 % of it; the accelerator projects document their own separate ECP5 builds. A system "
               "prototype needs a larger FPGA (or a reduced accelerator configuration).", ""]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "fpga.md"), "w").write("\n".join(md) + "\n")
    print("fpga_report: reports/fpga.md written")


if __name__ == "__main__":
    main()
