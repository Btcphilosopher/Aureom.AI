#!/usr/bin/env bash
# Package the ControlCore project as a zip: sources, generated files, firmware images, bitstream, reports.
# Excluded: simulator build trees (build/, tb/unit/sim_build), fetched dependencies (deps/: riscv-tests is
# fetched by scripts/run_riscv_tests.sh), large intermediate FPGA netlists (cc_fpga.json, cc_fpga.config).
# usage: scripts/package.sh <output.zip>
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
NAME=$(basename "$ROOT")
cd "$ROOT/.."
rm -f "$OUT"
zip -q -r "$OUT" "$NAME" \
  -x "$NAME/build/*" "$NAME/deps/*" "$NAME/tb/unit/sim_build/*" "$NAME/*__pycache__*" "$NAME/*.pyc" \
     "$NAME/fpga/build/cc_fpga.json" "$NAME/fpga/build/cc_fpga.config" "$NAME/tb/unit/results.xml" \
     "$NAME/firmware/build/fw/*.payload.bin"
echo "package: $OUT ($(du -h "$OUT" | cut -f1), $(unzip -l "$OUT" | tail -1 | awk '{print $2}') files)"
