// =============================================================================
// SilicaFlux ControlCore :: tb_fpga_top -- RTL simulation of the FPGA harness
// (fpga/cc_fpga_top.sv) exactly as synthesised: FPGA SRAM backend, block RAM
// device memory initialised by $readmemh, boot mode EXT, no host, accelerators
// absent.  Passes when the firmware reaches HOST_READY (led[1]) and the console
// UART has transmitted the boot banner.  This is NOT a hardware test.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_fpga_top;
  logic clk = 1'b0;
  always #20 clk = ~clk;                       // 25 MHz
  logic [7:0] led;
  logic txd, wifi;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  cc_fpga_top #(.INIT_FILE("fpga/build/controlcore_fw.hex")) dut (
    .clk_25mhz(clk), .btn(1'b1), .ftdi_rxd(txd), .led, .wifi_gpio0(wifi));

  // UART receiver model (115200 8N1 at 25 MHz = 217 clocks / bit)
  string line = "";
  int nchar = 0;
  initial begin
    forever begin
      @(negedge txd);
      repeat (108) @(posedge clk);             // middle of the start bit
      begin
        logic [7:0] b;
        for (int i = 0; i < 8; i++) begin repeat (217) @(posedge clk); b[i] = txd; end
        repeat (217) @(posedge clk);
        nchar++;
        if (b == 8'h0A) begin $display("[%0d] UART| %s", cyc, line); line = ""; end
        else line = {line, string'(b)};
      end
    end
  end

  initial begin
    wait (led[1] === 1'b1);                    // host_ready
    $display("[%0d] FPGA harness: HOST_READY (led[1]) reached", cyc);
    repeat (400000) @(posedge clk);            // let the UART drain the banner
    if (nchar > 100) begin
      $display("TB_FPGA RESULT PASS cycles=%0d uart_chars=%0d leds=%08b", cyc, nchar, led);
      $finish(0);
    end else begin
      $fatal(1, "TB_FPGA RESULT FAIL: only %0d UART characters", nchar);
    end
  end
  initial begin
    #(40 * 8_000_000);
    $fatal(1, "TB_FPGA RESULT FAIL timeout (led=%08b)", led);
  end
endmodule
`default_nettype wire
