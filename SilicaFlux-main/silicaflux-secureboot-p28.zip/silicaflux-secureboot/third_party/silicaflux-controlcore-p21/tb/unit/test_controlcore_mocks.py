"""silicaflux_control_core ALONE, with isolated Python mocks instead of the accelerators:

  * accelerator register port: a mock that answers every access with rb_err = 1
    (no accelerator fitted) and records the forwarded addresses;
  * external data port: a Python SFB2 device-memory model;
  * host port: a Python host that loads the real firmware image and uses the mailbox.

Shows the hardware-independent path: the real boot ROM and firmware boot, discover
that no accelerator is present, report DEGRADED, still reach HOST_READY, and serve
host commands that need no accelerator (PING, DMA_COPY on the external port).
"""
import os

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, RisingEdge, Timer

from ccutil import M, ROOT

FW_HEX = os.path.join(ROOT, "firmware", "build", "fw", "controlcore_fw.hex")


class ExtMem:
    def __init__(self, dut):
        self.dut, self.mem, self.reqs = dut, {}, 0

    async def run(self):
        """SFB2 slave, 1-cycle latency: handshakes sampled mid-cycle, effects after the edge."""
        d = self.dut
        d.ext_req_ready.value = 1
        d.ext_rsp_valid.value = 0
        while True:
            await FallingEdge(d.clk)
            await Timer(1, units="ns")
            acc = int(d.ext_req_valid.value) and int(d.ext_req_ready.value)
            hs = int(d.ext_rsp_valid.value) and int(d.ext_rsp_ready.value)
            if acc:
                a, w = int(d.ext_req_addr.value), int(d.ext_req_write.value)
                wd, ws = int(d.ext_req_wdata.value), int(d.ext_req_wstrb.value)
            await RisingEdge(d.clk)
            if hs:
                d.ext_rsp_valid.value = 0
                d.ext_req_ready.value = 1
            if acc:
                self.reqs += 1
                ok = M.CC_DEVMEM_BASE <= a < M.CC_DEVMEM_BASE + M.CC_DEVMEM_SIZE
                old = self.mem.get(a, 0)
                if ok and w:
                    m = sum(0xFF << (8 * b) for b in range(4) if ws >> b & 1)
                    self.mem[a] = (old & ~m) | (wd & m)
                d.ext_rsp_valid.value = 1
                d.ext_rsp_rdata.value = 0 if (w or not ok) else old
                d.ext_rsp_error.value = 0 if ok else 1
                d.ext_req_ready.value = 0


class Host:
    def __init__(self, dut):
        self.d = dut

    async def access(self, write, addr, data=0):
        d = self.d
        await FallingEdge(d.clk)
        d.hs_req_valid.value, d.hs_req_write.value, d.hs_req_addr.value = 1, write, addr
        d.hs_req_wdata.value, d.hs_req_wstrb.value = data, 0xF
        await Timer(1, units="ns")
        while not int(d.hs_req_ready.value):
            await FallingEdge(d.clk)
            await Timer(1, units="ns")
        await RisingEdge(d.clk)
        await Timer(1, units="ns")
        d.hs_req_valid.value = 0
        while not int(d.hs_rsp_valid.value):
            await FallingEdge(d.clk)
            await Timer(1, units="ns")
        r = (int(d.hs_rsp_rdata.value), int(d.hs_rsp_error.value))
        await RisingEdge(d.clk)
        return r

    async def wr(self, a, v):
        _, e = await self.access(1, a, v)
        assert e == 0, f"host write 0x{a:08x} refused"

    async def rd(self, a):
        v, e = await self.access(0, a)
        assert e == 0, f"host read 0x{a:08x} refused"
        return v

    async def cmd(self, c, a1=0, a2=0, a3=0, budget=3_000_000):
        mb = M.CC_MAILBOX_BASE
        for i, v in enumerate((a1, a2, a3)):
            await self.wr(mb + M.CC_MBOX_H2F_MSG0 + 4 * (i + 1), v)
        await self.wr(mb + M.CC_MBOX_H2F_MSG0, c)
        await self.wr(mb + M.CC_MBOX_H2F_RING, c)
        return await self.wait_rsp(budget)

    async def wait_rsp(self, budget):
        for _ in range(budget):
            await RisingEdge(self.d.clk)
            if int(self.d.host_irq_o.value):
                break
        else:
            raise AssertionError("timeout waiting for the firmware")
        rsp = [await self.rd(M.CC_MAILBOX_BASE + M.CC_MBOX_F2H_MSG0 + 4 * i) for i in range(8)]
        await self.wr(M.CC_MAILBOX_BASE + M.CC_MBOX_F2H_ACK, 0)
        return rsp


@cocotb.test(timeout_time=600, timeout_unit="sec")
async def boot_without_accelerators(dut):
    d = dut
    for s in ("test_mode", "boot_mode_i", "host_rst_req_i", "hs_req_valid", "hs_req_write", "hs_req_addr",
              "hs_req_wdata", "hs_req_wstrb", "acc_rb_rdata", "acc_vec_irq_i", "acc_tsu_irq_i", "acc_vec_busy_i",
              "acc_tsu_busy_i", "acc_tsu_halted_i", "ext_warn_i", "ext_fatal_i", "ext_rsp_rdata", "ext_rsp_error"):
        getattr(d, s).value = 0
    d.hs_rsp_ready.value = 1
    d.acc_rb_err.value = 1                                         # mock: no accelerator answers
    d.rst_ni.value = 0
    cocotb.start_soon(Clock(d.clk, 10, units="ns").start())
    mem = ExtMem(d)
    cocotb.start_soon(mem.run())
    fwd = set()

    async def acc_monitor():
        while True:
            await RisingEdge(d.clk)
            if int(d.acc_rb_sel.value):
                fwd.add(int(d.acc_rb_addr.value))
    cocotb.start_soon(acc_monitor())
    chars = []

    async def console():
        while True:
            await RisingEdge(d.clk)
            if int(d.diag_valid_o.value):
                chars.append(chr(int(d.diag_char_o.value)))
    cocotb.start_soon(console())
    for _ in range(5):
        await RisingEdge(d.clk)
    d.rst_ni.value = 1
    h = Host(d)
    # boot ROM -> WAIT_IMAGE
    for _ in range(20000):                                         # DMEM test + IMEM scrub: ~200k cycles
        if await h.rd(M.CC_SYSCTRL_BASE + M.CC_SYSCTRL_BOOT_STAGE) == M.CC_BOOT_STAGE_WAIT_IMAGE:
            break
        for _ in range(100):
            await RisingEdge(d.clk)
    else:
        raise AssertionError("boot ROM never reached WAIT_IMAGE")
    img = [int(x, 16) for x in open(FW_HEX).read().split()]
    for i, w in enumerate(img):
        await h.wr(M.CC_IMEM_BASE + 4 * i, w)
    r = await h.cmd(M.CC_MBOX_CMD_IMAGE_READY)
    assert r[0] & 0xFF == M.CC_MBOX_STS_OK, "ROM rejected the image"
    for _ in range(2_000_000):
        await RisingEdge(d.clk)
        if int(d.host_ready_o.value):
            break
    caps = await h.wait_rsp(1000)
    dut._log.info("console:\n" + "".join(chars))
    assert caps[1] == 0, f"accelerator mask {caps[1]} (expected none)"
    hs = await h.rd(M.CC_SYSCTRL_BASE + M.CC_SYSCTRL_HOST_STATUS)
    assert hs & M.CC_HOST_STATUS_DEGRADED and hs & M.CC_HOST_STATUS_CMDPROC_READY, hex(hs)
    assert 0x8000 in fwd and 0x9000 in fwd, f"discovery probes not forwarded to pages 8/9: {sorted(fwd)}"
    assert "vector tile : NOT PRESENT" in "".join(chars)
    assert "tensor unit : NOT PRESENT" in "".join(chars)
    r = await h.cmd(M.CC_MBOX_CMD_PING, 0x600D)
    assert r[1] == 0x600D
    for i in range(16):
        mem.mem[M.CC_DEVMEM_BASE + 0x1000 + 4 * i] = 0xA0000000 + i
    r = await h.cmd(M.CC_MBOX_CMD_DMA_COPY, M.CC_DEVMEM_BASE + 0x1000, M.CC_DEVMEM_BASE + 0x2000, 64)
    assert r[0] & 0xFF == M.CC_MBOX_STS_OK
    assert all(mem.mem.get(M.CC_DEVMEM_BASE + 0x2000 + 4 * i) == 0xA0000000 + i for i in range(16))
    r = await h.cmd(M.CC_MBOX_CMD_GEMM, M.CC_DEVMEM_BASE)
    assert r[0] & 0xFF == M.CC_MBOX_STS_NO_DEVICE
    r = await h.cmd(M.CC_MBOX_CMD_SHUTDOWN, 0)
    for _ in range(20):
        await RisingEdge(d.clk)
    assert int(d.test_done_o.value) == 1 and int(d.test_fail_o.value) == 0
    dut._log.info(f"external-port requests served by the mock: {mem.reqs}")
