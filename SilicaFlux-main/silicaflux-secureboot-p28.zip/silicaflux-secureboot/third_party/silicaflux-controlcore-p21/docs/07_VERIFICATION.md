# 07 -- Verification

All results are tool outputs collected in `reports/` (summary: `reports/SUMMARY.md`). Simulator: Verilator 5.020
(timing mode). Firmware runs on the RTL CPU in every system test; no behavioural CPU model is used anywhere.

## 1. Environments

| Environment | DUT | What drives it | Command |
|---|---|---|---|
| System testbench `tb/tb_cc_system.sv` | `silicaflux_cc_hpc_system`: ControlCore + **real** vector tile + **real** tensor unit + DataFabric crossbar | testbench = host (host port, reset pin) + device-memory model (random back-pressure, poisoned window); boot ROM + firmware do everything else | `make regress` |
| cocotb unit tests `tb/unit/` | each new block in isolation; `silicaflux_control_core` alone with **Python mocks** (accelerator register port answering "absent", Python device memory, Python host) | Python | `make unit` |
| CPU ISA harness (MCU-I `tb_cpu.sv`, vendored) | `mcu_cpu` RV32M=1 | riscv-tests, 3 bus profiles x 2 seeds | `make isa` |
| FPGA harness simulation `tb/tb_fpga_top.sv` | `fpga/cc_fpga_top.sv` as synthesised (FPGA SRAM backend, `$readmemh` BRAM) | UART receiver model | `make fpga-sim` |
| Static | new RTL; address map; vendored files | Verilator `-Wall`, Icarus, validator negative tests, SHA-256 / archive comparison | `make lint check-map vendor` |

## 2. Brief section 9 -> evidence

| Required | Where verified | Result |
|---|---|---|
| Reset and boot | scenarios `boot_host`, `boot_ext`, `bad_image` (incl. host reset), `wdt_reset` (warm boot); unit `cc_sysctrl.reset_generator` | PASS |
| Firmware execution | every scenario (231 firmware checks on the RTL); unit `boot_without_accelerators` | PASS |
| MMIO read/write | firmware T2; unit tests of every register block | PASS |
| Invalid address access | firmware T2 (refused register accesses), T3 (unmapped load/store, ROM write, misaligned, execute-never fetch, EXT with nothing behind it) | PASS |
| Interrupt delivery | firmware T4, T5; every accelerator completion is interrupt driven | PASS |
| Simultaneous interrupts | firmware T5: 7 real sources pending at once, served in priority order in one trap | PASS |
| Timer | firmware T4 | PASS |
| Watchdog | firmware T13 (service, early warning); scenario `wdt_reset` (timeout -> reset -> warm boot) | PASS |
| Tensor command submission | firmware T8 (4 GEMMs incl. INT8 requantisation, bit-exact), T9, T10, T12; host GEMM commands (TB reference) | PASS |
| Vector command submission | firmware T7 (KERNEL x3, DMA+VEC pipeline, reduction, bit-exact), T9, T12; host VECTOR command (TB reference) | PASS |
| DMA completion | firmware T5, T6, T9; host DMA_COPY; ROM DMA boot (`boot_ext`) | PASS |
| Error handling | firmware T6, T10, T11, T14; host invalid GEMM and failing DMA; `bad_image` | PASS |

**Definition of done** ("executes real firmware in RTL simulation and can submit at least one supported
accelerator command and observe its completion"): met -- the firmware submits vector KERNEL / VEC / DMA commands
and tensor GEMM descriptors through the real ABIs to the real accelerator RTL and observes each completion by
interrupt, with results checked bit-exact (firmware and testbench references).

## 3. Bugs found and fixed during bring-up (all real, all re-verified)

| Found by | Problem | Fix |
|---|---|---|
| first host access at cycle 5 | the host port accepted a request while the crossbar was still in reset; the response never came | host port stalls until the SYS domain is out of reset (`sys_up_q`) |
| firmware T3 | **livelock**: an execute-never instruction fetch raised a RAS warning interrupt that pre-empted the fetch fault forever | instruction-side decode errors excluded from RAS interrupt sources (doc 02 section 6) |
| firmware T6 / T10 / T12 | test macro evaluated its argument twice -> every checked command ran twice (doubled counters, shifted records) | single-evaluation macros |
| firmware T6 | potential double interrupt: the DMA interrupt output is registered, the dispatcher re-claimed before it dropped | read-back after every W1C acknowledge (documented rule) |
| scenario `wdt_reset` | early-warning evidence lost across the reset | recorded in a POR-domain scratch register |
| cocotb | testbench sampling races (post-edge sampling of combinational handshakes) | mid-cycle sampling in all Python models |
| Yosys 0.33 | package wildcard imports and `int'()` casts unsupported | generated `cc_memmap_defs.svh` included per module; casts removed (regression re-run, identical cycle counts) |
| lint gate | the Yosys edit left a 5-bit `case` expression against 32-bit constants in `cc_ras` (WIDTHEXPAND) | zero-extended case expression; every gate re-run on the frozen sources |

## 4. Not covered (see doc 09)

Gate-level simulation, formal proofs of the new RTL, coverage collection, Icarus runs of the system scenarios,
constrained-random multi-master stress of the ControlCore crossbar, hardware.
