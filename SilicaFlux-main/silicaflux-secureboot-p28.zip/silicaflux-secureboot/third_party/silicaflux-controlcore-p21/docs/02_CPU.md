# 02 -- Processor: implemented ISA and privileged architecture

CPU: `third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv` (unmodified), instantiated with `RV32M = 1`,
`BOOT_ADDR = 0x0000_0000`, `MIMPID = 0x0021_0001`. Full design notes: `third_party/silicaflux-mcu-i/docs/CPU.md`.

## 1. Exact ISA

| Item | ControlCore configuration |
|---|---|
| Base | **RV32I** (32 x 32-bit registers, x0 = 0) |
| Extensions | **M** (iterative: every MUL/MULH*/DIV*/REM* takes 35 cycles, data independent), **Zicsr**, **Zifencei** (FENCE.I flushes the 2-entry prefetch buffer) |
| Not implemented | C (compressed), A, F, D, Zb*, PMP, S/U modes, MMU, debug module / triggers, misaligned access in hardware |
| Toolchain target | `-march=rv32im_zicsr_zifencei -mabi=ilp32` (GNU 13.2, rv32im/ilp32 multilib) |
| FENCE | executes as NOP (in-order, blocking loads/stores, no caches) |

## 2. Privileged features

Machine mode only. CSRs: `mstatus` (MIE, MPIE; MPP = M), `misa` (= `0x4000_1100`: MXL 32, I, M), `mie`, `mip`,
`mtvec` (direct or vectored; firmware uses direct), `mscratch`, `mepc`, `mcause`, `mtval`, `mcountinhibit`,
`mcycle[h]`, `minstret[h]` (+ user read-only aliases), `mvendorid = 0`, `marchid = 0`, `mimpid = 0x0021_0001`,
`mhartid = 0`, `mconfigptr = 0`.

## 3. Memory model

* **Endianness: little-endian** (bytes and SFB2 lanes); the image header and all registers are little-endian words.
* **Alignment:** loads/stores must be naturally aligned; a misaligned access raises a misaligned exception
  (mcause 4 / 6) and is not sent to the bus. The crossbar additionally rejects non-word-aligned SFB2 addresses.
* Register pages accept only 32-bit accesses.

## 4. Reset vector and trap handling

* Reset vector **0x0000_0000** (boot ROM). `mtvec` resets to the reset vector; the ROM and the firmware set
  their own handlers.
* Exceptions (precise; `mepc` = faulting instruction): 0 instruction misaligned, 1 instruction access fault
  (fetch bus error / execute-never), 2 illegal instruction (`mtval` = instruction), 3 breakpoint, 4/6
  load/store misaligned (`mtval` = address), 5/7 load/store access fault (bus error, `mtval` = address),
  11 ecall from M-mode.
* Interrupts: MEI (11, from the INTC), MSI (3, MTIMER.MSIP), MTI (7, mtime >= mtimecmp); priority MEI > MSI >
  MTI; taken at an instruction boundary that is not inside a bus access; an M-unit operation in progress is
  abandoned and re-executed after `mret`.
* Firmware trap path (`firmware/common/trap_entry.S`, `firmware/app/platform.c`): save x1, x3..x31 and `mepc`
  to a stack frame, dispatch (MEI -> INTC claim loop, MTI -> tick, MSI, exceptions), restore, `mret`. An
  exception that a test armed ("expected trap") is recorded and skipped (`mepc + 4`) or resumed at `ra`; any
  other exception is fatal: logged on the console, RAS `SW_REPORT` fatal, `BOOT_STAGE = FATAL`, test status FAIL.

## 5. Evidence (and what is not claimed)

| Evidence | Result |
|---|---|
| riscv-tests rv32ui + rv32um + rv32mi on `mcu_cpu RV32M=1`, re-run here (`scripts/run_riscv_tests.sh 1`), 3 bus profiles x 2 seeds | **63 / 63 PASS** (`reports/isa/riscv_tests_m1.txt`; riscv-tests commit `3df703c`) |
| Excluded tests | `rv32ui/ma_data` (misaligned access traps by design), `rv32mi/pmpaddr` (no PMP), `rv32mi/breakpoint` (no trigger module) |
| Harness sanity | a corrupted test image is reported FAIL (checked during this project) |
| Firmware-level | 231 firmware self-test checks on the RTL include misa/mimpid/mhartid, all exception causes above, MTI/MSI/MEI, WFI wake-up |
| MCU-I's own records (not re-run) | formal equivalence `mcu_cpu(RV32M=0)` == `sfv_cpu`; RV32M = 0 and 2 riscv-tests |

**No RISC-V compliance claim.** The RISC-V International architectural test suite (riscv-arch-test) has not
been run on this core.

## 6. Interaction found during bring-up

An instruction fetch from an execute-never region raises a crossbar decode error. Reporting that error as a
RAS warning interrupt livelocked the CPU: the pending interrupt is (correctly) taken before the faulting
instruction's own exception, and the re-fetch after `mret` raised the event again. Instruction-side decode
errors are therefore not RAS interrupt events (they remain precise exceptions and are counted by
`PERF.BUS_ERR`). The same reasoning applies to a parity error on an instruction fetch; the firmware policy for a
fatal `MEM_PARITY` in IMEM is a soft reset (warm boot re-checks the image CRC and falls back to host load).
