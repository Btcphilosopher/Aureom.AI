# 05 -- Accelerator orchestration

The ControlCore drives the **real** accelerators through their **real** register ABIs, using their own C
drivers unmodified. No command protocol was invented: the vector page and the tensor page are the units'
own register pages, forwarded from the ControlCore's register bus.

| Unit | ControlCore page | ABI (single source) | Driver used by the firmware |
|---|---|---|---|
| FP32 vector tile (HPC Module 08) | 8, `0x4000_8000` | 8-word descriptor CMD0..7 + DOORBELL; CPL_* record (`hpc_tile_defs.svh`, `third_party/silicaflux-hpc-m08-tile/docs/02_commands.md`, `03_register_map.md`) | `silicaflux_hpc.c` / `hpc_tile_regs.h` |
| INT8 tensor unit (TENSORCORE 08) | 9, `0x4000_9000` | 12-word GEMM descriptor (ABI v2) DESC0..11 + DOORBELL; 6-word record (`tsu_defs.svh`, `third_party/silicaflux-tensorcore08/docs/02_COMMAND_ABI.md`, `03_REGISTER_MAP.md`) | `tsu_driver.c` / `tsu_abi.h` |
| System DMA (`mcu_dma`) | 4, `0x4000_4000` | SRC / DST / LENGTH / MODE / CONTROL.START, INT_STATUS, ERROR_CODE (DataFabric codes) | `firmware/app/platform.c` |
| Tile DMA | via the tile (command type DMA) | part of the tile ABI | tile driver |

## 1. Submission and completion (firmware/app/accel.c)

* **Vector:** `vec_submit` (driver `hpc_submit`: never rings a full queue) -> the VECTOR interrupt handler
  drains every record with `hpc_poll` into a ring and acknowledges `IRQ_STATUS`; `vec_wait` sleeps in `WFI`
  until a record arrives. Commands used: KERNEL (load A/B/C from device memory, compute, store D, in one
  command), DMA (device memory <-> scratchpad), VEC (scratchpad-resident), NOP, with FADD / FSUB / FMUL /
  FMADD and sum reduction.
* **Tensor:** `tsu_build_gemm` (driver) builds the ABI v2 descriptor; `tsu_check` (driver) predicts the
  hardware's validation result; `tsu_submit` rings the doorbell; the TENSOR handler drains records with
  `tsu_poll`; `tsu_wait_irq` sleeps until one arrives (or the unit halts). INT32 output and requantised INT8
  output with ReLU are used.
* **DMA:** `dma_start` / `dma_wait` with the DMA completion interrupt; errors return the DataFabric code.
* **Concurrency:** a GEMM, a vector KERNEL and a system DMA run at the same time; their completion interrupts
  arrive independently (`PERF.ACC_OVERLAP` counts the overlapping cycles).
* **Host-submitted work:** the mailbox command processor accepts a GEMM or vector descriptor *already built
  by the host* in device memory (`MBOX_CMD_GEMM` / `MBOX_CMD_VECTOR_KERNEL`, argument = descriptor address),
  submits it unchanged, waits for the completion interrupt and returns the raw completion record.

## 2. Errors and recovery (all exercised on the RTL, firmware T10 and host commands)

| Error | Detection | Recovery |
|---|---|---|
| reserved tile command type | record `BAD_TYPE`; tile halts (HALT_ON_ERROR) | RAS `SW_REPORT`, `hpc_resume`, next command OK |
| tile DMA from failing memory | record `DMA_ERR`, DETAIL = READ_BUS (8) | resume, retry from good memory |
| invalid GEMM descriptor (M = 0; or VERSION != 2 from the host) | record ERROR `DIM_ZERO` / `VERSION`, nothing executed, later commands SKIPPED (stop-on-error) | `tsu_clear_error` (ERR_CLEAR), next GEMM OK |
| GEMM operand in failing memory | record ERROR `DMA_READ` with the failing word address | `ERR_CLEAR`, next GEMM OK |
| system DMA from an unmapped / failing address, or misaligned | `DMA.ERROR_CODE` 8 (READ_BUS) / validation code; RAS `DMA_ERR` | next transfer OK |
| tensor unit halted (port could not be drained) | RAS fatal `TSU_HALTED` (level) | `acc_reset()`: PMU reset of the accelerator domain + rediscovery (exercised unconditionally in T10: SUBMITTED returns to 0, next GEMM OK) |
| access to an isolated / clock-gated accelerator | bus error (load/store access fault), RAS `ISO_ACCESS` | clear `PMU.ACC_CTRL.ISO` |

## 3. Power management (PMU)

`ACC_CTRL.CLK_EN = 0` stops the accelerator clock once both units are idle and the external port is idle
(T14: the tensor unit's free-running cycle counter advanced 22 cycles while 3 049 cycles were gated);
`ACC_CTRL.RST` resets the domain; `ACC_CTRL.ISO` isolates it. Isolation is automatic whenever the clock is
requested off or the domain is in reset, and optionally on a RAS fatal (`RAS.CTRL.FATAL_ISOLATE`).

## 4. Performance counters and telemetry

* ControlCore (`cc_perf`, page 6): 64-bit cycle counter + 20 events (CPU sleep, tile / tensor / DMA busy,
  overlap, external requests and stalls, host requests, interrupt edges per source, accelerator register
  accesses, decode errors, isolation refusals). FREEZE for consistent snapshots, CLEAR.
* Tile: 24 counters (`PERF[i]`), tensor unit: 20 counters (`PERF[i]`) + 18 DMA counters, read through pages 8/9.
* `perf_dump(addr)` / host command `PERF_DUMP`: writes a 72-word telemetry block to device memory: `"FPCC"`,
  cycle lo/hi, n, ControlCore counters; `"FPCV"`, n, tile counters; `"FPCT"`, n, tensor counters.
* Exactness checked on the RTL (T12): after clearing, one 12x8x40 GEMM gives `GEMM_OK = 1`,
  `MACS = 3 840`, `CMD_DONE = 1`; one 32-element FADD KERNEL gives `KERNEL_CMDS = 1`, `VEC_ELEMS = 32`,
  `VEC_FLOPS = 32`.

## 5. Measured latencies (RTL cycles, `reports/sim/boot_host_bp0_s1.log`)

| Operation | Cycles |
|---|---|
| KERNEL FADD / FMUL, 32 elements (tile record CYCLES) | 440 |
| KERNEL FMADD, 32 elements | 584 |
| GEMM 8x8x16 / 17x13x29 / 4x4x4 INT32 (tensor record CYCLES) | 806 / 5 464 / 161 |
| Host GEMM command 9x11x40, host doorbell to host answer (incl. descriptor fetch, submit, IRQ, record copy) | 8 178 |
| Host VECTOR command, 48 elements, end to end | 4 668 |
| Host PING | 747 |
| Concurrent GEMM 16x16x64 + KERNEL + 1 KiB DMA: cycles with >= 2 engines busy | 1 473 |

The accelerators' own throughput is documented by their projects (TC08 `reports/perf.md`, M08
`reports/perf.md`); the ControlCore adds the register-bus submission (8 or 13 writes) and interrupt handling.
