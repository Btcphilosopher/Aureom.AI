# 08 -- FPGA implementation

**No board was available. Nothing in this project has run on FPGA hardware.** The results below are synthesis,
place-and-route estimates and an RTL simulation of the exact harness that was synthesised. Full numbers:
[reports/fpga.md](../reports/fpga.md).

## 1. Harness (`fpga/cc_fpga_top.sv`)

Target: ULX3S (Lattice LFE5U-85F-CABGA381), the board used by MCU-I, HPC Module 08 and TENSORCORE 08.

* `silicaflux_control_core` with the FPGA SRAM backend: IMEM and DMEM in block RAM, with parity.
* Boot mode EXT. The boot ROM DMA-copies the firmware image from a 64 KiB block-RAM "device memory" that is
  initialised with the firmware image at configuration (`$readmemh`), checks the CRC and starts it. No host
  is needed.
* Accelerator register port answers "absent". The tile and tensor unit are not in the harness (section 3), so
  the firmware reports them NOT PRESENT and runs DEGRADED.
* LEDs show host-irq, host-ready, command-processor-ready, test done/fail, RAS fatal, CPU sleep and a heartbeat.
  The console goes out on `ftdi_rxd` as UART 115200 8N1.
* Constraints `fpga/cc_ulx3s.lpf` reuse the MCU-I pin sites. Check them against your board revision first.

## 2. Results (seed 1, 25 MHz constraint)

| Metric | Result |
|---|---|
| Yosys `synth_ecp5` (flattened, harness included) | 15 187 LUT4, 3 815 FF, 1 287 CCU2C, 80 DP16KD, 0 MULT18X18D |
| nextpnr-ecp5 utilisation | 18 791 / 83 640 TRELLIS_COMB (22 %), 3 815 FF (4 %), 80 / 208 DP16KD (38 %), 12 IO |
| **Post-route Fmax estimate** | **27.42 MHz: PASS at 25 MHz** (placement-stage estimate 17.05 MHz) |
| Bitstream | `fpga/build/cc_fpga.bit` (`ecppack --compress`), SHA-256 in `fpga/build/cc_fpga.bit.sha256` |
| Harness RTL simulation (`make fpga-sim`) | boots from block RAM, reaches HOST_READY (led[1]), console on the UART model: **PASS** |

Critical path: IMEM block RAM → parity check → crossbar response → CPU fetch / interrupt decision → crossbar
request decode. Most of the delay is routing.

The margin is small (about 10 %). Options if more is needed:

* a response register slice on the IMEM port;
* a registered `irq_ext`;
* moving the parity check off the read path.

MCU-I hit the same class of path.

Area: the largest blocks are the CPU and `cc_perf` (about 4 k LUT4 each). The boot ROM is synthesised as logic.
The block RAM count is IMEM + DMEM with parity (48 DP16KD) plus the harness memory (32).

## 3. Full system

The complete system (ControlCore + vector tile + tensor unit) was synthesised by Yosys for a resource estimate
only (`make fpga-system`). The estimate is about 99 k logic-cell equivalents against 83.6 k on the LFE5U-85F,
so **it does not fit the largest ECP5** and was not placed and routed. A system prototype needs one of:

* a larger FPGA;
* a reduced accelerator configuration, e.g. TSU without quantisation / double buffering, or 2 tile lanes.

The accelerator projects report their own separate ECP5 builds.

## 4. Before using a board (checklist)

1. Check `fpga/cc_ulx3s.lpf` against the official LPF for the board revision.
2. Program `fpga/build/cc_fpga.bit` (for example with `openFPGALoader -b ulx3s`). Expect:
   * the heartbeat on led[7];
   * led[1] and led[2] (host-ready, command-processor-ready) within about 30 ms;
   * the boot banner on the FTDI serial port at 115200 baud.
3. Record what is actually observed. Do not reuse this document's simulation results as hardware evidence.
