# 04 -- Interrupts, timer and watchdog

## 1. Sources and priorities

| INTC id | Name | Source | Recommended priority (firmware) | Acknowledge (at the source) |
|---|---|---|---|---|
| 0 | FATAL | `cc_ras` fatal class: MEM_PARITY, TSU_HALTED, EXT_FATAL, SW_FATAL | 7 | `RAS.STATUS` W1C (level sources: clear the cause, or mask in `FATAL_EN`) |
| 1 | WDT | `mcu_wdt` early warning (COUNT <= EWI_THRESH) | 6 | service (KEY1, KEY2) then `WDT.STATUS.EWI` W1C |
| 2 | RAS_WARN | `cc_ras` warning class: BUS_DECODE, PERIPH_ERR, DMA_ERR, HOST_VIOL, ISO_ACCESS, EXT_WARN, SW_WARN | 5 | `RAS.STATUS` W1C |
| 3 | DMA | `mcu_dma` completion / error | 4 | `DMA.INT_STATUS` W1C |
| 4 | TENSOR | tensor unit record pushed (`INT_STATUS & INT_ENABLE`) | 3 | pop records (`CPL_POP`), `INT_STATUS` W1C |
| 5 | VECTOR | tile record pushed / error record / halted | 3 | pop records (`CPL_POP`), `IRQ_STATUS` W1C |
| 6 | HOST | mailbox H2F doorbell | 2 | `MBOX.H2F_ACK` |
| -- | MTI | `sfv_timer` mtime >= mtimecmp (CPU timer interrupt) | -- | re-arm `MTIMECMP` |
| -- | MSI | `sfv_timer` MSIP | -- | `MSIP = 0` |

* **Priority:** `INTC.PRIO0` holds 3-bit priorities (0 = never); a source interrupts when pending, enabled and
  its priority > `THRESHOLD`; `CLAIM` returns the highest priority, lowest index on ties. The source numbering
  is chosen so that even the reset default (all priorities 1) resolves FATAL > WDT > RAS_WARN > DMA > TENSOR >
  VECTOR > HOST. At the CPU, MEI > MSI > MTI.
* **Masking:** `INTC.ENABLE` per source, `INTC.THRESHOLD`, `mie` (MEIE/MTIE/MSIE), `mstatus.MIE`; plus the
  per-source enables inside each block (`RAS.WARN_EN/FATAL_EN`, `DMA.INT_ENABLE`, tile `IRQ_EN`, tensor
  `INT_ENABLE`). Accelerator interrupt lines are masked in hardware while the accelerator domain is isolated
  (PMU), because the firmware could not clear them.
* **Acknowledgement:** all sources are level-sensitive. The handler clears the cause *at the source* and reads
  the status register back (the source's interrupt output is registered; the read-back guarantees it has
  dropped before the dispatcher claims again). Reading `CLAIM` has no side effect.
* **Simultaneous interrupts:** the dispatcher (`dispatch_ext`) loops `CLAIM -> handler` until `CLAIM = 0`, so
  everything pending is served in priority order within one trap. A source that keeps re-asserting more than
  64 times in one trap, or has no handler, is masked and reported (RAS `SW_REPORT`).
* **Nesting:** not used (handlers run with `mstatus.MIE = 0`). `THRESHOLD` + re-enabling `MIE` would allow it.

## 2. Timer

`sfv_timer`: 64-bit `mtime` (prescaler `PRESCALE + 1`), `mtimecmp`, `msip`. The firmware runs a periodic
20 000-cycle tick (MTI) that services the watchdog and bounds every `WFI` wait (all waits have timeouts).
Idle firmware sleeps in `WFI`; `PMU.SLEEP_CYC` and `PERF.CPU_SLEEP` count the sleeping cycles.

## 3. Watchdog

`mcu_wdt` (unmodified): down-counter clocked every `PRESCALE + 1` cycles, set-only `EN` and `LOCK`, two-key
service (`0xA5A5`, `0x5A5A`; any other value while enabled requests a reset), early warning when `COUNT <=
EWI_THRESH`, expiry -> `reset_req` -> `cc_sysctrl` reset generator -> SYS reset with `RESET_CAUSE.WDT` (POR
domain). Firmware: `PRESCALE = 63`, `LOAD = 50 000` (3.2 M cycles), `EWI_THRESH = 5 000`; serviced by the tick.
Behaviour on timeout: early-warning interrupt first (firmware logs and, in the reset test, records evidence in
`SCRATCH2`), then reset; the ROM warm-boots the retained image (doc 03).

## 4. Verified

| Check | Where |
|---|---|
| MTI tick during WFI, prescaler, MSI, mcycle / minstret | firmware T4 (8 checks) |
| masking (ENABLE), priority 0 = never, priority order, tie -> lower index, THRESHOLD | firmware T5, software-pended sources |
| **7 real sources pending at once** (RAS fatal + warning injection, watchdog early warning, DMA completion, tensor NOP, vector NOP, host doorbell): taken in one trap in the order FATAL, WDT, RAS_WARN, DMA, TENSOR, VECTOR, HOST; every source cleared | firmware T5 (21 checks) |
| watchdog count, service, read-only COUNT refusal, early warning restored by the handler | firmware T13 |
| watchdog timeout -> reset -> warm boot without the host; early warning seen before the reset | scenario `wdt_reset` |
| completion interrupts of every accelerator command (the firmware never polls for completion) | firmware T7-T12, host commands |
| `mcu_intc` priority/claim properties | MCU-I formal proof (not re-run here) |

## 5. Pitfall found during bring-up

Instruction-fetch decode errors were first reported as RAS warnings; the CPU takes a pending interrupt before
the faulting instruction's exception, so the fault re-occurred after every `mret` (livelock). They are now
excluded from RAS interrupt sources (doc 02 section 6).
