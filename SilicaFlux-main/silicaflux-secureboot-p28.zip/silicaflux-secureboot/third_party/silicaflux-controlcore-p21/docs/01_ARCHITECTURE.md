# 01 -- ControlCore architecture

## 1. Purpose and scope

The ControlCore is the on-chip control subsystem of SilicaFlux-HPC: it brings the chip up, runs control
firmware, configures and sequences the FP32 vector tile and the INT8 tensor unit, supervises DMA, handles
interrupts and errors, and gives the host a status and command interface. It is deliberately a small,
deterministic microcontroller-class subsystem (machine-mode RV32IM, no caches, no MMU, no OS) -- not an
application processor.

## 2. Block diagram

```
                        +---------------------------------- silicaflux_control_core ----------------------------------+
  host access port ---> | cc_sfb_gate (host write lock) --+                                                          |
  (SFB2 slave)          |                                  |        sfb_crossbar (DataFabric, SFB2, round robin)     |
                        | mcu_cpu RV32IM_Zicsr  I-port ----+---> m0..m3 ----------------------------------- s0..s4     |
                        |                       D-port ----+                                                 |          |
                        | mcu_dma (system DMA) ------------+     s0 BOOTROM  sfv_bootrom 8 KiB (mask ROM)    |          |
                        |                                        s1 IMEM     mcu_sram_bank 64 KiB, byte parity          |
                        |                                        s2 DMEM     mcu_sram_bank 32 KiB, byte parity          |
                        |                                        s3 PERIPH   reg slice -> v1 adapter -> sfv_periph_bridge
                        |                                        s4 EXT      cc_sfb_gate (accelerator isolation) ------+--> ext_* (SFB2 master)
                        |   register pages (4 KiB each):                                                               |
                        |    0 cc_sysctrl  1 mcu_intc  2 sfv_timer  3 mcu_wdt  4 mcu_dma  5 cc_mailbox  6 cc_perf      |
                        |    7 cc_pmu      8..15 forwarded -------------------------------------------------------------+--> acc_rb_* (pages 8..15)
                        |   16 cc_ras     17 cc_secmon                                                                  |
                        |   INTC sources: FATAL WDT RAS_WARN DMA TENSOR VECTOR HOST  -> MEI;  MTIMER -> MTI / MSI      |
                        |   sfv_clkgate (PMU) --------------------------------------------------------------------------+--> acc_clk_o, acc_rst_no
                        +-------------------------------------------------------------------------------------------------+
                                       |  acc_rb_* (rb, page 8 / 9)        |  ext_* (SFB2)
                        +--------------v-----------------------------------v--------- sfx_hpc_tensor_system (TC08, unmodified)
                        |   silicaflux_hpc_tile (FP32 vector array, SPM, tile DMA)   silicaflux_tensor_unit (INT8 GEMM)  |
                        |   DataFabric crossbar: m0 = ControlCore, m1 = tile DMA, m2 = tensor DMA -> shared SRAM, tile SPM |
                        +-------------------------------------------------------------------------------- dm_* (device memory)
```

`integration/silicaflux_cc_hpc_system.sv` is exactly this wiring; `fpga/cc_fpga_top.sv` replaces the
accelerator subsystem with tie-offs ("absent") and a block-RAM device memory.

## 3. Components

| Function (brief section 2) | Implementation | Origin |
|---|---|---|
| Embedded processor | `mcu_cpu`, RV32IM_Zicsr_Zifencei, M-mode, 2-stage, precise traps | MCU-I (unmodified) |
| Boot ROM interface | `sfv_bootrom` + generated `sfv_bootrom_image` (from `firmware/bootrom`) | SilicaFlux-V mechanism; ROM code new |
| Local instruction / data memory | IMEM 64 KiB + DMEM 32 KiB, separate crossbar slaves (fetch and data in parallel), odd byte parity | MCU-I `mcu_sram_bank` on the SRAM library |
| Memory-mapped control bus | DataFabric SFB2 crossbar (4 masters x 5 slaves, access matrix) + SilicaFlux-V register bus | DataFabric / SilicaFlux-V |
| Interrupt controller | `mcu_intc`: 16 level sources, priority 0..7, threshold, claim, software pend | MCU-I |
| Timer and watchdog | `sfv_timer` (mtime/mtimecmp/msip) ; `mcu_wdt` (two-key service, early warning, reset) | SilicaFlux-V / MCU-I |
| Vector command interface | register page 8 forwarded to the tile's command/completion registers (8-word descriptors) | tile ABI (HPC Module 08) |
| Tensor command interface | register page 9 forwarded to the tensor unit (12-word GEMM descriptor, ABI v2) | tensor ABI (TENSORCORE 08) |
| DMA command interface | system DMA `mcu_dma` (page 4, completion IRQ) + the tile's DMA commands | MCU-I / Module 05 |
| Performance-counter access | `cc_perf` (ControlCore counters) + accelerator counter banks through pages 8 / 9; `perf_dump` telemetry | new + accelerators |
| Firmware loading and status | host port + `cc_mailbox`, boot ROM (host load / device-memory DMA boot / warm boot), `cc_sysctrl` boot stage & host-ready pins | new |
| Power management | `cc_pmu`: accelerator clock gate, reset, isolation | new |
| RAS | `cc_ras`: warning / fatal classes, counters, first/last error, injection, parity controls | new |
| Security status | `cc_secmon`: honest capability/status report, host write lock, write-once boot measurement | new |

## 4. Clock and reset

* **One functional clock** `clk`. The accelerator subsystem runs on `acc_clk_o`, an ICG-gated copy (`sfv_clkgate`,
  latch-based in simulation/ASIC, pass-through with `SFV_NO_CLOCK_GATE` on FPGA). The PMU enable is registered
  (glitch-free) and only drops when both accelerators are idle and no ControlCore transaction is outstanding.
* **Resets** (async assert, sync release via `sfv_rst_sync`; bypassed to `rst_ni` in `test_mode`):

| Domain | Released when | Contents |
|---|---|---|
| POR | `rst_ni` | `RESET_CAUSE`, `RESET_COUNT`, `SCRATCH0..3`, reset stretcher |
| SYS | POR and no soft / watchdog / host reset request (16-cycle stretched pulse) | CPU, crossbar, memories' control, all pages |
| ACC | SYS and `PMU.ACC_CTRL.RST = 0` (applied only once the external port is idle) | the accelerator subsystem |

* The host port does not accept requests (ready = 0) until the SYS domain is out of reset (found during
  bring-up: a request accepted by logic still in reset was lost).
* Asynchronous inputs (`boot_mode_i`, `host_rst_req_i`, `ext_warn_i`, `ext_fatal_i`) pass 2-flop synchronisers.

## 5. Bus and access rules

* SFB2 everywhere (DataFabric protocol: valid/ready request and response channels, one transaction in flight
  per port, write completion = acknowledged, errors returned in the response).
* Access matrix (generated from `config/cc_memmap.yaml`): the CPU instruction port reaches only BOOTROM and
  IMEM (**execute-never** for DMEM, EXT, PERIPH); the host port reaches BOOTROM/IMEM/DMEM/PERIPH but not EXT;
  the DMA reaches IMEM/DMEM/PERIPH/EXT (with `mcu_dma`'s own rule that a peripheral address is legal only as a
  fixed, paced side).
* Register pages answer in the strobe cycle; unmapped offsets, writes to read-only registers and sub-word
  writes are refused (bus error -> load/store access fault on the CPU, error response on the host port).
* Pages 8..15 leave the ControlCore on `acc_rb_*` with `acc_rb_addr[15:12] = page`, so the existing
  accelerator drivers work at their default addresses (`0x4000_8000` tile, `0x4000_9000` tensor unit).
* The device address space is shared: the ControlCore, the tile and the tensor unit use identical byte
  addresses for device memory (`0x2000_0000`) and the tile scratchpad (`0x3000_0000`). There are no caches,
  so there is no coherence problem; producers report completion only after their writes were acknowledged.

## 6. Determinism

In-order CPU without caches or branch prediction state beyond a 2-entry prefetch buffer; fixed 35-cycle
MUL/DIV; single-cycle register pages; round-robin crossbar arbitration with a bounded wait; interrupts taken
only at instruction boundaries. The firmware uses no dynamic memory. Latency of an accelerator command from
the ControlCore's side is bounded by the accelerator, not by the controller (doc 05).
