# 00 -- Repository audit (Project 21 ControlCore)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/lucid-tesla-fm7wq6`, commit `8158b9d`. The SilicaFlux work
lives almost entirely inside zip archives under `SilicaFlux-main/` (and `SilicaFlux2.0/SilicaFlux2.5/`). Every
archive relevant to a control processor was extracted and read; the findings below cite the archive.

## 1. What exists

| Area | Found | Evidence quality (as recorded by that project) | Decision |
|---|---|---|---|
| **RISC-V CPU** | `silicaflux-mcu-i.zip` `rtl/cpu/mcu_cpu.sv` -- RV32I[M]_Zicsr_Zifencei, machine mode, 2-stage, precise traps, CLINT-style interrupts, OBI-style I/D ports. Derived from SilicaFlux-V `sfv_cpu` (vendored in the same archive). | riscv-tests rv32ui/um/mi **63/63** (RV32M = 1, 2), **55/55** (RV32M = 0) under 3 bus profiles x 2 seeds; Yosys formal equivalence `mcu_cpu(RV32M=0)` == `sfv_cpu`; explicitly **no** RISC-V compliance claim (riscv-arch-test not run). | **Reused unmodified** (RV32M = 1). riscv-tests **re-run here: 63/63** (`reports/isa/`). |
| Other CPUs | `RISC-V CPU.zip` (`rv32i_core.sv`), `cpu_core.zip` (5-stage RV32I), `pipelined_cpu.zip`; `silicaflux.zip` `rtl/control_core.sv` | No ISA test suite, no CSRs/traps (cpu_core), custom non-RISC-V ISA (`control_core.sv` is a scalar pipeline of the original SilicaFlux dataflow ISA). | Not used. The name `control_core.sv` predates this project and is unrelated. |
| MCU-I SoC | `silicaflux-mcu-i.zip`: SoC with crossbar, boot ROM + SPI flash boot, SRAM banks with parity, INTC, watchdog, DMA, UART/SPI/I2C/GPIO/PWM, JTAG, fault log, MBIST | SoC firmware regression, cocotb unit tests, formal proofs, FPGA bitstreams (no board), Yosys ASIC synthesis | Template for the ControlCore. Reused: CPU, `mcu_intc`, `mcu_wdt`, `mcu_dma`, `mcu_sram_bank`. Not reused: UART/SPI/I2C/GPIO/PWM/JTAG/MBIST (not needed for on-chip orchestration in v1). |
| SilicaFlux-V | `silicaflux-v-release1.zip` (also vendored in MCU-I): register bus (`sfv_periph_bridge`), CLINT timer, boot ROM slave, synchronisers, clock gate | Reused by MCU-I and HPC Module 08 | Reused unmodified (`sfv_*`). |
| Bus | DataFabric (`silicaflux-datafabric.zip`): SFB2 protocol, crossbar, arbiters, register slice, DMA engines, protocol checker | Formal proofs, regressions (DataFabric reports) | Reused unmodified (SFB2 everywhere). |
| Command queues | HPC Module 06 `hpc_command_queue` (in M08/TC08), tile command FIFO, tensor command FIFO | Module regressions | Used **through the accelerators' own register pages** (no second command-queue protocol invented). |
| **Vector engine** | HPC Module 08 `silicaflux_hpc_tile` (FP32 vector array, banked scratchpad, tile DMA, command queue, 24 counters) | 145/145 integration runs, firmware on the SilicaFlux-V CPU 5/5 scenarios, bit-exact vs SoftFloat | **Driven by the ControlCore** via its register page and C driver. |
| **Tensor engine** | TENSORCORE 08 `silicaflux_tensor_unit` (INT8 GEMM, 4x4 systolic array, TC02-07) and `sfx_hpc_tensor_system` (tile + tensor unit + DataFabric crossbar + shared SRAM port) | 642 GEMMs checked, Icarus/Verilator identical, C driver on the RTL (co-simulation backend only) | **The accelerator subsystem of the ControlCore system**, unmodified. The C driver `tensor_gemm()` previously ran only on a co-simulation backend; it now runs **on the RTL CPU** inside the ControlCore. |
| DMA | DataFabric `dma_transfer_engine`; MCU-I `mcu_dma` (derived: fixed-address / byte modes, pacing); tile DMA (Module 05); tensor DMA (TC07) | as above | System DMA = `mcu_dma` (reused); accelerator-internal DMAs used through their command ABIs. |
| Reset logic | `sfv_rst_sync`, MCU-I reset generator inside `mcu_sysctrl` | | Pattern reused; ControlCore reset generator is new (`cc_sysctrl`). |
| Interrupt controllers | `sfv_intc` (enable + claim), MCU-I `mcu_intc` (16 sources, priority 0..7, threshold, claim, SW pend, formally checked) | MCU-I formal + unit tests | `mcu_intc` reused. |
| Boot ROMs | SilicaFlux-V ROM (POST, MBIST, UART/flash boot), MCU-I ROM (SPI flash image boot) | | ROM *mechanism* reused (`sfv_bootrom` + `gen_rom.py`); ControlCore ROM code is new (host-load / device-memory boot, CRC32 image check, warm boot). |
| Debug | MCU-I JTAG (SBA, CPU hold, no RISC-V debug module) | | Not included in ControlCore v1 (no debug port; reported in SECURITY.CAPS). |
| Firmware | MCU-I HAL/drivers/examples (GNU toolchain), M08 tile driver + demo, TC08 tensor driver | | Tile and tensor drivers reused unmodified; ControlCore runtime/firmware is new. |
| Security / firmware authentication | **Nothing.** No Project 28 deliverable in the repository. | -- | Not implemented. SECURITY page reports AUTH = absent; CRC32 is integrity only. |
| FPGA flows | MCU-I / M08 / TC08: Yosys + nextpnr-ecp5 (ULX3S LFE5U-85F), no board runs | | Same flow and board reused for the ControlCore harness. |

## 2. Decision: verified CPU exists -> reuse

A RISC-V CPU with real evidence exists (`mcu_cpu`), so no external core was imported and no interim
controller was written. The ControlCore instantiates it as **RV32IM_Zicsr_Zifencei** (`RV32M = 1`: iterative,
data-independent 35-cycle MUL/DIV -- deterministic timing suits orchestration), machine mode only. The
riscv-tests were re-run in this environment on the vendored RTL (63/63; three documented exclusions). As MCU-I
states, this is **not** a RISC-V compliance claim.

## 3. What is new in this project

`rtl/cc_*.sv`, `rtl/silicaflux_control_core.sv`, `integration/silicaflux_cc_hpc_system.sv`, the address map and
generator (`config/`, `scripts/gen_memmap.py`), the boot ROM and firmware (`firmware/`), the testbenches
(`tb/`), the FPGA harness (`fpga/`), scripts and documentation. Everything under `third_party/` is unmodified
(`scripts/check_vendor.py`: 160/160 byte-identical to the repository archives).

## 4. Gaps found in the repository that this project does not close

* Firmware authentication / secure boot (Project 28) -- absent; reported as absent.
* RISC-V External Debug Module -- absent in every CPU in the repository.
* No physical FPGA board results anywhere in the repository; none here either.
* No license file in the repository (see `third_party/PROVENANCE.md`).
