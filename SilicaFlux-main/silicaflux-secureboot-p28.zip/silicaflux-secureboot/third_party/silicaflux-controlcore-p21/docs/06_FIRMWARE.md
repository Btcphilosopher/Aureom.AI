# 06 -- Firmware and boot ROM

## 1. Layout

```
firmware/
  Makefile                 reproducible build (boot ROM + firmware image)
  include/cc_hw.h          register access, CSR macros, image header (addresses ONLY from the generated map)
  include/generated/       cc_memmap.h (C + assembler), cc_memory.ld (linker MEMORY) -- generated from the YAML
  common/crt0.S            firmware startup: sp/gp, mtvec, .data copy, .bss clear, main()
  common/trap_entry.S      trap entry/exit: 34-word frame, trap_handler(frame), mret
  common/fw.ld             firmware link script (IMEM code after the 256-byte header, DMEM data/stack)
  common/crc32.c           CRC-32 shared by ROM (and matched by scripts/mkimage.py)
  bootrom/rom_start.S      reset entry, DMEM scrub, ROM trap entry
  bootrom/bootrom.c        boot stages, memory test, host / device-memory / warm boot, image checks
  bootrom/rom.ld           ROM link script (code in BOOTROM, .bss + stack in DMEM)
  app/fw.h                 firmware-wide declarations, self-test masks, check macros
  app/platform.c           trap handler, INTC dispatch, ISRs, timer tick, watchdog, system DMA, RAS
  app/accel.c              accelerator discovery / reset, interrupt-driven submit/wait, telemetry
  app/main.c               boot stages, POST, host-ready, mailbox command processor
  app/selftest.c           14-part self-test suite (+ destructive watchdog-reset test)
  app/libc_min.c           memcpy/memset/memcmp, console printf (host-visible DIAG FIFO)
third_party/silicaflux-hpc-m08-tile/sw/drivers/silicaflux_hpc.c   vector tile driver   (unmodified)
third_party/silicaflux-tensorcore08/sw/tsu_driver.c               tensor unit driver   (unmodified)
```

## 2. Toolchain and reproducible build

GNU `riscv64-unknown-elf-gcc` 13.2.0 (Ubuntu 24.04 package `gcc-riscv64-unknown-elf`), multilib rv32im/ilp32,
freestanding (no libc; libgcc for 64-bit division and soft-float reference arithmetic).

```bash
sudo apt-get install -y gcc-riscv64-unknown-elf verilator iverilog yosys nextpnr-ecp5 fpga-trellis python3-yaml
```

```bash
make -C firmware
```

The firmware compile step is equivalent to (from `firmware/`):

```bash
riscv64-unknown-elf-gcc -march=rv32im_zicsr_zifencei -mabi=ilp32 -Os -g -ffreestanding -fno-builtin -fno-tree-loop-distribute-patterns -nostdlib -nostartfiles -ffunction-sections -fdata-sections -fno-common -Iinclude -I../third_party/silicaflux-hpc-m08-tile/sw/include -I../third_party/silicaflux-tensorcore08/sw/include -Tcommon/fw.ld common/crt0.S common/trap_entry.S common/crc32.c app/main.c app/platform.c app/accel.c app/selftest.c app/libc_min.c ../third_party/silicaflux-hpc-m08-tile/sw/drivers/silicaflux_hpc.c ../third_party/silicaflux-tensorcore08/sw/tsu_driver.c -o build/fw/controlcore_fw.elf -Linclude/generated -Wl,--gc-sections -lgcc
```

followed by `objcopy -O binary` and `scripts/mkimage.py` (header + CRC32 -> `.img`, `.hex`, `.json`). The boot
ROM is built the same way with `bootrom/rom.ld` and converted to `rtl/generated/sfv_bootrom_image.sv` by the
vendored `gen_rom.py`. Sizes: ROM 2 088 bytes of 8 KiB; firmware image about 31 KB of 64 KiB IMEM;
.data + .bss about 12 KiB of 32 KiB DMEM (the rest is stack). Builds with `-Wall -Wextra` and no warnings.

## 3. Runtime structure

* **No RTOS, no heap.** A single main loop sleeps in `WFI` and wakes on the HOST interrupt (mailbox) or the
  20 000-cycle timer tick (watchdog service, timeouts).
* **Interrupt-driven completion** for every engine (doc 04). Every wait has a timeout.
* **Expected-trap probes** (`probe_rd/probe_wr`) turn bus errors into return codes; used by discovery (an absent
  accelerator page answers with an error) and by the tests.
* **Console:** `cprintf` writes to `MAILBOX.DIAG_TX` -- a 256-entry FIFO the host drains (`DIAG_RX`/`DIAG_POP`);
  never blocks (characters are dropped and `OVF` set when the host does not drain). The simulation and the FPGA
  harness also tap the stream (`diag_valid_o`).

## 4. Host command processor (mailbox protocol)

Host: write arguments to `H2F_MSG1..3`, the command to `H2F_MSG0`, then `H2F_RING` (raises the HOST
interrupt). Firmware answers in `F2H_MSG0 = status | cmd << 8 | seq << 16`, data in `F2H_MSG1..7`, then
`F2H_RING` (pin `host_irq_o`); the host acknowledges with `F2H_ACK`. One command at a time.

| Command | Arguments | Answer |
|---|---|---|
| `PING` 0x02 | MSG1 = token | MSG1 = token, MSG2 = firmware version |
| `RUN_SELFTEST` 0x03 | MSG1 = test mask (0 = all, bit 31 = destructive watchdog-reset test) | MSG1 = checks, MSG2 = fails |
| `GEMM` 0x10 | MSG1 = device address of a 12-word TENSORCORE 08 ABI v2 descriptor | MSG1..6 = raw completion record, MSG7 = driver-predicted error code |
| `VECTOR_KERNEL` 0x11 | MSG1 = device address of an 8-word tile descriptor | MSG1 = CPL_INFO, then SEQ, COUNT, RESULT, ERR_ADDR, CYCLES |
| `DMA_COPY` 0x12 | MSG1 = src, MSG2 = dst, MSG3 = bytes | MSG1 = 0 or DataFabric error code, MSG2 = bytes done |
| `PERF_DUMP` 0x20 | MSG1 = device address | MSG1 = words written (72) |
| `RAS_DUMP` 0x21 | -- | STATUS, WARN_COUNT, FATAL_COUNT, FIRST_SRC, FIRST_ADDR, warning bits seen, fatal bits seen |
| `SHUTDOWN` 0x7F | MSG1 = host-side failure count | MSG1 = firmware checks, MSG2 = firmware fails; then `TEST_CTRL` = DONE / FAIL |

Status codes: `OK 0, BUSY 1, BAD_CMD 2, ACC_ERROR 3, TIMEOUT 4, NO_DEVICE 5`. An accelerator error is reported
(`ACC_ERROR` + record) and the unit is recovered (`ERR_CLEAR` / `RESUME`) so the next command executes.
Unsolicited message at boot: `cmd = 0`, capabilities in MSG1..6 (doc 03).

## 5. Self-test suite (`RUN_SELFTEST`, mask bits = `ST_*` in app/fw.h)

| Bit | Test | Checks | Brief item |
|---|---|---|---|
| 0 | identity: misa/mimpid/mhartid, IDs, map version, sizes, features, honest security caps, boot measurement | 17 | firmware execution |
| 1 | MMIO read/write patterns, walking ones, masked fields, RO write / sub-word write / unmapped offset / absent page / bad soft-reset key refused, RAS sees them | 15 | MMIO read/write |
| 2 | unmapped load / store, ROM write, misaligned, EXT address with nothing behind it, execute-never fetch, illegal instruction, ecall, ebreak; RAS first-error capture | 15 | invalid address access |
| 3 | mtime, WFI + MTI tick, prescaler, MSI, mcycle / minstret | 8 | timer |
| 4 | INTC masking / priority / threshold; 7 real simultaneous sources served in priority order | 21 | interrupt delivery, simultaneous interrupts |
| 5 | system DMA DMEM <-> device memory, device <-> device, IRQ count, read error, poisoned memory, misalignment, recovery | 14 | DMA completion |
| 6 | vector KERNEL FADD/FMUL/FMADD (bit-exact vs soft-float), DMA + VEC + DMA pipeline (4 queued commands), sum reduction | 31 | vector command submission |
| 7 | tensor GEMM 8x8x16, 17x13x29, 4x4x4 INT32 and 8x8x32 INT8 requantised + ReLU (bit-exact vs RV32IM reference) | 21 | tensor command submission |
| 8 | concurrent GEMM + KERNEL + DMA, all results, overlap counter | 13 | orchestration |
| 9 | error handling and recovery (table in doc 05), accelerator-domain reset and rediscovery | 29 | error handling |
| 10 | RAS warning / fatal injection, firmware report, **parity error injection** -> bus error + fatal + scrub | 13 | RAS |
| 11 | perf counters: freeze / clear, exact tile and tensor counters, telemetry dump | 18 | performance counters |
| 12 | watchdog count / service / early warning | 7 | watchdog |
| 13 | PMU isolation (register page and data port refused) and clock gating | 9 | power management |
| 31 | watchdog timeout -> reset (destructive; checked after the warm boot) | -- | watchdog |

Total 231 checks; all pass on the RTL in every regression run.
