#!/usr/bin/env bash
# =============================================================================
# SilicaFlux ControlCore -- FPGA build (Yosys + nextpnr-ecp5 + Project Trellis)
#   fpga/build.sh            ControlCore harness for ULX3S (LFE5U-85F-CABGA381): synth, P&R, bitstream
#   fpga/build.sh system     Yosys resource estimate of ControlCore + vector tile + tensor unit (no P&R)
# env: SEED (default 1), FREQ (MHz constraint, default 25)
# Outputs in fpga/build/, summary in reports/fpga.md (scripts/fpga_report.py).
# No hardware run: the bitstream has never been loaded on a board.
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
B=fpga/build; mkdir -p $B
for t in yosys nextpnr-ecp5 ecppack; do command -v $t >/dev/null || { echo "ERROR: $t not found"; exit 2; }; done
INC="-I rtl/generated -I third_party/silicaflux-sramlib/rtl/mem -I third_party/silicaflux-sramlib/rtl/mem/backends/asic"
SRC="$(grep -v '^//\|^+' rtl/files.f | tr '\n' ' ')"
SEED=${SEED:-1}; FREQ=${FREQ:-25}

if [ "${1:-}" = system ]; then
  SYS_INC="$INC $(grep '^+incdir+' integration/files_system.f | sed 's/^+incdir+/-I /' | tr '\n' ' ')"
  SYS_SRC="$SRC $(grep -v '^//\|^+' integration/files_system.f | tr '\n' ' ')"
  echo "[fpga] yosys synth_ecp5 silicaflux_cc_hpc_system (resource estimate only)"
  yosys -q -l $B/yosys_system.log -p "read_verilog -defer -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE $SYS_INC $SYS_SRC; \
    hierarchy -top silicaflux_cc_hpc_system; synth_ecp5 -top silicaflux_cc_hpc_system; \
    tee -q -o $B/yosys_stat_system.txt stat" || { tail -20 $B/yosys_system.log; exit 1; }
  exit 0
fi

make -s -C firmware fw || exit 1
cp firmware/build/fw/controlcore_fw.hex $B/controlcore_fw.hex
echo "[fpga] yosys synth_ecp5 cc_fpga_top"
yosys -q -l $B/yosys.log -p "read_verilog -defer -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE $INC $SRC fpga/cc_fpga_top.sv; \
  hierarchy -top cc_fpga_top; synth_ecp5 -top cc_fpga_top -json $B/cc_fpga.json; tee -q -o $B/yosys_stat.txt stat" \
  || { tail -20 $B/yosys.log; exit 1; }
echo "[fpga] yosys per-module breakdown (-noflatten)"
yosys -q -l $B/yosys_hier.log -p "read_verilog -defer -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE $INC $SRC fpga/cc_fpga_top.sv; \
  hierarchy -top cc_fpga_top; synth_ecp5 -noflatten -top cc_fpga_top; tee -q -o $B/yosys_stat_hier.txt stat" > /dev/null
echo "[fpga] nextpnr-ecp5 --85k CABGA381, ${FREQ} MHz, seed $SEED"
nextpnr-ecp5 --85k --package CABGA381 --json $B/cc_fpga.json --lpf fpga/cc_ulx3s.lpf --textcfg $B/cc_fpga.config \
  --freq $FREQ --seed $SEED --report $B/nextpnr_report.json -l $B/nextpnr.log > /dev/null 2>&1
rc=$?
if [ $rc != 0 ] && ! { grep -aq "Program finished normally" $B/nextpnr.log && [ -s $B/cc_fpga.config ]; }; then
  tail -30 $B/nextpnr.log; exit 1
fi
echo "[fpga] ecppack"
ecppack --compress $B/cc_fpga.config $B/cc_fpga.bit || exit 1
sha256sum $B/cc_fpga.bit > $B/cc_fpga.bit.sha256
python3 scripts/fpga_report.py
