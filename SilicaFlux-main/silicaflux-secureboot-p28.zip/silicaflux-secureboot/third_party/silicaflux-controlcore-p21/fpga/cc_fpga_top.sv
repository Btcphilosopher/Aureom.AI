// =============================================================================
// SilicaFlux ControlCore :: cc_fpga_top -- FPGA harness (ULX3S, LFE5U-85F)
//
// A self-contained, bootable ControlCore build for an FPGA prototype:
//   * silicaflux_control_core with the FPGA SRAM backend (block RAM),
//     boot_mode = EXT: the boot ROM DMA-copies the firmware image from device
//     memory, checks it and starts it -- no host needed;
//   * cc_fpga_devmem: 64 KiB block RAM on the external data port, initialised
//     with the firmware image (fpga/build/controlcore_fw.hex) at offset 0, which
//     the ControlCore sees at CC_EXT_IMAGE_DEFAULT (every EXT address aliases
//     into this RAM by its low 16 bits);
//   * accelerator register port answers "absent" (the vector tile and tensor
//     unit do not fit next to the ControlCore in this harness; firmware reports
//     them NOT PRESENT and runs DEGRADED);
//   * console: every DIAG_TX character -> 256-byte FIFO -> UART TX 115200 8N1
//     (ftdi_txd); LEDs show host-ready, command-processor-ready, test status,
//     RAS fatal, CPU sleep and a heartbeat.
// NOT run on a board in this project: no hardware was available.
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module cc_fpga_top #(
  parameter        INIT_FILE = "fpga/build/controlcore_fw.hex",
  parameter int    BAUD_DIV  = 217                      // 25 MHz / 115200
) (
  input  wire logic       clk_25mhz,
  input  wire logic [0:0] btn,                          // btn[0]: active-low reset (PWR button)
  output logic            ftdi_rxd,                     // FPGA -> PC (console)
  output logic [7:0]      led,
  output logic            wifi_gpio0                    // keep the ESP32 from resetting the FPGA
);
  wire clk = clk_25mhz;
  assign wifi_gpio0 = 1'b1;

  // power-on reset: hold for 16 cycles after configuration, or while btn[0] is pressed
  logic [4:0] por_q = '0;
  always_ff @(posedge clk) if (!por_q[4]) por_q <= por_q + 5'd1;
  wire rst_n = por_q[4] && btn[0];

  logic        x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [31:0] x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [3:0]  x_req_wstrb;
  logic        host_irq, host_ready, cmdproc_ready, ras_fatal, diag_valid, test_done, test_fail, cpu_sleep;
  logic        hs_req_ready, hs_rsp_valid, hs_rsp_error;
  logic [31:0] hs_rsp_rdata;
  logic [7:0]  diag_char;
  logic [15:0] test_code;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        acc_rb_sel, acc_rb_we, acc_clk, acc_rst_n;
  logic [15:0] acc_rb_addr;
  logic [31:0] acc_rb_wdata;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_control_core #(.RV32M(1), .SRAM_PARITY(1), .SRAM_BACKEND(`SRAM_BACKEND_FPGA)) u_cc (
    .clk, .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(2'b01), .host_rst_req_i(1'b0),
    .hs_req_valid(1'b0), .hs_req_ready, .hs_req_write(1'b0), .hs_req_addr(32'd0), .hs_req_wdata(32'd0),
    .hs_req_wstrb(4'h0), .hs_rsp_valid, .hs_rsp_ready(1'b1), .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(host_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready), .ras_fatal_o(ras_fatal),
    .acc_rb_sel, .acc_rb_we, .acc_rb_addr, .acc_rb_wdata, .acc_rb_rdata(32'd0), .acc_rb_err(1'b1),
    .ext_req_valid(x_req_valid), .ext_req_ready(x_req_ready), .ext_req_write(x_req_write), .ext_req_addr(x_req_addr),
    .ext_req_wdata(x_req_wdata), .ext_req_wstrb(x_req_wstrb), .ext_rsp_valid(x_rsp_valid), .ext_rsp_ready(x_rsp_ready),
    .ext_rsp_rdata(x_rsp_rdata), .ext_rsp_error(x_rsp_error),
    .acc_clk_o(acc_clk), .acc_rst_no(acc_rst_n),
    .acc_vec_irq_i(1'b0), .acc_tsu_irq_i(1'b0), .acc_vec_busy_i(1'b0), .acc_tsu_busy_i(1'b0), .acc_tsu_halted_i(1'b0),
    .ext_warn_i(1'b0), .ext_fatal_i(1'b0),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep)
  );

  cc_fpga_devmem #(.WORDS(16384), .INIT_FILE(INIT_FILE)) u_devmem (
    .clk, .rst_n,
    .req_valid(x_req_valid), .req_ready(x_req_ready), .req_write(x_req_write), .req_addr(x_req_addr),
    .req_wdata(x_req_wdata), .req_wstrb(x_req_wstrb), .rsp_valid(x_rsp_valid), .rsp_ready(x_rsp_ready),
    .rsp_rdata(x_rsp_rdata), .rsp_error(x_rsp_error)
  );

  // ---------------------------------------------------------------- console UART
  logic [7:0] cf [256];
  logic [7:0] cwp, crp, tx_byte;
  logic [8:0] cnt_q;
  logic [3:0] bit_q;
  logic [9:0] sh_q;
  logic       busy_q;
  always_ff @(posedge clk) if (diag_valid && (cwp + 8'd1) != crp) cf[cwp] <= diag_char;
  assign tx_byte = cf[crp];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cwp <= '0; crp <= '0; cnt_q <= '0; bit_q <= '0; sh_q <= '1; busy_q <= 1'b0;
    end else begin
      if (diag_valid && (cwp + 8'd1) != crp) cwp <= cwp + 8'd1;
      if (!busy_q) begin
        if (crp != cwp) begin
          sh_q <= {1'b1, tx_byte, 1'b0}; crp <= crp + 8'd1; busy_q <= 1'b1; bit_q <= '0; cnt_q <= '0;
        end
      end else if (cnt_q == 9'(BAUD_DIV - 1)) begin
        cnt_q <= '0;
        sh_q  <= {1'b1, sh_q[9:1]};
        if (bit_q == 4'd9) busy_q <= 1'b0;
        bit_q <= bit_q + 4'd1;
      end else begin
        cnt_q <= cnt_q + 9'd1;
      end
    end
  end
  assign ftdi_rxd = busy_q ? sh_q[0] : 1'b1;

  logic [23:0] hb_q;
  always_ff @(posedge clk or negedge rst_n) if (!rst_n) hb_q <= '0; else hb_q <= hb_q + 24'd1;
  assign led = {hb_q[23], cpu_sleep, ras_fatal, test_fail, test_done, cmdproc_ready, host_ready, host_irq};

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^{hs_req_ready, hs_rsp_valid, hs_rsp_error, hs_rsp_rdata, test_code};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

// -----------------------------------------------------------------------------
// Block-RAM SFB2 slave with initial content (FPGA only: $readmemh is bitstream
// initialisation).  Every address aliases by its low log2(4*WORDS) bits.
// -----------------------------------------------------------------------------
module cc_fpga_devmem #(
  parameter int    WORDS     = 16384,
  parameter        INIT_FILE = ""
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        req_valid,
  output logic             req_ready,
  input  wire logic        req_write,
  input  wire logic [31:0] req_addr,
  input  wire logic [31:0] req_wdata,
  input  wire logic [3:0]  req_wstrb,
  output logic             rsp_valid,
  input  wire logic        rsp_ready,
  output logic [31:0]      rsp_rdata,
  output logic             rsp_error
);
  localparam int AW = $clog2(WORDS);
  logic [31:0] mem [WORDS];
  initial if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
  wire acc = req_valid && req_ready;
  wire [AW-1:0] a = req_addr[AW+1:2];
  always_ff @(posedge clk) begin
    if (acc && req_write) begin
      for (int b = 0; b < 4; b++) if (req_wstrb[b]) mem[a][8*b +: 8] <= req_wdata[8*b +: 8];
    end
    if (acc && !req_write) rsp_rdata <= mem[a];
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rsp_valid <= 1'b0;
    else if (acc) rsp_valid <= 1'b1;
    else if (rsp_ready) rsp_valid <= 1'b0;
  end
  assign req_ready = !rsp_valid;
  assign rsp_error = 1'b0;
endmodule

`default_nettype wire
