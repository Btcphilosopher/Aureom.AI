# third_party -- provenance (all files unmodified)

Project 28 (SecureSilicon) vendors everything Project 21 vendored, plus the Project 21 ControlCore blocks it reuses,
two MCU-I debug files, and two external, vetted cryptographic implementations. `SHA256SUMS` lists all 204 files.
`python3 scripts/check_vendor.py --repo <path to Aureom.AI>` re-reads the original repository archives and compares
every repository-derived file byte for byte (last run: **204 files, 0 problems**); the two external directories are
checked against `SHA256SUMS` and were compared byte for byte with fresh clones of the pinned upstream commits.

## Added by Project 28

| Directory | Origin | Pin | Licence | Used for |
|---|---|---|---|---|
| `silicaflux-controlcore-p21/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-controlcore.zip` (Project 21) | archive member, byte-identical | internal Aureom.AI | unmodified blocks `cc_sfb_gate`, `cc_sysctrl`, `cc_mailbox`, `cc_perf`, `cc_pmu`, `cc_ras`; the P21 originals of the files P28 modified (`silicaflux_control_core.sv`, `cc_secmon.sv`, `cc_memmap.yaml`, `bootrom.c`, `rom_start.S`, `mkimage.py`, README, docs) kept for review/diff; the P21 FPGA harness (`fpga/`, `tb/tb_fpga_top.sv`), the P21 ControlCore mock test and P21 `scripts/fpga_report.py`, `package.sh` (not updated for v2, reference only) |
| `silicaflux-v/rtl/debug/sfv_jtag.sv`, `silicaflux-v/rtl/pkg/sfv_pkg.sv` | MCU-I archive, `third_party/silicaflux-v/` | byte-identical | internal | JTAG TAP + debug module (SBA, DBGCTRL), lifecycle-gated in the ControlCore v2 |
| `secworks-sha256/` | https://github.com/secworks/sha256 (Joachim Strömbergson) | commit `837c5cc396f001d18f2c765721c585716eb439ae` (2025-12-15) | BSD-2-Clause (`LICENSE`) | SHA-256 compression core: `sha256_core.v` (81ea4b86…), `sha256_w_mem.v` (0b4de636…), `sha256_k_constants.v` (78a9600a…) |
| `monocypher-4.0.2/` | https://github.com/LoupVaillant/Monocypher | tag `4.0.2`, commit `0d85f98c9d9b0227e42cf795cb527dff372b40a4` | BSD-2-Clause **or** CC0-1.0 (`LICENCE.md`) | Ed25519 verification in the boot ROM: `src/monocypher.c` (02174117…), `src/monocypher.h` (fcaf6ed7…), `src/monocypher-ed25519.c` (97d58163…, from `src/optional/`), `src/monocypher-ed25519.h` (3a303518…, from `src/optional/`) |

Test vectors (not under `third_party/`, hashes in `vectors/SHA256SUMS`): NIST CAVP SHA-256 Short/Long/Monte and the
djb/SUPERCOP Ed25519 `sign.input` from pyca `cryptography_vectors` 44.0.0 (PyPI sdist; Apache-2.0 / BSD), and
Wycheproof `ed25519_test.json` from https://github.com/C2SP/wycheproof commit `d5f724a21e449bbf8f142e032a6bf86884f2851c`
(Apache-2.0). Licence files are next to each set.

## Inherited from Project 21

| Directory | Origin archive (repository path) | Archive SHA-256 | Used for |
|---|---|---|---|
| `silicaflux-mcu-i/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-mcu-i.zip` | `f2dd5bdac590883a3949c38a1973f32a8651c42bdc46569fee9f4d29f5013c23` | **CPU** `mcu_cpu` (RV32I[M]_Zicsr, riscv-tests evidence), `mcu_intc`, `mcu_wdt`, `mcu_dma`, `mcu_sram_bank`, `mcu_memmap_pkg` (register offsets of those blocks), CPU ISA testbench `tb/cpu/tb_cpu.sv`, MCU-I's CPU doc and recorded riscv-tests result |
| `silicaflux-v/` | same archive, `third_party/silicaflux-v/` (SilicaFlux-V release 1) | (as above) | `sfv_common` (reset/level synchronisers), `sfv_clkgate`, `sfv_periph_bridge` (register bus), `sfv_periph_misc` (`sfv_timer`), `sfv_mem_slaves` (`sfv_bootrom`), `gen_rom.py`, `bin2hex.py` |
| `silicaflux-datafabric/` | MCU-I and TENSORCORE 08 archives, `third_party/silicaflux-datafabric/` (identical where both carry a file) | (as above / below) | SFB2 crossbar, arbiter, decoders, register slice, skid buffer, v1 slave adapter, protocol docs; DMA engines used inside the accelerators |
| `silicaflux-sramlib/` | MCU-I and TENSORCORE 08 archives (identical) | | SRAM wrapper library (generic / FPGA / ASIC-leaf backends) for IMEM and DMEM |
| `silicaflux-tensorcore08/` | `SilicaFlux-main/silicaflux-tensorcore08.zip` | `be676860442cc1b670223b3ef9e59a9aeaed7d3998615a70b7aa2e9bf0c45f06` | **tensor unit** `silicaflux_tensor_unit` + `integration/sfx_hpc_tensor_system.sv` (the accelerator subsystem the ControlCore drives), C driver `tsu_driver.c`, ABI header `tsu_abi.h`, ABI / register-map docs |
| `silicaflux-tensorcore02..07/`, `silicaflux-hpc-m04-scratchpad/` | same TENSORCORE 08 archive, `third_party/` | | systolic array, operand buffers, accumulator, quantiser, tile iterator, tensor DMA adapter, scratchpad |
| `silicaflux-hpc-m08-tile/rtl`, `docs/02..03`, `third_party/` | same TENSORCORE 08 archive, `third_party/silicaflux-hpc-m08-tile/` | | **FP32 vector tile** `silicaflux_hpc_tile` (vector array, scratchpad, tile DMA, command queue, counters) |
| `silicaflux-hpc-m08-tile/sw/`, `docs/06_host_software.md` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m08-tile.zip` | `fa2e5a893f637c8f4152d8252754df063b4e6a0fdc901448453f2fe6040ee3f8` | tile C driver `silicaflux_hpc.c`, generated register header `hpc_tile_regs.h` |

Each of those projects documents its own verification evidence and limitations in its archive (MCU-I
`reports/SUMMARY.md`, TENSORCORE 08 `README.md` / `reports/`, HPC Module 08 `README.md` / `reports/`). The
ControlCore re-ran the CPU's riscv-tests here (`reports/isa/`) and exercises the accelerators through their real
register ABIs (`reports/regression.md`); it does not re-run the accelerators' own unit regressions.

License: the source repository contains no license file; these are internal Aureom.AI sources. The owner must
add a license before any external distribution. riscv-tests (BSD-licensed, riscv-software-src) is fetched by
`scripts/run_riscv_tests.sh` into `deps/`, not redistributed.
