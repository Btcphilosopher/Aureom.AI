/* =============================================================================
 * SilicaFlux secure boot (Project 28) -- native host build of the ROM policy
 *
 * libsbref.so = firmware/sb/sb_policy.c (the exact source compiled into the
 * mask ROM) + Monocypher 4.0.2 (same files as the ROM) + this shim.  The only
 * substitution is the image hash: on the chip it is the hardware SHA-256
 * engine; here OpenSSL's SHA256() stands in for it.  ref/run_ref.py drives it
 * through ctypes and compares every result with tools/sbimage.py (independent
 * Python/OpenSSL implementation) and with published test vectors.
 * ===========================================================================*/
#include <stddef.h>
#include <string.h>
#include <openssl/sha.h>
#include "sb_policy.h"
#include "monocypher-ed25519.h"

int sbref_ed25519_check(const uint8_t sig[64], const uint8_t pk[32], const uint8_t *msg, size_t n) {
  return crypto_ed25519_check(sig, pk, msg, n);
}

int sbref_rom_ed25519_verify(const uint8_t sig[64], const uint8_t pk[32], const uint8_t *msg, size_t n) {
  return sb_ed25519_verify(sig, pk, msg, (uint32_t)n);
}

uint32_t sbref_manifest_check(const uint8_t *mbytes, uint32_t lc, uint32_t revoked, uint32_t min_svn,
                              uint32_t rollback) {
  sb_manifest_t m;
  memcpy(&m, mbytes, sizeof m);
  sb_ctx_t c = {lc, revoked, min_svn, rollback, CC_SB_TARGET_ID, CC_SB_HW_VERSION};
  return sb_manifest_check(&m, &c);
}

/* Same sequence as the ROM's verify step (firmware/bootrom/bootrom.c): the ROM
 * copies the manifest out of (sealed) IMEM, checks it, hashes the payload,
 * verifies the signature, compares digests in constant time. */
uint32_t sbref_verify_imem(const uint8_t *imem, uint32_t imem_size, uint32_t lc, uint32_t revoked,
                           uint32_t min_svn, uint32_t rollback) {
  sb_manifest_t m;
  uint8_t d[32];
  if (imem_size != CC_IMEM_SIZE) return 0xFFu;
  memcpy(&m, imem, sizeof m);
  sb_ctx_t c = {lc, revoked, min_svn, rollback, CC_SB_TARGET_ID, CC_SB_HW_VERSION};
  uint32_t e = sb_manifest_check(&m, &c);
  if (e != CC_BOOT_ERR_NONE) return e;
  SHA256(imem + m.image_offset, m.image_length, d);
  e = sb_signature_check(&m);
  if (e != CC_BOOT_ERR_NONE) return e;
  return sb_ct_equal(d, m.image_digest, 32) ? CC_BOOT_ERR_NONE : CC_BOOT_ERR_DIGEST;
}
