#!/usr/bin/env python3
"""SilicaFlux secure boot (Project 28) -- software verification reference run.

Step 1 of the brief ("start with a software-validated image format and
verification reference").  Writes reports/ref.md.  Checks:

 A. Ed25519, independent known-good vectors, on BOTH verifiers:
      Monocypher 4.0.2 crypto_ed25519_check (the ROM code, native build) and
      OpenSSL (via `cryptography`, used by the signer and the Python reference):
      * djb/SUPERCOP sign.input (1024 vectors; vectors 1-3 = RFC 8032 7.1 TEST 1-3):
        valid signature accepted; signature with one bit flipped rejected;
        message with one bit flipped rejected; OpenSSL re-signs bit-exactly.
      * Wycheproof ed25519_test.json: "valid" accepted, "invalid" rejected.
 B. SHA-256 NIST CAVP Short/Long messages on hashlib (sanity of the reference
    used to build manifests; the RTL engine is checked against the same files
    in tb/unit/tb_sb_sha256.sv).
 C. Security corpus (tools/mkvectors.py, synthetic payload): the Python
    reference and the native ROM policy must both return the specified code.
 D. Differential fuzzing: random manifest mutations x random device contexts,
    Python check_manifest == C sb_manifest_check (no expected values needed).
"""
import ctypes
import hashlib
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))
import sbimage as S  # noqa: E402
import mkvectors as V  # noqa: E402
from cryptography.exceptions import InvalidSignature  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey  # noqa: E402

M = S.M
lib = ctypes.CDLL(os.path.join(HERE, "build", "libsbref.so"))
lib.sbref_ed25519_check.restype = ctypes.c_int
lib.sbref_ed25519_check.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_size_t]
lib.sbref_rom_ed25519_verify.restype = ctypes.c_int
lib.sbref_rom_ed25519_verify.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_size_t]
lib.sbref_manifest_check.restype = ctypes.c_uint32
lib.sbref_manifest_check.argtypes = [ctypes.c_char_p] + [ctypes.c_uint32] * 4
lib.sbref_verify_imem.restype = ctypes.c_uint32
lib.sbref_verify_imem.argtypes = [ctypes.c_char_p] + [ctypes.c_uint32] * 5

report, fails = [], 0


def mono_ok(sig, pk, msg):
    return lib.sbref_ed25519_check(sig, pk, msg, len(msg)) == 0


def rom_ok(sig, pk, msg):
    return lib.sbref_rom_ed25519_verify(sig, pk, msg, len(msg)) == 0


def ossl_ok(sig, pk, msg):
    try:
        Ed25519PublicKey.from_public_bytes(pk).verify(sig, msg)
        return True
    except (InvalidSignature, ValueError):
        return False


def section(title, rows, total, bad):
    global fails
    fails += bad
    report.append(f"## {title}\n\n**{total - bad} / {total} PASS**\n")
    if rows:
        report.extend(rows)
    report.append("")


def part_a():
    # --- djb sign.input
    path = os.path.join(ROOT, "vectors", "ed25519_djb", "sign.input")
    n = bad = 0
    rows = []
    for ln, line in enumerate(open(path)):
        f = line.rstrip("\n").split(":")
        sk, pk, msg, sm = bytes.fromhex(f[0]), bytes.fromhex(f[1]), bytes.fromhex(f[2]), bytes.fromhex(f[3])
        sig = sm[:64]
        checks = [
            ("valid accepted (Monocypher)", mono_ok(sig, pk, msg)),
            ("valid accepted (ROM verifier)", rom_ok(sig, pk, msg)),
            ("valid accepted (OpenSSL)", ossl_ok(sig, pk, msg)),
            ("bit-flipped signature rejected (Monocypher)", not mono_ok(bytes([sig[0] ^ 1]) + sig[1:], pk, msg)),
            ("bit-flipped signature rejected (ROM verifier)", not rom_ok(bytes([sig[0] ^ 1]) + sig[1:], pk, msg)),
            ("bit-flipped signature rejected (OpenSSL)", not ossl_ok(bytes([sig[0] ^ 1]) + sig[1:], pk, msg)),
            ("OpenSSL re-sign is bit-exact", Ed25519PrivateKey.from_private_bytes(sk[:32]).sign(msg) == sig),
        ]
        if msg:
            mm = bytes([msg[0] ^ 0x80]) + msg[1:]
            checks.append(("modified message rejected (Monocypher)", not mono_ok(sig, pk, mm)))
            checks.append(("modified message rejected (ROM verifier)", not rom_ok(sig, pk, mm)))
        for what, ok in checks:
            n += 1
            if not ok:
                bad += 1
                rows.append(f"* FAIL vector {ln + 1}: {what}")
    section(f"A1. Ed25519 djb/SUPERCOP sign.input (1024 vectors, RFC 8032 TEST 1-3 = lines 1-3) -- {n} checks",
            rows, n, bad)
    # --- Wycheproof
    j = json.load(open(os.path.join(ROOT, "vectors", "wycheproof", "ed25519_test.json")))
    n = bad = 0
    rows = []
    stats = {"valid": 0, "invalid": 0, "acceptable": 0}
    disagree = []
    raw_dev = []
    for g in j["testGroups"]:
        pk = bytes.fromhex(g["publicKey"]["pk"])
        for t in g["tests"]:
            sig, msg = bytes.fromhex(t["sig"]), bytes.fromhex(t["msg"])
            r = t["result"]
            stats[r] += 1
            raw = mono_ok(sig, pk, msg) if len(sig) == 64 else False
            mo = rom_ok(sig, pk, msg) if len(sig) == 64 else False
            os_ = ossl_ok(sig, pk, msg) if len(sig) == 64 else False
            if raw != (r == "valid") and r != "acceptable":
                raw_dev.append(f"tcId {t['tcId']} ({r}, {t['comment']}): raw Monocypher "
                               f"{'accepted' if raw else 'rejected'}; ROM verifier {'accepted' if mo else 'rejected'}")
            if mo != os_:
                disagree.append(f"tcId {t['tcId']} ({r}, {t['comment']}): ROM verifier={mo} OpenSSL={os_}")
            if r == "acceptable":
                continue
            n += 1
            if mo != (r == "valid"):
                bad += 1
                rows.append(f"* FAIL tcId {t['tcId']} ({t['comment']}, flags {t['flags']}): expected {r}, "
                            f"ROM verifier {'accepted' if mo else 'rejected'}")
    rows.append(f"* vector set: {stats}; ROM verifier vs OpenSSL disagreements (incl. 'acceptable'): {len(disagree)}")
    rows.extend(f"  * {d}" for d in disagree)
    rows.append(f"* raw Monocypher 4.0.2 deviations from the expected result (closed by the ROM's RFC 8032 "
                f"5.1.3 R check): {len(raw_dev)}")
    rows.extend(f"  * {d}" for d in raw_dev)
    disagree = []
    rows.extend(f"  * {d}" for d in disagree)
    section(f"A2. Ed25519 Wycheproof ed25519_test.json (C2SP/wycheproof) -- ROM verifier verdict vs expected", rows, n, bad)


def part_b():
    n = bad = 0
    rows = []
    for fn in ("SHA256ShortMsg.rsp", "SHA256LongMsg.rsp"):
        ln = None
        for line in open(os.path.join(ROOT, "vectors", "nist_cavp_sha256", fn)):
            line = line.strip()
            if line.startswith("Len ="):
                ln = int(line.split("=")[1])
            elif line.startswith("Msg =") and ln is not None:
                msg = bytes.fromhex(line.split("=")[1].strip())[: ln // 8]
            elif line.startswith("MD =") and ln is not None:
                n += 1
                if hashlib.sha256(msg).hexdigest() != line.split("=")[1].strip():
                    bad += 1
                    rows.append(f"* FAIL {fn} Len={ln}")
                ln = None
    section("B. SHA-256 NIST CAVP ShortMsg + LongMsg on hashlib (reference sanity)", rows, n, bad)


def ctx_args(c):
    ctx = S.Ctx(c["lc"], c["revoked"], c["min_svn"], c["rollback"])
    return ctx, (ctx.lc, ctx.revoked, ctx.min_svn, int(ctx.rollback))


def part_c():
    payload, entry = V.synthetic_payload()
    cases = V.make_cases(payload, entry)
    n = bad = 0
    rows = ["| case | requirement | context | expected | Python ref | ROM policy (native) |", "|---|---|---|---|---|---|"]
    for c in cases:
        ctx, args = ctx_args(c)
        py, _ = S.verify_image(c["img"], ctx)
        cc = lib.sbref_verify_imem(S.imem_view(c["img"]), M.CC_IMEM_SIZE, *args)
        n += 1
        ok = (py == c["expect"] == cc)
        bad += not ok
        ctxs = f"{c['lc']}" + (f" revoked=0x{c['revoked']:x}" if c["revoked"] else "") + \
               (f" min_svn={c['min_svn']}" if c["min_svn"] else "") + (" rollback_cfg=1" if c["rollback"] else "")
        rows.append(f"| {'' if ok else '**FAIL** '}{c['name']} | {c['req']} | {ctxs} | {S.err_name(c['expect'])} | "
                    f"{S.err_name(py)} | {S.err_name(cc)} |")
    section(f"C. Security image corpus ({n} cases): specified code == Python reference == native ROM policy", rows, n, bad)


def part_d(iters=20000, seed=28):
    rnd = random.Random(seed)
    payload, entry = V.synthetic_payload()
    ks, _ = V.keyfiles()
    base = S.build_image(payload, entry, V.key(ks[1]), 1, svn=5)
    m0 = S.unpack(base)
    ints = [f for f in S.FIELDS if isinstance(m0[f], int)]
    interesting = [0, 1, 2, 3, 4, 0x20, 0x21, 0xFF, 0x100, 0x200, 0xFFFF, 0x10000, 0x10100, 0x1FF00, 0x1FFFC, 0x20000,
                   M.CC_IMEM_BASE, M.CC_IMEM_BASE + 0x100, M.CC_IMEM_SIZE - 0x100, M.CC_SB_TARGET_ID,
                   M.CC_SB_HW_VERSION, M.CC_SB_HW_VERSION + 1, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFC, 0xFFFFFFFF]
    n = bad = 0
    rows = []
    codes = {}
    for _ in range(iters):
        m = dict(m0)
        for _k in range(rnd.choice([1, 1, 1, 2, 3])):
            f = rnd.choice(ints + ["reserved1"])
            if f == "reserved1":
                r = bytearray(64)
                if rnd.random() < 0.5:
                    r[rnd.randrange(64)] = rnd.randrange(1, 256)
                m[f] = bytes(r)
            else:
                width = 0xFFFF if f in ("manifest_version", "manifest_size") else 0xFFFFFFFF
                v = rnd.choice(interesting + [rnd.getrandbits(32)]) if rnd.random() < 0.8 else m0[f] + rnd.randint(-8, 8)
                m[f] = v & width
        ctx = S.Ctx(rnd.choice(list(S.LC)), rnd.getrandbits(4), rnd.randrange(0, 34), rnd.getrandbits(1))
        py = S.check_manifest(m, ctx)
        cc = lib.sbref_manifest_check(S.pack(m), ctx.lc, ctx.revoked, ctx.min_svn, int(ctx.rollback))
        n += 1
        codes[S.err_name(py)] = codes.get(S.err_name(py), 0) + 1
        if py != cc:
            bad += 1
            if len(rows) < 20:
                rows.append(f"* FAIL: Python {S.err_name(py)} vs C {S.err_name(cc)} for {m}")
    rows.append("* outcome distribution: " + ", ".join(f"{k} {v}" for k, v in sorted(codes.items())))
    section(f"D. Differential fuzzing of the manifest policy ({iters} random mutations, seed {seed}): Python == C",
            rows, n, bad)


def main():
    t0 = time.time()
    part_a()
    part_b()
    part_c()
    part_d()
    hdr = ["# Software verification reference (Project 28, step 1)", "",
           "Generated by `ref/run_ref.py` (`make ref`).  Native ROM policy = `firmware/sb/sb_policy.c` + Monocypher 4.0.2, "
           "compiled with host gcc into `ref/build/libsbref.so` (OpenSSL SHA256 stands in for the hardware hash).  "
           "Python reference = `tools/sbimage.py` (hashlib + OpenSSL Ed25519 through `cryptography`).", "",
           f"**Overall: {'PASS' if fails == 0 else 'FAIL'}** ({fails} failing checks, {time.time() - t0:.1f} s)", ""]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "ref.md"), "w") as f:
        f.write("\n".join(hdr + report) + "\n")
    for line in hdr[4:5] + [r for r in report if r.startswith("## ") or r.startswith("**")]:
        print(line)
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
