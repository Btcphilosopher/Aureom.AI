# 00 — Repository and threat audit

Scope (brief §1): boot ROM, firmware, ControlCore, DMA, DataFabric, debug interfaces, key storage, existing
cryptographic IP, reset mechanisms. Baseline: the Project 21 ControlCore archive
(`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-controlcore.zip`). Its regression was re-run here
unchanged before any modification (Verilator 5.020, gcc 13.2): **6/6 PASS** (boot_host 2.79 M cycles).

## 1. What exists

| Area | Found | Relevance |
|---|---|---|
| Boot ROM | `firmware/bootrom/` (P21), 8 KiB mask ROM, CRC32 image check | replaced by the secure ROM (32 KiB) |
| Firmware | P21 C firmware, CRC32 image header (`scripts/mkimage.py`) | kept; header replaced by the signed manifest |
| ControlCore | `silicaflux_control_core.sv`, RV32IM `mcu_cpu` (MCU-I), crossbar (DataFabric), 4 masters | extended to v2 |
| System DMA | `mcu_dma` (MCU-I, DataFabric-derived): validation before access, peripheral rule | kept unmodified, put behind `sb_dma_guard` |
| Accelerator DMA | vector tile DMA (HPC M05), tensor DMA (TC07) on the accelerator fabric | reach device memory + tile SPM only (structural) |
| DataFabric | `sfb_crossbar` with a static master→slave access matrix | used for the coarse layer of isolation |
| HostLink (P25) | DMA windows with 65-bit range arithmetic; documents reliance on the host IOMMU | same conventions reused for the DMA guard |
| Debug | MCU-I `sfv_jtag.sv`: TAP + **system-bus access (SBA, arbitrary read/write)**, CPU hold, system reset, boot-mode override; **not integrated in P21** | integrated here, lifecycle-gated |
| Key storage | none; no OTP/eFuse macro anywhere (sramlib + PDK SRAM leaf cells only) | a fuse **model** only (`sb_otp_model`), never claimed as OTP |
| Crypto IP | none suitable: `silicafluxbitcoinasic.zip` has generated SHA-256d mining datapaths (no padding/streaming, not vetted); `sha256-learn-r-asic-ml-optimizer.zip` is R modelling code | vetted external IP used instead (05_CRYPTOGRAPHY) |
| Resets | POR (rst_ni), soft (key), watchdog, host pin; async assert / sync release; POR-domain cause/count/scratch | kept; fuse model and failure counter added to the POR domain |

## 2. Findings in the Project 21 baseline (before Project 28)

| # | Finding | Severity (for a secure boot) | Resolution in P28 |
|---|---|---|---|
| F1 | CRC32 only — no authentication (P21 says so) | critical | Ed25519 + SHA-256 secure boot |
| F2 | The host can **write DMEM while the boot ROM runs** (access matrix HOST→DMEM; the lock is set by firmware later). DMEM holds the ROM's stack → the host can overwrite return addresses → code execution in ROM context | critical | host filter (hardware): DMEM never host-accessible; matrix HOST→DMEM removed |
| F3 | Time-of-check/time-of-use: the host can rewrite IMEM after the CRC check and before/after the jump | critical | SEAL: IMEM write-protected for every master at the IMEM slave port before measurement |
| F4 | The host can program the system DMA through the peripheral window → DMA writes IMEM/DMEM, bypassing the host lock | critical | host filter refuses DMA/DMA_GUARD pages; DMA guard windows; matrix DMA→PERIPH removed |
| F5 | The host can write the write-once `SECURITY.BOOT_MEASURE` before the ROM → measurement spoofing | high | register removed; measurement = hardware SHA-256 (read-only) |
| F6 | The host can write SYSCTRL (SOFT_RESET, BOOT_STAGE…), RAS (INJECT, PAR_INJECT), PMU, WDT, INTC (CLAIM read side effect), timer | high | allow-list host filter |
| F7 | `DMA_COPY` mailbox command takes host addresses → confused deputy (DMA into firmware/stack) | high | DMA guard (default deny, firmware least-privilege windows, locked) |
| F8 | Warm boot restarts the retained image after header + CRC only | high | warm boot re-seals and fully re-authenticates |
| F9 | No W^X: running code writable by CPU and DMA | medium | execute window read-only after hand-off (IMEM gate); fetch only inside the window |
| F10 | `test_mode` pin bypasses the reset synchronisers, ungated | medium | gated by lifecycle (DEV only) |
| F11 | MCU-I JTAG SBA = full bus access; if integrated as is, a complete bypass | high (if integrated) | integrated with SBA/CPU hold/reset/boot override gated by lifecycle |
| F12 | No key storage hardware | — | ROM-embedded public keys + fuse model; limitation documented |
| F13 | No vetted crypto IP in the repository | — | secworks SHA-256, Monocypher 4.0.2 |
| F14 | Accelerator DMA can write the device-memory image store | medium | verify-after-copy on the sealed IMEM copy (TOCTOU-safe); store read-only for the system DMA |
| F15 | `sfv_bootrom` range check `{1'b0,addr[13:2]} < 13'(WORDS)` truncates WORDS = 8192 to 0: at most 8191 words | bug (found by the first P28 boot: ROM read zeros) | `sb_bootrom` (same contract, bound sized from AW); vendored file unmodified |
| F16 | Accelerator-domain and RAS behaviour | — | unchanged |

## 3. Reuse decisions

* Unmodified, byte-identical (checked by `scripts/check_vendor.py --repo`): all P21 third-party sources, the six
  P21 blocks `cc_sfb_gate`, `cc_sysctrl`, `cc_mailbox`, `cc_perf`, `cc_pmu`, `cc_ras` (now under
  `third_party/silicaflux-controlcore-p21/`), MCU-I `sfv_jtag.sv` and `sfv_pkg.sv`.
* Vetted external IP, unmodified: secworks/sha256 (commit `837c5cc`), Monocypher 4.0.2 (tag commit `0d85f98`).
* Modified (diff against the P21 originals kept in `third_party/silicaflux-controlcore-p21/`):
  `silicaflux_control_core.sv`, `cc_memmap.yaml` (map v1.0 → v2.0), boot ROM, firmware (manifest, DMA windows,
  security commands, self-test T16), testbench `tb_cc_system.sv`.
* Retired: `cc_secmon.sv` (status-only), CRC32 image format (`mkimage.py`, `crc32.c`), firmware `HOST_LOCK`.
