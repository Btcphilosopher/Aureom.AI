# 12 — Security review

**This is a self-review of a prototype. It is not a certification.** Passing the unit and regression tests shows
that the implemented checks behave as specified in simulation; it does not show that the chip is secure. Nothing
here has run on an FPGA board or on silicon.

## 1. Hardware trust assumptions

1. Mask ROM content cannot be changed after manufacture and is fetched correctly (on an FPGA: the bitstream is
   trusted — a bitstream attacker owns the device).
2. `silicaflux_secure_boot`, `sb_access_policy`, the gates, `sb_dma_guard`, `sb_sha256_*`, the crossbar access
   matrix and `mcu_cpu` are implemented as written (no netlist tampering, no synthesis bug that drops a check).
3. Single clean clock and reset; no glitching (A6 out of the evaluated scope).
4. Fuses are persistent and one-way — **false in this prototype** (fuse model).
5. Only the ControlCore CPU, the host port, the system DMA, the secure-boot reader and the JTAG port are bus
   masters of the ControlCore; the accelerator fabric cannot master into it (true by construction here; must stay
   true in any SoC integration).

## 2. Side-channel exposure

| Channel | Exposure | Assessment |
|---|---|---|
| Timing of verification | Ed25519 verification and manifest checks are variable time | no secret involved (public key, public signature, public image) |
| Timing of digest compare | constant time in software; single-cycle 256-bit compare in hardware | not needed for secrecy; avoids a comparison oracle anyway |
| Power/EM | not analysed by measurement | no device key exists to extract; future device secrets (attestation keys, encryption) would require a dedicated SCA-hardened design and evaluation |
| Error/status oracle | codes reveal which check failed | acceptable: every input is public; an attacker learns nothing that helps forge |

## 3. Fault-injection exposure

The signature decision is made by software on the ControlCore CPU. A single successful glitch of the ROM
(skipping `sb_signature_check`'s branch) is mitigated, not prevented:

* the attacker must also make the two-token sequence happen (two specific stores of complementary constants that
  are only executed on the success path), and the hardware still requires the measured digest to equal the digest
  in the manifest, so the payload must still match a manifest — but an attacker-built manifest with a forged
  signature and a matching digest of attacker code **would pass the hardware checks if the ROM's signature branch
  and token stores are both glitched**. The signature check itself is not duplicated (cost: a second ≈ 6 M-cycle
  verification). Recommended before production: double verification with a random delay, or a hardware
  signature verifier, plus glitch detectors and an evaluation.
* Glitching the hardware state register is mitigated by sparse encoding and the separate pass flag (single-bit
  upsets); multi-bit or targeted faults are not.
* Faults on the hardware gates themselves (fetch gate, IMEM gate, host filter, DMA guard comparators) are out of
  the evaluated scope; each is a single comparator path without redundancy.
* The KAT detects a broken SHA-256 datapath at reset only, not a transient fault during the measurement.

## 4. Key-storage limitations

* Root public keys in mask ROM: immutable, but changeable only by a new mask. Three production slots.
* Private keys in this repository are **test keys derived from public labels**. A product needs an HSM key
  ceremony and HSM-backed signing; neither exists here.
* Revocation, lifecycle and minimum security version are held in `sb_otp_model`, a POR-domain register model:
  lost at power-off; on an FPGA chosen by whoever sets the tie-offs. **No OTP or eFuse security is claimed.**

## 5. Unauthenticated recovery paths

Searched for any path that leads to execution of unauthenticated code:

| Path | Status |
|---|---|
| Host-loaded image | authenticated |
| EXT (device-memory) image | authenticated after the copy (TOCTOU-safe) |
| Warm boot (soft / watchdog) | re-authenticated in full (P21 restarted after CRC only) |
| RECOVERY mode | authenticated, debug closed |
| LOCKDOWN | no execution of IMEM at all |
| JTAG in PROV/PROD/RECOVERY | no bus access, no CPU control |
| **JTAG in DEV** | **unauthenticated execution possible by design** (`debug_dev` demonstrates it) — DEV parts are not secure |
| `test_mode` pin | DEV only; no scan chains exist in this RTL (a tape-out flow must add lifecycle-gated scan) |
| Host register access to SECURITY / DMA / DMA_GUARD | refused |
| Firmware-provided DMA addresses | constrained by locked windows |
| ROM data / stack in DMEM | not host-accessible; DMA only through ROM-programmed one-shot windows |

No unauthenticated recovery path was found outside lifecycle DEV.

## 6. Unprotected interfaces

* **External data port / device memory**: no confidentiality, no integrity; anything the firmware reads from
  device memory (descriptors, operands, host commands) is attacker-controlled data and must be validated by the
  firmware (the P21 command processor validates descriptors through the accelerators' validators).
* **Mailbox**: unauthenticated host commands by design (the host is the device's user); commands that change
  security state (SVN commit, revocation, lifecycle) are executed by authenticated firmware and constrained by
  hardware rules — a production firmware should additionally require an authenticated request (e.g. signed
  command) before committing them.
* **Accelerator DMA** (vector tile, tensor unit): confined to device memory and the tile scratchpad by their own
  validators; can corrupt shared data and the image store (not the boot).
* **Accelerator register pages**: reachable only by the ControlCore CPU (authenticated firmware) and, in DEV, the
  debugger.
* **RAS / ext_warn / ext_fatal inputs**: can cause isolation or reporting (availability), not execution.
* **JTAG TAP** (IDCODE/BYPASS) in every state; **recovery strap** pin (forces RECOVERY: availability only).

## 7. Required third-party review before any production use

1. Independent security architecture and RTL review of `silicaflux_secure_boot`, `sb_access_policy`,
   `sb_dma_guard`, the gates and the ControlCore integration, including formal verification of the gate
   properties (no IMEM write outside LOAD/W^X, no fetch outside the window, no host access outside the allow-list).
2. Code review of the boot ROM (`bootrom.c`, `sb_policy.c`) and of the Monocypher 4.0.2 build for RV32 with GCC 13
   (compiler-introduced issues), plus fuzzing of the ROM policy on the target.
3. Fault-injection and side-channel evaluation on silicon (or at least FPGA glitch testing), with the
   recommended double verification implemented first.
4. Real OTP/eFuse integration review (programming path, read path, test modes).
5. Key ceremony, HSM signing infrastructure and release process review.
6. DFT review: scan/BIST access tied to the lifecycle.
7. Certification-oriented evaluation if a scheme is targeted (e.g. Common Criteria, FIPS 140-3 for the module,
   SESIP) — none is claimed.
