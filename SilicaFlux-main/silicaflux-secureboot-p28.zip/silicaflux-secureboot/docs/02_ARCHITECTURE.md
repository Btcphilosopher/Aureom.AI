# 02 — Root-of-trust architecture

```
 Immutable Boot ROM  ->  Firmware Manifest  ->  Cryptographic Verification  ->  Authenticated Load  ->  Controlled Execution
 (32 KiB mask ROM)       (256 B, signed)        (Ed25519 in ROM,               (IMEM sealed; hash    (execute window = measured
                                                 SHA-256 in hardware)            of the sealed copy)     range, W^X, DMA windows)
```

## 1. Hardware / software split

| Function | Where | Why there |
|---|---|---|
| Boot flow, manifest parsing + policy | ROM (C, `firmware/bootrom/bootrom.c`, `firmware/sb/sb_policy.c`) | immutable, auditable, shared with the native reference build |
| Ed25519 signature verification | ROM (Monocypher 4.0.2 `crypto_ed25519_check` + RFC 8032 R check) | no vetted open hardware Ed25519 verifier exists in reach; a self-written curve datapath would be invented cryptography |
| SHA-256 of the image | hardware: `sb_sha256_wrapper` (secworks core + padding + KAT) fed by the block's own bus master | measures the bytes that become executable, independent of the ROM; ~60 k cycles for 34 KB |
| Seal, measurement, hand-off decision, execute window, W^X, ROM-fetch closure | hardware: `silicaflux_secure_boot` | not bypassable by ROM bugs, the host, the DMA or (outside DEV) the debugger |
| Host / fetch / IMEM / debug access rules | hardware: `sb_access_policy` + `cc_sfb_gate` instances | master-independent choke points |
| DMA access control | hardware: `sb_dma_guard` | descriptor validation + per-beat firewall |
| Lifecycle, revocation, minimum SVN | hardware: fuse **model** `sb_otp_model` + rules in `silicaflux_secure_boot` | one-way semantics enforced in logic |

## 2. Block diagram (ControlCore v2)

```
 mcu_cpu I ── fetch gate (ROM until first window fetch; IMEM only in the window) ──┐
 mcu_cpu D ────────────────────────────────────────────────────────────────────────┤
 host ─────── host gate  (sb_access_policy allow-list) ────────────────────────────┤        ┌─ s0 BOOTROM sb_bootrom (32 KiB)
 mcu_dma ──── DMA gate   (sb_dma_guard per-beat check) ────────────────────────────┼─ xbar ─┼─ s1 IMEM ── IMEM gate (seal, W^X) ── SRAM
 SBHASH ───── (silicaflux_secure_boot reader, matrix: IMEM only) ──────────────────┤ (6x5)  ├─ s2 DMEM
 JTAG SBA ─── debug gate (lifecycle DEV only) ─────────────────────────────────────┘        ├─ s3 PERIPH ── page 4 DMA (through sb_dma_guard)
                                                                                           │              page 17 SECURITY = silicaflux_secure_boot
                                                                                           │              page 18 DMA_GUARD = sb_dma_guard
                                                                                           └─ s4 EXT ── isolation gate ── accelerators / device memory
 POR domain: sb_otp_model (fuse MODEL: LC, REVOKE, SVN, CFG; failure counter), reset cause/count/scratch
```

Access matrix (coarse layer, `config/cc_memmap.yaml`): CPU_I {BOOTROM, IMEM}; CPU_D {all}; HOST {IMEM,
PERIPH}; DMA {IMEM, DMEM, EXT}; SBHASH {IMEM}; DBG {all, gated}. Finer rules are in the gates.

## 3. Secure-boot state machine (`rtl/silicaflux_secure_boot.sv`)

| State | IMEM writes | IMEM execute | ROM fetch | Left by |
|---|---|---|---|---|
| SELFTEST | no | no | yes | KAT done: LOAD, or LOCKDOWN (KAT fail / invalid lifecycle) |
| LOAD | yes (host, DMA with window, CPU) | no | yes | SEAL |
| SEALING | no | no | yes | every IMEM writer idle (IMEM gate idle, DMA idle) |
| SEALED | no | no | yes | HASH (parameters checked) or FAIL |
| HASHING | no | no | yes | digest done → HASHED; bus error → FAIL |
| HASHED | no | no | yes | HANDOFF (hardware checks) → PASS or FAIL; FAIL |
| FAIL | no | no | yes | RELOAD → LOAD (digest, EXPECT, tokens cleared) |
| PASS | outside the window only (CPU) | **window only** | until the first window fetch | reset only |
| LOCKDOWN | no | no | yes (ROM reports and parks) | reset only |

Encodings are sparse 8-bit codes with pairwise Hamming distance ≥ 4; any other value is LOCKDOWN.
Execution additionally needs the separate `pass_q` flag.

### Hand-off checks (all in hardware, evaluated on the HANDOFF command)

1. state = HASHED (the measurement was taken after the seal and is the latest one);
2. EXPECT (written by the ROM from the verified manifest) = DIGEST (measured), all 256 bits;
3. signature tokens written after this measurement, in order: `SB_TOKEN_A`, then `SB_TOKEN_B = ~A`;
4. ENTRY inside [HASH_BASE, HASH_BASE + HASH_LEN), word aligned;
5. KEY_SLOT allowed in the lifecycle (slot 0 = development: DEV only) and not revoked (fuse model);
6. IMAGE_SVN ≥ MIN_SVN and ≤ 32 when rollback is enforced.

A refusal sets STATUS[31:24] (`SB_HREF_*`), moves to FAIL and counts a failure.

## 4. Register interface

Page 17 `SECURITY` and page 18 `DMA_GUARD`: full tables in [MEMORY_MAP.md](MEMORY_MAP.md) (generated from
`config/cc_memmap.yaml`). Write privilege: ROM-phase registers (CMD, HASH_*, ENTRY, KEY_SLOT, IMAGE_SVN,
SIG_TOKEN, EXPECT, FAIL_CODE) only before PASS; firmware-phase registers (SVN_COMMIT, REVOKE_SET, LC_ADVANCE,
VIOL_STATUS) only in PASS. Only the CPU can reach them: the host filter refuses every write to these pages, the
DMA has no peripheral access, the debugger only in DEV. Refused writes answer a bus error and are logged.

## 5. Lifecycle (from the fuse model, latched at each system reset)

DEV (blank) → PROV → PROD, one-way; RECOVERY = PROV/PROD + recovery strap or ≥ 3 consecutive failures;
invalid code → LOCKDOWN. Details: [09_LIFECYCLE_DEBUG.md](09_LIFECYCLE_DEBUG.md).

## 6. Clocks and resets

One clock. All secure-boot state is in the **system** reset domain: any reset (POR, soft, watchdog, host, debug
in DEV) returns to SELFTEST → LOAD with execution closed. Only the fuse model and the failure counter are in the
POR domain. The system reset is held until the fuse model has been sensed.

## 7. Area (Yosys 0.33 `synth_ecp5` estimate, reports/synth.md — no place-and-route)

| Block | LUT4 | FF |
|---|---|---|
| `silicaflux_secure_boot` (total, incl. SHA-256 wrapper) | 12 566 | 2 781 |
| of which `sb_sha256_wrapper` (secworks core 4 735 LUT4 + padding + KAT) | 5 965 | 1 859 |
| `sb_dma_guard` (4 windows, 33-bit comparators) | 2 157 | 532 |
| `sb_access_policy` | 129 | 0 |
| `sb_otp_model` (register model) | 274 | 133 |

The remaining ≈ 6.6 k LUT4 of the secure-boot block are mostly the 256-bit DIGEST/EXPECT registers, their
comparator and the register read multiplexer; an area-optimised version could keep EXPECT in the ROM's DMEM and
compare word-serially. Not included: the 32 KiB ROM (block RAM / ROM macro), the four extra `cc_sfb_gate`
instances and the single-cycle multiplier of RV32M = 2.

## 8. Performance

Authentication of the 34 KB firmware: **≈ 6.4 M cycles** from IMAGE_READY (≈ 257 ms at 25 MHz):
≈ 61 k cycles hardware SHA-256 + ≈ 6.2 M cycles Ed25519 on RV32IM (single-cycle multiply). The Ed25519 field
arithmetic is multiply-bound; with the P21 iterative multiplier (RV32M = 1: 35 cycles per MUL/MULH instead of 1)
it would be substantially slower (not measured), which is why the ControlCore v2 default is RV32M = 2.

## 9. Changes against Project 21 (for review)

| File | Change |
|---|---|
| `config/cc_memmap.yaml` | v2.0: BOOTROM 8 → 32 KiB; masters SBHASH, DBG; HOST matrix −BOOTROM −DMEM; DMA matrix −PERIPH; page 17 → `silicaflux_secure_boot`, new page 18; enums BOOT_ERR (CRC codes retired), SB_*, DG_*, MBOX_CMD SB_*; secure-boot constants |
| `scripts/gen_memmap.py` | block prefixes SEC/DG; generated-name collision check; page-range message |
| `rtl/silicaflux_control_core.sv` | see its header: RV32M default 2, MIMPID 0x0028_0001, gates, guard, SBC, fuse model, JTAG, test-mode gating, resets |
| `rtl/sb_*.sv`, `rtl/silicaflux_secure_boot.sv` | new |
| `firmware/bootrom/*` | new secure ROM; `rom.ld` 8 KiB stack reservation |
| `firmware/app/*` | manifest instead of CRC header; DMA windows + lock; guard-aware `dma_start`; `.dmabuf`; SB mailbox commands; self-test T1/T3/T5/T6 updates + T16; no firmware host lock |
| `firmware/common/fw.ld` | `.dmabuf` section |
| `integration/silicaflux_cc_hpc_system.sv` | new ports passed through; RV32M 2 |
| `tb/tb_cc_system.sv` | new ports; P28 status/host-filter checks; DIGEST instead of CRC in `bad_image`; longer timeouts |
