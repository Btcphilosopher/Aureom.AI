# 01 — Threat model

## 1. Security objective

**Only firmware signed by an authorised, non-revoked root key, built for this device, and not older than the
committed security version may execute on the ControlCore — and DMA cannot write the firmware or control state.**
"No verified firmware means no privileged firmware execution": everything that runs on the ControlCore CPU after
reset is either the immutable ROM or authenticated firmware.

## 2. Assets

| Asset | Property needed |
|---|---|
| ControlCore firmware (IMEM) | integrity + authenticity before and during execution |
| Firmware control data, stack (DMEM) | integrity (DMA, host) |
| Secure-boot policy state (lifecycle, revocation, minimum security version) | integrity, one-way updates |
| Root public keys (mask ROM) | integrity (they are public; confidentiality not needed) |
| Accelerator control (register pages, completion records) | reachable only by authenticated firmware |
| Image store in device memory | integrity not required (the copy is verified), availability only |

There are **no secrets on the device** in this design (no private keys, no device-unique keys, no encryption).
Side channels therefore cannot leak a key; they matter only as fault/timing aids (see 12_SECURITY_REVIEW).

## 3. Adversaries and capabilities

| Adversary | Capabilities assumed | In scope |
|---|---|---|
| A1 compromised host / driver | full control of the host port: any read/write the port allows, mailbox, host reset pin; chooses the image and its device-memory location | **yes** |
| A2 malicious image supplier | crafts arbitrary images/manifests (malformed, oversized, replayed old signed images) | **yes** |
| A3 device-memory attacker (accelerators, other SoC masters) | modifies the image store and shared buffers at any time | **yes** |
| A4 confused deputy | makes authenticated firmware perform DMA with attacker-chosen addresses | **yes** |
| A5 debug-port user | drives JTAG on a deployed (PROD) part | **yes** |
| A6 physical fault attacker | glitches (clock/voltage/EM/laser) | partially: basic countermeasures only, **not evaluated** |
| A7 side-channel attacker | power/EM/timing | analysed (no secrets); **not evaluated** |
| A8 invasive attacker / foundry | probes, edits the ROM mask, the netlist, the fuses | **no** (trusted manufacturing) |
| A9 signing-key compromise | holds a root private key | mitigated by revocation/rotation only |

## 4. Trust assumptions (the trusted computing base)

1. **The mask ROM is immutable and correct**: boot flow, manifest policy (`sb_policy.c`) and the Ed25519 verifier
   (Monocypher 4.0.2 + RFC 8032 R check). A ROM bug can only be fixed by a new mask (no ROM patching exists).
2. **The secure-boot RTL is correct**: state machine, gates, policy, SHA-256 wrapper; the vendored secworks core.
3. **Root public keys in the ROM are the intended ones**; the corresponding private keys are held in an HSM
   (in this prototype they are **test keys derived from public labels — not secret**).
4. **Fuse state is persistent and one-way.** *Not true in this prototype*: `sb_otp_model` is a POR-domain model.
   Revocation and anti-rollback therefore last only until power-off (07_ANTI_ROLLBACK).
5. **Reset and clock are clean** (no glitch attacker, A6).
6. The authenticated firmware is not malicious; if it is buggy it can still be confined (W^X, DMA windows).
7. The CPU (`mcu_cpu`) executes the ROM as specified (riscv-tests evidence only; no formal proof).

## 5. Threats → mitigations → evidence

| ID | Threat (STRIDE) | Mitigation | Test(s) |
|---|---|---|---|
| T1 | Unsigned / forged firmware (S, T) | Ed25519 over the manifest; manifest binds the SHA-256 of the payload; fail closed | vectors: `sig_*`, `wrong_key_*`, `modified_*` |
| T2 | Modified payload after signing (T) | hardware SHA-256 of the sealed IMEM vs signed digest, checked by ROM and by hardware | vectors `modified_payload_*`, `ext_reject` |
| T3 | TOCTOU: modify IMEM after the check (T) | SEAL before measuring; IMEM gate refuses all writes until PASS; execute window = measured range | `toctou`, `debug_dev` (debugger refused) |
| T4 | Overwrite the ROM's stack/data via host or DMA (T, E) | host filter: no DMEM; DMA guard default deny; DMA has no window in the ROM phase | `boot_ok` host checks, T16, `tb_sb_dma_guard` |
| T5 | Malformed manifest exploits the parser (T, E) | fixed-size manifest copied once into private DMEM; every field range-checked before any copy/hash; no length-derived addition can wrap | vectors: oversized/unsupported/target/entry, fuzzing (20 000 cases, Python == C) |
| T6 | Rollback to an old, vulnerable signed image (T) | security version in the signed manifest vs one-way minimum (fuse model) | `rollback`, vectors `rollback_*` |
| T7 | Compromised signing key (S) | 3 production slots; revocation (fuse model) by authenticated firmware; cannot revoke the active or last slot | `revoke`, `lifecycle`, `tb_sb_core` |
| T8 | Development key/image on a production part (E) | slot 0 accepted only in DEV; DEV_ONLY flag; checked in ROM and hardware | vectors `dev_key_on_prod`, `dev_only_on_prod`; `tb_sb_core` KEY_LC |
| T9 | Image for another device (T) | target ID + hardware version in the manifest vs hardware | vectors `target_*` |
| T10 | Debug port opens the device (E, I) | JTAG bus access, CPU hold, reset and boot override only in DEV; test mode only in DEV | `debug_prod`, `debug_dev` |
| T11 | Host abuses registers (reset, RAS injection, DMA programming) (T, D) | allow-list host filter (hardware) | `boot_ok` (13 refusals) |
| T12 | Confused deputy DMA (T, E) | DMA guard: firmware least-privilege windows, locked; descriptor checked whole, 33-bit end | `boot_ok` DMA_COPY, T16, guard unit test |
| T13 | Code injection / self-modification after boot (T, E) | W^X: execute window read-only, data never executable, ROM fetch closed | T16 |
| T14 | Reset/glitch mid-verification leaves a "half-trusted" state (T) | all secure-boot state in the system reset domain; PASS needs state code + pass flag; tokens; sparse encoding | `reset_auth`, `tb_sb_core` illegal state |
| T15 | Warm boot shortcut (T) | warm boot fully re-authenticates the retained image | `warm_boot` |
| T16 | Crypto datapath fault at reset (T) | SHA-256 power-on KAT through the real datapath → LOCKDOWN | `kat_fault`, `tb_sb_sha256 +katfault` |
| T17 | Corrupted lifecycle fuses open debug (E) | redundant one-way codes (Hamming distance 8/16); invalid → LOCKDOWN, debug closed | `lc_invalid` |
| T18 | Denial of service: endless bad images (D) | not prevented (the host controls the device anyway); bounded by recovery policy; failures counted | `recovery` |
| T19 | Information disclosure through diagnostics (I) | codes + public values only; ROM state in DMEM unreadable by the host; EXPECT write-only | `boot_ok` host checks |

Out of scope: A8, supply-chain of the toolchain, confidentiality of firmware, attacks on the host itself,
denial of service by a host that controls power/reset.
