# 04 — Firmware image format (manifest v1)

Image = **manifest (256 bytes) ‖ payload**, loaded at `CC_IMEM_BASE` (0x0001_0000). Little-endian.
Definitions: `firmware/sb/sb_manifest.h` (C), `tools/sbimage.py` (Python, separate implementation); numeric
constants from `config/cc_memmap.yaml` (`CC_SB_*`).

## 1. Layout

| Offset | Size | Field | Rule (checked by the ROM) | Error |
|---|---|---|---|---|
| 0x00 | 4 | magic | `0x42534653` ("SFSB") | `M_MAGIC` 0x10 |
| 0x04 | 2 | manifest_version | 1 | `M_VERSION` 0x11 |
| 0x06 | 2 | manifest_size | 0x100 | `M_SIZE` 0x12 |
| 0x08 | 4 | target_id | = `SECURITY.TARGET_ID` (0x43434653 "SFCC") | `TARGET` 0x16 |
| 0x0C | 4 | target_hw_version | [31:16] = HW major, [15:0] ≤ HW minor (HW 2.0) | `TARGET_HW` 0x17 |
| 0x10 | 4 | hash_alg | 1 = SHA-256 | `HASH_ALG` 0x13 |
| 0x14 | 4 | sig_alg | 1 = Ed25519 (RFC 8032, pure) | `SIG_ALG` 0x14 |
| 0x18 | 4 | key_id | < 4; slot 0 only in DEV; not revoked | `KEY_ID` 0x18, `KEY_LIFECYCLE` 0x19, `KEY_REVOKED` 0x1A |
| 0x1C | 4 | policy_version | 1 | `POLICY` 0x15 |
| 0x20 | 4 | fw_version | informational | — |
| 0x24 | 4 | security_version | ≤ 32; ≥ MIN_SVN when rollback is enforced | `SVN_RANGE` 0x20, `ROLLBACK` 0x21 |
| 0x28 | 4 | flags | known bits only (bit 0 DEV_ONLY); DEV_ONLY only on DEV | `FLAGS` 0x1B |
| 0x2C | 4 | load_addr | = `CC_IMEM_BASE` | `LOAD_ADDR` 0x1D |
| 0x30 | 4 | image_offset | = 0x100 | `LOAD_ADDR` 0x1D |
| 0x34 | 4 | image_length | 4 ≤ n ≤ IMEM − 0x100 (65 280), n % 4 = 0 | `LENGTH` 0x1E |
| 0x38 | 4 | entry | IMEM + 0x100 ≤ e < IMEM + 0x100 + n, e % 4 = 0 | `ENTRY` 0x1F |
| 0x3C | 4 | reserved0 | 0 | `RESERVED` 0x1C |
| 0x40 | 32 | image_digest | SHA-256(payload) | `DIGEST` 0x23 |
| 0x60 | 32 | build_id | opaque (signed, not interpreted) | — |
| 0x80 | 64 | reserved1 | all 0 | `RESERVED` 0x1C |
| 0xC0 | 64 | signature | Ed25519(R ‖ S) over bytes [0x00, 0xC0) | `SIGNATURE` 0x22 |
| 0x100 | n | payload | `objcopy -O binary` of the firmware ELF (code first) | |

Hardware-side codes: `HW_HASH` 0x24 (measurement failed), `HANDOFF` 0x25 (hardware refused the hand-off; reason
in `SECURITY.STATUS[31:24]`), `LIFECYCLE` 0x26, `CRYPTO_KAT` 0x27, `SEAL` 0x28. P21 codes 0x01–0x05 (CRC format)
are retired.

## 2. Design notes

* **Fixed size, fixed offsets**: no TLV, no variable-length field, nothing to walk. The parser cannot be driven
  out of bounds; the manifest is copied once into ROM-private DMEM and only that copy is used.
* **Every bound before any copy**: `image_length` and `entry` are checked against the IMEM size before the EXT
  payload copy (the RTL test `ext_reject` shows only the 64 manifest words are read for an oversized manifest).
  All comparisons are on values < 2^17 or written so that no addition can wrap (`entry - lo >= length`).
* **What is signed**: everything that controls execution — target, algorithms, key slot, version, security
  version, flags, placement, length, entry, payload digest. A changed field invalidates the signature
  (vectors `modified_manifest_*`).
* **Why the signature covers the manifest and not the payload**: the payload is bound through SHA-256, computed
  by hardware over the sealed copy; Ed25519 then signs 192 bytes, which keeps the ROM's SHA-512 work small.
* **Versioning**: `manifest_version`, `policy_version` and the algorithm fields let a future ROM accept a new
  format or algorithm explicitly; this ROM accepts exactly v1/SHA-256/Ed25519/policy 1 and nothing else.

## 3. Tools

* Sign: `tools/sfsign.py --elf fw.elf --bin fw.payload.bin --key <pem> --slot N --svn S [--dev-only] --out <prefix>`
  (refuses a key that does not match the ROM slot; verifies the result with the reference before writing).
* Verify / dump: `tools/sbimage.py verify|dump <image.img> [--lc PROD --revoked 0x0 --min-svn N]`.
* Test corpus: `tools/mkvectors.py` (53 images with the expected code of each).
