# 11 — Verification and security tests

## 1. Layers

| Layer | What | Command | Report |
|---|---|---|---|
| Step 1: software reference | native build of the ROM policy + verifier (same C sources as the ROM) vs an independent Python/OpenSSL reference; independent vectors; differential fuzzing | `make ref` | reports/ref.md |
| Unit, new RTL | `tb_sb_sha256` (NIST CAVP Short/Long/Monte, stalls, KAT fault), `tb_sb_dma_guard` (reference model, 200 000 random), `tb_sb_core` (secure-boot block register by register) | `make unit-sb` | reports/unit_sb.md |
| Unit, reused P21 blocks | P21 cocotb tests against the v2.0 map package | `make unit` | reports/unit.md |
| System, security | `tb_sb_system.sv`: ControlCore v2 RTL + real ROM + signed firmware, 15 scenarios; firmware self-test T16 runs inside `boot_ok` | `make sb-regress` | reports/security_regression.md |
| System, functional | `tb_cc_system.sv` with the real vector tile and tensor unit (P21 scenarios, signed images) | `make regress` | reports/regression.md |
| Static | Verilator -Wall (0 warnings in new RTL), Icarus elaboration, firmware -Wall -Wextra, address-map validator, vendor check | `make lint check-map vendor` | reports/lint.md |
| CPU | riscv-tests rv32ui/um/mi on `mcu_cpu` RV32M = 2 | `make isa` | reports/isa/riscv_tests_m2.txt |

Two monitors run in every system scenario: an IMEM instruction fetch reaching the crossbar outside an open
authenticated window is an error (`illegal_fetches`, always 0), and every opening of the execute window is counted
(`exec_open_rises`, checked against the expected number of successful boots).

## 2. Brief §10 tests → evidence

| Required test | RTL system evidence (`tb_sb_system`) | Other evidence |
|---|---|---|
| Valid signature | `boot_ok`; vectors `valid_slot1_prod`, `valid_slot2_prod`, `valid_dev_key_dev`, `valid_prod_key_dev`, `valid_recovery`, `valid_svn_equal_min`, `dev_only_on_dev`, `rollback_dev_not_enforced`; `ext_boot`; `regress` (with accelerators) | ref A1 (1 024 vectors), C |
| Invalid signature | vectors `sig_bitflip_R`, `sig_bitflip_S`, `sig_zero`, `sig_noncanonical_S_plus_L`, `truncated_in_signature` → SIGNATURE | ref A1 (bit flips), A2 Wycheproof (64 invalid) |
| Wrong key | vectors `wrong_key_attacker` (key not in ROM), `wrong_key_other_slot`, `dev_key_on_prod` (KEY_LIFECYCLE), `revoked_slot1` (KEY_REVOKED); `revoke` scenario | `tb_sb_core` KEY_LC hardware re-check |
| Modified image | vectors `modified_payload_byte/last` (DIGEST), `modified_manifest_fwver/digest/svn/keyid` (SIGNATURE); `ext_reject` (store modified); `toctou` (writes after seal refused); `warm_boot` (retained image modified) | `bad_image` (with accelerators) |
| Truncated image | vectors `truncated_payload` (DIGEST), `truncated_in_signature`, `truncated_manifest_6` (M_SIZE), `empty_image` (M_MAGIC) | ref C |
| Oversized image | vectors `oversized_length`, `oversized_length_wrap`, `oversized_file` (LENGTH; host writes beyond IMEM refused); `ext_reject`: only the 64 manifest words are read before the length is rejected | fuzzing D |
| Unsupported manifest | vectors `bad_magic`, `manifest_version_2`, `manifest_size_0x200`, `hash_alg_sha384`, `sig_alg_ecdsa_p256`, `policy_version_2`, `unknown_flag`, `reserved0_set`, `reserved1_set`, `load_addr_dmem`, `image_offset_0x200`, `entry_*`, `zero_length`, `unaligned_length`, `key_id_out_of_range` | ref C, D |
| Incorrect target | vectors `target_id_other`, `target_hw_major_1`, `target_hw_minor_newer` (TARGET, TARGET_HW), `dev_only_on_prod` (FLAGS) | ref C |
| Version rollback | `rollback` (commit rules, refusal, documented power-cycle limit); vectors `rollback_prod`, `rollback_dev_enforced`, `svn_out_of_range` | `tb_sb_core`, `debug_dev` (hardware re-check) |
| DMA access violation | `boot_ok`: host `DMA_COPY` into IMEM and onto the stack → DENIED; firmware T16: DMA into code, DMEM data, image store, registers, 2^32 wrap, window crossing → refused; legal transfers still work | `tb_sb_dma_guard` (798 k checks) |
| Debug-access restriction | `debug_prod` (SBA refused, DBGCTRL ignored, DEBUG_USED = 0); `debug_dev` (open in DEV, recorded; hardware hand-off checks still enforced; sealed IMEM still read-only) | |
| Reset during authentication | `reset_auth` (host reset while hashing, during Ed25519, power-on reset during Ed25519); `warm_boot` | `tb_sb_core` (state not sticky across reset) |

Additional: `kat_fault` (crypto self-test failure → LOCKDOWN), `lc_invalid` (corrupted lifecycle → LOCKDOWN),
`lifecycle` (DEV → PROV → PROD, one way, dev key refused after PROV), `recovery` (strap; automatic after 3 failures).

## 3. Independent known-good vectors

See 05_CRYPTOGRAPHY §4: djb/SUPERCOP `sign.input` (RFC 8032 TEST 1–3 included), Wycheproof `ed25519_test.json`,
NIST CAVP SHA-256 Short/Long/Monte. Expected values come from those files, never from the implementation under
test. The 53-image corpus carries expected codes written from the specification; the Python reference, the native
ROM policy and the RTL must each produce exactly those codes.

## 4. What the tests do not show

Simulation of the RTL as written: not gate level, not silicon, not a fault-injection or side-channel campaign,
no formal proof. A passing suite is evidence that the specified checks are implemented, not that the device is
secure (12_SECURITY_REVIEW).
