# 13 — Known limitations

Stated plainly so that nothing in this package is read as a claim it does not make.

## Evidence

* **Simulation only** (Verilator 5.020). No FPGA board, no silicon, no gate-level simulation, no formal proofs of
  the new RTL. A Yosys synthesis estimate of the new blocks exists (reports/synth.md); no place-and-route and no
  bitstream of the secure ControlCore. The P21 ULX3S FPGA harness was **not** updated for the v2 port list (fuse
  inputs, JTAG, recovery strap); it is kept unmodified under `third_party/silicaflux-controlcore-p21/fpga/` for
  reference only.
* RISC-V: riscv-tests (not riscv-arch-test) on `mcu_cpu` with RV32M = 2; no compliance claim.
* Cross-simulator runs (Icarus) of the system tests were not performed (Icarus elaborates the RTL only).

## Security

* **No real OTP/eFuse**: lifecycle, key revocation and minimum security version live in `sb_otp_model`, a
  POR-domain register model. **Anti-rollback and revocation are not persistent across power cycles; genuine
  rollback resistance is not provided** (07_ANTI_ROLLBACK). On an FPGA the "fuses" are bitstream tie-offs.
* **Keys are test keys**: every private key in `keys/` is derived from a published label. No HSM, no key ceremony.
* **Signature check in software**: the Ed25519 decision is made by the ROM on the ControlCore CPU; a successful
  double fault (signature branch + token stores) on the ROM could pass a forged manifest whose digest matches
  attacker code. The signature is verified once (no redundant second verification).
* **DEV lifecycle is not secure**: debug (JTAG system-bus access) can open execution without a signature check.
* No authenticated debug unlock / RMA state; no scan-chain gating (no scan chains in the RTL).
* No secure firmware update protocol beyond "the host writes a signed image"; no A/B slots, no measured-boot
  attestation (the measurement is readable but not signed by the device — the device has no key).
* SVN, revocation and lifecycle commands are accepted from authenticated firmware on a plain mailbox request; a
  production firmware should require an authenticated host request.
* Side-channel and fault-injection resistance not evaluated.

## Functional

* Authentication takes ≈ 6.4 M cycles (≈ 257 ms at 25 MHz) for a 34 KB image, dominated by Ed25519 in software.
* The 32 KiB ROM is generated as a combinational case statement (as in P21); an FPGA flow should map it to block
  RAM and an ASIC flow to a ROM macro (same contract).
* The boot ROM grew 8 → 32 KiB; IMEM firmware limit unchanged (64 KiB − 256 B manifest).
* The DMA guard protects the system DMA only; accelerator DMA masters are confined by their own validators and
  the fabric structure, not by a guard instance (the module is generic; a fabric-level instance is future work).
* Firmware must place DMA buffers in `.dmabuf` (DMEM) or device memory; other DMEM is unreachable for the DMA.
* `SECURITY` HW_VERSION (2.0) and `SYSCTRL.HW_VERSION` (1.0, vendored unmodified P21 block) differ; the secure-boot
  identity is the SECURITY page.
* The P21 cocotb top-level mock test and the `cc_secmon` unit test were retired (CRC boot flow / removed block).
* The P21 self-test T13 had a timing race with the timer tick (exposed by the new boot timing); fixed by masking
  interrupts during its 2 000-cycle sample.
