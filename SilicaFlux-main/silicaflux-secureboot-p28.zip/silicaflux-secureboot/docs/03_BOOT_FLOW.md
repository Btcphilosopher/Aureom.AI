# 03 — Boot flow and fail-closed policy

## 1. Policy

**Fail closed.** The ROM never jumps into IMEM on its own authority: instruction fetch from IMEM is refused by
the fetch gate until the secure-boot block is in PASS, and PASS is reachable only through the hardware hand-off
checks. Every failure produces a BOOT_ERR_* code in `SYSCTRL.BOOT_STATUS` and `SECURITY.FAIL_CODE`, a mailbox
answer to the host, and then either a return to LOAD (the host may supply another image) or, for failures of the
root of trust itself, LOCKDOWN (CPU parked until reset). There is no unauthenticated fallback.

## 2. Stages (`SYSCTRL.BOOT_STAGE`)

| Stage | What happens |
|---|---|
| ROM_START | `rom_start.S`: mtvec → ROM trap handler; DMEM scrubbed; stack in DMEM (host cannot read or write DMEM) |
| ROM_INIT | INTC/DMA/RAS quiesced; DMEM pattern test; wait for the SHA-256 KAT; LOCKDOWN → stage FATAL with `CRYPTO_KAT` or `LIFECYCLE`; read lifecycle, revocation, MIN_SVN, rollback/EXT policy |
| (warm) | reset cause SOFT/WDT and not RECOVERY: **seal + full authentication of the retained image**; failure → cold boot |
| (cold) | IMEM scrubbed (only possible in LOAD), parity checking on |
| IMAGE_CHECK (EXT) | BOOT_MODE_EXT, not disabled (fuse CFG / RECOVERY): source checked (aligned, inside EXT); DMA copies the 256-byte manifest through a one-shot guard window; **manifest validated (all lengths and bounds) before the payload is copied**; payload copied (exactly `image_length` bytes); windows closed; authenticate; failure → fall back to the host |
| WAIT_IMAGE | LOAD: the host writes the image into IMEM, `IMAGE_READY` doorbell |
| IMAGE_CHECK | `authenticate()`: SEAL (wait SEALED) → copy the manifest once into DMEM → `sb_manifest_check` (policy, no crypto) → HASH_BASE/LEN → hardware SHA-256 → `sb_signature_check` (Ed25519) → constant-time digest compare → EXPECT, ENTRY, KEY_SLOT, IMAGE_SVN, tokens → HANDOFF |
| FW_START | hardware PASS confirmed; host answered OK; `fence.i`; jump to the entry inside the window |
| FW_INIT … HOST_READY | firmware: DMA windows + lock, platform init, discovery, POST, mailbox (P21 flow) |
| BOOT_ERROR | code reported; FAIL → RELOAD; IMEM scrubbed; back to WAIT_IMAGE |
| FATAL | LOCKDOWN: code reported, CPU parked |

## 3. Check order (identical in ROM, native reference and Python reference)

Manifest structure → algorithms/policy → target → key slot (range, lifecycle, revocation) → flags/reserved →
placement/length/entry → security version → *(payload copy for EXT)* → hardware SHA-256 → Ed25519 →
digest compare → hardware hand-off checks. Cheap checks first: a malformed manifest never reaches the
signature verifier and never causes a copy.

## 4. Measured timing (RTL simulation, `reports/security_regression.md`)

| Step | Cycles |
|---|---|
| ROM start → WAIT_IMAGE | ≈ 300 k (DMEM scrub + pattern test, IMEM scrub) |
| Host writes the 34 472-byte image (8 618 words) | ≈ 17 k |
| SEAL | 1 |
| Hardware SHA-256 of the 33.9 KB payload | ≈ 61 k |
| Ed25519 verification (RV32IM, single-cycle MUL) | ≈ 6.2 M |
| IMAGE_READY → hand-off | **≈ 6.4 M** (≈ 257 ms at 25 MHz) |

## 5. Recovery process

* **Bad image** (any BOOT_ERR): the device stays in the ROM, answers the reason, scrubs IMEM and waits for a
  new image. No reset is required; nothing unauthenticated can run.
* **Bad image store** (EXT boot): automatic fall back to host loading.
* **Repeated failures**: after 3 consecutive authentication failures (POR-domain counter), the next reset of a
  PROV/PROD part enters RECOVERY: EXT and warm boot are skipped, the host must supply a signed image; debug stays
  closed; authentication rules are unchanged. A successful hand-off clears the counter.
* **Recovery strap** (`recovery_req_i`): same mode on demand.
* **LOCKDOWN** (KAT failure, invalid lifecycle code): no recovery by software; a reset re-runs the KAT (a
  transient fault recovers, a permanent one does not). Return/failure analysis needs a DEV part — there is no
  authenticated debug unlock (13_LIMITATIONS).
