# 08 — DMA isolation and access control

## 1. Layers

| Layer | Block | Granularity | Bypassable by |
|---|---|---|---|
| Access matrix | `sfb_crossbar` (`CC_XBAR_EN`) | master × region | nothing (static) |
| Host filter | `sb_access_policy` → `cc_sfb_gate` (host) | address + offset allow-list | nothing |
| DMA descriptor validation | `sb_dma_guard` on the DMA register page | whole transfer, at START | nothing (only the CPU can program the DMA) |
| DMA per-beat firewall | `sb_dma_guard.beat_ok` → `cc_sfb_gate` (DMA master) | every word | — (defence in depth) |
| IMEM gate (seal, W^X) | `sb_access_policy` → `cc_sfb_gate` (IMEM slave) | every IMEM write, any master | nothing |
| Fetch gate | `sb_access_policy` → `cc_sfb_gate` (CPU I) | every fetch | nothing |

## 2. System DMA guard (`rtl/sb_dma_guard.sv`)

**Windows**: 4 × {BASE, LAST (inclusive), ATTR = EN | READ | WRITE}. Reset: all disabled — **the DMA can access
nothing** (default deny). Window registers are writable only while unlocked **and the DMA is idle** (a window can
never change under a transfer that was validated against it); `CTRL.LOCK` makes them read-only until reset.

**Descriptor validation at START** (the `CONTROL.START` write; the guard shadows SRC/DST/LENGTH/MODE exactly as
`mcu_dma` latches them):

| Check | Rule |
|---|---|
| source / destination address | range = `[a & ~3, (a + len + 3) & ~3)` for an incrementing side, `[a & ~3, +4)` for a fixed side |
| transfer length | 0 → passed to the DMA, which refuses it without access; otherwise covered by the range |
| integer overflow | 33-bit end; end > 2^32 → `SRC_OVF` / `DST_OVF` (no wrap-around can alias a low address) |
| permissions | the whole source range inside ONE enabled window with READ; destination with WRITE |
| MMIO restriction | any overlap with PERIPH (all register pages) or BOOTROM → `PROTECTED` |
| firmware/control region | destination overlapping IMEM while the secure-boot block is not in LOAD → `PROTECTED` |

A refused START never reaches `mcu_dma` (no access, no partial transfer), answers a bus error (the CPU takes a
precise store access fault; the firmware maps it to `DMA_GUARD_DENIED` / mailbox status `DENIED`), and is
recorded in `DENY_SRC/DST/LEN/REASON/COUNT` and `SECURITY.VIOL_STATUS.DMA`.

**Per-beat firewall**: the same windows and protected regions applied to every word the DMA requests; a refused
beat is answered with an error (DMA reports a bus error) and logged (`BEAT_VIOLATION`). With windows frozen
during transfers it can only fire if layer 1 is wrong or the seal closes during a transfer (SEAL waits for the
DMA to be idle, so it does not).

## 3. Policy used by the reference firmware (`sb_platform_init`, then locked)

| Window | Range | Access | Purpose |
|---|---|---|---|
| W0 | device memory below the image store (0x2000_0000 … 0x200E_FFFF) | read/write | operands, results, telemetry, host DMA_COPY |
| W1 | firmware image store (0x200F_0000 … 0x200F_FFFF) | **read only** | protected firmware/control region |
| W2 | DMEM `.dmabuf` section (linker-placed, 256-byte aligned) | read/write | the only DMEM the DMA may touch |
| W3 | — | disabled | |

Everything else — IMEM (running firmware), the rest of DMEM (stack, `.data`, `.bss`, secure-boot state), ROM,
registers, the tile scratchpad — is out of reach of the system DMA, including for host-supplied `DMA_COPY`
addresses (confused deputy). The boot ROM uses one-shot windows for its EXT copy and closes them.

## 4. Host port (untrusted in every lifecycle state)

Reads: IMEM; SYSCTRL, MAILBOX, PERF, PMU, RAS, SECURITY, DMA_GUARD pages. Writes: IMEM only in LOAD; MAILBOX
H2F_MSG0..7, H2F_RING, F2H_ACK, DIAG_POP, DIAG_STATUS. Everything else is refused (13 refusal checks in
`boot_ok`). The access matrix removes BOOTROM and DMEM for the host entirely.

## 5. Accelerator DMA masters

The vector-tile DMA (HPC M05) and the tensor DMA (TC07) live in the accelerator subsystem behind the ControlCore's
master-only external port: there is **no path** from them into BOOTROM, IMEM, DMEM or the ControlCore registers.
They are confined to device memory and the tile scratchpad by their own validators (tensor unit `MEM_LO/MEM_HI`,
tile address map). They **can** write the device-memory image store; secure boot does not depend on it (the image
is verified after the copy into sealed IMEM). A fabric-level instance of the guard for these masters (the module is
generic) is listed as future work in 13_LIMITATIONS.

## 6. Verification

`tb/unit_sb/tb_sb_dma_guard.sv`: directed cases (wrap at 2^32, window ending at 2^32, window edges ±4, byte mode,
fixed sides, protected regions, IMEM in/out of LOAD, busy/lock) and **200 000 random descriptors** compared with an
independent 64-bit reference model, all six outcomes covered, plus per-beat decisions: **798 136 checks**.
System level: firmware self-test T16 (8 refused transfers, legal ones still work), `boot_ok` (host DMA_COPY into
IMEM and onto the stack refused).
