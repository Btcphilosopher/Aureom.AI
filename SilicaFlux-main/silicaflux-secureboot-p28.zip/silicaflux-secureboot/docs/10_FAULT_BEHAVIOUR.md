# 10 — Fault behaviour

## 1. Authentication failure

| Requirement (brief §9) | Behaviour | Evidence |
|---|---|---|
| Block privileged execution | Instruction fetch from IMEM is refused by hardware until PASS; PASS only through the hand-off checks; FAIL closes nothing that was open because nothing was | every negative vector; `illegal_fetches = 0` monitor in every scenario; `exec_open_rises` counted |
| Controlled failure status | `SYSCTRL.BOOT_STATUS` and `SECURITY.FAIL_CODE` = BOOT_ERR_*; `SECURITY.STATUS[31:24]` = hardware refusal reason; `BOOT_STAGE` = BOOT_ERROR / FATAL; mailbox answer `BAD_CMD` + code (`F2H_MSG1`); `BOOT_FAILS` counter | `vectors` checks status, code and FAIL_CODE for all 45 negative images (8 positive) |
| No secrets in diagnostics | The device holds no secret. Diagnostics carry codes, stages, public values (digest prefix, entry, slot, SVN). ROM working data (manifest copy, context) lives in DMEM, which the host can neither read nor write; `EXPECT` registers read as 0 | host filter checks in `boot_ok` (DMEM read refused) |
| Documented recovery policy | 03_BOOT_FLOW §5: stay in ROM, scrub IMEM, accept another signed image; EXT failure → host; 3 failures → RECOVERY at the next reset | `ext_reject`, `recovery` |

## 2. Failure classes

| Class | Examples | Result |
|---|---|---|
| Image rejected | any manifest/policy/signature/digest error, hand-off refusal | FAIL → RELOAD → LOAD; IMEM scrubbed; WAIT_IMAGE |
| Measurement failed | bus error while hashing (e.g. IMEM parity) | FAIL (`HASH_ERR`) → same as above |
| Root of trust unusable | SHA-256 KAT failure; invalid lifecycle code; illegal secure-boot state code | LOCKDOWN: CPU parked after reporting; IMEM neither writable nor executable; only a reset leaves it |
| Secure-boot block stuck | SEALING/HASHING never completes (ROM timeout ≈ 2 M polls) | LOCKDOWN reported by the ROM (`SEAL` / `HW_HASH`) |
| ROM exception | any trap in the ROM | reported (`TRAP`, mcause/mepc/mtval in the mailbox), CPU parked |

## 3. Reset during verification

All secure-boot state (state machine, measurement, EXPECT, tokens, execute window, pass flag, hash reader) is in
the system reset domain. A reset at any point:

* returns to SELFTEST → LOAD with execution closed (no "resume" of a half-done verification);
* is **not** counted as an authentication failure;
* leads to a cold boot (host / POR) that scrubs IMEM, or a warm boot (soft / watchdog) that re-seals and fully
  re-authenticates the retained image.

`reset_auth` resets during hashing (host reset), during the Ed25519 check (host reset) and with a power-on reset
during the Ed25519 check, and checks each time: execute window never opened, state LOAD, no digest/tokens carried
over, IMEM scrubbed, no failure counted; then a normal boot succeeds and the window opens exactly once.
`warm_boot` shows a watchdog reset re-authenticating, and a retained image modified between the reset and the seal
being rejected (DIGEST) and replaced by a cold boot.

## 4. Fault-injection countermeasures (basic, not evaluated)

| Countermeasure | Against |
|---|---|
| Sparse state encoding (Hamming distance ≥ 4); illegal → LOCKDOWN | single-bit upsets of the state register (`tb_sb_core` forces 0x55 while in PASS: execution closes) |
| Execute window needs `state == PASS` **and** a separate `pass_q` flag | a single upset opening execution |
| Two-word signature token (A then ~A, cleared by any other write, only in HASHED) | one skipped/glitched ROM store |
| Hardware re-checks of digest, entry, key slot/revocation, security version | one skipped ROM branch |
| Seal before measure, measure by hardware, window = measured range | ROM confusion about what was verified |
| Redundant revocation bits; lifecycle codes with distance 8/16 | fuse-read upsets towards a more permissive state |
| Power-on KAT through the real datapath | permanent datapath faults at reset |

They have not been evaluated against an actual glitch campaign; see 12_SECURITY_REVIEW §3.
