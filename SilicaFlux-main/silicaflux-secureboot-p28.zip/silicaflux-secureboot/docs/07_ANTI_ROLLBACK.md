# 07 — Anti-rollback (optional version enforcement)

## 1. What is implemented

* Every manifest carries a signed **security version** (`security_version`, 0…32), separate from the
  informational `fw_version`. It is increased only when a release fixes a security problem.
* The minimum acceptable security version is a **thermometer** in the fuse-model word `SVN` (bit i set =
  SVN i+1 committed): one-way by construction, monotonic, decoded as "highest set bit + 1".
* Enforcement (ROM `ROLLBACK`, hardware hand-off re-check `SB_HREF_ROLLBACK`): `security_version ≥ MIN_SVN`.
  Always in PROV/PROD/RECOVERY; **optional in DEV** (fuse-model `CFG[0]` = ROLLBACK_IN_DEV).
* Raising the minimum: authenticated firmware writes `SECURITY.SVN_COMMIT = n`. Hardware accepts only
  1 ≤ n ≤ the security version of the image that is running (latched at hand-off): firmware cannot raise the
  minimum above its own security version, so a commit can never lock out the image that is running. Recommended
  policy: commit only after the new firmware has run successfully (e.g. after N healthy boots or a host
  confirmation), so a bad update can still be rolled back to the previous security version.

Tested: `rollback` (commit refused above the own SVN; commit 1; svn-0 image refused; svn-1 image boots),
vectors `rollback_prod`, `rollback_dev_not_enforced`, `rollback_dev_enforced`, `svn_out_of_range`,
`valid_svn_equal_min`, `tb_sb_core`.

## 2. What is NOT claimed

**This prototype does not provide genuine rollback resistance.** The brief's condition — persistent, protected,
monotonic state — is not met:

* `sb_otp_model` is a register model in the power-on-reset domain. It survives soft, watchdog, host and debug
  resets, **but not a power cycle**: at power-up it reloads whatever the `fuse_*_i` inputs present (tie-offs on an
  FPGA, plusargs in the testbench). The `rollback` scenario demonstrates this explicitly: after a power cycle the
  committed SVN is gone and the svn-0 image boots again.
* On an FPGA, the tie-offs are part of the bitstream; whoever controls the bitstream controls the "fuses".
* A software-stored version number (flash, device memory, host) would be no better: it can be rewritten or
  replayed.

## 3. What a real product needs

One of:
1. an OTP/eFuse macro for the target process with a read path that is not bypassable and a programming path
   reachable only by the secure-boot block (replace `sb_otp_model`, keep its interface and the rules in
   `silicaflux_secure_boot`), or
2. an authenticated monotonic counter in an external secure element / RPMB-capable memory, read and
   authenticated by the ROM before the version check (this needs a device-unique secret, which this design does
   not have).

Until then the SVN mechanism is a correct *policy implementation* with *volatile* state.
