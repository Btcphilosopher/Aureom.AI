# 09 — Lifecycle states and debug security

## 1. States

| State | Encoding (fuse-model word `LC`) | Keys accepted | Rollback | Debug (JTAG bus access, CPU hold, system reset, boot override) | DFT `test_mode` | Boot sources |
|---|---|---|---|---|---|---|
| **Development** (DEV) | `0x0000_0000` (blank) | dev slot 0 + production 1–3 | optional (`CFG[0]`) | **open** | allowed | host, EXT, warm |
| **Provisioning** (PROV) | `0x0000_5AA5` | production only | enforced | closed | gated off | host, EXT, warm |
| **Production** (PROD) | `0x5AA5_5AA5` | production only | enforced | closed | gated off | host, EXT, warm |
| **Recovery** (RECOVERY) | PROV/PROD + strap, or ≥ 3 consecutive failures | production only | enforced | closed | gated off | **host only** |
| invalid | any other value | — | — | closed | gated off | none: **LOCKDOWN** |

* Transitions DEV → PROV → PROD only add bits (one-way); a single-bit error in any valid code is an invalid code
  (Hamming distances 8 / 8 / 16), which fails closed.
* The lifecycle is latched at each system reset; `LC_ADVANCE` takes effect at the next reset.
* RECOVERY is a per-boot mode of a PROV/PROD part, not a fuse state. It never opens debug and never relaxes
  authentication; it removes the EXT and warm boot paths so that a part with a corrupted image store or retained
  image can be recovered with a signed image from the host.

## 2. Debug interfaces and what is restricted

| Interface | Risk | DEV | PROV / PROD / RECOVERY |
|---|---|---|---|
| JTAG TAP (IDCODE, BYPASS) | identification only | yes | yes |
| JTAG SBA (system-bus read/write) | complete bypass: read/write any memory and register | **yes** (and recorded: `STATUS.DEBUG_USED`) | **refused** (debug gate; error + `VIOL_STATUS.DEBUG`) |
| JTAG DBGCTRL CPU_HOLD | stop the ROM at will | yes | ignored |
| JTAG DBGCTRL SYS_RESET | reset injection | yes | ignored |
| JTAG DBGCTRL BOOT_OVR | override the boot straps | yes | ignored |
| `test_mode` pin | reset-synchroniser bypass, clock-gate test enable | yes | gated off |
| Host port | untrusted in every state | filtered | filtered |

**An ordinary exposed JTAG port is not secure, and in DEV this one is not.** The `debug_dev` test demonstrates that
a debugger on a DEV part can hold the CPU, seal and measure the image and **open execution without any signature
check** — DEV is a development state by definition (and the development private key is public anyway). The same
test shows that even then the debugger cannot write the sealed IMEM and that every hardware hand-off rule
(digest, tokens, entry, revocation, rollback) still applies.

In PROD (`debug_prod`): IDCODE readable; SBA read and write refused with no data; CPU hold, system reset and boot
override ignored; nothing reaches the bus (`DEBUG_USED` = 0); violations logged.

## 3. Not provided

* No authenticated debug unlock (e.g. a signed RMA/unlock token) and no "RMA" lifecycle state: a PROD part cannot
  be reopened for failure analysis. Failure analysis needs DEV parts.
* No scan-chain or BIST access control: the RTL has no inserted scan chains; a real tape-out must tie scan
  enable/mode to the lifecycle in the DFT flow (13_LIMITATIONS).
* Lifecycle states live in the fuse model (see 07_ANTI_ROLLBACK): on an FPGA, whoever controls the tie-offs
  chooses the lifecycle.
