# 05 — Cryptography: algorithms, implementations, validation

No cryptographic primitive was designed or written for this project. Every primitive is a vetted, published
implementation, vendored unmodified; the project's own code only frames them (padding/streaming around the
SHA-256 compression core, the RFC 8032 R-encoding pre-check, manifest framing).

## 1. Algorithms

| Use | Algorithm | Parameters |
|---|---|---|
| Firmware signature | **Ed25519**, RFC 8032 §5.1 (pure Ed25519, no context, no pre-hash) | 32-byte public keys, 64-byte signatures; message = manifest bytes [0x00, 0xC0) (192 B); internal hash SHA-512 |
| Image digest | **SHA-256**, FIPS 180-4 | over the payload bytes [0x100, 0x100 + image_length) of the sealed IMEM copy |
| Digest comparison | constant-time byte comparison (`sb_ct_equal`) + 256-bit hardware comparison | |

Why Ed25519 rather than ECDSA P-256: deterministic signatures (no per-signature randomness at the signer), a
small verifier, strict-verification guidance (Wycheproof), and a previously audited, permissively licensed,
embedded-friendly implementation (Monocypher). Signing uses OpenSSL (via the `cryptography` package), an independent
implementation from the verifier.

## 2. Implementations

| Component | Implementation | Version / pin | Licence | Where |
|---|---|---|---|---|
| Ed25519 verify (ROM) | Monocypher `crypto_ed25519_check` (`src/optional/monocypher-ed25519.c` + `src/monocypher.c`) | **4.0.2**, tag commit `0d85f98c9d9b0227e42cf795cb527dff372b40a4` | BSD-2-Clause or CC0 | `third_party/monocypher-4.0.2/` (unmodified) |
| R strict-decoding pre-check | `r_is_canonical()` in `firmware/sb/sb_policy.c` | this project (12 lines, byte comparisons, RFC 8032 §5.1.3) | — | see §3 |
| SHA-256 compression | secworks/sha256 `sha256_core.v`, `sha256_w_mem.v`, `sha256_k_constants.v` (Joachim Strömbergson) | commit `837c5cc396f001d18f2c765721c585716eb439ae` | BSD-2-Clause | `third_party/secworks-sha256/` (unmodified) |
| SHA-256 padding/streaming + KAT | `rtl/sb_sha256_stream.sv`, `rtl/sb_sha256_wrapper.sv` | this project | — | FIPS 180-4 §5.1.1 framing only |
| Signing (host) | OpenSSL 3.0 Ed25519 via `cryptography` 50.0.1 | | Apache-2.0/BSD | `tools/sfsign.py` |
| Reference SHA-256 (host) | Python `hashlib` (OpenSSL) | | | `tools/sbimage.py` |

Monocypher was audited by Cure53 in 2020 (findings MON-01-00x addressed in release 3.1.2, per its CHANGELOG); the
4.x series used here is a later refactor that, to our knowledge, has not had a separate third-party audit — one
reason the ROM verifier is re-validated against RFC 8032, djb and Wycheproof vectors here. Its Ed25519 is the
RFC 8032 variant (SHA-512) in the optional module.
The ROM is compiled with GCC 13.2 `-Os` for RV32IM; Monocypher + policy + boot flow = 23 192 bytes of the 32 KiB ROM.

## 3. Strict verification

Monocypher 4.0.2 `crypto_ed25519_check` rejects S ≥ L (malleability) and verifies the cofactorless equation. On
the Wycheproof set it deviates from the expected result in exactly one case: **tcId 151** — R encodes y = 1 with
the sign bit of x set, which RFC 8032 §5.1.3 says must fail to decode (raw Monocypher accepts it; OpenSSL
rejects it). This is not a forgery path under an honest root key (it requires a signature whose R is the
identity, i.e. an honest signer's nonce r ≡ 0 mod L), but the boot ROM must verify strictly, so
`sb_ed25519_verify()` first applies the RFC 8032 decoding rule to R (reject y ≥ p; reject the x sign bit when
x = 0, i.e. y = 1 or y = p − 1), then calls Monocypher. With that pre-check the ROM verifier agrees with the
expected Wycheproof result on all 181 valid/invalid vectors and with OpenSSL on all 210 vectors.

## 4. Validation against independent known-good vectors (`make ref`, `make unit-sb`)

| Vectors (source) | Device under test | Result |
|---|---|---|
| djb/SUPERCOP `sign.input`, 1 024 vectors (lines 1–3 = RFC 8032 §7.1 TEST 1–3), via pyca `cryptography_vectors` 44.0.0 | ROM verifier (native build), raw Monocypher, OpenSSL: valid accepted, 1-bit-flipped signature rejected, modified message rejected; OpenSSL re-signs bit-exactly | **9 214 / 9 214** |
| Wycheproof `ed25519_test.json` (C2SP/wycheproof `d5f724a2`) | ROM verifier vs expected (valid / invalid) | **181 / 181**; 0 disagreements with OpenSSL (210 incl. "acceptable") |
| NIST CAVP `SHA256ShortMsg.rsp` + `SHA256LongMsg.rsp` (129 messages, every byte length 0…64 and long messages up to 51 200 bytes) | **RTL** `sb_sha256_wrapper` | **129 / 129** (also with 40 % random input stalls) |
| NIST CAVP `SHA256Monte.rsp` (100 checkpoints × 1 000 chained hashes) | **RTL** `sb_sha256_wrapper` | **100 / 100** |
| FIPS 180-2 "abc" and 448-bit message | power-on KAT inside the RTL, every reset | pass; a forced stuck-at fault makes it fail closed |
| Hardware digest of the signed firmware | RTL SBC vs `hashlib` value in the manifest | equal (`debug_dev`, `tb_sb_core`, every boot) |

## 5. Side channels

The device holds no secret: verification processes public data only (public keys, signatures, images). The
Ed25519 verifier is not required to be constant time; Monocypher's verification path is variable time by
design. The digest comparison is constant time anyway. No secret-dependent behaviour exists to leak. See
12_SECURITY_REVIEW for the fault-injection view.

## 6. Not done

* No hardware signature verifier (e.g. OpenTitan OTBN, Caliptra ECC): the signature check runs on the ControlCore
  CPU, so the ROM code is in the trusted computing base for the signature decision (mitigated, not removed, by the
  hardware hand-off checks).
* No post-quantum signature; no dual signatures; no certificate chains (direct root keys only).
* No formal verification of the SHA-256 wrapper or of Monocypher on this toolchain/ISA (vector testing only).
