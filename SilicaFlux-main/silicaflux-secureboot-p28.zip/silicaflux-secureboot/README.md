# SilicaFlux-HPC · Project 28 — SecureSilicon: secure boot and hardware isolation

**Primary RTL:** [`rtl/silicaflux_secure_boot.sv`](rtl/silicaflux_secure_boot.sv) · Aureom.AI / SilicaFlux-HPC

A minimal, defensible hardware root of trust for the SilicaFlux ControlCore (Project 21). ControlCore firmware is
authenticated before it can execute, and DMA and the host are confined by hardware rules:

```
Immutable Boot ROM -> Firmware Manifest -> Cryptographic Verification -> Authenticated Firmware Load -> Controlled Execution
  32 KiB mask ROM      256 B, signed         Ed25519 (Monocypher 4.0.2)      IMEM sealed, SHA-256 in       execute window = measured
                                             SHA-256 (secworks, in HW)        hardware of the sealed copy   range; W^X; DMA windows
```

> **Status — read this first.** Everything below is RTL simulation, a software reference and a Yosys estimate.
> Nothing ran on an FPGA board or silicon. **This is not a security certification** (docs/12). There is **no OTP or
> eFuse**: lifecycle, revocation and anti-rollback state live in a *fuse model* that is lost at power-off, so
> **genuine rollback resistance is not provided** (docs/07). All keys in `keys/` are **test/development keys derived
> from public labels**. Lifecycle DEV is not secure (open debug). Delivered as an archive.

## Definition of done: met in RTL simulation

* **Correctly signed firmware executes**: the real Project 21 firmware, signed with `tools/sfsign.py`, boots on the
  ControlCore v2 RTL through the secure ROM and runs its full self-test with the real vector tile and tensor unit.
* **Modified or unauthorised firmware is rejected**: of a 53-image corpus, the 45 bad images (invalid/zero/
  non-canonical signatures, wrong and revoked keys, modified payload or manifest, truncated, oversized, unsupported,
  wrong target, rollback) are rejected by the RTL with exactly the error code the specification and two independent
  software references give, and the 8 good ones boot; no instruction is ever fetched from IMEM outside an authenticated window (monitored in every scenario).
* **DMA address restrictions are enforced and tested**: DMA into the firmware, the stack, the image store and the
  register space, wrapping and window-crossing transfers are refused before any access, at system level and against
  a 200 000-descriptor randomised reference model.

## Results (from `reports/`, final run on the frozen sources — `reports/SUMMARY.md`)

| Check | Result | Report |
|---|---|---|
| Step 1 software reference — Ed25519 djb/SUPERCOP vectors (1 024, incl. RFC 8032 TEST 1–3) on the ROM verifier, raw Monocypher and OpenSSL | **9 214 / 9 214** | [ref](reports/ref.md) |
| Wycheproof Ed25519 on the ROM verifier | **181 / 181** (0 disagreements with OpenSSL) | [ref](reports/ref.md) |
| Security corpus: specification == Python reference == native ROM policy | **53 / 53** | [ref](reports/ref.md) |
| Differential fuzzing of the manifest policy (Python vs C) | **20 000 / 20 000** | [ref](reports/ref.md) |
| SHA-256 RTL vs NIST CAVP (129 messages + Monte 100 × 1 000), stalls, KAT fault | **PASS** | [unit_sb](reports/unit_sb.md) |
| DMA guard vs reference model (directed + 200 000 random, all outcomes covered) | **798 k checks PASS** | [unit_sb](reports/unit_sb.md) |
| Secure-boot block alone (hand-off rules incl. KEY_LC, privilege, fuse rules, illegal-state injection) | **PASS** | [unit_sb](reports/unit_sb.md) |
| **Security regression on the RTL** (15 scenarios, all brief §10 cases) | **15 / 15 scenarios, 318 / 318 checks** | [security_regression](reports/security_regression.md) |
| Functional regression with the real accelerators, signed firmware (P21 scenarios incl. back-pressure) | **6 / 6 runs**, 740 firmware checks, 0 fails | [regression](reports/regression.md) |
| cocotb unit tests of the reused P21 blocks | **17 / 17** | [unit](reports/unit.md) |
| Lint: Verilator -Wall on all new RTL, Icarus elaboration, firmware + ROM -Wall -Wextra | **0 warnings** | [lint](reports/lint.md) |
| riscv-tests on `mcu_cpu` RV32M = 2 | **63 / 63** | [isa](reports/isa/riscv_tests_m2.txt) |
| Yosys `synth_ecp5` estimate of the new blocks | secure-boot block ≈ 12.6 k LUT4 incl. SHA-256 | [synth](reports/synth.md) |
| Vendored sources byte-identical (repository archives / pinned upstream commits) | **204 / 204** | [PROVENANCE](third_party/PROVENANCE.md) |
| Authentication time, 34 KB firmware | **6 418 557 cycles** (≈ 257 ms at 25 MHz) | [security_regression](reports/security_regression.md) |

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository and threat-model audit; threats and trust assumptions | [00_AUDIT](docs/00_AUDIT.md), [01_THREAT_MODEL](docs/01_THREAT_MODEL.md) |
| 2 | Root-of-trust architecture; fail-closed policy | [02_ARCHITECTURE](docs/02_ARCHITECTURE.md), [03_BOOT_FLOW](docs/03_BOOT_FLOW.md), `rtl/silicaflux_secure_boot.sv` |
| 3 | Documented signature scheme, real verification, exact algorithm + implementation | Ed25519 + SHA-256: [05_CRYPTOGRAPHY](docs/05_CRYPTOGRAPHY.md); `firmware/sb/sb_policy.c`, `rtl/sb_sha256_*.sv` |
| 4 | Key storage, provisioning, rotation, revocation, recovery, dev vs prod | [06_KEY_MANAGEMENT](docs/06_KEY_MANAGEMENT.md), `tools/sbkeys.py`, `keys/` |
| 5 | Versioned manifest; bounds validated before copying | [04_IMAGE_FORMAT](docs/04_IMAGE_FORMAT.md), `firmware/sb/sb_manifest.h`, `tools/sbimage.py` |
| 6 | Optional version enforcement; no false rollback claim | [07_ANTI_ROLLBACK](docs/07_ANTI_ROLLBACK.md) |
| 7 | Configurable DMA windows; addresses, lengths, permissions, overflow, MMIO | [08_DMA_ISOLATION](docs/08_DMA_ISOLATION.md), `rtl/sb_dma_guard.sv` |
| 8 | Lifecycle states DEV / PROV / PROD / RECOVERY; debug restricted | [09_LIFECYCLE_DEBUG](docs/09_LIFECYCLE_DEBUG.md), `rtl/sb_access_policy.sv` |
| 9 | Failure blocks execution, controlled status, no secrets, recovery policy, reset during verification | [10_FAULT_BEHAVIOUR](docs/10_FAULT_BEHAVIOUR.md) |
| 10 | The 12 required tests + independent vectors | [11_VERIFICATION](docs/11_VERIFICATION.md), `tb/tb_sb_system.sv`, `tb/unit_sb/`, `ref/` |
| 11 | Security review: trust, side channels, faults, key storage, recovery paths, interfaces, third-party review | [12_SECURITY_REVIEW](docs/12_SECURITY_REVIEW.md) |
| 12 | Deliverables + known limitations | table below, [13_LIMITATIONS](docs/13_LIMITATIONS.md) |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_secure_boot.sv` | `rtl/silicaflux_secure_boot.sv` (state machine, seal, hash reader, hand-off checks, lifecycle, fuse-model rules, violations) |
| Boot ROM integration | `firmware/bootrom/` (secure ROM), `rtl/sb_bootrom.sv`, `rtl/silicaflux_control_core.sv` (ControlCore v2), `config/cc_memmap.yaml` (map v2.0) |
| Manifest parser | `firmware/sb/sb_manifest.h`, `firmware/sb/sb_policy.c` (ROM and native reference), `tools/sbimage.py` (independent Python reference) |
| Verified cryptographic-core wrapper | `rtl/sb_sha256_wrapper.sv` + `rtl/sb_sha256_stream.sv` around `third_party/secworks-sha256`; ROM verifier `sb_ed25519_verify` around `third_party/monocypher-4.0.2` |
| DMA access-control logic | `rtl/sb_dma_guard.sv`, `rtl/sb_access_policy.sv` (host / fetch / IMEM / debug), `rtl/sb_otp_model.sv` (fuse model) |
| Firmware signing utility | `tools/sfsign.py`, `tools/sbkeys.py` |
| Test vectors | `vectors/` (NIST CAVP SHA-256, djb/RFC 8032 Ed25519, Wycheproof), `tools/mkvectors.py` (53-image security corpus) |
| Security regression suite | `tb/tb_sb_system.sv` + `scripts/sb_regress.py`; `tb/unit_sb/*` + `scripts/unit_sb.py`; `ref/run_ref.py`; firmware self-test T16 |
| Threat model | [docs/01_THREAT_MODEL.md](docs/01_THREAT_MODEL.md), [docs/12_SECURITY_REVIEW.md](docs/12_SECURITY_REVIEW.md) |
| Known limitations | [docs/13_LIMITATIONS.md](docs/13_LIMITATIONS.md) |

## Quick start

Tools used (Ubuntu 24.04 packages): Verilator 5.020, Icarus Verilog 12, Yosys 0.33, `gcc-riscv64-unknown-elf`
13.2, host gcc + `libssl-dev`, Python 3 with PyYAML and `cryptography`; cocotb 1.9.2 (pip) for `make unit`.

```bash
sudo apt-get install -y verilator iverilog yosys gcc-riscv64-unknown-elf libssl-dev python3-yaml python3-cryptography
```

```bash
pip install cocotb==1.9.2
```

```bash
make all
```

Or step by step: `make ref` (software reference), `make fw` (secure ROM + signed firmware), `make unit-sb`,
`make sb-regress` (security regression, ~6 min on 4 cores), `make regress` (with the accelerators), `make lint`,
`make isa`, `make synth`, `make summary`.

Sign your own image (prototype test key of ROM slot 1 — not secret):

```bash
python3 tools/sfsign.py --elf fw.elf --bin fw.bin --key keys/test/slot1_TEST_PROD_NOT_FOR_DEVICES.pem --slot 1 --svn 1 --out build/my_fw
```

```bash
python3 tools/sbimage.py verify build/my_fw.img --lc PROD
```

## Layout

```
config/       cc_memmap.yaml (address map v2.0, single source of truth)
rtl/          silicaflux_secure_boot.sv (primary), sb_*.sv, silicaflux_control_core.sv (ControlCore v2), generated/
integration/  ControlCore v2 + the real accelerator subsystem
firmware/     bootrom/ (secure ROM), sb/ (manifest + policy, shared with ref/), app/ (P21 firmware + P28 changes)
tools/        sfsign.py (signer), sbimage.py (format + reference verifier), sbkeys.py, mkvectors.py
keys/         TEST / DEVELOPMENT keys (derived from public labels: NOT secret)
ref/          native build of the ROM policy + verifier, run_ref.py (step 1)
vectors/      independent known-good vectors (NIST CAVP, djb/RFC 8032, Wycheproof)
tb/           tb_sb_system.sv (security), tb_cc_system.sv (system), unit_sb/ (new RTL), unit/ (P21 blocks)
scripts/      map generator, regressions, lint, ISA, synthesis, vendor check, summary
third_party/  unmodified sources: P21 blocks + originals, MCU-I, DataFabric, accelerators, secworks-sha256, Monocypher
docs/         00 audit ... 13 limitations, MEMORY_MAP (generated)
reports/      outputs of the final run (SUMMARY.md)
```
