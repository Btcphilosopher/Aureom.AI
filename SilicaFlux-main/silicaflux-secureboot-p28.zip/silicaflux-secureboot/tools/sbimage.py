#!/usr/bin/env python3
"""SilicaFlux secure boot (Project 28) -- image format + reference verifier.

This module is the *software-validated reference* for the boot ROM:

  * pack/unpack of the 256-byte manifest v1 (docs/04_IMAGE_FORMAT.md),
  * signing (Ed25519, RFC 8032, via the `cryptography` package = OpenSSL),
  * an independent re-implementation of the ROM policy (`check_manifest`) and of
    the whole verification (`verify_image`), using hashlib SHA-256 and
    OpenSSL Ed25519 verification instead of the ROM's hardware SHA-256 and
    Monocypher.  ref/run_ref.py requires identical error codes from this module
    and from the C policy code compiled natively; the RTL regression requires the
    same codes from the boot ROM running on the RTL.

Only the numeric constants are shared with the C/RTL code (scripts/generated/
cc_memmap.py, generated from config/cc_memmap.yaml); the logic is written
independently.

CLI:  sbimage.py verify <image.img> [--lc DEV|PROV|PROD|RECOVERY] [--revoked 0x0]
                        [--min-svn N] [--rollback 0|1]
      sbimage.py dump <image.img>
"""
import argparse
import hashlib
import json
import os
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "scripts", "generated"))
import cc_memmap as M  # noqa: E402

from cryptography.exceptions import InvalidSignature  # noqa: E402
from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import (  # noqa: E402
    Ed25519PrivateKey, Ed25519PublicKey)

FMT = "<IHH" + "I" * 14 + "32s32s64s64s"
FIELDS = ["magic", "manifest_version", "manifest_size", "target_id", "target_hw_version", "hash_alg",
          "sig_alg", "key_id", "policy_version", "fw_version", "security_version", "flags", "load_addr",
          "image_offset", "image_length", "entry", "reserved0", "image_digest", "build_id", "reserved1",
          "signature"]
assert struct.calcsize(FMT) == M.CC_SB_MANIFEST_SIZE == 0x100

ERR = {k[len("CC_BOOT_ERR_"):]: v for k, v in vars(M).items() if k.startswith("CC_BOOT_ERR_")}
ERR_NAME = {v: k for k, v in ERR.items()}
LC = {"DEV": M.CC_SB_LC_DEV, "PROV": M.CC_SB_LC_PROV, "PROD": M.CC_SB_LC_PROD, "RECOVERY": M.CC_SB_LC_RECOVERY}
ROM_KEYS_JSON = os.path.join(ROOT, "keys", "rom_keys.json")


def err_name(code):
    return ERR_NAME.get(code, f"0x{code:02x}")


# ----------------------------------------------------------------------------- keys
def load_private(path):
    with open(path, "rb") as f:
        k = serialization.load_pem_private_key(f.read(), password=None)
    if not isinstance(k, Ed25519PrivateKey):
        raise SystemExit(f"{path}: not an Ed25519 private key")
    return k


def raw_public(priv):
    return priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def rom_keys():
    """The 4 root public keys compiled into the ROM (keys/rom_keys.json)."""
    with open(ROM_KEYS_JSON) as f:
        j = json.load(f)
    return [bytes.fromhex(s["public"]) for s in sorted(j["slots"], key=lambda s: s["slot"])]


# ----------------------------------------------------------------------------- manifest
def default_manifest():
    return dict(magic=M.CC_SB_MANIFEST_MAGIC, manifest_version=M.CC_SB_MANIFEST_VERSION,
                manifest_size=M.CC_SB_MANIFEST_SIZE, target_id=M.CC_SB_TARGET_ID,
                target_hw_version=M.CC_SB_HW_VERSION, hash_alg=M.CC_SB_HASH_SHA256, sig_alg=M.CC_SB_SIG_ED25519,
                key_id=1, policy_version=M.CC_SB_POLICY_VERSION, fw_version=0x00020000, security_version=0, flags=0,
                load_addr=M.CC_IMEM_BASE, image_offset=M.CC_SB_MANIFEST_SIZE, image_length=0, entry=0, reserved0=0,
                image_digest=b"\0" * 32, build_id=b"\0" * 32, reserved1=b"\0" * 64, signature=b"\0" * 64)


def pack(m):
    return struct.pack(FMT, *[m[f] for f in FIELDS])


def unpack(b):
    return dict(zip(FIELDS, struct.unpack(FMT, b[:M.CC_SB_MANIFEST_SIZE])))


def sign_manifest(m, priv):
    """Fill m['signature'] = Ed25519(priv, manifest bytes [0, SIGNED_BYTES))."""
    m = dict(m)
    m["signature"] = priv.sign(pack(m)[:M.CC_SB_SIGNED_BYTES])
    return m


def build_image(payload, entry, priv, key_id, fw_version=0x00020000, svn=0, flags=0, build_id=b"", **override):
    """Signed image bytes = manifest || payload.  `override` replaces manifest fields
    *before* signing (used to produce correctly signed but policy-invalid test images)."""
    payload = bytes(payload) + b"\0" * ((-len(payload)) % 4)
    m = default_manifest()
    m.update(key_id=key_id, fw_version=fw_version, security_version=svn, flags=flags, image_length=len(payload),
             entry=entry, image_digest=hashlib.sha256(payload).digest(),
             build_id=(build_id + b"\0" * 32)[:32])
    m.update(override)
    m = sign_manifest(m, priv)
    return pack(m) + payload


# ----------------------------------------------------------------------------- reference policy
class Ctx:
    def __init__(self, lc="DEV", revoked=0, min_svn=0, rollback=None):
        self.lc = LC[lc] if isinstance(lc, str) else lc
        self.revoked = revoked
        self.min_svn = min_svn
        # rollback is always enforced outside DEV; optional (fuse CFG bit) in DEV
        self.rollback = (self.lc != M.CC_SB_LC_DEV) if rollback is None else bool(rollback or self.lc != M.CC_SB_LC_DEV)
        self.target_id = M.CC_SB_TARGET_ID
        self.hw_version = M.CC_SB_HW_VERSION


def check_manifest(m, ctx):
    """Independent implementation of the ROM manifest policy.  Same check order as
    firmware/sb/sb_policy.c (the order is part of the specification)."""
    E = ERR
    if m["magic"] != M.CC_SB_MANIFEST_MAGIC:
        return E["M_MAGIC"]
    if m["manifest_version"] != M.CC_SB_MANIFEST_VERSION:
        return E["M_VERSION"]
    if m["manifest_size"] != M.CC_SB_MANIFEST_SIZE:
        return E["M_SIZE"]
    if m["hash_alg"] != M.CC_SB_HASH_SHA256:
        return E["HASH_ALG"]
    if m["sig_alg"] != M.CC_SB_SIG_ED25519:
        return E["SIG_ALG"]
    if m["policy_version"] != M.CC_SB_POLICY_VERSION:
        return E["POLICY"]
    if m["target_id"] != ctx.target_id:
        return E["TARGET"]
    hw_major, hw_minor = ctx.hw_version >> 16, ctx.hw_version & 0xFFFF
    if m["target_hw_version"] >> 16 != hw_major or (m["target_hw_version"] & 0xFFFF) > hw_minor:
        return E["TARGET_HW"]
    if not 0 <= m["key_id"] < M.CC_SB_NKEYS:
        return E["KEY_ID"]
    if (M.CC_SB_DEV_KEY_MASK >> m["key_id"]) & 1 and ctx.lc != M.CC_SB_LC_DEV:
        return E["KEY_LIFECYCLE"]
    if (ctx.revoked >> m["key_id"]) & 1:
        return E["KEY_REVOKED"]
    if m["flags"] & ~M.CC_SB_FLAGS_KNOWN & 0xFFFFFFFF:
        return E["FLAGS"]
    if m["flags"] & M.CC_SB_FLAG_DEV_ONLY and ctx.lc != M.CC_SB_LC_DEV:
        return E["FLAGS"]
    if m["reserved0"] != 0 or any(m["reserved1"]):
        return E["RESERVED"]
    if m["load_addr"] != M.CC_IMEM_BASE or m["image_offset"] != M.CC_SB_MANIFEST_SIZE:
        return E["LOAD_ADDR"]
    n = m["image_length"]
    if n == 0 or n % 4 or n > M.CC_IMEM_SIZE - M.CC_SB_MANIFEST_SIZE:
        return E["LENGTH"]
    lo = M.CC_IMEM_BASE + M.CC_SB_MANIFEST_SIZE
    if not (lo <= m["entry"] < lo + n) or m["entry"] % 4:
        return E["ENTRY"]
    if m["security_version"] > M.CC_SB_SVN_MAX:
        return E["SVN_RANGE"]
    if ctx.rollback and m["security_version"] < ctx.min_svn:
        return E["ROLLBACK"]
    return E["NONE"]


def imem_view(img):
    """What the ROM sees after a host load: IMEM scrubbed to zero, then the image
    bytes written from CC_IMEM_BASE (writes beyond IMEM are refused by hardware)."""
    v = bytearray(M.CC_IMEM_SIZE)
    n = min(len(img), M.CC_IMEM_SIZE)
    v[:n] = img[:n]
    return bytes(v)


def verify_image(img, ctx, keys=None):
    """Full reference verification of `img` as loaded into IMEM.  Returns
    (BOOT_ERR code, info dict).  Order: manifest policy -> SHA-256 of the payload
    -> Ed25519 over the manifest -> digest comparison (same as the ROM)."""
    keys = rom_keys() if keys is None else keys
    v = imem_view(img)
    m = unpack(v)
    e = check_manifest(m, ctx)
    info = {"manifest": m}
    if e:
        return e, info
    off, n = m["image_offset"], m["image_length"]
    digest = hashlib.sha256(v[off:off + n]).digest()
    info["digest"] = digest
    try:
        Ed25519PublicKey.from_public_bytes(keys[m["key_id"]]).verify(m["signature"], v[:M.CC_SB_SIGNED_BYTES])
    except InvalidSignature:
        return ERR["SIGNATURE"], info
    if digest != m["image_digest"]:
        return ERR["DIGEST"], info
    return ERR["NONE"], info


def write_outputs(img, prefix, meta=None):
    with open(prefix + ".img", "wb") as f:
        f.write(img)
    padded = img + b"\0" * ((-len(img)) % 4)
    with open(prefix + ".hex", "w") as f:
        for i in range(0, len(padded), 4):
            f.write("%08x\n" % struct.unpack_from("<I", padded, i)[0])
    m = unpack(img + b"\0" * max(0, M.CC_SB_MANIFEST_SIZE - len(img)))
    j = {k: (v.hex() if isinstance(v, bytes) else (f"0x{v:08x}" if isinstance(v, int) else v)) for k, v in m.items()}
    j["file_bytes"] = len(img)
    j["words"] = len(padded) // 4
    if meta:
        j.update(meta)
    with open(prefix + ".json", "w") as f:
        json.dump(j, f, indent=1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("verify")
    v.add_argument("image")
    v.add_argument("--lc", default="DEV", choices=list(LC))
    v.add_argument("--revoked", type=lambda x: int(x, 0), default=0)
    v.add_argument("--min-svn", type=int, default=0)
    v.add_argument("--rollback", type=int, default=0)
    d = sub.add_parser("dump")
    d.add_argument("image")
    a = ap.parse_args()
    img = open(a.image, "rb").read()
    if a.cmd == "dump":
        for k, val in unpack(imem_view(img)).items():
            print(f"{k:18s} {val.hex() if isinstance(val, bytes) else f'0x{val:08x}'}")
        return
    code, info = verify_image(img, Ctx(a.lc, a.revoked, a.min_svn, a.rollback))
    print(f"{err_name(code)} 0x{code:02x}")
    sys.exit(0 if code == 0 else 1)


if __name__ == "__main__":
    main()
