#!/usr/bin/env python3
"""SilicaFlux secure boot (Project 28) -- security test-image corpus.

    mkvectors.py --elf fw.elf --bin fw.payload.bin --out build/vectors     (images over real firmware)
    mkvectors.py --synthetic --out build/vectors_syn                        (random payload)

Every case = (image bytes, device context, EXPECTED BOOT_ERR code).  The
expected codes are written here from the specification (docs/04_IMAGE_FORMAT.md),
not computed: ref/run_ref.py checks that the Python reference AND the native
build of the ROM policy return exactly these codes, and the RTL regression
checks that the boot ROM on the RTL reports them.

Images that must be *correctly signed* but policy-invalid (wrong target,
oversized length, unsupported algorithm ...) are signed after the field is set,
so they test the policy, not merely the signature.
"""
import argparse
import hashlib
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sbimage as S  # noqa: E402

M = S.M
E = S.ERR
ROOT = S.ROOT
L_ED25519 = 2 ** 252 + 27742317777372353535851937790883648493


def key(rel):
    return S.load_private(os.path.join(ROOT, rel))


def keyfiles():
    j = json.load(open(S.ROM_KEYS_JSON))
    ks = {s["slot"]: s["private_key_file"] for s in j["slots"]}
    return ks, j["attacker"]["private_key_file"]


def resign(img, priv):
    m = S.unpack(img)
    return S.pack(S.sign_manifest(m, priv)) + img[M.CC_SB_MANIFEST_SIZE:]


def patch_field(img, field, value, priv=None):
    """Change one manifest field; re-sign with `priv` if given (policy test), else
    leave the old signature (tamper test)."""
    m = S.unpack(img)
    m[field] = value
    out = S.pack(m) + img[M.CC_SB_MANIFEST_SIZE:]
    return resign(out, priv) if priv else out


def flip(img, off, mask=0x01):
    b = bytearray(img)
    b[off] ^= mask
    return bytes(b)


def make_cases(payload, entry):
    ks, atk = keyfiles()
    k = {s: key(p) for s, p in ks.items()}
    attacker = key(atk)
    base = S.build_image(payload, entry, k[1], 1, svn=2, build_id=b"p28-valid-slot1")
    n = len(payload) + ((-len(payload)) % 4)
    H = M.CC_SB_MANIFEST_SIZE
    cases = []

    def add(name, img, expect, lc="PROD", revoked=0, min_svn=0, rollback=0, req="", note=""):
        cases.append(dict(name=name, img=img, expect=expect, lc=lc, revoked=revoked, min_svn=min_svn,
                          rollback=rollback, req=req, note=note))

    # ---- positive
    add("valid_slot1_prod", base, E["NONE"], req="valid signature")
    add("valid_slot2_prod", S.build_image(payload, entry, k[2], 2, svn=2), E["NONE"], req="valid signature (rotated key)")
    add("valid_dev_key_dev", S.build_image(payload, entry, k[0], 0), E["NONE"], lc="DEV", req="valid signature (DEV)")
    add("valid_prod_key_dev", base, E["NONE"], lc="DEV", req="production key on a DEV part")
    add("valid_recovery", base, E["NONE"], lc="RECOVERY", req="valid signature in RECOVERY")
    add("valid_svn_equal_min", base, E["NONE"], min_svn=2, req="version rollback (boundary)")
    # ---- invalid signature
    add("sig_bitflip_R", flip(base, 0xC0), E["SIGNATURE"], req="invalid signature")
    add("sig_bitflip_S", flip(base, 0xE0), E["SIGNATURE"], req="invalid signature")
    add("sig_zero", base[:0xC0] + b"\0" * 64 + base[H:], E["SIGNATURE"], req="invalid signature")
    m = S.unpack(base)
    s_int = int.from_bytes(m["signature"][32:], "little") + L_ED25519
    if s_int < 2 ** 256:
        mal = base[:0xE0] + s_int.to_bytes(32, "little") + base[H:]
        add("sig_noncanonical_S_plus_L", mal, E["SIGNATURE"], req="invalid signature",
            note="malleability: S + L must be rejected (RFC 8032 5.1.7)")
    # ---- wrong key
    add("wrong_key_attacker", S.build_image(payload, entry, attacker, 1, svn=2), E["SIGNATURE"], req="wrong key",
        note="signed by a key that is not in the ROM, claims slot 1")
    add("wrong_key_other_slot", S.build_image(payload, entry, k[2], 1, svn=2), E["SIGNATURE"], req="wrong key",
        note="signed by slot 2's key, claims slot 1")
    add("dev_key_on_prod", S.build_image(payload, entry, k[0], 0), E["KEY_LIFECYCLE"], req="wrong key",
        note="development key refused outside DEV")
    add("revoked_slot1", base, E["KEY_REVOKED"], revoked=0x2, req="wrong key (revoked)")
    add("key_id_out_of_range", patch_field(base, "key_id", 4, k[1]), E["KEY_ID"], req="unsupported manifest")
    # ---- modified image
    add("modified_payload_byte", flip(base, H + n // 2), E["DIGEST"], req="modified image")
    add("modified_payload_last", flip(base, H + n - 1, 0x80), E["DIGEST"], req="modified image")
    add("modified_manifest_fwver", patch_field(base, "fw_version", 0x00099999), E["SIGNATURE"], req="modified image",
        note="manifest field changed after signing")
    add("modified_manifest_digest", patch_field(base, "image_digest", hashlib.sha256(b"evil").digest()),
        E["SIGNATURE"], req="modified image")
    add("modified_manifest_svn", patch_field(base, "security_version", 9), E["SIGNATURE"], req="modified image")
    add("modified_manifest_keyid", patch_field(base, "key_id", 2), E["SIGNATURE"], req="modified image")
    # ---- truncated
    add("truncated_payload", base[:len(base) - 256], E["DIGEST"], req="truncated image",
        note="last 256 bytes missing: IMEM reads scrubbed zeros")
    add("truncated_in_signature", base[:0xD0], E["SIGNATURE"], req="truncated image")
    add("truncated_manifest_6", base[:6], E["M_SIZE"], req="truncated image",
        note="magic + version present, manifest_size reads 0")
    add("empty_image", b"", E["M_MAGIC"], req="truncated image")
    # ---- oversized
    add("oversized_length", patch_field(base, "image_length", M.CC_IMEM_SIZE - H + 4, k[1]), E["LENGTH"],
        req="oversized image")
    add("oversized_length_wrap", patch_field(base, "image_length", 0xFFFFFFFC, k[1]), E["LENGTH"],
        req="oversized image", note="length that would wrap a 32-bit end address")
    big = bytes((i * 37) & 0xFF for i in range(M.CC_IMEM_SIZE))           # payload larger than IMEM
    add("oversized_file", S.build_image(big, entry, k[1], 1), E["LENGTH"], req="oversized image")
    add("zero_length", patch_field(base, "image_length", 0, k[1]), E["LENGTH"], req="unsupported manifest")
    add("unaligned_length", patch_field(base, "image_length", n - 2, k[1]), E["LENGTH"], req="unsupported manifest")
    # ---- unsupported manifest
    add("bad_magic", patch_field(base, "magic", 0x43434653, k[1]), E["M_MAGIC"], req="unsupported manifest",
        note="P21 CRC-format magic 'SFCC'")
    add("manifest_version_2", patch_field(base, "manifest_version", 2, k[1]), E["M_VERSION"], req="unsupported manifest")
    add("manifest_size_0x200", patch_field(base, "manifest_size", 0x200, k[1]), E["M_SIZE"], req="unsupported manifest")
    add("hash_alg_sha384", patch_field(base, "hash_alg", 2, k[1]), E["HASH_ALG"], req="unsupported manifest")
    add("sig_alg_ecdsa_p256", patch_field(base, "sig_alg", 2, k[1]), E["SIG_ALG"], req="unsupported manifest")
    add("policy_version_2", patch_field(base, "policy_version", 2, k[1]), E["POLICY"], req="unsupported manifest")
    add("unknown_flag", patch_field(base, "flags", 0x80, k[1]), E["FLAGS"], req="unsupported manifest")
    add("dev_only_on_prod", patch_field(base, "flags", M.CC_SB_FLAG_DEV_ONLY, k[1]), E["FLAGS"],
        req="incorrect target")
    add("dev_only_on_dev", patch_field(base, "flags", M.CC_SB_FLAG_DEV_ONLY, k[1]), E["NONE"], lc="DEV",
        req="incorrect target (positive)")
    add("reserved0_set", patch_field(base, "reserved0", 1, k[1]), E["RESERVED"], req="unsupported manifest")
    add("reserved1_set", patch_field(base, "reserved1", b"\x01" + b"\0" * 63, k[1]), E["RESERVED"],
        req="unsupported manifest")
    add("load_addr_dmem", patch_field(base, "load_addr", M.CC_DMEM_BASE, k[1]), E["LOAD_ADDR"],
        req="unsupported manifest")
    add("image_offset_0x200", patch_field(base, "image_offset", 0x200, k[1]), E["LOAD_ADDR"],
        req="unsupported manifest")
    add("entry_in_manifest", patch_field(base, "entry", M.CC_IMEM_BASE, k[1]), E["ENTRY"], req="unsupported manifest")
    add("entry_past_end", patch_field(base, "entry", M.CC_IMEM_BASE + H + n, k[1]), E["ENTRY"],
        req="unsupported manifest")
    add("entry_unaligned", patch_field(base, "entry", entry + 2, k[1]), E["ENTRY"], req="unsupported manifest")
    # ---- incorrect target
    add("target_id_other", patch_field(base, "target_id", 0x43544653, k[1]), E["TARGET"], req="incorrect target",
        note="'SFTC' tensor-unit identity")
    add("target_hw_major_1", patch_field(base, "target_hw_version", 0x00010000, k[1]), E["TARGET_HW"],
        req="incorrect target", note="image built for the P21 ControlCore v1")
    add("target_hw_minor_newer", patch_field(base, "target_hw_version", M.CC_SB_HW_VERSION + 1, k[1]),
        E["TARGET_HW"], req="incorrect target")
    # ---- rollback
    add("rollback_prod", base, E["ROLLBACK"], min_svn=3, req="version rollback")
    add("rollback_dev_not_enforced", base, E["NONE"], lc="DEV", min_svn=3, rollback=0,
        req="version rollback (optional in DEV)")
    add("rollback_dev_enforced", base, E["ROLLBACK"], lc="DEV", min_svn=3, rollback=1,
        req="version rollback (enforced in DEV by fuse CFG)")
    add("svn_out_of_range", patch_field(base, "security_version", 33, k[1]), E["SVN_RANGE"], req="version rollback")
    return cases


def synthetic_payload():
    p = bytearray(hashlib.sha256(b"p28 synthetic payload").digest() * 400)    # 12 800 bytes
    return bytes(p), M.CC_IMEM_BASE + M.CC_SB_MANIFEST_SIZE


def elf_entry(path):
    with open(path, "rb") as f:
        hdr = f.read(52)
    return struct.unpack_from("<I", hdr, 0x18)[0]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--elf")
    ap.add_argument("--bin")
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if a.synthetic:
        payload, entry = synthetic_payload()
    else:
        payload, entry = open(a.bin, "rb").read(), elf_entry(a.elf)
    os.makedirs(a.out, exist_ok=True)
    index = []
    for c in make_cases(payload, entry):
        S.write_outputs(c["img"], os.path.join(a.out, c["name"]))
        index.append({k: v for k, v in c.items() if k != "img"} | {"expect_name": S.err_name(c["expect"])})
    with open(os.path.join(a.out, "index.json"), "w") as f:
        json.dump(index, f, indent=1)
    # plain index for the RTL testbench: the device context expressed as fuse-model words
    lc_code = {"DEV": M.CC_SB_LC_CODE_DEV, "PROV": M.CC_SB_LC_CODE_PROV, "PROD": M.CC_SB_LC_CODE_PROD,
               "RECOVERY": M.CC_SB_LC_CODE_PROD}
    with open(os.path.join(a.out, "tb_index.txt"), "w") as f:
        for c in index:
            svn = (1 << c["min_svn"]) - 1 if c["min_svn"] < 32 else 0xFFFFFFFF
            f.write(f"{c['name']} {c['expect']:02x} {lc_code[c['lc']]:08x} {c['revoked']:08x} {svn:08x} "
                    f"{1 if c['rollback'] else 0:08x} {1 if c['lc'] == 'RECOVERY' else 0} "
                    f"{os.path.relpath(os.path.join(a.out, c['name'] + '.hex'), ROOT)}\n")
    print(f"mkvectors: {len(index)} cases -> {a.out}")


if __name__ == "__main__":
    main()
