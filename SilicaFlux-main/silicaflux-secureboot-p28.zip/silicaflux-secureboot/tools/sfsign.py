#!/usr/bin/env python3
"""SilicaFlux secure boot (Project 28) -- firmware signing utility.

    sfsign.py --elf fw.elf --bin fw.payload.bin --key keys/test/slot1_....pem --slot 1 \
              [--fw-version 0x00020000] [--svn 0] [--dev-only] [--build-id TEXT] --out build/fw/name

Produces <out>.img (manifest || payload), <out>.hex (little-endian 32-bit words,
for the testbench host loader and the device-memory image store) and <out>.json.

Algorithm: SHA-256 (hashlib) of the payload into the manifest; Ed25519
(RFC 8032, `cryptography` / OpenSSL) over manifest bytes [0x00, 0xC0).
Safety checks before anything is written:
  * the private key must match the ROM public key of --slot (keys/rom_keys.json),
  * the ELF entry point must lie inside the payload,
  * the result is verified with the independent reference verifier
    (tools/sbimage.py) under the lifecycle the key is meant for.
This tool signs with keys from files.  A production signer must keep the key
in an HSM and sign through it; see docs/06_KEY_MANAGEMENT.md.
"""
import argparse
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sbimage as S  # noqa: E402


def elf_entry(path):
    with open(path, "rb") as f:
        hdr = f.read(52)
    if hdr[:4] != b"\x7fELF" or hdr[4] != 1:
        sys.exit("sfsign: not an ELF32 file")
    return struct.unpack_from("<I", hdr, 0x18)[0]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--elf", required=True)
    ap.add_argument("--bin", required=True, help="objcopy -O binary payload (starts at IMEM_BASE + 0x100)")
    ap.add_argument("--key", required=True)
    ap.add_argument("--slot", type=int, required=True)
    ap.add_argument("--fw-version", type=lambda x: int(x, 0), default=0x00020000)
    ap.add_argument("--svn", type=int, default=0)
    ap.add_argument("--dev-only", action="store_true", help="set FLAG_DEV_ONLY (image runs on DEV parts only)")
    ap.add_argument("--build-id", default="")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    priv = S.load_private(a.key)
    keys = S.rom_keys()
    if not 0 <= a.slot < len(keys):
        sys.exit(f"sfsign: slot {a.slot} out of range")
    if S.raw_public(priv) != keys[a.slot]:
        sys.exit(f"sfsign: {a.key} does not match the ROM public key of slot {a.slot}")
    payload = open(a.bin, "rb").read()
    entry = elf_entry(a.elf)
    img = S.build_image(payload, entry, priv, a.slot, fw_version=a.fw_version, svn=a.svn,
                        flags=S.M.CC_SB_FLAG_DEV_ONLY if a.dev_only else 0, build_id=a.build_id.encode())
    lc = "DEV" if (S.M.CC_SB_DEV_KEY_MASK >> a.slot) & 1 or a.dev_only else "PROD"
    code, info = S.verify_image(img, S.Ctx(lc))
    if code:
        sys.exit(f"sfsign: reference verification FAILED: {S.err_name(code)} -- nothing written")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    S.write_outputs(img, a.out, {"signed_with_slot": a.slot, "reference_verdict": f"OK ({lc})"})
    m = info["manifest"]
    print(f"sfsign: {a.out}.img {len(img)} B slot {a.slot} svn {a.svn} entry 0x{entry:08x} "
          f"sha256 {m['image_digest'].hex()[:16]}... ref-verify OK ({lc})")


if __name__ == "__main__":
    main()
