// =============================================================================
// SilicaFlux secure boot :: sb_sha256_stream -- FIPS 180-4 message padding and
// block assembly around the vendored secworks SHA-256 compression core
//
// The cryptographic transformation is entirely third_party/secworks-sha256
// (sha256_core + sha256_w_mem + sha256_k_constants, BSD-2-Clause, commit
// 837c5cc, unmodified).  This block only does what FIPS 180-4 section 5.1.1
// specifies around it: collect the message into 512-bit blocks, append the
// 0x80 byte, zero fill, append the 64-bit big-endian bit length, and drive the
// core's init/next handshake.  Byte-granular lengths are supported so the
// NIST CAVP byte-oriented vectors exercise every padding position.
//
// Stream protocol (one message at a time):
//   start            pulse while !busy: begin a new message
//   in_valid/in_ready one big-endian word per beat (first message byte in
//                    [31:24]); in_nbytes = 1..4 valid bytes from the MSB; a
//                    word with in_nbytes < 4 must be the last data word
//   finish           pulse after the last data word (or right after start for
//                    the empty message); the digest follows
//   done             one-cycle pulse; digest stays valid until the next start
// Throughput: 16 data beats + 66 compression cycles per 64-byte block.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sb_sha256_stream (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         start,
  input  wire logic         in_valid,
  output logic              in_ready,
  input  wire logic [31:0]  in_data,
  input  wire logic [2:0]   in_nbytes,
  input  wire logic         finish,
  output logic              busy,
  output logic              done,
  output logic [255:0]      digest
);
  typedef enum logic [2:0] {S_IDLE, S_ABSORB, S_PAD, S_GO, S_WAIT} st_e;
  st_e         st;
  logic [31:0] blk [16];
  logic [4:0]  widx;            // next free word, 0..16
  logic [31:0] nbytes_q;        // message length in bytes (< 2^32)
  logic        first_q;         // next compression is the first block (core init)
  logic        partial_q;       // 0x80 already placed (last data word was partial)
  logic        need80_q;        // 0x80 still to place (message ended on a word boundary)
  logic        last_blk_q;      // the block being compressed is the final one

  // ------------------------------------------------------------ secworks core (unmodified)
  logic         c_init, c_next, c_ready, c_dvalid;
  logic [511:0] c_block;
  logic [255:0] c_digest;
  always_comb for (int i = 0; i < 16; i++) c_block[511 - 32 * i -: 32] = blk[i];
  sha256_core u_core (
    .clk, .reset_n(rst_n), .init(c_init), .next(c_next), .mode(1'b1),   // mode 1 = SHA-256
    .block(c_block), .ready(c_ready), .digest(c_digest), .digest_valid(c_dvalid)
  );
  assign c_init = (st == S_GO) && first_q;
  assign c_next = (st == S_GO) && !first_q;

  // ------------------------------------------------------------ data word with in-word padding
  logic [31:0] keep, word_pad;
  always_comb begin
    case (in_nbytes)
      3'd1:    keep = 32'hFF00_0000;
      3'd2:    keep = 32'hFFFF_0000;
      3'd3:    keep = 32'hFFFF_FF00;
      default: keep = 32'hFFFF_FFFF;
    endcase
    word_pad = in_data & keep;
    case (in_nbytes)
      3'd1:    word_pad = word_pad | 32'h0080_0000;
      3'd2:    word_pad = word_pad | 32'h0000_8000;
      3'd3:    word_pad = word_pad | 32'h0000_0080;
      default: ;
    endcase
  end
  wire [2:0] nb  = (in_nbytes == 3'd0 || in_nbytes > 3'd4) ? 3'd4 : in_nbytes;   // 0/5..7 treated as 4
  assign in_ready = (st == S_ABSORB) && (widx < 5'd16) && !partial_q;
  wire   take     = in_valid && in_ready;
  assign busy     = (st != S_IDLE);

  wire [63:0] bitlen = {29'd0, nbytes_q, 3'b000};

  logic fin_q;      // finish requested (latched: a pulse during a compression is not lost)
  logic padding_q;  // message ended: all further words are padding
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; widx <= '0; nbytes_q <= '0; first_q <= 1'b1; partial_q <= 1'b0; need80_q <= 1'b0;
      last_blk_q <= 1'b0; done <= 1'b0; digest <= '0; fin_q <= 1'b0; padding_q <= 1'b0;
      for (int i = 0; i < 16; i++) blk[i] <= '0;
    end else begin
      done <= 1'b0;
      if (finish && st != S_IDLE) fin_q <= 1'b1;
      case (st)
        S_IDLE: if (start) begin
          widx <= '0; nbytes_q <= '0; first_q <= 1'b1; partial_q <= 1'b0; need80_q <= 1'b0; last_blk_q <= 1'b0;
          fin_q <= finish; padding_q <= 1'b0;
          st <= S_ABSORB;
        end
        S_ABSORB: begin
          if (take) begin
            blk[widx[3:0]] <= (nb == 3'd4) ? in_data : word_pad;
            widx           <= widx + 5'd1;
            nbytes_q       <= nbytes_q + 32'(nb);
            if (nb != 3'd4) partial_q <= 1'b1;
          end else if (widx == 5'd16) begin
            st <= S_GO;                                   // full data block
          end else if (fin_q || finish) begin
            need80_q  <= !partial_q;
            padding_q <= 1'b1;
            st <= S_PAD;
          end
        end
        S_PAD: begin
          if (widx == 5'd16) begin
            st <= S_GO;
          end else if (need80_q) begin
            blk[widx[3:0]] <= 32'h8000_0000; widx <= widx + 5'd1; need80_q <= 1'b0;
          end else if (widx == 5'd14) begin
            blk[14] <= bitlen[63:32]; blk[15] <= bitlen[31:0]; widx <= 5'd16; last_blk_q <= 1'b1;
          end else begin
            blk[widx[3:0]] <= 32'd0; widx <= widx + 5'd1;
          end
        end
        S_GO: if (c_ready) st <= S_WAIT;                 // init/next asserted in this cycle
        S_WAIT: if (c_ready) begin                        // the core drops ready the cycle after GO
          first_q <= 1'b0;
          widx    <= '0;
          if (last_blk_q) begin
            digest <= c_digest; done <= 1'b1; fin_q <= 1'b0; st <= S_IDLE;
          end else begin
            st <= padding_q ? S_PAD : S_ABSORB;
          end
        end
        default: st <= S_IDLE;
      endcase
    end
  end
  wire unused_ok = c_dvalid;
endmodule

`default_nettype wire
