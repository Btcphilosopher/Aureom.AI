// =============================================================================
// SilicaFlux secure boot :: sb_bootrom -- mask-ROM slave for the 32 KiB secure ROM
//
// Same contract as SilicaFlux-V sfv_bootrom (third_party/silicaflux-v/rtl/mem/
// sfv_mem_slaves.sv): single-cycle grant, registered word address into the
// generated combinational image module sfv_bootrom_image, rvalid one cycle
// later, writes answer a bus error.  Why not the vendored module: its range
// check is the constant expression `{1'b0, addr[13:2]} < 13'(WORDS)`, which
// truncates WORDS = 8192 to 0 (every read returns 0) and ignores address bit
// 14 -- it supports at most 8191 words.  Found by the first P28 boot (ROM
// never executed).  Here the address and the bound are sized from AW.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sb_bootrom #(
  parameter int WORDS = 8192,
  localparam int AW = $clog2(WORDS)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        req,
  output logic             gnt,
  input  wire logic [31:0] addr,
  input  wire logic        we,
  input  wire logic [3:0]  be,
  input  wire logic [31:0] wdata,
  output logic             rvalid,
  output logic [31:0]      rdata,
  output logic             err
);
  logic [AW-1:0] a_q;
  logic          rd_q, range_q;
  logic [31:0]   img;
  wire unused_ok = ^{be, wdata, addr[31:AW+2], addr[1:0]};

  assign gnt = 1'b1;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rvalid <= 1'b0; err <= 1'b0; rd_q <= 1'b0; range_q <= 1'b0; a_q <= '0;
    end else begin
      rvalid <= req;
      err    <= req && we;
      rd_q   <= req && !we;
      if (req && !we) begin
        a_q     <= addr[AW+1:2];
        range_q <= ({1'b0, addr[AW+1:2]} < (AW + 1)'(WORDS));
      end
    end
  end

  sfv_bootrom_image u_img (.addr(a_q), .data(img));
  assign rdata = (rd_q && range_q) ? img : 32'd0;
endmodule

`default_nettype wire
