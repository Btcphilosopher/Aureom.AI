// =============================================================================
// SilicaFlux secure boot :: sb_access_policy -- per-master access decisions
//
// Purely combinational.  Each `*_refuse` output drives the `refuse` input of a
// cc_sfb_gate (Project 21, unmodified): a refused request never reaches the
// crossbar / memory; it is answered locally with an SFB2 error (instruction /
// load / store access fault for the CPU, error response for the host and the
// debug port) and reported to the secure-boot block (VIOL_*).
//
//  HOST  (untrusted in every lifecycle state)
//    read : IMEM; pages SYSCTRL, MAILBOX, PERF, PMU, RAS, SECURITY, DMA_GUARD
//    write: IMEM only while the secure-boot block is in LOAD;
//           MAILBOX H2F_MSG0..7, H2F_RING, F2H_ACK, DIAG_POP, DIAG_STATUS
//    everything else (BOOTROM, DMEM, DMA/INTC/WDT/MTIMER/accelerator pages,
//    any SECURITY / DMA_GUARD / SYSCTRL write ...) is refused.
//  CPU instruction fetch
//    BOOTROM while rom_fetch_open; IMEM only inside the authenticated execute
//    window [exec_base, exec_end) while exec_open.  Nothing else.
//  IMEM slave port (every master, after the crossbar -- master independent)
//    writes only while load_open, or after hand-off outside the execute
//    window (W^X).  This is the single choke point that enforces the seal.
//  DEBUG (JTAG system-bus access)
//    everything (still subject to the IMEM slave rule) when debug_en
//    (lifecycle DEV only); nothing otherwise.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sb_access_policy (
  input  wire logic        load_open,
  input  wire logic        exec_open,
  input  wire logic        rom_fetch_open,
  input  wire logic        debug_en,
  input  wire logic [31:0] exec_base,
  input  wire logic [31:0] exec_end,
  // host port request
  input  wire logic [31:0] host_addr,
  input  wire logic        host_write,
  output logic             host_refuse,
  // CPU instruction port request
  input  wire logic [31:0] fetch_addr,
  output logic             fetch_refuse,
  // IMEM slave port request (after the crossbar)
  input  wire logic [31:0] imem_addr,
  input  wire logic        imem_write,
  output logic             imem_refuse,
  // debug port request
  output logic             dbg_refuse
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */

  function automatic logic in_region(input logic [31:0] a, input logic [31:0] base, input logic [31:0] size);
    in_region = (a & ~(size - 32'd1)) == base;
  endfunction
  function automatic logic in_page(input logic [31:0] a, input int pg);
    in_page = in_region(a, CC_PERIPH_BASE + 32'(pg) * CC_PAGE_SIZE, CC_PAGE_SIZE);
  endfunction

  // ------------------------------------------------------------------ host
  logic [11:0] hofs;
  logic        h_imem, h_read_ok, h_mbox_wr_ok;
  always_comb begin
    hofs   = host_addr[11:0];
    h_imem = in_region(host_addr, CC_IMEM_BASE, CC_IMEM_SIZE);
    h_read_ok = h_imem || in_page(host_addr, CC_PG_SYSCTRL) || in_page(host_addr, CC_PG_MAILBOX) ||
                in_page(host_addr, CC_PG_PERF) || in_page(host_addr, CC_PG_PMU) || in_page(host_addr, CC_PG_RAS) ||
                in_page(host_addr, CC_PG_SECURITY) || in_page(host_addr, CC_PG_DMA_GUARD);
    h_mbox_wr_ok = in_page(host_addr, CC_PG_MAILBOX) &&
                   ((hofs & 12'hFE0) == CC_MBOX_H2F_MSG0 ||   /* H2F_MSG0..7 (32-byte aligned block) */
                    hofs == CC_MBOX_H2F_RING ||
                    hofs == CC_MBOX_F2H_ACK || hofs == CC_MBOX_DIAG_POP || hofs == CC_MBOX_DIAG_STATUS);
    host_refuse = host_write ? !((h_imem && load_open) || h_mbox_wr_ok) : !h_read_ok;
  end

  // ------------------------------------------------------------------ CPU instruction fetch
  wire in_window = exec_open && (fetch_addr >= exec_base) && (fetch_addr < exec_end);
  assign fetch_refuse = !((in_region(fetch_addr, CC_BOOTROM_BASE, CC_BOOTROM_SIZE) && rom_fetch_open) || in_window);

  // ------------------------------------------------------------------ IMEM slave port (W^X, seal)
  wire imem_in_window = (imem_addr >= exec_base) && (imem_addr < exec_end);
  assign imem_refuse = imem_write && !(load_open || (exec_open && !imem_in_window));

  // ------------------------------------------------------------------ debug
  assign dbg_refuse = !debug_en;
endmodule

`default_nettype wire
