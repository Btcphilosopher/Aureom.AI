// =============================================================================
// SilicaFlux secure boot :: sb_dma_guard -- access control for the system DMA
//
// Two independent layers in front of mcu_dma (MCU-I, unmodified):
//
//  1. Descriptor validation at START (register-bus filter on the DMA page).
//     The guard shadows SRC/DST/LENGTH/MODE exactly as mcu_dma latches them
//     (written only while the engine is idle).  On the CONTROL write that would
//     start a transfer it checks the WHOLE source and destination ranges:
//       * 33-bit end arithmetic: a range whose end passes 2^32 is refused
//         (SRC_OVF / DST_OVF) -- no wrap-around can alias a low address;
//       * the range must lie inside ONE enabled window with the needed
//         permission (READ for the source, WRITE for the destination);
//       * hard-wired protected regions, independent of the windows:
//         BOOTROM and PERIPH never; IMEM writes only while the secure-boot
//         block is in LOAD (protects the sealed / running firmware).
//     A refused START does not reach mcu_dma (no access at all, no partial
//     transfer); the register write answers rb_err, so the CPU takes a store
//     access fault it cannot overlook; DENY_* record the descriptor.
//     A fixed-address side covers its word [a & ~3, +4); an incrementing side
//     covers [a & ~3, (a + len + 3) & ~3) (word accesses, byte mode included).
//  2. Per-beat firewall: beat_ok gates every DMA bus request (cc_sfb_gate in
//     the ControlCore).  It applies the same windows + protected regions to
//     each word.  With the windows read-only while the DMA is busy it can only
//     trigger if layer 1 is wrong or the seal closes mid-transfer: defence in
//     depth.
//  Windows: DG_WINDOWS x {BASE, LAST (inclusive), ATTR = EN|READ|WRITE}.
//  Default after reset: all disabled -> the DMA can access nothing.  Writable
//  while unlocked and the DMA is idle; CTRL.LOCK makes them read-only until
//  the next system reset.  Who can write them: only the CPU (the host filter
//  refuses DMA_GUARD writes; the DMA has no PERIPH access; debug in DEV only).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sb_dma_guard #(
  parameter int NW = 4
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // own register page (DMA_GUARD)
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // DMA register page: filter between the peripheral bridge and mcu_dma
  input  wire logic        dma_rb_sel_i,
  output logic             dma_rb_sel_o,
  input  wire logic        dma_rb_err_i,
  output logic             dma_rb_err_o,
  input  wire logic        dma_busy,
  // secure-boot state
  input  wire logic        imem_load_open,
  // per-beat check of the DMA master request
  input  wire logic [31:0] beat_addr,
  input  wire logic        beat_write,
  output logic             beat_ok,
  input  wire logic        beat_refused,      // the gate refused a beat (pulse)
  // violation report
  output logic             viol_evt,
  output logic [31:0]      viol_addr
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  localparam logic [3:0] R_NONE = 4'(CC_DG_REASON_NONE), R_SRC = 4'(CC_DG_REASON_SRC_WINDOW),
                         R_DST = 4'(CC_DG_REASON_DST_WINDOW), R_SOVF = 4'(CC_DG_REASON_SRC_OVF),
                         R_DOVF = 4'(CC_DG_REASON_DST_OVF), R_PROT = 4'(CC_DG_REASON_PROTECTED),
                         R_BEAT = 4'(CC_DG_REASON_BEAT);

  // ------------------------------------------------------------------ windows
  logic [31:0] w_base [NW];
  logic [31:0] w_last [NW];
  logic [2:0]  w_attr [NW];
  logic        lock_q;

  // range [lo, end) (end exclusive, 33 bits, end > lo) inside one window with permission `wr`
  // (functions assign their name instead of `return`: Yosys 0.33 compatibility)
  function automatic logic in_windows(input logic [32:0] lo, input logic [32:0] hi, input logic wr);
    in_windows = 1'b0;
    for (int i = 0; i < NW; i++)
      if (w_attr[i][0] && (wr ? w_attr[i][2] : w_attr[i][1]) &&
          lo >= {1'b0, w_base[i]} && (hi - 33'd1) <= {1'b0, w_last[i]})
        in_windows = 1'b1;
  endfunction
  // [lo, hi) overlaps region [base, base + size)
  function automatic logic overlaps(input logic [32:0] lo, input logic [32:0] hi, input logic [31:0] base,
                                    input logic [31:0] size);
    overlaps = (lo < ({1'b0, base} + {1'b0, size})) && ({1'b0, base} < hi);
  endfunction
  function automatic logic protected_rng(input logic [32:0] lo, input logic [32:0] hi, input logic wr);
    protected_rng = overlaps(lo, hi, CC_BOOTROM_BASE, CC_BOOTROM_SIZE) || overlaps(lo, hi, CC_PERIPH_BASE, CC_PERIPH_SIZE) ||
                    (wr && !imem_load_open && overlaps(lo, hi, CC_IMEM_BASE, CC_IMEM_SIZE));
  endfunction

  // ------------------------------------------------------------------ shadow of the DMA configuration
  logic [31:0] s_src, s_dst, s_len;
  logic        s_sfix, s_dfix;
  wire dma_wr = dma_rb_sel_i && rb_we;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_src <= '0; s_dst <= '0; s_len <= '0; s_sfix <= 1'b0; s_dfix <= 1'b0;
    end else if (dma_wr && !dma_busy) begin             // identical condition to mcu_dma's cfg registers
      case (rb_addr)
        CC_DMA_SRC_ADDR: s_src <= rb_wdata;
        CC_DMA_DST_ADDR: s_dst <= rb_wdata;
        CC_DMA_LENGTH:   s_len <= rb_wdata;
        CC_DMA_MODE:     begin s_sfix <= rb_wdata[0]; s_dfix <= rb_wdata[1]; end
        default: ;
      endcase
    end
  end

  // ------------------------------------------------------------------ descriptor check (layer 1)
  logic [32:0] s_lo, s_hi, d_lo, d_hi;
  logic [3:0]  dreason;
  always_comb begin
    s_lo = {1'b0, s_src[31:2], 2'b00};
    d_lo = {1'b0, s_dst[31:2], 2'b00};
    s_hi = s_sfix ? s_lo + 33'd4 : (({1'b0, s_src} + {1'b0, s_len} + 33'd3) & ~33'd3);
    d_hi = s_dfix ? d_lo + 33'd4 : (({1'b0, s_dst} + {1'b0, s_len} + 33'd3) & ~33'd3);
    dreason = R_NONE;
    if (s_len != 32'd0) begin                      // zero length: mcu_dma refuses it itself (no access)
      if (s_hi > 33'h1_0000_0000)                  dreason = R_SOVF;
      else if (d_hi > 33'h1_0000_0000)             dreason = R_DOVF;
      else if (protected_rng(s_lo, s_hi, 1'b0) || protected_rng(d_lo, d_hi, 1'b1)) dreason = R_PROT;
      else if (!in_windows(s_lo, s_hi, 1'b0))      dreason = R_SRC;
      else if (!in_windows(d_lo, d_hi, 1'b1))      dreason = R_DST;
    end
  end
  wire start_req = dma_wr && rb_addr == CC_DMA_CONTROL && rb_wdata[0] && !dma_busy;
  wire deny      = start_req && (dreason != R_NONE);
  assign dma_rb_sel_o = dma_rb_sel_i && !deny;
  assign dma_rb_err_o = deny ? 1'b1 : dma_rb_err_i;

  // ------------------------------------------------------------------ per-beat check (layer 2)
  wire [32:0] b_lo = {1'b0, beat_addr[31:2], 2'b00};
  assign beat_ok = !protected_rng(b_lo, b_lo + 33'd4, beat_write) && in_windows(b_lo, b_lo + 33'd4, beat_write);

  // ------------------------------------------------------------------ registers
  localparam logic [11:0] A_CTRL = CC_DG_CTRL, A_STATUS = CC_DG_STATUS, A_INFO = CC_DG_INFO;
  localparam logic [11:0] A_WIN = CC_DG_WIN0_BASE;
  logic [31:0] dcnt_q, dsrc_q, ddst_q, dlen_q, baddr_q;
  logic [3:0]  dreason_q;
  logic        last_deny_q, beat_viol_q;
  wire         wr     = rb_sel && rb_we;
  wire [11:0]  wofs   = rb_addr - A_WIN;
  wire         is_win = (rb_addr >= A_WIN) && (rb_addr < A_WIN + 12'(16 * NW)) && (wofs[3:0] <= 4'h8);
  localparam int WIW = (NW > 1) ? $clog2(NW) : 1;
  wire [WIW-1:0] wi   = WIW'(wofs >> 4);
  wire         win_wr_ok = !lock_q && !dma_busy;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lock_q <= 1'b0; dcnt_q <= '0; dsrc_q <= '0; ddst_q <= '0; dlen_q <= '0; baddr_q <= '0;
      dreason_q <= R_NONE; last_deny_q <= 1'b0; beat_viol_q <= 1'b0;
      for (int i = 0; i < NW; i++) begin w_base[i] <= '0; w_last[i] <= '0; w_attr[i] <= '0; end
    end else begin
      if (wr && rb_addr == A_CTRL && rb_wdata[0]) lock_q <= 1'b1;
      if (wr && is_win && win_wr_ok) begin
        case (wofs[3:0])
          4'h0:    w_base[wi] <= rb_wdata;
          4'h4:    w_last[wi] <= rb_wdata;
          default: w_attr[wi] <= rb_wdata[2:0];
        endcase
      end
      if (wr && rb_addr == CC_DG_CLEAR && rb_wdata[0]) begin last_deny_q <= 1'b0; beat_viol_q <= 1'b0; end
      if (deny) begin
        last_deny_q <= 1'b1; dsrc_q <= s_src; ddst_q <= s_dst; dlen_q <= s_len; dreason_q <= dreason;
      end
      if (beat_refused) begin beat_viol_q <= 1'b1; baddr_q <= beat_addr; dreason_q <= R_BEAT; end
      if ((deny || beat_refused) && dcnt_q != 32'hFFFF_FFFF) dcnt_q <= dcnt_q + 32'd1;
    end
  end
  assign viol_evt  = deny || beat_refused;
  assign viol_addr = deny ? ((dreason == R_SRC || dreason == R_SOVF) ? s_src : s_dst) : beat_addr;

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (is_win) begin
      case (wofs[3:0])
        4'h0:    rb_rdata = w_base[wi];
        4'h4:    rb_rdata = w_last[wi];
        default: rb_rdata = {29'd0, w_attr[wi]};
      endcase
      rb_err = rb_we && !win_wr_ok;
    end else begin
      case (rb_addr)
        A_CTRL:              rb_rdata = {31'd0, lock_q};
        A_STATUS:            begin rb_rdata = {23'd0, beat_viol_q, 6'd0, last_deny_q, lock_q}; rb_err = rb_we; end
        A_INFO:              begin rb_rdata = 32'(NW); rb_err = rb_we; end
        CC_DG_DENY_COUNT:    begin rb_rdata = dcnt_q; rb_err = rb_we; end
        CC_DG_DENY_SRC:      begin rb_rdata = dsrc_q; rb_err = rb_we; end
        CC_DG_DENY_DST:      begin rb_rdata = ddst_q; rb_err = rb_we; end
        CC_DG_DENY_LEN:      begin rb_rdata = dlen_q; rb_err = rb_we; end
        CC_DG_DENY_REASON:   begin rb_rdata = {28'd0, dreason_q}; rb_err = rb_we; end
        CC_DG_BEAT_ADDR:     begin rb_rdata = baddr_q; rb_err = rb_we; end
        CC_DG_CLEAR:         rb_err = !rb_we;
        default:             rb_err = 1'b1;
      endcase
    end
  end
endmodule

`default_nettype wire
