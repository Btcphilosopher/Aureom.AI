// =============================================================================
// SilicaFlux secure boot :: sb_sha256_wrapper -- verified SHA-256 core wrapper
//
// = sb_sha256_stream (FIPS 180-4 padding around the vendored secworks core)
//   + a power-on known-answer self-test (KAT) through the SAME datapath.
//
// After every reset the wrapper hashes two FIPS 180-2 / NIST example messages
// before it accepts any client data:
//   KAT1 "abc" (3 bytes: partial-word padding, single block)
//        ba7816bf 8f01cfea 414140de 5dae2223 b00361a3 96177a9c b410ff61 f20015ad
//   KAT2 "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq" (56 bytes:
//        0x80 + length do not fit -> second, padding-only block; core `next`)
//        248d6a61 d20638b8 e5c02693 0c3e6039 a33ce459 64ff2167 f6ecedd4 19db06c1
// kat_ok = both digests bit-exact.  Until kat_done the client port is held off
// (in_ready = 0, start ignored); if kat_ok = 0 it stays held off forever and the
// secure-boot block goes to LOCKDOWN (fail closed: no measurement, no hand-off).
// A KAT detects a broken or faulty datapath at reset; it is not a defence
// against a fault injected later (docs/12_SECURITY_REVIEW.md).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sb_sha256_wrapper (
  input  wire logic         clk,
  input  wire logic         rst_n,
  // client stream (see sb_sha256_stream)
  input  wire logic         start,
  input  wire logic         in_valid,
  output logic              in_ready,
  input  wire logic [31:0]  in_data,
  input  wire logic [2:0]   in_nbytes,
  input  wire logic         finish,
  output logic              busy,
  output logic              done,
  output logic [255:0]      digest,
  // self-test status
  output logic              kat_done,
  output logic              kat_ok
);
  localparam logic [255:0] KAT1_MD = 256'hba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad;
  localparam logic [255:0] KAT2_MD = 256'h248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1;
  localparam logic [447:0] KAT2_MSG = 448'h6162636462636465636465666465666765666768666768696768696a68696a6b696a6b6c6a6b6c6d6b6c6d6e6c6d6e6f6d6e6f706e6f7071;

  typedef enum logic [2:0] {K_START1, K_FEED1, K_WAIT1, K_START2, K_FEED2, K_WAIT2, K_DONE} kst_e;
  kst_e        ks;
  logic [3:0]  kidx;
  logic        kat_pass1_q;

  // engine port mux: KAT sequencer until kat_done, then the client
  logic        e_start, e_valid, e_ready, e_finish, e_busy, e_done;
  logic [31:0] e_data;
  logic [2:0]  e_nbytes;
  logic [255:0] e_digest;
  sb_sha256_stream u_eng (
    .clk, .rst_n, .start(e_start), .in_valid(e_valid), .in_ready(e_ready), .in_data(e_data),
    .in_nbytes(e_nbytes), .finish(e_finish), .busy(e_busy), .done(e_done), .digest(e_digest)
  );

  wire        kat_active = (ks != K_DONE);
  wire [31:0] kat2_word  = KAT2_MSG[447 - 32 * kidx -: 32];
  always_comb begin
    if (kat_active) begin
      e_start  = (ks == K_START1) || (ks == K_START2);
      e_valid  = (ks == K_FEED1) || (ks == K_FEED2);
      e_data   = (ks == K_FEED1) ? 32'h6162_6300 : kat2_word;
      e_nbytes = (ks == K_FEED1) ? 3'd3 : 3'd4;
      e_finish = (ks == K_WAIT1) || (ks == K_WAIT2);
    end else begin
      e_start  = start && kat_ok;
      e_valid  = in_valid && kat_ok;
      e_data   = in_data;
      e_nbytes = in_nbytes;
      e_finish = finish && kat_ok;
    end
  end
  assign in_ready = !kat_active && kat_ok && e_ready;
  assign busy     = kat_active || e_busy;
  assign done     = !kat_active && e_done;
  assign digest   = e_digest;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ks <= K_START1; kidx <= '0; kat_pass1_q <= 1'b0; kat_done <= 1'b0; kat_ok <= 1'b0;
    end else begin
      case (ks)
        K_START1: ks <= K_FEED1;
        K_FEED1:  if (e_ready) ks <= K_WAIT1;                       // "abc" absorbed
        K_WAIT1:  if (e_done) begin kat_pass1_q <= (e_digest == KAT1_MD); ks <= K_START2; end
        K_START2: begin kidx <= '0; ks <= K_FEED2; end
        K_FEED2:  if (e_ready) begin
          if (kidx == 4'd13) ks <= K_WAIT2;                          // 14 words = 56 bytes
          kidx <= kidx + 4'd1;
        end
        K_WAIT2:  if (e_done) begin
          kat_ok   <= kat_pass1_q && (e_digest == KAT2_MD);
          kat_done <= 1'b1;
          ks       <= K_DONE;
        end
        default:  ks <= K_DONE;
      endcase
    end
  end
endmodule

`default_nettype wire
