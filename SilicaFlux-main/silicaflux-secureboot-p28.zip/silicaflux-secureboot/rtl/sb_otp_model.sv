// =============================================================================
// SilicaFlux secure boot :: sb_otp_model -- one-time-programmable fuse MODEL
//
// *** THIS IS NOT OTP / eFUSE HARDWARE. ***  No fuse or antifuse macro exists in
// the SilicaFlux repository (sramlib, PDK leaf cells: SRAM only).  This block
// models the *behaviour* the secure-boot policy needs from fuses so that the
// policy can be implemented and tested:
//   * four 32-bit words: LC (lifecycle code), REVOKE (key revocation),
//     SVN (anti-rollback thermometer), CFG (policy options);
//   * "sensing": the words are loaded once, in the first clock after
//     power-on reset, from the fuse_*_i inputs (tie-offs on FPGA, plusargs in
//     the testbench) -- a model of reading a fuse array at power-up;
//   * one-way programming: prog_bits are OR-ed in (0 -> 1 only), as a fuse;
//   * state is held in the POR domain: it survives soft / watchdog / host
//     resets but NOT a power cycle.  Real persistence, and therefore real
//     rollback resistance and real revocation, need a physical OTP/eFuse macro
//     (or an authenticated monotonic counter) -- docs/07_ANTI_ROLLBACK.md.
// Also in the POR domain: the consecutive authentication-failure counter used
// for automatic RECOVERY entry.
// Classification: SYNTHESIZABLE (as a register model; not a security boundary)
// =============================================================================
`default_nettype none

module sb_otp_model (
  input  wire logic        clk,
  input  wire logic        por_rst_n,
  // power-up sensing
  input  wire logic [31:0] fuse_lc_i,
  input  wire logic [31:0] fuse_revoke_i,
  input  wire logic [31:0] fuse_svn_i,
  input  wire logic [31:0] fuse_cfg_i,
  output logic             loaded,
  // current array contents
  output logic [31:0]      lc,
  output logic [31:0]      revoke,
  output logic [31:0]      svn,
  output logic [31:0]      cfg,
  // one-way programming (sys domain request, single-cycle pulse)
  input  wire logic        prog_en,
  input  wire logic [1:0]  prog_sel,      // 0 LC 1 REVOKE 2 SVN 3 CFG
  input  wire logic [31:0] prog_bits,
  // POR-domain authentication-failure counter (saturating at 15)
  input  wire logic        fail_inc,
  input  wire logic        fail_clr,
  output logic [3:0]       fails
);
  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      loaded <= 1'b0;
      lc <= '0; revoke <= '0; svn <= '0; cfg <= '0;
      fails <= '0;
    end else begin
      if (!loaded) begin
        lc <= fuse_lc_i; revoke <= fuse_revoke_i; svn <= fuse_svn_i; cfg <= fuse_cfg_i;
        loaded <= 1'b1;
      end else if (prog_en) begin
        case (prog_sel)
          2'd0:    lc     <= lc     | prog_bits;
          2'd1:    revoke <= revoke | prog_bits;
          2'd2:    svn    <= svn    | prog_bits;
          default: cfg    <= cfg    | prog_bits;
        endcase
      end
      if (fail_clr)                         fails <= '0;
      else if (fail_inc && fails != 4'hF)   fails <= fails + 4'd1;
    end
  end
endmodule

`default_nettype wire
