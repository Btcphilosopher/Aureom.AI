// =============================================================================
// SilicaFlux-HPC :: silicaflux_secure_boot -- SecureSilicon root-of-trust block
// (Project 28, primary RTL)
//
// Hardware half of the ControlCore secure boot.  The software half is the
// immutable boot ROM (firmware/bootrom), which parses the manifest and runs
// the Ed25519 verification (Monocypher 4.0.2).  This block makes the policy
// *enforceable*: nothing the ROM, the host, the DMA or the debug port does can
// open instruction fetch from IMEM unless this state machine reached PASS.
//
//   SELFTEST --KAT ok, lifecycle valid--> LOAD --SEAL--> SEALING --IMEM writers idle--> SEALED
//   SEALED --HASH(base,len)--> HASHING --digest--> HASHED --HANDOFF + hardware checks--> PASS
//   SEALED / HASHED / LOAD --FAIL--> FAIL --RELOAD--> LOAD          any illegal code -> LOCKDOWN
//
//  * LOAD: IMEM writable (host, DMA, CPU -- per-master rules in sb_access_policy /
//    sb_dma_guard); IMEM not executable.
//  * SEALED..HASHED, FAIL: IMEM write-protected for every master (checked at
//    the IMEM slave port), still not executable.
//  * HASHING: the block's own bus master (SBHASH, access matrix: IMEM only)
//    reads [HASH_BASE, HASH_BASE+HASH_LEN) and streams it into the verified
//    SHA-256 wrapper (secworks core + padding + power-on KAT).  The ROM cannot
//    influence the bytes that are measured.
//  * HANDOFF is accepted only if, in hardware:
//      EXPECT (digest from the ROM-verified manifest) == DIGEST (measured);
//      the ROM wrote the two signature tokens (A then ~A) after this measurement;
//      ENTRY lies in the measured range, word aligned;
//      the reported key slot is allowed in the lifecycle and not revoked;
//      the reported security version is >= MIN_SVN when rollback is enforced.
//    These duplicate the ROM's checks against an independent source (fuse
//    model, measured digest): a ROM bug or a single glitched branch in the ROM
//    is not enough to open execution.  Signature correctness itself remains
//    the ROM's responsibility (docs/12_SECURITY_REVIEW.md).
//  * PASS: execute window = exactly the measured range; IMEM inside it is
//    read-only (W^X); boot-ROM fetch closes after the first fetch from the
//    window; ROM-phase registers lock; firmware-phase fuse-model operations
//    (SVN commit, key revocation, lifecycle advance) open, each with
//    hardware rules.  PASS is left only by a reset.
//  * Lifecycle (from the fuse MODEL, latched at reset): DEV / PROV / PROD,
//    RECOVERY (= PROV/PROD with the recovery strap or >= 3 consecutive
//    failures), INVALID -> LOCKDOWN.  Debug and test mode only in DEV.
//  * Fault-injection countermeasures (basic, not evaluated): sparse state
//    encoding (pairwise Hamming distance >= 4, illegal -> LOCKDOWN), execute
//    window needs both the state code and a separate pass flag, two-word
//    signature token, redundant revocation bits.
// Register page CC_PG_SECURITY; offsets/encodings: config/cc_memmap.yaml.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_secure_boot (
  input  wire logic        clk,
  input  wire logic        rst_n,               // system domain
  // register page
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // fuse MODEL (POR domain, sb_otp_model)
  input  wire logic [31:0] otp_lc,
  input  wire logic [31:0] otp_revoke,
  input  wire logic [31:0] otp_svn,
  input  wire logic [31:0] otp_cfg,
  input  wire logic [3:0]  boot_fails,
  output logic             otp_prog_en,
  output logic [1:0]       otp_prog_sel,
  output logic [31:0]      otp_prog_bits,
  output logic             fail_inc,
  output logic             fail_clr,
  input  wire logic        recovery_strap,       // synchronised pin
  // hash reader: SFB2 master, read-only (crossbar master SBHASH, IMEM only)
  output logic             h_req_valid,
  input  wire logic        h_req_ready,
  output logic [31:0]      h_req_addr,
  input  wire logic        h_rsp_valid,
  output logic             h_rsp_ready,
  input  wire logic [31:0] h_rsp_rdata,
  input  wire logic        h_rsp_error,
  // seal quiescence
  input  wire logic        imem_idle,            // nothing outstanding at the IMEM slave port
  input  wire logic        dma_busy,
  // accepted CPU instruction fetches (for the ROM-fetch closure)
  input  wire logic        fetch_acc,
  input  wire logic [31:0] fetch_addr,
  // refused accesses: [0] HOST [1] DMA [2] FETCH [3] IMEM_WRITE [4] DEBUG
  input  wire logic [4:0]  viol_evt,
  input  wire logic [159:0] viol_addr,
  input  wire logic        dbg_used,             // the debug port issued a transaction
  // policy outputs
  output logic             load_open,
  output logic             exec_open,
  output logic             rom_fetch_open,
  output logic [31:0]      exec_base,
  output logic [31:0]      exec_end,
  output logic             debug_en,
  output logic             test_mode_en,
  output logic             lockdown
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */

  // ------------------------------------------------------------------ sparse state encoding
  localparam logic [7:0] ST_SELFTEST = 8'h17, ST_LOAD = 8'h2B, ST_SEALING = 8'h4D, ST_SEALED = 8'h8E,
                         ST_HASHING = 8'h71, ST_HASHED = 8'hB2, ST_PASS = 8'hD4, ST_FAIL = 8'hE8,
                         ST_LOCKDOWN = 8'h00;
  logic [7:0] st_q;
  logic [3:0] st_enum;
  always_comb begin
    case (st_q)
      ST_SELFTEST: st_enum = 4'(CC_SB_STATE_SELFTEST);
      ST_LOAD:     st_enum = 4'(CC_SB_STATE_LOAD);
      ST_SEALING:  st_enum = 4'(CC_SB_STATE_SEALING);
      ST_SEALED:   st_enum = 4'(CC_SB_STATE_SEALED);
      ST_HASHING:  st_enum = 4'(CC_SB_STATE_HASHING);
      ST_HASHED:   st_enum = 4'(CC_SB_STATE_HASHED);
      ST_PASS:     st_enum = 4'(CC_SB_STATE_PASS);
      ST_FAIL:     st_enum = 4'(CC_SB_STATE_FAIL);
      default:     st_enum = 4'(CC_SB_STATE_LOCKDOWN);
    endcase
  end
  wire legal_state = (st_q == ST_SELFTEST) || (st_q == ST_LOAD) || (st_q == ST_SEALING) || (st_q == ST_SEALED) ||
                     (st_q == ST_HASHING) || (st_q == ST_HASHED) || (st_q == ST_PASS) || (st_q == ST_FAIL);
  wire rom_phase = legal_state && (st_q != ST_PASS);   // LOCKDOWN (0x00) is not legal_state
  wire fw_phase  = (st_q == ST_PASS);

  // ------------------------------------------------------------------ lifecycle (latched once after reset)
  // (assignment to the function name, not `return`: Yosys 0.33 compatibility)
  function automatic logic [3:0] lc_decode(input logic [31:0] w);
    if (w == CC_SB_LC_CODE_DEV)       lc_decode = 4'(CC_SB_LC_DEV);
    else if (w == CC_SB_LC_CODE_PROV) lc_decode = 4'(CC_SB_LC_PROV);
    else if (w == CC_SB_LC_CODE_PROD) lc_decode = 4'(CC_SB_LC_PROD);
    else                              lc_decode = 4'(CC_SB_LC_INVALID);
  endfunction
  logic       init_q;
  logic [3:0] lc_fused_q, lc_eff_q;
  logic       strap_q;
  wire  [3:0] lc_fused_now = lc_decode(otp_lc);
  wire        rec_now = (lc_fused_now == 4'(CC_SB_LC_PROV) || lc_fused_now == 4'(CC_SB_LC_PROD)) &&
                        (recovery_strap || boot_fails >= 4'(CC_SB_RECOVERY_FAILS));
  wire        lc_invalid  = (lc_fused_q == 4'(CC_SB_LC_INVALID));
  assign debug_en     = init_q && (lc_eff_q == 4'(CC_SB_LC_DEV));
  assign test_mode_en = debug_en;
  wire   rollback_enf = (lc_eff_q != 4'(CC_SB_LC_DEV)) || otp_cfg[0];
  wire   ext_boot_dis = otp_cfg[1] || (lc_eff_q == 4'(CC_SB_LC_RECOVERY));
  wire [3:0] revoked  = otp_revoke[3:0] | otp_revoke[19:16];   // either copy revokes (fails toward revoked)
  logic [5:0] min_svn;
  always_comb begin
    min_svn = 6'd0;
    for (int i = 0; i < 32; i++) if (otp_svn[i]) min_svn = 6'(i + 1);
  end

  // ------------------------------------------------------------------ SHA-256 (verified wrapper)
  logic        e_start, e_valid, e_ready, e_finish, e_busy, e_done, kat_done, kat_ok;
  logic [31:0] e_data;
  logic [255:0] e_digest;
  wire unused_busy = e_busy;
  sb_sha256_wrapper u_sha (
    .clk, .rst_n, .start(e_start), .in_valid(e_valid), .in_ready(e_ready), .in_data(e_data), .in_nbytes(3'd4),
    .finish(e_finish), .busy(e_busy), .done(e_done), .digest(e_digest), .kat_done, .kat_ok
  );

  // ------------------------------------------------------------------ registers
  logic [31:0] hash_base_q, hash_len_q, entry_q, fail_code_q;
  logic [1:0]  key_slot_q, act_slot_q;
  logic [5:0]  img_svn_q, act_svn_q;
  logic [255:0] digest_q, expect_q;
  logic        digest_valid_q, pass_q, act_valid_q, rom_fetch_q, dbg_used_q;
  logic [1:0]  tok_q;                              // 0 none, 1 A seen, 2 A then B
  logic [7:0]  href_q;
  logic [31:0] exec_base_q, exec_end_q;
  logic [5:0]  viol_q;
  logic [31:0] viol_addr_q, viol_cnt_q;
  logic [7:0]  otp_status_q;

  wire wr = rb_sel && rb_we;
  localparam logic [3:0] DEVMASK = 4'(CC_SB_DEV_KEY_MASK);
  wire [3:0] wmask = rb_wdata[3:0];
  wire [32:0] hash_end = {1'b0, hash_base_q} + {1'b0, hash_len_q};
  wire hash_params_ok = hash_len_q != 32'd0 && hash_len_q[1:0] == 2'b00 && hash_base_q[1:0] == 2'b00 &&
                        hash_base_q >= CC_IMEM_BASE && hash_end <= {1'b0, CC_IMEM_BASE} + {1'b0, CC_IMEM_SIZE};
  wire digest_match = digest_valid_q && (digest_q == expect_q);

  // hand-off checks (combinational, evaluated on the HANDOFF command)
  logic [7:0] href_now;
  always_comb begin
    href_now = 8'(CC_SB_HREF_NONE);
    if (st_q != ST_HASHED)                                                   href_now = 8'(CC_SB_HREF_STATE);
    else if (!digest_match)                                                  href_now = 8'(CC_SB_HREF_DIGEST);
    else if (tok_q != 2'd2)                                                  href_now = 8'(CC_SB_HREF_TOKENS);
    else if (entry_q < hash_base_q || {1'b0, entry_q} >= hash_end || entry_q[1:0] != 2'b00)
                                                                             href_now = 8'(CC_SB_HREF_ENTRY);
    else if (DEVMASK[key_slot_q] && lc_eff_q != 4'(CC_SB_LC_DEV)) href_now = 8'(CC_SB_HREF_KEY_LC);
    else if (revoked[key_slot_q])                                            href_now = 8'(CC_SB_HREF_KEY_REVOKED);
    else if (rollback_enf && (img_svn_q < min_svn || img_svn_q > 6'(CC_SB_SVN_MAX)))
                                                                             href_now = 8'(CC_SB_HREF_ROLLBACK);
  end

  // command decode
  wire        cmd_wr  = wr && rb_addr == CC_SEC_CMD;
  wire        cmd_tag = rb_wdata[31:8] == 24'(CC_SB_CMD_KEY >> 8);
  wire [7:0]  cmd     = rb_wdata[7:0];
  wire c_seal    = cmd_wr && cmd_tag && cmd == 8'(CC_SB_CMD_SEAL)    && st_q == ST_LOAD;
  wire c_hash    = cmd_wr && cmd_tag && cmd == 8'(CC_SB_CMD_HASH)    && st_q == ST_SEALED;
  wire c_handoff = cmd_wr && cmd_tag && cmd == 8'(CC_SB_CMD_HANDOFF) && st_q == ST_HASHED;
  wire c_fail    = cmd_wr && cmd_tag && cmd == 8'(CC_SB_CMD_FAIL)    &&
                   (st_q == ST_LOAD || st_q == ST_SEALED || st_q == ST_HASHED || st_q == ST_FAIL);
  wire c_reload  = cmd_wr && cmd_tag && cmd == 8'(CC_SB_CMD_RELOAD)  && st_q == ST_FAIL;
  wire cmd_ok    = c_seal || c_hash || c_handoff || c_fail || c_reload;

  // write permission per register (refused writes answer rb_err and are logged)
  logic wr_ok;
  always_comb begin
    wr_ok = 1'b0;
    case (rb_addr)
      CC_SEC_CMD:                         wr_ok = cmd_ok;
      CC_SEC_FAIL_CODE, CC_SEC_ENTRY, CC_SEC_KEY_SLOT, CC_SEC_IMAGE_SVN:
                                          wr_ok = rom_phase;
      CC_SEC_HASH_BASE, CC_SEC_HASH_LEN:  wr_ok = (st_q == ST_LOAD || st_q == ST_SEALING || st_q == ST_SEALED);
      CC_SEC_SIG_TOKEN:                   wr_ok = (st_q == ST_HASHED);
      CC_SEC_SVN_COMMIT, CC_SEC_REVOKE_SET, CC_SEC_LC_ADVANCE, CC_SEC_VIOL_STATUS:
                                          wr_ok = fw_phase;
      default:
        if (rb_addr >= CC_SEC_EXPECT0 && rb_addr <= CC_SEC_EXPECT0 + 12'h01C) wr_ok = (st_q == ST_HASHED);
    endcase
  end
  wire wr_acc = wr && wr_ok;
  wire wr_ref = wr && !wr_ok;

  // ------------------------------------------------------------------ fuse-model operations (firmware phase)
  logic       op_en;
  logic [1:0] op_sel;
  logic [31:0] op_bits;
  logic [3:0] op_err;
  always_comb begin
    op_en = 1'b0; op_sel = 2'd0; op_bits = '0; op_err = 4'(CC_SB_OTPERR_NONE);
    if (wr_acc && rb_addr == CC_SEC_SVN_COMMIT) begin
      if (rb_wdata == 32'd0 || rb_wdata > 32'(CC_SB_SVN_MAX) || rb_wdata > 32'(act_svn_q)) op_err = 4'(CC_SB_OTPERR_RANGE);
      else begin
        op_en = 1'b1; op_sel = 2'd2;
        op_bits = (rb_wdata == 32'd32) ? 32'hFFFF_FFFF : ((32'd1 << rb_wdata[4:0]) - 32'd1);
      end
    end else if (wr_acc && rb_addr == CC_SEC_REVOKE_SET) begin
      if (rb_wdata[3:0] == 4'd0 || rb_wdata[31:4] != 28'd0)                 op_err = 4'(CC_SB_OTPERR_RANGE);
      else if (wmask[act_slot_q])                                       op_err = 4'(CC_SB_OTPERR_ACTIVE_SLOT);
      else if ((((revoked | rb_wdata[3:0]) | 4'(CC_SB_DEV_KEY_MASK)) == 4'hF)) op_err = 4'(CC_SB_OTPERR_LAST_SLOT);
      else begin op_en = 1'b1; op_sel = 2'd1; op_bits = {12'd0, rb_wdata[3:0], 12'd0, rb_wdata[3:0]}; end
    end else if (wr_acc && rb_addr == CC_SEC_LC_ADVANCE) begin
      if ((lc_fused_now == 4'(CC_SB_LC_DEV)  && rb_wdata == CC_SB_LC_CODE_PROV) ||
          (lc_fused_now == 4'(CC_SB_LC_PROV) && rb_wdata == CC_SB_LC_CODE_PROD)) begin
        op_en = 1'b1; op_sel = 2'd0; op_bits = rb_wdata;
      end else op_err = 4'(CC_SB_OTPERR_TRANSITION);
    end
  end
  wire op_wr = wr_acc && (rb_addr == CC_SEC_SVN_COMMIT || rb_addr == CC_SEC_REVOKE_SET || rb_addr == CC_SEC_LC_ADVANCE);
  assign otp_prog_en   = op_en;
  assign otp_prog_sel  = op_sel;
  assign otp_prog_bits = op_bits;

  // ------------------------------------------------------------------ hash reader (SBHASH master)
  typedef enum logic [2:0] {R_IDLE, R_REQ, R_RSP, R_PUSH, R_FIN, R_WAIT} rst_e;
  rst_e        rs;
  logic [31:0] r_addr, r_left, r_word;
  logic        r_err;
  assign h_req_valid = (rs == R_REQ);
  assign h_req_addr  = r_addr;
  assign h_rsp_ready = (rs == R_RSP);
  assign e_start     = c_hash;
  assign e_valid     = (rs == R_PUSH);
  assign e_data      = {r_word[7:0], r_word[15:8], r_word[23:16], r_word[31:24]};   // memory bytes in order
  assign e_finish    = (rs == R_FIN);

  // ------------------------------------------------------------------ state machine + registers
  wire enter_fail = (c_fail || (c_handoff && href_now != 8'(CC_SB_HREF_NONE)) || (c_hash && !hash_params_ok) ||
                     (st_q == ST_HASHING && rs == R_WAIT && e_done && r_err)) && st_q != ST_FAIL;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= ST_SELFTEST; init_q <= 1'b0; lc_fused_q <= 4'(CC_SB_LC_INVALID); lc_eff_q <= 4'(CC_SB_LC_INVALID);
      strap_q <= 1'b0;
      hash_base_q <= '0; hash_len_q <= '0; entry_q <= '0; fail_code_q <= '0; key_slot_q <= '0; img_svn_q <= '0;
      digest_q <= '0; expect_q <= '0; digest_valid_q <= 1'b0; tok_q <= '0; href_q <= '0;
      pass_q <= 1'b0; act_valid_q <= 1'b0; act_slot_q <= '0; act_svn_q <= '0; exec_base_q <= '0; exec_end_q <= '0;
      rom_fetch_q <= 1'b1; dbg_used_q <= 1'b0; viol_q <= '0; viol_addr_q <= '0; viol_cnt_q <= '0; otp_status_q <= '0;
      rs <= R_IDLE; r_addr <= '0; r_left <= '0; r_word <= '0; r_err <= 1'b0;
    end else begin
      // ---- lifecycle latch: first cycle after the system reset (fuse model already sensed)
      if (!init_q) begin
        init_q     <= 1'b1;
        lc_fused_q <= lc_fused_now;
        lc_eff_q   <= rec_now ? 4'(CC_SB_LC_RECOVERY) : lc_fused_now;
        strap_q    <= recovery_strap;
      end
      if (dbg_used) dbg_used_q <= 1'b1;
      // ---- ROM-phase registers
      if (wr_acc) begin
        case (rb_addr)
          CC_SEC_HASH_BASE: hash_base_q <= rb_wdata;
          CC_SEC_HASH_LEN:  hash_len_q  <= rb_wdata;
          CC_SEC_ENTRY:     entry_q     <= rb_wdata;
          CC_SEC_KEY_SLOT:  key_slot_q  <= rb_wdata[1:0];
          CC_SEC_IMAGE_SVN: img_svn_q   <= (rb_wdata > 32'd63) ? 6'd63 : rb_wdata[5:0];
          CC_SEC_FAIL_CODE: fail_code_q <= rb_wdata;
          CC_SEC_SIG_TOKEN: tok_q <= (tok_q == 2'd0 && rb_wdata == CC_SB_TOKEN_A) ? 2'd1 :
                                     (tok_q == 2'd1 && rb_wdata == CC_SB_TOKEN_B) ? 2'd2 : 2'd0;
          default:
            if (rb_addr >= CC_SEC_EXPECT0 && rb_addr <= CC_SEC_EXPECT0 + 12'h01C)
              expect_q[255 - 32 * rb_addr[4:2] -: 32] <= rb_wdata;
        endcase
      end
      if (op_wr) otp_status_q <= {op_err, 2'b00, op_err != 4'd0, 1'b1};
      // ---- violations (refused accesses anywhere + refused privileged register writes)
      begin
        logic [5:0] ev;
        ev = {wr_ref, viol_evt};
        viol_q <= (wr_acc && rb_addr == CC_SEC_VIOL_STATUS ? viol_q & ~rb_wdata[5:0] : viol_q) | ev;
        for (int i = 0; i < 5; i++) if (viol_evt[i]) viol_addr_q <= viol_addr[32 * i +: 32];
        if (wr_ref) viol_addr_q <= CC_SECURITY_BASE + 32'(rb_addr);
        if (ev != 6'd0 && viol_cnt_q != 32'hFFFF_FFFF) viol_cnt_q <= viol_cnt_q + 32'd1;
      end
      // ---- ROM fetch closes after the first fetch from the authenticated window
      if (exec_open && fetch_acc && fetch_addr >= exec_base_q && fetch_addr < exec_end_q) rom_fetch_q <= 1'b0;

      // ---- hash reader
      case (rs)
        R_IDLE: if (c_hash && hash_params_ok) begin
          r_addr <= hash_base_q; r_left <= hash_len_q; r_err <= 1'b0; rs <= R_REQ;
        end
        R_REQ:  if (h_req_ready) rs <= R_RSP;
        R_RSP:  if (h_rsp_valid) begin
          r_word <= h_rsp_rdata;
          if (h_rsp_error) begin r_err <= 1'b1; rs <= R_FIN; end
          else rs <= R_PUSH;
        end
        R_PUSH: if (e_ready) begin
          r_addr <= r_addr + 32'd4;
          r_left <= r_left - 32'd4;
          rs <= (r_left == 32'd4) ? R_FIN : R_REQ;
        end
        R_FIN:  rs <= R_WAIT;
        R_WAIT: if (e_done) rs <= R_IDLE;
        default: rs <= R_IDLE;
      endcase

      // ---- main state machine
      if (!legal_state) begin
        st_q <= ST_LOCKDOWN;
      end else begin
        case (st_q)
          ST_SELFTEST: if (init_q && kat_done)
                         st_q <= (kat_ok && lc_fused_q != 4'(CC_SB_LC_INVALID)) ? ST_LOAD : ST_LOCKDOWN;
          ST_LOAD:     if (c_seal) st_q <= ST_SEALING;
          ST_SEALING:  if (imem_idle && !dma_busy) st_q <= ST_SEALED;
          ST_SEALED:   if (c_hash) begin
                         if (hash_params_ok) begin st_q <= ST_HASHING; digest_valid_q <= 1'b0; end
                         else begin st_q <= ST_FAIL; href_q <= 8'(CC_SB_HREF_RANGE); end
                       end
          ST_HASHING:  if (rs == R_WAIT && e_done) begin
                         if (r_err) begin st_q <= ST_FAIL; href_q <= 8'(CC_SB_HREF_HASH_ERR); end
                         else begin st_q <= ST_HASHED; digest_q <= e_digest; digest_valid_q <= 1'b1; tok_q <= '0; end
                       end
          ST_HASHED:   if (c_handoff) begin
                         href_q <= href_now;
                         if (href_now == 8'(CC_SB_HREF_NONE)) begin
                           st_q <= ST_PASS; pass_q <= 1'b1;
                           exec_base_q <= hash_base_q; exec_end_q <= hash_end[31:0];
                           act_valid_q <= 1'b1; act_slot_q <= key_slot_q; act_svn_q <= img_svn_q;
                         end else st_q <= ST_FAIL;
                       end
          ST_FAIL:     if (c_reload) begin
                         st_q <= ST_LOAD; digest_valid_q <= 1'b0; digest_q <= '0; expect_q <= '0; tok_q <= '0;
                         hash_base_q <= '0; hash_len_q <= '0;
                       end
          default: ;
        endcase
        if (c_fail) st_q <= ST_FAIL;
      end
    end
  end
  assign fail_inc = enter_fail;
  assign fail_clr = c_handoff && href_now == 8'(CC_SB_HREF_NONE);

  assign load_open      = (st_q == ST_LOAD);
  assign exec_open      = (st_q == ST_PASS) && pass_q;
  assign rom_fetch_open = rom_fetch_q;
  assign exec_base      = exec_base_q;
  assign exec_end       = exec_end_q;
  assign lockdown       = !legal_state;

  // ------------------------------------------------------------------ read mux
  localparam logic [31:0] CAPS = 32'h0000_04FF | (32'(CC_SB_NKEYS) << 12);   // [8] OTP=0 [9] persistent rollback=0
  always_comb begin
    rb_rdata = 32'd0;
    case (rb_addr)
      CC_SEC_CAPS:           rb_rdata = CAPS;
      CC_SEC_STATUS:         rb_rdata = {href_q, 7'd0, dbg_used_q, debug_en, rom_fetch_q, exec_open, tok_q == 2'd2,
                                         digest_match, digest_valid_q, kat_done, kat_ok, lc_eff_q, st_enum};
      CC_SEC_FAIL_CODE:      rb_rdata = fail_code_q;
      CC_SEC_HASH_BASE:      rb_rdata = hash_base_q;
      CC_SEC_HASH_LEN:       rb_rdata = hash_len_q;
      CC_SEC_ENTRY:          rb_rdata = entry_q;
      CC_SEC_KEY_SLOT:       rb_rdata = {30'd0, key_slot_q};
      CC_SEC_IMAGE_SVN:      rb_rdata = {26'd0, img_svn_q};
      CC_SEC_LIFECYCLE:      rb_rdata = {17'd0, lc_invalid, strap_q, ext_boot_dis, rollback_enf, test_mode_en,
                                         debug_en, lc_eff_q == 4'(CC_SB_LC_RECOVERY), lc_fused_q, lc_eff_q};
      CC_SEC_TARGET_ID:      rb_rdata = CC_SB_TARGET_ID;
      CC_SEC_HW_VERSION:     rb_rdata = CC_SB_HW_VERSION;
      CC_SEC_POLICY_VERSION: rb_rdata = CC_SB_POLICY_VERSION;
      CC_SEC_BOOT_FAILS:     rb_rdata = {28'd0, boot_fails};
      CC_SEC_EXEC_BASE:      rb_rdata = exec_base_q;
      CC_SEC_EXEC_END:       rb_rdata = exec_end_q;
      CC_SEC_ACTIVE:         rb_rdata = {act_valid_q, 17'd0, act_svn_q, 6'd0, act_slot_q};
      CC_SEC_OTP_LC:         rb_rdata = otp_lc;
      CC_SEC_OTP_REVOKE:     rb_rdata = otp_revoke;
      CC_SEC_OTP_SVN:        rb_rdata = otp_svn;
      CC_SEC_OTP_CFG:        rb_rdata = otp_cfg;
      CC_SEC_MIN_SVN:        rb_rdata = {26'd0, min_svn};
      CC_SEC_REVOKED:        rb_rdata = {28'd0, revoked};
      CC_SEC_OTP_STATUS:     rb_rdata = {24'd0, otp_status_q};
      CC_SEC_VIOL_STATUS:    rb_rdata = {26'd0, viol_q};
      CC_SEC_VIOL_ADDR:      rb_rdata = viol_addr_q;
      CC_SEC_VIOL_COUNT:     rb_rdata = viol_cnt_q;
      default:
        if (rb_addr >= CC_SEC_DIGEST0 && rb_addr <= CC_SEC_DIGEST0 + 12'h01C)
          rb_rdata = digest_q[255 - 32 * rb_addr[4:2] -: 32];
    endcase
  end
  // reads of unmapped offsets and refused writes answer a bus error
  logic mapped;
  always_comb begin
    case (rb_addr)
      CC_SEC_CAPS, CC_SEC_STATUS, CC_SEC_CMD, CC_SEC_FAIL_CODE, CC_SEC_HASH_BASE, CC_SEC_HASH_LEN, CC_SEC_ENTRY,
      CC_SEC_KEY_SLOT, CC_SEC_IMAGE_SVN, CC_SEC_SIG_TOKEN, CC_SEC_LIFECYCLE, CC_SEC_TARGET_ID, CC_SEC_HW_VERSION,
      CC_SEC_POLICY_VERSION, CC_SEC_BOOT_FAILS, CC_SEC_EXEC_BASE, CC_SEC_EXEC_END, CC_SEC_ACTIVE, CC_SEC_OTP_LC,
      CC_SEC_OTP_REVOKE, CC_SEC_OTP_SVN, CC_SEC_OTP_CFG, CC_SEC_MIN_SVN, CC_SEC_REVOKED, CC_SEC_SVN_COMMIT,
      CC_SEC_REVOKE_SET, CC_SEC_LC_ADVANCE, CC_SEC_OTP_STATUS, CC_SEC_VIOL_STATUS, CC_SEC_VIOL_ADDR,
      CC_SEC_VIOL_COUNT: mapped = 1'b1;
      default: mapped = (rb_addr >= CC_SEC_DIGEST0 && rb_addr <= CC_SEC_EXPECT0 + 12'h01C);
    endcase
  end
  assign rb_err = rb_sel && (rb_we ? !wr_ok : !mapped);
endmodule

`default_nettype wire
