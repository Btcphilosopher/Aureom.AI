#!/usr/bin/env bash
# =============================================================================
# Project 28 -- build the delivery archive
#   scripts/package.sh <out.zip>
# Contents: sources, docs, keys (test/dev, not secret), vectors, reports (incl. simulation logs) and the
# release artefacts of the final run (secure ROM image, signed firmware images).  Excluded: build trees,
# the riscv-tests clone (deps/, fetched by `make isa`), Python/cocotb caches.
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(realpath -m "${1:?usage: package.sh <out.zip>}")"
NAME="$(basename "$ROOT")"
cd "$(dirname "$ROOT")"
rm -f "$OUT"
zip -q -r -X "$OUT" "$NAME" \
  -x "$NAME/build/*" "$NAME/deps/*" "$NAME/ref/build/*" "$NAME/firmware/build/*" \
     "$NAME/tb/unit/sim_build/*" "$NAME/tb/unit/results.xml" "*/__pycache__/*" "*.pyc"
# release artefacts of the final run
zip -q -X "$OUT" \
  "$NAME"/firmware/build/rom/bootrom.elf "$NAME"/firmware/build/rom/bootrom.bin \
  "$NAME"/firmware/build/fw/controlcore_fw.elf \
  "$NAME"/firmware/build/fw/controlcore_fw*.img "$NAME"/firmware/build/fw/controlcore_fw*.json \
  "$NAME"/firmware/build/fw/controlcore_fw*.hex
echo "package: $OUT ($(du -h "$OUT" | cut -f1), $(unzip -l "$OUT" | tail -1 | awk '{print $2}') files)"
