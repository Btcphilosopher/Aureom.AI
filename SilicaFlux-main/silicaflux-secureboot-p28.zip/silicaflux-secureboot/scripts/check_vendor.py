#!/usr/bin/env python3
"""Verify that every file under third_party/ is byte-identical to its origin.

    check_vendor.py                      check against third_party/SHA256SUMS
    check_vendor.py --repo <Aureom.AI>   additionally compare every file with the
                                         member of the original archive in the
                                         repository (SilicaFlux-main/...zip)
    check_vendor.py --write              regenerate third_party/SHA256SUMS
"""
import argparse
import hashlib
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TP = os.path.join(ROOT, "third_party")
A25 = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/"
ARCH = {
    "mcu": (A25 + "silicaflux-mcu-i.zip", "silicaflux-mcu-i/"),
    "tc08": ("SilicaFlux-main/silicaflux-tensorcore08.zip", "silicaflux-tensorcore08/"),
    "m08": (A25 + "silicaflux-hpc-m08-tile.zip", "silicaflux-hpc-m08-tile/"),
    "p21": (A25 + "silicaflux-controlcore.zip", "silicaflux-controlcore/"),     # Project 21 ControlCore
}
# vendored from upstream git (not from a repository archive): checked against SHA256SUMS only;
# upstream commits and per-file hashes are recorded in PROVENANCE.md
EXTERNAL = ("secworks-sha256", "monocypher-4.0.2")
P21_MAP = {"cc_memmap.yaml": "config/cc_memmap.yaml", "mkimage.py": "scripts/mkimage.py", "README_P21.md": "README.md"}


def candidates(rel):
    top, rest = rel.split("/", 1)
    if top in EXTERNAL:
        return []
    if top == "silicaflux-controlcore-p21":
        return [("p21", P21_MAP.get(rest, rest))]
    if top == "silicaflux-mcu-i":
        return [("mcu", rest)]
    if top in ("silicaflux-v", "silicaflux-datafabric", "silicaflux-sramlib"):
        return [("mcu", f"third_party/{top}/{rest}"), ("tc08", f"third_party/{top}/{rest}")]
    if top == "silicaflux-tensorcore08":
        return [("tc08", rest)]
    if top == "silicaflux-hpc-m08-tile" and (rest.startswith("sw/") or rest == "docs/06_host_software.md"):
        return [("m08", rest)]
    return [("tc08", f"third_party/{top}/{rest}")]


def files():
    out = []
    for d, _, fs in os.walk(TP):
        for f in fs:
            p = os.path.join(d, f)
            rel = os.path.relpath(p, TP)
            if rel in ("SHA256SUMS", "PROVENANCE.md"):
                continue
            out.append(rel)
    return sorted(out)


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo")
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()
    fl = files()
    sums = os.path.join(TP, "SHA256SUMS")
    if a.write:
        with open(sums, "w") as f:
            for rel in fl:
                f.write(f"{sha(os.path.join(TP, rel))}  {rel}\n")
        print(f"check_vendor: wrote {len(fl)} entries")
        return
    bad = 0
    ref = dict(reversed(l.strip().split("  ", 1)) for l in open(sums) if l.strip())
    for rel in fl:
        if ref.get(rel) != sha(os.path.join(TP, rel)):
            print("MISMATCH (SHA256SUMS)", rel)
            bad += 1
    missing = set(ref) - set(fl)
    for m in sorted(missing):
        print("MISSING", m)
        bad += 1
    if a.repo:
        zips = {k: zipfile.ZipFile(os.path.join(a.repo, v[0])) for k, v in ARCH.items()}
        for rel in fl:
            if rel.split("/", 1)[0] in EXTERNAL:
                continue
            data = open(os.path.join(TP, rel), "rb").read()
            ok = False
            for k, inner in candidates(rel):
                name = ARCH[k][1] + inner
                try:
                    if zips[k].read(name) == data:
                        ok = True
                        break
                except KeyError:
                    pass
            if not ok:
                print("NOT IDENTICAL TO ANY ORIGIN ARCHIVE:", rel)
                bad += 1
    print(f"check_vendor: {len(fl)} files, {bad} problems" + (" (archives compared)" if a.repo else ""))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
