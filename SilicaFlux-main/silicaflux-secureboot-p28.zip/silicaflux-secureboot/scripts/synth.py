#!/usr/bin/env python3
"""SilicaFlux secure boot (Project 28) -- Yosys synthesis estimate of the new blocks.

    synth.py          -> reports/synth.md, build/synth/*.log

Yosys `synth_ecp5` (Lattice ECP5 generic mapping, the FPGA family of the P21 board flow) on each new block
as its own top.  This is a resource ESTIMATE: no constraints, no place-and-route, no timing closure.
"""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "build", "synth")
SHA = ["third_party/secworks-sha256/rtl/sha256_k_constants.v", "third_party/secworks-sha256/rtl/sha256_w_mem.v",
       "third_party/secworks-sha256/rtl/sha256_core.v"]
PKG = ["rtl/generated/cc_memmap_pkg.sv"]
BLOCKS = [
    ("sha256_core", SHA, "secworks SHA-256 compression core (vendored)"),
    ("sb_sha256_wrapper", SHA + ["rtl/sb_sha256_stream.sv", "rtl/sb_sha256_wrapper.sv"],
     "verified SHA-256 wrapper: padding + KAT + core"),
    ("silicaflux_secure_boot", PKG + SHA + ["rtl/sb_sha256_stream.sv", "rtl/sb_sha256_wrapper.sv",
                                            "rtl/silicaflux_secure_boot.sv"],
     "secure-boot block incl. SHA-256 wrapper, hash reader, registers"),
    ("sb_dma_guard", PKG + ["rtl/sb_dma_guard.sv"], "DMA guard, 4 windows"),
    ("sb_access_policy", PKG + ["rtl/sb_access_policy.sv"], "host / fetch / IMEM / debug policy (combinational)"),
    ("sb_otp_model", ["rtl/sb_otp_model.sv"], "fuse MODEL (registers, not OTP)"),
]


def run(top, files):
    os.makedirs(OUT, exist_ok=True)
    script = (f"read_verilog -sv -I rtl/generated {' '.join(files)}; "
              f"synth_ecp5 -top {top} -noflatten; flatten; stat")
    p = subprocess.run(["yosys", "-q", "-l", os.path.join(OUT, f"{top}.log"), "-p", script], cwd=ROOT,
                       capture_output=True, text=True)
    log = open(os.path.join(OUT, f"{top}.log")).read()
    stat = log[log.rfind("=== design hierarchy ==="):] if "=== design hierarchy ===" in log else log[log.rfind("Number of cells"):]
    def cnt(cell):
        m = re.findall(rf"^\s+{cell}\s+(\d+)", stat, re.M)
        return int(m[-1]) if m else 0
    luts = cnt("LUT4")
    ffs = sum(cnt(c) for c in ("TRELLIS_FF",))
    ccu = cnt("CCU2C")
    ram = cnt("DP16KD") + cnt("TRELLIS_DPR16X4")
    mult = cnt("MULT18X18D")
    return p.returncode, luts, ffs, ccu, ram, mult


def main():
    rows, bad = [], 0
    for top, files, what in BLOCKS:
        rc, luts, ffs, ccu, ram, mult = run(top, files)
        bad += rc != 0
        rows.append((top, what, "ok" if rc == 0 else "FAILED", luts, ffs, ccu, ram, mult))
        print(f"{top:24s} rc={rc} LUT4={luts} FF={ffs} CCU2C={ccu} RAM={ram} MULT={mult}")
    ver = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    md = ["# Synthesis estimate of the Project 28 blocks", "",
          f"{ver}, `synth_ecp5` per block (generic Lattice ECP5 mapping, as the P21 FPGA flow). **Estimate only**: "
          "no constraints, no place-and-route, no timing. Logs: `build/synth/*.log`.", "",
          "| Block | Contents | Synthesis | LUT4 | FF | CCU2C (carry) | RAM primitives | MULT18 |",
          "|---|---|---|---|---|---|---|---|"]
    md += [f"| `{a}` | {b} | {c} | {d} | {e} | {f} | {g} | {h} |" for a, b, c, d, e, f, g, h in rows]
    md += ["", "Not included: the 32 KiB boot ROM (generated combinational image; an FPGA flow should infer block RAM, "
           "an ASIC flow uses a ROM macro), the four added `cc_sfb_gate` instances (P21 block, small) and the "
           "single-cycle 33x33 multiplier of `mcu_cpu` RV32M = 2 (MCU-I, DSP blocks on ECP5)."]
    with open(os.path.join(ROOT, "reports", "synth.md"), "w") as f:
        f.write("\n".join(md) + "\n")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
