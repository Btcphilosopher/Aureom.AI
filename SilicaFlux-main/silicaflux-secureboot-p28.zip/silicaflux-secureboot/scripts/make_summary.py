#!/usr/bin/env python3
"""Project 28 -- collect the final result of every gate into reports/SUMMARY.md (from the reports themselves)."""
import json
import os
import re
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "reports")


def rd(p):
    p = os.path.join(R, p)
    return open(p, errors="replace").read() if os.path.exists(p) else ""


def first(pat, txt, default="not run"):
    m = re.search(pat, txt)
    return m.group(1) if m else default


def main():
    rows = []
    ref = rd("ref.md")
    rows.append(("Software reference (step 1): Ed25519 djb/RFC 8032 vectors on the ROM verifier, Monocypher and OpenSSL",
                 first(r"## A1[^\n]*\n\n\*\*([^*]+)\*\*", ref), "ref.md"))
    rows.append(("Software reference: Wycheproof Ed25519 (ROM verifier vs expected)",
                 first(r"## A2[^\n]*\n\n\*\*([^*]+)\*\*", ref), "ref.md"))
    rows.append(("Software reference: security corpus, spec == Python reference == native ROM policy",
                 first(r"## C\.[^\n]*\n\n\*\*([^*]+)\*\*", ref), "ref.md"))
    rows.append(("Software reference: differential fuzzing of the manifest policy (Python == C)",
                 first(r"## D\.[^\n]*\n\n\*\*([^*]+)\*\*", ref), "ref.md"))
    u = rd("unit_sb.md")
    rows.append(("Unit tests of the new RTL (SHA-256 vs NIST CAVP incl. Monte, KAT fault, DMA guard 200 k random, "
                 "secure-boot block)", first(r"\*\*(\d+ / \d+ runs PASS)\*\*", u), "unit_sb.md"))
    rows.append(("cocotb unit tests of the reused P21 blocks", first(r"\*\*(\d+ / \d+ PASS)\*\*", rd("unit.md")), "unit.md"))
    s = rd("security_regression.md")
    rows.append(("**Security regression on the RTL** (15 scenarios: all brief §10 cases)",
                 first(r"\*\*(\d+ / \d+ scenarios PASS, \d+ / \d+ checks PASS)\*\*", s), "security_regression.md"))
    rows.append(("Authentication time, 34 KB image (IMAGE_READY -> hand-off)",
                 first(r"\(IMAGE_READY -> answer, measured in `boot_ok`\): \*\*([^*]+)\*\*", s), "security_regression.md"))
    reg = json.loads(rd("regression.json") or "[]")
    if reg:
        npass = sum(r["result"] == "PASS" for r in reg)
        fw = [r for r in reg if r["fw_checks"]]
        rows.append(("Functional regression with the real accelerators (signed firmware)", f"{npass} / {len(reg)} PASS; "
                     f"{sum(r['fw_checks'] for r in fw)} firmware checks, {sum(r['fw_fails'] for r in fw)} fails",
                     "regression.md"))
    lint = rd("lint.md")
    nl = len(re.findall(r"\| \*\*PASS\*\* \|", lint))
    rows.append(("Lint (Verilator -Wall new RTL = 0 warnings; Icarus elaboration; firmware -Wall -Wextra)",
                 f"{nl} / {len(re.findall(r'^\| [^|-]', lint, re.M)) - 1} PASS" if lint else "not run", "lint.md"))
    isa = open(os.path.join(R, "isa", "riscv_tests_m2.txt")).read() if os.path.exists(os.path.join(R, "isa", "riscv_tests_m2.txt")) else ""
    rows.append(("riscv-tests on mcu_cpu RV32M = 2 (3 bus profiles x 2 seeds)", first(r"TOTAL (pass=\d+ fail=\d+)", isa),
                 "isa/riscv_tests_m2.txt"))
    syn = rd("synth.md")
    rows.append(("Yosys estimate: silicaflux_secure_boot (incl. SHA-256)",
                 first(r"`silicaflux_secure_boot` \|[^|]*\| ok \| (\d+) \|", syn) + " LUT4" if syn else "not run", "synth.md"))
    p = subprocess.run(["python3", "scripts/check_vendor.py"], cwd=ROOT, capture_output=True, text=True)
    rows.append(("Vendored sources unmodified (SHA256SUMS)", p.stdout.strip().splitlines()[-1] if p.stdout else "n/a",
                 "../third_party/PROVENANCE.md"))
    md = ["# Project 28 -- results summary", "",
          "Every line is copied from the report next to it (`make summary`). Simulation only: no FPGA board, no silicon. "
          "Not a security certification (docs/12_SECURITY_REVIEW.md).", "",
          "| Gate | Result | Report |", "|---|---|---|"]
    md += [f"| {a} | {b} | [{c}]({c}) |" for a, b, c in rows]
    with open(os.path.join(R, "SUMMARY.md"), "w") as f:
        f.write("\n".join(md) + "\n")
    print("\n".join(f"{b:45s} {a}" for a, b, c in rows))


if __name__ == "__main__":
    main()
