#!/usr/bin/env python3
"""Negative tests of the address-map validator (scripts/gen_memmap.py).

Each case mutates a copy of config/cc_memmap.yaml and asserts that validation
FAILS with the expected message; the unmodified map must pass.  Output:
reports/memmap_tests.md.
"""
import copy
import os
import sys

import yaml

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_memmap as G  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def region(m, name):
    return next(r for r in m["regions"] if r["name"] == name)


def blk(m, name):
    return m["blocks"][name]["regs"]


CASES = [
    ("region overlap (DMEM moved onto IMEM)", "overlap", lambda m: region(m, "DMEM").update(base=0x00018000)),
    ("region base not aligned to its size", "not aligned", lambda m: region(m, "IMEM").update(base=0x00012000)),
    ("region size not a power of two", "power of two", lambda m: region(m, "DMEM").update(size=0x6000)),
    ("region beyond 4 GiB", "32-bit space", lambda m: region(m, "EXT").update(base=0xE0000000, size=0x40000000)),
    ("duplicate crossbar slave index", "slave indices", lambda m: region(m, "EXT").update(slave=0)),
    ("EXT sub-region outside EXT", "not inside EXT", lambda m: m["ext_subregions"][0].update(base=0x40000000)),
    ("PERIPH not 32 pages", "32 pages", lambda m: region(m, "PERIPH").update(size=0x10000)),
    ("page defined twice", "defined twice", lambda m: m["pages"].append(dict(m["pages"][0]))),
    ("forwarded page outside 8..15", "forwarded", lambda m: m["pages"][0].update(forwarded=True)),
    ("register offset misaligned", "misaligned", lambda m: blk(m, "cc_ras")[1].update(ofs=0x006)),
    ("register offset outside the page", "outside the page", lambda m: blk(m, "cc_ras")[1].update(ofs=0x1000)),
    ("duplicate register offset", "duplicate offset", lambda m: blk(m, "cc_ras")[2].update(ofs=0x004)),
    ("duplicate IRQ id", "irq ids", lambda m: m["irqs"][1].update(id=0)),
    ("IRQ id >= 16", "irq ids", lambda m: m["irqs"][1].update(id=16)),
    ("access matrix names an unknown region", "unknown region", lambda m: m["access"]["DMA"].append("NOWHERE")),
    ("reused block offset differs from MCU-I package", "mcu_memmap_pkg", lambda m: blk(m, "mcu_wdt")[0].update(ofs=0x020)),
    ("duplicate enumeration value", "duplicate values", lambda m: m["enums"]["BOOT_STAGE"].update(ROM_INIT=0x01)),
]


def main():
    base = yaml.safe_load(open(G.CFG))
    G.errors.clear()
    G.validate(copy.deepcopy(base))
    ok = not G.errors
    rows = [("unmodified map passes", "-", "PASS" if ok else f"FAIL {G.errors}")]
    fails = 0 if ok else 1
    for name, expect, mut in CASES:
        m = copy.deepcopy(base)
        mut(m)
        G.errors.clear()
        try:
            G.validate(m)
        except Exception as e:  # a crash is not a clean rejection
            G.errors.append(f"EXCEPTION {e!r}")
        hit = [e for e in G.errors if expect in e]
        res = "PASS (rejected)" if hit and not any(e.startswith("EXCEPTION") for e in G.errors) else f"FAIL {G.errors}"
        fails += not res.startswith("PASS")
        rows.append((name, hit[0] if hit else "-", res))
    G.errors.clear()
    md = ["# Address-map validator: negative tests", "", "`scripts/test_memmap.py` mutates `config/cc_memmap.yaml` "
          "and checks that `scripts/gen_memmap.py` rejects every illegal map.", "",
          f"**{len(rows) - fails} / {len(rows)} PASS**", "", "| Case | Validator message | Result |", "|---|---|---|"]
    md += [f"| {a} | {b} | {c} |" for a, b, c in rows]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "memmap_tests.md"), "w").write("\n".join(md) + "\n")
    for a, b, c in rows:
        print(f"{c:<16} {a}")
    print(f"test_memmap: {len(rows) - fails}/{len(rows)} PASS")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
