/* Minimal freestanding memcpy/memset for the boot ROM (GCC may emit calls to
 * them for structure copies; Monocypher uses them).  Byte loops: small, no
 * alignment assumptions. */
#include <stddef.h>
void *memcpy(void *d, const void *s, size_t n) {
  unsigned char *p = d;
  const unsigned char *q = s;
  while (n--) *p++ = *q++;
  return d;
}
void *memset(void *d, int c, size_t n) {
  unsigned char *p = d;
  while (n--) *p++ = (unsigned char)c;
  return d;
}
