/* =============================================================================
 * SilicaFlux ControlCore v2 -- SECURE BOOT ROM (Project 28; mask ROM, 32 KiB)
 *
 *   Immutable boot ROM -> firmware manifest -> cryptographic verification
 *   -> authenticated firmware load -> controlled execution
 *
 * Fail-closed policy: the ROM never jumps to code the secure-boot block has
 * not opened (instruction fetch from IMEM is impossible before PASS, so a ROM
 * bug cannot do it either).  Every failure ends in a reported BOOT_ERR_* code
 * and either "wait for a new image from the host" or a parked CPU (lockdown).
 *
 * Stages (SYSCTRL.BOOT_STAGE) and what happens:
 *   ROM_START    DMEM scrubbed (rom_start.S); wait for the SHA-256 KAT
 *   ROM_INIT     peripherals to a known state, DMEM pattern test, lifecycle read
 *   warm boot    (cause SOFT/WDT, not RECOVERY): the retained image is SEALED
 *                and fully RE-AUTHENTICATED (no "warm" shortcut)
 *   cold boot    IMEM scrubbed, parity on; BOOT_MODE_EXT (unless disabled by the
 *                fuse model or RECOVERY): manifest DMA-copied and VALIDATED
 *                (lengths, bounds) before the payload is copied
 *   WAIT_IMAGE   host writes the image into IMEM (LOAD state), IMAGE_READY doorbell
 *   IMAGE_CHECK  seal -> manifest copy into DMEM -> policy -> hardware SHA-256 ->
 *                Ed25519 (Monocypher) -> constant-time digest compare -> hardware
 *                hand-off checks -> PASS
 *   FW_START     jump to the entry point inside the authenticated window
 *   BOOT_ERROR   FAIL_CODE / BOOT_STATUS = BOOT_ERR_*; host told; RELOAD; IMEM
 *                scrubbed; wait for the next image (recovery path is authenticated)
 * Diagnostics carry error codes, stages and public values only (the device
 * holds no secret: root keys are public keys).
 * ===========================================================================*/
#include "cc_hw.h"
#include "sb_policy.h"

#define TMO_SB 2000000u

static sb_manifest_t g_m;        /* manifest copy in DMEM (ROM-private: host cannot read or write DMEM) */
static sb_ctx_t      g_ctx;

static void rputc(char c) { MBOX(CC_MBOX_DIAG_TX) = (uint8_t)c; }
static void rputs(const char *s) { while (*s) rputc(*s++); }
static void rhex(uint32_t v) {
  for (int i = 28; i >= 0; i -= 4) rputc("0123456789abcdef"[(v >> i) & 15u]);
}

static void reply(uint32_t cmd, uint32_t sts, uint32_t detail) {
  MBOX_F2H(1) = detail;
  MBOX_F2H(0) = sts | (cmd << 8);
  MBOX(CC_MBOX_F2H_RING) = cmd;
}

static void park(void) {
  for (;;) wfi();
}

void rom_trap_c(uint32_t cause, uint32_t epc, uint32_t tval) {
  MBOX_F2H(1) = cause;
  MBOX_F2H(2) = epc;
  MBOX_F2H(3) = tval;
  SYSCTRL(CC_SYSCTRL_BOOT_STATUS) = CC_BOOT_ERR_TRAP;
  boot_stage(CC_BOOT_STAGE_BOOT_ERROR);
  rputs("ROM: trap ");
  rhex(cause);
  rputc(' ');
  rhex(epc);
  rputc('\n');
}

static int sb_wait_not(uint32_t st) {
  for (uint32_t i = 0; i < TMO_SB; i++)
    if (SB_STATE() != st) return 0;
  return -1;
}

/* fatal, before any image is considered: KAT failure, invalid lifecycle */
static void lockdown(uint32_t code) {
  SYSCTRL(CC_SYSCTRL_BOOT_STATUS) = code;
  boot_stage(CC_BOOT_STAGE_FATAL);
  rputs("ROM: LOCKDOWN ");
  rhex(code);
  rputc('\n');
  MBOX_F2H(1) = code;
  MBOX_F2H(0) = CC_MBOX_STS_BAD_CMD | (CC_MBOX_CMD_IMAGE_READY << 8);
  MBOX(CC_MBOX_F2H_RING) = CC_MBOX_CMD_IMAGE_READY;
  park();
}

/* an authentication attempt failed: record, tell the host, return to LOAD */
static void boot_error(uint32_t code) {
  uint32_t st = SB_STATE();
  /* only commands that are legal in the current state (an illegal one is a bus error) */
  if (st == CC_SB_STATE_LOAD || st == CC_SB_STATE_SEALED || st == CC_SB_STATE_HASHED || st == CC_SB_STATE_FAIL) {
    SEC(CC_SEC_FAIL_CODE) = code;
    if (st != CC_SB_STATE_FAIL) sb_cmd(CC_SB_CMD_FAIL);
    sb_cmd(CC_SB_CMD_RELOAD);                                /* FAIL -> LOAD: IMEM writable, not executable */
  } else {
    lockdown(code);                                          /* SEALING / HASHING stuck, LOCKDOWN, PASS: stop */
  }
  SYSCTRL(CC_SYSCTRL_BOOT_STATUS) = code;
  boot_stage(CC_BOOT_STAGE_BOOT_ERROR);
  rputs("ROM: authentication failed, code ");
  rhex(code);
  rputs(" refusal ");
  rhex(SEC(CC_SEC_STATUS) >> 24);
  rputc('\n');
  reply(CC_MBOX_CMD_IMAGE_READY, CC_MBOX_STS_BAD_CMD, code);
}

/* DMEM pattern test between the ROM's .bss and its stack */
extern uint32_t __bss_end[], __stack_top[];
static int memtest_dmem(void) {
  volatile uint32_t *lo = (volatile uint32_t *)(uintptr_t)__bss_end;
  volatile uint32_t *hi = (volatile uint32_t *)((uintptr_t)__stack_top - 8192u);   /* keep 8 KiB of stack */
  int bad = 0;
  for (volatile uint32_t *p = lo; p < hi; p++) *p = (uint32_t)(uintptr_t)p ^ 0xA5A55A5Au;
  for (volatile uint32_t *p = lo; p < hi; p++) if (*p != ((uint32_t)(uintptr_t)p ^ 0xA5A55A5Au)) bad++;
  for (volatile uint32_t *p = lo; p < hi; p++) *p = 0u;
  return bad;
}

static void scrub_imem(void) {           /* only possible in LOAD: the IMEM gate refuses it otherwise */
  volatile uint32_t *p = (volatile uint32_t *)CC_IMEM_BASE;
  volatile uint32_t *e = (volatile uint32_t *)(CC_IMEM_BASE + CC_IMEM_SIZE);
  while (p < e) { p[0] = 0u; p[1] = 0u; p[2] = 0u; p[3] = 0u; p += 4; }
}

/* ---------------------------------------------------------------- system DMA through the guard */
static void dg_window(uint32_t i, uint32_t base, uint32_t len, uint32_t attr) {
  DG_WIN(i, CC_DG_WIN0_BASE - CC_DG_WIN0_BASE) = base;
  DG_WIN(i, CC_DG_WIN0_LAST - CC_DG_WIN0_BASE) = base + len - 1u;
  DG_WIN(i, CC_DG_WIN0_ATTR - CC_DG_WIN0_BASE) = attr;
}
static int dma_copy(uint32_t src, uint32_t dst, uint32_t len) {
  dg_window(0, src, len, CC_DG_ATTR_EN | CC_DG_ATTR_READ);
  dg_window(1, dst, len, CC_DG_ATTR_EN | CC_DG_ATTR_WRITE);
  DMA(CC_DMA_INT_ENABLE) = 0u;
  DMA(CC_DMA_SRC_ADDR) = src;
  DMA(CC_DMA_DST_ADDR) = dst;
  DMA(CC_DMA_LENGTH) = len;
  DMA(CC_DMA_MODE) = 0u;
  DMA(CC_DMA_INT_STATUS) = CC_DMA_INT_DONE | CC_DMA_INT_ERROR;
  DMA(CC_DMA_CONTROL) = CC_DMA_CONTROL_START;
  while (DMA(CC_DMA_STATUS) & CC_DMA_STATUS_BUSY) {}
  int r = (DMA(CC_DMA_STATUS) & CC_DMA_STATUS_ERROR) ? -1 : 0;
  DG_WIN(0, CC_DG_WIN0_ATTR - CC_DG_WIN0_BASE) = 0u;          /* default deny again */
  DG_WIN(1, CC_DG_WIN0_ATTR - CC_DG_WIN0_BASE) = 0u;
  return r;
}

static void copy_manifest(void) {        /* one copy into ROM-private DMEM; every later check uses it */
  const volatile uint32_t *s = (const volatile uint32_t *)CC_IMEM_BASE;
  uint32_t *d = (uint32_t *)&g_m;
  for (unsigned i = 0; i < sizeof g_m / 4u; i++) d[i] = s[i];
}

/* BOOT_MODE_EXT: manifest first, validated, then exactly image_length payload bytes */
static uint32_t ext_load(uint32_t src) {
  if ((src & 3u) || src < CC_EXT_BASE || src > CC_EXT_BASE + CC_EXT_SIZE - CC_IMEM_SIZE) return CC_BOOT_ERR_DMA;
  if (dma_copy(src, CC_IMEM_BASE, CC_SB_MANIFEST_SIZE)) return CC_BOOT_ERR_DMA;
  copy_manifest();
  uint32_t e = sb_manifest_check(&g_m, &g_ctx);         /* lengths and bounds BEFORE the copy */
  if (e != CC_BOOT_ERR_NONE) return e;
  if (dma_copy(src + CC_SB_MANIFEST_SIZE, CC_IMEM_BASE + CC_SB_MANIFEST_SIZE, g_m.image_length)) return CC_BOOT_ERR_DMA;
  return CC_BOOT_ERR_NONE;
}

static uint32_t be32(const uint8_t *p) {
  return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

/* seal -> policy -> hardware measurement -> signature -> digest -> hand-off registers */
static uint32_t authenticate(void) {
  boot_stage(CC_BOOT_STAGE_IMAGE_CHECK);
  sb_cmd(CC_SB_CMD_SEAL);                                  /* IMEM now write-protected for every master */
  if (sb_wait_not(CC_SB_STATE_SEALING) || SB_STATE() != CC_SB_STATE_SEALED) return CC_BOOT_ERR_SEAL;
  copy_manifest();
  uint32_t e = sb_manifest_check(&g_m, &g_ctx);
  if (e != CC_BOOT_ERR_NONE) return e;
  SEC(CC_SEC_HASH_BASE) = CC_IMEM_BASE + g_m.image_offset;
  SEC(CC_SEC_HASH_LEN) = g_m.image_length;
  sb_cmd(CC_SB_CMD_HASH);
  if (sb_wait_not(CC_SB_STATE_HASHING) || SB_STATE() != CC_SB_STATE_HASHED) return CC_BOOT_ERR_HW_HASH;
  e = sb_signature_check(&g_m);                            /* Ed25519 over manifest [0x00, 0xC0) */
  if (e != CC_BOOT_ERR_NONE) return e;
  uint8_t d[32];
  for (unsigned i = 0; i < 8; i++) {
    uint32_t w = SEC(CC_SEC_DIGEST0 + 4u * i);
    d[4 * i] = (uint8_t)(w >> 24); d[4 * i + 1] = (uint8_t)(w >> 16); d[4 * i + 2] = (uint8_t)(w >> 8); d[4 * i + 3] = (uint8_t)w;
  }
  if (!sb_ct_equal(d, g_m.image_digest, 32)) return CC_BOOT_ERR_DIGEST;
  /* hand the verified facts to the hardware, which re-checks them independently */
  for (unsigned i = 0; i < 8; i++) SEC(CC_SEC_EXPECT0 + 4u * i) = be32(&g_m.image_digest[4 * i]);
  SEC(CC_SEC_ENTRY) = g_m.entry;
  SEC(CC_SEC_KEY_SLOT) = g_m.key_id;
  SEC(CC_SEC_IMAGE_SVN) = g_m.security_version;
  SEC(CC_SEC_SIG_TOKEN) = CC_SB_TOKEN_A;
  SEC(CC_SEC_SIG_TOKEN) = CC_SB_TOKEN_B;
  return CC_BOOT_ERR_NONE;
}

/* returns only if the hardware refused the hand-off */
static uint32_t handoff(uint32_t warm, uint32_t notify_host) {
  sb_cmd(CC_SB_CMD_HANDOFF);
  if (SB_STATE() != CC_SB_STATE_PASS) return CC_BOOT_ERR_HANDOFF;
  if (notify_host) reply(CC_MBOX_CMD_IMAGE_READY, CC_MBOX_STS_OK, 0u);   /* only once the hardware agreed */
  SYSCTRL(CC_SYSCTRL_BOOT_STATUS) = warm ? 0x100u : 0u;
  boot_stage(CC_BOOT_STAGE_FW_START);
  rputs(warm ? "ROM: authenticated (warm), start " : "ROM: authenticated, start ");
  rhex(g_m.entry);
  rputs(" slot ");
  rhex(g_m.key_id);
  rputs(" svn ");
  rhex(g_m.security_version);
  rputs(" sha256 ");
  rhex(SEC(CC_SEC_DIGEST0));
  rhex(SEC(CC_SEC_DIGEST0 + 4u));
  rputs("...\n");
  fence_i();
  ((void (*)(void))(uintptr_t)g_m.entry)();
  return CC_BOOT_ERR_HANDOFF;
}

static const char *lc_name(uint32_t lc) {
  switch (lc) {
    case CC_SB_LC_DEV: return "DEV (debug OPEN, development key accepted -- NOT SECURE)";
    case CC_SB_LC_PROV: return "PROV";
    case CC_SB_LC_PROD: return "PROD";
    case CC_SB_LC_RECOVERY: return "RECOVERY";
    default: return "INVALID";
  }
}

void rom_main(void) {
  boot_stage(CC_BOOT_STAGE_ROM_START);
  rputs("\nSFCC secure boot ROM v2.0 (P28)\n");
  uint32_t cause = SYSCTRL(CC_SYSCTRL_RESET_CAUSE);
  uint32_t mode = SYSCTRL(CC_SYSCTRL_BOOT_MODE) & 3u;

  /* ---- ROM_INIT: known peripheral state, memory test, crypto self-test, lifecycle */
  boot_stage(CC_BOOT_STAGE_ROM_INIT);
  INTC(CC_INTC_ENABLE) = 0u;
  INTC(CC_INTC_THRESHOLD) = 0u;
  DMA(CC_DMA_INT_ENABLE) = 0u;
  RAS(CC_RAS_WARN_EN) = 0u;
  RAS(CC_RAS_FATAL_EN) = 0u;
  if (memtest_dmem()) {
    boot_error(CC_BOOT_ERR_MEMTEST);
    park();
  }
  if (sb_wait_not(CC_SB_STATE_SELFTEST)) lockdown(CC_BOOT_ERR_CRYPTO_KAT);
  uint32_t status = SEC(CC_SEC_STATUS);
  uint32_t lcr = SEC(CC_SEC_LIFECYCLE);
  if ((status & 0xFu) == CC_SB_STATE_LOCKDOWN)
    lockdown(((status >> 8) & 1u) ? CC_BOOT_ERR_LIFECYCLE : CC_BOOT_ERR_CRYPTO_KAT);
  g_ctx.lc = lcr & 0xFu;
  g_ctx.revoked = SEC(CC_SEC_REVOKED);
  g_ctx.min_svn = SEC(CC_SEC_MIN_SVN);
  g_ctx.rollback_enforced = (lcr >> 11) & 1u;
  g_ctx.target_id = SEC(CC_SEC_TARGET_ID);
  g_ctx.hw_version = SEC(CC_SEC_HW_VERSION);
  uint32_t ext_disabled = (lcr >> 12) & 1u;
  rputs("ROM: lifecycle ");
  rputs(lc_name(g_ctx.lc));
  rputs(" min_svn ");
  rhex(g_ctx.min_svn);
  rputs(" revoked ");
  rhex(g_ctx.revoked);
  rputc('\n');

  /* ---- warm boot: the retained image is re-authenticated in full */
  if ((cause & (CC_RESET_CAUSE_SOFT | CC_RESET_CAUSE_WDT)) && g_ctx.lc != CC_SB_LC_RECOVERY) {
    RAS(CC_RAS_PAR_CHK_EN) = 1u;
    uint32_t e = authenticate();
    if (e == CC_BOOT_ERR_NONE) e = handoff(1u, 0u);
    boot_error(e);
    rputs("ROM: retained image not authentic, cold boot\n");
  }

  /* ---- cold boot */
  scrub_imem();
  RAS(CC_RAS_PAR_CHK_EN) = 1u;

  if (mode == CC_BOOT_MODE_EXT && !ext_disabled) {
    uint32_t src = MBOX_H2F(1) ? MBOX_H2F(1) : CC_EXT_IMAGE_DEFAULT;
    rputs("ROM: image from ");
    rhex(src);
    rputc('\n');
    uint32_t e = ext_load(src);
    if (e == CC_BOOT_ERR_NONE) e = authenticate();
    if (e == CC_BOOT_ERR_NONE) e = handoff(0u, 0u);
    boot_error(e);
    scrub_imem();                                             /* fall back to host loading */
  }

  for (;;) {
    boot_stage(CC_BOOT_STAGE_WAIT_IMAGE);
    for (;;) {
      if (MBOX(CC_MBOX_DB_STATUS) & 1u) {
        uint32_t cmd = MBOX_H2F(0);
        MBOX(CC_MBOX_H2F_ACK) = 0u;
        if (cmd == CC_MBOX_CMD_IMAGE_READY) break;
        reply(cmd, CC_MBOX_STS_BUSY, 0u);                     /* not ready for commands yet */
      }
    }
    uint32_t e = authenticate();
    if (e == CC_BOOT_ERR_NONE) e = handoff(0u, 1u);
    boot_error(e);
    scrub_imem();                                             /* nothing unauthenticated stays in IMEM */
  }
}
