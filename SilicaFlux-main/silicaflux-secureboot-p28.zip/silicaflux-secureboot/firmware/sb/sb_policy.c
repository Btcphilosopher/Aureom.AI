/* =============================================================================
 * SilicaFlux secure boot (Project 28) -- manifest policy and signature check
 * See sb_policy.h.  Order of the checks is part of the specification: the
 * Python reference (tools/sbimage.py) implements the same order independently
 * and the cross-check (ref/run_ref.py) requires identical error codes.
 * ===========================================================================*/
#include "sb_policy.h"
#include "sb_rom_keys.h"
#include "monocypher-ed25519.h"

int sb_ct_equal(const uint8_t *a, const uint8_t *b, unsigned n) {
  uint32_t d = 0;
  for (unsigned i = 0; i < n; i++) d |= (uint32_t)(a[i] ^ b[i]);
  return (int)(1u & ((d - 1u) >> 8));        /* d == 0 -> 1, d in 1..255 -> 0, no branch on data */
}

static int all_zero(const uint8_t *p, unsigned n) {
  uint32_t d = 0;
  for (unsigned i = 0; i < n; i++) d |= p[i];
  return d == 0;
}

uint32_t sb_manifest_check(const sb_manifest_t *m, const sb_ctx_t *c) {
  /* 1-3 format identification */
  if (m->magic != CC_SB_MANIFEST_MAGIC) return CC_BOOT_ERR_M_MAGIC;
  if (m->manifest_version != CC_SB_MANIFEST_VERSION) return CC_BOOT_ERR_M_VERSION;
  if (m->manifest_size != CC_SB_MANIFEST_SIZE) return CC_BOOT_ERR_M_SIZE;
  /* 4-6 algorithms and policy: only what this ROM implements */
  if (m->hash_alg != CC_SB_HASH_SHA256) return CC_BOOT_ERR_HASH_ALG;
  if (m->sig_alg != CC_SB_SIG_ED25519) return CC_BOOT_ERR_SIG_ALG;
  if (m->policy_version != CC_SB_POLICY_VERSION) return CC_BOOT_ERR_POLICY;
  /* 7-8 target device */
  if (m->target_id != c->target_id) return CC_BOOT_ERR_TARGET;
  if ((m->target_hw_version >> 16) != (c->hw_version >> 16) ||
      (m->target_hw_version & 0xFFFFu) > (c->hw_version & 0xFFFFu))
    return CC_BOOT_ERR_TARGET_HW;
  /* 9-11 root key: slot exists, allowed in this lifecycle, not revoked */
  if (m->key_id >= CC_SB_NKEYS) return CC_BOOT_ERR_KEY_ID;
  if (sb_slot_is_dev(m->key_id) && c->lc != CC_SB_LC_DEV) return CC_BOOT_ERR_KEY_LIFECYCLE;
  if ((c->revoked >> m->key_id) & 1u) return CC_BOOT_ERR_KEY_REVOKED;
  /* 12-13 flags and reserved fields */
  if (m->flags & ~(uint32_t)CC_SB_FLAGS_KNOWN) return CC_BOOT_ERR_FLAGS;
  if ((m->flags & CC_SB_FLAG_DEV_ONLY) && c->lc != CC_SB_LC_DEV) return CC_BOOT_ERR_FLAGS;
  if (m->reserved0 != 0u || !all_zero(m->reserved1, sizeof m->reserved1)) return CC_BOOT_ERR_RESERVED;
  /* 14-16 placement, length, entry: no addition that can wrap (all operands < 2^17) */
  if (m->load_addr != CC_IMEM_BASE || m->image_offset != CC_SB_MANIFEST_SIZE) return CC_BOOT_ERR_LOAD_ADDR;
  if (m->image_length == 0u || (m->image_length & 3u) ||
      m->image_length > (uint32_t)CC_IMEM_SIZE - (uint32_t)CC_SB_MANIFEST_SIZE)
    return CC_BOOT_ERR_LENGTH;
  {
    uint32_t lo = CC_IMEM_BASE + CC_SB_MANIFEST_SIZE;
    if (m->entry < lo || m->entry - lo >= m->image_length || (m->entry & 3u)) return CC_BOOT_ERR_ENTRY;
  }
  /* 17-18 anti-rollback */
  if (m->security_version > CC_SB_SVN_MAX) return CC_BOOT_ERR_SVN_RANGE;
  if (c->rollback_enforced && m->security_version < c->min_svn) return CC_BOOT_ERR_ROLLBACK;
  return CC_BOOT_ERR_NONE;
}

/* R strict-encoding rule of RFC 8032 5.1.3 (public data: not constant time).
 * y = R with bit 255 cleared, little-endian; p = 2^255 - 19. */
static int r_is_canonical(const uint8_t r[32]) {
  int mid_ff = 1;
  for (int i = 1; i < 31; i++) mid_ff &= (r[i] == 0xFFu);
  int top_7f = ((r[31] & 0x7Fu) == 0x7Fu);
  int sign = r[31] >> 7;
  if (mid_ff && top_7f && r[0] >= 0xEDu) return 0;                 /* y >= p                      */
  if (!sign) return 1;
  int zero_mid = 1;
  for (int i = 1; i < 31; i++) zero_mid &= (r[i] == 0u);
  if (zero_mid && (r[31] & 0x7Fu) == 0u && r[0] == 1u) return 0;    /* y = 1, x = 0, sign bit set  */
  if (mid_ff && top_7f && r[0] == 0xECu) return 0;                  /* y = p-1, x = 0, sign bit set */
  return 1;
}

int sb_ed25519_verify(const uint8_t sig[64], const uint8_t pk[32], const uint8_t *msg, uint32_t n) {
  if (!r_is_canonical(sig)) return -1;
  return crypto_ed25519_check(sig, pk, msg, n);
}

uint32_t sb_signature_check(const sb_manifest_t *m) {
  if (m->key_id >= CC_SB_NKEYS) return CC_BOOT_ERR_KEY_ID;
  int r = sb_ed25519_verify(m->signature, sb_rom_keys[m->key_id], (const uint8_t *)m, CC_SB_SIGNED_BYTES);
  return (r == 0) ? CC_BOOT_ERR_NONE : CC_BOOT_ERR_SIGNATURE;
}
