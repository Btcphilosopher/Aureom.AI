/* =============================================================================
 * SilicaFlux secure boot (Project 28) -- manifest policy and signature check
 *
 * Shared, unmodified, by the mask-ROM build (firmware/bootrom) and the native
 * host reference (ref/sbref.c).  No hardware access in this file: the caller
 * supplies the device context (lifecycle, fuse-model state, hardware identity).
 * ===========================================================================*/
#ifndef SB_POLICY_H
#define SB_POLICY_H
#include <stdint.h>
#include "sb_manifest.h"

typedef struct {
  uint32_t lc;                 /* effective lifecycle, CC_SB_LC_* (DEV, PROV, PROD, RECOVERY)      */
  uint32_t revoked;            /* [CC_SB_NKEYS-1:0] revoked root-key slots (fuse model)            */
  uint32_t min_svn;            /* minimum security version (fuse model thermometer, decoded)       */
  uint32_t rollback_enforced;  /* 1: security_version < min_svn is rejected                        */
  uint32_t target_id;          /* SECURITY.TARGET_ID                                               */
  uint32_t hw_version;         /* SECURITY.HW_VERSION                                              */
} sb_ctx_t;

/* Structural + policy checks of a manifest copy, in the documented order
 * (docs/04_IMAGE_FORMAT.md section 3).  Uses no cryptography.  Returns
 * CC_BOOT_ERR_NONE or the first failing CC_BOOT_ERR_*.  Every length and
 * bound is checked here, before any payload byte is copied or hashed. */
uint32_t sb_manifest_check(const sb_manifest_t *m, const sb_ctx_t *c);

/* Ed25519 (RFC 8032) verification of manifest bytes [0, CC_SB_SIGNED_BYTES)
 * with the ROM root key of slot m->key_id (slot range must already have been
 * checked by sb_manifest_check).  Returns CC_BOOT_ERR_NONE or
 * CC_BOOT_ERR_SIGNATURE. */
uint32_t sb_signature_check(const sb_manifest_t *m);

/* The ROM's Ed25519 verifier: RFC 8032 section 5.1.3 strict decoding of R
 * (y < p; the sign bit must be 0 when x = 0, i.e. y = 1 or y = p - 1), then
 * Monocypher crypto_ed25519_check (which itself rejects S >= L).  The R rule
 * closes the one Wycheproof vector Monocypher 4.0.2 accepts (tcId 151).
 * Returns 0 when the signature is valid. */
int sb_ed25519_verify(const uint8_t sig[64], const uint8_t pk[32], const uint8_t *msg, uint32_t n);

/* Constant-time comparison: returns 1 when equal, 0 otherwise. */
int sb_ct_equal(const uint8_t *a, const uint8_t *b, unsigned n);

/* Is root-key slot `slot` a development key? */
static inline int sb_slot_is_dev(uint32_t slot) { return (int)((CC_SB_DEV_KEY_MASK >> slot) & 1u); }

#endif
