/* =============================================================================
 * SilicaFlux secure boot (Project 28) -- firmware manifest v1
 *
 * The signed image is   [ manifest (0x100 bytes) | payload (image_length bytes) ]
 * and is loaded at CC_IMEM_BASE.  All fields are little-endian.  The Ed25519
 * signature (RFC 8032, pure Ed25519) covers manifest bytes [0x00, 0xC0); it is
 * stored at [0xC0, 0x100).  The payload is bound to the manifest by its
 * SHA-256 digest (image_digest), which the hardware recomputes over the sealed
 * IMEM copy.  Format reference: docs/04_IMAGE_FORMAT.md; independent Python
 * reference: tools/sbimage.py (same layout, separate implementation).
 * ===========================================================================*/
#ifndef SB_MANIFEST_H
#define SB_MANIFEST_H
#include <stdint.h>
#include "generated/cc_memmap.h"

typedef struct {
  uint32_t magic;             /* 0x00 CC_SB_MANIFEST_MAGIC ("SFSB")                       */
  uint16_t manifest_version;  /* 0x04 CC_SB_MANIFEST_VERSION                               */
  uint16_t manifest_size;     /* 0x06 CC_SB_MANIFEST_SIZE                                  */
  uint32_t target_id;         /* 0x08 must equal SECURITY.TARGET_ID                        */
  uint32_t target_hw_version; /* 0x0C [31:16] major == HW major, [15:0] minor <= HW minor   */
  uint32_t hash_alg;          /* 0x10 CC_SB_HASH_SHA256                                    */
  uint32_t sig_alg;           /* 0x14 CC_SB_SIG_ED25519                                    */
  uint32_t key_id;            /* 0x18 root-key slot 0..CC_SB_NKEYS-1                       */
  uint32_t policy_version;    /* 0x1C CC_SB_POLICY_VERSION                                 */
  uint32_t fw_version;        /* 0x20 informational                                        */
  uint32_t security_version;  /* 0x24 anti-rollback counter value, 0..CC_SB_SVN_MAX        */
  uint32_t flags;             /* 0x28 CC_SB_FLAG_*; unknown bits rejected                  */
  uint32_t load_addr;         /* 0x2C == CC_IMEM_BASE                                      */
  uint32_t image_offset;      /* 0x30 == CC_SB_MANIFEST_SIZE                               */
  uint32_t image_length;      /* 0x34 payload bytes, multiple of 4, 4..IMEM-0x100          */
  uint32_t entry;             /* 0x38 absolute, word aligned, inside the payload           */
  uint32_t reserved0;         /* 0x3C 0                                                    */
  uint8_t  image_digest[32];  /* 0x40 SHA-256(payload)                                     */
  uint8_t  build_id[32];      /* 0x60 opaque (signed, not interpreted)                     */
  uint8_t  reserved1[64];     /* 0x80 0                                                    */
  uint8_t  signature[64];     /* 0xC0 Ed25519(R || S) over bytes [0x00, 0xC0)              */
} sb_manifest_t;

_Static_assert(sizeof(sb_manifest_t) == CC_SB_MANIFEST_SIZE, "manifest must be 0x100 bytes");
_Static_assert(__builtin_offsetof(sb_manifest_t, image_digest) == 0x40, "layout");
_Static_assert(__builtin_offsetof(sb_manifest_t, signature) == CC_SB_SIGNED_BYTES, "layout");

#endif
