/* =============================================================================
 * SilicaFlux ControlCore firmware -- main: boot stages + host command processor
 *
 * Boot (continuing the ROM's stages, all visible in SYSCTRL.BOOT_STAGE):
 *   FW_INIT        reset cause, interrupt controller, timer tick, watchdog, RAS
 *   ACC_DISCOVERY  probe the vector tile and the tensor unit (IDs, ABI, config)
 *   SELF_TEST      power-on self-test: one NOP round trip per accelerator (IRQ)
 *   CMDPROC_READY  mailbox command processor running  (HOST_STATUS.CMDPROC_READY)
 *   HOST_READY     capabilities published, host told   (HOST_STATUS.HOST_READY pin)
 * Then: sleep (WFI) until the HOST interrupt delivers a mailbox command; run it on
 * the accelerators; answer in F2H_MSG0..7 and ring F2H (host_irq pin).
 * Response: F2H_MSG0 = status | cmd << 8 | seq << 16, F2H_MSG1.. = data.
 * ===========================================================================*/
#include "fw.h"

static uint32_t reset_cause;

static void respond(uint32_t cmd, uint32_t sts, const uint32_t *d, int n) {
  for (int i = 0; i < n && i < 7; i++) MBOX_F2H(1 + i) = d[i];
  MBOX_F2H(0) = sts | (cmd << 8) | ((g_cmd_seq & 0xFFFFu) << 16);
  MBOX(CC_MBOX_F2H_RING) = cmd;
}

static int post(void) {
  int fails = 0;
  hpc_cpl_t cpl;
  tsu_record_t rec;
  uint32_t d[TSU_DESC_WORDS];
  if (g_acc.vec_present) {
    hpc_cmd_t c = hpc_cmd_nop(0x01, 0u);
    if (vec_run(&c, &cpl) || cpl.status != HPC_ST_OK || cpl.tag != 0x01) fails++;
  }
  if (g_acc.tsu_present) {
    tsu_build_nop(d, 0x01, 1);
    if (tsu_run(d, &rec) || rec.status != TSU_ST_OK || rec.tid != 0x01) fails++;
  }
  static DMABUF uint32_t s[4], t[4];
  for (int i = 0; i < 4; i++) { s[i] = (uint32_t)i + 1u; t[i] = 0u; }
  if (dma_copy((uint32_t)(uintptr_t)s, (uint32_t)(uintptr_t)t, 16u) || memcmp(s, t, 16)) fails++;
  if (RAS(CC_RAS_PAR_CHK_EN) != 1u) fails++;
  return fails;
}

static void cmd_gemm(void) {
  uint32_t d[TSU_DESC_WORDS], out[7];
  tsu_record_t rec;
  if (!g_acc.tsu_present) { respond(CC_MBOX_CMD_GEMM, CC_MBOX_STS_NO_DEVICE, 0, 0); return; }
  for (unsigned i = 0; i < TSU_DESC_WORDS; i++) d[i] = REG32(g_cmd[1] + 4u * i);   /* host-built ABI v2 descriptor */
  int pred = tsu_check(&g_acc.tsu, d);
  int rc = tsu_run(d, &rec);
  for (int i = 0; i < 6; i++) out[i] = rec.raw[i];
  out[6] = (uint32_t)pred;
  uint32_t sts = rc ? CC_MBOX_STS_TIMEOUT : (rec.status == TSU_ST_OK ? CC_MBOX_STS_OK : CC_MBOX_STS_ACC_ERROR);
  if (!rc && rec.status != TSU_ST_OK) {
    ras_report(0, 0xB0000000u | rec.err);
    tsu_clear_error();                                  /* recover: the next command executes */
  }
  cprintf("[cmd] GEMM desc@%08x -> status=%u err=%02x tiles=%u cycles=%u\n", g_cmd[1], rec.status, rec.err,
          rec.tiles, rec.cycles);
  respond(CC_MBOX_CMD_GEMM, sts, out, 7);
}

static void cmd_vector(void) {
  hpc_cmd_t c;
  hpc_cpl_t cpl;
  if (!g_acc.vec_present) { respond(CC_MBOX_CMD_VECTOR_KERNEL, CC_MBOX_STS_NO_DEVICE, 0, 0); return; }
  for (int i = 0; i < 8; i++) c.w[i] = REG32(g_cmd[1] + 4u * i);               /* host-built tile descriptor */
  int rc = vec_run(&c, &cpl);
  uint32_t out[6] = {(uint32_t)cpl.tag | ((uint32_t)cpl.status << 8) | ((uint32_t)cpl.type << 12) |
                         ((uint32_t)cpl.detail << 16) | ((uint32_t)cpl.fflags << 20) | ((uint32_t)cpl.step << 25),
                     cpl.seq, cpl.count, cpl.result, cpl.err_addr, cpl.cycles};
  uint32_t sts = rc ? CC_MBOX_STS_TIMEOUT : (cpl.status == HPC_ST_OK ? CC_MBOX_STS_OK : CC_MBOX_STS_ACC_ERROR);
  if (!rc && cpl.status != HPC_ST_OK) {
    ras_report(0, 0xA0000000u | cpl.status);
    hpc_resume(CC_VECTOR_BASE);
  }
  cprintf("[cmd] VECTOR desc@%08x -> status=%u count=%u cycles=%u\n", g_cmd[1], cpl.status, cpl.count, cpl.cycles);
  respond(CC_MBOX_CMD_VECTOR_KERNEL, sts, out, 6);
}

static void cmd_dma(void) {
  int rc = dma_copy(g_cmd[1], g_cmd[2], g_cmd[3]);
  uint32_t out[2] = {(uint32_t)rc, DMA(CC_DMA_BYTES_DONE)};
  cprintf("[cmd] DMA %08x -> %08x len %u -> %d\n", g_cmd[1], g_cmd[2], g_cmd[3], rc);
  respond(CC_MBOX_CMD_DMA_COPY,
          rc == DMA_GUARD_DENIED ? CC_MBOX_STS_DENIED : (rc ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK), out, 2);
}

/* P28 secure-boot commands (firmware phase: the fuse-model rules are enforced by hardware) */
static void cmd_sb(uint32_t cmd) {
  uint32_t o[7];
  switch (cmd) {
    case CC_MBOX_CMD_SB_SVN_COMMIT: SEC(CC_SEC_SVN_COMMIT) = g_cmd[1]; break;
    case CC_MBOX_CMD_SB_REVOKE:     SEC(CC_SEC_REVOKE_SET) = g_cmd[1]; break;
    case CC_MBOX_CMD_SB_LC_ADVANCE: SEC(CC_SEC_LC_ADVANCE) = g_cmd[1]; break;
    default: break;
  }
  o[0] = SEC(CC_SEC_STATUS);
  o[1] = SEC(CC_SEC_LIFECYCLE);
  o[2] = SEC(CC_SEC_ACTIVE);
  o[3] = SEC(CC_SEC_MIN_SVN);
  o[4] = SEC(CC_SEC_REVOKED);
  o[5] = SEC(CC_SEC_OTP_STATUS);
  o[6] = SEC(CC_SEC_OTP_LC);
  uint32_t refused = (cmd != CC_MBOX_CMD_SB_STATUS) && (o[5] & 2u);
  cprintf("[cmd] SB %02x arg %08x -> otp_status=%02x min_svn=%u revoked=%x lc_fuse=%08x\n", cmd, g_cmd[1], o[5], o[3],
          o[4], o[6]);
  respond(cmd, refused ? CC_MBOX_STS_DENIED : CC_MBOX_STS_OK, o, 7);
}

int main(void) {
  boot_stage(CC_BOOT_STAGE_FW_INIT);
  reset_cause = SYSCTRL(CC_SYSCTRL_RESET_CAUSE);
  SYSCTRL(CC_SYSCTRL_RESET_CAUSE) = 0xFu;                 /* W1C: the next reset starts from a clean cause */
  uint32_t boot_status = SYSCTRL(CC_SYSCTRL_BOOT_STATUS);
  SYSCTRL(CC_SYSCTRL_FW_VERSION) = FW_VERSION;
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING;
  cprintf("\nSilicaFlux ControlCore firmware %x.%x  (RV32IM, misa=%08x mimpid=%08x)\n", FW_VERSION >> 16,
          FW_VERSION & 0xFFFFu, csr_read(misa), csr_read(mimpid));
  cprintf("map v%u.%u  reset cause=%x  boot status=%x  resets=%u\n", CC_MAP_VERSION >> 16, CC_MAP_VERSION & 0xFFFFu,
          reset_cause, boot_status, SYSCTRL(CC_SYSCTRL_RESET_COUNT));
  {
    uint32_t st = SEC(CC_SEC_STATUS), lc = SEC(CC_SEC_LIFECYCLE), act = SEC(CC_SEC_ACTIVE);
    cprintf("secure boot: AUTHENTICATED (state %u) key slot %u svn %u window %08x..%08x sha256 %08x%08x...\n",
            st & 0xFu, act & 3u, (act >> 8) & 0x3Fu, SEC(CC_SEC_EXEC_BASE), SEC(CC_SEC_EXEC_END),
            SEC(CC_SEC_DIGEST0), SEC(CC_SEC_DIGEST0 + 4u));
    cprintf("lifecycle %u%s%s, min svn %u, revoked %x\n", lc & 0xFu, (lc >> 9) & 1u ? " DEBUG OPEN (not secure)" : "",
            (lc >> 8) & 1u ? " RECOVERY" : "", SEC(CC_SEC_MIN_SVN), SEC(CC_SEC_REVOKED));
  }
  sb_platform_init();
  platform_init();

  /* watchdog-reset test: the previous run armed it and let the watchdog fire */
  if ((reset_cause & CC_RESET_CAUSE_WDT) && SYSCTRL(CC_SYSCTRL_SCRATCH0) == SCRATCH_WDT_MARK) {
    SYSCTRL(CC_SYSCTRL_SCRATCH0) = SCRATCH_WDT_PASS;
    cprintf("[T15 watchdog reset] observed: cause=WDT, early warnings before reset=%u, warm boot=%u\n",
            SYSCTRL(CC_SYSCTRL_SCRATCH2), (boot_status >> 8) & 1u);
  }

  boot_stage(CC_BOOT_STAGE_ACC_DISCOVERY);
  int acc = acc_discover();
  if (g_acc.vec_present)
    cprintf("vector tile : %u lanes, %u-bit, SPM %u KiB @%08x, queue %u, %u counters\n", g_acc.vec.lanes,
            8u * g_acc.vec.data_bytes, (1u << g_acc.vec.spm_log2) >> 10, g_acc.vec.spm_base, g_acc.vec.cmdq_depth,
            g_acc.vec.num_perf);
  else
    cprintf("vector tile : NOT PRESENT\n");
  if (g_acc.tsu_present)
    cprintf("tensor unit : ABI v%u, %ux%u array, TILE_K %u, K_MAX %u, window %08x..%08x, quant=%u dbuf=%u\n",
            g_acc.tsu.info & 0xFu, (g_acc.tsu.info >> 8) & 0xFFu, (g_acc.tsu.info >> 16) & 0xFFu,
            g_acc.tsu.caps & 0xFFFFu, g_acc.tsu.k_max, g_acc.tsu.mem_lo, g_acc.tsu.mem_last,
            (g_acc.tsu.info >> 24) & 1u, (g_acc.tsu.info >> 25) & 1u);
  else
    cprintf("tensor unit : NOT PRESENT\n");

  boot_stage(CC_BOOT_STAGE_SELF_TEST);
  int pf = post();
  cprintf("POST: %s\n", pf ? "FAIL" : "PASS");
  if (pf) g_tally.fails += (uint32_t)pf;

  /* P28: no firmware host lock any more -- the host filter is hardware (sb_access_policy) */
  boot_stage(CC_BOOT_STAGE_CMDPROC_READY);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING | CC_HOST_STATUS_CMDPROC_READY |
                                    (acc != 3 ? CC_HOST_STATUS_DEGRADED : 0u);
  boot_stage(CC_BOOT_STAGE_HOST_READY);
  uint32_t caps[6] = {(uint32_t)acc, g_acc.vec_present ? HPC_REG(CC_VECTOR_BASE, HPC_REG_CONFIG0) : 0u,
                      g_acc.tsu.info, reset_cause, FW_VERSION, SEC(CC_SEC_DIGEST0)};
  respond(CC_MBOX_CMD_NONE, pf ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK, caps, 6);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = SYSCTRL(CC_SYSCTRL_HOST_STATUS) | CC_HOST_STATUS_HOST_READY;
  cprintf("HOST READY\n");

  uint32_t done = 0;
  for (;;) {
    WAIT_UNTIL(g_cmd_pending != done, 0xFFFFFFFFu);
    if (g_cmd_pending == done) continue;
    done = g_cmd_pending;
    g_cmd_seq++;
    uint32_t cmd = g_cmd[0];
    switch (cmd) {
      case CC_MBOX_CMD_PING: {
        uint32_t o[2] = {g_cmd[1], FW_VERSION};
        respond(cmd, CC_MBOX_STS_OK, o, 2);
        break;
      }
      case CC_MBOX_CMD_RUN_SELFTEST: {
        uint32_t c0 = g_tally.checks;
        uint32_t f = selftest_run(g_cmd[1] ? g_cmd[1] : ST_ALL);
        uint32_t o[2] = {g_tally.checks - c0, f};
        boot_stage(CC_BOOT_STAGE_HOST_READY);
        respond(cmd, CC_MBOX_STS_OK, o, 2);
        break;
      }
      case CC_MBOX_CMD_GEMM: cmd_gemm(); break;
      case CC_MBOX_CMD_VECTOR_KERNEL: cmd_vector(); break;
      case CC_MBOX_CMD_DMA_COPY: cmd_dma(); break;
      case CC_MBOX_CMD_SB_STATUS:
      case CC_MBOX_CMD_SB_SVN_COMMIT:
      case CC_MBOX_CMD_SB_REVOKE:
      case CC_MBOX_CMD_SB_LC_ADVANCE: cmd_sb(cmd); break;
      case CC_MBOX_CMD_PERF_DUMP: {
        uint32_t o[1] = {perf_dump(g_cmd[1])};
        respond(cmd, CC_MBOX_STS_OK, o, 1);
        break;
      }
      case CC_MBOX_CMD_RAS_DUMP: {
        uint32_t o[7] = {RAS(CC_RAS_STATUS), RAS(CC_RAS_WARN_COUNT), RAS(CC_RAS_FATAL_COUNT), RAS(CC_RAS_FIRST_SRC),
                         RAS(CC_RAS_FIRST_ADDR), g_ras_warn_bits, g_ras_fatal_bits};
        respond(cmd, CC_MBOX_STS_OK, o, 7);
        break;
      }
      case CC_MBOX_CMD_SHUTDOWN: {
        uint32_t fails = g_tally.fails + g_cmd[1];        /* firmware self-test + host-side verdict */
        cprintf("SHUTDOWN: firmware checks=%u fails=%u, host-reported fails=%u -> %s\n", g_tally.checks,
                g_tally.fails, g_cmd[1], fails ? "FAIL" : "PASS");
        uint32_t o[2] = {g_tally.checks, g_tally.fails};
        respond(cmd, CC_MBOX_STS_OK, o, 2);
        boot_stage(CC_BOOT_STAGE_SHUTDOWN);
        SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0x80000000u | (fails ? 0x40000000u : 0u) | (fails & 0xFFFFu);
        break;
      }
      default:
        respond(cmd, CC_MBOX_STS_BAD_CMD, 0, 0);
        break;
    }
  }
}
