/* =============================================================================
 * SilicaFlux ControlCore firmware -- shared declarations
 * ===========================================================================*/
#ifndef FW_H
#define FW_H

#include "cc_hw.h"
#include "sb_manifest.h"
#define DMA_GUARD_DENIED 16                        /* dma_copy(): START refused by sb_dma_guard */
#define DMABUF __attribute__((section(".dmabuf"), aligned(4)))   /* the only DMEM the system DMA may touch */
extern uint32_t __dmabuf_start[], __dmabuf_end[];
void sb_platform_init(void);
#include "silicaflux_hpc.h"      /* HPC Module 08 tile driver (vendored, unmodified) */
#include "tsu_driver.h"          /* TENSORCORE 08 driver (vendored, unmodified)       */

#define FW_VERSION       0x00020000u
#define TICK_CYCLES      20000u            /* periodic timer tick (watchdog supervision, wait timeouts) */
#define WDT_PRESCALE_RUN 63u
#define WDT_LOAD_RUN     50000u            /* 64 * 50 000 = 3.2 M cycles without service -> reset */
#define WDT_EWI_RUN      5000u
#define TMO_DEFAULT      4000000u          /* cycles */

/* ---------------------------------------------------------------- libc subset */
void  *memcpy(void *d, const void *s, size_t n);
void  *memset(void *d, int c, size_t n);
int    memcmp(const void *a, const void *b, size_t n);

/* ---------------------------------------------------------------- console (host-visible DIAG FIFO) */
void   con_putc(char c);
void   con_puts(const char *s);
void   cprintf(const char *fmt, ...);

/* ---------------------------------------------------------------- traps */
typedef struct { uint32_t x[32]; uint32_t mepc; } trap_frame_t;
enum { EXP_SKIP = 0, EXP_RESUME_RA = 1 };
typedef struct { volatile uint32_t armed, mode, cause, epc, tval, count; } expect_t;
extern expect_t g_expect;
uint32_t probe_rd(uint32_t addr, uint32_t *val);   /* 0 = no trap, else mcause */
uint32_t probe_wr(uint32_t addr, uint32_t val);
uint32_t probe_wr8(uint32_t addr, uint8_t val);
void     expect_arm(uint32_t mode);
uint32_t expect_result(void);                     /* mcause of the trap taken, 0 = none */

/* ---------------------------------------------------------------- interrupts */
extern volatile uint32_t g_irq_log[32], g_irq_log_n, g_irq_count[16];
extern volatile uint32_t g_ticks, g_msi_count;
void     platform_init(void);
uint32_t cycles(void);
uint64_t mtime(void);
#define WAIT_UNTIL(cond, tmo) ({                                         \
    int __r = 0; uint32_t __t0 = cycles();                               \
    for (;;) {                                                           \
      csr_clear(mstatus, MSTATUS_MIE);                                   \
      if (cond) break;                                                   \
      if (cycles() - __t0 > (uint32_t)(tmo)) { __r = -1; break; }        \
      wfi();                                                             \
      csr_set(mstatus, MSTATUS_MIE);                                     \
    }                                                                    \
    csr_set(mstatus, MSTATUS_MIE);                                       \
    __r; })

/* ---------------------------------------------------------------- watchdog */
extern volatile uint32_t g_wdt_ewi, g_wdt_hang;
void wdt_service(void);

/* ---------------------------------------------------------------- system DMA */
extern volatile uint32_t g_dma_done, g_dma_status;
int  dma_start(uint32_t src, uint32_t dst, uint32_t len);
int  dma_wait(uint32_t tmo);                       /* 0 ok, -1 timeout, >0 DataFabric error code */
int  dma_copy(uint32_t src, uint32_t dst, uint32_t len);

/* ---------------------------------------------------------------- RAS */
extern volatile uint32_t g_ras_warn_bits, g_ras_fatal_bits, g_ras_warn_irqs, g_ras_fatal_irqs;
void ras_report(int fatal, uint32_t code);

/* ---------------------------------------------------------------- accelerators */
typedef struct {
  int        vec_present, tsu_present;
  hpc_info_t vec;
  tsu_dev_t  tsu;
  uint32_t   vec_tag;
  volatile uint32_t tsu_halted;
} acc_state_t;
extern acc_state_t g_acc;
int  acc_discover(void);                           /* returns bitmask: 1 vector, 2 tensor */
int  acc_reset(void);                              /* PMU reset of the accelerator domain + rediscovery */
int  vec_submit(const hpc_cmd_t *c);
int  vec_wait(hpc_cpl_t *cpl, uint32_t tmo);       /* completion by VECTOR interrupt */
int  vec_run(const hpc_cmd_t *c, hpc_cpl_t *cpl);
int  tsu_submit_irq(const uint32_t d[TSU_DESC_WORDS]);
int  tsu_wait_irq(tsu_record_t *r, uint32_t tmo);  /* completion by TENSOR interrupt */
int  tsu_run(const uint32_t d[TSU_DESC_WORDS], tsu_record_t *r);
uint32_t vec_pending(void);
uint32_t tsu_pending(void);

/* ---------------------------------------------------------------- host command processor */
extern volatile uint32_t g_cmd[8], g_cmd_pending, g_cmd_seq;

/* ---------------------------------------------------------------- self-test */
typedef struct { uint32_t checks, fails; } tally_t;
extern tally_t g_tally;
#define ST_IDENTITY  (1u << 0)
#define ST_MMIO      (1u << 1)
#define ST_EXCEPT    (1u << 2)
#define ST_TIMER     (1u << 3)
#define ST_INTC      (1u << 4)
#define ST_DMA       (1u << 5)
#define ST_VECTOR    (1u << 6)
#define ST_TENSOR    (1u << 7)
#define ST_CONCUR    (1u << 8)
#define ST_ERRORS    (1u << 9)
#define ST_RAS       (1u << 10)
#define ST_PERF      (1u << 11)
#define ST_WDT       (1u << 12)
#define ST_PMU       (1u << 13)
#define ST_SECURITY  (1u << 14)                    /* P28: secure boot / isolation (T16) */
#define ST_ALL       0x7FFFu
#define ST_WDT_RESET (1u << 31)                    /* not in ST_ALL: deliberately lets the watchdog reset the chip */
uint32_t selftest_run(uint32_t mask);
void     check(int ok, uint32_t id, uint32_t got, uint32_t exp);
/* each argument is evaluated exactly once (they often submit hardware commands) */
#define CHECK_EQ(id, got, exp) do { uint32_t __g = (uint32_t)(got), __e = (uint32_t)(exp); \
                                    check(__g == __e, (id), __g, __e); } while (0)
#define CHECK_TRUE(id, c)      do { int __c = !!(c); check(__c, (id), (uint32_t)__c, 1u); } while (0)

/* ---------------------------------------------------------------- telemetry */
uint32_t perf_dump(uint32_t dev_addr);             /* returns words written */

#define SCRATCH_WDT_MARK  0x57445430u              /* "WDT0": watchdog-reset test armed */
#define SCRATCH_WDT_PASS  0x57445450u              /* "WDTP": test observed the reset   */

#endif /* FW_H */
