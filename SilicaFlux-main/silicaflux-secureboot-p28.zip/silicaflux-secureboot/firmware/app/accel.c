/* =============================================================================
 * SilicaFlux ControlCore firmware -- accelerator orchestration
 *
 * Uses the REAL command ABIs through the vendored, unmodified drivers:
 *   vector tile  (HPC Module 08): 8-word descriptors, CPL_* records   silicaflux_hpc.c
 *   tensor unit  (TENSORCORE 08): 12-word GEMM descriptors (ABI v2)   tsu_driver.c
 * Completion is interrupt driven: the VECTOR / TENSOR interrupt handlers drain
 * every completion record into a ring and acknowledge (W1C) the unit's
 * interrupt status; vec_wait / tsu_wait_irq sleep (WFI) until a record arrives.
 * Discovery probes each register page with an expected-trap read, so an absent
 * or isolated accelerator is reported, not fatal.
 * ===========================================================================*/
#include "fw.h"

acc_state_t g_acc;

#define RING 16u
static hpc_cpl_t    vec_ring[RING];
static tsu_record_t tsu_ring[RING];
static volatile uint32_t vec_wr, vec_rd, tsu_wr, tsu_rd;

uint32_t vec_pending(void) { return vec_wr - vec_rd; }
uint32_t tsu_pending(void) { return tsu_wr - tsu_rd; }

void isr_vector(void) {
  hpc_cpl_t c;
  while (hpc_poll(CC_VECTOR_BASE, &c)) {
    if (vec_wr - vec_rd < RING) vec_ring[vec_wr % RING] = c;
    vec_wr++;
  }
  HPC_REG(CC_VECTOR_BASE, HPC_REG_IRQ_STATUS) = 7u;   /* W1C: acknowledge */
  (void)HPC_REG(CC_VECTOR_BASE, HPC_REG_IRQ_STATUS);    /* read back before the next claim */
}

void isr_tensor(void) {
  tsu_record_t r;
  while (tsu_poll(&g_acc.tsu, &r)) {
    if (tsu_wr - tsu_rd < RING) tsu_ring[tsu_wr % RING] = r;
    tsu_wr++;
  }
  TSU_WR32(TSU_R_INT_STATUS, 7u);                       /* W1C: acknowledge */
  (void)TSU_RD32(TSU_R_INT_STATUS);                     /* read back before the next claim */
}

int acc_discover(void) {
  uint32_t v;
  int mask = 0;
  uint32_t m = irq_save();
  vec_wr = vec_rd = tsu_wr = tsu_rd = 0;
  g_acc.vec_present = g_acc.tsu_present = 0;
  g_acc.tsu_halted = 0;
  /* vector tile: page must answer with the "SFHT" ID */
  if (probe_rd(CC_VECTOR_BASE + HPC_REG_ID, &v) == 0 && v == HPC_TILE_ID &&
      hpc_probe(CC_VECTOR_BASE, &g_acc.vec) == 0) {
    hpc_configure(CC_VECTOR_BASE, 1, 0);                 /* halt on error, counters running */
    HPC_REG(CC_VECTOR_BASE, HPC_REG_IRQ_STATUS) = 7u;
    HPC_REG(CC_VECTOR_BASE, HPC_REG_IRQ_EN) = 7u;        /* completion, error completion, halt */
    g_acc.vec_present = 1;
    mask |= 1;
  }
  /* tensor unit: "SFTC", ABI version 2 */
  if (probe_rd(TSU_BASE + TSU_R_ID, &v) == 0 && v == TSU_ID_VALUE && tsu_init(&g_acc.tsu) == 0) {
    TSU_WR32(TSU_R_INT_STATUS, 7u);
    TSU_WR32(TSU_R_INT_ENABLE, 1u << 2);                 /* DONE: any record */
    g_acc.tsu_present = 1;
    mask |= 2;
  }
  irq_restore(m);
  return mask;
}

/* Full reset of the accelerator domain through the PMU, then rediscovery.  The
 * PMU isolates the domain while the reset is applied (no access can reach it). */
int acc_reset(void) {
  uint32_t t0 = cycles();
  PMU(CC_PMU_ACC_CTRL) = 0x1u | 0x2u;                    /* CLK_EN, RST */
  while (!(PMU(CC_PMU_ACC_STATUS) & 0x2u)) if (cycles() - t0 > 100000u) return -1;
  PMU(CC_PMU_ACC_CTRL) = 0x1u;                           /* release */
  while (PMU(CC_PMU_ACC_STATUS) & 0x6u) if (cycles() - t0 > 200000u) return -2;
  /* the tensor-unit halt condition is gone: report it again from now on */
  RAS(CC_RAS_STATUS) = 0xFF00u;
  RAS(CC_RAS_FATAL_EN) = RAS(CC_RAS_FATAL_EN) | (1u << (CC_RAS_SRC_TSU_HALTED - 8));
  return acc_discover();
}

int vec_submit(const hpc_cmd_t *c) { return hpc_submit(CC_VECTOR_BASE, c); }

int vec_wait(hpc_cpl_t *cpl, uint32_t tmo) {
  if (WAIT_UNTIL(vec_wr != vec_rd, tmo)) return -1;
  *cpl = vec_ring[vec_rd % RING];
  vec_rd++;
  return 0;
}

int vec_run(const hpc_cmd_t *c, hpc_cpl_t *cpl) {
  if (vec_submit(c)) return -2;
  return vec_wait(cpl, TMO_DEFAULT);
}

int tsu_submit_irq(const uint32_t d[TSU_DESC_WORDS]) { return tsu_submit(&g_acc.tsu, d); }

int tsu_wait_irq(tsu_record_t *r, uint32_t tmo) {
  if (WAIT_UNTIL(tsu_wr != tsu_rd || g_acc.tsu_halted, tmo)) return TSU_ETIMEDOUT;
  if (tsu_wr == tsu_rd) return TSU_EHALTED;
  *r = tsu_ring[tsu_rd % RING];
  tsu_rd++;
  return 0;
}

int tsu_run(const uint32_t d[TSU_DESC_WORDS], tsu_record_t *r) {
  int rc = tsu_submit_irq(d);
  if (rc) return rc;
  return tsu_wait_irq(r, 20000000u);
}

/* Telemetry block for the host (PERF_DUMP): ControlCore counters, then the
 * tile's 24 and the tensor unit's 20 counters, each block preceded by a tag. */
uint32_t perf_dump(uint32_t dev_addr) {
  volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)dev_addr;
  uint32_t n = 0, ncc = PERF(CC_PERF_INFO) & 0xFFu;
  PERF(CC_PERF_CTRL) = 1u;                               /* freeze: consistent snapshot */
  p[n++] = 0x43435046u;                                  /* "FPCC" */
  p[n++] = PERF(CC_PERF_CYCLE_LO);
  p[n++] = PERF(CC_PERF_CYCLE_HI);
  p[n++] = ncc;
  for (uint32_t i = 0; i < ncc; i++) p[n++] = PERF_CNT(i);
  PERF(CC_PERF_CTRL) = 0u;
  p[n++] = 0x56435046u;                                  /* "FPCV" */
  p[n++] = g_acc.vec_present ? g_acc.vec.num_perf : 0u;
  if (g_acc.vec_present)
    for (uint32_t i = 0; i < g_acc.vec.num_perf; i++) p[n++] = hpc_perf_read(CC_VECTOR_BASE, i);
  p[n++] = 0x54435046u;                                  /* "FPCT" */
  p[n++] = g_acc.tsu_present ? (uint32_t)TSU_NUM_PC : 0u;
  if (g_acc.tsu_present)
    for (int i = 0; i < (int)TSU_NUM_PC; i++) p[n++] = tsu_counter(i);
  return n;
}
