package com.example.data

import com.example.model.*
import kotlin.math.roundToInt

object SyntheticDataRepository {

    val LOCATIONS = listOf(
        LocationNode("OAK", "Oakland", "Port of Oakland Rail Terminal", "OAK-01", "94607", RegionZone.NORTHERN_CA, 37.8044, -122.2712, listOf("BNSF", "UP"), isIntermodalTerminal = true, isPort = true),
        LocationNode("SAC", "Sacramento", "Sacramento Regional Freight Yard", "SAC-02", "95814", RegionZone.NORTHERN_CA, 38.5816, -121.4944, listOf("UP", "Sierra Northern")),
        LocationNode("ROS", "Roseville", "J.R. Davis Classification Yard", "ROS-03", "95678", RegionZone.NORTHERN_CA, 38.7525, -121.2880, listOf("UP")),
        LocationNode("STK", "Stockton", "Stockton Intermodal Facility", "STK-04", "95202", RegionZone.NORTHERN_CA, 37.9577, -121.2908, listOf("BNSF", "UP", "CCT"), isIntermodalTerminal = true),
        LocationNode("LTH", "Lathrop", "Lathrop Intermodal Gateway", "LTH-05", "95330", RegionZone.NORTHERN_CA, 37.8227, -121.2766, listOf("UP"), isIntermodalTerminal = true),
        LocationNode("MOD", "Modesto", "Modesto Industrial Rail Hub", "MOD-06", "95354", RegionZone.CENTRAL_VALLEY, 37.6393, -120.9970, listOf("UP", "M&ET")),
        LocationNode("MRC", "Merced", "Merced Valley Freight Yard", "MRC-07", "95340", RegionZone.CENTRAL_VALLEY, 37.3022, -120.4830, listOf("BNSF", "UP")),
        LocationNode("FAT", "Fresno", "Fresno Main Freight Yard", "FAT-08", "93721", RegionZone.CENTRAL_VALLEY, 36.7468, -119.7726, listOf("BNSF", "UP", "SJVR")),
        LocationNode("BFL", "Bakersfield", "Bakersfield Freight Junction", "BFL-09", "93301", RegionZone.CENTRAL_VALLEY, 35.3733, -119.0187, listOf("BNSF", "UP", "SJVR")),
        LocationNode("LAX", "Los Angeles", "LA Hobart Intermodal Yard", "LAX-10", "90023", RegionZone.SOUTHERN_CA, 34.0522, -118.2437, listOf("BNSF", "UP"), isIntermodalTerminal = true),
        LocationNode("LGB", "Long Beach", "Port of Long Beach On-Dock Rail", "LGB-11", "90802", RegionZone.SOUTHERN_CA, 33.7701, -118.1937, listOf("BNSF", "UP", "PHL"), isIntermodalTerminal = true, isPort = true),
        LocationNode("SBD", "San Bernardino", "San Bernardino Intermodal Hub", "SBD-12", "92408", RegionZone.SOUTHERN_CA, 34.1083, -117.2898, listOf("BNSF"), isIntermodalTerminal = true),
        LocationNode("RIV", "Riverside", "Riverside Industrial Rail Center", "RIV-13", "92501", RegionZone.SOUTHERN_CA, 33.9806, -117.3755, listOf("UP", "BNSF")),
        LocationNode("COL", "Colton", "Colton Crossing & Classification Yard", "COL-14", "92324", RegionZone.SOUTHERN_CA, 34.0739, -117.3137, listOf("UP")),
        LocationNode("BAR", "Barstow", "Barstow Classification Yard", "BAR-15", "92311", RegionZone.SOUTHERN_CA, 34.8958, -117.0173, listOf("BNSF")),
        LocationNode("YER", "Yermo", "Yermo Rail Gateway", "YER-16", "92398", RegionZone.SOUTHERN_CA, 34.9056, -116.8206, listOf("UP")),
        LocationNode("SNS", "Salinas", "Salinas Valley Agriculture Yard", "SNS-17", "93901", RegionZone.CENTRAL_COAST, 36.6777, -121.6555, listOf("UP")),
        LocationNode("MRY", "Monterey", "Monterey Bay Industrial Siding", "MRY-18", "93940", RegionZone.CENTRAL_COAST, 36.6002, -121.8947, listOf("UP")),
        LocationNode("SBA", "Santa Barbara", "Santa Barbara Freight Junction", "SBA-19", "93101", RegionZone.CENTRAL_COAST, 34.4208, -119.6982, listOf("UP")),
        LocationNode("SAN", "San Diego", "Port of San Diego Freight Hub", "SAN-20", "92101", RegionZone.BORDER_REGION, 32.7157, -117.1611, listOf("BNSF", "SDIV"), isPort = true),
        LocationNode("IMP", "Imperial Valley", "El Centro & Imperial Agri Hub", "IMP-21", "92243", RegionZone.BORDER_REGION, 32.7920, -115.5631, listOf("UP"))
    )

    val COMMODITIES = listOf(
        Commodity("3241", "Cement", "Building Materials", EquipmentCategory.COVERED_HOPPER, 100.0, 3.85),
        Commodity("1441", "Aggregates & Gravel", "Building Materials", EquipmentCategory.GONDOLA, 105.0, 3.20),
        Commodity("3312", "Steel & Primary Metals", "Industrial", EquipmentCategory.FLATCAR, 90.0, 4.10),
        Commodity("2812", "Chemicals & Caustic Soda", "Chemicals", EquipmentCategory.TANK_CAR, 95.0, 5.20),
        Commodity("0113", "Grain & Agricultural Products", "Agriculture", EquipmentCategory.COVERED_HOPPER, 98.0, 3.50),
        Commodity("2421", "Lumber & Wood", "Forest Products", EquipmentCategory.BOXCAR, 85.0, 3.90),
        Commodity("2911", "Petroleum Products", "Energy", EquipmentCategory.TANK_CAR, 92.0, 4.90),
        Commodity("2033", "Canned Food & Beverages", "Consumer Goods", EquipmentCategory.REFRIGERATED, 75.0, 4.25),
        Commodity("1455", "Clay & Industrial Minerals", "Minerals", EquipmentCategory.COVERED_HOPPER, 100.0, 3.40),
        Commodity("4211", "Intermodal Containerized Freight", "Intermodal", EquipmentCategory.INTERMODAL_53, 22.0, 2.80)
    )

    val PORTS = listOf(
        PortInfo("Port of Los Angeles", 3_850_000L, 10_600_000L, 88.5, listOf("BNSF Railway", "Union Pacific Railroad", "Pacific Harbor Line"), 280.0, 36.4, "Moderate"),
        PortInfo("Port of Long Beach", 3_420_000L, 9_800_000L, 85.0, listOf("BNSF Railway", "Union Pacific Railroad", "Pacific Harbor Line"), 260.0, 34.2, "Moderate"),
        PortInfo("Port of Oakland", 920_000L, 2_450_000L, 78.2, listOf("BNSF Railway", "Union Pacific Railroad"), 220.0, 28.5, "Low"),
        PortInfo("Port of Hueneme", 140_000L, 380_000L, 62.0, listOf("Ventura County Railroad", "Union Pacific Railroad"), 310.0, 22.0, "Low")
    )

    val MARKET_BENCHMARKS = listOf(
        MarketBenchmark("Cement (STCC 3241)", "$ / Ton", 43.10, +2.4, +5.1, +8.2, "$41.20 - $46.80"),
        MarketBenchmark("Steel (STCC 3312)", "$ / Ton", 58.40, -1.2, +1.8, +4.5, "$54.00 - $63.20"),
        MarketBenchmark("Grain (STCC 0113)", "$ / Ton", 36.20, +0.8, -2.1, +3.1, "$33.80 - $39.50"),
        MarketBenchmark("Chemicals (STCC 2812)", "$ / Ton", 72.80, +3.1, +6.4, +11.0, "$68.50 - $78.00"),
        MarketBenchmark("Lumber (STCC 2421)", "$ / Car", 4120.0, +1.5, +3.2, +6.8, "$3850 - $4400"),
        MarketBenchmark("Intermodal Container", "$ / Container", 2280.0, -2.0, -0.5, +2.4, "$2100 - $2500")
    )

    val DEMO_CUSTOMER = CustomerProfile(
        customerId = "CUST-CIM01",
        name = "California Industrial Materials Inc.",
        annualVolumeTons = 4200000.0,
        annualSpendMillion = 184.7,
        activeLanesCount = 42,
        activeContractsCount = 7,
        avgRatePerTon = 43.10,
        onTimeServicePercent = 91.8
    )

    val DEMURRAGE = DemurrageExposure(
        carsOnDemurrage = 48,
        currentExposureDollars = 31480.0,
        forecastExposureDollars = 47200.0,
        averageDwellHours = 31.4,
        freeTimeHours = 24.0,
        dailyRatePerCar = 120.0
    )

    val DATA_HEALTH_CHECKS = listOf(
        DataHealthCheck("Missing Origin / Destination Mapping", 0, "OK", "All 1,842 active rates mapped to valid rail nodes."),
        DataHealthCheck("Expired Customer Contracts", 2, "MEDIUM", "2 contracts expiring within 14 days require renewal."),
        DataHealthCheck("Inconsistent STCC Code Classification", 0, "OK", "Commodities aligned with STCC 4-digit standard."),
        DataHealthCheck("Unusual Fuel Surcharge Deviations", 1, "LOW", "1 short-line formula exceeds 15% revenue threshold."),
        DataHealthCheck("Negative or Zero Price Anomalies", 0, "OK", "All rate tables passed non-zero validation.")
    )

    val AUDIT_LOGS = mutableListOf(
        AuditLog("AUD-9821", "J. SMITH", "2026-10-01 14:42:17", "RATE CHANGE", "$3,620 / CAR", "$3,842 / CAR", "2026 CONTRACT RENEWAL", "M. WILSON"),
        AuditLog("AUD-9818", "A. DAVIS", "2026-09-28 09:15:02", "FUEL FORMULA", "DOE Index Base $3.50", "DOE Index Base $3.75", "Q4 FUEL INDEX REBALANCING", "M. WILSON"),
        AuditLog("AUD-9810", "R. GARCIA", "2026-09-25 16:30:45", "CONTRACT NEW", "N/A", "YF-2026-0418", "NEW CEMENT LANE OAK->SBD", "E. CHEN")
    )

    val CONTRACTS = mutableListOf(
        Contract("YF-2026-0418", "California Industrial Materials Inc.", "BNSF Railway", "Cement", "3241", "Oakland", "San Bernardino", 3842.0, "2026-01-01", "2026-12-31", "Formula A (DOE Fuel Index)", "ACTIVE", 250000.0, 18400000.0),
        Contract("UP-2026-1102", "Pacific Steel Supply", "Union Pacific Railroad", "Steel & Primary Metals", "3312", "Los Angeles", "Roseville", 4118.0, "2026-02-01", "2026-12-31", "Formula B (Mileage Base)", "ACTIVE", 180000.0, 14200000.0),
        Contract("CCT-2026-009", "Central Valley Agriculture Co.", "California Northern RR", "Grain & Agricultural Products", "0113", "Stockton", "Bakersfield", 3420.0, "2025-10-15", "2026-10-15", "Formula A (DOE Fuel Index)", "ACTIVE", 310000.0, 11200000.0),
        Contract("BNSF-2026-881", "CalChemicals Corp.", "BNSF Railway", "Chemicals & Caustic Soda", "2812", "Long Beach", "Modesto", 4980.0, "2026-03-01", "2027-02-28", "Formula C (Percentage of Revenue)", "ACTIVE", 95000.0, 9500000.0)
    )

    val INITIAL_SHIPMENTS = mutableListOf(
        Shipment("CS-840192", "California Industrial Materials", "Oakland", "San Bernardino", "Cement", EquipmentCategory.COVERED_HOPPER, 50, ShipmentStatus.IN_TRANSIT, "18:40 Today", "Barstow Yard", "BNSF Railway", 3842.0, 192100.0, "10 mins ago"),
        Shipment("CS-840193", "Pacific Steel Supply", "Los Angeles", "Roseville", "Steel", EquipmentCategory.FLATCAR, 35, ShipmentStatus.INTERCHANGE, "Tomorrow 08:30", "Fresno Junction", "Union Pacific", 4118.0, 144130.0, "25 mins ago"),
        Shipment("CS-840194", "Central Valley Ag", "Stockton", "Bakersfield", "Grain", EquipmentCategory.COVERED_HOPPER, 80, ShipmentStatus.LOADING, "Tomorrow 14:00", "Stockton Elevator", "BNSF Railway", 3420.0, 273600.0, "1 hour ago"),
        Shipment("CS-840195", "CalChemicals Corp", "Long Beach", "Modesto", "Caustic Soda", EquipmentCategory.TANK_CAR, 20, ShipmentStatus.DEPARTED, "Today 22:15", "Colton Yard", "Union Pacific", 4980.0, 99600.0, "5 mins ago")
    )

    fun calculateFreightPrice(
        origin: LocationNode,
        destination: LocationNode,
        commodity: Commodity,
        carsCount: Int,
        equipment: EquipmentCategory,
        service: ServiceType,
        scenario: ScenarioSettings = ScenarioSettings()
    ): PriceBreakdown {
        // Distance calculation (Haversine approx in miles)
        val latDiff = destination.latitude - origin.latitude
        val lonDiff = destination.longitude - origin.longitude
        val miles = (Math.sqrt(latDiff * latDiff + lonDiff * lonDiff) * 62.5).coerceAtLeast(45.0)

        // Service factor
        val serviceFactor = when(service) {
            ServiceType.UNIT_TRAIN -> 0.85
            ServiceType.SHUTTLE -> 0.88
            ServiceType.CARLOAD -> 1.0
            ServiceType.MANIFEST -> 1.05
            ServiceType.INTERMODAL -> 0.72
            ServiceType.PRIVATE_EQUIPMENT -> 0.92
        }

        val baseLinehaul = miles * commodity.baseRatePerCarMile * serviceFactor * scenario.volumeMultiplier.toDouble()
        val fuelSurcharge = baseLinehaul * 0.127 * scenario.fuelIndexMultiplier.toDouble()
        val accessorials = 120.0 * scenario.drayageCostMultiplier.toDouble()
        val terminal = 180.0 * scenario.terminalCostMultiplier.toDouble()
        val storage = 0.0
        val demurrageReserve = (80.0 + scenario.dwellHoursAdjustment * 3.5).coerceAtLeast(0.0)

        val totalPerCar = baseLinehaul + fuelSurcharge + accessorials + terminal + storage + demurrageReserve
        val loadTons = if (equipment.code.startsWith("IN")) 22.0 else commodity.typicalLoadTonsPerCar
        val totalPerTon = totalPerCar / loadTons

        val totalLanded = (totalPerCar * carsCount) + (if (service == ServiceType.INTERMODAL) 350.0 * carsCount else 150.0 * carsCount)

        return PriceBreakdown(
            linehaulPerCar = (baseLinehaul * 100).roundToInt() / 100.0,
            fuelSurchargePerCar = (fuelSurcharge * 100).roundToInt() / 100.0,
            accessorialsPerCar = (accessorials * 100).roundToInt() / 100.0,
            terminalHandlingPerCar = (terminal * 100).roundToInt() / 100.0,
            storagePerCar = storage,
            demurrageReservePerCar = (demurrageReserve * 100).roundToInt() / 100.0,
            totalPerCar = (totalPerCar * 100).roundToInt() / 100.0,
            totalPerTon = (totalPerTon * 100).roundToInt() / 100.0,
            totalLandedCost = (totalLanded * 100).roundToInt() / 100.0,
            totalMiles = (miles * 10).roundToInt() / 10.0
        )
    }

    fun getCarrierOptions(
        origin: LocationNode,
        destination: LocationNode,
        commodity: Commodity,
        equipment: EquipmentCategory,
        baseBreakdown: PriceBreakdown
    ): List<CarrierQuoteOption> {
        val rate = baseBreakdown.totalPerCar
        val tons = commodity.typicalLoadTonsPerCar
        val transitBase = (baseBreakdown.totalMiles / 12.0 + 16).roundToInt()

        return listOf(
            CarrierQuoteOption(
                carrierName = "BNSF Railway",
                carrierCode = "BNSF",
                serviceType = ServiceType.CARLOAD,
                ratePerCar = rate,
                ratePerTon = (rate / tons * 100).roundToInt() / 100.0,
                transitTimeHours = transitBase,
                equipmentCategory = equipment,
                confidence = "High",
                emissionsKgCo2 = (baseBreakdown.totalMiles * 1.85).roundToInt().toDouble(),
                reliabilityPercent = 93.4,
                interlineRoute = "${origin.name} (BNSF) → ${destination.name}"
            ),
            CarrierQuoteOption(
                carrierName = "Union Pacific Railroad",
                carrierCode = "UP",
                serviceType = ServiceType.CARLOAD,
                ratePerCar = ((rate * 1.02) * 100).roundToInt() / 100.0,
                ratePerTon = (((rate * 1.02) / tons) * 100).roundToInt() / 100.0,
                transitTimeHours = transitBase + 4,
                equipmentCategory = equipment,
                confidence = "Medium",
                emissionsKgCo2 = (baseBreakdown.totalMiles * 1.92).roundToInt().toDouble(),
                reliabilityPercent = 90.8,
                interlineRoute = "${origin.name} (UP) → Colton Yard → ${destination.name}"
            ),
            CarrierQuoteOption(
                carrierName = "California Interline Joint Service",
                carrierCode = "INTERLINE",
                serviceType = ServiceType.MANIFEST,
                ratePerCar = ((rate * 1.085) * 100).roundToInt() / 100.0,
                ratePerTon = (((rate * 1.085) / tons) * 100).roundToInt() / 100.0,
                transitTimeHours = transitBase + 11,
                equipmentCategory = equipment,
                confidence = "Low",
                emissionsKgCo2 = (baseBreakdown.totalMiles * 2.10).roundToInt().toDouble(),
                reliabilityPercent = 86.2,
                interlineRoute = "${origin.name} → Shortline Switch → Class I Trunk → ${destination.name}"
            )
        )
    }

    fun getEquipmentList(): List<EquipmentItem> {
        return listOf(
            EquipmentItem("BNSF-41802", EquipmentCategory.COVERED_HOPPER, "BNSF", 100.0, "Barstow Yard", "Loaded", 12.4, 31.0, 24.5),
            EquipmentItem("UP-88102", EquipmentCategory.GONDOLA, "UP", 105.0, "Fresno Siding", "Empty", 14.2, 38.5, 32.0),
            EquipmentItem("TTX-99210", EquipmentCategory.FLATCAR, "TTX", 90.0, "Commerce Yard", "Loaded", 10.8, 22.0, 18.0),
            EquipmentItem("CIMX-1002", EquipmentCategory.COVERED_HOPPER, "Private", 100.0, "Oakland Plant", "Maintenance", 18.0, 48.0, 12.0),
            EquipmentItem("UTLX-4412", EquipmentCategory.TANK_CAR, "Private", 95.0, "Modesto Depot", "Loaded", 15.0, 29.0, 20.0)
        )
    }
}
