package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ScenarioSettings
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@Composable
fun ScenarioScreen(
    uiState: CalStrikeUiState,
    onScenarioChange: (ScenarioSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val settings = uiState.scenarioSettings

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "COMMERCIAL WHAT-IF SCENARIO & PROCUREMENT LAB",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Adjust Fuel Surcharges, Volume, Dwell & Terminal Costs to simulate spend impact",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 36 — SCENARIO LAB Sliders
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "SCENARIO SLIDERS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBright)

                // Fuel Multiplier
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Diesel Fuel Index Multiplier", fontSize = 11.sp, color = Color.White)
                        Text("${String.format("%.1f", settings.fuelIndexMultiplier * 100)}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                    }
                    Slider(
                        value = settings.fuelIndexMultiplier,
                        onValueChange = { onScenarioChange(settings.copy(fuelIndexMultiplier = it)) },
                        valueRange = 0.8f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = AmberBright, activeTrackColor = AmberBright)
                    )
                }

                // Volume Multiplier
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Volume Commitment Scale", fontSize = 11.sp, color = Color.White)
                        Text("${String.format("%.1f", settings.volumeMultiplier * 100)}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyanMap)
                    }
                    Slider(
                        value = settings.volumeMultiplier,
                        onValueChange = { onScenarioChange(settings.copy(volumeMultiplier = it)) },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = CyanMap, activeTrackColor = CyanMap)
                    )
                }

                // Dwell Hours Adjustment
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Terminal Dwell Adjustment", fontSize = 11.sp, color = Color.White)
                        Text("${if (settings.dwellHoursAdjustment >= 0) "+" else ""}${settings.dwellHoursAdjustment} hrs", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = YellowWarn)
                    }
                    Slider(
                        value = settings.dwellHoursAdjustment.toFloat(),
                        onValueChange = { onScenarioChange(settings.copy(dwellHoursAdjustment = it.toInt())) },
                        valueRange = -12f..24f,
                        colors = SliderDefaults.colors(thumbColor = YellowWarn, activeTrackColor = YellowWarn)
                    )
                }
            }
        }

        // 33 — RAIL VS TRUCK Comparison
        uiState.calculatedBreakdown?.let { breakdown ->
            val railTotal = breakdown.totalLandedCost
            val truckTotal = railTotal * 1.34 // Truck typically 30-40% more expensive for heavy bulk

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "RAIL VS TRUCK MODE COMPARISON", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            color = NavyDark,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("RAIL FREIGHT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GreenSuccess)
                                Text("$${String.format("%,.0f", railTotal)}", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text("50 Cars (5,000 tons)", fontSize = 9.sp, color = TextSecondaryDark)
                                Text("CO2: ~9.2 tonnes", fontSize = 9.sp, color = TextSecondaryDark)
                            }
                        }

                        Surface(
                            color = NavyDark,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("OVER-THE-ROAD TRUCK", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RedDanger)
                                Text("$${String.format("%,.0f", truckTotal)}", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text("200 Trucks required", fontSize = 9.sp, color = TextSecondaryDark)
                                Text("CO2: ~34.8 tonnes", fontSize = 9.sp, color = TextSecondaryDark)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Rail achieves a $${String.format("%,.0f", truckTotal - railTotal)} (34%) cost advantage and 73% lower CO2 emissions for this shipment.",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = GreenSuccess
                    )
                }
            }
        }
    }
}
