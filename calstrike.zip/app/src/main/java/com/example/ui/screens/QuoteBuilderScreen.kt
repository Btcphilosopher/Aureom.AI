package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@Composable
fun QuoteBuilderScreen(
    uiState: CalStrikeUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "COMMERCIAL FREIGHT QUOTATION BUILDER & INVOICING",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "PDF-style Quotation Generator & Converted Freight Invoices",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 22 — COMMERCIAL QUOTE BUILDER Preview
        val quote = uiState.activeQuote
        if (quote != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "CALSTRIKE FREIGHT QUOTATION", fontSize = 14.sp, fontWeight = FontWeight.Black, color = AmberBright)
                        Text(text = "QUOTE ID: ${quote.quoteId}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Divider(color = BorderDark, modifier = Modifier.padding(vertical = 10.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        QuoteDetailRow("CUSTOMER", quote.customerName)
                        QuoteDetailRow("LANE", "${quote.origin.name} → ${quote.destination.name}")
                        QuoteDetailRow("COMMODITY", "${quote.commodity.name} (STCC ${quote.commodity.stccCode})")
                        QuoteDetailRow("CONSIST", "${quote.shipmentCars} Cars • ${quote.equipment.label}")
                        QuoteDetailRow("CARRIER & SERVICE", "${quote.carrierName} • ${quote.serviceType.label}")
                        QuoteDetailRow("QUOTED RATE / CAR", "$${String.format("%,.0f", quote.breakdown.totalPerCar)} / CAR")
                        QuoteDetailRow("EFFECTIVE RATE / TON", "$${String.format("%.2f", quote.breakdown.totalPerTon)} / TON")
                        QuoteDetailRow("TOTAL LANDED COST", "$${String.format("%,.0f", quote.breakdown.totalLandedCost)}")
                        QuoteDetailRow("VALIDITY PERIOD", "${quote.validityDays} DAYS FROM ${quote.createdDate}")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "STATUS: ${quote.status} • SUBJECT TO RAILROAD CONTRACT TERMS & FUEL SURCHARGE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = GreenSuccess,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }

        // 55 — INVOICING Table
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "GENERATED FREIGHT INVOICES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                Spacer(modifier = Modifier.height(8.dp))

                if (uiState.invoicesList.isEmpty()) {
                    Text("No invoices generated yet. Accept a quote to generate invoice.", fontSize = 11.sp, color = TextSecondaryDark)
                } else {
                    uiState.invoicesList.forEach { inv ->
                        Surface(
                            color = NavyDark,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("${inv.invoiceId} • ${inv.shipmentId}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("${inv.customerName} • ${inv.commodityName}", fontSize = 10.sp, color = TextSecondaryDark)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("$${String.format("%,.0f", inv.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GreenSuccess)
                                    Surface(color = YellowWarn, shape = RoundedCornerShape(4.dp)) {
                                        Text(inv.paymentStatus, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuoteDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, color = TextSecondaryDark)
        Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
