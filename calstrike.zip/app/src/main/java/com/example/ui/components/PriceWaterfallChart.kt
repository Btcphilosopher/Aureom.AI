package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PriceBreakdown
import com.example.ui.theme.*

@Composable
fun PriceWaterfallChart(
    breakdown: PriceBreakdown,
    carsCount: Int,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "COMMERCIAL PRICE WATERFALL",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = AmberBright,
                letterSpacing = 1.sp
            )
            Text(
                text = "Landed Rail Freight Cost Breakdown ($ / car & total)",
                fontSize = 10.sp,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(12.dp))

            val items = listOf(
                Pair("Linehaul", breakdown.linehaulPerCar),
                Pair("Fuel", breakdown.fuelSurchargePerCar),
                Pair("Terminal", breakdown.terminalHandlingPerCar),
                Pair("Accessorial", breakdown.accessorialsPerCar),
                Pair("Demurrage", breakdown.demurrageReservePerCar),
                Pair("TOTAL/CAR", breakdown.totalPerCar)
            )

            val maxValue = breakdown.totalPerCar.coerceAtLeast(1.0)

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items.forEach { (label, value) ->
                    val isTotal = label.startsWith("TOTAL")
                    val barRatio = (value / maxValue).coerceIn(0.05, 1.0).toFloat()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isTotal) FontWeight.Bold else FontWeight.Medium,
                            color = if (isTotal) AmberBright else Color.White,
                            modifier = Modifier.width(85.dp)
                        )

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp)
                                .background(NavyDark, RoundedCornerShape(4.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(barRatio)
                                    .background(
                                        when {
                                            isTotal -> AmberBright
                                            label == "Linehaul" -> CyanMap
                                            label == "Fuel" -> YellowWarn
                                            else -> SteelHeader
                                        },
                                        RoundedCornerShape(4.dp)
                                    )
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "$${String.format("%,.0f", value)}",
                            fontSize = 11.sp,
                            fontWeight = if (isTotal) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (isTotal) AmberBright else Color.White,
                            modifier = Modifier.width(70.dp)
                        )
                    }
                }
            }

            Divider(
                color = BorderDark,
                modifier = Modifier.padding(vertical = 10.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "TOTAL LANDED FREIGHT SPEND", fontSize = 10.sp, color = TextSecondaryDark)
                    Text(
                        text = "$${String.format("%,.2f", breakdown.totalLandedCost)}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = GreenSuccess
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "EFFECTIVE RATE / TON", fontSize = 10.sp, color = TextSecondaryDark)
                    Text(
                        text = "$${String.format("%.2f", breakdown.totalPerTon)} / TON",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
