package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.NavTab

@Composable
fun NavigationTabs(
    selectedTab: NavTab,
    onTabSelected: (NavTab) -> Unit
) {
    val scrollState = rememberScrollState()

    Surface(
        color = NavyDark,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavTab.entries.forEach { tab ->
                val isSelected = tab == selectedTab
                val icon = getIconForTab(tab)

                Surface(
                    onClick = { onTabSelected(tab) },
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected) AmberBright else NavySurface,
                    contentColor = if (isSelected) Color.White else TextSecondaryDark,
                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = tab.title,
                            modifier = Modifier.size(15.dp),
                            tint = if (isSelected) Color.White else TextSecondaryDark
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = tab.title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    }
}

private fun getIconForTab(tab: NavTab): ImageVector {
    return when(tab) {
        NavTab.OVERVIEW -> Icons.Default.Dashboard
        NavTab.PRICE -> Icons.Default.AttachMoney
        NavTab.ROUTES -> Icons.Default.Map
        NavTab.MARKET -> Icons.Default.TrendingUp
        NavTab.CONTRACTS -> Icons.Default.Description
        NavTab.SHIPMENTS -> Icons.Default.LocalShipping
        NavTab.EQUIPMENT -> Icons.Default.Train
        NavTab.PORTS -> Icons.Default.Anchor
        NavTab.CUSTOMERS -> Icons.Default.Business
        NavTab.CARRIERS -> Icons.Default.DirectionsRailway
        NavTab.ANALYTICS -> Icons.Default.Assessment
        NavTab.FORECAST -> Icons.Default.ShowChart
        NavTab.SCENARIO -> Icons.Default.Science
        NavTab.PROCUREMENT -> Icons.Default.ShoppingBag
        NavTab.DEMURRAGE -> Icons.Default.Timer
        NavTab.QUOTE_BUILDER -> Icons.Default.ReceiptLong
        NavTab.DATA_AUDIT -> Icons.Default.FactCheck
    }
}
