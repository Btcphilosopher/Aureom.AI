package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.ui.theme.*

@Composable
fun PortsScreen(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "CALIFORNIA PORT GATEWAY & INTERMODAL ANALYSIS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Port of LA, Long Beach, Oakland & Hueneme On-Dock Rail Connections & Dwell",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 11 — PORTS List
        SyntheticDataRepository.PORTS.forEach { port ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = port.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                        Surface(
                            color = if (port.congestionLevel == "Low") GreenSuccess else YellowWarn,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "${port.congestionLevel} Congestion",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            PortMetricRow("ANNUAL RAIL VOLUME", "${String.format("%,d", port.annualRailVolumeTeu)} TEUs")
                            PortMetricRow("TOTAL CONTAINER VOLUME", "${String.format("%,d", port.containerVolumeTeu)} TEUs")
                            PortMetricRow("INTERMODAL CAPACITY UTILIZATION", "${port.intermodalCapacityPercent}%")
                            PortMetricRow("AVERAGE CONTAINER DWELL", "${port.avgDwellHours} hours")
                            PortMetricRow("AVERAGE ORIGIN DRAYAGE COST", "$${port.avgDrayageCost.toInt()} / container")
                            PortMetricRow("RAIL CONNECTIONS", port.railConnections.joinToString(", "))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PortMetricRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, color = TextSecondaryDark)
        Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
