package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.ui.theme.*

@Composable
fun DemurrageScreen(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()
    val dem = SyntheticDataRepository.DEMURRAGE
    var dwellSimHrs by remember { mutableStateOf(31.4f) }

    val simExposure = (dem.carsOnDemurrage * (dwellSimHrs.toDouble() - dem.freeTimeHours).coerceAtLeast(0.0) / 24.0 * dem.dailyRatePerCar * 10)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ENTERPRISE DEMURRAGE & TRACK STORAGE EXPOSURE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Free Time Calendar, Yard Hold Time, Daily Penalty Rates & Unloading Simulations",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 17 — DEMURRAGE Dashboard Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("CARS ON DEMURRAGE", fontSize = 10.sp, color = TextSecondaryDark)
                    Text("${dem.carsOnDemurrage} Cars", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = RedDanger)
                    Text("Free time: ${dem.freeTimeHours.toInt()}h", fontSize = 9.sp, color = TextSecondaryDark)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("CURRENT EXPOSURE", fontSize = 10.sp, color = TextSecondaryDark)
                    Text("$${String.format("%,.0f", dem.currentExposureDollars)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                    Text("Rate: $120/car/day", fontSize = 9.sp, color = TextSecondaryDark)
                }
            }
        }

        // Demurrage Dwell Simulator
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("DEMURRAGE SIMULATION: UNLOADING DWELL ADJUSTMENT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Simulated Average Unloading Dwell: ${String.format("%.1f", dwellSimHrs)} hours", fontSize = 11.sp, color = Color.White)
                Slider(
                    value = dwellSimHrs,
                    onValueChange = { dwellSimHrs = it },
                    valueRange = 12f..60f,
                    colors = SliderDefaults.colors(thumbColor = AmberBright, activeTrackColor = AmberBright)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Simulated Exposure:", fontSize = 11.sp, color = TextSecondaryDark)
                    Text("$${String.format("%,.0f", simExposure)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (simExposure < dem.currentExposureDollars) GreenSuccess else RedDanger)
                }
                if (dwellSimHrs < dem.averageDwellHours) {
                    Text("Improving unloading by ${String.format("%.1f", dem.averageDwellHours - dwellSimHrs)}h saves $${String.format("%,.0f", dem.currentExposureDollars - simExposure)} in penalties!", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GreenSuccess)
                }
            }
        }
    }
}
