package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.model.*
import com.example.ui.components.PriceWaterfallChart
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PricingScreen(
    uiState: CalStrikeUiState,
    onOriginChange: (LocationNode) -> Unit,
    onDestinationChange: (LocationNode) -> Unit,
    onCommodityChange: (Commodity) -> Unit,
    onCarsCountChange: (Int) -> Unit,
    onEquipmentChange: (EquipmentCategory) -> Unit,
    onServiceChange: (ServiceType) -> Unit,
    onCalculateClick: () -> Unit,
    onAcceptQuoteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var sortCriteria by remember { mutableStateOf("PRICE") } // "PRICE", "TRANSIT", "RELIABILITY", "EMISSIONS"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section Header
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "PRICE A SHIPMENT — COMMERCIAL QUOTATION ENGINE",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Calculate linehaul, fuel surcharge, accessorials, demurrage and total landed freight cost.",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 05 — PRICE A SHIPMENT FORM
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "SHIPMENT PARAMETERS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberBright,
                    letterSpacing = 1.sp
                )

                // Origin & Destination pickers
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Origin dropdown
                    var originExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = originExpanded,
                        onExpandedChange = { originExpanded = !originExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = uiState.selectedOrigin.name,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("ORIGIN", fontSize = 10.sp, color = TextSecondaryDark) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = originExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AmberBright,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("origin_selector")
                        )
                        ExposedDropdownMenu(
                            expanded = originExpanded,
                            onDismissRequest = { originExpanded = false },
                            modifier = Modifier.background(NavySurface)
                        ) {
                            SyntheticDataRepository.LOCATIONS.forEach { loc ->
                                DropdownMenuItem(
                                    text = { Text("${loc.name} (${loc.stationCode})", color = Color.White, fontSize = 12.sp) },
                                    onClick = {
                                        onOriginChange(loc)
                                        originExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Destination dropdown
                    var destExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = destExpanded,
                        onExpandedChange = { destExpanded = !destExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = uiState.selectedDestination.name,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("DESTINATION", fontSize = 10.sp, color = TextSecondaryDark) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = destExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AmberBright,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("destination_selector")
                        )
                        ExposedDropdownMenu(
                            expanded = destExpanded,
                            onDismissRequest = { destExpanded = false },
                            modifier = Modifier.background(NavySurface)
                        ) {
                            SyntheticDataRepository.LOCATIONS.forEach { loc ->
                                DropdownMenuItem(
                                    text = { Text("${loc.name} (${loc.stationCode})", color = Color.White, fontSize = 12.sp) },
                                    onClick = {
                                        onDestinationChange(loc)
                                        destExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Commodity & STCC lookup
                var commExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = commExpanded,
                    onExpandedChange = { commExpanded = !commExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = "${uiState.selectedCommodity.name} (STCC ${uiState.selectedCommodity.stccCode})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("COMMODITY & STCC CODE", fontSize = 10.sp, color = TextSecondaryDark) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = commExpanded) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberBright,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("commodity_selector")
                    )
                    ExposedDropdownMenu(
                        expanded = commExpanded,
                        onDismissRequest = { commExpanded = false },
                        modifier = Modifier.background(NavySurface)
                    ) {
                        SyntheticDataRepository.COMMODITIES.forEach { comm ->
                            DropdownMenuItem(
                                text = { Text("${comm.name} — STCC ${comm.stccCode}", color = Color.White, fontSize = 12.sp) },
                                onClick = {
                                    onCommodityChange(comm)
                                    commExpanded = false
                                }
                            )
                        }
                    }
                }

                // Cars count & Equipment category
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = uiState.carsCount.toString(),
                        onValueChange = { str ->
                            val parsed = str.filter { it.isDigit() }.toIntOrNull() ?: 1
                            onCarsCountChange(parsed)
                        },
                        label = { Text("SHIPMENT SIZE (CARS)", fontSize = 10.sp, color = TextSecondaryDark) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberBright,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cars_count_input")
                    )

                    var equipExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = equipExpanded,
                        onExpandedChange = { equipExpanded = !equipExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = uiState.selectedEquipment.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("EQUIPMENT TYPE", fontSize = 10.sp, color = TextSecondaryDark) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = equipExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AmberBright,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("equipment_selector")
                        )
                        ExposedDropdownMenu(
                            expanded = equipExpanded,
                            onDismissRequest = { equipExpanded = false },
                            modifier = Modifier.background(NavySurface)
                        ) {
                            EquipmentCategory.entries.forEach { equip ->
                                DropdownMenuItem(
                                    text = { Text(equip.label, color = Color.White, fontSize = 12.sp) },
                                    onClick = {
                                        onEquipmentChange(equip)
                                        equipExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Service level
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    var serviceExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = serviceExpanded,
                        onExpandedChange = { serviceExpanded = !serviceExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = uiState.selectedService.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("SERVICE TYPE", fontSize = 10.sp, color = TextSecondaryDark) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = serviceExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AmberBright,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("service_type_selector")
                        )
                        ExposedDropdownMenu(
                            expanded = serviceExpanded,
                            onDismissRequest = { serviceExpanded = false },
                            modifier = Modifier.background(NavySurface)
                        ) {
                            ServiceType.entries.forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.label, color = Color.White, fontSize = 12.sp) },
                                    onClick = {
                                        onServiceChange(st)
                                        serviceExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Button(
                        onClick = onCalculateClick,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberBright),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .padding(top = 8.dp)
                            .testTag("calculate_freight_button")
                    ) {
                        Icon(imageVector = Icons.Default.Calculate, contentDescription = "Calculate", tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("CALCULATE RATE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // 06 — RATE RESULT & 07 — PRICE BUILD-UP
        val breakdown = uiState.calculatedBreakdown
        if (breakdown != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CALSTRIKE PRICE ESTIMATE",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = AmberBright,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "ESTIMATE — SUBJECT TO CONTRACT / CARRIER QUOTE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondaryDark
                            )
                        }

                        Surface(
                            color = NavyDark,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "${uiState.selectedOrigin.name} → ${uiState.selectedDestination.name}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Big Rate Metrics Display
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NavyDark, RoundedCornerShape(6.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ESTIMATED FREIGHT / CAR", fontSize = 10.sp, color = TextSecondaryDark)
                            Text(
                                text = "$${String.format("%,.0f", breakdown.totalPerCar)} / CAR",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = AmberBright
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("RATE / TON", fontSize = 10.sp, color = TextSecondaryDark)
                            Text(
                                text = "$${String.format("%.2f", breakdown.totalPerTon)} / TON",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("TOTAL FREIGHT", fontSize = 10.sp, color = TextSecondaryDark)
                            Text(
                                text = "$${String.format("%,.0f", breakdown.totalLandedCost)}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = GreenSuccess
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 07 — PRICE BUILD-UP Table Breakdown
                    Text("PRICE BUILD-UP BREAKDOWN ($ / CAR)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(6.dp))

                    PriceRow("LINEHAUL RATE", breakdown.linehaulPerCar)
                    PriceRow("FUEL SURCHARGE (12.7%)", breakdown.fuelSurchargePerCar)
                    PriceRow("ACCESSORIALS & DRAYAGE", breakdown.accessorialsPerCar)
                    PriceRow("TERMINAL HANDLING", breakdown.terminalHandlingPerCar)
                    PriceRow("STORAGE FEE", breakdown.storagePerCar)
                    PriceRow("DEMURRAGE RESERVE", breakdown.demurrageReservePerCar)
                    Divider(color = BorderDark, modifier = Modifier.padding(vertical = 4.dp))
                    PriceRow("TOTAL FREIGHT / CAR", breakdown.totalPerCar, isBold = true, highlightColor = AmberBright)
                }
            }

            // Price Waterfall Visualizer Component
            PriceWaterfallChart(breakdown = breakdown, carsCount = uiState.carsCount)

            // 08 — RATE COMPARISON
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "COMPARE CARRIER OPTIONS & ROUTING",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberBright,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Sort Criteria Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("PRICE", "TRANSIT", "RELIABILITY", "EMISSIONS").forEach { tag ->
                            FilterChip(
                                selected = sortCriteria == tag,
                                onClick = { sortCriteria = tag },
                                label = { Text(tag, fontSize = 9.sp) },
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val sortedOptions = when(sortCriteria) {
                        "TRANSIT" -> uiState.carrierOptions.sortedBy { it.transitTimeHours }
                        "RELIABILITY" -> uiState.carrierOptions.sortedByDescending { it.reliabilityPercent }
                        "EMISSIONS" -> uiState.carrierOptions.sortedBy { it.emissionsKgCo2 }
                        else -> uiState.carrierOptions.sortedBy { it.ratePerCar }
                    }

                    sortedOptions.forEach { opt ->
                        Surface(
                            color = NavyDark,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = opt.carrierName,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = opt.interlineRoute,
                                            fontSize = 10.sp,
                                            color = TextSecondaryDark
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "$${String.format("%,.0f", opt.ratePerCar)} / car",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Black,
                                            color = AmberBright
                                        )
                                        Text(
                                            text = "$${String.format("%.2f", opt.ratePerTon)} / ton",
                                            fontSize = 10.sp,
                                            color = GreenSuccess
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Transit: ${opt.transitTimeHours}h", fontSize = 10.sp, color = TextSecondaryDark)
                                    Text("Reliability: ${opt.reliabilityPercent}%", fontSize = 10.sp, color = GreenSuccess)
                                    Text("CO2: ${opt.emissionsKgCo2.toInt()}kg", fontSize = 10.sp, color = TextSecondaryDark)
                                    Surface(
                                        color = if (opt.confidence == "High") GreenSuccess else YellowWarn,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "${opt.confidence} Conf.",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 59 — WHY DID THE PRICE CHANGE? (Analytical Attribution)
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "WHY DID THE PRICE CHANGE? (ANALYTICAL ATTRIBUTION)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberBright,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Synthetic price variance vs 90-day baseline contract",
                        fontSize = 9.sp,
                        color = TextSecondaryDark
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        AttributionRow("BASE RATE ADJUSTMENT", "+4.2%", GreenSuccess)
                        AttributionRow("FUEL SURCHARGE DIESEL INDEX", "+8.1%", RedDanger)
                        AttributionRow("TERMINAL HANDLING SURCHARGE", "+2.4%", YellowWarn)
                        AttributionRow("SEASONAL DEMAND IMPACT", "+3.8%", YellowWarn)
                        AttributionRow("CAPACITY DISCOUNT", "-4.1%", GreenSuccess)
                        AttributionRow("CONTRACT ESCALATION FORMULA", "+1.2%", YellowWarn)
                        Divider(color = BorderDark, modifier = Modifier.padding(vertical = 4.dp))
                        AttributionRow("NET COMMERCIAL VARIANCE", "+5.7%", AmberBright, isBold = true)
                    }
                }
            }

            // CTA to ACCEPT QUOTE & CREATE SHIPMENT
            Button(
                onClick = onAcceptQuoteClick,
                colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("accept_quote_button")
            ) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Accept", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ACCEPT QUOTE & GENERATE SHIPMENT BOOKING",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun PriceRow(
    label: String,
    value: Double,
    isBold: Boolean = false,
    highlightColor: Color = Color.White
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (isBold) highlightColor else TextSecondaryDark
        )
        Text(
            text = "$${String.format("%,.2f", value)} / car",
            fontSize = 11.sp,
            fontWeight = if (isBold) FontWeight.Black else FontWeight.SemiBold,
            color = if (isBold) highlightColor else Color.White
        )
    }
}

@Composable
private fun AttributionRow(
    label: String,
    value: String,
    color: Color,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (isBold) Color.White else TextSecondaryDark
        )
        Text(
            text = value,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
