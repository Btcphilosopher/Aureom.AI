package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.ui.theme.*

@Composable
fun MarketScreen(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "CALIFORNIA FREIGHT COMMODITY MARKET & BENCHMARKS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Synthetic commercial freight benchmarks across Cement, Steel, Grain, Chemicals & Intermodal",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 28 — COMMODITY MARKET Dashboard
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SyntheticDataRepository.MARKET_BENCHMARKS.forEach { bm ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateCard),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = bm.commodityName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = "Spread: ${bm.regionalSpread}", fontSize = 10.sp, color = TextSecondaryDark)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "$${String.format("%,.2f", bm.currentBenchmark)} ${bm.unit}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = AmberBright
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "30d: ${if (bm.trend30dPercent >= 0) "+" else ""}${bm.trend30dPercent}%",
                                    fontSize = 10.sp,
                                    color = if (bm.trend30dPercent >= 0) RedDanger else GreenSuccess
                                )
                                Text(
                                    text = "90d: ${if (bm.trend90dPercent >= 0) "+" else ""}${bm.trend90dPercent}%",
                                    fontSize = 10.sp,
                                    color = TextSecondaryDark
                                )
                            }
                        }
                    }
                }
            }
        }

        // 29 — RATE BENCHMARKING Comparison
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "CUSTOMER RATE VS MARKET BENCHMARK INTELLIGENCE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberBright,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                BenchmarkMetricRow("YOUR CONTRACTED RATE", "$41.20 / Ton", GreenSuccess)
                BenchmarkMetricRow("MARKET BENCHMARK", "$43.10 / Ton", YellowWarn)
                BenchmarkMetricRow("HISTORICAL 12M AVERAGE", "$39.80 / Ton", TextSecondaryDark)
                BenchmarkMetricRow("CALSTRIKE MODELLED COST", "$42.40 / Ton", CyanMap)
            }
        }
    }
}

@Composable
private fun BenchmarkMetricRow(label: String, value: String, color: Color) {
    Surface(
        color = NavyDark,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color.White)
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}
