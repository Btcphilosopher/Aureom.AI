package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.model.LocationNode
import com.example.ui.theme.*

@Composable
fun RailNetworkMapView(
    selectedOrigin: LocationNode?,
    selectedDestination: LocationNode?,
    onNodeSelected: (LocationNode) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CALIFORNIA FREIGHT RAIL GIS NETWORK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberBright,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Class I Mainlines (BNSF / UP), Short Lines & Port Terminals",
                        fontSize = 9.sp,
                        color = TextSecondaryDark
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LegendTag("BNSF", CyanMap)
                    LegendTag("UP", YellowWarn)
                    LegendTag("Port/Yard", GreenSuccess)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Canvas Map Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(NavyDark, RoundedCornerShape(6.dp))
                    .testTag("rail_network_map")
            ) {
                val locations = SyntheticDataRepository.LOCATIONS

                // Min/Max bounds for map normalization
                val minLat = 32.5
                val maxLat = 39.0
                val minLon = -122.5
                val maxLon = -115.0

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    fun getPoint(loc: LocationNode): Offset {
                        val normX = ((loc.longitude - minLon) / (maxLon - minLon)).toFloat().coerceIn(0.05f, 0.95f)
                        val normY = (1.0f - ((loc.latitude - minLat) / (maxLat - minLat)).toFloat()).coerceIn(0.05f, 0.95f)
                        return Offset(normX * w, normY * h)
                    }

                    // 1. Draw Network Connections (Rail Mainlines)
                    for (i in locations.indices) {
                        val nodeA = locations[i]
                        val ptA = getPoint(nodeA)

                        for (j in i + 1 until locations.size) {
                            val nodeB = locations[j]
                            val isConnected = when {
                                // Northern Corridor
                                (nodeA.id in listOf("OAK", "SAC", "ROS", "STK", "LTH") && nodeB.id in listOf("OAK", "SAC", "ROS", "STK", "LTH")) -> true
                                // Central Valley Trunk
                                (nodeA.id in listOf("STK", "MOD", "MRC", "FAT", "BFL") && nodeB.id in listOf("STK", "MOD", "MRC", "FAT", "BFL")) -> true
                                // Southern Corridor
                                (nodeA.id in listOf("BFL", "LAX", "LGB", "SBD", "COL", "BAR", "YER") && nodeB.id in listOf("BFL", "LAX", "LGB", "SBD", "COL", "BAR", "YER")) -> true
                                // Border
                                (nodeA.id in listOf("LAX", "SAN", "IMP") && nodeB.id in listOf("LAX", "SAN", "IMP")) -> true
                                else -> false
                            }

                            if (isConnected) {
                                val ptB = getPoint(nodeB)
                                val isBnsf = "BNSF" in nodeA.primaryRailroads && "BNSF" in nodeB.primaryRailroads
                                val trackColor = if (isBnsf) CyanMap.copy(alpha = 0.4f) else YellowWarn.copy(alpha = 0.3f)

                                drawLine(
                                    color = trackColor,
                                    start = ptA,
                                    end = ptB,
                                    strokeWidth = 3f,
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    }

                    // 2. Draw Selected Route Highlight Line if origin & destination selected
                    if (selectedOrigin != null && selectedDestination != null) {
                        val ptO = getPoint(selectedOrigin)
                        val ptD = getPoint(selectedDestination)

                        // Highlight route line
                        drawLine(
                            color = AmberBright,
                            start = ptO,
                            end = ptD,
                            strokeWidth = 6f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                        )
                    }

                    // 3. Draw Station Nodes
                    locations.forEach { loc ->
                        val pt = getPoint(loc)
                        val isSelectedOrigin = selectedOrigin?.id == loc.id
                        val isSelectedDest = selectedDestination?.id == loc.id

                        val nodeColor = when {
                            isSelectedOrigin -> AmberBright
                            isSelectedDest -> GreenSuccess
                            loc.isPort -> GreenSuccess
                            loc.isIntermodalTerminal -> CyanMap
                            else -> SteelHeader
                        }

                        val radius = if (isSelectedOrigin || isSelectedDest) 10f else if (loc.isPort) 8f else 6f

                        drawCircle(
                            color = nodeColor,
                            radius = radius,
                            center = pt
                        )

                        if (isSelectedOrigin || isSelectedDest) {
                            drawCircle(
                                color = Color.White,
                                radius = radius + 4f,
                                center = pt,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Station Selector Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Select Origin / Dest:", fontSize = 10.sp, color = TextSecondaryDark)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "Origin: ${selectedOrigin?.name ?: "None"}",
                            fontSize = 10.sp,
                            color = AmberBright,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "Dest: ${selectedDestination?.name ?: "None"}",
                            fontSize = 10.sp,
                            color = GreenSuccess,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendTag(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, RoundedCornerShape(4.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 9.sp, color = TextSecondaryDark)
    }
}
