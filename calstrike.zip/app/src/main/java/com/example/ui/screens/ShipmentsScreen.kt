package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Shipment
import com.example.ui.components.RailNetworkMapView
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@Composable
fun ShipmentsScreen(
    uiState: CalStrikeUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ACTIVE FREIGHT SHIPMENT TRACKING & LIVE POSITIONS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Real-time California Rail Consignment Status, Location & Interlines",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // Live Rail Network GIS Map
        RailNetworkMapView(
            selectedOrigin = uiState.selectedOrigin,
            selectedDestination = uiState.selectedDestination,
            onNodeSelected = {}
        )

        // Active Shipments List (24 — SHIPMENT MANAGEMENT)
        uiState.shipmentsList.forEach { ship ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SHIPMENT ${ship.shipmentId}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = AmberBright
                            )
                            Text(
                                text = "${ship.customerName} • ${ship.commodityName}",
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }

                        Surface(
                            color = if (ship.status.name == "IN_TRANSIT") CyanMap else GreenSuccess,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = ship.status.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            ShipmentDetailRow("LANE", "${ship.originName} → ${ship.destinationName}")
                            ShipmentDetailRow("EQUIPMENT & CONSIST", "${ship.equipment.label} • ${ship.carsCount} Cars")
                            ShipmentDetailRow("CURRENT LOCATION", ship.currentLocation)
                            ShipmentDetailRow("ESTIMATED ARRIVAL (ETA)", ship.eta)
                            ShipmentDetailRow("CARRIER & RATE", "${ship.carrier} • $${String.format("%,.0f", ship.ratePerCar)}/car")
                            ShipmentDetailRow("TOTAL SHIPMENT VALUE", "$${String.format("%,.0f", ship.totalCost)}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShipmentDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, color = TextSecondaryDark)
        Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
