package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.KpiCard
import com.example.ui.components.RailNetworkMapView
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState
import com.example.viewmodel.NavTab

@Composable
fun OverviewScreen(
    uiState: CalStrikeUiState,
    onNavigateTab: (NavTab) -> Unit,
    onPriceClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Header Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "CALIFORNIA RAIL FREIGHT",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Price the movement. Understand the market. Control the freight.",
                            fontSize = 12.sp,
                            color = TextSecondaryDark
                        )
                    }

                    Button(
                        onClick = onPriceClick,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberBright),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("hero_price_shipment_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = "Price Shipment",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PRICE A SHIPMENT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    color = NavyDark,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "SYNTHETIC DEMONSTRATION DATA — CALSTRIKE FREIGHT OPERATING SYSTEM",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberBright,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // KPI Grid (04 — HOME / COMMERCIAL CONTROL CENTRE)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                KpiCard(
                    title = "ACTIVE QUOTES",
                    value = "184",
                    subtext = "24 hours activity",
                    icon = Icons.Default.ReceiptLong,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "OPEN SHIPMENTS",
                    value = "2,841",
                    subtext = "Across CA network",
                    icon = Icons.Default.LocalShipping,
                    iconTint = CyanMap,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                KpiCard(
                    title = "CONTRACTS",
                    value = "426",
                    subtext = "BNSF / UP / Short Lines",
                    icon = Icons.Default.Description,
                    iconTint = YellowWarn,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "MONTHLY SPEND",
                    value = "$184.7M",
                    subtext = "California Industrial Materials",
                    icon = Icons.Default.AttachMoney,
                    iconTint = GreenSuccess,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                KpiCard(
                    title = "AVG RATE / CAR",
                    value = "$3,842",
                    subtext = "Weighted CA carload",
                    icon = Icons.Default.BarChart,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "ON-TIME SERVICE",
                    value = "91.8%",
                    subtext = "BNSF 93.4% / UP 90.8%",
                    icon = Icons.Default.Timer,
                    iconTint = GreenSuccess,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Interactive California Map Module
        RailNetworkMapView(
            selectedOrigin = uiState.selectedOrigin,
            selectedDestination = uiState.selectedDestination,
            onNodeSelected = {}
        )

        // Active Commercial Actions / Recent Activity
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ACTIVE FREIGHT PIPELINE & QUOTES",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberBright,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (uiState.shipmentsList.isEmpty()) {
                    Text("No active shipments.", fontSize = 12.sp, color = TextSecondaryDark)
                } else {
                    uiState.shipmentsList.take(3).forEach { ship ->
                        Surface(
                            color = NavyDark,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${ship.shipmentId} • ${ship.commodityName} (${ship.carsCount} cars)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${ship.originName} → ${ship.destinationName} • ${ship.carrier}",
                                        fontSize = 10.sp,
                                        color = TextSecondaryDark
                                    )
                                }

                                Surface(
                                    color = if (ship.status.name == "IN_TRANSIT") CyanMap else GreenSuccess,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = ship.status.label,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { onNavigateTab(NavTab.SHIPMENTS) }) {
                        Text("VIEW ALL SHIPMENTS →", color = AmberBright, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
