package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.ui.theme.*

@Composable
fun CustomersScreen(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()
    val cust = SyntheticDataRepository.DEMO_CUSTOMER

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "CUSTOMER COMMERCIAL MANAGEMENT",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Enterprise customer profiles, spend history, active contracts & lane performance",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // Customer Profile Card (23 — CUSTOMER MANAGEMENT)
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = cust.name, fontSize = 15.sp, fontWeight = FontWeight.Black, color = AmberBright)
                        Text(text = "ID: ${cust.customerId} • Industrial Materials Sector", fontSize = 10.sp, color = TextSecondaryDark)
                    }

                    Surface(
                        color = GreenSuccess,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "PREMIER ACCOUNT",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    color = NavyDark,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        CustomerStatRow("ANNUAL FREIGHT SPEND", "$${cust.annualSpendMillion}M")
                        CustomerStatRow("ANNUAL VOLUME", "${String.format("%,.0f", cust.annualVolumeTons)} TONS")
                        CustomerStatRow("ACTIVE CA LANES", "${cust.activeLanesCount} LANES")
                        CustomerStatRow("ACTIVE CONTRACTS", "${cust.activeContractsCount} CONTRACTS")
                        CustomerStatRow("AVERAGE RATE / TON", "$${cust.avgRatePerTon} / TON")
                        CustomerStatRow("ON-TIME SERVICE LEVEL", "${cust.onTimeServicePercent}%")
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerStatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, color = TextSecondaryDark)
        Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
