package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CALSTRIKE Institutional Freight Color Palette
val NavyDark = Color(0xFF0B192C)        // Base background dark
val NavySurface = Color(0xFF1E293B)     // Surface dark
val SlateCard = Color(0xFF0F172A)       // Card container dark
val SteelHeader = Color(0xFF334155)     // Header background
val TextPrimaryDark = Color(0xFFF8FAFC) // Primary text dark
val TextSecondaryDark = Color(0xFF94A3B8)// Muted text dark

val AmberAccent = Color(0xFFEA580C)      // California Sunset Amber/Red
val AmberBright = Color(0xFFF97316)      // Primary action CTA
val GreenSuccess = Color(0xFF16A34A)     // On-time, active, green
val RedDanger = Color(0xFFDC2626)        // Demurrage, risk alert
val CyanMap = Color(0xFF0284C7)          // Rail network blue
val YellowWarn = Color(0xFFD97706)       // Pending / Medium confidence

// Light Mode palette
val SlateLightBg = Color(0xFFF1F5F9)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)
val BorderDark = Color(0xFF334155)
