package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.RailNetworkMapView
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@Composable
fun RoutesScreen(
    uiState: CalStrikeUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "CALIFORNIA ROUTING ENGINE & INTERCHANGE VISUALIZATION",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Subdivisions, Yard Classification, Interchange Points & Service Restrictions",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // California Interactive GIS Map
        RailNetworkMapView(
            selectedOrigin = uiState.selectedOrigin,
            selectedDestination = uiState.selectedDestination,
            onNodeSelected = {}
        )

        // Route Breakdown (09 — ROUTE ENGINE)
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ACTIVE ROUTE STEP BREAKDOWN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberBright,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                RouteStepItem("01 — ORIGIN FACILITY", "${uiState.selectedOrigin.name} (${uiState.selectedOrigin.facilityName})", "First-mile drayage / origin switch", CyanMap)
                RouteStepItem("02 — CLASS I TRUNK LINE", "Oakland Subdivision → Lathrop Yard → Barstow Yard", "BNSF Mainline • 382 rail miles", YellowWarn)
                RouteStepItem("03 — INTERCHANGE POINT", "Barstow Classification Yard Junction", "Railroad interchange & car sorting", AmberBright)
                RouteStepItem("04 — DESTINATION TERMINAL", "${uiState.selectedDestination.name} (${uiState.selectedDestination.facilityName})", "Final placement & unloading siding", GreenSuccess)
            }
        }
    }
}

@Composable
private fun RouteStepItem(stepTitle: String, mainText: String, subText: String, accentColor: Color) {
    Surface(
        color = NavyDark,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(accentColor, RoundedCornerShape(5.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = stepTitle, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = accentColor)
                Text(text = mainText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(text = subText, fontSize = 10.sp, color = TextSecondaryDark)
            }
        }
    }
}
