package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AmberBright,
    onPrimary = Color.White,
    primaryContainer = SteelHeader,
    onPrimaryContainer = TextPrimaryDark,
    secondary = CyanMap,
    onSecondary = Color.White,
    tertiary = GreenSuccess,
    background = NavyDark,
    onBackground = TextPrimaryDark,
    surface = NavySurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = SlateCard,
    onSurfaceVariant = TextSecondaryDark,
    outline = BorderDark,
    error = RedDanger
)

private val LightColorScheme = lightColorScheme(
    primary = AmberAccent,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFEDD5),
    onPrimaryContainer = Color(0xFF9A3412),
    secondary = CyanMap,
    onSecondary = Color.White,
    tertiary = GreenSuccess,
    background = SlateLightBg,
    onBackground = TextPrimaryLight,
    surface = SurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFF8FAFC),
    onSurfaceVariant = TextSecondaryLight,
    outline = BorderLight,
    error = RedDanger
)

@Composable
fun CalStrikeTheme(
    darkTheme: Boolean = true, // Default to dark enterprise theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
