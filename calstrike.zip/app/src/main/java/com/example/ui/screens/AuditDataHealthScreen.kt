package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@Composable
fun AuditDataHealthScreen(
    uiState: CalStrikeUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "DATA HEALTH & COMMERCIAL AUDIT LOGS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "System integrity checks, rate version audits & commercial role governance",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 41 — DATA QUALITY Dashboard
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "COMMERCIAL DATA HEALTH AUDIT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                Spacer(modifier = Modifier.height(8.dp))

                SyntheticDataRepository.DATA_HEALTH_CHECKS.forEach { check ->
                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(check.checkName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(check.description, fontSize = 9.sp, color = TextSecondaryDark)
                            }
                            Surface(
                                color = if (check.severity == "OK") GreenSuccess else YellowWarn,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (check.severity == "OK") "PASSED" else "${check.issueCount} ISSUES",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 42 — AUDIT SYSTEM Log Stream
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "SYSTEM AUDIT LOG STREAM", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                Spacer(modifier = Modifier.height(8.dp))

                uiState.auditLogsList.forEach { log ->
                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${log.logId} • ${log.recordType}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(log.timestamp, fontSize = 9.sp, color = TextSecondaryDark)
                            }
                            Text("User: ${log.user} • Approved by: ${log.approvedBy}", fontSize = 9.sp, color = CyanMap)
                            Text("Value Shift: ${log.oldValue} → ${log.newValue}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                            Text("Reason: ${log.reason}", fontSize = 9.sp, color = TextSecondaryDark)
                        }
                    }
                }
            }
        }
    }
}
