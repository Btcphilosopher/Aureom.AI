package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.KpiCard
import com.example.ui.components.PriceWaterfallChart
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@Composable
fun AnalyticsScreen(
    uiState: CalStrikeUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 39 — EXECUTIVE DASHBOARD
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "COMMERCIAL FREIGHT EXECUTIVE ANALYTICS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Macro spend, volume trends, carrier market share & total landed cost intelligence",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // Executive KPI Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KpiCard(
                title = "ANNUAL SPEND",
                value = "$184.7M",
                subtext = "4.2M Tonnes Moved",
                icon = Icons.Default.MonetizationOn,
                modifier = Modifier.weight(1f)
            )
            KpiCard(
                title = "ACTIVE LANES",
                value = "1,842",
                subtext = "BNSF / UP / Shortlines",
                icon = Icons.Default.AltRoute,
                iconTint = CyanMap,
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KpiCard(
                title = "AVG $/TON",
                value = "$43.10",
                subtext = "3.2% vs 2025 Baseline",
                icon = Icons.Default.TrendingUp,
                iconTint = YellowWarn,
                modifier = Modifier.weight(1f)
            )
            KpiCard(
                title = "DEMURRAGE RISK",
                value = "$2.8M",
                subtext = "48 cars currently on demurrage",
                icon = Icons.Default.Warning,
                iconTint = RedDanger,
                modifier = Modifier.weight(1f)
            )
        }

        // Price Waterfall Component if available
        uiState.calculatedBreakdown?.let { breakdown ->
            PriceWaterfallChart(breakdown = breakdown, carsCount = uiState.carsCount)
        }

        // 30 — LANE ANALYTICS Table
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "TOP CALIFORNIA LANES PERFORMANCE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberBright,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LanePerformanceItem("Oakland → San Bernardino", "Cement", "184,000 tons", "$3,842 / car", "$20.91 / ton", "38h", 93.4)
                LanePerformanceItem("Los Angeles → Roseville", "Steel", "120,000 tons", "$4,118 / car", "$45.75 / ton", "42h", 90.8)
                LanePerformanceItem("Stockton → Bakersfield", "Grain", "310,000 tons", "$3,420 / car", "$34.89 / ton", "28h", 91.2)
                LanePerformanceItem("Long Beach → Modesto", "Chemicals", "95,000 tons", "$4,980 / car", "$52.42 / ton", "31h", 94.0)
            }
        }
    }
}

@Composable
private fun LanePerformanceItem(lane: String, commodity: String, volume: String, rateCar: String, rateTon: String, transit: String, reliability: Double) {
    Surface(
        color = NavyDark,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = lane, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(text = rateCar, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AmberBright)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "$commodity • $volume", fontSize = 10.sp, color = TextSecondaryDark)
                Text(text = "$rateTon • Transit: $transit • On-time: $reliability%", fontSize = 10.sp, color = GreenSuccess)
            }
        }
    }
}
