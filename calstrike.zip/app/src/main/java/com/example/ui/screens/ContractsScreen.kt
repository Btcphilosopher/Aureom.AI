package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Contract
import com.example.ui.theme.*
import com.example.viewmodel.CalStrikeUiState

@Composable
fun ContractsScreen(
    uiState: CalStrikeUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "COMMERCIAL CONTRACT & RATE MANAGEMENT",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "426 Active Customer Rail Contracts, Fuel Formulas, Volume Commitments & Expiries",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 19 — CONTRACT MANAGEMENT Cards
        uiState.contractsList.forEach { contract ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CONTRACT ${contract.contractId}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberBright
                            )
                            Text(
                                text = contract.customerName,
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }

                        Surface(
                            color = GreenSuccess,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = contract.status,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = NavyDark,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            ContractField("LANE", "${contract.originName} → ${contract.destinationName}")
                            ContractField("CARRIER & COMMODITY", "${contract.carrierName} • ${contract.commodityName}")
                            ContractField("CONTRACTED RATE", "$${String.format("%,.0f", contract.ratePerCar)} / CAR")
                            ContractField("FUEL FORMULA", contract.fuelFormula)
                            ContractField("VALIDITY DATES", "${contract.validFrom} → ${contract.validTo}")
                            ContractField("ANNUAL SPEND", "$${String.format("%.1f", contract.annualSpend / 1000000.0)}M")
                        }
                    }
                }
            }
        }

        // 21 — RATE VERSION CONTROL
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "RATE VERSION CONTROL (AUDIT HISTORY)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberBright,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                RateVersionRow("v3 (CURRENT)", "$3,842 / car", "J. SMITH", "2026-10-01", "2026 Renewal", GreenSuccess)
                RateVersionRow("v2", "$3,620 / car", "A. DAVIS", "2025-10-01", "Fuel Formula Shift", YellowWarn)
                RateVersionRow("v1", "$3,420 / car", "R. GARCIA", "2024-10-01", "Initial Tariff Base", TextSecondaryDark)
            }
        }
    }
}

@Composable
private fun ContractField(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, color = TextSecondaryDark)
        Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
private fun RateVersionRow(vTag: String, rate: String, user: String, date: String, reason: String, color: Color) {
    Surface(
        color = NavyDark,
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = vTag, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
                Text(text = "$user • $date • $reason", fontSize = 9.sp, color = TextSecondaryDark)
            }
            Text(text = rate, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
