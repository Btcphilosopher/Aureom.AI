package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticDataRepository
import com.example.ui.theme.*

@Composable
fun EquipmentScreen(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "EQUIPMENT FLEET TRACKING & CYCLE ECONOMICS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Boxcars, Covered Hoppers, Tankers, Flatcars & Intermodal Chassis Economics",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }

        // 27 — EQUIPMENT ECONOMICS Summary Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("EMPTY MILES RATIO", fontSize = 10.sp, color = TextSecondaryDark)
                    Text("22.4%", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AmberBright)
                    Text("Target: < 20.0%", fontSize = 9.sp, color = GreenSuccess)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("AVERAGE CYCLE TIME", fontSize = 10.sp, color = TextSecondaryDark)
                    Text("13.2 Days", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CyanMap)
                    Text("Turn time: 31.0h", fontSize = 9.sp, color = TextSecondaryDark)
                }
            }
        }

        // Equipment Fleet List
        SyntheticDataRepository.getEquipmentList().forEach { equip ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = equip.carNumber, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(text = "${equip.equipmentCategory.label} • Owner: ${equip.owner}", fontSize = 10.sp, color = TextSecondaryDark)
                        Text(text = "Location: ${equip.currentLocation}", fontSize = 10.sp, color = CyanMap)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            color = when(equip.status) {
                                "Loaded" -> GreenSuccess
                                "Empty" -> YellowWarn
                                else -> RedDanger
                            },
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = equip.status,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Turn: ${equip.turnTimeHours}h", fontSize = 10.sp, color = TextSecondaryDark)
                    }
                }
            }
        }
    }
}
