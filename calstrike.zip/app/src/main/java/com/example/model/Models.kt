package com.example.model

enum class RateType(val label: String) {
    PUBLIC_RATE("Public Tariff"),
    CONTRACT_RATE("Contract Rate"),
    QUOTE("Carrier Quote"),
    ESTIMATE("CALSTRIKE Estimate"),
    BENCHMARK("Market Benchmark")
}

enum class EquipmentCategory(val label: String, val code: String) {
    COVERED_HOPPER("Covered Hopper", "CH"),
    BOXCAR("Boxcar", "BX"),
    TANK_CAR("Tank Car", "TC"),
    GONDOLA("Gondola", "GD"),
    FLATCAR("Flatcar", "FC"),
    REFRIGERATED("Refrigerated Equipment", "RF"),
    INTERMODAL_20("20ft Intermodal Container", "IN20"),
    INTERMODAL_40("40ft Intermodal Container", "IN40"),
    INTERMODAL_53("53ft Intermodal Container", "IN53")
}

enum class ServiceType(val label: String) {
    CARLOAD("Carload"),
    UNIT_TRAIN("Unit Train"),
    SHUTTLE("Shuttle"),
    INTERMODAL("Intermodal"),
    MANIFEST("Manifest"),
    PRIVATE_EQUIPMENT("Private Equipment")
}

enum class RegionZone(val label: String) {
    NORTHERN_CA("Northern California"),
    CENTRAL_VALLEY("Central Valley"),
    SOUTHERN_CA("Southern California"),
    CENTRAL_COAST("Central Coast"),
    BORDER_REGION("Border Region")
}

data class LocationNode(
    val id: String,
    val name: String,
    val facilityName: String,
    val stationCode: String,
    val zipCode: String,
    val region: RegionZone,
    val latitude: Double,
    val longitude: Double,
    val primaryRailroads: List<String>,
    val isIntermodalTerminal: Boolean = false,
    val isPort: Boolean = false
)

data class Commodity(
    val stccCode: String,
    val name: String,
    val category: String,
    val defaultEquipment: EquipmentCategory,
    val typicalLoadTonsPerCar: Double,
    val baseRatePerCarMile: Double
)

data class PriceBreakdown(
    val linehaulPerCar: Double,
    val fuelSurchargePerCar: Double,
    val accessorialsPerCar: Double,
    val terminalHandlingPerCar: Double,
    val storagePerCar: Double,
    val demurrageReservePerCar: Double,
    val totalPerCar: Double,
    val totalPerTon: Double,
    val totalLandedCost: Double,
    val totalMiles: Double
)

data class CarrierQuoteOption(
    val carrierName: String,
    val carrierCode: String,
    val serviceType: ServiceType,
    val ratePerCar: Double,
    val ratePerTon: Double,
    val transitTimeHours: Int,
    val equipmentCategory: EquipmentCategory,
    val confidence: String, // "High", "Medium", "Low"
    val emissionsKgCo2: Double,
    val reliabilityPercent: Double,
    val interlineRoute: String
)

data class PriceQuote(
    val quoteId: String,
    val customerName: String,
    val origin: LocationNode,
    val destination: LocationNode,
    val commodity: Commodity,
    val shipmentCars: Int,
    val totalTons: Double,
    val equipment: EquipmentCategory,
    val serviceType: ServiceType,
    val carrierName: String,
    val breakdown: PriceBreakdown,
    val status: String, // "QUOTED", "ACCEPTED", "BOOKED", "SHIPMENT_CREATED", "INVOICED"
    val validityDays: Int = 30,
    val createdDate: String,
    val rateType: RateType = RateType.ESTIMATE
)

data class Contract(
    val contractId: String,
    val customerName: String,
    val carrierName: String,
    val commodityName: String,
    val stcc: String,
    val originName: String,
    val destinationName: String,
    val ratePerCar: Double,
    val validFrom: String,
    val validTo: String,
    val fuelFormula: String,
    val status: String, // "ACTIVE", "EXPIRED", "UNDER_RENEWAL"
    val minVolumeTons: Double,
    val annualSpend: Double
)

enum class ShipmentStatus(val label: String) {
    BOOKED("Booked"),
    RELEASED("Released"),
    LOADING("Loading"),
    DEPARTED("Departed"),
    IN_TRANSIT("In Transit"),
    YARD("Yard"),
    INTERCHANGE("Interchange"),
    DESTINATION("At Destination"),
    UNLOADING("Unloading"),
    COMPLETE("Complete")
}

data class Shipment(
    val shipmentId: String,
    val customerName: String,
    val originName: String,
    val destinationName: String,
    val commodityName: String,
    val equipment: EquipmentCategory,
    val carsCount: Int,
    val status: ShipmentStatus,
    val eta: String,
    val currentLocation: String,
    val carrier: String,
    val ratePerCar: Double,
    val totalCost: Double,
    val lastUpdated: String
)

data class PortInfo(
    val name: String,
    val annualRailVolumeTeu: Long,
    val containerVolumeTeu: Long,
    val intermodalCapacityPercent: Double,
    val railConnections: List<String>,
    val avgDrayageCost: Double,
    val avgDwellHours: Double,
    val congestionLevel: String
)

data class MarketBenchmark(
    val commodityName: String,
    val unit: String,
    val currentBenchmark: Double,
    val trend30dPercent: Double,
    val trend90dPercent: Double,
    val trend12mPercent: Double,
    val regionalSpread: String
)

data class EquipmentItem(
    val carNumber: String,
    val equipmentCategory: EquipmentCategory,
    val owner: String, // "Private", "UP", "BNSF", "TTX"
    val capacityTons: Double,
    val currentLocation: String,
    val status: String, // "Loaded", "Empty", "Maintenance", "In Yard"
    val cycleTimeDays: Double,
    val turnTimeHours: Double,
    val emptyMilesPercent: Double
)

data class CustomerProfile(
    val customerId: String,
    val name: String,
    val annualVolumeTons: Double,
    val annualSpendMillion: Double,
    val activeLanesCount: Int,
    val activeContractsCount: Int,
    val avgRatePerTon: Double,
    val onTimeServicePercent: Double
)

data class DemurrageExposure(
    val carsOnDemurrage: Int,
    val currentExposureDollars: Double,
    val forecastExposureDollars: Double,
    val averageDwellHours: Double,
    val freeTimeHours: Double = 24.0,
    val dailyRatePerCar: Double = 120.0
)

data class AuditLog(
    val logId: String,
    val user: String,
    val timestamp: String,
    val recordType: String,
    val oldValue: String,
    val newValue: String,
    val reason: String,
    val approvedBy: String
)

data class DataHealthCheck(
    val checkName: String,
    val issueCount: Int,
    val severity: String, // "CRITICAL", "HIGH", "MEDIUM", "OK"
    val description: String
)

data class RateVersion(
    val version: String,
    val ratePerCar: Double,
    val changedBy: String,
    val date: String,
    val reason: String,
    val status: String
)

data class ScenarioSettings(
    val fuelIndexMultiplier: Float = 1.0f,      // 0.8 to 1.5
    val volumeMultiplier: Float = 1.0f,         // 0.5 to 2.0
    val transitHoursAdjustment: Int = 0,         // -12 to +24
    val dwellHoursAdjustment: Int = 0,           // -12 to +24
    val terminalCostMultiplier: Float = 1.0f,   // 0.8 to 1.5
    val drayageCostMultiplier: Float = 1.0f     // 0.8 to 1.5
)

data class FreightInvoice(
    val invoiceId: String,
    val shipmentId: String,
    val customerName: String,
    val commodityName: String,
    val carsCount: Int,
    val linehaulAmount: Double,
    val fuelSurchargeAmount: Double,
    val accessorialsAmount: Double,
    val demurrageAmount: Double,
    val totalAmount: Double,
    val invoiceDate: String,
    val paymentStatus: String // "PAID", "PENDING", "OVERDUE"
)
