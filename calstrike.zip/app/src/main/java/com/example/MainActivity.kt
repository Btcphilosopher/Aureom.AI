package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.NavigationTabs
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.*
import com.example.ui.theme.CalStrikeTheme
import com.example.ui.theme.NavyDark
import com.example.ui.theme.SteelHeader
import com.example.ui.theme.TextSecondaryDark
import com.example.viewmodel.CalStrikeViewModel
import com.example.viewmodel.NavTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CalStrikeTheme {
                CalStrikeApp()
            }
        }
    }
}

@Composable
fun CalStrikeApp(
    viewModel: CalStrikeViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopHeaderBar(
                isExecutiveMode = uiState.isExecutiveMode,
                onToggleExecutiveMode = { viewModel.toggleExecutiveMode() },
                userNotification = uiState.userNotification,
                onDismissNotification = { viewModel.clearNotification() }
            )
        },
        bottomBar = {
            // Institutional Footer (65 — FINAL BRAND)
            Surface(
                color = SteelHeader,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp, horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "CALSTRIKE • PRICE THE RAIL NETWORK.",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "California Rail Freight Pricing & Commercial Intelligence — DEMONSTRATION PLATFORM — SYNTHETIC DATA",
                        fontSize = 8.sp,
                        color = TextSecondaryDark,
                        textAlign = TextAlign.Center
                    )
                }
            }
        },
        containerColor = NavyDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Enterprise Navigation Tabs
            NavigationTabs(
                selectedTab = uiState.currentTab,
                onTabSelected = { tab -> viewModel.selectTab(tab) }
            )

            // Main Screen Container
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("main_screen_container")
            ) {
                when (uiState.currentTab) {
                    NavTab.OVERVIEW -> OverviewScreen(
                        uiState = uiState,
                        onNavigateTab = { tab -> viewModel.selectTab(tab) },
                        onPriceClick = { viewModel.selectTab(NavTab.PRICE) }
                    )
                    NavTab.PRICE -> PricingScreen(
                        uiState = uiState,
                        onOriginChange = { viewModel.updateOrigin(it) },
                        onDestinationChange = { viewModel.updateDestination(it) },
                        onCommodityChange = { viewModel.updateCommodity(it) },
                        onCarsCountChange = { viewModel.updateCarsCount(it) },
                        onEquipmentChange = { viewModel.updateEquipment(it) },
                        onServiceChange = { viewModel.updateService(it) },
                        onCalculateClick = { viewModel.calculateFreight() },
                        onAcceptQuoteClick = { viewModel.acceptActiveQuote() }
                    )
                    NavTab.ROUTES -> RoutesScreen(uiState = uiState)
                    NavTab.MARKET -> MarketScreen()
                    NavTab.CONTRACTS -> ContractsScreen(uiState = uiState)
                    NavTab.SHIPMENTS -> ShipmentsScreen(uiState = uiState)
                    NavTab.EQUIPMENT -> EquipmentScreen()
                    NavTab.PORTS -> PortsScreen()
                    NavTab.CUSTOMERS, NavTab.CARRIERS -> CustomersScreen()
                    NavTab.ANALYTICS, NavTab.FORECAST -> AnalyticsScreen(uiState = uiState)
                    NavTab.SCENARIO, NavTab.PROCUREMENT -> ScenarioScreen(
                        uiState = uiState,
                        onScenarioChange = { viewModel.updateScenarioSettings(it) }
                    )
                    NavTab.DEMURRAGE -> DemurrageScreen()
                    NavTab.QUOTE_BUILDER -> QuoteBuilderScreen(uiState = uiState)
                    NavTab.DATA_AUDIT -> AuditDataHealthScreen(uiState = uiState)
                }
            }
        }
    }
}
