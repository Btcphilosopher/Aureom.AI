package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SyntheticDataRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class NavTab(val title: String) {
    OVERVIEW("OVERVIEW"),
    PRICE("PRICE"),
    ROUTES("ROUTES"),
    MARKET("MARKET"),
    CONTRACTS("CONTRACTS"),
    SHIPMENTS("SHIPMENTS"),
    EQUIPMENT("EQUIPMENT"),
    PORTS("PORTS"),
    CUSTOMERS("CUSTOMERS"),
    CARRIERS("CARRIERS"),
    ANALYTICS("ANALYTICS"),
    FORECAST("FORECAST"),
    SCENARIO("SCENARIO LAB"),
    PROCUREMENT("PROCUREMENT"),
    DEMURRAGE("DEMURRAGE"),
    QUOTE_BUILDER("QUOTE BUILDER"),
    DATA_AUDIT("DATA & AUDIT")
}

data class CalStrikeUiState(
    val currentTab: NavTab = NavTab.OVERVIEW,
    val isExecutiveMode: Boolean = false,
    val searchFilter: String = "",
    
    // Form Inputs for "PRICE A SHIPMENT"
    val selectedOrigin: LocationNode = SyntheticDataRepository.LOCATIONS[0], // Oakland
    val selectedDestination: LocationNode = SyntheticDataRepository.LOCATIONS[11], // San Bernardino
    val selectedCommodity: Commodity = SyntheticDataRepository.COMMODITIES[0], // Cement
    val carsCount: Int = 50,
    val selectedEquipment: EquipmentCategory = EquipmentCategory.COVERED_HOPPER,
    val selectedService: ServiceType = ServiceType.CARLOAD,
    val shipmentDate: String = "2026-10-15",
    val selectedCustomerName: String = "California Industrial Materials Inc.",
    val selectedCarrierName: String = "BNSF Railway",
    
    // Calculation Results
    val calculatedBreakdown: PriceBreakdown? = null,
    val carrierOptions: List<CarrierQuoteOption> = emptyList(),
    val activeQuote: PriceQuote? = null,
    
    // State lists
    val quotesList: List<PriceQuote> = emptyList(),
    val contractsList: List<Contract> = SyntheticDataRepository.CONTRACTS,
    val shipmentsList: List<Shipment> = SyntheticDataRepository.INITIAL_SHIPMENTS,
    val invoicesList: List<FreightInvoice> = emptyList(),
    val auditLogsList: List<AuditLog> = SyntheticDataRepository.AUDIT_LOGS,
    
    // Scenario Lab
    val scenarioSettings: ScenarioSettings = ScenarioSettings(),
    
    // Alert / Toast message
    val userNotification: String? = null
)

class CalStrikeViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CalStrikeUiState())
    val uiState: StateFlow<CalStrikeUiState> = _uiState.asStateFlow()

    init {
        // Initial price calculation on launch
        calculateFreight()
    }

    fun selectTab(tab: NavTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun toggleExecutiveMode() {
        _uiState.value = _uiState.value.copy(isExecutiveMode = !_uiState.value.isExecutiveMode)
    }

    fun updateSearchFilter(text: String) {
        _uiState.value = _uiState.value.copy(searchFilter = text)
    }

    fun updateOrigin(node: LocationNode) {
        _uiState.value = _uiState.value.copy(selectedOrigin = node)
        calculateFreight()
    }

    fun updateDestination(node: LocationNode) {
        _uiState.value = _uiState.value.copy(selectedDestination = node)
        calculateFreight()
    }

    fun updateCommodity(commodity: Commodity) {
        _uiState.value = _uiState.value.copy(
            selectedCommodity = commodity,
            selectedEquipment = commodity.defaultEquipment
        )
        calculateFreight()
    }

    fun updateCarsCount(count: Int) {
        val safeCount = count.coerceIn(1, 200)
        _uiState.value = _uiState.value.copy(carsCount = safeCount)
        calculateFreight()
    }

    fun updateEquipment(equipment: EquipmentCategory) {
        _uiState.value = _uiState.value.copy(selectedEquipment = equipment)
        calculateFreight()
    }

    fun updateService(service: ServiceType) {
        _uiState.value = _uiState.value.copy(selectedService = service)
        calculateFreight()
    }

    fun updateScenarioSettings(settings: ScenarioSettings) {
        _uiState.value = _uiState.value.copy(scenarioSettings = settings)
        calculateFreight()
    }

    fun calculateFreight() {
        val state = _uiState.value
        val breakdown = SyntheticDataRepository.calculateFreightPrice(
            origin = state.selectedOrigin,
            destination = state.selectedDestination,
            commodity = state.selectedCommodity,
            carsCount = state.carsCount,
            equipment = state.selectedEquipment,
            service = state.selectedService,
            scenario = state.scenarioSettings
        )

        val options = SyntheticDataRepository.getCarrierOptions(
            origin = state.selectedOrigin,
            destination = state.selectedDestination,
            commodity = state.selectedCommodity,
            equipment = state.selectedEquipment,
            baseBreakdown = breakdown
        )

        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val tons = state.carsCount * state.selectedCommodity.typicalLoadTonsPerCar
        
        val quote = PriceQuote(
            quoteId = "QT-${(1000..9999).random()}",
            customerName = state.selectedCustomerName,
            origin = state.selectedOrigin,
            destination = state.selectedDestination,
            commodity = state.selectedCommodity,
            shipmentCars = state.carsCount,
            totalTons = tons,
            equipment = state.selectedEquipment,
            serviceType = state.selectedService,
            carrierName = state.selectedCarrierName,
            breakdown = breakdown,
            status = "QUOTED",
            createdDate = dateStr
        )

        _uiState.value = _uiState.value.copy(
            calculatedBreakdown = breakdown,
            carrierOptions = options,
            activeQuote = quote
        )
    }

    // Pipeline workflow: ACCEPT QUOTE -> CREATE CONTRACT -> CREATE SHIPMENT -> INVOICE
    fun acceptActiveQuote() {
        val activeQuote = _uiState.value.activeQuote ?: return
        val currentQuotes = _uiState.value.quotesList.toMutableList()
        val acceptedQuote = activeQuote.copy(status = "ACCEPTED")
        currentQuotes.add(0, acceptedQuote)

        // Create new Shipment automatically
        val newShipmentId = "CS-${(840200..849999).random()}"
        val newShipment = Shipment(
            shipmentId = newShipmentId,
            customerName = activeQuote.customerName,
            originName = activeQuote.origin.name,
            destinationName = activeQuote.destination.name,
            commodityName = activeQuote.commodity.name,
            equipment = activeQuote.equipment,
            carsCount = activeQuote.shipmentCars,
            status = ShipmentStatus.BOOKED,
            eta = "Estimated 36h from Dispatch",
            currentLocation = "${activeQuote.origin.name} Rail Yard",
            carrier = activeQuote.carrierName,
            ratePerCar = activeQuote.breakdown.totalPerCar,
            totalCost = activeQuote.breakdown.totalLandedCost,
            lastUpdated = "Just now"
        )

        val updatedShipments = _uiState.value.shipmentsList.toMutableList()
        updatedShipments.add(0, newShipment)

        // Create Invoice
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val newInvoice = FreightInvoice(
            invoiceId = "INV-${(9000..9999).random()}",
            shipmentId = newShipmentId,
            customerName = activeQuote.customerName,
            commodityName = activeQuote.commodity.name,
            carsCount = activeQuote.shipmentCars,
            linehaulAmount = activeQuote.breakdown.linehaulPerCar * activeQuote.shipmentCars,
            fuelSurchargeAmount = activeQuote.breakdown.fuelSurchargePerCar * activeQuote.shipmentCars,
            accessorialsAmount = activeQuote.breakdown.accessorialsPerCar * activeQuote.shipmentCars,
            demurrageAmount = activeQuote.breakdown.demurrageReservePerCar * activeQuote.shipmentCars,
            totalAmount = activeQuote.breakdown.totalLandedCost,
            invoiceDate = dateStr,
            paymentStatus = "PENDING"
        )

        val updatedInvoices = _uiState.value.invoicesList.toMutableList()
        updatedInvoices.add(0, newInvoice)

        // Log Audit Event
        val newAudit = AuditLog(
            logId = "AUD-${(9830..9999).random()}",
            user = "COMMERCIAL ANALYST",
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
            recordType = "QUOTE ACCEPTED",
            oldValue = "QUOTED",
            newValue = "ACCEPTED (${activeQuote.quoteId})",
            reason = "COMMERCIAL CONTRACT CONVERSION",
            approvedBy = "SYSTEM AUTO-APPROVE"
        )
        val updatedAudit = _uiState.value.auditLogsList.toMutableList()
        updatedAudit.add(0, newAudit)

        _uiState.value = _uiState.value.copy(
            quotesList = currentQuotes,
            shipmentsList = updatedShipments,
            invoicesList = updatedInvoices,
            auditLogsList = updatedAudit,
            activeQuote = acceptedQuote,
            userNotification = "Quote ${activeQuote.quoteId} Accepted! Created Shipment $newShipmentId & Freight Invoice."
        )
    }

    fun clearNotification() {
        _uiState.value = _uiState.value.copy(userNotification = null)
    }
}
