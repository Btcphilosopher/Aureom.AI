package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.api.ApiExplorerScreen
import com.example.ui.checkout.CheckoutSdkDemoScreen
import com.example.ui.copilot.AmexCopilotScreen
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.marketplace.MarketplaceScreen

@Composable
fun AmexConnectApp(
    viewModel: AmexConnectViewModel = viewModel()
) {
    var activeTabIdx by remember { mutableStateOf(0) }

    val amexBlue = Color(0xFF006FCF)
    val goldColor = Color(0xFFC5A059)
    val brandNavy = Color(0xFF002244)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .testTag("app_navigation_bar")
                    .background(Color(0xFF0A0A0A)),
                containerColor = Color(0xFF0A0A0A),
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = activeTabIdx == 0,
                    onClick = { activeTabIdx = 0 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = "Dashboard"
                        )
                    },
                    label = { Text("Dashboard", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_item_dashboard"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF006FCF),
                        indicatorColor = Color(0xFF006FCF).copy(alpha = 0.2f),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    )
                )

                NavigationBarItem(
                    selected = activeTabIdx == 1,
                    onClick = { activeTabIdx = 1 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Checkout Frame Sandbox"
                        )
                    },
                    label = { Text("Checkout Frame", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_item_checkout"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF006FCF),
                        indicatorColor = Color(0xFF006FCF).copy(alpha = 0.2f),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    )
                )

                NavigationBarItem(
                    selected = activeTabIdx == 2,
                    onClick = { activeTabIdx = 2 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Verifiable Software Market"
                        )
                    },
                    label = { Text("Marketplace", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_item_marketplace"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF006FCF),
                        indicatorColor = Color(0xFF006FCF).copy(alpha = 0.2f),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    )
                )

                NavigationBarItem(
                    selected = activeTabIdx == 3,
                    onClick = { activeTabIdx == 3 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = "Developer API Testing Tool"
                        )
                    },
                    label = { Text("API Explorer", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_item_apiexplorer"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF006FCF),
                        indicatorColor = Color(0xFF006FCF).copy(alpha = 0.2f),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    )
                )

                NavigationBarItem(
                    selected = activeTabIdx == 4,
                    onClick = { activeTabIdx = 4 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "LLM Integration CoPilot"
                        )
                    },
                    label = { Text("Genius Copilot", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_item_copilot"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF006FCF),
                        indicatorColor = Color(0xFF006FCF).copy(alpha = 0.2f),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (activeTabIdx) {
                0 -> DashboardScreen(viewModel = viewModel)
                1 -> CheckoutSdkDemoScreen(viewModel = viewModel)
                2 -> MarketplaceScreen(viewModel = viewModel)
                3 -> ApiExplorerScreen(viewModel = viewModel)
                4 -> AmexCopilotScreen(viewModel = viewModel)
            }
        }
    }
}
