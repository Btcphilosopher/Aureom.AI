package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = AmexBrightBlue,
    secondary = CardGold,
    tertiary = IceBlueAccent,
    background = ElegantDarkBg,
    surface = ElegantDarkSurface,
    onPrimary = Color.White,
    onSecondary = ElegantDarkBg,
    onBackground = ElegantDarkText,
    onSurface = ElegantDarkText
  )

private val LightColorScheme =
  lightColorScheme(
    primary = AmexBrightBlue,
    secondary = AmexDarkBlue,
    tertiary = CardGold,
    background = ElegantDarkBg,
    surface = ElegantDarkSurface,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = ElegantDarkText,
    onSurface = ElegantDarkText
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  // Disable dynamic color to maintain strict brand theme fidelity
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
