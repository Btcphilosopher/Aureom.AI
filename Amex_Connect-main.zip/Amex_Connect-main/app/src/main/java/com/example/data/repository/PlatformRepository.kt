package com.example.data.repository

import com.example.data.database.AmexConnectDao
import com.example.data.model.Customer
import com.example.data.model.EventLog
import com.example.data.model.MarketplaceAsset
import com.example.data.model.Payment
import com.example.data.model.PurchasedLicense
import com.example.data.model.Subscription
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.security.MessageDigest
import java.util.UUID

class PlatformRepository(private val dao: AmexConnectDao) {

    val payments: Flow<List<Payment>> = dao.getAllPayments()
    val customers: Flow<List<Customer>> = dao.getAllCustomers()
    val subscriptions: Flow<List<Subscription>> = dao.getAllSubscriptions()
    val marketplaceAssets: Flow<List<MarketplaceAsset>> = dao.getAllMarketplaceAssets()
    val purchasedLicenses: Flow<List<PurchasedLicense>> = dao.getAllPurchasedLicenses()
    val eventLogs: Flow<List<EventLog>> = dao.getAllEventLogs()

    // Generate cryptographic-like hash for signatures
    private fun sha256Hex(text: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(text.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            UUID.randomUUID().toString().replace("-", "")
        }
    }

    suspend fun logEvent(type: String, message: String) {
        val event = EventLog(
            eventType = type,
            payload = "{\"timestamp\":${System.currentTimeMillis()},\"msg\":\"$message\"}",
            timestamp = System.currentTimeMillis()
        )
        dao.insertEventLog(event)
    }

    suspend fun clearEventLogs() {
        dao.clearEventLogs()
    }

    suspend fun prePopulateIfEmpty() {
        // Populate standard marketplace assets if none exist
        val assets = marketplaceAssets.first()
        if (assets.isEmpty()) {
            val mockAssets = listOf(
                MarketplaceAsset(
                    id = "ast_ai_inf_901",
                    name = "Decentralized AI Inference Node",
                    type = "AI Model",
                    description = "Enterprise-grade high-throughput Llama model node with browser-native RPC deployment capabilities.",
                    price = 1500.00,
                    version = "v3.1.2",
                    licenseType = "Enterprise License"
                ),
                MarketplaceAsset(
                    id = "ast_saas_ct_304",
                    name = "AMEX Connect Broker Platform",
                    type = "SaaS Platform",
                    description = "Automated high-frequency merchant settlement software with real-time multi-currency support.",
                    price = 250.00,
                    version = "v1.5.0",
                    licenseType = "Developer License"
                ),
                MarketplaceAsset(
                    id = "ast_ext_cent_104",
                    name = "Centurion Web3 Sovereign Extension",
                    type = "Browser Extension",
                    description = "Merchant digital proof key wallet enabling one-click tokenized Amex secure checkout on decentralized portals.",
                    price = 49.00,
                    version = "v2.0.4",
                    licenseType = "Lifetime License"
                ),
                MarketplaceAsset(
                    id = "ast_api_ledg_702",
                    name = "Sovereign Audit Ledger API",
                    type = "API",
                    description = "Cryptographically secure immutable audit logger. Seamlessly records PCI-DSS transaction histories.",
                    price = 3500.00,
                    version = "v4.1.0",
                    licenseType = "Enterprise License"
                )
            )
            for (valAsset in mockAssets) {
                dao.insertMarketplaceAsset(valAsset)
            }
            logEvent("SYSTEM_INIT", "Pre-populated market assets.")
        }

        val currents = payments.first()
        if (currents.isEmpty()) {
            logEvent("SYSTEM_INIT", "Seeding initial financial history...")

            // Seed Customers
            val cus1 = Customer(id = "cus_reg_8921", name = "Regis Philbin", email = "regis@philbin.com", cardToken = "tok_amex_278e91a03")
            val cus2 = Customer(id = "cus_jane_2309", name = "Jane Miller", email = "jane@millers.io", cardToken = "tok_amex_89e4c19a9")
            val cus3 = Customer(id = "cus_acme_7712", name = "Acme Global Enterprise", email = "procure@acmeglobal.com", cardToken = "tok_amex_cce410abf")

            dao.insertCustomer(cus1)
            dao.insertCustomer(cus2)
            dao.insertCustomer(cus3)

            logEvent("CUSTOMER_CREATED", "Customer Regis Philbin (cus_reg_8921) registered successfully.")
            logEvent("CUSTOMER_CREATED", "Customer Jane Miller (cus_jane_2309) registered successfully.")
            logEvent("CUSTOMER_CREATED", "Customer Acme Global Enterprise (cus_acme_7712) registered successfully.")

            // Seed Payments
            val day = 24 * 60 * 60 * 1000L
            val p1 = Payment(
                id = "pay_891bcfa39105",
                amount = 14500.00,
                currency = "USD",
                customerName = "Acme Global Enterprise",
                customerEmail = "procure@acmeglobal.com",
                status = "CAPTURED",
                riskScore = 14,
                riskLevel = "LOW",
                cardLast4 = "1007",
                timestamp = System.currentTimeMillis() - 4 * day,
                description = "Sovereign Audit Ledger API Deployment License",
                checkoutMode = "API"
            )
            val p2 = Payment(
                id = "pay_0129bcfe3401",
                amount = 250.00,
                currency = "USD",
                customerName = "Jane Miller",
                customerEmail = "jane@millers.io",
                status = "CAPTURED",
                riskScore = 22,
                riskLevel = "LOW",
                cardLast4 = "2002",
                timestamp = System.currentTimeMillis() - 2 * day,
                description = "AMEX Connect Broker Platform License",
                checkoutMode = "Embedded"
            )
            val p3 = Payment(
                id = "pay_cfee02341a02",
                amount = 1200.00,
                currency = "USD",
                customerName = "Regis Philbin",
                customerEmail = "regis@philbin.com",
                status = "AUTHORIZED",
                riskScore = 18,
                riskLevel = "LOW",
                cardLast4 = "1007",
                timestamp = System.currentTimeMillis() - 8 * 60 * 60 * 1000L,
                description = "Pre-authorization fee for Decentralized AI node setup",
                checkoutMode = "Hosted"
            )
            val p4 = Payment(
                id = "pay_fede90cba712",
                amount = 4900.00,
                currency = "USD",
                customerName = "Dr. Raymond Shaw",
                customerEmail = "raymond@shaw.com",
                status = "FAILED",
                riskScore = 89,
                riskLevel = "HIGH",
                cardLast4 = "8891",
                timestamp = System.currentTimeMillis() - 1 * day,
                description = "High-risk dynamic transaction trigger failure",
                checkoutMode = "Browser-Native"
            )

            dao.insertPayment(p1)
            dao.insertPayment(p2)
            dao.insertPayment(p3)
            dao.insertPayment(p4)

            logEvent("PAYMENT_CAPTURED", "Payment pay_891bcfa39105 for $14,500.00 CAPTURED securely via Amex-Centurion network.")
            logEvent("PAYMENT_CAPTURED", "Payment pay_0129bcfe3401 for $250.00 CAPTURED securely.")
            logEvent("PAYMENT_AUTHORIZED", "Payment pay_cfee02341a02 for $1,200.00 AUTHORIZED. Risk level: LOW.")
            logEvent("PAYMENT_FAILED", "Payment pay_fede90cba712 for $4,900.00 REJECTED by Amex Fraud Score Engine (velocity check failure).")

            // Seed Subscriptions
            val sub1 = Subscription(
                id = "sub_p190c1f",
                customerId = "cus_reg_8921",
                customerName = "Regis Philbin",
                planName = "AMEX Platform Master Plan",
                amount = 199.00,
                status = "ACTIVE"
            )
            dao.insertSubscription(sub1)
            logEvent("SUBSCRIPTION_CREATED", "Subscription sub_p190c1f for Regis Philbin (ACTIVE).")

            // Seed Purchased Licenses
            val signSpec = sha256Hex("lic_init_signature_for_${p1.id}_ast_api_ledg_702")
            val license = PurchasedLicense(
                licenseId = "lic_891bcfa3",
                assetId = "ast_api_ledg_702",
                assetName = "Sovereign Audit Ledger API",
                ownerEmail = "procure@acmeglobal.com",
                licenseType = "Enterprise License",
                pricePaid = 3500.00,
                cryptoSignature = "0x$signSpec",
                verificationMetadata = "{\"issuer\":\"AMEX-CONNECT\",\"ledgerBlock\":108422,\"signature_schema\":\"ED25519-AMEX\",\"timestamp\":${System.currentTimeMillis()}}"
            )
            dao.insertPurchasedLicense(license)
            logEvent("LICENSE_PURCHASED", "License lic_891bcfa3 compiled & cryptographically sealed for procure@acmeglobal.com")
            logEvent("DIGITAL_ASSET_PURCHASED", "Digital asset Sovereing Audit Ledger API acquired by Acme.")
            logEvent("DEPLOYMENT_COMPLETED", "Asset deploy completed to server ip https://amex-sovereign-node.acme.cloud")
        }
    }

    suspend fun executePayment(
        amount: Double,
        customerName: String,
        email: String,
        cardNum: String,
        description: String,
        checkoutMode: String
    ): Payment {
        // Run simulated fraud and security engine
        val cleanCard = cardNum.replace(" ", "")
        val cardLast4 = if (cleanCard.length >= 4) cleanCard.takeLast(4) else "2002"

        // Generate dynamic fraud score
        // High cards or strange amounts trigger higher risk
        var fraudScore = (10..40).random()
        if (amount > 10000.00) fraudScore += 15
        if (customerName.lowercase().contains("test")) fraudScore += 20
        if (cleanCard.startsWith("4")) fraudScore += 10 // Amex card numbers start with 3

        val riskLevel = when {
            fraudScore >= 75 -> "CRITICAL"
            fraudScore >= 50 -> "HIGH"
            fraudScore >= 30 -> "MEDIUM"
            else -> "LOW"
        }

        val paymentId = "pay_" + UUID.randomUUID().toString().replace("-", "").take(12)
        val status = if (riskLevel == "CRITICAL" || cleanCard.endsWith("404")) "FAILED" else "AUTHORIZED"

        val payment = Payment(
            id = paymentId,
            amount = amount,
            currency = "USD",
            customerName = customerName,
            customerEmail = email,
            status = status,
            riskScore = fraudScore,
            riskLevel = riskLevel,
            cardLast4 = cardLast4,
            description = description,
            checkoutMode = checkoutMode
        )

        dao.insertPayment(payment)

        if (status == "FAILED") {
            logEvent("PAYMENT_FAILED", "Transaction $paymentId failed: fraud Score engine flagged $riskLevel risk rating ($fraudScore/100).")
        } else {
            logEvent("PAYMENT_AUTHORIZED", "Amex Transaction $paymentId authorized (Risk score: $fraudScore, level: $riskLevel)")
        }

        return payment
    }

    suspend fun capturePayment(paymentId: String) {
        dao.updatePaymentStatus(paymentId, "CAPTURED")
        logEvent("PAYMENT_CAPTURED", "Transaction $paymentId settled on Amex secure ledger card networks. Merchant payout processing initialized.")
    }

    suspend fun refundPayment(paymentId: String) {
        dao.updatePaymentStatus(paymentId, "REFUNDED")
        logEvent("REFUND_CREATED", "Refund initiated for Transaction $paymentId. Funds returning to associated card account.")
    }

    suspend fun voidPayment(paymentId: String) {
        dao.updatePaymentStatus(paymentId, "VOIDED")
        logEvent("PAYMENT_FAILED", "Authorization voided for Transaction $paymentId.")
    }

    suspend fun createCustomer(name: String, email: String, cardNo: String): Customer {
        val cleanC = cardNo.replace(" ", "").takeLast(4)
        val token = "tok_amex_" + sha256Hex(name + UUID.randomUUID().toString()).take(12)
        val customer = Customer(name = name, email = email, cardToken = token)
        dao.insertCustomer(customer)
        logEvent("CUSTOMER_CREATED", "Registered custom profile '${customer.name}' with card token '${customer.cardToken}'")
        return customer
    }

    suspend fun createSubscription(customerId: String, customerName: String, planName: String, amount: Double): Subscription {
        val sub = Subscription(
            customerId = customerId,
            customerName = customerName,
            planName = planName,
            amount = amount,
            status = "ACTIVE"
        )
        dao.insertSubscription(sub)
        logEvent("SUBSCRIPTION_CREATED", "New subscription ${sub.id} initiated for $customerName. Billing plan: $planName.")
        return sub
    }

    suspend fun cancelSubscription(subId: String) {
        dao.updateSubscriptionStatus(subId, "CANCELED")
        logEvent("SUBSCRIPTION_RENEWED", "Subscription $subId canceled by merchant request. State modified to inactive.")
    }

    suspend fun purchaseMarketplaceAsset(
        assetId: String,
        customerName: String,
        email: String,
        cardNum: String
    ): PurchasedLicense? {
        val asset = marketplaceAssets.first().firstOrNull { it.id == assetId } ?: return null

        logEvent("MARKETPLACE_PURCHASE", "Initiating secure marketplace checkout for product [${asset.name}] via client card proxy...")

        // 1. Authorize Payment
        val payment = executePayment(
            amount = asset.price,
            customerName = customerName,
            email = email,
            cardNum = cardNum,
            description = "Marketplace purchase: ${asset.name} (${asset.licenseType})",
            checkoutMode = "Browser-Native"
        )

        if (payment.status == "FAILED") {
            return null
        }

        // 2. Capture Payment
        capturePayment(payment.id)
        logEvent("PAYMENT_SETTLED", "Payment for marketplace checkout ${payment.id} settled fully.")

        // 3. Generate secure cryptographic Web3 signature and unique License
        val licenseId = "lic_" + UUID.randomUUID().toString().replace("-", "").take(8)
        val signatureInput = "$licenseId::${asset.id}::${email}::${System.currentTimeMillis()}"
        val cryptSig = "0x" + sha256Hex(signatureInput)

        val meta = "{\"issuer\":\"AMEX-CONNECT\",\"verifiableProof\":true,\"blockchainTarget\":\"AMEX-PRIVATE-COMMERCE-CHAIN\",\"blockHeight\":129048,\"shaChecksum\":\"${asset.checksum}\"}"

        val license = PurchasedLicense(
            licenseId = licenseId,
            assetId = asset.id,
            assetName = asset.name,
            ownerEmail = email,
            licenseType = asset.licenseType,
            pricePaid = asset.price,
            cryptoSignature = cryptSig,
            verificationMetadata = meta
        )

        dao.insertPurchasedLicense(license)

        logEvent("LICENSE_PURCHASED", "License $licenseId purchased & minted to $email. Block verified securely.")
        logEvent("DIGITAL_ASSET_PURCHASED", "Digital Asset [${asset.name}] transfer completed successfully.")
        logEvent("DEPLOYMENT_COMPLETED", "Browser-native digital package deployed successfully. Check client device logs.")

        return license
    }
}
