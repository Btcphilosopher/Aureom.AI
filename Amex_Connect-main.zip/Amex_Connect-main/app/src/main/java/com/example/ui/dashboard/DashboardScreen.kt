package com.example.ui.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EventLog
import com.example.data.model.Payment
import com.example.ui.AmexConnectViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: AmexConnectViewModel,
    modifier: Modifier = Modifier
) {
    val payments by viewModel.payments.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val subscriptions by viewModel.subscriptions.collectAsState()
    val licenses by viewModel.purchasedLicenses.collectAsState()
    val events by viewModel.eventLogs.collectAsState()

    var selectedPaymentForRisk by remember { mutableStateOf<Payment?>(null) }

    // Aggregate statistics
    val totalVolume = payments.filter { it.status == "CAPTURED" }.sumOf { it.amount }
    val capturedCount = payments.filter { it.status == "CAPTURED" }.size
    val activeSubscriptionsCount = subscriptions.filter { it.status == "ACTIVE" }.size
    val totalLicensesCount = licenses.size

    val activeColor = MaterialTheme.colorScheme.primary
    val goldColor = Color(0xFFC5A059)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen_root")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header Section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ENTERPRISE PORTAL",
                        color = Color(0xFF94A3B8), // slate-400
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 2.sp
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AMEX ",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "CONNECT",
                            color = Color(0xFF006FCF),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-0.5).sp
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { viewModel.triggerCheckout() },
                        modifier = Modifier
                            .testTag("notification_bell")
                            .background(Color(0xFF0F172A), CircleShape)
                            .border(1.dp, Color(0xFF1E293B), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Quick notifications alert",
                            tint = goldColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFF1E293B), CircleShape)
                            .border(1.dp, Color(0xFF334155), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "JD",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Metrics Grid Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Large principal revenue card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF1E293B).copy(alpha = 0.4f), RoundedCornerShape(28.dp)),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF0F172A)
                    )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF006FCF),
                                        Color(0xFF004A8C)
                                    )
                                )
                            )
                            .padding(24.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "SETTLED VOLUME",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White.copy(alpha = 0.8f),
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "WEB3_SYNCED",
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = String.format("$%,.2f", totalVolume),
                                fontSize = 32.sp,
                                fontFamily = FontFamily.SansSerif,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = (-0.5).sp
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "ACTIVE LICENSES",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = "${totalLicensesCount} Nodes",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Column {
                                    Text(
                                        text = "AUTH RATE",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = "99.8%",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Column {
                                    Text(
                                        text = "HEALTH",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = "99.9ms",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF6EE7B7) // green-300
                                    )
                                }
                            }
                        }
                    }
                }

                // Split metrics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ElevatedCard(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "Sovereign Customers",
                                    tint = goldColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "CUSTOMERS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "${customers.size}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Tokenized Profiles",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )
                        }
                    }

                    ElevatedCard(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.List,
                                    contentDescription = "Active business subscriptions",
                                    tint = goldColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SUBSCRIBERS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "$activeSubscriptionsCount",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Contract Billing",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )
                        }
                    }

                    ElevatedCard(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = "Active deploy licenses",
                                    tint = goldColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "MINTED LIC",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "$totalLicensesCount",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Web3 Contracts",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )
                        }
                    }
                }
            }
        }

        // Live Canvas Transaction bar chart
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "NETWORK TRANSACTION CLEARING DENSITY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val points = listOf(140f, 220f, 180f, 320f, 280f, 410f, 360f, 480f)
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    ) {
                        val width = size.width
                        val height = size.height
                        val lineSpacing = width / (points.size - 1)

                        // Draw Grid lines
                        for (i in 1..3) {
                            val y = height * (i / 4f)
                            drawLine(
                                color = Color.White.copy(alpha = 0.08f),
                                start = Offset(0f, y),
                                end = Offset(width, y),
                                strokeWidth = 1f
                            )
                        }

                        // Draw continuous gradient area
                        val brush = Brush.verticalGradient(
                            colors = listOf(
                                activeColor.copy(alpha = 0.35f),
                                Color.Transparent
                            )
                        )

                        // Create geometric path points
                        val mappedPoints = points.mapIndexed { idx, value ->
                            val x = idx * lineSpacing
                            // scale value: max is roughly 550f
                            val scaledValue = value / 550f
                            val y = height - (scaledValue * height)
                            Offset(x, y)
                        }

                        // Draw lines & accent drops
                        for (i in 0 until mappedPoints.size - 1) {
                            val p1 = mappedPoints[i]
                            val p2 = mappedPoints[i + 1]
                            drawLine(
                                color = goldColor,
                                start = p1,
                                end = p2,
                                strokeWidth = 5f
                            )
                            // Draw circle anchors
                            drawCircle(
                                color = activeColor,
                                radius = 4f,
                                center = p1
                            )
                        }
                        // Draw last anchor point
                        drawCircle(
                            color = goldColor,
                            radius = 6f,
                            center = mappedPoints.last()
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("00:00 UTC", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                        Text("06:00", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                        Text("12:00", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                        Text("18:00", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                        Text("Now (Clear)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = goldColor)
                    }
                }
            }
        }

        // Selected Dynamic Fraud Risk Engine Diagnostics Panel
        item {
            Column {
                Text(
                    text = "DASHBOARD FRAUD ENGINE EVALUATOR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        if (selectedPaymentForRisk == null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Evaluate fraud",
                                    tint = goldColor,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Risk Analysis Engine Active",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Select any transaction below to load full velocity, geotracking telemetry, and secure compliance metrics.",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        } else {
                            val p = selectedPaymentForRisk!!
                            val isCritical = p.riskLevel == "CRITICAL" || p.riskLevel == "HIGH"
                            val bulletColor = if (isCritical) Color(0xFFEF4444) else Color(0xFF10B981)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(bulletColor, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Telemetry ID: ${p.id}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Text(
                                    text = "CLOSE Diagnostics",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = goldColor,
                                    modifier = Modifier
                                        .clickable { selectedPaymentForRisk = null }
                                        .padding(4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "DYNAMIC RISK SCORE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                                    Text(
                                        text = "${p.riskScore} / 100",
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace,
                                        color = bulletColor
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "CLASSIFICATION", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                                    Text(
                                        text = p.riskLevel,
                                        color = bulletColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }
                            }
                            Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurface.copy(0.1f))

                            // Anti-Fraud Checks checklist
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                RiskItem(
                                    name = "Platform Velocity Gate",
                                    desc = "Validates concurrent operations per card window.",
                                    status = if (p.amount > 6000.0) "WARNED (amount > threshold)" else "SECURE (1.0 req/m)",
                                    isPass = p.amount < 6000.0
                                )
                                RiskItem(
                                    name = "Device Fingerprint Token",
                                    desc = "Encrypted HSM container device pairing telemetry.",
                                    status = "VERIFIED (Amex-Trust Secure)",
                                    isPass = true
                                )
                                RiskItem(
                                    name = "IP Geolocation Routing",
                                    desc = "Coordinates network node match with customer profiles.",
                                    status = if (p.riskScore > 60) "SUSPICIOUS (IP mismatch)" else "VERIFIED (US-EST-1 node match)",
                                    isPass = p.riskScore <= 60
                                )
                                RiskItem(
                                    name = "PCI PAN Protection Shield",
                                    desc = "Primary credential mask shielding active card networks.",
                                    status = "ENCRYPTED (token proxy '${p.cardLast4}')",
                                    isPass = true
                                )
                            }
                        }
                    }
                }
            }
        }

        // List of recent transaction parameters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TRANSACTION CLEARING HISTORY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Text(
                    text = "${payments.size} items",
                    fontSize = 11.sp,
                    color = goldColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (payments.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No transactions logged in database.", color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                }
            }
        } else {
            items(payments) { p ->
                val cardColor = if (selectedPaymentForRisk?.id == p.id) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                } else {
                    MaterialTheme.colorScheme.surface
                }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payment_item_${p.id}")
                        .clickable { selectedPaymentForRisk = p },
                    colors = CardDefaults.cardColors(containerColor = cardColor)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Icon indicator based on status
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    when (p.status) {
                                        "CAPTURED" -> Color(0xFF10B981).copy(alpha = 0.15f)
                                        "AUTHORIZED" -> Color(0xFF3B82F6).copy(alpha = 0.15f)
                                        "REFUNDED" -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                        else -> Color(0xFFEF4444).copy(alpha = 0.15f)
                                    },
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (p.status) {
                                    "CAPTURED" -> Icons.Default.CheckCircle
                                    "AUTHORIZED" -> Icons.Default.Lock
                                    "REFUNDED" -> Icons.Default.Refresh
                                    else -> Icons.Default.Warning
                                },
                                contentDescription = p.status,
                                tint = when (p.status) {
                                    "CAPTURED" -> Color(0xFF10B981)
                                    "AUTHORIZED" -> Color(0xFF3B82F6)
                                    "REFUNDED" -> Color(0xFFF59E0B)
                                    else -> Color(0xFFEF4444)
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = p.customerName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = String.format("$%,.2f", p.amount),
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (p.status == "FAILED") Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Amex (•${p.cardLast4})",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = p.checkoutMode,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = goldColor
                                    )
                                }
                                Text(
                                    text = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(p.timestamp)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                            if (p.description.isNotBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = p.description,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // Ledger Audit log timeline
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "IMMUTABLE AUDIT LEDGER EVENTS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                IconButton(
                    onClick = { viewModel.clearLogs() },
                    modifier = Modifier.testTag("clear_logs_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear visual logs",
                        tint = goldColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        if (events.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.2f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Ledger empty. Trigger checkout to spawn platform events.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                    }
                }
            }
        } else {
            items(events.take(20)) { ev ->
                val (bulletColor, labelText) = when {
                    ev.eventType.contains("PAYMENT") || ev.eventType.contains("CHARGED") || ev.eventType.contains("CAPTURE") -> {
                        Color(0xFF10B981) to "Payment Captured"
                    }
                    ev.eventType.contains("LICENSE") || ev.eventType.contains("MINT") -> {
                        Color(0xFF8B5CF6) to "License Issued"
                    }
                    else -> {
                        Color(0xFF3B82F6) to "System Event"
                    }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("audit_event_${ev.id}")
                        .border(1.dp, Color(0xFF1E293B).copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Colored bullet
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(bulletColor, CircleShape)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (ev.eventType.isNotBlank()) ev.eventType.uppercase().replace("_", " ") else labelText.uppercase(),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = ev.payload.substringAfter("\"msg\":\"").substringBefore("\"}").uppercase(),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF64748B),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Text(
                            text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ev.timestamp)),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Final safe spacing spacer
        item {
            Spacer(modifier = Modifier.height(86.dp))
        }
    }
}

@Composable
fun RiskItem(name: String, desc: String, status: String, isPass: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = name, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(text = desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }
        Text(
            text = status,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isPass) Color(0xFF10B981) else Color(0xFFF59E0B),
            modifier = Modifier
                .background(
                    if (isPass) Color(0xFF10B981).copy(0.1f) else Color(0xFFF59E0B).copy(0.1f),
                    RoundedCornerShape(4.dp)
                )
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
