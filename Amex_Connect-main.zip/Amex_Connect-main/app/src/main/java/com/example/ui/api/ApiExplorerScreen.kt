package com.example.ui.api

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AmexConnectViewModel

@Composable
fun ApiExplorerScreen(
    viewModel: AmexConnectViewModel,
    modifier: Modifier = Modifier
) {
    val responseResult by viewModel.apiResponseResult.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    var selectedMethod by remember { mutableStateOf("POST") }
    var endpointInput by remember { mutableStateOf("/payments") }
    var jsonBodyInput by remember { mutableStateOf(paymentPresetBody) }

    val goldColor = Color(0xFFC5A059)
    val terminalBg = Color(0xFF090D14)

    // Api Route metadata presets
    val presets = listOf(
        RoutePreset("POST", "/payments", "Authorize Payment & Auto-Capture", paymentPresetBody),
        RoutePreset("POST", "/tokens/create", "Generate Secure HSM Token Proxy", tokenPresetBody),
        RoutePreset("POST", "/customers", "Create Customer Profile Entry", customerPresetBody),
        RoutePreset("POST", "/subscriptions", "Initialize Recurring Subscription Plan", subPresetBody),
        RoutePreset("POST", "/wallets/create", "Provision Sovereign Settlement Vault", walletPresetBody),
        RoutePreset("POST", "/settlements/create", "Clear Wire Settlements", clearingPresetBody),
        RoutePreset("POST", "/marketplace/deploy", "Provision Sandbox Deployments", deployPresetBody)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("api_explorer_root")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Form subheader
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "AMEX CONNECT DEVELOPERS",
                    color = goldColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Developer API Testing",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Awaiting REST-endpoint queries. Edit raw payloads below to test on-device clearing execution.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    fontSize = 12.sp
                )
            }
        }

        // Horizontal Selection Row for presets
        item {
            Column {
                Text(
                    text = "CHOOSE API QUERY PRESETS:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(presets) { p ->
                        val isSelected = endpointInput == p.path && selectedMethod == p.method
                        Card(
                            modifier = Modifier
                                .testTag("route_preset_${p.path.replace("/", "_")}")
                                .clickable {
                                    selectedMethod = p.method
                                    endpointInput = p.path
                                    jsonBodyInput = p.body
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) goldColor.copy(0.12f) else MaterialTheme.colorScheme.surface
                            ),
                            shape = RoundedCornerShape(8.dp),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, goldColor) else null
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = p.method,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (p.method == "POST") Color(0xFF10B981) else Color(0xFF3B82F6),
                                        modifier = Modifier
                                            .background(
                                                if (p.method == "POST") Color(0xFF10B981).copy(0.1f) else Color(0xFF3B82F6).copy(0.1f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = p.path,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = p.label,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(0.5f),
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Endpoint and Method Input fields
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "REST ROUTING GATEWAY PARAMETERS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = selectedMethod,
                            onValueChange = { selectedMethod = it },
                            label = { Text("Verb") },
                            modifier = Modifier
                                .width(90.dp)
                                .testTag("api_input_method"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = goldColor,
                                focusedLabelColor = goldColor
                            ),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                        )

                        OutlinedTextField(
                            value = endpointInput,
                            onValueChange = { endpointInput = it },
                            label = { Text("Resource Endpoint") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("api_input_endpoint"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = goldColor,
                                focusedLabelColor = goldColor
                            ),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                        )
                    }

                    OutlinedTextField(
                        value = jsonBodyInput,
                        onValueChange = { jsonBodyInput = it },
                        label = { Text("JSON Request Payload Block") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("api_input_body"),
                        maxLines = 6,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = goldColor,
                            focusedLabelColor = goldColor
                        ),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                    )

                    Button(
                        onClick = { viewModel.executeRawApiRequest(selectedMethod, endpointInput, jsonBodyInput) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("execute_api_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = goldColor),
                        enabled = !isProcessing
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Run Query",
                            tint = MaterialTheme.colorScheme.background,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isProcessing) "EXECUTING QUERY CHALLENGE..." else "EXECUTE MERCHANT API CHALLENGE",
                            color = MaterialTheme.colorScheme.background,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Output CLI Console Terminal
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = "Console",
                            tint = goldColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AMEX DEVS TERMINAL OUTPUT CONSOLE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                    Text(
                        text = "HTTP/1.1 SECURE",
                        fontSize = 9.sp,
                        color = Color(0xFF10B981),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(Color(0xFF10B981).copy(0.08f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(terminalBg, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = responseResult,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF38BDF8), // nice cyber sky blue terminal text
                        lineHeight = 16.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("terminal_output_text")
                    )
                }
            }
        }

        // Compliance guidance footnote
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Compliance Specs",
                        tint = goldColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Sandbox requests emulate complete payment handshakes, auto-generating mock TLS 1.3 encryption, and capturing event audits to secure Room database models.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                    )
                }
            }
        }

        // Final safe layout padding
        item {
            Spacer(modifier = Modifier.height(96.dp))
        }
    }
}

data class RoutePreset(
    val method: String,
    val path: String,
    val label: String,
    val body: String
)

// Request Body Constants
val paymentPresetBody = """{
  "amount": 299.50,
  "customerName": "Acme Global Enterprise",
  "customerEmail": "procure@acmeglobal.com",
  "cardNumber": "3782 822490 10007",
  "description": "Amex Sovereign API Seat Licensing fee"
}"""

val tokenPresetBody = """{
  "cardNumber": "3782 110004 22002",
  "cardholder": "Alice Operator Oracle",
  "pciSecureGate": true
}"""

val customerPresetBody = """{
  "name": "Jane Miller",
  "email": "jane@millers.io",
  "cardNumber": "3782 900100 22019"
}"""

val subPresetBody = """{
  "customerId": "cus_reg_8921",
  "customerName": "Regis Philbin",
  "planName": "AI Model Broker Sub Plan",
  "amount": 199.00
}"""

val walletPresetBody = """{
  "merchantId": "mch_amex_8812a02",
  "currencyTarget": "USD",
  "p2pAnchor": "0x-connected-mesh"
}"""

val clearingPresetBody = """{
  "amount": 12850.00,
  "settlementWirePath": "AMEX-ACBS-SWIFT",
  "clearingCode": "ACH-CENTURION-VAULT"
}"""

val deployPresetBody = """{
  "assetId": "ast_ai_inf_901",
  "ownerEmail": "buyer@sovereign.com",
  "licenseType": "Enterprise License"
}"""
