package com.example.ui.checkout

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.IconButton
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AmexConnectViewModel
import java.security.MessageDigest
import java.util.UUID

@Composable
fun CheckoutSdkDemoScreen(
    viewModel: AmexConnectViewModel,
    modifier: Modifier = Modifier
) {
    val amount by viewModel.checkoutAmount.collectAsState()
    val holder by viewModel.cardholderName.collectAsState()
    val number by viewModel.cardNumber.collectAsState()
    val expiry by viewModel.cardExpiry.collectAsState()
    val cvv by viewModel.cardCvv.collectAsState()
    val focusedSide by viewModel.cardFocusedSide.collectAsState()
    val description by viewModel.checkoutDescription.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val checkoutResult by viewModel.checkoutResult.collectAsState()

    val goldColor = Color(0xFFC5A059)
    val amexBlue = Color(0xFF006FCF)

    // Calculate interactive real-time risk simulation as user types
    val amtVal = amount.toDoubleOrNull() ?: 0.0
    var riskValue = 18
    if (amtVal > 1000.0) riskValue += 15
    if (amtVal > 10000.0) riskValue += 20
    if (holder.lowercase().contains("test")) riskValue += 25
    if (number.length < 15) riskValue += 5

    val currentRiskLevel = when {
        riskValue >= 60 -> "HIGH RISK"
        riskValue >= 40 -> "MEDIUM"
        else -> "LOW RISK"
    }
    val currentRiskColor = when {
        riskValue >= 60 -> Color(0xFFEF4444)
        riskValue >= 40 -> Color(0xFFF59E0B)
        else -> Color(0xFF10B981)
    }

    // Toggle 3D card rotation state
    val cardRotationY by animateFloatAsState(
        targetValue = if (focusedSide == "BACK") 180f else 0f,
        animationSpec = tween(durationMillis = 600)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("checkout_sdk_root")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Platform sub-header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "EMBEDDED AMEX CHECKOUT",
                    color = goldColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Checkout Frame Sandbox",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Demonstrate payment tokenization, real-time risk rating, and verifiable Web3 smart receipts.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    fontSize = 12.sp
                )
            }
        }

        // 3D-style credit card visual module
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .height(210.dp)
                    .graphicsLayer {
                        rotationY = cardRotationY
                        cameraDistance = 12f * density
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        viewModel.cardFocusedSide.value = if (focusedSide == "FRONT") "BACK" else "FRONT"
                    }
            ) {
                if (cardRotationY <= 90f) {
                    // Front side rendering
                    Card(
                        modifier = Modifier.fillMaxSize(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF131A26))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFF1B2330),
                                            Color(0xFF0F141C),
                                            Color(0xFF080B10)
                                        )
                                    )
                                )
                                .padding(20.dp)
                        ) {
                            // GLADIATOR WATERMARK EMBED
                            Box(
                                modifier = Modifier
                                    .size(100.dp)
                                    .align(Alignment.CenterEnd)
                                    .background(goldColor.copy(alpha = 0.05f), CircleShape)
                            ) {
                                Text(
                                    text = "AMEX",
                                    color = goldColor.copy(0.1f),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }

                            Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "AMERICAN EXPRESS",
                                            color = goldColor,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 12.sp,
                                            letterSpacing = 1.sp
                                        )
                                        Text(
                                            text = "CENTURION MEMBER",
                                            color = Color.White.copy(0.4f),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 8.sp,
                                            letterSpacing = 1.5.sp
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Contactless payment active",
                                        tint = goldColor,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                // Amex Chip representation
                                Box(
                                    modifier = Modifier
                                        .size(38.dp, 28.dp)
                                        .background(goldColor.copy(0.35f), RoundedCornerShape(4.dp))
                                        .border(1.dp, goldColor, RoundedCornerShape(4.dp))
                                )

                                // Ember embossed credit card spaces
                                Text(
                                    text = formatAmexCardNumber(number),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.5.sp
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Bottom
                                ) {
                                    Column {
                                        Text(
                                            text = "CARDHOLDER",
                                            fontSize = 8.sp,
                                            color = Color.White.copy(0.4f),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = holder.uppercase(),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = goldColor,
                                            maxLines = 1
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "EXPIRES",
                                            fontSize = 8.sp,
                                            color = Color.White.copy(0.4f),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = expiry,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "FRONT CVV",
                                            fontSize = 8.sp,
                                            color = Color.White.copy(0.4f),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = cvv,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Back side rendering (flipped)
                    Card(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { this.rotationY = 180f },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F141C))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(vertical = 16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Magnetic black strip
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(34.dp)
                                    .background(Color.Black)
                            )

                            // Signature Panel
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(32.dp)
                                        .background(Color.White)
                                        .padding(horizontal = 8.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(
                                        text = holder,
                                        fontFamily = FontFamily.Cursive,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color.DarkGray
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(45.dp, 28.dp)
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = cvv.takeLast(3),
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp,
                                        color = Color.Black
                                    )
                                }
                            }

                            // Centurion signature info note
                            Text(
                                text = "AMERICAN EXPRESS SECURITY SERVICES CO. INC. • AUTHORIZED SIGNATURE",
                                fontSize = 6.sp,
                                color = Color.White.copy(0.3f),
                                modifier = Modifier.padding(horizontal = 20.dp),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Live Anti-Fraud Diagnostic Widget
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = currentRiskColor.copy(alpha = 0.08f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Real-time risk scoring engine metric",
                            tint = currentRiskColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "PRE-TRANSACTION RISK RATING",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                            Text(
                                text = "Dynamic evaluation score: $riskValue/100",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = currentRiskLevel,
                        color = currentRiskColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .background(currentRiskColor.copy(0.15f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Checkout Inputs Panel
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = amount,
                            onValueChange = { viewModel.checkoutAmount.value = it },
                            label = { Text("Amount (USD)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("checkout_input_amount"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = goldColor,
                                focusedLabelColor = goldColor
                            )
                        )

                        OutlinedTextField(
                            value = expiry,
                            onValueChange = { viewModel.cardExpiry.value = it },
                            label = { Text("Expiry Date") },
                            placeholder = { Text("MM/YY") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("checkout_input_expiry"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = goldColor,
                                focusedLabelColor = goldColor
                            )
                        )
                    }

                    OutlinedTextField(
                        value = holder,
                        onValueChange = { viewModel.cardholderName.value = it },
                        label = { Text("Cardholder Full Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("checkout_input_holder"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = goldColor,
                            focusedLabelColor = goldColor
                        )
                    )

                    OutlinedTextField(
                        value = number,
                        onValueChange = {
                            viewModel.cardNumber.value = it.take(19) // limit digits max
                            viewModel.cardFocusedSide.value = "FRONT"
                        },
                        label = { Text("Amex 15-Digit Card Number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("checkout_input_cardnum"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = goldColor,
                            focusedLabelColor = goldColor
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = cvv,
                            onValueChange = {
                                viewModel.cardCvv.value = it.take(4) // amex card digits CVV
                                if (it.length == 3) {
                                    viewModel.cardFocusedSide.value = "BACK"
                                } else {
                                    viewModel.cardFocusedSide.value = "FRONT"
                                }
                            },
                            label = { Text("CVV/PIN Code") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("checkout_input_cvv"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = goldColor,
                                focusedLabelColor = goldColor
                            )
                        )

                        OutlinedTextField(
                            value = description,
                            onValueChange = { viewModel.checkoutDescription.value = it },
                            label = { Text("Invoice Description") },
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("checkout_input_desc"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = goldColor,
                                focusedLabelColor = goldColor
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (isProcessing) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = goldColor,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    } else {
                        Button(
                            onClick = { viewModel.triggerCheckout() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("checkout_purchase_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = amexBlue
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Lock",
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "AUTHORIZE & PURCHASE: \$${amount}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Live Processing Event Outcome Overlay / Panel
        item {
            AnimatedVisibility(visible = checkoutResult != null) {
                val isSuccess = checkoutResult == "SUCCESS"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSuccess) Color(0xFF0F2D24) else Color(0xFF331616)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isSuccess) "TRANSACTION SETTLED FULLY" else "AUTH SECURITY REJECTION",
                                color = if (isSuccess) Color(0xFF10B981) else Color(0xFFEF4444),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp
                            )
                            IconButton(onClick = { viewModel.resetCheckoutStatus() }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Clear result alert banner",
                                    tint = Color.White.copy(alpha = 0.5f),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        if (isSuccess) {
                            Text(
                                text = "Your American Express transaction settled on the clearing platform.",
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            // Display cryptographic verifiable receipt receipt
                            Text(
                                text = "CRYPTOGRAPHIC BLOCK VERIFICATION:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = goldColor
                            )
                            Text(
                                text = "MINT_SIG: 0x${sha256Hex(holder + amount + System.currentTimeMillis().toString()).take(24)}...\nNET_LEDGER: AMEX-CONNECTED-LE-44129\nPCI_VAULT_TOKEN: tok_amex_sec_${sha256Hex(number).take(10)}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Color.LightGray.copy(0.7f),
                                modifier = Modifier
                                    .background(Color.Black.copy(0.3f), RoundedCornerShape(4.dp))
                                    .fillMaxWidth()
                                    .padding(8.dp)
                            )
                        } else {
                            Text(
                                text = "Operational denial: The anti-fraud analyzer engine flagged critical transaction risks. The credential card has been locked temporarily.",
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Final safe spacing spacer
        item {
            Spacer(modifier = Modifier.height(96.dp))
        }
    }
}

// Spacings for Amex dynamic formatting representation
private fun formatAmexCardNumber(rawText: String): String {
    val clean = rawText.replace(" ", "")
    var formatted = ""
    for (i in clean.indices) {
        formatted += clean[i]
        // Amex cards are 15 digits spaced as 4-6-5: xxxx xxxxxxx xxxxx
        if (i == 3 || i == 9) {
            formatted += " "
        }
    }
    return formatted.trim()
}

private fun sha256Hex(text: String): String {
    return try {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(text.toByteArray(Charsets.UTF_8))
        hash.joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        UUID.randomUUID().toString().replace("-", "")
    }
}
