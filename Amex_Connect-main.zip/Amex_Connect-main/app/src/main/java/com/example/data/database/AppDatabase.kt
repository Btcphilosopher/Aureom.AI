package com.example.data.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import com.example.data.model.Customer
import com.example.data.model.EventLog
import com.example.data.model.MarketplaceAsset
import com.example.data.model.Payment
import com.example.data.model.PurchasedLicense
import com.example.data.model.Subscription
import kotlinx.coroutines.flow.Flow

@Dao
interface AmexConnectDao {
    // Payments
    @Query("SELECT * FROM payments ORDER BY timestamp DESC")
    fun getAllPayments(): Flow<List<Payment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment)

    @Query("UPDATE payments SET status = :status WHERE id = :id")
    suspend fun updatePaymentStatus(id: String, status: String)

    // Customers
    @Query("SELECT * FROM customers ORDER BY created DESC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer)

    // Subscriptions
    @Query("SELECT * FROM subscriptions ORDER BY created DESC")
    fun getAllSubscriptions(): Flow<List<Subscription>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(subscription: Subscription)

    @Query("UPDATE subscriptions SET status = :status WHERE id = :id")
    suspend fun updateSubscriptionStatus(id: String, status: String)

    // Marketplace Assets
    @Query("SELECT * FROM marketplace_assets ORDER BY name ASC")
    fun getAllMarketplaceAssets(): Flow<List<MarketplaceAsset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarketplaceAsset(asset: MarketplaceAsset)

    // Purchased Licenses
    @Query("SELECT * FROM purchased_licenses ORDER BY purchasedAt DESC")
    fun getAllPurchasedLicenses(): Flow<List<PurchasedLicense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchasedLicense(license: PurchasedLicense)

    // Event Logs
    @Query("SELECT * FROM event_logs ORDER BY timestamp DESC")
    fun getAllEventLogs(): Flow<List<EventLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEventLog(eventLog: EventLog)

    @Query("DELETE FROM event_logs")
    suspend fun clearEventLogs()
}

@Database(
    entities = [
        Payment::class,
        Customer::class,
        Subscription::class,
        MarketplaceAsset::class,
        PurchasedLicense::class,
        EventLog::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun amexConnectDao(): AmexConnectDao
}
