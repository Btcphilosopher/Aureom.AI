package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Amex Dark/Light Brand Theme
val AmexDarkBlue = Color(0xFF002244)  // Centurion Deep Navy
val AmexBrightBlue = Color(0xFF006FCF)  // Classic Amex Card Blue
val CardGold = Color(0xFFC5A059)  // Amex Gold Accent
val CoolSlate = Color(0xFF1E293B)  // Dark slate for containers
val CenturionSlate = Color(0xFF0A0A0A)  // Dark luxury background (#0a0a0a)
val PlatinumGray = Color(0xFFF1F5F9)  // Slate-100 grey text
val IceBlueAccent = Color(0xFF38BDF8)  // Modern cyber accent

// Elegant Dark spec colors
val ElegantDarkBg = Color(0xFF0A0A0A)
val ElegantDarkSurface = Color(0xFF0F172A) // slate-900 container
val ElegantDarkBorder = Color(0xFF1E293B)  // slate-800 border
val ElegantDarkTextMuted = Color(0xFF94A3B8) // slate-400 text
val ElegantDarkText = Color(0xFFF8FAFC) // slate-50 text

val Blue80 = Color(0xFF8DC6FF)
val BlueGrey80 = Color(0xFFB0C4DE)
val Ice80 = Color(0xFFE0F7FA)

val Blue40 = Color(0xFF005691)
val BlueGrey40 = Color(0xFF4682B4)
val Ice40 = Color(0xFF00838F)
