package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey val id: String = "pay_" + UUID.randomUUID().toString().replace("-", "").take(12),
    val amount: Double,
    val currency: String = "USD",
    val customerName: String,
    val customerEmail: String = "",
    val status: String, // AUTHORIZED, CAPTURED, REFUNDED, VOIDED, FAILED
    val riskScore: Int, // 0 - 100
    val riskLevel: String, // LOW, MEDIUM, HIGH, CRITICAL
    val cardLast4: String = "2002", // standard mock Amex centenary
    val cardBrand: String = "American Express",
    val timestamp: Long = System.currentTimeMillis(),
    val description: String = "",
    val checkoutMode: String = "Embedded" // Embedded, Hosted, Browser-Native, API
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String = "cus_" + UUID.randomUUID().toString().replace("-", "").take(12),
    val name: String,
    val email: String,
    val cardToken: String,
    val created: Long = System.currentTimeMillis()
)

@Entity(tableName = "subscriptions")
data class Subscription(
    @PrimaryKey val id: String = "sub_" + UUID.randomUUID().toString().replace("-", "").take(12),
    val customerId: String,
    val customerName: String,
    val planName: String,
    val amount: Double,
    val status: String, // ACTIVE, CANCELED
    val nextRenewal: Long = System.currentTimeMillis() + 30 * 24 * 60 * 60 * 1000L, // 30 days later
    val created: Long = System.currentTimeMillis()
)

@Entity(tableName = "marketplace_assets")
data class MarketplaceAsset(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // AI Model, SaaS, API, Browser Extension, Enterprise Software
    val description: String,
    val price: Double,
    val version: String,
    val licenseType: String, // Enterprise, Developer, Lifetime, Subscription
    val checksum: String = UUID.randomUUID().toString().substring(0, 16)
)

@Entity(tableName = "purchased_licenses")
data class PurchasedLicense(
    @PrimaryKey val licenseId: String = "lic_" + UUID.randomUUID().toString().replace("-", "").take(12),
    val assetId: String,
    val assetName: String,
    val ownerEmail: String,
    val licenseType: String,
    val pricePaid: Double,
    val cryptoSignature: String, // Cryptographic mock signature
    val verificationMetadata: String, // JSON metadata verifying ledger blocks
    val purchasedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "event_logs")
data class EventLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val eventType: String, // PAYMENT_AUTHORIZED, PAYMENT_CAPTURED, etc.
    val payload: String,
    val timestamp: Long = System.currentTimeMillis()
)
