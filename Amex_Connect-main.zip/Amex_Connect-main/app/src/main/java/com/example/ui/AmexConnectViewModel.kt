package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.database.AppDatabase
import com.example.data.model.Customer
import com.example.data.model.EventLog
import com.example.data.model.MarketplaceAsset
import com.example.data.model.Payment
import com.example.data.model.PurchasedLicense
import com.example.data.model.Subscription
import com.example.data.repository.PlatformRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import okhttp3.MediaType.Companion.toMediaTypeOrNull

class AmexConnectViewModel(application: Application) : AndroidViewModel(application) {

    private val database: AppDatabase by lazy {
        Room.databaseBuilder(
            application,
            AppDatabase::class.java,
            "amex_connect_db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    val repository: PlatformRepository by lazy {
        PlatformRepository(database.amexConnectDao())
    }

    // UI Reactiveness via Flow
    val payments: StateFlow<List<Payment>> by lazy {
        repository.payments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    val customers: StateFlow<List<Customer>> by lazy {
        repository.customers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    val subscriptions: StateFlow<List<Subscription>> by lazy {
        repository.subscriptions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    val marketplaceAssets: StateFlow<List<MarketplaceAsset>> by lazy {
        repository.marketplaceAssets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    val purchasedLicenses: StateFlow<List<PurchasedLicense>> by lazy {
        repository.purchasedLicenses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    val eventLogs: StateFlow<List<EventLog>> by lazy {
        repository.eventLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    // Interactive Checkout Form State
    var checkoutAmount = MutableStateFlow("149.00")
    var cardholderName = MutableStateFlow("David Rockefeller")
    var cardNumber = MutableStateFlow("3782 822490 10007") // Valid Amex format prefix
    var cardExpiry = MutableStateFlow("12/28")
    var cardCvv = MutableStateFlow("2002") // Amex has 4-digit CVV on front
    var cardFocusedSide = MutableStateFlow("FRONT") // FRONT, BACK
    var checkoutDescription = MutableStateFlow("SLA Developer API Seat")

    // Transaction Processing State Indicator
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _checkoutResult = MutableStateFlow<String?>(null) // success, failed, or error
    val checkoutResult: StateFlow<String?> = _checkoutResult.asStateFlow()

    // Gemini Chat Copilot State
    @androidx.annotation.Keep
    data class ChatMessage(val sender: String, val text: String, val timestamp: Long = System.currentTimeMillis())

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("assistant", "Greetings. I am the AMEX CONNECT Integration Specialist. You can ask me to write Amex Web3 API examples (Kotlin, Java, TypeScript, Swift), assist with PCI-DSS audit specs, or review transaction risks.")
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    init {
        viewModelScope.launch {
            // Seed DB on start
            repository.prePopulateIfEmpty()
        }
    }

    // Checkout payment flow simulation
    fun triggerCheckout() {
        viewModelScope.launch {
            if (_isProcessing.value) return@launch
            _isProcessing.value = true
            _checkoutResult.value = null

            val amt = checkoutAmount.value.toDoubleOrNull() ?: 1.00
            val card = cardNumber.value.replace(" ", "")

            delay(1200) // Simulate payment gateway handshakes

            try {
                val payment = repository.executePayment(
                    amount = amt,
                    customerName = cardholderName.value,
                    email = if (cardholderName.value.lowercase().contains("rockefeller")) "david@rockefeller.org" else "client@merchant.com",
                    cardNum = card,
                    description = checkoutDescription.value,
                    checkoutMode = "Embedded"
                )

                delay(900) // Capture processing transition

                if (payment.status != "FAILED") {
                    repository.capturePayment(payment.id)
                    _checkoutResult.value = "SUCCESS"
                } else {
                    _checkoutResult.value = "FAILED"
                }
            } catch (e: Exception) {
                _checkoutResult.value = "ERROR: ${e.message}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun resetCheckoutStatus() {
        _checkoutResult.value = null
    }

    // Marketplace Purchase Wrapper
    fun buyAsset(assetId: String, callback: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isProcessing.value = true
            val name = cardholderName.value
            val email = if (name.lowercase().contains("rockefeller")) "david@rockefeller.org" else "buyer@sovereign.com"
            val card = cardNumber.value

            val license = repository.purchaseMarketplaceAsset(
                assetId = assetId,
                customerName = name,
                email = email,
                cardNum = card
            )
            _isProcessing.value = false
            callback(license != null)
        }
    }

    // Actions
    fun refundPayment(paymentId: String) {
        viewModelScope.launch {
            repository.refundPayment(paymentId)
        }
    }

    fun voidPayment(paymentId: String) {
        viewModelScope.launch {
            repository.voidPayment(paymentId)
        }
    }

    fun cancelSub(subId: String) {
        viewModelScope.launch {
            repository.cancelSubscription(subId)
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearEventLogs()
            repository.logEvent("SYSTEM_CLEARED", "Developer cleared event log terminal.")
        }
    }

    // Simulated API Playground executor
    private val _apiResponseResult = MutableStateFlow("{\n  \"status\": \"Awaiting Request Execution\"\n}")
    val apiResponseResult: StateFlow<String> = _apiResponseResult.asStateFlow()

    fun executeRawApiRequest(method: String, endpoint: String, jsonBody: String) {
        viewModelScope.launch(Dispatchers.Default) {
            withContext(Dispatchers.Main) {
                _isProcessing.value = true
            }
            delay(600) // realistic network roundtrip

            val dateStr = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss", Locale.US).format(Date())
            val requestLog = "API_REQUEST_RECEIVED"
            val path = endpoint.trim().lowercase()

            val response = try {
                val json = if (jsonBody.isNotBlank()) JSONObject(jsonBody) else JSONObject()
                when {
                    method == "POST" && path.contains("/payments") -> {
                        val amount = json.optDouble("amount", 299.00)
                        val name = json.optString("customerName", "Anonymous Merchant")
                        val email = json.optString("customerEmail", "dev@merchant.com")
                        val desc = json.optString("description", "Enterprise API Subscription")
                        val card = json.optString("cardNumber", "378282249010007")

                        val p = repository.executePayment(amount, name, email, card, desc, "API")
                        if (p.status != "FAILED") {
                            repository.capturePayment(p.id)
                        }

                        JSONObject().apply {
                            put("id", p.id)
                            put("object", "payment_intent")
                            put("amount", p.amount)
                            put("currency", p.currency)
                            put("status", if (p.status == "FAILED") "failed" else "succeeded")
                            put("customer_name", p.customerName)
                            put("risk_score", p.riskScore)
                            put("risk_classification", p.riskLevel)
                            put("pci_card_last4", p.cardLast4)
                        }.toString(2)
                    }

                    method == "POST" && path.contains("/customers") -> {
                        val name = json.optString("name", "John Developer")
                        val email = json.optString("email", "john@devops.sh")
                        val card = json.optString("cardNumber", "378211110000002")

                        val c = repository.createCustomer(name, email, card)
                        JSONObject().apply {
                            put("id", c.id)
                            put("object", "customer")
                            put("name", c.name)
                            put("email", c.email)
                            put("card_token", c.cardToken)
                            put("created_at", c.created)
                        }.toString(2)
                    }

                    method == "POST" && path.contains("/subscriptions") -> {
                        val cusId = json.optString("customerId", "cus_reg_8921")
                        val cusName = json.optString("customerName", "Regis Philbin")
                        val plan = json.optString("planName", "Developer Pro Node Pack")
                        val price = json.optDouble("amount", 99.00)

                        val s = repository.createSubscription(cusId, cusName, plan, price)
                        JSONObject().apply {
                            put("id", s.id)
                            put("object", "subscription")
                            put("customer_id", s.customerId)
                            put("plan", s.planName)
                            put("price", s.amount)
                            put("status", s.status)
                            put("next_bill_epoch", s.nextRenewal)
                        }.toString(2)
                    }

                    method == "POST" && path.contains("/tokens/create") -> {
                        val card = json.optString("cardNumber", "3782 000022 11001")
                        val holder = json.optString("cardholder", "Sovereign Node Proxy")
                        val token = "tok_amex_sec_" + sha256Hex(card + holder).take(12)

                        repository.logEvent("TOKEN_MINTED", "Created secure PCI-compliant card token proxy $token")
                        JSONObject().apply {
                            put("object", "card_token")
                            put("token", token)
                            put("brand", "American Express")
                            put("pci_dss_compliant", true)
                            put("encryption_algorithm", "HSM-AES256")
                        }.toString(2)
                    }

                    method == "POST" && path.contains("/wallets/create") -> {
                        val walletId = "wlt_amex_" + UUID.randomUUID().toString().replace("-", "").take(8)
                        repository.logEvent("WALLET_CREATED", "Initialized wallet container $walletId for digital identity settlement.")
                        JSONObject().apply {
                            put("wallet_id", walletId)
                            put("object", "merchant_wallet")
                            put("status", "ACTIVE")
                            put("supported_networks", listOf("Amex ExpressPay", "Web3 Verifiable Invoices"))
                            put("p2p_channel", "0x-network")
                        }.toString(2)
                    }

                    method == "POST" && path.contains("/settlements/create") -> {
                        val settlementId = "set_amex_" + System.currentTimeMillis().toString().takeLast(6)
                        val amt = json.optDouble("amount", 5400.0)
                        repository.logEvent("PAYMENT_SETTLED", "Created electronic corporate clearing record $settlementId for $amt")
                        JSONObject().apply {
                            put("settlement_id", settlementId)
                            put("amount", amt)
                            put("clearing_house", "Amex Central Bank Settlement (ACBS)")
                            put("wire_id", "WX-" + UUID.randomUUID().toString().take(6).uppercase())
                            put("status", "CLEARED")
                        }.toString(2)
                    }

                    method == "POST" && path.contains("/marketplace/deploy") -> {
                        val assetId = json.optString("assetId", "ast_ai_inf_901")
                        val owner = json.optString("ownerEmail", "operator@oracles.net")
                        val license = "lic_sandbox_" + UUID.randomUUID().toString().take(6)
                        repository.logEvent("DEPLOYMENT_COMPLETED", "Deployed sandbox package $assetId to remote Web3 host oracle.")
                        JSONObject().apply {
                            put("license_id", license)
                            put("asset_id", assetId)
                            put("deployment_status", "PROVISIONED")
                            put("host_cluster", "Amex Connected Sovereign Grid")
                            put("cryptographic_hash", "0x" + sha256Hex(license + assetId))
                        }.toString(2)
                    }

                    else -> {
                        JSONObject().apply {
                            put("error", "Routing error")
                            put("message", "The specified API Resource endpoint '$method $endpoint' was not identified by AMEX CONNECT route registers.")
                            put("suggested_endpoints", listOf("POST /payments", "POST /customers", "POST /subscriptions", "POST /tokens/create", "POST /wallets/create", "POST /settlements/create", "POST /marketplace/deploy"))
                        }.toString(2)
                    }
                }
            } catch (e: Exception) {
                JSONObject().apply {
                    put("error", "Malformed Payload")
                    put("message", e.message)
                }.toString(2)
            }

            withContext(Dispatchers.Main) {
                _apiResponseResult.value = response
                _isProcessing.value = false
            }
        }
    }


    // Direct Gemini REST client implementation
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = ChatMessage("user", text)
        _chatMessages.value = _chatMessages.value + userMsg

        viewModelScope.launch {
            _isChatLoading.value = true

            val systemInstr = """
                You are AMEX CONNECT Enterprise Payments Architect & Web3 Specialist.
                You assist developers, compliance officers, and fintech engineers with American Express integration, modern payment processing, tokenized card metrics, Web3 commerce, PCI-DSS compliance specifications, and software license design.
                Reply clearly, professionally, and with expertise. Provide complete readable Kotlin, Java, Swift, or TypeScript snippets if asked. Keep replies friendly but enterprise-serious. No marketing hype.
            """.trimIndent()

            val fallbackPrompt = """
                The user asks: $text
                Formulate a helpful and highly knowledgeable answer outlining the proper payment flow and code logic for AMEX CONNECT.
                Include a code snippet (for example in Kotlin or TypeScript) detailing custom card authorization, or license audit tracking if relevant.
            """.trimIndent()

            val rawResult = try {
                // Call actual Gemini API if available, else fallback cleanly
                val apiKey = com.example.BuildConfig.GEMINI_API_KEY
                if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
                    val prompt = "$text\n\n(Provide direct, informative answers in Markdown format. Keep explanations technical and exact.)"
                    val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
                    val jsonReq = org.json.JSONObject().apply {
                        put("contents", org.json.JSONArray().put(org.json.JSONObject().apply {
                            put("parts", org.json.JSONArray().put(org.json.JSONObject().apply {
                                put("text", prompt)
                            }))
                        }))
                        put("systemInstruction", org.json.JSONObject().apply {
                            put("parts", org.json.JSONArray().put(org.json.JSONObject().apply {
                                put("text", systemInstr)
                            }))
                        })
                    }
                    val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()!!
                    val body = okhttp3.RequestBody.create(mediaType, jsonReq.toString())
                    val request = okhttp3.Request.Builder().url(url).post(body).build()
                    val client = okhttp3.OkHttpClient.Builder()
                        .connectTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                        .build()
                        
                    var resultText: String? = null
                    withContext(Dispatchers.IO) {
                        client.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val respStr = response.body?.string() ?: ""
                                val jsonResp = org.json.JSONObject(respStr)
                                val candidates = jsonResp.getJSONArray("candidates")
                                if (candidates.length() > 0) {
                                    val firstCandidate = candidates.getJSONObject(0)
                                    val contentObj = firstCandidate.getJSONObject("content")
                                    val partsArr = contentObj.getJSONArray("parts")
                                    if (partsArr.length() > 0) {
                                        resultText = partsArr.getJSONObject(0).getString("text")
                                    }
                                }
                            }
                        }
                    }
                    resultText ?: "No response from Gemini node. How can I assist you with integration?"
                } else {
                    simulateIntegrationGeniusResponse(text)
                }
            } catch (e: Exception) {
                "Amex Connect Central Oracle experienced an operational anomaly: ${e.localizedMessage}. However, I can state that standard merchant authorization is handled with secure tokens inside American Express and PCI-certified HSM gateways."
            }

            _chatMessages.value = _chatMessages.value + ChatMessage("assistant", rawResult)
            _isChatLoading.value = false
        }
    }

    // High quality mock responses for users running offline or without keys
    private fun simulateIntegrationGeniusResponse(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("code") || q.contains("kotlin") || q.contains("sdk") || q.contains("java") -> {
                """
                ### AMEX CONNECT Integration: Kotlin Server SDK Pattern
                
                To initialize payments from security certified environments, developers consume the `AmexMerchantGateway` pipeline. Below is the production implementation scheme:
                
                ```kotlin
                import com.amex.connect.gateway.AmexMerchantGateway
                import com.amex.connect.model.PaymentIntentResult
                import com.amex.connect.model.Amount
                
                class SettlementService(private val amexGateway: AmexMerchantGateway) {
                    
                    suspend fun processEnterpriseInvoice(
                        customerId: String,
                        invoiceAmountSecured: Double
                    ): PaymentIntentResult {
                        // Create a secure processing intent bound to specific telemetry fingerprinting
                        val connectionIntent = amexGateway.payments().createIntent(
                            amount = Amount.ofUSD(invoiceAmountSecured),
                            customerReference = customerId,
                            captureMethod = "AUTOMATIC",
                            idempotencyKey = "idem_" + System.currentTimeMillis()
                        )
                        
                        // Execute authorization on the secure Amex Centurion core
                        return amexGateway.payments().authorize(connectionIntent.intentId)
                    }
                }
                ```
                
                For client checkout setups, verify with the **Checkout SDK** tab using browser-native frame containment. We enforce tokenization to prevent exposure of primary account numbers (PAN) on merchant devices.
                """.trimIndent()
            }
            q.contains("pci") || q.contains("compliance") || q.contains("secure") || q.contains("audit") -> {
                """
                ### PCI-DSS v4.0 Compliance Blueprint
                
                AMEX CONNECT enforces Zero-Trust architecture down to the browser level:
                1. **Tokenization (PAN Protection)**: Under PCI compliance, primary card numbers must never enter merchant application memory. Our front-end SDK generates a secure cryptographic token proxy (`tok_amex_xxxx`) directly with American Express vaults.
                2. **Encryption In-Flight**: All client-to-platform operations use TLS 1.3 with AES-256-GCM cipher-suites.
                3. **On-Chain Audit Records**: All ledger activities map to immutable event blocks. This lets auditors instantly query the payment timeline and run cryptographic verification on settlement accounts.
                """.trimIndent()
            }
            q.contains("web3") || q.contains("blockchain") || q.contains("license") || q.contains("digital") || q.contains("asset") -> {
                """
                ### Web3 Sovereign Digital Commerce Pipeline
                
                AMEX CONNECT resolves one of payments' toughest issues: linking traditional fiat networks to cryptographically verified digital software licenses.
                
                **Ledger Execution Flow:**
                1. Card Authorization on American Express payment networks.
                2. On-chain validation of asset checksum parameters.
                3. Generation of verification metadata, including:
                   * Cryptographic Issuer Key (AMEX-CONNECT Proof Service)
                   * Public Key SHA signature matching the licensing model
                   * Automatic block timestamp records
                4. Deployment hook execution to merchant-side hosts.
                
                This creates standard financial ledger compliance side-by-side with modern sovereign asset integrity. Review the **Marketplace** page, where clicking "Select Product" simulates the complete loop!
                """.trimIndent()
            }
            else -> {
                """
                ### Amex Connect Integration Intelligence Center
                
                I have analyzed your query concerning **"${query}"**.
                
                **Platform Architectural Highlights:**
                * **Unified Vaults**: Seamlessly handles Amex Centurion credit accounts alongside modern digital asset clearing accounts (`POST /wallets/create`).
                * **Enterprise Ledgers**: Every transaction and system audit writes directly to our secure immutable Room engine, raising dynamic events (e.g. `PAYMENT_AUTHORIZED`, `LICENSE_PURCHASED`) on each state shift.
                * **Adaptive Anti-Fraud Engine**: Checks velocity parameters, device signatures, and geolocations in real-time. HIGH-rated anomalies trigger automated step-up verification.
                
                Please navigate to the various tabs inside **Amex Connect** to run interactive card checkouts, query real REST outputs in the API playground, or deploy software packages with cryptographic proof chains!
                """.trimIndent()
            }
        }
    }

    private fun sha256Hex(input: String): String {
        return try {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(input.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "abc123789xyz"
        }
    }
}
