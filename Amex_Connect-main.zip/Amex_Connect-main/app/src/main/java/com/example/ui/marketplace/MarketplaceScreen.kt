package com.example.ui.marketplace

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarketplaceAsset
import com.example.data.model.PurchasedLicense
import com.example.ui.AmexConnectViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MarketplaceScreen(
    viewModel: AmexConnectViewModel,
    modifier: Modifier = Modifier
) {
    val assets by viewModel.marketplaceAssets.collectAsState()
    val ownedLicenses by viewModel.purchasedLicenses.collectAsState()
    val cardholder by viewModel.cardholderName.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0 = Storefront, 1 = Owned Licenses
    var selectedAssetForPurchase by remember { mutableStateOf<MarketplaceAsset?>(null) }
    var deployPhase by remember { mutableStateOf("IDLE") } // IDLE, CLEARING, MINTING, PROVISIONING, SUCCESS, FAILED

    val goldColor = Color(0xFFC5A059)
    val amexBlue = Color(0xFF006FCF)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("marketplace_screen_root")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Platform Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "AMEX SOVEREIGN NETWORK",
                    color = goldColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Digital Asset Marketplace",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Procure websites, microservices, AI nodes, and enterprise packages with cryptographic billing clearance.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    fontSize = 12.sp
                )
            }
        }

        // Navigation Tabs between Store and License Ledger
        item {
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = Color.Transparent,
                contentColor = goldColor,
                indicator = { tabPositions ->
                    Box(
                        modifier = Modifier
                            .tabIndicatorOffset(tabPositions[activeTab])
                            .height(3.dp)
                            .background(goldColor)
                    )
                }
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    modifier = Modifier.testTag("tab_storefront")
                ) {
                    Text(
                        text = "Browser Storefront",
                        modifier = Modifier.padding(14.dp),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (activeTab == 0) goldColor else MaterialTheme.colorScheme.onBackground.copy(0.5f)
                    )
                }
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    modifier = Modifier.testTag("tab_license_ledger")
                ) {
                    Text(
                        text = "Licensed Contracts (${ownedLicenses.size})",
                        modifier = Modifier.padding(14.dp),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (activeTab == 1) goldColor else MaterialTheme.colorScheme.onBackground.copy(0.5f)
                    )
                }
            }
        }

        // Storefront View
        if (activeTab == 0) {
            item {
                Text(
                    text = "AVAILABLE PACKAGES",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            // List of products
            items(assets) { asset ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("market_asset_${asset.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(goldColor.copy(0.1f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when (asset.type) {
                                            "AI Model" -> Icons.Default.Build
                                            "SaaS Platform" -> Icons.Default.Home
                                            "API" -> Icons.Default.Build
                                            else -> Icons.Default.Info
                                        },
                                        contentDescription = asset.type,
                                        tint = goldColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = asset.name,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${asset.type} • ${asset.version}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(0.5f)
                                    )
                                }
                            }
                            Text(
                                text = String.format("$%,.2f", asset.price),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = goldColor
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = asset.description,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(0.7f),
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(0.08f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Legal licence specifications parameters
                        Text(
                            text = "LEGAL COMPLIANCE PARAMETERS:",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(0.4f)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Rights Structure", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
                            Text(text = asset.licenseType, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Signature Schema", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
                            Text(text = "Verifiable Proof SHA-256", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurface)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                selectedAssetForPurchase = asset
                                deployPhase = "IDLE"
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("purchase_asset_btn_${asset.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = goldColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "Cart",
                                tint = MaterialTheme.colorScheme.background,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SELECT PRODUCT & DEPLOY",
                                color = MaterialTheme.colorScheme.background,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Licenses Ledger View
        if (activeTab == 1) {
            item {
                Text(
                    text = "OWNED VERIFIABLE SOFTWARE LICENSES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            if (ownedLicenses.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Legal contracts empty",
                                tint = goldColor.copy(0.2f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No active digital software licenses compiled.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(0.4f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(ownedLicenses) { license ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owned_license_${license.licenseId}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.4f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Verified Seal",
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LICENSE: ${license.licenseId}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = goldColor
                                    )
                                }
                                Text(
                                    text = "VERIFIED",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF10B981)
                                )
                            }
                            Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(0.08f))

                            Text(
                                text = license.assetName,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Acquired by: ${license.ownerEmail}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                            )
                            Text(
                                text = "Payment Clear Status: Centurion Settled (\$${license.pricePaid})",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                            )
                            Text(
                                text = "Purchase Epoch: " + SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(license.purchasedAt)),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "LEDGER PROOF KEY:",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(0.5f)
                            )
                            Text(
                                text = license.cryptoSignature,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color.LightGray.copy(0.8f),
                                modifier = Modifier
                                    .background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                                    .fillMaxWidth()
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Active Deployment Interactive Modal Overlay
        item {
            AnimatedVisibility(visible = selectedAssetForPurchase != null) {
                val asset = selectedAssetForPurchase!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "SOVEREIGN LAUNCH WORKFLOW",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = goldColor,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Deploying: ${asset.name}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Clearing Account Card Name: $cardholder",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Render step-by-step progress
                        when (deployPhase) {
                            "IDLE" -> {
                                Text(
                                    text = "Ready to initialize payment network clearance and secure Web3 container orchestration. Clicking deploy locks the billing loop with your card wallet proxy.",
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { selectedAssetForPurchase = null },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface)
                                    ) {
                                        Text("Cancel")
                                    }
                                    Button(
                                        onClick = {
                                            deployPhase = "CLEARING"
                                            viewModel.buyAsset(asset.id) { isSuccess ->
                                                deployPhase = if (isSuccess) "SUCCESS" else "FAILED"
                                            }
                                        },
                                        modifier = Modifier.weight(1f).testTag("confirm_deploy_execution"),
                                        colors = ButtonDefaults.buttonColors(containerColor = amexBlue)
                                    ) {
                                        Text("CONFIRM GATEWAY DEPLOY", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            "CLEARING" -> {
                                DeployStep(text = "American Express Authorization handshakes...", isActive = true)
                                Spacer(modifier = Modifier.height(6.dp))
                                DeployStep(text = "Minting Verifiable Signature parameters...", isActive = false)
                                Spacer(modifier = Modifier.height(6.dp))
                                DeployStep(text = "Routing sovereign container grid clusters...", isActive = false)
                            }
                            "SUCCESS" -> {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Launch check green",
                                        tint = Color(0xFF10B981)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("PROVISIONING COMPLETED SECURELY!", fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Ledger clears finished. Check download signatures inside the Contracts tab. Deploy host is fully provisioned on secure cloud endpoints.",
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        selectedAssetForPurchase = null
                                        activeTab = 1
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F2D24)),
                                    modifier = Modifier.fillMaxWidth().testTag("go_to_contracts_btn")
                                ) {
                                    Icon(Icons.Default.List, contentDescription = "View Contracts", tint = Color(0xFF10B981))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("OPEN CONTRACTS", color = Color(0xFF10B981))
                                }
                            }
                            "FAILED" -> {
                                Text("Platform clearance rejected. Possible reasons include credit authorization issues or fraud score flag limits.", color = Color(0xFFEF4444))
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(onClick = { selectedAssetForPurchase = null }) {
                                    Text("Close Panel")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Final safe spacing
        item {
            Spacer(modifier = Modifier.height(96.dp))
        }
    }
}

@Composable
fun DeployStep(text: String, isActive: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .background(
                    if (isActive) MaterialTheme.colorScheme.primary.copy(0.2f) else Color.DarkGray,
                    CircleShape
                )
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = text,
            fontSize = 13.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            color = if (isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(0.4f)
        )
    }
}

// Tab layout helpers
@Composable
fun tabIndicatorOffset(currentTabPosition: tabPosition): Modifier {
    return Modifier
}
typealias tabPosition = androidx.compose.material3.TabPosition
fun Modifier.tabIndicatorOffset(tabPosition: tabPosition): Modifier {
    return this.then(
        Modifier
            .fillMaxWidth(tabPosition.width.value)
            .offset(x = tabPosition.left)
    )
}
