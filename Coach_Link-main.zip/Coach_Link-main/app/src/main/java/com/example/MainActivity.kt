package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.example.data.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import org.json.JSONObject

// ==========================================
// 1. Android App Main Activity
// ==========================================
class MainActivity : ComponentActivity() {
    private lateinit var database: CoachLinkDatabase
    private lateinit var repository: CoachLinkRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Establish SQLite Persistence with Room Builder
        database = Room.databaseBuilder(
            applicationContext,
            CoachLinkDatabase::class.java,
            "coachlink_runtime.db"
        ).fallbackToDestructiveMigration().build()

        repository = CoachLinkRepository(database.coachLinkDao())

        // Seed default parameters for 2030 network simulation
        lifecycleScope.launch(Dispatchers.IO) {
            val passCount = database.coachLinkDao().getAllPasses().firstOrNull()?.size ?: 0
            val trackerCount = database.coachLinkDao().getAllTrackers().firstOrNull()?.size ?: 0
            val dutiesCount = database.coachLinkDao().getDriverDuties().firstOrNull()?.size ?: 0
            val kpisCount = database.coachLinkDao().getOpsAnalytics().firstOrNull()?.size ?: 0

            repository.populateInitialDataIfEmpty(
                hasPasses = passCount > 0,
                hasTrackers = trackerCount > 0,
                hasDuties = dutiesCount > 0,
                hasKpis = kpisCount > 0
            )
        }

        setContent {
            MyApplicationTheme {
                CoachLinkApp(repository)
            }
        }
    }
}

// ==========================================
// 2. High-Fidelity App Enums & States
// ==========================================
enum class SystemSpace {
    CUSTOMER_PORTAL,
    DRIVER_CONSOLE,
    OPERATIONS_HUB,
    TECHNICAL_SPECS
}

enum class CustomerSubScreen {
    PLANNER,
    BOOKINGS,
    MAP_TRACKER,
    LOYALTY
}

// ==========================================
// 3. UI State ViewModel
// ==========================================
class CoachViewModel(val repository: CoachLinkRepository) : ViewModel() {
    // Current Active Space
    var activeSpace by mutableStateOf(SystemSpace.CUSTOMER_PORTAL)
    var customerSubScreen by mutableStateOf(CustomerSubScreen.PLANNER)

    // Form states
    var originInput by mutableStateOf("London Victoria Coach Stn")
    var destinationInput by mutableStateOf("Manchester Central Hub")
    var travelDate by mutableStateOf("2026-06-15")
    var timePref by mutableStateOf("Morning (08:00 - 12:00)")
    var directOnly by mutableStateOf(false)
    var isMultimodalSearch by mutableStateOf(false)

    // Selection States
    var selectedJourneyForBooking by mutableStateOf<CalculatedJourney?>(null)
    var selectedSeatNum by mutableStateOf("")
    var luggageAddon by mutableStateOf(false)
    var priorityAddon by mutableStateOf(false)
    var insuranceAddon by mutableStateOf(false)
    var mealAddon by mutableStateOf(false)

    // Database reactive streams
    val recentSearches = repository.recentSearches.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val myBookings = repository.allBookings.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val myPasses = repository.allPasses.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val liveTrackers = repository.allTrackers.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val driverDuties = repository.driverDuties.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val opsAnalytics = repository.opsAnalytics.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // AI Chat logs
    val aiConversation = mutableStateListOf<ChatMessage>().apply {
        add(ChatMessage("assistant", "Greetings, eco-traveler! Pack your virtual bags and prepare for 2030 CoachLink connectivity. I can analyze disruption risks, plan your multi-modal connections, compute carbon savings, or assist with your seat select."))
    }
    var aiInputMessage by mutableStateOf("")
    var aiGeneratingState by mutableStateOf(false)

    // Simulated alerts for customer companion
    var alertBannerText by mutableStateOf("⚠️ Mid-country rail industrial delay detected. Automatic rebooking protection activated.")

    // Plan journeys dynamically
    var searchFinished by mutableStateOf(false)
    val calculatedJourneys = mutableStateListOf<CalculatedJourney>()

    fun executeSearch() {
        calculatedJourneys.clear()
        val orig = originInput.trim()
        val dest = destinationInput.trim()

        viewModelScope.launch {
            repository.saveSearch(orig, dest, travelDate, timePref, directOnly, isMultimodalSearch)

            // Dynamic logic simulating 2030 multi-modal options based on actual route pairs
            if (isMultimodalSearch) {
                // Airport / Rail Integration
                calculatedJourneys.add(
                    CalculatedJourney(
                        routeLabel = "$orig → Rail Express → Coach terminal → $dest",
                        departureTime = "08:15",
                        arrivalTime = "11:45",
                        totalDuration = "3h 30m",
                        changes = 2,
                        transferRisk = "Low (94% Connection Safety)",
                        walkingMeters = 240,
                        price = 38.50,
                        isMultimodal = true,
                        riskScore = "Comfortable",
                        pointsEarned = 120,
                        hasAirportSegment = true
                    )
                )
                calculatedJourneys.add(
                    CalculatedJourney(
                        routeLabel = "$orig → Coach Express → Airport Terminal Shuttle → $dest",
                        departureTime = "10:30",
                        arrivalTime = "13:10",
                        totalDuration = "2h 40m",
                        changes = 1,
                        transferRisk = "Medium (Delays on M25)",
                        walkingMeters = 400,
                        price = 45.00,
                        isMultimodal = true,
                        riskScore = "Medium",
                        pointsEarned = 150,
                        hasAirportSegment = true
                    )
                )
            } else {
                // Coach network pathways
                calculatedJourneys.add(
                    CalculatedJourney(
                        routeLabel = "Direct CoachLink Service (Horizon-Express CL-40)",
                        departureTime = "09:00",
                        arrivalTime = "12:55",
                        totalDuration = "3h 55m",
                        changes = 0,
                        transferRisk = "Direct (N/A)",
                        walkingMeters = 50,
                        price = 14.99,
                        isMultimodal = false,
                        riskScore = "Minimal",
                        pointsEarned = 50
                    )
                )
                calculatedJourneys.add(
                    CalculatedJourney(
                        routeLabel = "$orig → Coach C12 → Birmingham Terminal → Coach M5 → $dest",
                        departureTime = "08:30",
                        arrivalTime = "13:20",
                        totalDuration = "4h 50m",
                        changes = 1,
                        transferRisk = "Tight (80m gap, automatic auto-rebook guaranteed)",
                        walkingMeters = 120,
                        price = 11.50,
                        isMultimodal = false,
                        riskScore = "82% Chance of success",
                        pointsEarned = 80
                    )
                )
                if (!directOnly) {
                    calculatedJourneys.add(
                        CalculatedJourney(
                            routeLabel = "$orig → Coach C8 → Bristol Coach Central → Train Link → $dest",
                            departureTime = "11:15",
                            arrivalTime = "15:45",
                            totalDuration = "4h 30m",
                            changes = 2,
                            transferRisk = "Low (Rail transit buffer implemented)",
                            walkingMeters = 180,
                            price = 29.99,
                            isMultimodal = true,
                            riskScore = "Extremely Safe",
                            pointsEarned = 100
                        )
                    )
                }
            }
            searchFinished = true
        }
    }

    // Book journey
    fun bookSelectedJourney() {
        val journey = selectedJourneyForBooking ?: return
        viewModelScope.launch {
            val record = BookingRecord(
                origin = originInput,
                destination = destinationInput,
                departureTime = journey.departureTime,
                arrivalTime = journey.arrivalTime,
                totalTime = journey.totalDuration,
                totalChanges = journey.changes,
                seatNumber = if (selectedSeatNum.isNotEmpty()) selectedSeatNum else "B4 (Premium)",
                coachNumber = "CL-2030 (Horizon)",
                qrToken = "COACHLINK-2030-${System.currentTimeMillis().toString().takeLast(6)}",
                ticketType = if (journey.price > 30) "Business Flexticket" else "Standard Advance Saver",
                pricePaid = journey.price + (if (luggageAddon) 5.0 else 0.0) + (if (priorityAddon) 3.5 else 0.0),
                status = "UPCOMING",
                connectionRisk = journey.riskScore,
                walkingDistanceMeters = journey.walkingMeters,
                extraLuggageSelected = luggageAddon,
                priorityBoardingSelected = priorityAddon,
                travelInsuranceSelected = insuranceAddon,
                partnerMealVoucherSelected = mealAddon,
                pointsEarned = journey.pointsEarned
            )
            repository.addBooking(record)

            // Reset booking flow
            selectedJourneyForBooking = null
            selectedSeatNum = ""
            luggageAddon = false
            priorityAddon = false
            insuranceAddon = false
            mealAddon = false

            // Travel straight to Bookings subscreen
            customerSubScreen = CustomerSubScreen.BOOKINGS
        }
    }

    // Trigger rebook trigger
    fun triggerAutoRebook(booking: BookingRecord) {
        viewModelScope.launch {
            val updated = booking.copy(
                status = "REBOOKED",
                departureTime = "10:15",
                arrivalTime = "14:10",
                totalTime = "3h 55m",
                seatNumber = "C1 (Re-allocated Elite Zone)",
                qrToken = booking.qrToken + "-REBOOK"
            )
            repository.updateBooking(updated)
            alertBannerText = "✅ Auto-Rebook complete! Seamless Transfer protection applied: Seat reallocated. No additional fare."
        }
    }

    // Call Gemini API safely
    fun triggerAiChat() {
        val prompt = aiInputMessage.trim()
        if (prompt.isEmpty() || aiGeneratingState) return

        aiConversation.add(ChatMessage("user", prompt))
        aiInputMessage = ""
        aiGeneratingState = true

        viewModelScope.launch {
            val response = try {
                callGeminiRest(prompt)
            } catch (e: Exception) {
                Log.e("COACHLINK_AI", "Error calling Gemini API", e)
                "2030 Dispatcher Update: Connectivity offline. Our autonomous CoachLink scheduling calculations predict optimal paths for London Victoria → Leeds Coach Station in 3 hours via the M1 eco-lane corridor. Standard carbon reduction: 82% over single-pax ICE vehicles."
            }
            aiConversation.add(ChatMessage("assistant", response))
            aiGeneratingState = false
        }
    }

    private suspend fun callGeminiRest(userPrompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "🤖 [Simulation offline] No active Google AI Studio Secrets Key found.\nIn the Year 2030 CoachLink system:\n- AI Predictive disruption management recommends booking the 09:00 service to sidestep potential heavy traffic around Milton Keynes.\n- Estimated carbon emissions saved: 4.8kg CO2.\n- Multimodal transfer connection risk scorecard is graded: Grade A (Very Safe)."
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        val jsonRequest = JSONObject().apply {
            val contentsArray = org.json.JSONArray().apply {
                val userContent = JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(JSONObject().put("text", userPrompt))
                    })
                }
                put(userContent)
            }
            put("contents", contentsArray)

            val sysInstruction = JSONObject().apply {
                put("parts", org.json.JSONArray().apply {
                    put(JSONObject().put("text", "You are CoachLink's automated 2035 Mobility AI planner. Your answers should highlight multi-modal passenger transit links, autonomous routing updates, smart carbon auditing, transfer delay protection rules, and dynamic passenger lounge facilities. Answer efficiently, in under 4-5 sentences, using a premium professional voice with beautiful spacing."))
                })
            }
            put("systemInstruction", sysInstruction)
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = jsonRequest.toString().toRequestBody(mediaType)
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return@withContext "CoachLink Dispatch: Connection issues. Please ensure your AI Studio key matches. Current status: Fleet CL-2030 in-route green on timeline."
            }
            val body = response.body?.string() ?: return@withContext "Empty answer."
            val parsed = JSONObject(body)
            val candidates = parsed.getJSONArray("candidates")
            val textPart = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
            textPart
        }
    }
}

data class ChatMessage(val role: String, val content: String)

data class CalculatedJourney(
    val routeLabel: String,
    val departureTime: String,
    val arrivalTime: String,
    val totalDuration: String,
    val changes: Int,
    val transferRisk: String,
    val walkingMeters: Int,
    val price: Double,
    val isMultimodal: Boolean,
    val riskScore: String,
    val pointsEarned: Int,
    val hasAirportSegment: Boolean = false
)

// ==========================================
// 4. Custom App Layout Framework (Compose Edge-to-Edge Scaffold)
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CoachLinkApp(repository: CoachLinkRepository) {
    val viewModel: CoachViewModel = viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return CoachViewModel(repository) as T
        }
    })

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            // Elegant M3-style Tab Control for selecting general platform workspace spaces
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = viewModel.activeSpace == SystemSpace.CUSTOMER_PORTAL,
                    onClick = { viewModel.activeSpace = SystemSpace.CUSTOMER_PORTAL },
                    label = { Text("Passenger Portal", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Passenger Portal") }
                )
                NavigationBarItem(
                    selected = viewModel.activeSpace == SystemSpace.DRIVER_CONSOLE,
                    onClick = { viewModel.activeSpace = SystemSpace.DRIVER_CONSOLE },
                    label = { Text("Driver Console", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Driver Console") }
                )
                NavigationBarItem(
                    selected = viewModel.activeSpace == SystemSpace.OPERATIONS_HUB,
                    onClick = { viewModel.activeSpace = SystemSpace.OPERATIONS_HUB },
                    label = { Text("Ops Metrics", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Refresh, contentDescription = "Ops Hub") }
                )
                NavigationBarItem(
                    selected = viewModel.activeSpace == SystemSpace.TECHNICAL_SPECS,
                    onClick = { viewModel.activeSpace = SystemSpace.TECHNICAL_SPECS },
                    label = { Text("Platform Specs", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Specs") }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
        ) {
            // Simulated Device Status Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "10:24",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B) // slate-500
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(Color(0xFFCBD5E1), CircleShape) // slate-300
                    )
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(Color(0xFFCBD5E1), CircleShape) // slate-300
                    )
                }
            }

            // Geometric Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = buildAnnotatedString {
                            withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)) {
                                append("COACHLINK")
                            }
                            withStyle(SpanStyle(color = Color(0xFF94A3B8), fontWeight = FontWeight.Black)) {
                                append(".")
                            }
                        },
                        fontSize = 24.sp,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-1.5).sp
                    )
                    Text(
                        text = "MOBILITY 2030",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        color = Color(0xFF94A3B8) // slate-400
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Retain the ACTIVE system ecosystem badge elegantly
                    Box(
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp)
                            )
                            .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "ACTIVE",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    // Profile avatar with blue-to-indigo gradient
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White, CircleShape)
                            .border(1.dp, Color(0xFFF1F5F9), CircleShape), // border-slate-100
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(Color(0xFF3B82F6), Color(0xFF4F46E5)) // blue-400 to indigo-500
                                    )
                                )
                        )
                    }
                }
            }

            // Cross-App Simulated Notifications Ribbon
            AnimatedVisibility(visible = viewModel.alertBannerText.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = "Alert Symbol",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = viewModel.alertBannerText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.alertBannerText = "" },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Text("×", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }

            // Central Space Dispatcher
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (viewModel.activeSpace) {
                    SystemSpace.CUSTOMER_PORTAL -> CustomerPortalScreen(viewModel)
                    SystemSpace.DRIVER_CONSOLE -> DriverConsoleScreen(viewModel)
                    SystemSpace.OPERATIONS_HUB -> OperationsHubScreen(viewModel)
                    SystemSpace.TECHNICAL_SPECS -> PlatformSpecsScreen()
                }
            }
        }
    }
}

// ==========================================
// 5. Customer Portal Screen Components
// ==========================================
@Composable
fun CustomerPortalScreen(viewModel: CoachViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Customer subscreen selectors
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SubTabItem(
                label = "🔍 Journey Search",
                selected = viewModel.customerSubScreen == CustomerSubScreen.PLANNER,
                onClick = { viewModel.customerSubScreen = CustomerSubScreen.PLANNER }
            )
            SubTabItem(
                label = "🎫 My Tickets",
                selected = viewModel.customerSubScreen == CustomerSubScreen.BOOKINGS,
                onClick = { viewModel.customerSubScreen = CustomerSubScreen.BOOKINGS }
            )
            SubTabItem(
                label = "🛰️ GIS Real-Time Map",
                selected = viewModel.customerSubScreen == CustomerSubScreen.MAP_TRACKER,
                onClick = { viewModel.customerSubScreen = CustomerSubScreen.MAP_TRACKER }
            )
            SubTabItem(
                label = "🌟 Loyalty Lounge",
                selected = viewModel.customerSubScreen == CustomerSubScreen.LOYALTY,
                onClick = { viewModel.customerSubScreen = CustomerSubScreen.LOYALTY }
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (viewModel.customerSubScreen) {
                CustomerSubScreen.PLANNER -> JourneyPlannerView(viewModel)
                CustomerSubScreen.BOOKINGS -> BookingsView(viewModel)
                CustomerSubScreen.MAP_TRACKER -> LiveTrackerMapView(viewModel)
                CustomerSubScreen.LOYALTY -> LoyaltyLoungeView(viewModel)
            }
        }
    }
}

@Composable
fun SubTabItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
    }
}

// ------------------------------------------
// 5a. Customer Portal -> Journey Search
// ------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JourneyPlannerView(viewModel: CoachViewModel) {
    val recentList by viewModel.recentSearches.collectAsStateWithLifecycle()

    if (viewModel.selectedJourneyForBooking != null) {
        // Seat & Ancillary Upgrade overlay
        SeatReservationAndAncillaryView(viewModel)
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp), // geometric balance rounded-3xl
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Search Next-Gen Journey",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Origin Pick with custom blue circle indicator
                        OutlinedTextField(
                            value = viewModel.originInput,
                            onValueChange = { viewModel.originInput = it },
                            label = { Text("From (Origin)") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = TextStyle(fontWeight = FontWeight.Bold),
                            leadingIcon = {
                                Box(
                                    modifier = Modifier
                                        .padding(start = 6.dp)
                                        .size(10.dp)
                                        .background(Color(0xFF3B82F6), CircleShape) // blue-500
                                )
                            },
                            shape = RoundedCornerShape(16.dp)
                        )

                        // Destination Pick with custom slate diamond rotating indicator
                        OutlinedTextField(
                            value = viewModel.destinationInput,
                            onValueChange = { viewModel.destinationInput = it },
                            label = { Text("To (Destination)") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = TextStyle(fontWeight = FontWeight.Bold),
                            leadingIcon = {
                                Box(
                                    modifier = Modifier
                                        .padding(start = 6.dp)
                                        .size(8.dp)
                                        .rotate(45f)
                                        .background(Color(0xFFCBD5E1)) // slate-300
                                )
                            },
                            shape = RoundedCornerShape(16.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = viewModel.travelDate,
                                onValueChange = { viewModel.travelDate = it },
                                label = { Text("Departure Date") },
                                modifier = Modifier.weight(1f),
                                textStyle = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold),
                                shape = RoundedCornerShape(16.dp)
                            )
                            OutlinedTextField(
                                value = viewModel.timePref,
                                onValueChange = { viewModel.timePref = it },
                                label = { Text("Preferred Window") },
                                modifier = Modifier.weight(1f),
                                textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                shape = RoundedCornerShape(16.dp)
                            )
                        }

                        // Connectors preferences
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Direct Services Only",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                            )
                            Switch(
                                checked = viewModel.directOnly,
                                onCheckedChange = { viewModel.directOnly = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    "Airport & Rail Integration",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    "Mix regional trains, express coach & flights",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                            Switch(
                                checked = viewModel.isMultimodalSearch,
                                onCheckedChange = { viewModel.isMultimodalSearch = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.secondary)
                            )
                        }

                        Button(
                            onClick = { viewModel.executeSearch() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(16.dp) // rounded-2xl
                        ) {
                            Text(
                                "FIND JOURNEYS", // uppercase tracking-normal matches o.g. structure beautifully
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }

            // Quick Stats Balanced Grid from Geometric Balance HTML
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Carbon Saved Widget
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "CARBON SAVED",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF94A3B8), // slate-400
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "142kg",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A) // slate-900
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "+12% this month",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF16A34A) // green-600
                            )
                        }
                    }

                    // Points Widget
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "POINTS BALANCE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF94A3B8), // slate-400
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "4,850",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A) // slate-900
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Tier: Traveller Plus",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB) // blue-600
                            )
                        }
                    }
                }
            }

            // Loyalty Upgradable Banner from Geometric Balance HTML
            item {
                var isUpgraded by remember { mutableStateOf(false) }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(Color(0xFF4F46E5), Color(0xFF2563EB)) // Indigo-600 to Blue-600
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isUpgraded) "Upgraded to Premium Edition" else "Upgrade to Premium",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (isUpgraded) "Thank you for supporting 2030 mobility." else "Unlock 2030 Lounge access & Priority",
                                    color = Color(0xFFDBEAFE), // blue-100
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            Button(
                                onClick = {
                                    isUpgraded = true
                                    viewModel.alertBannerText = "🎉 UPGRADED! Your account now has Elite Access to lounge & connections."
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (isUpgraded) "ACTIVE" else "UPGRADE",
                                    color = Color(0xFF1D4ED8), // blue-700
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Render Recent Queries from Room Database
            if (recentList.isNotEmpty()) {
                item {
                    Text(
                        text = "Recent Searches",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        recentList.take(4).forEach { rec ->
                            SuggestionChip(
                                onClick = {
                                    viewModel.originInput = rec.origin
                                    viewModel.destinationInput = rec.destination
                                    viewModel.directOnly = rec.directOnly
                                    viewModel.isMultimodalSearch = rec.isMultimodal
                                    viewModel.executeSearch()
                                },
                                label = { Text("${rec.origin.take(12)} → ${rec.destination.take(12)}", fontSize = 10.sp) }
                            )
                        }
                    }
                }
            }

            // Searched results display
            if (viewModel.searchFinished) {
                if (viewModel.calculatedJourneys.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Text(
                                "No viable 2030 travel paths found under specified filters.",
                                modifier = Modifier.padding(16.dp),
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                } else {
                    item {
                        Text(
                            text = "Viable Corridors Found (${viewModel.calculatedJourneys.size})",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    items(viewModel.calculatedJourneys) { journey ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectedJourneyForBooking = journey },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (journey.isMultimodal) MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f) else Color.Transparent
                            ),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (journey.isMultimodal) "🚇 MULTIMODAL NETWORK" else "🚍 COACHLINK EXPRESS",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.sp,
                                        color = if (journey.isMultimodal) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .background(
                                                color = (if (journey.isMultimodal) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary).copy(
                                                    alpha = 0.15f
                                                ),
                                                shape = RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )

                                    Text(
                                        text = "From £${String.format("%.2f", journey.price)}",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = journey.routeLabel,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("DEPARTURE", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text(journey.departureTime, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    Column {
                                        Text("DURATION", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text(journey.totalDuration, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    Column {
                                        Text("CHANGEOVERS", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text("${journey.changes} transfers", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }

                                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "Transfer Protection Index",
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                        )
                                        Text(
                                            text = journey.transferRisk,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp,
                                            color = if (journey.changes == 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "Earn +${journey.pointsEarned} pts",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------
// 5b. Customer Portal -> Seat & Ancillary View
// ------------------------------------------
@Composable
fun SeatReservationAndAncillaryView(viewModel: CoachViewModel) {
    val journey = viewModel.selectedJourneyForBooking ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "Customize: Seat & Ancillaries",
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.primary
            )

            Button(
                onClick = { viewModel.selectedJourneyForBooking = null },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Cancel", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Selected Trip: ${journey.routeLabel}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("Base Price: £${String.format("%.2f", journey.price)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
        }

        // Custom drawn interactive Coach Seat layout using Jetpack Compose drawing
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Coach Layout (Horizon Elite)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendItem("Available", MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f))
                    LegendItem("Premium", MaterialTheme.colorScheme.secondary)
                    LegendItem("Selected", MaterialTheme.colorScheme.primary)
                    LegendItem("Occupied", Color.DarkGray)
                }

                // Grid seating map
                listOf("A", "B", "C", "D").forEach { rowLetter ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        for (seatIndex in 1..6) {
                            val seatId = "$rowLetter$seatIndex"
                            val isWheelchairSpace = (rowLetter == "D" && seatIndex <= 2)
                            val isPremium = (rowLetter == "A" || rowLetter == "B") && seatIndex <= 3
                            val isOccupied = (seatIndex == 2 && rowLetter == "C") || (seatIndex == 4 && rowLetter == "A")
                            val isSelected = viewModel.selectedSeatNum == seatId

                            val bgColor = when {
                                isSelected -> MaterialTheme.colorScheme.primary
                                isOccupied -> Color.DarkGray
                                isPremium -> MaterialTheme.colorScheme.secondary
                                else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                            }

                            val borderStroke = if (isWheelchairSpace) {
                                BorderStroke(1.5.dp, MaterialTheme.colorScheme.error)
                            } else null

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(bgColor, RoundedCornerShape(8.dp))
                                    .clickable(enabled = !isOccupied) {
                                        viewModel.selectedSeatNum = seatId
                                    }
                                    .then(if (borderStroke != null) Modifier.border(borderStroke, RoundedCornerShape(8.dp)) else Modifier),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isWheelchairSpace && !isSelected) "♿" else seatId,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isSelected || isOccupied) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            if (seatIndex == 3) {
                                Spacer(modifier = Modifier.width(30.dp)) // Coach Gangway / aisle space
                            }
                        }
                    }
                }
            }
        }

        // Ancillaries Upsells
        Text("Commerce & Ancillary Options", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)

        AncillaryToggleRow(
            emoji = "🧳",
            title = "Extra Luggage (+£5.00)",
            subtitle = "Additional 23kg check-in bag allocation + overhead storage guarantee.",
            checked = viewModel.luggageAddon,
            onChecked = { viewModel.luggageAddon = it }
        )

        AncillaryToggleRow(
            emoji = "⚡",
            title = "Premium Priority Boarding (+£3.50)",
            subtitle = "Board first, lock premium workspace overhead cabinet space.",
            checked = viewModel.priorityAddon,
            onChecked = { viewModel.priorityAddon = it }
        )

        AncillaryToggleRow(
            emoji = "🛡️",
            title = "Dynamic Disruption Insurance (+£2.50)",
            subtitle = "Free platform alternative flight/rail transfer rebooks during major weather blocks.",
            checked = viewModel.insuranceAddon,
            onChecked = { viewModel.insuranceAddon = it }
        )

        AncillaryToggleRow(
            emoji = "🥪",
            title = "2030 Partner Lunch Voucher (+£6.00)",
            subtitle = "Redeem at Cambridge, Bristol, or London terminals.",
            checked = viewModel.mealAddon,
            onChecked = { viewModel.mealAddon = it }
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Column {
                val addonCost = (if (viewModel.luggageAddon) 5.0 else 0.0) + (if (viewModel.priorityAddon) 3.5 else 0.0) + (if (viewModel.insuranceAddon) 2.5 else 0.0) + (if (viewModel.mealAddon) 6.0 else 0.0)
                val totalAmount = journey.price + addonCost
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Price:", fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text("£${String.format("%.2f", totalAmount)}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Seat assigned: ${if (viewModel.selectedSeatNum.isNotEmpty()) viewModel.selectedSeatNum else "Auto-allocated"}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.bookSelectedJourney() },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("CONFIRM DEPLOYMENT & BOOK TICKET", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(color, RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun AncillaryToggleRow(emoji: String, title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 22.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
            Checkbox(
                checked = checked,
                onCheckedChange = onChecked,
                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
            )
        }
    }
}

// ------------------------------------------
// 5c. Customer Portal -> My Tickets & Companion Mode
// ------------------------------------------
@Composable
fun BookingsView(viewModel: CoachViewModel) {
    val bookings by viewModel.myBookings.collectAsStateWithLifecycle()
    var selectedBookingForCompanion by remember { mutableStateOf<BookingRecord?>(null) }

    if (selectedBookingForCompanion != null) {
        CompanionCompanionModeView(selectedBookingForCompanion!!, viewModel) {
            selectedBookingForCompanion = null
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Digital Boarding Wallet",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Button(
                        onClick = { viewModel.customerSubScreen = CustomerSubScreen.PLANNER },
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("+ New Journey", fontSize = 11.sp)
                    }
                }
            }

            if (bookings.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🎫", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Your Wallet is empty", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Search and schedule long-distance corridors for 2030 to create smart tickets.", fontSize = 11.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }
                }
            } else {
                items(bookings) { booking ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(
                                                color = if (booking.status == "REBOOKED") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                                shape = CircleShape
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        booking.status,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp,
                                        color = if (booking.status == "REBOOKED") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                    )
                                }

                                Text(
                                    text = booking.ticketType,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("From", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(booking.origin, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(booking.departureTime, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("🚍", fontSize = 18.sp)
                                    Text("${booking.totalChanges} changes", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                                }

                                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                    Text("To", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(booking.destination, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(booking.arrivalTime, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("ASSIGNED SEAT", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(booking.seatNumber, fontWeight = FontWeight.Black, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                }

                                Column {
                                    Text("VEHICLE", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(booking.coachNumber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("QR TOKEN", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(booking.qrToken, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                }
                            }

                            // Dynamic QR rendering using Canvas
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp)
                                    .background(Color.White, RoundedCornerShape(12.dp))
                                    .padding(14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Canvas(modifier = Modifier.size(100.dp)) {
                                        // Draw modular simulated 2030 matrix QR code squares
                                        val squareSize = 10.dp.toPx()
                                        for (x in 0..9) {
                                            for (y in 0..9) {
                                                val shouldFill = ((x + y) % 3 == 0) || (x in 0..2 && y in 0..2) || (x in 7..9 && y in 0..2) || (x in 0..2 && y in 7..9)
                                                if (shouldFill) {
                                                    drawRect(
                                                        color = Color(0xFF0F172A),
                                                        topLeft = Offset(x * squareSize, y * squareSize),
                                                        size = androidx.compose.ui.geometry.Size(squareSize, squareSize)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "NFC TAP ACTIVATED • TOUCH TO PASS GATE",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.DarkGray
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Google Wallet integration badge mockup button
                                Button(
                                    onClick = {
                                        viewModel.alertBannerText = "🌟 Added to Google Wallet & Apple Wallet Pass successfully!"
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Add to Wallet", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                Button(
                                    onClick = { selectedBookingForCompanion = booking },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("⚠️ Companion Guide", fontSize = 11.sp)
                                }
                            }

                            // Disruption alert button simulator
                            if (booking.origin.contains("London") && booking.status == "UPCOMING") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 10.dp)
                                        .background(Color(0xFFFFECEF), RoundedCornerShape(6.dp))
                                        .border(1.dp, Color(0xFFFFA2AB), RoundedCornerShape(6.dp))
                                        .clickable {
                                            viewModel.triggerAutoRebook(booking)
                                        }
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        "❗ Connection delayed. Multi-leg protect: Trigger Auto-Rebooking",
                                        color = Color(0xFFBF213E),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------
// 5c-sub. Journey Companion Mode View
// ------------------------------------------
@Composable
fun CompanionCompanionModeView(booking: BookingRecord, viewModel: CoachViewModel, onClose: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Companion: Active Portal",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )

            Button(onClick = onClose, shape = RoundedCornerShape(8.dp)) {
                Text("Exit Guide", fontSize = 11.sp)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp), // geometric balance rounded-3xl
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)) // slate-900
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Background abstract ring circle simulation
                Canvas(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(128.dp)
                        .graphicsLayer { alpha = 0.15f }
                ) {
                    drawCircle(
                        color = Color.White,
                        radius = 64.dp.toPx(),
                        style = Stroke(width = 4.dp.toPx())
                    )
                }

                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = Color(0xFF3B82F6), // blue-500
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "ACTIVE TRIP",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                }
                                Text(
                                    text = "SERVICE NX-420",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8), // slate-400
                                    letterSpacing = 0.5.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = booking.destination, // e.g. Birmingham or Manchester
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = booking.departureTime.ifEmpty { "14:15" },
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Light,
                                color = Color.White
                            )
                            Text(
                                text = "ON TIME",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF60A5FA) // blue-400
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress track
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(Color(0xFF1E293B), CircleShape) // slate-800
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(0.66f) // w-2/3
                                .background(Color(0xFF2563EB), CircleShape) // blue-600
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF64748B), CircleShape) // slate-500
                            )
                            Text(
                                text = "Birmingham Coach St.",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8), // slate-400
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Text(
                            text = "Next: 22m",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8), // slate-400
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Animated progression canvas
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Route Progression Stream", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(14.dp))

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    val width = size.width
                    val midY = size.height / 2

                    // Horizontal tracks
                    drawLine(
                        color = Color.LightGray,
                        start = Offset(40f, midY),
                        end = Offset(width - 40f, midY),
                        strokeWidth = 4f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    // Draw progression nodes
                    // London
                    drawCircle(color = Color(0xFF0369A1), radius = 12f, center = Offset(40f, midY))
                    // Birmingham (current)
                    drawCircle(color = Color(0xFF2DD4BF), radius = 16f, center = Offset(width * 0.55f, midY))
                    // Manchester
                    drawCircle(color = Color.LightGray, radius = 12f, center = Offset(width - 40f, midY))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("London Victoria\n(Dep)", fontSize = 10.sp, textAlign = TextAlign.Left, fontWeight = FontWeight.SemiBold)
                    Text("Birmingham Terminal\n(At Platform Gate 4)", fontSize = 10.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Manchester Hub\n(Dest)", fontSize = 10.sp, textAlign = TextAlign.Right, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Terminal navigation assistance
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("AR Station Navigation & Transfers", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Transfer connection in Birmingham requires 120m walking across Gate 4 corridor. Estimated walk time is 1.5 mins. Wheelchair access path ramp B is actively illuminated in green.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

// ------------------------------------------
// 5d. Customer Portal -> GIS Real-Time Map
// ------------------------------------------
@Composable
fun LiveTrackerMapView(viewModel: CoachViewModel) {
    val trackers by viewModel.liveTrackers.collectAsStateWithLifecycle()
    var selectedTrackerId by remember { mutableIntStateOf(1) }

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    "Interactive GIS Map Selector (Touch to track)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    trackers.forEach { tracker ->
                        Box(
                            modifier = Modifier
                                .background(
                                    color = if (selectedTrackerId == tracker.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.background,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedTrackerId = tracker.id }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                tracker.coachNumber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTrackerId == tracker.id) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // GIS Map Canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .background(Color(0xFF0B132B), RoundedCornerShape(16.dp))
                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            val selectedTracker = trackers.find { it.id == selectedTrackerId } ?: trackers.firstOrNull()

            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                //  .pointerInput(Unit) { ... } // Not adding touch tracking to avoid complexity
            ) {
                // Background futuristic GIS coordinate grids
                val width = size.width
                val height = size.height

                // Draw transit grid corridors lines
                val strokeColor = Color(0xFF1E293B)
                val gridGap = 80f
                var x = 0f
                while (x < width) {
                    drawLine(strokeColor, Offset(x, 0f), Offset(x, height), strokeWidth = 1f)
                    x += gridGap
                }
                var y = 0f
                while (y < height) {
                    drawLine(strokeColor, Offset(0f, y), Offset(width, y), strokeWidth = 1f)
                    y += gridGap
                }

                // Render Route Network lines (London - Birmingham - Cambridge - Manchester)
                // Let's draw vector arterial pathways linking key hub points
                val londonCoords = Offset(width * 0.5f, height * 0.8f)
                val cardiffCoords = Offset(width * 0.2f, height * 0.65f)
                val birminghamCoords = Offset(width * 0.4f, height * 0.5f)
                val cambridgeCoords = Offset(width * 0.7f, height * 0.6f)
                val manchesterCoords = Offset(width * 0.45f, height * 0.25f)
                val newcastleCoords = Offset(width * 0.6f, height * 0.1f)

                // Render corridors line (neon transparent background)
                drawLine(Color(0x3338BDF8), londonCoords, birminghamCoords, strokeWidth = 8f)
                drawLine(Color(0x3338BDF8), birminghamCoords, manchesterCoords, strokeWidth = 8f)
                drawLine(Color(0x332DD4BF), londonCoords, cambridgeCoords, strokeWidth = 8f)
                drawLine(Color(0x33FF6B6B), cardiffCoords, birminghamCoords, strokeWidth = 8f)
                drawLine(Color(0x33FF6B6B), birminghamCoords, newcastleCoords, strokeWidth = 8f)

                // Render arterial vector links
                drawLine(Color(0xFF38BDF8), londonCoords, birminghamCoords, strokeWidth = 2f)
                drawLine(Color(0xFF38BDF8), birminghamCoords, manchesterCoords, strokeWidth = 2f)
                drawLine(Color(0xFF2DD4BF), londonCoords, cambridgeCoords, strokeWidth = 2f)
                drawLine(Color(0xFFFF6B6B), cardiffCoords, birminghamCoords, strokeWidth = 2f)
                drawLine(Color(0xFFFF6B6B), birminghamCoords, newcastleCoords, strokeWidth = 2f)

                // Key terminal nodes rendering
                val terminalsList = listOf(
                    "London" to londonCoords,
                    "Cardiff" to cardiffCoords,
                    "Birmingham" to birminghamCoords,
                    "Cambridge" to cambridgeCoords,
                    "Manchester" to manchesterCoords,
                    "Newcastle" to newcastleCoords
                )

                terminalsList.forEach { node ->
                    drawCircle(Color(0xFF1E293B), radius = 14f, center = node.second)
                    drawCircle(Color(0xFF38BDF8), radius = 6f, center = node.second)
                }

                // Pulsate active tracking coach
                if (selectedTracker != null) {
                    val trackerPos = Offset(
                        width * selectedTracker.latitudePercent,
                        height * selectedTracker.longitudePercent
                    )

                    // Draw outer beacon ripple glow
                    drawCircle(
                        color = Color(0x66FF6B6B),
                        radius = 28f,
                        center = trackerPos
                    )

                    drawCircle(
                        color = Color(0xFFFF6B6B),
                        radius = 12f,
                        center = trackerPos
                    )
                }

                // Render other mock coaches in small blue dots
                trackers.filter { it.id != selectedTrackerId }.forEach { tr ->
                    val mockPos = Offset(width * tr.latitudePercent, height * tr.longitudePercent)
                    drawCircle(Color(0xFF2DD4BF), radius = 8f, center = mockPos)
                }
            }

            // Map Overlay Metadata Card
            selectedTracker?.let { coach ->
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .fillMaxWidth(0.92f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "VEHICLE TRACKER ACTIVE",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(coach.coachNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Route: ${coach.routeName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                "At: ${coach.currentStop} → ${coach.nextStop}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("ETA COUNTDOWN", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text("${coach.etaMinutes}m", fontWeight = FontWeight.Black, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                            Text(
                                if (coach.delayMinutes > 0) "+${coach.delayMinutes}m delay" else "On Time (0 delay)",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (coach.delayMinutes > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------
// 5e. Customer Portal -> AI Advisor Lounge
// ------------------------------------------
@Composable
fun LoyaltyLoungeView(viewModel: CoachViewModel) {
    val passes by viewModel.myPasses.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "COACHLINK HORIZON MILES",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Membership Tier: Premium Elite plus", fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Points Balance: 3,450 pts", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Next Reward: 4,000 pts", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }

                    LinearProgressIndicator(
                        progress = { 0.85f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("🎯 Priority Class Select", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        Text("🎯 1 complimentary upgrade code available", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }

        // Membership subscriptions
        item {
            Text("Travel Passes & Tiers", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        }

        items(passes) { pass ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(pass.passName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Tier class: ${pass.tier}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                        }

                        Text(
                            text = if (pass.isOwned) "ACTIVE OWNED" else "£${pass.price}/yr",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = if (pass.isOwned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .background(
                                    color = (if (pass.isOwned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary).copy(
                                        alpha = 0.15f
                                    ),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        pass.description,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    if (!pass.isOwned) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                viewModel.alertBannerText = "🎉 Subscribed to ${pass.passName}! Enjoy ultimate CoachLink coverage."
                                viewModel.viewModelScope.launch {
                                    viewModel.repository.updatePass(pass.copy(isOwned = true))
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("BUY WITH PASSENGER ACCOUNT", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Year 2030 Gemini Travel Agent
        item {
            Text("🧠 Gemini AI Travel Assistant (2030 Smart Engine)", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Message Lists
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(viewModel.aiConversation) { msg ->
                            val isAssistant = msg.role == "assistant"
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                contentAlignment = if (isAssistant) Alignment.CenterStart else Alignment.CenterEnd
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isAssistant) Color(0xFF1E293B) else Color(0xFF0284C7)
                                    ),
                                    modifier = Modifier.fillMaxWidth(0.85f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text(
                                            text = if (isAssistant) "COACHLINK AI" else "YOU",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isAssistant) Color(0xFF38BDF8) else Color(0xFFE0F2FE)
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = msg.content,
                                            fontSize = 11.sp,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = viewModel.aiInputMessage,
                            onValueChange = { viewModel.aiInputMessage = it },
                            placeholder = { Text("Ask about delay risk or multimodal paths...", fontSize = 11.sp, color = Color.Gray) },
                            modifier = Modifier.weight(1f),
                            maxLines = 2,
                            textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color.DarkGray
                            )
                        )

                        Button(
                            onClick = { viewModel.triggerAiChat() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            enabled = !viewModel.aiGeneratingState,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            if (viewModel.aiGeneratingState) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                            } else {
                                Text("Send", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. Driver Console Screen (Checks & Boarding Scanner)
// ==========================================
@Composable
fun DriverConsoleScreen(viewModel: CoachViewModel) {
    val duties by viewModel.driverDuties.collectAsStateWithLifecycle()
    var selectedDutyForInspect by remember { mutableStateOf<DriverDutyRecord?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Driver Duty Assignments",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Verify schedule, execute vehicle inspections, scan passenger QR passes.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }

        if (selectedDutyForInspect != null) {
            item {
                val duty = selectedDutyForInspect!!
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pre-Duty Inspection checklist: ${duty.coachNumber}", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                        CheckpointRow("Brakes & autonomous LiDAR tracking sensors integrity green", duty.inspectionCleared) {
                            viewModel.viewModelScope.launch {
                                viewModel.repository.updateDriverDuty(duty.copy(inspectionCleared = true))
                                selectedDutyForInspect = duty.copy(inspectionCleared = true)
                            }
                        }

                        CheckpointRow("Electronic boarding manifest passenger roster verified", duty.manifestVerified) {
                            viewModel.viewModelScope.launch {
                                viewModel.repository.updateDriverDuty(duty.copy(manifestVerified = true))
                                selectedDutyForInspect = duty.copy(manifestVerified = true)
                            }
                        }

                        Button(
                            onClick = {
                                if (duty.inspectionCleared && duty.manifestVerified) {
                                    viewModel.viewModelScope.launch {
                                        viewModel.repository.updateDriverDuty(duty.copy(status = "BOARDING"))
                                        selectedDutyForInspect = duty.copy(status = "BOARDING")
                                        viewModel.alertBannerText = "🚍 Coach CL-2030 boarding initiated. Dynamic boarding gate unlocked."
                                    }
                                } else {
                                    viewModel.alertBannerText = "⚠️ Please clear all driver checkpoints before proceeding."
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("DEPLOY VEHICLE DOOR ON PLATFORM")
                        }

                        Button(
                            onClick = { selectedDutyForInspect = null },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                        ) {
                            Text("Go back", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        } else {
            items(duties) { duty ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(duty.coachNumber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                "Status: ${duty.status}",
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 11.sp
                            )
                        }

                        Text("Route: ${duty.routeName}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("Origin: ${duty.origin}", fontSize = 11.sp)
                        Text("Destination: ${duty.destination}", fontSize = 11.sp)
                        Text(duty.timeLabel, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { selectedDutyForInspect = duty },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Checklist", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    viewModel.alertBannerText = "📸 Ticket Scan Emulator triggered. Seat booked successfully."
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Text("Scan Boarding QR", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CheckpointRow(label: String, checked: Boolean, onChecked: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onChecked)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = { onChecked() })
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, fontSize = 11.sp)
    }
}

// ==========================================
// 7. Operations Hub Screen (Analytics KPI Table)
// ==========================================
@Composable
fun OperationsHubScreen(viewModel: CoachViewModel) {
    val kpis by viewModel.opsAnalytics.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Corporate Operations & Fleet Analytics",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Real-time corporate KPIs, route profitability, average delays, carbon saving forecasts.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("TOTAL NETWORK METRICS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Revenue", fontSize = 9.sp)
                            Text("£70,290.00", fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                        Column {
                            Text("Total Passengers", fontSize = 9.sp)
                            Text("3,670 pax", fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                        Column {
                            Text("Net CO2 Saved", fontSize = 9.sp)
                            Text("5.1 Tonnes", fontWeight = FontWeight.Black, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
        }

        items(kpis) { kp ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(kp.routeName, fontWeight = FontWeight.Black, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CORRIDOR REVENUE", fontSize = 8.sp, color = Color.Gray)
                            Text("£${String.format("%.2f", kp.revenue)}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Column {
                            Text("LOAD FACTOR", fontSize = 8.sp, color = Color.Gray)
                            Text("${kp.loadFactorPercent}% Capacity", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Column {
                            Text("CO2 SAVED", fontSize = 8.sp, color = Color.Gray)
                            Text("${kp.carbonSavedKg} kg", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("AVG DELAY", fontSize = 8.sp, color = Color.Gray)
                            Text("${kp.averageDelayMinutes} mins", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (kp.averageDelayMinutes > 10) MaterialTheme.colorScheme.error else Color.White)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 8. Platform Specs & Deliverables Screen
// ==========================================
@Composable
fun PlatformSpecsScreen() {
    var activeCategory by remember { mutableStateOf("ARCH_BLUEPRINT") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "CoachLink Specifications Lounge",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Detailed digital platform designs, microservices models, API schemas, and SQLite definitions.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }

        // Horizontal Category Tabs for various deliverables
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ChipSelector("🏛️ Product Architecture", activeCategory == "ARCH_BLUEPRINT") { activeCategory = "ARCH_BLUEPRINT" }
                ChipSelector("🎫 Ticketing System Spec", activeCategory == "TICKETING_SPEC") { activeCategory = "TICKETING_SPEC" }
                ChipSelector("🗄️ Relational DB schema", activeCategory == "DB_SCHEMA") { activeCategory = "DB_SCHEMA" }
                ChipSelector("🌐 OpenAPI Schema Spec", activeCategory == "API_SCHEMA") { activeCategory = "API_SCHEMA" }
                ChipSelector("📈 Ops Dashboard Design", activeCategory == "OPS_DESIGN") { activeCategory = "OPS_DESIGN" }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    when (activeCategory) {
                        "ARCH_BLUEPRINT" -> ArchitectureSpecsContent()
                        "TICKETING_SPEC" -> TicketingSpecsContent()
                        "DB_SCHEMA" -> DatabaseSchemaSpecsContent()
                        "API_SCHEMA" -> ApiSpecsContent()
                        "OPS_DESIGN" -> OpsSpecsContent()
                    }
                }
            }
        }
    }
}

@Composable
fun ChipSelector(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            label,
            color = if (active) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ArchitectureSpecsContent() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("1. Complete Product Architecture & Microservices", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        Text(
            "CoachLink operates as an Event-Driven API Federation ecosystem designed with isolated microservices interfaces, backed by Kotlin Ktor and Apache Kafka clusters for high-response message tracking coordinates.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        Text("Core Microservices Division:", fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)) { append("• Journey Microservice: ") }
                append("Calculates multimodal transfer matrix paths (coach-to-coach, coach-to-airport, coach-to-rail) using Dijkstra multi-cost graphs.\n\n")
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)) { append("• Ticketing Logic Engine: ") }
                append("Enforces dynamic seating arrays, flex rates, corporate student savers, dynamic cancellations.\n\n")
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)) { append("• Tracking coordination node: ") }
                append("Consumes telemetry signals from IoT autonomous vehicle sensors, feeding geographic buffers in under 150ms.\n\n")
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)) { append("• Commerce & Loyalty microservice: ") }
                append("Stores member loyalty ledger states, progress tiers, priority upgrades, partner voucher integrations.\n\n")
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)) { append("• Ops & Fleet Orchestrator: ") }
                append("Computes driver route assignments, dynamic vehicle loads, autonomous vehicle health checks, dispatch schedules.")
            },
            fontSize = 11.sp
        )
    }
}

@Composable
fun TicketingSpecsContent() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("2. Ticketing and Validation Specification", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        Text(
            "The 2030 Ticketing protocol is built for instantaneous, offline-ready validating gateways across airports, trains, and coaches.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) { append("• QR Cryptographic token validation:\n") }
                append("Every ticketing item contains a compact, tamper-proof JSON-Web-Token (JWT) signed using SHA-256 containing seat indexes, departure dates, and validation state. Gate validators decode raw content offline without database connectivity.\n\n")

                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) { append("• Multimodal transfer delay protection:\n") }
                append("If a multi-leg journey detects a late vehicle trigger in London, the ticketing database automatically marks the active token with REBOOK flags. It suggests alternatives (e.g., London -> Cambridge Rail -> Cambridge Park Coach) in real-time, re-allocating seating models instantly.")
            },
            fontSize = 11.sp
        )
    }
}

@Composable
fun DatabaseSchemaSpecsContent() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("3. Relational SQL & Room Database Schema", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        Text(
            "Below are the critical SQLite relational diagrams representing persistent states mapped inside the CoachLink container:",
            fontSize = 11.sp
        )

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        Text(
            text = "TABLE: search_records\n" +
                    "  - id: INTEGER (PRIMARY KEY AUTOINCREMENT)\n" +
                    "  - origin: VARCHAR(120)\n" +
                    "  - destination: VARCHAR(120)\n" +
                    "  - date: VARCHAR(20)\n" +
                    "  - isMultimodal: BOOLEAN\n" +
                    "  - timestamp: BIGINT\n\n" +
                    "TABLE: booking_records\n" +
                    "  - id: INTEGER (PRIMARY KEY)\n" +
                    "  - origin/destination: VARCHAR(120)\n" +
                    "  - seatNumber: VARCHAR(10)\n" +
                    "  - qrToken: VARCHAR(200)\n" +
                    "  - pricePaid: DOUBLE\n" +
                    "  - status: VARCHAR(20) [UPCOMING/REBOOKED]\n" +
                    "  - extraLuggageSelected: BOOLEAN\n\n" +
                    "TABLE: tracker_records\n" +
                    "  - id: INTEGER (PRIMARY KEY)\n" +
                    "  - coachNumber: VARCHAR(30)\n" +
                    "  - currentStop/nextStop: VARCHAR(80)\n" +
                    "  - delayMinutes: INT\n" +
                    "  - latitudePercent/longitudePercent: FLOAT",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.secondary
        )
    }
}

@Composable
fun ApiSpecsContent() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("4. OpenAPI 2030 Endpoint Specification", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        Text(
            "This structured REST API represents CoachLink connectivity pipelines for third-party transport portals:",
            fontSize = 11.sp
        )

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        Text(
            text = "GET /api/v1/journeys/search\n" +
                    "  Description: Search multi-modal transit legs including airport lines.\n" +
                    "  Params: origin, destination, date, directOnly\n" +
                    "  Response: Array of CalculatedJourneys\n\n" +
                    "POST /api/v1/bookings/ticket-deploy\n" +
                    "  Description: Reserve seating & generate JWT QR boarding tokens.\n" +
                    "  Body: { journeyId, seatNo, addons: { luggage: bool, priority: bool } }\n" +
                    "  Response: BookingRecord JSON\n\n" +
                    "GET /api/v1/tracking/live-stream\n" +
                    "  Description: Fetch dynamic latitude/longitude coord updates.\n" +
                    "  Response: SSE (Server-Sent Events) dynamic stream",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.secondary
        )
    }
}

@Composable
fun OpsSpecsContent() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("5. Operations & Dispatch Control Specifications", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        Text(
            "Provides dispatchers with fleet efficiency parameters and load optimization models.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) { append("• Autonomous Fleet Dispatch optimization:\n") }
                append("During peak hours, if the calculated Load Factor Index of London-Manchester route hits 85%, scheduling software triggers standby autonomous electric coaches to double frequencies seamlessly.\n\n")

                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) { append("• Carbon Footprint Tracking formulas:\n") }
                append("CO2 saved is modeled based on average occupant count multiplied by equivalent passenger-car emission factors subtracting active coach generation factors (average 82% savings).")
            },
            fontSize = 11.sp
        )
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
