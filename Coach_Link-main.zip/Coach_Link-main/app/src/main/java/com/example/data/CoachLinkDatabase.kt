package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ==========================================
// 1. Database Entities
// ==========================================

@Entity(tableName = "search_records")
data class SearchRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val origin: String,
    val destination: String,
    val date: String,
    val timePreference: String,
    val directOnly: Boolean = false,
    val isMultimodal: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "booking_records")
data class BookingRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val origin: String,
    val destination: String,
    val departureTime: String,
    val arrivalTime: String,
    val totalTime: String,
    val totalChanges: Int,
    val seatNumber: String,
    val coachNumber: String,
    val qrToken: String,
    val ticketType: String, // "Single", "Return", "Business Flexticket", "Student Saver"
    val pricePaid: Double,
    val status: String, // "UPCOMING", "ACTIVE", "COMPLETED", "CANCELLED", "REBOOKED"
    val connectionRisk: String, // "Low", "Medium", "High"
    val walkingDistanceMeters: Int,
    val extraLuggageSelected: Boolean = false,
    val priorityBoardingSelected: Boolean = false,
    val travelInsuranceSelected: Boolean = false,
    val partnerMealVoucherSelected: Boolean = false,
    val pointsEarned: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "pass_records")
data class PassRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val passName: String,
    val tier: String, // "Traveller", "Plus", "Premium"
    val price: Double,
    val description: String,
    val isOwned: Boolean = false,
    val pointsBalance: Int = 0
)

@Entity(tableName = "tracker_records")
data class TrackerRecord(
    @PrimaryKey val id: Int, // Fixed IDs for persistent route demonstration
    val coachNumber: String,
    val routeName: String,
    val startTerminal: String,
    val endTerminal: String,
    val currentStop: String,
    val nextStop: String,
    val etaMinutes: Int,
    val delayMinutes: Int,
    val currentOccupancy: Int,
    val latitudePercent: Float, // 0.0 to 1.0 representation for interactive map
    val longitudePercent: Float // 0.0 to 1.0 representation for interactive map
)

@Entity(tableName = "driver_duty_records")
data class DriverDutyRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val coachNumber: String,
    val routeName: String,
    val origin: String,
    val destination: String,
    val timeLabel: String,
    val paxCount: Int,
    val status: String, // "ASSIGNED", "INSPECTING", "BOARDING", "IN_TRANSIT", "COMPLETED"
    val manifestVerified: Boolean = false,
    val inspectionCleared: Boolean = false,
    val delayReportText: String = ""
)

@Entity(tableName = "ops_kpi_records")
data class OpsKpiRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val routeName: String,
    val revenue: Double,
    val ridership: Int,
    val averageDelayMinutes: Int,
    val loadFactorPercent: Int,
    val carbonSavedKg: Int
)

// ==========================================
// 2. Data Access Objects (DAOs)
// ==========================================

@Dao
interface CoachLinkDao {
    // Search history query
    @Query("SELECT * FROM search_records ORDER BY timestamp DESC LIMIT 10")
    fun getRecentSearches(): Flow<List<SearchRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearch(search: SearchRecord)

    @Query("DELETE FROM search_records")
    suspend fun clearSearchHistory()

    // Bookings query
    @Query("SELECT * FROM booking_records ORDER BY timestamp DESC")
    fun getAllBookings(): Flow<List<BookingRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingRecord)

    @Update
    suspend fun updateBooking(booking: BookingRecord)

    @Query("DELETE FROM booking_records")
    suspend fun clearAllBookings()

    // Passes
    @Query("SELECT * FROM pass_records")
    fun getAllPasses(): Flow<List<PassRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPasses(passes: List<PassRecord>)

    @Update
    suspend fun updatePass(pass: PassRecord)

    // Live trackers updates
    @Query("SELECT * FROM tracker_records")
    fun getAllTrackers(): Flow<List<TrackerRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrackers(trackers: List<TrackerRecord>)

    @Update
    suspend fun updateTracker(tracker: TrackerRecord)

    // Driver tasks
    @Query("SELECT * FROM driver_duty_records")
    fun getDriverDuties(): Flow<List<DriverDutyRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDriverDuty(duty: DriverDutyRecord)

    @Update
    suspend fun updateDriverDuty(duty: DriverDutyRecord)

    // Operations KPIs
    @Query("SELECT * FROM ops_kpi_records ORDER BY revenue DESC")
    fun getOpsAnalytics(): Flow<List<OpsKpiRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOpsKpis(kpis: List<OpsKpiRecord>)
}

// ==========================================
// 3. Database Definition
// ==========================================

@Database(
    entities = [
        SearchRecord::class,
        BookingRecord::class,
        PassRecord::class,
        TrackerRecord::class,
        DriverDutyRecord::class,
        OpsKpiRecord::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CoachLinkDatabase : RoomDatabase() {
    abstract fun coachLinkDao(): CoachLinkDao
}

// ==========================================
// 4. Repository (Abstracted Data Source)
// ==========================================

class CoachLinkRepository(private val dao: CoachLinkDao) {
    val recentSearches: Flow<List<SearchRecord>> = dao.getRecentSearches()
    val allBookings: Flow<List<BookingRecord>> = dao.getAllBookings()
    val allPasses: Flow<List<PassRecord>> = dao.getAllPasses()
    val allTrackers: Flow<List<TrackerRecord>> = dao.getAllTrackers()
    val driverDuties: Flow<List<DriverDutyRecord>> = dao.getDriverDuties()
    val opsAnalytics: Flow<List<OpsKpiRecord>> = dao.getOpsAnalytics()

    suspend fun saveSearch(origin: String, destination: String, date: String, timePref: String, direct: Boolean, multimodal: Boolean) {
        dao.insertSearch(
            SearchRecord(
                origin = origin,
                destination = destination,
                date = date,
                timePreference = timePref,
                directOnly = direct,
                isMultimodal = multimodal
            )
        )
    }

    suspend fun addBooking(booking: BookingRecord) {
        dao.insertBooking(booking)
    }

    suspend fun updateBooking(booking: BookingRecord) {
        dao.updateBooking(booking)
    }

    suspend fun purchasePass(passId: Int) {
        // Implementation that will be used below
    }

    suspend fun updatePass(pass: PassRecord) {
        dao.updatePass(pass)
    }

    suspend fun updateTracker(tracker: TrackerRecord) {
        dao.updateTracker(tracker)
    }

    suspend fun updateDriverDuty(duty: DriverDutyRecord) {
        dao.updateDriverDuty(duty)
    }

    suspend fun insertDriverDuty(duty: DriverDutyRecord) {
        dao.insertDriverDuty(duty)
    }

    suspend fun clearHistory() {
        dao.clearSearchHistory()
        dao.clearAllBookings()
    }

    suspend fun populateInitialDataIfEmpty(
        hasPasses: Boolean,
        hasTrackers: Boolean,
        hasDuties: Boolean,
        hasKpis: Boolean
    ) {
        if (!hasPasses) {
            val initialPasses = listOf(
                PassRecord(
                    passName = "Traveller Pass (Standard)",
                    tier = "Traveller",
                    price = 9.99,
                    description = "Collect double point multipliers, standard reward access, and companion rebooking alerts.",
                    isOwned = true,
                    pointsBalance = 450
                ),
                PassRecord(
                    passName = "Plus Pass (Frequent flyer tier)",
                    tier = "Plus",
                    price = 19.99,
                    description = "Zone-1 seat select, priority boarding, and unique partner airline transfer vouchers.",
                    isOwned = false,
                    pointsBalance = 0
                ),
                PassRecord(
                    passName = "Premium Horizon Access",
                    tier = "Premium",
                    price = 49.99,
                    description = "Complimentary lounge workspace access, 100% transfer protective insurance, free dynamic cancellations.",
                    isOwned = false,
                    pointsBalance = 0
                )
            )
            dao.insertPasses(initialPasses)
        }

        if (!hasTrackers) {
            val initialTrackers = listOf(
                TrackerRecord(
                    id = 1,
                    coachNumber = "CL-2030 (Horizon Elite)",
                    routeName = "Trans-Pennine Link (C40)",
                    startTerminal = "London Victoria Coach Stn",
                    endTerminal = "Manchester Central Hub",
                    currentStop = "Birmingham Coach Station",
                    nextStop = "Manchester Central Hub",
                    etaMinutes = 34,
                    delayMinutes = 4,
                    currentOccupancy = 72,
                    latitudePercent = 0.45f,
                    longitudePercent = 0.52f
                ),
                TrackerRecord(
                    id = 2,
                    coachNumber = "CL-114A (EcoFleet)",
                    routeName = "East Airport Direct (EXP-9)",
                    startTerminal = "London Heathrow Terminal 5",
                    endTerminal = "Cambridge Parkside",
                    currentStop = "London Kings Cross Rail",
                    nextStop = "Cambridge Parkside",
                    etaMinutes = 12,
                    delayMinutes = 0,
                    currentOccupancy = 40,
                    latitudePercent = 0.61f,
                    longitudePercent = 0.73f
                ),
                TrackerRecord(
                    id = 3,
                    coachNumber = "CL-815 (Starlight Express)",
                    routeName = "Midland Connector (M2)",
                    startTerminal = "Cardiff Sophia Gardens",
                    endTerminal = "Newcastle Gallowgate Stn",
                    currentStop = "Bristol Temple Meads",
                    nextStop = "Birmingham Coach Station",
                    etaMinutes = 58,
                    delayMinutes = 15, // Delayed
                    currentOccupancy = 89,
                    latitudePercent = 0.32f,
                    longitudePercent = 0.38f
                )
            )
            dao.insertTrackers(initialTrackers)
        }

        if (!hasDuties) {
            val initialDuties = listOf(
                DriverDutyRecord(
                    coachNumber = "CL-2030",
                    routeName = "Trans-Pennine Link (C40)",
                    origin = "London Victoria Coach Stn",
                    destination = "Manchester Central Hub",
                    timeLabel = "Departure: 13:45",
                    paxCount = 38,
                    status = "ASSIGNED",
                    manifestVerified = false,
                    inspectionCleared = false
                ),
                DriverDutyRecord(
                    coachNumber = "CL-114A",
                    routeName = "East Airport Direct (EXP-9)",
                    origin = "London Heathrow Terminal 5",
                    destination = "Cambridge Parkside",
                    timeLabel = "Departure: 15:10",
                    paxCount = 18,
                    status = "COMPLETED",
                    manifestVerified = true,
                    inspectionCleared = true
                )
            )
            for (duty in initialDuties) {
                dao.insertDriverDuty(duty)
            }
        }

        if (!hasKpis) {
            val initialKpis = listOf(
                OpsKpiRecord(
                    routeName = "London-Manchester (C40)",
                    revenue = 24890.0,
                    ridership = 1240,
                    averageDelayMinutes = 5,
                    loadFactorPercent = 84,
                    carbonSavedKg = 1840
                ),
                OpsKpiRecord(
                    routeName = "Heathrow-Cambridge (EXP-9)",
                    revenue = 14200.0,
                    ridership = 980,
                    averageDelayMinutes = 2,
                    loadFactorPercent = 67,
                    carbonSavedKg = 890
                ),
                OpsKpiRecord(
                    routeName = "Cardiff-Newcastle (M2)",
                    revenue = 31200.0,
                    ridership = 1450,
                    averageDelayMinutes = 12,
                    loadFactorPercent = 91,
                    carbonSavedKg = 2410
                )
            )
            dao.insertOpsKpis(initialKpis)
        }
    }
}
