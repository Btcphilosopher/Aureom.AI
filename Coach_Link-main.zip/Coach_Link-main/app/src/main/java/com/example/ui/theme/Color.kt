package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors (Geometric Balance - Primary Slate/Blue/Indigo)
val LightPrimary = Color(0xFF2563EB) // Blue-600
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFDBEAFE) // Blue-100
val LightOnPrimaryContainer = Color(0xFF1D4ED8) // Blue-700
val LightSecondary = Color(0xFF4F46E5) // Indigo-600
val LightBackground = Color(0xFFF8FAFC) // Slate-50 background
val LightSurface = Color(0xFFFFFFFF) // White high-alignment cards
val LightOnSurface = Color(0xFF0F172A) // Slate-900 text
val LightAccent = Color(0xFFEF4444) // Red-500 Alert

// Dark Theme Colors (Geometric Balance Midnight variant)
val DarkPrimary = Color(0xFF60A5FA) // Blue-400
val DarkOnPrimary = Color(0xFF0F172A) // Slate-900
val DarkPrimaryContainer = Color(0xFF1E3A8A) // Blue-900
val DarkSecondary = Color(0xFF818CF8) // Indigo-400
val DarkBackground = Color(0xFF0F172A) // Slate-900 background
val DarkSurface = Color(0xFF1E293B) // Slate-800 layered cards
val DarkOnSurface = Color(0xFFF8FAFC) // Slate-50 text
val DarkOnBackground = Color(0xFFE2E8F0)
val DarkAccent = Color(0xFFF87171) // Red-400 Alert
val DarkCardBg = Color(0xFF1E293B)
val LightCardBg = Color(0xFFFFFFFF)
