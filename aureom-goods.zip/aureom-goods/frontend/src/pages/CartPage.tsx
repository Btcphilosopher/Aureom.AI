import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight, Minus, Plus, RefreshCw, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { validateCartServer } from '../lib/api';
import { formatCategoryLabel, formatGbp } from '../lib/format';
import { ProductImage } from '../components/ProductCard';
import type { CartValidationResponse } from '../types';

export function CartPage() {
  const { items, updateQuantity, removeItem, syncServerSnapshot } = useCart();
  const [validation, setValidation] = useState<CartValidationResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (items.length === 0) {
      setValidation(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await validateCartServer(
        items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
          expectedUnitPricePence: i.unitPricePence,
        })),
      );
      setValidation(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to refresh bag.');
    } finally {
      setLoading(false);
    }
  }, [items]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h1 className="font-display text-3xl text-[#1E3A2B]">Your bag is empty</h1>
        <Link to="/shop" className="mt-8 min-h-[44px] px-6 py-3 inline-flex items-center gap-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm font-medium">
          <span>Browse collection</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="pb-6 border-b border-[#E5DFD3] flex justify-between items-end">
        <div>
          <h1 className="font-display text-3xl text-[#1E3A2B]">Shopping Bag</h1>
          <p className="mt-1 text-sm text-[#556358]">Prices and availability refreshed live from server.</p>
        </div>
        <button type="button" onClick={refresh} className="inline-flex items-center gap-2 text-sm text-[#1E3A2B]">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {validation?.hasMaterialChanges && (
        <div role="status" className="mt-6 p-5 rounded-lg border border-[#D4B483] bg-[#FBF6EC]">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-[#8A5A19] shrink-0" />
            <div>
              <p className="text-sm font-semibold text-[#5C3B0E]">Catalogue updates affect your bag</p>
              <ul className="mt-1 text-sm text-[#5C3B0E] list-disc list-inside">
                {validation.materialChanges.map((c, i) => (
                  <li key={i}>{c.message}</li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() =>
                  syncServerSnapshot(
                    validation.items
                      .filter((x) => x.isActive)
                      .map((x) => ({
                        productId: x.productId,
                        name: x.name,
                        slug: x.slug,
                        unitPricePence: x.unitPricePence,
                        quantity: Math.min(x.requestedQuantity, Math.max(1, x.availableQuantity)),
                      })),
                  )
                }
                className="mt-3 px-4 py-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-xs font-medium"
              >
                Accept updated prices
              </button>
            </div>
          </div>
        </div>
      )}

      {error && <div role="alert" className="mt-6 p-4 rounded-lg bg-[#FDF6F6] text-sm text-[#8B3A3A]">{error}</div>}

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        <div className="lg:col-span-8 divide-y divide-[#E5DFD3] border-t border-b border-[#E5DFD3]">
          {(validation?.items ?? []).map((item) => (
            <div key={item.productId} className="py-6 flex flex-col sm:flex-row gap-5">
              <div className="w-full sm:w-32 aspect-[4/3] rounded-md overflow-hidden bg-[#F2EFE8] border border-[#E5DFD3]">
                <ProductImage src={item.imageUrl} alt={item.name} />
              </div>
              <div className="flex-1 flex flex-col justify-between gap-4">
                <div className="flex justify-between">
                  <div>
                    <p className="text-xs text-[#556358]">{formatCategoryLabel(item.category)}</p>
                    <h2 className="text-base font-semibold text-[#1E3A2B]">{item.name}</h2>
                    <p className="text-sm tabular-nums">{formatGbp(item.unitPricePence)}</p>
                  </div>
                  <p className="font-semibold text-[#1E3A2B] tabular-nums">{formatGbp(item.lineTotalPence)}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="inline-flex items-center border border-[#E5DFD3] rounded-md bg-white">
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.productId, item.requestedQuantity - 1)}
                      aria-label={`Decrease quantity of ${item.name}`}
                      className="w-10 h-10 flex items-center justify-center"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-10 text-center text-sm tabular-nums">{item.requestedQuantity}</span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.productId, Math.min(item.availableQuantity, item.requestedQuantity + 1))}
                      disabled={item.requestedQuantity >= item.availableQuantity}
                      aria-label={`Increase quantity of ${item.name}`}
                      className="w-10 h-10 flex items-center justify-center disabled:opacity-40"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <button type="button" onClick={() => removeItem(item.productId)} className="inline-flex items-center gap-1.5 text-xs text-[#556358] hover:text-[#8B3A3A]">
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <aside className="lg:col-span-4 rounded-xl border border-[#E5DFD3] bg-[#F2EFE8]/60 p-6 sm:p-8">
          <h2 className="font-display text-xl text-[#1E3A2B]">Order summary</h2>
          <dl className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between">
              <dt className="text-[#556358]">Subtotal</dt>
              <dd className="tabular-nums font-medium">{validation ? formatGbp(validation.subtotalPence) : '—'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#556358]">Standard UK delivery</dt>
              <dd className="tabular-nums font-medium text-[#1E3A2B]">{validation ? formatGbp(validation.shippingPence) : 'Free'}</dd>
            </div>
            <div className="pt-4 border-t border-[#E5DFD3] flex justify-between text-base font-semibold text-[#1E3A2B]">
              <dt>Estimated total</dt>
              <dd className="tabular-nums">{validation ? formatGbp(validation.totalPence) : '—'}</dd>
            </div>
          </dl>
          {validation && (
            <div className="mt-4 text-xs text-[#556358] space-y-1">
              <p>{validation.shippingPolicySummary}</p>
              <p>{validation.taxPolicySummary}</p>
            </div>
          )}
          <div className="mt-6">
            {validation?.canCheckout ? (
              <Link to="/checkout" className="w-full min-h-[48px] px-6 py-3 inline-flex items-center justify-center gap-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm font-medium">
                <span>Proceed to checkout</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            ) : (
              <button type="button" disabled className="w-full min-h-[48px] px-6 py-3 rounded-md bg-[#9BA89E] text-[#FAF8F4] text-sm font-medium">
                Resolve bag issues to checkout
              </button>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
