import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { CheckCircle2, Lock } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { fetchOrderByReference } from '../lib/api';
import { formatFulfilmentStatus, formatGbp, formatOrderStatus, formatPaymentStatus } from '../lib/format';
import type { Order } from '../types';

export function OrderConfirmationPage() {
  const { reference = '' } = useParams();
  const [searchParams] = useSearchParams();
  const { getOrderAccessToken } = useCart();

  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = searchParams.get('token') || getOrderAccessToken(reference);
    if (!token) {
      setError('A valid order access token is required to view this order.');
      setLoading(false);
      return;
    }
    fetchOrderByReference(reference, token)
      .then(setOrder)
      .catch((err) => setError(err instanceof Error ? err.message : 'Unable to retrieve order.'))
      .finally(() => setLoading(false));
  }, [reference, searchParams, getOrderAccessToken]);

  if (loading) {
    return <div className="max-w-4xl mx-auto px-4 py-16 text-sm text-[#556358]">Loading order confirmation...</div>;
  }

  if (error || !order) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <Lock className="w-8 h-8 mx-auto text-[#1E3A2B]" />
        <h1 className="mt-4 font-display text-3xl text-[#1E3A2B]">Order access protected</h1>
        <p className="mt-2 text-sm text-[#556358]">{error}</p>
        <Link to="/shop" className="mt-6 inline-flex px-6 py-2.5 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm">
          Return to shop
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="p-6 sm:p-8 rounded-xl border border-[#C8D4C9] bg-[#E7ECE7]/65">
        <div className="flex items-start gap-3">
          <CheckCircle2 className="w-6 h-6 text-[#1E3A2B] shrink-0 mt-0.5" />
          <div>
            <p className="text-xs text-[#556358] tabular-nums">Order reference: <strong className="text-[#1E3A2B]">{order.reference}</strong></p>
            <h1 className="mt-1 font-display text-2xl sm:text-3xl text-[#1E3A2B]">{order.statusBanner}</h1>
            <p className="mt-2 text-sm">Saved for {order.customerName} ({order.customerEmail}).</p>
          </div>
        </div>
        <dl className="mt-6 pt-5 border-t border-[#C8D4C9] grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
          <div><dt className="text-xs text-[#556358]">Payment status</dt><dd className="font-semibold text-[#1E3A2B]">{formatPaymentStatus(order.paymentStatus)}</dd></div>
          <div><dt className="text-xs text-[#556358]">Order status</dt><dd className="font-semibold text-[#1E3A2B]">{formatOrderStatus(order.orderStatus)}</dd></div>
          <div><dt className="text-xs text-[#556358]">Fulfilment status</dt><dd className="font-semibold text-[#1E3A2B]">{formatFulfilmentStatus(order.fulfilmentStatus)}</dd></div>
        </dl>
      </div>

      <div className="mt-10 grid grid-cols-1 md:grid-cols-12 gap-8">
        <div className="md:col-span-7">
          <h2 className="font-display text-xl text-[#1E3A2B] pb-3 border-b border-[#E5DFD3]">Purchased items</h2>
          <ul className="divide-y divide-[#E5DFD3] border-b border-[#E5DFD3]">
            {order.items.map((item) => (
              <li key={item.id} className="py-4 flex justify-between text-sm">
                <div>
                  <p className="font-semibold text-[#1E3A2B]">{item.productName}</p>
                  <p className="text-xs text-[#556358] tabular-nums">Qty {item.quantity} × {formatGbp(item.unitPricePence)}</p>
                </div>
                <p className="font-medium tabular-nums">{formatGbp(item.lineTotalPence)}</p>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex justify-between text-base font-semibold text-[#1E3A2B]">
            <span>Final total</span>
            <span className="tabular-nums">{formatGbp(order.totalPence)}</span>
          </div>
        </div>
        <aside className="md:col-span-5 p-6 rounded-lg border border-[#E5DFD3] bg-[#F2EFE8]/50 text-sm space-y-1">
          <h2 className="font-display text-lg text-[#1E3A2B] mb-2">Delivery destination</h2>
          <p className="font-medium">{order.customerName}</p>
          <p>{order.deliveryAddress.line1}</p>
          {order.deliveryAddress.line2 && <p>{order.deliveryAddress.line2}</p>}
          <p>{order.deliveryAddress.city}, {order.deliveryAddress.postcode}</p>
          <p>{order.deliveryAddress.country}</p>
        </aside>
      </div>
    </div>
  );
}
