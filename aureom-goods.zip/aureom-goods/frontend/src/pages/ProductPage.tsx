import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Check, Minus, Plus, ShoppingBag } from 'lucide-react';
import { fetchProductBySlug } from '../lib/api';
import { formatCategoryLabel, formatGbp } from '../lib/format';
import { useCart } from '../context/CartContext';
import { ProductImage } from '../components/ProductCard';
import type { Product } from '../types';

export function ProductPage() {
  const { slug = '' } = useParams();
  const { addItem, items } = useCart();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetchProductBySlug(slug)
      .then(setProduct)
      .catch((err) => setError(err instanceof Error ? err.message : 'Product not found'))
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="h-96 rounded-xl bg-[#E5DFD3]/50 animate-pulse" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h1 className="font-display text-3xl text-[#1E3A2B]">Product not found</h1>
        <p className="mt-2 text-sm text-[#556358]">{error}</p>
        <Link to="/shop" className="mt-6 inline-flex px-6 py-2.5 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm">
          Return to shop
        </Link>
      </div>
    );
  }

  const inBag = items.find((i) => i.productId === product.id)?.quantity ?? 0;
  const maxAddable = Math.max(0, product.stockQuantity - inBag);

  const handleAdd = () => {
    if (maxAddable === 0) return;
    addItem(product, Math.min(quantity, maxAddable));
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
      <Link to="/shop" className="inline-flex items-center gap-2 text-sm text-[#556358] hover:text-[#1E3A2B] mb-8">
        <ArrowLeft className="w-4 h-4" />
        <span>Back to collection</span>
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start">
        <div className="lg:col-span-7">
          <div className="aspect-[4/3] w-full overflow-hidden rounded-xl bg-[#F2EFE8] border border-[#E5DFD3]">
            <ProductImage src={product.imageUrl} alt={product.name} />
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="flex items-center gap-2 text-xs text-[#556358]">
            <span>{formatCategoryLabel(product.category)}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              {product.stockQuantity === 0 ? 'Out of stock' : `${product.stockQuantity} in stock`}
            </span>
          </div>

          <h1 className="mt-3 font-display text-3xl sm:text-4xl text-[#1E3A2B]">{product.name}</h1>
          <p className="mt-4 text-2xl font-medium tabular-nums">{formatGbp(product.pricePence)}</p>
          <p className="mt-6 text-base text-[#556358] leading-relaxed">{product.description}</p>

          <div className="mt-8 pt-8 border-t border-[#E5DFD3] space-y-6">
            <div>
              <label htmlFor="vite-qty" className="block text-sm font-medium text-[#1E3A2B]">Quantity</label>
              <div className="mt-2 inline-flex items-center border border-[#E5DFD3] rounded-md bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  disabled={quantity <= 1}
                  aria-label="Decrease quantity"
                  className="w-11 h-11 flex items-center justify-center text-[#1E3A2B] disabled:opacity-40"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span id="vite-qty" className="w-12 text-center text-sm font-medium tabular-nums">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.min(Math.max(1, product.stockQuantity), q + 1))}
                  disabled={quantity >= product.stockQuantity}
                  aria-label="Increase quantity"
                  className="w-11 h-11 flex items-center justify-center text-[#1E3A2B] disabled:opacity-40"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={handleAdd}
                disabled={product.stockQuantity === 0 || maxAddable === 0}
                className="flex-1 min-h-[48px] px-6 py-3 inline-flex items-center justify-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] disabled:bg-[#9BA89E] text-[#FAF8F4] text-sm font-medium"
              >
                {justAdded ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
                <span>
                  {justAdded
                    ? 'Added to bag'
                    : product.stockQuantity === 0
                      ? 'Out of stock'
                      : maxAddable === 0
                        ? 'Maximum stock in bag'
                        : 'Add to bag'}
                </span>
              </button>
              {inBag > 0 && (
                <Link to="/cart" className="min-h-[48px] px-5 py-3 inline-flex items-center justify-center rounded-md border border-[#1E3A2B] text-[#1E3A2B] text-sm font-medium">
                  View bag
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
