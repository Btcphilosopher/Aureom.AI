import React, { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AlertCircle, Lock, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { submitCheckout, validateCartServer } from '../lib/api';
import { formatGbp } from '../lib/format';
import type { CartValidationResponse } from '../types';

export function CheckoutPage() {
  const navigate = useNavigate();
  const {
    items,
    clearCart,
    syncServerSnapshot,
    getCheckoutIdempotencyKey,
    rotateCheckoutIdempotencyKey,
    saveOrderAccessToken,
  } = useCart();

  const [form, setForm] = useState({
    name: '',
    email: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    postcode: '',
    country: 'United Kingdom',
  });
  const [validation, setValidation] = useState<CartValidationResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const loadSummary = useCallback(async () => {
    if (items.length === 0) return;
    try {
      const res = await validateCartServer(
        items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
          expectedUnitPricePence: i.unitPricePence,
        })),
      );
      setValidation(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to calculate server order total.');
    }
  }, [items]);

  useEffect(() => {
    loadSummary();
  }, [loadSummary]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!validation?.canCheckout) return;

    setSubmitting(true);
    const idempotencyKey = getCheckoutIdempotencyKey();

    try {
      const res = await submitCheckout({
        idempotencyKey,
        customer: form,
        items: validation.items.map((i) => ({
          productId: i.productId,
          quantity: i.requestedQuantity,
          expectedUnitPricePence: i.unitPricePence,
        })),
        acknowledgedTotalPence: validation.totalPence,
      });

      saveOrderAccessToken(res.order.reference, res.accessToken);
      clearCart();
      rotateCheckoutIdempotencyKey();
      navigate(`/orders/${encodeURIComponent(res.order.reference)}?token=${encodeURIComponent(res.accessToken)}`);
    } catch (err) {
      const e2 = err as Error & { code?: string };
      if (e2.code === 'MATERIAL_CHANGE' || e2.code === 'TOTAL_MISMATCH') {
        await loadSummary();
        if (validation) {
          syncServerSnapshot(
            validation.items.filter((i) => i.isActive).map((i) => ({
              productId: i.productId,
              name: i.name,
              slug: i.slug,
              unitPricePence: i.unitPricePence,
              quantity: Math.min(i.requestedQuantity, Math.max(1, i.availableQuantity)),
            })),
          );
        }
      }
      setError(e2.message || 'Unable to save demo order.');
    } finally {
      setSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h1 className="font-display text-3xl text-[#1E3A2B]">Your bag is empty</h1>
        <Link to="/shop" className="mt-6 inline-flex px-6 py-2.5 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm">
          Browse collection
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <h1 className="font-display text-3xl text-[#1E3A2B] pb-6 border-b border-[#E5DFD3]">Checkout</h1>

      <div className="mt-6 p-4 rounded-lg border border-[#C8D4C9] bg-[#E7ECE7]/70 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-[#1E3A2B] shrink-0 mt-0.5" />
        <div className="text-sm text-[#1E3A2B]">
          <p className="font-semibold">Demonstration checkout — no payment taken</p>
          <p className="text-[#243028]">No card details are requested. Submitting saves a real order in SQLite and deducts stock atomically.</p>
        </div>
      </div>

      {error && (
        <div role="alert" className="mt-6 p-4 rounded-lg border border-[#D8B4B4] bg-[#FDF6F6] flex items-center gap-3 text-sm text-[#8B3A3A]">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        <form onSubmit={handleSubmit} className="lg:col-span-7 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="v-name" className="block text-sm font-medium text-[#1E3A2B]">Full name</label>
              <input id="v-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1 w-full h-11 px-3 bg-white border border-[#E5DFD3] rounded-md text-sm" />
            </div>
            <div>
              <label htmlFor="v-email" className="block text-sm font-medium text-[#1E3A2B]">Email address</label>
              <input id="v-email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="mt-1 w-full h-11 px-3 bg-white border border-[#E5DFD3] rounded-md text-sm" />
            </div>
          </div>
          <div>
            <label htmlFor="v-addr1" className="block text-sm font-medium text-[#1E3A2B]">Street address</label>
            <input id="v-addr1" required value={form.addressLine1} onChange={(e) => setForm({ ...form, addressLine1: e.target.value })} className="mt-1 w-full h-11 px-3 bg-white border border-[#E5DFD3] rounded-md text-sm" />
          </div>
          <div>
            <label htmlFor="v-addr2" className="block text-sm font-medium text-[#1E3A2B]">Address line 2 (optional)</label>
            <input id="v-addr2" value={form.addressLine2} onChange={(e) => setForm({ ...form, addressLine2: e.target.value })} className="mt-1 w-full h-11 px-3 bg-white border border-[#E5DFD3] rounded-md text-sm" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="v-city" className="block text-sm font-medium text-[#1E3A2B]">City</label>
              <input id="v-city" required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="mt-1 w-full h-11 px-3 bg-white border border-[#E5DFD3] rounded-md text-sm" />
            </div>
            <div>
              <label htmlFor="v-post" className="block text-sm font-medium text-[#1E3A2B]">Postcode</label>
              <input id="v-post" required value={form.postcode} onChange={(e) => setForm({ ...form, postcode: e.target.value })} className="mt-1 w-full h-11 px-3 bg-white border border-[#E5DFD3] rounded-md text-sm" />
            </div>
            <div>
              <label htmlFor="v-country" className="block text-sm font-medium text-[#1E3A2B]">Country</label>
              <input id="v-country" required value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="mt-1 w-full h-11 px-3 bg-white border border-[#E5DFD3] rounded-md text-sm" />
            </div>
          </div>
          <button
            type="submit"
            disabled={submitting || !validation?.canCheckout}
            className="min-h-[48px] px-8 py-3 inline-flex items-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] disabled:bg-[#9BA89E] text-[#FAF8F4] text-sm font-medium"
          >
            <Lock className="w-4 h-4" />
            <span>{submitting ? 'Saving demo order...' : 'Place demo order (no payment)'}</span>
          </button>
        </form>

        <aside className="lg:col-span-5 rounded-xl border border-[#E5DFD3] bg-[#F2EFE8]/60 p-6 sm:p-8">
          <h2 className="font-display text-xl text-[#1E3A2B]">Order summary</h2>
          <ul className="mt-4 divide-y divide-[#E5DFD3] border-t border-b border-[#E5DFD3]">
            {(validation?.items ?? []).map((item) => (
              <li key={item.productId} className="py-3 flex justify-between text-sm">
                <span>{item.name} × {item.requestedQuantity}</span>
                <span className="tabular-nums font-medium">{formatGbp(item.lineTotalPence)}</span>
              </li>
            ))}
          </ul>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-[#556358]">Standard UK delivery</dt>
              <dd className="tabular-nums font-medium text-[#1E3A2B]">{validation ? formatGbp(validation.shippingPence) : 'Free'}</dd>
            </div>
            <div className="pt-3 border-t border-[#E5DFD3] flex justify-between text-base font-semibold text-[#1E3A2B]">
              <dt>Total</dt>
              <dd className="tabular-nums">{validation ? formatGbp(validation.totalPence) : '—'}</dd>
            </div>
          </dl>
        </aside>
      </div>
    </div>
  );
}
