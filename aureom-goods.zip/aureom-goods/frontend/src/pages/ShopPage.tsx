import React, { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AlertCircle, RotateCcw, Search } from 'lucide-react';
import { fetchProducts } from '../lib/api';
import { ProductCard } from '../components/ProductCard';
import type { Product } from '../types';

const TABS = [
  { id: 'all', label: 'All' },
  { id: 'homeware', label: 'Homeware' },
  { id: 'stationery', label: 'Stationery' },
  { id: 'accessories', label: 'Accessories' },
];

export function ShopPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const category = searchParams.get('category') ?? 'all';
  const appliedQuery = searchParams.get('q') ?? '';
  const sort = searchParams.get('sort') ?? 'featured';

  const [queryInput, setQueryInput] = useState(appliedQuery);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setQueryInput(appliedQuery);
  }, [appliedQuery]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchProducts({ category, q: appliedQuery, sort });
      setProducts(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load products.');
    } finally {
      setLoading(false);
    }
  }, [category, appliedQuery, sort]);

  useEffect(() => {
    load();
  }, [load]);

  const updateParam = (key: string, val: string) => {
    const next = new URLSearchParams(searchParams);
    if (!val || val === 'all' || val === 'featured') {
      next.delete(key);
    } else {
      next.set(key, val);
    }
    setSearchParams(next);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateParam('q', queryInput.trim());
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="pb-8 border-b border-[#E5DFD3]">
        <h1 className="font-display text-3xl sm:text-4xl font-normal text-[#1E3A2B]">The Collection</h1>
        <div className="mt-8 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div role="tablist" className="inline-flex flex-wrap gap-1 p-1 bg-[#F2EFE8] border border-[#E5DFD3] rounded-lg w-fit">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={category === t.id}
                onClick={() => updateParam('category', t.id)}
                className={`min-h-[38px] px-4 py-1.5 text-sm font-medium rounded-md whitespace-nowrap ${
                  category === t.id ? 'bg-[#1E3A2B] text-[#FAF8F4]' : 'text-[#243028] hover:bg-[#FAF8F4]/70'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <form onSubmit={handleSearch} className="relative flex items-center" role="search">
              <label htmlFor="vite-shop-search" className="sr-only">Search catalogue</label>
              <input
                id="vite-shop-search"
                type="search"
                value={queryInput}
                onChange={(e) => setQueryInput(e.target.value)}
                placeholder="Search by name or material..."
                className="w-full sm:w-64 h-11 pl-3.5 pr-10 text-sm bg-white border border-[#E5DFD3] rounded-md"
              />
              <button type="submit" aria-label="Apply search" className="absolute right-1.5 w-8 h-8 flex items-center justify-center text-[#1E3A2B]">
                <Search className="w-4 h-4" />
              </button>
            </form>

            <div className="flex items-center gap-2">
              <label htmlFor="vite-shop-sort" className="text-sm text-[#556358]">Sort by</label>
              <select
                id="vite-shop-sort"
                value={sort}
                onChange={(e) => updateParam('sort', e.target.value)}
                className="h-11 px-3 text-sm bg-white border border-[#E5DFD3] rounded-md"
              >
                <option value="featured">Featured</option>
                <option value="price_asc">Price: Low to high</option>
                <option value="price_desc">Price: High to low</option>
                <option value="name_asc">Name: A to Z</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div role="alert" className="mt-8 p-6 rounded-lg border border-[#D8B4B4] bg-[#FDF6F6] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-sm text-[#8B3A3A]">
            <AlertCircle className="w-5 h-5" />
            <span>{error}</span>
          </div>
          <button type="button" onClick={load} className="px-4 py-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm">
            Try again
          </button>
        </div>
      )}

      {!error && loading && (
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className="aspect-[4/3] rounded-lg bg-[#E5DFD3]/60 animate-pulse" />
          ))}
        </div>
      )}

      {!error && !loading && products.length === 0 && (
        <div className="mt-12 py-16 text-center rounded-lg border border-[#E5DFD3] bg-[#F2EFE8]/40">
          <h2 className="font-display text-2xl text-[#1E3A2B]">No matching pieces found</h2>
          <button
            type="button"
            onClick={() => setSearchParams({})}
            className="mt-6 min-h-[44px] px-5 py-2.5 inline-flex items-center gap-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset filters</span>
          </button>
        </div>
      )}

      {!error && !loading && products.length > 0 && (
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
