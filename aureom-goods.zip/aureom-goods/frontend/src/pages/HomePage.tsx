import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { fetchProducts } from '../lib/api';
import { ProductCard, ProductImage } from '../components/ProductCard';
import type { Product } from '../types';

const CATEGORIES = [
  {
    slug: 'homeware',
    title: 'Homeware',
    description: 'Wheel-thrown stoneware, spun-aluminium lighting, and organic cotton kitchen linens.',
    imageUrl: '/images/studio-mug.jpg',
  },
  {
    slug: 'stationery',
    title: 'Stationery',
    description: 'Smyth-sewn field notebooks, undated weekly planners, and solid ash desk organisers.',
    imageUrl: '/images/field-notebook.jpg',
  },
  {
    slug: 'accessories',
    title: 'Accessories',
    description: 'Heavyweight 18oz canvas totes and vacuum-insulated bottles built for daily transit.',
    imageUrl: '/images/everyday-tote.jpg',
  },
];

export function HomePage() {
  const [featured, setFeatured] = useState<Product[]>([]);

  useEffect(() => {
    fetchProducts({ featured: true })
      .then((items) => setFeatured(items.slice(0, 3)))
      .catch(() => setFeatured([]));
  }, []);

  return (
    <div>
      <section className="border-b border-[#E5DFD3] bg-[#FAF8F4]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            <div className="lg:col-span-5 flex flex-col justify-center">
              <p className="text-xs font-medium text-[#556358]">
                Small-batch homeware, stationery &amp; carry goods
              </p>
              <h1 className="mt-4 font-display text-4xl sm:text-5xl lg:text-[3.5rem] font-normal tracking-tight text-[#1E3A2B] leading-[1.08]">
                Good things. For everyday living.
              </h1>
              <p className="mt-6 text-base sm:text-lg text-[#556358] leading-relaxed max-w-md">
                Quietly considered objects crafted from natural stoneware, organic canvas, brushed brass, and European ash.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-5">
                <Link
                  to="/shop"
                  className="min-h-[44px] px-6 py-3 inline-flex items-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] text-[#FAF8F4] text-sm font-medium"
                >
                  <span>Shop the collection</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </Link>
                <Link to="/shop?category=homeware" className="text-sm font-medium text-[#1E3A2B] hover:underline underline-offset-4">
                  Browse homeware
                </Link>
              </div>
              <p className="mt-8 pt-6 border-t border-[#E5DFD3] text-xs text-[#556358]">
                Complimentary UK delivery on every order · Prices in GBP include applicable VAT
              </p>
            </div>
            <div className="lg:col-span-7">
              <div className="aspect-[16/9] lg:h-full lg:min-h-[420px] w-full overflow-hidden rounded-xl bg-[#F2EFE8] border border-[#E5DFD3]">
                <ProductImage src="/images/hero-living.jpg" alt="Aureom Goods studio table" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#E5DFD3]">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-normal text-[#1E3A2B]">Featured pieces</h2>
            <p className="mt-2 text-sm text-[#556358]">Core studio editions ready for immediate dispatch.</p>
          </div>
          <Link to="/shop" className="inline-flex items-center gap-1.5 text-sm font-medium text-[#1E3A2B] hover:underline">
            <span>View all 8 products</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </Link>
        </div>
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="border-t border-[#E5DFD3] bg-[#F2EFE8]/45">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <h2 className="font-display text-2xl sm:text-3xl font-normal text-[#1E3A2B]">Shop by category</h2>
          <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">
            {CATEGORIES.map((category) => (
              <Link
                key={category.slug}
                to={`/shop?category=${category.slug}`}
                className="group block bg-[#FAF8F4] rounded-lg border border-[#E5DFD3] overflow-hidden hover:-translate-y-0.5 hover:shadow-md transition-all"
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-[#F2EFE8]">
                  <ProductImage src={category.imageUrl} alt={category.title} />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-xl text-[#1E3A2B]">{category.title}</h3>
                    <ArrowRight className="w-4 h-4 text-[#1E3A2B]" aria-hidden="true" />
                  </div>
                  <p className="mt-2 text-sm text-[#556358] leading-relaxed">{category.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
