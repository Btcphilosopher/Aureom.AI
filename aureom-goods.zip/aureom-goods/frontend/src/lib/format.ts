export function formatGbp(pence: number): string {
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(pence / 100);
}

export function formatCategoryLabel(category: string): string {
  switch (category) {
    case 'homeware':
      return 'Homeware';
    case 'stationery':
      return 'Stationery';
    case 'accessories':
      return 'Accessories';
    default:
      return category;
  }
}

export function formatPaymentStatus(status: string): string {
  const labels: Record<string, string> = {
    no_payment_taken: 'No Payment Taken (Demo)',
    pending: 'Pending Payment',
    paid: 'Paid',
    failed: 'Failed',
    cancelled: 'Cancelled',
    expired: 'Expired',
  };
  return labels[status] ?? status;
}

export function formatOrderStatus(status: string): string {
  const labels: Record<string, string> = {
    confirmed_demo: 'Confirmed (Demo Order)',
    awaiting_payment: 'Awaiting Payment',
    confirmed: 'Confirmed',
    cancelled: 'Cancelled',
  };
  return labels[status] ?? status;
}

export function formatFulfilmentStatus(status: string): string {
  const labels: Record<string, string> = {
    unfulfilled: 'Not Dispatched (Demo)',
    processing: 'Preparing Order',
    dispatched: 'Dispatched',
  };
  return labels[status] ?? status;
}
