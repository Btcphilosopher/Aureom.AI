import type { CartValidationResponse, Order, Product } from '../types';

const API_BASE = (import.meta.env.VITE_API_BASE_URL ?? '').replace(/\/$/, '');

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });
  const body = await res.json();
  if (!res.ok) {
    const err = new Error(body?.error?.message ?? 'Request failed') as Error & {
      code?: string;
      details?: Record<string, unknown>;
    };
    err.code = body?.error?.code;
    err.details = body?.error?.details;
    throw err;
  }
  return body as T;
}

export async function fetchProducts(params: {
  q?: string;
  category?: string;
  sort?: string;
  featured?: boolean;
}): Promise<Product[]> {
  const sp = new URLSearchParams();
  if (params.q) sp.set('q', params.q);
  if (params.category && params.category !== 'all') sp.set('category', params.category);
  if (params.sort && params.sort !== 'featured') sp.set('sort', params.sort);
  if (params.featured) sp.set('featured', 'true');
  const qs = sp.toString();
  const data = await requestJson<{ products: Product[] }>(`/api/products${qs ? `?${qs}` : ''}`);
  return data.products;
}

export async function fetchProductBySlug(slug: string): Promise<Product> {
  const data = await requestJson<{ product: Product }>(`/api/products/${encodeURIComponent(slug)}`);
  return data.product;
}

export async function validateCartServer(
  items: Array<{ productId: number; quantity: number; expectedUnitPricePence: number }>,
): Promise<CartValidationResponse> {
  return requestJson<CartValidationResponse>('/api/cart/validate', {
    method: 'POST',
    body: JSON.stringify({ items }),
  });
}

export async function submitCheckout(payload: {
  idempotencyKey: string;
  customer: {
    name: string;
    email: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    postcode: string;
    country: string;
  };
  items: Array<{ productId: number; quantity: number; expectedUnitPricePence?: number }>;
  acknowledgedTotalPence?: number;
}): Promise<{ order: Order; accessToken: string; replayed: boolean }> {
  return requestJson('/api/checkout', {
    method: 'POST',
    headers: { 'Idempotency-Key': payload.idempotencyKey },
    body: JSON.stringify(payload),
  });
}

export async function fetchOrderByReference(reference: string, token: string): Promise<Order> {
  const data = await requestJson<{ order: Order }>(
    `/api/orders/${encodeURIComponent(reference)}?token=${encodeURIComponent(token)}`,
  );
  return data.order;
}
