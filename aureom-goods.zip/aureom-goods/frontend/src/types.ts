export type ProductCategory = 'homeware' | 'stationery' | 'accessories';

export interface Product {
  id: number;
  slug: string;
  name: string;
  description: string;
  category: ProductCategory;
  imageUrl: string;
  pricePence: number;
  currency: 'GBP';
  stockQuantity: number;
  isActive: boolean;
  featured: boolean;
}

export interface CartClientItem {
  productId: number;
  slug: string;
  name: string;
  unitPricePence: number;
  quantity: number;
}

export interface CartMaterialChange {
  productId: number;
  productName: string;
  slug: string;
  reason: 'discontinued' | 'out_of_stock' | 'insufficient_stock' | 'price_changed';
  message: string;
  previousPricePence?: number;
  currentPricePence?: number;
  requestedQuantity: number;
  availableQuantity: number;
}

export interface ValidatedCartItem {
  productId: number;
  slug: string;
  name: string;
  category: ProductCategory;
  imageUrl: string;
  unitPricePence: number;
  currency: 'GBP';
  requestedQuantity: number;
  availableQuantity: number;
  isActive: boolean;
  lineTotalPence: number;
  hasIssue: boolean;
}

export interface CartValidationResponse {
  items: ValidatedCartItem[];
  materialChanges: CartMaterialChange[];
  hasMaterialChanges: boolean;
  canCheckout: boolean;
  subtotalPence: number;
  shippingPence: number;
  totalPence: number;
  currency: 'GBP';
  shippingPolicySummary: string;
  taxPolicySummary: string;
}

export interface OrderItem {
  id: number;
  productId: number;
  productSlug: string;
  productName: string;
  unitPricePence: number;
  currency: 'GBP';
  quantity: number;
  lineTotalPence: number;
}

export interface Order {
  reference: string;
  customerName: string;
  customerEmail: string;
  deliveryAddress: {
    line1: string;
    line2: string | null;
    city: string;
    postcode: string;
    country: string;
  };
  subtotalPence: number;
  shippingPence: number;
  totalPence: number;
  currency: 'GBP';
  checkoutMode: 'demo' | 'hosted';
  paymentStatus: string;
  orderStatus: string;
  fulfilmentStatus: string;
  statusBanner: string;
  shippingPolicySummary: string;
  taxPolicySummary: string;
  createdAt: string;
  items: OrderItem[];
}
