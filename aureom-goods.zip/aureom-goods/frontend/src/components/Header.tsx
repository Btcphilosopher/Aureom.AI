import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, Search, ShoppingBag, X } from 'lucide-react';
import { useCart } from '../context/CartContext';

export function Header() {
  const { totalCount } = useCart();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = query.trim();
    setMenuOpen(false);
    navigate(trimmed ? `/shop?q=${encodeURIComponent(trimmed)}` : '/shop');
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F4]/95 backdrop-blur-sm border-b border-[#E5DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 lg:gap-8">
        <Link
          to="/"
          className="font-display text-xl sm:text-2xl font-medium tracking-tight text-[#1E3A2B] whitespace-nowrap shrink-0"
        >
          Aureom Goods
        </Link>

        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-6 text-sm font-medium text-[#243028]">
          <Link to="/" className="hover:text-[#1E3A2B] hover:underline underline-offset-4 whitespace-nowrap shrink-0">
            Home
          </Link>
          <Link to="/shop" className="hover:text-[#1E3A2B] hover:underline underline-offset-4 whitespace-nowrap shrink-0">
            Shop
          </Link>
          <Link to="/shop?category=homeware" className="hover:text-[#1E3A2B] hover:underline underline-offset-4 whitespace-nowrap shrink-0">
            Homeware
          </Link>
          <Link to="/shop?category=stationery" className="hover:text-[#1E3A2B] hover:underline underline-offset-4 whitespace-nowrap shrink-0">
            Stationery
          </Link>
          <Link to="/shop?category=accessories" className="hover:text-[#1E3A2B] hover:underline underline-offset-4 whitespace-nowrap shrink-0">
            Accessories
          </Link>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <form onSubmit={handleSearch} className="hidden lg:flex items-center relative" role="search">
            <label htmlFor="vite-header-search" className="sr-only">
              Search products
            </label>
            <input
              id="vite-header-search"
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search goods..."
              className="w-44 xl:w-52 h-10 pl-3 pr-9 text-sm bg-[#F2EFE8] border border-[#E5DFD3] rounded-md text-[#243028] placeholder:text-[#556358]"
            />
            <button
              type="submit"
              aria-label="Submit search"
              className="absolute right-1.5 w-8 h-8 flex items-center justify-center text-[#1E3A2B]"
            >
              <Search className="w-4 h-4" aria-hidden="true" />
            </button>
          </form>

          <Link
            to="/cart"
            aria-label={`Shopping bag with ${totalCount} items`}
            className="min-h-[44px] px-4 py-2 inline-flex items-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] text-[#FAF8F4] text-sm font-medium whitespace-nowrap shrink-0"
          >
            <ShoppingBag className="w-4 h-4" aria-hidden="true" />
            <span className="tabular-nums">Bag{totalCount > 0 ? ` (${totalCount})` : ''}</span>
          </Link>

          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-md text-[#1E3A2B]"
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav aria-label="Mobile navigation" className="md:hidden border-t border-[#E5DFD3] px-4 py-3 flex flex-col gap-1">
          {[
            { to: '/', label: 'Home' },
            { to: '/shop', label: 'Shop All' },
            { to: '/shop?category=homeware', label: 'Homeware' },
            { to: '/shop?category=stationery', label: 'Stationery' },
            { to: '/shop?category=accessories', label: 'Accessories' },
          ].map((item) => (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setMenuOpen(false)}
              className="min-h-[44px] flex items-center px-2 text-sm font-medium text-[#243028]"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
