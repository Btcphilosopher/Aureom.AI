import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="border-t border-[#E5DFD3] bg-[#F2EFE8]/60 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <p className="font-display text-lg font-medium text-[#1E3A2B]">Aureom Goods</p>
            <p className="mt-2 text-sm text-[#556358] max-w-xs leading-relaxed">
              Thoughtfully proportioned everyday homeware, stationery, and carry goods designed for quiet daily routines.
            </p>
          </div>
          <div>
            <h2 className="text-sm font-semibold text-[#1E3A2B]">Collection</h2>
            <ul className="mt-3 space-y-2 text-sm text-[#556358]">
              <li><Link to="/shop" className="hover:text-[#1E3A2B]">All Goods</Link></li>
              <li><Link to="/shop?category=homeware" className="hover:text-[#1E3A2B]">Homeware</Link></li>
              <li><Link to="/shop?category=stationery" className="hover:text-[#1E3A2B]">Stationery</Link></li>
              <li><Link to="/shop?category=accessories" className="hover:text-[#1E3A2B]">Accessories</Link></li>
            </ul>
          </div>
          <div>
            <h2 className="text-sm font-semibold text-[#1E3A2B]">Ordering &amp; Delivery</h2>
            <p className="mt-3 text-sm text-[#556358] leading-relaxed">
              Complimentary standard UK delivery on every order. Displayed GBP prices include applicable UK VAT.
            </p>
            <p className="mt-2 text-xs text-[#556358]">
              Storefront operates in demonstration mode — orders are saved without taking payment.
            </p>
          </div>
        </div>
        <div className="mt-10 pt-6 border-t border-[#E5DFD3] flex flex-col sm:flex-row justify-between gap-4 text-xs text-[#556358]">
          <p>© {new Date().getFullYear()} Aureom Goods. All rights reserved.</p>
          <div className="flex gap-6">
            <Link to="/shop" className="hover:text-[#1E3A2B]">Catalogue</Link>
            <Link to="/cart" className="hover:text-[#1E3A2B]">Shopping Bag</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
