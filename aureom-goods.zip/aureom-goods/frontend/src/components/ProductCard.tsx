import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Package } from 'lucide-react';
import { formatCategoryLabel, formatGbp } from '../lib/format';
import type { Product } from '../types';

export function ProductImage({ src, alt, className = '' }: { src: string; alt: string; className?: string }) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div role="img" aria-label={alt} className={`w-full h-full bg-[#F2EFE8] flex flex-col items-center justify-center gap-2 text-[#5F7461] p-6 ${className}`}>
        <Package className="w-8 h-8 opacity-60" aria-hidden="true" />
        <span className="text-xs font-medium text-center text-[#556358]">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`w-full h-full object-cover ${className}`}
    />
  );
}

export function ProductCard({ product }: { product: Product }) {
  const stockText =
    product.stockQuantity === 0
      ? 'Out of stock'
      : product.stockQuantity <= 8
        ? `${product.stockQuantity} remaining`
        : 'In stock';

  return (
    <article className="group flex flex-col">
      <Link to={`/products/${product.slug}`} className="block rounded-lg">
        <div className="aspect-[4/3] w-full overflow-hidden rounded-lg bg-[#F2EFE8] border border-[#E5DFD3] transition-all duration-200 group-hover:-translate-y-0.5 group-hover:shadow-md">
          <ProductImage
            src={product.imageUrl}
            alt={product.name}
            className="transition-transform duration-300 group-hover:scale-[1.02]"
          />
        </div>
        <div className="mt-4 flex flex-col gap-1">
          <div className="flex items-center gap-2 text-xs text-[#556358]">
            <span>{formatCategoryLabel(product.category)}</span>
            <span aria-hidden="true">·</span>
            <span className={product.stockQuantity === 0 ? 'text-[#8B3A3A] font-medium' : ''}>{stockText}</span>
          </div>
          <div className="flex items-baseline justify-between gap-4">
            <h3 className="text-base font-semibold text-[#1E3A2B] group-hover:underline underline-offset-4">
              {product.name}
            </h3>
            <p className="text-[15px] font-medium text-[#243028] tabular-nums shrink-0">
              {formatGbp(product.pricePence)}
            </p>
          </div>
        </div>
      </Link>
    </article>
  );
}
