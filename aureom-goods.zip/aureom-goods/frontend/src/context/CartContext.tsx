import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { CartClientItem, Product } from '../types';

const CART_KEY = 'aureom_goods_cart_v1';
const IDEM_KEY = 'aureom_goods_checkout_idempotency_v1';
const TOKEN_PREFIX = 'aureom_goods_order_token_';

interface CartContextValue {
  items: CartClientItem[];
  totalCount: number;
  addItem: (product: Product, quantity?: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  removeItem: (productId: number) => void;
  clearCart: () => void;
  syncServerSnapshot: (
    updates: Array<{ productId: number; name: string; slug: string; unitPricePence: number; quantity: number }>,
  ) => void;
  getCheckoutIdempotencyKey: () => string;
  rotateCheckoutIdempotencyKey: () => string;
  saveOrderAccessToken: (ref: string, token: string) => void;
  getOrderAccessToken: (ref: string) => string | null;
}

const CartContext = createContext<CartContextValue | null>(null);

function makeKey() {
  return typeof crypto !== 'undefined' && crypto.randomUUID
    ? `chk_${crypto.randomUUID().replace(/-/g, '')}`
    : `chk_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 12)}`;
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartClientItem[]>(() => {
    try {
      const raw = window.localStorage.getItem(CART_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(CART_KEY, JSON.stringify(items));
    } catch {
      // ignore
    }
  }, [items]);

  const addItem = useCallback((product: Product, quantity = 1) => {
    const qty = Math.max(1, Math.min(99, Math.floor(quantity)));
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.productId === product.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = {
          ...next[idx],
          name: product.name,
          slug: product.slug,
          unitPricePence: product.pricePence,
          quantity: Math.min(product.stockQuantity || 99, next[idx].quantity + qty),
        };
        return next;
      }
      return [
        ...prev,
        {
          productId: product.id,
          slug: product.slug,
          name: product.name,
          unitPricePence: product.pricePence,
          quantity: qty,
        },
      ];
    });
  }, []);

  const updateQuantity = useCallback((productId: number, quantity: number) => {
    if (quantity < 1) {
      setItems((prev) => prev.filter((i) => i.productId !== productId));
      return;
    }
    setItems((prev) =>
      prev.map((i) => (i.productId === productId ? { ...i, quantity: Math.min(99, quantity) } : i)),
    );
  }, []);

  const removeItem = useCallback((productId: number) => {
    setItems((prev) => prev.filter((i) => i.productId !== productId));
  }, []);

  const clearCart = useCallback(() => setItems([]), []);

  const syncServerSnapshot = useCallback(
    (
      updates: Array<{ productId: number; name: string; slug: string; unitPricePence: number; quantity: number }>,
    ) => {
      const map = new Map(updates.map((u) => [u.productId, u]));
      setItems((prev) =>
        prev.map((i) => {
          const u = map.get(i.productId);
          return u ? { ...i, ...u } : i;
        }),
      );
    },
    [],
  );

  const getCheckoutIdempotencyKey = useCallback(() => {
    const existing = window.sessionStorage.getItem(IDEM_KEY);
    if (existing) return existing;
    const fresh = makeKey();
    window.sessionStorage.setItem(IDEM_KEY, fresh);
    return fresh;
  }, []);

  const rotateCheckoutIdempotencyKey = useCallback(() => {
    const fresh = makeKey();
    window.sessionStorage.setItem(IDEM_KEY, fresh);
    return fresh;
  }, []);

  const saveOrderAccessToken = useCallback((ref: string, token: string) => {
    window.sessionStorage.setItem(`${TOKEN_PREFIX}${ref.toUpperCase()}`, token);
  }, []);

  const getOrderAccessToken = useCallback((ref: string) => {
    return window.sessionStorage.getItem(`${TOKEN_PREFIX}${ref.toUpperCase()}`);
  }, []);

  const totalCount = useMemo(() => items.reduce((sum, i) => sum + i.quantity, 0), [items]);

  const value = useMemo(
    () => ({
      items,
      totalCount,
      addItem,
      updateQuantity,
      removeItem,
      clearCart,
      syncServerSnapshot,
      getCheckoutIdempotencyKey,
      rotateCheckoutIdempotencyKey,
      saveOrderAccessToken,
      getOrderAccessToken,
    }),
    [
      items,
      totalCount,
      addItem,
      updateQuantity,
      removeItem,
      clearCart,
      syncServerSnapshot,
      getCheckoutIdempotencyKey,
      rotateCheckoutIdempotencyKey,
      saveOrderAccessToken,
      getOrderAccessToken,
    ],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
