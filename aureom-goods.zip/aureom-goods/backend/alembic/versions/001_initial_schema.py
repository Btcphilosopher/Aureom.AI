"""Initial Aureom Goods schema

Revision ID: 001_initial_schema
Revises:
Create Date: 2026-11-14 00:00:00
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision = "001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "products",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("slug", sa.String(length=80), nullable=False),
        sa.Column("name", sa.String(length=140), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("category", sa.String(length=32), nullable=False),
        sa.Column("image_url", sa.String(length=255), nullable=False),
        sa.Column("price_pence", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(length=3), nullable=False),
        sa.Column("stock_quantity", sa.Integer(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column("featured", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint(
            "category IN ('homeware', 'stationery', 'accessories')",
            name="ck_product_category",
        ),
        sa.CheckConstraint("price_pence >= 0", name="ck_product_price_non_negative"),
        sa.CheckConstraint("stock_quantity >= 0", name="ck_product_stock_non_negative"),
        sa.CheckConstraint("currency = 'GBP'", name="ck_product_currency_gbp"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("slug"),
    )
    op.create_index("ix_products_category", "products", ["category"], unique=False)
    op.create_index("ix_products_slug", "products", ["slug"], unique=True)

    op.create_table(
        "orders",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("reference", sa.String(length=32), nullable=False),
        sa.Column("access_token_hash", sa.String(length=64), nullable=False),
        sa.Column("customer_name", sa.String(length=120), nullable=False),
        sa.Column("customer_email", sa.String(length=160), nullable=False),
        sa.Column("delivery_address_line1", sa.String(length=160), nullable=False),
        sa.Column("delivery_address_line2", sa.String(length=160), nullable=True),
        sa.Column("delivery_city", sa.String(length=100), nullable=False),
        sa.Column("delivery_postcode", sa.String(length=20), nullable=False),
        sa.Column("delivery_country", sa.String(length=80), nullable=False),
        sa.Column("subtotal_pence", sa.Integer(), nullable=False),
        sa.Column("shipping_pence", sa.Integer(), nullable=False),
        sa.Column("total_pence", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(length=3), nullable=False),
        sa.Column("checkout_mode", sa.String(length=16), nullable=False),
        sa.Column("payment_status", sa.String(length=32), nullable=False),
        sa.Column("order_status", sa.String(length=32), nullable=False),
        sa.Column("fulfilment_status", sa.String(length=32), nullable=False),
        sa.Column("shipping_policy_summary", sa.String(length=255), nullable=False),
        sa.Column("tax_policy_summary", sa.String(length=255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("subtotal_pence >= 0", name="ck_order_subtotal_non_negative"),
        sa.CheckConstraint("shipping_pence >= 0", name="ck_order_shipping_non_negative"),
        sa.CheckConstraint("total_pence >= 0", name="ck_order_total_non_negative"),
        sa.CheckConstraint("currency = 'GBP'", name="ck_order_currency_gbp"),
        sa.CheckConstraint("checkout_mode IN ('demo', 'hosted')", name="ck_order_checkout_mode"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("reference"),
    )
    op.create_index("ix_orders_reference", "orders", ["reference"], unique=True)

    op.create_table(
        "order_items",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("order_id", sa.Integer(), nullable=False),
        sa.Column("product_id", sa.Integer(), nullable=False),
        sa.Column("product_slug", sa.String(length=80), nullable=False),
        sa.Column("product_name", sa.String(length=140), nullable=False),
        sa.Column("unit_price_pence", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(length=3), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("line_total_pence", sa.Integer(), nullable=False),
        sa.CheckConstraint("unit_price_pence >= 0", name="ck_order_item_price_non_negative"),
        sa.CheckConstraint("quantity > 0", name="ck_order_item_qty_positive"),
        sa.CheckConstraint("line_total_pence >= 0", name="ck_order_item_line_total_non_negative"),
        sa.ForeignKeyConstraint(["order_id"], ["orders.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["product_id"], ["products.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_order_items_order_id", "order_items", ["order_id"], unique=False)

    op.create_table(
        "checkout_requests",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("idempotency_key", sa.String(length=120), nullable=False),
        sa.Column("request_hash", sa.String(length=64), nullable=False),
        sa.Column("status", sa.String(length=24), nullable=False),
        sa.Column("order_id", sa.Integer(), nullable=True),
        sa.Column("order_reference", sa.String(length=32), nullable=True),
        sa.Column("response_access_token", sa.String(length=128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["order_id"], ["orders.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("idempotency_key"),
    )
    op.create_index(
        "ix_checkout_requests_idempotency_key",
        "checkout_requests",
        ["idempotency_key"],
        unique=True,
    )

    op.create_table(
        "payment_webhook_events",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("provider", sa.String(length=32), nullable=False),
        sa.Column("event_id", sa.String(length=128), nullable=False),
        sa.Column("event_type", sa.String(length=64), nullable=False),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("event_id"),
    )


def downgrade() -> None:
    op.drop_table("payment_webhook_events")
    op.drop_index("ix_checkout_requests_idempotency_key", table_name="checkout_requests")
    op.drop_table("checkout_requests")
    op.drop_index("ix_order_items_order_id", table_name="order_items")
    op.drop_table("order_items")
    op.drop_index("ix_orders_reference", table_name="orders")
    op.drop_table("orders")
    op.drop_index("ix_products_slug", table_name="products")
    op.drop_index("ix_products_category", table_name="products")
    op.drop_table("products")
