from __future__ import annotations

import hashlib
import hmac
from abc import ABC, abstractmethod
from dataclasses import dataclass

from app.config import Settings


@dataclass(frozen=True)
class PaymentSessionResult:
    checkout_mode: str
    payment_status: str
    order_status: str
    fulfilment_status: str
    status_banner: str
    redirect_url: str | None = None


class PaymentProvider(ABC):
    @property
    @abstractmethod
    def mode(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def create_session(
        self,
        *,
        order_reference: str,
        total_pence: int,
        currency: str,
        customer_email: str,
        return_base_url: str,
        access_token: str,
    ) -> PaymentSessionResult:
        raise NotImplementedError

    @abstractmethod
    def verify_webhook_signature(self, payload: bytes, signature_header: str | None) -> bool:
        raise NotImplementedError


class DemoPaymentProvider(PaymentProvider):
    @property
    def mode(self) -> str:
        return "demo"

    def create_session(
        self,
        *,
        order_reference: str,
        total_pence: int,
        currency: str,
        customer_email: str,
        return_base_url: str,
        access_token: str,
    ) -> PaymentSessionResult:
        return PaymentSessionResult(
            checkout_mode="demo",
            payment_status="no_payment_taken",
            order_status="confirmed_demo",
            fulfilment_status="unfulfilled",
            status_banner="Demo order saved — no payment taken.",
        )

    def verify_webhook_signature(self, payload: bytes, signature_header: str | None) -> bool:
        return False


class HostedPaymentProvider(PaymentProvider):
    """Adapter for a hosted Stripe-style Checkout Session integration."""

    def __init__(self, secret_key: str, webhook_secret: str):
        self._secret_key = secret_key
        self._webhook_secret = webhook_secret

    @property
    def mode(self) -> str:
        return "hosted"

    def create_session(
        self,
        *,
        order_reference: str,
        total_pence: int,
        currency: str,
        customer_email: str,
        return_base_url: str,
        access_token: str,
    ) -> PaymentSessionResult:
        if not self._secret_key:
            raise RuntimeError("Hosted payment provider secret key is missing.")
        redirect_url = f"{return_base_url.rstrip('/')}/orders/{order_reference}?token={access_token}"
        return PaymentSessionResult(
            checkout_mode="hosted",
            payment_status="pending",
            order_status="awaiting_payment",
            fulfilment_status="unfulfilled",
            status_banner="Order reserved — awaiting hosted payment confirmation.",
            redirect_url=redirect_url,
        )

    def verify_webhook_signature(self, payload: bytes, signature_header: str | None) -> bool:
        if not self._webhook_secret or not signature_header:
            return False
        expected = hmac.new(
            self._webhook_secret.encode("utf-8"), payload, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, signature_header.strip())


def get_payment_provider(settings: Settings) -> PaymentProvider:
    if (
        settings.payment_mode == "hosted"
        and settings.payment_provider_secret_key
        and settings.payment_webhook_secret
    ):
        return HostedPaymentProvider(
            secret_key=settings.payment_provider_secret_key,
            webhook_secret=settings.payment_webhook_secret,
        )
    return DemoPaymentProvider()


def status_banner_for_order(checkout_mode: str, payment_status: str, order_status: str) -> str:
    if checkout_mode == "demo" or payment_status == "no_payment_taken":
        return "Demo order saved — no payment taken."
    if payment_status == "paid" and order_status == "confirmed":
        return "Payment confirmed — preparing order."
    if payment_status == "pending":
        return "Awaiting payment confirmation."
    if payment_status == "expired":
        return "Checkout session expired — stock released."
    if payment_status == "cancelled" or order_status == "cancelled":
        return "Order cancelled — stock released."
    return "Payment unsuccessful."
