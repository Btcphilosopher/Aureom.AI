from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import Base, SessionLocal, engine
from app.models import Product

SEED_PRODUCTS = [
    {
        "slug": "everyday-tote",
        "name": "Everyday Tote",
        "description": (
            "Constructed from 18oz organic unbleached cotton canvas with deep forest-green "
            "herringbone webbing straps, solid brass rivets, and a reinforced gusset base "
            "sized for laptops and market errands."
        ),
        "category": "accessories",
        "image_url": "/images/everyday-tote.jpg",
        "price_pence": 3400,
        "currency": "GBP",
        "stock_quantity": 18,
        "featured": True,
    },
    {
        "slug": "studio-mug",
        "name": "Studio Mug",
        "description": (
            "Wheel-thrown in small batches from speckled stoneware clay and finished in a "
            "satin oatmeal glaze with a hand-dipped sage rim. Holds 320ml and retains warmth "
            "comfortably in hand."
        ),
        "category": "homeware",
        "image_url": "/images/studio-mug.jpg",
        "price_pence": 2200,
        "currency": "GBP",
        "stock_quantity": 24,
        "featured": True,
    },
    {
        "slug": "field-notebook",
        "name": "Field Notebook",
        "description": (
            "Smyth-sewn A5 notebook bound in bookcloth with 192 pages of fountain-pen-friendly "
            "115gsm cream archival paper. Opens completely flat on any work surface."
        ),
        "category": "stationery",
        "image_url": "/images/field-notebook.jpg",
        "price_pence": 1600,
        "currency": "GBP",
        "stock_quantity": 40,
        "featured": True,
    },
    {
        "slug": "desk-lamp",
        "name": "Desk Lamp",
        "description": (
            "Architectural task lamp pairing a spun-aluminium forest-green shade with a brushed "
            "brass articulated stem and honed travertine base. Includes braided textile cord "
            "and inline brass switch."
        ),
        "category": "homeware",
        "image_url": "/images/desk-lamp.jpg",
        "price_pence": 14500,
        "currency": "GBP",
        "stock_quantity": 7,
        "featured": True,
    },
    {
        "slug": "travel-bottle",
        "name": "Travel Bottle",
        "description": (
            "Double-walled vacuum-insulated 500ml flask in powder-coated sage steel with a "
            "machined stainless steel neck and natural Portuguese cork collar. Keeps water "
            "chilled for 24 hours."
        ),
        "category": "accessories",
        "image_url": "/images/travel-bottle.jpg",
        "price_pence": 2800,
        "currency": "GBP",
        "stock_quantity": 15,
        "featured": False,
    },
    {
        "slug": "weekly-planner",
        "name": "Weekly Planner",
        "description": (
            "Undated 52-week linen-bound desk planner featuring a structured Monday-to-Sunday "
            "spread alongside a fine 5mm dot-grid sheet for studio notes and priorities."
        ),
        "category": "stationery",
        "image_url": "/images/weekly-planner.jpg",
        "price_pence": 1900,
        "currency": "GBP",
        "stock_quantity": 32,
        "featured": False,
    },
    {
        "slug": "cotton-tea-towel",
        "name": "Cotton Tea Towel",
        "description": (
            "Generously sized set of two kitchen cloths loomed from long-staple organic cotton—"
            "one tactile sage waffle weave and one natural flax herringbone—fitted with stitched "
            "hanging loops."
        ),
        "category": "homeware",
        "image_url": "/images/cotton-tea-towel.jpg",
        "price_pence": 1800,
        "currency": "GBP",
        "stock_quantity": 28,
        "featured": False,
    },
    {
        "slug": "desk-organiser",
        "name": "Desk Organiser",
        "description": (
            "Modular desktop tray milled from solid European ash wood with removable muted-sage "
            "powder-coated steel compartments for notebooks, pens, clips, and small studio tools."
        ),
        "category": "stationery",
        "image_url": "/images/desk-organiser.jpg",
        "price_pence": 5400,
        "currency": "GBP",
        "stock_quantity": 9,
        "featured": False,
    },
]


def seed_products(db: Session) -> int:
    """Idempotently seed the 8 catalogue products without overwriting existing rows."""
    inserted = 0
    for item in SEED_PRODUCTS:
        existing = db.scalar(select(Product).where(Product.slug == item["slug"]))
        if not existing:
            db.add(Product(**item, is_active=True))
            inserted += 1
    db.commit()
    return inserted


def main() -> None:
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        inserted = seed_products(db)
        print(f"Seed complete: {inserted} new product(s) inserted.")


if __name__ == "__main__":
    main()
