from __future__ import annotations

import logging
from pathlib import Path
from fastapi import Depends, FastAPI, Header, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import Settings, get_settings
from app.database import Base, engine, get_db
from app.models import Product
from app.payments import get_payment_provider
from app.schemas import CartValidateRequest, CheckoutRequestIn
from app.seed import seed_products
from app.services import (
    StoreException,
    create_checkout_order,
    get_order_by_reference,
    get_product_by_slug,
    list_products,
    process_payment_webhook,
    validate_cart,
)

logger = logging.getLogger("aureom.api")

app = FastAPI(title="Aureom Goods API", version="1.0.0")

settings = get_settings()
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "Idempotency-Key"],
)


@app.middleware("http")
async def limit_request_size(request: Request, call_next):
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > settings.max_request_bytes:
        return JSONResponse(
            status_code=413,
            content={
                "error": {
                    "code": "PAYLOAD_TOO_LARGE",
                    "message": "Request payload exceeds maximum allowed size.",
                }
            },
        )
    return await call_next(request)


@app.exception_handler(StoreException)
async def store_exception_handler(_request: Request, exc: StoreException):
    payload: dict = {"error": {"code": exc.code, "message": exc.message}}
    if exc.details:
        payload["error"]["details"] = exc.details
    return JSONResponse(status_code=exc.status_code, content=payload)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(_request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": "VALIDATION_ERROR",
                "message": "Please check your submitted input values.",
                "details": {"issues": [{"loc": e["loc"], "msg": e["msg"]} for e in exc.errors()]},
            }
        },
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(_request: Request, exc: Exception):
    logger.error("Unhandled API exception: %s", type(exc).__name__)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": "An unexpected server error occurred.",
            }
        },
    )


@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)
    with Session(engine) as db:
        seed_products(db)


@app.get("/api/health")
def health(db: Session = Depends(get_db), cfg: Settings = Depends(get_settings)):
    count = db.scalar(select(func.count(Product.id)).where(Product.is_active.is_(True))) or 0
    return {
        "status": "ok",
        "database": "connected",
        "paymentMode": get_payment_provider(cfg).mode,
        "productCount": count,
    }


@app.get("/api/products")
def api_list_products(
    q: str | None = Query(default=None, max_length=80),
    category: str | None = Query(default=None),
    sort: str = Query(default="featured"),
    featured: bool = Query(default=False),
    db: Session = Depends(get_db),
):
    products = list_products(db, q=q, category=category, sort=sort, featured_only=featured)
    return {"products": [p.model_dump(by_alias=True) for p in products], "count": len(products)}


@app.get("/api/products/{slug}")
def api_get_product(slug: str, db: Session = Depends(get_db)):
    product = get_product_by_slug(db, slug)
    return {"product": product.model_dump(by_alias=True)}


@app.post("/api/cart/validate")
def api_validate_cart(
    payload: CartValidateRequest,
    db: Session = Depends(get_db),
    cfg: Settings = Depends(get_settings),
):
    result = validate_cart(db, payload.items, cfg)
    return result.model_dump(by_alias=True)


@app.post("/api/checkout")
def api_checkout(
    payload: CheckoutRequestIn,
    db: Session = Depends(get_db),
    cfg: Settings = Depends(get_settings),
):
    result = create_checkout_order(db, payload, cfg)
    status_code = 200 if result.replayed else 201
    return JSONResponse(status_code=status_code, content=result.model_dump(by_alias=True))


@app.get("/api/orders/{reference}")
def api_get_order(
    reference: str,
    token: str | None = Query(default=None),
    authorization: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    bearer = None
    if authorization and authorization.lower().startswith("bearer "):
        bearer = authorization[7:].strip()
    order = get_order_by_reference(db, reference, bearer or token)
    return {"order": order.model_dump(by_alias=True)}


@app.post("/api/payments/webhook")
async def api_payment_webhook(
    request: Request,
    db: Session = Depends(get_db),
    cfg: Settings = Depends(get_settings),
):
    raw_body = await request.body()
    sig = request.headers.get("x-aureom-signature") or request.headers.get("stripe-signature")
    return process_payment_webhook(db, raw_body=raw_body, signature_header=sig, settings=cfg)


if settings.serve_static:
    dist_dir = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
    if dist_dir.exists():
        app.mount("/assets", StaticFiles(directory=dist_dir / "assets"), name="assets")
        if (dist_dir / "images").exists():
            app.mount("/images", StaticFiles(directory=dist_dir / "images"), name="images")

        @app.get("/{full_path:path}")
        def serve_spa(full_path: str):
            candidate = (dist_dir / full_path).resolve()
            if candidate.is_file() and str(candidate).startswith(str(dist_dir.resolve())):
                return FileResponse(candidate)
            return FileResponse(dist_dir / "index.html")
