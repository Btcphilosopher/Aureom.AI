from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    database_url: str = "sqlite:///./aureom_goods.db"
    allowed_origins: str = "http://localhost:5173,http://127.0.0.1:5173"
    public_base_url: str = "http://localhost:8000"
    payment_mode: str = "demo"
    prices_include_tax: bool = True
    tax_policy_note: str = (
        "Displayed prices include applicable UK VAT. No additional tax is calculated at checkout."
    )
    shipping_policy_note: str = (
        "Complimentary standard UK delivery on all orders (2–4 working days)."
    )
    serve_static: bool = False
    payment_provider_secret_key: str = ""
    payment_webhook_secret: str = ""
    max_request_bytes: int = 32768

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.allowed_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
