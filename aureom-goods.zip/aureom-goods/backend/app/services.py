from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from datetime import datetime, timezone
from sqlalchemy import asc, desc, or_, select, text, update
from sqlalchemy.orm import Session

from app.config import Settings
from app.models import CheckoutRequest, Order, OrderItem, PaymentWebhookEvent, Product
from app.payments import get_payment_provider, status_banner_for_order
from app.schemas import (
    CartItemIn,
    CartValidateResponse,
    CheckoutRequestIn,
    CheckoutResponseOut,
    DeliveryAddressOut,
    MaterialChangeOut,
    OrderItemOut,
    OrderOut,
    ProductOut,
    ValidatedCartItemOut,
)


class StoreException(Exception):
    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        details: dict | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def generate_order_reference() -> str:
    date_part = datetime.now(timezone.utc).strftime("%Y%m%d")
    random_part = secrets.token_hex(3).upper()
    return f"AUR-{date_part}-{random_part}"


def normalize_items(raw_items: list[CartItemIn]) -> list[CartItemIn]:
    merged: dict[int, CartItemIn] = {}
    for item in raw_items:
        if item.product_id in merged:
            combined = merged[item.product_id].quantity + item.quantity
            if combined > 99:
                raise StoreException(
                    400, "INVALID_QUANTITY", "Combined item quantity cannot exceed 99."
                )
            merged[item.product_id].quantity = combined
        else:
            merged[item.product_id] = CartItemIn(
                product_id=item.product_id,
                quantity=item.quantity,
                expected_unit_price_pence=item.expected_unit_price_pence,
            )
    return sorted(merged.values(), key=lambda x: x.product_id)


def list_products(
    db: Session,
    *,
    q: str | None = None,
    category: str | None = None,
    sort: str = "featured",
    featured_only: bool = False,
) -> list[ProductOut]:
    stmt = select(Product).where(Product.is_active.is_(True))

    if category and category != "all":
        if category not in {"homeware", "stationery", "accessories"}:
            raise StoreException(400, "INVALID_CATEGORY", "Unsupported product category filter.")
        stmt = stmt.where(Product.category == category)

    if featured_only:
        stmt = stmt.where(Product.featured.is_(True))

    if q and q.strip():
        pattern = f"%{q.strip()[:80].lower()}%"
        stmt = stmt.where(
            or_(
                Product.name.ilike(pattern),
                Product.description.ilike(pattern),
                Product.category.ilike(pattern),
            )
        )

    if sort == "price_asc":
        stmt = stmt.order_by(asc(Product.price_pence), asc(Product.id))
    elif sort == "price_desc":
        stmt = stmt.order_by(desc(Product.price_pence), asc(Product.id))
    elif sort == "name_asc":
        stmt = stmt.order_by(asc(Product.name), asc(Product.id))
    elif sort == "featured":
        stmt = stmt.order_by(desc(Product.featured), asc(Product.id))
    else:
        raise StoreException(400, "INVALID_SORT", "Unsupported sort parameter.")

    rows = db.scalars(stmt).all()
    return [ProductOut.model_validate(row) for row in rows]


def get_product_by_slug(db: Session, slug: str) -> ProductOut:
    clean = slug.strip().lower()
    product = db.scalar(
        select(Product).where(Product.slug == clean, Product.is_active.is_(True))
    )
    if not product:
        raise StoreException(404, "PRODUCT_NOT_FOUND", "Product could not be found.")
    return ProductOut.model_validate(product)


def validate_cart(
    db: Session, raw_items: list[CartItemIn], settings: Settings
) -> CartValidateResponse:
    if not raw_items:
        return CartValidateResponse(
            items=[],
            material_changes=[],
            has_material_changes=False,
            can_checkout=False,
            subtotal_pence=0,
            shipping_pence=0,
            total_pence=0,
            currency="GBP",
            shipping_policy_summary=settings.shipping_policy_note,
            tax_policy_summary=settings.tax_policy_note,
        )

    items = normalize_items(raw_items)
    out_items: list[ValidatedCartItemOut] = []
    material_changes: list[MaterialChangeOut] = []
    subtotal_pence = 0
    can_checkout = True

    for req_item in items:
        product = db.get(Product, req_item.product_id)
        if not product or not product.is_active:
            can_checkout = False
            name = product.name if product else f"Product #{req_item.product_id}"
            slug = product.slug if product else ""
            material_changes.append(
                MaterialChangeOut(
                    product_id=req_item.product_id,
                    product_name=name,
                    slug=slug,
                    reason="discontinued",
                    message=f"{name} is no longer available in the catalogue.",
                    requested_quantity=req_item.quantity,
                    available_quantity=0,
                )
            )
            out_items.append(
                ValidatedCartItemOut(
                    product_id=req_item.product_id,
                    slug=slug,
                    name=name,
                    category=product.category if product else "homeware",
                    image_url=product.image_url if product else "",
                    unit_price_pence=product.price_pence if product else 0,
                    currency="GBP",
                    requested_quantity=req_item.quantity,
                    available_quantity=0,
                    is_active=False,
                    line_total_pence=0,
                    has_issue=True,
                )
            )
            continue

        item_has_issue = False
        if (
            req_item.expected_unit_price_pence is not None
            and req_item.expected_unit_price_pence != product.price_pence
        ):
            material_changes.append(
                MaterialChangeOut(
                    product_id=product.id,
                    product_name=product.name,
                    slug=product.slug,
                    reason="price_changed",
                    message=(
                        f"Price for {product.name} changed from "
                        f"£{req_item.expected_unit_price_pence / 100:.2f} to "
                        f"£{product.price_pence / 100:.2f}."
                    ),
                    previous_price_pence=req_item.expected_unit_price_pence,
                    current_price_pence=product.price_pence,
                    requested_quantity=req_item.quantity,
                    available_quantity=product.stock_quantity,
                )
            )

        if product.stock_quantity == 0:
            can_checkout = False
            item_has_issue = True
            material_changes.append(
                MaterialChangeOut(
                    product_id=product.id,
                    product_name=product.name,
                    slug=product.slug,
                    reason="out_of_stock",
                    message=f"{product.name} is currently out of stock.",
                    requested_quantity=req_item.quantity,
                    available_quantity=0,
                )
            )
        elif req_item.quantity > product.stock_quantity:
            can_checkout = False
            item_has_issue = True
            material_changes.append(
                MaterialChangeOut(
                    product_id=product.id,
                    product_name=product.name,
                    slug=product.slug,
                    reason="insufficient_stock",
                    message=(
                        f"Only {product.stock_quantity} unit"
                        f"{'' if product.stock_quantity == 1 else 's'} of {product.name} "
                        f"remaining (you requested {req_item.quantity})."
                    ),
                    requested_quantity=req_item.quantity,
                    available_quantity=product.stock_quantity,
                )
            )

        billable_qty = min(req_item.quantity, product.stock_quantity)
        line_total = product.price_pence * billable_qty
        subtotal_pence += line_total

        out_items.append(
            ValidatedCartItemOut(
                product_id=product.id,
                slug=product.slug,
                name=product.name,
                category=product.category,
                image_url=product.image_url,
                unit_price_pence=product.price_pence,
                currency="GBP",
                requested_quantity=req_item.quantity,
                available_quantity=product.stock_quantity,
                is_active=True,
                line_total_pence=line_total,
                has_issue=item_has_issue,
            )
        )

    shipping_pence = 0
    return CartValidateResponse(
        items=out_items,
        material_changes=material_changes,
        has_material_changes=len(material_changes) > 0,
        can_checkout=can_checkout,
        subtotal_pence=subtotal_pence,
        shipping_pence=shipping_pence,
        total_pence=subtotal_pence + shipping_pence,
        currency="GBP",
        shipping_policy_summary=settings.shipping_policy_note,
        tax_policy_summary=settings.tax_policy_note,
    )


def serialize_order(order: Order) -> OrderOut:
    return OrderOut(
        reference=order.reference,
        customer_name=order.customer_name,
        customer_email=order.customer_email,
        delivery_address=DeliveryAddressOut(
            line1=order.delivery_address_line1,
            line2=order.delivery_address_line2,
            city=order.delivery_city,
            postcode=order.delivery_postcode,
            country=order.delivery_country,
        ),
        subtotal_pence=order.subtotal_pence,
        shipping_pence=order.shipping_pence,
        total_pence=order.total_pence,
        currency="GBP",
        checkout_mode=order.checkout_mode,  # type: ignore[arg-type]
        payment_status=order.payment_status,
        order_status=order.order_status,
        fulfilment_status=order.fulfilment_status,
        status_banner=status_banner_for_order(
            order.checkout_mode, order.payment_status, order.order_status
        ),
        shipping_policy_summary=order.shipping_policy_summary,
        tax_policy_summary=order.tax_policy_summary,
        created_at=order.created_at.isoformat(),
        items=[OrderItemOut.model_validate(item) for item in order.items],
    )


def _compute_request_hash(payload: CheckoutRequestIn, items: list[CartItemIn]) -> str:
    canonical = json.dumps(
        {
            "customer": {
                "name": payload.customer.name,
                "email": payload.customer.email.lower(),
                "address_line1": payload.customer.address_line1,
                "address_line2": payload.customer.address_line2 or "",
                "city": payload.customer.city,
                "postcode": payload.customer.postcode.upper(),
                "country": payload.customer.country,
            },
            "items": [{"product_id": i.product_id, "quantity": i.quantity} for i in items],
        },
        sort_keys=True,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def create_checkout_order(
    db: Session, payload: CheckoutRequestIn, settings: Settings
) -> CheckoutResponseOut:
    items = normalize_items(payload.items)
    request_hash = _compute_request_hash(payload, items)
    payment_provider = get_payment_provider(settings)

    # Begin immediate SQLite write transaction for atomic inventory deduction
    bind_dialect = db.bind.dialect.name if db.bind else ""
    if bind_dialect == "sqlite":
        db.execute(text("BEGIN IMMEDIATE"))

    try:
        existing_req = db.scalar(
            select(CheckoutRequest).where(
                CheckoutRequest.idempotency_key == payload.idempotency_key
            )
        )
        if existing_req:
            if existing_req.request_hash != request_hash:
                raise StoreException(
                    409,
                    "IDEMPOTENCY_KEY_CONFLICT",
                    "This checkout session key was already used for a different cart or address.",
                )
            if (
                existing_req.status == "completed"
                and existing_req.order_id
                and existing_req.response_access_token
            ):
                existing_order = db.get(Order, existing_req.order_id)
                if existing_order:
                    db.commit()
                    return CheckoutResponseOut(
                        order=serialize_order(existing_order),
                        access_token=existing_req.response_access_token,
                        replayed=True,
                    )

        material_changes: list[dict] = []
        subtotal_pence = 0
        snapshots: list[dict] = []

        for req_item in items:
            product = db.get(Product, req_item.product_id)
            if not product or not product.is_active:
                material_changes.append(
                    {
                        "productId": req_item.product_id,
                        "productName": product.name if product else f"Product #{req_item.product_id}",
                        "reason": "discontinued",
                        "message": "An item in your bag is no longer available.",
                    }
                )
                continue

            if (
                req_item.expected_unit_price_pence is not None
                and req_item.expected_unit_price_pence != product.price_pence
            ):
                material_changes.append(
                    {
                        "productId": product.id,
                        "productName": product.name,
                        "reason": "price_changed",
                        "message": f"Price of {product.name} updated to £{product.price_pence / 100:.2f}.",
                    }
                )

            if product.stock_quantity < req_item.quantity:
                material_changes.append(
                    {
                        "productId": product.id,
                        "productName": product.name,
                        "reason": "out_of_stock" if product.stock_quantity == 0 else "insufficient_stock",
                        "message": (
                            f"{product.name} is out of stock."
                            if product.stock_quantity == 0
                            else f"Only {product.stock_quantity} left for {product.name}."
                        ),
                    }
                )
                continue

            result = db.execute(
                update(Product)
                .where(
                    Product.id == product.id,
                    Product.is_active.is_(True),
                    Product.stock_quantity >= req_item.quantity,
                )
                .values(stock_quantity=Product.stock_quantity - req_item.quantity)
            )
            if result.rowcount != 1:
                material_changes.append(
                    {
                        "productId": product.id,
                        "productName": product.name,
                        "reason": "insufficient_stock",
                        "message": f"Insufficient remaining stock for {product.name}.",
                    }
                )
                continue

            line_total = product.price_pence * req_item.quantity
            subtotal_pence += line_total
            snapshots.append(
                {
                    "product_id": product.id,
                    "product_slug": product.slug,
                    "product_name": product.name,
                    "unit_price_pence": product.price_pence,
                    "quantity": req_item.quantity,
                    "line_total_pence": line_total,
                }
            )

        if material_changes:
            raise StoreException(
                409,
                "MATERIAL_CHANGE",
                "Your bag changed since you loaded checkout. Please review before confirming.",
                {"materialChanges": material_changes},
            )

        shipping_pence = 0
        total_pence = subtotal_pence + shipping_pence

        if (
            payload.acknowledged_total_pence is not None
            and payload.acknowledged_total_pence != total_pence
        ):
            raise StoreException(
                409,
                "TOTAL_MISMATCH",
                "Order total changed on the server. Please review the updated summary.",
                {
                    "expectedTotalPence": payload.acknowledged_total_pence,
                    "recalculatedTotalPence": total_pence,
                },
            )

        order_reference = generate_order_reference()
        access_token = secrets.token_urlsafe(24)
        session_info = payment_provider.create_session(
            order_reference=order_reference,
            total_pence=total_pence,
            currency="GBP",
            customer_email=payload.customer.email.lower(),
            return_base_url=settings.public_base_url,
            access_token=access_token,
        )

        order = Order(
            reference=order_reference,
            access_token_hash=hash_token(access_token),
            customer_name=payload.customer.name,
            customer_email=payload.customer.email.lower(),
            delivery_address_line1=payload.customer.address_line1,
            delivery_address_line2=payload.customer.address_line2 or None,
            delivery_city=payload.customer.city,
            delivery_postcode=payload.customer.postcode.upper(),
            delivery_country=payload.customer.country,
            subtotal_pence=subtotal_pence,
            shipping_pence=shipping_pence,
            total_pence=total_pence,
            currency="GBP",
            checkout_mode=session_info.checkout_mode,
            payment_status=session_info.payment_status,
            order_status=session_info.order_status,
            fulfilment_status=session_info.fulfilment_status,
            shipping_policy_summary=settings.shipping_policy_note,
            tax_policy_summary=settings.tax_policy_note,
        )
        db.add(order)
        db.flush()

        for snap in snapshots:
            db.add(
                OrderItem(
                    order_id=order.id,
                    product_id=snap["product_id"],
                    product_slug=snap["product_slug"],
                    product_name=snap["product_name"],
                    unit_price_pence=snap["unit_price_pence"],
                    currency="GBP",
                    quantity=snap["quantity"],
                    line_total_pence=snap["line_total_pence"],
                )
            )

        db.add(
            CheckoutRequest(
                idempotency_key=payload.idempotency_key,
                request_hash=request_hash,
                status="completed",
                order_id=order.id,
                order_reference=order.reference,
                response_access_token=access_token,
            )
        )

        db.commit()
        db.refresh(order)
        return CheckoutResponseOut(
            order=serialize_order(order),
            access_token=access_token,
            replayed=False,
            redirect_url=session_info.redirect_url,
        )
    except Exception:
        db.rollback()
        raise


def get_order_by_reference(db: Session, reference: str, access_token: str | None) -> OrderOut:
    clean_ref = reference.strip().upper()
    if not access_token or len(access_token.strip()) < 16:
        raise StoreException(
            401,
            "ORDER_ACCESS_DENIED",
            "A valid order access token is required to view this order.",
        )

    order = db.scalar(select(Order).where(Order.reference == clean_ref))
    if not order:
        raise StoreException(404, "ORDER_NOT_FOUND", "Order could not be found or token is invalid.")

    if not hmac.compare_digest(hash_token(access_token.strip()), order.access_token_hash):
        raise StoreException(403, "ORDER_ACCESS_DENIED", "Order could not be found or token is invalid.")

    return serialize_order(order)


def process_payment_webhook(
    db: Session,
    *,
    raw_body: bytes,
    signature_header: str | None,
    settings: Settings,
) -> dict:
    provider = get_payment_provider(settings)
    if provider.mode != "hosted":
        raise StoreException(
            400,
            "WEBHOOK_DISABLED_IN_DEMO",
            "Payment webhooks are inactive while PAYMENT_MODE=demo.",
        )
    if not provider.verify_webhook_signature(raw_body, signature_header):
        raise StoreException(401, "INVALID_WEBHOOK_SIGNATURE", "Webhook signature verification failed.")

    event = json.loads(raw_body.decode("utf-8"))
    event_id = event.get("id") or hashlib.sha256(raw_body).hexdigest()
    event_type = event.get("type") or ""
    data = event.get("data") or {}
    order_ref = data.get("orderReference")

    if not order_ref:
        raise StoreException(400, "MISSING_ORDER_REFERENCE", "Webhook event missing orderReference.")

    bind_dialect = db.bind.dialect.name if db.bind else ""
    if bind_dialect == "sqlite":
        db.execute(text("BEGIN IMMEDIATE"))
    try:
        if db.scalar(select(PaymentWebhookEvent).where(PaymentWebhookEvent.event_id == event_id)):
            db.commit()
            return {"received": True, "deduplicated": True}

        order = db.scalar(select(Order).where(Order.reference == order_ref))
        if not order:
            raise StoreException(404, "ORDER_NOT_FOUND", "Order referenced by webhook was not found.")

        if event_type == "checkout.session.completed":
            amount = data.get("amountPence")
            if amount is not None and amount != order.total_pence:
                raise StoreException(400, "AMOUNT_MISMATCH", "Webhook amount does not match server total.")
            order.payment_status = "paid"
            order.order_status = "confirmed"
        elif event_type in {"checkout.session.expired", "payment_intent.payment_failed"}:
            if order.payment_status == "pending":
                for item in order.items:
                    db.execute(
                        update(Product)
                        .where(Product.id == item.product_id)
                        .values(stock_quantity=Product.stock_quantity + item.quantity)
                    )
                order.payment_status = "expired" if event_type == "checkout.session.expired" else "failed"
                order.order_status = "cancelled"

        db.add(PaymentWebhookEvent(provider="hosted", event_id=event_id, event_type=event_type))
        db.commit()
        return {"received": True, "deduplicated": False}
    except Exception:
        db.rollback()
        raise
