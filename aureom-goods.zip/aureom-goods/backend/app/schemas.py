from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


def to_camel(string: str) -> str:
    parts = string.split("_")
    return parts[0] + "".join(word.capitalize() for word in parts[1:])


class CamelModel(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class ProductOut(CamelModel):
    id: int
    slug: str
    name: str
    description: str
    category: Literal["homeware", "stationery", "accessories"]
    image_url: str
    price_pence: int
    currency: Literal["GBP"]
    stock_quantity: int
    is_active: bool
    featured: bool


class CartItemIn(CamelModel):
    product_id: int = Field(..., gt=0)
    quantity: int = Field(..., ge=1, le=99)
    expected_unit_price_pence: int | None = Field(default=None, ge=0)


class CartValidateRequest(CamelModel):
    items: list[CartItemIn] = Field(default_factory=list, max_length=50)


class MaterialChangeOut(CamelModel):
    product_id: int
    product_name: str
    slug: str
    reason: Literal["discontinued", "out_of_stock", "insufficient_stock", "price_changed"]
    message: str
    previous_price_pence: int | None = None
    current_price_pence: int | None = None
    requested_quantity: int
    available_quantity: int


class ValidatedCartItemOut(CamelModel):
    product_id: int
    slug: str
    name: str
    category: str
    image_url: str
    unit_price_pence: int
    currency: Literal["GBP"]
    requested_quantity: int
    available_quantity: int
    is_active: bool
    line_total_pence: int
    has_issue: bool


class CartValidateResponse(CamelModel):
    items: list[ValidatedCartItemOut]
    material_changes: list[MaterialChangeOut]
    has_material_changes: bool
    can_checkout: bool
    subtotal_pence: int
    shipping_pence: int
    total_pence: int
    currency: Literal["GBP"]
    shipping_policy_summary: str
    tax_policy_summary: str


class CustomerIn(CamelModel):
    name: str = Field(..., min_length=2, max_length=120)
    email: EmailStr
    address_line1: str = Field(..., min_length=4, max_length=160)
    address_line2: str | None = Field(default="", max_length=160)
    city: str = Field(..., min_length=2, max_length=100)
    postcode: str = Field(..., min_length=3, max_length=20)
    country: str = Field(default="United Kingdom", min_length=2, max_length=80)

    @field_validator("name", "address_line1", "city", "postcode", "country", mode="before")
    @classmethod
    def strip_text(cls, value: str) -> str:
        if isinstance(value, str):
            return value.strip()
        return value


class CheckoutRequestIn(CamelModel):
    idempotency_key: str = Field(..., min_length=8, max_length=120, pattern=r"^[a-zA-Z0-9_-]+$")
    customer: CustomerIn
    items: list[CartItemIn] = Field(..., min_length=1, max_length=50)
    acknowledged_total_pence: int | None = Field(default=None, ge=0)


class OrderItemOut(CamelModel):
    id: int
    product_id: int
    product_slug: str
    product_name: str
    unit_price_pence: int
    currency: Literal["GBP"]
    quantity: int
    line_total_pence: int


class DeliveryAddressOut(CamelModel):
    line1: str
    line2: str | None = None
    city: str
    postcode: str
    country: str


class OrderOut(CamelModel):
    reference: str
    customer_name: str
    customer_email: str
    delivery_address: DeliveryAddressOut
    subtotal_pence: int
    shipping_pence: int
    total_pence: int
    currency: Literal["GBP"]
    checkout_mode: Literal["demo", "hosted"]
    payment_status: str
    order_status: str
    fulfilment_status: str
    status_banner: str
    shipping_policy_summary: str
    tax_policy_summary: str
    created_at: str
    items: list[OrderItemOut]


class CheckoutResponseOut(CamelModel):
    order: OrderOut
    access_token: str
    replayed: bool
    redirect_url: str | None = None
