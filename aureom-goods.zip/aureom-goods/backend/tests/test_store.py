from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import sessionmaker

from app.database import Base, create_db_engine, get_db
from app.main import app
from app.models import Order, Product
from app.seed import seed_products


@pytest.fixture()
def test_env(tmp_path):
    db_file = tmp_path / "test_aureom.db"
    engine = create_db_engine(f"sqlite:///{db_file}")
    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(
        bind=engine, autoflush=False, autocommit=False, expire_on_commit=False
    )

    with TestingSessionLocal() as db:
        seed_products(db)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    yield client, TestingSessionLocal
    app.dependency_overrides.clear()
    engine.dispose()


def _customer():
    return {
        "name": "Clara Bennett",
        "email": "clara@example.co.uk",
        "addressLine1": "14 Meadow Lane",
        "addressLine2": "Studio 3",
        "city": "Bristol",
        "postcode": "BS1 4TR",
        "country": "United Kingdom",
    }


def test_product_retrieval(test_env):
    client, _ = test_env
    res = client.get("/api/products")
    assert res.status_code == 200
    body = res.json()
    assert body["count"] == 8

    detail = client.get("/api/products/studio-mug")
    assert detail.status_code == 200
    assert detail.json()["product"]["pricePence"] == 2200

    missing = client.get("/api/products/does-not-exist")
    assert missing.status_code == 404


def test_backend_price_calculation_ignores_tampered_client_values(test_env):
    client, SessionMaker = test_env
    with SessionMaker() as db:
        mug = db.scalar(select(Product).where(Product.slug == "studio-mug"))
        lamp = db.scalar(select(Product).where(Product.slug == "desk-lamp"))

    # Client sends bogus expectedUnitPricePence without matching real server price -> rejected with 409
    tampered = client.post(
        "/api/checkout",
        json={
            "idempotencyKey": "chk_tampered_price_01",
            "customer": _customer(),
            "items": [{"productId": mug.id, "quantity": 2, "expectedUnitPricePence": 1}],
        },
    )
    assert tampered.status_code == 409

    # Valid checkout calculates exact total on server (2 * 2200 + 14500 = 18900)
    res = client.post(
        "/api/checkout",
        json={
            "idempotencyKey": "chk_valid_price_01",
            "customer": _customer(),
            "items": [
                {"productId": mug.id, "quantity": 2},
                {"productId": lamp.id, "quantity": 1},
            ],
        },
    )
    assert res.status_code == 201
    order = res.json()["order"]
    assert order["subtotalPence"] == 18900
    assert order["shippingPence"] == 0
    assert order["totalPence"] == 18900
    assert order["paymentStatus"] == "no_payment_taken"
    assert order["orderStatus"] == "confirmed_demo"

    # Mutate catalogue price after purchase: order history snapshot remains unchanged
    with SessionMaker() as db:
        mug_row = db.scalar(select(Product).where(Product.slug == "studio-mug"))
        mug_row.price_pence = 9900
        mug_row.name = "Renamed Studio Mug"
        db.commit()

    ref = order["reference"]
    token = res.json()["accessToken"]
    fetched = client.get(f"/api/orders/{ref}?token={token}")
    assert fetched.status_code == 200
    assert fetched.json()["order"]["items"][0]["productName"] == "Studio Mug"
    assert fetched.json()["order"]["items"][0]["unitPricePence"] == 2200


def test_invalid_quantities_rejected(test_env):
    client, SessionMaker = test_env
    with SessionMaker() as db:
        mug = db.scalar(select(Product).where(Product.slug == "studio-mug"))

    for bad_qty in [0, -2, 100, "two"]:
        res = client.post(
            "/api/checkout",
            json={
                "idempotencyKey": f"chk_bad_qty_{bad_qty}",
                "customer": _customer(),
                "items": [{"productId": mug.id, "quantity": bad_qty}],
            },
        )
        assert res.status_code in (400, 422)


def test_insufficient_stock_and_atomic_rollback(test_env):
    client, SessionMaker = test_env
    with SessionMaker() as db:
        mug = db.scalar(select(Product).where(Product.slug == "studio-mug"))
        lamp = db.scalar(select(Product).where(Product.slug == "desk-lamp"))
        initial_mug_stock = mug.stock_quantity
        initial_lamp_stock = lamp.stock_quantity

    # First item valid (2 mugs), second item exceeds Desk Lamp stock (7 available, requesting 9)
    res = client.post(
        "/api/checkout",
        json={
            "idempotencyKey": "chk_atomic_rollback_01",
            "customer": _customer(),
            "items": [
                {"productId": mug.id, "quantity": 2},
                {"productId": lamp.id, "quantity": initial_lamp_stock + 2},
            ],
        },
    )
    assert res.status_code == 409

    # Verify Studio Mug stock was NOT partially deducted
    with SessionMaker() as db:
        mug_after = db.scalar(select(Product).where(Product.id == mug.id))
        lamp_after = db.scalar(select(Product).where(Product.id == lamp.id))
        orders_count = len(db.scalars(select(Order)).all())
        assert mug_after.stock_quantity == initial_mug_stock
        assert lamp_after.stock_quantity == initial_lamp_stock
        assert orders_count == 0


def test_duplicate_checkout_requests_idempotent(test_env):
    client, SessionMaker = test_env
    with SessionMaker() as db:
        tote = db.scalar(select(Product).where(Product.slug == "everyday-tote"))
        initial_stock = tote.stock_quantity

    payload = {
        "idempotencyKey": "chk_idempotent_key_01",
        "customer": _customer(),
        "items": [{"productId": tote.id, "quantity": 3}],
    }
    first = client.post("/api/checkout", json=payload)
    second = client.post("/api/checkout", json=payload)

    assert first.status_code == 201
    assert second.status_code == 200
    assert second.json()["replayed"] is True
    assert first.json()["order"]["reference"] == second.json()["order"]["reference"]

    with SessionMaker() as db:
        tote_after = db.scalar(select(Product).where(Product.id == tote.id))
        assert tote_after.stock_quantity == initial_stock - 3
        assert len(db.scalars(select(Order)).all()) == 1


def test_competing_orders_prevent_overselling(test_env):
    client, SessionMaker = test_env
    with SessionMaker() as db:
        lamp = db.scalar(select(Product).where(Product.slug == "desk-lamp"))
        lamp.stock_quantity = 5
        db.commit()
        lamp_id = lamp.id

    def submit(idx: int):
        return client.post(
            "/api/checkout",
            json={
                "idempotencyKey": f"chk_competing_order_{idx}",
                "customer": _customer(),
                "items": [{"productId": lamp_id, "quantity": 4}],
            },
        )

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(submit, [1, 2]))

    statuses = sorted(r.status_code for r in results)
    assert statuses == [201, 409]

    with SessionMaker() as db:
        lamp_after = db.scalar(select(Product).where(Product.id == lamp_id))
        assert lamp_after.stock_quantity == 1


def test_protected_order_access(test_env):
    client, SessionMaker = test_env
    with SessionMaker() as db:
        notebook = db.scalar(select(Product).where(Product.slug == "field-notebook"))

    created = client.post(
        "/api/checkout",
        json={
            "idempotencyKey": "chk_protected_order_01",
            "customer": _customer(),
            "items": [{"productId": notebook.id, "quantity": 1}],
        },
    )
    assert created.status_code == 201
    ref = created.json()["order"]["reference"]
    token = created.json()["accessToken"]

    assert client.get(f"/api/orders/{ref}").status_code == 401
    assert client.get(f"/api/orders/{ref}?token=wrong_token_value_123456").status_code == 403
    ok = client.get(f"/api/orders/{ref}?token={token}")
    assert ok.status_code == 200
    assert ok.json()["order"]["reference"] == ref


def test_cart_to_confirmation_flow(test_env):
    client, SessionMaker = test_env
    with SessionMaker() as db:
        mug = db.scalar(select(Product).where(Product.slug == "studio-mug"))

    validated = client.post(
        "/api/cart/validate",
        json={"items": [{"productId": mug.id, "quantity": 2, "expectedUnitPricePence": 2200}]},
    )
    assert validated.status_code == 200
    v_body = validated.json()
    assert v_body["canCheckout"] is True
    assert v_body["totalPence"] == 4400

    checked_out = client.post(
        "/api/checkout",
        json={
            "idempotencyKey": "chk_full_flow_01",
            "customer": _customer(),
            "items": [{"productId": mug.id, "quantity": 2, "expectedUnitPricePence": 2200}],
            "acknowledgedTotalPence": v_body["totalPence"],
        },
    )
    assert checked_out.status_code == 201
    ref = checked_out.json()["order"]["reference"]
    token = checked_out.json()["accessToken"]

    confirmed = client.get(f"/api/orders/{ref}?token={token}")
    assert confirmed.status_code == 200
    assert confirmed.json()["order"]["statusBanner"] == "Demo order saved — no payment taken."
