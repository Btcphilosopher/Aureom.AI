# Aureom Goods

Minimalist ecommerce storefront for everyday homeware, stationery, and accessories — built with React, TypeScript, Tailwind CSS, FastAPI, SQLAlchemy, Alembic, and SQLite.

## Project Structure

```text
aureom-goods/
  frontend/        # React + TypeScript + Vite + Tailwind CSS storefront
  backend/         # Python + FastAPI + SQLAlchemy + Alembic + SQLite API
  README.md
```

## Quick Start (Local Development)

### 1. Backend (FastAPI + SQLite + Migrations)

```bash
cd aureom-goods/backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env

# Run Alembic database migrations
alembic upgrade head

# Seed the 8 initial products (safe to run repeatedly)
python -m app.seed

# Start FastAPI server on port 8000
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### 2. Frontend (React + Vite + Tailwind CSS)

```bash
cd aureom-goods/frontend
npm install
cp .env.example .env

# Start Vite dev server on port 5173 (proxies /api -> http://127.0.0.1:8000)
npm run dev
```

Open `http://localhost:5173` in your browser.

### 3. Production (Same-Origin Serving)

Build the Vite frontend and let FastAPI serve both the static SPA and `/api/*` from the same origin:

```bash
cd aureom-goods/frontend
npm run build

cd ../backend
SERVE_STATIC=true uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Running Tests

### Backend Tests (Pytest)

```bash
cd aureom-goods/backend
pytest -v
```

### Workspace Integration Tests (Node SQLite + Store Service)

From the workspace root:

```bash
npm test
```

## API Endpoints

- `GET /api/health` — Database connectivity, active product count, and payment mode (`demo` or `hosted`)
- `GET /api/products` — List active products with `q`, `category`, `sort`, and `featured` query params
- `GET /api/products/{slug}` — Single product detail
- `POST /api/cart/validate` — Refresh cart item prices/availability from server and report material changes
- `POST /api/checkout` — Idempotent, atomic transactional checkout (`BEGIN IMMEDIATE`)
- `GET /api/orders/{reference}?token=...` — Token-protected order confirmation retrieval
- `POST /api/payments/webhook` — Signature-verified hosted payment webhook (active when `PAYMENT_MODE=hosted`)

## Policies & Optional Hosted Payments

- **Shipping**: Complimentary standard UK delivery on all orders (`£0.00`).
- **Tax**: Displayed GBP prices include applicable UK VAT; no dynamic tax calculation is added.
- **Demo Mode (Default)**: Saves real orders and deducts stock atomically without requesting card details (`"Demo order saved — no payment taken."`).
- **Hosted Payments (Optional)**: Set `PAYMENT_MODE=hosted`, `PAYMENT_PROVIDER_SECRET_KEY`, and `PAYMENT_WEBHOOK_SECRET` on the server to enable the `HostedPaymentProvider` adapter and webhook signature verification.
