export type ProductCategory = 'homeware' | 'stationery' | 'accessories';

export interface ProductDTO {
  id: number;
  slug: string;
  name: string;
  description: string;
  category: ProductCategory;
  imageUrl: string;
  pricePence: number;
  currency: 'GBP';
  stockQuantity: number;
  isActive: boolean;
  featured: boolean;
}

export interface CartClientItem {
  productId: number;
  slug: string;
  name: string;
  unitPricePence: number;
  quantity: number;
}

export interface CartValidationRequestItem {
  productId: number;
  quantity: number;
  expectedUnitPricePence?: number;
}

export type CartChangeReason =
  | 'discontinued'
  | 'out_of_stock'
  | 'insufficient_stock'
  | 'price_changed';

export interface CartMaterialChange {
  productId: number;
  productName: string;
  slug: string;
  reason: CartChangeReason;
  message: string;
  previousPricePence?: number;
  currentPricePence?: number;
  requestedQuantity: number;
  availableQuantity: number;
}

export interface ValidatedCartItem {
  productId: number;
  slug: string;
  name: string;
  category: ProductCategory;
  imageUrl: string;
  unitPricePence: number;
  currency: 'GBP';
  requestedQuantity: number;
  availableQuantity: number;
  isActive: boolean;
  lineTotalPence: number;
  hasIssue: boolean;
}

export interface CartValidationResponse {
  items: ValidatedCartItem[];
  materialChanges: CartMaterialChange[];
  hasMaterialChanges: boolean;
  canCheckout: boolean;
  subtotalPence: number;
  shippingPence: number;
  totalPence: number;
  currency: 'GBP';
  shippingPolicySummary: string;
  taxPolicySummary: string;
}

export interface CheckoutCustomerInput {
  name: string;
  email: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  postcode: string;
  country: string;
}

export interface CheckoutRequestPayload {
  idempotencyKey: string;
  customer: CheckoutCustomerInput;
  items: CartValidationRequestItem[];
  acknowledgedTotalPence?: number;
}

export type PaymentStatus =
  | 'no_payment_taken'
  | 'pending'
  | 'paid'
  | 'failed'
  | 'cancelled'
  | 'expired';

export type OrderStatus =
  | 'confirmed_demo'
  | 'awaiting_payment'
  | 'confirmed'
  | 'cancelled';

export type FulfilmentStatus = 'unfulfilled' | 'processing' | 'dispatched';

export interface OrderItemDTO {
  id: number;
  productId: number;
  productSlug: string;
  productName: string;
  unitPricePence: number;
  currency: 'GBP';
  quantity: number;
  lineTotalPence: number;
}

export interface OrderDTO {
  reference: string;
  customerName: string;
  customerEmail: string;
  deliveryAddress: {
    line1: string;
    line2: string | null;
    city: string;
    postcode: string;
    country: string;
  };
  subtotalPence: number;
  shippingPence: number;
  totalPence: number;
  currency: 'GBP';
  checkoutMode: 'demo' | 'hosted';
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  fulfilmentStatus: FulfilmentStatus;
  statusBanner: string;
  shippingPolicySummary: string;
  taxPolicySummary: string;
  createdAt: string;
  items: OrderItemDTO[];
}

export interface CheckoutSuccessResponse {
  order: OrderDTO;
  accessToken: string;
  replayed: boolean;
  redirectUrl?: string;
}

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
}
