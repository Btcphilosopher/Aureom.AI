import { NextRequest, NextResponse } from 'next/server';
import { StoreError } from './store-service';

const MAX_JSON_BODY_BYTES = 32 * 1024; // 32 KB bounded request size

export function getCorsHeaders(req: NextRequest): Record<string, string> {
  const origin = req.headers.get('origin');
  const allowed = (
    process.env.AUREOM_ALLOWED_ORIGINS ??
    'http://localhost:3000,http://127.0.0.1:3000,http://localhost:5173'
  )
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  if (origin && allowed.includes(origin)) {
    return {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, Idempotency-Key',
      Vary: 'Origin',
    };
  }
  return {};
}

export async function readBoundedJson<T>(req: NextRequest): Promise<T> {
  const contentLength = req.headers.get('content-length');
  if (contentLength && Number(contentLength) > MAX_JSON_BODY_BYTES) {
    throw new StoreError(413, 'PAYLOAD_TOO_LARGE', 'Request payload exceeds maximum allowed size.');
  }

  const rawText = await req.text();
  if (Buffer.byteLength(rawText, 'utf8') > MAX_JSON_BODY_BYTES) {
    throw new StoreError(413, 'PAYLOAD_TOO_LARGE', 'Request payload exceeds maximum allowed size.');
  }

  try {
    return JSON.parse(rawText) as T;
  } catch {
    throw new StoreError(400, 'INVALID_JSON', 'Request body must be valid JSON.');
  }
}

export function handleApiError(err: unknown, req?: NextRequest): NextResponse {
  const corsHeaders = req ? getCorsHeaders(req) : {};

  if (err instanceof StoreError) {
    return NextResponse.json(
      {
        error: {
          code: err.code,
          message: err.message,
          ...(err.details ? { details: err.details } : {}),
        },
      },
      { status: err.statusCode, headers: corsHeaders },
    );
  }

  // Redacted server logging: do not emit PII, customer payloads, or stack secrets
  console.error('[aureom-api] Unexpected error', {
    name: err instanceof Error ? err.name : 'UnknownError',
  });

  return NextResponse.json(
    {
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An unexpected server error occurred. Please try again.',
      },
    },
    { status: 500, headers: corsHeaders },
  );
}
