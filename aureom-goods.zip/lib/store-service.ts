import crypto from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { getPaymentProvider, getOrderStatusBanner } from './payment.ts';
import type {
  CartMaterialChange,
  CartValidationRequestItem,
  CartValidationResponse,
  CheckoutRequestPayload,
  CheckoutSuccessResponse,
  OrderDTO,
  OrderItemDTO,
  ProductCategory,
  ProductDTO,
  ValidatedCartItem,
} from './types';

export class StoreError extends Error {
  readonly statusCode: number;
  readonly code: string;
  readonly details?: Record<string, unknown>;

  constructor(
    statusCode: number,
    code: string,
    message: string,
    details?: Record<string, unknown>,
  ) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

export function getStorePolicies(): {
  shippingPolicySummary: string;
  taxPolicySummary: string;
} {
  return {
    shippingPolicySummary:
      process.env.AUREOM_SHIPPING_POLICY_NOTE ??
      'Complimentary standard UK delivery on all orders (2–4 working days).',
    taxPolicySummary:
      process.env.AUREOM_TAX_POLICY_NOTE ??
      'Displayed prices include applicable UK VAT. No additional tax is calculated at checkout.',
  };
}

interface ProductRow {
  id: number;
  slug: string;
  name: string;
  description: string;
  category: ProductCategory;
  image_url: string;
  price_pence: number;
  currency: 'GBP';
  stock_quantity: number;
  is_active: number;
  featured: number;
}

function mapProductRow(row: ProductRow): ProductDTO {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    description: row.description,
    category: row.category,
    imageUrl: row.image_url,
    pricePence: row.price_pence,
    currency: row.currency,
    stockQuantity: row.stock_quantity,
    isActive: row.is_active === 1,
    featured: row.featured === 1,
  };
}

export interface ListProductsParams {
  q?: string;
  category?: string;
  sort?: 'featured' | 'price_asc' | 'price_desc' | 'name_asc';
  featuredOnly?: boolean;
}

export function listProducts(
  db: DatabaseSync,
  params: ListProductsParams = {},
): ProductDTO[] {
  const conditions: string[] = ['is_active = 1'];
  const values: Array<string | number> = [];

  if (params.category && params.category !== 'all') {
    const validCategories = new Set(['homeware', 'stationery', 'accessories']);
    if (!validCategories.has(params.category)) {
      throw new StoreError(400, 'INVALID_CATEGORY', 'Unsupported product category filter.');
    }
    conditions.push('category = ?');
    values.push(params.category);
  }

  if (params.featuredOnly) {
    conditions.push('featured = 1');
  }

  if (params.q && params.q.trim().length > 0) {
    const term = params.q.trim().slice(0, 80);
    conditions.push('(LOWER(name) LIKE ? OR LOWER(description) LIKE ? OR LOWER(category) LIKE ?)');
    const pattern = `%${term.toLowerCase()}%`;
    values.push(pattern, pattern, pattern);
  }

  let orderBy = 'featured DESC, id ASC';
  switch (params.sort) {
    case 'price_asc':
      orderBy = 'price_pence ASC, id ASC';
      break;
    case 'price_desc':
      orderBy = 'price_pence DESC, id ASC';
      break;
    case 'name_asc':
      orderBy = 'name ASC, id ASC';
      break;
    case 'featured':
    default:
      orderBy = 'featured DESC, id ASC';
      break;
  }

  const sql = `
    SELECT id, slug, name, description, category, image_url, price_pence, currency, stock_quantity, is_active, featured
    FROM products
    WHERE ${conditions.join(' AND ')}
    ORDER BY ${orderBy}
  `;
  const rows = db.prepare(sql).all(...values) as unknown as ProductRow[];
  return rows.map(mapProductRow);
}

export function getProductBySlug(db: DatabaseSync, slug: string): ProductDTO {
  const cleanSlug = slug.trim().toLowerCase();
  if (!/^[a-z0-9-]{1,80}$/.test(cleanSlug)) {
    throw new StoreError(400, 'INVALID_SLUG', 'Invalid product identifier.');
  }

  const row = db
    .prepare(
      `SELECT id, slug, name, description, category, image_url, price_pence, currency, stock_quantity, is_active, featured
       FROM products
       WHERE slug = ? AND is_active = 1`,
    )
    .get(cleanSlug) as unknown as ProductRow | undefined;

  if (!row) {
    throw new StoreError(404, 'PRODUCT_NOT_FOUND', 'Product could not be found.');
  }

  return mapProductRow(row);
}

function normalizeRequestedItems(
  rawItems: CartValidationRequestItem[],
): CartValidationRequestItem[] {
  if (!Array.isArray(rawItems) || rawItems.length === 0) {
    throw new StoreError(400, 'EMPTY_CART', 'Your bag is empty.');
  }
  if (rawItems.length > 50) {
    throw new StoreError(400, 'TOO_MANY_ITEMS', 'Cart cannot exceed 50 distinct line items.');
  }

  const merged = new Map<number, CartValidationRequestItem>();

  for (const item of rawItems) {
    if (
      typeof item?.productId !== 'number' ||
      !Number.isInteger(item.productId) ||
      item.productId <= 0
    ) {
      throw new StoreError(400, 'INVALID_PRODUCT_ID', 'Each cart item must have a valid integer product ID.');
    }
    if (
      typeof item?.quantity !== 'number' ||
      !Number.isInteger(item.quantity) ||
      item.quantity < 1 ||
      item.quantity > 99
    ) {
      throw new StoreError(
        400,
        'INVALID_QUANTITY',
        'Item quantity must be a whole number between 1 and 99.',
      );
    }
    if (
      item.expectedUnitPricePence !== undefined &&
      (!Number.isInteger(item.expectedUnitPricePence) || item.expectedUnitPricePence < 0)
    ) {
      throw new StoreError(400, 'INVALID_PRICE_FORMAT', 'Expected unit price must be a non-negative integer.');
    }

    const prev = merged.get(item.productId);
    if (prev) {
      const combinedQty = prev.quantity + item.quantity;
      if (combinedQty > 99) {
        throw new StoreError(400, 'INVALID_QUANTITY', 'Combined item quantity cannot exceed 99.');
      }
      prev.quantity = combinedQty;
    } else {
      merged.set(item.productId, {
        productId: item.productId,
        quantity: item.quantity,
        expectedUnitPricePence: item.expectedUnitPricePence,
      });
    }
  }

  return Array.from(merged.values()).sort((a, b) => a.productId - b.productId);
}

export function validateCart(
  db: DatabaseSync,
  rawItems: CartValidationRequestItem[],
): CartValidationResponse {
  const { shippingPolicySummary, taxPolicySummary } = getStorePolicies();

  if (!Array.isArray(rawItems) || rawItems.length === 0) {
    return {
      items: [],
      materialChanges: [],
      hasMaterialChanges: false,
      canCheckout: false,
      subtotalPence: 0,
      shippingPence: 0,
      totalPence: 0,
      currency: 'GBP',
      shippingPolicySummary,
      taxPolicySummary,
    };
  }

  const normalized = normalizeRequestedItems(rawItems);
  const selectProduct = db.prepare(
    `SELECT id, slug, name, description, category, image_url, price_pence, currency, stock_quantity, is_active, featured
     FROM products
     WHERE id = ?`,
  );

  const items: ValidatedCartItem[] = [];
  const materialChanges: CartMaterialChange[] = [];
  let subtotalPence = 0;
  let canCheckout = true;

  for (const reqItem of normalized) {
    const row = selectProduct.get(reqItem.productId) as unknown as ProductRow | undefined;

    if (!row || row.is_active !== 1) {
      canCheckout = false;
      const fallbackName = row?.name ?? `Product #${reqItem.productId}`;
      const fallbackSlug = row?.slug ?? '';
      materialChanges.push({
        productId: reqItem.productId,
        productName: fallbackName,
        slug: fallbackSlug,
        reason: 'discontinued',
        message: `${fallbackName} is no longer available in the catalogue.`,
        requestedQuantity: reqItem.quantity,
        availableQuantity: 0,
      });
      items.push({
        productId: reqItem.productId,
        slug: fallbackSlug,
        name: fallbackName,
        category: (row?.category ?? 'homeware') as ProductCategory,
        imageUrl: row?.image_url ?? '',
        unitPricePence: row?.price_pence ?? 0,
        currency: 'GBP',
        requestedQuantity: reqItem.quantity,
        availableQuantity: 0,
        isActive: false,
        lineTotalPence: 0,
        hasIssue: true,
      });
      continue;
    }

    let itemHasIssue = false;

    if (
      reqItem.expectedUnitPricePence !== undefined &&
      reqItem.expectedUnitPricePence !== row.price_pence
    ) {
      materialChanges.push({
        productId: row.id,
        productName: row.name,
        slug: row.slug,
        reason: 'price_changed',
        message: `Price for ${row.name} changed from £${(reqItem.expectedUnitPricePence / 100).toFixed(2)} to £${(row.price_pence / 100).toFixed(2)}.`,
        previousPricePence: reqItem.expectedUnitPricePence,
        currentPricePence: row.price_pence,
        requestedQuantity: reqItem.quantity,
        availableQuantity: row.stock_quantity,
      });
    }

    if (row.stock_quantity === 0) {
      canCheckout = false;
      itemHasIssue = true;
      materialChanges.push({
        productId: row.id,
        productName: row.name,
        slug: row.slug,
        reason: 'out_of_stock',
        message: `${row.name} is currently out of stock.`,
        requestedQuantity: reqItem.quantity,
        availableQuantity: 0,
      });
    } else if (reqItem.quantity > row.stock_quantity) {
      canCheckout = false;
      itemHasIssue = true;
      materialChanges.push({
        productId: row.id,
        productName: row.name,
        slug: row.slug,
        reason: 'insufficient_stock',
        message: `Only ${row.stock_quantity} unit${row.stock_quantity === 1 ? '' : 's'} of ${row.name} remaining (you requested ${reqItem.quantity}).`,
        requestedQuantity: reqItem.quantity,
        availableQuantity: row.stock_quantity,
      });
    }

    const billableQty = Math.min(reqItem.quantity, row.stock_quantity);
    const lineTotalPence = row.price_pence * billableQty;
    subtotalPence += lineTotalPence;

    items.push({
      productId: row.id,
      slug: row.slug,
      name: row.name,
      category: row.category,
      imageUrl: row.image_url,
      unitPricePence: row.price_pence,
      currency: row.currency,
      requestedQuantity: reqItem.quantity,
      availableQuantity: row.stock_quantity,
      isActive: true,
      lineTotalPence,
      hasIssue: itemHasIssue,
    });
  }

  const shippingPence = 0; // Explicit free UK shipping policy
  const totalPence = subtotalPence + shippingPence;

  return {
    items,
    materialChanges,
    hasMaterialChanges: materialChanges.length > 0,
    canCheckout,
    subtotalPence,
    shippingPence,
    totalPence,
    currency: 'GBP',
    shippingPolicySummary,
    taxPolicySummary,
  };
}

function validateCustomerInput(customer: CheckoutRequestPayload['customer']) {
  if (!customer || typeof customer !== 'object') {
    throw new StoreError(400, 'INVALID_CUSTOMER', 'Customer delivery details are required.');
  }

  const fieldErrors: Record<string, string> = {};
  const name = typeof customer.name === 'string' ? customer.name.trim() : '';
  const email = typeof customer.email === 'string' ? customer.email.trim() : '';
  const addressLine1 =
    typeof customer.addressLine1 === 'string' ? customer.addressLine1.trim() : '';
  const addressLine2 =
    typeof customer.addressLine2 === 'string' ? customer.addressLine2.trim() : '';
  const city = typeof customer.city === 'string' ? customer.city.trim() : '';
  const postcode = typeof customer.postcode === 'string' ? customer.postcode.trim() : '';
  const country =
    typeof customer.country === 'string' && customer.country.trim().length > 0
      ? customer.country.trim()
      : 'United Kingdom';

  if (name.length < 2 || name.length > 120) {
    fieldErrors.name = 'Please enter your full name (2–120 characters).';
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 160) {
    fieldErrors.email = 'Please enter a valid email address.';
  }
  if (addressLine1.length < 4 || addressLine1.length > 160) {
    fieldErrors.addressLine1 = 'Please enter a valid street address.';
  }
  if (addressLine2.length > 160) {
    fieldErrors.addressLine2 = 'Address line 2 must be 160 characters or fewer.';
  }
  if (city.length < 2 || city.length > 100) {
    fieldErrors.city = 'Please enter your town or city.';
  }
  if (postcode.length < 3 || postcode.length > 20) {
    fieldErrors.postcode = 'Please enter a valid postcode.';
  }
  if (country.length < 2 || country.length > 80) {
    fieldErrors.country = 'Please enter a valid country.';
  }

  if (Object.keys(fieldErrors).length > 0) {
    throw new StoreError(422, 'VALIDATION_ERROR', 'Please check the highlighted delivery details.', {
      fields: fieldErrors,
    });
  }

  return {
    name,
    email: email.toLowerCase(),
    addressLine1,
    addressLine2: addressLine2 || null,
    city,
    postcode: postcode.toUpperCase(),
    country,
  };
}

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function generateOrderReference(): string {
  const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randomPart = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `AUR-${datePart}-${randomPart}`;
}

function generateAccessToken(): string {
  return crypto.randomBytes(24).toString('base64url');
}

function computeRequestHash(
  customer: ReturnType<typeof validateCustomerInput>,
  items: CartValidationRequestItem[],
): string {
  const canonical = JSON.stringify({
    customer,
    items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
  });
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

interface OrderRow {
  id: number;
  reference: string;
  access_token_hash: string;
  customer_name: string;
  customer_email: string;
  delivery_address_line1: string;
  delivery_address_line2: string | null;
  delivery_city: string;
  delivery_postcode: string;
  delivery_country: string;
  subtotal_pence: number;
  shipping_pence: number;
  total_pence: number;
  currency: 'GBP';
  checkout_mode: 'demo' | 'hosted';
  payment_status: OrderDTO['paymentStatus'];
  order_status: OrderDTO['orderStatus'];
  fulfilment_status: OrderDTO['fulfilmentStatus'];
  shipping_policy_summary: string;
  tax_policy_summary: string;
  created_at: string;
}

interface OrderItemRow {
  id: number;
  order_id: number;
  product_id: number;
  product_slug: string;
  product_name: string;
  unit_price_pence: number;
  currency: 'GBP';
  quantity: number;
  line_total_pence: number;
}

function hydrateOrder(db: DatabaseSync, row: OrderRow): OrderDTO {
  const itemRows = db
    .prepare(
      `SELECT id, order_id, product_id, product_slug, product_name, unit_price_pence, currency, quantity, line_total_pence
       FROM order_items
       WHERE order_id = ?
       ORDER BY id ASC`,
    )
    .all(row.id) as unknown as OrderItemRow[];

  const items: OrderItemDTO[] = itemRows.map((item) => ({
    id: item.id,
    productId: item.product_id,
    productSlug: item.product_slug,
    productName: item.product_name,
    unitPricePence: item.unit_price_pence,
    currency: item.currency,
    quantity: item.quantity,
    lineTotalPence: item.line_total_pence,
  }));

  return {
    reference: row.reference,
    customerName: row.customer_name,
    customerEmail: row.customer_email,
    deliveryAddress: {
      line1: row.delivery_address_line1,
      line2: row.delivery_address_line2,
      city: row.delivery_city,
      postcode: row.delivery_postcode,
      country: row.delivery_country,
    },
    subtotalPence: row.subtotal_pence,
    shippingPence: row.shipping_pence,
    totalPence: row.total_pence,
    currency: row.currency,
    checkoutMode: row.checkout_mode,
    paymentStatus: row.payment_status,
    orderStatus: row.order_status,
    fulfilmentStatus: row.fulfilment_status,
    statusBanner: getOrderStatusBanner({
      checkoutMode: row.checkout_mode,
      paymentStatus: row.payment_status,
      orderStatus: row.order_status,
    }),
    shippingPolicySummary: row.shipping_policy_summary,
    taxPolicySummary: row.tax_policy_summary,
    createdAt: row.created_at,
    items,
  };
}

export async function createCheckoutOrder(
  db: DatabaseSync,
  payload: CheckoutRequestPayload,
  returnBaseUrl = 'http://localhost:3000',
): Promise<CheckoutSuccessResponse> {
  const idempotencyKey =
    typeof payload.idempotencyKey === 'string' ? payload.idempotencyKey.trim() : '';
  if (!/^[a-zA-Z0-9_-]{8,120}$/.test(idempotencyKey)) {
    throw new StoreError(
      400,
      'INVALID_IDEMPOTENCY_KEY',
      'A valid checkout idempotency key is required.',
    );
  }

  const customer = validateCustomerInput(payload.customer);
  const items = normalizeRequestedItems(payload.items);
  const requestHash = computeRequestHash(customer, items);
  const { shippingPolicySummary, taxPolicySummary } = getStorePolicies();
  const paymentProvider = getPaymentProvider();

  // First check idempotency before acquiring write lock for fast replay
  const existingReq = db
    .prepare(
      `SELECT id, request_hash, status, order_id, response_access_token
       FROM checkout_requests
       WHERE idempotency_key = ?`,
    )
    .get(idempotencyKey) as
    | {
        id: number;
        request_hash: string;
        status: string;
        order_id: number | null;
        response_access_token: string | null;
      }
    | undefined;

  if (existingReq) {
    if (existingReq.request_hash !== requestHash) {
      throw new StoreError(
        409,
        'IDEMPOTENCY_KEY_CONFLICT',
        'This checkout session key was already used for a different cart or delivery address.',
      );
    }
    if (existingReq.status === 'completed' && existingReq.order_id && existingReq.response_access_token) {
      const orderRow = db
        .prepare('SELECT * FROM orders WHERE id = ?')
        .get(existingReq.order_id) as unknown as OrderRow | undefined;
      if (orderRow) {
        return {
          order: hydrateOrder(db, orderRow),
          accessToken: existingReq.response_access_token,
          replayed: true,
        };
      }
    }
  }

  const orderReference = generateOrderReference();
  const accessToken = generateAccessToken();
  const accessTokenHash = hashToken(accessToken);

  // Compute payment session metadata before opening SQLite write transaction
  // (Demo provider resolves synchronously in memory; hosted providers would reserve stock first
  // and create the external session outside the DB lock in production).
  let subtotalPence = 0;
  const lineSnapshots: Array<{
    productId: number;
    productSlug: string;
    productName: string;
    unitPricePence: number;
    quantity: number;
    lineTotalPence: number;
  }> = [];

  db.exec('BEGIN IMMEDIATE');
  try {
    // Re-check inside exclusive write lock to eliminate TOCTOU race conditions
    const lockedExisting = db
      .prepare(
        `SELECT id, request_hash, status, order_id, response_access_token
         FROM checkout_requests
         WHERE idempotency_key = ?`,
      )
      .get(idempotencyKey) as
      | {
          id: number;
          request_hash: string;
          status: string;
          order_id: number | null;
          response_access_token: string | null;
        }
      | undefined;

    if (lockedExisting) {
      if (lockedExisting.request_hash !== requestHash) {
        throw new StoreError(
          409,
          'IDEMPOTENCY_KEY_CONFLICT',
          'This checkout session key was already used for a different cart or delivery address.',
        );
      }
      if (
        lockedExisting.status === 'completed' &&
        lockedExisting.order_id &&
        lockedExisting.response_access_token
      ) {
        const orderRow = db
          .prepare('SELECT * FROM orders WHERE id = ?')
          .get(lockedExisting.order_id) as unknown as OrderRow;
        db.exec('COMMIT');
        return {
          order: hydrateOrder(db, orderRow),
          accessToken: lockedExisting.response_access_token,
          replayed: true,
        };
      }
      if (lockedExisting.status === 'processing') {
        throw new StoreError(
          409,
          'CHECKOUT_IN_PROGRESS',
          'This checkout request is already being processed.',
        );
      }
    }

    const selectProduct = db.prepare(
      `SELECT id, slug, name, price_pence, currency, stock_quantity, is_active
       FROM products
       WHERE id = ?`,
    );
    const deductStock = db.prepare(
      `UPDATE products
       SET stock_quantity = stock_quantity - ?,
           updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
       WHERE id = ? AND is_active = 1 AND stock_quantity >= ?`,
    );

    const materialChanges: CartMaterialChange[] = [];

    for (const reqItem of items) {
      const product = selectProduct.get(reqItem.productId) as
        | {
            id: number;
            slug: string;
            name: string;
            price_pence: number;
            currency: 'GBP';
            stock_quantity: number;
            is_active: number;
          }
        | undefined;

      if (!product || product.is_active !== 1) {
        materialChanges.push({
          productId: reqItem.productId,
          productName: product?.name ?? `Product #${reqItem.productId}`,
          slug: product?.slug ?? '',
          reason: 'discontinued',
          message: `${product?.name ?? 'An item in your bag'} is no longer available.`,
          requestedQuantity: reqItem.quantity,
          availableQuantity: 0,
        });
        continue;
      }

      if (
        reqItem.expectedUnitPricePence !== undefined &&
        reqItem.expectedUnitPricePence !== product.price_pence
      ) {
        materialChanges.push({
          productId: product.id,
          productName: product.name,
          slug: product.slug,
          reason: 'price_changed',
          message: `The price of ${product.name} changed to £${(product.price_pence / 100).toFixed(2)}.`,
          previousPricePence: reqItem.expectedUnitPricePence,
          currentPricePence: product.price_pence,
          requestedQuantity: reqItem.quantity,
          availableQuantity: product.stock_quantity,
        });
      }

      if (product.stock_quantity === 0) {
        materialChanges.push({
          productId: product.id,
          productName: product.name,
          slug: product.slug,
          reason: 'out_of_stock',
          message: `${product.name} is out of stock.`,
          requestedQuantity: reqItem.quantity,
          availableQuantity: 0,
        });
        continue;
      }

      if (reqItem.quantity > product.stock_quantity) {
        materialChanges.push({
          productId: product.id,
          productName: product.name,
          slug: product.slug,
          reason: 'insufficient_stock',
          message: `Only ${product.stock_quantity} unit${product.stock_quantity === 1 ? '' : 's'} of ${product.name} available.`,
          requestedQuantity: reqItem.quantity,
          availableQuantity: product.stock_quantity,
        });
        continue;
      }

      // Atomic conditional stock deduction
      const updateResult = deductStock.run(reqItem.quantity, product.id, reqItem.quantity);
      if (updateResult.changes !== 1) {
        materialChanges.push({
          productId: product.id,
          productName: product.name,
          slug: product.slug,
          reason: 'insufficient_stock',
          message: `Insufficient remaining stock for ${product.name}.`,
          requestedQuantity: reqItem.quantity,
          availableQuantity: product.stock_quantity,
        });
        continue;
      }

      const lineTotalPence = product.price_pence * reqItem.quantity;
      subtotalPence += lineTotalPence;
      lineSnapshots.push({
        productId: product.id,
        productSlug: product.slug,
        productName: product.name,
        unitPricePence: product.price_pence,
        quantity: reqItem.quantity,
        lineTotalPence,
      });
    }

    if (materialChanges.length > 0) {
      throw new StoreError(
        409,
        'MATERIAL_CHANGE',
        'Your bag changed since you loaded checkout. Please review the updated prices or availability.',
        { materialChanges },
      );
    }

    const shippingPence = 0;
    const totalPence = subtotalPence + shippingPence;

    if (
      payload.acknowledgedTotalPence !== undefined &&
      payload.acknowledgedTotalPence !== totalPence
    ) {
      throw new StoreError(
        409,
        'TOTAL_MISMATCH',
        'Order total changed on the server. Please review the updated summary before confirming.',
        {
          expectedTotalPence: payload.acknowledgedTotalPence,
          recalculatedTotalPence: totalPence,
        },
      );
    }

    const paymentSession = await paymentProvider.createPaymentIntentOrSession({
      orderReference,
      totalPence,
      currency: 'GBP',
      customerEmail: customer.email,
      returnBaseUrl,
      accessToken,
    });

    const insertOrder = db.prepare(`
      INSERT INTO orders (
        reference,
        access_token_hash,
        customer_name,
        customer_email,
        delivery_address_line1,
        delivery_address_line2,
        delivery_city,
        delivery_postcode,
        delivery_country,
        subtotal_pence,
        shipping_pence,
        total_pence,
        currency,
        checkout_mode,
        payment_status,
        order_status,
        fulfilment_status,
        shipping_policy_summary,
        tax_policy_summary
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'GBP', ?, ?, ?, ?, ?, ?)
    `);

    const orderResult = insertOrder.run(
      orderReference,
      accessTokenHash,
      customer.name,
      customer.email,
      customer.addressLine1,
      customer.addressLine2,
      customer.city,
      customer.postcode,
      customer.country,
      subtotalPence,
      shippingPence,
      totalPence,
      paymentSession.checkoutMode,
      paymentSession.paymentStatus,
      paymentSession.orderStatus,
      paymentSession.fulfilmentStatus,
      shippingPolicySummary,
      taxPolicySummary,
    );

    const orderId = Number(orderResult.lastInsertRowid);

    const insertItem = db.prepare(`
      INSERT INTO order_items (
        order_id,
        product_id,
        product_slug,
        product_name,
        unit_price_pence,
        currency,
        quantity,
        line_total_pence
      ) VALUES (?, ?, ?, ?, ?, 'GBP', ?, ?)
    `);

    for (const snap of lineSnapshots) {
      insertItem.run(
        orderId,
        snap.productId,
        snap.productSlug,
        snap.productName,
        snap.unitPricePence,
        snap.quantity,
        snap.lineTotalPence,
      );
    }

    db.prepare(`
      INSERT INTO checkout_requests (
        idempotency_key,
        request_hash,
        status,
        order_id,
        order_reference,
        response_access_token
      ) VALUES (?, ?, 'completed', ?, ?, ?)
      ON CONFLICT(idempotency_key) DO UPDATE SET
        status = 'completed',
        order_id = excluded.order_id,
        order_reference = excluded.order_reference,
        response_access_token = excluded.response_access_token,
        updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
    `).run(idempotencyKey, requestHash, orderId, orderReference, accessToken);

    const createdOrderRow = db
      .prepare('SELECT * FROM orders WHERE id = ?')
      .get(orderId) as unknown as OrderRow;

    db.exec('COMMIT');

    return {
      order: hydrateOrder(db, createdOrderRow),
      accessToken,
      replayed: false,
      redirectUrl: paymentSession.redirectUrl,
    };
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

export function getOrderByReferenceAndToken(
  db: DatabaseSync,
  reference: string,
  accessToken: string | null | undefined,
): OrderDTO {
  const cleanRef = reference.trim().toUpperCase();
  if (!/^AUR-\d{8}-[A-F0-9]{6}$/.test(cleanRef)) {
    throw new StoreError(400, 'INVALID_ORDER_REFERENCE', 'Invalid order reference format.');
  }

  if (!accessToken || typeof accessToken !== 'string' || accessToken.trim().length < 16) {
    throw new StoreError(
      401,
      'ORDER_ACCESS_DENIED',
      'A valid order access token is required to view this order.',
    );
  }

  const row = db
    .prepare('SELECT * FROM orders WHERE reference = ?')
    .get(cleanRef) as unknown as OrderRow | undefined;

  if (!row) {
    // Return 404/403 consistently without leaking customer existence
    throw new StoreError(404, 'ORDER_NOT_FOUND', 'Order could not be found or token is invalid.');
  }

  const providedHash = Buffer.from(hashToken(accessToken.trim()), 'hex');
  const storedHash = Buffer.from(row.access_token_hash, 'hex');

  if (
    providedHash.length !== storedHash.length ||
    !crypto.timingSafeEqual(providedHash, storedHash)
  ) {
    throw new StoreError(403, 'ORDER_ACCESS_DENIED', 'Order could not be found or token is invalid.');
  }

  return hydrateOrder(db, row);
}

export function checkHealth(db: DatabaseSync): {
  status: 'ok';
  database: 'connected';
  paymentMode: 'demo' | 'hosted';
  productCount: number;
} {
  const row = db
    .prepare('SELECT COUNT(*) AS count FROM products WHERE is_active = 1')
    .get() as { count: number };
  const paymentProvider = getPaymentProvider();
  return {
    status: 'ok',
    database: 'connected',
    paymentMode: paymentProvider.mode,
    productCount: row.count,
  };
}
