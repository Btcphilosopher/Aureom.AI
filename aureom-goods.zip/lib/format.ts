export function formatGbp(pence: number): string {
  const pounds = pence / 100;
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(pounds);
}

export function formatCategoryLabel(category: string): string {
  switch (category) {
    case 'homeware':
      return 'Homeware';
    case 'stationery':
      return 'Stationery';
    case 'accessories':
      return 'Accessories';
    default:
      return category;
  }
}

export function formatOrderStatusLabel(status: string): string {
  switch (status) {
    case 'confirmed_demo':
      return 'Confirmed (Demo Order)';
    case 'awaiting_payment':
      return 'Awaiting Payment';
    case 'confirmed':
      return 'Confirmed';
    case 'cancelled':
      return 'Cancelled';
    default:
      return status;
  }
}

export function formatPaymentStatusLabel(status: string): string {
  switch (status) {
    case 'no_payment_taken':
      return 'No Payment Taken (Demo)';
    case 'pending':
      return 'Pending Payment';
    case 'paid':
      return 'Paid';
    case 'failed':
      return 'Failed';
    case 'cancelled':
      return 'Cancelled';
    case 'expired':
      return 'Expired';
    default:
      return status;
  }
}

export function formatFulfilmentStatusLabel(status: string): string {
  switch (status) {
    case 'unfulfilled':
      return 'Not Dispatched (Demo)';
    case 'processing':
      return 'Preparing Order';
    case 'dispatched':
      return 'Dispatched';
    default:
      return status;
  }
}
