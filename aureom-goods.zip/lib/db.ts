import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

export interface SeedProduct {
  slug: string;
  name: string;
  description: string;
  category: 'homeware' | 'stationery' | 'accessories';
  imageUrl: string;
  pricePence: number;
  currency: 'GBP';
  stockQuantity: number;
  featured: boolean;
}

export const INITIAL_PRODUCTS: SeedProduct[] = [
  {
    slug: 'everyday-tote',
    name: 'Everyday Tote',
    description:
      'Constructed from 18oz organic unbleached cotton canvas with deep forest-green herringbone webbing straps, solid brass rivets, and a reinforced gusset base sized for laptops and market errands.',
    category: 'accessories',
    imageUrl: '/images/everyday-tote.jpg',
    pricePence: 3400,
    currency: 'GBP',
    stockQuantity: 18,
    featured: true,
  },
  {
    slug: 'studio-mug',
    name: 'Studio Mug',
    description:
      'Wheel-thrown in small batches from speckled stoneware clay and finished in a satin oatmeal glaze with a hand-dipped sage rim. Holds 320ml and retains warmth comfortably in hand.',
    category: 'homeware',
    imageUrl: '/images/studio-mug.jpg',
    pricePence: 2200,
    currency: 'GBP',
    stockQuantity: 24,
    featured: true,
  },
  {
    slug: 'field-notebook',
    name: 'Field Notebook',
    description:
      'Smyth-sewn A5 notebook bound in bookcloth with 192 pages of fountain-pen-friendly 115gsm cream archival paper. Opens completely flat on any work surface.',
    category: 'stationery',
    imageUrl: '/images/field-notebook.jpg',
    pricePence: 1600,
    currency: 'GBP',
    stockQuantity: 40,
    featured: true,
  },
  {
    slug: 'desk-lamp',
    name: 'Desk Lamp',
    description:
      'Architectural task lamp pairing a spun-aluminium forest-green shade with a brushed brass articulated stem and honed travertine base. Includes braided textile cord and inline brass switch.',
    category: 'homeware',
    imageUrl: '/images/desk-lamp.jpg',
    pricePence: 14500,
    currency: 'GBP',
    stockQuantity: 7,
    featured: true,
  },
  {
    slug: 'travel-bottle',
    name: 'Travel Bottle',
    description:
      'Double-walled vacuum-insulated 500ml flask in powder-coated sage steel with a machined stainless steel neck and natural Portuguese cork collar. Keeps water chilled for 24 hours.',
    category: 'accessories',
    imageUrl: '/images/travel-bottle.jpg',
    pricePence: 2800,
    currency: 'GBP',
    stockQuantity: 15,
    featured: false,
  },
  {
    slug: 'weekly-planner',
    name: 'Weekly Planner',
    description:
      'Undated 52-week linen-bound desk planner featuring a structured Monday-to-Sunday spread alongside a fine 5mm dot-grid sheet for studio notes and priorities.',
    category: 'stationery',
    imageUrl: '/images/weekly-planner.jpg',
    pricePence: 1900,
    currency: 'GBP',
    stockQuantity: 32,
    featured: false,
  },
  {
    slug: 'cotton-tea-towel',
    name: 'Cotton Tea Towel',
    description:
      'Generously sized set of two kitchen cloths loomed from long-staple organic cotton—one tactile sage waffle weave and one natural flax herringbone—fitted with stitched hanging loops.',
    category: 'homeware',
    imageUrl: '/images/cotton-tea-towel.jpg',
    pricePence: 1800,
    currency: 'GBP',
    stockQuantity: 28,
    featured: false,
  },
  {
    slug: 'desk-organiser',
    name: 'Desk Organiser',
    description:
      'Modular desktop tray milled from solid European ash wood with removable muted-sage powder-coated steel compartments for notebooks, pens, clips, and small studio tools.',
    category: 'stationery',
    imageUrl: '/images/desk-organiser.jpg',
    pricePence: 5400,
    currency: 'GBP',
    stockQuantity: 9,
    featured: false,
  },
];

const MIGRATIONS: Array<{ version: string; sql: string }> = [
  {
    version: '001_initial_schema',
    sql: `
      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slug TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL CHECK (category IN ('homeware', 'stationery', 'accessories')),
        image_url TEXT NOT NULL,
        price_pence INTEGER NOT NULL CHECK (price_pence >= 0),
        currency TEXT NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
        stock_quantity INTEGER NOT NULL CHECK (stock_quantity >= 0),
        is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
        featured INTEGER NOT NULL DEFAULT 0 CHECK (featured IN (0, 1)),
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
      );

      CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
      CREATE INDEX IF NOT EXISTS idx_products_active_featured ON products(is_active, featured);

      CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reference TEXT NOT NULL UNIQUE,
        access_token_hash TEXT NOT NULL,
        customer_name TEXT NOT NULL,
        customer_email TEXT NOT NULL,
        delivery_address_line1 TEXT NOT NULL,
        delivery_address_line2 TEXT,
        delivery_city TEXT NOT NULL,
        delivery_postcode TEXT NOT NULL,
        delivery_country TEXT NOT NULL,
        subtotal_pence INTEGER NOT NULL CHECK (subtotal_pence >= 0),
        shipping_pence INTEGER NOT NULL DEFAULT 0 CHECK (shipping_pence >= 0),
        total_pence INTEGER NOT NULL CHECK (total_pence >= 0),
        currency TEXT NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
        checkout_mode TEXT NOT NULL CHECK (checkout_mode IN ('demo', 'hosted')),
        payment_status TEXT NOT NULL CHECK (payment_status IN ('no_payment_taken', 'pending', 'paid', 'failed', 'cancelled', 'expired')),
        order_status TEXT NOT NULL CHECK (order_status IN ('confirmed_demo', 'awaiting_payment', 'confirmed', 'cancelled')),
        fulfilment_status TEXT NOT NULL CHECK (fulfilment_status IN ('unfulfilled', 'processing', 'dispatched')),
        shipping_policy_summary TEXT NOT NULL,
        tax_policy_summary TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
      );

      CREATE INDEX IF NOT EXISTS idx_orders_reference ON orders(reference);

      CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(id),
        product_slug TEXT NOT NULL,
        product_name TEXT NOT NULL,
        unit_price_pence INTEGER NOT NULL CHECK (unit_price_pence >= 0),
        currency TEXT NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        line_total_pence INTEGER NOT NULL CHECK (line_total_pence >= 0)
      );

      CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

      CREATE TABLE IF NOT EXISTS checkout_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        idempotency_key TEXT NOT NULL UNIQUE,
        request_hash TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('processing', 'completed', 'failed')),
        order_id INTEGER REFERENCES orders(id),
        order_reference TEXT,
        response_access_token TEXT,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
      );

      CREATE INDEX IF NOT EXISTS idx_checkout_requests_key ON checkout_requests(idempotency_key);

      CREATE TABLE IF NOT EXISTS payment_webhook_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        provider TEXT NOT NULL,
        event_id TEXT NOT NULL UNIQUE,
        event_type TEXT NOT NULL,
        processed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
      );
    `,
  },
];

export function runMigrations(db: DatabaseSync): void {
  db.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA journal_mode = WAL;
    PRAGMA busy_timeout = 5000;
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );
  `);

  const checkStmt = db.prepare('SELECT 1 FROM schema_migrations WHERE version = ?');
  const insertStmt = db.prepare('INSERT INTO schema_migrations (version) VALUES (?)');

  for (const migration of MIGRATIONS) {
    const existing = checkStmt.get(migration.version);
    if (!existing) {
      db.exec('BEGIN IMMEDIATE');
      try {
        db.exec(migration.sql);
        insertStmt.run(migration.version);
        db.exec('COMMIT');
      } catch (err) {
        db.exec('ROLLBACK');
        throw err;
      }
    }
  }
}

export function seedProducts(db: DatabaseSync): void {
  const existingCountRow = db
    .prepare('SELECT COUNT(*) AS count FROM products')
    .get() as { count: number };

  if (existingCountRow.count > 0) {
    // Ensure safe idempotency: only insert missing slugs without overwriting live stock or test edits
    const checkSlug = db.prepare('SELECT id FROM products WHERE slug = ?');
    const insert = db.prepare(`
      INSERT INTO products (slug, name, description, category, image_url, price_pence, currency, stock_quantity, is_active, featured)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);
    for (const p of INITIAL_PRODUCTS) {
      if (!checkSlug.get(p.slug)) {
        insert.run(
          p.slug,
          p.name,
          p.description,
          p.category,
          p.imageUrl,
          p.pricePence,
          p.currency,
          p.stockQuantity,
          p.featured ? 1 : 0,
        );
      }
    }
    return;
  }

  const insert = db.prepare(`
    INSERT INTO products (slug, name, description, category, image_url, price_pence, currency, stock_quantity, is_active, featured)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
  `);

  db.exec('BEGIN IMMEDIATE');
  try {
    for (const p of INITIAL_PRODUCTS) {
      insert.run(
        p.slug,
        p.name,
        p.description,
        p.category,
        p.imageUrl,
        p.pricePence,
        p.currency,
        p.stockQuantity,
        p.featured ? 1 : 0,
      );
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

const globalForDb = globalThis as unknown as {
  __aureomDb?: DatabaseSync;
  __aureomDbPath?: string;
};

export function getDb(customPath?: string): DatabaseSync {
  const resolvedPath =
    customPath ??
    process.env.AUREOM_DB_PATH ??
    path.join(process.cwd(), 'data', 'aureom.db');

  if (
    !customPath &&
    globalForDb.__aureomDb &&
    globalForDb.__aureomDbPath === resolvedPath
  ) {
    return globalForDb.__aureomDb;
  }

  if (resolvedPath !== ':memory:') {
    const dir = path.dirname(resolvedPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new DatabaseSync(resolvedPath);
  runMigrations(db);
  seedProducts(db);

  if (!customPath) {
    globalForDb.__aureomDb = db;
    globalForDb.__aureomDbPath = resolvedPath;
  }

  return db;
}
