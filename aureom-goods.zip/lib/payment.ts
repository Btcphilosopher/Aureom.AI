import crypto from 'node:crypto';
import type { OrderDTO, OrderStatus, PaymentStatus, FulfilmentStatus } from './types';

export interface PaymentSessionResult {
  checkoutMode: 'demo' | 'hosted';
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  fulfilmentStatus: FulfilmentStatus;
  statusBanner: string;
  redirectUrl?: string;
}

export interface PaymentProvider {
  readonly mode: 'demo' | 'hosted';
  createPaymentIntentOrSession(params: {
    orderReference: string;
    totalPence: number;
    currency: 'GBP';
    customerEmail: string;
    returnBaseUrl: string;
    accessToken: string;
  }): Promise<PaymentSessionResult>;
  verifyWebhookSignature(payload: string, signatureHeader: string | null): boolean;
}

export class DemoPaymentProvider implements PaymentProvider {
  readonly mode = 'demo' as const;

  async createPaymentIntentOrSession(params: {
    orderReference: string;
    totalPence: number;
    currency: 'GBP';
    customerEmail: string;
    returnBaseUrl: string;
    accessToken: string;
  }): Promise<PaymentSessionResult> {
    void params;
    return {
      checkoutMode: 'demo',
      paymentStatus: 'no_payment_taken',
      orderStatus: 'confirmed_demo',
      fulfilmentStatus: 'unfulfilled',
      statusBanner: 'Demo order saved — no payment taken.',
    };
  }

  verifyWebhookSignature(): boolean {
    return false;
  }
}

/**
 * Hosted checkout payment-provider adapter for a future Stripe/hosted integration.
 * - Secret keys are read strictly on the server via process.env.PAYMENT_PROVIDER_SECRET_KEY.
 * - Amounts are always derived from server-calculated order totals in minor units (pence).
 * - Orders are never marked paid from browser redirect alone; only verified webhooks transition state.
 */
export class HostedPaymentProvider implements PaymentProvider {
  readonly mode = 'hosted' as const;
  private readonly secretKey: string;
  private readonly webhookSecret: string;

  constructor(secretKey: string, webhookSecret: string) {
    this.secretKey = secretKey;
    this.webhookSecret = webhookSecret;
  }

  async createPaymentIntentOrSession(params: {
    orderReference: string;
    totalPence: number;
    currency: 'GBP';
    customerEmail: string;
    returnBaseUrl: string;
    accessToken: string;
  }): Promise<PaymentSessionResult> {
    if (!this.secretKey) {
      throw new Error('Hosted payment provider credentials are not configured.');
    }
    // In a live Stripe integration, call Stripe Checkout Sessions API using this.secretKey,
    // passing params.totalPence (never client amounts) and metadata.order_reference.
    const successUrl = `${params.returnBaseUrl}/orders/${encodeURIComponent(
      params.orderReference,
    )}?token=${encodeURIComponent(params.accessToken)}`;

    return {
      checkoutMode: 'hosted',
      paymentStatus: 'pending',
      orderStatus: 'awaiting_payment',
      fulfilmentStatus: 'unfulfilled',
      statusBanner: 'Order reserved — awaiting hosted payment confirmation.',
      redirectUrl: successUrl,
    };
  }

  verifyWebhookSignature(payload: string, signatureHeader: string | null): boolean {
    if (!this.webhookSecret || !signatureHeader) return false;
    const expected = crypto
      .createHmac('sha256', this.webhookSecret)
      .update(payload)
      .digest('hex');
    const providedBuffer = Buffer.from(signatureHeader);
    const expectedBuffer = Buffer.from(expected);
    if (providedBuffer.length !== expectedBuffer.length) return false;
    return crypto.timingSafeEqual(providedBuffer, expectedBuffer);
  }
}

export function getPaymentProvider(): PaymentProvider {
  const configuredMode = process.env.AUREOM_PAYMENT_MODE ?? 'demo';
  const secretKey = process.env.PAYMENT_PROVIDER_SECRET_KEY ?? '';
  const webhookSecret = process.env.PAYMENT_WEBHOOK_SECRET ?? '';

  if (configuredMode === 'hosted' && secretKey && webhookSecret) {
    return new HostedPaymentProvider(secretKey, webhookSecret);
  }
  return new DemoPaymentProvider();
}

export function getOrderStatusBanner(order: Pick<OrderDTO, 'checkoutMode' | 'paymentStatus' | 'orderStatus'>): string {
  if (order.checkoutMode === 'demo' || order.paymentStatus === 'no_payment_taken') {
    return 'Demo order saved — no payment taken.';
  }
  if (order.paymentStatus === 'paid' && order.orderStatus === 'confirmed') {
    return 'Payment confirmed — preparing order.';
  }
  if (order.paymentStatus === 'pending') {
    return 'Awaiting payment confirmation.';
  }
  if (order.paymentStatus === 'cancelled' || order.orderStatus === 'cancelled') {
    return 'Order cancelled — stock released.';
  }
  if (order.paymentStatus === 'expired') {
    return 'Checkout session expired — stock released.';
  }
  return 'Payment unsuccessful.';
}
