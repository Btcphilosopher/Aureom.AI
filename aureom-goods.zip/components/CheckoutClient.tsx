'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AlertCircle, AlertTriangle, ArrowLeft, Lock, ShieldCheck } from 'lucide-react';
import { useCart } from './CartProvider';
import { formatGbp } from '@/lib/format';
import type { CartValidationResponse, CheckoutSuccessResponse } from '@/lib/types';

interface FormValues {
  name: string;
  email: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  postcode: string;
  country: string;
}

export function CheckoutClient() {
  const router = useRouter();
  const {
    items,
    isHydrated,
    clearCart,
    syncServerSnapshot,
    getCheckoutIdempotencyKey,
    rotateCheckoutIdempotencyKey,
    saveOrderAccessToken,
  } = useCart();

  const [values, setValues] = useState<FormValues>({
    name: '',
    email: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    postcode: '',
    country: 'United Kingdom',
  });

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [validation, setValidation] = useState<CartValidationResponse | null>(null);
  const [isCheckingCart, setIsCheckingCart] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [changesReviewed, setChangesReviewed] = useState(false);

  const loadServerSummary = useCallback(async () => {
    if (!isHydrated || items.length === 0) return;
    setIsCheckingCart(true);
    try {
      const res = await fetch('/api/cart/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: items.map((i) => ({
            productId: i.productId,
            quantity: i.quantity,
            expectedUnitPricePence: i.unitPricePence,
          })),
        }),
      });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error?.message ?? 'Could not verify order summary.');
      }
      setValidation(body as CartValidationResponse);
    } catch (err) {
      setSubmitError(
        err instanceof Error ? err.message : 'Unable to calculate order total on server.',
      );
    } finally {
      setIsCheckingCart(false);
    }
  }, [items, isHydrated]);

  useEffect(() => {
    if (!isHydrated || items.length === 0) return;
    let active = true;
    fetch('/api/cart/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
          expectedUnitPricePence: i.unitPricePence,
        })),
      }),
    })
      .then(async (res) => {
        const body = await res.json();
        if (!res.ok) {
          throw new Error(body?.error?.message ?? 'Could not verify order summary.');
        }
        return body as CartValidationResponse;
      })
      .then((data) => {
        if (active) {
          setValidation(data);
          setIsCheckingCart(false);
        }
      })
      .catch((err) => {
        if (active) {
          setSubmitError(
            err instanceof Error ? err.message : 'Unable to calculate order total on server.',
          );
          setIsCheckingCart(false);
        }
      });

    return () => {
      active = false;
    };
  }, [items, isHydrated]);

  const validateFormClient = (): boolean => {
    const errors: Record<string, string> = {};
    if (values.name.trim().length < 2) errors.name = 'Please enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email.trim())) {
      errors.email = 'Please enter a valid email address.';
    }
    if (values.addressLine1.trim().length < 4) {
      errors.addressLine1 = 'Please enter your street address.';
    }
    if (values.city.trim().length < 2) errors.city = 'Please enter your town or city.';
    if (values.postcode.trim().length < 3) errors.postcode = 'Please enter your postcode.';
    if (values.country.trim().length < 2) errors.country = 'Please enter your country.';

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFieldChange = (field: keyof FormValues, val: string) => {
    setValues((prev) => ({ ...prev, [field]: val }));
    if (fieldErrors[field]) {
      setFieldErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const handleAcceptUpdatedSummary = () => {
    if (!validation) return;
    syncServerSnapshot(
      validation.items
        .filter((i) => i.isActive)
        .map((i) => ({
          productId: i.productId,
          name: i.name,
          slug: i.slug,
          unitPricePence: i.unitPricePence,
          quantity:
            i.availableQuantity > 0
              ? Math.min(i.requestedQuantity, i.availableQuantity)
              : i.requestedQuantity,
        })),
    );
    setChangesReviewed(true);
    setSubmitError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!validateFormClient()) return;
    if (!validation || !validation.canCheckout) {
      setSubmitError('Please resolve item availability in your bag before placing your order.');
      return;
    }

    if (validation.hasMaterialChanges && !changesReviewed) {
      setSubmitError('Please review and accept the updated catalogue prices before confirming.');
      return;
    }

    setIsSubmitting(true);
    const idempotencyKey = getCheckoutIdempotencyKey();

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': idempotencyKey,
        },
        body: JSON.stringify({
          idempotencyKey,
          customer: {
            name: values.name.trim(),
            email: values.email.trim(),
            addressLine1: values.addressLine1.trim(),
            addressLine2: values.addressLine2.trim(),
            city: values.city.trim(),
            postcode: values.postcode.trim(),
            country: values.country.trim(),
          },
          items: validation.items.map((i) => ({
            productId: i.productId,
            quantity: i.requestedQuantity,
            expectedUnitPricePence: i.unitPricePence,
          })),
          acknowledgedTotalPence: validation.totalPence,
        }),
      });

      const body = await res.json();

      if (!res.ok) {
        if (body?.error?.details?.fields) {
          setFieldErrors(body.error.details.fields);
        }
        if (body?.error?.code === 'MATERIAL_CHANGE' || body?.error?.code === 'TOTAL_MISMATCH') {
          await loadServerSummary();
          setChangesReviewed(false);
        }
        if (body?.error?.code === 'IDEMPOTENCY_KEY_CONFLICT') {
          rotateCheckoutIdempotencyKey();
        }
        setSubmitError(body?.error?.message ?? 'Unable to complete checkout. Please try again.');
        return;
      }

      const success = body as CheckoutSuccessResponse;
      saveOrderAccessToken(success.order.reference, success.accessToken);
      clearCart();
      rotateCheckoutIdempotencyKey();

      router.push(
        `/orders/${encodeURIComponent(success.order.reference)}?token=${encodeURIComponent(
          success.accessToken,
        )}`,
      );
    } catch {
      setSubmitError(
        'Network error while submitting your order. You can safely retry — your checkout key prevents duplicate orders.',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isHydrated) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="h-9 w-48 bg-[#E5DFD3]/60 rounded animate-pulse" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-20 text-center">
        <h1 className="font-display text-3xl text-[#1E3A2B]">Your bag is empty</h1>
        <p className="mt-3 text-sm text-[#556358]">
          Add items to your shopping bag before proceeding to checkout.
        </p>
        <Link
          href="/shop"
          className="mt-6 min-h-[44px] px-6 py-2.5 inline-flex items-center rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm font-medium"
        >
          Browse collection
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <nav aria-label="Breadcrumb" className="mb-6">
        <Link
          href="/cart"
          className="inline-flex items-center gap-2 text-sm font-medium text-[#556358] hover:text-[#1E3A2B]"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Return to bag</span>
        </Link>
      </nav>

      <div className="pb-6 border-b border-[#E5DFD3]">
        <h1 className="font-display text-3xl sm:text-4xl font-normal text-[#1E3A2B]">
          Checkout
        </h1>
        <p className="mt-2 text-sm text-[#556358]">
          Enter your delivery details to place a demonstration order.
        </p>
      </div>

      {/* Explicit Demo Mode Notice */}
      <div className="mt-6 p-4 rounded-lg border border-[#C8D4C9] bg-[#E7ECE7]/70 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-[#1E3A2B] shrink-0 mt-0.5" aria-hidden="true" />
        <div className="text-sm text-[#1E3A2B]">
          <p className="font-semibold">Demonstration checkout — no payment taken</p>
          <p className="mt-0.5 text-[#243028]">
            This storefront is running in demo mode. No card details are requested and no charge will be made. Submitting saves a real order to the database and deducts stock atomically.
          </p>
        </div>
      </div>

      {/* Material Change Notice */}
      {validation?.hasMaterialChanges && !changesReviewed && (
        <div
          role="alert"
          className="mt-6 p-5 rounded-lg border border-[#D4B483] bg-[#FBF6EC] flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-[#8A5A19] shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <p className="text-sm font-semibold text-[#5C3B0E]">
                Order details updated from catalogue
              </p>
              <ul className="mt-1 space-y-1 text-sm text-[#5C3B0E]">
                {validation.materialChanges.map((c, i) => (
                  <li key={`${c.productId}-${i}`}>{c.message}</li>
                ))}
              </ul>
            </div>
          </div>
          {validation.canCheckout ? (
            <button
              type="button"
              onClick={handleAcceptUpdatedSummary}
              className="min-h-[40px] px-4 py-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-xs font-medium whitespace-nowrap shrink-0"
            >
              Confirm updated total
            </button>
          ) : (
            <Link
              href="/cart"
              className="min-h-[40px] px-4 py-2 inline-flex items-center rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-xs font-medium whitespace-nowrap shrink-0"
            >
              Edit bag
            </Link>
          )}
        </div>
      )}

      {submitError && (
        <div
          role="alert"
          className="mt-6 p-4 rounded-lg border border-[#D8B4B4] bg-[#FDF6F6] flex items-start gap-3 text-sm text-[#8B3A3A]"
        >
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" aria-hidden="true" />
          <p>{submitError}</p>
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
        <form onSubmit={handleSubmit} noValidate className="lg:col-span-7 space-y-6">
          <fieldset className="space-y-5">
            <legend className="font-display text-xl font-normal text-[#1E3A2B] pb-2 border-b border-[#E5DFD3] w-full">
              Contact &amp; Delivery Address
            </legend>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="checkout-name" className="block text-sm font-medium text-[#1E3A2B]">
                  Full name
                </label>
                <input
                  id="checkout-name"
                  name="name"
                  type="text"
                  autoComplete="name"
                  required
                  value={values.name}
                  onChange={(e) => handleFieldChange('name', e.target.value)}
                  aria-invalid={Boolean(fieldErrors.name)}
                  aria-describedby={fieldErrors.name ? 'error-name' : undefined}
                  className="mt-1.5 w-full h-11 px-3.5 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
                  placeholder="Clara Bennett"
                />
                {fieldErrors.name && (
                  <p id="error-name" className="mt-1.5 text-xs text-[#8B3A3A]">
                    {fieldErrors.name}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="checkout-email" className="block text-sm font-medium text-[#1E3A2B]">
                  Email address
                </label>
                <input
                  id="checkout-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={values.email}
                  onChange={(e) => handleFieldChange('email', e.target.value)}
                  aria-invalid={Boolean(fieldErrors.email)}
                  aria-describedby={fieldErrors.email ? 'error-email' : undefined}
                  className="mt-1.5 w-full h-11 px-3.5 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
                  placeholder="clara@example.co.uk"
                />
                {fieldErrors.email && (
                  <p id="error-email" className="mt-1.5 text-xs text-[#8B3A3A]">
                    {fieldErrors.email}
                  </p>
                )}
              </div>
            </div>

            <div>
              <label htmlFor="checkout-address1" className="block text-sm font-medium text-[#1E3A2B]">
                Street address
              </label>
              <input
                id="checkout-address1"
                name="addressLine1"
                type="text"
                autoComplete="address-line1"
                required
                value={values.addressLine1}
                onChange={(e) => handleFieldChange('addressLine1', e.target.value)}
                aria-invalid={Boolean(fieldErrors.addressLine1)}
                aria-describedby={fieldErrors.addressLine1 ? 'error-address1' : undefined}
                className="mt-1.5 w-full h-11 px-3.5 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
                placeholder="14 Meadow Lane"
              />
              {fieldErrors.addressLine1 && (
                <p id="error-address1" className="mt-1.5 text-xs text-[#8B3A3A]">
                  {fieldErrors.addressLine1}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="checkout-address2" className="block text-sm font-medium text-[#1E3A2B]">
                Flat, studio, or building (optional)
              </label>
              <input
                id="checkout-address2"
                name="addressLine2"
                type="text"
                autoComplete="address-line2"
                value={values.addressLine2}
                onChange={(e) => handleFieldChange('addressLine2', e.target.value)}
                className="mt-1.5 w-full h-11 px-3.5 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
                placeholder="Studio 3"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label htmlFor="checkout-city" className="block text-sm font-medium text-[#1E3A2B]">
                  Town / City
                </label>
                <input
                  id="checkout-city"
                  name="city"
                  type="text"
                  autoComplete="address-level2"
                  required
                  value={values.city}
                  onChange={(e) => handleFieldChange('city', e.target.value)}
                  aria-invalid={Boolean(fieldErrors.city)}
                  aria-describedby={fieldErrors.city ? 'error-city' : undefined}
                  className="mt-1.5 w-full h-11 px-3.5 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
                  placeholder="Bristol"
                />
                {fieldErrors.city && (
                  <p id="error-city" className="mt-1.5 text-xs text-[#8B3A3A]">
                    {fieldErrors.city}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="checkout-postcode" className="block text-sm font-medium text-[#1E3A2B]">
                  Postcode
                </label>
                <input
                  id="checkout-postcode"
                  name="postcode"
                  type="text"
                  autoComplete="postal-code"
                  required
                  value={values.postcode}
                  onChange={(e) => handleFieldChange('postcode', e.target.value)}
                  aria-invalid={Boolean(fieldErrors.postcode)}
                  aria-describedby={fieldErrors.postcode ? 'error-postcode' : undefined}
                  className="mt-1.5 w-full h-11 px-3.5 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
                  placeholder="BS1 4TR"
                />
                {fieldErrors.postcode && (
                  <p id="error-postcode" className="mt-1.5 text-xs text-[#8B3A3A]">
                    {fieldErrors.postcode}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="checkout-country" className="block text-sm font-medium text-[#1E3A2B]">
                  Country
                </label>
                <input
                  id="checkout-country"
                  name="country"
                  type="text"
                  autoComplete="country-name"
                  required
                  value={values.country}
                  onChange={(e) => handleFieldChange('country', e.target.value)}
                  aria-invalid={Boolean(fieldErrors.country)}
                  aria-describedby={fieldErrors.country ? 'error-country' : undefined}
                  className="mt-1.5 w-full h-11 px-3.5 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
                />
                {fieldErrors.country && (
                  <p id="error-country" className="mt-1.5 text-xs text-[#8B3A3A]">
                    {fieldErrors.country}
                  </p>
                )}
              </div>
            </div>
          </fieldset>

          <div className="pt-4 border-t border-[#E5DFD3]">
            <button
              type="submit"
              disabled={
                isSubmitting ||
                isCheckingCart ||
                !validation?.canCheckout ||
                (Boolean(validation?.hasMaterialChanges) && !changesReviewed)
              }
              className="w-full sm:w-auto min-h-[48px] px-8 py-3 inline-flex items-center justify-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] disabled:bg-[#9BA89E] disabled:cursor-not-allowed text-[#FAF8F4] text-sm font-medium transition-colors"
            >
              <Lock className="w-4 h-4" aria-hidden="true" />
              <span>{isSubmitting ? 'Saving demo order...' : 'Place demo order (no payment)'}</span>
            </button>
          </div>
        </form>

        <aside className="lg:col-span-5 rounded-xl border border-[#E5DFD3] bg-[#F2EFE8]/60 p-6 sm:p-8">
          <h2 className="font-display text-xl font-normal text-[#1E3A2B]">Order summary</h2>

          {!validation ? (
            <p className="mt-4 text-sm text-[#556358]">Recalculating totals from server...</p>
          ) : (
            <>
              <ul className="mt-6 divide-y divide-[#E5DFD3] border-t border-b border-[#E5DFD3]">
                {validation.items.map((item) => (
                  <li key={item.productId} className="py-4 flex items-center justify-between gap-4 text-sm">
                    <div>
                      <p className="font-medium text-[#1E3A2B]">{item.name}</p>
                      <p className="text-xs text-[#556358] tabular-nums">
                        Qty {item.requestedQuantity} × {formatGbp(item.unitPricePence)}
                      </p>
                    </div>
                    <p className="font-medium text-[#243028] tabular-nums shrink-0">
                      {formatGbp(item.lineTotalPence)}
                    </p>
                  </li>
                ))}
              </ul>

              <dl className="mt-6 space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <dt className="text-[#556358]">Subtotal</dt>
                  <dd className="font-medium text-[#243028] tabular-nums">
                    {formatGbp(validation.subtotalPence)}
                  </dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-[#556358]">Standard UK delivery</dt>
                  <dd className="font-medium text-[#1E3A2B] tabular-nums">
                    {formatGbp(validation.shippingPence)}
                  </dd>
                </div>
                <div className="pt-4 border-t border-[#E5DFD3] flex items-center justify-between text-base font-semibold text-[#1E3A2B]">
                  <dt>Total</dt>
                  <dd className="tabular-nums">{formatGbp(validation.totalPence)}</dd>
                </div>
              </dl>

              <div className="mt-5 space-y-2 text-xs text-[#556358] leading-relaxed">
                <p>{validation.shippingPolicySummary}</p>
                <p>{validation.taxPolicySummary}</p>
              </div>
            </>
          )}
        </aside>
      </div>
    </div>
  );
}
