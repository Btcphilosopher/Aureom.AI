'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { AlertTriangle, ArrowRight, Minus, Plus, RefreshCw, Trash2 } from 'lucide-react';
import { useCart } from './CartProvider';
import { ProductImage } from './ProductCard';
import { formatCategoryLabel, formatGbp } from '@/lib/format';
import type { CartValidationResponse } from '@/lib/types';

export function CartClient() {
  const { items, isHydrated, updateQuantity, removeItem, syncServerSnapshot } = useCart();
  const [validation, setValidation] = useState<CartValidationResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const validateWithServer = useCallback(async () => {
    if (!isHydrated || items.length === 0) return;
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await fetch('/api/cart/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: items.map((i) => ({
            productId: i.productId,
            quantity: i.quantity,
            expectedUnitPricePence: i.unitPricePence,
          })),
        }),
      });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error?.message ?? 'Unable to verify bag availability.');
      }
      setValidation(body as CartValidationResponse);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Unable to refresh bag details from the server.',
      );
    } finally {
      setIsLoading(false);
    }
  }, [items, isHydrated]);

  useEffect(() => {
    if (!isHydrated || items.length === 0) return;
    let active = true;
    fetch('/api/cart/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
          expectedUnitPricePence: i.unitPricePence,
        })),
      }),
    })
      .then(async (res) => {
        const body = await res.json();
        if (!res.ok) {
          throw new Error(body?.error?.message ?? 'Unable to verify bag availability.');
        }
        return body as CartValidationResponse;
      })
      .then((data) => {
        if (active) {
          setValidation(data);
          setErrorMessage(null);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        if (active) {
          setErrorMessage(
            err instanceof Error ? err.message : 'Unable to refresh bag details from the server.',
          );
          setIsLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, [items, isHydrated]);

  const handleAcceptUpdatedPrices = () => {
    if (!validation) return;
    syncServerSnapshot(
      validation.items
        .filter((i) => i.isActive)
        .map((i) => ({
          productId: i.productId,
          name: i.name,
          slug: i.slug,
          unitPricePence: i.unitPricePence,
          quantity:
            i.availableQuantity > 0
              ? Math.min(i.requestedQuantity, i.availableQuantity)
              : i.requestedQuantity,
        })),
    );
  };

  if (!isHydrated) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="h-9 w-48 bg-[#E5DFD3]/60 rounded animate-pulse" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-20 text-center">
        <h1 className="font-display text-3xl sm:text-4xl font-normal text-[#1E3A2B]">
          Your bag is empty
        </h1>
        <p className="mt-3 text-base text-[#556358]">
          Explore our stoneware, stationery, and everyday carry pieces to add items to your bag.
        </p>
        <Link
          href="/shop"
          className="mt-8 min-h-[44px] px-6 py-3 inline-flex items-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] text-[#FAF8F4] text-sm font-medium transition-colors"
        >
          <span>Browse collection</span>
          <ArrowRight className="w-4 h-4" aria-hidden="true" />
        </Link>
      </div>
    );
  }

  const displayItems = validation?.items ?? [];
  const hasBlockingIssues = validation ? !validation.canCheckout : false;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="pb-6 border-b border-[#E5DFD3] flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-normal text-[#1E3A2B]">
            Shopping Bag
          </h1>
          <p className="mt-1 text-sm text-[#556358]">
            Prices and stock availability are verified live with the catalogue.
          </p>
        </div>
        <button
          type="button"
          onClick={validateWithServer}
          disabled={isLoading}
          className="inline-flex items-center gap-2 text-sm font-medium text-[#1E3A2B] hover:underline underline-offset-4 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} aria-hidden="true" />
          <span>Refresh availability</span>
        </button>
      </div>

      {/* Material Change / Stock Warning Banner */}
      {validation?.hasMaterialChanges && (
        <div
          role="status"
          aria-live="polite"
          className="mt-6 p-5 rounded-lg border border-[#D4B483] bg-[#FBF6EC]"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-[#8A5A19] shrink-0 mt-0.5" aria-hidden="true" />
            <div className="flex-1">
              <h2 className="text-sm font-semibold text-[#5C3B0E]">
                Catalogue updates affect items in your bag
              </h2>
              <ul className="mt-2 space-y-1 text-sm text-[#5C3B0E] list-disc list-inside">
                {validation.materialChanges.map((change, idx) => (
                  <li key={`${change.productId}-${change.reason}-${idx}`}>{change.message}</li>
                ))}
              </ul>
              {validation.materialChanges.some((c) => c.reason === 'price_changed') && (
                <button
                  type="button"
                  onClick={handleAcceptUpdatedPrices}
                  className="mt-3 px-4 py-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-xs font-medium hover:bg-[#162C20]"
                >
                  Acknowledge updated prices &amp; quantities
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {errorMessage && (
        <div role="alert" className="mt-6 p-4 rounded-lg border border-[#D8B4B4] bg-[#FDF6F6] text-sm text-[#8B3A3A]">
          {errorMessage}
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
        {/* Line Items */}
        <div className="lg:col-span-8 divide-y divide-[#E5DFD3] border-t border-b border-[#E5DFD3]">
          {displayItems.length === 0 ? (
            <div className="py-12 text-sm text-[#556358]">Checking live catalogue prices and stock...</div>
          ) : (
            displayItems.map((item) => {
              const clientSnapshot = items.find((c) => c.productId === item.productId);
              const priceChanged =
                clientSnapshot &&
                item.isActive &&
                clientSnapshot.unitPricePence !== item.unitPricePence;

              return (
                <div key={item.productId} className="py-6 flex flex-col sm:flex-row gap-5">
                  <Link
                    href={item.slug ? `/products/${item.slug}` : '/shop'}
                    className="w-full sm:w-32 aspect-[4/3] rounded-md overflow-hidden bg-[#F2EFE8] border border-[#E5DFD3] shrink-0"
                  >
                    <ProductImage src={item.imageUrl} alt={item.name} />
                  </Link>

                  <div className="flex-1 flex flex-col justify-between gap-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-xs text-[#556358]">
                          {formatCategoryLabel(item.category)}
                        </p>
                        <h2 className="mt-0.5 text-base font-semibold text-[#1E3A2B]">
                          {item.isActive && item.slug ? (
                            <Link href={`/products/${item.slug}`} className="hover:underline underline-offset-4">
                              {item.name}
                            </Link>
                          ) : (
                            item.name
                          )}
                        </h2>
                        <div className="mt-1 flex items-center gap-2 text-sm tabular-nums">
                          <span className="text-[#243028] font-medium">
                            {formatGbp(item.unitPricePence)}
                          </span>
                          {priceChanged && clientSnapshot && (
                            <span className="text-xs text-[#8A5A19]">
                              (previously {formatGbp(clientSnapshot.unitPricePence)})
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-base font-semibold text-[#1E3A2B] tabular-nums">
                        {formatGbp(item.lineTotalPence)}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        {item.isActive && item.availableQuantity > 0 ? (
                          <div className="inline-flex items-center border border-[#E5DFD3] rounded-md bg-white">
                            <button
                              type="button"
                              onClick={() =>
                                updateQuantity(item.productId, item.requestedQuantity - 1)
                              }
                              aria-label={`Decrease quantity of ${item.name}`}
                              className="w-10 h-10 flex items-center justify-center text-[#1E3A2B] hover:bg-[#F2EFE8]"
                            >
                              <Minus className="w-3.5 h-3.5" aria-hidden="true" />
                            </button>
                            <span
                              className="w-10 text-center text-sm font-medium tabular-nums"
                              aria-label={`Quantity of ${item.name}`}
                            >
                              {item.requestedQuantity}
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                updateQuantity(
                                  item.productId,
                                  Math.min(item.availableQuantity, item.requestedQuantity + 1),
                                )
                              }
                              disabled={item.requestedQuantity >= item.availableQuantity}
                              aria-label={`Increase quantity of ${item.name}`}
                              className="w-10 h-10 flex items-center justify-center text-[#1E3A2B] hover:bg-[#F2EFE8] disabled:opacity-40"
                            >
                              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs font-medium text-[#8B3A3A]">
                            {!item.isActive ? 'Discontinued' : 'Out of stock'}
                          </span>
                        )}

                        {item.isActive &&
                          item.availableQuantity > 0 &&
                          item.requestedQuantity > item.availableQuantity && (
                            <button
                              type="button"
                              onClick={() =>
                                updateQuantity(item.productId, item.availableQuantity)
                              }
                              className="text-xs font-medium text-[#1E3A2B] underline underline-offset-4"
                            >
                              Adjust to {item.availableQuantity} available
                            </button>
                          )}
                      </div>

                      <button
                        type="button"
                        onClick={() => removeItem(item.productId)}
                        className="min-h-[40px] px-2 inline-flex items-center gap-1.5 text-xs font-medium text-[#556358] hover:text-[#8B3A3A] transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Summary Panel */}
        <aside className="lg:col-span-4 rounded-xl border border-[#E5DFD3] bg-[#F2EFE8]/60 p-6 sm:p-8">
          <h2 className="font-display text-xl font-normal text-[#1E3A2B]">Order summary</h2>

          <dl className="mt-6 space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-[#556358]">Subtotal</dt>
              <dd className="font-medium text-[#243028] tabular-nums">
                {validation ? formatGbp(validation.subtotalPence) : '—'}
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-[#556358]">Standard UK delivery</dt>
              <dd className="font-medium text-[#1E3A2B] tabular-nums">
                {validation ? formatGbp(validation.shippingPence) : 'Free'}
              </dd>
            </div>
            <div className="pt-4 border-t border-[#E5DFD3] flex items-center justify-between text-base font-semibold text-[#1E3A2B]">
              <dt>Estimated total</dt>
              <dd className="tabular-nums">
                {validation ? formatGbp(validation.totalPence) : '—'}
              </dd>
            </div>
          </dl>

          {validation && (
            <div className="mt-5 space-y-2 text-xs text-[#556358] leading-relaxed">
              <p>{validation.shippingPolicySummary}</p>
              <p>{validation.taxPolicySummary}</p>
            </div>
          )}

          <div className="mt-6">
            {hasBlockingIssues ? (
              <button
                type="button"
                disabled
                className="w-full min-h-[48px] px-6 py-3 rounded-md bg-[#9BA89E] text-[#FAF8F4] text-sm font-medium cursor-not-allowed"
              >
                Resolve bag issues to checkout
              </button>
            ) : (
              <Link
                href="/checkout"
                className="w-full min-h-[48px] px-6 py-3 inline-flex items-center justify-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] text-[#FAF8F4] text-sm font-medium transition-colors"
              >
                <span>Proceed to checkout</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
