'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Search, RotateCcw, AlertCircle } from 'lucide-react';
import { ProductCard } from './ProductCard';
import type { ProductDTO } from '@/lib/types';

const CATEGORY_TABS = [
  { id: 'all', label: 'All' },
  { id: 'homeware', label: 'Homeware' },
  { id: 'stationery', label: 'Stationery' },
  { id: 'accessories', label: 'Accessories' },
] as const;

const SORT_OPTIONS = [
  { id: 'featured', label: 'Featured' },
  { id: 'price_asc', label: 'Price: Low to high' },
  { id: 'price_desc', label: 'Price: High to low' },
  { id: 'name_asc', label: 'Name: A to Z' },
] as const;

export function ShopClient({ initialProducts }: { initialProducts: ProductDTO[] }) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const category = searchParams.get('category') ?? 'all';
  const appliedQuery = searchParams.get('q') ?? '';
  const sort = searchParams.get('sort') ?? 'featured';

  const [queryInput, setQueryInput] = useState(appliedQuery);
  const [products, setProducts] = useState<ProductDTO[]>(initialProducts);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const loadFromServer = useCallback(async (cat: string, q: string, s: string) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const params = new URLSearchParams();
      if (cat && cat !== 'all') params.set('category', cat);
      if (q.trim()) params.set('q', q.trim());
      if (s && s !== 'featured') params.set('sort', s);

      const res = await fetch(`/api/products?${params.toString()}`, {
        cache: 'no-store',
      });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error?.message ?? 'Unable to load products.');
      }
      setProducts(body.products ?? []);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Unable to reach the product catalogue.',
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    let active = true;
    const params = new URLSearchParams();
    if (category && category !== 'all') params.set('category', category);
    if (appliedQuery.trim()) params.set('q', appliedQuery.trim());
    if (sort && sort !== 'featured') params.set('sort', sort);

    fetch(`/api/products?${params.toString()}`, { cache: 'no-store' })
      .then(async (res) => {
        const body = await res.json();
        if (!res.ok) {
          throw new Error(body?.error?.message ?? 'Unable to load products.');
        }
        return body.products ?? [];
      })
      .then((list: ProductDTO[]) => {
        if (active) {
          setProducts(list);
          setErrorMessage(null);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        if (active) {
          setErrorMessage(
            err instanceof Error ? err.message : 'Unable to reach the product catalogue.',
          );
          setIsLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, [category, appliedQuery, sort]);

  const updateUrl = (nextCat: string, nextQ: string, nextSort: string) => {
    const params = new URLSearchParams();
    if (nextCat && nextCat !== 'all') params.set('category', nextCat);
    if (nextQ.trim()) params.set('q', nextQ.trim());
    if (nextSort && nextSort !== 'featured') params.set('sort', nextSort);
    const qs = params.toString();
    setIsLoading(true);
    router.replace(qs ? `/shop?${qs}` : '/shop', { scroll: false });
  };

  const handleCategoryChange = (nextCat: string) => {
    updateUrl(nextCat, appliedQuery, sort);
  };

  const handleSortChange = (nextSort: string) => {
    updateUrl(category, appliedQuery, nextSort);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUrl(category, queryInput, sort);
  };

  const handleResetFilters = () => {
    setQueryInput('');
    setIsLoading(true);
    router.replace('/shop', { scroll: false });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="pb-8 border-b border-[#E5DFD3]">
        <h1 className="font-display text-3xl sm:text-4xl font-normal text-[#1E3A2B]">
          The Collection
        </h1>
        <p className="mt-2 text-base text-[#556358] max-w-2xl">
          Everyday homeware, stationery, and carry pieces stocked in small runs. Complimentary UK delivery on every order.
        </p>

        {/* Controls Bar */}
        <div className="mt-8 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Category Filter Tabs */}
          <div
            role="tablist"
            aria-label="Filter products by category"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-[#F2EFE8] border border-[#E5DFD3] rounded-lg w-fit"
          >
            {CATEGORY_TABS.map((tab) => {
              const active = category === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => handleCategoryChange(tab.id)}
                  className={`min-h-[38px] px-4 py-1.5 text-sm font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-[#1E3A2B] text-[#FAF8F4] shadow-xs'
                      : 'text-[#243028] hover:text-[#1E3A2B] hover:bg-[#FAF8F4]/70'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Search & Sort Controls */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center" role="search">
              <label htmlFor="shop-search" className="sr-only">
                Search catalogue
              </label>
              <input
                id="shop-search"
                type="search"
                value={queryInput}
                onChange={(e) => setQueryInput(e.target.value)}
                placeholder="Search by name or material..."
                className="w-full sm:w-64 h-11 pl-3.5 pr-10 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] placeholder:text-[#556358] focus:border-[#1E3A2B]"
              />
              <button
                type="submit"
                aria-label="Apply search filter"
                className="absolute right-1.5 w-8 h-8 flex items-center justify-center text-[#1E3A2B] hover:opacity-75"
              >
                <Search className="w-4 h-4" aria-hidden="true" />
              </button>
            </form>

            <div className="flex items-center gap-2">
              <label htmlFor="shop-sort" className="text-sm text-[#556358] whitespace-nowrap">
                Sort by
              </label>
              <select
                id="shop-sort"
                value={sort}
                onChange={(e) => handleSortChange(e.target.value)}
                className="h-11 px-3 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] focus:border-[#1E3A2B]"
              >
                {SORT_OPTIONS.map((opt) => (
                  <option key={opt.id} value={opt.id}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Results Status Row */}
      <div className="mt-6 flex items-center justify-between text-sm text-[#556358]" aria-live="polite">
        <p className="tabular-nums">
          {isLoading
            ? 'Updating catalogue...'
            : `${products.length} product${products.length === 1 ? '' : 's'} shown`}
        </p>
        {(category !== 'all' || appliedQuery !== '' || sort !== 'featured') && (
          <button
            type="button"
            onClick={handleResetFilters}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-[#1E3A2B] hover:underline underline-offset-4"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Reset filters</span>
          </button>
        )}
      </div>

      {/* Error State */}
      {errorMessage && (
        <div
          role="alert"
          className="mt-8 p-6 rounded-lg border border-[#D8B4B4] bg-[#FDF6F6] flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-[#8B3A3A] shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <h2 className="text-sm font-semibold text-[#8B3A3A]">Unable to load products</h2>
              <p className="mt-1 text-sm text-[#556358]">{errorMessage}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => loadFromServer(category, appliedQuery, sort)}
            className="min-h-[40px] px-4 py-2 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm font-medium whitespace-nowrap shrink-0"
          >
            Try again
          </button>
        </div>
      )}

      {/* Loading Skeleton State */}
      {!errorMessage && isLoading && products.length === 0 && (
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12" aria-busy="true">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className="animate-pulse">
              <div className="aspect-[4/3] w-full rounded-lg bg-[#E5DFD3]/60" />
              <div className="mt-4 h-3 w-24 rounded bg-[#E5DFD3]/70" />
              <div className="mt-2 h-5 w-44 rounded bg-[#E5DFD3]/70" />
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!errorMessage && !isLoading && products.length === 0 && (
        <div className="mt-12 py-16 px-6 text-center rounded-lg border border-[#E5DFD3] bg-[#F2EFE8]/40">
          <h2 className="font-display text-2xl font-normal text-[#1E3A2B]">
            No matching pieces found
          </h2>
          <p className="mt-2 text-sm text-[#556358] max-w-md mx-auto">
            No items matched your current search or category selection. Try clearing your filters to explore the full catalogue.
          </p>
          <button
            type="button"
            onClick={handleResetFilters}
            className="mt-6 min-h-[44px] px-5 py-2.5 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] text-[#FAF8F4] text-sm font-medium transition-colors"
          >
            View all products
          </button>
        </div>
      )}

      {/* Product Grid */}
      {!errorMessage && products.length > 0 && (
        <div
          className={`mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12 transition-opacity duration-150 ${
            isLoading ? 'opacity-65' : 'opacity-100'
          }`}
        >
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
