'use client';

import React, { createContext, useCallback, useContext, useMemo, useSyncExternalStore } from 'react';
import type { CartClientItem, ProductDTO } from '@/lib/types';

const CART_STORAGE_KEY = 'aureom_goods_cart_v1';
const IDEMPOTENCY_STORAGE_KEY = 'aureom_goods_checkout_idempotency_v1';
const ORDER_TOKEN_PREFIX = 'aureom_goods_order_token_';
const CART_CHANGE_EVENT = 'aureom-cart-change';

const EMPTY_CART: CartClientItem[] = [];
let cachedRawCart: string | null = null;
let cachedParsedCart: CartClientItem[] = EMPTY_CART;

function readCartFromStorage(): CartClientItem[] {
  if (typeof window === 'undefined') return EMPTY_CART;
  try {
    const raw = window.localStorage.getItem(CART_STORAGE_KEY);
    if (raw === cachedRawCart) {
      return cachedParsedCart;
    }
    cachedRawCart = raw;
    if (!raw) {
      cachedParsedCart = EMPTY_CART;
      return cachedParsedCart;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      cachedParsedCart = parsed.filter(
        (x): x is CartClientItem =>
          typeof x?.productId === 'number' &&
          typeof x?.slug === 'string' &&
          typeof x?.name === 'string' &&
          typeof x?.unitPricePence === 'number' &&
          typeof x?.quantity === 'number' &&
          x.quantity >= 1,
      );
      return cachedParsedCart;
    }
  } catch {
    // Ignore malformed local storage
  }
  cachedParsedCart = EMPTY_CART;
  return cachedParsedCart;
}

function writeCartToStorage(next: CartClientItem[]): void {
  if (typeof window === 'undefined') return;
  try {
    const serialized = JSON.stringify(next);
    cachedRawCart = serialized;
    cachedParsedCart = next;
    window.localStorage.setItem(CART_STORAGE_KEY, serialized);
    window.dispatchEvent(new Event(CART_CHANGE_EVENT));
  } catch {
    // Ignore storage quota errors
  }
}

function subscribeCart(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  const onStorage = (e: StorageEvent) => {
    if (e.key === CART_STORAGE_KEY || e.key === null) callback();
  };
  window.addEventListener('storage', onStorage);
  window.addEventListener(CART_CHANGE_EVENT, callback);
  return () => {
    window.removeEventListener('storage', onStorage);
    window.removeEventListener(CART_CHANGE_EVENT, callback);
  };
}

function subscribeHydrated(): () => void {
  return () => {};
}

interface CartContextValue {
  items: CartClientItem[];
  totalCount: number;
  isHydrated: boolean;
  addItem: (
    product: Pick<ProductDTO, 'id' | 'slug' | 'name' | 'pricePence' | 'stockQuantity'>,
    quantity?: number,
  ) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  removeItem: (productId: number) => void;
  clearCart: () => void;
  syncServerSnapshot: (
    updates: Array<{
      productId: number;
      name: string;
      slug: string;
      unitPricePence: number;
      quantity: number;
    }>,
  ) => void;
  getCheckoutIdempotencyKey: () => string;
  rotateCheckoutIdempotencyKey: () => string;
  saveOrderAccessToken: (reference: string, token: string) => void;
  getOrderAccessToken: (reference: string) => string | null;
}

const CartContext = createContext<CartContextValue | null>(null);

function createIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `chk_${crypto.randomUUID().replace(/-/g, '')}`;
  }
  return `chk_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 12)}`;
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const items = useSyncExternalStore(
    subscribeCart,
    readCartFromStorage,
    () => EMPTY_CART,
  );
  const isHydrated = useSyncExternalStore(
    subscribeHydrated,
    () => true,
    () => false,
  );

  const addItem = useCallback(
    (
      product: Pick<ProductDTO, 'id' | 'slug' | 'name' | 'pricePence' | 'stockQuantity'>,
      quantity = 1,
    ) => {
      const safeQty = Math.max(1, Math.min(99, Math.floor(quantity)));
      const prev = readCartFromStorage();
      const idx = prev.findIndex((i) => i.productId === product.id);
      if (idx >= 0) {
        const next = [...prev];
        const existing = next[idx];
        const maxAllowed = product.stockQuantity > 0 ? Math.min(99, product.stockQuantity) : 99;
        next[idx] = {
          ...existing,
          name: product.name,
          slug: product.slug,
          unitPricePence: product.pricePence,
          quantity: Math.min(maxAllowed, existing.quantity + safeQty),
        };
        writeCartToStorage(next);
      } else {
        writeCartToStorage([
          ...prev,
          {
            productId: product.id,
            slug: product.slug,
            name: product.name,
            unitPricePence: product.pricePence,
            quantity: safeQty,
          },
        ]);
      }
    },
    [],
  );

  const updateQuantity = useCallback((productId: number, quantity: number) => {
    const prev = readCartFromStorage();
    if (quantity < 1) {
      writeCartToStorage(prev.filter((i) => i.productId !== productId));
      return;
    }
    const safeQty = Math.min(99, Math.floor(quantity));
    writeCartToStorage(
      prev.map((i) => (i.productId === productId ? { ...i, quantity: safeQty } : i)),
    );
  }, []);

  const removeItem = useCallback((productId: number) => {
    const prev = readCartFromStorage();
    writeCartToStorage(prev.filter((i) => i.productId !== productId));
  }, []);

  const clearCart = useCallback(() => {
    writeCartToStorage([]);
  }, []);

  const syncServerSnapshot = useCallback(
    (
      updates: Array<{
        productId: number;
        name: string;
        slug: string;
        unitPricePence: number;
        quantity: number;
      }>,
    ) => {
      const prev = readCartFromStorage();
      const map = new Map(updates.map((u) => [u.productId, u]));
      writeCartToStorage(
        prev.map((item) => {
          const fresh = map.get(item.productId);
          if (!fresh) return item;
          return {
            ...item,
            name: fresh.name,
            slug: fresh.slug,
            unitPricePence: fresh.unitPricePence,
            quantity: fresh.quantity,
          };
        }),
      );
    },
    [],
  );

  const getCheckoutIdempotencyKey = useCallback(() => {
    try {
      const existing = window.sessionStorage.getItem(IDEMPOTENCY_STORAGE_KEY);
      if (existing) return existing;
      const fresh = createIdempotencyKey();
      window.sessionStorage.setItem(IDEMPOTENCY_STORAGE_KEY, fresh);
      return fresh;
    } catch {
      return createIdempotencyKey();
    }
  }, []);

  const rotateCheckoutIdempotencyKey = useCallback(() => {
    const fresh = createIdempotencyKey();
    try {
      window.sessionStorage.setItem(IDEMPOTENCY_STORAGE_KEY, fresh);
    } catch {
      // ignore
    }
    return fresh;
  }, []);

  const saveOrderAccessToken = useCallback((reference: string, token: string) => {
    try {
      window.sessionStorage.setItem(`${ORDER_TOKEN_PREFIX}${reference.toUpperCase()}`, token);
    } catch {
      // ignore
    }
  }, []);

  const getOrderAccessToken = useCallback((reference: string) => {
    try {
      return window.sessionStorage.getItem(`${ORDER_TOKEN_PREFIX}${reference.toUpperCase()}`);
    } catch {
      return null;
    }
  }, []);

  const totalCount = useMemo(
    () => items.reduce((sum, item) => sum + item.quantity, 0),
    [items],
  );

  const value = useMemo<CartContextValue>(
    () => ({
      items,
      totalCount,
      isHydrated,
      addItem,
      updateQuantity,
      removeItem,
      clearCart,
      syncServerSnapshot,
      getCheckoutIdempotencyKey,
      rotateCheckoutIdempotencyKey,
      saveOrderAccessToken,
      getOrderAccessToken,
    }),
    [
      items,
      totalCount,
      isHydrated,
      addItem,
      updateQuantity,
      removeItem,
      clearCart,
      syncServerSnapshot,
      getCheckoutIdempotencyKey,
      rotateCheckoutIdempotencyKey,
      saveOrderAccessToken,
      getOrderAccessToken,
    ],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error('useCart must be used within CartProvider');
  }
  return ctx;
}
