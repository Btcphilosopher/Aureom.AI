'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Menu, Search, ShoppingBag, X } from 'lucide-react';
import { useCart } from './CartProvider';

export function SiteHeader() {
  const { totalCount, isHydrated } = useCart();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = searchQuery.trim();
    setMobileMenuOpen(false);
    setMobileSearchOpen(false);
    if (trimmed) {
      router.push(`/shop?q=${encodeURIComponent(trimmed)}`);
    } else {
      router.push('/shop');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F4]/95 backdrop-blur-sm border-b border-[#E5DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Single-element Wordmark */}
        <Link
          href="/"
          className="font-display text-xl sm:text-2xl font-medium tracking-tight text-[#1E3A2B] whitespace-nowrap shrink-0 hover:opacity-85 transition-opacity duration-150"
        >
          Aureom Goods
        </Link>

        {/* Zone 2: Clean single-line navigation links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-6 text-sm font-medium text-[#243028]">
          <Link
            href="/"
            className="hover:text-[#1E3A2B] hover:underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 py-1"
          >
            Home
          </Link>
          <Link
            href="/shop"
            className="hover:text-[#1E3A2B] hover:underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 py-1"
          >
            Shop
          </Link>
          <Link
            href="/shop?category=homeware"
            className="hover:text-[#1E3A2B] hover:underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 py-1"
          >
            Homeware
          </Link>
          <Link
            href="/shop?category=stationery"
            className="hover:text-[#1E3A2B] hover:underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 py-1"
          >
            Stationery
          </Link>
          <Link
            href="/shop?category=accessories"
            className="hover:text-[#1E3A2B] hover:underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 py-1"
          >
            Accessories
          </Link>
        </nav>

        {/* Zone 3: Search + Cart Action */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <form onSubmit={handleSearchSubmit} className="hidden lg:flex items-center relative" role="search">
            <label htmlFor="header-search" className="sr-only">
              Search products
            </label>
            <input
              id="header-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search goods..."
              className="w-44 xl:w-52 h-10 pl-3 pr-9 text-sm bg-[#F2EFE8] border border-[#E5DFD3] rounded-md text-[#243028] placeholder:text-[#556358] focus:bg-white focus:border-[#1E3A2B] transition-colors duration-150"
            />
            <button
              type="submit"
              aria-label="Submit search"
              className="absolute right-1.5 w-8 h-8 flex items-center justify-center text-[#1E3A2B] hover:opacity-75 transition-opacity"
            >
              <Search className="w-4 h-4" aria-hidden="true" />
            </button>
          </form>

          <button
            type="button"
            onClick={() => setMobileSearchOpen((v) => !v)}
            aria-label={mobileSearchOpen ? 'Close search' : 'Open search'}
            aria-expanded={mobileSearchOpen}
            className="lg:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-md text-[#1E3A2B] hover:bg-[#F2EFE8] transition-colors"
          >
            <Search className="w-5 h-5" aria-hidden="true" />
          </button>

          <Link
            href="/cart"
            aria-label={`Shopping bag with ${isHydrated ? totalCount : 0} items`}
            className="min-h-[44px] px-4 py-2 inline-flex items-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] text-[#FAF8F4] text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0"
          >
            <ShoppingBag className="w-4 h-4" aria-hidden="true" />
            <span className="tabular-nums">
              Bag{isHydrated && totalCount > 0 ? ` (${totalCount})` : ''}
            </span>
          </Link>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((v) => !v)}
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileMenuOpen}
            className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-md text-[#1E3A2B] hover:bg-[#F2EFE8] transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" aria-hidden="true" />
            ) : (
              <Menu className="w-5 h-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Search Drawer */}
      {mobileSearchOpen && (
        <div className="lg:hidden border-t border-[#E5DFD3] bg-[#FAF8F4] px-4 py-3">
          <form onSubmit={handleSearchSubmit} className="flex items-center gap-2" role="search">
            <label htmlFor="mobile-header-search" className="sr-only">
              Search products
            </label>
            <input
              id="mobile-header-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search homeware, stationery, accessories..."
              className="flex-1 h-11 px-3 text-sm bg-white border border-[#E5DFD3] rounded-md text-[#243028] placeholder:text-[#556358]"
            />
            <button
              type="submit"
              className="h-11 px-4 rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm font-medium whitespace-nowrap"
            >
              Search
            </button>
          </form>
        </div>
      )}

      {/* Mobile Nav Drawer */}
      {mobileMenuOpen && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden border-t border-[#E5DFD3] bg-[#FAF8F4] px-4 py-3 flex flex-col gap-1"
        >
          {[
            { href: '/', label: 'Home' },
            { href: '/shop', label: 'Shop All' },
            { href: '/shop?category=homeware', label: 'Homeware' },
            { href: '/shop?category=stationery', label: 'Stationery' },
            { href: '/shop?category=accessories', label: 'Accessories' },
          ].map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="min-h-[44px] flex items-center px-2 text-sm font-medium text-[#243028] hover:text-[#1E3A2B] hover:bg-[#F2EFE8] rounded-md"
            >
              {link.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
