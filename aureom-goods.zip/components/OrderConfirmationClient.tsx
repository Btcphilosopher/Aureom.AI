'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { CheckCircle2, Lock, ArrowRight } from 'lucide-react';
import { useCart } from './CartProvider';
import {
  formatFulfilmentStatusLabel,
  formatGbp,
  formatOrderStatusLabel,
  formatPaymentStatusLabel,
} from '@/lib/format';
import type { OrderDTO } from '@/lib/types';

export function OrderConfirmationClient({ reference }: { reference: string }) {
  const searchParams = useSearchParams();
  const { getOrderAccessToken, isHydrated } = useCart();

  const queryToken = searchParams.get('token');
  const storedToken = isHydrated ? getOrderAccessToken(reference) : null;
  const token = queryToken || storedToken;

  const [order, setOrder] = useState<OrderDTO | null>(null);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [hasLoaded, setHasLoaded] = useState(false);

  useEffect(() => {
    if (!isHydrated || !token) return;
    let cancelled = false;

    fetch(`/api/orders/${encodeURIComponent(reference)}?token=${encodeURIComponent(token)}`, {
      cache: 'no-store',
    })
      .then(async (res) => {
        const body = await res.json();
        if (!res.ok) {
          throw new Error(body?.error?.message ?? 'Order could not be retrieved.');
        }
        return body.order as OrderDTO;
      })
      .then((data) => {
        if (!cancelled) {
          setOrder(data);
          setFetchError(null);
          setHasLoaded(true);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setFetchError(
            err instanceof Error ? err.message : 'Unable to retrieve order details.',
          );
          setHasLoaded(true);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [reference, token, isHydrated]);

  if (!isHydrated || (token && !hasLoaded)) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
        <div className="h-8 w-64 bg-[#E5DFD3]/60 rounded animate-pulse" />
        <div className="mt-6 h-48 bg-[#E5DFD3]/40 rounded-lg animate-pulse" />
      </div>
    );
  }

  const missingTokenMessage = !token
    ? 'Access to this order requires its private confirmation link token.'
    : null;
  const displayError = missingTokenMessage ?? fetchError;

  if (displayError || !order) {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-20 text-center">
        <div className="w-12 h-12 mx-auto rounded-full bg-[#F2EFE8] flex items-center justify-center text-[#1E3A2B]">
          <Lock className="w-5 h-5" aria-hidden="true" />
        </div>
        <h1 className="mt-5 font-display text-3xl text-[#1E3A2B]">Order access protected</h1>
        <p className="mt-3 text-sm text-[#556358]">
          {displayError ?? 'This order confirmation cannot be displayed without a valid access token.'}
        </p>
        <Link
          href="/shop"
          className="mt-8 min-h-[44px] px-6 py-2.5 inline-flex items-center rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm font-medium"
        >
          Return to shop
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="p-6 sm:p-8 rounded-xl border border-[#C8D4C9] bg-[#E7ECE7]/65">
        <div className="flex items-start gap-3">
          <CheckCircle2 className="w-6 h-6 text-[#1E3A2B] shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="text-xs font-medium text-[#556358] tabular-nums">
              Order reference: <span className="text-[#1E3A2B] font-semibold">{order.reference}</span>
            </p>
            <h1 className="mt-1 font-display text-2xl sm:text-3xl font-normal text-[#1E3A2B]">
              {order.statusBanner}
            </h1>
            <p className="mt-2 text-sm text-[#243028]">
              Thank you, {order.customerName}. Your order snapshot has been saved under{' '}
              <span className="font-medium">{order.customerEmail}</span>.
            </p>
          </div>
        </div>

        <dl className="mt-6 pt-5 border-t border-[#C8D4C9] grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
          <div>
            <dt className="text-xs text-[#556358]">Payment status</dt>
            <dd className="mt-0.5 font-semibold text-[#1E3A2B]">
              {formatPaymentStatusLabel(order.paymentStatus)}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-[#556358]">Order status</dt>
            <dd className="mt-0.5 font-semibold text-[#1E3A2B]">
              {formatOrderStatusLabel(order.orderStatus)}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-[#556358]">Fulfilment status</dt>
            <dd className="mt-0.5 font-semibold text-[#1E3A2B]">
              {formatFulfilmentStatusLabel(order.fulfilmentStatus)}
            </dd>
          </div>
        </dl>
      </div>

      <div className="mt-10 grid grid-cols-1 md:grid-cols-12 gap-8">
        <section className="md:col-span-7" aria-labelledby="items-heading">
          <h2 id="items-heading" className="font-display text-xl font-normal text-[#1E3A2B] pb-3 border-b border-[#E5DFD3]">
            Purchased items
          </h2>

          <ul className="divide-y divide-[#E5DFD3] border-b border-[#E5DFD3]">
            {order.items.map((item) => (
              <li key={item.id} className="py-4 flex items-center justify-between gap-4 text-sm">
                <div>
                  <p className="font-semibold text-[#1E3A2B]">{item.productName}</p>
                  <p className="mt-0.5 text-xs text-[#556358] tabular-nums">
                    Qty {item.quantity} × {formatGbp(item.unitPricePence)}
                  </p>
                </div>
                <p className="font-medium text-[#243028] tabular-nums">
                  {formatGbp(item.lineTotalPence)}
                </p>
              </li>
            ))}
          </ul>

          <dl className="mt-5 space-y-2.5 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-[#556358]">Subtotal</dt>
              <dd className="font-medium text-[#243028] tabular-nums">
                {formatGbp(order.subtotalPence)}
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-[#556358]">Standard UK delivery</dt>
              <dd className="font-medium text-[#1E3A2B] tabular-nums">
                {formatGbp(order.shippingPence)}
              </dd>
            </div>
            <div className="pt-3 border-t border-[#E5DFD3] flex items-center justify-between text-base font-semibold text-[#1E3A2B]">
              <dt>Final total</dt>
              <dd className="tabular-nums">{formatGbp(order.totalPence)}</dd>
            </div>
          </dl>
        </section>

        <aside className="md:col-span-5 space-y-6">
          <div className="p-6 rounded-lg border border-[#E5DFD3] bg-[#F2EFE8]/50">
            <h2 className="font-display text-lg font-normal text-[#1E3A2B]">Delivery destination</h2>
            <address className="mt-3 not-italic text-sm text-[#243028] space-y-1 leading-relaxed">
              <p className="font-medium">{order.customerName}</p>
              <p>{order.deliveryAddress.line1}</p>
              {order.deliveryAddress.line2 && <p>{order.deliveryAddress.line2}</p>}
              <p>
                {order.deliveryAddress.city}, {order.deliveryAddress.postcode}
              </p>
              <p>{order.deliveryAddress.country}</p>
            </address>
          </div>

          <div className="p-6 rounded-lg border border-[#E5DFD3] bg-[#FAF8F4] text-xs text-[#556358] space-y-2 leading-relaxed">
            <p className="font-semibold text-[#1E3A2B]">Shipping &amp; tax policy</p>
            <p>{order.shippingPolicySummary}</p>
            <p>{order.taxPolicySummary}</p>
          </div>

          <Link
            href="/shop"
            className="w-full min-h-[44px] px-5 py-2.5 inline-flex items-center justify-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] text-[#FAF8F4] text-sm font-medium transition-colors"
          >
            <span>Continue shopping</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </Link>
        </aside>
      </div>
    </div>
  );
}
