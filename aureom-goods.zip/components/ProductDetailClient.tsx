'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Check, Minus, Plus, ShoppingBag } from 'lucide-react';
import { useCart } from './CartProvider';
import { ProductImage } from './ProductCard';
import { formatCategoryLabel, formatGbp } from '@/lib/format';
import type { ProductDTO } from '@/lib/types';

export function ProductDetailClient({ product }: { product: ProductDTO }) {
  const { addItem, items } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);

  const inBagCount = items.find((i) => i.productId === product.id)?.quantity ?? 0;
  const maxAddable = Math.max(0, product.stockQuantity - inBagCount);
  const isOutOfStock = product.stockQuantity === 0;
  const maxSelector = Math.max(1, product.stockQuantity);

  const handleAddToCart = () => {
    if (isOutOfStock || maxAddable === 0) return;
    const qtyToAdd = Math.min(quantity, maxAddable);
    addItem(product, qtyToAdd);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
      <nav aria-label="Breadcrumb" className="mb-8">
        <Link
          href="/shop"
          className="inline-flex items-center gap-2 text-sm font-medium text-[#556358] hover:text-[#1E3A2B] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to collection</span>
        </Link>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start">
        {/* Left: Sticky Product Media */}
        <div className="lg:col-span-7 lg:sticky lg:top-24">
          <div className="aspect-[4/3] w-full overflow-hidden rounded-xl bg-[#F2EFE8] border border-[#E5DFD3]">
            <ProductImage src={product.imageUrl} alt={product.name} priority />
          </div>
        </div>

        {/* Right: Contiguous Purchase Module */}
        <div className="lg:col-span-5 flex flex-col">
          <div className="flex items-center gap-2 text-xs text-[#556358]">
            <Link
              href={`/shop?category=${product.category}`}
              className="hover:text-[#1E3A2B] hover:underline underline-offset-4"
            >
              {formatCategoryLabel(product.category)}
            </Link>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              {isOutOfStock
                ? 'Currently out of stock'
                : `${product.stockQuantity} in stock`}
            </span>
          </div>

          <h1 className="mt-3 font-display text-3xl sm:text-4xl font-normal text-[#1E3A2B]">
            {product.name}
          </h1>

          <p className="mt-4 text-2xl font-medium text-[#243028] tabular-nums">
            {formatGbp(product.pricePence)}
          </p>

          <p className="mt-6 text-base text-[#556358] leading-relaxed">
            {product.description}
          </p>

          <div className="mt-8 pt-8 border-t border-[#E5DFD3] space-y-6">
            {/* Quantity Selector */}
            <div>
              <label htmlFor="product-qty" className="block text-sm font-medium text-[#1E3A2B]">
                Quantity
              </label>
              <div className="mt-2 flex items-center gap-4">
                <div className="inline-flex items-center border border-[#E5DFD3] rounded-md bg-white">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    disabled={isOutOfStock || quantity <= 1}
                    aria-label="Decrease quantity"
                    className="w-11 h-11 flex items-center justify-center text-[#1E3A2B] hover:bg-[#F2EFE8] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  >
                    <Minus className="w-4 h-4" aria-hidden="true" />
                  </button>
                  <input
                    id="product-qty"
                    type="number"
                    min={1}
                    max={maxSelector}
                    value={quantity}
                    disabled={isOutOfStock}
                    onChange={(e) => {
                      const val = parseInt(e.target.value, 10);
                      if (!Number.isNaN(val)) {
                        setQuantity(Math.max(1, Math.min(maxSelector, val)));
                      }
                    }}
                    className="w-14 h-11 text-center text-sm font-medium text-[#243028] tabular-nums bg-transparent focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.min(maxSelector, q + 1))}
                    disabled={isOutOfStock || quantity >= maxSelector}
                    aria-label="Increase quantity"
                    className="w-11 h-11 flex items-center justify-center text-[#1E3A2B] hover:bg-[#F2EFE8] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  >
                    <Plus className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>

                {inBagCount > 0 && (
                  <span className="text-xs text-[#556358] tabular-nums">
                    {inBagCount} already in bag
                  </span>
                )}
              </div>
            </div>

            {/* Add to Bag Button */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={handleAddToCart}
                disabled={isOutOfStock || maxAddable === 0}
                className="flex-1 min-h-[48px] px-6 py-3 inline-flex items-center justify-center gap-2 rounded-md bg-[#1E3A2B] hover:bg-[#162C20] disabled:bg-[#9BA89E] disabled:cursor-not-allowed text-[#FAF8F4] text-sm font-medium transition-colors duration-150"
              >
                {justAdded ? (
                  <>
                    <Check className="w-4 h-4" aria-hidden="true" />
                    <span>Added to bag</span>
                  </>
                ) : isOutOfStock ? (
                  <span>Out of stock</span>
                ) : maxAddable === 0 ? (
                  <span>Maximum stock in bag</span>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" aria-hidden="true" />
                    <span>Add to bag</span>
                  </>
                )}
              </button>

              {inBagCount > 0 && (
                <Link
                  href="/cart"
                  className="min-h-[48px] px-5 py-3 inline-flex items-center justify-center rounded-md border border-[#1E3A2B] text-[#1E3A2B] hover:bg-[#E7ECE7] text-sm font-medium transition-colors whitespace-nowrap"
                >
                  View bag
                </Link>
              )}
            </div>

            <div aria-live="polite" className="text-xs text-[#556358] space-y-1.5 pt-2">
              <p>Complimentary standard UK delivery (2–4 working days).</p>
              <p>Displayed price includes applicable UK VAT.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
