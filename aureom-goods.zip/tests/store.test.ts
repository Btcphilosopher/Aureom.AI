import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { getDb, seedProducts } from '../lib/db.ts';
import {
  checkHealth,
  createCheckoutOrder,
  getOrderByReferenceAndToken,
  getProductBySlug,
  listProducts,
  StoreError,
  validateCart,
} from '../lib/store-service.ts';

function withTempDb() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aureom-test-'));
  const dbPath = path.join(dir, 'test.db');
  const db = getDb(dbPath);
  return {
    db,
    cleanup: () => {
      db.close();
      fs.rmSync(dir, { recursive: true, force: true });
    },
  };
}

const SAMPLE_CUSTOMER = {
  name: 'Clara Bennett',
  email: 'clara@example.co.uk',
  addressLine1: '14 Meadow Lane',
  addressLine2: 'Studio 3',
  city: 'Bristol',
  postcode: 'BS1 4TR',
  country: 'United Kingdom',
};

test('1. Product retrieval, filtering, sorting, and idempotent seeding', () => {
  const { db, cleanup } = withTempDb();
  try {
    // Seed twice to verify idempotency
    seedProducts(db);
    const all = listProducts(db);
    assert.equal(all.length, 8);

    const homeware = listProducts(db, { category: 'homeware' });
    assert.equal(homeware.length, 3);
    assert.ok(homeware.every((p) => p.category === 'homeware'));

    const searched = listProducts(db, { q: 'Field Notebook' });
    assert.equal(searched.length, 1);
    assert.equal(searched[0].slug, 'field-notebook');

    const sortedAsc = listProducts(db, { sort: 'price_asc' });
    for (let i = 1; i < sortedAsc.length; i++) {
      assert.ok(sortedAsc[i].pricePence >= sortedAsc[i - 1].pricePence);
    }

    const mug = getProductBySlug(db, 'studio-mug');
    assert.equal(mug.pricePence, 2200);
    assert.equal(mug.currency, 'GBP');

    assert.throws(() => getProductBySlug(db, 'non-existent-item'), (err: unknown) => {
      return err instanceof StoreError && err.statusCode === 404;
    });
  } finally {
    cleanup();
  }
});

test('2. Backend price calculation & order history snapshot preservation', async () => {
  const { db, cleanup } = withTempDb();
  try {
    const mug = getProductBySlug(db, 'studio-mug'); // 2200p
    const lamp = getProductBySlug(db, 'desk-lamp'); // 14500p

    // Tampered client price triggers 409 MATERIAL_CHANGE
    await assert.rejects(
      () =>
        createCheckoutOrder(db, {
          idempotencyKey: 'chk_tamper_price_01',
          customer: SAMPLE_CUSTOMER,
          items: [{ productId: mug.id, quantity: 2, expectedUnitPricePence: 100 }],
        }),
      (err: unknown) => err instanceof StoreError && err.statusCode === 409,
    );

    // Valid server-recalculated checkout: 2 * 2200 + 1 * 14500 = 18900p
    const created = await createCheckoutOrder(db, {
      idempotencyKey: 'chk_valid_price_01',
      customer: SAMPLE_CUSTOMER,
      items: [
        { productId: mug.id, quantity: 2 },
        { productId: lamp.id, quantity: 1 },
      ],
    });
    assert.equal(created.order.subtotalPence, 18900);
    assert.equal(created.order.shippingPence, 0);
    assert.equal(created.order.totalPence, 18900);
    assert.equal(created.order.paymentStatus, 'no_payment_taken');
    assert.equal(created.order.orderStatus, 'confirmed_demo');

    // Mutate product catalogue name & price after order placed
    db.prepare('UPDATE products SET name = ?, price_pence = ? WHERE id = ?').run(
      'Renamed Mug',
      9900,
      mug.id,
    );

    const retrieved = getOrderByReferenceAndToken(
      db,
      created.order.reference,
      created.accessToken,
    );
    const mugLine = retrieved.items.find((i) => i.productId === mug.id);
    assert.ok(mugLine);
    assert.equal(mugLine.productName, 'Studio Mug');
    assert.equal(mugLine.unitPricePence, 2200);
  } finally {
    cleanup();
  }
});

test('3. Invalid quantities rejected cleanly', async () => {
  const { db, cleanup } = withTempDb();
  try {
    const mug = getProductBySlug(db, 'studio-mug');
    for (const badQty of [0, -1, 100, 1.5]) {
      await assert.rejects(
        () =>
          createCheckoutOrder(db, {
            idempotencyKey: `chk_bad_qty_${String(badQty).replace('.', '_')}`,
            customer: SAMPLE_CUSTOMER,
            items: [{ productId: mug.id, quantity: badQty }],
          }),
        (err: unknown) =>
          err instanceof StoreError && err.statusCode === 400 && err.code === 'INVALID_QUANTITY',
      );
    }
  } finally {
    cleanup();
  }
});

test('4. Insufficient stock & 5. Atomic checkout rollback (no partial deduction)', async () => {
  const { db, cleanup } = withTempDb();
  try {
    const mug = getProductBySlug(db, 'studio-mug');
    const lamp = getProductBySlug(db, 'desk-lamp');

    await assert.rejects(
      () =>
        createCheckoutOrder(db, {
          idempotencyKey: 'chk_atomic_rollback_01',
          customer: SAMPLE_CUSTOMER,
          items: [
            { productId: mug.id, quantity: 3 },
            { productId: lamp.id, quantity: lamp.stockQuantity + 5 },
          ],
        }),
      (err: unknown) =>
        err instanceof StoreError && err.statusCode === 409 && err.code === 'MATERIAL_CHANGE',
    );

    // Confirm Studio Mug stock was rolled back completely
    const mugAfter = getProductBySlug(db, 'studio-mug');
    const lampAfter = getProductBySlug(db, 'desk-lamp');
    const ordersCount = db.prepare('SELECT COUNT(*) AS c FROM orders').get() as { c: number };
    assert.equal(mugAfter.stockQuantity, mug.stockQuantity);
    assert.equal(lampAfter.stockQuantity, lamp.stockQuantity);
    assert.equal(ordersCount.c, 0);
  } finally {
    cleanup();
  }
});

test('6. Duplicate checkout requests are idempotent and do not double-deduct stock', async () => {
  const { db, cleanup } = withTempDb();
  try {
    const tote = getProductBySlug(db, 'everyday-tote');
    const payload = {
      idempotencyKey: 'chk_idempotent_01',
      customer: SAMPLE_CUSTOMER,
      items: [{ productId: tote.id, quantity: 4 }],
    };

    const first = await createCheckoutOrder(db, payload);
    const second = await createCheckoutOrder(db, payload);

    assert.equal(first.replayed, false);
    assert.equal(second.replayed, true);
    assert.equal(first.order.reference, second.order.reference);
    assert.equal(first.accessToken, second.accessToken);

    const toteAfter = getProductBySlug(db, 'everyday-tote');
    assert.equal(toteAfter.stockQuantity, tote.stockQuantity - 4);

    // Reusing the same idempotency key with a different cart must fail with 409 conflict
    await assert.rejects(
      () =>
        createCheckoutOrder(db, {
          idempotencyKey: 'chk_idempotent_01',
          customer: SAMPLE_CUSTOMER,
          items: [{ productId: tote.id, quantity: 1 }],
        }),
      (err: unknown) =>
        err instanceof StoreError &&
        err.statusCode === 409 &&
        err.code === 'IDEMPOTENCY_KEY_CONFLICT',
    );
  } finally {
    cleanup();
  }
});

test('7. Competing orders cannot oversell remaining stock', async () => {
  const { db, cleanup } = withTempDb();
  try {
    const lamp = getProductBySlug(db, 'desk-lamp');
    db.prepare('UPDATE products SET stock_quantity = 5 WHERE id = ?').run(lamp.id);

    const results = await Promise.allSettled([
      createCheckoutOrder(db, {
        idempotencyKey: 'chk_compete_a',
        customer: SAMPLE_CUSTOMER,
        items: [{ productId: lamp.id, quantity: 4 }],
      }),
      createCheckoutOrder(db, {
        idempotencyKey: 'chk_compete_b',
        customer: SAMPLE_CUSTOMER,
        items: [{ productId: lamp.id, quantity: 4 }],
      }),
    ]);

    const fulfilled = results.filter((r) => r.status === 'fulfilled');
    const rejected = results.filter((r) => r.status === 'rejected');
    assert.equal(fulfilled.length, 1);
    assert.equal(rejected.length, 1);

    const lampAfter = getProductBySlug(db, 'desk-lamp');
    assert.equal(lampAfter.stockQuantity, 1);
  } finally {
    cleanup();
  }
});

test('8. Protected order access denies missing or invalid tokens', async () => {
  const { db, cleanup } = withTempDb();
  try {
    const notebook = getProductBySlug(db, 'field-notebook');
    const created = await createCheckoutOrder(db, {
      idempotencyKey: 'chk_protected_01',
      customer: SAMPLE_CUSTOMER,
      items: [{ productId: notebook.id, quantity: 1 }],
    });

    assert.throws(
      () => getOrderByReferenceAndToken(db, created.order.reference, null),
      (err: unknown) => err instanceof StoreError && err.statusCode === 401,
    );

    assert.throws(
      () => getOrderByReferenceAndToken(db, created.order.reference, 'wrong_token_value_1234567890'),
      (err: unknown) => err instanceof StoreError && err.statusCode === 403,
    );

    const ok = getOrderByReferenceAndToken(db, created.order.reference, created.accessToken);
    assert.equal(ok.reference, created.order.reference);
  } finally {
    cleanup();
  }
});

test('9. Cart validation to checkout to confirmation flow & discontinued item detection', async () => {
  const { db, cleanup } = withTempDb();
  try {
    const planner = getProductBySlug(db, 'weekly-planner');
    const towel = getProductBySlug(db, 'cotton-tea-towel');

    // Discontinue towel and change planner price
    db.prepare('UPDATE products SET is_active = 0 WHERE id = ?').run(towel.id);
    db.prepare('UPDATE products SET price_pence = 2100 WHERE id = ?').run(planner.id);

    const validationWithIssues = validateCart(db, [
      { productId: planner.id, quantity: 2, expectedUnitPricePence: 1900 },
      { productId: towel.id, quantity: 1, expectedUnitPricePence: 1800 },
    ]);
    assert.equal(validationWithIssues.hasMaterialChanges, true);
    assert.equal(validationWithIssues.canCheckout, false);
    assert.ok(validationWithIssues.materialChanges.some((c) => c.reason === 'discontinued'));
    assert.ok(validationWithIssues.materialChanges.some((c) => c.reason === 'price_changed'));

    // Customer removes discontinued item and acknowledges new price
    const cleanValidation = validateCart(db, [
      { productId: planner.id, quantity: 2, expectedUnitPricePence: 2100 },
    ]);
    assert.equal(cleanValidation.hasMaterialChanges, false);
    assert.equal(cleanValidation.canCheckout, true);
    assert.equal(cleanValidation.totalPence, 4200);

    const checkout = await createCheckoutOrder(db, {
      idempotencyKey: 'chk_end_to_end_01',
      customer: SAMPLE_CUSTOMER,
      items: [{ productId: planner.id, quantity: 2, expectedUnitPricePence: 2100 }],
      acknowledgedTotalPence: cleanValidation.totalPence,
    });
    assert.equal(checkout.order.statusBanner, 'Demo order saved — no payment taken.');

    const confirmed = getOrderByReferenceAndToken(
      db,
      checkout.order.reference,
      checkout.accessToken,
    );
    assert.equal(confirmed.totalPence, 4200);
    assert.equal(confirmed.items.length, 1);

    const health = checkHealth(db);
    assert.equal(health.status, 'ok');
    assert.equal(health.paymentMode, 'demo');
  } finally {
    cleanup();
  }
});
