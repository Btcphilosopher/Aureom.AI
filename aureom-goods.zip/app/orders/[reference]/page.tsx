import React, { Suspense } from 'react';
import { OrderConfirmationClient } from '@/components/OrderConfirmationClient';

export const dynamic = 'force-dynamic';

export default async function OrderConfirmationPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const { reference } = await params;

  return (
    <Suspense
      fallback={
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
          <div className="h-8 w-56 bg-[#E5DFD3]/60 rounded animate-pulse" />
        </div>
      }
    >
      <OrderConfirmationClient reference={reference} />
    </Suspense>
  );
}
