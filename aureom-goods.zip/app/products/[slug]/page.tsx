import React from 'react';
import Link from 'next/link';
import { getDb } from '@/lib/db';
import { getProductBySlug, StoreError } from '@/lib/store-service';
import { ProductDetailClient } from '@/components/ProductDetailClient';

export const dynamic = 'force-dynamic';

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const db = getDb();

  let product = null;
  try {
    product = getProductBySlug(db, slug);
  } catch (err) {
    if (!(err instanceof StoreError && (err.statusCode === 404 || err.statusCode === 400))) {
      throw err;
    }
  }

  if (!product) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-20 text-center">
        <h1 className="font-display text-3xl text-[#1E3A2B]">Product not found</h1>
        <p className="mt-3 text-sm text-[#556358]">
          This piece may have been discontinued or the link may be out of date.
        </p>
        <Link
          href="/shop"
          className="mt-6 min-h-[44px] px-6 py-2.5 inline-flex items-center rounded-md bg-[#1E3A2B] text-[#FAF8F4] text-sm font-medium"
        >
          Return to shop
        </Link>
      </div>
    );
  }

  return <ProductDetailClient product={product} />;
}
