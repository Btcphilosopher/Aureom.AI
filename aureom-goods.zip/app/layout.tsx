import type { Metadata } from 'next';
import { Fraunces, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';
import { CartProvider } from '@/components/CartProvider';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';

const fraunces = Fraunces({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-display',
  display: 'swap',
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Aureom Goods — Good things. For everyday living.',
  description:
    'Minimalist everyday homeware, stationery and accessories crafted in small runs for calm daily spaces.',
  openGraph: {
    title: 'Aureom Goods — Good things. For everyday living.',
    description:
      'Minimalist everyday homeware, stationery and accessories crafted in small runs for calm daily spaces.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aureom Goods — Good things. For everyday living.',
    description:
      'Minimalist everyday homeware, stationery and accessories crafted in small runs for calm daily spaces.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${plusJakarta.variable}`}>
      <body suppressHydrationWarning className="min-h-screen flex flex-col bg-[#FAF8F4] text-[#243028]">
        <CartProvider>
          <a
            href="#main-content"
            className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:bg-[#1E3A2B] focus:text-[#FAF8F4] focus:px-4 focus:py-2 focus:rounded-md focus:text-sm focus:font-medium"
          >
            Skip to main content
          </a>
          <SiteHeader />
          <main id="main-content" className="flex-1">
            {children}
          </main>
          <SiteFooter />
        </CartProvider>
      </body>
    </html>
  );
}
