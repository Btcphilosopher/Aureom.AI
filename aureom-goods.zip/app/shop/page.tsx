import React, { Suspense } from 'react';
import { getDb } from '@/lib/db';
import { listProducts } from '@/lib/store-service';
import { ShopClient } from '@/components/ShopClient';

export const dynamic = 'force-dynamic';

export default function ShopPage() {
  const db = getDb();
  const initialProducts = listProducts(db);

  return (
    <Suspense
      fallback={
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="h-10 w-56 bg-[#E5DFD3]/60 rounded animate-pulse" />
        </div>
      }
    >
      <ShopClient initialProducts={initialProducts} />
    </Suspense>
  );
}
