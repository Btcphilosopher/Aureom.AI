import { NextRequest, NextResponse } from 'next/server';
import { getCorsHeaders, handleApiError } from '@/lib/api-http';
import { getDb } from '@/lib/db';
import { checkHealth } from '@/lib/store-service';

export async function GET(req: NextRequest) {
  try {
    const db = getDb();
    const health = checkHealth(db);
    return NextResponse.json(health, { status: 200, headers: getCorsHeaders(req) });
  } catch (err) {
    return handleApiError(err, req);
  }
}
