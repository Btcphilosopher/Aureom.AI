import { NextRequest, NextResponse } from 'next/server';
import { getCorsHeaders, handleApiError, readBoundedJson } from '@/lib/api-http';
import { getDb } from '@/lib/db';
import { validateCart } from '@/lib/store-service';
import type { CartValidationRequestItem } from '@/lib/types';

export async function OPTIONS(req: NextRequest) {
  return new NextResponse(null, { status: 204, headers: getCorsHeaders(req) });
}

export async function POST(req: NextRequest) {
  try {
    const body = await readBoundedJson<{ items?: CartValidationRequestItem[] }>(req);
    const db = getDb();
    const result = validateCart(db, body.items ?? []);
    return NextResponse.json(result, { status: 200, headers: getCorsHeaders(req) });
  } catch (err) {
    return handleApiError(err, req);
  }
}
