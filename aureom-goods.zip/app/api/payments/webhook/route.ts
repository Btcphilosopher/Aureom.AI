import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { handleApiError } from '@/lib/api-http';
import { getDb } from '@/lib/db';
import { getPaymentProvider } from '@/lib/payment';
import { StoreError } from '@/lib/store-service';

/**
 * Optional hosted payment provider webhook endpoint.
 * - Verifies HMAC signature before processing.
 * - Deduplicates repeated webhook deliveries via payment_webhook_events.
 * - Updates payment_status/order_status separately from fulfilment_status.
 * - Releases reserved stock if a hosted session expires or is cancelled.
 */
export async function POST(req: NextRequest) {
  try {
    const provider = getPaymentProvider();
    if (provider.mode !== 'hosted') {
      throw new StoreError(
        400,
        'WEBHOOK_DISABLED_IN_DEMO',
        'Payment webhooks are inactive while AUREOM_PAYMENT_MODE is set to demo.',
      );
    }

    const rawBody = await req.text();
    const signature = req.headers.get('x-aureom-signature') ?? req.headers.get('stripe-signature');
    if (!provider.verifyWebhookSignature(rawBody, signature)) {
      throw new StoreError(401, 'INVALID_WEBHOOK_SIGNATURE', 'Webhook signature verification failed.');
    }

    const event = JSON.parse(rawBody) as {
      id?: string;
      type?: string;
      data?: { orderReference?: string; amountPence?: number };
    };

    const eventId = event.id ?? crypto.createHash('sha256').update(rawBody).digest('hex');
    const eventType = event.type ?? '';
    const orderReference = event.data?.orderReference;

    if (!orderReference) {
      throw new StoreError(400, 'MISSING_ORDER_REFERENCE', 'Webhook event missing orderReference.');
    }

    const db = getDb();
    db.exec('BEGIN IMMEDIATE');
    try {
      const existingEvent = db
        .prepare('SELECT id FROM payment_webhook_events WHERE event_id = ?')
        .get(eventId);
      if (existingEvent) {
        db.exec('COMMIT');
        return NextResponse.json({ received: true, deduplicated: true });
      }

      const order = db
        .prepare('SELECT id, total_pence, payment_status, order_status FROM orders WHERE reference = ?')
        .get(orderReference) as
        | { id: number; total_pence: number; payment_status: string; order_status: string }
        | undefined;

      if (!order) {
        throw new StoreError(404, 'ORDER_NOT_FOUND', 'Order referenced by webhook was not found.');
      }

      if (eventType === 'checkout.session.completed') {
        if (event.data?.amountPence !== undefined && event.data.amountPence !== order.total_pence) {
          throw new StoreError(400, 'AMOUNT_MISMATCH', 'Webhook amount does not match server order total.');
        }
        db.prepare(
          `UPDATE orders
           SET payment_status = 'paid', order_status = 'confirmed', updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
           WHERE id = ?`,
        ).run(order.id);
      } else if (
        eventType === 'checkout.session.expired' ||
        eventType === 'payment_intent.payment_failed'
      ) {
        const nextPayStatus = eventType === 'checkout.session.expired' ? 'expired' : 'failed';
        if (order.payment_status === 'pending') {
          const items = db
            .prepare('SELECT product_id, quantity FROM order_items WHERE order_id = ?')
            .all(order.id) as Array<{ product_id: number; quantity: number }>;
          const releaseStmt = db.prepare(
            'UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?',
          );
          for (const item of items) {
            releaseStmt.run(item.quantity, item.product_id);
          }
          db.prepare(
            `UPDATE orders
             SET payment_status = ?, order_status = 'cancelled', updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
             WHERE id = ?`,
          ).run(nextPayStatus, order.id);
        }
      }

      db.prepare(
        'INSERT INTO payment_webhook_events (provider, event_id, event_type) VALUES (?, ?, ?)',
      ).run('hosted', eventId, eventType);

      db.exec('COMMIT');
      return NextResponse.json({ received: true, deduplicated: false });
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  } catch (err) {
    return handleApiError(err, req);
  }
}
