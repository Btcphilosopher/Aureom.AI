import { NextRequest, NextResponse } from 'next/server';
import { getCorsHeaders, handleApiError, readBoundedJson } from '@/lib/api-http';
import { getDb } from '@/lib/db';
import { createCheckoutOrder } from '@/lib/store-service';
import type { CheckoutRequestPayload } from '@/lib/types';

export async function OPTIONS(req: NextRequest) {
  return new NextResponse(null, { status: 204, headers: getCorsHeaders(req) });
}

export async function POST(req: NextRequest) {
  try {
    const body = await readBoundedJson<CheckoutRequestPayload>(req);
    const headerIdem = req.headers.get('idempotency-key');
    const payload: CheckoutRequestPayload = {
      ...body,
      idempotencyKey: body.idempotencyKey || headerIdem || '',
    };

    const db = getDb();
    const origin =
      process.env.APP_URL ?? req.nextUrl.origin ?? 'http://localhost:3000';
    const result = await createCheckoutOrder(db, payload, origin);

    return NextResponse.json(result, {
      status: result.replayed ? 200 : 201,
      headers: getCorsHeaders(req),
    });
  } catch (err) {
    return handleApiError(err, req);
  }
}
