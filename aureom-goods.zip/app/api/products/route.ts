import { NextRequest, NextResponse } from 'next/server';
import { getCorsHeaders, handleApiError } from '@/lib/api-http';
import { getDb } from '@/lib/db';
import { listProducts, StoreError } from '@/lib/store-service';

const ALLOWED_SORTS = new Set(['featured', 'price_asc', 'price_desc', 'name_asc']);

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get('q') ?? undefined;
    const category = searchParams.get('category') ?? undefined;
    const sortRaw = searchParams.get('sort') ?? 'featured';
    const featuredOnly = searchParams.get('featured') === 'true';

    if (!ALLOWED_SORTS.has(sortRaw)) {
      throw new StoreError(400, 'INVALID_SORT', 'Unsupported sort parameter.');
    }

    const db = getDb();
    const products = listProducts(db, {
      q,
      category,
      sort: sortRaw as 'featured' | 'price_asc' | 'price_desc' | 'name_asc',
      featuredOnly,
    });

    return NextResponse.json(
      { products, count: products.length },
      { status: 200, headers: getCorsHeaders(req) },
    );
  } catch (err) {
    return handleApiError(err, req);
  }
}
