import { NextRequest, NextResponse } from 'next/server';
import { getCorsHeaders, handleApiError } from '@/lib/api-http';
import { getDb } from '@/lib/db';
import { getProductBySlug } from '@/lib/store-service';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await context.params;
    const db = getDb();
    const product = getProductBySlug(db, slug);
    return NextResponse.json({ product }, { status: 200, headers: getCorsHeaders(req) });
  } catch (err) {
    return handleApiError(err, req);
  }
}
