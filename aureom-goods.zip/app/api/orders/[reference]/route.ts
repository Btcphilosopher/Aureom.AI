import { NextRequest, NextResponse } from 'next/server';
import { getCorsHeaders, handleApiError } from '@/lib/api-http';
import { getDb } from '@/lib/db';
import { getOrderByReferenceAndToken } from '@/lib/store-service';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ reference: string }> },
) {
  try {
    const { reference } = await context.params;
    const { searchParams } = new URL(req.url);
    const authHeader = req.headers.get('authorization');
    const bearerToken =
      authHeader && authHeader.toLowerCase().startsWith('bearer ')
        ? authHeader.slice(7).trim()
        : null;
    const token = bearerToken || searchParams.get('token');

    const db = getDb();
    const order = getOrderByReferenceAndToken(db, reference, token);
    return NextResponse.json({ order }, { status: 200, headers: getCorsHeaders(req) });
  } catch (err) {
    return handleApiError(err, req);
  }
}
