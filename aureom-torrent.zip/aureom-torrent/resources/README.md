Application resources.

* `aureom-torrent.svg` – application icon (original artwork for this project, MIT licensed with the code).
* Theme arrow images are generated at run time into the data directory (`cache/theme`), so no
  binary assets are shipped.
