"""Test doubles for the feeds subsystem (never imported by the application)."""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass, field
from typing import Callable, Mapping

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.domain.magnet import parse_magnet
from aureom_torrent.domain.transfers import TorrentFile, TorrentMetadata, TransferRecord
from aureom_torrent.engine.interface import TorrentFormatError
from aureom_torrent.net.http import HttpFetchError, HttpPolicy
from aureom_torrent.services.interfaces import AddOutcome, AddRejected
from aureom_torrent.settings.models import AppSettings


class FakeClock:
    def __init__(self, start: float = 1_800_000_000.0):
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def monotonic(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t += seconds


def fake_torrent(name: str, size: int, v1: str | None = None, v2: str | None = None) -> bytes:
    """A stand-in for .torrent bytes that :class:`FakeTransferGateway` can "inspect"."""
    if v1 is None and v2 is None:
        import hashlib

        v1 = hashlib.sha1(f"{name}:{size}".encode()).hexdigest()
    return json.dumps({"fake_torrent": True, "name": name, "size": size, "v1": v1, "v2": v2}).encode()


@dataclass
class GatewayCall:
    kind: str  # torrent | magnet
    identity: TorrentIdentity
    save_path: str
    category: str
    paused: bool
    preview: bool
    source: str
    feed_entry_id: int | None
    transfer_id: str


class FakeTransferGateway:
    """Implements ``services.interfaces.TransferGateway`` in memory."""

    def __init__(self, save_path: str = "/downloads"):
        self.save_path = save_path
        self.records: dict[str, TransferRecord] = {}
        self.calls: list[GatewayCall] = []
        self.reject_with: AddRejected | None = None
        self.inspect_calls = 0
        self._n = 0
        self._lock = threading.Lock()

    # -- helpers for tests -----------------------------------------------------
    def seed_existing(self, identity: TorrentIdentity, *, name: str = "existing", manual_paused: bool = True,
                      save_path: str = "/elsewhere") -> TransferRecord:
        with self._lock:
            self._n += 1
            record = TransferRecord(id=f"t{self._n}", identity=identity, name=name, save_path=save_path,
                                    manual_paused=manual_paused, file_priorities=[0, 4])
            self.records[record.id] = record
            return record

    def remove(self, transfer_id: str) -> None:
        self.records.pop(transfer_id, None)

    # -- TransferGateway ---------------------------------------------------------
    def inspect_torrent(self, torrent_data: bytes) -> TorrentMetadata:
        self.inspect_calls += 1
        try:
            data = json.loads(torrent_data)
            if not data.get("fake_torrent"):
                raise ValueError
            identity = TorrentIdentity(data.get("v1"), data.get("v2"))
        except Exception as exc:
            raise TorrentFormatError("This is not a valid torrent file (fake).") from exc
        size = int(data["size"])
        return TorrentMetadata(identity=identity, name=data["name"], total_size=size, piece_length=16384,
                               num_pieces=max(1, size // 16384),
                               files=(TorrentFile(0, data["name"], size),))

    def find_duplicate(self, identity: TorrentIdentity) -> TransferRecord | None:
        for record in self.records.values():
            if record.identity.matches(identity):
                return record
        return None

    def _add(self, kind: str, identity: TorrentIdentity, name: str, *, save_path, category, paused, preview,
             source, feed_entry_id) -> AddOutcome:
        if self.reject_with is not None:
            raise self.reject_with
        existing = self.find_duplicate(identity)
        if existing is not None:
            return AddOutcome(existing.id, created=False, duplicate_of=existing.id, message="already present")
        with self._lock:
            self._n += 1
            record = TransferRecord(id=f"t{self._n}", identity=identity, name=name, save_path=save_path,
                                    category=category, source=source, manual_paused=paused, preview=preview,
                                    feed_entry_id=feed_entry_id)
            self.records[record.id] = record
            self.calls.append(GatewayCall(kind, identity, save_path, category, paused, preview, source,
                                          feed_entry_id, record.id))
        return AddOutcome(record.id, created=True)

    def add_torrent_data(self, torrent_data: bytes, *, save_path: str, category: str = "", paused: bool = False,
                         file_priorities=None, source: str = "file", feed_entry_id: int | None = None,
                         manifest_id: str | None = None) -> AddOutcome:
        try:
            meta = self.inspect_torrent(torrent_data)
        except TorrentFormatError as exc:
            raise AddRejected(str(exc), reason="invalid") from exc
        return self._add("torrent", meta.identity, meta.name, save_path=save_path, category=category,
                         paused=paused, preview=False, source=source, feed_entry_id=feed_entry_id)

    def add_magnet(self, uri: str, *, save_path: str, category: str = "", paused: bool = False,
                   preview: bool = False, source: str = "magnet", feed_entry_id: int | None = None) -> AddOutcome:
        link = parse_magnet(uri)
        return self._add("magnet", link.identity, link.display_name or link.identity.short(), save_path=save_path,
                         category=category, paused=paused, preview=preview, source=source,
                         feed_entry_id=feed_entry_id)

    def default_save_path(self) -> str:
        return self.save_path


@dataclass(frozen=True)
class FakeResult:
    """Duck-types ``net.http.HttpResult`` and additionally carries per-hop redirect statuses."""

    status: int = 200
    body: bytes = b""
    headers: Mapping[str, str] = field(default_factory=dict)
    url: str = ""
    redirects: tuple[str, ...] = ()
    redirect_statuses: tuple[int, ...] = ()

    def header(self, name: str) -> str | None:
        return {k.lower(): v for k, v in self.headers.items()}.get(name.lower())


@dataclass
class FetchRecord:
    url: str
    headers: dict[str, str]
    policy: HttpPolicy | None


Responder = Callable[[FetchRecord], FakeResult]


class FakeFetcher:
    """A scripted ``net.http.Fetcher``.

    ``routes[url]`` is a ``FakeResult``, an ``HttpFetchError`` to raise, a callable
    ``(FetchRecord) -> FakeResult``, or a list of those consumed one per request
    (the last one repeats).
    """

    def __init__(self) -> None:
        self.routes: dict[str, object] = {}
        self.requests: list[FetchRecord] = []

    def set(self, url: str, response: object) -> None:
        self.routes[url] = response

    def count(self, url: str) -> int:
        return sum(1 for r in self.requests if r.url == url)

    def fetch(self, url: str, *, method: str = "GET", headers: Mapping[str, str] | None = None,
              body: bytes | None = None, policy: HttpPolicy | None = None):
        record = FetchRecord(url, dict(headers or {}), policy)
        self.requests.append(record)
        if url not in self.routes:
            return FakeResult(status=404, url=url)
        route = self.routes[url]
        if isinstance(route, list):
            route = route.pop(0) if len(route) > 1 else route[0]
        if callable(route):
            route = route(record)
        if isinstance(route, HttpFetchError):
            raise route
        assert isinstance(route, FakeResult)
        if not route.url:
            route = FakeResult(route.status, route.body, route.headers, url, route.redirects,
                               route.redirect_statuses)
        return route


def make_settings(**feed_overrides) -> Callable[[], AppSettings]:
    settings = AppSettings()
    for name, value in feed_overrides.items():
        setattr(settings.feeds, name, value)
    return lambda: settings


# ---------------------------------------------------------------------------- fixtures
from pathlib import Path  # noqa: E402

FIXTURES = Path(__file__).resolve().parent.parent / "fixtures" / "feeds"
DEFAULT_BASE = "https://feeds.example.org"


def fixture_bytes(name: str, base: str = DEFAULT_BASE) -> bytes:
    """A feed fixture with its ``{BASE}`` placeholder filled in."""
    return (FIXTURES / name).read_bytes().replace(b"{BASE}", base.encode())


def rss_document(items: list[dict], *, title: str = "Generated Feed", base: str = DEFAULT_BASE) -> bytes:
    """Build a small RSS 2.0 document. Item keys: title, guid, link, torrent, magnet, size, date."""
    from xml.sax.saxutils import escape, quoteattr

    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<rss version="2.0" xmlns:torrent="http://xmlns.ezrss.it/0.1/"><channel>',
             f"<title>{escape(title)}</title><link>{base}/</link><description>generated</description>"]
    for item in items:
        parts.append("<item>")
        parts.append(f"<title>{escape(item.get('title', ''))}</title>")
        if item.get("guid"):
            parts.append(f'<guid isPermaLink="false">{escape(item["guid"])}</guid>')
        if item.get("link"):
            parts.append(f"<link>{escape(item['link'])}</link>")
        if item.get("date"):
            parts.append(f"<pubDate>{escape(item['date'])}</pubDate>")
        if item.get("torrent"):
            parts.append(f'<enclosure url={quoteattr(item["torrent"])} type="application/x-bittorrent" '
                         f'length="{item.get("length", 1000)}"/>')
        if item.get("magnet"):
            parts.append(f'<enclosure url={quoteattr(item["magnet"])} type="application/x-bittorrent" length="0"/>')
        if item.get("size") is not None:
            parts.append(f"<torrent:contentLength>{item['size']}</torrent:contentLength>")
        parts.append("</item>")
    parts.append("</channel></rss>")
    return "\n".join(parts).encode()
