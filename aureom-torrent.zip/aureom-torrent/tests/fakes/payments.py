"""Test doubles for the payments subsystem (never used by the application itself)."""

from __future__ import annotations

import hashlib
import itertools
import threading
from dataclasses import dataclass, field
from typing import Callable

import bolt11
from bolt11 import Bolt11, MilliSatoshi
from bolt11.models.tags import Tags

from aureom_torrent.payments.interface import (BackendInfo, BackendRejected, BackendUnavailable, CreatedInvoice,
                                               DecodedInvoice, IncomingStatus, InvoiceLookup, OutgoingStatus,
                                               PaymentAlreadyKnown, PaymentNotFound, PaymentOutcomeUnknown,
                                               PaymentResult)
from aureom_torrent.settings.models import AppSettings

# Throwaway secp256k1 key used only to sign test invoices. It controls no funds.
TEST_NODE_PRIVKEY = "e126f68f7eafcc8b74f54d269fe206be715000f94dac067d1c04a8ca3b2db734"
TEST_NODE_PUBKEY = "03e7156ae33b0a208d0744199163177e909e80176e55d97a2f221ede0f934dd9ad"
OTHER_NODE_PRIVKEY = "41" * 32

_CURRENCY = {"mainnet": "bc", "testnet": "tb", "signet": "tbs", "regtest": "bcrt"}
_counter = itertools.count(1)


class FakeClock:
    def __init__(self, now: float = 1_800_000_000.0):
        self._now = float(now)

    def now(self) -> float:
        return self._now

    def monotonic(self) -> float:
        return self._now

    def advance(self, seconds: float) -> None:
        self._now += seconds


def make_invoice(*, network: str = "regtest", amount_msat: int | None = 21_000, description: str = "tip",
                 expiry: int = 3600, created_at: int = 1_800_000_000, description_hash: str | None = None,
                 privkey: str = TEST_NODE_PRIVKEY, preimage: bytes | None = None) -> tuple[str, str]:
    """Return ``(bolt11, payment_hash_hex)`` for a freshly signed test invoice."""
    preimage = preimage or hashlib.sha256(f"preimage-{next(_counter)}".encode()).digest()
    payment_hash = hashlib.sha256(preimage).hexdigest()
    tags: dict = {"payment_hash": payment_hash, "payment_secret": "11" * 32, "expire_time": expiry}
    if description_hash:
        tags["description_hash"] = description_hash
    else:
        tags["description"] = description
    inv = Bolt11(currency=_CURRENCY[network], date=created_at, tags=Tags.from_dict(tags),
                 amount_msat=MilliSatoshi(amount_msat) if amount_msat else None)
    return bolt11.encode(inv, privkey), payment_hash


def settings_factory(**payment_overrides) -> Callable[[], AppSettings]:
    settings = AppSettings()
    settings.payments.backend = "lnd_rest"
    settings.payments.expected_network = "regtest"
    for key, value in payment_overrides.items():
        setattr(settings.payments, key, value)
    settings.validate()
    return lambda: settings


@dataclass
class Call:
    method: str
    args: dict = field(default_factory=dict)


class FakeLightningBackend:
    """Scriptable in-memory backend.

    ``pay_script`` is a list of behaviours consumed one per ``pay_invoice`` call:

    * ``"succeed"``   – settle, fee ``fee_msat``
    * ``"fail:<REASON>"`` – definitive failure (e.g. ``fail:FAILURE_REASON_NO_ROUTE``)
    * ``"reject"``    – ``BackendRejected`` (nothing started)
    * ``"unreachable"`` – ``BackendUnavailable`` (not sent)
    * ``"timeout"``   – ``PaymentOutcomeUnknown``; the payment is recorded according to
      ``timeout_then`` ("in_flight", "succeeded", "failed", or "lost" = backend never saw it)
    * ``"in_flight"`` – returns IN_FLIGHT; settle later with :meth:`settle_outgoing`
    * ``"crash"``     – raises RuntimeError (unexpected error)

    An empty script means ``"succeed"``.  Every call is recorded in ``calls``.
    """

    name = "fake"

    def __init__(self, *, network: str = "regtest", pubkey: str = "02" + "ab" * 32, alias: str = "fake-node"):
        self.network = network
        self.pubkey = pubkey
        self.alias = alias
        self.reachable = True
        self.pay_script: list[str] = []
        self.timeout_then = "in_flight"
        self.fee_msat = 1_000
        self.calls: list[Call] = []
        self.outgoing: dict[str, PaymentResult] = {}  # payment hash -> last known state at the "node"
        self.invoices: dict[str, InvoiceLookup] = {}
        self.on_pay: Callable[[str], None] | None = None  # hook executed inside pay_invoice
        self._lock = threading.Lock()

    # -- helpers for tests ------------------------------------------------------
    def count(self, method: str) -> int:
        return sum(1 for c in self.calls if c.method == method)

    def settle_outgoing(self, payment_hash: str, *, fee_msat: int | None = None) -> None:
        self.outgoing[payment_hash] = PaymentResult(payment_hash, OutgoingStatus.SUCCEEDED,
                                                    fee_msat=self.fee_msat if fee_msat is None else fee_msat)

    def fail_outgoing(self, payment_hash: str, reason: str = "FAILURE_REASON_NO_ROUTE") -> None:
        self.outgoing[payment_hash] = PaymentResult(payment_hash, OutgoingStatus.FAILED, failure_reason=reason)

    def settle_invoice(self, payment_hash: str, *, at: int = 0) -> None:
        old = self.invoices[payment_hash]
        self.invoices[payment_hash] = InvoiceLookup(payment_hash, IncomingStatus.SETTLED,
                                                    amount_paid_msat=old.value_msat or 0,
                                                    value_msat=old.value_msat, settled_at=at or None,
                                                    expires_at=old.expires_at)

    def cancel_invoice(self, payment_hash: str) -> None:
        old = self.invoices[payment_hash]
        self.invoices[payment_hash] = InvoiceLookup(payment_hash, IncomingStatus.CANCELED,
                                                    value_msat=old.value_msat, expires_at=old.expires_at)

    def _record(self, method: str, **args) -> None:
        with self._lock:
            self.calls.append(Call(method, args))
        if not self.reachable:
            raise BackendUnavailable("fake backend is unreachable")

    # -- LightningBackend -------------------------------------------------------
    def get_info(self) -> BackendInfo:
        self._record("get_info")
        return BackendInfo(backend=self.name, alias=self.alias, pubkey=self.pubkey, network=self.network,
                           version="0.0-fake", synced=True, active_channels=1)

    def decode_invoice(self, payment_request: str) -> DecodedInvoice:
        self._record("decode_invoice")
        inv = bolt11.decode(payment_request)
        return DecodedInvoice(destination=inv.payee, payment_hash=inv.payment_hash,
                              amount_msat=int(inv.amount_msat) if inv.amount_msat else None,
                              timestamp=inv.date, expiry_s=inv.expiry, description=inv.description or "",
                              description_hash=inv.description_hash or "")

    def pay_invoice(self, payment_request: str, *, amount_msat: int | None, fee_limit_msat: int,
                    timeout_s: int) -> PaymentResult:
        inv = bolt11.decode(payment_request)
        payment_hash = inv.payment_hash
        self._record("pay_invoice", payment_hash=payment_hash, amount_msat=amount_msat,
                     fee_limit_msat=fee_limit_msat, timeout_s=timeout_s)
        if self.on_pay:
            self.on_pay(payment_hash)
        if payment_hash in self.outgoing:
            raise PaymentAlreadyKnown("payment already exists")
        behaviour = self.pay_script.pop(0) if self.pay_script else "succeed"
        value = amount_msat if amount_msat is not None else int(inv.amount_msat)
        if behaviour == "succeed":
            fee = min(self.fee_msat, fee_limit_msat)
            self.outgoing[payment_hash] = PaymentResult(payment_hash, OutgoingStatus.SUCCEEDED, fee_msat=fee,
                                                        amount_msat=value)
            return self.outgoing[payment_hash]
        if behaviour.startswith("fail"):
            reason = behaviour.partition(":")[2] or "FAILURE_REASON_NO_ROUTE"
            self.outgoing[payment_hash] = PaymentResult(payment_hash, OutgoingStatus.FAILED, failure_reason=reason)
            return self.outgoing[payment_hash]
        if behaviour == "reject":
            raise BackendRejected("invoice rejected by fake backend", code="400")
        if behaviour == "unreachable":
            raise BackendUnavailable("could not connect; nothing was sent")
        if behaviour == "in_flight":
            self.outgoing[payment_hash] = PaymentResult(payment_hash, OutgoingStatus.IN_FLIGHT, amount_msat=value)
            return self.outgoing[payment_hash]
        if behaviour == "timeout":
            if self.timeout_then == "in_flight":
                self.outgoing[payment_hash] = PaymentResult(payment_hash, OutgoingStatus.IN_FLIGHT)
            elif self.timeout_then == "succeeded":
                self.settle_outgoing(payment_hash)
            elif self.timeout_then == "failed":
                self.fail_outgoing(payment_hash)
            raise PaymentOutcomeUnknown("timed out waiting for the backend")
        if behaviour == "crash":
            raise RuntimeError("boom")
        raise AssertionError(f"unknown fake behaviour {behaviour!r}")

    def track_payment(self, payment_hash: str) -> PaymentResult:
        self._record("track_payment", payment_hash=payment_hash)
        if payment_hash not in self.outgoing:
            raise PaymentNotFound("no such payment")
        return self.outgoing[payment_hash]

    def create_invoice(self, amount_msat: int, *, memo: str, expiry_s: int) -> CreatedInvoice:
        self._record("create_invoice", amount_msat=amount_msat, memo=memo, expiry_s=expiry_s)
        now = int(self.clock.now()) if hasattr(self, "clock") else 1_800_000_000
        pr, payment_hash = make_invoice(network=self.network, amount_msat=amount_msat, description=memo or "invoice",
                                        expiry=expiry_s, created_at=now)
        self.invoices[payment_hash] = InvoiceLookup(payment_hash, IncomingStatus.OPEN, value_msat=amount_msat,
                                                    expires_at=now + expiry_s)
        return CreatedInvoice(payment_hash=payment_hash, payment_request=pr)

    def lookup_invoice(self, payment_hash: str) -> InvoiceLookup:
        self._record("lookup_invoice", payment_hash=payment_hash)
        if payment_hash not in self.invoices:
            raise PaymentNotFound("no such invoice")
        return self.invoices[payment_hash]
