"""Test doubles for the publishing subsystem. Test-only: never imported by the application."""

from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.domain.transfers import TorrentMetadata, TransferRecord
from aureom_torrent.engine.interface import CreatedTorrent, CreationCancelled
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec, LibtorrentCreator
from aureom_torrent.net.http import HttpFetchError, HttpPolicy, HttpResult
from aureom_torrent.persistence.database import Database
from aureom_torrent.publishing.models import PublishDraft, PublishOperationResult
from aureom_torrent.publishing.service import PublishService
from aureom_torrent.services.interfaces import AddOutcome, AddRejected
from aureom_torrent.settings.models import AppSettings
from aureom_torrent.settings.secrets import MemorySecretStore


class FakeClock:
    def __init__(self, start: float = 1_800_000_000.0):
        self.t = start

    def now(self) -> float:
        return self.t

    def monotonic(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t += seconds


@dataclass
class GatewayCall:
    torrent_data: bytes
    save_path: str
    category: str
    paused: bool
    source: str
    manifest_id: str | None


class FakeTransferGateway:
    """Records "start seeding" requests. ``mode``: ok | duplicate | reject | crash."""

    def __init__(self, mode: str = "ok"):
        self.mode = mode
        self.calls: list[GatewayCall] = []
        self._codec = LibtorrentCodec()

    def inspect_torrent(self, torrent_data: bytes) -> TorrentMetadata:
        return self._codec.inspect(torrent_data)

    def find_duplicate(self, identity: TorrentIdentity) -> TransferRecord | None:
        return None

    def add_torrent_data(self, torrent_data: bytes, *, save_path: str, category: str = "", paused: bool = False,
                         file_priorities: list[int] | None = None, source: str = "file",
                         feed_entry_id: int | None = None, manifest_id: str | None = None) -> AddOutcome:
        self.calls.append(GatewayCall(torrent_data, save_path, category, paused, source, manifest_id))
        if self.mode == "reject":
            raise AddRejected("The destination already belongs to another transfer.", reason="conflict")
        if self.mode == "crash":
            raise RuntimeError("engine exploded")
        if self.mode == "duplicate":
            return AddOutcome(transfer_id="existing-1", created=False, duplicate_of="existing-1")
        return AddOutcome(transfer_id=f"transfer-{len(self.calls)}", created=True)

    def add_magnet(self, uri: str, **kwargs: Any) -> AddOutcome:  # pragma: no cover - not used by publishing
        raise AssertionError("publishing never adds magnets")

    def default_save_path(self) -> str:
        return ""


class FakePublishAdapter:
    """Scripted adapter. ``behaviour`` maps an artifact-name suffix to ok | fail | raise.

    ``on_publish`` is called before each artifact; a test can use it to flip a
    cancel flag, simulating a destination that hangs until the user stops the run.
    """

    def __init__(self, behaviour: Mapping[str, str] | None = None,
                 on_publish: Callable[[str], None] | None = None, secret: str = ""):
        self.behaviour = dict(behaviour or {})
        self.on_publish = on_publish
        self.published: list[tuple[str, int, str]] = []
        self.secret = secret

    def describe(self) -> str:
        return "fake destination"

    def publish(self, artifact_name: str, content: bytes, content_type: str) -> PublishOperationResult:
        if self.on_publish:
            self.on_publish(artifact_name)
        mode = "ok"
        for suffix, value in self.behaviour.items():
            if artifact_name.endswith(suffix):
                mode = value
        if mode == "raise":
            raise ConnectionError("socket closed")
        if mode == "fail":
            return PublishOperationResult("publish", self.describe(), False,
                                          f"refused {artifact_name} token={self.secret}" if self.secret
                                          else f"refused {artifact_name}", 0)
        self.published.append((artifact_name, len(content), content_type))
        return PublishOperationResult("publish", self.describe(), True, f"stored {artifact_name}", 0)


@dataclass
class FetchCall:
    url: str
    method: str
    headers: dict[str, str]
    body: bytes | None
    policy: HttpPolicy | None


class FakeFetcher:
    """Returns queued results (HttpResult or an exception to raise) and records every request."""

    def __init__(self, *responses: HttpResult | Exception):
        self.responses = list(responses)
        self.calls: list[FetchCall] = []

    def fetch(self, url: str, *, method: str = "GET", headers: Mapping[str, str] | None = None,
              body: bytes | None = None, policy: HttpPolicy | None = None) -> HttpResult:
        self.calls.append(FetchCall(url, method, dict(headers or {}), body, policy))
        if not self.responses:
            raise HttpFetchError("no response queued")
        nxt = self.responses.pop(0) if len(self.responses) > 1 else self.responses[0]
        if isinstance(nxt, Exception):
            raise nxt
        return nxt


def http_result(status: int = 200, body: bytes = b"", url: str = "https://upload.example/x") -> HttpResult:
    return HttpResult(status=status, headers={}, body=body, url=url)


class CancellingCreator:
    """Wraps the real creator and trips a cancel flag after ``after`` pieces have been hashed."""

    def __init__(self, after: int = 1):
        self.after = after
        self.flag = threading.Event()
        self._real = LibtorrentCreator()

    def cancelled(self) -> bool:
        return self.flag.is_set()

    def create(self, request, progress, cancelled) -> CreatedTorrent:
        def watch(done: int, total: int) -> None:
            if done >= self.after:
                self.flag.set()
            progress(done, total)

        return self._real.create(request, watch, cancelled)


class ExplodingCreator:
    def __init__(self, exc: Exception):
        self.exc = exc

    def create(self, request, progress, cancelled) -> CreatedTorrent:
        raise self.exc


def make_tree(base, name: str = "Open Data Pack") -> str:
    """A small synthetic folder (deterministic contents). Returns its absolute path."""
    root = os.path.join(str(base), name)
    os.makedirs(os.path.join(root, "docs"), exist_ok=True)
    with open(os.path.join(root, "readme.txt"), "wb") as fh:
        fh.write(b"Synthetic demonstration data. Public domain (CC0-1.0).\n" * 40)
    with open(os.path.join(root, "data.bin"), "wb") as fh:
        fh.write(bytes(range(256)) * 600)  # 153 600 bytes
    with open(os.path.join(root, "docs", "notes.md"), "wb") as fh:
        fh.write(b"# Notes\n\nNothing to see here.\n" * 100)
    return root


TREE_FILES = ["data.bin", "docs/notes.md", "readme.txt"]


def make_draft(root: str, out_dir, **overrides: Any) -> PublishDraft:
    draft = PublishDraft(
        source_path=root, included_files=list(TREE_FILES), format="hybrid",
        output_torrent_path=os.path.join(str(out_dir), "out.torrent"), start_seeding=False)
    for key, value in overrides.items():
        setattr(draft, key, value)
    return draft


@dataclass
class Harness:
    service: PublishService
    db: Database
    gateway: FakeTransferGateway
    secrets: MemorySecretStore
    settings: AppSettings
    clock: FakeClock
    exports_dir: str
    extra: dict[str, Any] = field(default_factory=dict)


def make_service(tmp_path, *, db: Database | None = None, gateway: FakeTransferGateway | None = None,
                 creator=None, fetcher=None, adapter_factory=None, settings: AppSettings | None = None,
                 secrets: MemorySecretStore | None = None, with_gateway: bool = True) -> Harness:
    db = db or Database(None)
    gateway = gateway or FakeTransferGateway()
    secrets = secrets or MemorySecretStore()
    settings = settings or AppSettings()
    clock = FakeClock()
    exports = os.path.join(str(tmp_path), "exports")
    service = PublishService(db, creator or LibtorrentCreator(), LibtorrentCodec(),
                             gateway if with_gateway else None, secrets, fetcher, settings, clock, exports,
                             adapter_factory=adapter_factory)
    return Harness(service, db, gateway, secrets, settings, clock, exports)
