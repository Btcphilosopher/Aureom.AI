"""Test doubles for the engine boundary. Used only by tests – never by the application."""

from __future__ import annotations

from typing import Any

from aureom_torrent.domain.transfers import EnginePhase, TorrentStatus
from aureom_torrent.engine import commands as c
from aureom_torrent.engine import events as e
from aureom_torrent.engine.interface import EngineCapabilities


class FakeClock:
    def __init__(self, now: float = 1_800_000_000.0):
        self._now = now
        self._mono = 1000.0

    def now(self) -> float:
        return self._now

    def monotonic(self) -> float:
        return self._mono

    def advance(self, seconds: float) -> None:
        self._now += seconds
        self._mono += seconds

    def set(self, now: float) -> None:
        self._mono += max(0.0, now - self._now)
        self._now = now


class FakeEngine:
    """Records commands and lets a test deliver events when it chooses (i.e. arbitrarily delayed).

    With ``auto=True`` the obvious acknowledgements are queued for the next
    :meth:`deliver` call: ``TorrentAdded`` for adds, ``TorrentRemoved`` for
    removals, pause/resume acknowledgements.
    """

    def __init__(self, *, auto: bool = True, version: str = "fake-1.0"):
        self.auto = auto
        self.version = version
        self.commands: list[Any] = []
        self.pending: list[Any] = []
        self.sink = None
        self.started = False
        self.shutdown_timeout: float | None = None
        self.shutdown_result = e.ShutdownReport(clean=True, resume_saved=0)
        self.fail_moves = False
        self.loaded: dict[str, c.AddTorrent] = {}

    # -- TorrentEngine --------------------------------------------------
    def capabilities(self) -> EngineCapabilities:
        return EngineCapabilities(engine="fake", version=self.version)

    def start(self, settings: c.EngineSettings, sink) -> None:
        self.settings = settings
        self.sink = sink
        self.started = True
        sink(e.EngineStarted("fake", self.version))

    def submit(self, command: Any) -> None:
        self.commands.append(command)
        if not self.auto:
            return
        if isinstance(command, c.AddTorrent):
            self.loaded[command.transfer_id] = command
        elif isinstance(command, c.RemoveTorrent):
            self.loaded.pop(command.transfer_id, None)
            self.pending.append(e.TorrentRemoved(command.transfer_id))
        elif isinstance(command, c.MoveStorage):
            if self.fail_moves:
                self.pending.append(e.StorageMoveFailed(command.transfer_id, "Permission denied"))
            else:
                self.pending.append(e.StorageMoved(command.transfer_id, command.new_path))
        elif isinstance(command, c.ConfirmPreview):
            if self.fail_moves:
                self.pending.append(e.StorageMoveFailed(command.transfer_id, "Permission denied"))
            else:
                self.pending.append(e.StorageMoved(command.transfer_id, command.save_path))

    def shutdown(self, timeout: float) -> e.ShutdownReport:
        self.shutdown_timeout = timeout
        self.started = False
        if self.sink:
            self.sink(e.EngineStopped(self.shutdown_result))
        return self.shutdown_result

    # -- test helpers ---------------------------------------------------
    def deliver(self, *events: Any) -> None:
        """Deliver queued acknowledgements, then the given events, in order."""
        queued, self.pending = self.pending, []
        for event in (*queued, *events):
            self.sink(event)

    def of(self, kind: type) -> list[Any]:
        return [cmd for cmd in self.commands if isinstance(cmd, kind)]

    def last(self, kind: type) -> Any:
        found = self.of(kind)
        return found[-1] if found else None

    def clear(self) -> None:
        self.commands.clear()


def status(transfer_id: str, **overrides: Any) -> TorrentStatus:
    """A downloading status with sensible defaults; override any field."""
    base = dict(transfer_id=transfer_id, phase=EnginePhase.DOWNLOADING, has_metadata=True, total=1000,
                total_wanted=1000, wanted_done=0, auto_managed=True)
    base.update(overrides)
    return TorrentStatus(**base)
