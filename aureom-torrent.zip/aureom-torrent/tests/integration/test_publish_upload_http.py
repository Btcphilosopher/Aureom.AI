"""HTTPS upload adapter against a real local HTTP server through the real policy-checked fetcher.

Loopback and plain http are allowed *explicitly* in these tests' policies; the
default publishing policy refuses both.
"""

from __future__ import annotations

import http.server
import threading
import time

import pytest

from aureom_torrent.net.http import HttpFetcher, HttpPolicy
from aureom_torrent.publishing.adapters.https_upload import HttpsUploadAdapter
from aureom_torrent.publishing.models import JobState, PublishDestination
from aureom_torrent.settings.models import AppSettings
from tests.fakes.publishing import make_draft, make_service, make_tree

pytestmark = pytest.mark.integration

TOKEN = "upl_SECRET_TOKEN_0123456789"


class UploadHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    store: dict[str, tuple[bytes, str]] = {}

    def log_message(self, *args):  # keep test output quiet
        pass

    def _reply(self, status: int, body: bytes = b"", headers: dict[str, str] | None = None) -> None:
        self.send_response(status)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_PUT(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length)
        if self.path.startswith("/slow/"):
            time.sleep(1.5)
            return self._reply(201)
        if self.path.startswith("/moved/"):
            return self._reply(307, headers={"Location": self.path.replace("/moved/", "/drop/")})
        if self.path.startswith("/chatty/"):
            return self._reply(201, b"x" * (200 * 1024))
        if self.headers.get("Authorization") != f"Bearer {TOKEN}":
            return self._reply(401, b"bad token")
        self.store[self.path] = (body, self.headers.get("Content-Type", ""))
        return self._reply(201, b"created")


@pytest.fixture()
def server():
    UploadHandler.store = {}
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), UploadHandler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{httpd.server_address[1]}"
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=5)


LOCAL_TEST_POLICY = HttpPolicy(timeout_s=5, max_bytes=1024 * 1024, allow_http=True, allow_loopback=True)


def adapter(base: str, *, policy: HttpPolicy = LOCAL_TEST_POLICY, token: str | None = TOKEN) -> HttpsUploadAdapter:
    return HttpsUploadAdapter(base, fetcher=HttpFetcher(policy), policy=policy, token=token)


def test_upload_success(server):
    res = adapter(server + "/drop").publish("page.html", b"<html>ok</html>", "text/html; charset=utf-8")
    assert res.ok and "HTTP 201" in res.message and "does not prove it is publicly reachable" in res.message
    assert UploadHandler.store["/drop/page.html"] == (b"<html>ok</html>", "text/html; charset=utf-8")
    assert TOKEN not in res.message and TOKEN not in res.destination


def test_upload_rejected_credentials(server):
    res = adapter(server + "/drop", token="wrong").publish("page.html", b"x", "text/html")
    assert not res.ok and "rejected the credentials (HTTP 401)" in res.message
    assert UploadHandler.store == {}
    res = adapter(server + "/drop", token=None).publish("page.html", b"x", "text/html")
    assert not res.ok and "401" in res.message


def test_upload_timeout_is_reported(server):
    policy = HttpPolicy(timeout_s=0.4, allow_http=True, allow_loopback=True)
    started = time.monotonic()
    res = adapter(server + "/slow", policy=policy).publish("big.bin", b"x" * 10, "application/octet-stream")
    assert not res.ok and "Timed out" in res.message
    assert time.monotonic() - started < 1.4


def test_oversized_response_is_cut_off(server):
    res = adapter(server + "/chatty").publish("a.txt", b"x", "text/plain")
    assert not res.ok and "larger than" in res.message


def test_redirects_are_not_followed_for_uploads(server):
    res = adapter(server + "/moved").publish("a.txt", b"x", "text/plain")
    assert not res.ok and "redirect" in res.message
    assert UploadHandler.store == {}  # the body was never re-sent to the redirect target


def test_default_policy_refuses_http_and_loopback(server):
    default = HttpPolicy.from_settings(AppSettings().publishing_network)
    assert default.allow_http is False and default.allow_loopback is False and default.allow_private is False
    res = adapter(server + "/drop", policy=default).publish("a.txt", b"x", "text/plain")
    assert not res.ok and "https://" in res.message
    https_loopback = "https://127.0.0.1:" + server.rsplit(":", 1)[1] + "/drop"
    res = adapter(https_loopback, policy=default).publish("a.txt", b"x", "text/plain")
    assert not res.ok and "loopback" in res.message
    http_only = HttpPolicy(allow_http=True)  # http allowed, loopback still not
    res = adapter(server + "/drop", policy=http_only).publish("a.txt", b"x", "text/plain")
    assert not res.ok and "loopback" in res.message
    assert UploadHandler.store == {}


def test_end_to_end_publish_through_the_service(server, tmp_path):
    settings = AppSettings()
    settings.publishing_network.allow_http = True  # explicit opt-in for this local test
    settings.publishing_network.allow_loopback = True
    policy = HttpPolicy.from_settings(settings.publishing_network)
    h = make_service(tmp_path, settings=settings, fetcher=HttpFetcher(policy))
    job = h.service.start_job(make_draft(make_tree(tmp_path / "src"), tmp_path))
    assert job.state is JobState.COMPLETED
    dest = h.service.save_destination(
        PublishDestination("", "https_upload", "Local test server", {"base_url": server + "/drop"}), token=TOKEN)
    results = h.service.publish(job.id, dest.id, ["torrent", "page", "atom"],
                                public_torrent_url="https://example.org/Open-Data-Pack.torrent")
    assert all(r.ok for r in results), [r.message for r in results]
    assert sorted(UploadHandler.store) == ["/drop/Open-Data-Pack.atom.xml", "/drop/Open-Data-Pack.html",
                                           "/drop/Open-Data-Pack.torrent"]
    assert UploadHandler.store["/drop/Open-Data-Pack.torrent"][0] == open(job.torrent_path, "rb").read()
    assert UploadHandler.store["/drop/Open-Data-Pack.torrent"][1] == "application/x-bittorrent"
    # with the wrong token every operation fails and is recorded as failed
    h.service.save_destination(dest, token="wrong")
    failed = h.service.publish(job.id, dest.id, ["page"])
    assert [r.ok for r in failed] == [False] and "401" in failed[0].message
    ops = [o for o in h.service.get_job(job.id).operations if o.operation.startswith("publish:")]
    assert [o.ok for o in ops] == [True, True, True, False]
    assert TOKEN not in " ".join(o.message + o.destination for o in ops)
