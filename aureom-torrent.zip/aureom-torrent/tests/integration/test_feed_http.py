"""Feed refresh over real HTTP: a local ``http.server`` on 127.0.0.1 and the real ``HttpFetcher``.

No public network access: the server binds to loopback and the feed network
policy is told explicitly that loopback is allowed for these tests.
"""

from __future__ import annotations

import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from aureom_torrent.feeds.models import STATUS_ADDED, STATUS_NEW, STATUS_REVIEW, FeedRule
from aureom_torrent.feeds.service import FeedService
from aureom_torrent.net.http import HttpFetcher, HttpPolicy, HttpResult
from aureom_torrent.persistence.database import Database
from tests.fakes.feeds import (FIXTURES, FakeClock, FakeTransferGateway, fake_torrent, fixture_bytes,
                               make_settings, rss_document)

pytestmark = pytest.mark.integration

LAST_MODIFIED = "Mon, 23 Nov 2026 09:30:00 GMT"


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):  # keep test output quiet
        pass

    def do_GET(self):
        server: "FeedTestServer" = self.server.owner  # type: ignore[attr-defined]
        path = self.path.split("?", 1)[0]
        server.requests.append((path, {k.lower(): v for k, v in self.headers.items()}))
        route = server.routes.get(path)
        if route is None:
            self._send(404, b"not found")
            return
        route(self)

    def _send(self, status: int, body: bytes = b"", headers: dict | None = None, *, length: bool = True):
        self.send_response(status)
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        if length:
            self.send_header("Content-Length", str(len(body)))
        else:
            self.send_header("Connection", "close")
        self.end_headers()
        if body:
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass  # the client stopped reading (size limit)
        if not length:
            self.close_connection = True


class FeedTestServer:
    def __init__(self):
        self.routes: dict = {}
        self.requests: list[tuple[str, dict]] = []
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self.httpd.daemon_threads = True
        self.httpd.owner = self  # type: ignore[attr-defined]
        self.base = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        self.thread = threading.Thread(target=self.httpd.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
        self.thread.start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(5)

    # -- route helpers ---------------------------------------------------------
    def static(self, path: str, body: bytes, status: int = 200, headers: dict | None = None, *, length=True):
        self.routes[path] = lambda h: h._send(status, body, {"Content-Type": "application/xml", **(headers or {})},
                                              length=length)

    def conditional(self, path: str, body: bytes, etag: str):
        def route(h: _Handler):
            if h.headers.get("If-None-Match") == etag and h.headers.get("If-Modified-Since") == LAST_MODIFIED:
                h._send(304, b"", {"ETag": etag})
            else:
                h._send(200, body, {"ETag": etag, "Last-Modified": LAST_MODIFIED,
                                    "Content-Type": "application/rss+xml"})
        self.routes[path] = route

    def redirect(self, path: str, target: str, status: int = 302):
        self.routes[path] = lambda h: h._send(status, b"", {"Location": target})

    def count(self, path: str) -> int:
        return sum(1 for p, _ in self.requests if p == path)


@pytest.fixture
def server():
    srv = FeedTestServer()
    yield srv
    srv.close()


class Env:
    def __init__(self, *, allow_loopback: bool = True):
        self.settings = make_settings()
        net = self.settings().feeds_network
        net.allow_loopback = allow_loopback
        net.timeout_s = 5
        self.gateway = FakeTransferGateway()
        self.clock = FakeClock()
        self.fetcher = HttpFetcher(HttpPolicy())  # the service passes the per-request policy from settings
        self.service = FeedService(Database(None), self.fetcher, self.gateway, self.settings, self.clock)


@pytest.fixture
def env():
    return Env()


def test_rss_and_atom_fixtures_end_to_end(server, env):
    server.static("/rss.xml", fixture_bytes("rss_sample.xml", server.base))
    server.static("/atom.xml", fixture_bytes("atom_sample.xml", server.base))
    rss = env.service.add_feed(server.base + "/rss.xml")
    atom = env.service.add_feed(server.base + "/atom.xml", folder="Fonts")

    results = env.service.refresh_due()
    assert [r.ok for r in results] == [True, True] and all(r.baseline for r in results)
    assert {r.feed_id: r.new_entries for r in results} == {rss.id: 4, atom.id: 2}

    feeds = {f.id: f for f in env.service.list_feeds()}
    assert feeds[rss.id].title == "Aureom Open Data Releases" and feeds[rss.id].site_url == server.base + "/"
    assert feeds[atom.id].title == "Libre Typeface Builds"
    torrent_urls = sorted(e.torrent_url for e in env.service.list_entries(link_type="torrent"))
    assert torrent_urls == sorted([
        server.base + "/torrents/field-recordings-3.torrent",
        server.base + "/torrents/meridian-sans-2.4.torrent",  # relative enclosure resolved against the feed URL
        server.base + "/torrents/meridian-sans-2.3-src.torrent",
    ])
    user_agent = server.requests[0][1]["user-agent"]
    assert user_agent.startswith("AureomTorrent/")
    assert "cookie" not in server.requests[0][1]


def test_conditional_requests_and_304(server, env):
    server.conditional("/feed.xml", fixture_bytes("rss_sample.xml", server.base), etag='"rev-7"')
    feed = env.service.add_feed(server.base + "/feed.xml")

    first = env.service.refresh_feed(feed.id)
    assert first.ok and not first.not_modified and first.status_code == 200
    assert "if-none-match" not in server.requests[0][1] and "if-modified-since" not in server.requests[0][1]

    second = env.service.refresh_feed(feed.id)
    assert second.ok and second.not_modified and second.status_code == 304 and second.new_entries == 0
    sent = server.requests[1][1]
    assert sent["if-none-match"] == '"rev-7"' and sent["if-modified-since"] == LAST_MODIFIED
    stored = env.service.get_feed(feed.id)
    assert stored.last_status == "not_modified" and stored.entry_count == 4 and stored.fail_count == 0

    # the document changes: a new validator, and the new item is picked up
    items = [{"title": "Brand new (CC0)", "guid": "new-1", "link": server.base + "/n/1",
              "magnet": "magnet:?xt=urn:btih:" + "12" * 20}]
    server.conditional("/feed.xml", rss_document(items, base=server.base), etag='"rev-8"')
    third = env.service.refresh_feed(feed.id)
    assert third.ok and not third.not_modified and third.new_entries == 1
    assert env.service.get_feed(feed.id).etag == '"rev-8"'


def test_oversized_responses_are_rejected(server, env):
    env.settings().feeds_network.max_response_bytes = 4096
    big = rss_document([{"title": "x" * 300, "guid": f"g{i}", "link": f"{server.base}/i/{i}"} for i in range(400)],
                       base=server.base)
    assert len(big) > 100_000
    server.static("/declared.xml", big)  # honest Content-Length
    server.static("/streamed.xml", big, length=False)  # no Content-Length: the limit is enforced while reading
    for path in ("/declared.xml", "/streamed.xml"):
        feed = env.service.add_feed(server.base + path)
        result = env.service.refresh_feed(feed.id)
        assert not result.ok and "larger than the 4,096-byte limit" in result.error, path
        stored = env.service.get_feed(feed.id)
        assert stored.entry_count == 0 and stored.fail_count == 1 and not stored.baseline_done


def test_redirects_are_followed_within_limits(server, env):
    server.static("/feed.xml", fixture_bytes("rss_sample.xml", server.base))
    server.redirect("/old.xml", "/hop.xml")
    server.redirect("/hop.xml", server.base + "/feed.xml")
    feed = env.service.add_feed(server.base + "/old.xml")
    result = env.service.refresh_feed(feed.id)
    assert result.ok and result.new_entries == 4
    assert env.service.get_feed(feed.id).url == server.base + "/old.xml"  # temporary redirects do not move it

    server.redirect("/loop.xml", "/loop.xml")
    looping = env.service.add_feed(server.base + "/loop.xml")
    result = env.service.refresh_feed(looping.id)
    assert not result.ok and "Too many redirects" in result.error
    assert server.count("/loop.xml") == env.settings().feeds_network.max_redirects + 1

    env.settings().feeds_network.max_redirects = 0
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and "Too many redirects" in result.error


def test_redirect_to_a_non_http_scheme_is_refused(server, env):
    server.redirect("/evil.xml", "file:///etc/passwd")
    feed = env.service.add_feed(server.base + "/evil.xml")
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and "Only http and https" in result.error


@pytest.mark.skipif("redirect_statuses" not in HttpResult.__dataclass_fields__,
                    reason="net.http.HttpResult does not report per-hop redirect statuses in this build")
def test_permanent_redirect_moves_the_subscription(server, env):
    server.static("/new.xml", fixture_bytes("rss_sample.xml", server.base))
    server.redirect("/old.xml", "/new.xml", status=301)
    feed = env.service.add_feed(server.base + "/old.xml")
    assert env.service.refresh_feed(feed.id).ok
    assert env.service.get_feed(feed.id).url == server.base + "/new.xml"


def test_malformed_content_then_recovery(server, env):
    server.static("/feed.xml", (FIXTURES / "malformed_not_a_feed.html").read_bytes(),
                  headers={"Content-Type": "text/html", "ETag": '"html"'})
    feed = env.service.add_feed(server.base + "/feed.xml")
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and "not an RSS or Atom feed" in result.error
    stored = env.service.get_feed(feed.id)
    assert stored.etag == "" and stored.fail_count == 1 and stored.next_check == int(env.clock.now()) + 300

    server.static("/feed.xml", fixture_bytes("entity_bomb.xml"))
    started = time.monotonic()
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and "entities" in result.error and time.monotonic() - started < 2

    server.static("/feed.xml", fixture_bytes("truncated.xml", server.base))
    result = env.service.refresh_feed(feed.id)
    assert result.ok and result.baseline and result.new_entries >= 1 and result.warning
    assert env.service.get_feed(feed.id).fail_count == 0


def test_http_error_statuses(server, env):
    feed = env.service.add_feed(server.base + "/missing.xml")
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and result.status_code == 404 and "HTTP 404" in result.error

    server.static("/busy.xml", b"slow down", status=503, headers={"Retry-After": "900"})
    busy = env.service.add_feed(server.base + "/busy.xml")
    result = env.service.refresh_feed(busy.id)
    assert not result.ok and result.status_code == 503
    assert result.next_check == int(env.clock.now()) + 900


def test_timeouts_are_reported(server, env):
    release = threading.Event()

    def slow(h: _Handler):
        release.wait(3)
        h._send(200, b"<rss/>")

    server.routes["/slow.xml"] = slow
    env.settings().feeds_network.timeout_s = 0.3
    feed = env.service.add_feed(server.base + "/slow.xml")
    started = time.monotonic()
    result = env.service.refresh_feed(feed.id)
    release.set()
    assert not result.ok and "Timed out" in result.error
    assert time.monotonic() - started < 2.5
    assert "?" not in result.error


def test_loopback_is_refused_unless_explicitly_allowed(server):
    env = Env(allow_loopback=False)
    server.static("/feed.xml", fixture_bytes("rss_sample.xml", server.base))
    feed = env.service.add_feed(server.base + "/feed.xml")
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and "loopback" in result.error
    assert server.requests == []  # nothing was sent


def test_rule_limits_end_to_end(server, env):
    """Rules + size verification + per-refresh limit over real HTTP, adding through the gateway."""
    feed = env.service.add_feed(server.base + "/feed.xml", category="Open Data")
    env.service.set_auto_download(feed.id, True)
    env.service.save_rule(FeedRule(feed_id=feed.id, name="small CC0 packs", include=["cc0"], exclude=["beta"],
                                   max_size=1_000_000, max_per_refresh=2, daily_count_budget=10,
                                   destination="/data/open", add_paused=True))

    def item(i, title):
        return {"title": title, "guid": f"pack-{i}", "link": f"{server.base}/packs/{i}",
                "torrent": f"{server.base}/torrents/pack-{i}.torrent", "size": 1}

    server.static("/feed.xml", rss_document([item(0, "Pack 0 (CC0)")], base=server.base))
    assert env.service.refresh_feed(feed.id).baseline
    assert env.gateway.calls == []

    sizes = {1: 200_000, 2: 300_000, 3: 50_000_000, 4: 400_000, 5: 100_000, 6: 100_000}
    for i, size in sizes.items():
        server.static(f"/torrents/pack-{i}.torrent", fake_torrent(f"pack-{i}", size),
                      headers={"Content-Type": "application/x-bittorrent"})
    titles = {1: "Pack 1 (CC0)", 2: "Pack 2 (CC0)", 3: "Pack 3 huge (CC0)", 4: "Pack 4 (CC0)",
              5: "Pack 5 beta (CC0)", 6: "Pack 6 (CC BY)"}
    server.static("/feed.xml", rss_document([item(i, titles[i]) for i in range(6, 0, -1)] + [item(0, "Pack 0 (CC0)")],
                                            base=server.base))
    result = env.service.refresh_feed(feed.id)
    assert result.ok and result.new_entries == 6
    assert result.auto_added == 2 and result.queued_for_review == 1

    assert [(c.kind, c.save_path, c.category, c.paused, c.source) for c in env.gateway.calls] == \
        [("torrent", "/data/open", "Open Data", True, "feed")] * 2
    statuses = {e.title: e for e in env.service.list_entries(feed_id=feed.id)}
    assert statuses["Pack 1 (CC0)"].status == STATUS_ADDED and statuses["Pack 2 (CC0)"].status == STATUS_ADDED
    assert statuses["Pack 1 (CC0)"].size == 200_000 and statuses["Pack 1 (CC0)"].size_trusted
    # too large according to the real metadata (the feed claimed 1 byte)
    assert statuses["Pack 3 huge (CC0)"].status == STATUS_NEW and statuses["Pack 3 huge (CC0)"].size == 50_000_000
    # matched, but the per-refresh limit was already used up
    assert statuses["Pack 4 (CC0)"].status == STATUS_REVIEW
    assert "per-refresh limit" in statuses["Pack 4 (CC0)"].status_reason
    # excluded / not included: untouched, and their torrent files were never requested
    assert statuses["Pack 5 beta (CC0)"].status == STATUS_NEW and statuses["Pack 6 (CC BY)"].status == STATUS_NEW
    assert server.count("/torrents/pack-5.torrent") == 0 and server.count("/torrents/pack-6.torrent") == 0
    assert statuses["Pack 0 (CC0)"].status == "baseline" and server.count("/torrents/pack-0.torrent") == 0

    # the same document again changes nothing
    again = env.service.refresh_feed(feed.id)
    assert again.new_entries == 0 and again.auto_added == 0 and len(env.gateway.calls) == 2

    # approving the queued item is an explicit action and is not subject to the limit
    outcome = env.service.approve_review(statuses["Pack 4 (CC0)"].id)
    assert outcome.created and len(env.gateway.calls) == 3


def test_oversized_torrent_download_goes_to_review(server, env):
    env.settings().feeds_network.max_response_bytes = 2048
    feed = env.service.add_feed(server.base + "/feed.xml", download_existing=True)
    env.service.set_auto_download(feed.id, True)
    env.service.save_rule(FeedRule(feed_id=feed.id, name="all"))
    server.static("/feed.xml", rss_document([{"title": "Big torrent file", "guid": "b",
                                              "torrent": server.base + "/torrents/big.torrent"}], base=server.base))
    server.static("/torrents/big.torrent", b"d" + b"x" * 50_000)
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 0 and result.queued_for_review == 1 and env.gateway.calls == []
    assert "larger than" in env.service.list_review()[0].status_reason
