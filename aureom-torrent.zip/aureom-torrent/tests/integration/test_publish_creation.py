"""Real torrent creation through the wizard backend (libtorrent creator, synthetic files).

v1, v2 and hybrid are exercised as separate cases.
"""

from __future__ import annotations

import hashlib
import os

import feedparser
import libtorrent as lt
import pytest

from aureom_torrent.domain.magnet import parse_magnet
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec
from aureom_torrent.publishing.manifests import SignatureStatus, parse_manifest, verify_signature
from aureom_torrent.publishing.models import JobState, PublisherInfo
from tests.fakes.publishing import TREE_FILES, make_draft, make_service, make_tree

pytestmark = pytest.mark.integration

PUBLISHER = PublisherInfo(name="Example Open Data Collective", description="Synthetic demo data.",
                          website="https://example.org/data", feed_url="https://example.org/data/feed.xml",
                          bitcoin_address="bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4",
                          lightning_address="tips@example.org", licence="CC0-1.0")
TRACKERS = "udp://tracker.example.org:6969/announce\nhttps://tracker.example.org/announce\n\nhttp://backup.example.net/announce"
codec = LibtorrentCodec()


def create(tmp_path, fmt, **overrides):
    tree = make_tree(tmp_path / "src")
    h = make_service(tmp_path)
    options = dict(format=fmt, trackers_text=TRACKERS, web_seeds=["https://seed.example.org/files/"],
                   publisher=PUBLISHER, comment="Synthetic demonstration torrent")
    options.update(overrides)
    job = h.service.start_job(make_draft(tree, tmp_path, **options))
    assert job.state is JobState.COMPLETED, job.error
    data = open(job.torrent_path, "rb").read()
    return h, job, codec.inspect(data), data, tree


def check_common(job, meta, tree, data):
    assert meta.name == "Open Data Pack"
    assert sorted(f.path for f in meta.real_files) == [f"Open Data Pack/{rel}" for rel in TREE_FILES]
    assert meta.total_size == sum(os.path.getsize(os.path.join(tree, *rel.split("/"))) for rel in TREE_FILES)
    assert meta.trackers == (("udp://tracker.example.org:6969/announce", 0),
                             ("https://tracker.example.org/announce", 0),
                             ("http://backup.example.net/announce", 1))
    assert meta.web_seeds == ("https://seed.example.org/files/",)
    assert meta.private is False and meta.path_problems == ()
    # comment / creator are read from the raw file (independent of how the codec surfaces them)
    top = lt.bdecode(data)
    assert top[b"comment"] == b"Synthetic demonstration torrent"
    assert top[b"created by"] == b"AUREOM TORRENT"
    assert isinstance(top[b"creation date"], int)
    assert meta.identity == job.identity
    link = parse_magnet(job.magnet)
    assert link.identity == job.identity and link.display_name == "Open Data Pack"
    assert link.trackers[0] == "udp://tracker.example.org:6969/announce" and len(link.trackers) == 3
    assert link.web_seeds == ("https://seed.example.org/files/",)
    embedded = parse_manifest(meta.embedded_manifest)
    assert embedded.publisher == PUBLISHER.name and embedded.identity is None  # bound by position, not by hash
    assert embedded.lightning_address == "tips@example.org" and embedded.licence == "CC0-1.0"


def test_create_v1(tmp_path):
    h, job, meta, data, tree = create(tmp_path, "v1")
    assert job.format == "v1" and meta.identity.kind == "v1"
    assert meta.identity.v1 and meta.identity.v2 is None
    assert job.magnet.startswith(f"magnet:?xt=urn:btih:{meta.identity.v1}") and "btmh" not in job.magnet
    assert not any(f.pad for f in meta.files)
    check_common(job, meta, tree, data)


def test_create_v2(tmp_path):
    h, job, meta, data, tree = create(tmp_path, "v2")
    assert job.format == "v2" and meta.identity.kind == "v2"
    assert meta.identity.v1 is None and len(meta.identity.v2) == 64
    assert job.magnet.startswith(f"magnet:?xt=urn:btmh:1220{meta.identity.v2}") and "btih" not in job.magnet
    check_common(job, meta, tree, data)


def test_create_hybrid(tmp_path):
    h, job, meta, data, tree = create(tmp_path, "hybrid")
    assert job.format == "hybrid" and meta.identity.kind == "hybrid"
    assert f"xt=urn:btih:{meta.identity.v1}" in job.magnet and f"xt=urn:btmh:1220{meta.identity.v2}" in job.magnet
    check_common(job, meta, tree, data)
    # hybrid torrents pad files for v1 piece alignment; pad files are not real content
    assert job.file_count == 3 and job.total_size == meta.total_size


@pytest.mark.parametrize("fmt", ["v1", "v2", "hybrid"])
def test_private_flag_and_custom_piece_length(tmp_path, fmt):
    h, job, meta, data, tree = create(tmp_path, fmt, private=True, piece_length=32 * 1024,
                                      trackers_text="https://private.example.org/announce/PASSKEY")
    assert meta.private is True and job.private is True
    assert meta.piece_length == 32 * 1024 == job.piece_length
    assert meta.num_pieces >= -(-meta.total_size // (32 * 1024))
    assert meta.identity.kind == fmt


def test_automatic_piece_length_and_identity_changes_with_embedded_manifest(tmp_path):
    _, with_manifest, meta_a, _, _ = create(tmp_path / "a", "hybrid")
    _, without, meta_b, _, _ = create(tmp_path / "b", "hybrid", publisher=None)
    assert meta_a.piece_length == 16 * 1024  # automatic for ~160 kB
    assert meta_b.embedded_manifest == b""
    # the manifest lives inside the info dictionary, so it is covered by (and changes) the info-hash
    assert with_manifest.identity != without.identity
    _, unembedded, meta_c, _, _ = create(tmp_path / "c", "hybrid", embed_manifest=False)
    assert meta_c.embedded_manifest == b"" and unembedded.identity == without.identity


def test_signed_embedded_manifest_survives_the_round_trip(tmp_path):
    h, job, meta, data, tree = create(tmp_path, "hybrid", sign_manifest=True)
    embedded = parse_manifest(meta.embedded_manifest)
    assert verify_signature(embedded) is SignatureStatus.VALID
    assert embedded.signature.public_key == h.service.signing_public_key()
    tampered = meta.embedded_manifest.replace(b"tips@example.org", b"evil@example.org")
    assert verify_signature(parse_manifest(tampered)) is SignatureStatus.INVALID


def test_subset_of_files_and_single_file(tmp_path):
    h, job, meta, data, tree = create(tmp_path, "hybrid", included_files=["data.bin", "docs/notes.md"],
                                      publisher=None)
    assert sorted(f.path for f in meta.real_files) == ["Open Data Pack/data.bin", "Open Data Pack/docs/notes.md"]
    single = os.path.join(tree, "data.bin")
    job2 = h.service.start_job(make_draft(single, tmp_path, included_files=["data.bin"],
                                          output_torrent_path=str(tmp_path / "single.torrent")))
    assert job2.state is JobState.COMPLETED
    meta2 = codec.inspect(open(job2.torrent_path, "rb").read())
    assert [f.path for f in meta2.real_files] == ["data.bin"] and meta2.name == "data.bin"


def test_renamed_torrent_when_not_seeding_in_place(tmp_path):
    h, job, meta, data, tree = create(tmp_path, "v1", name="Renamed Pack", publisher=None)
    assert meta.name == "Renamed Pack" and job.name == "Renamed Pack"
    assert all(f.path.startswith("Renamed Pack/") for f in meta.real_files)


def test_creation_is_deterministic_for_identical_content(tmp_path):
    """Same files, same options, no timestamps inside the info dict -> same identity."""
    _, a, _, _, _ = create(tmp_path / "a", "hybrid", publisher=None)
    _, b, _, _, _ = create(tmp_path / "b", "hybrid", publisher=None)
    assert a.identity == b.identity


def test_symlinks_are_never_followed_or_included(tmp_path):
    tree = make_tree(tmp_path / "src")
    secret_dir = tmp_path / "private"
    secret_dir.mkdir()
    (secret_dir / "secret.txt").write_text("TOP-SECRET-CONTENT")
    os.symlink(secret_dir / "secret.txt", os.path.join(tree, "leak.txt"))  # file link pointing outside
    os.symlink(secret_dir, os.path.join(tree, "leakdir"))  # directory link pointing outside
    os.symlink(os.path.join(tree, "data.bin"), os.path.join(tree, "alias.bin"))  # link inside the root
    with open(os.path.join(tree, ".DS_Store"), "wb") as fh:
        fh.write(b"junk")
    h = make_service(tmp_path)
    scan = h.service.scan(tree)
    assert [f.relative for f in scan.files] == TREE_FILES
    reasons = dict(scan.skipped)
    assert reasons["leak.txt"] == "symbolic link pointing outside the selected folder"
    assert reasons["leakdir"] == "symbolic link pointing outside the selected folder"
    assert reasons["alias.bin"] == "symbolic link (links are not followed)"
    assert reasons[".DS_Store"] == "operating-system metadata file"
    job = h.service.start_job(make_draft(tree, tmp_path, included_files=[f.relative for f in scan.files]))
    assert job.state is JobState.COMPLETED
    data = open(job.torrent_path, "rb").read()
    meta = codec.inspect(data)
    paths = [f.path for f in meta.files]
    assert not any("leak" in p or "secret" in p or "alias" in p or "DS_Store" in p for p in paths)
    assert b"secret" not in data and b"leak" not in data
    assert meta.total_size == sum(f.size for f in scan.files)


def test_a_symlinked_selection_is_refused(tmp_path):
    from aureom_torrent.publishing.models import PublishError

    tree = make_tree(tmp_path / "src")
    link = tmp_path / "pack-link"
    os.symlink(tree, link)
    h = make_service(tmp_path)
    with pytest.raises(PublishError):
        h.service.scan(str(link))
    with pytest.raises(PublishError):
        h.service.start_job(make_draft(str(link), tmp_path))
    with pytest.raises(PublishError):
        h.service.scan(str(tmp_path / "does-not-exist"))


def test_exported_atom_entry_matches_the_created_torrent(tmp_path):
    h, job, meta, data, tree = create(tmp_path, "hybrid")
    (atom,) = h.service.build_artifacts(job.id, ["atom"], public_torrent_url="https://example.org/data/pack.torrent")
    parsed = feedparser.parse(atom.content)
    assert not parsed.bozo
    (entry,) = parsed.entries
    assert entry.link == job.magnet and parse_magnet(entry.link).identity == meta.identity
    assert entry.torrent_infohash == meta.identity.v1
    assert int(entry.torrent_contentlength) == meta.total_size
    (enclosure,) = [l for l in entry.links if l.rel == "enclosure"]
    assert enclosure.href == "https://example.org/data/pack.torrent" and int(enclosure.length) == len(data)
    assert entry.author == PUBLISHER.name


def test_piece_hashes_cover_the_real_file_content(tmp_path):
    """Changing a byte of the source changes the identity: the torrent really describes these files."""
    _, original, _, _, _ = create(tmp_path / "a", "v1", publisher=None)
    tree_b = make_tree(tmp_path / "b" / "src")
    with open(os.path.join(tree_b, "data.bin"), "r+b") as fh:
        fh.seek(1000)
        fh.write(b"\xff")
    h = make_service(tmp_path / "b")
    changed = h.service.start_job(make_draft(tree_b, tmp_path / "b", format="v1"))
    assert changed.state is JobState.COMPLETED and changed.identity != original.identity
    assert hashlib.sha1(b"x").hexdigest() != changed.v1  # sanity: a real 40-hex digest
    assert len(changed.v1) == 40
