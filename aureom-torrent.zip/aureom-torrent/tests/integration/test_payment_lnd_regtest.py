"""Optional end-to-end test against real LND nodes on Bitcoin **regtest** (no real funds).

Skipped unless the environment describes a running regtest setup (see
``scripts/lightning_regtest_setup.sh`` and docs/payments.md):

Payer node ("alice", needs an outbound channel to the payee):
    AUREOM_LND_URL            e.g. https://127.0.0.1:8081
    AUREOM_LND_MACAROON_HEX   hex of a macaroon with info:read invoices:read invoices:write
                              offchain:read offchain:write
    AUREOM_LND_TLS_CERT       path to alice's tls.cert

Invoice source — either a second node ("bob"):
    AUREOM_LND_PAYEE_URL, AUREOM_LND_PAYEE_MACAROON_HEX, AUREOM_LND_PAYEE_TLS_CERT
or a ready-made regtest invoice from the payee:
    AUREOM_LND_TEST_INVOICE   (BOLT11, lnbcrt…, 1 000 sat suggested)

This test was NOT executed in the build environment of this release (the LND
and bitcoind binaries could not be downloaded there).  It is the check that
confirms the three API details the adapter handles defensively: the URL-safe
base64 path for TrackPaymentV2, the NotFound response for an unknown hash, and
the AlreadyExists response for a repeated payment.
"""

import os
import time

import pytest

from aureom_torrent.net.http import HttpPolicy
from aureom_torrent.payments.adapters.lnd_rest import LndRestBackend
from aureom_torrent.payments.interface import (IncomingStatus, OutgoingStatus, PaymentAlreadyKnown,
                                               PaymentNotFound)
from aureom_torrent.payments.models import DuplicatePayment, PaymentState
from aureom_torrent.payments.service import PaymentService
from aureom_torrent.persistence.database import Database
from aureom_torrent.settings.secrets import SECRET_LND_MACAROON, MemorySecretStore
from aureom_torrent.util.clock import SystemClock
from tests.fakes.payments import settings_factory

pytestmark = pytest.mark.lightning_regtest

_PAYER = ("AUREOM_LND_URL", "AUREOM_LND_MACAROON_HEX", "AUREOM_LND_TLS_CERT")
_PAYEE = ("AUREOM_LND_PAYEE_URL", "AUREOM_LND_PAYEE_MACAROON_HEX", "AUREOM_LND_PAYEE_TLS_CERT")
_missing = [name for name in _PAYER if not os.environ.get(name)]
_has_payee = all(os.environ.get(name) for name in _PAYEE)
_has_invoice = bool(os.environ.get("AUREOM_LND_TEST_INVOICE"))

if _missing:
    pytestmark = [pytestmark, pytest.mark.skip(
        reason="LND regtest environment not configured (missing " + ", ".join(_missing) + "); "
               "integration check NOT executed")]

POLICY = HttpPolicy(timeout_s=20, max_bytes=1024 * 1024, max_redirects=0, allow_http=False,
                    allow_loopback=True, allow_private=True)


def _backend(url_var, macaroon_var, cert_var) -> LndRestBackend:
    secrets = MemorySecretStore()  # the macaroon stays in memory for the duration of the test
    secrets.set(SECRET_LND_MACAROON, os.environ[macaroon_var])
    return LndRestBackend(os.environ[url_var], secrets=secrets, policy=POLICY,
                          tls_cert_path=os.environ[cert_var])


@pytest.fixture(scope="module")
def payer():
    return _backend(*_PAYER)


@pytest.fixture(scope="module")
def payee():
    if not _has_payee:
        pytest.skip("payee node not configured (AUREOM_LND_PAYEE_*); check NOT executed")
    return _backend(*_PAYEE)


@pytest.fixture
def service(payer, tmp_path):
    return PaymentService(Database(tmp_path / "regtest.sqlite3"), lambda: payer, settings_factory(), SystemClock())


def test_node_is_on_regtest(payer):
    info = payer.get_info()
    assert info.network == "regtest", "refusing to run payment tests against a non-regtest node"
    assert info.pubkey and info.synced


def test_incoming_invoice_round_trip(service, payer):
    intent = service.create_incoming_invoice(2_000_000, memo="aureom regtest", expiry_s=600)
    assert intent.state is PaymentState.PENDING and intent.invoice.startswith("lnbcrt")
    lookup = payer.lookup_invoice(intent.payment_hash)
    assert lookup.status is IncomingStatus.OPEN and lookup.value_msat == 2_000_000
    decoded = payer.decode_invoice(intent.invoice)
    assert decoded.payment_hash == intent.payment_hash and decoded.amount_msat == 2_000_000
    assert service.refresh(intent.id).state is PaymentState.PENDING  # unpaid: must not be reported settled


def test_unknown_payment_hash_is_not_found(payer):
    with pytest.raises(PaymentNotFound):
        payer.track_payment("ab" * 32)
    with pytest.raises(PaymentNotFound):
        payer.lookup_invoice("ab" * 32)


def test_pay_invoice_end_to_end(service, payer, request):
    assert payer.get_info().network == "regtest"
    payee_backend = request.getfixturevalue("payee") if _has_payee else None
    if payee_backend is not None:
        created = payee_backend.create_invoice(1_000_000, memo="aureom regtest tip", expiry_s=600)
        invoice, payment_hash = created.payment_request, created.payment_hash
    elif _has_invoice:
        invoice, payment_hash = os.environ["AUREOM_LND_TEST_INVOICE"], None
    else:
        pytest.skip("no invoice source configured (AUREOM_LND_PAYEE_* or AUREOM_LND_TEST_INVOICE); NOT executed")

    intent, summary = service.prepare_invoice_payment(invoice)
    assert summary.network == "regtest" and "confirmed by the backend" in summary.destination_source
    payment_hash = payment_hash or intent.payment_hash

    done = service.approve_and_send(intent.id, fee_limit_msat=summary.suggested_fee_limit_msat)
    deadline = time.time() + 60
    while done.state in (PaymentState.PENDING, PaymentState.UNKNOWN) and time.time() < deadline:
        time.sleep(1)
        done = service.refresh(intent.id)
    assert done.state is PaymentState.SUCCEEDED, done.error
    assert done.fee_paid_msat is not None and done.fee_paid_msat <= summary.suggested_fee_limit_msat

    # reconciliation primitives against the real node
    tracked = payer.track_payment(payment_hash)  # exercises the URL-safe base64 path parameter
    assert tracked.status is OutgoingStatus.SUCCEEDED
    with pytest.raises(DuplicatePayment):  # the application refuses first ...
        service.prepare_invoice_payment(invoice)
    with pytest.raises(PaymentAlreadyKnown):  # ... and so does LND for the same payment hash
        payer.pay_invoice(invoice, amount_msat=None, fee_limit_msat=1_000, timeout_s=30)

    if payee_backend is not None:
        assert payee_backend.lookup_invoice(payment_hash).status is IncomingStatus.SETTLED
