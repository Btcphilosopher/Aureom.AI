"""Restart recovery: payment intents survive on disk and are reconciled without resubmission."""

import pytest

from aureom_torrent.payments.models import PaymentDirection, PaymentIntent, PaymentKind, PaymentState
from aureom_torrent.payments.repository import PaymentRepository
from aureom_torrent.payments.service import PaymentService
from aureom_torrent.persistence.database import Database
from tests.fakes.payments import FakeClock, FakeLightningBackend, make_invoice, settings_factory

S = PaymentState
NOW = 1_800_000_000


def open_service(path, backend, clock):
    db = Database(path)
    return db, PaymentService(db, lambda: backend, settings_factory(), clock)


def test_unknown_outcome_survives_restart_and_is_reconciled(tmp_path):
    path = tmp_path / "aureom.sqlite3"
    clock = FakeClock(NOW)
    backend = FakeLightningBackend()
    backend.pay_script = ["timeout"]
    backend.timeout_then = "in_flight"

    db, service = open_service(path, backend, clock)
    pr, payment_hash = make_invoice(amount_msat=75_000, created_at=NOW)
    intent, _ = service.prepare_invoice_payment(pr)
    assert service.approve_and_send(intent.id, fee_limit_msat=1_000).state is S.UNKNOWN
    db.close()

    # --- restart 1: backend says "in flight" -> PENDING
    clock.advance(30)
    db, service = open_service(path, backend, clock)
    assert service.get(intent.id).state is S.UNKNOWN
    report = service.reconcile_on_startup()
    assert (report.checked, report.pending, report.resubmitted) == (1, 1, 0) and report.backend_reachable
    assert service.get(intent.id).state is S.PENDING
    db.close()

    # --- restart 2: the payment settled while the application was closed
    backend.settle_outgoing(payment_hash, fee_msat=250)
    db, service = open_service(path, backend, clock)
    report = service.reconcile_on_startup()
    final = service.get(intent.id)
    assert report.succeeded == 1 and final.state is S.SUCCEEDED and final.fee_paid_msat == 250
    assert final.invoice is None
    assert [e.to_state for e in service.events(intent.id)] == [
        S.DRAFT, S.AWAITING_APPROVAL, S.SUBMITTED, S.UNKNOWN, S.PENDING, S.SUCCEEDED]
    assert backend.count("pay_invoice") == 1  # exactly one submission across three runs
    assert "Nothing was resubmitted" in report.summary()
    db.close()


def test_crash_between_persisting_and_backend_answer(tmp_path):
    """A row left in SUBMITTED means the process died mid-submission: treat as unknown, track, never resend."""
    path = tmp_path / "aureom.sqlite3"
    clock = FakeClock(NOW)
    backend = FakeLightningBackend()
    pr_a, hash_a = make_invoice(amount_msat=10_000, created_at=NOW, expiry=600)
    pr_b, hash_b = make_invoice(amount_msat=20_000, created_at=NOW, expiry=600)

    db = Database(path)
    repo = PaymentRepository(db)
    for pid, pr, ph in (("a", pr_a, hash_a), ("b", pr_b, hash_b)):
        repo.insert(PaymentIntent(id=pid, direction=PaymentDirection.OUTGOING, kind=PaymentKind.LIGHTNING_INVOICE,
                                  state=S.DRAFT, network="regtest", amount_msat=10_000, payment_hash=ph,
                                  invoice=pr, expires_at=NOW + 600, created_at=NOW, updated_at=NOW))
        repo.transition(pid, S.AWAITING_APPROVAL, now=NOW)
        repo.transition(pid, S.SUBMITTED, now=NOW, fee_limit_msat=100, submitted_at=NOW)
    # a half-created incoming invoice and an unapproved, long-expired intent
    repo.insert(PaymentIntent(id="draft", direction=PaymentDirection.INCOMING, kind=PaymentKind.LIGHTNING_RECEIVE,
                              state=S.DRAFT, network="regtest", amount_msat=1_000, created_at=NOW, updated_at=NOW))
    repo.insert(PaymentIntent(id="stale", direction=PaymentDirection.OUTGOING, kind=PaymentKind.LIGHTNING_INVOICE,
                              state=S.DRAFT, network="regtest", amount_msat=1_000, payment_hash="77" * 32,
                              invoice="lnbcrt1stale", expires_at=NOW + 60, created_at=NOW, updated_at=NOW))
    repo.transition("stale", S.AWAITING_APPROVAL, now=NOW)
    db.close()

    backend.settle_outgoing(hash_a)  # the node did receive and complete payment "a"; it never saw "b"
    clock.advance(120)
    db, service = open_service(path, backend, clock)
    report = service.reconcile_on_startup()
    assert service.get("a").state is S.SUCCEEDED
    assert service.get("b").state is S.UNKNOWN  # no record, invoice still valid: stay unknown
    assert service.get("draft").state is S.FAILED
    assert service.get("stale").state is S.EXPIRED
    assert report.interrupted == 3 and report.succeeded == 1 and report.unknown == 1 and report.expired == 1
    assert backend.count("pay_invoice") == 0 and backend.count("create_invoice") == 0

    clock.advance(600 + 121)  # "b" can no longer be paid: its invoice expired
    report = service.reconcile_on_startup()
    assert service.get("b").state is S.FAILED and report.failed == 1
    assert backend.count("pay_invoice") == 0
    db.close()


def test_incoming_invoice_survives_restart(tmp_path):
    path = tmp_path / "aureom.sqlite3"
    clock = FakeClock(NOW)
    backend = FakeLightningBackend()
    backend.clock = clock
    db, service = open_service(path, backend, clock)
    intent = service.create_incoming_invoice(12_000, memo="release tips", expiry_s=900)
    db.close()

    backend.settle_invoice(intent.payment_hash)
    db, service = open_service(path, backend, clock)
    assert service.get(intent.id).state is S.PENDING and service.get(intent.id).invoice
    report = service.reconcile_on_startup()
    assert report.succeeded == 1 and service.get(intent.id).state is S.SUCCEEDED
    db.close()


def test_reconciliation_without_backend_changes_nothing(tmp_path):
    path = tmp_path / "aureom.sqlite3"
    clock = FakeClock(NOW)
    backend = FakeLightningBackend()
    backend.pay_script = ["timeout"]
    db, service = open_service(path, backend, clock)
    pr, _ = make_invoice(created_at=NOW)
    intent, _ = service.prepare_invoice_payment(pr)
    service.approve_and_send(intent.id, fee_limit_msat=1_000)
    db.close()

    db = Database(path)
    offline = PaymentService(db, lambda: None, settings_factory(), clock)
    report = offline.reconcile_on_startup()
    assert not report.backend_reachable and report.unknown == 1 and report.notes
    assert offline.get(intent.id).state is S.UNKNOWN
    assert len(offline.list_payments()) == 1  # history stays readable with no backend at all
    db.close()


def test_schema_has_no_secret_columns(tmp_path):
    db = Database(tmp_path / "x.sqlite3")
    cols = {r["name"] for r in db.query("PRAGMA table_info(payments)")}
    assert not cols & {"preimage", "payment_preimage", "macaroon", "secret", "seed", "private_key"}
    assert {"payment_hash", "state", "amount_msat", "fee_limit_msat"} <= cols
    with pytest.raises(Exception):
        db.execute("INSERT INTO payment_events(payment_id, ts, to_state) VALUES ('missing', 1, 'draft')")
    db.close()
