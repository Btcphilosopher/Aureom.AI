"""One-off tip flow against a real local HTTP server (LNURL-pay), with a fake Lightning backend."""

import hashlib
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

import pytest

from aureom_torrent.net.http import HttpFetcher, HttpPolicy
from aureom_torrent.payments.lnurl import LnurlError
from aureom_torrent.payments.models import (PaymentKind, PaymentLimitError, PaymentState, PublisherRef,
                                            PublisherTrust)
from aureom_torrent.payments.service import PaymentService
from aureom_torrent.persistence.database import Database
from tests.fakes.payments import FakeClock, FakeLightningBackend, make_invoice, settings_factory

NOW = 1_800_000_000
META = json.dumps([["text/plain", "Support Open Archive releases"]])


class LnurlServer:
    """A tiny LNURL-pay service. ``mode`` selects how it (mis)behaves."""

    def __init__(self):
        self.mode = "ok"
        self.requests: list[str] = []
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):  # keep test output quiet
                pass

            def _json(self, payload, status=200):
                body = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                outer.requests.append(self.path)
                parts = urlsplit(self.path)
                base = f"http://127.0.0.1:{outer.port}"
                if parts.path == "/.well-known/lnurlp/alice":
                    if outer.mode == "not_pay":
                        return self._json({"tag": "withdrawRequest"})
                    if outer.mode == "huge":
                        return self._json(b"{" + b" " * 200_000 + b"}")
                    if outer.mode == "redirect_out":
                        self.send_response(302)
                        self.send_header("Location", "http://198.51.100.7/elsewhere")
                        self.end_headers()
                        return None
                    return self._json({"tag": "payRequest", "callback": base + "/cb", "minSendable": 1000,
                                       "maxSendable": 50_000_000, "metadata": META})
                if parts.path == "/cb":
                    amount = int(parse_qs(parts.query)["amount"][0])
                    if outer.mode == "error":
                        return self._json({"status": "ERROR", "reason": "service paused"})
                    if outer.mode == "http_500":
                        return self._json({}, status=500)
                    good = hashlib.sha256(META.encode()).hexdigest()
                    pr, _ = make_invoice(
                        network="mainnet" if outer.mode == "wrong_network" else "regtest",
                        amount_msat=amount + 1000 if outer.mode == "wrong_amount" else amount,
                        description_hash="11" * 32 if outer.mode == "wrong_hash" else good,
                        created_at=NOW, expiry=600)
                    return self._json({"pr": pr, "routes": [], "successAction": {"tag": "url", "url": "http://x"}})
                return self._json({}, status=404)

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = self._server.server_address[1]
        self._thread = threading.Thread(target=self._server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
        self._thread.start()

    def close(self):
        self._server.shutdown()
        self._server.server_close()


@pytest.fixture
def server():
    s = LnurlServer()
    yield s
    s.close()


@pytest.fixture
def env(server):
    class E:
        pass

    e = E()
    e.clock = FakeClock(NOW)
    e.backend = FakeLightningBackend()
    # Local testing only: plain http on loopback is explicitly allowed by this policy.
    e.policy = HttpPolicy(timeout_s=5, max_bytes=64 * 1024, max_redirects=2, allow_http=True, allow_loopback=True)
    e.service = PaymentService(Database(None), lambda: e.backend, settings_factory(), e.clock,
                               HttpFetcher(e.policy), lnurl_policy=e.policy)
    e.address = f"alice@127.0.0.1:{server.port}"
    return e


def test_tip_requires_separate_explicit_approval(env, server):
    publisher = PublisherRef("Open Archive", PublisherTrust.SELF_ASSERTED, "manifest-1")
    intent, summary = env.service.prepare_tip(env.address, 21_000, publisher=publisher, transfer_id="t1")
    assert intent.kind is PaymentKind.LIGHTNING_TIP and intent.state is PaymentState.AWAITING_APPROVAL
    assert intent.amount_msat == 21_000 and summary.amount_text == "21 sats"
    assert summary.description == "Support Open Archive releases"  # verified against the invoice's hash
    assert "127.0.0.1" in summary.destination_source
    assert any("cannot verify who operates" in w for w in summary.warnings)
    assert any("self-asserted" in w for w in summary.warnings)
    assert server.requests == ["/.well-known/lnurlp/alice", "/cb?amount=21000"]
    assert env.backend.count("pay_invoice") == 0  # fetching an invoice never pays it

    done = env.service.approve_and_send(intent.id, fee_limit_msat=summary.suggested_fee_limit_msat)
    assert done.state is PaymentState.SUCCEEDED and env.backend.count("pay_invoice") == 1
    assert done.publisher_name == "Open Archive" and done.manifest_id == "manifest-1"


@pytest.mark.parametrize("mode", ["wrong_amount", "wrong_hash", "error", "http_500", "not_pay", "huge",
                                  "redirect_out"])
def test_misbehaving_tip_service_is_rejected(env, server, mode):
    server.mode = mode
    with pytest.raises(LnurlError):
        env.service.prepare_tip(env.address, 21_000)
    assert env.service.list_payments() == []  # nothing recorded, nothing to approve
    assert env.backend.count("pay_invoice") == 0


def test_invoice_for_wrong_network_is_rejected(env, server):
    server.mode = "wrong_network"
    with pytest.raises(ValueError):
        env.service.prepare_tip(env.address, 21_000)
    assert env.service.list_payments() == []


def test_tip_amount_limits_checked_before_any_network_request(env, server):
    for amount in (0, 10**12):
        with pytest.raises(PaymentLimitError):
            env.service.prepare_tip(env.address, amount)
    with pytest.raises(ValueError):
        env.service.prepare_tip(env.address, 21.5)
    assert server.requests == []


def test_amount_above_service_maximum_never_reaches_the_callback(env, server):
    # 60 000 sats is within the application's limit but above this service's maxSendable (50 000 sats).
    with pytest.raises(LnurlError):
        env.service.prepare_tip(env.address, 60_000_000)
    assert server.requests == ["/.well-known/lnurlp/alice"]
    assert env.service.list_payments() == []


def test_default_policy_refuses_loopback_tip_services(server):
    service = PaymentService(Database(None), lambda: None, settings_factory(), FakeClock(NOW))
    with pytest.raises(LnurlError):
        service.prepare_tip(f"alice@127.0.0.1:{server.port}", 21_000)
    assert server.requests == []
