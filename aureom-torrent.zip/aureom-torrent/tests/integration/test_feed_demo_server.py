"""The demo feed server (scripts/demo_feed_server.py) driven by the real feed service.

Covers the documented demo flow: baseline → publish a new item → rule adds it,
with real .torrent files created and inspected by libtorrent.
"""

from __future__ import annotations

import importlib.util
import threading
import urllib.request
from pathlib import Path

import pytest

from aureom_torrent.feeds.models import STATUS_ADDED, STATUS_BASELINE, FeedRule
from aureom_torrent.feeds.service import FeedService
from aureom_torrent.net.http import HttpFetcher, HttpPolicy
from aureom_torrent.persistence.database import Database
from tests.fakes.feeds import FakeClock, FakeTransferGateway, make_settings

pytestmark = pytest.mark.integration

SCRIPT = Path(__file__).resolve().parents[2] / "scripts" / "demo_feed_server.py"


class CodecGateway(FakeTransferGateway):
    """The fake gateway, but .torrent bytes are parsed by the real engine codec."""

    def __init__(self):
        super().__init__()
        from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec

        self._codec = LibtorrentCodec()

    def inspect_torrent(self, torrent_data: bytes):
        self.inspect_calls += 1
        return self._codec.inspect(torrent_data)


@pytest.fixture
def demo(tmp_path):
    pytest.importorskip("libtorrent")
    spec = importlib.util.spec_from_file_location("demo_feed_server", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    server, state = module.build_server("127.0.0.1", 0, tmp_path / "data", initial_items=2)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    yield base, state
    server.shutdown()
    server.server_close()
    thread.join(5)


def test_demo_flow_baseline_publish_and_rules(demo):
    base, state = demo
    assert state.torrents_enabled
    settings = make_settings()
    settings().feeds_network.allow_loopback = True
    gateway = CodecGateway()
    service = FeedService(Database(None), HttpFetcher(HttpPolicy()), gateway, settings, FakeClock())

    rss = service.add_feed(base + "/rss.xml")
    atom = service.add_feed(base + "/atom.xml")
    for feed in (rss, atom):
        service.set_auto_download(feed.id, True)
    service.save_rule(FeedRule(feed_id=rss.id, name="small datasets", include=["dataset"], max_size=5_000_000))
    service.save_rule(FeedRule(feed_id=atom.id, name="everything", add_paused=True))

    first = {r.feed_id: r for r in service.refresh_due()}
    assert first[rss.id].ok and first[rss.id].baseline and first[rss.id].new_entries == 2
    assert first[atom.id].ok and first[atom.id].baseline and first[atom.id].new_entries == 2
    assert gateway.calls == []
    assert {e.status for e in service.list_entries()} == {STATUS_BASELINE}

    # nothing changed: both feeds answer 304
    again = [service.refresh_feed(rss.id), service.refresh_feed(atom.id)]
    assert all(r.ok and r.not_modified for r in again)

    with urllib.request.urlopen(urllib.request.Request(base + "/publish", method="POST"), timeout=10) as resp:
        assert resp.status == 201

    rss_result = service.refresh_feed(rss.id)
    assert rss_result.ok and rss_result.new_entries == 1 and rss_result.auto_added == 1
    added = next(e for e in service.list_entries(feed_id=rss.id) if e.status == STATUS_ADDED)
    assert added.size_trusted and added.size == state.items[-1].size and added.v1 == state.items[-1].v1

    # the Atom feed lists the same torrent as a magnet link: it is recognised as already handled
    atom_result = service.refresh_feed(atom.id)
    assert atom_result.new_entries == 1 and atom_result.auto_added == 0 and atom_result.duplicates == 1
    assert [c.kind for c in gateway.calls] == ["torrent"]
