"""First vertical slice: open torrent → choose destination → transfer on loopback → verified
progress → pause → close → restart → resume → verify output byte-for-byte.

Run separately for v1, v2 and hybrid torrents. Public discovery is disabled (isolated nodes).
"""

from __future__ import annotations

import pytest

from aureom_torrent.domain.transfers import TransferState
from tests.support import create_torrent, make_payload, sha256_file

pytestmark = pytest.mark.integration

FILES = {"alpha.bin": 3_000_000, "docs/readme.txt": 70_000, "docs/notes/b.dat": 400_000}


@pytest.mark.parametrize("fmt", ["v1", "v2", "hybrid"])
def test_transfer_pause_restart_resume_verify(fmt, nodes, tmp_path):
    source_parent = tmp_path / "seed-data"
    payload = make_payload(source_parent / "payload", FILES)
    created = create_torrent(payload, fmt)
    assert created.metadata.identity.kind == fmt

    seeder = nodes("seeder").start()
    out = seeder.service.add_torrent_data(created.torrent_data, save_path=str(source_parent), source="created")
    assert out.created
    view = seeder.wait_state(out.transfer_id, TransferState.SEEDING)
    assert view.torrent_complete and view.progress_ppm == 1_000_000

    dest = tmp_path / "downloads"
    dest.mkdir()
    leech = nodes("leech").start()
    # throttle so that a pause lands mid-transfer
    leech.service.add_torrent_data(created.torrent_data, save_path=str(dest), paused=True)
    tid = leech.views()[0].id
    paused = leech.wait_state(tid, TransferState.PAUSED)
    assert paused.progress_ppm == 0 and not paused.selected_complete
    leech.service.set_limits(tid, download_limit=600_000)
    leech.service.resume([tid])
    leech.connect(tid, seeder)
    leech.wait(lambda: 0 < leech.view(tid).progress_ppm < 1_000_000, 30, "partial verified progress")
    mid = leech.view(tid)
    assert mid.state is TransferState.DOWNLOADING
    assert not mid.selected_complete and not mid.torrent_complete

    # manual pause, then close the application
    leech.service.pause([tid])
    leech.wait_state(tid, TransferState.PAUSED)
    progress_at_pause = leech.view(tid).progress_ppm
    assert 0 < progress_at_pause < 1_000_000
    report = leech.stop()
    assert report.clean and report.resume_saved == 1 and not report.resume_unsaved

    # restart: the manual pause and verified progress survive
    leech2 = nodes("leech").start()
    again = leech2.wait_state(tid, TransferState.PAUSED)
    assert again.manual_paused
    assert again.progress_ppm >= progress_at_pause > 0
    assert again.save_path == str(dest)
    activity = " ".join(m for _, _, _, m in leech2.service.activity(tid))
    assert "re-checked" not in activity  # resume data was accepted, no full recheck needed

    leech2.service.set_limits(tid, download_limit=0)
    leech2.service.resume([tid])
    leech2.connect(tid, seeder)
    done = leech2.wait_state(tid, TransferState.SEEDING, timeout=60)
    assert done.selected_complete and done.torrent_complete and done.progress_ppm == 1_000_000

    for rel in FILES:
        assert sha256_file(dest / "payload" / rel) == sha256_file(payload / rel), rel
