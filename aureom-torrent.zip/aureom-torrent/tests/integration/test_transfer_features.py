"""Engine integration on loopback: magnet preview, selection, corruption, duplicates, moves, removal."""

from __future__ import annotations

import os

import pytest

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.domain.transfers import TransferState
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec
from aureom_torrent.services.interfaces import AddRejected
from aureom_torrent.services.transfer_service import OperationRejected
from tests.support import create_torrent, make_payload, sha256_file

pytestmark = pytest.mark.integration

FILES = {"a.bin": 600_000, "sub/b.bin": 300_000, "sub/c.txt": 50_000}


def seeded(nodes, tmp_path, fmt="hybrid", files=FILES, name="payload", **kw):
    parent = tmp_path / f"seed-{name}"
    payload = make_payload(parent / name, files)
    created = create_torrent(payload, fmt, **kw)
    seeder = nodes(f"seeder-{name}").start()
    out = seeder.service.add_torrent_data(created.torrent_data, save_path=str(parent), source="created")
    seeder.wait_state(out.transfer_id, TransferState.SEEDING)
    return seeder, created, payload


def dir_files(root):
    return sorted(str(p.relative_to(root)) for p in root.rglob("*") if p.is_file())


@pytest.mark.parametrize("fmt", ["v1", "v2", "hybrid"])
def test_magnet_metadata_preview_then_selective_download(fmt, nodes, tmp_path):
    seeder, created, payload = seeded(nodes, tmp_path, fmt)
    magnet = LibtorrentCodec().make_magnet(created.torrent_data)
    dest = tmp_path / "dl"
    leech = nodes("leech").start()
    out = leech.service.add_magnet(magnet, save_path=str(dest), preview=True)
    tid = out.transfer_id
    view = leech.wait_state(tid, TransferState.RETRIEVING_METADATA)
    assert view.state.label == "Retrieving metadata" and not view.has_metadata
    leech.connect(tid, seeder)
    leech.wait(lambda: any(k == "preview_ready" for k, _ in leech.notes), 30, "metadata")
    meta = leech.service.metadata(tid)
    assert [f.path for f in meta.real_files] == ["payload/a.bin", "payload/sub/b.bin", "payload/sub/c.txt"]
    assert meta.identity.matches(created.metadata.identity)

    # Metadata retrieval must not have started payload transfer or written anything.
    import time
    time.sleep(1.0)
    view = leech.view(tid)
    assert view.preview and view.state is TransferState.PAUSED and "review" in view.state_detail
    assert view.downloaded == 0 and view.progress_ppm == 0 and not view.selected_complete
    assert not dest.exists()
    assert dir_files(leech.paths.staging_dir) == []

    # The user reviews: only sub/c.txt, chosen destination.
    priorities = [4 if f.path.endswith("c.txt") else 0 for f in meta.files]
    leech.service.confirm_preview(tid, save_path=str(dest), file_priorities=priorities)
    leech.wait(lambda: not leech.view(tid).preview, 10, "confirmation to be applied by the engine")
    leech.connect(tid, seeder)
    done = leech.wait_state(tid, TransferState.SEEDING, timeout=30)
    assert done.selected_complete and not done.torrent_complete  # selected ≠ entire torrent
    assert done.progress_ppm == 1_000_000 and done.save_path == str(dest) and not done.preview
    assert sha256_file(dest / "payload/sub/c.txt") == sha256_file(payload / "sub/c.txt")
    assert not (dest / "payload/a.bin").exists()
    # boundary pieces of deselected files may only live in the engine's parts file
    extra = [f for f in dir_files(dest) if not f.endswith("c.txt")]
    assert all(os.path.basename(f).startswith(".") and f.endswith(".parts") for f in extra), extra

    # Selecting another file later resumes downloading; state is no longer "complete".
    priorities = [4 if not f.pad else 0 for f in meta.files]
    leech.service.set_file_priorities(tid, priorities)
    leech.connect(tid, seeder)
    leech.wait(lambda: leech.view(tid).torrent_complete, 30, "entire torrent")
    for rel in FILES:
        assert sha256_file(dest / "payload" / rel) == sha256_file(payload / rel)


def test_duplicate_detection_across_v1_v2_hybrid(nodes, tmp_path):
    seeder, created, _ = seeded(nodes, tmp_path, "hybrid")
    codec = LibtorrentCodec()
    ident = created.metadata.identity
    v1_magnet = codec.magnet_for(TorrentIdentity(ident.v1, None), "x")
    v2_magnet = codec.magnet_for(TorrentIdentity(None, ident.v2), "x")
    leech = nodes("leech").start()
    first = leech.service.add_torrent_data(created.torrent_data, save_path=str(tmp_path / "d1"), paused=True)
    assert first.created
    for magnet in (v1_magnet, v2_magnet):
        dup = leech.service.add_magnet(magnet, save_path=str(tmp_path / "d2"))
        assert not dup.created and dup.duplicate_of == first.transfer_id
    again = leech.service.add_torrent_data(created.torrent_data, save_path=str(tmp_path / "d3"))
    assert not again.created
    assert len(leech.views()) == 1
    assert leech.view(first.transfer_id).manual_paused  # the existing transfer was not modified


def test_hybrid_revealed_by_metadata_removes_second_transfer(nodes, tmp_path):
    """A v1-only magnet and a v2-only magnet for the same hybrid torrent cannot be matched until
    metadata arrives; when it does, the newer transfer is removed (no two writers)."""
    seeder, created, _ = seeded(nodes, tmp_path, "hybrid")
    codec = LibtorrentCodec()
    ident = created.metadata.identity
    leech = nodes("leech").start()
    a = leech.service.add_magnet(codec.magnet_for(TorrentIdentity(ident.v1, None), "a"),
                                 save_path=str(tmp_path / "same"), paused=False)
    leech.connect(a.transfer_id, seeder)
    leech.wait(lambda: leech.view(a.transfer_id).has_metadata, 30, "first metadata")
    # After metadata the first transfer knows both hashes, so a v2 magnet is recognised immediately.
    b = leech.service.add_magnet(codec.magnet_for(TorrentIdentity(None, ident.v2), "b"),
                                 save_path=str(tmp_path / "same"))
    assert not b.created and b.duplicate_of == a.transfer_id
    assert len(leech.views()) == 1


def test_destination_conflict_is_rejected(nodes, tmp_path):
    one = make_payload(tmp_path / "one" / "shared-name", {"x.bin": 100_000}, seed="one")
    two = make_payload(tmp_path / "two" / "shared-name", {"x.bin": 100_000}, seed="two")
    t1, t2 = create_torrent(one, "v1"), create_torrent(two, "v1")
    assert not t1.metadata.identity.matches(t2.metadata.identity)
    node = nodes("n").start()
    dest = tmp_path / "dest"
    dest.mkdir()
    node.service.add_torrent_data(t1.torrent_data, save_path=str(dest), paused=True)
    with pytest.raises(AddRejected) as err:
        node.service.add_torrent_data(t2.torrent_data, save_path=str(dest), paused=True)
    assert err.value.reason == "conflict"
    assert len(node.views()) == 1


@pytest.mark.parametrize("fmt", ["v1", "v2", "hybrid"])
def test_corruption_is_detected_and_repaired(fmt, nodes, tmp_path):
    seeder, created, payload = seeded(nodes, tmp_path, fmt)
    dest = tmp_path / "dl"
    dest.mkdir()
    leech = nodes("leech").start()
    tid = leech.service.add_torrent_data(created.torrent_data, save_path=str(dest)).transfer_id
    leech.connect(tid, seeder)
    leech.wait_state(tid, TransferState.SEEDING)
    leech.service.pause([tid])
    leech.wait_state(tid, TransferState.COMPLETED)

    target = dest / "payload/a.bin"
    data = bytearray(target.read_bytes())
    data[100_000:100_032] = b"\x00" * 32
    target.write_bytes(bytes(data))

    leech.service.recheck([tid])
    # the recheck must discover the damage: not complete any more, and never shown as complete
    leech.wait(lambda: (v := leech.view(tid)).state is TransferState.PAUSED and v.progress_ppm < 1_000_000, 30,
               "corruption detected")
    damaged = leech.view(tid)
    assert not damaged.selected_complete and not damaged.torrent_complete

    leech.service.resume([tid])
    leech.connect(tid, seeder)
    leech.wait(lambda: leech.view(tid).torrent_complete, 30, "repair")
    assert sha256_file(target) == sha256_file(payload / "a.bin")


def test_move_storage_updates_destination_only_after_engine_confirms(nodes, tmp_path):
    seeder, created, payload = seeded(nodes, tmp_path, "v1")
    dest, dest2 = tmp_path / "dl", tmp_path / "moved"
    dest.mkdir()
    leech = nodes("leech").start()
    tid = leech.service.add_torrent_data(created.torrent_data, save_path=str(dest)).transfer_id
    leech.connect(tid, seeder)
    leech.wait_state(tid, TransferState.SEEDING)

    leech.service.move_storage(tid, str(dest2))
    assert leech.service.record(tid).save_path == str(dest)  # not persisted before the engine event
    leech.wait(lambda: leech.service.record(tid).save_path == str(dest2), 20, "move to finish")
    assert sha256_file(dest2 / "payload/a.bin") == sha256_file(payload / "a.bin")
    assert not (dest / "payload/a.bin").exists()

    # A failing move (destination already holds a file of the same name) keeps the old destination.
    blocked = tmp_path / "blocked"
    (blocked / "payload").mkdir(parents=True)
    (blocked / "payload/a.bin").write_bytes(b"unrelated user file")
    leech.service.move_storage(tid, str(blocked))
    leech.wait(lambda: any(k == "error" and "moved" in p.get("message", "") for k, p in leech.notes), 20,
               "move failure notification")
    assert leech.service.record(tid).save_path == str(dest2)
    assert (blocked / "payload/a.bin").read_bytes() == b"unrelated user file"
    assert (dest2 / "payload/a.bin").exists()

    # restart: the persisted destination is the confirmed one and data is intact
    leech.stop()
    leech2 = nodes("leech").start()
    view = leech2.wait_state(tid, TransferState.SEEDING)
    assert view.save_path == str(dest2) and view.torrent_complete


def test_remove_keeps_data_and_delete_only_touches_owned_files(nodes, tmp_path):
    seeder, created, payload = seeded(nodes, tmp_path, "hybrid")
    dest = tmp_path / "dl"
    dest.mkdir()
    leech = nodes("leech").start()
    tid = leech.service.add_torrent_data(created.torrent_data, save_path=str(dest)).transfer_id
    leech.connect(tid, seeder)
    leech.wait_state(tid, TransferState.SEEDING)

    # removal without deletion
    leech.service.remove([tid])
    leech.wait(lambda: leech.view(tid) is None, 10, "removal")
    assert sha256_file(dest / "payload/a.bin") == sha256_file(payload / "a.bin")
    assert not leech.paths.resume_dir.joinpath(f"{tid}.fastresume").exists()

    # re-add over the existing data: verified by checking, then delete with data
    tid2 = leech.service.add_torrent_data(created.torrent_data, save_path=str(dest)).transfer_id
    leech.wait_state(tid2, TransferState.SEEDING)
    (dest / "payload/sub/my-notes.txt").write_text("not part of the torrent")
    (dest / "unrelated.txt").write_text("sibling")
    leech.service.remove([tid2], delete_data=True)
    leech.wait(lambda: leech.view(tid2) is None, 10, "removal with data")
    leech.wait(lambda: not (dest / "payload/a.bin").exists(), 10, "data deletion")
    assert not (dest / "payload/sub/b.bin").exists() and not (dest / "payload/sub/c.txt").exists()
    assert (dest / "payload/sub/my-notes.txt").read_text() == "not part of the torrent"
    assert (dest / "unrelated.txt").read_text() == "sibling"


def test_delete_refused_when_files_resolve_outside_destination(nodes, tmp_path):
    seeder, created, payload = seeded(nodes, tmp_path, "v1")
    dest = tmp_path / "dl"
    dest.mkdir()
    leech = nodes("leech").start()
    tid = leech.service.add_torrent_data(created.torrent_data, save_path=str(dest)).transfer_id
    leech.connect(tid, seeder)
    leech.wait_state(tid, TransferState.SEEDING)
    leech.service.pause([tid])
    leech.wait_state(tid, TransferState.COMPLETED)

    # Replace the "sub" directory by a symlink that points outside the destination.
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "b.bin").write_bytes(b"precious")
    import shutil
    shutil.rmtree(dest / "payload/sub")
    os.symlink(outside, dest / "payload/sub")

    with pytest.raises(OperationRejected):
        leech.service.remove([tid], delete_data=True)
    assert leech.view(tid) is not None  # nothing was removed
    assert (outside / "b.bin").read_bytes() == b"precious"
    assert (dest / "payload/a.bin").exists()


def test_missing_and_corrupt_resume_data_recover_by_rechecking(nodes, tmp_path):
    seeder, created, payload = seeded(nodes, tmp_path, "hybrid")
    dest = tmp_path / "dl"
    dest.mkdir()
    leech = nodes("leech").start()
    tid = leech.service.add_torrent_data(created.torrent_data, save_path=str(dest)).transfer_id
    leech.connect(tid, seeder)
    leech.wait_state(tid, TransferState.SEEDING)
    leech.stop()

    resume = leech.paths.resume_dir / f"{tid}.fastresume"
    assert resume.exists()
    resume.write_bytes(b"this is not bencoded resume data")  # corrupt
    (leech.paths.resume_dir / "leftover.fastresume.tmp").write_bytes(b"interrupted write")
    leech2 = nodes("leech").start()
    view = leech2.wait_state(tid, TransferState.SEEDING)
    assert view.torrent_complete
    notes = " ".join(m for _, _, _, m in leech2.service.activity(tid))
    assert "could not be read" in notes
    assert not (leech2.paths.resume_dir / "leftover.fastresume.tmp").exists()
    leech2.stop()

    resume.unlink()  # missing
    leech3 = nodes("leech").start()
    assert leech3.wait_state(tid, TransferState.SEEDING).torrent_complete
    assert "No saved resume data" in " ".join(m for _, _, _, m in leech3.service.activity(tid))


def test_missing_destination_is_not_silently_recreated(nodes, tmp_path):
    seeder, created, payload = seeded(nodes, tmp_path, "v1")
    dest = tmp_path / "removable-drive"
    dest.mkdir()
    leech = nodes("leech").start()
    tid = leech.service.add_torrent_data(created.torrent_data, save_path=str(dest)).transfer_id
    leech.connect(tid, seeder)
    leech.wait_state(tid, TransferState.SEEDING)
    leech.stop()

    import shutil
    shutil.rmtree(dest)
    leech2 = nodes("leech").start()
    leech2.wait(lambda: (v := leech2.view(tid)) is not None and v.live, 10, "restore")
    view = leech2.view(tid)
    assert view.state is TransferState.ERROR and "missing" in view.error
    leech2.service.resume([tid])
    assert not dest.exists()  # starting again does not quietly re-download into a recreated folder
    assert leech2.view(tid).state is TransferState.ERROR


def test_private_torrent_flag_is_preserved(nodes, tmp_path):
    parent = tmp_path / "seedp"
    payload = make_payload(parent / "payload", {"p.bin": 100_000})
    created = create_torrent(payload, "hybrid", private=True, trackers=(("http://127.0.0.1:9/announce",),))
    node = nodes("n").start()
    tid = node.service.add_torrent_data(created.torrent_data, save_path=str(parent)).transfer_id
    view = node.wait_state(tid, TransferState.SEEDING)
    assert view.private and node.service.metadata(tid).private
    assert "tr=" in node.service.magnet_uri(tid)
