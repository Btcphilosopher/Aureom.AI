"""Shared helpers for tests: synthetic payloads and an isolated application node."""

from __future__ import annotations

import hashlib
import os
import time
from pathlib import Path
from typing import Callable

from aureom_torrent.domain.transfers import TransferState, TransferView
from aureom_torrent.engine.commands import CreateRequest
from aureom_torrent.engine.libtorrent_adapter import LibtorrentEngine
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec, LibtorrentCreator
from aureom_torrent.persistence.database import Database
from aureom_torrent.services.event_pump import EventPump
from aureom_torrent.services.transfer_service import TransferService
from aureom_torrent.settings.paths import AppPaths
from aureom_torrent.settings.store import SettingsStore


def synthetic_bytes(size: int, seed: str) -> bytes:
    """Deterministic, incompressible-looking test data (no real content)."""
    out = bytearray()
    counter = 0
    while len(out) < size:
        out += hashlib.sha256(f"{seed}:{counter}".encode()).digest()
        counter += 1
    return bytes(out[:size])


def make_payload(root: Path, files: dict[str, int], seed: str = "aureom") -> Path:
    for rel, size in files.items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(synthetic_bytes(size, f"{seed}:{rel}"))
    return root


def create_torrent(root: Path, fmt: str = "hybrid", *, piece_length: int = 16384, private: bool = False,
                   trackers=(), files: tuple[str, ...] | None = None):
    if files is None:
        if root.is_file():
            files = (root.name,)
        else:
            files = tuple(sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()))
    request = CreateRequest(root_path=str(root), files=files, format=fmt, piece_length=piece_length,
                            private=private, trackers=tuple(trackers))
    return LibtorrentCreator().create(request, lambda done, total: None, lambda: False)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Node:
    """A complete, isolated application back end (no GUI): real engine on loopback only."""

    def __init__(self, home: Path):
        self.home = home
        self.paths = AppPaths(home)
        self.paths.ensure()
        self.db = Database(self.paths.database)
        self.settings = SettingsStore(self.db)
        self.engine = LibtorrentEngine()
        self.codec = LibtorrentCodec()
        self.service = TransferService(self.db, self.engine, self.codec, self.paths, self.settings.get,
                                       isolated=True)
        self.pump = EventPump(self.service.handle_event)
        self.notes: list[tuple[str, dict]] = []
        self.service.subscribe(lambda kind, payload: self.notes.append((kind, payload)))
        self.started = False

    def start(self) -> "Node":
        self.pump.start()
        self.engine.start(self.service.current_engine_settings(), self.pump.post)
        self.service.restore()
        self.started = True
        self.wait(lambda: self.session().listen_port > 0, 10, "engine to listen")
        return self

    def stop(self, timeout: float = 10.0):
        if not self.started:
            return None
        self.started = False
        self.service.prepare_shutdown()
        report = self.engine.shutdown(timeout)
        self.pump.stop()
        self.db.close()
        return report

    def session(self):
        return self.service.snapshot()[2]

    @property
    def port(self) -> int:
        return self.session().listen_port

    def view(self, transfer_id: str) -> TransferView | None:
        for v in self.service.snapshot()[1]:
            if v.id == transfer_id:
                return v
        return None

    def views(self) -> list[TransferView]:
        return self.service.snapshot()[1]

    def wait(self, predicate: Callable[[], bool], timeout: float = 30.0, what: str = "condition") -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return
            time.sleep(0.05)
        states = [(v.name, v.state.value, v.state_detail, v.progress_ppm) for v in self.views()]
        raise AssertionError(f"timed out waiting for {what}; transfers: {states}; notes: {self.notes[-5:]}")

    def wait_state(self, transfer_id: str, *states: TransferState, timeout: float = 30.0) -> TransferView:
        self.wait(lambda: (v := self.view(transfer_id)) is not None and v.live and v.state in states, timeout,
                  f"state {[s.value for s in states]}")
        view = self.view(transfer_id)
        assert view is not None
        return view

    def connect(self, transfer_id: str, other: "Node") -> None:
        self.service.connect_peer(transfer_id, "127.0.0.1", other.port)
