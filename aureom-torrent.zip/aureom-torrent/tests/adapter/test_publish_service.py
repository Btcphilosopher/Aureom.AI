"""PublishService against fakes: job lifecycle, seeding hand-off, recorded publish operations."""

from __future__ import annotations

import json
import os
import threading

import pytest

from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec
from aureom_torrent.net.http import FetchTimeout
from aureom_torrent.persistence.database import Database
from aureom_torrent.publishing.manifests import (ManifestError, Provenance, SignatureStatus, TrustLevel,
                                                 build_manifest, generate_signing_key, sign_manifest)
from aureom_torrent.publishing.models import (ARTIFACT_KINDS, JobState, PublishDestination, PublishError,
                                              PublisherInfo)
from aureom_torrent.publishing.service import INTERRUPTED_MESSAGE
from aureom_torrent.settings.secrets import SECRET_MANIFEST_SIGNING_KEY, upload_secret_name
from tests.fakes.publishing import (CancellingCreator, ExplodingCreator, FakeFetcher, FakePublishAdapter,
                                    FakeTransferGateway, http_result, make_draft, make_service, make_tree)

PUBLISHER = PublisherInfo(name="Example Press", description="Synthetic data", website="https://example.org",
                          lightning_address="tips@example.org", licence="CC0-1.0")


@pytest.fixture()
def tree(tmp_path):
    return make_tree(tmp_path / "src")


def completed_job(h, tree, tmp_path, **overrides):
    job = h.service.start_job(make_draft(tree, tmp_path, **overrides))
    assert job.state is JobState.COMPLETED, job.error
    return job


def test_job_completes_and_is_persisted(tmp_path, tree):
    h = make_service(tmp_path)
    progress: list[tuple[int, int]] = []
    job = h.service.start_job(make_draft(tree, tmp_path, trackers_text="udp://t.example:6969/announce"),
                              on_progress=lambda d, t: progress.append((d, t)))
    assert job.state is JobState.COMPLETED and job.error == ""
    assert os.path.isfile(job.torrent_path)
    assert job.identity.kind == "hybrid" and job.magnet.startswith("magnet:?xt=urn:btih:")
    on_disk = sum(os.path.getsize(os.path.join(tree, *rel.split("/"))) for rel in ("data.bin", "docs/notes.md", "readme.txt"))
    assert job.file_count == 3 and job.total_size == on_disk
    assert all(op.ts == int(h.clock.now()) for op in job.operations)
    assert progress[0] == (0, progress[-1][1]) and progress[-1][0] == progress[-1][1] > 0
    stored = h.service.get_job(job.id)
    assert stored.state is JobState.COMPLETED and stored.magnet == job.magnet
    assert stored.operation("save_torrent").ok
    assert stored.options["included_files"] == 3 and "trackers" in stored.options
    assert [j.id for j in h.service.list_jobs()] == [job.id]
    assert h.gateway.calls == []  # seeding was not requested


def test_invalid_draft_raises_and_records_nothing(tmp_path, tree):
    h = make_service(tmp_path)
    with pytest.raises(PublishError) as err:
        h.service.start_job(make_draft(tree, tmp_path, format="v9", included_files=[]))
    assert len(err.value.problems) >= 2
    assert h.service.list_jobs() == []
    assert h.service.validate_options(make_draft(tree, tmp_path)) == []
    assert h.service.option_warnings(make_draft(tree, tmp_path, private=True))


def test_files_outside_a_fresh_scan_are_refused(tmp_path, tree):
    """A stale or forged file list cannot smuggle in links or files that are no longer regular."""
    outside = tmp_path / "secret.txt"
    outside.write_text("do not publish")
    os.symlink(outside, os.path.join(tree, "link.txt"))
    os.symlink(tmp_path, os.path.join(tree, "linkdir"))
    h = make_service(tmp_path)
    for forged in ("link.txt", "linkdir/secret.txt", "missing.bin"):
        with pytest.raises(PublishError) as err:
            h.service.start_job(make_draft(tree, tmp_path, included_files=["data.bin", forged]))
        assert "no longer regular files inside the selection" in str(err.value)
    assert h.service.list_jobs() == []
    scan = h.service.scan(tree)
    assert [f.relative for f in scan.files] == ["data.bin", "docs/notes.md", "readme.txt"]
    reasons = dict(scan.skipped)
    assert "outside the selected folder" in reasons["link.txt"] and "outside" in reasons["linkdir"]


def test_cancellation_leaves_no_torrent(tmp_path, tree):
    creator = CancellingCreator(after=2)
    h = make_service(tmp_path, creator=creator)
    job = h.service.start_job(make_draft(tree, tmp_path, start_seeding=True), cancelled=creator.cancelled)
    assert job.state is JobState.CANCELLED
    assert not os.path.exists(job.torrent_path)
    assert os.listdir(tmp_path) == ["src"] or "out.torrent" not in os.listdir(tmp_path)
    assert not [n for n in os.listdir(tmp_path) if n.endswith(".tmp")]
    assert h.gateway.calls == []
    assert h.service.get_job(job.id).state is JobState.CANCELLED
    with pytest.raises(PublishError):
        h.service.share_info(job.id)


def test_cancellation_from_another_thread(tmp_path, tree):
    flag = threading.Event()
    h = make_service(tmp_path)
    flag.set()  # the user pressed Cancel before hashing began
    job = h.service.start_job(make_draft(tree, tmp_path), cancelled=flag.is_set)
    assert job.state is JobState.CANCELLED and not os.path.exists(job.torrent_path)


def test_no_silent_overwrite(tmp_path, tree):
    h = make_service(tmp_path)
    target = tmp_path / "out.torrent"
    target.write_bytes(b"precious")
    with pytest.raises(PublishError) as err:
        h.service.start_job(make_draft(tree, tmp_path))
    assert "already exists" in str(err.value) and target.read_bytes() == b"precious"
    job = completed_job(h, tree, tmp_path, overwrite=True)
    assert target.read_bytes() != b"precious" and LibtorrentCodec().inspect(target.read_bytes()).name == job.name


def test_file_appearing_during_hashing_is_not_overwritten(tmp_path, tree):
    """The exclusive write closes the gap between the pre-check and the save."""
    target = tmp_path / "out.torrent"

    class Racing(CancellingCreator):
        def create(self, request, progress, cancelled):
            made = self._real.create(request, progress, cancelled)
            target.write_bytes(b"someone else wrote this")
            return made

    h = make_service(tmp_path, creator=Racing())
    job = h.service.start_job(make_draft(tree, tmp_path))
    assert job.state is JobState.FAILED and "not overwritten" in job.error
    assert target.read_bytes() == b"someone else wrote this"
    assert not [n for n in os.listdir(tmp_path) if n.endswith(".tmp")]


@pytest.mark.parametrize("exc,needle", [(OSError(5, "Input/output error"), "Input/output error"),
                                        (ValueError("the selected files are empty"), "empty"),
                                        (RuntimeError("boom"), "Unexpected error (RuntimeError)")])
def test_creation_errors_become_failed_jobs(tmp_path, tree, exc, needle):
    h = make_service(tmp_path, creator=ExplodingCreator(exc))
    job = h.service.start_job(make_draft(tree, tmp_path, start_seeding=True))
    assert job.state is JobState.FAILED and needle in job.error
    assert not os.path.exists(job.torrent_path) and h.gateway.calls == []
    assert h.service.get_job(job.id).error == job.error


def test_interrupted_jobs_are_recovered_by_a_new_service_instance(tmp_path, tree):
    db_path = tmp_path / "app.sqlite3"
    db = Database(db_path)
    creator = CancellingCreator(after=1)

    class Crash(BaseException):
        """Simulates the process dying mid-hash (not caught by the service)."""

    def die() -> bool:
        if creator.flag.is_set():
            raise Crash()
        return False

    h = make_service(tmp_path, db=db, creator=creator)
    with pytest.raises(Crash):
        h.service.start_job(make_draft(tree, tmp_path), cancelled=die)
    (job,) = h.service.list_jobs()
    assert job.state is JobState.HASHING  # what a crash leaves behind
    leftover = tmp_path / "out.torrent.k3j2h1.tmp"
    leftover.write_bytes(b"partial")
    db.close()

    db2 = Database(db_path)
    h2 = make_service(tmp_path, db=db2)
    assert h2.service.recover_interrupted() == 1
    recovered = h2.service.get_job(job.id)
    assert recovered.state is JobState.INTERRUPTED and recovered.error.startswith(INTERRUPTED_MESSAGE)
    assert not leftover.exists() and not os.path.exists(recovered.torrent_path)
    assert h2.service.recover_interrupted() == 0  # idempotent
    with pytest.raises(PublishError):
        h2.service.share_info(job.id)
    db2.close()


def test_start_seeding_hands_the_torrent_to_the_gateway_once(tmp_path, tree):
    h = make_service(tmp_path)
    job = completed_job(h, tree, tmp_path, start_seeding=True, category="Datasets", publisher=PUBLISHER)
    (call,) = h.gateway.calls
    assert call.source == "created" and call.paused is False and call.category == "Datasets"
    assert call.save_path == os.path.dirname(tree)  # the parent of the selected folder: files stay in place
    assert call.torrent_data == open(job.torrent_path, "rb").read()
    assert call.manifest_id == job.manifest_id
    assert job.transfer_id == "transfer-1"
    op = job.operation("start_seeding")
    assert op.ok and "verified first" in op.message
    info = h.service.share_info(job.id)
    assert info.seeding_requested and info.seeding_started is True and info.transfer_id == "transfer-1"
    assert h.service.manifests_for_transfer("transfer-1")[0].id == job.manifest_id


def test_single_file_seeding_uses_the_files_folder(tmp_path, tree):
    h = make_service(tmp_path)
    single = os.path.join(tree, "data.bin")
    completed_job(h, single, tmp_path, included_files=["data.bin"], start_seeding=True)
    assert h.gateway.calls[0].save_path == tree


@pytest.mark.parametrize("mode,ok,needle", [("duplicate", True, "already in your transfers"),
                                            ("reject", False, "belongs to another transfer"),
                                            ("crash", False, "could not be added (RuntimeError)")])
def test_seeding_outcomes_are_recorded_without_failing_the_job(tmp_path, tree, mode, ok, needle):
    h = make_service(tmp_path, gateway=FakeTransferGateway(mode))
    job = completed_job(h, tree, tmp_path, start_seeding=True)
    op = h.service.get_job(job.id).operation("start_seeding")
    assert op.ok is ok and needle in op.message
    info = h.service.share_info(job.id)
    assert info.seeding_started is ok
    assert (info.transfer_id == "existing-1") is (mode == "duplicate")


def test_seeding_not_requested_and_no_engine(tmp_path, tree):
    h = make_service(tmp_path, with_gateway=False)
    with pytest.raises(PublishError) as err:
        h.service.start_job(make_draft(tree, tmp_path, start_seeding=True))
    assert "engine is not available" in str(err.value)
    job = completed_job(h, tree, tmp_path)
    info = h.service.share_info(job.id)
    assert info.seeding_requested is False and info.seeding_started is None and info.transfer_id is None


def test_share_info_contents(tmp_path, tree):
    h = make_service(tmp_path)
    job = completed_job(h, tree, tmp_path, publisher=PUBLISHER, trackers_text="udp://t.example:6969/announce")
    info = h.service.share_info(job.id)
    assert info.magnet == job.magnet and info.torrent_file_exists and info.identity == job.identity
    assert info.qr.ok and not info.qr.trimmed and info.qr.svg and info.qr.png
    assert info.publisher_label == "Example Press — self-asserted"
    assert job.magnet in info.share_text and "Example Press" in info.share_text
    assert any("does not host the files" in n for n in info.notes)
    assert any("must stay online" in n for n in info.notes)
    assert any("does not publish it" in n for n in info.notes)
    os.unlink(job.torrent_path)
    assert h.service.share_info(job.id).torrent_file_exists is False


def test_private_job_keeps_tracker_in_qr_and_marks_private(tmp_path, tree):
    h = make_service(tmp_path)
    job = completed_job(h, tree, tmp_path, private=True, trackers_text="https://t.example/announce/PASSKEY123456789")
    info = h.service.share_info(job.id)
    assert info.private and "private" in info.share_text
    assert info.qr.ok and "tr=" in info.qr.payload


def test_manifest_is_stored_locally_signed_and_embedded(tmp_path, tree):
    h = make_service(tmp_path)
    assert h.service.signing_public_key() is None
    job = completed_job(h, tree, tmp_path, publisher=PUBLISHER, sign_manifest=True)
    public = h.service.signing_public_key()
    assert public and h.secrets.get(SECRET_MANIFEST_SIGNING_KEY)
    record = h.service.manifest_for_job(job.id)
    assert record.provenance is Provenance.LOCAL and record.signature_status is SignatureStatus.VALID
    assert record.manifest.identity == job.identity and record.manifest.signature.public_key == public
    assert h.service.assess(record).level is TrustLevel.SIGNED_UNRECOGNISED
    h.service.pin_key(public, "my own key")
    assert h.service.assess(record).level is TrustLevel.PINNED_KEY
    assert h.service.share_info(job.id).publisher_label.endswith("verified against a key you pinned")
    h.service.unpin_key(public)
    assert h.service.pinned_keys() == {}
    # the embedded copy has no identity, is signed separately and is recognised as embedded
    meta = LibtorrentCodec().inspect(open(job.torrent_path, "rb").read())
    embedded = h.service.record_embedded_manifest(meta, transfer_id="t-9")
    assert embedded.provenance is Provenance.EMBEDDED and embedded.manifest.identity is None
    assert embedded.signature_status is SignatureStatus.VALID and embedded.identity == job.identity
    assert h.service.record_embedded_manifest(meta, transfer_id="t-9").id == embedded.id  # idempotent
    kinds = [r.provenance for r in h.service.manifests_for_identity(job.identity)]
    assert kinds == [Provenance.EMBEDDED, Provenance.LOCAL]
    # the private key never reaches SQLite
    dump = "\n".join(str(tuple(r)) for t in ("publish_jobs", "manifests", "pinned_publisher_keys", "settings")
                     for r in h.db.query(f"SELECT * FROM {t}"))
    assert h.secrets.get(SECRET_MANIFEST_SIGNING_KEY) not in dump


def test_unembedded_manifest_stays_out_of_the_torrent(tmp_path, tree):
    h = make_service(tmp_path)
    job = completed_job(h, tree, tmp_path, publisher=PUBLISHER, embed_manifest=False)
    meta = LibtorrentCodec().inspect(open(job.torrent_path, "rb").read())
    assert meta.embedded_manifest == b"" and h.service.record_embedded_manifest(meta) is None
    assert h.service.manifest_for_job(job.id).manifest.publisher == "Example Press"


def test_external_manifests_are_untrusted_and_bound_to_the_expected_torrent(tmp_path, tree):
    h = make_service(tmp_path)
    job = completed_job(h, tree, tmp_path)
    key = generate_signing_key()
    good = sign_manifest(build_manifest(publisher="Someone", created=5, identity=job.identity), key)
    record = h.service.import_manifest(good.canonical_bytes(), identity=job.identity, transfer_id="t-1")
    assert record.provenance is Provenance.EXTERNAL and record.signature_status is SignatureStatus.VALID
    assert h.service.assess(record).label == "signed by unrecognised key (self-asserted)"
    from aureom_torrent.domain.identity import TorrentIdentity

    other = build_manifest(publisher="Someone", created=5, identity=TorrentIdentity("99" * 20, None))
    with pytest.raises(ManifestError) as err:
        h.service.import_manifest(other.canonical_bytes(), identity=job.identity)
    assert "different torrent" in str(err.value)
    with pytest.raises(ManifestError):
        h.service.import_manifest(b'{"schema_version": 1, "publisher": "x", "invoice": "lnbc1..."}')
    assert len(h.service.list_manifests()) == 1
    h.service.delete_manifest(record.id)
    assert h.service.get_manifest(record.id) is None


def test_fetch_manifest_is_bounded_and_reports_failures(tmp_path, tree):
    body = build_manifest(publisher="Remote Press", created=5).canonical_bytes()
    fetcher = FakeFetcher(http_result(200, body))
    h = make_service(tmp_path, fetcher=fetcher)
    record = h.service.fetch_manifest("https://example.org/manifest.json")
    assert record.provenance is Provenance.EXTERNAL and record.manifest.publisher == "Remote Press"
    call = fetcher.calls[0]
    assert call.method == "GET" and call.policy.max_bytes == 16 * 1024 and call.policy.allow_http is False
    for response, needle in ((http_result(404), "HTTP 404"), (FetchTimeout("Timed out contacting x."), "Timed out")):
        h2 = make_service(tmp_path, fetcher=FakeFetcher(response))
        with pytest.raises(PublishError) as err:
            h2.service.fetch_manifest("https://example.org/manifest.json?token=SECRET")
        assert needle in str(err.value) and "SECRET" not in str(err.value)
    with pytest.raises(PublishError):
        make_service(tmp_path).service.fetch_manifest("https://example.org/m.json")  # no fetcher configured


def test_build_artifacts_cover_every_kind(tmp_path, tree):
    h = make_service(tmp_path)
    job = completed_job(h, tree, tmp_path, publisher=PUBLISHER, name="")
    artifacts = {a.kind: a for a in h.service.build_artifacts(job.id, public_torrent_url="https://example.org/o.torrent")}
    assert set(artifacts) == set(ARTIFACT_KINDS)
    assert artifacts["torrent"].content == open(job.torrent_path, "rb").read()
    assert artifacts["torrent"].name == "Open-Data-Pack.torrent"
    assert b"<!doctype html>" in artifacts["page"].content and b"docs/notes.md" in artifacts["page"].content
    assert artifacts["atom"].content.startswith(b"<?xml") and b"o.torrent" in artifacts["atom"].content
    assert artifacts["qr_png"].content.startswith(b"\x89PNG") and b"<svg" in artifacts["qr_svg"].content
    assert json.loads(artifacts["manifest"].content)["publisher"] == "Example Press"
    assert job.magnet.encode() in artifacts["share_text"].content
    with pytest.raises(PublishError):
        h.service.build_artifacts(job.id, ["bogus"])
    with pytest.raises(PublishError):
        h.service.build_artifacts(job.id, public_torrent_url="javascript:alert(1)")
    # without publisher details or the saved file, those artifacts are simply not produced
    job2 = completed_job(h, tree, tmp_path, output_torrent_path=str(tmp_path / "second.torrent"))
    os.unlink(job2.torrent_path)
    kinds = {a.kind for a in h.service.build_artifacts(job2.id)}
    assert kinds == set(ARTIFACT_KINDS) - {"manifest", "torrent"}


def test_publish_records_each_operation_including_failures(tmp_path, tree):
    adapter = FakePublishAdapter({".html": "fail", ".atom.xml": "raise"})
    h = make_service(tmp_path, adapter_factory=lambda dest: adapter)
    job = completed_job(h, tree, tmp_path)
    dest = h.service.save_destination(PublishDestination("", "local_dir", "Fake", {"directory": str(tmp_path / "x")}))
    results = h.service.publish(job.id, dest.id, ["torrent", "page", "atom", "manifest", "qr_png"])
    by_op = {r.operation: r for r in results}
    assert by_op["publish:torrent"].ok and by_op["publish:qr_png"].ok
    assert not by_op["publish:page"].ok and "refused" in by_op["publish:page"].message
    assert not by_op["publish:atom"].ok and "ConnectionError" in by_op["publish:atom"].message
    assert not by_op["publish:manifest"].ok and "Not produced" in by_op["publish:manifest"].message
    assert all(r.destination == "fake destination" and r.ts > 0 for r in results)
    stored = h.service.get_job(job.id)
    assert [o.operation for o in stored.operations][-5:] == [r.operation for r in results]
    assert [o.ok for o in stored.operations if o.operation.startswith("publish:")] == [r.ok for r in results]
    assert tuple(stored.operations) == h.service.share_info(job.id).operations
    assert [name for name, _, _ in adapter.published] == ["Open-Data-Pack.torrent", "Open-Data-Pack.qr.png"]


def test_interrupted_publish_reports_what_was_and_was_not_attempted(tmp_path, tree):
    stop = threading.Event()

    def hang_on_second(name: str) -> None:
        if name.endswith(".html"):
            stop.set()  # the user stops a destination that is not responding

    adapter = FakePublishAdapter(on_publish=hang_on_second)
    h = make_service(tmp_path, adapter_factory=lambda dest: adapter)
    job = completed_job(h, tree, tmp_path)
    dest = h.service.save_destination(PublishDestination("", "local_dir", "Fake", {"directory": str(tmp_path / "x")}))
    results = h.service.publish(job.id, dest.id, ["torrent", "page", "atom", "share_text"], cancelled=stop.is_set)
    assert [(r.operation, r.ok) for r in results] == [("publish:torrent", True), ("publish:page", True),
                                                      ("publish:atom", False), ("publish:share_text", False)]
    assert all("Not attempted" in r.message for r in results[2:])
    assert len([o for o in h.service.get_job(job.id).operations if o.operation.startswith("publish:")]) == 4


def test_adapter_messages_are_redacted_before_they_are_stored(tmp_path, tree):
    adapter = FakePublishAdapter({".torrent": "fail"}, secret="tok_live_ABCDEFGH12345678")
    h = make_service(tmp_path, adapter_factory=lambda dest: adapter)
    job = completed_job(h, tree, tmp_path)
    dest = h.service.save_destination(PublishDestination("", "local_dir", "Fake", {"directory": str(tmp_path / "x")}))
    (res,) = h.service.publish(job.id, dest.id, ["torrent"])
    assert "tok_live" not in res.message and "[redacted]" in res.message


def test_destinations_store_config_but_never_the_token(tmp_path, tree):
    h = make_service(tmp_path)
    token = "upl_SECRET_TOKEN_0123456789"
    dest = h.service.save_destination(
        PublishDestination("", "https_upload", " My server ", {"base_url": "https://files.example.org/drop/"}),
        token=token)
    assert dest.id and dest.name == "My server" and dest.config == {"base_url": "https://files.example.org/drop"}
    assert h.secrets.get(upload_secret_name(dest.id)) == token and h.service.destination_has_token(dest.id)
    raw = "\n".join(str(tuple(r)) for r in h.db.query("SELECT * FROM publish_destinations"))
    assert token not in raw and "files.example.org" in raw
    assert [d.id for d in h.service.list_destinations()] == [dest.id]
    h.service.save_destination(dest, token=None)  # unchanged
    assert h.service.destination_has_token(dest.id)
    h.service.save_destination(dest, token="")  # removed
    assert not h.service.destination_has_token(dest.id)
    h.service.save_destination(dest, token=token)
    h.service.delete_destination(dest.id)
    assert h.service.list_destinations() == [] and h.secrets.get(upload_secret_name(dest.id)) is None


@pytest.mark.parametrize("kind,config,needle", [
    ("s3", {}, "Unknown destination type"),
    ("https_upload", {"base_url": "http://files.example.org/drop"}, "https://"),
    ("https_upload", {"base_url": "https://files.example.org/drop?X-Amz-Signature=abc"}, "query string"),
    ("https_upload", {"base_url": "https://files.example.org/drop", "token": "abc"}, "Unexpected destination settings"),
    ("local_dir", {"directory": "relative/path"}, "absolute folder"),
    ("local_dir", {"directory": "/tmp/x", "password": "p"}, "Unexpected destination settings"),
])
def test_bad_destinations_are_refused(tmp_path, kind, config, needle):
    h = make_service(tmp_path)
    with pytest.raises(PublishError) as err:
        h.service.save_destination(PublishDestination("", kind, "Name", config))
    assert needle in " ".join(err.value.problems)
    assert h.service.list_destinations() == []


def test_publish_to_unknown_destination_or_unfinished_job(tmp_path, tree):
    h = make_service(tmp_path, creator=ExplodingCreator(ValueError("nope")))
    failed = h.service.start_job(make_draft(tree, tmp_path))
    with pytest.raises(PublishError):
        h.service.publish(failed.id, "missing")
    with pytest.raises(PublishError):
        h.service.publish("no-such-job", "missing")
    h2 = make_service(tmp_path)
    job = completed_job(h2, tree, tmp_path)
    with pytest.raises(PublishError) as err:
        h2.service.publish(job.id, "missing")
    assert "destination no longer exists" in str(err.value)


def test_diagnostics_contain_no_secrets(tmp_path, tree):
    token = "upl_SECRET_TOKEN_0123456789"
    passkey = "PASSKEY0123456789ABCDEF"
    h = make_service(tmp_path, creator=None)
    job = completed_job(h, tree, tmp_path, private=True, publisher=PUBLISHER, sign_manifest=True,
                        trackers_text=f"https://tracker.example/announce/{passkey}")
    h.service.save_destination(
        PublishDestination("", "https_upload", "Server", {"base_url": "https://files.example.org/drop"}), token=token)
    failing = make_service(tmp_path, db=h.db, creator=ExplodingCreator(OSError(13, "Permission denied")))
    failing.service.start_job(make_draft(tree, tmp_path, output_torrent_path=str(tmp_path / "b.torrent")))
    diag = h.service.diagnostics()
    text = json.dumps(diag)
    assert diag["jobs_by_state"] == {"completed": 1, "failed": 1}
    assert diag["destinations"] == [{"id": diag["destinations"][0]["id"], "kind": "https_upload", "name": "Server",
                                     "target": "https://files.example.org/drop", "has_token": True}]
    assert diag["signing_key_present"] is True and diag["s3_adapter"] == "not implemented"
    assert diag["manifests_by_provenance"] == {"local": 1}
    for secret in (token, passkey, h.secrets.get(SECRET_MANIFEST_SIGNING_KEY), job.magnet):
        assert secret not in text
    assert "Permission denied" in text  # errors are still useful


def test_delete_job_removes_only_the_record(tmp_path, tree):
    h = make_service(tmp_path)
    job = completed_job(h, tree, tmp_path)
    h.service.delete_job(job.id)
    assert h.service.get_job(job.id) is None and os.path.isfile(job.torrent_path)


def test_settings_may_be_a_store_a_callable_or_a_plain_object(tmp_path, tree):
    from aureom_torrent.publishing.service import PublishService
    from aureom_torrent.engine.libtorrent_codec import LibtorrentCreator
    from aureom_torrent.settings.models import AppSettings
    from aureom_torrent.settings.secrets import MemorySecretStore
    from aureom_torrent.settings.store import SettingsStore

    db = Database(None)
    for source in (AppSettings(), SettingsStore(db), lambda: AppSettings()):
        svc = PublishService(db, LibtorrentCreator(), LibtorrentCodec(), None, MemorySecretStore(), None, source)
        assert svc.destination_problems("https_upload", "x", {"base_url": "http://e.org/x"})  # https-only default
