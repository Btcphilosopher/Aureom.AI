"""LND REST adapter against httpx.MockTransport (request shapes, parsing, error mapping)."""

import base64
import json
import logging

import httpx
import pytest

from aureom_torrent.net.http import HttpPolicy
from aureom_torrent.payments.adapters.lnd_rest import LndRestBackend, hash_to_path_segment
from aureom_torrent.payments.interface import (BackendRejected, BackendUnavailable, IncomingStatus,
                                               OutgoingStatus, PaymentAlreadyKnown, PaymentNotFound,
                                               PaymentOutcomeUnknown)
from aureom_torrent.settings.secrets import SECRET_LND_MACAROON, MemorySecretStore

MACAROON = "0201036c6e6402f801030a10" + "ab" * 40
PREIMAGE = "cd" * 32
HASH = "fb" + "ef" * 30 + "ff"  # standard base64 of this contains '+' and '/': exercises URL-safe encoding
POLICY = HttpPolicy(timeout_s=5, max_bytes=1024 * 1024, max_redirects=0, allow_http=False,
                    allow_loopback=True, allow_private=True)


def backend(handler, *, macaroon=MACAROON, url="https://127.0.0.1:8080", policy=POLICY):
    secrets = MemorySecretStore()
    if macaroon is not None:
        secrets.set(SECRET_LND_MACAROON, macaroon)
    return LndRestBackend(url, secrets=secrets, policy=policy, transport=httpx.MockTransport(handler))


def stream(*objs):
    return httpx.Response(200, content="".join(json.dumps(o) + "\n" for o in objs).encode())


# ------------------------------------------------------------------ configuration
@pytest.mark.parametrize("url", ["", "ftp://127.0.0.1:8080", "http://203.0.113.5:8080", "https://user:pw@127.0.0.1:8080",
                                 "https://127.0.0.1:8080/?x=1", "not a url"])
def test_bad_base_urls_are_refused(url):
    with pytest.raises(BackendUnavailable):
        backend(lambda r: httpx.Response(200), url=url)


def test_plain_http_only_for_loopback_and_policy_is_applied():
    backend(lambda r: httpx.Response(200), url="http://127.0.0.1:8080")
    backend(lambda r: httpx.Response(200), url="http://localhost:8080")
    strict = HttpPolicy(allow_loopback=False, allow_private=False)
    with pytest.raises(BackendUnavailable):
        backend(lambda r: httpx.Response(200), url="https://127.0.0.1:8080", policy=strict)
    with pytest.raises(BackendUnavailable):
        backend(lambda r: httpx.Response(200), url="https://10.0.0.5:8080", policy=strict)
    backend(lambda r: httpx.Response(200), url="https://10.0.0.5:8080")


def test_missing_or_malformed_macaroon():
    with pytest.raises(BackendUnavailable) as err:
        backend(lambda r: httpx.Response(200, json={}), macaroon=None).get_info()
    assert "macaroon" in str(err.value)
    with pytest.raises(BackendUnavailable):
        backend(lambda r: httpx.Response(200, json={}), macaroon="not-hex!").get_info()


# ------------------------------------------------------------------ unary calls
def test_get_info_request_and_parsing():
    seen = {}

    def handler(request: httpx.Request):
        seen["method"], seen["path"] = request.method, request.url.path
        seen["macaroon"] = request.headers.get("Grpc-Metadata-macaroon")
        return httpx.Response(200, json={
            "identity_pubkey": "02" + "AB" * 32, "alias": "alice", "version": "0.21.8-beta commit=x",
            "synced_to_chain": True, "num_active_channels": 2,
            "chains": [{"chain": "bitcoin", "network": "regtest"}]})

    info = backend(handler).get_info()
    assert seen == {"method": "GET", "path": "/v1/getinfo", "macaroon": MACAROON}
    assert (info.alias, info.network, info.synced, info.active_channels) == ("alice", "regtest", True, 2)
    assert info.pubkey == "02" + "ab" * 32 and info.backend == "lnd_rest"


def test_create_invoice_request_and_parsing():
    seen = {}
    r_hash = base64.b64encode(bytes.fromhex(HASH)).decode()

    def handler(request: httpx.Request):
        seen["path"], seen["body"] = request.url.path, json.loads(request.content)
        return httpx.Response(200, json={"r_hash": r_hash, "payment_request": "LNBCRT1EXAMPLE", "add_index": "7"})

    created = backend(handler).create_invoice(21_500, memo="tip jar", expiry_s=600)
    assert seen["path"] == "/v1/invoices"
    assert seen["body"] == {"memo": "tip jar", "value_msat": "21500", "expiry": "600"}  # msat, never "value"
    assert created.payment_hash == HASH and created.payment_request == "lnbcrt1example"
    with pytest.raises(ValueError):
        backend(handler).create_invoice(0, memo="", expiry_s=600)
    with pytest.raises(BackendRejected):
        backend(lambda r: httpx.Response(200, json={"payment_request": "x"})).create_invoice(1, memo="", expiry_s=60)


@pytest.mark.parametrize("state,expected", [("OPEN", IncomingStatus.OPEN), ("SETTLED", IncomingStatus.SETTLED),
                                            ("CANCELED", IncomingStatus.CANCELED),
                                            ("ACCEPTED", IncomingStatus.ACCEPTED)])
def test_lookup_invoice_uses_hex_path(state, expected):
    seen = {}

    def handler(request: httpx.Request):
        seen["path"] = request.url.path
        return httpx.Response(200, json={"state": state, "amt_paid_msat": "9000", "value_msat": "9000",
                                         "creation_date": "1800000000", "expiry": "3600",
                                         "settle_date": "1800000100" if state == "SETTLED" else "0",
                                         "r_preimage": "c2VjcmV0"})

    lookup = backend(handler).lookup_invoice(HASH)
    assert seen["path"] == "/v1/invoice/" + HASH
    assert lookup.status is expected and lookup.amount_paid_msat == 9000 and lookup.expires_at == 1_800_003_600
    assert lookup.settled_at == (1_800_000_100 if state == "SETTLED" else None)
    assert not hasattr(lookup, "preimage")


def test_decode_invoice_path_and_fields():
    seen = {}

    def handler(request: httpx.Request):
        seen["path"] = request.url.path
        return httpx.Response(200, json={"destination": "03" + "aa" * 32, "payment_hash": HASH,
                                         "num_satoshis": "21", "num_msat": "21000", "timestamp": "1800000000",
                                         "expiry": "3600", "description": "coffee", "description_hash": ""})

    decoded = backend(handler).decode_invoice("lnbcrt210n1example")
    assert seen["path"] == "/v1/payreq/lnbcrt210n1example"
    assert decoded.amount_msat == 21_000 and decoded.payment_hash == HASH and decoded.expiry_s == 3600
    assert decoded.description == "coffee"


def test_unary_error_mapping():
    def status(code, body=None):
        return backend(lambda r: httpx.Response(code, json=body or {"code": 2, "message": "boom"}))

    with pytest.raises(PaymentNotFound):
        status(404, {"code": 5, "message": "unable to locate invoice"}).lookup_invoice(HASH)
    with pytest.raises(BackendRejected) as err:
        status(401, {"message": "verification failed"}).get_info()
    assert "macaroon" in str(err.value)
    with pytest.raises(BackendUnavailable):
        status(503).get_info()
    with pytest.raises(BackendRejected):
        status(400, {"message": "invalid argument"}).get_info()
    with pytest.raises(BackendUnavailable):
        status(307).get_info()
    with pytest.raises(BackendRejected):
        backend(lambda r: httpx.Response(200, content=b"<html>")).get_info()
    with pytest.raises(BackendRejected):
        backend(lambda r: httpx.Response(200, json={"num_active_channels": 1.5})).get_info()

    def refuse(request):
        raise httpx.ConnectError("refused", request=request)

    def slow(request):
        raise httpx.ReadTimeout("slow", request=request)

    for handler in (refuse, slow):
        with pytest.raises(BackendUnavailable):
            backend(handler).get_info()


def test_oversized_response_is_refused():
    small = HttpPolicy(timeout_s=5, max_bytes=2048, allow_loopback=True, allow_private=True)
    with pytest.raises(BackendRejected):
        backend(lambda r: httpx.Response(200, json={"alias": "x" * 5000}), policy=small).get_info()


# ------------------------------------------------------------------ SendPaymentV2
def test_pay_invoice_request_shape_and_success_drops_preimage():
    seen = {}

    def handler(request: httpx.Request):
        seen["method"], seen["path"] = request.method, request.url.path
        seen["body"] = json.loads(request.content)
        seen["macaroon"] = request.headers["grpc-metadata-macaroon"]
        return stream({"result": {"payment_hash": HASH, "status": "SUCCEEDED", "fee_msat": "1200",
                                  "value_msat": "21000", "payment_preimage": PREIMAGE,
                                  "failure_reason": "FAILURE_REASON_NONE"}})

    result = backend(handler).pay_invoice("lnbcrt210n1example", amount_msat=None, fee_limit_msat=5_000, timeout_s=45)
    assert seen["method"] == "POST" and seen["path"] == "/v2/router/send" and seen["macaroon"] == MACAROON
    assert seen["body"] == {"payment_request": "lnbcrt210n1example", "fee_limit_msat": "5000",
                            "timeout_seconds": 45, "no_inflight_updates": True}
    assert result.status is OutgoingStatus.SUCCEEDED and result.fee_msat == 1200 and result.amount_msat == 21_000
    assert PREIMAGE not in repr(result) and not hasattr(result, "preimage")


def test_pay_invoice_always_sends_fee_limit_and_amount_only_when_given():
    bodies = []

    def handler(request: httpx.Request):
        bodies.append(json.loads(request.content))
        return stream({"result": {"payment_hash": HASH, "status": "SUCCEEDED"}})

    b = backend(handler)
    b.pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=0, timeout_s=60)
    b.pay_invoice("lnbcrt1x", amount_msat=7_000, fee_limit_msat=10, timeout_s=60)
    assert bodies[0]["fee_limit_msat"] == "0" and "amt_msat" not in bodies[0] and "amt" not in bodies[0]
    assert bodies[1]["amt_msat"] == "7000"
    for bad in (dict(amount_msat=1.5, fee_limit_msat=1), dict(amount_msat=None, fee_limit_msat=-1),
                dict(amount_msat=0, fee_limit_msat=1), dict(amount_msat=None, fee_limit_msat=2.0)):
        with pytest.raises(ValueError):
            b.pay_invoice("lnbcrt1x", timeout_s=60, **bad)
    assert len(bodies) == 2


def test_pay_invoice_failure_and_in_flight_streams():
    failed = backend(lambda r: stream(
        {"result": {"payment_hash": HASH, "status": "IN_FLIGHT"}},
        {"result": {"payment_hash": HASH, "status": "FAILED", "failure_reason": "FAILURE_REASON_NO_ROUTE"}}))
    result = failed.pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=1, timeout_s=60)
    assert result.status is OutgoingStatus.FAILED and result.failure_reason == "FAILURE_REASON_NO_ROUTE"

    # the stream ends while the payment is still in flight -> IN_FLIGHT, not a failure
    flying = backend(lambda r: stream({"result": {"payment_hash": HASH, "status": "INITIATED"}},
                                      {"result": {"payment_hash": HASH, "status": "IN_FLIGHT"}}))
    assert flying.pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=1, timeout_s=60).status \
        is OutgoingStatus.IN_FLIGHT

    # an unwrapped Payment object is tolerated
    bare = backend(lambda r: stream({"payment_hash": HASH, "status": "SUCCEEDED", "fee_msat": 5}))
    assert bare.pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=1, timeout_s=60).fee_msat == 5


def test_pay_invoice_error_mapping():
    def pay(handler):
        return backend(handler).pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=1, timeout_s=60)

    with pytest.raises(PaymentAlreadyKnown):
        pay(lambda r: httpx.Response(409, json={"code": 6, "message": "invoice is already paid"}))
    with pytest.raises(BackendRejected) as err:
        pay(lambda r: httpx.Response(400, json={"code": 3, "message": "invalid payment request lnbcrt1" + "q" * 40}))
    assert "lnbcrt1qqq" not in str(err.value)  # invoices are scrubbed from backend messages
    with pytest.raises(BackendRejected):
        pay(lambda r: httpx.Response(403, json={"message": "permission denied"}))
    # server-side errors are NOT treated as failures: the payment may have started
    for code in (500, 502, 503, 504, 408, 429):
        with pytest.raises(PaymentOutcomeUnknown):
            pay(lambda r, code=code: httpx.Response(code, json={"code": 2, "message": "internal"}))
    # an error line in the middle of the stream, an empty stream, and garbage are all "unknown"
    with pytest.raises(PaymentOutcomeUnknown):
        pay(lambda r: stream({"error": {"code": 2, "message": "stream broke"}}))
    with pytest.raises(PaymentOutcomeUnknown):
        pay(lambda r: httpx.Response(200, content=b""))
    with pytest.raises(PaymentOutcomeUnknown):
        pay(lambda r: httpx.Response(200, content=b"not json\n{\"result\": {\"status\": \"UNKNOWN\"}}\n"))


def test_pay_invoice_timeout_is_unknown_but_connect_failure_is_not_sent():
    def read_timeout(request):
        raise httpx.ReadTimeout("no answer", request=request)

    def dropped(request):
        raise httpx.RemoteProtocolError("peer closed connection", request=request)

    def refused(request):
        raise httpx.ConnectError("connection refused", request=request)

    def connect_timeout(request):
        raise httpx.ConnectTimeout("timed out", request=request)

    for handler in (read_timeout, dropped):
        with pytest.raises(PaymentOutcomeUnknown):
            backend(handler).pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=1, timeout_s=60)
    for handler in (refused, connect_timeout):
        with pytest.raises(BackendUnavailable) as err:
            backend(handler).pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=1, timeout_s=60)
        assert "nothing was sent" in str(err.value)


# ------------------------------------------------------------------ TrackPaymentV2
def test_track_payment_uses_urlsafe_base64_path():
    seen = {}

    def handler(request: httpx.Request):
        seen["raw_path"] = request.url.raw_path.decode()
        seen["method"] = request.method
        return stream({"result": {"payment_hash": HASH, "status": "IN_FLIGHT"}},
                      {"result": {"payment_hash": HASH, "status": "SUCCEEDED"}})

    result = backend(handler).track_payment(HASH)
    segment = hash_to_path_segment(HASH)
    assert segment == base64.urlsafe_b64encode(bytes.fromhex(HASH)).decode()
    standard = base64.b64encode(bytes.fromhex(HASH)).decode()
    assert "+" in standard and "/" in standard
    assert "+" not in segment and "/" not in segment and "_" in segment and "-" in segment
    assert seen["method"] == "GET"
    assert seen["raw_path"] == f"/v2/router/track/{segment}?no_inflight_updates=false"
    assert result.status is OutgoingStatus.IN_FLIGHT  # first update = current state; no waiting for the end
    with pytest.raises(ValueError):
        hash_to_path_segment("xyz")


def test_track_payment_error_mapping():
    def track(handler):
        return backend(handler).track_payment(HASH)

    with pytest.raises(PaymentNotFound):
        track(lambda r: httpx.Response(404, json={"code": 5, "message": "payment isn't initiated"}))
    with pytest.raises(PaymentNotFound):
        track(lambda r: httpx.Response(500, json={"code": 2, "message": "payment isn't initiated"}))
    with pytest.raises(PaymentNotFound):
        track(lambda r: stream({"error": {"code": 5, "message": "not found"}}))
    with pytest.raises(BackendUnavailable):
        track(lambda r: httpx.Response(500, json={"code": 13, "message": "internal"}))
    with pytest.raises(BackendUnavailable):
        track(lambda r: httpx.Response(200, content=b""))
    with pytest.raises(BackendRejected):
        track(lambda r: httpx.Response(403, json={"message": "permission denied"}))

    def slow(request):
        raise httpx.ReadTimeout("slow", request=request)

    with pytest.raises(BackendUnavailable):
        track(slow)


# ------------------------------------------------------------------ secrets hygiene
def test_macaroon_and_preimage_never_reach_logs_or_errors(caplog):
    caplog.set_level(logging.DEBUG)

    def handler(request: httpx.Request):
        if request.url.path == "/v2/router/send":
            return stream({"result": {"payment_hash": HASH, "status": "SUCCEEDED", "payment_preimage": PREIMAGE}})
        return httpx.Response(500, json={"message": f"bad macaroon {MACAROON}"[:60]})

    b = backend(handler)
    b.pay_invoice("lnbcrt1x", amount_msat=None, fee_limit_msat=1, timeout_s=60)
    with pytest.raises(BackendUnavailable) as err:
        b.get_info()
    text = caplog.text + repr(err.value)
    assert PREIMAGE not in text and MACAROON not in text
