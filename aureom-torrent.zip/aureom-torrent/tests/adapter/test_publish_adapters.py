"""Publishing adapters: the local folder adapter and the HTTPS upload adapter against a fake fetcher."""

from __future__ import annotations

import logging
import os

import pytest

from aureom_torrent.net.http import (BlockedDestination, FetchTimeout, HttpPolicy, ResponseTooLarge,
                                     TooManyRedirects, TransportFailure)
from aureom_torrent.publishing.adapters.base import MAX_ARTIFACT_BYTES
from aureom_torrent.publishing.adapters.https_upload import HttpsUploadAdapter
from aureom_torrent.publishing.adapters.local_dir import LocalDirAdapter
from aureom_torrent.publishing.models import JobState, PublishDestination
from tests.fakes.publishing import FakeFetcher, http_result, make_draft, make_service, make_tree

TOKEN = "upl_SECRET_TOKEN_0123456789"
POLICY = HttpPolicy(timeout_s=5, max_bytes=1024 * 1024, max_redirects=5, allow_http=False)


# -- local folder -------------------------------------------------------------------

def test_local_dir_writes_atomically_and_says_it_is_not_hosting(tmp_path):
    adapter = LocalDirAdapter(str(tmp_path / "export" / "nested"))
    res = adapter.publish("page.html", b"<html></html>", "text/html")
    assert res.ok and "not public hosting" in res.message and res.operation == "publish:page.html"
    assert (tmp_path / "export" / "nested" / "page.html").read_bytes() == b"<html></html>"
    assert adapter.publish("page.html", b"v2", "text/html").ok  # replaced by default
    assert sorted(os.listdir(tmp_path / "export" / "nested")) == ["page.html"]  # no temp files left
    assert "local folder" in adapter.describe()


@pytest.mark.parametrize("name", ["../escape.html", "/etc/passwd", "a/b.html", ".hidden", "x\x00.html", ""])
def test_local_dir_rejects_unsafe_names(tmp_path, name):
    adapter = LocalDirAdapter(str(tmp_path / "export"))
    res = adapter.publish(name, b"x", "text/plain")
    assert not res.ok and "not a safe file name" in res.message
    assert not (tmp_path / "escape.html").exists()
    assert not (tmp_path / "export").exists() or os.listdir(tmp_path / "export") == []


def test_local_dir_failure_modes(tmp_path):
    export = tmp_path / "export"
    adapter = LocalDirAdapter(str(export), overwrite=False)
    assert adapter.publish("a.txt", b"1", "text/plain").ok
    again = adapter.publish("a.txt", b"2", "text/plain")
    assert not again.ok and "already exists" in again.message and (export / "a.txt").read_bytes() == b"1"
    (export / "dir.txt").mkdir()
    assert not LocalDirAdapter(str(export)).publish("dir.txt", b"x", "text/plain").ok
    too_big = LocalDirAdapter(str(export)).publish("big.bin", b"\0" * (MAX_ARTIFACT_BYTES + 1), "x/y")
    assert not too_big.ok and "32 MiB" in too_big.message
    blocker = tmp_path / "file"
    blocker.write_text("x")
    res = LocalDirAdapter(str(blocker / "sub")).publish("a.txt", b"x", "text/plain")
    assert not res.ok and "Could not write" in res.message


def test_local_dir_replaces_a_planted_symlink_instead_of_following_it(tmp_path):
    export = tmp_path / "export"
    export.mkdir()
    victim = tmp_path / "victim.txt"
    victim.write_text("untouched")
    os.symlink(victim, export / "page.html")
    assert LocalDirAdapter(str(export)).publish("page.html", b"new", "text/html").ok
    assert victim.read_text() == "untouched"
    assert not os.path.islink(export / "page.html") and (export / "page.html").read_bytes() == b"new"


def test_local_dir_config_validation(tmp_path):
    assert LocalDirAdapter.config_problems({"directory": str(tmp_path)}) == []
    assert LocalDirAdapter.config_problems({"directory": "relative"})
    assert LocalDirAdapter.config_problems({})
    f = tmp_path / "f"
    f.write_text("x")
    assert LocalDirAdapter.config_problems({"directory": str(f)})


# -- HTTPS upload (fake fetcher) -------------------------------------------------------

def upload(fetcher, *, base="https://files.example.org/drop/", policy=POLICY, token=TOKEN, name="open.torrent",
           content=b"data"):
    adapter = HttpsUploadAdapter(base, fetcher=fetcher, policy=policy, token=token)
    return adapter, adapter.publish(name, content, "application/x-bittorrent")


def test_upload_is_a_put_with_bearer_token_and_no_redirects():
    fetcher = FakeFetcher(http_result(201))
    adapter, res = upload(fetcher)
    assert res.ok and "HTTP 201" in res.message
    assert "does not prove it is publicly reachable" in res.message
    (call,) = fetcher.calls
    assert call.method == "PUT" and call.url == "https://files.example.org/drop/open.torrent"
    assert call.body == b"data"
    assert call.headers == {"Content-Type": "application/x-bittorrent", "Authorization": f"Bearer {TOKEN}"}
    assert call.policy.max_redirects == 0 and call.policy.allow_http is False
    assert call.policy.allow_loopback is False and call.policy.allow_private is False
    assert call.policy.max_bytes <= 64 * 1024  # the response is bounded tightly
    assert adapter.describe() == "upload to https://files.example.org/drop"
    assert TOKEN not in res.message and TOKEN not in adapter.describe()


def test_upload_without_token_sends_no_authorization_header():
    fetcher = FakeFetcher(http_result(204))
    _, res = upload(fetcher, token=None)
    assert res.ok and "Authorization" not in fetcher.calls[0].headers


@pytest.mark.parametrize("status,needle", [(401, "rejected the credentials"), (403, "rejected the credentials"),
                                           (404, "not found"), (413, "too large"), (500, "refused the upload"),
                                           (302, "redirect")])
def test_upload_http_failures_are_explained(status, needle):
    _, res = upload(FakeFetcher(http_result(status)))
    assert not res.ok and needle in res.message and f"HTTP {status}" in res.message
    assert TOKEN not in res.message


@pytest.mark.parametrize("exc,needle", [
    (FetchTimeout("Timed out contacting https://files.example.org/drop/open.torrent."), "Timed out"),
    (ResponseTooLarge("The response is larger than the 65,536-byte limit."), "larger than"),
    (TooManyRedirects("The server redirected an upload; redirects are not followed for uploads."), "redirect"),
    (BlockedDestination("“10.0.0.5” is a private-network address, which is not allowed for this service."), "private"),
    (TransportFailure("The configured proxy refused or failed the connection (no direct connection was attempted)."),
     "no direct connection"),
    (RuntimeError("unexpected"), "RuntimeError"),
])
def test_upload_transport_failures_are_results_not_exceptions(exc, needle, caplog):
    with caplog.at_level(logging.WARNING, logger="aureom_torrent"):
        _, res = upload(FakeFetcher(exc))
    assert not res.ok and needle in res.message
    assert TOKEN not in caplog.text and TOKEN not in res.message


def test_upload_refuses_http_bad_names_and_oversize_before_any_request():
    fetcher = FakeFetcher(http_result(201))
    _, res = upload(fetcher, base="http://files.example.org/drop")
    assert not res.ok and "https://" in res.message
    _, res = upload(fetcher, name="../../etc/passwd")
    assert not res.ok and "not a safe file name" in res.message
    _, res = upload(fetcher, content=b"\0" * (MAX_ARTIFACT_BYTES + 1))
    assert not res.ok and "32 MiB" in res.message
    _, res = upload(fetcher, base="https://files.example.org/drop?sig=abc")
    assert not res.ok and "query string" in res.message
    assert fetcher.calls == []
    # http is possible only when the user's publishing network settings allow it
    lax = HttpPolicy(allow_http=True)
    _, res = upload(fetcher, base="http://files.example.org/drop", policy=lax)
    assert res.ok and fetcher.calls[0].policy.allow_http is True


def test_proxy_setting_is_passed_through_never_dropped():
    fetcher = FakeFetcher(http_result(200))
    policy = HttpPolicy(allow_http=False, proxy_url="socks5://127.0.0.1:9050")
    upload(fetcher, policy=policy)
    assert fetcher.calls[0].policy.proxy_url == "socks5://127.0.0.1:9050"


# -- through the service -------------------------------------------------------------------

def test_service_publishes_through_a_stored_https_destination(tmp_path, caplog):
    fetcher = FakeFetcher(http_result(201), http_result(401), http_result(201))
    h = make_service(tmp_path, fetcher=fetcher)
    job = h.service.start_job(make_draft(make_tree(tmp_path / "src"), tmp_path))
    assert job.state is JobState.COMPLETED
    dest = h.service.save_destination(
        PublishDestination("", "https_upload", "Server", {"base_url": "https://files.example.org/drop"}), token=TOKEN)
    with caplog.at_level(logging.DEBUG, logger="aureom_torrent"):
        results = h.service.publish(job.id, dest.id, ["torrent", "page", "share_text"])
    assert [(r.operation, r.ok) for r in results] == [("publish:torrent", True), ("publish:page", False),
                                                      ("publish:share_text", True)]
    assert all(r.destination == "upload to https://files.example.org/drop" for r in results)
    assert [c.url for c in fetcher.calls] == [
        "https://files.example.org/drop/Open-Data-Pack.torrent",
        "https://files.example.org/drop/Open-Data-Pack.html",
        "https://files.example.org/drop/Open-Data-Pack.txt"]
    assert all(c.headers["Authorization"] == f"Bearer {TOKEN}" and c.method == "PUT" for c in fetcher.calls)
    assert fetcher.calls[1].headers["Content-Type"].startswith("text/html")
    stored = [o for o in h.service.get_job(job.id).operations if o.operation.startswith("publish:")]
    assert [o.ok for o in stored] == [True, False, True]
    blob = caplog.text + " ".join(o.message + o.destination for o in stored)
    assert TOKEN not in blob


def test_service_local_destination_writes_real_files(tmp_path):
    h = make_service(tmp_path)
    job = h.service.start_job(make_draft(make_tree(tmp_path / "src"), tmp_path))
    out = tmp_path / "site"
    dest = h.service.save_destination(PublishDestination("", "local_dir", "Site folder", {"directory": str(out)}))
    results = h.service.publish(job.id, dest.id, ["torrent", "page", "atom", "qr_svg", "qr_png", "share_text"])
    assert all(r.ok for r in results), [r.message for r in results if not r.ok]
    assert sorted(os.listdir(out)) == ["Open-Data-Pack.atom.xml", "Open-Data-Pack.html", "Open-Data-Pack.qr.png",
                                       "Open-Data-Pack.qr.svg", "Open-Data-Pack.torrent", "Open-Data-Pack.txt"]
    assert (out / "Open-Data-Pack.torrent").read_bytes() == open(job.torrent_path, "rb").read()


def test_export_to_default_directory(tmp_path):
    h = make_service(tmp_path)
    job = h.service.start_job(make_draft(make_tree(tmp_path / "src"), tmp_path))
    results = h.service.export_to_directory(job.id, kinds=["page", "share_text"])
    assert all(r.ok for r in results)
    assert sorted(os.listdir(os.path.join(h.exports_dir, "Open-Data-Pack"))) == ["Open-Data-Pack.html",
                                                                                 "Open-Data-Pack.txt"]
    page = open(os.path.join(h.exports_dir, "Open-Data-Pack", "Open-Data-Pack.html"), encoding="utf-8").read()
    assert "Exporting it does not publish it or host the files." in page
