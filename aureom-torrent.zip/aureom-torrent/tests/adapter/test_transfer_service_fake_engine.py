"""Transfer service against the fake engine: delayed alerts, metadata retrieval, failed moves,
queue rules, restart recovery and shutdown – without any networking."""

from __future__ import annotations

import datetime as dt
import os

import pytest

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.domain.transfers import EnginePhase, TransferState
from aureom_torrent.engine import commands as c
from aureom_torrent.engine import events as e
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec
from aureom_torrent.persistence.database import Database
from aureom_torrent.services.event_pump import EventPump
from aureom_torrent.services.interfaces import AddRejected
from aureom_torrent.services.transfer_service import OperationRejected, TransferService
from aureom_torrent.settings.models import BandwidthSchedule
from aureom_torrent.settings.paths import AppPaths
from aureom_torrent.settings.store import SettingsStore
from tests.fakes.engine import FakeClock, FakeEngine, status
from tests.support import create_torrent, make_payload


class Harness:
    def __init__(self, home, engine=None, clock=None):
        self.home = home
        self.paths = AppPaths(home)
        self.paths.ensure()
        self.db = Database(self.paths.database)
        self.settings = SettingsStore(self.db)
        self.engine = engine or FakeEngine()
        self.clock = clock or FakeClock()
        self.service = TransferService(self.db, self.engine, LibtorrentCodec(), self.paths, self.settings.get,
                                       self.clock, isolated=True)
        self.pump = EventPump(self.service.handle_event)
        self.notes = []
        self.service.subscribe(lambda kind, payload: self.notes.append((kind, payload)))
        self.engine.start(self.service.current_engine_settings(), self.pump.post)
        self.restored = self.service.restore()
        self.pump.drain()

    def deliver(self, *events):
        self.engine.deliver(*events)
        self.pump.drain()

    def view(self, tid):
        return next((v for v in self.service.snapshot()[1] if v.id == tid), None)

    def kinds(self):
        return [k for k, _ in self.notes]

    def close(self):
        self.service.prepare_shutdown()
        report = self.engine.shutdown(1.0)
        self.pump.drain()
        self.db.close()
        return report


@pytest.fixture
def torrent(tmp_path):
    payload = make_payload(tmp_path / "src" / "payload", {"a.bin": 40_000, "sub/b.bin": 20_000})
    return create_torrent(payload, "hybrid")


@pytest.fixture
def h(tmp_path):
    harness = Harness(tmp_path / "home")
    yield harness
    harness.db.close()


def add(h, torrent, tmp_path, **kw):
    dest = tmp_path / "dl"
    dest.mkdir(exist_ok=True)
    out = h.service.add_torrent_data(torrent.torrent_data, save_path=str(dest), **kw)
    h.deliver(e.TorrentAdded(out.transfer_id, torrent.metadata.identity, torrent.metadata.name, True))
    return out.transfer_id


# --------------------------------------------------------------- delayed alerts
def test_view_before_and_after_delayed_engine_events(h, torrent, tmp_path):
    out = h.service.add_torrent_data(torrent.torrent_data, save_path=str(tmp_path))
    view = h.view(out.transfer_id)
    assert view.state is TransferState.ADDED and not view.live and view.progress_ppm == 0
    add_cmd = h.engine.last(c.AddTorrent)
    assert add_cmd.torrent_data == torrent.torrent_data and not add_cmd.paused and not add_cmd.metadata_only

    # status arrives long after; nothing is assumed in between
    h.deliver(e.StatusBatch((status(out.transfer_id, total_wanted=60_000, wanted_done=30_000, download_rate=5000,
                                    num_peers=1),)))
    view = h.view(out.transfer_id)
    assert view.live and view.state is TransferState.DOWNLOADING and view.progress_ppm == 500_000
    assert not view.selected_complete


def test_events_for_unknown_or_removed_transfers_are_ignored(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    h.service.remove([tid])
    assert h.view(tid).state_detail == "Removing…"
    # late events racing with the removal must not resurrect or crash
    h.deliver(e.StatusBatch((status(tid, wanted_done=10),)), e.ResumeDataReady(tid, b"late"),
              e.TorrentFinished("f" * 32), e.StorageMoved("f" * 32, "/x"), e.MetadataReceived("f" * 32, torrent.metadata))
    assert h.view(tid) is None
    assert not h.paths.resume_dir.joinpath(f"{tid}.fastresume").exists()
    assert ("removed", {"transfer_id": tid, "name": "payload", "deleted": False}) in h.notes


def test_add_failure_reported_by_engine_becomes_error_state(h, torrent, tmp_path):
    out = h.service.add_torrent_data(torrent.torrent_data, save_path=str(tmp_path))
    h.deliver(e.TorrentAddFailed(out.transfer_id, "The engine refused this torrent: invalid"))
    view = h.view(out.transfer_id)
    assert view.state is TransferState.ERROR and "refused" in view.error and "error" in h.kinds()


def test_finished_only_when_engine_says_so(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    h.deliver(e.StatusBatch((status(tid, total_wanted=60_000, wanted_done=59_999),)))
    assert h.view(tid).progress_ppm < 1_000_000 and h.service.record(tid).completed_at is None
    h.deliver(e.TorrentFinished(tid),
              e.StatusBatch((status(tid, total_wanted=60_000, wanted_done=60_000, is_finished=True, is_seeding=True,
                                    phase=EnginePhase.SEEDING),)))
    view = h.view(tid)
    assert view.state is TransferState.SEEDING and view.torrent_complete and view.progress_ppm == 1_000_000
    assert h.service.record(tid).completed_at == int(h.clock.now())


# ---------------------------------------------------------- metadata retrieval
def test_magnet_preview_flow(h, torrent, tmp_path):
    magnet = LibtorrentCodec().make_magnet(torrent.torrent_data)
    out = h.service.add_magnet(magnet, save_path=str(tmp_path / "dl"), preview=True)
    tid = out.transfer_id
    cmd = h.engine.last(c.AddTorrent)
    assert cmd.metadata_only and cmd.save_path == str(h.paths.staging_dir) and cmd.torrent_data is None
    h.deliver(e.TorrentAdded(tid, torrent.metadata.identity, "payload", False),
              e.StatusBatch((status(tid, has_metadata=False, phase=EnginePhase.DOWNLOADING_METADATA, total=0,
                                    total_wanted=0, upload_mode=True),)))
    assert h.view(tid).state is TransferState.RETRIEVING_METADATA

    with pytest.raises(OperationRejected):  # files cannot be chosen before metadata exists
        h.service.confirm_preview(tid, save_path=str(tmp_path / "dl"), file_priorities=[4, 0])

    h.deliver(e.MetadataReceived(tid, torrent.metadata, None),
              e.StatusBatch((status(tid, upload_mode=True, total=60_000, total_wanted=60_000),)))
    assert ("preview_ready", {"transfer_id": tid, "name": "payload"}) in h.notes
    view = h.view(tid)
    assert view.preview and view.state is TransferState.PAUSED and view.progress_ppm == 0
    assert not (tmp_path / "dl").exists()  # nothing created before the user confirms

    priorities = [4 if f.path.endswith("a.bin") else 0 for f in torrent.metadata.files]
    h.service.confirm_preview(tid, save_path=str(tmp_path / "dl"), file_priorities=priorities, category="Docs")
    confirm = h.engine.last(c.ConfirmPreview)
    assert confirm.save_path == str(tmp_path / "dl") and list(confirm.file_priorities) == priorities
    assert h.service.record(tid).preview  # still a preview until the engine confirms
    h.deliver()  # StorageMoved acknowledgement
    record = h.service.record(tid)
    assert not record.preview and record.save_path == str(tmp_path / "dl") and record.category == "Docs"
    assert record.file_priorities == priorities
    assert not h.view(tid).live  # the pre-confirmation status was discarded


def test_failed_preview_confirmation_keeps_the_preview(h, torrent, tmp_path):
    magnet = LibtorrentCodec().make_magnet(torrent.torrent_data)
    tid = h.service.add_magnet(magnet, save_path=str(tmp_path / "dl"), preview=True).transfer_id
    h.deliver(e.MetadataReceived(tid, torrent.metadata, None))
    h.engine.fail_moves = True
    h.service.confirm_preview(tid, save_path=str(tmp_path / "dl"))
    h.deliver()
    assert h.service.record(tid).preview and "error" in h.kinds()


def test_unsafe_metadata_from_magnet_is_refused(h, torrent, tmp_path):
    from dataclasses import replace

    tid = h.service.add_magnet(LibtorrentCodec().make_magnet(torrent.torrent_data), save_path=str(tmp_path)).transfer_id
    bad = replace(torrent.metadata, path_problems=("the metadata contains 1 unsafe path component(s)",))
    h.deliver(e.MetadataReceived(tid, bad, None))
    assert isinstance(h.engine.last(c.PauseTorrent), c.PauseTorrent)
    record = h.service.record(tid)
    assert record.manual_paused and "unsafe" in record.last_error and not record.has_metadata


def test_unsafe_torrent_file_is_rejected_before_reaching_the_engine(h, tmp_path):
    import libtorrent as lt

    evil = lt.bencode({b"info": {b"name": b"x", b"piece length": 16384, b"pieces": b"a" * 20,
                                 b"files": [{b"length": 5, b"path": [b"..", b"..", b"etc", b"passwd"]}]}})
    with pytest.raises(AddRejected) as err:
        h.service.add_torrent_data(evil, save_path=str(tmp_path))
    assert err.value.reason == "unsafe_paths" and not h.engine.of(c.AddTorrent)
    with pytest.raises(AddRejected) as err:
        h.service.add_torrent_data(b"not a torrent", save_path=str(tmp_path))
    assert err.value.reason == "invalid"
    with pytest.raises(AddRejected) as err:
        h.service.add_magnet("magnet:?dn=nothing", save_path=str(tmp_path))
    assert err.value.reason == "invalid"


def test_hybrid_revealed_by_metadata_removes_newer_duplicate(h, torrent, tmp_path):
    ident = torrent.metadata.identity
    codec = LibtorrentCodec()
    a = h.service.add_magnet(codec.magnet_for(TorrentIdentity(ident.v1, None)), save_path=str(tmp_path)).transfer_id
    h.clock.advance(5)
    b = h.service.add_magnet(codec.magnet_for(TorrentIdentity(None, ident.v2)), save_path=str(tmp_path)).transfer_id
    assert a != b and len(h.service.snapshot()[1]) == 2  # indistinguishable until metadata arrives
    h.deliver(e.MetadataReceived(b, torrent.metadata, None))
    removal = h.engine.last(c.RemoveTorrent)
    assert removal.transfer_id == b and not removal.delete_files
    h.deliver()
    assert [v.id for v in h.service.snapshot()[1]] == [a]


# ------------------------------------------------------------------ moves
def test_failed_move_keeps_persisted_destination(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    original = h.service.record(tid).save_path
    h.engine.fail_moves = True
    h.service.move_storage(tid, str(tmp_path / "elsewhere"))
    with pytest.raises(OperationRejected, match="already in progress"):
        h.service.move_storage(tid, str(tmp_path / "third"))
    assert h.service.record(tid).save_path == original
    h.deliver()
    assert h.service.record(tid).save_path == original
    assert any(k == "error" and "Permission denied" in p["message"] for k, p in h.notes)
    # a later successful move is persisted only on the engine event
    h.engine.fail_moves = False
    h.service.move_storage(tid, str(tmp_path / "elsewhere"))
    assert h.service.record(tid).save_path == original
    h.deliver()
    assert h.service.record(tid).save_path == str(tmp_path / "elsewhere")
    with pytest.raises(OperationRejected, match="already stored"):
        h.service.move_storage(tid, str(tmp_path / "elsewhere"))


# ------------------------------------------------------------ queue rules
def test_manual_pause_beats_schedule_and_survives_restart(tmp_path, torrent):
    h = Harness(tmp_path / "home")
    tid = add(h, torrent, tmp_path)
    other = create_torrent(make_payload(tmp_path / "src2" / "other", {"x.bin": 30_000}, seed="o"), "v1")
    tid2 = h.service.add_torrent_data(other.torrent_data, save_path=str(tmp_path / "dl")).transfer_id
    h.service.pause([tid])
    assert h.engine.last(c.PauseTorrent).transfer_id == tid and h.service.record(tid).manual_paused

    # a "pause all" schedule starts and ends: only the session is paused/resumed, never single transfers
    settings = h.settings.snapshot()
    now = dt.datetime.fromtimestamp(h.clock.now())
    start = now.hour * 60 + now.minute
    settings.queue.schedules = [BandwidthSchedule(name="quiet", days=list(range(7)), start_minute=start,
                                                  end_minute=(start + 30) % 1440, pause_all=True)]
    h.settings.save(settings)
    h.engine.clear()
    h.service.apply_settings()
    assert h.engine.last(c.SetSessionPaused).paused and not h.engine.of(c.ResumeTorrent)
    h.clock.advance(45 * 60)
    h.engine.clear()
    h.service.tick()
    assert h.engine.last(c.SetSessionPaused).paused is False
    assert not h.engine.of(c.ResumeTorrent) and not h.engine.of(c.PauseTorrent)
    assert h.service.record(tid).manual_paused
    h.deliver(e.StatusBatch((status(tid, paused=True, auto_managed=False), status(tid2, download_rate=9000, num_peers=1))))
    assert h.view(tid).state is TransferState.PAUSED and h.view(tid2).state is TransferState.DOWNLOADING
    h.close()

    # restart: the pause intention is restored from the database, whatever the resume data says
    h2 = Harness(tmp_path / "home")
    added = {cmd.transfer_id: cmd for cmd in h2.engine.of(c.AddTorrent)}
    assert h2.restored == 2 and added[tid].paused and not added[tid2].paused
    assert added[tid].torrent_data == torrent.torrent_data
    assert h2.view(tid).manual_paused
    h2.db.close()


def test_seeding_limit_stops_and_manual_start_lifts_it(h, torrent, tmp_path):
    settings = h.settings.snapshot()
    settings.queue.ratio_limit_permille = 1500
    h.settings.save(settings)
    tid = add(h, torrent, tmp_path)
    seeding = dict(is_finished=True, is_seeding=True, phase=EnginePhase.SEEDING, total_wanted=60_000,
                   wanted_done=60_000, all_time_download=60_000)
    h.deliver(e.StatusBatch((status(tid, all_time_upload=80_000, **seeding),)))
    assert not h.engine.of(c.PauseTorrent)
    h.deliver(e.StatusBatch((status(tid, all_time_upload=90_000, **seeding),)))
    assert h.engine.last(c.PauseTorrent).transfer_id == tid
    record = h.service.record(tid)
    assert record.stopped_by_limit and not record.manual_paused
    h.deliver(e.StatusBatch((status(tid, all_time_upload=90_000, paused=True, auto_managed=False, **seeding),)))
    view = h.view(tid)
    assert view.state is TransferState.COMPLETED and "limit" in view.state_detail.lower()

    h.service.resume([tid])
    record = h.service.record(tid)
    assert not record.stopped_by_limit and record.ratio_limit_permille == -1
    h.engine.clear()
    h.deliver(e.StatusBatch((status(tid, all_time_upload=200_000, **seeding),)))
    assert not h.engine.of(c.PauseTorrent)  # not stopped again behind the user's back


def test_manually_paused_seed_is_not_touched_by_limits(h, torrent, tmp_path):
    settings = h.settings.snapshot()
    settings.queue.seed_time_limit_minutes = 1
    h.settings.save(settings)
    tid = add(h, torrent, tmp_path)
    h.service.pause([tid])
    h.engine.clear()
    h.deliver(e.StatusBatch((status(tid, is_finished=True, paused=True, auto_managed=False, seeding_seconds=9999),)))
    assert not h.engine.commands and not h.service.record(tid).stopped_by_limit


def test_limits_and_trackers_validation(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    h.service.set_limits(tid, download_limit=50_000, upload_limit=0, ratio_limit_permille=2000, seed_time_limit_s=None)
    assert h.engine.last(c.SetTorrentLimits) == c.SetTorrentLimits(tid, 50_000, 0)
    record = h.service.record(tid)
    assert record.ratio_limit_permille == 2000 and record.seed_time_limit_s is None
    h.service.replace_trackers(tid, [("udp://t.example:1/announce", 0), ("https://t2.example/a?passkey=SECRETKEY1234567", 1)])
    assert len(h.engine.last(c.ReplaceTrackers).trackers) == 2
    with pytest.raises(OperationRejected) as err:
        h.service.replace_trackers(tid, [("ftp://bad.example/a?passkey=SECRETKEY1234567", 0)])
    assert "SECRETKEY1234567" not in str(err.value)
    with pytest.raises(OperationRejected):
        h.service.set_file_priorities(tid, [1])


def test_tracker_results_are_recorded_without_passkeys(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    url = "https://tracker.example/announce?passkey=abcdef0123456789abcdef"
    h.deliver(e.TrackerAnnounced(tid, url, False, "Connection refused"), e.TrackerAnnounced(tid, url, False, "Connection refused"),
              e.TrackerAnnounced(tid, url, True, "", 7))
    announce = h.view(tid).last_announce
    assert announce["ok"] and announce["peers"] == 7 and "abcdef0123456789abcdef" not in announce["url"]
    log = h.service.activity(tid)
    assert sum("Announce failed" in m for _, _, _, m in log) == 1  # state changes only: bounded noise
    assert all("abcdef0123456789abcdef" not in m for _, _, _, m in log)


def test_storage_errors_are_translated_and_deduplicated(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    h.deliver(e.TorrentErrored(tid, "No space left on device", "/dl/payload/a.bin"),
              e.TorrentErrored(tid, "No space left on device", "/dl/payload/a.bin"))
    assert h.service.record(tid).last_error.startswith("The disk is full")
    assert h.kinds().count("error") == 1
    h.deliver(e.StatusBatch((status(tid, paused=True, auto_managed=False),)))
    assert h.view(tid).state is TransferState.ERROR
    h.service.resume([tid])
    assert h.service.record(tid).last_error == "" and h.engine.last(c.ResumeTorrent).transfer_id == tid


# ------------------------------------------------------- remove / delete
def test_delete_is_validated_before_anything_is_removed(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    dest = tmp_path / "dl"
    outside = tmp_path / "outside"
    outside.mkdir()
    (dest / "payload").mkdir()
    os.symlink(outside, dest / "payload" / "sub")
    with pytest.raises(OperationRejected, match="not deleted"):
        h.service.remove([tid], delete_data=True)
    assert not h.engine.of(c.RemoveTorrent) and h.view(tid) is not None
    os.unlink(dest / "payload" / "sub")
    h.service.remove([tid], delete_data=True)
    assert h.engine.last(c.RemoveTorrent) == c.RemoveTorrent(tid, delete_files=True)
    h.deliver(e.FilesDeleteFailed(tid, "Directory not empty"))
    assert h.view(tid) is None
    assert any(k == "info" and "other files" in p["message"] for k, p in h.notes)


def test_removing_a_preview_never_deletes_data(h, torrent, tmp_path):
    tid = h.service.add_magnet(LibtorrentCodec().make_magnet(torrent.torrent_data), save_path=str(tmp_path),
                               preview=True).transfer_id
    h.service.remove([tid], delete_data=True)
    assert h.engine.last(c.RemoveTorrent) == c.RemoveTorrent(tid, delete_files=False)


# --------------------------------------------------------- restart recovery
def test_restore_passes_resume_data_and_notes_engine_change(tmp_path, torrent):
    h = Harness(tmp_path / "home")
    tid = add(h, torrent, tmp_path)
    h.deliver(e.ResumeDataReady(tid, b"resume-bytes-v1"), e.ResumeDataReady(tid, b"resume-bytes-v2"),
              e.StatusBatch((status(tid, total_wanted=60_000, wanted_done=30_000, all_time_download=30_000),)))
    h.close()

    h2 = Harness(tmp_path / "home", engine=FakeEngine(version="fake-2.0"))
    cmd = h2.engine.last(c.AddTorrent)
    assert cmd.resume_data == b"resume-bytes-v2" and cmd.torrent_data == torrent.torrent_data
    assert cmd.save_path == str(tmp_path / "dl")
    assert any("changed from fake-1.0 to fake-2.0" in note for note in h2.service.startup_notes)
    view = h2.view(tid)
    assert not view.live and view.progress_ppm == 500_000  # last persisted progress shown until the engine reports
    assert view.state is TransferState.QUEUED  # never "downloading" without a live engine status
    h2.db.close()


def test_restore_with_nothing_to_recover_from_is_an_error_not_a_crash(tmp_path, torrent):
    h = Harness(tmp_path / "home")
    tid = add(h, torrent, tmp_path)
    h.close()
    h.paths.torrents_dir.joinpath(f"{tid}.torrent").unlink()
    h2 = Harness(tmp_path / "home")
    assert not h2.engine.of(c.AddTorrent)
    view = h2.view(tid)
    assert view.state is TransferState.ERROR and "Remove it" in view.error
    h2.service.remove([tid])
    h2.deliver()
    assert h2.view(tid) is None
    h2.db.close()


def test_unreadable_stored_torrent_falls_back_to_magnet(tmp_path, torrent):
    h = Harness(tmp_path / "home")
    magnet = LibtorrentCodec().make_magnet(torrent.torrent_data)
    tid = h.service.add_magnet(magnet, save_path=str(tmp_path / "dl")).transfer_id
    h.deliver(e.MetadataReceived(tid, torrent.metadata, torrent.torrent_data))
    h.close()
    h.paths.torrents_dir.joinpath(f"{tid}.torrent").write_bytes(b"garbage")
    h2 = Harness(tmp_path / "home")
    cmd = h2.engine.last(c.AddTorrent)
    assert cmd.torrent_data is None and cmd.magnet_uri and cmd.magnet_uri.startswith("magnet:?")
    h2.db.close()


# ---------------------------------------------------------------- shutdown
def test_shutdown_reports_unsaved_resume_state(tmp_path, torrent):
    h = Harness(tmp_path / "home")
    tid = add(h, torrent, tmp_path)
    h.engine.shutdown_result = e.ShutdownReport(clean=False, resume_saved=0, resume_unsaved=(tid,),
                                                message="Resume data for 1 transfer(s) was not written")
    report = h.close()
    assert not report.clean and report.resume_unsaved == (tid,)
    assert h.engine.shutdown_timeout == 1.0
    assert h.service.shutdown_report is report
    assert h.service.diagnostics()["shutdown_report"]["unsaved"] == 1


def test_export_and_magnet(h, torrent, tmp_path):
    tid = add(h, torrent, tmp_path)
    target = tmp_path / "out" / "x.torrent"
    assert h.service.export_torrent(tid, str(target)) == str(target)
    assert target.read_bytes() == torrent.torrent_data
    assert "xt=urn:btih:" in h.service.magnet_uri(tid) and "xt=urn:btmh:" in h.service.magnet_uri(tid)
    # a v2 magnet without stored torrent data asks the engine and reports its answer
    other = create_torrent(make_payload(tmp_path / "s3" / "o", {"y.bin": 20_000}, seed="y"), "v2")
    mid = h.service.add_magnet(LibtorrentCodec().make_magnet(other.torrent_data), save_path=str(tmp_path)).transfer_id
    h.deliver(e.MetadataReceived(mid, other.metadata, None))
    assert h.service.export_torrent(mid, str(tmp_path / "out" / "y.torrent")) is None
    assert h.engine.last(c.ExportTorrent).transfer_id == mid
    h.deliver(e.TorrentExported(mid, None, "A complete .torrent file is not available yet"))
    assert any(k == "error" and "not available yet" in p["message"] for k, p in h.notes)
    h.service.export_torrent(mid, str(tmp_path / "out" / "y.torrent"))
    h.deliver(e.TorrentExported(mid, other.torrent_data))
    assert (tmp_path / "out" / "y.torrent").read_bytes() == other.torrent_data
