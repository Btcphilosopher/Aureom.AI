"""PaymentService against the scriptable fake backend."""

import json
import threading
import time

import pytest

from aureom_torrent.diagnostics.redaction import redact_obj
from aureom_torrent.payments.interface import BackendUnavailable
from aureom_torrent.payments.invoices import InvoiceError
from aureom_torrent.payments.models import (DuplicatePayment, InvalidPaymentState, PaymentDirection,
                                            PaymentError, PaymentKind, PaymentLimitError, PaymentState,
                                            PublisherRef, PublisherTrust)
from aureom_torrent.payments.service import PAYMENT_DISCLOSURES, PaymentService
from aureom_torrent.persistence.database import Database
from tests.fakes.payments import (OTHER_NODE_PRIVKEY, TEST_NODE_PUBKEY, FakeClock, FakeLightningBackend,
                                  make_invoice, settings_factory)

S = PaymentState
NOW = 1_800_000_000


class Env:
    def __init__(self, *, backend=True, db=None, **payment_overrides):
        self.db = db or Database(None)
        self.clock = FakeClock(NOW)
        self.backend = FakeLightningBackend() if backend else None
        if self.backend:
            self.backend.clock = self.clock
        self.settings = settings_factory(**payment_overrides)
        self.service = PaymentService(self.db, lambda: self.backend, self.settings, self.clock)

    def invoice(self, **kw):
        kw.setdefault("created_at", int(self.clock.now()))
        return make_invoice(**kw)

    def prepared(self, **kw):
        pr, payment_hash = self.invoice(**kw)
        intent, summary = self.service.prepare_invoice_payment(pr)
        return intent, summary, payment_hash


@pytest.fixture
def env():
    return Env()


# ---------------------------------------------------------------- approval summary
def test_prepare_records_intent_and_builds_full_summary(env):
    pr, payment_hash = env.invoice(amount_msat=250_000, description="Support the archive", expiry=600)
    publisher = PublisherRef(name="Open Archive", trust=PublisherTrust.SELF_ASSERTED, manifest_id="m1")
    intent, summary = env.service.prepare_invoice_payment(pr, publisher=publisher, transfer_id="t1",
                                                          note="thanks\x00!")
    assert intent.state is S.AWAITING_APPROVAL and intent.direction is PaymentDirection.OUTGOING
    assert env.service.get(intent.id).invoice == pr  # persisted before any submission
    assert env.backend.count("pay_invoice") == 0
    # everything section 9 requires is present
    assert summary.amount_msat == 250_000 and summary.amount_text == "250 sats"
    assert summary.network == "regtest"
    assert summary.destination == TEST_NODE_PUBKEY and "backend" in summary.destination_source
    assert summary.publisher_name == "Open Archive" and summary.publisher_trust is PublisherTrust.SELF_ASSERTED
    assert "Self-asserted" in summary.trust_label
    assert summary.description == "Support the archive"
    assert summary.expires_at == NOW + 600 and summary.seconds_until_expiry == 600
    assert summary.suggested_fee_limit_msat == 5_000  # 1 % would be 2 500 msat; the 5 sat floor applies
    assert summary.max_fee_limit_msat == 250_000
    assert summary.backend_name == "fake" and summary.backend_alias == "fake-node"
    assert summary.payment_hash_short == payment_hash[:12]
    assert any("self-asserted" in w for w in summary.warnings)
    assert intent.note == "thanks !" and intent.transfer_id == "t1" and intent.manifest_id == "m1"
    assert len(PAYMENT_DISCLOSURES) >= 3


def test_trust_labels_in_warnings(env):
    _, unknown, _ = env.prepared()
    assert any("not linked to a known publisher" in w for w in unknown.warnings)
    pr, _ = env.invoice()
    _, verified = env.service.prepare_invoice_payment(
        pr, publisher=PublisherRef("P", PublisherTrust.VERIFIED))
    assert any("does not prove" in w for w in verified.warnings)


def test_amountless_invoice_needs_amount(env):
    pr, _ = env.invoice(amount_msat=None)
    with pytest.raises(InvoiceError):
        env.service.prepare_invoice_payment(pr)
    intent, summary = env.service.prepare_invoice_payment(pr, amount_msat=42_000)
    assert intent.amount_msat == 42_000 and any("entered by you" in w for w in summary.warnings)
    done = env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert done.state is S.SUCCEEDED
    assert env.backend.calls[-1].args["amount_msat"] == 42_000  # explicit amount passed for amountless


def test_fixed_amount_invoice_sends_no_amount_override(env):
    intent, _, _ = env.prepared(amount_msat=30_000)
    env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    call = [c for c in env.backend.calls if c.method == "pay_invoice"][0]
    assert call.args["amount_msat"] is None and call.args["fee_limit_msat"] == 1_000
    assert call.args["timeout_s"] == 60


def test_limits_and_network_are_enforced_at_prepare():
    env = Env(max_payment_sat=100)
    pr, _ = env.invoice(amount_msat=101_000)
    with pytest.raises(InvoiceError):
        env.service.prepare_invoice_payment(pr)
    pr, _ = env.invoice(network="mainnet")
    with pytest.raises(InvoiceError):
        env.service.prepare_invoice_payment(pr)
    assert env.service.list_payments() == []


def test_backend_on_other_network_blocks_payment(env):
    env.backend.network = "testnet"
    pr, _ = env.invoice()
    with pytest.raises(PaymentError):
        env.service.prepare_invoice_payment(pr)
    assert env.service.backend_status().network_matches is False


def test_own_invoice_is_flagged(env):
    env.backend.pubkey = TEST_NODE_PUBKEY
    _, summary, _ = env.prepared()
    assert any("your own node" in w for w in summary.warnings)


# ---------------------------------------------------------------- happy path + persistence order
def test_success_clears_invoice_and_records_fee(env):
    intent, _, payment_hash = env.prepared(amount_msat=100_000)
    done = env.service.approve_and_send(intent.id, fee_limit_msat=2_000)
    assert done.state is S.SUCCEEDED and done.fee_paid_msat == 1_000 and done.fee_limit_msat == 2_000
    assert done.invoice is None and done.payment_hash == payment_hash and done.settled_at == NOW
    assert env.service.describe_amount_paid(done) == "100 sats + 1 sat fee"
    states = [e.to_state for e in env.service.events(intent.id)]
    assert states == [S.DRAFT, S.AWAITING_APPROVAL, S.SUBMITTED, S.SUCCEEDED]


def test_intent_is_persisted_as_submitted_before_the_backend_call(env):
    intent, _, payment_hash = env.prepared()
    seen = {}

    def during_call(ph):
        row = env.db.query_one("SELECT state, fee_limit_msat, submitted_at FROM payments WHERE id = ?", (intent.id,))
        seen.update(state=row["state"], fee=row["fee_limit_msat"], at=row["submitted_at"], ph=ph)

    env.backend.on_pay = during_call
    env.service.approve_and_send(intent.id, fee_limit_msat=777)
    assert seen == {"state": "submitted", "fee": 777, "at": NOW, "ph": payment_hash}


# ---------------------------------------------------------------- failures
def test_backend_rejection_is_a_definitive_failure(env):
    env.backend.pay_script = ["reject"]
    intent, _, _ = env.prepared()
    done = env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert done.state is S.FAILED and "rejected" in done.error and done.invoice is None


def test_route_failure_reported_by_backend(env):
    env.backend.pay_script = ["fail:FAILURE_REASON_NO_ROUTE"]
    intent, _, _ = env.prepared()
    done = env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert done.state is S.FAILED and "no route" in done.error


def test_connect_failure_means_not_sent(env):
    env.backend.pay_script = ["unreachable"]
    intent, _, _ = env.prepared()
    done = env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert done.state is S.FAILED and done.error.startswith("Not sent")


def test_backend_down_before_submission_leaves_intent_untouched(env):
    intent, _, _ = env.prepared()
    env.backend.reachable = False
    with pytest.raises(BackendUnavailable):
        env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert env.service.get(intent.id).state is S.AWAITING_APPROVAL
    assert env.backend.count("pay_invoice") == 0


def test_expired_invoice_at_approval_time_sends_nothing(env):
    intent, _, _ = env.prepared(expiry=120)
    env.clock.advance(200)
    done = env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert done.state is S.EXPIRED and "Nothing was sent" in done.error and done.invoice is None
    assert env.backend.count("pay_invoice") == 0
    with pytest.raises(InvalidPaymentState):
        env.service.approve_and_send(intent.id, fee_limit_msat=1_000)


def test_fee_limit_validation(env):
    intent, summary, _ = env.prepared(amount_msat=10_000)
    for bad in (-1, 1.5, "5", True):
        with pytest.raises(Exception):
            env.service.approve_and_send(intent.id, fee_limit_msat=bad)
    with pytest.raises(PaymentLimitError):
        env.service.approve_and_send(intent.id, fee_limit_msat=summary.max_fee_limit_msat + 1)
    assert env.service.get(intent.id).state is S.AWAITING_APPROVAL and env.backend.count("pay_invoice") == 0
    assert env.service.approve_and_send(intent.id, fee_limit_msat=0).state is S.SUCCEEDED  # zero-fee is allowed


# ---------------------------------------------------------------- unknown outcomes & reconciliation
def test_timeout_is_unknown_not_failed_and_is_never_resubmitted(env):
    env.backend.pay_script = ["timeout"]
    env.backend.timeout_then = "lost"  # the backend never saw the request
    intent, _, _ = env.prepared(expiry=3600)
    done = env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert done.state is S.UNKNOWN and "unknown" in done.error.lower()
    assert done.invoice is not None  # kept: the payment may still be in progress

    report = env.service.reconcile_on_startup()
    assert env.backend.count("pay_invoice") == 1  # NOT resubmitted
    assert report.resubmitted == 0 and report.unknown == 1 and report.checked == 1
    assert env.service.get(intent.id).state is S.UNKNOWN  # no record + invoice still valid => stays unknown

    with pytest.raises(InvalidPaymentState):
        env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert env.service.refresh(intent.id).state is S.UNKNOWN
    assert env.service.poll_open() == []
    assert env.backend.count("pay_invoice") == 1

    env.clock.advance(3600 + 121)  # invoice expired (+ margin) and the backend still has no record
    final = env.service.refresh(intent.id)
    assert final.state is S.FAILED and "invoice has expired" in final.error
    assert env.service.events(intent.id)[-1].detail == "reconciliation: never initiated; invoice expired"
    assert env.backend.count("pay_invoice") == 1


@pytest.mark.parametrize("then,expected", [("succeeded", S.SUCCEEDED), ("failed", S.FAILED), ("in_flight", S.PENDING)])
def test_reconciliation_resolves_unknown(env, then, expected):
    env.backend.pay_script = ["timeout"]
    env.backend.timeout_then = then
    intent, _, payment_hash = env.prepared()
    assert env.service.approve_and_send(intent.id, fee_limit_msat=1_000).state is S.UNKNOWN
    changed = env.service.poll_open()
    assert [c.id for c in changed] == [intent.id] and changed[0].state is expected
    if expected is S.SUCCEEDED:
        assert changed[0].fee_paid_msat == 1_000 and changed[0].invoice is None and changed[0].error == ""
    if expected is S.PENDING:
        env.backend.settle_outgoing(payment_hash, fee_msat=7)
        assert env.service.refresh(intent.id).state is S.SUCCEEDED
        assert env.service.get(intent.id).fee_paid_msat == 7
    assert env.backend.count("pay_invoice") == 1


def test_in_flight_then_settles(env):
    env.backend.pay_script = ["in_flight"]
    intent, _, payment_hash = env.prepared()
    assert env.service.approve_and_send(intent.id, fee_limit_msat=1_000).state is S.PENDING
    assert env.service.poll_open() == []  # still in flight: no change, no event spam
    assert len(env.service.events(intent.id)) == 4
    env.backend.settle_outgoing(payment_hash)
    assert env.service.poll_open()[0].state is S.SUCCEEDED


def test_unexpected_error_during_submission_is_unknown(env):
    env.backend.pay_script = ["crash"]
    intent, _, _ = env.prepared()
    assert env.service.approve_and_send(intent.id, fee_limit_msat=1_000).state is S.UNKNOWN


def test_backend_already_knows_payment_resolves_by_tracking(env):
    intent, _, payment_hash = env.prepared()
    env.backend.settle_outgoing(payment_hash, fee_msat=3)  # e.g. paid through the node by other means
    done = env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert done.state is S.SUCCEEDED and done.fee_paid_msat == 3
    assert [e.to_state for e in env.service.events(intent.id)][-2:] == [S.UNKNOWN, S.SUCCEEDED]


def test_unreachable_backend_during_reconciliation_changes_nothing(env):
    env.backend.pay_script = ["timeout"]
    intent, _, _ = env.prepared()
    env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    env.backend.reachable = False
    report = env.service.reconcile_on_startup()
    assert not report.backend_reachable and report.unknown == 1 and report.notes
    assert env.service.poll_open() == []
    with pytest.raises(BackendUnavailable):
        env.service.refresh(intent.id)
    assert env.service.get(intent.id).state is S.UNKNOWN


# ---------------------------------------------------------------- duplicates
def test_duplicate_payment_prevention(env):
    pr, _ = env.invoice()
    first, _ = env.service.prepare_invoice_payment(pr)
    second, _ = env.service.prepare_invoice_payment(pr)  # re-pasting supersedes the unsent one
    assert env.service.get(first.id).state is S.CANCELLED and second.state is S.AWAITING_APPROVAL
    assert env.service.get(first.id).invoice is None
    with pytest.raises(InvalidPaymentState):
        env.service.approve_and_send(first.id, fee_limit_msat=1_000)
    env.service.approve_and_send(second.id, fee_limit_msat=1_000)
    with pytest.raises(DuplicatePayment) as err:
        env.service.prepare_invoice_payment(pr)
    assert err.value.existing_id == second.id and "already been paid" in str(err.value)
    assert env.backend.count("pay_invoice") == 1


@pytest.mark.parametrize("behaviour", ["timeout", "in_flight"])
def test_duplicate_blocked_while_outcome_open(env, behaviour):
    env.backend.pay_script = [behaviour]
    pr, _ = env.invoice()
    intent, _ = env.service.prepare_invoice_payment(pr)
    env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    with pytest.raises(DuplicatePayment):
        env.service.prepare_invoice_payment(pr)
    assert env.backend.count("pay_invoice") == 1


def test_failed_payment_may_be_prepared_again_explicitly(env):
    env.backend.pay_script = ["reject"]
    pr, _ = env.invoice()
    intent, _ = env.service.prepare_invoice_payment(pr)
    assert env.service.approve_and_send(intent.id, fee_limit_msat=1_000).state is S.FAILED
    again, _ = env.service.prepare_invoice_payment(pr)  # a new explicit user action, new approval
    assert again.id != intent.id and again.state is S.AWAITING_APPROVAL


def test_concurrent_double_approval_submits_once(env):
    intent, _, _ = env.prepared()
    gate = threading.Event()
    env.backend.on_pay = lambda ph: gate.wait(5)
    results = []

    def approve():
        try:
            results.append(env.service.approve_and_send(intent.id, fee_limit_msat=1_000).state)
        except InvalidPaymentState:
            results.append("refused")

    threads = [threading.Thread(target=approve) for _ in range(2)]
    threads[0].start()
    deadline = time.monotonic() + 5
    while env.backend.count("pay_invoice") == 0 and time.monotonic() < deadline:
        time.sleep(0.005)
    threads[1].start()
    threads[1].join(5)
    assert env.service.poll_open() == []  # an in-progress submission is not reconciled concurrently
    gate.set()
    threads[0].join(5)
    assert sorted(map(str, results)) == sorted([str(S.SUCCEEDED), "refused"])
    assert env.backend.count("pay_invoice") == 1


# ---------------------------------------------------------------- cancel
def test_cancel_only_before_submission(env):
    intent, _, _ = env.prepared()
    cancelled = env.service.cancel(intent.id)
    assert cancelled.state is S.CANCELLED and cancelled.invoice is None
    with pytest.raises(InvalidPaymentState):
        env.service.approve_and_send(intent.id, fee_limit_msat=1)
    other, _, _ = env.prepared()
    env.service.approve_and_send(other.id, fee_limit_msat=1_000)
    with pytest.raises(InvalidPaymentState):
        env.service.cancel(other.id)
    with pytest.raises(InvalidPaymentState):
        env.service.cancel("nope")


def test_unapproved_intent_expires_locally(env):
    intent, _, _ = env.prepared(expiry=300)
    env.clock.advance(301)
    changed = env.service.poll_open()
    assert [c.state for c in changed] == [S.EXPIRED]
    assert env.backend.count("track_payment") == 0  # nothing was ever submitted, nothing to track


# ---------------------------------------------------------------- incoming invoices
def test_incoming_invoice_settles_only_when_backend_confirms(env):
    intent = env.service.create_incoming_invoice(21_000, memo="tips welcome", expiry_s=600)
    assert intent.state is S.PENDING and intent.direction is PaymentDirection.INCOMING
    assert intent.kind is PaymentKind.LIGHTNING_RECEIVE and intent.invoice.startswith("lnbcrt")
    assert intent.expires_at == NOW + 600 and intent.state_label == "Waiting for payment"
    assert env.service.poll_open() == []
    assert env.service.get(intent.id).state is S.PENDING
    env.backend.settle_invoice(intent.payment_hash)
    settled = env.service.refresh(intent.id)
    assert settled.state is S.SUCCEEDED and settled.settled_at == NOW and settled.invoice is None
    assert settled.state_label == "Settled"


def test_incoming_invoice_expires_unpaid(env):
    intent = env.service.create_incoming_invoice(5_000, expiry_s=60)
    env.clock.advance(61)
    assert env.service.poll_open()[0].state is S.EXPIRED
    assert env.service.get(intent.id).invoice is None


def test_incoming_invoice_not_expired_while_backend_unreachable(env):
    intent = env.service.create_incoming_invoice(5_000, expiry_s=60)
    env.clock.advance(61)
    env.backend.reachable = False
    assert env.service.poll_open() == []
    assert env.service.get(intent.id).state is S.PENDING  # it may have been paid; only the backend knows
    env.backend.reachable = True
    env.backend.settle_invoice(intent.payment_hash)
    assert env.service.poll_open()[0].state is S.SUCCEEDED


def test_incoming_invoice_cancelled_at_backend(env):
    intent = env.service.create_incoming_invoice(5_000, expiry_s=600)
    env.backend.cancel_invoice(intent.payment_hash)
    assert env.service.refresh(intent.id).state is S.FAILED


def test_incoming_invoice_limits_and_failures(env):
    with pytest.raises(PaymentLimitError):
        env.service.create_incoming_invoice(0)
    with pytest.raises(PaymentLimitError):
        env.service.create_incoming_invoice(10**12)
    with pytest.raises(PaymentLimitError):
        env.service.create_incoming_invoice(5_000, expiry_s=5)
    with pytest.raises(Exception):
        env.service.create_incoming_invoice(5_000.0)
    assert env.service.list_payments() == []
    env.backend.reachable = False
    with pytest.raises(BackendUnavailable):
        env.service.create_incoming_invoice(5_000)


# ---------------------------------------------------------------- bitcoin (BIP21 hand-off)
def test_bitcoin_request_is_never_marked_paid():
    env = Env(expected_network="mainnet", backend=False)
    addr = "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4"
    intent, uri = env.service.create_bitcoin_request(
        addr, amount_sat=25_000, label="Open Archive", message="Thank you",
        publisher=PublisherRef("Open Archive", PublisherTrust.SELF_ASSERTED))
    assert uri == f"bitcoin:{addr}?amount=0.00025&label=Open%20Archive&message=Thank%20you"
    assert intent.state is S.AWAITING_APPROVAL and intent.kind is PaymentKind.BITCOIN_EXTERNAL
    assert intent.amount_msat == 25_000_000 and intent.destination == addr and intent.network == "mainnet"
    summary = env.service.bitcoin_request_summary(intent.id)
    assert summary.suggested_fee_limit_msat is None and any("public and permanent" in w for w in summary.warnings)

    opened = env.service.mark_wallet_opened(intent.id)
    assert opened.state is S.UNKNOWN and "not tracked" in opened.state_label
    assert env.service.mark_wallet_opened(intent.id).state is S.UNKNOWN  # idempotent
    assert env.service.refresh(intent.id).state is S.UNKNOWN
    assert env.service.poll_open() == []
    assert env.service.reconcile_on_startup().checked == 0
    assert env.service.get(intent.id).state is S.UNKNOWN
    with pytest.raises(InvalidPaymentState):
        env.service.approve_and_send(intent.id, fee_limit_msat=0)
    with pytest.raises(InvalidPaymentState):
        env.service.cancel(intent.id)


def test_bitcoin_request_validation():
    env = Env(expected_network="mainnet", backend=False)
    with pytest.raises(ValueError):
        env.service.create_bitcoin_request("tb1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3q0sl5k7")
    with pytest.raises(ValueError):
        env.service.create_bitcoin_request("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", amount_sat=0)
    with pytest.raises(ValueError):
        env.service.create_bitcoin_request("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", amount_sat=0.001)
    intent, uri = env.service.create_bitcoin_request("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4")
    assert intent.amount_msat is None and "?" not in uri
    assert env.service.describe_amount_paid(intent) == "amount chosen in wallet"
    assert env.service.cancel(intent.id).state is S.CANCELLED


# ---------------------------------------------------------------- no backend / diagnostics
def test_service_works_without_a_backend():
    env = Env(backend=False)
    status = env.service.backend_status()
    assert not status.configured and not status.connected and "without" in status.message
    assert env.service.list_payments() == [] and env.service.poll_open() == []
    assert env.service.reconcile_on_startup().summary() == "No payments needed reconciliation."
    pr, _ = env.invoice()
    intent, summary = env.service.prepare_invoice_payment(pr)  # can be reviewed ...
    assert any("No Lightning backend" in w for w in summary.warnings)
    with pytest.raises(BackendUnavailable):  # ... but not sent
        env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    assert env.service.get(intent.id).state is S.AWAITING_APPROVAL
    with pytest.raises(BackendUnavailable):
        env.service.create_incoming_invoice(1_000)


def test_backend_provider_failure_is_contained():
    env = Env()

    def broken():
        raise BackendUnavailable("No LND macaroon is stored.")

    service = PaymentService(env.db, broken, env.settings, env.clock)
    status = service.backend_status()
    assert status.configured and not status.connected and "macaroon" in status.message
    assert service.poll_open() == [] and service.list_payments() == []


def test_list_filters_and_presets(env):
    a, _, _ = env.prepared()
    env.service.approve_and_send(a.id, fee_limit_msat=1_000)
    b = env.service.create_incoming_invoice(2_000, transfer_id="t9")
    assert {p.id for p in env.service.list_payments()} == {a.id, b.id}
    assert [p.id for p in env.service.list_payments(direction=PaymentDirection.INCOMING)] == [b.id]
    assert [p.id for p in env.service.list_payments(state=S.SUCCEEDED)] == [a.id]
    assert [p.id for p in env.service.list_payments(transfer_id="t9")] == [b.id]
    assert env.service.tip_presets_msat() == [21_000, 100_000, 500_000, 1_000_000, 5_000_000]
    assert "1 sat" in env.service.limits_text()


def test_diagnostics_expose_no_secrets(env):
    env.backend.pay_script = ["timeout"]
    intent, _, payment_hash = env.prepared(description="secret gift for Dana")
    env.service.approve_and_send(intent.id, fee_limit_msat=1_000)
    incoming = env.service.create_incoming_invoice(9_000, memo="private memo")
    bundle = json.dumps(redact_obj(env.service.diagnostics()))
    stored = env.service.get(intent.id)
    assert stored.invoice and stored.invoice not in bundle and incoming.invoice not in bundle
    assert "lnbcrt" not in bundle and payment_hash not in bundle and incoming.payment_hash not in bundle
    assert "secret gift" not in bundle and "private memo" not in bundle
    assert TEST_NODE_PUBKEY not in bundle and "preimage" not in bundle.lower() and "macaroon" not in bundle.lower()
    data = env.service.diagnostics()
    assert data["counts_by_state"] == {"unknown": 1, "pending": 1}
    assert {row["hash_prefix"] for row in data["open"]} == {payment_hash[:8], incoming.payment_hash[:8]}


def test_invoice_signed_by_other_key_has_other_payee(env):
    pr, _ = env.invoice(privkey=OTHER_NODE_PRIVKEY)
    _, summary = env.service.prepare_invoice_payment(pr)
    assert summary.destination != TEST_NODE_PUBKEY and len(summary.destination) == 66
