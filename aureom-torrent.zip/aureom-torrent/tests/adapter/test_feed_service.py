"""FeedService against fakes: scripted fetcher, in-memory database, fake transfer gateway."""

from __future__ import annotations

import threading

import pytest

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.feeds.models import (STATUS_ADDED, STATUS_BASELINE, STATUS_DISMISSED, STATUS_DUPLICATE,
                                         STATUS_NEW, FeedError, FeedRule)
from aureom_torrent.feeds.rules import RuleError
from aureom_torrent.feeds.service import FeedService
from aureom_torrent.net.http import FetchTimeout, ResponseTooLarge
from aureom_torrent.persistence.database import Database
from aureom_torrent.services.interfaces import AddRejected
from tests.fakes.feeds import (DEFAULT_BASE, FIXTURES, FakeClock, FakeFetcher, FakeResult, FakeTransferGateway,
                               fake_torrent, fixture_bytes, make_settings, rss_document)

URL = DEFAULT_BASE + "/feed.xml"
V1 = ["%040x" % (0x1000 + i) for i in range(50)]


def magnet(i: int) -> str:
    return f"magnet:?xt=urn:btih:{V1[i]}&dn=item-{i}"


def magnet_item(i: int, title: str | None = None, **extra) -> dict:
    return {"title": title or f"Item {i} FLAC", "guid": f"guid-{i}", "link": f"{DEFAULT_BASE}/items/{i}",
            "magnet": magnet(i), **extra}


def torrent_item(i: int, title: str | None = None, **extra) -> dict:
    return {"title": title or f"Item {i} FLAC", "guid": f"guid-{i}", "link": f"{DEFAULT_BASE}/items/{i}",
            "torrent": f"{DEFAULT_BASE}/torrents/{i}.torrent", **extra}


class Env:
    def __init__(self, **feed_settings):
        self.db = Database(None)
        self.fetcher = FakeFetcher()
        self.gateway = FakeTransferGateway()
        self.clock = FakeClock()
        self.settings = make_settings(**feed_settings)
        self.service = FeedService(self.db, self.fetcher, self.gateway, self.settings, self.clock)

    def serve(self, items: list[dict], url: str = URL, **headers) -> None:
        self.fetcher.set(url, FakeResult(body=rss_document(items), headers=headers))

    def serve_torrent(self, i: int, size: int = 5000) -> None:
        self.fetcher.set(f"{DEFAULT_BASE}/torrents/{i}.torrent",
                         FakeResult(body=fake_torrent(f"item-{i}", size, v1=V1[i])))

    def subscribe(self, *, auto: bool = False, rule: FeedRule | None = None, **kwargs):
        feed = self.service.add_feed(URL, **kwargs)
        if auto:
            feed = self.service.set_auto_download(feed.id, True)
        if rule is not None:
            rule.feed_id = feed.id
            self.service.save_rule(rule)
        return feed

    def statuses(self, feed_id: int) -> dict[str, str]:
        return {e.title: e.status for e in self.service.list_entries(feed_id=feed_id, limit=1000)}

    def log_rows(self) -> int:
        return self.db.query_one("SELECT COUNT(*) AS n FROM feed_rule_log")["n"]


@pytest.fixture
def env():
    return Env()


# --------------------------------------------------------------------------- baseline
def test_first_refresh_is_a_baseline_and_adds_nothing(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="everything"))
    env.serve([magnet_item(2), magnet_item(1)])
    result = env.service.refresh_feed(feed.id)
    assert result.ok and result.baseline and result.new_entries == 2
    assert result.auto_added == 0 and env.gateway.calls == []
    assert set(env.statuses(feed.id).values()) == {STATUS_BASELINE}

    # an item published after the baseline is picked up by the rule
    env.serve([magnet_item(3), magnet_item(2), magnet_item(1)])
    result = env.service.refresh_feed(feed.id)
    assert not result.baseline and result.new_entries == 1 and result.auto_added == 1
    assert [c.identity.v1 for c in env.gateway.calls] == [V1[3]]
    assert env.gateway.calls[0].source == "feed" and env.gateway.calls[0].feed_entry_id is not None
    statuses = env.statuses(feed.id)
    assert statuses["Item 3 FLAC"] == STATUS_ADDED and statuses["Item 1 FLAC"] == STATUS_BASELINE


def test_download_existing_is_an_explicit_choice(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="all", max_per_refresh=0), download_existing=True)
    env.serve([magnet_item(2), magnet_item(1)])
    result = env.service.refresh_feed(feed.id)
    assert not result.baseline and result.auto_added == 2
    assert set(env.statuses(feed.id).values()) == {STATUS_ADDED}


def test_rules_do_nothing_without_the_per_feed_opt_in(env):
    feed = env.subscribe(auto=False, rule=FeedRule(name="all"))
    env.serve([magnet_item(1)])
    env.service.refresh_feed(feed.id)
    env.serve([magnet_item(2), magnet_item(1)])
    result = env.service.refresh_feed(feed.id)
    assert result.new_entries == 1 and result.auto_added == 0 and env.gateway.calls == []
    assert env.statuses(feed.id)["Item 2 FLAC"] == STATUS_NEW
    with pytest.raises(FeedError, match="Enable automatic downloads"):
        env.service.apply_rules_now(feed.id)


def test_disabled_rule_is_ignored(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="off", enabled=False))
    env.serve([])
    env.fetcher.set(URL, FakeResult(body=rss_document([magnet_item(0)])))
    env.service.refresh_feed(feed.id)
    env.serve([magnet_item(1), magnet_item(0)])
    assert env.service.refresh_feed(feed.id).auto_added == 0


# ------------------------------------------------------------------ conditional requests
def test_conditional_refresh_and_304(env):
    feed = env.subscribe()
    env.serve([magnet_item(1)], ETag='"abc"', **{"Last-Modified": "Mon, 23 Nov 2026 09:30:00 GMT"})
    assert env.service.refresh_feed(feed.id).ok
    stored = env.service.get_feed(feed.id)
    assert stored.etag == '"abc"' and stored.last_modified == "Mon, 23 Nov 2026 09:30:00 GMT"
    assert stored.title == "Generated Feed" and stored.last_status == "ok" and stored.baseline_done

    env.fetcher.set(URL, FakeResult(status=304))
    env.clock.advance(10)
    result = env.service.refresh_feed(feed.id)
    assert result.ok and result.not_modified and result.new_entries == 0
    sent = env.fetcher.requests[-1].headers
    assert sent["If-None-Match"] == '"abc"' and sent["If-Modified-Since"] == "Mon, 23 Nov 2026 09:30:00 GMT"
    stored = env.service.get_feed(feed.id)
    assert stored.last_status == "not_modified" and stored.etag == '"abc"'
    assert stored.next_check == int(env.clock.now()) + stored.interval_minutes * 60


def test_policy_comes_from_the_feed_network_settings(env):
    env.settings().feeds_network.max_response_bytes = 12345
    env.settings().feeds_network.proxy_url = "socks5://127.0.0.1:9050"
    feed = env.subscribe()
    env.serve([])
    env.service.refresh_feed(feed.id)
    policy = env.fetcher.requests[-1].policy
    assert policy.max_bytes == 12345 and policy.proxy_url == "socks5://127.0.0.1:9050"
    assert policy.allow_loopback is False


# --------------------------------------------------------------------------- failures
def test_timeouts_back_off_and_recover(env):
    feed = env.subscribe()
    env.fetcher.set(URL, FetchTimeout("Timed out contacting https://feeds.example.org/feed.xml."))
    start = int(env.clock.now())
    delays = []
    for _ in range(4):
        result = env.service.refresh_feed(feed.id)
        assert not result.ok and "Timed out" in result.error
        delays.append(result.next_check - int(env.clock.now()))
        env.clock.advance(1)
    assert delays == [300, 600, 1200, 2400]
    stored = env.service.get_feed(feed.id)
    assert stored.fail_count == 4 and stored.last_status == "error" and "Timed out" in stored.last_error
    assert stored.last_success is None and stored.last_checked >= start
    assert not stored.baseline_done  # a failed first refresh must not consume the baseline

    env.serve([magnet_item(1)])
    result = env.service.refresh_feed(feed.id)
    assert result.ok and result.baseline
    stored = env.service.get_feed(feed.id)
    assert stored.fail_count == 0 and stored.last_error == "" and stored.last_status == "ok"


def test_malformed_response_keeps_validators_and_entries(env):
    feed = env.subscribe()
    env.serve([magnet_item(1)], ETag='"good"')
    env.service.refresh_feed(feed.id)
    env.fetcher.set(URL, FakeResult(body=(FIXTURES / "malformed_not_a_feed.html").read_bytes(),
                                    headers={"ETag": '"bad"'}))
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and "not an RSS or Atom feed" in result.error
    stored = env.service.get_feed(feed.id)
    assert stored.etag == '"good"' and stored.fail_count == 1 and stored.entry_count == 1


def test_oversized_and_entity_bomb_responses_are_errors(env):
    feed = env.subscribe()
    env.fetcher.set(URL, ResponseTooLarge("The response is larger than the 4,194,304-byte limit."))
    assert "larger than" in env.service.refresh_feed(feed.id).error
    env.fetcher.set(URL, FakeResult(body=fixture_bytes("entity_bomb.xml")))
    assert "entities" in env.service.refresh_feed(feed.id).error
    assert env.service.get_feed(feed.id).entry_count == 0


def test_retry_after_lengthens_the_backoff(env):
    feed = env.subscribe()
    env.fetcher.set(URL, FakeResult(status=429, headers={"Retry-After": "7200"}))
    result = env.service.refresh_feed(feed.id)
    assert not result.ok and result.status_code == 429
    assert result.next_check == int(env.clock.now()) + 7200


def test_permanent_redirect_updates_the_address_only_after_a_good_parse(env):
    feed = env.subscribe()
    new_url = DEFAULT_BASE + "/moved.xml"
    env.fetcher.set(URL, FakeResult(body=b"<html>moved</html>", url=new_url, redirects=(URL,),
                                    redirect_statuses=(301,)))
    assert not env.service.refresh_feed(feed.id).ok
    assert env.service.get_feed(feed.id).url == URL

    env.fetcher.set(URL, FakeResult(body=rss_document([magnet_item(1)]), url=new_url, redirects=(URL,),
                                    redirect_statuses=(302,)))
    assert env.service.refresh_feed(feed.id).ok
    assert env.service.get_feed(feed.id).url == URL  # temporary redirect: keep the original

    env.fetcher.set(URL, FakeResult(body=rss_document([magnet_item(1)]), url=new_url, redirects=(URL,),
                                    redirect_statuses=(308,)))
    assert env.service.refresh_feed(feed.id).ok
    assert env.service.get_feed(feed.id).url == new_url


def test_same_feed_is_not_refreshed_concurrently(env):
    feed = env.subscribe()
    entered, release = threading.Event(), threading.Event()

    def slow(_record):
        entered.set()
        assert release.wait(5)
        return FakeResult(body=rss_document([magnet_item(1)]))

    env.fetcher.set(URL, slow)
    results = []
    worker = threading.Thread(target=lambda: results.append(env.service.refresh_feed(feed.id)))
    worker.start()
    assert entered.wait(5)
    second = env.service.refresh_feed(feed.id)
    assert not second.ok and "already running" in second.error
    release.set()
    worker.join(5)
    assert results[0].ok and env.fetcher.count(URL) == 1


def test_refresh_due_only_touches_due_feeds(env):
    a = env.service.add_feed(URL)
    b = env.service.add_feed(DEFAULT_BASE + "/other.xml", interval_minutes=30)
    env.serve([magnet_item(1)])
    env.serve([magnet_item(2)], url=DEFAULT_BASE + "/other.xml")
    assert sorted(r.feed_id for r in env.service.refresh_due()) == [a.id, b.id]
    assert env.service.refresh_due() == []
    env.clock.advance(31 * 60)
    due = env.service.refresh_due()
    assert [r.feed_id for r in due] == [b.id] and due[0].manual is False
    env.clock.advance(30 * 60)
    assert sorted(r.feed_id for r in env.service.refresh_due()) == [a.id, b.id]


# ---------------------------------------------------------------------- de-duplication
def test_unchanged_entries_are_not_new_again(env):
    feed = env.subscribe()
    env.fetcher.set(URL, FakeResult(body=fixture_bytes("rss_sample.xml")))
    assert env.service.refresh_feed(feed.id).new_entries == 4
    again = env.service.refresh_feed(feed.id)
    assert again.new_entries == 0 and again.updated_entries == 0
    assert env.service.get_feed(feed.id).entry_count == 4


def test_changed_guid_with_same_link_updates_instead_of_duplicating(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="all"))
    env.serve([magnet_item(1)])
    env.service.refresh_feed(feed.id)
    env.serve([magnet_item(1, title="Item 1 FLAC (fixed title)", guid="a-brand-new-guid")])
    result = env.service.refresh_feed(feed.id)
    assert result.new_entries == 0 and result.updated_entries == 1 and result.auto_added == 0
    (entry,) = env.service.list_entries(feed_id=feed.id)
    assert entry.title == "Item 1 FLAC (fixed title)" and entry.guid == "a-brand-new-guid"
    assert entry.status == STATUS_BASELINE


def test_changed_guid_and_link_with_same_torrent_is_the_same_entry(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="all"))
    env.serve([magnet_item(1)])
    env.service.refresh_feed(feed.id)
    env.serve([{"title": "Item 1 FLAC", "guid": "other", "link": DEFAULT_BASE + "/moved/1", "magnet": magnet(1)}])
    result = env.service.refresh_feed(feed.id)
    assert result.new_entries == 0 and env.gateway.calls == []
    assert env.service.get_feed(feed.id).entry_count == 1


def test_missing_guids_and_shared_links(env):
    feed = env.subscribe()
    env.fetcher.set(URL, FakeResult(body=fixture_bytes("no_guid.xml")))
    assert env.service.refresh_feed(feed.id).new_entries == 3  # the shared link does not merge A and B
    assert env.service.refresh_feed(feed.id).new_entries == 0
    assert sorted(env.statuses(feed.id)) == ["Sample Pack A (CC0)", "Sample Pack B (CC0)", "Sample Pack C (CC0)"]


def test_read_state_and_status_survive_content_updates(env):
    feed = env.subscribe()
    env.serve([magnet_item(1)])
    env.service.refresh_feed(feed.id)
    (entry,) = env.service.list_entries(feed_id=feed.id)
    env.service.mark_read([entry.id])
    env.serve([magnet_item(1, title="Item 1 FLAC v2")])
    env.service.refresh_feed(feed.id)
    (entry,) = env.service.list_entries(feed_id=feed.id)
    assert entry.title == "Item 1 FLAC v2" and entry.read and entry.status == STATUS_BASELINE


def test_pruned_entries_are_not_resurrected(env):
    env = Env(max_entries_per_feed=20)
    feed = env.subscribe(auto=True, rule=FeedRule(name="all", max_per_refresh=0, daily_count_budget=0))
    older = [magnet_item(i, date=f"Mon, {i + 1:02d} Nov 2026 10:00:00 GMT") for i in range(20)]
    env.serve(list(reversed(older)))
    env.service.refresh_feed(feed.id)
    newer = [magnet_item(i, date=f"Tue, {i - 19:02d} Dec 2026 10:00:00 GMT") for i in range(20, 30)]
    env.serve(list(reversed(newer)) + list(reversed(older))[:10])  # the 10 oldest left the feed
    result = env.service.refresh_feed(feed.id)
    assert result.new_entries == 10 and result.auto_added == 10
    assert env.service.get_feed(feed.id).entry_count == 20  # pruned to the limit
    # the publisher re-lists an old, pruned item: it is known history, not a new entry
    env.serve(list(reversed(newer)) + [older[0]])
    result = env.service.refresh_feed(feed.id)
    assert result.new_entries == 0 and result.auto_added == 0
    assert len(env.gateway.calls) == 10


# -------------------------------------------------------- manual decisions are respected
def test_existing_transfer_is_linked_and_never_modified(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="all", add_paused=False, category="Auto",
                                                 destination="/auto"))
    env.serve([])
    env.fetcher.set(URL, FakeResult(body=rss_document([magnet_item(0)])))
    env.service.refresh_feed(feed.id)
    existing = env.gateway.seed_existing(TorrentIdentity(V1[1]), manual_paused=True, save_path="/my/choice")
    snapshot = existing.copy()

    env.serve([magnet_item(1), magnet_item(0)])
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 0 and result.duplicates == 1 and env.gateway.calls == []
    entry = next(e for e in env.service.list_entries(feed_id=feed.id) if e.title == "Item 1 FLAC")
    assert entry.status == STATUS_DUPLICATE and entry.transfer_id == existing.id
    assert "already in your transfers" in entry.status_reason
    assert env.gateway.records[existing.id] == snapshot  # pause state, destination, priorities untouched


def test_removed_transfer_is_not_re_added_by_a_later_refresh(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="all"))
    env.serve([magnet_item(0)])
    env.service.refresh_feed(feed.id)
    env.serve([magnet_item(1), magnet_item(0)])
    assert env.service.refresh_feed(feed.id).auto_added == 1
    env.gateway.remove(env.gateway.calls[0].transfer_id)  # the user removes the transfer

    # same entry again: nothing happens
    assert env.service.refresh_feed(feed.id).auto_added == 0
    # the publisher re-posts the same torrent as a "new" item with new GUID, link and title
    repost = {"title": "Item 1 FLAC REPOST", "guid": "repost-1", "link": DEFAULT_BASE + "/repost/1",
              "magnet": magnet(1)}
    other_url = DEFAULT_BASE + "/mirror.xml"
    mirror = env.service.add_feed(other_url, download_existing=True)
    env.service.set_auto_download(mirror.id, True)
    env.service.save_rule(FeedRule(feed_id=mirror.id, name="all"))
    env.serve([repost], url=other_url)
    result = env.service.refresh_feed(mirror.id)
    assert result.auto_added == 0 and result.duplicates == 1
    assert len(env.gateway.calls) == 1
    (entry,) = env.service.list_entries(feed_id=mirror.id)
    assert entry.status == STATUS_DUPLICATE and "already added" in entry.status_reason


def test_dismissed_item_is_not_added_by_another_feed(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="sized", max_size=10))
    env.serve([])
    env.fetcher.set(URL, FakeResult(body=rss_document([magnet_item(0)])))
    env.service.refresh_feed(feed.id)
    env.serve([magnet_item(1), magnet_item(0)])
    assert env.service.refresh_feed(feed.id).queued_for_review == 1
    (queued,) = env.service.list_review()
    env.service.dismiss_review(queued.id)
    assert env.service.get_entry(queued.id).status == STATUS_DISMISSED and env.service.list_review() == []

    other_url = DEFAULT_BASE + "/mirror.xml"
    mirror = env.service.add_feed(other_url, download_existing=True)
    env.service.set_auto_download(mirror.id, True)
    env.service.save_rule(FeedRule(feed_id=mirror.id, name="all"))
    env.serve([magnet_item(1)], url=other_url)
    result = env.service.refresh_feed(mirror.id)
    assert result.auto_added == 0 and env.gateway.calls == []
    assert "already dismissed" in env.service.list_entries(feed_id=mirror.id)[0].status_reason


# ------------------------------------------------------------------------ rule outcomes
def _prime(env, rule: FeedRule):
    """Subscribe with auto-download, record an empty baseline, return the feed."""
    feed = env.subscribe(auto=True, rule=rule)
    env.serve([])
    env.fetcher.set(URL, FakeResult(body=rss_document([{"title": "seed post", "guid": "seed"}])))
    assert env.service.refresh_feed(feed.id).baseline
    return feed


def test_include_exclude_and_rule_options(env):
    feed = _prime(env, FeedRule(name="flac", include=["flac"], exclude=["sample"], category="Music",
                                destination="/music", add_paused=True))
    env.serve([magnet_item(1, "Album FLAC"), magnet_item(2, "Album MP3"), magnet_item(3, "Album FLAC sample")])
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 1
    (call,) = env.gateway.calls
    assert (call.kind, call.save_path, call.category, call.paused, call.preview) == \
        ("magnet", "/music", "Music", True, False)
    statuses = env.statuses(feed.id)
    assert statuses["Album FLAC"] == STATUS_ADDED
    assert statuses["Album MP3"] == STATUS_NEW and statuses["Album FLAC sample"] == STATUS_NEW


def test_rule_defaults_fall_back_to_feed_category_and_default_path(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="all"), category="FeedCat", download_existing=True)
    env.serve([magnet_item(1)])
    env.service.refresh_feed(feed.id)
    (call,) = env.gateway.calls
    assert call.save_path == "/downloads" and call.category == "FeedCat" and call.paused is False


def test_size_limit_uses_fetched_torrent_metadata(env):
    feed = _prime(env, FeedRule(name="small", max_size=10_000, max_per_refresh=0))
    env.serve([torrent_item(1, size=1), torrent_item(2, size=1)])  # the feed claims both are tiny
    env.serve_torrent(1, size=5_000)
    env.serve_torrent(2, size=50_000_000)
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 1
    entries = {e.title: e for e in env.service.list_entries(feed_id=feed.id)}
    ok, big = entries["Item 1 FLAC"], entries["Item 2 FLAC"]
    assert ok.status == STATUS_ADDED and ok.size == 5_000 and ok.size_trusted and ok.v1 == V1[1]
    assert ok.size_label == "from torrent metadata"
    assert big.status == STATUS_NEW and big.size == 50_000_000 and big.size_trusted
    assert [c.kind for c in env.gateway.calls] == ["torrent"]
    # the torrent file was downloaded once per entry, not twice for the added one
    assert env.fetcher.count(f"{DEFAULT_BASE}/torrents/1.torrent") == 1


def test_size_limit_with_magnet_goes_to_review(env):
    feed = _prime(env, FeedRule(name="small", max_size=10_000))
    env.serve([magnet_item(1, size=100)])  # feed-reported size is not trusted
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 0 and result.queued_for_review == 1
    (entry,) = env.service.list_review()
    assert "magnet link does not state a trustworthy size" in entry.status_reason
    assert entry.size == 100 and not entry.size_trusted and entry.size_label == "feed-reported"


def test_unfetchable_or_invalid_torrent_goes_to_review(env):
    feed = _prime(env, FeedRule(name="small", max_size=10_000, max_per_refresh=0))
    env.serve([torrent_item(1), torrent_item(2), torrent_item(3)])
    env.fetcher.set(f"{DEFAULT_BASE}/torrents/1.torrent", FetchTimeout("Timed out contacting host."))
    env.fetcher.set(f"{DEFAULT_BASE}/torrents/2.torrent", FakeResult(body=b"<html>not a torrent</html>"))
    # /torrents/3.torrent is a 404
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 0 and result.queued_for_review == 3 and env.gateway.calls == []
    reasons = {e.title: e.status_reason for e in env.service.list_review()}
    assert "could not be downloaded" in reasons["Item 1 FLAC"]
    assert "not valid" in reasons["Item 2 FLAC"]
    assert "HTTP 404" in reasons["Item 3 FLAC"]


def test_gateway_rejection_goes_to_review(env):
    feed = _prime(env, FeedRule(name="all"))
    env.gateway.reject_with = AddRejected("The destination is not writable.", reason="destination")
    env.serve([magnet_item(1)])
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 0 and result.queued_for_review == 1
    (entry,) = env.service.list_review()
    assert "The destination is not writable." in entry.status_reason

    # the user fixes the problem and approves the queued item
    env.gateway.reject_with = None
    outcome = env.service.approve_review(entry.id)
    assert outcome.created
    assert env.service.get_entry(entry.id).status == STATUS_ADDED and env.service.list_review() == []


def test_max_additions_per_refresh(env):
    feed = _prime(env, FeedRule(name="all", max_per_refresh=2, daily_count_budget=0))
    env.serve([magnet_item(i) for i in range(5, 0, -1)])
    result = env.service.refresh_feed(feed.id)
    assert result.new_entries == 5 and result.auto_added == 2 and result.queued_for_review == 3
    # oldest entries first
    assert [c.identity.v1 for c in env.gateway.calls] == [V1[1], V1[2]]
    assert all("per-refresh limit" in e.status_reason for e in env.service.list_review())
    # the limit is per refresh: the next refresh may add again
    env.serve([magnet_item(6)] + [magnet_item(i) for i in range(5, 0, -1)])
    assert env.service.refresh_feed(feed.id).auto_added == 1


def test_daily_count_budget_and_day_rollover(env):
    feed = _prime(env, FeedRule(name="all", max_per_refresh=0, daily_count_budget=3))
    env.serve([magnet_item(i) for i in range(2, 0, -1)])
    assert env.service.refresh_feed(feed.id).auto_added == 2
    env.serve([magnet_item(i) for i in range(5, 0, -1)])
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 1 and result.queued_for_review == 2
    assert all("daily budget" in e.status_reason for e in env.service.list_review())
    env.clock.advance(24 * 3600)  # next UTC day: the budget is available again
    env.serve([magnet_item(i) for i in range(7, 0, -1)])
    assert env.service.refresh_feed(feed.id).auto_added == 2


def test_daily_bytes_budget(env):
    feed = _prime(env, FeedRule(name="bytes", max_per_refresh=0, daily_count_budget=0, daily_bytes_budget=10_000))
    env.serve([torrent_item(i) for i in range(3, 0, -1)])
    for i in (1, 2, 3):
        env.serve_torrent(i, size=4_000)
    result = env.service.refresh_feed(feed.id)
    assert result.auto_added == 2 and result.queued_for_review == 1
    assert "daily size budget" in env.service.list_review()[0].status_reason


def test_regex_timeout_goes_to_review(env):
    env = Env(regex_timeout_ms=10)
    feed = env.subscribe(auto=True)
    env.serve([{"title": "seed", "guid": "seed"}])
    env.service.refresh_feed(feed.id)
    # stored directly: a pattern that validates quickly on "" but explodes on real input
    env.service.save_rule(FeedRule(feed_id=feed.id, name="evil", regex=r"^(a|aa)+$"))
    env.serve([magnet_item(1, "a" * 80 + "!")])
    result = env.service.refresh_feed(feed.id)
    assert result.queued_for_review == 1 and env.gateway.calls == []
    assert "too long" in env.service.list_review()[0].status_reason


def test_first_matching_rule_wins(env):
    feed = _prime(env, FeedRule(name="flac", include=["flac"], category="Lossless"))
    env.service.save_rule(FeedRule(feed_id=feed.id, name="everything", category="Other"))
    env.serve([magnet_item(1, "Album FLAC"), magnet_item(2, "Album MP3")])
    assert env.service.refresh_feed(feed.id).auto_added == 2
    assert {c.identity.v1: c.category for c in env.gateway.calls} == {V1[1]: "Lossless", V1[2]: "Other"}


def test_rule_decisions_are_logged_and_bounded_to_feed(env):
    feed = _prime(env, FeedRule(name="all", max_per_refresh=1))
    env.serve([magnet_item(2), magnet_item(1)])
    env.service.refresh_feed(feed.id)
    log = env.service.rule_log(feed_id=feed.id)
    assert sorted(r.action for r in log) == ["add", "review"]
    assert all(r.rule_id is not None and r.entry_title for r in log)


# --------------------------------------------------------------------------- dry run
def test_rule_preview_has_no_side_effects(env):
    feed = env.subscribe(auto=True)
    env.serve([torrent_item(4, "Album FLAC torrent"), magnet_item(3, "Album FLAC"), magnet_item(2, "Album MP3"),
               {"title": "News FLAC post", "guid": "news"}, magnet_item(1, "Old FLAC")])
    env.service.refresh_feed(feed.id)
    existing = env.gateway.seed_existing(TorrentIdentity(V1[1]))
    requests_before = len(env.fetcher.requests)
    statuses_before = env.statuses(feed.id)

    rows = env.service.preview_rule(FeedRule(feed_id=feed.id, name="draft", include=["flac"]))
    decisions = {r.entry.title: (r.decision, r.reason) for r in rows}
    assert decisions["Album FLAC"][0] == "add"
    assert decisions["Album FLAC torrent"][0] == "add"
    assert decisions["Album MP3"][0] == "skip"
    assert decisions["News FLAC post"] == ("skip", "the entry has no torrent or magnet link")
    assert decisions["Old FLAC"] == ("duplicate", "already in your transfers")

    sized = env.service.preview_rule(FeedRule(feed_id=feed.id, include=["flac"], max_size=10))
    by_title = {r.entry.title: r for r in sized}
    assert by_title["Album FLAC torrent"].decision == "review" and "not done in a dry run" in by_title["Album FLAC torrent"].reason
    assert by_title["Album FLAC"].decision == "review"

    limited = env.service.preview_rule(FeedRule(feed_id=feed.id, include=["flac"], max_per_refresh=1))
    assert sorted(r.decision for r in limited if r.entry.title.startswith("Album FLAC")) == ["add", "review"]

    # nothing was fetched, added, stored or logged
    assert len(env.fetcher.requests) == requests_before
    assert env.gateway.calls == [] and env.gateway.records == {existing.id: existing}
    assert env.statuses(feed.id) == statuses_before
    assert env.service.list_rules(feed.id) == [] and env.log_rows() == 0
    with pytest.raises(RuleError):
        env.service.preview_rule(FeedRule(feed_id=feed.id, regex="("))


def test_apply_rules_now_is_an_explicit_backfill(env):
    feed = env.subscribe(auto=True, rule=FeedRule(name="flac", include=["flac"], max_per_refresh=0))
    env.serve([magnet_item(2, "Album FLAC"), magnet_item(1, "Album MP3")])
    assert env.service.refresh_feed(feed.id).auto_added == 0  # baseline
    result = env.service.apply_rules_now(feed.id)
    assert result.auto_added == 1 and env.statuses(feed.id)["Album FLAC"] == STATUS_ADDED


# ---------------------------------------------------------------------- manual actions
def test_manual_add_of_torrent_and_magnet_entries(env):
    feed = env.subscribe()
    env.serve([torrent_item(1), magnet_item(2), {"title": "post", "guid": "p"}])
    env.serve_torrent(1)
    env.service.refresh_feed(feed.id)
    entries = {e.title: e for e in env.service.list_entries(feed_id=feed.id)}

    outcome = env.service.add_entry_as_transfer(entries["Item 1 FLAC"].id, save_path="/dl", category="C", paused=True)
    assert outcome.created
    outcome2 = env.service.add_entry_as_transfer(entries["Item 2 FLAC"].id, save_path="/dl", preview=True)
    assert outcome2.created
    torrent_call, magnet_call = env.gateway.calls
    assert (torrent_call.kind, torrent_call.save_path, torrent_call.category, torrent_call.paused) == \
        ("torrent", "/dl", "C", True)
    assert torrent_call.feed_entry_id == entries["Item 1 FLAC"].id and torrent_call.source == "feed"
    assert (magnet_call.kind, magnet_call.preview) == ("magnet", True)

    added = env.service.get_entry(entries["Item 1 FLAC"].id)
    assert added.status == STATUS_ADDED and added.read and added.transfer_id == outcome.transfer_id

    # adding the same entry again links to the existing transfer instead of creating another
    again = env.service.add_entry_as_transfer(entries["Item 2 FLAC"].id, save_path="/dl")
    assert not again.created and len(env.gateway.calls) == 2

    with pytest.raises(FeedError, match="no torrent or magnet link"):
        env.service.add_entry_as_transfer(entries["post"].id, save_path="/dl")
    env.gateway.reject_with = AddRejected("Conflicting destination.", reason="conflict")
    with pytest.raises(AddRejected, match="Conflicting destination"):
        env.service.add_entry_as_transfer(entries["Item 1 FLAC"].id, save_path="/dl")
    with pytest.raises(FeedError, match="no longer exists"):
        env.service.add_entry_as_transfer(999_999, save_path="/dl")


def test_review_queue_guards(env):
    feed = env.subscribe()
    env.serve([magnet_item(1)])
    env.service.refresh_feed(feed.id)
    (entry,) = env.service.list_entries(feed_id=feed.id)
    with pytest.raises(FeedError, match="not waiting for review"):
        env.service.approve_review(entry.id)
    with pytest.raises(FeedError, match="not waiting for review"):
        env.service.dismiss_review(entry.id)


def test_approve_review_uses_rule_settings_or_override(env):
    feed = _prime(env, FeedRule(name="sized", max_size=10, destination="/rule/dest", category="RuleCat",
                                add_paused=True))
    env.serve([magnet_item(1), magnet_item(2)])
    assert env.service.refresh_feed(feed.id).queued_for_review == 2
    first, second = sorted(env.service.list_review(), key=lambda e: e.title)
    env.service.approve_review(first.id)
    env.service.approve_review(second.id, save_path="/override")
    a, b = env.gateway.calls
    assert (a.save_path, a.category, a.paused) == ("/rule/dest", "RuleCat", True)
    assert b.save_path == "/override"


# -------------------------------------------------------------- browsing / housekeeping
def test_read_state_search_filter_and_pagination(env):
    feed = env.subscribe(folder="Open Data/Audio")
    env.fetcher.set(URL, FakeResult(body=fixture_bytes("rss_sample.xml")))
    env.service.refresh_feed(feed.id)
    other = env.service.add_feed(DEFAULT_BASE + "/atom.xml", folder="Fonts")
    env.fetcher.set(DEFAULT_BASE + "/atom.xml", FakeResult(body=fixture_bytes("atom_sample.xml")))
    env.service.refresh_feed(other.id)

    everything = env.service.list_entries()
    assert len(everything) == 6
    assert [e.published for e in everything] == sorted((e.published for e in everything), reverse=True)
    assert everything[0].feed_title == "Libre Typeface Builds"

    assert len(env.service.list_entries(feed_id=feed.id)) == 4
    assert len(env.service.list_entries(folder="Open Data")) == 4  # parent folder includes children
    assert len(env.service.list_entries(folder="Fonts")) == 2
    assert env.service.list_entries(folder="Open") == []
    assert [e.title for e in env.service.list_entries(search="timetables")] == ["City Bus Timetables 2026-11 (ODbL, CSV)"]
    assert len(env.service.list_entries(search="archive team")) == 2  # publisher match
    assert len(env.service.list_entries(search="read-only sunday")) == 1  # summary text, all words
    assert env.service.list_entries(search="100%_nothing") == []
    assert len(env.service.list_entries(link_type="torrent")) == 3
    assert len(env.service.list_entries(link_type="magnet")) == 2
    assert len(env.service.list_entries(status=STATUS_BASELINE)) == 6
    assert [e.id for e in env.service.list_entries(limit=2, offset=2)] == [e.id for e in everything[2:4]]

    feeds = {f.id: f for f in env.service.list_feeds()}
    assert feeds[feed.id].unread_count == 4 and feeds[other.id].unread_count == 2
    env.service.mark_read([everything[0].id, everything[1].id])
    assert len(env.service.list_entries(unread_only=True)) == 4
    env.service.mark_read([everything[0].id], read=False)
    assert len(env.service.list_entries(unread_only=True)) == 5
    assert env.service.mark_all_read(feed.id) == 3
    assert env.service.mark_all_read() == 2
    assert env.service.list_entries(unread_only=True) == []
    assert env.service.list_folders() == ["Fonts", "Open Data/Audio"]


def test_subscription_management(env):
    feed = env.service.add_feed("  " + URL + " ", title=" My\nFeed ", folder=" A / B //", category="Docs",
                                interval_minutes=1)
    assert feed.url == URL and feed.title == "My Feed" and feed.folder == "A/B"
    assert feed.interval_minutes == 5  # clamped to the configured minimum
    assert feed.auto_download is False and feed.last_status == "never"
    with pytest.raises(FeedError, match="already subscribed"):
        env.service.add_feed(URL)
    with pytest.raises(FeedError, match="Only http and https"):
        env.service.add_feed("ftp://example.org/feed")

    other = env.service.add_feed(DEFAULT_BASE + "/b.xml")
    with pytest.raises(FeedError, match="Another subscription"):
        env.service.update_feed(other.id, url=URL)
    with pytest.raises(FeedError, match="cannot be changed"):
        env.service.update_feed(other.id, etag="x")
    with pytest.raises(FeedError, match="true or false"):
        env.service.update_feed(other.id, auto_download="yes")

    env.serve([magnet_item(1)], url=DEFAULT_BASE + "/b.xml", ETag='"e1"')
    env.service.refresh_feed(other.id)
    moved = env.service.update_feed(other.id, url=DEFAULT_BASE + "/c.xml", title="Renamed", interval_minutes=120)
    assert moved.url.endswith("/c.xml") and moved.etag == "" and moved.next_check == 0
    assert moved.title == "Renamed" and moved.interval_minutes == 120

    rule = env.service.save_rule(FeedRule(feed_id=other.id, name="r"))
    env.service.remove_feed(other.id)
    assert env.service.get_feed(other.id) is None and env.service.list_rules() == []
    assert env.service.list_entries(feed_id=other.id) == []
    with pytest.raises(FeedError, match="no longer exists"):
        env.service.refresh_feed(other.id)
    with pytest.raises(FeedError):
        env.service.save_rule(FeedRule(feed_id=other.id, name="orphan"))
    assert rule.id is not None


def test_rule_crud(env):
    feed = env.subscribe()
    rule = env.service.save_rule(FeedRule(feed_id=feed.id, name="one", include=["a", "b"], max_size=5))
    assert rule.id is not None and rule.include == ["a", "b"] and rule.created_at > 0
    rule.name = "renamed"
    rule.exclude = ["x"]
    saved = env.service.save_rule(rule)
    assert saved.id == rule.id and saved.name == "renamed" and saved.exclude == ["x"]
    assert [r.name for r in env.service.list_rules(feed.id)] == ["renamed"]
    env.service.delete_rule(rule.id)
    assert env.service.list_rules(feed.id) == []
    with pytest.raises(RuleError):
        env.service.save_rule(FeedRule(feed_id=feed.id, regex="[unclosed"))


def test_opml_import_and_export_through_the_service(env):
    result = env.service.import_opml((FIXTURES / "subscriptions.opml").read_text())
    assert (result.added, result.skipped_existing, result.invalid) == (3, 0, 1)
    assert env.fetcher.requests == []  # importing does not contact any feed
    again = env.service.import_opml((FIXTURES / "subscriptions.opml").read_text())
    assert (again.added, again.skipped_existing) == (0, 3)
    feeds = {f.url: f for f in env.service.list_feeds()}
    assert feeds["https://feeds.example.org/bus.xml"].folder == "Open Data/Transport"
    assert all(not f.auto_download and not f.download_existing for f in feeds.values())
    exported = env.service.export_opml()
    assert 'xmlUrl="https://feeds.example.org/bus.xml"' in exported and "Transport" in exported


def test_diagnostics_do_not_expose_query_strings(env):
    secret_url = DEFAULT_BASE + "/private.xml?passkey=SUPERSECRET"
    feed = env.service.add_feed(secret_url)
    env.fetcher.set(secret_url, FetchTimeout("Timed out contacting https://feeds.example.org/private.xml."))
    env.service.refresh_feed(feed.id)
    report = env.service.diagnostics()
    assert report["subscriptions"] == 1
    assert report["feeds"][0]["address"] == DEFAULT_BASE + "/private.xml"
    assert report["feeds"][0]["last_status"] == "error" and report["feeds"][0]["fail_count"] == 1
    assert "SUPERSECRET" not in repr(report)


def test_feed_errors_are_logged_without_query_strings(env, caplog):
    secret_url = DEFAULT_BASE + "/private.xml?token=SUPERSECRET"
    feed = env.service.add_feed(secret_url)
    env.fetcher.set(secret_url, FakeResult(status=500))
    with caplog.at_level("INFO", logger="aureom_torrent.feeds"):
        env.service.refresh_feed(feed.id)
    assert caplog.records and "SUPERSECRET" not in caplog.text
