Publishing fixtures (all synthetic):

* `manifest_valid.json` – a schema-1 publisher manifest using every field. The Bitcoin address is the
  BIP 173 example address; the info-hashes are placeholders.
* `manifest_with_invoice.json` – carries the BOLT 11 specification's example invoice in
  `lightning_address`; it must be rejected (invoices expire and are single-use).
