# Payment test fixtures

No static invoices are stored here. BOLT11 test invoices are generated at test
time by `tests/fakes/payments.py::make_invoice`, signed with a throwaway
secp256k1 key that controls no funds, for any of mainnet / testnet / signet /
regtest. The one static vector used (in `tests/unit/test_payment_invoices.py`)
is the "1 cup coffee" example from the BOLT #11 specification.

Bitcoin address vectors in `tests/unit/test_payment_bitcoin_uri.py` come from
BIP173 and BIP350 plus well-known Base58Check examples.

Automated tests never touch real funds: the default suite uses
`FakeLightningBackend`; the optional LND test requires a **regtest** node and
refuses to run against any other network.
