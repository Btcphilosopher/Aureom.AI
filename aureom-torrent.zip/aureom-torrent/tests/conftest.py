from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture
def nodes(tmp_path):
    """Factory for isolated application nodes; all are shut down after the test."""
    from tests.support import Node

    created = []

    def factory(name: str) -> "Node":
        node = Node(tmp_path / "homes" / name)
        created.append(node)
        return node

    yield factory
    for node in created:
        try:
            node.stop(5)
        except Exception:
            pass
