"""GUI smoke tests (Qt offscreen): the real window on top of a fake engine.

They check wiring, model/view behaviour and keyboard reachability – not pixels.
"""

from __future__ import annotations

import pytest
from PySide6.QtCore import Qt
from PySide6.QtGui import QKeySequence
from PySide6.QtWidgets import QCheckBox, QLineEdit, QPushButton, QRadioButton, QTableView

from aureom_torrent.app import AppContext
from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.domain.transfers import EnginePhase, TransferState, TransferView
from aureom_torrent.engine import commands as c
from aureom_torrent.engine import events as e
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec, LibtorrentCreator
from aureom_torrent.settings.secrets import MemorySecretStore
from aureom_torrent.ui.main_window import NAV, SHORTCUTS, MainWindow
from aureom_torrent.ui.models.rows import ROW_ROLE, Column, RowsModel
from aureom_torrent.ui.models.transfers import FILTERS, TransferFilterProxy, TransferTableModel, filter_counts
from aureom_torrent.ui.transfers.dialogs import FileSelectionModel, TrackersDialog
from tests.fakes.engine import FakeEngine, status
from tests.support import create_torrent, make_payload

pytestmark = pytest.mark.gui


def view(i: int, **kw) -> TransferView:
    base = dict(id=f"{i:032x}", name=f"item {i:04d}", identity=TorrentIdentity(f"{i:040x}", None),
                state=TransferState.DOWNLOADING, state_detail="", size=1000 + i, total_size=1000 + i,
                progress_ppm=i * 100 % 1_000_000, selected_complete=False, torrent_complete=False,
                download_rate=i, upload_rate=0, peers=1, seeds=0, ratio_permille=0, eta_seconds=10,
                category="", save_path="/dl", added_at=0, has_metadata=True, private=False, preview=False,
                manual_paused=False, error="", downloaded=0, uploaded=0, pieces_have=0, pieces_total=10,
                seeding_seconds=0, last_announce={}, source="file", live=True)
    base.update(kw)
    return TransferView(**base)


# ------------------------------------------------------------------ models
def test_rows_model_emits_narrow_updates(qtbot):
    model = RowsModel([Column("Name", lambda r: r[1])], key=lambda r: r[0])
    resets, inserts, removes, changes = [], [], [], []
    model.modelReset.connect(lambda: resets.append(1))
    model.rowsInserted.connect(lambda *_: inserts.append(1))
    model.rowsRemoved.connect(lambda *_: removes.append(1))
    model.dataChanged.connect(lambda a, b: changes.append((a.row(), b.row())))
    model.set_rows([(1, "a"), (2, "b"), (3, "c")])
    assert model.rowCount() == 3 and not resets  # first fill is insert-only
    inserts.clear()
    model.set_rows([(1, "a"), (2, "B"), (3, "c")])
    assert changes == [(1, 1)] and not resets and not inserts
    model.set_rows([(1, "a"), (3, "c"), (4, "d")])
    assert removes and inserts and not resets and [r[0] for r in model.rows()] == [1, 3, 4]
    model.set_rows([(4, "d"), (1, "a")])  # reordering falls back to a reset
    assert resets and [r[0] for r in model.rows()] == [4, 1]


def test_transfer_table_scales_and_filters(qtbot):
    model = TransferTableModel()
    proxy = TransferFilterProxy()
    proxy.setSourceModel(model)
    table = QTableView()
    table.setModel(proxy)
    qtbot.addWidget(table)
    views = [view(i) for i in range(20_000)]
    views[5] = view(5, state=TransferState.ERROR, error="disk full")
    views[6] = view(6, state=TransferState.SEEDING, selected_complete=True, torrent_complete=True, progress_ppm=1_000_000)
    views[7] = view(7, state=TransferState.PAUSED, manual_paused=True)
    views[8] = view(8, state=TransferState.DOWNLOADING, state_detail="Stalled — no peers connected", progress_ppm=999_999)
    model.set_rows(views)
    assert proxy.rowCount() == 20_000
    changed = []
    model.dataChanged.connect(lambda a, b: changed.append((a.row(), b.row())))
    views2 = list(views)
    views2[100] = view(100, download_rate=999_999)
    model.set_rows(views2)
    assert changed == [(100, 100)]  # one row repainted out of 20 000

    counts = filter_counts(views)
    assert counts["errors"] == 1 and counts["seeding"] == 1 and counts["completed"] == 1 and counts["paused"] == 1
    assert set(FILTERS) == {k for k, _ in NAV if k in FILTERS}
    proxy.set_filter("errors")
    assert proxy.rowCount() == 1 and proxy.index(0, 0).data(ROW_ROLE).id == views[5].id
    proxy.set_filter("completed")
    assert proxy.rowCount() == 1  # the stalled 99.9 % transfer is not listed as completed
    proxy.set_filter("all")
    proxy.set_search("item 0042")
    assert proxy.rowCount() == 1
    # the stalled transfer's cells
    proxy.set_search("item 0008")
    assert proxy.index(0, 2).data() == "99.9%" and proxy.index(0, 3).data() == "Downloading (stalled)"


def test_file_selection_model_and_tracker_dialog(qtbot, tmp_path):
    created = create_torrent(make_payload(tmp_path / "p", {"a.bin": 5000, "d/b.bin": 7000}), "hybrid")
    model = FileSelectionModel(created.metadata)
    assert model.rowCount() == 2 and model.selected_size() == 12_000  # pad files are hidden
    model.setData(model.index(0, 0), Qt.CheckState.Unchecked, Qt.ItemDataRole.CheckStateRole)
    assert model.selected_count() == 1 and len(model.priorities()) == len(created.metadata.files)
    model.set_priority([1], 7)
    assert model.index(1, 2).data() == "High" and model.selected_size() == 7000

    dialog = TrackersDialog([("udp://a/1", 0), ("udp://b/1", 0), ("https://c/1", 1)], private=True)
    qtbot.addWidget(dialog)
    assert dialog.trackers() == [("udp://a/1", 0), ("udp://b/1", 0), ("https://c/1", 1)]
    dialog.text.setPlainText("udp://x/1\n\n\nudp://y/1\nudp://z/1")
    assert dialog.trackers() == [("udp://x/1", 0), ("udp://y/1", 1), ("udp://z/1", 1)]


# ------------------------------------------------------------ main window
@pytest.fixture
def app_window(qtbot, tmp_path):
    engine = FakeEngine()
    ctx = AppContext(tmp_path / "home", engine=engine, codec=LibtorrentCodec(), creator=LibtorrentCreator(),
                     secrets=MemorySecretStore(), isolated=True)
    ctx.start()
    window = MainWindow(ctx)
    qtbot.addWidget(window)
    window.show()
    yield window, ctx, engine
    window._shutdown_done = True  # skip the asynchronous close path in tests
    window._timer.stop()
    window._wallet_timer.stop()
    window.bridge.close()
    window.close()
    ctx.shutdown(1.0)


def test_main_window_structure_and_navigation(app_window, qtbot):
    window, ctx, engine = app_window
    assert window.windowTitle() == "AUREOM TORRENT"
    labels = [window.nav.item(i).text() for i in range(window.nav.count()) if window.nav.item(i).text()]
    assert labels == ["All Transfers", "Downloading", "Seeding", "Completed", "Paused", "Checking", "Errors",
                      "RSS Feeds", "Publish & Share", "Payments", "Settings"]
    assert [a.text() for a in window.toolbar.actions() if a.text()] == [
        "Add Torrent", "Add Magnet", "Create Torrent", "Start", "Pause"]
    assert window.search.placeholderText() == "Search transfers"
    assert [window.transfers_page.tabs.tabText(i) for i in range(7)] == [
        "Overview", "Files", "Peers", "Trackers", "Pieces", "Activity", "Publisher"]
    headers = [window.transfers_page.model.headerData(i, Qt.Orientation.Horizontal) for i in range(11)]
    assert headers == ["Name", "Size", "Verified", "State", "Down", "Up", "Peers", "Ratio", "ETA", "Category",
                       "Destination"]
    for key, page in (("feeds", window.feeds_page), ("publish", window.publish_page),
                      ("payments", window.payments_page), ("settings", window.settings_page),
                      ("errors", window.transfers_page)):
        window.navigate(key)
        assert window.stack.currentWidget() is page
    assert window.transfers_page.proxy._filter == "errors"
    # every toolbar action and documented shortcut is keyboard reachable
    assert {a.shortcut().toString() for a in window.toolbar.actions() if a.text()} == {
        "Ctrl+O", "Ctrl+Shift+O", "Ctrl+N", "Ctrl+S", "Ctrl+P"}
    assert len(SHORTCUTS) >= 12
    # interactive controls carry accessible names or visible text
    for page in (window.feeds_page, window.payments_page, window.settings_page, window.publish_page):
        for kind in (QPushButton, QCheckBox, QRadioButton):
            for button in page.findChildren(kind):
                assert button.text() or button.accessibleName(), button
    secret_fields = [edit for edit in window.settings_page.findChildren(QLineEdit)
                     if edit.echoMode() == QLineEdit.EchoMode.Password]
    assert len(secret_fields) == 2  # macaroon and proxy password are never shown in clear text
    qtbot.waitUntil(lambda: "Wallet: not configured" in window.st_wallet.text(), timeout=5000)


def test_live_updates_selection_and_controls(app_window, qtbot, tmp_path):
    window, ctx, engine = app_window
    created = create_torrent(make_payload(tmp_path / "src" / "demo", {"a.bin": 50_000}), "v1")
    dest = tmp_path / "dl"
    dest.mkdir()
    tid = ctx.transfers.add_torrent_data(created.torrent_data, save_path=str(dest), category="Docs").transfer_id
    engine.deliver(e.TorrentAdded(tid, created.metadata.identity, "demo", True),
                   e.StatusBatch((status(tid, total_wanted=50_000, wanted_done=25_000, download_rate=4096, num_peers=2),)))
    window.navigate("all")
    page = window.transfers_page
    qtbot.waitUntil(lambda: page.proxy.rowCount() == 1 and page.proxy.index(0, 3).data() == "Downloading", timeout=5000)
    assert page.proxy.index(0, 2).data() == "50.0%" and page.proxy.index(0, 9).data() == "Docs"
    assert "↓ 4.0 KiB/s" in window.st_speed.text() and "1 active of 1" in window.st_active.text()
    assert window._nav_items["downloading"].text().endswith("1")

    assert not window.act_start.isEnabled()
    page.table.selectRow(0)
    assert window.act_pause.isEnabled() and page.selected_ids() == [tid]
    assert "demo" in page.ov["name"].text() and "Not complete" in page.ov["complete"].text()

    window.act_pause.trigger()
    qtbot.waitUntil(lambda: bool(engine.of(c.PauseTorrent)), timeout=5000)
    engine.deliver(e.StatusBatch((status(tid, total_wanted=50_000, wanted_done=25_000, paused=True, auto_managed=False),)))
    qtbot.waitUntil(lambda: page.proxy.index(0, 3).data() == "Paused", timeout=5000)
    window.act_start.trigger()
    qtbot.waitUntil(lambda: bool(engine.of(c.ResumeTorrent)), timeout=5000)

    # an engine error surfaces in the banner and in the Errors filter, never as completion
    engine.deliver(e.TorrentErrored(tid, "No space left on device", "a.bin"),
                   e.StatusBatch((status(tid, total_wanted=50_000, wanted_done=25_000, error="No space left on device",
                                         paused=True),)))
    qtbot.waitUntil(lambda: window.banner.isVisible() and "disk is full" in window.banner.label.text(), timeout=5000)
    window.navigate("errors")
    qtbot.waitUntil(lambda: page.proxy.rowCount() == 1, timeout=5000)
    window.navigate("completed")
    assert page.proxy.rowCount() == 0

    # details are requested for the visible tab only
    window.navigate("all")
    page.table.selectRow(0)
    engine.clear()
    page.tabs.setCurrentIndex(2)  # Peers
    qtbot.waitUntil(lambda: any(isinstance(cmd, c.RequestDetails) and cmd.peers and not cmd.pieces
                                for cmd in engine.commands), timeout=5000)

    # theme and density switch live
    settings = ctx.settings.snapshot()
    settings.ui.theme, settings.ui.density = "dark", "comfortable"
    ctx.settings.save(settings)
    window.apply_theme()
    assert window.palette_.name == "dark" and page.table.verticalHeader().defaultSectionSize() == 34


def test_settings_page_round_trip_keeps_secrets_out_of_the_database(app_window, qtbot):
    window, ctx, engine = app_window
    page = window.settings_page
    window.navigate("settings")
    page.max_down.setValue(7)
    page.backend.setCurrentIndex(page.backend.findData("lnd_rest"))
    page.lnd_url.setText("https://127.0.0.1:8080")
    page.macaroon.setText("0201036C6E6402F801")
    page.proxy_kind.setCurrentIndex(page.proxy_kind.findData("socks5_pw"))
    page.proxy_password.setText("proxy-secret-pw")
    page.net_feeds.proxy.setText("socks5://127.0.0.1:9050")
    page.save()
    qtbot.waitUntil(lambda: page.saved_label.text().startswith("Saved"), timeout=5000)
    saved = ctx.settings.get()
    assert saved.queue.max_active_downloads == 7 and saved.payments.backend == "lnd_rest"
    assert saved.feeds_network.proxy_url == "socks5://127.0.0.1:9050" and saved.publishing_network.proxy_url == ""
    from aureom_torrent.settings.secrets import SECRET_BT_PROXY_PASSWORD, SECRET_LND_MACAROON

    assert ctx.secrets.get(SECRET_LND_MACAROON) == "0201036c6e6402f801"
    assert ctx.secrets.get(SECRET_BT_PROXY_PASSWORD) == "proxy-secret-pw"
    dump = " ".join(str(tuple(row)) for row in ctx.db.query("SELECT key, value FROM settings"))
    assert "0201036c6e6402f801" not in dump.lower() and "proxy-secret-pw" not in dump
    assert page.macaroon.text() == "" and page.proxy_password.text() == ""  # cleared after saving
    # the engine received the new queue limits and the proxy password
    qtbot.waitUntil(lambda: any(isinstance(cmd, c.ApplySettings) and cmd.settings.active_downloads == 7
                                and cmd.settings.proxy_password == "proxy-secret-pw" for cmd in engine.commands),
                    timeout=5000)
    assert "0201036c6e6402f801" not in ctx.diagnostics.export_json().lower()
    assert "proxy-secret-pw" not in ctx.diagnostics.export_json()


def test_feed_content_is_rendered_without_remote_resources(app_window, qtbot):
    window, ctx, engine = app_window
    browser = window.feeds_page.content
    assert not browser.openLinks() and not browser.openExternalLinks()
    browser.setHtml('<p>hello <img src="http://tracker.invalid/pixel.png"> <a href="http://x.invalid/">link</a></p>')
    assert browser.loadResource(2, "http://tracker.invalid/pixel.png") is None
    assert "hello" in browser.toPlainText()
