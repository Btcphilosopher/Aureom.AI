"""BOLT11 validation policy on top of the bolt11 library."""

import pytest

from aureom_torrent.payments.invoices import (InvoiceError, decode_invoice, normalise_invoice_text,
                                              sanitise_text, validate_invoice)
from tests.fakes.payments import TEST_NODE_PUBKEY, make_invoice

NOW = 1_800_000_000
KW = dict(expected_network="regtest", now=NOW, min_msat=1_000, max_msat=100_000_000)

# From the BOLT #11 specification examples (mainnet, 2500 µBTC, "1 cup coffee", 60 s expiry, 2017).
SPEC_VECTOR = ("lnbc2500u1pvjluezsp5zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zygspp5qqqsyqcyq5rqwzqfqqqsyqcyq5"
               "rqwzqfqqqsyqcyq5rqwzqfqypqdq5xysxxatsyp3k7enxv4jsxqzpu9qrsgquk0rl77nj30yxdy8j9vdx85fkpmdla2087ne0xh8"
               "nhedh8w27kyke0lp53ut353s06fv3qfegext0eh0ymjpf39tuven09sam30g4vgpfna3rh")


@pytest.mark.parametrize("network", ["mainnet", "testnet", "signet", "regtest"])
def test_valid_invoice_per_network(network):
    pr, payment_hash = make_invoice(network=network, amount_msat=123_456, description="Thanks!", created_at=NOW)
    v = validate_invoice(pr, **{**KW, "expected_network": network})
    assert v.network == network
    assert v.payment_hash == payment_hash
    assert v.amount_msat == v.invoice_amount_msat == 123_456
    assert v.payee == TEST_NODE_PUBKEY
    assert v.description == "Thanks!"
    assert v.created_at == NOW and v.expires_at == NOW + 3600
    assert not v.amountless


def test_spec_vector_decodes_and_is_expired():
    text, inv = decode_invoice(SPEC_VECTOR)
    assert inv.currency == "bc" and int(inv.amount_msat) == 250_000_000
    assert inv.payment_hash == "0001020304050607080900010203040506070809000102030405060708090102"
    with pytest.raises(InvoiceError) as err:
        validate_invoice(SPEC_VECTOR, expected_network="mainnet", now=NOW, min_msat=1, max_msat=10**12)
    assert err.value.reason == "expired"


def test_lightning_prefix_and_case_are_normalised():
    pr, _ = make_invoice(created_at=NOW)
    assert normalise_invoice_text("  lightning:" + pr + "\n") == pr
    assert normalise_invoice_text("LIGHTNING:" + pr.upper()) == pr
    assert validate_invoice("lightning:" + pr.upper(), **KW).bolt11 == pr


def test_wrong_network_rejected():
    pr, _ = make_invoice(network="mainnet", created_at=NOW)
    with pytest.raises(InvoiceError) as err:
        validate_invoice(pr, **KW)
    assert err.value.reason == "network"
    assert "mainnet" in str(err.value) and "regtest" in str(err.value)


def test_expired_and_about_to_expire_rejected():
    pr, _ = make_invoice(created_at=NOW - 7200, expiry=3600)
    with pytest.raises(InvoiceError) as err:
        validate_invoice(pr, **KW)
    assert err.value.reason == "expired"
    pr, _ = make_invoice(created_at=NOW - 3590, expiry=3600)  # 10 s left: inside the safety margin
    with pytest.raises(InvoiceError) as err:
        validate_invoice(pr, **KW)
    assert err.value.reason == "expired"
    assert validate_invoice(pr, **KW, expiry_margin_s=5).expires_at == NOW + 10


def test_future_dated_invoice_rejected():
    pr, _ = make_invoice(created_at=NOW + 3 * 3600)
    with pytest.raises(InvoiceError):
        validate_invoice(pr, **KW)


def test_amountless_invoice_requires_explicit_amount():
    pr, _ = make_invoice(amount_msat=None, created_at=NOW)
    with pytest.raises(InvoiceError) as err:
        validate_invoice(pr, **KW)
    assert err.value.reason == "amount_required"
    with pytest.raises(InvoiceError):
        validate_invoice(pr, **KW, amount_msat=0)
    v = validate_invoice(pr, **KW, amount_msat=50_000)
    assert v.amountless and v.amount_msat == 50_000 and v.invoice_amount_msat is None


def test_fixed_amount_cannot_be_overridden():
    pr, _ = make_invoice(amount_msat=10_000, created_at=NOW)
    with pytest.raises(InvoiceError) as err:
        validate_invoice(pr, **KW, amount_msat=20_000)
    assert err.value.reason == "amount"
    assert validate_invoice(pr, **KW, amount_msat=10_000).amount_msat == 10_000


@pytest.mark.parametrize("bad_amount", [1.5, "1000", True])
def test_non_integer_amount_rejected(bad_amount):
    pr, _ = make_invoice(amount_msat=None, created_at=NOW)
    with pytest.raises(InvoiceError):
        validate_invoice(pr, **KW, amount_msat=bad_amount)


def test_limits_enforced():
    low, _ = make_invoice(amount_msat=999, created_at=NOW)
    high, _ = make_invoice(amount_msat=100_000_001, created_at=NOW)
    for pr in (low, high):
        with pytest.raises(InvoiceError) as err:
            validate_invoice(pr, **KW)
        assert err.value.reason == "limit"


@pytest.mark.parametrize("text,reason", [
    ("lno1qgsqvgnwgcg35z6ee2h3yczraddm72xrfua9uve2rlrm9deu7xyfzrc", "unsupported"),
    ("lnurl1dp68gurn8ghj7um9wfmxjcm99e3k7mf0v9cxj0m385ekvcenxc6r2c35xvukxefcv5mkvv34x5ekzd3ev56nyd3hxqurzepexejxxepnxscrvwfnv9nxzcn9xq6xyefhvgcxxcmyxymnserxfq5fns", "unsupported"),
    ("alice@example.org", "unsupported"),
    ("bitcoin:bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", "unsupported"),
    ("hello world", "invalid"),
    ("", "invalid"),
    ("lnbc1notaninvoice", "invalid"),
    ("lnbcrt1" + "q" * 5000, "invalid"),
    ("LnBcRt1qqqq", "invalid"),
])
def test_unsupported_and_garbage_inputs(text, reason):
    with pytest.raises(InvoiceError) as err:
        validate_invoice(text, **KW)
    assert err.value.reason == reason


@pytest.mark.parametrize("value", [None, 5, b"lnbc"])
def test_non_text_rejected(value):
    with pytest.raises(InvoiceError):
        normalise_invoice_text(value)


def test_tampered_invoice_fails_signature_or_checksum():
    pr, _ = make_invoice(created_at=NOW)
    tampered = pr[:-10] + ("q" if pr[-10] != "q" else "p") + pr[-9:]
    with pytest.raises(InvoiceError):
        validate_invoice(tampered, **KW)


def test_description_is_sanitised_for_display():
    pr, _ = make_invoice(description="Pay‮ me\x00\nnow " + "x" * 600, created_at=NOW)
    v = validate_invoice(pr, **KW)
    assert "‮" not in v.description and "\x00" not in v.description and "\n" not in v.description
    assert len(v.description) <= 280 and v.description.endswith("…")
    assert sanitise_text(None) == "" and sanitise_text("  a \t b ") == "a b"


def test_description_hash_only_invoice():
    pr, _ = make_invoice(description_hash="ab" * 32, created_at=NOW)
    v = validate_invoice(pr, **KW)
    assert v.description == "" and v.description_hash == "ab" * 32
