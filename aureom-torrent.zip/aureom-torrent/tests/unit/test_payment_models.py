"""The payment state machine: every transition is either explicitly allowed or rejected."""

import itertools

import pytest

from aureom_torrent.payments.models import (BLOCKING_STATES, TERMINAL_STATES, InvalidPaymentState,
                                            PaymentDirection, PaymentIntent, PaymentKind, PaymentState,
                                            allowed_transitions, can_transition)
from aureom_torrent.payments.repository import PaymentRepository
from aureom_torrent.persistence.database import Database

S = PaymentState

EXPECTED_DEFAULT = {
    S.DRAFT: {S.AWAITING_APPROVAL, S.CANCELLED, S.FAILED},
    S.AWAITING_APPROVAL: {S.SUBMITTED, S.CANCELLED, S.EXPIRED},
    S.SUBMITTED: {S.PENDING, S.SUCCEEDED, S.FAILED, S.UNKNOWN},
    S.PENDING: {S.SUCCEEDED, S.FAILED, S.UNKNOWN},
    S.UNKNOWN: {S.PENDING, S.SUCCEEDED, S.FAILED},
    S.SUCCEEDED: set(), S.FAILED: set(), S.EXPIRED: set(), S.CANCELLED: set(),
}
EXPECTED_RECEIVE = {
    S.DRAFT: {S.PENDING, S.FAILED, S.CANCELLED},
    S.AWAITING_APPROVAL: set(), S.SUBMITTED: set(),
    S.PENDING: {S.SUCCEEDED, S.FAILED, S.EXPIRED},
    S.UNKNOWN: set(),
    S.SUCCEEDED: set(), S.FAILED: set(), S.EXPIRED: set(), S.CANCELLED: set(),
}
EXPECTED_BITCOIN = {
    S.DRAFT: {S.AWAITING_APPROVAL, S.CANCELLED, S.FAILED},
    S.AWAITING_APPROVAL: {S.UNKNOWN, S.CANCELLED},
    S.SUBMITTED: set(), S.PENDING: set(), S.UNKNOWN: set(),
    S.SUCCEEDED: set(), S.FAILED: set(), S.EXPIRED: set(), S.CANCELLED: set(),
}


@pytest.mark.parametrize("kind,table", [
    (None, EXPECTED_DEFAULT), (PaymentKind.LIGHTNING_INVOICE, EXPECTED_DEFAULT),
    (PaymentKind.LIGHTNING_TIP, EXPECTED_DEFAULT), (PaymentKind.LIGHTNING_RECEIVE, EXPECTED_RECEIVE),
    (PaymentKind.BITCOIN_EXTERNAL, EXPECTED_BITCOIN),
])
def test_full_transition_matrix(kind, table):
    for src, dst in itertools.product(PaymentState, PaymentState):
        assert can_transition(src, dst, kind) == (dst in table[src]), (kind, src, dst)
    assert all(allowed_transitions(s, kind) == frozenset(table[s]) for s in PaymentState)


def test_terminal_states_have_no_exits_and_no_self_loops():
    for kind in (None, *PaymentKind):
        for state in PaymentState:
            assert not can_transition(state, state, kind)
        for state in TERMINAL_STATES:
            assert allowed_transitions(state, kind) == frozenset()
            assert state.terminal


def test_bitcoin_handoff_can_never_succeed():
    for src in PaymentState:
        assert not can_transition(src, S.SUCCEEDED, PaymentKind.BITCOIN_EXTERNAL)
        assert not can_transition(src, S.SUBMITTED, PaymentKind.BITCOIN_EXTERNAL)


def test_unknown_never_returns_to_approval_or_submission():
    for kind in (None, *PaymentKind):
        assert not can_transition(S.UNKNOWN, S.AWAITING_APPROVAL, kind)
        assert not can_transition(S.UNKNOWN, S.SUBMITTED, kind)
        assert not can_transition(S.UNKNOWN, S.CANCELLED, kind)
        assert not can_transition(S.FAILED, S.SUBMITTED, kind)


def test_blocking_states():
    assert BLOCKING_STATES == {S.SUBMITTED, S.PENDING, S.UNKNOWN, S.SUCCEEDED}


def _intent(state=S.DRAFT, kind=PaymentKind.LIGHTNING_INVOICE):
    return PaymentIntent(id="p1", direction=PaymentDirection.OUTGOING, kind=kind, state=state,
                         network="regtest", amount_msat=1000, created_at=10, updated_at=10)


def test_repository_enforces_the_table_and_records_history():
    repo = PaymentRepository(Database(None))
    repo.insert(_intent(), "created")
    repo.transition("p1", S.AWAITING_APPROVAL, now=11, detail="ok")
    with pytest.raises(InvalidPaymentState):
        repo.transition("p1", S.SUCCEEDED, now=12)  # cannot skip submission
    with pytest.raises(InvalidPaymentState):
        repo.transition("p1", S.SUBMITTED, now=12, expected=(S.DRAFT,))  # optimistic check
    assert repo.get("p1").state is S.AWAITING_APPROVAL  # nothing changed
    repo.transition("p1", S.SUBMITTED, now=12, fee_limit_msat=5, submitted_at=12)
    repo.transition("p1", S.UNKNOWN, now=13, detail="timeout")
    with pytest.raises(InvalidPaymentState):
        repo.transition("p1", S.SUBMITTED, now=14)  # never resubmit from UNKNOWN
    final = repo.transition("p1", S.SUCCEEDED, now=15, fee_paid_msat=2, settled_at=15)
    assert final.state is S.SUCCEEDED and final.fee_paid_msat == 2 and final.updated_at == 15
    assert [(e.from_state, e.to_state) for e in repo.events("p1")] == [
        (None, S.DRAFT), (S.DRAFT, S.AWAITING_APPROVAL), (S.AWAITING_APPROVAL, S.SUBMITTED),
        (S.SUBMITTED, S.UNKNOWN), (S.UNKNOWN, S.SUCCEEDED)]
    with pytest.raises(InvalidPaymentState):
        repo.transition("p1", S.FAILED, now=16)
    with pytest.raises(InvalidPaymentState):
        repo.transition("missing", S.FAILED, now=16)
    with pytest.raises(ValueError):
        repo.transition("p1", S.FAILED, now=16, state="x")


def test_state_labels_for_special_kinds():
    assert "not tracked" in _intent(S.UNKNOWN, PaymentKind.BITCOIN_EXTERNAL).state_label
    assert _intent(S.UNKNOWN).state_label == "Unknown outcome"
    assert all(s.label for s in PaymentState)
