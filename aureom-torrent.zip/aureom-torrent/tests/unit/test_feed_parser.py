"""Parsing and sanitisation of RSS 2.0 and Atom documents."""

from __future__ import annotations

import time

import pytest

from aureom_torrent.feeds.models import LINK_MAGNET, LINK_NONE, LINK_TORRENT
from aureom_torrent.feeds.parser import (FeedParseError, declares_entities, parse_feed, plain_text,
                                         sanitise_html)
from tests.fakes.feeds import DEFAULT_BASE, fixture_bytes, rss_document


@pytest.fixture(scope="module")
def rss():
    return parse_feed(fixture_bytes("rss_sample.xml"), base_url=DEFAULT_BASE + "/feed.xml")


@pytest.fixture(scope="module")
def atom():
    return parse_feed(fixture_bytes("atom_sample.xml"), base_url=DEFAULT_BASE + "/atom.xml")


def test_rss_feed_level_fields(rss):
    assert rss.title == "Aureom Open Data Releases"
    assert rss.site_url == DEFAULT_BASE + "/"
    assert rss.format == "rss20"
    assert rss.warning == ""
    assert len(rss.entries) == 4


def test_rss_torrent_enclosure_entry(rss):
    e = rss.entries[0]
    assert e.title == "Open Field Recordings Vol. 3 (CC0, FLAC)"
    assert e.guid == "aureom-open-data-0003"
    assert e.link == DEFAULT_BASE + "/releases/field-recordings-3"
    assert e.publisher == "Aureom Archive Team"
    assert time.gmtime(e.published)[:5] == (2026, 11, 23, 9, 30)
    assert e.link_type == LINK_TORRENT
    assert e.torrent_url == DEFAULT_BASE + "/torrents/field-recordings-3.torrent"
    # torrent:infoHash is normalised to lower-case hex
    assert e.v1 == "3b1a7c0e9d2f4a5b6c7d8e9f0a1b2c3d4e5f6071" and e.v2 is None
    # torrent:contentLength wins over the enclosure length (which is the .torrent file's size)
    assert e.size == 734003200
    assert "<b>public-domain</b>" in e.summary_html and "<li>" in e.summary_html
    assert "public-domain field recordings" in e.summary_text


def test_rss_magnet_enclosure_entry(rss):
    e = rss.entries[1]
    assert e.link_type == LINK_MAGNET
    assert e.torrent_url == ""
    assert e.magnet.startswith("magnet:?xt=urn:btih:8f2c1d0b9a7e6f5d4c3b2a190817263544536271")
    assert "tr=udp%3A%2F%2Ftracker.example.org%3A6969%2Fannounce" in e.magnet
    assert e.v1 == "8f2c1d0b9a7e6f5d4c3b2a190817263544536271"
    assert e.size is None  # a zero enclosure length is not a size


def test_rss_plain_entry_has_no_download_link(rss):
    e = rss.entries[2]
    assert e.link_type == LINK_NONE and not e.torrent_url and not e.magnet


def test_hostile_markup_is_removed(rss):
    html = rss.entries[2].summary_html
    lowered = html.lower()
    for forbidden in ("<script", "alert(", "<img", "onclick", "javascript:", "<iframe", "<style", "color:red",
                      "tracking-pixel"):
        assert forbidden not in lowered, forbidden
    assert "The archive will be read-only on Sunday." in html
    # the harmless link survives, with rel set and nothing else
    assert f'<a href="{DEFAULT_BASE}/news/maintenance" rel="noopener noreferrer">read more</a>' in html
    assert "alert" not in rss.entries[2].summary_text


def test_magnet_found_in_content_gives_hybrid_identity(rss):
    e = rss.entries[3]
    assert e.link_type == LINK_MAGNET
    assert e.v1 == "0a1b2c3d4e5f60718293a4b5c6d7e8f901234567"
    assert e.v2 == "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"
    # magnet: links are not allowed as clickable markup
    assert "magnet:" not in e.summary_html


def test_atom_entries(atom):
    assert atom.title == "Libre Typeface Builds" and atom.format == "atom10"
    assert len(atom.entries) == 2
    first, second = atom.entries
    assert first.guid == "urn:uuid:5f0c2a0e-4c1b-4f6e-9a57-000000000002"
    assert first.link == DEFAULT_BASE + "/builds/meridian-2.4"
    # a relative enclosure address is resolved against the feed address
    assert first.torrent_url == DEFAULT_BASE + "/torrents/meridian-sans-2.4.torrent"
    assert first.link_type == LINK_TORRENT and first.size == 9120
    assert first.publisher == "Libre Type Collective"  # feed-level author
    assert time.gmtime(first.published)[:3] == (2026, 11, 24)
    assert first.summary_html == "<p>Variable and static builds. Licence: <em>SIL OFL 1.1</em>.</p>"
    # no MIME type, but the path ends in .torrent
    assert second.link_type == LINK_TORRENT
    assert second.torrent_url.endswith("/torrents/meridian-sans-2.3-src.torrent")
    assert second.publisher == "Build Bot"  # entry-level author
    assert second.size is None


@pytest.mark.parametrize("body", [b"", b"   \n", b"this is not xml at all",
                                  fixture_bytes("malformed_not_a_feed.html"), b"{\"json\": true}"])
def test_non_feeds_are_rejected(body):
    with pytest.raises(FeedParseError):
        parse_feed(body)


def test_truncated_document_keeps_complete_entries_and_warns():
    parsed = parse_feed(fixture_bytes("truncated.xml"))
    assert [e.title for e in parsed.entries][:1] == ["Complete Item (CC0)"]
    assert parsed.warning


def test_entity_declarations_are_refused_quickly():
    body = fixture_bytes("entity_bomb.xml")
    assert declares_entities(body)
    started = time.monotonic()
    with pytest.raises(FeedParseError, match="entities"):
        parse_feed(body)
    assert time.monotonic() - started < 0.5
    assert declares_entities('<?xml version="1.0"?><!DOCTYPE r [<!ENTITY a "b">]><rss/>'.encode("utf-16"))
    assert not declares_entities(fixture_bytes("rss_sample.xml"))


def test_entry_limit_and_field_limits():
    items = [{"title": f"Item {i} " + "x" * 2000, "guid": f"g{i}", "link": f"{DEFAULT_BASE}/i/{i}"}
             for i in range(30)]
    parsed = parse_feed(rss_document(items), max_entries=10)
    assert len(parsed.entries) == 10 and parsed.truncated
    assert all(len(e.title) <= 500 for e in parsed.entries)


def test_invalid_download_links_are_ignored():
    items = [
        {"title": "bad magnet", "guid": "a", "magnet": "magnet:?xt=urn:btih:nothex"},
        {"title": "ftp torrent", "guid": "b", "torrent": "ftp://example.org/a.torrent"},
        {"title": "credentials", "guid": "c", "torrent": "https://user:pw@example.org/a.torrent"},
        {"title": "file scheme", "guid": "d", "torrent": "file:///etc/passwd.torrent"},
        {"title": "silly sizes", "guid": "e", "torrent": "https://example.org/e.torrent", "length": -5,
         "size": 10 ** 30},
    ]
    parsed = parse_feed(rss_document(items))
    by_title = {e.title: e for e in parsed.entries}
    for title in ("bad magnet", "ftp torrent", "credentials", "file scheme"):
        assert by_title[title].link_type == LINK_NONE, title
    assert by_title["silly sizes"].link_type == LINK_TORRENT
    assert by_title["silly sizes"].size is None


def test_sanitise_helpers():
    dirty = ('<p style="x" onmouseover="y">a<img src=x onerror=alert(1)><svg onload=alert(1)></svg>'
             '<a href="data:text/html,x">d</a><a href="https://ok.example/">ok</a><!-- c --></p>')
    clean = sanitise_html(dirty)
    assert clean == '<p>a<a rel="noopener noreferrer">d</a><a href="https://ok.example/" rel="noopener noreferrer">ok</a></p>'
    assert plain_text("<p>a &amp; b</p><p>c</p><script>evil()</script>") == "a & b c"
    assert sanitise_html("") == "" and plain_text("") == ""
    huge = "<p>" + "word " * 20000 + "</p>"
    assert len(sanitise_html(huge)) < 6000
