"""Integer-only amount arithmetic and BTC formatting/parsing."""

import ast
from pathlib import Path

import pytest

import aureom_torrent.payments as payments_pkg
from aureom_torrent.payments.amounts import (MAX_SAT, AmountError, fee_cap_msat, format_btc, format_msat,
                                             format_sats, msat_is_whole_sat, msat_to_sat_ceil,
                                             msat_to_sat_floor, parse_btc_decimal, parse_sats, require_int,
                                             sat_to_msat)


def test_sat_msat_conversion_and_rounding_direction():
    assert sat_to_msat(1) == 1000
    assert sat_to_msat(0) == 0
    assert msat_to_sat_floor(1999) == 1  # received: never overstated
    assert msat_to_sat_ceil(1001) == 2  # paid: never understated
    assert msat_to_sat_ceil(1000) == 1
    assert msat_to_sat_ceil(0) == 0
    assert msat_is_whole_sat(5000) and not msat_is_whole_sat(5001)
    assert sat_to_msat(MAX_SAT) == 2_100_000_000_000_000_000


@pytest.mark.parametrize("bad", [1.0, "1", None, True, 1.5])
def test_amounts_must_be_plain_integers(bad):
    with pytest.raises(AmountError):
        require_int(bad)
    with pytest.raises(AmountError):
        sat_to_msat(bad)


def test_out_of_range_amounts_rejected():
    with pytest.raises(AmountError):
        sat_to_msat(-1)
    with pytest.raises(AmountError):
        sat_to_msat(MAX_SAT + 1)
    with pytest.raises(AmountError):
        msat_to_sat_floor(-1)


def test_formatting_is_exact():
    assert format_sats(1) == "1 sat"
    assert format_sats(1234567) == "1,234,567 sats"
    assert format_msat(21_000) == "21 sats"
    assert format_msat(1_234_567) == "1,234.567 sats"
    assert format_msat(1) == "0.001 sats"
    assert format_btc(1) == "0.00000001"
    assert format_btc(100_000_000) == "1.00000000"
    assert format_btc(2_099_999_997_690_000) == "20999999.97690000"
    assert format_btc(123_456_789, trim=True) == "1.23456789"
    assert format_btc(150_000_000, trim=True) == "1.5"
    assert format_btc(100_000_000, trim=True) == "1"
    assert format_btc(0, trim=True) == "0"
    # 0.1 + 0.2 style cases that break binary floating point stay exact
    assert format_btc(10_000_000 + 20_000_000, trim=True) == "0.3"


@pytest.mark.parametrize("text,sats", [
    ("0.00000001", 1), ("1", 100_000_000), ("1.0", 100_000_000), ("0.1", 10_000_000),
    ("0.3", 30_000_000), ("20999999.9769", 2_099_999_997_690_000), ("21000000", MAX_SAT),
    (" 0.5 ", 50_000_000), ("00000001.00000000", 100_000_000),
])
def test_parse_btc_decimal_valid(text, sats):
    assert parse_btc_decimal(text) == sats


@pytest.mark.parametrize("text", [
    "", ".", ".5", "1.", "0.000000001", "1e-8", "1E8", "-1", "+1", "1,5", "0x10", "1 000", "NaN", "inf",
    "21000000.00000001", "１", "1.2.3", "1_000",
])
def test_parse_btc_decimal_rejects(text):
    with pytest.raises(AmountError):
        parse_btc_decimal(text)


@pytest.mark.parametrize("value", [0.5, 1, None, b"1"])
def test_parse_btc_decimal_requires_text(value):
    with pytest.raises(AmountError):
        parse_btc_decimal(value)


def test_btc_round_trip_is_lossless():
    for sats in (0, 1, 9, 10, 99_999_999, 100_000_000, 100_000_001, 123_456_789_012, MAX_SAT):
        assert parse_btc_decimal(format_btc(sats)) == sats
        assert parse_btc_decimal(format_btc(sats, trim=True)) == sats


def test_parse_sats():
    assert parse_sats("1,000") == 1000
    assert parse_sats(" 21 ") == 21
    assert parse_sats(5) == 5
    for bad in ("1.5", "-3", "abc", "", 1.0, True, "1e3"):
        with pytest.raises(AmountError):
            parse_sats(bad)


def test_fee_cap_uses_ceiling_and_floor():
    assert fee_cap_msat(1_000_000, 10_000, 0) == 10_000  # exactly 1 %
    assert fee_cap_msat(1_001, 10_000, 0) == 11  # ceil(10.01)
    assert fee_cap_msat(1_000, 10_000, 5) == 5_000  # floor of 5 sats wins
    assert fee_cap_msat(0, 10_000, 0) == 0
    with pytest.raises(AmountError):
        fee_cap_msat(1000, -1, 0)


def test_payment_code_contains_no_floating_point():
    """No ``float(...)`` calls, float literals or true division anywhere in the payments package."""
    root = Path(payments_pkg.__file__).parent
    offenders: list[str] = []
    files = sorted(root.rglob("*.py"))
    assert len(files) >= 10
    for path in files:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            where = f"{path.relative_to(root)}:{getattr(node, 'lineno', '?')}"
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "float":
                offenders.append(f"{where} float() call")
            elif isinstance(node, ast.Constant) and isinstance(node.value, float):
                offenders.append(f"{where} float literal {node.value!r}")
            elif isinstance(node, (ast.BinOp, ast.AugAssign)) and isinstance(node.op, ast.Div):
                offenders.append(f"{where} true division")
            elif isinstance(node, ast.Name) and node.id == "Decimal":
                offenders.append(f"{where} Decimal")
    assert offenders == []


def test_payments_package_does_not_import_feeds():
    root = Path(payments_pkg.__file__).parent
    for path in root.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.ImportFrom):
                names = [node.module or ""]
            elif isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            assert not any("feeds" in n.split(".") for n in names), f"{path} imports feeds"
