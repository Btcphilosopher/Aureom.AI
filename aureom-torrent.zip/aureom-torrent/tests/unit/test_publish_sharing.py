"""QR capacity handling, share text, the static publisher page and the Atom catalogue entry."""

from __future__ import annotations

from html.parser import HTMLParser
from urllib.parse import quote

import feedparser
import pytest
import segno

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.domain.magnet import MAX_MAGNET_LENGTH, parse_magnet
from aureom_torrent.domain.transfers import TorrentFile, TorrentMetadata
from aureom_torrent.publishing import sharing
from aureom_torrent.publishing.manifests import assess_trust, build_manifest, generate_signing_key, sign_manifest

V1 = "ab" * 20
V2 = "cd" * 32
IDENT = TorrentIdentity(V1, V2)
MAGNET = f"magnet:?xt=urn:btih:{V1}&xt=urn:btmh:1220{V2}&dn=Open+Data&tr=" + quote("udp://tracker.example:6969/announce", safe="")


def long_magnet(trackers: int = 40) -> str:
    extra = "".join("&tr=" + quote(f"https://tracker{i}.example.org/announce/long-path-segment-{i:04d}", safe="")
                    for i in range(trackers))
    return MAGNET + extra + "&ws=" + quote("https://seed.example.org/files/", safe="")


# -- QR ------------------------------------------------------------------------

def test_qr_for_a_normal_magnet_has_svg_and_png():
    qr = sharing.make_magnet_qr(MAGNET)
    assert qr.ok and not qr.trimmed and qr.payload == MAGNET
    assert qr.version <= sharing.QR_MAX_VERSION
    assert qr.svg.startswith("<?xml") and "<svg" in qr.svg and "<path" in qr.svg
    assert qr.svg_inline.startswith("<svg") and "<script" not in qr.svg_inline
    assert qr.png.startswith(b"\x89PNG\r\n\x1a\n") and len(qr.png) > 200
    assert qr.modules == 17 + 4 * qr.version


def test_qr_capacity_threshold_matches_the_documented_symbol():
    # version 25, level M, byte mode holds exactly 997 bytes
    assert sharing.QR_MAX_BYTES == 997
    assert int(segno.make("m" * 997, error="m", boost_error=False, micro=False).version) == 25
    assert int(segno.make("m" * 998, error="m", boost_error=False, micro=False).version) == 26


def test_very_long_magnet_gets_a_trimmed_code_not_an_unreadable_one():
    magnet = long_magnet()
    assert sharing.QR_MAX_BYTES < len(magnet) <= MAX_MAGNET_LENGTH
    qr = sharing.make_magnet_qr(magnet)
    assert qr.ok and qr.trimmed
    assert len(qr.payload) <= sharing.QR_MAX_BYTES and qr.version <= sharing.QR_MAX_VERSION
    trimmed = parse_magnet(qr.payload)
    assert trimmed.identity == IDENT  # still the same torrent
    assert trimmed.display_name == "Open Data"
    assert 1 <= len(trimmed.trackers) <= 3 and trimmed.trackers[0] == "udp://tracker.example:6969/announce"
    assert trimmed.web_seeds == ()
    assert "at most 997 bytes" in qr.reason and "shortened" in qr.reason


def test_trimming_can_be_refused():
    qr = sharing.make_magnet_qr(long_magnet(), allow_trim=False)
    assert not qr.ok and qr.svg == "" and qr.png == b""
    assert "997" in qr.reason
    assert qr.alternative == sharing.QR_ALTERNATIVE


def test_private_torrent_never_loses_its_tracker_in_the_qr():
    tracker = "https://private.example.org/announce/" + "k" * 1100  # a single tracker too long to fit
    magnet = f"magnet:?xt=urn:btih:{V1}&dn=Secret&tr=" + quote(tracker, safe="")
    assert sharing.make_magnet_qr(magnet, require_tracker=False).ok  # public: falls back to hash + name
    private = sharing.make_magnet_qr(magnet, require_tracker=True)
    assert not private.ok and "private" in private.reason
    assert private.alternative


def test_unusable_or_missing_magnet_yields_no_code():
    assert not sharing.make_magnet_qr("").ok
    too_long = MAGNET + "&x=" + "y" * (MAX_MAGNET_LENGTH + 10)
    qr = sharing.make_magnet_qr(too_long)
    assert not qr.ok and qr.alternative and "could not be shortened" in qr.reason


def test_trimmed_candidates_are_ordered_longest_first():
    cands = sharing.trimmed_magnet_candidates(long_magnet(5))
    assert all(c.startswith("magnet:?xt=urn:btih:") for c in cands)
    assert [len(c) for c in cands] == sorted((len(c) for c in cands), reverse=True)
    assert cands[-1] == f"magnet:?xt=urn:btih:{V1}&xt=urn:btmh:1220{V2}"
    with_tracker_only = sharing.trimmed_magnet_candidates(long_magnet(5), require_tracker=True)
    assert all("&tr=" in c for c in with_tracker_only)


# -- share text ------------------------------------------------------------------

def test_share_text_is_honest_about_availability():
    manifest = build_manifest(publisher="Example Press", licence="CC0-1.0", created=5)
    text = sharing.build_share_text(name="Open Data", total_size=5 * 1024 * 1024, file_count=3, fmt="hybrid",
                                    identity=IDENT, magnet=MAGNET, manifest=manifest,
                                    trust=assess_trust(manifest))
    lines = text.splitlines()
    assert lines[0] == "Open Data"
    assert "5.0 MiB in 3 files" in lines[1] and "hybrid" in lines[1]
    assert f"Info-hash (v1): {V1}" in text and f"Info-hash (v2): {V2}" in text
    assert "Publisher: Example Press — self-asserted" in text
    assert f"Magnet: {MAGNET}" in text
    assert "only while at least one seeder is online" in text


def test_format_size_and_stem():
    assert sharing.format_size(0) == "0 bytes"
    assert sharing.format_size(1023) == "1023 bytes"
    assert sharing.format_size(1536) == "1.5 KiB"
    assert sharing.safe_file_stem("../../etc/passwd") == "etc-passwd"
    import re

    assert re.fullmatch(r"[A-Za-z0-9._-]+", sharing.safe_file_stem("Ünï cødé ✓.iso"))
    assert sharing.safe_file_stem("///") == "torrent"
    for hostile in ("..", "a/b\\c", "con\x00", " leading", "x" * 500):
        stem = sharing.safe_file_stem(hostile)
        assert stem and "/" not in stem and "\\" not in stem and ".." not in stem and len(stem) <= 80


# -- static page -------------------------------------------------------------------

class Audit(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags: list[str] = []
        self.attrs: list[tuple[str, str, str]] = []
        self.text: list[str] = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        for k, v in attrs:
            self.attrs.append((tag, k, v or ""))

    def handle_data(self, data):
        self.text.append(data)


def audit(page: str) -> Audit:
    a = Audit()
    a.feed(page)
    return a


HOSTILE = '<script>alert("x")</script><img src=https://evil.example/p.png onerror=alert(1)>'


def hostile_page() -> str:
    meta = TorrentMetadata(
        identity=IDENT, name=HOSTILE, total_size=10, piece_length=16384, num_pieces=1,
        files=(TorrentFile(0, f"dir/{HOSTILE}.txt", 10), TorrentFile(1, ".pad/1", 5, pad=True)))
    manifest = build_manifest(publisher='Evil "Press" <b>', description="<iframe src=//evil></iframe>\nline2",
                              website="https://example.org/?a=1&b=<2>", feed_url="https://example.org/feed",
                              bitcoin_address="bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4",
                              lightning_address="tips@example.org", licence="CC0-1.0", created=5)
    return sharing.build_static_page(
        name=HOSTILE, magnet=MAGNET + "&dn=" + quote(HOSTILE), identity=IDENT, total_size=10, file_count=1,
        fmt="hybrid", metadata=meta, manifest=manifest, trust=assess_trust(manifest),
        qr=sharing.make_magnet_qr(MAGNET), public_torrent_url="https://example.org/x.torrent")


def test_static_page_has_no_scripts_or_remote_resources():
    page = hostile_page()
    a = audit(page)
    forbidden = {"script", "iframe", "object", "embed", "img", "link", "base", "form", "video", "audio", "source"}
    assert not forbidden.intersection(a.tags)
    assert not [x for x in a.attrs if x[1] == "src" or x[1] == "srcset" or x[1].startswith("on")]
    assert "url(" not in page and "@import" not in page
    # hyperlinks are the only URLs, and only on <a>
    hrefs = [(tag, v) for tag, k, v in a.attrs if k == "href"]
    assert hrefs and all(tag == "a" for tag, _ in hrefs)
    assert all(v.startswith(("magnet:?", "https://example.org/", "bitcoin:bc1q")) for _, v in hrefs)
    assert "default-src 'none'" in page  # CSP as defence in depth
    assert "<style>" in page and page.count("<style") == 1


def test_static_page_escapes_hostile_text():
    page = hostile_page()
    assert "<script>alert" not in page and "onerror=alert" not in page.replace("&lt;", "<").split("<title>")[0]
    assert "&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;" in page
    assert "&lt;iframe src=//evil&gt;" in page
    text = " ".join(audit(page).text)
    assert HOSTILE in text  # shown as text, never interpreted
    assert 'Evil "Press" <b>' in text


def test_static_page_labels_and_notes():
    page = hostile_page()
    text = " ".join(" ".join(audit(page).text).split())
    assert "(self-asserted)" in text
    assert sharing.NOTE_EXPORT_IS_NOT_PUBLISHING in text
    assert "This page is a local file. Exporting it does not publish it or host the files." in text
    assert "does not host the files" in text
    assert "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4" in text and "tips@example.org" in text
    assert "do not buy access" in text
    assert ".pad/1" not in text  # pad files are not listed
    assert "lnbc" not in page.lower()


def test_static_page_signed_and_pinned_labels():
    key = generate_signing_key()
    manifest = sign_manifest(build_manifest(publisher="Example Press", created=5), key)
    unpinned = sharing.build_static_page(name="n", magnet=MAGNET, identity=IDENT, total_size=1, file_count=1,
                                         fmt="v1", manifest=manifest, trust=assess_trust(manifest))
    assert "signed by unrecognised key (self-asserted)" in unpinned
    pinned = sharing.build_static_page(name="n", magnet=MAGNET, identity=IDENT, total_size=1, file_count=1,
                                       fmt="v1", manifest=manifest,
                                       trust=assess_trust(manifest, [manifest.signature.public_key]))
    assert "verified against a key you pinned" in pinned


def test_static_page_bounds_file_list_and_refuses_non_magnet_links():
    files = tuple(TorrentFile(i, f"f{i:04d}.bin", 1) for i in range(sharing.MAX_PAGE_FILES + 50))
    meta = TorrentMetadata(identity=IDENT, name="n", total_size=len(files), piece_length=16384, num_pieces=1,
                           files=files)
    page = sharing.build_static_page(name="n", magnet="javascript:alert(1)", identity=IDENT, total_size=1,
                                     file_count=len(files), fmt="v1", metadata=meta,
                                     public_torrent_url="javascript:alert(2)",
                                     qr=sharing.make_magnet_qr("", allow_trim=False))
    a = audit(page)
    assert not [v for _, k, v in a.attrs if k == "href"]
    assert page.count("<tr><td>") == sharing.MAX_PAGE_FILES
    assert "and 50 more files" in page
    assert "No QR code" in page


# -- Atom ---------------------------------------------------------------------------

def test_atom_feed_parses_and_yields_the_magnet():
    xml = sharing.build_atom_entry(name='Open <Data> & "more"', magnet=MAGNET, identity=IDENT,
                                   total_size=123456, file_count=3, fmt="hybrid", updated=1795596682,
                                   publisher="Example & Press", category="Datasets",
                                   public_torrent_url="https://example.org/files/open.torrent?x=1&y=2",
                                   torrent_file_size=987)
    assert xml.startswith('<?xml version="1.0" encoding="utf-8"?>')
    parsed = feedparser.parse(xml.encode("utf-8"))
    assert not parsed.bozo, parsed.get("bozo_exception")
    assert parsed.feed.title == "Example & Press — torrents"
    (entry,) = parsed.entries
    assert entry.title == 'Open <Data> & "more"'
    assert entry.link == MAGNET
    assert entry.id == f"urn:btih:{V1}"
    assert entry.author == "Example & Press"
    enclosures = [l for l in entry.links if l.rel == "enclosure"]
    assert enclosures == [{"rel": "enclosure", "type": "application/x-bittorrent",
                           "href": "https://example.org/files/open.torrent?x=1&y=2", "length": "987"}]
    assert entry.torrent_infohash == V1
    assert entry.torrent_contentlength == "123456"
    assert entry.torrent_magneturi == MAGNET
    import time

    assert entry.updated == time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(1795596682))  # RFC 3339
    assert parse_magnet(entry.link).identity == IDENT


def test_atom_without_public_url_has_no_enclosure_and_v2_only_id():
    v2_only = TorrentIdentity(None, V2)
    magnet = f"magnet:?xt=urn:btmh:1220{V2}&dn=x"
    xml = sharing.build_atom_entry(name="x", magnet=magnet, identity=v2_only, total_size=1, file_count=1,
                                   fmt="v2", updated=1795596682, public_torrent_url="javascript:alert(1)")
    parsed = feedparser.parse(xml.encode("utf-8"))
    (entry,) = parsed.entries
    assert not [l for l in entry.links if l.rel == "enclosure"]
    assert entry.id == f"urn:btmh:1220{V2}"
    assert entry.torrent_infohash == V2
    assert entry.link == magnet


def test_atom_entry_only_and_illegal_xml_characters():
    xml = sharing.build_atom_entry(name="bad\x00\x0bname", magnet=MAGNET, identity=IDENT, total_size=1,
                                   file_count=1, fmt="v1", updated=5, entry_only=True)
    assert "<entry" in xml and "<feed" not in xml and "\x00" not in xml and "\x0b" not in xml
    import xml.etree.ElementTree as ET

    root = ET.fromstring(xml.encode("utf-8"))
    assert root.tag == "{http://www.w3.org/2005/Atom}entry"
    assert root.find("{http://www.w3.org/2005/Atom}title").text == "badname"


@pytest.mark.parametrize("fmt,label", [("v1", "BitTorrent v1"), ("v2", "BitTorrent v2"),
                                       ("hybrid", "BitTorrent v1 + v2 (hybrid)")])
def test_format_labels(fmt, label):
    assert sharing.format_label(fmt) == label
