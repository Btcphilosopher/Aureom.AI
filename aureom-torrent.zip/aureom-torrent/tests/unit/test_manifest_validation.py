"""Publisher manifest schema validation and canonicalisation."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.publishing import manifests as m
from aureom_torrent.publishing.manifests import ManifestError, build_manifest, parse_manifest

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "publishing"
V1 = "ab" * 20
V2 = "cd" * 32


def base(**extra):
    data = {"schema_version": 1, "publisher": "Example Press"}
    data.update(extra)
    return data


def problems(data) -> str:
    with pytest.raises(ManifestError) as err:
        parse_manifest(data)
    assert err.value.problems
    return " | ".join(err.value.problems)


def test_fixture_with_every_field_is_accepted():
    manifest = parse_manifest((FIXTURES / "manifest_valid.json").read_bytes())
    assert manifest.publisher == "Example Open Data Collective"
    assert manifest.identity == TorrentIdentity("0123456789abcdef0123456789abcdef01234567",
                                                "0123456789abcdef" * 4)
    assert manifest.bitcoin_network == "mainnet"
    assert manifest.lightning_address == "tips@example.org"
    assert manifest.licence == "CC0-1.0"
    assert manifest.created == 1795596682
    assert manifest.has_payment_endpoint


def test_minimal_manifest():
    manifest = parse_manifest(base())
    assert manifest.to_dict() == {"schema_version": 1, "publisher": "Example Press"}
    assert not manifest.has_payment_endpoint


def test_invoice_is_rejected_as_a_permanent_payment_destination():
    text = problems((FIXTURES / "manifest_with_invoice.json").read_bytes())
    assert "invoice" in text.lower() and "expire" in text.lower()


@pytest.mark.parametrize("value", [
    "LNBC10U1PVJLUEZSP5ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYGS",
    "lightning:lnbc1pvjluezsp5zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zygs",
    "lntb20m1pvjluezsp5zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zygs",
    "lnbcrt1pvjluezsp5zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zygs",
])
def test_invoice_like_strings_rejected_for_every_network(value):
    assert "invoice" in problems(base(lightning_address=value)).lower()


@pytest.mark.parametrize("value", ["tips@example.org", "a.b+c_d-e@pay.example.co.uk",
                                   "lnurl1dp68gurn8ghj7um9wfmxjcm99e3k7mf0v9cxj0m385ekvcenxc6r2c35xvukxefcv5mkvv34x5ekzd3ev56nyd3hxqurzepexejxxepnxscrvwfnv9nxzcn9xq6xyefhvgcxxcmyxymnserxfq5fns"])
def test_lightning_address_forms_accepted(value):
    assert parse_manifest(base(lightning_address=value)).lightning_address == value


@pytest.mark.parametrize("value", ["Tips@Example.org", "tips@localhost", "tips", "@example.org",
                                   "tips@exa mple.org", "lno1qgsqvgnwgcg35z6ee2h3yczraddm72xrfua9uve2rlrm9deu7xyfzrc",
                                   "https://example.org/pay", "x" * 2000, 5, ""])
def test_bad_lightning_values_rejected(value):
    assert "lightning_address" in problems(base(lightning_address=value))


def test_schema_version_rules():
    assert "schema_version" in problems({"publisher": "x"})
    assert "not supported" in problems({"schema_version": 2, "publisher": "x"})
    assert "schema_version" in problems({"schema_version": True, "publisher": "x"})
    assert "schema_version" in problems({"schema_version": "1", "publisher": "x"})


def test_unknown_members_are_rejected_at_every_level():
    assert "Unknown manifest members: invoice" in problems(base(invoice="x"))
    assert "Unknown members in “torrent”" in problems(base(torrent={"v1": V1, "v3": "x"}))
    assert "Unknown members in “bitcoin”" in problems(
        base(bitcoin={"address": "1BoatSLRHtKNngkdXEeobR76b53LETtpyT", "network": "mainnet", "amount": 5}))
    assert "exactly the members" in problems(base(signature={"alg": "ed25519", "public_key": "00" * 32}))


def test_publisher_limits():
    assert "required" in problems({"schema_version": 1})
    assert "must be text" in problems(base(publisher=5))
    assert "must not be empty" in problems(base(publisher="   "))
    assert "longer than 120" in problems(base(publisher="x" * 121))
    assert parse_manifest(base(publisher="x" * 120)).publisher == "x" * 120
    assert "control characters" in problems(base(publisher="evil\x1b[31m"))
    assert "control characters" in problems(base(publisher="two\nlines"))
    assert "start or end with spaces" in problems(base(publisher=" padded "))
    assert "NFC" in problems(base(publisher="Cafe\u0301"))  # decomposed é


def test_description_limits_and_newlines():
    assert parse_manifest(base(description="line one\nline two")).description == "line one\nline two"
    assert "longer than 2000" in problems(base(description="d" * 2001))
    assert "control characters" in problems(base(description="tab\there"))


@pytest.mark.parametrize("field", ["website", "feed_url"])
@pytest.mark.parametrize("url", [
    "ftp://example.org/x", "javascript:alert(1)", "https://user:pw@example.org/", "https:///nohost",
    "https://example.org/a b", "HTTPS://example.org/", "https://example.org:99999/", "", 7,
    "https://example.org/" + "a" * 600, "//example.org/x", "example.org",
])
def test_bad_urls_rejected(field, url):
    assert field in problems(base(**{field: url}))


def test_good_urls_accepted():
    manifest = parse_manifest(base(website="http://example.org", feed_url="https://example.org:8443/f?x=1"))
    assert manifest.website == "http://example.org" and manifest.feed_url.endswith("?x=1")


def test_identity_validation():
    assert parse_manifest(base(torrent={"v1": V1})).identity == TorrentIdentity(V1, None)
    assert parse_manifest(base(torrent={"v2": V2})).identity == TorrentIdentity(None, V2)
    assert "torrent.v1" in problems(base(torrent={"v1": "ab" * 19}))
    assert "torrent.v1" in problems(base(torrent={"v1": V1.upper()}))
    assert "torrent.v2" in problems(base(torrent={"v2": "cd" * 20}))
    assert "torrent.v2" in problems(base(torrent={"v1": V1, "v2": 5}))
    assert "“torrent” must be an object" in problems(base(torrent={}))
    assert "“torrent” must be an object" in problems(base(torrent="urn:btih:" + V1))


@pytest.mark.parametrize("address,network", [
    ("1BoatSLRHtKNngkdXEeobR76b53LETtpyT", "mainnet"),
    ("3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy", "mainnet"),
    ("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", "mainnet"),
    ("tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx", "testnet"),
    ("tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx", "signet"),
    ("mipcBbFg9gMiCh81Kj8tqqdgoZub1ZJRfn", "testnet"),
    ("bcrt1qw508d6qejxtdg4y5r3zarvary0c5xw7kygt080", "regtest"),
])
def test_bitcoin_address_sanity_accepts(address, network):
    manifest = parse_manifest(base(bitcoin={"address": address, "network": network}))
    assert (manifest.bitcoin_address, manifest.bitcoin_network) == (address, network)


@pytest.mark.parametrize("address,network", [
    ("tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx", "mainnet"),  # wrong network
    ("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", "testnet"),
    ("1BoatSLRHtKNngkdXEeobR76b53LETtpyT", "regtest"),
    ("BC1QW508D6QEJXTDG4Y5R3ZARVARY0C5XW7KV8F3T4", "mainnet"),  # must be lowercase
    ("bc1qb", "mainnet"),
    ("0x52908400098527886E0F7030069857D2E4169EE7", "mainnet"),
    ("bitcoin:1BoatSLRHtKNngkdXEeobR76b53LETtpyT", "mainnet"),
    ("1BoatSLRHtKNngkdXEeobR76b53LETtpyT", "liquid"),
    ("x" * 200, "mainnet"),
    (5, "mainnet"),
])
def test_bitcoin_address_sanity_rejects(address, network):
    assert "bitcoin" in problems(base(bitcoin={"address": address, "network": network}))


def test_bitcoin_must_be_an_object():
    assert "“bitcoin” must be an object" in problems(base(bitcoin="1BoatSLRHtKNngkdXEeobR76b53LETtpyT"))


@pytest.mark.parametrize("licence", ["CC-BY-4.0", "MIT", "GPL-3.0-or-later", "https://example.org/licence"])
def test_licence_accepted(licence):
    assert parse_manifest(base(licence=licence)).licence == licence


@pytest.mark.parametrize("licence", ["two words", "x" * 65, "ftp://example.org/l", "", 3, "<b>MIT</b>"])
def test_licence_rejected(licence):
    assert "licence" in problems(base(licence=licence))


@pytest.mark.parametrize("created", [-1, 0, 1.5, "1795596682", True, 99_999_999_999_999])
def test_created_must_be_integer_seconds(created):
    assert "created" in problems(base(created=created))


def test_floats_and_non_finite_numbers_rejected_in_json_text():
    assert "not valid JSON" in problems(b'{"schema_version": 1, "publisher": "x", "created": 1.0}')
    assert "not valid JSON" in problems(b'{"schema_version": 1, "publisher": "x", "created": NaN}')
    assert "not valid JSON" in problems(b'{"schema_version": 1, "publisher": "x", "created": 1e3}')


def test_duplicate_members_and_bad_encodings_rejected():
    assert "duplicate" in problems(b'{"schema_version": 1, "publisher": "a", "publisher": "b"}')
    assert "not valid JSON" in problems(b'{"schema_version": 1, "publisher": "\xff"}')
    assert "not valid JSON" in problems(b"not json")
    assert "JSON object" in problems(b"[1, 2]")
    assert "JSON object" in problems(None)


def test_oversize_manifest_rejected_before_parsing():
    raw = json.dumps(base(description="d" * 2000)).encode() + b" " * m.MAX_MANIFEST_BYTES
    assert "16 KiB" in problems(raw)
    assert "16 KiB" in problems(base(**{f"pad{i}": "x" * 1000 for i in range(20)}))
    assert m.MAX_MANIFEST_BYTES == 16 * 1024


def test_every_problem_is_reported_together():
    text = problems(base(publisher="", website="ftp://x", licence="a b", created=-5, extra=1))
    for needle in ("publisher", "website", "licence", "created", "extra"):
        assert needle in text


def test_canonical_form_is_stable_and_minimal():
    a = parse_manifest({"publisher": "Ünïcode Press", "schema_version": 1, "created": 5,
                        "torrent": {"v2": V2, "v1": V1}, "licence": "MIT",
                        "description": 'He said "hi"\\ok\nbye'})
    b = parse_manifest(json.dumps(a.to_dict(), indent=4, sort_keys=False))
    assert a == b and a.canonical_bytes() == b.canonical_bytes()
    raw = a.canonical_bytes()
    assert raw == (
        '{"created":5,"description":"He said \\"hi\\"\\\\ok\\nbye","licence":"MIT",'
        '"publisher":"Ünïcode Press","schema_version":1,'
        f'"torrent":{{"v1":"{V1}","v2":"{V2}"}}}}'
    ).encode("utf-8")
    assert parse_manifest(raw).canonical_bytes() == raw  # canonical form is a fixed point


def test_build_manifest_normalises_user_input():
    manifest = build_manifest(publisher="  Cafe\u0301 Press ", description="a\r\nb", website=" https://example.org ",
                              lightning_address="Tips@Example.ORG", licence="MIT", created=10,
                              bitcoin_address="bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4")
    assert manifest.publisher == "Caf\u00e9 Press"
    assert manifest.description == "a\nb"
    assert manifest.website == "https://example.org"
    assert manifest.lightning_address == "tips@example.org"
    assert manifest.bitcoin_network == "mainnet"
    with pytest.raises(ManifestError):
        build_manifest(publisher="")
    with pytest.raises(ManifestError) as err:
        build_manifest(publisher="x", lightning_address="LNBC1PVJLUEZSP5ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYG3ZYGS")
    assert "invoice" in str(err.value).lower()


def test_embedded_form_omits_identity_and_identity_rebinding_drops_signature():
    full = build_manifest(publisher="P", created=5, identity=TorrentIdentity(V1, V2))
    inner = full.embedded_form()
    assert inner.identity is None and "torrent" not in inner.to_dict()
    assert inner.with_identity(TorrentIdentity(V1, None)).identity.v1 == V1
    assert len(inner.canonical_bytes()) <= 16 * 1024


def test_manifest_module_does_not_depend_on_payments():
    import ast
    import inspect

    import aureom_torrent.publishing as pkg

    for path in Path(inspect.getfile(pkg)).parent.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [("." * node.level) + (node.module or "")]
            assert not any("payments" in n for n in names), f"{path.name} imports payments"
