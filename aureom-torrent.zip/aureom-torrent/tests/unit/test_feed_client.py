"""Feed address validation, back-off schedule and Retry-After handling."""

from __future__ import annotations

import email.utils

import pytest

from aureom_torrent.feeds.client import (MAX_BACKOFF_S, FeedClient, FeedFetchError, backoff_seconds,
                                         parse_retry_after, validate_feed_url)
from aureom_torrent.feeds.models import FeedError
from aureom_torrent.net.http import BlockedDestination, FetchTimeout, TooManyRedirects
from tests.fakes.feeds import FakeFetcher, FakeResult

URL = "https://feeds.example.org/feed.xml"


def test_backoff_schedule_is_deterministic_and_capped():
    assert [backoff_seconds(n) for n in range(1, 8)] == [300, 600, 1200, 2400, 4800, 9600, 19200]
    assert backoff_seconds(10) == MAX_BACKOFF_S == backoff_seconds(500)
    assert backoff_seconds(0) == 300  # defensive
    # Retry-After can only lengthen the delay, and is bounded
    assert backoff_seconds(1, retry_after=30) == 300
    assert backoff_seconds(1, retry_after=3600) == 3600
    assert backoff_seconds(1, retry_after=10 ** 9) == MAX_BACKOFF_S


def test_parse_retry_after():
    now = 1_800_000_000
    assert parse_retry_after("120", now) == 120
    assert parse_retry_after(email.utils.formatdate(now + 90, usegmt=True), now) == 90
    assert parse_retry_after(email.utils.formatdate(now - 90, usegmt=True), now) == 0
    assert parse_retry_after("999999999", now) == 24 * 3600
    assert parse_retry_after("soon", now) is None and parse_retry_after(None, now) is None


@pytest.mark.parametrize("raw, expected", [
    (" https://Example.org/feed.xml ", "https://Example.org/feed.xml"),
    ("feed://example.org/rss", "http://example.org/rss"),
    ("feed:https://example.org/rss", "https://example.org/rss"),
])
def test_validate_feed_url_accepts(raw, expected):
    assert validate_feed_url(raw) == expected


@pytest.mark.parametrize("raw", ["", "ftp://example.org/feed", "javascript:alert(1)", "file:///etc/passwd",
                                 "https://user:pw@example.org/feed", "https:///nohost", "https://ex.org/\x00",
                                 "https://example.org:notaport/feed", "https://example.org/" + "a" * 3000, None])
def test_validate_feed_url_rejects(raw):
    with pytest.raises(FeedError):
        validate_feed_url(raw)


def test_conditional_headers_and_validators():
    fetcher = FakeFetcher()
    fetcher.set(URL, FakeResult(body=b"<rss/>", headers={"ETag": '"v1"', "Last-Modified": "Mon, 23 Nov 2026 09:30:00 GMT"}))
    client = FeedClient(fetcher)
    first = client.fetch_feed(URL)
    assert (first.etag, first.last_modified) == ('"v1"', "Mon, 23 Nov 2026 09:30:00 GMT")
    assert "If-None-Match" not in fetcher.requests[0].headers
    fetcher.set(URL, FakeResult(status=304))
    second = client.fetch_feed(URL, etag=first.etag, last_modified=first.last_modified)
    assert second.not_modified and second.etag == '"v1"'
    sent = fetcher.requests[1].headers
    assert sent["If-None-Match"] == '"v1"' and sent["If-Modified-Since"] == "Mon, 23 Nov 2026 09:30:00 GMT"


def test_oversized_validators_are_not_stored():
    fetcher = FakeFetcher()
    fetcher.set(URL, FakeResult(body=b"x", headers={"ETag": "e" * 5000}))
    assert FeedClient(fetcher).fetch_feed(URL).etag == ""


@pytest.mark.parametrize("status, text", [(404, "not found"), (410, "not found"), (403, "refused"),
                                           (500, "HTTP 500"), (200, "empty")])
def test_http_errors(status, text):
    fetcher = FakeFetcher()
    fetcher.set(URL, FakeResult(status=status, body=b""))
    with pytest.raises(FeedFetchError, match=text):
        FeedClient(fetcher).fetch_feed(URL)


def test_retry_after_is_reported():
    fetcher = FakeFetcher()
    fetcher.set(URL, FakeResult(status=429, headers={"Retry-After": "1800"}))
    with pytest.raises(FeedFetchError) as info:
        FeedClient(fetcher).fetch_feed(URL, now=1_800_000_000)
    assert info.value.status == 429 and info.value.retry_after == 1800


@pytest.mark.parametrize("error", [FetchTimeout("Timed out contacting https://feeds.example.org/feed.xml."),
                                   BlockedDestination("blocked"), TooManyRedirects("Too many redirects (limit 5).")])
def test_transport_errors_become_feed_errors(error):
    fetcher = FakeFetcher()
    fetcher.set(URL, error)
    with pytest.raises(FeedFetchError, match=str(error)[:10]):
        FeedClient(fetcher).fetch_feed(URL)


def test_permanent_redirect_is_only_reported_when_every_hop_is_permanent():
    fetcher = FakeFetcher()
    new = "https://feeds.example.org/new.xml"
    fetcher.set(URL, FakeResult(body=b"<rss/>", url=new, redirects=(URL,), redirect_statuses=(301,)))
    assert FeedClient(fetcher).fetch_feed(URL).permanent_url == new
    fetcher.set(URL, FakeResult(body=b"<rss/>", url=new, redirects=(URL, "https://x/"), redirect_statuses=(301, 302)))
    assert FeedClient(fetcher).fetch_feed(URL).permanent_url == ""
    fetcher.set(URL, FakeResult(body=b"<rss/>", url=new, redirects=(URL,)))  # statuses unknown
    assert FeedClient(fetcher).fetch_feed(URL).permanent_url == ""


def test_fetch_torrent():
    fetcher = FakeFetcher()
    turl = "https://feeds.example.org/a.torrent"
    fetcher.set(turl, FakeResult(body=b"data"))
    client = FeedClient(fetcher)
    assert client.fetch_torrent(turl) == b"data"
    fetcher.set(turl, FakeResult(status=404))
    with pytest.raises(FeedFetchError, match="HTTP 404"):
        client.fetch_torrent(turl)
