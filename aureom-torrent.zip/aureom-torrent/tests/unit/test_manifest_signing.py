"""Manifest signatures: validity is kept separate from trust."""

from __future__ import annotations

import dataclasses

import pytest

from aureom_torrent.domain.identity import TorrentIdentity
from aureom_torrent.publishing.manifests import (SignatureStatus, TrustLevel, assess_trust, build_manifest,
                                                 ensure_signing_key, generate_signing_key, key_fingerprint,
                                                 parse_manifest, public_key_of, sign_manifest,
                                                 verify_signature)
from aureom_torrent.settings.secrets import SECRET_MANIFEST_SIGNING_KEY, MemorySecretStore

V1 = "12" * 20


@pytest.fixture()
def manifest():
    return build_manifest(publisher="Example Press", website="https://example.org", created=1795596682,
                          lightning_address="tips@example.org", identity=TorrentIdentity(V1, None))


def test_unsigned_manifest_is_self_asserted(manifest):
    assert verify_signature(manifest) is SignatureStatus.UNSIGNED
    trust = assess_trust(manifest, pinned_keys=["ab" * 32])
    assert trust.level is TrustLevel.SELF_ASSERTED
    assert trust.label == "self-asserted"
    assert not trust.verified and trust.public_key == ""


def test_sign_verify_round_trip_through_json(manifest):
    key = generate_signing_key()
    signed = sign_manifest(manifest, key)
    assert signed.signature.alg == "ed25519"
    assert signed.signature.public_key == public_key_of(key)
    assert verify_signature(signed) is SignatureStatus.VALID
    reparsed = parse_manifest(signed.canonical_bytes())
    assert reparsed == signed
    assert verify_signature(reparsed) is SignatureStatus.VALID
    # the signature covers the canonical bytes without the signature member
    assert b'"signature"' not in signed.signing_bytes()
    assert signed.signing_bytes() == manifest.canonical_bytes()


def test_valid_signature_by_unpinned_key_is_still_self_asserted(manifest):
    signed = sign_manifest(manifest, generate_signing_key())
    trust = assess_trust(signed, pinned_keys=[])
    assert trust.signature_status is SignatureStatus.VALID
    assert trust.level is TrustLevel.SIGNED_UNRECOGNISED
    assert trust.label == "signed by unrecognised key (self-asserted)"
    assert not trust.verified
    assert "does not" in trust.explanation
    assert trust.fingerprint == key_fingerprint(signed.signature.public_key)


def test_valid_signature_by_pinned_key(manifest):
    key = generate_signing_key()
    signed = sign_manifest(manifest, key)
    trust = assess_trust(signed, pinned_keys=[public_key_of(key).upper()])
    assert trust.level is TrustLevel.PINNED_KEY
    assert trust.label == "verified against a key you pinned"
    assert trust.verified


@pytest.mark.parametrize("change", [
    {"publisher": "Evil Press"},
    {"lightning_address": "thief@example.net"},
    {"website": "https://example.net"},
    {"identity": TorrentIdentity("34" * 20, None)},
    {"created": 1},
])
def test_tampering_invalidates_the_signature(manifest, change):
    key = generate_signing_key()
    signed = sign_manifest(manifest, key)
    tampered = dataclasses.replace(signed, **change)
    assert verify_signature(tampered) is SignatureStatus.INVALID
    trust = assess_trust(tampered, pinned_keys=[public_key_of(key)])  # pinning never rescues a bad signature
    assert trust.level is TrustLevel.INVALID_SIGNATURE
    assert not trust.verified


def test_signature_from_another_key_is_invalid(manifest):
    signed = sign_manifest(manifest, generate_signing_key())
    other = public_key_of(generate_signing_key())
    swapped = dataclasses.replace(signed, signature=dataclasses.replace(signed.signature, public_key=other))
    assert verify_signature(swapped) is SignatureStatus.INVALID


def test_embedded_and_full_forms_need_their_own_signatures(manifest):
    key = generate_signing_key()
    signed_full = sign_manifest(manifest, key)
    inner = signed_full.embedded_form()
    assert inner.signature is None  # the old signature would not cover the identity-less form
    signed_inner = sign_manifest(inner, key)
    assert verify_signature(signed_inner) is SignatureStatus.VALID
    assert signed_inner.signature.value != signed_full.signature.value


def test_malformed_public_key_is_invalid_not_an_exception(manifest):
    signed = sign_manifest(manifest, generate_signing_key())
    # 32 bytes that are not a valid curve point encoding still must not raise
    broken = dataclasses.replace(signed, signature=dataclasses.replace(signed.signature, public_key="ff" * 32))
    assert verify_signature(broken) in (SignatureStatus.INVALID,)


def test_signing_key_lives_only_in_the_secret_store():
    secrets = MemorySecretStore()
    assert ensure_signing_key(secrets, create=False) is None
    private, public, created = ensure_signing_key(secrets, create=True)
    assert created and secrets.get(SECRET_MANIFEST_SIGNING_KEY) == private
    again = ensure_signing_key(secrets, create=True)
    assert again == (private, public, False)
    assert len(private) == 64 and len(public) == 64 and private != public


def test_fingerprint_format():
    fp = key_fingerprint("00" * 32)
    assert len(fp) == 19 and fp.count(" ") == 3
