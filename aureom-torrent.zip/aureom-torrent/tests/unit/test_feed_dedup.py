"""De-duplication keys."""

from __future__ import annotations

from aureom_torrent.feeds.dedup import canonical_url, entry_keys, identity_keys, shared_links
from aureom_torrent.feeds.models import ParsedEntry


def kinds(keys):
    return sorted(k.kind for k in keys)


def test_canonical_url_normalises_for_comparison():
    assert canonical_url("HTTPS://Example.ORG:443/a/b/?utm_source=x&id=7#frag") == "https://example.org/a/b?id=7"
    assert canonical_url("http://example.org") == "http://example.org/"
    assert canonical_url("http://example.org:8080/x") == "http://example.org:8080/x"
    assert canonical_url("https://example.org/a?b=1") != canonical_url("https://example.org/a?b=2")


def test_keys_for_a_complete_entry():
    e = ParsedEntry(guid="g1", link="https://ex.org/a", title="A", torrent_url="https://ex.org/a.torrent",
                    v1="ab" * 20, v2="cd" * 32)
    keys = entry_keys(7, e)
    assert kinds(keys) == ["e", "g", "i1", "i2", "l"]
    scoped = {k.kind: k.feed_scoped for k in keys}
    assert scoped == {"g": True, "l": True, "e": False, "i1": False, "i2": False}
    # feed-scoped keys differ between feeds, global ones do not
    other = {k.kind: k.key for k in entry_keys(8, e)}
    mine = {k.kind: k.key for k in keys}
    assert mine["g"] != other["g"] and mine["l"] != other["l"]
    assert mine["e"] == other["e"] and mine["i1"] == other["i1"] and mine["i2"] == other["i2"]


def test_missing_guid_falls_back_to_link_then_title_hash():
    with_link = ParsedEntry(link="https://ex.org/a", title="A")
    assert kinds(entry_keys(1, with_link)) == ["l"]
    bare = ParsedEntry(title="A", torrent_url="https://ex.org/a.torrent")
    assert kinds(entry_keys(1, bare)) == ["e", "t"]
    # the same title with a different download is a different entry
    other = ParsedEntry(title="A", torrent_url="https://ex.org/b.torrent")
    t1 = next(k.key for k in entry_keys(1, bare) if k.kind == "t")
    t2 = next(k.key for k in entry_keys(1, other) if k.kind == "t")
    assert t1 != t2


def test_changed_guid_still_shares_link_and_identity_keys():
    before = ParsedEntry(guid="old", link="https://ex.org/a?utm_campaign=x", title="A", v1="ab" * 20)
    after = ParsedEntry(guid="new", link="https://ex.org/a", title="A (updated)", v1="AB" * 20)
    shared = {k.key for k in entry_keys(3, before)} & {k.key for k in entry_keys(3, after)}
    assert len(shared) == 2  # link + v1 identity


def test_non_identifying_shared_links_are_detected():
    entries = [ParsedEntry(link="https://ex.org/downloads", title="A"),
               ParsedEntry(link="https://ex.org/downloads/", title="B"),
               ParsedEntry(link="https://ex.org/c", title="C")]
    assert shared_links(entries) == {"https://ex.org/downloads"}
    keys = entry_keys(1, entries[0], use_link=False)
    assert kinds(keys) == ["t"]


def test_identity_keys():
    assert [k.key for k in identity_keys("AB" * 20, None)] == ["i1:*:" + "ab" * 20]
    assert identity_keys(None, None) == []
