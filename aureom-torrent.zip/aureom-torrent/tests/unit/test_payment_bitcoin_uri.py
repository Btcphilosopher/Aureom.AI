"""Bitcoin address validation and BIP21 building/parsing."""

import pytest

from aureom_torrent.payments.bitcoin_uri import AddressError, build_bip21, parse_bip21, validate_address

# Valid standard addresses (BIP173 / BIP350 test vectors and well-known examples).
VALID = [
    ("BC1QW508D6QEJXTDG4Y5R3ZARVARY0C5XW7KV8F3T4", "mainnet", "p2wpkh"),
    ("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", "mainnet", "p2wpkh"),
    ("tb1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3q0sl5k7", "testnet", "p2wsh"),
    ("tb1qqqqqp399et2xygdj5xreqhjjvcmzhxw4aywxecjdzew6hylgvsesrxh6hy", "signet", "p2wsh"),
    ("bc1p0xlxvlhemja6c4dqv22uapctqupfhlxm9h8z3k2e72q4k9hcz7vqzk5jj0", "mainnet", "p2tr"),
    ("tb1pqqqqp399et2xygdj5xreqhjjvcmzhxw4aywxecjdzew6hylgvsesf3hn0c", "testnet", "p2tr"),
    ("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2", "mainnet", "p2pkh"),
    ("3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy", "mainnet", "p2sh"),
    ("mipcBbFg9gMiCh81Kj8tqqdgoZub1ZJRfn", "testnet", "p2pkh"),
    ("mipcBbFg9gMiCh81Kj8tqqdgoZub1ZJRfn", "regtest", "p2pkh"),
    ("2MzQwSSnBHWHqSAqtTVQ6v47XtaisrJa1Vc", "testnet", "p2sh"),
    ("bcrt1qw508d6qejxtdg4y5r3zarvary0c5xw7kygt080", "regtest", "p2wpkh"),
]

# Invalid: BIP173/BIP350 invalid vectors, bad checksums, wrong encodings, non-standard programs.
INVALID = [
    "tc1qw508d6qejxtdg4y5r3zarvary0c5xw7kg3g4ty",  # invalid human-readable part
    "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t5",  # invalid checksum
    "BC13W508D6QEJXTDG4Y5R3ZARVARY0C5XW7KN40WF2",  # invalid witness version
    "bc1rw5uspcuh",  # invalid program length
    "bc10w508d6qejxtdg4y5r3zarvary0c5xw7kw508d6qejxtdg4y5r3zarvary0c5xw7kw5rljs90",  # program too long
    "BC1QR508D6QEJXTDG4Y5R3ZARVARYV98GJ9P",  # invalid program length for v0
    "tb1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3q0sL5k7",  # mixed case
    "bc1zw508d6qejxtdg4y5r3zarvaryvqyzf3du",  # zero padding of more than 4 bits
    "bc1gmk9yu",  # empty data section
    "bc1p0xlxvlhemja6c4dqv22uapctqupfhlxm9h8z3k2e72q4k9hcz7vq5zuyut",  # v1 with bech32 (not bech32m) checksum
    "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kemeawh",  # v0 with bech32m checksum
    "bc1pw508d6qejxtdg4y5r3zarvary0c5xw7kw508d6qejxtdg4y5r3zarvary0c5xw7kt5nd6y",  # v1, 40-byte program
    "BC1SW50QGDZ25J",  # v16: valid encoding but not a standard output type
    "1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN3",  # base58 bad checksum
    "1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN",  # truncated
    "LVg2kJoFNg45Nbpy53h7Fe1wKyeXVRhMH9",  # litecoin version byte
    "0x52908400098527886E0F7030069857D2E4169EE7",  # not bitcoin
    "", "bc1", "hello", "bc1q", "💰",
]


@pytest.mark.parametrize("address,network,kind", VALID)
def test_valid_addresses(address, network, kind):
    info = validate_address(address, network)
    assert info.kind == kind and network in info.networks
    assert validate_address(address).kind == kind  # network detection without a constraint


@pytest.mark.parametrize("address", INVALID)
def test_invalid_addresses(address):
    with pytest.raises(AddressError):
        validate_address(address)


@pytest.mark.parametrize("value", [None, 12, b"bc1q"])
def test_non_text_address(value):
    with pytest.raises(AddressError):
        validate_address(value)


@pytest.mark.parametrize("address,network", [
    ("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", "testnet"),
    ("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4", "regtest"),
    ("tb1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3q0sl5k7", "mainnet"),
    ("tb1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3q0sl5k7", "regtest"),
    ("bcrt1qw508d6qejxtdg4y5r3zarvary0c5xw7kygt080", "mainnet"),
    ("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2", "testnet"),
    ("mipcBbFg9gMiCh81Kj8tqqdgoZub1ZJRfn", "mainnet"),
])
def test_wrong_network_rejected(address, network):
    with pytest.raises(AddressError) as err:
        validate_address(address, network)
    assert network in str(err.value)


def test_unknown_network_name():
    with pytest.raises(AddressError):
        validate_address("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2", "litecoin")


ADDR = "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4"


def test_build_bip21_exact_amounts():
    assert build_bip21(ADDR, network="mainnet") == f"bitcoin:{ADDR}"
    assert build_bip21(ADDR, network="mainnet", amount_sat=1) == f"bitcoin:{ADDR}?amount=0.00000001"
    assert build_bip21(ADDR, network="mainnet", amount_sat=30_000_000) == f"bitcoin:{ADDR}?amount=0.3"
    assert build_bip21(ADDR, network="mainnet", amount_sat=2_100_000_000_000_000) == f"bitcoin:{ADDR}?amount=21000000"
    uri = build_bip21(ADDR.upper(), network="mainnet", amount_sat=12_345, label="Ana & Co", message="Thanks for #1?")
    assert uri == f"bitcoin:{ADDR}?amount=0.00012345&label=Ana%20%26%20Co&message=Thanks%20for%20%231%3F"


@pytest.mark.parametrize("amount", [0, -5, 2_100_000_000_000_001, 1.5, "100", True])
def test_build_bip21_rejects_bad_amounts(amount):
    with pytest.raises((AddressError, ValueError)):
        build_bip21(ADDR, network="mainnet", amount_sat=amount)


def test_build_requires_matching_network():
    with pytest.raises(AddressError):
        build_bip21(ADDR, network="testnet", amount_sat=1000)


def test_parse_round_trip():
    uri = build_bip21(ADDR, network="mainnet", amount_sat=12_345, label="Ana & Co", message="Thanks for #1?")
    req = parse_bip21(uri, network="mainnet")
    assert req.address.address == ADDR and req.amount_sat == 12_345
    assert req.label == "Ana & Co" and req.message == "Thanks for #1?"
    assert req.ignored == ()


def test_parse_variants():
    req = parse_bip21(f"BITCOIN:{ADDR.upper()}?amount=1.5&lightning=lnbc1xyz&foo=bar")
    assert req.amount_sat == 150_000_000 and req.ignored == ("lightning", "foo")
    assert parse_bip21(f"bitcoin:{ADDR}").amount_sat is None
    assert parse_bip21(f"bitcoin:{ADDR}?label=%E2%82%BF").label == "₿"


@pytest.mark.parametrize("uri", [
    f"bitcoin:{ADDR}?req-somethingnew=1",  # unknown required parameter: must be rejected (BIP21)
    f"bitcoin:{ADDR}?amount=0.000000001",
    f"bitcoin:{ADDR}?amount=1e-3",
    f"bitcoin:{ADDR}?amount=-1",
    f"bitcoin:{ADDR}?amount=0",
    f"bitcoin:{ADDR}?amount=",
    f"bitcoin:{ADDR}?amount",
    f"bitcoin:{ADDR}?amount=1&amount=2",
    f"bitcoin:{ADDR}?label=%ff",
    "bitcoin:?amount=1",
    "bitcoin:notanaddress",
    f"litecoin:{ADDR}",
    ADDR,
    "bitcoin:" + ADDR + "?message=" + "a" * 3000,
])
def test_parse_rejects(uri):
    with pytest.raises(AddressError):
        parse_bip21(uri)


def test_parse_checks_network():
    with pytest.raises(AddressError):
        parse_bip21(f"bitcoin:{ADDR}?amount=1", network="regtest")


def test_parse_sanitises_text_fields():
    req = parse_bip21(f"bitcoin:{ADDR}?label=a%0Ab%E2%80%AEc&message=" + "m" * 400)
    assert req.label == "a b c" and len(req.message) == 280
