"""LNURL-pay target resolution and parameter validation (no network)."""

import hashlib
import json

import bech32
import pytest

from aureom_torrent.net.http import HttpPolicy, HttpResult
from aureom_torrent.payments.lnurl import LnurlError, LnurlPayClient, resolve_target, tip_policy
from tests.fakes.payments import make_invoice

PUBLIC = HttpPolicy(allow_http=False, allow_loopback=False, allow_private=False, proxy_url="socks5://127.0.0.1:9")


class ScriptedFetcher:
    """Returns canned JSON per URL prefix and records what was requested."""

    def __init__(self, routes):
        self.routes = routes
        self.requested = []

    def fetch(self, url, *, method="GET", headers=None, body=None, policy=None):
        self.requested.append(url)
        for prefix, payload in self.routes.items():
            if url.startswith(prefix):
                status, data = payload if isinstance(payload, tuple) else (200, payload)
                raw = data if isinstance(data, bytes) else json.dumps(data).encode()
                return HttpResult(status=status, headers={}, body=raw, url=url)
        raise AssertionError(f"unexpected request {url}")


def lnurl_encode(url: str) -> str:
    return bech32.bech32_encode("lnurl", bech32.convertbits(url.encode(), 8, 5, True))


def test_resolve_lightning_address():
    assert resolve_target("Alice@Example.org") == "https://example.org/.well-known/lnurlp/alice"
    assert resolve_target("lightning:tips+dev@pay.example.org") == "https://pay.example.org/.well-known/lnurlp/tips+dev"
    assert resolve_target("a@127.0.0.1:8080", allow_http_loopback=True) == "http://127.0.0.1:8080/.well-known/lnurlp/a"
    assert resolve_target("a@127.0.0.1:8080") == "https://127.0.0.1:8080/.well-known/lnurlp/a"


def test_resolve_bech32_lnurl_and_https_url():
    url = "https://service.example/api/v1/lnurl/pay/abc"
    assert resolve_target(lnurl_encode(url)) == url
    assert resolve_target(lnurl_encode(url).upper()) == url
    assert resolve_target(url) == url


@pytest.mark.parametrize("text", [
    "", "alice", "alice@", "@example.org", "alice@exa mple.org", "alice@hidden.onion", "a/b@example.org",
    "http://example.org/.well-known/lnurlp/alice", "ftp://example.org/x", "lnurl1qqqqqqqqqq", None, 5,
    "x" * 3000,
])
def test_resolve_rejects(text):
    with pytest.raises(LnurlError):
        resolve_target(text)


def test_http_lnurl_rejected_even_inside_bech32():
    with pytest.raises(LnurlError):
        resolve_target(lnurl_encode("http://example.org/pay"))


def test_tip_policy_is_strict():
    base = HttpPolicy(allow_http=True, allow_loopback=True, allow_private=True, proxy_url="socks5://127.0.0.1:9050",
                      max_bytes=10**9)
    p = tip_policy(base)
    assert not p.allow_http and not p.allow_loopback and not p.allow_private
    assert p.proxy_url == "socks5://127.0.0.1:9050" and p.max_bytes == 64 * 1024


META = json.dumps([["text/plain", "Tips for the Open Archive"], ["image/png;base64", "AAAA"]])
PARAMS = {"tag": "payRequest", "callback": "https://example.org/cb?k=1", "minSendable": 1000,
          "maxSendable": 10_000_000, "metadata": META, "commentAllowed": 0}


def client(routes):
    fetcher = ScriptedFetcher(routes)
    return LnurlPayClient(fetcher, PUBLIC), fetcher


def test_fetch_params_and_request_invoice():
    pr, _ = make_invoice(amount_msat=21_000, description_hash=hashlib.sha256(META.encode()).hexdigest())
    c, fetcher = client({"https://example.org/.well-known": PARAMS, "https://example.org/cb": {"pr": pr.upper()}})
    params = c.fetch_params("alice@example.org")
    assert params.domain == "example.org" and params.description == "Tips for the Open Archive"
    assert (params.min_sendable_msat, params.max_sendable_msat) == (1000, 10_000_000)
    assert c.request_invoice(params, 21_000) == pr
    assert fetcher.requested[-1] == "https://example.org/cb?k=1&amount=21000"  # existing query preserved


@pytest.mark.parametrize("override", [
    {"tag": "withdrawRequest"}, {"callback": "http://example.org/cb"}, {"callback": 5}, {"metadata": 7},
    {"minSendable": 0}, {"minSendable": 5000, "maxSendable": 10}, {"minSendable": 1000.0}, {"maxSendable": "5000"},
    {"minSendable": True}, {"metadata": "x" * 20_000},
])
def test_bad_params_rejected(override):
    c, _ = client({"https://example.org/": {**PARAMS, **override}})
    with pytest.raises(LnurlError):
        c.fetch_params("alice@example.org")


@pytest.mark.parametrize("payload", [
    (500, {}), (200, b"not json"), (200, [1, 2]), (200, {"status": "ERROR", "reason": "no such user"}),
])
def test_bad_param_responses(payload):
    c, _ = client({"https://example.org/": payload})
    with pytest.raises(LnurlError):
        c.fetch_params("alice@example.org")


def test_amount_outside_service_limits_is_not_requested():
    c, fetcher = client({"https://example.org/.well-known": PARAMS})
    params = c.fetch_params("alice@example.org")
    for amount in (999, 10_000_001):
        with pytest.raises(LnurlError):
            c.request_invoice(params, amount)
    assert len(fetcher.requested) == 1  # the callback was never contacted


def test_invoice_must_match_amount_and_metadata():
    good_hash = hashlib.sha256(META.encode()).hexdigest()
    wrong_amount, _ = make_invoice(amount_msat=22_000, description_hash=good_hash)
    wrong_hash, _ = make_invoice(amount_msat=21_000, description_hash="00" * 32)
    plain_desc, _ = make_invoice(amount_msat=21_000, description="Tips for the Open Archive")
    no_amount, _ = make_invoice(amount_msat=None, description_hash=good_hash)
    for pr in (wrong_amount, wrong_hash, plain_desc, no_amount, "lnbcrt1garbage", None):
        c, _ = client({"https://example.org/.well-known": PARAMS, "https://example.org/cb": {"pr": pr}})
        params = c.fetch_params("alice@example.org")
        with pytest.raises(LnurlError):
            c.request_invoice(params, 21_000)


def test_private_destinations_blocked_by_policy():
    direct = HttpPolicy(allow_http=False, allow_loopback=False, allow_private=False)
    c = LnurlPayClient(ScriptedFetcher({}), direct)
    for target in ("alice@127.0.0.1", "alice@10.0.0.8", "alice@localhost", "https://192.168.1.4/pay"):
        with pytest.raises(LnurlError):
            c.fetch_params(target)
