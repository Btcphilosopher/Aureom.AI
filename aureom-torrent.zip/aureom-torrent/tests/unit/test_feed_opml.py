"""OPML import/export."""

from __future__ import annotations

import pytest

from aureom_torrent.feeds.models import Feed
from aureom_torrent.feeds.opml import MAX_OPML_BYTES, OpmlError, export_opml, parse_opml
from tests.fakes.feeds import FIXTURES


def test_import_fixture():
    outlines, invalid = parse_opml((FIXTURES / "subscriptions.opml").read_text())
    assert invalid == 1  # the ftp:// outline
    assert [(o.url, o.title, o.folder, o.category) for o in outlines] == [
        ("https://feeds.example.org/open-data.xml", "Aureom Open Data Releases", "Open Data", "Documents"),
        ("https://feeds.example.org/bus.xml", "Bus Timetables", "Open Data/Transport", ""),
        ("https://type.example.net/atom.xml", "Libre Typeface Builds", "", "Software"),
    ]


def test_round_trip_preserves_folders_and_categories():
    feeds = [
        Feed(id=1, url="https://a.example/feed.xml", title="Alpha & <Beta>", folder="News/Tech", category="Software"),
        Feed(id=2, url="https://b.example/rss?x=1&y=2", title="", folder=""),
        Feed(id=3, url="https://c.example/atom", title="Gamma", folder="News", site_url="https://c.example/"),
    ]
    text = export_opml(feeds)
    assert text.startswith('<?xml version="1.0" encoding="UTF-8"?>')
    outlines, invalid = parse_opml(text)
    assert invalid == 0
    got = {o.url: (o.title, o.folder, o.category) for o in outlines}
    assert got == {
        "https://a.example/feed.xml": ("Alpha & <Beta>", "News/Tech", "Software"),
        "https://b.example/rss?x=1&y=2": ("https://b.example/rss?x=1&y=2", "", ""),
        "https://c.example/atom": ("Gamma", "News", ""),
    }


def test_entity_expansion_and_external_entities_are_rejected():
    with pytest.raises(OpmlError, match="not allowed"):
        parse_opml((FIXTURES / "opml_bomb.opml").read_bytes())


@pytest.mark.parametrize("text, message", [
    ("", "empty"),
    ("<opml><body>", "well-formed"),
    ("<rss version='2.0'/>", "not an OPML"),
    ("<opml version='2.0'><head/></opml>", "no <body>"),
    ("x" * (MAX_OPML_BYTES + 1), "larger than"),
])
def test_unusable_documents(text, message):
    with pytest.raises(OpmlError, match=message):
        parse_opml(text)


def test_too_many_feeds_and_excessive_nesting():
    many = "".join(f'<outline xmlUrl="https://e.example/{i}.xml"/>' for i in range(2001))
    with pytest.raises(OpmlError, match="more than"):
        parse_opml(f"<opml><body>{many}</body></opml>")
    deep = "<outline text='f'>" * 30 + '<outline xmlUrl="https://e.example/deep.xml"/>' + "</outline>" * 30
    outlines, invalid = parse_opml(f"<opml><body>{deep}</body></opml>")
    assert outlines == [] and invalid == 1
