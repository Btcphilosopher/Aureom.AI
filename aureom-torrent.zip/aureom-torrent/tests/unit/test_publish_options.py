"""Wizard option validation, tracker parsing and safe .torrent output (no engine involved)."""

from __future__ import annotations

import os

import pytest

from aureom_torrent.publishing import creator as c
from aureom_torrent.publishing.adapters.base import UnsafeArtifactName, check_artifact_name
from aureom_torrent.publishing.adapters.https_upload import base_url_problems
from aureom_torrent.publishing.models import JobState, PublishDraft, PublisherInfo, PublishOperationResult
from tests.fakes.publishing import TREE_FILES, make_draft, make_tree


@pytest.fixture()
def tree(tmp_path):
    return make_tree(tmp_path)


def errors(draft, **kw) -> str:
    return " | ".join(c.check_options(draft, **kw).errors)


def warnings(draft, **kw) -> str:
    return " | ".join(c.check_options(draft, **kw).warnings)


def test_tracker_text_tiers_and_duplicates():
    text = ("udp://a.example:6969/announce\nhttps://b.example/announce\r\n\r\n"
            "http://c.example/announce\n\n\nudp://a.example:6969/announce\n")
    tiers, problems = c.parse_tracker_text(text)
    assert problems == []
    assert tiers == [["udp://a.example:6969/announce", "https://b.example/announce"], ["http://c.example/announce"]]


@pytest.mark.parametrize("bad", ["ws://tracker.example/announce", "tracker.example:6969", "udp://", "https://x y/",
                                 "magnet:?xt=urn:btih:abc", "udp://tracker.example:99999999/announce"])
def test_bad_tracker_urls_reported_without_leaking_paths(bad):
    tiers, problems = c.parse_tracker_text("https://ok.example/announce/SECRETPASSKEY\n" + bad)
    assert tiers == [["https://ok.example/announce/SECRETPASSKEY"]]
    assert len(problems) == 1 and "SECRETPASSKEY" not in problems[0]


def test_tracker_and_web_seed_limits():
    many = "\n".join(f"https://t{i}.example/announce" for i in range(c.MAX_TRACKERS + 1))
    assert any("Too many trackers" in p for p in c.parse_tracker_text(many)[1])
    tiers = [[f"https://t{i}.example/a"] for i in range(c.MAX_TIERS + 1)]
    assert any("tiers" in p for p in c.normalise_tiers(tiers)[1])
    seeds = [f"https://s{i}.example/files/" for i in range(c.MAX_WEB_SEEDS + 1)]
    assert any("Too many web seeds" in p for p in c.web_seed_problems(seeds)[1])
    clean, problems = c.web_seed_problems(["https://s.example/f/", "ftp://s.example/f/", "udp://s.example/f"])
    assert clean == ["https://s.example/f/"] and len(problems) == 2 and "BEP 19" in problems[0]


def test_valid_draft_passes(tree, tmp_path):
    draft = make_draft(tree, tmp_path, trackers_text="udp://tracker.example:6969/announce")
    check = c.check_options(draft, total_size=180_000)
    assert check.ok, check.errors
    assert check.tiers == (("udp://tracker.example:6969/announce",),)
    assert check.piece_length == 16 * 1024 and check.estimated_pieces == 11


@pytest.mark.parametrize("fmt,ok", [("v1", True), ("v2", True), ("hybrid", True), ("v3", False), ("", False)])
def test_format_choice(tree, tmp_path, fmt, ok):
    assert ("torrent format" not in errors(make_draft(tree, tmp_path, format=fmt))) is ok


@pytest.mark.parametrize("value,ok", [(0, True), (16 * 1024, True), (64 * 1024 * 1024, True), (8 * 1024, False),
                                      (128 * 1024 * 1024, False), (100_000, False), (-1, False), (True, False)])
def test_piece_length_choice(tree, tmp_path, value, ok):
    assert ("piece size" not in errors(make_draft(tree, tmp_path, piece_length=value))) is ok


def test_piece_length_choices_cover_the_supported_range():
    choices = c.piece_length_choices()
    assert choices[0] == ("Automatic", 0)
    assert choices[1] == ("16 KiB", 16 * 1024) and choices[-1] == ("64 MiB", 64 * 1024 * 1024)
    assert all(c.valid_piece_length(v) for _, v in choices)


def test_piece_count_warnings(tree, tmp_path):
    small = make_draft(tree, tmp_path, piece_length=16 * 1024)
    assert "pieces" in warnings(small, total_size=16 * 1024 * 200_000)
    big = make_draft(tree, tmp_path, piece_length=4 * 1024 * 1024)
    assert "single piece" in warnings(big, total_size=180_000)
    assert "empty" in errors(make_draft(tree, tmp_path), total_size=0)


def test_private_and_trackerless_warnings(tree, tmp_path):
    private = make_draft(tree, tmp_path, private=True)
    text = warnings(private)
    assert "disables DHT, peer exchange and local peer discovery" in text
    assert "cannot find any peers" in text
    with_tracker = make_draft(tree, tmp_path, private=True, trackers_text="https://t.example/announce")
    assert "cannot find any peers" not in warnings(with_tracker)
    assert "No trackers" in warnings(make_draft(tree, tmp_path))
    assert "v1" in warnings(make_draft(tree, tmp_path, format="v1"))


def test_source_and_file_list_problems(tree, tmp_path):
    assert "Select a file or folder" in errors(make_draft("", tmp_path))
    assert "no longer exists" in errors(make_draft(str(tmp_path / "gone"), tmp_path))
    assert "No files are selected" in errors(make_draft(tree, tmp_path, included_files=[]))
    assert "duplicates" in errors(make_draft(tree, tmp_path, included_files=["data.bin", "data.bin"]))
    for bad in ("../outside.txt", "/etc/passwd", "a/../../b", "nul\x00byte"):
        assert "unsafe" in errors(make_draft(tree, tmp_path, included_files=[bad]))
    link = tmp_path / "link"
    os.symlink(tree, link)
    assert "symbolic link" in errors(make_draft(str(link), tmp_path))


def test_single_file_rules(tree, tmp_path):
    single = os.path.join(tree, "data.bin")
    ok = make_draft(single, tmp_path, included_files=["data.bin"])
    assert c.check_options(ok).ok
    assert "exactly the selected file" in errors(make_draft(single, tmp_path, included_files=["other.bin"]))
    assert "takes its name from the file" in errors(make_draft(single, tmp_path, included_files=["data.bin"],
                                                                name="renamed.bin"))


def test_name_rules(tree, tmp_path):
    assert "plain name" in errors(make_draft(tree, tmp_path, name="a/b"))
    assert "plain name" in errors(make_draft(tree, tmp_path, name=".."))
    assert c.check_options(make_draft(tree, tmp_path, name="Renamed Pack")).ok
    assert "keep the folder's name" in errors(make_draft(tree, tmp_path, name="Renamed Pack", start_seeding=True))


def test_output_path_rules(tree, tmp_path):
    assert "where to save" in errors(make_draft(tree, tmp_path, output_torrent_path=""))
    assert "where to save" in errors(make_draft(tree, tmp_path, output_torrent_path="relative.torrent"))
    assert "must end with .torrent" in errors(make_draft(tree, tmp_path, output_torrent_path=str(tmp_path / "x.txt")))
    existing = tmp_path / "exists.torrent"
    existing.write_bytes(b"old")
    assert "already exists" in errors(make_draft(tree, tmp_path, output_torrent_path=str(existing)))
    assert c.check_options(make_draft(tree, tmp_path, output_torrent_path=str(existing), overwrite=True)).ok
    single = os.path.join(tree, "data.bin")
    assert "cannot replace" in errors(make_draft(single, tmp_path, included_files=["data.bin"],
                                                 output_torrent_path=single, overwrite=True))


def test_torrent_named_file_inside_source_cannot_be_overwritten(tmp_path):
    root = tmp_path / "pack"
    root.mkdir()
    (root / "inner.torrent").write_bytes(b"x" * 100)
    draft = PublishDraft(source_path=str(root), included_files=["inner.torrent"],
                         output_torrent_path=str(root / "inner.torrent"), overwrite=True, start_seeding=False)
    assert "overwrite one of the files being published" in errors(draft)


def test_publisher_details_validated_through_the_manifest_rules(tree, tmp_path):
    good = PublisherInfo(name="Example Press", website="https://example.org", lightning_address="tips@example.org")
    check = c.check_options(make_draft(tree, tmp_path, publisher=good))
    assert check.ok and any("self-asserted" in w for w in check.warnings)
    bad = PublisherInfo(name="Example", website="ftp://example.org",
                        lightning_address="lnbc1pvjluezsp5zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3zygs")
    text = errors(make_draft(tree, tmp_path, publisher=bad))
    assert "Publisher details" in text and "website" in text and "invoice" in text.lower()
    nameless = PublisherInfo(website="https://example.org")
    assert "publisher name" in errors(make_draft(tree, tmp_path, publisher=nameless))
    assert "no publisher details to sign" in errors(make_draft(tree, tmp_path, sign_manifest=True))
    unembedded = make_draft(tree, tmp_path, publisher=good, embed_manifest=False)
    assert "not be stored in the torrent" in warnings(unembedded)


def test_seeding_requires_an_engine(tree, tmp_path):
    draft = make_draft(tree, tmp_path, start_seeding=True)
    assert c.check_options(draft, can_seed=True).ok
    assert "engine is not available" in errors(draft, can_seed=False)


def test_comment_limit(tree, tmp_path):
    assert "comment" in errors(make_draft(tree, tmp_path, comment="x" * 2000))
    assert "comment" in errors(make_draft(tree, tmp_path, comment="bell\x07"))


def test_write_torrent_file_never_overwrites_silently(tmp_path):
    target = tmp_path / "sub" / "a.torrent"
    c.write_torrent_file(str(target), b"first", overwrite=False)
    assert target.read_bytes() == b"first"
    with pytest.raises(FileExistsError):
        c.write_torrent_file(str(target), b"second", overwrite=False)
    assert target.read_bytes() == b"first"
    assert c.leftover_temp_files(str(target)) == []  # the temporary file was cleaned up
    c.write_torrent_file(str(target), b"third", overwrite=True)
    assert target.read_bytes() == b"third"
    assert sorted(os.listdir(target.parent)) == ["a.torrent"]


def test_leftover_temp_files_only_matches_this_torrent(tmp_path):
    target = tmp_path / "we[i]rd name.torrent"
    mine = tmp_path / "we[i]rd name.torrent.abc123.tmp"
    other = tmp_path / "other.torrent.abc123.tmp"
    mine.write_bytes(b"partial")
    other.write_bytes(b"partial")
    assert c.leftover_temp_files(str(target)) == [str(mine)]
    assert c.leftover_temp_files("") == []


def test_suggested_output_path_is_beside_the_source(tree):
    assert c.suggest_torrent_path(tree) == tree + ".torrent"
    assert c.suggest_torrent_path(os.path.join(tree, "data.bin")) == os.path.join(tree, "data.bin.torrent")


@pytest.mark.parametrize("name", ["a.torrent", "Open-Data_1.0.qr.png", "x"])
def test_artifact_names_accepted(name):
    assert check_artifact_name(name) == name


@pytest.mark.parametrize("name", ["", "../a", "a/b", "a\\b", ".hidden", "a..b", "trailing.", "sp ace", "x" * 200,
                                  "nul\x00", None])
def test_artifact_names_rejected(name):
    with pytest.raises(UnsafeArtifactName):
        check_artifact_name(name)


def test_upload_base_url_rules():
    assert base_url_problems("https://example.org/files") == []
    assert base_url_problems("http://example.org/files")
    assert base_url_problems("http://example.org/files", allow_http=True) == []
    assert any("query" in p for p in base_url_problems("https://example.org/f?X-Amz-Signature=abc"))
    assert any("user name" in p for p in base_url_problems("https://user:pw@example.org/f"))
    assert base_url_problems("") and base_url_problems(None) and base_url_problems("https:///x")


def test_models_round_trip_and_labels():
    op = PublishOperationResult("publish:page", "local folder /x", True, "ok", 5)
    assert PublishOperationResult.from_dict(op.to_dict()) == op
    assert JobState.INTERRUPTED.finished and not JobState.HASHING.finished
    assert all(s.label for s in JobState)
    assert PublisherInfo().is_empty() and not PublisherInfo(name="x").is_empty()
    assert TREE_FILES == sorted(TREE_FILES)
