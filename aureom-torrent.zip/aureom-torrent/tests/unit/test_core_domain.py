"""Unit tests: identity, magnet parsing, lifecycle state mapping, queue rules, formatting."""

from __future__ import annotations

import base64
import datetime as dt

import pytest

from aureom_torrent.domain.identity import IdentityError, TorrentIdentity
from aureom_torrent.domain.magnet import MAX_MAGNET_LENGTH, MagnetError, parse_magnet
from aureom_torrent.domain.schedule import bandwidth_plan, seeding_limit_reached
from aureom_torrent.domain.state import derive_state, eta_seconds, ratio_permille
from aureom_torrent.domain.transfers import EnginePhase, TorrentStatus, TransferRecord, TransferState
from aureom_torrent.settings.models import BandwidthSchedule, QueueSettings
from aureom_torrent.ui.format import format_eta, format_progress, format_ratio, format_size

V1 = "ab" * 20
V1B = "cd" * 20
V2 = "12" * 32
V2B = "34" * 32


# ---------------------------------------------------------------- identity
def test_identity_kinds_and_normalisation():
    assert TorrentIdentity(V1.upper(), None).v1 == V1
    assert TorrentIdentity(V1, None).kind == "v1"
    assert TorrentIdentity(None, V2).kind == "v2"
    assert TorrentIdentity(V1, V2).kind == "hybrid"


@pytest.mark.parametrize("v1,v2", [(None, None), ("xyz", None), (V1[:-1], None), (None, V2 + "0"), (V2, None)])
def test_identity_rejects_bad_hashes(v1, v2):
    with pytest.raises(IdentityError):
        TorrentIdentity(v1, v2)


def test_duplicate_identities_across_v1_v2_hybrid():
    hybrid = TorrentIdentity(V1, V2)
    assert hybrid.matches(TorrentIdentity(V1, None))
    assert hybrid.matches(TorrentIdentity(None, V2))
    assert TorrentIdentity(V1, None).matches(hybrid)
    assert not TorrentIdentity(V1, None).matches(TorrentIdentity(None, V2))  # unknowable without metadata
    assert not hybrid.matches(TorrentIdentity(V1B, V2B))
    assert TorrentIdentity(V1, None).merged(TorrentIdentity(V1, V2)) == hybrid
    assert TorrentIdentity(V1, V2).conflicts(TorrentIdentity(V1, V2B))
    with pytest.raises(IdentityError):
        TorrentIdentity(V1, V2).merged(TorrentIdentity(V1, V2B))


# ------------------------------------------------------------------ magnet
def test_magnet_v1_hex_and_base32():
    link = parse_magnet(f"magnet:?xt=urn:btih:{V1.upper()}&dn=My+File")
    assert link.identity == TorrentIdentity(V1, None) and link.display_name == "My File"
    b32 = base64.b32encode(bytes.fromhex(V1)).decode()
    assert parse_magnet(f"magnet:?xt=urn:btih:{b32}").identity.v1 == V1


def test_magnet_v2_and_hybrid_multiple_xt():
    assert parse_magnet(f"magnet:?xt=urn:btmh:1220{V2}").identity == TorrentIdentity(None, V2)
    link = parse_magnet(f"magnet:?xt=urn:btih:{V1}&xt=urn:btmh:1220{V2}&xt=urn:sha1:IGNORED")
    assert link.identity.kind == "hybrid" and any(i.startswith("xt:") for i in link.ignored)
    assert parse_magnet(f"magnet:?xt.1=urn:btih:{V1}&xt.2=urn:btmh:1220{V2}").identity.kind == "hybrid"


def test_magnet_trackers_webseeds_peers_sources_select_only():
    uri = (f"magnet:?xt=urn:btih:{V1}&tr=udp%3A%2F%2Ft.example%3A6969%2Fannounce&tr=https://t2.example/announce"
           "&tr=ftp://bad/&tr=javascript:alert(1)&ws=https://seed.example/files/&ws=file:///etc/passwd"
           "&xs=https://example.org/a.torrent&x.pe=192.0.2.1:6881&x.pe=[2001:db8::1]:51413&x.pe=bad&so=0,2,4-6")
    link = parse_magnet(uri)
    assert link.trackers == ("udp://t.example:6969/announce", "https://t2.example/announce")
    assert link.web_seeds == ("https://seed.example/files/",)
    assert link.sources == ("https://example.org/a.torrent",)
    assert link.peers == (("192.0.2.1", 6881), ("2001:db8::1", 51413))
    assert link.select_only == (0, 2, 4, 5, 6)
    again = parse_magnet(link.canonical_uri())
    assert again.identity == link.identity and again.trackers == link.trackers


def test_magnet_display_name_is_only_a_label():
    link = parse_magnet(f"magnet:?xt=urn:btih:{V1}&dn=..%2F..%2Fetc%2Fpasswd")
    assert "/" not in link.display_name and "\\" not in link.display_name
    assert parse_magnet(f"magnet:?xt=urn:btih:{V1}&dn=" + "a" * 5000).display_name == "a" * 255


@pytest.mark.parametrize("uri,fragment", [
    ("http://example.org", "not a magnet"),
    ("magnet:?dn=only-a-name", "no BitTorrent info-hash"),
    (f"magnet:?xt=urn:btih:{V1[:-2]}", "40 hexadecimal or 32 base32"),
    ("magnet:?xt=urn:btih:" + "!" * 32, "base32"),
    (f"magnet:?xt=urn:btmh:1220{V2[:-2]}", "64 hexadecimal"),
    (f"magnet:?xt=urn:btmh:1120{V2}", "SHA-256"),
    (f"magnet:?xt=urn:btih:{V1}&xt=urn:btih:{V1B}", "two different v1"),
    (f"magnet:?xt=urn:btmh:1220{V2}&xt=urn:btmh:1220{V2B}", "two different v2"),
    (f"magnet:?xt=urn:btih:{V1}&dn=a\x00b", "control characters"),
    (f"magnet:?xt=urn:btih:{V1}&dn=%ff%fe", "UTF-8"),
])
def test_malformed_magnets_have_clear_errors(uri, fragment):
    with pytest.raises(MagnetError) as err:
        parse_magnet(uri)
    assert fragment in str(err.value)


def test_magnet_size_limits():
    with pytest.raises(MagnetError, match="too long"):
        parse_magnet(f"magnet:?xt=urn:btih:{V1}&dn=" + "a" * MAX_MAGNET_LENGTH)
    with pytest.raises(MagnetError, match="too many parameters"):
        parse_magnet(f"magnet:?xt=urn:btih:{V1}" + "&a=1" * 300)
    many = parse_magnet(f"magnet:?xt=urn:btih:{V1}" + "".join(f"&tr=udp://t{i}.ex:1/a" for i in range(200)))
    assert len(many.trackers) == 64


def test_magnet_never_carries_payment_instructions():
    link = parse_magnet(f"magnet:?xt=urn:btih:{V1}&lightning=lnbc1xyz&bitcoin=bc1qxyz&pay=1000")
    assert set(link.ignored) >= {"lightning", "bitcoin", "pay"}
    assert not hasattr(link, "payment")


# ------------------------------------------------------------ state mapping
def st(**kw) -> TorrentStatus:
    base = dict(transfer_id="t", phase=EnginePhase.DOWNLOADING, has_metadata=True, auto_managed=True,
                total=1000, total_wanted=1000)
    base.update(kw)
    return TorrentStatus(**base)


@pytest.mark.parametrize("status,kwargs,expected", [
    (st(has_metadata=False, phase=EnginePhase.DOWNLOADING_METADATA), {}, TransferState.RETRIEVING_METADATA),
    (st(has_metadata=False, paused=True, auto_managed=False), {}, TransferState.PAUSED),
    (st(has_metadata=False, paused=True), {}, TransferState.QUEUED),
    (st(phase=EnginePhase.CHECKING_FILES), {}, TransferState.CHECKING),
    (st(phase=EnginePhase.CHECKING_FILES, paused=True), {}, TransferState.QUEUED),
    (st(download_rate=5000, num_peers=2), {}, TransferState.DOWNLOADING),
    (st(download_rate=0, num_peers=2), {}, TransferState.DOWNLOADING),
    (st(paused=True, auto_managed=False), {"manual_paused": True}, TransferState.PAUSED),
    (st(paused=True), {}, TransferState.QUEUED),
    (st(session_paused=True), {}, TransferState.QUEUED),
    (st(is_finished=True, phase=EnginePhase.FINISHED), {}, TransferState.SEEDING),
    (st(is_finished=True, is_seeding=True, phase=EnginePhase.SEEDING), {}, TransferState.SEEDING),
    (st(is_finished=True, paused=True, auto_managed=False), {"manual_paused": True}, TransferState.COMPLETED),
    (st(is_finished=True, paused=True, auto_managed=False), {"stopped_by_limit": True}, TransferState.COMPLETED),
    (st(is_finished=True, paused=True), {}, TransferState.QUEUED),
    (st(moving_storage=True), {}, TransferState.MOVING),
    (st(error="disk full", download_rate=10), {}, TransferState.ERROR),
    (st(upload_mode=True), {}, TransferState.ERROR),
    (st(is_finished=True, total_wanted=0), {}, TransferState.PAUSED),
    (st(is_finished=True), {"preview": True}, TransferState.PAUSED),
])
def test_state_mapping(status, kwargs, expected):
    params = {"manual_paused": False, **kwargs}
    assert derive_state(status, **params)[0] is expected


def test_stalled_transfer_is_never_complete():
    stalled = st(wanted_done=999, download_rate=0, num_peers=0)
    state, detail = derive_state(stalled, manual_paused=False)
    assert state is TransferState.DOWNLOADING and "Stalled" in detail
    assert stalled.progress_ppm == 999_000 < 1_000_000
    almost = st(total_wanted=10**9, wanted_done=10**9 - 1)
    assert almost.progress_ppm == 999_999 and format_progress(almost.progress_ppm) == "99.9%"
    assert format_progress(1_000_000) == "100%"
    # engine says finished → exactly 100 %
    assert st(is_finished=True, wanted_done=1000).progress_ppm == 1_000_000
    # nothing selected is not progress
    assert st(is_finished=True, total_wanted=0).progress_ppm == 0
    assert st(has_metadata=False).progress_ppm == 0


def test_selected_complete_is_distinct_from_torrent_complete():
    selected = st(is_finished=True, is_seeding=False, total=5000, total_wanted=1000, wanted_done=1000)
    assert derive_state(selected, manual_paused=False) == (TransferState.SEEDING, "Seeding the selected files")
    whole = st(is_finished=True, is_seeding=True)
    assert derive_state(whole, manual_paused=False)[1] == "Seeding the complete torrent"


def test_eta_only_when_meaningful():
    assert eta_seconds(st(wanted_done=0, download_rate=100), TransferState.DOWNLOADING) is None  # too slow
    assert eta_seconds(st(total_wanted=10_000_000, download_rate=100_000), TransferState.DOWNLOADING) == 100
    assert eta_seconds(st(download_rate=100_000), TransferState.PAUSED) is None
    assert eta_seconds(st(total_wanted=10**15, download_rate=2000), TransferState.DOWNLOADING) is None


def test_ratio():
    assert ratio_permille(500, 1000, 0) == 500
    assert ratio_permille(3000, 0, 1000) == 3000  # a created torrent: ratio against its size
    assert ratio_permille(1, 0, 0) is None
    assert format_ratio(1234) == "1.23" and format_ratio(None) == "—"


# -------------------------------------------------------------- queue rules
def rec(**kw) -> TransferRecord:
    return TransferRecord(id="a" * 32, identity=TorrentIdentity(V1, None), name="n", save_path="/x", **kw)


def test_seeding_limits_global_and_per_transfer():
    queue = QueueSettings(ratio_limit_permille=2000, seed_time_limit_minutes=60)
    seeding = st(is_finished=True, all_time_download=1000, all_time_upload=1999, seeding_seconds=10)
    assert seeding_limit_reached(rec(), seeding, queue) is None
    assert "ratio" in seeding_limit_reached(rec(), st(is_finished=True, all_time_download=1000, all_time_upload=2000), queue)
    assert "time" in seeding_limit_reached(rec(), st(is_finished=True, seeding_seconds=3600), queue)
    # per-transfer override: unlimited beats global, stricter beats global
    over = st(is_finished=True, all_time_download=1000, all_time_upload=9000, seeding_seconds=99999)
    assert seeding_limit_reached(rec(ratio_limit_permille=-1, seed_time_limit_s=-1), over, queue) is None
    assert seeding_limit_reached(rec(ratio_limit_permille=500), st(is_finished=True, all_time_download=1000,
                                                                    all_time_upload=500), QueueSettings()) is not None
    # not finished, or nothing selected → never
    assert seeding_limit_reached(rec(), st(all_time_upload=10**9, all_time_download=1), queue) is None
    assert seeding_limit_reached(rec(), st(is_finished=True, total_wanted=0, seeding_seconds=10**6), queue) is None
    # a created torrent (nothing downloaded) uses its size as the ratio base
    created = st(is_finished=True, total_wanted=1000, all_time_download=0, all_time_upload=2000)
    assert seeding_limit_reached(rec(), created, queue) is not None


def test_bandwidth_schedule_selection():
    night = BandwidthSchedule(name="night", days=[0, 1, 2, 3, 4], start_minute=22 * 60, end_minute=6 * 60,
                              download_limit=0, upload_limit=50_000)
    office = BandwidthSchedule(name="office", days=[0, 1, 2, 3, 4], start_minute=9 * 60, end_minute=17 * 60,
                               pause_all=True)
    queue = QueueSettings(download_limit=1_000_000, upload_limit=200_000, schedules=[office, night])
    monday = dt.datetime(2026, 11, 23)  # a Monday
    assert bandwidth_plan(queue, monday.replace(hour=10)).pause_all
    assert bandwidth_plan(queue, monday.replace(hour=18)).schedule_name == ""
    assert bandwidth_plan(queue, monday.replace(hour=18)).download_limit == 1_000_000
    assert bandwidth_plan(queue, monday.replace(hour=23)).schedule_name == "night"
    # Saturday 02:00 still belongs to Friday night's period; Sunday 02:00 does not (Saturday is not selected)
    assert bandwidth_plan(queue, dt.datetime(2026, 11, 28, 2)).schedule_name == "night"
    assert bandwidth_plan(queue, dt.datetime(2026, 11, 29, 2)).schedule_name == ""
    office.enabled = False
    assert not bandwidth_plan(queue, monday.replace(hour=10)).pause_all
    whole_day = BandwidthSchedule(name="sunday", days=[6], start_minute=0, end_minute=0, pause_all=True)
    assert bandwidth_plan(QueueSettings(schedules=[whole_day]), dt.datetime(2026, 11, 29, 15)).pause_all


# ---------------------------------------------------------------- formatting
def test_formatting():
    assert format_size(0) == "0 B" and format_size(1536) == "1.5 KiB" and format_size(None) == "—"
    assert format_size(5 * 1024 ** 3) == "5.0 GiB"
    assert format_eta(59) == "59s" and format_eta(3661) == "1h 01m" and format_eta(None) == ""
