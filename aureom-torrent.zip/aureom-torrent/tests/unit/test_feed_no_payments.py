"""Structural guard: the RSS subsystem cannot reach the payment subsystem.

Feed rules must never trigger Bitcoin or Lightning payments.  The strongest way
to guarantee that is for the ``feeds`` package to have no path to ``payments``
at all, which these tests enforce on the source and at import time.
"""

from __future__ import annotations

import ast
import subprocess
import sys
from pathlib import Path

import aureom_torrent.feeds as feeds_pkg

FEEDS_DIR = Path(feeds_pkg.__file__).resolve().parent
FORBIDDEN = ("payments", "bolt11", "lnurl", "keyring")


def _imports(path: Path) -> list[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom):
            module = "." * node.level + (node.module or "")
            names.append(module)
            names += [f"{module}.{a.name}" for a in node.names]
    return names


def test_feeds_sources_do_not_import_payment_code():
    files = sorted(FEEDS_DIR.glob("*.py"))
    assert len(files) >= 8
    for path in files:
        for name in _imports(path):
            assert not any(part in name.lower().split(".") for part in FORBIDDEN), f"{path.name} imports {name}"


def test_feeds_sources_do_not_mention_payment_apis():
    for path in sorted(FEEDS_DIR.glob("*.py")):
        text = path.read_text(encoding="utf-8").lower()
        for needle in ("paymentservice", "pay_invoice", "send_payment", "lightningbackend"):
            assert needle not in text, f"{path.name} mentions {needle}"


def test_importing_feeds_does_not_load_the_payments_package():
    code = ("import sys, aureom_torrent.feeds.service, aureom_torrent.feeds.rules, aureom_torrent.feeds.opml;"
            "bad=[m for m in sys.modules if m.startswith('aureom_torrent.payments.') or m in ('bolt11','keyring')];"
            "print(bad); sys.exit(1 if bad else 0)")
    proc = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=60)
    assert proc.returncode == 0, proc.stdout + proc.stderr
