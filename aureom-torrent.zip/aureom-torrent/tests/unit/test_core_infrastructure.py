"""Unit tests: path validation, persistence recovery, settings corruption, redaction, HTTP policy,
event coalescing, engine settings translation, theme contrast."""

from __future__ import annotations

import json
import logging
import os
import sqlite3

import pytest

from aureom_torrent.diagnostics.export import DiagnosticsCollector
from aureom_torrent.diagnostics.logs import configure_logging, ring_buffer
from aureom_torrent.diagnostics.redaction import REDACTED, redact, redact_obj
from aureom_torrent.domain.transfers import TorrentStatus
from aureom_torrent.engine import commands as c
from aureom_torrent.engine import events as e
from aureom_torrent.filesystem.paths import (UnsafePathError, atomic_write, check_destination, owned_paths,
                                             relative_path_problems, resolve_inside, scan_for_publish)
from aureom_torrent.net.http import (BlockedDestination, HttpPolicy, check_url, safe_url_for_display)
from aureom_torrent.persistence.database import Database, DatabaseError
from aureom_torrent.persistence.transfers import ResumeStore
from aureom_torrent.services.event_pump import EventPump
from aureom_torrent.settings.models import AppSettings
from aureom_torrent.settings.store import SettingsStore
from aureom_torrent.ui.themes.theme import CONTRAST_PAIRS, DARK, LIGHT, contrast_ratio, stylesheet


# ---------------------------------------------------------- path validation
@pytest.mark.parametrize("path,fragment", [
    ("../etc/passwd", "traversal"), ("a/../../b", "traversal"), ("/etc/passwd", "absolute"),
    ("C:\\Windows\\x", "absolute"), ("a//b", "empty path component"), ("a/./b", "current-directory"),
    ("a\x00b", "control"), ("a/" + "x" * 300, "too long"), ("", "empty path"),
    ("CON", "reserved"), ("dir/aux.txt", "reserved"), ("LPT1.log", "reserved"),
    ("name. ", "ends with"), ("what?.txt", "Windows forbids"),
])
def test_relative_path_problems(path, fragment):
    assert any(fragment in p for p in relative_path_problems(path)), relative_path_problems(path)


def test_safe_paths_have_no_problems():
    for path in ("a.bin", "dir/sub/file.name.txt", "ünïcødé/文件.dat", "console/config.txt"):
        assert relative_path_problems(path) == []


def test_resolve_inside_blocks_traversal_and_symlink_escape(tmp_path):
    root = tmp_path / "root"
    (root / "sub").mkdir(parents=True)
    outside = tmp_path / "outside"
    outside.mkdir()
    assert resolve_inside(root, "sub/file.bin") == (root / "sub/file.bin").resolve()
    with pytest.raises(UnsafePathError):
        resolve_inside(root, "../outside/x")
    with pytest.raises(UnsafePathError):
        resolve_inside(root, "/etc/passwd")
    os.symlink(outside, root / "link")
    with pytest.raises(UnsafePathError):
        resolve_inside(root, "link/secret.txt")


def test_owned_paths_for_deletion(tmp_path):
    root = tmp_path / "dl"
    root.mkdir()
    assert owned_paths(str(root), ["t/a", "t/b/c"]) == [(root / "t/a").resolve(), (root / "t/b/c").resolve()]
    with pytest.raises(UnsafePathError):
        owned_paths("relative/dir", ["a"])
    with pytest.raises(UnsafePathError):
        owned_paths("/", ["etc/passwd"])
    with pytest.raises(UnsafePathError):
        owned_paths(str(root), ["ok", "../escape"])


def test_check_destination(tmp_path):
    assert check_destination(str(tmp_path / "new" / "deeper"), 10).ok  # creatable
    assert not check_destination("relative", 0).ok
    file_path = tmp_path / "file"
    file_path.write_text("x")
    assert "file, not a folder" in check_destination(str(file_path)).problems[0]
    report = check_destination(str(tmp_path), 10 ** 18)
    assert not report.ok and "Not enough free space" in report.problems[0]
    if os.geteuid() != 0:
        locked = tmp_path / "locked"
        locked.mkdir()
        locked.chmod(0o500)
        assert "permission" in check_destination(str(locked / "x")).problems[0].lower()


def test_atomic_write_leaves_no_partial_file(tmp_path):
    target = tmp_path / "state.bin"
    atomic_write(target, b"one")
    atomic_write(target, b"two")
    assert target.read_bytes() == b"two"
    assert [p.name for p in tmp_path.iterdir()] == ["state.bin"]


def test_scan_never_follows_symlinks(tmp_path):
    root = tmp_path / "share"
    (root / "docs").mkdir(parents=True)
    (root / "docs/a.txt").write_text("a")
    (root / ".DS_Store").write_text("junk")
    secret = tmp_path / "secret.txt"
    secret.write_text("private")
    os.symlink(secret, root / "docs/leak.txt")
    os.symlink(tmp_path, root / "parent")
    os.symlink(root / "docs/a.txt", root / "inner-link.txt")
    scan = scan_for_publish(str(root))
    assert [f.relative for f in scan.files] == ["docs/a.txt"]
    reasons = dict(scan.skipped)
    assert "outside" in reasons["docs/leak.txt"] and "outside" in reasons["parent"]
    assert "not followed" in reasons["inner-link.txt"] and "operating-system" in reasons[".DS_Store"]
    link_root = tmp_path / "link-root"
    os.symlink(root, link_root)
    with pytest.raises(UnsafePathError):
        scan_for_publish(str(link_root))


# ------------------------------------------------------ persistence recovery
def test_migrations_apply_once_and_are_versioned(tmp_path):
    db = Database(tmp_path / "a.sqlite3")
    assert db.schema_version() >= 4
    tables = {r[0] for r in db.query("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"transfers", "feeds", "payments", "publish_jobs", "manifests", "settings", "meta"} <= tables
    assert db.migrate() == []  # idempotent
    db.close()


def test_corrupt_database_is_set_aside_not_fatal(tmp_path):
    path = tmp_path / "a.sqlite3"
    path.write_bytes(b"this is definitely not a sqlite database" * 50)
    db = Database(path)
    assert db.recovered_from and os.path.exists(db.recovered_from)
    assert db.schema_version() >= 1
    db.close()


def test_newer_schema_is_refused(tmp_path):
    path = tmp_path / "a.sqlite3"
    Database(path).close()
    conn = sqlite3.connect(path)
    conn.execute("INSERT INTO schema_migrations VALUES (9999, 'future', 0)")
    conn.commit()
    conn.close()
    with pytest.raises(DatabaseError, match="newer version"):
        Database(path)


def test_transaction_rolls_back_on_error():
    db = Database(None)
    with pytest.raises(RuntimeError):
        with db.tx() as conn:
            conn.execute("INSERT INTO meta(key, value) VALUES ('k', 'v')")
            raise RuntimeError("boom")
    assert db.get_meta("k") is None


def test_resume_store_atomic_and_sweeps_interrupted_writes(tmp_path):
    (tmp_path / "resume").mkdir()
    (tmp_path / "resume" / "x.fastresume.abc.tmp").write_bytes(b"partial")
    store = ResumeStore(tmp_path / "resume", tmp_path / "torrents")
    assert not list((tmp_path / "resume").glob("*.tmp"))
    tid = "a" * 32
    assert store.load_resume(tid) is None
    store.save_resume(tid, b"v1")
    store.save_resume(tid, b"v2")
    assert store.load_resume(tid) == b"v2"
    store.resume_path(tid).write_bytes(b"")
    assert store.load_resume(tid) is None  # an empty file is treated as missing
    with pytest.raises(ValueError):
        store.save_resume("../../etc/passwd", b"x")
    store.delete(tid)
    assert not store.resume_path(tid).exists()


def test_corrupt_settings_fall_back_per_section():
    db = Database(None)
    db.execute("INSERT INTO settings VALUES ('queue', '{not json', 0)")
    db.execute("INSERT INTO settings VALUES ('ui', ?, 0)", (json.dumps({"theme": 7, "density": "comfortable"}),))
    db.execute("INSERT INTO settings VALUES ('bittorrent', ?, 0)",
               (json.dumps({"listen_port": 99999999, "encryption": "nope", "proxy": "oops", "extra": 1}),))
    store = SettingsStore(db)
    s = store.get()
    assert s.queue.max_active_downloads == 3  # defaults restored
    assert s.ui.theme == "light" and s.ui.density == "comfortable"
    assert s.bittorrent.listen_port == 65535 and s.bittorrent.encryption == "enabled"
    assert s.bittorrent.proxy.kind == "none"
    assert len(store.warnings) >= 3
    changed = store.snapshot()
    changed.queue.max_active_seeds = 9
    store.save(changed)
    assert SettingsStore(db).get().queue.max_active_seeds == 9 and not SettingsStore(db).warnings


def test_settings_never_contain_secrets():
    text = json.dumps(AppSettings().to_dict()).lower()
    for word in ("password", "macaroon", "token", "secret"):
        assert word not in text


# ---------------------------------------------------------------- redaction
@pytest.mark.parametrize("secret,text", [
    ("s3cr3tpasskey0123456789abcdef", "announce to https://tracker.example/announce?passkey=s3cr3tpasskey0123456789abcdef&x=1"),
    ("0123456789abcdef0123456789abcdef", "http://tracker.example/0123456789abcdef0123456789abcdef/announce failed"),
    ("0123456789abcdef0123456789abcdef", "udp://tracker.example:6969/announce/0123456789abcdef0123456789abcdef"),
    ("hunter2", "proxy socks5://alice:hunter2@10.0.0.1:1080 refused"),
    ("AKIAEXAMPLE", "PUT https://bucket.s3.example/page.html?X-Amz-Credential=AKIAEXAMPLE&X-Amz-Signature=abcdef12"),
    ("0201036c6e6402f801", "Grpc-Metadata-macaroon: 0201036c6e6402f801"),
    ("0201036c6e6402f801", "macaroon=0201036c6e6402f801"),
    ("deadbeefcafe", '{"payment_preimage": "deadbeefcafe"}'),
    ("topsecret", "Authorization: Bearer topsecret"),
    ("qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq", "paying lnbc2500u1pqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq now"),
    ("tracker.secret.example", "magnet:?xt=urn:btih:" + "ab" * 20 + "&tr=http%3A%2F%2Ftracker.secret.example%2Fann%3Fpk%3D1"),
    ("ab" * 60, "macaroon bytes " + "ab" * 60),
])
def test_redaction_removes_secret(secret, text):
    out = redact(text)
    assert secret not in out and REDACTED in out
    assert redact(out) == out  # idempotent


def test_redaction_keeps_useful_context():
    line = "tracker https://tracker.example/announce?passkey=abcdef0123456789 returned 503 for " + "ab" * 20
    out = redact(line)
    assert "tracker.example" in out and "503" in out and "ab" * 20 in out  # info-hashes are not secrets


def test_redact_obj_and_log_pipeline(tmp_path):
    data = redact_obj({"lnd_url": "https://node.example:8080/v1?macaroon=abc123456", "macaroon": "0201aa",
                       "nested": [{"proxy_url": "socks5://u:p@h:1", "note": "ok"}], "invoice": "lnbc1qqq", "empty": ""})
    assert data["macaroon"] == REDACTED and data["invoice"] == REDACTED and data["empty"] == ""
    assert data["nested"][0]["proxy_url"] == REDACTED and data["nested"][0]["note"] == "ok"
    assert "abc123456" not in data["lnd_url"]

    configure_logging(tmp_path / "logs")
    log = logging.getLogger("aureom_torrent.test")
    log.info("fetching %s", "https://feed.example/rss?token=verysecrettoken")
    try:
        raise RuntimeError("boom at https://u:pw@host/x?key=zzzzzzzz")
    except RuntimeError:
        log.exception("failed")
    for handler in logging.getLogger("aureom_torrent").handlers:
        handler.flush()
    file_text = (tmp_path / "logs" / "aureom-torrent.log").read_text()
    ring_text = "\n".join(entry.message for entry in ring_buffer().entries())
    for text in (file_text, ring_text):
        assert "verysecrettoken" not in text and "zzzzzzzz" not in text and ":pw@" not in text
        assert "feed.example" in text

    collector = DiagnosticsCollector()
    collector.register("backend", lambda: {"url": "https://x.example/?sig=abcdefgh1234", "password": "p"})
    collector.register("broken", lambda: 1 / 0)
    bundle = json.loads(collector.export_json())
    assert bundle["backend"]["password"] == REDACTED and "abcdefgh1234" not in json.dumps(bundle)
    assert "ZeroDivisionError" in bundle["broken"]["error"] and "libtorrent" in bundle["libraries"]
    assert "verysecrettoken" not in json.dumps(bundle)


def test_log_ring_buffer_is_bounded():
    ring = ring_buffer()
    log = logging.getLogger("aureom_torrent.flood")
    logging.getLogger("aureom_torrent").setLevel(logging.INFO)
    if ring not in logging.getLogger("aureom_torrent").handlers:
        logging.getLogger("aureom_torrent").addHandler(ring)
    for i in range(5000):
        log.info("line %d", i)
    assert len(ring.entries()) <= 2000


# --------------------------------------------------------------- HTTP policy
def fake_resolver(mapping):
    def resolve(host, port, type=None):
        return [(2, 1, 6, "", (mapping[host], port))]
    return resolve


@pytest.mark.parametrize("url", [
    "ftp://example.org/x", "file:///etc/passwd", "javascript:alert(1)", "https://user:pw@example.org/",
    "http://127.0.0.1/x", "http://[::1]/x", "http://localhost/x", "http://10.0.0.5/x", "http://192.168.1.1/",
    "http://169.254.169.254/latest/meta-data", "http://0.0.0.0/", "https:///nohost", "http://[::ffff:127.0.0.1]/",
])
def test_check_url_blocks_by_default(url):
    with pytest.raises(BlockedDestination):
        check_url(url, HttpPolicy())


def test_check_url_resolved_names_and_explicit_allowances():
    with pytest.raises(BlockedDestination):
        check_url("https://intranet.example/x", HttpPolicy(), resolver=fake_resolver({"intranet.example": "10.1.2.3"}))
    check_url("https://public.example/x", HttpPolicy(), resolver=fake_resolver({"public.example": "93.184.216.34"}))
    check_url("http://127.0.0.1:8080/x", HttpPolicy(allow_loopback=True))
    check_url("https://10.0.0.5/x", HttpPolicy(allow_private=True))
    with pytest.raises(BlockedDestination, match="https"):
        check_url("http://public.example/", HttpPolicy(allow_http=False),
                  resolver=fake_resolver({"public.example": "93.184.216.34"}))
    with pytest.raises(BlockedDestination):  # link-local stays blocked even when private is allowed
        check_url("http://169.254.1.1/", HttpPolicy(allow_private=True, allow_loopback=True))


def test_safe_url_for_display_drops_query_and_credentials():
    assert safe_url_for_display("https://u:p@h.example:8443/a/b?token=1#f") == "https://h.example:8443/a/b"


# ------------------------------------------------------------ event pump
def test_event_pump_coalesces_snapshots_but_never_drops_lifecycle_events():
    seen = []
    pump = EventPump(seen.append)
    a1, a2 = TorrentStatus("a", wanted_done=1), TorrentStatus("a", wanted_done=2)
    b1 = TorrentStatus("b", wanted_done=5)
    pump.post(e.StatusBatch((a1,)))
    pump.post(e.StatusBatch((b1,)))
    pump.post(e.StatusBatch((a2,)))
    pump.post(e.TorrentFinished("a"))
    pump.post(e.StatusBatch((a1,)))
    pump.post(e.TorrentRemoved("a"))
    pump.post(e.TorrentRemoved("b"))
    assert pump.drain() == 5
    assert isinstance(seen[0], e.StatusBatch) and {s.transfer_id: s.wanted_done for s in seen[0].statuses} == {"a": 2, "b": 5}
    assert [type(x).__name__ for x in seen[1:]] == ["TorrentFinished", "StatusBatch", "TorrentRemoved", "TorrentRemoved"]
    assert pump.coalesced == 2


def test_event_pump_survives_handler_errors_and_stops_cleanly():
    seen = []

    def handler(event):
        if isinstance(event, e.TorrentFinished):
            raise RuntimeError("handler bug")
        seen.append(event)

    pump = EventPump(handler)
    pump.start()
    pump.post(e.TorrentFinished("x"))
    pump.post(e.TorrentRemoved("x"))
    pump.stop()
    assert seen == [e.TorrentRemoved("x")]


# ------------------------------------------------------- engine settings
def test_settings_pack_respects_proxy_and_isolation():
    from aureom_torrent.engine.libtorrent_adapter import build_settings_pack

    plain = build_settings_pack(c.EngineSettings())
    assert plain["enable_dht"] and plain["enable_lsd"] and plain["proxy_type"] == 0
    socks = build_settings_pack(c.EngineSettings(proxy_kind="socks5_pw", proxy_host="p", proxy_port=1080,
                                                 proxy_username="u", proxy_password="pw"))
    assert socks["proxy_hostname"] == "p" and socks["proxy_password"] == "pw"
    assert not socks["enable_lsd"] and not socks["enable_upnp"] and not socks["enable_natpmp"]
    assert socks["enable_dht"]  # SOCKS5 can carry UDP
    http = build_settings_pack(c.EngineSettings(proxy_kind="http", proxy_host="p", proxy_port=3128))
    assert not http["enable_dht"] and not http["enable_outgoing_utp"] and not http["enable_incoming_utp"]
    isolated = build_settings_pack(c.EngineSettings(isolated=True))
    assert not any(isolated[k] for k in ("enable_dht", "enable_lsd", "enable_upnp", "enable_natpmp"))
    forced = build_settings_pack(c.EngineSettings(encryption="forced"))
    assert forced["in_enc_policy"] == forced["out_enc_policy"] == 0


def test_engine_settings_from_app_settings():
    from aureom_torrent.services.engine_config import engine_settings, listen_interfaces
    from aureom_torrent.settings.secrets import SECRET_BT_PROXY_PASSWORD, MemorySecretStore

    app = AppSettings()
    assert listen_interfaces(app.bittorrent) == "0.0.0.0:6881,[::]:6881"
    app.bittorrent.bind_interface = "tun0"
    assert listen_interfaces(app.bittorrent) == "tun0:6881"
    app.bittorrent.proxy.kind = "socks5_pw"
    secrets = MemorySecretStore()
    secrets.set(SECRET_BT_PROXY_PASSWORD, "pw")
    es = engine_settings(app, secrets)
    assert es.proxy_password == "pw" and es.bound_interface == "tun0"
    assert engine_settings(app, secrets, isolated=True).listen_interfaces == "127.0.0.1:0"


def test_interface_presence_probe():
    from aureom_torrent.engine.libtorrent_adapter import interface_present

    assert interface_present("") and interface_present("127.0.0.1") and interface_present("lo")
    assert not interface_present("no-such-if0") and not interface_present("203.0.113.77")


# ------------------------------------------------------------------- theme
@pytest.mark.parametrize("palette", [LIGHT, DARK])
def test_theme_text_contrast_meets_wcag_aa(palette):
    for fg, bg in CONTRAST_PAIRS:
        ratio = contrast_ratio(getattr(palette, fg), getattr(palette, bg))
        assert ratio >= 4.5, f"{palette.name}: {fg} on {bg} = {ratio:.2f}"


def test_stylesheet_builds_for_both_densities():
    for palette in (LIGHT, DARK):
        for density in ("compact", "comfortable"):
            assert "QTableView" in stylesheet(palette, density)
