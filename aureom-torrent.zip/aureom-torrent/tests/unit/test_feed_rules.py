"""Rule validation and pure evaluation."""

from __future__ import annotations

import time

import pytest

from aureom_torrent.feeds.models import (ACTION_ADD, ACTION_NEED_SIZE, ACTION_REVIEW, ACTION_SKIP, LINK_MAGNET,
                                         LINK_NONE, LINK_TORRENT, FeedRule)
from aureom_torrent.feeds.rules import RuleError, RuleInput, check_budget, evaluate_rule, validate_rule


def entry(title="Open Field Recordings Vol. 3 (FLAC)", link_type=LINK_TORRENT, size=None, trusted=False):
    return RuleInput(title, link_type, size, trusted)


def test_include_terms_must_all_match_case_insensitively():
    rule = FeedRule(id=1, include=["field", "FLAC"])
    assert evaluate_rule(rule, entry()).action == ACTION_ADD
    assert evaluate_rule(rule, entry("Open Field Recordings (MP3)")).action == ACTION_SKIP
    assert "FLAC" in evaluate_rule(rule, entry("Open Field Recordings (MP3)")).reason


def test_exclude_terms_win():
    rule = FeedRule(id=1, include=["field"], exclude=["vol. 3"])
    decision = evaluate_rule(rule, entry())
    assert decision.action == ACTION_SKIP and "excluded" in decision.reason


def test_rule_without_terms_matches_everything_with_a_link():
    rule = FeedRule(id=1)
    assert evaluate_rule(rule, entry()).action == ACTION_ADD
    assert evaluate_rule(rule, entry(link_type=LINK_NONE)).action == ACTION_SKIP


def test_regex_matching():
    rule = FeedRule(id=1, regex=r"vol\.\s*(\d+)")
    assert evaluate_rule(rule, entry()).action == ACTION_ADD
    assert evaluate_rule(rule, entry("No volume here")).action == ACTION_SKIP


def test_catastrophic_regex_times_out_and_goes_to_review():
    rule = FeedRule(id=1, regex=r"^(a|aa)+$")  # exponential backtracking even in `regex`
    started = time.monotonic()
    decision = evaluate_rule(rule, entry("a" * 60 + "!"), regex_timeout_ms=50)
    elapsed = time.monotonic() - started
    assert decision.action == ACTION_REVIEW and "too long" in decision.reason
    assert elapsed < 2.0


def test_size_limits_need_a_trusted_size():
    rule = FeedRule(id=1, max_size=1000)
    # unknown and feed-reported sizes are not good enough
    assert evaluate_rule(rule, entry(size=None)).action == ACTION_NEED_SIZE
    assert evaluate_rule(rule, entry(size=10, trusted=False)).action == ACTION_NEED_SIZE
    assert evaluate_rule(rule, entry(size=10, trusted=True)).action == ACTION_ADD
    too_big = evaluate_rule(rule, entry(size=1001, trusted=True))
    assert too_big.action == ACTION_SKIP and "maximum" in too_big.reason
    small = evaluate_rule(FeedRule(id=1, min_size=500), entry(size=499, trusted=True))
    assert small.action == ACTION_SKIP and "minimum" in small.reason
    # a byte budget also needs a real size
    assert evaluate_rule(FeedRule(id=1, daily_bytes_budget=10), entry(link_type=LINK_MAGNET)).action == ACTION_NEED_SIZE


def test_size_is_not_checked_when_the_title_does_not_match():
    rule = FeedRule(id=1, include=["nomatch"], max_size=1000)
    assert evaluate_rule(rule, entry()).action == ACTION_SKIP


def test_check_budget():
    rule = FeedRule(id=1, max_per_refresh=2, daily_count_budget=5, daily_bytes_budget=1000)
    ok = dict(added_this_refresh=0, added_today=0, bytes_today=0, size=100)
    assert check_budget(rule, **ok) is None
    assert "per-refresh" in check_budget(rule, **{**ok, "added_this_refresh": 2})
    assert "daily budget" in check_budget(rule, **{**ok, "added_today": 5})
    assert "size budget" in check_budget(rule, **{**ok, "bytes_today": 950})
    assert "known size" in check_budget(rule, **{**ok, "size": None})
    unlimited = FeedRule(id=2, max_per_refresh=0, daily_count_budget=0)
    assert check_budget(unlimited, added_this_refresh=10 ** 6, added_today=10 ** 6, bytes_today=0, size=None) is None


def test_validate_rule_normalises():
    rule = validate_rule(FeedRule(feed_id=1, name="  My rule  ", include=" flac , FLAC,,vol ", exclude=["x", " "],
                                  min_size=0, max_size=10))
    assert rule.name == "My rule"
    assert rule.include == ["flac", "vol"] and rule.exclude == ["x"]
    assert rule.min_size is None and rule.max_size == 10


@pytest.mark.parametrize("kwargs, message", [
    (dict(regex="("), "not valid"),
    (dict(regex="a" * 501), "longer than"),
    (dict(include=["x" * 201]), "longer than"),
    (dict(include=[f"t{i}" for i in range(40)]), "at most"),
    (dict(min_size=10, max_size=5), "larger than the maximum"),
    (dict(max_size=-1), "whole numbers"),
    (dict(max_per_refresh=-1), "whole numbers"),
    (dict(daily_count_budget=True), "whole numbers"),
    (dict(destination="bad\x00path"), "destination"),
])
def test_validate_rule_rejects(kwargs, message):
    with pytest.raises(RuleError, match=message):
        validate_rule(FeedRule(feed_id=1, **kwargs))
