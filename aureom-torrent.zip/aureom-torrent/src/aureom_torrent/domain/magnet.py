"""Strict magnet-link parsing.

This parser validates and bounds user/feed supplied magnet links *before* they
reach the engine. It understands:

* ``xt=urn:btih:<40 hex | 32 base32>``  BitTorrent v1 info-hash
* ``xt=urn:btmh:1220<64 hex>``          BitTorrent v2 info-hash (SHA-256 multihash)
* several ``xt`` parameters (hybrid magnets carry both)
* ``dn`` display name, ``tr`` trackers, ``ws`` web seeds (BEP 19),
  ``x.pe`` peer addresses, ``so`` select-only (BEP 53), ``xs``/``as`` sources

Payment data is deliberately *not* part of magnet parsing: unknown parameters
are ignored and never acted upon.  Magnet generation is delegated to the engine
(see ``engine.interface.TorrentCodec.make_magnet``).
"""

from __future__ import annotations

import base64
import re
from dataclasses import dataclass, field
from urllib.parse import unquote_plus, urlsplit

from .identity import IdentityError, TorrentIdentity

MAX_MAGNET_LENGTH = 8192
MAX_TRACKERS = 64
MAX_WEB_SEEDS = 16
MAX_SOURCES = 8
MAX_PEERS = 32
MAX_PARAMS = 256
MAX_NAME_LENGTH = 255
MAX_URL_LENGTH = 2048

TRACKER_SCHEMES = ("http", "https", "udp")
WEB_SEED_SCHEMES = ("http", "https")

_CONTROL = re.compile(r"[\x00-\x1f\x7f]")
_HEX = re.compile(r"^[0-9a-fA-F]+$")
_PEER = re.compile(r"^(\[[0-9a-fA-F:.]+\]|[A-Za-z0-9.-]{1,253}):(\d{1,5})$")


class MagnetError(ValueError):
    """A magnet link that cannot be used; the message is safe to show to the user."""


@dataclass(frozen=True, slots=True)
class MagnetLink:
    identity: TorrentIdentity
    display_name: str | None = None
    trackers: tuple[str, ...] = ()
    web_seeds: tuple[str, ...] = ()
    sources: tuple[str, ...] = ()
    peers: tuple[tuple[str, int], ...] = ()
    select_only: tuple[int, ...] = ()
    ignored: tuple[str, ...] = field(default=())

    def canonical_uri(self) -> str:
        """A normalised magnet carrying only validated parameters."""
        from urllib.parse import quote

        parts = []
        if self.identity.v1:
            parts.append(f"xt=urn:btih:{self.identity.v1}")
        if self.identity.v2:
            parts.append(f"xt=urn:btmh:1220{self.identity.v2}")
        if self.display_name:
            parts.append("dn=" + quote(self.display_name, safe=""))
        parts += ["tr=" + quote(t, safe="") for t in self.trackers]
        parts += ["ws=" + quote(w, safe="") for w in self.web_seeds]
        parts += [f"x.pe={h}:{p}" for h, p in self.peers]
        return "magnet:?" + "&".join(parts)


def looks_like_magnet(text: str) -> bool:
    return text.strip()[:8].lower() == "magnet:?"


def _clean_name(raw: str) -> str | None:
    name = _CONTROL.sub("", raw).strip()
    # A display name is a label only; never let it look like a path.
    name = name.replace("/", "_").replace("\\", "_")
    if not name or name in (".", ".."):
        return None
    return name[:MAX_NAME_LENGTH]


def _check_url(raw: str, schemes: tuple[str, ...], what: str) -> str | None:
    """Return a validated URL, or None when it should be ignored."""
    url = raw.strip()
    if not url or len(url) > MAX_URL_LENGTH or _CONTROL.search(url):
        return None
    try:
        parts = urlsplit(url)
        _ = parts.port  # raises ValueError for a malformed port
    except ValueError:
        return None
    if parts.scheme.lower() not in schemes or not parts.hostname:
        return None
    return url


def _parse_xt(value: str) -> tuple[str, str] | None:
    """Return ("v1"|"v2", hex) for a supported exact-topic, else None."""
    lower = value.lower()
    if lower.startswith("urn:btih:"):
        digest = value[9:]
        if len(digest) == 40 and _HEX.match(digest):
            return "v1", digest.lower()
        if len(digest) == 32:
            try:
                raw = base64.b32decode(digest.upper())
            except Exception as exc:  # binascii.Error
                raise MagnetError("The v1 info-hash in this magnet link is not valid base32.") from exc
            return "v1", raw.hex()
        raise MagnetError(
            "The v1 info-hash in this magnet link must be 40 hexadecimal or 32 base32 characters."
        )
    if lower.startswith("urn:btmh:"):
        digest = value[9:]
        if not _HEX.match(digest):
            raise MagnetError("The v2 info-hash in this magnet link is not hexadecimal.")
        if not lower[9:].startswith("1220"):
            raise MagnetError("Only SHA-256 (1220…) v2 info-hashes are supported.")
        if len(digest) != 68:
            raise MagnetError("The v2 info-hash in this magnet link must be 64 hexadecimal characters.")
        return "v2", digest[4:].lower()
    return None


def parse_magnet(uri: str) -> MagnetLink:
    """Parse and validate a magnet link. Raises :class:`MagnetError` with a clear message."""
    if not isinstance(uri, str):
        raise MagnetError("A magnet link must be text.")
    uri = uri.strip()
    if len(uri) > MAX_MAGNET_LENGTH:
        raise MagnetError(
            f"This magnet link is too long ({len(uri)} characters; the limit is {MAX_MAGNET_LENGTH})."
        )
    if not looks_like_magnet(uri):
        raise MagnetError("This is not a magnet link (it must start with “magnet:?”).")
    if _CONTROL.search(uri):
        raise MagnetError("This magnet link contains control characters.")
    query = uri[8:]
    pairs = [p for p in query.split("&") if p]
    if len(pairs) > MAX_PARAMS:
        raise MagnetError("This magnet link has too many parameters.")

    v1: str | None = None
    v2: str | None = None
    name: str | None = None
    trackers: list[str] = []
    web_seeds: list[str] = []
    sources: list[str] = []
    peers: list[tuple[str, int]] = []
    select_only: list[int] = []
    ignored: list[str] = []

    for pair in pairs:
        key, sep, raw_value = pair.partition("=")
        if not sep:
            ignored.append(key[:32])
            continue
        key = key.lower()
        # "tr.1=" style numbered parameters are equivalent to the bare key.
        base_key = re.sub(r"\.\d+$", "", key)
        try:
            value = unquote_plus(raw_value, errors="strict")
        except UnicodeDecodeError as exc:
            raise MagnetError("This magnet link contains text that is not valid UTF-8.") from exc

        if base_key == "xt":
            parsed = _parse_xt(value)
            if parsed is None:
                ignored.append("xt:" + value[:24])
                continue
            kind, digest = parsed
            if kind == "v1":
                if v1 is not None and v1 != digest:
                    raise MagnetError("This magnet link names two different v1 info-hashes.")
                v1 = digest
            else:
                if v2 is not None and v2 != digest:
                    raise MagnetError("This magnet link names two different v2 info-hashes.")
                v2 = digest
        elif base_key == "dn":
            name = name or _clean_name(value)
        elif base_key == "tr":
            url = _check_url(value, TRACKER_SCHEMES, "tracker")
            if url is None:
                ignored.append("tr")
            elif url not in trackers and len(trackers) < MAX_TRACKERS:
                trackers.append(url)
        elif base_key == "ws":
            url = _check_url(value, WEB_SEED_SCHEMES, "web seed")
            if url is None:
                ignored.append("ws")
            elif url not in web_seeds and len(web_seeds) < MAX_WEB_SEEDS:
                web_seeds.append(url)
        elif base_key in ("xs", "as"):
            url = _check_url(value, WEB_SEED_SCHEMES, "source")
            if url is None:
                ignored.append(base_key)
            elif url not in sources and len(sources) < MAX_SOURCES:
                sources.append(url)
        elif key == "x.pe":
            m = _PEER.match(value.strip())
            if m and 0 < int(m.group(2)) < 65536 and len(peers) < MAX_PEERS:
                peers.append((m.group(1).strip("[]"), int(m.group(2))))
            else:
                ignored.append("x.pe")
        elif key == "so":
            select_only = _parse_select_only(value)
        else:
            ignored.append(key[:32])

    if v1 is None and v2 is None:
        raise MagnetError(
            "This magnet link has no BitTorrent info-hash (expected xt=urn:btih:… or xt=urn:btmh:…)."
        )
    try:
        identity = TorrentIdentity(v1, v2)
    except IdentityError as exc:  # pragma: no cover - guarded above
        raise MagnetError(str(exc)) from exc
    return MagnetLink(
        identity=identity,
        display_name=name,
        trackers=tuple(trackers),
        web_seeds=tuple(web_seeds),
        sources=tuple(sources),
        peers=tuple(peers),
        select_only=tuple(select_only),
        ignored=tuple(ignored[:32]),
    )


def _parse_select_only(value: str) -> list[int]:
    """BEP 53 ``so=0,2,4-6``. Malformed or oversized selections are ignored."""
    out: list[int] = []
    for part in value.split(","):
        part = part.strip()
        if not part:
            continue
        lo, sep, hi = part.partition("-")
        if not lo.isdigit() or (sep and not hi.isdigit()):
            return []
        a, b = int(lo), int(hi) if sep else int(lo)
        if b < a or b - a > 10_000 or b > 1_000_000:
            return []
        out.extend(range(a, b + 1))
        if len(out) > 10_000:
            return []
    return sorted(set(out))
