"""Mapping from engine status + user intent to the application's lifecycle state.

The mapping is a pure function so it can be unit-tested exhaustively.  The key
guarantees:

* a transfer is only ever shown as complete when the engine reports that its
  selected files are complete (``is_finished``); a stalled download stays
  ``DOWNLOADING`` with a "stalled" detail;
* a manual pause is distinguishable from engine queueing;
* an error always wins.
"""

from __future__ import annotations

from .transfers import EnginePhase, TorrentStatus, TransferState


def derive_state(status: TorrentStatus, *, manual_paused: bool, stopped_by_limit: bool = False,
                 preview: bool = False) -> tuple[TransferState, str]:
    """Return ``(state, detail)`` for a live engine status."""
    if status.error:
        detail = status.error
        if status.error_file:
            detail = f"{status.error} ({status.error_file})"
        return TransferState.ERROR, detail

    if status.moving_storage:
        return TransferState.MOVING, "Moving files to the new destination"

    checking = status.phase in (EnginePhase.CHECKING_FILES, EnginePhase.CHECKING_RESUME)
    stopped = status.paused and not status.auto_managed

    if not status.has_metadata:
        if stopped:
            return TransferState.PAUSED, "Paused before metadata was retrieved"
        if status.paused:
            return TransferState.QUEUED, "Waiting to retrieve metadata"
        return TransferState.RETRIEVING_METADATA, "Asking peers for the torrent metadata"

    if preview:
        return TransferState.PAUSED, "Metadata retrieved — waiting for your review"

    if checking:
        if status.paused and status.auto_managed:
            return TransferState.QUEUED, "Queued for checking"
        if stopped:
            return TransferState.PAUSED, "Paused while checking"
        pct = status.checking_progress_ppm / 10_000
        return TransferState.CHECKING, f"Verifying existing data ({pct:.1f}%)"

    if stopped:
        if status.is_finished:
            if stopped_by_limit:
                return TransferState.COMPLETED, "Seeding limit reached"
            return TransferState.COMPLETED, "Stopped by you" if manual_paused else "Stopped"
        return TransferState.PAUSED, "Paused by you" if manual_paused else "Paused"

    if status.session_paused:
        return TransferState.QUEUED, "All transfers are paused by the bandwidth schedule"

    if status.paused and status.auto_managed:
        if status.is_finished:
            return TransferState.QUEUED, "Queued for seeding"
        return TransferState.QUEUED, "Queued for download"

    if status.is_finished and status.total_wanted <= 0:
        return TransferState.PAUSED, "No files are selected — choose files to download"

    if status.is_finished:
        if status.is_seeding:
            return TransferState.SEEDING, "Seeding the complete torrent"
        return TransferState.SEEDING, "Seeding the selected files"

    if status.upload_mode:
        return TransferState.ERROR, "The engine stopped requesting data after a storage error"

    if status.download_rate <= 0:
        if status.num_peers <= 0:
            return TransferState.DOWNLOADING, "Stalled — no peers connected"
        return TransferState.DOWNLOADING, "Stalled — connected peers are not sending data"
    return TransferState.DOWNLOADING, ""


def eta_seconds(status: TorrentStatus, state: TransferState) -> int | None:
    """Estimated time remaining, only when it is meaningful."""
    if state is not TransferState.DOWNLOADING or status.download_rate < 1024:
        return None
    remaining = status.total_wanted - status.wanted_done
    if remaining <= 0:
        return None
    eta = remaining // status.download_rate
    return int(eta) if eta < 100 * 24 * 3600 else None


def ratio_permille(uploaded: int, downloaded: int, size: int) -> int | None:
    """Share ratio ×1000. Uses the selected size when nothing was downloaded (e.g. a created torrent)."""
    base = downloaded if downloaded > 0 else size
    if base <= 0:
        return None
    return uploaded * 1000 // base
