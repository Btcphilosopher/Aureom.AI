"""Torrent identity: v1 (SHA-1) and/or v2 (SHA-256) info-hashes.

A hybrid torrent has both. Two identities refer to the same torrent when they
share either hash, which is how duplicates are detected across a v1 magnet, a
v2 magnet and a hybrid .torrent file describing the same content.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

_HEX40 = re.compile(r"^[0-9a-f]{40}$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")


class IdentityError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class TorrentIdentity:
    v1: str | None = None
    v2: str | None = None

    def __post_init__(self) -> None:
        v1 = self.v1.lower() if self.v1 else None
        v2 = self.v2.lower() if self.v2 else None
        if v1 is not None and not _HEX40.match(v1):
            raise IdentityError("v1 info-hash must be 40 hexadecimal characters")
        if v2 is not None and not _HEX64.match(v2):
            raise IdentityError("v2 info-hash must be 64 hexadecimal characters")
        if v1 is None and v2 is None:
            raise IdentityError("a torrent identity needs a v1 or v2 info-hash")
        object.__setattr__(self, "v1", v1)
        object.__setattr__(self, "v2", v2)

    @property
    def kind(self) -> str:
        if self.v1 and self.v2:
            return "hybrid"
        return "v2" if self.v2 else "v1"

    @property
    def primary(self) -> str:
        """A stable display/lookup key (v1 preferred because trackers and most tools show it)."""
        return self.v1 or self.v2  # type: ignore[return-value]

    def matches(self, other: "TorrentIdentity") -> bool:
        """True when both identities can refer to the same torrent."""
        if self.v1 and other.v1 and self.v1 == other.v1:
            return True
        if self.v2 and other.v2 and self.v2 == other.v2:
            return True
        return False

    def conflicts(self, other: "TorrentIdentity") -> bool:
        """True when the identities share one hash but disagree on the other."""
        if not self.matches(other):
            return False
        if self.v1 and other.v1 and self.v1 != other.v1:
            return True
        if self.v2 and other.v2 and self.v2 != other.v2:
            return True
        return False

    def merged(self, other: "TorrentIdentity") -> "TorrentIdentity":
        """Union of the known hashes (used when metadata reveals a hybrid torrent)."""
        if self.conflicts(other):
            raise IdentityError("identities disagree and cannot be merged")
        return TorrentIdentity(self.v1 or other.v1, self.v2 or other.v2)

    def short(self) -> str:
        return self.primary[:12]
