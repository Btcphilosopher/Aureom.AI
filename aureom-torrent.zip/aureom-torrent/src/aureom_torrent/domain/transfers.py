"""Engine-neutral transfer models shared by the engine adapter, services and UI."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field, replace
from typing import Any

from .identity import TorrentIdentity


class TransferState(str, enum.Enum):
    ADDED = "added"
    RETRIEVING_METADATA = "retrieving_metadata"
    QUEUED = "queued"
    CHECKING = "checking"
    DOWNLOADING = "downloading"
    SEEDING = "seeding"
    PAUSED = "paused"
    MOVING = "moving"
    COMPLETED = "completed"  # completed and stopped
    ERROR = "error"

    @property
    def label(self) -> str:
        return _STATE_LABELS[self]


_STATE_LABELS = {
    TransferState.ADDED: "Added",
    TransferState.RETRIEVING_METADATA: "Retrieving metadata",
    TransferState.QUEUED: "Queued",
    TransferState.CHECKING: "Checking existing data",
    TransferState.DOWNLOADING: "Downloading",
    TransferState.SEEDING: "Seeding",
    TransferState.PAUSED: "Paused",
    TransferState.MOVING: "Moving storage",
    TransferState.COMPLETED: "Completed (stopped)",
    TransferState.ERROR: "Error",
}


class EnginePhase(str, enum.Enum):
    """What the engine itself reports it is doing, before pause/queue flags are applied."""

    CHECKING_RESUME = "checking_resume_data"
    CHECKING_FILES = "checking_files"
    DOWNLOADING_METADATA = "downloading_metadata"
    DOWNLOADING = "downloading"
    FINISHED = "finished"  # all *selected* files complete
    SEEDING = "seeding"  # the *entire* torrent complete
    UNKNOWN = "unknown"


class FilePriority(enum.IntEnum):
    SKIP = 0
    LOW = 1
    NORMAL = 4
    HIGH = 7


@dataclass(frozen=True, slots=True)
class TorrentFile:
    index: int
    path: str  # relative, forward slashes, as stored in the metadata
    size: int
    pad: bool = False


@dataclass(frozen=True, slots=True)
class TorrentMetadata:
    """Everything the application needs to know about a torrent's info dictionary."""

    identity: TorrentIdentity
    name: str
    total_size: int
    piece_length: int
    num_pieces: int
    files: tuple[TorrentFile, ...]
    private: bool = False
    trackers: tuple[tuple[str, int], ...] = ()  # (url, tier)
    web_seeds: tuple[str, ...] = ()
    comment: str = ""
    creator: str = ""
    creation_date: int | None = None
    path_problems: tuple[str, ...] = ()
    # Raw publisher manifest found inside the info dictionary (bound to the info-hash), if any.
    embedded_manifest: bytes = b""

    @property
    def real_files(self) -> tuple[TorrentFile, ...]:
        return tuple(f for f in self.files if not f.pad)


@dataclass(frozen=True, slots=True)
class TorrentStatus:
    """A point-in-time engine status for one transfer.

    Byte counters follow the engine's piece-verified semantics: ``wanted_done``
    only counts bytes in pieces that passed their hash check, for pieces that
    belong to selected files.
    """

    transfer_id: str
    phase: EnginePhase = EnginePhase.UNKNOWN
    paused: bool = False
    auto_managed: bool = True
    session_paused: bool = False
    has_metadata: bool = False
    moving_storage: bool = False
    is_finished: bool = False  # selected files complete
    is_seeding: bool = False  # entire torrent complete
    upload_mode: bool = False
    error: str = ""
    error_file: str = ""
    name: str = ""
    save_path: str = ""
    total: int = 0
    total_wanted: int = 0
    wanted_done: int = 0  # verified bytes of selected data
    total_done: int = 0  # verified bytes of all data
    pieces_total: int = 0
    pieces_have: int = 0
    download_rate: int = 0
    upload_rate: int = 0
    all_time_download: int = 0
    all_time_upload: int = 0
    num_peers: int = 0
    num_seeds: int = 0
    list_peers: int = 0
    queue_position: int = -1
    seeding_seconds: int = 0
    active_seconds: int = 0
    checking_progress_ppm: int = 0
    next_announce_s: int = 0
    current_tracker: str = ""
    identity: TorrentIdentity | None = None

    @property
    def progress_ppm(self) -> int:
        """Verified progress of the selected files, parts per million."""
        if not self.has_metadata or self.total_wanted <= 0:
            return 0  # nothing selected (or nothing known) is never shown as progress
        if self.is_finished:
            return 1_000_000
        ppm = self.wanted_done * 1_000_000 // self.total_wanted
        # Never round an unfinished transfer up to 100 %.
        return min(ppm, 999_999)


@dataclass(slots=True)
class TransferRecord:
    """The persisted description of a transfer (user intent + last known facts)."""

    id: str
    identity: TorrentIdentity
    name: str
    save_path: str
    category: str = ""
    added_at: int = 0
    completed_at: int | None = None
    source: str = "file"  # file | magnet | feed | created
    magnet_uri: str | None = None
    has_metadata: bool = False
    preview: bool = False  # metadata-only magnet preview, not yet confirmed by the user
    manual_paused: bool = False
    stopped_by_limit: bool = False
    download_limit: int = 0  # bytes/s, 0 = unlimited
    upload_limit: int = 0
    ratio_limit_permille: int | None = None  # None = global setting, -1 = unlimited
    seed_time_limit_s: int | None = None
    file_priorities: list[int] = field(default_factory=list)
    total_size: int = 0
    private: bool = False
    last_state: TransferState = TransferState.ADDED
    last_progress_ppm: int = 0
    downloaded_total: int = 0
    uploaded_total: int = 0
    seeding_seconds: int = 0
    last_error: str = ""
    last_announce: dict[str, Any] = field(default_factory=dict)
    manifest_id: str | None = None
    feed_entry_id: int | None = None

    def copy(self) -> "TransferRecord":
        return replace(self, file_priorities=list(self.file_priorities), last_announce=dict(self.last_announce))


@dataclass(frozen=True, slots=True)
class TransferView:
    """One row of the main transfer table. Immutable; produced off the GUI thread."""

    id: str
    name: str
    identity: TorrentIdentity
    state: TransferState
    state_detail: str
    size: int  # selected size when known, else total
    total_size: int
    progress_ppm: int
    selected_complete: bool
    torrent_complete: bool
    download_rate: int
    upload_rate: int
    peers: int
    seeds: int
    ratio_permille: int | None
    eta_seconds: int | None
    category: str
    save_path: str
    added_at: int
    has_metadata: bool
    private: bool
    preview: bool
    manual_paused: bool
    error: str
    downloaded: int
    uploaded: int
    pieces_have: int
    pieces_total: int
    seeding_seconds: int
    last_announce: dict[str, Any]
    source: str
    live: bool  # False until the engine has reported on this transfer in this run


@dataclass(frozen=True, slots=True)
class PeerView:
    address: str
    client: str
    progress_ppm: int
    download_rate: int
    upload_rate: int
    flags: str
    source: str
    connection: str


@dataclass(frozen=True, slots=True)
class TrackerView:
    url: str  # already redacted for display where needed
    tier: int
    status: str
    message: str
    seeds: int
    leeches: int
    next_announce_s: int
    fails: int


@dataclass(frozen=True, slots=True)
class FileView:
    index: int
    path: str
    size: int
    done: int
    priority: int
    pad: bool = False


@dataclass(frozen=True, slots=True)
class TransferDetails:
    transfer_id: str
    peers: tuple[PeerView, ...] = ()
    trackers: tuple[TrackerView, ...] = ()
    files: tuple[FileView, ...] = ()
    pieces: bytes = b""  # one byte per piece: 0 missing, 1 have
    web_seeds: tuple[str, ...] = ()
