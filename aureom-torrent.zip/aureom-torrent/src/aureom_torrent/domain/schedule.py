"""Queue policy helpers: bandwidth schedules and seeding limits (pure functions)."""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from ..settings.models import BandwidthSchedule, QueueSettings
from .transfers import TorrentStatus, TransferRecord


@dataclass(frozen=True, slots=True)
class BandwidthPlan:
    download_limit: int  # bytes/s, 0 = unlimited
    upload_limit: int
    pause_all: bool
    schedule_name: str = ""  # "" = no schedule active


def _matches(schedule: BandwidthSchedule, when: _dt.datetime) -> bool:
    if not schedule.enabled or not schedule.days:
        return False
    minute = when.hour * 60 + when.minute
    today = when.weekday()
    start, end = schedule.start_minute, schedule.end_minute
    if start == end:
        return today in schedule.days  # whole day
    if start < end:
        return today in schedule.days and start <= minute < end
    # wraps past midnight: the early-morning part belongs to the previous day's schedule
    if minute >= start:
        return today in schedule.days
    return (today - 1) % 7 in schedule.days and minute < end


def bandwidth_plan(queue: QueueSettings, when: _dt.datetime) -> BandwidthPlan:
    """The first enabled schedule that covers ``when`` wins; otherwise the global limits apply."""
    for schedule in queue.schedules:
        if _matches(schedule, when):
            return BandwidthPlan(schedule.download_limit, schedule.upload_limit, schedule.pause_all,
                                 schedule.name or "schedule")
    return BandwidthPlan(queue.download_limit, queue.upload_limit, False, "")


def seeding_limit_reached(record: TransferRecord, status: TorrentStatus, queue: QueueSettings) -> str | None:
    """Return a human-readable reason when this seeding transfer should stop, else None.

    Per-transfer limits override the global ones; ``-1`` means unlimited.
    Only meaningful once the selected files are complete.
    """
    if not status.is_finished or status.total_wanted <= 0:
        return None
    ratio_limit = record.ratio_limit_permille if record.ratio_limit_permille is not None else queue.ratio_limit_permille
    time_limit_s = record.seed_time_limit_s if record.seed_time_limit_s is not None else (
        queue.seed_time_limit_minutes * 60 if queue.seed_time_limit_minutes >= 0 else -1)
    if ratio_limit is not None and ratio_limit >= 0:
        base = status.all_time_download if status.all_time_download > 0 else status.total_wanted
        if base > 0 and status.all_time_upload * 1000 >= ratio_limit * base:
            return f"share ratio {ratio_limit / 1000:.2f} reached"
    if time_limit_s is not None and time_limit_s >= 0 and status.seeding_seconds >= time_limit_s:
        return f"seeding time limit of {time_limit_s // 60} min reached"
    return None
