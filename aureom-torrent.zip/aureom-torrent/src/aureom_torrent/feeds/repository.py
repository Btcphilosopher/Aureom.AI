"""SQLite persistence for feeds, entries, de-duplication history, rules and budgets."""

from __future__ import annotations

import json
import sqlite3
from typing import Any, Iterable, Sequence

from ..persistence.database import Database
from .dedup import DedupKey
from .models import (STATUS_REVIEW, Feed, FeedEntry, FeedRule, ParsedEntry, RuleLogRow)

RULE_LOG_LIMIT = 2000
BUDGET_DAYS_KEPT = 14

_FEED_COLUMNS = {"url", "title", "site_url", "folder", "category", "interval_minutes", "auto_download",
                 "download_existing", "baseline_done", "etag", "last_modified", "last_checked", "last_success",
                 "next_check", "fail_count", "last_status", "last_error"}

_OUTCOME_RANK = {"seen": 0, "baseline": 1, "duplicate": 2, "review": 3, "dismissed": 4, "added": 5}


def _like(text: str) -> str:
    return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


class FeedRepository:
    def __init__(self, db: Database):
        self.db = db

    # -- feeds ----------------------------------------------------------------
    _FEED_SELECT = (
        "SELECT f.*, "
        " (SELECT COUNT(*) FROM feed_entries e WHERE e.feed_id = f.id) AS entry_count, "
        " (SELECT COUNT(*) FROM feed_entries e WHERE e.feed_id = f.id AND e.is_read = 0) AS unread_count, "
        " (SELECT COUNT(*) FROM feed_entries e WHERE e.feed_id = f.id AND e.status = 'review') AS review_count "
        "FROM feeds f "
    )

    @staticmethod
    def _feed(row: sqlite3.Row) -> Feed:
        return Feed(
            id=row["id"], url=row["url"], title=row["title"], site_url=row["site_url"], folder=row["folder"],
            category=row["category"], interval_minutes=row["interval_minutes"],
            auto_download=bool(row["auto_download"]), download_existing=bool(row["download_existing"]),
            baseline_done=bool(row["baseline_done"]), etag=row["etag"], last_modified=row["last_modified"],
            created_at=row["created_at"], last_checked=row["last_checked"], last_success=row["last_success"],
            next_check=row["next_check"], fail_count=row["fail_count"], last_status=row["last_status"],
            last_error=row["last_error"], unread_count=row["unread_count"], entry_count=row["entry_count"],
            review_count=row["review_count"],
        )

    def insert_feed(self, *, url: str, title: str, folder: str, category: str, interval_minutes: int,
                    download_existing: bool, now: int) -> int:
        cur = self.db.execute(
            "INSERT INTO feeds(url, title, folder, category, interval_minutes, download_existing, created_at,"
            " next_check) VALUES (?,?,?,?,?,?,?,0)",
            (url, title, folder, category, interval_minutes, int(download_existing), now))
        return int(cur.lastrowid)

    def get_feed(self, feed_id: int) -> Feed | None:
        row = self.db.query_one(self._FEED_SELECT + "WHERE f.id = ?", (feed_id,))
        return self._feed(row) if row else None

    def get_feed_by_url(self, url: str) -> Feed | None:
        row = self.db.query_one(self._FEED_SELECT + "WHERE f.url = ?", (url,))
        return self._feed(row) if row else None

    def list_feeds(self) -> list[Feed]:
        rows = self.db.query(self._FEED_SELECT + "ORDER BY f.folder COLLATE NOCASE, f.title COLLATE NOCASE, f.id")
        return [self._feed(r) for r in rows]

    def due_feeds(self, now: int, limit: int) -> list[Feed]:
        rows = self.db.query(self._FEED_SELECT + "WHERE f.next_check <= ? ORDER BY f.next_check, f.id LIMIT ?",
                             (now, limit))
        return [self._feed(r) for r in rows]

    def update_feed(self, feed_id: int, **fields: Any) -> None:
        unknown = set(fields) - _FEED_COLUMNS
        if unknown:
            raise ValueError(f"unknown feed columns: {sorted(unknown)}")
        if not fields:
            return
        assignments = ", ".join(f"{name} = ?" for name in fields)
        values = [int(v) if isinstance(v, bool) else v for v in fields.values()]
        self.db.execute(f"UPDATE feeds SET {assignments} WHERE id = ?", (*values, feed_id))

    def delete_feed(self, feed_id: int) -> None:
        with self.db.tx() as conn:
            conn.execute("DELETE FROM feed_budget WHERE rule_id IN (SELECT id FROM feed_rules WHERE feed_id = ?)",
                         (feed_id,))
            conn.execute("DELETE FROM feed_rule_log WHERE feed_id = ?", (feed_id,))
            # Feed-scoped history is meaningless without the feed; global keys (torrent identity,
            # enclosure URL) are kept so that already-handled items stay handled.
            conn.execute("DELETE FROM feed_seen WHERE feed_id = ?", (feed_id,))
            conn.execute("UPDATE feed_seen SET entry_id = NULL WHERE entry_id IN "
                         "(SELECT id FROM feed_entries WHERE feed_id = ?)", (feed_id,))
            conn.execute("DELETE FROM feeds WHERE id = ?", (feed_id,))  # cascades to entries and rules

    # -- entries --------------------------------------------------------------
    _ENTRY_SELECT = ("SELECT e.*, f.title AS feed_title, f.url AS feed_url FROM feed_entries e "
                     "JOIN feeds f ON f.id = e.feed_id ")

    @staticmethod
    def _entry(row: sqlite3.Row) -> FeedEntry:
        return FeedEntry(
            id=row["id"], feed_id=row["feed_id"], guid=row["guid"], link=row["link"], title=row["title"],
            publisher=row["publisher"], published=row["published"], summary_html=row["summary_html"],
            summary_text=row["summary_text"], link_type=row["link_type"], torrent_url=row["torrent_url"],
            magnet=row["magnet"], v1=row["v1"], v2=row["v2"], size=row["size"],
            size_trusted=bool(row["size_trusted"]), read=bool(row["is_read"]), status=row["status"],
            status_reason=row["status_reason"], transfer_id=row["transfer_id"], rule_id=row["rule_id"],
            first_seen=row["first_seen"], updated_at=row["updated_at"],
            feed_title=row["feed_title"] or row["feed_url"],
        )

    def insert_entry(self, feed_id: int, e: ParsedEntry, *, status: str, read: bool, now: int) -> int:
        cur = self.db.execute(
            "INSERT INTO feed_entries(feed_id, guid, link, title, publisher, published, summary_html, summary_text,"
            " link_type, torrent_url, magnet, v1, v2, size, size_trusted, is_read, status, first_seen, updated_at)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?,?)",
            (feed_id, e.guid, e.link, e.title, e.publisher, e.published, e.summary_html, e.summary_text,
             e.link_type, e.torrent_url, e.magnet, e.v1, e.v2, e.size, int(read), status, now, now))
        return int(cur.lastrowid)

    def update_entry_content(self, entry_id: int, e: ParsedEntry, *, now: int) -> bool:
        """Refresh the descriptive fields of a known entry. User state (read flag, status,
        linked transfer) and metadata-derived facts (trusted size) are left alone."""
        row = self.db.query_one(
            "SELECT guid, link, title, publisher, published, summary_html, link_type, torrent_url, magnet,"
            " size_trusted, size, v1, v2 FROM feed_entries WHERE id = ?", (entry_id,))
        if row is None:
            return False
        trusted = bool(row["size_trusted"])
        new_size = row["size"] if trusted else e.size
        new_v1 = row["v1"] or e.v1
        new_v2 = row["v2"] or e.v2
        current = (row["guid"], row["link"], row["title"], row["publisher"], row["published"],
                   row["summary_html"], row["link_type"], row["torrent_url"], row["magnet"], row["size"],
                   row["v1"], row["v2"])
        updated = (e.guid, e.link, e.title, e.publisher, e.published if e.published is not None else row["published"],
                   e.summary_html, e.link_type, e.torrent_url, e.magnet, new_size, new_v1, new_v2)
        if current == updated:
            return False
        self.db.execute(
            "UPDATE feed_entries SET guid=?, link=?, title=?, publisher=?, published=?, summary_html=?,"
            " summary_text=?, link_type=?, torrent_url=?, magnet=?, size=?, v1=?, v2=?, updated_at=? WHERE id=?",
            (updated[0], updated[1], updated[2], updated[3], updated[4], updated[5], e.summary_text, updated[6],
             updated[7], updated[8], new_size, new_v1, new_v2, now, entry_id))
        return True

    def get_entry(self, entry_id: int) -> FeedEntry | None:
        row = self.db.query_one(self._ENTRY_SELECT + "WHERE e.id = ?", (entry_id,))
        return self._entry(row) if row else None

    def list_entries(self, *, feed_id: int | None = None, folder: str | None = None, unread_only: bool = False,
                     search: str = "", link_type: str | None = None, status: str | None = None,
                     limit: int = 200, offset: int = 0) -> list[FeedEntry]:
        where: list[str] = []
        params: list[Any] = []
        if feed_id is not None:
            where.append("e.feed_id = ?")
            params.append(feed_id)
        if folder is not None:
            where.append("(f.folder = ? OR f.folder LIKE ? ESCAPE '\\')")
            params += [folder, _like(folder + "/")[1:]]
        if unread_only:
            where.append("e.is_read = 0")
        if link_type:
            where.append("e.link_type = ?")
            params.append(link_type)
        if status:
            where.append("e.status = ?")
            params.append(status)
        for word in search.split()[:8]:
            pattern = _like(word[:100])
            where.append("(e.title LIKE ? ESCAPE '\\' OR e.publisher LIKE ? ESCAPE '\\' "
                         "OR e.summary_text LIKE ? ESCAPE '\\')")
            params += [pattern, pattern, pattern]
        sql = self._ENTRY_SELECT
        if where:
            sql += "WHERE " + " AND ".join(where) + " "
        sql += "ORDER BY COALESCE(e.published, e.first_seen) DESC, e.id DESC LIMIT ? OFFSET ?"
        params += [max(1, min(int(limit), 1000)), max(0, int(offset))]
        return [self._entry(r) for r in self.db.query(sql, params)]

    def entries_for_feed(self, feed_id: int, statuses: Sequence[str] | None = None, limit: int = 1000) -> list[FeedEntry]:
        sql = self._ENTRY_SELECT + "WHERE e.feed_id = ? "
        params: list[Any] = [feed_id]
        if statuses:
            sql += f"AND e.status IN ({','.join('?' * len(statuses))}) "
            params += list(statuses)
        sql += "ORDER BY COALESCE(e.published, e.first_seen) DESC, e.id DESC LIMIT ?"
        params.append(limit)
        return [self._entry(r) for r in self.db.query(sql, params)]

    def set_read(self, entry_ids: Iterable[int], read: bool) -> int:
        ids = [int(i) for i in entry_ids]
        changed = 0
        with self.db.tx() as conn:
            for start in range(0, len(ids), 500):
                chunk = ids[start:start + 500]
                cur = conn.execute(
                    f"UPDATE feed_entries SET is_read = ? WHERE id IN ({','.join('?' * len(chunk))})",
                    (int(read), *chunk))
                changed += cur.rowcount
        return changed

    def mark_all_read(self, feed_id: int | None) -> int:
        if feed_id is None:
            return self.db.execute("UPDATE feed_entries SET is_read = 1 WHERE is_read = 0").rowcount
        return self.db.execute("UPDATE feed_entries SET is_read = 1 WHERE is_read = 0 AND feed_id = ?",
                               (feed_id,)).rowcount

    def set_entry_status(self, entry_id: int, status: str, reason: str = "", *, transfer_id: str | None = None,
                         rule_id: int | None = None, now: int = 0) -> None:
        self.db.execute(
            "UPDATE feed_entries SET status = ?, status_reason = ?, transfer_id = COALESCE(?, transfer_id),"
            " rule_id = COALESCE(?, rule_id), updated_at = ? WHERE id = ?",
            (status, reason[:500], transfer_id, rule_id, now, entry_id))

    def set_entry_metadata(self, entry_id: int, *, size: int | None, v1: str | None, v2: str | None) -> None:
        """Record facts learned from fetched torrent metadata (these are trustworthy)."""
        self.db.execute(
            "UPDATE feed_entries SET size = COALESCE(?, size), size_trusted = CASE WHEN ? IS NULL THEN size_trusted"
            " ELSE 1 END, v1 = COALESCE(?, v1), v2 = COALESCE(?, v2) WHERE id = ?",
            (size, size, v1, v2, entry_id))

    def prune_entries(self, feed_id: int, keep: int) -> int:
        """Delete the oldest entries beyond ``keep`` (never ones waiting for review)."""
        cur = self.db.execute(
            "DELETE FROM feed_entries WHERE feed_id = ? AND status != ? AND id NOT IN ("
            " SELECT id FROM feed_entries WHERE feed_id = ?"
            " ORDER BY COALESCE(published, first_seen) DESC, id DESC LIMIT ?)",
            (feed_id, STATUS_REVIEW, feed_id, keep))
        return cur.rowcount

    def entry_counts(self) -> dict[str, int]:
        rows = self.db.query("SELECT status, COUNT(*) AS n FROM feed_entries GROUP BY status")
        return {r["status"]: r["n"] for r in rows}

    # -- de-duplication history -------------------------------------------------
    def lookup_seen(self, keys: Sequence[str]) -> dict[str, sqlite3.Row]:
        if not keys:
            return {}
        rows = self.db.query(
            f"SELECT * FROM feed_seen WHERE key IN ({','.join('?' * len(keys))})", list(keys))
        return {r["key"]: r for r in rows}

    def record_seen(self, keys: Sequence[DedupKey], *, feed_id: int, entry_id: int | None, outcome: str,
                    now: int, transfer_id: str | None = None) -> None:
        """Insert or refresh history rows. An outcome is only ever upgraded
        (seen < baseline < duplicate < review < dismissed < added)."""
        if not keys:
            return
        existing = self.lookup_seen([k.key for k in keys])
        with self.db.tx() as conn:
            for k in keys:
                row = existing.get(k.key)
                scope_feed = feed_id if k.feed_scoped else None
                if row is None:
                    conn.execute(
                        "INSERT INTO feed_seen(key, feed_id, entry_id, first_seen, last_seen, outcome, transfer_id)"
                        " VALUES (?,?,?,?,?,?,?)",
                        (k.key, scope_feed, entry_id, now, now, outcome, transfer_id))
                    continue
                new_outcome = outcome if _OUTCOME_RANK.get(outcome, 0) > _OUTCOME_RANK.get(row["outcome"], 0) \
                    else row["outcome"]
                # A feed-scoped key always points at its entry; a global key keeps its first owner
                # unless that entry is gone.
                new_entry = entry_id if (k.feed_scoped or row["entry_id"] is None) else row["entry_id"]
                conn.execute(
                    "UPDATE feed_seen SET last_seen = ?, outcome = ?, entry_id = ?,"
                    " transfer_id = COALESCE(?, transfer_id) WHERE key = ?",
                    (now, new_outcome, new_entry, transfer_id, k.key))

    def prune_seen(self, cutoff: int) -> int:
        """Forget passive history that has not appeared in any feed since ``cutoff``.
        Rows recording a user-visible decision (added / dismissed / review) are kept."""
        return self.db.execute(
            "DELETE FROM feed_seen WHERE last_seen < ? AND outcome IN ('seen', 'baseline', 'duplicate')",
            (cutoff,)).rowcount

    def entry_exists(self, entry_id: int) -> bool:
        return self.db.query_one("SELECT 1 FROM feed_entries WHERE id = ?", (entry_id,)) is not None

    # -- rules ------------------------------------------------------------------
    @staticmethod
    def _rule(row: sqlite3.Row) -> FeedRule:
        def terms(raw: str) -> list[str]:
            try:
                value = json.loads(raw)
            except ValueError:
                return []
            return [str(t) for t in value if isinstance(t, str)] if isinstance(value, list) else []

        return FeedRule(
            id=row["id"], feed_id=row["feed_id"], name=row["name"], enabled=bool(row["enabled"]),
            include=terms(row["include_terms"]), exclude=terms(row["exclude_terms"]), regex=row["regex"],
            category=row["category"], destination=row["destination"], min_size=row["min_size"],
            max_size=row["max_size"], max_per_refresh=row["max_per_refresh"],
            daily_count_budget=row["daily_count_budget"], daily_bytes_budget=row["daily_bytes_budget"],
            add_paused=bool(row["add_paused"]), created_at=row["created_at"],
        )

    def list_rules(self, feed_id: int | None = None) -> list[FeedRule]:
        if feed_id is None:
            rows = self.db.query("SELECT * FROM feed_rules ORDER BY feed_id, id")
        else:
            rows = self.db.query("SELECT * FROM feed_rules WHERE feed_id = ? ORDER BY id", (feed_id,))
        return [self._rule(r) for r in rows]

    def get_rule(self, rule_id: int) -> FeedRule | None:
        row = self.db.query_one("SELECT * FROM feed_rules WHERE id = ?", (rule_id,))
        return self._rule(row) if row else None

    def save_rule(self, rule: FeedRule, now: int) -> int:
        values = (rule.feed_id, rule.name, int(rule.enabled), json.dumps(rule.include), json.dumps(rule.exclude),
                  rule.regex, rule.category, rule.destination, rule.min_size, rule.max_size, rule.max_per_refresh,
                  rule.daily_count_budget, rule.daily_bytes_budget, int(rule.add_paused))
        if rule.id is None:
            cur = self.db.execute(
                "INSERT INTO feed_rules(feed_id, name, enabled, include_terms, exclude_terms, regex, category,"
                " destination, min_size, max_size, max_per_refresh, daily_count_budget, daily_bytes_budget,"
                " add_paused, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (*values, now))
            return int(cur.lastrowid)
        self.db.execute(
            "UPDATE feed_rules SET feed_id=?, name=?, enabled=?, include_terms=?, exclude_terms=?, regex=?,"
            " category=?, destination=?, min_size=?, max_size=?, max_per_refresh=?, daily_count_budget=?,"
            " daily_bytes_budget=?, add_paused=? WHERE id=?", (*values, rule.id))
        return int(rule.id)

    def delete_rule(self, rule_id: int) -> None:
        with self.db.tx() as conn:
            conn.execute("DELETE FROM feed_budget WHERE rule_id = ?", (rule_id,))
            conn.execute("DELETE FROM feed_rules WHERE id = ?", (rule_id,))

    # -- rule log / budgets -------------------------------------------------------
    def add_log(self, *, ts: int, feed_id: int, rule_id: int | None, entry_id: int | None, title: str,
                action: str, reason: str) -> None:
        with self.db.tx() as conn:
            cur = conn.execute(
                "INSERT INTO feed_rule_log(ts, feed_id, rule_id, entry_id, entry_title, action, reason)"
                " VALUES (?,?,?,?,?,?,?)", (ts, feed_id, rule_id, entry_id, title[:200], action, reason[:500]))
            if cur.lastrowid and cur.lastrowid % 50 == 0:
                conn.execute("DELETE FROM feed_rule_log WHERE id <= ?", (cur.lastrowid - RULE_LOG_LIMIT,))

    def recent_log(self, limit: int = 100, feed_id: int | None = None) -> list[RuleLogRow]:
        if feed_id is None:
            rows = self.db.query("SELECT * FROM feed_rule_log ORDER BY id DESC LIMIT ?", (limit,))
        else:
            rows = self.db.query("SELECT * FROM feed_rule_log WHERE feed_id = ? ORDER BY id DESC LIMIT ?",
                                 (feed_id, limit))
        return [RuleLogRow(r["ts"], r["feed_id"], r["rule_id"], r["entry_id"], r["entry_title"], r["action"],
                           r["reason"]) for r in rows]

    def get_budget(self, day: str, rule_id: int) -> tuple[int, int]:
        row = self.db.query_one("SELECT added_count, added_bytes FROM feed_budget WHERE day = ? AND rule_id = ?",
                                (day, rule_id))
        return (row["added_count"], row["added_bytes"]) if row else (0, 0)

    def add_budget(self, day: str, rule_id: int, *, count: int, size: int) -> None:
        with self.db.tx() as conn:
            conn.execute(
                "INSERT INTO feed_budget(day, rule_id, added_count, added_bytes) VALUES (?,?,?,?)"
                " ON CONFLICT(day, rule_id) DO UPDATE SET added_count = added_count + excluded.added_count,"
                " added_bytes = added_bytes + excluded.added_bytes", (day, rule_id, count, size))
            conn.execute("DELETE FROM feed_budget WHERE day < date(?, ?)", (day, f"-{BUDGET_DAYS_KEPT} days"))
