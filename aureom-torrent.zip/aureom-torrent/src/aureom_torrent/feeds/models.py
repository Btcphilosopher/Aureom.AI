"""Plain data models for the RSS/Atom subsystem (no behaviour, no I/O)."""

from __future__ import annotations

from dataclasses import dataclass, field

LINK_TORRENT = "torrent"
LINK_MAGNET = "magnet"
LINK_NONE = "none"

# Entry statuses
STATUS_NEW = "new"  # seen after the baseline; nothing has been done with it
STATUS_BASELINE = "baseline"  # already in the feed when the subscription was created
STATUS_ADDED = "added"  # a transfer was created from it (manually or by a rule)
STATUS_DUPLICATE = "duplicate"  # refers to a transfer/item that was already handled
STATUS_REVIEW = "review"  # a rule matched but could not be applied safely; waiting for the user
STATUS_DISMISSED = "dismissed"  # the user dismissed it from the review queue

ENTRY_STATUSES = (STATUS_NEW, STATUS_BASELINE, STATUS_ADDED, STATUS_DUPLICATE, STATUS_REVIEW, STATUS_DISMISSED)


class FeedError(Exception):
    """A feed operation that failed. ``str(exc)`` is safe to show to the user."""


@dataclass(slots=True)
class Feed:
    id: int
    url: str
    title: str = ""
    site_url: str = ""
    folder: str = ""
    category: str = ""
    interval_minutes: int = 60
    auto_download: bool = False  # explicit per-feed opt-in for automation rules
    download_existing: bool = False  # user chose to treat the first refresh's entries as new
    baseline_done: bool = False
    etag: str = ""
    last_modified: str = ""
    created_at: int = 0
    last_checked: int | None = None
    last_success: int | None = None
    next_check: int = 0
    fail_count: int = 0
    last_status: str = "never"  # never | ok | not_modified | error
    last_error: str = ""
    unread_count: int = 0
    entry_count: int = 0
    review_count: int = 0

    @property
    def display_title(self) -> str:
        return self.title or self.url


@dataclass(slots=True)
class ParsedEntry:
    """One entry as normalised by the parser, before it is matched against stored history."""

    guid: str = ""
    link: str = ""
    title: str = ""
    publisher: str = ""
    published: int | None = None
    summary_html: str = ""
    summary_text: str = ""
    link_type: str = LINK_NONE
    torrent_url: str = ""
    magnet: str = ""
    v1: str | None = None
    v2: str | None = None
    size: int | None = None  # feed-reported; never trusted for limits


@dataclass(slots=True)
class ParsedFeed:
    title: str = ""
    site_url: str = ""
    format: str = ""  # e.g. rss20, atom10
    entries: list[ParsedEntry] = field(default_factory=list)
    warning: str = ""  # non-fatal parse problem (the feed was still usable)
    truncated: bool = False  # more entries than the per-feed limit


@dataclass(slots=True)
class FeedEntry:
    id: int
    feed_id: int
    guid: str = ""
    link: str = ""
    title: str = ""
    publisher: str = ""
    published: int | None = None
    summary_html: str = ""  # sanitised, restricted markup; safe to render as rich text
    summary_text: str = ""
    link_type: str = LINK_NONE  # torrent | magnet | none
    torrent_url: str = ""
    magnet: str = ""
    v1: str | None = None
    v2: str | None = None
    size: int | None = None
    size_trusted: bool = False  # True only when the size came from fetched torrent metadata
    read: bool = False
    status: str = STATUS_NEW
    status_reason: str = ""
    transfer_id: str | None = None
    rule_id: int | None = None
    first_seen: int = 0
    updated_at: int = 0
    feed_title: str = ""

    @property
    def size_label(self) -> str:
        """How the UI should qualify the size column."""
        if self.size is None:
            return "unknown"
        return "from torrent metadata" if self.size_trusted else "feed-reported"

    @property
    def can_add(self) -> bool:
        return self.link_type in (LINK_TORRENT, LINK_MAGNET)


@dataclass(slots=True)
class FeedRule:
    """An automatic-download rule. Applies only when its feed has auto-download enabled.

    Matching is done against the entry title, case-insensitively:
    every ``include`` term must be present, no ``exclude`` term may be present and,
    when set, ``regex`` must match.  A rule with no include terms and no regex
    matches every entry (subject to exclude terms and limits).
    """

    id: int | None = None
    feed_id: int = 0
    name: str = ""
    enabled: bool = True
    include: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)
    regex: str = ""
    category: str = ""
    destination: str = ""  # "" = the application's default save path
    min_size: int | None = None  # bytes; needs a trustworthy size
    max_size: int | None = None
    max_per_refresh: int = 3  # 0 = no limit
    daily_count_budget: int = 10  # additions per UTC day; 0 = no limit
    daily_bytes_budget: int = 0  # bytes per UTC day; 0 = no limit (needs a trustworthy size)
    add_paused: bool = False
    created_at: int = 0


ACTION_ADD = "add"
ACTION_SKIP = "skip"
ACTION_REVIEW = "review"
ACTION_NEED_SIZE = "need_size"  # internal: a size limit applies and no trustworthy size is known
ACTION_DUPLICATE = "duplicate"


@dataclass(frozen=True, slots=True)
class RuleDecision:
    action: str
    reason: str
    rule_id: int | None = None


@dataclass(frozen=True, slots=True)
class RulePreviewRow:
    entry: FeedEntry
    decision: str  # add | skip | review | duplicate
    reason: str


@dataclass(frozen=True, slots=True)
class RuleLogRow:
    ts: int
    feed_id: int
    rule_id: int | None
    entry_id: int | None
    entry_title: str
    action: str
    reason: str


@dataclass(slots=True)
class RefreshResult:
    feed_id: int
    ok: bool = False
    not_modified: bool = False
    baseline: bool = False  # this refresh recorded the subscription baseline
    new_entries: int = 0
    updated_entries: int = 0
    auto_added: int = 0
    queued_for_review: int = 0
    duplicates: int = 0
    error: str = ""
    warning: str = ""
    status_code: int | None = None
    next_check: int = 0
    manual: bool = True


@dataclass(slots=True)
class OpmlOutline:
    url: str
    title: str = ""
    folder: str = ""
    category: str = ""


@dataclass(slots=True)
class OpmlImportResult:
    added: int = 0
    skipped_existing: int = 0
    invalid: int = 0
    feed_ids: list[int] = field(default_factory=list)
