"""The RSS/Atom subscription service.

Threading: every public method may be called from worker threads (never from
the GUI thread – they perform database and, for refresh/add, network work).
A per-feed lock prevents concurrent refreshes of the same subscription.

Guarantees implemented here:

* **Baseline** – the first successful refresh of a subscription records what is
  already in the feed; those entries are never added automatically unless the
  user subscribed with ``download_existing=True``.
* **Opt-in automation** – rules run only for feeds whose ``auto_download`` flag
  is set, only for entries first seen in the current refresh (or when the user
  explicitly calls :meth:`FeedService.apply_rules_now`).
* **No overwriting of manual decisions** – an item that already has a transfer,
  or that history records as added or dismissed, is linked/marked and otherwise
  left alone; existing transfers are never modified by a refresh.
* **Review instead of guessing** – when a rule cannot be applied safely (size
  unknown, limits reached, download failed, add rejected) the entry goes to the
  review queue.
* **No payments** – this package has no access to the payment subsystem.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable

from ..domain.identity import IdentityError, TorrentIdentity
from ..net.http import Fetcher, HttpPolicy, safe_url_for_display
from ..persistence.database import Database
from ..services.interfaces import AddOutcome, AddRejected, TransferGateway
from ..util.clock import Clock
from . import dedup
from .client import FeedClient, FeedFetchError, backoff_seconds, validate_feed_url
from .models import (ACTION_ADD, ACTION_DUPLICATE, ACTION_NEED_SIZE, ACTION_REVIEW, ACTION_SKIP, LINK_MAGNET,
                     LINK_TORRENT, STATUS_ADDED, STATUS_BASELINE, STATUS_DISMISSED, STATUS_DUPLICATE, STATUS_NEW,
                     STATUS_REVIEW, Feed, FeedEntry, FeedError, FeedRule, OpmlImportResult, ParsedEntry,
                     ParsedFeed, RefreshResult, RuleLogRow, RulePreviewRow)
from .opml import export_opml, parse_opml
from .parser import FeedParseError, parse_feed
from .repository import FeedRepository
from .rules import RuleInput, check_budget, evaluate_rule, validate_rule

log = logging.getLogger(__name__)

MAX_DUE_PER_CALL = 10
MAX_FEEDS = 2000
HISTORY_RETENTION_S = 400 * 24 * 3600
HISTORY_PRUNE_INTERVAL_S = 24 * 3600
PREVIEW_LIMIT = 200
MAX_INTERVAL_MINUTES = 7 * 24 * 60
_HANDLED = ("added", "dismissed")


class FeedService:
    def __init__(self, db: Database, fetcher: Fetcher, gateway: TransferGateway,
                 settings: Callable[[], Any], clock: Clock):
        self._repo = FeedRepository(db)
        self._client = FeedClient(fetcher)
        self._gateway = gateway
        self._settings = settings
        self._clock = clock
        self._locks: dict[int, threading.Lock] = {}
        self._locks_guard = threading.Lock()
        self._last_history_prune = 0.0

    # ------------------------------------------------------------------ helpers
    def _now(self) -> int:
        return int(self._clock.now())

    def _policy(self) -> HttpPolicy:
        return HttpPolicy.from_settings(self._settings().feeds_network)

    def _feed_settings(self):
        return self._settings().feeds

    def _feed_lock(self, feed_id: int) -> threading.Lock:
        with self._locks_guard:
            return self._locks.setdefault(feed_id, threading.Lock())

    def _require_feed(self, feed_id: int) -> Feed:
        feed = self._repo.get_feed(feed_id)
        if feed is None:
            raise FeedError("That subscription no longer exists.")
        return feed

    def _require_entry(self, entry_id: int) -> FeedEntry:
        entry = self._repo.get_entry(entry_id)
        if entry is None:
            raise FeedError("That feed entry no longer exists.")
        return entry

    def _interval(self, minutes: int | None) -> int:
        fs = self._feed_settings()
        if minutes is None:
            minutes = fs.default_interval_minutes
        if isinstance(minutes, bool) or not isinstance(minutes, int):
            raise FeedError("The refresh interval must be a whole number of minutes.")
        return max(fs.min_interval_minutes, min(int(minutes), MAX_INTERVAL_MINUTES))

    @staticmethod
    def _folder(folder: str) -> str:
        parts = [" ".join(p.split()) for p in str(folder or "").replace("\\", "/").split("/")]
        return "/".join(p for p in parts if p)[:200]

    @staticmethod
    def _label(text: str, limit: int) -> str:
        return " ".join("".join(c if ord(c) >= 32 else " " for c in str(text or "")).split())[:limit]

    # ------------------------------------------------------------ subscriptions
    def add_feed(self, url: str, *, title: str = "", folder: str = "", category: str = "",
                 interval_minutes: int | None = None, download_existing: bool = False) -> Feed:
        """Subscribe. No network request is made here; the feed is due for refresh immediately.

        ``download_existing=True`` is the explicit choice to treat the entries already in the
        feed as new (so enabled rules may add them on the first refresh).
        """
        url = validate_feed_url(url)
        if self._repo.get_feed_by_url(url) is not None:
            raise FeedError("You are already subscribed to this feed.")
        if len(self._repo.list_feeds()) >= MAX_FEEDS:
            raise FeedError(f"The limit of {MAX_FEEDS} subscriptions was reached.")
        feed_id = self._repo.insert_feed(
            url=url, title=self._label(title, 300), folder=self._folder(folder),
            category=self._label(category, 64), interval_minutes=self._interval(interval_minutes),
            download_existing=bool(download_existing), now=self._now())
        log.info("subscribed to %s", safe_url_for_display(url))
        return self._require_feed(feed_id)

    def update_feed(self, feed_id: int, **changes: Any) -> Feed:
        feed = self._require_feed(feed_id)
        fields: dict[str, Any] = {}
        for name, value in changes.items():
            if name == "url":
                url = validate_feed_url(value)
                if url != feed.url:
                    other = self._repo.get_feed_by_url(url)
                    if other is not None and other.id != feed.id:
                        raise FeedError("Another subscription already uses this address.")
                    # A different document: forget the validators and check again soon.
                    fields.update(url=url, etag="", last_modified="", next_check=0)
            elif name == "title":
                fields["title"] = self._label(value, 300)
            elif name == "folder":
                fields["folder"] = self._folder(value)
            elif name == "category":
                fields["category"] = self._label(value, 64)
            elif name == "interval_minutes":
                fields["interval_minutes"] = self._interval(value)
            elif name == "auto_download":
                if not isinstance(value, bool):
                    raise FeedError("auto_download must be true or false.")
                fields["auto_download"] = value
            else:
                raise FeedError(f"“{name}” cannot be changed.")
        self._repo.update_feed(feed_id, **fields)
        return self._require_feed(feed_id)

    def set_auto_download(self, feed_id: int, enabled: bool) -> Feed:
        return self.update_feed(feed_id, auto_download=bool(enabled))

    def remove_feed(self, feed_id: int) -> None:
        lock = self._feed_lock(feed_id)
        with lock:
            self._repo.delete_feed(feed_id)
        with self._locks_guard:
            self._locks.pop(feed_id, None)

    def list_feeds(self) -> list[Feed]:
        return self._repo.list_feeds()

    def get_feed(self, feed_id: int) -> Feed | None:
        return self._repo.get_feed(feed_id)

    def list_folders(self) -> list[str]:
        return sorted({f.folder for f in self._repo.list_feeds() if f.folder}, key=str.lower)

    # ------------------------------------------------------------------ refresh
    def refresh_due(self) -> list[RefreshResult]:
        """Refresh subscriptions whose next check time has passed (bounded per call)."""
        results = []
        for feed in self._repo.due_feeds(self._now(), MAX_DUE_PER_CALL):
            try:
                results.append(self.refresh_feed(feed.id, manual=False))
            except FeedError as exc:  # e.g. removed concurrently
                results.append(RefreshResult(feed.id, ok=False, error=str(exc), manual=False))
        return results

    def refresh_feed(self, feed_id: int, *, manual: bool = True) -> RefreshResult:
        lock = self._feed_lock(feed_id)
        if not lock.acquire(blocking=False):
            return RefreshResult(feed_id, ok=False, error="A refresh of this feed is already running.",
                                 manual=manual)
        try:
            return self._refresh(feed_id, manual)
        finally:
            lock.release()

    def _refresh(self, feed_id: int, manual: bool) -> RefreshResult:
        feed = self._require_feed(feed_id)
        settings = self._settings()
        policy = HttpPolicy.from_settings(settings.feeds_network)
        now = self._now()
        result = RefreshResult(feed_id, manual=manual)
        shown = safe_url_for_display(feed.url)

        try:
            resp = self._client.fetch_feed(feed.url, etag=feed.etag, last_modified=feed.last_modified,
                                           policy=policy, now=now)
        except FeedFetchError as exc:
            return self._record_failure(feed, result, str(exc), now, status=exc.status,
                                        retry_after=exc.retry_after)

        interval_s = feed.interval_minutes * 60
        result.status_code = resp.status
        if resp.not_modified:
            self._repo.update_feed(feed.id, last_checked=now, last_success=now, next_check=now + interval_s,
                                   fail_count=0, last_status="not_modified", last_error="")
            result.ok = True
            result.not_modified = True
            result.next_check = now + interval_s
            log.info("feed %s: not modified", shown)
            return result

        try:
            parsed = parse_feed(resp.body, base_url=resp.final_url or feed.url,
                                max_entries=settings.feeds.max_entries_per_feed)
        except FeedParseError as exc:
            return self._record_failure(feed, result, str(exc), now, status=resp.status)

        baseline = not feed.baseline_done and not feed.download_existing
        try:
            new_ids, updated = self._merge(feed, parsed, now, baseline)
        except Exception:  # storage problem: report, back off, keep the old validators
            log.exception("feed %s: storing entries failed", shown)
            return self._record_failure(feed, result, "The feed entries could not be stored.", now,
                                        status=resp.status)

        fields: dict[str, Any] = dict(
            last_checked=now, last_success=now, next_check=now + interval_s, fail_count=0, last_status="ok",
            last_error="", etag=resp.etag, last_modified=resp.last_modified, baseline_done=True)
        if not feed.title and parsed.title:
            fields["title"] = parsed.title
        if parsed.site_url:
            fields["site_url"] = parsed.site_url
        if resp.permanent_url and resp.permanent_url != feed.url:
            # Only now – after the redirected document proved to be a feed – follow a permanent move.
            try:
                moved = validate_feed_url(resp.permanent_url)
            except FeedError:
                moved = ""
            if moved and self._repo.get_feed_by_url(moved) is None:
                fields["url"] = moved
                log.info("feed %s moved permanently to %s", shown, safe_url_for_display(moved))
        self._repo.update_feed(feed.id, **fields)
        self._repo.prune_entries(feed.id, settings.feeds.max_entries_per_feed)

        result.ok = True
        result.baseline = not feed.baseline_done and baseline
        result.new_entries = len(new_ids)
        result.updated_entries = updated
        result.next_check = now + interval_s
        result.warning = parsed.warning

        if new_ids and not baseline and feed.auto_download:
            self._run_rules(feed, new_ids, result, policy)

        if self._clock.monotonic() - self._last_history_prune > HISTORY_PRUNE_INTERVAL_S:
            self._last_history_prune = self._clock.monotonic()
            self._repo.prune_seen(now - HISTORY_RETENTION_S)
        log.info("feed %s refreshed: %d new, %d updated, %d added, %d for review%s", shown, result.new_entries,
                 updated, result.auto_added, result.queued_for_review, " (baseline)" if result.baseline else "")
        return result

    def _record_failure(self, feed: Feed, result: RefreshResult, message: str, now: int, *,
                        status: int | None = None, retry_after: int | None = None) -> RefreshResult:
        fail_count = feed.fail_count + 1
        next_check = now + backoff_seconds(fail_count, retry_after)
        self._repo.update_feed(feed.id, last_checked=now, next_check=next_check, fail_count=fail_count,
                               last_status="error", last_error=message[:500])
        result.ok = False
        result.error = message
        result.status_code = status
        result.next_check = next_check
        log.warning("feed %s failed (attempt %d): %s", safe_url_for_display(feed.url), fail_count, message)
        return result

    def _merge(self, feed: Feed, parsed: ParsedFeed, now: int, baseline: bool) -> tuple[list[int], int]:
        """Store a parsed document. Returns ``(ids of entries new to this feed, updated count)``."""
        shared = dedup.shared_links(parsed.entries)
        new_ids: list[int] = []
        updated = 0
        with self._repo.db.tx():
            # Documents list newest first; insert oldest first so ids follow publication order.
            for pe in reversed(parsed.entries):
                use_link = not pe.link or dedup.canonical_url(pe.link) not in shared
                keys = dedup.entry_keys(feed.id, pe, use_link=use_link)
                rows = self._repo.lookup_seen([k.key for k in keys])

                entry_id: int | None = None
                for k in keys:  # the same entry in this feed (GUID, link or title hash)
                    row = rows.get(k.key)
                    if k.feed_scoped and row is not None and row["entry_id"] is not None:
                        entry_id = row["entry_id"]
                        break
                if entry_id is None:
                    # GUID and link both changed, but it is the same torrent from the same feed.
                    for k in keys:
                        row = rows.get(k.key)
                        if not k.feed_scoped and row is not None and row["entry_id"] is not None:
                            existing = self._repo.get_entry(row["entry_id"])
                            if existing is not None and existing.feed_id == feed.id:
                                entry_id = existing.id
                                break
                if entry_id is not None and self._repo.entry_exists(entry_id):
                    if self._repo.update_entry_content(entry_id, pe, now=now):
                        updated += 1
                    self._repo.record_seen(keys, feed_id=feed.id, entry_id=entry_id, outcome="seen", now=now)
                    continue
                if any(k.feed_scoped and k.key in rows for k in keys):
                    # Known to this feed's history but pruned from the entry list: do not resurrect it.
                    self._repo.record_seen(keys, feed_id=feed.id, entry_id=None, outcome="seen", now=now)
                    continue

                status = STATUS_BASELINE if baseline else STATUS_NEW
                entry_id = self._repo.insert_entry(feed.id, pe, status=status, read=False, now=now)
                self._repo.record_seen(keys, feed_id=feed.id, entry_id=entry_id,
                                       outcome="baseline" if baseline else "seen", now=now)
                new_ids.append(entry_id)
        return new_ids, updated

    # ---------------------------------------------------------------- automation
    def _run_rules(self, feed: Feed, entry_ids: list[int], result: RefreshResult, policy: HttpPolicy) -> None:
        rules = [r for r in self._repo.list_rules(feed.id) if r.enabled]
        if not rules:
            return
        counters: dict[int, int] = {}
        for entry_id in entry_ids:
            entry = self._repo.get_entry(entry_id)
            if entry is None:
                continue
            try:
                outcome = self._auto_process(feed, entry, rules, counters, policy)
            except Exception:  # never let one entry abort the refresh
                log.exception("rule processing failed for an entry of feed %s", safe_url_for_display(feed.url))
                self._to_review(feed, entry, None, "an internal error occurred while applying the rules")
                outcome = ACTION_REVIEW
            if outcome == ACTION_ADD:
                result.auto_added += 1
            elif outcome == ACTION_REVIEW:
                result.queued_for_review += 1
            elif outcome == ACTION_DUPLICATE:
                result.duplicates += 1

    def apply_rules_now(self, feed_id: int) -> RefreshResult:
        """Explicit user action: apply the feed's enabled rules to entries that are still
        untouched (status ``new`` or ``baseline``). Requires auto-download to be enabled."""
        feed = self._require_feed(feed_id)
        result = RefreshResult(feed_id, ok=True, manual=True)
        if not feed.auto_download:
            raise FeedError("Enable automatic downloads for this feed before applying its rules.")
        with self._feed_lock(feed_id):
            entries = self._repo.entries_for_feed(feed_id, (STATUS_NEW, STATUS_BASELINE))
            ids = [e.id for e in reversed(entries)]
            self._run_rules(feed, ids, result, self._policy())
        return result

    def _entry_identity(self, entry: FeedEntry) -> TorrentIdentity | None:
        if not (entry.v1 or entry.v2):
            return None
        try:
            return TorrentIdentity(entry.v1, entry.v2)
        except IdentityError:
            return None

    @staticmethod
    def _history_keys(entry: FeedEntry) -> list[dedup.DedupKey]:
        """Keys used to record what happened to an entry (GUID + global keys)."""
        pe = ParsedEntry(guid=entry.guid, title=entry.title, torrent_url=entry.torrent_url,
                         v1=entry.v1, v2=entry.v2)
        return [k for k in dedup.entry_keys(entry.feed_id, pe, use_link=False) if k.kind != "t"]

    def _handled_elsewhere(self, entry: FeedEntry) -> str | None:
        """'added' / 'dismissed' when history says this torrent was already handled."""
        keys = [k.key for k in self._history_keys(entry) if not k.feed_scoped]
        for row in self._repo.lookup_seen(keys).values():
            if row["outcome"] in _HANDLED and row["entry_id"] != entry.id:
                return row["outcome"]
        return None

    def _existing_transfer(self, entry: FeedEntry):
        identity = self._entry_identity(entry)
        return self._gateway.find_duplicate(identity) if identity is not None else None

    def _mark(self, entry: FeedEntry, status: str, reason: str, *, outcome: str,
              transfer_id: str | None = None, rule_id: int | None = None) -> None:
        now = self._now()
        self._repo.set_entry_status(entry.id, status, reason, transfer_id=transfer_id, rule_id=rule_id, now=now)
        self._repo.record_seen(self._history_keys(entry), feed_id=entry.feed_id, entry_id=entry.id,
                               outcome=outcome, now=now, transfer_id=transfer_id)

    def _log_decision(self, feed_id: int, entry: FeedEntry, rule_id: int | None, action: str, reason: str) -> None:
        self._repo.add_log(ts=self._now(), feed_id=feed_id, rule_id=rule_id, entry_id=entry.id,
                           title=entry.title, action=action, reason=reason)

    def _to_review(self, feed: Feed, entry: FeedEntry, rule: FeedRule | None, reason: str) -> str:
        rule_id = rule.id if rule else None
        self._mark(entry, STATUS_REVIEW, reason, outcome="review", rule_id=rule_id)
        self._log_decision(feed.id, entry, rule_id, ACTION_REVIEW, reason)
        return ACTION_REVIEW

    def _to_duplicate(self, feed: Feed, entry: FeedEntry, reason: str, transfer_id: str | None = None,
                      rule_id: int | None = None) -> str:
        self._mark(entry, STATUS_DUPLICATE, reason, outcome="duplicate", transfer_id=transfer_id, rule_id=rule_id)
        self._log_decision(feed.id, entry, rule_id, ACTION_DUPLICATE, reason)
        return ACTION_DUPLICATE

    def _check_already_handled(self, feed: Feed, entry: FeedEntry) -> str | None:
        handled = self._handled_elsewhere(entry)
        if handled is not None:
            return self._to_duplicate(feed, entry, f"this torrent was already {handled} earlier")
        existing = self._existing_transfer(entry)
        if existing is not None:
            # The existing transfer is linked, never modified.
            return self._to_duplicate(feed, entry, "already in your transfers", transfer_id=existing.id)
        return None

    def _learn_metadata(self, entry: FeedEntry, torrent_data: bytes) -> FeedEntry:
        """Inspect fetched .torrent bytes and store the trustworthy size and identity."""
        meta = self._gateway.inspect_torrent(torrent_data)
        self._repo.set_entry_metadata(entry.id, size=meta.total_size, v1=meta.identity.v1, v2=meta.identity.v2)
        self._repo.record_seen(dedup.identity_keys(meta.identity.v1, meta.identity.v2), feed_id=entry.feed_id,
                               entry_id=entry.id, outcome="seen", now=self._now())
        return self._require_entry(entry.id)

    def _auto_process(self, feed: Feed, entry: FeedEntry, rules: list[FeedRule], counters: dict[int, int],
                      policy: HttpPolicy) -> str:
        """Apply the first matching rule to one entry. Returns add | review | duplicate | skip."""
        if not entry.can_add:
            return ACTION_SKIP
        already = self._check_already_handled(feed, entry)
        if already is not None:
            return already

        timeout_ms = self._feed_settings().regex_timeout_ms
        torrent_data: bytes | None = None
        for rule in rules:
            decision = evaluate_rule(rule, RuleInput(entry.title, entry.link_type, entry.size, entry.size_trusted),
                                     regex_timeout_ms=timeout_ms)
            if decision.action == ACTION_SKIP:
                continue
            if decision.action == ACTION_NEED_SIZE:
                if entry.link_type != LINK_TORRENT:
                    return self._to_review(feed, entry, rule, "the rule has a size limit, and a magnet link "
                                                              "does not state a trustworthy size")
                try:
                    torrent_data = torrent_data or self._client.fetch_torrent(entry.torrent_url, policy=policy)
                    entry = self._learn_metadata(entry, torrent_data)
                except FeedFetchError as exc:
                    return self._to_review(feed, entry, rule, f"the torrent file could not be downloaded to "
                                                              f"check its size: {exc}")
                except ValueError as exc:  # TorrentFormatError
                    return self._to_review(feed, entry, rule, f"the torrent file is not valid: {exc}")
                already = self._check_already_handled(feed, entry)
                if already is not None:
                    return already
                decision = evaluate_rule(rule, RuleInput(entry.title, entry.link_type, entry.size,
                                                         entry.size_trusted), regex_timeout_ms=timeout_ms)
                if decision.action == ACTION_SKIP:
                    self._log_decision(feed.id, entry, rule.id, ACTION_SKIP, decision.reason)
                    continue
            if decision.action in (ACTION_REVIEW, ACTION_NEED_SIZE):
                return self._to_review(feed, entry, rule, decision.reason)

            # decision.action == add: stateful limits
            day = time.strftime("%Y-%m-%d", time.gmtime(self._clock.now()))
            added_today, bytes_today = self._repo.get_budget(day, rule.id)
            over = check_budget(rule, added_this_refresh=counters.get(rule.id, 0), added_today=added_today,
                                bytes_today=bytes_today, size=entry.size if entry.size_trusted else None)
            if over is not None:
                return self._to_review(feed, entry, rule, over)

            save_path = rule.destination or self._gateway.default_save_path()
            category = rule.category or feed.category
            try:
                outcome = self._perform_add(entry, save_path=save_path, category=category,
                                            paused=rule.add_paused, preview=False, torrent_data=torrent_data,
                                            policy=policy)
            except (AddRejected, FeedError) as exc:
                return self._to_review(feed, entry, rule, f"could not be added automatically: {exc}")
            if not outcome.created:
                return self._to_duplicate(feed, entry, "already in your transfers",
                                          transfer_id=outcome.duplicate_of or outcome.transfer_id, rule_id=rule.id)
            counters[rule.id] = counters.get(rule.id, 0) + 1
            fresh = self._repo.get_entry(entry.id) or entry
            self._repo.add_budget(day, rule.id, count=1, size=fresh.size if fresh.size_trusted and fresh.size else 0)
            self._mark(entry, STATUS_ADDED, f"added by rule “{rule.name or rule.id}”", outcome="added",
                       transfer_id=outcome.transfer_id, rule_id=rule.id)
            self._log_decision(feed.id, entry, rule.id, ACTION_ADD,
                               "added paused" if rule.add_paused else "added")
            return ACTION_ADD
        return ACTION_SKIP

    def _perform_add(self, entry: FeedEntry, *, save_path: str, category: str, paused: bool, preview: bool,
                     torrent_data: bytes | None = None, policy: HttpPolicy | None = None) -> AddOutcome:
        """Create the transfer for an entry through the gateway (the only side-effect channel)."""
        if entry.link_type == LINK_TORRENT and entry.torrent_url:
            data = torrent_data or self._client.fetch_torrent(entry.torrent_url, policy=policy or self._policy())
            return self._gateway.add_torrent_data(data, save_path=save_path, category=category, paused=paused,
                                                  source="feed", feed_entry_id=entry.id)
        if entry.magnet:
            return self._gateway.add_magnet(entry.magnet, save_path=save_path, category=category, paused=paused,
                                            preview=preview, source="feed", feed_entry_id=entry.id)
        raise FeedError("This entry has no torrent or magnet link.")

    # ------------------------------------------------------------------ entries
    def list_entries(self, *, feed_id: int | None = None, folder: str | None = None, unread_only: bool = False,
                     search: str = "", link_type: str | None = None, status: str | None = None,
                     limit: int = 200, offset: int = 0) -> list[FeedEntry]:
        return self._repo.list_entries(feed_id=feed_id, folder=folder, unread_only=unread_only,
                                       search=search or "", link_type=link_type, status=status,
                                       limit=limit, offset=offset)

    def get_entry(self, entry_id: int) -> FeedEntry | None:
        return self._repo.get_entry(entry_id)

    def mark_read(self, entry_ids, read: bool = True) -> int:
        return self._repo.set_read(entry_ids, read)

    def mark_all_read(self, feed_id: int | None = None) -> int:
        return self._repo.mark_all_read(feed_id)

    def add_entry_as_transfer(self, entry_id: int, *, save_path: str, category: str = "", paused: bool = False,
                              preview: bool = False) -> AddOutcome:
        """The manual “Add Transfer” action. Raises ``AddRejected`` / ``FeedError`` with a
        user-presentable message when the transfer cannot be created."""
        entry = self._require_entry(entry_id)
        if not entry.can_add:
            raise FeedError("This entry has no torrent or magnet link.")
        outcome = self._perform_add(entry, save_path=save_path, category=category, paused=paused,
                                    preview=preview)
        self._after_manual_add(entry, outcome)
        return outcome

    def _after_manual_add(self, entry: FeedEntry, outcome: AddOutcome) -> None:
        if outcome.created:
            self._mark(entry, STATUS_ADDED, "added by you", outcome="added", transfer_id=outcome.transfer_id)
        else:
            self._mark(entry, STATUS_DUPLICATE, "already in your transfers", outcome="duplicate",
                       transfer_id=outcome.duplicate_of or outcome.transfer_id)
        self._repo.set_read([entry.id], True)

    # -------------------------------------------------------------------- rules
    def list_rules(self, feed_id: int | None = None) -> list[FeedRule]:
        return self._repo.list_rules(feed_id)

    def save_rule(self, rule: FeedRule) -> FeedRule:
        self._require_feed(rule.feed_id)
        validate_rule(rule, regex_timeout_ms=self._feed_settings().regex_timeout_ms)
        if rule.id is not None and self._repo.get_rule(rule.id) is None:
            raise FeedError("That rule no longer exists.")
        rule_id = self._repo.save_rule(rule, self._now())
        saved = self._repo.get_rule(rule_id)
        assert saved is not None
        return saved

    def delete_rule(self, rule_id: int) -> None:
        self._repo.delete_rule(rule_id)

    def preview_rule(self, rule: FeedRule) -> list[RulePreviewRow]:
        """Dry run: what would this rule decide for the feed's current entries?

        Nothing is fetched, added, logged or stored.  Entries whose size would have
        to be verified from torrent metadata are reported as ``review`` with a
        reason that says so.  Limits are simulated as if all listed entries arrived
        in one refresh, oldest first, on top of today's recorded budget use.
        """
        self._require_feed(rule.feed_id)
        candidate = FeedRule(**{name: getattr(rule, name) for name in FeedRule.__dataclass_fields__})
        candidate.include = list(rule.include or [])
        candidate.exclude = list(rule.exclude or [])
        timeout_ms = self._feed_settings().regex_timeout_ms
        validate_rule(candidate, regex_timeout_ms=timeout_ms)

        day = time.strftime("%Y-%m-%d", time.gmtime(self._clock.now()))
        added_today, bytes_today = self._repo.get_budget(day, candidate.id) if candidate.id else (0, 0)
        this_refresh = 0
        rows: list[RulePreviewRow] = []
        entries = self._repo.entries_for_feed(candidate.feed_id, limit=PREVIEW_LIMIT)
        for entry in reversed(entries):  # oldest first, like a refresh
            decision, reason = self._preview_one(candidate, entry, timeout_ms, this_refresh, added_today,
                                                 bytes_today)
            if decision == ACTION_ADD:
                this_refresh += 1
                added_today += 1
                bytes_today += entry.size or 0
            rows.append(RulePreviewRow(entry, decision, reason))
        rows.reverse()
        return rows

    def _preview_one(self, rule: FeedRule, entry: FeedEntry, timeout_ms: int, this_refresh: int,
                     added_today: int, bytes_today: int) -> tuple[str, str]:
        if not entry.can_add:
            return ACTION_SKIP, "the entry has no torrent or magnet link"
        if entry.status in (STATUS_ADDED, STATUS_DISMISSED):
            return ACTION_DUPLICATE, f"already {entry.status}"
        handled = self._handled_elsewhere(entry)
        if handled is not None:
            return ACTION_DUPLICATE, f"this torrent was already {handled} earlier"
        if self._existing_transfer(entry) is not None:
            return ACTION_DUPLICATE, "already in your transfers"
        decision = evaluate_rule(rule, RuleInput(entry.title, entry.link_type, entry.size, entry.size_trusted),
                                 regex_timeout_ms=timeout_ms)
        if decision.action == ACTION_NEED_SIZE:
            if entry.link_type == LINK_MAGNET:
                return ACTION_REVIEW, "size limit set, and a magnet link does not state a trustworthy size"
            return ACTION_REVIEW, ("size limit set: the torrent file would be downloaded to check the size "
                                   "(not done in a dry run)")
        if decision.action != ACTION_ADD:
            return decision.action, decision.reason
        over = check_budget(rule, added_this_refresh=this_refresh, added_today=added_today,
                            bytes_today=bytes_today, size=entry.size if entry.size_trusted else None)
        if over is not None:
            return ACTION_REVIEW, over
        return ACTION_ADD, "would be added paused" if rule.add_paused else "would be added"

    def rule_log(self, *, feed_id: int | None = None, limit: int = 100) -> list[RuleLogRow]:
        return self._repo.recent_log(limit, feed_id)

    # ------------------------------------------------------------- review queue
    def list_review(self) -> list[FeedEntry]:
        return self._repo.list_entries(status=STATUS_REVIEW, limit=1000)

    def approve_review(self, entry_id: int, *, save_path: str | None = None) -> AddOutcome:
        """Add a queued entry (explicit user action; rule limits do not apply)."""
        entry = self._require_entry(entry_id)
        if entry.status != STATUS_REVIEW:
            raise FeedError("This entry is not waiting for review.")
        feed = self._require_feed(entry.feed_id)
        rule = self._repo.get_rule(entry.rule_id) if entry.rule_id else None
        destination = save_path or (rule.destination if rule else "") or self._gateway.default_save_path()
        category = (rule.category if rule else "") or feed.category
        outcome = self._perform_add(entry, save_path=destination, category=category,
                                    paused=bool(rule.add_paused) if rule else False, preview=False)
        self._after_manual_add(entry, outcome)
        self._log_decision(feed.id, entry, entry.rule_id, ACTION_ADD if outcome.created else ACTION_DUPLICATE,
                           "approved by you")
        return outcome

    def dismiss_review(self, entry_id: int) -> None:
        entry = self._require_entry(entry_id)
        if entry.status != STATUS_REVIEW:
            raise FeedError("This entry is not waiting for review.")
        self._mark(entry, STATUS_DISMISSED, "dismissed by you", outcome="dismissed")
        self._repo.set_read([entry.id], True)
        self._log_decision(entry.feed_id, entry, entry.rule_id, ACTION_SKIP, "dismissed by you")

    # --------------------------------------------------------------------- OPML
    def import_opml(self, text: str | bytes) -> OpmlImportResult:
        outlines, invalid = parse_opml(text)
        result = OpmlImportResult(invalid=invalid)
        for outline in outlines:
            if self._repo.get_feed_by_url(outline.url) is not None:
                result.skipped_existing += 1
                continue
            try:
                feed = self.add_feed(outline.url, title=outline.title, folder=outline.folder,
                                     category=outline.category)
            except FeedError:
                result.invalid += 1
                continue
            result.added += 1
            result.feed_ids.append(feed.id)
        return result

    def export_opml(self) -> str:
        return export_opml(self._repo.list_feeds())

    # -------------------------------------------------------------- diagnostics
    def diagnostics(self) -> dict[str, Any]:
        feeds = self._repo.list_feeds()
        return {
            "subscriptions": len(feeds),
            "auto_download_enabled": sum(1 for f in feeds if f.auto_download),
            "entries_by_status": self._repo.entry_counts(),
            "rules": len(self._repo.list_rules()),
            "feeds": [
                {
                    "id": f.id,
                    "address": safe_url_for_display(f.url),
                    "title": f.title,
                    "last_status": f.last_status,
                    "last_error": f.last_error,
                    "fail_count": f.fail_count,
                    "last_checked": f.last_checked,
                    "next_check": f.next_check,
                    "interval_minutes": f.interval_minutes,
                    "auto_download": f.auto_download,
                    "baseline_done": f.baseline_done,
                    "entries": f.entry_count,
                    "unread": f.unread_count,
                    "review": f.review_count,
                }
                for f in feeds[:200]
            ],
            "recent_rule_decisions": [
                {"ts": r.ts, "feed_id": r.feed_id, "rule_id": r.rule_id, "action": r.action, "reason": r.reason,
                 "entry": r.entry_title}
                for r in self._repo.recent_log(50)
            ],
        }
