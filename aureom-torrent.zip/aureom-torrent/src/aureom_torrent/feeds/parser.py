"""RSS 2.0 / Atom parsing and normalisation.

* ``feedparser`` is only ever given bytes wrapped in a stream – it never fetches a URL
  and never opens a local file on our behalf.
* Entry content is reduced to a small allow-list of inert tags with ``nh3``:
  no images, scripts, styles, frames or event handlers; links keep http/https
  targets only.  Nothing remote is loaded when an entry is displayed.
* Sizes found in a feed are recorded as *feed-reported* and are never used to
  satisfy a size limit.
"""

from __future__ import annotations

import calendar
import html
import io
import re
from urllib.parse import urljoin, urlsplit

import feedparser
import nh3

from ..domain.magnet import MagnetError, looks_like_magnet, parse_magnet
from .models import LINK_MAGNET, LINK_NONE, LINK_TORRENT, FeedError, ParsedEntry, ParsedFeed

MAX_TITLE = 500
MAX_PUBLISHER = 200
MAX_GUID = 1024
MAX_URL = 2048
MAX_RAW_SUMMARY = 200_000
MAX_SUMMARY_HTML = 20_000
MAX_SUMMARY_TEXT = 5_000
MAX_SIZE = 1 << 50  # 1 PiB; anything larger is treated as nonsense
ENTITY_SCAN_BYTES = 1024 * 1024

ALLOWED_TAGS = {"p", "br", "b", "strong", "i", "em", "ul", "ol", "li", "blockquote", "code", "pre", "a"}
ALLOWED_ATTRIBUTES = {"a": {"href"}}
ALLOWED_SCHEMES = {"http", "https"}
TORRENT_MIME = "application/x-bittorrent"

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_WS = re.compile(r"\s+")
_MAGNET_IN_TEXT = re.compile(r"""magnet:\?[^\s"'<>]{10,8000}""", re.IGNORECASE)
_HEX40 = re.compile(r"^[0-9a-fA-F]{40}$")
_HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")
_TAG_BREAK = re.compile(r"(?i)<\s*(br|/p|/li|/blockquote|/pre|/div|/h[1-6])\b[^>]*>")


class FeedParseError(FeedError):
    """The response body is not a usable RSS or Atom document."""


def sanitise_html(raw: str) -> str:
    """Return restricted, inert markup."""
    if not raw:
        return ""
    cleaned = nh3.clean(
        raw[:MAX_RAW_SUMMARY],
        tags=ALLOWED_TAGS,
        attributes=ALLOWED_ATTRIBUTES,
        url_schemes=ALLOWED_SCHEMES,
        link_rel="noopener noreferrer",
        strip_comments=True,
    )
    if len(cleaned) > MAX_SUMMARY_HTML:
        # Cutting markup mid-tag could re-open something; fall back to escaped plain text.
        cleaned = "<p>" + html.escape(plain_text(cleaned)[:MAX_SUMMARY_TEXT]) + "…</p>"
    return cleaned


def plain_text(raw: str) -> str:
    """Text-only rendering of (possibly hostile) markup."""
    if not raw:
        return ""
    spaced = _TAG_BREAK.sub(lambda m: m.group(0) + " ", raw[:MAX_RAW_SUMMARY])
    text = html.unescape(nh3.clean(spaced, tags=set()))
    return _WS.sub(" ", _CONTROL.sub("", text)).strip()[:MAX_SUMMARY_TEXT]


def _text(value, limit: int) -> str:
    if not isinstance(value, str):
        return ""
    return _WS.sub(" ", _CONTROL.sub("", html.unescape(nh3.clean(value, tags=set())))).strip()[:limit]


def _http_url(value) -> str:
    if not isinstance(value, str):
        return ""
    url = value.strip()
    if not url or len(url) > MAX_URL or _CONTROL.search(url) or " " in url:
        return ""
    try:
        parts = urlsplit(url)
        _ = parts.port
    except ValueError:
        return ""
    if parts.scheme.lower() not in ("http", "https") or not parts.hostname:
        return ""
    if parts.username or parts.password:
        return ""
    return url


def _is_torrent_url(url: str) -> bool:
    try:
        return urlsplit(url).path.lower().endswith(".torrent")
    except ValueError:
        return False


def _valid_magnet(value) -> tuple[str, str | None, str | None] | None:
    """Return (canonical uri, v1, v2) for a usable magnet link, else None."""
    if not isinstance(value, str) or not looks_like_magnet(value):
        return None
    try:
        link = parse_magnet(html.unescape(value.strip()))
    except MagnetError:
        return None
    return link.canonical_uri(), link.identity.v1, link.identity.v2


def _size(value) -> int | None:
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return n if 0 < n <= MAX_SIZE else None


def _timestamp(entry) -> int | None:
    for key in ("published_parsed", "updated_parsed", "created_parsed"):
        value = entry.get(key)
        if value:
            try:
                ts = calendar.timegm(value)
            except (TypeError, ValueError, OverflowError):
                continue
            if 0 < ts < 4_102_444_800:  # before 2100
                return int(ts)
    return None


def declares_entities(body: bytes) -> bool:
    """True when the document declares XML entities (the vector for entity-expansion attacks)."""
    head = bytes(body[:ENTITY_SCAN_BYTES])
    if b"<!entity" in head.lower():
        return True
    for bom, codec in ((b"\xff\xfe\x00\x00", "utf-32-le"), (b"\x00\x00\xfe\xff", "utf-32-be"),
                       (b"\xff\xfe", "utf-16-le"), (b"\xfe\xff", "utf-16-be")):
        if head.startswith(bom):
            return "<!entity" in head.decode(codec, "ignore").lower()
    if b"\x00" in head[:8]:  # UTF-16/32 without a byte-order mark
        for codec in ("utf-16-le", "utf-16-be", "utf-32-le", "utf-32-be"):
            if "<!entity" in head.decode(codec, "ignore").lower():
                return True
    return False


def parse_feed(body: bytes, *, base_url: str = "", max_entries: int = 500) -> ParsedFeed:
    """Parse a feed document. Raises :class:`FeedParseError` when it is not RSS/Atom."""
    if not isinstance(body, (bytes, bytearray)) or not body.strip():
        raise FeedParseError("The feed is empty.")
    if declares_entities(body):
        # feedparser expands nested internal entities; refuse rather than risk exponential growth.
        raise FeedParseError("The feed declares XML entities, which are not accepted.")
    headers = {"content-type": "application/xml"}
    if base_url:
        headers["content-location"] = base_url
    try:
        doc = feedparser.parse(io.BytesIO(bytes(body)), response_headers=headers)
    except Exception as exc:  # feedparser is lenient, but never let a parser bug escape
        raise FeedParseError(f"The feed could not be parsed ({type(exc).__name__}).") from exc
    if not doc.get("version"):
        detail = ""
        if doc.get("bozo"):
            detail = f" ({type(doc.get('bozo_exception')).__name__})"
        raise FeedParseError("The response is not an RSS or Atom feed." + detail)

    feed = doc.get("feed") or {}
    parsed = ParsedFeed(
        title=_text(feed.get("title"), MAX_TITLE),
        site_url=_http_url(feed.get("link")),
        format=str(doc.get("version"))[:16],
    )
    if doc.get("bozo") and not doc.get("entries"):
        parsed.warning = "The feed is not well-formed and no entries could be read."
    elif doc.get("bozo"):
        exc = doc.get("bozo_exception")
        # CharacterEncodingOverride and friends are harmless; keep a short note for diagnostics.
        parsed.warning = f"The feed is not fully well-formed ({type(exc).__name__})."

    feed_author = _text(feed.get("author") or (feed.get("publisher") or ""), MAX_PUBLISHER)
    entries = doc.get("entries") or []
    if len(entries) > max_entries:
        parsed.truncated = True
        entries = entries[:max_entries]
    for raw in entries:
        try:
            entry = _normalise_entry(raw, feed_author, base_url)
        except Exception:  # one odd entry must not lose the rest of the feed
            continue
        if entry is not None:
            parsed.entries.append(entry)
    return parsed


def _normalise_entry(raw, feed_author: str, base_url: str = "") -> ParsedEntry | None:
    entry = ParsedEntry()
    guid = raw.get("id")
    entry.guid = guid.strip()[:MAX_GUID] if isinstance(guid, str) else ""
    entry.title = _text(raw.get("title"), MAX_TITLE)

    link_raw = raw.get("link") if isinstance(raw.get("link"), str) else ""
    entry.link = _http_url(link_raw)

    source = raw.get("source") or {}
    entry.publisher = (_text(raw.get("author"), MAX_PUBLISHER)
                       or _text(source.get("title") if isinstance(source, dict) else "", MAX_PUBLISHER)
                       or feed_author)
    entry.published = _timestamp(raw)

    content = ""
    contents = raw.get("content")
    if isinstance(contents, list) and contents and isinstance(contents[0], dict):
        content = contents[0].get("value") or ""
    if not content:
        content = raw.get("summary") or ""
    if not isinstance(content, str):
        content = ""
    entry.summary_html = sanitise_html(content)
    entry.summary_text = plain_text(content)

    # --- downloadable link detection -------------------------------------------------
    torrent_url = ""
    magnet = None
    enclosure_size: int | None = None

    links = raw.get("links") if isinstance(raw.get("links"), list) else []
    enclosures = raw.get("enclosures") if isinstance(raw.get("enclosures"), list) else []
    for item in list(enclosures) + [l for l in links if isinstance(l, dict) and l.get("rel") == "enclosure"]:
        if not isinstance(item, dict):
            continue
        href = item.get("href") or item.get("url") or ""
        mime = str(item.get("type") or "").lower().strip()
        if magnet is None:
            magnet = _valid_magnet(href)
            if magnet is not None:
                continue
        if base_url and isinstance(href, str) and href and "://" not in href[:12]:
            href = urljoin(base_url, href.strip())  # feedparser leaves enclosure addresses unresolved
        url = _http_url(href)
        if url and not torrent_url and (mime == TORRENT_MIME or _is_torrent_url(url)):
            torrent_url = url
            enclosure_size = _size(item.get("length"))

    if not torrent_url and entry.link and _is_torrent_url(entry.link):
        torrent_url = entry.link
    for candidate in (raw.get("torrent_magneturi"), link_raw, entry.guid):
        if magnet is None:
            magnet = _valid_magnet(candidate)
    if magnet is None:
        for found in _MAGNET_IN_TEXT.findall(html.unescape(content[:MAX_RAW_SUMMARY]))[:5]:
            magnet = _valid_magnet(found)
            if magnet is not None:
                break

    if magnet is not None:
        entry.magnet, entry.v1, entry.v2 = magnet
    info_hash = raw.get("torrent_infohash")
    if isinstance(info_hash, str):
        info_hash = info_hash.strip()
        if _HEX40.match(info_hash) and entry.v1 is None:
            entry.v1 = info_hash.lower()
        elif _HEX64.match(info_hash) and entry.v2 is None:
            entry.v2 = info_hash.lower()

    entry.torrent_url = torrent_url
    if torrent_url:
        entry.link_type = LINK_TORRENT
    elif entry.magnet:
        entry.link_type = LINK_MAGNET
    else:
        entry.link_type = LINK_NONE

    # Content size: the torrent namespace states it explicitly; an enclosure's length is often
    # the size of the .torrent file itself, so it is only a hint. Either way it is feed-reported.
    entry.size = _size(raw.get("torrent_contentlength"))
    if entry.size is None and enclosure_size is not None and entry.link_type == LINK_TORRENT:
        entry.size = enclosure_size

    if not (entry.title or entry.link or entry.guid or entry.torrent_url or entry.magnet):
        return None
    if not entry.title:
        entry.title = entry.summary_text[:80] or "(untitled entry)"
    return entry
