"""Conditional, bounded feed fetching on top of the shared HTTP policy layer.

All network access of the feeds subsystem goes through a ``net.http.Fetcher``;
this module adds the feed-specific parts: validators (ETag / Last-Modified),
status interpretation, Retry-After and the deterministic failure back-off.
"""

from __future__ import annotations

import email.utils
import logging
from dataclasses import dataclass
from urllib.parse import urlsplit

from ..net.http import Fetcher, HttpFetchError, HttpPolicy, safe_url_for_display
from .models import FeedError

log = logging.getLogger(__name__)

MAX_URL_LENGTH = 2048
MAX_VALIDATOR_LENGTH = 512
MIN_BACKOFF_S = 5 * 60
MAX_BACKOFF_S = 24 * 3600
MAX_RETRY_AFTER_S = 24 * 3600
ACCEPT = "application/atom+xml, application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.1"
TORRENT_ACCEPT = "application/x-bittorrent, application/octet-stream;q=0.9, */*;q=0.1"


class FeedFetchError(FeedError):
    """A refresh that failed at the HTTP level."""

    def __init__(self, message: str, *, status: int | None = None, retry_after: int | None = None):
        super().__init__(message)
        self.status = status
        self.retry_after = retry_after


@dataclass(frozen=True, slots=True)
class FeedResponse:
    not_modified: bool
    body: bytes = b""
    etag: str = ""
    last_modified: str = ""
    final_url: str = ""
    content_type: str = ""
    status: int = 200
    # Set when every redirect hop was permanent (301/308); the caller stores it only
    # after the body was parsed successfully.
    permanent_url: str = ""


def validate_feed_url(url: str) -> str:
    """Syntactic validation at subscription time (destination policy is enforced on every fetch)."""
    if not isinstance(url, str):
        raise FeedError("A feed address must be text.")
    url = url.strip()
    if url.lower().startswith("feed://"):
        url = "http://" + url[7:]
    elif url.lower().startswith("feed:"):
        url = url[5:]
    if not url:
        raise FeedError("Enter a feed address.")
    if len(url) > MAX_URL_LENGTH or any(ord(c) < 32 or c == "\x7f" for c in url):
        raise FeedError("The feed address is too long or contains control characters.")
    try:
        parts = urlsplit(url)
        _ = parts.port
    except ValueError as exc:
        raise FeedError("The feed address is not a valid URL.") from exc
    if parts.scheme.lower() not in ("http", "https"):
        raise FeedError("Only http and https feed addresses are supported.")
    if not parts.hostname:
        raise FeedError("The feed address has no host name.")
    if parts.username or parts.password:
        raise FeedError("Feed addresses with embedded user names or passwords are not accepted.")
    return url


def backoff_seconds(fail_count: int, retry_after: int | None = None) -> int:
    """Deterministic exponential back-off: 5, 10, 20, 40 … minutes, capped at 24 hours.

    A server-supplied Retry-After (bounded to 24 hours) can only lengthen the delay.
    """
    n = max(1, int(fail_count))
    delay = min(MAX_BACKOFF_S, MIN_BACKOFF_S * (2 ** min(n - 1, 20)))
    if retry_after is not None and retry_after > 0:
        delay = max(delay, min(int(retry_after), MAX_RETRY_AFTER_S))
    return int(delay)


def parse_retry_after(value: str | None, now: float) -> int | None:
    """Seconds to wait from a Retry-After header (delta-seconds or HTTP date), bounded."""
    if not value:
        return None
    value = value.strip()
    if value.isdigit():
        return min(int(value), MAX_RETRY_AFTER_S)
    try:
        when = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if when is None:
        return None
    delta = int(when.timestamp() - now)
    return min(max(delta, 0), MAX_RETRY_AFTER_S)


def _validator(value: str | None) -> str:
    if not value:
        return ""
    value = value.strip()
    if len(value) > MAX_VALIDATOR_LENGTH or any(ord(c) < 32 for c in value):
        return ""  # an oversized or odd validator is simply not stored
    return value


class FeedClient:
    def __init__(self, fetcher: Fetcher):
        self._fetcher = fetcher

    def fetch_feed(self, url: str, *, etag: str = "", last_modified: str = "",
                   policy: HttpPolicy | None = None, now: float = 0.0) -> FeedResponse:
        headers = {"Accept": ACCEPT}
        if etag:
            headers["If-None-Match"] = etag
        if last_modified:
            headers["If-Modified-Since"] = last_modified
        try:
            result = self._fetcher.fetch(url, headers=headers, policy=policy)
        except HttpFetchError as exc:
            raise FeedFetchError(str(exc)) from exc

        permanent = ""
        hops = tuple(getattr(result, "redirects", ()) or ())
        statuses = tuple(getattr(result, "redirect_statuses", ()) or ())
        if hops and len(statuses) == len(hops) and all(s in (301, 308) for s in statuses):
            permanent = result.url

        if result.status == 304:
            return FeedResponse(not_modified=True, etag=etag, last_modified=last_modified,
                                final_url=result.url, status=304, permanent_url=permanent)
        if result.status in (429, 503):
            retry = parse_retry_after(result.header("retry-after"), now)
            raise FeedFetchError(
                f"The server asked to slow down (HTTP {result.status}).", status=result.status, retry_after=retry)
        if result.status in (404, 410):
            raise FeedFetchError(f"The feed was not found (HTTP {result.status}).", status=result.status)
        if result.status in (401, 403):
            raise FeedFetchError(f"The server refused access to the feed (HTTP {result.status}).",
                                 status=result.status)
        if not 200 <= result.status < 300:
            raise FeedFetchError(f"The server answered with HTTP {result.status}.", status=result.status)
        if not result.body:
            raise FeedFetchError("The server sent an empty response.", status=result.status)
        return FeedResponse(
            not_modified=False,
            body=result.body,
            etag=_validator(result.header("etag")),
            last_modified=_validator(result.header("last-modified")),
            final_url=result.url,
            content_type=(result.header("content-type") or "")[:200],
            status=result.status,
            permanent_url=permanent,
        )

    def fetch_torrent(self, url: str, *, policy: HttpPolicy | None = None) -> bytes:
        """Download a .torrent enclosure (bounded by the policy's response-size limit)."""
        try:
            result = self._fetcher.fetch(url, headers={"Accept": TORRENT_ACCEPT}, policy=policy)
        except HttpFetchError as exc:
            raise FeedFetchError(str(exc)) from exc
        if not 200 <= result.status < 300:
            raise FeedFetchError(
                f"Could not download the torrent file from {safe_url_for_display(url)} (HTTP {result.status}).",
                status=result.status)
        if not result.body:
            raise FeedFetchError("The torrent file download was empty.", status=result.status)
        return result.body
