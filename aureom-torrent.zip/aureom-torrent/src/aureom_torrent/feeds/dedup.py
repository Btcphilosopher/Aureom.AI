"""De-duplication keys for feed entries.

An entry gets several keys; it is considered *already known* when any of them is
present in the persisted history (``feed_seen``):

===========  ========  =====================================================
kind         scope     derived from
===========  ========  =====================================================
``g``        feed      the entry GUID / Atom id
``l``        feed      the canonicalised entry link
``t``        feed      hash of title + download link (only when there is
                       neither a GUID nor a link)
``e``        global    the canonicalised .torrent enclosure URL
``i1``       global    the v1 info-hash
``i2``       global    the v2 info-hash
===========  ========  =====================================================

Feed-scoped keys identify "the same entry in this feed" (so a changed GUID is
tolerated as long as the link, enclosure or identity still matches).  Global
keys identify "the same torrent anywhere" and are what prevents an item that
was already added or dismissed from being added again by another feed.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .models import ParsedEntry

_TRACKING = re.compile(r"^(utm_[a-z0-9_]+|fbclid|gclid|mc_cid|mc_eid|ref_src)$", re.IGNORECASE)
_DEFAULT_PORTS = {"http": 80, "https": 443}

GLOBAL_KINDS = ("e", "i1", "i2")
FEED_KINDS = ("g", "l", "t")


def canonical_url(url: str) -> str:
    """Normalise a URL for comparison (not for fetching)."""
    try:
        parts = urlsplit(url.strip())
        port = parts.port
    except ValueError:
        return url.strip()
    scheme = parts.scheme.lower()
    host = (parts.hostname or "").lower().rstrip(".")
    if port and port != _DEFAULT_PORTS.get(scheme):
        host = f"{host}:{port}"
    path = parts.path or "/"
    if len(path) > 1 and path.endswith("/"):
        path = path.rstrip("/")
    query = urlencode([(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
                       if not _TRACKING.match(k)])
    return urlunsplit((scheme, host, path, query, ""))


def _h(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", "surrogatepass")).hexdigest()[:32]


@dataclass(frozen=True, slots=True)
class DedupKey:
    kind: str
    key: str  # the stored primary key
    feed_scoped: bool


def _feed_key(kind: str, feed_id: int, value: str) -> DedupKey:
    return DedupKey(kind, f"{kind}:{feed_id}:{_h(value)}", True)


def _global_key(kind: str, value: str) -> DedupKey:
    return DedupKey(kind, f"{kind}:*:{value}", False)


def identity_keys(v1: str | None, v2: str | None) -> list[DedupKey]:
    keys = []
    if v1:
        keys.append(_global_key("i1", v1.lower()))
    if v2:
        keys.append(_global_key("i2", v2.lower()))
    return keys


def entry_keys(feed_id: int, entry: ParsedEntry, *, use_link: bool = True) -> list[DedupKey]:
    """All keys for an entry. ``use_link=False`` drops the link key (see :func:`shared_links`)."""
    keys: list[DedupKey] = []
    if entry.guid:
        keys.append(_feed_key("g", feed_id, entry.guid))
    link_usable = bool(entry.link) and use_link
    if link_usable:
        keys.append(_feed_key("l", feed_id, canonical_url(entry.link)))
    if entry.torrent_url:
        keys.append(_global_key("e", _h(canonical_url(entry.torrent_url))))
    keys.extend(identity_keys(entry.v1, entry.v2))
    if not entry.guid and not link_usable:
        download = canonical_url(entry.torrent_url) if entry.torrent_url else (entry.v1 or entry.v2 or "")
        keys.append(_feed_key("t", feed_id, f"{entry.title}\n{download}"))
    return keys


def shared_links(entries: list[ParsedEntry]) -> set[str]:
    """Links used by more than one entry of the same document.

    Some feeds point every item at the same page; such a link does not identify
    an entry and must not be used as a de-duplication key.
    """
    seen: dict[str, int] = {}
    for e in entries:
        if e.link:
            c = canonical_url(e.link)
            seen[c] = seen.get(c, 0) + 1
    return {link for link, count in seen.items() if count > 1}
