"""OPML import and export for subscriptions.

Import is parsed with ``defusedxml`` (entity declarations and external
references are rejected), is size-limited and depth-limited, and only yields
http/https feed addresses.  Folders are nested ``<outline>`` elements; the
nesting is flattened to a ``Parent/Child`` folder path.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Iterable

from defusedxml import ElementTree as SafeET
from defusedxml.common import DefusedXmlException

from .client import validate_feed_url
from .models import Feed, FeedError, OpmlOutline

MAX_OPML_BYTES = 2 * 1024 * 1024
MAX_OUTLINES = 2000
MAX_DEPTH = 16
MAX_TEXT = 300


class OpmlError(FeedError):
    pass


def _clean(value: str | None, limit: int = MAX_TEXT) -> str:
    if not value:
        return ""
    return " ".join("".join(c if ord(c) >= 32 else " " for c in value).split())[:limit]


def parse_opml(text: str | bytes) -> tuple[list[OpmlOutline], int]:
    """Return ``(outlines, invalid_count)``. Raises :class:`OpmlError` for unusable documents."""
    data = text.encode("utf-8") if isinstance(text, str) else bytes(text)
    if not data.strip():
        raise OpmlError("The OPML file is empty.")
    if len(data) > MAX_OPML_BYTES:
        raise OpmlError(f"The OPML file is larger than the {MAX_OPML_BYTES // (1024 * 1024)} MiB limit.")
    try:
        root = SafeET.fromstring(data, forbid_dtd=False, forbid_entities=True, forbid_external=True)
    except DefusedXmlException as exc:
        raise OpmlError("The OPML file uses XML features that are not allowed (entities or external "
                        "references).") from exc
    except ET.ParseError as exc:
        raise OpmlError(f"The OPML file is not well-formed XML ({exc}).") from exc
    if _local(root.tag) != "opml":
        raise OpmlError("This is not an OPML document.")
    body = next((child for child in root if _local(child.tag) == "body"), None)
    if body is None:
        raise OpmlError("The OPML document has no <body>.")

    outlines: list[OpmlOutline] = []
    seen: set[str] = set()
    counters = {"invalid": 0, "visited": 0}

    def walk(node: ET.Element, path: tuple[str, ...]) -> None:  # depth is bounded by MAX_DEPTH
        for child in node:
            if _local(child.tag) != "outline":
                continue
            counters["visited"] += 1
            if counters["visited"] > MAX_OUTLINES * 4:
                raise OpmlError("The OPML file has too many outlines.")
            attrs = {k.lower(): v for k, v in child.attrib.items()}
            url = attrs.get("xmlurl", "")
            label = _clean(attrs.get("title") or attrs.get("text"))
            if url:
                try:
                    valid = validate_feed_url(url)
                except FeedError:
                    counters["invalid"] += 1
                    continue
                if valid in seen:
                    continue
                seen.add(valid)
                if len(outlines) >= MAX_OUTLINES:
                    raise OpmlError(f"The OPML file has more than {MAX_OUTLINES} feeds.")
                category = _clean(attrs.get("category"), 64).split(",")[0].strip()
                outlines.append(OpmlOutline(url=valid, title=label, folder="/".join(path), category=category))
            elif len(path) >= MAX_DEPTH:
                counters["invalid"] += 1
            else:
                walk(child, path + (label.replace("/", "-") or "Folder",))

    walk(body, ())
    return outlines, counters["invalid"]


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower() if isinstance(tag, str) else ""


def export_opml(feeds: Iterable[Feed], *, title: str = "AUREOM TORRENT subscriptions") -> str:
    """Serialise subscriptions as OPML 2.0 with folders as nested outlines."""
    root = ET.Element("opml", {"version": "2.0"})
    head = ET.SubElement(root, "head")
    ET.SubElement(head, "title").text = title
    body = ET.SubElement(root, "body")
    folders: dict[tuple[str, ...], ET.Element] = {(): body}

    def folder_node(path: tuple[str, ...]) -> ET.Element:
        if path in folders:
            return folders[path]
        parent = folder_node(path[:-1])
        node = ET.SubElement(parent, "outline", {"text": path[-1], "title": path[-1]})
        folders[path] = node
        return node

    for feed in sorted(feeds, key=lambda f: (f.folder.lower(), f.display_title.lower())):
        path = tuple(p for p in (s.strip() for s in feed.folder.split("/")) if p)
        attrs = {"type": "rss", "text": feed.display_title, "title": feed.display_title, "xmlUrl": feed.url}
        if feed.site_url:
            attrs["htmlUrl"] = feed.site_url
        if feed.category:
            attrs["category"] = feed.category
        ET.SubElement(folder_node(path), "outline", attrs)
    ET.indent(root)
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode") + "\n"
