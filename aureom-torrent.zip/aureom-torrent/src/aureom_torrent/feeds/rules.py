"""Pure evaluation of automatic-download rules.

Nothing here performs I/O or knows about transfers – and nothing in the feeds
package can reach the payment subsystem: a rule's only possible outcomes are
*add a transfer*, *skip* or *queue for review*.

Limits that need state (per-refresh maximum, daily budget) are applied by the
service; :func:`check_budget` holds the arithmetic so it can be unit-tested.
"""

from __future__ import annotations

from dataclasses import dataclass

import regex

from .models import (ACTION_ADD, ACTION_NEED_SIZE, ACTION_REVIEW, ACTION_SKIP, LINK_NONE, FeedError,
                     FeedRule, RuleDecision)

MAX_TERMS = 32
MAX_TERM_LENGTH = 200
MAX_REGEX_LENGTH = 500
MAX_MATCH_INPUT = 1000
MAX_NAME_LENGTH = 100
MAX_PATH_LENGTH = 4096


class RuleError(FeedError):
    """An invalid rule definition. The message is safe to show."""


@dataclass(frozen=True, slots=True)
class RuleInput:
    title: str
    link_type: str
    size: int | None = None
    size_trusted: bool = False


def _clean_terms(terms) -> list[str]:
    if terms is None:
        return []
    if isinstance(terms, str):
        terms = [t for t in terms.replace("\n", ",").split(",")]
    out: list[str] = []
    for term in terms:
        if not isinstance(term, str):
            raise RuleError("Rule terms must be text.")
        term = term.strip()
        if not term:
            continue
        if len(term) > MAX_TERM_LENGTH:
            raise RuleError(f"A rule term is longer than {MAX_TERM_LENGTH} characters.")
        if term.lower() not in (t.lower() for t in out):
            out.append(term)
    if len(out) > MAX_TERMS:
        raise RuleError(f"A rule can have at most {MAX_TERMS} terms.")
    return out


def validate_rule(rule: FeedRule, *, regex_timeout_ms: int = 100) -> FeedRule:
    """Normalise and validate a rule in place; raises :class:`RuleError`."""
    rule.name = (rule.name or "").strip()[:MAX_NAME_LENGTH]
    rule.include = _clean_terms(rule.include)
    rule.exclude = _clean_terms(rule.exclude)
    rule.regex = (rule.regex or "").strip()
    if len(rule.regex) > MAX_REGEX_LENGTH:
        raise RuleError(f"The regular expression is longer than {MAX_REGEX_LENGTH} characters.")
    if rule.regex:
        try:
            compiled = regex.compile(rule.regex, regex.IGNORECASE)
            compiled.search("", timeout=regex_timeout_ms / 1000)
        except TimeoutError as exc:
            raise RuleError("The regular expression is too slow to evaluate.") from exc
        except regex.error as exc:
            raise RuleError(f"The regular expression is not valid: {exc}") from exc
    rule.category = (rule.category or "").strip()[:64]
    rule.destination = (rule.destination or "").strip()
    if len(rule.destination) > MAX_PATH_LENGTH or "\x00" in rule.destination:
        raise RuleError("The destination path is not valid.")
    for name in ("min_size", "max_size"):
        value = getattr(rule, name)
        if value is not None:
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise RuleError("Size limits must be whole numbers of bytes.")
            if value == 0:
                setattr(rule, name, None)
    if rule.min_size is not None and rule.max_size is not None and rule.min_size > rule.max_size:
        raise RuleError("The minimum size is larger than the maximum size.")
    for name in ("max_per_refresh", "daily_count_budget", "daily_bytes_budget"):
        value = getattr(rule, name)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise RuleError("Rule limits must be whole numbers (0 means no limit).")
    rule.max_per_refresh = min(rule.max_per_refresh, 1000)
    rule.daily_count_budget = min(rule.daily_count_budget, 10_000)
    rule.enabled = bool(rule.enabled)
    rule.add_paused = bool(rule.add_paused)
    return rule


def needs_trusted_size(rule: FeedRule) -> bool:
    return rule.min_size is not None or rule.max_size is not None or rule.daily_bytes_budget > 0


def evaluate_rule(rule: FeedRule, entry: RuleInput, *, regex_timeout_ms: int = 100) -> RuleDecision:
    """Decide what ``rule`` says about ``entry`` (ignoring stateful limits).

    Returns one of:

    * ``skip``      – the rule does not match;
    * ``need_size`` – it matches, but a size limit applies and no trustworthy size is known;
    * ``review``    – it cannot be evaluated safely (e.g. the pattern timed out);
    * ``add``       – it matches and nothing prevents an automatic addition.
    """
    if entry.link_type == LINK_NONE:
        return RuleDecision(ACTION_SKIP, "the entry has no torrent or magnet link", rule.id)
    title = (entry.title or "")[:MAX_MATCH_INPUT]
    folded = title.casefold()
    for term in rule.exclude:
        if term.casefold() in folded:
            return RuleDecision(ACTION_SKIP, f"excluded by “{term}”", rule.id)
    for term in rule.include:
        if term.casefold() not in folded:
            return RuleDecision(ACTION_SKIP, f"does not contain “{term}”", rule.id)
    if rule.regex:
        try:
            matched = regex.search(rule.regex, title, flags=regex.IGNORECASE, timeout=regex_timeout_ms / 1000)
        except TimeoutError:
            return RuleDecision(ACTION_REVIEW, "the regular expression took too long to evaluate", rule.id)
        except regex.error as exc:
            return RuleDecision(ACTION_REVIEW, f"the regular expression is not valid ({exc})", rule.id)
        if not matched:
            return RuleDecision(ACTION_SKIP, "the regular expression does not match", rule.id)

    if needs_trusted_size(rule):
        if entry.size is None or not entry.size_trusted:
            return RuleDecision(ACTION_NEED_SIZE, "a size limit applies and the size is not known from "
                                                  "torrent metadata", rule.id)
        if rule.min_size is not None and entry.size < rule.min_size:
            return RuleDecision(ACTION_SKIP, f"smaller than the minimum size ({entry.size:,} bytes)", rule.id)
        if rule.max_size is not None and entry.size > rule.max_size:
            return RuleDecision(ACTION_SKIP, f"larger than the maximum size ({entry.size:,} bytes)", rule.id)
    return RuleDecision(ACTION_ADD, "matches the rule", rule.id)


def check_budget(rule: FeedRule, *, added_this_refresh: int, added_today: int, bytes_today: int,
                 size: int | None) -> str | None:
    """Return a reason when adding one more item would exceed a limit, else ``None``."""
    if rule.max_per_refresh > 0 and added_this_refresh >= rule.max_per_refresh:
        return f"the per-refresh limit of {rule.max_per_refresh} was reached"
    if rule.daily_count_budget > 0 and added_today >= rule.daily_count_budget:
        return f"the daily budget of {rule.daily_count_budget} additions was reached"
    if rule.daily_bytes_budget > 0:
        if size is None:
            return "the daily size budget needs a known size"
        if bytes_today + size > rule.daily_bytes_budget:
            return f"the daily size budget of {rule.daily_bytes_budget:,} bytes would be exceeded"
    return None
