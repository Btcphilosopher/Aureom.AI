"""The Lightning payment-backend boundary.

``PaymentService`` is written against :class:`LightningBackend` and the neutral
result types below.  Provider-specific wire formats stay inside
``payments.adapters``; the test double lives in ``tests/fakes/payments.py``.

Error contract (important for money safety):

* :class:`BackendUnavailable` – the backend is not configured or the connection
  could not be established.  For ``pay_invoice`` this means the request was
  **not sent**.
* :class:`BackendRejected` – the backend answered with a definitive refusal.
* :class:`PaymentAlreadyKnown` – the backend already has a payment for this
  payment hash (in flight or completed).  Resolve by tracking, never by resending.
* :class:`PaymentOutcomeUnknown` – the request may have been sent but no
  definitive answer was received (timeout, dropped connection, server error).
  This is **not** a failure.
* :class:`PaymentNotFound` – the backend has no record of this payment hash.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Protocol


class BackendError(Exception):
    """Base class; ``str(exc)`` is safe to show and never contains credentials or invoices."""


class BackendUnavailable(BackendError):
    pass


class BackendRejected(BackendError):
    def __init__(self, message: str, *, code: str = ""):
        super().__init__(message)
        self.code = code


class PaymentAlreadyKnown(BackendError):
    pass


class PaymentOutcomeUnknown(BackendError):
    pass


class PaymentNotFound(BackendError):
    pass


class OutgoingStatus(str, enum.Enum):
    IN_FLIGHT = "in_flight"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class IncomingStatus(str, enum.Enum):
    OPEN = "open"
    ACCEPTED = "accepted"  # HTLC held, not yet settled
    SETTLED = "settled"
    CANCELED = "canceled"


@dataclass(frozen=True, slots=True)
class BackendInfo:
    backend: str
    alias: str
    pubkey: str
    network: str  # mainnet | testnet | signet | regtest | "" when unknown
    version: str = ""
    synced: bool = False
    active_channels: int = 0


@dataclass(frozen=True, slots=True)
class DecodedInvoice:
    destination: str
    payment_hash: str
    amount_msat: int | None  # None for an amountless invoice
    timestamp: int
    expiry_s: int
    description: str = ""
    description_hash: str = ""


@dataclass(frozen=True, slots=True)
class PaymentResult:
    """Outcome of an outgoing payment. The preimage is deliberately not part of this type."""

    payment_hash: str
    status: OutgoingStatus
    fee_msat: int | None = None
    amount_msat: int | None = None
    failure_reason: str = ""


@dataclass(frozen=True, slots=True)
class CreatedInvoice:
    payment_hash: str
    payment_request: str


@dataclass(frozen=True, slots=True)
class InvoiceLookup:
    payment_hash: str
    status: IncomingStatus
    amount_paid_msat: int = 0
    value_msat: int | None = None
    settled_at: int | None = None
    expires_at: int | None = None


class LightningBackend(Protocol):
    name: str

    def get_info(self) -> BackendInfo: ...

    def decode_invoice(self, payment_request: str) -> DecodedInvoice: ...

    def pay_invoice(self, payment_request: str, *, amount_msat: int | None, fee_limit_msat: int,
                    timeout_s: int) -> PaymentResult:
        """Pay a BOLT11 invoice. ``amount_msat`` is given only for amountless invoices."""

    def track_payment(self, payment_hash: str) -> PaymentResult:
        """Current state of an outgoing payment (read-only; never sends)."""

    def create_invoice(self, amount_msat: int, *, memo: str, expiry_s: int) -> CreatedInvoice: ...

    def lookup_invoice(self, payment_hash: str) -> InvoiceLookup: ...
