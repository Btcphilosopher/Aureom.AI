"""LND REST adapter (the one Lightning backend supported in this release).

Written against the REST gateway definitions in the lnd repository
(``lnrpc/lightning.yaml``, ``lnrpc/routerrpc/router.yaml`` and the matching
``.proto`` files; checked against ``master`` on 2026-11-25, latest release
v0.21.8-beta):

==================  ======  ==========================================
RPC                 Method  Path
==================  ======  ==========================================
GetInfo             GET     /v1/getinfo
AddInvoice          POST    /v1/invoices
LookupInvoice       GET     /v1/invoice/{r_hash_str}      (hex)
DecodePayReq        GET     /v1/payreq/{pay_req}
SendPaymentV2       POST    /v2/router/send               (streamed)
TrackPaymentV2      GET     /v2/router/track/{payment_hash} (base64, streamed)
==================  ======  ==========================================

Authentication: ``Grpc-Metadata-macaroon: <hex of the macaroon bytes>``.
The macaroon is read from the credential store for every request and is never
logged, stored in SQLite or included in error messages.

Not verified against a live node in this build (see docs/payments.md):
the URL-safe base64 form of ``{payment_hash}``, the response for an unknown
payment hash (expected: gRPC NotFound → HTTP 404), and the exact JSON shape of
an error emitted mid-stream.  All three are handled defensively.

Money-safety rules implemented here:

* ``fee_limit_msat`` is always sent (LND's default of 0 means "zero-fee routes only");
* a connection that could not be established raises ``BackendUnavailable``
  (nothing was sent); anything that goes wrong *after* the request was written
  raises ``PaymentOutcomeUnknown`` – never a failure;
* HTTP 409 (gRPC AlreadyExists) raises ``PaymentAlreadyKnown``;
* the payment preimage returned by LND is dropped at this boundary.
"""

from __future__ import annotations

import base64
import json
import logging
import re
import ssl
from typing import Any, Iterator
from urllib.parse import quote, urlsplit

import httpx

from ...net.http import USER_AGENT, BlockedDestination, HttpFetchError, HttpPolicy, check_url
from ...settings.secrets import SECRET_LND_MACAROON, SecretStore
from ..interface import (BackendInfo, BackendRejected, BackendUnavailable, CreatedInvoice, DecodedInvoice,
                         IncomingStatus, InvoiceLookup, OutgoingStatus, PaymentAlreadyKnown, PaymentNotFound,
                         PaymentOutcomeUnknown, PaymentResult)

log = logging.getLogger(__name__)

BACKEND_NAME = "lnd_rest"
MAX_STREAM_BYTES = 1024 * 1024
SEND_TIMEOUT_MARGIN_S = 30

_HEX = re.compile(r"^[0-9a-fA-F]+$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_LOOPBACK = ("localhost", "127.0.0.1", "::1")
_NETWORKS = {"mainnet": "mainnet", "testnet": "testnet", "testnet3": "testnet", "testnet4": "testnet",
             "signet": "signet", "regtest": "regtest", "simnet": "regtest"}
_NOT_FOUND_HINTS = ("not found", "isn't initiated", "not initiated", "unable to locate", "no such payment")


def _to_int(value: Any, field: str) -> int:
    """grpc-gateway renders (u)int64 as JSON strings; accept strings or integers, never floats."""
    if isinstance(value, bool):
        raise BackendRejected(f"The backend sent a non-numeric value for {field}.")
    if isinstance(value, int):
        return value
    if isinstance(value, str) and re.fullmatch(r"-?[0-9]{1,20}", value):
        return int(value)
    raise BackendRejected(f"The backend sent a non-integer value for {field}.")


def _opt_int(value: Any, field: str) -> int | None:
    if value is None or value == "":
        return None
    return _to_int(value, field)


def _clean(text: Any, limit: int = 200) -> str:
    text = re.sub(r"[\x00-\x1f\x7f]", " ", str(text or ""))
    text = re.sub(r"\bln(?:bc|tb|tbs|bcrt)[0-9a-z]{20,}", "[invoice]", text, flags=re.IGNORECASE)
    return text[:limit].strip()


def hash_to_path_segment(payment_hash_hex: str) -> str:
    """REST ``bytes`` path parameters are base64; the URL-safe alphabet avoids ``/`` in the path."""
    if not _HEX64.match(payment_hash_hex):
        raise ValueError("payment hash must be 64 lower-case hexadecimal characters")
    return base64.urlsafe_b64encode(bytes.fromhex(payment_hash_hex)).decode("ascii")


class LndRestBackend:
    name = BACKEND_NAME

    def __init__(self, base_url: str, *, secrets: SecretStore, policy: HttpPolicy, tls_cert_path: str = "",
                 transport: httpx.BaseTransport | None = None):
        self._base_url = self._validate_base_url(base_url, policy)
        self._secrets = secrets
        self._policy = policy
        self._tls_cert_path = tls_cert_path
        self._transport = transport

    # -- configuration ---------------------------------------------------------
    @staticmethod
    def _validate_base_url(base_url: str, policy: HttpPolicy) -> str:
        url = (base_url or "").strip().rstrip("/")
        if not url:
            raise BackendUnavailable("No LND REST address is configured.")
        try:
            parts = urlsplit(url)
        except ValueError as exc:
            raise BackendUnavailable("The LND REST address is not a valid URL.") from exc
        host = parts.hostname or ""
        if parts.query or parts.fragment:
            raise BackendUnavailable("The LND REST address must not contain a query or fragment.")
        if parts.scheme == "http" and host not in _LOOPBACK:
            raise BackendUnavailable(
                "The LND REST address must use https (plain http is accepted only for this computer).")
        # The backend URL is explicitly configured by the user, so the service policy may allow
        # loopback/private destinations; http is acceptable only for the loopback case above.
        effective = HttpPolicy(timeout_s=policy.timeout_s, max_bytes=policy.max_bytes, max_redirects=0,
                               allow_http=parts.scheme == "http", allow_loopback=policy.allow_loopback,
                               allow_private=policy.allow_private, proxy_url=policy.proxy_url)
        try:
            check_url(url, effective)
        except BlockedDestination as exc:
            raise BackendUnavailable(f"The LND REST address is not allowed: {exc}") from exc
        except HttpFetchError as exc:
            raise BackendUnavailable(f"The LND REST address cannot be used: {exc}") from exc
        return url

    def _macaroon(self) -> str:
        value = (self._secrets.get(SECRET_LND_MACAROON) or "").strip()
        if not value:
            raise BackendUnavailable("No LND macaroon is stored. Add one in Settings → Payments.")
        if not _HEX.match(value) or len(value) % 2:
            raise BackendUnavailable("The stored LND macaroon is not hexadecimal.")
        return value

    def _verify(self) -> Any:
        if self._tls_cert_path:
            try:
                return ssl.create_default_context(cafile=self._tls_cert_path)
            except (OSError, ssl.SSLError) as exc:
                raise BackendUnavailable("The LND TLS certificate file could not be read.") from exc
        return True  # system trust store; verification is never disabled

    def _client(self, read_timeout: int | None = None) -> httpx.Client:
        base = self._policy.timeout_s
        kwargs: dict[str, Any] = dict(
            timeout=httpx.Timeout(read_timeout or base, connect=min(base, 10)),
            follow_redirects=False,
            trust_env=False,
            headers={"User-Agent": USER_AGENT, "Grpc-Metadata-macaroon": self._macaroon()},
        )
        if self._transport is not None:
            kwargs["transport"] = self._transport
        else:
            kwargs["verify"] = self._verify()
            if self._policy.proxy_url:
                kwargs["proxy"] = self._policy.proxy_url
        return httpx.Client(**kwargs)

    # -- low-level helpers -------------------------------------------------------
    @staticmethod
    def _read_limited(resp: httpx.Response, limit: int = 65536) -> bytes:
        body = bytearray()
        for chunk in resp.iter_bytes():
            body += chunk
            if len(body) > limit:
                break
        return bytes(body[:limit])

    @staticmethod
    def _error_body(body: bytes) -> tuple[str, str]:
        """Return ``(message, grpc_code)`` from a grpc-gateway error body, tolerantly."""
        try:
            data = json.loads(body[:65536].decode("utf-8", "replace"))
        except ValueError:
            return "", ""
        if isinstance(data, dict):
            inner = data.get("error") if isinstance(data.get("error"), dict) else data
            return _clean(inner.get("message") or inner.get("error") or ""), str(inner.get("code", ""))
        return "", ""

    def _unary(self, method: str, path: str, *, json_body: dict | None = None) -> dict:
        """A non-payment request. Raises BackendUnavailable / PaymentNotFound / BackendRejected."""
        try:
            with self._client() as client:
                with client.stream(method, self._base_url + path, json=json_body) as resp:
                    declared = resp.headers.get("content-length", "")
                    if declared.isdigit() and int(declared) > self._policy.max_bytes:
                        raise BackendRejected("The backend response is too large.")
                    body = bytearray()
                    for chunk in resp.iter_bytes():
                        body += chunk
                        if len(body) > self._policy.max_bytes:
                            raise BackendRejected("The backend response is too large.")
                    status = resp.status_code
                    if status == 200:
                        try:
                            data = json.loads(body.decode("utf-8"))
                        except ValueError as exc:
                            raise BackendRejected("The backend sent a response that is not valid JSON.") from exc
                        if not isinstance(data, dict):
                            raise BackendRejected("The backend sent an unexpected response.")
                        return data
                    message, code = self._error_body(bytes(body))
        except httpx.TimeoutException as exc:
            raise BackendUnavailable("The Lightning backend did not answer in time.") from exc
        except httpx.HTTPError as exc:
            raise BackendUnavailable(f"Could not reach the Lightning backend ({type(exc).__name__}).") from exc
        if status in (301, 302, 303, 307, 308):
            raise BackendUnavailable("The Lightning backend address redirects elsewhere; redirects are not followed.")
        if status == 404 or code == "5" or any(h in message.lower() for h in _NOT_FOUND_HINTS):
            raise PaymentNotFound(message or "The backend has no such record.")
        if status in (401, 403):
            raise BackendRejected("The backend refused the macaroon (missing permission or wrong node).",
                                  code=str(status))
        if status >= 500:
            raise BackendUnavailable(f"The Lightning backend reported an error (HTTP {status})"
                                     + (f": {message}" if message else "."))
        raise BackendRejected(message or f"The backend rejected the request (HTTP {status}).", code=str(status))

    @staticmethod
    def _iter_stream(resp: httpx.Response) -> Iterator[dict]:
        size = 0
        for line in resp.iter_lines():
            size += len(line)
            if size > MAX_STREAM_BYTES:
                raise PaymentOutcomeUnknown("The backend sent more data than expected; the outcome is unknown.")
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if isinstance(obj, dict):
                yield obj

    @staticmethod
    def _payment_from(obj: dict) -> PaymentResult | None:
        """Extract a Payment update from a stream line, dropping the preimage."""
        payment = obj.get("result") if isinstance(obj.get("result"), dict) else obj
        status = payment.get("status") if isinstance(payment, dict) else None
        if not isinstance(status, str):
            return None
        mapped = {"SUCCEEDED": OutgoingStatus.SUCCEEDED, "FAILED": OutgoingStatus.FAILED,
                  "IN_FLIGHT": OutgoingStatus.IN_FLIGHT, "INITIATED": OutgoingStatus.IN_FLIGHT}.get(status)
        if mapped is None:
            return None  # deprecated UNKNOWN or an unrecognised value: not a definitive answer
        return PaymentResult(
            payment_hash=str(payment.get("payment_hash", "")).lower(),
            status=mapped,
            fee_msat=_opt_int(payment.get("fee_msat"), "fee_msat"),
            amount_msat=_opt_int(payment.get("value_msat"), "value_msat"),
            failure_reason=str(payment.get("failure_reason", ""))[:64] if mapped is OutgoingStatus.FAILED else "",
        )

    # -- LightningBackend --------------------------------------------------------
    def get_info(self) -> BackendInfo:
        data = self._unary("GET", "/v1/getinfo")
        network = ""
        chains = data.get("chains")
        if isinstance(chains, list) and chains and isinstance(chains[0], dict):
            network = _NETWORKS.get(str(chains[0].get("network", "")).lower(), "")
        return BackendInfo(
            backend=BACKEND_NAME,
            alias=_clean(data.get("alias"), 64),
            pubkey=str(data.get("identity_pubkey", "")).lower()[:66],
            network=network,
            version=_clean(data.get("version"), 64),
            synced=bool(data.get("synced_to_chain", False)),
            active_channels=_opt_int(data.get("num_active_channels"), "num_active_channels") or 0,
        )

    def decode_invoice(self, payment_request: str) -> DecodedInvoice:
        data = self._unary("GET", "/v1/payreq/" + quote(payment_request, safe=""))
        msat = _opt_int(data.get("num_msat"), "num_msat")
        return DecodedInvoice(
            destination=str(data.get("destination", "")).lower(),
            payment_hash=str(data.get("payment_hash", "")).lower(),
            amount_msat=msat if msat else None,
            timestamp=_opt_int(data.get("timestamp"), "timestamp") or 0,
            expiry_s=_opt_int(data.get("expiry"), "expiry") or 3600,
            description=_clean(data.get("description"), 640),
            description_hash=str(data.get("description_hash", "")).lower(),
        )

    def pay_invoice(self, payment_request: str, *, amount_msat: int | None, fee_limit_msat: int,
                    timeout_s: int) -> PaymentResult:
        for name, value in (("fee_limit_msat", fee_limit_msat), ("timeout_s", timeout_s)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a non-negative integer")
        body: dict[str, Any] = {
            "payment_request": payment_request,
            "fee_limit_msat": str(fee_limit_msat),
            "timeout_seconds": int(timeout_s),
            "no_inflight_updates": True,
        }
        if amount_msat is not None:
            if isinstance(amount_msat, bool) or not isinstance(amount_msat, int) or amount_msat <= 0:
                raise ValueError("amount_msat must be a positive integer")
            body["amt_msat"] = str(amount_msat)

        client = self._client(read_timeout=timeout_s + SEND_TIMEOUT_MARGIN_S)  # may raise Unavailable
        last: PaymentResult | None = None
        try:
            with client, client.stream("POST", self._base_url + "/v2/router/send", json=body) as resp:
                status = resp.status_code
                if status != 200:
                    message, _code = self._error_body(self._read_limited(resp))
                    if status == 409:
                        raise PaymentAlreadyKnown(
                            "The backend already has a payment for this invoice"
                            + (f" ({message})." if message else "."))
                    if status in (401, 403):
                        raise BackendRejected(
                            "The backend refused the macaroon (it needs the offchain:write permission).",
                            code=str(status))
                    if 400 <= status < 500 and status not in (408, 429):
                        raise BackendRejected(message or f"The backend rejected the payment (HTTP {status}).",
                                              code=str(status))
                    # 5xx / 408 / 429: the backend may or may not have started the payment.
                    raise PaymentOutcomeUnknown(
                        f"The backend answered HTTP {status}" + (f" ({message})" if message else "")
                        + "; the outcome is unknown until it is reconciled.")
                for obj in self._iter_stream(resp):
                    if isinstance(obj.get("error"), dict) and "result" not in obj:
                        message = _clean(obj["error"].get("message"))
                        raise PaymentOutcomeUnknown(
                            "The backend reported an error while the payment was in progress"
                            + (f" ({message})" if message else "") + "; the outcome is unknown.")
                    update = self._payment_from(obj)
                    if update is None:
                        continue
                    last = update
                    if update.status in (OutgoingStatus.SUCCEEDED, OutgoingStatus.FAILED):
                        return update
        except (httpx.ConnectError, httpx.ConnectTimeout) as exc:
            # The connection was never established, so the request was not sent.
            raise BackendUnavailable(
                f"Could not connect to the Lightning backend ({type(exc).__name__}); nothing was sent.") from exc
        except httpx.HTTPError as exc:
            if last is not None:
                return last
            raise PaymentOutcomeUnknown(
                f"The connection to the backend was lost ({type(exc).__name__}) before it reported "
                "the outcome.") from exc
        if last is not None:
            return last  # the stream ended while the payment was still in flight
        raise PaymentOutcomeUnknown("The backend closed the connection without reporting an outcome.")

    def track_payment(self, payment_hash: str) -> PaymentResult:
        path = "/v2/router/track/" + hash_to_path_segment(payment_hash) + "?no_inflight_updates=false"
        try:
            with self._client() as client, client.stream("GET", self._base_url + path) as resp:
                status = resp.status_code
                if status != 200:
                    message, code = self._error_body(self._read_limited(resp))
                    if status == 404 or code == "5" or any(h in message.lower() for h in _NOT_FOUND_HINTS):
                        raise PaymentNotFound("The backend has no record of this payment.")
                    if status in (401, 403):
                        raise BackendRejected(
                            "The backend refused the macaroon (it needs the offchain:read permission).",
                            code=str(status))
                    raise BackendUnavailable(f"The backend could not report the payment state (HTTP {status}).")
                for obj in self._iter_stream(resp):
                    if isinstance(obj.get("error"), dict) and "result" not in obj:
                        message = _clean(obj["error"].get("message"))
                        if str(obj["error"].get("code", "")) == "5" or any(
                                h in message.lower() for h in _NOT_FOUND_HINTS):
                            raise PaymentNotFound("The backend has no record of this payment.")
                        raise BackendUnavailable("The backend could not report the payment state.")
                    update = self._payment_from(obj)
                    if update is not None:
                        return update  # the first update is the current state; do not wait for the end
        except PaymentOutcomeUnknown as exc:
            raise BackendUnavailable(str(exc)) from exc
        except httpx.TimeoutException as exc:
            raise BackendUnavailable("The Lightning backend did not answer in time.") from exc
        except httpx.HTTPError as exc:
            raise BackendUnavailable(f"Could not reach the Lightning backend ({type(exc).__name__}).") from exc
        raise BackendUnavailable("The backend closed the connection without reporting the payment state.")

    def create_invoice(self, amount_msat: int, *, memo: str, expiry_s: int) -> CreatedInvoice:
        if isinstance(amount_msat, bool) or not isinstance(amount_msat, int) or amount_msat <= 0:
            raise ValueError("amount_msat must be a positive integer")
        data = self._unary("POST", "/v1/invoices", json_body={
            "memo": memo, "value_msat": str(amount_msat), "expiry": str(int(expiry_s))})
        pr = data.get("payment_request")
        r_hash = data.get("r_hash")
        if not isinstance(pr, str) or not isinstance(r_hash, str):
            raise BackendRejected("The backend did not return an invoice.")
        try:
            payment_hash = base64.b64decode(r_hash.replace("-", "+").replace("_", "/"), validate=True).hex()
        except ValueError as exc:
            raise BackendRejected("The backend returned an unreadable payment hash.") from exc
        if not _HEX64.match(payment_hash):
            raise BackendRejected("The backend returned an unreadable payment hash.")
        return CreatedInvoice(payment_hash=payment_hash, payment_request=pr.lower())

    def lookup_invoice(self, payment_hash: str) -> InvoiceLookup:
        if not _HEX64.match(payment_hash):
            raise ValueError("payment hash must be 64 lower-case hexadecimal characters")
        data = self._unary("GET", "/v1/invoice/" + payment_hash)
        state = str(data.get("state", "OPEN")).upper()
        status = {"SETTLED": IncomingStatus.SETTLED, "CANCELED": IncomingStatus.CANCELED,
                  "ACCEPTED": IncomingStatus.ACCEPTED, "PENDING_SETTLE": IncomingStatus.ACCEPTED,
                  "OPEN": IncomingStatus.OPEN}.get(state, IncomingStatus.OPEN)
        created = _opt_int(data.get("creation_date"), "creation_date")
        expiry = _opt_int(data.get("expiry"), "expiry")
        settle = _opt_int(data.get("settle_date"), "settle_date")
        return InvoiceLookup(
            payment_hash=payment_hash,
            status=status,
            amount_paid_msat=_opt_int(data.get("amt_paid_msat"), "amt_paid_msat") or 0,
            value_msat=_opt_int(data.get("value_msat"), "value_msat"),
            settled_at=settle if settle else None,
            expires_at=(created + expiry) if created and expiry else None,
        )
