"""Integer-only Bitcoin amounts.

Internal accounting uses **millisatoshis** (Lightning) or **satoshis**
(on-chain) as Python ``int``.  Floating point is never used for amounts; BTC
decimal strings are produced and parsed with integer arithmetic.

Rounding rules at boundaries (see docs/payments.md):

* msat → sat for *display of money you pay* (amounts and fees) rounds **up**
  (:func:`msat_to_sat_ceil`), so the UI never understates a cost;
* msat → sat for *display of money you receive* rounds **down**
  (:func:`msat_to_sat_floor`), so the UI never overstates income;
* values sent to a backend are always the exact msat integer; the backend's
  satoshi-denominated fields are ignored whenever an ``_msat`` field exists;
* BIP21 amounts are whole satoshis rendered as an exact BTC decimal.
"""

from __future__ import annotations

import re

MSAT_PER_SAT = 1000
SAT_PER_BTC = 100_000_000
MAX_SAT = 21_000_000 * SAT_PER_BTC
MAX_MSAT = MAX_SAT * MSAT_PER_SAT

# ASCII digits only: ``\d`` would also accept other Unicode digit characters.
_BTC_DECIMAL = re.compile(r"^([0-9]{1,8})(?:\.([0-9]{1,8}))?$")
_WHOLE = re.compile(r"^[0-9]{1,17}$")


class AmountError(ValueError):
    """An amount that cannot be used. The message is safe to show to the user."""


def require_int(value: object, what: str = "amount") -> int:
    """Reject bools, floats, Decimals and strings: amounts must be plain integers."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise AmountError(f"The {what} must be a whole number (got {type(value).__name__}).")
    return int(value)


def require_msat(value: object, what: str = "amount") -> int:
    v = require_int(value, what)
    if v < 0 or v > MAX_MSAT:
        raise AmountError(f"The {what} is out of range.")
    return v


def sat_to_msat(sat: int) -> int:
    v = require_int(sat, "satoshi amount")
    if v < 0 or v > MAX_SAT:
        raise AmountError("The satoshi amount is out of range.")
    return v * MSAT_PER_SAT


def msat_to_sat_floor(msat: int) -> int:
    """Whole satoshis, rounded down (use for amounts received)."""
    return require_msat(msat) // MSAT_PER_SAT


def msat_to_sat_ceil(msat: int) -> int:
    """Whole satoshis, rounded up (use for amounts and fees paid)."""
    return -(-require_msat(msat) // MSAT_PER_SAT)


def msat_is_whole_sat(msat: int) -> bool:
    return require_msat(msat) % MSAT_PER_SAT == 0


def _group(n: int) -> str:
    return f"{n:,}"


def format_sats(sat: int) -> str:
    v = require_int(sat, "satoshi amount")
    return f"{_group(v)} sat" + ("" if v == 1 else "s")


def format_msat(msat: int) -> str:
    """Exact rendering, e.g. ``1,234 sats`` or ``1,234.567 sats`` (no rounding)."""
    v = require_msat(msat)
    whole, frac = divmod(v, MSAT_PER_SAT)
    if frac == 0:
        return format_sats(whole)
    return f"{_group(whole)}.{frac:03d} sats"


def format_btc(sat: int, *, trim: bool = False) -> str:
    """Exact BTC decimal with 8 places (``trim=True`` drops trailing zeros, keeping one digit)."""
    v = require_int(sat, "satoshi amount")
    if v < 0 or v > MAX_SAT:
        raise AmountError("The satoshi amount is out of range.")
    whole, frac = divmod(v, SAT_PER_BTC)
    text = f"{whole}.{frac:08d}"
    if trim:
        text = text.rstrip("0")
        if text.endswith("."):
            text = text[:-1]
    return text


def parse_btc_decimal(text: object) -> int:
    """Strictly parse a BTC decimal string (as used by BIP21) into satoshis.

    Accepts ``digits`` or ``digits.digits`` with at most eight decimal places.
    Rejects signs, exponents, thousands separators, whitespace inside the
    number, more than eight decimals, and anything that is not a ``str``.
    """
    if not isinstance(text, str):
        raise AmountError("A BTC amount must be given as text, not as a number.")
    m = _BTC_DECIMAL.match(text.strip())
    if not m:
        raise AmountError("The BTC amount is not a plain decimal with at most 8 decimal places.")
    whole = int(m.group(1))
    frac_text = (m.group(2) or "").ljust(8, "0")
    sat = whole * SAT_PER_BTC + int(frac_text)
    if sat > MAX_SAT:
        raise AmountError("The BTC amount exceeds the total bitcoin supply.")
    return sat


def parse_sats(text: object) -> int:
    """Strictly parse a whole number of satoshis typed by the user (digits, optional , or _ grouping)."""
    if isinstance(text, bool):
        raise AmountError("The amount must be a whole number of satoshis.")
    if isinstance(text, int):
        value = text
    elif isinstance(text, str):
        cleaned = text.strip().replace(",", "").replace("_", "").replace(" ", "")
        if not _WHOLE.match(cleaned):
            raise AmountError("The amount must be a whole number of satoshis.")
        value = int(cleaned)
    else:
        raise AmountError("The amount must be a whole number of satoshis.")
    if value < 0 or value > MAX_SAT:
        raise AmountError("The satoshi amount is out of range.")
    return value


def fee_cap_msat(amount_msat: int, ppm: int, floor_sat: int) -> int:
    """``ceil(amount × ppm / 1 000 000)``, but never below ``floor_sat`` satoshis. Integer maths only."""
    amount = require_msat(amount_msat)
    ppm = require_int(ppm, "fee rate")
    floor_sat = require_int(floor_sat, "fee floor")
    if ppm < 0 or floor_sat < 0:
        raise AmountError("Fee parameters cannot be negative.")
    proportional = -(-(amount * ppm) // 1_000_000)
    return max(proportional, floor_sat * MSAT_PER_SAT)
