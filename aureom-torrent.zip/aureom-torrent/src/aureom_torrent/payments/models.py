"""Payment domain models and the explicit payment state machine."""

from __future__ import annotations

import enum
from dataclasses import dataclass, replace


class PaymentState(str, enum.Enum):
    DRAFT = "draft"
    AWAITING_APPROVAL = "awaiting_approval"
    SUBMITTED = "submitted"
    PENDING = "pending"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    EXPIRED = "expired"
    UNKNOWN = "unknown"  # unknown outcome: never assume failure, never retry blindly
    CANCELLED = "cancelled"  # cancelled before submission

    @property
    def label(self) -> str:
        return _STATE_LABELS[self]

    @property
    def terminal(self) -> bool:
        return self in TERMINAL_STATES


class PaymentDirection(str, enum.Enum):
    OUTGOING = "outgoing"
    INCOMING = "incoming"


class PaymentKind(str, enum.Enum):
    LIGHTNING_INVOICE = "lightning_invoice"  # pay a publisher's BOLT11 invoice
    LIGHTNING_TIP = "lightning_tip"  # one-off tip: invoice obtained through LNURL-pay
    BITCOIN_EXTERNAL = "bitcoin_external"  # BIP21 request handed to an external wallet
    LIGHTNING_RECEIVE = "lightning_receive"  # incoming invoice created on the backend

    @property
    def label(self) -> str:
        return {
            PaymentKind.LIGHTNING_INVOICE: "Lightning invoice",
            PaymentKind.LIGHTNING_TIP: "Lightning tip",
            PaymentKind.BITCOIN_EXTERNAL: "Bitcoin (external wallet)",
            PaymentKind.LIGHTNING_RECEIVE: "Lightning invoice (incoming)",
        }[self]


class PublisherTrust(str, enum.Enum):
    VERIFIED = "verified"  # a signed manifest whose key the user has chosen to trust
    SELF_ASSERTED = "self_asserted"  # unsigned or untrusted-key manifest: the publisher's own claim
    UNKNOWN = "unknown"

    @property
    def label(self) -> str:
        return {
            PublisherTrust.VERIFIED: "Verified (signed manifest, key trusted by you)",
            PublisherTrust.SELF_ASSERTED: "Self-asserted (not verified)",
            PublisherTrust.UNKNOWN: "Unknown publisher",
        }[self]


_STATE_LABELS = {
    PaymentState.DRAFT: "Draft",
    PaymentState.AWAITING_APPROVAL: "Awaiting your approval",
    PaymentState.SUBMITTED: "Submitted",
    PaymentState.PENDING: "Pending",
    PaymentState.SUCCEEDED: "Succeeded",
    PaymentState.FAILED: "Failed",
    PaymentState.EXPIRED: "Expired",
    PaymentState.UNKNOWN: "Unknown outcome",
    PaymentState.CANCELLED: "Cancelled before submission",
}

TERMINAL_STATES = frozenset(
    {PaymentState.SUCCEEDED, PaymentState.FAILED, PaymentState.EXPIRED, PaymentState.CANCELLED})

# States in which an outgoing payment for a given payment hash may have moved (or may yet move)
# money.  A second outgoing intent for the same hash is refused while one of these exists.
BLOCKING_STATES = frozenset(
    {PaymentState.SUBMITTED, PaymentState.PENDING, PaymentState.UNKNOWN, PaymentState.SUCCEEDED})

# Transitions valid for every kind of payment.
_TRANSITIONS: dict[PaymentState, frozenset[PaymentState]] = {
    PaymentState.DRAFT: frozenset({PaymentState.AWAITING_APPROVAL, PaymentState.CANCELLED, PaymentState.FAILED}),
    PaymentState.AWAITING_APPROVAL: frozenset(
        {PaymentState.SUBMITTED, PaymentState.CANCELLED, PaymentState.EXPIRED}),
    PaymentState.SUBMITTED: frozenset(
        {PaymentState.PENDING, PaymentState.SUCCEEDED, PaymentState.FAILED, PaymentState.UNKNOWN}),
    PaymentState.PENDING: frozenset({PaymentState.SUCCEEDED, PaymentState.FAILED, PaymentState.UNKNOWN}),
    # Only reconciliation against the backend may leave UNKNOWN.
    PaymentState.UNKNOWN: frozenset({PaymentState.PENDING, PaymentState.SUCCEEDED, PaymentState.FAILED}),
    PaymentState.SUCCEEDED: frozenset(),
    PaymentState.FAILED: frozenset(),
    PaymentState.EXPIRED: frozenset(),
    PaymentState.CANCELLED: frozenset(),
}

# Kind-specific additions / replacements.
_KIND_TRANSITIONS: dict[PaymentKind, dict[PaymentState, frozenset[PaymentState]]] = {
    # An incoming invoice has no approval step: it becomes PENDING once the backend created it,
    # and an unpaid invoice can expire.
    PaymentKind.LIGHTNING_RECEIVE: {
        PaymentState.DRAFT: frozenset({PaymentState.PENDING, PaymentState.FAILED, PaymentState.CANCELLED}),
        PaymentState.AWAITING_APPROVAL: frozenset(),
        PaymentState.SUBMITTED: frozenset(),
        PaymentState.PENDING: frozenset({PaymentState.SUCCEEDED, PaymentState.FAILED, PaymentState.EXPIRED}),
        PaymentState.UNKNOWN: frozenset(),
    },
    # A BIP21 hand-off is never submitted by this application.  Opening the wallet moves the
    # record to UNKNOWN ("handed to external wallet — outcome not tracked") and it stays there:
    # no backend observes the chain in this release, so it can never become SUCCEEDED.
    PaymentKind.BITCOIN_EXTERNAL: {
        PaymentState.AWAITING_APPROVAL: frozenset({PaymentState.UNKNOWN, PaymentState.CANCELLED}),
        PaymentState.SUBMITTED: frozenset(),
        PaymentState.PENDING: frozenset(),
        PaymentState.UNKNOWN: frozenset(),
    },
}


def allowed_transitions(state: PaymentState, kind: PaymentKind | None = None) -> frozenset[PaymentState]:
    if kind is not None:
        override = _KIND_TRANSITIONS.get(kind, {})
        if state in override:
            return override[state]
    return _TRANSITIONS[state]


def can_transition(src: PaymentState, dst: PaymentState, kind: PaymentKind | None = None) -> bool:
    return dst in allowed_transitions(src, kind)


class PaymentError(Exception):
    """Base class for payment problems; ``str(exc)`` is safe to show to the user."""


class InvalidPaymentState(PaymentError):
    pass


class DuplicatePayment(PaymentError):
    def __init__(self, message: str, existing_id: str):
        super().__init__(message)
        self.existing_id = existing_id


class PaymentLimitError(PaymentError):
    pass


@dataclass(frozen=True, slots=True)
class PublisherRef:
    """Who a payment is associated with. Purely informational: it never selects a destination."""

    name: str = ""
    trust: PublisherTrust = PublisherTrust.UNKNOWN
    manifest_id: str | None = None


@dataclass(slots=True)
class PaymentIntent:
    id: str
    direction: PaymentDirection
    kind: PaymentKind
    state: PaymentState
    network: str  # mainnet | testnet | signet | regtest
    amount_msat: int | None = None  # None only for a BIP21 request whose amount is chosen in the wallet
    fee_limit_msat: int | None = None
    fee_paid_msat: int | None = None
    backend: str = ""
    payment_hash: str | None = None
    destination: str = ""  # payee node public key, or Bitcoin address
    description: str = ""
    invoice: str | None = None  # BOLT11; cleared once an outgoing payment is terminal
    expires_at: int | None = None
    publisher_name: str = ""
    publisher_trust: PublisherTrust = PublisherTrust.UNKNOWN
    transfer_id: str | None = None
    manifest_id: str | None = None
    note: str = ""
    error: str = ""
    created_at: int = 0
    updated_at: int = 0
    submitted_at: int | None = None
    settled_at: int | None = None

    def copy(self) -> "PaymentIntent":
        return replace(self)

    @property
    def is_lightning(self) -> bool:
        return self.kind is not PaymentKind.BITCOIN_EXTERNAL

    @property
    def state_label(self) -> str:
        if self.kind is PaymentKind.BITCOIN_EXTERNAL and self.state is PaymentState.UNKNOWN:
            return "Handed to external wallet — outcome not tracked"
        if self.kind is PaymentKind.BITCOIN_EXTERNAL and self.state is PaymentState.AWAITING_APPROVAL:
            return "Ready to open in your wallet"
        if self.kind is PaymentKind.LIGHTNING_RECEIVE and self.state is PaymentState.PENDING:
            return "Waiting for payment"
        if self.kind is PaymentKind.LIGHTNING_RECEIVE and self.state is PaymentState.SUCCEEDED:
            return "Settled"
        return self.state.label


@dataclass(frozen=True, slots=True)
class PaymentEvent:
    ts: int
    from_state: PaymentState | None
    to_state: PaymentState
    detail: str


@dataclass(frozen=True, slots=True)
class ApprovalSummary:
    """Everything the approval dialog must show before an outgoing payment."""

    intent_id: str
    kind: PaymentKind
    amount_msat: int | None
    amount_text: str
    network: str
    destination: str  # payee node public key / Bitcoin address
    destination_source: str  # where the destination information came from
    publisher_name: str
    publisher_trust: PublisherTrust
    trust_label: str
    description: str
    expires_at: int | None
    seconds_until_expiry: int | None
    suggested_fee_limit_msat: int | None
    max_fee_limit_msat: int | None
    backend_name: str
    backend_alias: str
    payment_hash_short: str
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class BackendStatus:
    configured: bool
    connected: bool
    name: str = ""
    alias: str = ""
    network: str = ""
    network_matches: bool = True
    synced: bool = False
    version: str = ""
    message: str = ""
