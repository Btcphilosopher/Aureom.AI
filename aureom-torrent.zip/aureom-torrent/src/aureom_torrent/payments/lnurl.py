"""Minimal LNURL-pay (LUD-06) and Lightning address (LUD-16) client for one-off tips.

Scope, deliberately small:

* resolve ``user@domain`` to ``https://domain/.well-known/lnurlp/user`` (LUD-16),
  or decode a bech32 ``lnurl1…`` string, or accept an ``https://`` LNURL-pay URL;
* fetch the pay parameters and request **one** invoice for an exact amount;
* verify that the returned BOLT11 invoice is for exactly the requested amount
  and commits to the service's metadata (``description_hash == sha256(metadata)``).

Everything else in the LNURL family (auth, withdraw, channel, success actions,
payer data, comments beyond a plain string) is unsupported.  ``successAction``
values are ignored and never opened.

These calls contact the publisher's server, which learns the caller's IP
address (or the proxy's).  They are only ever made from an explicit user action.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from urllib.parse import urlsplit

import bech32

from ..net.http import Fetcher, HttpFetchError, HttpPolicy, check_url
from .amounts import format_msat, require_msat
from .invoices import InvoiceError, decode_invoice, sanitise_text

MAX_LNURL_LENGTH = 2048
MAX_METADATA_BYTES = 16 * 1024
MAX_RESPONSE_BYTES = 64 * 1024

_ADDRESS = re.compile(r"^([a-z0-9._+-]{1,64})@([a-z0-9.-]{1,253})(?::([0-9]{1,5}))?$")
_LOOPBACK_HOSTS = ("localhost", "127.0.0.1", "::1")


class LnurlError(ValueError):
    """A tip destination that cannot be used. The message is safe to show."""


@dataclass(frozen=True, slots=True)
class PayParams:
    url: str  # where the parameters were fetched from
    domain: str
    callback: str
    min_sendable_msat: int
    max_sendable_msat: int
    metadata: str  # raw metadata string; the invoice must commit to its SHA-256
    description: str  # text/plain entry of the metadata, sanitised for display
    comment_allowed: int = 0


def tip_policy(base: HttpPolicy) -> HttpPolicy:
    """Policy for contacting a publisher's LNURL server: https only, public addresses only."""
    return HttpPolicy(timeout_s=min(base.timeout_s, 20), max_bytes=MAX_RESPONSE_BYTES, max_redirects=2,
                      allow_http=False, allow_loopback=False, allow_private=False, proxy_url=base.proxy_url)


def resolve_target(text: object, *, allow_http_loopback: bool = False) -> str:
    """Turn a Lightning address, ``lnurl1…`` string or https URL into the LNURL-pay endpoint URL."""
    if not isinstance(text, str):
        raise LnurlError("Enter a Lightning address such as name@example.org.")
    value = text.strip()
    if len(value) > MAX_LNURL_LENGTH or not value:
        raise LnurlError("Enter a Lightning address such as name@example.org.")
    if value[:10].lower() == "lightning:":
        value = value[10:]
    lower = value.lower()
    if lower.startswith("lnurl1"):
        hrp, data = bech32.bech32_decode(lower)
        if hrp != "lnurl" or data is None:
            raise LnurlError("This LNURL string is not valid.")
        raw = bech32.convertbits(data, 5, 8, False)
        if raw is None:
            raise LnurlError("This LNURL string is not valid.")
        try:
            url = bytes(raw).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise LnurlError("This LNURL string does not contain a web address.") from exc
    elif lower.startswith(("https://", "http://")):
        url = value
    else:
        m = _ADDRESS.match(lower)
        if not m:
            raise LnurlError("This is not a Lightning address (expected name@example.org).")
        user, domain, port = m.group(1), m.group(2), m.group(3)
        if domain.endswith(".onion"):
            raise LnurlError("Onion Lightning addresses are not supported.")
        scheme = "http" if (allow_http_loopback and domain in _LOOPBACK_HOSTS) else "https"
        url = f"{scheme}://{domain}{':' + port if port else ''}/.well-known/lnurlp/{user}"
    _check_scheme(url, allow_http_loopback)
    return url


def _check_scheme(url: str, allow_http_loopback: bool) -> None:
    try:
        parts = urlsplit(url)
    except ValueError as exc:
        raise LnurlError("The tip address is not a valid web address.") from exc
    if parts.scheme == "https":
        return
    if parts.scheme == "http" and allow_http_loopback and (parts.hostname or "") in _LOOPBACK_HOSTS:
        return
    raise LnurlError("Tip services must use https.")


class LnurlPayClient:
    def __init__(self, fetcher: Fetcher, policy: HttpPolicy):
        self._fetcher = fetcher
        self._policy = policy
        # http is acceptable only for an explicitly allowed loopback endpoint (local testing).
        self._http_loopback = bool(policy.allow_http and policy.allow_loopback)

    def _get_json(self, url: str) -> dict:
        _check_scheme(url, self._http_loopback)
        try:
            check_url(url, self._policy)
            result = self._fetcher.fetch(url, headers={"Accept": "application/json"}, policy=self._policy)
        except HttpFetchError as exc:
            raise LnurlError(f"Could not contact the tip service: {exc}") from exc
        if result.status != 200:
            raise LnurlError(f"The tip service answered with HTTP {result.status}.")
        try:
            data = json.loads(result.body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError, RecursionError) as exc:
            raise LnurlError("The tip service sent a response that is not valid JSON.") from exc
        if not isinstance(data, dict):
            raise LnurlError("The tip service sent an unexpected response.")
        if str(data.get("status", "")).upper() == "ERROR":
            raise LnurlError("The tip service refused the request: "
                             + (sanitise_text(str(data.get("reason", "")), 160) or "no reason given"))
        return data

    def fetch_params(self, target: str) -> PayParams:
        url = resolve_target(target, allow_http_loopback=self._http_loopback)
        data = self._get_json(url)
        if data.get("tag") != "payRequest":
            raise LnurlError("This address is not an LNURL-pay endpoint (only tips by payment are supported).")
        callback = data.get("callback")
        metadata = data.get("metadata")
        lo, hi = data.get("minSendable"), data.get("maxSendable")
        if not isinstance(callback, str) or len(callback) > MAX_LNURL_LENGTH:
            raise LnurlError("The tip service did not provide a usable callback address.")
        _check_scheme(callback, self._http_loopback)
        if not isinstance(metadata, str) or len(metadata.encode("utf-8")) > MAX_METADATA_BYTES:
            raise LnurlError("The tip service sent unusable metadata.")
        if isinstance(lo, bool) or isinstance(hi, bool) or not isinstance(lo, int) or not isinstance(hi, int):
            raise LnurlError("The tip service sent amount limits that are not whole numbers.")
        if lo < 1 or hi < lo:
            raise LnurlError("The tip service sent inconsistent amount limits.")
        comment_allowed = data.get("commentAllowed", 0)
        if isinstance(comment_allowed, bool) or not isinstance(comment_allowed, int) or comment_allowed < 0:
            comment_allowed = 0
        return PayParams(url=url, domain=urlsplit(url).hostname or "", callback=callback,
                         min_sendable_msat=lo, max_sendable_msat=hi, metadata=metadata,
                         description=_plain_description(metadata), comment_allowed=min(comment_allowed, 2000))

    def request_invoice(self, params: PayParams, amount_msat: int, *, comment: str = "") -> str:
        """Ask the service for an invoice for exactly ``amount_msat`` and verify what comes back."""
        amount = require_msat(amount_msat)
        if amount < params.min_sendable_msat or amount > params.max_sendable_msat:
            raise LnurlError(
                f"This publisher accepts tips between {format_msat(params.min_sendable_msat)} and "
                f"{format_msat(params.max_sendable_msat)}.")
        sep = "&" if urlsplit(params.callback).query else "?"
        url = f"{params.callback}{sep}amount={amount}"
        if comment and params.comment_allowed:
            from urllib.parse import quote

            url += "&comment=" + quote(sanitise_text(comment, params.comment_allowed), safe="")
        data = self._get_json(url)
        pr = data.get("pr")
        if not isinstance(pr, str):
            raise LnurlError("The tip service did not return an invoice.")
        try:
            normalised, inv = decode_invoice(pr)
        except InvoiceError as exc:
            raise LnurlError(f"The tip service returned an unusable invoice: {exc}") from exc
        if inv.amount_msat is None or int(inv.amount_msat) != amount:
            raise LnurlError("The tip service returned an invoice for a different amount than requested; "
                             "it was rejected.")
        expected = hashlib.sha256(params.metadata.encode("utf-8")).hexdigest()
        if str(inv.description_hash or "").lower() != expected:
            raise LnurlError("The invoice returned by the tip service does not match the service's "
                             "description; it was rejected.")
        return normalised


def _plain_description(metadata: str) -> str:
    try:
        items = json.loads(metadata)
    except (ValueError, RecursionError):
        return ""
    if not isinstance(items, list):
        return ""
    for item in items[:32]:
        if isinstance(item, list) and len(item) == 2 and item[0] == "text/plain" and isinstance(item[1], str):
            return sanitise_text(item[1])
    return ""
