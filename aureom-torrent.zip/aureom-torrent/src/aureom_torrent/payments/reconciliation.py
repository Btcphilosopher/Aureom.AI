"""Reconciliation of payments whose outcome is not yet known.

Strategy (documented in docs/payments.md):

* The **payment hash** of the invoice is the stable identifier.  LND refuses a
  second payment for a hash that is in flight or already paid, and
  ``TrackPaymentV2`` reports the state of a payment by hash.
* Reconciliation is **read-only**: it tracks, it never (re)submits.
* A timeout or dropped connection during submission leaves the intent in
  ``UNKNOWN``.  It leaves that state only when the backend reports the payment
  as succeeded, failed or in flight – or when the backend has *no record* of
  the hash **and** the invoice has expired (plus a safety margin), because an
  expired invoice can no longer be paid.
* While the backend has no record and the invoice is still valid, the intent
  stays ``UNKNOWN`` and a second submission for the same hash is refused.

The decision logic is a pure function so it can be tested exhaustively.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .interface import IncomingStatus, InvoiceLookup, OutgoingStatus, PaymentResult
from .models import PaymentIntent, PaymentState

NOT_FOUND_EXPIRY_MARGIN_S = 120

FAILURE_TEXT = {
    "FAILURE_REASON_TIMEOUT": "the payment timed out before a route succeeded",
    "FAILURE_REASON_NO_ROUTE": "no route to the recipient was found within the fee limit",
    "FAILURE_REASON_ERROR": "the backend reported a payment error",
    "FAILURE_REASON_INCORRECT_PAYMENT_DETAILS": "the recipient rejected the payment details "
                                                "(wrong amount, expired or unknown invoice)",
    "FAILURE_REASON_INSUFFICIENT_BALANCE": "the node does not have enough outbound balance",
    "FAILURE_REASON_CANCELED": "the payment was cancelled at the backend",
    "FAILURE_REASON_NONE": "the backend reported a failure without a reason",
}


def failure_text(reason: str) -> str:
    return FAILURE_TEXT.get(reason, "the backend reported a failure" + (f" ({reason[:60]})" if reason else ""))


@dataclass(frozen=True, slots=True)
class Decision:
    state: PaymentState | None  # None = leave the state unchanged
    detail: str
    fee_paid_msat: int | None = None
    error: str = ""
    settled: bool = False


def decide_outgoing(intent: PaymentIntent, result: PaymentResult | None, *, now: int) -> Decision:
    """Map a tracking result (``None`` = backend has no record of the hash) to a state decision."""
    if result is None:
        expired = intent.expires_at is not None and now > intent.expires_at + NOT_FOUND_EXPIRY_MARGIN_S
        if expired:
            return Decision(PaymentState.FAILED, "never initiated; invoice expired",
                            error="Not sent: the backend has no record of this payment and the invoice has expired.")
        note = ("The backend has no record of this payment yet. It stays “unknown” until the backend "
                "reports it or the invoice expires. Do not pay this invoice again from another wallet.")
        if intent.state is PaymentState.UNKNOWN:
            return Decision(None, "backend has no record; invoice still valid", error=note)
        return Decision(PaymentState.UNKNOWN, "backend has no record; invoice still valid", error=note)
    if result.status is OutgoingStatus.SUCCEEDED:
        return Decision(PaymentState.SUCCEEDED, "backend reports the payment succeeded",
                        fee_paid_msat=result.fee_msat, settled=True)
    if result.status is OutgoingStatus.FAILED:
        return Decision(PaymentState.FAILED, "backend reports the payment failed: " + failure_text(result.failure_reason),
                        error="Payment failed: " + failure_text(result.failure_reason) + ".")
    if intent.state is PaymentState.PENDING:
        return Decision(None, "still in flight")
    return Decision(PaymentState.PENDING, "backend reports the payment is in flight")


def decide_incoming(intent: PaymentIntent, lookup: InvoiceLookup | None, *, now: int) -> Decision:
    """Map an invoice lookup (``None`` = backend has no such invoice) to a state decision."""
    past_expiry = intent.expires_at is not None and now > intent.expires_at
    if lookup is None:
        if past_expiry:
            return Decision(PaymentState.EXPIRED, "invoice expired; backend has no record of it")
        return Decision(None, "backend has no record of this invoice",
                        error="The backend does not know this invoice.")
    if lookup.status is IncomingStatus.SETTLED:
        return Decision(PaymentState.SUCCEEDED, "backend confirms the invoice is settled", settled=True)
    if lookup.status is IncomingStatus.CANCELED:
        if past_expiry:
            return Decision(PaymentState.EXPIRED, "invoice expired unpaid")
        return Decision(PaymentState.FAILED, "invoice cancelled at the backend",
                        error="The invoice was cancelled at the backend.")
    if past_expiry:
        return Decision(PaymentState.EXPIRED, "invoice expired unpaid")
    return Decision(None, "invoice open")


@dataclass(slots=True)
class ReconciliationReport:
    backend_reachable: bool = False
    checked: int = 0
    succeeded: int = 0
    failed: int = 0
    expired: int = 0
    pending: int = 0
    unknown: int = 0
    interrupted: int = 0  # found in SUBMITTED/DRAFT from a previous run
    resubmitted: int = 0  # always 0: reconciliation never sends
    changed: list[str] = field(default_factory=list)  # ids of intents whose state changed
    notes: list[str] = field(default_factory=list)

    def summary(self) -> str:
        if not (self.checked or self.interrupted):
            return "No payments needed reconciliation."
        parts = [f"{self.checked} checked"]
        for label, n in (("succeeded", self.succeeded), ("failed", self.failed), ("expired", self.expired),
                         ("still pending", self.pending), ("outcome still unknown", self.unknown)):
            if n:
                parts.append(f"{n} {label}")
        if not self.backend_reachable:
            parts.append("backend not reachable")
        return "Payment reconciliation: " + ", ".join(parts) + ". Nothing was resubmitted."
