"""SQLite persistence for payment intents and their state history."""

from __future__ import annotations

import enum
import sqlite3
from typing import Any, Iterable

from ..persistence.database import Database
from .models import (InvalidPaymentState, PaymentDirection, PaymentEvent, PaymentIntent, PaymentKind,
                     PaymentState, PublisherTrust, can_transition)

_COLUMNS = ("id", "created_at", "updated_at", "direction", "kind", "state", "network", "amount_msat",
            "fee_limit_msat", "fee_paid_msat", "backend", "payment_hash", "destination", "description",
            "invoice", "expires_at", "publisher_name", "publisher_trust", "transfer_id", "manifest_id",
            "note", "error", "submitted_at", "settled_at")
_UPDATABLE = frozenset(_COLUMNS) - {"id", "created_at", "direction", "kind", "state"}
MAX_EVENTS_PER_PAYMENT = 200


def _row_to_intent(row: sqlite3.Row) -> PaymentIntent:
    try:
        trust = PublisherTrust(row["publisher_trust"])
    except ValueError:
        trust = PublisherTrust.UNKNOWN
    return PaymentIntent(
        id=row["id"], direction=PaymentDirection(row["direction"]), kind=PaymentKind(row["kind"]),
        state=PaymentState(row["state"]), network=row["network"], amount_msat=row["amount_msat"],
        fee_limit_msat=row["fee_limit_msat"], fee_paid_msat=row["fee_paid_msat"], backend=row["backend"],
        payment_hash=row["payment_hash"], destination=row["destination"], description=row["description"],
        invoice=row["invoice"], expires_at=row["expires_at"], publisher_name=row["publisher_name"],
        publisher_trust=trust, transfer_id=row["transfer_id"], manifest_id=row["manifest_id"],
        note=row["note"], error=row["error"], created_at=row["created_at"], updated_at=row["updated_at"],
        submitted_at=row["submitted_at"], settled_at=row["settled_at"])


def _value(v: Any) -> Any:
    return v.value if isinstance(v, enum.Enum) else v


class PaymentRepository:
    def __init__(self, db: Database):
        self._db = db

    def insert(self, intent: PaymentIntent, detail: str = "") -> None:
        """Insert a new intent and record its initial state in the history (one transaction)."""
        values = [_value(getattr(intent, c)) for c in _COLUMNS]
        with self._db.tx() as conn:
            conn.execute(
                f"INSERT INTO payments({', '.join(_COLUMNS)}) VALUES ({', '.join('?' * len(_COLUMNS))})", values)
            conn.execute(
                "INSERT INTO payment_events(payment_id, ts, from_state, to_state, detail) VALUES (?,?,?,?,?)",
                (intent.id, intent.created_at, None, intent.state.value, detail))

    def transition(self, intent_id: str, to: PaymentState, *, now: int, detail: str = "",
                   expected: Iterable[PaymentState] | None = None, **fields: Any) -> PaymentIntent:
        """Atomically move an intent to ``to``, update ``fields`` and append a history event.

        The current state is read inside the transaction; an illegal transition (or a
        state other than ``expected``) raises :class:`InvalidPaymentState` and changes nothing.
        """
        unknown = set(fields) - _UPDATABLE
        if unknown:
            raise ValueError(f"cannot update payment fields: {sorted(unknown)}")
        with self._db.tx() as conn:
            row = conn.execute("SELECT * FROM payments WHERE id = ?", (intent_id,)).fetchone()
            if row is None:
                raise InvalidPaymentState("This payment record no longer exists.")
            current = PaymentState(row["state"])
            kind = PaymentKind(row["kind"])
            if expected is not None and current not in tuple(expected):
                raise InvalidPaymentState(
                    f"This payment is “{current.label}”; the requested action is no longer possible.")
            if not can_transition(current, to, kind):
                raise InvalidPaymentState(
                    f"A payment that is “{current.label}” cannot become “{to.label}”.")
            fields = dict(fields)
            fields["updated_at"] = now
            sets = ", ".join(f"{k} = ?" for k in fields)
            conn.execute(f"UPDATE payments SET state = ?, {sets} WHERE id = ?",
                         [to.value, *[_value(v) for v in fields.values()], intent_id])
            conn.execute(
                "INSERT INTO payment_events(payment_id, ts, from_state, to_state, detail) VALUES (?,?,?,?,?)",
                (intent_id, now, current.value, to.value, detail[:500]))
            conn.execute(
                "DELETE FROM payment_events WHERE payment_id = ? AND id NOT IN ("
                " SELECT id FROM payment_events WHERE payment_id = ? ORDER BY id DESC LIMIT ?)",
                (intent_id, intent_id, MAX_EVENTS_PER_PAYMENT))
            row = conn.execute("SELECT * FROM payments WHERE id = ?", (intent_id,)).fetchone()
        return _row_to_intent(row)

    def annotate(self, intent_id: str, *, now: int, **fields: Any) -> PaymentIntent | None:
        """Update non-state fields (e.g. a status note) without a state change or history event."""
        unknown = set(fields) - _UPDATABLE
        if unknown:
            raise ValueError(f"cannot update payment fields: {sorted(unknown)}")
        fields = dict(fields)
        fields["updated_at"] = now
        sets = ", ".join(f"{k} = ?" for k in fields)
        with self._db.tx() as conn:
            conn.execute(f"UPDATE payments SET {sets} WHERE id = ?",
                         [*[_value(v) for v in fields.values()], intent_id])
        return self.get(intent_id)

    def get(self, intent_id: str) -> PaymentIntent | None:
        row = self._db.query_one("SELECT * FROM payments WHERE id = ?", (intent_id,))
        return _row_to_intent(row) if row else None

    def find_by_hash(self, payment_hash: str, direction: PaymentDirection | None = None) -> list[PaymentIntent]:
        sql = "SELECT * FROM payments WHERE payment_hash = ?"
        params: list[Any] = [payment_hash]
        if direction is not None:
            sql += " AND direction = ?"
            params.append(direction.value)
        return [_row_to_intent(r) for r in self._db.query(sql + " ORDER BY created_at, id", params)]

    def list(self, *, limit: int = 200, direction: PaymentDirection | None = None,
             states: Iterable[PaymentState] | None = None, transfer_id: str | None = None,
             kinds: Iterable[PaymentKind] | None = None) -> list[PaymentIntent]:
        clauses: list[str] = []
        params: list[Any] = []
        if direction is not None:
            clauses.append("direction = ?")
            params.append(direction.value)
        if states is not None:
            states = list(states)
            clauses.append(f"state IN ({', '.join('?' * len(states))})")
            params += [s.value for s in states]
        if kinds is not None:
            kinds = list(kinds)
            clauses.append(f"kind IN ({', '.join('?' * len(kinds))})")
            params += [k.value for k in kinds]
        if transfer_id is not None:
            clauses.append("transfer_id = ?")
            params.append(transfer_id)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        params.append(max(1, min(int(limit), 5000)))
        rows = self._db.query(f"SELECT * FROM payments{where} ORDER BY created_at DESC, rowid DESC LIMIT ?", params)
        return [_row_to_intent(r) for r in rows]

    def events(self, intent_id: str) -> list[PaymentEvent]:
        rows = self._db.query(
            "SELECT ts, from_state, to_state, detail FROM payment_events WHERE payment_id = ? ORDER BY id",
            (intent_id,))
        return [PaymentEvent(ts=r["ts"], from_state=PaymentState(r["from_state"]) if r["from_state"] else None,
                             to_state=PaymentState(r["to_state"]), detail=r["detail"]) for r in rows]

    def counts_by_state(self) -> dict[str, int]:
        return {r["state"]: r["n"] for r in self._db.query("SELECT state, COUNT(*) AS n FROM payments GROUP BY state")}

    def counts_by_kind(self) -> dict[str, int]:
        return {r["kind"]: r["n"] for r in self._db.query("SELECT kind, COUNT(*) AS n FROM payments GROUP BY kind")}

    def recent_events(self, limit: int = 20) -> list[sqlite3.Row]:
        return self._db.query(
            "SELECT payment_id, ts, from_state, to_state FROM payment_events ORDER BY id DESC LIMIT ?", (limit,))
