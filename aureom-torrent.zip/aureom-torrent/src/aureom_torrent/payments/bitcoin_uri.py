"""Bitcoin addresses and BIP21 payment URIs.

This application never signs or broadcasts transactions.  A BIP21 URI is built
here and handed to whatever wallet the operating system associates with the
``bitcoin:`` scheme – and only after an explicit click.  Opening a wallet is not
evidence of payment.

Address checks use the ``base58`` and ``bech32`` libraries for the encodings
and checksums (Base58Check, Bech32 per BIP173, Bech32m per BIP350).  Only
standard output types are accepted: P2PKH, P2SH, P2WPKH, P2WSH and P2TR.
"""

from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import quote, unquote

import base58
import bech32

from .amounts import AmountError, MAX_SAT, format_btc, parse_btc_decimal, require_int
from .invoices import sanitise_text

MAX_URI_LENGTH = 2048
MAX_LABEL_LENGTH = 120
MAX_MESSAGE_LENGTH = 280

_BECH32_CONST = 1
_BECH32M_CONST = 0x2BC830A3

# network -> (bech32 hrp, p2pkh version, p2sh version)
_NETWORKS = {
    "mainnet": ("bc", 0x00, 0x05),
    "testnet": ("tb", 0x6F, 0xC4),
    "signet": ("tb", 0x6F, 0xC4),
    "regtest": ("bcrt", 0x6F, 0xC4),
}
_HRP_NETWORKS = {"bc": ("mainnet",), "tb": ("testnet", "signet"), "bcrt": ("regtest",)}
_BASE58_NETWORKS = {
    0x00: (("mainnet",), "p2pkh"), 0x05: (("mainnet",), "p2sh"),
    0x6F: (("testnet", "signet", "regtest"), "p2pkh"), 0xC4: (("testnet", "signet", "regtest"), "p2sh"),
}


class AddressError(ValueError):
    """An address or payment URI that cannot be used. The message is safe to show."""


@dataclass(frozen=True, slots=True)
class AddressInfo:
    address: str
    networks: tuple[str, ...]  # every network this encoding is valid on
    kind: str  # p2pkh | p2sh | p2wpkh | p2wsh | p2tr


@dataclass(frozen=True, slots=True)
class BitcoinRequest:
    address: AddressInfo
    amount_sat: int | None = None
    label: str = ""
    message: str = ""
    ignored: tuple[str, ...] = ()


def _decode_segwit(address: str) -> AddressInfo | None:
    """Return info for a valid native segwit address, ``None`` if it is not bech32 at all."""
    lower = address.lower()
    pos = lower.rfind("1")
    hrp = lower[:pos] if pos > 0 else ""
    if hrp not in _HRP_NETWORKS:
        return None
    if len(address) > 90:
        raise AddressError("The address is too long.")
    if address != lower and address != address.upper():
        raise AddressError("The address mixes upper and lower case.")
    data_part = lower[pos + 1:]
    if len(data_part) < 7 or any(c not in bech32.CHARSET for c in data_part):
        raise AddressError("The address contains characters that are not valid in a bech32 address.")
    values = [bech32.CHARSET.find(c) for c in data_part]
    const = bech32.bech32_polymod(bech32.bech32_hrp_expand(hrp) + values)
    if const not in (_BECH32_CONST, _BECH32M_CONST):
        raise AddressError("The address checksum is wrong (possibly a typing mistake).")
    payload = values[:-6]
    if not payload:
        raise AddressError("The address is empty.")
    version = payload[0]
    program = bech32.convertbits(payload[1:], 5, 8, False)
    if program is None or version > 16:
        raise AddressError("The address is not a valid segwit address.")
    if version == 0 and const != _BECH32_CONST:
        raise AddressError("The address uses the wrong checksum type for a version 0 segwit address.")
    if version != 0 and const != _BECH32M_CONST:
        raise AddressError("The address uses the wrong checksum type for its segwit version.")
    if version == 0 and len(program) == 20:
        kind = "p2wpkh"
    elif version == 0 and len(program) == 32:
        kind = "p2wsh"
    elif version == 1 and len(program) == 32:
        kind = "p2tr"
    else:
        raise AddressError("This segwit address type is not a standard output type and is not supported.")
    return AddressInfo(address=lower, networks=_HRP_NETWORKS[hrp], kind=kind)


def _decode_base58(address: str) -> AddressInfo:
    if not (26 <= len(address) <= 35):
        raise AddressError("This is not a valid Bitcoin address.")
    try:
        raw = base58.b58decode_check(address)
    except Exception as exc:
        raise AddressError("The address checksum is wrong (possibly a typing mistake).") from exc
    if len(raw) != 21 or raw[0] not in _BASE58_NETWORKS:
        raise AddressError("This is not a supported Bitcoin address type.")
    networks, kind = _BASE58_NETWORKS[raw[0]]
    return AddressInfo(address=address, networks=networks, kind=kind)


def validate_address(address: object, network: str | None = None) -> AddressInfo:
    """Validate a Bitcoin address; with ``network`` given, also require that it belongs to it."""
    if not isinstance(address, str):
        raise AddressError("A Bitcoin address must be text.")
    text = address.strip()
    if not text or len(text) > 90 or not text.isascii() or not text.isalnum():
        raise AddressError("This is not a valid Bitcoin address.")
    if network is not None and network not in _NETWORKS:
        raise AddressError(f"Unknown Bitcoin network “{network}”.")
    info = _decode_segwit(text)
    if info is None:
        info = _decode_base58(text)
    if network is not None and network not in info.networks:
        raise AddressError(
            f"This address belongs to {' / '.join(info.networks)}, but payments are configured for {network}.")
    return info


def build_bip21(address: str, *, network: str, amount_sat: int | None = None, label: str = "",
                message: str = "") -> str:
    """Build ``bitcoin:<address>?amount=<BTC>&label=…&message=…`` from integer satoshis."""
    info = validate_address(address, network)
    params: list[str] = []
    if amount_sat is not None:
        amount = require_int(amount_sat, "amount")
        if amount <= 0 or amount > MAX_SAT:
            raise AddressError("The amount must be a positive number of satoshis.")
        params.append("amount=" + format_btc(amount, trim=True))
    label = sanitise_text(label, MAX_LABEL_LENGTH)
    message = sanitise_text(message, MAX_MESSAGE_LENGTH)
    if label:
        params.append("label=" + quote(label, safe=""))
    if message:
        params.append("message=" + quote(message, safe=""))
    # Upper-casing bech32 is allowed (and QR-friendlier) but lower case is the common form.
    uri = "bitcoin:" + info.address + ("?" + "&".join(params) if params else "")
    if len(uri) > MAX_URI_LENGTH:
        raise AddressError("The payment request is too long.")
    return uri


def parse_bip21(uri: object, *, network: str | None = None) -> BitcoinRequest:
    """Parse a BIP21 URI. Unknown ``req-`` parameters make the URI invalid, as BIP21 requires.

    Other unknown parameters (including ``lightning=``) are ignored and reported
    in ``ignored``; nothing in a URI ever triggers a payment by itself.
    """
    if not isinstance(uri, str):
        raise AddressError("A payment URI must be text.")
    text = uri.strip()
    if len(text) > MAX_URI_LENGTH:
        raise AddressError("The payment URI is too long.")
    if text[:8].lower() != "bitcoin:":
        raise AddressError("This is not a bitcoin: payment URI.")
    rest = text[8:]
    if rest.startswith("//"):
        rest = rest[2:]
    addr_part, _, query = rest.partition("?")
    info = validate_address(addr_part, network)
    amount: int | None = None
    label = ""
    message = ""
    ignored: list[str] = []
    seen: set[str] = set()
    for pair in (p for p in query.split("&") if p):
        key, sep, raw = pair.partition("=")
        key = key.lower()
        if key in seen and key in ("amount", "label", "message"):
            raise AddressError(f"The payment URI repeats the “{key}” parameter.")
        seen.add(key)
        try:
            value = unquote(raw, errors="strict")
        except UnicodeDecodeError as exc:
            raise AddressError("The payment URI contains text that is not valid UTF-8.") from exc
        if key == "amount":
            if not sep:
                raise AddressError("The payment URI has an empty amount.")
            try:
                amount = parse_btc_decimal(value)
            except AmountError as exc:
                raise AddressError(str(exc)) from exc
            if amount <= 0:
                raise AddressError("The payment URI asks for a zero amount.")
        elif key == "label":
            label = sanitise_text(value, MAX_LABEL_LENGTH)
        elif key == "message":
            message = sanitise_text(value, MAX_MESSAGE_LENGTH)
        elif key.startswith("req-"):
            raise AddressError(
                f"The payment URI requires a feature this application does not support (“{sanitise_text(key, 32)}”).")
        else:
            ignored.append(sanitise_text(key, 32))
    return BitcoinRequest(address=info, amount_sat=amount, label=label, message=message,
                          ignored=tuple(ignored[:16]))
