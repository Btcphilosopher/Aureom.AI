"""BOLT11 invoice decoding and validation.

Decoding (bech32, tagged fields, signature recovery/verification) is done by
the maintained ``bolt11`` library; this module only applies application policy
on top of the decoded invoice.

Not accepted here: BOLT12 offers/invoices (``lno1…``/``lni1…``), LNURL strings
(``lnurl1…``) and Lightning addresses.  LNURL-pay is handled, for explicit user
tips only, in ``payments.lnurl``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import bolt11
from bolt11.exceptions import Bolt11Exception

from .amounts import AmountError, format_msat, require_msat

MAX_INVOICE_LENGTH = 4096
MAX_DESCRIPTION_DISPLAY = 280
DEFAULT_EXPIRY_MARGIN_S = 30

NETWORK_BY_CURRENCY = {"bc": "mainnet", "tb": "testnet", "tbs": "signet", "bcrt": "regtest"}

_CONTROL = re.compile(r"[\x00-\x1f\x7f-\x9f​-‏‪-‮⁦-⁩]")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_HEX66 = re.compile(r"^[0-9a-f]{66}$")


class InvoiceError(ValueError):
    """An invoice that cannot be paid. ``reason`` is a stable code; the message is safe to show."""

    def __init__(self, message: str, *, reason: str = "invalid"):
        super().__init__(message)
        self.reason = reason  # invalid | unsupported | network | expired | amount_required | amount | limit


@dataclass(frozen=True, slots=True)
class ValidatedInvoice:
    bolt11: str  # normalised (lower case, no "lightning:" prefix)
    network: str
    payment_hash: str
    payee: str  # node public key recovered/declared by the invoice
    amount_msat: int  # the amount that will be paid
    invoice_amount_msat: int | None  # None for an amountless invoice
    description: str  # sanitised for display
    description_hash: str  # set when the invoice commits to a description by hash only
    created_at: int
    expires_at: int

    @property
    def amountless(self) -> bool:
        return self.invoice_amount_msat is None


def sanitise_text(text: str | None, limit: int = MAX_DESCRIPTION_DISPLAY) -> str:
    """Strip control and bidirectional-override characters and bound the length (display only)."""
    if not text:
        return ""
    cleaned = _CONTROL.sub(" ", str(text))
    cleaned = " ".join(cleaned.split())
    if len(cleaned) > limit:
        cleaned = cleaned[: limit - 1] + "…"
    return cleaned


def normalise_invoice_text(text: object) -> str:
    """Trim, strip one ``lightning:`` URI prefix and lower-case. Raises for unsupported formats."""
    if not isinstance(text, str):
        raise InvoiceError("An invoice must be text.")
    value = text.strip()
    if len(value) > MAX_INVOICE_LENGTH:
        raise InvoiceError(f"This invoice is too long (limit {MAX_INVOICE_LENGTH} characters).")
    if value[:10].lower() == "lightning:":
        value = value[10:].strip()
        if value.startswith("//"):
            value = value[2:]
    if not value:
        raise InvoiceError("Paste a Lightning invoice (it starts with “ln”).")
    if any(c.isspace() for c in value) or _CONTROL.search(value):
        raise InvoiceError("The invoice contains spaces or control characters.")
    lower = value.lower()
    if value != lower and value != value.upper():
        raise InvoiceError("The invoice mixes upper and lower case, which BOLT11 does not allow.")
    if lower.startswith(("lno1", "lni1", "lnr1")):
        raise InvoiceError("BOLT12 offers and invoices are not supported; ask for a BOLT11 invoice.",
                           reason="unsupported")
    if lower.startswith("lnurl"):
        raise InvoiceError("This is an LNURL, not an invoice. Use “Send a tip” with the publisher's "
                           "Lightning address instead.", reason="unsupported")
    if "@" in lower:
        raise InvoiceError("This is a Lightning address, not an invoice. Use “Send a tip” instead.",
                           reason="unsupported")
    if lower.startswith(("bitcoin:", "bc1", "tb1", "bcrt1")):
        raise InvoiceError("This is a Bitcoin address or payment URI, not a Lightning invoice.",
                           reason="unsupported")
    if not lower.startswith("ln"):
        raise InvoiceError("This does not look like a Lightning invoice (it must start with “ln”).",
                           reason="unsupported")
    return lower


def decode_invoice(text: object):
    """Decode with the ``bolt11`` library; returns ``(normalised_text, decoded)``."""
    normalised = normalise_invoice_text(text)
    try:
        decoded = bolt11.decode(normalised)
    except Bolt11Exception as exc:
        raise InvoiceError(f"This Lightning invoice is not valid ({_describe(exc)}).") from exc
    except Exception as exc:  # malformed input can surface as ValueError/IndexError inside the decoder
        raise InvoiceError("This Lightning invoice could not be decoded.") from exc
    return normalised, decoded


def _describe(exc: Exception) -> str:
    name = type(exc).__name__.removeprefix("Bolt11").removesuffix("Exception")
    words = re.sub(r"(?<!^)(?=[A-Z])", " ", name).lower() or "invalid"
    return words


def validate_invoice(text: object, *, expected_network: str, now: float, min_msat: int, max_msat: int,
                     amount_msat: int | None = None,
                     expiry_margin_s: int = DEFAULT_EXPIRY_MARGIN_S) -> ValidatedInvoice:
    """Decode an invoice and check network, expiry and amount policy.

    ``amount_msat`` must be supplied for an amountless invoice and must be
    omitted (or equal) for an invoice that fixes its amount.
    """
    normalised, inv = decode_invoice(text)

    network = NETWORK_BY_CURRENCY.get(inv.currency)
    if network is None:
        raise InvoiceError(f"The invoice is for an unsupported network (“{sanitise_text(inv.currency, 12)}”).",
                           reason="network")
    if network != expected_network:
        raise InvoiceError(
            f"This invoice is for {network}, but payments are configured for {expected_network}.",
            reason="network")

    payment_hash = str(inv.payment_hash).lower()
    if not _HEX64.match(payment_hash):
        raise InvoiceError("The invoice has no usable payment hash.")
    payee = str(inv.payee or "").lower()
    if not _HEX66.match(payee):
        raise InvoiceError("The invoice does not identify its recipient node.")

    created_at = int(inv.date)
    expiry = int(inv.expiry)
    if expiry <= 0 or created_at <= 0:
        raise InvoiceError("The invoice has an invalid timestamp or expiry.")
    expires_at = created_at + expiry
    if int(now) + int(expiry_margin_s) >= expires_at:
        raise InvoiceError("This invoice has expired (or is about to). Ask the publisher for a new one.",
                           reason="expired")
    if created_at > int(now) + 2 * 3600:
        raise InvoiceError("The invoice is dated in the future; check this computer's clock.")

    invoice_amount = None if inv.amount_msat is None else int(inv.amount_msat)
    if invoice_amount is not None and invoice_amount <= 0:
        invoice_amount = None
    try:
        requested = None if amount_msat is None else require_msat(amount_msat)
    except AmountError as exc:
        raise InvoiceError(str(exc), reason="amount") from exc

    if invoice_amount is None:
        if requested is None or requested <= 0:
            raise InvoiceError("This invoice does not state an amount; enter the amount you want to send.",
                               reason="amount_required")
        final = requested
    else:
        if requested is not None and requested != invoice_amount:
            raise InvoiceError(
                f"This invoice fixes the amount at {format_msat(invoice_amount)}; it cannot be changed.",
                reason="amount")
        final = invoice_amount

    if final < min_msat:
        raise InvoiceError(f"The amount ({format_msat(final)}) is below the minimum of "
                           f"{format_msat(min_msat)} set in Settings.", reason="limit")
    if final > max_msat:
        raise InvoiceError(f"The amount ({format_msat(final)}) is above the maximum of "
                           f"{format_msat(max_msat)} set in Settings.", reason="limit")

    return ValidatedInvoice(
        bolt11=normalised,
        network=network,
        payment_hash=payment_hash,
        payee=payee,
        amount_msat=final,
        invoice_amount_msat=invoice_amount,
        description=sanitise_text(inv.description),
        description_hash=str(inv.description_hash or "").lower(),
        created_at=created_at,
        expires_at=expires_at,
    )
