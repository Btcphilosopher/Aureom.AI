"""Payment orchestration: optional publisher support via Bitcoin (BIP21 hand-off) and Lightning.

Design rules enforced here
--------------------------
* **Explicit action only.**  Nothing in this module runs by itself: every
  outgoing payment needs ``prepare_*`` (which only records an intent and builds
  an approval summary) followed by ``approve_and_send`` from a user click.
  Feeds, magnets, manifests and torrent metadata cannot reach this service
  (``payments`` imports nothing from ``feeds``, and vice versa).
* **Intent before submission.**  The intent is committed to SQLite in
  ``SUBMITTED`` state *before* the backend is called.
* **A timeout is not a failure.**  Uncertain outcomes become ``UNKNOWN`` and
  are resolved only by read-only reconciliation (``payments.reconciliation``).
* **No blind retries, no duplicates.**  A second outgoing intent for a payment
  hash that is submitted / pending / unknown / succeeded is refused.
* **Settlement comes from the backend.**  Incoming invoices become
  ``SUCCEEDED`` only when the backend reports them settled; a BIP21 hand-off
  never becomes ``SUCCEEDED`` at all.
* **Integers only.**  Amounts are ``int`` millisatoshis/satoshis throughout.

All methods block and must be called from worker threads, never the GUI thread.
The service works without a backend: history and BIP21 requests stay available
and backend-dependent methods raise ``BackendUnavailable``.
"""

from __future__ import annotations

import logging
import threading
import uuid
from typing import Callable

from ..net.http import Fetcher, HttpFetcher, HttpPolicy
from ..persistence.database import Database
from ..util.clock import Clock
from .amounts import (MAX_SAT, AmountError, fee_cap_msat, format_msat, format_sats, msat_to_sat_ceil,
                      require_int, require_msat, sat_to_msat)
from .bitcoin_uri import build_bip21, validate_address
from .interface import (BackendError, BackendInfo, BackendRejected, BackendUnavailable, LightningBackend,
                        OutgoingStatus, PaymentAlreadyKnown, PaymentNotFound, PaymentOutcomeUnknown)
from .invoices import InvoiceError, ValidatedInvoice, sanitise_text, validate_invoice
from .lnurl import LnurlPayClient, tip_policy
from .models import (BLOCKING_STATES, ApprovalSummary, BackendStatus, DuplicatePayment, InvalidPaymentState,
                     PaymentDirection, PaymentError, PaymentEvent, PaymentIntent, PaymentKind,
                     PaymentLimitError, PaymentState, PublisherRef, PublisherTrust)
from .reconciliation import Decision, ReconciliationReport, decide_incoming, decide_outgoing, failure_text
from .repository import PaymentRepository

log = logging.getLogger(__name__)

MAX_NOTE_LENGTH = 280
MAX_MEMO_LENGTH = 200

# Shown by the UI next to every payment action.
PAYMENT_DISCLOSURES = (
    "Payments are voluntary support for a publisher. They are not part of the BitTorrent protocol.",
    "A payment does not unlock, speed up or guarantee any download, and it is not proof of delivery.",
    "Lightning and Bitcoin payments cannot be refunded by this application.",
    "Routing fees may apply and settlement is not guaranteed to be instant.",
)

_OUTGOING_LIGHTNING = (PaymentKind.LIGHTNING_INVOICE, PaymentKind.LIGHTNING_TIP)
_OPEN_STATES = (PaymentState.SUBMITTED, PaymentState.PENDING, PaymentState.UNKNOWN)


class PaymentService:
    def __init__(self, db: Database, backend_provider: Callable[[], LightningBackend | None],
                 settings: Callable[[], object], clock: Clock, fetcher: Fetcher | None = None, *,
                 lnurl_policy: HttpPolicy | None = None):
        self._repo = PaymentRepository(db)
        self._backend_provider = backend_provider
        self._settings = settings
        self._clock = clock
        self._fetcher = fetcher
        self._lnurl_policy = lnurl_policy
        self._lock = threading.RLock()
        self._sending: set[str] = set()  # intents with a submission currently in progress

    # ------------------------------------------------------------------ helpers
    def _now(self) -> int:
        return int(self._clock.now())

    def _pay(self):
        return self._settings().payments

    def _limits_msat(self) -> tuple[int, int]:
        p = self._pay()
        return sat_to_msat(p.min_payment_sat), sat_to_msat(p.max_payment_sat)

    def _backend(self, required: bool = True) -> LightningBackend | None:
        try:
            backend = self._backend_provider()
        except BackendUnavailable:
            if required:
                raise
            return None
        if backend is None and required:
            raise BackendUnavailable(
                "No Lightning backend is configured (Settings → Payments). "
                "Downloads, seeding and publishing work without one.")
        return backend

    def _check_limits(self, amount_msat: int) -> None:
        lo, hi = self._limits_msat()
        if amount_msat < lo:
            raise PaymentLimitError(f"The minimum amount is {format_msat(lo)}.")
        if amount_msat > hi:
            raise PaymentLimitError(
                f"The maximum amount is {format_msat(hi)} (change it in Settings → Payments).")

    def _require(self, intent_id: str) -> PaymentIntent:
        intent = self._repo.get(intent_id)
        if intent is None:
            raise InvalidPaymentState("This payment record no longer exists.")
        return intent

    def _block_duplicates(self, payment_hash: str, *, ignore: str | None = None) -> None:
        for other in self._repo.find_by_hash(payment_hash, PaymentDirection.OUTGOING):
            if other.id != ignore and other.state in BLOCKING_STATES:
                if other.state is PaymentState.SUCCEEDED:
                    msg = "This invoice has already been paid from this application."
                else:
                    msg = (f"A payment for this invoice already exists and is “{other.state.label}”. "
                           "It will not be sent again; check its status instead.")
                raise DuplicatePayment(msg, other.id)

    # ------------------------------------------------------------------ status
    def backend_status(self) -> BackendStatus:
        """Connectivity of the configured backend. Never raises."""
        pay = self._pay()
        try:
            backend = self._backend_provider()
            if backend is None:
                return BackendStatus(configured=False, connected=False,
                                     message="No payment backend is configured. Transfers work without one.")
            info = backend.get_info()
        except BackendError as exc:
            return BackendStatus(configured=True, connected=False, name=pay.backend, message=str(exc))
        except Exception as exc:  # a broken backend must never break the application
            log.warning("payment backend status failed: %s", type(exc).__name__)
            return BackendStatus(configured=True, connected=False, name=pay.backend,
                                 message="The payment backend could not be queried.")
        matches = info.network == pay.expected_network
        if not matches:
            message = (f"The node is on {info.network or 'an unknown network'}, but payments are configured "
                       f"for {pay.expected_network}. Payments are disabled until this matches.")
        elif not info.synced:
            message = "Connected; the node is still synchronising with the chain."
        else:
            message = "Connected."
        return BackendStatus(configured=True, connected=True, name=info.backend, alias=info.alias,
                             network=info.network, network_matches=matches, synced=info.synced,
                             version=info.version, message=message)

    def suggested_fee_limit_msat(self, amount_msat: int) -> int:
        """Default routing-fee cap: ``max_fee_ppm`` of the amount, never below ``min_fee_limit_sat``."""
        pay = self._pay()
        return fee_cap_msat(require_msat(amount_msat), pay.max_fee_ppm, pay.min_fee_limit_sat)

    def max_fee_limit_msat(self, amount_msat: int) -> int:
        """Hard ceiling for a user-chosen fee limit: the amount itself, or the suggested cap if larger."""
        return max(require_msat(amount_msat), self.suggested_fee_limit_msat(amount_msat))

    # ------------------------------------------------------- outgoing: prepare
    def prepare_invoice_payment(self, invoice_text: str, *, amount_msat: int | None = None,
                                publisher: PublisherRef | None = None, transfer_id: str | None = None,
                                note: str = "") -> tuple[PaymentIntent, ApprovalSummary]:
        """Validate a pasted BOLT11 invoice and record an intent awaiting approval. Sends nothing."""
        validated = self._validate(invoice_text, amount_msat)
        return self._prepare_outgoing(validated, PaymentKind.LIGHTNING_INVOICE, publisher, transfer_id, note,
                                      description=validated.description,
                                      destination_source="node public key from the invoice", warnings=[])

    def prepare_tip(self, lightning_address_or_lnurl: str, amount_msat: int, *,
                    publisher: PublisherRef | None = None, transfer_id: str | None = None,
                    note: str = "") -> tuple[PaymentIntent, ApprovalSummary]:
        """Fetch a one-off invoice from a publisher's LNURL-pay service and record an intent.

        Contacts the publisher's server (it sees this computer's or the proxy's IP
        address).  Sends no money; approval is a separate explicit step.
        """
        amount = require_msat(amount_msat)
        if amount <= 0:
            raise PaymentLimitError("Enter a tip amount.")
        self._check_limits(amount)
        policy = self._lnurl_policy or tip_policy(HttpPolicy.from_settings(self._settings().payments_network))
        fetcher = self._fetcher or HttpFetcher(policy)
        client = LnurlPayClient(fetcher, policy)
        params = client.fetch_params(lightning_address_or_lnurl)
        pr = client.request_invoice(params, amount)
        validated = self._validate(pr, amount)
        description = params.description or "(no description provided by the tip service)"
        warnings = [f"The invoice was issued by the tip service at {sanitise_text(params.domain, 80)}; "
                    "this application cannot verify who operates it."]
        return self._prepare_outgoing(validated, PaymentKind.LIGHTNING_TIP, publisher, transfer_id, note,
                                      description=description,
                                      destination_source=f"invoice from the LNURL-pay service at "
                                                         f"{sanitise_text(params.domain, 80)}",
                                      warnings=warnings)

    def _validate(self, invoice_text: str, amount_msat: int | None) -> ValidatedInvoice:
        lo, hi = self._limits_msat()
        return validate_invoice(invoice_text, expected_network=self._pay().expected_network, now=self._clock.now(),
                                min_msat=lo, max_msat=hi, amount_msat=amount_msat)

    def _prepare_outgoing(self, v: ValidatedInvoice, kind: PaymentKind, publisher: PublisherRef | None,
                          transfer_id: str | None, note: str, *, description: str, destination_source: str,
                          warnings: list[str]) -> tuple[PaymentIntent, ApprovalSummary]:
        publisher = publisher or PublisherRef()
        backend_name, backend_alias = "", ""
        backend = self._backend(required=False)
        if backend is None:
            warnings.append("No Lightning backend is connected. Connect one in Settings → Payments before sending.")
        else:
            backend_name = backend.name
            try:
                info = backend.get_info()
                backend_alias = info.alias
                if info.network != v.network:
                    raise PaymentError(
                        f"The Lightning node is on {info.network or 'an unknown network'}, "
                        f"but this invoice is for {v.network}.")
                if info.pubkey and info.pubkey == v.payee:
                    warnings.append("This invoice was created by your own node.")
                decoded = backend.decode_invoice(v.bolt11)
                if decoded.payment_hash != v.payment_hash or decoded.destination != v.payee or (
                        decoded.amount_msat is not None and v.invoice_amount_msat is not None
                        and decoded.amount_msat != v.invoice_amount_msat):
                    raise PaymentError("The backend decodes this invoice differently from this application; "
                                       "it was rejected.")
                destination_source += " (confirmed by the backend)"
            except BackendUnavailable as exc:
                warnings.append(f"The Lightning backend is not reachable right now ({exc}).")
            except BackendError as exc:
                raise PaymentError(f"The backend rejected this invoice: {exc}") from exc

        if v.amountless:
            warnings.append("The invoice does not fix an amount; the amount shown was entered by you.")
        if not v.description and v.description_hash and kind is PaymentKind.LIGHTNING_INVOICE:
            warnings.append("The invoice commits to a description by hash only; its text is not available.")
        if publisher.trust is PublisherTrust.SELF_ASSERTED:
            warnings.append("The publisher identity is self-asserted and has not been verified.")
        elif publisher.trust is PublisherTrust.UNKNOWN:
            warnings.append("The recipient is not linked to a known publisher.")
        else:
            warnings.append("“Verified” means the manifest signature matches a key you chose to trust. "
                            "It does not prove that this invoice belongs to that publisher.")

        now = self._now()
        intent = PaymentIntent(
            id=uuid.uuid4().hex, direction=PaymentDirection.OUTGOING, kind=kind, state=PaymentState.DRAFT,
            network=v.network, amount_msat=v.amount_msat, backend=backend_name, payment_hash=v.payment_hash,
            destination=v.payee, description=sanitise_text(description), invoice=v.bolt11,
            expires_at=v.expires_at, publisher_name=sanitise_text(publisher.name, 120),
            publisher_trust=publisher.trust, transfer_id=transfer_id, manifest_id=publisher.manifest_id,
            note=sanitise_text(note, MAX_NOTE_LENGTH), created_at=now, updated_at=now)
        with self._lock:
            self._block_duplicates(v.payment_hash)
            # Supersede earlier, never-submitted intents for the same invoice.
            for other in self._repo.find_by_hash(v.payment_hash, PaymentDirection.OUTGOING):
                if other.state in (PaymentState.DRAFT, PaymentState.AWAITING_APPROVAL):
                    self._repo.transition(other.id, PaymentState.CANCELLED, now=now, invoice=None,
                                          detail="superseded by a newer request for the same invoice")
            self._repo.insert(intent, "created")
            intent = self._repo.transition(intent.id, PaymentState.AWAITING_APPROVAL, now=now,
                                           detail="validated; awaiting explicit approval")
        log.info("payment %s prepared (%s, awaiting approval)", intent.id[:8], kind.value)
        return intent, self._summary(intent, destination_source, backend_alias, tuple(warnings))

    def _summary(self, intent: PaymentIntent, destination_source: str, backend_alias: str,
                 warnings: tuple[str, ...]) -> ApprovalSummary:
        amount = intent.amount_msat
        return ApprovalSummary(
            intent_id=intent.id, kind=intent.kind, amount_msat=amount,
            amount_text=format_msat(amount) if amount is not None else "chosen in your wallet",
            network=intent.network, destination=intent.destination, destination_source=destination_source,
            publisher_name=intent.publisher_name, publisher_trust=intent.publisher_trust,
            trust_label=intent.publisher_trust.label, description=intent.description,
            expires_at=intent.expires_at,
            seconds_until_expiry=(intent.expires_at - self._now()) if intent.expires_at else None,
            suggested_fee_limit_msat=self.suggested_fee_limit_msat(amount) if amount and intent.is_lightning else None,
            max_fee_limit_msat=self.max_fee_limit_msat(amount) if amount and intent.is_lightning else None,
            backend_name=intent.backend, backend_alias=backend_alias,
            payment_hash_short=(intent.payment_hash or "")[:12], warnings=warnings)

    # ---------------------------------------------------------- outgoing: send
    def approve_and_send(self, intent_id: str, *, fee_limit_msat: int) -> PaymentIntent:
        """Submit an approved Lightning payment. Call only from an explicit user action.

        Returns the intent in its resulting state: ``SUCCEEDED``, ``FAILED``,
        ``PENDING`` (in flight), ``UNKNOWN`` (no definitive answer – reconcile
        later, do not retry) or ``EXPIRED`` (the invoice expired before approval;
        nothing was sent).  Raises without sending when the request is invalid,
        the backend is unavailable, or the payment would be a duplicate.
        """
        fee_limit = require_msat(fee_limit_msat, "fee limit")
        with self._lock:
            intent = self._require(intent_id)
            if intent.kind not in _OUTGOING_LIGHTNING:
                raise InvalidPaymentState("Only Lightning payments are sent by this application.")
            if intent.state is not PaymentState.AWAITING_APPROVAL:
                raise InvalidPaymentState(
                    f"This payment is “{intent.state.label}” and cannot be sent (again).")
            if not intent.invoice or not intent.payment_hash or not intent.amount_msat:
                raise InvalidPaymentState("This payment record is incomplete and cannot be sent.")
            now = self._now()
            # Re-validate at the moment of approval: expiry, network and limits may have changed.
            try:
                lo, hi = self._limits_msat()
                validated = validate_invoice(intent.invoice, expected_network=self._pay().expected_network,
                                             now=self._clock.now(), min_msat=lo, max_msat=hi,
                                             amount_msat=intent.amount_msat)
            except InvoiceError as exc:
                if exc.reason == "expired":
                    log.info("payment %s expired before approval", intent.id[:8])
                    return self._repo.transition(intent.id, PaymentState.EXPIRED, now=now,
                                                 detail="invoice expired before approval; nothing was sent",
                                                 error="The invoice expired before it was approved. "
                                                       "Nothing was sent.", invoice=None)
                raise
            if validated.payment_hash != intent.payment_hash or validated.amount_msat != intent.amount_msat:
                raise InvalidPaymentState("The stored invoice no longer matches this payment record.")
            if fee_limit > self.max_fee_limit_msat(intent.amount_msat):
                raise PaymentLimitError(
                    f"The fee limit cannot exceed {format_msat(self.max_fee_limit_msat(intent.amount_msat))} "
                    "for this payment.")
            self._block_duplicates(intent.payment_hash, ignore=intent.id)

            backend = self._backend(required=True)
            info: BackendInfo = backend.get_info()  # raises BackendUnavailable: nothing sent, state unchanged
            if info.network != intent.network:
                raise PaymentError(
                    f"The Lightning node is on {info.network or 'an unknown network'}, but this payment is for "
                    f"{intent.network}. Nothing was sent.")

            # Persist the intent as SUBMITTED *before* contacting the backend.
            intent = self._repo.transition(
                intent.id, PaymentState.SUBMITTED, now=now, expected=(PaymentState.AWAITING_APPROVAL,),
                detail=f"approved; submitting with fee limit {format_msat(fee_limit)}",
                fee_limit_msat=fee_limit, submitted_at=now, backend=backend.name, error="")
            self._sending.add(intent.id)
            invoice, amountless_amount = intent.invoice, None
            if validated.amountless:
                amountless_amount = intent.amount_msat

        log.info("payment %s submitted to %s", intent.id[:8], backend.name)
        try:
            try:
                result = backend.pay_invoice(invoice, amount_msat=amountless_amount, fee_limit_msat=fee_limit,
                                             timeout_s=int(self._pay().payment_timeout_s))
            except BackendRejected as exc:
                return self._finish(intent.id, PaymentState.FAILED, f"rejected by the backend: {exc}",
                                    error=f"The backend rejected the payment: {exc}", invoice=None)
            except BackendUnavailable as exc:
                # The adapter guarantees this means the request was not sent.
                return self._finish(intent.id, PaymentState.FAILED, f"not sent: {exc}",
                                    error=f"Not sent: {exc}", invoice=None)
            except PaymentAlreadyKnown as exc:
                self._finish(intent.id, PaymentState.UNKNOWN, f"backend already has this payment: {exc}",
                             error="The backend already has a payment for this invoice; checking its state.")
                with self._lock:
                    self._sending.discard(intent.id)
                return self._reconcile_one(self._require(intent.id), backend)
            except PaymentOutcomeUnknown as exc:
                return self._finish(
                    intent.id, PaymentState.UNKNOWN, f"no definitive answer: {exc}",
                    error="The outcome of this payment is unknown. It may still complete. It will be checked "
                          "against the backend automatically; do not pay this invoice again elsewhere.")
            except Exception as exc:  # anything unexpected after submission is an unknown outcome
                log.error("payment %s: unexpected %s during submission", intent.id[:8], type(exc).__name__)
                return self._finish(
                    intent.id, PaymentState.UNKNOWN, f"unexpected error during submission ({type(exc).__name__})",
                    error="The outcome of this payment is unknown after an unexpected error. It will be "
                          "checked against the backend; do not pay this invoice again elsewhere.")

            if result.payment_hash and result.payment_hash != intent.payment_hash:
                return self._finish(intent.id, PaymentState.UNKNOWN,
                                    "backend answered for a different payment hash",
                                    error="The backend's answer did not match this payment; the outcome is unknown.")
            if result.status is OutgoingStatus.SUCCEEDED:
                return self._finish(intent.id, PaymentState.SUCCEEDED, "backend reports the payment succeeded",
                                    fee_paid_msat=result.fee_msat, settled_at=self._now(), invoice=None, error="")
            if result.status is OutgoingStatus.FAILED:
                text = failure_text(result.failure_reason)
                return self._finish(intent.id, PaymentState.FAILED, f"backend reports failure: {text}",
                                    error=f"Payment failed: {text}.", invoice=None)
            return self._finish(intent.id, PaymentState.PENDING, "backend reports the payment is in flight")
        finally:
            with self._lock:
                self._sending.discard(intent.id)

    def _finish(self, intent_id: str, state: PaymentState, detail: str, **fields) -> PaymentIntent:
        with self._lock:
            intent = self._repo.transition(intent_id, state, now=self._now(), detail=detail, **fields)
        log.info("payment %s is now %s", intent_id[:8], state.value)
        return intent

    def cancel(self, intent_id: str) -> PaymentIntent:
        """Cancel before submission. A submitted payment cannot be cancelled from here."""
        with self._lock:
            intent = self._require(intent_id)
            if intent.state not in (PaymentState.DRAFT, PaymentState.AWAITING_APPROVAL):
                raise InvalidPaymentState(
                    f"This payment is “{intent.state.label}”; only payments that were not submitted can be cancelled.")
            return self._repo.transition(intent.id, PaymentState.CANCELLED, now=self._now(),
                                         detail="cancelled by the user before submission", invoice=None)

    # -------------------------------------------------------- bitcoin (BIP21)
    def create_bitcoin_request(self, address: str, *, amount_sat: int | None = None, label: str = "",
                               message: str = "", publisher: PublisherRef | None = None,
                               transfer_id: str | None = None) -> tuple[PaymentIntent, str]:
        """Build a BIP21 URI for an external wallet and record the intent. Opens nothing."""
        publisher = publisher or PublisherRef()
        network = self._pay().expected_network
        info = validate_address(address, network)
        amount_msat: int | None = None
        if amount_sat is not None:
            amount = require_int(amount_sat, "amount")
            if amount <= 0 or amount > MAX_SAT:
                raise AmountError("Enter a positive number of satoshis.")
            amount_msat = sat_to_msat(amount)
        uri = build_bip21(info.address, network=network, amount_sat=amount_sat, label=label, message=message)
        now = self._now()
        intent = PaymentIntent(
            id=uuid.uuid4().hex, direction=PaymentDirection.OUTGOING, kind=PaymentKind.BITCOIN_EXTERNAL,
            state=PaymentState.DRAFT, network=network, amount_msat=amount_msat, backend="external-wallet",
            destination=info.address, description=sanitise_text(message or label),
            publisher_name=sanitise_text(publisher.name, 120), publisher_trust=publisher.trust,
            transfer_id=transfer_id, manifest_id=publisher.manifest_id, created_at=now, updated_at=now)
        with self._lock:
            self._repo.insert(intent, "created")
            intent = self._repo.transition(intent.id, PaymentState.AWAITING_APPROVAL, now=now,
                                           detail="BIP21 request prepared; not yet opened in a wallet")
        return intent, uri

    def bitcoin_request_summary(self, intent_id: str) -> ApprovalSummary:
        intent = self._require(intent_id)
        warnings = ["Your wallet, not this application, sends the transaction. This application cannot see "
                    "whether it was broadcast or confirmed.",
                    "On-chain transactions are public and permanent."]
        if intent.publisher_trust is not PublisherTrust.VERIFIED:
            warnings.append("The address comes from publisher-supplied data that has not been verified.")
        return self._summary(intent, "Bitcoin address", "", tuple(warnings))

    def mark_wallet_opened(self, intent_id: str) -> PaymentIntent:
        """Record that the BIP21 URI was handed to an external wallet (after an explicit click).

        The record moves to ``UNKNOWN`` – "handed to external wallet, outcome not
        tracked" – and stays there.  Opening a wallet is not evidence of payment.
        """
        with self._lock:
            intent = self._require(intent_id)
            if intent.kind is not PaymentKind.BITCOIN_EXTERNAL:
                raise InvalidPaymentState("This is not an external-wallet payment request.")
            if intent.state is PaymentState.UNKNOWN:
                return intent
            return self._repo.transition(
                intent.id, PaymentState.UNKNOWN, now=self._now(), expected=(PaymentState.AWAITING_APPROVAL,),
                detail="handed to external wallet; outcome not tracked", submitted_at=self._now(),
                error="Handed to your external wallet. This application does not track whether the "
                      "transaction was sent or confirmed.")

    # ------------------------------------------------------------- incoming
    def create_incoming_invoice(self, amount_msat: int, *, memo: str = "", expiry_s: int | None = None,
                                transfer_id: str | None = None) -> PaymentIntent:
        """Create an invoice on the backend so someone can tip you. Returns it in ``PENDING``."""
        amount = require_msat(amount_msat)
        if amount <= 0:
            raise PaymentLimitError("Enter an amount for the invoice.")
        self._check_limits(amount)
        pay = self._pay()
        expiry = int(expiry_s) if expiry_s is not None else int(pay.invoice_expiry_s)
        if isinstance(expiry_s, bool) or expiry < 60 or expiry > 7 * 24 * 3600:
            raise PaymentLimitError("The invoice expiry must be between one minute and seven days.")
        backend = self._backend(required=True)
        info = backend.get_info()
        if info.network != pay.expected_network:
            raise PaymentError(f"The Lightning node is on {info.network or 'an unknown network'}, but payments "
                               f"are configured for {pay.expected_network}.")
        memo = sanitise_text(memo, MAX_MEMO_LENGTH)
        now = self._now()
        intent = PaymentIntent(
            id=uuid.uuid4().hex, direction=PaymentDirection.INCOMING, kind=PaymentKind.LIGHTNING_RECEIVE,
            state=PaymentState.DRAFT, network=pay.expected_network, amount_msat=amount, backend=backend.name,
            destination=info.pubkey, description=memo, transfer_id=transfer_id, created_at=now, updated_at=now)
        with self._lock:
            self._repo.insert(intent, "created")
        try:
            created = backend.create_invoice(amount, memo=memo, expiry_s=expiry)
        except BackendError as exc:
            self._finish(intent.id, PaymentState.FAILED, f"invoice creation failed: {exc}",
                         error=f"The invoice could not be created: {exc}")
            raise
        return self._finish(intent.id, PaymentState.PENDING, "invoice created; waiting for payment",
                            invoice=created.payment_request, payment_hash=created.payment_hash,
                            expires_at=now + expiry)

    # -------------------------------------------------- refresh / reconcile
    def refresh(self, intent_id: str) -> PaymentIntent:
        """Explicit "check status": read-only against the backend, never (re)sends.

        Raises ``BackendUnavailable`` when the state cannot be checked.
        """
        intent = self._require(intent_id)
        with self._lock:
            if intent.id in self._sending:
                return intent
        if intent.state is PaymentState.AWAITING_APPROVAL:
            return self._expire_unapproved(intent)
        if intent.kind is PaymentKind.BITCOIN_EXTERNAL or intent.state not in _OPEN_STATES:
            return intent
        return self._reconcile_one(intent, self._backend(required=True), raise_unavailable=True)

    def poll_open(self) -> list[PaymentIntent]:
        """Check every open Lightning record once; returns the intents whose state changed.

        Intended for a low-frequency timer on a worker thread while the payments
        page is visible or an invoice is displayed.  Without a reachable backend,
        states are left untouched (only unapproved, locally expired intents are closed).
        """
        changed: list[PaymentIntent] = []
        for intent in self._repo.list(limit=500, states=(PaymentState.AWAITING_APPROVAL,)):
            updated = self._expire_unapproved(intent)
            if updated.state is not intent.state:
                changed.append(updated)
        open_intents = [i for i in self._repo.list(limit=500, states=_OPEN_STATES)
                        if i.kind is not PaymentKind.BITCOIN_EXTERNAL]
        if not open_intents:
            return changed
        backend = self._backend(required=False)
        if backend is None:
            return changed
        for intent in open_intents:
            with self._lock:
                if intent.id in self._sending:
                    continue
            try:
                updated = self._reconcile_one(intent, backend, raise_unavailable=True)
            except BackendUnavailable:
                break  # backend unreachable: keep every state as it is
            if updated.state is not intent.state:
                changed.append(updated)
        return changed

    def reconcile_on_startup(self) -> ReconciliationReport:
        """Resolve payments left open by a previous run. Never resubmits anything."""
        report = ReconciliationReport()
        now = self._now()
        with self._lock:
            for intent in self._repo.list(limit=1000, states=(PaymentState.DRAFT,)):
                self._repo.transition(intent.id, PaymentState.FAILED, now=now,
                                      detail="interrupted before completion; nothing was submitted",
                                      error="Interrupted before completion. Nothing was sent.", invoice=None)
                report.interrupted += 1
                report.changed.append(intent.id)
            for intent in self._repo.list(limit=1000, states=(PaymentState.SUBMITTED,)):
                if intent.kind in _OUTGOING_LIGHTNING:
                    self._repo.transition(
                        intent.id, PaymentState.UNKNOWN, now=now,
                        detail="application stopped before the backend confirmed the outcome",
                        error="The application stopped before the backend confirmed the outcome. "
                              "The payment is being checked against the backend; it was not resubmitted.")
                    report.interrupted += 1
                    report.changed.append(intent.id)
        for intent in self._repo.list(limit=1000, states=(PaymentState.AWAITING_APPROVAL,)):
            updated = self._expire_unapproved(intent)
            if updated.state is PaymentState.EXPIRED:
                report.expired += 1
                report.changed.append(intent.id)

        open_intents = [i for i in self._repo.list(limit=1000, states=(PaymentState.PENDING, PaymentState.UNKNOWN))
                        if i.kind is not PaymentKind.BITCOIN_EXTERNAL]
        backend = self._backend(required=False) if open_intents else None
        if open_intents and backend is None:
            report.notes.append("No payment backend is available; open payments were left unchanged.")
        reachable = backend is not None
        for intent in open_intents:
            final = intent
            if reachable:
                try:
                    final = self._reconcile_one(intent, backend, raise_unavailable=True)
                    report.checked += 1
                except BackendUnavailable as exc:
                    reachable = False
                    report.notes.append(f"The payment backend is not reachable ({exc}); "
                                        "open payments were left unchanged.")
            if final.state is not intent.state and intent.id not in report.changed:
                report.changed.append(intent.id)
            if final.state is PaymentState.SUCCEEDED:
                report.succeeded += 1
            elif final.state is PaymentState.FAILED:
                report.failed += 1
            elif final.state is PaymentState.EXPIRED:
                report.expired += 1
            elif final.state is PaymentState.PENDING:
                report.pending += 1
            elif final.state is PaymentState.UNKNOWN:
                report.unknown += 1
        report.backend_reachable = reachable and backend is not None
        log.info("%s", report.summary())
        return report

    def _expire_unapproved(self, intent: PaymentIntent) -> PaymentIntent:
        if (intent.state is PaymentState.AWAITING_APPROVAL and intent.kind in _OUTGOING_LIGHTNING
                and intent.expires_at is not None and self._now() >= intent.expires_at):
            with self._lock:
                try:
                    return self._repo.transition(intent.id, PaymentState.EXPIRED, now=self._now(),
                                                 expected=(PaymentState.AWAITING_APPROVAL,),
                                                 detail="invoice expired before approval; nothing was sent",
                                                 error="The invoice expired before it was approved. Nothing was sent.",
                                                 invoice=None)
                except InvalidPaymentState:
                    return self._require(intent.id)
        return intent

    def _reconcile_one(self, intent: PaymentIntent, backend: LightningBackend, *,
                       raise_unavailable: bool = False) -> PaymentIntent:
        """Read the backend's view of one open intent and apply the resulting decision."""
        if not intent.payment_hash:
            return intent
        now = self._now()
        try:
            if intent.direction is PaymentDirection.INCOMING:
                try:
                    lookup = backend.lookup_invoice(intent.payment_hash)
                except PaymentNotFound:
                    lookup = None
                decision = decide_incoming(intent, lookup, now=now)
            else:
                try:
                    result = backend.track_payment(intent.payment_hash)
                except PaymentNotFound:
                    result = None
                decision = decide_outgoing(intent, result, now=now)
        except (BackendUnavailable, PaymentOutcomeUnknown) as exc:
            if raise_unavailable:
                raise BackendUnavailable(str(exc)) from exc
            return intent
        except BackendRejected as exc:
            if raise_unavailable:
                raise BackendUnavailable(f"The backend refused the status request: {exc}") from exc
            return intent
        return self._apply(intent, decision, now)

    def _apply(self, intent: PaymentIntent, decision: Decision, now: int) -> PaymentIntent:
        with self._lock:
            current = self._require(intent.id)
            if current.state is not intent.state or current.id in self._sending:
                return current  # changed concurrently; the newer state wins
            if decision.state is None:
                if decision.error and decision.error != current.error:
                    return self._repo.annotate(current.id, now=now, error=decision.error) or current
                return current
            fields: dict = {"error": decision.error}
            if decision.state.terminal:
                fields["invoice"] = None
            if decision.settled:
                fields["settled_at"] = now
            if decision.fee_paid_msat is not None:
                fields["fee_paid_msat"] = decision.fee_paid_msat
            updated = self._repo.transition(current.id, decision.state, now=now,
                                            detail="reconciliation: " + decision.detail, **fields)
        log.info("payment %s reconciled: %s -> %s", intent.id[:8], intent.state.value, decision.state.value)
        return updated

    # ------------------------------------------------------------- queries
    def list_payments(self, *, limit: int = 200, direction: PaymentDirection | None = None,
                      state: PaymentState | None = None, transfer_id: str | None = None) -> list[PaymentIntent]:
        return self._repo.list(limit=limit, direction=direction, states=(state,) if state else None,
                               transfer_id=transfer_id)

    def get(self, intent_id: str) -> PaymentIntent | None:
        return self._repo.get(intent_id)

    def events(self, intent_id: str) -> list[PaymentEvent]:
        return self._repo.events(intent_id)

    def tip_presets_msat(self) -> list[int]:
        lo, hi = self._limits_msat()
        return [sat_to_msat(s) for s in self._pay().tip_presets_sat if lo <= sat_to_msat(s) <= hi]

    def limits_text(self) -> str:
        pay = self._pay()
        return f"Between {format_sats(pay.min_payment_sat)} and {format_sats(pay.max_payment_sat)} per payment."

    def describe_amount_paid(self, intent: PaymentIntent) -> str:
        """Amount (+ fee) text for history rows; msat are rounded *up* to whole sats for money paid."""
        if intent.amount_msat is None:
            return "amount chosen in wallet"
        text = format_sats(msat_to_sat_ceil(intent.amount_msat))
        if intent.fee_paid_msat:
            text += f" + {format_sats(msat_to_sat_ceil(intent.fee_paid_msat))} fee"
        return text

    def diagnostics(self) -> dict:
        """Redaction-safe summary: no invoices, no credentials, hashes truncated."""
        status = self.backend_status()
        open_rows = []
        for intent in self._repo.list(limit=50, states=_OPEN_STATES):
            open_rows.append({
                "id": intent.id[:8], "kind": intent.kind.value, "direction": intent.direction.value,
                "state": intent.state.value, "hash_prefix": (intent.payment_hash or "")[:8],
                "age_s": max(0, self._now() - intent.created_at),
            })
        return {
            "backend": {"configured": status.configured, "connected": status.connected, "name": status.name,
                        "network": status.network, "network_matches": status.network_matches,
                        "synced": status.synced, "version": status.version, "message": status.message},
            "expected_network": self._pay().expected_network,
            "counts_by_state": self._repo.counts_by_state(),
            "counts_by_kind": self._repo.counts_by_kind(),
            "open": open_rows,
            "recent_transitions": [
                {"id": r["payment_id"][:8], "ts": r["ts"], "from": r["from_state"], "to": r["to_state"]}
                for r in self._repo.recent_events(20)],
        }
