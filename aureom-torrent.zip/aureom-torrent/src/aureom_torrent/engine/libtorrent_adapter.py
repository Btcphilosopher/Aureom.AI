"""libtorrent implementation of :class:`engine.interface.TorrentEngine`.

Threading
---------
One *owner thread* creates the ``lt.session``, executes commands in order and
consumes alerts continuously.  No other thread touches libtorrent objects.

* ``submit()`` enqueues a command (never blocks).
* Each loop iteration drains the command queue, waits up to ``TICK_MS`` for an
  alert, pops and translates all pending alerts, and runs periodic work
  (status snapshots, debounced resume-data saves, interface watchdog).
* Events are delivered by calling ``sink(event)`` on the owner thread; the
  sink only enqueues (see ``services.event_pump``).

Progress semantics
------------------
Status is requested *without* ``query_accurate_download_counters``; libtorrent
then reports ``total_wanted_done``/``total_done`` from pieces that passed the
hash check only, at piece granularity.  A piece that straddles a selected and
a deselected file is downloaded and counted whole (the deselected part is kept
in the engine's ``.parts`` file).

Written against libtorrent 2.1.3.
"""

from __future__ import annotations

import logging
import queue
import socket
import threading
import time
from typing import Any

import libtorrent as lt

from ..domain.identity import TorrentIdentity
from ..domain.transfers import (EnginePhase, FileView, PeerView, TorrentStatus, TrackerView, TransferDetails)
from . import commands as c
from . import events as e
from .interface import EngineCapabilities, EventSink, TorrentFormatError
from .libtorrent_codec import (identity_from_info_hashes, load_params, metadata_from_torrent_info,
                               torrent_bytes_from_params)

log = logging.getLogger(__name__)

TICK_MS = 100
SESSION_STATS_INTERVAL_S = 2.0
INTERFACE_CHECK_INTERVAL_S = 3.0
MAX_PEERS_IN_DETAILS = 500

_STATUS_FLAGS = 0xFFFFFFFF & ~int(lt.status_flags_t.query_accurate_download_counters) \
    & ~int(lt.status_flags_t.query_distributed_copies) & ~int(lt.status_flags_t.query_pieces) \
    & ~int(lt.status_flags_t.query_verified_pieces)

_PHASES = {
    "checking_resume_data": EnginePhase.CHECKING_RESUME,
    "checking_files": EnginePhase.CHECKING_FILES,
    "queued_for_checking": EnginePhase.CHECKING_FILES,
    "allocating": EnginePhase.CHECKING_FILES,
    "downloading_metadata": EnginePhase.DOWNLOADING_METADATA,
    "downloading": EnginePhase.DOWNLOADING,
    "finished": EnginePhase.FINISHED,
    "seeding": EnginePhase.SEEDING,
}

_PROXY_TYPES = {
    "none": lt.proxy_type_t.none, "socks5": lt.proxy_type_t.socks5, "socks5_pw": lt.proxy_type_t.socks5_pw,
    "http": lt.proxy_type_t.http, "http_pw": lt.proxy_type_t.http_pw,
}


def build_settings_pack(s: c.EngineSettings) -> dict[str, Any]:
    """Translate neutral settings to a libtorrent settings pack (pure; unit-tested)."""
    proxied = s.proxy_kind != "none"
    http_proxy = s.proxy_kind in ("http", "http_pw")
    pack: dict[str, Any] = {
        "user_agent": s.user_agent,
        "alert_mask": int(lt.alert_category.status | lt.alert_category.storage | lt.alert_category.error
                          | lt.alert_category.tracker | lt.alert_category.port_mapping),
        "alert_queue_size": 10_000,
        "listen_interfaces": s.listen_interfaces,
        "enable_dht": s.enable_dht,
        "enable_lsd": s.enable_lsd,
        "enable_upnp": s.enable_upnp,
        "enable_natpmp": s.enable_natpmp,
        "connections_limit": s.max_connections,
        "active_downloads": s.active_downloads,
        "active_seeds": s.active_seeds,
        "active_limit": s.active_limit,
        "download_rate_limit": max(0, s.download_rate_limit),
        "upload_rate_limit": max(0, s.upload_rate_limit),
        "stop_tracker_timeout": 2,
        "anonymous_mode": False,
        "enable_incoming_utp": True,
        "enable_outgoing_utp": True,
        "proxy_type": int(_PROXY_TYPES.get(s.proxy_kind, lt.proxy_type_t.none)),
        "proxy_hostname": s.proxy_host if proxied else "",
        "proxy_port": s.proxy_port if proxied else 0,
        "proxy_username": s.proxy_username if proxied else "",
        "proxy_password": s.proxy_password if proxied else "",
        "proxy_peer_connections": s.proxy_peers,
        "proxy_tracker_connections": s.proxy_trackers,
        "proxy_hostnames": s.proxy_hostnames,
    }
    policy = {"enabled": lt.enc_policy.enabled, "forced": lt.enc_policy.forced,
              "disabled": lt.enc_policy.disabled}.get(s.encryption, lt.enc_policy.enabled)
    pack["in_enc_policy"] = int(policy)
    pack["out_enc_policy"] = int(policy)
    pack["allowed_enc_level"] = int(lt.enc_level.rc4 if s.encryption == "forced" else lt.enc_level.both)
    if proxied:
        # Nothing may bypass a configured proxy: local discovery and port mapping talk to the
        # local network directly, so they are switched off whenever a proxy is in use.
        pack["enable_lsd"] = False
        pack["enable_upnp"] = False
        pack["enable_natpmp"] = False
        if http_proxy or not s.proxy_peers:
            pass
        if http_proxy:
            # An HTTP proxy cannot carry UDP: disable DHT and uTP rather than send them directly.
            pack["enable_dht"] = False
            pack["enable_incoming_utp"] = False
            pack["enable_outgoing_utp"] = False
    if s.isolated:
        pack.update({
            "enable_dht": False, "enable_lsd": False, "enable_upnp": False, "enable_natpmp": False,
            "allow_multiple_connections_per_ip": True, "dht_bootstrap_nodes": "",
            "min_reconnect_time": 1,
        })
    return pack


def convert_status(st, transfer_id: str, session_paused: bool) -> TorrentStatus:
    flags = int(st.flags)
    paused = bool(flags & int(lt.torrent_flags.paused))
    phase = _PHASES.get(str(st.state), EnginePhase.UNKNOWN)
    error = ""
    try:
        if st.errc.value() != 0:
            error = st.errc.message()
    except Exception:
        error = str(getattr(st, "error", "") or "")
    checking = phase in (EnginePhase.CHECKING_FILES, EnginePhase.CHECKING_RESUME)
    identity = None
    try:
        identity = identity_from_info_hashes(st.info_hashes)
    except Exception:
        pass
    return TorrentStatus(
        transfer_id=transfer_id,
        phase=phase,
        paused=paused,
        auto_managed=bool(flags & int(lt.torrent_flags.auto_managed)),
        session_paused=session_paused,
        has_metadata=bool(st.has_metadata),
        moving_storage=bool(st.moving_storage),
        is_finished=bool(st.is_finished) and bool(st.has_metadata),
        is_seeding=bool(st.is_seeding) and bool(st.has_metadata),
        upload_mode=bool(flags & int(lt.torrent_flags.upload_mode)),
        error=error,
        error_file="",
        name=st.name or "",
        save_path=st.save_path or "",
        total=int(st.total),
        total_wanted=int(st.total_wanted),
        wanted_done=int(st.total_wanted_done),
        total_done=int(st.total_done),
        pieces_total=0,
        pieces_have=int(st.num_pieces),
        download_rate=int(st.download_payload_rate),
        upload_rate=int(st.upload_payload_rate),
        all_time_download=int(st.all_time_download),
        all_time_upload=int(st.all_time_upload),
        num_peers=int(st.num_peers),
        num_seeds=int(st.num_seeds),
        list_peers=int(st.list_peers),
        queue_position=int(st.queue_position),
        seeding_seconds=int(st.seeding_duration.total_seconds()) if hasattr(st.seeding_duration, "total_seconds")
        else int(st.seeding_time),
        active_seconds=int(st.active_duration.total_seconds()) if hasattr(st.active_duration, "total_seconds")
        else int(st.active_time),
        checking_progress_ppm=int(st.progress_ppm) if checking else 0,
        next_announce_s=max(0, int(st.next_announce.total_seconds())) if hasattr(st.next_announce, "total_seconds") else 0,
        current_tracker=st.current_tracker or "",
        identity=identity,
    )


class LibtorrentEngine:
    def __init__(self) -> None:
        self._commands: "queue.SimpleQueue[Any]" = queue.SimpleQueue()
        self._thread: threading.Thread | None = None
        self._sink: EventSink = lambda event: None
        self._settings = c.EngineSettings()
        self._stop = threading.Event()
        self._stop_timeout = 10.0
        self._report: e.ShutdownReport | None = None
        self._ses: Any = None
        # owner-thread state
        self._handles: dict[str, Any] = {}
        self._ids: dict[Any, str] = {}
        self._previews: set[str] = set()
        self._confirming: dict[str, c.ConfirmPreview] = {}
        self._removing: dict[Any, str] = {}
        self._deleting: dict[str, str] = {}
        self._exports: set[str] = set()
        self._resume_pending: set[str] = set()
        self._dirty: set[str] = set()
        self._last_error: dict[str, str] = {}
        self._session_paused = False
        self._paused_by_fault = False
        self._stats: dict[str, int] = {}
        self._listen_port = 0
        self._listening = False
        # Status freshness: a state_update_alert answers one post_torrent_updates() call. After an
        # operation that changes what "finished" means (confirming a preview), snapshots requested
        # before that operation are stale and must not reach the application.
        self._posts_issued = 0
        self._updates_seen = 0
        self._fresh_after: dict[str, int] = {}

    # ------------------------------------------------------------------ API
    def capabilities(self) -> EngineCapabilities:
        return EngineCapabilities(
            engine="libtorrent", version=lt.__version__,
            notes=(
                "BitTorrent v1, v2 and hybrid torrents are supported by the engine.",
                "Web seeds: BEP 19 (url-list) only; BEP 17 HTTP seeds are not offered.",
                "WebTorrent and I2P are not enabled in the PyPI build of the bindings.",
                "Peer exchange is a session plug-in: changing it takes effect at the next start.",
                "A complete .torrent for a v2/hybrid magnet can only be exported after the payload "
                "is verified (piece layers are not part of magnet metadata).",
            ),
        )

    def start(self, settings: c.EngineSettings, sink: EventSink) -> None:
        if self._thread is not None:
            raise RuntimeError("engine already started")
        self._settings = settings
        self._sink = sink
        self._thread = threading.Thread(target=self._run, name="aureom-engine", daemon=True)
        self._thread.start()

    def submit(self, command: c.Command) -> None:
        self._commands.put(command)

    def shutdown(self, timeout: float) -> e.ShutdownReport:
        if self._thread is None:
            return e.ShutdownReport(clean=True, message="engine was not running")
        self._stop_timeout = max(0.5, timeout)
        self._stop.set()
        self._thread.join(timeout + 5.0)
        if self._thread.is_alive():
            return e.ShutdownReport(clean=False, resume_unsaved=tuple(self._handles),
                                    message="the engine did not stop in time; resume state may be stale")
        return self._report or e.ShutdownReport(clean=False, message="engine stopped without a report")

    # ------------------------------------------------------------ main loop
    def _emit(self, event: Any) -> None:
        try:
            self._sink(event)
        except Exception:
            log.exception("event sink failed for %s", type(event).__name__)

    def _run(self) -> None:
        try:
            pack = build_settings_pack(self._settings)
            ses = lt.session(pack, 0)  # no default plug-ins: add exactly the ones configured
            ses.add_extension("ut_metadata")
            ses.add_extension("smart_ban")
            if self._settings.enable_pex and not self._settings.isolated:
                ses.add_extension("ut_pex")
            self._ses = ses
        except Exception as exc:
            log.exception("engine start failed")
            self._emit(e.EngineFault(f"The BitTorrent engine could not start: {exc}", networking_stopped=True))
            self._report = e.ShutdownReport(clean=False, message=str(exc))
            self._emit(e.EngineStopped(self._report))
            return
        log.info("libtorrent %s session started (dht=%s lsd=%s pex=%s)", lt.__version__,
                 pack["enable_dht"], pack["enable_lsd"], self._settings.enable_pex)
        self._emit(e.EngineStarted("libtorrent", lt.__version__))

        next_status = next_stats = next_resume = next_iface = 0.0
        while not self._stop.is_set():
            self._drain_commands()
            try:
                if ses.wait_for_alert(TICK_MS) is not None:
                    self._drain_alerts()
            except Exception:
                log.exception("alert processing failed")
            now = time.monotonic()
            if now >= next_status:
                ses.post_torrent_updates(_STATUS_FLAGS)
                self._posts_issued += 1
                next_status = now + self._settings.status_interval_ms / 1000.0
            if now >= next_stats:
                ses.post_session_stats()
                next_stats = now + SESSION_STATS_INTERVAL_S
            if now >= next_resume:
                if next_resume:
                    self._save_dirty()
                next_resume = now + self._settings.resume_save_interval_s
            if self._settings.bound_interface and now >= next_iface:
                self._check_interface()
                next_iface = now + INTERFACE_CHECK_INTERVAL_S
        self._shutdown_session()

    def _drain_commands(self) -> None:
        for _ in range(500):
            try:
                command = self._commands.get_nowait()
            except queue.Empty:
                return
            try:
                self._handle(command)
            except Exception as exc:
                log.exception("command %s failed", type(command).__name__)
                tid = getattr(command, "transfer_id", None)
                if tid:
                    self._emit(e.TransferNotice(tid, "error", "engine", f"{type(command).__name__} failed: {exc}"))

    # ------------------------------------------------------------- commands
    def _handle(self, cmd: Any) -> None:
        if isinstance(cmd, c.AddTorrent):
            return self._add(cmd)
        if isinstance(cmd, c.ApplySettings):
            self._settings = cmd.settings
            self._ses.apply_settings(build_settings_pack(cmd.settings))
            return None
        if isinstance(cmd, c.SetSessionPaused):
            self._set_session_paused(cmd.paused)
            return None
        if isinstance(cmd, c.SaveResumeData) and cmd.transfer_id is None:
            self._save_dirty(force=True)
            return None

        tid = cmd.transfer_id
        h = self._handles.get(tid)
        if h is None or not h.is_valid():
            if isinstance(cmd, c.RemoveTorrent):
                self._emit(e.TorrentRemoved(tid))  # already gone: removal is idempotent
            else:
                log.debug("%s for unknown transfer %s ignored", type(cmd).__name__, tid)
            return None

        if isinstance(cmd, c.PauseTorrent):
            h.unset_flags(lt.torrent_flags.auto_managed)
            h.pause()
            self._dirty.add(tid)
        elif isinstance(cmd, c.ResumeTorrent):
            self._last_error.pop(tid, None)
            h.clear_error()
            h.unset_flags(lt.torrent_flags.stop_when_ready)
            h.set_flags(lt.torrent_flags.auto_managed)
            h.resume()
            self._dirty.add(tid)
        elif isinstance(cmd, c.ForceRecheck):
            st = h.status(0)
            stopped = bool(int(st.flags) & int(lt.torrent_flags.paused)) and not bool(
                int(st.flags) & int(lt.torrent_flags.auto_managed))
            h.clear_error()
            h.force_recheck()
            if stopped:
                # Check now, then return to the paused state the user chose.
                h.set_flags(lt.torrent_flags.stop_when_ready)
                h.resume()
            self._dirty.add(tid)
        elif isinstance(cmd, c.SetFilePriorities):
            h.prioritize_files([int(p) for p in cmd.priorities])
            self._dirty.add(tid)
        elif isinstance(cmd, c.MoveStorage):
            h.move_storage(cmd.new_path, lt.move_flags_t.fail_if_exist)
        elif isinstance(cmd, c.ConfirmPreview):
            self._confirming[tid] = cmd
            # Nothing has been downloaded: re-point storage (existing data at the destination is checked).
            h.move_storage(cmd.save_path, lt.move_flags_t.reset_save_path)
        elif isinstance(cmd, c.SetTorrentLimits):
            h.set_download_limit(cmd.download_limit if cmd.download_limit > 0 else -1)
            h.set_upload_limit(cmd.upload_limit if cmd.upload_limit > 0 else -1)
            self._dirty.add(tid)
        elif isinstance(cmd, c.ReplaceTrackers):
            entries = []
            for url, tier in cmd.trackers:
                ae = lt.announce_entry(url)
                ae.tier = int(tier)
                entries.append(ae)
            h.replace_trackers(entries)
            h.force_reannounce()
            self._dirty.add(tid)
        elif isinstance(cmd, c.Reannounce):
            h.force_reannounce()
        elif isinstance(cmd, c.ConnectPeer):
            h.connect_peer((cmd.host, int(cmd.port)))
        elif isinstance(cmd, c.RequestDetails):
            self._emit(e.DetailsReady(self._details(tid, h, cmd)))
        elif isinstance(cmd, c.SaveResumeData):
            self._request_resume(tid, h, only_if_modified=False)
        elif isinstance(cmd, c.ExportTorrent):
            self._exports.add(tid)
            self._request_resume(tid, h, only_if_modified=False)
        elif isinstance(cmd, c.RemoveTorrent):
            self._removing[h] = tid
            if cmd.delete_files:
                self._deleting[self._hash_key(h.info_hashes())] = tid
                self._ses.remove_torrent(h, lt.options_t.delete_files)
            else:
                self._ses.remove_torrent(h)
            self._forget(tid, h)
        return None

    def _add(self, cmd: c.AddTorrent) -> None:
        tid = cmd.transfer_id
        if tid in self._handles:
            self._emit(e.TorrentAddFailed(tid, "This transfer is already loaded.", duplicate=True))
            return
        atp = None
        used_resume = False
        if cmd.resume_data:
            try:
                atp = lt.read_resume_data(cmd.resume_data)
                used_resume = True
            except Exception as exc:
                self._emit(e.TransferNotice(tid, "warning", "resume",
                                            f"Saved resume data could not be read ({exc}); existing files will be re-checked."))
                atp = None
        try:
            if atp is not None:
                if atp.ti is None and cmd.torrent_data:
                    atp.ti = load_params(cmd.torrent_data).ti
            elif cmd.torrent_data:
                atp = load_params(cmd.torrent_data)
            elif cmd.magnet_uri:
                atp = lt.parse_magnet_uri(cmd.magnet_uri)
            else:
                raise TorrentFormatError("Nothing to add: no torrent data, magnet link or resume data.")
        except TorrentFormatError as exc:
            self._emit(e.TorrentAddFailed(tid, str(exc)))
            return
        except Exception as exc:
            self._emit(e.TorrentAddFailed(tid, f"The magnet link was not accepted by the engine ({exc})."))
            return

        atp.save_path = cmd.save_path  # the database is authoritative for the destination
        flags = int(atp.flags)
        flags |= int(lt.torrent_flags.duplicate_is_error) | int(lt.torrent_flags.update_subscribe)
        flags &= ~int(lt.torrent_flags.seed_mode) & ~int(lt.torrent_flags.stop_when_ready)
        flags &= ~int(lt.torrent_flags.default_dont_download)
        if cmd.metadata_only:
            # Documented libtorrent behaviour: in upload mode a torrent "will not request any
            # pieces", so metadata is exchanged but no payload is downloaded or written. Files stay
            # selected so the torrent is not considered finished (which would drop seed peers).
            flags |= int(lt.torrent_flags.upload_mode)
            flags &= ~int(lt.torrent_flags.auto_managed) & ~int(lt.torrent_flags.paused)
        else:
            flags &= ~int(lt.torrent_flags.upload_mode)
            if cmd.paused:
                flags |= int(lt.torrent_flags.paused)
                flags &= ~int(lt.torrent_flags.auto_managed)
            else:
                flags |= int(lt.torrent_flags.auto_managed)
                flags &= ~int(lt.torrent_flags.paused)
        atp.flags = flags
        if cmd.file_priorities is not None and not cmd.metadata_only:
            atp.file_priorities = [int(p) for p in cmd.file_priorities]
        if cmd.download_limit > 0:
            atp.download_limit = cmd.download_limit
        if cmd.upload_limit > 0:
            atp.upload_limit = cmd.upload_limit
        try:
            h = self._ses.add_torrent(atp)
        except RuntimeError as exc:
            text = str(exc)
            self._emit(e.TorrentAddFailed(tid, f"The engine refused this torrent: {text}",
                                          duplicate="already" in text.lower() or "duplicate" in text.lower()))
            return
        self._handles[tid] = h
        self._ids[h] = tid
        if cmd.metadata_only:
            self._previews.add(tid)
        for host, port in cmd.peers:
            try:
                h.connect_peer((host, int(port)))
            except Exception:
                pass
        st = h.status(0)
        self._emit(e.TorrentAdded(tid, identity_from_info_hashes(h.info_hashes()), st.name or "", bool(st.has_metadata)))
        if not used_resume:
            self._dirty.add(tid)

    def _forget(self, tid: str, h: Any) -> None:
        self._handles.pop(tid, None)
        self._ids.pop(h, None)
        self._previews.discard(tid)
        self._confirming.pop(tid, None)
        self._exports.discard(tid)
        self._dirty.discard(tid)
        self._resume_pending.discard(tid)
        self._last_error.pop(tid, None)
        self._fresh_after.pop(tid, None)

    def _set_session_paused(self, paused: bool) -> None:
        if paused:
            self._ses.pause()
        elif not self._paused_by_fault:
            self._ses.resume()
        self._session_paused = paused

    # ---------------------------------------------------------- resume data
    def _request_resume(self, tid: str, h: Any, *, only_if_modified: bool) -> None:
        flags = int(lt.save_resume_flags_t.save_info_dict)
        if only_if_modified:
            flags |= int(lt.save_resume_flags_t.only_if_modified)
        try:
            h.save_resume_data(flags)
            self._resume_pending.add(tid)
        except Exception as exc:
            self._emit(e.ResumeDataFailed(tid, str(exc)))

    def _save_dirty(self, force: bool = False) -> int:
        """Debounced save: request resume data for transfers that changed since the last pass."""
        requested = 0
        for tid, h in list(self._handles.items()):
            if tid in self._previews or tid in self._resume_pending or not h.is_valid():
                continue
            try:
                needs = force or tid in self._dirty or h.need_save_resume_data()
            except Exception:
                needs = True
            if needs:
                self._request_resume(tid, h, only_if_modified=not (force or tid in self._dirty))
                requested += 1
        self._dirty.clear()
        return requested

    # --------------------------------------------------------------- alerts
    def _tid(self, alert: Any) -> str | None:
        try:
            return self._ids.get(alert.handle)
        except Exception:
            return None

    @staticmethod
    def _hash_key(info_hashes: Any) -> str:
        return str(info_hashes.get_best())

    def _drain_alerts(self) -> None:
        for alert in self._ses.pop_alerts():
            try:
                self._on_alert(alert)
            except Exception:
                log.exception("failed to handle %s", type(alert).__name__)

    def _on_alert(self, a: Any) -> None:  # noqa: C901 - a flat dispatch is the clearest form here
        if isinstance(a, lt.state_update_alert):
            self._updates_seen += 1
            statuses = []
            for st in a.status:
                tid = self._ids.get(st.handle)
                if tid is None:
                    continue
                barrier = self._fresh_after.get(tid)
                if barrier is not None:
                    if self._updates_seen <= barrier:
                        continue  # requested before the selection/destination changed
                    del self._fresh_after[tid]
                statuses.append(convert_status(st, tid, self._session_paused))
            if statuses:
                self._emit(e.StatusBatch(tuple(statuses), self._session_stats()))
            return
        if isinstance(a, lt.session_stats_alert):
            values = a.values
            self._stats = {
                "dht_nodes": int(values.get("dht.dht_nodes", 0)),
                "has_incoming": int(values.get("net.has_incoming_connections", 0)),
                "peers": int(values.get("peer.num_peers_connected", 0)),
            }
            self._emit(e.StatusBatch((), self._session_stats()))
            return
        if isinstance(a, lt.save_resume_data_alert):
            tid = self._tid(a)
            if tid is None:
                return
            self._resume_pending.discard(tid)
            if tid not in self._previews:
                self._emit(e.ResumeDataReady(tid, lt.write_resume_data_buf(a.params)))
            if tid in self._exports:
                self._exports.discard(tid)
                try:
                    self._emit(e.TorrentExported(tid, torrent_bytes_from_params(a.params)))
                except Exception as exc:
                    self._emit(e.TorrentExported(tid, None, self._export_reason(str(exc))))
            return
        if isinstance(a, lt.save_resume_data_failed_alert):
            tid = self._tid(a)
            if tid is None:
                return
            self._resume_pending.discard(tid)
            message = a.error.message() if hasattr(a, "error") else a.message()
            if tid in self._exports:
                self._exports.discard(tid)
                self._emit(e.TorrentExported(tid, None, f"The engine could not produce the torrent data ({message})."))
            if "not modified" not in message.lower():
                self._emit(e.ResumeDataFailed(tid, message))
            return
        if isinstance(a, lt.metadata_received_alert):
            tid = self._tid(a)
            if tid is None:
                return
            h = a.handle
            ti = h.torrent_file()
            if ti is None:
                return
            trackers = tuple((t["url"], int(t.get("tier", 0))) for t in h.trackers())
            metadata = metadata_from_torrent_info(ti, trackers=trackers, web_seeds=tuple(h.url_seeds()),
                                                  raw=b"x")
            data: bytes | None = None
            try:
                atp = lt.add_torrent_params()
                atp.ti = ti
                atp.trackers = [t[0] for t in trackers]
                atp.tracker_tiers = [t[1] for t in trackers]
                data = torrent_bytes_from_params(atp)
            except Exception:
                data = None  # v2/hybrid: piece layers are not known yet
            self._emit(e.MetadataReceived(tid, metadata, data))
            if tid not in self._previews:
                self._dirty.add(tid)
            return
        if isinstance(a, lt.torrent_finished_alert):
            tid = self._tid(a)
            if tid and tid not in self._previews:
                self._emit(e.TorrentFinished(tid))
                self._request_resume(tid, a.handle, only_if_modified=False)
            return
        if isinstance(a, lt.torrent_checked_alert):
            tid = self._tid(a)
            if tid and tid not in self._previews:
                self._emit(e.TorrentChecked(tid))
                self._dirty.add(tid)
            return
        if isinstance(a, lt.torrent_paused_alert):
            tid = self._tid(a)
            if tid and tid not in self._previews:
                self._emit(e.TorrentPaused(tid))
                self._dirty.add(tid)
            return
        if isinstance(a, lt.torrent_resumed_alert):
            tid = self._tid(a)
            if tid and tid not in self._previews:
                self._emit(e.TorrentResumed(tid))
            return
        if isinstance(a, lt.file_error_alert):
            self._error(self._tid(a), a.error.message(), a.filename(), "storage")
            return
        if isinstance(a, lt.torrent_error_alert):
            self._error(self._tid(a), a.error.message(), "", "storage")
            return
        if isinstance(a, lt.metadata_failed_alert):
            self._error(self._tid(a), f"The metadata received from peers was invalid ({a.error.message()}).", "", "metadata")
            return
        if isinstance(a, lt.hash_failed_alert):
            tid = self._tid(a)
            if tid:
                self._emit(e.PieceHashFailed(tid, int(a.piece_index)))
            return
        if isinstance(a, lt.storage_moved_alert):
            tid = self._tid(a)
            if tid is None:
                return
            confirm = self._confirming.pop(tid, None)
            if confirm is not None:
                self._finish_confirm(tid, a.handle, confirm)
            self._emit(e.StorageMoved(tid, a.storage_path()))
            self._request_resume(tid, a.handle, only_if_modified=False)
            return
        if isinstance(a, lt.storage_moved_failed_alert):
            tid = self._tid(a)
            if tid:
                self._confirming.pop(tid, None)
                detail = a.error.message()
                try:
                    path = a.file_path()
                    if path:
                        detail = f"{detail}: {path}"
                except Exception:
                    pass
                self._emit(e.StorageMoveFailed(tid, detail))
            return
        if isinstance(a, lt.torrent_removed_alert):
            tid = self._removing.pop(a.handle, None)
            if tid:
                self._emit(e.TorrentRemoved(tid))
            return
        if isinstance(a, lt.torrent_deleted_alert):
            tid = self._deleting.pop(self._hash_key(a.info_hashes), None)
            if tid:
                self._emit(e.FilesDeleted(tid))
            return
        if isinstance(a, lt.torrent_delete_failed_alert):
            tid = self._deleting.pop(self._hash_key(a.info_hashes), None)
            if tid:
                self._emit(e.FilesDeleteFailed(tid, a.error.message()))
            return
        if isinstance(a, lt.tracker_reply_alert):
            tid = self._tid(a)
            if tid:
                self._emit(e.TrackerAnnounced(tid, a.tracker_url(), True, "", int(a.num_peers)))
            return
        if isinstance(a, lt.tracker_error_alert):
            tid = self._tid(a)
            if tid:
                reason = ""
                try:
                    reason = a.failure_reason() or a.error.message()
                except Exception:
                    reason = a.error.message() if hasattr(a, "error") else a.message()
                self._emit(e.TrackerAnnounced(tid, a.tracker_url(), False, reason))
            return
        if isinstance(a, lt.tracker_warning_alert):
            tid = self._tid(a)
            if tid:
                self._emit(e.TransferNotice(tid, "warning", "tracker", f"Tracker warning: {a.message()}"))
            return
        if isinstance(a, lt.fastresume_rejected_alert):
            tid = self._tid(a)
            if tid:
                self._emit(e.TransferNotice(tid, "warning", "resume",
                                            f"Resume data was rejected ({a.error.message()}); existing files are being re-checked."))
            return
        if isinstance(a, lt.torrent_conflict_alert):
            tid = self._tid(a)
            other = self._ids.get(a.conflicting_torrent)
            if tid and other:
                self._emit(e.TorrentConflict(tid, other))
            return
        if isinstance(a, lt.listen_succeeded_alert):
            self._listening = True
            self._listen_port = int(a.port)
            self._emit(e.ListenResult(True, str(a.address), int(a.port), str(a.socket_type)))
            return
        if isinstance(a, lt.listen_failed_alert):
            self._emit(e.ListenResult(False, str(getattr(a, "address", "")), int(getattr(a, "port", 0)),
                                      str(getattr(a, "socket_type", "")), a.error.message()))
            return
        if isinstance(a, lt.portmap_alert):
            self._emit(e.PortMapped(True, str(a.map_protocol), int(a.external_port)))
            return
        if isinstance(a, lt.portmap_error_alert):
            self._emit(e.PortMapped(False, str(getattr(a, "map_transport", "")), 0, a.error.message()))
            return
        if isinstance(a, lt.alerts_dropped_alert):
            log.warning("the engine dropped alerts: %s", a.message())
            return

    def _error(self, tid: str | None, message: str, file: str, kind: str) -> None:
        if not tid or tid in self._previews and kind == "storage":
            return
        key = f"{message}|{file}"
        if self._last_error.get(tid) == key:
            return  # libtorrent repeats the alert for each failed operation
        self._last_error[tid] = key
        self._emit(e.TorrentErrored(tid, message, file, kind))

    @staticmethod
    def _export_reason(text: str) -> str:
        if "piece layer" in text:
            return ("A complete .torrent file is not available yet: for v2/hybrid torrents added from a "
                    "magnet link the engine learns the piece layers while it verifies the download.")
        return f"The engine could not produce the torrent data ({text})."

    def _finish_confirm(self, tid: str, h: Any, cmd: c.ConfirmPreview) -> None:
        self._previews.discard(tid)
        self._fresh_after[tid] = self._posts_issued
        if cmd.file_priorities is not None:
            h.prioritize_files([int(p) for p in cmd.file_priorities])
        h.unset_flags(lt.torrent_flags.upload_mode)
        if cmd.paused:
            h.unset_flags(lt.torrent_flags.auto_managed)
            h.pause()
        else:
            h.set_flags(lt.torrent_flags.auto_managed)
            h.resume()
        self._dirty.add(tid)

    def _session_stats(self) -> e.SessionStats:
        down = up = 0
        return e.SessionStats(
            download_rate=down, upload_rate=up,
            dht_nodes=self._stats.get("dht_nodes", 0),
            dht_enabled=bool(self._settings.enable_dht and not self._settings.isolated),
            listening=self._listening, listen_port=self._listen_port,
            has_incoming=bool(self._stats.get("has_incoming", 0)),
            num_peers=self._stats.get("peers", 0),
            paused=self._session_paused or self._paused_by_fault,
        )

    # -------------------------------------------------------------- details
    def _details(self, tid: str, h: Any, cmd: c.RequestDetails) -> TransferDetails:
        peers: list[PeerView] = []
        trackers: list[TrackerView] = []
        files: list[FileView] = []
        pieces = b""
        web_seeds: tuple[str, ...] = ()
        if cmd.peers:
            for p in h.get_peer_info()[:MAX_PEERS_IN_DETAILS]:
                flags = int(p.flags)
                marks = "".join(mark for mark, bit in (
                    ("I", lt.peer_info.interesting), ("C", lt.peer_info.choked),
                    ("i", lt.peer_info.remote_interested), ("c", lt.peer_info.remote_choked),
                    ("S", lt.peer_info.seed), ("E", lt.peer_info.rc4_encrypted),
                    ("e", lt.peer_info.plaintext_encrypted), ("U", lt.peer_info.upload_only)) if flags & int(bit))
                source = int(p.source)
                origin = ",".join(name for name, bit in (
                    ("tracker", lt.peer_info.tracker), ("DHT", lt.peer_info.dht), ("PEX", lt.peer_info.pex),
                    ("LSD", lt.peer_info.lsd), ("resume", lt.peer_info.resume_data)) if source & int(bit)) or "manual"
                ip = p.ip
                address = f"{ip[0]}:{ip[1]}" if isinstance(ip, tuple) else str(ip)
                try:
                    client = p.client.decode("utf-8", "replace") if isinstance(p.client, bytes) else str(p.client)
                except Exception:
                    client = ""
                kind = "web seed" if int(p.connection_type) == int(lt.peer_info.web_seed) else (
                    "uTP" if flags & int(getattr(lt.peer_info, "utp_socket", 0)) else "TCP")
                peers.append(PeerView(address, client[:64], int(p.progress_ppm), int(p.payload_down_speed),
                                      int(p.payload_up_speed), marks, origin, kind))
        if cmd.trackers:
            for t in h.trackers():
                trackers.append(_tracker_view(t))
            web_seeds = tuple(h.url_seeds())
        if cmd.files or cmd.pieces:
            st = h.status(int(lt.status_flags_t.query_pieces))
            if st.has_metadata:
                if cmd.files:
                    ti = h.torrent_file()
                    fs = ti.layout()
                    progress = h.file_progress(lt.file_progress_flags_t.piece_granularity)
                    prios = h.get_file_priorities()
                    for i in range(fs.num_files()):
                        files.append(FileView(i, fs.file_path(i).replace("\\", "/"), int(fs.file_size(i)),
                                              int(progress[i]) if i < len(progress) else 0,
                                              int(prios[i]) if i < len(prios) else 4,
                                              bool(fs.file_flags(i) & lt.file_storage.flag_pad_file)))
                if cmd.pieces:
                    pieces = bytes(1 if have else 0 for have in st.pieces)
        return TransferDetails(tid, tuple(peers), tuple(trackers), tuple(files), pieces, web_seeds)

    # ------------------------------------------------------------ interface
    def _check_interface(self) -> None:
        present = interface_present(self._settings.bound_interface)
        if not present and not self._paused_by_fault:
            self._paused_by_fault = True
            self._ses.pause()
            log.error("bound interface %s disappeared; BitTorrent networking stopped", self._settings.bound_interface)
            self._emit(e.EngineFault(
                f"The network interface “{self._settings.bound_interface}” is no longer available. "
                "BitTorrent networking has been stopped until it returns.", networking_stopped=True))
        elif present and self._paused_by_fault:
            self._paused_by_fault = False
            try:
                self._ses.reopen_network_sockets()
            except Exception:
                pass
            if not self._session_paused:
                self._ses.resume()
            self._emit(e.EngineFault(
                f"The network interface “{self._settings.bound_interface}” is back; networking resumed.",
                networking_stopped=False))

    # ------------------------------------------------------------- shutdown
    def _shutdown_session(self) -> None:
        deadline = time.monotonic() + self._stop_timeout
        ses = self._ses
        saved = 0
        try:
            self._drain_commands()  # honour commands queued just before shutdown (e.g. final pauses)
            ses.pause()
            self._resume_pending.clear()
            self._drain_alerts()
            waiting: set[str] = set()
            for tid, h in self._handles.items():
                if tid in self._previews or not h.is_valid():
                    continue
                try:
                    h.save_resume_data(int(lt.save_resume_flags_t.save_info_dict)
                                       | int(lt.save_resume_flags_t.flush_disk_cache))
                    waiting.add(tid)
                except Exception:
                    pass
            while waiting and time.monotonic() < deadline:
                ses.wait_for_alert(100)
                for a in ses.pop_alerts():
                    if isinstance(a, (lt.save_resume_data_alert, lt.save_resume_data_failed_alert)):
                        tid = self._tid(a)
                        if tid in waiting:
                            waiting.discard(tid)
                            if isinstance(a, lt.save_resume_data_alert):
                                self._emit(e.ResumeDataReady(tid, lt.write_resume_data_buf(a.params)))
                                saved += 1
                            else:
                                self._emit(e.ResumeDataFailed(tid, a.error.message()))
                    else:
                        try:
                            self._on_alert(a)
                        except Exception:
                            pass
            unsaved = tuple(sorted(waiting))
            self._report = e.ShutdownReport(
                clean=not unsaved, resume_saved=saved, resume_unsaved=unsaved,
                message="" if not unsaved else
                f"Resume data for {len(unsaved)} transfer(s) was not written before the shutdown time limit; "
                "they will be re-checked at the next start.")
        except Exception as exc:
            log.exception("engine shutdown failed")
            self._report = e.ShutdownReport(clean=False, resume_saved=saved, resume_unsaved=tuple(self._handles),
                                            message=f"shutdown error: {exc}")
        finally:
            self._emit(e.EngineStopped(self._report))
            self._handles.clear()
            self._ids.clear()
            self._ses = None
            del ses  # the session destructor stops trackers (bounded by stop_tracker_timeout)


def _tracker_view(t: dict) -> TrackerView:
    url = t.get("url", "")
    message = ""
    fails = 0
    seeds = leeches = -1
    next_announce = 0
    updating = False
    working = False
    now = time.time()
    for ep in t.get("endpoints", []) or []:
        for key in ("info_hashes", ):
            for ih in ep.get(key, []) or []:
                message = message or ih.get("message", "") or ""
                err = ih.get("last_error", {})
                if isinstance(err, dict) and err.get("value"):
                    message = message or str(err.get("message", ""))
                fails = max(fails, int(ih.get("fails", 0)))
                seeds = max(seeds, int(ih.get("scrape_complete", -1)))
                leeches = max(leeches, int(ih.get("scrape_incomplete", -1)))
                updating = updating or bool(ih.get("updating"))
                working = working or (int(ih.get("fails", 0)) == 0 and bool(ih.get("start_sent")))
                na = ih.get("next_announce")
                if hasattr(na, "timestamp"):
                    next_announce = max(next_announce, int(na.timestamp() - now))
    status = "updating" if updating else ("working" if working else ("error" if fails else "not contacted"))
    return TrackerView(url=url, tier=int(t.get("tier", 0)), status=status, message=message[:200],
                       seeds=seeds, leeches=leeches, next_announce_s=max(0, next_announce), fails=fails)


def interface_present(name_or_address: str) -> bool:
    """True when a device name exists or an IP literal can be bound on this host."""
    if not name_or_address:
        return True
    try:
        import ipaddress

        ip = ipaddress.ip_address(name_or_address)
    except ValueError:
        try:
            return name_or_address in {name for _, name in socket.if_nameindex()}
        except OSError:
            return True  # cannot enumerate on this platform: do not raise false alarms
    family = socket.AF_INET6 if ip.version == 6 else socket.AF_INET
    try:
        with socket.socket(family, socket.SOCK_DGRAM) as probe:
            probe.bind((str(ip), 0))
        return True
    except OSError:
        return False
