"""The transfer-engine boundary.

Everything above this boundary (services, UI) is written against these
protocols and the neutral types in ``domain`` / ``engine.commands`` /
``engine.events``.  libtorrent types never cross it; see
``engine.libtorrent_adapter`` for the one real implementation and
``tests/fakes/engine.py`` for the test double.

Command/event bridge
--------------------
* ``submit(command)`` is non-blocking and thread-safe.  The engine owner thread
  executes commands in submission order.
* The engine calls ``sink(event)`` on its own thread.  The sink must return
  quickly (the application's ``EventPump`` only enqueues).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol

from ..domain.identity import TorrentIdentity
from ..domain.transfers import TorrentMetadata
from .commands import Command, CreateRequest, EngineSettings
from .events import EngineEvent, ShutdownReport

EventSink = Callable[[EngineEvent], None]


class TorrentFormatError(ValueError):
    """The data is not a usable .torrent file. The message is safe to show."""


class CreationCancelled(Exception):
    pass


@dataclass(frozen=True, slots=True)
class EngineCapabilities:
    engine: str
    version: str
    v1: bool = True
    v2: bool = True
    hybrid: bool = True
    dht: bool = True
    pex: bool = True
    lsd: bool = True
    udp_trackers: bool = True
    http_trackers: bool = True
    web_seeds_bep19: bool = True
    web_seeds_bep17: bool = False
    upnp: bool = True
    natpmp: bool = True
    encryption: bool = True
    proxies: tuple[str, ...] = ("socks5", "socks5_pw", "http", "http_pw")
    webtorrent: bool = False
    i2p: bool = False
    notes: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CreatedTorrent:
    torrent_data: bytes
    metadata: TorrentMetadata


class TorrentEngine(Protocol):
    def capabilities(self) -> EngineCapabilities: ...

    def start(self, settings: EngineSettings, sink: EventSink) -> None:
        """Start the owner thread. Returns immediately; ``EngineStarted`` follows as an event."""

    def submit(self, command: Command) -> None: ...

    def shutdown(self, timeout: float) -> ShutdownReport:
        """Pause the session, flush resume data for at most ``timeout`` seconds, and stop."""


class TorrentCodec(Protocol):
    """Stateless metadata helpers implemented by the engine binding."""

    def inspect(self, torrent_data: bytes) -> TorrentMetadata:
        """Parse .torrent bytes. Raises :class:`TorrentFormatError`."""

    def make_magnet(self, torrent_data: bytes) -> str: ...

    def magnet_for(self, identity: TorrentIdentity, name: str = "",
                   trackers: tuple[str, ...] = ()) -> str: ...


class TorrentCreator(Protocol):
    def create(self, request: CreateRequest, progress: Callable[[int, int], None],
               cancelled: Callable[[], bool]) -> CreatedTorrent:
        """Hash the files and build the torrent (blocking; call from a worker thread).

        ``progress(pieces_done, pieces_total)`` is called as hashing proceeds.
        Raises :class:`CreationCancelled` when ``cancelled()`` turns true.
        """
