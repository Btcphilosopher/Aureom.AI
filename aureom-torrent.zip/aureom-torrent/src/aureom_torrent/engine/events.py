"""Events emitted by the engine owner thread.

``StatusBatch`` is a *snapshot* event: consumers may coalesce it (only the
latest matters).  Every other event is a lifecycle event and must never be
dropped.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..domain.identity import TorrentIdentity
from ..domain.transfers import TorrentMetadata, TorrentStatus, TransferDetails


@dataclass(frozen=True, slots=True)
class SessionStats:
    download_rate: int = 0
    upload_rate: int = 0
    dht_nodes: int = 0
    dht_enabled: bool = False
    listening: bool = False
    listen_port: int = 0
    has_incoming: bool = False
    num_peers: int = 0
    paused: bool = False


@dataclass(frozen=True, slots=True)
class ShutdownReport:
    clean: bool
    resume_saved: int = 0
    resume_unsaved: tuple[str, ...] = ()  # transfer ids whose latest state was not written
    message: str = ""


@dataclass(frozen=True, slots=True)
class EngineStarted:
    engine: str
    version: str


@dataclass(frozen=True, slots=True)
class ListenResult:
    ok: bool
    address: str
    port: int
    transport: str = ""
    message: str = ""


@dataclass(frozen=True, slots=True)
class EngineFault:
    """A session-level problem (e.g. the bound interface disappeared)."""

    message: str
    networking_stopped: bool = False


@dataclass(frozen=True, slots=True)
class TorrentAdded:
    transfer_id: str
    identity: TorrentIdentity
    name: str
    has_metadata: bool


@dataclass(frozen=True, slots=True)
class TorrentAddFailed:
    transfer_id: str
    message: str
    duplicate: bool = False


@dataclass(frozen=True, slots=True)
class MetadataReceived:
    transfer_id: str
    metadata: TorrentMetadata
    # None when the engine cannot yet serialise a complete .torrent (v2/hybrid metadata obtained
    # from peers lacks piece layers until the payload has been verified).
    torrent_data: bytes | None = None


@dataclass(frozen=True, slots=True)
class StatusBatch:
    statuses: tuple[TorrentStatus, ...]
    session: SessionStats = field(default_factory=SessionStats)


@dataclass(frozen=True, slots=True)
class TorrentFinished:
    """All selected files are complete and verified."""

    transfer_id: str


@dataclass(frozen=True, slots=True)
class TorrentChecked:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class TorrentPaused:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class TorrentResumed:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class TorrentErrored:
    transfer_id: str
    message: str
    file: str = ""
    kind: str = "storage"  # storage | metadata | other


@dataclass(frozen=True, slots=True)
class PieceHashFailed:
    transfer_id: str
    piece: int


@dataclass(frozen=True, slots=True)
class StorageMoved:
    transfer_id: str
    new_path: str


@dataclass(frozen=True, slots=True)
class StorageMoveFailed:
    transfer_id: str
    message: str


@dataclass(frozen=True, slots=True)
class TorrentRemoved:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class FilesDeleted:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class FilesDeleteFailed:
    transfer_id: str
    message: str


@dataclass(frozen=True, slots=True)
class TrackerAnnounced:
    transfer_id: str
    url: str
    ok: bool
    message: str = ""
    peers: int = 0


@dataclass(frozen=True, slots=True)
class ResumeDataReady:
    transfer_id: str
    data: bytes


@dataclass(frozen=True, slots=True)
class ResumeDataFailed:
    transfer_id: str
    message: str


@dataclass(frozen=True, slots=True)
class DetailsReady:
    details: TransferDetails


@dataclass(frozen=True, slots=True)
class TorrentConflict:
    """Metadata revealed that two transfers are the same (hybrid) torrent."""

    transfer_id: str
    other_transfer_id: str


@dataclass(frozen=True, slots=True)
class PortMapped:
    ok: bool
    protocol: str
    external_port: int = 0
    message: str = ""


@dataclass(frozen=True, slots=True)
class TorrentExported:
    transfer_id: str
    torrent_data: bytes | None
    message: str = ""


@dataclass(frozen=True, slots=True)
class TransferNotice:
    """A non-fatal, per-transfer note for the activity log (e.g. resume data rejected)."""

    transfer_id: str
    level: str  # info | warning | error
    kind: str
    message: str


@dataclass(frozen=True, slots=True)
class EngineStopped:
    report: ShutdownReport


EngineEvent = (EngineStarted | ListenResult | EngineFault | TorrentAdded | TorrentAddFailed | MetadataReceived
               | StatusBatch | TorrentFinished | TorrentChecked | TorrentPaused | TorrentResumed | TorrentErrored
               | PieceHashFailed | StorageMoved | StorageMoveFailed | TorrentRemoved | FilesDeleted
               | FilesDeleteFailed | TrackerAnnounced | ResumeDataReady | ResumeDataFailed | DetailsReady
               | TorrentConflict | PortMapped | TorrentExported | TransferNotice | EngineStopped)
