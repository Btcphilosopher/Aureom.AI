"""Commands sent to the engine owner thread.

Commands are immutable, engine-neutral values.  ``TorrentEngine.submit`` never
blocks; outcomes arrive later as events (``engine.events``).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class EngineSettings:
    """Engine-neutral session configuration (derived from the application settings)."""

    listen_interfaces: str = "0.0.0.0:6881,[::]:6881"
    # Optional device name or IP literal that listening (and therefore outgoing) sockets are bound
    # to. The engine watches it and stops networking when it disappears.
    bound_interface: str = ""
    enable_dht: bool = True
    enable_pex: bool = True
    enable_lsd: bool = True
    enable_upnp: bool = True
    enable_natpmp: bool = True
    encryption: str = "enabled"  # enabled | forced | disabled
    max_connections: int = 300
    proxy_kind: str = "none"
    proxy_host: str = ""
    proxy_port: int = 0
    proxy_username: str = ""
    proxy_password: str = ""
    proxy_peers: bool = True
    proxy_trackers: bool = True
    proxy_hostnames: bool = True
    active_downloads: int = 3
    active_seeds: int = 5
    active_limit: int = 8
    download_rate_limit: int = 0
    upload_rate_limit: int = 0
    resume_save_interval_s: int = 60
    status_interval_ms: int = 500
    # Test/demo isolation: loopback only, no DHT/LSD/port mapping, local peers allowed.
    isolated: bool = False
    user_agent: str = "AureomTorrent/0.1"


@dataclass(frozen=True, slots=True)
class AddTorrent:
    transfer_id: str
    save_path: str
    torrent_data: bytes | None = None
    magnet_uri: str | None = None
    resume_data: bytes | None = None
    file_priorities: tuple[int, ...] | None = None
    paused: bool = False
    # Retrieve metadata only: the engine is told not to request any payload.
    metadata_only: bool = False
    download_limit: int = 0
    upload_limit: int = 0
    peers: tuple[tuple[str, int], ...] = ()


@dataclass(frozen=True, slots=True)
class ConfirmPreview:
    """Turn a metadata-only preview into a real transfer at ``save_path``.

    ``file_priorities=None`` keeps every file selected (used when the user
    starts a magnet without waiting for the preview).
    """

    transfer_id: str
    save_path: str
    file_priorities: tuple[int, ...] | None = None
    paused: bool = False


@dataclass(frozen=True, slots=True)
class ExportTorrent:
    """Ask for .torrent bytes of a transfer (answered by ``TorrentExported``)."""

    transfer_id: str


@dataclass(frozen=True, slots=True)
class RemoveTorrent:
    transfer_id: str
    delete_files: bool = False


@dataclass(frozen=True, slots=True)
class PauseTorrent:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class ResumeTorrent:
    """Start (or re-queue) a transfer under the engine's automatic queue management."""

    transfer_id: str


@dataclass(frozen=True, slots=True)
class ForceRecheck:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class SetFilePriorities:
    transfer_id: str
    priorities: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class MoveStorage:
    transfer_id: str
    new_path: str


@dataclass(frozen=True, slots=True)
class SetTorrentLimits:
    transfer_id: str
    download_limit: int = 0
    upload_limit: int = 0


@dataclass(frozen=True, slots=True)
class ReplaceTrackers:
    transfer_id: str
    trackers: tuple[tuple[str, int], ...]  # (url, tier)


@dataclass(frozen=True, slots=True)
class Reannounce:
    transfer_id: str


@dataclass(frozen=True, slots=True)
class ConnectPeer:
    transfer_id: str
    host: str
    port: int


@dataclass(frozen=True, slots=True)
class RequestDetails:
    transfer_id: str
    peers: bool = False
    trackers: bool = False
    files: bool = False
    pieces: bool = False


@dataclass(frozen=True, slots=True)
class ApplySettings:
    settings: EngineSettings


@dataclass(frozen=True, slots=True)
class SetSessionPaused:
    paused: bool
    reason: str = ""


@dataclass(frozen=True, slots=True)
class SaveResumeData:
    transfer_id: str | None = None  # None = every transfer that has unsaved state


Command = (AddTorrent | ConfirmPreview | ExportTorrent | RemoveTorrent | PauseTorrent | ResumeTorrent | ForceRecheck | SetFilePriorities
           | MoveStorage | SetTorrentLimits | ReplaceTrackers | Reannounce | ConnectPeer | RequestDetails
           | ApplySettings | SetSessionPaused | SaveResumeData)


@dataclass(frozen=True, slots=True)
class CreateRequest:
    """Input for torrent creation (hashing runs on a worker thread)."""

    root_path: str  # the selected file or folder
    files: tuple[str, ...]  # included files, relative to the folder (or the single file name)
    name: str = ""  # torrent name; defaults to the root's base name
    format: str = "hybrid"  # v1 | v2 | hybrid
    piece_length: int = 0  # 0 = automatic; otherwise a power of two, 16 KiB … 64 MiB
    trackers: tuple[tuple[str, ...], ...] = ()  # tiers
    web_seeds: tuple[str, ...] = ()
    private: bool = False
    comment: str = ""
    creator: str = "AUREOM TORRENT"
    # Optional publisher manifest (canonical JSON bytes) stored inside the info dictionary under
    # ``x-aureom-publisher`` so that it is covered by the torrent's info-hash.
    embedded_manifest: bytes = b""
