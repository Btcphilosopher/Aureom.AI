"""Stateless libtorrent helpers: .torrent inspection, magnet generation, torrent creation.

libtorrent types stay inside this module; callers receive neutral domain types.
Written against libtorrent 2.1.3 (``create_file_entry`` based creation API).
"""

from __future__ import annotations

import os
import time
from typing import Callable

import libtorrent as lt

from ..domain.identity import TorrentIdentity
from ..domain.transfers import TorrentFile, TorrentMetadata
from ..filesystem.paths import is_fatal_problem, relative_path_problems
from .commands import CreateRequest
from .interface import CreatedTorrent, CreationCancelled, TorrentFormatError

MAX_TORRENT_FILE_BYTES = 32 * 1024 * 1024
MANIFEST_INFO_KEY = b"x-aureom-publisher"
MAX_EMBEDDED_MANIFEST = 16 * 1024
MIN_PIECE_LENGTH = 16 * 1024
MAX_PIECE_LENGTH = 64 * 1024 * 1024
_LOAD_LIMITS = {"max_buffer_size": MAX_TORRENT_FILE_BYTES, "max_pieces": 0x200000, "max_decode_depth": 100,
                "max_decode_tokens": 3_000_000}


def identity_from_info_hashes(ih) -> TorrentIdentity:
    v1 = str(ih.v1) if ih.has_v1() else None
    v2 = str(ih.v2) if ih.has_v2() else None
    return TorrentIdentity(v1, v2)


def metadata_from_torrent_info(ti, *, trackers=(), web_seeds=(), raw: bytes | None = None,
                               comment: str = "", creator: str = "", created: int = 0) -> TorrentMetadata:
    fs = ti.layout()
    files = []
    problems: list[str] = []
    for i in range(fs.num_files()):
        path = fs.file_path(i).replace("\\", "/")
        pad = bool(fs.file_flags(i) & lt.file_storage.flag_pad_file)
        files.append(TorrentFile(index=i, path=path, size=fs.file_size(i), pad=pad))
        if not pad:
            for problem in relative_path_problems(path):
                if is_fatal_problem(problem) and len(problems) < 20:
                    problems.append(f"{path}: {problem}")
    manifest = b""
    if raw is not None:
        manifest = _embedded_manifest(ti)
        problems = _raw_path_problems(ti) + problems
    # libtorrent 2.1 carries comment / creator / creation date on add_torrent_params; the
    # torrent_info accessors are kept as a fallback for metadata obtained from a handle.
    comment = comment or _safe_call(ti, "comment") or ""
    creator = creator or _safe_call(ti, "creator") or ""
    created = created or _safe_call(ti, "creation_date") or 0
    return TorrentMetadata(
        identity=identity_from_info_hashes(ti.info_hashes()),
        name=ti.name(),
        total_size=sum(f.size for f in files if not f.pad),
        piece_length=ti.piece_length(),
        num_pieces=ti.num_pieces(),
        files=tuple(files),
        private=bool(ti.priv()),
        trackers=tuple(trackers),
        web_seeds=tuple(web_seeds),
        comment=str(comment)[:2000],
        creator=str(creator)[:200],
        creation_date=int(created) if created else None,
        path_problems=tuple(problems),
        embedded_manifest=manifest,
    )


def _safe_call(obj, name: str):
    try:
        return getattr(obj, name)()
    except Exception:
        return None


def _bad_component(part) -> bool:
    if not isinstance(part, bytes) or part in (b"", b".", b".."):
        return True
    return b"/" in part or b"\\" in part or b"\x00" in part


def _raw_path_problems(ti) -> list[str]:
    """Inspect the *unsanitised* info dictionary.

    libtorrent rewrites unsafe paths when it loads a torrent, so the sanitised
    layout never shows a traversal.  A legitimate torrent has no reason to
    contain such components, so their presence is reported and the application
    refuses the torrent.
    """
    try:
        info = lt.bdecode(ti.info_section())
    except Exception:
        return []
    if not isinstance(info, dict):
        return []
    bad = 0
    name = info.get(b"name")
    if isinstance(name, bytes) and (name in (b"", b".", b"..") or b"/" in name or b"\\" in name or b"\x00" in name):
        bad += 1
    for entry in info.get(b"files", []) or []:
        path = entry.get(b"path") if isinstance(entry, dict) else None
        if isinstance(path, list) and any(_bad_component(p) for p in path):
            bad += 1

    def walk(tree, depth=0):
        nonlocal bad
        if not isinstance(tree, dict) or depth > 64:
            return
        for key, value in tree.items():
            if key == b"":
                continue  # file leaf marker
            if _bad_component(key):
                bad += 1
            walk(value, depth + 1)

    walk(info.get(b"file tree"))
    if bad:
        return [f"the metadata contains {bad} unsafe path component(s) (absolute or parent-directory paths)"]
    return []


def _embedded_manifest(ti) -> bytes:
    try:
        info = lt.bdecode(ti.info_section())
    except Exception:
        return b""
    value = info.get(MANIFEST_INFO_KEY) if isinstance(info, dict) else None
    if isinstance(value, bytes) and 0 < len(value) <= MAX_EMBEDDED_MANIFEST:
        return value
    return b""


def load_params(torrent_data: bytes):
    """Parse .torrent bytes into ``add_torrent_params`` (raises TorrentFormatError)."""
    if not isinstance(torrent_data, (bytes, bytearray)) or not torrent_data:
        raise TorrentFormatError("The torrent file is empty.")
    if len(torrent_data) > MAX_TORRENT_FILE_BYTES:
        raise TorrentFormatError("The torrent file is larger than the 32 MiB limit.")
    try:
        atp = lt.load_torrent_buffer(bytes(torrent_data), dict(_LOAD_LIMITS))
    except Exception as exc:  # libtorrent raises RuntimeError with a descriptive message
        raise TorrentFormatError(f"This is not a valid torrent file ({exc}).") from exc
    if atp.ti is None or not atp.ti.is_valid():
        raise TorrentFormatError("This torrent file has no usable metadata.")
    return atp


def metadata_from_params(atp, raw: bytes | None) -> TorrentMetadata:
    tiers = list(atp.tracker_tiers) if atp.tracker_tiers else []
    trackers = tuple((url, tiers[i] if i < len(tiers) else 0) for i, url in enumerate(atp.trackers))
    return metadata_from_torrent_info(atp.ti, trackers=trackers, web_seeds=tuple(atp.url_seeds), raw=raw,
                                      comment=atp.comment or "", creator=atp.created_by or "",
                                      created=int(atp.creation_date or 0))


def torrent_bytes_from_params(atp) -> bytes:
    """Serialise ``add_torrent_params`` (with metadata) back to .torrent bytes."""
    return lt.bencode(lt.write_torrent_file(atp))


class LibtorrentCodec:
    def inspect(self, torrent_data: bytes) -> TorrentMetadata:
        atp = load_params(torrent_data)
        return metadata_from_params(atp, torrent_data)

    def make_magnet(self, torrent_data: bytes) -> str:
        atp = load_params(torrent_data)
        atp.name = atp.ti.name()
        return lt.make_magnet_uri(atp)

    def magnet_for(self, identity: TorrentIdentity, name: str = "", trackers: tuple[str, ...] = ()) -> str:
        atp = lt.add_torrent_params()
        ih = lt.info_hash_t()
        if identity.v1 and identity.v2:
            ih = lt.info_hash_t(lt.sha1_hash(bytes.fromhex(identity.v1)), lt.sha256_hash(bytes.fromhex(identity.v2)))
        elif identity.v1:
            ih = lt.info_hash_t(lt.sha1_hash(bytes.fromhex(identity.v1)))
        else:
            ih = lt.info_hash_t(lt.sha256_hash(bytes.fromhex(identity.v2)))
        atp.info_hashes = ih
        atp.name = name
        atp.trackers = list(trackers)
        return lt.make_magnet_uri(atp)


def automatic_piece_length(total_size: int) -> int:
    """Aim for roughly 1 000–2 000 pieces, within 16 KiB … 16 MiB (powers of two)."""
    length = MIN_PIECE_LENGTH
    while length < 16 * 1024 * 1024 and total_size / length > 2000:
        length *= 2
    return length


def valid_piece_length(value: int) -> bool:
    return value == 0 or (MIN_PIECE_LENGTH <= value <= MAX_PIECE_LENGTH and value & (value - 1) == 0)


class LibtorrentCreator:
    def create(self, request: CreateRequest, progress: Callable[[int, int], None],
               cancelled: Callable[[], bool]) -> CreatedTorrent:
        if request.format not in ("v1", "v2", "hybrid"):
            raise ValueError("format must be v1, v2 or hybrid")
        if not valid_piece_length(request.piece_length):
            raise ValueError("piece length must be a power of two between 16 KiB and 64 MiB")
        if not request.files:
            raise ValueError("no files were selected")
        if len(request.embedded_manifest) > MAX_EMBEDDED_MANIFEST:
            raise ValueError("the embedded publisher manifest is too large")

        root = os.path.abspath(request.root_path)
        single = os.path.isfile(root)
        parent = os.path.dirname(root)
        base = os.path.basename(root)
        name = request.name or base
        if single and name != base:
            raise ValueError("a single-file torrent takes its name from the file")

        entries = []
        total = 0
        for rel in sorted(set(request.files)):
            fatal = [p for p in relative_path_problems(rel) if is_fatal_problem(p)]
            if fatal:
                raise ValueError(f"unsafe file path “{rel}”: {', '.join(fatal)}")
            disk = root if single else os.path.join(root, *rel.split("/"))
            if os.path.islink(disk) or not os.path.isfile(disk):
                raise ValueError(f"“{rel}” is not a regular file")
            st = os.stat(disk)
            total += st.st_size
            entries.append(lt.create_file_entry(base if single else f"{base}/{rel}", st.st_size, 0, int(st.st_mtime)))
        if total <= 0:
            raise ValueError("the selected files are empty")

        flags = 0
        if request.format == "v1":
            flags = lt.create_torrent.v1_only
        elif request.format == "v2":
            flags = lt.create_torrent.v2_only
        piece_length = request.piece_length or automatic_piece_length(total)
        ct = lt.create_torrent(entries, piece_length, flags)
        total_pieces = ct.num_pieces()

        def on_piece(index: int) -> None:
            if cancelled():
                raise CreationCancelled()
            progress(int(index) + 1, total_pieces)

        progress(0, total_pieces)
        try:
            lt.set_piece_hashes(ct, parent, on_piece)
        except CreationCancelled:
            raise
        except RuntimeError as exc:
            if cancelled():
                raise CreationCancelled() from exc
            raise OSError(f"Hashing failed: {exc}") from exc

        for tier, urls in enumerate(request.trackers):
            for url in urls:
                ct.add_tracker(url, tier)
        for url in request.web_seeds:
            ct.add_url_seed(url)
        ct.set_priv(bool(request.private))
        if request.comment:
            ct.set_comment(request.comment[:1024])
        ct.set_creator((request.creator or "AUREOM TORRENT")[:128])
        ct.set_creation_date(int(time.time()))

        entry = ct.generate()
        info = entry[b"info"]
        if name != base and not single:
            info[b"name"] = name.encode("utf-8")
        if request.embedded_manifest:
            info[MANIFEST_INFO_KEY] = bytes(request.embedded_manifest)
        data = lt.bencode(entry)
        atp = load_params(data)  # proves the result is loadable and yields the final identity
        return CreatedTorrent(torrent_data=data, metadata=metadata_from_params(atp, data))
