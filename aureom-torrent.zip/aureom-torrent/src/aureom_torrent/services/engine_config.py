"""Derive engine-neutral session settings from the application settings."""

from __future__ import annotations

import datetime as _dt

from ..domain.schedule import BandwidthPlan, bandwidth_plan
from ..engine.commands import EngineSettings
from ..settings.models import AppSettings
from ..settings.secrets import SECRET_BT_PROXY_PASSWORD, SecretStore


def listen_interfaces(net) -> str:
    port = net.listen_port
    if net.bind_interface:
        return f"{net.bind_interface}:{port}"
    if net.listen_address:
        host = net.listen_address
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        return f"{host}:{port}"
    return f"0.0.0.0:{port},[::]:{port}"


def engine_settings(app: AppSettings, secrets: SecretStore | None, *, plan: BandwidthPlan | None = None,
                    isolated: bool = False, now: _dt.datetime | None = None) -> EngineSettings:
    net = app.bittorrent
    plan = plan or bandwidth_plan(app.queue, now or _dt.datetime.now())
    password = ""
    if net.proxy.kind in ("socks5_pw", "http_pw") and secrets is not None:
        password = secrets.get(SECRET_BT_PROXY_PASSWORD) or ""
    return EngineSettings(
        listen_interfaces="127.0.0.1:0" if isolated else listen_interfaces(net),
        bound_interface="" if isolated else net.bind_interface,
        enable_dht=net.enable_dht, enable_pex=net.enable_pex, enable_lsd=net.enable_lsd,
        enable_upnp=net.enable_upnp, enable_natpmp=net.enable_natpmp,
        encryption=net.encryption, max_connections=net.max_connections,
        proxy_kind=net.proxy.kind, proxy_host=net.proxy.host, proxy_port=net.proxy.port,
        proxy_username=net.proxy.username, proxy_password=password,
        proxy_peers=net.proxy.proxy_peers, proxy_trackers=net.proxy.proxy_trackers,
        proxy_hostnames=net.proxy.proxy_hostnames,
        active_downloads=app.queue.max_active_downloads, active_seeds=app.queue.max_active_seeds,
        active_limit=app.queue.max_active_total,
        download_rate_limit=plan.download_limit, upload_rate_limit=plan.upload_limit,
        resume_save_interval_s=app.general.resume_save_interval_s,
        isolated=isolated,
    )
