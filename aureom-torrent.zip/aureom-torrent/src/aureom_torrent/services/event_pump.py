"""Bridge between the engine owner thread and application services.

The engine calls :meth:`EventPump.post` (cheap: append + notify).  A dispatcher
thread delivers events to the handler in order.  Consecutive status snapshots
that have not been delivered yet are *coalesced* (the newer status of each
transfer replaces the older); lifecycle events are never dropped or reordered.
"""

from __future__ import annotations

import collections
import logging
import threading
from typing import Callable

from ..engine.events import EngineEvent, StatusBatch

log = logging.getLogger(__name__)


class EventPump:
    def __init__(self, handler: Callable[[EngineEvent], None]):
        self._handler = handler
        self._queue: collections.deque[EngineEvent] = collections.deque()
        self._cond = threading.Condition()
        self._thread: threading.Thread | None = None
        self._stopping = False
        self.coalesced = 0
        self.delivered = 0

    def post(self, event: EngineEvent) -> None:
        with self._cond:
            if isinstance(event, StatusBatch) and self._queue and isinstance(self._queue[-1], StatusBatch):
                previous = self._queue[-1]
                merged = {s.transfer_id: s for s in previous.statuses}
                merged.update({s.transfer_id: s for s in event.statuses})
                self._queue[-1] = StatusBatch(tuple(merged.values()), event.session)
                self.coalesced += 1
            else:
                self._queue.append(event)
            self._cond.notify()

    def start(self) -> None:
        if self._thread is None:
            self._thread = threading.Thread(target=self._run, name="aureom-events", daemon=True)
            self._thread.start()

    def _run(self) -> None:
        while True:
            with self._cond:
                while not self._queue and not self._stopping:
                    self._cond.wait()
                if not self._queue and self._stopping:
                    return
                event = self._queue.popleft()
            self._deliver(event)

    def _deliver(self, event: EngineEvent) -> None:
        try:
            self._handler(event)
        except Exception:
            log.exception("handler failed for %s", type(event).__name__)
        self.delivered += 1

    def drain(self) -> int:
        """Deliver everything queued on the calling thread (tests and shutdown)."""
        count = 0
        while True:
            with self._cond:
                if not self._queue:
                    return count
                event = self._queue.popleft()
            self._deliver(event)
            count += 1

    def stop(self, timeout: float = 5.0) -> None:
        """Deliver what is queued, then stop the dispatcher thread."""
        with self._cond:
            self._stopping = True
            self._cond.notify_all()
        if self._thread is not None:
            self._thread.join(timeout)
            self._thread = None
        self.drain()
